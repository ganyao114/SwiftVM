
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/2/8.bin:     file format binary


Disassembly of section .data:

00007f716ee01170 <.data>:
    7f716ee01170:	sub    rsp,0x150
    7f716ee01177:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0117f:	mov    QWORD PTR [rsp],r11
    7f716ee01183:	cmp    DWORD PTR [r12+0x310],0x0
    7f716ee0118c:	je     0x7f716ee01217
    7f716ee01192:	push   rdx
    7f716ee01193:	push   rsi
    7f716ee01194:	push   r10
    7f716ee01196:	push   r11
    7f716ee01198:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0119d:	mov    r10d,edx
    7f716ee011a0:	and    r10d,0xc000
    7f716ee011a7:	shl    r10d,0x10
    7f716ee011ab:	mov    r11d,edx
    7f716ee011ae:	and    r11d,0x100
    7f716ee011b5:	shl    r11d,0x15
    7f716ee011b9:	or     r10d,r11d
    7f716ee011bc:	and    edx,0x1
    7f716ee011bf:	shl    edx,0x1c
    7f716ee011c2:	or     r10d,edx
    7f716ee011c5:	btc    r10,0x1d
    7f716ee011ca:	mov    r11d,0xf0000000
    7f716ee011d0:	and    r11,r10
    7f716ee011d3:	movabs rsi,0xffffffff0fffffff
    7f716ee011dd:	and    rbx,rsi
    7f716ee011e0:	or     rbx,r11
    7f716ee011e3:	pop    r11
    7f716ee011e5:	pop    r10
    7f716ee011e7:	pop    rsi
    7f716ee011e8:	pop    rdx
    7f716ee011e9:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee011f1:	mov    eax,0x4103f8
    7f716ee011f6:	mov    QWORD PTR [r12+0x100],rax
    7f716ee011fe:	add    rsp,0x150
    7f716ee01205:	mov    eax,0x3
    7f716ee0120a:	movabs r11,0x5fdfb8bf7ca0
    7f716ee01214:	jmp    r11
    7f716ee01217:	mov    r13d,DWORD PTR [r12+0x98]
    7f716ee0121f:	add    r13d,0x1
    7f716ee01223:	mov    QWORD PTR [r12+0x98],r13
    7f716ee0122b:	sub    r13d,0x10000
    7f716ee01232:	mov    rcx,QWORD PTR [r12+0x380]
    7f716ee0123a:	jrcxz  0x7f716ee01241
    7f716ee0123c:	jmp    0x7f716ee0abf5
    7f716ee01241:	jne    0x7f716ee0125a
    7f716ee01247:	mov    r11,rax
    7f716ee0124a:	lahf
    7f716ee0124b:	seto   al
    7f716ee0124e:	mov    WORD PTR [rsp],ax
    7f716ee01252:	mov    rax,r11
    7f716ee01255:	jmp    0x7f716ee0126d
    7f716ee0125a:	mov    r11,rax
    7f716ee0125d:	lahf
    7f716ee0125e:	seto   al
    7f716ee01261:	mov    WORD PTR [rsp],ax
    7f716ee01265:	mov    rax,r11
    7f716ee01268:	jmp    0x7f716ee03d43
    7f716ee0126d:	mov    r13d,0x420000
    7f716ee01273:	mov    QWORD PTR [r12+0x40],r13
    7f716ee01278:	movabs r13,0x100000001
    7f716ee01282:	mov    r14d,0x0
    7f716ee01288:	mov    QWORD PTR [r12+0x110],r13
    7f716ee01290:	mov    QWORD PTR [r12+0x118],r14
    7f716ee01298:	movabs r13,0x3fa0000000000000
    7f716ee012a2:	mov    QWORD PTR [r12+0x50],r13
    7f716ee012a7:	mov    r13d,0x420b10
    7f716ee012ad:	mov    r14,QWORD PTR [r13+0x0]
    7f716ee012b1:	mov    r13d,0x0
    7f716ee012b7:	mov    QWORD PTR [r12+0x120],r14
    7f716ee012bf:	mov    QWORD PTR [r12+0x128],r13
    7f716ee012c7:	movabs r13,0x4100000041
    7f716ee012d1:	mov    r14d,0x0
    7f716ee012d7:	mov    QWORD PTR [r12+0x140],r13
    7f716ee012df:	mov    QWORD PTR [r12+0x148],r14
    7f716ee012e7:	movabs r13,0x3fc0000000000000
    7f716ee012f1:	movabs r14,0x3fc0000000000000
    7f716ee012fb:	mov    QWORD PTR [r12+0x150],r13
    7f716ee01303:	mov    QWORD PTR [r12+0x158],r14
    7f716ee0130b:	movabs r13,0x200000002
    7f716ee01315:	mov    r14d,0x0
    7f716ee0131b:	mov    QWORD PTR [r12+0x160],r13
    7f716ee01323:	mov    QWORD PTR [r12+0x168],r14
    7f716ee0132b:	movabs r13,0x3fa0000000000000
    7f716ee01335:	mov    QWORD PTR [r12+0x130],r13
    7f716ee0133d:	mov    QWORD PTR [r12+0x138],r13
    7f716ee01345:	mov    r13d,0x2
    7f716ee0134b:	mov    QWORD PTR [r12+0x170],r13
    7f716ee01353:	mov    QWORD PTR [r12+0x178],r13
    7f716ee0135b:	mov    r13d,0x420000
    7f716ee01361:	mov    QWORD PTR [r12+0x40],r13
    7f716ee01366:	mov    r13d,0x430000
    7f716ee0136c:	mov    QWORD PTR [r12+0x50],r13
    7f716ee01371:	mov    r13d,0x420a40
    7f716ee01377:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7f716ee0137d:	movdqu XMMWORD PTR [r12+0x180],xmm2
    7f716ee01387:	mov    r13d,0x0
    7f716ee0138d:	mov    QWORD PTR [r12+0x48],r13
    7f716ee01392:	mov    r13d,0x431000
    7f716ee01398:	add    r13,0xe00
    7f716ee0139f:	mov    QWORD PTR [r12+0x40],r13
    7f716ee013a4:	mov    r13d,0x430cb8
    7f716ee013aa:	mov    r14d,DWORD PTR [r12]
    7f716ee013ae:	mov    DWORD PTR [r13+0x0],r14d
    7f716ee013b2:	mov    r13d,0x0
    7f716ee013b8:	mov    DWORD PTR [r12+0x32c],r13d
    7f716ee013c0:	mov    r13d,0x432000
    7f716ee013c6:	mov    QWORD PTR [r12+0x50],r13
    7f716ee013cb:	mov    r11,rax
    7f716ee013ce:	movzx  eax,WORD PTR [rsp]
    7f716ee013d2:	add    al,0x7f
    7f716ee013d4:	sahf
    7f716ee013d5:	mov    rax,r11
    7f716ee013d8:	jmp    0x7f716ee013dd
    7f716ee013dd:	mov    r13,QWORD PTR [r12+0x180]
    7f716ee013e5:	mov    r14,QWORD PTR [r12+0x188]
    7f716ee013ed:	mov    r15d,0x0
    7f716ee013f3:	mov    r11,rax
    7f716ee013f6:	lahf
    7f716ee013f7:	seto   al
    7f716ee013fa:	mov    WORD PTR [rsp],ax
    7f716ee013fe:	mov    rax,r11
    7f716ee01401:	mov    ecx,0xffffffff
    7f716ee01406:	and    r13,rcx
    7f716ee01409:	mov    rbp,r15
    7f716ee0140c:	or     rbp,r13
    7f716ee0140f:	mov    ecx,0xffffffff
    7f716ee01414:	and    r14,rcx
    7f716ee01417:	shl    r14,0x20
    7f716ee0141b:	or     rbp,r14
    7f716ee0141e:	mov    QWORD PTR [r12+0x210],rbp
    7f716ee01426:	mov    QWORD PTR [r12+0x218],r15
    7f716ee0142e:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    7f716ee01438:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    7f716ee01442:	movdqa xmm1,xmm3
    7f716ee01446:	psubd  xmm2,xmm1
    7f716ee0144a:	movdqa xmm14,xmm2
    7f716ee0144f:	movdqa xmm1,xmm14
    7f716ee01454:	movq   rax,xmm1
    7f716ee01459:	mov    r13,rax
    7f716ee0145c:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    7f716ee01466:	movdqu xmm4,XMMWORD PTR [r12+0x170]
    7f716ee01470:	movdqa xmm1,xmm4
    7f716ee01474:	paddq  xmm2,xmm1
    7f716ee01478:	movdqu XMMWORD PTR [r12+0x180],xmm2
    7f716ee01482:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    7f716ee0148c:	movdqa xmm1,xmm2
    7f716ee01490:	paddd  xmm3,xmm1
    7f716ee01494:	movdqa xmm14,xmm3
    7f716ee01499:	movdqa xmm1,xmm14
    7f716ee0149e:	movq   rax,xmm1
    7f716ee014a3:	mov    r14,rax
    7f716ee014a6:	mov    r15d,0x0
    7f716ee014ac:	mov    QWORD PTR [r12+0x120],r14
    7f716ee014b4:	mov    QWORD PTR [r12+0x128],r15
    7f716ee014bc:	mov    r14d,0x0
    7f716ee014c2:	mov    ecx,0xffffffff
    7f716ee014c7:	mov    r15,r13
    7f716ee014ca:	and    r15,rcx
    7f716ee014cd:	mov    rbp,r14
    7f716ee014d0:	or     rbp,r15
    7f716ee014d3:	shr    r13,0x20
    7f716ee014d7:	mov    ecx,0xffffffff
    7f716ee014dc:	and    r13,rcx
    7f716ee014df:	or     r14,r13
    7f716ee014e2:	mov    QWORD PTR [r12+0x220],rbp
    7f716ee014ea:	mov    QWORD PTR [r12+0x228],r14
    7f716ee014f2:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    7f716ee014fc:	movdqu xmm3,XMMWORD PTR [r12+0x110]
    7f716ee01506:	movdqa xmm1,xmm3
    7f716ee0150a:	paddd  xmm2,xmm1
    7f716ee0150e:	movdqa xmm14,xmm2
    7f716ee01513:	movdqa xmm1,xmm14
    7f716ee01518:	movq   rax,xmm1
    7f716ee0151d:	mov    r13,rax
    7f716ee01520:	mov    r14d,0x0
    7f716ee01526:	mov    QWORD PTR [r12+0x210],r13
    7f716ee0152e:	mov    QWORD PTR [r12+0x218],r14
    7f716ee01536:	lea    r13,[r12]
    7f716ee0153a:	movabs r14,0xb6e61da31
    7f716ee01544:	mov    r15d,0x410468
    7f716ee0154a:	mov    rdx,QWORD PTR [rsp]
    7f716ee0154e:	mov    r10d,edx
    7f716ee01551:	and    r10d,0xc000
    7f716ee01558:	shl    r10d,0x10
    7f716ee0155c:	mov    r11d,edx
    7f716ee0155f:	and    r11d,0x100
    7f716ee01566:	shl    r11d,0x15
    7f716ee0156a:	or     r10d,r11d
    7f716ee0156d:	and    edx,0x1
    7f716ee01570:	shl    edx,0x1c
    7f716ee01573:	or     r10d,edx
    7f716ee01576:	btc    r10,0x1d
    7f716ee0157b:	mov    r11d,0xf0000000
    7f716ee01581:	and    r11,r10
    7f716ee01584:	movabs rsi,0xffffffff0fffffff
    7f716ee0158e:	and    rbx,rsi
    7f716ee01591:	or     rbx,r11
    7f716ee01594:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee015a0:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee015a8:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee015ae:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee015b3:	test   r10d,0x3f
    7f716ee015ba:	je     0x7f716ee015df
    7f716ee015c0:	mov    r11d,r10d
    7f716ee015c3:	shr    r10d,1
    7f716ee015c6:	and    r10d,0x1e
    7f716ee015ca:	and    r11d,0x1
    7f716ee015ce:	or     r10d,r11d
    7f716ee015d1:	or     DWORD PTR [r12+0x314],r10d
    7f716ee015d9:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee015df:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee015e5:	movabs r11,0x5fdfb8a595e0
    7f716ee015ef:	mov    rdi,r13
    7f716ee015f2:	mov    rsi,r14
    7f716ee015f5:	mov    rdx,r15
    7f716ee015f8:	call   r11
    7f716ee015fb:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee01601:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee01609:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee01615:	mov    rbp,rax
    7f716ee01618:	mov    r13,QWORD PTR [r12+0x210]
    7f716ee01620:	mov    r14d,0x0
    7f716ee01626:	mov    ecx,0xffffffff
    7f716ee0162b:	mov    r15,r13
    7f716ee0162e:	and    r15,rcx
    7f716ee01631:	mov    rbp,r14
    7f716ee01634:	or     rbp,r15
    7f716ee01637:	shr    r13,0x20
    7f716ee0163b:	mov    ecx,0xffffffff
    7f716ee01640:	and    r13,rcx
    7f716ee01643:	or     r14,r13
    7f716ee01646:	mov    QWORD PTR [r12+0x210],rbp
    7f716ee0164e:	mov    QWORD PTR [r12+0x218],r14
    7f716ee01656:	lea    r13,[r12]
    7f716ee0165a:	movabs r14,0xb6e61da10
    7f716ee01664:	mov    r15d,0x410470
    7f716ee0166a:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee01676:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0167e:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee01684:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee01689:	test   r10d,0x3f
    7f716ee01690:	je     0x7f716ee016b5
    7f716ee01696:	mov    r11d,r10d
    7f716ee01699:	shr    r10d,1
    7f716ee0169c:	and    r10d,0x1e
    7f716ee016a0:	and    r11d,0x1
    7f716ee016a4:	or     r10d,r11d
    7f716ee016a7:	or     DWORD PTR [r12+0x314],r10d
    7f716ee016af:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee016b5:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee016bb:	movabs r11,0x5fdfb8a595e0
    7f716ee016c5:	mov    rdi,r13
    7f716ee016c8:	mov    rsi,r14
    7f716ee016cb:	mov    rdx,r15
    7f716ee016ce:	call   r11
    7f716ee016d1:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee016d7:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee016df:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee016eb:	mov    rbp,rax
    7f716ee016ee:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    7f716ee016f8:	movdqu xmm3,XMMWORD PTR [r12+0x150]
    7f716ee01702:	movdqa xmm0,xmm2
    7f716ee01706:	movdqa xmm1,xmm3
    7f716ee0170a:	mulpd  xmm0,xmm1
    7f716ee0170e:	movdqa xmm14,xmm0
    7f716ee01713:	movdqu xmm15,XMMWORD PTR [rip+0x9f34]        # 0x7f716ee0b650
    7f716ee0171c:	pand   xmm14,xmm15
    7f716ee01721:	movdqu xmm15,XMMWORD PTR [rip+0x9f36]        # 0x7f716ee0b660
    7f716ee0172a:	pcmpeqq xmm14,xmm15
    7f716ee01730:	movdqa xmm15,xmm0
    7f716ee01735:	cmpunordpd xmm15,xmm0
    7f716ee0173b:	por    xmm14,xmm15
    7f716ee01740:	pmovmskb ecx,xmm14
    7f716ee01745:	jrcxz  0x7f716ee0174c
    7f716ee01747:	jmp    0x7f716ee03dbd
    7f716ee0174c:	movdqa xmm4,xmm0
    7f716ee01750:	movdqu XMMWORD PTR [r12+0x220],xmm4
    7f716ee0175a:	mov    r13,QWORD PTR [r12+0x48]
    7f716ee0175f:	mov    r14,QWORD PTR [r12+0x50]
    7f716ee01764:	add    r14,r13
    7f716ee01767:	movdqu XMMWORD PTR [r14],xmm4
    7f716ee0176c:	mov    r14d,0x0
    7f716ee01772:	mov    DWORD PTR [r12+0x32c],r14d
    7f716ee0177a:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    7f716ee01784:	movdqu xmm3,XMMWORD PTR [r12+0x130]
    7f716ee0178e:	movdqa xmm0,xmm2
    7f716ee01792:	movdqa xmm1,xmm3
    7f716ee01796:	mulpd  xmm0,xmm1
    7f716ee0179a:	movdqa xmm14,xmm0
    7f716ee0179f:	movdqu xmm15,XMMWORD PTR [rip+0x9ea8]        # 0x7f716ee0b650
    7f716ee017a8:	pand   xmm14,xmm15
    7f716ee017ad:	movdqu xmm15,XMMWORD PTR [rip+0x9eaa]        # 0x7f716ee0b660
    7f716ee017b6:	pcmpeqq xmm14,xmm15
    7f716ee017bc:	movdqa xmm15,xmm0
    7f716ee017c1:	cmpunordpd xmm15,xmm0
    7f716ee017c7:	por    xmm14,xmm15
    7f716ee017cc:	pmovmskb ecx,xmm14
    7f716ee017d1:	jrcxz  0x7f716ee017d8
    7f716ee017d3:	jmp    0x7f716ee03de1
    7f716ee017d8:	movdqa xmm4,xmm0
    7f716ee017dc:	movdqu XMMWORD PTR [r12+0x210],xmm4
    7f716ee017e6:	mov    r14,QWORD PTR [r12+0x40]
    7f716ee017eb:	add    r14,r13
    7f716ee017ee:	movdqu XMMWORD PTR [r14],xmm4
    7f716ee017f3:	add    r13,0x10
    7f716ee017f7:	mov    QWORD PTR [r12+0x48],r13
    7f716ee017fc:	sub    r13,0x200
    7f716ee01803:	mov    rcx,QWORD PTR [r12+0x380]
    7f716ee0180b:	jrcxz  0x7f716ee01812
    7f716ee0180d:	jmp    0x7f716ee0ac89
    7f716ee01812:	jne    0x7f716ee013dd
    7f716ee01818:	mov    r11,rax
    7f716ee0181b:	lahf
    7f716ee0181c:	seto   al
    7f716ee0181f:	mov    WORD PTR [rsp],ax
    7f716ee01823:	mov    rax,r11
    7f716ee01826:	jmp    0x7f716ee0182b
    7f716ee0182b:	mov    r13,QWORD PTR [r12+0x50]
    7f716ee01830:	mov    r14,r13
    7f716ee01833:	add    r14,0x80
    7f716ee0183a:	mov    r15,r14
    7f716ee0183d:	add    r15,0x10
    7f716ee01841:	movdqu xmm2,XMMWORD PTR [r14]
    7f716ee01846:	movdqu xmm3,XMMWORD PTR [r15]
    7f716ee0184b:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7f716ee01855:	movdqu XMMWORD PTR [r12+0x110],xmm3
    7f716ee0185f:	mov    r14d,0x0
    7f716ee01865:	mov    r15d,0x0
    7f716ee0186b:	mov    QWORD PTR [r12+0x1b0],r14
    7f716ee01873:	mov    QWORD PTR [r12+0x1b8],r15
    7f716ee0187b:	mov    r14,r13
    7f716ee0187e:	add    r14,0x40
    7f716ee01882:	mov    r15,r14
    7f716ee01885:	add    r15,0x10
    7f716ee01889:	movdqu xmm4,XMMWORD PTR [r14]
    7f716ee0188e:	movdqu xmm5,XMMWORD PTR [r15]
    7f716ee01893:	movdqu XMMWORD PTR [r12+0x250],xmm4
    7f716ee0189d:	movdqu XMMWORD PTR [r12+0x120],xmm5
    7f716ee018a7:	mov    r14d,0x0
    7f716ee018ad:	mov    QWORD PTR [r12+0x48],r14
    7f716ee018b2:	mov    r14,r13
    7f716ee018b5:	add    r14,0x10
    7f716ee018b9:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    7f716ee018bf:	movdqu xmm6,XMMWORD PTR [r14]
    7f716ee018c4:	movdqu XMMWORD PTR [r12+0x170],xmm4
    7f716ee018ce:	movdqu XMMWORD PTR [r12+0x180],xmm6
    7f716ee018d8:	mov    r14,QWORD PTR [r12+0xf8]
    7f716ee018e0:	mov    r15,r14
    7f716ee018e3:	add    r15,0xe0
    7f716ee018ea:	mov    rbp,r15
    7f716ee018ed:	add    rbp,0x10
    7f716ee018f1:	movdqu XMMWORD PTR [r15],xmm3
    7f716ee018f6:	mov    r15d,0x0
    7f716ee018fc:	mov    DWORD PTR [r12+0x32c],r15d
    7f716ee01904:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7f716ee01909:	mov    r15,r13
    7f716ee0190c:	add    r15,0xc0
    7f716ee01913:	mov    rbp,r15
    7f716ee01916:	add    rbp,0x10
    7f716ee0191a:	movdqu xmm2,XMMWORD PTR [r15]
    7f716ee0191f:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7f716ee01924:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7f716ee0192e:	movdqu XMMWORD PTR [r12+0x110],xmm3
    7f716ee01938:	mov    r15,r13
    7f716ee0193b:	add    r15,0x140
    7f716ee01942:	mov    rbp,r15
    7f716ee01945:	add    rbp,0x10
    7f716ee01949:	movdqu xmm7,XMMWORD PTR [r15]
    7f716ee0194e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    7f716ee01954:	movdqu XMMWORD PTR [r12+0x270],xmm7
    7f716ee0195e:	movdqu XMMWORD PTR [r12+0x190],xmm8
    7f716ee01968:	mov    r15,r13
    7f716ee0196b:	add    r15,0x180
    7f716ee01972:	mov    rbp,r15
    7f716ee01975:	add    rbp,0x10
    7f716ee01979:	movdqu xmm7,XMMWORD PTR [r15]
    7f716ee0197e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    7f716ee01984:	movdqu XMMWORD PTR [r12+0x2a0],xmm7
    7f716ee0198e:	movdqu XMMWORD PTR [r12+0x1a0],xmm8
    7f716ee01998:	mov    r15,r14
    7f716ee0199b:	add    r15,0xc0
    7f716ee019a2:	mov    rbp,r15
    7f716ee019a5:	add    rbp,0x10
    7f716ee019a9:	movdqu XMMWORD PTR [r15],xmm3
    7f716ee019ae:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7f716ee019b3:	mov    r15,r13
    7f716ee019b6:	add    r15,0x100
    7f716ee019bd:	mov    rbp,r15
    7f716ee019c0:	add    rbp,0x10
    7f716ee019c4:	movdqu xmm2,XMMWORD PTR [r15]
    7f716ee019c9:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7f716ee019ce:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7f716ee019d8:	movdqu XMMWORD PTR [r12+0x300],xmm3
    7f716ee019e2:	mov    r15,r13
    7f716ee019e5:	add    r15,0x1c0
    7f716ee019ec:	mov    rbp,r15
    7f716ee019ef:	add    rbp,0x10
    7f716ee019f3:	movdqu xmm3,XMMWORD PTR [r15]
    7f716ee019f8:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    7f716ee019fd:	movdqu XMMWORD PTR [r12+0x240],xmm3
    7f716ee01a07:	movdqu XMMWORD PTR [r12+0x1c0],xmm7
    7f716ee01a11:	mov    r15,r13
    7f716ee01a14:	add    r15,0x20
    7f716ee01a18:	mov    rbp,r15
    7f716ee01a1b:	add    rbp,0x10
    7f716ee01a1f:	movdqu xmm7,XMMWORD PTR [r15]
    7f716ee01a24:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    7f716ee01a2a:	movdqu XMMWORD PTR [r12+0x1d0],xmm7
    7f716ee01a34:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
    7f716ee01a3e:	mov    r15,r14
    7f716ee01a41:	add    r15,0x20
    7f716ee01a45:	mov    rbp,r15
    7f716ee01a48:	add    rbp,0x10
    7f716ee01a4c:	movdqu XMMWORD PTR [r15],xmm2
    7f716ee01a51:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    7f716ee01a56:	mov    r15,r13
    7f716ee01a59:	add    r15,0x60
    7f716ee01a5d:	mov    rbp,r15
    7f716ee01a60:	add    rbp,0x10
    7f716ee01a64:	movdqu xmm2,XMMWORD PTR [r15]
    7f716ee01a69:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    7f716ee01a6e:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7f716ee01a78:	movdqu XMMWORD PTR [r12+0x120],xmm5
    7f716ee01a82:	mov    r15,r14
    7f716ee01a85:	add    r15,0x60
    7f716ee01a89:	mov    rbp,r15
    7f716ee01a8c:	add    rbp,0x10
    7f716ee01a90:	movdqu XMMWORD PTR [r15],xmm4
    7f716ee01a95:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    7f716ee01a9a:	mov    r15,r13
    7f716ee01a9d:	add    r15,0xe0
    7f716ee01aa4:	mov    rbp,r15
    7f716ee01aa7:	add    rbp,0x10
    7f716ee01aab:	movdqu xmm3,XMMWORD PTR [r15]
    7f716ee01ab0:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    7f716ee01ab5:	movdqu XMMWORD PTR [r12+0x200],xmm3
    7f716ee01abf:	movdqu XMMWORD PTR [r12+0x2d0],xmm4
    7f716ee01ac9:	mov    r15,r13
    7f716ee01acc:	add    r15,0x120
    7f716ee01ad3:	mov    rbp,r15
    7f716ee01ad6:	add    rbp,0x10
    7f716ee01ada:	movdqu xmm3,XMMWORD PTR [r15]
    7f716ee01adf:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    7f716ee01ae4:	movdqu XMMWORD PTR [r12+0x2e0],xmm3
    7f716ee01aee:	movdqu XMMWORD PTR [r12+0x2f0],xmm4
    7f716ee01af8:	mov    r15,r14
    7f716ee01afb:	add    r15,0xa0
    7f716ee01b02:	mov    rbp,r15
    7f716ee01b05:	add    rbp,0x10
    7f716ee01b09:	movdqu XMMWORD PTR [r15],xmm5
    7f716ee01b0e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7f716ee01b13:	mov    r15,r13
    7f716ee01b16:	add    r15,0xa0
    7f716ee01b1d:	mov    rbp,r15
    7f716ee01b20:	add    rbp,0x10
    7f716ee01b24:	movdqu xmm2,XMMWORD PTR [r15]
    7f716ee01b29:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7f716ee01b2e:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7f716ee01b38:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7f716ee01b42:	mov    r15,r13
    7f716ee01b45:	add    r15,0x160
    7f716ee01b4c:	mov    rbp,r15
    7f716ee01b4f:	add    rbp,0x10
    7f716ee01b53:	movdqu xmm4,XMMWORD PTR [r15]
    7f716ee01b58:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    7f716ee01b5d:	movdqu XMMWORD PTR [r12+0x2c0],xmm4
    7f716ee01b67:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
    7f716ee01b71:	mov    r15,r13
    7f716ee01b74:	add    r15,0x1a0
    7f716ee01b7b:	mov    rbp,r15
    7f716ee01b7e:	add    rbp,0x10
    7f716ee01b82:	movdqu xmm5,XMMWORD PTR [r15]
    7f716ee01b87:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    7f716ee01b8c:	movdqu XMMWORD PTR [r12+0x290],xmm5
    7f716ee01b96:	movdqu XMMWORD PTR [r12+0x1e0],xmm7
    7f716ee01ba0:	mov    r15,r14
    7f716ee01ba3:	add    r15,0x80
    7f716ee01baa:	mov    rbp,r15
    7f716ee01bad:	add    rbp,0x10
    7f716ee01bb1:	movdqu XMMWORD PTR [r15],xmm3
    7f716ee01bb6:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7f716ee01bbb:	add    r13,0x1e0
    7f716ee01bc2:	mov    r15,r13
    7f716ee01bc5:	add    r15,0x10
    7f716ee01bc9:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7f716ee01bcf:	movdqu xmm3,XMMWORD PTR [r15]
    7f716ee01bd4:	movdqu XMMWORD PTR [r12+0x230],xmm2
    7f716ee01bde:	movdqu XMMWORD PTR [r12+0x280],xmm3
    7f716ee01be8:	mov    r13d,0x432000
    7f716ee01bee:	add    r13,0x200
    7f716ee01bf5:	mov    QWORD PTR [r12+0x50],r13
    7f716ee01bfa:	mov    r13,r14
    7f716ee01bfd:	add    r13,0x40
    7f716ee01c01:	mov    r15,r13
    7f716ee01c04:	add    r15,0x10
    7f716ee01c08:	movdqu XMMWORD PTR [r13+0x0],xmm4
    7f716ee01c0e:	movdqu XMMWORD PTR [r15],xmm6
    7f716ee01c13:	mov    r13,r14
    7f716ee01c16:	add    r13,0x10
    7f716ee01c1a:	movdqu XMMWORD PTR [r14],xmm3
    7f716ee01c1f:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7f716ee01c25:	mov    r11,rax
    7f716ee01c28:	movzx  eax,WORD PTR [rsp]
    7f716ee01c2c:	add    al,0x7f
    7f716ee01c2e:	sahf
    7f716ee01c2f:	mov    rax,r11
    7f716ee01c32:	jmp    0x7f716ee01c37
    7f716ee01c37:	mov    r13d,0x0
    7f716ee01c3d:	mov    QWORD PTR [r12+0x58],r13
    7f716ee01c42:	mov    r11,rax
    7f716ee01c45:	lahf
    7f716ee01c46:	seto   al
    7f716ee01c49:	mov    WORD PTR [rsp],ax
    7f716ee01c4d:	mov    rax,r11
    7f716ee01c50:	jmp    0x7f716ee01c55
    7f716ee01c55:	mov    r13,QWORD PTR [r12+0x58]
    7f716ee01c5a:	mov    r14,QWORD PTR [r12+0x40]
    7f716ee01c5f:	add    r14,r13
    7f716ee01c62:	mov    QWORD PTR [r12+0x60],r14
    7f716ee01c67:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    7f716ee01c71:	movdqa xmm0,xmm2
    7f716ee01c75:	movdqa xmm1,xmm2
    7f716ee01c79:	por    xmm0,xmm1
    7f716ee01c7d:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    7f716ee01c87:	movdqu xmm4,XMMWORD PTR [r12+0x1a0]
    7f716ee01c91:	movdqa xmm0,xmm4
    7f716ee01c95:	movdqa xmm1,xmm4
    7f716ee01c99:	por    xmm0,xmm1
    7f716ee01c9d:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7f716ee01ca7:	mov    r15,r14
    7f716ee01caa:	add    r15,0x30
    7f716ee01cae:	mov    rbp,r15
    7f716ee01cb1:	add    rbp,0x8
    7f716ee01cb5:	mov    r8,QWORD PTR [r15]
    7f716ee01cb8:	mov    r15,QWORD PTR [rbp+0x0]
    7f716ee01cbc:	mov    ebp,0x0
    7f716ee01cc1:	mov    QWORD PTR [r12+0x130],r8
    7f716ee01cc9:	mov    QWORD PTR [r12+0x138],rbp
    7f716ee01cd1:	mov    ebp,0x0
    7f716ee01cd6:	mov    QWORD PTR [r12+0x280],r15
    7f716ee01cde:	mov    QWORD PTR [r12+0x288],rbp
    7f716ee01ce6:	movdqu xmm5,XMMWORD PTR [r12+0x270]
    7f716ee01cf0:	movdqa xmm0,xmm5
    7f716ee01cf4:	movdqa xmm1,xmm5
    7f716ee01cf8:	por    xmm0,xmm1
    7f716ee01cfc:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    7f716ee01d06:	mov    r15,r14
    7f716ee01d09:	add    r15,0x20
    7f716ee01d0d:	mov    rbp,r15
    7f716ee01d10:	add    rbp,0x8
    7f716ee01d14:	mov    r8,QWORD PTR [r15]
    7f716ee01d17:	mov    r15,QWORD PTR [rbp+0x0]
    7f716ee01d1b:	mov    ebp,0x0
    7f716ee01d20:	mov    QWORD PTR [r12+0x150],r8
    7f716ee01d28:	mov    QWORD PTR [r12+0x158],rbp
    7f716ee01d30:	mov    ebp,0x0
    7f716ee01d35:	mov    QWORD PTR [r12+0x140],r15
    7f716ee01d3d:	mov    QWORD PTR [r12+0x148],rbp
    7f716ee01d45:	mov    r15,r14
    7f716ee01d48:	add    r15,0x10
    7f716ee01d4c:	mov    rbp,r15
    7f716ee01d4f:	add    rbp,0x8
    7f716ee01d53:	mov    r8,QWORD PTR [r15]
    7f716ee01d56:	mov    r15,QWORD PTR [rbp+0x0]
    7f716ee01d5a:	mov    ebp,0x0
    7f716ee01d5f:	mov    QWORD PTR [r12+0x170],r8
    7f716ee01d67:	mov    QWORD PTR [r12+0x178],rbp
    7f716ee01d6f:	mov    ebp,0x0
    7f716ee01d74:	mov    QWORD PTR [r12+0x160],r15
    7f716ee01d7c:	mov    QWORD PTR [r12+0x168],rbp
    7f716ee01d84:	mov    r15d,0x8
    7f716ee01d8a:	mov    rbp,QWORD PTR [r14]
    7f716ee01d8d:	mov    QWORD PTR [r12+0x180],rbp
    7f716ee01d95:	mov    QWORD PTR [r12+0x188],rbp
    7f716ee01d9d:	add    r14,r15
    7f716ee01da0:	mov    QWORD PTR [r12+0x60],r14
    7f716ee01da5:	mov    r15,QWORD PTR [r14]
    7f716ee01da8:	mov    r14d,0x0
    7f716ee01dae:	mov    QWORD PTR [r12+0x230],r15
    7f716ee01db6:	mov    QWORD PTR [r12+0x238],r14
    7f716ee01dbe:	mov    r14,QWORD PTR [r12+0xf8]
    7f716ee01dc6:	mov    r15,r14
    7f716ee01dc9:	add    r15,0x50
    7f716ee01dcd:	mov    rbp,r15
    7f716ee01dd0:	add    rbp,0x10
    7f716ee01dd4:	movdqu xmm6,XMMWORD PTR [r15]
    7f716ee01dd9:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    7f716ee01dde:	movdqu XMMWORD PTR [r12+0x220],xmm6
    7f716ee01de8:	movdqu XMMWORD PTR [r12+0x210],xmm7
    7f716ee01df2:	mov    r15,r14
    7f716ee01df5:	add    r15,0x30
    7f716ee01df9:	movdqu xmm8,XMMWORD PTR [r15]
    7f716ee01dfe:	movdqu XMMWORD PTR [r12+0x110],xmm8
    7f716ee01e08:	mov    r15,QWORD PTR [r12+0x50]
    7f716ee01e0d:	add    r15,r13
    7f716ee01e10:	mov    QWORD PTR [r12+0x60],r15
    7f716ee01e15:	add    r13,0x40
    7f716ee01e19:	mov    QWORD PTR [r12+0x58],r13
    7f716ee01e1e:	movdqu xmm9,XMMWORD PTR [r12+0x180]
    7f716ee01e28:	movdqa xmm0,xmm9
    7f716ee01e2d:	movdqa xmm1,xmm2
    7f716ee01e31:	mulpd  xmm0,xmm1
    7f716ee01e35:	movdqa xmm14,xmm0
    7f716ee01e3a:	movdqu xmm15,XMMWORD PTR [rip+0x980d]        # 0x7f716ee0b650
    7f716ee01e43:	pand   xmm14,xmm15
    7f716ee01e48:	movdqu xmm15,XMMWORD PTR [rip+0x980f]        # 0x7f716ee0b660
    7f716ee01e51:	pcmpeqq xmm14,xmm15
    7f716ee01e57:	movdqa xmm15,xmm0
    7f716ee01e5c:	cmpunordpd xmm15,xmm0
    7f716ee01e62:	por    xmm14,xmm15
    7f716ee01e67:	pmovmskb ecx,xmm14
    7f716ee01e6c:	jrcxz  0x7f716ee01e73
    7f716ee01e6e:	jmp    0x7f716ee03e05
    7f716ee01e73:	movdqa xmm10,xmm0
    7f716ee01e78:	movdqu xmm2,XMMWORD PTR [r12+0x230]
    7f716ee01e82:	movdqa xmm0,xmm8
    7f716ee01e87:	movdqa xmm1,xmm2
    7f716ee01e8b:	pshufd xmm1,xmm1,0x44
    7f716ee01e90:	mulpd  xmm0,xmm1
    7f716ee01e94:	movdqa xmm14,xmm0
    7f716ee01e99:	movdqu xmm15,XMMWORD PTR [rip+0x97ae]        # 0x7f716ee0b650
    7f716ee01ea2:	pand   xmm14,xmm15
    7f716ee01ea7:	movdqu xmm15,XMMWORD PTR [rip+0x97b0]        # 0x7f716ee0b660
    7f716ee01eb0:	pcmpeqq xmm14,xmm15
    7f716ee01eb6:	movdqa xmm15,xmm0
    7f716ee01ebb:	cmpunordpd xmm15,xmm0
    7f716ee01ec1:	por    xmm14,xmm15
    7f716ee01ec6:	pmovmskb ecx,xmm14
    7f716ee01ecb:	jrcxz  0x7f716ee01ed2
    7f716ee01ecd:	jmp    0x7f716ee03e2a
    7f716ee01ed2:	movdqa xmm11,xmm0
    7f716ee01ed7:	movdqu XMMWORD PTR [r12+0x260],xmm11
    7f716ee01ee1:	mov    ebp,0x0
    7f716ee01ee6:	mov    r8d,0x0
    7f716ee01eec:	mov    QWORD PTR [r12+0x110],rbp
    7f716ee01ef4:	mov    QWORD PTR [r12+0x118],r8
    7f716ee01efc:	movdqa xmm0,xmm9
    7f716ee01f01:	movdqa xmm1,xmm7
    7f716ee01f05:	mulpd  xmm0,xmm1
    7f716ee01f09:	movdqa xmm14,xmm0
    7f716ee01f0e:	movdqu xmm15,XMMWORD PTR [rip+0x9739]        # 0x7f716ee0b650
    7f716ee01f17:	pand   xmm14,xmm15
    7f716ee01f1c:	movdqu xmm15,XMMWORD PTR [rip+0x973b]        # 0x7f716ee0b660
    7f716ee01f25:	pcmpeqq xmm14,xmm15
    7f716ee01f2b:	movdqa xmm15,xmm0
    7f716ee01f30:	cmpunordpd xmm15,xmm0
    7f716ee01f36:	por    xmm14,xmm15
    7f716ee01f3b:	pmovmskb ecx,xmm14
    7f716ee01f40:	jrcxz  0x7f716ee01f47
    7f716ee01f42:	jmp    0x7f716ee03e4f
    7f716ee01f47:	movdqa xmm8,xmm0
    7f716ee01f4c:	movdqa xmm0,xmm9
    7f716ee01f51:	movdqa xmm1,xmm6
    7f716ee01f55:	mulpd  xmm0,xmm1
    7f716ee01f59:	movdqa xmm14,xmm0
    7f716ee01f5e:	movdqu xmm15,XMMWORD PTR [rip+0x96e9]        # 0x7f716ee0b650
    7f716ee01f67:	pand   xmm14,xmm15
    7f716ee01f6c:	movdqu xmm15,XMMWORD PTR [rip+0x96eb]        # 0x7f716ee0b660
    7f716ee01f75:	pcmpeqq xmm14,xmm15
    7f716ee01f7b:	movdqa xmm15,xmm0
    7f716ee01f80:	cmpunordpd xmm15,xmm0
    7f716ee01f86:	por    xmm14,xmm15
    7f716ee01f8b:	pmovmskb ecx,xmm14
    7f716ee01f90:	jrcxz  0x7f716ee01f97
    7f716ee01f92:	jmp    0x7f716ee03e74
    7f716ee01f97:	movdqa xmm7,xmm0
    7f716ee01f9b:	movdqu xmm6,XMMWORD PTR [r12+0x1f0]
    7f716ee01fa5:	movdqa xmm0,xmm9
    7f716ee01faa:	movdqa xmm1,xmm6
    7f716ee01fae:	mulpd  xmm0,xmm1
    7f716ee01fb2:	movdqa xmm14,xmm0
    7f716ee01fb7:	movdqu xmm15,XMMWORD PTR [rip+0x9690]        # 0x7f716ee0b650
    7f716ee01fc0:	pand   xmm14,xmm15
    7f716ee01fc5:	movdqu xmm15,XMMWORD PTR [rip+0x9692]        # 0x7f716ee0b660
    7f716ee01fce:	pcmpeqq xmm14,xmm15
    7f716ee01fd4:	movdqa xmm15,xmm0
    7f716ee01fd9:	cmpunordpd xmm15,xmm0
    7f716ee01fdf:	por    xmm14,xmm15
    7f716ee01fe4:	pmovmskb ecx,xmm14
    7f716ee01fe9:	jrcxz  0x7f716ee01ff0
    7f716ee01feb:	jmp    0x7f716ee03e99
    7f716ee01ff0:	movdqa xmm12,xmm0
    7f716ee01ff5:	movdqu XMMWORD PTR [r12+0x180],xmm12
    7f716ee01fff:	movdqu xmm6,XMMWORD PTR [r12+0x2a0]
    7f716ee02009:	movdqa xmm0,xmm6
    7f716ee0200d:	movdqa xmm1,xmm6
    7f716ee02011:	por    xmm0,xmm1
    7f716ee02015:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    7f716ee0201f:	movdqu xmm9,XMMWORD PTR [r12+0x250]
    7f716ee02029:	movdqa xmm0,xmm9
    7f716ee0202e:	movdqa xmm1,xmm9
    7f716ee02033:	por    xmm0,xmm1
    7f716ee02037:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    7f716ee02041:	movdqa xmm0,xmm9
    7f716ee02046:	movdqa xmm1,xmm2
    7f716ee0204a:	pshufd xmm1,xmm1,0x44
    7f716ee0204f:	mulpd  xmm0,xmm1
    7f716ee02053:	movdqa xmm14,xmm0
    7f716ee02058:	movdqu xmm15,XMMWORD PTR [rip+0x95ef]        # 0x7f716ee0b650
    7f716ee02061:	pand   xmm14,xmm15
    7f716ee02066:	movdqu xmm15,XMMWORD PTR [rip+0x95f1]        # 0x7f716ee0b660
    7f716ee0206f:	pcmpeqq xmm14,xmm15
    7f716ee02075:	movdqa xmm15,xmm0
    7f716ee0207a:	cmpunordpd xmm15,xmm0
    7f716ee02080:	por    xmm14,xmm15
    7f716ee02085:	pmovmskb ecx,xmm14
    7f716ee0208a:	jrcxz  0x7f716ee02091
    7f716ee0208c:	jmp    0x7f716ee03ebe
    7f716ee02091:	movdqa xmm4,xmm0
    7f716ee02095:	movdqu XMMWORD PTR [r12+0x250],xmm4
    7f716ee0209f:	sub    r13,0x200
    7f716ee020a6:	movdqu xmm9,XMMWORD PTR [r12+0x110]
    7f716ee020b0:	movdqa xmm0,xmm10
    7f716ee020b5:	movdqa xmm1,xmm9
    7f716ee020ba:	addpd  xmm0,xmm1
    7f716ee020be:	movdqa xmm14,xmm0
    7f716ee020c3:	movdqu xmm15,XMMWORD PTR [rip+0x9584]        # 0x7f716ee0b650
    7f716ee020cc:	pand   xmm14,xmm15
    7f716ee020d1:	movdqu xmm15,XMMWORD PTR [rip+0x9586]        # 0x7f716ee0b660
    7f716ee020da:	pcmpeqq xmm14,xmm15
    7f716ee020e0:	movdqa xmm15,xmm0
    7f716ee020e5:	cmpunordpd xmm15,xmm0
    7f716ee020eb:	por    xmm14,xmm15
    7f716ee020f0:	pmovmskb ecx,xmm14
    7f716ee020f5:	jrcxz  0x7f716ee020fc
    7f716ee020f7:	jmp    0x7f716ee03ee3
    7f716ee020fc:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7f716ee02106:	movdqu xmm10,XMMWORD PTR [r12+0x1b0]
    7f716ee02110:	movdqa xmm0,xmm8
    7f716ee02115:	movdqa xmm1,xmm10
    7f716ee0211a:	addpd  xmm0,xmm1
    7f716ee0211e:	movdqa xmm14,xmm0
    7f716ee02123:	movdqu xmm15,XMMWORD PTR [rip+0x9524]        # 0x7f716ee0b650
    7f716ee0212c:	pand   xmm14,xmm15
    7f716ee02131:	movdqu xmm15,XMMWORD PTR [rip+0x9526]        # 0x7f716ee0b660
    7f716ee0213a:	pcmpeqq xmm14,xmm15
    7f716ee02140:	movdqa xmm15,xmm0
    7f716ee02145:	cmpunordpd xmm15,xmm0
    7f716ee0214b:	por    xmm14,xmm15
    7f716ee02150:	pmovmskb ecx,xmm14
    7f716ee02155:	jrcxz  0x7f716ee0215c
    7f716ee02157:	jmp    0x7f716ee03f24
    7f716ee0215c:	movdqa xmm6,xmm0
    7f716ee02160:	movdqu XMMWORD PTR [r12+0x210],xmm6
    7f716ee0216a:	movdqa xmm0,xmm7
    7f716ee0216e:	movdqa xmm1,xmm10
    7f716ee02173:	addpd  xmm0,xmm1
    7f716ee02177:	movdqa xmm14,xmm0
    7f716ee0217c:	movdqu xmm15,XMMWORD PTR [rip+0x94cb]        # 0x7f716ee0b650
    7f716ee02185:	pand   xmm14,xmm15
    7f716ee0218a:	movdqu xmm15,XMMWORD PTR [rip+0x94cd]        # 0x7f716ee0b660
    7f716ee02193:	pcmpeqq xmm14,xmm15
    7f716ee02199:	movdqa xmm15,xmm0
    7f716ee0219e:	cmpunordpd xmm15,xmm0
    7f716ee021a4:	por    xmm14,xmm15
    7f716ee021a9:	pmovmskb ecx,xmm14
    7f716ee021ae:	jrcxz  0x7f716ee021b5
    7f716ee021b0:	jmp    0x7f716ee03f65
    7f716ee021b5:	movdqa xmm8,xmm0
    7f716ee021ba:	movdqu XMMWORD PTR [r12+0x220],xmm8
    7f716ee021c4:	movdqu xmm7,XMMWORD PTR [r12+0x2f0]
    7f716ee021ce:	setne  BYTE PTR [rsp+0x8]
    7f716ee021d3:	mov    r11,rax
    7f716ee021d6:	lahf
    7f716ee021d7:	seto   al
    7f716ee021da:	mov    WORD PTR [rsp],ax
    7f716ee021de:	mov    rax,r11
    7f716ee021e1:	movdqa xmm0,xmm7
    7f716ee021e5:	movdqa xmm1,xmm7
    7f716ee021e9:	por    xmm0,xmm1
    7f716ee021ed:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    7f716ee021f7:	movdqu xmm10,XMMWORD PTR [r12+0x2e0]
    7f716ee02201:	movdqa xmm0,xmm10
    7f716ee02206:	movdqa xmm1,xmm10
    7f716ee0220b:	por    xmm0,xmm1
    7f716ee0220f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    7f716ee02219:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    7f716ee02223:	movdqa xmm0,xmm13
    7f716ee02228:	movdqa xmm1,xmm13
    7f716ee0222d:	por    xmm0,xmm1
    7f716ee02231:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    7f716ee0223b:	movdqu xmm5,XMMWORD PTR [r12+0x200]
    7f716ee02245:	movdqa xmm0,xmm5
    7f716ee02249:	movdqa xmm1,xmm5
    7f716ee0224d:	por    xmm0,xmm1
    7f716ee02251:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    7f716ee0225b:	movdqu xmm7,XMMWORD PTR [r12+0x1c0]
    7f716ee02265:	movdqa xmm1,xmm7
    7f716ee02269:	por    xmm7,xmm1
    7f716ee0226d:	movdqu XMMWORD PTR [r12+0x200],xmm7
    7f716ee02277:	movdqu xmm3,XMMWORD PTR [r12+0x190]
    7f716ee02281:	movdqa xmm1,xmm3
    7f716ee02285:	por    xmm3,xmm1
    7f716ee02289:	movdqu XMMWORD PTR [r12+0x1c0],xmm3
    7f716ee02293:	movdqu xmm10,XMMWORD PTR [r12+0x300]
    7f716ee0229d:	movdqa xmm1,xmm10
    7f716ee022a2:	por    xmm10,xmm1
    7f716ee022a7:	movdqu XMMWORD PTR [r12+0x190],xmm10
    7f716ee022b1:	mov    r13,r14
    7f716ee022b4:	add    r13,0xa0
    7f716ee022bb:	mov    rbp,r13
    7f716ee022be:	add    rbp,0x10
    7f716ee022c2:	movdqu xmm13,XMMWORD PTR [r13+0x0]
    7f716ee022c8:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    7f716ee022cd:	movdqu XMMWORD PTR [r12+0x300],xmm13
    7f716ee022d7:	movdqu XMMWORD PTR [r12+0x270],xmm5
    7f716ee022e1:	movdqa xmm0,xmm12
    7f716ee022e6:	movdqa xmm1,xmm9
    7f716ee022eb:	addpd  xmm0,xmm1
    7f716ee022ef:	movdqa xmm14,xmm0
    7f716ee022f4:	movdqu xmm15,XMMWORD PTR [rip+0x9353]        # 0x7f716ee0b650
    7f716ee022fd:	pand   xmm14,xmm15
    7f716ee02302:	movdqu xmm15,XMMWORD PTR [rip+0x9355]        # 0x7f716ee0b660
    7f716ee0230b:	pcmpeqq xmm14,xmm15
    7f716ee02311:	movdqa xmm15,xmm0
    7f716ee02316:	cmpunordpd xmm15,xmm0
    7f716ee0231c:	por    xmm14,xmm15
    7f716ee02321:	pmovmskb ecx,xmm14
    7f716ee02326:	jrcxz  0x7f716ee0232d
    7f716ee02328:	jmp    0x7f716ee03fa5
    7f716ee0232d:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7f716ee02337:	mov    r13,r14
    7f716ee0233a:	add    r13,0xf0
    7f716ee02341:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    7f716ee02347:	movdqu XMMWORD PTR [r12+0x110],xmm9
    7f716ee02351:	movdqa xmm0,xmm6
    7f716ee02355:	movdqa xmm1,xmm4
    7f716ee02359:	addpd  xmm0,xmm1
    7f716ee0235d:	movdqa xmm14,xmm0
    7f716ee02362:	movdqu xmm15,XMMWORD PTR [rip+0x92e5]        # 0x7f716ee0b650
    7f716ee0236b:	pand   xmm14,xmm15
    7f716ee02370:	movdqu xmm15,XMMWORD PTR [rip+0x92e7]        # 0x7f716ee0b660
    7f716ee02379:	pcmpeqq xmm14,xmm15
    7f716ee0237f:	movdqa xmm15,xmm0
    7f716ee02384:	cmpunordpd xmm15,xmm0
    7f716ee0238a:	por    xmm14,xmm15
    7f716ee0238f:	pmovmskb ecx,xmm14
    7f716ee02394:	jrcxz  0x7f716ee0239b
    7f716ee02396:	jmp    0x7f716ee03fcb
    7f716ee0239b:	movdqa xmm12,xmm0
    7f716ee023a0:	movdqu XMMWORD PTR [r12+0x210],xmm12
    7f716ee023aa:	movdqa xmm0,xmm8
    7f716ee023af:	movdqa xmm1,xmm11
    7f716ee023b4:	addpd  xmm0,xmm1
    7f716ee023b8:	movdqa xmm14,xmm0
    7f716ee023bd:	movdqu xmm15,XMMWORD PTR [rip+0x928a]        # 0x7f716ee0b650
    7f716ee023c6:	pand   xmm14,xmm15
    7f716ee023cb:	movdqu xmm15,XMMWORD PTR [rip+0x928c]        # 0x7f716ee0b660
    7f716ee023d4:	pcmpeqq xmm14,xmm15
    7f716ee023da:	movdqa xmm15,xmm0
    7f716ee023df:	cmpunordpd xmm15,xmm0
    7f716ee023e5:	por    xmm14,xmm15
    7f716ee023ea:	pmovmskb ecx,xmm14
    7f716ee023ef:	jrcxz  0x7f716ee023f6
    7f716ee023f1:	jmp    0x7f716ee03fef
    7f716ee023f6:	movdqa xmm4,xmm0
    7f716ee023fa:	movdqu XMMWORD PTR [r12+0x220],xmm4
    7f716ee02404:	movdqa xmm0,xmm5
    7f716ee02408:	movdqa xmm1,xmm2
    7f716ee0240c:	pshufd xmm1,xmm1,0x44
    7f716ee02411:	mulpd  xmm0,xmm1
    7f716ee02415:	movdqa xmm14,xmm0
    7f716ee0241a:	movdqu xmm15,XMMWORD PTR [rip+0x922d]        # 0x7f716ee0b650
    7f716ee02423:	pand   xmm14,xmm15
    7f716ee02428:	movdqu xmm15,XMMWORD PTR [rip+0x922f]        # 0x7f716ee0b660
    7f716ee02431:	pcmpeqq xmm14,xmm15
    7f716ee02437:	movdqa xmm15,xmm0
    7f716ee0243c:	cmpunordpd xmm15,xmm0
    7f716ee02442:	por    xmm14,xmm15
    7f716ee02447:	pmovmskb ecx,xmm14
    7f716ee0244c:	jrcxz  0x7f716ee02453
    7f716ee0244e:	jmp    0x7f716ee04015
    7f716ee02453:	movdqa xmm6,xmm0
    7f716ee02457:	movdqu XMMWORD PTR [r12+0x270],xmm6
    7f716ee02461:	movdqu xmm5,XMMWORD PTR [r12+0x170]
    7f716ee0246b:	movdqa xmm0,xmm9
    7f716ee02470:	movdqa xmm1,xmm5
    7f716ee02474:	pshufd xmm1,xmm1,0x44
    7f716ee02479:	mulpd  xmm0,xmm1
    7f716ee0247d:	movdqa xmm14,xmm0
    7f716ee02482:	movdqu xmm15,XMMWORD PTR [rip+0x91c5]        # 0x7f716ee0b650
    7f716ee0248b:	pand   xmm14,xmm15
    7f716ee02490:	movdqu xmm15,XMMWORD PTR [rip+0x91c7]        # 0x7f716ee0b660
    7f716ee02499:	pcmpeqq xmm14,xmm15
    7f716ee0249f:	movdqa xmm15,xmm0
    7f716ee024a4:	cmpunordpd xmm15,xmm0
    7f716ee024aa:	por    xmm14,xmm15
    7f716ee024af:	pmovmskb ecx,xmm14
    7f716ee024b4:	jrcxz  0x7f716ee024bb
    7f716ee024b6:	jmp    0x7f716ee04039
    7f716ee024bb:	movdqa xmm8,xmm0
    7f716ee024c0:	movdqu XMMWORD PTR [r12+0x250],xmm8
    7f716ee024ca:	mov    r13,r14
    7f716ee024cd:	add    r13,0xe0
    7f716ee024d4:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    7f716ee024da:	movdqu XMMWORD PTR [r12+0x110],xmm9
    7f716ee024e4:	movdqa xmm0,xmm13
    7f716ee024e9:	movdqa xmm1,xmm2
    7f716ee024ed:	pshufd xmm1,xmm1,0x44
    7f716ee024f2:	mulpd  xmm0,xmm1
    7f716ee024f6:	movdqa xmm14,xmm0
    7f716ee024fb:	movdqu xmm15,XMMWORD PTR [rip+0x914c]        # 0x7f716ee0b650
    7f716ee02504:	pand   xmm14,xmm15
    7f716ee02509:	movdqu xmm15,XMMWORD PTR [rip+0x914e]        # 0x7f716ee0b660
    7f716ee02512:	pcmpeqq xmm14,xmm15
    7f716ee02518:	movdqa xmm15,xmm0
    7f716ee0251d:	cmpunordpd xmm15,xmm0
    7f716ee02523:	por    xmm14,xmm15
    7f716ee02528:	pmovmskb ecx,xmm14
    7f716ee0252d:	jrcxz  0x7f716ee02534
    7f716ee0252f:	jmp    0x7f716ee0405e
    7f716ee02534:	movdqa xmm11,xmm0
    7f716ee02539:	movdqu XMMWORD PTR [r12+0x230],xmm11
    7f716ee02543:	movdqa xmm0,xmm10
    7f716ee02548:	movdqa xmm1,xmm10
    7f716ee0254d:	por    xmm0,xmm1
    7f716ee02551:	movdqu XMMWORD PTR [r12+0x300],xmm0
    7f716ee0255b:	movdqa xmm0,xmm3
    7f716ee0255f:	movdqa xmm1,xmm3
    7f716ee02563:	por    xmm0,xmm1
    7f716ee02567:	movdqu XMMWORD PTR [r12+0x190],xmm0
    7f716ee02571:	movdqa xmm0,xmm9
    7f716ee02576:	movdqa xmm1,xmm5
    7f716ee0257a:	pshufd xmm1,xmm1,0x44
    7f716ee0257f:	mulpd  xmm0,xmm1
    7f716ee02583:	movdqa xmm14,xmm0
    7f716ee02588:	movdqu xmm15,XMMWORD PTR [rip+0x90bf]        # 0x7f716ee0b650
    7f716ee02591:	pand   xmm14,xmm15
    7f716ee02596:	movdqu xmm15,XMMWORD PTR [rip+0x90c1]        # 0x7f716ee0b660
    7f716ee0259f:	pcmpeqq xmm14,xmm15
    7f716ee025a5:	movdqa xmm15,xmm0
    7f716ee025aa:	cmpunordpd xmm15,xmm0
    7f716ee025b0:	por    xmm14,xmm15
    7f716ee025b5:	pmovmskb ecx,xmm14
    7f716ee025ba:	jrcxz  0x7f716ee025c1
    7f716ee025bc:	jmp    0x7f716ee04083
    7f716ee025c1:	movdqa xmm2,xmm0
    7f716ee025c5:	movdqu XMMWORD PTR [r12+0x260],xmm2
    7f716ee025cf:	mov    r13,r14
    7f716ee025d2:	add    r13,0x90
    7f716ee025d9:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    7f716ee025df:	movdqu XMMWORD PTR [r12+0x110],xmm9
    7f716ee025e9:	movdqa xmm0,xmm7
    7f716ee025ed:	movdqa xmm1,xmm7
    7f716ee025f1:	por    xmm0,xmm1
    7f716ee025f5:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    7f716ee025ff:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    7f716ee02609:	movdqu xmm1,XMMWORD PTR [r12+0x2d0]
    7f716ee02613:	por    xmm13,xmm1
    7f716ee02618:	movdqu XMMWORD PTR [r12+0x200],xmm13
    7f716ee02622:	movdqu xmm7,XMMWORD PTR [r12+0x2e0]
    7f716ee0262c:	movdqu xmm1,XMMWORD PTR [r12+0x2e0]
    7f716ee02636:	por    xmm7,xmm1
    7f716ee0263a:	movdqu XMMWORD PTR [r12+0x2d0],xmm7
    7f716ee02644:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7f716ee0264e:	movdqu xmm1,XMMWORD PTR [r12+0x2f0]
    7f716ee02658:	por    xmm0,xmm1
    7f716ee0265c:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    7f716ee02666:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7f716ee02670:	movdqa xmm1,xmm6
    7f716ee02674:	addpd  xmm0,xmm1
    7f716ee02678:	movdqa xmm14,xmm0
    7f716ee0267d:	movdqu xmm15,XMMWORD PTR [rip+0x8fca]        # 0x7f716ee0b650
    7f716ee02686:	pand   xmm14,xmm15
    7f716ee0268b:	movdqu xmm15,XMMWORD PTR [rip+0x8fcc]        # 0x7f716ee0b660
    7f716ee02694:	pcmpeqq xmm14,xmm15
    7f716ee0269a:	movdqa xmm15,xmm0
    7f716ee0269f:	cmpunordpd xmm15,xmm0
    7f716ee026a5:	por    xmm14,xmm15
    7f716ee026aa:	pmovmskb ecx,xmm14
    7f716ee026af:	jrcxz  0x7f716ee026b6
    7f716ee026b1:	jmp    0x7f716ee040a8
    7f716ee026b6:	movdqa xmm3,xmm0
    7f716ee026ba:	movdqu XMMWORD PTR [r12+0x240],xmm3
    7f716ee026c4:	movdqa xmm0,xmm9
    7f716ee026c9:	movdqa xmm1,xmm5
    7f716ee026cd:	pshufd xmm1,xmm1,0x44
    7f716ee026d2:	mulpd  xmm0,xmm1
    7f716ee026d6:	movdqa xmm14,xmm0
    7f716ee026db:	movdqu xmm15,XMMWORD PTR [rip+0x8f6c]        # 0x7f716ee0b650
    7f716ee026e4:	pand   xmm14,xmm15
    7f716ee026e9:	movdqu xmm15,XMMWORD PTR [rip+0x8f6e]        # 0x7f716ee0b660
    7f716ee026f2:	pcmpeqq xmm14,xmm15
    7f716ee026f8:	movdqa xmm15,xmm0
    7f716ee026fd:	cmpunordpd xmm15,xmm0
    7f716ee02703:	por    xmm14,xmm15
    7f716ee02708:	pmovmskb ecx,xmm14
    7f716ee0270d:	jrcxz  0x7f716ee02714
    7f716ee0270f:	jmp    0x7f716ee040d2
    7f716ee02714:	movdqa xmm6,xmm0
    7f716ee02718:	movdqu XMMWORD PTR [r12+0x270],xmm6
    7f716ee02722:	mov    r13,r14
    7f716ee02725:	add    r13,0x80
    7f716ee0272c:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    7f716ee02732:	movdqu XMMWORD PTR [r12+0x110],xmm9
    7f716ee0273c:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7f716ee02746:	movdqa xmm1,xmm11
    7f716ee0274b:	addpd  xmm0,xmm1
    7f716ee0274f:	movdqa xmm14,xmm0
    7f716ee02754:	movdqu xmm15,XMMWORD PTR [rip+0x8ef3]        # 0x7f716ee0b650
    7f716ee0275d:	pand   xmm14,xmm15
    7f716ee02762:	movdqu xmm15,XMMWORD PTR [rip+0x8ef5]        # 0x7f716ee0b660
    7f716ee0276b:	pcmpeqq xmm14,xmm15
    7f716ee02771:	movdqa xmm15,xmm0
    7f716ee02776:	cmpunordpd xmm15,xmm0
    7f716ee0277c:	por    xmm14,xmm15
    7f716ee02781:	pmovmskb ecx,xmm14
    7f716ee02786:	jrcxz  0x7f716ee0278d
    7f716ee02788:	jmp    0x7f716ee040f7
    7f716ee0278d:	movdqa xmm10,xmm0
    7f716ee02792:	movdqu XMMWORD PTR [r12+0x180],xmm10
    7f716ee0279c:	movdqa xmm0,xmm12
    7f716ee027a1:	movdqa xmm1,xmm8
    7f716ee027a6:	addpd  xmm0,xmm1
    7f716ee027aa:	movdqa xmm14,xmm0
    7f716ee027af:	movdqu xmm15,XMMWORD PTR [rip+0x8e98]        # 0x7f716ee0b650
    7f716ee027b8:	pand   xmm14,xmm15
    7f716ee027bd:	movdqu xmm15,XMMWORD PTR [rip+0x8e9a]        # 0x7f716ee0b660
    7f716ee027c6:	pcmpeqq xmm14,xmm15
    7f716ee027cc:	movdqa xmm15,xmm0
    7f716ee027d1:	cmpunordpd xmm15,xmm0
    7f716ee027d7:	por    xmm14,xmm15
    7f716ee027dc:	pmovmskb ecx,xmm14
    7f716ee027e1:	jrcxz  0x7f716ee027e8
    7f716ee027e3:	jmp    0x7f716ee04122
    7f716ee027e8:	movdqa xmm11,xmm0
    7f716ee027ed:	movdqu XMMWORD PTR [r12+0x210],xmm11
    7f716ee027f7:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    7f716ee02801:	movdqu xmm1,XMMWORD PTR [r12+0x1b0]
    7f716ee0280b:	por    xmm0,xmm1
    7f716ee0280f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    7f716ee02819:	movdqa xmm0,xmm9
    7f716ee0281e:	movdqa xmm1,xmm5
    7f716ee02822:	pshufd xmm1,xmm1,0x44
    7f716ee02827:	mulpd  xmm0,xmm1
    7f716ee0282b:	movdqa xmm14,xmm0
    7f716ee02830:	movdqu xmm15,XMMWORD PTR [rip+0x8e17]        # 0x7f716ee0b650
    7f716ee02839:	pand   xmm14,xmm15
    7f716ee0283e:	movdqu xmm15,XMMWORD PTR [rip+0x8e19]        # 0x7f716ee0b660
    7f716ee02847:	pcmpeqq xmm14,xmm15
    7f716ee0284d:	movdqa xmm15,xmm0
    7f716ee02852:	cmpunordpd xmm15,xmm0
    7f716ee02858:	por    xmm14,xmm15
    7f716ee0285d:	pmovmskb ecx,xmm14
    7f716ee02862:	jrcxz  0x7f716ee02869
    7f716ee02864:	jmp    0x7f716ee04148
    7f716ee02869:	movdqa xmm12,xmm0
    7f716ee0286e:	movdqu XMMWORD PTR [r12+0x170],xmm12
    7f716ee02878:	mov    r13,r14
    7f716ee0287b:	add    r13,0xd0
    7f716ee02882:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    7f716ee02888:	movdqu XMMWORD PTR [r12+0x110],xmm5
    7f716ee02892:	movdqa xmm0,xmm4
    7f716ee02896:	movdqa xmm1,xmm2
    7f716ee0289a:	addpd  xmm0,xmm1
    7f716ee0289e:	movdqa xmm14,xmm0
    7f716ee028a3:	movdqu xmm15,XMMWORD PTR [rip+0x8da4]        # 0x7f716ee0b650
    7f716ee028ac:	pand   xmm14,xmm15
    7f716ee028b1:	movdqu xmm15,XMMWORD PTR [rip+0x8da6]        # 0x7f716ee0b660
    7f716ee028ba:	pcmpeqq xmm14,xmm15
    7f716ee028c0:	movdqa xmm15,xmm0
    7f716ee028c5:	cmpunordpd xmm15,xmm0
    7f716ee028cb:	por    xmm14,xmm15
    7f716ee028d0:	pmovmskb ecx,xmm14
    7f716ee028d5:	jrcxz  0x7f716ee028dc
    7f716ee028d7:	jmp    0x7f716ee0416d
    7f716ee028dc:	movdqa xmm9,xmm0
    7f716ee028e1:	movdqu XMMWORD PTR [r12+0x220],xmm9
    7f716ee028eb:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    7f716ee028f5:	movdqa xmm0,xmm13
    7f716ee028fa:	movdqa xmm1,xmm2
    7f716ee028fe:	pshufd xmm1,xmm1,0x44
    7f716ee02903:	mulpd  xmm0,xmm1
    7f716ee02907:	movdqa xmm14,xmm0
    7f716ee0290c:	movdqu xmm15,XMMWORD PTR [rip+0x8d3b]        # 0x7f716ee0b650
    7f716ee02915:	pand   xmm14,xmm15
    7f716ee0291a:	movdqu xmm15,XMMWORD PTR [rip+0x8d3d]        # 0x7f716ee0b660
    7f716ee02923:	pcmpeqq xmm14,xmm15
    7f716ee02929:	movdqa xmm15,xmm0
    7f716ee0292e:	cmpunordpd xmm15,xmm0
    7f716ee02934:	por    xmm14,xmm15
    7f716ee02939:	pmovmskb ecx,xmm14
    7f716ee0293e:	jrcxz  0x7f716ee02945
    7f716ee02940:	jmp    0x7f716ee04191
    7f716ee02945:	movdqa xmm4,xmm0
    7f716ee02949:	movdqu XMMWORD PTR [r12+0x260],xmm4
    7f716ee02953:	mov    r13d,0x0
    7f716ee02959:	mov    ebp,0x0
    7f716ee0295e:	mov    QWORD PTR [r12+0x1b0],r13
    7f716ee02966:	mov    QWORD PTR [r12+0x1b8],rbp
    7f716ee0296e:	movdqa xmm0,xmm5
    7f716ee02972:	movdqa xmm1,xmm2
    7f716ee02976:	pshufd xmm1,xmm1,0x44
    7f716ee0297b:	mulpd  xmm0,xmm1
    7f716ee0297f:	movdqa xmm14,xmm0
    7f716ee02984:	movdqu xmm15,XMMWORD PTR [rip+0x8cc3]        # 0x7f716ee0b650
    7f716ee0298d:	pand   xmm14,xmm15
    7f716ee02992:	movdqu xmm15,XMMWORD PTR [rip+0x8cc5]        # 0x7f716ee0b660
    7f716ee0299b:	pcmpeqq xmm14,xmm15
    7f716ee029a1:	movdqa xmm15,xmm0
    7f716ee029a6:	cmpunordpd xmm15,xmm0
    7f716ee029ac:	por    xmm14,xmm15
    7f716ee029b1:	pmovmskb ecx,xmm14
    7f716ee029b6:	jrcxz  0x7f716ee029bd
    7f716ee029b8:	jmp    0x7f716ee041b6
    7f716ee029bd:	movdqa xmm13,xmm0
    7f716ee029c2:	movdqu XMMWORD PTR [r12+0x230],xmm13
    7f716ee029cc:	mov    r13,r14
    7f716ee029cf:	add    r13,0xc0
    7f716ee029d6:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    7f716ee029dc:	movdqu XMMWORD PTR [r12+0x110],xmm5
    7f716ee029e6:	movdqa xmm0,xmm3
    7f716ee029ea:	movdqa xmm1,xmm6
    7f716ee029ee:	addpd  xmm0,xmm1
    7f716ee029f2:	movdqa xmm14,xmm0
    7f716ee029f7:	movdqu xmm15,XMMWORD PTR [rip+0x8c50]        # 0x7f716ee0b650
    7f716ee02a00:	pand   xmm14,xmm15
    7f716ee02a05:	movdqu xmm15,XMMWORD PTR [rip+0x8c52]        # 0x7f716ee0b660
    7f716ee02a0e:	pcmpeqq xmm14,xmm15
    7f716ee02a14:	movdqa xmm15,xmm0
    7f716ee02a19:	cmpunordpd xmm15,xmm0
    7f716ee02a1f:	por    xmm14,xmm15
    7f716ee02a24:	pmovmskb ecx,xmm14
    7f716ee02a29:	jrcxz  0x7f716ee02a30
    7f716ee02a2b:	jmp    0x7f716ee041da
    7f716ee02a30:	movdqa xmm8,xmm0
    7f716ee02a35:	movdqu XMMWORD PTR [r12+0x240],xmm8
    7f716ee02a3f:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    7f716ee02a49:	movdqu xmm1,XMMWORD PTR [r12+0x1a0]
    7f716ee02a53:	por    xmm0,xmm1
    7f716ee02a57:	movdqu XMMWORD PTR [r12+0x270],xmm0
    7f716ee02a61:	movdqu xmm6,XMMWORD PTR [r12+0x120]
    7f716ee02a6b:	movdqu xmm1,XMMWORD PTR [r12+0x120]
    7f716ee02a75:	por    xmm6,xmm1
    7f716ee02a79:	movdqu XMMWORD PTR [r12+0x1a0],xmm6
    7f716ee02a83:	movdqa xmm0,xmm5
    7f716ee02a87:	movdqa xmm1,xmm2
    7f716ee02a8b:	pshufd xmm1,xmm1,0x44
    7f716ee02a90:	mulpd  xmm0,xmm1
    7f716ee02a94:	movdqa xmm14,xmm0
    7f716ee02a99:	movdqu xmm15,XMMWORD PTR [rip+0x8bae]        # 0x7f716ee0b650
    7f716ee02aa2:	pand   xmm14,xmm15
    7f716ee02aa7:	movdqu xmm15,XMMWORD PTR [rip+0x8bb0]        # 0x7f716ee0b660
    7f716ee02ab0:	pcmpeqq xmm14,xmm15
    7f716ee02ab6:	movdqa xmm15,xmm0
    7f716ee02abb:	cmpunordpd xmm15,xmm0
    7f716ee02ac1:	por    xmm14,xmm15
    7f716ee02ac6:	pmovmskb ecx,xmm14
    7f716ee02acb:	jrcxz  0x7f716ee02ad2
    7f716ee02acd:	jmp    0x7f716ee041fe
    7f716ee02ad2:	movdqa xmm6,xmm0
    7f716ee02ad6:	movdqu XMMWORD PTR [r12+0x250],xmm6
    7f716ee02ae0:	mov    r13,r14
    7f716ee02ae3:	add    r13,0x20
    7f716ee02ae7:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    7f716ee02aed:	movdqu XMMWORD PTR [r12+0x110],xmm5
    7f716ee02af7:	movdqa xmm0,xmm10
    7f716ee02afc:	movdqa xmm1,xmm12
    7f716ee02b01:	addpd  xmm0,xmm1
    7f716ee02b05:	movdqa xmm14,xmm0
    7f716ee02b0a:	movdqu xmm15,XMMWORD PTR [rip+0x8b3d]        # 0x7f716ee0b650
    7f716ee02b13:	pand   xmm14,xmm15
    7f716ee02b18:	movdqu xmm15,XMMWORD PTR [rip+0x8b3f]        # 0x7f716ee0b660
    7f716ee02b21:	pcmpeqq xmm14,xmm15
    7f716ee02b27:	movdqa xmm15,xmm0
    7f716ee02b2c:	cmpunordpd xmm15,xmm0
    7f716ee02b32:	por    xmm14,xmm15
    7f716ee02b37:	pmovmskb ecx,xmm14
    7f716ee02b3c:	jrcxz  0x7f716ee02b43
    7f716ee02b3e:	jmp    0x7f716ee04222
    7f716ee02b43:	movdqa xmm3,xmm0
    7f716ee02b47:	movdqa xmm0,xmm7
    7f716ee02b4b:	movdqa xmm1,xmm2
    7f716ee02b4f:	pshufd xmm1,xmm1,0x44
    7f716ee02b54:	mulpd  xmm0,xmm1
    7f716ee02b58:	movdqa xmm14,xmm0
    7f716ee02b5d:	movdqu xmm15,XMMWORD PTR [rip+0x8aea]        # 0x7f716ee0b650
    7f716ee02b66:	pand   xmm14,xmm15
    7f716ee02b6b:	movdqu xmm15,XMMWORD PTR [rip+0x8aec]        # 0x7f716ee0b660
    7f716ee02b74:	pcmpeqq xmm14,xmm15
    7f716ee02b7a:	movdqa xmm15,xmm0
    7f716ee02b7f:	cmpunordpd xmm15,xmm0
    7f716ee02b85:	por    xmm14,xmm15
    7f716ee02b8a:	pmovmskb ecx,xmm14
    7f716ee02b8f:	jrcxz  0x7f716ee02b96
    7f716ee02b91:	jmp    0x7f716ee04248
    7f716ee02b96:	movdqa xmm10,xmm0
    7f716ee02b9b:	movdqa xmm0,xmm11
    7f716ee02ba0:	movdqa xmm1,xmm13
    7f716ee02ba5:	addpd  xmm0,xmm1
    7f716ee02ba9:	movdqa xmm14,xmm0
    7f716ee02bae:	movdqu xmm15,XMMWORD PTR [rip+0x8a99]        # 0x7f716ee0b650
    7f716ee02bb7:	pand   xmm14,xmm15
    7f716ee02bbc:	movdqu xmm15,XMMWORD PTR [rip+0x8a9b]        # 0x7f716ee0b660
    7f716ee02bc5:	pcmpeqq xmm14,xmm15
    7f716ee02bcb:	movdqa xmm15,xmm0
    7f716ee02bd0:	cmpunordpd xmm15,xmm0
    7f716ee02bd6:	por    xmm14,xmm15
    7f716ee02bdb:	pmovmskb ecx,xmm14
    7f716ee02be0:	jrcxz  0x7f716ee02be7
    7f716ee02be2:	jmp    0x7f716ee0426c
    7f716ee02be7:	movdqa xmm2,xmm0
    7f716ee02beb:	movdqu xmm7,XMMWORD PTR [r12+0x150]
    7f716ee02bf5:	movdqa xmm0,xmm5
    7f716ee02bf9:	movdqa xmm1,xmm7
    7f716ee02bfd:	pshufd xmm1,xmm1,0x44
    7f716ee02c02:	mulpd  xmm0,xmm1
    7f716ee02c06:	movdqa xmm14,xmm0
    7f716ee02c0b:	movdqu xmm15,XMMWORD PTR [rip+0x8a3c]        # 0x7f716ee0b650
    7f716ee02c14:	pand   xmm14,xmm15
    7f716ee02c19:	movdqu xmm15,XMMWORD PTR [rip+0x8a3e]        # 0x7f716ee0b660
    7f716ee02c22:	pcmpeqq xmm14,xmm15
    7f716ee02c28:	movdqa xmm15,xmm0
    7f716ee02c2d:	cmpunordpd xmm15,xmm0
    7f716ee02c33:	por    xmm14,xmm15
    7f716ee02c38:	pmovmskb ecx,xmm14
    7f716ee02c3d:	jrcxz  0x7f716ee02c44
    7f716ee02c3f:	jmp    0x7f716ee04292
    7f716ee02c44:	movdqa xmm11,xmm0
    7f716ee02c49:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    7f716ee02c53:	movdqa xmm1,xmm7
    7f716ee02c57:	pshufd xmm1,xmm1,0x44
    7f716ee02c5c:	mulpd  xmm0,xmm1
    7f716ee02c60:	movdqa xmm14,xmm0
    7f716ee02c65:	movdqu xmm15,XMMWORD PTR [rip+0x89e2]        # 0x7f716ee0b650
    7f716ee02c6e:	pand   xmm14,xmm15
    7f716ee02c73:	movdqu xmm15,XMMWORD PTR [rip+0x89e4]        # 0x7f716ee0b660
    7f716ee02c7c:	pcmpeqq xmm14,xmm15
    7f716ee02c82:	movdqa xmm15,xmm0
    7f716ee02c87:	cmpunordpd xmm15,xmm0
    7f716ee02c8d:	por    xmm14,xmm15
    7f716ee02c92:	pmovmskb ecx,xmm14
    7f716ee02c97:	jrcxz  0x7f716ee02c9e
    7f716ee02c99:	jmp    0x7f716ee042b6
    7f716ee02c9e:	movdqa xmm5,xmm0
    7f716ee02ca2:	movdqa xmm0,xmm8
    7f716ee02ca7:	movdqa xmm1,xmm4
    7f716ee02cab:	addpd  xmm0,xmm1
    7f716ee02caf:	movdqa xmm14,xmm0
    7f716ee02cb4:	movdqu xmm15,XMMWORD PTR [rip+0x8993]        # 0x7f716ee0b650
    7f716ee02cbd:	pand   xmm14,xmm15
    7f716ee02cc2:	movdqu xmm15,XMMWORD PTR [rip+0x8995]        # 0x7f716ee0b660
    7f716ee02ccb:	pcmpeqq xmm14,xmm15
    7f716ee02cd1:	movdqa xmm15,xmm0
    7f716ee02cd6:	cmpunordpd xmm15,xmm0
    7f716ee02cdc:	por    xmm14,xmm15
    7f716ee02ce1:	pmovmskb ecx,xmm14
    7f716ee02ce6:	jrcxz  0x7f716ee02ced
    7f716ee02ce8:	jmp    0x7f716ee042e0
    7f716ee02ced:	movdqa xmm12,xmm0
    7f716ee02cf2:	movdqu XMMWORD PTR [r12+0x240],xmm12
    7f716ee02cfc:	movdqa xmm0,xmm9
    7f716ee02d01:	movdqa xmm1,xmm6
    7f716ee02d05:	addpd  xmm0,xmm1
    7f716ee02d09:	movdqa xmm14,xmm0
    7f716ee02d0e:	movdqu xmm15,XMMWORD PTR [rip+0x8939]        # 0x7f716ee0b650
    7f716ee02d17:	pand   xmm14,xmm15
    7f716ee02d1c:	movdqu xmm15,XMMWORD PTR [rip+0x893b]        # 0x7f716ee0b660
    7f716ee02d25:	pcmpeqq xmm14,xmm15
    7f716ee02d2b:	movdqa xmm15,xmm0
    7f716ee02d30:	cmpunordpd xmm15,xmm0
    7f716ee02d36:	por    xmm14,xmm15
    7f716ee02d3b:	pmovmskb ecx,xmm14
    7f716ee02d40:	jrcxz  0x7f716ee02d47
    7f716ee02d42:	jmp    0x7f716ee04305
    7f716ee02d47:	movdqa xmm4,xmm0
    7f716ee02d4b:	movdqu XMMWORD PTR [r12+0x220],xmm4
    7f716ee02d55:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    7f716ee02d5f:	movdqa xmm1,xmm7
    7f716ee02d63:	pshufd xmm1,xmm1,0x44
    7f716ee02d68:	mulpd  xmm0,xmm1
    7f716ee02d6c:	movdqa xmm14,xmm0
    7f716ee02d71:	movdqu xmm15,XMMWORD PTR [rip+0x88d6]        # 0x7f716ee0b650
    7f716ee02d7a:	pand   xmm14,xmm15
    7f716ee02d7f:	movdqu xmm15,XMMWORD PTR [rip+0x88d8]        # 0x7f716ee0b660
    7f716ee02d88:	pcmpeqq xmm14,xmm15
    7f716ee02d8e:	movdqa xmm15,xmm0
    7f716ee02d93:	cmpunordpd xmm15,xmm0
    7f716ee02d99:	por    xmm14,xmm15
    7f716ee02d9e:	pmovmskb ecx,xmm14
    7f716ee02da3:	jrcxz  0x7f716ee02daa
    7f716ee02da5:	jmp    0x7f716ee0432a
    7f716ee02daa:	movdqa xmm6,xmm0
    7f716ee02dae:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7f716ee02db8:	movdqa xmm1,xmm7
    7f716ee02dbc:	pshufd xmm1,xmm1,0x44
    7f716ee02dc1:	mulpd  xmm0,xmm1
    7f716ee02dc5:	movdqa xmm14,xmm0
    7f716ee02dca:	movdqu xmm15,XMMWORD PTR [rip+0x887d]        # 0x7f716ee0b650
    7f716ee02dd3:	pand   xmm14,xmm15
    7f716ee02dd8:	movdqu xmm15,XMMWORD PTR [rip+0x887f]        # 0x7f716ee0b660
    7f716ee02de1:	pcmpeqq xmm14,xmm15
    7f716ee02de7:	movdqa xmm15,xmm0
    7f716ee02dec:	cmpunordpd xmm15,xmm0
    7f716ee02df2:	por    xmm14,xmm15
    7f716ee02df7:	pmovmskb ecx,xmm14
    7f716ee02dfc:	jrcxz  0x7f716ee02e03
    7f716ee02dfe:	jmp    0x7f716ee04354
    7f716ee02e03:	movdqa xmm8,xmm0
    7f716ee02e08:	movdqu XMMWORD PTR [r12+0x150],xmm8
    7f716ee02e12:	movdqa xmm0,xmm3
    7f716ee02e16:	movdqa xmm1,xmm10
    7f716ee02e1b:	addpd  xmm0,xmm1
    7f716ee02e1f:	movdqa xmm14,xmm0
    7f716ee02e24:	movdqu xmm15,XMMWORD PTR [rip+0x8823]        # 0x7f716ee0b650
    7f716ee02e2d:	pand   xmm14,xmm15
    7f716ee02e32:	movdqu xmm15,XMMWORD PTR [rip+0x8825]        # 0x7f716ee0b660
    7f716ee02e3b:	pcmpeqq xmm14,xmm15
    7f716ee02e41:	movdqa xmm15,xmm0
    7f716ee02e46:	cmpunordpd xmm15,xmm0
    7f716ee02e4c:	por    xmm14,xmm15
    7f716ee02e51:	pmovmskb ecx,xmm14
    7f716ee02e56:	jrcxz  0x7f716ee02e5d
    7f716ee02e58:	jmp    0x7f716ee0437e
    7f716ee02e5d:	movdqa xmm7,xmm0
    7f716ee02e61:	movdqu XMMWORD PTR [r12+0x160],xmm7
    7f716ee02e6b:	movdqa xmm0,xmm2
    7f716ee02e6f:	movdqa xmm1,xmm11
    7f716ee02e74:	addpd  xmm0,xmm1
    7f716ee02e78:	movdqa xmm14,xmm0
    7f716ee02e7d:	movdqu xmm15,XMMWORD PTR [rip+0x87ca]        # 0x7f716ee0b650
    7f716ee02e86:	pand   xmm14,xmm15
    7f716ee02e8b:	movdqu xmm15,XMMWORD PTR [rip+0x87cc]        # 0x7f716ee0b660
    7f716ee02e94:	pcmpeqq xmm14,xmm15
    7f716ee02e9a:	movdqa xmm15,xmm0
    7f716ee02e9f:	cmpunordpd xmm15,xmm0
    7f716ee02ea5:	por    xmm14,xmm15
    7f716ee02eaa:	pmovmskb ecx,xmm14
    7f716ee02eaf:	jrcxz  0x7f716ee02eb6
    7f716ee02eb1:	jmp    0x7f716ee043a3
    7f716ee02eb6:	movdqa xmm3,xmm0
    7f716ee02eba:	movdqu XMMWORD PTR [r12+0x170],xmm3
    7f716ee02ec4:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    7f716ee02ece:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7f716ee02ed8:	movdqa xmm1,xmm2
    7f716ee02edc:	pshufd xmm1,xmm1,0x44
    7f716ee02ee1:	mulpd  xmm0,xmm1
    7f716ee02ee5:	movdqa xmm14,xmm0
    7f716ee02eea:	movdqu xmm15,XMMWORD PTR [rip+0x875d]        # 0x7f716ee0b650
    7f716ee02ef3:	pand   xmm14,xmm15
    7f716ee02ef8:	movdqu xmm15,XMMWORD PTR [rip+0x875f]        # 0x7f716ee0b660
    7f716ee02f01:	pcmpeqq xmm14,xmm15
    7f716ee02f07:	movdqa xmm15,xmm0
    7f716ee02f0c:	cmpunordpd xmm15,xmm0
    7f716ee02f12:	por    xmm14,xmm15
    7f716ee02f17:	pmovmskb ecx,xmm14
    7f716ee02f1c:	jrcxz  0x7f716ee02f23
    7f716ee02f1e:	jmp    0x7f716ee043c8
    7f716ee02f23:	movdqa xmm9,xmm0
    7f716ee02f28:	movdqu XMMWORD PTR [r12+0x180],xmm9
    7f716ee02f32:	movdqa xmm0,xmm4
    7f716ee02f36:	movdqa xmm1,xmm5
    7f716ee02f3a:	addpd  xmm0,xmm1
    7f716ee02f3e:	movdqa xmm14,xmm0
    7f716ee02f43:	movdqu xmm15,XMMWORD PTR [rip+0x8704]        # 0x7f716ee0b650
    7f716ee02f4c:	pand   xmm14,xmm15
    7f716ee02f51:	movdqu xmm15,XMMWORD PTR [rip+0x8706]        # 0x7f716ee0b660
    7f716ee02f5a:	pcmpeqq xmm14,xmm15
    7f716ee02f60:	movdqa xmm15,xmm0
    7f716ee02f65:	cmpunordpd xmm15,xmm0
    7f716ee02f6b:	por    xmm14,xmm15
    7f716ee02f70:	pmovmskb ecx,xmm14
    7f716ee02f75:	jrcxz  0x7f716ee02f7c
    7f716ee02f77:	jmp    0x7f716ee043f2
    7f716ee02f7c:	movdqa xmm10,xmm0
    7f716ee02f81:	movdqu XMMWORD PTR [r12+0x210],xmm10
    7f716ee02f8b:	movdqa xmm0,xmm12
    7f716ee02f90:	movdqa xmm1,xmm6
    7f716ee02f94:	addpd  xmm0,xmm1
    7f716ee02f98:	movdqa xmm14,xmm0
    7f716ee02f9d:	movdqu xmm15,XMMWORD PTR [rip+0x86aa]        # 0x7f716ee0b650
    7f716ee02fa6:	pand   xmm14,xmm15
    7f716ee02fab:	movdqu xmm15,XMMWORD PTR [rip+0x86ac]        # 0x7f716ee0b660
    7f716ee02fb4:	pcmpeqq xmm14,xmm15
    7f716ee02fba:	movdqa xmm15,xmm0
    7f716ee02fbf:	cmpunordpd xmm15,xmm0
    7f716ee02fc5:	por    xmm14,xmm15
    7f716ee02fca:	pmovmskb ecx,xmm14
    7f716ee02fcf:	jrcxz  0x7f716ee02fd6
    7f716ee02fd1:	jmp    0x7f716ee04416
    7f716ee02fd6:	movdqa xmm4,xmm0
    7f716ee02fda:	movdqu XMMWORD PTR [r12+0x230],xmm4
    7f716ee02fe4:	movdqu xmm5,XMMWORD PTR [r12+0x2a0]
    7f716ee02fee:	movdqu xmm1,XMMWORD PTR [r12+0x2a0]
    7f716ee02ff8:	por    xmm5,xmm1
    7f716ee02ffc:	movdqu XMMWORD PTR [r12+0x250],xmm5
    7f716ee03006:	movdqu xmm5,XMMWORD PTR [r12+0x1d0]
    7f716ee03010:	movdqu xmm1,XMMWORD PTR [r12+0x1d0]
    7f716ee0301a:	por    xmm5,xmm1
    7f716ee0301e:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    7f716ee03028:	movdqu xmm6,XMMWORD PTR [r12+0x2c0]
    7f716ee03032:	movdqu xmm1,XMMWORD PTR [r12+0x2c0]
    7f716ee0303c:	por    xmm6,xmm1
    7f716ee03040:	movdqu XMMWORD PTR [r12+0x1d0],xmm6
    7f716ee0304a:	mov    r13,r14
    7f716ee0304d:	add    r13,0x40
    7f716ee03051:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    7f716ee03057:	movdqu XMMWORD PTR [r12+0x2c0],xmm6
    7f716ee03061:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    7f716ee0306b:	movdqa xmm1,xmm2
    7f716ee0306f:	pshufd xmm1,xmm1,0x44
    7f716ee03074:	mulpd  xmm0,xmm1
    7f716ee03078:	movdqa xmm14,xmm0
    7f716ee0307d:	movdqu xmm15,XMMWORD PTR [rip+0x85ca]        # 0x7f716ee0b650
    7f716ee03086:	pand   xmm14,xmm15
    7f716ee0308b:	movdqu xmm15,XMMWORD PTR [rip+0x85cc]        # 0x7f716ee0b660
    7f716ee03094:	pcmpeqq xmm14,xmm15
    7f716ee0309a:	movdqa xmm15,xmm0
    7f716ee0309f:	cmpunordpd xmm15,xmm0
    7f716ee030a5:	por    xmm14,xmm15
    7f716ee030aa:	pmovmskb ecx,xmm14
    7f716ee030af:	jrcxz  0x7f716ee030b6
    7f716ee030b1:	jmp    0x7f716ee0443b
    7f716ee030b6:	movdqa xmm11,xmm0
    7f716ee030bb:	movdqa xmm0,xmm7
    7f716ee030bf:	movdqa xmm1,xmm8
    7f716ee030c4:	addpd  xmm0,xmm1
    7f716ee030c8:	movdqa xmm14,xmm0
    7f716ee030cd:	movdqu xmm15,XMMWORD PTR [rip+0x857a]        # 0x7f716ee0b650
    7f716ee030d6:	pand   xmm14,xmm15
    7f716ee030db:	movdqu xmm15,XMMWORD PTR [rip+0x857c]        # 0x7f716ee0b660
    7f716ee030e4:	pcmpeqq xmm14,xmm15
    7f716ee030ea:	movdqa xmm15,xmm0
    7f716ee030ef:	cmpunordpd xmm15,xmm0
    7f716ee030f5:	por    xmm14,xmm15
    7f716ee030fa:	pmovmskb ecx,xmm14
    7f716ee030ff:	jrcxz  0x7f716ee03106
    7f716ee03101:	jmp    0x7f716ee04465
    7f716ee03106:	movdqa xmm12,xmm0
    7f716ee0310b:	movdqa xmm0,xmm3
    7f716ee0310f:	movdqa xmm1,xmm9
    7f716ee03114:	addpd  xmm0,xmm1
    7f716ee03118:	movdqa xmm14,xmm0
    7f716ee0311d:	movdqu xmm15,XMMWORD PTR [rip+0x852a]        # 0x7f716ee0b650
    7f716ee03126:	pand   xmm14,xmm15
    7f716ee0312b:	movdqu xmm15,XMMWORD PTR [rip+0x852c]        # 0x7f716ee0b660
    7f716ee03134:	pcmpeqq xmm14,xmm15
    7f716ee0313a:	movdqa xmm15,xmm0
    7f716ee0313f:	cmpunordpd xmm15,xmm0
    7f716ee03145:	por    xmm14,xmm15
    7f716ee0314a:	pmovmskb ecx,xmm14
    7f716ee0314f:	jrcxz  0x7f716ee03156
    7f716ee03151:	jmp    0x7f716ee0448a
    7f716ee03156:	movdqa xmm7,xmm0
    7f716ee0315a:	movdqu XMMWORD PTR [r12+0x160],xmm7
    7f716ee03164:	movdqa xmm0,xmm6
    7f716ee03168:	movdqa xmm1,xmm2
    7f716ee0316c:	pshufd xmm1,xmm1,0x44
    7f716ee03171:	mulpd  xmm0,xmm1
    7f716ee03175:	movdqa xmm14,xmm0
    7f716ee0317a:	movdqu xmm15,XMMWORD PTR [rip+0x84cd]        # 0x7f716ee0b650
    7f716ee03183:	pand   xmm14,xmm15
    7f716ee03188:	movdqu xmm15,XMMWORD PTR [rip+0x84cf]        # 0x7f716ee0b660
    7f716ee03191:	pcmpeqq xmm14,xmm15
    7f716ee03197:	movdqa xmm15,xmm0
    7f716ee0319c:	cmpunordpd xmm15,xmm0
    7f716ee031a2:	por    xmm14,xmm15
    7f716ee031a7:	pmovmskb ecx,xmm14
    7f716ee031ac:	jrcxz  0x7f716ee031b3
    7f716ee031ae:	jmp    0x7f716ee044af
    7f716ee031b3:	movdqa xmm3,xmm0
    7f716ee031b7:	movdqu XMMWORD PTR [r12+0x240],xmm3
    7f716ee031c1:	movdqu xmm6,XMMWORD PTR [r12+0x2b0]
    7f716ee031cb:	movdqa xmm0,xmm6
    7f716ee031cf:	movdqa xmm1,xmm2
    7f716ee031d3:	pshufd xmm1,xmm1,0x44
    7f716ee031d8:	mulpd  xmm0,xmm1
    7f716ee031dc:	movdqa xmm14,xmm0
    7f716ee031e1:	movdqu xmm15,XMMWORD PTR [rip+0x8466]        # 0x7f716ee0b650
    7f716ee031ea:	pand   xmm14,xmm15
    7f716ee031ef:	movdqu xmm15,XMMWORD PTR [rip+0x8468]        # 0x7f716ee0b660
    7f716ee031f8:	pcmpeqq xmm14,xmm15
    7f716ee031fe:	movdqa xmm15,xmm0
    7f716ee03203:	cmpunordpd xmm15,xmm0
    7f716ee03209:	por    xmm14,xmm15
    7f716ee0320e:	pmovmskb ecx,xmm14
    7f716ee03213:	jrcxz  0x7f716ee0321a
    7f716ee03215:	jmp    0x7f716ee044d3
    7f716ee0321a:	movdqa xmm8,xmm0
    7f716ee0321f:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    7f716ee03229:	movdqa xmm0,xmm5
    7f716ee0322d:	movdqa xmm1,xmm2
    7f716ee03231:	pshufd xmm1,xmm1,0x44
    7f716ee03236:	mulpd  xmm0,xmm1
    7f716ee0323a:	movdqa xmm14,xmm0
    7f716ee0323f:	movdqu xmm15,XMMWORD PTR [rip+0x8408]        # 0x7f716ee0b650
    7f716ee03248:	pand   xmm14,xmm15
    7f716ee0324d:	movdqu xmm15,XMMWORD PTR [rip+0x840a]        # 0x7f716ee0b660
    7f716ee03256:	pcmpeqq xmm14,xmm15
    7f716ee0325c:	movdqa xmm15,xmm0
    7f716ee03261:	cmpunordpd xmm15,xmm0
    7f716ee03267:	por    xmm14,xmm15
    7f716ee0326c:	pmovmskb ecx,xmm14
    7f716ee03271:	jrcxz  0x7f716ee03278
    7f716ee03273:	jmp    0x7f716ee044f7
    7f716ee03278:	movdqa xmm6,xmm0
    7f716ee0327c:	movdqu XMMWORD PTR [r12+0x170],xmm6
    7f716ee03286:	movdqa xmm0,xmm10
    7f716ee0328b:	movdqa xmm1,xmm11
    7f716ee03290:	addpd  xmm0,xmm1
    7f716ee03294:	movdqa xmm14,xmm0
    7f716ee03299:	movdqu xmm15,XMMWORD PTR [rip+0x83ae]        # 0x7f716ee0b650
    7f716ee032a2:	pand   xmm14,xmm15
    7f716ee032a7:	movdqu xmm15,XMMWORD PTR [rip+0x83b0]        # 0x7f716ee0b660
    7f716ee032b0:	pcmpeqq xmm14,xmm15
    7f716ee032b6:	movdqa xmm15,xmm0
    7f716ee032bb:	cmpunordpd xmm15,xmm0
    7f716ee032c1:	por    xmm14,xmm15
    7f716ee032c6:	pmovmskb ecx,xmm14
    7f716ee032cb:	jrcxz  0x7f716ee032d2
    7f716ee032cd:	jmp    0x7f716ee0451b
    7f716ee032d2:	movdqa xmm5,xmm0
    7f716ee032d6:	movdqu XMMWORD PTR [r12+0x180],xmm5
    7f716ee032e0:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7f716ee032ea:	movdqa xmm1,xmm2
    7f716ee032ee:	pshufd xmm1,xmm1,0x44
    7f716ee032f3:	mulpd  xmm0,xmm1
    7f716ee032f7:	movdqa xmm14,xmm0
    7f716ee032fc:	movdqu xmm15,XMMWORD PTR [rip+0x834b]        # 0x7f716ee0b650
    7f716ee03305:	pand   xmm14,xmm15
    7f716ee0330a:	movdqu xmm15,XMMWORD PTR [rip+0x834d]        # 0x7f716ee0b660
    7f716ee03313:	pcmpeqq xmm14,xmm15
    7f716ee03319:	movdqa xmm15,xmm0
    7f716ee0331e:	cmpunordpd xmm15,xmm0
    7f716ee03324:	por    xmm14,xmm15
    7f716ee03329:	pmovmskb ecx,xmm14
    7f716ee0332e:	jrcxz  0x7f716ee03335
    7f716ee03330:	jmp    0x7f716ee04541
    7f716ee03335:	movdqa xmm9,xmm0
    7f716ee0333a:	movdqu XMMWORD PTR [r12+0x210],xmm9
    7f716ee03344:	movdqa xmm0,xmm4
    7f716ee03348:	movdqa xmm1,xmm3
    7f716ee0334c:	addpd  xmm0,xmm1
    7f716ee03350:	movdqa xmm14,xmm0
    7f716ee03355:	movdqu xmm15,XMMWORD PTR [rip+0x82f2]        # 0x7f716ee0b650
    7f716ee0335e:	pand   xmm14,xmm15
    7f716ee03363:	movdqu xmm15,XMMWORD PTR [rip+0x82f4]        # 0x7f716ee0b660
    7f716ee0336c:	pcmpeqq xmm14,xmm15
    7f716ee03372:	movdqa xmm15,xmm0
    7f716ee03377:	cmpunordpd xmm15,xmm0
    7f716ee0337d:	por    xmm14,xmm15
    7f716ee03382:	pmovmskb ecx,xmm14
    7f716ee03387:	jrcxz  0x7f716ee0338e
    7f716ee03389:	jmp    0x7f716ee0456b
    7f716ee0338e:	movdqa xmm10,xmm0
    7f716ee03393:	movdqu XMMWORD PTR [r12+0x220],xmm10
    7f716ee0339d:	movdqu xmm3,XMMWORD PTR [r12+0x290]
    7f716ee033a7:	movdqa xmm0,xmm3
    7f716ee033ab:	movdqa xmm1,xmm2
    7f716ee033af:	pshufd xmm1,xmm1,0x44
    7f716ee033b4:	mulpd  xmm0,xmm1
    7f716ee033b8:	movdqa xmm14,xmm0
    7f716ee033bd:	movdqu xmm15,XMMWORD PTR [rip+0x828a]        # 0x7f716ee0b650
    7f716ee033c6:	pand   xmm14,xmm15
    7f716ee033cb:	movdqu xmm15,XMMWORD PTR [rip+0x828c]        # 0x7f716ee0b660
    7f716ee033d4:	pcmpeqq xmm14,xmm15
    7f716ee033da:	movdqa xmm15,xmm0
    7f716ee033df:	cmpunordpd xmm15,xmm0
    7f716ee033e5:	por    xmm14,xmm15
    7f716ee033ea:	pmovmskb ecx,xmm14
    7f716ee033ef:	jrcxz  0x7f716ee033f6
    7f716ee033f1:	jmp    0x7f716ee0458f
    7f716ee033f6:	movdqa xmm4,xmm0
    7f716ee033fa:	movdqu XMMWORD PTR [r12+0x230],xmm4
    7f716ee03404:	movdqa xmm0,xmm12
    7f716ee03409:	movdqa xmm1,xmm8
    7f716ee0340e:	addpd  xmm0,xmm1
    7f716ee03412:	movdqa xmm14,xmm0
    7f716ee03417:	movdqu xmm15,XMMWORD PTR [rip+0x8230]        # 0x7f716ee0b650
    7f716ee03420:	pand   xmm14,xmm15
    7f716ee03425:	movdqu xmm15,XMMWORD PTR [rip+0x8232]        # 0x7f716ee0b660
    7f716ee0342e:	pcmpeqq xmm14,xmm15
    7f716ee03434:	movdqa xmm15,xmm0
    7f716ee03439:	cmpunordpd xmm15,xmm0
    7f716ee0343f:	por    xmm14,xmm15
    7f716ee03444:	pmovmskb ecx,xmm14
    7f716ee03449:	jrcxz  0x7f716ee03450
    7f716ee0344b:	jmp    0x7f716ee045b3
    7f716ee03450:	movdqa xmm3,xmm0
    7f716ee03454:	movdqu XMMWORD PTR [r12+0x140],xmm3
    7f716ee0345e:	movdqu xmm8,XMMWORD PTR [r12+0x1e0]
    7f716ee03468:	movdqa xmm0,xmm8
    7f716ee0346d:	movdqa xmm1,xmm2
    7f716ee03471:	pshufd xmm1,xmm1,0x44
    7f716ee03476:	mulpd  xmm0,xmm1
    7f716ee0347a:	movdqa xmm14,xmm0
    7f716ee0347f:	movdqu xmm15,XMMWORD PTR [rip+0x81c8]        # 0x7f716ee0b650
    7f716ee03488:	pand   xmm14,xmm15
    7f716ee0348d:	movdqu xmm15,XMMWORD PTR [rip+0x81ca]        # 0x7f716ee0b660
    7f716ee03496:	pcmpeqq xmm14,xmm15
    7f716ee0349c:	movdqa xmm15,xmm0
    7f716ee034a1:	cmpunordpd xmm15,xmm0
    7f716ee034a7:	por    xmm14,xmm15
    7f716ee034ac:	pmovmskb ecx,xmm14
    7f716ee034b1:	jrcxz  0x7f716ee034b8
    7f716ee034b3:	jmp    0x7f716ee045d9
    7f716ee034b8:	movdqa xmm11,xmm0
    7f716ee034bd:	movdqu XMMWORD PTR [r12+0x130],xmm11
    7f716ee034c7:	movdqa xmm0,xmm7
    7f716ee034cb:	movdqa xmm1,xmm6
    7f716ee034cf:	addpd  xmm0,xmm1
    7f716ee034d3:	movdqa xmm14,xmm0
    7f716ee034d8:	movdqu xmm15,XMMWORD PTR [rip+0x816f]        # 0x7f716ee0b650
    7f716ee034e1:	pand   xmm14,xmm15
    7f716ee034e6:	movdqu xmm15,XMMWORD PTR [rip+0x8171]        # 0x7f716ee0b660
    7f716ee034ef:	pcmpeqq xmm14,xmm15
    7f716ee034f5:	movdqa xmm15,xmm0
    7f716ee034fa:	cmpunordpd xmm15,xmm0
    7f716ee03500:	por    xmm14,xmm15
    7f716ee03505:	pmovmskb ecx,xmm14
    7f716ee0350a:	jrcxz  0x7f716ee03511
    7f716ee0350c:	jmp    0x7f716ee045fe
    7f716ee03511:	movdqa xmm2,xmm0
    7f716ee03515:	movdqu XMMWORD PTR [r12+0x150],xmm2
    7f716ee0351f:	mov    r13,r14
    7f716ee03522:	add    r13,0x70
    7f716ee03526:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    7f716ee0352c:	movdqu XMMWORD PTR [r12+0x240],xmm6
    7f716ee03536:	movdqa xmm0,xmm5
    7f716ee0353a:	movdqa xmm1,xmm9
    7f716ee0353f:	addpd  xmm0,xmm1
    7f716ee03543:	movdqa xmm14,xmm0
    7f716ee03548:	movdqu xmm15,XMMWORD PTR [rip+0x80ff]        # 0x7f716ee0b650
    7f716ee03551:	pand   xmm14,xmm15
    7f716ee03556:	movdqu xmm15,XMMWORD PTR [rip+0x8101]        # 0x7f716ee0b660
    7f716ee0355f:	pcmpeqq xmm14,xmm15
    7f716ee03565:	movdqa xmm15,xmm0
    7f716ee0356a:	cmpunordpd xmm15,xmm0
    7f716ee03570:	por    xmm14,xmm15
    7f716ee03575:	pmovmskb ecx,xmm14
    7f716ee0357a:	jrcxz  0x7f716ee03581
    7f716ee0357c:	jmp    0x7f716ee04622
    7f716ee03581:	movdqa xmm7,xmm0
    7f716ee03585:	movdqu XMMWORD PTR [r12+0x170],xmm7
    7f716ee0358f:	movdqu xmm5,XMMWORD PTR [r12+0x280]
    7f716ee03599:	movdqa xmm0,xmm6
    7f716ee0359d:	movdqa xmm1,xmm5
    7f716ee035a1:	pshufd xmm1,xmm1,0x44
    7f716ee035a6:	mulpd  xmm0,xmm1
    7f716ee035aa:	movdqa xmm14,xmm0
    7f716ee035af:	movdqu xmm15,XMMWORD PTR [rip+0x8098]        # 0x7f716ee0b650
    7f716ee035b8:	pand   xmm14,xmm15
    7f716ee035bd:	movdqu xmm15,XMMWORD PTR [rip+0x809a]        # 0x7f716ee0b660
    7f716ee035c6:	pcmpeqq xmm14,xmm15
    7f716ee035cc:	movdqa xmm15,xmm0
    7f716ee035d1:	cmpunordpd xmm15,xmm0
    7f716ee035d7:	por    xmm14,xmm15
    7f716ee035dc:	pmovmskb ecx,xmm14
    7f716ee035e1:	jrcxz  0x7f716ee035e8
    7f716ee035e3:	jmp    0x7f716ee04647
    7f716ee035e8:	movdqa xmm8,xmm0
    7f716ee035ed:	movdqu XMMWORD PTR [r12+0x160],xmm8
    7f716ee035f7:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7f716ee03601:	movdqa xmm1,xmm5
    7f716ee03605:	pshufd xmm1,xmm1,0x44
    7f716ee0360a:	mulpd  xmm0,xmm1
    7f716ee0360e:	movdqa xmm14,xmm0
    7f716ee03613:	movdqu xmm15,XMMWORD PTR [rip+0x8034]        # 0x7f716ee0b650
    7f716ee0361c:	pand   xmm14,xmm15
    7f716ee03621:	movdqu xmm15,XMMWORD PTR [rip+0x8036]        # 0x7f716ee0b660
    7f716ee0362a:	pcmpeqq xmm14,xmm15
    7f716ee03630:	movdqa xmm15,xmm0
    7f716ee03635:	cmpunordpd xmm15,xmm0
    7f716ee0363b:	por    xmm14,xmm15
    7f716ee03640:	pmovmskb ecx,xmm14
    7f716ee03645:	jrcxz  0x7f716ee0364c
    7f716ee03647:	jmp    0x7f716ee0466b
    7f716ee0364c:	movdqa xmm6,xmm0
    7f716ee03650:	movdqu XMMWORD PTR [r12+0x180],xmm6
    7f716ee0365a:	movdqa xmm0,xmm10
    7f716ee0365f:	movdqa xmm1,xmm4
    7f716ee03663:	addpd  xmm0,xmm1
    7f716ee03667:	movdqa xmm14,xmm0
    7f716ee0366c:	movdqu xmm15,XMMWORD PTR [rip+0x7fdb]        # 0x7f716ee0b650
    7f716ee03675:	pand   xmm14,xmm15
    7f716ee0367a:	movdqu xmm15,XMMWORD PTR [rip+0x7fdd]        # 0x7f716ee0b660
    7f716ee03683:	pcmpeqq xmm14,xmm15
    7f716ee03689:	movdqa xmm15,xmm0
    7f716ee0368e:	cmpunordpd xmm15,xmm0
    7f716ee03694:	por    xmm14,xmm15
    7f716ee03699:	pmovmskb ecx,xmm14
    7f716ee0369e:	jrcxz  0x7f716ee036a5
    7f716ee036a0:	jmp    0x7f716ee04695
    7f716ee036a5:	movdqa xmm9,xmm0
    7f716ee036aa:	movdqu XMMWORD PTR [r12+0x210],xmm9
    7f716ee036b4:	mov    r13,r14
    7f716ee036b7:	add    r13,0x10
    7f716ee036bb:	movdqu xmm4,XMMWORD PTR [r14]
    7f716ee036c0:	movdqu xmm10,XMMWORD PTR [r13+0x0]
    7f716ee036c6:	movdqu XMMWORD PTR [r12+0x230],xmm10
    7f716ee036d0:	movdqa xmm0,xmm3
    7f716ee036d4:	movdqa xmm1,xmm11
    7f716ee036d9:	addpd  xmm0,xmm1
    7f716ee036dd:	movdqa xmm14,xmm0
    7f716ee036e2:	movdqu xmm15,XMMWORD PTR [rip+0x7f65]        # 0x7f716ee0b650
    7f716ee036eb:	pand   xmm14,xmm15
    7f716ee036f0:	movdqu xmm15,XMMWORD PTR [rip+0x7f67]        # 0x7f716ee0b660
    7f716ee036f9:	pcmpeqq xmm14,xmm15
    7f716ee036ff:	movdqa xmm15,xmm0
    7f716ee03704:	cmpunordpd xmm15,xmm0
    7f716ee0370a:	por    xmm14,xmm15
    7f716ee0370f:	pmovmskb ecx,xmm14
    7f716ee03714:	jrcxz  0x7f716ee0371b
    7f716ee03716:	jmp    0x7f716ee046ba
    7f716ee0371b:	movdqa xmm12,xmm0
    7f716ee03720:	movdqu XMMWORD PTR [r12+0x130],xmm12
    7f716ee0372a:	movdqa xmm0,xmm10
    7f716ee0372f:	movdqa xmm1,xmm5
    7f716ee03733:	pshufd xmm1,xmm1,0x44
    7f716ee03738:	mulpd  xmm0,xmm1
    7f716ee0373c:	movdqa xmm14,xmm0
    7f716ee03741:	movdqu xmm15,XMMWORD PTR [rip+0x7f06]        # 0x7f716ee0b650
    7f716ee0374a:	pand   xmm14,xmm15
    7f716ee0374f:	movdqu xmm15,XMMWORD PTR [rip+0x7f08]        # 0x7f716ee0b660
    7f716ee03758:	pcmpeqq xmm14,xmm15
    7f716ee0375e:	movdqa xmm15,xmm0
    7f716ee03763:	cmpunordpd xmm15,xmm0
    7f716ee03769:	por    xmm14,xmm15
    7f716ee0376e:	pmovmskb ecx,xmm14
    7f716ee03773:	jrcxz  0x7f716ee0377a
    7f716ee03775:	jmp    0x7f716ee046df
    7f716ee0377a:	movdqa xmm3,xmm0
    7f716ee0377e:	movdqu XMMWORD PTR [r12+0x220],xmm3
    7f716ee03788:	movdqa xmm0,xmm4
    7f716ee0378c:	movdqa xmm1,xmm5
    7f716ee03790:	pshufd xmm1,xmm1,0x44
    7f716ee03795:	mulpd  xmm0,xmm1
    7f716ee03799:	movdqa xmm14,xmm0
    7f716ee0379e:	movdqu xmm15,XMMWORD PTR [rip+0x7ea9]        # 0x7f716ee0b650
    7f716ee037a7:	pand   xmm14,xmm15
    7f716ee037ac:	movdqu xmm15,XMMWORD PTR [rip+0x7eab]        # 0x7f716ee0b660
    7f716ee037b5:	pcmpeqq xmm14,xmm15
    7f716ee037bb:	movdqa xmm15,xmm0
    7f716ee037c0:	cmpunordpd xmm15,xmm0
    7f716ee037c6:	por    xmm14,xmm15
    7f716ee037cb:	pmovmskb ecx,xmm14
    7f716ee037d0:	jrcxz  0x7f716ee037d7
    7f716ee037d2:	jmp    0x7f716ee04704
    7f716ee037d7:	movdqa xmm10,xmm0
    7f716ee037dc:	movdqa xmm0,xmm2
    7f716ee037e0:	movdqa xmm1,xmm8
    7f716ee037e5:	addpd  xmm0,xmm1
    7f716ee037e9:	movdqa xmm14,xmm0
    7f716ee037ee:	movdqu xmm15,XMMWORD PTR [rip+0x7e59]        # 0x7f716ee0b650
    7f716ee037f7:	pand   xmm14,xmm15
    7f716ee037fc:	movdqu xmm15,XMMWORD PTR [rip+0x7e5b]        # 0x7f716ee0b660
    7f716ee03805:	pcmpeqq xmm14,xmm15
    7f716ee0380b:	movdqa xmm15,xmm0
    7f716ee03810:	cmpunordpd xmm15,xmm0
    7f716ee03816:	por    xmm14,xmm15
    7f716ee0381b:	pmovmskb ecx,xmm14
    7f716ee03820:	jrcxz  0x7f716ee03827
    7f716ee03822:	jmp    0x7f716ee04728
    7f716ee03827:	movdqa xmm4,xmm0
    7f716ee0382b:	movdqu XMMWORD PTR [r12+0x140],xmm4
    7f716ee03835:	movdqa xmm0,xmm7
    7f716ee03839:	movdqa xmm1,xmm6
    7f716ee0383d:	addpd  xmm0,xmm1
    7f716ee03841:	movdqa xmm14,xmm0
    7f716ee03846:	movdqu xmm15,XMMWORD PTR [rip+0x7e01]        # 0x7f716ee0b650
    7f716ee0384f:	pand   xmm14,xmm15
    7f716ee03854:	movdqu xmm15,XMMWORD PTR [rip+0x7e03]        # 0x7f716ee0b660
    7f716ee0385d:	pcmpeqq xmm14,xmm15
    7f716ee03863:	movdqa xmm15,xmm0
    7f716ee03868:	cmpunordpd xmm15,xmm0
    7f716ee0386e:	por    xmm14,xmm15
    7f716ee03873:	pmovmskb ecx,xmm14
    7f716ee03878:	jrcxz  0x7f716ee0387f
    7f716ee0387a:	jmp    0x7f716ee0474d
    7f716ee0387f:	movdqa xmm2,xmm0
    7f716ee03883:	movdqu XMMWORD PTR [r12+0x150],xmm2
    7f716ee0388d:	movdqa xmm0,xmm9
    7f716ee03892:	movdqa xmm1,xmm3
    7f716ee03896:	addpd  xmm0,xmm1
    7f716ee0389a:	movdqa xmm14,xmm0
    7f716ee0389f:	movdqu xmm15,XMMWORD PTR [rip+0x7da8]        # 0x7f716ee0b650
    7f716ee038a8:	pand   xmm14,xmm15
    7f716ee038ad:	movdqu xmm15,XMMWORD PTR [rip+0x7daa]        # 0x7f716ee0b660
    7f716ee038b6:	pcmpeqq xmm14,xmm15
    7f716ee038bc:	movdqa xmm15,xmm0
    7f716ee038c1:	cmpunordpd xmm15,xmm0
    7f716ee038c7:	por    xmm14,xmm15
    7f716ee038cc:	pmovmskb ecx,xmm14
    7f716ee038d1:	jrcxz  0x7f716ee038d8
    7f716ee038d3:	jmp    0x7f716ee04771
    7f716ee038d8:	movdqa xmm5,xmm0
    7f716ee038dc:	movdqu XMMWORD PTR [r12+0x160],xmm5
    7f716ee038e6:	movdqa xmm0,xmm12
    7f716ee038eb:	movdqa xmm1,xmm10
    7f716ee038f0:	addpd  xmm0,xmm1
    7f716ee038f4:	movdqa xmm14,xmm0
    7f716ee038f9:	movdqu xmm15,XMMWORD PTR [rip+0x7d4e]        # 0x7f716ee0b650
    7f716ee03902:	pand   xmm14,xmm15
    7f716ee03907:	movdqu xmm15,XMMWORD PTR [rip+0x7d50]        # 0x7f716ee0b660
    7f716ee03910:	pcmpeqq xmm14,xmm15
    7f716ee03916:	movdqa xmm15,xmm0
    7f716ee0391b:	cmpunordpd xmm15,xmm0
    7f716ee03921:	por    xmm14,xmm15
    7f716ee03926:	pmovmskb ecx,xmm14
    7f716ee0392b:	jrcxz  0x7f716ee03932
    7f716ee0392d:	jmp    0x7f716ee04796
    7f716ee03932:	movdqa xmm3,xmm0
    7f716ee03936:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7f716ee03940:	mov    r13,r15
    7f716ee03943:	add    r13,0x10
    7f716ee03947:	movdqu XMMWORD PTR [r15],xmm4
    7f716ee0394c:	mov    r14d,0x0
    7f716ee03952:	mov    DWORD PTR [r12+0x32c],r14d
    7f716ee0395a:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7f716ee03960:	add    r15,0x20
    7f716ee03964:	mov    r13,r15
    7f716ee03967:	add    r13,0x10
    7f716ee0396b:	movdqu XMMWORD PTR [r15],xmm5
    7f716ee03970:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7f716ee03976:	mov    rcx,QWORD PTR [r12+0x380]
    7f716ee0397e:	jrcxz  0x7f716ee03985
    7f716ee03980:	jmp    0x7f716ee0ad1d
    7f716ee03985:	cmp    BYTE PTR [rsp+0x8],0x0
    7f716ee0398a:	jne    0x7f716ee01c55
    7f716ee03990:	jmp    0x7f716ee03995
    7f716ee03995:	mov    r13d,DWORD PTR [r12+0x48]
    7f716ee0399a:	add    r13d,0x1
    7f716ee0399e:	mov    QWORD PTR [r12+0x48],r13
    7f716ee039a3:	sub    r13d,0x1f4
    7f716ee039aa:	mov    rcx,QWORD PTR [r12+0x380]
    7f716ee039b2:	jrcxz  0x7f716ee039b9
    7f716ee039b4:	jmp    0x7f716ee0ada2
    7f716ee039b9:	jne    0x7f716ee01c37
    7f716ee039bf:	mov    r11,rax
    7f716ee039c2:	lahf
    7f716ee039c3:	seto   al
    7f716ee039c6:	mov    WORD PTR [rsp],ax
    7f716ee039ca:	mov    rax,r11
    7f716ee039cd:	jmp    0x7f716ee039d2
    7f716ee039d2:	mov    r13d,0x430000
    7f716ee039d8:	mov    QWORD PTR [r12+0x40],r13
    7f716ee039dd:	mov    r13d,0x0
    7f716ee039e3:	mov    QWORD PTR [r12+0x48],r13
    7f716ee039e8:	mov    r13d,0x430cc0
    7f716ee039ee:	mov    r14,QWORD PTR [r13+0x0]
    7f716ee039f2:	mov    r13d,0x0
    7f716ee039f8:	mov    QWORD PTR [r12+0x110],r14
    7f716ee03a00:	mov    QWORD PTR [r12+0x118],r13
    7f716ee03a08:	jmp    0x7f716ee03a0d
    7f716ee03a0d:	mov    r13,QWORD PTR [r12+0x48]
    7f716ee03a12:	mov    r14,QWORD PTR [r12+0x50]
    7f716ee03a17:	add    r14,r13
    7f716ee03a1a:	movdqu xmm2,XMMWORD PTR [r14]
    7f716ee03a1f:	movdqu XMMWORD PTR [r12+0x120],xmm2
    7f716ee03a29:	add    r13,0x10
    7f716ee03a2d:	mov    QWORD PTR [r12+0x48],r13
    7f716ee03a32:	sub    r13,0x200
    7f716ee03a39:	mov    r13,QWORD PTR [r12+0x128]
    7f716ee03a41:	mov    r14d,0x0
    7f716ee03a47:	mov    QWORD PTR [r12+0x130],r13
    7f716ee03a4f:	mov    QWORD PTR [r12+0x138],r14
    7f716ee03a57:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    7f716ee03a61:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    7f716ee03a6b:	movdqa xmm0,xmm2
    7f716ee03a6f:	movdqa xmm1,xmm3
    7f716ee03a73:	movq   xmm0,xmm0
    7f716ee03a77:	movq   xmm1,xmm1
    7f716ee03a7b:	addsd  xmm0,xmm1
    7f716ee03a7f:	movdqa xmm14,xmm0
    7f716ee03a84:	movdqu xmm15,XMMWORD PTR [rip+0x7bc3]        # 0x7f716ee0b650
    7f716ee03a8d:	pand   xmm14,xmm15
    7f716ee03a92:	movdqu xmm15,XMMWORD PTR [rip+0x7bc5]        # 0x7f716ee0b660
    7f716ee03a9b:	pcmpeqq xmm14,xmm15
    7f716ee03aa1:	movdqa xmm15,xmm0
    7f716ee03aa6:	cmpunordpd xmm15,xmm0
    7f716ee03aac:	por    xmm14,xmm15
    7f716ee03ab1:	pmovmskb ecx,xmm14
    7f716ee03ab6:	jrcxz  0x7f716ee03abd
    7f716ee03ab8:	jmp    0x7f716ee047bc
    7f716ee03abd:	movdqa xmm4,xmm0
    7f716ee03ac1:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    7f716ee03acb:	movdqa xmm0,xmm4
    7f716ee03acf:	movdqa xmm1,xmm2
    7f716ee03ad3:	movq   xmm0,xmm0
    7f716ee03ad7:	movq   xmm1,xmm1
    7f716ee03adb:	addsd  xmm0,xmm1
    7f716ee03adf:	movdqa xmm14,xmm0
    7f716ee03ae4:	movdqu xmm15,XMMWORD PTR [rip+0x7b63]        # 0x7f716ee0b650
    7f716ee03aed:	pand   xmm14,xmm15
    7f716ee03af2:	movdqu xmm15,XMMWORD PTR [rip+0x7b65]        # 0x7f716ee0b660
    7f716ee03afb:	pcmpeqq xmm14,xmm15
    7f716ee03b01:	movdqa xmm15,xmm0
    7f716ee03b06:	cmpunordpd xmm15,xmm0
    7f716ee03b0c:	por    xmm14,xmm15
    7f716ee03b11:	pmovmskb ecx,xmm14
    7f716ee03b16:	jrcxz  0x7f716ee03b1d
    7f716ee03b18:	jmp    0x7f716ee047fb
    7f716ee03b1d:	movdqa xmm3,xmm0
    7f716ee03b21:	movdqu XMMWORD PTR [r12+0x110],xmm3
    7f716ee03b2b:	mov    rcx,QWORD PTR [r12+0x380]
    7f716ee03b33:	jrcxz  0x7f716ee03b3a
    7f716ee03b35:	jmp    0x7f716ee0ae36
    7f716ee03b3a:	jne    0x7f716ee03b53
    7f716ee03b40:	mov    r11,rax
    7f716ee03b43:	lahf
    7f716ee03b44:	seto   al
    7f716ee03b47:	mov    WORD PTR [rsp],ax
    7f716ee03b4b:	mov    rax,r11
    7f716ee03b4e:	jmp    0x7f716ee03b66
    7f716ee03b53:	mov    r11,rax
    7f716ee03b56:	lahf
    7f716ee03b57:	seto   al
    7f716ee03b5a:	mov    WORD PTR [rsp],ax
    7f716ee03b5e:	mov    rax,r11
    7f716ee03b61:	jmp    0x7f716ee03a0d
    7f716ee03b66:	mov    r13,QWORD PTR [r12+0xf8]
    7f716ee03b6e:	mov    r14,r13
    7f716ee03b71:	add    r14,0x1d0
    7f716ee03b78:	mov    r15,r14
    7f716ee03b7b:	add    r15,0x8
    7f716ee03b7f:	mov    rbp,QWORD PTR [r14]
    7f716ee03b82:	mov    r14,QWORD PTR [r15]
    7f716ee03b85:	mov    QWORD PTR [r12+0xa0],rbp
    7f716ee03b8d:	mov    QWORD PTR [r12+0x98],r14
    7f716ee03b95:	mov    r14,QWORD PTR [r12+0x40]
    7f716ee03b9a:	add    r14,0xcc0
    7f716ee03ba1:	mov    r15,QWORD PTR [r12+0x110]
    7f716ee03ba9:	mov    QWORD PTR [r14],r15
    7f716ee03bac:	mov    r14d,0x0
    7f716ee03bb2:	mov    DWORD PTR [r12+0x32c],r14d
    7f716ee03bba:	mov    r14,r13
    7f716ee03bbd:	add    r14,0x1c0
    7f716ee03bc4:	mov    r15,r14
    7f716ee03bc7:	add    r15,0x8
    7f716ee03bcb:	mov    rbp,QWORD PTR [r14]
    7f716ee03bce:	mov    r14,QWORD PTR [r15]
    7f716ee03bd1:	mov    QWORD PTR [r12+0xe8],rbp
    7f716ee03bd9:	mov    QWORD PTR [r12+0xf0],r14
    7f716ee03be1:	mov    r14,r13
    7f716ee03be4:	add    r14,0x1b0
    7f716ee03beb:	mov    r15,r14
    7f716ee03bee:	add    r15,0x8
    7f716ee03bf2:	mov    rbp,QWORD PTR [r14]
    7f716ee03bf5:	mov    r14,QWORD PTR [r15]
    7f716ee03bf8:	mov    r15d,0x0
    7f716ee03bfe:	mov    QWORD PTR [r12+0x1a0],rbp
    7f716ee03c06:	mov    QWORD PTR [r12+0x1a8],r15
    7f716ee03c0e:	mov    r15d,0x0
    7f716ee03c14:	mov    QWORD PTR [r12+0x190],r14
    7f716ee03c1c:	mov    QWORD PTR [r12+0x198],r15
    7f716ee03c24:	mov    r14,r13
    7f716ee03c27:	add    r14,0x1a0
    7f716ee03c2e:	mov    r15,r14
    7f716ee03c31:	add    r15,0x8
    7f716ee03c35:	mov    rbp,QWORD PTR [r14]
    7f716ee03c38:	mov    r14,QWORD PTR [r15]
    7f716ee03c3b:	mov    r15d,0x0
    7f716ee03c41:	mov    QWORD PTR [r12+0x1c0],rbp
    7f716ee03c49:	mov    QWORD PTR [r12+0x1c8],r15
    7f716ee03c51:	mov    r15d,0x0
    7f716ee03c57:	mov    QWORD PTR [r12+0x1b0],r14
    7f716ee03c5f:	mov    QWORD PTR [r12+0x1b8],r15
    7f716ee03c67:	mov    r14,r13
    7f716ee03c6a:	add    r14,0x190
    7f716ee03c71:	mov    r15,r14
    7f716ee03c74:	add    r15,0x8
    7f716ee03c78:	mov    rbp,QWORD PTR [r14]
    7f716ee03c7b:	mov    r14,QWORD PTR [r15]
    7f716ee03c7e:	mov    r15d,0x0
    7f716ee03c84:	mov    QWORD PTR [r12+0x1e0],rbp
    7f716ee03c8c:	mov    QWORD PTR [r12+0x1e8],r15
    7f716ee03c94:	mov    r15d,0x0
    7f716ee03c9a:	mov    QWORD PTR [r12+0x1d0],r14
    7f716ee03ca2:	mov    QWORD PTR [r12+0x1d8],r15
    7f716ee03caa:	mov    r14,r13
    7f716ee03cad:	add    r14,0x180
    7f716ee03cb4:	mov    r15,r14
    7f716ee03cb7:	add    r15,0x8
    7f716ee03cbb:	mov    rbp,QWORD PTR [r14]
    7f716ee03cbe:	mov    r14,QWORD PTR [r15]
    7f716ee03cc1:	mov    r15d,0x0
    7f716ee03cc7:	mov    QWORD PTR [r12+0x200],rbp
    7f716ee03ccf:	mov    QWORD PTR [r12+0x208],r15
    7f716ee03cd7:	mov    r15d,0x0
    7f716ee03cdd:	mov    QWORD PTR [r12+0x1f0],r14
    7f716ee03ce5:	mov    QWORD PTR [r12+0x1f8],r15
    7f716ee03ced:	add    r13,0x1e0
    7f716ee03cf4:	mov    QWORD PTR [r12+0xf8],r13
    7f716ee03cfc:	mov    rcx,QWORD PTR [r12+0x380]
    7f716ee03d04:	jrcxz  0x7f716ee03d0b
    7f716ee03d06:	jmp    0x7f716ee0aeca
    7f716ee03d0b:	mov    r13,QWORD PTR [r12+0xf0]
    7f716ee03d13:	mov    QWORD PTR [r12+0x100],r13
    7f716ee03d1b:	mov    r11,QWORD PTR [rsp]
    7f716ee03d1f:	mov    QWORD PTR [r12+0x398],r11
    7f716ee03d27:	mov    rdi,QWORD PTR [r12+0x100]
    7f716ee03d2f:	add    rsp,0x150
    7f716ee03d36:	movabs r11,0x5fdfb8bf7940
    7f716ee03d40:	jmp    r11
    7f716ee03d43:	mov    r13d,DWORD PTR [r12+0x98]
    7f716ee03d4b:	mov    r14d,DWORD PTR [r12]
    7f716ee03d4f:	add    r14d,r13d
    7f716ee03d52:	mov    QWORD PTR [r12],r14
    7f716ee03d56:	mov    r13d,0x4103f8
    7f716ee03d5c:	mov    QWORD PTR [r12+0xf0],r13
    7f716ee03d64:	mov    r13d,0x4109a4
    7f716ee03d6a:	mov    QWORD PTR [r12+0x100],r13
    7f716ee03d72:	mov    r11,QWORD PTR [rsp]
    7f716ee03d76:	mov    QWORD PTR [r12+0x398],r11
    7f716ee03d7e:	mov    edi,0x4109a4
    7f716ee03d83:	mov    QWORD PTR [r12+0x100],rdi
    7f716ee03d8b:	add    rsp,0x150
    7f716ee03d92:	nop    WORD PTR [rax+rax*1+0x0]
    7f716ee03d98:	jmp    QWORD PTR [rip+0x2]        # 0x7f716ee03da0
    7f716ee03d9e:	xchg   ax,ax
    7f716ee03da0:	rex (bad)
    7f716ee03da2:	loopne 0x7f716ee03e12
    7f716ee03da4:	jno    0x7f716ee03e25
    7f716ee03da6:	add    BYTE PTR [rax],al
    7f716ee03da8:	mov    al,0x3d
    7f716ee03daa:	loopne 0x7f716ee03e1a
    7f716ee03dac:	jno    0x7f716ee03e2d
    7f716ee03dae:	add    BYTE PTR [rax],al
    7f716ee03db0:	movabs r11,0x5fdfb8bf7940
    7f716ee03dba:	jmp    r11
    7f716ee03dbd:	movdqa xmm0,xmm2
    7f716ee03dc1:	movdqa xmm1,xmm3
    7f716ee03dc5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee03dce:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee03dd7:	call   0x7f716ee04840
    7f716ee03ddc:	jmp    0x7f716ee0174c
    7f716ee03de1:	movdqa xmm0,xmm2
    7f716ee03de5:	movdqa xmm1,xmm3
    7f716ee03de9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee03df2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee03dfb:	call   0x7f716ee04840
    7f716ee03e00:	jmp    0x7f716ee017d8
    7f716ee03e05:	movdqa xmm0,xmm9
    7f716ee03e0a:	movdqa xmm1,xmm2
    7f716ee03e0e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee03e17:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee03e20:	call   0x7f716ee04910
    7f716ee03e25:	jmp    0x7f716ee01e73
    7f716ee03e2a:	movdqa xmm0,xmm8
    7f716ee03e2f:	movdqa xmm1,xmm2
    7f716ee03e33:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee03e3c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee03e45:	call   0x7f716ee04a20
    7f716ee03e4a:	jmp    0x7f716ee01ed2
    7f716ee03e4f:	movdqa xmm0,xmm9
    7f716ee03e54:	movdqa xmm1,xmm7
    7f716ee03e58:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee03e61:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee03e6a:	call   0x7f716ee04b40
    7f716ee03e6f:	jmp    0x7f716ee01f47
    7f716ee03e74:	movdqa xmm0,xmm9
    7f716ee03e79:	movdqa xmm1,xmm6
    7f716ee03e7d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee03e86:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee03e8f:	call   0x7f716ee04c60
    7f716ee03e94:	jmp    0x7f716ee01f97
    7f716ee03e99:	movdqa xmm0,xmm9
    7f716ee03e9e:	movdqa xmm1,xmm6
    7f716ee03ea2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee03eab:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee03eb4:	call   0x7f716ee04d80
    7f716ee03eb9:	jmp    0x7f716ee01ff0
    7f716ee03ebe:	movdqa xmm0,xmm9
    7f716ee03ec3:	movdqa xmm1,xmm2
    7f716ee03ec7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee03ed0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee03ed9:	call   0x7f716ee04eb0
    7f716ee03ede:	jmp    0x7f716ee02091
    7f716ee03ee3:	mov    r11,rax
    7f716ee03ee6:	lahf
    7f716ee03ee7:	seto   al
    7f716ee03eea:	mov    WORD PTR [rsp],ax
    7f716ee03eee:	mov    rax,r11
    7f716ee03ef1:	movdqa xmm0,xmm10
    7f716ee03ef6:	movdqa xmm1,xmm9
    7f716ee03efb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee03f04:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee03f0d:	call   0x7f716ee04ff0
    7f716ee03f12:	mov    r11,rax
    7f716ee03f15:	movzx  eax,WORD PTR [rsp]
    7f716ee03f19:	add    al,0x7f
    7f716ee03f1b:	sahf
    7f716ee03f1c:	mov    rax,r11
    7f716ee03f1f:	jmp    0x7f716ee020fc
    7f716ee03f24:	mov    r11,rax
    7f716ee03f27:	lahf
    7f716ee03f28:	seto   al
    7f716ee03f2b:	mov    WORD PTR [rsp],ax
    7f716ee03f2f:	mov    rax,r11
    7f716ee03f32:	movdqa xmm0,xmm8
    7f716ee03f37:	movdqa xmm1,xmm10
    7f716ee03f3c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee03f45:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee03f4e:	call   0x7f716ee04ff0
    7f716ee03f53:	mov    r11,rax
    7f716ee03f56:	movzx  eax,WORD PTR [rsp]
    7f716ee03f5a:	add    al,0x7f
    7f716ee03f5c:	sahf
    7f716ee03f5d:	mov    rax,r11
    7f716ee03f60:	jmp    0x7f716ee0215c
    7f716ee03f65:	mov    r11,rax
    7f716ee03f68:	lahf
    7f716ee03f69:	seto   al
    7f716ee03f6c:	mov    WORD PTR [rsp],ax
    7f716ee03f70:	mov    rax,r11
    7f716ee03f73:	movdqa xmm0,xmm7
    7f716ee03f77:	movdqa xmm1,xmm10
    7f716ee03f7c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee03f85:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee03f8e:	call   0x7f716ee051c0
    7f716ee03f93:	mov    r11,rax
    7f716ee03f96:	movzx  eax,WORD PTR [rsp]
    7f716ee03f9a:	add    al,0x7f
    7f716ee03f9c:	sahf
    7f716ee03f9d:	mov    rax,r11
    7f716ee03fa0:	jmp    0x7f716ee021b5
    7f716ee03fa5:	movdqa xmm0,xmm12
    7f716ee03faa:	movdqa xmm1,xmm9
    7f716ee03faf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee03fb8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee03fc1:	call   0x7f716ee05380
    7f716ee03fc6:	jmp    0x7f716ee0232d
    7f716ee03fcb:	movdqa xmm0,xmm6
    7f716ee03fcf:	movdqa xmm1,xmm4
    7f716ee03fd3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee03fdc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee03fe5:	call   0x7f716ee05580
    7f716ee03fea:	jmp    0x7f716ee0239b
    7f716ee03fef:	movdqa xmm0,xmm8
    7f716ee03ff4:	movdqa xmm1,xmm11
    7f716ee03ff9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04002:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee0400b:	call   0x7f716ee05770
    7f716ee04010:	jmp    0x7f716ee023f6
    7f716ee04015:	movdqa xmm0,xmm5
    7f716ee04019:	movdqa xmm1,xmm2
    7f716ee0401d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04026:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee0402f:	call   0x7f716ee05960
    7f716ee04034:	jmp    0x7f716ee02453
    7f716ee04039:	movdqa xmm0,xmm9
    7f716ee0403e:	movdqa xmm1,xmm5
    7f716ee04042:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0404b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04054:	call   0x7f716ee05b30
    7f716ee04059:	jmp    0x7f716ee024bb
    7f716ee0405e:	movdqa xmm0,xmm13
    7f716ee04063:	movdqa xmm1,xmm2
    7f716ee04067:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04070:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04079:	call   0x7f716ee05d10
    7f716ee0407e:	jmp    0x7f716ee02534
    7f716ee04083:	movdqa xmm0,xmm9
    7f716ee04088:	movdqa xmm1,xmm5
    7f716ee0408c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04095:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee0409e:	call   0x7f716ee05f00
    7f716ee040a3:	jmp    0x7f716ee025c1
    7f716ee040a8:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7f716ee040b2:	movdqa xmm1,xmm6
    7f716ee040b6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee040bf:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee040c8:	call   0x7f716ee060c0
    7f716ee040cd:	jmp    0x7f716ee026b6
    7f716ee040d2:	movdqa xmm0,xmm9
    7f716ee040d7:	movdqa xmm1,xmm5
    7f716ee040db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee040e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee040ed:	call   0x7f716ee062a0
    7f716ee040f2:	jmp    0x7f716ee02714
    7f716ee040f7:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7f716ee04101:	movdqa xmm1,xmm11
    7f716ee04106:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0410f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04118:	call   0x7f716ee06480
    7f716ee0411d:	jmp    0x7f716ee0278d
    7f716ee04122:	movdqa xmm0,xmm12
    7f716ee04127:	movdqa xmm1,xmm8
    7f716ee0412c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04135:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee0413e:	call   0x7f716ee06670
    7f716ee04143:	jmp    0x7f716ee027e8
    7f716ee04148:	movdqa xmm0,xmm9
    7f716ee0414d:	movdqa xmm1,xmm5
    7f716ee04151:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0415a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04163:	call   0x7f716ee06860
    7f716ee04168:	jmp    0x7f716ee02869
    7f716ee0416d:	movdqa xmm0,xmm4
    7f716ee04171:	movdqa xmm1,xmm2
    7f716ee04175:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0417e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04187:	call   0x7f716ee06a40
    7f716ee0418c:	jmp    0x7f716ee028dc
    7f716ee04191:	movdqa xmm0,xmm13
    7f716ee04196:	movdqa xmm1,xmm2
    7f716ee0419a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee041a3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee041ac:	call   0x7f716ee06c20
    7f716ee041b1:	jmp    0x7f716ee02945
    7f716ee041b6:	movdqa xmm0,xmm5
    7f716ee041ba:	movdqa xmm1,xmm2
    7f716ee041be:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee041c7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee041d0:	call   0x7f716ee06e00
    7f716ee041d5:	jmp    0x7f716ee029bd
    7f716ee041da:	movdqa xmm0,xmm3
    7f716ee041de:	movdqa xmm1,xmm6
    7f716ee041e2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee041eb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee041f4:	call   0x7f716ee06fe0
    7f716ee041f9:	jmp    0x7f716ee02a30
    7f716ee041fe:	movdqa xmm0,xmm5
    7f716ee04202:	movdqa xmm1,xmm2
    7f716ee04206:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0420f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04218:	call   0x7f716ee071d0
    7f716ee0421d:	jmp    0x7f716ee02ad2
    7f716ee04222:	movdqa xmm0,xmm10
    7f716ee04227:	movdqa xmm1,xmm12
    7f716ee0422c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04235:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee0423e:	call   0x7f716ee073c0
    7f716ee04243:	jmp    0x7f716ee02b43
    7f716ee04248:	movdqa xmm0,xmm7
    7f716ee0424c:	movdqa xmm1,xmm2
    7f716ee04250:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04259:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04262:	call   0x7f716ee075c0
    7f716ee04267:	jmp    0x7f716ee02b96
    7f716ee0426c:	movdqa xmm0,xmm11
    7f716ee04271:	movdqa xmm1,xmm13
    7f716ee04276:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0427f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04288:	call   0x7f716ee077a0
    7f716ee0428d:	jmp    0x7f716ee02be7
    7f716ee04292:	movdqa xmm0,xmm5
    7f716ee04296:	movdqa xmm1,xmm7
    7f716ee0429a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee042a3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee042ac:	call   0x7f716ee07980
    7f716ee042b1:	jmp    0x7f716ee02c44
    7f716ee042b6:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    7f716ee042c0:	movdqa xmm1,xmm7
    7f716ee042c4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee042cd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee042d6:	call   0x7f716ee07b50
    7f716ee042db:	jmp    0x7f716ee02c9e
    7f716ee042e0:	movdqa xmm0,xmm8
    7f716ee042e5:	movdqa xmm1,xmm4
    7f716ee042e9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee042f2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee042fb:	call   0x7f716ee07d20
    7f716ee04300:	jmp    0x7f716ee02ced
    7f716ee04305:	movdqa xmm0,xmm9
    7f716ee0430a:	movdqa xmm1,xmm6
    7f716ee0430e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04317:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04320:	call   0x7f716ee07f00
    7f716ee04325:	jmp    0x7f716ee02d47
    7f716ee0432a:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    7f716ee04334:	movdqa xmm1,xmm7
    7f716ee04338:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04341:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee0434a:	call   0x7f716ee080d0
    7f716ee0434f:	jmp    0x7f716ee02daa
    7f716ee04354:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7f716ee0435e:	movdqa xmm1,xmm7
    7f716ee04362:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0436b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04374:	call   0x7f716ee08290
    7f716ee04379:	jmp    0x7f716ee02e03
    7f716ee0437e:	movdqa xmm0,xmm3
    7f716ee04382:	movdqa xmm1,xmm10
    7f716ee04387:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04390:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04399:	call   0x7f716ee08460
    7f716ee0439e:	jmp    0x7f716ee02e5d
    7f716ee043a3:	movdqa xmm0,xmm2
    7f716ee043a7:	movdqa xmm1,xmm11
    7f716ee043ac:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee043b5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee043be:	call   0x7f716ee08630
    7f716ee043c3:	jmp    0x7f716ee02eb6
    7f716ee043c8:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7f716ee043d2:	movdqa xmm1,xmm2
    7f716ee043d6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee043df:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee043e8:	call   0x7f716ee087f0
    7f716ee043ed:	jmp    0x7f716ee02f23
    7f716ee043f2:	movdqa xmm0,xmm4
    7f716ee043f6:	movdqa xmm1,xmm5
    7f716ee043fa:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04403:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee0440c:	call   0x7f716ee089a0
    7f716ee04411:	jmp    0x7f716ee02f7c
    7f716ee04416:	movdqa xmm0,xmm12
    7f716ee0441b:	movdqa xmm1,xmm6
    7f716ee0441f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04428:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04431:	call   0x7f716ee08b70
    7f716ee04436:	jmp    0x7f716ee02fd6
    7f716ee0443b:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    7f716ee04445:	movdqa xmm1,xmm2
    7f716ee04449:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04452:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee0445b:	call   0x7f716ee07980
    7f716ee04460:	jmp    0x7f716ee030b6
    7f716ee04465:	movdqa xmm0,xmm7
    7f716ee04469:	movdqa xmm1,xmm8
    7f716ee0446e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04477:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04480:	call   0x7f716ee07d20
    7f716ee04485:	jmp    0x7f716ee03106
    7f716ee0448a:	movdqa xmm0,xmm3
    7f716ee0448e:	movdqa xmm1,xmm9
    7f716ee04493:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0449c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee044a5:	call   0x7f716ee08d30
    7f716ee044aa:	jmp    0x7f716ee03156
    7f716ee044af:	movdqa xmm0,xmm6
    7f716ee044b3:	movdqa xmm1,xmm2
    7f716ee044b7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee044c0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee044c9:	call   0x7f716ee08f00
    7f716ee044ce:	jmp    0x7f716ee031b3
    7f716ee044d3:	movdqa xmm0,xmm6
    7f716ee044d7:	movdqa xmm1,xmm2
    7f716ee044db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee044e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee044ed:	call   0x7f716ee08290
    7f716ee044f2:	jmp    0x7f716ee0321a
    7f716ee044f7:	movdqa xmm0,xmm5
    7f716ee044fb:	movdqa xmm1,xmm2
    7f716ee044ff:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04508:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04511:	call   0x7f716ee090c0
    7f716ee04516:	jmp    0x7f716ee03278
    7f716ee0451b:	movdqa xmm0,xmm10
    7f716ee04520:	movdqa xmm1,xmm11
    7f716ee04525:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0452e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04537:	call   0x7f716ee09290
    7f716ee0453c:	jmp    0x7f716ee032d2
    7f716ee04541:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7f716ee0454b:	movdqa xmm1,xmm2
    7f716ee0454f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04558:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04561:	call   0x7f716ee087f0
    7f716ee04566:	jmp    0x7f716ee03335
    7f716ee0456b:	movdqa xmm0,xmm4
    7f716ee0456f:	movdqa xmm1,xmm3
    7f716ee04573:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0457c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04585:	call   0x7f716ee089a0
    7f716ee0458a:	jmp    0x7f716ee0338e
    7f716ee0458f:	movdqa xmm0,xmm3
    7f716ee04593:	movdqa xmm1,xmm2
    7f716ee04597:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee045a0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee045a9:	call   0x7f716ee09460
    7f716ee045ae:	jmp    0x7f716ee033f6
    7f716ee045b3:	movdqa xmm0,xmm12
    7f716ee045b8:	movdqa xmm1,xmm8
    7f716ee045bd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee045c6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee045cf:	call   0x7f716ee09630
    7f716ee045d4:	jmp    0x7f716ee03450
    7f716ee045d9:	movdqa xmm0,xmm8
    7f716ee045de:	movdqa xmm1,xmm2
    7f716ee045e2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee045eb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee045f4:	call   0x7f716ee07980
    7f716ee045f9:	jmp    0x7f716ee034b8
    7f716ee045fe:	movdqa xmm0,xmm7
    7f716ee04602:	movdqa xmm1,xmm6
    7f716ee04606:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0460f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04618:	call   0x7f716ee09800
    7f716ee0461d:	jmp    0x7f716ee03511
    7f716ee04622:	movdqa xmm0,xmm5
    7f716ee04626:	movdqa xmm1,xmm9
    7f716ee0462b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04634:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee0463d:	call   0x7f716ee099c0
    7f716ee04642:	jmp    0x7f716ee03581
    7f716ee04647:	movdqa xmm0,xmm6
    7f716ee0464b:	movdqa xmm1,xmm5
    7f716ee0464f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04658:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04661:	call   0x7f716ee09b80
    7f716ee04666:	jmp    0x7f716ee035e8
    7f716ee0466b:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7f716ee04675:	movdqa xmm1,xmm5
    7f716ee04679:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04682:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee0468b:	call   0x7f716ee09d30
    7f716ee04690:	jmp    0x7f716ee0364c
    7f716ee04695:	movdqa xmm0,xmm10
    7f716ee0469a:	movdqa xmm1,xmm4
    7f716ee0469e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee046a7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee046b0:	call   0x7f716ee09ef0
    7f716ee046b5:	jmp    0x7f716ee036a5
    7f716ee046ba:	movdqa xmm0,xmm3
    7f716ee046be:	movdqa xmm1,xmm11
    7f716ee046c3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee046cc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee046d5:	call   0x7f716ee07d20
    7f716ee046da:	jmp    0x7f716ee0371b
    7f716ee046df:	movdqa xmm0,xmm10
    7f716ee046e4:	movdqa xmm1,xmm5
    7f716ee046e8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee046f1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee046fa:	call   0x7f716ee0a0c0
    7f716ee046ff:	jmp    0x7f716ee0377a
    7f716ee04704:	movdqa xmm0,xmm4
    7f716ee04708:	movdqa xmm1,xmm5
    7f716ee0470c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04715:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee0471e:	call   0x7f716ee0a290
    7f716ee04723:	jmp    0x7f716ee037d7
    7f716ee04728:	movdqa xmm0,xmm2
    7f716ee0472c:	movdqa xmm1,xmm8
    7f716ee04731:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0473a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04743:	call   0x7f716ee08b70
    7f716ee04748:	jmp    0x7f716ee03827
    7f716ee0474d:	movdqa xmm0,xmm7
    7f716ee04751:	movdqa xmm1,xmm6
    7f716ee04755:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0475e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04767:	call   0x7f716ee0a460
    7f716ee0476c:	jmp    0x7f716ee0387f
    7f716ee04771:	movdqa xmm0,xmm9
    7f716ee04776:	movdqa xmm1,xmm3
    7f716ee0477a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee04783:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee0478c:	call   0x7f716ee0a610
    7f716ee04791:	jmp    0x7f716ee038d8
    7f716ee04796:	movdqa xmm0,xmm12
    7f716ee0479b:	movdqa xmm1,xmm10
    7f716ee047a0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee047a9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee047b2:	call   0x7f716ee0a7b0
    7f716ee047b7:	jmp    0x7f716ee03932
    7f716ee047bc:	mov    r11,rax
    7f716ee047bf:	lahf
    7f716ee047c0:	seto   al
    7f716ee047c3:	mov    WORD PTR [rsp],ax
    7f716ee047c7:	mov    rax,r11
    7f716ee047ca:	movdqa xmm0,xmm2
    7f716ee047ce:	movdqa xmm1,xmm3
    7f716ee047d2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee047db:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee047e4:	call   0x7f716ee0a940
    7f716ee047e9:	mov    r11,rax
    7f716ee047ec:	movzx  eax,WORD PTR [rsp]
    7f716ee047f0:	add    al,0x7f
    7f716ee047f2:	sahf
    7f716ee047f3:	mov    rax,r11
    7f716ee047f6:	jmp    0x7f716ee03abd
    7f716ee047fb:	mov    r11,rax
    7f716ee047fe:	lahf
    7f716ee047ff:	seto   al
    7f716ee04802:	mov    WORD PTR [rsp],ax
    7f716ee04806:	mov    rax,r11
    7f716ee04809:	movdqa xmm0,xmm4
    7f716ee0480d:	movdqa xmm1,xmm2
    7f716ee04811:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7f716ee0481a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7f716ee04823:	call   0x7f716ee0aaa0
    7f716ee04828:	mov    r11,rax
    7f716ee0482b:	movzx  eax,WORD PTR [rsp]
    7f716ee0482f:	add    al,0x7f
    7f716ee04831:	sahf
    7f716ee04832:	mov    rax,r11
    7f716ee04835:	jmp    0x7f716ee03b1d
    7f716ee0483a:	nop    WORD PTR [rax+rax*1+0x0]
    7f716ee04840:	sub    rsp,0x8
    7f716ee04844:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee04850:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee04856:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0485c:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee04864:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0486a:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0486f:	test   r10d,0x3f
    7f716ee04876:	je     0x7f716ee0489b
    7f716ee0487c:	mov    r11d,r10d
    7f716ee0487f:	shr    r10d,1
    7f716ee04882:	and    r10d,0x1e
    7f716ee04886:	and    r11d,0x1
    7f716ee0488a:	or     r10d,r11d
    7f716ee0488d:	or     DWORD PTR [r12+0x314],r10d
    7f716ee04895:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0489b:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee048a1:	lea    rdi,[rsp+0x110]
    7f716ee048a9:	lea    rsi,[rsp+0xf0]
    7f716ee048b1:	lea    rdx,[rsp+0x100]
    7f716ee048b9:	mov    ecx,0x16
    7f716ee048be:	mov    r8d,0x0
    7f716ee048c4:	lea    r9,[r12+0x314]
    7f716ee048cc:	movabs r11,0x5fdfb8a5e650
    7f716ee048d6:	call   r11
    7f716ee048d9:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee048df:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee048e5:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee048eb:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee048f3:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee048ff:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee04908:	add    rsp,0x8
    7f716ee0490c:	ret
    7f716ee0490d:	nop    DWORD PTR [rax]
    7f716ee04910:	sub    rsp,0x8
    7f716ee04914:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee04920:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee04926:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee0492c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee04932:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee0493c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee04946:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0494e:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee04954:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee04959:	test   r10d,0x3f
    7f716ee04960:	je     0x7f716ee04985
    7f716ee04966:	mov    r11d,r10d
    7f716ee04969:	shr    r10d,1
    7f716ee0496c:	and    r10d,0x1e
    7f716ee04970:	and    r11d,0x1
    7f716ee04974:	or     r10d,r11d
    7f716ee04977:	or     DWORD PTR [r12+0x314],r10d
    7f716ee0497f:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee04985:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee0498b:	lea    rdi,[rsp+0x110]
    7f716ee04993:	lea    rsi,[rsp+0xf0]
    7f716ee0499b:	lea    rdx,[rsp+0x100]
    7f716ee049a3:	mov    ecx,0x16
    7f716ee049a8:	mov    r8d,0x0
    7f716ee049ae:	lea    r9,[r12+0x314]
    7f716ee049b6:	movabs r11,0x5fdfb8a5e650
    7f716ee049c0:	call   r11
    7f716ee049c3:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee049c9:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee049cf:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee049d5:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee049db:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee049e5:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee049ef:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee049f7:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee04a03:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee04a0c:	add    rsp,0x8
    7f716ee04a10:	ret
    7f716ee04a11:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee04a20:	sub    rsp,0x8
    7f716ee04a24:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee04a30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee04a36:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee04a3c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee04a42:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee04a4c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee04a56:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee04a60:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee04a68:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee04a6e:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee04a73:	test   r10d,0x3f
    7f716ee04a7a:	je     0x7f716ee04a9f
    7f716ee04a80:	mov    r11d,r10d
    7f716ee04a83:	shr    r10d,1
    7f716ee04a86:	and    r10d,0x1e
    7f716ee04a8a:	and    r11d,0x1
    7f716ee04a8e:	or     r10d,r11d
    7f716ee04a91:	or     DWORD PTR [r12+0x314],r10d
    7f716ee04a99:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee04a9f:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee04aa5:	lea    rdi,[rsp+0x110]
    7f716ee04aad:	lea    rsi,[rsp+0xf0]
    7f716ee04ab5:	lea    rdx,[rsp+0x100]
    7f716ee04abd:	mov    ecx,0x56
    7f716ee04ac2:	mov    r8d,0x0
    7f716ee04ac8:	lea    r9,[r12+0x314]
    7f716ee04ad0:	movabs r11,0x5fdfb8a5e650
    7f716ee04ada:	call   r11
    7f716ee04add:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee04ae3:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee04ae9:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee04aef:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee04af5:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee04aff:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee04b09:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee04b13:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee04b1b:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee04b27:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee04b30:	add    rsp,0x8
    7f716ee04b34:	ret
    7f716ee04b35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee04b40:	sub    rsp,0x8
    7f716ee04b44:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee04b50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee04b56:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee04b5c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee04b62:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee04b6c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee04b76:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee04b80:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee04b88:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee04b8e:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee04b93:	test   r10d,0x3f
    7f716ee04b9a:	je     0x7f716ee04bbf
    7f716ee04ba0:	mov    r11d,r10d
    7f716ee04ba3:	shr    r10d,1
    7f716ee04ba6:	and    r10d,0x1e
    7f716ee04baa:	and    r11d,0x1
    7f716ee04bae:	or     r10d,r11d
    7f716ee04bb1:	or     DWORD PTR [r12+0x314],r10d
    7f716ee04bb9:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee04bbf:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee04bc5:	lea    rdi,[rsp+0x110]
    7f716ee04bcd:	lea    rsi,[rsp+0xf0]
    7f716ee04bd5:	lea    rdx,[rsp+0x100]
    7f716ee04bdd:	mov    ecx,0x16
    7f716ee04be2:	mov    r8d,0x0
    7f716ee04be8:	lea    r9,[r12+0x314]
    7f716ee04bf0:	movabs r11,0x5fdfb8a5e650
    7f716ee04bfa:	call   r11
    7f716ee04bfd:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee04c03:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee04c09:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee04c0f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee04c15:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee04c1f:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee04c29:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee04c33:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee04c3b:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee04c47:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee04c50:	add    rsp,0x8
    7f716ee04c54:	ret
    7f716ee04c55:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee04c60:	sub    rsp,0x8
    7f716ee04c64:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee04c70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee04c76:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee04c7c:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee04c86:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee04c90:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee04c9a:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee04ca4:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee04cac:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee04cb2:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee04cb7:	test   r10d,0x3f
    7f716ee04cbe:	je     0x7f716ee04ce3
    7f716ee04cc4:	mov    r11d,r10d
    7f716ee04cc7:	shr    r10d,1
    7f716ee04cca:	and    r10d,0x1e
    7f716ee04cce:	and    r11d,0x1
    7f716ee04cd2:	or     r10d,r11d
    7f716ee04cd5:	or     DWORD PTR [r12+0x314],r10d
    7f716ee04cdd:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee04ce3:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee04ce9:	lea    rdi,[rsp+0x110]
    7f716ee04cf1:	lea    rsi,[rsp+0xf0]
    7f716ee04cf9:	lea    rdx,[rsp+0x100]
    7f716ee04d01:	mov    ecx,0x16
    7f716ee04d06:	mov    r8d,0x0
    7f716ee04d0c:	lea    r9,[r12+0x314]
    7f716ee04d14:	movabs r11,0x5fdfb8a5e650
    7f716ee04d1e:	call   r11
    7f716ee04d21:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee04d27:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee04d2d:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee04d33:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee04d3d:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee04d47:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee04d51:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee04d5b:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee04d63:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee04d6f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee04d78:	add    rsp,0x8
    7f716ee04d7c:	ret
    7f716ee04d7d:	nop    DWORD PTR [rax]
    7f716ee04d80:	sub    rsp,0x8
    7f716ee04d84:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee04d90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee04d96:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee04d9c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee04da2:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee04dac:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee04db6:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee04dc0:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee04dca:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee04dd2:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee04dd8:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee04ddd:	test   r10d,0x3f
    7f716ee04de4:	je     0x7f716ee04e09
    7f716ee04dea:	mov    r11d,r10d
    7f716ee04ded:	shr    r10d,1
    7f716ee04df0:	and    r10d,0x1e
    7f716ee04df4:	and    r11d,0x1
    7f716ee04df8:	or     r10d,r11d
    7f716ee04dfb:	or     DWORD PTR [r12+0x314],r10d
    7f716ee04e03:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee04e09:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee04e0f:	lea    rdi,[rsp+0x110]
    7f716ee04e17:	lea    rsi,[rsp+0xf0]
    7f716ee04e1f:	lea    rdx,[rsp+0x100]
    7f716ee04e27:	mov    ecx,0x16
    7f716ee04e2c:	mov    r8d,0x0
    7f716ee04e32:	lea    r9,[r12+0x314]
    7f716ee04e3a:	movabs r11,0x5fdfb8a5e650
    7f716ee04e44:	call   r11
    7f716ee04e47:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee04e4d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee04e53:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee04e59:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee04e5f:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee04e69:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee04e73:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee04e7d:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee04e87:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee04e8f:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee04e9b:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee04ea4:	add    rsp,0x8
    7f716ee04ea8:	ret
    7f716ee04ea9:	nop    DWORD PTR [rax+0x0]
    7f716ee04eb0:	sub    rsp,0x8
    7f716ee04eb4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee04ec0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee04ec6:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee04ecc:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee04ed6:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee04ee0:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee04eea:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee04ef4:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee04efe:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee04f06:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee04f0c:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee04f11:	test   r10d,0x3f
    7f716ee04f18:	je     0x7f716ee04f3d
    7f716ee04f1e:	mov    r11d,r10d
    7f716ee04f21:	shr    r10d,1
    7f716ee04f24:	and    r10d,0x1e
    7f716ee04f28:	and    r11d,0x1
    7f716ee04f2c:	or     r10d,r11d
    7f716ee04f2f:	or     DWORD PTR [r12+0x314],r10d
    7f716ee04f37:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee04f3d:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee04f43:	lea    rdi,[rsp+0x110]
    7f716ee04f4b:	lea    rsi,[rsp+0xf0]
    7f716ee04f53:	lea    rdx,[rsp+0x100]
    7f716ee04f5b:	mov    ecx,0x56
    7f716ee04f60:	mov    r8d,0x0
    7f716ee04f66:	lea    r9,[r12+0x314]
    7f716ee04f6e:	movabs r11,0x5fdfb8a5e650
    7f716ee04f78:	call   r11
    7f716ee04f7b:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee04f81:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee04f87:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee04f8d:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee04f97:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee04fa1:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee04fab:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee04fb5:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee04fbf:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee04fc7:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee04fd3:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee04fdc:	add    rsp,0x8
    7f716ee04fe0:	ret
    7f716ee04fe1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee04ff0:	sub    rsp,0x8
    7f716ee04ff4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee05000:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee05006:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee0500c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee05012:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee0501c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee05026:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee05030:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee0503a:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee05044:	push   rdx
    7f716ee05045:	push   rsi
    7f716ee05046:	push   r10
    7f716ee05048:	push   r11
    7f716ee0504a:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee0504f:	mov    r10d,edx
    7f716ee05052:	and    r10d,0xc000
    7f716ee05059:	shl    r10d,0x10
    7f716ee0505d:	mov    r11d,edx
    7f716ee05060:	and    r11d,0x100
    7f716ee05067:	shl    r11d,0x15
    7f716ee0506b:	or     r10d,r11d
    7f716ee0506e:	and    edx,0x1
    7f716ee05071:	shl    edx,0x1c
    7f716ee05074:	or     r10d,edx
    7f716ee05077:	btc    r10,0x1d
    7f716ee0507c:	mov    r11d,0xf0000000
    7f716ee05082:	and    r11,r10
    7f716ee05085:	movabs rsi,0xffffffff0fffffff
    7f716ee0508f:	and    rbx,rsi
    7f716ee05092:	or     rbx,r11
    7f716ee05095:	pop    r11
    7f716ee05097:	pop    r10
    7f716ee05099:	pop    rsi
    7f716ee0509a:	pop    rdx
    7f716ee0509b:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee050a3:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee050a9:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee050ae:	test   r10d,0x3f
    7f716ee050b5:	je     0x7f716ee050da
    7f716ee050bb:	mov    r11d,r10d
    7f716ee050be:	shr    r10d,1
    7f716ee050c1:	and    r10d,0x1e
    7f716ee050c5:	and    r11d,0x1
    7f716ee050c9:	or     r10d,r11d
    7f716ee050cc:	or     DWORD PTR [r12+0x314],r10d
    7f716ee050d4:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee050da:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee050e0:	lea    rdi,[rsp+0x110]
    7f716ee050e8:	lea    rsi,[rsp+0xf0]
    7f716ee050f0:	lea    rdx,[rsp+0x100]
    7f716ee050f8:	mov    ecx,0x14
    7f716ee050fd:	mov    r8d,0x0
    7f716ee05103:	lea    r9,[r12+0x314]
    7f716ee0510b:	movabs r11,0x5fdfb8a5e650
    7f716ee05115:	call   r11
    7f716ee05118:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee0511e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee05124:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee0512a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee05130:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee0513a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee05144:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee0514e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee05158:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee05162:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0516a:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee05176:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0517f:	mov    rdx,rbx
    7f716ee05182:	shr    rdx,0x10
    7f716ee05186:	and    edx,0xc000
    7f716ee0518c:	mov    rax,rbx
    7f716ee0518f:	shr    rax,0x15
    7f716ee05193:	and    eax,0x100
    7f716ee05198:	xor    eax,0x100
    7f716ee0519d:	or     edx,eax
    7f716ee0519f:	mov    rax,rbx
    7f716ee051a2:	shr    rax,0x1c
    7f716ee051a6:	and    eax,0x1
    7f716ee051a9:	or     edx,eax
    7f716ee051ab:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee051b0:	add    rsp,0x8
    7f716ee051b4:	ret
    7f716ee051b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee051c0:	sub    rsp,0x8
    7f716ee051c4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee051d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee051d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee051dc:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee051e2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee051e8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee051f2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee051fc:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee05206:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee05210:	push   rdx
    7f716ee05211:	push   rsi
    7f716ee05212:	push   r10
    7f716ee05214:	push   r11
    7f716ee05216:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee0521b:	mov    r10d,edx
    7f716ee0521e:	and    r10d,0xc000
    7f716ee05225:	shl    r10d,0x10
    7f716ee05229:	mov    r11d,edx
    7f716ee0522c:	and    r11d,0x100
    7f716ee05233:	shl    r11d,0x15
    7f716ee05237:	or     r10d,r11d
    7f716ee0523a:	and    edx,0x1
    7f716ee0523d:	shl    edx,0x1c
    7f716ee05240:	or     r10d,edx
    7f716ee05243:	btc    r10,0x1d
    7f716ee05248:	mov    r11d,0xf0000000
    7f716ee0524e:	and    r11,r10
    7f716ee05251:	movabs rsi,0xffffffff0fffffff
    7f716ee0525b:	and    rbx,rsi
    7f716ee0525e:	or     rbx,r11
    7f716ee05261:	pop    r11
    7f716ee05263:	pop    r10
    7f716ee05265:	pop    rsi
    7f716ee05266:	pop    rdx
    7f716ee05267:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0526f:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee05275:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0527a:	test   r10d,0x3f
    7f716ee05281:	je     0x7f716ee052a6
    7f716ee05287:	mov    r11d,r10d
    7f716ee0528a:	shr    r10d,1
    7f716ee0528d:	and    r10d,0x1e
    7f716ee05291:	and    r11d,0x1
    7f716ee05295:	or     r10d,r11d
    7f716ee05298:	or     DWORD PTR [r12+0x314],r10d
    7f716ee052a0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee052a6:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee052ac:	lea    rdi,[rsp+0x110]
    7f716ee052b4:	lea    rsi,[rsp+0xf0]
    7f716ee052bc:	lea    rdx,[rsp+0x100]
    7f716ee052c4:	mov    ecx,0x14
    7f716ee052c9:	mov    r8d,0x0
    7f716ee052cf:	lea    r9,[r12+0x314]
    7f716ee052d7:	movabs r11,0x5fdfb8a5e650
    7f716ee052e1:	call   r11
    7f716ee052e4:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee052ea:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee052f0:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee052f6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee052fc:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee05302:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee0530c:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee05316:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee05320:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee0532a:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee05332:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0533e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee05347:	mov    rdx,rbx
    7f716ee0534a:	shr    rdx,0x10
    7f716ee0534e:	and    edx,0xc000
    7f716ee05354:	mov    rax,rbx
    7f716ee05357:	shr    rax,0x15
    7f716ee0535b:	and    eax,0x100
    7f716ee05360:	xor    eax,0x100
    7f716ee05365:	or     edx,eax
    7f716ee05367:	mov    rax,rbx
    7f716ee0536a:	shr    rax,0x1c
    7f716ee0536e:	and    eax,0x1
    7f716ee05371:	or     edx,eax
    7f716ee05373:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee05378:	add    rsp,0x8
    7f716ee0537c:	ret
    7f716ee0537d:	nop    DWORD PTR [rax]
    7f716ee05380:	sub    rsp,0x8
    7f716ee05384:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee05390:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee05396:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0539c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee053a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee053a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee053ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee053b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee053be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee053c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee053d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee053dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee053e6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee053f0:	push   rdx
    7f716ee053f1:	push   rsi
    7f716ee053f2:	push   r10
    7f716ee053f4:	push   r11
    7f716ee053f6:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee053fb:	mov    r10d,edx
    7f716ee053fe:	and    r10d,0xc000
    7f716ee05405:	shl    r10d,0x10
    7f716ee05409:	mov    r11d,edx
    7f716ee0540c:	and    r11d,0x100
    7f716ee05413:	shl    r11d,0x15
    7f716ee05417:	or     r10d,r11d
    7f716ee0541a:	and    edx,0x1
    7f716ee0541d:	shl    edx,0x1c
    7f716ee05420:	or     r10d,edx
    7f716ee05423:	btc    r10,0x1d
    7f716ee05428:	mov    r11d,0xf0000000
    7f716ee0542e:	and    r11,r10
    7f716ee05431:	movabs rsi,0xffffffff0fffffff
    7f716ee0543b:	and    rbx,rsi
    7f716ee0543e:	or     rbx,r11
    7f716ee05441:	pop    r11
    7f716ee05443:	pop    r10
    7f716ee05445:	pop    rsi
    7f716ee05446:	pop    rdx
    7f716ee05447:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0544f:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee05455:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0545a:	test   r10d,0x3f
    7f716ee05461:	je     0x7f716ee05486
    7f716ee05467:	mov    r11d,r10d
    7f716ee0546a:	shr    r10d,1
    7f716ee0546d:	and    r10d,0x1e
    7f716ee05471:	and    r11d,0x1
    7f716ee05475:	or     r10d,r11d
    7f716ee05478:	or     DWORD PTR [r12+0x314],r10d
    7f716ee05480:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee05486:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee0548c:	lea    rdi,[rsp+0x110]
    7f716ee05494:	lea    rsi,[rsp+0xf0]
    7f716ee0549c:	lea    rdx,[rsp+0x100]
    7f716ee054a4:	mov    ecx,0x14
    7f716ee054a9:	mov    r8d,0x0
    7f716ee054af:	lea    r9,[r12+0x314]
    7f716ee054b7:	movabs r11,0x5fdfb8a5e650
    7f716ee054c1:	call   r11
    7f716ee054c4:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee054ca:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee054d0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee054d6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee054dc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee054e2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee054e8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee054ee:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee054f8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee05502:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee0550c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee05516:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee05520:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee0552a:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee05532:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0553e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee05547:	mov    rdx,rbx
    7f716ee0554a:	shr    rdx,0x10
    7f716ee0554e:	and    edx,0xc000
    7f716ee05554:	mov    rax,rbx
    7f716ee05557:	shr    rax,0x15
    7f716ee0555b:	and    eax,0x100
    7f716ee05560:	xor    eax,0x100
    7f716ee05565:	or     edx,eax
    7f716ee05567:	mov    rax,rbx
    7f716ee0556a:	shr    rax,0x1c
    7f716ee0556e:	and    eax,0x1
    7f716ee05571:	or     edx,eax
    7f716ee05573:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee05578:	add    rsp,0x8
    7f716ee0557c:	ret
    7f716ee0557d:	nop    DWORD PTR [rax]
    7f716ee05580:	sub    rsp,0x8
    7f716ee05584:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee05590:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee05596:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0559c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee055a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee055a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee055ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee055b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee055be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee055c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee055d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee055dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee055e6:	push   rdx
    7f716ee055e7:	push   rsi
    7f716ee055e8:	push   r10
    7f716ee055ea:	push   r11
    7f716ee055ec:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee055f1:	mov    r10d,edx
    7f716ee055f4:	and    r10d,0xc000
    7f716ee055fb:	shl    r10d,0x10
    7f716ee055ff:	mov    r11d,edx
    7f716ee05602:	and    r11d,0x100
    7f716ee05609:	shl    r11d,0x15
    7f716ee0560d:	or     r10d,r11d
    7f716ee05610:	and    edx,0x1
    7f716ee05613:	shl    edx,0x1c
    7f716ee05616:	or     r10d,edx
    7f716ee05619:	btc    r10,0x1d
    7f716ee0561e:	mov    r11d,0xf0000000
    7f716ee05624:	and    r11,r10
    7f716ee05627:	movabs rsi,0xffffffff0fffffff
    7f716ee05631:	and    rbx,rsi
    7f716ee05634:	or     rbx,r11
    7f716ee05637:	pop    r11
    7f716ee05639:	pop    r10
    7f716ee0563b:	pop    rsi
    7f716ee0563c:	pop    rdx
    7f716ee0563d:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee05645:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0564b:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee05650:	test   r10d,0x3f
    7f716ee05657:	je     0x7f716ee0567c
    7f716ee0565d:	mov    r11d,r10d
    7f716ee05660:	shr    r10d,1
    7f716ee05663:	and    r10d,0x1e
    7f716ee05667:	and    r11d,0x1
    7f716ee0566b:	or     r10d,r11d
    7f716ee0566e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee05676:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0567c:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee05682:	lea    rdi,[rsp+0x110]
    7f716ee0568a:	lea    rsi,[rsp+0xf0]
    7f716ee05692:	lea    rdx,[rsp+0x100]
    7f716ee0569a:	mov    ecx,0x14
    7f716ee0569f:	mov    r8d,0x0
    7f716ee056a5:	lea    r9,[r12+0x314]
    7f716ee056ad:	movabs r11,0x5fdfb8a5e650
    7f716ee056b7:	call   r11
    7f716ee056ba:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee056c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee056c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee056cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee056d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee056d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee056de:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee056e4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee056ee:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee056f8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee05702:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee0570c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee05716:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0571e:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0572a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee05733:	mov    rdx,rbx
    7f716ee05736:	shr    rdx,0x10
    7f716ee0573a:	and    edx,0xc000
    7f716ee05740:	mov    rax,rbx
    7f716ee05743:	shr    rax,0x15
    7f716ee05747:	and    eax,0x100
    7f716ee0574c:	xor    eax,0x100
    7f716ee05751:	or     edx,eax
    7f716ee05753:	mov    rax,rbx
    7f716ee05756:	shr    rax,0x1c
    7f716ee0575a:	and    eax,0x1
    7f716ee0575d:	or     edx,eax
    7f716ee0575f:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee05764:	add    rsp,0x8
    7f716ee05768:	ret
    7f716ee05769:	nop    DWORD PTR [rax+0x0]
    7f716ee05770:	sub    rsp,0x8
    7f716ee05774:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee05780:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee05786:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0578c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee05792:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee05798:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee057a2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee057ac:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee057b6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee057c0:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee057ca:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee057d4:	push   rdx
    7f716ee057d5:	push   rsi
    7f716ee057d6:	push   r10
    7f716ee057d8:	push   r11
    7f716ee057da:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee057df:	mov    r10d,edx
    7f716ee057e2:	and    r10d,0xc000
    7f716ee057e9:	shl    r10d,0x10
    7f716ee057ed:	mov    r11d,edx
    7f716ee057f0:	and    r11d,0x100
    7f716ee057f7:	shl    r11d,0x15
    7f716ee057fb:	or     r10d,r11d
    7f716ee057fe:	and    edx,0x1
    7f716ee05801:	shl    edx,0x1c
    7f716ee05804:	or     r10d,edx
    7f716ee05807:	btc    r10,0x1d
    7f716ee0580c:	mov    r11d,0xf0000000
    7f716ee05812:	and    r11,r10
    7f716ee05815:	movabs rsi,0xffffffff0fffffff
    7f716ee0581f:	and    rbx,rsi
    7f716ee05822:	or     rbx,r11
    7f716ee05825:	pop    r11
    7f716ee05827:	pop    r10
    7f716ee05829:	pop    rsi
    7f716ee0582a:	pop    rdx
    7f716ee0582b:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee05833:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee05839:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0583e:	test   r10d,0x3f
    7f716ee05845:	je     0x7f716ee0586a
    7f716ee0584b:	mov    r11d,r10d
    7f716ee0584e:	shr    r10d,1
    7f716ee05851:	and    r10d,0x1e
    7f716ee05855:	and    r11d,0x1
    7f716ee05859:	or     r10d,r11d
    7f716ee0585c:	or     DWORD PTR [r12+0x314],r10d
    7f716ee05864:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0586a:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee05870:	lea    rdi,[rsp+0x110]
    7f716ee05878:	lea    rsi,[rsp+0xf0]
    7f716ee05880:	lea    rdx,[rsp+0x100]
    7f716ee05888:	mov    ecx,0x14
    7f716ee0588d:	mov    r8d,0x0
    7f716ee05893:	lea    r9,[r12+0x314]
    7f716ee0589b:	movabs r11,0x5fdfb8a5e650
    7f716ee058a5:	call   r11
    7f716ee058a8:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee058ae:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee058b4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee058ba:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee058c0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee058c6:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee058d0:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee058da:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee058e4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee058ee:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee058f8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee05902:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0590a:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee05916:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0591f:	mov    rdx,rbx
    7f716ee05922:	shr    rdx,0x10
    7f716ee05926:	and    edx,0xc000
    7f716ee0592c:	mov    rax,rbx
    7f716ee0592f:	shr    rax,0x15
    7f716ee05933:	and    eax,0x100
    7f716ee05938:	xor    eax,0x100
    7f716ee0593d:	or     edx,eax
    7f716ee0593f:	mov    rax,rbx
    7f716ee05942:	shr    rax,0x1c
    7f716ee05946:	and    eax,0x1
    7f716ee05949:	or     edx,eax
    7f716ee0594b:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee05950:	add    rsp,0x8
    7f716ee05954:	ret
    7f716ee05955:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee05960:	sub    rsp,0x8
    7f716ee05964:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee05970:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee05976:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0597c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee05982:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee05988:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee0598e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee05998:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee059a2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee059ac:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee059b6:	push   rdx
    7f716ee059b7:	push   rsi
    7f716ee059b8:	push   r10
    7f716ee059ba:	push   r11
    7f716ee059bc:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee059c1:	mov    r10d,edx
    7f716ee059c4:	and    r10d,0xc000
    7f716ee059cb:	shl    r10d,0x10
    7f716ee059cf:	mov    r11d,edx
    7f716ee059d2:	and    r11d,0x100
    7f716ee059d9:	shl    r11d,0x15
    7f716ee059dd:	or     r10d,r11d
    7f716ee059e0:	and    edx,0x1
    7f716ee059e3:	shl    edx,0x1c
    7f716ee059e6:	or     r10d,edx
    7f716ee059e9:	btc    r10,0x1d
    7f716ee059ee:	mov    r11d,0xf0000000
    7f716ee059f4:	and    r11,r10
    7f716ee059f7:	movabs rsi,0xffffffff0fffffff
    7f716ee05a01:	and    rbx,rsi
    7f716ee05a04:	or     rbx,r11
    7f716ee05a07:	pop    r11
    7f716ee05a09:	pop    r10
    7f716ee05a0b:	pop    rsi
    7f716ee05a0c:	pop    rdx
    7f716ee05a0d:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee05a15:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee05a1b:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee05a20:	test   r10d,0x3f
    7f716ee05a27:	je     0x7f716ee05a4c
    7f716ee05a2d:	mov    r11d,r10d
    7f716ee05a30:	shr    r10d,1
    7f716ee05a33:	and    r10d,0x1e
    7f716ee05a37:	and    r11d,0x1
    7f716ee05a3b:	or     r10d,r11d
    7f716ee05a3e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee05a46:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee05a4c:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee05a52:	lea    rdi,[rsp+0x110]
    7f716ee05a5a:	lea    rsi,[rsp+0xf0]
    7f716ee05a62:	lea    rdx,[rsp+0x100]
    7f716ee05a6a:	mov    ecx,0x56
    7f716ee05a6f:	mov    r8d,0x0
    7f716ee05a75:	lea    r9,[r12+0x314]
    7f716ee05a7d:	movabs r11,0x5fdfb8a5e650
    7f716ee05a87:	call   r11
    7f716ee05a8a:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee05a90:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee05a96:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee05a9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee05aa2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee05aa8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee05aae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee05ab8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee05ac2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee05acc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee05ad6:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee05ade:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee05aea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee05af3:	mov    rdx,rbx
    7f716ee05af6:	shr    rdx,0x10
    7f716ee05afa:	and    edx,0xc000
    7f716ee05b00:	mov    rax,rbx
    7f716ee05b03:	shr    rax,0x15
    7f716ee05b07:	and    eax,0x100
    7f716ee05b0c:	xor    eax,0x100
    7f716ee05b11:	or     edx,eax
    7f716ee05b13:	mov    rax,rbx
    7f716ee05b16:	shr    rax,0x1c
    7f716ee05b1a:	and    eax,0x1
    7f716ee05b1d:	or     edx,eax
    7f716ee05b1f:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee05b24:	add    rsp,0x8
    7f716ee05b28:	ret
    7f716ee05b29:	nop    DWORD PTR [rax+0x0]
    7f716ee05b30:	sub    rsp,0x8
    7f716ee05b34:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee05b40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee05b46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee05b4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee05b52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee05b58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee05b5e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee05b64:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee05b6e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee05b78:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee05b82:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee05b8c:	push   rdx
    7f716ee05b8d:	push   rsi
    7f716ee05b8e:	push   r10
    7f716ee05b90:	push   r11
    7f716ee05b92:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee05b97:	mov    r10d,edx
    7f716ee05b9a:	and    r10d,0xc000
    7f716ee05ba1:	shl    r10d,0x10
    7f716ee05ba5:	mov    r11d,edx
    7f716ee05ba8:	and    r11d,0x100
    7f716ee05baf:	shl    r11d,0x15
    7f716ee05bb3:	or     r10d,r11d
    7f716ee05bb6:	and    edx,0x1
    7f716ee05bb9:	shl    edx,0x1c
    7f716ee05bbc:	or     r10d,edx
    7f716ee05bbf:	btc    r10,0x1d
    7f716ee05bc4:	mov    r11d,0xf0000000
    7f716ee05bca:	and    r11,r10
    7f716ee05bcd:	movabs rsi,0xffffffff0fffffff
    7f716ee05bd7:	and    rbx,rsi
    7f716ee05bda:	or     rbx,r11
    7f716ee05bdd:	pop    r11
    7f716ee05bdf:	pop    r10
    7f716ee05be1:	pop    rsi
    7f716ee05be2:	pop    rdx
    7f716ee05be3:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee05beb:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee05bf1:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee05bf6:	test   r10d,0x3f
    7f716ee05bfd:	je     0x7f716ee05c22
    7f716ee05c03:	mov    r11d,r10d
    7f716ee05c06:	shr    r10d,1
    7f716ee05c09:	and    r10d,0x1e
    7f716ee05c0d:	and    r11d,0x1
    7f716ee05c11:	or     r10d,r11d
    7f716ee05c14:	or     DWORD PTR [r12+0x314],r10d
    7f716ee05c1c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee05c22:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee05c28:	lea    rdi,[rsp+0x110]
    7f716ee05c30:	lea    rsi,[rsp+0xf0]
    7f716ee05c38:	lea    rdx,[rsp+0x100]
    7f716ee05c40:	mov    ecx,0x56
    7f716ee05c45:	mov    r8d,0x0
    7f716ee05c4b:	lea    r9,[r12+0x314]
    7f716ee05c53:	movabs r11,0x5fdfb8a5e650
    7f716ee05c5d:	call   r11
    7f716ee05c60:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee05c66:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee05c6c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee05c72:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee05c78:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee05c7e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee05c84:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee05c8a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee05c94:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee05c9e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee05ca8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee05cb2:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee05cba:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee05cc6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee05ccf:	mov    rdx,rbx
    7f716ee05cd2:	shr    rdx,0x10
    7f716ee05cd6:	and    edx,0xc000
    7f716ee05cdc:	mov    rax,rbx
    7f716ee05cdf:	shr    rax,0x15
    7f716ee05ce3:	and    eax,0x100
    7f716ee05ce8:	xor    eax,0x100
    7f716ee05ced:	or     edx,eax
    7f716ee05cef:	mov    rax,rbx
    7f716ee05cf2:	shr    rax,0x1c
    7f716ee05cf6:	and    eax,0x1
    7f716ee05cf9:	or     edx,eax
    7f716ee05cfb:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee05d00:	add    rsp,0x8
    7f716ee05d04:	ret
    7f716ee05d05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee05d10:	sub    rsp,0x8
    7f716ee05d14:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee05d20:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee05d26:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee05d2c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee05d32:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee05d38:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee05d3e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee05d44:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee05d4e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee05d58:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee05d62:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee05d6c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee05d76:	push   rdx
    7f716ee05d77:	push   rsi
    7f716ee05d78:	push   r10
    7f716ee05d7a:	push   r11
    7f716ee05d7c:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee05d81:	mov    r10d,edx
    7f716ee05d84:	and    r10d,0xc000
    7f716ee05d8b:	shl    r10d,0x10
    7f716ee05d8f:	mov    r11d,edx
    7f716ee05d92:	and    r11d,0x100
    7f716ee05d99:	shl    r11d,0x15
    7f716ee05d9d:	or     r10d,r11d
    7f716ee05da0:	and    edx,0x1
    7f716ee05da3:	shl    edx,0x1c
    7f716ee05da6:	or     r10d,edx
    7f716ee05da9:	btc    r10,0x1d
    7f716ee05dae:	mov    r11d,0xf0000000
    7f716ee05db4:	and    r11,r10
    7f716ee05db7:	movabs rsi,0xffffffff0fffffff
    7f716ee05dc1:	and    rbx,rsi
    7f716ee05dc4:	or     rbx,r11
    7f716ee05dc7:	pop    r11
    7f716ee05dc9:	pop    r10
    7f716ee05dcb:	pop    rsi
    7f716ee05dcc:	pop    rdx
    7f716ee05dcd:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee05dd5:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee05ddb:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee05de0:	test   r10d,0x3f
    7f716ee05de7:	je     0x7f716ee05e0c
    7f716ee05ded:	mov    r11d,r10d
    7f716ee05df0:	shr    r10d,1
    7f716ee05df3:	and    r10d,0x1e
    7f716ee05df7:	and    r11d,0x1
    7f716ee05dfb:	or     r10d,r11d
    7f716ee05dfe:	or     DWORD PTR [r12+0x314],r10d
    7f716ee05e06:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee05e0c:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee05e12:	lea    rdi,[rsp+0x110]
    7f716ee05e1a:	lea    rsi,[rsp+0xf0]
    7f716ee05e22:	lea    rdx,[rsp+0x100]
    7f716ee05e2a:	mov    ecx,0x56
    7f716ee05e2f:	mov    r8d,0x0
    7f716ee05e35:	lea    r9,[r12+0x314]
    7f716ee05e3d:	movabs r11,0x5fdfb8a5e650
    7f716ee05e47:	call   r11
    7f716ee05e4a:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee05e50:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee05e56:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee05e5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee05e62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee05e68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee05e6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee05e74:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee05e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee05e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee05e92:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee05e9c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee05ea6:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee05eae:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee05eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee05ec3:	mov    rdx,rbx
    7f716ee05ec6:	shr    rdx,0x10
    7f716ee05eca:	and    edx,0xc000
    7f716ee05ed0:	mov    rax,rbx
    7f716ee05ed3:	shr    rax,0x15
    7f716ee05ed7:	and    eax,0x100
    7f716ee05edc:	xor    eax,0x100
    7f716ee05ee1:	or     edx,eax
    7f716ee05ee3:	mov    rax,rbx
    7f716ee05ee6:	shr    rax,0x1c
    7f716ee05eea:	and    eax,0x1
    7f716ee05eed:	or     edx,eax
    7f716ee05eef:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee05ef4:	add    rsp,0x8
    7f716ee05ef8:	ret
    7f716ee05ef9:	nop    DWORD PTR [rax+0x0]
    7f716ee05f00:	sub    rsp,0x8
    7f716ee05f04:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee05f10:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee05f16:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee05f1c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee05f22:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee05f28:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee05f32:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee05f3c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee05f46:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee05f50:	push   rdx
    7f716ee05f51:	push   rsi
    7f716ee05f52:	push   r10
    7f716ee05f54:	push   r11
    7f716ee05f56:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee05f5b:	mov    r10d,edx
    7f716ee05f5e:	and    r10d,0xc000
    7f716ee05f65:	shl    r10d,0x10
    7f716ee05f69:	mov    r11d,edx
    7f716ee05f6c:	and    r11d,0x100
    7f716ee05f73:	shl    r11d,0x15
    7f716ee05f77:	or     r10d,r11d
    7f716ee05f7a:	and    edx,0x1
    7f716ee05f7d:	shl    edx,0x1c
    7f716ee05f80:	or     r10d,edx
    7f716ee05f83:	btc    r10,0x1d
    7f716ee05f88:	mov    r11d,0xf0000000
    7f716ee05f8e:	and    r11,r10
    7f716ee05f91:	movabs rsi,0xffffffff0fffffff
    7f716ee05f9b:	and    rbx,rsi
    7f716ee05f9e:	or     rbx,r11
    7f716ee05fa1:	pop    r11
    7f716ee05fa3:	pop    r10
    7f716ee05fa5:	pop    rsi
    7f716ee05fa6:	pop    rdx
    7f716ee05fa7:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee05faf:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee05fb5:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee05fba:	test   r10d,0x3f
    7f716ee05fc1:	je     0x7f716ee05fe6
    7f716ee05fc7:	mov    r11d,r10d
    7f716ee05fca:	shr    r10d,1
    7f716ee05fcd:	and    r10d,0x1e
    7f716ee05fd1:	and    r11d,0x1
    7f716ee05fd5:	or     r10d,r11d
    7f716ee05fd8:	or     DWORD PTR [r12+0x314],r10d
    7f716ee05fe0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee05fe6:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee05fec:	lea    rdi,[rsp+0x110]
    7f716ee05ff4:	lea    rsi,[rsp+0xf0]
    7f716ee05ffc:	lea    rdx,[rsp+0x100]
    7f716ee06004:	mov    ecx,0x56
    7f716ee06009:	mov    r8d,0x0
    7f716ee0600f:	lea    r9,[r12+0x314]
    7f716ee06017:	movabs r11,0x5fdfb8a5e650
    7f716ee06021:	call   r11
    7f716ee06024:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee0602a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee06030:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee06036:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee0603c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee06042:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee0604c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee06056:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee06060:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee0606a:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee06072:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0607e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee06087:	mov    rdx,rbx
    7f716ee0608a:	shr    rdx,0x10
    7f716ee0608e:	and    edx,0xc000
    7f716ee06094:	mov    rax,rbx
    7f716ee06097:	shr    rax,0x15
    7f716ee0609b:	and    eax,0x100
    7f716ee060a0:	xor    eax,0x100
    7f716ee060a5:	or     edx,eax
    7f716ee060a7:	mov    rax,rbx
    7f716ee060aa:	shr    rax,0x1c
    7f716ee060ae:	and    eax,0x1
    7f716ee060b1:	or     edx,eax
    7f716ee060b3:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee060b8:	add    rsp,0x8
    7f716ee060bc:	ret
    7f716ee060bd:	nop    DWORD PTR [rax]
    7f716ee060c0:	sub    rsp,0x8
    7f716ee060c4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee060d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee060d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee060dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee060e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee060e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee060ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee060f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee06102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee0610c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee06116:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee06120:	push   rdx
    7f716ee06121:	push   rsi
    7f716ee06122:	push   r10
    7f716ee06124:	push   r11
    7f716ee06126:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee0612b:	mov    r10d,edx
    7f716ee0612e:	and    r10d,0xc000
    7f716ee06135:	shl    r10d,0x10
    7f716ee06139:	mov    r11d,edx
    7f716ee0613c:	and    r11d,0x100
    7f716ee06143:	shl    r11d,0x15
    7f716ee06147:	or     r10d,r11d
    7f716ee0614a:	and    edx,0x1
    7f716ee0614d:	shl    edx,0x1c
    7f716ee06150:	or     r10d,edx
    7f716ee06153:	btc    r10,0x1d
    7f716ee06158:	mov    r11d,0xf0000000
    7f716ee0615e:	and    r11,r10
    7f716ee06161:	movabs rsi,0xffffffff0fffffff
    7f716ee0616b:	and    rbx,rsi
    7f716ee0616e:	or     rbx,r11
    7f716ee06171:	pop    r11
    7f716ee06173:	pop    r10
    7f716ee06175:	pop    rsi
    7f716ee06176:	pop    rdx
    7f716ee06177:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0617f:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee06185:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0618a:	test   r10d,0x3f
    7f716ee06191:	je     0x7f716ee061b6
    7f716ee06197:	mov    r11d,r10d
    7f716ee0619a:	shr    r10d,1
    7f716ee0619d:	and    r10d,0x1e
    7f716ee061a1:	and    r11d,0x1
    7f716ee061a5:	or     r10d,r11d
    7f716ee061a8:	or     DWORD PTR [r12+0x314],r10d
    7f716ee061b0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee061b6:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee061bc:	lea    rdi,[rsp+0x110]
    7f716ee061c4:	lea    rsi,[rsp+0xf0]
    7f716ee061cc:	lea    rdx,[rsp+0x100]
    7f716ee061d4:	mov    ecx,0x14
    7f716ee061d9:	mov    r8d,0x0
    7f716ee061df:	lea    r9,[r12+0x314]
    7f716ee061e7:	movabs r11,0x5fdfb8a5e650
    7f716ee061f1:	call   r11
    7f716ee061f4:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee061fa:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee06200:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee06206:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee0620c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee06212:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee06218:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee06222:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee0622c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee06236:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee06240:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee0624a:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee06252:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0625e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee06267:	mov    rdx,rbx
    7f716ee0626a:	shr    rdx,0x10
    7f716ee0626e:	and    edx,0xc000
    7f716ee06274:	mov    rax,rbx
    7f716ee06277:	shr    rax,0x15
    7f716ee0627b:	and    eax,0x100
    7f716ee06280:	xor    eax,0x100
    7f716ee06285:	or     edx,eax
    7f716ee06287:	mov    rax,rbx
    7f716ee0628a:	shr    rax,0x1c
    7f716ee0628e:	and    eax,0x1
    7f716ee06291:	or     edx,eax
    7f716ee06293:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee06298:	add    rsp,0x8
    7f716ee0629c:	ret
    7f716ee0629d:	nop    DWORD PTR [rax]
    7f716ee062a0:	sub    rsp,0x8
    7f716ee062a4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee062b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee062b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee062bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee062c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee062c8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee062ce:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee062d8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee062e2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee062ec:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee062f6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee06300:	push   rdx
    7f716ee06301:	push   rsi
    7f716ee06302:	push   r10
    7f716ee06304:	push   r11
    7f716ee06306:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee0630b:	mov    r10d,edx
    7f716ee0630e:	and    r10d,0xc000
    7f716ee06315:	shl    r10d,0x10
    7f716ee06319:	mov    r11d,edx
    7f716ee0631c:	and    r11d,0x100
    7f716ee06323:	shl    r11d,0x15
    7f716ee06327:	or     r10d,r11d
    7f716ee0632a:	and    edx,0x1
    7f716ee0632d:	shl    edx,0x1c
    7f716ee06330:	or     r10d,edx
    7f716ee06333:	btc    r10,0x1d
    7f716ee06338:	mov    r11d,0xf0000000
    7f716ee0633e:	and    r11,r10
    7f716ee06341:	movabs rsi,0xffffffff0fffffff
    7f716ee0634b:	and    rbx,rsi
    7f716ee0634e:	or     rbx,r11
    7f716ee06351:	pop    r11
    7f716ee06353:	pop    r10
    7f716ee06355:	pop    rsi
    7f716ee06356:	pop    rdx
    7f716ee06357:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0635f:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee06365:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0636a:	test   r10d,0x3f
    7f716ee06371:	je     0x7f716ee06396
    7f716ee06377:	mov    r11d,r10d
    7f716ee0637a:	shr    r10d,1
    7f716ee0637d:	and    r10d,0x1e
    7f716ee06381:	and    r11d,0x1
    7f716ee06385:	or     r10d,r11d
    7f716ee06388:	or     DWORD PTR [r12+0x314],r10d
    7f716ee06390:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee06396:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee0639c:	lea    rdi,[rsp+0x110]
    7f716ee063a4:	lea    rsi,[rsp+0xf0]
    7f716ee063ac:	lea    rdx,[rsp+0x100]
    7f716ee063b4:	mov    ecx,0x56
    7f716ee063b9:	mov    r8d,0x0
    7f716ee063bf:	lea    r9,[r12+0x314]
    7f716ee063c7:	movabs r11,0x5fdfb8a5e650
    7f716ee063d1:	call   r11
    7f716ee063d4:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee063da:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee063e0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee063e6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee063ec:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee063f2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee063f8:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee06402:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee0640c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee06416:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee06420:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee0642a:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee06432:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0643e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee06447:	mov    rdx,rbx
    7f716ee0644a:	shr    rdx,0x10
    7f716ee0644e:	and    edx,0xc000
    7f716ee06454:	mov    rax,rbx
    7f716ee06457:	shr    rax,0x15
    7f716ee0645b:	and    eax,0x100
    7f716ee06460:	xor    eax,0x100
    7f716ee06465:	or     edx,eax
    7f716ee06467:	mov    rax,rbx
    7f716ee0646a:	shr    rax,0x1c
    7f716ee0646e:	and    eax,0x1
    7f716ee06471:	or     edx,eax
    7f716ee06473:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee06478:	add    rsp,0x8
    7f716ee0647c:	ret
    7f716ee0647d:	nop    DWORD PTR [rax]
    7f716ee06480:	sub    rsp,0x8
    7f716ee06484:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee06490:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee06496:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0649c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee064a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee064a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee064ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee064b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee064be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee064c8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee064d2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee064dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee064e6:	push   rdx
    7f716ee064e7:	push   rsi
    7f716ee064e8:	push   r10
    7f716ee064ea:	push   r11
    7f716ee064ec:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee064f1:	mov    r10d,edx
    7f716ee064f4:	and    r10d,0xc000
    7f716ee064fb:	shl    r10d,0x10
    7f716ee064ff:	mov    r11d,edx
    7f716ee06502:	and    r11d,0x100
    7f716ee06509:	shl    r11d,0x15
    7f716ee0650d:	or     r10d,r11d
    7f716ee06510:	and    edx,0x1
    7f716ee06513:	shl    edx,0x1c
    7f716ee06516:	or     r10d,edx
    7f716ee06519:	btc    r10,0x1d
    7f716ee0651e:	mov    r11d,0xf0000000
    7f716ee06524:	and    r11,r10
    7f716ee06527:	movabs rsi,0xffffffff0fffffff
    7f716ee06531:	and    rbx,rsi
    7f716ee06534:	or     rbx,r11
    7f716ee06537:	pop    r11
    7f716ee06539:	pop    r10
    7f716ee0653b:	pop    rsi
    7f716ee0653c:	pop    rdx
    7f716ee0653d:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee06545:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0654b:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee06550:	test   r10d,0x3f
    7f716ee06557:	je     0x7f716ee0657c
    7f716ee0655d:	mov    r11d,r10d
    7f716ee06560:	shr    r10d,1
    7f716ee06563:	and    r10d,0x1e
    7f716ee06567:	and    r11d,0x1
    7f716ee0656b:	or     r10d,r11d
    7f716ee0656e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee06576:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0657c:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee06582:	lea    rdi,[rsp+0x110]
    7f716ee0658a:	lea    rsi,[rsp+0xf0]
    7f716ee06592:	lea    rdx,[rsp+0x100]
    7f716ee0659a:	mov    ecx,0x14
    7f716ee0659f:	mov    r8d,0x0
    7f716ee065a5:	lea    r9,[r12+0x314]
    7f716ee065ad:	movabs r11,0x5fdfb8a5e650
    7f716ee065b7:	call   r11
    7f716ee065ba:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee065c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee065c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee065cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee065d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee065d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee065de:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee065e4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee065ee:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee065f8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee06602:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee0660c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee06616:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0661e:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0662a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee06633:	mov    rdx,rbx
    7f716ee06636:	shr    rdx,0x10
    7f716ee0663a:	and    edx,0xc000
    7f716ee06640:	mov    rax,rbx
    7f716ee06643:	shr    rax,0x15
    7f716ee06647:	and    eax,0x100
    7f716ee0664c:	xor    eax,0x100
    7f716ee06651:	or     edx,eax
    7f716ee06653:	mov    rax,rbx
    7f716ee06656:	shr    rax,0x1c
    7f716ee0665a:	and    eax,0x1
    7f716ee0665d:	or     edx,eax
    7f716ee0665f:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee06664:	add    rsp,0x8
    7f716ee06668:	ret
    7f716ee06669:	nop    DWORD PTR [rax+0x0]
    7f716ee06670:	sub    rsp,0x8
    7f716ee06674:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee06680:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee06686:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0668c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee06692:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee06698:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee0669e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee066a4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee066ae:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee066b8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee066c2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee066cc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee066d6:	push   rdx
    7f716ee066d7:	push   rsi
    7f716ee066d8:	push   r10
    7f716ee066da:	push   r11
    7f716ee066dc:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee066e1:	mov    r10d,edx
    7f716ee066e4:	and    r10d,0xc000
    7f716ee066eb:	shl    r10d,0x10
    7f716ee066ef:	mov    r11d,edx
    7f716ee066f2:	and    r11d,0x100
    7f716ee066f9:	shl    r11d,0x15
    7f716ee066fd:	or     r10d,r11d
    7f716ee06700:	and    edx,0x1
    7f716ee06703:	shl    edx,0x1c
    7f716ee06706:	or     r10d,edx
    7f716ee06709:	btc    r10,0x1d
    7f716ee0670e:	mov    r11d,0xf0000000
    7f716ee06714:	and    r11,r10
    7f716ee06717:	movabs rsi,0xffffffff0fffffff
    7f716ee06721:	and    rbx,rsi
    7f716ee06724:	or     rbx,r11
    7f716ee06727:	pop    r11
    7f716ee06729:	pop    r10
    7f716ee0672b:	pop    rsi
    7f716ee0672c:	pop    rdx
    7f716ee0672d:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee06735:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0673b:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee06740:	test   r10d,0x3f
    7f716ee06747:	je     0x7f716ee0676c
    7f716ee0674d:	mov    r11d,r10d
    7f716ee06750:	shr    r10d,1
    7f716ee06753:	and    r10d,0x1e
    7f716ee06757:	and    r11d,0x1
    7f716ee0675b:	or     r10d,r11d
    7f716ee0675e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee06766:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0676c:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee06772:	lea    rdi,[rsp+0x110]
    7f716ee0677a:	lea    rsi,[rsp+0xf0]
    7f716ee06782:	lea    rdx,[rsp+0x100]
    7f716ee0678a:	mov    ecx,0x14
    7f716ee0678f:	mov    r8d,0x0
    7f716ee06795:	lea    r9,[r12+0x314]
    7f716ee0679d:	movabs r11,0x5fdfb8a5e650
    7f716ee067a7:	call   r11
    7f716ee067aa:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee067b0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee067b6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee067bc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee067c2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee067c8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee067ce:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee067d4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee067de:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee067e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee067f2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee067fc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee06806:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0680e:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0681a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee06823:	mov    rdx,rbx
    7f716ee06826:	shr    rdx,0x10
    7f716ee0682a:	and    edx,0xc000
    7f716ee06830:	mov    rax,rbx
    7f716ee06833:	shr    rax,0x15
    7f716ee06837:	and    eax,0x100
    7f716ee0683c:	xor    eax,0x100
    7f716ee06841:	or     edx,eax
    7f716ee06843:	mov    rax,rbx
    7f716ee06846:	shr    rax,0x1c
    7f716ee0684a:	and    eax,0x1
    7f716ee0684d:	or     edx,eax
    7f716ee0684f:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee06854:	add    rsp,0x8
    7f716ee06858:	ret
    7f716ee06859:	nop    DWORD PTR [rax+0x0]
    7f716ee06860:	sub    rsp,0x8
    7f716ee06864:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee06870:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee06876:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0687c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee06882:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee06888:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee0688e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee06894:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee0689e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee068a8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee068b2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee068bc:	push   rdx
    7f716ee068bd:	push   rsi
    7f716ee068be:	push   r10
    7f716ee068c0:	push   r11
    7f716ee068c2:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee068c7:	mov    r10d,edx
    7f716ee068ca:	and    r10d,0xc000
    7f716ee068d1:	shl    r10d,0x10
    7f716ee068d5:	mov    r11d,edx
    7f716ee068d8:	and    r11d,0x100
    7f716ee068df:	shl    r11d,0x15
    7f716ee068e3:	or     r10d,r11d
    7f716ee068e6:	and    edx,0x1
    7f716ee068e9:	shl    edx,0x1c
    7f716ee068ec:	or     r10d,edx
    7f716ee068ef:	btc    r10,0x1d
    7f716ee068f4:	mov    r11d,0xf0000000
    7f716ee068fa:	and    r11,r10
    7f716ee068fd:	movabs rsi,0xffffffff0fffffff
    7f716ee06907:	and    rbx,rsi
    7f716ee0690a:	or     rbx,r11
    7f716ee0690d:	pop    r11
    7f716ee0690f:	pop    r10
    7f716ee06911:	pop    rsi
    7f716ee06912:	pop    rdx
    7f716ee06913:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0691b:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee06921:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee06926:	test   r10d,0x3f
    7f716ee0692d:	je     0x7f716ee06952
    7f716ee06933:	mov    r11d,r10d
    7f716ee06936:	shr    r10d,1
    7f716ee06939:	and    r10d,0x1e
    7f716ee0693d:	and    r11d,0x1
    7f716ee06941:	or     r10d,r11d
    7f716ee06944:	or     DWORD PTR [r12+0x314],r10d
    7f716ee0694c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee06952:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee06958:	lea    rdi,[rsp+0x110]
    7f716ee06960:	lea    rsi,[rsp+0xf0]
    7f716ee06968:	lea    rdx,[rsp+0x100]
    7f716ee06970:	mov    ecx,0x56
    7f716ee06975:	mov    r8d,0x0
    7f716ee0697b:	lea    r9,[r12+0x314]
    7f716ee06983:	movabs r11,0x5fdfb8a5e650
    7f716ee0698d:	call   r11
    7f716ee06990:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee06996:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee0699c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee069a2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee069a8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee069ae:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee069b4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee069ba:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee069c4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee069ce:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee069d8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee069e2:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee069ea:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee069f6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee069ff:	mov    rdx,rbx
    7f716ee06a02:	shr    rdx,0x10
    7f716ee06a06:	and    edx,0xc000
    7f716ee06a0c:	mov    rax,rbx
    7f716ee06a0f:	shr    rax,0x15
    7f716ee06a13:	and    eax,0x100
    7f716ee06a18:	xor    eax,0x100
    7f716ee06a1d:	or     edx,eax
    7f716ee06a1f:	mov    rax,rbx
    7f716ee06a22:	shr    rax,0x1c
    7f716ee06a26:	and    eax,0x1
    7f716ee06a29:	or     edx,eax
    7f716ee06a2b:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee06a30:	add    rsp,0x8
    7f716ee06a34:	ret
    7f716ee06a35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee06a40:	sub    rsp,0x8
    7f716ee06a44:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee06a50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee06a56:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee06a5c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee06a62:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee06a68:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee06a6e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee06a74:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee06a7e:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee06a88:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee06a92:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee06a9c:	push   rdx
    7f716ee06a9d:	push   rsi
    7f716ee06a9e:	push   r10
    7f716ee06aa0:	push   r11
    7f716ee06aa2:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee06aa7:	mov    r10d,edx
    7f716ee06aaa:	and    r10d,0xc000
    7f716ee06ab1:	shl    r10d,0x10
    7f716ee06ab5:	mov    r11d,edx
    7f716ee06ab8:	and    r11d,0x100
    7f716ee06abf:	shl    r11d,0x15
    7f716ee06ac3:	or     r10d,r11d
    7f716ee06ac6:	and    edx,0x1
    7f716ee06ac9:	shl    edx,0x1c
    7f716ee06acc:	or     r10d,edx
    7f716ee06acf:	btc    r10,0x1d
    7f716ee06ad4:	mov    r11d,0xf0000000
    7f716ee06ada:	and    r11,r10
    7f716ee06add:	movabs rsi,0xffffffff0fffffff
    7f716ee06ae7:	and    rbx,rsi
    7f716ee06aea:	or     rbx,r11
    7f716ee06aed:	pop    r11
    7f716ee06aef:	pop    r10
    7f716ee06af1:	pop    rsi
    7f716ee06af2:	pop    rdx
    7f716ee06af3:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee06afb:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee06b01:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee06b06:	test   r10d,0x3f
    7f716ee06b0d:	je     0x7f716ee06b32
    7f716ee06b13:	mov    r11d,r10d
    7f716ee06b16:	shr    r10d,1
    7f716ee06b19:	and    r10d,0x1e
    7f716ee06b1d:	and    r11d,0x1
    7f716ee06b21:	or     r10d,r11d
    7f716ee06b24:	or     DWORD PTR [r12+0x314],r10d
    7f716ee06b2c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee06b32:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee06b38:	lea    rdi,[rsp+0x110]
    7f716ee06b40:	lea    rsi,[rsp+0xf0]
    7f716ee06b48:	lea    rdx,[rsp+0x100]
    7f716ee06b50:	mov    ecx,0x14
    7f716ee06b55:	mov    r8d,0x0
    7f716ee06b5b:	lea    r9,[r12+0x314]
    7f716ee06b63:	movabs r11,0x5fdfb8a5e650
    7f716ee06b6d:	call   r11
    7f716ee06b70:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee06b76:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee06b7c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee06b82:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee06b88:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee06b8e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee06b94:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee06b9a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee06ba4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee06bae:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee06bb8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee06bc2:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee06bca:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee06bd6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee06bdf:	mov    rdx,rbx
    7f716ee06be2:	shr    rdx,0x10
    7f716ee06be6:	and    edx,0xc000
    7f716ee06bec:	mov    rax,rbx
    7f716ee06bef:	shr    rax,0x15
    7f716ee06bf3:	and    eax,0x100
    7f716ee06bf8:	xor    eax,0x100
    7f716ee06bfd:	or     edx,eax
    7f716ee06bff:	mov    rax,rbx
    7f716ee06c02:	shr    rax,0x1c
    7f716ee06c06:	and    eax,0x1
    7f716ee06c09:	or     edx,eax
    7f716ee06c0b:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee06c10:	add    rsp,0x8
    7f716ee06c14:	ret
    7f716ee06c15:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee06c20:	sub    rsp,0x8
    7f716ee06c24:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee06c30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee06c36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee06c3c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee06c42:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee06c48:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee06c4e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee06c58:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee06c62:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee06c6c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee06c76:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee06c80:	push   rdx
    7f716ee06c81:	push   rsi
    7f716ee06c82:	push   r10
    7f716ee06c84:	push   r11
    7f716ee06c86:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee06c8b:	mov    r10d,edx
    7f716ee06c8e:	and    r10d,0xc000
    7f716ee06c95:	shl    r10d,0x10
    7f716ee06c99:	mov    r11d,edx
    7f716ee06c9c:	and    r11d,0x100
    7f716ee06ca3:	shl    r11d,0x15
    7f716ee06ca7:	or     r10d,r11d
    7f716ee06caa:	and    edx,0x1
    7f716ee06cad:	shl    edx,0x1c
    7f716ee06cb0:	or     r10d,edx
    7f716ee06cb3:	btc    r10,0x1d
    7f716ee06cb8:	mov    r11d,0xf0000000
    7f716ee06cbe:	and    r11,r10
    7f716ee06cc1:	movabs rsi,0xffffffff0fffffff
    7f716ee06ccb:	and    rbx,rsi
    7f716ee06cce:	or     rbx,r11
    7f716ee06cd1:	pop    r11
    7f716ee06cd3:	pop    r10
    7f716ee06cd5:	pop    rsi
    7f716ee06cd6:	pop    rdx
    7f716ee06cd7:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee06cdf:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee06ce5:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee06cea:	test   r10d,0x3f
    7f716ee06cf1:	je     0x7f716ee06d16
    7f716ee06cf7:	mov    r11d,r10d
    7f716ee06cfa:	shr    r10d,1
    7f716ee06cfd:	and    r10d,0x1e
    7f716ee06d01:	and    r11d,0x1
    7f716ee06d05:	or     r10d,r11d
    7f716ee06d08:	or     DWORD PTR [r12+0x314],r10d
    7f716ee06d10:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee06d16:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee06d1c:	lea    rdi,[rsp+0x110]
    7f716ee06d24:	lea    rsi,[rsp+0xf0]
    7f716ee06d2c:	lea    rdx,[rsp+0x100]
    7f716ee06d34:	mov    ecx,0x56
    7f716ee06d39:	mov    r8d,0x0
    7f716ee06d3f:	lea    r9,[r12+0x314]
    7f716ee06d47:	movabs r11,0x5fdfb8a5e650
    7f716ee06d51:	call   r11
    7f716ee06d54:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee06d5a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee06d60:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee06d66:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee06d6c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee06d72:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee06d78:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee06d82:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee06d8c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee06d96:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee06da0:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee06daa:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee06db2:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee06dbe:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee06dc7:	mov    rdx,rbx
    7f716ee06dca:	shr    rdx,0x10
    7f716ee06dce:	and    edx,0xc000
    7f716ee06dd4:	mov    rax,rbx
    7f716ee06dd7:	shr    rax,0x15
    7f716ee06ddb:	and    eax,0x100
    7f716ee06de0:	xor    eax,0x100
    7f716ee06de5:	or     edx,eax
    7f716ee06de7:	mov    rax,rbx
    7f716ee06dea:	shr    rax,0x1c
    7f716ee06dee:	and    eax,0x1
    7f716ee06df1:	or     edx,eax
    7f716ee06df3:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee06df8:	add    rsp,0x8
    7f716ee06dfc:	ret
    7f716ee06dfd:	nop    DWORD PTR [rax]
    7f716ee06e00:	sub    rsp,0x8
    7f716ee06e04:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee06e10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee06e16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee06e1c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee06e22:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee06e28:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee06e2e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee06e34:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee06e3e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee06e48:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee06e52:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee06e5c:	push   rdx
    7f716ee06e5d:	push   rsi
    7f716ee06e5e:	push   r10
    7f716ee06e60:	push   r11
    7f716ee06e62:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee06e67:	mov    r10d,edx
    7f716ee06e6a:	and    r10d,0xc000
    7f716ee06e71:	shl    r10d,0x10
    7f716ee06e75:	mov    r11d,edx
    7f716ee06e78:	and    r11d,0x100
    7f716ee06e7f:	shl    r11d,0x15
    7f716ee06e83:	or     r10d,r11d
    7f716ee06e86:	and    edx,0x1
    7f716ee06e89:	shl    edx,0x1c
    7f716ee06e8c:	or     r10d,edx
    7f716ee06e8f:	btc    r10,0x1d
    7f716ee06e94:	mov    r11d,0xf0000000
    7f716ee06e9a:	and    r11,r10
    7f716ee06e9d:	movabs rsi,0xffffffff0fffffff
    7f716ee06ea7:	and    rbx,rsi
    7f716ee06eaa:	or     rbx,r11
    7f716ee06ead:	pop    r11
    7f716ee06eaf:	pop    r10
    7f716ee06eb1:	pop    rsi
    7f716ee06eb2:	pop    rdx
    7f716ee06eb3:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee06ebb:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee06ec1:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee06ec6:	test   r10d,0x3f
    7f716ee06ecd:	je     0x7f716ee06ef2
    7f716ee06ed3:	mov    r11d,r10d
    7f716ee06ed6:	shr    r10d,1
    7f716ee06ed9:	and    r10d,0x1e
    7f716ee06edd:	and    r11d,0x1
    7f716ee06ee1:	or     r10d,r11d
    7f716ee06ee4:	or     DWORD PTR [r12+0x314],r10d
    7f716ee06eec:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee06ef2:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee06ef8:	lea    rdi,[rsp+0x110]
    7f716ee06f00:	lea    rsi,[rsp+0xf0]
    7f716ee06f08:	lea    rdx,[rsp+0x100]
    7f716ee06f10:	mov    ecx,0x56
    7f716ee06f15:	mov    r8d,0x0
    7f716ee06f1b:	lea    r9,[r12+0x314]
    7f716ee06f23:	movabs r11,0x5fdfb8a5e650
    7f716ee06f2d:	call   r11
    7f716ee06f30:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee06f36:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee06f3c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee06f42:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee06f48:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee06f4e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee06f54:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee06f5a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee06f64:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee06f6e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee06f78:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee06f82:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee06f8a:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee06f96:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee06f9f:	mov    rdx,rbx
    7f716ee06fa2:	shr    rdx,0x10
    7f716ee06fa6:	and    edx,0xc000
    7f716ee06fac:	mov    rax,rbx
    7f716ee06faf:	shr    rax,0x15
    7f716ee06fb3:	and    eax,0x100
    7f716ee06fb8:	xor    eax,0x100
    7f716ee06fbd:	or     edx,eax
    7f716ee06fbf:	mov    rax,rbx
    7f716ee06fc2:	shr    rax,0x1c
    7f716ee06fc6:	and    eax,0x1
    7f716ee06fc9:	or     edx,eax
    7f716ee06fcb:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee06fd0:	add    rsp,0x8
    7f716ee06fd4:	ret
    7f716ee06fd5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee06fe0:	sub    rsp,0x8
    7f716ee06fe4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee06ff0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee06ff6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee06ffc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee07002:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee07008:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee0700e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee07014:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee0701e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee07028:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee07032:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee0703c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee07046:	push   rdx
    7f716ee07047:	push   rsi
    7f716ee07048:	push   r10
    7f716ee0704a:	push   r11
    7f716ee0704c:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee07051:	mov    r10d,edx
    7f716ee07054:	and    r10d,0xc000
    7f716ee0705b:	shl    r10d,0x10
    7f716ee0705f:	mov    r11d,edx
    7f716ee07062:	and    r11d,0x100
    7f716ee07069:	shl    r11d,0x15
    7f716ee0706d:	or     r10d,r11d
    7f716ee07070:	and    edx,0x1
    7f716ee07073:	shl    edx,0x1c
    7f716ee07076:	or     r10d,edx
    7f716ee07079:	btc    r10,0x1d
    7f716ee0707e:	mov    r11d,0xf0000000
    7f716ee07084:	and    r11,r10
    7f716ee07087:	movabs rsi,0xffffffff0fffffff
    7f716ee07091:	and    rbx,rsi
    7f716ee07094:	or     rbx,r11
    7f716ee07097:	pop    r11
    7f716ee07099:	pop    r10
    7f716ee0709b:	pop    rsi
    7f716ee0709c:	pop    rdx
    7f716ee0709d:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee070a5:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee070ab:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee070b0:	test   r10d,0x3f
    7f716ee070b7:	je     0x7f716ee070dc
    7f716ee070bd:	mov    r11d,r10d
    7f716ee070c0:	shr    r10d,1
    7f716ee070c3:	and    r10d,0x1e
    7f716ee070c7:	and    r11d,0x1
    7f716ee070cb:	or     r10d,r11d
    7f716ee070ce:	or     DWORD PTR [r12+0x314],r10d
    7f716ee070d6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee070dc:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee070e2:	lea    rdi,[rsp+0x110]
    7f716ee070ea:	lea    rsi,[rsp+0xf0]
    7f716ee070f2:	lea    rdx,[rsp+0x100]
    7f716ee070fa:	mov    ecx,0x14
    7f716ee070ff:	mov    r8d,0x0
    7f716ee07105:	lea    r9,[r12+0x314]
    7f716ee0710d:	movabs r11,0x5fdfb8a5e650
    7f716ee07117:	call   r11
    7f716ee0711a:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee07120:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee07126:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee0712c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee07132:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee07138:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee0713e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee07144:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee0714e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee07158:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee07162:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee0716c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee07176:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0717e:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0718a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee07193:	mov    rdx,rbx
    7f716ee07196:	shr    rdx,0x10
    7f716ee0719a:	and    edx,0xc000
    7f716ee071a0:	mov    rax,rbx
    7f716ee071a3:	shr    rax,0x15
    7f716ee071a7:	and    eax,0x100
    7f716ee071ac:	xor    eax,0x100
    7f716ee071b1:	or     edx,eax
    7f716ee071b3:	mov    rax,rbx
    7f716ee071b6:	shr    rax,0x1c
    7f716ee071ba:	and    eax,0x1
    7f716ee071bd:	or     edx,eax
    7f716ee071bf:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee071c4:	add    rsp,0x8
    7f716ee071c8:	ret
    7f716ee071c9:	nop    DWORD PTR [rax+0x0]
    7f716ee071d0:	sub    rsp,0x8
    7f716ee071d4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee071e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee071e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee071ec:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee071f2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee071f8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee07202:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee0720c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee07216:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee07220:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee0722a:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee07234:	push   rdx
    7f716ee07235:	push   rsi
    7f716ee07236:	push   r10
    7f716ee07238:	push   r11
    7f716ee0723a:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee0723f:	mov    r10d,edx
    7f716ee07242:	and    r10d,0xc000
    7f716ee07249:	shl    r10d,0x10
    7f716ee0724d:	mov    r11d,edx
    7f716ee07250:	and    r11d,0x100
    7f716ee07257:	shl    r11d,0x15
    7f716ee0725b:	or     r10d,r11d
    7f716ee0725e:	and    edx,0x1
    7f716ee07261:	shl    edx,0x1c
    7f716ee07264:	or     r10d,edx
    7f716ee07267:	btc    r10,0x1d
    7f716ee0726c:	mov    r11d,0xf0000000
    7f716ee07272:	and    r11,r10
    7f716ee07275:	movabs rsi,0xffffffff0fffffff
    7f716ee0727f:	and    rbx,rsi
    7f716ee07282:	or     rbx,r11
    7f716ee07285:	pop    r11
    7f716ee07287:	pop    r10
    7f716ee07289:	pop    rsi
    7f716ee0728a:	pop    rdx
    7f716ee0728b:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee07293:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee07299:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0729e:	test   r10d,0x3f
    7f716ee072a5:	je     0x7f716ee072ca
    7f716ee072ab:	mov    r11d,r10d
    7f716ee072ae:	shr    r10d,1
    7f716ee072b1:	and    r10d,0x1e
    7f716ee072b5:	and    r11d,0x1
    7f716ee072b9:	or     r10d,r11d
    7f716ee072bc:	or     DWORD PTR [r12+0x314],r10d
    7f716ee072c4:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee072ca:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee072d0:	lea    rdi,[rsp+0x110]
    7f716ee072d8:	lea    rsi,[rsp+0xf0]
    7f716ee072e0:	lea    rdx,[rsp+0x100]
    7f716ee072e8:	mov    ecx,0x56
    7f716ee072ed:	mov    r8d,0x0
    7f716ee072f3:	lea    r9,[r12+0x314]
    7f716ee072fb:	movabs r11,0x5fdfb8a5e650
    7f716ee07305:	call   r11
    7f716ee07308:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee0730e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee07314:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee0731a:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee07320:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee07326:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee07330:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee0733a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee07344:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee0734e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee07358:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee07362:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0736a:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee07376:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0737f:	mov    rdx,rbx
    7f716ee07382:	shr    rdx,0x10
    7f716ee07386:	and    edx,0xc000
    7f716ee0738c:	mov    rax,rbx
    7f716ee0738f:	shr    rax,0x15
    7f716ee07393:	and    eax,0x100
    7f716ee07398:	xor    eax,0x100
    7f716ee0739d:	or     edx,eax
    7f716ee0739f:	mov    rax,rbx
    7f716ee073a2:	shr    rax,0x1c
    7f716ee073a6:	and    eax,0x1
    7f716ee073a9:	or     edx,eax
    7f716ee073ab:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee073b0:	add    rsp,0x8
    7f716ee073b4:	ret
    7f716ee073b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee073c0:	sub    rsp,0x8
    7f716ee073c4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee073d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee073d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee073dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee073e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee073e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee073ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee073f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee07402:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee0740c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee07416:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee07420:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee0742a:	push   rdx
    7f716ee0742b:	push   rsi
    7f716ee0742c:	push   r10
    7f716ee0742e:	push   r11
    7f716ee07430:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee07435:	mov    r10d,edx
    7f716ee07438:	and    r10d,0xc000
    7f716ee0743f:	shl    r10d,0x10
    7f716ee07443:	mov    r11d,edx
    7f716ee07446:	and    r11d,0x100
    7f716ee0744d:	shl    r11d,0x15
    7f716ee07451:	or     r10d,r11d
    7f716ee07454:	and    edx,0x1
    7f716ee07457:	shl    edx,0x1c
    7f716ee0745a:	or     r10d,edx
    7f716ee0745d:	btc    r10,0x1d
    7f716ee07462:	mov    r11d,0xf0000000
    7f716ee07468:	and    r11,r10
    7f716ee0746b:	movabs rsi,0xffffffff0fffffff
    7f716ee07475:	and    rbx,rsi
    7f716ee07478:	or     rbx,r11
    7f716ee0747b:	pop    r11
    7f716ee0747d:	pop    r10
    7f716ee0747f:	pop    rsi
    7f716ee07480:	pop    rdx
    7f716ee07481:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee07489:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0748f:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee07494:	test   r10d,0x3f
    7f716ee0749b:	je     0x7f716ee074c0
    7f716ee074a1:	mov    r11d,r10d
    7f716ee074a4:	shr    r10d,1
    7f716ee074a7:	and    r10d,0x1e
    7f716ee074ab:	and    r11d,0x1
    7f716ee074af:	or     r10d,r11d
    7f716ee074b2:	or     DWORD PTR [r12+0x314],r10d
    7f716ee074ba:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee074c0:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee074c6:	lea    rdi,[rsp+0x110]
    7f716ee074ce:	lea    rsi,[rsp+0xf0]
    7f716ee074d6:	lea    rdx,[rsp+0x100]
    7f716ee074de:	mov    ecx,0x14
    7f716ee074e3:	mov    r8d,0x0
    7f716ee074e9:	lea    r9,[r12+0x314]
    7f716ee074f1:	movabs r11,0x5fdfb8a5e650
    7f716ee074fb:	call   r11
    7f716ee074fe:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee07504:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee0750a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee07510:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee07516:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee0751c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee07522:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee0752c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee07536:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee07540:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee0754a:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee07554:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee0755e:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee07566:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee07572:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0757b:	mov    rdx,rbx
    7f716ee0757e:	shr    rdx,0x10
    7f716ee07582:	and    edx,0xc000
    7f716ee07588:	mov    rax,rbx
    7f716ee0758b:	shr    rax,0x15
    7f716ee0758f:	and    eax,0x100
    7f716ee07594:	xor    eax,0x100
    7f716ee07599:	or     edx,eax
    7f716ee0759b:	mov    rax,rbx
    7f716ee0759e:	shr    rax,0x1c
    7f716ee075a2:	and    eax,0x1
    7f716ee075a5:	or     edx,eax
    7f716ee075a7:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee075ac:	add    rsp,0x8
    7f716ee075b0:	ret
    7f716ee075b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee075c0:	sub    rsp,0x8
    7f716ee075c4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee075d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee075d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee075dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee075e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee075e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee075ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee075f4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee075fe:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee07608:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee07612:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee0761c:	push   rdx
    7f716ee0761d:	push   rsi
    7f716ee0761e:	push   r10
    7f716ee07620:	push   r11
    7f716ee07622:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee07627:	mov    r10d,edx
    7f716ee0762a:	and    r10d,0xc000
    7f716ee07631:	shl    r10d,0x10
    7f716ee07635:	mov    r11d,edx
    7f716ee07638:	and    r11d,0x100
    7f716ee0763f:	shl    r11d,0x15
    7f716ee07643:	or     r10d,r11d
    7f716ee07646:	and    edx,0x1
    7f716ee07649:	shl    edx,0x1c
    7f716ee0764c:	or     r10d,edx
    7f716ee0764f:	btc    r10,0x1d
    7f716ee07654:	mov    r11d,0xf0000000
    7f716ee0765a:	and    r11,r10
    7f716ee0765d:	movabs rsi,0xffffffff0fffffff
    7f716ee07667:	and    rbx,rsi
    7f716ee0766a:	or     rbx,r11
    7f716ee0766d:	pop    r11
    7f716ee0766f:	pop    r10
    7f716ee07671:	pop    rsi
    7f716ee07672:	pop    rdx
    7f716ee07673:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0767b:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee07681:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee07686:	test   r10d,0x3f
    7f716ee0768d:	je     0x7f716ee076b2
    7f716ee07693:	mov    r11d,r10d
    7f716ee07696:	shr    r10d,1
    7f716ee07699:	and    r10d,0x1e
    7f716ee0769d:	and    r11d,0x1
    7f716ee076a1:	or     r10d,r11d
    7f716ee076a4:	or     DWORD PTR [r12+0x314],r10d
    7f716ee076ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee076b2:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee076b8:	lea    rdi,[rsp+0x110]
    7f716ee076c0:	lea    rsi,[rsp+0xf0]
    7f716ee076c8:	lea    rdx,[rsp+0x100]
    7f716ee076d0:	mov    ecx,0x56
    7f716ee076d5:	mov    r8d,0x0
    7f716ee076db:	lea    r9,[r12+0x314]
    7f716ee076e3:	movabs r11,0x5fdfb8a5e650
    7f716ee076ed:	call   r11
    7f716ee076f0:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee076f6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee076fc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee07702:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee07708:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee0770e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee07714:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee0771a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee07724:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee0772e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee07738:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee07742:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0774a:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee07756:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0775f:	mov    rdx,rbx
    7f716ee07762:	shr    rdx,0x10
    7f716ee07766:	and    edx,0xc000
    7f716ee0776c:	mov    rax,rbx
    7f716ee0776f:	shr    rax,0x15
    7f716ee07773:	and    eax,0x100
    7f716ee07778:	xor    eax,0x100
    7f716ee0777d:	or     edx,eax
    7f716ee0777f:	mov    rax,rbx
    7f716ee07782:	shr    rax,0x1c
    7f716ee07786:	and    eax,0x1
    7f716ee07789:	or     edx,eax
    7f716ee0778b:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee07790:	add    rsp,0x8
    7f716ee07794:	ret
    7f716ee07795:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee077a0:	sub    rsp,0x8
    7f716ee077a4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee077b0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee077b6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee077bc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee077c2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee077c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee077d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee077dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee077e6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee077f0:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7f716ee077fa:	push   rdx
    7f716ee077fb:	push   rsi
    7f716ee077fc:	push   r10
    7f716ee077fe:	push   r11
    7f716ee07800:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee07805:	mov    r10d,edx
    7f716ee07808:	and    r10d,0xc000
    7f716ee0780f:	shl    r10d,0x10
    7f716ee07813:	mov    r11d,edx
    7f716ee07816:	and    r11d,0x100
    7f716ee0781d:	shl    r11d,0x15
    7f716ee07821:	or     r10d,r11d
    7f716ee07824:	and    edx,0x1
    7f716ee07827:	shl    edx,0x1c
    7f716ee0782a:	or     r10d,edx
    7f716ee0782d:	btc    r10,0x1d
    7f716ee07832:	mov    r11d,0xf0000000
    7f716ee07838:	and    r11,r10
    7f716ee0783b:	movabs rsi,0xffffffff0fffffff
    7f716ee07845:	and    rbx,rsi
    7f716ee07848:	or     rbx,r11
    7f716ee0784b:	pop    r11
    7f716ee0784d:	pop    r10
    7f716ee0784f:	pop    rsi
    7f716ee07850:	pop    rdx
    7f716ee07851:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee07859:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0785f:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee07864:	test   r10d,0x3f
    7f716ee0786b:	je     0x7f716ee07890
    7f716ee07871:	mov    r11d,r10d
    7f716ee07874:	shr    r10d,1
    7f716ee07877:	and    r10d,0x1e
    7f716ee0787b:	and    r11d,0x1
    7f716ee0787f:	or     r10d,r11d
    7f716ee07882:	or     DWORD PTR [r12+0x314],r10d
    7f716ee0788a:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee07890:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee07896:	lea    rdi,[rsp+0x110]
    7f716ee0789e:	lea    rsi,[rsp+0xf0]
    7f716ee078a6:	lea    rdx,[rsp+0x100]
    7f716ee078ae:	mov    ecx,0x14
    7f716ee078b3:	mov    r8d,0x0
    7f716ee078b9:	lea    r9,[r12+0x314]
    7f716ee078c1:	movabs r11,0x5fdfb8a5e650
    7f716ee078cb:	call   r11
    7f716ee078ce:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee078d4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee078da:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee078e0:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee078e6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee078ec:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee078f6:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee07900:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee0790a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee07914:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7f716ee0791e:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee07926:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee07932:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0793b:	mov    rdx,rbx
    7f716ee0793e:	shr    rdx,0x10
    7f716ee07942:	and    edx,0xc000
    7f716ee07948:	mov    rax,rbx
    7f716ee0794b:	shr    rax,0x15
    7f716ee0794f:	and    eax,0x100
    7f716ee07954:	xor    eax,0x100
    7f716ee07959:	or     edx,eax
    7f716ee0795b:	mov    rax,rbx
    7f716ee0795e:	shr    rax,0x1c
    7f716ee07962:	and    eax,0x1
    7f716ee07965:	or     edx,eax
    7f716ee07967:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee0796c:	add    rsp,0x8
    7f716ee07970:	ret
    7f716ee07971:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee07980:	sub    rsp,0x8
    7f716ee07984:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee07990:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee07996:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0799c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee079a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee079a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee079ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee079b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee079be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee079c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee079d2:	push   rdx
    7f716ee079d3:	push   rsi
    7f716ee079d4:	push   r10
    7f716ee079d6:	push   r11
    7f716ee079d8:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee079dd:	mov    r10d,edx
    7f716ee079e0:	and    r10d,0xc000
    7f716ee079e7:	shl    r10d,0x10
    7f716ee079eb:	mov    r11d,edx
    7f716ee079ee:	and    r11d,0x100
    7f716ee079f5:	shl    r11d,0x15
    7f716ee079f9:	or     r10d,r11d
    7f716ee079fc:	and    edx,0x1
    7f716ee079ff:	shl    edx,0x1c
    7f716ee07a02:	or     r10d,edx
    7f716ee07a05:	btc    r10,0x1d
    7f716ee07a0a:	mov    r11d,0xf0000000
    7f716ee07a10:	and    r11,r10
    7f716ee07a13:	movabs rsi,0xffffffff0fffffff
    7f716ee07a1d:	and    rbx,rsi
    7f716ee07a20:	or     rbx,r11
    7f716ee07a23:	pop    r11
    7f716ee07a25:	pop    r10
    7f716ee07a27:	pop    rsi
    7f716ee07a28:	pop    rdx
    7f716ee07a29:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee07a31:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee07a37:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee07a3c:	test   r10d,0x3f
    7f716ee07a43:	je     0x7f716ee07a68
    7f716ee07a49:	mov    r11d,r10d
    7f716ee07a4c:	shr    r10d,1
    7f716ee07a4f:	and    r10d,0x1e
    7f716ee07a53:	and    r11d,0x1
    7f716ee07a57:	or     r10d,r11d
    7f716ee07a5a:	or     DWORD PTR [r12+0x314],r10d
    7f716ee07a62:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee07a68:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee07a6e:	lea    rdi,[rsp+0x110]
    7f716ee07a76:	lea    rsi,[rsp+0xf0]
    7f716ee07a7e:	lea    rdx,[rsp+0x100]
    7f716ee07a86:	mov    ecx,0x56
    7f716ee07a8b:	mov    r8d,0x0
    7f716ee07a91:	lea    r9,[r12+0x314]
    7f716ee07a99:	movabs r11,0x5fdfb8a5e650
    7f716ee07aa3:	call   r11
    7f716ee07aa6:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee07aac:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee07ab2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee07ab8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee07abe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee07ac4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee07aca:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee07ad0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee07ada:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee07ae4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee07aee:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee07af6:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee07b02:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee07b0b:	mov    rdx,rbx
    7f716ee07b0e:	shr    rdx,0x10
    7f716ee07b12:	and    edx,0xc000
    7f716ee07b18:	mov    rax,rbx
    7f716ee07b1b:	shr    rax,0x15
    7f716ee07b1f:	and    eax,0x100
    7f716ee07b24:	xor    eax,0x100
    7f716ee07b29:	or     edx,eax
    7f716ee07b2b:	mov    rax,rbx
    7f716ee07b2e:	shr    rax,0x1c
    7f716ee07b32:	and    eax,0x1
    7f716ee07b35:	or     edx,eax
    7f716ee07b37:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee07b3c:	add    rsp,0x8
    7f716ee07b40:	ret
    7f716ee07b41:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee07b50:	sub    rsp,0x8
    7f716ee07b54:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee07b60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee07b66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee07b6c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee07b72:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee07b78:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee07b7e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee07b88:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee07b92:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee07b9c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee07ba6:	push   rdx
    7f716ee07ba7:	push   rsi
    7f716ee07ba8:	push   r10
    7f716ee07baa:	push   r11
    7f716ee07bac:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee07bb1:	mov    r10d,edx
    7f716ee07bb4:	and    r10d,0xc000
    7f716ee07bbb:	shl    r10d,0x10
    7f716ee07bbf:	mov    r11d,edx
    7f716ee07bc2:	and    r11d,0x100
    7f716ee07bc9:	shl    r11d,0x15
    7f716ee07bcd:	or     r10d,r11d
    7f716ee07bd0:	and    edx,0x1
    7f716ee07bd3:	shl    edx,0x1c
    7f716ee07bd6:	or     r10d,edx
    7f716ee07bd9:	btc    r10,0x1d
    7f716ee07bde:	mov    r11d,0xf0000000
    7f716ee07be4:	and    r11,r10
    7f716ee07be7:	movabs rsi,0xffffffff0fffffff
    7f716ee07bf1:	and    rbx,rsi
    7f716ee07bf4:	or     rbx,r11
    7f716ee07bf7:	pop    r11
    7f716ee07bf9:	pop    r10
    7f716ee07bfb:	pop    rsi
    7f716ee07bfc:	pop    rdx
    7f716ee07bfd:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee07c05:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee07c0b:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee07c10:	test   r10d,0x3f
    7f716ee07c17:	je     0x7f716ee07c3c
    7f716ee07c1d:	mov    r11d,r10d
    7f716ee07c20:	shr    r10d,1
    7f716ee07c23:	and    r10d,0x1e
    7f716ee07c27:	and    r11d,0x1
    7f716ee07c2b:	or     r10d,r11d
    7f716ee07c2e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee07c36:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee07c3c:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee07c42:	lea    rdi,[rsp+0x110]
    7f716ee07c4a:	lea    rsi,[rsp+0xf0]
    7f716ee07c52:	lea    rdx,[rsp+0x100]
    7f716ee07c5a:	mov    ecx,0x56
    7f716ee07c5f:	mov    r8d,0x0
    7f716ee07c65:	lea    r9,[r12+0x314]
    7f716ee07c6d:	movabs r11,0x5fdfb8a5e650
    7f716ee07c77:	call   r11
    7f716ee07c7a:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee07c80:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee07c86:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee07c8c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee07c92:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee07c98:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee07c9e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee07ca8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee07cb2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee07cbc:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee07cc6:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee07cce:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee07cda:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee07ce3:	mov    rdx,rbx
    7f716ee07ce6:	shr    rdx,0x10
    7f716ee07cea:	and    edx,0xc000
    7f716ee07cf0:	mov    rax,rbx
    7f716ee07cf3:	shr    rax,0x15
    7f716ee07cf7:	and    eax,0x100
    7f716ee07cfc:	xor    eax,0x100
    7f716ee07d01:	or     edx,eax
    7f716ee07d03:	mov    rax,rbx
    7f716ee07d06:	shr    rax,0x1c
    7f716ee07d0a:	and    eax,0x1
    7f716ee07d0d:	or     edx,eax
    7f716ee07d0f:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee07d14:	add    rsp,0x8
    7f716ee07d18:	ret
    7f716ee07d19:	nop    DWORD PTR [rax+0x0]
    7f716ee07d20:	sub    rsp,0x8
    7f716ee07d24:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee07d30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee07d36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee07d3c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee07d42:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee07d48:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee07d4e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee07d54:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee07d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee07d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee07d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee07d7c:	push   rdx
    7f716ee07d7d:	push   rsi
    7f716ee07d7e:	push   r10
    7f716ee07d80:	push   r11
    7f716ee07d82:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee07d87:	mov    r10d,edx
    7f716ee07d8a:	and    r10d,0xc000
    7f716ee07d91:	shl    r10d,0x10
    7f716ee07d95:	mov    r11d,edx
    7f716ee07d98:	and    r11d,0x100
    7f716ee07d9f:	shl    r11d,0x15
    7f716ee07da3:	or     r10d,r11d
    7f716ee07da6:	and    edx,0x1
    7f716ee07da9:	shl    edx,0x1c
    7f716ee07dac:	or     r10d,edx
    7f716ee07daf:	btc    r10,0x1d
    7f716ee07db4:	mov    r11d,0xf0000000
    7f716ee07dba:	and    r11,r10
    7f716ee07dbd:	movabs rsi,0xffffffff0fffffff
    7f716ee07dc7:	and    rbx,rsi
    7f716ee07dca:	or     rbx,r11
    7f716ee07dcd:	pop    r11
    7f716ee07dcf:	pop    r10
    7f716ee07dd1:	pop    rsi
    7f716ee07dd2:	pop    rdx
    7f716ee07dd3:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee07ddb:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee07de1:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee07de6:	test   r10d,0x3f
    7f716ee07ded:	je     0x7f716ee07e12
    7f716ee07df3:	mov    r11d,r10d
    7f716ee07df6:	shr    r10d,1
    7f716ee07df9:	and    r10d,0x1e
    7f716ee07dfd:	and    r11d,0x1
    7f716ee07e01:	or     r10d,r11d
    7f716ee07e04:	or     DWORD PTR [r12+0x314],r10d
    7f716ee07e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee07e12:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee07e18:	lea    rdi,[rsp+0x110]
    7f716ee07e20:	lea    rsi,[rsp+0xf0]
    7f716ee07e28:	lea    rdx,[rsp+0x100]
    7f716ee07e30:	mov    ecx,0x14
    7f716ee07e35:	mov    r8d,0x0
    7f716ee07e3b:	lea    r9,[r12+0x314]
    7f716ee07e43:	movabs r11,0x5fdfb8a5e650
    7f716ee07e4d:	call   r11
    7f716ee07e50:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee07e56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee07e5c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee07e62:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee07e68:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee07e6e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee07e74:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee07e7a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee07e84:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee07e8e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee07e98:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee07ea2:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee07eaa:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee07eb6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee07ebf:	mov    rdx,rbx
    7f716ee07ec2:	shr    rdx,0x10
    7f716ee07ec6:	and    edx,0xc000
    7f716ee07ecc:	mov    rax,rbx
    7f716ee07ecf:	shr    rax,0x15
    7f716ee07ed3:	and    eax,0x100
    7f716ee07ed8:	xor    eax,0x100
    7f716ee07edd:	or     edx,eax
    7f716ee07edf:	mov    rax,rbx
    7f716ee07ee2:	shr    rax,0x1c
    7f716ee07ee6:	and    eax,0x1
    7f716ee07ee9:	or     edx,eax
    7f716ee07eeb:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee07ef0:	add    rsp,0x8
    7f716ee07ef4:	ret
    7f716ee07ef5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee07f00:	sub    rsp,0x8
    7f716ee07f04:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee07f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee07f16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee07f1c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee07f22:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee07f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee07f2e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee07f38:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee07f42:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee07f4c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee07f56:	push   rdx
    7f716ee07f57:	push   rsi
    7f716ee07f58:	push   r10
    7f716ee07f5a:	push   r11
    7f716ee07f5c:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee07f61:	mov    r10d,edx
    7f716ee07f64:	and    r10d,0xc000
    7f716ee07f6b:	shl    r10d,0x10
    7f716ee07f6f:	mov    r11d,edx
    7f716ee07f72:	and    r11d,0x100
    7f716ee07f79:	shl    r11d,0x15
    7f716ee07f7d:	or     r10d,r11d
    7f716ee07f80:	and    edx,0x1
    7f716ee07f83:	shl    edx,0x1c
    7f716ee07f86:	or     r10d,edx
    7f716ee07f89:	btc    r10,0x1d
    7f716ee07f8e:	mov    r11d,0xf0000000
    7f716ee07f94:	and    r11,r10
    7f716ee07f97:	movabs rsi,0xffffffff0fffffff
    7f716ee07fa1:	and    rbx,rsi
    7f716ee07fa4:	or     rbx,r11
    7f716ee07fa7:	pop    r11
    7f716ee07fa9:	pop    r10
    7f716ee07fab:	pop    rsi
    7f716ee07fac:	pop    rdx
    7f716ee07fad:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee07fb5:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee07fbb:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee07fc0:	test   r10d,0x3f
    7f716ee07fc7:	je     0x7f716ee07fec
    7f716ee07fcd:	mov    r11d,r10d
    7f716ee07fd0:	shr    r10d,1
    7f716ee07fd3:	and    r10d,0x1e
    7f716ee07fd7:	and    r11d,0x1
    7f716ee07fdb:	or     r10d,r11d
    7f716ee07fde:	or     DWORD PTR [r12+0x314],r10d
    7f716ee07fe6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee07fec:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee07ff2:	lea    rdi,[rsp+0x110]
    7f716ee07ffa:	lea    rsi,[rsp+0xf0]
    7f716ee08002:	lea    rdx,[rsp+0x100]
    7f716ee0800a:	mov    ecx,0x14
    7f716ee0800f:	mov    r8d,0x0
    7f716ee08015:	lea    r9,[r12+0x314]
    7f716ee0801d:	movabs r11,0x5fdfb8a5e650
    7f716ee08027:	call   r11
    7f716ee0802a:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee08030:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee08036:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee0803c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee08042:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee08048:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee0804e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee08058:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee08062:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee0806c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee08076:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0807e:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0808a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee08093:	mov    rdx,rbx
    7f716ee08096:	shr    rdx,0x10
    7f716ee0809a:	and    edx,0xc000
    7f716ee080a0:	mov    rax,rbx
    7f716ee080a3:	shr    rax,0x15
    7f716ee080a7:	and    eax,0x100
    7f716ee080ac:	xor    eax,0x100
    7f716ee080b1:	or     edx,eax
    7f716ee080b3:	mov    rax,rbx
    7f716ee080b6:	shr    rax,0x1c
    7f716ee080ba:	and    eax,0x1
    7f716ee080bd:	or     edx,eax
    7f716ee080bf:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee080c4:	add    rsp,0x8
    7f716ee080c8:	ret
    7f716ee080c9:	nop    DWORD PTR [rax+0x0]
    7f716ee080d0:	sub    rsp,0x8
    7f716ee080d4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee080e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee080e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee080ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee080f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee080f8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee080fe:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee08108:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee08112:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee0811c:	push   rdx
    7f716ee0811d:	push   rsi
    7f716ee0811e:	push   r10
    7f716ee08120:	push   r11
    7f716ee08122:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee08127:	mov    r10d,edx
    7f716ee0812a:	and    r10d,0xc000
    7f716ee08131:	shl    r10d,0x10
    7f716ee08135:	mov    r11d,edx
    7f716ee08138:	and    r11d,0x100
    7f716ee0813f:	shl    r11d,0x15
    7f716ee08143:	or     r10d,r11d
    7f716ee08146:	and    edx,0x1
    7f716ee08149:	shl    edx,0x1c
    7f716ee0814c:	or     r10d,edx
    7f716ee0814f:	btc    r10,0x1d
    7f716ee08154:	mov    r11d,0xf0000000
    7f716ee0815a:	and    r11,r10
    7f716ee0815d:	movabs rsi,0xffffffff0fffffff
    7f716ee08167:	and    rbx,rsi
    7f716ee0816a:	or     rbx,r11
    7f716ee0816d:	pop    r11
    7f716ee0816f:	pop    r10
    7f716ee08171:	pop    rsi
    7f716ee08172:	pop    rdx
    7f716ee08173:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0817b:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee08181:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee08186:	test   r10d,0x3f
    7f716ee0818d:	je     0x7f716ee081b2
    7f716ee08193:	mov    r11d,r10d
    7f716ee08196:	shr    r10d,1
    7f716ee08199:	and    r10d,0x1e
    7f716ee0819d:	and    r11d,0x1
    7f716ee081a1:	or     r10d,r11d
    7f716ee081a4:	or     DWORD PTR [r12+0x314],r10d
    7f716ee081ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee081b2:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee081b8:	lea    rdi,[rsp+0x110]
    7f716ee081c0:	lea    rsi,[rsp+0xf0]
    7f716ee081c8:	lea    rdx,[rsp+0x100]
    7f716ee081d0:	mov    ecx,0x56
    7f716ee081d5:	mov    r8d,0x0
    7f716ee081db:	lea    r9,[r12+0x314]
    7f716ee081e3:	movabs r11,0x5fdfb8a5e650
    7f716ee081ed:	call   r11
    7f716ee081f0:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee081f6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee081fc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee08202:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee08208:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee0820e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee08214:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee0821e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee08228:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee08232:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0823a:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee08246:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0824f:	mov    rdx,rbx
    7f716ee08252:	shr    rdx,0x10
    7f716ee08256:	and    edx,0xc000
    7f716ee0825c:	mov    rax,rbx
    7f716ee0825f:	shr    rax,0x15
    7f716ee08263:	and    eax,0x100
    7f716ee08268:	xor    eax,0x100
    7f716ee0826d:	or     edx,eax
    7f716ee0826f:	mov    rax,rbx
    7f716ee08272:	shr    rax,0x1c
    7f716ee08276:	and    eax,0x1
    7f716ee08279:	or     edx,eax
    7f716ee0827b:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee08280:	add    rsp,0x8
    7f716ee08284:	ret
    7f716ee08285:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee08290:	sub    rsp,0x8
    7f716ee08294:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee082a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee082a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee082ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee082b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee082b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee082be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee082c4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee082ce:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee082d8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee082e2:	push   rdx
    7f716ee082e3:	push   rsi
    7f716ee082e4:	push   r10
    7f716ee082e6:	push   r11
    7f716ee082e8:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee082ed:	mov    r10d,edx
    7f716ee082f0:	and    r10d,0xc000
    7f716ee082f7:	shl    r10d,0x10
    7f716ee082fb:	mov    r11d,edx
    7f716ee082fe:	and    r11d,0x100
    7f716ee08305:	shl    r11d,0x15
    7f716ee08309:	or     r10d,r11d
    7f716ee0830c:	and    edx,0x1
    7f716ee0830f:	shl    edx,0x1c
    7f716ee08312:	or     r10d,edx
    7f716ee08315:	btc    r10,0x1d
    7f716ee0831a:	mov    r11d,0xf0000000
    7f716ee08320:	and    r11,r10
    7f716ee08323:	movabs rsi,0xffffffff0fffffff
    7f716ee0832d:	and    rbx,rsi
    7f716ee08330:	or     rbx,r11
    7f716ee08333:	pop    r11
    7f716ee08335:	pop    r10
    7f716ee08337:	pop    rsi
    7f716ee08338:	pop    rdx
    7f716ee08339:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee08341:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee08347:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0834c:	test   r10d,0x3f
    7f716ee08353:	je     0x7f716ee08378
    7f716ee08359:	mov    r11d,r10d
    7f716ee0835c:	shr    r10d,1
    7f716ee0835f:	and    r10d,0x1e
    7f716ee08363:	and    r11d,0x1
    7f716ee08367:	or     r10d,r11d
    7f716ee0836a:	or     DWORD PTR [r12+0x314],r10d
    7f716ee08372:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee08378:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee0837e:	lea    rdi,[rsp+0x110]
    7f716ee08386:	lea    rsi,[rsp+0xf0]
    7f716ee0838e:	lea    rdx,[rsp+0x100]
    7f716ee08396:	mov    ecx,0x56
    7f716ee0839b:	mov    r8d,0x0
    7f716ee083a1:	lea    r9,[r12+0x314]
    7f716ee083a9:	movabs r11,0x5fdfb8a5e650
    7f716ee083b3:	call   r11
    7f716ee083b6:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee083bc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee083c2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee083c8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee083ce:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee083d4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee083da:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee083e0:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee083ea:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee083f4:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee083fe:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee08406:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee08412:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0841b:	mov    rdx,rbx
    7f716ee0841e:	shr    rdx,0x10
    7f716ee08422:	and    edx,0xc000
    7f716ee08428:	mov    rax,rbx
    7f716ee0842b:	shr    rax,0x15
    7f716ee0842f:	and    eax,0x100
    7f716ee08434:	xor    eax,0x100
    7f716ee08439:	or     edx,eax
    7f716ee0843b:	mov    rax,rbx
    7f716ee0843e:	shr    rax,0x1c
    7f716ee08442:	and    eax,0x1
    7f716ee08445:	or     edx,eax
    7f716ee08447:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee0844c:	add    rsp,0x8
    7f716ee08450:	ret
    7f716ee08451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee08460:	sub    rsp,0x8
    7f716ee08464:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee08470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee08476:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0847c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee08482:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee08488:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee0848e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee08498:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee084a2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee084ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee084b6:	push   rdx
    7f716ee084b7:	push   rsi
    7f716ee084b8:	push   r10
    7f716ee084ba:	push   r11
    7f716ee084bc:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee084c1:	mov    r10d,edx
    7f716ee084c4:	and    r10d,0xc000
    7f716ee084cb:	shl    r10d,0x10
    7f716ee084cf:	mov    r11d,edx
    7f716ee084d2:	and    r11d,0x100
    7f716ee084d9:	shl    r11d,0x15
    7f716ee084dd:	or     r10d,r11d
    7f716ee084e0:	and    edx,0x1
    7f716ee084e3:	shl    edx,0x1c
    7f716ee084e6:	or     r10d,edx
    7f716ee084e9:	btc    r10,0x1d
    7f716ee084ee:	mov    r11d,0xf0000000
    7f716ee084f4:	and    r11,r10
    7f716ee084f7:	movabs rsi,0xffffffff0fffffff
    7f716ee08501:	and    rbx,rsi
    7f716ee08504:	or     rbx,r11
    7f716ee08507:	pop    r11
    7f716ee08509:	pop    r10
    7f716ee0850b:	pop    rsi
    7f716ee0850c:	pop    rdx
    7f716ee0850d:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee08515:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0851b:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee08520:	test   r10d,0x3f
    7f716ee08527:	je     0x7f716ee0854c
    7f716ee0852d:	mov    r11d,r10d
    7f716ee08530:	shr    r10d,1
    7f716ee08533:	and    r10d,0x1e
    7f716ee08537:	and    r11d,0x1
    7f716ee0853b:	or     r10d,r11d
    7f716ee0853e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee08546:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0854c:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee08552:	lea    rdi,[rsp+0x110]
    7f716ee0855a:	lea    rsi,[rsp+0xf0]
    7f716ee08562:	lea    rdx,[rsp+0x100]
    7f716ee0856a:	mov    ecx,0x14
    7f716ee0856f:	mov    r8d,0x0
    7f716ee08575:	lea    r9,[r12+0x314]
    7f716ee0857d:	movabs r11,0x5fdfb8a5e650
    7f716ee08587:	call   r11
    7f716ee0858a:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee08590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee08596:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee0859c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee085a2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee085a8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee085ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee085b8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee085c2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee085cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee085d6:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee085de:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee085ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee085f3:	mov    rdx,rbx
    7f716ee085f6:	shr    rdx,0x10
    7f716ee085fa:	and    edx,0xc000
    7f716ee08600:	mov    rax,rbx
    7f716ee08603:	shr    rax,0x15
    7f716ee08607:	and    eax,0x100
    7f716ee0860c:	xor    eax,0x100
    7f716ee08611:	or     edx,eax
    7f716ee08613:	mov    rax,rbx
    7f716ee08616:	shr    rax,0x1c
    7f716ee0861a:	and    eax,0x1
    7f716ee0861d:	or     edx,eax
    7f716ee0861f:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee08624:	add    rsp,0x8
    7f716ee08628:	ret
    7f716ee08629:	nop    DWORD PTR [rax+0x0]
    7f716ee08630:	sub    rsp,0x8
    7f716ee08634:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee08640:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee08646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee0864c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee08652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee08658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee0865e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee08668:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee08672:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee0867c:	push   rdx
    7f716ee0867d:	push   rsi
    7f716ee0867e:	push   r10
    7f716ee08680:	push   r11
    7f716ee08682:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee08687:	mov    r10d,edx
    7f716ee0868a:	and    r10d,0xc000
    7f716ee08691:	shl    r10d,0x10
    7f716ee08695:	mov    r11d,edx
    7f716ee08698:	and    r11d,0x100
    7f716ee0869f:	shl    r11d,0x15
    7f716ee086a3:	or     r10d,r11d
    7f716ee086a6:	and    edx,0x1
    7f716ee086a9:	shl    edx,0x1c
    7f716ee086ac:	or     r10d,edx
    7f716ee086af:	btc    r10,0x1d
    7f716ee086b4:	mov    r11d,0xf0000000
    7f716ee086ba:	and    r11,r10
    7f716ee086bd:	movabs rsi,0xffffffff0fffffff
    7f716ee086c7:	and    rbx,rsi
    7f716ee086ca:	or     rbx,r11
    7f716ee086cd:	pop    r11
    7f716ee086cf:	pop    r10
    7f716ee086d1:	pop    rsi
    7f716ee086d2:	pop    rdx
    7f716ee086d3:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee086db:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee086e1:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee086e6:	test   r10d,0x3f
    7f716ee086ed:	je     0x7f716ee08712
    7f716ee086f3:	mov    r11d,r10d
    7f716ee086f6:	shr    r10d,1
    7f716ee086f9:	and    r10d,0x1e
    7f716ee086fd:	and    r11d,0x1
    7f716ee08701:	or     r10d,r11d
    7f716ee08704:	or     DWORD PTR [r12+0x314],r10d
    7f716ee0870c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee08712:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee08718:	lea    rdi,[rsp+0x110]
    7f716ee08720:	lea    rsi,[rsp+0xf0]
    7f716ee08728:	lea    rdx,[rsp+0x100]
    7f716ee08730:	mov    ecx,0x14
    7f716ee08735:	mov    r8d,0x0
    7f716ee0873b:	lea    r9,[r12+0x314]
    7f716ee08743:	movabs r11,0x5fdfb8a5e650
    7f716ee0874d:	call   r11
    7f716ee08750:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee08756:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee0875c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee08762:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee08768:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee0876e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee08774:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee0877e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee08788:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee08792:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0879a:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee087a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee087af:	mov    rdx,rbx
    7f716ee087b2:	shr    rdx,0x10
    7f716ee087b6:	and    edx,0xc000
    7f716ee087bc:	mov    rax,rbx
    7f716ee087bf:	shr    rax,0x15
    7f716ee087c3:	and    eax,0x100
    7f716ee087c8:	xor    eax,0x100
    7f716ee087cd:	or     edx,eax
    7f716ee087cf:	mov    rax,rbx
    7f716ee087d2:	shr    rax,0x1c
    7f716ee087d6:	and    eax,0x1
    7f716ee087d9:	or     edx,eax
    7f716ee087db:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee087e0:	add    rsp,0x8
    7f716ee087e4:	ret
    7f716ee087e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee087f0:	sub    rsp,0x8
    7f716ee087f4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee08800:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee08806:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0880c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee08812:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee08818:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee0881e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee08824:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee0882e:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee08838:	push   rdx
    7f716ee08839:	push   rsi
    7f716ee0883a:	push   r10
    7f716ee0883c:	push   r11
    7f716ee0883e:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee08843:	mov    r10d,edx
    7f716ee08846:	and    r10d,0xc000
    7f716ee0884d:	shl    r10d,0x10
    7f716ee08851:	mov    r11d,edx
    7f716ee08854:	and    r11d,0x100
    7f716ee0885b:	shl    r11d,0x15
    7f716ee0885f:	or     r10d,r11d
    7f716ee08862:	and    edx,0x1
    7f716ee08865:	shl    edx,0x1c
    7f716ee08868:	or     r10d,edx
    7f716ee0886b:	btc    r10,0x1d
    7f716ee08870:	mov    r11d,0xf0000000
    7f716ee08876:	and    r11,r10
    7f716ee08879:	movabs rsi,0xffffffff0fffffff
    7f716ee08883:	and    rbx,rsi
    7f716ee08886:	or     rbx,r11
    7f716ee08889:	pop    r11
    7f716ee0888b:	pop    r10
    7f716ee0888d:	pop    rsi
    7f716ee0888e:	pop    rdx
    7f716ee0888f:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee08897:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0889d:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee088a2:	test   r10d,0x3f
    7f716ee088a9:	je     0x7f716ee088ce
    7f716ee088af:	mov    r11d,r10d
    7f716ee088b2:	shr    r10d,1
    7f716ee088b5:	and    r10d,0x1e
    7f716ee088b9:	and    r11d,0x1
    7f716ee088bd:	or     r10d,r11d
    7f716ee088c0:	or     DWORD PTR [r12+0x314],r10d
    7f716ee088c8:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee088ce:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee088d4:	lea    rdi,[rsp+0x110]
    7f716ee088dc:	lea    rsi,[rsp+0xf0]
    7f716ee088e4:	lea    rdx,[rsp+0x100]
    7f716ee088ec:	mov    ecx,0x56
    7f716ee088f1:	mov    r8d,0x0
    7f716ee088f7:	lea    r9,[r12+0x314]
    7f716ee088ff:	movabs r11,0x5fdfb8a5e650
    7f716ee08909:	call   r11
    7f716ee0890c:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee08912:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee08918:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee0891e:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee08924:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee0892a:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee08930:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee08936:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee08940:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee0894a:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee08952:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0895e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee08967:	mov    rdx,rbx
    7f716ee0896a:	shr    rdx,0x10
    7f716ee0896e:	and    edx,0xc000
    7f716ee08974:	mov    rax,rbx
    7f716ee08977:	shr    rax,0x15
    7f716ee0897b:	and    eax,0x100
    7f716ee08980:	xor    eax,0x100
    7f716ee08985:	or     edx,eax
    7f716ee08987:	mov    rax,rbx
    7f716ee0898a:	shr    rax,0x1c
    7f716ee0898e:	and    eax,0x1
    7f716ee08991:	or     edx,eax
    7f716ee08993:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee08998:	add    rsp,0x8
    7f716ee0899c:	ret
    7f716ee0899d:	nop    DWORD PTR [rax]
    7f716ee089a0:	sub    rsp,0x8
    7f716ee089a4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee089b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee089b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee089bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee089c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee089c8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee089ce:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee089d4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee089de:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee089e8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee089f2:	push   rdx
    7f716ee089f3:	push   rsi
    7f716ee089f4:	push   r10
    7f716ee089f6:	push   r11
    7f716ee089f8:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee089fd:	mov    r10d,edx
    7f716ee08a00:	and    r10d,0xc000
    7f716ee08a07:	shl    r10d,0x10
    7f716ee08a0b:	mov    r11d,edx
    7f716ee08a0e:	and    r11d,0x100
    7f716ee08a15:	shl    r11d,0x15
    7f716ee08a19:	or     r10d,r11d
    7f716ee08a1c:	and    edx,0x1
    7f716ee08a1f:	shl    edx,0x1c
    7f716ee08a22:	or     r10d,edx
    7f716ee08a25:	btc    r10,0x1d
    7f716ee08a2a:	mov    r11d,0xf0000000
    7f716ee08a30:	and    r11,r10
    7f716ee08a33:	movabs rsi,0xffffffff0fffffff
    7f716ee08a3d:	and    rbx,rsi
    7f716ee08a40:	or     rbx,r11
    7f716ee08a43:	pop    r11
    7f716ee08a45:	pop    r10
    7f716ee08a47:	pop    rsi
    7f716ee08a48:	pop    rdx
    7f716ee08a49:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee08a51:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee08a57:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee08a5c:	test   r10d,0x3f
    7f716ee08a63:	je     0x7f716ee08a88
    7f716ee08a69:	mov    r11d,r10d
    7f716ee08a6c:	shr    r10d,1
    7f716ee08a6f:	and    r10d,0x1e
    7f716ee08a73:	and    r11d,0x1
    7f716ee08a77:	or     r10d,r11d
    7f716ee08a7a:	or     DWORD PTR [r12+0x314],r10d
    7f716ee08a82:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee08a88:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee08a8e:	lea    rdi,[rsp+0x110]
    7f716ee08a96:	lea    rsi,[rsp+0xf0]
    7f716ee08a9e:	lea    rdx,[rsp+0x100]
    7f716ee08aa6:	mov    ecx,0x14
    7f716ee08aab:	mov    r8d,0x0
    7f716ee08ab1:	lea    r9,[r12+0x314]
    7f716ee08ab9:	movabs r11,0x5fdfb8a5e650
    7f716ee08ac3:	call   r11
    7f716ee08ac6:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee08acc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee08ad2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee08ad8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee08ade:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee08ae4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee08aea:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee08af0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee08afa:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee08b04:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee08b0e:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee08b16:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee08b22:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee08b2b:	mov    rdx,rbx
    7f716ee08b2e:	shr    rdx,0x10
    7f716ee08b32:	and    edx,0xc000
    7f716ee08b38:	mov    rax,rbx
    7f716ee08b3b:	shr    rax,0x15
    7f716ee08b3f:	and    eax,0x100
    7f716ee08b44:	xor    eax,0x100
    7f716ee08b49:	or     edx,eax
    7f716ee08b4b:	mov    rax,rbx
    7f716ee08b4e:	shr    rax,0x1c
    7f716ee08b52:	and    eax,0x1
    7f716ee08b55:	or     edx,eax
    7f716ee08b57:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee08b5c:	add    rsp,0x8
    7f716ee08b60:	ret
    7f716ee08b61:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee08b70:	sub    rsp,0x8
    7f716ee08b74:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee08b80:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee08b86:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee08b8c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee08b92:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee08b98:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee08ba2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee08bac:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee08bb6:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee08bc0:	push   rdx
    7f716ee08bc1:	push   rsi
    7f716ee08bc2:	push   r10
    7f716ee08bc4:	push   r11
    7f716ee08bc6:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee08bcb:	mov    r10d,edx
    7f716ee08bce:	and    r10d,0xc000
    7f716ee08bd5:	shl    r10d,0x10
    7f716ee08bd9:	mov    r11d,edx
    7f716ee08bdc:	and    r11d,0x100
    7f716ee08be3:	shl    r11d,0x15
    7f716ee08be7:	or     r10d,r11d
    7f716ee08bea:	and    edx,0x1
    7f716ee08bed:	shl    edx,0x1c
    7f716ee08bf0:	or     r10d,edx
    7f716ee08bf3:	btc    r10,0x1d
    7f716ee08bf8:	mov    r11d,0xf0000000
    7f716ee08bfe:	and    r11,r10
    7f716ee08c01:	movabs rsi,0xffffffff0fffffff
    7f716ee08c0b:	and    rbx,rsi
    7f716ee08c0e:	or     rbx,r11
    7f716ee08c11:	pop    r11
    7f716ee08c13:	pop    r10
    7f716ee08c15:	pop    rsi
    7f716ee08c16:	pop    rdx
    7f716ee08c17:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee08c1f:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee08c25:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee08c2a:	test   r10d,0x3f
    7f716ee08c31:	je     0x7f716ee08c56
    7f716ee08c37:	mov    r11d,r10d
    7f716ee08c3a:	shr    r10d,1
    7f716ee08c3d:	and    r10d,0x1e
    7f716ee08c41:	and    r11d,0x1
    7f716ee08c45:	or     r10d,r11d
    7f716ee08c48:	or     DWORD PTR [r12+0x314],r10d
    7f716ee08c50:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee08c56:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee08c5c:	lea    rdi,[rsp+0x110]
    7f716ee08c64:	lea    rsi,[rsp+0xf0]
    7f716ee08c6c:	lea    rdx,[rsp+0x100]
    7f716ee08c74:	mov    ecx,0x14
    7f716ee08c79:	mov    r8d,0x0
    7f716ee08c7f:	lea    r9,[r12+0x314]
    7f716ee08c87:	movabs r11,0x5fdfb8a5e650
    7f716ee08c91:	call   r11
    7f716ee08c94:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee08c9a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee08ca0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee08ca6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee08cac:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee08cb2:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee08cbc:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee08cc6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee08cd0:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee08cda:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee08ce2:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee08cee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee08cf7:	mov    rdx,rbx
    7f716ee08cfa:	shr    rdx,0x10
    7f716ee08cfe:	and    edx,0xc000
    7f716ee08d04:	mov    rax,rbx
    7f716ee08d07:	shr    rax,0x15
    7f716ee08d0b:	and    eax,0x100
    7f716ee08d10:	xor    eax,0x100
    7f716ee08d15:	or     edx,eax
    7f716ee08d17:	mov    rax,rbx
    7f716ee08d1a:	shr    rax,0x1c
    7f716ee08d1e:	and    eax,0x1
    7f716ee08d21:	or     edx,eax
    7f716ee08d23:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee08d28:	add    rsp,0x8
    7f716ee08d2c:	ret
    7f716ee08d2d:	nop    DWORD PTR [rax]
    7f716ee08d30:	sub    rsp,0x8
    7f716ee08d34:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee08d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee08d46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee08d4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee08d52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee08d58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee08d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee08d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee08d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee08d7c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee08d86:	push   rdx
    7f716ee08d87:	push   rsi
    7f716ee08d88:	push   r10
    7f716ee08d8a:	push   r11
    7f716ee08d8c:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee08d91:	mov    r10d,edx
    7f716ee08d94:	and    r10d,0xc000
    7f716ee08d9b:	shl    r10d,0x10
    7f716ee08d9f:	mov    r11d,edx
    7f716ee08da2:	and    r11d,0x100
    7f716ee08da9:	shl    r11d,0x15
    7f716ee08dad:	or     r10d,r11d
    7f716ee08db0:	and    edx,0x1
    7f716ee08db3:	shl    edx,0x1c
    7f716ee08db6:	or     r10d,edx
    7f716ee08db9:	btc    r10,0x1d
    7f716ee08dbe:	mov    r11d,0xf0000000
    7f716ee08dc4:	and    r11,r10
    7f716ee08dc7:	movabs rsi,0xffffffff0fffffff
    7f716ee08dd1:	and    rbx,rsi
    7f716ee08dd4:	or     rbx,r11
    7f716ee08dd7:	pop    r11
    7f716ee08dd9:	pop    r10
    7f716ee08ddb:	pop    rsi
    7f716ee08ddc:	pop    rdx
    7f716ee08ddd:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee08de5:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee08deb:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee08df0:	test   r10d,0x3f
    7f716ee08df7:	je     0x7f716ee08e1c
    7f716ee08dfd:	mov    r11d,r10d
    7f716ee08e00:	shr    r10d,1
    7f716ee08e03:	and    r10d,0x1e
    7f716ee08e07:	and    r11d,0x1
    7f716ee08e0b:	or     r10d,r11d
    7f716ee08e0e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee08e16:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee08e1c:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee08e22:	lea    rdi,[rsp+0x110]
    7f716ee08e2a:	lea    rsi,[rsp+0xf0]
    7f716ee08e32:	lea    rdx,[rsp+0x100]
    7f716ee08e3a:	mov    ecx,0x14
    7f716ee08e3f:	mov    r8d,0x0
    7f716ee08e45:	lea    r9,[r12+0x314]
    7f716ee08e4d:	movabs r11,0x5fdfb8a5e650
    7f716ee08e57:	call   r11
    7f716ee08e5a:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee08e60:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee08e66:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee08e6c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee08e72:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee08e78:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee08e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee08e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee08e92:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee08e9c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee08ea6:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee08eae:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee08eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee08ec3:	mov    rdx,rbx
    7f716ee08ec6:	shr    rdx,0x10
    7f716ee08eca:	and    edx,0xc000
    7f716ee08ed0:	mov    rax,rbx
    7f716ee08ed3:	shr    rax,0x15
    7f716ee08ed7:	and    eax,0x100
    7f716ee08edc:	xor    eax,0x100
    7f716ee08ee1:	or     edx,eax
    7f716ee08ee3:	mov    rax,rbx
    7f716ee08ee6:	shr    rax,0x1c
    7f716ee08eea:	and    eax,0x1
    7f716ee08eed:	or     edx,eax
    7f716ee08eef:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee08ef4:	add    rsp,0x8
    7f716ee08ef8:	ret
    7f716ee08ef9:	nop    DWORD PTR [rax+0x0]
    7f716ee08f00:	sub    rsp,0x8
    7f716ee08f04:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee08f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee08f16:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee08f1c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee08f22:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee08f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee08f2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee08f38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee08f42:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee08f4c:	push   rdx
    7f716ee08f4d:	push   rsi
    7f716ee08f4e:	push   r10
    7f716ee08f50:	push   r11
    7f716ee08f52:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee08f57:	mov    r10d,edx
    7f716ee08f5a:	and    r10d,0xc000
    7f716ee08f61:	shl    r10d,0x10
    7f716ee08f65:	mov    r11d,edx
    7f716ee08f68:	and    r11d,0x100
    7f716ee08f6f:	shl    r11d,0x15
    7f716ee08f73:	or     r10d,r11d
    7f716ee08f76:	and    edx,0x1
    7f716ee08f79:	shl    edx,0x1c
    7f716ee08f7c:	or     r10d,edx
    7f716ee08f7f:	btc    r10,0x1d
    7f716ee08f84:	mov    r11d,0xf0000000
    7f716ee08f8a:	and    r11,r10
    7f716ee08f8d:	movabs rsi,0xffffffff0fffffff
    7f716ee08f97:	and    rbx,rsi
    7f716ee08f9a:	or     rbx,r11
    7f716ee08f9d:	pop    r11
    7f716ee08f9f:	pop    r10
    7f716ee08fa1:	pop    rsi
    7f716ee08fa2:	pop    rdx
    7f716ee08fa3:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee08fab:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee08fb1:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee08fb6:	test   r10d,0x3f
    7f716ee08fbd:	je     0x7f716ee08fe2
    7f716ee08fc3:	mov    r11d,r10d
    7f716ee08fc6:	shr    r10d,1
    7f716ee08fc9:	and    r10d,0x1e
    7f716ee08fcd:	and    r11d,0x1
    7f716ee08fd1:	or     r10d,r11d
    7f716ee08fd4:	or     DWORD PTR [r12+0x314],r10d
    7f716ee08fdc:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee08fe2:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee08fe8:	lea    rdi,[rsp+0x110]
    7f716ee08ff0:	lea    rsi,[rsp+0xf0]
    7f716ee08ff8:	lea    rdx,[rsp+0x100]
    7f716ee09000:	mov    ecx,0x56
    7f716ee09005:	mov    r8d,0x0
    7f716ee0900b:	lea    r9,[r12+0x314]
    7f716ee09013:	movabs r11,0x5fdfb8a5e650
    7f716ee0901d:	call   r11
    7f716ee09020:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee09026:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee0902c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee09032:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee09038:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee0903e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee09044:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee0904e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee09058:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee09062:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0906a:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee09076:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0907f:	mov    rdx,rbx
    7f716ee09082:	shr    rdx,0x10
    7f716ee09086:	and    edx,0xc000
    7f716ee0908c:	mov    rax,rbx
    7f716ee0908f:	shr    rax,0x15
    7f716ee09093:	and    eax,0x100
    7f716ee09098:	xor    eax,0x100
    7f716ee0909d:	or     edx,eax
    7f716ee0909f:	mov    rax,rbx
    7f716ee090a2:	shr    rax,0x1c
    7f716ee090a6:	and    eax,0x1
    7f716ee090a9:	or     edx,eax
    7f716ee090ab:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee090b0:	add    rsp,0x8
    7f716ee090b4:	ret
    7f716ee090b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee090c0:	sub    rsp,0x8
    7f716ee090c4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee090d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee090d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee090dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee090e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee090e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee090ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee090f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee09102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee0910c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee09116:	push   rdx
    7f716ee09117:	push   rsi
    7f716ee09118:	push   r10
    7f716ee0911a:	push   r11
    7f716ee0911c:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee09121:	mov    r10d,edx
    7f716ee09124:	and    r10d,0xc000
    7f716ee0912b:	shl    r10d,0x10
    7f716ee0912f:	mov    r11d,edx
    7f716ee09132:	and    r11d,0x100
    7f716ee09139:	shl    r11d,0x15
    7f716ee0913d:	or     r10d,r11d
    7f716ee09140:	and    edx,0x1
    7f716ee09143:	shl    edx,0x1c
    7f716ee09146:	or     r10d,edx
    7f716ee09149:	btc    r10,0x1d
    7f716ee0914e:	mov    r11d,0xf0000000
    7f716ee09154:	and    r11,r10
    7f716ee09157:	movabs rsi,0xffffffff0fffffff
    7f716ee09161:	and    rbx,rsi
    7f716ee09164:	or     rbx,r11
    7f716ee09167:	pop    r11
    7f716ee09169:	pop    r10
    7f716ee0916b:	pop    rsi
    7f716ee0916c:	pop    rdx
    7f716ee0916d:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee09175:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0917b:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee09180:	test   r10d,0x3f
    7f716ee09187:	je     0x7f716ee091ac
    7f716ee0918d:	mov    r11d,r10d
    7f716ee09190:	shr    r10d,1
    7f716ee09193:	and    r10d,0x1e
    7f716ee09197:	and    r11d,0x1
    7f716ee0919b:	or     r10d,r11d
    7f716ee0919e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee091a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee091ac:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee091b2:	lea    rdi,[rsp+0x110]
    7f716ee091ba:	lea    rsi,[rsp+0xf0]
    7f716ee091c2:	lea    rdx,[rsp+0x100]
    7f716ee091ca:	mov    ecx,0x56
    7f716ee091cf:	mov    r8d,0x0
    7f716ee091d5:	lea    r9,[r12+0x314]
    7f716ee091dd:	movabs r11,0x5fdfb8a5e650
    7f716ee091e7:	call   r11
    7f716ee091ea:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee091f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee091f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee091fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee09202:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee09208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee0920e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee09218:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee09222:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee0922c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee09236:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0923e:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0924a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee09253:	mov    rdx,rbx
    7f716ee09256:	shr    rdx,0x10
    7f716ee0925a:	and    edx,0xc000
    7f716ee09260:	mov    rax,rbx
    7f716ee09263:	shr    rax,0x15
    7f716ee09267:	and    eax,0x100
    7f716ee0926c:	xor    eax,0x100
    7f716ee09271:	or     edx,eax
    7f716ee09273:	mov    rax,rbx
    7f716ee09276:	shr    rax,0x1c
    7f716ee0927a:	and    eax,0x1
    7f716ee0927d:	or     edx,eax
    7f716ee0927f:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee09284:	add    rsp,0x8
    7f716ee09288:	ret
    7f716ee09289:	nop    DWORD PTR [rax+0x0]
    7f716ee09290:	sub    rsp,0x8
    7f716ee09294:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee092a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee092a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee092ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee092b2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee092b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee092be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee092c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee092d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee092dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee092e6:	push   rdx
    7f716ee092e7:	push   rsi
    7f716ee092e8:	push   r10
    7f716ee092ea:	push   r11
    7f716ee092ec:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee092f1:	mov    r10d,edx
    7f716ee092f4:	and    r10d,0xc000
    7f716ee092fb:	shl    r10d,0x10
    7f716ee092ff:	mov    r11d,edx
    7f716ee09302:	and    r11d,0x100
    7f716ee09309:	shl    r11d,0x15
    7f716ee0930d:	or     r10d,r11d
    7f716ee09310:	and    edx,0x1
    7f716ee09313:	shl    edx,0x1c
    7f716ee09316:	or     r10d,edx
    7f716ee09319:	btc    r10,0x1d
    7f716ee0931e:	mov    r11d,0xf0000000
    7f716ee09324:	and    r11,r10
    7f716ee09327:	movabs rsi,0xffffffff0fffffff
    7f716ee09331:	and    rbx,rsi
    7f716ee09334:	or     rbx,r11
    7f716ee09337:	pop    r11
    7f716ee09339:	pop    r10
    7f716ee0933b:	pop    rsi
    7f716ee0933c:	pop    rdx
    7f716ee0933d:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee09345:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0934b:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee09350:	test   r10d,0x3f
    7f716ee09357:	je     0x7f716ee0937c
    7f716ee0935d:	mov    r11d,r10d
    7f716ee09360:	shr    r10d,1
    7f716ee09363:	and    r10d,0x1e
    7f716ee09367:	and    r11d,0x1
    7f716ee0936b:	or     r10d,r11d
    7f716ee0936e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee09376:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0937c:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee09382:	lea    rdi,[rsp+0x110]
    7f716ee0938a:	lea    rsi,[rsp+0xf0]
    7f716ee09392:	lea    rdx,[rsp+0x100]
    7f716ee0939a:	mov    ecx,0x14
    7f716ee0939f:	mov    r8d,0x0
    7f716ee093a5:	lea    r9,[r12+0x314]
    7f716ee093ad:	movabs r11,0x5fdfb8a5e650
    7f716ee093b7:	call   r11
    7f716ee093ba:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee093c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee093c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee093cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee093d2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee093d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee093de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee093e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee093f2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee093fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee09406:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0940e:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0941a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee09423:	mov    rdx,rbx
    7f716ee09426:	shr    rdx,0x10
    7f716ee0942a:	and    edx,0xc000
    7f716ee09430:	mov    rax,rbx
    7f716ee09433:	shr    rax,0x15
    7f716ee09437:	and    eax,0x100
    7f716ee0943c:	xor    eax,0x100
    7f716ee09441:	or     edx,eax
    7f716ee09443:	mov    rax,rbx
    7f716ee09446:	shr    rax,0x1c
    7f716ee0944a:	and    eax,0x1
    7f716ee0944d:	or     edx,eax
    7f716ee0944f:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee09454:	add    rsp,0x8
    7f716ee09458:	ret
    7f716ee09459:	nop    DWORD PTR [rax+0x0]
    7f716ee09460:	sub    rsp,0x8
    7f716ee09464:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee09470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee09476:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0947c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee09482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee09488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee0948e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee09498:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee094a2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee094ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee094b6:	push   rdx
    7f716ee094b7:	push   rsi
    7f716ee094b8:	push   r10
    7f716ee094ba:	push   r11
    7f716ee094bc:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee094c1:	mov    r10d,edx
    7f716ee094c4:	and    r10d,0xc000
    7f716ee094cb:	shl    r10d,0x10
    7f716ee094cf:	mov    r11d,edx
    7f716ee094d2:	and    r11d,0x100
    7f716ee094d9:	shl    r11d,0x15
    7f716ee094dd:	or     r10d,r11d
    7f716ee094e0:	and    edx,0x1
    7f716ee094e3:	shl    edx,0x1c
    7f716ee094e6:	or     r10d,edx
    7f716ee094e9:	btc    r10,0x1d
    7f716ee094ee:	mov    r11d,0xf0000000
    7f716ee094f4:	and    r11,r10
    7f716ee094f7:	movabs rsi,0xffffffff0fffffff
    7f716ee09501:	and    rbx,rsi
    7f716ee09504:	or     rbx,r11
    7f716ee09507:	pop    r11
    7f716ee09509:	pop    r10
    7f716ee0950b:	pop    rsi
    7f716ee0950c:	pop    rdx
    7f716ee0950d:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee09515:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0951b:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee09520:	test   r10d,0x3f
    7f716ee09527:	je     0x7f716ee0954c
    7f716ee0952d:	mov    r11d,r10d
    7f716ee09530:	shr    r10d,1
    7f716ee09533:	and    r10d,0x1e
    7f716ee09537:	and    r11d,0x1
    7f716ee0953b:	or     r10d,r11d
    7f716ee0953e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee09546:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0954c:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee09552:	lea    rdi,[rsp+0x110]
    7f716ee0955a:	lea    rsi,[rsp+0xf0]
    7f716ee09562:	lea    rdx,[rsp+0x100]
    7f716ee0956a:	mov    ecx,0x56
    7f716ee0956f:	mov    r8d,0x0
    7f716ee09575:	lea    r9,[r12+0x314]
    7f716ee0957d:	movabs r11,0x5fdfb8a5e650
    7f716ee09587:	call   r11
    7f716ee0958a:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee09590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee09596:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee0959c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee095a2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee095a8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee095ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee095b8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee095c2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee095cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee095d6:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee095de:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee095ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee095f3:	mov    rdx,rbx
    7f716ee095f6:	shr    rdx,0x10
    7f716ee095fa:	and    edx,0xc000
    7f716ee09600:	mov    rax,rbx
    7f716ee09603:	shr    rax,0x15
    7f716ee09607:	and    eax,0x100
    7f716ee0960c:	xor    eax,0x100
    7f716ee09611:	or     edx,eax
    7f716ee09613:	mov    rax,rbx
    7f716ee09616:	shr    rax,0x1c
    7f716ee0961a:	and    eax,0x1
    7f716ee0961d:	or     edx,eax
    7f716ee0961f:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee09624:	add    rsp,0x8
    7f716ee09628:	ret
    7f716ee09629:	nop    DWORD PTR [rax+0x0]
    7f716ee09630:	sub    rsp,0x8
    7f716ee09634:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee09640:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee09646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee0964c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee09652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee09658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee0965e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee09668:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee09672:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee0967c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee09686:	push   rdx
    7f716ee09687:	push   rsi
    7f716ee09688:	push   r10
    7f716ee0968a:	push   r11
    7f716ee0968c:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee09691:	mov    r10d,edx
    7f716ee09694:	and    r10d,0xc000
    7f716ee0969b:	shl    r10d,0x10
    7f716ee0969f:	mov    r11d,edx
    7f716ee096a2:	and    r11d,0x100
    7f716ee096a9:	shl    r11d,0x15
    7f716ee096ad:	or     r10d,r11d
    7f716ee096b0:	and    edx,0x1
    7f716ee096b3:	shl    edx,0x1c
    7f716ee096b6:	or     r10d,edx
    7f716ee096b9:	btc    r10,0x1d
    7f716ee096be:	mov    r11d,0xf0000000
    7f716ee096c4:	and    r11,r10
    7f716ee096c7:	movabs rsi,0xffffffff0fffffff
    7f716ee096d1:	and    rbx,rsi
    7f716ee096d4:	or     rbx,r11
    7f716ee096d7:	pop    r11
    7f716ee096d9:	pop    r10
    7f716ee096db:	pop    rsi
    7f716ee096dc:	pop    rdx
    7f716ee096dd:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee096e5:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee096eb:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee096f0:	test   r10d,0x3f
    7f716ee096f7:	je     0x7f716ee0971c
    7f716ee096fd:	mov    r11d,r10d
    7f716ee09700:	shr    r10d,1
    7f716ee09703:	and    r10d,0x1e
    7f716ee09707:	and    r11d,0x1
    7f716ee0970b:	or     r10d,r11d
    7f716ee0970e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee09716:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0971c:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee09722:	lea    rdi,[rsp+0x110]
    7f716ee0972a:	lea    rsi,[rsp+0xf0]
    7f716ee09732:	lea    rdx,[rsp+0x100]
    7f716ee0973a:	mov    ecx,0x14
    7f716ee0973f:	mov    r8d,0x0
    7f716ee09745:	lea    r9,[r12+0x314]
    7f716ee0974d:	movabs r11,0x5fdfb8a5e650
    7f716ee09757:	call   r11
    7f716ee0975a:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee09760:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee09766:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee0976c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee09772:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee09778:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee0977e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee09788:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee09792:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee0979c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee097a6:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee097ae:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee097ba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee097c3:	mov    rdx,rbx
    7f716ee097c6:	shr    rdx,0x10
    7f716ee097ca:	and    edx,0xc000
    7f716ee097d0:	mov    rax,rbx
    7f716ee097d3:	shr    rax,0x15
    7f716ee097d7:	and    eax,0x100
    7f716ee097dc:	xor    eax,0x100
    7f716ee097e1:	or     edx,eax
    7f716ee097e3:	mov    rax,rbx
    7f716ee097e6:	shr    rax,0x1c
    7f716ee097ea:	and    eax,0x1
    7f716ee097ed:	or     edx,eax
    7f716ee097ef:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee097f4:	add    rsp,0x8
    7f716ee097f8:	ret
    7f716ee097f9:	nop    DWORD PTR [rax+0x0]
    7f716ee09800:	sub    rsp,0x8
    7f716ee09804:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee09810:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee09816:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee0981c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee09822:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee09828:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee0982e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee09838:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee09842:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee0984c:	push   rdx
    7f716ee0984d:	push   rsi
    7f716ee0984e:	push   r10
    7f716ee09850:	push   r11
    7f716ee09852:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee09857:	mov    r10d,edx
    7f716ee0985a:	and    r10d,0xc000
    7f716ee09861:	shl    r10d,0x10
    7f716ee09865:	mov    r11d,edx
    7f716ee09868:	and    r11d,0x100
    7f716ee0986f:	shl    r11d,0x15
    7f716ee09873:	or     r10d,r11d
    7f716ee09876:	and    edx,0x1
    7f716ee09879:	shl    edx,0x1c
    7f716ee0987c:	or     r10d,edx
    7f716ee0987f:	btc    r10,0x1d
    7f716ee09884:	mov    r11d,0xf0000000
    7f716ee0988a:	and    r11,r10
    7f716ee0988d:	movabs rsi,0xffffffff0fffffff
    7f716ee09897:	and    rbx,rsi
    7f716ee0989a:	or     rbx,r11
    7f716ee0989d:	pop    r11
    7f716ee0989f:	pop    r10
    7f716ee098a1:	pop    rsi
    7f716ee098a2:	pop    rdx
    7f716ee098a3:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee098ab:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee098b1:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee098b6:	test   r10d,0x3f
    7f716ee098bd:	je     0x7f716ee098e2
    7f716ee098c3:	mov    r11d,r10d
    7f716ee098c6:	shr    r10d,1
    7f716ee098c9:	and    r10d,0x1e
    7f716ee098cd:	and    r11d,0x1
    7f716ee098d1:	or     r10d,r11d
    7f716ee098d4:	or     DWORD PTR [r12+0x314],r10d
    7f716ee098dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee098e2:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee098e8:	lea    rdi,[rsp+0x110]
    7f716ee098f0:	lea    rsi,[rsp+0xf0]
    7f716ee098f8:	lea    rdx,[rsp+0x100]
    7f716ee09900:	mov    ecx,0x14
    7f716ee09905:	mov    r8d,0x0
    7f716ee0990b:	lea    r9,[r12+0x314]
    7f716ee09913:	movabs r11,0x5fdfb8a5e650
    7f716ee0991d:	call   r11
    7f716ee09920:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee09926:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee0992c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee09932:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee09938:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee0993e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee09944:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee0994e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee09958:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee09962:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0996a:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee09976:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0997f:	mov    rdx,rbx
    7f716ee09982:	shr    rdx,0x10
    7f716ee09986:	and    edx,0xc000
    7f716ee0998c:	mov    rax,rbx
    7f716ee0998f:	shr    rax,0x15
    7f716ee09993:	and    eax,0x100
    7f716ee09998:	xor    eax,0x100
    7f716ee0999d:	or     edx,eax
    7f716ee0999f:	mov    rax,rbx
    7f716ee099a2:	shr    rax,0x1c
    7f716ee099a6:	and    eax,0x1
    7f716ee099a9:	or     edx,eax
    7f716ee099ab:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee099b0:	add    rsp,0x8
    7f716ee099b4:	ret
    7f716ee099b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee099c0:	sub    rsp,0x8
    7f716ee099c4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee099d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee099d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee099dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee099e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee099e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee099ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee099f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee09a02:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee09a0c:	push   rdx
    7f716ee09a0d:	push   rsi
    7f716ee09a0e:	push   r10
    7f716ee09a10:	push   r11
    7f716ee09a12:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee09a17:	mov    r10d,edx
    7f716ee09a1a:	and    r10d,0xc000
    7f716ee09a21:	shl    r10d,0x10
    7f716ee09a25:	mov    r11d,edx
    7f716ee09a28:	and    r11d,0x100
    7f716ee09a2f:	shl    r11d,0x15
    7f716ee09a33:	or     r10d,r11d
    7f716ee09a36:	and    edx,0x1
    7f716ee09a39:	shl    edx,0x1c
    7f716ee09a3c:	or     r10d,edx
    7f716ee09a3f:	btc    r10,0x1d
    7f716ee09a44:	mov    r11d,0xf0000000
    7f716ee09a4a:	and    r11,r10
    7f716ee09a4d:	movabs rsi,0xffffffff0fffffff
    7f716ee09a57:	and    rbx,rsi
    7f716ee09a5a:	or     rbx,r11
    7f716ee09a5d:	pop    r11
    7f716ee09a5f:	pop    r10
    7f716ee09a61:	pop    rsi
    7f716ee09a62:	pop    rdx
    7f716ee09a63:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee09a6b:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee09a71:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee09a76:	test   r10d,0x3f
    7f716ee09a7d:	je     0x7f716ee09aa2
    7f716ee09a83:	mov    r11d,r10d
    7f716ee09a86:	shr    r10d,1
    7f716ee09a89:	and    r10d,0x1e
    7f716ee09a8d:	and    r11d,0x1
    7f716ee09a91:	or     r10d,r11d
    7f716ee09a94:	or     DWORD PTR [r12+0x314],r10d
    7f716ee09a9c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee09aa2:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee09aa8:	lea    rdi,[rsp+0x110]
    7f716ee09ab0:	lea    rsi,[rsp+0xf0]
    7f716ee09ab8:	lea    rdx,[rsp+0x100]
    7f716ee09ac0:	mov    ecx,0x14
    7f716ee09ac5:	mov    r8d,0x0
    7f716ee09acb:	lea    r9,[r12+0x314]
    7f716ee09ad3:	movabs r11,0x5fdfb8a5e650
    7f716ee09add:	call   r11
    7f716ee09ae0:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee09ae6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee09aec:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee09af2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee09af8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee09afe:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee09b04:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee09b0e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee09b18:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee09b22:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee09b2a:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee09b36:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee09b3f:	mov    rdx,rbx
    7f716ee09b42:	shr    rdx,0x10
    7f716ee09b46:	and    edx,0xc000
    7f716ee09b4c:	mov    rax,rbx
    7f716ee09b4f:	shr    rax,0x15
    7f716ee09b53:	and    eax,0x100
    7f716ee09b58:	xor    eax,0x100
    7f716ee09b5d:	or     edx,eax
    7f716ee09b5f:	mov    rax,rbx
    7f716ee09b62:	shr    rax,0x1c
    7f716ee09b66:	and    eax,0x1
    7f716ee09b69:	or     edx,eax
    7f716ee09b6b:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee09b70:	add    rsp,0x8
    7f716ee09b74:	ret
    7f716ee09b75:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee09b80:	sub    rsp,0x8
    7f716ee09b84:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee09b90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee09b96:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee09b9c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee09ba2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee09ba8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee09bae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee09bb4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee09bbe:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee09bc8:	push   rdx
    7f716ee09bc9:	push   rsi
    7f716ee09bca:	push   r10
    7f716ee09bcc:	push   r11
    7f716ee09bce:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee09bd3:	mov    r10d,edx
    7f716ee09bd6:	and    r10d,0xc000
    7f716ee09bdd:	shl    r10d,0x10
    7f716ee09be1:	mov    r11d,edx
    7f716ee09be4:	and    r11d,0x100
    7f716ee09beb:	shl    r11d,0x15
    7f716ee09bef:	or     r10d,r11d
    7f716ee09bf2:	and    edx,0x1
    7f716ee09bf5:	shl    edx,0x1c
    7f716ee09bf8:	or     r10d,edx
    7f716ee09bfb:	btc    r10,0x1d
    7f716ee09c00:	mov    r11d,0xf0000000
    7f716ee09c06:	and    r11,r10
    7f716ee09c09:	movabs rsi,0xffffffff0fffffff
    7f716ee09c13:	and    rbx,rsi
    7f716ee09c16:	or     rbx,r11
    7f716ee09c19:	pop    r11
    7f716ee09c1b:	pop    r10
    7f716ee09c1d:	pop    rsi
    7f716ee09c1e:	pop    rdx
    7f716ee09c1f:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee09c27:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee09c2d:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee09c32:	test   r10d,0x3f
    7f716ee09c39:	je     0x7f716ee09c5e
    7f716ee09c3f:	mov    r11d,r10d
    7f716ee09c42:	shr    r10d,1
    7f716ee09c45:	and    r10d,0x1e
    7f716ee09c49:	and    r11d,0x1
    7f716ee09c4d:	or     r10d,r11d
    7f716ee09c50:	or     DWORD PTR [r12+0x314],r10d
    7f716ee09c58:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee09c5e:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee09c64:	lea    rdi,[rsp+0x110]
    7f716ee09c6c:	lea    rsi,[rsp+0xf0]
    7f716ee09c74:	lea    rdx,[rsp+0x100]
    7f716ee09c7c:	mov    ecx,0x56
    7f716ee09c81:	mov    r8d,0x0
    7f716ee09c87:	lea    r9,[r12+0x314]
    7f716ee09c8f:	movabs r11,0x5fdfb8a5e650
    7f716ee09c99:	call   r11
    7f716ee09c9c:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee09ca2:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee09ca8:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee09cae:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee09cb4:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee09cba:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee09cc0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee09cc6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee09cd0:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee09cda:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee09ce2:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee09cee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee09cf7:	mov    rdx,rbx
    7f716ee09cfa:	shr    rdx,0x10
    7f716ee09cfe:	and    edx,0xc000
    7f716ee09d04:	mov    rax,rbx
    7f716ee09d07:	shr    rax,0x15
    7f716ee09d0b:	and    eax,0x100
    7f716ee09d10:	xor    eax,0x100
    7f716ee09d15:	or     edx,eax
    7f716ee09d17:	mov    rax,rbx
    7f716ee09d1a:	shr    rax,0x1c
    7f716ee09d1e:	and    eax,0x1
    7f716ee09d21:	or     edx,eax
    7f716ee09d23:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee09d28:	add    rsp,0x8
    7f716ee09d2c:	ret
    7f716ee09d2d:	nop    DWORD PTR [rax]
    7f716ee09d30:	sub    rsp,0x8
    7f716ee09d34:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee09d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee09d46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee09d4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee09d52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee09d58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee09d5e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee09d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee09d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee09d7c:	push   rdx
    7f716ee09d7d:	push   rsi
    7f716ee09d7e:	push   r10
    7f716ee09d80:	push   r11
    7f716ee09d82:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee09d87:	mov    r10d,edx
    7f716ee09d8a:	and    r10d,0xc000
    7f716ee09d91:	shl    r10d,0x10
    7f716ee09d95:	mov    r11d,edx
    7f716ee09d98:	and    r11d,0x100
    7f716ee09d9f:	shl    r11d,0x15
    7f716ee09da3:	or     r10d,r11d
    7f716ee09da6:	and    edx,0x1
    7f716ee09da9:	shl    edx,0x1c
    7f716ee09dac:	or     r10d,edx
    7f716ee09daf:	btc    r10,0x1d
    7f716ee09db4:	mov    r11d,0xf0000000
    7f716ee09dba:	and    r11,r10
    7f716ee09dbd:	movabs rsi,0xffffffff0fffffff
    7f716ee09dc7:	and    rbx,rsi
    7f716ee09dca:	or     rbx,r11
    7f716ee09dcd:	pop    r11
    7f716ee09dcf:	pop    r10
    7f716ee09dd1:	pop    rsi
    7f716ee09dd2:	pop    rdx
    7f716ee09dd3:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee09ddb:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee09de1:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee09de6:	test   r10d,0x3f
    7f716ee09ded:	je     0x7f716ee09e12
    7f716ee09df3:	mov    r11d,r10d
    7f716ee09df6:	shr    r10d,1
    7f716ee09df9:	and    r10d,0x1e
    7f716ee09dfd:	and    r11d,0x1
    7f716ee09e01:	or     r10d,r11d
    7f716ee09e04:	or     DWORD PTR [r12+0x314],r10d
    7f716ee09e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee09e12:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee09e18:	lea    rdi,[rsp+0x110]
    7f716ee09e20:	lea    rsi,[rsp+0xf0]
    7f716ee09e28:	lea    rdx,[rsp+0x100]
    7f716ee09e30:	mov    ecx,0x56
    7f716ee09e35:	mov    r8d,0x0
    7f716ee09e3b:	lea    r9,[r12+0x314]
    7f716ee09e43:	movabs r11,0x5fdfb8a5e650
    7f716ee09e4d:	call   r11
    7f716ee09e50:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee09e56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee09e5c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee09e62:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee09e68:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee09e6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee09e74:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee09e7e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee09e88:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee09e92:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee09e9a:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee09ea6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee09eaf:	mov    rdx,rbx
    7f716ee09eb2:	shr    rdx,0x10
    7f716ee09eb6:	and    edx,0xc000
    7f716ee09ebc:	mov    rax,rbx
    7f716ee09ebf:	shr    rax,0x15
    7f716ee09ec3:	and    eax,0x100
    7f716ee09ec8:	xor    eax,0x100
    7f716ee09ecd:	or     edx,eax
    7f716ee09ecf:	mov    rax,rbx
    7f716ee09ed2:	shr    rax,0x1c
    7f716ee09ed6:	and    eax,0x1
    7f716ee09ed9:	or     edx,eax
    7f716ee09edb:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee09ee0:	add    rsp,0x8
    7f716ee09ee4:	ret
    7f716ee09ee5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee09ef0:	sub    rsp,0x8
    7f716ee09ef4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee09f00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee09f06:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee09f0c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee09f12:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee09f18:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee09f1e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee09f24:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee09f2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee09f38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f716ee09f42:	push   rdx
    7f716ee09f43:	push   rsi
    7f716ee09f44:	push   r10
    7f716ee09f46:	push   r11
    7f716ee09f48:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee09f4d:	mov    r10d,edx
    7f716ee09f50:	and    r10d,0xc000
    7f716ee09f57:	shl    r10d,0x10
    7f716ee09f5b:	mov    r11d,edx
    7f716ee09f5e:	and    r11d,0x100
    7f716ee09f65:	shl    r11d,0x15
    7f716ee09f69:	or     r10d,r11d
    7f716ee09f6c:	and    edx,0x1
    7f716ee09f6f:	shl    edx,0x1c
    7f716ee09f72:	or     r10d,edx
    7f716ee09f75:	btc    r10,0x1d
    7f716ee09f7a:	mov    r11d,0xf0000000
    7f716ee09f80:	and    r11,r10
    7f716ee09f83:	movabs rsi,0xffffffff0fffffff
    7f716ee09f8d:	and    rbx,rsi
    7f716ee09f90:	or     rbx,r11
    7f716ee09f93:	pop    r11
    7f716ee09f95:	pop    r10
    7f716ee09f97:	pop    rsi
    7f716ee09f98:	pop    rdx
    7f716ee09f99:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee09fa1:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee09fa7:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee09fac:	test   r10d,0x3f
    7f716ee09fb3:	je     0x7f716ee09fd8
    7f716ee09fb9:	mov    r11d,r10d
    7f716ee09fbc:	shr    r10d,1
    7f716ee09fbf:	and    r10d,0x1e
    7f716ee09fc3:	and    r11d,0x1
    7f716ee09fc7:	or     r10d,r11d
    7f716ee09fca:	or     DWORD PTR [r12+0x314],r10d
    7f716ee09fd2:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee09fd8:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee09fde:	lea    rdi,[rsp+0x110]
    7f716ee09fe6:	lea    rsi,[rsp+0xf0]
    7f716ee09fee:	lea    rdx,[rsp+0x100]
    7f716ee09ff6:	mov    ecx,0x14
    7f716ee09ffb:	mov    r8d,0x0
    7f716ee0a001:	lea    r9,[r12+0x314]
    7f716ee0a009:	movabs r11,0x5fdfb8a5e650
    7f716ee0a013:	call   r11
    7f716ee0a016:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee0a01c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee0a022:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee0a028:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee0a02e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee0a034:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee0a03a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee0a040:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee0a04a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee0a054:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7f716ee0a05e:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0a066:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0a072:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0a07b:	mov    rdx,rbx
    7f716ee0a07e:	shr    rdx,0x10
    7f716ee0a082:	and    edx,0xc000
    7f716ee0a088:	mov    rax,rbx
    7f716ee0a08b:	shr    rax,0x15
    7f716ee0a08f:	and    eax,0x100
    7f716ee0a094:	xor    eax,0x100
    7f716ee0a099:	or     edx,eax
    7f716ee0a09b:	mov    rax,rbx
    7f716ee0a09e:	shr    rax,0x1c
    7f716ee0a0a2:	and    eax,0x1
    7f716ee0a0a5:	or     edx,eax
    7f716ee0a0a7:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee0a0ac:	add    rsp,0x8
    7f716ee0a0b0:	ret
    7f716ee0a0b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee0a0c0:	sub    rsp,0x8
    7f716ee0a0c4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee0a0d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee0a0d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee0a0dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee0a0e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee0a0e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee0a0ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee0a0f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee0a102:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee0a10c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee0a116:	push   rdx
    7f716ee0a117:	push   rsi
    7f716ee0a118:	push   r10
    7f716ee0a11a:	push   r11
    7f716ee0a11c:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee0a121:	mov    r10d,edx
    7f716ee0a124:	and    r10d,0xc000
    7f716ee0a12b:	shl    r10d,0x10
    7f716ee0a12f:	mov    r11d,edx
    7f716ee0a132:	and    r11d,0x100
    7f716ee0a139:	shl    r11d,0x15
    7f716ee0a13d:	or     r10d,r11d
    7f716ee0a140:	and    edx,0x1
    7f716ee0a143:	shl    edx,0x1c
    7f716ee0a146:	or     r10d,edx
    7f716ee0a149:	btc    r10,0x1d
    7f716ee0a14e:	mov    r11d,0xf0000000
    7f716ee0a154:	and    r11,r10
    7f716ee0a157:	movabs rsi,0xffffffff0fffffff
    7f716ee0a161:	and    rbx,rsi
    7f716ee0a164:	or     rbx,r11
    7f716ee0a167:	pop    r11
    7f716ee0a169:	pop    r10
    7f716ee0a16b:	pop    rsi
    7f716ee0a16c:	pop    rdx
    7f716ee0a16d:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0a175:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0a17b:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0a180:	test   r10d,0x3f
    7f716ee0a187:	je     0x7f716ee0a1ac
    7f716ee0a18d:	mov    r11d,r10d
    7f716ee0a190:	shr    r10d,1
    7f716ee0a193:	and    r10d,0x1e
    7f716ee0a197:	and    r11d,0x1
    7f716ee0a19b:	or     r10d,r11d
    7f716ee0a19e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee0a1a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0a1ac:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee0a1b2:	lea    rdi,[rsp+0x110]
    7f716ee0a1ba:	lea    rsi,[rsp+0xf0]
    7f716ee0a1c2:	lea    rdx,[rsp+0x100]
    7f716ee0a1ca:	mov    ecx,0x56
    7f716ee0a1cf:	mov    r8d,0x0
    7f716ee0a1d5:	lea    r9,[r12+0x314]
    7f716ee0a1dd:	movabs r11,0x5fdfb8a5e650
    7f716ee0a1e7:	call   r11
    7f716ee0a1ea:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee0a1f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee0a1f6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee0a1fc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee0a202:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee0a208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee0a20e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee0a218:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee0a222:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee0a22c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee0a236:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0a23e:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0a24a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0a253:	mov    rdx,rbx
    7f716ee0a256:	shr    rdx,0x10
    7f716ee0a25a:	and    edx,0xc000
    7f716ee0a260:	mov    rax,rbx
    7f716ee0a263:	shr    rax,0x15
    7f716ee0a267:	and    eax,0x100
    7f716ee0a26c:	xor    eax,0x100
    7f716ee0a271:	or     edx,eax
    7f716ee0a273:	mov    rax,rbx
    7f716ee0a276:	shr    rax,0x1c
    7f716ee0a27a:	and    eax,0x1
    7f716ee0a27d:	or     edx,eax
    7f716ee0a27f:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee0a284:	add    rsp,0x8
    7f716ee0a288:	ret
    7f716ee0a289:	nop    DWORD PTR [rax+0x0]
    7f716ee0a290:	sub    rsp,0x8
    7f716ee0a294:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee0a2a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee0a2a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0a2ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee0a2b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee0a2b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee0a2be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee0a2c4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f716ee0a2ce:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee0a2d8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee0a2e2:	push   rdx
    7f716ee0a2e3:	push   rsi
    7f716ee0a2e4:	push   r10
    7f716ee0a2e6:	push   r11
    7f716ee0a2e8:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee0a2ed:	mov    r10d,edx
    7f716ee0a2f0:	and    r10d,0xc000
    7f716ee0a2f7:	shl    r10d,0x10
    7f716ee0a2fb:	mov    r11d,edx
    7f716ee0a2fe:	and    r11d,0x100
    7f716ee0a305:	shl    r11d,0x15
    7f716ee0a309:	or     r10d,r11d
    7f716ee0a30c:	and    edx,0x1
    7f716ee0a30f:	shl    edx,0x1c
    7f716ee0a312:	or     r10d,edx
    7f716ee0a315:	btc    r10,0x1d
    7f716ee0a31a:	mov    r11d,0xf0000000
    7f716ee0a320:	and    r11,r10
    7f716ee0a323:	movabs rsi,0xffffffff0fffffff
    7f716ee0a32d:	and    rbx,rsi
    7f716ee0a330:	or     rbx,r11
    7f716ee0a333:	pop    r11
    7f716ee0a335:	pop    r10
    7f716ee0a337:	pop    rsi
    7f716ee0a338:	pop    rdx
    7f716ee0a339:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0a341:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0a347:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0a34c:	test   r10d,0x3f
    7f716ee0a353:	je     0x7f716ee0a378
    7f716ee0a359:	mov    r11d,r10d
    7f716ee0a35c:	shr    r10d,1
    7f716ee0a35f:	and    r10d,0x1e
    7f716ee0a363:	and    r11d,0x1
    7f716ee0a367:	or     r10d,r11d
    7f716ee0a36a:	or     DWORD PTR [r12+0x314],r10d
    7f716ee0a372:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0a378:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee0a37e:	lea    rdi,[rsp+0x110]
    7f716ee0a386:	lea    rsi,[rsp+0xf0]
    7f716ee0a38e:	lea    rdx,[rsp+0x100]
    7f716ee0a396:	mov    ecx,0x56
    7f716ee0a39b:	mov    r8d,0x0
    7f716ee0a3a1:	lea    r9,[r12+0x314]
    7f716ee0a3a9:	movabs r11,0x5fdfb8a5e650
    7f716ee0a3b3:	call   r11
    7f716ee0a3b6:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee0a3bc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee0a3c2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee0a3c8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee0a3ce:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee0a3d4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee0a3da:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee0a3e0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7f716ee0a3ea:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee0a3f4:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee0a3fe:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0a406:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0a412:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0a41b:	mov    rdx,rbx
    7f716ee0a41e:	shr    rdx,0x10
    7f716ee0a422:	and    edx,0xc000
    7f716ee0a428:	mov    rax,rbx
    7f716ee0a42b:	shr    rax,0x15
    7f716ee0a42f:	and    eax,0x100
    7f716ee0a434:	xor    eax,0x100
    7f716ee0a439:	or     edx,eax
    7f716ee0a43b:	mov    rax,rbx
    7f716ee0a43e:	shr    rax,0x1c
    7f716ee0a442:	and    eax,0x1
    7f716ee0a445:	or     edx,eax
    7f716ee0a447:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee0a44c:	add    rsp,0x8
    7f716ee0a450:	ret
    7f716ee0a451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee0a460:	sub    rsp,0x8
    7f716ee0a464:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee0a470:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0a476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee0a47c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7f716ee0a482:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f716ee0a488:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee0a492:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee0a49c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee0a4a6:	push   rdx
    7f716ee0a4a7:	push   rsi
    7f716ee0a4a8:	push   r10
    7f716ee0a4aa:	push   r11
    7f716ee0a4ac:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee0a4b1:	mov    r10d,edx
    7f716ee0a4b4:	and    r10d,0xc000
    7f716ee0a4bb:	shl    r10d,0x10
    7f716ee0a4bf:	mov    r11d,edx
    7f716ee0a4c2:	and    r11d,0x100
    7f716ee0a4c9:	shl    r11d,0x15
    7f716ee0a4cd:	or     r10d,r11d
    7f716ee0a4d0:	and    edx,0x1
    7f716ee0a4d3:	shl    edx,0x1c
    7f716ee0a4d6:	or     r10d,edx
    7f716ee0a4d9:	btc    r10,0x1d
    7f716ee0a4de:	mov    r11d,0xf0000000
    7f716ee0a4e4:	and    r11,r10
    7f716ee0a4e7:	movabs rsi,0xffffffff0fffffff
    7f716ee0a4f1:	and    rbx,rsi
    7f716ee0a4f4:	or     rbx,r11
    7f716ee0a4f7:	pop    r11
    7f716ee0a4f9:	pop    r10
    7f716ee0a4fb:	pop    rsi
    7f716ee0a4fc:	pop    rdx
    7f716ee0a4fd:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0a505:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0a50b:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0a510:	test   r10d,0x3f
    7f716ee0a517:	je     0x7f716ee0a53c
    7f716ee0a51d:	mov    r11d,r10d
    7f716ee0a520:	shr    r10d,1
    7f716ee0a523:	and    r10d,0x1e
    7f716ee0a527:	and    r11d,0x1
    7f716ee0a52b:	or     r10d,r11d
    7f716ee0a52e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee0a536:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0a53c:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee0a542:	lea    rdi,[rsp+0x110]
    7f716ee0a54a:	lea    rsi,[rsp+0xf0]
    7f716ee0a552:	lea    rdx,[rsp+0x100]
    7f716ee0a55a:	mov    ecx,0x14
    7f716ee0a55f:	mov    r8d,0x0
    7f716ee0a565:	lea    r9,[r12+0x314]
    7f716ee0a56d:	movabs r11,0x5fdfb8a5e650
    7f716ee0a577:	call   r11
    7f716ee0a57a:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee0a580:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee0a586:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee0a58c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7f716ee0a592:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7f716ee0a598:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee0a5a2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee0a5ac:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee0a5b6:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0a5be:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0a5ca:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0a5d3:	mov    rdx,rbx
    7f716ee0a5d6:	shr    rdx,0x10
    7f716ee0a5da:	and    edx,0xc000
    7f716ee0a5e0:	mov    rax,rbx
    7f716ee0a5e3:	shr    rax,0x15
    7f716ee0a5e7:	and    eax,0x100
    7f716ee0a5ec:	xor    eax,0x100
    7f716ee0a5f1:	or     edx,eax
    7f716ee0a5f3:	mov    rax,rbx
    7f716ee0a5f6:	shr    rax,0x1c
    7f716ee0a5fa:	and    eax,0x1
    7f716ee0a5fd:	or     edx,eax
    7f716ee0a5ff:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee0a604:	add    rsp,0x8
    7f716ee0a608:	ret
    7f716ee0a609:	nop    DWORD PTR [rax+0x0]
    7f716ee0a610:	sub    rsp,0x8
    7f716ee0a614:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee0a620:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee0a626:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0a62c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee0a632:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7f716ee0a63c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee0a646:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee0a650:	push   rdx
    7f716ee0a651:	push   rsi
    7f716ee0a652:	push   r10
    7f716ee0a654:	push   r11
    7f716ee0a656:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee0a65b:	mov    r10d,edx
    7f716ee0a65e:	and    r10d,0xc000
    7f716ee0a665:	shl    r10d,0x10
    7f716ee0a669:	mov    r11d,edx
    7f716ee0a66c:	and    r11d,0x100
    7f716ee0a673:	shl    r11d,0x15
    7f716ee0a677:	or     r10d,r11d
    7f716ee0a67a:	and    edx,0x1
    7f716ee0a67d:	shl    edx,0x1c
    7f716ee0a680:	or     r10d,edx
    7f716ee0a683:	btc    r10,0x1d
    7f716ee0a688:	mov    r11d,0xf0000000
    7f716ee0a68e:	and    r11,r10
    7f716ee0a691:	movabs rsi,0xffffffff0fffffff
    7f716ee0a69b:	and    rbx,rsi
    7f716ee0a69e:	or     rbx,r11
    7f716ee0a6a1:	pop    r11
    7f716ee0a6a3:	pop    r10
    7f716ee0a6a5:	pop    rsi
    7f716ee0a6a6:	pop    rdx
    7f716ee0a6a7:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0a6af:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0a6b5:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0a6ba:	test   r10d,0x3f
    7f716ee0a6c1:	je     0x7f716ee0a6e6
    7f716ee0a6c7:	mov    r11d,r10d
    7f716ee0a6ca:	shr    r10d,1
    7f716ee0a6cd:	and    r10d,0x1e
    7f716ee0a6d1:	and    r11d,0x1
    7f716ee0a6d5:	or     r10d,r11d
    7f716ee0a6d8:	or     DWORD PTR [r12+0x314],r10d
    7f716ee0a6e0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0a6e6:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee0a6ec:	lea    rdi,[rsp+0x110]
    7f716ee0a6f4:	lea    rsi,[rsp+0xf0]
    7f716ee0a6fc:	lea    rdx,[rsp+0x100]
    7f716ee0a704:	mov    ecx,0x14
    7f716ee0a709:	mov    r8d,0x0
    7f716ee0a70f:	lea    r9,[r12+0x314]
    7f716ee0a717:	movabs r11,0x5fdfb8a5e650
    7f716ee0a721:	call   r11
    7f716ee0a724:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee0a72a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee0a730:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee0a736:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee0a73c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7f716ee0a746:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee0a750:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee0a75a:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0a762:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0a76e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0a777:	mov    rdx,rbx
    7f716ee0a77a:	shr    rdx,0x10
    7f716ee0a77e:	and    edx,0xc000
    7f716ee0a784:	mov    rax,rbx
    7f716ee0a787:	shr    rax,0x15
    7f716ee0a78b:	and    eax,0x100
    7f716ee0a790:	xor    eax,0x100
    7f716ee0a795:	or     edx,eax
    7f716ee0a797:	mov    rax,rbx
    7f716ee0a79a:	shr    rax,0x1c
    7f716ee0a79e:	and    eax,0x1
    7f716ee0a7a1:	or     edx,eax
    7f716ee0a7a3:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee0a7a8:	add    rsp,0x8
    7f716ee0a7ac:	ret
    7f716ee0a7ad:	nop    DWORD PTR [rax]
    7f716ee0a7b0:	sub    rsp,0x8
    7f716ee0a7b4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee0a7c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee0a7c6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee0a7cc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f716ee0a7d2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f716ee0a7dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f716ee0a7e6:	push   rdx
    7f716ee0a7e7:	push   rsi
    7f716ee0a7e8:	push   r10
    7f716ee0a7ea:	push   r11
    7f716ee0a7ec:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee0a7f1:	mov    r10d,edx
    7f716ee0a7f4:	and    r10d,0xc000
    7f716ee0a7fb:	shl    r10d,0x10
    7f716ee0a7ff:	mov    r11d,edx
    7f716ee0a802:	and    r11d,0x100
    7f716ee0a809:	shl    r11d,0x15
    7f716ee0a80d:	or     r10d,r11d
    7f716ee0a810:	and    edx,0x1
    7f716ee0a813:	shl    edx,0x1c
    7f716ee0a816:	or     r10d,edx
    7f716ee0a819:	btc    r10,0x1d
    7f716ee0a81e:	mov    r11d,0xf0000000
    7f716ee0a824:	and    r11,r10
    7f716ee0a827:	movabs rsi,0xffffffff0fffffff
    7f716ee0a831:	and    rbx,rsi
    7f716ee0a834:	or     rbx,r11
    7f716ee0a837:	pop    r11
    7f716ee0a839:	pop    r10
    7f716ee0a83b:	pop    rsi
    7f716ee0a83c:	pop    rdx
    7f716ee0a83d:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0a845:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0a84b:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0a850:	test   r10d,0x3f
    7f716ee0a857:	je     0x7f716ee0a87c
    7f716ee0a85d:	mov    r11d,r10d
    7f716ee0a860:	shr    r10d,1
    7f716ee0a863:	and    r10d,0x1e
    7f716ee0a867:	and    r11d,0x1
    7f716ee0a86b:	or     r10d,r11d
    7f716ee0a86e:	or     DWORD PTR [r12+0x314],r10d
    7f716ee0a876:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0a87c:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee0a882:	lea    rdi,[rsp+0x110]
    7f716ee0a88a:	lea    rsi,[rsp+0xf0]
    7f716ee0a892:	lea    rdx,[rsp+0x100]
    7f716ee0a89a:	mov    ecx,0x14
    7f716ee0a89f:	mov    r8d,0x0
    7f716ee0a8a5:	lea    r9,[r12+0x314]
    7f716ee0a8ad:	movabs r11,0x5fdfb8a5e650
    7f716ee0a8b7:	call   r11
    7f716ee0a8ba:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee0a8c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee0a8c6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee0a8cc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7f716ee0a8d2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7f716ee0a8dc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7f716ee0a8e6:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0a8ee:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0a8fa:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0a903:	mov    rdx,rbx
    7f716ee0a906:	shr    rdx,0x10
    7f716ee0a90a:	and    edx,0xc000
    7f716ee0a910:	mov    rax,rbx
    7f716ee0a913:	shr    rax,0x15
    7f716ee0a917:	and    eax,0x100
    7f716ee0a91c:	xor    eax,0x100
    7f716ee0a921:	or     edx,eax
    7f716ee0a923:	mov    rax,rbx
    7f716ee0a926:	shr    rax,0x1c
    7f716ee0a92a:	and    eax,0x1
    7f716ee0a92d:	or     edx,eax
    7f716ee0a92f:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee0a934:	add    rsp,0x8
    7f716ee0a938:	ret
    7f716ee0a939:	nop    DWORD PTR [rax+0x0]
    7f716ee0a940:	sub    rsp,0x8
    7f716ee0a944:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee0a950:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee0a956:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f716ee0a95c:	push   rdx
    7f716ee0a95d:	push   rsi
    7f716ee0a95e:	push   r10
    7f716ee0a960:	push   r11
    7f716ee0a962:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee0a967:	mov    r10d,edx
    7f716ee0a96a:	and    r10d,0xc000
    7f716ee0a971:	shl    r10d,0x10
    7f716ee0a975:	mov    r11d,edx
    7f716ee0a978:	and    r11d,0x100
    7f716ee0a97f:	shl    r11d,0x15
    7f716ee0a983:	or     r10d,r11d
    7f716ee0a986:	and    edx,0x1
    7f716ee0a989:	shl    edx,0x1c
    7f716ee0a98c:	or     r10d,edx
    7f716ee0a98f:	btc    r10,0x1d
    7f716ee0a994:	mov    r11d,0xf0000000
    7f716ee0a99a:	and    r11,r10
    7f716ee0a99d:	movabs rsi,0xffffffff0fffffff
    7f716ee0a9a7:	and    rbx,rsi
    7f716ee0a9aa:	or     rbx,r11
    7f716ee0a9ad:	pop    r11
    7f716ee0a9af:	pop    r10
    7f716ee0a9b1:	pop    rsi
    7f716ee0a9b2:	pop    rdx
    7f716ee0a9b3:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0a9bb:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0a9c1:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0a9c6:	test   r10d,0x3f
    7f716ee0a9cd:	je     0x7f716ee0a9f2
    7f716ee0a9d3:	mov    r11d,r10d
    7f716ee0a9d6:	shr    r10d,1
    7f716ee0a9d9:	and    r10d,0x1e
    7f716ee0a9dd:	and    r11d,0x1
    7f716ee0a9e1:	or     r10d,r11d
    7f716ee0a9e4:	or     DWORD PTR [r12+0x314],r10d
    7f716ee0a9ec:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0a9f2:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee0a9f8:	lea    rdi,[rsp+0x110]
    7f716ee0aa00:	lea    rsi,[rsp+0xf0]
    7f716ee0aa08:	lea    rdx,[rsp+0x100]
    7f716ee0aa10:	mov    ecx,0xc
    7f716ee0aa15:	mov    r8d,0x0
    7f716ee0aa1b:	lea    r9,[r12+0x314]
    7f716ee0aa23:	movabs r11,0x5fdfb8a5e650
    7f716ee0aa2d:	call   r11
    7f716ee0aa30:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee0aa36:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee0aa3c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7f716ee0aa42:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0aa4a:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0aa56:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0aa5f:	mov    rdx,rbx
    7f716ee0aa62:	shr    rdx,0x10
    7f716ee0aa66:	and    edx,0xc000
    7f716ee0aa6c:	mov    rax,rbx
    7f716ee0aa6f:	shr    rax,0x15
    7f716ee0aa73:	and    eax,0x100
    7f716ee0aa78:	xor    eax,0x100
    7f716ee0aa7d:	or     edx,eax
    7f716ee0aa7f:	mov    rax,rbx
    7f716ee0aa82:	shr    rax,0x1c
    7f716ee0aa86:	and    eax,0x1
    7f716ee0aa89:	or     edx,eax
    7f716ee0aa8b:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee0aa90:	add    rsp,0x8
    7f716ee0aa94:	ret
    7f716ee0aa95:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee0aaa0:	sub    rsp,0x8
    7f716ee0aaa4:	mov    QWORD PTR [r12+0x378],0x3
    7f716ee0aab0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f716ee0aab6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f716ee0aabc:	push   rdx
    7f716ee0aabd:	push   rsi
    7f716ee0aabe:	push   r10
    7f716ee0aac0:	push   r11
    7f716ee0aac2:	mov    rdx,QWORD PTR [rsp+0x30]
    7f716ee0aac7:	mov    r10d,edx
    7f716ee0aaca:	and    r10d,0xc000
    7f716ee0aad1:	shl    r10d,0x10
    7f716ee0aad5:	mov    r11d,edx
    7f716ee0aad8:	and    r11d,0x100
    7f716ee0aadf:	shl    r11d,0x15
    7f716ee0aae3:	or     r10d,r11d
    7f716ee0aae6:	and    edx,0x1
    7f716ee0aae9:	shl    edx,0x1c
    7f716ee0aaec:	or     r10d,edx
    7f716ee0aaef:	btc    r10,0x1d
    7f716ee0aaf4:	mov    r11d,0xf0000000
    7f716ee0aafa:	and    r11,r10
    7f716ee0aafd:	movabs rsi,0xffffffff0fffffff
    7f716ee0ab07:	and    rbx,rsi
    7f716ee0ab0a:	or     rbx,r11
    7f716ee0ab0d:	pop    r11
    7f716ee0ab0f:	pop    r10
    7f716ee0ab11:	pop    rsi
    7f716ee0ab12:	pop    rdx
    7f716ee0ab13:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0ab1b:	stmxcsr DWORD PTR [r12-0x28]
    7f716ee0ab21:	mov    r10d,DWORD PTR [r12-0x28]
    7f716ee0ab26:	test   r10d,0x3f
    7f716ee0ab2d:	je     0x7f716ee0ab52
    7f716ee0ab33:	mov    r11d,r10d
    7f716ee0ab36:	shr    r10d,1
    7f716ee0ab39:	and    r10d,0x1e
    7f716ee0ab3d:	and    r11d,0x1
    7f716ee0ab41:	or     r10d,r11d
    7f716ee0ab44:	or     DWORD PTR [r12+0x314],r10d
    7f716ee0ab4c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7f716ee0ab52:	ldmxcsr DWORD PTR [r12-0x38]
    7f716ee0ab58:	lea    rdi,[rsp+0x110]
    7f716ee0ab60:	lea    rsi,[rsp+0xf0]
    7f716ee0ab68:	lea    rdx,[rsp+0x100]
    7f716ee0ab70:	mov    ecx,0xc
    7f716ee0ab75:	mov    r8d,0x0
    7f716ee0ab7b:	lea    r9,[r12+0x314]
    7f716ee0ab83:	movabs r11,0x5fdfb8a5e650
    7f716ee0ab8d:	call   r11
    7f716ee0ab90:	ldmxcsr DWORD PTR [r12-0x28]
    7f716ee0ab96:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7f716ee0ab9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7f716ee0aba2:	mov    rbx,QWORD PTR [r12+0x108]
    7f716ee0abaa:	mov    QWORD PTR [r12+0x378],0x2
    7f716ee0abb6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7f716ee0abbf:	mov    rdx,rbx
    7f716ee0abc2:	shr    rdx,0x10
    7f716ee0abc6:	and    edx,0xc000
    7f716ee0abcc:	mov    rax,rbx
    7f716ee0abcf:	shr    rax,0x15
    7f716ee0abd3:	and    eax,0x100
    7f716ee0abd8:	xor    eax,0x100
    7f716ee0abdd:	or     edx,eax
    7f716ee0abdf:	mov    rax,rbx
    7f716ee0abe2:	shr    rax,0x1c
    7f716ee0abe6:	and    eax,0x1
    7f716ee0abe9:	or     edx,eax
    7f716ee0abeb:	mov    QWORD PTR [rsp+0x10],rdx
    7f716ee0abf0:	add    rsp,0x8
    7f716ee0abf4:	ret
    7f716ee0abf5:	mov    eax,0x410400
    7f716ee0abfa:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0ac02:	push   rdx
    7f716ee0ac03:	push   rsi
    7f716ee0ac04:	push   r10
    7f716ee0ac06:	push   r11
    7f716ee0ac08:	mov    r11,rax
    7f716ee0ac0b:	lahf
    7f716ee0ac0c:	seto   al
    7f716ee0ac0f:	mov    WORD PTR [rsp+0x20],ax
    7f716ee0ac14:	mov    rax,r11
    7f716ee0ac17:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0ac1c:	mov    r10d,edx
    7f716ee0ac1f:	and    r10d,0xc000
    7f716ee0ac26:	shl    r10d,0x10
    7f716ee0ac2a:	mov    r11d,edx
    7f716ee0ac2d:	and    r11d,0x100
    7f716ee0ac34:	shl    r11d,0x15
    7f716ee0ac38:	or     r10d,r11d
    7f716ee0ac3b:	and    edx,0x1
    7f716ee0ac3e:	shl    edx,0x1c
    7f716ee0ac41:	or     r10d,edx
    7f716ee0ac44:	btc    r10,0x1d
    7f716ee0ac49:	mov    r11d,0xf0000000
    7f716ee0ac4f:	and    r11,r10
    7f716ee0ac52:	movabs rsi,0xffffffff0fffffff
    7f716ee0ac5c:	and    rbx,rsi
    7f716ee0ac5f:	or     rbx,r11
    7f716ee0ac62:	pop    r11
    7f716ee0ac64:	pop    r10
    7f716ee0ac66:	pop    rsi
    7f716ee0ac67:	pop    rdx
    7f716ee0ac68:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0ac70:	add    rsp,0x150
    7f716ee0ac77:	mov    eax,0xc
    7f716ee0ac7c:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0ac86:	jmp    r11
    7f716ee0ac89:	mov    eax,0x41048c
    7f716ee0ac8e:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0ac96:	push   rdx
    7f716ee0ac97:	push   rsi
    7f716ee0ac98:	push   r10
    7f716ee0ac9a:	push   r11
    7f716ee0ac9c:	mov    r11,rax
    7f716ee0ac9f:	lahf
    7f716ee0aca0:	seto   al
    7f716ee0aca3:	mov    WORD PTR [rsp+0x20],ax
    7f716ee0aca8:	mov    rax,r11
    7f716ee0acab:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0acb0:	mov    r10d,edx
    7f716ee0acb3:	and    r10d,0xc000
    7f716ee0acba:	shl    r10d,0x10
    7f716ee0acbe:	mov    r11d,edx
    7f716ee0acc1:	and    r11d,0x100
    7f716ee0acc8:	shl    r11d,0x15
    7f716ee0accc:	or     r10d,r11d
    7f716ee0accf:	and    edx,0x1
    7f716ee0acd2:	shl    edx,0x1c
    7f716ee0acd5:	or     r10d,edx
    7f716ee0acd8:	btc    r10,0x1d
    7f716ee0acdd:	mov    r11d,0xf0000000
    7f716ee0ace3:	and    r11,r10
    7f716ee0ace6:	movabs rsi,0xffffffff0fffffff
    7f716ee0acf0:	and    rbx,rsi
    7f716ee0acf3:	or     rbx,r11
    7f716ee0acf6:	pop    r11
    7f716ee0acf8:	pop    r10
    7f716ee0acfa:	pop    rsi
    7f716ee0acfb:	pop    rdx
    7f716ee0acfc:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0ad04:	add    rsp,0x150
    7f716ee0ad0b:	mov    eax,0xc
    7f716ee0ad10:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0ad1a:	jmp    r11
    7f716ee0ad1d:	mov    eax,0x4106cc
    7f716ee0ad22:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0ad2a:	push   rdx
    7f716ee0ad2b:	push   rsi
    7f716ee0ad2c:	push   r10
    7f716ee0ad2e:	push   r11
    7f716ee0ad30:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0ad35:	mov    r10d,edx
    7f716ee0ad38:	and    r10d,0xc000
    7f716ee0ad3f:	shl    r10d,0x10
    7f716ee0ad43:	mov    r11d,edx
    7f716ee0ad46:	and    r11d,0x100
    7f716ee0ad4d:	shl    r11d,0x15
    7f716ee0ad51:	or     r10d,r11d
    7f716ee0ad54:	and    edx,0x1
    7f716ee0ad57:	shl    edx,0x1c
    7f716ee0ad5a:	or     r10d,edx
    7f716ee0ad5d:	btc    r10,0x1d
    7f716ee0ad62:	mov    r11d,0xf0000000
    7f716ee0ad68:	and    r11,r10
    7f716ee0ad6b:	movabs rsi,0xffffffff0fffffff
    7f716ee0ad75:	and    rbx,rsi
    7f716ee0ad78:	or     rbx,r11
    7f716ee0ad7b:	pop    r11
    7f716ee0ad7d:	pop    r10
    7f716ee0ad7f:	pop    rsi
    7f716ee0ad80:	pop    rdx
    7f716ee0ad81:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0ad89:	add    rsp,0x150
    7f716ee0ad90:	mov    eax,0xc
    7f716ee0ad95:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0ad9f:	jmp    r11
    7f716ee0ada2:	mov    eax,0x4106d8
    7f716ee0ada7:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0adaf:	push   rdx
    7f716ee0adb0:	push   rsi
    7f716ee0adb1:	push   r10
    7f716ee0adb3:	push   r11
    7f716ee0adb5:	mov    r11,rax
    7f716ee0adb8:	lahf
    7f716ee0adb9:	seto   al
    7f716ee0adbc:	mov    WORD PTR [rsp+0x20],ax
    7f716ee0adc1:	mov    rax,r11
    7f716ee0adc4:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0adc9:	mov    r10d,edx
    7f716ee0adcc:	and    r10d,0xc000
    7f716ee0add3:	shl    r10d,0x10
    7f716ee0add7:	mov    r11d,edx
    7f716ee0adda:	and    r11d,0x100
    7f716ee0ade1:	shl    r11d,0x15
    7f716ee0ade5:	or     r10d,r11d
    7f716ee0ade8:	and    edx,0x1
    7f716ee0adeb:	shl    edx,0x1c
    7f716ee0adee:	or     r10d,edx
    7f716ee0adf1:	btc    r10,0x1d
    7f716ee0adf6:	mov    r11d,0xf0000000
    7f716ee0adfc:	and    r11,r10
    7f716ee0adff:	movabs rsi,0xffffffff0fffffff
    7f716ee0ae09:	and    rbx,rsi
    7f716ee0ae0c:	or     rbx,r11
    7f716ee0ae0f:	pop    r11
    7f716ee0ae11:	pop    r10
    7f716ee0ae13:	pop    rsi
    7f716ee0ae14:	pop    rdx
    7f716ee0ae15:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0ae1d:	add    rsp,0x150
    7f716ee0ae24:	mov    eax,0xc
    7f716ee0ae29:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0ae33:	jmp    r11
    7f716ee0ae36:	mov    eax,0x410700
    7f716ee0ae3b:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0ae43:	push   rdx
    7f716ee0ae44:	push   rsi
    7f716ee0ae45:	push   r10
    7f716ee0ae47:	push   r11
    7f716ee0ae49:	mov    r11,rax
    7f716ee0ae4c:	lahf
    7f716ee0ae4d:	seto   al
    7f716ee0ae50:	mov    WORD PTR [rsp+0x20],ax
    7f716ee0ae55:	mov    rax,r11
    7f716ee0ae58:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0ae5d:	mov    r10d,edx
    7f716ee0ae60:	and    r10d,0xc000
    7f716ee0ae67:	shl    r10d,0x10
    7f716ee0ae6b:	mov    r11d,edx
    7f716ee0ae6e:	and    r11d,0x100
    7f716ee0ae75:	shl    r11d,0x15
    7f716ee0ae79:	or     r10d,r11d
    7f716ee0ae7c:	and    edx,0x1
    7f716ee0ae7f:	shl    edx,0x1c
    7f716ee0ae82:	or     r10d,edx
    7f716ee0ae85:	btc    r10,0x1d
    7f716ee0ae8a:	mov    r11d,0xf0000000
    7f716ee0ae90:	and    r11,r10
    7f716ee0ae93:	movabs rsi,0xffffffff0fffffff
    7f716ee0ae9d:	and    rbx,rsi
    7f716ee0aea0:	or     rbx,r11
    7f716ee0aea3:	pop    r11
    7f716ee0aea5:	pop    r10
    7f716ee0aea7:	pop    rsi
    7f716ee0aea8:	pop    rdx
    7f716ee0aea9:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0aeb1:	add    rsp,0x150
    7f716ee0aeb8:	mov    eax,0xc
    7f716ee0aebd:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0aec7:	jmp    r11
    7f716ee0aeca:	mov    eax,0x410724
    7f716ee0aecf:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0aed7:	push   rdx
    7f716ee0aed8:	push   rsi
    7f716ee0aed9:	push   r10
    7f716ee0aedb:	push   r11
    7f716ee0aedd:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0aee2:	mov    r10d,edx
    7f716ee0aee5:	and    r10d,0xc000
    7f716ee0aeec:	shl    r10d,0x10
    7f716ee0aef0:	mov    r11d,edx
    7f716ee0aef3:	and    r11d,0x100
    7f716ee0aefa:	shl    r11d,0x15
    7f716ee0aefe:	or     r10d,r11d
    7f716ee0af01:	and    edx,0x1
    7f716ee0af04:	shl    edx,0x1c
    7f716ee0af07:	or     r10d,edx
    7f716ee0af0a:	btc    r10,0x1d
    7f716ee0af0f:	mov    r11d,0xf0000000
    7f716ee0af15:	and    r11,r10
    7f716ee0af18:	movabs rsi,0xffffffff0fffffff
    7f716ee0af22:	and    rbx,rsi
    7f716ee0af25:	or     rbx,r11
    7f716ee0af28:	pop    r11
    7f716ee0af2a:	pop    r10
    7f716ee0af2c:	pop    rsi
    7f716ee0af2d:	pop    rdx
    7f716ee0af2e:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0af36:	add    rsp,0x150
    7f716ee0af3d:	mov    eax,0xc
    7f716ee0af42:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0af4c:	jmp    r11
    7f716ee0af4f:	nop
    7f716ee0af50:	sub    rsp,0x150
    7f716ee0af57:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0af5f:	mov    QWORD PTR [rsp],r11
    7f716ee0af63:	cmp    DWORD PTR [r12+0x310],0x0
    7f716ee0af6c:	je     0x7f716ee0aff7
    7f716ee0af72:	push   rdx
    7f716ee0af73:	push   rsi
    7f716ee0af74:	push   r10
    7f716ee0af76:	push   r11
    7f716ee0af78:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0af7d:	mov    r10d,edx
    7f716ee0af80:	and    r10d,0xc000
    7f716ee0af87:	shl    r10d,0x10
    7f716ee0af8b:	mov    r11d,edx
    7f716ee0af8e:	and    r11d,0x100
    7f716ee0af95:	shl    r11d,0x15
    7f716ee0af99:	or     r10d,r11d
    7f716ee0af9c:	and    edx,0x1
    7f716ee0af9f:	shl    edx,0x1c
    7f716ee0afa2:	or     r10d,edx
    7f716ee0afa5:	btc    r10,0x1d
    7f716ee0afaa:	mov    r11d,0xf0000000
    7f716ee0afb0:	and    r11,r10
    7f716ee0afb3:	movabs rsi,0xffffffff0fffffff
    7f716ee0afbd:	and    rbx,rsi
    7f716ee0afc0:	or     rbx,r11
    7f716ee0afc3:	pop    r11
    7f716ee0afc5:	pop    r10
    7f716ee0afc7:	pop    rsi
    7f716ee0afc8:	pop    rdx
    7f716ee0afc9:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0afd1:	mov    eax,0x410404
    7f716ee0afd6:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0afde:	add    rsp,0x150
    7f716ee0afe5:	mov    eax,0x3
    7f716ee0afea:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0aff4:	jmp    r11
    7f716ee0aff7:	jmp    0x7f716ee0126d
    7f716ee0affc:	nop    DWORD PTR [rax+0x0]
    7f716ee0b000:	sub    rsp,0x150
    7f716ee0b007:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0b00f:	mov    QWORD PTR [rsp],r11
    7f716ee0b013:	cmp    DWORD PTR [r12+0x310],0x0
    7f716ee0b01c:	je     0x7f716ee0b0a7
    7f716ee0b022:	push   rdx
    7f716ee0b023:	push   rsi
    7f716ee0b024:	push   r10
    7f716ee0b026:	push   r11
    7f716ee0b028:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0b02d:	mov    r10d,edx
    7f716ee0b030:	and    r10d,0xc000
    7f716ee0b037:	shl    r10d,0x10
    7f716ee0b03b:	mov    r11d,edx
    7f716ee0b03e:	and    r11d,0x100
    7f716ee0b045:	shl    r11d,0x15
    7f716ee0b049:	or     r10d,r11d
    7f716ee0b04c:	and    edx,0x1
    7f716ee0b04f:	shl    edx,0x1c
    7f716ee0b052:	or     r10d,edx
    7f716ee0b055:	btc    r10,0x1d
    7f716ee0b05a:	mov    r11d,0xf0000000
    7f716ee0b060:	and    r11,r10
    7f716ee0b063:	movabs rsi,0xffffffff0fffffff
    7f716ee0b06d:	and    rbx,rsi
    7f716ee0b070:	or     rbx,r11
    7f716ee0b073:	pop    r11
    7f716ee0b075:	pop    r10
    7f716ee0b077:	pop    rsi
    7f716ee0b078:	pop    rdx
    7f716ee0b079:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0b081:	mov    eax,0x410450
    7f716ee0b086:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0b08e:	add    rsp,0x150
    7f716ee0b095:	mov    eax,0x3
    7f716ee0b09a:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0b0a4:	jmp    r11
    7f716ee0b0a7:	mov    r11,rax
    7f716ee0b0aa:	movzx  eax,WORD PTR [rsp]
    7f716ee0b0ae:	add    al,0x7f
    7f716ee0b0b0:	sahf
    7f716ee0b0b1:	mov    rax,r11
    7f716ee0b0b4:	jmp    0x7f716ee013dd
    7f716ee0b0b9:	nop    DWORD PTR [rax+0x0]
    7f716ee0b0c0:	sub    rsp,0x150
    7f716ee0b0c7:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0b0cf:	mov    QWORD PTR [rsp],r11
    7f716ee0b0d3:	cmp    DWORD PTR [r12+0x310],0x0
    7f716ee0b0dc:	je     0x7f716ee0b167
    7f716ee0b0e2:	push   rdx
    7f716ee0b0e3:	push   rsi
    7f716ee0b0e4:	push   r10
    7f716ee0b0e6:	push   r11
    7f716ee0b0e8:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0b0ed:	mov    r10d,edx
    7f716ee0b0f0:	and    r10d,0xc000
    7f716ee0b0f7:	shl    r10d,0x10
    7f716ee0b0fb:	mov    r11d,edx
    7f716ee0b0fe:	and    r11d,0x100
    7f716ee0b105:	shl    r11d,0x15
    7f716ee0b109:	or     r10d,r11d
    7f716ee0b10c:	and    edx,0x1
    7f716ee0b10f:	shl    edx,0x1c
    7f716ee0b112:	or     r10d,edx
    7f716ee0b115:	btc    r10,0x1d
    7f716ee0b11a:	mov    r11d,0xf0000000
    7f716ee0b120:	and    r11,r10
    7f716ee0b123:	movabs rsi,0xffffffff0fffffff
    7f716ee0b12d:	and    rbx,rsi
    7f716ee0b130:	or     rbx,r11
    7f716ee0b133:	pop    r11
    7f716ee0b135:	pop    r10
    7f716ee0b137:	pop    rsi
    7f716ee0b138:	pop    rdx
    7f716ee0b139:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0b141:	mov    eax,0x410490
    7f716ee0b146:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0b14e:	add    rsp,0x150
    7f716ee0b155:	mov    eax,0x3
    7f716ee0b15a:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0b164:	jmp    r11
    7f716ee0b167:	jmp    0x7f716ee0182b
    7f716ee0b16c:	nop    DWORD PTR [rax+0x0]
    7f716ee0b170:	sub    rsp,0x150
    7f716ee0b177:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0b17f:	mov    QWORD PTR [rsp],r11
    7f716ee0b183:	cmp    DWORD PTR [r12+0x310],0x0
    7f716ee0b18c:	je     0x7f716ee0b217
    7f716ee0b192:	push   rdx
    7f716ee0b193:	push   rsi
    7f716ee0b194:	push   r10
    7f716ee0b196:	push   r11
    7f716ee0b198:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0b19d:	mov    r10d,edx
    7f716ee0b1a0:	and    r10d,0xc000
    7f716ee0b1a7:	shl    r10d,0x10
    7f716ee0b1ab:	mov    r11d,edx
    7f716ee0b1ae:	and    r11d,0x100
    7f716ee0b1b5:	shl    r11d,0x15
    7f716ee0b1b9:	or     r10d,r11d
    7f716ee0b1bc:	and    edx,0x1
    7f716ee0b1bf:	shl    edx,0x1c
    7f716ee0b1c2:	or     r10d,edx
    7f716ee0b1c5:	btc    r10,0x1d
    7f716ee0b1ca:	mov    r11d,0xf0000000
    7f716ee0b1d0:	and    r11,r10
    7f716ee0b1d3:	movabs rsi,0xffffffff0fffffff
    7f716ee0b1dd:	and    rbx,rsi
    7f716ee0b1e0:	or     rbx,r11
    7f716ee0b1e3:	pop    r11
    7f716ee0b1e5:	pop    r10
    7f716ee0b1e7:	pop    rsi
    7f716ee0b1e8:	pop    rdx
    7f716ee0b1e9:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0b1f1:	mov    eax,0x410500
    7f716ee0b1f6:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0b1fe:	add    rsp,0x150
    7f716ee0b205:	mov    eax,0x3
    7f716ee0b20a:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0b214:	jmp    r11
    7f716ee0b217:	mov    r11,rax
    7f716ee0b21a:	movzx  eax,WORD PTR [rsp]
    7f716ee0b21e:	add    al,0x7f
    7f716ee0b220:	sahf
    7f716ee0b221:	mov    rax,r11
    7f716ee0b224:	jmp    0x7f716ee01c37
    7f716ee0b229:	nop    DWORD PTR [rax+0x0]
    7f716ee0b230:	sub    rsp,0x150
    7f716ee0b237:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0b23f:	mov    QWORD PTR [rsp],r11
    7f716ee0b243:	cmp    DWORD PTR [r12+0x310],0x0
    7f716ee0b24c:	je     0x7f716ee0b2d7
    7f716ee0b252:	push   rdx
    7f716ee0b253:	push   rsi
    7f716ee0b254:	push   r10
    7f716ee0b256:	push   r11
    7f716ee0b258:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0b25d:	mov    r10d,edx
    7f716ee0b260:	and    r10d,0xc000
    7f716ee0b267:	shl    r10d,0x10
    7f716ee0b26b:	mov    r11d,edx
    7f716ee0b26e:	and    r11d,0x100
    7f716ee0b275:	shl    r11d,0x15
    7f716ee0b279:	or     r10d,r11d
    7f716ee0b27c:	and    edx,0x1
    7f716ee0b27f:	shl    edx,0x1c
    7f716ee0b282:	or     r10d,edx
    7f716ee0b285:	btc    r10,0x1d
    7f716ee0b28a:	mov    r11d,0xf0000000
    7f716ee0b290:	and    r11,r10
    7f716ee0b293:	movabs rsi,0xffffffff0fffffff
    7f716ee0b29d:	and    rbx,rsi
    7f716ee0b2a0:	or     rbx,r11
    7f716ee0b2a3:	pop    r11
    7f716ee0b2a5:	pop    r10
    7f716ee0b2a7:	pop    rsi
    7f716ee0b2a8:	pop    rdx
    7f716ee0b2a9:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0b2b1:	mov    eax,0x410504
    7f716ee0b2b6:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0b2be:	add    rsp,0x150
    7f716ee0b2c5:	mov    eax,0x3
    7f716ee0b2ca:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0b2d4:	jmp    r11
    7f716ee0b2d7:	jmp    0x7f716ee01c55
    7f716ee0b2dc:	nop    DWORD PTR [rax+0x0]
    7f716ee0b2e0:	sub    rsp,0x150
    7f716ee0b2e7:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0b2ef:	mov    QWORD PTR [rsp],r11
    7f716ee0b2f3:	cmp    DWORD PTR [r12+0x310],0x0
    7f716ee0b2fc:	je     0x7f716ee0b387
    7f716ee0b302:	push   rdx
    7f716ee0b303:	push   rsi
    7f716ee0b304:	push   r10
    7f716ee0b306:	push   r11
    7f716ee0b308:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0b30d:	mov    r10d,edx
    7f716ee0b310:	and    r10d,0xc000
    7f716ee0b317:	shl    r10d,0x10
    7f716ee0b31b:	mov    r11d,edx
    7f716ee0b31e:	and    r11d,0x100
    7f716ee0b325:	shl    r11d,0x15
    7f716ee0b329:	or     r10d,r11d
    7f716ee0b32c:	and    edx,0x1
    7f716ee0b32f:	shl    edx,0x1c
    7f716ee0b332:	or     r10d,edx
    7f716ee0b335:	btc    r10,0x1d
    7f716ee0b33a:	mov    r11d,0xf0000000
    7f716ee0b340:	and    r11,r10
    7f716ee0b343:	movabs rsi,0xffffffff0fffffff
    7f716ee0b34d:	and    rbx,rsi
    7f716ee0b350:	or     rbx,r11
    7f716ee0b353:	pop    r11
    7f716ee0b355:	pop    r10
    7f716ee0b357:	pop    rsi
    7f716ee0b358:	pop    rdx
    7f716ee0b359:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0b361:	mov    eax,0x4106d0
    7f716ee0b366:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0b36e:	add    rsp,0x150
    7f716ee0b375:	mov    eax,0x3
    7f716ee0b37a:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0b384:	jmp    r11
    7f716ee0b387:	jmp    0x7f716ee03995
    7f716ee0b38c:	nop    DWORD PTR [rax+0x0]
    7f716ee0b390:	sub    rsp,0x150
    7f716ee0b397:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0b39f:	mov    QWORD PTR [rsp],r11
    7f716ee0b3a3:	cmp    DWORD PTR [r12+0x310],0x0
    7f716ee0b3ac:	je     0x7f716ee0b437
    7f716ee0b3b2:	push   rdx
    7f716ee0b3b3:	push   rsi
    7f716ee0b3b4:	push   r10
    7f716ee0b3b6:	push   r11
    7f716ee0b3b8:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0b3bd:	mov    r10d,edx
    7f716ee0b3c0:	and    r10d,0xc000
    7f716ee0b3c7:	shl    r10d,0x10
    7f716ee0b3cb:	mov    r11d,edx
    7f716ee0b3ce:	and    r11d,0x100
    7f716ee0b3d5:	shl    r11d,0x15
    7f716ee0b3d9:	or     r10d,r11d
    7f716ee0b3dc:	and    edx,0x1
    7f716ee0b3df:	shl    edx,0x1c
    7f716ee0b3e2:	or     r10d,edx
    7f716ee0b3e5:	btc    r10,0x1d
    7f716ee0b3ea:	mov    r11d,0xf0000000
    7f716ee0b3f0:	and    r11,r10
    7f716ee0b3f3:	movabs rsi,0xffffffff0fffffff
    7f716ee0b3fd:	and    rbx,rsi
    7f716ee0b400:	or     rbx,r11
    7f716ee0b403:	pop    r11
    7f716ee0b405:	pop    r10
    7f716ee0b407:	pop    rsi
    7f716ee0b408:	pop    rdx
    7f716ee0b409:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0b411:	mov    eax,0x4106dc
    7f716ee0b416:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0b41e:	add    rsp,0x150
    7f716ee0b425:	mov    eax,0x3
    7f716ee0b42a:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0b434:	jmp    r11
    7f716ee0b437:	jmp    0x7f716ee039d2
    7f716ee0b43c:	nop    DWORD PTR [rax+0x0]
    7f716ee0b440:	sub    rsp,0x150
    7f716ee0b447:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0b44f:	mov    QWORD PTR [rsp],r11
    7f716ee0b453:	cmp    DWORD PTR [r12+0x310],0x0
    7f716ee0b45c:	je     0x7f716ee0b4e7
    7f716ee0b462:	push   rdx
    7f716ee0b463:	push   rsi
    7f716ee0b464:	push   r10
    7f716ee0b466:	push   r11
    7f716ee0b468:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0b46d:	mov    r10d,edx
    7f716ee0b470:	and    r10d,0xc000
    7f716ee0b477:	shl    r10d,0x10
    7f716ee0b47b:	mov    r11d,edx
    7f716ee0b47e:	and    r11d,0x100
    7f716ee0b485:	shl    r11d,0x15
    7f716ee0b489:	or     r10d,r11d
    7f716ee0b48c:	and    edx,0x1
    7f716ee0b48f:	shl    edx,0x1c
    7f716ee0b492:	or     r10d,edx
    7f716ee0b495:	btc    r10,0x1d
    7f716ee0b49a:	mov    r11d,0xf0000000
    7f716ee0b4a0:	and    r11,r10
    7f716ee0b4a3:	movabs rsi,0xffffffff0fffffff
    7f716ee0b4ad:	and    rbx,rsi
    7f716ee0b4b0:	or     rbx,r11
    7f716ee0b4b3:	pop    r11
    7f716ee0b4b5:	pop    r10
    7f716ee0b4b7:	pop    rsi
    7f716ee0b4b8:	pop    rdx
    7f716ee0b4b9:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0b4c1:	mov    eax,0x4106e8
    7f716ee0b4c6:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0b4ce:	add    rsp,0x150
    7f716ee0b4d5:	mov    eax,0x3
    7f716ee0b4da:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0b4e4:	jmp    r11
    7f716ee0b4e7:	jmp    0x7f716ee03a0d
    7f716ee0b4ec:	nop    DWORD PTR [rax+0x0]
    7f716ee0b4f0:	sub    rsp,0x150
    7f716ee0b4f7:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0b4ff:	mov    QWORD PTR [rsp],r11
    7f716ee0b503:	cmp    DWORD PTR [r12+0x310],0x0
    7f716ee0b50c:	je     0x7f716ee0b597
    7f716ee0b512:	push   rdx
    7f716ee0b513:	push   rsi
    7f716ee0b514:	push   r10
    7f716ee0b516:	push   r11
    7f716ee0b518:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0b51d:	mov    r10d,edx
    7f716ee0b520:	and    r10d,0xc000
    7f716ee0b527:	shl    r10d,0x10
    7f716ee0b52b:	mov    r11d,edx
    7f716ee0b52e:	and    r11d,0x100
    7f716ee0b535:	shl    r11d,0x15
    7f716ee0b539:	or     r10d,r11d
    7f716ee0b53c:	and    edx,0x1
    7f716ee0b53f:	shl    edx,0x1c
    7f716ee0b542:	or     r10d,edx
    7f716ee0b545:	btc    r10,0x1d
    7f716ee0b54a:	mov    r11d,0xf0000000
    7f716ee0b550:	and    r11,r10
    7f716ee0b553:	movabs rsi,0xffffffff0fffffff
    7f716ee0b55d:	and    rbx,rsi
    7f716ee0b560:	or     rbx,r11
    7f716ee0b563:	pop    r11
    7f716ee0b565:	pop    r10
    7f716ee0b567:	pop    rsi
    7f716ee0b568:	pop    rdx
    7f716ee0b569:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0b571:	mov    eax,0x410704
    7f716ee0b576:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0b57e:	add    rsp,0x150
    7f716ee0b585:	mov    eax,0x3
    7f716ee0b58a:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0b594:	jmp    r11
    7f716ee0b597:	jmp    0x7f716ee03b66
    7f716ee0b59c:	nop    DWORD PTR [rax+0x0]
    7f716ee0b5a0:	sub    rsp,0x150
    7f716ee0b5a7:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0b5af:	mov    QWORD PTR [rsp],r11
    7f716ee0b5b3:	cmp    DWORD PTR [r12+0x310],0x0
    7f716ee0b5bc:	je     0x7f716ee0b647
    7f716ee0b5c2:	push   rdx
    7f716ee0b5c3:	push   rsi
    7f716ee0b5c4:	push   r10
    7f716ee0b5c6:	push   r11
    7f716ee0b5c8:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0b5cd:	mov    r10d,edx
    7f716ee0b5d0:	and    r10d,0xc000
    7f716ee0b5d7:	shl    r10d,0x10
    7f716ee0b5db:	mov    r11d,edx
    7f716ee0b5de:	and    r11d,0x100
    7f716ee0b5e5:	shl    r11d,0x15
    7f716ee0b5e9:	or     r10d,r11d
    7f716ee0b5ec:	and    edx,0x1
    7f716ee0b5ef:	shl    edx,0x1c
    7f716ee0b5f2:	or     r10d,edx
    7f716ee0b5f5:	btc    r10,0x1d
    7f716ee0b5fa:	mov    r11d,0xf0000000
    7f716ee0b600:	and    r11,r10
    7f716ee0b603:	movabs rsi,0xffffffff0fffffff
    7f716ee0b60d:	and    rbx,rsi
    7f716ee0b610:	or     rbx,r11
    7f716ee0b613:	pop    r11
    7f716ee0b615:	pop    r10
    7f716ee0b617:	pop    rsi
    7f716ee0b618:	pop    rdx
    7f716ee0b619:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee0b621:	mov    eax,0x4103f0
    7f716ee0b626:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0b62e:	add    rsp,0x150
    7f716ee0b635:	mov    eax,0x3
    7f716ee0b63a:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0b644:	jmp    r11
    7f716ee0b647:	jmp    0x7f716ee03d43
    7f716ee0b64c:	nop    DWORD PTR [rax+0x0]
    7f716ee0b650:	(bad)
    7f716ee0b651:	(bad)
    7f716ee0b652:	(bad)
    7f716ee0b653:	(bad)
    7f716ee0b654:	(bad)
    7f716ee0b655:	(bad)
    7f716ee0b656:	(bad)
    7f716ee0b657:	jg     0x7f716ee0b658
    7f716ee0b659:	(bad)
    7f716ee0b65a:	(bad)
    7f716ee0b65b:	(bad)
    7f716ee0b65c:	(bad)
    7f716ee0b65d:	(bad)
    7f716ee0b65e:	(bad)
    7f716ee0b65f:	jg     0x7f716ee0b661
    7f716ee0b661:	add    BYTE PTR [rax],al
    7f716ee0b663:	add    BYTE PTR [rax],al
    7f716ee0b665:	add    BYTE PTR [rax],dl
    7f716ee0b667:	add    BYTE PTR [rax],al
    7f716ee0b669:	add    BYTE PTR [rax],al
    7f716ee0b66b:	add    BYTE PTR [rax],al
    7f716ee0b66d:	add    BYTE PTR [rax],dl
	...
