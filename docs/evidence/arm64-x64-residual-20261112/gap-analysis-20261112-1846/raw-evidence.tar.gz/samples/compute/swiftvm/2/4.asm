
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/2/4.bin:     file format binary


Disassembly of section .data:

00007f716ee00080 <.data>:
    7f716ee00080:	sub    rsp,0x10
    7f716ee00084:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0008c:	mov    QWORD PTR [rsp],r11
    7f716ee00090:	mov    r13,QWORD PTR [r12+0xf8]
    7f716ee00098:	add    r13,0x168
    7f716ee0009f:	mov    r14,QWORD PTR [r13+0x0]
    7f716ee000a3:	mov    QWORD PTR [r12+0x40],r14
    7f716ee000a8:	sub    r14,0x38
    7f716ee000ac:	mov    rcx,QWORD PTR [r12+0x380]
    7f716ee000b4:	jrcxz  0x7f716ee000bb
    7f716ee000b6:	jmp    0x7f716ee0018d
    7f716ee000bb:	jne    0x7f716ee000d4
    7f716ee000c1:	mov    r11,rax
    7f716ee000c4:	lahf
    7f716ee000c5:	seto   al
    7f716ee000c8:	mov    WORD PTR [rsp],ax
    7f716ee000cc:	mov    rax,r11
    7f716ee000cf:	jmp    0x7f716ee000e7
    7f716ee000d4:	mov    r11,rax
    7f716ee000d7:	lahf
    7f716ee000d8:	seto   al
    7f716ee000db:	mov    WORD PTR [rsp],ax
    7f716ee000df:	mov    rax,r11
    7f716ee000e2:	jmp    0x7f716ee0013d
    7f716ee000e7:	mov    r13d,0x4102d4
    7f716ee000ed:	mov    QWORD PTR [r12+0x100],r13
    7f716ee000f5:	mov    r11,QWORD PTR [rsp]
    7f716ee000f9:	mov    QWORD PTR [r12+0x398],r11
    7f716ee00101:	mov    edi,0x4102d4
    7f716ee00106:	mov    QWORD PTR [r12+0x100],rdi
    7f716ee0010e:	add    rsp,0x10
    7f716ee00112:	nop    WORD PTR [rax+rax*1+0x0]
    7f716ee00118:	jmp    QWORD PTR [rip+0x2]        # 0x7f716ee00120
    7f716ee0011e:	xchg   ax,ax
    7f716ee00120:	(bad)
    7f716ee00121:	add    al,ah
    7f716ee00123:	outs   dx,BYTE PTR ds:[rsi]
    7f716ee00124:	jno    0x7f716ee001a5
    7f716ee00126:	add    BYTE PTR [rax],al
    7f716ee00128:	xor    BYTE PTR [rcx],al
    7f716ee0012a:	loopne 0x7f716ee0019a
    7f716ee0012c:	jno    0x7f716ee001ad
    7f716ee0012e:	add    BYTE PTR [rax],al
    7f716ee00130:	movabs r11,0x5fdfb8bf7940
    7f716ee0013a:	jmp    r11
    7f716ee0013d:	mov    r13d,0x4102b8
    7f716ee00143:	mov    QWORD PTR [r12+0x100],r13
    7f716ee0014b:	mov    r11,QWORD PTR [rsp]
    7f716ee0014f:	mov    QWORD PTR [r12+0x398],r11
    7f716ee00157:	mov    edi,0x4102b8
    7f716ee0015c:	mov    QWORD PTR [r12+0x100],rdi
    7f716ee00164:	add    rsp,0x10
    7f716ee00168:	jmp    QWORD PTR [rip+0x2]        # 0x7f716ee00170
    7f716ee0016e:	xchg   ax,ax
    7f716ee00170:	add    al,spl
    7f716ee00173:	outs   dx,BYTE PTR ds:[rsi]
    7f716ee00174:	jno    0x7f716ee001f5
    7f716ee00176:	add    BYTE PTR [rax],al
    7f716ee00178:	add    BYTE PTR [rcx],0xe0
    7f716ee0017b:	outs   dx,BYTE PTR ds:[rsi]
    7f716ee0017c:	jno    0x7f716ee001fd
    7f716ee0017e:	add    BYTE PTR [rax],al
    7f716ee00180:	movabs r11,0x5fdfb8bf7940
    7f716ee0018a:	jmp    r11
    7f716ee0018d:	mov    eax,0x4102d0
    7f716ee00192:	mov    QWORD PTR [r12+0x100],rax
    7f716ee0019a:	push   rdx
    7f716ee0019b:	push   rsi
    7f716ee0019c:	push   r10
    7f716ee0019e:	push   r11
    7f716ee001a0:	mov    r11,rax
    7f716ee001a3:	lahf
    7f716ee001a4:	seto   al
    7f716ee001a7:	mov    WORD PTR [rsp+0x20],ax
    7f716ee001ac:	mov    rax,r11
    7f716ee001af:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee001b4:	mov    r10d,edx
    7f716ee001b7:	and    r10d,0xc000
    7f716ee001be:	shl    r10d,0x10
    7f716ee001c2:	mov    r11d,edx
    7f716ee001c5:	and    r11d,0x100
    7f716ee001cc:	shl    r11d,0x15
    7f716ee001d0:	or     r10d,r11d
    7f716ee001d3:	and    edx,0x1
    7f716ee001d6:	shl    edx,0x1c
    7f716ee001d9:	or     r10d,edx
    7f716ee001dc:	btc    r10,0x1d
    7f716ee001e1:	mov    r11d,0xf0000000
    7f716ee001e7:	and    r11,r10
    7f716ee001ea:	movabs rsi,0xffffffff0fffffff
    7f716ee001f4:	and    rbx,rsi
    7f716ee001f7:	or     rbx,r11
    7f716ee001fa:	pop    r11
    7f716ee001fc:	pop    r10
    7f716ee001fe:	pop    rsi
    7f716ee001ff:	pop    rdx
    7f716ee00200:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee00208:	add    rsp,0x10
    7f716ee0020c:	mov    eax,0xc
    7f716ee00211:	movabs r11,0x5fdfb8bf7ca0
    7f716ee0021b:	jmp    r11
    7f716ee0021e:	nop
    7f716ee0021f:	nop
