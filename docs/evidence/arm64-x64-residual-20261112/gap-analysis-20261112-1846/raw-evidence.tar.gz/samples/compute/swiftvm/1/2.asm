
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/1/2.bin:     file format binary


Disassembly of section .data:

000075b0bab00b80 <.data>:
    75b0bab00b80:	sub    rsp,0x10
    75b0bab00b84:	mov    r13d,DWORD PTR [r12+0xa0]
    75b0bab00b8c:	sub    r13d,0x1
    75b0bab00b90:	mov    QWORD PTR [r12+0xa0],r13
    75b0bab00b98:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab00ba0:	jrcxz  0x75b0bab00ba7
    75b0bab00ba2:	jmp    0x75b0bab00d3d
    75b0bab00ba7:	jne    0x75b0bab00bc0
    75b0bab00bad:	mov    r11,rax
    75b0bab00bb0:	lahf
    75b0bab00bb1:	seto   al
    75b0bab00bb4:	mov    WORD PTR [rsp],ax
    75b0bab00bb8:	mov    rax,r11
    75b0bab00bbb:	jmp    0x75b0bab00bd3
    75b0bab00bc0:	mov    r11,rax
    75b0bab00bc3:	lahf
    75b0bab00bc4:	seto   al
    75b0bab00bc7:	mov    WORD PTR [rsp],ax
    75b0bab00bcb:	mov    rax,r11
    75b0bab00bce:	jmp    0x75b0bab00ca5
    75b0bab00bd3:	mov    r13,QWORD PTR [r12+0xf8]
    75b0bab00bdb:	mov    r14,r13
    75b0bab00bde:	add    r14,0x120
    75b0bab00be5:	mov    r15,QWORD PTR [r14]
    75b0bab00be8:	mov    QWORD PTR [r12+0x98],r15
    75b0bab00bf0:	mov    r14d,0x80
    75b0bab00bf6:	mov    QWORD PTR [r12+0x40],r14
    75b0bab00bfb:	mov    r14,r13
    75b0bab00bfe:	add    r14,0x100
    75b0bab00c05:	mov    QWORD PTR [r12],r14
    75b0bab00c09:	mov    r14,r13
    75b0bab00c0c:	add    r14,0x17c
    75b0bab00c13:	mov    QWORD PTR [r12+0x8],r14
    75b0bab00c18:	mov    r14d,0x1
    75b0bab00c1e:	mov    QWORD PTR [r12+0x10],r14
    75b0bab00c23:	add    r13,0x17c
    75b0bab00c2a:	movzx  r14d,BYTE PTR [r12+0x40]
    75b0bab00c30:	mov    BYTE PTR [r13+0x0],r14b
    75b0bab00c34:	mov    r13d,0x0
    75b0bab00c3a:	mov    DWORD PTR [r12+0x32c],r13d
    75b0bab00c42:	mov    r13d,0x4102a8
    75b0bab00c48:	mov    QWORD PTR [r12+0xf0],r13
    75b0bab00c50:	mov    r13d,0x410728
    75b0bab00c56:	mov    QWORD PTR [r12+0x100],r13
    75b0bab00c5e:	mov    r11,QWORD PTR [rsp]
    75b0bab00c62:	mov    QWORD PTR [r12+0x398],r11
    75b0bab00c6a:	mov    edi,0x410728
    75b0bab00c6f:	mov    QWORD PTR [r12+0x100],rdi
    75b0bab00c77:	add    rsp,0x10
    75b0bab00c7b:	nop    DWORD PTR [rax+rax*1+0x0]
    75b0bab00c80:	jmp    QWORD PTR [rip+0x2]        # 0x75b0bab00c88
    75b0bab00c86:	xchg   ax,ax
    75b0bab00c88:	loopne 0x75b0bab00c6f
    75b0bab00c8a:	scas   eax,DWORD PTR es:[rdi]
    75b0bab00c8b:	mov    edx,0x75b0
    75b0bab00c90:	cwde
    75b0bab00c91:	or     al,0xb0
    75b0bab00c93:	mov    edx,0x75b0
    75b0bab00c98:	movabs r11,0x59d8f50c0940
    75b0bab00ca2:	jmp    r11
    75b0bab00ca5:	mov    r13,QWORD PTR [r12+0xf8]
    75b0bab00cad:	add    r13,0x100
    75b0bab00cb4:	mov    QWORD PTR [r12],r13
    75b0bab00cb8:	mov    r13d,0x0
    75b0bab00cbe:	mov    r14,QWORD PTR [r12+0x98]
    75b0bab00cc6:	or     r13,r14
    75b0bab00cc9:	mov    QWORD PTR [r12+0x8],r13
    75b0bab00cce:	mov    r13d,0x12c
    75b0bab00cd4:	mov    QWORD PTR [r12+0x10],r13
    75b0bab00cd9:	mov    r13d,0x410284
    75b0bab00cdf:	mov    QWORD PTR [r12+0xf0],r13
    75b0bab00ce7:	mov    r13d,0x410728
    75b0bab00ced:	mov    QWORD PTR [r12+0x100],r13
    75b0bab00cf5:	mov    r11,QWORD PTR [rsp]
    75b0bab00cf9:	mov    QWORD PTR [r12+0x398],r11
    75b0bab00d01:	mov    edi,0x410728
    75b0bab00d06:	mov    QWORD PTR [r12+0x100],rdi
    75b0bab00d0e:	add    rsp,0x10
    75b0bab00d12:	nop    WORD PTR [rax+rax*1+0x0]
    75b0bab00d18:	jmp    QWORD PTR [rip+0x2]        # 0x75b0bab00d20
    75b0bab00d1e:	xchg   ax,ax
    75b0bab00d20:	loopne 0x75b0bab00d07
    75b0bab00d22:	scas   eax,DWORD PTR es:[rdi]
    75b0bab00d23:	mov    edx,0x75b0
    75b0bab00d28:	xor    BYTE PTR [rip+0x75b0bab0],cl        # 0x75b13060c7de
    75b0bab00d2e:	add    BYTE PTR [rax],al
    75b0bab00d30:	movabs r11,0x59d8f50c0940
    75b0bab00d3a:	jmp    r11
    75b0bab00d3d:	mov    eax,0x410288
    75b0bab00d42:	mov    QWORD PTR [r12+0x100],rax
    75b0bab00d4a:	push   rdx
    75b0bab00d4b:	push   rsi
    75b0bab00d4c:	push   r10
    75b0bab00d4e:	push   r11
    75b0bab00d50:	mov    r11,rax
    75b0bab00d53:	lahf
    75b0bab00d54:	seto   al
    75b0bab00d57:	mov    WORD PTR [rsp+0x20],ax
    75b0bab00d5c:	mov    rax,r11
    75b0bab00d5f:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab00d64:	mov    r10d,edx
    75b0bab00d67:	and    r10d,0xc000
    75b0bab00d6e:	shl    r10d,0x10
    75b0bab00d72:	mov    r11d,edx
    75b0bab00d75:	and    r11d,0x100
    75b0bab00d7c:	shl    r11d,0x15
    75b0bab00d80:	or     r10d,r11d
    75b0bab00d83:	and    edx,0x1
    75b0bab00d86:	shl    edx,0x1c
    75b0bab00d89:	or     r10d,edx
    75b0bab00d8c:	btc    r10,0x1d
    75b0bab00d91:	mov    r11d,0xf0000000
    75b0bab00d97:	and    r11,r10
    75b0bab00d9a:	movabs rsi,0xffffffff0fffffff
    75b0bab00da4:	and    rbx,rsi
    75b0bab00da7:	or     rbx,r11
    75b0bab00daa:	pop    r11
    75b0bab00dac:	pop    r10
    75b0bab00dae:	pop    rsi
    75b0bab00daf:	pop    rdx
    75b0bab00db0:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab00db8:	add    rsp,0x10
    75b0bab00dbc:	mov    eax,0xc
    75b0bab00dc1:	movabs r11,0x59d8f50c0ca0
    75b0bab00dcb:	jmp    r11
    75b0bab00dce:	xchg   ax,ax
    75b0bab00dd0:	sub    rsp,0x10
    75b0bab00dd4:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab00ddc:	mov    QWORD PTR [rsp],r11
    75b0bab00de0:	jmp    0x75b0bab00bd3
    75b0bab00de5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab00df0:	sub    rsp,0x10
    75b0bab00df4:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab00dfc:	mov    QWORD PTR [rsp],r11
    75b0bab00e00:	jmp    0x75b0bab00ca5
    75b0bab00e05:	nop
    75b0bab00e06:	nop
    75b0bab00e07:	nop
