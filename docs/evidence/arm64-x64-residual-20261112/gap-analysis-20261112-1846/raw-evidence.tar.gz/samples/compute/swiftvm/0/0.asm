
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

000074a37e4fe000 <.data>:
    74a37e4fe000:	sub    rsp,0x10
    74a37e4fe004:	mov    r11,QWORD PTR [r12+0x398]
    74a37e4fe00c:	mov    QWORD PTR [rsp],r11
    74a37e4fe010:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e4fe018:	sub    r13,0x1e0
    74a37e4fe01f:	mov    QWORD PTR [r12+0xf8],r13
    74a37e4fe027:	mov    r14d,0x420000
    74a37e4fe02d:	mov    QWORD PTR [r12+0x40],r14
    74a37e4fe032:	mov    r14d,0x420000
    74a37e4fe038:	mov    QWORD PTR [r12+0x48],r14
    74a37e4fe03d:	mov    r14,r13
    74a37e4fe040:	add    r14,0x1d0
    74a37e4fe047:	mov    r15,r14
    74a37e4fe04a:	add    r15,0x8
    74a37e4fe04e:	mov    rbp,QWORD PTR [r12+0xa0]
    74a37e4fe056:	mov    r8,QWORD PTR [r12+0x98]
    74a37e4fe05e:	mov    QWORD PTR [r14],rbp
    74a37e4fe061:	mov    r14d,0x0
    74a37e4fe067:	mov    DWORD PTR [r12+0x32c],r14d
    74a37e4fe06f:	mov    QWORD PTR [r15],r8
    74a37e4fe072:	mov    r14d,0x420aa0
    74a37e4fe078:	movdqu xmm2,XMMWORD PTR [r14]
    74a37e4fe07d:	movdqu XMMWORD PTR [r12+0x110],xmm2
    74a37e4fe087:	mov    r14d,0x420a30
    74a37e4fe08d:	movdqu xmm3,XMMWORD PTR [r14]
    74a37e4fe092:	movdqu XMMWORD PTR [r12+0x120],xmm3
    74a37e4fe09c:	mov    r14d,0x420ac0
    74a37e4fe0a2:	movdqu xmm4,XMMWORD PTR [r14]
    74a37e4fe0a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
    74a37e4fe0b1:	mov    r14d,0x420a60
    74a37e4fe0b7:	movdqu xmm5,XMMWORD PTR [r14]
    74a37e4fe0bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
    74a37e4fe0c6:	mov    r14d,0x430000
    74a37e4fe0cc:	mov    rax,r14
    74a37e4fe0cf:	add    rax,0xcd0
    74a37e4fe0d5:	mov    QWORD PTR [r12+0x98],rax
    74a37e4fe0dd:	mov    r15d,0x420ad0
    74a37e4fe0e3:	movdqu xmm6,XMMWORD PTR [r15]
    74a37e4fe0e8:	movdqu XMMWORD PTR [r12+0x150],xmm6
    74a37e4fe0f2:	mov    r15,QWORD PTR [r12+0x98]
    74a37e4fe0fa:	add    r15,0x10
    74a37e4fe0fe:	mov    rdi,QWORD PTR [r12+0x98]
    74a37e4fe106:	movdqu XMMWORD PTR [rdi],xmm2
    74a37e4fe10a:	movdqu XMMWORD PTR [r15],xmm3
    74a37e4fe10f:	mov    r15,QWORD PTR [r12+0x98]
    74a37e4fe117:	add    r15,0x20
    74a37e4fe11b:	mov    rbp,r15
    74a37e4fe11e:	add    rbp,0x10
    74a37e4fe122:	movdqu XMMWORD PTR [r15],xmm4
    74a37e4fe127:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    74a37e4fe12c:	mov    r15d,0x420a20
    74a37e4fe132:	movdqu xmm4,XMMWORD PTR [r15]
    74a37e4fe137:	movdqu XMMWORD PTR [r12+0x130],xmm4
    74a37e4fe141:	mov    r15d,0x420a10
    74a37e4fe147:	movdqu xmm5,XMMWORD PTR [r15]
    74a37e4fe14c:	movdqu XMMWORD PTR [r12+0x140],xmm5
    74a37e4fe156:	mov    r15,QWORD PTR [r12+0x98]
    74a37e4fe15e:	add    r15,0x100
    74a37e4fe165:	mov    rbp,r15
    74a37e4fe168:	add    rbp,0x10
    74a37e4fe16c:	movdqu XMMWORD PTR [r15],xmm2
    74a37e4fe171:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    74a37e4fe176:	mov    r15,QWORD PTR [r12+0x98]
    74a37e4fe17e:	add    r15,0x40
    74a37e4fe182:	mov    rbp,r15
    74a37e4fe185:	add    rbp,0x10
    74a37e4fe189:	movdqu XMMWORD PTR [r15],xmm6
    74a37e4fe18e:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    74a37e4fe193:	mov    r15d,0x420a00
    74a37e4fe199:	movdqu xmm2,XMMWORD PTR [r15]
    74a37e4fe19e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    74a37e4fe1a8:	mov    r15d,0x420a70
    74a37e4fe1ae:	movdqu xmm3,XMMWORD PTR [r15]
    74a37e4fe1b3:	movdqu XMMWORD PTR [r12+0x150],xmm3
    74a37e4fe1bd:	mov    r15d,0xf8d3
    74a37e4fe1c3:	mov    QWORD PTR [r12+0x48],r15
    74a37e4fe1c8:	mov    r15,QWORD PTR [r12+0x98]
    74a37e4fe1d0:	add    r15,0x60
    74a37e4fe1d4:	mov    rbp,r15
    74a37e4fe1d7:	add    rbp,0x10
    74a37e4fe1db:	movdqu XMMWORD PTR [r15],xmm5
    74a37e4fe1e0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    74a37e4fe1e5:	mov    r15d,0x420a80
    74a37e4fe1eb:	movdqu xmm2,XMMWORD PTR [r15]
    74a37e4fe1f0:	movdqu XMMWORD PTR [r12+0x130],xmm2
    74a37e4fe1fa:	mov    r15d,0x420a50
    74a37e4fe200:	movdqu xmm4,XMMWORD PTR [r15]
    74a37e4fe205:	movdqu XMMWORD PTR [r12+0x140],xmm4
    74a37e4fe20f:	mov    r15d,0xf8d3
    74a37e4fe215:	mov    ebp,0x421d
    74a37e4fe21a:	and    ebp,0xffff
    74a37e4fe220:	mov    rax,r15
    74a37e4fe223:	movabs rcx,0xffffffff0000ffff
    74a37e4fe22d:	and    rax,rcx
    74a37e4fe230:	mov    rdx,rbp
    74a37e4fe233:	shl    rdx,0x10
    74a37e4fe237:	mov    ecx,0xffff0000
    74a37e4fe23c:	and    rdx,rcx
    74a37e4fe23f:	or     rax,rdx
    74a37e4fe242:	mov    r8d,eax
    74a37e4fe245:	mov    QWORD PTR [r12+0x48],r8
    74a37e4fe24a:	mov    r15,QWORD PTR [r12+0x98]
    74a37e4fe252:	add    r15,0x80
    74a37e4fe259:	mov    rbp,r15
    74a37e4fe25c:	add    rbp,0x10
    74a37e4fe260:	movdqu XMMWORD PTR [r15],xmm3
    74a37e4fe265:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    74a37e4fe26a:	mov    r15d,0x420af0
    74a37e4fe270:	movdqu xmm2,XMMWORD PTR [r15]
    74a37e4fe275:	movdqu XMMWORD PTR [r12+0x130],xmm2
    74a37e4fe27f:	mov    r15d,0x420b00
    74a37e4fe285:	movdqu xmm3,XMMWORD PTR [r15]
    74a37e4fe28a:	movdqu XMMWORD PTR [r12+0x150],xmm3
    74a37e4fe294:	mov    r15d,0x3e8
    74a37e4fe29a:	mov    QWORD PTR [r12+0xa0],r15
    74a37e4fe2a2:	mov    r15,QWORD PTR [r12+0x98]
    74a37e4fe2aa:	add    r15,0xa0
    74a37e4fe2b1:	mov    rbp,r15
    74a37e4fe2b4:	add    rbp,0x10
    74a37e4fe2b8:	movdqu XMMWORD PTR [r15],xmm4
    74a37e4fe2bd:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    74a37e4fe2c2:	mov    r15d,0x420ae0
    74a37e4fe2c8:	movdqu xmm2,XMMWORD PTR [r15]
    74a37e4fe2cd:	movdqu XMMWORD PTR [r12+0x130],xmm2
    74a37e4fe2d7:	mov    r15d,0x420a90
    74a37e4fe2dd:	movdqu xmm4,XMMWORD PTR [r15]
    74a37e4fe2e2:	movdqu XMMWORD PTR [r12+0x140],xmm4
    74a37e4fe2ec:	mov    r15,r13
    74a37e4fe2ef:	add    r15,0x180
    74a37e4fe2f6:	mov    rbp,r15
    74a37e4fe2f9:	add    rbp,0x8
    74a37e4fe2fd:	mov    r9,QWORD PTR [r12+0x200]
    74a37e4fe305:	mov    r14,QWORD PTR [r12+0x1f0]
    74a37e4fe30d:	mov    QWORD PTR [r15],r9
    74a37e4fe310:	mov    QWORD PTR [rbp+0x0],r14
    74a37e4fe314:	mov    r14,QWORD PTR [r12+0x98]
    74a37e4fe31c:	add    r14,0xc0
    74a37e4fe323:	mov    r15,r14
    74a37e4fe326:	add    r15,0x10
    74a37e4fe32a:	movdqu XMMWORD PTR [r14],xmm3
    74a37e4fe32f:	movdqu XMMWORD PTR [r15],xmm2
    74a37e4fe334:	mov    r14d,0x420ab0
    74a37e4fe33a:	movdqu xmm2,XMMWORD PTR [r14]
    74a37e4fe33f:	movdqu XMMWORD PTR [r12+0x130],xmm2
    74a37e4fe349:	mov    r14d,0x420b18
    74a37e4fe34f:	mov    r15,QWORD PTR [r14]
    74a37e4fe352:	mov    r14d,0x0
    74a37e4fe358:	mov    QWORD PTR [r12+0x110],r15
    74a37e4fe360:	mov    QWORD PTR [r12+0x118],r14
    74a37e4fe368:	mov    r14d,0x420b20
    74a37e4fe36e:	mov    QWORD PTR [r12+0x40],r14
    74a37e4fe373:	mov    r14,QWORD PTR [r12+0x98]
    74a37e4fe37b:	add    r14,0xe0
    74a37e4fe382:	mov    rbp,r14
    74a37e4fe385:	add    rbp,0x10
    74a37e4fe389:	movdqu XMMWORD PTR [r14],xmm4
    74a37e4fe38e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    74a37e4fe393:	mov    r14d,0x420b80
    74a37e4fe399:	movdqu xmm2,XMMWORD PTR [r14]
    74a37e4fe39e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    74a37e4fe3a8:	mov    r14,QWORD PTR [r12+0x98]
    74a37e4fe3b0:	add    r14,0x120
    74a37e4fe3b7:	mov    QWORD PTR [r14],r15
    74a37e4fe3ba:	mov    r14d,0x420b60
    74a37e4fe3c0:	mov    r15d,0x420b70
    74a37e4fe3c6:	movdqu xmm3,XMMWORD PTR [r14]
    74a37e4fe3cb:	movdqu xmm4,XMMWORD PTR [r15]
    74a37e4fe3d0:	movdqu XMMWORD PTR [r12+0x120],xmm3
    74a37e4fe3da:	movdqu XMMWORD PTR [r12+0x110],xmm4
    74a37e4fe3e4:	mov    r14,r13
    74a37e4fe3e7:	add    r14,0x160
    74a37e4fe3ee:	movdqu XMMWORD PTR [r14],xmm2
    74a37e4fe3f3:	mov    r14,r13
    74a37e4fe3f6:	add    r14,0x190
    74a37e4fe3fd:	mov    r15,r14
    74a37e4fe400:	add    r15,0x8
    74a37e4fe404:	mov    rbp,QWORD PTR [r12+0x1e0]
    74a37e4fe40c:	mov    r9,QWORD PTR [r12+0x1d0]
    74a37e4fe414:	mov    QWORD PTR [r14],rbp
    74a37e4fe417:	mov    QWORD PTR [r15],r9
    74a37e4fe41a:	mov    r14,r13
    74a37e4fe41d:	add    r14,0x140
    74a37e4fe424:	mov    r15,r14
    74a37e4fe427:	add    r15,0x10
    74a37e4fe42b:	movdqu XMMWORD PTR [r14],xmm3
    74a37e4fe430:	movdqu XMMWORD PTR [r15],xmm4
    74a37e4fe435:	mov    r14d,0x420b20
    74a37e4fe43b:	mov    r15d,0x420b30
    74a37e4fe441:	movdqu xmm2,XMMWORD PTR [r14]
    74a37e4fe446:	movdqu xmm3,XMMWORD PTR [r15]
    74a37e4fe44b:	movdqu XMMWORD PTR [r12+0x110],xmm2
    74a37e4fe455:	movdqu XMMWORD PTR [r12+0x120],xmm3
    74a37e4fe45f:	mov    r14,r13
    74a37e4fe462:	add    r14,0x1a0
    74a37e4fe469:	mov    r15,r14
    74a37e4fe46c:	add    r15,0x8
    74a37e4fe470:	mov    rbp,QWORD PTR [r12+0x1c0]
    74a37e4fe478:	mov    r9,QWORD PTR [r12+0x1b0]
    74a37e4fe480:	mov    QWORD PTR [r14],rbp
    74a37e4fe483:	mov    QWORD PTR [r15],r9
    74a37e4fe486:	mov    r14,r13
    74a37e4fe489:	add    r14,0x1b0
    74a37e4fe490:	mov    r15,r14
    74a37e4fe493:	add    r15,0x8
    74a37e4fe497:	mov    rbp,QWORD PTR [r12+0x1a0]
    74a37e4fe49f:	mov    r9,QWORD PTR [r12+0x190]
    74a37e4fe4a7:	mov    QWORD PTR [r14],rbp
    74a37e4fe4aa:	mov    QWORD PTR [r15],r9
    74a37e4fe4ad:	mov    r14,r13
    74a37e4fe4b0:	add    r14,0x100
    74a37e4fe4b7:	mov    r15,r14
    74a37e4fe4ba:	add    r15,0x10
    74a37e4fe4be:	movdqu XMMWORD PTR [r14],xmm2
    74a37e4fe4c3:	movdqu XMMWORD PTR [r15],xmm3
    74a37e4fe4c8:	mov    r14d,0x420b40
    74a37e4fe4ce:	mov    r15d,0x420b50
    74a37e4fe4d4:	movdqu xmm2,XMMWORD PTR [r14]
    74a37e4fe4d9:	movdqu xmm3,XMMWORD PTR [r15]
    74a37e4fe4de:	movdqu XMMWORD PTR [r12+0x110],xmm2
    74a37e4fe4e8:	movdqu XMMWORD PTR [r12+0x130],xmm3
    74a37e4fe4f2:	mov    r14,r13
    74a37e4fe4f5:	add    r14,0x1c0
    74a37e4fe4fc:	mov    r15,r14
    74a37e4fe4ff:	add    r15,0x8
    74a37e4fe503:	mov    rbp,QWORD PTR [r12+0xe8]
    74a37e4fe50b:	mov    r9,QWORD PTR [r12+0xf0]
    74a37e4fe513:	mov    QWORD PTR [r14],rbp
    74a37e4fe516:	mov    QWORD PTR [r15],r9
    74a37e4fe519:	mov    r14,QWORD PTR [r12+0x98]
    74a37e4fe521:	add    r14,0x128
    74a37e4fe528:	mov    DWORD PTR [r14],r8d
    74a37e4fe52b:	mov    r14,r13
    74a37e4fe52e:	add    r14,0x120
    74a37e4fe535:	mov    r15,r14
    74a37e4fe538:	add    r15,0x10
    74a37e4fe53c:	movdqu XMMWORD PTR [r14],xmm2
    74a37e4fe541:	movdqu XMMWORD PTR [r15],xmm3
    74a37e4fe546:	add    r13,0x100
    74a37e4fe54d:	mov    QWORD PTR [r12],r13
    74a37e4fe551:	mov    r13d,0x0
    74a37e4fe557:	mov    rcx,QWORD PTR [r12+0x98]
    74a37e4fe55f:	or     r13,rcx
    74a37e4fe562:	mov    QWORD PTR [r12+0x8],r13
    74a37e4fe567:	mov    r13d,0x12c
    74a37e4fe56d:	mov    QWORD PTR [r12+0x10],r13
    74a37e4fe572:	mov    r13d,0x410284
    74a37e4fe578:	mov    QWORD PTR [r12+0xf0],r13
    74a37e4fe580:	mov    r13d,0x410728
    74a37e4fe586:	mov    QWORD PTR [r12+0x100],r13
    74a37e4fe58e:	mov    r11,QWORD PTR [rsp]
    74a37e4fe592:	mov    QWORD PTR [r12+0x398],r11
    74a37e4fe59a:	mov    edi,0x410728
    74a37e4fe59f:	mov    QWORD PTR [r12+0x100],rdi
    74a37e4fe5a7:	add    rsp,0x10
    74a37e4fe5ab:	nop    DWORD PTR [rax+rax*1+0x0]
    74a37e4fe5b0:	jmp    QWORD PTR [rip+0x2]        # 0x74a37e4fe5b8
    74a37e4fe5b6:	xchg   ax,ax
    74a37e4fe5b8:	loopne 0x74a37e4fe59f
    74a37e4fe5ba:	rex.WRXB jle 0x74a37e4fe560
    74a37e4fe5bd:	je     0x74a37e4fe5bf
    74a37e4fe5bf:	add    al,cl
    74a37e4fe5c1:	in     eax,0x4f
    74a37e4fe5c3:	jle    0x74a37e4fe568
    74a37e4fe5c5:	je     0x74a37e4fe5c7
    74a37e4fe5c7:	add    BYTE PTR [rcx-0x45],cl
    74a37e4fe5ca:	rex cdq
    74a37e4fe5cc:	outs   dx,BYTE PTR ds:[rsi]
    74a37e4fe5cd:	rex.RX adc eax,0x41000057
    74a37e4fe5d3:	jmp    rbx
    74a37e4fe5d5:	nop
    74a37e4fe5d6:	nop
    74a37e4fe5d7:	nop
