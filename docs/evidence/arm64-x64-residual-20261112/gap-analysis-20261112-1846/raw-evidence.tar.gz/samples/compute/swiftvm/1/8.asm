
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/1/8.bin:     file format binary


Disassembly of section .data:

000075b0bab02170 <.data>:
    75b0bab02170:	sub    rsp,0x150
    75b0bab02177:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0217f:	mov    QWORD PTR [rsp],r11
    75b0bab02183:	cmp    DWORD PTR [r12+0x310],0x0
    75b0bab0218c:	je     0x75b0bab02217
    75b0bab02192:	push   rdx
    75b0bab02193:	push   rsi
    75b0bab02194:	push   r10
    75b0bab02196:	push   r11
    75b0bab02198:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0219d:	mov    r10d,edx
    75b0bab021a0:	and    r10d,0xc000
    75b0bab021a7:	shl    r10d,0x10
    75b0bab021ab:	mov    r11d,edx
    75b0bab021ae:	and    r11d,0x100
    75b0bab021b5:	shl    r11d,0x15
    75b0bab021b9:	or     r10d,r11d
    75b0bab021bc:	and    edx,0x1
    75b0bab021bf:	shl    edx,0x1c
    75b0bab021c2:	or     r10d,edx
    75b0bab021c5:	btc    r10,0x1d
    75b0bab021ca:	mov    r11d,0xf0000000
    75b0bab021d0:	and    r11,r10
    75b0bab021d3:	movabs rsi,0xffffffff0fffffff
    75b0bab021dd:	and    rbx,rsi
    75b0bab021e0:	or     rbx,r11
    75b0bab021e3:	pop    r11
    75b0bab021e5:	pop    r10
    75b0bab021e7:	pop    rsi
    75b0bab021e8:	pop    rdx
    75b0bab021e9:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab021f1:	mov    eax,0x4103f8
    75b0bab021f6:	mov    QWORD PTR [r12+0x100],rax
    75b0bab021fe:	add    rsp,0x150
    75b0bab02205:	mov    eax,0x3
    75b0bab0220a:	movabs r11,0x59d8f50c0ca0
    75b0bab02214:	jmp    r11
    75b0bab02217:	mov    r13d,DWORD PTR [r12+0x98]
    75b0bab0221f:	add    r13d,0x1
    75b0bab02223:	mov    QWORD PTR [r12+0x98],r13
    75b0bab0222b:	sub    r13d,0x10000
    75b0bab02232:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab0223a:	jrcxz  0x75b0bab02241
    75b0bab0223c:	jmp    0x75b0bab0bbf5
    75b0bab02241:	jne    0x75b0bab0225a
    75b0bab02247:	mov    r11,rax
    75b0bab0224a:	lahf
    75b0bab0224b:	seto   al
    75b0bab0224e:	mov    WORD PTR [rsp],ax
    75b0bab02252:	mov    rax,r11
    75b0bab02255:	jmp    0x75b0bab0226d
    75b0bab0225a:	mov    r11,rax
    75b0bab0225d:	lahf
    75b0bab0225e:	seto   al
    75b0bab02261:	mov    WORD PTR [rsp],ax
    75b0bab02265:	mov    rax,r11
    75b0bab02268:	jmp    0x75b0bab04d43
    75b0bab0226d:	mov    r13d,0x420000
    75b0bab02273:	mov    QWORD PTR [r12+0x40],r13
    75b0bab02278:	movabs r13,0x100000001
    75b0bab02282:	mov    r14d,0x0
    75b0bab02288:	mov    QWORD PTR [r12+0x110],r13
    75b0bab02290:	mov    QWORD PTR [r12+0x118],r14
    75b0bab02298:	movabs r13,0x3fa0000000000000
    75b0bab022a2:	mov    QWORD PTR [r12+0x50],r13
    75b0bab022a7:	mov    r13d,0x420b10
    75b0bab022ad:	mov    r14,QWORD PTR [r13+0x0]
    75b0bab022b1:	mov    r13d,0x0
    75b0bab022b7:	mov    QWORD PTR [r12+0x120],r14
    75b0bab022bf:	mov    QWORD PTR [r12+0x128],r13
    75b0bab022c7:	movabs r13,0x4100000041
    75b0bab022d1:	mov    r14d,0x0
    75b0bab022d7:	mov    QWORD PTR [r12+0x140],r13
    75b0bab022df:	mov    QWORD PTR [r12+0x148],r14
    75b0bab022e7:	movabs r13,0x3fc0000000000000
    75b0bab022f1:	movabs r14,0x3fc0000000000000
    75b0bab022fb:	mov    QWORD PTR [r12+0x150],r13
    75b0bab02303:	mov    QWORD PTR [r12+0x158],r14
    75b0bab0230b:	movabs r13,0x200000002
    75b0bab02315:	mov    r14d,0x0
    75b0bab0231b:	mov    QWORD PTR [r12+0x160],r13
    75b0bab02323:	mov    QWORD PTR [r12+0x168],r14
    75b0bab0232b:	movabs r13,0x3fa0000000000000
    75b0bab02335:	mov    QWORD PTR [r12+0x130],r13
    75b0bab0233d:	mov    QWORD PTR [r12+0x138],r13
    75b0bab02345:	mov    r13d,0x2
    75b0bab0234b:	mov    QWORD PTR [r12+0x170],r13
    75b0bab02353:	mov    QWORD PTR [r12+0x178],r13
    75b0bab0235b:	mov    r13d,0x420000
    75b0bab02361:	mov    QWORD PTR [r12+0x40],r13
    75b0bab02366:	mov    r13d,0x430000
    75b0bab0236c:	mov    QWORD PTR [r12+0x50],r13
    75b0bab02371:	mov    r13d,0x420a40
    75b0bab02377:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    75b0bab0237d:	movdqu XMMWORD PTR [r12+0x180],xmm2
    75b0bab02387:	mov    r13d,0x0
    75b0bab0238d:	mov    QWORD PTR [r12+0x48],r13
    75b0bab02392:	mov    r13d,0x431000
    75b0bab02398:	add    r13,0xe00
    75b0bab0239f:	mov    QWORD PTR [r12+0x40],r13
    75b0bab023a4:	mov    r13d,0x430cb8
    75b0bab023aa:	mov    r14d,DWORD PTR [r12]
    75b0bab023ae:	mov    DWORD PTR [r13+0x0],r14d
    75b0bab023b2:	mov    r13d,0x0
    75b0bab023b8:	mov    DWORD PTR [r12+0x32c],r13d
    75b0bab023c0:	mov    r13d,0x432000
    75b0bab023c6:	mov    QWORD PTR [r12+0x50],r13
    75b0bab023cb:	mov    r11,rax
    75b0bab023ce:	movzx  eax,WORD PTR [rsp]
    75b0bab023d2:	add    al,0x7f
    75b0bab023d4:	sahf
    75b0bab023d5:	mov    rax,r11
    75b0bab023d8:	jmp    0x75b0bab023dd
    75b0bab023dd:	mov    r13,QWORD PTR [r12+0x180]
    75b0bab023e5:	mov    r14,QWORD PTR [r12+0x188]
    75b0bab023ed:	mov    r15d,0x0
    75b0bab023f3:	mov    r11,rax
    75b0bab023f6:	lahf
    75b0bab023f7:	seto   al
    75b0bab023fa:	mov    WORD PTR [rsp],ax
    75b0bab023fe:	mov    rax,r11
    75b0bab02401:	mov    ecx,0xffffffff
    75b0bab02406:	and    r13,rcx
    75b0bab02409:	mov    rbp,r15
    75b0bab0240c:	or     rbp,r13
    75b0bab0240f:	mov    ecx,0xffffffff
    75b0bab02414:	and    r14,rcx
    75b0bab02417:	shl    r14,0x20
    75b0bab0241b:	or     rbp,r14
    75b0bab0241e:	mov    QWORD PTR [r12+0x210],rbp
    75b0bab02426:	mov    QWORD PTR [r12+0x218],r15
    75b0bab0242e:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    75b0bab02438:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    75b0bab02442:	movdqa xmm1,xmm3
    75b0bab02446:	psubd  xmm2,xmm1
    75b0bab0244a:	movdqa xmm14,xmm2
    75b0bab0244f:	movdqa xmm1,xmm14
    75b0bab02454:	movq   rax,xmm1
    75b0bab02459:	mov    r13,rax
    75b0bab0245c:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    75b0bab02466:	movdqu xmm4,XMMWORD PTR [r12+0x170]
    75b0bab02470:	movdqa xmm1,xmm4
    75b0bab02474:	paddq  xmm2,xmm1
    75b0bab02478:	movdqu XMMWORD PTR [r12+0x180],xmm2
    75b0bab02482:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    75b0bab0248c:	movdqa xmm1,xmm2
    75b0bab02490:	paddd  xmm3,xmm1
    75b0bab02494:	movdqa xmm14,xmm3
    75b0bab02499:	movdqa xmm1,xmm14
    75b0bab0249e:	movq   rax,xmm1
    75b0bab024a3:	mov    r14,rax
    75b0bab024a6:	mov    r15d,0x0
    75b0bab024ac:	mov    QWORD PTR [r12+0x120],r14
    75b0bab024b4:	mov    QWORD PTR [r12+0x128],r15
    75b0bab024bc:	mov    r14d,0x0
    75b0bab024c2:	mov    ecx,0xffffffff
    75b0bab024c7:	mov    r15,r13
    75b0bab024ca:	and    r15,rcx
    75b0bab024cd:	mov    rbp,r14
    75b0bab024d0:	or     rbp,r15
    75b0bab024d3:	shr    r13,0x20
    75b0bab024d7:	mov    ecx,0xffffffff
    75b0bab024dc:	and    r13,rcx
    75b0bab024df:	or     r14,r13
    75b0bab024e2:	mov    QWORD PTR [r12+0x220],rbp
    75b0bab024ea:	mov    QWORD PTR [r12+0x228],r14
    75b0bab024f2:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    75b0bab024fc:	movdqu xmm3,XMMWORD PTR [r12+0x110]
    75b0bab02506:	movdqa xmm1,xmm3
    75b0bab0250a:	paddd  xmm2,xmm1
    75b0bab0250e:	movdqa xmm14,xmm2
    75b0bab02513:	movdqa xmm1,xmm14
    75b0bab02518:	movq   rax,xmm1
    75b0bab0251d:	mov    r13,rax
    75b0bab02520:	mov    r14d,0x0
    75b0bab02526:	mov    QWORD PTR [r12+0x210],r13
    75b0bab0252e:	mov    QWORD PTR [r12+0x218],r14
    75b0bab02536:	lea    r13,[r12]
    75b0bab0253a:	movabs r14,0xb6e61da31
    75b0bab02544:	mov    r15d,0x410468
    75b0bab0254a:	mov    rdx,QWORD PTR [rsp]
    75b0bab0254e:	mov    r10d,edx
    75b0bab02551:	and    r10d,0xc000
    75b0bab02558:	shl    r10d,0x10
    75b0bab0255c:	mov    r11d,edx
    75b0bab0255f:	and    r11d,0x100
    75b0bab02566:	shl    r11d,0x15
    75b0bab0256a:	or     r10d,r11d
    75b0bab0256d:	and    edx,0x1
    75b0bab02570:	shl    edx,0x1c
    75b0bab02573:	or     r10d,edx
    75b0bab02576:	btc    r10,0x1d
    75b0bab0257b:	mov    r11d,0xf0000000
    75b0bab02581:	and    r11,r10
    75b0bab02584:	movabs rsi,0xffffffff0fffffff
    75b0bab0258e:	and    rbx,rsi
    75b0bab02591:	or     rbx,r11
    75b0bab02594:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab025a0:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab025a8:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab025ae:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab025b3:	test   r10d,0x3f
    75b0bab025ba:	je     0x75b0bab025df
    75b0bab025c0:	mov    r11d,r10d
    75b0bab025c3:	shr    r10d,1
    75b0bab025c6:	and    r10d,0x1e
    75b0bab025ca:	and    r11d,0x1
    75b0bab025ce:	or     r10d,r11d
    75b0bab025d1:	or     DWORD PTR [r12+0x314],r10d
    75b0bab025d9:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab025df:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab025e5:	movabs r11,0x59d8f4f225e0
    75b0bab025ef:	mov    rdi,r13
    75b0bab025f2:	mov    rsi,r14
    75b0bab025f5:	mov    rdx,r15
    75b0bab025f8:	call   r11
    75b0bab025fb:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab02601:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab02609:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab02615:	mov    rbp,rax
    75b0bab02618:	mov    r13,QWORD PTR [r12+0x210]
    75b0bab02620:	mov    r14d,0x0
    75b0bab02626:	mov    ecx,0xffffffff
    75b0bab0262b:	mov    r15,r13
    75b0bab0262e:	and    r15,rcx
    75b0bab02631:	mov    rbp,r14
    75b0bab02634:	or     rbp,r15
    75b0bab02637:	shr    r13,0x20
    75b0bab0263b:	mov    ecx,0xffffffff
    75b0bab02640:	and    r13,rcx
    75b0bab02643:	or     r14,r13
    75b0bab02646:	mov    QWORD PTR [r12+0x210],rbp
    75b0bab0264e:	mov    QWORD PTR [r12+0x218],r14
    75b0bab02656:	lea    r13,[r12]
    75b0bab0265a:	movabs r14,0xb6e61da10
    75b0bab02664:	mov    r15d,0x410470
    75b0bab0266a:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab02676:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0267e:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab02684:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab02689:	test   r10d,0x3f
    75b0bab02690:	je     0x75b0bab026b5
    75b0bab02696:	mov    r11d,r10d
    75b0bab02699:	shr    r10d,1
    75b0bab0269c:	and    r10d,0x1e
    75b0bab026a0:	and    r11d,0x1
    75b0bab026a4:	or     r10d,r11d
    75b0bab026a7:	or     DWORD PTR [r12+0x314],r10d
    75b0bab026af:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab026b5:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab026bb:	movabs r11,0x59d8f4f225e0
    75b0bab026c5:	mov    rdi,r13
    75b0bab026c8:	mov    rsi,r14
    75b0bab026cb:	mov    rdx,r15
    75b0bab026ce:	call   r11
    75b0bab026d1:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab026d7:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab026df:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab026eb:	mov    rbp,rax
    75b0bab026ee:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    75b0bab026f8:	movdqu xmm3,XMMWORD PTR [r12+0x150]
    75b0bab02702:	movdqa xmm0,xmm2
    75b0bab02706:	movdqa xmm1,xmm3
    75b0bab0270a:	mulpd  xmm0,xmm1
    75b0bab0270e:	movdqa xmm14,xmm0
    75b0bab02713:	movdqu xmm15,XMMWORD PTR [rip+0x9f34]        # 0x75b0bab0c650
    75b0bab0271c:	pand   xmm14,xmm15
    75b0bab02721:	movdqu xmm15,XMMWORD PTR [rip+0x9f36]        # 0x75b0bab0c660
    75b0bab0272a:	pcmpeqq xmm14,xmm15
    75b0bab02730:	movdqa xmm15,xmm0
    75b0bab02735:	cmpunordpd xmm15,xmm0
    75b0bab0273b:	por    xmm14,xmm15
    75b0bab02740:	pmovmskb ecx,xmm14
    75b0bab02745:	jrcxz  0x75b0bab0274c
    75b0bab02747:	jmp    0x75b0bab04dbd
    75b0bab0274c:	movdqa xmm4,xmm0
    75b0bab02750:	movdqu XMMWORD PTR [r12+0x220],xmm4
    75b0bab0275a:	mov    r13,QWORD PTR [r12+0x48]
    75b0bab0275f:	mov    r14,QWORD PTR [r12+0x50]
    75b0bab02764:	add    r14,r13
    75b0bab02767:	movdqu XMMWORD PTR [r14],xmm4
    75b0bab0276c:	mov    r14d,0x0
    75b0bab02772:	mov    DWORD PTR [r12+0x32c],r14d
    75b0bab0277a:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    75b0bab02784:	movdqu xmm3,XMMWORD PTR [r12+0x130]
    75b0bab0278e:	movdqa xmm0,xmm2
    75b0bab02792:	movdqa xmm1,xmm3
    75b0bab02796:	mulpd  xmm0,xmm1
    75b0bab0279a:	movdqa xmm14,xmm0
    75b0bab0279f:	movdqu xmm15,XMMWORD PTR [rip+0x9ea8]        # 0x75b0bab0c650
    75b0bab027a8:	pand   xmm14,xmm15
    75b0bab027ad:	movdqu xmm15,XMMWORD PTR [rip+0x9eaa]        # 0x75b0bab0c660
    75b0bab027b6:	pcmpeqq xmm14,xmm15
    75b0bab027bc:	movdqa xmm15,xmm0
    75b0bab027c1:	cmpunordpd xmm15,xmm0
    75b0bab027c7:	por    xmm14,xmm15
    75b0bab027cc:	pmovmskb ecx,xmm14
    75b0bab027d1:	jrcxz  0x75b0bab027d8
    75b0bab027d3:	jmp    0x75b0bab04de1
    75b0bab027d8:	movdqa xmm4,xmm0
    75b0bab027dc:	movdqu XMMWORD PTR [r12+0x210],xmm4
    75b0bab027e6:	mov    r14,QWORD PTR [r12+0x40]
    75b0bab027eb:	add    r14,r13
    75b0bab027ee:	movdqu XMMWORD PTR [r14],xmm4
    75b0bab027f3:	add    r13,0x10
    75b0bab027f7:	mov    QWORD PTR [r12+0x48],r13
    75b0bab027fc:	sub    r13,0x200
    75b0bab02803:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab0280b:	jrcxz  0x75b0bab02812
    75b0bab0280d:	jmp    0x75b0bab0bc89
    75b0bab02812:	jne    0x75b0bab023dd
    75b0bab02818:	mov    r11,rax
    75b0bab0281b:	lahf
    75b0bab0281c:	seto   al
    75b0bab0281f:	mov    WORD PTR [rsp],ax
    75b0bab02823:	mov    rax,r11
    75b0bab02826:	jmp    0x75b0bab0282b
    75b0bab0282b:	mov    r13,QWORD PTR [r12+0x50]
    75b0bab02830:	mov    r14,r13
    75b0bab02833:	add    r14,0x80
    75b0bab0283a:	mov    r15,r14
    75b0bab0283d:	add    r15,0x10
    75b0bab02841:	movdqu xmm2,XMMWORD PTR [r14]
    75b0bab02846:	movdqu xmm3,XMMWORD PTR [r15]
    75b0bab0284b:	movdqu XMMWORD PTR [r12+0x130],xmm2
    75b0bab02855:	movdqu XMMWORD PTR [r12+0x110],xmm3
    75b0bab0285f:	mov    r14d,0x0
    75b0bab02865:	mov    r15d,0x0
    75b0bab0286b:	mov    QWORD PTR [r12+0x1b0],r14
    75b0bab02873:	mov    QWORD PTR [r12+0x1b8],r15
    75b0bab0287b:	mov    r14,r13
    75b0bab0287e:	add    r14,0x40
    75b0bab02882:	mov    r15,r14
    75b0bab02885:	add    r15,0x10
    75b0bab02889:	movdqu xmm4,XMMWORD PTR [r14]
    75b0bab0288e:	movdqu xmm5,XMMWORD PTR [r15]
    75b0bab02893:	movdqu XMMWORD PTR [r12+0x250],xmm4
    75b0bab0289d:	movdqu XMMWORD PTR [r12+0x120],xmm5
    75b0bab028a7:	mov    r14d,0x0
    75b0bab028ad:	mov    QWORD PTR [r12+0x48],r14
    75b0bab028b2:	mov    r14,r13
    75b0bab028b5:	add    r14,0x10
    75b0bab028b9:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    75b0bab028bf:	movdqu xmm6,XMMWORD PTR [r14]
    75b0bab028c4:	movdqu XMMWORD PTR [r12+0x170],xmm4
    75b0bab028ce:	movdqu XMMWORD PTR [r12+0x180],xmm6
    75b0bab028d8:	mov    r14,QWORD PTR [r12+0xf8]
    75b0bab028e0:	mov    r15,r14
    75b0bab028e3:	add    r15,0xe0
    75b0bab028ea:	mov    rbp,r15
    75b0bab028ed:	add    rbp,0x10
    75b0bab028f1:	movdqu XMMWORD PTR [r15],xmm3
    75b0bab028f6:	mov    r15d,0x0
    75b0bab028fc:	mov    DWORD PTR [r12+0x32c],r15d
    75b0bab02904:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    75b0bab02909:	mov    r15,r13
    75b0bab0290c:	add    r15,0xc0
    75b0bab02913:	mov    rbp,r15
    75b0bab02916:	add    rbp,0x10
    75b0bab0291a:	movdqu xmm2,XMMWORD PTR [r15]
    75b0bab0291f:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    75b0bab02924:	movdqu XMMWORD PTR [r12+0x130],xmm2
    75b0bab0292e:	movdqu XMMWORD PTR [r12+0x110],xmm3
    75b0bab02938:	mov    r15,r13
    75b0bab0293b:	add    r15,0x140
    75b0bab02942:	mov    rbp,r15
    75b0bab02945:	add    rbp,0x10
    75b0bab02949:	movdqu xmm7,XMMWORD PTR [r15]
    75b0bab0294e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    75b0bab02954:	movdqu XMMWORD PTR [r12+0x270],xmm7
    75b0bab0295e:	movdqu XMMWORD PTR [r12+0x190],xmm8
    75b0bab02968:	mov    r15,r13
    75b0bab0296b:	add    r15,0x180
    75b0bab02972:	mov    rbp,r15
    75b0bab02975:	add    rbp,0x10
    75b0bab02979:	movdqu xmm7,XMMWORD PTR [r15]
    75b0bab0297e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    75b0bab02984:	movdqu XMMWORD PTR [r12+0x2a0],xmm7
    75b0bab0298e:	movdqu XMMWORD PTR [r12+0x1a0],xmm8
    75b0bab02998:	mov    r15,r14
    75b0bab0299b:	add    r15,0xc0
    75b0bab029a2:	mov    rbp,r15
    75b0bab029a5:	add    rbp,0x10
    75b0bab029a9:	movdqu XMMWORD PTR [r15],xmm3
    75b0bab029ae:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    75b0bab029b3:	mov    r15,r13
    75b0bab029b6:	add    r15,0x100
    75b0bab029bd:	mov    rbp,r15
    75b0bab029c0:	add    rbp,0x10
    75b0bab029c4:	movdqu xmm2,XMMWORD PTR [r15]
    75b0bab029c9:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    75b0bab029ce:	movdqu XMMWORD PTR [r12+0x110],xmm2
    75b0bab029d8:	movdqu XMMWORD PTR [r12+0x300],xmm3
    75b0bab029e2:	mov    r15,r13
    75b0bab029e5:	add    r15,0x1c0
    75b0bab029ec:	mov    rbp,r15
    75b0bab029ef:	add    rbp,0x10
    75b0bab029f3:	movdqu xmm3,XMMWORD PTR [r15]
    75b0bab029f8:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    75b0bab029fd:	movdqu XMMWORD PTR [r12+0x240],xmm3
    75b0bab02a07:	movdqu XMMWORD PTR [r12+0x1c0],xmm7
    75b0bab02a11:	mov    r15,r13
    75b0bab02a14:	add    r15,0x20
    75b0bab02a18:	mov    rbp,r15
    75b0bab02a1b:	add    rbp,0x10
    75b0bab02a1f:	movdqu xmm7,XMMWORD PTR [r15]
    75b0bab02a24:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    75b0bab02a2a:	movdqu XMMWORD PTR [r12+0x1d0],xmm7
    75b0bab02a34:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
    75b0bab02a3e:	mov    r15,r14
    75b0bab02a41:	add    r15,0x20
    75b0bab02a45:	mov    rbp,r15
    75b0bab02a48:	add    rbp,0x10
    75b0bab02a4c:	movdqu XMMWORD PTR [r15],xmm2
    75b0bab02a51:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    75b0bab02a56:	mov    r15,r13
    75b0bab02a59:	add    r15,0x60
    75b0bab02a5d:	mov    rbp,r15
    75b0bab02a60:	add    rbp,0x10
    75b0bab02a64:	movdqu xmm2,XMMWORD PTR [r15]
    75b0bab02a69:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    75b0bab02a6e:	movdqu XMMWORD PTR [r12+0x110],xmm2
    75b0bab02a78:	movdqu XMMWORD PTR [r12+0x120],xmm5
    75b0bab02a82:	mov    r15,r14
    75b0bab02a85:	add    r15,0x60
    75b0bab02a89:	mov    rbp,r15
    75b0bab02a8c:	add    rbp,0x10
    75b0bab02a90:	movdqu XMMWORD PTR [r15],xmm4
    75b0bab02a95:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    75b0bab02a9a:	mov    r15,r13
    75b0bab02a9d:	add    r15,0xe0
    75b0bab02aa4:	mov    rbp,r15
    75b0bab02aa7:	add    rbp,0x10
    75b0bab02aab:	movdqu xmm3,XMMWORD PTR [r15]
    75b0bab02ab0:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    75b0bab02ab5:	movdqu XMMWORD PTR [r12+0x200],xmm3
    75b0bab02abf:	movdqu XMMWORD PTR [r12+0x2d0],xmm4
    75b0bab02ac9:	mov    r15,r13
    75b0bab02acc:	add    r15,0x120
    75b0bab02ad3:	mov    rbp,r15
    75b0bab02ad6:	add    rbp,0x10
    75b0bab02ada:	movdqu xmm3,XMMWORD PTR [r15]
    75b0bab02adf:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    75b0bab02ae4:	movdqu XMMWORD PTR [r12+0x2e0],xmm3
    75b0bab02aee:	movdqu XMMWORD PTR [r12+0x2f0],xmm4
    75b0bab02af8:	mov    r15,r14
    75b0bab02afb:	add    r15,0xa0
    75b0bab02b02:	mov    rbp,r15
    75b0bab02b05:	add    rbp,0x10
    75b0bab02b09:	movdqu XMMWORD PTR [r15],xmm5
    75b0bab02b0e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    75b0bab02b13:	mov    r15,r13
    75b0bab02b16:	add    r15,0xa0
    75b0bab02b1d:	mov    rbp,r15
    75b0bab02b20:	add    rbp,0x10
    75b0bab02b24:	movdqu xmm2,XMMWORD PTR [r15]
    75b0bab02b29:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    75b0bab02b2e:	movdqu XMMWORD PTR [r12+0x110],xmm2
    75b0bab02b38:	movdqu XMMWORD PTR [r12+0x120],xmm3
    75b0bab02b42:	mov    r15,r13
    75b0bab02b45:	add    r15,0x160
    75b0bab02b4c:	mov    rbp,r15
    75b0bab02b4f:	add    rbp,0x10
    75b0bab02b53:	movdqu xmm4,XMMWORD PTR [r15]
    75b0bab02b58:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    75b0bab02b5d:	movdqu XMMWORD PTR [r12+0x2c0],xmm4
    75b0bab02b67:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
    75b0bab02b71:	mov    r15,r13
    75b0bab02b74:	add    r15,0x1a0
    75b0bab02b7b:	mov    rbp,r15
    75b0bab02b7e:	add    rbp,0x10
    75b0bab02b82:	movdqu xmm5,XMMWORD PTR [r15]
    75b0bab02b87:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    75b0bab02b8c:	movdqu XMMWORD PTR [r12+0x290],xmm5
    75b0bab02b96:	movdqu XMMWORD PTR [r12+0x1e0],xmm7
    75b0bab02ba0:	mov    r15,r14
    75b0bab02ba3:	add    r15,0x80
    75b0bab02baa:	mov    rbp,r15
    75b0bab02bad:	add    rbp,0x10
    75b0bab02bb1:	movdqu XMMWORD PTR [r15],xmm3
    75b0bab02bb6:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    75b0bab02bbb:	add    r13,0x1e0
    75b0bab02bc2:	mov    r15,r13
    75b0bab02bc5:	add    r15,0x10
    75b0bab02bc9:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    75b0bab02bcf:	movdqu xmm3,XMMWORD PTR [r15]
    75b0bab02bd4:	movdqu XMMWORD PTR [r12+0x230],xmm2
    75b0bab02bde:	movdqu XMMWORD PTR [r12+0x280],xmm3
    75b0bab02be8:	mov    r13d,0x432000
    75b0bab02bee:	add    r13,0x200
    75b0bab02bf5:	mov    QWORD PTR [r12+0x50],r13
    75b0bab02bfa:	mov    r13,r14
    75b0bab02bfd:	add    r13,0x40
    75b0bab02c01:	mov    r15,r13
    75b0bab02c04:	add    r15,0x10
    75b0bab02c08:	movdqu XMMWORD PTR [r13+0x0],xmm4
    75b0bab02c0e:	movdqu XMMWORD PTR [r15],xmm6
    75b0bab02c13:	mov    r13,r14
    75b0bab02c16:	add    r13,0x10
    75b0bab02c1a:	movdqu XMMWORD PTR [r14],xmm3
    75b0bab02c1f:	movdqu XMMWORD PTR [r13+0x0],xmm2
    75b0bab02c25:	mov    r11,rax
    75b0bab02c28:	movzx  eax,WORD PTR [rsp]
    75b0bab02c2c:	add    al,0x7f
    75b0bab02c2e:	sahf
    75b0bab02c2f:	mov    rax,r11
    75b0bab02c32:	jmp    0x75b0bab02c37
    75b0bab02c37:	mov    r13d,0x0
    75b0bab02c3d:	mov    QWORD PTR [r12+0x58],r13
    75b0bab02c42:	mov    r11,rax
    75b0bab02c45:	lahf
    75b0bab02c46:	seto   al
    75b0bab02c49:	mov    WORD PTR [rsp],ax
    75b0bab02c4d:	mov    rax,r11
    75b0bab02c50:	jmp    0x75b0bab02c55
    75b0bab02c55:	mov    r13,QWORD PTR [r12+0x58]
    75b0bab02c5a:	mov    r14,QWORD PTR [r12+0x40]
    75b0bab02c5f:	add    r14,r13
    75b0bab02c62:	mov    QWORD PTR [r12+0x60],r14
    75b0bab02c67:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    75b0bab02c71:	movdqa xmm0,xmm2
    75b0bab02c75:	movdqa xmm1,xmm2
    75b0bab02c79:	por    xmm0,xmm1
    75b0bab02c7d:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    75b0bab02c87:	movdqu xmm4,XMMWORD PTR [r12+0x1a0]
    75b0bab02c91:	movdqa xmm0,xmm4
    75b0bab02c95:	movdqa xmm1,xmm4
    75b0bab02c99:	por    xmm0,xmm1
    75b0bab02c9d:	movdqu XMMWORD PTR [r12+0x120],xmm0
    75b0bab02ca7:	mov    r15,r14
    75b0bab02caa:	add    r15,0x30
    75b0bab02cae:	mov    rbp,r15
    75b0bab02cb1:	add    rbp,0x8
    75b0bab02cb5:	mov    r8,QWORD PTR [r15]
    75b0bab02cb8:	mov    r15,QWORD PTR [rbp+0x0]
    75b0bab02cbc:	mov    ebp,0x0
    75b0bab02cc1:	mov    QWORD PTR [r12+0x130],r8
    75b0bab02cc9:	mov    QWORD PTR [r12+0x138],rbp
    75b0bab02cd1:	mov    ebp,0x0
    75b0bab02cd6:	mov    QWORD PTR [r12+0x280],r15
    75b0bab02cde:	mov    QWORD PTR [r12+0x288],rbp
    75b0bab02ce6:	movdqu xmm5,XMMWORD PTR [r12+0x270]
    75b0bab02cf0:	movdqa xmm0,xmm5
    75b0bab02cf4:	movdqa xmm1,xmm5
    75b0bab02cf8:	por    xmm0,xmm1
    75b0bab02cfc:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    75b0bab02d06:	mov    r15,r14
    75b0bab02d09:	add    r15,0x20
    75b0bab02d0d:	mov    rbp,r15
    75b0bab02d10:	add    rbp,0x8
    75b0bab02d14:	mov    r8,QWORD PTR [r15]
    75b0bab02d17:	mov    r15,QWORD PTR [rbp+0x0]
    75b0bab02d1b:	mov    ebp,0x0
    75b0bab02d20:	mov    QWORD PTR [r12+0x150],r8
    75b0bab02d28:	mov    QWORD PTR [r12+0x158],rbp
    75b0bab02d30:	mov    ebp,0x0
    75b0bab02d35:	mov    QWORD PTR [r12+0x140],r15
    75b0bab02d3d:	mov    QWORD PTR [r12+0x148],rbp
    75b0bab02d45:	mov    r15,r14
    75b0bab02d48:	add    r15,0x10
    75b0bab02d4c:	mov    rbp,r15
    75b0bab02d4f:	add    rbp,0x8
    75b0bab02d53:	mov    r8,QWORD PTR [r15]
    75b0bab02d56:	mov    r15,QWORD PTR [rbp+0x0]
    75b0bab02d5a:	mov    ebp,0x0
    75b0bab02d5f:	mov    QWORD PTR [r12+0x170],r8
    75b0bab02d67:	mov    QWORD PTR [r12+0x178],rbp
    75b0bab02d6f:	mov    ebp,0x0
    75b0bab02d74:	mov    QWORD PTR [r12+0x160],r15
    75b0bab02d7c:	mov    QWORD PTR [r12+0x168],rbp
    75b0bab02d84:	mov    r15d,0x8
    75b0bab02d8a:	mov    rbp,QWORD PTR [r14]
    75b0bab02d8d:	mov    QWORD PTR [r12+0x180],rbp
    75b0bab02d95:	mov    QWORD PTR [r12+0x188],rbp
    75b0bab02d9d:	add    r14,r15
    75b0bab02da0:	mov    QWORD PTR [r12+0x60],r14
    75b0bab02da5:	mov    r15,QWORD PTR [r14]
    75b0bab02da8:	mov    r14d,0x0
    75b0bab02dae:	mov    QWORD PTR [r12+0x230],r15
    75b0bab02db6:	mov    QWORD PTR [r12+0x238],r14
    75b0bab02dbe:	mov    r14,QWORD PTR [r12+0xf8]
    75b0bab02dc6:	mov    r15,r14
    75b0bab02dc9:	add    r15,0x50
    75b0bab02dcd:	mov    rbp,r15
    75b0bab02dd0:	add    rbp,0x10
    75b0bab02dd4:	movdqu xmm6,XMMWORD PTR [r15]
    75b0bab02dd9:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    75b0bab02dde:	movdqu XMMWORD PTR [r12+0x220],xmm6
    75b0bab02de8:	movdqu XMMWORD PTR [r12+0x210],xmm7
    75b0bab02df2:	mov    r15,r14
    75b0bab02df5:	add    r15,0x30
    75b0bab02df9:	movdqu xmm8,XMMWORD PTR [r15]
    75b0bab02dfe:	movdqu XMMWORD PTR [r12+0x110],xmm8
    75b0bab02e08:	mov    r15,QWORD PTR [r12+0x50]
    75b0bab02e0d:	add    r15,r13
    75b0bab02e10:	mov    QWORD PTR [r12+0x60],r15
    75b0bab02e15:	add    r13,0x40
    75b0bab02e19:	mov    QWORD PTR [r12+0x58],r13
    75b0bab02e1e:	movdqu xmm9,XMMWORD PTR [r12+0x180]
    75b0bab02e28:	movdqa xmm0,xmm9
    75b0bab02e2d:	movdqa xmm1,xmm2
    75b0bab02e31:	mulpd  xmm0,xmm1
    75b0bab02e35:	movdqa xmm14,xmm0
    75b0bab02e3a:	movdqu xmm15,XMMWORD PTR [rip+0x980d]        # 0x75b0bab0c650
    75b0bab02e43:	pand   xmm14,xmm15
    75b0bab02e48:	movdqu xmm15,XMMWORD PTR [rip+0x980f]        # 0x75b0bab0c660
    75b0bab02e51:	pcmpeqq xmm14,xmm15
    75b0bab02e57:	movdqa xmm15,xmm0
    75b0bab02e5c:	cmpunordpd xmm15,xmm0
    75b0bab02e62:	por    xmm14,xmm15
    75b0bab02e67:	pmovmskb ecx,xmm14
    75b0bab02e6c:	jrcxz  0x75b0bab02e73
    75b0bab02e6e:	jmp    0x75b0bab04e05
    75b0bab02e73:	movdqa xmm10,xmm0
    75b0bab02e78:	movdqu xmm2,XMMWORD PTR [r12+0x230]
    75b0bab02e82:	movdqa xmm0,xmm8
    75b0bab02e87:	movdqa xmm1,xmm2
    75b0bab02e8b:	pshufd xmm1,xmm1,0x44
    75b0bab02e90:	mulpd  xmm0,xmm1
    75b0bab02e94:	movdqa xmm14,xmm0
    75b0bab02e99:	movdqu xmm15,XMMWORD PTR [rip+0x97ae]        # 0x75b0bab0c650
    75b0bab02ea2:	pand   xmm14,xmm15
    75b0bab02ea7:	movdqu xmm15,XMMWORD PTR [rip+0x97b0]        # 0x75b0bab0c660
    75b0bab02eb0:	pcmpeqq xmm14,xmm15
    75b0bab02eb6:	movdqa xmm15,xmm0
    75b0bab02ebb:	cmpunordpd xmm15,xmm0
    75b0bab02ec1:	por    xmm14,xmm15
    75b0bab02ec6:	pmovmskb ecx,xmm14
    75b0bab02ecb:	jrcxz  0x75b0bab02ed2
    75b0bab02ecd:	jmp    0x75b0bab04e2a
    75b0bab02ed2:	movdqa xmm11,xmm0
    75b0bab02ed7:	movdqu XMMWORD PTR [r12+0x260],xmm11
    75b0bab02ee1:	mov    ebp,0x0
    75b0bab02ee6:	mov    r8d,0x0
    75b0bab02eec:	mov    QWORD PTR [r12+0x110],rbp
    75b0bab02ef4:	mov    QWORD PTR [r12+0x118],r8
    75b0bab02efc:	movdqa xmm0,xmm9
    75b0bab02f01:	movdqa xmm1,xmm7
    75b0bab02f05:	mulpd  xmm0,xmm1
    75b0bab02f09:	movdqa xmm14,xmm0
    75b0bab02f0e:	movdqu xmm15,XMMWORD PTR [rip+0x9739]        # 0x75b0bab0c650
    75b0bab02f17:	pand   xmm14,xmm15
    75b0bab02f1c:	movdqu xmm15,XMMWORD PTR [rip+0x973b]        # 0x75b0bab0c660
    75b0bab02f25:	pcmpeqq xmm14,xmm15
    75b0bab02f2b:	movdqa xmm15,xmm0
    75b0bab02f30:	cmpunordpd xmm15,xmm0
    75b0bab02f36:	por    xmm14,xmm15
    75b0bab02f3b:	pmovmskb ecx,xmm14
    75b0bab02f40:	jrcxz  0x75b0bab02f47
    75b0bab02f42:	jmp    0x75b0bab04e4f
    75b0bab02f47:	movdqa xmm8,xmm0
    75b0bab02f4c:	movdqa xmm0,xmm9
    75b0bab02f51:	movdqa xmm1,xmm6
    75b0bab02f55:	mulpd  xmm0,xmm1
    75b0bab02f59:	movdqa xmm14,xmm0
    75b0bab02f5e:	movdqu xmm15,XMMWORD PTR [rip+0x96e9]        # 0x75b0bab0c650
    75b0bab02f67:	pand   xmm14,xmm15
    75b0bab02f6c:	movdqu xmm15,XMMWORD PTR [rip+0x96eb]        # 0x75b0bab0c660
    75b0bab02f75:	pcmpeqq xmm14,xmm15
    75b0bab02f7b:	movdqa xmm15,xmm0
    75b0bab02f80:	cmpunordpd xmm15,xmm0
    75b0bab02f86:	por    xmm14,xmm15
    75b0bab02f8b:	pmovmskb ecx,xmm14
    75b0bab02f90:	jrcxz  0x75b0bab02f97
    75b0bab02f92:	jmp    0x75b0bab04e74
    75b0bab02f97:	movdqa xmm7,xmm0
    75b0bab02f9b:	movdqu xmm6,XMMWORD PTR [r12+0x1f0]
    75b0bab02fa5:	movdqa xmm0,xmm9
    75b0bab02faa:	movdqa xmm1,xmm6
    75b0bab02fae:	mulpd  xmm0,xmm1
    75b0bab02fb2:	movdqa xmm14,xmm0
    75b0bab02fb7:	movdqu xmm15,XMMWORD PTR [rip+0x9690]        # 0x75b0bab0c650
    75b0bab02fc0:	pand   xmm14,xmm15
    75b0bab02fc5:	movdqu xmm15,XMMWORD PTR [rip+0x9692]        # 0x75b0bab0c660
    75b0bab02fce:	pcmpeqq xmm14,xmm15
    75b0bab02fd4:	movdqa xmm15,xmm0
    75b0bab02fd9:	cmpunordpd xmm15,xmm0
    75b0bab02fdf:	por    xmm14,xmm15
    75b0bab02fe4:	pmovmskb ecx,xmm14
    75b0bab02fe9:	jrcxz  0x75b0bab02ff0
    75b0bab02feb:	jmp    0x75b0bab04e99
    75b0bab02ff0:	movdqa xmm12,xmm0
    75b0bab02ff5:	movdqu XMMWORD PTR [r12+0x180],xmm12
    75b0bab02fff:	movdqu xmm6,XMMWORD PTR [r12+0x2a0]
    75b0bab03009:	movdqa xmm0,xmm6
    75b0bab0300d:	movdqa xmm1,xmm6
    75b0bab03011:	por    xmm0,xmm1
    75b0bab03015:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    75b0bab0301f:	movdqu xmm9,XMMWORD PTR [r12+0x250]
    75b0bab03029:	movdqa xmm0,xmm9
    75b0bab0302e:	movdqa xmm1,xmm9
    75b0bab03033:	por    xmm0,xmm1
    75b0bab03037:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    75b0bab03041:	movdqa xmm0,xmm9
    75b0bab03046:	movdqa xmm1,xmm2
    75b0bab0304a:	pshufd xmm1,xmm1,0x44
    75b0bab0304f:	mulpd  xmm0,xmm1
    75b0bab03053:	movdqa xmm14,xmm0
    75b0bab03058:	movdqu xmm15,XMMWORD PTR [rip+0x95ef]        # 0x75b0bab0c650
    75b0bab03061:	pand   xmm14,xmm15
    75b0bab03066:	movdqu xmm15,XMMWORD PTR [rip+0x95f1]        # 0x75b0bab0c660
    75b0bab0306f:	pcmpeqq xmm14,xmm15
    75b0bab03075:	movdqa xmm15,xmm0
    75b0bab0307a:	cmpunordpd xmm15,xmm0
    75b0bab03080:	por    xmm14,xmm15
    75b0bab03085:	pmovmskb ecx,xmm14
    75b0bab0308a:	jrcxz  0x75b0bab03091
    75b0bab0308c:	jmp    0x75b0bab04ebe
    75b0bab03091:	movdqa xmm4,xmm0
    75b0bab03095:	movdqu XMMWORD PTR [r12+0x250],xmm4
    75b0bab0309f:	sub    r13,0x200
    75b0bab030a6:	movdqu xmm9,XMMWORD PTR [r12+0x110]
    75b0bab030b0:	movdqa xmm0,xmm10
    75b0bab030b5:	movdqa xmm1,xmm9
    75b0bab030ba:	addpd  xmm0,xmm1
    75b0bab030be:	movdqa xmm14,xmm0
    75b0bab030c3:	movdqu xmm15,XMMWORD PTR [rip+0x9584]        # 0x75b0bab0c650
    75b0bab030cc:	pand   xmm14,xmm15
    75b0bab030d1:	movdqu xmm15,XMMWORD PTR [rip+0x9586]        # 0x75b0bab0c660
    75b0bab030da:	pcmpeqq xmm14,xmm15
    75b0bab030e0:	movdqa xmm15,xmm0
    75b0bab030e5:	cmpunordpd xmm15,xmm0
    75b0bab030eb:	por    xmm14,xmm15
    75b0bab030f0:	pmovmskb ecx,xmm14
    75b0bab030f5:	jrcxz  0x75b0bab030fc
    75b0bab030f7:	jmp    0x75b0bab04ee3
    75b0bab030fc:	movdqu XMMWORD PTR [r12+0x240],xmm0
    75b0bab03106:	movdqu xmm10,XMMWORD PTR [r12+0x1b0]
    75b0bab03110:	movdqa xmm0,xmm8
    75b0bab03115:	movdqa xmm1,xmm10
    75b0bab0311a:	addpd  xmm0,xmm1
    75b0bab0311e:	movdqa xmm14,xmm0
    75b0bab03123:	movdqu xmm15,XMMWORD PTR [rip+0x9524]        # 0x75b0bab0c650
    75b0bab0312c:	pand   xmm14,xmm15
    75b0bab03131:	movdqu xmm15,XMMWORD PTR [rip+0x9526]        # 0x75b0bab0c660
    75b0bab0313a:	pcmpeqq xmm14,xmm15
    75b0bab03140:	movdqa xmm15,xmm0
    75b0bab03145:	cmpunordpd xmm15,xmm0
    75b0bab0314b:	por    xmm14,xmm15
    75b0bab03150:	pmovmskb ecx,xmm14
    75b0bab03155:	jrcxz  0x75b0bab0315c
    75b0bab03157:	jmp    0x75b0bab04f24
    75b0bab0315c:	movdqa xmm6,xmm0
    75b0bab03160:	movdqu XMMWORD PTR [r12+0x210],xmm6
    75b0bab0316a:	movdqa xmm0,xmm7
    75b0bab0316e:	movdqa xmm1,xmm10
    75b0bab03173:	addpd  xmm0,xmm1
    75b0bab03177:	movdqa xmm14,xmm0
    75b0bab0317c:	movdqu xmm15,XMMWORD PTR [rip+0x94cb]        # 0x75b0bab0c650
    75b0bab03185:	pand   xmm14,xmm15
    75b0bab0318a:	movdqu xmm15,XMMWORD PTR [rip+0x94cd]        # 0x75b0bab0c660
    75b0bab03193:	pcmpeqq xmm14,xmm15
    75b0bab03199:	movdqa xmm15,xmm0
    75b0bab0319e:	cmpunordpd xmm15,xmm0
    75b0bab031a4:	por    xmm14,xmm15
    75b0bab031a9:	pmovmskb ecx,xmm14
    75b0bab031ae:	jrcxz  0x75b0bab031b5
    75b0bab031b0:	jmp    0x75b0bab04f65
    75b0bab031b5:	movdqa xmm8,xmm0
    75b0bab031ba:	movdqu XMMWORD PTR [r12+0x220],xmm8
    75b0bab031c4:	movdqu xmm7,XMMWORD PTR [r12+0x2f0]
    75b0bab031ce:	setne  BYTE PTR [rsp+0x8]
    75b0bab031d3:	mov    r11,rax
    75b0bab031d6:	lahf
    75b0bab031d7:	seto   al
    75b0bab031da:	mov    WORD PTR [rsp],ax
    75b0bab031de:	mov    rax,r11
    75b0bab031e1:	movdqa xmm0,xmm7
    75b0bab031e5:	movdqa xmm1,xmm7
    75b0bab031e9:	por    xmm0,xmm1
    75b0bab031ed:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    75b0bab031f7:	movdqu xmm10,XMMWORD PTR [r12+0x2e0]
    75b0bab03201:	movdqa xmm0,xmm10
    75b0bab03206:	movdqa xmm1,xmm10
    75b0bab0320b:	por    xmm0,xmm1
    75b0bab0320f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    75b0bab03219:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    75b0bab03223:	movdqa xmm0,xmm13
    75b0bab03228:	movdqa xmm1,xmm13
    75b0bab0322d:	por    xmm0,xmm1
    75b0bab03231:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    75b0bab0323b:	movdqu xmm5,XMMWORD PTR [r12+0x200]
    75b0bab03245:	movdqa xmm0,xmm5
    75b0bab03249:	movdqa xmm1,xmm5
    75b0bab0324d:	por    xmm0,xmm1
    75b0bab03251:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    75b0bab0325b:	movdqu xmm7,XMMWORD PTR [r12+0x1c0]
    75b0bab03265:	movdqa xmm1,xmm7
    75b0bab03269:	por    xmm7,xmm1
    75b0bab0326d:	movdqu XMMWORD PTR [r12+0x200],xmm7
    75b0bab03277:	movdqu xmm3,XMMWORD PTR [r12+0x190]
    75b0bab03281:	movdqa xmm1,xmm3
    75b0bab03285:	por    xmm3,xmm1
    75b0bab03289:	movdqu XMMWORD PTR [r12+0x1c0],xmm3
    75b0bab03293:	movdqu xmm10,XMMWORD PTR [r12+0x300]
    75b0bab0329d:	movdqa xmm1,xmm10
    75b0bab032a2:	por    xmm10,xmm1
    75b0bab032a7:	movdqu XMMWORD PTR [r12+0x190],xmm10
    75b0bab032b1:	mov    r13,r14
    75b0bab032b4:	add    r13,0xa0
    75b0bab032bb:	mov    rbp,r13
    75b0bab032be:	add    rbp,0x10
    75b0bab032c2:	movdqu xmm13,XMMWORD PTR [r13+0x0]
    75b0bab032c8:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    75b0bab032cd:	movdqu XMMWORD PTR [r12+0x300],xmm13
    75b0bab032d7:	movdqu XMMWORD PTR [r12+0x270],xmm5
    75b0bab032e1:	movdqa xmm0,xmm12
    75b0bab032e6:	movdqa xmm1,xmm9
    75b0bab032eb:	addpd  xmm0,xmm1
    75b0bab032ef:	movdqa xmm14,xmm0
    75b0bab032f4:	movdqu xmm15,XMMWORD PTR [rip+0x9353]        # 0x75b0bab0c650
    75b0bab032fd:	pand   xmm14,xmm15
    75b0bab03302:	movdqu xmm15,XMMWORD PTR [rip+0x9355]        # 0x75b0bab0c660
    75b0bab0330b:	pcmpeqq xmm14,xmm15
    75b0bab03311:	movdqa xmm15,xmm0
    75b0bab03316:	cmpunordpd xmm15,xmm0
    75b0bab0331c:	por    xmm14,xmm15
    75b0bab03321:	pmovmskb ecx,xmm14
    75b0bab03326:	jrcxz  0x75b0bab0332d
    75b0bab03328:	jmp    0x75b0bab04fa5
    75b0bab0332d:	movdqu XMMWORD PTR [r12+0x180],xmm0
    75b0bab03337:	mov    r13,r14
    75b0bab0333a:	add    r13,0xf0
    75b0bab03341:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    75b0bab03347:	movdqu XMMWORD PTR [r12+0x110],xmm9
    75b0bab03351:	movdqa xmm0,xmm6
    75b0bab03355:	movdqa xmm1,xmm4
    75b0bab03359:	addpd  xmm0,xmm1
    75b0bab0335d:	movdqa xmm14,xmm0
    75b0bab03362:	movdqu xmm15,XMMWORD PTR [rip+0x92e5]        # 0x75b0bab0c650
    75b0bab0336b:	pand   xmm14,xmm15
    75b0bab03370:	movdqu xmm15,XMMWORD PTR [rip+0x92e7]        # 0x75b0bab0c660
    75b0bab03379:	pcmpeqq xmm14,xmm15
    75b0bab0337f:	movdqa xmm15,xmm0
    75b0bab03384:	cmpunordpd xmm15,xmm0
    75b0bab0338a:	por    xmm14,xmm15
    75b0bab0338f:	pmovmskb ecx,xmm14
    75b0bab03394:	jrcxz  0x75b0bab0339b
    75b0bab03396:	jmp    0x75b0bab04fcb
    75b0bab0339b:	movdqa xmm12,xmm0
    75b0bab033a0:	movdqu XMMWORD PTR [r12+0x210],xmm12
    75b0bab033aa:	movdqa xmm0,xmm8
    75b0bab033af:	movdqa xmm1,xmm11
    75b0bab033b4:	addpd  xmm0,xmm1
    75b0bab033b8:	movdqa xmm14,xmm0
    75b0bab033bd:	movdqu xmm15,XMMWORD PTR [rip+0x928a]        # 0x75b0bab0c650
    75b0bab033c6:	pand   xmm14,xmm15
    75b0bab033cb:	movdqu xmm15,XMMWORD PTR [rip+0x928c]        # 0x75b0bab0c660
    75b0bab033d4:	pcmpeqq xmm14,xmm15
    75b0bab033da:	movdqa xmm15,xmm0
    75b0bab033df:	cmpunordpd xmm15,xmm0
    75b0bab033e5:	por    xmm14,xmm15
    75b0bab033ea:	pmovmskb ecx,xmm14
    75b0bab033ef:	jrcxz  0x75b0bab033f6
    75b0bab033f1:	jmp    0x75b0bab04fef
    75b0bab033f6:	movdqa xmm4,xmm0
    75b0bab033fa:	movdqu XMMWORD PTR [r12+0x220],xmm4
    75b0bab03404:	movdqa xmm0,xmm5
    75b0bab03408:	movdqa xmm1,xmm2
    75b0bab0340c:	pshufd xmm1,xmm1,0x44
    75b0bab03411:	mulpd  xmm0,xmm1
    75b0bab03415:	movdqa xmm14,xmm0
    75b0bab0341a:	movdqu xmm15,XMMWORD PTR [rip+0x922d]        # 0x75b0bab0c650
    75b0bab03423:	pand   xmm14,xmm15
    75b0bab03428:	movdqu xmm15,XMMWORD PTR [rip+0x922f]        # 0x75b0bab0c660
    75b0bab03431:	pcmpeqq xmm14,xmm15
    75b0bab03437:	movdqa xmm15,xmm0
    75b0bab0343c:	cmpunordpd xmm15,xmm0
    75b0bab03442:	por    xmm14,xmm15
    75b0bab03447:	pmovmskb ecx,xmm14
    75b0bab0344c:	jrcxz  0x75b0bab03453
    75b0bab0344e:	jmp    0x75b0bab05015
    75b0bab03453:	movdqa xmm6,xmm0
    75b0bab03457:	movdqu XMMWORD PTR [r12+0x270],xmm6
    75b0bab03461:	movdqu xmm5,XMMWORD PTR [r12+0x170]
    75b0bab0346b:	movdqa xmm0,xmm9
    75b0bab03470:	movdqa xmm1,xmm5
    75b0bab03474:	pshufd xmm1,xmm1,0x44
    75b0bab03479:	mulpd  xmm0,xmm1
    75b0bab0347d:	movdqa xmm14,xmm0
    75b0bab03482:	movdqu xmm15,XMMWORD PTR [rip+0x91c5]        # 0x75b0bab0c650
    75b0bab0348b:	pand   xmm14,xmm15
    75b0bab03490:	movdqu xmm15,XMMWORD PTR [rip+0x91c7]        # 0x75b0bab0c660
    75b0bab03499:	pcmpeqq xmm14,xmm15
    75b0bab0349f:	movdqa xmm15,xmm0
    75b0bab034a4:	cmpunordpd xmm15,xmm0
    75b0bab034aa:	por    xmm14,xmm15
    75b0bab034af:	pmovmskb ecx,xmm14
    75b0bab034b4:	jrcxz  0x75b0bab034bb
    75b0bab034b6:	jmp    0x75b0bab05039
    75b0bab034bb:	movdqa xmm8,xmm0
    75b0bab034c0:	movdqu XMMWORD PTR [r12+0x250],xmm8
    75b0bab034ca:	mov    r13,r14
    75b0bab034cd:	add    r13,0xe0
    75b0bab034d4:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    75b0bab034da:	movdqu XMMWORD PTR [r12+0x110],xmm9
    75b0bab034e4:	movdqa xmm0,xmm13
    75b0bab034e9:	movdqa xmm1,xmm2
    75b0bab034ed:	pshufd xmm1,xmm1,0x44
    75b0bab034f2:	mulpd  xmm0,xmm1
    75b0bab034f6:	movdqa xmm14,xmm0
    75b0bab034fb:	movdqu xmm15,XMMWORD PTR [rip+0x914c]        # 0x75b0bab0c650
    75b0bab03504:	pand   xmm14,xmm15
    75b0bab03509:	movdqu xmm15,XMMWORD PTR [rip+0x914e]        # 0x75b0bab0c660
    75b0bab03512:	pcmpeqq xmm14,xmm15
    75b0bab03518:	movdqa xmm15,xmm0
    75b0bab0351d:	cmpunordpd xmm15,xmm0
    75b0bab03523:	por    xmm14,xmm15
    75b0bab03528:	pmovmskb ecx,xmm14
    75b0bab0352d:	jrcxz  0x75b0bab03534
    75b0bab0352f:	jmp    0x75b0bab0505e
    75b0bab03534:	movdqa xmm11,xmm0
    75b0bab03539:	movdqu XMMWORD PTR [r12+0x230],xmm11
    75b0bab03543:	movdqa xmm0,xmm10
    75b0bab03548:	movdqa xmm1,xmm10
    75b0bab0354d:	por    xmm0,xmm1
    75b0bab03551:	movdqu XMMWORD PTR [r12+0x300],xmm0
    75b0bab0355b:	movdqa xmm0,xmm3
    75b0bab0355f:	movdqa xmm1,xmm3
    75b0bab03563:	por    xmm0,xmm1
    75b0bab03567:	movdqu XMMWORD PTR [r12+0x190],xmm0
    75b0bab03571:	movdqa xmm0,xmm9
    75b0bab03576:	movdqa xmm1,xmm5
    75b0bab0357a:	pshufd xmm1,xmm1,0x44
    75b0bab0357f:	mulpd  xmm0,xmm1
    75b0bab03583:	movdqa xmm14,xmm0
    75b0bab03588:	movdqu xmm15,XMMWORD PTR [rip+0x90bf]        # 0x75b0bab0c650
    75b0bab03591:	pand   xmm14,xmm15
    75b0bab03596:	movdqu xmm15,XMMWORD PTR [rip+0x90c1]        # 0x75b0bab0c660
    75b0bab0359f:	pcmpeqq xmm14,xmm15
    75b0bab035a5:	movdqa xmm15,xmm0
    75b0bab035aa:	cmpunordpd xmm15,xmm0
    75b0bab035b0:	por    xmm14,xmm15
    75b0bab035b5:	pmovmskb ecx,xmm14
    75b0bab035ba:	jrcxz  0x75b0bab035c1
    75b0bab035bc:	jmp    0x75b0bab05083
    75b0bab035c1:	movdqa xmm2,xmm0
    75b0bab035c5:	movdqu XMMWORD PTR [r12+0x260],xmm2
    75b0bab035cf:	mov    r13,r14
    75b0bab035d2:	add    r13,0x90
    75b0bab035d9:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    75b0bab035df:	movdqu XMMWORD PTR [r12+0x110],xmm9
    75b0bab035e9:	movdqa xmm0,xmm7
    75b0bab035ed:	movdqa xmm1,xmm7
    75b0bab035f1:	por    xmm0,xmm1
    75b0bab035f5:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    75b0bab035ff:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    75b0bab03609:	movdqu xmm1,XMMWORD PTR [r12+0x2d0]
    75b0bab03613:	por    xmm13,xmm1
    75b0bab03618:	movdqu XMMWORD PTR [r12+0x200],xmm13
    75b0bab03622:	movdqu xmm7,XMMWORD PTR [r12+0x2e0]
    75b0bab0362c:	movdqu xmm1,XMMWORD PTR [r12+0x2e0]
    75b0bab03636:	por    xmm7,xmm1
    75b0bab0363a:	movdqu XMMWORD PTR [r12+0x2d0],xmm7
    75b0bab03644:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    75b0bab0364e:	movdqu xmm1,XMMWORD PTR [r12+0x2f0]
    75b0bab03658:	por    xmm0,xmm1
    75b0bab0365c:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    75b0bab03666:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    75b0bab03670:	movdqa xmm1,xmm6
    75b0bab03674:	addpd  xmm0,xmm1
    75b0bab03678:	movdqa xmm14,xmm0
    75b0bab0367d:	movdqu xmm15,XMMWORD PTR [rip+0x8fca]        # 0x75b0bab0c650
    75b0bab03686:	pand   xmm14,xmm15
    75b0bab0368b:	movdqu xmm15,XMMWORD PTR [rip+0x8fcc]        # 0x75b0bab0c660
    75b0bab03694:	pcmpeqq xmm14,xmm15
    75b0bab0369a:	movdqa xmm15,xmm0
    75b0bab0369f:	cmpunordpd xmm15,xmm0
    75b0bab036a5:	por    xmm14,xmm15
    75b0bab036aa:	pmovmskb ecx,xmm14
    75b0bab036af:	jrcxz  0x75b0bab036b6
    75b0bab036b1:	jmp    0x75b0bab050a8
    75b0bab036b6:	movdqa xmm3,xmm0
    75b0bab036ba:	movdqu XMMWORD PTR [r12+0x240],xmm3
    75b0bab036c4:	movdqa xmm0,xmm9
    75b0bab036c9:	movdqa xmm1,xmm5
    75b0bab036cd:	pshufd xmm1,xmm1,0x44
    75b0bab036d2:	mulpd  xmm0,xmm1
    75b0bab036d6:	movdqa xmm14,xmm0
    75b0bab036db:	movdqu xmm15,XMMWORD PTR [rip+0x8f6c]        # 0x75b0bab0c650
    75b0bab036e4:	pand   xmm14,xmm15
    75b0bab036e9:	movdqu xmm15,XMMWORD PTR [rip+0x8f6e]        # 0x75b0bab0c660
    75b0bab036f2:	pcmpeqq xmm14,xmm15
    75b0bab036f8:	movdqa xmm15,xmm0
    75b0bab036fd:	cmpunordpd xmm15,xmm0
    75b0bab03703:	por    xmm14,xmm15
    75b0bab03708:	pmovmskb ecx,xmm14
    75b0bab0370d:	jrcxz  0x75b0bab03714
    75b0bab0370f:	jmp    0x75b0bab050d2
    75b0bab03714:	movdqa xmm6,xmm0
    75b0bab03718:	movdqu XMMWORD PTR [r12+0x270],xmm6
    75b0bab03722:	mov    r13,r14
    75b0bab03725:	add    r13,0x80
    75b0bab0372c:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    75b0bab03732:	movdqu XMMWORD PTR [r12+0x110],xmm9
    75b0bab0373c:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    75b0bab03746:	movdqa xmm1,xmm11
    75b0bab0374b:	addpd  xmm0,xmm1
    75b0bab0374f:	movdqa xmm14,xmm0
    75b0bab03754:	movdqu xmm15,XMMWORD PTR [rip+0x8ef3]        # 0x75b0bab0c650
    75b0bab0375d:	pand   xmm14,xmm15
    75b0bab03762:	movdqu xmm15,XMMWORD PTR [rip+0x8ef5]        # 0x75b0bab0c660
    75b0bab0376b:	pcmpeqq xmm14,xmm15
    75b0bab03771:	movdqa xmm15,xmm0
    75b0bab03776:	cmpunordpd xmm15,xmm0
    75b0bab0377c:	por    xmm14,xmm15
    75b0bab03781:	pmovmskb ecx,xmm14
    75b0bab03786:	jrcxz  0x75b0bab0378d
    75b0bab03788:	jmp    0x75b0bab050f7
    75b0bab0378d:	movdqa xmm10,xmm0
    75b0bab03792:	movdqu XMMWORD PTR [r12+0x180],xmm10
    75b0bab0379c:	movdqa xmm0,xmm12
    75b0bab037a1:	movdqa xmm1,xmm8
    75b0bab037a6:	addpd  xmm0,xmm1
    75b0bab037aa:	movdqa xmm14,xmm0
    75b0bab037af:	movdqu xmm15,XMMWORD PTR [rip+0x8e98]        # 0x75b0bab0c650
    75b0bab037b8:	pand   xmm14,xmm15
    75b0bab037bd:	movdqu xmm15,XMMWORD PTR [rip+0x8e9a]        # 0x75b0bab0c660
    75b0bab037c6:	pcmpeqq xmm14,xmm15
    75b0bab037cc:	movdqa xmm15,xmm0
    75b0bab037d1:	cmpunordpd xmm15,xmm0
    75b0bab037d7:	por    xmm14,xmm15
    75b0bab037dc:	pmovmskb ecx,xmm14
    75b0bab037e1:	jrcxz  0x75b0bab037e8
    75b0bab037e3:	jmp    0x75b0bab05122
    75b0bab037e8:	movdqa xmm11,xmm0
    75b0bab037ed:	movdqu XMMWORD PTR [r12+0x210],xmm11
    75b0bab037f7:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    75b0bab03801:	movdqu xmm1,XMMWORD PTR [r12+0x1b0]
    75b0bab0380b:	por    xmm0,xmm1
    75b0bab0380f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    75b0bab03819:	movdqa xmm0,xmm9
    75b0bab0381e:	movdqa xmm1,xmm5
    75b0bab03822:	pshufd xmm1,xmm1,0x44
    75b0bab03827:	mulpd  xmm0,xmm1
    75b0bab0382b:	movdqa xmm14,xmm0
    75b0bab03830:	movdqu xmm15,XMMWORD PTR [rip+0x8e17]        # 0x75b0bab0c650
    75b0bab03839:	pand   xmm14,xmm15
    75b0bab0383e:	movdqu xmm15,XMMWORD PTR [rip+0x8e19]        # 0x75b0bab0c660
    75b0bab03847:	pcmpeqq xmm14,xmm15
    75b0bab0384d:	movdqa xmm15,xmm0
    75b0bab03852:	cmpunordpd xmm15,xmm0
    75b0bab03858:	por    xmm14,xmm15
    75b0bab0385d:	pmovmskb ecx,xmm14
    75b0bab03862:	jrcxz  0x75b0bab03869
    75b0bab03864:	jmp    0x75b0bab05148
    75b0bab03869:	movdqa xmm12,xmm0
    75b0bab0386e:	movdqu XMMWORD PTR [r12+0x170],xmm12
    75b0bab03878:	mov    r13,r14
    75b0bab0387b:	add    r13,0xd0
    75b0bab03882:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    75b0bab03888:	movdqu XMMWORD PTR [r12+0x110],xmm5
    75b0bab03892:	movdqa xmm0,xmm4
    75b0bab03896:	movdqa xmm1,xmm2
    75b0bab0389a:	addpd  xmm0,xmm1
    75b0bab0389e:	movdqa xmm14,xmm0
    75b0bab038a3:	movdqu xmm15,XMMWORD PTR [rip+0x8da4]        # 0x75b0bab0c650
    75b0bab038ac:	pand   xmm14,xmm15
    75b0bab038b1:	movdqu xmm15,XMMWORD PTR [rip+0x8da6]        # 0x75b0bab0c660
    75b0bab038ba:	pcmpeqq xmm14,xmm15
    75b0bab038c0:	movdqa xmm15,xmm0
    75b0bab038c5:	cmpunordpd xmm15,xmm0
    75b0bab038cb:	por    xmm14,xmm15
    75b0bab038d0:	pmovmskb ecx,xmm14
    75b0bab038d5:	jrcxz  0x75b0bab038dc
    75b0bab038d7:	jmp    0x75b0bab0516d
    75b0bab038dc:	movdqa xmm9,xmm0
    75b0bab038e1:	movdqu XMMWORD PTR [r12+0x220],xmm9
    75b0bab038eb:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    75b0bab038f5:	movdqa xmm0,xmm13
    75b0bab038fa:	movdqa xmm1,xmm2
    75b0bab038fe:	pshufd xmm1,xmm1,0x44
    75b0bab03903:	mulpd  xmm0,xmm1
    75b0bab03907:	movdqa xmm14,xmm0
    75b0bab0390c:	movdqu xmm15,XMMWORD PTR [rip+0x8d3b]        # 0x75b0bab0c650
    75b0bab03915:	pand   xmm14,xmm15
    75b0bab0391a:	movdqu xmm15,XMMWORD PTR [rip+0x8d3d]        # 0x75b0bab0c660
    75b0bab03923:	pcmpeqq xmm14,xmm15
    75b0bab03929:	movdqa xmm15,xmm0
    75b0bab0392e:	cmpunordpd xmm15,xmm0
    75b0bab03934:	por    xmm14,xmm15
    75b0bab03939:	pmovmskb ecx,xmm14
    75b0bab0393e:	jrcxz  0x75b0bab03945
    75b0bab03940:	jmp    0x75b0bab05191
    75b0bab03945:	movdqa xmm4,xmm0
    75b0bab03949:	movdqu XMMWORD PTR [r12+0x260],xmm4
    75b0bab03953:	mov    r13d,0x0
    75b0bab03959:	mov    ebp,0x0
    75b0bab0395e:	mov    QWORD PTR [r12+0x1b0],r13
    75b0bab03966:	mov    QWORD PTR [r12+0x1b8],rbp
    75b0bab0396e:	movdqa xmm0,xmm5
    75b0bab03972:	movdqa xmm1,xmm2
    75b0bab03976:	pshufd xmm1,xmm1,0x44
    75b0bab0397b:	mulpd  xmm0,xmm1
    75b0bab0397f:	movdqa xmm14,xmm0
    75b0bab03984:	movdqu xmm15,XMMWORD PTR [rip+0x8cc3]        # 0x75b0bab0c650
    75b0bab0398d:	pand   xmm14,xmm15
    75b0bab03992:	movdqu xmm15,XMMWORD PTR [rip+0x8cc5]        # 0x75b0bab0c660
    75b0bab0399b:	pcmpeqq xmm14,xmm15
    75b0bab039a1:	movdqa xmm15,xmm0
    75b0bab039a6:	cmpunordpd xmm15,xmm0
    75b0bab039ac:	por    xmm14,xmm15
    75b0bab039b1:	pmovmskb ecx,xmm14
    75b0bab039b6:	jrcxz  0x75b0bab039bd
    75b0bab039b8:	jmp    0x75b0bab051b6
    75b0bab039bd:	movdqa xmm13,xmm0
    75b0bab039c2:	movdqu XMMWORD PTR [r12+0x230],xmm13
    75b0bab039cc:	mov    r13,r14
    75b0bab039cf:	add    r13,0xc0
    75b0bab039d6:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    75b0bab039dc:	movdqu XMMWORD PTR [r12+0x110],xmm5
    75b0bab039e6:	movdqa xmm0,xmm3
    75b0bab039ea:	movdqa xmm1,xmm6
    75b0bab039ee:	addpd  xmm0,xmm1
    75b0bab039f2:	movdqa xmm14,xmm0
    75b0bab039f7:	movdqu xmm15,XMMWORD PTR [rip+0x8c50]        # 0x75b0bab0c650
    75b0bab03a00:	pand   xmm14,xmm15
    75b0bab03a05:	movdqu xmm15,XMMWORD PTR [rip+0x8c52]        # 0x75b0bab0c660
    75b0bab03a0e:	pcmpeqq xmm14,xmm15
    75b0bab03a14:	movdqa xmm15,xmm0
    75b0bab03a19:	cmpunordpd xmm15,xmm0
    75b0bab03a1f:	por    xmm14,xmm15
    75b0bab03a24:	pmovmskb ecx,xmm14
    75b0bab03a29:	jrcxz  0x75b0bab03a30
    75b0bab03a2b:	jmp    0x75b0bab051da
    75b0bab03a30:	movdqa xmm8,xmm0
    75b0bab03a35:	movdqu XMMWORD PTR [r12+0x240],xmm8
    75b0bab03a3f:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    75b0bab03a49:	movdqu xmm1,XMMWORD PTR [r12+0x1a0]
    75b0bab03a53:	por    xmm0,xmm1
    75b0bab03a57:	movdqu XMMWORD PTR [r12+0x270],xmm0
    75b0bab03a61:	movdqu xmm6,XMMWORD PTR [r12+0x120]
    75b0bab03a6b:	movdqu xmm1,XMMWORD PTR [r12+0x120]
    75b0bab03a75:	por    xmm6,xmm1
    75b0bab03a79:	movdqu XMMWORD PTR [r12+0x1a0],xmm6
    75b0bab03a83:	movdqa xmm0,xmm5
    75b0bab03a87:	movdqa xmm1,xmm2
    75b0bab03a8b:	pshufd xmm1,xmm1,0x44
    75b0bab03a90:	mulpd  xmm0,xmm1
    75b0bab03a94:	movdqa xmm14,xmm0
    75b0bab03a99:	movdqu xmm15,XMMWORD PTR [rip+0x8bae]        # 0x75b0bab0c650
    75b0bab03aa2:	pand   xmm14,xmm15
    75b0bab03aa7:	movdqu xmm15,XMMWORD PTR [rip+0x8bb0]        # 0x75b0bab0c660
    75b0bab03ab0:	pcmpeqq xmm14,xmm15
    75b0bab03ab6:	movdqa xmm15,xmm0
    75b0bab03abb:	cmpunordpd xmm15,xmm0
    75b0bab03ac1:	por    xmm14,xmm15
    75b0bab03ac6:	pmovmskb ecx,xmm14
    75b0bab03acb:	jrcxz  0x75b0bab03ad2
    75b0bab03acd:	jmp    0x75b0bab051fe
    75b0bab03ad2:	movdqa xmm6,xmm0
    75b0bab03ad6:	movdqu XMMWORD PTR [r12+0x250],xmm6
    75b0bab03ae0:	mov    r13,r14
    75b0bab03ae3:	add    r13,0x20
    75b0bab03ae7:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    75b0bab03aed:	movdqu XMMWORD PTR [r12+0x110],xmm5
    75b0bab03af7:	movdqa xmm0,xmm10
    75b0bab03afc:	movdqa xmm1,xmm12
    75b0bab03b01:	addpd  xmm0,xmm1
    75b0bab03b05:	movdqa xmm14,xmm0
    75b0bab03b0a:	movdqu xmm15,XMMWORD PTR [rip+0x8b3d]        # 0x75b0bab0c650
    75b0bab03b13:	pand   xmm14,xmm15
    75b0bab03b18:	movdqu xmm15,XMMWORD PTR [rip+0x8b3f]        # 0x75b0bab0c660
    75b0bab03b21:	pcmpeqq xmm14,xmm15
    75b0bab03b27:	movdqa xmm15,xmm0
    75b0bab03b2c:	cmpunordpd xmm15,xmm0
    75b0bab03b32:	por    xmm14,xmm15
    75b0bab03b37:	pmovmskb ecx,xmm14
    75b0bab03b3c:	jrcxz  0x75b0bab03b43
    75b0bab03b3e:	jmp    0x75b0bab05222
    75b0bab03b43:	movdqa xmm3,xmm0
    75b0bab03b47:	movdqa xmm0,xmm7
    75b0bab03b4b:	movdqa xmm1,xmm2
    75b0bab03b4f:	pshufd xmm1,xmm1,0x44
    75b0bab03b54:	mulpd  xmm0,xmm1
    75b0bab03b58:	movdqa xmm14,xmm0
    75b0bab03b5d:	movdqu xmm15,XMMWORD PTR [rip+0x8aea]        # 0x75b0bab0c650
    75b0bab03b66:	pand   xmm14,xmm15
    75b0bab03b6b:	movdqu xmm15,XMMWORD PTR [rip+0x8aec]        # 0x75b0bab0c660
    75b0bab03b74:	pcmpeqq xmm14,xmm15
    75b0bab03b7a:	movdqa xmm15,xmm0
    75b0bab03b7f:	cmpunordpd xmm15,xmm0
    75b0bab03b85:	por    xmm14,xmm15
    75b0bab03b8a:	pmovmskb ecx,xmm14
    75b0bab03b8f:	jrcxz  0x75b0bab03b96
    75b0bab03b91:	jmp    0x75b0bab05248
    75b0bab03b96:	movdqa xmm10,xmm0
    75b0bab03b9b:	movdqa xmm0,xmm11
    75b0bab03ba0:	movdqa xmm1,xmm13
    75b0bab03ba5:	addpd  xmm0,xmm1
    75b0bab03ba9:	movdqa xmm14,xmm0
    75b0bab03bae:	movdqu xmm15,XMMWORD PTR [rip+0x8a99]        # 0x75b0bab0c650
    75b0bab03bb7:	pand   xmm14,xmm15
    75b0bab03bbc:	movdqu xmm15,XMMWORD PTR [rip+0x8a9b]        # 0x75b0bab0c660
    75b0bab03bc5:	pcmpeqq xmm14,xmm15
    75b0bab03bcb:	movdqa xmm15,xmm0
    75b0bab03bd0:	cmpunordpd xmm15,xmm0
    75b0bab03bd6:	por    xmm14,xmm15
    75b0bab03bdb:	pmovmskb ecx,xmm14
    75b0bab03be0:	jrcxz  0x75b0bab03be7
    75b0bab03be2:	jmp    0x75b0bab0526c
    75b0bab03be7:	movdqa xmm2,xmm0
    75b0bab03beb:	movdqu xmm7,XMMWORD PTR [r12+0x150]
    75b0bab03bf5:	movdqa xmm0,xmm5
    75b0bab03bf9:	movdqa xmm1,xmm7
    75b0bab03bfd:	pshufd xmm1,xmm1,0x44
    75b0bab03c02:	mulpd  xmm0,xmm1
    75b0bab03c06:	movdqa xmm14,xmm0
    75b0bab03c0b:	movdqu xmm15,XMMWORD PTR [rip+0x8a3c]        # 0x75b0bab0c650
    75b0bab03c14:	pand   xmm14,xmm15
    75b0bab03c19:	movdqu xmm15,XMMWORD PTR [rip+0x8a3e]        # 0x75b0bab0c660
    75b0bab03c22:	pcmpeqq xmm14,xmm15
    75b0bab03c28:	movdqa xmm15,xmm0
    75b0bab03c2d:	cmpunordpd xmm15,xmm0
    75b0bab03c33:	por    xmm14,xmm15
    75b0bab03c38:	pmovmskb ecx,xmm14
    75b0bab03c3d:	jrcxz  0x75b0bab03c44
    75b0bab03c3f:	jmp    0x75b0bab05292
    75b0bab03c44:	movdqa xmm11,xmm0
    75b0bab03c49:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    75b0bab03c53:	movdqa xmm1,xmm7
    75b0bab03c57:	pshufd xmm1,xmm1,0x44
    75b0bab03c5c:	mulpd  xmm0,xmm1
    75b0bab03c60:	movdqa xmm14,xmm0
    75b0bab03c65:	movdqu xmm15,XMMWORD PTR [rip+0x89e2]        # 0x75b0bab0c650
    75b0bab03c6e:	pand   xmm14,xmm15
    75b0bab03c73:	movdqu xmm15,XMMWORD PTR [rip+0x89e4]        # 0x75b0bab0c660
    75b0bab03c7c:	pcmpeqq xmm14,xmm15
    75b0bab03c82:	movdqa xmm15,xmm0
    75b0bab03c87:	cmpunordpd xmm15,xmm0
    75b0bab03c8d:	por    xmm14,xmm15
    75b0bab03c92:	pmovmskb ecx,xmm14
    75b0bab03c97:	jrcxz  0x75b0bab03c9e
    75b0bab03c99:	jmp    0x75b0bab052b6
    75b0bab03c9e:	movdqa xmm5,xmm0
    75b0bab03ca2:	movdqa xmm0,xmm8
    75b0bab03ca7:	movdqa xmm1,xmm4
    75b0bab03cab:	addpd  xmm0,xmm1
    75b0bab03caf:	movdqa xmm14,xmm0
    75b0bab03cb4:	movdqu xmm15,XMMWORD PTR [rip+0x8993]        # 0x75b0bab0c650
    75b0bab03cbd:	pand   xmm14,xmm15
    75b0bab03cc2:	movdqu xmm15,XMMWORD PTR [rip+0x8995]        # 0x75b0bab0c660
    75b0bab03ccb:	pcmpeqq xmm14,xmm15
    75b0bab03cd1:	movdqa xmm15,xmm0
    75b0bab03cd6:	cmpunordpd xmm15,xmm0
    75b0bab03cdc:	por    xmm14,xmm15
    75b0bab03ce1:	pmovmskb ecx,xmm14
    75b0bab03ce6:	jrcxz  0x75b0bab03ced
    75b0bab03ce8:	jmp    0x75b0bab052e0
    75b0bab03ced:	movdqa xmm12,xmm0
    75b0bab03cf2:	movdqu XMMWORD PTR [r12+0x240],xmm12
    75b0bab03cfc:	movdqa xmm0,xmm9
    75b0bab03d01:	movdqa xmm1,xmm6
    75b0bab03d05:	addpd  xmm0,xmm1
    75b0bab03d09:	movdqa xmm14,xmm0
    75b0bab03d0e:	movdqu xmm15,XMMWORD PTR [rip+0x8939]        # 0x75b0bab0c650
    75b0bab03d17:	pand   xmm14,xmm15
    75b0bab03d1c:	movdqu xmm15,XMMWORD PTR [rip+0x893b]        # 0x75b0bab0c660
    75b0bab03d25:	pcmpeqq xmm14,xmm15
    75b0bab03d2b:	movdqa xmm15,xmm0
    75b0bab03d30:	cmpunordpd xmm15,xmm0
    75b0bab03d36:	por    xmm14,xmm15
    75b0bab03d3b:	pmovmskb ecx,xmm14
    75b0bab03d40:	jrcxz  0x75b0bab03d47
    75b0bab03d42:	jmp    0x75b0bab05305
    75b0bab03d47:	movdqa xmm4,xmm0
    75b0bab03d4b:	movdqu XMMWORD PTR [r12+0x220],xmm4
    75b0bab03d55:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    75b0bab03d5f:	movdqa xmm1,xmm7
    75b0bab03d63:	pshufd xmm1,xmm1,0x44
    75b0bab03d68:	mulpd  xmm0,xmm1
    75b0bab03d6c:	movdqa xmm14,xmm0
    75b0bab03d71:	movdqu xmm15,XMMWORD PTR [rip+0x88d6]        # 0x75b0bab0c650
    75b0bab03d7a:	pand   xmm14,xmm15
    75b0bab03d7f:	movdqu xmm15,XMMWORD PTR [rip+0x88d8]        # 0x75b0bab0c660
    75b0bab03d88:	pcmpeqq xmm14,xmm15
    75b0bab03d8e:	movdqa xmm15,xmm0
    75b0bab03d93:	cmpunordpd xmm15,xmm0
    75b0bab03d99:	por    xmm14,xmm15
    75b0bab03d9e:	pmovmskb ecx,xmm14
    75b0bab03da3:	jrcxz  0x75b0bab03daa
    75b0bab03da5:	jmp    0x75b0bab0532a
    75b0bab03daa:	movdqa xmm6,xmm0
    75b0bab03dae:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    75b0bab03db8:	movdqa xmm1,xmm7
    75b0bab03dbc:	pshufd xmm1,xmm1,0x44
    75b0bab03dc1:	mulpd  xmm0,xmm1
    75b0bab03dc5:	movdqa xmm14,xmm0
    75b0bab03dca:	movdqu xmm15,XMMWORD PTR [rip+0x887d]        # 0x75b0bab0c650
    75b0bab03dd3:	pand   xmm14,xmm15
    75b0bab03dd8:	movdqu xmm15,XMMWORD PTR [rip+0x887f]        # 0x75b0bab0c660
    75b0bab03de1:	pcmpeqq xmm14,xmm15
    75b0bab03de7:	movdqa xmm15,xmm0
    75b0bab03dec:	cmpunordpd xmm15,xmm0
    75b0bab03df2:	por    xmm14,xmm15
    75b0bab03df7:	pmovmskb ecx,xmm14
    75b0bab03dfc:	jrcxz  0x75b0bab03e03
    75b0bab03dfe:	jmp    0x75b0bab05354
    75b0bab03e03:	movdqa xmm8,xmm0
    75b0bab03e08:	movdqu XMMWORD PTR [r12+0x150],xmm8
    75b0bab03e12:	movdqa xmm0,xmm3
    75b0bab03e16:	movdqa xmm1,xmm10
    75b0bab03e1b:	addpd  xmm0,xmm1
    75b0bab03e1f:	movdqa xmm14,xmm0
    75b0bab03e24:	movdqu xmm15,XMMWORD PTR [rip+0x8823]        # 0x75b0bab0c650
    75b0bab03e2d:	pand   xmm14,xmm15
    75b0bab03e32:	movdqu xmm15,XMMWORD PTR [rip+0x8825]        # 0x75b0bab0c660
    75b0bab03e3b:	pcmpeqq xmm14,xmm15
    75b0bab03e41:	movdqa xmm15,xmm0
    75b0bab03e46:	cmpunordpd xmm15,xmm0
    75b0bab03e4c:	por    xmm14,xmm15
    75b0bab03e51:	pmovmskb ecx,xmm14
    75b0bab03e56:	jrcxz  0x75b0bab03e5d
    75b0bab03e58:	jmp    0x75b0bab0537e
    75b0bab03e5d:	movdqa xmm7,xmm0
    75b0bab03e61:	movdqu XMMWORD PTR [r12+0x160],xmm7
    75b0bab03e6b:	movdqa xmm0,xmm2
    75b0bab03e6f:	movdqa xmm1,xmm11
    75b0bab03e74:	addpd  xmm0,xmm1
    75b0bab03e78:	movdqa xmm14,xmm0
    75b0bab03e7d:	movdqu xmm15,XMMWORD PTR [rip+0x87ca]        # 0x75b0bab0c650
    75b0bab03e86:	pand   xmm14,xmm15
    75b0bab03e8b:	movdqu xmm15,XMMWORD PTR [rip+0x87cc]        # 0x75b0bab0c660
    75b0bab03e94:	pcmpeqq xmm14,xmm15
    75b0bab03e9a:	movdqa xmm15,xmm0
    75b0bab03e9f:	cmpunordpd xmm15,xmm0
    75b0bab03ea5:	por    xmm14,xmm15
    75b0bab03eaa:	pmovmskb ecx,xmm14
    75b0bab03eaf:	jrcxz  0x75b0bab03eb6
    75b0bab03eb1:	jmp    0x75b0bab053a3
    75b0bab03eb6:	movdqa xmm3,xmm0
    75b0bab03eba:	movdqu XMMWORD PTR [r12+0x170],xmm3
    75b0bab03ec4:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    75b0bab03ece:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    75b0bab03ed8:	movdqa xmm1,xmm2
    75b0bab03edc:	pshufd xmm1,xmm1,0x44
    75b0bab03ee1:	mulpd  xmm0,xmm1
    75b0bab03ee5:	movdqa xmm14,xmm0
    75b0bab03eea:	movdqu xmm15,XMMWORD PTR [rip+0x875d]        # 0x75b0bab0c650
    75b0bab03ef3:	pand   xmm14,xmm15
    75b0bab03ef8:	movdqu xmm15,XMMWORD PTR [rip+0x875f]        # 0x75b0bab0c660
    75b0bab03f01:	pcmpeqq xmm14,xmm15
    75b0bab03f07:	movdqa xmm15,xmm0
    75b0bab03f0c:	cmpunordpd xmm15,xmm0
    75b0bab03f12:	por    xmm14,xmm15
    75b0bab03f17:	pmovmskb ecx,xmm14
    75b0bab03f1c:	jrcxz  0x75b0bab03f23
    75b0bab03f1e:	jmp    0x75b0bab053c8
    75b0bab03f23:	movdqa xmm9,xmm0
    75b0bab03f28:	movdqu XMMWORD PTR [r12+0x180],xmm9
    75b0bab03f32:	movdqa xmm0,xmm4
    75b0bab03f36:	movdqa xmm1,xmm5
    75b0bab03f3a:	addpd  xmm0,xmm1
    75b0bab03f3e:	movdqa xmm14,xmm0
    75b0bab03f43:	movdqu xmm15,XMMWORD PTR [rip+0x8704]        # 0x75b0bab0c650
    75b0bab03f4c:	pand   xmm14,xmm15
    75b0bab03f51:	movdqu xmm15,XMMWORD PTR [rip+0x8706]        # 0x75b0bab0c660
    75b0bab03f5a:	pcmpeqq xmm14,xmm15
    75b0bab03f60:	movdqa xmm15,xmm0
    75b0bab03f65:	cmpunordpd xmm15,xmm0
    75b0bab03f6b:	por    xmm14,xmm15
    75b0bab03f70:	pmovmskb ecx,xmm14
    75b0bab03f75:	jrcxz  0x75b0bab03f7c
    75b0bab03f77:	jmp    0x75b0bab053f2
    75b0bab03f7c:	movdqa xmm10,xmm0
    75b0bab03f81:	movdqu XMMWORD PTR [r12+0x210],xmm10
    75b0bab03f8b:	movdqa xmm0,xmm12
    75b0bab03f90:	movdqa xmm1,xmm6
    75b0bab03f94:	addpd  xmm0,xmm1
    75b0bab03f98:	movdqa xmm14,xmm0
    75b0bab03f9d:	movdqu xmm15,XMMWORD PTR [rip+0x86aa]        # 0x75b0bab0c650
    75b0bab03fa6:	pand   xmm14,xmm15
    75b0bab03fab:	movdqu xmm15,XMMWORD PTR [rip+0x86ac]        # 0x75b0bab0c660
    75b0bab03fb4:	pcmpeqq xmm14,xmm15
    75b0bab03fba:	movdqa xmm15,xmm0
    75b0bab03fbf:	cmpunordpd xmm15,xmm0
    75b0bab03fc5:	por    xmm14,xmm15
    75b0bab03fca:	pmovmskb ecx,xmm14
    75b0bab03fcf:	jrcxz  0x75b0bab03fd6
    75b0bab03fd1:	jmp    0x75b0bab05416
    75b0bab03fd6:	movdqa xmm4,xmm0
    75b0bab03fda:	movdqu XMMWORD PTR [r12+0x230],xmm4
    75b0bab03fe4:	movdqu xmm5,XMMWORD PTR [r12+0x2a0]
    75b0bab03fee:	movdqu xmm1,XMMWORD PTR [r12+0x2a0]
    75b0bab03ff8:	por    xmm5,xmm1
    75b0bab03ffc:	movdqu XMMWORD PTR [r12+0x250],xmm5
    75b0bab04006:	movdqu xmm5,XMMWORD PTR [r12+0x1d0]
    75b0bab04010:	movdqu xmm1,XMMWORD PTR [r12+0x1d0]
    75b0bab0401a:	por    xmm5,xmm1
    75b0bab0401e:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    75b0bab04028:	movdqu xmm6,XMMWORD PTR [r12+0x2c0]
    75b0bab04032:	movdqu xmm1,XMMWORD PTR [r12+0x2c0]
    75b0bab0403c:	por    xmm6,xmm1
    75b0bab04040:	movdqu XMMWORD PTR [r12+0x1d0],xmm6
    75b0bab0404a:	mov    r13,r14
    75b0bab0404d:	add    r13,0x40
    75b0bab04051:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    75b0bab04057:	movdqu XMMWORD PTR [r12+0x2c0],xmm6
    75b0bab04061:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    75b0bab0406b:	movdqa xmm1,xmm2
    75b0bab0406f:	pshufd xmm1,xmm1,0x44
    75b0bab04074:	mulpd  xmm0,xmm1
    75b0bab04078:	movdqa xmm14,xmm0
    75b0bab0407d:	movdqu xmm15,XMMWORD PTR [rip+0x85ca]        # 0x75b0bab0c650
    75b0bab04086:	pand   xmm14,xmm15
    75b0bab0408b:	movdqu xmm15,XMMWORD PTR [rip+0x85cc]        # 0x75b0bab0c660
    75b0bab04094:	pcmpeqq xmm14,xmm15
    75b0bab0409a:	movdqa xmm15,xmm0
    75b0bab0409f:	cmpunordpd xmm15,xmm0
    75b0bab040a5:	por    xmm14,xmm15
    75b0bab040aa:	pmovmskb ecx,xmm14
    75b0bab040af:	jrcxz  0x75b0bab040b6
    75b0bab040b1:	jmp    0x75b0bab0543b
    75b0bab040b6:	movdqa xmm11,xmm0
    75b0bab040bb:	movdqa xmm0,xmm7
    75b0bab040bf:	movdqa xmm1,xmm8
    75b0bab040c4:	addpd  xmm0,xmm1
    75b0bab040c8:	movdqa xmm14,xmm0
    75b0bab040cd:	movdqu xmm15,XMMWORD PTR [rip+0x857a]        # 0x75b0bab0c650
    75b0bab040d6:	pand   xmm14,xmm15
    75b0bab040db:	movdqu xmm15,XMMWORD PTR [rip+0x857c]        # 0x75b0bab0c660
    75b0bab040e4:	pcmpeqq xmm14,xmm15
    75b0bab040ea:	movdqa xmm15,xmm0
    75b0bab040ef:	cmpunordpd xmm15,xmm0
    75b0bab040f5:	por    xmm14,xmm15
    75b0bab040fa:	pmovmskb ecx,xmm14
    75b0bab040ff:	jrcxz  0x75b0bab04106
    75b0bab04101:	jmp    0x75b0bab05465
    75b0bab04106:	movdqa xmm12,xmm0
    75b0bab0410b:	movdqa xmm0,xmm3
    75b0bab0410f:	movdqa xmm1,xmm9
    75b0bab04114:	addpd  xmm0,xmm1
    75b0bab04118:	movdqa xmm14,xmm0
    75b0bab0411d:	movdqu xmm15,XMMWORD PTR [rip+0x852a]        # 0x75b0bab0c650
    75b0bab04126:	pand   xmm14,xmm15
    75b0bab0412b:	movdqu xmm15,XMMWORD PTR [rip+0x852c]        # 0x75b0bab0c660
    75b0bab04134:	pcmpeqq xmm14,xmm15
    75b0bab0413a:	movdqa xmm15,xmm0
    75b0bab0413f:	cmpunordpd xmm15,xmm0
    75b0bab04145:	por    xmm14,xmm15
    75b0bab0414a:	pmovmskb ecx,xmm14
    75b0bab0414f:	jrcxz  0x75b0bab04156
    75b0bab04151:	jmp    0x75b0bab0548a
    75b0bab04156:	movdqa xmm7,xmm0
    75b0bab0415a:	movdqu XMMWORD PTR [r12+0x160],xmm7
    75b0bab04164:	movdqa xmm0,xmm6
    75b0bab04168:	movdqa xmm1,xmm2
    75b0bab0416c:	pshufd xmm1,xmm1,0x44
    75b0bab04171:	mulpd  xmm0,xmm1
    75b0bab04175:	movdqa xmm14,xmm0
    75b0bab0417a:	movdqu xmm15,XMMWORD PTR [rip+0x84cd]        # 0x75b0bab0c650
    75b0bab04183:	pand   xmm14,xmm15
    75b0bab04188:	movdqu xmm15,XMMWORD PTR [rip+0x84cf]        # 0x75b0bab0c660
    75b0bab04191:	pcmpeqq xmm14,xmm15
    75b0bab04197:	movdqa xmm15,xmm0
    75b0bab0419c:	cmpunordpd xmm15,xmm0
    75b0bab041a2:	por    xmm14,xmm15
    75b0bab041a7:	pmovmskb ecx,xmm14
    75b0bab041ac:	jrcxz  0x75b0bab041b3
    75b0bab041ae:	jmp    0x75b0bab054af
    75b0bab041b3:	movdqa xmm3,xmm0
    75b0bab041b7:	movdqu XMMWORD PTR [r12+0x240],xmm3
    75b0bab041c1:	movdqu xmm6,XMMWORD PTR [r12+0x2b0]
    75b0bab041cb:	movdqa xmm0,xmm6
    75b0bab041cf:	movdqa xmm1,xmm2
    75b0bab041d3:	pshufd xmm1,xmm1,0x44
    75b0bab041d8:	mulpd  xmm0,xmm1
    75b0bab041dc:	movdqa xmm14,xmm0
    75b0bab041e1:	movdqu xmm15,XMMWORD PTR [rip+0x8466]        # 0x75b0bab0c650
    75b0bab041ea:	pand   xmm14,xmm15
    75b0bab041ef:	movdqu xmm15,XMMWORD PTR [rip+0x8468]        # 0x75b0bab0c660
    75b0bab041f8:	pcmpeqq xmm14,xmm15
    75b0bab041fe:	movdqa xmm15,xmm0
    75b0bab04203:	cmpunordpd xmm15,xmm0
    75b0bab04209:	por    xmm14,xmm15
    75b0bab0420e:	pmovmskb ecx,xmm14
    75b0bab04213:	jrcxz  0x75b0bab0421a
    75b0bab04215:	jmp    0x75b0bab054d3
    75b0bab0421a:	movdqa xmm8,xmm0
    75b0bab0421f:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    75b0bab04229:	movdqa xmm0,xmm5
    75b0bab0422d:	movdqa xmm1,xmm2
    75b0bab04231:	pshufd xmm1,xmm1,0x44
    75b0bab04236:	mulpd  xmm0,xmm1
    75b0bab0423a:	movdqa xmm14,xmm0
    75b0bab0423f:	movdqu xmm15,XMMWORD PTR [rip+0x8408]        # 0x75b0bab0c650
    75b0bab04248:	pand   xmm14,xmm15
    75b0bab0424d:	movdqu xmm15,XMMWORD PTR [rip+0x840a]        # 0x75b0bab0c660
    75b0bab04256:	pcmpeqq xmm14,xmm15
    75b0bab0425c:	movdqa xmm15,xmm0
    75b0bab04261:	cmpunordpd xmm15,xmm0
    75b0bab04267:	por    xmm14,xmm15
    75b0bab0426c:	pmovmskb ecx,xmm14
    75b0bab04271:	jrcxz  0x75b0bab04278
    75b0bab04273:	jmp    0x75b0bab054f7
    75b0bab04278:	movdqa xmm6,xmm0
    75b0bab0427c:	movdqu XMMWORD PTR [r12+0x170],xmm6
    75b0bab04286:	movdqa xmm0,xmm10
    75b0bab0428b:	movdqa xmm1,xmm11
    75b0bab04290:	addpd  xmm0,xmm1
    75b0bab04294:	movdqa xmm14,xmm0
    75b0bab04299:	movdqu xmm15,XMMWORD PTR [rip+0x83ae]        # 0x75b0bab0c650
    75b0bab042a2:	pand   xmm14,xmm15
    75b0bab042a7:	movdqu xmm15,XMMWORD PTR [rip+0x83b0]        # 0x75b0bab0c660
    75b0bab042b0:	pcmpeqq xmm14,xmm15
    75b0bab042b6:	movdqa xmm15,xmm0
    75b0bab042bb:	cmpunordpd xmm15,xmm0
    75b0bab042c1:	por    xmm14,xmm15
    75b0bab042c6:	pmovmskb ecx,xmm14
    75b0bab042cb:	jrcxz  0x75b0bab042d2
    75b0bab042cd:	jmp    0x75b0bab0551b
    75b0bab042d2:	movdqa xmm5,xmm0
    75b0bab042d6:	movdqu XMMWORD PTR [r12+0x180],xmm5
    75b0bab042e0:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    75b0bab042ea:	movdqa xmm1,xmm2
    75b0bab042ee:	pshufd xmm1,xmm1,0x44
    75b0bab042f3:	mulpd  xmm0,xmm1
    75b0bab042f7:	movdqa xmm14,xmm0
    75b0bab042fc:	movdqu xmm15,XMMWORD PTR [rip+0x834b]        # 0x75b0bab0c650
    75b0bab04305:	pand   xmm14,xmm15
    75b0bab0430a:	movdqu xmm15,XMMWORD PTR [rip+0x834d]        # 0x75b0bab0c660
    75b0bab04313:	pcmpeqq xmm14,xmm15
    75b0bab04319:	movdqa xmm15,xmm0
    75b0bab0431e:	cmpunordpd xmm15,xmm0
    75b0bab04324:	por    xmm14,xmm15
    75b0bab04329:	pmovmskb ecx,xmm14
    75b0bab0432e:	jrcxz  0x75b0bab04335
    75b0bab04330:	jmp    0x75b0bab05541
    75b0bab04335:	movdqa xmm9,xmm0
    75b0bab0433a:	movdqu XMMWORD PTR [r12+0x210],xmm9
    75b0bab04344:	movdqa xmm0,xmm4
    75b0bab04348:	movdqa xmm1,xmm3
    75b0bab0434c:	addpd  xmm0,xmm1
    75b0bab04350:	movdqa xmm14,xmm0
    75b0bab04355:	movdqu xmm15,XMMWORD PTR [rip+0x82f2]        # 0x75b0bab0c650
    75b0bab0435e:	pand   xmm14,xmm15
    75b0bab04363:	movdqu xmm15,XMMWORD PTR [rip+0x82f4]        # 0x75b0bab0c660
    75b0bab0436c:	pcmpeqq xmm14,xmm15
    75b0bab04372:	movdqa xmm15,xmm0
    75b0bab04377:	cmpunordpd xmm15,xmm0
    75b0bab0437d:	por    xmm14,xmm15
    75b0bab04382:	pmovmskb ecx,xmm14
    75b0bab04387:	jrcxz  0x75b0bab0438e
    75b0bab04389:	jmp    0x75b0bab0556b
    75b0bab0438e:	movdqa xmm10,xmm0
    75b0bab04393:	movdqu XMMWORD PTR [r12+0x220],xmm10
    75b0bab0439d:	movdqu xmm3,XMMWORD PTR [r12+0x290]
    75b0bab043a7:	movdqa xmm0,xmm3
    75b0bab043ab:	movdqa xmm1,xmm2
    75b0bab043af:	pshufd xmm1,xmm1,0x44
    75b0bab043b4:	mulpd  xmm0,xmm1
    75b0bab043b8:	movdqa xmm14,xmm0
    75b0bab043bd:	movdqu xmm15,XMMWORD PTR [rip+0x828a]        # 0x75b0bab0c650
    75b0bab043c6:	pand   xmm14,xmm15
    75b0bab043cb:	movdqu xmm15,XMMWORD PTR [rip+0x828c]        # 0x75b0bab0c660
    75b0bab043d4:	pcmpeqq xmm14,xmm15
    75b0bab043da:	movdqa xmm15,xmm0
    75b0bab043df:	cmpunordpd xmm15,xmm0
    75b0bab043e5:	por    xmm14,xmm15
    75b0bab043ea:	pmovmskb ecx,xmm14
    75b0bab043ef:	jrcxz  0x75b0bab043f6
    75b0bab043f1:	jmp    0x75b0bab0558f
    75b0bab043f6:	movdqa xmm4,xmm0
    75b0bab043fa:	movdqu XMMWORD PTR [r12+0x230],xmm4
    75b0bab04404:	movdqa xmm0,xmm12
    75b0bab04409:	movdqa xmm1,xmm8
    75b0bab0440e:	addpd  xmm0,xmm1
    75b0bab04412:	movdqa xmm14,xmm0
    75b0bab04417:	movdqu xmm15,XMMWORD PTR [rip+0x8230]        # 0x75b0bab0c650
    75b0bab04420:	pand   xmm14,xmm15
    75b0bab04425:	movdqu xmm15,XMMWORD PTR [rip+0x8232]        # 0x75b0bab0c660
    75b0bab0442e:	pcmpeqq xmm14,xmm15
    75b0bab04434:	movdqa xmm15,xmm0
    75b0bab04439:	cmpunordpd xmm15,xmm0
    75b0bab0443f:	por    xmm14,xmm15
    75b0bab04444:	pmovmskb ecx,xmm14
    75b0bab04449:	jrcxz  0x75b0bab04450
    75b0bab0444b:	jmp    0x75b0bab055b3
    75b0bab04450:	movdqa xmm3,xmm0
    75b0bab04454:	movdqu XMMWORD PTR [r12+0x140],xmm3
    75b0bab0445e:	movdqu xmm8,XMMWORD PTR [r12+0x1e0]
    75b0bab04468:	movdqa xmm0,xmm8
    75b0bab0446d:	movdqa xmm1,xmm2
    75b0bab04471:	pshufd xmm1,xmm1,0x44
    75b0bab04476:	mulpd  xmm0,xmm1
    75b0bab0447a:	movdqa xmm14,xmm0
    75b0bab0447f:	movdqu xmm15,XMMWORD PTR [rip+0x81c8]        # 0x75b0bab0c650
    75b0bab04488:	pand   xmm14,xmm15
    75b0bab0448d:	movdqu xmm15,XMMWORD PTR [rip+0x81ca]        # 0x75b0bab0c660
    75b0bab04496:	pcmpeqq xmm14,xmm15
    75b0bab0449c:	movdqa xmm15,xmm0
    75b0bab044a1:	cmpunordpd xmm15,xmm0
    75b0bab044a7:	por    xmm14,xmm15
    75b0bab044ac:	pmovmskb ecx,xmm14
    75b0bab044b1:	jrcxz  0x75b0bab044b8
    75b0bab044b3:	jmp    0x75b0bab055d9
    75b0bab044b8:	movdqa xmm11,xmm0
    75b0bab044bd:	movdqu XMMWORD PTR [r12+0x130],xmm11
    75b0bab044c7:	movdqa xmm0,xmm7
    75b0bab044cb:	movdqa xmm1,xmm6
    75b0bab044cf:	addpd  xmm0,xmm1
    75b0bab044d3:	movdqa xmm14,xmm0
    75b0bab044d8:	movdqu xmm15,XMMWORD PTR [rip+0x816f]        # 0x75b0bab0c650
    75b0bab044e1:	pand   xmm14,xmm15
    75b0bab044e6:	movdqu xmm15,XMMWORD PTR [rip+0x8171]        # 0x75b0bab0c660
    75b0bab044ef:	pcmpeqq xmm14,xmm15
    75b0bab044f5:	movdqa xmm15,xmm0
    75b0bab044fa:	cmpunordpd xmm15,xmm0
    75b0bab04500:	por    xmm14,xmm15
    75b0bab04505:	pmovmskb ecx,xmm14
    75b0bab0450a:	jrcxz  0x75b0bab04511
    75b0bab0450c:	jmp    0x75b0bab055fe
    75b0bab04511:	movdqa xmm2,xmm0
    75b0bab04515:	movdqu XMMWORD PTR [r12+0x150],xmm2
    75b0bab0451f:	mov    r13,r14
    75b0bab04522:	add    r13,0x70
    75b0bab04526:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    75b0bab0452c:	movdqu XMMWORD PTR [r12+0x240],xmm6
    75b0bab04536:	movdqa xmm0,xmm5
    75b0bab0453a:	movdqa xmm1,xmm9
    75b0bab0453f:	addpd  xmm0,xmm1
    75b0bab04543:	movdqa xmm14,xmm0
    75b0bab04548:	movdqu xmm15,XMMWORD PTR [rip+0x80ff]        # 0x75b0bab0c650
    75b0bab04551:	pand   xmm14,xmm15
    75b0bab04556:	movdqu xmm15,XMMWORD PTR [rip+0x8101]        # 0x75b0bab0c660
    75b0bab0455f:	pcmpeqq xmm14,xmm15
    75b0bab04565:	movdqa xmm15,xmm0
    75b0bab0456a:	cmpunordpd xmm15,xmm0
    75b0bab04570:	por    xmm14,xmm15
    75b0bab04575:	pmovmskb ecx,xmm14
    75b0bab0457a:	jrcxz  0x75b0bab04581
    75b0bab0457c:	jmp    0x75b0bab05622
    75b0bab04581:	movdqa xmm7,xmm0
    75b0bab04585:	movdqu XMMWORD PTR [r12+0x170],xmm7
    75b0bab0458f:	movdqu xmm5,XMMWORD PTR [r12+0x280]
    75b0bab04599:	movdqa xmm0,xmm6
    75b0bab0459d:	movdqa xmm1,xmm5
    75b0bab045a1:	pshufd xmm1,xmm1,0x44
    75b0bab045a6:	mulpd  xmm0,xmm1
    75b0bab045aa:	movdqa xmm14,xmm0
    75b0bab045af:	movdqu xmm15,XMMWORD PTR [rip+0x8098]        # 0x75b0bab0c650
    75b0bab045b8:	pand   xmm14,xmm15
    75b0bab045bd:	movdqu xmm15,XMMWORD PTR [rip+0x809a]        # 0x75b0bab0c660
    75b0bab045c6:	pcmpeqq xmm14,xmm15
    75b0bab045cc:	movdqa xmm15,xmm0
    75b0bab045d1:	cmpunordpd xmm15,xmm0
    75b0bab045d7:	por    xmm14,xmm15
    75b0bab045dc:	pmovmskb ecx,xmm14
    75b0bab045e1:	jrcxz  0x75b0bab045e8
    75b0bab045e3:	jmp    0x75b0bab05647
    75b0bab045e8:	movdqa xmm8,xmm0
    75b0bab045ed:	movdqu XMMWORD PTR [r12+0x160],xmm8
    75b0bab045f7:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    75b0bab04601:	movdqa xmm1,xmm5
    75b0bab04605:	pshufd xmm1,xmm1,0x44
    75b0bab0460a:	mulpd  xmm0,xmm1
    75b0bab0460e:	movdqa xmm14,xmm0
    75b0bab04613:	movdqu xmm15,XMMWORD PTR [rip+0x8034]        # 0x75b0bab0c650
    75b0bab0461c:	pand   xmm14,xmm15
    75b0bab04621:	movdqu xmm15,XMMWORD PTR [rip+0x8036]        # 0x75b0bab0c660
    75b0bab0462a:	pcmpeqq xmm14,xmm15
    75b0bab04630:	movdqa xmm15,xmm0
    75b0bab04635:	cmpunordpd xmm15,xmm0
    75b0bab0463b:	por    xmm14,xmm15
    75b0bab04640:	pmovmskb ecx,xmm14
    75b0bab04645:	jrcxz  0x75b0bab0464c
    75b0bab04647:	jmp    0x75b0bab0566b
    75b0bab0464c:	movdqa xmm6,xmm0
    75b0bab04650:	movdqu XMMWORD PTR [r12+0x180],xmm6
    75b0bab0465a:	movdqa xmm0,xmm10
    75b0bab0465f:	movdqa xmm1,xmm4
    75b0bab04663:	addpd  xmm0,xmm1
    75b0bab04667:	movdqa xmm14,xmm0
    75b0bab0466c:	movdqu xmm15,XMMWORD PTR [rip+0x7fdb]        # 0x75b0bab0c650
    75b0bab04675:	pand   xmm14,xmm15
    75b0bab0467a:	movdqu xmm15,XMMWORD PTR [rip+0x7fdd]        # 0x75b0bab0c660
    75b0bab04683:	pcmpeqq xmm14,xmm15
    75b0bab04689:	movdqa xmm15,xmm0
    75b0bab0468e:	cmpunordpd xmm15,xmm0
    75b0bab04694:	por    xmm14,xmm15
    75b0bab04699:	pmovmskb ecx,xmm14
    75b0bab0469e:	jrcxz  0x75b0bab046a5
    75b0bab046a0:	jmp    0x75b0bab05695
    75b0bab046a5:	movdqa xmm9,xmm0
    75b0bab046aa:	movdqu XMMWORD PTR [r12+0x210],xmm9
    75b0bab046b4:	mov    r13,r14
    75b0bab046b7:	add    r13,0x10
    75b0bab046bb:	movdqu xmm4,XMMWORD PTR [r14]
    75b0bab046c0:	movdqu xmm10,XMMWORD PTR [r13+0x0]
    75b0bab046c6:	movdqu XMMWORD PTR [r12+0x230],xmm10
    75b0bab046d0:	movdqa xmm0,xmm3
    75b0bab046d4:	movdqa xmm1,xmm11
    75b0bab046d9:	addpd  xmm0,xmm1
    75b0bab046dd:	movdqa xmm14,xmm0
    75b0bab046e2:	movdqu xmm15,XMMWORD PTR [rip+0x7f65]        # 0x75b0bab0c650
    75b0bab046eb:	pand   xmm14,xmm15
    75b0bab046f0:	movdqu xmm15,XMMWORD PTR [rip+0x7f67]        # 0x75b0bab0c660
    75b0bab046f9:	pcmpeqq xmm14,xmm15
    75b0bab046ff:	movdqa xmm15,xmm0
    75b0bab04704:	cmpunordpd xmm15,xmm0
    75b0bab0470a:	por    xmm14,xmm15
    75b0bab0470f:	pmovmskb ecx,xmm14
    75b0bab04714:	jrcxz  0x75b0bab0471b
    75b0bab04716:	jmp    0x75b0bab056ba
    75b0bab0471b:	movdqa xmm12,xmm0
    75b0bab04720:	movdqu XMMWORD PTR [r12+0x130],xmm12
    75b0bab0472a:	movdqa xmm0,xmm10
    75b0bab0472f:	movdqa xmm1,xmm5
    75b0bab04733:	pshufd xmm1,xmm1,0x44
    75b0bab04738:	mulpd  xmm0,xmm1
    75b0bab0473c:	movdqa xmm14,xmm0
    75b0bab04741:	movdqu xmm15,XMMWORD PTR [rip+0x7f06]        # 0x75b0bab0c650
    75b0bab0474a:	pand   xmm14,xmm15
    75b0bab0474f:	movdqu xmm15,XMMWORD PTR [rip+0x7f08]        # 0x75b0bab0c660
    75b0bab04758:	pcmpeqq xmm14,xmm15
    75b0bab0475e:	movdqa xmm15,xmm0
    75b0bab04763:	cmpunordpd xmm15,xmm0
    75b0bab04769:	por    xmm14,xmm15
    75b0bab0476e:	pmovmskb ecx,xmm14
    75b0bab04773:	jrcxz  0x75b0bab0477a
    75b0bab04775:	jmp    0x75b0bab056df
    75b0bab0477a:	movdqa xmm3,xmm0
    75b0bab0477e:	movdqu XMMWORD PTR [r12+0x220],xmm3
    75b0bab04788:	movdqa xmm0,xmm4
    75b0bab0478c:	movdqa xmm1,xmm5
    75b0bab04790:	pshufd xmm1,xmm1,0x44
    75b0bab04795:	mulpd  xmm0,xmm1
    75b0bab04799:	movdqa xmm14,xmm0
    75b0bab0479e:	movdqu xmm15,XMMWORD PTR [rip+0x7ea9]        # 0x75b0bab0c650
    75b0bab047a7:	pand   xmm14,xmm15
    75b0bab047ac:	movdqu xmm15,XMMWORD PTR [rip+0x7eab]        # 0x75b0bab0c660
    75b0bab047b5:	pcmpeqq xmm14,xmm15
    75b0bab047bb:	movdqa xmm15,xmm0
    75b0bab047c0:	cmpunordpd xmm15,xmm0
    75b0bab047c6:	por    xmm14,xmm15
    75b0bab047cb:	pmovmskb ecx,xmm14
    75b0bab047d0:	jrcxz  0x75b0bab047d7
    75b0bab047d2:	jmp    0x75b0bab05704
    75b0bab047d7:	movdqa xmm10,xmm0
    75b0bab047dc:	movdqa xmm0,xmm2
    75b0bab047e0:	movdqa xmm1,xmm8
    75b0bab047e5:	addpd  xmm0,xmm1
    75b0bab047e9:	movdqa xmm14,xmm0
    75b0bab047ee:	movdqu xmm15,XMMWORD PTR [rip+0x7e59]        # 0x75b0bab0c650
    75b0bab047f7:	pand   xmm14,xmm15
    75b0bab047fc:	movdqu xmm15,XMMWORD PTR [rip+0x7e5b]        # 0x75b0bab0c660
    75b0bab04805:	pcmpeqq xmm14,xmm15
    75b0bab0480b:	movdqa xmm15,xmm0
    75b0bab04810:	cmpunordpd xmm15,xmm0
    75b0bab04816:	por    xmm14,xmm15
    75b0bab0481b:	pmovmskb ecx,xmm14
    75b0bab04820:	jrcxz  0x75b0bab04827
    75b0bab04822:	jmp    0x75b0bab05728
    75b0bab04827:	movdqa xmm4,xmm0
    75b0bab0482b:	movdqu XMMWORD PTR [r12+0x140],xmm4
    75b0bab04835:	movdqa xmm0,xmm7
    75b0bab04839:	movdqa xmm1,xmm6
    75b0bab0483d:	addpd  xmm0,xmm1
    75b0bab04841:	movdqa xmm14,xmm0
    75b0bab04846:	movdqu xmm15,XMMWORD PTR [rip+0x7e01]        # 0x75b0bab0c650
    75b0bab0484f:	pand   xmm14,xmm15
    75b0bab04854:	movdqu xmm15,XMMWORD PTR [rip+0x7e03]        # 0x75b0bab0c660
    75b0bab0485d:	pcmpeqq xmm14,xmm15
    75b0bab04863:	movdqa xmm15,xmm0
    75b0bab04868:	cmpunordpd xmm15,xmm0
    75b0bab0486e:	por    xmm14,xmm15
    75b0bab04873:	pmovmskb ecx,xmm14
    75b0bab04878:	jrcxz  0x75b0bab0487f
    75b0bab0487a:	jmp    0x75b0bab0574d
    75b0bab0487f:	movdqa xmm2,xmm0
    75b0bab04883:	movdqu XMMWORD PTR [r12+0x150],xmm2
    75b0bab0488d:	movdqa xmm0,xmm9
    75b0bab04892:	movdqa xmm1,xmm3
    75b0bab04896:	addpd  xmm0,xmm1
    75b0bab0489a:	movdqa xmm14,xmm0
    75b0bab0489f:	movdqu xmm15,XMMWORD PTR [rip+0x7da8]        # 0x75b0bab0c650
    75b0bab048a8:	pand   xmm14,xmm15
    75b0bab048ad:	movdqu xmm15,XMMWORD PTR [rip+0x7daa]        # 0x75b0bab0c660
    75b0bab048b6:	pcmpeqq xmm14,xmm15
    75b0bab048bc:	movdqa xmm15,xmm0
    75b0bab048c1:	cmpunordpd xmm15,xmm0
    75b0bab048c7:	por    xmm14,xmm15
    75b0bab048cc:	pmovmskb ecx,xmm14
    75b0bab048d1:	jrcxz  0x75b0bab048d8
    75b0bab048d3:	jmp    0x75b0bab05771
    75b0bab048d8:	movdqa xmm5,xmm0
    75b0bab048dc:	movdqu XMMWORD PTR [r12+0x160],xmm5
    75b0bab048e6:	movdqa xmm0,xmm12
    75b0bab048eb:	movdqa xmm1,xmm10
    75b0bab048f0:	addpd  xmm0,xmm1
    75b0bab048f4:	movdqa xmm14,xmm0
    75b0bab048f9:	movdqu xmm15,XMMWORD PTR [rip+0x7d4e]        # 0x75b0bab0c650
    75b0bab04902:	pand   xmm14,xmm15
    75b0bab04907:	movdqu xmm15,XMMWORD PTR [rip+0x7d50]        # 0x75b0bab0c660
    75b0bab04910:	pcmpeqq xmm14,xmm15
    75b0bab04916:	movdqa xmm15,xmm0
    75b0bab0491b:	cmpunordpd xmm15,xmm0
    75b0bab04921:	por    xmm14,xmm15
    75b0bab04926:	pmovmskb ecx,xmm14
    75b0bab0492b:	jrcxz  0x75b0bab04932
    75b0bab0492d:	jmp    0x75b0bab05796
    75b0bab04932:	movdqa xmm3,xmm0
    75b0bab04936:	movdqu XMMWORD PTR [r12+0x120],xmm3
    75b0bab04940:	mov    r13,r15
    75b0bab04943:	add    r13,0x10
    75b0bab04947:	movdqu XMMWORD PTR [r15],xmm4
    75b0bab0494c:	mov    r14d,0x0
    75b0bab04952:	mov    DWORD PTR [r12+0x32c],r14d
    75b0bab0495a:	movdqu XMMWORD PTR [r13+0x0],xmm2
    75b0bab04960:	add    r15,0x20
    75b0bab04964:	mov    r13,r15
    75b0bab04967:	add    r13,0x10
    75b0bab0496b:	movdqu XMMWORD PTR [r15],xmm5
    75b0bab04970:	movdqu XMMWORD PTR [r13+0x0],xmm3
    75b0bab04976:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab0497e:	jrcxz  0x75b0bab04985
    75b0bab04980:	jmp    0x75b0bab0bd1d
    75b0bab04985:	cmp    BYTE PTR [rsp+0x8],0x0
    75b0bab0498a:	jne    0x75b0bab02c55
    75b0bab04990:	jmp    0x75b0bab04995
    75b0bab04995:	mov    r13d,DWORD PTR [r12+0x48]
    75b0bab0499a:	add    r13d,0x1
    75b0bab0499e:	mov    QWORD PTR [r12+0x48],r13
    75b0bab049a3:	sub    r13d,0x1f4
    75b0bab049aa:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab049b2:	jrcxz  0x75b0bab049b9
    75b0bab049b4:	jmp    0x75b0bab0bda2
    75b0bab049b9:	jne    0x75b0bab02c37
    75b0bab049bf:	mov    r11,rax
    75b0bab049c2:	lahf
    75b0bab049c3:	seto   al
    75b0bab049c6:	mov    WORD PTR [rsp],ax
    75b0bab049ca:	mov    rax,r11
    75b0bab049cd:	jmp    0x75b0bab049d2
    75b0bab049d2:	mov    r13d,0x430000
    75b0bab049d8:	mov    QWORD PTR [r12+0x40],r13
    75b0bab049dd:	mov    r13d,0x0
    75b0bab049e3:	mov    QWORD PTR [r12+0x48],r13
    75b0bab049e8:	mov    r13d,0x430cc0
    75b0bab049ee:	mov    r14,QWORD PTR [r13+0x0]
    75b0bab049f2:	mov    r13d,0x0
    75b0bab049f8:	mov    QWORD PTR [r12+0x110],r14
    75b0bab04a00:	mov    QWORD PTR [r12+0x118],r13
    75b0bab04a08:	jmp    0x75b0bab04a0d
    75b0bab04a0d:	mov    r13,QWORD PTR [r12+0x48]
    75b0bab04a12:	mov    r14,QWORD PTR [r12+0x50]
    75b0bab04a17:	add    r14,r13
    75b0bab04a1a:	movdqu xmm2,XMMWORD PTR [r14]
    75b0bab04a1f:	movdqu XMMWORD PTR [r12+0x120],xmm2
    75b0bab04a29:	add    r13,0x10
    75b0bab04a2d:	mov    QWORD PTR [r12+0x48],r13
    75b0bab04a32:	sub    r13,0x200
    75b0bab04a39:	mov    r13,QWORD PTR [r12+0x128]
    75b0bab04a41:	mov    r14d,0x0
    75b0bab04a47:	mov    QWORD PTR [r12+0x130],r13
    75b0bab04a4f:	mov    QWORD PTR [r12+0x138],r14
    75b0bab04a57:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    75b0bab04a61:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    75b0bab04a6b:	movdqa xmm0,xmm2
    75b0bab04a6f:	movdqa xmm1,xmm3
    75b0bab04a73:	movq   xmm0,xmm0
    75b0bab04a77:	movq   xmm1,xmm1
    75b0bab04a7b:	addsd  xmm0,xmm1
    75b0bab04a7f:	movdqa xmm14,xmm0
    75b0bab04a84:	movdqu xmm15,XMMWORD PTR [rip+0x7bc3]        # 0x75b0bab0c650
    75b0bab04a8d:	pand   xmm14,xmm15
    75b0bab04a92:	movdqu xmm15,XMMWORD PTR [rip+0x7bc5]        # 0x75b0bab0c660
    75b0bab04a9b:	pcmpeqq xmm14,xmm15
    75b0bab04aa1:	movdqa xmm15,xmm0
    75b0bab04aa6:	cmpunordpd xmm15,xmm0
    75b0bab04aac:	por    xmm14,xmm15
    75b0bab04ab1:	pmovmskb ecx,xmm14
    75b0bab04ab6:	jrcxz  0x75b0bab04abd
    75b0bab04ab8:	jmp    0x75b0bab057bc
    75b0bab04abd:	movdqa xmm4,xmm0
    75b0bab04ac1:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    75b0bab04acb:	movdqa xmm0,xmm4
    75b0bab04acf:	movdqa xmm1,xmm2
    75b0bab04ad3:	movq   xmm0,xmm0
    75b0bab04ad7:	movq   xmm1,xmm1
    75b0bab04adb:	addsd  xmm0,xmm1
    75b0bab04adf:	movdqa xmm14,xmm0
    75b0bab04ae4:	movdqu xmm15,XMMWORD PTR [rip+0x7b63]        # 0x75b0bab0c650
    75b0bab04aed:	pand   xmm14,xmm15
    75b0bab04af2:	movdqu xmm15,XMMWORD PTR [rip+0x7b65]        # 0x75b0bab0c660
    75b0bab04afb:	pcmpeqq xmm14,xmm15
    75b0bab04b01:	movdqa xmm15,xmm0
    75b0bab04b06:	cmpunordpd xmm15,xmm0
    75b0bab04b0c:	por    xmm14,xmm15
    75b0bab04b11:	pmovmskb ecx,xmm14
    75b0bab04b16:	jrcxz  0x75b0bab04b1d
    75b0bab04b18:	jmp    0x75b0bab057fb
    75b0bab04b1d:	movdqa xmm3,xmm0
    75b0bab04b21:	movdqu XMMWORD PTR [r12+0x110],xmm3
    75b0bab04b2b:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab04b33:	jrcxz  0x75b0bab04b3a
    75b0bab04b35:	jmp    0x75b0bab0be36
    75b0bab04b3a:	jne    0x75b0bab04b53
    75b0bab04b40:	mov    r11,rax
    75b0bab04b43:	lahf
    75b0bab04b44:	seto   al
    75b0bab04b47:	mov    WORD PTR [rsp],ax
    75b0bab04b4b:	mov    rax,r11
    75b0bab04b4e:	jmp    0x75b0bab04b66
    75b0bab04b53:	mov    r11,rax
    75b0bab04b56:	lahf
    75b0bab04b57:	seto   al
    75b0bab04b5a:	mov    WORD PTR [rsp],ax
    75b0bab04b5e:	mov    rax,r11
    75b0bab04b61:	jmp    0x75b0bab04a0d
    75b0bab04b66:	mov    r13,QWORD PTR [r12+0xf8]
    75b0bab04b6e:	mov    r14,r13
    75b0bab04b71:	add    r14,0x1d0
    75b0bab04b78:	mov    r15,r14
    75b0bab04b7b:	add    r15,0x8
    75b0bab04b7f:	mov    rbp,QWORD PTR [r14]
    75b0bab04b82:	mov    r14,QWORD PTR [r15]
    75b0bab04b85:	mov    QWORD PTR [r12+0xa0],rbp
    75b0bab04b8d:	mov    QWORD PTR [r12+0x98],r14
    75b0bab04b95:	mov    r14,QWORD PTR [r12+0x40]
    75b0bab04b9a:	add    r14,0xcc0
    75b0bab04ba1:	mov    r15,QWORD PTR [r12+0x110]
    75b0bab04ba9:	mov    QWORD PTR [r14],r15
    75b0bab04bac:	mov    r14d,0x0
    75b0bab04bb2:	mov    DWORD PTR [r12+0x32c],r14d
    75b0bab04bba:	mov    r14,r13
    75b0bab04bbd:	add    r14,0x1c0
    75b0bab04bc4:	mov    r15,r14
    75b0bab04bc7:	add    r15,0x8
    75b0bab04bcb:	mov    rbp,QWORD PTR [r14]
    75b0bab04bce:	mov    r14,QWORD PTR [r15]
    75b0bab04bd1:	mov    QWORD PTR [r12+0xe8],rbp
    75b0bab04bd9:	mov    QWORD PTR [r12+0xf0],r14
    75b0bab04be1:	mov    r14,r13
    75b0bab04be4:	add    r14,0x1b0
    75b0bab04beb:	mov    r15,r14
    75b0bab04bee:	add    r15,0x8
    75b0bab04bf2:	mov    rbp,QWORD PTR [r14]
    75b0bab04bf5:	mov    r14,QWORD PTR [r15]
    75b0bab04bf8:	mov    r15d,0x0
    75b0bab04bfe:	mov    QWORD PTR [r12+0x1a0],rbp
    75b0bab04c06:	mov    QWORD PTR [r12+0x1a8],r15
    75b0bab04c0e:	mov    r15d,0x0
    75b0bab04c14:	mov    QWORD PTR [r12+0x190],r14
    75b0bab04c1c:	mov    QWORD PTR [r12+0x198],r15
    75b0bab04c24:	mov    r14,r13
    75b0bab04c27:	add    r14,0x1a0
    75b0bab04c2e:	mov    r15,r14
    75b0bab04c31:	add    r15,0x8
    75b0bab04c35:	mov    rbp,QWORD PTR [r14]
    75b0bab04c38:	mov    r14,QWORD PTR [r15]
    75b0bab04c3b:	mov    r15d,0x0
    75b0bab04c41:	mov    QWORD PTR [r12+0x1c0],rbp
    75b0bab04c49:	mov    QWORD PTR [r12+0x1c8],r15
    75b0bab04c51:	mov    r15d,0x0
    75b0bab04c57:	mov    QWORD PTR [r12+0x1b0],r14
    75b0bab04c5f:	mov    QWORD PTR [r12+0x1b8],r15
    75b0bab04c67:	mov    r14,r13
    75b0bab04c6a:	add    r14,0x190
    75b0bab04c71:	mov    r15,r14
    75b0bab04c74:	add    r15,0x8
    75b0bab04c78:	mov    rbp,QWORD PTR [r14]
    75b0bab04c7b:	mov    r14,QWORD PTR [r15]
    75b0bab04c7e:	mov    r15d,0x0
    75b0bab04c84:	mov    QWORD PTR [r12+0x1e0],rbp
    75b0bab04c8c:	mov    QWORD PTR [r12+0x1e8],r15
    75b0bab04c94:	mov    r15d,0x0
    75b0bab04c9a:	mov    QWORD PTR [r12+0x1d0],r14
    75b0bab04ca2:	mov    QWORD PTR [r12+0x1d8],r15
    75b0bab04caa:	mov    r14,r13
    75b0bab04cad:	add    r14,0x180
    75b0bab04cb4:	mov    r15,r14
    75b0bab04cb7:	add    r15,0x8
    75b0bab04cbb:	mov    rbp,QWORD PTR [r14]
    75b0bab04cbe:	mov    r14,QWORD PTR [r15]
    75b0bab04cc1:	mov    r15d,0x0
    75b0bab04cc7:	mov    QWORD PTR [r12+0x200],rbp
    75b0bab04ccf:	mov    QWORD PTR [r12+0x208],r15
    75b0bab04cd7:	mov    r15d,0x0
    75b0bab04cdd:	mov    QWORD PTR [r12+0x1f0],r14
    75b0bab04ce5:	mov    QWORD PTR [r12+0x1f8],r15
    75b0bab04ced:	add    r13,0x1e0
    75b0bab04cf4:	mov    QWORD PTR [r12+0xf8],r13
    75b0bab04cfc:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab04d04:	jrcxz  0x75b0bab04d0b
    75b0bab04d06:	jmp    0x75b0bab0beca
    75b0bab04d0b:	mov    r13,QWORD PTR [r12+0xf0]
    75b0bab04d13:	mov    QWORD PTR [r12+0x100],r13
    75b0bab04d1b:	mov    r11,QWORD PTR [rsp]
    75b0bab04d1f:	mov    QWORD PTR [r12+0x398],r11
    75b0bab04d27:	mov    rdi,QWORD PTR [r12+0x100]
    75b0bab04d2f:	add    rsp,0x150
    75b0bab04d36:	movabs r11,0x59d8f50c0940
    75b0bab04d40:	jmp    r11
    75b0bab04d43:	mov    r13d,DWORD PTR [r12+0x98]
    75b0bab04d4b:	mov    r14d,DWORD PTR [r12]
    75b0bab04d4f:	add    r14d,r13d
    75b0bab04d52:	mov    QWORD PTR [r12],r14
    75b0bab04d56:	mov    r13d,0x4103f8
    75b0bab04d5c:	mov    QWORD PTR [r12+0xf0],r13
    75b0bab04d64:	mov    r13d,0x4109a4
    75b0bab04d6a:	mov    QWORD PTR [r12+0x100],r13
    75b0bab04d72:	mov    r11,QWORD PTR [rsp]
    75b0bab04d76:	mov    QWORD PTR [r12+0x398],r11
    75b0bab04d7e:	mov    edi,0x4109a4
    75b0bab04d83:	mov    QWORD PTR [r12+0x100],rdi
    75b0bab04d8b:	add    rsp,0x150
    75b0bab04d92:	nop    WORD PTR [rax+rax*1+0x0]
    75b0bab04d98:	jmp    QWORD PTR [rip+0x2]        # 0x75b0bab04da0
    75b0bab04d9e:	xchg   ax,ax
    75b0bab04da0:	rex (bad)
    75b0bab04da2:	mov    al,0xba
    75b0bab04da4:	mov    al,0x75
    75b0bab04da6:	add    BYTE PTR [rax],al
    75b0bab04da8:	mov    al,0x4d
    75b0bab04daa:	mov    al,0xba
    75b0bab04dac:	mov    al,0x75
    75b0bab04dae:	add    BYTE PTR [rax],al
    75b0bab04db0:	movabs r11,0x59d8f50c0940
    75b0bab04dba:	jmp    r11
    75b0bab04dbd:	movdqa xmm0,xmm2
    75b0bab04dc1:	movdqa xmm1,xmm3
    75b0bab04dc5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab04dce:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab04dd7:	call   0x75b0bab05840
    75b0bab04ddc:	jmp    0x75b0bab0274c
    75b0bab04de1:	movdqa xmm0,xmm2
    75b0bab04de5:	movdqa xmm1,xmm3
    75b0bab04de9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab04df2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab04dfb:	call   0x75b0bab05840
    75b0bab04e00:	jmp    0x75b0bab027d8
    75b0bab04e05:	movdqa xmm0,xmm9
    75b0bab04e0a:	movdqa xmm1,xmm2
    75b0bab04e0e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab04e17:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab04e20:	call   0x75b0bab05910
    75b0bab04e25:	jmp    0x75b0bab02e73
    75b0bab04e2a:	movdqa xmm0,xmm8
    75b0bab04e2f:	movdqa xmm1,xmm2
    75b0bab04e33:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab04e3c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab04e45:	call   0x75b0bab05a20
    75b0bab04e4a:	jmp    0x75b0bab02ed2
    75b0bab04e4f:	movdqa xmm0,xmm9
    75b0bab04e54:	movdqa xmm1,xmm7
    75b0bab04e58:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab04e61:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab04e6a:	call   0x75b0bab05b40
    75b0bab04e6f:	jmp    0x75b0bab02f47
    75b0bab04e74:	movdqa xmm0,xmm9
    75b0bab04e79:	movdqa xmm1,xmm6
    75b0bab04e7d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab04e86:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab04e8f:	call   0x75b0bab05c60
    75b0bab04e94:	jmp    0x75b0bab02f97
    75b0bab04e99:	movdqa xmm0,xmm9
    75b0bab04e9e:	movdqa xmm1,xmm6
    75b0bab04ea2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab04eab:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab04eb4:	call   0x75b0bab05d80
    75b0bab04eb9:	jmp    0x75b0bab02ff0
    75b0bab04ebe:	movdqa xmm0,xmm9
    75b0bab04ec3:	movdqa xmm1,xmm2
    75b0bab04ec7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab04ed0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab04ed9:	call   0x75b0bab05eb0
    75b0bab04ede:	jmp    0x75b0bab03091
    75b0bab04ee3:	mov    r11,rax
    75b0bab04ee6:	lahf
    75b0bab04ee7:	seto   al
    75b0bab04eea:	mov    WORD PTR [rsp],ax
    75b0bab04eee:	mov    rax,r11
    75b0bab04ef1:	movdqa xmm0,xmm10
    75b0bab04ef6:	movdqa xmm1,xmm9
    75b0bab04efb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab04f04:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab04f0d:	call   0x75b0bab05ff0
    75b0bab04f12:	mov    r11,rax
    75b0bab04f15:	movzx  eax,WORD PTR [rsp]
    75b0bab04f19:	add    al,0x7f
    75b0bab04f1b:	sahf
    75b0bab04f1c:	mov    rax,r11
    75b0bab04f1f:	jmp    0x75b0bab030fc
    75b0bab04f24:	mov    r11,rax
    75b0bab04f27:	lahf
    75b0bab04f28:	seto   al
    75b0bab04f2b:	mov    WORD PTR [rsp],ax
    75b0bab04f2f:	mov    rax,r11
    75b0bab04f32:	movdqa xmm0,xmm8
    75b0bab04f37:	movdqa xmm1,xmm10
    75b0bab04f3c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab04f45:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab04f4e:	call   0x75b0bab05ff0
    75b0bab04f53:	mov    r11,rax
    75b0bab04f56:	movzx  eax,WORD PTR [rsp]
    75b0bab04f5a:	add    al,0x7f
    75b0bab04f5c:	sahf
    75b0bab04f5d:	mov    rax,r11
    75b0bab04f60:	jmp    0x75b0bab0315c
    75b0bab04f65:	mov    r11,rax
    75b0bab04f68:	lahf
    75b0bab04f69:	seto   al
    75b0bab04f6c:	mov    WORD PTR [rsp],ax
    75b0bab04f70:	mov    rax,r11
    75b0bab04f73:	movdqa xmm0,xmm7
    75b0bab04f77:	movdqa xmm1,xmm10
    75b0bab04f7c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab04f85:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab04f8e:	call   0x75b0bab061c0
    75b0bab04f93:	mov    r11,rax
    75b0bab04f96:	movzx  eax,WORD PTR [rsp]
    75b0bab04f9a:	add    al,0x7f
    75b0bab04f9c:	sahf
    75b0bab04f9d:	mov    rax,r11
    75b0bab04fa0:	jmp    0x75b0bab031b5
    75b0bab04fa5:	movdqa xmm0,xmm12
    75b0bab04faa:	movdqa xmm1,xmm9
    75b0bab04faf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab04fb8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab04fc1:	call   0x75b0bab06380
    75b0bab04fc6:	jmp    0x75b0bab0332d
    75b0bab04fcb:	movdqa xmm0,xmm6
    75b0bab04fcf:	movdqa xmm1,xmm4
    75b0bab04fd3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab04fdc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab04fe5:	call   0x75b0bab06580
    75b0bab04fea:	jmp    0x75b0bab0339b
    75b0bab04fef:	movdqa xmm0,xmm8
    75b0bab04ff4:	movdqa xmm1,xmm11
    75b0bab04ff9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05002:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab0500b:	call   0x75b0bab06770
    75b0bab05010:	jmp    0x75b0bab033f6
    75b0bab05015:	movdqa xmm0,xmm5
    75b0bab05019:	movdqa xmm1,xmm2
    75b0bab0501d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05026:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab0502f:	call   0x75b0bab06960
    75b0bab05034:	jmp    0x75b0bab03453
    75b0bab05039:	movdqa xmm0,xmm9
    75b0bab0503e:	movdqa xmm1,xmm5
    75b0bab05042:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0504b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05054:	call   0x75b0bab06b30
    75b0bab05059:	jmp    0x75b0bab034bb
    75b0bab0505e:	movdqa xmm0,xmm13
    75b0bab05063:	movdqa xmm1,xmm2
    75b0bab05067:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05070:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05079:	call   0x75b0bab06d10
    75b0bab0507e:	jmp    0x75b0bab03534
    75b0bab05083:	movdqa xmm0,xmm9
    75b0bab05088:	movdqa xmm1,xmm5
    75b0bab0508c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05095:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab0509e:	call   0x75b0bab06f00
    75b0bab050a3:	jmp    0x75b0bab035c1
    75b0bab050a8:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    75b0bab050b2:	movdqa xmm1,xmm6
    75b0bab050b6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab050bf:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab050c8:	call   0x75b0bab070c0
    75b0bab050cd:	jmp    0x75b0bab036b6
    75b0bab050d2:	movdqa xmm0,xmm9
    75b0bab050d7:	movdqa xmm1,xmm5
    75b0bab050db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab050e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab050ed:	call   0x75b0bab072a0
    75b0bab050f2:	jmp    0x75b0bab03714
    75b0bab050f7:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    75b0bab05101:	movdqa xmm1,xmm11
    75b0bab05106:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0510f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05118:	call   0x75b0bab07480
    75b0bab0511d:	jmp    0x75b0bab0378d
    75b0bab05122:	movdqa xmm0,xmm12
    75b0bab05127:	movdqa xmm1,xmm8
    75b0bab0512c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05135:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab0513e:	call   0x75b0bab07670
    75b0bab05143:	jmp    0x75b0bab037e8
    75b0bab05148:	movdqa xmm0,xmm9
    75b0bab0514d:	movdqa xmm1,xmm5
    75b0bab05151:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0515a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05163:	call   0x75b0bab07860
    75b0bab05168:	jmp    0x75b0bab03869
    75b0bab0516d:	movdqa xmm0,xmm4
    75b0bab05171:	movdqa xmm1,xmm2
    75b0bab05175:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0517e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05187:	call   0x75b0bab07a40
    75b0bab0518c:	jmp    0x75b0bab038dc
    75b0bab05191:	movdqa xmm0,xmm13
    75b0bab05196:	movdqa xmm1,xmm2
    75b0bab0519a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab051a3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab051ac:	call   0x75b0bab07c20
    75b0bab051b1:	jmp    0x75b0bab03945
    75b0bab051b6:	movdqa xmm0,xmm5
    75b0bab051ba:	movdqa xmm1,xmm2
    75b0bab051be:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab051c7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab051d0:	call   0x75b0bab07e00
    75b0bab051d5:	jmp    0x75b0bab039bd
    75b0bab051da:	movdqa xmm0,xmm3
    75b0bab051de:	movdqa xmm1,xmm6
    75b0bab051e2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab051eb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab051f4:	call   0x75b0bab07fe0
    75b0bab051f9:	jmp    0x75b0bab03a30
    75b0bab051fe:	movdqa xmm0,xmm5
    75b0bab05202:	movdqa xmm1,xmm2
    75b0bab05206:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0520f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05218:	call   0x75b0bab081d0
    75b0bab0521d:	jmp    0x75b0bab03ad2
    75b0bab05222:	movdqa xmm0,xmm10
    75b0bab05227:	movdqa xmm1,xmm12
    75b0bab0522c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05235:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab0523e:	call   0x75b0bab083c0
    75b0bab05243:	jmp    0x75b0bab03b43
    75b0bab05248:	movdqa xmm0,xmm7
    75b0bab0524c:	movdqa xmm1,xmm2
    75b0bab05250:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05259:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05262:	call   0x75b0bab085c0
    75b0bab05267:	jmp    0x75b0bab03b96
    75b0bab0526c:	movdqa xmm0,xmm11
    75b0bab05271:	movdqa xmm1,xmm13
    75b0bab05276:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0527f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05288:	call   0x75b0bab087a0
    75b0bab0528d:	jmp    0x75b0bab03be7
    75b0bab05292:	movdqa xmm0,xmm5
    75b0bab05296:	movdqa xmm1,xmm7
    75b0bab0529a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab052a3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab052ac:	call   0x75b0bab08980
    75b0bab052b1:	jmp    0x75b0bab03c44
    75b0bab052b6:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    75b0bab052c0:	movdqa xmm1,xmm7
    75b0bab052c4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab052cd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab052d6:	call   0x75b0bab08b50
    75b0bab052db:	jmp    0x75b0bab03c9e
    75b0bab052e0:	movdqa xmm0,xmm8
    75b0bab052e5:	movdqa xmm1,xmm4
    75b0bab052e9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab052f2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab052fb:	call   0x75b0bab08d20
    75b0bab05300:	jmp    0x75b0bab03ced
    75b0bab05305:	movdqa xmm0,xmm9
    75b0bab0530a:	movdqa xmm1,xmm6
    75b0bab0530e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05317:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05320:	call   0x75b0bab08f00
    75b0bab05325:	jmp    0x75b0bab03d47
    75b0bab0532a:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    75b0bab05334:	movdqa xmm1,xmm7
    75b0bab05338:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05341:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab0534a:	call   0x75b0bab090d0
    75b0bab0534f:	jmp    0x75b0bab03daa
    75b0bab05354:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    75b0bab0535e:	movdqa xmm1,xmm7
    75b0bab05362:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0536b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05374:	call   0x75b0bab09290
    75b0bab05379:	jmp    0x75b0bab03e03
    75b0bab0537e:	movdqa xmm0,xmm3
    75b0bab05382:	movdqa xmm1,xmm10
    75b0bab05387:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05390:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05399:	call   0x75b0bab09460
    75b0bab0539e:	jmp    0x75b0bab03e5d
    75b0bab053a3:	movdqa xmm0,xmm2
    75b0bab053a7:	movdqa xmm1,xmm11
    75b0bab053ac:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab053b5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab053be:	call   0x75b0bab09630
    75b0bab053c3:	jmp    0x75b0bab03eb6
    75b0bab053c8:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    75b0bab053d2:	movdqa xmm1,xmm2
    75b0bab053d6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab053df:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab053e8:	call   0x75b0bab097f0
    75b0bab053ed:	jmp    0x75b0bab03f23
    75b0bab053f2:	movdqa xmm0,xmm4
    75b0bab053f6:	movdqa xmm1,xmm5
    75b0bab053fa:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05403:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab0540c:	call   0x75b0bab099a0
    75b0bab05411:	jmp    0x75b0bab03f7c
    75b0bab05416:	movdqa xmm0,xmm12
    75b0bab0541b:	movdqa xmm1,xmm6
    75b0bab0541f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05428:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05431:	call   0x75b0bab09b70
    75b0bab05436:	jmp    0x75b0bab03fd6
    75b0bab0543b:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    75b0bab05445:	movdqa xmm1,xmm2
    75b0bab05449:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05452:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab0545b:	call   0x75b0bab08980
    75b0bab05460:	jmp    0x75b0bab040b6
    75b0bab05465:	movdqa xmm0,xmm7
    75b0bab05469:	movdqa xmm1,xmm8
    75b0bab0546e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05477:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05480:	call   0x75b0bab08d20
    75b0bab05485:	jmp    0x75b0bab04106
    75b0bab0548a:	movdqa xmm0,xmm3
    75b0bab0548e:	movdqa xmm1,xmm9
    75b0bab05493:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0549c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab054a5:	call   0x75b0bab09d30
    75b0bab054aa:	jmp    0x75b0bab04156
    75b0bab054af:	movdqa xmm0,xmm6
    75b0bab054b3:	movdqa xmm1,xmm2
    75b0bab054b7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab054c0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab054c9:	call   0x75b0bab09f00
    75b0bab054ce:	jmp    0x75b0bab041b3
    75b0bab054d3:	movdqa xmm0,xmm6
    75b0bab054d7:	movdqa xmm1,xmm2
    75b0bab054db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab054e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab054ed:	call   0x75b0bab09290
    75b0bab054f2:	jmp    0x75b0bab0421a
    75b0bab054f7:	movdqa xmm0,xmm5
    75b0bab054fb:	movdqa xmm1,xmm2
    75b0bab054ff:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05508:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05511:	call   0x75b0bab0a0c0
    75b0bab05516:	jmp    0x75b0bab04278
    75b0bab0551b:	movdqa xmm0,xmm10
    75b0bab05520:	movdqa xmm1,xmm11
    75b0bab05525:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0552e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05537:	call   0x75b0bab0a290
    75b0bab0553c:	jmp    0x75b0bab042d2
    75b0bab05541:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    75b0bab0554b:	movdqa xmm1,xmm2
    75b0bab0554f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05558:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05561:	call   0x75b0bab097f0
    75b0bab05566:	jmp    0x75b0bab04335
    75b0bab0556b:	movdqa xmm0,xmm4
    75b0bab0556f:	movdqa xmm1,xmm3
    75b0bab05573:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0557c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05585:	call   0x75b0bab099a0
    75b0bab0558a:	jmp    0x75b0bab0438e
    75b0bab0558f:	movdqa xmm0,xmm3
    75b0bab05593:	movdqa xmm1,xmm2
    75b0bab05597:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab055a0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab055a9:	call   0x75b0bab0a460
    75b0bab055ae:	jmp    0x75b0bab043f6
    75b0bab055b3:	movdqa xmm0,xmm12
    75b0bab055b8:	movdqa xmm1,xmm8
    75b0bab055bd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab055c6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab055cf:	call   0x75b0bab0a630
    75b0bab055d4:	jmp    0x75b0bab04450
    75b0bab055d9:	movdqa xmm0,xmm8
    75b0bab055de:	movdqa xmm1,xmm2
    75b0bab055e2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab055eb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab055f4:	call   0x75b0bab08980
    75b0bab055f9:	jmp    0x75b0bab044b8
    75b0bab055fe:	movdqa xmm0,xmm7
    75b0bab05602:	movdqa xmm1,xmm6
    75b0bab05606:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0560f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05618:	call   0x75b0bab0a800
    75b0bab0561d:	jmp    0x75b0bab04511
    75b0bab05622:	movdqa xmm0,xmm5
    75b0bab05626:	movdqa xmm1,xmm9
    75b0bab0562b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05634:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab0563d:	call   0x75b0bab0a9c0
    75b0bab05642:	jmp    0x75b0bab04581
    75b0bab05647:	movdqa xmm0,xmm6
    75b0bab0564b:	movdqa xmm1,xmm5
    75b0bab0564f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05658:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05661:	call   0x75b0bab0ab80
    75b0bab05666:	jmp    0x75b0bab045e8
    75b0bab0566b:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    75b0bab05675:	movdqa xmm1,xmm5
    75b0bab05679:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05682:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab0568b:	call   0x75b0bab0ad30
    75b0bab05690:	jmp    0x75b0bab0464c
    75b0bab05695:	movdqa xmm0,xmm10
    75b0bab0569a:	movdqa xmm1,xmm4
    75b0bab0569e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab056a7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab056b0:	call   0x75b0bab0aef0
    75b0bab056b5:	jmp    0x75b0bab046a5
    75b0bab056ba:	movdqa xmm0,xmm3
    75b0bab056be:	movdqa xmm1,xmm11
    75b0bab056c3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab056cc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab056d5:	call   0x75b0bab08d20
    75b0bab056da:	jmp    0x75b0bab0471b
    75b0bab056df:	movdqa xmm0,xmm10
    75b0bab056e4:	movdqa xmm1,xmm5
    75b0bab056e8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab056f1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab056fa:	call   0x75b0bab0b0c0
    75b0bab056ff:	jmp    0x75b0bab0477a
    75b0bab05704:	movdqa xmm0,xmm4
    75b0bab05708:	movdqa xmm1,xmm5
    75b0bab0570c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05715:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab0571e:	call   0x75b0bab0b290
    75b0bab05723:	jmp    0x75b0bab047d7
    75b0bab05728:	movdqa xmm0,xmm2
    75b0bab0572c:	movdqa xmm1,xmm8
    75b0bab05731:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0573a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05743:	call   0x75b0bab09b70
    75b0bab05748:	jmp    0x75b0bab04827
    75b0bab0574d:	movdqa xmm0,xmm7
    75b0bab05751:	movdqa xmm1,xmm6
    75b0bab05755:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0575e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05767:	call   0x75b0bab0b460
    75b0bab0576c:	jmp    0x75b0bab0487f
    75b0bab05771:	movdqa xmm0,xmm9
    75b0bab05776:	movdqa xmm1,xmm3
    75b0bab0577a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab05783:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab0578c:	call   0x75b0bab0b610
    75b0bab05791:	jmp    0x75b0bab048d8
    75b0bab05796:	movdqa xmm0,xmm12
    75b0bab0579b:	movdqa xmm1,xmm10
    75b0bab057a0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab057a9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab057b2:	call   0x75b0bab0b7b0
    75b0bab057b7:	jmp    0x75b0bab04932
    75b0bab057bc:	mov    r11,rax
    75b0bab057bf:	lahf
    75b0bab057c0:	seto   al
    75b0bab057c3:	mov    WORD PTR [rsp],ax
    75b0bab057c7:	mov    rax,r11
    75b0bab057ca:	movdqa xmm0,xmm2
    75b0bab057ce:	movdqa xmm1,xmm3
    75b0bab057d2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab057db:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab057e4:	call   0x75b0bab0b940
    75b0bab057e9:	mov    r11,rax
    75b0bab057ec:	movzx  eax,WORD PTR [rsp]
    75b0bab057f0:	add    al,0x7f
    75b0bab057f2:	sahf
    75b0bab057f3:	mov    rax,r11
    75b0bab057f6:	jmp    0x75b0bab04abd
    75b0bab057fb:	mov    r11,rax
    75b0bab057fe:	lahf
    75b0bab057ff:	seto   al
    75b0bab05802:	mov    WORD PTR [rsp],ax
    75b0bab05806:	mov    rax,r11
    75b0bab05809:	movdqa xmm0,xmm4
    75b0bab0580d:	movdqa xmm1,xmm2
    75b0bab05811:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75b0bab0581a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75b0bab05823:	call   0x75b0bab0baa0
    75b0bab05828:	mov    r11,rax
    75b0bab0582b:	movzx  eax,WORD PTR [rsp]
    75b0bab0582f:	add    al,0x7f
    75b0bab05831:	sahf
    75b0bab05832:	mov    rax,r11
    75b0bab05835:	jmp    0x75b0bab04b1d
    75b0bab0583a:	nop    WORD PTR [rax+rax*1+0x0]
    75b0bab05840:	sub    rsp,0x8
    75b0bab05844:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab05850:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab05856:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0585c:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab05864:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0586a:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0586f:	test   r10d,0x3f
    75b0bab05876:	je     0x75b0bab0589b
    75b0bab0587c:	mov    r11d,r10d
    75b0bab0587f:	shr    r10d,1
    75b0bab05882:	and    r10d,0x1e
    75b0bab05886:	and    r11d,0x1
    75b0bab0588a:	or     r10d,r11d
    75b0bab0588d:	or     DWORD PTR [r12+0x314],r10d
    75b0bab05895:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0589b:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab058a1:	lea    rdi,[rsp+0x110]
    75b0bab058a9:	lea    rsi,[rsp+0xf0]
    75b0bab058b1:	lea    rdx,[rsp+0x100]
    75b0bab058b9:	mov    ecx,0x16
    75b0bab058be:	mov    r8d,0x0
    75b0bab058c4:	lea    r9,[r12+0x314]
    75b0bab058cc:	movabs r11,0x59d8f4f27650
    75b0bab058d6:	call   r11
    75b0bab058d9:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab058df:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab058e5:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab058eb:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab058f3:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab058ff:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab05908:	add    rsp,0x8
    75b0bab0590c:	ret
    75b0bab0590d:	nop    DWORD PTR [rax]
    75b0bab05910:	sub    rsp,0x8
    75b0bab05914:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab05920:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab05926:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0592c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab05932:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab0593c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab05946:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0594e:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab05954:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab05959:	test   r10d,0x3f
    75b0bab05960:	je     0x75b0bab05985
    75b0bab05966:	mov    r11d,r10d
    75b0bab05969:	shr    r10d,1
    75b0bab0596c:	and    r10d,0x1e
    75b0bab05970:	and    r11d,0x1
    75b0bab05974:	or     r10d,r11d
    75b0bab05977:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0597f:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab05985:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0598b:	lea    rdi,[rsp+0x110]
    75b0bab05993:	lea    rsi,[rsp+0xf0]
    75b0bab0599b:	lea    rdx,[rsp+0x100]
    75b0bab059a3:	mov    ecx,0x16
    75b0bab059a8:	mov    r8d,0x0
    75b0bab059ae:	lea    r9,[r12+0x314]
    75b0bab059b6:	movabs r11,0x59d8f4f27650
    75b0bab059c0:	call   r11
    75b0bab059c3:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab059c9:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab059cf:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab059d5:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab059db:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab059e5:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab059ef:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab059f7:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab05a03:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab05a0c:	add    rsp,0x8
    75b0bab05a10:	ret
    75b0bab05a11:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab05a20:	sub    rsp,0x8
    75b0bab05a24:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab05a30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab05a36:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab05a3c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab05a42:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab05a4c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab05a56:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab05a60:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab05a68:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab05a6e:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab05a73:	test   r10d,0x3f
    75b0bab05a7a:	je     0x75b0bab05a9f
    75b0bab05a80:	mov    r11d,r10d
    75b0bab05a83:	shr    r10d,1
    75b0bab05a86:	and    r10d,0x1e
    75b0bab05a8a:	and    r11d,0x1
    75b0bab05a8e:	or     r10d,r11d
    75b0bab05a91:	or     DWORD PTR [r12+0x314],r10d
    75b0bab05a99:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab05a9f:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab05aa5:	lea    rdi,[rsp+0x110]
    75b0bab05aad:	lea    rsi,[rsp+0xf0]
    75b0bab05ab5:	lea    rdx,[rsp+0x100]
    75b0bab05abd:	mov    ecx,0x56
    75b0bab05ac2:	mov    r8d,0x0
    75b0bab05ac8:	lea    r9,[r12+0x314]
    75b0bab05ad0:	movabs r11,0x59d8f4f27650
    75b0bab05ada:	call   r11
    75b0bab05add:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab05ae3:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab05ae9:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab05aef:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab05af5:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab05aff:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab05b09:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab05b13:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab05b1b:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab05b27:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab05b30:	add    rsp,0x8
    75b0bab05b34:	ret
    75b0bab05b35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab05b40:	sub    rsp,0x8
    75b0bab05b44:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab05b50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab05b56:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab05b5c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab05b62:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab05b6c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab05b76:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab05b80:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab05b88:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab05b8e:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab05b93:	test   r10d,0x3f
    75b0bab05b9a:	je     0x75b0bab05bbf
    75b0bab05ba0:	mov    r11d,r10d
    75b0bab05ba3:	shr    r10d,1
    75b0bab05ba6:	and    r10d,0x1e
    75b0bab05baa:	and    r11d,0x1
    75b0bab05bae:	or     r10d,r11d
    75b0bab05bb1:	or     DWORD PTR [r12+0x314],r10d
    75b0bab05bb9:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab05bbf:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab05bc5:	lea    rdi,[rsp+0x110]
    75b0bab05bcd:	lea    rsi,[rsp+0xf0]
    75b0bab05bd5:	lea    rdx,[rsp+0x100]
    75b0bab05bdd:	mov    ecx,0x16
    75b0bab05be2:	mov    r8d,0x0
    75b0bab05be8:	lea    r9,[r12+0x314]
    75b0bab05bf0:	movabs r11,0x59d8f4f27650
    75b0bab05bfa:	call   r11
    75b0bab05bfd:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab05c03:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab05c09:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab05c0f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab05c15:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab05c1f:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab05c29:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab05c33:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab05c3b:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab05c47:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab05c50:	add    rsp,0x8
    75b0bab05c54:	ret
    75b0bab05c55:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab05c60:	sub    rsp,0x8
    75b0bab05c64:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab05c70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab05c76:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab05c7c:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab05c86:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab05c90:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab05c9a:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab05ca4:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab05cac:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab05cb2:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab05cb7:	test   r10d,0x3f
    75b0bab05cbe:	je     0x75b0bab05ce3
    75b0bab05cc4:	mov    r11d,r10d
    75b0bab05cc7:	shr    r10d,1
    75b0bab05cca:	and    r10d,0x1e
    75b0bab05cce:	and    r11d,0x1
    75b0bab05cd2:	or     r10d,r11d
    75b0bab05cd5:	or     DWORD PTR [r12+0x314],r10d
    75b0bab05cdd:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab05ce3:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab05ce9:	lea    rdi,[rsp+0x110]
    75b0bab05cf1:	lea    rsi,[rsp+0xf0]
    75b0bab05cf9:	lea    rdx,[rsp+0x100]
    75b0bab05d01:	mov    ecx,0x16
    75b0bab05d06:	mov    r8d,0x0
    75b0bab05d0c:	lea    r9,[r12+0x314]
    75b0bab05d14:	movabs r11,0x59d8f4f27650
    75b0bab05d1e:	call   r11
    75b0bab05d21:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab05d27:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab05d2d:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab05d33:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab05d3d:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab05d47:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab05d51:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab05d5b:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab05d63:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab05d6f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab05d78:	add    rsp,0x8
    75b0bab05d7c:	ret
    75b0bab05d7d:	nop    DWORD PTR [rax]
    75b0bab05d80:	sub    rsp,0x8
    75b0bab05d84:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab05d90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab05d96:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab05d9c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab05da2:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab05dac:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab05db6:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab05dc0:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab05dca:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab05dd2:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab05dd8:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab05ddd:	test   r10d,0x3f
    75b0bab05de4:	je     0x75b0bab05e09
    75b0bab05dea:	mov    r11d,r10d
    75b0bab05ded:	shr    r10d,1
    75b0bab05df0:	and    r10d,0x1e
    75b0bab05df4:	and    r11d,0x1
    75b0bab05df8:	or     r10d,r11d
    75b0bab05dfb:	or     DWORD PTR [r12+0x314],r10d
    75b0bab05e03:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab05e09:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab05e0f:	lea    rdi,[rsp+0x110]
    75b0bab05e17:	lea    rsi,[rsp+0xf0]
    75b0bab05e1f:	lea    rdx,[rsp+0x100]
    75b0bab05e27:	mov    ecx,0x16
    75b0bab05e2c:	mov    r8d,0x0
    75b0bab05e32:	lea    r9,[r12+0x314]
    75b0bab05e3a:	movabs r11,0x59d8f4f27650
    75b0bab05e44:	call   r11
    75b0bab05e47:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab05e4d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab05e53:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab05e59:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab05e5f:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab05e69:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab05e73:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab05e7d:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab05e87:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab05e8f:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab05e9b:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab05ea4:	add    rsp,0x8
    75b0bab05ea8:	ret
    75b0bab05ea9:	nop    DWORD PTR [rax+0x0]
    75b0bab05eb0:	sub    rsp,0x8
    75b0bab05eb4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab05ec0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab05ec6:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab05ecc:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab05ed6:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab05ee0:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab05eea:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab05ef4:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab05efe:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab05f06:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab05f0c:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab05f11:	test   r10d,0x3f
    75b0bab05f18:	je     0x75b0bab05f3d
    75b0bab05f1e:	mov    r11d,r10d
    75b0bab05f21:	shr    r10d,1
    75b0bab05f24:	and    r10d,0x1e
    75b0bab05f28:	and    r11d,0x1
    75b0bab05f2c:	or     r10d,r11d
    75b0bab05f2f:	or     DWORD PTR [r12+0x314],r10d
    75b0bab05f37:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab05f3d:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab05f43:	lea    rdi,[rsp+0x110]
    75b0bab05f4b:	lea    rsi,[rsp+0xf0]
    75b0bab05f53:	lea    rdx,[rsp+0x100]
    75b0bab05f5b:	mov    ecx,0x56
    75b0bab05f60:	mov    r8d,0x0
    75b0bab05f66:	lea    r9,[r12+0x314]
    75b0bab05f6e:	movabs r11,0x59d8f4f27650
    75b0bab05f78:	call   r11
    75b0bab05f7b:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab05f81:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab05f87:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab05f8d:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab05f97:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab05fa1:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab05fab:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab05fb5:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab05fbf:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab05fc7:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab05fd3:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab05fdc:	add    rsp,0x8
    75b0bab05fe0:	ret
    75b0bab05fe1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab05ff0:	sub    rsp,0x8
    75b0bab05ff4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab06000:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab06006:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0600c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab06012:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab0601c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab06026:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab06030:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab0603a:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab06044:	push   rdx
    75b0bab06045:	push   rsi
    75b0bab06046:	push   r10
    75b0bab06048:	push   r11
    75b0bab0604a:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0604f:	mov    r10d,edx
    75b0bab06052:	and    r10d,0xc000
    75b0bab06059:	shl    r10d,0x10
    75b0bab0605d:	mov    r11d,edx
    75b0bab06060:	and    r11d,0x100
    75b0bab06067:	shl    r11d,0x15
    75b0bab0606b:	or     r10d,r11d
    75b0bab0606e:	and    edx,0x1
    75b0bab06071:	shl    edx,0x1c
    75b0bab06074:	or     r10d,edx
    75b0bab06077:	btc    r10,0x1d
    75b0bab0607c:	mov    r11d,0xf0000000
    75b0bab06082:	and    r11,r10
    75b0bab06085:	movabs rsi,0xffffffff0fffffff
    75b0bab0608f:	and    rbx,rsi
    75b0bab06092:	or     rbx,r11
    75b0bab06095:	pop    r11
    75b0bab06097:	pop    r10
    75b0bab06099:	pop    rsi
    75b0bab0609a:	pop    rdx
    75b0bab0609b:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab060a3:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab060a9:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab060ae:	test   r10d,0x3f
    75b0bab060b5:	je     0x75b0bab060da
    75b0bab060bb:	mov    r11d,r10d
    75b0bab060be:	shr    r10d,1
    75b0bab060c1:	and    r10d,0x1e
    75b0bab060c5:	and    r11d,0x1
    75b0bab060c9:	or     r10d,r11d
    75b0bab060cc:	or     DWORD PTR [r12+0x314],r10d
    75b0bab060d4:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab060da:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab060e0:	lea    rdi,[rsp+0x110]
    75b0bab060e8:	lea    rsi,[rsp+0xf0]
    75b0bab060f0:	lea    rdx,[rsp+0x100]
    75b0bab060f8:	mov    ecx,0x14
    75b0bab060fd:	mov    r8d,0x0
    75b0bab06103:	lea    r9,[r12+0x314]
    75b0bab0610b:	movabs r11,0x59d8f4f27650
    75b0bab06115:	call   r11
    75b0bab06118:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0611e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab06124:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0612a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab06130:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab0613a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab06144:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0614e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab06158:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab06162:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0616a:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab06176:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0617f:	mov    rdx,rbx
    75b0bab06182:	shr    rdx,0x10
    75b0bab06186:	and    edx,0xc000
    75b0bab0618c:	mov    rax,rbx
    75b0bab0618f:	shr    rax,0x15
    75b0bab06193:	and    eax,0x100
    75b0bab06198:	xor    eax,0x100
    75b0bab0619d:	or     edx,eax
    75b0bab0619f:	mov    rax,rbx
    75b0bab061a2:	shr    rax,0x1c
    75b0bab061a6:	and    eax,0x1
    75b0bab061a9:	or     edx,eax
    75b0bab061ab:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab061b0:	add    rsp,0x8
    75b0bab061b4:	ret
    75b0bab061b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab061c0:	sub    rsp,0x8
    75b0bab061c4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab061d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab061d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab061dc:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab061e2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab061e8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab061f2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab061fc:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab06206:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab06210:	push   rdx
    75b0bab06211:	push   rsi
    75b0bab06212:	push   r10
    75b0bab06214:	push   r11
    75b0bab06216:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0621b:	mov    r10d,edx
    75b0bab0621e:	and    r10d,0xc000
    75b0bab06225:	shl    r10d,0x10
    75b0bab06229:	mov    r11d,edx
    75b0bab0622c:	and    r11d,0x100
    75b0bab06233:	shl    r11d,0x15
    75b0bab06237:	or     r10d,r11d
    75b0bab0623a:	and    edx,0x1
    75b0bab0623d:	shl    edx,0x1c
    75b0bab06240:	or     r10d,edx
    75b0bab06243:	btc    r10,0x1d
    75b0bab06248:	mov    r11d,0xf0000000
    75b0bab0624e:	and    r11,r10
    75b0bab06251:	movabs rsi,0xffffffff0fffffff
    75b0bab0625b:	and    rbx,rsi
    75b0bab0625e:	or     rbx,r11
    75b0bab06261:	pop    r11
    75b0bab06263:	pop    r10
    75b0bab06265:	pop    rsi
    75b0bab06266:	pop    rdx
    75b0bab06267:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0626f:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab06275:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0627a:	test   r10d,0x3f
    75b0bab06281:	je     0x75b0bab062a6
    75b0bab06287:	mov    r11d,r10d
    75b0bab0628a:	shr    r10d,1
    75b0bab0628d:	and    r10d,0x1e
    75b0bab06291:	and    r11d,0x1
    75b0bab06295:	or     r10d,r11d
    75b0bab06298:	or     DWORD PTR [r12+0x314],r10d
    75b0bab062a0:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab062a6:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab062ac:	lea    rdi,[rsp+0x110]
    75b0bab062b4:	lea    rsi,[rsp+0xf0]
    75b0bab062bc:	lea    rdx,[rsp+0x100]
    75b0bab062c4:	mov    ecx,0x14
    75b0bab062c9:	mov    r8d,0x0
    75b0bab062cf:	lea    r9,[r12+0x314]
    75b0bab062d7:	movabs r11,0x59d8f4f27650
    75b0bab062e1:	call   r11
    75b0bab062e4:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab062ea:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab062f0:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab062f6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab062fc:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab06302:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0630c:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab06316:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab06320:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0632a:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab06332:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0633e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab06347:	mov    rdx,rbx
    75b0bab0634a:	shr    rdx,0x10
    75b0bab0634e:	and    edx,0xc000
    75b0bab06354:	mov    rax,rbx
    75b0bab06357:	shr    rax,0x15
    75b0bab0635b:	and    eax,0x100
    75b0bab06360:	xor    eax,0x100
    75b0bab06365:	or     edx,eax
    75b0bab06367:	mov    rax,rbx
    75b0bab0636a:	shr    rax,0x1c
    75b0bab0636e:	and    eax,0x1
    75b0bab06371:	or     edx,eax
    75b0bab06373:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab06378:	add    rsp,0x8
    75b0bab0637c:	ret
    75b0bab0637d:	nop    DWORD PTR [rax]
    75b0bab06380:	sub    rsp,0x8
    75b0bab06384:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab06390:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab06396:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0639c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab063a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab063a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab063ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab063b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab063be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab063c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab063d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab063dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab063e6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab063f0:	push   rdx
    75b0bab063f1:	push   rsi
    75b0bab063f2:	push   r10
    75b0bab063f4:	push   r11
    75b0bab063f6:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab063fb:	mov    r10d,edx
    75b0bab063fe:	and    r10d,0xc000
    75b0bab06405:	shl    r10d,0x10
    75b0bab06409:	mov    r11d,edx
    75b0bab0640c:	and    r11d,0x100
    75b0bab06413:	shl    r11d,0x15
    75b0bab06417:	or     r10d,r11d
    75b0bab0641a:	and    edx,0x1
    75b0bab0641d:	shl    edx,0x1c
    75b0bab06420:	or     r10d,edx
    75b0bab06423:	btc    r10,0x1d
    75b0bab06428:	mov    r11d,0xf0000000
    75b0bab0642e:	and    r11,r10
    75b0bab06431:	movabs rsi,0xffffffff0fffffff
    75b0bab0643b:	and    rbx,rsi
    75b0bab0643e:	or     rbx,r11
    75b0bab06441:	pop    r11
    75b0bab06443:	pop    r10
    75b0bab06445:	pop    rsi
    75b0bab06446:	pop    rdx
    75b0bab06447:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0644f:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab06455:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0645a:	test   r10d,0x3f
    75b0bab06461:	je     0x75b0bab06486
    75b0bab06467:	mov    r11d,r10d
    75b0bab0646a:	shr    r10d,1
    75b0bab0646d:	and    r10d,0x1e
    75b0bab06471:	and    r11d,0x1
    75b0bab06475:	or     r10d,r11d
    75b0bab06478:	or     DWORD PTR [r12+0x314],r10d
    75b0bab06480:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab06486:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0648c:	lea    rdi,[rsp+0x110]
    75b0bab06494:	lea    rsi,[rsp+0xf0]
    75b0bab0649c:	lea    rdx,[rsp+0x100]
    75b0bab064a4:	mov    ecx,0x14
    75b0bab064a9:	mov    r8d,0x0
    75b0bab064af:	lea    r9,[r12+0x314]
    75b0bab064b7:	movabs r11,0x59d8f4f27650
    75b0bab064c1:	call   r11
    75b0bab064c4:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab064ca:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab064d0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab064d6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab064dc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab064e2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab064e8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab064ee:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab064f8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab06502:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0650c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab06516:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab06520:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab0652a:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab06532:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0653e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab06547:	mov    rdx,rbx
    75b0bab0654a:	shr    rdx,0x10
    75b0bab0654e:	and    edx,0xc000
    75b0bab06554:	mov    rax,rbx
    75b0bab06557:	shr    rax,0x15
    75b0bab0655b:	and    eax,0x100
    75b0bab06560:	xor    eax,0x100
    75b0bab06565:	or     edx,eax
    75b0bab06567:	mov    rax,rbx
    75b0bab0656a:	shr    rax,0x1c
    75b0bab0656e:	and    eax,0x1
    75b0bab06571:	or     edx,eax
    75b0bab06573:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab06578:	add    rsp,0x8
    75b0bab0657c:	ret
    75b0bab0657d:	nop    DWORD PTR [rax]
    75b0bab06580:	sub    rsp,0x8
    75b0bab06584:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab06590:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab06596:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0659c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab065a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab065a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab065ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab065b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab065be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab065c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab065d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab065dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab065e6:	push   rdx
    75b0bab065e7:	push   rsi
    75b0bab065e8:	push   r10
    75b0bab065ea:	push   r11
    75b0bab065ec:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab065f1:	mov    r10d,edx
    75b0bab065f4:	and    r10d,0xc000
    75b0bab065fb:	shl    r10d,0x10
    75b0bab065ff:	mov    r11d,edx
    75b0bab06602:	and    r11d,0x100
    75b0bab06609:	shl    r11d,0x15
    75b0bab0660d:	or     r10d,r11d
    75b0bab06610:	and    edx,0x1
    75b0bab06613:	shl    edx,0x1c
    75b0bab06616:	or     r10d,edx
    75b0bab06619:	btc    r10,0x1d
    75b0bab0661e:	mov    r11d,0xf0000000
    75b0bab06624:	and    r11,r10
    75b0bab06627:	movabs rsi,0xffffffff0fffffff
    75b0bab06631:	and    rbx,rsi
    75b0bab06634:	or     rbx,r11
    75b0bab06637:	pop    r11
    75b0bab06639:	pop    r10
    75b0bab0663b:	pop    rsi
    75b0bab0663c:	pop    rdx
    75b0bab0663d:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab06645:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0664b:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab06650:	test   r10d,0x3f
    75b0bab06657:	je     0x75b0bab0667c
    75b0bab0665d:	mov    r11d,r10d
    75b0bab06660:	shr    r10d,1
    75b0bab06663:	and    r10d,0x1e
    75b0bab06667:	and    r11d,0x1
    75b0bab0666b:	or     r10d,r11d
    75b0bab0666e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab06676:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0667c:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab06682:	lea    rdi,[rsp+0x110]
    75b0bab0668a:	lea    rsi,[rsp+0xf0]
    75b0bab06692:	lea    rdx,[rsp+0x100]
    75b0bab0669a:	mov    ecx,0x14
    75b0bab0669f:	mov    r8d,0x0
    75b0bab066a5:	lea    r9,[r12+0x314]
    75b0bab066ad:	movabs r11,0x59d8f4f27650
    75b0bab066b7:	call   r11
    75b0bab066ba:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab066c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab066c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab066cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab066d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab066d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab066de:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab066e4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab066ee:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab066f8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab06702:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab0670c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab06716:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0671e:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0672a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab06733:	mov    rdx,rbx
    75b0bab06736:	shr    rdx,0x10
    75b0bab0673a:	and    edx,0xc000
    75b0bab06740:	mov    rax,rbx
    75b0bab06743:	shr    rax,0x15
    75b0bab06747:	and    eax,0x100
    75b0bab0674c:	xor    eax,0x100
    75b0bab06751:	or     edx,eax
    75b0bab06753:	mov    rax,rbx
    75b0bab06756:	shr    rax,0x1c
    75b0bab0675a:	and    eax,0x1
    75b0bab0675d:	or     edx,eax
    75b0bab0675f:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab06764:	add    rsp,0x8
    75b0bab06768:	ret
    75b0bab06769:	nop    DWORD PTR [rax+0x0]
    75b0bab06770:	sub    rsp,0x8
    75b0bab06774:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab06780:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab06786:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0678c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab06792:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab06798:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab067a2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab067ac:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab067b6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab067c0:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab067ca:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab067d4:	push   rdx
    75b0bab067d5:	push   rsi
    75b0bab067d6:	push   r10
    75b0bab067d8:	push   r11
    75b0bab067da:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab067df:	mov    r10d,edx
    75b0bab067e2:	and    r10d,0xc000
    75b0bab067e9:	shl    r10d,0x10
    75b0bab067ed:	mov    r11d,edx
    75b0bab067f0:	and    r11d,0x100
    75b0bab067f7:	shl    r11d,0x15
    75b0bab067fb:	or     r10d,r11d
    75b0bab067fe:	and    edx,0x1
    75b0bab06801:	shl    edx,0x1c
    75b0bab06804:	or     r10d,edx
    75b0bab06807:	btc    r10,0x1d
    75b0bab0680c:	mov    r11d,0xf0000000
    75b0bab06812:	and    r11,r10
    75b0bab06815:	movabs rsi,0xffffffff0fffffff
    75b0bab0681f:	and    rbx,rsi
    75b0bab06822:	or     rbx,r11
    75b0bab06825:	pop    r11
    75b0bab06827:	pop    r10
    75b0bab06829:	pop    rsi
    75b0bab0682a:	pop    rdx
    75b0bab0682b:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab06833:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab06839:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0683e:	test   r10d,0x3f
    75b0bab06845:	je     0x75b0bab0686a
    75b0bab0684b:	mov    r11d,r10d
    75b0bab0684e:	shr    r10d,1
    75b0bab06851:	and    r10d,0x1e
    75b0bab06855:	and    r11d,0x1
    75b0bab06859:	or     r10d,r11d
    75b0bab0685c:	or     DWORD PTR [r12+0x314],r10d
    75b0bab06864:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0686a:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab06870:	lea    rdi,[rsp+0x110]
    75b0bab06878:	lea    rsi,[rsp+0xf0]
    75b0bab06880:	lea    rdx,[rsp+0x100]
    75b0bab06888:	mov    ecx,0x14
    75b0bab0688d:	mov    r8d,0x0
    75b0bab06893:	lea    r9,[r12+0x314]
    75b0bab0689b:	movabs r11,0x59d8f4f27650
    75b0bab068a5:	call   r11
    75b0bab068a8:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab068ae:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab068b4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab068ba:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab068c0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab068c6:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab068d0:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab068da:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab068e4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab068ee:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab068f8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab06902:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0690a:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab06916:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0691f:	mov    rdx,rbx
    75b0bab06922:	shr    rdx,0x10
    75b0bab06926:	and    edx,0xc000
    75b0bab0692c:	mov    rax,rbx
    75b0bab0692f:	shr    rax,0x15
    75b0bab06933:	and    eax,0x100
    75b0bab06938:	xor    eax,0x100
    75b0bab0693d:	or     edx,eax
    75b0bab0693f:	mov    rax,rbx
    75b0bab06942:	shr    rax,0x1c
    75b0bab06946:	and    eax,0x1
    75b0bab06949:	or     edx,eax
    75b0bab0694b:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab06950:	add    rsp,0x8
    75b0bab06954:	ret
    75b0bab06955:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab06960:	sub    rsp,0x8
    75b0bab06964:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab06970:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab06976:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0697c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab06982:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab06988:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab0698e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab06998:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab069a2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab069ac:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab069b6:	push   rdx
    75b0bab069b7:	push   rsi
    75b0bab069b8:	push   r10
    75b0bab069ba:	push   r11
    75b0bab069bc:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab069c1:	mov    r10d,edx
    75b0bab069c4:	and    r10d,0xc000
    75b0bab069cb:	shl    r10d,0x10
    75b0bab069cf:	mov    r11d,edx
    75b0bab069d2:	and    r11d,0x100
    75b0bab069d9:	shl    r11d,0x15
    75b0bab069dd:	or     r10d,r11d
    75b0bab069e0:	and    edx,0x1
    75b0bab069e3:	shl    edx,0x1c
    75b0bab069e6:	or     r10d,edx
    75b0bab069e9:	btc    r10,0x1d
    75b0bab069ee:	mov    r11d,0xf0000000
    75b0bab069f4:	and    r11,r10
    75b0bab069f7:	movabs rsi,0xffffffff0fffffff
    75b0bab06a01:	and    rbx,rsi
    75b0bab06a04:	or     rbx,r11
    75b0bab06a07:	pop    r11
    75b0bab06a09:	pop    r10
    75b0bab06a0b:	pop    rsi
    75b0bab06a0c:	pop    rdx
    75b0bab06a0d:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab06a15:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab06a1b:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab06a20:	test   r10d,0x3f
    75b0bab06a27:	je     0x75b0bab06a4c
    75b0bab06a2d:	mov    r11d,r10d
    75b0bab06a30:	shr    r10d,1
    75b0bab06a33:	and    r10d,0x1e
    75b0bab06a37:	and    r11d,0x1
    75b0bab06a3b:	or     r10d,r11d
    75b0bab06a3e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab06a46:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab06a4c:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab06a52:	lea    rdi,[rsp+0x110]
    75b0bab06a5a:	lea    rsi,[rsp+0xf0]
    75b0bab06a62:	lea    rdx,[rsp+0x100]
    75b0bab06a6a:	mov    ecx,0x56
    75b0bab06a6f:	mov    r8d,0x0
    75b0bab06a75:	lea    r9,[r12+0x314]
    75b0bab06a7d:	movabs r11,0x59d8f4f27650
    75b0bab06a87:	call   r11
    75b0bab06a8a:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab06a90:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab06a96:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab06a9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab06aa2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab06aa8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab06aae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab06ab8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab06ac2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab06acc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab06ad6:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab06ade:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab06aea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab06af3:	mov    rdx,rbx
    75b0bab06af6:	shr    rdx,0x10
    75b0bab06afa:	and    edx,0xc000
    75b0bab06b00:	mov    rax,rbx
    75b0bab06b03:	shr    rax,0x15
    75b0bab06b07:	and    eax,0x100
    75b0bab06b0c:	xor    eax,0x100
    75b0bab06b11:	or     edx,eax
    75b0bab06b13:	mov    rax,rbx
    75b0bab06b16:	shr    rax,0x1c
    75b0bab06b1a:	and    eax,0x1
    75b0bab06b1d:	or     edx,eax
    75b0bab06b1f:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab06b24:	add    rsp,0x8
    75b0bab06b28:	ret
    75b0bab06b29:	nop    DWORD PTR [rax+0x0]
    75b0bab06b30:	sub    rsp,0x8
    75b0bab06b34:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab06b40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab06b46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab06b4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab06b52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab06b58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab06b5e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab06b64:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab06b6e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab06b78:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab06b82:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab06b8c:	push   rdx
    75b0bab06b8d:	push   rsi
    75b0bab06b8e:	push   r10
    75b0bab06b90:	push   r11
    75b0bab06b92:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab06b97:	mov    r10d,edx
    75b0bab06b9a:	and    r10d,0xc000
    75b0bab06ba1:	shl    r10d,0x10
    75b0bab06ba5:	mov    r11d,edx
    75b0bab06ba8:	and    r11d,0x100
    75b0bab06baf:	shl    r11d,0x15
    75b0bab06bb3:	or     r10d,r11d
    75b0bab06bb6:	and    edx,0x1
    75b0bab06bb9:	shl    edx,0x1c
    75b0bab06bbc:	or     r10d,edx
    75b0bab06bbf:	btc    r10,0x1d
    75b0bab06bc4:	mov    r11d,0xf0000000
    75b0bab06bca:	and    r11,r10
    75b0bab06bcd:	movabs rsi,0xffffffff0fffffff
    75b0bab06bd7:	and    rbx,rsi
    75b0bab06bda:	or     rbx,r11
    75b0bab06bdd:	pop    r11
    75b0bab06bdf:	pop    r10
    75b0bab06be1:	pop    rsi
    75b0bab06be2:	pop    rdx
    75b0bab06be3:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab06beb:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab06bf1:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab06bf6:	test   r10d,0x3f
    75b0bab06bfd:	je     0x75b0bab06c22
    75b0bab06c03:	mov    r11d,r10d
    75b0bab06c06:	shr    r10d,1
    75b0bab06c09:	and    r10d,0x1e
    75b0bab06c0d:	and    r11d,0x1
    75b0bab06c11:	or     r10d,r11d
    75b0bab06c14:	or     DWORD PTR [r12+0x314],r10d
    75b0bab06c1c:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab06c22:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab06c28:	lea    rdi,[rsp+0x110]
    75b0bab06c30:	lea    rsi,[rsp+0xf0]
    75b0bab06c38:	lea    rdx,[rsp+0x100]
    75b0bab06c40:	mov    ecx,0x56
    75b0bab06c45:	mov    r8d,0x0
    75b0bab06c4b:	lea    r9,[r12+0x314]
    75b0bab06c53:	movabs r11,0x59d8f4f27650
    75b0bab06c5d:	call   r11
    75b0bab06c60:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab06c66:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab06c6c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab06c72:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab06c78:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab06c7e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab06c84:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab06c8a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab06c94:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab06c9e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab06ca8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab06cb2:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab06cba:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab06cc6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab06ccf:	mov    rdx,rbx
    75b0bab06cd2:	shr    rdx,0x10
    75b0bab06cd6:	and    edx,0xc000
    75b0bab06cdc:	mov    rax,rbx
    75b0bab06cdf:	shr    rax,0x15
    75b0bab06ce3:	and    eax,0x100
    75b0bab06ce8:	xor    eax,0x100
    75b0bab06ced:	or     edx,eax
    75b0bab06cef:	mov    rax,rbx
    75b0bab06cf2:	shr    rax,0x1c
    75b0bab06cf6:	and    eax,0x1
    75b0bab06cf9:	or     edx,eax
    75b0bab06cfb:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab06d00:	add    rsp,0x8
    75b0bab06d04:	ret
    75b0bab06d05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab06d10:	sub    rsp,0x8
    75b0bab06d14:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab06d20:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab06d26:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab06d2c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab06d32:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab06d38:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab06d3e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab06d44:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab06d4e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab06d58:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab06d62:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab06d6c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab06d76:	push   rdx
    75b0bab06d77:	push   rsi
    75b0bab06d78:	push   r10
    75b0bab06d7a:	push   r11
    75b0bab06d7c:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab06d81:	mov    r10d,edx
    75b0bab06d84:	and    r10d,0xc000
    75b0bab06d8b:	shl    r10d,0x10
    75b0bab06d8f:	mov    r11d,edx
    75b0bab06d92:	and    r11d,0x100
    75b0bab06d99:	shl    r11d,0x15
    75b0bab06d9d:	or     r10d,r11d
    75b0bab06da0:	and    edx,0x1
    75b0bab06da3:	shl    edx,0x1c
    75b0bab06da6:	or     r10d,edx
    75b0bab06da9:	btc    r10,0x1d
    75b0bab06dae:	mov    r11d,0xf0000000
    75b0bab06db4:	and    r11,r10
    75b0bab06db7:	movabs rsi,0xffffffff0fffffff
    75b0bab06dc1:	and    rbx,rsi
    75b0bab06dc4:	or     rbx,r11
    75b0bab06dc7:	pop    r11
    75b0bab06dc9:	pop    r10
    75b0bab06dcb:	pop    rsi
    75b0bab06dcc:	pop    rdx
    75b0bab06dcd:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab06dd5:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab06ddb:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab06de0:	test   r10d,0x3f
    75b0bab06de7:	je     0x75b0bab06e0c
    75b0bab06ded:	mov    r11d,r10d
    75b0bab06df0:	shr    r10d,1
    75b0bab06df3:	and    r10d,0x1e
    75b0bab06df7:	and    r11d,0x1
    75b0bab06dfb:	or     r10d,r11d
    75b0bab06dfe:	or     DWORD PTR [r12+0x314],r10d
    75b0bab06e06:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab06e0c:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab06e12:	lea    rdi,[rsp+0x110]
    75b0bab06e1a:	lea    rsi,[rsp+0xf0]
    75b0bab06e22:	lea    rdx,[rsp+0x100]
    75b0bab06e2a:	mov    ecx,0x56
    75b0bab06e2f:	mov    r8d,0x0
    75b0bab06e35:	lea    r9,[r12+0x314]
    75b0bab06e3d:	movabs r11,0x59d8f4f27650
    75b0bab06e47:	call   r11
    75b0bab06e4a:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab06e50:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab06e56:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab06e5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab06e62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab06e68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab06e6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab06e74:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab06e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab06e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab06e92:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab06e9c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab06ea6:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab06eae:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab06eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab06ec3:	mov    rdx,rbx
    75b0bab06ec6:	shr    rdx,0x10
    75b0bab06eca:	and    edx,0xc000
    75b0bab06ed0:	mov    rax,rbx
    75b0bab06ed3:	shr    rax,0x15
    75b0bab06ed7:	and    eax,0x100
    75b0bab06edc:	xor    eax,0x100
    75b0bab06ee1:	or     edx,eax
    75b0bab06ee3:	mov    rax,rbx
    75b0bab06ee6:	shr    rax,0x1c
    75b0bab06eea:	and    eax,0x1
    75b0bab06eed:	or     edx,eax
    75b0bab06eef:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab06ef4:	add    rsp,0x8
    75b0bab06ef8:	ret
    75b0bab06ef9:	nop    DWORD PTR [rax+0x0]
    75b0bab06f00:	sub    rsp,0x8
    75b0bab06f04:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab06f10:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab06f16:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab06f1c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab06f22:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab06f28:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab06f32:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab06f3c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab06f46:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab06f50:	push   rdx
    75b0bab06f51:	push   rsi
    75b0bab06f52:	push   r10
    75b0bab06f54:	push   r11
    75b0bab06f56:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab06f5b:	mov    r10d,edx
    75b0bab06f5e:	and    r10d,0xc000
    75b0bab06f65:	shl    r10d,0x10
    75b0bab06f69:	mov    r11d,edx
    75b0bab06f6c:	and    r11d,0x100
    75b0bab06f73:	shl    r11d,0x15
    75b0bab06f77:	or     r10d,r11d
    75b0bab06f7a:	and    edx,0x1
    75b0bab06f7d:	shl    edx,0x1c
    75b0bab06f80:	or     r10d,edx
    75b0bab06f83:	btc    r10,0x1d
    75b0bab06f88:	mov    r11d,0xf0000000
    75b0bab06f8e:	and    r11,r10
    75b0bab06f91:	movabs rsi,0xffffffff0fffffff
    75b0bab06f9b:	and    rbx,rsi
    75b0bab06f9e:	or     rbx,r11
    75b0bab06fa1:	pop    r11
    75b0bab06fa3:	pop    r10
    75b0bab06fa5:	pop    rsi
    75b0bab06fa6:	pop    rdx
    75b0bab06fa7:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab06faf:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab06fb5:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab06fba:	test   r10d,0x3f
    75b0bab06fc1:	je     0x75b0bab06fe6
    75b0bab06fc7:	mov    r11d,r10d
    75b0bab06fca:	shr    r10d,1
    75b0bab06fcd:	and    r10d,0x1e
    75b0bab06fd1:	and    r11d,0x1
    75b0bab06fd5:	or     r10d,r11d
    75b0bab06fd8:	or     DWORD PTR [r12+0x314],r10d
    75b0bab06fe0:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab06fe6:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab06fec:	lea    rdi,[rsp+0x110]
    75b0bab06ff4:	lea    rsi,[rsp+0xf0]
    75b0bab06ffc:	lea    rdx,[rsp+0x100]
    75b0bab07004:	mov    ecx,0x56
    75b0bab07009:	mov    r8d,0x0
    75b0bab0700f:	lea    r9,[r12+0x314]
    75b0bab07017:	movabs r11,0x59d8f4f27650
    75b0bab07021:	call   r11
    75b0bab07024:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0702a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab07030:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab07036:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0703c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab07042:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab0704c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab07056:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab07060:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0706a:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab07072:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0707e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab07087:	mov    rdx,rbx
    75b0bab0708a:	shr    rdx,0x10
    75b0bab0708e:	and    edx,0xc000
    75b0bab07094:	mov    rax,rbx
    75b0bab07097:	shr    rax,0x15
    75b0bab0709b:	and    eax,0x100
    75b0bab070a0:	xor    eax,0x100
    75b0bab070a5:	or     edx,eax
    75b0bab070a7:	mov    rax,rbx
    75b0bab070aa:	shr    rax,0x1c
    75b0bab070ae:	and    eax,0x1
    75b0bab070b1:	or     edx,eax
    75b0bab070b3:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab070b8:	add    rsp,0x8
    75b0bab070bc:	ret
    75b0bab070bd:	nop    DWORD PTR [rax]
    75b0bab070c0:	sub    rsp,0x8
    75b0bab070c4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab070d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab070d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab070dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab070e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab070e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab070ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab070f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab07102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab0710c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab07116:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab07120:	push   rdx
    75b0bab07121:	push   rsi
    75b0bab07122:	push   r10
    75b0bab07124:	push   r11
    75b0bab07126:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0712b:	mov    r10d,edx
    75b0bab0712e:	and    r10d,0xc000
    75b0bab07135:	shl    r10d,0x10
    75b0bab07139:	mov    r11d,edx
    75b0bab0713c:	and    r11d,0x100
    75b0bab07143:	shl    r11d,0x15
    75b0bab07147:	or     r10d,r11d
    75b0bab0714a:	and    edx,0x1
    75b0bab0714d:	shl    edx,0x1c
    75b0bab07150:	or     r10d,edx
    75b0bab07153:	btc    r10,0x1d
    75b0bab07158:	mov    r11d,0xf0000000
    75b0bab0715e:	and    r11,r10
    75b0bab07161:	movabs rsi,0xffffffff0fffffff
    75b0bab0716b:	and    rbx,rsi
    75b0bab0716e:	or     rbx,r11
    75b0bab07171:	pop    r11
    75b0bab07173:	pop    r10
    75b0bab07175:	pop    rsi
    75b0bab07176:	pop    rdx
    75b0bab07177:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0717f:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab07185:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0718a:	test   r10d,0x3f
    75b0bab07191:	je     0x75b0bab071b6
    75b0bab07197:	mov    r11d,r10d
    75b0bab0719a:	shr    r10d,1
    75b0bab0719d:	and    r10d,0x1e
    75b0bab071a1:	and    r11d,0x1
    75b0bab071a5:	or     r10d,r11d
    75b0bab071a8:	or     DWORD PTR [r12+0x314],r10d
    75b0bab071b0:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab071b6:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab071bc:	lea    rdi,[rsp+0x110]
    75b0bab071c4:	lea    rsi,[rsp+0xf0]
    75b0bab071cc:	lea    rdx,[rsp+0x100]
    75b0bab071d4:	mov    ecx,0x14
    75b0bab071d9:	mov    r8d,0x0
    75b0bab071df:	lea    r9,[r12+0x314]
    75b0bab071e7:	movabs r11,0x59d8f4f27650
    75b0bab071f1:	call   r11
    75b0bab071f4:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab071fa:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab07200:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab07206:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0720c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab07212:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab07218:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab07222:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0722c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab07236:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab07240:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab0724a:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab07252:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0725e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab07267:	mov    rdx,rbx
    75b0bab0726a:	shr    rdx,0x10
    75b0bab0726e:	and    edx,0xc000
    75b0bab07274:	mov    rax,rbx
    75b0bab07277:	shr    rax,0x15
    75b0bab0727b:	and    eax,0x100
    75b0bab07280:	xor    eax,0x100
    75b0bab07285:	or     edx,eax
    75b0bab07287:	mov    rax,rbx
    75b0bab0728a:	shr    rax,0x1c
    75b0bab0728e:	and    eax,0x1
    75b0bab07291:	or     edx,eax
    75b0bab07293:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab07298:	add    rsp,0x8
    75b0bab0729c:	ret
    75b0bab0729d:	nop    DWORD PTR [rax]
    75b0bab072a0:	sub    rsp,0x8
    75b0bab072a4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab072b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab072b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab072bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab072c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab072c8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab072ce:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab072d8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab072e2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab072ec:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab072f6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab07300:	push   rdx
    75b0bab07301:	push   rsi
    75b0bab07302:	push   r10
    75b0bab07304:	push   r11
    75b0bab07306:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0730b:	mov    r10d,edx
    75b0bab0730e:	and    r10d,0xc000
    75b0bab07315:	shl    r10d,0x10
    75b0bab07319:	mov    r11d,edx
    75b0bab0731c:	and    r11d,0x100
    75b0bab07323:	shl    r11d,0x15
    75b0bab07327:	or     r10d,r11d
    75b0bab0732a:	and    edx,0x1
    75b0bab0732d:	shl    edx,0x1c
    75b0bab07330:	or     r10d,edx
    75b0bab07333:	btc    r10,0x1d
    75b0bab07338:	mov    r11d,0xf0000000
    75b0bab0733e:	and    r11,r10
    75b0bab07341:	movabs rsi,0xffffffff0fffffff
    75b0bab0734b:	and    rbx,rsi
    75b0bab0734e:	or     rbx,r11
    75b0bab07351:	pop    r11
    75b0bab07353:	pop    r10
    75b0bab07355:	pop    rsi
    75b0bab07356:	pop    rdx
    75b0bab07357:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0735f:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab07365:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0736a:	test   r10d,0x3f
    75b0bab07371:	je     0x75b0bab07396
    75b0bab07377:	mov    r11d,r10d
    75b0bab0737a:	shr    r10d,1
    75b0bab0737d:	and    r10d,0x1e
    75b0bab07381:	and    r11d,0x1
    75b0bab07385:	or     r10d,r11d
    75b0bab07388:	or     DWORD PTR [r12+0x314],r10d
    75b0bab07390:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab07396:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0739c:	lea    rdi,[rsp+0x110]
    75b0bab073a4:	lea    rsi,[rsp+0xf0]
    75b0bab073ac:	lea    rdx,[rsp+0x100]
    75b0bab073b4:	mov    ecx,0x56
    75b0bab073b9:	mov    r8d,0x0
    75b0bab073bf:	lea    r9,[r12+0x314]
    75b0bab073c7:	movabs r11,0x59d8f4f27650
    75b0bab073d1:	call   r11
    75b0bab073d4:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab073da:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab073e0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab073e6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab073ec:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab073f2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab073f8:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab07402:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0740c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab07416:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab07420:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab0742a:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab07432:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0743e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab07447:	mov    rdx,rbx
    75b0bab0744a:	shr    rdx,0x10
    75b0bab0744e:	and    edx,0xc000
    75b0bab07454:	mov    rax,rbx
    75b0bab07457:	shr    rax,0x15
    75b0bab0745b:	and    eax,0x100
    75b0bab07460:	xor    eax,0x100
    75b0bab07465:	or     edx,eax
    75b0bab07467:	mov    rax,rbx
    75b0bab0746a:	shr    rax,0x1c
    75b0bab0746e:	and    eax,0x1
    75b0bab07471:	or     edx,eax
    75b0bab07473:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab07478:	add    rsp,0x8
    75b0bab0747c:	ret
    75b0bab0747d:	nop    DWORD PTR [rax]
    75b0bab07480:	sub    rsp,0x8
    75b0bab07484:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab07490:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab07496:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0749c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab074a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab074a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab074ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab074b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab074be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab074c8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab074d2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab074dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab074e6:	push   rdx
    75b0bab074e7:	push   rsi
    75b0bab074e8:	push   r10
    75b0bab074ea:	push   r11
    75b0bab074ec:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab074f1:	mov    r10d,edx
    75b0bab074f4:	and    r10d,0xc000
    75b0bab074fb:	shl    r10d,0x10
    75b0bab074ff:	mov    r11d,edx
    75b0bab07502:	and    r11d,0x100
    75b0bab07509:	shl    r11d,0x15
    75b0bab0750d:	or     r10d,r11d
    75b0bab07510:	and    edx,0x1
    75b0bab07513:	shl    edx,0x1c
    75b0bab07516:	or     r10d,edx
    75b0bab07519:	btc    r10,0x1d
    75b0bab0751e:	mov    r11d,0xf0000000
    75b0bab07524:	and    r11,r10
    75b0bab07527:	movabs rsi,0xffffffff0fffffff
    75b0bab07531:	and    rbx,rsi
    75b0bab07534:	or     rbx,r11
    75b0bab07537:	pop    r11
    75b0bab07539:	pop    r10
    75b0bab0753b:	pop    rsi
    75b0bab0753c:	pop    rdx
    75b0bab0753d:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab07545:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0754b:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab07550:	test   r10d,0x3f
    75b0bab07557:	je     0x75b0bab0757c
    75b0bab0755d:	mov    r11d,r10d
    75b0bab07560:	shr    r10d,1
    75b0bab07563:	and    r10d,0x1e
    75b0bab07567:	and    r11d,0x1
    75b0bab0756b:	or     r10d,r11d
    75b0bab0756e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab07576:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0757c:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab07582:	lea    rdi,[rsp+0x110]
    75b0bab0758a:	lea    rsi,[rsp+0xf0]
    75b0bab07592:	lea    rdx,[rsp+0x100]
    75b0bab0759a:	mov    ecx,0x14
    75b0bab0759f:	mov    r8d,0x0
    75b0bab075a5:	lea    r9,[r12+0x314]
    75b0bab075ad:	movabs r11,0x59d8f4f27650
    75b0bab075b7:	call   r11
    75b0bab075ba:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab075c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab075c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab075cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab075d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab075d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab075de:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab075e4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab075ee:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab075f8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab07602:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0760c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab07616:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0761e:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0762a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab07633:	mov    rdx,rbx
    75b0bab07636:	shr    rdx,0x10
    75b0bab0763a:	and    edx,0xc000
    75b0bab07640:	mov    rax,rbx
    75b0bab07643:	shr    rax,0x15
    75b0bab07647:	and    eax,0x100
    75b0bab0764c:	xor    eax,0x100
    75b0bab07651:	or     edx,eax
    75b0bab07653:	mov    rax,rbx
    75b0bab07656:	shr    rax,0x1c
    75b0bab0765a:	and    eax,0x1
    75b0bab0765d:	or     edx,eax
    75b0bab0765f:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab07664:	add    rsp,0x8
    75b0bab07668:	ret
    75b0bab07669:	nop    DWORD PTR [rax+0x0]
    75b0bab07670:	sub    rsp,0x8
    75b0bab07674:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab07680:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab07686:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0768c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab07692:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab07698:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0769e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab076a4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab076ae:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab076b8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab076c2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab076cc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab076d6:	push   rdx
    75b0bab076d7:	push   rsi
    75b0bab076d8:	push   r10
    75b0bab076da:	push   r11
    75b0bab076dc:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab076e1:	mov    r10d,edx
    75b0bab076e4:	and    r10d,0xc000
    75b0bab076eb:	shl    r10d,0x10
    75b0bab076ef:	mov    r11d,edx
    75b0bab076f2:	and    r11d,0x100
    75b0bab076f9:	shl    r11d,0x15
    75b0bab076fd:	or     r10d,r11d
    75b0bab07700:	and    edx,0x1
    75b0bab07703:	shl    edx,0x1c
    75b0bab07706:	or     r10d,edx
    75b0bab07709:	btc    r10,0x1d
    75b0bab0770e:	mov    r11d,0xf0000000
    75b0bab07714:	and    r11,r10
    75b0bab07717:	movabs rsi,0xffffffff0fffffff
    75b0bab07721:	and    rbx,rsi
    75b0bab07724:	or     rbx,r11
    75b0bab07727:	pop    r11
    75b0bab07729:	pop    r10
    75b0bab0772b:	pop    rsi
    75b0bab0772c:	pop    rdx
    75b0bab0772d:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab07735:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0773b:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab07740:	test   r10d,0x3f
    75b0bab07747:	je     0x75b0bab0776c
    75b0bab0774d:	mov    r11d,r10d
    75b0bab07750:	shr    r10d,1
    75b0bab07753:	and    r10d,0x1e
    75b0bab07757:	and    r11d,0x1
    75b0bab0775b:	or     r10d,r11d
    75b0bab0775e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab07766:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0776c:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab07772:	lea    rdi,[rsp+0x110]
    75b0bab0777a:	lea    rsi,[rsp+0xf0]
    75b0bab07782:	lea    rdx,[rsp+0x100]
    75b0bab0778a:	mov    ecx,0x14
    75b0bab0778f:	mov    r8d,0x0
    75b0bab07795:	lea    r9,[r12+0x314]
    75b0bab0779d:	movabs r11,0x59d8f4f27650
    75b0bab077a7:	call   r11
    75b0bab077aa:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab077b0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab077b6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab077bc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab077c2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab077c8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab077ce:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab077d4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab077de:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab077e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab077f2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab077fc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab07806:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0780e:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0781a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab07823:	mov    rdx,rbx
    75b0bab07826:	shr    rdx,0x10
    75b0bab0782a:	and    edx,0xc000
    75b0bab07830:	mov    rax,rbx
    75b0bab07833:	shr    rax,0x15
    75b0bab07837:	and    eax,0x100
    75b0bab0783c:	xor    eax,0x100
    75b0bab07841:	or     edx,eax
    75b0bab07843:	mov    rax,rbx
    75b0bab07846:	shr    rax,0x1c
    75b0bab0784a:	and    eax,0x1
    75b0bab0784d:	or     edx,eax
    75b0bab0784f:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab07854:	add    rsp,0x8
    75b0bab07858:	ret
    75b0bab07859:	nop    DWORD PTR [rax+0x0]
    75b0bab07860:	sub    rsp,0x8
    75b0bab07864:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab07870:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab07876:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0787c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab07882:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab07888:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0788e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab07894:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab0789e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab078a8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab078b2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab078bc:	push   rdx
    75b0bab078bd:	push   rsi
    75b0bab078be:	push   r10
    75b0bab078c0:	push   r11
    75b0bab078c2:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab078c7:	mov    r10d,edx
    75b0bab078ca:	and    r10d,0xc000
    75b0bab078d1:	shl    r10d,0x10
    75b0bab078d5:	mov    r11d,edx
    75b0bab078d8:	and    r11d,0x100
    75b0bab078df:	shl    r11d,0x15
    75b0bab078e3:	or     r10d,r11d
    75b0bab078e6:	and    edx,0x1
    75b0bab078e9:	shl    edx,0x1c
    75b0bab078ec:	or     r10d,edx
    75b0bab078ef:	btc    r10,0x1d
    75b0bab078f4:	mov    r11d,0xf0000000
    75b0bab078fa:	and    r11,r10
    75b0bab078fd:	movabs rsi,0xffffffff0fffffff
    75b0bab07907:	and    rbx,rsi
    75b0bab0790a:	or     rbx,r11
    75b0bab0790d:	pop    r11
    75b0bab0790f:	pop    r10
    75b0bab07911:	pop    rsi
    75b0bab07912:	pop    rdx
    75b0bab07913:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0791b:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab07921:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab07926:	test   r10d,0x3f
    75b0bab0792d:	je     0x75b0bab07952
    75b0bab07933:	mov    r11d,r10d
    75b0bab07936:	shr    r10d,1
    75b0bab07939:	and    r10d,0x1e
    75b0bab0793d:	and    r11d,0x1
    75b0bab07941:	or     r10d,r11d
    75b0bab07944:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0794c:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab07952:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab07958:	lea    rdi,[rsp+0x110]
    75b0bab07960:	lea    rsi,[rsp+0xf0]
    75b0bab07968:	lea    rdx,[rsp+0x100]
    75b0bab07970:	mov    ecx,0x56
    75b0bab07975:	mov    r8d,0x0
    75b0bab0797b:	lea    r9,[r12+0x314]
    75b0bab07983:	movabs r11,0x59d8f4f27650
    75b0bab0798d:	call   r11
    75b0bab07990:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab07996:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0799c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab079a2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab079a8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab079ae:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab079b4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab079ba:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab079c4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab079ce:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab079d8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab079e2:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab079ea:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab079f6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab079ff:	mov    rdx,rbx
    75b0bab07a02:	shr    rdx,0x10
    75b0bab07a06:	and    edx,0xc000
    75b0bab07a0c:	mov    rax,rbx
    75b0bab07a0f:	shr    rax,0x15
    75b0bab07a13:	and    eax,0x100
    75b0bab07a18:	xor    eax,0x100
    75b0bab07a1d:	or     edx,eax
    75b0bab07a1f:	mov    rax,rbx
    75b0bab07a22:	shr    rax,0x1c
    75b0bab07a26:	and    eax,0x1
    75b0bab07a29:	or     edx,eax
    75b0bab07a2b:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab07a30:	add    rsp,0x8
    75b0bab07a34:	ret
    75b0bab07a35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab07a40:	sub    rsp,0x8
    75b0bab07a44:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab07a50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab07a56:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab07a5c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab07a62:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab07a68:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab07a6e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab07a74:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab07a7e:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab07a88:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab07a92:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab07a9c:	push   rdx
    75b0bab07a9d:	push   rsi
    75b0bab07a9e:	push   r10
    75b0bab07aa0:	push   r11
    75b0bab07aa2:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab07aa7:	mov    r10d,edx
    75b0bab07aaa:	and    r10d,0xc000
    75b0bab07ab1:	shl    r10d,0x10
    75b0bab07ab5:	mov    r11d,edx
    75b0bab07ab8:	and    r11d,0x100
    75b0bab07abf:	shl    r11d,0x15
    75b0bab07ac3:	or     r10d,r11d
    75b0bab07ac6:	and    edx,0x1
    75b0bab07ac9:	shl    edx,0x1c
    75b0bab07acc:	or     r10d,edx
    75b0bab07acf:	btc    r10,0x1d
    75b0bab07ad4:	mov    r11d,0xf0000000
    75b0bab07ada:	and    r11,r10
    75b0bab07add:	movabs rsi,0xffffffff0fffffff
    75b0bab07ae7:	and    rbx,rsi
    75b0bab07aea:	or     rbx,r11
    75b0bab07aed:	pop    r11
    75b0bab07aef:	pop    r10
    75b0bab07af1:	pop    rsi
    75b0bab07af2:	pop    rdx
    75b0bab07af3:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab07afb:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab07b01:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab07b06:	test   r10d,0x3f
    75b0bab07b0d:	je     0x75b0bab07b32
    75b0bab07b13:	mov    r11d,r10d
    75b0bab07b16:	shr    r10d,1
    75b0bab07b19:	and    r10d,0x1e
    75b0bab07b1d:	and    r11d,0x1
    75b0bab07b21:	or     r10d,r11d
    75b0bab07b24:	or     DWORD PTR [r12+0x314],r10d
    75b0bab07b2c:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab07b32:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab07b38:	lea    rdi,[rsp+0x110]
    75b0bab07b40:	lea    rsi,[rsp+0xf0]
    75b0bab07b48:	lea    rdx,[rsp+0x100]
    75b0bab07b50:	mov    ecx,0x14
    75b0bab07b55:	mov    r8d,0x0
    75b0bab07b5b:	lea    r9,[r12+0x314]
    75b0bab07b63:	movabs r11,0x59d8f4f27650
    75b0bab07b6d:	call   r11
    75b0bab07b70:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab07b76:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab07b7c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab07b82:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab07b88:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab07b8e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab07b94:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab07b9a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab07ba4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab07bae:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab07bb8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab07bc2:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab07bca:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab07bd6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab07bdf:	mov    rdx,rbx
    75b0bab07be2:	shr    rdx,0x10
    75b0bab07be6:	and    edx,0xc000
    75b0bab07bec:	mov    rax,rbx
    75b0bab07bef:	shr    rax,0x15
    75b0bab07bf3:	and    eax,0x100
    75b0bab07bf8:	xor    eax,0x100
    75b0bab07bfd:	or     edx,eax
    75b0bab07bff:	mov    rax,rbx
    75b0bab07c02:	shr    rax,0x1c
    75b0bab07c06:	and    eax,0x1
    75b0bab07c09:	or     edx,eax
    75b0bab07c0b:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab07c10:	add    rsp,0x8
    75b0bab07c14:	ret
    75b0bab07c15:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab07c20:	sub    rsp,0x8
    75b0bab07c24:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab07c30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab07c36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab07c3c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab07c42:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab07c48:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab07c4e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab07c58:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab07c62:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab07c6c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab07c76:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab07c80:	push   rdx
    75b0bab07c81:	push   rsi
    75b0bab07c82:	push   r10
    75b0bab07c84:	push   r11
    75b0bab07c86:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab07c8b:	mov    r10d,edx
    75b0bab07c8e:	and    r10d,0xc000
    75b0bab07c95:	shl    r10d,0x10
    75b0bab07c99:	mov    r11d,edx
    75b0bab07c9c:	and    r11d,0x100
    75b0bab07ca3:	shl    r11d,0x15
    75b0bab07ca7:	or     r10d,r11d
    75b0bab07caa:	and    edx,0x1
    75b0bab07cad:	shl    edx,0x1c
    75b0bab07cb0:	or     r10d,edx
    75b0bab07cb3:	btc    r10,0x1d
    75b0bab07cb8:	mov    r11d,0xf0000000
    75b0bab07cbe:	and    r11,r10
    75b0bab07cc1:	movabs rsi,0xffffffff0fffffff
    75b0bab07ccb:	and    rbx,rsi
    75b0bab07cce:	or     rbx,r11
    75b0bab07cd1:	pop    r11
    75b0bab07cd3:	pop    r10
    75b0bab07cd5:	pop    rsi
    75b0bab07cd6:	pop    rdx
    75b0bab07cd7:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab07cdf:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab07ce5:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab07cea:	test   r10d,0x3f
    75b0bab07cf1:	je     0x75b0bab07d16
    75b0bab07cf7:	mov    r11d,r10d
    75b0bab07cfa:	shr    r10d,1
    75b0bab07cfd:	and    r10d,0x1e
    75b0bab07d01:	and    r11d,0x1
    75b0bab07d05:	or     r10d,r11d
    75b0bab07d08:	or     DWORD PTR [r12+0x314],r10d
    75b0bab07d10:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab07d16:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab07d1c:	lea    rdi,[rsp+0x110]
    75b0bab07d24:	lea    rsi,[rsp+0xf0]
    75b0bab07d2c:	lea    rdx,[rsp+0x100]
    75b0bab07d34:	mov    ecx,0x56
    75b0bab07d39:	mov    r8d,0x0
    75b0bab07d3f:	lea    r9,[r12+0x314]
    75b0bab07d47:	movabs r11,0x59d8f4f27650
    75b0bab07d51:	call   r11
    75b0bab07d54:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab07d5a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab07d60:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab07d66:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab07d6c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab07d72:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab07d78:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab07d82:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab07d8c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab07d96:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab07da0:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab07daa:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab07db2:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab07dbe:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab07dc7:	mov    rdx,rbx
    75b0bab07dca:	shr    rdx,0x10
    75b0bab07dce:	and    edx,0xc000
    75b0bab07dd4:	mov    rax,rbx
    75b0bab07dd7:	shr    rax,0x15
    75b0bab07ddb:	and    eax,0x100
    75b0bab07de0:	xor    eax,0x100
    75b0bab07de5:	or     edx,eax
    75b0bab07de7:	mov    rax,rbx
    75b0bab07dea:	shr    rax,0x1c
    75b0bab07dee:	and    eax,0x1
    75b0bab07df1:	or     edx,eax
    75b0bab07df3:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab07df8:	add    rsp,0x8
    75b0bab07dfc:	ret
    75b0bab07dfd:	nop    DWORD PTR [rax]
    75b0bab07e00:	sub    rsp,0x8
    75b0bab07e04:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab07e10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab07e16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab07e1c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab07e22:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab07e28:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab07e2e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab07e34:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab07e3e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab07e48:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab07e52:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab07e5c:	push   rdx
    75b0bab07e5d:	push   rsi
    75b0bab07e5e:	push   r10
    75b0bab07e60:	push   r11
    75b0bab07e62:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab07e67:	mov    r10d,edx
    75b0bab07e6a:	and    r10d,0xc000
    75b0bab07e71:	shl    r10d,0x10
    75b0bab07e75:	mov    r11d,edx
    75b0bab07e78:	and    r11d,0x100
    75b0bab07e7f:	shl    r11d,0x15
    75b0bab07e83:	or     r10d,r11d
    75b0bab07e86:	and    edx,0x1
    75b0bab07e89:	shl    edx,0x1c
    75b0bab07e8c:	or     r10d,edx
    75b0bab07e8f:	btc    r10,0x1d
    75b0bab07e94:	mov    r11d,0xf0000000
    75b0bab07e9a:	and    r11,r10
    75b0bab07e9d:	movabs rsi,0xffffffff0fffffff
    75b0bab07ea7:	and    rbx,rsi
    75b0bab07eaa:	or     rbx,r11
    75b0bab07ead:	pop    r11
    75b0bab07eaf:	pop    r10
    75b0bab07eb1:	pop    rsi
    75b0bab07eb2:	pop    rdx
    75b0bab07eb3:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab07ebb:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab07ec1:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab07ec6:	test   r10d,0x3f
    75b0bab07ecd:	je     0x75b0bab07ef2
    75b0bab07ed3:	mov    r11d,r10d
    75b0bab07ed6:	shr    r10d,1
    75b0bab07ed9:	and    r10d,0x1e
    75b0bab07edd:	and    r11d,0x1
    75b0bab07ee1:	or     r10d,r11d
    75b0bab07ee4:	or     DWORD PTR [r12+0x314],r10d
    75b0bab07eec:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab07ef2:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab07ef8:	lea    rdi,[rsp+0x110]
    75b0bab07f00:	lea    rsi,[rsp+0xf0]
    75b0bab07f08:	lea    rdx,[rsp+0x100]
    75b0bab07f10:	mov    ecx,0x56
    75b0bab07f15:	mov    r8d,0x0
    75b0bab07f1b:	lea    r9,[r12+0x314]
    75b0bab07f23:	movabs r11,0x59d8f4f27650
    75b0bab07f2d:	call   r11
    75b0bab07f30:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab07f36:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab07f3c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab07f42:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab07f48:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab07f4e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab07f54:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab07f5a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab07f64:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab07f6e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab07f78:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab07f82:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab07f8a:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab07f96:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab07f9f:	mov    rdx,rbx
    75b0bab07fa2:	shr    rdx,0x10
    75b0bab07fa6:	and    edx,0xc000
    75b0bab07fac:	mov    rax,rbx
    75b0bab07faf:	shr    rax,0x15
    75b0bab07fb3:	and    eax,0x100
    75b0bab07fb8:	xor    eax,0x100
    75b0bab07fbd:	or     edx,eax
    75b0bab07fbf:	mov    rax,rbx
    75b0bab07fc2:	shr    rax,0x1c
    75b0bab07fc6:	and    eax,0x1
    75b0bab07fc9:	or     edx,eax
    75b0bab07fcb:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab07fd0:	add    rsp,0x8
    75b0bab07fd4:	ret
    75b0bab07fd5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab07fe0:	sub    rsp,0x8
    75b0bab07fe4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab07ff0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab07ff6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab07ffc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab08002:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab08008:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0800e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab08014:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab0801e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab08028:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab08032:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab0803c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab08046:	push   rdx
    75b0bab08047:	push   rsi
    75b0bab08048:	push   r10
    75b0bab0804a:	push   r11
    75b0bab0804c:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab08051:	mov    r10d,edx
    75b0bab08054:	and    r10d,0xc000
    75b0bab0805b:	shl    r10d,0x10
    75b0bab0805f:	mov    r11d,edx
    75b0bab08062:	and    r11d,0x100
    75b0bab08069:	shl    r11d,0x15
    75b0bab0806d:	or     r10d,r11d
    75b0bab08070:	and    edx,0x1
    75b0bab08073:	shl    edx,0x1c
    75b0bab08076:	or     r10d,edx
    75b0bab08079:	btc    r10,0x1d
    75b0bab0807e:	mov    r11d,0xf0000000
    75b0bab08084:	and    r11,r10
    75b0bab08087:	movabs rsi,0xffffffff0fffffff
    75b0bab08091:	and    rbx,rsi
    75b0bab08094:	or     rbx,r11
    75b0bab08097:	pop    r11
    75b0bab08099:	pop    r10
    75b0bab0809b:	pop    rsi
    75b0bab0809c:	pop    rdx
    75b0bab0809d:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab080a5:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab080ab:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab080b0:	test   r10d,0x3f
    75b0bab080b7:	je     0x75b0bab080dc
    75b0bab080bd:	mov    r11d,r10d
    75b0bab080c0:	shr    r10d,1
    75b0bab080c3:	and    r10d,0x1e
    75b0bab080c7:	and    r11d,0x1
    75b0bab080cb:	or     r10d,r11d
    75b0bab080ce:	or     DWORD PTR [r12+0x314],r10d
    75b0bab080d6:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab080dc:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab080e2:	lea    rdi,[rsp+0x110]
    75b0bab080ea:	lea    rsi,[rsp+0xf0]
    75b0bab080f2:	lea    rdx,[rsp+0x100]
    75b0bab080fa:	mov    ecx,0x14
    75b0bab080ff:	mov    r8d,0x0
    75b0bab08105:	lea    r9,[r12+0x314]
    75b0bab0810d:	movabs r11,0x59d8f4f27650
    75b0bab08117:	call   r11
    75b0bab0811a:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab08120:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab08126:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0812c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab08132:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab08138:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0813e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab08144:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0814e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab08158:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab08162:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0816c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab08176:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0817e:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0818a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab08193:	mov    rdx,rbx
    75b0bab08196:	shr    rdx,0x10
    75b0bab0819a:	and    edx,0xc000
    75b0bab081a0:	mov    rax,rbx
    75b0bab081a3:	shr    rax,0x15
    75b0bab081a7:	and    eax,0x100
    75b0bab081ac:	xor    eax,0x100
    75b0bab081b1:	or     edx,eax
    75b0bab081b3:	mov    rax,rbx
    75b0bab081b6:	shr    rax,0x1c
    75b0bab081ba:	and    eax,0x1
    75b0bab081bd:	or     edx,eax
    75b0bab081bf:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab081c4:	add    rsp,0x8
    75b0bab081c8:	ret
    75b0bab081c9:	nop    DWORD PTR [rax+0x0]
    75b0bab081d0:	sub    rsp,0x8
    75b0bab081d4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab081e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab081e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab081ec:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab081f2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab081f8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab08202:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab0820c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab08216:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab08220:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab0822a:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab08234:	push   rdx
    75b0bab08235:	push   rsi
    75b0bab08236:	push   r10
    75b0bab08238:	push   r11
    75b0bab0823a:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0823f:	mov    r10d,edx
    75b0bab08242:	and    r10d,0xc000
    75b0bab08249:	shl    r10d,0x10
    75b0bab0824d:	mov    r11d,edx
    75b0bab08250:	and    r11d,0x100
    75b0bab08257:	shl    r11d,0x15
    75b0bab0825b:	or     r10d,r11d
    75b0bab0825e:	and    edx,0x1
    75b0bab08261:	shl    edx,0x1c
    75b0bab08264:	or     r10d,edx
    75b0bab08267:	btc    r10,0x1d
    75b0bab0826c:	mov    r11d,0xf0000000
    75b0bab08272:	and    r11,r10
    75b0bab08275:	movabs rsi,0xffffffff0fffffff
    75b0bab0827f:	and    rbx,rsi
    75b0bab08282:	or     rbx,r11
    75b0bab08285:	pop    r11
    75b0bab08287:	pop    r10
    75b0bab08289:	pop    rsi
    75b0bab0828a:	pop    rdx
    75b0bab0828b:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab08293:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab08299:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0829e:	test   r10d,0x3f
    75b0bab082a5:	je     0x75b0bab082ca
    75b0bab082ab:	mov    r11d,r10d
    75b0bab082ae:	shr    r10d,1
    75b0bab082b1:	and    r10d,0x1e
    75b0bab082b5:	and    r11d,0x1
    75b0bab082b9:	or     r10d,r11d
    75b0bab082bc:	or     DWORD PTR [r12+0x314],r10d
    75b0bab082c4:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab082ca:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab082d0:	lea    rdi,[rsp+0x110]
    75b0bab082d8:	lea    rsi,[rsp+0xf0]
    75b0bab082e0:	lea    rdx,[rsp+0x100]
    75b0bab082e8:	mov    ecx,0x56
    75b0bab082ed:	mov    r8d,0x0
    75b0bab082f3:	lea    r9,[r12+0x314]
    75b0bab082fb:	movabs r11,0x59d8f4f27650
    75b0bab08305:	call   r11
    75b0bab08308:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0830e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab08314:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0831a:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab08320:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab08326:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab08330:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0833a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab08344:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab0834e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab08358:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab08362:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0836a:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab08376:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0837f:	mov    rdx,rbx
    75b0bab08382:	shr    rdx,0x10
    75b0bab08386:	and    edx,0xc000
    75b0bab0838c:	mov    rax,rbx
    75b0bab0838f:	shr    rax,0x15
    75b0bab08393:	and    eax,0x100
    75b0bab08398:	xor    eax,0x100
    75b0bab0839d:	or     edx,eax
    75b0bab0839f:	mov    rax,rbx
    75b0bab083a2:	shr    rax,0x1c
    75b0bab083a6:	and    eax,0x1
    75b0bab083a9:	or     edx,eax
    75b0bab083ab:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab083b0:	add    rsp,0x8
    75b0bab083b4:	ret
    75b0bab083b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab083c0:	sub    rsp,0x8
    75b0bab083c4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab083d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab083d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab083dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab083e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab083e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab083ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab083f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab08402:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0840c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab08416:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab08420:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab0842a:	push   rdx
    75b0bab0842b:	push   rsi
    75b0bab0842c:	push   r10
    75b0bab0842e:	push   r11
    75b0bab08430:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab08435:	mov    r10d,edx
    75b0bab08438:	and    r10d,0xc000
    75b0bab0843f:	shl    r10d,0x10
    75b0bab08443:	mov    r11d,edx
    75b0bab08446:	and    r11d,0x100
    75b0bab0844d:	shl    r11d,0x15
    75b0bab08451:	or     r10d,r11d
    75b0bab08454:	and    edx,0x1
    75b0bab08457:	shl    edx,0x1c
    75b0bab0845a:	or     r10d,edx
    75b0bab0845d:	btc    r10,0x1d
    75b0bab08462:	mov    r11d,0xf0000000
    75b0bab08468:	and    r11,r10
    75b0bab0846b:	movabs rsi,0xffffffff0fffffff
    75b0bab08475:	and    rbx,rsi
    75b0bab08478:	or     rbx,r11
    75b0bab0847b:	pop    r11
    75b0bab0847d:	pop    r10
    75b0bab0847f:	pop    rsi
    75b0bab08480:	pop    rdx
    75b0bab08481:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab08489:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0848f:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab08494:	test   r10d,0x3f
    75b0bab0849b:	je     0x75b0bab084c0
    75b0bab084a1:	mov    r11d,r10d
    75b0bab084a4:	shr    r10d,1
    75b0bab084a7:	and    r10d,0x1e
    75b0bab084ab:	and    r11d,0x1
    75b0bab084af:	or     r10d,r11d
    75b0bab084b2:	or     DWORD PTR [r12+0x314],r10d
    75b0bab084ba:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab084c0:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab084c6:	lea    rdi,[rsp+0x110]
    75b0bab084ce:	lea    rsi,[rsp+0xf0]
    75b0bab084d6:	lea    rdx,[rsp+0x100]
    75b0bab084de:	mov    ecx,0x14
    75b0bab084e3:	mov    r8d,0x0
    75b0bab084e9:	lea    r9,[r12+0x314]
    75b0bab084f1:	movabs r11,0x59d8f4f27650
    75b0bab084fb:	call   r11
    75b0bab084fe:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab08504:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0850a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab08510:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab08516:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0851c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab08522:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab0852c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab08536:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab08540:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab0854a:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab08554:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab0855e:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab08566:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab08572:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0857b:	mov    rdx,rbx
    75b0bab0857e:	shr    rdx,0x10
    75b0bab08582:	and    edx,0xc000
    75b0bab08588:	mov    rax,rbx
    75b0bab0858b:	shr    rax,0x15
    75b0bab0858f:	and    eax,0x100
    75b0bab08594:	xor    eax,0x100
    75b0bab08599:	or     edx,eax
    75b0bab0859b:	mov    rax,rbx
    75b0bab0859e:	shr    rax,0x1c
    75b0bab085a2:	and    eax,0x1
    75b0bab085a5:	or     edx,eax
    75b0bab085a7:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab085ac:	add    rsp,0x8
    75b0bab085b0:	ret
    75b0bab085b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab085c0:	sub    rsp,0x8
    75b0bab085c4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab085d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab085d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab085dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab085e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab085e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab085ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab085f4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab085fe:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab08608:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab08612:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab0861c:	push   rdx
    75b0bab0861d:	push   rsi
    75b0bab0861e:	push   r10
    75b0bab08620:	push   r11
    75b0bab08622:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab08627:	mov    r10d,edx
    75b0bab0862a:	and    r10d,0xc000
    75b0bab08631:	shl    r10d,0x10
    75b0bab08635:	mov    r11d,edx
    75b0bab08638:	and    r11d,0x100
    75b0bab0863f:	shl    r11d,0x15
    75b0bab08643:	or     r10d,r11d
    75b0bab08646:	and    edx,0x1
    75b0bab08649:	shl    edx,0x1c
    75b0bab0864c:	or     r10d,edx
    75b0bab0864f:	btc    r10,0x1d
    75b0bab08654:	mov    r11d,0xf0000000
    75b0bab0865a:	and    r11,r10
    75b0bab0865d:	movabs rsi,0xffffffff0fffffff
    75b0bab08667:	and    rbx,rsi
    75b0bab0866a:	or     rbx,r11
    75b0bab0866d:	pop    r11
    75b0bab0866f:	pop    r10
    75b0bab08671:	pop    rsi
    75b0bab08672:	pop    rdx
    75b0bab08673:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0867b:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab08681:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab08686:	test   r10d,0x3f
    75b0bab0868d:	je     0x75b0bab086b2
    75b0bab08693:	mov    r11d,r10d
    75b0bab08696:	shr    r10d,1
    75b0bab08699:	and    r10d,0x1e
    75b0bab0869d:	and    r11d,0x1
    75b0bab086a1:	or     r10d,r11d
    75b0bab086a4:	or     DWORD PTR [r12+0x314],r10d
    75b0bab086ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab086b2:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab086b8:	lea    rdi,[rsp+0x110]
    75b0bab086c0:	lea    rsi,[rsp+0xf0]
    75b0bab086c8:	lea    rdx,[rsp+0x100]
    75b0bab086d0:	mov    ecx,0x56
    75b0bab086d5:	mov    r8d,0x0
    75b0bab086db:	lea    r9,[r12+0x314]
    75b0bab086e3:	movabs r11,0x59d8f4f27650
    75b0bab086ed:	call   r11
    75b0bab086f0:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab086f6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab086fc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab08702:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab08708:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0870e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab08714:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0871a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab08724:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0872e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab08738:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab08742:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0874a:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab08756:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0875f:	mov    rdx,rbx
    75b0bab08762:	shr    rdx,0x10
    75b0bab08766:	and    edx,0xc000
    75b0bab0876c:	mov    rax,rbx
    75b0bab0876f:	shr    rax,0x15
    75b0bab08773:	and    eax,0x100
    75b0bab08778:	xor    eax,0x100
    75b0bab0877d:	or     edx,eax
    75b0bab0877f:	mov    rax,rbx
    75b0bab08782:	shr    rax,0x1c
    75b0bab08786:	and    eax,0x1
    75b0bab08789:	or     edx,eax
    75b0bab0878b:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab08790:	add    rsp,0x8
    75b0bab08794:	ret
    75b0bab08795:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab087a0:	sub    rsp,0x8
    75b0bab087a4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab087b0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab087b6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab087bc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab087c2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab087c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab087d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab087dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab087e6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab087f0:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    75b0bab087fa:	push   rdx
    75b0bab087fb:	push   rsi
    75b0bab087fc:	push   r10
    75b0bab087fe:	push   r11
    75b0bab08800:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab08805:	mov    r10d,edx
    75b0bab08808:	and    r10d,0xc000
    75b0bab0880f:	shl    r10d,0x10
    75b0bab08813:	mov    r11d,edx
    75b0bab08816:	and    r11d,0x100
    75b0bab0881d:	shl    r11d,0x15
    75b0bab08821:	or     r10d,r11d
    75b0bab08824:	and    edx,0x1
    75b0bab08827:	shl    edx,0x1c
    75b0bab0882a:	or     r10d,edx
    75b0bab0882d:	btc    r10,0x1d
    75b0bab08832:	mov    r11d,0xf0000000
    75b0bab08838:	and    r11,r10
    75b0bab0883b:	movabs rsi,0xffffffff0fffffff
    75b0bab08845:	and    rbx,rsi
    75b0bab08848:	or     rbx,r11
    75b0bab0884b:	pop    r11
    75b0bab0884d:	pop    r10
    75b0bab0884f:	pop    rsi
    75b0bab08850:	pop    rdx
    75b0bab08851:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab08859:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0885f:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab08864:	test   r10d,0x3f
    75b0bab0886b:	je     0x75b0bab08890
    75b0bab08871:	mov    r11d,r10d
    75b0bab08874:	shr    r10d,1
    75b0bab08877:	and    r10d,0x1e
    75b0bab0887b:	and    r11d,0x1
    75b0bab0887f:	or     r10d,r11d
    75b0bab08882:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0888a:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab08890:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab08896:	lea    rdi,[rsp+0x110]
    75b0bab0889e:	lea    rsi,[rsp+0xf0]
    75b0bab088a6:	lea    rdx,[rsp+0x100]
    75b0bab088ae:	mov    ecx,0x14
    75b0bab088b3:	mov    r8d,0x0
    75b0bab088b9:	lea    r9,[r12+0x314]
    75b0bab088c1:	movabs r11,0x59d8f4f27650
    75b0bab088cb:	call   r11
    75b0bab088ce:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab088d4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab088da:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab088e0:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab088e6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab088ec:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab088f6:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab08900:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0890a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab08914:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    75b0bab0891e:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab08926:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab08932:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0893b:	mov    rdx,rbx
    75b0bab0893e:	shr    rdx,0x10
    75b0bab08942:	and    edx,0xc000
    75b0bab08948:	mov    rax,rbx
    75b0bab0894b:	shr    rax,0x15
    75b0bab0894f:	and    eax,0x100
    75b0bab08954:	xor    eax,0x100
    75b0bab08959:	or     edx,eax
    75b0bab0895b:	mov    rax,rbx
    75b0bab0895e:	shr    rax,0x1c
    75b0bab08962:	and    eax,0x1
    75b0bab08965:	or     edx,eax
    75b0bab08967:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0896c:	add    rsp,0x8
    75b0bab08970:	ret
    75b0bab08971:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab08980:	sub    rsp,0x8
    75b0bab08984:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab08990:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab08996:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0899c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab089a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab089a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab089ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab089b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab089be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab089c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab089d2:	push   rdx
    75b0bab089d3:	push   rsi
    75b0bab089d4:	push   r10
    75b0bab089d6:	push   r11
    75b0bab089d8:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab089dd:	mov    r10d,edx
    75b0bab089e0:	and    r10d,0xc000
    75b0bab089e7:	shl    r10d,0x10
    75b0bab089eb:	mov    r11d,edx
    75b0bab089ee:	and    r11d,0x100
    75b0bab089f5:	shl    r11d,0x15
    75b0bab089f9:	or     r10d,r11d
    75b0bab089fc:	and    edx,0x1
    75b0bab089ff:	shl    edx,0x1c
    75b0bab08a02:	or     r10d,edx
    75b0bab08a05:	btc    r10,0x1d
    75b0bab08a0a:	mov    r11d,0xf0000000
    75b0bab08a10:	and    r11,r10
    75b0bab08a13:	movabs rsi,0xffffffff0fffffff
    75b0bab08a1d:	and    rbx,rsi
    75b0bab08a20:	or     rbx,r11
    75b0bab08a23:	pop    r11
    75b0bab08a25:	pop    r10
    75b0bab08a27:	pop    rsi
    75b0bab08a28:	pop    rdx
    75b0bab08a29:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab08a31:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab08a37:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab08a3c:	test   r10d,0x3f
    75b0bab08a43:	je     0x75b0bab08a68
    75b0bab08a49:	mov    r11d,r10d
    75b0bab08a4c:	shr    r10d,1
    75b0bab08a4f:	and    r10d,0x1e
    75b0bab08a53:	and    r11d,0x1
    75b0bab08a57:	or     r10d,r11d
    75b0bab08a5a:	or     DWORD PTR [r12+0x314],r10d
    75b0bab08a62:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab08a68:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab08a6e:	lea    rdi,[rsp+0x110]
    75b0bab08a76:	lea    rsi,[rsp+0xf0]
    75b0bab08a7e:	lea    rdx,[rsp+0x100]
    75b0bab08a86:	mov    ecx,0x56
    75b0bab08a8b:	mov    r8d,0x0
    75b0bab08a91:	lea    r9,[r12+0x314]
    75b0bab08a99:	movabs r11,0x59d8f4f27650
    75b0bab08aa3:	call   r11
    75b0bab08aa6:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab08aac:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab08ab2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab08ab8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab08abe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab08ac4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab08aca:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab08ad0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab08ada:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab08ae4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab08aee:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab08af6:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab08b02:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab08b0b:	mov    rdx,rbx
    75b0bab08b0e:	shr    rdx,0x10
    75b0bab08b12:	and    edx,0xc000
    75b0bab08b18:	mov    rax,rbx
    75b0bab08b1b:	shr    rax,0x15
    75b0bab08b1f:	and    eax,0x100
    75b0bab08b24:	xor    eax,0x100
    75b0bab08b29:	or     edx,eax
    75b0bab08b2b:	mov    rax,rbx
    75b0bab08b2e:	shr    rax,0x1c
    75b0bab08b32:	and    eax,0x1
    75b0bab08b35:	or     edx,eax
    75b0bab08b37:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab08b3c:	add    rsp,0x8
    75b0bab08b40:	ret
    75b0bab08b41:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab08b50:	sub    rsp,0x8
    75b0bab08b54:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab08b60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab08b66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab08b6c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab08b72:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab08b78:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab08b7e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab08b88:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab08b92:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab08b9c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab08ba6:	push   rdx
    75b0bab08ba7:	push   rsi
    75b0bab08ba8:	push   r10
    75b0bab08baa:	push   r11
    75b0bab08bac:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab08bb1:	mov    r10d,edx
    75b0bab08bb4:	and    r10d,0xc000
    75b0bab08bbb:	shl    r10d,0x10
    75b0bab08bbf:	mov    r11d,edx
    75b0bab08bc2:	and    r11d,0x100
    75b0bab08bc9:	shl    r11d,0x15
    75b0bab08bcd:	or     r10d,r11d
    75b0bab08bd0:	and    edx,0x1
    75b0bab08bd3:	shl    edx,0x1c
    75b0bab08bd6:	or     r10d,edx
    75b0bab08bd9:	btc    r10,0x1d
    75b0bab08bde:	mov    r11d,0xf0000000
    75b0bab08be4:	and    r11,r10
    75b0bab08be7:	movabs rsi,0xffffffff0fffffff
    75b0bab08bf1:	and    rbx,rsi
    75b0bab08bf4:	or     rbx,r11
    75b0bab08bf7:	pop    r11
    75b0bab08bf9:	pop    r10
    75b0bab08bfb:	pop    rsi
    75b0bab08bfc:	pop    rdx
    75b0bab08bfd:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab08c05:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab08c0b:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab08c10:	test   r10d,0x3f
    75b0bab08c17:	je     0x75b0bab08c3c
    75b0bab08c1d:	mov    r11d,r10d
    75b0bab08c20:	shr    r10d,1
    75b0bab08c23:	and    r10d,0x1e
    75b0bab08c27:	and    r11d,0x1
    75b0bab08c2b:	or     r10d,r11d
    75b0bab08c2e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab08c36:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab08c3c:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab08c42:	lea    rdi,[rsp+0x110]
    75b0bab08c4a:	lea    rsi,[rsp+0xf0]
    75b0bab08c52:	lea    rdx,[rsp+0x100]
    75b0bab08c5a:	mov    ecx,0x56
    75b0bab08c5f:	mov    r8d,0x0
    75b0bab08c65:	lea    r9,[r12+0x314]
    75b0bab08c6d:	movabs r11,0x59d8f4f27650
    75b0bab08c77:	call   r11
    75b0bab08c7a:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab08c80:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab08c86:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab08c8c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab08c92:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab08c98:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab08c9e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab08ca8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab08cb2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab08cbc:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab08cc6:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab08cce:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab08cda:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab08ce3:	mov    rdx,rbx
    75b0bab08ce6:	shr    rdx,0x10
    75b0bab08cea:	and    edx,0xc000
    75b0bab08cf0:	mov    rax,rbx
    75b0bab08cf3:	shr    rax,0x15
    75b0bab08cf7:	and    eax,0x100
    75b0bab08cfc:	xor    eax,0x100
    75b0bab08d01:	or     edx,eax
    75b0bab08d03:	mov    rax,rbx
    75b0bab08d06:	shr    rax,0x1c
    75b0bab08d0a:	and    eax,0x1
    75b0bab08d0d:	or     edx,eax
    75b0bab08d0f:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab08d14:	add    rsp,0x8
    75b0bab08d18:	ret
    75b0bab08d19:	nop    DWORD PTR [rax+0x0]
    75b0bab08d20:	sub    rsp,0x8
    75b0bab08d24:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab08d30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab08d36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab08d3c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab08d42:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab08d48:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab08d4e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab08d54:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab08d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab08d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab08d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab08d7c:	push   rdx
    75b0bab08d7d:	push   rsi
    75b0bab08d7e:	push   r10
    75b0bab08d80:	push   r11
    75b0bab08d82:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab08d87:	mov    r10d,edx
    75b0bab08d8a:	and    r10d,0xc000
    75b0bab08d91:	shl    r10d,0x10
    75b0bab08d95:	mov    r11d,edx
    75b0bab08d98:	and    r11d,0x100
    75b0bab08d9f:	shl    r11d,0x15
    75b0bab08da3:	or     r10d,r11d
    75b0bab08da6:	and    edx,0x1
    75b0bab08da9:	shl    edx,0x1c
    75b0bab08dac:	or     r10d,edx
    75b0bab08daf:	btc    r10,0x1d
    75b0bab08db4:	mov    r11d,0xf0000000
    75b0bab08dba:	and    r11,r10
    75b0bab08dbd:	movabs rsi,0xffffffff0fffffff
    75b0bab08dc7:	and    rbx,rsi
    75b0bab08dca:	or     rbx,r11
    75b0bab08dcd:	pop    r11
    75b0bab08dcf:	pop    r10
    75b0bab08dd1:	pop    rsi
    75b0bab08dd2:	pop    rdx
    75b0bab08dd3:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab08ddb:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab08de1:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab08de6:	test   r10d,0x3f
    75b0bab08ded:	je     0x75b0bab08e12
    75b0bab08df3:	mov    r11d,r10d
    75b0bab08df6:	shr    r10d,1
    75b0bab08df9:	and    r10d,0x1e
    75b0bab08dfd:	and    r11d,0x1
    75b0bab08e01:	or     r10d,r11d
    75b0bab08e04:	or     DWORD PTR [r12+0x314],r10d
    75b0bab08e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab08e12:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab08e18:	lea    rdi,[rsp+0x110]
    75b0bab08e20:	lea    rsi,[rsp+0xf0]
    75b0bab08e28:	lea    rdx,[rsp+0x100]
    75b0bab08e30:	mov    ecx,0x14
    75b0bab08e35:	mov    r8d,0x0
    75b0bab08e3b:	lea    r9,[r12+0x314]
    75b0bab08e43:	movabs r11,0x59d8f4f27650
    75b0bab08e4d:	call   r11
    75b0bab08e50:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab08e56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab08e5c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab08e62:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab08e68:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab08e6e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab08e74:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab08e7a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab08e84:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab08e8e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab08e98:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab08ea2:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab08eaa:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab08eb6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab08ebf:	mov    rdx,rbx
    75b0bab08ec2:	shr    rdx,0x10
    75b0bab08ec6:	and    edx,0xc000
    75b0bab08ecc:	mov    rax,rbx
    75b0bab08ecf:	shr    rax,0x15
    75b0bab08ed3:	and    eax,0x100
    75b0bab08ed8:	xor    eax,0x100
    75b0bab08edd:	or     edx,eax
    75b0bab08edf:	mov    rax,rbx
    75b0bab08ee2:	shr    rax,0x1c
    75b0bab08ee6:	and    eax,0x1
    75b0bab08ee9:	or     edx,eax
    75b0bab08eeb:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab08ef0:	add    rsp,0x8
    75b0bab08ef4:	ret
    75b0bab08ef5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab08f00:	sub    rsp,0x8
    75b0bab08f04:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab08f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab08f16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab08f1c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab08f22:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab08f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab08f2e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab08f38:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab08f42:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab08f4c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab08f56:	push   rdx
    75b0bab08f57:	push   rsi
    75b0bab08f58:	push   r10
    75b0bab08f5a:	push   r11
    75b0bab08f5c:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab08f61:	mov    r10d,edx
    75b0bab08f64:	and    r10d,0xc000
    75b0bab08f6b:	shl    r10d,0x10
    75b0bab08f6f:	mov    r11d,edx
    75b0bab08f72:	and    r11d,0x100
    75b0bab08f79:	shl    r11d,0x15
    75b0bab08f7d:	or     r10d,r11d
    75b0bab08f80:	and    edx,0x1
    75b0bab08f83:	shl    edx,0x1c
    75b0bab08f86:	or     r10d,edx
    75b0bab08f89:	btc    r10,0x1d
    75b0bab08f8e:	mov    r11d,0xf0000000
    75b0bab08f94:	and    r11,r10
    75b0bab08f97:	movabs rsi,0xffffffff0fffffff
    75b0bab08fa1:	and    rbx,rsi
    75b0bab08fa4:	or     rbx,r11
    75b0bab08fa7:	pop    r11
    75b0bab08fa9:	pop    r10
    75b0bab08fab:	pop    rsi
    75b0bab08fac:	pop    rdx
    75b0bab08fad:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab08fb5:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab08fbb:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab08fc0:	test   r10d,0x3f
    75b0bab08fc7:	je     0x75b0bab08fec
    75b0bab08fcd:	mov    r11d,r10d
    75b0bab08fd0:	shr    r10d,1
    75b0bab08fd3:	and    r10d,0x1e
    75b0bab08fd7:	and    r11d,0x1
    75b0bab08fdb:	or     r10d,r11d
    75b0bab08fde:	or     DWORD PTR [r12+0x314],r10d
    75b0bab08fe6:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab08fec:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab08ff2:	lea    rdi,[rsp+0x110]
    75b0bab08ffa:	lea    rsi,[rsp+0xf0]
    75b0bab09002:	lea    rdx,[rsp+0x100]
    75b0bab0900a:	mov    ecx,0x14
    75b0bab0900f:	mov    r8d,0x0
    75b0bab09015:	lea    r9,[r12+0x314]
    75b0bab0901d:	movabs r11,0x59d8f4f27650
    75b0bab09027:	call   r11
    75b0bab0902a:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab09030:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab09036:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0903c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab09042:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab09048:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0904e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab09058:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab09062:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab0906c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab09076:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0907e:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0908a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab09093:	mov    rdx,rbx
    75b0bab09096:	shr    rdx,0x10
    75b0bab0909a:	and    edx,0xc000
    75b0bab090a0:	mov    rax,rbx
    75b0bab090a3:	shr    rax,0x15
    75b0bab090a7:	and    eax,0x100
    75b0bab090ac:	xor    eax,0x100
    75b0bab090b1:	or     edx,eax
    75b0bab090b3:	mov    rax,rbx
    75b0bab090b6:	shr    rax,0x1c
    75b0bab090ba:	and    eax,0x1
    75b0bab090bd:	or     edx,eax
    75b0bab090bf:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab090c4:	add    rsp,0x8
    75b0bab090c8:	ret
    75b0bab090c9:	nop    DWORD PTR [rax+0x0]
    75b0bab090d0:	sub    rsp,0x8
    75b0bab090d4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab090e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab090e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab090ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab090f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab090f8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab090fe:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab09108:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab09112:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab0911c:	push   rdx
    75b0bab0911d:	push   rsi
    75b0bab0911e:	push   r10
    75b0bab09120:	push   r11
    75b0bab09122:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab09127:	mov    r10d,edx
    75b0bab0912a:	and    r10d,0xc000
    75b0bab09131:	shl    r10d,0x10
    75b0bab09135:	mov    r11d,edx
    75b0bab09138:	and    r11d,0x100
    75b0bab0913f:	shl    r11d,0x15
    75b0bab09143:	or     r10d,r11d
    75b0bab09146:	and    edx,0x1
    75b0bab09149:	shl    edx,0x1c
    75b0bab0914c:	or     r10d,edx
    75b0bab0914f:	btc    r10,0x1d
    75b0bab09154:	mov    r11d,0xf0000000
    75b0bab0915a:	and    r11,r10
    75b0bab0915d:	movabs rsi,0xffffffff0fffffff
    75b0bab09167:	and    rbx,rsi
    75b0bab0916a:	or     rbx,r11
    75b0bab0916d:	pop    r11
    75b0bab0916f:	pop    r10
    75b0bab09171:	pop    rsi
    75b0bab09172:	pop    rdx
    75b0bab09173:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0917b:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab09181:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab09186:	test   r10d,0x3f
    75b0bab0918d:	je     0x75b0bab091b2
    75b0bab09193:	mov    r11d,r10d
    75b0bab09196:	shr    r10d,1
    75b0bab09199:	and    r10d,0x1e
    75b0bab0919d:	and    r11d,0x1
    75b0bab091a1:	or     r10d,r11d
    75b0bab091a4:	or     DWORD PTR [r12+0x314],r10d
    75b0bab091ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab091b2:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab091b8:	lea    rdi,[rsp+0x110]
    75b0bab091c0:	lea    rsi,[rsp+0xf0]
    75b0bab091c8:	lea    rdx,[rsp+0x100]
    75b0bab091d0:	mov    ecx,0x56
    75b0bab091d5:	mov    r8d,0x0
    75b0bab091db:	lea    r9,[r12+0x314]
    75b0bab091e3:	movabs r11,0x59d8f4f27650
    75b0bab091ed:	call   r11
    75b0bab091f0:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab091f6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab091fc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab09202:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab09208:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0920e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab09214:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0921e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab09228:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab09232:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0923a:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab09246:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0924f:	mov    rdx,rbx
    75b0bab09252:	shr    rdx,0x10
    75b0bab09256:	and    edx,0xc000
    75b0bab0925c:	mov    rax,rbx
    75b0bab0925f:	shr    rax,0x15
    75b0bab09263:	and    eax,0x100
    75b0bab09268:	xor    eax,0x100
    75b0bab0926d:	or     edx,eax
    75b0bab0926f:	mov    rax,rbx
    75b0bab09272:	shr    rax,0x1c
    75b0bab09276:	and    eax,0x1
    75b0bab09279:	or     edx,eax
    75b0bab0927b:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab09280:	add    rsp,0x8
    75b0bab09284:	ret
    75b0bab09285:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab09290:	sub    rsp,0x8
    75b0bab09294:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab092a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab092a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab092ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab092b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab092b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab092be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab092c4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab092ce:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab092d8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab092e2:	push   rdx
    75b0bab092e3:	push   rsi
    75b0bab092e4:	push   r10
    75b0bab092e6:	push   r11
    75b0bab092e8:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab092ed:	mov    r10d,edx
    75b0bab092f0:	and    r10d,0xc000
    75b0bab092f7:	shl    r10d,0x10
    75b0bab092fb:	mov    r11d,edx
    75b0bab092fe:	and    r11d,0x100
    75b0bab09305:	shl    r11d,0x15
    75b0bab09309:	or     r10d,r11d
    75b0bab0930c:	and    edx,0x1
    75b0bab0930f:	shl    edx,0x1c
    75b0bab09312:	or     r10d,edx
    75b0bab09315:	btc    r10,0x1d
    75b0bab0931a:	mov    r11d,0xf0000000
    75b0bab09320:	and    r11,r10
    75b0bab09323:	movabs rsi,0xffffffff0fffffff
    75b0bab0932d:	and    rbx,rsi
    75b0bab09330:	or     rbx,r11
    75b0bab09333:	pop    r11
    75b0bab09335:	pop    r10
    75b0bab09337:	pop    rsi
    75b0bab09338:	pop    rdx
    75b0bab09339:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab09341:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab09347:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0934c:	test   r10d,0x3f
    75b0bab09353:	je     0x75b0bab09378
    75b0bab09359:	mov    r11d,r10d
    75b0bab0935c:	shr    r10d,1
    75b0bab0935f:	and    r10d,0x1e
    75b0bab09363:	and    r11d,0x1
    75b0bab09367:	or     r10d,r11d
    75b0bab0936a:	or     DWORD PTR [r12+0x314],r10d
    75b0bab09372:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab09378:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0937e:	lea    rdi,[rsp+0x110]
    75b0bab09386:	lea    rsi,[rsp+0xf0]
    75b0bab0938e:	lea    rdx,[rsp+0x100]
    75b0bab09396:	mov    ecx,0x56
    75b0bab0939b:	mov    r8d,0x0
    75b0bab093a1:	lea    r9,[r12+0x314]
    75b0bab093a9:	movabs r11,0x59d8f4f27650
    75b0bab093b3:	call   r11
    75b0bab093b6:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab093bc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab093c2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab093c8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab093ce:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab093d4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab093da:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab093e0:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab093ea:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab093f4:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab093fe:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab09406:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab09412:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0941b:	mov    rdx,rbx
    75b0bab0941e:	shr    rdx,0x10
    75b0bab09422:	and    edx,0xc000
    75b0bab09428:	mov    rax,rbx
    75b0bab0942b:	shr    rax,0x15
    75b0bab0942f:	and    eax,0x100
    75b0bab09434:	xor    eax,0x100
    75b0bab09439:	or     edx,eax
    75b0bab0943b:	mov    rax,rbx
    75b0bab0943e:	shr    rax,0x1c
    75b0bab09442:	and    eax,0x1
    75b0bab09445:	or     edx,eax
    75b0bab09447:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0944c:	add    rsp,0x8
    75b0bab09450:	ret
    75b0bab09451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab09460:	sub    rsp,0x8
    75b0bab09464:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab09470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab09476:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0947c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab09482:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab09488:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0948e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab09498:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab094a2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab094ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab094b6:	push   rdx
    75b0bab094b7:	push   rsi
    75b0bab094b8:	push   r10
    75b0bab094ba:	push   r11
    75b0bab094bc:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab094c1:	mov    r10d,edx
    75b0bab094c4:	and    r10d,0xc000
    75b0bab094cb:	shl    r10d,0x10
    75b0bab094cf:	mov    r11d,edx
    75b0bab094d2:	and    r11d,0x100
    75b0bab094d9:	shl    r11d,0x15
    75b0bab094dd:	or     r10d,r11d
    75b0bab094e0:	and    edx,0x1
    75b0bab094e3:	shl    edx,0x1c
    75b0bab094e6:	or     r10d,edx
    75b0bab094e9:	btc    r10,0x1d
    75b0bab094ee:	mov    r11d,0xf0000000
    75b0bab094f4:	and    r11,r10
    75b0bab094f7:	movabs rsi,0xffffffff0fffffff
    75b0bab09501:	and    rbx,rsi
    75b0bab09504:	or     rbx,r11
    75b0bab09507:	pop    r11
    75b0bab09509:	pop    r10
    75b0bab0950b:	pop    rsi
    75b0bab0950c:	pop    rdx
    75b0bab0950d:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab09515:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0951b:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab09520:	test   r10d,0x3f
    75b0bab09527:	je     0x75b0bab0954c
    75b0bab0952d:	mov    r11d,r10d
    75b0bab09530:	shr    r10d,1
    75b0bab09533:	and    r10d,0x1e
    75b0bab09537:	and    r11d,0x1
    75b0bab0953b:	or     r10d,r11d
    75b0bab0953e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab09546:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0954c:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab09552:	lea    rdi,[rsp+0x110]
    75b0bab0955a:	lea    rsi,[rsp+0xf0]
    75b0bab09562:	lea    rdx,[rsp+0x100]
    75b0bab0956a:	mov    ecx,0x14
    75b0bab0956f:	mov    r8d,0x0
    75b0bab09575:	lea    r9,[r12+0x314]
    75b0bab0957d:	movabs r11,0x59d8f4f27650
    75b0bab09587:	call   r11
    75b0bab0958a:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab09590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab09596:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0959c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab095a2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab095a8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab095ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab095b8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab095c2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab095cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab095d6:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab095de:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab095ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab095f3:	mov    rdx,rbx
    75b0bab095f6:	shr    rdx,0x10
    75b0bab095fa:	and    edx,0xc000
    75b0bab09600:	mov    rax,rbx
    75b0bab09603:	shr    rax,0x15
    75b0bab09607:	and    eax,0x100
    75b0bab0960c:	xor    eax,0x100
    75b0bab09611:	or     edx,eax
    75b0bab09613:	mov    rax,rbx
    75b0bab09616:	shr    rax,0x1c
    75b0bab0961a:	and    eax,0x1
    75b0bab0961d:	or     edx,eax
    75b0bab0961f:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab09624:	add    rsp,0x8
    75b0bab09628:	ret
    75b0bab09629:	nop    DWORD PTR [rax+0x0]
    75b0bab09630:	sub    rsp,0x8
    75b0bab09634:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab09640:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab09646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0964c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab09652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab09658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab0965e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab09668:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab09672:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab0967c:	push   rdx
    75b0bab0967d:	push   rsi
    75b0bab0967e:	push   r10
    75b0bab09680:	push   r11
    75b0bab09682:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab09687:	mov    r10d,edx
    75b0bab0968a:	and    r10d,0xc000
    75b0bab09691:	shl    r10d,0x10
    75b0bab09695:	mov    r11d,edx
    75b0bab09698:	and    r11d,0x100
    75b0bab0969f:	shl    r11d,0x15
    75b0bab096a3:	or     r10d,r11d
    75b0bab096a6:	and    edx,0x1
    75b0bab096a9:	shl    edx,0x1c
    75b0bab096ac:	or     r10d,edx
    75b0bab096af:	btc    r10,0x1d
    75b0bab096b4:	mov    r11d,0xf0000000
    75b0bab096ba:	and    r11,r10
    75b0bab096bd:	movabs rsi,0xffffffff0fffffff
    75b0bab096c7:	and    rbx,rsi
    75b0bab096ca:	or     rbx,r11
    75b0bab096cd:	pop    r11
    75b0bab096cf:	pop    r10
    75b0bab096d1:	pop    rsi
    75b0bab096d2:	pop    rdx
    75b0bab096d3:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab096db:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab096e1:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab096e6:	test   r10d,0x3f
    75b0bab096ed:	je     0x75b0bab09712
    75b0bab096f3:	mov    r11d,r10d
    75b0bab096f6:	shr    r10d,1
    75b0bab096f9:	and    r10d,0x1e
    75b0bab096fd:	and    r11d,0x1
    75b0bab09701:	or     r10d,r11d
    75b0bab09704:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0970c:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab09712:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab09718:	lea    rdi,[rsp+0x110]
    75b0bab09720:	lea    rsi,[rsp+0xf0]
    75b0bab09728:	lea    rdx,[rsp+0x100]
    75b0bab09730:	mov    ecx,0x14
    75b0bab09735:	mov    r8d,0x0
    75b0bab0973b:	lea    r9,[r12+0x314]
    75b0bab09743:	movabs r11,0x59d8f4f27650
    75b0bab0974d:	call   r11
    75b0bab09750:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab09756:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0975c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab09762:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab09768:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0976e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab09774:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab0977e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab09788:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab09792:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0979a:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab097a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab097af:	mov    rdx,rbx
    75b0bab097b2:	shr    rdx,0x10
    75b0bab097b6:	and    edx,0xc000
    75b0bab097bc:	mov    rax,rbx
    75b0bab097bf:	shr    rax,0x15
    75b0bab097c3:	and    eax,0x100
    75b0bab097c8:	xor    eax,0x100
    75b0bab097cd:	or     edx,eax
    75b0bab097cf:	mov    rax,rbx
    75b0bab097d2:	shr    rax,0x1c
    75b0bab097d6:	and    eax,0x1
    75b0bab097d9:	or     edx,eax
    75b0bab097db:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab097e0:	add    rsp,0x8
    75b0bab097e4:	ret
    75b0bab097e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab097f0:	sub    rsp,0x8
    75b0bab097f4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab09800:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab09806:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0980c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab09812:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab09818:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0981e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab09824:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab0982e:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab09838:	push   rdx
    75b0bab09839:	push   rsi
    75b0bab0983a:	push   r10
    75b0bab0983c:	push   r11
    75b0bab0983e:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab09843:	mov    r10d,edx
    75b0bab09846:	and    r10d,0xc000
    75b0bab0984d:	shl    r10d,0x10
    75b0bab09851:	mov    r11d,edx
    75b0bab09854:	and    r11d,0x100
    75b0bab0985b:	shl    r11d,0x15
    75b0bab0985f:	or     r10d,r11d
    75b0bab09862:	and    edx,0x1
    75b0bab09865:	shl    edx,0x1c
    75b0bab09868:	or     r10d,edx
    75b0bab0986b:	btc    r10,0x1d
    75b0bab09870:	mov    r11d,0xf0000000
    75b0bab09876:	and    r11,r10
    75b0bab09879:	movabs rsi,0xffffffff0fffffff
    75b0bab09883:	and    rbx,rsi
    75b0bab09886:	or     rbx,r11
    75b0bab09889:	pop    r11
    75b0bab0988b:	pop    r10
    75b0bab0988d:	pop    rsi
    75b0bab0988e:	pop    rdx
    75b0bab0988f:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab09897:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0989d:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab098a2:	test   r10d,0x3f
    75b0bab098a9:	je     0x75b0bab098ce
    75b0bab098af:	mov    r11d,r10d
    75b0bab098b2:	shr    r10d,1
    75b0bab098b5:	and    r10d,0x1e
    75b0bab098b9:	and    r11d,0x1
    75b0bab098bd:	or     r10d,r11d
    75b0bab098c0:	or     DWORD PTR [r12+0x314],r10d
    75b0bab098c8:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab098ce:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab098d4:	lea    rdi,[rsp+0x110]
    75b0bab098dc:	lea    rsi,[rsp+0xf0]
    75b0bab098e4:	lea    rdx,[rsp+0x100]
    75b0bab098ec:	mov    ecx,0x56
    75b0bab098f1:	mov    r8d,0x0
    75b0bab098f7:	lea    r9,[r12+0x314]
    75b0bab098ff:	movabs r11,0x59d8f4f27650
    75b0bab09909:	call   r11
    75b0bab0990c:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab09912:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab09918:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0991e:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab09924:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0992a:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab09930:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab09936:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab09940:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0994a:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab09952:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0995e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab09967:	mov    rdx,rbx
    75b0bab0996a:	shr    rdx,0x10
    75b0bab0996e:	and    edx,0xc000
    75b0bab09974:	mov    rax,rbx
    75b0bab09977:	shr    rax,0x15
    75b0bab0997b:	and    eax,0x100
    75b0bab09980:	xor    eax,0x100
    75b0bab09985:	or     edx,eax
    75b0bab09987:	mov    rax,rbx
    75b0bab0998a:	shr    rax,0x1c
    75b0bab0998e:	and    eax,0x1
    75b0bab09991:	or     edx,eax
    75b0bab09993:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab09998:	add    rsp,0x8
    75b0bab0999c:	ret
    75b0bab0999d:	nop    DWORD PTR [rax]
    75b0bab099a0:	sub    rsp,0x8
    75b0bab099a4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab099b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab099b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab099bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab099c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab099c8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab099ce:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab099d4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab099de:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab099e8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab099f2:	push   rdx
    75b0bab099f3:	push   rsi
    75b0bab099f4:	push   r10
    75b0bab099f6:	push   r11
    75b0bab099f8:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab099fd:	mov    r10d,edx
    75b0bab09a00:	and    r10d,0xc000
    75b0bab09a07:	shl    r10d,0x10
    75b0bab09a0b:	mov    r11d,edx
    75b0bab09a0e:	and    r11d,0x100
    75b0bab09a15:	shl    r11d,0x15
    75b0bab09a19:	or     r10d,r11d
    75b0bab09a1c:	and    edx,0x1
    75b0bab09a1f:	shl    edx,0x1c
    75b0bab09a22:	or     r10d,edx
    75b0bab09a25:	btc    r10,0x1d
    75b0bab09a2a:	mov    r11d,0xf0000000
    75b0bab09a30:	and    r11,r10
    75b0bab09a33:	movabs rsi,0xffffffff0fffffff
    75b0bab09a3d:	and    rbx,rsi
    75b0bab09a40:	or     rbx,r11
    75b0bab09a43:	pop    r11
    75b0bab09a45:	pop    r10
    75b0bab09a47:	pop    rsi
    75b0bab09a48:	pop    rdx
    75b0bab09a49:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab09a51:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab09a57:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab09a5c:	test   r10d,0x3f
    75b0bab09a63:	je     0x75b0bab09a88
    75b0bab09a69:	mov    r11d,r10d
    75b0bab09a6c:	shr    r10d,1
    75b0bab09a6f:	and    r10d,0x1e
    75b0bab09a73:	and    r11d,0x1
    75b0bab09a77:	or     r10d,r11d
    75b0bab09a7a:	or     DWORD PTR [r12+0x314],r10d
    75b0bab09a82:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab09a88:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab09a8e:	lea    rdi,[rsp+0x110]
    75b0bab09a96:	lea    rsi,[rsp+0xf0]
    75b0bab09a9e:	lea    rdx,[rsp+0x100]
    75b0bab09aa6:	mov    ecx,0x14
    75b0bab09aab:	mov    r8d,0x0
    75b0bab09ab1:	lea    r9,[r12+0x314]
    75b0bab09ab9:	movabs r11,0x59d8f4f27650
    75b0bab09ac3:	call   r11
    75b0bab09ac6:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab09acc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab09ad2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab09ad8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab09ade:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab09ae4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab09aea:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab09af0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab09afa:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab09b04:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab09b0e:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab09b16:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab09b22:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab09b2b:	mov    rdx,rbx
    75b0bab09b2e:	shr    rdx,0x10
    75b0bab09b32:	and    edx,0xc000
    75b0bab09b38:	mov    rax,rbx
    75b0bab09b3b:	shr    rax,0x15
    75b0bab09b3f:	and    eax,0x100
    75b0bab09b44:	xor    eax,0x100
    75b0bab09b49:	or     edx,eax
    75b0bab09b4b:	mov    rax,rbx
    75b0bab09b4e:	shr    rax,0x1c
    75b0bab09b52:	and    eax,0x1
    75b0bab09b55:	or     edx,eax
    75b0bab09b57:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab09b5c:	add    rsp,0x8
    75b0bab09b60:	ret
    75b0bab09b61:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab09b70:	sub    rsp,0x8
    75b0bab09b74:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab09b80:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab09b86:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab09b8c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab09b92:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab09b98:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab09ba2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab09bac:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab09bb6:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab09bc0:	push   rdx
    75b0bab09bc1:	push   rsi
    75b0bab09bc2:	push   r10
    75b0bab09bc4:	push   r11
    75b0bab09bc6:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab09bcb:	mov    r10d,edx
    75b0bab09bce:	and    r10d,0xc000
    75b0bab09bd5:	shl    r10d,0x10
    75b0bab09bd9:	mov    r11d,edx
    75b0bab09bdc:	and    r11d,0x100
    75b0bab09be3:	shl    r11d,0x15
    75b0bab09be7:	or     r10d,r11d
    75b0bab09bea:	and    edx,0x1
    75b0bab09bed:	shl    edx,0x1c
    75b0bab09bf0:	or     r10d,edx
    75b0bab09bf3:	btc    r10,0x1d
    75b0bab09bf8:	mov    r11d,0xf0000000
    75b0bab09bfe:	and    r11,r10
    75b0bab09c01:	movabs rsi,0xffffffff0fffffff
    75b0bab09c0b:	and    rbx,rsi
    75b0bab09c0e:	or     rbx,r11
    75b0bab09c11:	pop    r11
    75b0bab09c13:	pop    r10
    75b0bab09c15:	pop    rsi
    75b0bab09c16:	pop    rdx
    75b0bab09c17:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab09c1f:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab09c25:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab09c2a:	test   r10d,0x3f
    75b0bab09c31:	je     0x75b0bab09c56
    75b0bab09c37:	mov    r11d,r10d
    75b0bab09c3a:	shr    r10d,1
    75b0bab09c3d:	and    r10d,0x1e
    75b0bab09c41:	and    r11d,0x1
    75b0bab09c45:	or     r10d,r11d
    75b0bab09c48:	or     DWORD PTR [r12+0x314],r10d
    75b0bab09c50:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab09c56:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab09c5c:	lea    rdi,[rsp+0x110]
    75b0bab09c64:	lea    rsi,[rsp+0xf0]
    75b0bab09c6c:	lea    rdx,[rsp+0x100]
    75b0bab09c74:	mov    ecx,0x14
    75b0bab09c79:	mov    r8d,0x0
    75b0bab09c7f:	lea    r9,[r12+0x314]
    75b0bab09c87:	movabs r11,0x59d8f4f27650
    75b0bab09c91:	call   r11
    75b0bab09c94:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab09c9a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab09ca0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab09ca6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab09cac:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab09cb2:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab09cbc:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab09cc6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab09cd0:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab09cda:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab09ce2:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab09cee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab09cf7:	mov    rdx,rbx
    75b0bab09cfa:	shr    rdx,0x10
    75b0bab09cfe:	and    edx,0xc000
    75b0bab09d04:	mov    rax,rbx
    75b0bab09d07:	shr    rax,0x15
    75b0bab09d0b:	and    eax,0x100
    75b0bab09d10:	xor    eax,0x100
    75b0bab09d15:	or     edx,eax
    75b0bab09d17:	mov    rax,rbx
    75b0bab09d1a:	shr    rax,0x1c
    75b0bab09d1e:	and    eax,0x1
    75b0bab09d21:	or     edx,eax
    75b0bab09d23:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab09d28:	add    rsp,0x8
    75b0bab09d2c:	ret
    75b0bab09d2d:	nop    DWORD PTR [rax]
    75b0bab09d30:	sub    rsp,0x8
    75b0bab09d34:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab09d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab09d46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab09d4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab09d52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab09d58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab09d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab09d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab09d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab09d7c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab09d86:	push   rdx
    75b0bab09d87:	push   rsi
    75b0bab09d88:	push   r10
    75b0bab09d8a:	push   r11
    75b0bab09d8c:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab09d91:	mov    r10d,edx
    75b0bab09d94:	and    r10d,0xc000
    75b0bab09d9b:	shl    r10d,0x10
    75b0bab09d9f:	mov    r11d,edx
    75b0bab09da2:	and    r11d,0x100
    75b0bab09da9:	shl    r11d,0x15
    75b0bab09dad:	or     r10d,r11d
    75b0bab09db0:	and    edx,0x1
    75b0bab09db3:	shl    edx,0x1c
    75b0bab09db6:	or     r10d,edx
    75b0bab09db9:	btc    r10,0x1d
    75b0bab09dbe:	mov    r11d,0xf0000000
    75b0bab09dc4:	and    r11,r10
    75b0bab09dc7:	movabs rsi,0xffffffff0fffffff
    75b0bab09dd1:	and    rbx,rsi
    75b0bab09dd4:	or     rbx,r11
    75b0bab09dd7:	pop    r11
    75b0bab09dd9:	pop    r10
    75b0bab09ddb:	pop    rsi
    75b0bab09ddc:	pop    rdx
    75b0bab09ddd:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab09de5:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab09deb:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab09df0:	test   r10d,0x3f
    75b0bab09df7:	je     0x75b0bab09e1c
    75b0bab09dfd:	mov    r11d,r10d
    75b0bab09e00:	shr    r10d,1
    75b0bab09e03:	and    r10d,0x1e
    75b0bab09e07:	and    r11d,0x1
    75b0bab09e0b:	or     r10d,r11d
    75b0bab09e0e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab09e16:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab09e1c:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab09e22:	lea    rdi,[rsp+0x110]
    75b0bab09e2a:	lea    rsi,[rsp+0xf0]
    75b0bab09e32:	lea    rdx,[rsp+0x100]
    75b0bab09e3a:	mov    ecx,0x14
    75b0bab09e3f:	mov    r8d,0x0
    75b0bab09e45:	lea    r9,[r12+0x314]
    75b0bab09e4d:	movabs r11,0x59d8f4f27650
    75b0bab09e57:	call   r11
    75b0bab09e5a:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab09e60:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab09e66:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab09e6c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab09e72:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab09e78:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab09e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab09e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab09e92:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab09e9c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab09ea6:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab09eae:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab09eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab09ec3:	mov    rdx,rbx
    75b0bab09ec6:	shr    rdx,0x10
    75b0bab09eca:	and    edx,0xc000
    75b0bab09ed0:	mov    rax,rbx
    75b0bab09ed3:	shr    rax,0x15
    75b0bab09ed7:	and    eax,0x100
    75b0bab09edc:	xor    eax,0x100
    75b0bab09ee1:	or     edx,eax
    75b0bab09ee3:	mov    rax,rbx
    75b0bab09ee6:	shr    rax,0x1c
    75b0bab09eea:	and    eax,0x1
    75b0bab09eed:	or     edx,eax
    75b0bab09eef:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab09ef4:	add    rsp,0x8
    75b0bab09ef8:	ret
    75b0bab09ef9:	nop    DWORD PTR [rax+0x0]
    75b0bab09f00:	sub    rsp,0x8
    75b0bab09f04:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab09f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab09f16:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab09f1c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab09f22:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab09f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab09f2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab09f38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab09f42:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab09f4c:	push   rdx
    75b0bab09f4d:	push   rsi
    75b0bab09f4e:	push   r10
    75b0bab09f50:	push   r11
    75b0bab09f52:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab09f57:	mov    r10d,edx
    75b0bab09f5a:	and    r10d,0xc000
    75b0bab09f61:	shl    r10d,0x10
    75b0bab09f65:	mov    r11d,edx
    75b0bab09f68:	and    r11d,0x100
    75b0bab09f6f:	shl    r11d,0x15
    75b0bab09f73:	or     r10d,r11d
    75b0bab09f76:	and    edx,0x1
    75b0bab09f79:	shl    edx,0x1c
    75b0bab09f7c:	or     r10d,edx
    75b0bab09f7f:	btc    r10,0x1d
    75b0bab09f84:	mov    r11d,0xf0000000
    75b0bab09f8a:	and    r11,r10
    75b0bab09f8d:	movabs rsi,0xffffffff0fffffff
    75b0bab09f97:	and    rbx,rsi
    75b0bab09f9a:	or     rbx,r11
    75b0bab09f9d:	pop    r11
    75b0bab09f9f:	pop    r10
    75b0bab09fa1:	pop    rsi
    75b0bab09fa2:	pop    rdx
    75b0bab09fa3:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab09fab:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab09fb1:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab09fb6:	test   r10d,0x3f
    75b0bab09fbd:	je     0x75b0bab09fe2
    75b0bab09fc3:	mov    r11d,r10d
    75b0bab09fc6:	shr    r10d,1
    75b0bab09fc9:	and    r10d,0x1e
    75b0bab09fcd:	and    r11d,0x1
    75b0bab09fd1:	or     r10d,r11d
    75b0bab09fd4:	or     DWORD PTR [r12+0x314],r10d
    75b0bab09fdc:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab09fe2:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab09fe8:	lea    rdi,[rsp+0x110]
    75b0bab09ff0:	lea    rsi,[rsp+0xf0]
    75b0bab09ff8:	lea    rdx,[rsp+0x100]
    75b0bab0a000:	mov    ecx,0x56
    75b0bab0a005:	mov    r8d,0x0
    75b0bab0a00b:	lea    r9,[r12+0x314]
    75b0bab0a013:	movabs r11,0x59d8f4f27650
    75b0bab0a01d:	call   r11
    75b0bab0a020:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0a026:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0a02c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0a032:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0a038:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0a03e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0a044:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0a04e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab0a058:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0a062:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0a06a:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0a076:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0a07f:	mov    rdx,rbx
    75b0bab0a082:	shr    rdx,0x10
    75b0bab0a086:	and    edx,0xc000
    75b0bab0a08c:	mov    rax,rbx
    75b0bab0a08f:	shr    rax,0x15
    75b0bab0a093:	and    eax,0x100
    75b0bab0a098:	xor    eax,0x100
    75b0bab0a09d:	or     edx,eax
    75b0bab0a09f:	mov    rax,rbx
    75b0bab0a0a2:	shr    rax,0x1c
    75b0bab0a0a6:	and    eax,0x1
    75b0bab0a0a9:	or     edx,eax
    75b0bab0a0ab:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0a0b0:	add    rsp,0x8
    75b0bab0a0b4:	ret
    75b0bab0a0b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab0a0c0:	sub    rsp,0x8
    75b0bab0a0c4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0a0d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0a0d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0a0dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0a0e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab0a0e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab0a0ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab0a0f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0a102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab0a10c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab0a116:	push   rdx
    75b0bab0a117:	push   rsi
    75b0bab0a118:	push   r10
    75b0bab0a11a:	push   r11
    75b0bab0a11c:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0a121:	mov    r10d,edx
    75b0bab0a124:	and    r10d,0xc000
    75b0bab0a12b:	shl    r10d,0x10
    75b0bab0a12f:	mov    r11d,edx
    75b0bab0a132:	and    r11d,0x100
    75b0bab0a139:	shl    r11d,0x15
    75b0bab0a13d:	or     r10d,r11d
    75b0bab0a140:	and    edx,0x1
    75b0bab0a143:	shl    edx,0x1c
    75b0bab0a146:	or     r10d,edx
    75b0bab0a149:	btc    r10,0x1d
    75b0bab0a14e:	mov    r11d,0xf0000000
    75b0bab0a154:	and    r11,r10
    75b0bab0a157:	movabs rsi,0xffffffff0fffffff
    75b0bab0a161:	and    rbx,rsi
    75b0bab0a164:	or     rbx,r11
    75b0bab0a167:	pop    r11
    75b0bab0a169:	pop    r10
    75b0bab0a16b:	pop    rsi
    75b0bab0a16c:	pop    rdx
    75b0bab0a16d:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0a175:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0a17b:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0a180:	test   r10d,0x3f
    75b0bab0a187:	je     0x75b0bab0a1ac
    75b0bab0a18d:	mov    r11d,r10d
    75b0bab0a190:	shr    r10d,1
    75b0bab0a193:	and    r10d,0x1e
    75b0bab0a197:	and    r11d,0x1
    75b0bab0a19b:	or     r10d,r11d
    75b0bab0a19e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0a1a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0a1ac:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0a1b2:	lea    rdi,[rsp+0x110]
    75b0bab0a1ba:	lea    rsi,[rsp+0xf0]
    75b0bab0a1c2:	lea    rdx,[rsp+0x100]
    75b0bab0a1ca:	mov    ecx,0x56
    75b0bab0a1cf:	mov    r8d,0x0
    75b0bab0a1d5:	lea    r9,[r12+0x314]
    75b0bab0a1dd:	movabs r11,0x59d8f4f27650
    75b0bab0a1e7:	call   r11
    75b0bab0a1ea:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0a1f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0a1f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0a1fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0a202:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0a208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0a20e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab0a218:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0a222:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab0a22c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0a236:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0a23e:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0a24a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0a253:	mov    rdx,rbx
    75b0bab0a256:	shr    rdx,0x10
    75b0bab0a25a:	and    edx,0xc000
    75b0bab0a260:	mov    rax,rbx
    75b0bab0a263:	shr    rax,0x15
    75b0bab0a267:	and    eax,0x100
    75b0bab0a26c:	xor    eax,0x100
    75b0bab0a271:	or     edx,eax
    75b0bab0a273:	mov    rax,rbx
    75b0bab0a276:	shr    rax,0x1c
    75b0bab0a27a:	and    eax,0x1
    75b0bab0a27d:	or     edx,eax
    75b0bab0a27f:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0a284:	add    rsp,0x8
    75b0bab0a288:	ret
    75b0bab0a289:	nop    DWORD PTR [rax+0x0]
    75b0bab0a290:	sub    rsp,0x8
    75b0bab0a294:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0a2a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0a2a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0a2ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0a2b2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0a2b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab0a2be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab0a2c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0a2d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab0a2dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab0a2e6:	push   rdx
    75b0bab0a2e7:	push   rsi
    75b0bab0a2e8:	push   r10
    75b0bab0a2ea:	push   r11
    75b0bab0a2ec:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0a2f1:	mov    r10d,edx
    75b0bab0a2f4:	and    r10d,0xc000
    75b0bab0a2fb:	shl    r10d,0x10
    75b0bab0a2ff:	mov    r11d,edx
    75b0bab0a302:	and    r11d,0x100
    75b0bab0a309:	shl    r11d,0x15
    75b0bab0a30d:	or     r10d,r11d
    75b0bab0a310:	and    edx,0x1
    75b0bab0a313:	shl    edx,0x1c
    75b0bab0a316:	or     r10d,edx
    75b0bab0a319:	btc    r10,0x1d
    75b0bab0a31e:	mov    r11d,0xf0000000
    75b0bab0a324:	and    r11,r10
    75b0bab0a327:	movabs rsi,0xffffffff0fffffff
    75b0bab0a331:	and    rbx,rsi
    75b0bab0a334:	or     rbx,r11
    75b0bab0a337:	pop    r11
    75b0bab0a339:	pop    r10
    75b0bab0a33b:	pop    rsi
    75b0bab0a33c:	pop    rdx
    75b0bab0a33d:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0a345:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0a34b:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0a350:	test   r10d,0x3f
    75b0bab0a357:	je     0x75b0bab0a37c
    75b0bab0a35d:	mov    r11d,r10d
    75b0bab0a360:	shr    r10d,1
    75b0bab0a363:	and    r10d,0x1e
    75b0bab0a367:	and    r11d,0x1
    75b0bab0a36b:	or     r10d,r11d
    75b0bab0a36e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0a376:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0a37c:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0a382:	lea    rdi,[rsp+0x110]
    75b0bab0a38a:	lea    rsi,[rsp+0xf0]
    75b0bab0a392:	lea    rdx,[rsp+0x100]
    75b0bab0a39a:	mov    ecx,0x14
    75b0bab0a39f:	mov    r8d,0x0
    75b0bab0a3a5:	lea    r9,[r12+0x314]
    75b0bab0a3ad:	movabs r11,0x59d8f4f27650
    75b0bab0a3b7:	call   r11
    75b0bab0a3ba:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0a3c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0a3c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0a3cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0a3d2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0a3d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0a3de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab0a3e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0a3f2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab0a3fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0a406:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0a40e:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0a41a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0a423:	mov    rdx,rbx
    75b0bab0a426:	shr    rdx,0x10
    75b0bab0a42a:	and    edx,0xc000
    75b0bab0a430:	mov    rax,rbx
    75b0bab0a433:	shr    rax,0x15
    75b0bab0a437:	and    eax,0x100
    75b0bab0a43c:	xor    eax,0x100
    75b0bab0a441:	or     edx,eax
    75b0bab0a443:	mov    rax,rbx
    75b0bab0a446:	shr    rax,0x1c
    75b0bab0a44a:	and    eax,0x1
    75b0bab0a44d:	or     edx,eax
    75b0bab0a44f:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0a454:	add    rsp,0x8
    75b0bab0a458:	ret
    75b0bab0a459:	nop    DWORD PTR [rax+0x0]
    75b0bab0a460:	sub    rsp,0x8
    75b0bab0a464:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0a470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0a476:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0a47c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab0a482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0a488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab0a48e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab0a498:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab0a4a2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0a4ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab0a4b6:	push   rdx
    75b0bab0a4b7:	push   rsi
    75b0bab0a4b8:	push   r10
    75b0bab0a4ba:	push   r11
    75b0bab0a4bc:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0a4c1:	mov    r10d,edx
    75b0bab0a4c4:	and    r10d,0xc000
    75b0bab0a4cb:	shl    r10d,0x10
    75b0bab0a4cf:	mov    r11d,edx
    75b0bab0a4d2:	and    r11d,0x100
    75b0bab0a4d9:	shl    r11d,0x15
    75b0bab0a4dd:	or     r10d,r11d
    75b0bab0a4e0:	and    edx,0x1
    75b0bab0a4e3:	shl    edx,0x1c
    75b0bab0a4e6:	or     r10d,edx
    75b0bab0a4e9:	btc    r10,0x1d
    75b0bab0a4ee:	mov    r11d,0xf0000000
    75b0bab0a4f4:	and    r11,r10
    75b0bab0a4f7:	movabs rsi,0xffffffff0fffffff
    75b0bab0a501:	and    rbx,rsi
    75b0bab0a504:	or     rbx,r11
    75b0bab0a507:	pop    r11
    75b0bab0a509:	pop    r10
    75b0bab0a50b:	pop    rsi
    75b0bab0a50c:	pop    rdx
    75b0bab0a50d:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0a515:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0a51b:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0a520:	test   r10d,0x3f
    75b0bab0a527:	je     0x75b0bab0a54c
    75b0bab0a52d:	mov    r11d,r10d
    75b0bab0a530:	shr    r10d,1
    75b0bab0a533:	and    r10d,0x1e
    75b0bab0a537:	and    r11d,0x1
    75b0bab0a53b:	or     r10d,r11d
    75b0bab0a53e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0a546:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0a54c:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0a552:	lea    rdi,[rsp+0x110]
    75b0bab0a55a:	lea    rsi,[rsp+0xf0]
    75b0bab0a562:	lea    rdx,[rsp+0x100]
    75b0bab0a56a:	mov    ecx,0x56
    75b0bab0a56f:	mov    r8d,0x0
    75b0bab0a575:	lea    r9,[r12+0x314]
    75b0bab0a57d:	movabs r11,0x59d8f4f27650
    75b0bab0a587:	call   r11
    75b0bab0a58a:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0a590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0a596:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0a59c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0a5a2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0a5a8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0a5ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab0a5b8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0a5c2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0a5cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0a5d6:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0a5de:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0a5ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0a5f3:	mov    rdx,rbx
    75b0bab0a5f6:	shr    rdx,0x10
    75b0bab0a5fa:	and    edx,0xc000
    75b0bab0a600:	mov    rax,rbx
    75b0bab0a603:	shr    rax,0x15
    75b0bab0a607:	and    eax,0x100
    75b0bab0a60c:	xor    eax,0x100
    75b0bab0a611:	or     edx,eax
    75b0bab0a613:	mov    rax,rbx
    75b0bab0a616:	shr    rax,0x1c
    75b0bab0a61a:	and    eax,0x1
    75b0bab0a61d:	or     edx,eax
    75b0bab0a61f:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0a624:	add    rsp,0x8
    75b0bab0a628:	ret
    75b0bab0a629:	nop    DWORD PTR [rax+0x0]
    75b0bab0a630:	sub    rsp,0x8
    75b0bab0a634:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0a640:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0a646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0a64c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab0a652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0a658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab0a65e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab0a668:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab0a672:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0a67c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab0a686:	push   rdx
    75b0bab0a687:	push   rsi
    75b0bab0a688:	push   r10
    75b0bab0a68a:	push   r11
    75b0bab0a68c:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0a691:	mov    r10d,edx
    75b0bab0a694:	and    r10d,0xc000
    75b0bab0a69b:	shl    r10d,0x10
    75b0bab0a69f:	mov    r11d,edx
    75b0bab0a6a2:	and    r11d,0x100
    75b0bab0a6a9:	shl    r11d,0x15
    75b0bab0a6ad:	or     r10d,r11d
    75b0bab0a6b0:	and    edx,0x1
    75b0bab0a6b3:	shl    edx,0x1c
    75b0bab0a6b6:	or     r10d,edx
    75b0bab0a6b9:	btc    r10,0x1d
    75b0bab0a6be:	mov    r11d,0xf0000000
    75b0bab0a6c4:	and    r11,r10
    75b0bab0a6c7:	movabs rsi,0xffffffff0fffffff
    75b0bab0a6d1:	and    rbx,rsi
    75b0bab0a6d4:	or     rbx,r11
    75b0bab0a6d7:	pop    r11
    75b0bab0a6d9:	pop    r10
    75b0bab0a6db:	pop    rsi
    75b0bab0a6dc:	pop    rdx
    75b0bab0a6dd:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0a6e5:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0a6eb:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0a6f0:	test   r10d,0x3f
    75b0bab0a6f7:	je     0x75b0bab0a71c
    75b0bab0a6fd:	mov    r11d,r10d
    75b0bab0a700:	shr    r10d,1
    75b0bab0a703:	and    r10d,0x1e
    75b0bab0a707:	and    r11d,0x1
    75b0bab0a70b:	or     r10d,r11d
    75b0bab0a70e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0a716:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0a71c:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0a722:	lea    rdi,[rsp+0x110]
    75b0bab0a72a:	lea    rsi,[rsp+0xf0]
    75b0bab0a732:	lea    rdx,[rsp+0x100]
    75b0bab0a73a:	mov    ecx,0x14
    75b0bab0a73f:	mov    r8d,0x0
    75b0bab0a745:	lea    r9,[r12+0x314]
    75b0bab0a74d:	movabs r11,0x59d8f4f27650
    75b0bab0a757:	call   r11
    75b0bab0a75a:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0a760:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0a766:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0a76c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0a772:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0a778:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0a77e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab0a788:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0a792:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0a79c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0a7a6:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0a7ae:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0a7ba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0a7c3:	mov    rdx,rbx
    75b0bab0a7c6:	shr    rdx,0x10
    75b0bab0a7ca:	and    edx,0xc000
    75b0bab0a7d0:	mov    rax,rbx
    75b0bab0a7d3:	shr    rax,0x15
    75b0bab0a7d7:	and    eax,0x100
    75b0bab0a7dc:	xor    eax,0x100
    75b0bab0a7e1:	or     edx,eax
    75b0bab0a7e3:	mov    rax,rbx
    75b0bab0a7e6:	shr    rax,0x1c
    75b0bab0a7ea:	and    eax,0x1
    75b0bab0a7ed:	or     edx,eax
    75b0bab0a7ef:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0a7f4:	add    rsp,0x8
    75b0bab0a7f8:	ret
    75b0bab0a7f9:	nop    DWORD PTR [rax+0x0]
    75b0bab0a800:	sub    rsp,0x8
    75b0bab0a804:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0a810:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0a816:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0a81c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab0a822:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0a828:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab0a82e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab0a838:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0a842:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab0a84c:	push   rdx
    75b0bab0a84d:	push   rsi
    75b0bab0a84e:	push   r10
    75b0bab0a850:	push   r11
    75b0bab0a852:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0a857:	mov    r10d,edx
    75b0bab0a85a:	and    r10d,0xc000
    75b0bab0a861:	shl    r10d,0x10
    75b0bab0a865:	mov    r11d,edx
    75b0bab0a868:	and    r11d,0x100
    75b0bab0a86f:	shl    r11d,0x15
    75b0bab0a873:	or     r10d,r11d
    75b0bab0a876:	and    edx,0x1
    75b0bab0a879:	shl    edx,0x1c
    75b0bab0a87c:	or     r10d,edx
    75b0bab0a87f:	btc    r10,0x1d
    75b0bab0a884:	mov    r11d,0xf0000000
    75b0bab0a88a:	and    r11,r10
    75b0bab0a88d:	movabs rsi,0xffffffff0fffffff
    75b0bab0a897:	and    rbx,rsi
    75b0bab0a89a:	or     rbx,r11
    75b0bab0a89d:	pop    r11
    75b0bab0a89f:	pop    r10
    75b0bab0a8a1:	pop    rsi
    75b0bab0a8a2:	pop    rdx
    75b0bab0a8a3:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0a8ab:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0a8b1:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0a8b6:	test   r10d,0x3f
    75b0bab0a8bd:	je     0x75b0bab0a8e2
    75b0bab0a8c3:	mov    r11d,r10d
    75b0bab0a8c6:	shr    r10d,1
    75b0bab0a8c9:	and    r10d,0x1e
    75b0bab0a8cd:	and    r11d,0x1
    75b0bab0a8d1:	or     r10d,r11d
    75b0bab0a8d4:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0a8dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0a8e2:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0a8e8:	lea    rdi,[rsp+0x110]
    75b0bab0a8f0:	lea    rsi,[rsp+0xf0]
    75b0bab0a8f8:	lea    rdx,[rsp+0x100]
    75b0bab0a900:	mov    ecx,0x14
    75b0bab0a905:	mov    r8d,0x0
    75b0bab0a90b:	lea    r9,[r12+0x314]
    75b0bab0a913:	movabs r11,0x59d8f4f27650
    75b0bab0a91d:	call   r11
    75b0bab0a920:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0a926:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0a92c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0a932:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0a938:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0a93e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0a944:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0a94e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0a958:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab0a962:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0a96a:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0a976:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0a97f:	mov    rdx,rbx
    75b0bab0a982:	shr    rdx,0x10
    75b0bab0a986:	and    edx,0xc000
    75b0bab0a98c:	mov    rax,rbx
    75b0bab0a98f:	shr    rax,0x15
    75b0bab0a993:	and    eax,0x100
    75b0bab0a998:	xor    eax,0x100
    75b0bab0a99d:	or     edx,eax
    75b0bab0a99f:	mov    rax,rbx
    75b0bab0a9a2:	shr    rax,0x1c
    75b0bab0a9a6:	and    eax,0x1
    75b0bab0a9a9:	or     edx,eax
    75b0bab0a9ab:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0a9b0:	add    rsp,0x8
    75b0bab0a9b4:	ret
    75b0bab0a9b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab0a9c0:	sub    rsp,0x8
    75b0bab0a9c4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0a9d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0a9d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0a9dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0a9e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab0a9e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0a9ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab0a9f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0aa02:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab0aa0c:	push   rdx
    75b0bab0aa0d:	push   rsi
    75b0bab0aa0e:	push   r10
    75b0bab0aa10:	push   r11
    75b0bab0aa12:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0aa17:	mov    r10d,edx
    75b0bab0aa1a:	and    r10d,0xc000
    75b0bab0aa21:	shl    r10d,0x10
    75b0bab0aa25:	mov    r11d,edx
    75b0bab0aa28:	and    r11d,0x100
    75b0bab0aa2f:	shl    r11d,0x15
    75b0bab0aa33:	or     r10d,r11d
    75b0bab0aa36:	and    edx,0x1
    75b0bab0aa39:	shl    edx,0x1c
    75b0bab0aa3c:	or     r10d,edx
    75b0bab0aa3f:	btc    r10,0x1d
    75b0bab0aa44:	mov    r11d,0xf0000000
    75b0bab0aa4a:	and    r11,r10
    75b0bab0aa4d:	movabs rsi,0xffffffff0fffffff
    75b0bab0aa57:	and    rbx,rsi
    75b0bab0aa5a:	or     rbx,r11
    75b0bab0aa5d:	pop    r11
    75b0bab0aa5f:	pop    r10
    75b0bab0aa61:	pop    rsi
    75b0bab0aa62:	pop    rdx
    75b0bab0aa63:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0aa6b:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0aa71:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0aa76:	test   r10d,0x3f
    75b0bab0aa7d:	je     0x75b0bab0aaa2
    75b0bab0aa83:	mov    r11d,r10d
    75b0bab0aa86:	shr    r10d,1
    75b0bab0aa89:	and    r10d,0x1e
    75b0bab0aa8d:	and    r11d,0x1
    75b0bab0aa91:	or     r10d,r11d
    75b0bab0aa94:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0aa9c:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0aaa2:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0aaa8:	lea    rdi,[rsp+0x110]
    75b0bab0aab0:	lea    rsi,[rsp+0xf0]
    75b0bab0aab8:	lea    rdx,[rsp+0x100]
    75b0bab0aac0:	mov    ecx,0x14
    75b0bab0aac5:	mov    r8d,0x0
    75b0bab0aacb:	lea    r9,[r12+0x314]
    75b0bab0aad3:	movabs r11,0x59d8f4f27650
    75b0bab0aadd:	call   r11
    75b0bab0aae0:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0aae6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0aaec:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0aaf2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0aaf8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0aafe:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0ab04:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0ab0e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0ab18:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab0ab22:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0ab2a:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0ab36:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0ab3f:	mov    rdx,rbx
    75b0bab0ab42:	shr    rdx,0x10
    75b0bab0ab46:	and    edx,0xc000
    75b0bab0ab4c:	mov    rax,rbx
    75b0bab0ab4f:	shr    rax,0x15
    75b0bab0ab53:	and    eax,0x100
    75b0bab0ab58:	xor    eax,0x100
    75b0bab0ab5d:	or     edx,eax
    75b0bab0ab5f:	mov    rax,rbx
    75b0bab0ab62:	shr    rax,0x1c
    75b0bab0ab66:	and    eax,0x1
    75b0bab0ab69:	or     edx,eax
    75b0bab0ab6b:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0ab70:	add    rsp,0x8
    75b0bab0ab74:	ret
    75b0bab0ab75:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab0ab80:	sub    rsp,0x8
    75b0bab0ab84:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0ab90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0ab96:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0ab9c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0aba2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab0aba8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0abae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab0abb4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0abbe:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab0abc8:	push   rdx
    75b0bab0abc9:	push   rsi
    75b0bab0abca:	push   r10
    75b0bab0abcc:	push   r11
    75b0bab0abce:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0abd3:	mov    r10d,edx
    75b0bab0abd6:	and    r10d,0xc000
    75b0bab0abdd:	shl    r10d,0x10
    75b0bab0abe1:	mov    r11d,edx
    75b0bab0abe4:	and    r11d,0x100
    75b0bab0abeb:	shl    r11d,0x15
    75b0bab0abef:	or     r10d,r11d
    75b0bab0abf2:	and    edx,0x1
    75b0bab0abf5:	shl    edx,0x1c
    75b0bab0abf8:	or     r10d,edx
    75b0bab0abfb:	btc    r10,0x1d
    75b0bab0ac00:	mov    r11d,0xf0000000
    75b0bab0ac06:	and    r11,r10
    75b0bab0ac09:	movabs rsi,0xffffffff0fffffff
    75b0bab0ac13:	and    rbx,rsi
    75b0bab0ac16:	or     rbx,r11
    75b0bab0ac19:	pop    r11
    75b0bab0ac1b:	pop    r10
    75b0bab0ac1d:	pop    rsi
    75b0bab0ac1e:	pop    rdx
    75b0bab0ac1f:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0ac27:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0ac2d:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0ac32:	test   r10d,0x3f
    75b0bab0ac39:	je     0x75b0bab0ac5e
    75b0bab0ac3f:	mov    r11d,r10d
    75b0bab0ac42:	shr    r10d,1
    75b0bab0ac45:	and    r10d,0x1e
    75b0bab0ac49:	and    r11d,0x1
    75b0bab0ac4d:	or     r10d,r11d
    75b0bab0ac50:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0ac58:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0ac5e:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0ac64:	lea    rdi,[rsp+0x110]
    75b0bab0ac6c:	lea    rsi,[rsp+0xf0]
    75b0bab0ac74:	lea    rdx,[rsp+0x100]
    75b0bab0ac7c:	mov    ecx,0x56
    75b0bab0ac81:	mov    r8d,0x0
    75b0bab0ac87:	lea    r9,[r12+0x314]
    75b0bab0ac8f:	movabs r11,0x59d8f4f27650
    75b0bab0ac99:	call   r11
    75b0bab0ac9c:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0aca2:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0aca8:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0acae:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0acb4:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0acba:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0acc0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0acc6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0acd0:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab0acda:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0ace2:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0acee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0acf7:	mov    rdx,rbx
    75b0bab0acfa:	shr    rdx,0x10
    75b0bab0acfe:	and    edx,0xc000
    75b0bab0ad04:	mov    rax,rbx
    75b0bab0ad07:	shr    rax,0x15
    75b0bab0ad0b:	and    eax,0x100
    75b0bab0ad10:	xor    eax,0x100
    75b0bab0ad15:	or     edx,eax
    75b0bab0ad17:	mov    rax,rbx
    75b0bab0ad1a:	shr    rax,0x1c
    75b0bab0ad1e:	and    eax,0x1
    75b0bab0ad21:	or     edx,eax
    75b0bab0ad23:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0ad28:	add    rsp,0x8
    75b0bab0ad2c:	ret
    75b0bab0ad2d:	nop    DWORD PTR [rax]
    75b0bab0ad30:	sub    rsp,0x8
    75b0bab0ad34:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0ad40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0ad46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0ad4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0ad52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab0ad58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab0ad5e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab0ad68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0ad72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab0ad7c:	push   rdx
    75b0bab0ad7d:	push   rsi
    75b0bab0ad7e:	push   r10
    75b0bab0ad80:	push   r11
    75b0bab0ad82:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0ad87:	mov    r10d,edx
    75b0bab0ad8a:	and    r10d,0xc000
    75b0bab0ad91:	shl    r10d,0x10
    75b0bab0ad95:	mov    r11d,edx
    75b0bab0ad98:	and    r11d,0x100
    75b0bab0ad9f:	shl    r11d,0x15
    75b0bab0ada3:	or     r10d,r11d
    75b0bab0ada6:	and    edx,0x1
    75b0bab0ada9:	shl    edx,0x1c
    75b0bab0adac:	or     r10d,edx
    75b0bab0adaf:	btc    r10,0x1d
    75b0bab0adb4:	mov    r11d,0xf0000000
    75b0bab0adba:	and    r11,r10
    75b0bab0adbd:	movabs rsi,0xffffffff0fffffff
    75b0bab0adc7:	and    rbx,rsi
    75b0bab0adca:	or     rbx,r11
    75b0bab0adcd:	pop    r11
    75b0bab0adcf:	pop    r10
    75b0bab0add1:	pop    rsi
    75b0bab0add2:	pop    rdx
    75b0bab0add3:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0addb:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0ade1:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0ade6:	test   r10d,0x3f
    75b0bab0aded:	je     0x75b0bab0ae12
    75b0bab0adf3:	mov    r11d,r10d
    75b0bab0adf6:	shr    r10d,1
    75b0bab0adf9:	and    r10d,0x1e
    75b0bab0adfd:	and    r11d,0x1
    75b0bab0ae01:	or     r10d,r11d
    75b0bab0ae04:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0ae0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0ae12:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0ae18:	lea    rdi,[rsp+0x110]
    75b0bab0ae20:	lea    rsi,[rsp+0xf0]
    75b0bab0ae28:	lea    rdx,[rsp+0x100]
    75b0bab0ae30:	mov    ecx,0x56
    75b0bab0ae35:	mov    r8d,0x0
    75b0bab0ae3b:	lea    r9,[r12+0x314]
    75b0bab0ae43:	movabs r11,0x59d8f4f27650
    75b0bab0ae4d:	call   r11
    75b0bab0ae50:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0ae56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0ae5c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0ae62:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0ae68:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0ae6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0ae74:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab0ae7e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0ae88:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab0ae92:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0ae9a:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0aea6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0aeaf:	mov    rdx,rbx
    75b0bab0aeb2:	shr    rdx,0x10
    75b0bab0aeb6:	and    edx,0xc000
    75b0bab0aebc:	mov    rax,rbx
    75b0bab0aebf:	shr    rax,0x15
    75b0bab0aec3:	and    eax,0x100
    75b0bab0aec8:	xor    eax,0x100
    75b0bab0aecd:	or     edx,eax
    75b0bab0aecf:	mov    rax,rbx
    75b0bab0aed2:	shr    rax,0x1c
    75b0bab0aed6:	and    eax,0x1
    75b0bab0aed9:	or     edx,eax
    75b0bab0aedb:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0aee0:	add    rsp,0x8
    75b0bab0aee4:	ret
    75b0bab0aee5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab0aef0:	sub    rsp,0x8
    75b0bab0aef4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0af00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0af06:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0af0c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0af12:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab0af18:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0af1e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab0af24:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab0af2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0af38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    75b0bab0af42:	push   rdx
    75b0bab0af43:	push   rsi
    75b0bab0af44:	push   r10
    75b0bab0af46:	push   r11
    75b0bab0af48:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0af4d:	mov    r10d,edx
    75b0bab0af50:	and    r10d,0xc000
    75b0bab0af57:	shl    r10d,0x10
    75b0bab0af5b:	mov    r11d,edx
    75b0bab0af5e:	and    r11d,0x100
    75b0bab0af65:	shl    r11d,0x15
    75b0bab0af69:	or     r10d,r11d
    75b0bab0af6c:	and    edx,0x1
    75b0bab0af6f:	shl    edx,0x1c
    75b0bab0af72:	or     r10d,edx
    75b0bab0af75:	btc    r10,0x1d
    75b0bab0af7a:	mov    r11d,0xf0000000
    75b0bab0af80:	and    r11,r10
    75b0bab0af83:	movabs rsi,0xffffffff0fffffff
    75b0bab0af8d:	and    rbx,rsi
    75b0bab0af90:	or     rbx,r11
    75b0bab0af93:	pop    r11
    75b0bab0af95:	pop    r10
    75b0bab0af97:	pop    rsi
    75b0bab0af98:	pop    rdx
    75b0bab0af99:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0afa1:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0afa7:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0afac:	test   r10d,0x3f
    75b0bab0afb3:	je     0x75b0bab0afd8
    75b0bab0afb9:	mov    r11d,r10d
    75b0bab0afbc:	shr    r10d,1
    75b0bab0afbf:	and    r10d,0x1e
    75b0bab0afc3:	and    r11d,0x1
    75b0bab0afc7:	or     r10d,r11d
    75b0bab0afca:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0afd2:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0afd8:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0afde:	lea    rdi,[rsp+0x110]
    75b0bab0afe6:	lea    rsi,[rsp+0xf0]
    75b0bab0afee:	lea    rdx,[rsp+0x100]
    75b0bab0aff6:	mov    ecx,0x14
    75b0bab0affb:	mov    r8d,0x0
    75b0bab0b001:	lea    r9,[r12+0x314]
    75b0bab0b009:	movabs r11,0x59d8f4f27650
    75b0bab0b013:	call   r11
    75b0bab0b016:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0b01c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0b022:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0b028:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0b02e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0b034:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0b03a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0b040:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab0b04a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0b054:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b0bab0b05e:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0b066:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0b072:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0b07b:	mov    rdx,rbx
    75b0bab0b07e:	shr    rdx,0x10
    75b0bab0b082:	and    edx,0xc000
    75b0bab0b088:	mov    rax,rbx
    75b0bab0b08b:	shr    rax,0x15
    75b0bab0b08f:	and    eax,0x100
    75b0bab0b094:	xor    eax,0x100
    75b0bab0b099:	or     edx,eax
    75b0bab0b09b:	mov    rax,rbx
    75b0bab0b09e:	shr    rax,0x1c
    75b0bab0b0a2:	and    eax,0x1
    75b0bab0b0a5:	or     edx,eax
    75b0bab0b0a7:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0b0ac:	add    rsp,0x8
    75b0bab0b0b0:	ret
    75b0bab0b0b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab0b0c0:	sub    rsp,0x8
    75b0bab0b0c4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0b0d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0b0d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0b0dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab0b0e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0b0e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab0b0ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab0b0f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab0b102:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0b10c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab0b116:	push   rdx
    75b0bab0b117:	push   rsi
    75b0bab0b118:	push   r10
    75b0bab0b11a:	push   r11
    75b0bab0b11c:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0b121:	mov    r10d,edx
    75b0bab0b124:	and    r10d,0xc000
    75b0bab0b12b:	shl    r10d,0x10
    75b0bab0b12f:	mov    r11d,edx
    75b0bab0b132:	and    r11d,0x100
    75b0bab0b139:	shl    r11d,0x15
    75b0bab0b13d:	or     r10d,r11d
    75b0bab0b140:	and    edx,0x1
    75b0bab0b143:	shl    edx,0x1c
    75b0bab0b146:	or     r10d,edx
    75b0bab0b149:	btc    r10,0x1d
    75b0bab0b14e:	mov    r11d,0xf0000000
    75b0bab0b154:	and    r11,r10
    75b0bab0b157:	movabs rsi,0xffffffff0fffffff
    75b0bab0b161:	and    rbx,rsi
    75b0bab0b164:	or     rbx,r11
    75b0bab0b167:	pop    r11
    75b0bab0b169:	pop    r10
    75b0bab0b16b:	pop    rsi
    75b0bab0b16c:	pop    rdx
    75b0bab0b16d:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0b175:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0b17b:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0b180:	test   r10d,0x3f
    75b0bab0b187:	je     0x75b0bab0b1ac
    75b0bab0b18d:	mov    r11d,r10d
    75b0bab0b190:	shr    r10d,1
    75b0bab0b193:	and    r10d,0x1e
    75b0bab0b197:	and    r11d,0x1
    75b0bab0b19b:	or     r10d,r11d
    75b0bab0b19e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0b1a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0b1ac:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0b1b2:	lea    rdi,[rsp+0x110]
    75b0bab0b1ba:	lea    rsi,[rsp+0xf0]
    75b0bab0b1c2:	lea    rdx,[rsp+0x100]
    75b0bab0b1ca:	mov    ecx,0x56
    75b0bab0b1cf:	mov    r8d,0x0
    75b0bab0b1d5:	lea    r9,[r12+0x314]
    75b0bab0b1dd:	movabs r11,0x59d8f4f27650
    75b0bab0b1e7:	call   r11
    75b0bab0b1ea:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0b1f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0b1f6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0b1fc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0b202:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0b208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0b20e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab0b218:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0b222:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0b22c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0b236:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0b23e:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0b24a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0b253:	mov    rdx,rbx
    75b0bab0b256:	shr    rdx,0x10
    75b0bab0b25a:	and    edx,0xc000
    75b0bab0b260:	mov    rax,rbx
    75b0bab0b263:	shr    rax,0x15
    75b0bab0b267:	and    eax,0x100
    75b0bab0b26c:	xor    eax,0x100
    75b0bab0b271:	or     edx,eax
    75b0bab0b273:	mov    rax,rbx
    75b0bab0b276:	shr    rax,0x1c
    75b0bab0b27a:	and    eax,0x1
    75b0bab0b27d:	or     edx,eax
    75b0bab0b27f:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0b284:	add    rsp,0x8
    75b0bab0b288:	ret
    75b0bab0b289:	nop    DWORD PTR [rax+0x0]
    75b0bab0b290:	sub    rsp,0x8
    75b0bab0b294:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0b2a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0b2a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0b2ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0b2b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab0b2b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0b2be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab0b2c4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    75b0bab0b2ce:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab0b2d8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab0b2e2:	push   rdx
    75b0bab0b2e3:	push   rsi
    75b0bab0b2e4:	push   r10
    75b0bab0b2e6:	push   r11
    75b0bab0b2e8:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0b2ed:	mov    r10d,edx
    75b0bab0b2f0:	and    r10d,0xc000
    75b0bab0b2f7:	shl    r10d,0x10
    75b0bab0b2fb:	mov    r11d,edx
    75b0bab0b2fe:	and    r11d,0x100
    75b0bab0b305:	shl    r11d,0x15
    75b0bab0b309:	or     r10d,r11d
    75b0bab0b30c:	and    edx,0x1
    75b0bab0b30f:	shl    edx,0x1c
    75b0bab0b312:	or     r10d,edx
    75b0bab0b315:	btc    r10,0x1d
    75b0bab0b31a:	mov    r11d,0xf0000000
    75b0bab0b320:	and    r11,r10
    75b0bab0b323:	movabs rsi,0xffffffff0fffffff
    75b0bab0b32d:	and    rbx,rsi
    75b0bab0b330:	or     rbx,r11
    75b0bab0b333:	pop    r11
    75b0bab0b335:	pop    r10
    75b0bab0b337:	pop    rsi
    75b0bab0b338:	pop    rdx
    75b0bab0b339:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0b341:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0b347:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0b34c:	test   r10d,0x3f
    75b0bab0b353:	je     0x75b0bab0b378
    75b0bab0b359:	mov    r11d,r10d
    75b0bab0b35c:	shr    r10d,1
    75b0bab0b35f:	and    r10d,0x1e
    75b0bab0b363:	and    r11d,0x1
    75b0bab0b367:	or     r10d,r11d
    75b0bab0b36a:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0b372:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0b378:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0b37e:	lea    rdi,[rsp+0x110]
    75b0bab0b386:	lea    rsi,[rsp+0xf0]
    75b0bab0b38e:	lea    rdx,[rsp+0x100]
    75b0bab0b396:	mov    ecx,0x56
    75b0bab0b39b:	mov    r8d,0x0
    75b0bab0b3a1:	lea    r9,[r12+0x314]
    75b0bab0b3a9:	movabs r11,0x59d8f4f27650
    75b0bab0b3b3:	call   r11
    75b0bab0b3b6:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0b3bc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0b3c2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0b3c8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0b3ce:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0b3d4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0b3da:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0b3e0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75b0bab0b3ea:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0b3f4:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0b3fe:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0b406:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0b412:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0b41b:	mov    rdx,rbx
    75b0bab0b41e:	shr    rdx,0x10
    75b0bab0b422:	and    edx,0xc000
    75b0bab0b428:	mov    rax,rbx
    75b0bab0b42b:	shr    rax,0x15
    75b0bab0b42f:	and    eax,0x100
    75b0bab0b434:	xor    eax,0x100
    75b0bab0b439:	or     edx,eax
    75b0bab0b43b:	mov    rax,rbx
    75b0bab0b43e:	shr    rax,0x1c
    75b0bab0b442:	and    eax,0x1
    75b0bab0b445:	or     edx,eax
    75b0bab0b447:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0b44c:	add    rsp,0x8
    75b0bab0b450:	ret
    75b0bab0b451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab0b460:	sub    rsp,0x8
    75b0bab0b464:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0b470:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0b476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0b47c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    75b0bab0b482:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    75b0bab0b488:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab0b492:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0b49c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab0b4a6:	push   rdx
    75b0bab0b4a7:	push   rsi
    75b0bab0b4a8:	push   r10
    75b0bab0b4aa:	push   r11
    75b0bab0b4ac:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0b4b1:	mov    r10d,edx
    75b0bab0b4b4:	and    r10d,0xc000
    75b0bab0b4bb:	shl    r10d,0x10
    75b0bab0b4bf:	mov    r11d,edx
    75b0bab0b4c2:	and    r11d,0x100
    75b0bab0b4c9:	shl    r11d,0x15
    75b0bab0b4cd:	or     r10d,r11d
    75b0bab0b4d0:	and    edx,0x1
    75b0bab0b4d3:	shl    edx,0x1c
    75b0bab0b4d6:	or     r10d,edx
    75b0bab0b4d9:	btc    r10,0x1d
    75b0bab0b4de:	mov    r11d,0xf0000000
    75b0bab0b4e4:	and    r11,r10
    75b0bab0b4e7:	movabs rsi,0xffffffff0fffffff
    75b0bab0b4f1:	and    rbx,rsi
    75b0bab0b4f4:	or     rbx,r11
    75b0bab0b4f7:	pop    r11
    75b0bab0b4f9:	pop    r10
    75b0bab0b4fb:	pop    rsi
    75b0bab0b4fc:	pop    rdx
    75b0bab0b4fd:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0b505:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0b50b:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0b510:	test   r10d,0x3f
    75b0bab0b517:	je     0x75b0bab0b53c
    75b0bab0b51d:	mov    r11d,r10d
    75b0bab0b520:	shr    r10d,1
    75b0bab0b523:	and    r10d,0x1e
    75b0bab0b527:	and    r11d,0x1
    75b0bab0b52b:	or     r10d,r11d
    75b0bab0b52e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0b536:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0b53c:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0b542:	lea    rdi,[rsp+0x110]
    75b0bab0b54a:	lea    rsi,[rsp+0xf0]
    75b0bab0b552:	lea    rdx,[rsp+0x100]
    75b0bab0b55a:	mov    ecx,0x14
    75b0bab0b55f:	mov    r8d,0x0
    75b0bab0b565:	lea    r9,[r12+0x314]
    75b0bab0b56d:	movabs r11,0x59d8f4f27650
    75b0bab0b577:	call   r11
    75b0bab0b57a:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0b580:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0b586:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0b58c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    75b0bab0b592:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75b0bab0b598:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0b5a2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0b5ac:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0b5b6:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0b5be:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0b5ca:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0b5d3:	mov    rdx,rbx
    75b0bab0b5d6:	shr    rdx,0x10
    75b0bab0b5da:	and    edx,0xc000
    75b0bab0b5e0:	mov    rax,rbx
    75b0bab0b5e3:	shr    rax,0x15
    75b0bab0b5e7:	and    eax,0x100
    75b0bab0b5ec:	xor    eax,0x100
    75b0bab0b5f1:	or     edx,eax
    75b0bab0b5f3:	mov    rax,rbx
    75b0bab0b5f6:	shr    rax,0x1c
    75b0bab0b5fa:	and    eax,0x1
    75b0bab0b5fd:	or     edx,eax
    75b0bab0b5ff:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0b604:	add    rsp,0x8
    75b0bab0b608:	ret
    75b0bab0b609:	nop    DWORD PTR [rax+0x0]
    75b0bab0b610:	sub    rsp,0x8
    75b0bab0b614:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0b620:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0b626:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0b62c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0b632:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    75b0bab0b63c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0b646:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab0b650:	push   rdx
    75b0bab0b651:	push   rsi
    75b0bab0b652:	push   r10
    75b0bab0b654:	push   r11
    75b0bab0b656:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0b65b:	mov    r10d,edx
    75b0bab0b65e:	and    r10d,0xc000
    75b0bab0b665:	shl    r10d,0x10
    75b0bab0b669:	mov    r11d,edx
    75b0bab0b66c:	and    r11d,0x100
    75b0bab0b673:	shl    r11d,0x15
    75b0bab0b677:	or     r10d,r11d
    75b0bab0b67a:	and    edx,0x1
    75b0bab0b67d:	shl    edx,0x1c
    75b0bab0b680:	or     r10d,edx
    75b0bab0b683:	btc    r10,0x1d
    75b0bab0b688:	mov    r11d,0xf0000000
    75b0bab0b68e:	and    r11,r10
    75b0bab0b691:	movabs rsi,0xffffffff0fffffff
    75b0bab0b69b:	and    rbx,rsi
    75b0bab0b69e:	or     rbx,r11
    75b0bab0b6a1:	pop    r11
    75b0bab0b6a3:	pop    r10
    75b0bab0b6a5:	pop    rsi
    75b0bab0b6a6:	pop    rdx
    75b0bab0b6a7:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0b6af:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0b6b5:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0b6ba:	test   r10d,0x3f
    75b0bab0b6c1:	je     0x75b0bab0b6e6
    75b0bab0b6c7:	mov    r11d,r10d
    75b0bab0b6ca:	shr    r10d,1
    75b0bab0b6cd:	and    r10d,0x1e
    75b0bab0b6d1:	and    r11d,0x1
    75b0bab0b6d5:	or     r10d,r11d
    75b0bab0b6d8:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0b6e0:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0b6e6:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0b6ec:	lea    rdi,[rsp+0x110]
    75b0bab0b6f4:	lea    rsi,[rsp+0xf0]
    75b0bab0b6fc:	lea    rdx,[rsp+0x100]
    75b0bab0b704:	mov    ecx,0x14
    75b0bab0b709:	mov    r8d,0x0
    75b0bab0b70f:	lea    r9,[r12+0x314]
    75b0bab0b717:	movabs r11,0x59d8f4f27650
    75b0bab0b721:	call   r11
    75b0bab0b724:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0b72a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0b730:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0b736:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0b73c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    75b0bab0b746:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0b750:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0b75a:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0b762:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0b76e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0b777:	mov    rdx,rbx
    75b0bab0b77a:	shr    rdx,0x10
    75b0bab0b77e:	and    edx,0xc000
    75b0bab0b784:	mov    rax,rbx
    75b0bab0b787:	shr    rax,0x15
    75b0bab0b78b:	and    eax,0x100
    75b0bab0b790:	xor    eax,0x100
    75b0bab0b795:	or     edx,eax
    75b0bab0b797:	mov    rax,rbx
    75b0bab0b79a:	shr    rax,0x1c
    75b0bab0b79e:	and    eax,0x1
    75b0bab0b7a1:	or     edx,eax
    75b0bab0b7a3:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0b7a8:	add    rsp,0x8
    75b0bab0b7ac:	ret
    75b0bab0b7ad:	nop    DWORD PTR [rax]
    75b0bab0b7b0:	sub    rsp,0x8
    75b0bab0b7b4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0b7c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0b7c6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0b7cc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    75b0bab0b7d2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    75b0bab0b7dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    75b0bab0b7e6:	push   rdx
    75b0bab0b7e7:	push   rsi
    75b0bab0b7e8:	push   r10
    75b0bab0b7ea:	push   r11
    75b0bab0b7ec:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0b7f1:	mov    r10d,edx
    75b0bab0b7f4:	and    r10d,0xc000
    75b0bab0b7fb:	shl    r10d,0x10
    75b0bab0b7ff:	mov    r11d,edx
    75b0bab0b802:	and    r11d,0x100
    75b0bab0b809:	shl    r11d,0x15
    75b0bab0b80d:	or     r10d,r11d
    75b0bab0b810:	and    edx,0x1
    75b0bab0b813:	shl    edx,0x1c
    75b0bab0b816:	or     r10d,edx
    75b0bab0b819:	btc    r10,0x1d
    75b0bab0b81e:	mov    r11d,0xf0000000
    75b0bab0b824:	and    r11,r10
    75b0bab0b827:	movabs rsi,0xffffffff0fffffff
    75b0bab0b831:	and    rbx,rsi
    75b0bab0b834:	or     rbx,r11
    75b0bab0b837:	pop    r11
    75b0bab0b839:	pop    r10
    75b0bab0b83b:	pop    rsi
    75b0bab0b83c:	pop    rdx
    75b0bab0b83d:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0b845:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0b84b:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0b850:	test   r10d,0x3f
    75b0bab0b857:	je     0x75b0bab0b87c
    75b0bab0b85d:	mov    r11d,r10d
    75b0bab0b860:	shr    r10d,1
    75b0bab0b863:	and    r10d,0x1e
    75b0bab0b867:	and    r11d,0x1
    75b0bab0b86b:	or     r10d,r11d
    75b0bab0b86e:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0b876:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0b87c:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0b882:	lea    rdi,[rsp+0x110]
    75b0bab0b88a:	lea    rsi,[rsp+0xf0]
    75b0bab0b892:	lea    rdx,[rsp+0x100]
    75b0bab0b89a:	mov    ecx,0x14
    75b0bab0b89f:	mov    r8d,0x0
    75b0bab0b8a5:	lea    r9,[r12+0x314]
    75b0bab0b8ad:	movabs r11,0x59d8f4f27650
    75b0bab0b8b7:	call   r11
    75b0bab0b8ba:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0b8c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0b8c6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0b8cc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    75b0bab0b8d2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    75b0bab0b8dc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75b0bab0b8e6:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0b8ee:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0b8fa:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0b903:	mov    rdx,rbx
    75b0bab0b906:	shr    rdx,0x10
    75b0bab0b90a:	and    edx,0xc000
    75b0bab0b910:	mov    rax,rbx
    75b0bab0b913:	shr    rax,0x15
    75b0bab0b917:	and    eax,0x100
    75b0bab0b91c:	xor    eax,0x100
    75b0bab0b921:	or     edx,eax
    75b0bab0b923:	mov    rax,rbx
    75b0bab0b926:	shr    rax,0x1c
    75b0bab0b92a:	and    eax,0x1
    75b0bab0b92d:	or     edx,eax
    75b0bab0b92f:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0b934:	add    rsp,0x8
    75b0bab0b938:	ret
    75b0bab0b939:	nop    DWORD PTR [rax+0x0]
    75b0bab0b940:	sub    rsp,0x8
    75b0bab0b944:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0b950:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0b956:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75b0bab0b95c:	push   rdx
    75b0bab0b95d:	push   rsi
    75b0bab0b95e:	push   r10
    75b0bab0b960:	push   r11
    75b0bab0b962:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0b967:	mov    r10d,edx
    75b0bab0b96a:	and    r10d,0xc000
    75b0bab0b971:	shl    r10d,0x10
    75b0bab0b975:	mov    r11d,edx
    75b0bab0b978:	and    r11d,0x100
    75b0bab0b97f:	shl    r11d,0x15
    75b0bab0b983:	or     r10d,r11d
    75b0bab0b986:	and    edx,0x1
    75b0bab0b989:	shl    edx,0x1c
    75b0bab0b98c:	or     r10d,edx
    75b0bab0b98f:	btc    r10,0x1d
    75b0bab0b994:	mov    r11d,0xf0000000
    75b0bab0b99a:	and    r11,r10
    75b0bab0b99d:	movabs rsi,0xffffffff0fffffff
    75b0bab0b9a7:	and    rbx,rsi
    75b0bab0b9aa:	or     rbx,r11
    75b0bab0b9ad:	pop    r11
    75b0bab0b9af:	pop    r10
    75b0bab0b9b1:	pop    rsi
    75b0bab0b9b2:	pop    rdx
    75b0bab0b9b3:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0b9bb:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0b9c1:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0b9c6:	test   r10d,0x3f
    75b0bab0b9cd:	je     0x75b0bab0b9f2
    75b0bab0b9d3:	mov    r11d,r10d
    75b0bab0b9d6:	shr    r10d,1
    75b0bab0b9d9:	and    r10d,0x1e
    75b0bab0b9dd:	and    r11d,0x1
    75b0bab0b9e1:	or     r10d,r11d
    75b0bab0b9e4:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0b9ec:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0b9f2:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0b9f8:	lea    rdi,[rsp+0x110]
    75b0bab0ba00:	lea    rsi,[rsp+0xf0]
    75b0bab0ba08:	lea    rdx,[rsp+0x100]
    75b0bab0ba10:	mov    ecx,0xc
    75b0bab0ba15:	mov    r8d,0x0
    75b0bab0ba1b:	lea    r9,[r12+0x314]
    75b0bab0ba23:	movabs r11,0x59d8f4f27650
    75b0bab0ba2d:	call   r11
    75b0bab0ba30:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0ba36:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0ba3c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75b0bab0ba42:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0ba4a:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0ba56:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0ba5f:	mov    rdx,rbx
    75b0bab0ba62:	shr    rdx,0x10
    75b0bab0ba66:	and    edx,0xc000
    75b0bab0ba6c:	mov    rax,rbx
    75b0bab0ba6f:	shr    rax,0x15
    75b0bab0ba73:	and    eax,0x100
    75b0bab0ba78:	xor    eax,0x100
    75b0bab0ba7d:	or     edx,eax
    75b0bab0ba7f:	mov    rax,rbx
    75b0bab0ba82:	shr    rax,0x1c
    75b0bab0ba86:	and    eax,0x1
    75b0bab0ba89:	or     edx,eax
    75b0bab0ba8b:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0ba90:	add    rsp,0x8
    75b0bab0ba94:	ret
    75b0bab0ba95:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab0baa0:	sub    rsp,0x8
    75b0bab0baa4:	mov    QWORD PTR [r12+0x378],0x3
    75b0bab0bab0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75b0bab0bab6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    75b0bab0babc:	push   rdx
    75b0bab0babd:	push   rsi
    75b0bab0babe:	push   r10
    75b0bab0bac0:	push   r11
    75b0bab0bac2:	mov    rdx,QWORD PTR [rsp+0x30]
    75b0bab0bac7:	mov    r10d,edx
    75b0bab0baca:	and    r10d,0xc000
    75b0bab0bad1:	shl    r10d,0x10
    75b0bab0bad5:	mov    r11d,edx
    75b0bab0bad8:	and    r11d,0x100
    75b0bab0badf:	shl    r11d,0x15
    75b0bab0bae3:	or     r10d,r11d
    75b0bab0bae6:	and    edx,0x1
    75b0bab0bae9:	shl    edx,0x1c
    75b0bab0baec:	or     r10d,edx
    75b0bab0baef:	btc    r10,0x1d
    75b0bab0baf4:	mov    r11d,0xf0000000
    75b0bab0bafa:	and    r11,r10
    75b0bab0bafd:	movabs rsi,0xffffffff0fffffff
    75b0bab0bb07:	and    rbx,rsi
    75b0bab0bb0a:	or     rbx,r11
    75b0bab0bb0d:	pop    r11
    75b0bab0bb0f:	pop    r10
    75b0bab0bb11:	pop    rsi
    75b0bab0bb12:	pop    rdx
    75b0bab0bb13:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0bb1b:	stmxcsr DWORD PTR [r12-0x28]
    75b0bab0bb21:	mov    r10d,DWORD PTR [r12-0x28]
    75b0bab0bb26:	test   r10d,0x3f
    75b0bab0bb2d:	je     0x75b0bab0bb52
    75b0bab0bb33:	mov    r11d,r10d
    75b0bab0bb36:	shr    r10d,1
    75b0bab0bb39:	and    r10d,0x1e
    75b0bab0bb3d:	and    r11d,0x1
    75b0bab0bb41:	or     r10d,r11d
    75b0bab0bb44:	or     DWORD PTR [r12+0x314],r10d
    75b0bab0bb4c:	and    DWORD PTR [r12-0x28],0xffffffc0
    75b0bab0bb52:	ldmxcsr DWORD PTR [r12-0x38]
    75b0bab0bb58:	lea    rdi,[rsp+0x110]
    75b0bab0bb60:	lea    rsi,[rsp+0xf0]
    75b0bab0bb68:	lea    rdx,[rsp+0x100]
    75b0bab0bb70:	mov    ecx,0xc
    75b0bab0bb75:	mov    r8d,0x0
    75b0bab0bb7b:	lea    r9,[r12+0x314]
    75b0bab0bb83:	movabs r11,0x59d8f4f27650
    75b0bab0bb8d:	call   r11
    75b0bab0bb90:	ldmxcsr DWORD PTR [r12-0x28]
    75b0bab0bb96:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75b0bab0bb9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    75b0bab0bba2:	mov    rbx,QWORD PTR [r12+0x108]
    75b0bab0bbaa:	mov    QWORD PTR [r12+0x378],0x2
    75b0bab0bbb6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75b0bab0bbbf:	mov    rdx,rbx
    75b0bab0bbc2:	shr    rdx,0x10
    75b0bab0bbc6:	and    edx,0xc000
    75b0bab0bbcc:	mov    rax,rbx
    75b0bab0bbcf:	shr    rax,0x15
    75b0bab0bbd3:	and    eax,0x100
    75b0bab0bbd8:	xor    eax,0x100
    75b0bab0bbdd:	or     edx,eax
    75b0bab0bbdf:	mov    rax,rbx
    75b0bab0bbe2:	shr    rax,0x1c
    75b0bab0bbe6:	and    eax,0x1
    75b0bab0bbe9:	or     edx,eax
    75b0bab0bbeb:	mov    QWORD PTR [rsp+0x10],rdx
    75b0bab0bbf0:	add    rsp,0x8
    75b0bab0bbf4:	ret
    75b0bab0bbf5:	mov    eax,0x410400
    75b0bab0bbfa:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0bc02:	push   rdx
    75b0bab0bc03:	push   rsi
    75b0bab0bc04:	push   r10
    75b0bab0bc06:	push   r11
    75b0bab0bc08:	mov    r11,rax
    75b0bab0bc0b:	lahf
    75b0bab0bc0c:	seto   al
    75b0bab0bc0f:	mov    WORD PTR [rsp+0x20],ax
    75b0bab0bc14:	mov    rax,r11
    75b0bab0bc17:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0bc1c:	mov    r10d,edx
    75b0bab0bc1f:	and    r10d,0xc000
    75b0bab0bc26:	shl    r10d,0x10
    75b0bab0bc2a:	mov    r11d,edx
    75b0bab0bc2d:	and    r11d,0x100
    75b0bab0bc34:	shl    r11d,0x15
    75b0bab0bc38:	or     r10d,r11d
    75b0bab0bc3b:	and    edx,0x1
    75b0bab0bc3e:	shl    edx,0x1c
    75b0bab0bc41:	or     r10d,edx
    75b0bab0bc44:	btc    r10,0x1d
    75b0bab0bc49:	mov    r11d,0xf0000000
    75b0bab0bc4f:	and    r11,r10
    75b0bab0bc52:	movabs rsi,0xffffffff0fffffff
    75b0bab0bc5c:	and    rbx,rsi
    75b0bab0bc5f:	or     rbx,r11
    75b0bab0bc62:	pop    r11
    75b0bab0bc64:	pop    r10
    75b0bab0bc66:	pop    rsi
    75b0bab0bc67:	pop    rdx
    75b0bab0bc68:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0bc70:	add    rsp,0x150
    75b0bab0bc77:	mov    eax,0xc
    75b0bab0bc7c:	movabs r11,0x59d8f50c0ca0
    75b0bab0bc86:	jmp    r11
    75b0bab0bc89:	mov    eax,0x41048c
    75b0bab0bc8e:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0bc96:	push   rdx
    75b0bab0bc97:	push   rsi
    75b0bab0bc98:	push   r10
    75b0bab0bc9a:	push   r11
    75b0bab0bc9c:	mov    r11,rax
    75b0bab0bc9f:	lahf
    75b0bab0bca0:	seto   al
    75b0bab0bca3:	mov    WORD PTR [rsp+0x20],ax
    75b0bab0bca8:	mov    rax,r11
    75b0bab0bcab:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0bcb0:	mov    r10d,edx
    75b0bab0bcb3:	and    r10d,0xc000
    75b0bab0bcba:	shl    r10d,0x10
    75b0bab0bcbe:	mov    r11d,edx
    75b0bab0bcc1:	and    r11d,0x100
    75b0bab0bcc8:	shl    r11d,0x15
    75b0bab0bccc:	or     r10d,r11d
    75b0bab0bccf:	and    edx,0x1
    75b0bab0bcd2:	shl    edx,0x1c
    75b0bab0bcd5:	or     r10d,edx
    75b0bab0bcd8:	btc    r10,0x1d
    75b0bab0bcdd:	mov    r11d,0xf0000000
    75b0bab0bce3:	and    r11,r10
    75b0bab0bce6:	movabs rsi,0xffffffff0fffffff
    75b0bab0bcf0:	and    rbx,rsi
    75b0bab0bcf3:	or     rbx,r11
    75b0bab0bcf6:	pop    r11
    75b0bab0bcf8:	pop    r10
    75b0bab0bcfa:	pop    rsi
    75b0bab0bcfb:	pop    rdx
    75b0bab0bcfc:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0bd04:	add    rsp,0x150
    75b0bab0bd0b:	mov    eax,0xc
    75b0bab0bd10:	movabs r11,0x59d8f50c0ca0
    75b0bab0bd1a:	jmp    r11
    75b0bab0bd1d:	mov    eax,0x4106cc
    75b0bab0bd22:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0bd2a:	push   rdx
    75b0bab0bd2b:	push   rsi
    75b0bab0bd2c:	push   r10
    75b0bab0bd2e:	push   r11
    75b0bab0bd30:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0bd35:	mov    r10d,edx
    75b0bab0bd38:	and    r10d,0xc000
    75b0bab0bd3f:	shl    r10d,0x10
    75b0bab0bd43:	mov    r11d,edx
    75b0bab0bd46:	and    r11d,0x100
    75b0bab0bd4d:	shl    r11d,0x15
    75b0bab0bd51:	or     r10d,r11d
    75b0bab0bd54:	and    edx,0x1
    75b0bab0bd57:	shl    edx,0x1c
    75b0bab0bd5a:	or     r10d,edx
    75b0bab0bd5d:	btc    r10,0x1d
    75b0bab0bd62:	mov    r11d,0xf0000000
    75b0bab0bd68:	and    r11,r10
    75b0bab0bd6b:	movabs rsi,0xffffffff0fffffff
    75b0bab0bd75:	and    rbx,rsi
    75b0bab0bd78:	or     rbx,r11
    75b0bab0bd7b:	pop    r11
    75b0bab0bd7d:	pop    r10
    75b0bab0bd7f:	pop    rsi
    75b0bab0bd80:	pop    rdx
    75b0bab0bd81:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0bd89:	add    rsp,0x150
    75b0bab0bd90:	mov    eax,0xc
    75b0bab0bd95:	movabs r11,0x59d8f50c0ca0
    75b0bab0bd9f:	jmp    r11
    75b0bab0bda2:	mov    eax,0x4106d8
    75b0bab0bda7:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0bdaf:	push   rdx
    75b0bab0bdb0:	push   rsi
    75b0bab0bdb1:	push   r10
    75b0bab0bdb3:	push   r11
    75b0bab0bdb5:	mov    r11,rax
    75b0bab0bdb8:	lahf
    75b0bab0bdb9:	seto   al
    75b0bab0bdbc:	mov    WORD PTR [rsp+0x20],ax
    75b0bab0bdc1:	mov    rax,r11
    75b0bab0bdc4:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0bdc9:	mov    r10d,edx
    75b0bab0bdcc:	and    r10d,0xc000
    75b0bab0bdd3:	shl    r10d,0x10
    75b0bab0bdd7:	mov    r11d,edx
    75b0bab0bdda:	and    r11d,0x100
    75b0bab0bde1:	shl    r11d,0x15
    75b0bab0bde5:	or     r10d,r11d
    75b0bab0bde8:	and    edx,0x1
    75b0bab0bdeb:	shl    edx,0x1c
    75b0bab0bdee:	or     r10d,edx
    75b0bab0bdf1:	btc    r10,0x1d
    75b0bab0bdf6:	mov    r11d,0xf0000000
    75b0bab0bdfc:	and    r11,r10
    75b0bab0bdff:	movabs rsi,0xffffffff0fffffff
    75b0bab0be09:	and    rbx,rsi
    75b0bab0be0c:	or     rbx,r11
    75b0bab0be0f:	pop    r11
    75b0bab0be11:	pop    r10
    75b0bab0be13:	pop    rsi
    75b0bab0be14:	pop    rdx
    75b0bab0be15:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0be1d:	add    rsp,0x150
    75b0bab0be24:	mov    eax,0xc
    75b0bab0be29:	movabs r11,0x59d8f50c0ca0
    75b0bab0be33:	jmp    r11
    75b0bab0be36:	mov    eax,0x410700
    75b0bab0be3b:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0be43:	push   rdx
    75b0bab0be44:	push   rsi
    75b0bab0be45:	push   r10
    75b0bab0be47:	push   r11
    75b0bab0be49:	mov    r11,rax
    75b0bab0be4c:	lahf
    75b0bab0be4d:	seto   al
    75b0bab0be50:	mov    WORD PTR [rsp+0x20],ax
    75b0bab0be55:	mov    rax,r11
    75b0bab0be58:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0be5d:	mov    r10d,edx
    75b0bab0be60:	and    r10d,0xc000
    75b0bab0be67:	shl    r10d,0x10
    75b0bab0be6b:	mov    r11d,edx
    75b0bab0be6e:	and    r11d,0x100
    75b0bab0be75:	shl    r11d,0x15
    75b0bab0be79:	or     r10d,r11d
    75b0bab0be7c:	and    edx,0x1
    75b0bab0be7f:	shl    edx,0x1c
    75b0bab0be82:	or     r10d,edx
    75b0bab0be85:	btc    r10,0x1d
    75b0bab0be8a:	mov    r11d,0xf0000000
    75b0bab0be90:	and    r11,r10
    75b0bab0be93:	movabs rsi,0xffffffff0fffffff
    75b0bab0be9d:	and    rbx,rsi
    75b0bab0bea0:	or     rbx,r11
    75b0bab0bea3:	pop    r11
    75b0bab0bea5:	pop    r10
    75b0bab0bea7:	pop    rsi
    75b0bab0bea8:	pop    rdx
    75b0bab0bea9:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0beb1:	add    rsp,0x150
    75b0bab0beb8:	mov    eax,0xc
    75b0bab0bebd:	movabs r11,0x59d8f50c0ca0
    75b0bab0bec7:	jmp    r11
    75b0bab0beca:	mov    eax,0x410724
    75b0bab0becf:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0bed7:	push   rdx
    75b0bab0bed8:	push   rsi
    75b0bab0bed9:	push   r10
    75b0bab0bedb:	push   r11
    75b0bab0bedd:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0bee2:	mov    r10d,edx
    75b0bab0bee5:	and    r10d,0xc000
    75b0bab0beec:	shl    r10d,0x10
    75b0bab0bef0:	mov    r11d,edx
    75b0bab0bef3:	and    r11d,0x100
    75b0bab0befa:	shl    r11d,0x15
    75b0bab0befe:	or     r10d,r11d
    75b0bab0bf01:	and    edx,0x1
    75b0bab0bf04:	shl    edx,0x1c
    75b0bab0bf07:	or     r10d,edx
    75b0bab0bf0a:	btc    r10,0x1d
    75b0bab0bf0f:	mov    r11d,0xf0000000
    75b0bab0bf15:	and    r11,r10
    75b0bab0bf18:	movabs rsi,0xffffffff0fffffff
    75b0bab0bf22:	and    rbx,rsi
    75b0bab0bf25:	or     rbx,r11
    75b0bab0bf28:	pop    r11
    75b0bab0bf2a:	pop    r10
    75b0bab0bf2c:	pop    rsi
    75b0bab0bf2d:	pop    rdx
    75b0bab0bf2e:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0bf36:	add    rsp,0x150
    75b0bab0bf3d:	mov    eax,0xc
    75b0bab0bf42:	movabs r11,0x59d8f50c0ca0
    75b0bab0bf4c:	jmp    r11
    75b0bab0bf4f:	nop
    75b0bab0bf50:	sub    rsp,0x150
    75b0bab0bf57:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0bf5f:	mov    QWORD PTR [rsp],r11
    75b0bab0bf63:	cmp    DWORD PTR [r12+0x310],0x0
    75b0bab0bf6c:	je     0x75b0bab0bff7
    75b0bab0bf72:	push   rdx
    75b0bab0bf73:	push   rsi
    75b0bab0bf74:	push   r10
    75b0bab0bf76:	push   r11
    75b0bab0bf78:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0bf7d:	mov    r10d,edx
    75b0bab0bf80:	and    r10d,0xc000
    75b0bab0bf87:	shl    r10d,0x10
    75b0bab0bf8b:	mov    r11d,edx
    75b0bab0bf8e:	and    r11d,0x100
    75b0bab0bf95:	shl    r11d,0x15
    75b0bab0bf99:	or     r10d,r11d
    75b0bab0bf9c:	and    edx,0x1
    75b0bab0bf9f:	shl    edx,0x1c
    75b0bab0bfa2:	or     r10d,edx
    75b0bab0bfa5:	btc    r10,0x1d
    75b0bab0bfaa:	mov    r11d,0xf0000000
    75b0bab0bfb0:	and    r11,r10
    75b0bab0bfb3:	movabs rsi,0xffffffff0fffffff
    75b0bab0bfbd:	and    rbx,rsi
    75b0bab0bfc0:	or     rbx,r11
    75b0bab0bfc3:	pop    r11
    75b0bab0bfc5:	pop    r10
    75b0bab0bfc7:	pop    rsi
    75b0bab0bfc8:	pop    rdx
    75b0bab0bfc9:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0bfd1:	mov    eax,0x410404
    75b0bab0bfd6:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0bfde:	add    rsp,0x150
    75b0bab0bfe5:	mov    eax,0x3
    75b0bab0bfea:	movabs r11,0x59d8f50c0ca0
    75b0bab0bff4:	jmp    r11
    75b0bab0bff7:	jmp    0x75b0bab0226d
    75b0bab0bffc:	nop    DWORD PTR [rax+0x0]
    75b0bab0c000:	sub    rsp,0x150
    75b0bab0c007:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0c00f:	mov    QWORD PTR [rsp],r11
    75b0bab0c013:	cmp    DWORD PTR [r12+0x310],0x0
    75b0bab0c01c:	je     0x75b0bab0c0a7
    75b0bab0c022:	push   rdx
    75b0bab0c023:	push   rsi
    75b0bab0c024:	push   r10
    75b0bab0c026:	push   r11
    75b0bab0c028:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0c02d:	mov    r10d,edx
    75b0bab0c030:	and    r10d,0xc000
    75b0bab0c037:	shl    r10d,0x10
    75b0bab0c03b:	mov    r11d,edx
    75b0bab0c03e:	and    r11d,0x100
    75b0bab0c045:	shl    r11d,0x15
    75b0bab0c049:	or     r10d,r11d
    75b0bab0c04c:	and    edx,0x1
    75b0bab0c04f:	shl    edx,0x1c
    75b0bab0c052:	or     r10d,edx
    75b0bab0c055:	btc    r10,0x1d
    75b0bab0c05a:	mov    r11d,0xf0000000
    75b0bab0c060:	and    r11,r10
    75b0bab0c063:	movabs rsi,0xffffffff0fffffff
    75b0bab0c06d:	and    rbx,rsi
    75b0bab0c070:	or     rbx,r11
    75b0bab0c073:	pop    r11
    75b0bab0c075:	pop    r10
    75b0bab0c077:	pop    rsi
    75b0bab0c078:	pop    rdx
    75b0bab0c079:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0c081:	mov    eax,0x410450
    75b0bab0c086:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0c08e:	add    rsp,0x150
    75b0bab0c095:	mov    eax,0x3
    75b0bab0c09a:	movabs r11,0x59d8f50c0ca0
    75b0bab0c0a4:	jmp    r11
    75b0bab0c0a7:	mov    r11,rax
    75b0bab0c0aa:	movzx  eax,WORD PTR [rsp]
    75b0bab0c0ae:	add    al,0x7f
    75b0bab0c0b0:	sahf
    75b0bab0c0b1:	mov    rax,r11
    75b0bab0c0b4:	jmp    0x75b0bab023dd
    75b0bab0c0b9:	nop    DWORD PTR [rax+0x0]
    75b0bab0c0c0:	sub    rsp,0x150
    75b0bab0c0c7:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0c0cf:	mov    QWORD PTR [rsp],r11
    75b0bab0c0d3:	cmp    DWORD PTR [r12+0x310],0x0
    75b0bab0c0dc:	je     0x75b0bab0c167
    75b0bab0c0e2:	push   rdx
    75b0bab0c0e3:	push   rsi
    75b0bab0c0e4:	push   r10
    75b0bab0c0e6:	push   r11
    75b0bab0c0e8:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0c0ed:	mov    r10d,edx
    75b0bab0c0f0:	and    r10d,0xc000
    75b0bab0c0f7:	shl    r10d,0x10
    75b0bab0c0fb:	mov    r11d,edx
    75b0bab0c0fe:	and    r11d,0x100
    75b0bab0c105:	shl    r11d,0x15
    75b0bab0c109:	or     r10d,r11d
    75b0bab0c10c:	and    edx,0x1
    75b0bab0c10f:	shl    edx,0x1c
    75b0bab0c112:	or     r10d,edx
    75b0bab0c115:	btc    r10,0x1d
    75b0bab0c11a:	mov    r11d,0xf0000000
    75b0bab0c120:	and    r11,r10
    75b0bab0c123:	movabs rsi,0xffffffff0fffffff
    75b0bab0c12d:	and    rbx,rsi
    75b0bab0c130:	or     rbx,r11
    75b0bab0c133:	pop    r11
    75b0bab0c135:	pop    r10
    75b0bab0c137:	pop    rsi
    75b0bab0c138:	pop    rdx
    75b0bab0c139:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0c141:	mov    eax,0x410490
    75b0bab0c146:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0c14e:	add    rsp,0x150
    75b0bab0c155:	mov    eax,0x3
    75b0bab0c15a:	movabs r11,0x59d8f50c0ca0
    75b0bab0c164:	jmp    r11
    75b0bab0c167:	jmp    0x75b0bab0282b
    75b0bab0c16c:	nop    DWORD PTR [rax+0x0]
    75b0bab0c170:	sub    rsp,0x150
    75b0bab0c177:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0c17f:	mov    QWORD PTR [rsp],r11
    75b0bab0c183:	cmp    DWORD PTR [r12+0x310],0x0
    75b0bab0c18c:	je     0x75b0bab0c217
    75b0bab0c192:	push   rdx
    75b0bab0c193:	push   rsi
    75b0bab0c194:	push   r10
    75b0bab0c196:	push   r11
    75b0bab0c198:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0c19d:	mov    r10d,edx
    75b0bab0c1a0:	and    r10d,0xc000
    75b0bab0c1a7:	shl    r10d,0x10
    75b0bab0c1ab:	mov    r11d,edx
    75b0bab0c1ae:	and    r11d,0x100
    75b0bab0c1b5:	shl    r11d,0x15
    75b0bab0c1b9:	or     r10d,r11d
    75b0bab0c1bc:	and    edx,0x1
    75b0bab0c1bf:	shl    edx,0x1c
    75b0bab0c1c2:	or     r10d,edx
    75b0bab0c1c5:	btc    r10,0x1d
    75b0bab0c1ca:	mov    r11d,0xf0000000
    75b0bab0c1d0:	and    r11,r10
    75b0bab0c1d3:	movabs rsi,0xffffffff0fffffff
    75b0bab0c1dd:	and    rbx,rsi
    75b0bab0c1e0:	or     rbx,r11
    75b0bab0c1e3:	pop    r11
    75b0bab0c1e5:	pop    r10
    75b0bab0c1e7:	pop    rsi
    75b0bab0c1e8:	pop    rdx
    75b0bab0c1e9:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0c1f1:	mov    eax,0x410500
    75b0bab0c1f6:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0c1fe:	add    rsp,0x150
    75b0bab0c205:	mov    eax,0x3
    75b0bab0c20a:	movabs r11,0x59d8f50c0ca0
    75b0bab0c214:	jmp    r11
    75b0bab0c217:	mov    r11,rax
    75b0bab0c21a:	movzx  eax,WORD PTR [rsp]
    75b0bab0c21e:	add    al,0x7f
    75b0bab0c220:	sahf
    75b0bab0c221:	mov    rax,r11
    75b0bab0c224:	jmp    0x75b0bab02c37
    75b0bab0c229:	nop    DWORD PTR [rax+0x0]
    75b0bab0c230:	sub    rsp,0x150
    75b0bab0c237:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0c23f:	mov    QWORD PTR [rsp],r11
    75b0bab0c243:	cmp    DWORD PTR [r12+0x310],0x0
    75b0bab0c24c:	je     0x75b0bab0c2d7
    75b0bab0c252:	push   rdx
    75b0bab0c253:	push   rsi
    75b0bab0c254:	push   r10
    75b0bab0c256:	push   r11
    75b0bab0c258:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0c25d:	mov    r10d,edx
    75b0bab0c260:	and    r10d,0xc000
    75b0bab0c267:	shl    r10d,0x10
    75b0bab0c26b:	mov    r11d,edx
    75b0bab0c26e:	and    r11d,0x100
    75b0bab0c275:	shl    r11d,0x15
    75b0bab0c279:	or     r10d,r11d
    75b0bab0c27c:	and    edx,0x1
    75b0bab0c27f:	shl    edx,0x1c
    75b0bab0c282:	or     r10d,edx
    75b0bab0c285:	btc    r10,0x1d
    75b0bab0c28a:	mov    r11d,0xf0000000
    75b0bab0c290:	and    r11,r10
    75b0bab0c293:	movabs rsi,0xffffffff0fffffff
    75b0bab0c29d:	and    rbx,rsi
    75b0bab0c2a0:	or     rbx,r11
    75b0bab0c2a3:	pop    r11
    75b0bab0c2a5:	pop    r10
    75b0bab0c2a7:	pop    rsi
    75b0bab0c2a8:	pop    rdx
    75b0bab0c2a9:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0c2b1:	mov    eax,0x410504
    75b0bab0c2b6:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0c2be:	add    rsp,0x150
    75b0bab0c2c5:	mov    eax,0x3
    75b0bab0c2ca:	movabs r11,0x59d8f50c0ca0
    75b0bab0c2d4:	jmp    r11
    75b0bab0c2d7:	jmp    0x75b0bab02c55
    75b0bab0c2dc:	nop    DWORD PTR [rax+0x0]
    75b0bab0c2e0:	sub    rsp,0x150
    75b0bab0c2e7:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0c2ef:	mov    QWORD PTR [rsp],r11
    75b0bab0c2f3:	cmp    DWORD PTR [r12+0x310],0x0
    75b0bab0c2fc:	je     0x75b0bab0c387
    75b0bab0c302:	push   rdx
    75b0bab0c303:	push   rsi
    75b0bab0c304:	push   r10
    75b0bab0c306:	push   r11
    75b0bab0c308:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0c30d:	mov    r10d,edx
    75b0bab0c310:	and    r10d,0xc000
    75b0bab0c317:	shl    r10d,0x10
    75b0bab0c31b:	mov    r11d,edx
    75b0bab0c31e:	and    r11d,0x100
    75b0bab0c325:	shl    r11d,0x15
    75b0bab0c329:	or     r10d,r11d
    75b0bab0c32c:	and    edx,0x1
    75b0bab0c32f:	shl    edx,0x1c
    75b0bab0c332:	or     r10d,edx
    75b0bab0c335:	btc    r10,0x1d
    75b0bab0c33a:	mov    r11d,0xf0000000
    75b0bab0c340:	and    r11,r10
    75b0bab0c343:	movabs rsi,0xffffffff0fffffff
    75b0bab0c34d:	and    rbx,rsi
    75b0bab0c350:	or     rbx,r11
    75b0bab0c353:	pop    r11
    75b0bab0c355:	pop    r10
    75b0bab0c357:	pop    rsi
    75b0bab0c358:	pop    rdx
    75b0bab0c359:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0c361:	mov    eax,0x4106d0
    75b0bab0c366:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0c36e:	add    rsp,0x150
    75b0bab0c375:	mov    eax,0x3
    75b0bab0c37a:	movabs r11,0x59d8f50c0ca0
    75b0bab0c384:	jmp    r11
    75b0bab0c387:	jmp    0x75b0bab04995
    75b0bab0c38c:	nop    DWORD PTR [rax+0x0]
    75b0bab0c390:	sub    rsp,0x150
    75b0bab0c397:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0c39f:	mov    QWORD PTR [rsp],r11
    75b0bab0c3a3:	cmp    DWORD PTR [r12+0x310],0x0
    75b0bab0c3ac:	je     0x75b0bab0c437
    75b0bab0c3b2:	push   rdx
    75b0bab0c3b3:	push   rsi
    75b0bab0c3b4:	push   r10
    75b0bab0c3b6:	push   r11
    75b0bab0c3b8:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0c3bd:	mov    r10d,edx
    75b0bab0c3c0:	and    r10d,0xc000
    75b0bab0c3c7:	shl    r10d,0x10
    75b0bab0c3cb:	mov    r11d,edx
    75b0bab0c3ce:	and    r11d,0x100
    75b0bab0c3d5:	shl    r11d,0x15
    75b0bab0c3d9:	or     r10d,r11d
    75b0bab0c3dc:	and    edx,0x1
    75b0bab0c3df:	shl    edx,0x1c
    75b0bab0c3e2:	or     r10d,edx
    75b0bab0c3e5:	btc    r10,0x1d
    75b0bab0c3ea:	mov    r11d,0xf0000000
    75b0bab0c3f0:	and    r11,r10
    75b0bab0c3f3:	movabs rsi,0xffffffff0fffffff
    75b0bab0c3fd:	and    rbx,rsi
    75b0bab0c400:	or     rbx,r11
    75b0bab0c403:	pop    r11
    75b0bab0c405:	pop    r10
    75b0bab0c407:	pop    rsi
    75b0bab0c408:	pop    rdx
    75b0bab0c409:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0c411:	mov    eax,0x4106dc
    75b0bab0c416:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0c41e:	add    rsp,0x150
    75b0bab0c425:	mov    eax,0x3
    75b0bab0c42a:	movabs r11,0x59d8f50c0ca0
    75b0bab0c434:	jmp    r11
    75b0bab0c437:	jmp    0x75b0bab049d2
    75b0bab0c43c:	nop    DWORD PTR [rax+0x0]
    75b0bab0c440:	sub    rsp,0x150
    75b0bab0c447:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0c44f:	mov    QWORD PTR [rsp],r11
    75b0bab0c453:	cmp    DWORD PTR [r12+0x310],0x0
    75b0bab0c45c:	je     0x75b0bab0c4e7
    75b0bab0c462:	push   rdx
    75b0bab0c463:	push   rsi
    75b0bab0c464:	push   r10
    75b0bab0c466:	push   r11
    75b0bab0c468:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0c46d:	mov    r10d,edx
    75b0bab0c470:	and    r10d,0xc000
    75b0bab0c477:	shl    r10d,0x10
    75b0bab0c47b:	mov    r11d,edx
    75b0bab0c47e:	and    r11d,0x100
    75b0bab0c485:	shl    r11d,0x15
    75b0bab0c489:	or     r10d,r11d
    75b0bab0c48c:	and    edx,0x1
    75b0bab0c48f:	shl    edx,0x1c
    75b0bab0c492:	or     r10d,edx
    75b0bab0c495:	btc    r10,0x1d
    75b0bab0c49a:	mov    r11d,0xf0000000
    75b0bab0c4a0:	and    r11,r10
    75b0bab0c4a3:	movabs rsi,0xffffffff0fffffff
    75b0bab0c4ad:	and    rbx,rsi
    75b0bab0c4b0:	or     rbx,r11
    75b0bab0c4b3:	pop    r11
    75b0bab0c4b5:	pop    r10
    75b0bab0c4b7:	pop    rsi
    75b0bab0c4b8:	pop    rdx
    75b0bab0c4b9:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0c4c1:	mov    eax,0x4106e8
    75b0bab0c4c6:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0c4ce:	add    rsp,0x150
    75b0bab0c4d5:	mov    eax,0x3
    75b0bab0c4da:	movabs r11,0x59d8f50c0ca0
    75b0bab0c4e4:	jmp    r11
    75b0bab0c4e7:	jmp    0x75b0bab04a0d
    75b0bab0c4ec:	nop    DWORD PTR [rax+0x0]
    75b0bab0c4f0:	sub    rsp,0x150
    75b0bab0c4f7:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0c4ff:	mov    QWORD PTR [rsp],r11
    75b0bab0c503:	cmp    DWORD PTR [r12+0x310],0x0
    75b0bab0c50c:	je     0x75b0bab0c597
    75b0bab0c512:	push   rdx
    75b0bab0c513:	push   rsi
    75b0bab0c514:	push   r10
    75b0bab0c516:	push   r11
    75b0bab0c518:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0c51d:	mov    r10d,edx
    75b0bab0c520:	and    r10d,0xc000
    75b0bab0c527:	shl    r10d,0x10
    75b0bab0c52b:	mov    r11d,edx
    75b0bab0c52e:	and    r11d,0x100
    75b0bab0c535:	shl    r11d,0x15
    75b0bab0c539:	or     r10d,r11d
    75b0bab0c53c:	and    edx,0x1
    75b0bab0c53f:	shl    edx,0x1c
    75b0bab0c542:	or     r10d,edx
    75b0bab0c545:	btc    r10,0x1d
    75b0bab0c54a:	mov    r11d,0xf0000000
    75b0bab0c550:	and    r11,r10
    75b0bab0c553:	movabs rsi,0xffffffff0fffffff
    75b0bab0c55d:	and    rbx,rsi
    75b0bab0c560:	or     rbx,r11
    75b0bab0c563:	pop    r11
    75b0bab0c565:	pop    r10
    75b0bab0c567:	pop    rsi
    75b0bab0c568:	pop    rdx
    75b0bab0c569:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0c571:	mov    eax,0x410704
    75b0bab0c576:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0c57e:	add    rsp,0x150
    75b0bab0c585:	mov    eax,0x3
    75b0bab0c58a:	movabs r11,0x59d8f50c0ca0
    75b0bab0c594:	jmp    r11
    75b0bab0c597:	jmp    0x75b0bab04b66
    75b0bab0c59c:	nop    DWORD PTR [rax+0x0]
    75b0bab0c5a0:	sub    rsp,0x150
    75b0bab0c5a7:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0c5af:	mov    QWORD PTR [rsp],r11
    75b0bab0c5b3:	cmp    DWORD PTR [r12+0x310],0x0
    75b0bab0c5bc:	je     0x75b0bab0c647
    75b0bab0c5c2:	push   rdx
    75b0bab0c5c3:	push   rsi
    75b0bab0c5c4:	push   r10
    75b0bab0c5c6:	push   r11
    75b0bab0c5c8:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0c5cd:	mov    r10d,edx
    75b0bab0c5d0:	and    r10d,0xc000
    75b0bab0c5d7:	shl    r10d,0x10
    75b0bab0c5db:	mov    r11d,edx
    75b0bab0c5de:	and    r11d,0x100
    75b0bab0c5e5:	shl    r11d,0x15
    75b0bab0c5e9:	or     r10d,r11d
    75b0bab0c5ec:	and    edx,0x1
    75b0bab0c5ef:	shl    edx,0x1c
    75b0bab0c5f2:	or     r10d,edx
    75b0bab0c5f5:	btc    r10,0x1d
    75b0bab0c5fa:	mov    r11d,0xf0000000
    75b0bab0c600:	and    r11,r10
    75b0bab0c603:	movabs rsi,0xffffffff0fffffff
    75b0bab0c60d:	and    rbx,rsi
    75b0bab0c610:	or     rbx,r11
    75b0bab0c613:	pop    r11
    75b0bab0c615:	pop    r10
    75b0bab0c617:	pop    rsi
    75b0bab0c618:	pop    rdx
    75b0bab0c619:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab0c621:	mov    eax,0x4103f0
    75b0bab0c626:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0c62e:	add    rsp,0x150
    75b0bab0c635:	mov    eax,0x3
    75b0bab0c63a:	movabs r11,0x59d8f50c0ca0
    75b0bab0c644:	jmp    r11
    75b0bab0c647:	jmp    0x75b0bab04d43
    75b0bab0c64c:	nop    DWORD PTR [rax+0x0]
    75b0bab0c650:	(bad)
    75b0bab0c651:	(bad)
    75b0bab0c652:	(bad)
    75b0bab0c653:	(bad)
    75b0bab0c654:	(bad)
    75b0bab0c655:	(bad)
    75b0bab0c656:	(bad)
    75b0bab0c657:	jg     0x75b0bab0c658
    75b0bab0c659:	(bad)
    75b0bab0c65a:	(bad)
    75b0bab0c65b:	(bad)
    75b0bab0c65c:	(bad)
    75b0bab0c65d:	(bad)
    75b0bab0c65e:	(bad)
    75b0bab0c65f:	jg     0x75b0bab0c661
    75b0bab0c661:	add    BYTE PTR [rax],al
    75b0bab0c663:	add    BYTE PTR [rax],al
    75b0bab0c665:	add    BYTE PTR [rax],dl
    75b0bab0c667:	add    BYTE PTR [rax],al
    75b0bab0c669:	add    BYTE PTR [rax],al
    75b0bab0c66b:	add    BYTE PTR [rax],al
    75b0bab0c66d:	add    BYTE PTR [rax],dl
	...
