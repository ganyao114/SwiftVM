
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/0/5.bin:     file format binary


Disassembly of section .data:

000074a37e501220 <.data>:
    74a37e501220:	sub    rsp,0x10
    74a37e501224:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50122c:	mov    QWORD PTR [rsp],r11
    74a37e501230:	mov    rax,QWORD PTR [r12+0xf8]
    74a37e501238:	mov    r14,QWORD PTR [r12+0xf8]
    74a37e501240:	add    r14,0x100
    74a37e501247:	mov    r15d,DWORD PTR [r14]
    74a37e50124a:	mov    QWORD PTR [r12+0x40],r15
    74a37e50124f:	mov    r14,QWORD PTR [r12+0xf8]
    74a37e501257:	add    r14,0x104
    74a37e50125e:	mov    ebp,DWORD PTR [r14]
    74a37e501261:	mov    QWORD PTR [r12+0x50],rbp
    74a37e501266:	mov    r14d,0x430c90
    74a37e50126c:	mov    QWORD PTR [r12+0x48],r14
    74a37e501271:	mov    r14,QWORD PTR [r12+0xf8]
    74a37e501279:	add    r14,0x108
    74a37e501280:	mov    r8d,DWORD PTR [r14]
    74a37e501283:	mov    QWORD PTR [r12+0x58],r8
    74a37e501288:	mov    r14,QWORD PTR [r12+0xf8]
    74a37e501290:	add    r14,0x10c
    74a37e501297:	mov    eax,DWORD PTR [r14]
    74a37e50129a:	mov    QWORD PTR [r12+0x60],rax
    74a37e50129f:	movabs rcx,0xff00ff00ff00ff
    74a37e5012a9:	mov    r14,r15
    74a37e5012ac:	and    r14,rcx
    74a37e5012af:	shl    r14,0x8
    74a37e5012b3:	movabs rcx,0xff00ff00ff00ff00
    74a37e5012bd:	mov    r13,r15
    74a37e5012c0:	and    r13,rcx
    74a37e5012c3:	shr    r13,0x8
    74a37e5012c7:	or     r13,r14
    74a37e5012ca:	movabs rcx,0xffff0000ffff
    74a37e5012d4:	mov    r14,r13
    74a37e5012d7:	and    r14,rcx
    74a37e5012da:	shl    r14,0x10
    74a37e5012de:	movabs rcx,0xffff0000ffff0000
    74a37e5012e8:	and    r13,rcx
    74a37e5012eb:	shr    r13,0x10
    74a37e5012ef:	or     r13,r14
    74a37e5012f2:	mov    ecx,0xffffffff
    74a37e5012f7:	and    r13,rcx
    74a37e5012fa:	mov    QWORD PTR [r12+0x40],r13
    74a37e5012ff:	movabs rcx,0xff00ff00ff00ff
    74a37e501309:	mov    r14,rbp
    74a37e50130c:	and    r14,rcx
    74a37e50130f:	shl    r14,0x8
    74a37e501313:	movabs rcx,0xff00ff00ff00ff00
    74a37e50131d:	mov    r15,rbp
    74a37e501320:	and    r15,rcx
    74a37e501323:	shr    r15,0x8
    74a37e501327:	or     r15,r14
    74a37e50132a:	movabs rcx,0xffff0000ffff
    74a37e501334:	mov    r14,r15
    74a37e501337:	and    r14,rcx
    74a37e50133a:	shl    r14,0x10
    74a37e50133e:	movabs rcx,0xffff0000ffff0000
    74a37e501348:	and    r15,rcx
    74a37e50134b:	shr    r15,0x10
    74a37e50134f:	or     r15,r14
    74a37e501352:	mov    ecx,0xffffffff
    74a37e501357:	and    r15,rcx
    74a37e50135a:	mov    QWORD PTR [r12+0x50],r15
    74a37e50135f:	mov    r14d,0x0
    74a37e501365:	mov    QWORD PTR [r12+0xa0],r14
    74a37e50136d:	mov    r14d,0x430c90
    74a37e501373:	mov    ebp,0x430c94
    74a37e501378:	mov    rax,r13
    74a37e50137b:	mov    eax,eax
    74a37e50137d:	mov    r9d,eax
    74a37e501380:	mov    rax,r15
    74a37e501383:	mov    eax,eax
    74a37e501385:	mov    r13d,eax
    74a37e501388:	mov    DWORD PTR [r14],r9d
    74a37e50138b:	mov    r14d,0x0
    74a37e501391:	mov    DWORD PTR [r12+0x32c],r14d
    74a37e501399:	mov    DWORD PTR [rbp+0x0],r13d
    74a37e50139d:	movabs rcx,0xff00ff00ff00ff
    74a37e5013a7:	mov    r13,r8
    74a37e5013aa:	and    r13,rcx
    74a37e5013ad:	shl    r13,0x8
    74a37e5013b1:	movabs rcx,0xff00ff00ff00ff00
    74a37e5013bb:	mov    r14,r8
    74a37e5013be:	and    r14,rcx
    74a37e5013c1:	shr    r14,0x8
    74a37e5013c5:	or     r14,r13
    74a37e5013c8:	movabs rcx,0xffff0000ffff
    74a37e5013d2:	mov    r13,r14
    74a37e5013d5:	and    r13,rcx
    74a37e5013d8:	shl    r13,0x10
    74a37e5013dc:	movabs rcx,0xffff0000ffff0000
    74a37e5013e6:	and    r14,rcx
    74a37e5013e9:	shr    r14,0x10
    74a37e5013ed:	or     r14,r13
    74a37e5013f0:	mov    ecx,0xffffffff
    74a37e5013f5:	and    r14,rcx
    74a37e5013f8:	mov    QWORD PTR [r12+0x40],r14
    74a37e5013fd:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e501405:	add    r13,0x110
    74a37e50140c:	mov    r15d,DWORD PTR [r13+0x0]
    74a37e501410:	mov    QWORD PTR [r12+0x50],r15
    74a37e501415:	movabs rcx,0xff00ff00ff00ff
    74a37e50141f:	mov    r13d,DWORD PTR [r12+0x60]
    74a37e501424:	and    r13,rcx
    74a37e501427:	shl    r13,0x8
    74a37e50142b:	movabs rcx,0xff00ff00ff00ff00
    74a37e501435:	mov    ebp,DWORD PTR [r12+0x60]
    74a37e50143a:	and    rbp,rcx
    74a37e50143d:	shr    rbp,0x8
    74a37e501441:	or     rbp,r13
    74a37e501444:	movabs rcx,0xffff0000ffff
    74a37e50144e:	mov    r13,rbp
    74a37e501451:	and    r13,rcx
    74a37e501454:	shl    r13,0x10
    74a37e501458:	movabs rcx,0xffff0000ffff0000
    74a37e501462:	and    rbp,rcx
    74a37e501465:	shr    rbp,0x10
    74a37e501469:	or     rbp,r13
    74a37e50146c:	mov    ecx,0xffffffff
    74a37e501471:	and    rbp,rcx
    74a37e501474:	mov    QWORD PTR [r12+0x58],rbp
    74a37e501479:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e501481:	add    r13,0x114
    74a37e501488:	mov    eax,DWORD PTR [r13+0x0]
    74a37e50148c:	mov    QWORD PTR [r12+0x60],rax
    74a37e501491:	mov    r13d,0x430000
    74a37e501497:	add    r13,0xdfc
    74a37e50149e:	mov    QWORD PTR [r12+0x98],r13
    74a37e5014a6:	mov    r13d,0x430c98
    74a37e5014ac:	mov    r9d,0x430c9c
    74a37e5014b2:	mov    rax,r14
    74a37e5014b5:	mov    eax,eax
    74a37e5014b7:	mov    r8d,eax
    74a37e5014ba:	mov    rax,rbp
    74a37e5014bd:	mov    eax,eax
    74a37e5014bf:	mov    r14d,eax
    74a37e5014c2:	mov    DWORD PTR [r13+0x0],r8d
    74a37e5014c6:	mov    DWORD PTR [r9],r14d
    74a37e5014c9:	movabs rcx,0xff00ff00ff00ff
    74a37e5014d3:	mov    r13,r15
    74a37e5014d6:	and    r13,rcx
    74a37e5014d9:	shl    r13,0x8
    74a37e5014dd:	movabs rcx,0xff00ff00ff00ff00
    74a37e5014e7:	mov    r14,r15
    74a37e5014ea:	and    r14,rcx
    74a37e5014ed:	shr    r14,0x8
    74a37e5014f1:	or     r14,r13
    74a37e5014f4:	movabs rcx,0xffff0000ffff
    74a37e5014fe:	mov    r13,r14
    74a37e501501:	and    r13,rcx
    74a37e501504:	shl    r13,0x10
    74a37e501508:	movabs rcx,0xffff0000ffff0000
    74a37e501512:	and    r14,rcx
    74a37e501515:	shr    r14,0x10
    74a37e501519:	or     r14,r13
    74a37e50151c:	mov    ecx,0xffffffff
    74a37e501521:	and    r14,rcx
    74a37e501524:	mov    QWORD PTR [r12+0x40],r14
    74a37e501529:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e501531:	add    r13,0x118
    74a37e501538:	mov    r15d,DWORD PTR [r13+0x0]
    74a37e50153c:	mov    QWORD PTR [r12+0x50],r15
    74a37e501541:	movabs rcx,0xff00ff00ff00ff
    74a37e50154b:	mov    r13d,DWORD PTR [r12+0x60]
    74a37e501550:	and    r13,rcx
    74a37e501553:	shl    r13,0x8
    74a37e501557:	movabs rcx,0xff00ff00ff00ff00
    74a37e501561:	mov    ebp,DWORD PTR [r12+0x60]
    74a37e501566:	and    rbp,rcx
    74a37e501569:	shr    rbp,0x8
    74a37e50156d:	or     rbp,r13
    74a37e501570:	movabs rcx,0xffff0000ffff
    74a37e50157a:	mov    r13,rbp
    74a37e50157d:	and    r13,rcx
    74a37e501580:	shl    r13,0x10
    74a37e501584:	movabs rcx,0xffff0000ffff0000
    74a37e50158e:	and    rbp,rcx
    74a37e501591:	shr    rbp,0x10
    74a37e501595:	or     rbp,r13
    74a37e501598:	mov    ecx,0xffffffff
    74a37e50159d:	and    rbp,rcx
    74a37e5015a0:	mov    QWORD PTR [r12+0x58],rbp
    74a37e5015a5:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e5015ad:	add    r13,0x11c
    74a37e5015b4:	mov    eax,DWORD PTR [r13+0x0]
    74a37e5015b8:	mov    QWORD PTR [r12+0x60],rax
    74a37e5015bd:	mov    r13d,0x430ca0
    74a37e5015c3:	mov    r9d,0x430ca4
    74a37e5015c9:	mov    rax,r14
    74a37e5015cc:	mov    eax,eax
    74a37e5015ce:	mov    r8d,eax
    74a37e5015d1:	mov    rax,rbp
    74a37e5015d4:	mov    eax,eax
    74a37e5015d6:	mov    r14d,eax
    74a37e5015d9:	mov    DWORD PTR [r13+0x0],r8d
    74a37e5015dd:	mov    DWORD PTR [r9],r14d
    74a37e5015e0:	movabs rcx,0xff00ff00ff00ff
    74a37e5015ea:	mov    r13,r15
    74a37e5015ed:	and    r13,rcx
    74a37e5015f0:	shl    r13,0x8
    74a37e5015f4:	movabs rcx,0xff00ff00ff00ff00
    74a37e5015fe:	mov    r14,r15
    74a37e501601:	and    r14,rcx
    74a37e501604:	shr    r14,0x8
    74a37e501608:	or     r14,r13
    74a37e50160b:	movabs rcx,0xffff0000ffff
    74a37e501615:	mov    r13,r14
    74a37e501618:	and    r13,rcx
    74a37e50161b:	shl    r13,0x10
    74a37e50161f:	movabs rcx,0xffff0000ffff0000
    74a37e501629:	and    r14,rcx
    74a37e50162c:	shr    r14,0x10
    74a37e501630:	or     r14,r13
    74a37e501633:	mov    ecx,0xffffffff
    74a37e501638:	and    r14,rcx
    74a37e50163b:	mov    QWORD PTR [r12+0x40],r14
    74a37e501640:	movabs rcx,0xff00ff00ff00ff
    74a37e50164a:	mov    r13d,DWORD PTR [r12+0x60]
    74a37e50164f:	and    r13,rcx
    74a37e501652:	shl    r13,0x8
    74a37e501656:	movabs rcx,0xff00ff00ff00ff00
    74a37e501660:	mov    r15d,DWORD PTR [r12+0x60]
    74a37e501665:	and    r15,rcx
    74a37e501668:	shr    r15,0x8
    74a37e50166c:	or     r15,r13
    74a37e50166f:	movabs rcx,0xffff0000ffff
    74a37e501679:	mov    r13,r15
    74a37e50167c:	and    r13,rcx
    74a37e50167f:	shl    r13,0x10
    74a37e501683:	movabs rcx,0xffff0000ffff0000
    74a37e50168d:	and    r15,rcx
    74a37e501690:	shr    r15,0x10
    74a37e501694:	or     r15,r13
    74a37e501697:	mov    ecx,0xffffffff
    74a37e50169c:	and    r15,rcx
    74a37e50169f:	mov    QWORD PTR [r12+0x50],r15
    74a37e5016a4:	mov    r13d,0x430ca8
    74a37e5016aa:	mov    ebp,0x430cac
    74a37e5016af:	mov    rax,r14
    74a37e5016b2:	mov    eax,eax
    74a37e5016b4:	mov    r8d,eax
    74a37e5016b7:	mov    rax,r15
    74a37e5016ba:	mov    eax,eax
    74a37e5016bc:	mov    r14d,eax
    74a37e5016bf:	mov    DWORD PTR [r13+0x0],r8d
    74a37e5016c3:	mov    DWORD PTR [rbp+0x0],r14d
    74a37e5016c7:	mov    r13d,0x11
    74a37e5016cd:	mov    QWORD PTR [r12],r13
    74a37e5016d1:	mov    r13d,0x41035c
    74a37e5016d7:	mov    QWORD PTR [r12+0xf0],r13
    74a37e5016df:	mov    r13d,0x4109a4
    74a37e5016e5:	mov    QWORD PTR [r12+0x100],r13
    74a37e5016ed:	mov    r11,QWORD PTR [rsp]
    74a37e5016f1:	mov    QWORD PTR [r12+0x398],r11
    74a37e5016f9:	mov    edi,0x4109a4
    74a37e5016fe:	mov    QWORD PTR [r12+0x100],rdi
    74a37e501706:	add    rsp,0x10
    74a37e50170a:	nop    WORD PTR [rax+rax*1+0x0]
    74a37e501710:	jmp    QWORD PTR [rip+0x2]        # 0x74a37e501718
    74a37e501716:	xchg   ax,ax
    74a37e501718:	rex (bad)
    74a37e50171a:	push   rax
    74a37e50171b:	jle    0x74a37e5016c0
    74a37e50171d:	je     0x74a37e50171f
    74a37e50171f:	add    BYTE PTR [rax],ch
    74a37e501721:	(bad)
    74a37e501722:	push   rax
    74a37e501723:	jle    0x74a37e5016c8
    74a37e501725:	je     0x74a37e501727
    74a37e501727:	add    BYTE PTR [rcx-0x45],cl
    74a37e50172a:	rex cdq
    74a37e50172c:	outs   dx,BYTE PTR ds:[rsi]
    74a37e50172d:	rex.RX adc eax,0x41000057
    74a37e501733:	jmp    rbx
    74a37e501735:	nop
    74a37e501736:	nop
    74a37e501737:	nop
