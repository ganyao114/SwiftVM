
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/0/7.bin:     file format binary


Disassembly of section .data:

000074a37e501910 <.data>:
    74a37e501910:	sub    rsp,0x10
    74a37e501914:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50191c:	mov    QWORD PTR [rsp],r11
    74a37e501920:	mov    r13,QWORD PTR [r12+0xa0]
    74a37e501928:	mov    r14,r13
    74a37e50192b:	shl    r14,0x2
    74a37e50192f:	mov    r15,QWORD PTR [r12+0x98]
    74a37e501937:	add    r15,r14
    74a37e50193a:	mov    r14d,DWORD PTR [r12]
    74a37e50193e:	mov    DWORD PTR [r15],r14d
    74a37e501941:	mov    r14d,0x0
    74a37e501947:	mov    DWORD PTR [r12+0x32c],r14d
    74a37e50194f:	add    r13,0x1
    74a37e501953:	mov    QWORD PTR [r12+0xa0],r13
    74a37e50195b:	sub    r13,0x400
    74a37e501962:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e50196a:	jrcxz  0x74a37e501971
    74a37e50196c:	jmp    0x74a37e501d4d
    74a37e501971:	jne    0x74a37e50198a
    74a37e501977:	mov    r11,rax
    74a37e50197a:	lahf
    74a37e50197b:	seto   al
    74a37e50197e:	mov    WORD PTR [rsp],ax
    74a37e501982:	mov    rax,r11
    74a37e501985:	jmp    0x74a37e50199d
    74a37e50198a:	mov    r11,rax
    74a37e50198d:	lahf
    74a37e50198e:	seto   al
    74a37e501991:	mov    WORD PTR [rsp],ax
    74a37e501995:	mov    rax,r11
    74a37e501998:	jmp    0x74a37e501cdd
    74a37e50199d:	mov    r13d,0x1
    74a37e5019a3:	mov    QWORD PTR [r12+0x40],r13
    74a37e5019a8:	mov    r11,rax
    74a37e5019ab:	movzx  eax,WORD PTR [rsp]
    74a37e5019af:	add    al,0x7f
    74a37e5019b1:	sahf
    74a37e5019b2:	mov    rax,r11
    74a37e5019b5:	jmp    0x74a37e5019ba
    74a37e5019ba:	mov    r13,QWORD PTR [r12+0x40]
    74a37e5019bf:	mov    r14,r13
    74a37e5019c2:	lea    r14,[r14*4+0x0]
    74a37e5019ca:	mov    r15,QWORD PTR [r12+0x98]
    74a37e5019d2:	mov    r11,rax
    74a37e5019d5:	lahf
    74a37e5019d6:	seto   al
    74a37e5019d9:	mov    WORD PTR [rsp],ax
    74a37e5019dd:	mov    rax,r11
    74a37e5019e0:	add    r15,r14
    74a37e5019e3:	mov    r14d,DWORD PTR [r15]
    74a37e5019e6:	mov    QWORD PTR [r12+0x48],r14
    74a37e5019eb:	mov    r14d,0x0
    74a37e5019f1:	or     r14,r13
    74a37e5019f4:	mov    QWORD PTR [r12+0x50],r14
    74a37e5019f9:	jmp    0x74a37e5019fe
    74a37e5019fe:	mov    r13d,DWORD PTR [r12+0x50]
    74a37e501a03:	sub    r13d,0x1
    74a37e501a07:	mov    QWORD PTR [r12+0x58],r13
    74a37e501a0c:	mov    ecx,0xffffffff
    74a37e501a11:	mov    r14,r13
    74a37e501a14:	and    r14,rcx
    74a37e501a17:	shl    r14,0x2
    74a37e501a1b:	mov    r13,QWORD PTR [r12+0x98]
    74a37e501a23:	add    r13,r14
    74a37e501a26:	mov    r14d,DWORD PTR [r13+0x0]
    74a37e501a2a:	mov    QWORD PTR [r12+0x60],r14
    74a37e501a2f:	mov    r13d,DWORD PTR [r12+0x48]
    74a37e501a34:	sub    r14d,r13d
    74a37e501a37:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e501a3f:	jrcxz  0x74a37e501a46
    74a37e501a41:	jmp    0x74a37e501dde
    74a37e501a46:	jbe    0x74a37e501a5f
    74a37e501a4c:	mov    r11,rax
    74a37e501a4f:	lahf
    74a37e501a50:	seto   al
    74a37e501a53:	mov    WORD PTR [rsp],ax
    74a37e501a57:	mov    rax,r11
    74a37e501a5a:	jmp    0x74a37e501a72
    74a37e501a5f:	mov    r11,rax
    74a37e501a62:	lahf
    74a37e501a63:	seto   al
    74a37e501a66:	mov    WORD PTR [rsp],ax
    74a37e501a6a:	mov    rax,r11
    74a37e501a6d:	jmp    0x74a37e501af1
    74a37e501a72:	mov    r13,QWORD PTR [r12+0x50]
    74a37e501a77:	mov    r14,r13
    74a37e501a7a:	shl    r14,0x2
    74a37e501a7e:	mov    r15,QWORD PTR [r12+0x98]
    74a37e501a86:	add    r15,r14
    74a37e501a89:	mov    r14d,DWORD PTR [r12+0x60]
    74a37e501a8e:	mov    DWORD PTR [r15],r14d
    74a37e501a91:	mov    r14d,0x0
    74a37e501a97:	mov    DWORD PTR [r12+0x32c],r14d
    74a37e501a9f:	sub    r13,0x1
    74a37e501aa3:	mov    QWORD PTR [r12+0x50],r13
    74a37e501aa8:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e501ab0:	jrcxz  0x74a37e501ab7
    74a37e501ab2:	jmp    0x74a37e501e6f
    74a37e501ab7:	mov    r13,QWORD PTR [r12+0x58]
    74a37e501abc:	mov    rax,r13
    74a37e501abf:	test   rax,rax
    74a37e501ac2:	jne    0x74a37e5019fe
    74a37e501ac8:	jmp    0x74a37e501acd
    74a37e501acd:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e501ad5:	jrcxz  0x74a37e501adc
    74a37e501ad7:	jmp    0x74a37e501ef1
    74a37e501adc:	jmp    0x74a37e501ae1
    74a37e501ae1:	mov    r13d,0x0
    74a37e501ae7:	mov    QWORD PTR [r12+0x50],r13
    74a37e501aec:	jmp    0x74a37e501af1
    74a37e501af1:	mov    r13,QWORD PTR [r12+0x40]
    74a37e501af6:	add    r13,0x1
    74a37e501afa:	mov    QWORD PTR [r12+0x40],r13
    74a37e501aff:	mov    r14,QWORD PTR [r12+0x50]
    74a37e501b04:	mov    ecx,0xffffffff
    74a37e501b09:	and    r14,rcx
    74a37e501b0c:	shl    r14,0x2
    74a37e501b10:	mov    r15,QWORD PTR [r12+0x98]
    74a37e501b18:	add    r15,r14
    74a37e501b1b:	mov    r14d,DWORD PTR [r12+0x48]
    74a37e501b20:	mov    DWORD PTR [r15],r14d
    74a37e501b23:	mov    r14d,0x0
    74a37e501b29:	mov    DWORD PTR [r12+0x32c],r14d
    74a37e501b31:	sub    r13,0x400
    74a37e501b38:	jne    0x74a37e5019ba
    74a37e501b3e:	mov    r11,rax
    74a37e501b41:	lahf
    74a37e501b42:	seto   al
    74a37e501b45:	mov    WORD PTR [rsp],ax
    74a37e501b49:	mov    rax,r11
    74a37e501b4c:	jmp    0x74a37e501b51
    74a37e501b51:	mov    r13d,0x430000
    74a37e501b57:	mov    QWORD PTR [r12+0x40],r13
    74a37e501b5c:	mov    r13d,0x0
    74a37e501b62:	mov    QWORD PTR [r12+0x58],r13
    74a37e501b67:	mov    r13d,0x0
    74a37e501b6d:	mov    QWORD PTR [r12+0x50],r13
    74a37e501b72:	mov    r13d,0x430cb0
    74a37e501b78:	mov    r14,QWORD PTR [r13+0x0]
    74a37e501b7c:	mov    QWORD PTR [r12+0x48],r14
    74a37e501b81:	jmp    0x74a37e501b86
    74a37e501b86:	mov    r13,QWORD PTR [r12+0x58]
    74a37e501b8b:	mov    r14,r13
    74a37e501b8e:	shl    r14,0x2
    74a37e501b92:	mov    r15,QWORD PTR [r12+0x98]
    74a37e501b9a:	add    r15,r14
    74a37e501b9d:	mov    QWORD PTR [r12+0x60],r15
    74a37e501ba2:	mov    r14,r15
    74a37e501ba5:	add    r14,0x4
    74a37e501ba9:	mov    ebp,DWORD PTR [r15]
    74a37e501bac:	mov    r15d,DWORD PTR [r14]
    74a37e501baf:	mov    QWORD PTR [r12+0x60],r15
    74a37e501bb4:	mov    r14,rbp
    74a37e501bb7:	imul   r14,r13
    74a37e501bbb:	mov    r8,rbp
    74a37e501bbe:	add    r8,r14
    74a37e501bc1:	mov    QWORD PTR [r12+0x68],r8
    74a37e501bc6:	add    r13,0x2
    74a37e501bca:	mov    QWORD PTR [r12+0x58],r13
    74a37e501bcf:	mov    r14,r13
    74a37e501bd2:	sub    r14,0x400
    74a37e501bd9:	mov    r14,QWORD PTR [r12+0x50]
    74a37e501bde:	setne  BYTE PTR [rsp+0x8]
    74a37e501be3:	mov    r11,rax
    74a37e501be6:	lahf
    74a37e501be7:	seto   al
    74a37e501bea:	mov    WORD PTR [rsp],ax
    74a37e501bee:	mov    rax,r11
    74a37e501bf1:	imul   r13,r15
    74a37e501bf5:	add    r14,r13
    74a37e501bf8:	mov    QWORD PTR [r12+0x50],r14
    74a37e501bfd:	mov    r13,QWORD PTR [r12+0x48]
    74a37e501c02:	add    r8,r13
    74a37e501c05:	mov    QWORD PTR [r12+0x48],r8
    74a37e501c0a:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e501c12:	jrcxz  0x74a37e501c19
    74a37e501c14:	jmp    0x74a37e501f73
    74a37e501c19:	cmp    BYTE PTR [rsp+0x8],0x0
    74a37e501c1e:	jne    0x74a37e501b86
    74a37e501c24:	jmp    0x74a37e501c29
    74a37e501c29:	mov    r13d,0x0
    74a37e501c2f:	mov    QWORD PTR [r12+0x98],r13
    74a37e501c37:	mov    r13,QWORD PTR [r12+0x48]
    74a37e501c3c:	mov    r14,QWORD PTR [r12+0x50]
    74a37e501c41:	add    r14,r13
    74a37e501c44:	mov    QWORD PTR [r12+0x48],r14
    74a37e501c49:	mov    r13d,0x1
    74a37e501c4f:	mov    QWORD PTR [r12],r13
    74a37e501c53:	mov    r13,QWORD PTR [r12+0x40]
    74a37e501c58:	add    r13,0xcb0
    74a37e501c5f:	mov    QWORD PTR [r13+0x0],r14
    74a37e501c63:	mov    r13d,0x0
    74a37e501c69:	mov    DWORD PTR [r12+0x32c],r13d
    74a37e501c71:	mov    r13d,0x1
    74a37e501c77:	mov    QWORD PTR [r12],r13
    74a37e501c7b:	mov    r13d,0x4103f8
    74a37e501c81:	mov    QWORD PTR [r12+0xf0],r13
    74a37e501c89:	mov    r13d,0x4109a4
    74a37e501c8f:	mov    QWORD PTR [r12+0x100],r13
    74a37e501c97:	mov    r11,QWORD PTR [rsp]
    74a37e501c9b:	mov    QWORD PTR [r12+0x398],r11
    74a37e501ca3:	mov    edi,0x4109a4
    74a37e501ca8:	mov    QWORD PTR [r12+0x100],rdi
    74a37e501cb0:	add    rsp,0x10
    74a37e501cb4:	nop    DWORD PTR [rax+0x0]
    74a37e501cb8:	jmp    QWORD PTR [rip+0x2]        # 0x74a37e501cc0
    74a37e501cbe:	xchg   ax,ax
    74a37e501cc0:	rex (bad)
    74a37e501cc2:	push   rax
    74a37e501cc3:	jle    0x74a37e501c68
    74a37e501cc5:	je     0x74a37e501cc7
    74a37e501cc7:	add    al,dl
    74a37e501cc9:	sbb    al,0x50
    74a37e501ccb:	jle    0x74a37e501c70
    74a37e501ccd:	je     0x74a37e501ccf
    74a37e501ccf:	add    BYTE PTR [rcx-0x45],cl
    74a37e501cd2:	rex cdq
    74a37e501cd4:	outs   dx,BYTE PTR ds:[rsi]
    74a37e501cd5:	rex.RX adc eax,0x41000057
    74a37e501cdb:	jmp    rbx
    74a37e501cdd:	mov    r13d,DWORD PTR [r12+0xa0]
    74a37e501ce5:	add    r13d,0x11
    74a37e501ce9:	mov    QWORD PTR [r12],r13
    74a37e501ced:	mov    r13d,0x41035c
    74a37e501cf3:	mov    QWORD PTR [r12+0xf0],r13
    74a37e501cfb:	mov    r13d,0x4109a4
    74a37e501d01:	mov    QWORD PTR [r12+0x100],r13
    74a37e501d09:	mov    r11,QWORD PTR [rsp]
    74a37e501d0d:	mov    QWORD PTR [r12+0x398],r11
    74a37e501d15:	mov    edi,0x4109a4
    74a37e501d1a:	mov    QWORD PTR [r12+0x100],rdi
    74a37e501d22:	add    rsp,0x10
    74a37e501d26:	xchg   ax,ax
    74a37e501d28:	jmp    QWORD PTR [rip+0x2]        # 0x74a37e501d30
    74a37e501d2e:	xchg   ax,ax
    74a37e501d30:	rex (bad)
    74a37e501d32:	push   rax
    74a37e501d33:	jle    0x74a37e501cd8
    74a37e501d35:	je     0x74a37e501d37
    74a37e501d37:	add    BYTE PTR [rax+0x1d],al
    74a37e501d3a:	push   rax
    74a37e501d3b:	jle    0x74a37e501ce0
    74a37e501d3d:	je     0x74a37e501d3f
    74a37e501d3f:	add    BYTE PTR [rcx-0x45],cl
    74a37e501d42:	rex cdq
    74a37e501d44:	outs   dx,BYTE PTR ds:[rsi]
    74a37e501d45:	rex.RX adc eax,0x41000057
    74a37e501d4b:	jmp    rbx
    74a37e501d4d:	mov    eax,0x410368
    74a37e501d52:	mov    QWORD PTR [r12+0x100],rax
    74a37e501d5a:	push   rdx
    74a37e501d5b:	push   rsi
    74a37e501d5c:	push   r10
    74a37e501d5e:	push   r11
    74a37e501d60:	mov    r11,rax
    74a37e501d63:	lahf
    74a37e501d64:	seto   al
    74a37e501d67:	mov    WORD PTR [rsp+0x20],ax
    74a37e501d6c:	mov    rax,r11
    74a37e501d6f:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e501d74:	mov    r10d,edx
    74a37e501d77:	and    r10d,0xc000
    74a37e501d7e:	shl    r10d,0x10
    74a37e501d82:	mov    r11d,edx
    74a37e501d85:	and    r11d,0x100
    74a37e501d8c:	shl    r11d,0x15
    74a37e501d90:	or     r10d,r11d
    74a37e501d93:	and    edx,0x1
    74a37e501d96:	shl    edx,0x1c
    74a37e501d99:	or     r10d,edx
    74a37e501d9c:	btc    r10,0x1d
    74a37e501da1:	mov    r11d,0xf0000000
    74a37e501da7:	and    r11,r10
    74a37e501daa:	movabs rsi,0xffffffff0fffffff
    74a37e501db4:	and    rbx,rsi
    74a37e501db7:	or     rbx,r11
    74a37e501dba:	pop    r11
    74a37e501dbc:	pop    r10
    74a37e501dbe:	pop    rsi
    74a37e501dbf:	pop    rdx
    74a37e501dc0:	mov    QWORD PTR [r12+0x108],rbx
    74a37e501dc8:	add    rsp,0x10
    74a37e501dcc:	mov    eax,0xc
    74a37e501dd1:	movabs r11,0x5715466e9ca0
    74a37e501ddb:	jmp    r11
    74a37e501dde:	mov    eax,0x41039c
    74a37e501de3:	mov    QWORD PTR [r12+0x100],rax
    74a37e501deb:	push   rdx
    74a37e501dec:	push   rsi
    74a37e501ded:	push   r10
    74a37e501def:	push   r11
    74a37e501df1:	mov    r11,rax
    74a37e501df4:	lahf
    74a37e501df5:	seto   al
    74a37e501df8:	mov    WORD PTR [rsp+0x20],ax
    74a37e501dfd:	mov    rax,r11
    74a37e501e00:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e501e05:	mov    r10d,edx
    74a37e501e08:	and    r10d,0xc000
    74a37e501e0f:	shl    r10d,0x10
    74a37e501e13:	mov    r11d,edx
    74a37e501e16:	and    r11d,0x100
    74a37e501e1d:	shl    r11d,0x15
    74a37e501e21:	or     r10d,r11d
    74a37e501e24:	and    edx,0x1
    74a37e501e27:	shl    edx,0x1c
    74a37e501e2a:	or     r10d,edx
    74a37e501e2d:	btc    r10,0x1d
    74a37e501e32:	mov    r11d,0xf0000000
    74a37e501e38:	and    r11,r10
    74a37e501e3b:	movabs rsi,0xffffffff0fffffff
    74a37e501e45:	and    rbx,rsi
    74a37e501e48:	or     rbx,r11
    74a37e501e4b:	pop    r11
    74a37e501e4d:	pop    r10
    74a37e501e4f:	pop    rsi
    74a37e501e50:	pop    rdx
    74a37e501e51:	mov    QWORD PTR [r12+0x108],rbx
    74a37e501e59:	add    rsp,0x10
    74a37e501e5d:	mov    eax,0xc
    74a37e501e62:	movabs r11,0x5715466e9ca0
    74a37e501e6c:	jmp    r11
    74a37e501e6f:	mov    eax,0x4103a8
    74a37e501e74:	mov    QWORD PTR [r12+0x100],rax
    74a37e501e7c:	push   rdx
    74a37e501e7d:	push   rsi
    74a37e501e7e:	push   r10
    74a37e501e80:	push   r11
    74a37e501e82:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e501e87:	mov    r10d,edx
    74a37e501e8a:	and    r10d,0xc000
    74a37e501e91:	shl    r10d,0x10
    74a37e501e95:	mov    r11d,edx
    74a37e501e98:	and    r11d,0x100
    74a37e501e9f:	shl    r11d,0x15
    74a37e501ea3:	or     r10d,r11d
    74a37e501ea6:	and    edx,0x1
    74a37e501ea9:	shl    edx,0x1c
    74a37e501eac:	or     r10d,edx
    74a37e501eaf:	btc    r10,0x1d
    74a37e501eb4:	mov    r11d,0xf0000000
    74a37e501eba:	and    r11,r10
    74a37e501ebd:	movabs rsi,0xffffffff0fffffff
    74a37e501ec7:	and    rbx,rsi
    74a37e501eca:	or     rbx,r11
    74a37e501ecd:	pop    r11
    74a37e501ecf:	pop    r10
    74a37e501ed1:	pop    rsi
    74a37e501ed2:	pop    rdx
    74a37e501ed3:	mov    QWORD PTR [r12+0x108],rbx
    74a37e501edb:	add    rsp,0x10
    74a37e501edf:	mov    eax,0xc
    74a37e501ee4:	movabs r11,0x5715466e9ca0
    74a37e501eee:	jmp    r11
    74a37e501ef1:	mov    eax,0x4103ac
    74a37e501ef6:	mov    QWORD PTR [r12+0x100],rax
    74a37e501efe:	push   rdx
    74a37e501eff:	push   rsi
    74a37e501f00:	push   r10
    74a37e501f02:	push   r11
    74a37e501f04:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e501f09:	mov    r10d,edx
    74a37e501f0c:	and    r10d,0xc000
    74a37e501f13:	shl    r10d,0x10
    74a37e501f17:	mov    r11d,edx
    74a37e501f1a:	and    r11d,0x100
    74a37e501f21:	shl    r11d,0x15
    74a37e501f25:	or     r10d,r11d
    74a37e501f28:	and    edx,0x1
    74a37e501f2b:	shl    edx,0x1c
    74a37e501f2e:	or     r10d,edx
    74a37e501f31:	btc    r10,0x1d
    74a37e501f36:	mov    r11d,0xf0000000
    74a37e501f3c:	and    r11,r10
    74a37e501f3f:	movabs rsi,0xffffffff0fffffff
    74a37e501f49:	and    rbx,rsi
    74a37e501f4c:	or     rbx,r11
    74a37e501f4f:	pop    r11
    74a37e501f51:	pop    r10
    74a37e501f53:	pop    rsi
    74a37e501f54:	pop    rdx
    74a37e501f55:	mov    QWORD PTR [r12+0x108],rbx
    74a37e501f5d:	add    rsp,0x10
    74a37e501f61:	mov    eax,0xc
    74a37e501f66:	movabs r11,0x5715466e9ca0
    74a37e501f70:	jmp    r11
    74a37e501f73:	mov    eax,0x4103dc
    74a37e501f78:	mov    QWORD PTR [r12+0x100],rax
    74a37e501f80:	push   rdx
    74a37e501f81:	push   rsi
    74a37e501f82:	push   r10
    74a37e501f84:	push   r11
    74a37e501f86:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e501f8b:	mov    r10d,edx
    74a37e501f8e:	and    r10d,0xc000
    74a37e501f95:	shl    r10d,0x10
    74a37e501f99:	mov    r11d,edx
    74a37e501f9c:	and    r11d,0x100
    74a37e501fa3:	shl    r11d,0x15
    74a37e501fa7:	or     r10d,r11d
    74a37e501faa:	and    edx,0x1
    74a37e501fad:	shl    edx,0x1c
    74a37e501fb0:	or     r10d,edx
    74a37e501fb3:	btc    r10,0x1d
    74a37e501fb8:	mov    r11d,0xf0000000
    74a37e501fbe:	and    r11,r10
    74a37e501fc1:	movabs rsi,0xffffffff0fffffff
    74a37e501fcb:	and    rbx,rsi
    74a37e501fce:	or     rbx,r11
    74a37e501fd1:	pop    r11
    74a37e501fd3:	pop    r10
    74a37e501fd5:	pop    rsi
    74a37e501fd6:	pop    rdx
    74a37e501fd7:	mov    QWORD PTR [r12+0x108],rbx
    74a37e501fdf:	add    rsp,0x10
    74a37e501fe3:	mov    eax,0xc
    74a37e501fe8:	movabs r11,0x5715466e9ca0
    74a37e501ff2:	jmp    r11
    74a37e501ff5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e502000:	sub    rsp,0x10
    74a37e502004:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50200c:	mov    QWORD PTR [rsp],r11
    74a37e502010:	jmp    0x74a37e50199d
    74a37e502015:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e502020:	sub    rsp,0x10
    74a37e502024:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50202c:	mov    QWORD PTR [rsp],r11
    74a37e502030:	mov    r11,rax
    74a37e502033:	movzx  eax,WORD PTR [rsp]
    74a37e502037:	add    al,0x7f
    74a37e502039:	sahf
    74a37e50203a:	mov    rax,r11
    74a37e50203d:	jmp    0x74a37e5019ba
    74a37e502042:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e502050:	sub    rsp,0x10
    74a37e502054:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50205c:	mov    QWORD PTR [rsp],r11
    74a37e502060:	jmp    0x74a37e5019fe
    74a37e502065:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e502070:	sub    rsp,0x10
    74a37e502074:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50207c:	mov    QWORD PTR [rsp],r11
    74a37e502080:	jmp    0x74a37e501a72
    74a37e502085:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e502090:	sub    rsp,0x10
    74a37e502094:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50209c:	mov    QWORD PTR [rsp],r11
    74a37e5020a0:	jmp    0x74a37e501acd
    74a37e5020a5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e5020b0:	sub    rsp,0x10
    74a37e5020b4:	mov    r11,QWORD PTR [r12+0x398]
    74a37e5020bc:	mov    QWORD PTR [rsp],r11
    74a37e5020c0:	jmp    0x74a37e501ae1
    74a37e5020c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e5020d0:	sub    rsp,0x10
    74a37e5020d4:	mov    r11,QWORD PTR [r12+0x398]
    74a37e5020dc:	mov    QWORD PTR [rsp],r11
    74a37e5020e0:	jmp    0x74a37e501af1
    74a37e5020e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e5020f0:	sub    rsp,0x10
    74a37e5020f4:	mov    r11,QWORD PTR [r12+0x398]
    74a37e5020fc:	mov    QWORD PTR [rsp],r11
    74a37e502100:	jmp    0x74a37e501b51
    74a37e502105:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e502110:	sub    rsp,0x10
    74a37e502114:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50211c:	mov    QWORD PTR [rsp],r11
    74a37e502120:	jmp    0x74a37e501b86
    74a37e502125:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e502130:	sub    rsp,0x10
    74a37e502134:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50213c:	mov    QWORD PTR [rsp],r11
    74a37e502140:	jmp    0x74a37e501c29
    74a37e502145:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e502150:	sub    rsp,0x10
    74a37e502154:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50215c:	mov    QWORD PTR [rsp],r11
    74a37e502160:	jmp    0x74a37e501cdd
    74a37e502165:	nop
    74a37e502166:	nop
    74a37e502167:	nop
