
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/2/1.bin:     file format binary


Disassembly of section .data:

00007f716edfd5e0 <.data>:
    7f716edfd5e0:	sub    rsp,0xc0
    7f716edfd5e7:	mov    r11,QWORD PTR [r12+0x398]
    7f716edfd5ef:	mov    QWORD PTR [rsp+0xb0],r11
    7f716edfd5f7:	mov    r13,QWORD PTR [r12]
    7f716edfd5fb:	mov    r14,r13
    7f716edfd5fe:	add    r14,0x20
    7f716edfd602:	mov    r15,QWORD PTR [r14]
    7f716edfd605:	mov    r14,QWORD PTR [r12+0x10]
    7f716edfd60a:	add    r15,r14
    7f716edfd60d:	mov    QWORD PTR [r12+0x40],r15
    7f716edfd612:	add    r13,0x20
    7f716edfd616:	mov    QWORD PTR [r13+0x0],r15
    7f716edfd61a:	mov    r13d,0x0
    7f716edfd620:	mov    DWORD PTR [r12+0x32c],r13d
    7f716edfd628:	mov    rax,r14
    7f716edfd62b:	test   rax,rax
    7f716edfd62e:	je     0x7f716edff735
    7f716edfd634:	jmp    0x7f716edfd639
    7f716edfd639:	mov    r13,QWORD PTR [r12+0xf8]
    7f716edfd641:	sub    r13,0x150
    7f716edfd648:	mov    QWORD PTR [r12+0xf8],r13
    7f716edfd650:	mov    r14,QWORD PTR [r12]
    7f716edfd654:	mov    r15,r14
    7f716edfd657:	add    r15,0x68
    7f716edfd65b:	mov    rbp,QWORD PTR [r15]
    7f716edfd65e:	mov    QWORD PTR [r12+0x88],rbp
    7f716edfd666:	add    r14,0x28
    7f716edfd66a:	mov    QWORD PTR [r12+0x40],r14
    7f716edfd66f:	mov    QWORD PTR [r12+0x48],r13
    7f716edfd674:	mov    r14d,0x420000
    7f716edfd67a:	add    r14,0xb90
    7f716edfd681:	mov    QWORD PTR [r12+0x50],r14
    7f716edfd686:	mov    r14,r13
    7f716edfd689:	add    r14,0x100
    7f716edfd690:	mov    r15,r14
    7f716edfd693:	add    r15,0x8
    7f716edfd697:	mov    rbp,QWORD PTR [r12+0xe8]
    7f716edfd69f:	mov    r8,QWORD PTR [r12+0xd8]
    7f716edfd6a7:	mov    QWORD PTR [r14],rbp
    7f716edfd6aa:	mov    r14d,0x0
    7f716edfd6b0:	mov    DWORD PTR [r12+0x32c],r14d
    7f716edfd6b8:	mov    QWORD PTR [r15],r8
    7f716edfd6bb:	mov    r14,r13
    7f716edfd6be:	add    r14,0x110
    7f716edfd6c5:	mov    r15,r14
    7f716edfd6c8:	add    r15,0x8
    7f716edfd6cc:	mov    rbp,QWORD PTR [r12+0xd0]
    7f716edfd6d4:	mov    r8,QWORD PTR [r12+0xc8]
    7f716edfd6dc:	mov    QWORD PTR [r14],rbp
    7f716edfd6df:	mov    QWORD PTR [r15],r8
    7f716edfd6e2:	mov    r14,r13
    7f716edfd6e5:	add    r14,0x120
    7f716edfd6ec:	mov    r15,r14
    7f716edfd6ef:	add    r15,0x8
    7f716edfd6f3:	mov    rbp,QWORD PTR [r12+0xc0]
    7f716edfd6fb:	mov    r8,QWORD PTR [r12+0xb8]
    7f716edfd703:	mov    QWORD PTR [r14],rbp
    7f716edfd706:	mov    QWORD PTR [r15],r8
    7f716edfd709:	mov    r14,r13
    7f716edfd70c:	add    r14,0x130
    7f716edfd713:	mov    r15,r14
    7f716edfd716:	add    r15,0x8
    7f716edfd71a:	mov    rbp,QWORD PTR [r12+0xb0]
    7f716edfd722:	mov    r8,QWORD PTR [r12+0xa8]
    7f716edfd72a:	mov    QWORD PTR [r14],rbp
    7f716edfd72d:	mov    QWORD PTR [r15],r8
    7f716edfd730:	add    r13,0x140
    7f716edfd737:	mov    r14,r13
    7f716edfd73a:	add    r14,0x8
    7f716edfd73e:	mov    r15,QWORD PTR [r12+0xa0]
    7f716edfd746:	mov    rbp,QWORD PTR [r12+0x98]
    7f716edfd74e:	mov    QWORD PTR [r13+0x0],r15
    7f716edfd752:	mov    QWORD PTR [r14],rbp
    7f716edfd755:	jmp    0x7f716edfd75a
    7f716edfd75a:	mov    r13,QWORD PTR [r12+0x8]
    7f716edfd75f:	mov    r14,r13
    7f716edfd762:	add    r14,0x1
    7f716edfd766:	movzx  r15d,BYTE PTR [r13+0x0]
    7f716edfd76b:	mov    QWORD PTR [r12+0x58],r15
    7f716edfd770:	mov    QWORD PTR [r12+0x8],r14
    7f716edfd775:	mov    r13,QWORD PTR [r12+0x88]
    7f716edfd77d:	mov    r14,r13
    7f716edfd780:	add    r14,0x1
    7f716edfd784:	mov    QWORD PTR [r12+0x60],r14
    7f716edfd789:	mov    r15,QWORD PTR [r12]
    7f716edfd78d:	mov    rbp,r15
    7f716edfd790:	add    rbp,0x68
    7f716edfd794:	mov    QWORD PTR [rbp+0x0],r14
    7f716edfd798:	mov    r14d,0x0
    7f716edfd79e:	mov    DWORD PTR [r12+0x32c],r14d
    7f716edfd7a6:	mov    r14,r15
    7f716edfd7a9:	add    r14,r13
    7f716edfd7ac:	mov    QWORD PTR [r12+0x60],r14
    7f716edfd7b1:	add    r14,0x28
    7f716edfd7b5:	movzx  r13d,BYTE PTR [r12+0x58]
    7f716edfd7bb:	mov    BYTE PTR [r14],r13b
    7f716edfd7be:	add    r15,0x68
    7f716edfd7c2:	mov    r13,QWORD PTR [r15]
    7f716edfd7c5:	mov    QWORD PTR [r12+0x88],r13
    7f716edfd7cd:	sub    r13,0x40
    7f716edfd7d1:	mov    rcx,QWORD PTR [r12+0x380]
    7f716edfd7d9:	jrcxz  0x7f716edfd7e0
    7f716edfd7db:	jmp    0x7f716edff780
    7f716edfd7e0:	jne    0x7f716edfd7fd
    7f716edfd7e6:	mov    r11,rax
    7f716edfd7e9:	lahf
    7f716edfd7ea:	seto   al
    7f716edfd7ed:	mov    WORD PTR [rsp+0xb0],ax
    7f716edfd7f5:	mov    rax,r11
    7f716edfd7f8:	jmp    0x7f716edfd814
    7f716edfd7fd:	mov    r11,rax
    7f716edfd800:	lahf
    7f716edfd801:	seto   al
    7f716edfd804:	mov    WORD PTR [rsp+0xb0],ax
    7f716edfd80c:	mov    rax,r11
    7f716edfd80f:	jmp    0x7f716edff637
    7f716edfd814:	mov    rax,QWORD PTR [r12+0x40]
    7f716edfd819:	mov    eax,0x0
    7f716edfd81e:	mov    QWORD PTR [rsp+0x18],rax
    7f716edfd823:	mov    eax,0x0
    7f716edfd828:	mov    QWORD PTR [rsp+0x10],rax
    7f716edfd82d:	mov    eax,0x0
    7f716edfd832:	mov    QWORD PTR [rsp+0x8],rax
    7f716edfd837:	mov    eax,0x0
    7f716edfd83c:	mov    QWORD PTR [rsp],rax
    7f716edfd840:	mov    rdi,QWORD PTR [r12+0x40]
    7f716edfd845:	movzx  r9d,BYTE PTR [rdi]
    7f716edfd849:	mov    r13,QWORD PTR [rsp+0x18]
    7f716edfd84e:	or     r13,r9
    7f716edfd851:	mov    r9,QWORD PTR [r12+0x40]
    7f716edfd856:	add    r9,0x1
    7f716edfd85a:	movzx  r8d,BYTE PTR [r9]
    7f716edfd85e:	mov    r9,QWORD PTR [rsp+0x10]
    7f716edfd863:	or     r9,r8
    7f716edfd866:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfd86b:	add    r8,0x2
    7f716edfd86f:	movzx  ebp,BYTE PTR [r8]
    7f716edfd873:	mov    r8,QWORD PTR [rsp+0x8]
    7f716edfd878:	or     r8,rbp
    7f716edfd87b:	mov    rbp,QWORD PTR [r12+0x40]
    7f716edfd880:	add    rbp,0x3
    7f716edfd884:	movzx  r15d,BYTE PTR [rbp+0x0]
    7f716edfd889:	mov    rbp,QWORD PTR [rsp]
    7f716edfd88d:	or     rbp,r15
    7f716edfd890:	mov    r15,QWORD PTR [r12+0x40]
    7f716edfd895:	add    r15,0x4
    7f716edfd899:	movzx  r14d,BYTE PTR [r15]
    7f716edfd89d:	mov    r15,r14
    7f716edfd8a0:	shl    r15,0x8
    7f716edfd8a4:	or     r13,r15
    7f716edfd8a7:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd8ac:	add    r14,0x5
    7f716edfd8b0:	movzx  r15d,BYTE PTR [r14]
    7f716edfd8b4:	mov    r14,r15
    7f716edfd8b7:	shl    r14,0x8
    7f716edfd8bb:	or     r9,r14
    7f716edfd8be:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd8c3:	add    r14,0x6
    7f716edfd8c7:	movzx  r15d,BYTE PTR [r14]
    7f716edfd8cb:	mov    r14,r15
    7f716edfd8ce:	shl    r14,0x8
    7f716edfd8d2:	or     r8,r14
    7f716edfd8d5:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd8da:	add    r14,0x7
    7f716edfd8de:	movzx  r15d,BYTE PTR [r14]
    7f716edfd8e2:	mov    r14,r15
    7f716edfd8e5:	shl    r14,0x8
    7f716edfd8e9:	or     rbp,r14
    7f716edfd8ec:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd8f1:	add    r14,0x8
    7f716edfd8f5:	movzx  r15d,BYTE PTR [r14]
    7f716edfd8f9:	mov    r14,r15
    7f716edfd8fc:	shl    r14,0x10
    7f716edfd900:	or     r13,r14
    7f716edfd903:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd908:	add    r14,0x9
    7f716edfd90c:	movzx  r15d,BYTE PTR [r14]
    7f716edfd910:	mov    r14,r15
    7f716edfd913:	shl    r14,0x10
    7f716edfd917:	or     r9,r14
    7f716edfd91a:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd91f:	add    r14,0xa
    7f716edfd923:	movzx  r15d,BYTE PTR [r14]
    7f716edfd927:	mov    r14,r15
    7f716edfd92a:	shl    r14,0x10
    7f716edfd92e:	or     r8,r14
    7f716edfd931:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd936:	add    r14,0xb
    7f716edfd93a:	movzx  r15d,BYTE PTR [r14]
    7f716edfd93e:	mov    r14,r15
    7f716edfd941:	shl    r14,0x10
    7f716edfd945:	or     rbp,r14
    7f716edfd948:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd94d:	add    r14,0xc
    7f716edfd951:	movzx  r15d,BYTE PTR [r14]
    7f716edfd955:	mov    r14,r15
    7f716edfd958:	shl    r14,0x18
    7f716edfd95c:	or     r13,r14
    7f716edfd95f:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd964:	add    r14,0xd
    7f716edfd968:	movzx  r15d,BYTE PTR [r14]
    7f716edfd96c:	mov    r14,r15
    7f716edfd96f:	shl    r14,0x18
    7f716edfd973:	or     r9,r14
    7f716edfd976:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd97b:	add    r14,0xe
    7f716edfd97f:	movzx  r15d,BYTE PTR [r14]
    7f716edfd983:	mov    r14,r15
    7f716edfd986:	shl    r14,0x18
    7f716edfd98a:	or     r8,r14
    7f716edfd98d:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd992:	add    r14,0xf
    7f716edfd996:	movzx  r15d,BYTE PTR [r14]
    7f716edfd99a:	mov    r14,r15
    7f716edfd99d:	shl    r14,0x18
    7f716edfd9a1:	or     rbp,r14
    7f716edfd9a4:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd9a9:	add    r14,0x10
    7f716edfd9ad:	movzx  r15d,BYTE PTR [r14]
    7f716edfd9b1:	mov    r14,r15
    7f716edfd9b4:	shl    r14,0x20
    7f716edfd9b8:	or     r13,r14
    7f716edfd9bb:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd9c0:	add    r14,0x11
    7f716edfd9c4:	movzx  r15d,BYTE PTR [r14]
    7f716edfd9c8:	mov    r14,r15
    7f716edfd9cb:	shl    r14,0x20
    7f716edfd9cf:	or     r9,r14
    7f716edfd9d2:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd9d7:	add    r14,0x12
    7f716edfd9db:	movzx  r15d,BYTE PTR [r14]
    7f716edfd9df:	mov    r14,r15
    7f716edfd9e2:	shl    r14,0x20
    7f716edfd9e6:	or     r8,r14
    7f716edfd9e9:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfd9ee:	add    r14,0x13
    7f716edfd9f2:	movzx  r15d,BYTE PTR [r14]
    7f716edfd9f6:	mov    r14,r15
    7f716edfd9f9:	shl    r14,0x20
    7f716edfd9fd:	or     rbp,r14
    7f716edfda00:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfda05:	add    r14,0x14
    7f716edfda09:	movzx  r15d,BYTE PTR [r14]
    7f716edfda0d:	mov    r14,r15
    7f716edfda10:	shl    r14,0x28
    7f716edfda14:	or     r13,r14
    7f716edfda17:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfda1c:	add    r14,0x15
    7f716edfda20:	movzx  r15d,BYTE PTR [r14]
    7f716edfda24:	mov    r14,r15
    7f716edfda27:	shl    r14,0x28
    7f716edfda2b:	or     r9,r14
    7f716edfda2e:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfda33:	add    r14,0x16
    7f716edfda37:	movzx  r15d,BYTE PTR [r14]
    7f716edfda3b:	mov    r14,r15
    7f716edfda3e:	shl    r14,0x28
    7f716edfda42:	or     r8,r14
    7f716edfda45:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfda4a:	add    r14,0x17
    7f716edfda4e:	movzx  r15d,BYTE PTR [r14]
    7f716edfda52:	mov    r14,r15
    7f716edfda55:	shl    r14,0x28
    7f716edfda59:	or     rbp,r14
    7f716edfda5c:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfda61:	add    r14,0x18
    7f716edfda65:	movzx  r15d,BYTE PTR [r14]
    7f716edfda69:	mov    r14,r15
    7f716edfda6c:	shl    r14,0x30
    7f716edfda70:	or     r13,r14
    7f716edfda73:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfda78:	add    r14,0x19
    7f716edfda7c:	movzx  r15d,BYTE PTR [r14]
    7f716edfda80:	mov    r14,r15
    7f716edfda83:	shl    r14,0x30
    7f716edfda87:	or     r9,r14
    7f716edfda8a:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfda8f:	add    r14,0x1a
    7f716edfda93:	movzx  r15d,BYTE PTR [r14]
    7f716edfda97:	mov    r14,r15
    7f716edfda9a:	shl    r14,0x30
    7f716edfda9e:	or     r8,r14
    7f716edfdaa1:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfdaa6:	add    r14,0x1b
    7f716edfdaaa:	movzx  r15d,BYTE PTR [r14]
    7f716edfdaae:	mov    r14,r15
    7f716edfdab1:	shl    r14,0x30
    7f716edfdab5:	or     rbp,r14
    7f716edfdab8:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfdabd:	add    r14,0x1c
    7f716edfdac1:	movzx  r15d,BYTE PTR [r14]
    7f716edfdac5:	mov    r14,r15
    7f716edfdac8:	shl    r14,0x38
    7f716edfdacc:	mov    rax,r13
    7f716edfdacf:	or     rax,r14
    7f716edfdad2:	mov    QWORD PTR [rsp+0x28],rax
    7f716edfdad7:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfdadc:	add    r14,0x1d
    7f716edfdae0:	movzx  r15d,BYTE PTR [r14]
    7f716edfdae4:	mov    r14,r15
    7f716edfdae7:	shl    r14,0x38
    7f716edfdaeb:	mov    rax,r9
    7f716edfdaee:	or     rax,r14
    7f716edfdaf1:	mov    QWORD PTR [rsp+0x38],rax
    7f716edfdaf6:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfdafb:	add    r14,0x1e
    7f716edfdaff:	movzx  r15d,BYTE PTR [r14]
    7f716edfdb03:	mov    r14,r15
    7f716edfdb06:	shl    r14,0x38
    7f716edfdb0a:	mov    rax,r8
    7f716edfdb0d:	or     rax,r14
    7f716edfdb10:	mov    QWORD PTR [rsp+0x30],rax
    7f716edfdb15:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfdb1a:	add    r14,0x1f
    7f716edfdb1e:	movzx  r15d,BYTE PTR [r14]
    7f716edfdb22:	mov    r14,r15
    7f716edfdb25:	shl    r14,0x38
    7f716edfdb29:	mov    rax,rbp
    7f716edfdb2c:	or     rax,r14
    7f716edfdb2f:	mov    QWORD PTR [rsp+0x20],rax
    7f716edfdb34:	mov    r14,QWORD PTR [r12+0x40]
    7f716edfdb39:	add    r14,0x20
    7f716edfdb3d:	movzx  r15d,BYTE PTR [r14]
    7f716edfdb41:	mov    r14,QWORD PTR [rsp+0x18]
    7f716edfdb46:	or     r14,r15
    7f716edfdb49:	mov    r15,QWORD PTR [r12+0x40]
    7f716edfdb4e:	add    r15,0x21
    7f716edfdb52:	movzx  ebp,BYTE PTR [r15]
    7f716edfdb56:	mov    r15,QWORD PTR [rsp+0x10]
    7f716edfdb5b:	or     r15,rbp
    7f716edfdb5e:	mov    rbp,QWORD PTR [r12+0x40]
    7f716edfdb63:	add    rbp,0x22
    7f716edfdb67:	movzx  r13d,BYTE PTR [rbp+0x0]
    7f716edfdb6c:	mov    rbp,QWORD PTR [rsp+0x8]
    7f716edfdb71:	or     rbp,r13
    7f716edfdb74:	mov    r13,QWORD PTR [r12+0x40]
    7f716edfdb79:	add    r13,0x23
    7f716edfdb7d:	movzx  r8d,BYTE PTR [r13+0x0]
    7f716edfdb82:	mov    r13,QWORD PTR [rsp]
    7f716edfdb86:	or     r13,r8
    7f716edfdb89:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdb8e:	add    r8,0x24
    7f716edfdb92:	movzx  r9d,BYTE PTR [r8]
    7f716edfdb96:	mov    r8,r9
    7f716edfdb99:	shl    r8,0x8
    7f716edfdb9d:	or     r14,r8
    7f716edfdba0:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdba5:	add    r8,0x25
    7f716edfdba9:	movzx  r9d,BYTE PTR [r8]
    7f716edfdbad:	mov    r8,r9
    7f716edfdbb0:	shl    r8,0x8
    7f716edfdbb4:	or     r15,r8
    7f716edfdbb7:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdbbc:	add    r8,0x26
    7f716edfdbc0:	movzx  r9d,BYTE PTR [r8]
    7f716edfdbc4:	mov    r8,r9
    7f716edfdbc7:	shl    r8,0x8
    7f716edfdbcb:	or     rbp,r8
    7f716edfdbce:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdbd3:	add    r8,0x27
    7f716edfdbd7:	movzx  r9d,BYTE PTR [r8]
    7f716edfdbdb:	mov    r8,r9
    7f716edfdbde:	shl    r8,0x8
    7f716edfdbe2:	or     r13,r8
    7f716edfdbe5:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdbea:	add    r8,0x28
    7f716edfdbee:	movzx  r9d,BYTE PTR [r8]
    7f716edfdbf2:	mov    r8,r9
    7f716edfdbf5:	shl    r8,0x10
    7f716edfdbf9:	or     r14,r8
    7f716edfdbfc:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdc01:	add    r8,0x29
    7f716edfdc05:	movzx  r9d,BYTE PTR [r8]
    7f716edfdc09:	mov    r8,r9
    7f716edfdc0c:	shl    r8,0x10
    7f716edfdc10:	or     r15,r8
    7f716edfdc13:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdc18:	add    r8,0x2a
    7f716edfdc1c:	movzx  r9d,BYTE PTR [r8]
    7f716edfdc20:	mov    r8,r9
    7f716edfdc23:	shl    r8,0x10
    7f716edfdc27:	or     rbp,r8
    7f716edfdc2a:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdc2f:	add    r8,0x2b
    7f716edfdc33:	movzx  r9d,BYTE PTR [r8]
    7f716edfdc37:	mov    r8,r9
    7f716edfdc3a:	shl    r8,0x10
    7f716edfdc3e:	or     r13,r8
    7f716edfdc41:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdc46:	add    r8,0x2c
    7f716edfdc4a:	movzx  r9d,BYTE PTR [r8]
    7f716edfdc4e:	mov    r8,r9
    7f716edfdc51:	shl    r8,0x18
    7f716edfdc55:	or     r14,r8
    7f716edfdc58:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdc5d:	add    r8,0x2d
    7f716edfdc61:	movzx  r9d,BYTE PTR [r8]
    7f716edfdc65:	mov    r8,r9
    7f716edfdc68:	shl    r8,0x18
    7f716edfdc6c:	or     r15,r8
    7f716edfdc6f:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdc74:	add    r8,0x2e
    7f716edfdc78:	movzx  r9d,BYTE PTR [r8]
    7f716edfdc7c:	mov    r8,r9
    7f716edfdc7f:	shl    r8,0x18
    7f716edfdc83:	or     rbp,r8
    7f716edfdc86:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdc8b:	add    r8,0x2f
    7f716edfdc8f:	movzx  r9d,BYTE PTR [r8]
    7f716edfdc93:	mov    r8,r9
    7f716edfdc96:	shl    r8,0x18
    7f716edfdc9a:	or     r13,r8
    7f716edfdc9d:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdca2:	add    r8,0x30
    7f716edfdca6:	movzx  r9d,BYTE PTR [r8]
    7f716edfdcaa:	mov    r8,r9
    7f716edfdcad:	shl    r8,0x20
    7f716edfdcb1:	or     r14,r8
    7f716edfdcb4:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdcb9:	add    r8,0x31
    7f716edfdcbd:	movzx  r9d,BYTE PTR [r8]
    7f716edfdcc1:	mov    r8,r9
    7f716edfdcc4:	shl    r8,0x20
    7f716edfdcc8:	or     r15,r8
    7f716edfdccb:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdcd0:	add    r8,0x32
    7f716edfdcd4:	movzx  r9d,BYTE PTR [r8]
    7f716edfdcd8:	mov    r8,r9
    7f716edfdcdb:	shl    r8,0x20
    7f716edfdcdf:	or     rbp,r8
    7f716edfdce2:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdce7:	add    r8,0x33
    7f716edfdceb:	movzx  r9d,BYTE PTR [r8]
    7f716edfdcef:	mov    r8,r9
    7f716edfdcf2:	shl    r8,0x20
    7f716edfdcf6:	or     r13,r8
    7f716edfdcf9:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdcfe:	add    r8,0x34
    7f716edfdd02:	movzx  r9d,BYTE PTR [r8]
    7f716edfdd06:	mov    r8,r9
    7f716edfdd09:	shl    r8,0x28
    7f716edfdd0d:	or     r14,r8
    7f716edfdd10:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdd15:	add    r8,0x35
    7f716edfdd19:	movzx  r9d,BYTE PTR [r8]
    7f716edfdd1d:	mov    r8,r9
    7f716edfdd20:	shl    r8,0x28
    7f716edfdd24:	or     r15,r8
    7f716edfdd27:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdd2c:	add    r8,0x36
    7f716edfdd30:	movzx  r9d,BYTE PTR [r8]
    7f716edfdd34:	mov    r8,r9
    7f716edfdd37:	shl    r8,0x28
    7f716edfdd3b:	or     rbp,r8
    7f716edfdd3e:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdd43:	add    r8,0x37
    7f716edfdd47:	movzx  r9d,BYTE PTR [r8]
    7f716edfdd4b:	mov    r8,r9
    7f716edfdd4e:	shl    r8,0x28
    7f716edfdd52:	or     r13,r8
    7f716edfdd55:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdd5a:	add    r8,0x38
    7f716edfdd5e:	movzx  r9d,BYTE PTR [r8]
    7f716edfdd62:	mov    r8,r9
    7f716edfdd65:	shl    r8,0x30
    7f716edfdd69:	or     r14,r8
    7f716edfdd6c:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdd71:	add    r8,0x39
    7f716edfdd75:	movzx  r9d,BYTE PTR [r8]
    7f716edfdd79:	mov    r8,r9
    7f716edfdd7c:	shl    r8,0x30
    7f716edfdd80:	or     r15,r8
    7f716edfdd83:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdd88:	add    r8,0x3a
    7f716edfdd8c:	movzx  r9d,BYTE PTR [r8]
    7f716edfdd90:	mov    r8,r9
    7f716edfdd93:	shl    r8,0x30
    7f716edfdd97:	or     rbp,r8
    7f716edfdd9a:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdd9f:	add    r8,0x3b
    7f716edfdda3:	movzx  r9d,BYTE PTR [r8]
    7f716edfdda7:	mov    r8,r9
    7f716edfddaa:	shl    r8,0x30
    7f716edfddae:	or     r13,r8
    7f716edfddb1:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfddb6:	add    r8,0x3c
    7f716edfddba:	movzx  r9d,BYTE PTR [r8]
    7f716edfddbe:	mov    r8,r9
    7f716edfddc1:	shl    r8,0x38
    7f716edfddc5:	or     r14,r8
    7f716edfddc8:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfddcd:	add    r8,0x3d
    7f716edfddd1:	movzx  r9d,BYTE PTR [r8]
    7f716edfddd5:	mov    r8,r9
    7f716edfddd8:	shl    r8,0x38
    7f716edfdddc:	or     r15,r8
    7f716edfdddf:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfdde4:	add    r8,0x3e
    7f716edfdde8:	movzx  r9d,BYTE PTR [r8]
    7f716edfddec:	mov    r8,r9
    7f716edfddef:	shl    r8,0x38
    7f716edfddf3:	or     rbp,r8
    7f716edfddf6:	mov    r8,QWORD PTR [r12+0x40]
    7f716edfddfb:	add    r8,0x3f
    7f716edfddff:	movzx  r9d,BYTE PTR [r8]
    7f716edfde03:	mov    r8,r9
    7f716edfde06:	shl    r8,0x38
    7f716edfde0a:	mov    rax,r13
    7f716edfde0d:	or     rax,r8
    7f716edfde10:	mov    QWORD PTR [rsp+0x40],rax
    7f716edfde15:	mov    r8d,0x0
    7f716edfde1b:	mov    QWORD PTR [r12+0x58],r8
    7f716edfde20:	mov    r8d,0x0
    7f716edfde26:	mov    r9,QWORD PTR [rsp+0x38]
    7f716edfde2b:	and    r9,0xff
    7f716edfde32:	and    r9,0xffff
    7f716edfde39:	mov    r13,r8
    7f716edfde3c:	or     r13,r9
    7f716edfde3f:	mov    r9,QWORD PTR [rsp+0x38]
    7f716edfde44:	shr    r9,0x8
    7f716edfde48:	and    r9,0xff
    7f716edfde4f:	and    r9,0xffff
    7f716edfde56:	shl    r9,0x10
    7f716edfde5a:	or     r13,r9
    7f716edfde5d:	mov    r9,QWORD PTR [rsp+0x38]
    7f716edfde62:	shr    r9,0x10
    7f716edfde66:	and    r9,0xff
    7f716edfde6d:	and    r9,0xffff
    7f716edfde74:	shl    r9,0x20
    7f716edfde78:	or     r13,r9
    7f716edfde7b:	mov    r9,QWORD PTR [rsp+0x38]
    7f716edfde80:	shr    r9,0x18
    7f716edfde84:	and    r9,0xff
    7f716edfde8b:	and    r9,0xffff
    7f716edfde92:	shl    r9,0x30
    7f716edfde96:	or     r13,r9
    7f716edfde99:	mov    r9,QWORD PTR [rsp+0x38]
    7f716edfde9e:	shr    r9,0x20
    7f716edfdea2:	and    r9,0xff
    7f716edfdea9:	and    r9,0xffff
    7f716edfdeb0:	or     r8,r9
    7f716edfdeb3:	mov    r9,QWORD PTR [rsp+0x38]
    7f716edfdeb8:	shr    r9,0x28
    7f716edfdebc:	and    r9,0xff
    7f716edfdec3:	and    r9,0xffff
    7f716edfdeca:	shl    r9,0x10
    7f716edfdece:	or     r8,r9
    7f716edfded1:	mov    r9,QWORD PTR [rsp+0x38]
    7f716edfded6:	shr    r9,0x30
    7f716edfdeda:	and    r9,0xff
    7f716edfdee1:	and    r9,0xffff
    7f716edfdee8:	shl    r9,0x20
    7f716edfdeec:	or     r8,r9
    7f716edfdeef:	mov    r9,QWORD PTR [rsp+0x38]
    7f716edfdef4:	shr    r9,0x38
    7f716edfdef8:	and    r9,0xff
    7f716edfdeff:	and    r9,0xffff
    7f716edfdf06:	shl    r9,0x30
    7f716edfdf0a:	or     r8,r9
    7f716edfdf0d:	mov    QWORD PTR [r12+0x150],r13
    7f716edfdf15:	mov    QWORD PTR [r12+0x158],r8
    7f716edfdf1d:	mov    r13d,0x0
    7f716edfdf23:	mov    r8,QWORD PTR [rsp+0x30]
    7f716edfdf28:	and    r8,0xff
    7f716edfdf2f:	and    r8,0xffff
    7f716edfdf36:	mov    r9,r13
    7f716edfdf39:	or     r9,r8
    7f716edfdf3c:	mov    r8,QWORD PTR [rsp+0x30]
    7f716edfdf41:	shr    r8,0x8
    7f716edfdf45:	and    r8,0xff
    7f716edfdf4c:	and    r8,0xffff
    7f716edfdf53:	shl    r8,0x10
    7f716edfdf57:	or     r9,r8
    7f716edfdf5a:	mov    r8,QWORD PTR [rsp+0x30]
    7f716edfdf5f:	shr    r8,0x10
    7f716edfdf63:	and    r8,0xff
    7f716edfdf6a:	and    r8,0xffff
    7f716edfdf71:	shl    r8,0x20
    7f716edfdf75:	or     r9,r8
    7f716edfdf78:	mov    r8,QWORD PTR [rsp+0x30]
    7f716edfdf7d:	shr    r8,0x18
    7f716edfdf81:	and    r8,0xff
    7f716edfdf88:	and    r8,0xffff
    7f716edfdf8f:	shl    r8,0x30
    7f716edfdf93:	mov    rax,r9
    7f716edfdf96:	or     rax,r8
    7f716edfdf99:	mov    QWORD PTR [rsp+0x50],rax
    7f716edfdf9e:	mov    r8,QWORD PTR [rsp+0x30]
    7f716edfdfa3:	shr    r8,0x20
    7f716edfdfa7:	and    r8,0xff
    7f716edfdfae:	and    r8,0xffff
    7f716edfdfb5:	or     r13,r8
    7f716edfdfb8:	mov    r8,QWORD PTR [rsp+0x30]
    7f716edfdfbd:	shr    r8,0x28
    7f716edfdfc1:	and    r8,0xff
    7f716edfdfc8:	and    r8,0xffff
    7f716edfdfcf:	shl    r8,0x10
    7f716edfdfd3:	or     r13,r8
    7f716edfdfd6:	mov    r8,QWORD PTR [rsp+0x30]
    7f716edfdfdb:	shr    r8,0x30
    7f716edfdfdf:	and    r8,0xff
    7f716edfdfe6:	and    r8,0xffff
    7f716edfdfed:	shl    r8,0x20
    7f716edfdff1:	or     r13,r8
    7f716edfdff4:	mov    r8,QWORD PTR [rsp+0x30]
    7f716edfdff9:	shr    r8,0x38
    7f716edfdffd:	and    r8,0xff
    7f716edfe004:	and    r8,0xffff
    7f716edfe00b:	shl    r8,0x30
    7f716edfe00f:	mov    rax,r13
    7f716edfe012:	or     rax,r8
    7f716edfe015:	mov    QWORD PTR [rsp+0x48],rax
    7f716edfe01a:	mov    r8d,0x0
    7f716edfe020:	mov    r13,QWORD PTR [rsp+0x28]
    7f716edfe025:	and    r13,0xff
    7f716edfe02c:	and    r13,0xffff
    7f716edfe033:	mov    r9,r8
    7f716edfe036:	or     r9,r13
    7f716edfe039:	mov    r13,QWORD PTR [rsp+0x28]
    7f716edfe03e:	shr    r13,0x8
    7f716edfe042:	and    r13,0xff
    7f716edfe049:	and    r13,0xffff
    7f716edfe050:	shl    r13,0x10
    7f716edfe054:	or     r9,r13
    7f716edfe057:	mov    r13,QWORD PTR [rsp+0x28]
    7f716edfe05c:	shr    r13,0x10
    7f716edfe060:	and    r13,0xff
    7f716edfe067:	and    r13,0xffff
    7f716edfe06e:	shl    r13,0x20
    7f716edfe072:	or     r9,r13
    7f716edfe075:	mov    r13,QWORD PTR [rsp+0x28]
    7f716edfe07a:	shr    r13,0x18
    7f716edfe07e:	and    r13,0xff
    7f716edfe085:	and    r13,0xffff
    7f716edfe08c:	shl    r13,0x30
    7f716edfe090:	mov    rax,r9
    7f716edfe093:	or     rax,r13
    7f716edfe096:	mov    QWORD PTR [rsp+0x58],rax
    7f716edfe09b:	mov    r13,QWORD PTR [rsp+0x28]
    7f716edfe0a0:	shr    r13,0x20
    7f716edfe0a4:	and    r13,0xff
    7f716edfe0ab:	and    r13,0xffff
    7f716edfe0b2:	or     r8,r13
    7f716edfe0b5:	mov    r13,QWORD PTR [rsp+0x28]
    7f716edfe0ba:	shr    r13,0x28
    7f716edfe0be:	and    r13,0xff
    7f716edfe0c5:	and    r13,0xffff
    7f716edfe0cc:	shl    r13,0x10
    7f716edfe0d0:	or     r8,r13
    7f716edfe0d3:	mov    r13,QWORD PTR [rsp+0x28]
    7f716edfe0d8:	shr    r13,0x30
    7f716edfe0dc:	and    r13,0xff
    7f716edfe0e3:	and    r13,0xffff
    7f716edfe0ea:	shl    r13,0x20
    7f716edfe0ee:	or     r8,r13
    7f716edfe0f1:	mov    r13,QWORD PTR [rsp+0x28]
    7f716edfe0f6:	shr    r13,0x38
    7f716edfe0fa:	and    r13,0xff
    7f716edfe101:	and    r13,0xffff
    7f716edfe108:	shl    r13,0x30
    7f716edfe10c:	mov    rax,r8
    7f716edfe10f:	or     rax,r13
    7f716edfe112:	mov    QWORD PTR [rsp+0x60],rax
    7f716edfe117:	mov    r13d,0x0
    7f716edfe11d:	mov    r9,r14
    7f716edfe120:	and    r9,0xff
    7f716edfe127:	and    r9,0xffff
    7f716edfe12e:	mov    r8,r13
    7f716edfe131:	or     r8,r9
    7f716edfe134:	mov    r9,r14
    7f716edfe137:	shr    r9,0x8
    7f716edfe13b:	and    r9,0xff
    7f716edfe142:	and    r9,0xffff
    7f716edfe149:	shl    r9,0x10
    7f716edfe14d:	or     r8,r9
    7f716edfe150:	mov    r9,r14
    7f716edfe153:	shr    r9,0x10
    7f716edfe157:	and    r9,0xff
    7f716edfe15e:	and    r9,0xffff
    7f716edfe165:	shl    r9,0x20
    7f716edfe169:	or     r8,r9
    7f716edfe16c:	mov    r9,r14
    7f716edfe16f:	shr    r9,0x18
    7f716edfe173:	and    r9,0xff
    7f716edfe17a:	and    r9,0xffff
    7f716edfe181:	shl    r9,0x30
    7f716edfe185:	mov    rax,r8
    7f716edfe188:	or     rax,r9
    7f716edfe18b:	mov    QWORD PTR [rsp+0x68],rax
    7f716edfe190:	mov    r9,r14
    7f716edfe193:	shr    r9,0x20
    7f716edfe197:	and    r9,0xff
    7f716edfe19e:	and    r9,0xffff
    7f716edfe1a5:	or     r13,r9
    7f716edfe1a8:	mov    r9,r14
    7f716edfe1ab:	shr    r9,0x28
    7f716edfe1af:	and    r9,0xff
    7f716edfe1b6:	and    r9,0xffff
    7f716edfe1bd:	shl    r9,0x10
    7f716edfe1c1:	or     r13,r9
    7f716edfe1c4:	mov    r9,r14
    7f716edfe1c7:	shr    r9,0x30
    7f716edfe1cb:	and    r9,0xff
    7f716edfe1d2:	and    r9,0xffff
    7f716edfe1d9:	shl    r9,0x20
    7f716edfe1dd:	or     r13,r9
    7f716edfe1e0:	shr    r14,0x38
    7f716edfe1e4:	and    r14,0xff
    7f716edfe1eb:	and    r14,0xffff
    7f716edfe1f2:	shl    r14,0x30
    7f716edfe1f6:	or     r13,r14
    7f716edfe1f9:	mov    r14d,0x0
    7f716edfe1ff:	mov    r9,r15
    7f716edfe202:	and    r9,0xff
    7f716edfe209:	and    r9,0xffff
    7f716edfe210:	mov    r8,r14
    7f716edfe213:	or     r8,r9
    7f716edfe216:	mov    r9,r15
    7f716edfe219:	shr    r9,0x8
    7f716edfe21d:	and    r9,0xff
    7f716edfe224:	and    r9,0xffff
    7f716edfe22b:	shl    r9,0x10
    7f716edfe22f:	or     r8,r9
    7f716edfe232:	mov    r9,r15
    7f716edfe235:	shr    r9,0x10
    7f716edfe239:	and    r9,0xff
    7f716edfe240:	and    r9,0xffff
    7f716edfe247:	shl    r9,0x20
    7f716edfe24b:	or     r8,r9
    7f716edfe24e:	mov    r9,r15
    7f716edfe251:	shr    r9,0x18
    7f716edfe255:	and    r9,0xff
    7f716edfe25c:	and    r9,0xffff
    7f716edfe263:	shl    r9,0x30
    7f716edfe267:	or     r8,r9
    7f716edfe26a:	mov    r9,r15
    7f716edfe26d:	shr    r9,0x20
    7f716edfe271:	and    r9,0xff
    7f716edfe278:	and    r9,0xffff
    7f716edfe27f:	or     r14,r9
    7f716edfe282:	mov    r9,r15
    7f716edfe285:	shr    r9,0x28
    7f716edfe289:	and    r9,0xff
    7f716edfe290:	and    r9,0xffff
    7f716edfe297:	shl    r9,0x10
    7f716edfe29b:	or     r14,r9
    7f716edfe29e:	mov    r9,r15
    7f716edfe2a1:	shr    r9,0x30
    7f716edfe2a5:	and    r9,0xff
    7f716edfe2ac:	and    r9,0xffff
    7f716edfe2b3:	shl    r9,0x20
    7f716edfe2b7:	or     r14,r9
    7f716edfe2ba:	shr    r15,0x38
    7f716edfe2be:	and    r15,0xff
    7f716edfe2c5:	and    r15,0xffff
    7f716edfe2cc:	shl    r15,0x30
    7f716edfe2d0:	or     r14,r15
    7f716edfe2d3:	mov    QWORD PTR [r12+0x210],r8
    7f716edfe2db:	mov    QWORD PTR [r12+0x218],r14
    7f716edfe2e3:	mov    r14d,0x0
    7f716edfe2e9:	mov    r15,rbp
    7f716edfe2ec:	and    r15,0xff
    7f716edfe2f3:	and    r15,0xffff
    7f716edfe2fa:	mov    r8,r14
    7f716edfe2fd:	or     r8,r15
    7f716edfe300:	mov    r15,rbp
    7f716edfe303:	shr    r15,0x8
    7f716edfe307:	and    r15,0xff
    7f716edfe30e:	and    r15,0xffff
    7f716edfe315:	shl    r15,0x10
    7f716edfe319:	or     r8,r15
    7f716edfe31c:	mov    r15,rbp
    7f716edfe31f:	shr    r15,0x10
    7f716edfe323:	and    r15,0xff
    7f716edfe32a:	and    r15,0xffff
    7f716edfe331:	shl    r15,0x20
    7f716edfe335:	or     r8,r15
    7f716edfe338:	mov    r15,rbp
    7f716edfe33b:	shr    r15,0x18
    7f716edfe33f:	and    r15,0xff
    7f716edfe346:	and    r15,0xffff
    7f716edfe34d:	shl    r15,0x30
    7f716edfe351:	or     r8,r15
    7f716edfe354:	mov    r15,rbp
    7f716edfe357:	shr    r15,0x20
    7f716edfe35b:	and    r15,0xff
    7f716edfe362:	and    r15,0xffff
    7f716edfe369:	or     r14,r15
    7f716edfe36c:	mov    r15,rbp
    7f716edfe36f:	shr    r15,0x28
    7f716edfe373:	and    r15,0xff
    7f716edfe37a:	and    r15,0xffff
    7f716edfe381:	shl    r15,0x10
    7f716edfe385:	or     r14,r15
    7f716edfe388:	mov    r15,rbp
    7f716edfe38b:	shr    r15,0x30
    7f716edfe38f:	and    r15,0xff
    7f716edfe396:	and    r15,0xffff
    7f716edfe39d:	shl    r15,0x20
    7f716edfe3a1:	or     r14,r15
    7f716edfe3a4:	shr    rbp,0x38
    7f716edfe3a8:	and    rbp,0xff
    7f716edfe3af:	and    rbp,0xffff
    7f716edfe3b6:	shl    rbp,0x30
    7f716edfe3ba:	or     r14,rbp
    7f716edfe3bd:	mov    r15d,0x0
    7f716edfe3c3:	mov    rbp,QWORD PTR [rsp+0x20]
    7f716edfe3c8:	and    rbp,0xff
    7f716edfe3cf:	and    rbp,0xffff
    7f716edfe3d6:	mov    r9,r15
    7f716edfe3d9:	or     r9,rbp
    7f716edfe3dc:	mov    rbp,QWORD PTR [rsp+0x20]
    7f716edfe3e1:	shr    rbp,0x8
    7f716edfe3e5:	and    rbp,0xff
    7f716edfe3ec:	and    rbp,0xffff
    7f716edfe3f3:	shl    rbp,0x10
    7f716edfe3f7:	or     r9,rbp
    7f716edfe3fa:	mov    rbp,QWORD PTR [rsp+0x20]
    7f716edfe3ff:	shr    rbp,0x10
    7f716edfe403:	and    rbp,0xff
    7f716edfe40a:	and    rbp,0xffff
    7f716edfe411:	shl    rbp,0x20
    7f716edfe415:	or     r9,rbp
    7f716edfe418:	mov    rbp,QWORD PTR [rsp+0x20]
    7f716edfe41d:	shr    rbp,0x18
    7f716edfe421:	and    rbp,0xff
    7f716edfe428:	and    rbp,0xffff
    7f716edfe42f:	shl    rbp,0x30
    7f716edfe433:	mov    rax,r9
    7f716edfe436:	or     rax,rbp
    7f716edfe439:	mov    QWORD PTR [rsp+0x78],rax
    7f716edfe43e:	mov    rbp,QWORD PTR [rsp+0x20]
    7f716edfe443:	shr    rbp,0x20
    7f716edfe447:	and    rbp,0xff
    7f716edfe44e:	and    rbp,0xffff
    7f716edfe455:	or     r15,rbp
    7f716edfe458:	mov    rbp,QWORD PTR [rsp+0x20]
    7f716edfe45d:	shr    rbp,0x28
    7f716edfe461:	and    rbp,0xff
    7f716edfe468:	and    rbp,0xffff
    7f716edfe46f:	shl    rbp,0x10
    7f716edfe473:	or     r15,rbp
    7f716edfe476:	mov    rbp,QWORD PTR [rsp+0x20]
    7f716edfe47b:	shr    rbp,0x30
    7f716edfe47f:	and    rbp,0xff
    7f716edfe486:	and    rbp,0xffff
    7f716edfe48d:	shl    rbp,0x20
    7f716edfe491:	or     r15,rbp
    7f716edfe494:	mov    rbp,QWORD PTR [rsp+0x20]
    7f716edfe499:	shr    rbp,0x38
    7f716edfe49d:	and    rbp,0xff
    7f716edfe4a4:	and    rbp,0xffff
    7f716edfe4ab:	shl    rbp,0x30
    7f716edfe4af:	mov    rax,r15
    7f716edfe4b2:	or     rax,rbp
    7f716edfe4b5:	mov    QWORD PTR [rsp+0x70],rax
    7f716edfe4ba:	mov    rax,QWORD PTR [rsp+0x78]
    7f716edfe4bf:	mov    QWORD PTR [r12+0x250],rax
    7f716edfe4c7:	mov    rax,QWORD PTR [rsp+0x70]
    7f716edfe4cc:	mov    QWORD PTR [r12+0x258],rax
    7f716edfe4d4:	mov    ebp,0x0
    7f716edfe4d9:	mov    r15,QWORD PTR [rsp+0x40]
    7f716edfe4de:	and    r15,0xff
    7f716edfe4e5:	and    r15,0xffff
    7f716edfe4ec:	mov    r9,rbp
    7f716edfe4ef:	or     r9,r15
    7f716edfe4f2:	mov    r15,QWORD PTR [rsp+0x40]
    7f716edfe4f7:	shr    r15,0x8
    7f716edfe4fb:	and    r15,0xff
    7f716edfe502:	and    r15,0xffff
    7f716edfe509:	shl    r15,0x10
    7f716edfe50d:	or     r9,r15
    7f716edfe510:	mov    r15,QWORD PTR [rsp+0x40]
    7f716edfe515:	shr    r15,0x10
    7f716edfe519:	and    r15,0xff
    7f716edfe520:	and    r15,0xffff
    7f716edfe527:	shl    r15,0x20
    7f716edfe52b:	or     r9,r15
    7f716edfe52e:	mov    r15,QWORD PTR [rsp+0x40]
    7f716edfe533:	shr    r15,0x18
    7f716edfe537:	and    r15,0xff
    7f716edfe53e:	and    r15,0xffff
    7f716edfe545:	shl    r15,0x30
    7f716edfe549:	mov    rax,r9
    7f716edfe54c:	or     rax,r15
    7f716edfe54f:	mov    QWORD PTR [rsp+0x80],rax
    7f716edfe557:	mov    r15,QWORD PTR [rsp+0x40]
    7f716edfe55c:	shr    r15,0x20
    7f716edfe560:	and    r15,0xff
    7f716edfe567:	and    r15,0xffff
    7f716edfe56e:	or     rbp,r15
    7f716edfe571:	mov    r15,QWORD PTR [rsp+0x40]
    7f716edfe576:	shr    r15,0x28
    7f716edfe57a:	and    r15,0xff
    7f716edfe581:	and    r15,0xffff
    7f716edfe588:	shl    r15,0x10
    7f716edfe58c:	or     rbp,r15
    7f716edfe58f:	mov    r15,QWORD PTR [rsp+0x40]
    7f716edfe594:	shr    r15,0x30
    7f716edfe598:	and    r15,0xff
    7f716edfe59f:	and    r15,0xffff
    7f716edfe5a6:	shl    r15,0x20
    7f716edfe5aa:	or     rbp,r15
    7f716edfe5ad:	mov    r15,QWORD PTR [rsp+0x40]
    7f716edfe5b2:	shr    r15,0x38
    7f716edfe5b6:	and    r15,0xff
    7f716edfe5bd:	and    r15,0xffff
    7f716edfe5c4:	shl    r15,0x30
    7f716edfe5c8:	mov    rax,rbp
    7f716edfe5cb:	or     rax,r15
    7f716edfe5ce:	mov    QWORD PTR [rsp+0x88],rax
    7f716edfe5d6:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    7f716edfe5e0:	pxor   xmm0,xmm0
    7f716edfe5e4:	movdqa xmm3,xmm0
    7f716edfe5e8:	movdqa xmm0,xmm2
    7f716edfe5ec:	movdqa xmm1,xmm3
    7f716edfe5f0:	punpcklwd xmm0,xmm1
    7f716edfe5f4:	movdqa xmm4,xmm0
    7f716edfe5f8:	movdqa xmm0,xmm4
    7f716edfe5fc:	pslld  xmm0,0x10
    7f716edfe601:	movdqa xmm3,xmm0
    7f716edfe605:	mov    r15d,0x0
    7f716edfe60b:	mov    r9,QWORD PTR [rsp+0x50]
    7f716edfe610:	and    r9,0xffff
    7f716edfe617:	shl    r9,0x8
    7f716edfe61b:	mov    ecx,0xffffffff
    7f716edfe620:	and    r9,rcx
    7f716edfe623:	mov    rbp,r15
    7f716edfe626:	or     rbp,r9
    7f716edfe629:	mov    r9,QWORD PTR [rsp+0x50]
    7f716edfe62e:	shr    r9,0x10
    7f716edfe632:	and    r9,0xffff
    7f716edfe639:	shl    r9,0x8
    7f716edfe63d:	mov    ecx,0xffffffff
    7f716edfe642:	and    r9,rcx
    7f716edfe645:	shl    r9,0x20
    7f716edfe649:	or     rbp,r9
    7f716edfe64c:	mov    r9,QWORD PTR [rsp+0x50]
    7f716edfe651:	shr    r9,0x20
    7f716edfe655:	and    r9,0xffff
    7f716edfe65c:	shl    r9,0x8
    7f716edfe660:	mov    ecx,0xffffffff
    7f716edfe665:	and    r9,rcx
    7f716edfe668:	or     r15,r9
    7f716edfe66b:	mov    r9,QWORD PTR [rsp+0x50]
    7f716edfe670:	shr    r9,0x30
    7f716edfe674:	and    r9,0xffff
    7f716edfe67b:	shl    r9,0x8
    7f716edfe67f:	mov    ecx,0xffffffff
    7f716edfe684:	and    r9,rcx
    7f716edfe687:	shl    r9,0x20
    7f716edfe68b:	or     r15,r9
    7f716edfe68e:	mov    QWORD PTR [r12+0x240],rbp
    7f716edfe696:	mov    QWORD PTR [r12+0x248],r15
    7f716edfe69e:	mov    r15d,0x0
    7f716edfe6a4:	mov    rbp,QWORD PTR [rsp+0x60]
    7f716edfe6a9:	and    rbp,0xffff
    7f716edfe6b0:	mov    ecx,0xffffffff
    7f716edfe6b5:	and    rbp,rcx
    7f716edfe6b8:	mov    r9,r15
    7f716edfe6bb:	or     r9,rbp
    7f716edfe6be:	mov    rbp,QWORD PTR [rsp+0x60]
    7f716edfe6c3:	shr    rbp,0x10
    7f716edfe6c7:	and    rbp,0xffff
    7f716edfe6ce:	mov    ecx,0xffffffff
    7f716edfe6d3:	and    rbp,rcx
    7f716edfe6d6:	shl    rbp,0x20
    7f716edfe6da:	or     r9,rbp
    7f716edfe6dd:	mov    rbp,QWORD PTR [rsp+0x60]
    7f716edfe6e2:	shr    rbp,0x20
    7f716edfe6e6:	and    rbp,0xffff
    7f716edfe6ed:	mov    ecx,0xffffffff
    7f716edfe6f2:	and    rbp,rcx
    7f716edfe6f5:	or     r15,rbp
    7f716edfe6f8:	mov    rbp,QWORD PTR [rsp+0x60]
    7f716edfe6fd:	shr    rbp,0x30
    7f716edfe701:	and    rbp,0xffff
    7f716edfe708:	mov    ecx,0xffffffff
    7f716edfe70d:	and    rbp,rcx
    7f716edfe710:	shl    rbp,0x20
    7f716edfe714:	or     r15,rbp
    7f716edfe717:	mov    QWORD PTR [r12+0x260],r9
    7f716edfe71f:	mov    QWORD PTR [r12+0x268],r15
    7f716edfe727:	mov    r15d,0x0
    7f716edfe72d:	mov    rbp,r13
    7f716edfe730:	and    rbp,0xffff
    7f716edfe737:	mov    ecx,0xffffffff
    7f716edfe73c:	and    rbp,rcx
    7f716edfe73f:	mov    r9,r15
    7f716edfe742:	or     r9,rbp
    7f716edfe745:	mov    rbp,r13
    7f716edfe748:	shr    rbp,0x10
    7f716edfe74c:	and    rbp,0xffff
    7f716edfe753:	mov    ecx,0xffffffff
    7f716edfe758:	and    rbp,rcx
    7f716edfe75b:	shl    rbp,0x20
    7f716edfe75f:	or     r9,rbp
    7f716edfe762:	mov    rbp,r13
    7f716edfe765:	shr    rbp,0x20
    7f716edfe769:	and    rbp,0xffff
    7f716edfe770:	mov    ecx,0xffffffff
    7f716edfe775:	and    rbp,rcx
    7f716edfe778:	or     r15,rbp
    7f716edfe77b:	shr    r13,0x30
    7f716edfe77f:	and    r13,0xffff
    7f716edfe786:	mov    ecx,0xffffffff
    7f716edfe78b:	and    r13,rcx
    7f716edfe78e:	shl    r13,0x20
    7f716edfe792:	or     r15,r13
    7f716edfe795:	mov    QWORD PTR [r12+0x270],r9
    7f716edfe79d:	mov    QWORD PTR [r12+0x278],r15
    7f716edfe7a5:	mov    r13d,0x0
    7f716edfe7ab:	mov    r15,QWORD PTR [rsp+0x58]
    7f716edfe7b0:	and    r15,0xffff
    7f716edfe7b7:	mov    ecx,0xffffffff
    7f716edfe7bc:	and    r15,rcx
    7f716edfe7bf:	mov    rbp,r13
    7f716edfe7c2:	or     rbp,r15
    7f716edfe7c5:	mov    r15,QWORD PTR [rsp+0x58]
    7f716edfe7ca:	shr    r15,0x10
    7f716edfe7ce:	and    r15,0xffff
    7f716edfe7d5:	mov    ecx,0xffffffff
    7f716edfe7da:	and    r15,rcx
    7f716edfe7dd:	shl    r15,0x20
    7f716edfe7e1:	or     rbp,r15
    7f716edfe7e4:	mov    r15,QWORD PTR [rsp+0x58]
    7f716edfe7e9:	shr    r15,0x20
    7f716edfe7ed:	and    r15,0xffff
    7f716edfe7f4:	mov    ecx,0xffffffff
    7f716edfe7f9:	and    r15,rcx
    7f716edfe7fc:	or     r13,r15
    7f716edfe7ff:	mov    r15,QWORD PTR [rsp+0x58]
    7f716edfe804:	shr    r15,0x30
    7f716edfe808:	and    r15,0xffff
    7f716edfe80f:	mov    ecx,0xffffffff
    7f716edfe814:	and    r15,rcx
    7f716edfe817:	shl    r15,0x20
    7f716edfe81b:	or     r13,r15
    7f716edfe81e:	mov    QWORD PTR [r12+0x170],rbp
    7f716edfe826:	mov    QWORD PTR [r12+0x178],r13
    7f716edfe82e:	movdqu xmm4,XMMWORD PTR [r12+0x210]
    7f716edfe838:	pxor   xmm0,xmm0
    7f716edfe83c:	movdqa xmm5,xmm0
    7f716edfe840:	movdqa xmm0,xmm4
    7f716edfe844:	movdqa xmm1,xmm5
    7f716edfe848:	punpckhwd xmm0,xmm1
    7f716edfe84c:	movdqa xmm6,xmm0
    7f716edfe850:	movdqa xmm0,xmm6
    7f716edfe854:	pslld  xmm0,0x10
    7f716edfe859:	movdqa xmm5,xmm0
    7f716edfe85d:	movdqu XMMWORD PTR [r12+0x280],xmm5
    7f716edfe867:	mov    r13d,0x0
    7f716edfe86d:	mov    r15,QWORD PTR [rsp+0x68]
    7f716edfe872:	and    r15,0xffff
    7f716edfe879:	mov    ecx,0xffffffff
    7f716edfe87e:	and    r15,rcx
    7f716edfe881:	mov    rbp,r13
    7f716edfe884:	or     rbp,r15
    7f716edfe887:	mov    r15,QWORD PTR [rsp+0x68]
    7f716edfe88c:	shr    r15,0x10
    7f716edfe890:	and    r15,0xffff
    7f716edfe897:	mov    ecx,0xffffffff
    7f716edfe89c:	and    r15,rcx
    7f716edfe89f:	shl    r15,0x20
    7f716edfe8a3:	or     rbp,r15
    7f716edfe8a6:	mov    r15,QWORD PTR [rsp+0x68]
    7f716edfe8ab:	shr    r15,0x20
    7f716edfe8af:	and    r15,0xffff
    7f716edfe8b6:	mov    ecx,0xffffffff
    7f716edfe8bb:	and    r15,rcx
    7f716edfe8be:	or     r13,r15
    7f716edfe8c1:	mov    r15,QWORD PTR [rsp+0x68]
    7f716edfe8c6:	shr    r15,0x30
    7f716edfe8ca:	and    r15,0xffff
    7f716edfe8d1:	mov    ecx,0xffffffff
    7f716edfe8d6:	and    r15,rcx
    7f716edfe8d9:	shl    r15,0x20
    7f716edfe8dd:	or     r13,r15
    7f716edfe8e0:	mov    QWORD PTR [r12+0x180],rbp
    7f716edfe8e8:	mov    QWORD PTR [r12+0x188],r13
    7f716edfe8f0:	pxor   xmm0,xmm0
    7f716edfe8f4:	movdqa xmm6,xmm0
    7f716edfe8f8:	movdqa xmm0,xmm4
    7f716edfe8fc:	movdqa xmm1,xmm6
    7f716edfe900:	punpcklwd xmm0,xmm1
    7f716edfe904:	movdqa xmm7,xmm0
    7f716edfe908:	movdqa xmm0,xmm7
    7f716edfe90c:	pslld  xmm0,0x10
    7f716edfe911:	movdqa xmm4,xmm0
    7f716edfe915:	pxor   xmm0,xmm0
    7f716edfe919:	movdqa xmm6,xmm0
    7f716edfe91d:	movdqa xmm0,xmm2
    7f716edfe921:	movdqa xmm1,xmm6
    7f716edfe925:	punpckhwd xmm0,xmm1
    7f716edfe929:	movdqa xmm7,xmm0
    7f716edfe92d:	movdqa xmm0,xmm7
    7f716edfe931:	pslld  xmm0,0x10
    7f716edfe936:	movdqa xmm2,xmm0
    7f716edfe93a:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    7f716edfe944:	movdqa xmm1,xmm6
    7f716edfe948:	por    xmm3,xmm1
    7f716edfe94c:	movdqu XMMWORD PTR [r12+0x230],xmm3
    7f716edfe956:	mov    r13d,0x0
    7f716edfe95c:	mov    r15,r14
    7f716edfe95f:	and    r15,0xffff
    7f716edfe966:	shl    r15,0x8
    7f716edfe96a:	mov    ecx,0xffffffff
    7f716edfe96f:	and    r15,rcx
    7f716edfe972:	mov    rbp,r13
    7f716edfe975:	or     rbp,r15
    7f716edfe978:	mov    r15,r14
    7f716edfe97b:	shr    r15,0x10
    7f716edfe97f:	and    r15,0xffff
    7f716edfe986:	shl    r15,0x8
    7f716edfe98a:	mov    ecx,0xffffffff
    7f716edfe98f:	and    r15,rcx
    7f716edfe992:	shl    r15,0x20
    7f716edfe996:	or     rbp,r15
    7f716edfe999:	mov    r15,r14
    7f716edfe99c:	shr    r15,0x20
    7f716edfe9a0:	and    r15,0xffff
    7f716edfe9a7:	shl    r15,0x8
    7f716edfe9ab:	mov    ecx,0xffffffff
    7f716edfe9b0:	and    r15,rcx
    7f716edfe9b3:	or     r13,r15
    7f716edfe9b6:	shr    r14,0x30
    7f716edfe9ba:	and    r14,0xffff
    7f716edfe9c1:	shl    r14,0x8
    7f716edfe9c5:	mov    ecx,0xffffffff
    7f716edfe9ca:	and    r14,rcx
    7f716edfe9cd:	shl    r14,0x20
    7f716edfe9d1:	or     r13,r14
    7f716edfe9d4:	mov    QWORD PTR [r12+0x240],rbp
    7f716edfe9dc:	mov    QWORD PTR [r12+0x248],r13
    7f716edfe9e4:	mov    r13d,0x0
    7f716edfe9ea:	mov    r14,r8
    7f716edfe9ed:	and    r14,0xffff
    7f716edfe9f4:	shl    r14,0x8
    7f716edfe9f8:	mov    ecx,0xffffffff
    7f716edfe9fd:	and    r14,rcx
    7f716edfea00:	mov    r15,r13
    7f716edfea03:	or     r15,r14
    7f716edfea06:	mov    r14,r8
    7f716edfea09:	shr    r14,0x10
    7f716edfea0d:	and    r14,0xffff
    7f716edfea14:	shl    r14,0x8
    7f716edfea18:	mov    ecx,0xffffffff
    7f716edfea1d:	and    r14,rcx
    7f716edfea20:	shl    r14,0x20
    7f716edfea24:	or     r15,r14
    7f716edfea27:	mov    r14,r8
    7f716edfea2a:	shr    r14,0x20
    7f716edfea2e:	and    r14,0xffff
    7f716edfea35:	shl    r14,0x8
    7f716edfea39:	mov    ecx,0xffffffff
    7f716edfea3e:	and    r14,rcx
    7f716edfea41:	or     r13,r14
    7f716edfea44:	shr    r8,0x30
    7f716edfea48:	and    r8,0xffff
    7f716edfea4f:	shl    r8,0x8
    7f716edfea53:	mov    ecx,0xffffffff
    7f716edfea58:	and    r8,rcx
    7f716edfea5b:	shl    r8,0x20
    7f716edfea5f:	or     r13,r8
    7f716edfea62:	mov    QWORD PTR [r12+0x220],r15
    7f716edfea6a:	mov    QWORD PTR [r12+0x228],r13
    7f716edfea72:	mov    r13d,0x0
    7f716edfea78:	mov    r14,QWORD PTR [rsp+0x48]
    7f716edfea7d:	and    r14,0xffff
    7f716edfea84:	shl    r14,0x8
    7f716edfea88:	mov    ecx,0xffffffff
    7f716edfea8d:	and    r14,rcx
    7f716edfea90:	mov    r15,r13
    7f716edfea93:	or     r15,r14
    7f716edfea96:	mov    r14,QWORD PTR [rsp+0x48]
    7f716edfea9b:	shr    r14,0x10
    7f716edfea9f:	and    r14,0xffff
    7f716edfeaa6:	shl    r14,0x8
    7f716edfeaaa:	mov    ecx,0xffffffff
    7f716edfeaaf:	and    r14,rcx
    7f716edfeab2:	shl    r14,0x20
    7f716edfeab6:	or     r15,r14
    7f716edfeab9:	mov    r14,QWORD PTR [rsp+0x48]
    7f716edfeabe:	shr    r14,0x20
    7f716edfeac2:	and    r14,0xffff
    7f716edfeac9:	shl    r14,0x8
    7f716edfeacd:	mov    ecx,0xffffffff
    7f716edfead2:	and    r14,rcx
    7f716edfead5:	or     r13,r14
    7f716edfead8:	mov    r14,QWORD PTR [rsp+0x48]
    7f716edfeadd:	shr    r14,0x30
    7f716edfeae1:	and    r14,0xffff
    7f716edfeae8:	shl    r14,0x8
    7f716edfeaec:	mov    ecx,0xffffffff
    7f716edfeaf1:	and    r14,rcx
    7f716edfeaf4:	shl    r14,0x20
    7f716edfeaf8:	or     r13,r14
    7f716edfeafb:	mov    QWORD PTR [r12+0x160],r15
    7f716edfeb03:	mov    QWORD PTR [r12+0x168],r13
    7f716edfeb0b:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    7f716edfeb15:	movdqa xmm0,xmm6
    7f716edfeb19:	pslld  xmm0,0x18
    7f716edfeb1e:	movdqa xmm7,xmm0
    7f716edfeb22:	movdqu XMMWORD PTR [r12+0x170],xmm7
    7f716edfeb2c:	movdqu xmm6,XMMWORD PTR [r12+0x270]
    7f716edfeb36:	movdqa xmm0,xmm6
    7f716edfeb3a:	pslld  xmm0,0x18
    7f716edfeb3f:	movdqa xmm8,xmm0
    7f716edfeb44:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    7f716edfeb4e:	movdqa xmm0,xmm6
    7f716edfeb52:	pslld  xmm0,0x18
    7f716edfeb57:	movdqa xmm9,xmm0
    7f716edfeb5c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    7f716edfeb66:	mov    r13d,0x0
    7f716edfeb6c:	mov    r14,QWORD PTR [rsp+0x78]
    7f716edfeb71:	and    r14,0xffff
    7f716edfeb78:	mov    ecx,0xffffffff
    7f716edfeb7d:	and    r14,rcx
    7f716edfeb80:	mov    r15,r13
    7f716edfeb83:	or     r15,r14
    7f716edfeb86:	mov    r14,QWORD PTR [rsp+0x78]
    7f716edfeb8b:	shr    r14,0x10
    7f716edfeb8f:	and    r14,0xffff
    7f716edfeb96:	mov    ecx,0xffffffff
    7f716edfeb9b:	and    r14,rcx
    7f716edfeb9e:	shl    r14,0x20
    7f716edfeba2:	or     r15,r14
    7f716edfeba5:	mov    r14,QWORD PTR [rsp+0x78]
    7f716edfebaa:	shr    r14,0x20
    7f716edfebae:	and    r14,0xffff
    7f716edfebb5:	mov    ecx,0xffffffff
    7f716edfebba:	and    r14,rcx
    7f716edfebbd:	or     r13,r14
    7f716edfebc0:	mov    r14,QWORD PTR [rsp+0x78]
    7f716edfebc5:	shr    r14,0x30
    7f716edfebc9:	and    r14,0xffff
    7f716edfebd0:	mov    ecx,0xffffffff
    7f716edfebd5:	and    r14,rcx
    7f716edfebd8:	shl    r14,0x20
    7f716edfebdc:	or     r13,r14
    7f716edfebdf:	mov    QWORD PTR [r12+0x140],r15
    7f716edfebe7:	mov    QWORD PTR [r12+0x148],r13
    7f716edfebef:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    7f716edfebf9:	movdqa xmm1,xmm6
    7f716edfebfd:	por    xmm5,xmm1
    7f716edfec01:	movdqu xmm6,XMMWORD PTR [r12+0x220]
    7f716edfec0b:	movdqa xmm1,xmm6
    7f716edfec0f:	por    xmm4,xmm1
    7f716edfec13:	movdqu XMMWORD PTR [r12+0x210],xmm4
    7f716edfec1d:	movdqu xmm6,XMMWORD PTR [r12+0x260]
    7f716edfec27:	movdqa xmm0,xmm6
    7f716edfec2b:	pslld  xmm0,0x18
    7f716edfec30:	movdqa xmm10,xmm0
    7f716edfec35:	movdqu XMMWORD PTR [r12+0x220],xmm10
    7f716edfec3f:	movdqu xmm6,XMMWORD PTR [r12+0x160]
    7f716edfec49:	movdqa xmm1,xmm6
    7f716edfec4d:	por    xmm2,xmm1
    7f716edfec51:	movdqa xmm1,xmm7
    7f716edfec55:	por    xmm3,xmm1
    7f716edfec59:	movdqu XMMWORD PTR [r12+0x160],xmm3
    7f716edfec63:	mov    r13d,0x0
    7f716edfec69:	mov    r14,QWORD PTR [rsp+0x88]
    7f716edfec71:	and    r14,0xffff
    7f716edfec78:	mov    ecx,0xffffffff
    7f716edfec7d:	and    r14,rcx
    7f716edfec80:	mov    r15,r13
    7f716edfec83:	or     r15,r14
    7f716edfec86:	mov    r14,QWORD PTR [rsp+0x88]
    7f716edfec8e:	shr    r14,0x10
    7f716edfec92:	and    r14,0xffff
    7f716edfec99:	mov    ecx,0xffffffff
    7f716edfec9e:	and    r14,rcx
    7f716edfeca1:	shl    r14,0x20
    7f716edfeca5:	or     r15,r14
    7f716edfeca8:	mov    r14,QWORD PTR [rsp+0x88]
    7f716edfecb0:	shr    r14,0x20
    7f716edfecb4:	and    r14,0xffff
    7f716edfecbb:	mov    ecx,0xffffffff
    7f716edfecc0:	and    r14,rcx
    7f716edfecc3:	or     r13,r14
    7f716edfecc6:	mov    r14,QWORD PTR [rsp+0x88]
    7f716edfecce:	shr    r14,0x30
    7f716edfecd2:	and    r14,0xffff
    7f716edfecd9:	mov    ecx,0xffffffff
    7f716edfecde:	and    r14,rcx
    7f716edfece1:	shl    r14,0x20
    7f716edfece5:	or     r13,r14
    7f716edfece8:	mov    QWORD PTR [r12+0x170],r15
    7f716edfecf0:	mov    QWORD PTR [r12+0x178],r13
    7f716edfecf8:	mov    r13d,0x0
    7f716edfecfe:	mov    r14,QWORD PTR [rsp+0x80]
    7f716edfed06:	and    r14,0xffff
    7f716edfed0d:	mov    ecx,0xffffffff
    7f716edfed12:	and    r14,rcx
    7f716edfed15:	mov    r15,r13
    7f716edfed18:	or     r15,r14
    7f716edfed1b:	mov    r14,QWORD PTR [rsp+0x80]
    7f716edfed23:	shr    r14,0x10
    7f716edfed27:	and    r14,0xffff
    7f716edfed2e:	mov    ecx,0xffffffff
    7f716edfed33:	and    r14,rcx
    7f716edfed36:	shl    r14,0x20
    7f716edfed3a:	or     r15,r14
    7f716edfed3d:	mov    r14,QWORD PTR [rsp+0x80]
    7f716edfed45:	shr    r14,0x20
    7f716edfed49:	and    r14,0xffff
    7f716edfed50:	mov    ecx,0xffffffff
    7f716edfed55:	and    r14,rcx
    7f716edfed58:	or     r13,r14
    7f716edfed5b:	mov    r14,QWORD PTR [rsp+0x80]
    7f716edfed63:	shr    r14,0x30
    7f716edfed67:	and    r14,0xffff
    7f716edfed6e:	mov    ecx,0xffffffff
    7f716edfed73:	and    r14,rcx
    7f716edfed76:	shl    r14,0x20
    7f716edfed7a:	or     r13,r14
    7f716edfed7d:	mov    QWORD PTR [r12+0x110],r15
    7f716edfed85:	mov    QWORD PTR [r12+0x118],r13
    7f716edfed8d:	movdqa xmm1,xmm8
    7f716edfed92:	por    xmm5,xmm1
    7f716edfed96:	movdqa xmm1,xmm9
    7f716edfed9b:	por    xmm4,xmm1
    7f716edfed9f:	mov    r13d,0x0
    7f716edfeda5:	mov    r14,QWORD PTR [rsp+0x70]
    7f716edfedaa:	and    r14,0xffff
    7f716edfedb1:	mov    ecx,0xffffffff
    7f716edfedb6:	and    r14,rcx
    7f716edfedb9:	mov    r15,r13
    7f716edfedbc:	or     r15,r14
    7f716edfedbf:	mov    r14,QWORD PTR [rsp+0x70]
    7f716edfedc4:	shr    r14,0x10
    7f716edfedc8:	and    r14,0xffff
    7f716edfedcf:	mov    ecx,0xffffffff
    7f716edfedd4:	and    r14,rcx
    7f716edfedd7:	shl    r14,0x20
    7f716edfeddb:	or     r15,r14
    7f716edfedde:	mov    r14,QWORD PTR [rsp+0x70]
    7f716edfede3:	shr    r14,0x20
    7f716edfede7:	and    r14,0xffff
    7f716edfedee:	mov    ecx,0xffffffff
    7f716edfedf3:	and    r14,rcx
    7f716edfedf6:	or     r13,r14
    7f716edfedf9:	mov    r14,QWORD PTR [rsp+0x70]
    7f716edfedfe:	shr    r14,0x30
    7f716edfee02:	and    r14,0xffff
    7f716edfee09:	mov    ecx,0xffffffff
    7f716edfee0e:	and    r14,rcx
    7f716edfee11:	shl    r14,0x20
    7f716edfee15:	or     r13,r14
    7f716edfee18:	mov    QWORD PTR [r12+0x180],r15
    7f716edfee20:	mov    QWORD PTR [r12+0x188],r13
    7f716edfee28:	movdqa xmm1,xmm10
    7f716edfee2d:	por    xmm2,xmm1
    7f716edfee31:	movdqu XMMWORD PTR [r12+0x150],xmm2
    7f716edfee3b:	movdqu xmm6,XMMWORD PTR [r12+0x140]
    7f716edfee45:	movdqa xmm1,xmm6
    7f716edfee49:	por    xmm3,xmm1
    7f716edfee4d:	movdqu XMMWORD PTR [r12+0x140],xmm3
    7f716edfee57:	movdqu xmm6,XMMWORD PTR [r12+0x110]
    7f716edfee61:	movdqa xmm1,xmm6
    7f716edfee65:	por    xmm4,xmm1
    7f716edfee69:	movdqu XMMWORD PTR [r12+0x110],xmm4
    7f716edfee73:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    7f716edfee7d:	movdqa xmm1,xmm6
    7f716edfee81:	por    xmm5,xmm1
    7f716edfee85:	movdqu XMMWORD PTR [r12+0x120],xmm5
    7f716edfee8f:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    7f716edfee99:	movdqa xmm1,xmm6
    7f716edfee9d:	por    xmm2,xmm1
    7f716edfeea1:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7f716edfeeab:	mov    r13,QWORD PTR [r12+0xf8]
    7f716edfeeb3:	mov    r14,r13
    7f716edfeeb6:	add    r14,0x20
    7f716edfeeba:	mov    r15,r14
    7f716edfeebd:	add    r15,0x10
    7f716edfeec1:	movdqu XMMWORD PTR [r14],xmm4
    7f716edfeec6:	mov    r14d,0x0
    7f716edfeecc:	mov    DWORD PTR [r12+0x32c],r14d
    7f716edfeed4:	movdqu XMMWORD PTR [r15],xmm5
    7f716edfeed9:	mov    r14,r13
    7f716edfeedc:	add    r14,0x10
    7f716edfeee0:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7f716edfeee6:	movdqu XMMWORD PTR [r14],xmm2
    7f716edfeeeb:	mov    r14d,DWORD PTR [r13+0x0]
    7f716edfeeef:	mov    QWORD PTR [r12+0x60],r14
    7f716edfeef4:	jmp    0x7f716edfeef9
    7f716edfeef9:	mov    r13,QWORD PTR [r12+0x58]
    7f716edfeefe:	mov    r14,QWORD PTR [r12+0x48]
    7f716edfef03:	add    r14,r13
    7f716edfef06:	mov    QWORD PTR [r12+0x68],r14
    7f716edfef0b:	add    r13,0x4
    7f716edfef0f:	mov    QWORD PTR [r12+0x58],r13
    7f716edfef14:	mov    r15,r14
    7f716edfef17:	add    r15,0x4
    7f716edfef1b:	mov    eax,DWORD PTR [r15]
    7f716edfef1e:	mov    QWORD PTR [r12+0x70],rax
    7f716edfef23:	mov    r15,r14
    7f716edfef26:	add    r15,0x38
    7f716edfef2a:	mov    r8d,DWORD PTR [r15]
    7f716edfef2d:	mov    QWORD PTR [r12+0x78],r8
    7f716edfef32:	mov    r15,r14
    7f716edfef35:	add    r15,0x24
    7f716edfef39:	mov    r9d,DWORD PTR [r15]
    7f716edfef3c:	mov    QWORD PTR [r12+0x90],r9
    7f716edfef44:	sub    r13,0xc0
    7f716edfef4b:	setne  BYTE PTR [rsp+0xb8]
    7f716edfef53:	mov    r11,rax
    7f716edfef56:	lahf
    7f716edfef57:	seto   al
    7f716edfef5a:	mov    WORD PTR [rsp+0xb0],ax
    7f716edfef62:	mov    rax,r11
    7f716edfef65:	mov    r13d,DWORD PTR [r12+0x70]
    7f716edfef6a:	mov    r13d,r13d
    7f716edfef6d:	mov    r13d,r13d
    7f716edfef70:	ror    r13d,0x7
    7f716edfef74:	mov    QWORD PTR [r12+0x80],r13
    7f716edfef7c:	mov    r15d,r8d
    7f716edfef7f:	mov    r15d,r15d
    7f716edfef82:	ror    r15d,0x11
    7f716edfef86:	mov    QWORD PTR [r12+0x88],r15
    7f716edfef8e:	mov    ebp,DWORD PTR [r12+0x60]
    7f716edfef93:	add    r9d,ebp
    7f716edfef96:	mov    QWORD PTR [r12+0x60],r9
    7f716edfef9b:	mov    ebp,DWORD PTR [r12+0x70]
    7f716edfefa0:	mov    ebp,ebp
    7f716edfefa2:	mov    ebp,ebp
    7f716edfefa4:	ror    ebp,0x12
    7f716edfefa7:	xor    r13d,ebp
    7f716edfefaa:	mov    QWORD PTR [r12+0x80],r13
    7f716edfefb2:	mov    ebp,r8d
    7f716edfefb5:	mov    ebp,ebp
    7f716edfefb7:	ror    ebp,0x13
    7f716edfefba:	xor    r15d,ebp
    7f716edfefbd:	mov    QWORD PTR [r12+0x88],r15
    7f716edfefc5:	mov    ebp,DWORD PTR [r12+0x70]
    7f716edfefca:	mov    ebp,ebp
    7f716edfefcc:	mov    ebp,ebp
    7f716edfefce:	shr    ebp,0x3
    7f716edfefd1:	xor    r13d,ebp
    7f716edfefd4:	mov    QWORD PTR [r12+0x80],r13
    7f716edfefdc:	mov    r8d,r8d
    7f716edfefdf:	shr    r8d,0xa
    7f716edfefe3:	xor    r15d,r8d
    7f716edfefe6:	mov    QWORD PTR [r12+0x78],r15
    7f716edfefeb:	add    r9d,r13d
    7f716edfefee:	mov    QWORD PTR [r12+0x60],r9
    7f716edfeff3:	add    r9d,r15d
    7f716edfeff6:	mov    QWORD PTR [r12+0x60],r9
    7f716edfeffb:	add    r14,0x40
    7f716edfefff:	mov    DWORD PTR [r14],r9d
    7f716edff002:	mov    r13d,0x0
    7f716edff008:	mov    DWORD PTR [r12+0x32c],r13d
    7f716edff010:	mov    r13d,0x0
    7f716edff016:	mov    ecx,DWORD PTR [r12+0x70]
    7f716edff01b:	mov    ecx,ecx
    7f716edff01d:	mov    r14d,r13d
    7f716edff020:	or     r14d,ecx
    7f716edff023:	mov    QWORD PTR [r12+0x60],r14
    7f716edff028:	mov    rcx,QWORD PTR [r12+0x380]
    7f716edff030:	jrcxz  0x7f716edff037
    7f716edff032:	jmp    0x7f716edff81a
    7f716edff037:	cmp    BYTE PTR [rsp+0xb8],0x0
    7f716edff03f:	jne    0x7f716edfeef9
    7f716edff045:	jmp    0x7f716edff04a
    7f716edff04a:	mov    r13,QWORD PTR [r12]
    7f716edff04e:	mov    r14,r13
    7f716edff051:	add    r14,0x4
    7f716edff055:	mov    r15d,DWORD PTR [r13+0x0]
    7f716edff059:	mov    ebp,DWORD PTR [r14]
    7f716edff05c:	mov    QWORD PTR [r12+0x78],r15
    7f716edff061:	mov    QWORD PTR [r12+0x80],rbp
    7f716edff069:	mov    r14,r13
    7f716edff06c:	add    r14,0x8
    7f716edff070:	mov    r8,r14
    7f716edff073:	add    r8,0x4
    7f716edff077:	mov    r9d,DWORD PTR [r14]
    7f716edff07a:	mov    eax,DWORD PTR [r8]
    7f716edff07d:	mov    QWORD PTR [rsp+0x90],rax
    7f716edff085:	mov    QWORD PTR [r12+0x70],r9
    7f716edff08a:	mov    rax,QWORD PTR [rsp+0x90]
    7f716edff092:	mov    QWORD PTR [r12+0x68],rax
    7f716edff097:	mov    r8,r13
    7f716edff09a:	add    r8,0x18
    7f716edff09e:	mov    r14,r8
    7f716edff0a1:	add    r14,0x4
    7f716edff0a5:	mov    eax,DWORD PTR [r8]
    7f716edff0a8:	mov    QWORD PTR [rsp+0x98],rax
    7f716edff0b0:	mov    r8d,DWORD PTR [r14]
    7f716edff0b3:	mov    rax,QWORD PTR [rsp+0x98]
    7f716edff0bb:	mov    QWORD PTR [r12+0x58],rax
    7f716edff0c0:	mov    QWORD PTR [r12+0x60],r8
    7f716edff0c5:	add    r13,0x10
    7f716edff0c9:	mov    r14,r13
    7f716edff0cc:	add    r14,0x4
    7f716edff0d0:	mov    eax,DWORD PTR [r13+0x0]
    7f716edff0d4:	mov    QWORD PTR [rsp+0xa0],rax
    7f716edff0dc:	mov    eax,DWORD PTR [r14]
    7f716edff0df:	mov    QWORD PTR [rsp+0xa8],rax
    7f716edff0e7:	mov    rax,QWORD PTR [rsp+0xa0]
    7f716edff0ef:	mov    QWORD PTR [r12+0x18],rax
    7f716edff0f4:	mov    rax,QWORD PTR [rsp+0xa8]
    7f716edff0fc:	mov    QWORD PTR [r12+0x90],rax
    7f716edff104:	mov    r14d,0x0
    7f716edff10a:	mov    QWORD PTR [r12+0x88],r14
    7f716edff112:	mov    r14d,0x0
    7f716edff118:	mov    r13d,r14d
    7f716edff11b:	or     r13d,r15d
    7f716edff11e:	mov    QWORD PTR [r12+0xa8],r13
    7f716edff126:	mov    r13d,0x0
    7f716edff12c:	mov    r14d,r13d
    7f716edff12f:	or     r14d,ebp
    7f716edff132:	mov    QWORD PTR [r12+0x38],r14
    7f716edff137:	mov    r13d,0x0
    7f716edff13d:	mov    r14d,r13d
    7f716edff140:	or     r14d,r9d
    7f716edff143:	mov    QWORD PTR [r12+0x98],r14
    7f716edff14b:	mov    r13d,0x0
    7f716edff151:	mov    ecx,DWORD PTR [rsp+0x90]
    7f716edff158:	mov    r14d,r13d
    7f716edff15b:	or     r14d,ecx
    7f716edff15e:	mov    QWORD PTR [r12+0x28],r14
    7f716edff163:	mov    r13d,0x0
    7f716edff169:	mov    r14d,r13d
    7f716edff16c:	or     r14d,r8d
    7f716edff16f:	mov    QWORD PTR [r12+0xb0],r14
    7f716edff177:	mov    r13d,0x0
    7f716edff17d:	mov    ecx,DWORD PTR [rsp+0x98]
    7f716edff184:	mov    r14d,r13d
    7f716edff187:	or     r14d,ecx
    7f716edff18a:	mov    QWORD PTR [r12+0xc0],r14
    7f716edff192:	mov    r13d,0x0
    7f716edff198:	mov    ecx,DWORD PTR [rsp+0xa8]
    7f716edff19f:	mov    r14d,r13d
    7f716edff1a2:	or     r14d,ecx
    7f716edff1a5:	mov    QWORD PTR [r12+0xc8],r14
    7f716edff1ad:	mov    r13d,0x0
    7f716edff1b3:	mov    ecx,DWORD PTR [rsp+0xa0]
    7f716edff1ba:	mov    r14d,r13d
    7f716edff1bd:	or     r14d,ecx
    7f716edff1c0:	mov    QWORD PTR [r12+0xb8],r14
    7f716edff1c8:	jmp    0x7f716edff1cd
    7f716edff1cd:	mov    r13d,0x0
    7f716edff1d3:	mov    r14d,DWORD PTR [r12+0xb8]
    7f716edff1db:	mov    eax,r13d
    7f716edff1de:	or     eax,r14d
    7f716edff1e1:	mov    QWORD PTR [r12+0x30],rax
    7f716edff1e6:	mov    r13d,0x0
    7f716edff1ec:	mov    ebp,DWORD PTR [r12+0xc0]
    7f716edff1f4:	mov    eax,r13d
    7f716edff1f7:	or     eax,ebp
    7f716edff1f9:	mov    QWORD PTR [r12+0xa0],rax
    7f716edff201:	mov    r13d,0x0
    7f716edff207:	mov    ebp,DWORD PTR [r12+0x28]
    7f716edff20c:	mov    eax,r13d
    7f716edff20f:	or     eax,ebp
    7f716edff211:	mov    QWORD PTR [r12+0xc0],rax
    7f716edff219:	mov    r13d,0x0
    7f716edff21f:	mov    ebp,DWORD PTR [r12+0x98]
    7f716edff227:	mov    eax,r13d
    7f716edff22a:	or     eax,ebp
    7f716edff22c:	mov    QWORD PTR [r12+0x28],rax
    7f716edff231:	mov    r13d,0x0
    7f716edff237:	mov    ebp,DWORD PTR [r12+0x38]
    7f716edff23c:	mov    eax,r13d
    7f716edff23f:	or     eax,ebp
    7f716edff241:	mov    QWORD PTR [r12+0x98],rax
    7f716edff249:	mov    r13d,0x0
    7f716edff24f:	mov    ebp,DWORD PTR [r12+0xa8]
    7f716edff257:	mov    eax,r13d
    7f716edff25a:	or     eax,ebp
    7f716edff25c:	mov    QWORD PTR [r12+0x38],rax
    7f716edff261:	mov    r14d,r14d
    7f716edff264:	ror    r14d,0x6
    7f716edff268:	mov    QWORD PTR [r12+0xb8],r14
    7f716edff270:	mov    r13d,DWORD PTR [r12+0xc8]
    7f716edff278:	mov    ebp,DWORD PTR [r12+0x30]
    7f716edff27d:	mov    ebp,ebp
    7f716edff27f:	and    ebp,r13d
    7f716edff282:	mov    QWORD PTR [r12+0xa8],rbp
    7f716edff28a:	mov    r9d,DWORD PTR [r12+0x38]
    7f716edff28f:	mov    r9d,r9d
    7f716edff292:	mov    r9d,r9d
    7f716edff295:	ror    r9d,0x2
    7f716edff299:	mov    QWORD PTR [r12+0xd0],r9
    7f716edff2a1:	mov    r15d,0x0
    7f716edff2a7:	mov    eax,r15d
    7f716edff2aa:	or     eax,r13d
    7f716edff2ad:	mov    QWORD PTR [r12+0x20],rax
    7f716edff2b2:	mov    rax,QWORD PTR [r12+0x88]
    7f716edff2ba:	mov    r15,QWORD PTR [r12+0x50]
    7f716edff2bf:	mov    rcx,QWORD PTR [r12+0x88]
    7f716edff2c7:	add    r15,rcx
    7f716edff2ca:	mov    r13d,DWORD PTR [r15]
    7f716edff2cd:	mov    QWORD PTR [r12+0xc8],r13
    7f716edff2d5:	mov    ecx,DWORD PTR [r12+0x30]
    7f716edff2da:	mov    ecx,ecx
    7f716edff2dc:	mov    r15d,DWORD PTR [r12+0xa0]
    7f716edff2e4:	mov    r15d,r15d
    7f716edff2e7:	not    rcx
    7f716edff2ea:	and    r15d,ecx
    7f716edff2ed:	mov    QWORD PTR [r12+0xd8],r15
    7f716edff2f5:	mov    r8d,DWORD PTR [r12+0xb0]
    7f716edff2fd:	add    ebp,r8d
    7f716edff300:	mov    QWORD PTR [r12+0xa8],rbp
    7f716edff308:	mov    r8d,DWORD PTR [r12+0x30]
    7f716edff30d:	mov    r8d,r8d
    7f716edff310:	mov    r8d,r8d
    7f716edff313:	ror    r8d,0xb
    7f716edff317:	xor    r14d,r8d
    7f716edff31a:	mov    QWORD PTR [r12+0xb0],r14
    7f716edff322:	mov    r8d,DWORD PTR [r12+0x38]
    7f716edff327:	mov    r8d,r8d
    7f716edff32a:	mov    r8d,r8d
    7f716edff32d:	ror    r8d,0xd
    7f716edff331:	xor    r9d,r8d
    7f716edff334:	mov    QWORD PTR [r12+0xd0],r9
    7f716edff33c:	add    ebp,r15d
    7f716edff33f:	mov    QWORD PTR [r12+0xa8],rbp
    7f716edff347:	mov    r15,QWORD PTR [r12+0x48]
    7f716edff34c:	mov    rcx,QWORD PTR [r12+0x88]
    7f716edff354:	add    r15,rcx
    7f716edff357:	mov    r8d,DWORD PTR [r15]
    7f716edff35a:	mov    QWORD PTR [r12+0xb8],r8
    7f716edff362:	mov    ecx,DWORD PTR [r12+0x98]
    7f716edff36a:	mov    ecx,ecx
    7f716edff36c:	mov    eax,DWORD PTR [r12+0x28]
    7f716edff371:	mov    eax,eax
    7f716edff373:	and    eax,ecx
    7f716edff375:	mov    QWORD PTR [r12+0xd8],rax
    7f716edff37d:	add    ebp,r13d
    7f716edff380:	mov    QWORD PTR [r12+0xa8],rbp
    7f716edff388:	mov    ecx,DWORD PTR [r12+0x98]
    7f716edff390:	mov    ecx,ecx
    7f716edff392:	mov    r13d,DWORD PTR [r12+0x28]
    7f716edff397:	mov    r13d,r13d
    7f716edff39a:	xor    r13d,ecx
    7f716edff39d:	mov    QWORD PTR [r12+0xc8],r13
    7f716edff3a5:	mov    r15d,DWORD PTR [r12+0x30]
    7f716edff3aa:	mov    r15d,r15d
    7f716edff3ad:	mov    r15d,r15d
    7f716edff3b0:	ror    r15d,0x19
    7f716edff3b4:	xor    r14d,r15d
    7f716edff3b7:	mov    QWORD PTR [r12+0xb0],r14
    7f716edff3bf:	mov    ecx,DWORD PTR [r12+0x38]
    7f716edff3c4:	mov    ecx,ecx
    7f716edff3c6:	and    r13d,ecx
    7f716edff3c9:	mov    QWORD PTR [r12+0xc8],r13
    7f716edff3d1:	mov    r15d,DWORD PTR [r12+0x38]
    7f716edff3d6:	mov    r15d,r15d
    7f716edff3d9:	mov    r15d,r15d
    7f716edff3dc:	ror    r15d,0x16
    7f716edff3e0:	xor    r9d,r15d
    7f716edff3e3:	mov    QWORD PTR [r12+0xd0],r9
    7f716edff3eb:	add    ebp,r8d
    7f716edff3ee:	mov    QWORD PTR [r12+0xa8],rbp
    7f716edff3f6:	mov    ecx,DWORD PTR [r12+0xd8]
    7f716edff3fe:	mov    ecx,ecx
    7f716edff400:	xor    r13d,ecx
    7f716edff403:	mov    QWORD PTR [r12+0xb8],r13
    7f716edff40b:	add    ebp,r14d
    7f716edff40e:	mov    QWORD PTR [r12+0xa8],rbp
    7f716edff416:	mov    r14,QWORD PTR [r12+0x88]
    7f716edff41e:	add    r14,0x4
    7f716edff422:	mov    QWORD PTR [r12+0x88],r14
    7f716edff42a:	add    r13d,r9d
    7f716edff42d:	mov    QWORD PTR [r12+0xb0],r13
    7f716edff435:	mov    ecx,DWORD PTR [r12+0xc0]
    7f716edff43d:	mov    ecx,ecx
    7f716edff43f:	mov    r15d,ebp
    7f716edff442:	add    r15d,ecx
    7f716edff445:	mov    QWORD PTR [r12+0xb8],r15
    7f716edff44d:	sub    r14,0x100
    7f716edff454:	setne  BYTE PTR [rsp+0xb8]
    7f716edff45c:	mov    r11,rax
    7f716edff45f:	lahf
    7f716edff460:	seto   al
    7f716edff463:	mov    WORD PTR [rsp+0xb0],ax
    7f716edff46b:	mov    rax,r11
    7f716edff46e:	add    r13d,ebp
    7f716edff471:	mov    QWORD PTR [r12+0xa8],r13
    7f716edff479:	mov    r13d,0x0
    7f716edff47f:	mov    ecx,DWORD PTR [r12+0xa0]
    7f716edff487:	mov    ecx,ecx
    7f716edff489:	mov    r14d,r13d
    7f716edff48c:	or     r14d,ecx
    7f716edff48f:	mov    QWORD PTR [r12+0xb0],r14
    7f716edff497:	mov    r13d,0x0
    7f716edff49d:	mov    ecx,DWORD PTR [r12+0x20]
    7f716edff4a2:	mov    ecx,ecx
    7f716edff4a4:	mov    r14d,r13d
    7f716edff4a7:	or     r14d,ecx
    7f716edff4aa:	mov    QWORD PTR [r12+0xc0],r14
    7f716edff4b2:	mov    r13d,0x0
    7f716edff4b8:	mov    ecx,DWORD PTR [r12+0x30]
    7f716edff4bd:	mov    ecx,ecx
    7f716edff4bf:	mov    r14d,r13d
    7f716edff4c2:	or     r14d,ecx
    7f716edff4c5:	mov    QWORD PTR [r12+0xc8],r14
    7f716edff4cd:	mov    rcx,QWORD PTR [r12+0x380]
    7f716edff4d5:	jrcxz  0x7f716edff4dc
    7f716edff4d7:	jmp    0x7f716edff8a2
    7f716edff4dc:	cmp    BYTE PTR [rsp+0xb8],0x0
    7f716edff4e4:	jne    0x7f716edff1cd
    7f716edff4ea:	jmp    0x7f716edff4ef
    7f716edff4ef:	mov    r13d,DWORD PTR [r12+0x70]
    7f716edff4f4:	mov    r14d,DWORD PTR [r12+0x98]
    7f716edff4fc:	add    r14d,r13d
    7f716edff4ff:	mov    QWORD PTR [r12+0x70],r14
    7f716edff504:	mov    r13d,DWORD PTR [r12+0x68]
    7f716edff509:	mov    r15d,DWORD PTR [r12+0x28]
    7f716edff50e:	add    r15d,r13d
    7f716edff511:	mov    QWORD PTR [r12+0x68],r15
    7f716edff516:	mov    r13d,0x0
    7f716edff51c:	mov    QWORD PTR [r12+0x88],r13
    7f716edff524:	mov    r13d,DWORD PTR [r12+0x78]
    7f716edff529:	mov    ebp,DWORD PTR [r12+0xa8]
    7f716edff531:	add    ebp,r13d
    7f716edff534:	mov    QWORD PTR [r12+0x78],rbp
    7f716edff539:	mov    r13d,DWORD PTR [r12+0x80]
    7f716edff541:	mov    r8d,DWORD PTR [r12+0x38]
    7f716edff546:	add    r8d,r13d
    7f716edff549:	mov    QWORD PTR [r12+0x80],r8
    7f716edff551:	mov    rax,QWORD PTR [r12]
    7f716edff555:	mov    r9,QWORD PTR [r12]
    7f716edff559:	add    r9,0x8
    7f716edff55d:	mov    r13,r9
    7f716edff560:	add    r13,0x4
    7f716edff564:	mov    DWORD PTR [r9],r14d
    7f716edff567:	mov    r14d,0x0
    7f716edff56d:	mov    DWORD PTR [r12+0x32c],r14d
    7f716edff575:	mov    DWORD PTR [r13+0x0],r15d
    7f716edff579:	mov    r13d,DWORD PTR [r12+0x18]
    7f716edff57e:	mov    r14d,DWORD PTR [r12+0xb8]
    7f716edff586:	add    r14d,r13d
    7f716edff589:	mov    QWORD PTR [r12+0x68],r14
    7f716edff58e:	mov    r13d,DWORD PTR [r12+0x90]
    7f716edff596:	mov    r15d,DWORD PTR [r12+0x30]
    7f716edff59b:	add    r15d,r13d
    7f716edff59e:	mov    QWORD PTR [r12+0x70],r15
    7f716edff5a3:	mov    r13d,DWORD PTR [r12+0x58]
    7f716edff5a8:	mov    r9d,DWORD PTR [r12+0x20]
    7f716edff5ad:	mov    eax,r9d
    7f716edff5b0:	add    eax,r13d
    7f716edff5b3:	mov    QWORD PTR [r12+0x58],rax
    7f716edff5b8:	mov    r13d,DWORD PTR [r12+0x60]
    7f716edff5bd:	mov    r9d,DWORD PTR [r12+0xa0]
    7f716edff5c5:	add    r9d,r13d
    7f716edff5c8:	mov    QWORD PTR [r12+0x60],r9
    7f716edff5cd:	mov    r13,QWORD PTR [r12]
    7f716edff5d1:	add    r13,0x4
    7f716edff5d5:	mov    rdi,QWORD PTR [r12]
    7f716edff5d9:	mov    DWORD PTR [rdi],ebp
    7f716edff5db:	mov    DWORD PTR [r13+0x0],r8d
    7f716edff5df:	mov    r13,QWORD PTR [r12]
    7f716edff5e3:	add    r13,0x10
    7f716edff5e7:	mov    rbp,r13
    7f716edff5ea:	add    rbp,0x4
    7f716edff5ee:	mov    DWORD PTR [r13+0x0],r14d
    7f716edff5f2:	mov    DWORD PTR [rbp+0x0],r15d
    7f716edff5f6:	mov    r13,QWORD PTR [r12]
    7f716edff5fa:	add    r13,0x18
    7f716edff5fe:	mov    r14,r13
    7f716edff601:	add    r14,0x4
    7f716edff605:	mov    eax,DWORD PTR [r12+0x58]
    7f716edff60a:	mov    DWORD PTR [r13+0x0],eax
    7f716edff60e:	mov    DWORD PTR [r14],r9d
    7f716edff611:	mov    r13,QWORD PTR [r12]
    7f716edff615:	add    r13,0x68
    7f716edff619:	mov    r14d,0x0
    7f716edff61f:	mov    QWORD PTR [r13+0x0],r14
    7f716edff623:	mov    rcx,QWORD PTR [r12+0x380]
    7f716edff62b:	jrcxz  0x7f716edff632
    7f716edff62d:	jmp    0x7f716edff92a
    7f716edff632:	jmp    0x7f716edff637
    7f716edff637:	mov    r13,QWORD PTR [r12+0x10]
    7f716edff63c:	sub    r13,0x1
    7f716edff640:	mov    QWORD PTR [r12+0x10],r13
    7f716edff645:	mov    rax,r13
    7f716edff648:	test   rax,rax
    7f716edff64b:	je     0x7f716edff656
    7f716edff651:	jmp    0x7f716edfd75a
    7f716edff656:	mov    r13,QWORD PTR [r12+0xf8]
    7f716edff65e:	mov    r14,r13
    7f716edff661:	add    r14,0x140
    7f716edff668:	mov    r15,r14
    7f716edff66b:	add    r15,0x8
    7f716edff66f:	mov    rbp,QWORD PTR [r14]
    7f716edff672:	mov    r14,QWORD PTR [r15]
    7f716edff675:	mov    QWORD PTR [r12+0xa0],rbp
    7f716edff67d:	mov    QWORD PTR [r12+0x98],r14
    7f716edff685:	mov    r14,r13
    7f716edff688:	add    r14,0x130
    7f716edff68f:	mov    r15,r14
    7f716edff692:	add    r15,0x8
    7f716edff696:	mov    rbp,QWORD PTR [r14]
    7f716edff699:	mov    r14,QWORD PTR [r15]
    7f716edff69c:	mov    QWORD PTR [r12+0xb0],rbp
    7f716edff6a4:	mov    QWORD PTR [r12+0xa8],r14
    7f716edff6ac:	mov    r14,r13
    7f716edff6af:	add    r14,0x120
    7f716edff6b6:	mov    r15,r14
    7f716edff6b9:	add    r15,0x8
    7f716edff6bd:	mov    rbp,QWORD PTR [r14]
    7f716edff6c0:	mov    r14,QWORD PTR [r15]
    7f716edff6c3:	mov    QWORD PTR [r12+0xc0],rbp
    7f716edff6cb:	mov    QWORD PTR [r12+0xb8],r14
    7f716edff6d3:	mov    r14,r13
    7f716edff6d6:	add    r14,0x110
    7f716edff6dd:	mov    r15,r14
    7f716edff6e0:	add    r15,0x8
    7f716edff6e4:	mov    rbp,QWORD PTR [r14]
    7f716edff6e7:	mov    r14,QWORD PTR [r15]
    7f716edff6ea:	mov    QWORD PTR [r12+0xd0],rbp
    7f716edff6f2:	mov    QWORD PTR [r12+0xc8],r14
    7f716edff6fa:	mov    r14,r13
    7f716edff6fd:	add    r14,0x100
    7f716edff704:	mov    r15,r14
    7f716edff707:	add    r15,0x8
    7f716edff70b:	mov    rbp,QWORD PTR [r14]
    7f716edff70e:	mov    r14,QWORD PTR [r15]
    7f716edff711:	mov    QWORD PTR [r12+0xe8],rbp
    7f716edff719:	mov    QWORD PTR [r12+0xd8],r14
    7f716edff721:	add    r13,0x150
    7f716edff728:	mov    QWORD PTR [r12+0xf8],r13
    7f716edff730:	jmp    0x7f716edff735
    7f716edff735:	mov    rcx,QWORD PTR [r12+0x380]
    7f716edff73d:	jrcxz  0x7f716edff744
    7f716edff73f:	jmp    0x7f716edff9b2
    7f716edff744:	mov    r13,QWORD PTR [r12+0xf0]
    7f716edff74c:	mov    QWORD PTR [r12+0x100],r13
    7f716edff754:	mov    r11,QWORD PTR [rsp+0xb0]
    7f716edff75c:	mov    QWORD PTR [r12+0x398],r11
    7f716edff764:	mov    rdi,QWORD PTR [r12+0x100]
    7f716edff76c:	add    rsp,0xc0
    7f716edff773:	movabs r11,0x5fdfb8bf7940
    7f716edff77d:	jmp    r11
    7f716edff780:	mov    eax,0x41078c
    7f716edff785:	mov    QWORD PTR [r12+0x100],rax
    7f716edff78d:	push   rdx
    7f716edff78e:	push   rsi
    7f716edff78f:	push   r10
    7f716edff791:	push   r11
    7f716edff793:	mov    r11,rax
    7f716edff796:	lahf
    7f716edff797:	seto   al
    7f716edff79a:	mov    WORD PTR [rsp+0xd0],ax
    7f716edff7a2:	mov    rax,r11
    7f716edff7a5:	mov    rdx,QWORD PTR [rsp+0xd0]
    7f716edff7ad:	mov    r10d,edx
    7f716edff7b0:	and    r10d,0xc000
    7f716edff7b7:	shl    r10d,0x10
    7f716edff7bb:	mov    r11d,edx
    7f716edff7be:	and    r11d,0x100
    7f716edff7c5:	shl    r11d,0x15
    7f716edff7c9:	or     r10d,r11d
    7f716edff7cc:	and    edx,0x1
    7f716edff7cf:	shl    edx,0x1c
    7f716edff7d2:	or     r10d,edx
    7f716edff7d5:	btc    r10,0x1d
    7f716edff7da:	mov    r11d,0xf0000000
    7f716edff7e0:	and    r11,r10
    7f716edff7e3:	movabs rsi,0xffffffff0fffffff
    7f716edff7ed:	and    rbx,rsi
    7f716edff7f0:	or     rbx,r11
    7f716edff7f3:	pop    r11
    7f716edff7f5:	pop    r10
    7f716edff7f7:	pop    rsi
    7f716edff7f8:	pop    rdx
    7f716edff7f9:	mov    QWORD PTR [r12+0x108],rbx
    7f716edff801:	add    rsp,0xc0
    7f716edff808:	mov    eax,0xc
    7f716edff80d:	movabs r11,0x5fdfb8bf7ca0
    7f716edff817:	jmp    r11
    7f716edff81a:	mov    eax,0x410888
    7f716edff81f:	mov    QWORD PTR [r12+0x100],rax
    7f716edff827:	push   rdx
    7f716edff828:	push   rsi
    7f716edff829:	push   r10
    7f716edff82b:	push   r11
    7f716edff82d:	mov    rdx,QWORD PTR [rsp+0xd0]
    7f716edff835:	mov    r10d,edx
    7f716edff838:	and    r10d,0xc000
    7f716edff83f:	shl    r10d,0x10
    7f716edff843:	mov    r11d,edx
    7f716edff846:	and    r11d,0x100
    7f716edff84d:	shl    r11d,0x15
    7f716edff851:	or     r10d,r11d
    7f716edff854:	and    edx,0x1
    7f716edff857:	shl    edx,0x1c
    7f716edff85a:	or     r10d,edx
    7f716edff85d:	btc    r10,0x1d
    7f716edff862:	mov    r11d,0xf0000000
    7f716edff868:	and    r11,r10
    7f716edff86b:	movabs rsi,0xffffffff0fffffff
    7f716edff875:	and    rbx,rsi
    7f716edff878:	or     rbx,r11
    7f716edff87b:	pop    r11
    7f716edff87d:	pop    r10
    7f716edff87f:	pop    rsi
    7f716edff880:	pop    rdx
    7f716edff881:	mov    QWORD PTR [r12+0x108],rbx
    7f716edff889:	add    rsp,0xc0
    7f716edff890:	mov    eax,0xc
    7f716edff895:	movabs r11,0x5fdfb8bf7ca0
    7f716edff89f:	jmp    r11
    7f716edff8a2:	mov    eax,0x410948
    7f716edff8a7:	mov    QWORD PTR [r12+0x100],rax
    7f716edff8af:	push   rdx
    7f716edff8b0:	push   rsi
    7f716edff8b1:	push   r10
    7f716edff8b3:	push   r11
    7f716edff8b5:	mov    rdx,QWORD PTR [rsp+0xd0]
    7f716edff8bd:	mov    r10d,edx
    7f716edff8c0:	and    r10d,0xc000
    7f716edff8c7:	shl    r10d,0x10
    7f716edff8cb:	mov    r11d,edx
    7f716edff8ce:	and    r11d,0x100
    7f716edff8d5:	shl    r11d,0x15
    7f716edff8d9:	or     r10d,r11d
    7f716edff8dc:	and    edx,0x1
    7f716edff8df:	shl    edx,0x1c
    7f716edff8e2:	or     r10d,edx
    7f716edff8e5:	btc    r10,0x1d
    7f716edff8ea:	mov    r11d,0xf0000000
    7f716edff8f0:	and    r11,r10
    7f716edff8f3:	movabs rsi,0xffffffff0fffffff
    7f716edff8fd:	and    rbx,rsi
    7f716edff900:	or     rbx,r11
    7f716edff903:	pop    r11
    7f716edff905:	pop    r10
    7f716edff907:	pop    rsi
    7f716edff908:	pop    rdx
    7f716edff909:	mov    QWORD PTR [r12+0x108],rbx
    7f716edff911:	add    rsp,0xc0
    7f716edff918:	mov    eax,0xc
    7f716edff91d:	movabs r11,0x5fdfb8bf7ca0
    7f716edff927:	jmp    r11
    7f716edff92a:	mov    eax,0x410984
    7f716edff92f:	mov    QWORD PTR [r12+0x100],rax
    7f716edff937:	push   rdx
    7f716edff938:	push   rsi
    7f716edff939:	push   r10
    7f716edff93b:	push   r11
    7f716edff93d:	mov    rdx,QWORD PTR [rsp+0xd0]
    7f716edff945:	mov    r10d,edx
    7f716edff948:	and    r10d,0xc000
    7f716edff94f:	shl    r10d,0x10
    7f716edff953:	mov    r11d,edx
    7f716edff956:	and    r11d,0x100
    7f716edff95d:	shl    r11d,0x15
    7f716edff961:	or     r10d,r11d
    7f716edff964:	and    edx,0x1
    7f716edff967:	shl    edx,0x1c
    7f716edff96a:	or     r10d,edx
    7f716edff96d:	btc    r10,0x1d
    7f716edff972:	mov    r11d,0xf0000000
    7f716edff978:	and    r11,r10
    7f716edff97b:	movabs rsi,0xffffffff0fffffff
    7f716edff985:	and    rbx,rsi
    7f716edff988:	or     rbx,r11
    7f716edff98b:	pop    r11
    7f716edff98d:	pop    r10
    7f716edff98f:	pop    rsi
    7f716edff990:	pop    rdx
    7f716edff991:	mov    QWORD PTR [r12+0x108],rbx
    7f716edff999:	add    rsp,0xc0
    7f716edff9a0:	mov    eax,0xc
    7f716edff9a5:	movabs r11,0x5fdfb8bf7ca0
    7f716edff9af:	jmp    r11
    7f716edff9b2:	mov    eax,0x4109a0
    7f716edff9b7:	mov    QWORD PTR [r12+0x100],rax
    7f716edff9bf:	push   rdx
    7f716edff9c0:	push   rsi
    7f716edff9c1:	push   r10
    7f716edff9c3:	push   r11
    7f716edff9c5:	mov    rdx,QWORD PTR [rsp+0xd0]
    7f716edff9cd:	mov    r10d,edx
    7f716edff9d0:	and    r10d,0xc000
    7f716edff9d7:	shl    r10d,0x10
    7f716edff9db:	mov    r11d,edx
    7f716edff9de:	and    r11d,0x100
    7f716edff9e5:	shl    r11d,0x15
    7f716edff9e9:	or     r10d,r11d
    7f716edff9ec:	and    edx,0x1
    7f716edff9ef:	shl    edx,0x1c
    7f716edff9f2:	or     r10d,edx
    7f716edff9f5:	btc    r10,0x1d
    7f716edff9fa:	mov    r11d,0xf0000000
    7f716edffa00:	and    r11,r10
    7f716edffa03:	movabs rsi,0xffffffff0fffffff
    7f716edffa0d:	and    rbx,rsi
    7f716edffa10:	or     rbx,r11
    7f716edffa13:	pop    r11
    7f716edffa15:	pop    r10
    7f716edffa17:	pop    rsi
    7f716edffa18:	pop    rdx
    7f716edffa19:	mov    QWORD PTR [r12+0x108],rbx
    7f716edffa21:	add    rsp,0xc0
    7f716edffa28:	mov    eax,0xc
    7f716edffa2d:	movabs r11,0x5fdfb8bf7ca0
    7f716edffa37:	jmp    r11
    7f716edffa3a:	nop    WORD PTR [rax+rax*1+0x0]
    7f716edffa40:	sub    rsp,0xc0
    7f716edffa47:	mov    r11,QWORD PTR [r12+0x398]
    7f716edffa4f:	mov    QWORD PTR [rsp+0xb0],r11
    7f716edffa57:	jmp    0x7f716edfd639
    7f716edffa5c:	nop    DWORD PTR [rax+0x0]
    7f716edffa60:	sub    rsp,0xc0
    7f716edffa67:	mov    r11,QWORD PTR [r12+0x398]
    7f716edffa6f:	mov    QWORD PTR [rsp+0xb0],r11
    7f716edffa77:	jmp    0x7f716edfd75a
    7f716edffa7c:	nop    DWORD PTR [rax+0x0]
    7f716edffa80:	sub    rsp,0xc0
    7f716edffa87:	mov    r11,QWORD PTR [r12+0x398]
    7f716edffa8f:	mov    QWORD PTR [rsp+0xb0],r11
    7f716edffa97:	jmp    0x7f716edfd814
    7f716edffa9c:	nop    DWORD PTR [rax+0x0]
    7f716edffaa0:	sub    rsp,0xc0
    7f716edffaa7:	mov    r11,QWORD PTR [r12+0x398]
    7f716edffaaf:	mov    QWORD PTR [rsp+0xb0],r11
    7f716edffab7:	jmp    0x7f716edfeef9
    7f716edffabc:	nop    DWORD PTR [rax+0x0]
    7f716edffac0:	sub    rsp,0xc0
    7f716edffac7:	mov    r11,QWORD PTR [r12+0x398]
    7f716edffacf:	mov    QWORD PTR [rsp+0xb0],r11
    7f716edffad7:	jmp    0x7f716edff04a
    7f716edffadc:	nop    DWORD PTR [rax+0x0]
    7f716edffae0:	sub    rsp,0xc0
    7f716edffae7:	mov    r11,QWORD PTR [r12+0x398]
    7f716edffaef:	mov    QWORD PTR [rsp+0xb0],r11
    7f716edffaf7:	jmp    0x7f716edff1cd
    7f716edffafc:	nop    DWORD PTR [rax+0x0]
    7f716edffb00:	sub    rsp,0xc0
    7f716edffb07:	mov    r11,QWORD PTR [r12+0x398]
    7f716edffb0f:	mov    QWORD PTR [rsp+0xb0],r11
    7f716edffb17:	jmp    0x7f716edff4ef
    7f716edffb1c:	nop    DWORD PTR [rax+0x0]
    7f716edffb20:	sub    rsp,0xc0
    7f716edffb27:	mov    r11,QWORD PTR [r12+0x398]
    7f716edffb2f:	mov    QWORD PTR [rsp+0xb0],r11
    7f716edffb37:	jmp    0x7f716edff637
    7f716edffb3c:	nop    DWORD PTR [rax+0x0]
    7f716edffb40:	sub    rsp,0xc0
    7f716edffb47:	mov    r11,QWORD PTR [r12+0x398]
    7f716edffb4f:	mov    QWORD PTR [rsp+0xb0],r11
    7f716edffb57:	jmp    0x7f716edff656
    7f716edffb5c:	nop    DWORD PTR [rax+0x0]
    7f716edffb60:	sub    rsp,0xc0
    7f716edffb67:	mov    r11,QWORD PTR [r12+0x398]
    7f716edffb6f:	mov    QWORD PTR [rsp+0xb0],r11
    7f716edffb77:	jmp    0x7f716edff735
