
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/1/5.bin:     file format binary


Disassembly of section .data:

000075b0bab01220 <.data>:
    75b0bab01220:	sub    rsp,0x10
    75b0bab01224:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0122c:	mov    QWORD PTR [rsp],r11
    75b0bab01230:	mov    rax,QWORD PTR [r12+0xf8]
    75b0bab01238:	mov    r14,QWORD PTR [r12+0xf8]
    75b0bab01240:	add    r14,0x100
    75b0bab01247:	mov    r15d,DWORD PTR [r14]
    75b0bab0124a:	mov    QWORD PTR [r12+0x40],r15
    75b0bab0124f:	mov    r14,QWORD PTR [r12+0xf8]
    75b0bab01257:	add    r14,0x104
    75b0bab0125e:	mov    ebp,DWORD PTR [r14]
    75b0bab01261:	mov    QWORD PTR [r12+0x50],rbp
    75b0bab01266:	mov    r14d,0x430c90
    75b0bab0126c:	mov    QWORD PTR [r12+0x48],r14
    75b0bab01271:	mov    r14,QWORD PTR [r12+0xf8]
    75b0bab01279:	add    r14,0x108
    75b0bab01280:	mov    r8d,DWORD PTR [r14]
    75b0bab01283:	mov    QWORD PTR [r12+0x58],r8
    75b0bab01288:	mov    r14,QWORD PTR [r12+0xf8]
    75b0bab01290:	add    r14,0x10c
    75b0bab01297:	mov    eax,DWORD PTR [r14]
    75b0bab0129a:	mov    QWORD PTR [r12+0x60],rax
    75b0bab0129f:	movabs rcx,0xff00ff00ff00ff
    75b0bab012a9:	mov    r14,r15
    75b0bab012ac:	and    r14,rcx
    75b0bab012af:	shl    r14,0x8
    75b0bab012b3:	movabs rcx,0xff00ff00ff00ff00
    75b0bab012bd:	mov    r13,r15
    75b0bab012c0:	and    r13,rcx
    75b0bab012c3:	shr    r13,0x8
    75b0bab012c7:	or     r13,r14
    75b0bab012ca:	movabs rcx,0xffff0000ffff
    75b0bab012d4:	mov    r14,r13
    75b0bab012d7:	and    r14,rcx
    75b0bab012da:	shl    r14,0x10
    75b0bab012de:	movabs rcx,0xffff0000ffff0000
    75b0bab012e8:	and    r13,rcx
    75b0bab012eb:	shr    r13,0x10
    75b0bab012ef:	or     r13,r14
    75b0bab012f2:	mov    ecx,0xffffffff
    75b0bab012f7:	and    r13,rcx
    75b0bab012fa:	mov    QWORD PTR [r12+0x40],r13
    75b0bab012ff:	movabs rcx,0xff00ff00ff00ff
    75b0bab01309:	mov    r14,rbp
    75b0bab0130c:	and    r14,rcx
    75b0bab0130f:	shl    r14,0x8
    75b0bab01313:	movabs rcx,0xff00ff00ff00ff00
    75b0bab0131d:	mov    r15,rbp
    75b0bab01320:	and    r15,rcx
    75b0bab01323:	shr    r15,0x8
    75b0bab01327:	or     r15,r14
    75b0bab0132a:	movabs rcx,0xffff0000ffff
    75b0bab01334:	mov    r14,r15
    75b0bab01337:	and    r14,rcx
    75b0bab0133a:	shl    r14,0x10
    75b0bab0133e:	movabs rcx,0xffff0000ffff0000
    75b0bab01348:	and    r15,rcx
    75b0bab0134b:	shr    r15,0x10
    75b0bab0134f:	or     r15,r14
    75b0bab01352:	mov    ecx,0xffffffff
    75b0bab01357:	and    r15,rcx
    75b0bab0135a:	mov    QWORD PTR [r12+0x50],r15
    75b0bab0135f:	mov    r14d,0x0
    75b0bab01365:	mov    QWORD PTR [r12+0xa0],r14
    75b0bab0136d:	mov    r14d,0x430c90
    75b0bab01373:	mov    ebp,0x430c94
    75b0bab01378:	mov    rax,r13
    75b0bab0137b:	mov    eax,eax
    75b0bab0137d:	mov    r9d,eax
    75b0bab01380:	mov    rax,r15
    75b0bab01383:	mov    eax,eax
    75b0bab01385:	mov    r13d,eax
    75b0bab01388:	mov    DWORD PTR [r14],r9d
    75b0bab0138b:	mov    r14d,0x0
    75b0bab01391:	mov    DWORD PTR [r12+0x32c],r14d
    75b0bab01399:	mov    DWORD PTR [rbp+0x0],r13d
    75b0bab0139d:	movabs rcx,0xff00ff00ff00ff
    75b0bab013a7:	mov    r13,r8
    75b0bab013aa:	and    r13,rcx
    75b0bab013ad:	shl    r13,0x8
    75b0bab013b1:	movabs rcx,0xff00ff00ff00ff00
    75b0bab013bb:	mov    r14,r8
    75b0bab013be:	and    r14,rcx
    75b0bab013c1:	shr    r14,0x8
    75b0bab013c5:	or     r14,r13
    75b0bab013c8:	movabs rcx,0xffff0000ffff
    75b0bab013d2:	mov    r13,r14
    75b0bab013d5:	and    r13,rcx
    75b0bab013d8:	shl    r13,0x10
    75b0bab013dc:	movabs rcx,0xffff0000ffff0000
    75b0bab013e6:	and    r14,rcx
    75b0bab013e9:	shr    r14,0x10
    75b0bab013ed:	or     r14,r13
    75b0bab013f0:	mov    ecx,0xffffffff
    75b0bab013f5:	and    r14,rcx
    75b0bab013f8:	mov    QWORD PTR [r12+0x40],r14
    75b0bab013fd:	mov    r13,QWORD PTR [r12+0xf8]
    75b0bab01405:	add    r13,0x110
    75b0bab0140c:	mov    r15d,DWORD PTR [r13+0x0]
    75b0bab01410:	mov    QWORD PTR [r12+0x50],r15
    75b0bab01415:	movabs rcx,0xff00ff00ff00ff
    75b0bab0141f:	mov    r13d,DWORD PTR [r12+0x60]
    75b0bab01424:	and    r13,rcx
    75b0bab01427:	shl    r13,0x8
    75b0bab0142b:	movabs rcx,0xff00ff00ff00ff00
    75b0bab01435:	mov    ebp,DWORD PTR [r12+0x60]
    75b0bab0143a:	and    rbp,rcx
    75b0bab0143d:	shr    rbp,0x8
    75b0bab01441:	or     rbp,r13
    75b0bab01444:	movabs rcx,0xffff0000ffff
    75b0bab0144e:	mov    r13,rbp
    75b0bab01451:	and    r13,rcx
    75b0bab01454:	shl    r13,0x10
    75b0bab01458:	movabs rcx,0xffff0000ffff0000
    75b0bab01462:	and    rbp,rcx
    75b0bab01465:	shr    rbp,0x10
    75b0bab01469:	or     rbp,r13
    75b0bab0146c:	mov    ecx,0xffffffff
    75b0bab01471:	and    rbp,rcx
    75b0bab01474:	mov    QWORD PTR [r12+0x58],rbp
    75b0bab01479:	mov    r13,QWORD PTR [r12+0xf8]
    75b0bab01481:	add    r13,0x114
    75b0bab01488:	mov    eax,DWORD PTR [r13+0x0]
    75b0bab0148c:	mov    QWORD PTR [r12+0x60],rax
    75b0bab01491:	mov    r13d,0x430000
    75b0bab01497:	add    r13,0xdfc
    75b0bab0149e:	mov    QWORD PTR [r12+0x98],r13
    75b0bab014a6:	mov    r13d,0x430c98
    75b0bab014ac:	mov    r9d,0x430c9c
    75b0bab014b2:	mov    rax,r14
    75b0bab014b5:	mov    eax,eax
    75b0bab014b7:	mov    r8d,eax
    75b0bab014ba:	mov    rax,rbp
    75b0bab014bd:	mov    eax,eax
    75b0bab014bf:	mov    r14d,eax
    75b0bab014c2:	mov    DWORD PTR [r13+0x0],r8d
    75b0bab014c6:	mov    DWORD PTR [r9],r14d
    75b0bab014c9:	movabs rcx,0xff00ff00ff00ff
    75b0bab014d3:	mov    r13,r15
    75b0bab014d6:	and    r13,rcx
    75b0bab014d9:	shl    r13,0x8
    75b0bab014dd:	movabs rcx,0xff00ff00ff00ff00
    75b0bab014e7:	mov    r14,r15
    75b0bab014ea:	and    r14,rcx
    75b0bab014ed:	shr    r14,0x8
    75b0bab014f1:	or     r14,r13
    75b0bab014f4:	movabs rcx,0xffff0000ffff
    75b0bab014fe:	mov    r13,r14
    75b0bab01501:	and    r13,rcx
    75b0bab01504:	shl    r13,0x10
    75b0bab01508:	movabs rcx,0xffff0000ffff0000
    75b0bab01512:	and    r14,rcx
    75b0bab01515:	shr    r14,0x10
    75b0bab01519:	or     r14,r13
    75b0bab0151c:	mov    ecx,0xffffffff
    75b0bab01521:	and    r14,rcx
    75b0bab01524:	mov    QWORD PTR [r12+0x40],r14
    75b0bab01529:	mov    r13,QWORD PTR [r12+0xf8]
    75b0bab01531:	add    r13,0x118
    75b0bab01538:	mov    r15d,DWORD PTR [r13+0x0]
    75b0bab0153c:	mov    QWORD PTR [r12+0x50],r15
    75b0bab01541:	movabs rcx,0xff00ff00ff00ff
    75b0bab0154b:	mov    r13d,DWORD PTR [r12+0x60]
    75b0bab01550:	and    r13,rcx
    75b0bab01553:	shl    r13,0x8
    75b0bab01557:	movabs rcx,0xff00ff00ff00ff00
    75b0bab01561:	mov    ebp,DWORD PTR [r12+0x60]
    75b0bab01566:	and    rbp,rcx
    75b0bab01569:	shr    rbp,0x8
    75b0bab0156d:	or     rbp,r13
    75b0bab01570:	movabs rcx,0xffff0000ffff
    75b0bab0157a:	mov    r13,rbp
    75b0bab0157d:	and    r13,rcx
    75b0bab01580:	shl    r13,0x10
    75b0bab01584:	movabs rcx,0xffff0000ffff0000
    75b0bab0158e:	and    rbp,rcx
    75b0bab01591:	shr    rbp,0x10
    75b0bab01595:	or     rbp,r13
    75b0bab01598:	mov    ecx,0xffffffff
    75b0bab0159d:	and    rbp,rcx
    75b0bab015a0:	mov    QWORD PTR [r12+0x58],rbp
    75b0bab015a5:	mov    r13,QWORD PTR [r12+0xf8]
    75b0bab015ad:	add    r13,0x11c
    75b0bab015b4:	mov    eax,DWORD PTR [r13+0x0]
    75b0bab015b8:	mov    QWORD PTR [r12+0x60],rax
    75b0bab015bd:	mov    r13d,0x430ca0
    75b0bab015c3:	mov    r9d,0x430ca4
    75b0bab015c9:	mov    rax,r14
    75b0bab015cc:	mov    eax,eax
    75b0bab015ce:	mov    r8d,eax
    75b0bab015d1:	mov    rax,rbp
    75b0bab015d4:	mov    eax,eax
    75b0bab015d6:	mov    r14d,eax
    75b0bab015d9:	mov    DWORD PTR [r13+0x0],r8d
    75b0bab015dd:	mov    DWORD PTR [r9],r14d
    75b0bab015e0:	movabs rcx,0xff00ff00ff00ff
    75b0bab015ea:	mov    r13,r15
    75b0bab015ed:	and    r13,rcx
    75b0bab015f0:	shl    r13,0x8
    75b0bab015f4:	movabs rcx,0xff00ff00ff00ff00
    75b0bab015fe:	mov    r14,r15
    75b0bab01601:	and    r14,rcx
    75b0bab01604:	shr    r14,0x8
    75b0bab01608:	or     r14,r13
    75b0bab0160b:	movabs rcx,0xffff0000ffff
    75b0bab01615:	mov    r13,r14
    75b0bab01618:	and    r13,rcx
    75b0bab0161b:	shl    r13,0x10
    75b0bab0161f:	movabs rcx,0xffff0000ffff0000
    75b0bab01629:	and    r14,rcx
    75b0bab0162c:	shr    r14,0x10
    75b0bab01630:	or     r14,r13
    75b0bab01633:	mov    ecx,0xffffffff
    75b0bab01638:	and    r14,rcx
    75b0bab0163b:	mov    QWORD PTR [r12+0x40],r14
    75b0bab01640:	movabs rcx,0xff00ff00ff00ff
    75b0bab0164a:	mov    r13d,DWORD PTR [r12+0x60]
    75b0bab0164f:	and    r13,rcx
    75b0bab01652:	shl    r13,0x8
    75b0bab01656:	movabs rcx,0xff00ff00ff00ff00
    75b0bab01660:	mov    r15d,DWORD PTR [r12+0x60]
    75b0bab01665:	and    r15,rcx
    75b0bab01668:	shr    r15,0x8
    75b0bab0166c:	or     r15,r13
    75b0bab0166f:	movabs rcx,0xffff0000ffff
    75b0bab01679:	mov    r13,r15
    75b0bab0167c:	and    r13,rcx
    75b0bab0167f:	shl    r13,0x10
    75b0bab01683:	movabs rcx,0xffff0000ffff0000
    75b0bab0168d:	and    r15,rcx
    75b0bab01690:	shr    r15,0x10
    75b0bab01694:	or     r15,r13
    75b0bab01697:	mov    ecx,0xffffffff
    75b0bab0169c:	and    r15,rcx
    75b0bab0169f:	mov    QWORD PTR [r12+0x50],r15
    75b0bab016a4:	mov    r13d,0x430ca8
    75b0bab016aa:	mov    ebp,0x430cac
    75b0bab016af:	mov    rax,r14
    75b0bab016b2:	mov    eax,eax
    75b0bab016b4:	mov    r8d,eax
    75b0bab016b7:	mov    rax,r15
    75b0bab016ba:	mov    eax,eax
    75b0bab016bc:	mov    r14d,eax
    75b0bab016bf:	mov    DWORD PTR [r13+0x0],r8d
    75b0bab016c3:	mov    DWORD PTR [rbp+0x0],r14d
    75b0bab016c7:	mov    r13d,0x11
    75b0bab016cd:	mov    QWORD PTR [r12],r13
    75b0bab016d1:	mov    r13d,0x41035c
    75b0bab016d7:	mov    QWORD PTR [r12+0xf0],r13
    75b0bab016df:	mov    r13d,0x4109a4
    75b0bab016e5:	mov    QWORD PTR [r12+0x100],r13
    75b0bab016ed:	mov    r11,QWORD PTR [rsp]
    75b0bab016f1:	mov    QWORD PTR [r12+0x398],r11
    75b0bab016f9:	mov    edi,0x4109a4
    75b0bab016fe:	mov    QWORD PTR [r12+0x100],rdi
    75b0bab01706:	add    rsp,0x10
    75b0bab0170a:	nop    WORD PTR [rax+rax*1+0x0]
    75b0bab01710:	jmp    QWORD PTR [rip+0x2]        # 0x75b0bab01718
    75b0bab01716:	xchg   ax,ax
    75b0bab01718:	rex (bad)
    75b0bab0171a:	mov    al,0xba
    75b0bab0171c:	mov    al,0x75
    75b0bab0171e:	add    BYTE PTR [rax],al
    75b0bab01720:	sub    BYTE PTR [rdi],dl
    75b0bab01722:	mov    al,0xba
    75b0bab01724:	mov    al,0x75
    75b0bab01726:	add    BYTE PTR [rax],al
    75b0bab01728:	movabs r11,0x59d8f50c0940
    75b0bab01732:	jmp    r11
    75b0bab01735:	nop
    75b0bab01736:	nop
    75b0bab01737:	nop
