
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/1/3.bin:     file format binary


Disassembly of section .data:

000075b0bab00e10 <.data>:
    75b0bab00e10:	sub    rsp,0x10
    75b0bab00e14:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab00e1c:	mov    QWORD PTR [rsp],r11
    75b0bab00e20:	mov    r13,QWORD PTR [r12+0xf8]
    75b0bab00e28:	mov    r14,r13
    75b0bab00e2b:	add    r14,0x168
    75b0bab00e32:	mov    r15,QWORD PTR [r14]
    75b0bab00e35:	mov    QWORD PTR [r12+0x40],r15
    75b0bab00e3a:	add    r13,0x178
    75b0bab00e41:	mov    r14d,0x0
    75b0bab00e47:	mov    BYTE PTR [r13+0x0],r14b
    75b0bab00e4b:	mov    r13d,0x0
    75b0bab00e51:	mov    DWORD PTR [r12+0x32c],r13d
    75b0bab00e59:	sub    r15,0x38
    75b0bab00e5d:	je     0x75b0bab00e76
    75b0bab00e63:	mov    r11,rax
    75b0bab00e66:	lahf
    75b0bab00e67:	seto   al
    75b0bab00e6a:	mov    WORD PTR [rsp],ax
    75b0bab00e6e:	mov    rax,r11
    75b0bab00e71:	jmp    0x75b0bab00e89
    75b0bab00e76:	mov    r11,rax
    75b0bab00e79:	lahf
    75b0bab00e7a:	seto   al
    75b0bab00e7d:	mov    WORD PTR [rsp],ax
    75b0bab00e81:	mov    rax,r11
    75b0bab00e84:	jmp    0x75b0bab00f15
    75b0bab00e89:	mov    r13,QWORD PTR [r12+0xf8]
    75b0bab00e91:	mov    r14,r13
    75b0bab00e94:	add    r14,0x100
    75b0bab00e9b:	mov    QWORD PTR [r12],r14
    75b0bab00e9f:	add    r13,0x178
    75b0bab00ea6:	mov    QWORD PTR [r12+0x8],r13
    75b0bab00eab:	mov    r13d,0x1
    75b0bab00eb1:	mov    QWORD PTR [r12+0x10],r13
    75b0bab00eb6:	mov    r13d,0x4102c8
    75b0bab00ebc:	mov    QWORD PTR [r12+0xf0],r13
    75b0bab00ec4:	mov    r13d,0x410728
    75b0bab00eca:	mov    QWORD PTR [r12+0x100],r13
    75b0bab00ed2:	mov    r11,QWORD PTR [rsp]
    75b0bab00ed6:	mov    QWORD PTR [r12+0x398],r11
    75b0bab00ede:	mov    edi,0x410728
    75b0bab00ee3:	mov    QWORD PTR [r12+0x100],rdi
    75b0bab00eeb:	add    rsp,0x10
    75b0bab00eef:	nop
    75b0bab00ef0:	jmp    QWORD PTR [rip+0x2]        # 0x75b0bab00ef8
    75b0bab00ef6:	xchg   ax,ax
    75b0bab00ef8:	loopne 0x75b0bab00edf
    75b0bab00efa:	scas   eax,DWORD PTR es:[rdi]
    75b0bab00efb:	mov    edx,0x75b0
    75b0bab00f00:	or     BYTE PTR [rdi],cl
    75b0bab00f02:	mov    al,0xba
    75b0bab00f04:	mov    al,0x75
    75b0bab00f06:	add    BYTE PTR [rax],al
    75b0bab00f08:	movabs r11,0x59d8f50c0940
    75b0bab00f12:	jmp    r11
    75b0bab00f15:	mov    r13,QWORD PTR [r12+0x98]
    75b0bab00f1d:	ror    r13,0x3d
    75b0bab00f21:	and    r13,0xfffffffffffffff8
    75b0bab00f25:	mov    r14,QWORD PTR [r12+0xf8]
    75b0bab00f2d:	mov    r15,r14
    75b0bab00f30:	add    r15,0x100
    75b0bab00f37:	mov    QWORD PTR [r12],r15
    75b0bab00f3b:	mov    r15,r14
    75b0bab00f3e:	add    r15,0x170
    75b0bab00f45:	mov    QWORD PTR [r12+0x8],r15
    75b0bab00f4a:	mov    r15d,0x8
    75b0bab00f50:	mov    QWORD PTR [r12+0x10],r15
    75b0bab00f55:	movabs rcx,0xff00ff00ff00ff
    75b0bab00f5f:	mov    r15,r13
    75b0bab00f62:	and    r15,rcx
    75b0bab00f65:	shl    r15,0x8
    75b0bab00f69:	movabs rcx,0xff00ff00ff00ff00
    75b0bab00f73:	and    r13,rcx
    75b0bab00f76:	shr    r13,0x8
    75b0bab00f7a:	or     r13,r15
    75b0bab00f7d:	movabs rcx,0xffff0000ffff
    75b0bab00f87:	mov    r15,r13
    75b0bab00f8a:	and    r15,rcx
    75b0bab00f8d:	shl    r15,0x10
    75b0bab00f91:	movabs rcx,0xffff0000ffff0000
    75b0bab00f9b:	and    r13,rcx
    75b0bab00f9e:	shr    r13,0x10
    75b0bab00fa2:	or     r13,r15
    75b0bab00fa5:	mov    r15,r13
    75b0bab00fa8:	shl    r15,0x20
    75b0bab00fac:	shr    r13,0x20
    75b0bab00fb0:	or     r13,r15
    75b0bab00fb3:	mov    QWORD PTR [r12+0x40],r13
    75b0bab00fb8:	add    r14,0x170
    75b0bab00fbf:	mov    QWORD PTR [r14],r13
    75b0bab00fc2:	mov    r13d,0x0
    75b0bab00fc8:	mov    DWORD PTR [r12+0x32c],r13d
    75b0bab00fd0:	mov    r13d,0x4102f0
    75b0bab00fd6:	mov    QWORD PTR [r12+0xf0],r13
    75b0bab00fde:	mov    r13d,0x410728
    75b0bab00fe4:	mov    QWORD PTR [r12+0x100],r13
    75b0bab00fec:	mov    r11,QWORD PTR [rsp]
    75b0bab00ff0:	mov    QWORD PTR [r12+0x398],r11
    75b0bab00ff8:	mov    edi,0x410728
    75b0bab00ffd:	mov    QWORD PTR [r12+0x100],rdi
    75b0bab01005:	add    rsp,0x10
    75b0bab01009:	nop    DWORD PTR [rax+0x0]
    75b0bab01010:	jmp    QWORD PTR [rip+0x2]        # 0x75b0bab01018
    75b0bab01016:	xchg   ax,ax
    75b0bab01018:	loopne 0x75b0bab00fff
    75b0bab0101a:	scas   eax,DWORD PTR es:[rdi]
    75b0bab0101b:	mov    edx,0x75b0
    75b0bab01020:	sub    BYTE PTR [rax],dl
    75b0bab01022:	mov    al,0xba
    75b0bab01024:	mov    al,0x75
    75b0bab01026:	add    BYTE PTR [rax],al
    75b0bab01028:	movabs r11,0x59d8f50c0940
    75b0bab01032:	jmp    r11
    75b0bab01035:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab01040:	sub    rsp,0x10
    75b0bab01044:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0104c:	mov    QWORD PTR [rsp],r11
    75b0bab01050:	jmp    0x75b0bab00e89
    75b0bab01055:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab01060:	sub    rsp,0x10
    75b0bab01064:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0106c:	mov    QWORD PTR [rsp],r11
    75b0bab01070:	jmp    0x75b0bab00f15
    75b0bab01075:	nop
    75b0bab01076:	nop
    75b0bab01077:	nop
