
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/0/6.bin:     file format binary


Disassembly of section .data:

000074a37e501740 <.data>:
    74a37e501740:	sub    rsp,0x10
    74a37e501744:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50174c:	mov    QWORD PTR [rsp],r11
    74a37e501750:	mov    r13d,DWORD PTR [r12]
    74a37e501754:	mov    r14d,r13d
    74a37e501757:	mov    r14d,r14d
    74a37e50175a:	shr    r14d,0x10
    74a37e50175e:	xor    r13d,r14d
    74a37e501761:	mov    QWORD PTR [r12+0x40],r13
    74a37e501766:	mov    r14d,0x352d
    74a37e50176c:	mov    QWORD PTR [r12+0x48],r14
    74a37e501771:	mov    r14d,0x352d
    74a37e501777:	mov    r15d,0x7feb
    74a37e50177d:	and    r15d,0xffff
    74a37e501784:	mov    rax,r14
    74a37e501787:	movabs rcx,0xffffffff0000ffff
    74a37e501791:	and    rax,rcx
    74a37e501794:	mov    rdx,r15
    74a37e501797:	shl    rdx,0x10
    74a37e50179b:	mov    ecx,0xffff0000
    74a37e5017a0:	and    rdx,rcx
    74a37e5017a3:	or     rax,rdx
    74a37e5017a6:	mov    ebp,eax
    74a37e5017a8:	mov    QWORD PTR [r12+0x48],rbp
    74a37e5017ad:	mov    r14d,0x0
    74a37e5017b3:	imul   r13d,ebp
    74a37e5017b7:	mov    r15d,r14d
    74a37e5017ba:	add    r15d,r13d
    74a37e5017bd:	mov    QWORD PTR [r12+0x40],r15
    74a37e5017c2:	mov    r13d,0xa68b
    74a37e5017c8:	mov    QWORD PTR [r12+0x48],r13
    74a37e5017cd:	mov    r13d,0xa68b
    74a37e5017d3:	mov    r14d,0x846c
    74a37e5017d9:	and    r14d,0xffff
    74a37e5017e0:	mov    rax,r13
    74a37e5017e3:	movabs rcx,0xffffffff0000ffff
    74a37e5017ed:	and    rax,rcx
    74a37e5017f0:	mov    rdx,r14
    74a37e5017f3:	shl    rdx,0x10
    74a37e5017f7:	mov    ecx,0xffff0000
    74a37e5017fc:	and    rdx,rcx
    74a37e5017ff:	or     rax,rdx
    74a37e501802:	mov    ebp,eax
    74a37e501804:	mov    QWORD PTR [r12+0x48],rbp
    74a37e501809:	mov    r13d,r15d
    74a37e50180c:	mov    r13d,r13d
    74a37e50180f:	shr    r13d,0xf
    74a37e501813:	xor    r15d,r13d
    74a37e501816:	mov    QWORD PTR [r12+0x40],r15
    74a37e50181b:	mov    r13d,0x0
    74a37e501821:	imul   r15d,ebp
    74a37e501825:	mov    r14d,r13d
    74a37e501828:	add    r14d,r15d
    74a37e50182b:	mov    QWORD PTR [r12+0x40],r14
    74a37e501830:	mov    r13d,r14d
    74a37e501833:	mov    r13d,r13d
    74a37e501836:	shr    r13d,0x10
    74a37e50183a:	xor    r14d,r13d
    74a37e50183d:	mov    QWORD PTR [r12],r14
    74a37e501841:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e501849:	jrcxz  0x74a37e501850
    74a37e50184b:	jmp    0x74a37e501885
    74a37e501850:	mov    r13,QWORD PTR [r12+0xf0]
    74a37e501858:	mov    QWORD PTR [r12+0x100],r13
    74a37e501860:	mov    r11,QWORD PTR [rsp]
    74a37e501864:	mov    QWORD PTR [r12+0x398],r11
    74a37e50186c:	mov    rdi,QWORD PTR [r12+0x100]
    74a37e501874:	add    rsp,0x10
    74a37e501878:	movabs r11,0x5715466e9940
    74a37e501882:	jmp    r11
    74a37e501885:	mov    eax,0x4109c8
    74a37e50188a:	mov    QWORD PTR [r12+0x100],rax
    74a37e501892:	push   rdx
    74a37e501893:	push   rsi
    74a37e501894:	push   r10
    74a37e501896:	push   r11
    74a37e501898:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50189d:	mov    r10d,edx
    74a37e5018a0:	and    r10d,0xc000
    74a37e5018a7:	shl    r10d,0x10
    74a37e5018ab:	mov    r11d,edx
    74a37e5018ae:	and    r11d,0x100
    74a37e5018b5:	shl    r11d,0x15
    74a37e5018b9:	or     r10d,r11d
    74a37e5018bc:	and    edx,0x1
    74a37e5018bf:	shl    edx,0x1c
    74a37e5018c2:	or     r10d,edx
    74a37e5018c5:	btc    r10,0x1d
    74a37e5018ca:	mov    r11d,0xf0000000
    74a37e5018d0:	and    r11,r10
    74a37e5018d3:	movabs rsi,0xffffffff0fffffff
    74a37e5018dd:	and    rbx,rsi
    74a37e5018e0:	or     rbx,r11
    74a37e5018e3:	pop    r11
    74a37e5018e5:	pop    r10
    74a37e5018e7:	pop    rsi
    74a37e5018e8:	pop    rdx
    74a37e5018e9:	mov    QWORD PTR [r12+0x108],rbx
    74a37e5018f1:	add    rsp,0x10
    74a37e5018f5:	mov    eax,0xc
    74a37e5018fa:	movabs r11,0x5715466e9ca0
    74a37e501904:	jmp    r11
    74a37e501907:	nop
