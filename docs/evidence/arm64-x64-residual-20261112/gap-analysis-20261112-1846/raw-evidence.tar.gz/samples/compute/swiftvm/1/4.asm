
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/1/4.bin:     file format binary


Disassembly of section .data:

000075b0bab01080 <.data>:
    75b0bab01080:	sub    rsp,0x10
    75b0bab01084:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0108c:	mov    QWORD PTR [rsp],r11
    75b0bab01090:	mov    r13,QWORD PTR [r12+0xf8]
    75b0bab01098:	add    r13,0x168
    75b0bab0109f:	mov    r14,QWORD PTR [r13+0x0]
    75b0bab010a3:	mov    QWORD PTR [r12+0x40],r14
    75b0bab010a8:	sub    r14,0x38
    75b0bab010ac:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab010b4:	jrcxz  0x75b0bab010bb
    75b0bab010b6:	jmp    0x75b0bab0118d
    75b0bab010bb:	jne    0x75b0bab010d4
    75b0bab010c1:	mov    r11,rax
    75b0bab010c4:	lahf
    75b0bab010c5:	seto   al
    75b0bab010c8:	mov    WORD PTR [rsp],ax
    75b0bab010cc:	mov    rax,r11
    75b0bab010cf:	jmp    0x75b0bab010e7
    75b0bab010d4:	mov    r11,rax
    75b0bab010d7:	lahf
    75b0bab010d8:	seto   al
    75b0bab010db:	mov    WORD PTR [rsp],ax
    75b0bab010df:	mov    rax,r11
    75b0bab010e2:	jmp    0x75b0bab0113d
    75b0bab010e7:	mov    r13d,0x4102d4
    75b0bab010ed:	mov    QWORD PTR [r12+0x100],r13
    75b0bab010f5:	mov    r11,QWORD PTR [rsp]
    75b0bab010f9:	mov    QWORD PTR [r12+0x398],r11
    75b0bab01101:	mov    edi,0x4102d4
    75b0bab01106:	mov    QWORD PTR [r12+0x100],rdi
    75b0bab0110e:	add    rsp,0x10
    75b0bab01112:	nop    WORD PTR [rax+rax*1+0x0]
    75b0bab01118:	jmp    QWORD PTR [rip+0x2]        # 0x75b0bab01120
    75b0bab0111e:	xchg   ax,ax
    75b0bab01120:	(bad)
    75b0bab01121:	adc    BYTE PTR [rax+0x75b0ba],dh
    75b0bab01127:	add    BYTE PTR [rax],dh
    75b0bab01129:	adc    DWORD PTR [rax+0x75b0ba],esi
    75b0bab0112f:	add    BYTE PTR [rcx-0x45],cl
    75b0bab01132:	rex or DWORD PTR [rsi*8+0x59d8],ecx
    75b0bab0113a:	jmp    r11
    75b0bab0113d:	mov    r13d,0x4102b8
    75b0bab01143:	mov    QWORD PTR [r12+0x100],r13
    75b0bab0114b:	mov    r11,QWORD PTR [rsp]
    75b0bab0114f:	mov    QWORD PTR [r12+0x398],r11
    75b0bab01157:	mov    edi,0x4102b8
    75b0bab0115c:	mov    QWORD PTR [r12+0x100],rdi
    75b0bab01164:	add    rsp,0x10
    75b0bab01168:	jmp    QWORD PTR [rip+0x2]        # 0x75b0bab01170
    75b0bab0116e:	xchg   ax,ax
    75b0bab01170:	adc    BYTE PTR [rax+0x75b0ba],sil
    75b0bab01177:	add    BYTE PTR [rax-0x4f454fef],al
    75b0bab0117d:	jne    0x75b0bab0117f
    75b0bab0117f:	add    BYTE PTR [rcx-0x45],cl
    75b0bab01182:	rex or DWORD PTR [rsi*8+0x59d8],ecx
    75b0bab0118a:	jmp    r11
    75b0bab0118d:	mov    eax,0x4102d0
    75b0bab01192:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0119a:	push   rdx
    75b0bab0119b:	push   rsi
    75b0bab0119c:	push   r10
    75b0bab0119e:	push   r11
    75b0bab011a0:	mov    r11,rax
    75b0bab011a3:	lahf
    75b0bab011a4:	seto   al
    75b0bab011a7:	mov    WORD PTR [rsp+0x20],ax
    75b0bab011ac:	mov    rax,r11
    75b0bab011af:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab011b4:	mov    r10d,edx
    75b0bab011b7:	and    r10d,0xc000
    75b0bab011be:	shl    r10d,0x10
    75b0bab011c2:	mov    r11d,edx
    75b0bab011c5:	and    r11d,0x100
    75b0bab011cc:	shl    r11d,0x15
    75b0bab011d0:	or     r10d,r11d
    75b0bab011d3:	and    edx,0x1
    75b0bab011d6:	shl    edx,0x1c
    75b0bab011d9:	or     r10d,edx
    75b0bab011dc:	btc    r10,0x1d
    75b0bab011e1:	mov    r11d,0xf0000000
    75b0bab011e7:	and    r11,r10
    75b0bab011ea:	movabs rsi,0xffffffff0fffffff
    75b0bab011f4:	and    rbx,rsi
    75b0bab011f7:	or     rbx,r11
    75b0bab011fa:	pop    r11
    75b0bab011fc:	pop    r10
    75b0bab011fe:	pop    rsi
    75b0bab011ff:	pop    rdx
    75b0bab01200:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab01208:	add    rsp,0x10
    75b0bab0120c:	mov    eax,0xc
    75b0bab01211:	movabs r11,0x59d8f50c0ca0
    75b0bab0121b:	jmp    r11
    75b0bab0121e:	nop
    75b0bab0121f:	nop
