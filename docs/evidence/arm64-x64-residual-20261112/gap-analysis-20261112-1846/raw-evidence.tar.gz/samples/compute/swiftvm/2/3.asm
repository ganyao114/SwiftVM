
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/2/3.bin:     file format binary


Disassembly of section .data:

00007f716edffe10 <.data>:
    7f716edffe10:	sub    rsp,0x10
    7f716edffe14:	mov    r11,QWORD PTR [r12+0x398]
    7f716edffe1c:	mov    QWORD PTR [rsp],r11
    7f716edffe20:	mov    r13,QWORD PTR [r12+0xf8]
    7f716edffe28:	mov    r14,r13
    7f716edffe2b:	add    r14,0x168
    7f716edffe32:	mov    r15,QWORD PTR [r14]
    7f716edffe35:	mov    QWORD PTR [r12+0x40],r15
    7f716edffe3a:	add    r13,0x178
    7f716edffe41:	mov    r14d,0x0
    7f716edffe47:	mov    BYTE PTR [r13+0x0],r14b
    7f716edffe4b:	mov    r13d,0x0
    7f716edffe51:	mov    DWORD PTR [r12+0x32c],r13d
    7f716edffe59:	sub    r15,0x38
    7f716edffe5d:	je     0x7f716edffe76
    7f716edffe63:	mov    r11,rax
    7f716edffe66:	lahf
    7f716edffe67:	seto   al
    7f716edffe6a:	mov    WORD PTR [rsp],ax
    7f716edffe6e:	mov    rax,r11
    7f716edffe71:	jmp    0x7f716edffe89
    7f716edffe76:	mov    r11,rax
    7f716edffe79:	lahf
    7f716edffe7a:	seto   al
    7f716edffe7d:	mov    WORD PTR [rsp],ax
    7f716edffe81:	mov    rax,r11
    7f716edffe84:	jmp    0x7f716edfff15
    7f716edffe89:	mov    r13,QWORD PTR [r12+0xf8]
    7f716edffe91:	mov    r14,r13
    7f716edffe94:	add    r14,0x100
    7f716edffe9b:	mov    QWORD PTR [r12],r14
    7f716edffe9f:	add    r13,0x178
    7f716edffea6:	mov    QWORD PTR [r12+0x8],r13
    7f716edffeab:	mov    r13d,0x1
    7f716edffeb1:	mov    QWORD PTR [r12+0x10],r13
    7f716edffeb6:	mov    r13d,0x4102c8
    7f716edffebc:	mov    QWORD PTR [r12+0xf0],r13
    7f716edffec4:	mov    r13d,0x410728
    7f716edffeca:	mov    QWORD PTR [r12+0x100],r13
    7f716edffed2:	mov    r11,QWORD PTR [rsp]
    7f716edffed6:	mov    QWORD PTR [r12+0x398],r11
    7f716edffede:	mov    edi,0x410728
    7f716edffee3:	mov    QWORD PTR [r12+0x100],rdi
    7f716edffeeb:	add    rsp,0x10
    7f716edffeef:	nop
    7f716edffef0:	jmp    QWORD PTR [rip+0x2]        # 0x7f716edffef8
    7f716edffef6:	xchg   ax,ax
    7f716edffef8:	loopne 0x7f716edffecf
    7f716edffefa:	fild   QWORD PTR [rsi+0x71]
    7f716edffefd:	jg     0x7f716edffeff
    7f716edffeff:	add    BYTE PTR [rax],cl
    7f716edfff01:	call   (bad)
    7f716edfff02:	fild   QWORD PTR [rsi+0x71]
    7f716edfff05:	jg     0x7f716edfff07
    7f716edfff07:	add    BYTE PTR [rcx-0x45],cl
    7f716edfff0a:	rex jns 0x7f716edffecc
    7f716edfff0d:	mov    eax,0x5fdf
    7f716edfff12:	jmp    r11
    7f716edfff15:	mov    r13,QWORD PTR [r12+0x98]
    7f716edfff1d:	ror    r13,0x3d
    7f716edfff21:	and    r13,0xfffffffffffffff8
    7f716edfff25:	mov    r14,QWORD PTR [r12+0xf8]
    7f716edfff2d:	mov    r15,r14
    7f716edfff30:	add    r15,0x100
    7f716edfff37:	mov    QWORD PTR [r12],r15
    7f716edfff3b:	mov    r15,r14
    7f716edfff3e:	add    r15,0x170
    7f716edfff45:	mov    QWORD PTR [r12+0x8],r15
    7f716edfff4a:	mov    r15d,0x8
    7f716edfff50:	mov    QWORD PTR [r12+0x10],r15
    7f716edfff55:	movabs rcx,0xff00ff00ff00ff
    7f716edfff5f:	mov    r15,r13
    7f716edfff62:	and    r15,rcx
    7f716edfff65:	shl    r15,0x8
    7f716edfff69:	movabs rcx,0xff00ff00ff00ff00
    7f716edfff73:	and    r13,rcx
    7f716edfff76:	shr    r13,0x8
    7f716edfff7a:	or     r13,r15
    7f716edfff7d:	movabs rcx,0xffff0000ffff
    7f716edfff87:	mov    r15,r13
    7f716edfff8a:	and    r15,rcx
    7f716edfff8d:	shl    r15,0x10
    7f716edfff91:	movabs rcx,0xffff0000ffff0000
    7f716edfff9b:	and    r13,rcx
    7f716edfff9e:	shr    r13,0x10
    7f716edfffa2:	or     r13,r15
    7f716edfffa5:	mov    r15,r13
    7f716edfffa8:	shl    r15,0x20
    7f716edfffac:	shr    r13,0x20
    7f716edfffb0:	or     r13,r15
    7f716edfffb3:	mov    QWORD PTR [r12+0x40],r13
    7f716edfffb8:	add    r14,0x170
    7f716edfffbf:	mov    QWORD PTR [r14],r13
    7f716edfffc2:	mov    r13d,0x0
    7f716edfffc8:	mov    DWORD PTR [r12+0x32c],r13d
    7f716edfffd0:	mov    r13d,0x4102f0
    7f716edfffd6:	mov    QWORD PTR [r12+0xf0],r13
    7f716edfffde:	mov    r13d,0x410728
    7f716edfffe4:	mov    QWORD PTR [r12+0x100],r13
    7f716edfffec:	mov    r11,QWORD PTR [rsp]
    7f716edffff0:	mov    QWORD PTR [r12+0x398],r11
    7f716edffff8:	mov    edi,0x410728
    7f716edffffd:	mov    QWORD PTR [r12+0x100],rdi
    7f716ee00005:	add    rsp,0x10
    7f716ee00009:	nop    DWORD PTR [rax+0x0]
    7f716ee00010:	jmp    QWORD PTR [rip+0x2]        # 0x7f716ee00018
    7f716ee00016:	xchg   ax,ax
    7f716ee00018:	loopne 0x7f716edfffef
    7f716ee0001a:	fild   QWORD PTR [rsi+0x71]
    7f716ee0001d:	jg     0x7f716ee0001f
    7f716ee0001f:	add    BYTE PTR [rax],ch
    7f716ee00021:	add    al,ah
    7f716ee00023:	outs   dx,BYTE PTR ds:[rsi]
    7f716ee00024:	jno    0x7f716ee000a5
    7f716ee00026:	add    BYTE PTR [rax],al
    7f716ee00028:	movabs r11,0x5fdfb8bf7940
    7f716ee00032:	jmp    r11
    7f716ee00035:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee00040:	sub    rsp,0x10
    7f716ee00044:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0004c:	mov    QWORD PTR [rsp],r11
    7f716ee00050:	jmp    0x7f716edffe89
    7f716ee00055:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee00060:	sub    rsp,0x10
    7f716ee00064:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0006c:	mov    QWORD PTR [rsp],r11
    7f716ee00070:	jmp    0x7f716edfff15
    7f716ee00075:	nop
    7f716ee00076:	nop
    7f716ee00077:	nop
