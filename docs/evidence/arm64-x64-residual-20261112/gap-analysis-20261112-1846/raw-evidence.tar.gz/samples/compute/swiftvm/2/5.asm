
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/2/5.bin:     file format binary


Disassembly of section .data:

00007f716ee00220 <.data>:
    7f716ee00220:	sub    rsp,0x10
    7f716ee00224:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0022c:	mov    QWORD PTR [rsp],r11
    7f716ee00230:	mov    rax,QWORD PTR [r12+0xf8]
    7f716ee00238:	mov    r14,QWORD PTR [r12+0xf8]
    7f716ee00240:	add    r14,0x100
    7f716ee00247:	mov    r15d,DWORD PTR [r14]
    7f716ee0024a:	mov    QWORD PTR [r12+0x40],r15
    7f716ee0024f:	mov    r14,QWORD PTR [r12+0xf8]
    7f716ee00257:	add    r14,0x104
    7f716ee0025e:	mov    ebp,DWORD PTR [r14]
    7f716ee00261:	mov    QWORD PTR [r12+0x50],rbp
    7f716ee00266:	mov    r14d,0x430c90
    7f716ee0026c:	mov    QWORD PTR [r12+0x48],r14
    7f716ee00271:	mov    r14,QWORD PTR [r12+0xf8]
    7f716ee00279:	add    r14,0x108
    7f716ee00280:	mov    r8d,DWORD PTR [r14]
    7f716ee00283:	mov    QWORD PTR [r12+0x58],r8
    7f716ee00288:	mov    r14,QWORD PTR [r12+0xf8]
    7f716ee00290:	add    r14,0x10c
    7f716ee00297:	mov    eax,DWORD PTR [r14]
    7f716ee0029a:	mov    QWORD PTR [r12+0x60],rax
    7f716ee0029f:	movabs rcx,0xff00ff00ff00ff
    7f716ee002a9:	mov    r14,r15
    7f716ee002ac:	and    r14,rcx
    7f716ee002af:	shl    r14,0x8
    7f716ee002b3:	movabs rcx,0xff00ff00ff00ff00
    7f716ee002bd:	mov    r13,r15
    7f716ee002c0:	and    r13,rcx
    7f716ee002c3:	shr    r13,0x8
    7f716ee002c7:	or     r13,r14
    7f716ee002ca:	movabs rcx,0xffff0000ffff
    7f716ee002d4:	mov    r14,r13
    7f716ee002d7:	and    r14,rcx
    7f716ee002da:	shl    r14,0x10
    7f716ee002de:	movabs rcx,0xffff0000ffff0000
    7f716ee002e8:	and    r13,rcx
    7f716ee002eb:	shr    r13,0x10
    7f716ee002ef:	or     r13,r14
    7f716ee002f2:	mov    ecx,0xffffffff
    7f716ee002f7:	and    r13,rcx
    7f716ee002fa:	mov    QWORD PTR [r12+0x40],r13
    7f716ee002ff:	movabs rcx,0xff00ff00ff00ff
    7f716ee00309:	mov    r14,rbp
    7f716ee0030c:	and    r14,rcx
    7f716ee0030f:	shl    r14,0x8
    7f716ee00313:	movabs rcx,0xff00ff00ff00ff00
    7f716ee0031d:	mov    r15,rbp
    7f716ee00320:	and    r15,rcx
    7f716ee00323:	shr    r15,0x8
    7f716ee00327:	or     r15,r14
    7f716ee0032a:	movabs rcx,0xffff0000ffff
    7f716ee00334:	mov    r14,r15
    7f716ee00337:	and    r14,rcx
    7f716ee0033a:	shl    r14,0x10
    7f716ee0033e:	movabs rcx,0xffff0000ffff0000
    7f716ee00348:	and    r15,rcx
    7f716ee0034b:	shr    r15,0x10
    7f716ee0034f:	or     r15,r14
    7f716ee00352:	mov    ecx,0xffffffff
    7f716ee00357:	and    r15,rcx
    7f716ee0035a:	mov    QWORD PTR [r12+0x50],r15
    7f716ee0035f:	mov    r14d,0x0
    7f716ee00365:	mov    QWORD PTR [r12+0xa0],r14
    7f716ee0036d:	mov    r14d,0x430c90
    7f716ee00373:	mov    ebp,0x430c94
    7f716ee00378:	mov    rax,r13
    7f716ee0037b:	mov    eax,eax
    7f716ee0037d:	mov    r9d,eax
    7f716ee00380:	mov    rax,r15
    7f716ee00383:	mov    eax,eax
    7f716ee00385:	mov    r13d,eax
    7f716ee00388:	mov    DWORD PTR [r14],r9d
    7f716ee0038b:	mov    r14d,0x0
    7f716ee00391:	mov    DWORD PTR [r12+0x32c],r14d
    7f716ee00399:	mov    DWORD PTR [rbp+0x0],r13d
    7f716ee0039d:	movabs rcx,0xff00ff00ff00ff
    7f716ee003a7:	mov    r13,r8
    7f716ee003aa:	and    r13,rcx
    7f716ee003ad:	shl    r13,0x8
    7f716ee003b1:	movabs rcx,0xff00ff00ff00ff00
    7f716ee003bb:	mov    r14,r8
    7f716ee003be:	and    r14,rcx
    7f716ee003c1:	shr    r14,0x8
    7f716ee003c5:	or     r14,r13
    7f716ee003c8:	movabs rcx,0xffff0000ffff
    7f716ee003d2:	mov    r13,r14
    7f716ee003d5:	and    r13,rcx
    7f716ee003d8:	shl    r13,0x10
    7f716ee003dc:	movabs rcx,0xffff0000ffff0000
    7f716ee003e6:	and    r14,rcx
    7f716ee003e9:	shr    r14,0x10
    7f716ee003ed:	or     r14,r13
    7f716ee003f0:	mov    ecx,0xffffffff
    7f716ee003f5:	and    r14,rcx
    7f716ee003f8:	mov    QWORD PTR [r12+0x40],r14
    7f716ee003fd:	mov    r13,QWORD PTR [r12+0xf8]
    7f716ee00405:	add    r13,0x110
    7f716ee0040c:	mov    r15d,DWORD PTR [r13+0x0]
    7f716ee00410:	mov    QWORD PTR [r12+0x50],r15
    7f716ee00415:	movabs rcx,0xff00ff00ff00ff
    7f716ee0041f:	mov    r13d,DWORD PTR [r12+0x60]
    7f716ee00424:	and    r13,rcx
    7f716ee00427:	shl    r13,0x8
    7f716ee0042b:	movabs rcx,0xff00ff00ff00ff00
    7f716ee00435:	mov    ebp,DWORD PTR [r12+0x60]
    7f716ee0043a:	and    rbp,rcx
    7f716ee0043d:	shr    rbp,0x8
    7f716ee00441:	or     rbp,r13
    7f716ee00444:	movabs rcx,0xffff0000ffff
    7f716ee0044e:	mov    r13,rbp
    7f716ee00451:	and    r13,rcx
    7f716ee00454:	shl    r13,0x10
    7f716ee00458:	movabs rcx,0xffff0000ffff0000
    7f716ee00462:	and    rbp,rcx
    7f716ee00465:	shr    rbp,0x10
    7f716ee00469:	or     rbp,r13
    7f716ee0046c:	mov    ecx,0xffffffff
    7f716ee00471:	and    rbp,rcx
    7f716ee00474:	mov    QWORD PTR [r12+0x58],rbp
    7f716ee00479:	mov    r13,QWORD PTR [r12+0xf8]
    7f716ee00481:	add    r13,0x114
    7f716ee00488:	mov    eax,DWORD PTR [r13+0x0]
    7f716ee0048c:	mov    QWORD PTR [r12+0x60],rax
    7f716ee00491:	mov    r13d,0x430000
    7f716ee00497:	add    r13,0xdfc
    7f716ee0049e:	mov    QWORD PTR [r12+0x98],r13
    7f716ee004a6:	mov    r13d,0x430c98
    7f716ee004ac:	mov    r9d,0x430c9c
    7f716ee004b2:	mov    rax,r14
    7f716ee004b5:	mov    eax,eax
    7f716ee004b7:	mov    r8d,eax
    7f716ee004ba:	mov    rax,rbp
    7f716ee004bd:	mov    eax,eax
    7f716ee004bf:	mov    r14d,eax
    7f716ee004c2:	mov    DWORD PTR [r13+0x0],r8d
    7f716ee004c6:	mov    DWORD PTR [r9],r14d
    7f716ee004c9:	movabs rcx,0xff00ff00ff00ff
    7f716ee004d3:	mov    r13,r15
    7f716ee004d6:	and    r13,rcx
    7f716ee004d9:	shl    r13,0x8
    7f716ee004dd:	movabs rcx,0xff00ff00ff00ff00
    7f716ee004e7:	mov    r14,r15
    7f716ee004ea:	and    r14,rcx
    7f716ee004ed:	shr    r14,0x8
    7f716ee004f1:	or     r14,r13
    7f716ee004f4:	movabs rcx,0xffff0000ffff
    7f716ee004fe:	mov    r13,r14
    7f716ee00501:	and    r13,rcx
    7f716ee00504:	shl    r13,0x10
    7f716ee00508:	movabs rcx,0xffff0000ffff0000
    7f716ee00512:	and    r14,rcx
    7f716ee00515:	shr    r14,0x10
    7f716ee00519:	or     r14,r13
    7f716ee0051c:	mov    ecx,0xffffffff
    7f716ee00521:	and    r14,rcx
    7f716ee00524:	mov    QWORD PTR [r12+0x40],r14
    7f716ee00529:	mov    r13,QWORD PTR [r12+0xf8]
    7f716ee00531:	add    r13,0x118
    7f716ee00538:	mov    r15d,DWORD PTR [r13+0x0]
    7f716ee0053c:	mov    QWORD PTR [r12+0x50],r15
    7f716ee00541:	movabs rcx,0xff00ff00ff00ff
    7f716ee0054b:	mov    r13d,DWORD PTR [r12+0x60]
    7f716ee00550:	and    r13,rcx
    7f716ee00553:	shl    r13,0x8
    7f716ee00557:	movabs rcx,0xff00ff00ff00ff00
    7f716ee00561:	mov    ebp,DWORD PTR [r12+0x60]
    7f716ee00566:	and    rbp,rcx
    7f716ee00569:	shr    rbp,0x8
    7f716ee0056d:	or     rbp,r13
    7f716ee00570:	movabs rcx,0xffff0000ffff
    7f716ee0057a:	mov    r13,rbp
    7f716ee0057d:	and    r13,rcx
    7f716ee00580:	shl    r13,0x10
    7f716ee00584:	movabs rcx,0xffff0000ffff0000
    7f716ee0058e:	and    rbp,rcx
    7f716ee00591:	shr    rbp,0x10
    7f716ee00595:	or     rbp,r13
    7f716ee00598:	mov    ecx,0xffffffff
    7f716ee0059d:	and    rbp,rcx
    7f716ee005a0:	mov    QWORD PTR [r12+0x58],rbp
    7f716ee005a5:	mov    r13,QWORD PTR [r12+0xf8]
    7f716ee005ad:	add    r13,0x11c
    7f716ee005b4:	mov    eax,DWORD PTR [r13+0x0]
    7f716ee005b8:	mov    QWORD PTR [r12+0x60],rax
    7f716ee005bd:	mov    r13d,0x430ca0
    7f716ee005c3:	mov    r9d,0x430ca4
    7f716ee005c9:	mov    rax,r14
    7f716ee005cc:	mov    eax,eax
    7f716ee005ce:	mov    r8d,eax
    7f716ee005d1:	mov    rax,rbp
    7f716ee005d4:	mov    eax,eax
    7f716ee005d6:	mov    r14d,eax
    7f716ee005d9:	mov    DWORD PTR [r13+0x0],r8d
    7f716ee005dd:	mov    DWORD PTR [r9],r14d
    7f716ee005e0:	movabs rcx,0xff00ff00ff00ff
    7f716ee005ea:	mov    r13,r15
    7f716ee005ed:	and    r13,rcx
    7f716ee005f0:	shl    r13,0x8
    7f716ee005f4:	movabs rcx,0xff00ff00ff00ff00
    7f716ee005fe:	mov    r14,r15
    7f716ee00601:	and    r14,rcx
    7f716ee00604:	shr    r14,0x8
    7f716ee00608:	or     r14,r13
    7f716ee0060b:	movabs rcx,0xffff0000ffff
    7f716ee00615:	mov    r13,r14
    7f716ee00618:	and    r13,rcx
    7f716ee0061b:	shl    r13,0x10
    7f716ee0061f:	movabs rcx,0xffff0000ffff0000
    7f716ee00629:	and    r14,rcx
    7f716ee0062c:	shr    r14,0x10
    7f716ee00630:	or     r14,r13
    7f716ee00633:	mov    ecx,0xffffffff
    7f716ee00638:	and    r14,rcx
    7f716ee0063b:	mov    QWORD PTR [r12+0x40],r14
    7f716ee00640:	movabs rcx,0xff00ff00ff00ff
    7f716ee0064a:	mov    r13d,DWORD PTR [r12+0x60]
    7f716ee0064f:	and    r13,rcx
    7f716ee00652:	shl    r13,0x8
    7f716ee00656:	movabs rcx,0xff00ff00ff00ff00
    7f716ee00660:	mov    r15d,DWORD PTR [r12+0x60]
    7f716ee00665:	and    r15,rcx
    7f716ee00668:	shr    r15,0x8
    7f716ee0066c:	or     r15,r13
    7f716ee0066f:	movabs rcx,0xffff0000ffff
    7f716ee00679:	mov    r13,r15
    7f716ee0067c:	and    r13,rcx
    7f716ee0067f:	shl    r13,0x10
    7f716ee00683:	movabs rcx,0xffff0000ffff0000
    7f716ee0068d:	and    r15,rcx
    7f716ee00690:	shr    r15,0x10
    7f716ee00694:	or     r15,r13
    7f716ee00697:	mov    ecx,0xffffffff
    7f716ee0069c:	and    r15,rcx
    7f716ee0069f:	mov    QWORD PTR [r12+0x50],r15
    7f716ee006a4:	mov    r13d,0x430ca8
    7f716ee006aa:	mov    ebp,0x430cac
    7f716ee006af:	mov    rax,r14
    7f716ee006b2:	mov    eax,eax
    7f716ee006b4:	mov    r8d,eax
    7f716ee006b7:	mov    rax,r15
    7f716ee006ba:	mov    eax,eax
    7f716ee006bc:	mov    r14d,eax
    7f716ee006bf:	mov    DWORD PTR [r13+0x0],r8d
    7f716ee006c3:	mov    DWORD PTR [rbp+0x0],r14d
    7f716ee006c7:	mov    r13d,0x11
    7f716ee006cd:	mov    QWORD PTR [r12],r13
    7f716ee006d1:	mov    r13d,0x41035c
    7f716ee006d7:	mov    QWORD PTR [r12+0xf0],r13
    7f716ee006df:	mov    r13d,0x4109a4
    7f716ee006e5:	mov    QWORD PTR [r12+0x100],r13
    7f716ee006ed:	mov    r11,QWORD PTR [rsp]
    7f716ee006f1:	mov    QWORD PTR [r12+0x398],r11
    7f716ee006f9:	mov    edi,0x4109a4
    7f716ee006fe:	mov    QWORD PTR [r12+0x100],rdi
    7f716ee00706:	add    rsp,0x10
    7f716ee0070a:	nop    WORD PTR [rax+rax*1+0x0]
    7f716ee00710:	jmp    QWORD PTR [rip+0x2]        # 0x7f716ee00718
    7f716ee00716:	xchg   ax,ax
    7f716ee00718:	rex (bad)
    7f716ee0071a:	loopne 0x7f716ee0078a
    7f716ee0071c:	jno    0x7f716ee0079d
    7f716ee0071e:	add    BYTE PTR [rax],al
    7f716ee00720:	sub    BYTE PTR [rdi],al
    7f716ee00722:	loopne 0x7f716ee00792
    7f716ee00724:	jno    0x7f716ee007a5
    7f716ee00726:	add    BYTE PTR [rax],al
    7f716ee00728:	movabs r11,0x5fdfb8bf7940
    7f716ee00732:	jmp    r11
    7f716ee00735:	nop
    7f716ee00736:	nop
    7f716ee00737:	nop
