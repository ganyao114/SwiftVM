
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/2/7.bin:     file format binary


Disassembly of section .data:

00007f716ee00910 <.data>:
    7f716ee00910:	sub    rsp,0x10
    7f716ee00914:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0091c:	mov    QWORD PTR [rsp],r11
    7f716ee00920:	mov    r13,QWORD PTR [r12+0xa0]
    7f716ee00928:	mov    r14,r13
    7f716ee0092b:	shl    r14,0x2
    7f716ee0092f:	mov    r15,QWORD PTR [r12+0x98]
    7f716ee00937:	add    r15,r14
    7f716ee0093a:	mov    r14d,DWORD PTR [r12]
    7f716ee0093e:	mov    DWORD PTR [r15],r14d
    7f716ee00941:	mov    r14d,0x0
    7f716ee00947:	mov    DWORD PTR [r12+0x32c],r14d
    7f716ee0094f:	add    r13,0x1
    7f716ee00953:	mov    QWORD PTR [r12+0xa0],r13
    7f716ee0095b:	sub    r13,0x400
    7f716ee00962:	mov    rcx,QWORD PTR [r12+0x380]
    7f716ee0096a:	jrcxz  0x7f716ee00971
    7f716ee0096c:	jmp    0x7f716ee00d4d
    7f716ee00971:	jne    0x7f716ee0098a
    7f716ee00977:	mov    r11,rax
    7f716ee0097a:	lahf
    7f716ee0097b:	seto   al
    7f716ee0097e:	mov    WORD PTR [rsp],ax
    7f716ee00982:	mov    rax,r11
    7f716ee00985:	jmp    0x7f716ee0099d
    7f716ee0098a:	mov    r11,rax
    7f716ee0098d:	lahf
    7f716ee0098e:	seto   al
    7f716ee00991:	mov    WORD PTR [rsp],ax
    7f716ee00995:	mov    rax,r11
    7f716ee00998:	jmp    0x7f716ee00cdd
    7f716ee0099d:	mov    r13d,0x1
    7f716ee009a3:	mov    QWORD PTR [r12+0x40],r13
    7f716ee009a8:	mov    r11,rax
    7f716ee009ab:	movzx  eax,WORD PTR [rsp]
    7f716ee009af:	add    al,0x7f
    7f716ee009b1:	sahf
    7f716ee009b2:	mov    rax,r11
    7f716ee009b5:	jmp    0x7f716ee009ba
    7f716ee009ba:	mov    r13,QWORD PTR [r12+0x40]
    7f716ee009bf:	mov    r14,r13
    7f716ee009c2:	lea    r14,[r14*4+0x0]
    7f716ee009ca:	mov    r15,QWORD PTR [r12+0x98]
    7f716ee009d2:	mov    r11,rax
    7f716ee009d5:	lahf
    7f716ee009d6:	seto   al
    7f716ee009d9:	mov    WORD PTR [rsp],ax
    7f716ee009dd:	mov    rax,r11
    7f716ee009e0:	add    r15,r14
    7f716ee009e3:	mov    r14d,DWORD PTR [r15]
    7f716ee009e6:	mov    QWORD PTR [r12+0x48],r14
    7f716ee009eb:	mov    r14d,0x0
    7f716ee009f1:	or     r14,r13
    7f716ee009f4:	mov    QWORD PTR [r12+0x50],r14
    7f716ee009f9:	jmp    0x7f716ee009fe
    7f716ee009fe:	mov    r13d,DWORD PTR [r12+0x50]
    7f716ee00a03:	sub    r13d,0x1
    7f716ee00a07:	mov    QWORD PTR [r12+0x58],r13
    7f716ee00a0c:	mov    ecx,0xffffffff
    7f716ee00a11:	mov    r14,r13
    7f716ee00a14:	and    r14,rcx
    7f716ee00a17:	shl    r14,0x2
    7f716ee00a1b:	mov    r13,QWORD PTR [r12+0x98]
    7f716ee00a23:	add    r13,r14
    7f716ee00a26:	mov    r14d,DWORD PTR [r13+0x0]
    7f716ee00a2a:	mov    QWORD PTR [r12+0x60],r14
    7f716ee00a2f:	mov    r13d,DWORD PTR [r12+0x48]
    7f716ee00a34:	sub    r14d,r13d
    7f716ee00a37:	mov    rcx,QWORD PTR [r12+0x380]
    7f716ee00a3f:	jrcxz  0x7f716ee00a46
    7f716ee00a41:	jmp    0x7f716ee00dde
    7f716ee00a46:	jbe    0x7f716ee00a5f
    7f716ee00a4c:	mov    r11,rax
    7f716ee00a4f:	lahf
    7f716ee00a50:	seto   al
    7f716ee00a53:	mov    WORD PTR [rsp],ax
    7f716ee00a57:	mov    rax,r11
    7f716ee00a5a:	jmp    0x7f716ee00a72
    7f716ee00a5f:	mov    r11,rax
    7f716ee00a62:	lahf
    7f716ee00a63:	seto   al
    7f716ee00a66:	mov    WORD PTR [rsp],ax
    7f716ee00a6a:	mov    rax,r11
    7f716ee00a6d:	jmp    0x7f716ee00af1
    7f716ee00a72:	mov    r13,QWORD PTR [r12+0x50]
    7f716ee00a77:	mov    r14,r13
    7f716ee00a7a:	shl    r14,0x2
    7f716ee00a7e:	mov    r15,QWORD PTR [r12+0x98]
    7f716ee00a86:	add    r15,r14
    7f716ee00a89:	mov    r14d,DWORD PTR [r12+0x60]
    7f716ee00a8e:	mov    DWORD PTR [r15],r14d
    7f716ee00a91:	mov    r14d,0x0
    7f716ee00a97:	mov    DWORD PTR [r12+0x32c],r14d
    7f716ee00a9f:	sub    r13,0x1
    7f716ee00aa3:	mov    QWORD PTR [r12+0x50],r13
    7f716ee00aa8:	mov    rcx,QWORD PTR [r12+0x380]
    7f716ee00ab0:	jrcxz  0x7f716ee00ab7
    7f716ee00ab2:	jmp    0x7f716ee00e6f
    7f716ee00ab7:	mov    r13,QWORD PTR [r12+0x58]
    7f716ee00abc:	mov    rax,r13
    7f716ee00abf:	test   rax,rax
    7f716ee00ac2:	jne    0x7f716ee009fe
    7f716ee00ac8:	jmp    0x7f716ee00acd
    7f716ee00acd:	mov    rcx,QWORD PTR [r12+0x380]
    7f716ee00ad5:	jrcxz  0x7f716ee00adc
    7f716ee00ad7:	jmp    0x7f716ee00ef1
    7f716ee00adc:	jmp    0x7f716ee00ae1
    7f716ee00ae1:	mov    r13d,0x0
    7f716ee00ae7:	mov    QWORD PTR [r12+0x50],r13
    7f716ee00aec:	jmp    0x7f716ee00af1
    7f716ee00af1:	mov    r13,QWORD PTR [r12+0x40]
    7f716ee00af6:	add    r13,0x1
    7f716ee00afa:	mov    QWORD PTR [r12+0x40],r13
    7f716ee00aff:	mov    r14,QWORD PTR [r12+0x50]
    7f716ee00b04:	mov    ecx,0xffffffff
    7f716ee00b09:	and    r14,rcx
    7f716ee00b0c:	shl    r14,0x2
    7f716ee00b10:	mov    r15,QWORD PTR [r12+0x98]
    7f716ee00b18:	add    r15,r14
    7f716ee00b1b:	mov    r14d,DWORD PTR [r12+0x48]
    7f716ee00b20:	mov    DWORD PTR [r15],r14d
    7f716ee00b23:	mov    r14d,0x0
    7f716ee00b29:	mov    DWORD PTR [r12+0x32c],r14d
    7f716ee00b31:	sub    r13,0x400
    7f716ee00b38:	jne    0x7f716ee009ba
    7f716ee00b3e:	mov    r11,rax
    7f716ee00b41:	lahf
    7f716ee00b42:	seto   al
    7f716ee00b45:	mov    WORD PTR [rsp],ax
    7f716ee00b49:	mov    rax,r11
    7f716ee00b4c:	jmp    0x7f716ee00b51
    7f716ee00b51:	mov    r13d,0x430000
    7f716ee00b57:	mov    QWORD PTR [r12+0x40],r13
    7f716ee00b5c:	mov    r13d,0x0
    7f716ee00b62:	mov    QWORD PTR [r12+0x58],r13
    7f716ee00b67:	mov    r13d,0x0
    7f716ee00b6d:	mov    QWORD PTR [r12+0x50],r13
    7f716ee00b72:	mov    r13d,0x430cb0
    7f716ee00b78:	mov    r14,QWORD PTR [r13+0x0]
    7f716ee00b7c:	mov    QWORD PTR [r12+0x48],r14
    7f716ee00b81:	jmp    0x7f716ee00b86
    7f716ee00b86:	mov    r13,QWORD PTR [r12+0x58]
    7f716ee00b8b:	mov    r14,r13
    7f716ee00b8e:	shl    r14,0x2
    7f716ee00b92:	mov    r15,QWORD PTR [r12+0x98]
    7f716ee00b9a:	add    r15,r14
    7f716ee00b9d:	mov    QWORD PTR [r12+0x60],r15
    7f716ee00ba2:	mov    r14,r15
    7f716ee00ba5:	add    r14,0x4
    7f716ee00ba9:	mov    ebp,DWORD PTR [r15]
    7f716ee00bac:	mov    r15d,DWORD PTR [r14]
    7f716ee00baf:	mov    QWORD PTR [r12+0x60],r15
    7f716ee00bb4:	mov    r14,rbp
    7f716ee00bb7:	imul   r14,r13
    7f716ee00bbb:	mov    r8,rbp
    7f716ee00bbe:	add    r8,r14
    7f716ee00bc1:	mov    QWORD PTR [r12+0x68],r8
    7f716ee00bc6:	add    r13,0x2
    7f716ee00bca:	mov    QWORD PTR [r12+0x58],r13
    7f716ee00bcf:	mov    r14,r13
    7f716ee00bd2:	sub    r14,0x400
    7f716ee00bd9:	mov    r14,QWORD PTR [r12+0x50]
    7f716ee00bde:	setne  BYTE PTR [rsp+0x8]
    7f716ee00be3:	mov    r11,rax
    7f716ee00be6:	lahf
    7f716ee00be7:	seto   al
    7f716ee00bea:	mov    WORD PTR [rsp],ax
    7f716ee00bee:	mov    rax,r11
    7f716ee00bf1:	imul   r13,r15
    7f716ee00bf5:	add    r14,r13
    7f716ee00bf8:	mov    QWORD PTR [r12+0x50],r14
    7f716ee00bfd:	mov    r13,QWORD PTR [r12+0x48]
    7f716ee00c02:	add    r8,r13
    7f716ee00c05:	mov    QWORD PTR [r12+0x48],r8
    7f716ee00c0a:	mov    rcx,QWORD PTR [r12+0x380]
    7f716ee00c12:	jrcxz  0x7f716ee00c19
    7f716ee00c14:	jmp    0x7f716ee00f73
    7f716ee00c19:	cmp    BYTE PTR [rsp+0x8],0x0
    7f716ee00c1e:	jne    0x7f716ee00b86
    7f716ee00c24:	jmp    0x7f716ee00c29
    7f716ee00c29:	mov    r13d,0x0
    7f716ee00c2f:	mov    QWORD PTR [r12+0x98],r13
    7f716ee00c37:	mov    r13,QWORD PTR [r12+0x48]
    7f716ee00c3c:	mov    r14,QWORD PTR [r12+0x50]
    7f716ee00c41:	add    r14,r13
    7f716ee00c44:	mov    QWORD PTR [r12+0x48],r14
    7f716ee00c49:	mov    r13d,0x1
    7f716ee00c4f:	mov    QWORD PTR [r12],r13
    7f716ee00c53:	mov    r13,QWORD PTR [r12+0x40]
    7f716ee00c58:	add    r13,0xcb0
    7f716ee00c5f:	mov    QWORD PTR [r13+0x0],r14
    7f716ee00c63:	mov    r13d,0x0
    7f716ee00c69:	mov    DWORD PTR [r12+0x32c],r13d
    7f716ee00c71:	mov    r13d,0x1
    7f716ee00c77:	mov    QWORD PTR [r12],r13
    7f716ee00c7b:	mov    r13d,0x4103f8
    7f716ee00c81:	mov    QWORD PTR [r12+0xf0],r13
    7f716ee00c89:	mov    r13d,0x4109a4
    7f716ee00c8f:	mov    QWORD PTR [r12+0x100],r13
    7f716ee00c97:	mov    r11,QWORD PTR [rsp]
    7f716ee00c9b:	mov    QWORD PTR [r12+0x398],r11
    7f716ee00ca3:	mov    edi,0x4109a4
    7f716ee00ca8:	mov    QWORD PTR [r12+0x100],rdi
    7f716ee00cb0:	add    rsp,0x10
    7f716ee00cb4:	nop    DWORD PTR [rax+0x0]
    7f716ee00cb8:	jmp    QWORD PTR [rip+0x2]        # 0x7f716ee00cc0
    7f716ee00cbe:	xchg   ax,ax
    7f716ee00cc0:	rex (bad)
    7f716ee00cc2:	loopne 0x7f716ee00d32
    7f716ee00cc4:	jno    0x7f716ee00d45
    7f716ee00cc6:	add    BYTE PTR [rax],al
    7f716ee00cc8:	ror    BYTE PTR [rax+riz*8],1
    7f716ee00ccb:	outs   dx,BYTE PTR ds:[rsi]
    7f716ee00ccc:	jno    0x7f716ee00d4d
    7f716ee00cce:	add    BYTE PTR [rax],al
    7f716ee00cd0:	movabs r11,0x5fdfb8bf7940
    7f716ee00cda:	jmp    r11
    7f716ee00cdd:	mov    r13d,DWORD PTR [r12+0xa0]
    7f716ee00ce5:	add    r13d,0x11
    7f716ee00ce9:	mov    QWORD PTR [r12],r13
    7f716ee00ced:	mov    r13d,0x41035c
    7f716ee00cf3:	mov    QWORD PTR [r12+0xf0],r13
    7f716ee00cfb:	mov    r13d,0x4109a4
    7f716ee00d01:	mov    QWORD PTR [r12+0x100],r13
    7f716ee00d09:	mov    r11,QWORD PTR [rsp]
    7f716ee00d0d:	mov    QWORD PTR [r12+0x398],r11
    7f716ee00d15:	mov    edi,0x4109a4
    7f716ee00d1a:	mov    QWORD PTR [r12+0x100],rdi
    7f716ee00d22:	add    rsp,0x10
    7f716ee00d26:	xchg   ax,ax
    7f716ee00d28:	jmp    QWORD PTR [rip+0x2]        # 0x7f716ee00d30
    7f716ee00d2e:	xchg   ax,ax
    7f716ee00d30:	rex (bad)
    7f716ee00d32:	loopne 0x7f716ee00da2
    7f716ee00d34:	jno    0x7f716ee00db5
    7f716ee00d36:	add    BYTE PTR [rax],al
    7f716ee00d38:	rex or eax,0x7f716ee0
    7f716ee00d3e:	add    BYTE PTR [rax],al
    7f716ee00d40:	movabs r11,0x5fdfb8bf7940
    7f716ee00d4a:	jmp    r11
    7f716ee00d4d:	mov    eax,0x410368
    7f716ee00d52:	mov    QWORD PTR [r12+0x100],rax
    7f716ee00d5a:	push   rdx
    7f716ee00d5b:	push   rsi
    7f716ee00d5c:	push   r10
    7f716ee00d5e:	push   r11
    7f716ee00d60:	mov    r11,rax
    7f716ee00d63:	lahf
    7f716ee00d64:	seto   al
    7f716ee00d67:	mov    WORD PTR [rsp+0x20],ax
    7f716ee00d6c:	mov    rax,r11
    7f716ee00d6f:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee00d74:	mov    r10d,edx
    7f716ee00d77:	and    r10d,0xc000
    7f716ee00d7e:	shl    r10d,0x10
    7f716ee00d82:	mov    r11d,edx
    7f716ee00d85:	and    r11d,0x100
    7f716ee00d8c:	shl    r11d,0x15
    7f716ee00d90:	or     r10d,r11d
    7f716ee00d93:	and    edx,0x1
    7f716ee00d96:	shl    edx,0x1c
    7f716ee00d99:	or     r10d,edx
    7f716ee00d9c:	btc    r10,0x1d
    7f716ee00da1:	mov    r11d,0xf0000000
    7f716ee00da7:	and    r11,r10
    7f716ee00daa:	movabs rsi,0xffffffff0fffffff
    7f716ee00db4:	and    rbx,rsi
    7f716ee00db7:	or     rbx,r11
    7f716ee00dba:	pop    r11
    7f716ee00dbc:	pop    r10
    7f716ee00dbe:	pop    rsi
    7f716ee00dbf:	pop    rdx
    7f716ee00dc0:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee00dc8:	add    rsp,0x10
    7f716ee00dcc:	mov    eax,0xc
    7f716ee00dd1:	movabs r11,0x5fdfb8bf7ca0
    7f716ee00ddb:	jmp    r11
    7f716ee00dde:	mov    eax,0x41039c
    7f716ee00de3:	mov    QWORD PTR [r12+0x100],rax
    7f716ee00deb:	push   rdx
    7f716ee00dec:	push   rsi
    7f716ee00ded:	push   r10
    7f716ee00def:	push   r11
    7f716ee00df1:	mov    r11,rax
    7f716ee00df4:	lahf
    7f716ee00df5:	seto   al
    7f716ee00df8:	mov    WORD PTR [rsp+0x20],ax
    7f716ee00dfd:	mov    rax,r11
    7f716ee00e00:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee00e05:	mov    r10d,edx
    7f716ee00e08:	and    r10d,0xc000
    7f716ee00e0f:	shl    r10d,0x10
    7f716ee00e13:	mov    r11d,edx
    7f716ee00e16:	and    r11d,0x100
    7f716ee00e1d:	shl    r11d,0x15
    7f716ee00e21:	or     r10d,r11d
    7f716ee00e24:	and    edx,0x1
    7f716ee00e27:	shl    edx,0x1c
    7f716ee00e2a:	or     r10d,edx
    7f716ee00e2d:	btc    r10,0x1d
    7f716ee00e32:	mov    r11d,0xf0000000
    7f716ee00e38:	and    r11,r10
    7f716ee00e3b:	movabs rsi,0xffffffff0fffffff
    7f716ee00e45:	and    rbx,rsi
    7f716ee00e48:	or     rbx,r11
    7f716ee00e4b:	pop    r11
    7f716ee00e4d:	pop    r10
    7f716ee00e4f:	pop    rsi
    7f716ee00e50:	pop    rdx
    7f716ee00e51:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee00e59:	add    rsp,0x10
    7f716ee00e5d:	mov    eax,0xc
    7f716ee00e62:	movabs r11,0x5fdfb8bf7ca0
    7f716ee00e6c:	jmp    r11
    7f716ee00e6f:	mov    eax,0x4103a8
    7f716ee00e74:	mov    QWORD PTR [r12+0x100],rax
    7f716ee00e7c:	push   rdx
    7f716ee00e7d:	push   rsi
    7f716ee00e7e:	push   r10
    7f716ee00e80:	push   r11
    7f716ee00e82:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee00e87:	mov    r10d,edx
    7f716ee00e8a:	and    r10d,0xc000
    7f716ee00e91:	shl    r10d,0x10
    7f716ee00e95:	mov    r11d,edx
    7f716ee00e98:	and    r11d,0x100
    7f716ee00e9f:	shl    r11d,0x15
    7f716ee00ea3:	or     r10d,r11d
    7f716ee00ea6:	and    edx,0x1
    7f716ee00ea9:	shl    edx,0x1c
    7f716ee00eac:	or     r10d,edx
    7f716ee00eaf:	btc    r10,0x1d
    7f716ee00eb4:	mov    r11d,0xf0000000
    7f716ee00eba:	and    r11,r10
    7f716ee00ebd:	movabs rsi,0xffffffff0fffffff
    7f716ee00ec7:	and    rbx,rsi
    7f716ee00eca:	or     rbx,r11
    7f716ee00ecd:	pop    r11
    7f716ee00ecf:	pop    r10
    7f716ee00ed1:	pop    rsi
    7f716ee00ed2:	pop    rdx
    7f716ee00ed3:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee00edb:	add    rsp,0x10
    7f716ee00edf:	mov    eax,0xc
    7f716ee00ee4:	movabs r11,0x5fdfb8bf7ca0
    7f716ee00eee:	jmp    r11
    7f716ee00ef1:	mov    eax,0x4103ac
    7f716ee00ef6:	mov    QWORD PTR [r12+0x100],rax
    7f716ee00efe:	push   rdx
    7f716ee00eff:	push   rsi
    7f716ee00f00:	push   r10
    7f716ee00f02:	push   r11
    7f716ee00f04:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee00f09:	mov    r10d,edx
    7f716ee00f0c:	and    r10d,0xc000
    7f716ee00f13:	shl    r10d,0x10
    7f716ee00f17:	mov    r11d,edx
    7f716ee00f1a:	and    r11d,0x100
    7f716ee00f21:	shl    r11d,0x15
    7f716ee00f25:	or     r10d,r11d
    7f716ee00f28:	and    edx,0x1
    7f716ee00f2b:	shl    edx,0x1c
    7f716ee00f2e:	or     r10d,edx
    7f716ee00f31:	btc    r10,0x1d
    7f716ee00f36:	mov    r11d,0xf0000000
    7f716ee00f3c:	and    r11,r10
    7f716ee00f3f:	movabs rsi,0xffffffff0fffffff
    7f716ee00f49:	and    rbx,rsi
    7f716ee00f4c:	or     rbx,r11
    7f716ee00f4f:	pop    r11
    7f716ee00f51:	pop    r10
    7f716ee00f53:	pop    rsi
    7f716ee00f54:	pop    rdx
    7f716ee00f55:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee00f5d:	add    rsp,0x10
    7f716ee00f61:	mov    eax,0xc
    7f716ee00f66:	movabs r11,0x5fdfb8bf7ca0
    7f716ee00f70:	jmp    r11
    7f716ee00f73:	mov    eax,0x4103dc
    7f716ee00f78:	mov    QWORD PTR [r12+0x100],rax
    7f716ee00f80:	push   rdx
    7f716ee00f81:	push   rsi
    7f716ee00f82:	push   r10
    7f716ee00f84:	push   r11
    7f716ee00f86:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee00f8b:	mov    r10d,edx
    7f716ee00f8e:	and    r10d,0xc000
    7f716ee00f95:	shl    r10d,0x10
    7f716ee00f99:	mov    r11d,edx
    7f716ee00f9c:	and    r11d,0x100
    7f716ee00fa3:	shl    r11d,0x15
    7f716ee00fa7:	or     r10d,r11d
    7f716ee00faa:	and    edx,0x1
    7f716ee00fad:	shl    edx,0x1c
    7f716ee00fb0:	or     r10d,edx
    7f716ee00fb3:	btc    r10,0x1d
    7f716ee00fb8:	mov    r11d,0xf0000000
    7f716ee00fbe:	and    r11,r10
    7f716ee00fc1:	movabs rsi,0xffffffff0fffffff
    7f716ee00fcb:	and    rbx,rsi
    7f716ee00fce:	or     rbx,r11
    7f716ee00fd1:	pop    r11
    7f716ee00fd3:	pop    r10
    7f716ee00fd5:	pop    rsi
    7f716ee00fd6:	pop    rdx
    7f716ee00fd7:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee00fdf:	add    rsp,0x10
    7f716ee00fe3:	mov    eax,0xc
    7f716ee00fe8:	movabs r11,0x5fdfb8bf7ca0
    7f716ee00ff2:	jmp    r11
    7f716ee00ff5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee01000:	sub    rsp,0x10
    7f716ee01004:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0100c:	mov    QWORD PTR [rsp],r11
    7f716ee01010:	jmp    0x7f716ee0099d
    7f716ee01015:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee01020:	sub    rsp,0x10
    7f716ee01024:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0102c:	mov    QWORD PTR [rsp],r11
    7f716ee01030:	mov    r11,rax
    7f716ee01033:	movzx  eax,WORD PTR [rsp]
    7f716ee01037:	add    al,0x7f
    7f716ee01039:	sahf
    7f716ee0103a:	mov    rax,r11
    7f716ee0103d:	jmp    0x7f716ee009ba
    7f716ee01042:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee01050:	sub    rsp,0x10
    7f716ee01054:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0105c:	mov    QWORD PTR [rsp],r11
    7f716ee01060:	jmp    0x7f716ee009fe
    7f716ee01065:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee01070:	sub    rsp,0x10
    7f716ee01074:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0107c:	mov    QWORD PTR [rsp],r11
    7f716ee01080:	jmp    0x7f716ee00a72
    7f716ee01085:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee01090:	sub    rsp,0x10
    7f716ee01094:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0109c:	mov    QWORD PTR [rsp],r11
    7f716ee010a0:	jmp    0x7f716ee00acd
    7f716ee010a5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee010b0:	sub    rsp,0x10
    7f716ee010b4:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee010bc:	mov    QWORD PTR [rsp],r11
    7f716ee010c0:	jmp    0x7f716ee00ae1
    7f716ee010c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee010d0:	sub    rsp,0x10
    7f716ee010d4:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee010dc:	mov    QWORD PTR [rsp],r11
    7f716ee010e0:	jmp    0x7f716ee00af1
    7f716ee010e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee010f0:	sub    rsp,0x10
    7f716ee010f4:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee010fc:	mov    QWORD PTR [rsp],r11
    7f716ee01100:	jmp    0x7f716ee00b51
    7f716ee01105:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee01110:	sub    rsp,0x10
    7f716ee01114:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0111c:	mov    QWORD PTR [rsp],r11
    7f716ee01120:	jmp    0x7f716ee00b86
    7f716ee01125:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee01130:	sub    rsp,0x10
    7f716ee01134:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0113c:	mov    QWORD PTR [rsp],r11
    7f716ee01140:	jmp    0x7f716ee00c29
    7f716ee01145:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716ee01150:	sub    rsp,0x10
    7f716ee01154:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0115c:	mov    QWORD PTR [rsp],r11
    7f716ee01160:	jmp    0x7f716ee00cdd
    7f716ee01165:	nop
    7f716ee01166:	nop
    7f716ee01167:	nop
