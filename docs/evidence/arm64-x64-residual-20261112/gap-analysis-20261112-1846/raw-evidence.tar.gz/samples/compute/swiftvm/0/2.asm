
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/0/2.bin:     file format binary


Disassembly of section .data:

000074a37e500b80 <.data>:
    74a37e500b80:	sub    rsp,0x10
    74a37e500b84:	mov    r13d,DWORD PTR [r12+0xa0]
    74a37e500b8c:	sub    r13d,0x1
    74a37e500b90:	mov    QWORD PTR [r12+0xa0],r13
    74a37e500b98:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e500ba0:	jrcxz  0x74a37e500ba7
    74a37e500ba2:	jmp    0x74a37e500d3d
    74a37e500ba7:	jne    0x74a37e500bc0
    74a37e500bad:	mov    r11,rax
    74a37e500bb0:	lahf
    74a37e500bb1:	seto   al
    74a37e500bb4:	mov    WORD PTR [rsp],ax
    74a37e500bb8:	mov    rax,r11
    74a37e500bbb:	jmp    0x74a37e500bd3
    74a37e500bc0:	mov    r11,rax
    74a37e500bc3:	lahf
    74a37e500bc4:	seto   al
    74a37e500bc7:	mov    WORD PTR [rsp],ax
    74a37e500bcb:	mov    rax,r11
    74a37e500bce:	jmp    0x74a37e500ca5
    74a37e500bd3:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e500bdb:	mov    r14,r13
    74a37e500bde:	add    r14,0x120
    74a37e500be5:	mov    r15,QWORD PTR [r14]
    74a37e500be8:	mov    QWORD PTR [r12+0x98],r15
    74a37e500bf0:	mov    r14d,0x80
    74a37e500bf6:	mov    QWORD PTR [r12+0x40],r14
    74a37e500bfb:	mov    r14,r13
    74a37e500bfe:	add    r14,0x100
    74a37e500c05:	mov    QWORD PTR [r12],r14
    74a37e500c09:	mov    r14,r13
    74a37e500c0c:	add    r14,0x17c
    74a37e500c13:	mov    QWORD PTR [r12+0x8],r14
    74a37e500c18:	mov    r14d,0x1
    74a37e500c1e:	mov    QWORD PTR [r12+0x10],r14
    74a37e500c23:	add    r13,0x17c
    74a37e500c2a:	movzx  r14d,BYTE PTR [r12+0x40]
    74a37e500c30:	mov    BYTE PTR [r13+0x0],r14b
    74a37e500c34:	mov    r13d,0x0
    74a37e500c3a:	mov    DWORD PTR [r12+0x32c],r13d
    74a37e500c42:	mov    r13d,0x4102a8
    74a37e500c48:	mov    QWORD PTR [r12+0xf0],r13
    74a37e500c50:	mov    r13d,0x410728
    74a37e500c56:	mov    QWORD PTR [r12+0x100],r13
    74a37e500c5e:	mov    r11,QWORD PTR [rsp]
    74a37e500c62:	mov    QWORD PTR [r12+0x398],r11
    74a37e500c6a:	mov    edi,0x410728
    74a37e500c6f:	mov    QWORD PTR [r12+0x100],rdi
    74a37e500c77:	add    rsp,0x10
    74a37e500c7b:	nop    DWORD PTR [rax+rax*1+0x0]
    74a37e500c80:	jmp    QWORD PTR [rip+0x2]        # 0x74a37e500c88
    74a37e500c86:	xchg   ax,ax
    74a37e500c88:	loopne 0x74a37e500c6f
    74a37e500c8a:	rex.WRXB jle 0x74a37e500c30
    74a37e500c8d:	je     0x74a37e500c8f
    74a37e500c8f:	add    BYTE PTR [rax-0x5c81aff4],bl
    74a37e500c95:	je     0x74a37e500c97
    74a37e500c97:	add    BYTE PTR [rcx-0x45],cl
    74a37e500c9a:	rex cdq
    74a37e500c9c:	outs   dx,BYTE PTR ds:[rsi]
    74a37e500c9d:	rex.RX adc eax,0x41000057
    74a37e500ca3:	jmp    rbx
    74a37e500ca5:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e500cad:	add    r13,0x100
    74a37e500cb4:	mov    QWORD PTR [r12],r13
    74a37e500cb8:	mov    r13d,0x0
    74a37e500cbe:	mov    r14,QWORD PTR [r12+0x98]
    74a37e500cc6:	or     r13,r14
    74a37e500cc9:	mov    QWORD PTR [r12+0x8],r13
    74a37e500cce:	mov    r13d,0x12c
    74a37e500cd4:	mov    QWORD PTR [r12+0x10],r13
    74a37e500cd9:	mov    r13d,0x410284
    74a37e500cdf:	mov    QWORD PTR [r12+0xf0],r13
    74a37e500ce7:	mov    r13d,0x410728
    74a37e500ced:	mov    QWORD PTR [r12+0x100],r13
    74a37e500cf5:	mov    r11,QWORD PTR [rsp]
    74a37e500cf9:	mov    QWORD PTR [r12+0x398],r11
    74a37e500d01:	mov    edi,0x410728
    74a37e500d06:	mov    QWORD PTR [r12+0x100],rdi
    74a37e500d0e:	add    rsp,0x10
    74a37e500d12:	nop    WORD PTR [rax+rax*1+0x0]
    74a37e500d18:	jmp    QWORD PTR [rip+0x2]        # 0x74a37e500d20
    74a37e500d1e:	xchg   ax,ax
    74a37e500d20:	loopne 0x74a37e500d07
    74a37e500d22:	rex.WRXB jle 0x74a37e500cc8
    74a37e500d25:	je     0x74a37e500d27
    74a37e500d27:	add    BYTE PTR [rax],dh
    74a37e500d29:	or     eax,0x74a37e50
    74a37e500d2e:	add    BYTE PTR [rax],al
    74a37e500d30:	movabs r11,0x5715466e9940
    74a37e500d3a:	jmp    r11
    74a37e500d3d:	mov    eax,0x410288
    74a37e500d42:	mov    QWORD PTR [r12+0x100],rax
    74a37e500d4a:	push   rdx
    74a37e500d4b:	push   rsi
    74a37e500d4c:	push   r10
    74a37e500d4e:	push   r11
    74a37e500d50:	mov    r11,rax
    74a37e500d53:	lahf
    74a37e500d54:	seto   al
    74a37e500d57:	mov    WORD PTR [rsp+0x20],ax
    74a37e500d5c:	mov    rax,r11
    74a37e500d5f:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e500d64:	mov    r10d,edx
    74a37e500d67:	and    r10d,0xc000
    74a37e500d6e:	shl    r10d,0x10
    74a37e500d72:	mov    r11d,edx
    74a37e500d75:	and    r11d,0x100
    74a37e500d7c:	shl    r11d,0x15
    74a37e500d80:	or     r10d,r11d
    74a37e500d83:	and    edx,0x1
    74a37e500d86:	shl    edx,0x1c
    74a37e500d89:	or     r10d,edx
    74a37e500d8c:	btc    r10,0x1d
    74a37e500d91:	mov    r11d,0xf0000000
    74a37e500d97:	and    r11,r10
    74a37e500d9a:	movabs rsi,0xffffffff0fffffff
    74a37e500da4:	and    rbx,rsi
    74a37e500da7:	or     rbx,r11
    74a37e500daa:	pop    r11
    74a37e500dac:	pop    r10
    74a37e500dae:	pop    rsi
    74a37e500daf:	pop    rdx
    74a37e500db0:	mov    QWORD PTR [r12+0x108],rbx
    74a37e500db8:	add    rsp,0x10
    74a37e500dbc:	mov    eax,0xc
    74a37e500dc1:	movabs r11,0x5715466e9ca0
    74a37e500dcb:	jmp    r11
    74a37e500dce:	xchg   ax,ax
    74a37e500dd0:	sub    rsp,0x10
    74a37e500dd4:	mov    r11,QWORD PTR [r12+0x398]
    74a37e500ddc:	mov    QWORD PTR [rsp],r11
    74a37e500de0:	jmp    0x74a37e500bd3
    74a37e500de5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e500df0:	sub    rsp,0x10
    74a37e500df4:	mov    r11,QWORD PTR [r12+0x398]
    74a37e500dfc:	mov    QWORD PTR [rsp],r11
    74a37e500e00:	jmp    0x74a37e500ca5
    74a37e500e05:	nop
    74a37e500e06:	nop
    74a37e500e07:	nop
