#include <array>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>
#include <sys/mman.h>
#include "runtime/backend/x64/allocate.h"
#include "runtime/backend/x64/compile.h"
#include "runtime/backend/x64/runtime.h"
#include "runtime/ir/builder.h"
#include "runtime/ir/optimize.h"
using namespace swift::runtime;
using namespace ir;
using u64 = std::uint64_t;
using Clock = std::chrono::steady_clock;
namespace x64 = backend::x64;

void need(bool value) {
    if (!value) throw std::runtime_error("scaling verification failed");
}

Value emit(Builder& b,
           OpCode op,
           Type type,
           std::initializer_list<Operand> inputs,
           OperationMetadata meta = {}) {
    auto result = b.Append(op, type, inputs, meta);
    need(bool(result));
    return result.GetValue();
}

void check(Error error) { need(error == Error::None); }

Operand imm(u64 value) { return Operand::Immediate(value, Type::U64); }

Value load(Builder& b, unsigned offset, Type type = Type::U64) {
    return emit(b, OpCode::LoadUniform, type, {Operand::Uniform(offset, type)});
}

void store(Builder& b, unsigned offset, Value value, Type type = Type::U64) {
    emit(b,
         OpCode::StoreUniform,
         Type::Void,
         {Operand::Uniform(offset, type), Operand::ValueOf(value)});
}

struct Result {
    std::size_t nodes, bytes, frame, spills, erased, stubs, blocks;
    std::size_t operand_words{}, optimized_nodes{}, ir_bytes{}, ir_reserved_bytes{},
            home_capacity_bytes{}, allocation_capacity_bytes{};
};

Result run(const std::string& kind, unsigned count, bool verify) {
    const bool fp = kind == "fp" || kind == "cold", cfg = kind == "cfg";
    Builder b{cfg ? Scope::Function : Scope::Block, x64::KnownTargetInfo()};
    const unsigned blocks = cfg ? count / 64 : 1;
    std::vector<BlockRef> refs;
    for (unsigned i = 0; i < blocks; ++i) {
        auto block = b.CreateBlock();
        need(bool(block));
        refs.push_back(block.block);
    }
    Value value;
    for (unsigned block = 0; block < blocks; ++block) {
        check(b.BeginBlock(refs[block]));
        value = load(b, 0, fp ? Type::V128 : Type::U64);
        if (kind == "pressure") {
            std::array<Value, 20> values;
            values[0] = value;
            for (unsigned i = 1; i < values.size(); ++i) values[i] = load(b, i * 8);
            for (unsigned i = 1; i < values.size(); ++i)
                value = emit(b,
                             OpCode::Add,
                             Type::U64,
                             {Operand::ValueOf(value), Operand::ValueOf(values[i])});
        }
        Value right;
        if (fp) right = load(b, 16, Type::V128);
        for (unsigned i = 0; i < count / blocks; ++i) {
            if (fp)
                value = emit(b,
                             OpCode::ArmFPBinary,
                             Type::V128,
                             {Operand::ValueOf(value),
                              Operand::ValueOf(right),
                              imm(3012),
                              imm(3016),
                              imm(12)});
            else
                value = emit(b,
                             OpCode::Add,
                             Type::U64,
                             {Operand::ValueOf(value), imm(1)},
                             kind == "flags"
                                     ? OperationMetadata{i % 8 ? 4u : 15u,
                                                         FlagProfile::ArithmeticCanonicalCarry,
                                                         false}
                                     : OperationMetadata{});
            if (kind == "flags") {
                auto condition =
                        emit(b, OpCode::CondSet, Type::Bool, {Operand::Condition(Condition::GE)});
                value = emit(b,
                             OpCode::Add,
                             Type::U64,
                             {Operand::ValueOf(value), Operand::ValueOf(condition)});
            }
            if (kind == "uniform") store(b, 0, value);
        }
        if (fp)
            store(b, 2048, value, Type::V128);
        else
            store(b, 0, value);
        if (cfg) {
            auto counter = load(b, 8 + block * 8);
            counter = emit(b,
                           OpCode::Sub,
                           Type::U64,
                           {Operand::ValueOf(counter), imm(1)},
                           {15, FlagProfile::ArithmeticRaw, false});
            store(b, 8 + block * 8, counter);
            auto condition =
                    emit(b, OpCode::CondSet, Type::Bool, {Operand::Condition(Condition::NE)});
            if (block + 1 < blocks)
                check(b.EndBlock(Terminal::Branch(condition, refs[block], refs[block + 1])));
            else
                check(b.EndBlock(Terminal::Return(value)));
        } else {
            if (fp) value = emit(b, OpCode::LoadImm, Type::U64, {imm(0)});
            check(b.EndBlock(Terminal::Return(value)));
        }
    }
    auto submitted = b.Submit();
    need(bool(submitted));
    const auto nodes = submitted.program.Operations().size();
    auto optimized = Optimize(std::move(submitted.program),
                              SIZE_MAX,
                              {.flags = UniformRange{3000, 8},
                               .guest_memory_disjoint = true,
                               .numeric_control = UniformRange{3008, 4},
                               .pc = UniformRange{3024, 8}});
    need(bool(optimized));
    x64::CompileOptions options;
    options.flags_offset = 3000;
    options.mxcsr_offset = 3008;
    options.pc_offset = 3024;
    options.native_fp_environment = true;
    options.local_flags = true;
    options.relocatable = true;
    options.arm_fpcr = fp ? 0 : UINT32_MAX;
    options.arm_fpcr_offset = fp ? 3012 : UINT32_MAX;
    x64::Allocation allocation;
    backend::CompileResult code;
    x64::Compile(optimized.program, options, code, allocation);
    need(bool(code));
    Result result{nodes,
                  code.words.size() * 4,
                  code.frame_bytes,
                  0,
                  optimized.stats.uniform_stores_erased,
                  0,
                  blocks};

    result.operand_words = optimized.program.OperandArena().size();
    result.optimized_nodes = optimized.program.Operations().size();
    result.ir_bytes = optimized.program.StorageBytes();
    result.ir_reserved_bytes = optimized.program.ReservedBytes();
    result.home_capacity_bytes = allocation.homes.capacity() * sizeof(x64::Home);
    result.allocation_capacity_bytes = sizeof(allocation) + result.home_capacity_bytes +
                                       allocation.block_order.capacity() * sizeof(std::uint32_t) +
                                       allocation.flags_input.capacity() +
                                       (allocation.native_entry.capacity() + 7) / 8 +
                                       allocation.terminal_conditions.capacity();
    for (auto& home : allocation.homes)
        result.spills += home.spilled && home.uniform_offset == UINT32_MAX;
    for (auto& relocation : code.relocations)
        result.stubs += relocation.symbol == backend::HostSymbol::ArmFPBinary;
    if (verify) {
        const auto size = (result.bytes + 4095) & ~std::size_t{4095};
        auto* memory =
                mmap(nullptr, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        need(memory != MAP_FAILED);
        std::memcpy(memory, code.words.data(), result.bytes);
        need(mprotect(memory, size, PROT_READ | PROT_EXEC) == 0);
        alignas(16) std::array<std::uint8_t, 4096> state{};
        const auto put = [&](unsigned offset, auto value) {
            std::memcpy(state.data() + offset, &value, sizeof(value));
        };
        for (unsigned i = 0; i < 20; ++i) put(i * 8, u64{i + 1});
        put(0, u64{5});
        for (unsigned i = 0; cfg && i < blocks; ++i) put(8 + i * 8, u64{1});
        put(3008, std::uint32_t{0x1f80});
        if (fp) {
            put(0, kind == "cold" ? u64{0x7ff0000000000042} : u64{0x3ff0000000000000});
            put(16, u64{0x3ff8000000000000});
        }
        using Function = u64 (*)(std::uint8_t*);
        const auto actual = reinterpret_cast<Function>(memory)(state.data());
        if (fp) {
            std::array<u64, 2> actual_fp;
            std::memcpy(actual_fp.data(), state.data() + 2048, 16);
            double number = 1.0 + 1.5 * count;
            u64 expected;
            std::memcpy(&expected, &number, 8);
            need(actual == 0 &&
                 actual_fp[0] == (kind == "cold" ? u64{0x7ff8000000000042} : expected) &&
                 actual_fp[1] == 0);
            std::uint32_t status;
            std::memcpy(&status, state.data() + 3016, 4);
            need(status == (kind == "cold" ? 1u : 0u));
        } else
            need(actual == (kind == "pressure" ? 214u : 5u) + count * (kind == "flags" ? 2u : 1u));
        need(munmap(memory, size) == 0);
    }
    return result;
}

int main(int argc, char** argv) {
    need(argc == 3);
    const std::string kind = argv[1];
    const unsigned count = std::stoul(argv[2]);
    const auto result = run(kind, count, true);
    x64::Runtime runtime{false};
    const auto host = runtime.Bind();
    std::printf(
            "{\"kind\":\"%s\",\"count\":%u,\"nodes_before_optimize\":%zu,"
            "\"nodes_after_optimize\":%zu,\"physical_operand_words\":%zu,"
            "\"ir_payload_bytes\":%zu,\"ir_reserved_bytes\":%zu,"
            "\"home_capacity_bytes\":%zu,\"known_allocation_capacity_bytes\":%zu,"
            "\"sizeof_home\":%zu,\"sizeof_allocation\":%zu,\"isa_features\":%llu,"
            "\"native_bytes\":%zu,\"frame_bytes\":%zu,\"output_verified\":true}\n",
            kind.c_str(),
            count,
            result.nodes,
            result.optimized_nodes,
            result.operand_words,
            result.ir_bytes,
            result.ir_reserved_bytes,
            result.home_capacity_bytes,
            result.allocation_capacity_bytes,
            sizeof(x64::Home),
            sizeof(x64::Allocation),
            static_cast<unsigned long long>(host.isa_features),
            result.bytes,
            result.frame);
}
