00007b00b77ce69b  nop [rax+rax*1], eax
00007b00b77ce6a0  mov rax, [r15+0xF8]
00007b00b77ce6a7  lea r14, [rax-0x1B0]
00007b00b77ce6ae  mov [r15+0xF8], r14
00007b00b77ce6b5  lea rax, [r14+0x1A0]
00007b00b77ce6bc  mov r12, [r15+0xA0]
00007b00b77ce6c3  mov r11, [r15+0x98]
00007b00b77ce6ca  mov [r13+rax*1], r12
00007b00b77ce6cf  lea rax, [r14+0x1A8]
00007b00b77ce6d6  mov [r13+rax*1], r11
00007b00b77ce6db  mov eax, 0x420A30
00007b00b77ce6e0  movups xmm1, [r13+rax*1]
00007b00b77ce6e6  mov eax, 0x4209C0
00007b00b77ce6eb  movups xmm15, [r13+rax*1]
00007b00b77ce6f1  mov eax, 0x420A50
00007b00b77ce6f6  movups xmm14, [r13+rax*1]
00007b00b77ce6fc  mov eax, 0x4209F0
00007b00b77ce701  movups xmm13, [r13+rax*1]
00007b00b77ce707  mov qword ptr [r15+0x98], 0x430C60
00007b00b77ce712  mov eax, 0x420A60
00007b00b77ce717  movups xmm12, [r13+rax*1]
00007b00b77ce71d  mov eax, 0x430C60
00007b00b77ce722  movups [r13+rax*1], xmm1
00007b00b77ce728  mov eax, 0x430C70
00007b00b77ce72d  movups [r13+rax*1], xmm15
00007b00b77ce733  mov eax, 0x430C80
00007b00b77ce738  movups [r13+rax*1], xmm14
00007b00b77ce73e  mov eax, 0x430C90
00007b00b77ce743  movups [r13+rax*1], xmm13
00007b00b77ce749  mov eax, 0x4209B0
00007b00b77ce74e  movups xmm14, [r13+rax*1]
00007b00b77ce754  mov eax, 0x4209A0
00007b00b77ce759  movups xmm13, [r13+rax*1]
00007b00b77ce75f  mov eax, 0x430D60
00007b00b77ce764  movups [r13+rax*1], xmm1
00007b00b77ce76a  mov eax, 0x430D70
00007b00b77ce76f  movups [r13+rax*1], xmm15
00007b00b77ce775  mov eax, 0x430CA0
00007b00b77ce77a  movups [r13+rax*1], xmm12
00007b00b77ce780  mov eax, 0x430CB0
00007b00b77ce785  movups [r13+rax*1], xmm14
00007b00b77ce78b  mov eax, 0x420990
00007b00b77ce790  movups xmm1, [r13+rax*1]
00007b00b77ce796  mov eax, 0x420A00
00007b00b77ce79b  movups xmm15, [r13+rax*1]
00007b00b77ce7a1  mov eax, 0x430CC0
00007b00b77ce7a6  movups [r13+rax*1], xmm13
00007b00b77ce7ac  mov eax, 0x430CD0
00007b00b77ce7b1  movups [r13+rax*1], xmm1
00007b00b77ce7b7  mov eax, 0x420A10
00007b00b77ce7bc  movups xmm1, [r13+rax*1]
00007b00b77ce7c2  mov eax, 0x4209E0
00007b00b77ce7c7  movups xmm14, [r13+rax*1]
00007b00b77ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007b00b77ce7d5  mov eax, 0x430CE0
00007b00b77ce7da  movups [r13+rax*1], xmm15
00007b00b77ce7e0  mov eax, 0x430CF0
00007b00b77ce7e5  movups [r13+rax*1], xmm1
00007b00b77ce7eb  mov eax, 0x420A80
00007b00b77ce7f0  movups xmm1, [r13+rax*1]
00007b00b77ce7f6  mov eax, 0x420A90
00007b00b77ce7fb  movups xmm15, [r13+rax*1]
00007b00b77ce801  movaps [r15+0x150], xmm15
00007b00b77ce809  mov qword ptr [r15+0xA0], 0x3E8
00007b00b77ce814  mov eax, 0x430D00
00007b00b77ce819  movups [r13+rax*1], xmm14
00007b00b77ce81f  mov eax, 0x430D10
00007b00b77ce824  movups [r13+rax*1], xmm1
00007b00b77ce82a  mov eax, 0x420A70
00007b00b77ce82f  movups xmm1, [r13+rax*1]
00007b00b77ce835  mov eax, 0x420A20
00007b00b77ce83a  movups xmm14, [r13+rax*1]
00007b00b77ce840  movaps [r15+0x140], xmm14
00007b00b77ce848  lea rax, [r14+0x150]
00007b00b77ce84f  movq xmm13, qword ptr [r15+0x200]
00007b00b77ce858  movq xmm12, qword ptr [r15+0x1F0]
00007b00b77ce861  movq r12, xmm13
00007b00b77ce866  movq r11, xmm12
00007b00b77ce86b  mov [r13+rax*1], r12
00007b00b77ce870  lea rax, [r14+0x158]
00007b00b77ce877  mov [r13+rax*1], r11
00007b00b77ce87c  mov eax, 0x430D20
00007b00b77ce881  movups [r13+rax*1], xmm15
00007b00b77ce887  mov eax, 0x430D30
00007b00b77ce88c  movups [r13+rax*1], xmm1
00007b00b77ce892  mov eax, 0x420A40
00007b00b77ce897  movups xmm1, [r13+rax*1]
00007b00b77ce89d  mov eax, 0x420AA8
00007b00b77ce8a2  mov r12, [r13+rax*1]
00007b00b77ce8a7  movq xmm15, r12
00007b00b77ce8ac  mov qword ptr [r15+0x40], 0x420AB0
00007b00b77ce8b4  mov eax, 0x430D40
00007b00b77ce8b9  movups [r13+rax*1], xmm14
00007b00b77ce8bf  mov eax, 0x430D50
00007b00b77ce8c4  movups [r13+rax*1], xmm1
00007b00b77ce8ca  mov eax, 0x420B10
00007b00b77ce8cf  movups xmm1, [r13+rax*1]
00007b00b77ce8d5  movq rax, xmm15
00007b00b77ce8da  mov r12d, 0x430D80
00007b00b77ce8e0  mov [r13+r12*1], rax
00007b00b77ce8e5  mov eax, 0x420AF0
00007b00b77ce8ea  movups xmm15, [r13+rax*1]
00007b00b77ce8f0  mov eax, 0x420B00
00007b00b77ce8f5  movups xmm14, [r13+rax*1]
00007b00b77ce8fb  lea rax, [r14+0x130]
00007b00b77ce902  movups [r13+rax*1], xmm1
00007b00b77ce908  lea rax, [r14+0x160]
00007b00b77ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007b00b77ce918  movq xmm13, qword ptr [r15+0x1D0]
00007b00b77ce921  movq r12, xmm1
00007b00b77ce926  movq r11, xmm13
00007b00b77ce92b  mov [r13+rax*1], r12
00007b00b77ce930  lea rax, [r14+0x168]
00007b00b77ce937  mov [r13+rax*1], r11
00007b00b77ce93c  lea rax, [r14+0x110]
00007b00b77ce943  movups [r13+rax*1], xmm15
00007b00b77ce949  lea rax, [r14+0x120]
00007b00b77ce950  movups [r13+rax*1], xmm14
00007b00b77ce956  mov eax, 0x420AB0
00007b00b77ce95b  movups xmm1, [r13+rax*1]
00007b00b77ce961  mov eax, 0x420AC0
00007b00b77ce966  movups xmm15, [r13+rax*1]
00007b00b77ce96c  movaps [r15+0x120], xmm15
00007b00b77ce974  lea rax, [r14+0x170]
00007b00b77ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007b00b77ce984  movq xmm13, qword ptr [r15+0x1B0]
00007b00b77ce98d  movq r12, xmm14
00007b00b77ce992  movq r11, xmm13
00007b00b77ce997  mov [r13+rax*1], r12
00007b00b77ce99c  lea rax, [r14+0x178]
00007b00b77ce9a3  mov [r13+rax*1], r11
00007b00b77ce9a8  lea rax, [r14+0x180]
00007b00b77ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007b00b77ce9b8  movq xmm13, qword ptr [r15+0x190]
00007b00b77ce9c1  movq r12, xmm14
00007b00b77ce9c6  movq r11, xmm13
00007b00b77ce9cb  mov [r13+rax*1], r12
00007b00b77ce9d0  lea rax, [r14+0x188]
00007b00b77ce9d7  mov [r13+rax*1], r11
00007b00b77ce9dc  lea rax, [r14+0xD0]
00007b00b77ce9e3  movups [r13+rax*1], xmm1
00007b00b77ce9e9  lea rax, [r14+0xE0]
00007b00b77ce9f0  movups [r13+rax*1], xmm15
00007b00b77ce9f6  mov eax, 0x420AD0
00007b00b77ce9fb  movups xmm1, [r13+rax*1]
00007b00b77cea01  mov eax, 0x420AE0
00007b00b77cea06  movups xmm15, [r13+rax*1]
00007b00b77cea0c  movaps [r15+0x110], xmm1
00007b00b77cea14  movaps [r15+0x130], xmm15
00007b00b77cea1c  lea rax, [r14+0x190]
00007b00b77cea23  mov r12, [r15+0xE8]
00007b00b77cea2a  mov r11, [r15+0xF0]
00007b00b77cea31  mov [r13+rax*1], r12
00007b00b77cea36  lea rax, [r14+0x198]
00007b00b77cea3d  mov [r13+rax*1], r11
00007b00b77cea42  mov eax, 0x430D88
00007b00b77cea47  mov r12d, 0x421DF8D3
00007b00b77cea4d  mov [r13+rax*1], r12d
00007b00b77cea52  lea rax, [r14+0xF0]
00007b00b77cea59  movups [r13+rax*1], xmm1
00007b00b77cea5f  lea rax, [r14+0x100]
00007b00b77cea66  movups [r13+rax*1], xmm15
00007b00b77cea6c  lea rax, [r14+0xD0]
00007b00b77cea73  mov [r15], rax
00007b00b77cea76  mov qword ptr [r15+0x08], 0x430C60
00007b00b77cea7e  mov qword ptr [r15+0x10], 0x12C
00007b00b77cea86  mov qword ptr [r15+0xF0], 0x410284
00007b00b77cea91  mov r14d, [r15+0x320]
00007b00b77cea98  mov eax, 0x410284
00007b00b77cea9d  mov rcx, 0x7B00B77D07C0
00007b00b77ceaa7  mov [r15+r14*8+0x328], rax
00007b00b77ceaaf  mov [r15+r14*8+0x368], rcx
00007b00b77ceab7  add r14d, 0x01
00007b00b77ceabb  and r14d, 0x07
00007b00b77ceabf  mov [r15+0x320], r14d
00007b00b77ceac6  cmp dword ptr [r15+0x318], 0x00
00007b00b77ceace  jz 0x00007B00B77CED70
00007b00b77cead4  nop [rax+rax*1], ax
00007b00b77ceadd  nop [rax+rax*1], eax
00007b00b77ceae5  mov eax, 0x4106BC
00007b00b77ceaea  mov [r15+0x100], rax
00007b00b77ceaf1  jmp 0x00007B00B75FE110
00007b00b77ceaf6  int3
00007b00b77ceaf7  call 0x00007B00B760BC20
00007b00b77ceafc  jmp 0x00007B00B77CE6CF
00007b00b77ceb01  call 0x00007B00B760A9A0
00007b00b77ceb06  jmp 0x00007B00B77CE6DB
00007b00b77ceb0b  call 0x00007B00B75FF430
00007b00b77ceb10  jmp 0x00007B00B77CE6E6
00007b00b77ceb15  call 0x00007B00B760E760
00007b00b77ceb1a  jmp 0x00007B00B77CE6F1
00007b00b77ceb1f  call 0x00007B00B760D4E0
00007b00b77ceb24  jmp 0x00007B00B77CE6FC
00007b00b77ceb29  call 0x00007B00B760C260
00007b00b77ceb2e  jmp 0x00007B00B77CE707
00007b00b77ceb33  call 0x00007B00B760AFE0
00007b00b77ceb38  jmp 0x00007B00B77CE71D
00007b00b77ceb3d  call 0x00007B00B75FF540
00007b00b77ceb42  jmp 0x00007B00B77CE728
00007b00b77ceb47  call 0x00007B00B760E880
00007b00b77ceb4c  jmp 0x00007B00B77CE733
00007b00b77ceb51  call 0x00007B00B760D600
00007b00b77ceb56  jmp 0x00007B00B77CE73E
00007b00b77ceb5b  call 0x00007B00B760C380
00007b00b77ceb60  jmp 0x00007B00B77CE749
00007b00b77ceb65  call 0x00007B00B760D4E0
00007b00b77ceb6a  jmp 0x00007B00B77CE754
00007b00b77ceb6f  call 0x00007B00B760C260
00007b00b77ceb74  jmp 0x00007B00B77CE75F
00007b00b77ceb79  call 0x00007B00B75FF540
00007b00b77ceb7e  jmp 0x00007B00B77CE76A
00007b00b77ceb83  call 0x00007B00B760E880
00007b00b77ceb88  jmp 0x00007B00B77CE775
00007b00b77ceb8d  call 0x00007B00B760B100
00007b00b77ceb92  jmp 0x00007B00B77CE780
00007b00b77ceb97  call 0x00007B00B760D600
00007b00b77ceb9c  jmp 0x00007B00B77CE78B
00007b00b77ceba1  call 0x00007B00B75FF430
00007b00b77ceba6  jmp 0x00007B00B77CE796
00007b00b77cebab  call 0x00007B00B760E760
00007b00b77cebb0  jmp 0x00007B00B77CE7A1
00007b00b77cebb5  call 0x00007B00B760C380
00007b00b77cebba  jmp 0x00007B00B77CE7AC
00007b00b77cebbf  call 0x00007B00B75FF540
00007b00b77cebc4  jmp 0x00007B00B77CE7B7
00007b00b77cebc9  call 0x00007B00B75FF430
00007b00b77cebce  jmp 0x00007B00B77CE7C2
00007b00b77cebd3  call 0x00007B00B760D4E0
00007b00b77cebd8  jmp 0x00007B00B77CE7CD
00007b00b77cebdd  call 0x00007B00B760E880
00007b00b77cebe2  jmp 0x00007B00B77CE7E0
00007b00b77cebe7  call 0x00007B00B75FF540
00007b00b77cebec  jmp 0x00007B00B77CE7EB
00007b00b77cebf1  call 0x00007B00B75FF430
00007b00b77cebf6  jmp 0x00007B00B77CE7F6
00007b00b77cebfb  call 0x00007B00B760E760
00007b00b77cec00  jmp 0x00007B00B77CE801
00007b00b77cec05  call 0x00007B00B760D600
00007b00b77cec0a  jmp 0x00007B00B77CE81F
00007b00b77cec0f  call 0x00007B00B75FF540
00007b00b77cec14  jmp 0x00007B00B77CE82A
00007b00b77cec19  call 0x00007B00B75FF430
00007b00b77cec1e  jmp 0x00007B00B77CE835
00007b00b77cec23  call 0x00007B00B760D4E0
00007b00b77cec28  jmp 0x00007B00B77CE840
00007b00b77cec2d  call 0x00007B00B760BC20
00007b00b77cec32  jmp 0x00007B00B77CE870
00007b00b77cec37  call 0x00007B00B760A9A0
00007b00b77cec3c  jmp 0x00007B00B77CE87C
00007b00b77cec41  call 0x00007B00B760E880
00007b00b77cec46  jmp 0x00007B00B77CE887
00007b00b77cec4b  call 0x00007B00B75FF540
00007b00b77cec50  jmp 0x00007B00B77CE892
00007b00b77cec55  call 0x00007B00B75FF430
00007b00b77cec5a  jmp 0x00007B00B77CE89D
00007b00b77cec5f  call 0x00007B00B760B720
00007b00b77cec64  jmp 0x00007B00B77CE8A7
00007b00b77cec69  call 0x00007B00B760D600
00007b00b77cec6e  jmp 0x00007B00B77CE8BF
00007b00b77cec73  call 0x00007B00B75FF540
00007b00b77cec78  jmp 0x00007B00B77CE8CA
00007b00b77cec7d  call 0x00007B00B75FF430
00007b00b77cec82  jmp 0x00007B00B77CE8D5
00007b00b77cec87  call 0x00007B00B76B4CB0
00007b00b77cec8c  jmp 0x00007B00B77CE8E5
00007b00b77cec91  call 0x00007B00B760E760
00007b00b77cec96  jmp 0x00007B00B77CE8F0
00007b00b77cec9b  call 0x00007B00B760D4E0
00007b00b77ceca0  jmp 0x00007B00B77CE8FB
00007b00b77ceca5  call 0x00007B00B75FF540
00007b00b77cecaa  jmp 0x00007B00B77CE908
00007b00b77cecaf  call 0x00007B00B760BC20
00007b00b77cecb4  jmp 0x00007B00B77CE930
00007b00b77cecb9  call 0x00007B00B760A9A0
00007b00b77cecbe  jmp 0x00007B00B77CE93C
00007b00b77cecc3  call 0x00007B00B760E880
00007b00b77cecc8  jmp 0x00007B00B77CE949
00007b00b77ceccd  call 0x00007B00B760D600
00007b00b77cecd2  jmp 0x00007B00B77CE956
00007b00b77cecd7  call 0x00007B00B75FF430
00007b00b77cecdc  jmp 0x00007B00B77CE961
00007b00b77cece1  call 0x00007B00B760E760
00007b00b77cece6  jmp 0x00007B00B77CE96C
00007b00b77ceceb  call 0x00007B00B760BC20
00007b00b77cecf0  jmp 0x00007B00B77CE99C
00007b00b77cecf5  call 0x00007B00B760A9A0
00007b00b77cecfa  jmp 0x00007B00B77CE9A8
00007b00b77cecff  call 0x00007B00B760BC20
00007b00b77ced04  jmp 0x00007B00B77CE9D0
00007b00b77ced09  call 0x00007B00B760A9A0
00007b00b77ced0e  jmp 0x00007B00B77CE9DC
00007b00b77ced13  call 0x00007B00B75FF540
00007b00b77ced18  jmp 0x00007B00B77CE9E9
00007b00b77ced1d  call 0x00007B00B760E880
00007b00b77ced22  jmp 0x00007B00B77CE9F6
00007b00b77ced27  call 0x00007B00B75FF430
00007b00b77ced2c  jmp 0x00007B00B77CEA01
00007b00b77ced31  call 0x00007B00B760E760
00007b00b77ced36  jmp 0x00007B00B77CEA0C
00007b00b77ced3b  call 0x00007B00B760BC20
00007b00b77ced40  jmp 0x00007B00B77CEA36
00007b00b77ced45  call 0x00007B00B760A9A0
00007b00b77ced4a  jmp 0x00007B00B77CEA42
00007b00b77ced4f  call 0x00007B00B760BAE0
00007b00b77ced54  jmp 0x00007B00B77CEA52
00007b00b77ced59  call 0x00007B00B75FF540
00007b00b77ced5e  jmp 0x00007B00B77CEA5F
00007b00b77ced63  call 0x00007B00B760E880
00007b00b77ced68  jmp 0x00007B00B77CEA6C
00007b00b77ced6d  int3
00007b00b77ced6e  nop
00007b00b77ced70  mov rax, [r15]
00007b00b77ced73  lea r14, [rax+0x20]
00007b00b77ced77  mov r12, [r13+r14*1]
00007b00b77ced7c  mov r14, [r15+0x10]
00007b00b77ced80  lea r11, [r12+r14*1]
00007b00b77ced84  mov [r15+0x40], r11
00007b00b77ced88  lea r12, [rax+0x20]
00007b00b77ced8c  mov [r13+r12*1], r11
00007b00b77ced91  test r14, r14
00007b00b77ced94  setz r14b
00007b00b77ced98  movzx r14, r14b
00007b00b77ced9c  mov [rsp+0x414], r14b
00007b00b77ceda4  cmp byte ptr [rsp+0x414], 0x00
00007b00b77cedac  jz 0x00007B00B77CEDDE
00007b00b77cedae  cmp dword ptr [r15+0x318], 0x00
00007b00b77cedb6  mov eax, 0x410934
00007b00b77cedbb  mov [r15+0x100], rax
00007b00b77cedc2  jz 0x00007B00B75FE0A0
00007b00b77cedc8  nop [rax+rax*1], eax
00007b00b77cedcd  mov eax, 0x410934
00007b00b77cedd2  mov [r15+0x100], rax
00007b00b77cedd9  jmp 0x00007B00B75FE110
00007b00b77cedde  cmp dword ptr [r15+0x318], 0x00
00007b00b77cede6  jz 0x00007B00B77CEE30
00007b00b77cedec  nop [rax+rax*1], ax
00007b00b77cedf5  nop [rax+rax*1], eax
00007b00b77cedfd  mov eax, 0x4106CC
00007b00b77cee02  mov [r15+0x100], rax
00007b00b77cee09  jmp 0x00007B00B75FE110
00007b00b77cee0e  int3
00007b00b77cee0f  call 0x00007B00B76E27E0
00007b00b77cee14  jmp 0x00007B00B77CED7C
00007b00b77cee19  call 0x00007B00B76C0860
00007b00b77cee1e  jmp 0x00007B00B77CED91
00007b00b77cee23  int3
00007b00b77cee24  nop [rax+rax*1], ax
00007b00b77cee2d  nop [rax], eax
00007b00b77cee30  mov rax, [r15+0xF8]
00007b00b77cee37  lea r14, [rax-0x150]
00007b00b77cee3e  mov [r15+0xF8], r14
00007b00b77cee45  mov rax, [r15]
00007b00b77cee48  lea r12, [rax+0x68]
00007b00b77cee4c  mov r11, [r13+r12*1]
00007b00b77cee51  mov [r15+0x88], r11
00007b00b77cee58  lea r12, [rax+0x28]
00007b00b77cee5c  mov [r15+0x40], r12
00007b00b77cee60  mov [r15+0x48], r14
00007b00b77cee64  mov qword ptr [r15+0x50], 0x420B20
00007b00b77cee6c  lea rax, [r14+0x100]
00007b00b77cee73  mov r12, [r15+0xE8]
00007b00b77cee7a  mov r11, [r15+0xD8]
00007b00b77cee81  mov [r13+rax*1], r12
00007b00b77cee86  lea rax, [r14+0x108]
00007b00b77cee8d  mov [r13+rax*1], r11
00007b00b77cee92  lea rax, [r14+0x110]
00007b00b77cee99  mov r12, [r15+0xD0]
00007b00b77ceea0  mov r11, [r15+0xC8]
00007b00b77ceea7  mov [r13+rax*1], r12
00007b00b77ceeac  lea rax, [r14+0x118]
00007b00b77ceeb3  mov [r13+rax*1], r11
00007b00b77ceeb8  lea rax, [r14+0x120]
00007b00b77ceebf  mov r12, [r15+0xC0]
00007b00b77ceec6  mov r11, [r15+0xB8]
00007b00b77ceecd  mov [r13+rax*1], r12
00007b00b77ceed2  lea rax, [r14+0x128]
00007b00b77ceed9  mov [r13+rax*1], r11
00007b00b77ceede  lea rax, [r14+0x130]
00007b00b77ceee5  mov r12, [r15+0xB0]
00007b00b77ceeec  mov r11, [r15+0xA8]
00007b00b77ceef3  mov [r13+rax*1], r12
00007b00b77ceef8  lea rax, [r14+0x138]
00007b00b77ceeff  mov [r13+rax*1], r11
00007b00b77cef04  lea rax, [r14+0x140]
00007b00b77cef0b  mov r12, [r15+0xA0]
00007b00b77cef12  mov r11, [r15+0x98]
00007b00b77cef19  mov [r13+rax*1], r12
00007b00b77cef1e  lea rax, [r14+0x148]
00007b00b77cef25  mov [r13+rax*1], r11
00007b00b77cef2a  cmp dword ptr [r15+0x318], 0x00
00007b00b77cef32  jz 0x00007B00B77CEFD0
00007b00b77cef38  nop [rax+rax*1], ax
00007b00b77cef41  nop [rax+rax*1], eax
00007b00b77cef49  mov eax, 0x410704
00007b00b77cef4e  mov [r15+0x100], rax
00007b00b77cef55  jmp 0x00007B00B75FE110
00007b00b77cef5a  int3
00007b00b77cef5b  call 0x00007B00B76C0370
00007b00b77cef60  jmp 0x00007B00B77CEE51
00007b00b77cef65  call 0x00007B00B760BC20
00007b00b77cef6a  jmp 0x00007B00B77CEE86
00007b00b77cef6f  call 0x00007B00B760A9A0
00007b00b77cef74  jmp 0x00007B00B77CEE92
00007b00b77cef79  call 0x00007B00B760BC20
00007b00b77cef7e  jmp 0x00007B00B77CEEAC
00007b00b77cef83  call 0x00007B00B760A9A0
00007b00b77cef88  jmp 0x00007B00B77CEEB8
00007b00b77cef8d  call 0x00007B00B760BC20
00007b00b77cef92  jmp 0x00007B00B77CEED2
00007b00b77cef97  call 0x00007B00B760A9A0
00007b00b77cef9c  jmp 0x00007B00B77CEEDE
00007b00b77cefa1  call 0x00007B00B760BC20
00007b00b77cefa6  jmp 0x00007B00B77CEEF8
00007b00b77cefab  call 0x00007B00B760A9A0
00007b00b77cefb0  jmp 0x00007B00B77CEF04
00007b00b77cefb5  call 0x00007B00B760BC20
00007b00b77cefba  jmp 0x00007B00B77CEF1E
00007b00b77cefbf  call 0x00007B00B760A9A0
00007b00b77cefc4  jmp 0x00007B00B77CEF2A
00007b00b77cefc9  int3
00007b00b77cefca  nop [rax+rax*1], ax
00007b00b77cefd0  mov rax, [r15+0x08]
00007b00b77cefd4  movzx r14d, byte ptr [r13+rax*1]
00007b00b77cefda  movzx r14d, r14b
00007b00b77cefde  mov [rsp+0x10], r14d
00007b00b77cefe3  mov r14d, r14d
00007b00b77cefe6  mov [r15+0x58], r14
00007b00b77cefea  lea r14, [rax+0x01]
00007b00b77cefee  mov [r15+0x08], r14
00007b00b77ceff2  mov rax, [r15+0x88]
00007b00b77ceff9  lea r14, [rax+0x01]
00007b00b77ceffd  mov r12, [r15]
00007b00b77cf000  lea r11, [r12+0x68]
00007b00b77cf005  mov [r13+r11*1], r14
00007b00b77cf00a  lea r14, [r12+rax*1]
00007b00b77cf00e  mov [r15+0x60], r14
00007b00b77cf012  lea rax, [r14+0x28]
00007b00b77cf016  mov r11d, [rsp+0x10]
00007b00b77cf01b  movzx r14d, r11b
00007b00b77cf01f  mov [r13+rax*1], r14b
00007b00b77cf024  lea rax, [r12+0x68]
00007b00b77cf029  mov r14, [r13+rax*1]
00007b00b77cf02e  mov [r15+0x88], r14
00007b00b77cf035  xor eax, eax
00007b00b77cf037  mov r12d, 0x40
00007b00b77cf03d  cmp r14, r12
00007b00b77cf040  cmc
00007b00b77cf041  lahf
00007b00b77cf042  seto al
00007b00b77cf045  mov [r15+0x108], eax
00007b00b77cf04c  mov eax, [r15+0x108]
00007b00b77cf053  sahf
00007b00b77cf054  jnz 0x00007B00B77CF086
00007b00b77cf056  cmp dword ptr [r15+0x318], 0x00
00007b00b77cf05e  jz 0x00007B00B77CF170
00007b00b77cf064  nop [rax+rax*1], ax
00007b00b77cf06d  nop [rax+rax*1], eax
00007b00b77cf075  mov eax, 0x410724
00007b00b77cf07a  mov [r15+0x100], rax
00007b00b77cf081  jmp 0x00007B00B75FE110
00007b00b77cf086  cmp dword ptr [r15+0x318], 0x00
00007b00b77cf08e  jz 0x00007B00B77CF0E0
00007b00b77cf094  nop [rax+rax*1], ax
00007b00b77cf09d  nop [rax+rax*1], eax
00007b00b77cf0a5  mov eax, 0x4106FC
00007b00b77cf0aa  mov [r15+0x100], rax
00007b00b77cf0b1  jmp 0x00007B00B75FE110
00007b00b77cf0b6  int3
00007b00b77cf0b7  call 0x00007B00B760D860
00007b00b77cf0bc  jmp 0x00007B00B77CEFDA
00007b00b77cf0c1  call 0x00007B00B76B36E0
00007b00b77cf0c6  jmp 0x00007B00B77CF00A
00007b00b77cf0cb  call 0x00007B00B760DD60
00007b00b77cf0d0  jmp 0x00007B00B77CF024
00007b00b77cf0d5  call 0x00007B00B760DC20
00007b00b77cf0da  jmp 0x00007B00B77CF02E
00007b00b77cf0df  int3
00007b00b77cf0e0  mov rax, [r15+0x10]
00007b00b77cf0e4  lea r14, [rax-0x01]
00007b00b77cf0e8  mov [r15+0x10], r14
00007b00b77cf0ec  test r14, r14
00007b00b77cf0ef  setz r14b
00007b00b77cf0f3  movzx r14, r14b
00007b00b77cf0f7  mov [rsp+0x414], r14b
00007b00b77cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007b00b77cf107  jz 0x00007B00B77CF139
00007b00b77cf109  cmp dword ptr [r15+0x318], 0x00
00007b00b77cf111  jz 0x00007B00B77D0670
00007b00b77cf117  nop [rax+rax*1], ax
00007b00b77cf120  nop [rax+rax*1], eax
00007b00b77cf128  mov eax, 0x41091C
00007b00b77cf12d  mov [r15+0x100], rax
00007b00b77cf134  jmp 0x00007B00B75FE110
00007b00b77cf139  cmp dword ptr [r15+0x318], 0x00
00007b00b77cf141  jz 0x00007B00B77CEFD0
00007b00b77cf147  nop [rax+rax*1], ax
00007b00b77cf150  nop [rax+rax*1], eax
00007b00b77cf158  mov eax, 0x410704
00007b00b77cf15d  mov [r15+0x100], rax
00007b00b77cf164  jmp 0x00007B00B75FE110
00007b00b77cf169  int3
00007b00b77cf16a  int3
00007b00b77cf16b  nop [rax+rax*1], eax
00007b00b77cf170  mov rax, [r15+0x40]
00007b00b77cf174  movzx r14d, byte ptr [r13+rax*1]
00007b00b77cf17a  movaps xmm1, [r15+0x110]
00007b00b77cf182  pinsrb xmm1, r14d, 0x00
00007b00b77cf189  lea r14, [rax+0x01]
00007b00b77cf18d  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf193  movaps xmm15, [r15+0x120]
00007b00b77cf19b  pinsrb xmm15, r12d, 0x00
00007b00b77cf1a2  lea r14, [rax+0x02]
00007b00b77cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf1ac  movaps xmm14, [r15+0x130]
00007b00b77cf1b4  pinsrb xmm14, r12d, 0x00
00007b00b77cf1bb  lea r14, [rax+0x03]
00007b00b77cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf1c5  movaps xmm13, [r15+0x140]
00007b00b77cf1cd  pinsrb xmm13, r12d, 0x00
00007b00b77cf1d4  lea r14, [rax+0x04]
00007b00b77cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf1de  pinsrb xmm1, r12d, 0x01
00007b00b77cf1e5  lea r14, [rax+0x05]
00007b00b77cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf1ef  pinsrb xmm15, r12d, 0x01
00007b00b77cf1f6  lea r14, [rax+0x06]
00007b00b77cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf200  pinsrb xmm14, r12d, 0x01
00007b00b77cf207  lea r14, [rax+0x07]
00007b00b77cf20b  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf211  pinsrb xmm13, r12d, 0x01
00007b00b77cf218  lea r14, [rax+0x08]
00007b00b77cf21c  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf222  pinsrb xmm1, r12d, 0x02
00007b00b77cf229  lea r14, [rax+0x09]
00007b00b77cf22d  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf233  pinsrb xmm15, r12d, 0x02
00007b00b77cf23a  lea r14, [rax+0x0A]
00007b00b77cf23e  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf244  pinsrb xmm14, r12d, 0x02
00007b00b77cf24b  lea r14, [rax+0x0B]
00007b00b77cf24f  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf255  pinsrb xmm13, r12d, 0x02
00007b00b77cf25c  lea r14, [rax+0x0C]
00007b00b77cf260  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf266  pinsrb xmm1, r12d, 0x03
00007b00b77cf26d  lea r14, [rax+0x0D]
00007b00b77cf271  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf277  pinsrb xmm15, r12d, 0x03
00007b00b77cf27e  lea r14, [rax+0x0E]
00007b00b77cf282  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf288  pinsrb xmm14, r12d, 0x03
00007b00b77cf28f  lea r14, [rax+0x0F]
00007b00b77cf293  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf299  pinsrb xmm13, r12d, 0x03
00007b00b77cf2a0  lea r14, [rax+0x10]
00007b00b77cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf2aa  pinsrb xmm1, r12d, 0x04
00007b00b77cf2b1  lea r14, [rax+0x11]
00007b00b77cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf2bb  pinsrb xmm15, r12d, 0x04
00007b00b77cf2c2  lea r14, [rax+0x12]
00007b00b77cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf2cc  pinsrb xmm14, r12d, 0x04
00007b00b77cf2d3  lea r14, [rax+0x13]
00007b00b77cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf2dd  pinsrb xmm13, r12d, 0x04
00007b00b77cf2e4  lea r14, [rax+0x14]
00007b00b77cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf2ee  pinsrb xmm1, r12d, 0x05
00007b00b77cf2f5  lea r14, [rax+0x15]
00007b00b77cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf2ff  pinsrb xmm15, r12d, 0x05
00007b00b77cf306  lea r14, [rax+0x16]
00007b00b77cf30a  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf310  pinsrb xmm14, r12d, 0x05
00007b00b77cf317  lea r14, [rax+0x17]
00007b00b77cf31b  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf321  pinsrb xmm13, r12d, 0x05
00007b00b77cf328  lea r14, [rax+0x18]
00007b00b77cf32c  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf332  pinsrb xmm1, r12d, 0x06
00007b00b77cf339  lea r14, [rax+0x19]
00007b00b77cf33d  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf343  pinsrb xmm15, r12d, 0x06
00007b00b77cf34a  lea r14, [rax+0x1A]
00007b00b77cf34e  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf354  pinsrb xmm14, r12d, 0x06
00007b00b77cf35b  lea r14, [rax+0x1B]
00007b00b77cf35f  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf365  pinsrb xmm13, r12d, 0x06
00007b00b77cf36c  lea r14, [rax+0x1C]
00007b00b77cf370  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf376  pinsrb xmm1, r12d, 0x07
00007b00b77cf37d  lea r14, [rax+0x1D]
00007b00b77cf381  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf387  pinsrb xmm15, r12d, 0x07
00007b00b77cf38e  lea r14, [rax+0x1E]
00007b00b77cf392  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf398  pinsrb xmm14, r12d, 0x07
00007b00b77cf39f  lea r14, [rax+0x1F]
00007b00b77cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf3a9  pinsrb xmm13, r12d, 0x07
00007b00b77cf3b0  lea r14, [rax+0x20]
00007b00b77cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf3ba  pinsrb xmm1, r12d, 0x08
00007b00b77cf3c1  lea r14, [rax+0x21]
00007b00b77cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf3cb  pinsrb xmm15, r12d, 0x08
00007b00b77cf3d2  lea r14, [rax+0x22]
00007b00b77cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf3dc  pinsrb xmm14, r12d, 0x08
00007b00b77cf3e3  lea r14, [rax+0x23]
00007b00b77cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf3ed  pinsrb xmm13, r12d, 0x08
00007b00b77cf3f4  lea r14, [rax+0x24]
00007b00b77cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf3fe  pinsrb xmm1, r12d, 0x09
00007b00b77cf405  lea r14, [rax+0x25]
00007b00b77cf409  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf40f  pinsrb xmm15, r12d, 0x09
00007b00b77cf416  lea r14, [rax+0x26]
00007b00b77cf41a  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf420  pinsrb xmm14, r12d, 0x09
00007b00b77cf427  lea r14, [rax+0x27]
00007b00b77cf42b  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf431  pinsrb xmm13, r12d, 0x09
00007b00b77cf438  lea r14, [rax+0x28]
00007b00b77cf43c  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf442  pinsrb xmm1, r12d, 0x0A
00007b00b77cf449  lea r14, [rax+0x29]
00007b00b77cf44d  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf453  pinsrb xmm15, r12d, 0x0A
00007b00b77cf45a  lea r14, [rax+0x2A]
00007b00b77cf45e  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf464  pinsrb xmm14, r12d, 0x0A
00007b00b77cf46b  lea r14, [rax+0x2B]
00007b00b77cf46f  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf475  pinsrb xmm13, r12d, 0x0A
00007b00b77cf47c  lea r14, [rax+0x2C]
00007b00b77cf480  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf486  pinsrb xmm1, r12d, 0x0B
00007b00b77cf48d  lea r14, [rax+0x2D]
00007b00b77cf491  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf497  pinsrb xmm15, r12d, 0x0B
00007b00b77cf49e  lea r14, [rax+0x2E]
00007b00b77cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf4a8  pinsrb xmm14, r12d, 0x0B
00007b00b77cf4af  lea r14, [rax+0x2F]
00007b00b77cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf4b9  pinsrb xmm13, r12d, 0x0B
00007b00b77cf4c0  lea r14, [rax+0x30]
00007b00b77cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf4ca  pinsrb xmm1, r12d, 0x0C
00007b00b77cf4d1  lea r14, [rax+0x31]
00007b00b77cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf4db  pinsrb xmm15, r12d, 0x0C
00007b00b77cf4e2  lea r14, [rax+0x32]
00007b00b77cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf4ec  pinsrb xmm14, r12d, 0x0C
00007b00b77cf4f3  lea r14, [rax+0x33]
00007b00b77cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf4fd  pinsrb xmm13, r12d, 0x0C
00007b00b77cf504  lea r14, [rax+0x34]
00007b00b77cf508  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf50e  pinsrb xmm1, r12d, 0x0D
00007b00b77cf515  lea r14, [rax+0x35]
00007b00b77cf519  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf51f  pinsrb xmm15, r12d, 0x0D
00007b00b77cf526  lea r14, [rax+0x36]
00007b00b77cf52a  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf530  pinsrb xmm14, r12d, 0x0D
00007b00b77cf537  lea r14, [rax+0x37]
00007b00b77cf53b  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf541  pinsrb xmm13, r12d, 0x0D
00007b00b77cf548  lea r14, [rax+0x38]
00007b00b77cf54c  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf552  pinsrb xmm1, r12d, 0x0E
00007b00b77cf559  lea r14, [rax+0x39]
00007b00b77cf55d  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf563  pinsrb xmm15, r12d, 0x0E
00007b00b77cf56a  lea r14, [rax+0x3A]
00007b00b77cf56e  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf574  pinsrb xmm14, r12d, 0x0E
00007b00b77cf57b  lea r14, [rax+0x3B]
00007b00b77cf57f  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf585  pinsrb xmm13, r12d, 0x0E
00007b00b77cf58c  lea r14, [rax+0x3C]
00007b00b77cf590  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf596  pinsrb xmm1, r12d, 0x0F
00007b00b77cf59d  movaps [r15+0x110], xmm1
00007b00b77cf5a5  lea r14, [rax+0x3D]
00007b00b77cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf5af  pinsrb xmm15, r12d, 0x0F
00007b00b77cf5b6  movaps [r15+0x120], xmm15
00007b00b77cf5be  lea r14, [rax+0x3E]
00007b00b77cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007b00b77cf5c8  pinsrb xmm14, r12d, 0x0F
00007b00b77cf5cf  movaps [r15+0x130], xmm14
00007b00b77cf5d7  lea r14, [rax+0x3F]
00007b00b77cf5db  movzx eax, byte ptr [r13+r14*1]
00007b00b77cf5e1  pinsrb xmm13, eax, 0x0F
00007b00b77cf5e8  movaps [r15+0x140], xmm13
00007b00b77cf5f0  movq xmm1, qword ptr [r15+0x120]
00007b00b77cf5f9  pmovzxbw xmm1, xmm1
00007b00b77cf5fe  psllw xmm1, 0x00
00007b00b77cf603  movaps [r15+0x150], xmm1
00007b00b77cf60b  movq xmm1, qword ptr [r15+0x130]
00007b00b77cf614  pmovzxbw xmm1, xmm1
00007b00b77cf619  psllw xmm1, 0x00
00007b00b77cf61e  movaps [r15+0x160], xmm1
00007b00b77cf626  movq xmm1, qword ptr [r15+0x110]
00007b00b77cf62f  pmovzxbw xmm1, xmm1
00007b00b77cf634  psllw xmm1, 0x00
00007b00b77cf639  movaps [r15+0x170], xmm1
00007b00b77cf641  movaps xmm15, [r15+0x110]
00007b00b77cf649  pextrq rax, xmm15, 0x01
00007b00b77cf650  movq xmm15, rax
00007b00b77cf655  pmovzxbw xmm15, xmm15
00007b00b77cf65b  psllw xmm15, 0x00
00007b00b77cf661  movaps [r15+0x180], xmm15
00007b00b77cf669  movaps xmm14, [r15+0x120]
00007b00b77cf671  pextrq rax, xmm14, 0x01
00007b00b77cf678  movq xmm14, rax
00007b00b77cf67d  pmovzxbw xmm14, xmm14
00007b00b77cf683  psllw xmm14, 0x00
00007b00b77cf689  movaps [r15+0x210], xmm14
00007b00b77cf691  movaps xmm13, [r15+0x130]
00007b00b77cf699  pextrq rax, xmm13, 0x01
00007b00b77cf6a0  movq xmm13, rax
00007b00b77cf6a5  pmovzxbw xmm13, xmm13
00007b00b77cf6ab  psllw xmm13, 0x00
00007b00b77cf6b1  movaps [r15+0x220], xmm13
00007b00b77cf6b9  movq xmm12, qword ptr [r15+0x140]
00007b00b77cf6c2  pmovzxbw xmm12, xmm12
00007b00b77cf6c8  psllw xmm12, 0x00
00007b00b77cf6ce  movaps [r15+0x250], xmm12
00007b00b77cf6d6  movaps xmm12, [r15+0x140]
00007b00b77cf6de  pextrq rax, xmm12, 0x01
00007b00b77cf6e5  movq xmm12, rax
00007b00b77cf6ea  pmovzxbw xmm12, xmm12
00007b00b77cf6f0  psllw xmm12, 0x00
00007b00b77cf6f6  movaps [r15+0x110], xmm12
00007b00b77cf6fe  movq xmm11, qword ptr [r15+0x150]
00007b00b77cf707  pmovzxwd xmm11, xmm11
00007b00b77cf70d  pslld xmm11, 0x10
00007b00b77cf713  movq xmm10, qword ptr [r15+0x160]
00007b00b77cf71c  pmovzxwd xmm10, xmm10
00007b00b77cf722  pslld xmm10, 0x08
00007b00b77cf728  pextrq rax, xmm1, 0x01
00007b00b77cf72f  movq xmm1, rax
00007b00b77cf734  pmovzxwd xmm1, xmm1
00007b00b77cf739  pslld xmm1, 0x00
00007b00b77cf73e  movaps [r15+0x260], xmm1
00007b00b77cf746  pextrq rax, xmm15, 0x01
00007b00b77cf74d  movq xmm15, rax
00007b00b77cf752  pmovzxwd xmm15, xmm15
00007b00b77cf758  pslld xmm15, 0x00
00007b00b77cf75e  movaps [r15+0x270], xmm15
00007b00b77cf766  movq xmm9, qword ptr [r15+0x170]
00007b00b77cf76f  pmovzxwd xmm9, xmm9
00007b00b77cf775  pslld xmm9, 0x00
00007b00b77cf77b  pextrq rax, xmm14, 0x01
00007b00b77cf782  movq xmm14, rax
00007b00b77cf787  pmovzxwd xmm14, xmm14
00007b00b77cf78d  pslld xmm14, 0x10
00007b00b77cf793  movaps [r15+0x280], xmm14
00007b00b77cf79b  movq xmm8, qword ptr [r15+0x180]
00007b00b77cf7a4  pmovzxwd xmm8, xmm8
00007b00b77cf7aa  pslld xmm8, 0x00
00007b00b77cf7b0  movq xmm7, qword ptr [r15+0x210]
00007b00b77cf7b9  pmovzxwd xmm7, xmm7
00007b00b77cf7be  pslld xmm7, 0x10
00007b00b77cf7c3  movaps xmm6, [r15+0x150]
00007b00b77cf7cb  pextrq rax, xmm6, 0x01
00007b00b77cf7d2  movq xmm6, rax
00007b00b77cf7d7  pmovzxwd xmm6, xmm6
00007b00b77cf7dc  pslld xmm6, 0x10
00007b00b77cf7e1  por xmm11, xmm10
00007b00b77cf7e6  movaps [r15+0x230], xmm11
00007b00b77cf7ee  pextrq rax, xmm13, 0x01
00007b00b77cf7f5  movq xmm13, rax
00007b00b77cf7fa  pmovzxwd xmm13, xmm13
00007b00b77cf800  pslld xmm13, 0x08
00007b00b77cf806  movaps [r15+0x240], xmm13
00007b00b77cf80e  movq xmm10, qword ptr [r15+0x220]
00007b00b77cf817  pmovzxwd xmm10, xmm10
00007b00b77cf81d  pslld xmm10, 0x08
00007b00b77cf823  movaps xmm5, [r15+0x160]
00007b00b77cf82b  pextrq rax, xmm5, 0x01
00007b00b77cf832  movq xmm5, rax
00007b00b77cf837  pmovzxwd xmm5, xmm5
00007b00b77cf83c  pslld xmm5, 0x08
00007b00b77cf841  pslld xmm9, 0x18
00007b00b77cf847  pslld xmm15, 0x18
00007b00b77cf84d  pslld xmm8, 0x18
00007b00b77cf853  movq xmm4, qword ptr [r15+0x250]
00007b00b77cf85c  pmovzxwd xmm4, xmm4
00007b00b77cf861  pslld xmm4, 0x00
00007b00b77cf866  por xmm14, xmm13
00007b00b77cf86b  por xmm7, xmm10
00007b00b77cf870  movaps [r15+0x210], xmm7
00007b00b77cf878  pslld xmm1, 0x18
00007b00b77cf87d  movaps [r15+0x220], xmm1
00007b00b77cf885  por xmm6, xmm5
00007b00b77cf889  por xmm11, xmm9
00007b00b77cf88e  movaps [r15+0x160], xmm11
00007b00b77cf896  pextrq rax, xmm12, 0x01
00007b00b77cf89d  movq xmm13, rax
00007b00b77cf8a2  pmovzxwd xmm13, xmm13
00007b00b77cf8a8  pslld xmm13, 0x00
00007b00b77cf8ae  movaps [r15+0x170], xmm13
00007b00b77cf8b6  movq xmm12, qword ptr [r15+0x110]
00007b00b77cf8bf  pmovzxwd xmm12, xmm12
00007b00b77cf8c5  pslld xmm12, 0x00
00007b00b77cf8cb  por xmm14, xmm15
00007b00b77cf8d0  por xmm7, xmm8
00007b00b77cf8d5  movaps xmm15, [r15+0x250]
00007b00b77cf8dd  pextrq rax, xmm15, 0x01
00007b00b77cf8e4  movq xmm15, rax
00007b00b77cf8e9  pmovzxwd xmm15, xmm15
00007b00b77cf8ef  pslld xmm15, 0x00
00007b00b77cf8f5  movaps [r15+0x180], xmm15
00007b00b77cf8fd  por xmm6, xmm1
00007b00b77cf901  movaps [r15+0x150], xmm6
00007b00b77cf909  por xmm11, xmm4
00007b00b77cf90e  movaps [r15+0x140], xmm11
00007b00b77cf916  por xmm7, xmm12
00007b00b77cf91b  movaps [r15+0x110], xmm7
00007b00b77cf923  por xmm14, xmm13
00007b00b77cf928  movaps [r15+0x120], xmm14
00007b00b77cf930  por xmm6, xmm15
00007b00b77cf935  movaps [r15+0x130], xmm6
00007b00b77cf93d  mov rax, [r15+0xF8]
00007b00b77cf944  lea r14, [rax+0x20]
00007b00b77cf948  movups [r13+r14*1], xmm7
00007b00b77cf94e  lea r14, [rax+0x30]
00007b00b77cf952  movups [r13+r14*1], xmm14
00007b00b77cf958  movups [r13+rax*1], xmm11
00007b00b77cf95e  lea r14, [rax+0x10]
00007b00b77cf962  movups [r13+r14*1], xmm6
00007b00b77cf968  mov r14d, [r13+rax*1]
00007b00b77cf96d  mov rax, [r15+0x48]
00007b00b77cf971  mov [r15+0x68], rax
00007b00b77cf975  mov qword ptr [r15+0x58], 0x04
00007b00b77cf97d  lea r12, [rax+0x04]
00007b00b77cf981  mov r11d, [r13+r12*1]
00007b00b77cf986  mov [rsp+0x10], r11d
00007b00b77cf98b  mov r11d, r11d
00007b00b77cf98e  mov [r15+0x70], r11
00007b00b77cf992  lea r12, [rax+0x38]
00007b00b77cf996  mov r11d, [r13+r12*1]
00007b00b77cf99b  lea r12, [rax+0x24]
00007b00b77cf99f  mov r10d, [r13+r12*1]
00007b00b77cf9a4  mov [rsp+0x20], r10d
00007b00b77cf9a9  mov r10d, r10d
00007b00b77cf9ac  mov [r15+0x90], r10
00007b00b77cf9b3  mov [rsp+0x30], rax
00007b00b77cf9b8  xor eax, eax
00007b00b77cf9ba  mov r12d, 0x04
00007b00b77cf9c0  mov r10d, 0xC0
00007b00b77cf9c6  cmp r12, r10
00007b00b77cf9c9  cmc
00007b00b77cf9ca  lahf
00007b00b77cf9cb  seto al
00007b00b77cf9ce  mov [r15+0x108], eax
00007b00b77cf9d5  mov eax, [rsp+0x10]
00007b00b77cf9d9  mov r12d, [rsp+0x10]
00007b00b77cf9de  shrd eax, r12d, 0x07
00007b00b77cf9e3  mov [rsp+0x10], r11d
00007b00b77cf9e8  mov r10d, [rsp+0x10]
00007b00b77cf9ed  shrd r11d, r10d, 0x11
00007b00b77cf9f2  mov r9d, [rsp+0x20]
00007b00b77cf9f7  lea r8d, [r9d+r14d*1]
00007b00b77cf9fc  rorx r14d, r12d, 0x12
00007b00b77cfa02  xor eax, r14d
00007b00b77cfa05  rorx r14d, r10d, 0x13
00007b00b77cfa0b  xor r11d, r14d
00007b00b77cfa0e  mov [rsp+0x10], r11d
00007b00b77cfa13  mov r11d, r11d
00007b00b77cfa16  mov [r15+0x88], r11
00007b00b77cfa1d  mov [rsp+0x20], r12d
00007b00b77cfa22  shr r12d, 0x03
00007b00b77cfa26  xor eax, r12d
00007b00b77cfa29  mov [rsp+0x40], eax
00007b00b77cfa2d  mov eax, eax
00007b00b77cfa2f  mov [r15+0x80], rax
00007b00b77cfa36  shr r10d, 0x0A
00007b00b77cfa3a  mov eax, [rsp+0x10]
00007b00b77cfa3e  xor eax, r10d
00007b00b77cfa41  mov [rsp+0x10], eax
00007b00b77cfa45  mov eax, eax
00007b00b77cfa47  mov [r15+0x78], rax
00007b00b77cfa4b  mov eax, [rsp+0x40]
00007b00b77cfa4f  lea r14d, [r8d+eax*1]
00007b00b77cfa54  mov eax, [rsp+0x10]
00007b00b77cfa58  lea r12d, [r14d+eax*1]
00007b00b77cfa5d  mov rax, [rsp+0x30]
00007b00b77cfa62  lea r14, [rax+0x40]
00007b00b77cfa66  mov [r13+r14*1], r12d
00007b00b77cfa6b  mov eax, [rsp+0x20]
00007b00b77cfa6f  mov eax, eax
00007b00b77cfa71  mov [r15+0x60], rax
00007b00b77cfa75  mov eax, [r15+0x108]
00007b00b77cfa7c  sahf
00007b00b77cfa7d  jnz 0x00007B00B77CFAAF
00007b00b77cfa7f  cmp dword ptr [r15+0x318], 0x00
00007b00b77cfa87  jz 0x00007B00B77CFF70
00007b00b77cfa8d  nop [rax+rax*1], ax
00007b00b77cfa96  nop [rax+rax*1], eax
00007b00b77cfa9e  mov eax, 0x410820
00007b00b77cfaa3  mov [r15+0x100], rax
00007b00b77cfaaa  jmp 0x00007B00B75FE110
00007b00b77cfaaf  cmp dword ptr [r15+0x318], 0x00
00007b00b77cfab7  jz 0x00007B00B77CFDC0
00007b00b77cfabd  nop [rax+rax*1], ax
00007b00b77cfac6  nop [rax+rax*1], eax
00007b00b77cface  mov eax, 0x4107D8
00007b00b77cfad3  mov [r15+0x100], rax
00007b00b77cfada  jmp 0x00007B00B75FE110
00007b00b77cfadf  int3
00007b00b77cfae0  call 0x00007B00B760D860
00007b00b77cfae5  jmp 0x00007B00B77CF17A
00007b00b77cfaea  call 0x00007B00B76E2420
00007b00b77cfaef  jmp 0x00007B00B77CF193
00007b00b77cfaf4  call 0x00007B00B76E2420
00007b00b77cfaf9  jmp 0x00007B00B77CF1AC
00007b00b77cfafe  call 0x00007B00B76E2420
00007b00b77cfb03  jmp 0x00007B00B77CF1C5
00007b00b77cfb08  call 0x00007B00B76E2420
00007b00b77cfb0d  jmp 0x00007B00B77CF1DE
00007b00b77cfb12  call 0x00007B00B76E2420
00007b00b77cfb17  jmp 0x00007B00B77CF1EF
00007b00b77cfb1c  call 0x00007B00B76E2420
00007b00b77cfb21  jmp 0x00007B00B77CF200
00007b00b77cfb26  call 0x00007B00B76E2420
00007b00b77cfb2b  jmp 0x00007B00B77CF211
00007b00b77cfb30  call 0x00007B00B76E2420
00007b00b77cfb35  jmp 0x00007B00B77CF222
00007b00b77cfb3a  call 0x00007B00B76E2420
00007b00b77cfb3f  jmp 0x00007B00B77CF233
00007b00b77cfb44  call 0x00007B00B76E2420
00007b00b77cfb49  jmp 0x00007B00B77CF244
00007b00b77cfb4e  call 0x00007B00B76E2420
00007b00b77cfb53  jmp 0x00007B00B77CF255
00007b00b77cfb58  call 0x00007B00B76E2420
00007b00b77cfb5d  jmp 0x00007B00B77CF266
00007b00b77cfb62  call 0x00007B00B76E2420
00007b00b77cfb67  jmp 0x00007B00B77CF277
00007b00b77cfb6c  call 0x00007B00B76E2420
00007b00b77cfb71  jmp 0x00007B00B77CF288
00007b00b77cfb76  call 0x00007B00B76E2420
00007b00b77cfb7b  jmp 0x00007B00B77CF299
00007b00b77cfb80  call 0x00007B00B76E2420
00007b00b77cfb85  jmp 0x00007B00B77CF2AA
00007b00b77cfb8a  call 0x00007B00B76E2420
00007b00b77cfb8f  jmp 0x00007B00B77CF2BB
00007b00b77cfb94  call 0x00007B00B76E2420
00007b00b77cfb99  jmp 0x00007B00B77CF2CC
00007b00b77cfb9e  call 0x00007B00B76E2420
00007b00b77cfba3  jmp 0x00007B00B77CF2DD
00007b00b77cfba8  call 0x00007B00B76E2420
00007b00b77cfbad  jmp 0x00007B00B77CF2EE
00007b00b77cfbb2  call 0x00007B00B76E2420
00007b00b77cfbb7  jmp 0x00007B00B77CF2FF
00007b00b77cfbbc  call 0x00007B00B76E2420
00007b00b77cfbc1  jmp 0x00007B00B77CF310
00007b00b77cfbc6  call 0x00007B00B76E2420
00007b00b77cfbcb  jmp 0x00007B00B77CF321
00007b00b77cfbd0  call 0x00007B00B76E2420
00007b00b77cfbd5  jmp 0x00007B00B77CF332
00007b00b77cfbda  call 0x00007B00B76E2420
00007b00b77cfbdf  jmp 0x00007B00B77CF343
00007b00b77cfbe4  call 0x00007B00B76E2420
00007b00b77cfbe9  jmp 0x00007B00B77CF354
00007b00b77cfbee  call 0x00007B00B76E2420
00007b00b77cfbf3  jmp 0x00007B00B77CF365
00007b00b77cfbf8  call 0x00007B00B76E2420
00007b00b77cfbfd  jmp 0x00007B00B77CF376
00007b00b77cfc02  call 0x00007B00B76E2420
00007b00b77cfc07  jmp 0x00007B00B77CF387
00007b00b77cfc0c  call 0x00007B00B76E2420
00007b00b77cfc11  jmp 0x00007B00B77CF398
00007b00b77cfc16  call 0x00007B00B76E2420
00007b00b77cfc1b  jmp 0x00007B00B77CF3A9
00007b00b77cfc20  call 0x00007B00B76E2420
00007b00b77cfc25  jmp 0x00007B00B77CF3BA
00007b00b77cfc2a  call 0x00007B00B76E2420
00007b00b77cfc2f  jmp 0x00007B00B77CF3CB
00007b00b77cfc34  call 0x00007B00B76E2420
00007b00b77cfc39  jmp 0x00007B00B77CF3DC
00007b00b77cfc3e  call 0x00007B00B76E2420
00007b00b77cfc43  jmp 0x00007B00B77CF3ED
00007b00b77cfc48  call 0x00007B00B76E2420
00007b00b77cfc4d  jmp 0x00007B00B77CF3FE
00007b00b77cfc52  call 0x00007B00B76E2420
00007b00b77cfc57  jmp 0x00007B00B77CF40F
00007b00b77cfc5c  call 0x00007B00B76E2420
00007b00b77cfc61  jmp 0x00007B00B77CF420
00007b00b77cfc66  call 0x00007B00B76E2420
00007b00b77cfc6b  jmp 0x00007B00B77CF431
00007b00b77cfc70  call 0x00007B00B76E2420
00007b00b77cfc75  jmp 0x00007B00B77CF442
00007b00b77cfc7a  call 0x00007B00B76E2420
00007b00b77cfc7f  jmp 0x00007B00B77CF453
00007b00b77cfc84  call 0x00007B00B76E2420
00007b00b77cfc89  jmp 0x00007B00B77CF464
00007b00b77cfc8e  call 0x00007B00B76E2420
00007b00b77cfc93  jmp 0x00007B00B77CF475
00007b00b77cfc98  call 0x00007B00B76E2420
00007b00b77cfc9d  jmp 0x00007B00B77CF486
00007b00b77cfca2  call 0x00007B00B76E2420
00007b00b77cfca7  jmp 0x00007B00B77CF497
00007b00b77cfcac  call 0x00007B00B76E2420
00007b00b77cfcb1  jmp 0x00007B00B77CF4A8
00007b00b77cfcb6  call 0x00007B00B76E2420
00007b00b77cfcbb  jmp 0x00007B00B77CF4B9
00007b00b77cfcc0  call 0x00007B00B76E2420
00007b00b77cfcc5  jmp 0x00007B00B77CF4CA
00007b00b77cfcca  call 0x00007B00B76E2420
00007b00b77cfccf  jmp 0x00007B00B77CF4DB
00007b00b77cfcd4  call 0x00007B00B76E2420
00007b00b77cfcd9  jmp 0x00007B00B77CF4EC
00007b00b77cfcde  call 0x00007B00B76E2420
00007b00b77cfce3  jmp 0x00007B00B77CF4FD
00007b00b77cfce8  call 0x00007B00B76E2420
00007b00b77cfced  jmp 0x00007B00B77CF50E
00007b00b77cfcf2  call 0x00007B00B76E2420
00007b00b77cfcf7  jmp 0x00007B00B77CF51F
00007b00b77cfcfc  call 0x00007B00B76E2420
00007b00b77cfd01  jmp 0x00007B00B77CF530
00007b00b77cfd06  call 0x00007B00B76E2420
00007b00b77cfd0b  jmp 0x00007B00B77CF541
00007b00b77cfd10  call 0x00007B00B76E2420
00007b00b77cfd15  jmp 0x00007B00B77CF552
00007b00b77cfd1a  call 0x00007B00B76E2420
00007b00b77cfd1f  jmp 0x00007B00B77CF563
00007b00b77cfd24  call 0x00007B00B76E2420
00007b00b77cfd29  jmp 0x00007B00B77CF574
00007b00b77cfd2e  call 0x00007B00B76E2420
00007b00b77cfd33  jmp 0x00007B00B77CF585
00007b00b77cfd38  call 0x00007B00B76E2420
00007b00b77cfd3d  jmp 0x00007B00B77CF596
00007b00b77cfd42  call 0x00007B00B76E2420
00007b00b77cfd47  jmp 0x00007B00B77CF5AF
00007b00b77cfd4c  call 0x00007B00B76E2420
00007b00b77cfd51  jmp 0x00007B00B77CF5C8
00007b00b77cfd56  call 0x00007B00B76D5610
00007b00b77cfd5b  jmp 0x00007B00B77CF5E1
00007b00b77cfd60  call 0x00007B00B76DC580
00007b00b77cfd65  jmp 0x00007B00B77CF94E
00007b00b77cfd6a  call 0x00007B00B76E46C0
00007b00b77cfd6f  jmp 0x00007B00B77CF958
00007b00b77cfd74  call 0x00007B00B7609E90
00007b00b77cfd79  jmp 0x00007B00B77CF95E
00007b00b77cfd7e  call 0x00007B00B76DB310
00007b00b77cfd83  jmp 0x00007B00B77CF968
00007b00b77cfd88  call 0x00007B00B760DAE0
00007b00b77cfd8d  jmp 0x00007B00B77CF96D
00007b00b77cfd92  call 0x00007B00B76C0230
00007b00b77cfd97  jmp 0x00007B00B77CF986
00007b00b77cfd9c  call 0x00007B00B76C0230
00007b00b77cfda1  jmp 0x00007B00B77CF99B
00007b00b77cfda6  call 0x00007B00B76BEFC0
00007b00b77cfdab  jmp 0x00007B00B77CF9A4
00007b00b77cfdb0  call 0x00007B00B76E2BA0
00007b00b77cfdb5  jmp 0x00007B00B77CFA6B
00007b00b77cfdba  int3
00007b00b77cfdbb  nop [rax+rax*1], eax
00007b00b77cfdc0  mov rax, [r15+0x48]
00007b00b77cfdc4  mov r14, [r15+0x58]
00007b00b77cfdc8  lea r12, [rax+r14*1]
00007b00b77cfdcc  mov [r15+0x68], r12
00007b00b77cfdd0  lea rax, [r14+0x04]
00007b00b77cfdd4  mov [r15+0x58], rax
00007b00b77cfdd8  lea r14, [r12+0x04]
00007b00b77cfddd  mov r11d, [r13+r14*1]
00007b00b77cfde2  mov [rsp+0x10], r11d
00007b00b77cfde7  mov r11d, r11d
00007b00b77cfdea  mov [r15+0x70], r11
00007b00b77cfdee  lea r14, [r12+0x38]
00007b00b77cfdf3  mov r11d, [r13+r14*1]
00007b00b77cfdf8  lea r14, [r12+0x24]
00007b00b77cfdfd  mov r10d, [r13+r14*1]
00007b00b77cfe02  mov [rsp+0x20], r10d
00007b00b77cfe07  mov r10d, r10d
00007b00b77cfe0a  mov [r15+0x90], r10
00007b00b77cfe11  mov [rsp+0x30], rax
00007b00b77cfe16  xor eax, eax
00007b00b77cfe18  mov r14, [rsp+0x30]
00007b00b77cfe1d  mov r10d, 0xC0
00007b00b77cfe23  cmp r14, r10
00007b00b77cfe26  cmc
00007b00b77cfe27  lahf
00007b00b77cfe28  seto al
00007b00b77cfe2b  mov [r15+0x108], eax
00007b00b77cfe32  mov eax, [rsp+0x10]
00007b00b77cfe36  mov r14d, [rsp+0x10]
00007b00b77cfe3b  shrd eax, r14d, 0x07
00007b00b77cfe40  mov [rsp+0x10], r11d
00007b00b77cfe45  mov r10d, [rsp+0x10]
00007b00b77cfe4a  shrd r11d, r10d, 0x11
00007b00b77cfe4f  mov r9d, [r15+0x60]
00007b00b77cfe53  mov r8d, [rsp+0x20]
00007b00b77cfe58  lea ebp, [r8d+r9d*1]
00007b00b77cfe5d  rorx r9d, r14d, 0x12
00007b00b77cfe63  xor eax, r9d
00007b00b77cfe66  rorx r9d, r10d, 0x13
00007b00b77cfe6c  xor r11d, r9d
00007b00b77cfe6f  mov [rsp+0x10], r11d
00007b00b77cfe74  mov r11d, r11d
00007b00b77cfe77  mov [r15+0x88], r11
00007b00b77cfe7e  mov [rsp+0x20], r14d
00007b00b77cfe83  shr r14d, 0x03
00007b00b77cfe87  xor eax, r14d
00007b00b77cfe8a  mov [rsp+0x30], eax
00007b00b77cfe8e  mov eax, eax
00007b00b77cfe90  mov [r15+0x80], rax
00007b00b77cfe97  shr r10d, 0x0A
00007b00b77cfe9b  mov eax, [rsp+0x10]
00007b00b77cfe9f  xor eax, r10d
00007b00b77cfea2  mov [rsp+0x10], eax
00007b00b77cfea6  mov eax, eax
00007b00b77cfea8  mov [r15+0x78], rax
00007b00b77cfeac  mov eax, [rsp+0x30]
00007b00b77cfeb0  lea r14d, [ebp+eax*1]
00007b00b77cfeb6  mov eax, [rsp+0x10]
00007b00b77cfeba  lea r11d, [r14d+eax*1]
00007b00b77cfebf  lea rax, [r12+0x40]
00007b00b77cfec4  mov [r13+rax*1], r11d
00007b00b77cfec9  mov eax, [rsp+0x20]
00007b00b77cfecd  mov eax, eax
00007b00b77cfecf  mov [r15+0x60], rax
00007b00b77cfed3  mov eax, [r15+0x108]
00007b00b77cfeda  sahf
00007b00b77cfedb  jnz 0x00007B00B77CFF0D
00007b00b77cfedd  cmp dword ptr [r15+0x318], 0x00
00007b00b77cfee5  jz 0x00007B00B77CFF70
00007b00b77cfeeb  nop [rax+rax*1], ax
00007b00b77cfef4  nop [rax+rax*1], eax
00007b00b77cfefc  mov eax, 0x410820
00007b00b77cff01  mov [r15+0x100], rax
00007b00b77cff08  jmp 0x00007B00B75FE110
00007b00b77cff0d  cmp dword ptr [r15+0x318], 0x00
00007b00b77cff15  jz 0x00007B00B77CFDC0
00007b00b77cff1b  nop [rax+rax*1], ax
00007b00b77cff24  nop [rax+rax*1], eax
00007b00b77cff2c  mov eax, 0x4107D8
00007b00b77cff31  mov [r15+0x100], rax
00007b00b77cff38  jmp 0x00007B00B75FE110
00007b00b77cff3d  int3
00007b00b77cff3e  call 0x00007B00B76E1430
00007b00b77cff43  jmp 0x00007B00B77CFDE2
00007b00b77cff48  call 0x00007B00B76E1430
00007b00b77cff4d  jmp 0x00007B00B77CFDF8
00007b00b77cff52  call 0x00007B00B76E01C0
00007b00b77cff57  jmp 0x00007B00B77CFE02
00007b00b77cff5c  call 0x00007B00B760A860
00007b00b77cff61  jmp 0x00007B00B77CFEC9
00007b00b77cff66  int3
00007b00b77cff67  nop [rax+rax*1], ax
00007b00b77cff70  mov rax, [r15]
00007b00b77cff73  mov r14d, [r13+rax*1]
00007b00b77cff78  lea r12, [rax+0x04]
00007b00b77cff7c  mov r11d, [r13+r12*1]
00007b00b77cff81  mov [rsp+0x10], r14d
00007b00b77cff86  mov r14d, r14d
00007b00b77cff89  mov [r15+0x78], r14
00007b00b77cff8d  mov [rsp+0x20], r11d
00007b00b77cff92  mov r11d, r11d
00007b00b77cff95  mov [r15+0x80], r11
00007b00b77cff9c  lea r14, [rax+0x08]
00007b00b77cffa0  mov r12d, [r13+r14*1]
00007b00b77cffa5  lea r14, [rax+0x0C]
00007b00b77cffa9  mov r11d, [r13+r14*1]
00007b00b77cffae  mov [rsp+0x30], r12d
00007b00b77cffb3  mov r12d, r12d
00007b00b77cffb6  mov [r15+0x70], r12
00007b00b77cffba  mov [rsp+0x40], r11d
00007b00b77cffbf  mov r11d, r11d
00007b00b77cffc2  mov [r15+0x68], r11
00007b00b77cffc6  lea r14, [rax+0x18]
00007b00b77cffca  mov r12d, [r13+r14*1]
00007b00b77cffcf  lea r14, [rax+0x1C]
00007b00b77cffd3  mov r11d, [r13+r14*1]
00007b00b77cffd8  mov [rsp+0x50], r12d
00007b00b77cffdd  mov r12d, r12d
00007b00b77cffe0  mov [r15+0x58], r12
00007b00b77cffe4  mov [rsp+0x60], r11d
00007b00b77cffe9  mov r11d, r11d
00007b00b77cffec  mov [r15+0x60], r11
00007b00b77cfff0  lea r14, [rax+0x10]
00007b00b77cfff4  mov r12d, [r13+r14*1]
00007b00b77cfff9  lea r14, [rax+0x14]
00007b00b77cfffd  mov eax, [r13+r14*1]
00007b00b77d0002  mov [rsp+0x70], r12d
00007b00b77d0007  mov r12d, r12d
00007b00b77d000a  mov [r15+0x18], r12
00007b00b77d000e  mov [rsp+0x80], eax
00007b00b77d0015  mov eax, eax
00007b00b77d0017  mov [r15+0x90], rax
00007b00b77d001e  mov eax, [rsp+0x70]
00007b00b77d0022  mov eax, eax
00007b00b77d0024  mov [r15+0x30], rax
00007b00b77d0028  mov eax, [rsp+0x50]
00007b00b77d002c  mov eax, eax
00007b00b77d002e  mov [r15+0xA0], rax
00007b00b77d0035  mov eax, [rsp+0x30]
00007b00b77d0039  mov eax, eax
00007b00b77d003b  mov [r15+0x28], rax
00007b00b77d003f  mov eax, [rsp+0x20]
00007b00b77d0043  mov eax, eax
00007b00b77d0045  mov [r15+0x98], rax
00007b00b77d004c  mov eax, [rsp+0x10]
00007b00b77d0050  mov eax, eax
00007b00b77d0052  mov [r15+0x38], rax
00007b00b77d0056  mov eax, [rsp+0x70]
00007b00b77d005a  mov r14d, [rsp+0x70]
00007b00b77d005f  shrd eax, r14d, 0x06
00007b00b77d0064  mov [rsp+0x70], r14d
00007b00b77d0069  mov r12d, [rsp+0x80]
00007b00b77d0071  and r14d, r12d
00007b00b77d0074  mov r11d, [rsp+0x10]
00007b00b77d0079  mov r10d, [rsp+0x10]
00007b00b77d007e  shrd r11d, r10d, 0x02
00007b00b77d0083  mov [rsp+0x10], r12d
00007b00b77d0088  mov r12d, r12d
00007b00b77d008b  mov [r15+0x20], r12
00007b00b77d008f  mov r12, [r15+0x50]
00007b00b77d0093  mov r9d, [r13+r12*1]
00007b00b77d0098  mov r12d, [rsp+0x50]
00007b00b77d009d  mov r8d, [rsp+0x70]
00007b00b77d00a2  andn ebp, r8d, r12d
00007b00b77d00a7  mov edi, [rsp+0x60]
00007b00b77d00ab  lea esi, [r14d+edi*1]
00007b00b77d00b0  rorx r14d, r8d, 0x0B
00007b00b77d00b6  xor eax, r14d
00007b00b77d00b9  rorx r14d, r10d, 0x0D
00007b00b77d00bf  xor r11d, r14d
00007b00b77d00c2  lea edi, [esi+ebp*1]
00007b00b77d00c6  mov r14, [r15+0x48]
00007b00b77d00ca  mov ebp, [r13+r14*1]
00007b00b77d00cf  mov r14d, [rsp+0x30]
00007b00b77d00d4  mov esi, [rsp+0x20]
00007b00b77d00d8  and r14d, esi
00007b00b77d00db  mov [rsp+0x20], r14d
00007b00b77d00e0  mov r14d, r14d
00007b00b77d00e3  mov [r15+0xD8], r14
00007b00b77d00ea  lea r14d, [edi+r9d*1]
00007b00b77d00ef  mov r9d, [rsp+0x30]
00007b00b77d00f4  xor r9d, esi
00007b00b77d00f7  rorx edi, r8d, 0x19
00007b00b77d00fd  xor eax, edi
00007b00b77d00ff  and r9d, r10d
00007b00b77d0102  rorx edi, r10d, 0x16
00007b00b77d0108  xor r11d, edi
00007b00b77d010b  mov [rsp+0x30], r11d
00007b00b77d0110  mov r11d, r11d
00007b00b77d0113  mov [r15+0xD0], r11
00007b00b77d011a  lea r11d, [r14d+ebp*1]
00007b00b77d011f  mov r10d, [rsp+0x20]
00007b00b77d0124  xor r9d, r10d
00007b00b77d0127  lea r14d, [r11d+eax*1]
00007b00b77d012c  mov qword ptr [r15+0x88], 0x04
00007b00b77d0137  mov eax, [rsp+0x30]
00007b00b77d013b  lea r11d, [r9d+eax*1]
00007b00b77d0140  mov eax, [rsp+0x40]
00007b00b77d0144  lea r10d, [r14d+eax*1]
00007b00b77d0149  mov r10d, r10d
00007b00b77d014c  mov [r15+0xB8], r10
00007b00b77d0153  xor eax, eax
00007b00b77d0155  mov r10d, 0x04
00007b00b77d015b  mov r9d, 0x100
00007b00b77d0161  cmp r10, r9
00007b00b77d0164  cmc
00007b00b77d0165  lahf
00007b00b77d0166  seto al
00007b00b77d0169  mov [r15+0x108], eax
00007b00b77d0170  lea eax, [r11d+r14d*1]
00007b00b77d0175  mov eax, eax
00007b00b77d0177  mov [r15+0xA8], rax
00007b00b77d017e  mov r12d, r12d
00007b00b77d0181  mov [r15+0xB0], r12
00007b00b77d0188  mov eax, [rsp+0x10]
00007b00b77d018c  mov eax, eax
00007b00b77d018e  mov [r15+0xC0], rax
00007b00b77d0195  mov r8d, r8d
00007b00b77d0198  mov [r15+0xC8], r8
00007b00b77d019f  mov eax, [r15+0x108]
00007b00b77d01a6  sahf
00007b00b77d01a7  jnz 0x00007B00B77D01D9
00007b00b77d01a9  cmp dword ptr [r15+0x318], 0x00
00007b00b77d01b1  jz 0x00007B00B77D04A0
00007b00b77d01b7  nop [rax+rax*1], ax
00007b00b77d01c0  nop [rax+rax*1], eax
00007b00b77d01c8  mov eax, 0x4108E0
00007b00b77d01cd  mov [r15+0x100], rax
00007b00b77d01d4  jmp 0x00007B00B75FE110
00007b00b77d01d9  cmp dword ptr [r15+0x318], 0x00
00007b00b77d01e1  jz 0x00007B00B77D0270
00007b00b77d01e7  nop [rax+rax*1], ax
00007b00b77d01f0  nop [rax+rax*1], eax
00007b00b77d01f8  mov eax, 0x410854
00007b00b77d01fd  mov [r15+0x100], rax
00007b00b77d0204  jmp 0x00007B00B75FE110
00007b00b77d0209  int3
00007b00b77d020a  call 0x00007B00B760DAE0
00007b00b77d020f  jmp 0x00007B00B77CFF78
00007b00b77d0214  call 0x00007B00B76C0230
00007b00b77d0219  jmp 0x00007B00B77CFF81
00007b00b77d021e  call 0x00007B00B76E26A0
00007b00b77d0223  jmp 0x00007B00B77CFFA5
00007b00b77d0228  call 0x00007B00B76E1430
00007b00b77d022d  jmp 0x00007B00B77CFFAE
00007b00b77d0232  call 0x00007B00B76E26A0
00007b00b77d0237  jmp 0x00007B00B77CFFCF
00007b00b77d023c  call 0x00007B00B76E1430
00007b00b77d0241  jmp 0x00007B00B77CFFD8
00007b00b77d0246  call 0x00007B00B76E26A0
00007b00b77d024b  jmp 0x00007B00B77CFFF9
00007b00b77d0250  call 0x00007B00B76D5890
00007b00b77d0255  jmp 0x00007B00B77D0002
00007b00b77d025a  call 0x00007B00B76BDD50
00007b00b77d025f  jmp 0x00007B00B77D0098
00007b00b77d0264  call 0x00007B00B76DA580
00007b00b77d0269  jmp 0x00007B00B77D00CF
00007b00b77d026e  int3
00007b00b77d026f  nop
00007b00b77d0270  mov eax, [r15+0xB8]
00007b00b77d0277  mov [rsp+0x10], eax
00007b00b77d027b  mov eax, eax
00007b00b77d027d  mov [r15+0x30], rax
00007b00b77d0281  mov eax, [r15+0xC0]
00007b00b77d0288  mov [rsp+0x20], eax
00007b00b77d028c  mov eax, eax
00007b00b77d028e  mov [r15+0xA0], rax
00007b00b77d0295  mov eax, [r15+0x28]
00007b00b77d0299  mov r14d, [r15+0x98]
00007b00b77d02a0  mov [rsp+0x30], r14d
00007b00b77d02a5  mov r14d, r14d
00007b00b77d02a8  mov [r15+0x28], r14
00007b00b77d02ac  mov r14d, [r15+0x38]
00007b00b77d02b0  mov [rsp+0x40], r14d
00007b00b77d02b5  mov r14d, r14d
00007b00b77d02b8  mov [r15+0x98], r14
00007b00b77d02bf  mov r14d, [r15+0xA8]
00007b00b77d02c6  mov [rsp+0x50], r14d
00007b00b77d02cb  mov r14d, r14d
00007b00b77d02ce  mov [r15+0x38], r14
00007b00b77d02d2  mov r14d, [rsp+0x10]
00007b00b77d02d7  mov r12d, [rsp+0x10]
00007b00b77d02dc  shrd r14d, r12d, 0x06
00007b00b77d02e1  mov r11d, [r15+0xC8]
00007b00b77d02e8  mov [rsp+0x10], r12d
00007b00b77d02ed  and r12d, r11d
00007b00b77d02f0  mov r10d, [rsp+0x50]
00007b00b77d02f5  mov r9d, [rsp+0x50]
00007b00b77d02fa  shrd r10d, r9d, 0x02
00007b00b77d02ff  mov [rsp+0x50], r11d
00007b00b77d0304  mov r11d, r11d
00007b00b77d0307  mov [r15+0x20], r11
00007b00b77d030b  mov r11, [r15+0x88]
00007b00b77d0312  mov r8, [r15+0x50]
00007b00b77d0316  lea rbp, [r8+r11*1]
00007b00b77d031a  mov r8d, [r13+rbp*1]
00007b00b77d031f  mov ebp, [rsp+0x20]
00007b00b77d0323  mov edi, [rsp+0x10]
00007b00b77d0327  andn esi, edi, ebp
00007b00b77d032c  mov edx, [r15+0xB0]
00007b00b77d0333  lea ecx, [r12d+edx*1]
00007b00b77d0338  rorx r12d, edi, 0x0B
00007b00b77d033e  xor r14d, r12d
00007b00b77d0341  rorx r12d, r9d, 0x0D
00007b00b77d0347  xor r10d, r12d
00007b00b77d034a  lea r12d, [ecx+esi*1]
00007b00b77d034f  mov rsi, [r15+0x48]
00007b00b77d0353  lea rdx, [rsi+r11*1]
00007b00b77d0357  mov esi, [r13+rdx*1]
00007b00b77d035c  mov edx, [rsp+0x30]
00007b00b77d0360  mov ecx, [rsp+0x40]
00007b00b77d0364  and edx, ecx
00007b00b77d0366  mov [rsp+0x10], edx
00007b00b77d036a  mov edx, edx
00007b00b77d036c  mov [r15+0xD8], rdx
00007b00b77d0373  lea edx, [r12d+r8d*1]
00007b00b77d0378  mov r12d, [rsp+0x30]
00007b00b77d037d  xor r12d, ecx
00007b00b77d0380  rorx r8d, edi, 0x19
00007b00b77d0386  xor r14d, r8d
00007b00b77d0389  and r12d, r9d
00007b00b77d038c  rorx r8d, r9d, 0x16
00007b00b77d0392  xor r10d, r8d
00007b00b77d0395  mov [rsp+0x20], r10d
00007b00b77d039a  mov r10d, r10d
00007b00b77d039d  mov [r15+0xD0], r10
00007b00b77d03a4  lea r10d, [edx+esi*1]
00007b00b77d03a9  mov r9d, [rsp+0x10]
00007b00b77d03ae  xor r12d, r9d
00007b00b77d03b1  lea r9d, [r10d+r14d*1]
00007b00b77d03b6  lea r14, [r11+0x04]
00007b00b77d03ba  mov [r15+0x88], r14
00007b00b77d03c1  mov r11d, [rsp+0x20]
00007b00b77d03c6  lea r10d, [r12d+r11d*1]
00007b00b77d03cb  lea r11d, [r9d+eax*1]
00007b00b77d03d0  mov r11d, r11d
00007b00b77d03d3  mov [r15+0xB8], r11
00007b00b77d03da  xor eax, eax
00007b00b77d03dc  mov r12d, 0x100
00007b00b77d03e2  cmp r14, r12
00007b00b77d03e5  cmc
00007b00b77d03e6  lahf
00007b00b77d03e7  seto al
00007b00b77d03ea  mov [r15+0x108], eax
00007b00b77d03f1  lea eax, [r10d+r9d*1]
00007b00b77d03f6  mov eax, eax
00007b00b77d03f8  mov [r15+0xA8], rax
00007b00b77d03ff  mov ebp, ebp
00007b00b77d0401  mov [r15+0xB0], rbp
00007b00b77d0408  mov eax, [rsp+0x50]
00007b00b77d040c  mov eax, eax
00007b00b77d040e  mov [r15+0xC0], rax
00007b00b77d0415  mov edi, edi
00007b00b77d0417  mov [r15+0xC8], rdi
00007b00b77d041e  mov eax, [r15+0x108]
00007b00b77d0425  sahf
00007b00b77d0426  jnz 0x00007B00B77D0458
00007b00b77d0428  cmp dword ptr [r15+0x318], 0x00
00007b00b77d0430  jz 0x00007B00B77D04A0
00007b00b77d0436  nop [rax+rax*1], ax
00007b00b77d043f  nop [rax+rax*1], eax
00007b00b77d0447  mov eax, 0x4108E0
00007b00b77d044c  mov [r15+0x100], rax
00007b00b77d0453  jmp 0x00007B00B75FE110
00007b00b77d0458  cmp dword ptr [r15+0x318], 0x00
00007b00b77d0460  jz 0x00007B00B77D0270
00007b00b77d0466  nop [rax+rax*1], ax
00007b00b77d046f  nop [rax+rax*1], eax
00007b00b77d0477  mov eax, 0x410854
00007b00b77d047c  mov [r15+0x100], rax
00007b00b77d0483  jmp 0x00007B00B75FE110
00007b00b77d0488  int3
00007b00b77d0489  call 0x00007B00B7649010
00007b00b77d048e  jmp 0x00007B00B77D031F
00007b00b77d0493  call 0x00007B00B7625930
00007b00b77d0498  jmp 0x00007B00B77D035C
00007b00b77d049d  int3
00007b00b77d049e  nop
00007b00b77d04a0  mov eax, [r15+0x98]
00007b00b77d04a7  mov r14d, [r15+0x70]
00007b00b77d04ab  lea r12d, [eax+r14d*1]
00007b00b77d04b0  mov eax, [r15+0x28]
00007b00b77d04b4  mov r14d, [r15+0x68]
00007b00b77d04b8  lea r11d, [eax+r14d*1]
00007b00b77d04bd  mov qword ptr [r15+0x88], 0x00
00007b00b77d04c8  mov eax, [r15+0xA8]
00007b00b77d04cf  mov r14d, [r15+0x78]
00007b00b77d04d3  lea r10d, [eax+r14d*1]
00007b00b77d04d8  mov [rsp+0x10], r10d
00007b00b77d04dd  mov r10d, r10d
00007b00b77d04e0  mov [r15+0x78], r10
00007b00b77d04e4  mov eax, [r15+0x38]
00007b00b77d04e8  mov r14d, [r15+0x80]
00007b00b77d04ef  lea r10d, [eax+r14d*1]
00007b00b77d04f4  mov [rsp+0x20], r10d
00007b00b77d04f9  mov r10d, r10d
00007b00b77d04fc  mov [r15+0x80], r10
00007b00b77d0503  mov rax, [r15]
00007b00b77d0506  lea r14, [rax+0x08]
00007b00b77d050a  mov [r13+r14*1], r12d
00007b00b77d050f  lea r14, [rax+0x0C]
00007b00b77d0513  mov [r13+r14*1], r11d
00007b00b77d0518  mov r14d, [r15+0xB8]
00007b00b77d051f  mov r12d, [r15+0x18]
00007b00b77d0523  lea r11d, [r14d+r12d*1]
00007b00b77d0528  mov [rsp+0x30], r11d
00007b00b77d052d  mov r11d, r11d
00007b00b77d0530  mov [r15+0x68], r11
00007b00b77d0534  mov r14d, [r15+0x30]
00007b00b77d0538  mov r12d, [r15+0x90]
00007b00b77d053f  lea r11d, [r14d+r12d*1]
00007b00b77d0544  mov [rsp+0x40], r11d
00007b00b77d0549  mov r11d, r11d
00007b00b77d054c  mov [r15+0x70], r11
00007b00b77d0550  mov r14d, [r15+0x20]
00007b00b77d0554  mov r12d, [r15+0x58]
00007b00b77d0558  lea r11d, [r14d+r12d*1]
00007b00b77d055d  mov [rsp+0x50], r11d
00007b00b77d0562  mov r11d, r11d
00007b00b77d0565  mov [r15+0x58], r11
00007b00b77d0569  mov r14d, [r15+0xA0]
00007b00b77d0570  mov r12d, [r15+0x60]
00007b00b77d0574  lea r11d, [r14d+r12d*1]
00007b00b77d0579  mov [rsp+0x60], r11d
00007b00b77d057e  mov r11d, r11d
00007b00b77d0581  mov [r15+0x60], r11
00007b00b77d0585  mov r14d, [rsp+0x10]
00007b00b77d058a  mov [r13+rax*1], r14d
00007b00b77d058f  lea r14, [rax+0x04]
00007b00b77d0593  mov r12d, [rsp+0x20]
00007b00b77d0598  mov [r13+r14*1], r12d
00007b00b77d059d  lea r14, [rax+0x10]
00007b00b77d05a1  mov r12d, [rsp+0x30]
00007b00b77d05a6  mov [r13+r14*1], r12d
00007b00b77d05ab  lea r14, [rax+0x14]
00007b00b77d05af  mov r12d, [rsp+0x40]
00007b00b77d05b4  mov [r13+r14*1], r12d
00007b00b77d05b9  lea r14, [rax+0x18]
00007b00b77d05bd  mov r12d, [rsp+0x50]
00007b00b77d05c2  mov [r13+r14*1], r12d
00007b00b77d05c7  lea r14, [rax+0x1C]
00007b00b77d05cb  mov r12d, [rsp+0x60]
00007b00b77d05d0  mov [r13+r14*1], r12d
00007b00b77d05d5  lea r14, [rax+0x68]
00007b00b77d05d9  xor eax, eax
00007b00b77d05db  mov [r13+r14*1], rax
00007b00b77d05e0  cmp dword ptr [r15+0x318], 0x00
00007b00b77d05e8  jz 0x00007B00B77CF0E0
00007b00b77d05ee  nop [rax+rax*1], ax
00007b00b77d05f7  nop [rax+rax*1], eax
00007b00b77d05ff  mov eax, 0x4106FC
00007b00b77d0604  mov [r15+0x100], rax
00007b00b77d060b  jmp 0x00007B00B75FE110
00007b00b77d0610  int3
00007b00b77d0611  call 0x00007B00B76E2BA0
00007b00b77d0616  jmp 0x00007B00B77D050F
00007b00b77d061b  call 0x00007B00B76E1920
00007b00b77d0620  jmp 0x00007B00B77D0518
00007b00b77d0625  call 0x00007B00B760DFE0
00007b00b77d062a  jmp 0x00007B00B77D058F
00007b00b77d062f  call 0x00007B00B76E2BA0
00007b00b77d0634  jmp 0x00007B00B77D059D
00007b00b77d0639  call 0x00007B00B76E2BA0
00007b00b77d063e  jmp 0x00007B00B77D05AB
00007b00b77d0643  call 0x00007B00B76E2BA0
00007b00b77d0648  jmp 0x00007B00B77D05B9
00007b00b77d064d  call 0x00007B00B76E2BA0
00007b00b77d0652  jmp 0x00007B00B77D05C7
00007b00b77d0657  call 0x00007B00B76E2BA0
00007b00b77d065c  jmp 0x00007B00B77D05D5
00007b00b77d0661  call 0x00007B00B76D5EB0
00007b00b77d0666  jmp 0x00007B00B77D05E0
00007b00b77d066b  int3
00007b00b77d066c  nop [rax], eax
00007b00b77d0670  mov rax, [r15+0xF8]
00007b00b77d0677  lea r14, [rax+0x140]
00007b00b77d067e  mov r12, [r13+r14*1]
00007b00b77d0683  lea r14, [rax+0x148]
00007b00b77d068a  mov r11, [r13+r14*1]
00007b00b77d068f  mov [r15+0xA0], r12
00007b00b77d0696  mov [r15+0x98], r11
00007b00b77d069d  lea r14, [rax+0x130]
00007b00b77d06a4  mov r12, [r13+r14*1]
00007b00b77d06a9  lea r14, [rax+0x138]
00007b00b77d06b0  mov r11, [r13+r14*1]
00007b00b77d06b5  mov [r15+0xB0], r12
00007b00b77d06bc  mov [r15+0xA8], r11
00007b00b77d06c3  lea r14, [rax+0x120]
00007b00b77d06ca  mov r12, [r13+r14*1]
00007b00b77d06cf  lea r14, [rax+0x128]
00007b00b77d06d6  mov r11, [r13+r14*1]
00007b00b77d06db  mov [r15+0xC0], r12
00007b00b77d06e2  mov [r15+0xB8], r11
00007b00b77d06e9  lea r14, [rax+0x110]
00007b00b77d06f0  mov r12, [r13+r14*1]
00007b00b77d06f5  lea r14, [rax+0x118]
00007b00b77d06fc  mov r11, [r13+r14*1]
00007b00b77d0701  mov [r15+0xD0], r12
00007b00b77d0708  mov [r15+0xC8], r11
00007b00b77d070f  lea r14, [rax+0x100]
00007b00b77d0716  mov r12, [r13+r14*1]
00007b00b77d071b  lea r14, [rax+0x108]
00007b00b77d0722  mov r11, [r13+r14*1]
00007b00b77d0727  mov [r15+0xE8], r12
00007b00b77d072e  mov [r15+0xD8], r11
00007b00b77d0735  lea r14, [rax+0x150]
00007b00b77d073c  mov [r15+0xF8], r14
00007b00b77d0743  mov rax, [r15+0xF0]
00007b00b77d074a  mov [r15+0x100], rax
00007b00b77d0751  jmp 0x00007B00B77CE5C0
00007b00b77d0756  int3
00007b00b77d0757  call 0x00007B00B76E27E0
00007b00b77d075c  jmp 0x00007B00B77D0683
00007b00b77d0761  call 0x00007B00B76E1570
00007b00b77d0766  jmp 0x00007B00B77D068F
00007b00b77d076b  call 0x00007B00B76E27E0
00007b00b77d0770  jmp 0x00007B00B77D06A9
00007b00b77d0775  call 0x00007B00B76E1570
00007b00b77d077a  jmp 0x00007B00B77D06B5
00007b00b77d077f  call 0x00007B00B76E27E0
00007b00b77d0784  jmp 0x00007B00B77D06CF
00007b00b77d0789  call 0x00007B00B76E1570
00007b00b77d078e  jmp 0x00007B00B77D06DB
00007b00b77d0793  call 0x00007B00B76E27E0
00007b00b77d0798  jmp 0x00007B00B77D06F5
00007b00b77d079d  call 0x00007B00B76E1570
00007b00b77d07a2  jmp 0x00007B00B77D0701
00007b00b77d07a7  call 0x00007B00B76E27E0
00007b00b77d07ac  jmp 0x00007B00B77D071B
00007b00b77d07b1  call 0x00007B00B76E1570
00007b00b77d07b6  jmp 0x00007B00B77D0727
00007b00b77d07bb  int3
00007b00b77d07bc  nop [rax], eax
00007b00b77d07c0  mov eax, [r15+0xA0]
00007b00b77d07c7  mov [rsp+0x10], eax
00007b00b77d07cb  xor eax, eax
00007b00b77d07cd  mov r14d, [rsp+0x10]
00007b00b77d07d2  sub r14d, 0x01
00007b00b77d07d6  cmc
00007b00b77d07d7  lahf
00007b00b77d07d8  seto al
00007b00b77d07db  mov [r15+0x108], eax
00007b00b77d07e2  mov r14d, r14d
00007b00b77d07e5  mov [r15+0xA0], r14
00007b00b77d07ec  mov eax, [r15+0x108]
00007b00b77d07f3  sahf
00007b00b77d07f4  jnz 0x00007B00B77D0826
00007b00b77d07f6  cmp dword ptr [r15+0x318], 0x00
00007b00b77d07fe  jz 0x00007B00B77D0900
00007b00b77d0804  nop [rax+rax*1], ax
00007b00b77d080d  nop [rax+rax*1], eax
00007b00b77d0815  mov eax, 0x41028C
00007b00b77d081a  mov [r15+0x100], rax
00007b00b77d0821  jmp 0x00007B00B75FE110
00007b00b77d0826  cmp dword ptr [r15+0x318], 0x00
00007b00b77d082e  jz 0x00007B00B77D0860
00007b00b77d0834  nop [rax+rax*1], ax
00007b00b77d083d  nop [rax+rax*1], eax
00007b00b77d0845  mov eax, 0x410274
00007b00b77d084a  mov [r15+0x100], rax
00007b00b77d0851  jmp 0x00007B00B75FE110
00007b00b77d0856  int3
00007b00b77d0857  int3
00007b00b77d0858  nop [rax+rax*1], eax
00007b00b77d0860  mov rax, [r15+0xF8]
00007b00b77d0867  lea r14, [rax+0xD0]
00007b00b77d086e  mov [r15], r14
00007b00b77d0871  mov rax, [r15+0x98]
00007b00b77d0878  mov [r15+0x08], rax
00007b00b77d087c  mov qword ptr [r15+0x10], 0x12C
00007b00b77d0884  mov qword ptr [r15+0xF0], 0x410284
00007b00b77d088f  mov r14d, [r15+0x320]
00007b00b77d0896  mov eax, 0x410284
00007b00b77d089b  mov rcx, 0x7B00B77D07C0
00007b00b77d08a5  mov [r15+r14*8+0x328], rax
00007b00b77d08ad  mov [r15+r14*8+0x368], rcx
00007b00b77d08b5  add r14d, 0x01
00007b00b77d08b9  and r14d, 0x07
00007b00b77d08bd  mov [r15+0x320], r14d
00007b00b77d08c4  cmp dword ptr [r15+0x318], 0x00
00007b00b77d08cc  jz 0x00007B00B77CED70
00007b00b77d08d2  nop [rax+rax*1], ax
00007b00b77d08db  nop [rax+rax*1], eax
00007b00b77d08e3  mov eax, 0x4106BC
00007b00b77d08e8  mov [r15+0x100], rax
00007b00b77d08ef  jmp 0x00007B00B75FE110
00007b00b77d08f4  int3
00007b00b77d08f5  int3
00007b00b77d08f6  nop [rax+rax*1], ax
00007b00b77d08ff  nop
00007b00b77d0900  mov rax, [r15+0xF8]
00007b00b77d0907  lea r14, [rax+0xF0]
00007b00b77d090e  mov r12, [r13+r14*1]
00007b00b77d0913  mov [r15+0x98], r12
00007b00b77d091a  mov qword ptr [r15+0x40], 0x80
00007b00b77d0922  lea r14, [rax+0xD0]
00007b00b77d0929  mov [r15], r14
00007b00b77d092c  lea r14, [rax+0x14C]
00007b00b77d0933  mov [r15+0x08], r14
00007b00b77d0937  mov qword ptr [r15+0x10], 0x01
00007b00b77d093f  lea r14, [rax+0x14C]
00007b00b77d0946  mov eax, 0x80
00007b00b77d094b  mov [r13+r14*1], al
00007b00b77d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007b00b77d095b  mov r14d, [r15+0x320]
00007b00b77d0962  mov eax, 0x4102A8
00007b00b77d0967  mov rcx, 0x7B00B77D09E0
00007b00b77d0971  mov [r15+r14*8+0x328], rax
00007b00b77d0979  mov [r15+r14*8+0x368], rcx
00007b00b77d0981  add r14d, 0x01
00007b00b77d0985  and r14d, 0x07
00007b00b77d0989  mov [r15+0x320], r14d
00007b00b77d0990  cmp dword ptr [r15+0x318], 0x00
00007b00b77d0998  jz 0x00007B00B77CED70
00007b00b77d099e  nop [rax+rax*1], ax
00007b00b77d09a7  nop [rax+rax*1], eax
00007b00b77d09af  mov eax, 0x4106BC
00007b00b77d09b4  mov [r15+0x100], rax
00007b00b77d09bb  jmp 0x00007B00B75FE110
00007b00b77d09c0  int3
00007b00b77d09c1  call 0x00007B00B76E27E0
00007b00b77d09c6  jmp 0x00007B00B77D0913
00007b00b77d09cb  call 0x00007B00B76D5AF0
00007b00b77d09d0  jmp 0x00007B00B77D0950
00007b00b77d09d5  int3
00007b00b77d09d6  nop [rax+rax*1], ax
00007b00b77d09df  nop
00007b00b77d09e0  mov rax, [r15+0xF8]
00007b00b77d09e7  lea r14, [rax+0x138]
00007b00b77d09ee  mov r12, [r13+r14*1]
00007b00b77d09f3  mov [r15+0x40], r12
00007b00b77d09f7  lea r14, [rax+0x148]
00007b00b77d09fe  xor eax, eax
00007b00b77d0a00  mov [r13+r14*1], al
00007b00b77d0a05  xor eax, eax
00007b00b77d0a07  mov r14d, 0x38
00007b00b77d0a0d  cmp r12, r14
00007b00b77d0a10  cmc
00007b00b77d0a11  lahf
00007b00b77d0a12  seto al
00007b00b77d0a15  mov [r15+0x108], eax
00007b00b77d0a1c  mov eax, [r15+0x108]
00007b00b77d0a23  sahf
00007b00b77d0a24  jz 0x00007B00B77D0A56
00007b00b77d0a26  cmp dword ptr [r15+0x318], 0x00
00007b00b77d0a2e  jz 0x00007B00B77D0AA0
00007b00b77d0a34  nop [rax+rax*1], ax
00007b00b77d0a3d  nop [rax+rax*1], eax
00007b00b77d0a45  mov eax, 0x4102B8
00007b00b77d0a4a  mov [r15+0x100], rax
00007b00b77d0a51  jmp 0x00007B00B75FE110
00007b00b77d0a56  cmp dword ptr [r15+0x318], 0x00
00007b00b77d0a5e  jz 0x00007B00B77D0BF0
00007b00b77d0a64  nop [rax+rax*1], ax
00007b00b77d0a6d  nop [rax+rax*1], eax
00007b00b77d0a75  mov eax, 0x4102D4
00007b00b77d0a7a  mov [r15+0x100], rax
00007b00b77d0a81  jmp 0x00007B00B75FE110
00007b00b77d0a86  int3
00007b00b77d0a87  call 0x00007B00B76E27E0
00007b00b77d0a8c  jmp 0x00007B00B77D09F3
00007b00b77d0a91  call 0x00007B00B76D5AF0
00007b00b77d0a96  jmp 0x00007B00B77D0A05
00007b00b77d0a9b  int3
00007b00b77d0a9c  nop [rax], eax
00007b00b77d0aa0  mov rax, [r15+0xF8]
00007b00b77d0aa7  lea r14, [rax+0xD0]
00007b00b77d0aae  mov [r15], r14
00007b00b77d0ab1  lea r14, [rax+0x148]
00007b00b77d0ab8  mov [r15+0x08], r14
00007b00b77d0abc  mov qword ptr [r15+0x10], 0x01
00007b00b77d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007b00b77d0acf  mov r14d, [r15+0x320]
00007b00b77d0ad6  mov eax, 0x4102C8
00007b00b77d0adb  mov rcx, 0x7B00B77D0B40
00007b00b77d0ae5  mov [r15+r14*8+0x328], rax
00007b00b77d0aed  mov [r15+r14*8+0x368], rcx
00007b00b77d0af5  add r14d, 0x01
00007b00b77d0af9  and r14d, 0x07
00007b00b77d0afd  mov [r15+0x320], r14d
00007b00b77d0b04  cmp dword ptr [r15+0x318], 0x00
00007b00b77d0b0c  jz 0x00007B00B77CED70
00007b00b77d0b12  nop [rax+rax*1], ax
00007b00b77d0b1b  nop [rax+rax*1], eax
00007b00b77d0b23  mov eax, 0x4106BC
00007b00b77d0b28  mov [r15+0x100], rax
00007b00b77d0b2f  jmp 0x00007B00B75FE110
00007b00b77d0b34  int3
00007b00b77d0b35  int3
00007b00b77d0b36  nop [rax+rax*1], ax
00007b00b77d0b3f  nop
00007b00b77d0b40  mov rax, [r15+0xF8]
00007b00b77d0b47  lea r14, [rax+0x138]
00007b00b77d0b4e  mov rax, [r13+r14*1]
00007b00b77d0b53  mov [r15+0x40], rax
00007b00b77d0b57  mov [rsp+0x10], rax
00007b00b77d0b5c  xor eax, eax
00007b00b77d0b5e  mov r14, [rsp+0x10]
00007b00b77d0b63  mov r12d, 0x38
00007b00b77d0b69  cmp r14, r12
00007b00b77d0b6c  cmc
00007b00b77d0b6d  lahf
00007b00b77d0b6e  seto al
00007b00b77d0b71  mov [r15+0x108], eax
00007b00b77d0b78  mov eax, [r15+0x108]
00007b00b77d0b7f  sahf
00007b00b77d0b80  jnz 0x00007B00B77D0BB2
00007b00b77d0b82  cmp dword ptr [r15+0x318], 0x00
00007b00b77d0b8a  jz 0x00007B00B77D0BF0
00007b00b77d0b90  nop [rax+rax*1], ax
00007b00b77d0b99  nop [rax+rax*1], eax
00007b00b77d0ba1  mov eax, 0x4102D4
00007b00b77d0ba6  mov [r15+0x100], rax
00007b00b77d0bad  jmp 0x00007B00B75FE110
00007b00b77d0bb2  cmp dword ptr [r15+0x318], 0x00
00007b00b77d0bba  jz 0x00007B00B77D0AA0
00007b00b77d0bc0  nop [rax+rax*1], ax
00007b00b77d0bc9  nop [rax+rax*1], eax
00007b00b77d0bd1  mov eax, 0x4102B8
00007b00b77d0bd6  mov [r15+0x100], rax
00007b00b77d0bdd  jmp 0x00007B00B75FE110
00007b00b77d0be2  int3
00007b00b77d0be3  call 0x00007B00B76D59C0
00007b00b77d0be8  jmp 0x00007B00B77D0B53
00007b00b77d0bed  int3
00007b00b77d0bee  nop
00007b00b77d0bf0  mov rax, [r15+0x98]
00007b00b77d0bf7  rorx r14, rax, 0x3D
00007b00b77d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007b00b77d0c01  mov rax, [r15+0xF8]
00007b00b77d0c08  lea r12, [rax+0xD0]
00007b00b77d0c0f  mov [r15], r12
00007b00b77d0c12  lea r12, [rax+0x140]
00007b00b77d0c19  mov [r15+0x08], r12
00007b00b77d0c1d  mov qword ptr [r15+0x10], 0x08
00007b00b77d0c25  bswap r14
00007b00b77d0c28  mov [r15+0x40], r14
00007b00b77d0c2c  lea r12, [rax+0x140]
00007b00b77d0c33  mov [r13+r12*1], r14
00007b00b77d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007b00b77d0c43  mov r14d, [r15+0x320]
00007b00b77d0c4a  mov eax, 0x4102F0
00007b00b77d0c4f  mov rcx, 0x7B00B77D0CC0
00007b00b77d0c59  mov [r15+r14*8+0x328], rax
00007b00b77d0c61  mov [r15+r14*8+0x368], rcx
00007b00b77d0c69  add r14d, 0x01
00007b00b77d0c6d  and r14d, 0x07
00007b00b77d0c71  mov [r15+0x320], r14d
00007b00b77d0c78  cmp dword ptr [r15+0x318], 0x00
00007b00b77d0c80  jz 0x00007B00B77CED70
00007b00b77d0c86  nop [rax+rax*1], ax
00007b00b77d0c8f  nop [rax+rax*1], eax
00007b00b77d0c97  mov eax, 0x4106BC
00007b00b77d0c9c  mov [r15+0x100], rax
00007b00b77d0ca3  jmp 0x00007B00B75FE110
00007b00b77d0ca8  int3
00007b00b77d0ca9  call 0x00007B00B76C3FE0
00007b00b77d0cae  jmp 0x00007B00B77D0C38
00007b00b77d0cb3  int3
00007b00b77d0cb4  nop [rax+rax*1], ax
00007b00b77d0cbd  nop [rax], eax
00007b00b77d0cc0  mov rax, [r15+0xF8]
00007b00b77d0cc7  lea r14, [rax+0xD0]
00007b00b77d0cce  mov r12d, [r13+r14*1]
00007b00b77d0cd3  lea r14, [rax+0xD4]
00007b00b77d0cda  mov r11d, [r13+r14*1]
00007b00b77d0cdf  lea r14, [rax+0xD8]
00007b00b77d0ce6  mov r10d, [r13+r14*1]
00007b00b77d0ceb  lea r14, [rax+0xDC]
00007b00b77d0cf2  mov r9d, [r13+r14*1]
00007b00b77d0cf7  mov qword ptr [r15+0x48], 0x430C20
00007b00b77d0cff  mov qword ptr [r15+0xA0], 0x00
00007b00b77d0d0a  bswap r12d
00007b00b77d0d0d  bswap r11d
00007b00b77d0d10  mov qword ptr [r15+0x98], 0x430D8C
00007b00b77d0d1b  mov r14d, 0x430C20
00007b00b77d0d21  mov [r13+r14*1], r12d
00007b00b77d0d26  mov r14d, 0x430C24
00007b00b77d0d2c  mov [r13+r14*1], r11d
00007b00b77d0d31  bswap r10d
00007b00b77d0d34  bswap r9d
00007b00b77d0d37  lea r14, [rax+0xE0]
00007b00b77d0d3e  mov r12d, [r13+r14*1]
00007b00b77d0d43  lea r14, [rax+0xE4]
00007b00b77d0d4a  mov r11d, [r13+r14*1]
00007b00b77d0d4f  mov r14d, 0x430C28
00007b00b77d0d55  mov [r13+r14*1], r10d
00007b00b77d0d5a  mov r14d, 0x430C2C
00007b00b77d0d60  mov [r13+r14*1], r9d
00007b00b77d0d65  bswap r12d
00007b00b77d0d68  bswap r11d
00007b00b77d0d6b  mov [rsp+0x10], r11d
00007b00b77d0d70  mov r11d, r11d
00007b00b77d0d73  mov [r15+0x58], r11
00007b00b77d0d77  lea r14, [rax+0xE8]
00007b00b77d0d7e  mov r11d, [r13+r14*1]
00007b00b77d0d83  lea r14, [rax+0xEC]
00007b00b77d0d8a  mov eax, [r13+r14*1]
00007b00b77d0d8f  mov [rsp+0x20], eax
00007b00b77d0d93  mov eax, eax
00007b00b77d0d95  mov [r15+0x60], rax
00007b00b77d0d99  mov eax, 0x430C30
00007b00b77d0d9e  mov [r13+rax*1], r12d
00007b00b77d0da3  mov eax, 0x430C34
00007b00b77d0da8  mov r14d, [rsp+0x10]
00007b00b77d0dad  mov [r13+rax*1], r14d
00007b00b77d0db2  bswap r11d
00007b00b77d0db5  mov [rsp+0x10], r11d
00007b00b77d0dba  mov r11d, r11d
00007b00b77d0dbd  mov [r15+0x40], r11
00007b00b77d0dc1  mov eax, [rsp+0x20]
00007b00b77d0dc5  bswap eax
00007b00b77d0dc7  mov [rsp+0x20], eax
00007b00b77d0dcb  mov eax, eax
00007b00b77d0dcd  mov [r15+0x50], rax
00007b00b77d0dd1  mov eax, 0x430C38
00007b00b77d0dd6  mov r14d, [rsp+0x10]
00007b00b77d0ddb  mov [r13+rax*1], r14d
00007b00b77d0de0  mov eax, 0x430C3C
00007b00b77d0de5  mov r14d, [rsp+0x20]
00007b00b77d0dea  mov [r13+rax*1], r14d
00007b00b77d0def  mov eax, [r15+0xA0]
00007b00b77d0df6  lea r14d, [eax+0x11]
00007b00b77d0dfb  mov r14d, r14d
00007b00b77d0dfe  mov [r15], r14
00007b00b77d0e01  mov qword ptr [r15+0xF0], 0x41034C
00007b00b77d0e0c  mov r14d, [r15+0x320]
00007b00b77d0e13  mov eax, 0x41034C
00007b00b77d0e18  mov rcx, 0x7B00B77D0F90
00007b00b77d0e22  mov [r15+r14*8+0x328], rax
00007b00b77d0e2a  mov [r15+r14*8+0x368], rcx
00007b00b77d0e32  add r14d, 0x01
00007b00b77d0e36  and r14d, 0x07
00007b00b77d0e3a  mov [r15+0x320], r14d
00007b00b77d0e41  cmp dword ptr [r15+0x318], 0x00
00007b00b77d0e49  jz 0x00007B00B77D0F20
00007b00b77d0e4f  nop [rax+rax*1], ax
00007b00b77d0e58  nop [rax+rax*1], eax
00007b00b77d0e60  mov eax, 0x410938
00007b00b77d0e65  mov [r15+0x100], rax
00007b00b77d0e6c  jmp 0x00007B00B75FE110
00007b00b77d0e71  int3
00007b00b77d0e72  call 0x00007B00B76E26A0
00007b00b77d0e77  jmp 0x00007B00B77D0CD3
00007b00b77d0e7c  call 0x00007B00B76E1430
00007b00b77d0e81  jmp 0x00007B00B77D0CDF
00007b00b77d0e86  call 0x00007B00B76E01C0
00007b00b77d0e8b  jmp 0x00007B00B77D0CEB
00007b00b77d0e90  call 0x00007B00B76DEF50
00007b00b77d0e95  jmp 0x00007B00B77D0CF7
00007b00b77d0e9a  call 0x00007B00B76E2BA0
00007b00b77d0e9f  jmp 0x00007B00B77D0D26
00007b00b77d0ea4  call 0x00007B00B76E1920
00007b00b77d0ea9  jmp 0x00007B00B77D0D31
00007b00b77d0eae  call 0x00007B00B76E26A0
00007b00b77d0eb3  jmp 0x00007B00B77D0D43
00007b00b77d0eb8  call 0x00007B00B76E1430
00007b00b77d0ebd  jmp 0x00007B00B77D0D4F
00007b00b77d0ec2  call 0x00007B00B76E06B0
00007b00b77d0ec7  jmp 0x00007B00B77D0D5A
00007b00b77d0ecc  call 0x00007B00B76DF440
00007b00b77d0ed1  jmp 0x00007B00B77D0D65
00007b00b77d0ed6  call 0x00007B00B76E1430
00007b00b77d0edb  jmp 0x00007B00B77D0D83
00007b00b77d0ee0  call 0x00007B00B76D5890
00007b00b77d0ee5  jmp 0x00007B00B77D0D8F
00007b00b77d0eea  call 0x00007B00B760BAE0
00007b00b77d0eef  jmp 0x00007B00B77D0DA3
00007b00b77d0ef4  call 0x00007B00B760DFE0
00007b00b77d0ef9  jmp 0x00007B00B77D0DB2
00007b00b77d0efe  call 0x00007B00B760DFE0
00007b00b77d0f03  jmp 0x00007B00B77D0DE0
00007b00b77d0f08  call 0x00007B00B760DFE0
00007b00b77d0f0d  jmp 0x00007B00B77D0DEF
00007b00b77d0f12  int3
00007b00b77d0f13  nop [rax+rax*1], ax
00007b00b77d0f1c  nop [rax], eax
00007b00b77d0f20  mov eax, [r15]
00007b00b77d0f23  mov [rsp+0x10], eax
00007b00b77d0f27  shr eax, 0x10
00007b00b77d0f2a  mov r14d, [rsp+0x10]
00007b00b77d0f2f  xor r14d, eax
00007b00b77d0f32  imul r14d, r14d, 0x7FEB352D
00007b00b77d0f39  mov eax, 0x846CA68B
00007b00b77d0f3e  mov eax, eax
00007b00b77d0f40  mov [r15+0x48], rax
00007b00b77d0f44  mov [rsp+0x10], r14d
00007b00b77d0f49  shr r14d, 0x0F
00007b00b77d0f4d  mov eax, [rsp+0x10]
00007b00b77d0f51  xor eax, r14d
00007b00b77d0f54  imul eax, eax, 0x846CA68B
00007b00b77d0f5a  mov [rsp+0x10], eax
00007b00b77d0f5e  mov eax, eax
00007b00b77d0f60  mov [r15+0x40], rax
00007b00b77d0f64  mov eax, [rsp+0x10]
00007b00b77d0f68  shr eax, 0x10
00007b00b77d0f6b  mov r14d, [rsp+0x10]
00007b00b77d0f70  xor r14d, eax
00007b00b77d0f73  mov r14d, r14d
00007b00b77d0f76  mov [r15], r14
00007b00b77d0f79  mov rax, [r15+0xF0]
00007b00b77d0f80  mov [r15+0x100], rax
00007b00b77d0f87  jmp 0x00007B00B77CE5C0
00007b00b77d0f8c  int3
00007b00b77d0f8d  int3
00007b00b77d0f8e  nop
00007b00b77d0f90  mov rax, [r15+0xA0]
00007b00b77d0f97  mov [rsp+0x10], rax
00007b00b77d0f9c  shl rax, 0x02
00007b00b77d0fa0  mov r14, [r15+0x98]
00007b00b77d0fa7  lea r12, [r14+rax*1]
00007b00b77d0fab  mov eax, [r15]
00007b00b77d0fae  mov [r13+r12*1], eax
00007b00b77d0fb3  mov rax, [rsp+0x10]
00007b00b77d0fb8  lea r14, [rax+0x01]
00007b00b77d0fbc  mov [r15+0xA0], r14
00007b00b77d0fc3  xor eax, eax
00007b00b77d0fc5  mov r12d, 0x400
00007b00b77d0fcb  cmp r14, r12
00007b00b77d0fce  cmc
00007b00b77d0fcf  lahf
00007b00b77d0fd0  seto al
00007b00b77d0fd3  mov [r15+0x108], eax
00007b00b77d0fda  mov eax, [r15+0x108]
00007b00b77d0fe1  sahf
00007b00b77d0fe2  jnz 0x00007B00B77D1014
00007b00b77d0fe4  cmp dword ptr [r15+0x318], 0x00
00007b00b77d0fec  jz 0x00007B00B77D10E0
00007b00b77d0ff2  nop [rax+rax*1], ax
00007b00b77d0ffb  nop [rax+rax*1], eax
00007b00b77d1003  mov eax, 0x41035C
00007b00b77d1008  mov [r15+0x100], rax
00007b00b77d100f  jmp 0x00007B00B75FE110
00007b00b77d1014  cmp dword ptr [r15+0x318], 0x00
00007b00b77d101c  jz 0x00007B00B77D1050
00007b00b77d1022  nop [rax+rax*1], ax
00007b00b77d102b  nop [rax+rax*1], eax
00007b00b77d1033  mov eax, 0x410344
00007b00b77d1038  mov [r15+0x100], rax
00007b00b77d103f  jmp 0x00007B00B75FE110
00007b00b77d1044  int3
00007b00b77d1045  call 0x00007B00B76B4B70
00007b00b77d104a  jmp 0x00007B00B77D0FB3
00007b00b77d104f  int3
00007b00b77d1050  mov eax, [r15+0xA0]
00007b00b77d1057  lea r14d, [eax+0x11]
00007b00b77d105c  mov r14d, r14d
00007b00b77d105f  mov [r15], r14
00007b00b77d1062  mov qword ptr [r15+0xF0], 0x41034C
00007b00b77d106d  mov r14d, [r15+0x320]
00007b00b77d1074  mov eax, 0x41034C
00007b00b77d1079  mov rcx, 0x7B00B77D0F90
00007b00b77d1083  mov [r15+r14*8+0x328], rax
00007b00b77d108b  mov [r15+r14*8+0x368], rcx
00007b00b77d1093  add r14d, 0x01
00007b00b77d1097  and r14d, 0x07
00007b00b77d109b  mov [r15+0x320], r14d
00007b00b77d10a2  cmp dword ptr [r15+0x318], 0x00
00007b00b77d10aa  jz 0x00007B00B77D0F20
00007b00b77d10b0  nop [rax+rax*1], ax
00007b00b77d10b9  nop [rax+rax*1], eax
00007b00b77d10c1  mov eax, 0x410938
00007b00b77d10c6  mov [r15+0x100], rax
00007b00b77d10cd  jmp 0x00007B00B75FE110
00007b00b77d10d2  int3
00007b00b77d10d3  int3
00007b00b77d10d4  nop [rax+rax*1], ax
00007b00b77d10dd  nop [rax], eax
00007b00b77d10e0  mov qword ptr [r15+0x40], 0x01
00007b00b77d10e8  cmp dword ptr [r15+0x318], 0x00
00007b00b77d10f0  jz 0x00007B00B77D1120
00007b00b77d10f6  nop [rax+rax*1], ax
00007b00b77d10ff  nop [rax+rax*1], eax
00007b00b77d1107  mov eax, 0x410378
00007b00b77d110c  mov [r15+0x100], rax
00007b00b77d1113  jmp 0x00007B00B75FE110
00007b00b77d1118  int3
00007b00b77d1119  int3
00007b00b77d111a  nop [rax+rax*1], ax
00007b00b77d1120  mov rax, [r15+0x40]
00007b00b77d1124  mov [rsp+0x10], rax
00007b00b77d1129  shl rax, 0x02
00007b00b77d112d  mov r14, [r15+0x98]
00007b00b77d1134  lea r12, [r14+rax*1]
00007b00b77d1138  mov eax, [r13+r12*1]
00007b00b77d113d  mov [rsp+0x20], eax
00007b00b77d1141  mov eax, eax
00007b00b77d1143  mov [r15+0x48], rax
00007b00b77d1147  mov rax, [rsp+0x10]
00007b00b77d114c  mov [r15+0x50], rax
00007b00b77d1150  mov eax, [r15+0x50]
00007b00b77d1154  lea r12d, [eax-0x01]
00007b00b77d1159  mov r12d, r12d
00007b00b77d115c  mov [r15+0x58], r12
00007b00b77d1160  mov rax, [r15+0x58]
00007b00b77d1164  mov r12d, eax
00007b00b77d1167  mov r12d, r12d
00007b00b77d116a  shl r12, 0x02
00007b00b77d116e  lea rax, [r14+r12*1]
00007b00b77d1172  mov r14d, [r13+rax*1]
00007b00b77d1177  mov [rsp+0x10], r14d
00007b00b77d117c  mov r14d, r14d
00007b00b77d117f  mov [r15+0x60], r14
00007b00b77d1183  xor eax, eax
00007b00b77d1185  mov r14d, [rsp+0x10]
00007b00b77d118a  mov r12d, [rsp+0x20]
00007b00b77d118f  cmp r14d, r12d
00007b00b77d1192  cmc
00007b00b77d1193  lahf
00007b00b77d1194  seto al
00007b00b77d1197  mov [r15+0x108], eax
00007b00b77d119e  mov eax, [r15+0x108]
00007b00b77d11a5  sahf
00007b00b77d11a6  cmc
00007b00b77d11a7  jbe 0x00007B00B77D11D9
00007b00b77d11a9  cmp dword ptr [r15+0x318], 0x00
00007b00b77d11b1  jz 0x00007B00B77D1220
00007b00b77d11b7  nop [rax+rax*1], ax
00007b00b77d11c0  nop [rax+rax*1], eax
00007b00b77d11c8  mov eax, 0x410390
00007b00b77d11cd  mov [r15+0x100], rax
00007b00b77d11d4  jmp 0x00007B00B75FE110
00007b00b77d11d9  cmp dword ptr [r15+0x318], 0x00
00007b00b77d11e1  jz 0x00007B00B77D14C0
00007b00b77d11e7  nop [rax+rax*1], ax
00007b00b77d11f0  nop [rax+rax*1], eax
00007b00b77d11f8  mov eax, 0x410368
00007b00b77d11fd  mov [r15+0x100], rax
00007b00b77d1204  jmp 0x00007B00B75FE110
00007b00b77d1209  int3
00007b00b77d120a  call 0x00007B00B76B4690
00007b00b77d120f  jmp 0x00007B00B77D113D
00007b00b77d1214  call 0x00007B00B760DAE0
00007b00b77d1219  jmp 0x00007B00B77D1177
00007b00b77d121e  int3
00007b00b77d121f  nop
00007b00b77d1220  mov rax, [r15+0x50]
00007b00b77d1224  mov [rsp+0x10], rax
00007b00b77d1229  shl rax, 0x02
00007b00b77d122d  mov r14, [r15+0x98]
00007b00b77d1234  lea r12, [r14+rax*1]
00007b00b77d1238  mov eax, [r15+0x60]
00007b00b77d123c  mov [r13+r12*1], eax
00007b00b77d1241  mov rax, [rsp+0x10]
00007b00b77d1246  lea r14, [rax-0x01]
00007b00b77d124a  mov [r15+0x50], r14
00007b00b77d124e  mov rax, [r15+0x58]
00007b00b77d1252  test rax, rax
00007b00b77d1255  setz al
00007b00b77d1258  movzx rax, al
00007b00b77d125c  mov [rsp+0x414], al
00007b00b77d1263  cmp byte ptr [rsp+0x414], 0x00
00007b00b77d126b  jz 0x00007B00B77D129D
00007b00b77d126d  cmp dword ptr [r15+0x318], 0x00
00007b00b77d1275  jz 0x00007B00B77D12E0
00007b00b77d127b  nop [rax+rax*1], ax
00007b00b77d1284  nop [rax+rax*1], eax
00007b00b77d128c  mov eax, 0x41039C
00007b00b77d1291  mov [r15+0x100], rax
00007b00b77d1298  jmp 0x00007B00B75FE110
00007b00b77d129d  cmp dword ptr [r15+0x318], 0x00
00007b00b77d12a5  jz 0x00007B00B77D13E0
00007b00b77d12ab  nop [rax+rax*1], ax
00007b00b77d12b4  nop [rax+rax*1], eax
00007b00b77d12bc  mov eax, 0x410380
00007b00b77d12c1  mov [r15+0x100], rax
00007b00b77d12c8  jmp 0x00007B00B75FE110
00007b00b77d12cd  int3
00007b00b77d12ce  call 0x00007B00B76B4B70
00007b00b77d12d3  jmp 0x00007B00B77D1241
00007b00b77d12d8  int3
00007b00b77d12d9  nop [rax], eax
00007b00b77d12e0  cmp dword ptr [r15+0x318], 0x00
00007b00b77d12e8  jz 0x00007B00B77D1320
00007b00b77d12ee  nop [rax+rax*1], ax
00007b00b77d12f7  nop [rax+rax*1], eax
00007b00b77d12ff  mov eax, 0x410364
00007b00b77d1304  mov [r15+0x100], rax
00007b00b77d130b  jmp 0x00007B00B75FE110
00007b00b77d1310  int3
00007b00b77d1311  int3
00007b00b77d1312  nop [rax+rax*1], ax
00007b00b77d131b  nop [rax+rax*1], eax
00007b00b77d1320  mov qword ptr [r15+0x50], 0x00
00007b00b77d1328  mov rax, [r15+0x40]
00007b00b77d132c  lea r14, [rax+0x01]
00007b00b77d1330  mov [r15+0x40], r14
00007b00b77d1334  mov rax, [r15+0x98]
00007b00b77d133b  mov r12d, [r15+0x48]
00007b00b77d133f  mov [r13+rax*1], r12d
00007b00b77d1344  xor eax, eax
00007b00b77d1346  mov r12d, 0x400
00007b00b77d134c  cmp r14, r12
00007b00b77d134f  cmc
00007b00b77d1350  lahf
00007b00b77d1351  seto al
00007b00b77d1354  mov [r15+0x108], eax
00007b00b77d135b  mov eax, [r15+0x108]
00007b00b77d1362  sahf
00007b00b77d1363  jz 0x00007B00B77D1395
00007b00b77d1365  cmp dword ptr [r15+0x318], 0x00
00007b00b77d136d  jz 0x00007B00B77D1120
00007b00b77d1373  nop [rax+rax*1], ax
00007b00b77d137c  nop [rax+rax*1], eax
00007b00b77d1384  mov eax, 0x410378
00007b00b77d1389  mov [r15+0x100], rax
00007b00b77d1390  jmp 0x00007B00B75FE110
00007b00b77d1395  cmp dword ptr [r15+0x318], 0x00
00007b00b77d139d  jz 0x00007B00B77D1580
00007b00b77d13a3  nop [rax+rax*1], ax
00007b00b77d13ac  nop [rax+rax*1], eax
00007b00b77d13b4  mov eax, 0x4103A0
00007b00b77d13b9  mov [r15+0x100], rax
00007b00b77d13c0  jmp 0x00007B00B75FE110
00007b00b77d13c5  int3
00007b00b77d13c6  call 0x00007B00B760BAE0
00007b00b77d13cb  jmp 0x00007B00B77D1344
00007b00b77d13d0  int3
00007b00b77d13d1  nop [rax+rax*1], ax
00007b00b77d13da  nop [rax+rax*1], ax
00007b00b77d13e0  mov eax, [r15+0x50]
00007b00b77d13e4  lea r14d, [eax-0x01]
00007b00b77d13e9  mov r14d, r14d
00007b00b77d13ec  mov [r15+0x58], r14
00007b00b77d13f0  mov rax, [r15+0x58]
00007b00b77d13f4  mov r14d, eax
00007b00b77d13f7  mov r14d, r14d
00007b00b77d13fa  shl r14, 0x02
00007b00b77d13fe  mov rax, [r15+0x98]
00007b00b77d1405  lea r12, [rax+r14*1]
00007b00b77d1409  mov eax, [r13+r12*1]
00007b00b77d140e  mov [rsp+0x10], eax
00007b00b77d1412  mov eax, eax
00007b00b77d1414  mov [r15+0x60], rax
00007b00b77d1418  mov eax, [r15+0x48]
00007b00b77d141c  mov [rsp+0x20], eax
00007b00b77d1420  xor eax, eax
00007b00b77d1422  mov r14d, [rsp+0x10]
00007b00b77d1427  mov r12d, [rsp+0x20]
00007b00b77d142c  cmp r14d, r12d
00007b00b77d142f  cmc
00007b00b77d1430  lahf
00007b00b77d1431  seto al
00007b00b77d1434  mov [r15+0x108], eax
00007b00b77d143b  mov eax, [r15+0x108]
00007b00b77d1442  sahf
00007b00b77d1443  cmc
00007b00b77d1444  jbe 0x00007B00B77D1476
00007b00b77d1446  cmp dword ptr [r15+0x318], 0x00
00007b00b77d144e  jz 0x00007B00B77D1220
00007b00b77d1454  nop [rax+rax*1], ax
00007b00b77d145d  nop [rax+rax*1], eax
00007b00b77d1465  mov eax, 0x410390
00007b00b77d146a  mov [r15+0x100], rax
00007b00b77d1471  jmp 0x00007B00B75FE110
00007b00b77d1476  cmp dword ptr [r15+0x318], 0x00
00007b00b77d147e  jz 0x00007B00B77D14C0
00007b00b77d1484  nop [rax+rax*1], ax
00007b00b77d148d  nop [rax+rax*1], eax
00007b00b77d1495  mov eax, 0x410368
00007b00b77d149a  mov [r15+0x100], rax
00007b00b77d14a1  jmp 0x00007B00B75FE110
00007b00b77d14a6  int3
00007b00b77d14a7  call 0x00007B00B76B4690
00007b00b77d14ac  jmp 0x00007B00B77D140E
00007b00b77d14b1  int3
00007b00b77d14b2  nop [rax+rax*1], ax
00007b00b77d14bb  nop [rax+rax*1], eax
00007b00b77d14c0  mov rax, [r15+0x40]
00007b00b77d14c4  lea r14, [rax+0x01]
00007b00b77d14c8  mov [r15+0x40], r14
00007b00b77d14cc  mov rax, [r15+0x50]
00007b00b77d14d0  mov r12d, eax
00007b00b77d14d3  mov r12d, r12d
00007b00b77d14d6  shl r12, 0x02
00007b00b77d14da  mov rax, [r15+0x98]
00007b00b77d14e1  lea r11, [rax+r12*1]
00007b00b77d14e5  mov eax, [r15+0x48]
00007b00b77d14e9  mov [r13+r11*1], eax
00007b00b77d14ee  xor eax, eax
00007b00b77d14f0  mov r12d, 0x400
00007b00b77d14f6  cmp r14, r12
00007b00b77d14f9  cmc
00007b00b77d14fa  lahf
00007b00b77d14fb  seto al
00007b00b77d14fe  mov [r15+0x108], eax
00007b00b77d1505  mov eax, [r15+0x108]
00007b00b77d150c  sahf
00007b00b77d150d  jz 0x00007B00B77D153F
00007b00b77d150f  cmp dword ptr [r15+0x318], 0x00
00007b00b77d1517  jz 0x00007B00B77D1120
00007b00b77d151d  nop [rax+rax*1], ax
00007b00b77d1526  nop [rax+rax*1], eax
00007b00b77d152e  mov eax, 0x410378
00007b00b77d1533  mov [r15+0x100], rax
00007b00b77d153a  jmp 0x00007B00B75FE110
00007b00b77d153f  cmp dword ptr [r15+0x318], 0x00
00007b00b77d1547  jz 0x00007B00B77D1580
00007b00b77d154d  nop [rax+rax*1], ax
00007b00b77d1556  nop [rax+rax*1], eax
00007b00b77d155e  mov eax, 0x4103A0
00007b00b77d1563  mov [r15+0x100], rax
00007b00b77d156a  jmp 0x00007B00B75FE110
00007b00b77d156f  int3
00007b00b77d1570  call 0x00007B00B76A4270
00007b00b77d1575  jmp 0x00007B00B77D14EE
00007b00b77d157a  int3
00007b00b77d157b  nop [rax+rax*1], eax
00007b00b77d1580  mov qword ptr [r15+0x40], 0x430000
00007b00b77d1588  mov eax, 0x430C40
00007b00b77d158d  mov r14, [r13+rax*1]
00007b00b77d1592  mov rax, [r15+0x98]
00007b00b77d1599  mov r12d, [r13+rax*1]
00007b00b77d159e  lea r11, [rax+0x04]
00007b00b77d15a2  mov eax, [r13+r11*1]
00007b00b77d15a7  mov r12d, r12d
00007b00b77d15aa  mov [r15+0x68], r12
00007b00b77d15ae  mov eax, eax
00007b00b77d15b0  mov [r15+0x60], rax
00007b00b77d15b4  mov rax, [r15+0x68]
00007b00b77d15b8  mov [r15+0x68], rax
00007b00b77d15bc  mov qword ptr [r15+0x58], 0x02
00007b00b77d15c4  mov [rsp+0x10], rax
00007b00b77d15c9  xor eax, eax
00007b00b77d15cb  mov r12d, 0x02
00007b00b77d15d1  mov r11d, 0x400
00007b00b77d15d7  cmp r12, r11
00007b00b77d15da  cmc
00007b00b77d15db  lahf
00007b00b77d15dc  seto al
00007b00b77d15df  mov [r15+0x108], eax
00007b00b77d15e6  mov rax, [r15+0x60]
00007b00b77d15ea  mov r12d, 0x02
00007b00b77d15f0  imul rax, r12
00007b00b77d15f4  mov [r15+0x50], rax
00007b00b77d15f8  mov rax, [rsp+0x10]
00007b00b77d15fd  lea r12, [rax+r14*1]
00007b00b77d1601  mov [r15+0x48], r12
00007b00b77d1605  mov eax, [r15+0x108]
00007b00b77d160c  sahf
00007b00b77d160d  jnz 0x00007B00B77D163F
00007b00b77d160f  cmp dword ptr [r15+0x318], 0x00
00007b00b77d1617  jz 0x00007B00B77D17B0
00007b00b77d161d  nop [rax+rax*1], ax
00007b00b77d1626  nop [rax+rax*1], eax
00007b00b77d162e  mov eax, 0x4103D0
00007b00b77d1633  mov [r15+0x100], rax
00007b00b77d163a  jmp 0x00007B00B75FE110
00007b00b77d163f  cmp dword ptr [r15+0x318], 0x00
00007b00b77d1647  jz 0x00007B00B77D1690
00007b00b77d164d  nop [rax+rax*1], ax
00007b00b77d1656  nop [rax+rax*1], eax
00007b00b77d165e  mov eax, 0x4103B0
00007b00b77d1663  mov [r15+0x100], rax
00007b00b77d166a  jmp 0x00007B00B75FE110
00007b00b77d166f  int3
00007b00b77d1670  call 0x00007B00B760DC20
00007b00b77d1675  jmp 0x00007B00B77D1592
00007b00b77d167a  call 0x00007B00B760B5E0
00007b00b77d167f  jmp 0x00007B00B77D159E
00007b00b77d1684  call 0x00007B00B76A3D90
00007b00b77d1689  jmp 0x00007B00B77D15A7
00007b00b77d168e  int3
00007b00b77d168f  nop
00007b00b77d1690  mov rax, [r15+0x98]
00007b00b77d1697  mov r14, [r15+0x58]
00007b00b77d169b  mov [rsp+0x10], r14
00007b00b77d16a0  shl r14, 0x02
00007b00b77d16a4  lea r12, [rax+r14*1]
00007b00b77d16a8  mov eax, [r13+r12*1]
00007b00b77d16ad  lea r14, [r12+0x04]
00007b00b77d16b2  mov r12d, [r13+r14*1]
00007b00b77d16b7  mov eax, eax
00007b00b77d16b9  mov [r15+0x68], rax
00007b00b77d16bd  mov r12d, r12d
00007b00b77d16c0  mov [r15+0x60], r12
00007b00b77d16c4  mov rax, [r15+0x68]
00007b00b77d16c8  mov [rsp+0x20], rax
00007b00b77d16cd  mov r14, [rsp+0x10]
00007b00b77d16d2  imul rax, r14
00007b00b77d16d6  mov r12, [rsp+0x20]
00007b00b77d16db  lea r11, [r12+rax*1]
00007b00b77d16df  mov [r15+0x68], r11
00007b00b77d16e3  lea rax, [r14+0x02]
00007b00b77d16e7  mov [r15+0x58], rax
00007b00b77d16eb  mov [rsp+0x10], rax
00007b00b77d16f0  xor eax, eax
00007b00b77d16f2  mov r14, [rsp+0x10]
00007b00b77d16f7  mov r12d, 0x400
00007b00b77d16fd  cmp r14, r12
00007b00b77d1700  cmc
00007b00b77d1701  lahf
00007b00b77d1702  seto al
00007b00b77d1705  mov [r15+0x108], eax
00007b00b77d170c  mov rax, [r15+0x50]
00007b00b77d1710  mov r12, [r15+0x60]
00007b00b77d1714  imul r14, r12
00007b00b77d1718  lea r12, [rax+r14*1]
00007b00b77d171c  mov [r15+0x50], r12
00007b00b77d1720  mov rax, [r15+0x48]
00007b00b77d1724  lea r14, [r11+rax*1]
00007b00b77d1728  mov [r15+0x48], r14
00007b00b77d172c  mov eax, [r15+0x108]
00007b00b77d1733  sahf
00007b00b77d1734  jnz 0x00007B00B77D1766
00007b00b77d1736  cmp dword ptr [r15+0x318], 0x00
00007b00b77d173e  jz 0x00007B00B77D17B0
00007b00b77d1744  nop [rax+rax*1], ax
00007b00b77d174d  nop [rax+rax*1], eax
00007b00b77d1755  mov eax, 0x4103D0
00007b00b77d175a  mov [r15+0x100], rax
00007b00b77d1761  jmp 0x00007B00B75FE110
00007b00b77d1766  cmp dword ptr [r15+0x318], 0x00
00007b00b77d176e  jz 0x00007B00B77D1690
00007b00b77d1774  nop [rax+rax*1], ax
00007b00b77d177d  nop [rax+rax*1], eax
00007b00b77d1785  mov eax, 0x4103B0
00007b00b77d178a  mov [r15+0x100], rax
00007b00b77d1791  jmp 0x00007B00B75FE110
00007b00b77d1796  int3
00007b00b77d1797  call 0x00007B00B76B4690
00007b00b77d179c  jmp 0x00007B00B77D16AD
00007b00b77d17a1  call 0x00007B00B76E26A0
00007b00b77d17a6  jmp 0x00007B00B77D16B7
00007b00b77d17ab  int3
00007b00b77d17ac  nop [rax], eax
00007b00b77d17b0  mov qword ptr [r15+0x98], 0x00
00007b00b77d17bb  mov rax, [r15+0x50]
00007b00b77d17bf  mov r14, [r15+0x48]
00007b00b77d17c3  lea r12, [rax+r14*1]
00007b00b77d17c7  mov [r15+0x48], r12
00007b00b77d17cb  mov rax, [r15+0x40]
00007b00b77d17cf  lea r14, [rax+0xC40]
00007b00b77d17d6  mov [r13+r14*1], r12
00007b00b77d17db  mov qword ptr [r15], 0x01
00007b00b77d17e2  mov qword ptr [r15+0xF0], 0x4103E8
00007b00b77d17ed  mov r14d, [r15+0x320]
00007b00b77d17f4  mov eax, 0x4103E8
00007b00b77d17f9  mov rcx, 0x7B00B77D1860
00007b00b77d1803  mov [r15+r14*8+0x328], rax
00007b00b77d180b  mov [r15+r14*8+0x368], rcx
00007b00b77d1813  add r14d, 0x01
00007b00b77d1817  and r14d, 0x07
00007b00b77d181b  mov [r15+0x320], r14d
00007b00b77d1822  cmp dword ptr [r15+0x318], 0x00
00007b00b77d182a  jz 0x00007B00B77D0F20
00007b00b77d1830  nop [rax+rax*1], ax
00007b00b77d1839  nop [rax+rax*1], eax
00007b00b77d1841  mov eax, 0x410938
00007b00b77d1846  mov [r15+0x100], rax
00007b00b77d184d  jmp 0x00007B00B75FE110
00007b00b77d1852  int3
00007b00b77d1853  call 0x00007B00B76E2CE0
00007b00b77d1858  jmp 0x00007B00B77D17DB
00007b00b77d185d  int3
00007b00b77d185e  nop
00007b00b77d1860  mov eax, [r15+0x98]
00007b00b77d1867  lea r14d, [eax+0x01]
00007b00b77d186c  mov [rsp+0x10], r14d
00007b00b77d1871  mov r14d, r14d
00007b00b77d1874  mov [r15+0x98], r14
00007b00b77d187b  xor eax, eax
00007b00b77d187d  mov r14d, [rsp+0x10]
00007b00b77d1882  cmp r14d, 0x10000
00007b00b77d1889  cmc
00007b00b77d188a  lahf
00007b00b77d188b  seto al
00007b00b77d188e  mov [r15+0x108], eax
00007b00b77d1895  mov eax, [r15+0x108]
00007b00b77d189c  sahf
00007b00b77d189d  jnz 0x00007B00B77D18CF
00007b00b77d189f  cmp dword ptr [r15+0x318], 0x00
00007b00b77d18a7  jz 0x00007B00B77D19A0
00007b00b77d18ad  nop [rax+rax*1], ax
00007b00b77d18b6  nop [rax+rax*1], eax
00007b00b77d18be  mov eax, 0x4103F4
00007b00b77d18c3  mov [r15+0x100], rax
00007b00b77d18ca  jmp 0x00007B00B75FE110
00007b00b77d18cf  cmp dword ptr [r15+0x318], 0x00
00007b00b77d18d7  jz 0x00007B00B77D1910
00007b00b77d18dd  nop [rax+rax*1], ax
00007b00b77d18e6  nop [rax+rax*1], eax
00007b00b77d18ee  mov eax, 0x4103E0
00007b00b77d18f3  mov [r15+0x100], rax
00007b00b77d18fa  jmp 0x00007B00B75FE110
00007b00b77d18ff  int3
00007b00b77d1900  int3
00007b00b77d1901  nop [rax+rax*1], ax
00007b00b77d190a  nop [rax+rax*1], ax
00007b00b77d1910  mov eax, [r15]
00007b00b77d1913  mov r14d, [r15+0x98]
00007b00b77d191a  lea r12d, [eax+r14d*1]
00007b00b77d191f  mov r12d, r12d
00007b00b77d1922  mov [r15], r12
00007b00b77d1925  mov qword ptr [r15+0xF0], 0x4103E8
00007b00b77d1930  mov r14d, [r15+0x320]
00007b00b77d1937  mov eax, 0x4103E8
00007b00b77d193c  mov rcx, 0x7B00B77D1860
00007b00b77d1946  mov [r15+r14*8+0x328], rax
00007b00b77d194e  mov [r15+r14*8+0x368], rcx
00007b00b77d1956  add r14d, 0x01
00007b00b77d195a  and r14d, 0x07
00007b00b77d195e  mov [r15+0x320], r14d
00007b00b77d1965  cmp dword ptr [r15+0x318], 0x00
00007b00b77d196d  jz 0x00007B00B77D0F20
00007b00b77d1973  nop [rax+rax*1], ax
00007b00b77d197c  nop [rax+rax*1], eax
00007b00b77d1984  mov eax, 0x410938
00007b00b77d1989  mov [r15+0x100], rax
00007b00b77d1990  jmp 0x00007B00B75FE110
00007b00b77d1995  int3
00007b00b77d1996  int3
00007b00b77d1997  nop [rax+rax*1], ax
00007b00b77d19a0  vmovaps xmm1, [0x00007B00B73FE010]
00007b00b77d19a8  movq xmm1, xmm1
00007b00b77d19ac  movaps [r15+0x110], xmm1
00007b00b77d19b4  mov eax, 0x420AA0
00007b00b77d19b9  mov r14, [r13+rax*1]
00007b00b77d19be  movq xmm1, r14
00007b00b77d19c3  movaps [r15+0x120], xmm1
00007b00b77d19cb  vmovaps xmm1, [0x00007B00B73FE020]
00007b00b77d19d3  movq xmm1, xmm1
00007b00b77d19d7  movaps [r15+0x140], xmm1
00007b00b77d19df  vmovaps xmm1, [0x00007B00B73FE030]
00007b00b77d19e7  vpbroadcastq xmm1, xmm1
00007b00b77d19ec  movaps [r15+0x150], xmm1
00007b00b77d19f4  mov qword ptr [r15+0x40], 0x02
00007b00b77d19fc  vmovaps xmm15, [0x00007B00B73FE040]
00007b00b77d1a04  movq xmm15, xmm15
00007b00b77d1a09  movaps [r15+0x160], xmm15
00007b00b77d1a11  vmovaps xmm15, [0x00007B00B73FE050]
00007b00b77d1a19  vpbroadcastq xmm15, xmm15
00007b00b77d1a1e  movaps [r15+0x130], xmm15
00007b00b77d1a26  mov rax, [r15+0x40]
00007b00b77d1a2a  vmovq xmm14, rax
00007b00b77d1a2f  vpbroadcastq xmm14, xmm14
00007b00b77d1a34  movaps [r15+0x170], xmm14
00007b00b77d1a3c  mov eax, 0x4209D0
00007b00b77d1a41  movups xmm13, [r13+rax*1]
00007b00b77d1a47  mov qword ptr [r15+0x40], 0x431D90
00007b00b77d1a4f  mov eax, [r15]
00007b00b77d1a52  mov r14d, 0x430C48
00007b00b77d1a58  mov [r13+r14*1], eax
00007b00b77d1a5d  mov qword ptr [r15+0x50], 0x431F90
00007b00b77d1a65  vpmovqd xmm12, xmm13
00007b00b77d1a6b  pxor xmm11, xmm11
00007b00b77d1a70  punpcklqdq xmm12, xmm11
00007b00b77d1a75  movaps [r15+0x210], xmm12
00007b00b77d1a7d  movq xmm12, qword ptr [r15+0x140]
00007b00b77d1a86  movq xmm11, qword ptr [r15+0x120]
00007b00b77d1a8f  psubd xmm12, xmm11
00007b00b77d1a94  movq xmm12, xmm12
00007b00b77d1a99  paddq xmm13, xmm14
00007b00b77d1a9e  movaps [r15+0x180], xmm13
00007b00b77d1aa6  movq xmm14, qword ptr [r15+0x160]
00007b00b77d1aaf  paddd xmm11, xmm14
00007b00b77d1ab4  movq xmm11, xmm11
00007b00b77d1ab9  movq xmm11, xmm11
00007b00b77d1abe  movaps [r15+0x120], xmm11
00007b00b77d1ac6  pmovzxdq xmm12, xmm12
00007b00b77d1acc  psllq xmm12, 0x00
00007b00b77d1ad2  movq xmm14, qword ptr [r15+0x210]
00007b00b77d1adb  movq xmm13, qword ptr [r15+0x110]
00007b00b77d1ae4  paddd xmm14, xmm13
00007b00b77d1ae9  movq xmm14, xmm14
00007b00b77d1aee  vcvtuqq2pd xmm12, xmm12
00007b00b77d1af4  pmovzxdq xmm14, xmm14
00007b00b77d1afa  psllq xmm14, 0x00
00007b00b77d1b00  vcvtuqq2pd xmm14, xmm14
00007b00b77d1b06  movaps xmm13, xmm12
00007b00b77d1b0a  mulpd xmm13, xmm1
00007b00b77d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007b00b77d1b15  ptest xmm11, xmm11
00007b00b77d1b1b  jnz 0x00007B00B77D1C0F
00007b00b77d1b21  movaps [r15+0x220], xmm13
00007b00b77d1b29  mov eax, 0x431F90
00007b00b77d1b2e  movups [r13+rax*1], xmm13
00007b00b77d1b34  movaps xmm1, xmm14
00007b00b77d1b38  mulpd xmm1, xmm15
00007b00b77d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007b00b77d1b42  ptest xmm13, xmm13
00007b00b77d1b48  jnz 0x00007B00B77D1D5C
00007b00b77d1b4e  movaps [r15+0x210], xmm1
00007b00b77d1b56  mov eax, 0x431D90
00007b00b77d1b5b  movups [r13+rax*1], xmm1
00007b00b77d1b61  mov qword ptr [r15+0x48], 0x10
00007b00b77d1b69  xor eax, eax
00007b00b77d1b6b  mov r14d, 0x10
00007b00b77d1b71  mov r12d, 0x200
00007b00b77d1b77  cmp r14, r12
00007b00b77d1b7a  cmc
00007b00b77d1b7b  lahf
00007b00b77d1b7c  seto al
00007b00b77d1b7f  mov [r15+0x108], eax
00007b00b77d1b86  mov eax, [r15+0x108]
00007b00b77d1b8d  sahf
00007b00b77d1b8e  jnz 0x00007B00B77D1BC0
00007b00b77d1b90  cmp dword ptr [r15+0x318], 0x00
00007b00b77d1b98  jz 0x00007B00B77D2300
00007b00b77d1b9e  nop [rax+rax*1], ax
00007b00b77d1ba7  nop [rax+rax*1], eax
00007b00b77d1baf  mov eax, 0x410480
00007b00b77d1bb4  mov [r15+0x100], rax
00007b00b77d1bbb  jmp 0x00007B00B75FE110
00007b00b77d1bc0  cmp dword ptr [r15+0x318], 0x00
00007b00b77d1bc8  jz 0x00007B00B77D1EB0
00007b00b77d1bce  nop [rax+rax*1], ax
00007b00b77d1bd7  nop [rax+rax*1], eax
00007b00b77d1bdf  mov eax, 0x410440
00007b00b77d1be4  mov [r15+0x100], rax
00007b00b77d1beb  jmp 0x00007B00B75FE110
00007b00b77d1bf0  int3
00007b00b77d1bf1  call 0x00007B00B760DC20
00007b00b77d1bf6  jmp 0x00007B00B77D19BE
00007b00b77d1bfb  call 0x00007B00B760C260
00007b00b77d1c00  jmp 0x00007B00B77D1A47
00007b00b77d1c05  call 0x00007B00B76D5D70
00007b00b77d1c0a  jmp 0x00007B00B77D1A5D
00007b00b77d1c0f  sub rsp, 0x08
00007b00b77d1c13  push rax
00007b00b77d1c14  push rcx
00007b00b77d1c15  push rdx
00007b00b77d1c16  push rdi
00007b00b77d1c17  push rsi
00007b00b77d1c18  push r8
00007b00b77d1c1a  push r9
00007b00b77d1c1c  push r10
00007b00b77d1c1e  push r11
00007b00b77d1c20  sub rsp, 0xF0
00007b00b77d1c27  vmovaps [rsp], xmm0
00007b00b77d1c2c  vmovaps [rsp+0x10], xmm1
00007b00b77d1c32  vmovaps [rsp+0x20], xmm2
00007b00b77d1c38  vmovaps [rsp+0x30], xmm3
00007b00b77d1c3e  vmovaps [rsp+0x40], xmm4
00007b00b77d1c44  vmovaps [rsp+0x50], xmm5
00007b00b77d1c4a  vmovaps [rsp+0x60], xmm6
00007b00b77d1c50  vmovaps [rsp+0x70], xmm7
00007b00b77d1c56  vmovaps [rsp+0x80], xmm8
00007b00b77d1c5f  vmovaps [rsp+0x90], xmm9
00007b00b77d1c68  vmovaps [rsp+0xA0], xmm10
00007b00b77d1c71  vmovaps [rsp+0xB0], xmm11
00007b00b77d1c7a  vmovaps [rsp+0xC0], xmm12
00007b00b77d1c83  vmovaps [rsp+0xD0], xmm14
00007b00b77d1c8c  vmovaps [rsp+0xE0], xmm15
00007b00b77d1c95  sub rsp, 0x30
00007b00b77d1c99  movaps [rsp], xmm13
00007b00b77d1c9e  movaps [rsp+0x10], xmm12
00007b00b77d1ca4  movaps [rsp+0x20], xmm1
00007b00b77d1ca9  lea rdi, [rsp]
00007b00b77d1cad  mov esi, 0x00
00007b00b77d1cb2  mov rax, 0x612A23581530
00007b00b77d1cbc  call rax
00007b00b77d1cbe  movaps xmm13, [rsp]
00007b00b77d1cc3  add rsp, 0x30
00007b00b77d1cc7  vmovaps xmm0, [rsp]
00007b00b77d1ccc  vmovaps xmm1, [rsp+0x10]
00007b00b77d1cd2  vmovaps xmm2, [rsp+0x20]
00007b00b77d1cd8  vmovaps xmm3, [rsp+0x30]
00007b00b77d1cde  vmovaps xmm4, [rsp+0x40]
00007b00b77d1ce4  vmovaps xmm5, [rsp+0x50]
00007b00b77d1cea  vmovaps xmm6, [rsp+0x60]
00007b00b77d1cf0  vmovaps xmm7, [rsp+0x70]
00007b00b77d1cf6  vmovaps xmm8, [rsp+0x80]
00007b00b77d1cff  vmovaps xmm9, [rsp+0x90]
00007b00b77d1d08  vmovaps xmm10, [rsp+0xA0]
00007b00b77d1d11  vmovaps xmm11, [rsp+0xB0]
00007b00b77d1d1a  vmovaps xmm12, [rsp+0xC0]
00007b00b77d1d23  vmovaps xmm14, [rsp+0xD0]
00007b00b77d1d2c  vmovaps xmm15, [rsp+0xE0]
00007b00b77d1d35  add rsp, 0xF0
00007b00b77d1d3c  pop r11
00007b00b77d1d3e  pop r10
00007b00b77d1d40  pop r9
00007b00b77d1d42  pop r8
00007b00b77d1d44  pop rsi
00007b00b77d1d45  pop rdi
00007b00b77d1d46  pop rdx
00007b00b77d1d47  pop rcx
00007b00b77d1d48  pop rax
00007b00b77d1d49  add rsp, 0x08
00007b00b77d1d4d  jmp 0x00007B00B77D1B21
00007b00b77d1d52  call 0x00007B00B760C380
00007b00b77d1d57  jmp 0x00007B00B77D1B34
00007b00b77d1d5c  sub rsp, 0x08
00007b00b77d1d60  push rax
00007b00b77d1d61  push rcx
00007b00b77d1d62  push rdx
00007b00b77d1d63  push rdi
00007b00b77d1d64  push rsi
00007b00b77d1d65  push r8
00007b00b77d1d67  push r9
00007b00b77d1d69  push r10
00007b00b77d1d6b  push r11
00007b00b77d1d6d  sub rsp, 0xF0
00007b00b77d1d74  vmovaps [rsp], xmm0
00007b00b77d1d79  vmovaps [rsp+0x10], xmm2
00007b00b77d1d7f  vmovaps [rsp+0x20], xmm3
00007b00b77d1d85  vmovaps [rsp+0x30], xmm4
00007b00b77d1d8b  vmovaps [rsp+0x40], xmm5
00007b00b77d1d91  vmovaps [rsp+0x50], xmm6
00007b00b77d1d97  vmovaps [rsp+0x60], xmm7
00007b00b77d1d9d  vmovaps [rsp+0x70], xmm8
00007b00b77d1da3  vmovaps [rsp+0x80], xmm9
00007b00b77d1dac  vmovaps [rsp+0x90], xmm10
00007b00b77d1db5  vmovaps [rsp+0xA0], xmm11
00007b00b77d1dbe  vmovaps [rsp+0xB0], xmm12
00007b00b77d1dc7  vmovaps [rsp+0xC0], xmm13
00007b00b77d1dd0  vmovaps [rsp+0xD0], xmm14
00007b00b77d1dd9  vmovaps [rsp+0xE0], xmm15
00007b00b77d1de2  sub rsp, 0x30
00007b00b77d1de6  movaps [rsp], xmm1
00007b00b77d1dea  movaps [rsp+0x10], xmm14
00007b00b77d1df0  movaps [rsp+0x20], xmm15
00007b00b77d1df6  lea rdi, [rsp]
00007b00b77d1dfa  mov esi, 0x00
00007b00b77d1dff  mov rax, 0x612A23581530
00007b00b77d1e09  call rax
00007b00b77d1e0b  movaps xmm1, [rsp]
00007b00b77d1e0f  add rsp, 0x30
00007b00b77d1e13  vmovaps xmm0, [rsp]
00007b00b77d1e18  vmovaps xmm2, [rsp+0x10]
00007b00b77d1e1e  vmovaps xmm3, [rsp+0x20]
00007b00b77d1e24  vmovaps xmm4, [rsp+0x30]
00007b00b77d1e2a  vmovaps xmm5, [rsp+0x40]
00007b00b77d1e30  vmovaps xmm6, [rsp+0x50]
00007b00b77d1e36  vmovaps xmm7, [rsp+0x60]
00007b00b77d1e3c  vmovaps xmm8, [rsp+0x70]
00007b00b77d1e42  vmovaps xmm9, [rsp+0x80]
00007b00b77d1e4b  vmovaps xmm10, [rsp+0x90]
00007b00b77d1e54  vmovaps xmm11, [rsp+0xA0]
00007b00b77d1e5d  vmovaps xmm12, [rsp+0xB0]
00007b00b77d1e66  vmovaps xmm13, [rsp+0xC0]
00007b00b77d1e6f  vmovaps xmm14, [rsp+0xD0]
00007b00b77d1e78  vmovaps xmm15, [rsp+0xE0]
00007b00b77d1e81  add rsp, 0xF0
00007b00b77d1e88  pop r11
00007b00b77d1e8a  pop r10
00007b00b77d1e8c  pop r9
00007b00b77d1e8e  pop r8
00007b00b77d1e90  pop rsi
00007b00b77d1e91  pop rdi
00007b00b77d1e92  pop rdx
00007b00b77d1e93  pop rcx
00007b00b77d1e94  pop rax
00007b00b77d1e95  add rsp, 0x08
00007b00b77d1e99  jmp 0x00007B00B77D1B4E
00007b00b77d1e9e  call 0x00007B00B75FF540
00007b00b77d1ea3  jmp 0x00007B00B77D1B61
00007b00b77d1ea8  int3
00007b00b77d1ea9  nop [rax], eax
00007b00b77d1eb0  movaps xmm1, [r15+0x180]
00007b00b77d1eb8  vpmovqd xmm15, xmm1
00007b00b77d1ebe  pxor xmm14, xmm14
00007b00b77d1ec3  punpcklqdq xmm15, xmm14
00007b00b77d1ec8  movaps [r15+0x210], xmm15
00007b00b77d1ed0  movq xmm15, qword ptr [r15+0x140]
00007b00b77d1ed9  movq xmm14, qword ptr [r15+0x120]
00007b00b77d1ee2  psubd xmm15, xmm14
00007b00b77d1ee7  movq xmm15, xmm15
00007b00b77d1eec  movaps xmm13, [r15+0x170]
00007b00b77d1ef4  paddq xmm1, xmm13
00007b00b77d1ef9  movaps [r15+0x180], xmm1
00007b00b77d1f01  movq xmm1, qword ptr [r15+0x160]
00007b00b77d1f0a  paddd xmm14, xmm1
00007b00b77d1f0f  movq xmm14, xmm14
00007b00b77d1f14  movq xmm14, xmm14
00007b00b77d1f19  movaps [r15+0x120], xmm14
00007b00b77d1f21  pmovzxdq xmm15, xmm15
00007b00b77d1f27  psllq xmm15, 0x00
00007b00b77d1f2d  movq xmm1, qword ptr [r15+0x210]
00007b00b77d1f36  movq xmm14, qword ptr [r15+0x110]
00007b00b77d1f3f  paddd xmm1, xmm14
00007b00b77d1f44  movq xmm1, xmm1
00007b00b77d1f48  vcvtuqq2pd xmm15, xmm15
00007b00b77d1f4e  pmovzxdq xmm1, xmm1
00007b00b77d1f53  psllq xmm1, 0x00
00007b00b77d1f58  vcvtuqq2pd xmm1, xmm1
00007b00b77d1f5e  movaps xmm14, [r15+0x150]
00007b00b77d1f66  movaps xmm13, xmm15
00007b00b77d1f6a  mulpd xmm13, xmm14
00007b00b77d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007b00b77d1f75  ptest xmm12, xmm12
00007b00b77d1f7b  jnz 0x00007B00B77D205E
00007b00b77d1f81  movaps [r15+0x220], xmm13
00007b00b77d1f89  mov rax, [r15+0x48]
00007b00b77d1f8d  mov r14, [r15+0x50]
00007b00b77d1f91  lea r12, [r14+rax*1]
00007b00b77d1f95  movups [r13+r12*1], xmm13
00007b00b77d1f9b  movaps xmm15, [r15+0x130]
00007b00b77d1fa3  movaps xmm14, xmm1
00007b00b77d1fa7  mulpd xmm14, xmm15
00007b00b77d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007b00b77d1fb2  ptest xmm13, xmm13
00007b00b77d1fb8  jnz 0x00007B00B77D21AC
00007b00b77d1fbe  movaps [r15+0x210], xmm14
00007b00b77d1fc6  mov r14, [r15+0x40]
00007b00b77d1fca  lea r12, [r14+rax*1]
00007b00b77d1fce  movups [r13+r12*1], xmm14
00007b00b77d1fd4  lea r14, [rax+0x10]
00007b00b77d1fd8  mov [r15+0x48], r14
00007b00b77d1fdc  xor eax, eax
00007b00b77d1fde  mov r12d, 0x200
00007b00b77d1fe4  cmp r14, r12
00007b00b77d1fe7  cmc
00007b00b77d1fe8  lahf
00007b00b77d1fe9  seto al
00007b00b77d1fec  mov [r15+0x108], eax
00007b00b77d1ff3  mov eax, [r15+0x108]
00007b00b77d1ffa  sahf
00007b00b77d1ffb  jnz 0x00007B00B77D202D
00007b00b77d1ffd  cmp dword ptr [r15+0x318], 0x00
00007b00b77d2005  jz 0x00007B00B77D2300
00007b00b77d200b  nop [rax+rax*1], ax
00007b00b77d2014  nop [rax+rax*1], eax
00007b00b77d201c  mov eax, 0x410480
00007b00b77d2021  mov [r15+0x100], rax
00007b00b77d2028  jmp 0x00007B00B75FE110
00007b00b77d202d  cmp dword ptr [r15+0x318], 0x00
00007b00b77d2035  jz 0x00007B00B77D1EB0
00007b00b77d203b  nop [rax+rax*1], ax
00007b00b77d2044  nop [rax+rax*1], eax
00007b00b77d204c  mov eax, 0x410440
00007b00b77d2051  mov [r15+0x100], rax
00007b00b77d2058  jmp 0x00007B00B75FE110
00007b00b77d205d  int3
00007b00b77d205e  sub rsp, 0x08
00007b00b77d2062  push rax
00007b00b77d2063  push rcx
00007b00b77d2064  push rdx
00007b00b77d2065  push rdi
00007b00b77d2066  push rsi
00007b00b77d2067  push r8
00007b00b77d2069  push r9
00007b00b77d206b  push r10
00007b00b77d206d  push r11
00007b00b77d206f  sub rsp, 0xF0
00007b00b77d2076  vmovaps [rsp], xmm0
00007b00b77d207b  vmovaps [rsp+0x10], xmm1
00007b00b77d2081  vmovaps [rsp+0x20], xmm2
00007b00b77d2087  vmovaps [rsp+0x30], xmm3
00007b00b77d208d  vmovaps [rsp+0x40], xmm4
00007b00b77d2093  vmovaps [rsp+0x50], xmm5
00007b00b77d2099  vmovaps [rsp+0x60], xmm6
00007b00b77d209f  vmovaps [rsp+0x70], xmm7
00007b00b77d20a5  vmovaps [rsp+0x80], xmm8
00007b00b77d20ae  vmovaps [rsp+0x90], xmm9
00007b00b77d20b7  vmovaps [rsp+0xA0], xmm10
00007b00b77d20c0  vmovaps [rsp+0xB0], xmm11
00007b00b77d20c9  vmovaps [rsp+0xC0], xmm12
00007b00b77d20d2  vmovaps [rsp+0xD0], xmm14
00007b00b77d20db  vmovaps [rsp+0xE0], xmm15
00007b00b77d20e4  sub rsp, 0x30
00007b00b77d20e8  movaps [rsp], xmm13
00007b00b77d20ed  movaps [rsp+0x10], xmm15
00007b00b77d20f3  movaps [rsp+0x20], xmm14
00007b00b77d20f9  lea rdi, [rsp]
00007b00b77d20fd  mov esi, 0x00
00007b00b77d2102  mov rax, 0x612A23581530
00007b00b77d210c  call rax
00007b00b77d210e  movaps xmm13, [rsp]
00007b00b77d2113  add rsp, 0x30
00007b00b77d2117  vmovaps xmm0, [rsp]
00007b00b77d211c  vmovaps xmm1, [rsp+0x10]
00007b00b77d2122  vmovaps xmm2, [rsp+0x20]
00007b00b77d2128  vmovaps xmm3, [rsp+0x30]
00007b00b77d212e  vmovaps xmm4, [rsp+0x40]
00007b00b77d2134  vmovaps xmm5, [rsp+0x50]
00007b00b77d213a  vmovaps xmm6, [rsp+0x60]
00007b00b77d2140  vmovaps xmm7, [rsp+0x70]
00007b00b77d2146  vmovaps xmm8, [rsp+0x80]
00007b00b77d214f  vmovaps xmm9, [rsp+0x90]
00007b00b77d2158  vmovaps xmm10, [rsp+0xA0]
00007b00b77d2161  vmovaps xmm11, [rsp+0xB0]
00007b00b77d216a  vmovaps xmm12, [rsp+0xC0]
00007b00b77d2173  vmovaps xmm14, [rsp+0xD0]
00007b00b77d217c  vmovaps xmm15, [rsp+0xE0]
00007b00b77d2185  add rsp, 0xF0
00007b00b77d218c  pop r11
00007b00b77d218e  pop r10
00007b00b77d2190  pop r9
00007b00b77d2192  pop r8
00007b00b77d2194  pop rsi
00007b00b77d2195  pop rdi
00007b00b77d2196  pop rdx
00007b00b77d2197  pop rcx
00007b00b77d2198  pop rax
00007b00b77d2199  add rsp, 0x08
00007b00b77d219d  jmp 0x00007B00B77D1F81
00007b00b77d21a2  call 0x00007B00B76C2240
00007b00b77d21a7  jmp 0x00007B00B77D1F9B
00007b00b77d21ac  sub rsp, 0x08
00007b00b77d21b0  push rax
00007b00b77d21b1  push rcx
00007b00b77d21b2  push rdx
00007b00b77d21b3  push rdi
00007b00b77d21b4  push rsi
00007b00b77d21b5  push r8
00007b00b77d21b7  push r9
00007b00b77d21b9  push r10
00007b00b77d21bb  push r11
00007b00b77d21bd  sub rsp, 0xF0
00007b00b77d21c4  vmovaps [rsp], xmm0
00007b00b77d21c9  vmovaps [rsp+0x10], xmm1
00007b00b77d21cf  vmovaps [rsp+0x20], xmm2
00007b00b77d21d5  vmovaps [rsp+0x30], xmm3
00007b00b77d21db  vmovaps [rsp+0x40], xmm4
00007b00b77d21e1  vmovaps [rsp+0x50], xmm5
00007b00b77d21e7  vmovaps [rsp+0x60], xmm6
00007b00b77d21ed  vmovaps [rsp+0x70], xmm7
00007b00b77d21f3  vmovaps [rsp+0x80], xmm8
00007b00b77d21fc  vmovaps [rsp+0x90], xmm9
00007b00b77d2205  vmovaps [rsp+0xA0], xmm10
00007b00b77d220e  vmovaps [rsp+0xB0], xmm11
00007b00b77d2217  vmovaps [rsp+0xC0], xmm12
00007b00b77d2220  vmovaps [rsp+0xD0], xmm13
00007b00b77d2229  vmovaps [rsp+0xE0], xmm15
00007b00b77d2232  sub rsp, 0x30
00007b00b77d2236  movaps [rsp], xmm14
00007b00b77d223b  movaps [rsp+0x10], xmm1
00007b00b77d2240  movaps [rsp+0x20], xmm15
00007b00b77d2246  lea rdi, [rsp]
00007b00b77d224a  mov esi, 0x00
00007b00b77d224f  mov rax, 0x612A23581530
00007b00b77d2259  call rax
00007b00b77d225b  movaps xmm14, [rsp]
00007b00b77d2260  add rsp, 0x30
00007b00b77d2264  vmovaps xmm0, [rsp]
00007b00b77d2269  vmovaps xmm1, [rsp+0x10]
00007b00b77d226f  vmovaps xmm2, [rsp+0x20]
00007b00b77d2275  vmovaps xmm3, [rsp+0x30]
00007b00b77d227b  vmovaps xmm4, [rsp+0x40]
00007b00b77d2281  vmovaps xmm5, [rsp+0x50]
00007b00b77d2287  vmovaps xmm6, [rsp+0x60]
00007b00b77d228d  vmovaps xmm7, [rsp+0x70]
00007b00b77d2293  vmovaps xmm8, [rsp+0x80]
00007b00b77d229c  vmovaps xmm9, [rsp+0x90]
00007b00b77d22a5  vmovaps xmm10, [rsp+0xA0]
00007b00b77d22ae  vmovaps xmm11, [rsp+0xB0]
00007b00b77d22b7  vmovaps xmm12, [rsp+0xC0]
00007b00b77d22c0  vmovaps xmm13, [rsp+0xD0]
00007b00b77d22c9  vmovaps xmm15, [rsp+0xE0]
00007b00b77d22d2  add rsp, 0xF0
00007b00b77d22d9  pop r11
00007b00b77d22db  pop r10
00007b00b77d22dd  pop r9
00007b00b77d22df  pop r8
00007b00b77d22e1  pop rsi
00007b00b77d22e2  pop rdi
00007b00b77d22e3  pop rdx
00007b00b77d22e4  pop rcx
00007b00b77d22e5  pop rax
00007b00b77d22e6  add rsp, 0x08
00007b00b77d22ea  jmp 0x00007B00B77D1FBE
00007b00b77d22ef  call 0x00007B00B76C34C0
00007b00b77d22f4  jmp 0x00007B00B77D1FD4
00007b00b77d22f9  int3
00007b00b77d22fa  nop [rax+rax*1], ax
00007b00b77d2300  mov rax, [r15+0x50]
00007b00b77d2304  movups xmm1, [r13+rax*1]
00007b00b77d230a  lea r14, [rax+0x10]
00007b00b77d230e  movups xmm15, [r13+r14*1]
00007b00b77d2314  mov qword ptr [r15+0x48], 0x00
00007b00b77d231c  lea r14, [rax+0x40]
00007b00b77d2320  movups xmm14, [r13+r14*1]
00007b00b77d2326  lea r14, [rax+0x50]
00007b00b77d232a  movups xmm13, [r13+r14*1]
00007b00b77d2330  lea r14, [rax+0x80]
00007b00b77d2337  movups xmm12, [r13+r14*1]
00007b00b77d233d  lea r14, [rax+0x90]
00007b00b77d2344  movups xmm11, [r13+r14*1]
00007b00b77d234a  mov r14, [r15+0xF8]
00007b00b77d2351  movups [r13+r14*1], xmm1
00007b00b77d2357  lea r12, [rax+0x20]
00007b00b77d235b  movups xmm1, [r13+r12*1]
00007b00b77d2361  lea r12, [rax+0x30]
00007b00b77d2365  movups xmm10, [r13+r12*1]
00007b00b77d236b  lea r12, [rax+0xC0]
00007b00b77d2372  movups xmm9, [r13+r12*1]
00007b00b77d2378  lea r12, [rax+0xD0]
00007b00b77d237f  movups xmm8, [r13+r12*1]
00007b00b77d2385  lea r12, [rax+0x100]
00007b00b77d238c  movups xmm7, [r13+r12*1]
00007b00b77d2392  lea r12, [rax+0x110]
00007b00b77d2399  movups xmm6, [r13+r12*1]
00007b00b77d239f  lea r12, [rax+0x140]
00007b00b77d23a6  movups xmm5, [r13+r12*1]
00007b00b77d23ac  lea r12, [rax+0x150]
00007b00b77d23b3  movups xmm4, [r13+r12*1]
00007b00b77d23b9  lea r12, [r14+0xB0]
00007b00b77d23c0  movups [r13+r12*1], xmm10
00007b00b77d23c6  lea r12, [r14+0xC0]
00007b00b77d23cd  movups [r13+r12*1], xmm1
00007b00b77d23d3  lea r12, [rax+0x180]
00007b00b77d23da  movups xmm1, [r13+r12*1]
00007b00b77d23e0  lea r12, [rax+0x190]
00007b00b77d23e7  movups xmm10, [r13+r12*1]
00007b00b77d23ed  lea r12, [rax+0x1C0]
00007b00b77d23f4  movups xmm3, [r13+r12*1]
00007b00b77d23fa  lea r12, [rax+0x1D0]
00007b00b77d2401  movups xmm2, [r13+r12*1]
00007b00b77d2407  lea r12, [rax+0x60]
00007b00b77d240b  vmovaps [rsp+0x10], xmm1
00007b00b77d2411  movups xmm1, [r13+r12*1]
00007b00b77d2417  lea r12, [rax+0x70]
00007b00b77d241b  vmovaps [rsp+0x20], xmm1
00007b00b77d2421  movups xmm1, [r13+r12*1]
00007b00b77d2427  lea r12, [r14+0x70]
00007b00b77d242b  movups [r13+r12*1], xmm10
00007b00b77d2431  lea r12, [r14+0x80]
00007b00b77d2438  vmovaps xmm10, [rsp+0x10]
00007b00b77d243e  movups [r13+r12*1], xmm10
00007b00b77d2444  lea r12, [rax+0xA0]
00007b00b77d244b  movups xmm10, [r13+r12*1]
00007b00b77d2451  lea r12, [rax+0xB0]
00007b00b77d2458  vmovaps [rsp+0x10], xmm1
00007b00b77d245e  movups xmm1, [r13+r12*1]
00007b00b77d2464  lea r12, [r14+0x90]
00007b00b77d246b  movups [r13+r12*1], xmm2
00007b00b77d2471  lea r12, [r14+0xA0]
00007b00b77d2478  movups [r13+r12*1], xmm3
00007b00b77d247e  lea r12, [rax+0xE0]
00007b00b77d2485  movups xmm3, [r13+r12*1]
00007b00b77d248b  lea r12, [rax+0xF0]
00007b00b77d2492  movups xmm2, [r13+r12*1]
00007b00b77d2498  lea r12, [rax+0x120]
00007b00b77d249f  vmovaps [rsp+0x30], xmm1
00007b00b77d24a5  movups xmm1, [r13+r12*1]
00007b00b77d24ab  lea r12, [rax+0x130]
00007b00b77d24b2  vmovaps [rsp+0x40], xmm1
00007b00b77d24b8  movups xmm1, [r13+r12*1]
00007b00b77d24be  vmovaps [rsp+0x50], xmm1
00007b00b77d24c4  vmovaps xmm1, [rsp+0x40]
00007b00b77d24ca  movaps [r15+0x190], xmm1
00007b00b77d24d2  lea r12, [rax+0x160]
00007b00b77d24d9  vmovaps [rsp+0x40], xmm1
00007b00b77d24df  movups xmm1, [r13+r12*1]
00007b00b77d24e5  lea r12, [rax+0x170]
00007b00b77d24ec  vmovaps [rsp+0x60], xmm1
00007b00b77d24f2  movups xmm1, [r13+r12*1]
00007b00b77d24f8  lea r12, [rax+0x1A0]
00007b00b77d24ff  vmovaps [rsp+0x70], xmm1
00007b00b77d2505  movups xmm1, [r13+r12*1]
00007b00b77d250b  lea r12, [rax+0x1B0]
00007b00b77d2512  vmovaps [rsp+0x80], xmm1
00007b00b77d251b  movups xmm1, [r13+r12*1]
00007b00b77d2521  lea r12, [rax+0x1E0]
00007b00b77d2528  vmovaps [rsp+0x90], xmm1
00007b00b77d2531  movups xmm1, [r13+r12*1]
00007b00b77d2537  lea r12, [rax+0x1F0]
00007b00b77d253e  vmovaps [rsp+0xA0], xmm1
00007b00b77d2547  movups xmm1, [r13+r12*1]
00007b00b77d254d  mov qword ptr [r15+0x50], 0x432190
00007b00b77d2555  lea rax, [r14+0x50]
00007b00b77d2559  vmovaps [rsp+0xB0], xmm1
00007b00b77d2562  vmovaps xmm1, [rsp+0x60]
00007b00b77d2568  movups [r13+rax*1], xmm1
00007b00b77d256e  lea rax, [r14+0x60]
00007b00b77d2572  movups [r13+rax*1], xmm5
00007b00b77d2578  lea rax, [r14+0x40]
00007b00b77d257c  vmovaps xmm1, [rsp+0x70]
00007b00b77d2582  movups [r13+rax*1], xmm1
00007b00b77d2588  lea rax, [r14+0x20]
00007b00b77d258c  vmovaps xmm1, [rsp+0xA0]
00007b00b77d2595  movups [r13+rax*1], xmm1
00007b00b77d259b  lea rax, [r14+0x30]
00007b00b77d259f  vmovaps xmm1, [rsp+0x90]
00007b00b77d25a8  movups [r13+rax*1], xmm1
00007b00b77d25ae  lea rax, [r14+0x10]
00007b00b77d25b2  vmovaps xmm1, [rsp+0xB0]
00007b00b77d25bb  movups [r13+rax*1], xmm1
00007b00b77d25c1  mov rax, [r15+0x40]
00007b00b77d25c5  vxorps xmm1, xmm1, xmm1
00007b00b77d25c9  vpbroadcastq xmm1, xmm1
00007b00b77d25ce  vxorps xmm5, xmm5, xmm5
00007b00b77d25d2  vpbroadcastq xmm5, xmm5
00007b00b77d25d7  lea r12, [rax+0x30]
00007b00b77d25db  mov r11, [r13+r12*1]
00007b00b77d25e0  lea r12, [rax+0x38]
00007b00b77d25e4  mov r10, [r13+r12*1]
00007b00b77d25e9  vmovaps [rsp+0x60], xmm1
00007b00b77d25ef  movq xmm1, r11
00007b00b77d25f4  vmovaps [rsp+0x70], xmm1
00007b00b77d25fa  movq xmm1, r10
00007b00b77d25ff  vmovaps [rsp+0x90], xmm1
00007b00b77d2608  vmovaps xmm1, [rsp+0x70]
00007b00b77d260e  movq xmm1, xmm1
00007b00b77d2612  vmovaps [rsp+0x70], xmm1
00007b00b77d2618  vmovaps xmm1, [rsp+0x90]
00007b00b77d2621  movq xmm1, xmm1
00007b00b77d2625  vmovaps [rsp+0x90], xmm1
00007b00b77d262e  movq xmm1, xmm1
00007b00b77d2632  movaps [r15+0x270], xmm1
00007b00b77d263a  vmovaps [rsp+0xA0], xmm7
00007b00b77d2643  vmovaps xmm1, [rsp+0xA0]
00007b00b77d264c  por xmm7, xmm1
00007b00b77d2650  lea r12, [rax+0x20]
00007b00b77d2654  mov r11, [r13+r12*1]
00007b00b77d2659  lea r12, [rax+0x28]
00007b00b77d265d  mov r10, [r13+r12*1]
00007b00b77d2662  movq xmm1, r11
00007b00b77d2667  vmovaps [rsp+0xA0], xmm1
00007b00b77d2670  movq xmm1, r10
00007b00b77d2675  vmovaps [rsp+0xB0], xmm1
00007b00b77d267e  vmovaps xmm1, [rsp+0xA0]
00007b00b77d2687  movq xmm1, xmm1
00007b00b77d268b  vmovaps [rsp+0xA0], xmm1
00007b00b77d2694  vmovaps xmm1, [rsp+0xB0]
00007b00b77d269d  movq xmm1, xmm1
00007b00b77d26a1  vmovaps [rsp+0xB0], xmm2
00007b00b77d26aa  vmovaps [rsp+0xC0], xmm1
00007b00b77d26b3  vmovaps xmm1, [rsp+0xB0]
00007b00b77d26bc  por xmm2, xmm1
00007b00b77d26c0  vmovaps [rsp+0xB0], xmm3
00007b00b77d26c9  vmovaps xmm1, [rsp+0xB0]
00007b00b77d26d2  por xmm3, xmm1
00007b00b77d26d6  vmovaps [rsp+0xB0], xmm4
00007b00b77d26df  vmovaps xmm1, [rsp+0xB0]
00007b00b77d26e8  por xmm4, xmm1
00007b00b77d26ec  vmovaps [rsp+0xB0], xmm9
00007b00b77d26f5  vmovaps xmm1, [rsp+0xB0]
00007b00b77d26fe  por xmm9, xmm1
00007b00b77d2703  lea r12, [rax+0x10]
00007b00b77d2707  mov r11, [r13+r12*1]
00007b00b77d270c  lea r12, [rax+0x18]
00007b00b77d2710  mov r10, [r13+r12*1]
00007b00b77d2715  movq xmm1, r11
00007b00b77d271a  vmovaps [rsp+0xB0], xmm1
00007b00b77d2723  movq xmm1, r10
00007b00b77d2728  vmovaps [rsp+0xD0], xmm1
00007b00b77d2731  vmovaps xmm1, [rsp+0xB0]
00007b00b77d273a  movq xmm1, xmm1
00007b00b77d273e  vmovaps [rsp+0xB0], xmm1
00007b00b77d2747  vmovaps xmm1, [rsp+0xD0]
00007b00b77d2750  movq xmm1, xmm1
00007b00b77d2754  vmovaps [rsp+0xD0], xmm1
00007b00b77d275d  vmovaps xmm1, [rsp+0x80]
00007b00b77d2766  vmovaps [rsp+0xE0], xmm15
00007b00b77d276f  vmovaps xmm15, [rsp+0x80]
00007b00b77d2778  por xmm1, xmm15
00007b00b77d277d  vmovaps xmm15, [rsp+0x10]
00007b00b77d2783  vmovaps [rsp+0x80], xmm1
00007b00b77d278c  vmovaps xmm1, [rsp+0x10]
00007b00b77d2792  por xmm15, xmm1
00007b00b77d2797  vmovaps xmm1, [rsp+0x20]
00007b00b77d279d  vmovaps [rsp+0x10], xmm15
00007b00b77d27a3  vmovaps xmm15, [rsp+0x20]
00007b00b77d27a9  por xmm1, xmm15
00007b00b77d27ae  vmovaps [rsp+0x20], xmm6
00007b00b77d27b4  vmovaps xmm15, [rsp+0x20]
00007b00b77d27ba  por xmm6, xmm15
00007b00b77d27bf  vmovaps [rsp+0x20], xmm11
00007b00b77d27c5  vmovaps xmm15, [rsp+0x20]
00007b00b77d27cb  por xmm11, xmm15
00007b00b77d27d0  vmovaps [rsp+0x20], xmm13
00007b00b77d27d6  vmovaps xmm15, [rsp+0x20]
00007b00b77d27dc  por xmm13, xmm15
00007b00b77d27e1  vmovaps [rsp+0x20], xmm14
00007b00b77d27e7  vmovaps xmm15, [rsp+0x20]
00007b00b77d27ed  por xmm14, xmm15
00007b00b77d27f2  mov r12, [r13+rax*1]
00007b00b77d27f7  vmovq xmm15, r12
00007b00b77d27fc  vpbroadcastq xmm15, xmm15
00007b00b77d2801  vmovaps [rsp+0x20], xmm1
00007b00b77d2807  vxorps xmm1, xmm1, xmm1
00007b00b77d280b  vpbroadcastq xmm1, xmm1
00007b00b77d2810  vmovaps [rsp+0xF0], xmm1
00007b00b77d2819  movups xmm1, [r13+r14*1]
00007b00b77d281f  vmovaps [rsp+0x100], xmm1
00007b00b77d2828  vxorps xmm1, xmm1, xmm1
00007b00b77d282c  vpbroadcastq xmm1, xmm1
00007b00b77d2831  lea r12, [rax+0x08]
00007b00b77d2835  mov rax, [r13+r12*1]
00007b00b77d283a  vmovaps [rsp+0x110], xmm1
00007b00b77d2843  movq xmm1, rax
00007b00b77d2848  movaps [r15+0x240], xmm1
00007b00b77d2850  mov qword ptr [r15+0x60], 0x432190
00007b00b77d2858  mov qword ptr [r15+0x58], 0x40
00007b00b77d2860  vmovaps xmm1, [rsp+0x60]
00007b00b77d2866  vmovaps [rsp+0x60], xmm15
00007b00b77d286c  vmovaps xmm15, [rsp+0x100]
00007b00b77d2875  vmovaps [rsp+0x100], xmm14
00007b00b77d287e  vmovaps xmm14, [rsp+0x60]
00007b00b77d2884  vmovaps [rsp+0x60], xmm13
00007b00b77d288a  vmovaps [rsp+0x120], xmm12
00007b00b77d2893  movaps xmm13, xmm1
00007b00b77d2897  vfmadd231pd xmm13, xmm15, xmm14
00007b00b77d289c  vcmppd xmm12, xmm13, xmm13, 0x03
00007b00b77d28a2  vptest xmm12, xmm12
00007b00b77d28a7  jnz 0x00007B00B77D3482
00007b00b77d28ad  vmovaps xmm1, [rsp+0xE0]
00007b00b77d28b6  movaps xmm15, xmm5
00007b00b77d28ba  vfmadd231pd xmm15, xmm1, xmm14
00007b00b77d28bf  vcmppd xmm12, xmm15, xmm15, 0x03
00007b00b77d28c5  vptest xmm12, xmm12
00007b00b77d28ca  jnz 0x00007B00B77D35DB
00007b00b77d28d0  vmovaps xmm12, [rsp+0x50]
00007b00b77d28d6  vmovaps xmm5, [rsp+0x50]
00007b00b77d28dc  por xmm12, xmm5
00007b00b77d28e1  vmovaps xmm5, [rsp+0x30]
00007b00b77d28e7  vmovaps [rsp+0x50], xmm1
00007b00b77d28ed  vmovaps xmm1, [rsp+0x30]
00007b00b77d28f3  por xmm5, xmm1
00007b00b77d28f7  vmovaps [rsp+0x30], xmm10
00007b00b77d28fd  vmovaps xmm1, [rsp+0x30]
00007b00b77d2903  por xmm10, xmm1
00007b00b77d2908  vmovaps [rsp+0x30], xmm8
00007b00b77d290e  vmovaps xmm1, [rsp+0x30]
00007b00b77d2914  por xmm8, xmm1
00007b00b77d2919  vmovaps xmm1, [rsp+0x120]
00007b00b77d2922  vmovaps [rsp+0x30], xmm15
00007b00b77d2928  vmovaps xmm15, [rsp+0x120]
00007b00b77d2931  por xmm1, xmm15
00007b00b77d2936  vmovaps xmm15, [rsp+0x50]
00007b00b77d293c  vmovaps [rsp+0xE0], xmm1
00007b00b77d2945  vmovaps xmm1, [rsp+0x50]
00007b00b77d294b  por xmm15, xmm1
00007b00b77d2950  lea rax, [r14+0xC0]
00007b00b77d2957  movups xmm1, [r13+rax*1]
00007b00b77d295d  xor eax, eax
00007b00b77d295f  mov r12d, 0x40
00007b00b77d2965  mov r11d, 0x200
00007b00b77d296b  cmp r12, r11
00007b00b77d296e  cmc
00007b00b77d296f  lahf
00007b00b77d2970  seto al
00007b00b77d2973  mov [r15+0x108], eax
00007b00b77d297a  vmovaps [rsp+0x50], xmm1
00007b00b77d2980  vmovaps xmm1, [rsp+0xF0]
00007b00b77d2989  vmovaps [rsp+0xF0], xmm15
00007b00b77d2992  vmovaps xmm15, [rsp+0x50]
00007b00b77d2998  vmovaps [rsp+0x50], xmm13
00007b00b77d299e  vmovaps [rsp+0x120], xmm12
00007b00b77d29a7  movaps xmm13, xmm1
00007b00b77d29ab  vfmadd231pd xmm13, xmm15, xmm14
00007b00b77d29b0  vcmppd xmm12, xmm13, xmm13, 0x03
00007b00b77d29b6  vptest xmm12, xmm12
00007b00b77d29bb  jnz 0x00007B00B77D373D
00007b00b77d29c1  lea rax, [r14+0xB0]
00007b00b77d29c8  movups xmm1, [r13+rax*1]
00007b00b77d29ce  vmovaps xmm15, [rsp+0x110]
00007b00b77d29d7  vmovaps [rsp+0x110], xmm13
00007b00b77d29e0  movaps xmm12, xmm15
00007b00b77d29e4  vfmadd231pd xmm12, xmm1, xmm14
00007b00b77d29e9  vcmppd xmm13, xmm12, xmm12, 0x03
00007b00b77d29ef  vptest xmm13, xmm13
00007b00b77d29f4  jnz 0x00007B00B77D38A0
00007b00b77d29fa  vmovaps xmm1, [rsp+0x100]
00007b00b77d2a03  vmovaps xmm15, [rsp+0x100]
00007b00b77d2a0c  por xmm1, xmm15
00007b00b77d2a11  movaps [r15+0x210], xmm1
00007b00b77d2a19  vmovaps xmm15, [rsp+0x60]
00007b00b77d2a1f  vmovaps xmm14, [rsp+0x60]
00007b00b77d2a25  por xmm15, xmm14
00007b00b77d2a2a  movaps [r15+0x1C0], xmm15
00007b00b77d2a32  vmovaps [rsp+0x60], xmm11
00007b00b77d2a38  vmovaps xmm14, [rsp+0x60]
00007b00b77d2a3e  por xmm11, xmm14
00007b00b77d2a43  movaps [r15+0x280], xmm11
00007b00b77d2a4b  vmovaps [rsp+0x60], xmm6
00007b00b77d2a51  vmovaps xmm14, [rsp+0x60]
00007b00b77d2a57  por xmm6, xmm14
00007b00b77d2a5c  movaps [r15+0x2A0], xmm6
00007b00b77d2a64  vmovaps xmm14, [rsp+0x20]
00007b00b77d2a6a  vmovaps xmm13, [rsp+0x20]
00007b00b77d2a70  por xmm14, xmm13
00007b00b77d2a75  movaps [r15+0x2E0], xmm14
00007b00b77d2a7d  vmovaps xmm13, [rsp+0x10]
00007b00b77d2a83  vmovaps [rsp+0x20], xmm1
00007b00b77d2a89  vmovaps xmm1, [rsp+0x10]
00007b00b77d2a8f  por xmm13, xmm1
00007b00b77d2a94  movaps [r15+0x1F0], xmm13
00007b00b77d2a9c  vmovaps xmm1, [rsp+0xF0]
00007b00b77d2aa5  vmovaps [rsp+0x10], xmm15
00007b00b77d2aab  vmovaps xmm15, [rsp+0xF0]
00007b00b77d2ab4  por xmm1, xmm15
00007b00b77d2ab9  movaps [r15+0x250], xmm1
00007b00b77d2ac1  vmovaps xmm1, [rsp+0xE0]
00007b00b77d2aca  vmovaps xmm15, [rsp+0xE0]
00007b00b77d2ad3  por xmm1, xmm15
00007b00b77d2ad8  movaps [r15+0x260], xmm1
00007b00b77d2ae0  vmovaps [rsp+0x60], xmm8
00007b00b77d2ae6  vmovaps xmm15, [rsp+0x60]
00007b00b77d2aec  por xmm8, xmm15
00007b00b77d2af1  movaps [r15+0x290], xmm8
00007b00b77d2af9  vmovaps [rsp+0x60], xmm10
00007b00b77d2aff  vmovaps xmm15, [rsp+0x60]
00007b00b77d2b05  por xmm10, xmm15
00007b00b77d2b0a  movaps [r15+0x2C0], xmm10
00007b00b77d2b12  movq xmm15, qword ptr [r15+0x240]
00007b00b77d2b1b  vmovaps [rsp+0x60], xmm15
00007b00b77d2b21  vpermilpd xmm15, xmm15, 0x00
00007b00b77d2b27  vmovaps [rsp+0xE0], xmm1
00007b00b77d2b30  vmovaps xmm1, [rsp+0x50]
00007b00b77d2b36  vmovaps [rsp+0x50], xmm15
00007b00b77d2b3c  vmovaps xmm15, [rsp+0x20]
00007b00b77d2b42  vmovaps [rsp+0x20], xmm14
00007b00b77d2b48  vmovaps xmm14, [rsp+0x50]
00007b00b77d2b4e  vmovaps [rsp+0x50], xmm13
00007b00b77d2b54  vmovaps [rsp+0xF0], xmm12
00007b00b77d2b5d  movaps xmm13, xmm1
00007b00b77d2b61  vfmadd231pd xmm13, xmm15, xmm14
00007b00b77d2b66  vcmppd xmm12, xmm13, xmm13, 0x03
00007b00b77d2b6c  vptest xmm12, xmm12
00007b00b77d2b71  jnz 0x00007B00B77D39F9
00007b00b77d2b77  vmovaps xmm1, [rsp+0x60]
00007b00b77d2b7d  vpermilpd xmm1, xmm1, 0x00
00007b00b77d2b83  vmovaps xmm15, [rsp+0x110]
00007b00b77d2b8c  vmovaps xmm14, [rsp+0x20]
00007b00b77d2b92  vmovaps [rsp+0x20], xmm13
00007b00b77d2b98  movaps xmm12, xmm15
00007b00b77d2b9c  vfmadd231pd xmm12, xmm14, xmm1
00007b00b77d2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
00007b00b77d2ba7  vptest xmm13, xmm13
00007b00b77d2bac  jnz 0x00007B00B77D3B52
00007b00b77d2bb2  vmovaps xmm1, [rsp+0x60]
00007b00b77d2bb8  vpermilpd xmm1, xmm1, 0x00
00007b00b77d2bbe  vmovaps xmm15, [rsp+0x30]
00007b00b77d2bc4  vmovaps xmm14, [rsp+0x10]
00007b00b77d2bca  vmovaps [rsp+0x10], xmm12
00007b00b77d2bd0  movaps xmm13, xmm15
00007b00b77d2bd4  vfmadd231pd xmm13, xmm14, xmm1
00007b00b77d2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007b00b77d2bdf  vptest xmm12, xmm12
00007b00b77d2be4  jnz 0x00007B00B77D3CAB
00007b00b77d2bea  vmovaps [rsp+0x30], xmm5
00007b00b77d2bf0  vmovaps xmm1, [rsp+0x30]
00007b00b77d2bf6  por xmm5, xmm1
00007b00b77d2bfa  movaps [r15+0x1D0], xmm5
00007b00b77d2c02  vmovaps xmm1, [rsp+0x60]
00007b00b77d2c08  vpermilpd xmm1, xmm1, 0x00
00007b00b77d2c0e  vmovaps xmm15, [rsp+0xF0]
00007b00b77d2c17  vmovaps xmm14, [rsp+0x50]
00007b00b77d2c1d  vmovaps [rsp+0x30], xmm13
00007b00b77d2c23  movaps xmm12, xmm15
00007b00b77d2c27  vfmadd231pd xmm12, xmm14, xmm1
00007b00b77d2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
00007b00b77d2c32  vptest xmm13, xmm13
00007b00b77d2c37  jnz 0x00007B00B77D3E04
00007b00b77d2c3d  vmovaps xmm1, [rsp+0x80]
00007b00b77d2c46  vmovaps xmm15, [rsp+0x80]
00007b00b77d2c4f  por xmm1, xmm15
00007b00b77d2c54  movaps [r15+0x200], xmm1
00007b00b77d2c5c  vmovaps xmm15, [rsp+0x120]
00007b00b77d2c65  vmovaps xmm14, [rsp+0x120]
00007b00b77d2c6e  por xmm15, xmm14
00007b00b77d2c73  movaps [r15+0x1E0], xmm15
00007b00b77d2c7b  vmovaps [rsp+0x50], xmm4
00007b00b77d2c81  vmovaps xmm13, [rsp+0x50]
00007b00b77d2c87  por xmm4, xmm13
00007b00b77d2c8c  movaps [r15+0x2B0], xmm4
00007b00b77d2c94  vmovaps [rsp+0x50], xmm3
00007b00b77d2c9a  vmovaps xmm13, [rsp+0x50]
00007b00b77d2ca0  por xmm3, xmm13
00007b00b77d2ca5  movaps [r15+0x300], xmm3
00007b00b77d2cad  vmovaps xmm15, [rsp+0xB0]
00007b00b77d2cb6  vpermilpd xmm15, xmm15, 0x00
00007b00b77d2cbc  vmovaps xmm3, [rsp+0x20]
00007b00b77d2cc2  vmovaps [rsp+0x20], xmm1
00007b00b77d2cc8  vmovaps xmm1, [rsp+0xE0]
00007b00b77d2cd1  vmovaps [rsp+0x50], xmm14
00007b00b77d2cd7  vmovaps [rsp+0x60], xmm13
00007b00b77d2cdd  movaps xmm14, xmm3
00007b00b77d2ce1  vfmadd231pd xmm14, xmm1, xmm15
00007b00b77d2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
00007b00b77d2cec  vptest xmm13, xmm13
00007b00b77d2cf1  jnz 0x00007B00B77D3F5D
00007b00b77d2cf7  vmovaps xmm1, [rsp+0xB0]
00007b00b77d2d00  vpermilpd xmm1, xmm1, 0x00
00007b00b77d2d06  vmovaps xmm15, [rsp+0x10]
00007b00b77d2d0c  movaps xmm13, xmm15
00007b00b77d2d10  vfmadd231pd xmm13, xmm10, xmm1
00007b00b77d2d15  vcmppd xmm3, xmm13, xmm13, 0x03
00007b00b77d2d1b  vptest xmm3, xmm3
00007b00b77d2d20  jnz 0x00007B00B77D40B5
00007b00b77d2d26  vmovaps xmm1, [rsp+0xB0]
00007b00b77d2d2f  vpermilpd xmm1, xmm1, 0x00
00007b00b77d2d35  vmovaps xmm15, [rsp+0x30]
00007b00b77d2d3b  movaps xmm10, xmm15
00007b00b77d2d3f  vfmadd231pd xmm10, xmm11, xmm1
00007b00b77d2d44  vcmppd xmm3, xmm10, xmm10, 0x03
00007b00b77d2d4a  vptest xmm3, xmm3
00007b00b77d2d4f  jnz 0x00007B00B77D420E
00007b00b77d2d55  vmovaps xmm1, [rsp+0xB0]
00007b00b77d2d5e  vpermilpd xmm1, xmm1, 0x00
00007b00b77d2d64  movaps xmm15, xmm12
00007b00b77d2d68  vfmadd231pd xmm15, xmm5, xmm1
00007b00b77d2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
00007b00b77d2d73  vptest xmm11, xmm11
00007b00b77d2d78  jnz 0x00007B00B77D4367
00007b00b77d2d7e  vmovaps [rsp+0x10], xmm9
00007b00b77d2d84  vmovaps xmm1, [rsp+0x10]
00007b00b77d2d8a  por xmm9, xmm1
00007b00b77d2d8f  movaps [r15+0x180], xmm9
00007b00b77d2d97  vmovaps [rsp+0x10], xmm2
00007b00b77d2d9d  vmovaps xmm1, [rsp+0x10]
00007b00b77d2da3  por xmm2, xmm1
00007b00b77d2da7  movaps [r15+0x2D0], xmm2
00007b00b77d2daf  vmovaps xmm12, [rsp+0xD0]
00007b00b77d2db8  vpermilpd xmm12, xmm12, 0x00
00007b00b77d2dbe  vmovaps xmm11, [rsp+0x60]
00007b00b77d2dc4  movaps xmm5, xmm13
00007b00b77d2dc8  vfmadd231pd xmm5, xmm11, xmm12
00007b00b77d2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
00007b00b77d2dd2  vptest xmm3, xmm3
00007b00b77d2dd7  jnz 0x00007B00B77D44BF
00007b00b77d2ddd  vmovaps xmm13, [rsp+0xD0]
00007b00b77d2de6  vpermilpd xmm13, xmm13, 0x00
00007b00b77d2dec  movaps xmm12, xmm14
00007b00b77d2df0  vfmadd231pd xmm12, xmm9, xmm13
00007b00b77d2df5  vcmppd xmm11, xmm12, xmm12, 0x03
00007b00b77d2dfb  vptest xmm11, xmm11
00007b00b77d2e00  jnz 0x00007B00B77D4617
00007b00b77d2e06  lea rax, [r14+0x80]
00007b00b77d2e0d  movups xmm14, [r13+rax*1]
00007b00b77d2e13  movaps [r15+0x2F0], xmm14
00007b00b77d2e1b  vmovaps xmm13, [rsp+0xD0]
00007b00b77d2e24  vpermilpd xmm13, xmm13, 0x00
00007b00b77d2e2a  movaps xmm11, xmm10
00007b00b77d2e2e  vfmadd231pd xmm11, xmm8, xmm13
00007b00b77d2e33  vcmppd xmm9, xmm11, xmm11, 0x03
00007b00b77d2e39  vptest xmm9, xmm9
00007b00b77d2e3e  jnz 0x00007B00B77D477B
00007b00b77d2e44  vmovaps xmm13, [rsp+0xD0]
00007b00b77d2e4d  vpermilpd xmm13, xmm13, 0x00
00007b00b77d2e53  movaps xmm10, xmm15
00007b00b77d2e57  vfmadd231pd xmm10, xmm1, xmm13
00007b00b77d2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
00007b00b77d2e62  vptest xmm9, xmm9
00007b00b77d2e67  jnz 0x00007B00B77D48D5
00007b00b77d2e6d  vmovaps [rsp+0x10], xmm7
00007b00b77d2e73  vmovaps xmm1, [rsp+0x10]
00007b00b77d2e79  por xmm7, xmm1
00007b00b77d2e7d  movaps [r15+0x160], xmm7
00007b00b77d2e85  lea rax, [r14+0x40]
00007b00b77d2e89  movups xmm1, [r13+rax*1]
00007b00b77d2e8f  lea rax, [r14+0x50]
00007b00b77d2e93  movups xmm15, [r13+rax*1]
00007b00b77d2e99  movaps [r15+0x1B0], xmm1
00007b00b77d2ea1  movaps [r15+0x1A0], xmm15
00007b00b77d2ea9  vmovaps xmm13, [rsp+0xA0]
00007b00b77d2eb2  vpermilpd xmm13, xmm13, 0x00
00007b00b77d2eb8  vmovaps xmm9, [rsp+0x40]
00007b00b77d2ebe  movaps xmm8, xmm5
00007b00b77d2ec2  vfmadd231pd xmm8, xmm9, xmm13
00007b00b77d2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
00007b00b77d2ecd  vptest xmm3, xmm3
00007b00b77d2ed2  jnz 0x00007B00B77D4A42
00007b00b77d2ed8  vmovaps xmm13, [rsp+0xA0]
00007b00b77d2ee1  vpermilpd xmm13, xmm13, 0x00
00007b00b77d2ee7  movaps xmm9, xmm12
00007b00b77d2eeb  vfmadd231pd xmm9, xmm7, xmm13
00007b00b77d2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
00007b00b77d2ef6  vptest xmm5, xmm5
00007b00b77d2efb  jnz 0x00007B00B77D4B9B
00007b00b77d2f01  vmovaps xmm13, [rsp+0xA0]
00007b00b77d2f0a  vpermilpd xmm13, xmm13, 0x00
00007b00b77d2f10  movaps xmm12, xmm11
00007b00b77d2f14  vfmadd231pd xmm12, xmm6, xmm13
00007b00b77d2f19  vcmppd xmm7, xmm12, xmm12, 0x03
00007b00b77d2f1f  vptest xmm7, xmm7
00007b00b77d2f24  jnz 0x00007B00B77D4CF4
00007b00b77d2f2a  vmovaps xmm13, [rsp+0xA0]
00007b00b77d2f33  vpermilpd xmm13, xmm13, 0x00
00007b00b77d2f39  vmovaps xmm11, [rsp+0x50]
00007b00b77d2f3f  movaps xmm7, xmm10
00007b00b77d2f43  vfmadd231pd xmm7, xmm11, xmm13
00007b00b77d2f48  vcmppd xmm6, xmm7, xmm7, 0x03
00007b00b77d2f4d  vptest xmm6, xmm6
00007b00b77d2f52  jnz 0x00007B00B77D4E4D
00007b00b77d2f58  lea rax, [r14+0x60]
00007b00b77d2f5c  movups xmm13, [r13+rax*1]
00007b00b77d2f62  lea rax, [r14+0x70]
00007b00b77d2f66  movups xmm11, [r13+rax*1]
00007b00b77d2f6c  movaps [r15+0x150], xmm13
00007b00b77d2f74  movaps [r15+0x120], xmm11
00007b00b77d2f7c  vmovaps xmm10, [rsp+0xC0]
00007b00b77d2f85  vpermilpd xmm10, xmm10, 0x00
00007b00b77d2f8b  movaps xmm6, xmm8
00007b00b77d2f8f  vfmadd231pd xmm6, xmm15, xmm10
00007b00b77d2f94  vcmppd xmm5, xmm6, xmm6, 0x03
00007b00b77d2f99  vptest xmm5, xmm5
00007b00b77d2f9e  jnz 0x00007B00B77D4FB9
00007b00b77d2fa4  vmovaps xmm15, [rsp+0xC0]
00007b00b77d2fad  vpermilpd xmm15, xmm15, 0x00
00007b00b77d2fb3  movaps xmm10, xmm9
00007b00b77d2fb7  vfmadd231pd xmm10, xmm13, xmm15
00007b00b77d2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
00007b00b77d2fc2  vptest xmm8, xmm8
00007b00b77d2fc7  jnz 0x00007B00B77D5111
00007b00b77d2fcd  vmovaps xmm15, [rsp+0xC0]
00007b00b77d2fd6  vpermilpd xmm15, xmm15, 0x00
00007b00b77d2fdc  movaps xmm13, xmm12
00007b00b77d2fe0  vfmadd231pd xmm13, xmm4, xmm15
00007b00b77d2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
00007b00b77d2feb  vptest xmm9, xmm9
00007b00b77d2ff0  jnz 0x00007B00B77D526B
00007b00b77d2ff6  vmovaps xmm15, [rsp+0xC0]
00007b00b77d2fff  vpermilpd xmm15, xmm15, 0x00
00007b00b77d3005  movaps xmm12, xmm7
00007b00b77d3009  vfmadd231pd xmm12, xmm1, xmm15
00007b00b77d300e  vcmppd xmm9, xmm12, xmm12, 0x03
00007b00b77d3014  vptest xmm9, xmm9
00007b00b77d3019  jnz 0x00007B00B77D53C4
00007b00b77d301f  lea rax, [r14+0x20]
00007b00b77d3023  movups xmm1, [r13+rax*1]
00007b00b77d3029  lea rax, [r14+0x30]
00007b00b77d302d  movups xmm15, [r13+rax*1]
00007b00b77d3033  vmovaps xmm9, [rsp+0x70]
00007b00b77d3039  vpermilpd xmm9, xmm9, 0x00
00007b00b77d303f  vmovaps xmm8, [rsp+0x20]
00007b00b77d3045  movaps xmm7, xmm6
00007b00b77d3048  vfmadd231pd xmm7, xmm8, xmm9
00007b00b77d304d  vcmppd xmm5, xmm7, xmm7, 0x03
00007b00b77d3052  vptest xmm5, xmm5
00007b00b77d3057  jnz 0x00007B00B77D5530
00007b00b77d305d  vmovaps xmm9, [rsp+0x70]
00007b00b77d3063  vpermilpd xmm9, xmm9, 0x00
00007b00b77d3069  movaps xmm8, xmm10
00007b00b77d306d  vfmadd231pd xmm8, xmm14, xmm9
00007b00b77d3072  vcmppd xmm6, xmm8, xmm8, 0x03
00007b00b77d3078  vptest xmm6, xmm6
00007b00b77d307d  jnz 0x00007B00B77D5687
00007b00b77d3083  vmovaps xmm14, [rsp+0x70]
00007b00b77d3089  vpermilpd xmm14, xmm14, 0x00
00007b00b77d308f  movaps xmm10, xmm13
00007b00b77d3093  vfmadd231pd xmm10, xmm11, xmm14
00007b00b77d3098  vcmppd xmm9, xmm10, xmm10, 0x03
00007b00b77d309e  vptest xmm9, xmm9
00007b00b77d30a3  jnz 0x00007B00B77D57E1
00007b00b77d30a9  vmovaps xmm14, [rsp+0x70]
00007b00b77d30af  vpermilpd xmm14, xmm14, 0x00
00007b00b77d30b5  movaps xmm13, xmm12
00007b00b77d30b9  vfmadd231pd xmm13, xmm15, xmm14
00007b00b77d30be  vcmppd xmm11, xmm13, xmm13, 0x03
00007b00b77d30c4  vptest xmm11, xmm11
00007b00b77d30c9  jnz 0x00007B00B77D593B
00007b00b77d30cf  lea rax, [r14+0x90]
00007b00b77d30d6  movups xmm15, [r13+rax*1]
00007b00b77d30dc  lea rax, [r14+0xA0]
00007b00b77d30e3  movups xmm14, [r13+rax*1]
00007b00b77d30e9  movaps [r15+0x140], xmm15
00007b00b77d30f1  movaps [r15+0x130], xmm14
00007b00b77d30f9  vmovaps xmm12, [rsp+0x90]
00007b00b77d3102  vpermilpd xmm12, xmm12, 0x00
00007b00b77d3108  movaps xmm11, xmm7
00007b00b77d310c  vfmadd231pd xmm11, xmm1, xmm12
00007b00b77d3111  vcmppd xmm9, xmm11, xmm11, 0x03
00007b00b77d3117  vptest xmm9, xmm9
00007b00b77d311c  jnz 0x00007B00B77D5AA9
00007b00b77d3122  movaps [r15+0x220], xmm11
00007b00b77d312a  lea rax, [r14+0x10]
00007b00b77d312e  movups xmm1, [r13+rax*1]
00007b00b77d3134  movaps [r15+0x240], xmm1
00007b00b77d313c  vmovaps xmm12, [rsp+0x90]
00007b00b77d3145  vpermilpd xmm12, xmm12, 0x00
00007b00b77d314b  movaps xmm9, xmm8
00007b00b77d314f  vfmadd231pd xmm9, xmm14, xmm12
00007b00b77d3154  vcmppd xmm7, xmm9, xmm9, 0x03
00007b00b77d315a  vptest xmm7, xmm7
00007b00b77d315f  jnz 0x00007B00B77D5C0B
00007b00b77d3165  movaps [r15+0x110], xmm9
00007b00b77d316d  vmovaps xmm14, [rsp+0x90]
00007b00b77d3176  vpermilpd xmm14, xmm14, 0x00
00007b00b77d317c  movaps xmm12, xmm10
00007b00b77d3180  vfmadd231pd xmm12, xmm15, xmm14
00007b00b77d3185  vcmppd xmm8, xmm12, xmm12, 0x03
00007b00b77d318b  vptest xmm8, xmm8
00007b00b77d3190  jnz 0x00007B00B77D5D65
00007b00b77d3196  movaps [r15+0x170], xmm12
00007b00b77d319e  vmovaps xmm15, [rsp+0x90]
00007b00b77d31a7  vpermilpd xmm15, xmm15, 0x00
00007b00b77d31ad  movaps xmm14, xmm13
00007b00b77d31b1  vfmadd231pd xmm14, xmm1, xmm15
00007b00b77d31b6  vcmppd xmm10, xmm14, xmm14, 0x03
00007b00b77d31bc  vptest xmm10, xmm10
00007b00b77d31c1  jnz 0x00007B00B77D5EBF
00007b00b77d31c7  movaps [r15+0x230], xmm14
00007b00b77d31cf  mov eax, 0x432190
00007b00b77d31d4  movups [r13+rax*1], xmm9
00007b00b77d31da  mov eax, 0x4321A0
00007b00b77d31df  movups [r13+rax*1], xmm12
00007b00b77d31e5  mov eax, 0x4321B0
00007b00b77d31ea  movups [r13+rax*1], xmm11
00007b00b77d31f0  mov eax, 0x4321C0
00007b00b77d31f5  movups [r13+rax*1], xmm14
00007b00b77d31fb  mov eax, [r15+0x108]
00007b00b77d3202  sahf
00007b00b77d3203  jnz 0x00007B00B77D3235
00007b00b77d3205  cmp dword ptr [r15+0x318], 0x00
00007b00b77d320d  jz 0x00007B00B77D9950
00007b00b77d3213  nop [rax+rax*1], ax
00007b00b77d321c  nop [rax+rax*1], eax
00007b00b77d3224  mov eax, 0x410664
00007b00b77d3229  mov [r15+0x100], rax
00007b00b77d3230  jmp 0x00007B00B75FE110
00007b00b77d3235  cmp dword ptr [r15+0x318], 0x00
00007b00b77d323d  jz 0x00007B00B77D6050
00007b00b77d3243  nop [rax+rax*1], ax
00007b00b77d324c  nop [rax+rax*1], eax
00007b00b77d3254  mov eax, 0x4104F0
00007b00b77d3259  mov [r15+0x100], rax
00007b00b77d3260  jmp 0x00007B00B75FE110
00007b00b77d3265  int3
00007b00b77d3266  call 0x00007B00B75FF430
00007b00b77d326b  jmp 0x00007B00B77D230A
00007b00b77d3270  call 0x00007B00B76E5820
00007b00b77d3275  jmp 0x00007B00B77D2314
00007b00b77d327a  call 0x00007B00B76E45A0
00007b00b77d327f  jmp 0x00007B00B77D2326
00007b00b77d3284  call 0x00007B00B76E3320
00007b00b77d3289  jmp 0x00007B00B77D2330
00007b00b77d328e  call 0x00007B00B76E20A0
00007b00b77d3293  jmp 0x00007B00B77D233D
00007b00b77d3298  call 0x00007B00B76E0E30
00007b00b77d329d  jmp 0x00007B00B77D234A
00007b00b77d32a2  call 0x00007B00B76D6600
00007b00b77d32a7  jmp 0x00007B00B77D2357
00007b00b77d32ac  call 0x00007B00B76B52F0
00007b00b77d32b1  jmp 0x00007B00B77D2361
00007b00b77d32b6  call 0x00007B00B76BE9C0
00007b00b77d32bb  jmp 0x00007B00B77D236B
00007b00b77d32c0  call 0x00007B00B76BD750
00007b00b77d32c5  jmp 0x00007B00B77D2378
00007b00b77d32ca  call 0x00007B00B76BC4E0
00007b00b77d32cf  jmp 0x00007B00B77D2385
00007b00b77d32d4  call 0x00007B00B76BB270
00007b00b77d32d9  jmp 0x00007B00B77D2392
00007b00b77d32de  call 0x00007B00B76BA000
00007b00b77d32e3  jmp 0x00007B00B77D239F
00007b00b77d32e8  call 0x00007B00B76B8D90
00007b00b77d32ed  jmp 0x00007B00B77D23AC
00007b00b77d32f2  call 0x00007B00B76B8A20
00007b00b77d32f7  jmp 0x00007B00B77D23B9
00007b00b77d32fc  call 0x00007B00B76BEAE0
00007b00b77d3301  jmp 0x00007B00B77D23C6
00007b00b77d3306  call 0x00007B00B76B5400
00007b00b77d330b  jmp 0x00007B00B77D23D3
00007b00b77d3310  call 0x00007B00B76B52F0
00007b00b77d3315  jmp 0x00007B00B77D23E0
00007b00b77d331a  call 0x00007B00B76BE9C0
00007b00b77d331f  jmp 0x00007B00B77D23ED
00007b00b77d3324  call 0x00007B00B76B77B0
00007b00b77d3329  jmp 0x00007B00B77D23FA
00007b00b77d332e  call 0x00007B00B76B6550
00007b00b77d3333  jmp 0x00007B00B77D2407
00007b00b77d3338  call 0x00007B00B76B52F0
00007b00b77d333d  jmp 0x00007B00B77D2417
00007b00b77d3342  call 0x00007B00B76B52F0
00007b00b77d3347  jmp 0x00007B00B77D2427
00007b00b77d334c  call 0x00007B00B76BEAE0
00007b00b77d3351  jmp 0x00007B00B77D2431
00007b00b77d3356  call 0x00007B00B76BEAE0
00007b00b77d335b  jmp 0x00007B00B77D2444
00007b00b77d3360  call 0x00007B00B76BE9C0
00007b00b77d3365  jmp 0x00007B00B77D2451
00007b00b77d336a  call 0x00007B00B76B52F0
00007b00b77d336f  jmp 0x00007B00B77D2464
00007b00b77d3374  call 0x00007B00B76B6660
00007b00b77d3379  jmp 0x00007B00B77D2471
00007b00b77d337e  call 0x00007B00B76B78C0
00007b00b77d3383  jmp 0x00007B00B77D247E
00007b00b77d3388  call 0x00007B00B76B77B0
00007b00b77d338d  jmp 0x00007B00B77D248B
00007b00b77d3392  call 0x00007B00B76B6550
00007b00b77d3397  jmp 0x00007B00B77D2498
00007b00b77d339c  call 0x00007B00B76B52F0
00007b00b77d33a1  jmp 0x00007B00B77D24AB
00007b00b77d33a6  call 0x00007B00B76B52F0
00007b00b77d33ab  jmp 0x00007B00B77D24BE
00007b00b77d33b0  call 0x00007B00B76B52F0
00007b00b77d33b5  jmp 0x00007B00B77D24E5
00007b00b77d33ba  call 0x00007B00B76B52F0
00007b00b77d33bf  jmp 0x00007B00B77D24F8
00007b00b77d33c4  call 0x00007B00B76B52F0
00007b00b77d33c9  jmp 0x00007B00B77D250B
00007b00b77d33ce  call 0x00007B00B76B52F0
00007b00b77d33d3  jmp 0x00007B00B77D2521
00007b00b77d33d8  call 0x00007B00B76B52F0
00007b00b77d33dd  jmp 0x00007B00B77D2537
00007b00b77d33e2  call 0x00007B00B76B52F0
00007b00b77d33e7  jmp 0x00007B00B77D254D
00007b00b77d33ec  call 0x00007B00B75FF540
00007b00b77d33f1  jmp 0x00007B00B77D256E
00007b00b77d33f6  call 0x00007B00B7602FE0
00007b00b77d33fb  jmp 0x00007B00B77D2578
00007b00b77d3400  call 0x00007B00B75FF540
00007b00b77d3405  jmp 0x00007B00B77D2588
00007b00b77d340a  call 0x00007B00B75FF540
00007b00b77d340f  jmp 0x00007B00B77D259B
00007b00b77d3414  call 0x00007B00B75FF540
00007b00b77d3419  jmp 0x00007B00B77D25AE
00007b00b77d341e  call 0x00007B00B75FF540
00007b00b77d3423  jmp 0x00007B00B77D25C1
00007b00b77d3428  call 0x00007B00B76C0370
00007b00b77d342d  jmp 0x00007B00B77D25E0
00007b00b77d3432  call 0x00007B00B76BF100
00007b00b77d3437  jmp 0x00007B00B77D25E9
00007b00b77d343c  call 0x00007B00B76C0370
00007b00b77d3441  jmp 0x00007B00B77D2659
00007b00b77d3446  call 0x00007B00B76BF100
00007b00b77d344b  jmp 0x00007B00B77D2662
00007b00b77d3450  call 0x00007B00B76C0370
00007b00b77d3455  jmp 0x00007B00B77D270C
00007b00b77d345a  call 0x00007B00B76BF100
00007b00b77d345f  jmp 0x00007B00B77D2715
00007b00b77d3464  call 0x00007B00B760B720
00007b00b77d3469  jmp 0x00007B00B77D27F7
00007b00b77d346e  call 0x00007B00B76D64F0
00007b00b77d3473  jmp 0x00007B00B77D281F
00007b00b77d3478  call 0x00007B00B76B47C0
00007b00b77d347d  jmp 0x00007B00B77D283A
00007b00b77d3482  sub rsp, 0x08
00007b00b77d3486  push rax
00007b00b77d3487  push rcx
00007b00b77d3488  push rdx
00007b00b77d3489  push rdi
00007b00b77d348a  push rsi
00007b00b77d348b  push r8
00007b00b77d348d  push r9
00007b00b77d348f  push r10
00007b00b77d3491  push r11
00007b00b77d3493  sub rsp, 0xF0
00007b00b77d349a  vmovaps [rsp], xmm0
00007b00b77d349f  vmovaps [rsp+0x10], xmm1
00007b00b77d34a5  vmovaps [rsp+0x20], xmm2
00007b00b77d34ab  vmovaps [rsp+0x30], xmm3
00007b00b77d34b1  vmovaps [rsp+0x40], xmm4
00007b00b77d34b7  vmovaps [rsp+0x50], xmm5
00007b00b77d34bd  vmovaps [rsp+0x60], xmm6
00007b00b77d34c3  vmovaps [rsp+0x70], xmm7
00007b00b77d34c9  vmovaps [rsp+0x80], xmm8
00007b00b77d34d2  vmovaps [rsp+0x90], xmm9
00007b00b77d34db  vmovaps [rsp+0xA0], xmm10
00007b00b77d34e4  vmovaps [rsp+0xB0], xmm11
00007b00b77d34ed  vmovaps [rsp+0xC0], xmm12
00007b00b77d34f6  vmovaps [rsp+0xD0], xmm14
00007b00b77d34ff  vmovaps [rsp+0xE0], xmm15
00007b00b77d3508  sub rsp, 0x40
00007b00b77d350c  lea rdi, [rsp]
00007b00b77d3510  lea rsi, [rsp+0x10]
00007b00b77d3515  lea rdx, [rsp+0x20]
00007b00b77d351a  lea rcx, [rsp+0x30]
00007b00b77d351f  mov r8d, 0x00
00007b00b77d3525  lea r9, [r15+0x3A8]
00007b00b77d352c  movaps [rdi], xmm13
00007b00b77d3530  movaps [rsi], xmm1
00007b00b77d3533  movaps [rdx], xmm15
00007b00b77d3537  movaps [rcx], xmm14
00007b00b77d353b  mov rax, 0x612A23581A50
00007b00b77d3545  call rax
00007b00b77d3547  movaps xmm13, [rsp]
00007b00b77d354c  add rsp, 0x40
00007b00b77d3550  vmovaps xmm0, [rsp]
00007b00b77d3555  vmovaps xmm1, [rsp+0x10]
00007b00b77d355b  vmovaps xmm2, [rsp+0x20]
00007b00b77d3561  vmovaps xmm3, [rsp+0x30]
00007b00b77d3567  vmovaps xmm4, [rsp+0x40]
00007b00b77d356d  vmovaps xmm5, [rsp+0x50]
00007b00b77d3573  vmovaps xmm6, [rsp+0x60]
00007b00b77d3579  vmovaps xmm7, [rsp+0x70]
00007b00b77d357f  vmovaps xmm8, [rsp+0x80]
00007b00b77d3588  vmovaps xmm9, [rsp+0x90]
00007b00b77d3591  vmovaps xmm10, [rsp+0xA0]
00007b00b77d359a  vmovaps xmm11, [rsp+0xB0]
00007b00b77d35a3  vmovaps xmm12, [rsp+0xC0]
00007b00b77d35ac  vmovaps xmm14, [rsp+0xD0]
00007b00b77d35b5  vmovaps xmm15, [rsp+0xE0]
00007b00b77d35be  add rsp, 0xF0
00007b00b77d35c5  pop r11
00007b00b77d35c7  pop r10
00007b00b77d35c9  pop r9
00007b00b77d35cb  pop r8
00007b00b77d35cd  pop rsi
00007b00b77d35ce  pop rdi
00007b00b77d35cf  pop rdx
00007b00b77d35d0  pop rcx
00007b00b77d35d1  pop rax
00007b00b77d35d2  add rsp, 0x08
00007b00b77d35d6  jmp 0x00007B00B77D28AD
00007b00b77d35db  sub rsp, 0x08
00007b00b77d35df  push rax
00007b00b77d35e0  push rcx
00007b00b77d35e1  push rdx
00007b00b77d35e2  push rdi
00007b00b77d35e3  push rsi
00007b00b77d35e4  push r8
00007b00b77d35e6  push r9
00007b00b77d35e8  push r10
00007b00b77d35ea  push r11
00007b00b77d35ec  sub rsp, 0xF0
00007b00b77d35f3  vmovaps [rsp], xmm0
00007b00b77d35f8  vmovaps [rsp+0x10], xmm1
00007b00b77d35fe  vmovaps [rsp+0x20], xmm2
00007b00b77d3604  vmovaps [rsp+0x30], xmm3
00007b00b77d360a  vmovaps [rsp+0x40], xmm4
00007b00b77d3610  vmovaps [rsp+0x50], xmm5
00007b00b77d3616  vmovaps [rsp+0x60], xmm6
00007b00b77d361c  vmovaps [rsp+0x70], xmm7
00007b00b77d3622  vmovaps [rsp+0x80], xmm8
00007b00b77d362b  vmovaps [rsp+0x90], xmm9
00007b00b77d3634  vmovaps [rsp+0xA0], xmm10
00007b00b77d363d  vmovaps [rsp+0xB0], xmm11
00007b00b77d3646  vmovaps [rsp+0xC0], xmm12
00007b00b77d364f  vmovaps [rsp+0xD0], xmm13
00007b00b77d3658  vmovaps [rsp+0xE0], xmm14
00007b00b77d3661  sub rsp, 0x40
00007b00b77d3665  lea rdi, [rsp]
00007b00b77d3669  lea rsi, [rsp+0x10]
00007b00b77d366e  lea rdx, [rsp+0x20]
00007b00b77d3673  lea rcx, [rsp+0x30]
00007b00b77d3678  mov r8d, 0x00
00007b00b77d367e  lea r9, [r15+0x3A8]
00007b00b77d3685  movaps [rdi], xmm15
00007b00b77d3689  movaps [rsi], xmm5
00007b00b77d368c  movaps [rdx], xmm1
00007b00b77d368f  movaps [rcx], xmm14
00007b00b77d3693  mov rax, 0x612A23581A50
00007b00b77d369d  call rax
00007b00b77d369f  movaps xmm15, [rsp]
00007b00b77d36a4  add rsp, 0x40
00007b00b77d36a8  vmovaps xmm0, [rsp]
00007b00b77d36ad  vmovaps xmm1, [rsp+0x10]
00007b00b77d36b3  vmovaps xmm2, [rsp+0x20]
00007b00b77d36b9  vmovaps xmm3, [rsp+0x30]
00007b00b77d36bf  vmovaps xmm4, [rsp+0x40]
00007b00b77d36c5  vmovaps xmm5, [rsp+0x50]
00007b00b77d36cb  vmovaps xmm6, [rsp+0x60]
00007b00b77d36d1  vmovaps xmm7, [rsp+0x70]
00007b00b77d36d7  vmovaps xmm8, [rsp+0x80]
00007b00b77d36e0  vmovaps xmm9, [rsp+0x90]
00007b00b77d36e9  vmovaps xmm10, [rsp+0xA0]
00007b00b77d36f2  vmovaps xmm11, [rsp+0xB0]
00007b00b77d36fb  vmovaps xmm12, [rsp+0xC0]
00007b00b77d3704  vmovaps xmm13, [rsp+0xD0]
00007b00b77d370d  vmovaps xmm14, [rsp+0xE0]
00007b00b77d3716  add rsp, 0xF0
00007b00b77d371d  pop r11
00007b00b77d371f  pop r10
00007b00b77d3721  pop r9
00007b00b77d3723  pop r8
00007b00b77d3725  pop rsi
00007b00b77d3726  pop rdi
00007b00b77d3727  pop rdx
00007b00b77d3728  pop rcx
00007b00b77d3729  pop rax
00007b00b77d372a  add rsp, 0x08
00007b00b77d372e  jmp 0x00007B00B77D28D0
00007b00b77d3733  call 0x00007B00B75FF430
00007b00b77d3738  jmp 0x00007B00B77D295D
00007b00b77d373d  sub rsp, 0x08
00007b00b77d3741  push rax
00007b00b77d3742  push rcx
00007b00b77d3743  push rdx
00007b00b77d3744  push rdi
00007b00b77d3745  push rsi
00007b00b77d3746  push r8
00007b00b77d3748  push r9
00007b00b77d374a  push r10
00007b00b77d374c  push r11
00007b00b77d374e  sub rsp, 0xF0
00007b00b77d3755  vmovaps [rsp], xmm0
00007b00b77d375a  vmovaps [rsp+0x10], xmm1
00007b00b77d3760  vmovaps [rsp+0x20], xmm2
00007b00b77d3766  vmovaps [rsp+0x30], xmm3
00007b00b77d376c  vmovaps [rsp+0x40], xmm4
00007b00b77d3772  vmovaps [rsp+0x50], xmm5
00007b00b77d3778  vmovaps [rsp+0x60], xmm6
00007b00b77d377e  vmovaps [rsp+0x70], xmm7
00007b00b77d3784  vmovaps [rsp+0x80], xmm8
00007b00b77d378d  vmovaps [rsp+0x90], xmm9
00007b00b77d3796  vmovaps [rsp+0xA0], xmm10
00007b00b77d379f  vmovaps [rsp+0xB0], xmm11
00007b00b77d37a8  vmovaps [rsp+0xC0], xmm12
00007b00b77d37b1  vmovaps [rsp+0xD0], xmm14
00007b00b77d37ba  vmovaps [rsp+0xE0], xmm15
00007b00b77d37c3  sub rsp, 0x40
00007b00b77d37c7  lea rdi, [rsp]
00007b00b77d37cb  lea rsi, [rsp+0x10]
00007b00b77d37d0  lea rdx, [rsp+0x20]
00007b00b77d37d5  lea rcx, [rsp+0x30]
00007b00b77d37da  mov r8d, 0x00
00007b00b77d37e0  lea r9, [r15+0x3A8]
00007b00b77d37e7  movaps [rdi], xmm13
00007b00b77d37eb  movaps [rsi], xmm1
00007b00b77d37ee  movaps [rdx], xmm15
00007b00b77d37f2  movaps [rcx], xmm14
00007b00b77d37f6  mov rax, 0x612A23581A50
00007b00b77d3800  call rax
00007b00b77d3802  movaps xmm13, [rsp]
00007b00b77d3807  add rsp, 0x40
00007b00b77d380b  vmovaps xmm0, [rsp]
00007b00b77d3810  vmovaps xmm1, [rsp+0x10]
00007b00b77d3816  vmovaps xmm2, [rsp+0x20]
00007b00b77d381c  vmovaps xmm3, [rsp+0x30]
00007b00b77d3822  vmovaps xmm4, [rsp+0x40]
00007b00b77d3828  vmovaps xmm5, [rsp+0x50]
00007b00b77d382e  vmovaps xmm6, [rsp+0x60]
00007b00b77d3834  vmovaps xmm7, [rsp+0x70]
00007b00b77d383a  vmovaps xmm8, [rsp+0x80]
00007b00b77d3843  vmovaps xmm9, [rsp+0x90]
00007b00b77d384c  vmovaps xmm10, [rsp+0xA0]
00007b00b77d3855  vmovaps xmm11, [rsp+0xB0]
00007b00b77d385e  vmovaps xmm12, [rsp+0xC0]
00007b00b77d3867  vmovaps xmm14, [rsp+0xD0]
00007b00b77d3870  vmovaps xmm15, [rsp+0xE0]
00007b00b77d3879  add rsp, 0xF0
00007b00b77d3880  pop r11
00007b00b77d3882  pop r10
00007b00b77d3884  pop r9
00007b00b77d3886  pop r8
00007b00b77d3888  pop rsi
00007b00b77d3889  pop rdi
00007b00b77d388a  pop rdx
00007b00b77d388b  pop rcx
00007b00b77d388c  pop rax
00007b00b77d388d  add rsp, 0x08
00007b00b77d3891  jmp 0x00007B00B77D29C1
00007b00b77d3896  call 0x00007B00B75FF430
00007b00b77d389b  jmp 0x00007B00B77D29CE
00007b00b77d38a0  sub rsp, 0x08
00007b00b77d38a4  push rax
00007b00b77d38a5  push rcx
00007b00b77d38a6  push rdx
00007b00b77d38a7  push rdi
00007b00b77d38a8  push rsi
00007b00b77d38a9  push r8
00007b00b77d38ab  push r9
00007b00b77d38ad  push r10
00007b00b77d38af  push r11
00007b00b77d38b1  sub rsp, 0xF0
00007b00b77d38b8  vmovaps [rsp], xmm0
00007b00b77d38bd  vmovaps [rsp+0x10], xmm1
00007b00b77d38c3  vmovaps [rsp+0x20], xmm2
00007b00b77d38c9  vmovaps [rsp+0x30], xmm3
00007b00b77d38cf  vmovaps [rsp+0x40], xmm4
00007b00b77d38d5  vmovaps [rsp+0x50], xmm5
00007b00b77d38db  vmovaps [rsp+0x60], xmm6
00007b00b77d38e1  vmovaps [rsp+0x70], xmm7
00007b00b77d38e7  vmovaps [rsp+0x80], xmm8
00007b00b77d38f0  vmovaps [rsp+0x90], xmm9
00007b00b77d38f9  vmovaps [rsp+0xA0], xmm10
00007b00b77d3902  vmovaps [rsp+0xB0], xmm11
00007b00b77d390b  vmovaps [rsp+0xC0], xmm13
00007b00b77d3914  vmovaps [rsp+0xD0], xmm14
00007b00b77d391d  vmovaps [rsp+0xE0], xmm15
00007b00b77d3926  sub rsp, 0x40
00007b00b77d392a  lea rdi, [rsp]
00007b00b77d392e  lea rsi, [rsp+0x10]
00007b00b77d3933  lea rdx, [rsp+0x20]
00007b00b77d3938  lea rcx, [rsp+0x30]
00007b00b77d393d  mov r8d, 0x00
00007b00b77d3943  lea r9, [r15+0x3A8]
00007b00b77d394a  movaps [rdi], xmm12
00007b00b77d394e  movaps [rsi], xmm15
00007b00b77d3952  movaps [rdx], xmm1
00007b00b77d3955  movaps [rcx], xmm14
00007b00b77d3959  mov rax, 0x612A23581A50
00007b00b77d3963  call rax
00007b00b77d3965  movaps xmm12, [rsp]
00007b00b77d396a  add rsp, 0x40
00007b00b77d396e  vmovaps xmm0, [rsp]
00007b00b77d3973  vmovaps xmm1, [rsp+0x10]
00007b00b77d3979  vmovaps xmm2, [rsp+0x20]
00007b00b77d397f  vmovaps xmm3, [rsp+0x30]
00007b00b77d3985  vmovaps xmm4, [rsp+0x40]
00007b00b77d398b  vmovaps xmm5, [rsp+0x50]
00007b00b77d3991  vmovaps xmm6, [rsp+0x60]
00007b00b77d3997  vmovaps xmm7, [rsp+0x70]
00007b00b77d399d  vmovaps xmm8, [rsp+0x80]
00007b00b77d39a6  vmovaps xmm9, [rsp+0x90]
00007b00b77d39af  vmovaps xmm10, [rsp+0xA0]
00007b00b77d39b8  vmovaps xmm11, [rsp+0xB0]
00007b00b77d39c1  vmovaps xmm13, [rsp+0xC0]
00007b00b77d39ca  vmovaps xmm14, [rsp+0xD0]
00007b00b77d39d3  vmovaps xmm15, [rsp+0xE0]
00007b00b77d39dc  add rsp, 0xF0
00007b00b77d39e3  pop r11
00007b00b77d39e5  pop r10
00007b00b77d39e7  pop r9
00007b00b77d39e9  pop r8
00007b00b77d39eb  pop rsi
00007b00b77d39ec  pop rdi
00007b00b77d39ed  pop rdx
00007b00b77d39ee  pop rcx
00007b00b77d39ef  pop rax
00007b00b77d39f0  add rsp, 0x08
00007b00b77d39f4  jmp 0x00007B00B77D29FA
00007b00b77d39f9  sub rsp, 0x08
00007b00b77d39fd  push rax
00007b00b77d39fe  push rcx
00007b00b77d39ff  push rdx
00007b00b77d3a00  push rdi
00007b00b77d3a01  push rsi
00007b00b77d3a02  push r8
00007b00b77d3a04  push r9
00007b00b77d3a06  push r10
00007b00b77d3a08  push r11
00007b00b77d3a0a  sub rsp, 0xF0
00007b00b77d3a11  vmovaps [rsp], xmm0
00007b00b77d3a16  vmovaps [rsp+0x10], xmm1
00007b00b77d3a1c  vmovaps [rsp+0x20], xmm2
00007b00b77d3a22  vmovaps [rsp+0x30], xmm3
00007b00b77d3a28  vmovaps [rsp+0x40], xmm4
00007b00b77d3a2e  vmovaps [rsp+0x50], xmm5
00007b00b77d3a34  vmovaps [rsp+0x60], xmm6
00007b00b77d3a3a  vmovaps [rsp+0x70], xmm7
00007b00b77d3a40  vmovaps [rsp+0x80], xmm8
00007b00b77d3a49  vmovaps [rsp+0x90], xmm9
00007b00b77d3a52  vmovaps [rsp+0xA0], xmm10
00007b00b77d3a5b  vmovaps [rsp+0xB0], xmm11
00007b00b77d3a64  vmovaps [rsp+0xC0], xmm12
00007b00b77d3a6d  vmovaps [rsp+0xD0], xmm14
00007b00b77d3a76  vmovaps [rsp+0xE0], xmm15
00007b00b77d3a7f  sub rsp, 0x40
00007b00b77d3a83  lea rdi, [rsp]
00007b00b77d3a87  lea rsi, [rsp+0x10]
00007b00b77d3a8c  lea rdx, [rsp+0x20]
00007b00b77d3a91  lea rcx, [rsp+0x30]
00007b00b77d3a96  mov r8d, 0x00
00007b00b77d3a9c  lea r9, [r15+0x3A8]
00007b00b77d3aa3  movaps [rdi], xmm13
00007b00b77d3aa7  movaps [rsi], xmm1
00007b00b77d3aaa  movaps [rdx], xmm15
00007b00b77d3aae  movaps [rcx], xmm14
00007b00b77d3ab2  mov rax, 0x612A23581A50
00007b00b77d3abc  call rax
00007b00b77d3abe  movaps xmm13, [rsp]
00007b00b77d3ac3  add rsp, 0x40
00007b00b77d3ac7  vmovaps xmm0, [rsp]
00007b00b77d3acc  vmovaps xmm1, [rsp+0x10]
00007b00b77d3ad2  vmovaps xmm2, [rsp+0x20]
00007b00b77d3ad8  vmovaps xmm3, [rsp+0x30]
00007b00b77d3ade  vmovaps xmm4, [rsp+0x40]
00007b00b77d3ae4  vmovaps xmm5, [rsp+0x50]
00007b00b77d3aea  vmovaps xmm6, [rsp+0x60]
00007b00b77d3af0  vmovaps xmm7, [rsp+0x70]
00007b00b77d3af6  vmovaps xmm8, [rsp+0x80]
00007b00b77d3aff  vmovaps xmm9, [rsp+0x90]
00007b00b77d3b08  vmovaps xmm10, [rsp+0xA0]
00007b00b77d3b11  vmovaps xmm11, [rsp+0xB0]
00007b00b77d3b1a  vmovaps xmm12, [rsp+0xC0]
00007b00b77d3b23  vmovaps xmm14, [rsp+0xD0]
00007b00b77d3b2c  vmovaps xmm15, [rsp+0xE0]
00007b00b77d3b35  add rsp, 0xF0
00007b00b77d3b3c  pop r11
00007b00b77d3b3e  pop r10
00007b00b77d3b40  pop r9
00007b00b77d3b42  pop r8
00007b00b77d3b44  pop rsi
00007b00b77d3b45  pop rdi
00007b00b77d3b46  pop rdx
00007b00b77d3b47  pop rcx
00007b00b77d3b48  pop rax
00007b00b77d3b49  add rsp, 0x08
00007b00b77d3b4d  jmp 0x00007B00B77D2B77
00007b00b77d3b52  sub rsp, 0x08
00007b00b77d3b56  push rax
00007b00b77d3b57  push rcx
00007b00b77d3b58  push rdx
00007b00b77d3b59  push rdi
00007b00b77d3b5a  push rsi
00007b00b77d3b5b  push r8
00007b00b77d3b5d  push r9
00007b00b77d3b5f  push r10
00007b00b77d3b61  push r11
00007b00b77d3b63  sub rsp, 0xF0
00007b00b77d3b6a  vmovaps [rsp], xmm0
00007b00b77d3b6f  vmovaps [rsp+0x10], xmm1
00007b00b77d3b75  vmovaps [rsp+0x20], xmm2
00007b00b77d3b7b  vmovaps [rsp+0x30], xmm3
00007b00b77d3b81  vmovaps [rsp+0x40], xmm4
00007b00b77d3b87  vmovaps [rsp+0x50], xmm5
00007b00b77d3b8d  vmovaps [rsp+0x60], xmm6
00007b00b77d3b93  vmovaps [rsp+0x70], xmm7
00007b00b77d3b99  vmovaps [rsp+0x80], xmm8
00007b00b77d3ba2  vmovaps [rsp+0x90], xmm9
00007b00b77d3bab  vmovaps [rsp+0xA0], xmm10
00007b00b77d3bb4  vmovaps [rsp+0xB0], xmm11
00007b00b77d3bbd  vmovaps [rsp+0xC0], xmm13
00007b00b77d3bc6  vmovaps [rsp+0xD0], xmm14
00007b00b77d3bcf  vmovaps [rsp+0xE0], xmm15
00007b00b77d3bd8  sub rsp, 0x40
00007b00b77d3bdc  lea rdi, [rsp]
00007b00b77d3be0  lea rsi, [rsp+0x10]
00007b00b77d3be5  lea rdx, [rsp+0x20]
00007b00b77d3bea  lea rcx, [rsp+0x30]
00007b00b77d3bef  mov r8d, 0x00
00007b00b77d3bf5  lea r9, [r15+0x3A8]
00007b00b77d3bfc  movaps [rdi], xmm12
00007b00b77d3c00  movaps [rsi], xmm15
00007b00b77d3c04  movaps [rdx], xmm14
00007b00b77d3c08  movaps [rcx], xmm1
00007b00b77d3c0b  mov rax, 0x612A23581A50
00007b00b77d3c15  call rax
00007b00b77d3c17  movaps xmm12, [rsp]
00007b00b77d3c1c  add rsp, 0x40
00007b00b77d3c20  vmovaps xmm0, [rsp]
00007b00b77d3c25  vmovaps xmm1, [rsp+0x10]
00007b00b77d3c2b  vmovaps xmm2, [rsp+0x20]
00007b00b77d3c31  vmovaps xmm3, [rsp+0x30]
00007b00b77d3c37  vmovaps xmm4, [rsp+0x40]
00007b00b77d3c3d  vmovaps xmm5, [rsp+0x50]
00007b00b77d3c43  vmovaps xmm6, [rsp+0x60]
00007b00b77d3c49  vmovaps xmm7, [rsp+0x70]
00007b00b77d3c4f  vmovaps xmm8, [rsp+0x80]
00007b00b77d3c58  vmovaps xmm9, [rsp+0x90]
00007b00b77d3c61  vmovaps xmm10, [rsp+0xA0]
00007b00b77d3c6a  vmovaps xmm11, [rsp+0xB0]
00007b00b77d3c73  vmovaps xmm13, [rsp+0xC0]
00007b00b77d3c7c  vmovaps xmm14, [rsp+0xD0]
00007b00b77d3c85  vmovaps xmm15, [rsp+0xE0]
00007b00b77d3c8e  add rsp, 0xF0
00007b00b77d3c95  pop r11
00007b00b77d3c97  pop r10
00007b00b77d3c99  pop r9
00007b00b77d3c9b  pop r8
00007b00b77d3c9d  pop rsi
00007b00b77d3c9e  pop rdi
00007b00b77d3c9f  pop rdx
00007b00b77d3ca0  pop rcx
00007b00b77d3ca1  pop rax
00007b00b77d3ca2  add rsp, 0x08
00007b00b77d3ca6  jmp 0x00007B00B77D2BB2
00007b00b77d3cab  sub rsp, 0x08
00007b00b77d3caf  push rax
00007b00b77d3cb0  push rcx
00007b00b77d3cb1  push rdx
00007b00b77d3cb2  push rdi
00007b00b77d3cb3  push rsi
00007b00b77d3cb4  push r8
00007b00b77d3cb6  push r9
00007b00b77d3cb8  push r10
00007b00b77d3cba  push r11
00007b00b77d3cbc  sub rsp, 0xF0
00007b00b77d3cc3  vmovaps [rsp], xmm0
00007b00b77d3cc8  vmovaps [rsp+0x10], xmm1
00007b00b77d3cce  vmovaps [rsp+0x20], xmm2
00007b00b77d3cd4  vmovaps [rsp+0x30], xmm3
00007b00b77d3cda  vmovaps [rsp+0x40], xmm4
00007b00b77d3ce0  vmovaps [rsp+0x50], xmm5
00007b00b77d3ce6  vmovaps [rsp+0x60], xmm6
00007b00b77d3cec  vmovaps [rsp+0x70], xmm7
00007b00b77d3cf2  vmovaps [rsp+0x80], xmm8
00007b00b77d3cfb  vmovaps [rsp+0x90], xmm9
00007b00b77d3d04  vmovaps [rsp+0xA0], xmm10
00007b00b77d3d0d  vmovaps [rsp+0xB0], xmm11
00007b00b77d3d16  vmovaps [rsp+0xC0], xmm12
00007b00b77d3d1f  vmovaps [rsp+0xD0], xmm14
00007b00b77d3d28  vmovaps [rsp+0xE0], xmm15
00007b00b77d3d31  sub rsp, 0x40
00007b00b77d3d35  lea rdi, [rsp]
00007b00b77d3d39  lea rsi, [rsp+0x10]
00007b00b77d3d3e  lea rdx, [rsp+0x20]
00007b00b77d3d43  lea rcx, [rsp+0x30]
00007b00b77d3d48  mov r8d, 0x00
00007b00b77d3d4e  lea r9, [r15+0x3A8]
00007b00b77d3d55  movaps [rdi], xmm13
00007b00b77d3d59  movaps [rsi], xmm15
00007b00b77d3d5d  movaps [rdx], xmm14
00007b00b77d3d61  movaps [rcx], xmm1
00007b00b77d3d64  mov rax, 0x612A23581A50
00007b00b77d3d6e  call rax
00007b00b77d3d70  movaps xmm13, [rsp]
00007b00b77d3d75  add rsp, 0x40
00007b00b77d3d79  vmovaps xmm0, [rsp]
00007b00b77d3d7e  vmovaps xmm1, [rsp+0x10]
00007b00b77d3d84  vmovaps xmm2, [rsp+0x20]
00007b00b77d3d8a  vmovaps xmm3, [rsp+0x30]
00007b00b77d3d90  vmovaps xmm4, [rsp+0x40]
00007b00b77d3d96  vmovaps xmm5, [rsp+0x50]
00007b00b77d3d9c  vmovaps xmm6, [rsp+0x60]
00007b00b77d3da2  vmovaps xmm7, [rsp+0x70]
00007b00b77d3da8  vmovaps xmm8, [rsp+0x80]
00007b00b77d3db1  vmovaps xmm9, [rsp+0x90]
00007b00b77d3dba  vmovaps xmm10, [rsp+0xA0]
00007b00b77d3dc3  vmovaps xmm11, [rsp+0xB0]
00007b00b77d3dcc  vmovaps xmm12, [rsp+0xC0]
00007b00b77d3dd5  vmovaps xmm14, [rsp+0xD0]
00007b00b77d3dde  vmovaps xmm15, [rsp+0xE0]
00007b00b77d3de7  add rsp, 0xF0
00007b00b77d3dee  pop r11
00007b00b77d3df0  pop r10
00007b00b77d3df2  pop r9
00007b00b77d3df4  pop r8
00007b00b77d3df6  pop rsi
00007b00b77d3df7  pop rdi
00007b00b77d3df8  pop rdx
00007b00b77d3df9  pop rcx
00007b00b77d3dfa  pop rax
00007b00b77d3dfb  add rsp, 0x08
00007b00b77d3dff  jmp 0x00007B00B77D2BEA
00007b00b77d3e04  sub rsp, 0x08
00007b00b77d3e08  push rax
00007b00b77d3e09  push rcx
00007b00b77d3e0a  push rdx
00007b00b77d3e0b  push rdi
00007b00b77d3e0c  push rsi
00007b00b77d3e0d  push r8
00007b00b77d3e0f  push r9
00007b00b77d3e11  push r10
00007b00b77d3e13  push r11
00007b00b77d3e15  sub rsp, 0xF0
00007b00b77d3e1c  vmovaps [rsp], xmm0
00007b00b77d3e21  vmovaps [rsp+0x10], xmm1
00007b00b77d3e27  vmovaps [rsp+0x20], xmm2
00007b00b77d3e2d  vmovaps [rsp+0x30], xmm3
00007b00b77d3e33  vmovaps [rsp+0x40], xmm4
00007b00b77d3e39  vmovaps [rsp+0x50], xmm5
00007b00b77d3e3f  vmovaps [rsp+0x60], xmm6
00007b00b77d3e45  vmovaps [rsp+0x70], xmm7
00007b00b77d3e4b  vmovaps [rsp+0x80], xmm8
00007b00b77d3e54  vmovaps [rsp+0x90], xmm9
00007b00b77d3e5d  vmovaps [rsp+0xA0], xmm10
00007b00b77d3e66  vmovaps [rsp+0xB0], xmm11
00007b00b77d3e6f  vmovaps [rsp+0xC0], xmm13
00007b00b77d3e78  vmovaps [rsp+0xD0], xmm14
00007b00b77d3e81  vmovaps [rsp+0xE0], xmm15
00007b00b77d3e8a  sub rsp, 0x40
00007b00b77d3e8e  lea rdi, [rsp]
00007b00b77d3e92  lea rsi, [rsp+0x10]
00007b00b77d3e97  lea rdx, [rsp+0x20]
00007b00b77d3e9c  lea rcx, [rsp+0x30]
00007b00b77d3ea1  mov r8d, 0x00
00007b00b77d3ea7  lea r9, [r15+0x3A8]
00007b00b77d3eae  movaps [rdi], xmm12
00007b00b77d3eb2  movaps [rsi], xmm15
00007b00b77d3eb6  movaps [rdx], xmm14
00007b00b77d3eba  movaps [rcx], xmm1
00007b00b77d3ebd  mov rax, 0x612A23581A50
00007b00b77d3ec7  call rax
00007b00b77d3ec9  movaps xmm12, [rsp]
00007b00b77d3ece  add rsp, 0x40
00007b00b77d3ed2  vmovaps xmm0, [rsp]
00007b00b77d3ed7  vmovaps xmm1, [rsp+0x10]
00007b00b77d3edd  vmovaps xmm2, [rsp+0x20]
00007b00b77d3ee3  vmovaps xmm3, [rsp+0x30]
00007b00b77d3ee9  vmovaps xmm4, [rsp+0x40]
00007b00b77d3eef  vmovaps xmm5, [rsp+0x50]
00007b00b77d3ef5  vmovaps xmm6, [rsp+0x60]
00007b00b77d3efb  vmovaps xmm7, [rsp+0x70]
00007b00b77d3f01  vmovaps xmm8, [rsp+0x80]
00007b00b77d3f0a  vmovaps xmm9, [rsp+0x90]
00007b00b77d3f13  vmovaps xmm10, [rsp+0xA0]
00007b00b77d3f1c  vmovaps xmm11, [rsp+0xB0]
00007b00b77d3f25  vmovaps xmm13, [rsp+0xC0]
00007b00b77d3f2e  vmovaps xmm14, [rsp+0xD0]
00007b00b77d3f37  vmovaps xmm15, [rsp+0xE0]
00007b00b77d3f40  add rsp, 0xF0
00007b00b77d3f47  pop r11
00007b00b77d3f49  pop r10
00007b00b77d3f4b  pop r9
00007b00b77d3f4d  pop r8
00007b00b77d3f4f  pop rsi
00007b00b77d3f50  pop rdi
00007b00b77d3f51  pop rdx
00007b00b77d3f52  pop rcx
00007b00b77d3f53  pop rax
00007b00b77d3f54  add rsp, 0x08
00007b00b77d3f58  jmp 0x00007B00B77D2C3D
00007b00b77d3f5d  sub rsp, 0x08
00007b00b77d3f61  push rax
00007b00b77d3f62  push rcx
00007b00b77d3f63  push rdx
00007b00b77d3f64  push rdi
00007b00b77d3f65  push rsi
00007b00b77d3f66  push r8
00007b00b77d3f68  push r9
00007b00b77d3f6a  push r10
00007b00b77d3f6c  push r11
00007b00b77d3f6e  sub rsp, 0xF0
00007b00b77d3f75  vmovaps [rsp], xmm0
00007b00b77d3f7a  vmovaps [rsp+0x10], xmm1
00007b00b77d3f80  vmovaps [rsp+0x20], xmm2
00007b00b77d3f86  vmovaps [rsp+0x30], xmm3
00007b00b77d3f8c  vmovaps [rsp+0x40], xmm4
00007b00b77d3f92  vmovaps [rsp+0x50], xmm5
00007b00b77d3f98  vmovaps [rsp+0x60], xmm6
00007b00b77d3f9e  vmovaps [rsp+0x70], xmm7
00007b00b77d3fa4  vmovaps [rsp+0x80], xmm8
00007b00b77d3fad  vmovaps [rsp+0x90], xmm9
00007b00b77d3fb6  vmovaps [rsp+0xA0], xmm10
00007b00b77d3fbf  vmovaps [rsp+0xB0], xmm11
00007b00b77d3fc8  vmovaps [rsp+0xC0], xmm12
00007b00b77d3fd1  vmovaps [rsp+0xD0], xmm13
00007b00b77d3fda  vmovaps [rsp+0xE0], xmm15
00007b00b77d3fe3  sub rsp, 0x40
00007b00b77d3fe7  lea rdi, [rsp]
00007b00b77d3feb  lea rsi, [rsp+0x10]
00007b00b77d3ff0  lea rdx, [rsp+0x20]
00007b00b77d3ff5  lea rcx, [rsp+0x30]
00007b00b77d3ffa  mov r8d, 0x00
00007b00b77d4000  lea r9, [r15+0x3A8]
00007b00b77d4007  movaps [rdi], xmm14
00007b00b77d400b  movaps [rsi], xmm3
00007b00b77d400e  movaps [rdx], xmm1
00007b00b77d4011  movaps [rcx], xmm15
00007b00b77d4015  mov rax, 0x612A23581A50
00007b00b77d401f  call rax
00007b00b77d4021  movaps xmm14, [rsp]
00007b00b77d4026  add rsp, 0x40
00007b00b77d402a  vmovaps xmm0, [rsp]
00007b00b77d402f  vmovaps xmm1, [rsp+0x10]
00007b00b77d4035  vmovaps xmm2, [rsp+0x20]
00007b00b77d403b  vmovaps xmm3, [rsp+0x30]
00007b00b77d4041  vmovaps xmm4, [rsp+0x40]
00007b00b77d4047  vmovaps xmm5, [rsp+0x50]
00007b00b77d404d  vmovaps xmm6, [rsp+0x60]
00007b00b77d4053  vmovaps xmm7, [rsp+0x70]
00007b00b77d4059  vmovaps xmm8, [rsp+0x80]
00007b00b77d4062  vmovaps xmm9, [rsp+0x90]
00007b00b77d406b  vmovaps xmm10, [rsp+0xA0]
00007b00b77d4074  vmovaps xmm11, [rsp+0xB0]
00007b00b77d407d  vmovaps xmm12, [rsp+0xC0]
00007b00b77d4086  vmovaps xmm13, [rsp+0xD0]
00007b00b77d408f  vmovaps xmm15, [rsp+0xE0]
00007b00b77d4098  add rsp, 0xF0
00007b00b77d409f  pop r11
00007b00b77d40a1  pop r10
00007b00b77d40a3  pop r9
00007b00b77d40a5  pop r8
00007b00b77d40a7  pop rsi
00007b00b77d40a8  pop rdi
00007b00b77d40a9  pop rdx
00007b00b77d40aa  pop rcx
00007b00b77d40ab  pop rax
00007b00b77d40ac  add rsp, 0x08
00007b00b77d40b0  jmp 0x00007B00B77D2CF7
00007b00b77d40b5  sub rsp, 0x08
00007b00b77d40b9  push rax
00007b00b77d40ba  push rcx
00007b00b77d40bb  push rdx
00007b00b77d40bc  push rdi
00007b00b77d40bd  push rsi
00007b00b77d40be  push r8
00007b00b77d40c0  push r9
00007b00b77d40c2  push r10
00007b00b77d40c4  push r11
00007b00b77d40c6  sub rsp, 0xF0
00007b00b77d40cd  vmovaps [rsp], xmm0
00007b00b77d40d2  vmovaps [rsp+0x10], xmm1
00007b00b77d40d8  vmovaps [rsp+0x20], xmm2
00007b00b77d40de  vmovaps [rsp+0x30], xmm3
00007b00b77d40e4  vmovaps [rsp+0x40], xmm4
00007b00b77d40ea  vmovaps [rsp+0x50], xmm5
00007b00b77d40f0  vmovaps [rsp+0x60], xmm6
00007b00b77d40f6  vmovaps [rsp+0x70], xmm7
00007b00b77d40fc  vmovaps [rsp+0x80], xmm8
00007b00b77d4105  vmovaps [rsp+0x90], xmm9
00007b00b77d410e  vmovaps [rsp+0xA0], xmm10
00007b00b77d4117  vmovaps [rsp+0xB0], xmm11
00007b00b77d4120  vmovaps [rsp+0xC0], xmm12
00007b00b77d4129  vmovaps [rsp+0xD0], xmm14
00007b00b77d4132  vmovaps [rsp+0xE0], xmm15
00007b00b77d413b  sub rsp, 0x40
00007b00b77d413f  lea rdi, [rsp]
00007b00b77d4143  lea rsi, [rsp+0x10]
00007b00b77d4148  lea rdx, [rsp+0x20]
00007b00b77d414d  lea rcx, [rsp+0x30]
00007b00b77d4152  mov r8d, 0x00
00007b00b77d4158  lea r9, [r15+0x3A8]
00007b00b77d415f  movaps [rdi], xmm13
00007b00b77d4163  movaps [rsi], xmm15
00007b00b77d4167  movaps [rdx], xmm10
00007b00b77d416b  movaps [rcx], xmm1
00007b00b77d416e  mov rax, 0x612A23581A50
00007b00b77d4178  call rax
00007b00b77d417a  movaps xmm13, [rsp]
00007b00b77d417f  add rsp, 0x40
00007b00b77d4183  vmovaps xmm0, [rsp]
00007b00b77d4188  vmovaps xmm1, [rsp+0x10]
00007b00b77d418e  vmovaps xmm2, [rsp+0x20]
00007b00b77d4194  vmovaps xmm3, [rsp+0x30]
00007b00b77d419a  vmovaps xmm4, [rsp+0x40]
00007b00b77d41a0  vmovaps xmm5, [rsp+0x50]
00007b00b77d41a6  vmovaps xmm6, [rsp+0x60]
00007b00b77d41ac  vmovaps xmm7, [rsp+0x70]
00007b00b77d41b2  vmovaps xmm8, [rsp+0x80]
00007b00b77d41bb  vmovaps xmm9, [rsp+0x90]
00007b00b77d41c4  vmovaps xmm10, [rsp+0xA0]
00007b00b77d41cd  vmovaps xmm11, [rsp+0xB0]
00007b00b77d41d6  vmovaps xmm12, [rsp+0xC0]
00007b00b77d41df  vmovaps xmm14, [rsp+0xD0]
00007b00b77d41e8  vmovaps xmm15, [rsp+0xE0]
00007b00b77d41f1  add rsp, 0xF0
00007b00b77d41f8  pop r11
00007b00b77d41fa  pop r10
00007b00b77d41fc  pop r9
00007b00b77d41fe  pop r8
00007b00b77d4200  pop rsi
00007b00b77d4201  pop rdi
00007b00b77d4202  pop rdx
00007b00b77d4203  pop rcx
00007b00b77d4204  pop rax
00007b00b77d4205  add rsp, 0x08
00007b00b77d4209  jmp 0x00007B00B77D2D26
00007b00b77d420e  sub rsp, 0x08
00007b00b77d4212  push rax
00007b00b77d4213  push rcx
00007b00b77d4214  push rdx
00007b00b77d4215  push rdi
00007b00b77d4216  push rsi
00007b00b77d4217  push r8
00007b00b77d4219  push r9
00007b00b77d421b  push r10
00007b00b77d421d  push r11
00007b00b77d421f  sub rsp, 0xF0
00007b00b77d4226  vmovaps [rsp], xmm0
00007b00b77d422b  vmovaps [rsp+0x10], xmm1
00007b00b77d4231  vmovaps [rsp+0x20], xmm2
00007b00b77d4237  vmovaps [rsp+0x30], xmm3
00007b00b77d423d  vmovaps [rsp+0x40], xmm4
00007b00b77d4243  vmovaps [rsp+0x50], xmm5
00007b00b77d4249  vmovaps [rsp+0x60], xmm6
00007b00b77d424f  vmovaps [rsp+0x70], xmm7
00007b00b77d4255  vmovaps [rsp+0x80], xmm8
00007b00b77d425e  vmovaps [rsp+0x90], xmm9
00007b00b77d4267  vmovaps [rsp+0xA0], xmm11
00007b00b77d4270  vmovaps [rsp+0xB0], xmm12
00007b00b77d4279  vmovaps [rsp+0xC0], xmm13
00007b00b77d4282  vmovaps [rsp+0xD0], xmm14
00007b00b77d428b  vmovaps [rsp+0xE0], xmm15
00007b00b77d4294  sub rsp, 0x40
00007b00b77d4298  lea rdi, [rsp]
00007b00b77d429c  lea rsi, [rsp+0x10]
00007b00b77d42a1  lea rdx, [rsp+0x20]
00007b00b77d42a6  lea rcx, [rsp+0x30]
00007b00b77d42ab  mov r8d, 0x00
00007b00b77d42b1  lea r9, [r15+0x3A8]
00007b00b77d42b8  movaps [rdi], xmm10
00007b00b77d42bc  movaps [rsi], xmm15
00007b00b77d42c0  movaps [rdx], xmm11
00007b00b77d42c4  movaps [rcx], xmm1
00007b00b77d42c7  mov rax, 0x612A23581A50
00007b00b77d42d1  call rax
00007b00b77d42d3  movaps xmm10, [rsp]
00007b00b77d42d8  add rsp, 0x40
00007b00b77d42dc  vmovaps xmm0, [rsp]
00007b00b77d42e1  vmovaps xmm1, [rsp+0x10]
00007b00b77d42e7  vmovaps xmm2, [rsp+0x20]
00007b00b77d42ed  vmovaps xmm3, [rsp+0x30]
00007b00b77d42f3  vmovaps xmm4, [rsp+0x40]
00007b00b77d42f9  vmovaps xmm5, [rsp+0x50]
00007b00b77d42ff  vmovaps xmm6, [rsp+0x60]
00007b00b77d4305  vmovaps xmm7, [rsp+0x70]
00007b00b77d430b  vmovaps xmm8, [rsp+0x80]
00007b00b77d4314  vmovaps xmm9, [rsp+0x90]
00007b00b77d431d  vmovaps xmm11, [rsp+0xA0]
00007b00b77d4326  vmovaps xmm12, [rsp+0xB0]
00007b00b77d432f  vmovaps xmm13, [rsp+0xC0]
00007b00b77d4338  vmovaps xmm14, [rsp+0xD0]
00007b00b77d4341  vmovaps xmm15, [rsp+0xE0]
00007b00b77d434a  add rsp, 0xF0
00007b00b77d4351  pop r11
00007b00b77d4353  pop r10
00007b00b77d4355  pop r9
00007b00b77d4357  pop r8
00007b00b77d4359  pop rsi
00007b00b77d435a  pop rdi
00007b00b77d435b  pop rdx
00007b00b77d435c  pop rcx
00007b00b77d435d  pop rax
00007b00b77d435e  add rsp, 0x08
00007b00b77d4362  jmp 0x00007B00B77D2D55
00007b00b77d4367  sub rsp, 0x08
00007b00b77d436b  push rax
00007b00b77d436c  push rcx
00007b00b77d436d  push rdx
00007b00b77d436e  push rdi
00007b00b77d436f  push rsi
00007b00b77d4370  push r8
00007b00b77d4372  push r9
00007b00b77d4374  push r10
00007b00b77d4376  push r11
00007b00b77d4378  sub rsp, 0xF0
00007b00b77d437f  vmovaps [rsp], xmm0
00007b00b77d4384  vmovaps [rsp+0x10], xmm1
00007b00b77d438a  vmovaps [rsp+0x20], xmm2
00007b00b77d4390  vmovaps [rsp+0x30], xmm3
00007b00b77d4396  vmovaps [rsp+0x40], xmm4
00007b00b77d439c  vmovaps [rsp+0x50], xmm5
00007b00b77d43a2  vmovaps [rsp+0x60], xmm6
00007b00b77d43a8  vmovaps [rsp+0x70], xmm7
00007b00b77d43ae  vmovaps [rsp+0x80], xmm8
00007b00b77d43b7  vmovaps [rsp+0x90], xmm9
00007b00b77d43c0  vmovaps [rsp+0xA0], xmm10
00007b00b77d43c9  vmovaps [rsp+0xB0], xmm11
00007b00b77d43d2  vmovaps [rsp+0xC0], xmm12
00007b00b77d43db  vmovaps [rsp+0xD0], xmm13
00007b00b77d43e4  vmovaps [rsp+0xE0], xmm14
00007b00b77d43ed  sub rsp, 0x40
00007b00b77d43f1  lea rdi, [rsp]
00007b00b77d43f5  lea rsi, [rsp+0x10]
00007b00b77d43fa  lea rdx, [rsp+0x20]
00007b00b77d43ff  lea rcx, [rsp+0x30]
00007b00b77d4404  mov r8d, 0x00
00007b00b77d440a  lea r9, [r15+0x3A8]
00007b00b77d4411  movaps [rdi], xmm15
00007b00b77d4415  movaps [rsi], xmm12
00007b00b77d4419  movaps [rdx], xmm5
00007b00b77d441c  movaps [rcx], xmm1
00007b00b77d441f  mov rax, 0x612A23581A50
00007b00b77d4429  call rax
00007b00b77d442b  movaps xmm15, [rsp]
00007b00b77d4430  add rsp, 0x40
00007b00b77d4434  vmovaps xmm0, [rsp]
00007b00b77d4439  vmovaps xmm1, [rsp+0x10]
00007b00b77d443f  vmovaps xmm2, [rsp+0x20]
00007b00b77d4445  vmovaps xmm3, [rsp+0x30]
00007b00b77d444b  vmovaps xmm4, [rsp+0x40]
00007b00b77d4451  vmovaps xmm5, [rsp+0x50]
00007b00b77d4457  vmovaps xmm6, [rsp+0x60]
00007b00b77d445d  vmovaps xmm7, [rsp+0x70]
00007b00b77d4463  vmovaps xmm8, [rsp+0x80]
00007b00b77d446c  vmovaps xmm9, [rsp+0x90]
00007b00b77d4475  vmovaps xmm10, [rsp+0xA0]
00007b00b77d447e  vmovaps xmm11, [rsp+0xB0]
00007b00b77d4487  vmovaps xmm12, [rsp+0xC0]
00007b00b77d4490  vmovaps xmm13, [rsp+0xD0]
00007b00b77d4499  vmovaps xmm14, [rsp+0xE0]
00007b00b77d44a2  add rsp, 0xF0
00007b00b77d44a9  pop r11
00007b00b77d44ab  pop r10
00007b00b77d44ad  pop r9
00007b00b77d44af  pop r8
00007b00b77d44b1  pop rsi
00007b00b77d44b2  pop rdi
00007b00b77d44b3  pop rdx
00007b00b77d44b4  pop rcx
00007b00b77d44b5  pop rax
00007b00b77d44b6  add rsp, 0x08
00007b00b77d44ba  jmp 0x00007B00B77D2D7E
00007b00b77d44bf  sub rsp, 0x08
00007b00b77d44c3  push rax
00007b00b77d44c4  push rcx
00007b00b77d44c5  push rdx
00007b00b77d44c6  push rdi
00007b00b77d44c7  push rsi
00007b00b77d44c8  push r8
00007b00b77d44ca  push r9
00007b00b77d44cc  push r10
00007b00b77d44ce  push r11
00007b00b77d44d0  sub rsp, 0xF0
00007b00b77d44d7  vmovaps [rsp], xmm0
00007b00b77d44dc  vmovaps [rsp+0x10], xmm1
00007b00b77d44e2  vmovaps [rsp+0x20], xmm2
00007b00b77d44e8  vmovaps [rsp+0x30], xmm3
00007b00b77d44ee  vmovaps [rsp+0x40], xmm4
00007b00b77d44f4  vmovaps [rsp+0x50], xmm6
00007b00b77d44fa  vmovaps [rsp+0x60], xmm7
00007b00b77d4500  vmovaps [rsp+0x70], xmm8
00007b00b77d4506  vmovaps [rsp+0x80], xmm9
00007b00b77d450f  vmovaps [rsp+0x90], xmm10
00007b00b77d4518  vmovaps [rsp+0xA0], xmm11
00007b00b77d4521  vmovaps [rsp+0xB0], xmm12
00007b00b77d452a  vmovaps [rsp+0xC0], xmm13
00007b00b77d4533  vmovaps [rsp+0xD0], xmm14
00007b00b77d453c  vmovaps [rsp+0xE0], xmm15
00007b00b77d4545  sub rsp, 0x40
00007b00b77d4549  lea rdi, [rsp]
00007b00b77d454d  lea rsi, [rsp+0x10]
00007b00b77d4552  lea rdx, [rsp+0x20]
00007b00b77d4557  lea rcx, [rsp+0x30]
00007b00b77d455c  mov r8d, 0x00
00007b00b77d4562  lea r9, [r15+0x3A8]
00007b00b77d4569  movaps [rdi], xmm5
00007b00b77d456c  movaps [rsi], xmm13
00007b00b77d4570  movaps [rdx], xmm11
00007b00b77d4574  movaps [rcx], xmm12
00007b00b77d4578  mov rax, 0x612A23581A50
00007b00b77d4582  call rax
00007b00b77d4584  movaps xmm5, [rsp]
00007b00b77d4588  add rsp, 0x40
00007b00b77d458c  vmovaps xmm0, [rsp]
00007b00b77d4591  vmovaps xmm1, [rsp+0x10]
00007b00b77d4597  vmovaps xmm2, [rsp+0x20]
00007b00b77d459d  vmovaps xmm3, [rsp+0x30]
00007b00b77d45a3  vmovaps xmm4, [rsp+0x40]
00007b00b77d45a9  vmovaps xmm6, [rsp+0x50]
00007b00b77d45af  vmovaps xmm7, [rsp+0x60]
00007b00b77d45b5  vmovaps xmm8, [rsp+0x70]
00007b00b77d45bb  vmovaps xmm9, [rsp+0x80]
00007b00b77d45c4  vmovaps xmm10, [rsp+0x90]
00007b00b77d45cd  vmovaps xmm11, [rsp+0xA0]
00007b00b77d45d6  vmovaps xmm12, [rsp+0xB0]
00007b00b77d45df  vmovaps xmm13, [rsp+0xC0]
00007b00b77d45e8  vmovaps xmm14, [rsp+0xD0]
00007b00b77d45f1  vmovaps xmm15, [rsp+0xE0]
00007b00b77d45fa  add rsp, 0xF0
00007b00b77d4601  pop r11
00007b00b77d4603  pop r10
00007b00b77d4605  pop r9
00007b00b77d4607  pop r8
00007b00b77d4609  pop rsi
00007b00b77d460a  pop rdi
00007b00b77d460b  pop rdx
00007b00b77d460c  pop rcx
00007b00b77d460d  pop rax
00007b00b77d460e  add rsp, 0x08
00007b00b77d4612  jmp 0x00007B00B77D2DDD
00007b00b77d4617  sub rsp, 0x08
00007b00b77d461b  push rax
00007b00b77d461c  push rcx
00007b00b77d461d  push rdx
00007b00b77d461e  push rdi
00007b00b77d461f  push rsi
00007b00b77d4620  push r8
00007b00b77d4622  push r9
00007b00b77d4624  push r10
00007b00b77d4626  push r11
00007b00b77d4628  sub rsp, 0xF0
00007b00b77d462f  vmovaps [rsp], xmm0
00007b00b77d4634  vmovaps [rsp+0x10], xmm1
00007b00b77d463a  vmovaps [rsp+0x20], xmm2
00007b00b77d4640  vmovaps [rsp+0x30], xmm3
00007b00b77d4646  vmovaps [rsp+0x40], xmm4
00007b00b77d464c  vmovaps [rsp+0x50], xmm5
00007b00b77d4652  vmovaps [rsp+0x60], xmm6
00007b00b77d4658  vmovaps [rsp+0x70], xmm7
00007b00b77d465e  vmovaps [rsp+0x80], xmm8
00007b00b77d4667  vmovaps [rsp+0x90], xmm9
00007b00b77d4670  vmovaps [rsp+0xA0], xmm10
00007b00b77d4679  vmovaps [rsp+0xB0], xmm11
00007b00b77d4682  vmovaps [rsp+0xC0], xmm13
00007b00b77d468b  vmovaps [rsp+0xD0], xmm14
00007b00b77d4694  vmovaps [rsp+0xE0], xmm15
00007b00b77d469d  sub rsp, 0x40
00007b00b77d46a1  lea rdi, [rsp]
00007b00b77d46a5  lea rsi, [rsp+0x10]
00007b00b77d46aa  lea rdx, [rsp+0x20]
00007b00b77d46af  lea rcx, [rsp+0x30]
00007b00b77d46b4  mov r8d, 0x00
00007b00b77d46ba  lea r9, [r15+0x3A8]
00007b00b77d46c1  movaps [rdi], xmm12
00007b00b77d46c5  movaps [rsi], xmm14
00007b00b77d46c9  movaps [rdx], xmm9
00007b00b77d46cd  movaps [rcx], xmm13
00007b00b77d46d1  mov rax, 0x612A23581A50
00007b00b77d46db  call rax
00007b00b77d46dd  movaps xmm12, [rsp]
00007b00b77d46e2  add rsp, 0x40
00007b00b77d46e6  vmovaps xmm0, [rsp]
00007b00b77d46eb  vmovaps xmm1, [rsp+0x10]
00007b00b77d46f1  vmovaps xmm2, [rsp+0x20]
00007b00b77d46f7  vmovaps xmm3, [rsp+0x30]
00007b00b77d46fd  vmovaps xmm4, [rsp+0x40]
00007b00b77d4703  vmovaps xmm5, [rsp+0x50]
00007b00b77d4709  vmovaps xmm6, [rsp+0x60]
00007b00b77d470f  vmovaps xmm7, [rsp+0x70]
00007b00b77d4715  vmovaps xmm8, [rsp+0x80]
00007b00b77d471e  vmovaps xmm9, [rsp+0x90]
00007b00b77d4727  vmovaps xmm10, [rsp+0xA0]
00007b00b77d4730  vmovaps xmm11, [rsp+0xB0]
00007b00b77d4739  vmovaps xmm13, [rsp+0xC0]
00007b00b77d4742  vmovaps xmm14, [rsp+0xD0]
00007b00b77d474b  vmovaps xmm15, [rsp+0xE0]
00007b00b77d4754  add rsp, 0xF0
00007b00b77d475b  pop r11
00007b00b77d475d  pop r10
00007b00b77d475f  pop r9
00007b00b77d4761  pop r8
00007b00b77d4763  pop rsi
00007b00b77d4764  pop rdi
00007b00b77d4765  pop rdx
00007b00b77d4766  pop rcx
00007b00b77d4767  pop rax
00007b00b77d4768  add rsp, 0x08
00007b00b77d476c  jmp 0x00007B00B77D2E06
00007b00b77d4771  call 0x00007B00B760D4E0
00007b00b77d4776  jmp 0x00007B00B77D2E13
00007b00b77d477b  sub rsp, 0x08
00007b00b77d477f  push rax
00007b00b77d4780  push rcx
00007b00b77d4781  push rdx
00007b00b77d4782  push rdi
00007b00b77d4783  push rsi
00007b00b77d4784  push r8
00007b00b77d4786  push r9
00007b00b77d4788  push r10
00007b00b77d478a  push r11
00007b00b77d478c  sub rsp, 0xF0
00007b00b77d4793  vmovaps [rsp], xmm0
00007b00b77d4798  vmovaps [rsp+0x10], xmm1
00007b00b77d479e  vmovaps [rsp+0x20], xmm2
00007b00b77d47a4  vmovaps [rsp+0x30], xmm3
00007b00b77d47aa  vmovaps [rsp+0x40], xmm4
00007b00b77d47b0  vmovaps [rsp+0x50], xmm5
00007b00b77d47b6  vmovaps [rsp+0x60], xmm6
00007b00b77d47bc  vmovaps [rsp+0x70], xmm7
00007b00b77d47c2  vmovaps [rsp+0x80], xmm8
00007b00b77d47cb  vmovaps [rsp+0x90], xmm9
00007b00b77d47d4  vmovaps [rsp+0xA0], xmm10
00007b00b77d47dd  vmovaps [rsp+0xB0], xmm12
00007b00b77d47e6  vmovaps [rsp+0xC0], xmm13
00007b00b77d47ef  vmovaps [rsp+0xD0], xmm14
00007b00b77d47f8  vmovaps [rsp+0xE0], xmm15
00007b00b77d4801  sub rsp, 0x40
00007b00b77d4805  lea rdi, [rsp]
00007b00b77d4809  lea rsi, [rsp+0x10]
00007b00b77d480e  lea rdx, [rsp+0x20]
00007b00b77d4813  lea rcx, [rsp+0x30]
00007b00b77d4818  mov r8d, 0x00
00007b00b77d481e  lea r9, [r15+0x3A8]
00007b00b77d4825  movaps [rdi], xmm11
00007b00b77d4829  movaps [rsi], xmm10
00007b00b77d482d  movaps [rdx], xmm8
00007b00b77d4831  movaps [rcx], xmm13
00007b00b77d4835  mov rax, 0x612A23581A50
00007b00b77d483f  call rax
00007b00b77d4841  movaps xmm11, [rsp]
00007b00b77d4846  add rsp, 0x40
00007b00b77d484a  vmovaps xmm0, [rsp]
00007b00b77d484f  vmovaps xmm1, [rsp+0x10]
00007b00b77d4855  vmovaps xmm2, [rsp+0x20]
00007b00b77d485b  vmovaps xmm3, [rsp+0x30]
00007b00b77d4861  vmovaps xmm4, [rsp+0x40]
00007b00b77d4867  vmovaps xmm5, [rsp+0x50]
00007b00b77d486d  vmovaps xmm6, [rsp+0x60]
00007b00b77d4873  vmovaps xmm7, [rsp+0x70]
00007b00b77d4879  vmovaps xmm8, [rsp+0x80]
00007b00b77d4882  vmovaps xmm9, [rsp+0x90]
00007b00b77d488b  vmovaps xmm10, [rsp+0xA0]
00007b00b77d4894  vmovaps xmm12, [rsp+0xB0]
00007b00b77d489d  vmovaps xmm13, [rsp+0xC0]
00007b00b77d48a6  vmovaps xmm14, [rsp+0xD0]
00007b00b77d48af  vmovaps xmm15, [rsp+0xE0]
00007b00b77d48b8  add rsp, 0xF0
00007b00b77d48bf  pop r11
00007b00b77d48c1  pop r10
00007b00b77d48c3  pop r9
00007b00b77d48c5  pop r8
00007b00b77d48c7  pop rsi
00007b00b77d48c8  pop rdi
00007b00b77d48c9  pop rdx
00007b00b77d48ca  pop rcx
00007b00b77d48cb  pop rax
00007b00b77d48cc  add rsp, 0x08
00007b00b77d48d0  jmp 0x00007B00B77D2E44
00007b00b77d48d5  sub rsp, 0x08
00007b00b77d48d9  push rax
00007b00b77d48da  push rcx
00007b00b77d48db  push rdx
00007b00b77d48dc  push rdi
00007b00b77d48dd  push rsi
00007b00b77d48de  push r8
00007b00b77d48e0  push r9
00007b00b77d48e2  push r10
00007b00b77d48e4  push r11
00007b00b77d48e6  sub rsp, 0xF0
00007b00b77d48ed  vmovaps [rsp], xmm0
00007b00b77d48f2  vmovaps [rsp+0x10], xmm1
00007b00b77d48f8  vmovaps [rsp+0x20], xmm2
00007b00b77d48fe  vmovaps [rsp+0x30], xmm3
00007b00b77d4904  vmovaps [rsp+0x40], xmm4
00007b00b77d490a  vmovaps [rsp+0x50], xmm5
00007b00b77d4910  vmovaps [rsp+0x60], xmm6
00007b00b77d4916  vmovaps [rsp+0x70], xmm7
00007b00b77d491c  vmovaps [rsp+0x80], xmm8
00007b00b77d4925  vmovaps [rsp+0x90], xmm9
00007b00b77d492e  vmovaps [rsp+0xA0], xmm11
00007b00b77d4937  vmovaps [rsp+0xB0], xmm12
00007b00b77d4940  vmovaps [rsp+0xC0], xmm13
00007b00b77d4949  vmovaps [rsp+0xD0], xmm14
00007b00b77d4952  vmovaps [rsp+0xE0], xmm15
00007b00b77d495b  sub rsp, 0x40
00007b00b77d495f  lea rdi, [rsp]
00007b00b77d4963  lea rsi, [rsp+0x10]
00007b00b77d4968  lea rdx, [rsp+0x20]
00007b00b77d496d  lea rcx, [rsp+0x30]
00007b00b77d4972  mov r8d, 0x00
00007b00b77d4978  lea r9, [r15+0x3A8]
00007b00b77d497f  movaps [rdi], xmm10
00007b00b77d4983  movaps [rsi], xmm15
00007b00b77d4987  movaps [rdx], xmm1
00007b00b77d498a  movaps [rcx], xmm13
00007b00b77d498e  mov rax, 0x612A23581A50
00007b00b77d4998  call rax
00007b00b77d499a  movaps xmm10, [rsp]
00007b00b77d499f  add rsp, 0x40
00007b00b77d49a3  vmovaps xmm0, [rsp]
00007b00b77d49a8  vmovaps xmm1, [rsp+0x10]
00007b00b77d49ae  vmovaps xmm2, [rsp+0x20]
00007b00b77d49b4  vmovaps xmm3, [rsp+0x30]
00007b00b77d49ba  vmovaps xmm4, [rsp+0x40]
00007b00b77d49c0  vmovaps xmm5, [rsp+0x50]
00007b00b77d49c6  vmovaps xmm6, [rsp+0x60]
00007b00b77d49cc  vmovaps xmm7, [rsp+0x70]
00007b00b77d49d2  vmovaps xmm8, [rsp+0x80]
00007b00b77d49db  vmovaps xmm9, [rsp+0x90]
00007b00b77d49e4  vmovaps xmm11, [rsp+0xA0]
00007b00b77d49ed  vmovaps xmm12, [rsp+0xB0]
00007b00b77d49f6  vmovaps xmm13, [rsp+0xC0]
00007b00b77d49ff  vmovaps xmm14, [rsp+0xD0]
00007b00b77d4a08  vmovaps xmm15, [rsp+0xE0]
00007b00b77d4a11  add rsp, 0xF0
00007b00b77d4a18  pop r11
00007b00b77d4a1a  pop r10
00007b00b77d4a1c  pop r9
00007b00b77d4a1e  pop r8
00007b00b77d4a20  pop rsi
00007b00b77d4a21  pop rdi
00007b00b77d4a22  pop rdx
00007b00b77d4a23  pop rcx
00007b00b77d4a24  pop rax
00007b00b77d4a25  add rsp, 0x08
00007b00b77d4a29  jmp 0x00007B00B77D2E6D
00007b00b77d4a2e  call 0x00007B00B75FF430
00007b00b77d4a33  jmp 0x00007B00B77D2E8F
00007b00b77d4a38  call 0x00007B00B760E760
00007b00b77d4a3d  jmp 0x00007B00B77D2E99
00007b00b77d4a42  sub rsp, 0x08
00007b00b77d4a46  push rax
00007b00b77d4a47  push rcx
00007b00b77d4a48  push rdx
00007b00b77d4a49  push rdi
00007b00b77d4a4a  push rsi
00007b00b77d4a4b  push r8
00007b00b77d4a4d  push r9
00007b00b77d4a4f  push r10
00007b00b77d4a51  push r11
00007b00b77d4a53  sub rsp, 0xF0
00007b00b77d4a5a  vmovaps [rsp], xmm0
00007b00b77d4a5f  vmovaps [rsp+0x10], xmm1
00007b00b77d4a65  vmovaps [rsp+0x20], xmm2
00007b00b77d4a6b  vmovaps [rsp+0x30], xmm3
00007b00b77d4a71  vmovaps [rsp+0x40], xmm4
00007b00b77d4a77  vmovaps [rsp+0x50], xmm5
00007b00b77d4a7d  vmovaps [rsp+0x60], xmm6
00007b00b77d4a83  vmovaps [rsp+0x70], xmm7
00007b00b77d4a89  vmovaps [rsp+0x80], xmm9
00007b00b77d4a92  vmovaps [rsp+0x90], xmm10
00007b00b77d4a9b  vmovaps [rsp+0xA0], xmm11
00007b00b77d4aa4  vmovaps [rsp+0xB0], xmm12
00007b00b77d4aad  vmovaps [rsp+0xC0], xmm13
00007b00b77d4ab6  vmovaps [rsp+0xD0], xmm14
00007b00b77d4abf  vmovaps [rsp+0xE0], xmm15
00007b00b77d4ac8  sub rsp, 0x40
00007b00b77d4acc  lea rdi, [rsp]
00007b00b77d4ad0  lea rsi, [rsp+0x10]
00007b00b77d4ad5  lea rdx, [rsp+0x20]
00007b00b77d4ada  lea rcx, [rsp+0x30]
00007b00b77d4adf  mov r8d, 0x00
00007b00b77d4ae5  lea r9, [r15+0x3A8]
00007b00b77d4aec  movaps [rdi], xmm8
00007b00b77d4af0  movaps [rsi], xmm5
00007b00b77d4af3  movaps [rdx], xmm9
00007b00b77d4af7  movaps [rcx], xmm13
00007b00b77d4afb  mov rax, 0x612A23581A50
00007b00b77d4b05  call rax
00007b00b77d4b07  movaps xmm8, [rsp]
00007b00b77d4b0c  add rsp, 0x40
00007b00b77d4b10  vmovaps xmm0, [rsp]
00007b00b77d4b15  vmovaps xmm1, [rsp+0x10]
00007b00b77d4b1b  vmovaps xmm2, [rsp+0x20]
00007b00b77d4b21  vmovaps xmm3, [rsp+0x30]
00007b00b77d4b27  vmovaps xmm4, [rsp+0x40]
00007b00b77d4b2d  vmovaps xmm5, [rsp+0x50]
00007b00b77d4b33  vmovaps xmm6, [rsp+0x60]
00007b00b77d4b39  vmovaps xmm7, [rsp+0x70]
00007b00b77d4b3f  vmovaps xmm9, [rsp+0x80]
00007b00b77d4b48  vmovaps xmm10, [rsp+0x90]
00007b00b77d4b51  vmovaps xmm11, [rsp+0xA0]
00007b00b77d4b5a  vmovaps xmm12, [rsp+0xB0]
00007b00b77d4b63  vmovaps xmm13, [rsp+0xC0]
00007b00b77d4b6c  vmovaps xmm14, [rsp+0xD0]
00007b00b77d4b75  vmovaps xmm15, [rsp+0xE0]
00007b00b77d4b7e  add rsp, 0xF0
00007b00b77d4b85  pop r11
00007b00b77d4b87  pop r10
00007b00b77d4b89  pop r9
00007b00b77d4b8b  pop r8
00007b00b77d4b8d  pop rsi
00007b00b77d4b8e  pop rdi
00007b00b77d4b8f  pop rdx
00007b00b77d4b90  pop rcx
00007b00b77d4b91  pop rax
00007b00b77d4b92  add rsp, 0x08
00007b00b77d4b96  jmp 0x00007B00B77D2ED8
00007b00b77d4b9b  sub rsp, 0x08
00007b00b77d4b9f  push rax
00007b00b77d4ba0  push rcx
00007b00b77d4ba1  push rdx
00007b00b77d4ba2  push rdi
00007b00b77d4ba3  push rsi
00007b00b77d4ba4  push r8
00007b00b77d4ba6  push r9
00007b00b77d4ba8  push r10
00007b00b77d4baa  push r11
00007b00b77d4bac  sub rsp, 0xF0
00007b00b77d4bb3  vmovaps [rsp], xmm0
00007b00b77d4bb8  vmovaps [rsp+0x10], xmm1
00007b00b77d4bbe  vmovaps [rsp+0x20], xmm2
00007b00b77d4bc4  vmovaps [rsp+0x30], xmm3
00007b00b77d4bca  vmovaps [rsp+0x40], xmm4
00007b00b77d4bd0  vmovaps [rsp+0x50], xmm5
00007b00b77d4bd6  vmovaps [rsp+0x60], xmm6
00007b00b77d4bdc  vmovaps [rsp+0x70], xmm7
00007b00b77d4be2  vmovaps [rsp+0x80], xmm8
00007b00b77d4beb  vmovaps [rsp+0x90], xmm10
00007b00b77d4bf4  vmovaps [rsp+0xA0], xmm11
00007b00b77d4bfd  vmovaps [rsp+0xB0], xmm12
00007b00b77d4c06  vmovaps [rsp+0xC0], xmm13
00007b00b77d4c0f  vmovaps [rsp+0xD0], xmm14
00007b00b77d4c18  vmovaps [rsp+0xE0], xmm15
00007b00b77d4c21  sub rsp, 0x40
00007b00b77d4c25  lea rdi, [rsp]
00007b00b77d4c29  lea rsi, [rsp+0x10]
00007b00b77d4c2e  lea rdx, [rsp+0x20]
00007b00b77d4c33  lea rcx, [rsp+0x30]
00007b00b77d4c38  mov r8d, 0x00
00007b00b77d4c3e  lea r9, [r15+0x3A8]
00007b00b77d4c45  movaps [rdi], xmm9
00007b00b77d4c49  movaps [rsi], xmm12
00007b00b77d4c4d  movaps [rdx], xmm7
00007b00b77d4c50  movaps [rcx], xmm13
00007b00b77d4c54  mov rax, 0x612A23581A50
00007b00b77d4c5e  call rax
00007b00b77d4c60  movaps xmm9, [rsp]
00007b00b77d4c65  add rsp, 0x40
00007b00b77d4c69  vmovaps xmm0, [rsp]
00007b00b77d4c6e  vmovaps xmm1, [rsp+0x10]
00007b00b77d4c74  vmovaps xmm2, [rsp+0x20]
00007b00b77d4c7a  vmovaps xmm3, [rsp+0x30]
00007b00b77d4c80  vmovaps xmm4, [rsp+0x40]
00007b00b77d4c86  vmovaps xmm5, [rsp+0x50]
00007b00b77d4c8c  vmovaps xmm6, [rsp+0x60]
00007b00b77d4c92  vmovaps xmm7, [rsp+0x70]
00007b00b77d4c98  vmovaps xmm8, [rsp+0x80]
00007b00b77d4ca1  vmovaps xmm10, [rsp+0x90]
00007b00b77d4caa  vmovaps xmm11, [rsp+0xA0]
00007b00b77d4cb3  vmovaps xmm12, [rsp+0xB0]
00007b00b77d4cbc  vmovaps xmm13, [rsp+0xC0]
00007b00b77d4cc5  vmovaps xmm14, [rsp+0xD0]
00007b00b77d4cce  vmovaps xmm15, [rsp+0xE0]
00007b00b77d4cd7  add rsp, 0xF0
00007b00b77d4cde  pop r11
00007b00b77d4ce0  pop r10
00007b00b77d4ce2  pop r9
00007b00b77d4ce4  pop r8
00007b00b77d4ce6  pop rsi
00007b00b77d4ce7  pop rdi
00007b00b77d4ce8  pop rdx
00007b00b77d4ce9  pop rcx
00007b00b77d4cea  pop rax
00007b00b77d4ceb  add rsp, 0x08
00007b00b77d4cef  jmp 0x00007B00B77D2F01
00007b00b77d4cf4  sub rsp, 0x08
00007b00b77d4cf8  push rax
00007b00b77d4cf9  push rcx
00007b00b77d4cfa  push rdx
00007b00b77d4cfb  push rdi
00007b00b77d4cfc  push rsi
00007b00b77d4cfd  push r8
00007b00b77d4cff  push r9
00007b00b77d4d01  push r10
00007b00b77d4d03  push r11
00007b00b77d4d05  sub rsp, 0xF0
00007b00b77d4d0c  vmovaps [rsp], xmm0
00007b00b77d4d11  vmovaps [rsp+0x10], xmm1
00007b00b77d4d17  vmovaps [rsp+0x20], xmm2
00007b00b77d4d1d  vmovaps [rsp+0x30], xmm3
00007b00b77d4d23  vmovaps [rsp+0x40], xmm4
00007b00b77d4d29  vmovaps [rsp+0x50], xmm5
00007b00b77d4d2f  vmovaps [rsp+0x60], xmm6
00007b00b77d4d35  vmovaps [rsp+0x70], xmm7
00007b00b77d4d3b  vmovaps [rsp+0x80], xmm8
00007b00b77d4d44  vmovaps [rsp+0x90], xmm9
00007b00b77d4d4d  vmovaps [rsp+0xA0], xmm10
00007b00b77d4d56  vmovaps [rsp+0xB0], xmm11
00007b00b77d4d5f  vmovaps [rsp+0xC0], xmm13
00007b00b77d4d68  vmovaps [rsp+0xD0], xmm14
00007b00b77d4d71  vmovaps [rsp+0xE0], xmm15
00007b00b77d4d7a  sub rsp, 0x40
00007b00b77d4d7e  lea rdi, [rsp]
00007b00b77d4d82  lea rsi, [rsp+0x10]
00007b00b77d4d87  lea rdx, [rsp+0x20]
00007b00b77d4d8c  lea rcx, [rsp+0x30]
00007b00b77d4d91  mov r8d, 0x00
00007b00b77d4d97  lea r9, [r15+0x3A8]
00007b00b77d4d9e  movaps [rdi], xmm12
00007b00b77d4da2  movaps [rsi], xmm11
00007b00b77d4da6  movaps [rdx], xmm6
00007b00b77d4da9  movaps [rcx], xmm13
00007b00b77d4dad  mov rax, 0x612A23581A50
00007b00b77d4db7  call rax
00007b00b77d4db9  movaps xmm12, [rsp]
00007b00b77d4dbe  add rsp, 0x40
00007b00b77d4dc2  vmovaps xmm0, [rsp]
00007b00b77d4dc7  vmovaps xmm1, [rsp+0x10]
00007b00b77d4dcd  vmovaps xmm2, [rsp+0x20]
00007b00b77d4dd3  vmovaps xmm3, [rsp+0x30]
00007b00b77d4dd9  vmovaps xmm4, [rsp+0x40]
00007b00b77d4ddf  vmovaps xmm5, [rsp+0x50]
00007b00b77d4de5  vmovaps xmm6, [rsp+0x60]
00007b00b77d4deb  vmovaps xmm7, [rsp+0x70]
00007b00b77d4df1  vmovaps xmm8, [rsp+0x80]
00007b00b77d4dfa  vmovaps xmm9, [rsp+0x90]
00007b00b77d4e03  vmovaps xmm10, [rsp+0xA0]
00007b00b77d4e0c  vmovaps xmm11, [rsp+0xB0]
00007b00b77d4e15  vmovaps xmm13, [rsp+0xC0]
00007b00b77d4e1e  vmovaps xmm14, [rsp+0xD0]
00007b00b77d4e27  vmovaps xmm15, [rsp+0xE0]
00007b00b77d4e30  add rsp, 0xF0
00007b00b77d4e37  pop r11
00007b00b77d4e39  pop r10
00007b00b77d4e3b  pop r9
00007b00b77d4e3d  pop r8
00007b00b77d4e3f  pop rsi
00007b00b77d4e40  pop rdi
00007b00b77d4e41  pop rdx
00007b00b77d4e42  pop rcx
00007b00b77d4e43  pop rax
00007b00b77d4e44  add rsp, 0x08
00007b00b77d4e48  jmp 0x00007B00B77D2F2A
00007b00b77d4e4d  sub rsp, 0x08
00007b00b77d4e51  push rax
00007b00b77d4e52  push rcx
00007b00b77d4e53  push rdx
00007b00b77d4e54  push rdi
00007b00b77d4e55  push rsi
00007b00b77d4e56  push r8
00007b00b77d4e58  push r9
00007b00b77d4e5a  push r10
00007b00b77d4e5c  push r11
00007b00b77d4e5e  sub rsp, 0xF0
00007b00b77d4e65  vmovaps [rsp], xmm0
00007b00b77d4e6a  vmovaps [rsp+0x10], xmm1
00007b00b77d4e70  vmovaps [rsp+0x20], xmm2
00007b00b77d4e76  vmovaps [rsp+0x30], xmm3
00007b00b77d4e7c  vmovaps [rsp+0x40], xmm4
00007b00b77d4e82  vmovaps [rsp+0x50], xmm5
00007b00b77d4e88  vmovaps [rsp+0x60], xmm6
00007b00b77d4e8e  vmovaps [rsp+0x70], xmm8
00007b00b77d4e94  vmovaps [rsp+0x80], xmm9
00007b00b77d4e9d  vmovaps [rsp+0x90], xmm10
00007b00b77d4ea6  vmovaps [rsp+0xA0], xmm11
00007b00b77d4eaf  vmovaps [rsp+0xB0], xmm12
00007b00b77d4eb8  vmovaps [rsp+0xC0], xmm13
00007b00b77d4ec1  vmovaps [rsp+0xD0], xmm14
00007b00b77d4eca  vmovaps [rsp+0xE0], xmm15
00007b00b77d4ed3  sub rsp, 0x40
00007b00b77d4ed7  lea rdi, [rsp]
00007b00b77d4edb  lea rsi, [rsp+0x10]
00007b00b77d4ee0  lea rdx, [rsp+0x20]
00007b00b77d4ee5  lea rcx, [rsp+0x30]
00007b00b77d4eea  mov r8d, 0x00
00007b00b77d4ef0  lea r9, [r15+0x3A8]
00007b00b77d4ef7  movaps [rdi], xmm7
00007b00b77d4efa  movaps [rsi], xmm10
00007b00b77d4efe  movaps [rdx], xmm11
00007b00b77d4f02  movaps [rcx], xmm13
00007b00b77d4f06  mov rax, 0x612A23581A50
00007b00b77d4f10  call rax
00007b00b77d4f12  movaps xmm7, [rsp]
00007b00b77d4f16  add rsp, 0x40
00007b00b77d4f1a  vmovaps xmm0, [rsp]
00007b00b77d4f1f  vmovaps xmm1, [rsp+0x10]
00007b00b77d4f25  vmovaps xmm2, [rsp+0x20]
00007b00b77d4f2b  vmovaps xmm3, [rsp+0x30]
00007b00b77d4f31  vmovaps xmm4, [rsp+0x40]
00007b00b77d4f37  vmovaps xmm5, [rsp+0x50]
00007b00b77d4f3d  vmovaps xmm6, [rsp+0x60]
00007b00b77d4f43  vmovaps xmm8, [rsp+0x70]
00007b00b77d4f49  vmovaps xmm9, [rsp+0x80]
00007b00b77d4f52  vmovaps xmm10, [rsp+0x90]
00007b00b77d4f5b  vmovaps xmm11, [rsp+0xA0]
00007b00b77d4f64  vmovaps xmm12, [rsp+0xB0]
00007b00b77d4f6d  vmovaps xmm13, [rsp+0xC0]
00007b00b77d4f76  vmovaps xmm14, [rsp+0xD0]
00007b00b77d4f7f  vmovaps xmm15, [rsp+0xE0]
00007b00b77d4f88  add rsp, 0xF0
00007b00b77d4f8f  pop r11
00007b00b77d4f91  pop r10
00007b00b77d4f93  pop r9
00007b00b77d4f95  pop r8
00007b00b77d4f97  pop rsi
00007b00b77d4f98  pop rdi
00007b00b77d4f99  pop rdx
00007b00b77d4f9a  pop rcx
00007b00b77d4f9b  pop rax
00007b00b77d4f9c  add rsp, 0x08
00007b00b77d4fa0  jmp 0x00007B00B77D2F58
00007b00b77d4fa5  call 0x00007B00B760C260
00007b00b77d4faa  jmp 0x00007B00B77D2F62
00007b00b77d4faf  call 0x00007B00B7609D70
00007b00b77d4fb4  jmp 0x00007B00B77D2F6C
00007b00b77d4fb9  sub rsp, 0x08
00007b00b77d4fbd  push rax
00007b00b77d4fbe  push rcx
00007b00b77d4fbf  push rdx
00007b00b77d4fc0  push rdi
00007b00b77d4fc1  push rsi
00007b00b77d4fc2  push r8
00007b00b77d4fc4  push r9
00007b00b77d4fc6  push r10
00007b00b77d4fc8  push r11
00007b00b77d4fca  sub rsp, 0xF0
00007b00b77d4fd1  vmovaps [rsp], xmm0
00007b00b77d4fd6  vmovaps [rsp+0x10], xmm1
00007b00b77d4fdc  vmovaps [rsp+0x20], xmm2
00007b00b77d4fe2  vmovaps [rsp+0x30], xmm3
00007b00b77d4fe8  vmovaps [rsp+0x40], xmm4
00007b00b77d4fee  vmovaps [rsp+0x50], xmm5
00007b00b77d4ff4  vmovaps [rsp+0x60], xmm7
00007b00b77d4ffa  vmovaps [rsp+0x70], xmm8
00007b00b77d5000  vmovaps [rsp+0x80], xmm9
00007b00b77d5009  vmovaps [rsp+0x90], xmm10
00007b00b77d5012  vmovaps [rsp+0xA0], xmm11
00007b00b77d501b  vmovaps [rsp+0xB0], xmm12
00007b00b77d5024  vmovaps [rsp+0xC0], xmm13
00007b00b77d502d  vmovaps [rsp+0xD0], xmm14
00007b00b77d5036  vmovaps [rsp+0xE0], xmm15
00007b00b77d503f  sub rsp, 0x40
00007b00b77d5043  lea rdi, [rsp]
00007b00b77d5047  lea rsi, [rsp+0x10]
00007b00b77d504c  lea rdx, [rsp+0x20]
00007b00b77d5051  lea rcx, [rsp+0x30]
00007b00b77d5056  mov r8d, 0x00
00007b00b77d505c  lea r9, [r15+0x3A8]
00007b00b77d5063  movaps [rdi], xmm6
00007b00b77d5066  movaps [rsi], xmm8
00007b00b77d506a  movaps [rdx], xmm15
00007b00b77d506e  movaps [rcx], xmm10
00007b00b77d5072  mov rax, 0x612A23581A50
00007b00b77d507c  call rax
00007b00b77d507e  movaps xmm6, [rsp]
00007b00b77d5082  add rsp, 0x40
00007b00b77d5086  vmovaps xmm0, [rsp]
00007b00b77d508b  vmovaps xmm1, [rsp+0x10]
00007b00b77d5091  vmovaps xmm2, [rsp+0x20]
00007b00b77d5097  vmovaps xmm3, [rsp+0x30]
00007b00b77d509d  vmovaps xmm4, [rsp+0x40]
00007b00b77d50a3  vmovaps xmm5, [rsp+0x50]
00007b00b77d50a9  vmovaps xmm7, [rsp+0x60]
00007b00b77d50af  vmovaps xmm8, [rsp+0x70]
00007b00b77d50b5  vmovaps xmm9, [rsp+0x80]
00007b00b77d50be  vmovaps xmm10, [rsp+0x90]
00007b00b77d50c7  vmovaps xmm11, [rsp+0xA0]
00007b00b77d50d0  vmovaps xmm12, [rsp+0xB0]
00007b00b77d50d9  vmovaps xmm13, [rsp+0xC0]
00007b00b77d50e2  vmovaps xmm14, [rsp+0xD0]
00007b00b77d50eb  vmovaps xmm15, [rsp+0xE0]
00007b00b77d50f4  add rsp, 0xF0
00007b00b77d50fb  pop r11
00007b00b77d50fd  pop r10
00007b00b77d50ff  pop r9
00007b00b77d5101  pop r8
00007b00b77d5103  pop rsi
00007b00b77d5104  pop rdi
00007b00b77d5105  pop rdx
00007b00b77d5106  pop rcx
00007b00b77d5107  pop rax
00007b00b77d5108  add rsp, 0x08
00007b00b77d510c  jmp 0x00007B00B77D2FA4
00007b00b77d5111  sub rsp, 0x08
00007b00b77d5115  push rax
00007b00b77d5116  push rcx
00007b00b77d5117  push rdx
00007b00b77d5118  push rdi
00007b00b77d5119  push rsi
00007b00b77d511a  push r8
00007b00b77d511c  push r9
00007b00b77d511e  push r10
00007b00b77d5120  push r11
00007b00b77d5122  sub rsp, 0xF0
00007b00b77d5129  vmovaps [rsp], xmm0
00007b00b77d512e  vmovaps [rsp+0x10], xmm1
00007b00b77d5134  vmovaps [rsp+0x20], xmm2
00007b00b77d513a  vmovaps [rsp+0x30], xmm3
00007b00b77d5140  vmovaps [rsp+0x40], xmm4
00007b00b77d5146  vmovaps [rsp+0x50], xmm5
00007b00b77d514c  vmovaps [rsp+0x60], xmm6
00007b00b77d5152  vmovaps [rsp+0x70], xmm7
00007b00b77d5158  vmovaps [rsp+0x80], xmm8
00007b00b77d5161  vmovaps [rsp+0x90], xmm9
00007b00b77d516a  vmovaps [rsp+0xA0], xmm11
00007b00b77d5173  vmovaps [rsp+0xB0], xmm12
00007b00b77d517c  vmovaps [rsp+0xC0], xmm13
00007b00b77d5185  vmovaps [rsp+0xD0], xmm14
00007b00b77d518e  vmovaps [rsp+0xE0], xmm15
00007b00b77d5197  sub rsp, 0x40
00007b00b77d519b  lea rdi, [rsp]
00007b00b77d519f  lea rsi, [rsp+0x10]
00007b00b77d51a4  lea rdx, [rsp+0x20]
00007b00b77d51a9  lea rcx, [rsp+0x30]
00007b00b77d51ae  mov r8d, 0x00
00007b00b77d51b4  lea r9, [r15+0x3A8]
00007b00b77d51bb  movaps [rdi], xmm10
00007b00b77d51bf  movaps [rsi], xmm9
00007b00b77d51c3  movaps [rdx], xmm13
00007b00b77d51c7  movaps [rcx], xmm15
00007b00b77d51cb  mov rax, 0x612A23581A50
00007b00b77d51d5  call rax
00007b00b77d51d7  movaps xmm10, [rsp]
00007b00b77d51dc  add rsp, 0x40
00007b00b77d51e0  vmovaps xmm0, [rsp]
00007b00b77d51e5  vmovaps xmm1, [rsp+0x10]
00007b00b77d51eb  vmovaps xmm2, [rsp+0x20]
00007b00b77d51f1  vmovaps xmm3, [rsp+0x30]
00007b00b77d51f7  vmovaps xmm4, [rsp+0x40]
00007b00b77d51fd  vmovaps xmm5, [rsp+0x50]
00007b00b77d5203  vmovaps xmm6, [rsp+0x60]
00007b00b77d5209  vmovaps xmm7, [rsp+0x70]
00007b00b77d520f  vmovaps xmm8, [rsp+0x80]
00007b00b77d5218  vmovaps xmm9, [rsp+0x90]
00007b00b77d5221  vmovaps xmm11, [rsp+0xA0]
00007b00b77d522a  vmovaps xmm12, [rsp+0xB0]
00007b00b77d5233  vmovaps xmm13, [rsp+0xC0]
00007b00b77d523c  vmovaps xmm14, [rsp+0xD0]
00007b00b77d5245  vmovaps xmm15, [rsp+0xE0]
00007b00b77d524e  add rsp, 0xF0
00007b00b77d5255  pop r11
00007b00b77d5257  pop r10
00007b00b77d5259  pop r9
00007b00b77d525b  pop r8
00007b00b77d525d  pop rsi
00007b00b77d525e  pop rdi
00007b00b77d525f  pop rdx
00007b00b77d5260  pop rcx
00007b00b77d5261  pop rax
00007b00b77d5262  add rsp, 0x08
00007b00b77d5266  jmp 0x00007B00B77D2FCD
00007b00b77d526b  sub rsp, 0x08
00007b00b77d526f  push rax
00007b00b77d5270  push rcx
00007b00b77d5271  push rdx
00007b00b77d5272  push rdi
00007b00b77d5273  push rsi
00007b00b77d5274  push r8
00007b00b77d5276  push r9
00007b00b77d5278  push r10
00007b00b77d527a  push r11
00007b00b77d527c  sub rsp, 0xF0
00007b00b77d5283  vmovaps [rsp], xmm0
00007b00b77d5288  vmovaps [rsp+0x10], xmm1
00007b00b77d528e  vmovaps [rsp+0x20], xmm2
00007b00b77d5294  vmovaps [rsp+0x30], xmm3
00007b00b77d529a  vmovaps [rsp+0x40], xmm4
00007b00b77d52a0  vmovaps [rsp+0x50], xmm5
00007b00b77d52a6  vmovaps [rsp+0x60], xmm6
00007b00b77d52ac  vmovaps [rsp+0x70], xmm7
00007b00b77d52b2  vmovaps [rsp+0x80], xmm8
00007b00b77d52bb  vmovaps [rsp+0x90], xmm9
00007b00b77d52c4  vmovaps [rsp+0xA0], xmm10
00007b00b77d52cd  vmovaps [rsp+0xB0], xmm11
00007b00b77d52d6  vmovaps [rsp+0xC0], xmm12
00007b00b77d52df  vmovaps [rsp+0xD0], xmm14
00007b00b77d52e8  vmovaps [rsp+0xE0], xmm15
00007b00b77d52f1  sub rsp, 0x40
00007b00b77d52f5  lea rdi, [rsp]
00007b00b77d52f9  lea rsi, [rsp+0x10]
00007b00b77d52fe  lea rdx, [rsp+0x20]
00007b00b77d5303  lea rcx, [rsp+0x30]
00007b00b77d5308  mov r8d, 0x00
00007b00b77d530e  lea r9, [r15+0x3A8]
00007b00b77d5315  movaps [rdi], xmm13
00007b00b77d5319  movaps [rsi], xmm12
00007b00b77d531d  movaps [rdx], xmm4
00007b00b77d5320  movaps [rcx], xmm15
00007b00b77d5324  mov rax, 0x612A23581A50
00007b00b77d532e  call rax
00007b00b77d5330  movaps xmm13, [rsp]
00007b00b77d5335  add rsp, 0x40
00007b00b77d5339  vmovaps xmm0, [rsp]
00007b00b77d533e  vmovaps xmm1, [rsp+0x10]
00007b00b77d5344  vmovaps xmm2, [rsp+0x20]
00007b00b77d534a  vmovaps xmm3, [rsp+0x30]
00007b00b77d5350  vmovaps xmm4, [rsp+0x40]
00007b00b77d5356  vmovaps xmm5, [rsp+0x50]
00007b00b77d535c  vmovaps xmm6, [rsp+0x60]
00007b00b77d5362  vmovaps xmm7, [rsp+0x70]
00007b00b77d5368  vmovaps xmm8, [rsp+0x80]
00007b00b77d5371  vmovaps xmm9, [rsp+0x90]
00007b00b77d537a  vmovaps xmm10, [rsp+0xA0]
00007b00b77d5383  vmovaps xmm11, [rsp+0xB0]
00007b00b77d538c  vmovaps xmm12, [rsp+0xC0]
00007b00b77d5395  vmovaps xmm14, [rsp+0xD0]
00007b00b77d539e  vmovaps xmm15, [rsp+0xE0]
00007b00b77d53a7  add rsp, 0xF0
00007b00b77d53ae  pop r11
00007b00b77d53b0  pop r10
00007b00b77d53b2  pop r9
00007b00b77d53b4  pop r8
00007b00b77d53b6  pop rsi
00007b00b77d53b7  pop rdi
00007b00b77d53b8  pop rdx
00007b00b77d53b9  pop rcx
00007b00b77d53ba  pop rax
00007b00b77d53bb  add rsp, 0x08
00007b00b77d53bf  jmp 0x00007B00B77D2FF6
00007b00b77d53c4  sub rsp, 0x08
00007b00b77d53c8  push rax
00007b00b77d53c9  push rcx
00007b00b77d53ca  push rdx
00007b00b77d53cb  push rdi
00007b00b77d53cc  push rsi
00007b00b77d53cd  push r8
00007b00b77d53cf  push r9
00007b00b77d53d1  push r10
00007b00b77d53d3  push r11
00007b00b77d53d5  sub rsp, 0xF0
00007b00b77d53dc  vmovaps [rsp], xmm0
00007b00b77d53e1  vmovaps [rsp+0x10], xmm1
00007b00b77d53e7  vmovaps [rsp+0x20], xmm2
00007b00b77d53ed  vmovaps [rsp+0x30], xmm3
00007b00b77d53f3  vmovaps [rsp+0x40], xmm4
00007b00b77d53f9  vmovaps [rsp+0x50], xmm5
00007b00b77d53ff  vmovaps [rsp+0x60], xmm6
00007b00b77d5405  vmovaps [rsp+0x70], xmm7
00007b00b77d540b  vmovaps [rsp+0x80], xmm8
00007b00b77d5414  vmovaps [rsp+0x90], xmm9
00007b00b77d541d  vmovaps [rsp+0xA0], xmm10
00007b00b77d5426  vmovaps [rsp+0xB0], xmm11
00007b00b77d542f  vmovaps [rsp+0xC0], xmm13
00007b00b77d5438  vmovaps [rsp+0xD0], xmm14
00007b00b77d5441  vmovaps [rsp+0xE0], xmm15
00007b00b77d544a  sub rsp, 0x40
00007b00b77d544e  lea rdi, [rsp]
00007b00b77d5452  lea rsi, [rsp+0x10]
00007b00b77d5457  lea rdx, [rsp+0x20]
00007b00b77d545c  lea rcx, [rsp+0x30]
00007b00b77d5461  mov r8d, 0x00
00007b00b77d5467  lea r9, [r15+0x3A8]
00007b00b77d546e  movaps [rdi], xmm12
00007b00b77d5472  movaps [rsi], xmm7
00007b00b77d5475  movaps [rdx], xmm1
00007b00b77d5478  movaps [rcx], xmm15
00007b00b77d547c  mov rax, 0x612A23581A50
00007b00b77d5486  call rax
00007b00b77d5488  movaps xmm12, [rsp]
00007b00b77d548d  add rsp, 0x40
00007b00b77d5491  vmovaps xmm0, [rsp]
00007b00b77d5496  vmovaps xmm1, [rsp+0x10]
00007b00b77d549c  vmovaps xmm2, [rsp+0x20]
00007b00b77d54a2  vmovaps xmm3, [rsp+0x30]
00007b00b77d54a8  vmovaps xmm4, [rsp+0x40]
00007b00b77d54ae  vmovaps xmm5, [rsp+0x50]
00007b00b77d54b4  vmovaps xmm6, [rsp+0x60]
00007b00b77d54ba  vmovaps xmm7, [rsp+0x70]
00007b00b77d54c0  vmovaps xmm8, [rsp+0x80]
00007b00b77d54c9  vmovaps xmm9, [rsp+0x90]
00007b00b77d54d2  vmovaps xmm10, [rsp+0xA0]
00007b00b77d54db  vmovaps xmm11, [rsp+0xB0]
00007b00b77d54e4  vmovaps xmm13, [rsp+0xC0]
00007b00b77d54ed  vmovaps xmm14, [rsp+0xD0]
00007b00b77d54f6  vmovaps xmm15, [rsp+0xE0]
00007b00b77d54ff  add rsp, 0xF0
00007b00b77d5506  pop r11
00007b00b77d5508  pop r10
00007b00b77d550a  pop r9
00007b00b77d550c  pop r8
00007b00b77d550e  pop rsi
00007b00b77d550f  pop rdi
00007b00b77d5510  pop rdx
00007b00b77d5511  pop rcx
00007b00b77d5512  pop rax
00007b00b77d5513  add rsp, 0x08
00007b00b77d5517  jmp 0x00007B00B77D301F
00007b00b77d551c  call 0x00007B00B75FF430
00007b00b77d5521  jmp 0x00007B00B77D3029
00007b00b77d5526  call 0x00007B00B760E760
00007b00b77d552b  jmp 0x00007B00B77D3033
00007b00b77d5530  sub rsp, 0x08
00007b00b77d5534  push rax
00007b00b77d5535  push rcx
00007b00b77d5536  push rdx
00007b00b77d5537  push rdi
00007b00b77d5538  push rsi
00007b00b77d5539  push r8
00007b00b77d553b  push r9
00007b00b77d553d  push r10
00007b00b77d553f  push r11
00007b00b77d5541  sub rsp, 0xF0
00007b00b77d5548  vmovaps [rsp], xmm0
00007b00b77d554d  vmovaps [rsp+0x10], xmm1
00007b00b77d5553  vmovaps [rsp+0x20], xmm2
00007b00b77d5559  vmovaps [rsp+0x30], xmm3
00007b00b77d555f  vmovaps [rsp+0x40], xmm4
00007b00b77d5565  vmovaps [rsp+0x50], xmm5
00007b00b77d556b  vmovaps [rsp+0x60], xmm6
00007b00b77d5571  vmovaps [rsp+0x70], xmm8
00007b00b77d5577  vmovaps [rsp+0x80], xmm9
00007b00b77d5580  vmovaps [rsp+0x90], xmm10
00007b00b77d5589  vmovaps [rsp+0xA0], xmm11
00007b00b77d5592  vmovaps [rsp+0xB0], xmm12
00007b00b77d559b  vmovaps [rsp+0xC0], xmm13
00007b00b77d55a4  vmovaps [rsp+0xD0], xmm14
00007b00b77d55ad  vmovaps [rsp+0xE0], xmm15
00007b00b77d55b6  sub rsp, 0x40
00007b00b77d55ba  lea rdi, [rsp]
00007b00b77d55be  lea rsi, [rsp+0x10]
00007b00b77d55c3  lea rdx, [rsp+0x20]
00007b00b77d55c8  lea rcx, [rsp+0x30]
00007b00b77d55cd  mov r8d, 0x00
00007b00b77d55d3  lea r9, [r15+0x3A8]
00007b00b77d55da  movaps [rdi], xmm7
00007b00b77d55dd  movaps [rsi], xmm6
00007b00b77d55e0  movaps [rdx], xmm8
00007b00b77d55e4  movaps [rcx], xmm9
00007b00b77d55e8  mov rax, 0x612A23581A50
00007b00b77d55f2  call rax
00007b00b77d55f4  movaps xmm7, [rsp]
00007b00b77d55f8  add rsp, 0x40
00007b00b77d55fc  vmovaps xmm0, [rsp]
00007b00b77d5601  vmovaps xmm1, [rsp+0x10]
00007b00b77d5607  vmovaps xmm2, [rsp+0x20]
00007b00b77d560d  vmovaps xmm3, [rsp+0x30]
00007b00b77d5613  vmovaps xmm4, [rsp+0x40]
00007b00b77d5619  vmovaps xmm5, [rsp+0x50]
00007b00b77d561f  vmovaps xmm6, [rsp+0x60]
00007b00b77d5625  vmovaps xmm8, [rsp+0x70]
00007b00b77d562b  vmovaps xmm9, [rsp+0x80]
00007b00b77d5634  vmovaps xmm10, [rsp+0x90]
00007b00b77d563d  vmovaps xmm11, [rsp+0xA0]
00007b00b77d5646  vmovaps xmm12, [rsp+0xB0]
00007b00b77d564f  vmovaps xmm13, [rsp+0xC0]
00007b00b77d5658  vmovaps xmm14, [rsp+0xD0]
00007b00b77d5661  vmovaps xmm15, [rsp+0xE0]
00007b00b77d566a  add rsp, 0xF0
00007b00b77d5671  pop r11
00007b00b77d5673  pop r10
00007b00b77d5675  pop r9
00007b00b77d5677  pop r8
00007b00b77d5679  pop rsi
00007b00b77d567a  pop rdi
00007b00b77d567b  pop rdx
00007b00b77d567c  pop rcx
00007b00b77d567d  pop rax
00007b00b77d567e  add rsp, 0x08
00007b00b77d5682  jmp 0x00007B00B77D305D
00007b00b77d5687  sub rsp, 0x08
00007b00b77d568b  push rax
00007b00b77d568c  push rcx
00007b00b77d568d  push rdx
00007b00b77d568e  push rdi
00007b00b77d568f  push rsi
00007b00b77d5690  push r8
00007b00b77d5692  push r9
00007b00b77d5694  push r10
00007b00b77d5696  push r11
00007b00b77d5698  sub rsp, 0xF0
00007b00b77d569f  vmovaps [rsp], xmm0
00007b00b77d56a4  vmovaps [rsp+0x10], xmm1
00007b00b77d56aa  vmovaps [rsp+0x20], xmm2
00007b00b77d56b0  vmovaps [rsp+0x30], xmm3
00007b00b77d56b6  vmovaps [rsp+0x40], xmm4
00007b00b77d56bc  vmovaps [rsp+0x50], xmm5
00007b00b77d56c2  vmovaps [rsp+0x60], xmm6
00007b00b77d56c8  vmovaps [rsp+0x70], xmm7
00007b00b77d56ce  vmovaps [rsp+0x80], xmm9
00007b00b77d56d7  vmovaps [rsp+0x90], xmm10
00007b00b77d56e0  vmovaps [rsp+0xA0], xmm11
00007b00b77d56e9  vmovaps [rsp+0xB0], xmm12
00007b00b77d56f2  vmovaps [rsp+0xC0], xmm13
00007b00b77d56fb  vmovaps [rsp+0xD0], xmm14
00007b00b77d5704  vmovaps [rsp+0xE0], xmm15
00007b00b77d570d  sub rsp, 0x40
00007b00b77d5711  lea rdi, [rsp]
00007b00b77d5715  lea rsi, [rsp+0x10]
00007b00b77d571a  lea rdx, [rsp+0x20]
00007b00b77d571f  lea rcx, [rsp+0x30]
00007b00b77d5724  mov r8d, 0x00
00007b00b77d572a  lea r9, [r15+0x3A8]
00007b00b77d5731  movaps [rdi], xmm8
00007b00b77d5735  movaps [rsi], xmm10
00007b00b77d5739  movaps [rdx], xmm14
00007b00b77d573d  movaps [rcx], xmm9
00007b00b77d5741  mov rax, 0x612A23581A50
00007b00b77d574b  call rax
00007b00b77d574d  movaps xmm8, [rsp]
00007b00b77d5752  add rsp, 0x40
00007b00b77d5756  vmovaps xmm0, [rsp]
00007b00b77d575b  vmovaps xmm1, [rsp+0x10]
00007b00b77d5761  vmovaps xmm2, [rsp+0x20]
00007b00b77d5767  vmovaps xmm3, [rsp+0x30]
00007b00b77d576d  vmovaps xmm4, [rsp+0x40]
00007b00b77d5773  vmovaps xmm5, [rsp+0x50]
00007b00b77d5779  vmovaps xmm6, [rsp+0x60]
00007b00b77d577f  vmovaps xmm7, [rsp+0x70]
00007b00b77d5785  vmovaps xmm9, [rsp+0x80]
00007b00b77d578e  vmovaps xmm10, [rsp+0x90]
00007b00b77d5797  vmovaps xmm11, [rsp+0xA0]
00007b00b77d57a0  vmovaps xmm12, [rsp+0xB0]
00007b00b77d57a9  vmovaps xmm13, [rsp+0xC0]
00007b00b77d57b2  vmovaps xmm14, [rsp+0xD0]
00007b00b77d57bb  vmovaps xmm15, [rsp+0xE0]
00007b00b77d57c4  add rsp, 0xF0
00007b00b77d57cb  pop r11
00007b00b77d57cd  pop r10
00007b00b77d57cf  pop r9
00007b00b77d57d1  pop r8
00007b00b77d57d3  pop rsi
00007b00b77d57d4  pop rdi
00007b00b77d57d5  pop rdx
00007b00b77d57d6  pop rcx
00007b00b77d57d7  pop rax
00007b00b77d57d8  add rsp, 0x08
00007b00b77d57dc  jmp 0x00007B00B77D3083
00007b00b77d57e1  sub rsp, 0x08
00007b00b77d57e5  push rax
00007b00b77d57e6  push rcx
00007b00b77d57e7  push rdx
00007b00b77d57e8  push rdi
00007b00b77d57e9  push rsi
00007b00b77d57ea  push r8
00007b00b77d57ec  push r9
00007b00b77d57ee  push r10
00007b00b77d57f0  push r11
00007b00b77d57f2  sub rsp, 0xF0
00007b00b77d57f9  vmovaps [rsp], xmm0
00007b00b77d57fe  vmovaps [rsp+0x10], xmm1
00007b00b77d5804  vmovaps [rsp+0x20], xmm2
00007b00b77d580a  vmovaps [rsp+0x30], xmm3
00007b00b77d5810  vmovaps [rsp+0x40], xmm4
00007b00b77d5816  vmovaps [rsp+0x50], xmm5
00007b00b77d581c  vmovaps [rsp+0x60], xmm6
00007b00b77d5822  vmovaps [rsp+0x70], xmm7
00007b00b77d5828  vmovaps [rsp+0x80], xmm8
00007b00b77d5831  vmovaps [rsp+0x90], xmm9
00007b00b77d583a  vmovaps [rsp+0xA0], xmm11
00007b00b77d5843  vmovaps [rsp+0xB0], xmm12
00007b00b77d584c  vmovaps [rsp+0xC0], xmm13
00007b00b77d5855  vmovaps [rsp+0xD0], xmm14
00007b00b77d585e  vmovaps [rsp+0xE0], xmm15
00007b00b77d5867  sub rsp, 0x40
00007b00b77d586b  lea rdi, [rsp]
00007b00b77d586f  lea rsi, [rsp+0x10]
00007b00b77d5874  lea rdx, [rsp+0x20]
00007b00b77d5879  lea rcx, [rsp+0x30]
00007b00b77d587e  mov r8d, 0x00
00007b00b77d5884  lea r9, [r15+0x3A8]
00007b00b77d588b  movaps [rdi], xmm10
00007b00b77d588f  movaps [rsi], xmm13
00007b00b77d5893  movaps [rdx], xmm11
00007b00b77d5897  movaps [rcx], xmm14
00007b00b77d589b  mov rax, 0x612A23581A50
00007b00b77d58a5  call rax
00007b00b77d58a7  movaps xmm10, [rsp]
00007b00b77d58ac  add rsp, 0x40
00007b00b77d58b0  vmovaps xmm0, [rsp]
00007b00b77d58b5  vmovaps xmm1, [rsp+0x10]
00007b00b77d58bb  vmovaps xmm2, [rsp+0x20]
00007b00b77d58c1  vmovaps xmm3, [rsp+0x30]
00007b00b77d58c7  vmovaps xmm4, [rsp+0x40]
00007b00b77d58cd  vmovaps xmm5, [rsp+0x50]
00007b00b77d58d3  vmovaps xmm6, [rsp+0x60]
00007b00b77d58d9  vmovaps xmm7, [rsp+0x70]
00007b00b77d58df  vmovaps xmm8, [rsp+0x80]
00007b00b77d58e8  vmovaps xmm9, [rsp+0x90]
00007b00b77d58f1  vmovaps xmm11, [rsp+0xA0]
00007b00b77d58fa  vmovaps xmm12, [rsp+0xB0]
00007b00b77d5903  vmovaps xmm13, [rsp+0xC0]
00007b00b77d590c  vmovaps xmm14, [rsp+0xD0]
00007b00b77d5915  vmovaps xmm15, [rsp+0xE0]
00007b00b77d591e  add rsp, 0xF0
00007b00b77d5925  pop r11
00007b00b77d5927  pop r10
00007b00b77d5929  pop r9
00007b00b77d592b  pop r8
00007b00b77d592d  pop rsi
00007b00b77d592e  pop rdi
00007b00b77d592f  pop rdx
00007b00b77d5930  pop rcx
00007b00b77d5931  pop rax
00007b00b77d5932  add rsp, 0x08
00007b00b77d5936  jmp 0x00007B00B77D30A9
00007b00b77d593b  sub rsp, 0x08
00007b00b77d593f  push rax
00007b00b77d5940  push rcx
00007b00b77d5941  push rdx
00007b00b77d5942  push rdi
00007b00b77d5943  push rsi
00007b00b77d5944  push r8
00007b00b77d5946  push r9
00007b00b77d5948  push r10
00007b00b77d594a  push r11
00007b00b77d594c  sub rsp, 0xF0
00007b00b77d5953  vmovaps [rsp], xmm0
00007b00b77d5958  vmovaps [rsp+0x10], xmm1
00007b00b77d595e  vmovaps [rsp+0x20], xmm2
00007b00b77d5964  vmovaps [rsp+0x30], xmm3
00007b00b77d596a  vmovaps [rsp+0x40], xmm4
00007b00b77d5970  vmovaps [rsp+0x50], xmm5
00007b00b77d5976  vmovaps [rsp+0x60], xmm6
00007b00b77d597c  vmovaps [rsp+0x70], xmm7
00007b00b77d5982  vmovaps [rsp+0x80], xmm8
00007b00b77d598b  vmovaps [rsp+0x90], xmm9
00007b00b77d5994  vmovaps [rsp+0xA0], xmm10
00007b00b77d599d  vmovaps [rsp+0xB0], xmm11
00007b00b77d59a6  vmovaps [rsp+0xC0], xmm12
00007b00b77d59af  vmovaps [rsp+0xD0], xmm14
00007b00b77d59b8  vmovaps [rsp+0xE0], xmm15
00007b00b77d59c1  sub rsp, 0x40
00007b00b77d59c5  lea rdi, [rsp]
00007b00b77d59c9  lea rsi, [rsp+0x10]
00007b00b77d59ce  lea rdx, [rsp+0x20]
00007b00b77d59d3  lea rcx, [rsp+0x30]
00007b00b77d59d8  mov r8d, 0x00
00007b00b77d59de  lea r9, [r15+0x3A8]
00007b00b77d59e5  movaps [rdi], xmm13
00007b00b77d59e9  movaps [rsi], xmm12
00007b00b77d59ed  movaps [rdx], xmm15
00007b00b77d59f1  movaps [rcx], xmm14
00007b00b77d59f5  mov rax, 0x612A23581A50
00007b00b77d59ff  call rax
00007b00b77d5a01  movaps xmm13, [rsp]
00007b00b77d5a06  add rsp, 0x40
00007b00b77d5a0a  vmovaps xmm0, [rsp]
00007b00b77d5a0f  vmovaps xmm1, [rsp+0x10]
00007b00b77d5a15  vmovaps xmm2, [rsp+0x20]
00007b00b77d5a1b  vmovaps xmm3, [rsp+0x30]
00007b00b77d5a21  vmovaps xmm4, [rsp+0x40]
00007b00b77d5a27  vmovaps xmm5, [rsp+0x50]
00007b00b77d5a2d  vmovaps xmm6, [rsp+0x60]
00007b00b77d5a33  vmovaps xmm7, [rsp+0x70]
00007b00b77d5a39  vmovaps xmm8, [rsp+0x80]
00007b00b77d5a42  vmovaps xmm9, [rsp+0x90]
00007b00b77d5a4b  vmovaps xmm10, [rsp+0xA0]
00007b00b77d5a54  vmovaps xmm11, [rsp+0xB0]
00007b00b77d5a5d  vmovaps xmm12, [rsp+0xC0]
00007b00b77d5a66  vmovaps xmm14, [rsp+0xD0]
00007b00b77d5a6f  vmovaps xmm15, [rsp+0xE0]
00007b00b77d5a78  add rsp, 0xF0
00007b00b77d5a7f  pop r11
00007b00b77d5a81  pop r10
00007b00b77d5a83  pop r9
00007b00b77d5a85  pop r8
00007b00b77d5a87  pop rsi
00007b00b77d5a88  pop rdi
00007b00b77d5a89  pop rdx
00007b00b77d5a8a  pop rcx
00007b00b77d5a8b  pop rax
00007b00b77d5a8c  add rsp, 0x08
00007b00b77d5a90  jmp 0x00007B00B77D30CF
00007b00b77d5a95  call 0x00007B00B760E760
00007b00b77d5a9a  jmp 0x00007B00B77D30DC
00007b00b77d5a9f  call 0x00007B00B760D4E0
00007b00b77d5aa4  jmp 0x00007B00B77D30E9
00007b00b77d5aa9  sub rsp, 0x08
00007b00b77d5aad  push rax
00007b00b77d5aae  push rcx
00007b00b77d5aaf  push rdx
00007b00b77d5ab0  push rdi
00007b00b77d5ab1  push rsi
00007b00b77d5ab2  push r8
00007b00b77d5ab4  push r9
00007b00b77d5ab6  push r10
00007b00b77d5ab8  push r11
00007b00b77d5aba  sub rsp, 0xF0
00007b00b77d5ac1  vmovaps [rsp], xmm0
00007b00b77d5ac6  vmovaps [rsp+0x10], xmm1
00007b00b77d5acc  vmovaps [rsp+0x20], xmm2
00007b00b77d5ad2  vmovaps [rsp+0x30], xmm3
00007b00b77d5ad8  vmovaps [rsp+0x40], xmm4
00007b00b77d5ade  vmovaps [rsp+0x50], xmm5
00007b00b77d5ae4  vmovaps [rsp+0x60], xmm6
00007b00b77d5aea  vmovaps [rsp+0x70], xmm7
00007b00b77d5af0  vmovaps [rsp+0x80], xmm8
00007b00b77d5af9  vmovaps [rsp+0x90], xmm9
00007b00b77d5b02  vmovaps [rsp+0xA0], xmm10
00007b00b77d5b0b  vmovaps [rsp+0xB0], xmm12
00007b00b77d5b14  vmovaps [rsp+0xC0], xmm13
00007b00b77d5b1d  vmovaps [rsp+0xD0], xmm14
00007b00b77d5b26  vmovaps [rsp+0xE0], xmm15
00007b00b77d5b2f  sub rsp, 0x40
00007b00b77d5b33  lea rdi, [rsp]
00007b00b77d5b37  lea rsi, [rsp+0x10]
00007b00b77d5b3c  lea rdx, [rsp+0x20]
00007b00b77d5b41  lea rcx, [rsp+0x30]
00007b00b77d5b46  mov r8d, 0x00
00007b00b77d5b4c  lea r9, [r15+0x3A8]
00007b00b77d5b53  movaps [rdi], xmm11
00007b00b77d5b57  movaps [rsi], xmm7
00007b00b77d5b5a  movaps [rdx], xmm1
00007b00b77d5b5d  movaps [rcx], xmm12
00007b00b77d5b61  mov rax, 0x612A23581A50
00007b00b77d5b6b  call rax
00007b00b77d5b6d  movaps xmm11, [rsp]
00007b00b77d5b72  add rsp, 0x40
00007b00b77d5b76  vmovaps xmm0, [rsp]
00007b00b77d5b7b  vmovaps xmm1, [rsp+0x10]
00007b00b77d5b81  vmovaps xmm2, [rsp+0x20]
00007b00b77d5b87  vmovaps xmm3, [rsp+0x30]
00007b00b77d5b8d  vmovaps xmm4, [rsp+0x40]
00007b00b77d5b93  vmovaps xmm5, [rsp+0x50]
00007b00b77d5b99  vmovaps xmm6, [rsp+0x60]
00007b00b77d5b9f  vmovaps xmm7, [rsp+0x70]
00007b00b77d5ba5  vmovaps xmm8, [rsp+0x80]
00007b00b77d5bae  vmovaps xmm9, [rsp+0x90]
00007b00b77d5bb7  vmovaps xmm10, [rsp+0xA0]
00007b00b77d5bc0  vmovaps xmm12, [rsp+0xB0]
00007b00b77d5bc9  vmovaps xmm13, [rsp+0xC0]
00007b00b77d5bd2  vmovaps xmm14, [rsp+0xD0]
00007b00b77d5bdb  vmovaps xmm15, [rsp+0xE0]
00007b00b77d5be4  add rsp, 0xF0
00007b00b77d5beb  pop r11
00007b00b77d5bed  pop r10
00007b00b77d5bef  pop r9
00007b00b77d5bf1  pop r8
00007b00b77d5bf3  pop rsi
00007b00b77d5bf4  pop rdi
00007b00b77d5bf5  pop rdx
00007b00b77d5bf6  pop rcx
00007b00b77d5bf7  pop rax
00007b00b77d5bf8  add rsp, 0x08
00007b00b77d5bfc  jmp 0x00007B00B77D3122
00007b00b77d5c01  call 0x00007B00B75FF430
00007b00b77d5c06  jmp 0x00007B00B77D3134
00007b00b77d5c0b  sub rsp, 0x08
00007b00b77d5c0f  push rax
00007b00b77d5c10  push rcx
00007b00b77d5c11  push rdx
00007b00b77d5c12  push rdi
00007b00b77d5c13  push rsi
00007b00b77d5c14  push r8
00007b00b77d5c16  push r9
00007b00b77d5c18  push r10
00007b00b77d5c1a  push r11
00007b00b77d5c1c  sub rsp, 0xF0
00007b00b77d5c23  vmovaps [rsp], xmm0
00007b00b77d5c28  vmovaps [rsp+0x10], xmm1
00007b00b77d5c2e  vmovaps [rsp+0x20], xmm2
00007b00b77d5c34  vmovaps [rsp+0x30], xmm3
00007b00b77d5c3a  vmovaps [rsp+0x40], xmm4
00007b00b77d5c40  vmovaps [rsp+0x50], xmm5
00007b00b77d5c46  vmovaps [rsp+0x60], xmm6
00007b00b77d5c4c  vmovaps [rsp+0x70], xmm7
00007b00b77d5c52  vmovaps [rsp+0x80], xmm8
00007b00b77d5c5b  vmovaps [rsp+0x90], xmm10
00007b00b77d5c64  vmovaps [rsp+0xA0], xmm11
00007b00b77d5c6d  vmovaps [rsp+0xB0], xmm12
00007b00b77d5c76  vmovaps [rsp+0xC0], xmm13
00007b00b77d5c7f  vmovaps [rsp+0xD0], xmm14
00007b00b77d5c88  vmovaps [rsp+0xE0], xmm15
00007b00b77d5c91  sub rsp, 0x40
00007b00b77d5c95  lea rdi, [rsp]
00007b00b77d5c99  lea rsi, [rsp+0x10]
00007b00b77d5c9e  lea rdx, [rsp+0x20]
00007b00b77d5ca3  lea rcx, [rsp+0x30]
00007b00b77d5ca8  mov r8d, 0x00
00007b00b77d5cae  lea r9, [r15+0x3A8]
00007b00b77d5cb5  movaps [rdi], xmm9
00007b00b77d5cb9  movaps [rsi], xmm8
00007b00b77d5cbd  movaps [rdx], xmm14
00007b00b77d5cc1  movaps [rcx], xmm12
00007b00b77d5cc5  mov rax, 0x612A23581A50
00007b00b77d5ccf  call rax
00007b00b77d5cd1  movaps xmm9, [rsp]
00007b00b77d5cd6  add rsp, 0x40
00007b00b77d5cda  vmovaps xmm0, [rsp]
00007b00b77d5cdf  vmovaps xmm1, [rsp+0x10]
00007b00b77d5ce5  vmovaps xmm2, [rsp+0x20]
00007b00b77d5ceb  vmovaps xmm3, [rsp+0x30]
00007b00b77d5cf1  vmovaps xmm4, [rsp+0x40]
00007b00b77d5cf7  vmovaps xmm5, [rsp+0x50]
00007b00b77d5cfd  vmovaps xmm6, [rsp+0x60]
00007b00b77d5d03  vmovaps xmm7, [rsp+0x70]
00007b00b77d5d09  vmovaps xmm8, [rsp+0x80]
00007b00b77d5d12  vmovaps xmm10, [rsp+0x90]
00007b00b77d5d1b  vmovaps xmm11, [rsp+0xA0]
00007b00b77d5d24  vmovaps xmm12, [rsp+0xB0]
00007b00b77d5d2d  vmovaps xmm13, [rsp+0xC0]
00007b00b77d5d36  vmovaps xmm14, [rsp+0xD0]
00007b00b77d5d3f  vmovaps xmm15, [rsp+0xE0]
00007b00b77d5d48  add rsp, 0xF0
00007b00b77d5d4f  pop r11
00007b00b77d5d51  pop r10
00007b00b77d5d53  pop r9
00007b00b77d5d55  pop r8
00007b00b77d5d57  pop rsi
00007b00b77d5d58  pop rdi
00007b00b77d5d59  pop rdx
00007b00b77d5d5a  pop rcx
00007b00b77d5d5b  pop rax
00007b00b77d5d5c  add rsp, 0x08
00007b00b77d5d60  jmp 0x00007B00B77D3165
00007b00b77d5d65  sub rsp, 0x08
00007b00b77d5d69  push rax
00007b00b77d5d6a  push rcx
00007b00b77d5d6b  push rdx
00007b00b77d5d6c  push rdi
00007b00b77d5d6d  push rsi
00007b00b77d5d6e  push r8
00007b00b77d5d70  push r9
00007b00b77d5d72  push r10
00007b00b77d5d74  push r11
00007b00b77d5d76  sub rsp, 0xF0
00007b00b77d5d7d  vmovaps [rsp], xmm0
00007b00b77d5d82  vmovaps [rsp+0x10], xmm1
00007b00b77d5d88  vmovaps [rsp+0x20], xmm2
00007b00b77d5d8e  vmovaps [rsp+0x30], xmm3
00007b00b77d5d94  vmovaps [rsp+0x40], xmm4
00007b00b77d5d9a  vmovaps [rsp+0x50], xmm5
00007b00b77d5da0  vmovaps [rsp+0x60], xmm6
00007b00b77d5da6  vmovaps [rsp+0x70], xmm7
00007b00b77d5dac  vmovaps [rsp+0x80], xmm8
00007b00b77d5db5  vmovaps [rsp+0x90], xmm9
00007b00b77d5dbe  vmovaps [rsp+0xA0], xmm10
00007b00b77d5dc7  vmovaps [rsp+0xB0], xmm11
00007b00b77d5dd0  vmovaps [rsp+0xC0], xmm13
00007b00b77d5dd9  vmovaps [rsp+0xD0], xmm14
00007b00b77d5de2  vmovaps [rsp+0xE0], xmm15
00007b00b77d5deb  sub rsp, 0x40
00007b00b77d5def  lea rdi, [rsp]
00007b00b77d5df3  lea rsi, [rsp+0x10]
00007b00b77d5df8  lea rdx, [rsp+0x20]
00007b00b77d5dfd  lea rcx, [rsp+0x30]
00007b00b77d5e02  mov r8d, 0x00
00007b00b77d5e08  lea r9, [r15+0x3A8]
00007b00b77d5e0f  movaps [rdi], xmm12
00007b00b77d5e13  movaps [rsi], xmm10
00007b00b77d5e17  movaps [rdx], xmm15
00007b00b77d5e1b  movaps [rcx], xmm14
00007b00b77d5e1f  mov rax, 0x612A23581A50
00007b00b77d5e29  call rax
00007b00b77d5e2b  movaps xmm12, [rsp]
00007b00b77d5e30  add rsp, 0x40
00007b00b77d5e34  vmovaps xmm0, [rsp]
00007b00b77d5e39  vmovaps xmm1, [rsp+0x10]
00007b00b77d5e3f  vmovaps xmm2, [rsp+0x20]
00007b00b77d5e45  vmovaps xmm3, [rsp+0x30]
00007b00b77d5e4b  vmovaps xmm4, [rsp+0x40]
00007b00b77d5e51  vmovaps xmm5, [rsp+0x50]
00007b00b77d5e57  vmovaps xmm6, [rsp+0x60]
00007b00b77d5e5d  vmovaps xmm7, [rsp+0x70]
00007b00b77d5e63  vmovaps xmm8, [rsp+0x80]
00007b00b77d5e6c  vmovaps xmm9, [rsp+0x90]
00007b00b77d5e75  vmovaps xmm10, [rsp+0xA0]
00007b00b77d5e7e  vmovaps xmm11, [rsp+0xB0]
00007b00b77d5e87  vmovaps xmm13, [rsp+0xC0]
00007b00b77d5e90  vmovaps xmm14, [rsp+0xD0]
00007b00b77d5e99  vmovaps xmm15, [rsp+0xE0]
00007b00b77d5ea2  add rsp, 0xF0
00007b00b77d5ea9  pop r11
00007b00b77d5eab  pop r10
00007b00b77d5ead  pop r9
00007b00b77d5eaf  pop r8
00007b00b77d5eb1  pop rsi
00007b00b77d5eb2  pop rdi
00007b00b77d5eb3  pop rdx
00007b00b77d5eb4  pop rcx
00007b00b77d5eb5  pop rax
00007b00b77d5eb6  add rsp, 0x08
00007b00b77d5eba  jmp 0x00007B00B77D3196
00007b00b77d5ebf  sub rsp, 0x08
00007b00b77d5ec3  push rax
00007b00b77d5ec4  push rcx
00007b00b77d5ec5  push rdx
00007b00b77d5ec6  push rdi
00007b00b77d5ec7  push rsi
00007b00b77d5ec8  push r8
00007b00b77d5eca  push r9
00007b00b77d5ecc  push r10
00007b00b77d5ece  push r11
00007b00b77d5ed0  sub rsp, 0xF0
00007b00b77d5ed7  vmovaps [rsp], xmm0
00007b00b77d5edc  vmovaps [rsp+0x10], xmm1
00007b00b77d5ee2  vmovaps [rsp+0x20], xmm2
00007b00b77d5ee8  vmovaps [rsp+0x30], xmm3
00007b00b77d5eee  vmovaps [rsp+0x40], xmm4
00007b00b77d5ef4  vmovaps [rsp+0x50], xmm5
00007b00b77d5efa  vmovaps [rsp+0x60], xmm6
00007b00b77d5f00  vmovaps [rsp+0x70], xmm7
00007b00b77d5f06  vmovaps [rsp+0x80], xmm8
00007b00b77d5f0f  vmovaps [rsp+0x90], xmm9
00007b00b77d5f18  vmovaps [rsp+0xA0], xmm10
00007b00b77d5f21  vmovaps [rsp+0xB0], xmm11
00007b00b77d5f2a  vmovaps [rsp+0xC0], xmm12
00007b00b77d5f33  vmovaps [rsp+0xD0], xmm13
00007b00b77d5f3c  vmovaps [rsp+0xE0], xmm15
00007b00b77d5f45  sub rsp, 0x40
00007b00b77d5f49  lea rdi, [rsp]
00007b00b77d5f4d  lea rsi, [rsp+0x10]
00007b00b77d5f52  lea rdx, [rsp+0x20]
00007b00b77d5f57  lea rcx, [rsp+0x30]
00007b00b77d5f5c  mov r8d, 0x00
00007b00b77d5f62  lea r9, [r15+0x3A8]
00007b00b77d5f69  movaps [rdi], xmm14
00007b00b77d5f6d  movaps [rsi], xmm13
00007b00b77d5f71  movaps [rdx], xmm1
00007b00b77d5f74  movaps [rcx], xmm15
00007b00b77d5f78  mov rax, 0x612A23581A50
00007b00b77d5f82  call rax
00007b00b77d5f84  movaps xmm14, [rsp]
00007b00b77d5f89  add rsp, 0x40
00007b00b77d5f8d  vmovaps xmm0, [rsp]
00007b00b77d5f92  vmovaps xmm1, [rsp+0x10]
00007b00b77d5f98  vmovaps xmm2, [rsp+0x20]
00007b00b77d5f9e  vmovaps xmm3, [rsp+0x30]
00007b00b77d5fa4  vmovaps xmm4, [rsp+0x40]
00007b00b77d5faa  vmovaps xmm5, [rsp+0x50]
00007b00b77d5fb0  vmovaps xmm6, [rsp+0x60]
00007b00b77d5fb6  vmovaps xmm7, [rsp+0x70]
00007b00b77d5fbc  vmovaps xmm8, [rsp+0x80]
00007b00b77d5fc5  vmovaps xmm9, [rsp+0x90]
00007b00b77d5fce  vmovaps xmm10, [rsp+0xA0]
00007b00b77d5fd7  vmovaps xmm11, [rsp+0xB0]
00007b00b77d5fe0  vmovaps xmm12, [rsp+0xC0]
00007b00b77d5fe9  vmovaps xmm13, [rsp+0xD0]
00007b00b77d5ff2  vmovaps xmm15, [rsp+0xE0]
00007b00b77d5ffb  add rsp, 0xF0
00007b00b77d6002  pop r11
00007b00b77d6004  pop r10
00007b00b77d6006  pop r9
00007b00b77d6008  pop r8
00007b00b77d600a  pop rsi
00007b00b77d600b  pop rdi
00007b00b77d600c  pop rdx
00007b00b77d600d  pop rcx
00007b00b77d600e  pop rax
00007b00b77d600f  add rsp, 0x08
00007b00b77d6013  jmp 0x00007B00B77D31C7
00007b00b77d6018  call 0x00007B00B76079B0
00007b00b77d601d  jmp 0x00007B00B77D31DA
00007b00b77d6022  call 0x00007B00B760B100
00007b00b77d6027  jmp 0x00007B00B77D31E5
00007b00b77d602c  call 0x00007B00B7609E90
00007b00b77d6031  jmp 0x00007B00B77D31F0
00007b00b77d6036  call 0x00007B00B760D600
00007b00b77d603b  jmp 0x00007B00B77D31FB
00007b00b77d6040  int3
00007b00b77d6041  nop [rax+rax*1], ax
00007b00b77d604a  nop [rax+rax*1], ax
00007b00b77d6050  mov rax, [r15+0x40]
00007b00b77d6054  mov r14, [r15+0x58]
00007b00b77d6058  lea r12, [rax+r14*1]
00007b00b77d605c  vxorps xmm1, xmm1, xmm1
00007b00b77d6060  vpbroadcastq xmm1, xmm1
00007b00b77d6065  vxorps xmm15, xmm15, xmm15
00007b00b77d606a  vpbroadcastq xmm15, xmm15
00007b00b77d606f  lea rax, [r12+0x30]
00007b00b77d6074  mov r11, [r13+rax*1]
00007b00b77d6079  lea rax, [r12+0x38]
00007b00b77d607e  mov r10, [r13+rax*1]
00007b00b77d6083  movq xmm14, r11
00007b00b77d6088  movq xmm13, r10
00007b00b77d608d  movq xmm14, xmm14
00007b00b77d6092  movq xmm13, xmm13
00007b00b77d6097  vmovaps [rsp+0x10], xmm13
00007b00b77d609d  movq xmm13, xmm13
00007b00b77d60a2  movaps [r15+0x270], xmm13
00007b00b77d60aa  movaps xmm13, [r15+0x160]
00007b00b77d60b2  vmovaps [rsp+0x20], xmm13
00007b00b77d60b8  vmovaps xmm12, [rsp+0x20]
00007b00b77d60be  por xmm13, xmm12
00007b00b77d60c3  lea rax, [r12+0x20]
00007b00b77d60c8  mov r11, [r13+rax*1]
00007b00b77d60cd  lea rax, [r12+0x28]
00007b00b77d60d2  mov r10, [r13+rax*1]
00007b00b77d60d7  movq xmm12, r11
00007b00b77d60dc  movq xmm11, r10
00007b00b77d60e1  movq xmm12, xmm12
00007b00b77d60e6  movq xmm11, xmm11
00007b00b77d60eb  movaps xmm10, [r15+0x2D0]
00007b00b77d60f3  vmovaps [rsp+0x20], xmm10
00007b00b77d60f9  vmovaps xmm9, [rsp+0x20]
00007b00b77d60ff  por xmm10, xmm9
00007b00b77d6104  movaps xmm9, [r15+0x300]
00007b00b77d610c  vmovaps [rsp+0x20], xmm9
00007b00b77d6112  vmovaps xmm8, [rsp+0x20]
00007b00b77d6118  por xmm9, xmm8
00007b00b77d611d  movaps xmm8, [r15+0x2B0]
00007b00b77d6125  vmovaps [rsp+0x20], xmm8
00007b00b77d612b  vmovaps xmm7, [rsp+0x20]
00007b00b77d6131  por xmm8, xmm7
00007b00b77d6136  movaps xmm7, [r15+0x180]
00007b00b77d613e  vmovaps [rsp+0x20], xmm7
00007b00b77d6144  vmovaps xmm6, [rsp+0x20]
00007b00b77d614a  por xmm7, xmm6
00007b00b77d614e  lea rax, [r12+0x10]
00007b00b77d6153  mov r11, [r13+rax*1]
00007b00b77d6158  lea rax, [r12+0x18]
00007b00b77d615d  mov r10, [r13+rax*1]
00007b00b77d6162  movq xmm6, r11
00007b00b77d6167  movq xmm5, r10
00007b00b77d616c  movq xmm6, xmm6
00007b00b77d6170  movq xmm5, xmm5
00007b00b77d6174  movaps xmm4, [r15+0x200]
00007b00b77d617c  vmovaps [rsp+0x20], xmm4
00007b00b77d6182  vmovaps xmm3, [rsp+0x20]
00007b00b77d6188  por xmm4, xmm3
00007b00b77d618c  movaps xmm3, [r15+0x1F0]
00007b00b77d6194  vmovaps [rsp+0x20], xmm3
00007b00b77d619a  vmovaps xmm2, [rsp+0x20]
00007b00b77d61a0  por xmm3, xmm2
00007b00b77d61a4  movaps xmm2, [r15+0x2E0]
00007b00b77d61ac  vmovaps [rsp+0x20], xmm2
00007b00b77d61b2  vmovaps [rsp+0x30], xmm1
00007b00b77d61b8  vmovaps xmm1, [rsp+0x20]
00007b00b77d61be  por xmm2, xmm1
00007b00b77d61c2  movaps xmm1, [r15+0x2A0]
00007b00b77d61ca  vmovaps [rsp+0x20], xmm1
00007b00b77d61d0  vmovaps [rsp+0x40], xmm15
00007b00b77d61d6  vmovaps xmm15, [rsp+0x20]
00007b00b77d61dc  por xmm1, xmm15
00007b00b77d61e1  movaps xmm15, [r15+0x280]
00007b00b77d61e9  vmovaps [rsp+0x20], xmm15
00007b00b77d61ef  vmovaps [rsp+0x50], xmm1
00007b00b77d61f5  vmovaps xmm1, [rsp+0x20]
00007b00b77d61fb  por xmm15, xmm1
00007b00b77d6200  movaps xmm1, [r15+0x1C0]
00007b00b77d6208  vmovaps [rsp+0x20], xmm1
00007b00b77d620e  vmovaps [rsp+0x60], xmm15
00007b00b77d6214  vmovaps xmm15, [rsp+0x20]
00007b00b77d621a  por xmm1, xmm15
00007b00b77d621f  movaps xmm15, [r15+0x210]
00007b00b77d6227  vmovaps [rsp+0x20], xmm15
00007b00b77d622d  vmovaps [rsp+0x70], xmm1
00007b00b77d6233  vmovaps xmm1, [rsp+0x20]
00007b00b77d6239  por xmm15, xmm1
00007b00b77d623e  mov rax, [r13+r12*1]
00007b00b77d6243  vmovq xmm1, rax
00007b00b77d6248  vpbroadcastq xmm1, xmm1
00007b00b77d624d  vmovaps [rsp+0x20], xmm1
00007b00b77d6253  vxorps xmm1, xmm1, xmm1
00007b00b77d6257  vpbroadcastq xmm1, xmm1
00007b00b77d625c  mov rax, [r15+0xF8]
00007b00b77d6263  vmovaps [rsp+0x80], xmm1
00007b00b77d626c  movups xmm1, [r13+rax*1]
00007b00b77d6272  vmovaps [rsp+0x90], xmm1
00007b00b77d627b  vxorps xmm1, xmm1, xmm1
00007b00b77d627f  vpbroadcastq xmm1, xmm1
00007b00b77d6284  lea r11, [r12+0x08]
00007b00b77d6289  mov r12, [r13+r11*1]
00007b00b77d628e  vmovaps [rsp+0xA0], xmm1
00007b00b77d6297  movq xmm1, r12
00007b00b77d629c  movaps [r15+0x240], xmm1
00007b00b77d62a4  mov r12, [r15+0x50]
00007b00b77d62a8  lea r11, [r12+r14*1]
00007b00b77d62ac  mov [r15+0x60], r11
00007b00b77d62b0  lea r12, [r14+0x40]
00007b00b77d62b4  mov [r15+0x58], r12
00007b00b77d62b8  vmovaps xmm1, [rsp+0x30]
00007b00b77d62be  vmovaps [rsp+0x30], xmm15
00007b00b77d62c4  vmovaps xmm15, [rsp+0x90]
00007b00b77d62cd  vmovaps [rsp+0x90], xmm14
00007b00b77d62d6  vmovaps xmm14, [rsp+0x20]
00007b00b77d62dc  vmovaps [rsp+0x20], xmm13
00007b00b77d62e2  vmovaps [rsp+0xB0], xmm12
00007b00b77d62eb  movaps xmm13, xmm1
00007b00b77d62ef  vfmadd231pd xmm13, xmm15, xmm14
00007b00b77d62f4  vcmppd xmm12, xmm13, xmm13, 0x03
00007b00b77d62fa  vptest xmm12, xmm12
00007b00b77d62ff  jnz 0x00007B00B77D6D9C
00007b00b77d6305  movaps xmm1, [r15+0x250]
00007b00b77d630d  vmovaps xmm15, [rsp+0x40]
00007b00b77d6313  vmovaps [rsp+0x40], xmm13
00007b00b77d6319  movaps xmm12, xmm15
00007b00b77d631d  vfmadd231pd xmm12, xmm1, xmm14
00007b00b77d6322  vcmppd xmm13, xmm12, xmm12, 0x03
00007b00b77d6328  vptest xmm13, xmm13
00007b00b77d632d  jnz 0x00007B00B77D6EF5
00007b00b77d6333  movaps xmm15, [r15+0x1E0]
00007b00b77d633b  vmovaps [rsp+0xC0], xmm15
00007b00b77d6344  vmovaps xmm13, [rsp+0xC0]
00007b00b77d634d  por xmm15, xmm13
00007b00b77d6352  movaps xmm13, [r15+0x1D0]
00007b00b77d635a  vmovaps [rsp+0xC0], xmm13
00007b00b77d6363  vmovaps [rsp+0xD0], xmm1
00007b00b77d636c  vmovaps xmm1, [rsp+0xC0]
00007b00b77d6375  por xmm13, xmm1
00007b00b77d637a  movaps xmm1, [r15+0x2C0]
00007b00b77d6382  vmovaps [rsp+0xC0], xmm1
00007b00b77d638b  vmovaps [rsp+0xE0], xmm15
00007b00b77d6394  vmovaps xmm15, [rsp+0xC0]
00007b00b77d639d  por xmm1, xmm15
00007b00b77d63a2  movaps xmm15, [r15+0x290]
00007b00b77d63aa  vmovaps [rsp+0xC0], xmm15
00007b00b77d63b3  vmovaps [rsp+0xF0], xmm1
00007b00b77d63bc  vmovaps xmm1, [rsp+0xC0]
00007b00b77d63c5  por xmm15, xmm1
00007b00b77d63ca  movaps xmm1, [r15+0x260]
00007b00b77d63d2  vmovaps [rsp+0xC0], xmm1
00007b00b77d63db  vmovaps [rsp+0x100], xmm15
00007b00b77d63e4  vmovaps xmm15, [rsp+0xC0]
00007b00b77d63ed  por xmm1, xmm15
00007b00b77d63f2  vmovaps xmm15, [rsp+0xD0]
00007b00b77d63fb  vmovaps [rsp+0xC0], xmm1
00007b00b77d6404  vmovaps xmm1, [rsp+0xD0]
00007b00b77d640d  por xmm15, xmm1
00007b00b77d6412  lea r14, [rax+0xC0]
00007b00b77d6419  movups xmm1, [r13+r14*1]
00007b00b77d641f  mov [rsp+0xD0], rax
00007b00b77d6427  xor eax, eax
00007b00b77d6429  mov r14d, 0x200
00007b00b77d642f  cmp r12, r14
00007b00b77d6432  cmc
00007b00b77d6433  lahf
00007b00b77d6434  seto al
00007b00b77d6437  mov [r15+0x108], eax
00007b00b77d643e  vmovaps [rsp+0x110], xmm1
00007b00b77d6447  vmovaps xmm1, [rsp+0x80]
00007b00b77d6450  vmovaps [rsp+0x80], xmm15
00007b00b77d6459  vmovaps xmm15, [rsp+0x110]
00007b00b77d6462  vmovaps [rsp+0x110], xmm13
00007b00b77d646b  vmovaps [rsp+0x120], xmm12
00007b00b77d6474  movaps xmm13, xmm1
00007b00b77d6478  vfmadd231pd xmm13, xmm15, xmm14
00007b00b77d647d  vcmppd xmm12, xmm13, xmm13, 0x03
00007b00b77d6483  vptest xmm12, xmm12
00007b00b77d6488  jnz 0x00007B00B77D7058
00007b00b77d648e  mov rax, [rsp+0xD0]
00007b00b77d6496  lea r14, [rax+0xB0]
00007b00b77d649d  movups xmm1, [r13+r14*1]
00007b00b77d64a3  vmovaps xmm15, [rsp+0xA0]
00007b00b77d64ac  vmovaps [rsp+0xA0], xmm13
00007b00b77d64b5  movaps xmm12, xmm15
00007b00b77d64b9  vfmadd231pd xmm12, xmm1, xmm14
00007b00b77d64be  vcmppd xmm13, xmm12, xmm12, 0x03
00007b00b77d64c4  vptest xmm13, xmm13
00007b00b77d64c9  jnz 0x00007B00B77D71BB
00007b00b77d64cf  vmovaps xmm1, [rsp+0x30]
00007b00b77d64d5  vmovaps xmm15, [rsp+0x30]
00007b00b77d64db  por xmm1, xmm15
00007b00b77d64e0  movaps [r15+0x210], xmm1
00007b00b77d64e8  vmovaps xmm15, [rsp+0x70]
00007b00b77d64ee  vmovaps xmm14, [rsp+0x70]
00007b00b77d64f4  por xmm15, xmm14
00007b00b77d64f9  movaps [r15+0x1C0], xmm15
00007b00b77d6501  vmovaps xmm14, [rsp+0x60]
00007b00b77d6507  vmovaps xmm13, [rsp+0x60]
00007b00b77d650d  por xmm14, xmm13
00007b00b77d6512  movaps [r15+0x280], xmm14
00007b00b77d651a  vmovaps xmm13, [rsp+0x50]
00007b00b77d6520  vmovaps [rsp+0x30], xmm1
00007b00b77d6526  vmovaps xmm1, [rsp+0x50]
00007b00b77d652c  por xmm13, xmm1
00007b00b77d6531  movaps [r15+0x2A0], xmm13
00007b00b77d6539  vmovaps [rsp+0x50], xmm2
00007b00b77d653f  vmovaps xmm1, [rsp+0x50]
00007b00b77d6545  por xmm2, xmm1
00007b00b77d6549  movaps [r15+0x2E0], xmm2
00007b00b77d6551  vmovaps [rsp+0x50], xmm3
00007b00b77d6557  vmovaps xmm1, [rsp+0x50]
00007b00b77d655d  por xmm3, xmm1
00007b00b77d6561  movaps [r15+0x1F0], xmm3
00007b00b77d6569  vmovaps xmm1, [rsp+0x80]
00007b00b77d6572  vmovaps [rsp+0x50], xmm15
00007b00b77d6578  vmovaps xmm15, [rsp+0x80]
00007b00b77d6581  por xmm1, xmm15
00007b00b77d6586  movaps [r15+0x250], xmm1
00007b00b77d658e  vmovaps xmm1, [rsp+0xC0]
00007b00b77d6597  vmovaps xmm15, [rsp+0xC0]
00007b00b77d65a0  por xmm1, xmm15
00007b00b77d65a5  movaps [r15+0x260], xmm1
00007b00b77d65ad  vmovaps xmm15, [rsp+0x100]
00007b00b77d65b6  vmovaps [rsp+0x60], xmm1
00007b00b77d65bc  vmovaps xmm1, [rsp+0x100]
00007b00b77d65c5  por xmm15, xmm1
00007b00b77d65ca  movaps [r15+0x290], xmm15
00007b00b77d65d2  vmovaps xmm1, [rsp+0xF0]
00007b00b77d65db  vmovaps [rsp+0x70], xmm15
00007b00b77d65e1  vmovaps xmm15, [rsp+0xF0]
00007b00b77d65ea  por xmm1, xmm15
00007b00b77d65ef  movaps [r15+0x2C0], xmm1
00007b00b77d65f7  movq xmm15, qword ptr [r15+0x240]
00007b00b77d6600  vmovaps [rsp+0x80], xmm15
00007b00b77d6609  vpermilpd xmm15, xmm15, 0x00
00007b00b77d660f  vmovaps [rsp+0xC0], xmm1
00007b00b77d6618  vmovaps xmm1, [rsp+0x40]
00007b00b77d661e  vmovaps [rsp+0x40], xmm15
00007b00b77d6624  vmovaps xmm15, [rsp+0x30]
00007b00b77d662a  vmovaps [rsp+0x30], xmm14
00007b00b77d6630  vmovaps xmm14, [rsp+0x40]
00007b00b77d6636  vmovaps [rsp+0x40], xmm13
00007b00b77d663c  vmovaps [rsp+0xD0], xmm12
00007b00b77d6645  movaps xmm13, xmm1
00007b00b77d6649  vfmadd231pd xmm13, xmm15, xmm14
00007b00b77d664e  vcmppd xmm12, xmm13, xmm13, 0x03
00007b00b77d6654  vptest xmm12, xmm12
00007b00b77d6659  jnz 0x00007B00B77D7314
00007b00b77d665f  vmovaps xmm1, [rsp+0x80]
00007b00b77d6668  vpermilpd xmm1, xmm1, 0x00
00007b00b77d666e  vmovaps xmm15, [rsp+0xA0]
00007b00b77d6677  movaps xmm14, xmm15
00007b00b77d667b  vfmadd231pd xmm14, xmm2, xmm1
00007b00b77d6680  vcmppd xmm12, xmm14, xmm14, 0x03
00007b00b77d6686  vptest xmm12, xmm12
00007b00b77d668b  jnz 0x00007B00B77D746D
00007b00b77d6691  vmovaps xmm1, [rsp+0x80]
00007b00b77d669a  vpermilpd xmm1, xmm1, 0x00
00007b00b77d66a0  vmovaps xmm15, [rsp+0x120]
00007b00b77d66a9  vmovaps xmm12, [rsp+0x50]
00007b00b77d66af  vmovaps [rsp+0x50], xmm14
00007b00b77d66b5  movaps xmm2, xmm15
00007b00b77d66b9  vfmadd231pd xmm2, xmm12, xmm1
00007b00b77d66be  vcmppd xmm14, xmm2, xmm2, 0x03
00007b00b77d66c3  vptest xmm14, xmm14
00007b00b77d66c8  jnz 0x00007B00B77D75C5
00007b00b77d66ce  vmovaps xmm1, [rsp+0x110]
00007b00b77d66d7  vmovaps xmm15, [rsp+0x110]
00007b00b77d66e0  por xmm1, xmm15
00007b00b77d66e5  movaps [r15+0x1D0], xmm1
00007b00b77d66ed  vmovaps xmm15, [rsp+0x80]
00007b00b77d66f6  vpermilpd xmm15, xmm15, 0x00
00007b00b77d66fc  vmovaps xmm14, [rsp+0xD0]
00007b00b77d6705  vmovaps [rsp+0x80], xmm1
00007b00b77d670e  movaps xmm12, xmm14
00007b00b77d6712  vfmadd231pd xmm12, xmm3, xmm15
00007b00b77d6717  vcmppd xmm1, xmm12, xmm12, 0x03
00007b00b77d671d  vptest xmm1, xmm1
00007b00b77d6722  jnz 0x00007B00B77D771C
00007b00b77d6728  vmovaps [rsp+0xA0], xmm4
00007b00b77d6731  vmovaps xmm1, [rsp+0xA0]
00007b00b77d673a  por xmm4, xmm1
00007b00b77d673e  movaps [r15+0x200], xmm4
00007b00b77d6746  vmovaps xmm1, [rsp+0xE0]
00007b00b77d674f  vmovaps xmm15, [rsp+0xE0]
00007b00b77d6758  por xmm1, xmm15
00007b00b77d675d  movaps [r15+0x1E0], xmm1
00007b00b77d6765  vmovaps [rsp+0xA0], xmm8
00007b00b77d676e  vmovaps xmm1, [rsp+0xA0]
00007b00b77d6777  por xmm8, xmm1
00007b00b77d677c  movaps [r15+0x2B0], xmm8
00007b00b77d6784  vmovaps [rsp+0xA0], xmm9
00007b00b77d678d  vmovaps xmm1, [rsp+0xA0]
00007b00b77d6796  por xmm9, xmm1
00007b00b77d679b  movaps [r15+0x300], xmm9
00007b00b77d67a3  vmovaps [rsp+0xA0], xmm6
00007b00b77d67ac  vpermilpd xmm6, xmm6, 0x00
00007b00b77d67b2  vmovaps xmm14, [rsp+0x60]
00007b00b77d67b8  movaps xmm9, xmm13
00007b00b77d67bc  vfmadd231pd xmm9, xmm14, xmm6
00007b00b77d67c1  vcmppd xmm3, xmm9, xmm9, 0x03
00007b00b77d67c7  vptest xmm3, xmm3
00007b00b77d67cc  jnz 0x00007B00B77D7875
00007b00b77d67d2  vmovaps xmm14, [rsp+0xA0]
00007b00b77d67db  vpermilpd xmm14, xmm14, 0x00
00007b00b77d67e1  vmovaps xmm13, [rsp+0x50]
00007b00b77d67e7  vmovaps xmm6, [rsp+0xC0]
00007b00b77d67f0  vmovaps [rsp+0x50], xmm1
00007b00b77d67f6  movaps xmm3, xmm13
00007b00b77d67fa  vfmadd231pd xmm3, xmm6, xmm14
00007b00b77d67ff  vcmppd xmm1, xmm3, xmm3, 0x03
00007b00b77d6804  vptest xmm1, xmm1
00007b00b77d6809  jnz 0x00007B00B77D79CE
00007b00b77d680f  vmovaps xmm1, [rsp+0xA0]
00007b00b77d6818  vpermilpd xmm1, xmm1, 0x00
00007b00b77d681e  vmovaps xmm14, [rsp+0x30]
00007b00b77d6824  movaps xmm6, xmm2
00007b00b77d6827  vfmadd231pd xmm6, xmm14, xmm1
00007b00b77d682c  vcmppd xmm13, xmm6, xmm6, 0x03
00007b00b77d6831  vptest xmm13, xmm13
00007b00b77d6836  jnz 0x00007B00B77D7B25
00007b00b77d683c  vmovaps xmm1, [rsp+0xA0]
00007b00b77d6845  vpermilpd xmm1, xmm1, 0x00
00007b00b77d684b  vmovaps xmm14, [rsp+0x80]
00007b00b77d6854  movaps xmm13, xmm12
00007b00b77d6858  vfmadd231pd xmm13, xmm14, xmm1
00007b00b77d685d  vcmppd xmm2, xmm13, xmm13, 0x03
00007b00b77d6863  vptest xmm2, xmm2
00007b00b77d6868  jnz 0x00007B00B77D7C7B
00007b00b77d686e  vmovaps [rsp+0x30], xmm7
00007b00b77d6874  vmovaps xmm1, [rsp+0x30]
00007b00b77d687a  por xmm7, xmm1
00007b00b77d687e  movaps [r15+0x180], xmm7
00007b00b77d6886  vmovaps [rsp+0x30], xmm10
00007b00b77d688c  vmovaps xmm1, [rsp+0x30]
00007b00b77d6892  por xmm10, xmm1
00007b00b77d6897  movaps [r15+0x2D0], xmm10
00007b00b77d689f  vmovaps [rsp+0x30], xmm5
00007b00b77d68a5  vpermilpd xmm5, xmm5, 0x00
00007b00b77d68ab  vmovaps xmm14, [rsp+0x50]
00007b00b77d68b1  movaps xmm12, xmm3
00007b00b77d68b5  vfmadd231pd xmm12, xmm14, xmm5
00007b00b77d68ba  vcmppd xmm10, xmm12, xmm12, 0x03
00007b00b77d68c0  vptest xmm10, xmm10
00007b00b77d68c5  jnz 0x00007B00B77D7DD4
00007b00b77d68cb  vmovaps xmm14, [rsp+0x30]
00007b00b77d68d1  vpermilpd xmm14, xmm14, 0x00
00007b00b77d68d7  movaps xmm10, xmm9
00007b00b77d68db  vfmadd231pd xmm10, xmm7, xmm14
00007b00b77d68e0  vcmppd xmm5, xmm10, xmm10, 0x03
00007b00b77d68e6  vptest xmm5, xmm5
00007b00b77d68eb  jnz 0x00007B00B77D7F2C
00007b00b77d68f1  lea r14, [rax+0x80]
00007b00b77d68f8  movups xmm14, [r13+r14*1]
00007b00b77d68fe  movaps [r15+0x2F0], xmm14
00007b00b77d6906  vmovaps xmm9, [rsp+0x30]
00007b00b77d690c  vpermilpd xmm9, xmm9, 0x00
00007b00b77d6912  vmovaps xmm7, [rsp+0x70]
00007b00b77d6918  movaps xmm5, xmm6
00007b00b77d691b  vfmadd231pd xmm5, xmm7, xmm9
00007b00b77d6920  vcmppd xmm3, xmm5, xmm5, 0x03
00007b00b77d6925  vptest xmm3, xmm3
00007b00b77d692a  jnz 0x00007B00B77D808F
00007b00b77d6930  vmovaps xmm9, [rsp+0x30]
00007b00b77d6936  vpermilpd xmm9, xmm9, 0x00
00007b00b77d693c  movaps xmm7, xmm13
00007b00b77d6940  vfmadd231pd xmm7, xmm1, xmm9
00007b00b77d6945  vcmppd xmm6, xmm7, xmm7, 0x03
00007b00b77d694a  vptest xmm6, xmm6
00007b00b77d694f  jnz 0x00007B00B77D81E5
00007b00b77d6955  vmovaps xmm1, [rsp+0x20]
00007b00b77d695b  vmovaps xmm13, [rsp+0x20]
00007b00b77d6961  por xmm1, xmm13
00007b00b77d6966  movaps [r15+0x160], xmm1
00007b00b77d696e  lea r14, [rax+0x40]
00007b00b77d6972  movups xmm13, [r13+r14*1]
00007b00b77d6978  lea r14, [rax+0x50]
00007b00b77d697c  movups xmm9, [r13+r14*1]
00007b00b77d6982  movaps [r15+0x1B0], xmm13
00007b00b77d698a  movaps [r15+0x1A0], xmm9
00007b00b77d6992  movaps xmm6, [r15+0x190]
00007b00b77d699a  vmovaps xmm3, [rsp+0xB0]
00007b00b77d69a3  vpermilpd xmm3, xmm3, 0x00
00007b00b77d69a9  vmovaps [rsp+0x20], xmm1
00007b00b77d69af  movaps xmm2, xmm12
00007b00b77d69b3  vfmadd231pd xmm2, xmm6, xmm3
00007b00b77d69b8  vcmppd xmm1, xmm2, xmm2, 0x03
00007b00b77d69bd  vptest xmm1, xmm1
00007b00b77d69c2  jnz 0x00007B00B77D8350
00007b00b77d69c8  vmovaps xmm1, [rsp+0xB0]
00007b00b77d69d1  vpermilpd xmm1, xmm1, 0x00
00007b00b77d69d7  vmovaps xmm12, [rsp+0x20]
00007b00b77d69dd  movaps xmm6, xmm10
00007b00b77d69e1  vfmadd231pd xmm6, xmm12, xmm1
00007b00b77d69e6  vcmppd xmm3, xmm6, xmm6, 0x03
00007b00b77d69eb  vptest xmm3, xmm3
00007b00b77d69f0  jnz 0x00007B00B77D84A6
00007b00b77d69f6  vmovaps xmm1, [rsp+0xB0]
00007b00b77d69ff  vpermilpd xmm1, xmm1, 0x00
00007b00b77d6a05  vmovaps xmm12, [rsp+0x40]
00007b00b77d6a0b  movaps xmm10, xmm5
00007b00b77d6a0f  vfmadd231pd xmm10, xmm12, xmm1
00007b00b77d6a14  vcmppd xmm3, xmm10, xmm10, 0x03
00007b00b77d6a1a  vptest xmm3, xmm3
00007b00b77d6a1f  jnz 0x00007B00B77D85FD
00007b00b77d6a25  vmovaps xmm1, [rsp+0xB0]
00007b00b77d6a2e  vpermilpd xmm1, xmm1, 0x00
00007b00b77d6a34  movaps xmm12, xmm7
00007b00b77d6a38  vfmadd231pd xmm12, xmm15, xmm1
00007b00b77d6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
00007b00b77d6a43  vptest xmm5, xmm5
00007b00b77d6a48  jnz 0x00007B00B77D8755
00007b00b77d6a4e  lea r14, [rax+0x60]
00007b00b77d6a52  movups xmm1, [r13+r14*1]
00007b00b77d6a58  lea r14, [rax+0x70]
00007b00b77d6a5c  movups xmm15, [r13+r14*1]
00007b00b77d6a62  movaps [r15+0x150], xmm1
00007b00b77d6a6a  movaps [r15+0x120], xmm15
00007b00b77d6a72  vmovaps [rsp+0x20], xmm11
00007b00b77d6a78  vpermilpd xmm11, xmm11, 0x00
00007b00b77d6a7e  movaps xmm7, xmm2
00007b00b77d6a81  vfmadd231pd xmm7, xmm9, xmm11
00007b00b77d6a86  vcmppd xmm5, xmm7, xmm7, 0x03
00007b00b77d6a8b  vptest xmm5, xmm5
00007b00b77d6a90  jnz 0x00007B00B77D88C1
00007b00b77d6a96  vmovaps xmm11, [rsp+0x20]
00007b00b77d6a9c  vpermilpd xmm11, xmm11, 0x00
00007b00b77d6aa2  movaps xmm9, xmm6
00007b00b77d6aa6  vfmadd231pd xmm9, xmm1, xmm11
00007b00b77d6aab  vcmppd xmm5, xmm9, xmm9, 0x03
00007b00b77d6ab1  vptest xmm5, xmm5
00007b00b77d6ab6  jnz 0x00007B00B77D8A18
00007b00b77d6abc  vmovaps xmm1, [rsp+0x20]
00007b00b77d6ac2  vpermilpd xmm1, xmm1, 0x00
00007b00b77d6ac8  movaps xmm11, xmm10
00007b00b77d6acc  vfmadd231pd xmm11, xmm8, xmm1
00007b00b77d6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
00007b00b77d6ad7  vptest xmm6, xmm6
00007b00b77d6adc  jnz 0x00007B00B77D8B70
00007b00b77d6ae2  vmovaps xmm1, [rsp+0x20]
00007b00b77d6ae8  vpermilpd xmm1, xmm1, 0x00
00007b00b77d6aee  movaps xmm10, xmm12
00007b00b77d6af2  vfmadd231pd xmm10, xmm13, xmm1
00007b00b77d6af7  vcmppd xmm8, xmm10, xmm10, 0x03
00007b00b77d6afd  vptest xmm8, xmm8
00007b00b77d6b02  jnz 0x00007B00B77D8CC9
00007b00b77d6b08  lea r14, [rax+0x20]
00007b00b77d6b0c  movups xmm1, [r13+r14*1]
00007b00b77d6b12  lea r14, [rax+0x30]
00007b00b77d6b16  movups xmm13, [r13+r14*1]
00007b00b77d6b1c  vmovaps xmm12, [rsp+0x90]
00007b00b77d6b25  vpermilpd xmm12, xmm12, 0x00
00007b00b77d6b2b  movaps xmm8, xmm7
00007b00b77d6b2f  vfmadd231pd xmm8, xmm4, xmm12
00007b00b77d6b34  vcmppd xmm6, xmm8, xmm8, 0x03
00007b00b77d6b3a  vptest xmm6, xmm6
00007b00b77d6b3f  jnz 0x00007B00B77D8E36
00007b00b77d6b45  vmovaps xmm12, [rsp+0x90]
00007b00b77d6b4e  vpermilpd xmm12, xmm12, 0x00
00007b00b77d6b54  movaps xmm7, xmm9
00007b00b77d6b58  vfmadd231pd xmm7, xmm14, xmm12
00007b00b77d6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
00007b00b77d6b62  vptest xmm6, xmm6
00007b00b77d6b67  jnz 0x00007B00B77D8F8E
00007b00b77d6b6d  vmovaps xmm14, [rsp+0x90]
00007b00b77d6b76  vpermilpd xmm14, xmm14, 0x00
00007b00b77d6b7c  movaps xmm12, xmm11
00007b00b77d6b80  vfmadd231pd xmm12, xmm15, xmm14
00007b00b77d6b85  vcmppd xmm9, xmm12, xmm12, 0x03
00007b00b77d6b8b  vptest xmm9, xmm9
00007b00b77d6b90  jnz 0x00007B00B77D90E6
00007b00b77d6b96  vmovaps xmm15, [rsp+0x90]
00007b00b77d6b9f  vpermilpd xmm15, xmm15, 0x00
00007b00b77d6ba5  movaps xmm11, xmm10
00007b00b77d6ba9  vfmadd231pd xmm11, xmm13, xmm15
00007b00b77d6bae  vcmppd xmm14, xmm11, xmm11, 0x03
00007b00b77d6bb4  vptest xmm14, xmm14
00007b00b77d6bb9  jnz 0x00007B00B77D9240
00007b00b77d6bbf  lea r14, [rax+0x90]
00007b00b77d6bc6  movups xmm15, [r13+r14*1]
00007b00b77d6bcc  lea r14, [rax+0xA0]
00007b00b77d6bd3  movups xmm14, [r13+r14*1]
00007b00b77d6bd9  movaps [r15+0x140], xmm15
00007b00b77d6be1  movaps [r15+0x130], xmm14
00007b00b77d6be9  vmovaps xmm13, [rsp+0x10]
00007b00b77d6bef  vpermilpd xmm13, xmm13, 0x00
00007b00b77d6bf5  movaps xmm10, xmm8
00007b00b77d6bf9  vfmadd231pd xmm10, xmm1, xmm13
00007b00b77d6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
00007b00b77d6c04  vptest xmm9, xmm9
00007b00b77d6c09  jnz 0x00007B00B77D93AE
00007b00b77d6c0f  movaps [r15+0x220], xmm10
00007b00b77d6c17  lea r14, [rax+0x10]
00007b00b77d6c1b  movups xmm1, [r13+r14*1]
00007b00b77d6c21  movaps [r15+0x240], xmm1
00007b00b77d6c29  vmovaps xmm13, [rsp+0x10]
00007b00b77d6c2f  vpermilpd xmm13, xmm13, 0x00
00007b00b77d6c35  movaps xmm9, xmm7
00007b00b77d6c39  vfmadd231pd xmm9, xmm14, xmm13
00007b00b77d6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
00007b00b77d6c44  vptest xmm8, xmm8
00007b00b77d6c49  jnz 0x00007B00B77D9511
00007b00b77d6c4f  movaps [r15+0x110], xmm9
00007b00b77d6c57  vmovaps xmm14, [rsp+0x10]
00007b00b77d6c5d  vpermilpd xmm14, xmm14, 0x00
00007b00b77d6c63  movaps xmm13, xmm12
00007b00b77d6c67  vfmadd231pd xmm13, xmm15, xmm14
00007b00b77d6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
00007b00b77d6c72  vptest xmm8, xmm8
00007b00b77d6c77  jnz 0x00007B00B77D966A
00007b00b77d6c7d  movaps [r15+0x170], xmm13
00007b00b77d6c85  vmovaps xmm15, [rsp+0x10]
00007b00b77d6c8b  vpermilpd xmm15, xmm15, 0x00
00007b00b77d6c91  movaps xmm14, xmm11
00007b00b77d6c95  vfmadd231pd xmm14, xmm1, xmm15
00007b00b77d6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
00007b00b77d6ca0  vptest xmm12, xmm12
00007b00b77d6ca5  jnz 0x00007B00B77D97C4
00007b00b77d6cab  movaps [r15+0x230], xmm14
00007b00b77d6cb3  movups [r13+r11*1], xmm9
00007b00b77d6cb9  lea rax, [r11+0x10]
00007b00b77d6cbd  movups [r13+rax*1], xmm13
00007b00b77d6cc3  lea rax, [r11+0x20]
00007b00b77d6cc7  movups [r13+rax*1], xmm10
00007b00b77d6ccd  lea rax, [r11+0x30]
00007b00b77d6cd1  movups [r13+rax*1], xmm14
00007b00b77d6cd7  mov eax, [r15+0x108]
00007b00b77d6cde  sahf
00007b00b77d6cdf  jnz 0x00007B00B77D6D11
00007b00b77d6ce1  cmp dword ptr [r15+0x318], 0x00
00007b00b77d6ce9  jz 0x00007B00B77D9950
00007b00b77d6cef  nop [rax+rax*1], ax
00007b00b77d6cf8  nop [rax+rax*1], eax
00007b00b77d6d00  mov eax, 0x410664
00007b00b77d6d05  mov [r15+0x100], rax
00007b00b77d6d0c  jmp 0x00007B00B75FE110
00007b00b77d6d11  cmp dword ptr [r15+0x318], 0x00
00007b00b77d6d19  jz 0x00007B00B77D6050
00007b00b77d6d1f  nop [rax+rax*1], ax
00007b00b77d6d28  nop [rax+rax*1], eax
00007b00b77d6d30  mov eax, 0x4104F0
00007b00b77d6d35  mov [r15+0x100], rax
00007b00b77d6d3c  jmp 0x00007B00B75FE110
00007b00b77d6d41  int3
00007b00b77d6d42  call 0x00007B00B760A4B0
00007b00b77d6d47  jmp 0x00007B00B77D6079
00007b00b77d6d4c  call 0x00007B00B7609240
00007b00b77d6d51  jmp 0x00007B00B77D6083
00007b00b77d6d56  call 0x00007B00B760A4B0
00007b00b77d6d5b  jmp 0x00007B00B77D60CD
00007b00b77d6d60  call 0x00007B00B7609240
00007b00b77d6d65  jmp 0x00007B00B77D60D7
00007b00b77d6d6a  call 0x00007B00B760A4B0
00007b00b77d6d6f  jmp 0x00007B00B77D6158
00007b00b77d6d74  call 0x00007B00B7609240
00007b00b77d6d79  jmp 0x00007B00B77D6162
00007b00b77d6d7e  call 0x00007B00B76B47C0
00007b00b77d6d83  jmp 0x00007B00B77D6243
00007b00b77d6d88  call 0x00007B00B75FF430
00007b00b77d6d8d  jmp 0x00007B00B77D6272
00007b00b77d6d92  call 0x00007B00B76B0CE0
00007b00b77d6d97  jmp 0x00007B00B77D628E
00007b00b77d6d9c  sub rsp, 0x08
00007b00b77d6da0  push rax
00007b00b77d6da1  push rcx
00007b00b77d6da2  push rdx
00007b00b77d6da3  push rdi
00007b00b77d6da4  push rsi
00007b00b77d6da5  push r8
00007b00b77d6da7  push r9
00007b00b77d6da9  push r10
00007b00b77d6dab  push r11
00007b00b77d6dad  sub rsp, 0xF0
00007b00b77d6db4  vmovaps [rsp], xmm0
00007b00b77d6db9  vmovaps [rsp+0x10], xmm1
00007b00b77d6dbf  vmovaps [rsp+0x20], xmm2
00007b00b77d6dc5  vmovaps [rsp+0x30], xmm3
00007b00b77d6dcb  vmovaps [rsp+0x40], xmm4
00007b00b77d6dd1  vmovaps [rsp+0x50], xmm5
00007b00b77d6dd7  vmovaps [rsp+0x60], xmm6
00007b00b77d6ddd  vmovaps [rsp+0x70], xmm7
00007b00b77d6de3  vmovaps [rsp+0x80], xmm8
00007b00b77d6dec  vmovaps [rsp+0x90], xmm9
00007b00b77d6df5  vmovaps [rsp+0xA0], xmm10
00007b00b77d6dfe  vmovaps [rsp+0xB0], xmm11
00007b00b77d6e07  vmovaps [rsp+0xC0], xmm12
00007b00b77d6e10  vmovaps [rsp+0xD0], xmm14
00007b00b77d6e19  vmovaps [rsp+0xE0], xmm15
00007b00b77d6e22  sub rsp, 0x40
00007b00b77d6e26  lea rdi, [rsp]
00007b00b77d6e2a  lea rsi, [rsp+0x10]
00007b00b77d6e2f  lea rdx, [rsp+0x20]
00007b00b77d6e34  lea rcx, [rsp+0x30]
00007b00b77d6e39  mov r8d, 0x00
00007b00b77d6e3f  lea r9, [r15+0x3A8]
00007b00b77d6e46  movaps [rdi], xmm13
00007b00b77d6e4a  movaps [rsi], xmm1
00007b00b77d6e4d  movaps [rdx], xmm15
00007b00b77d6e51  movaps [rcx], xmm14
00007b00b77d6e55  mov rax, 0x612A23581A50
00007b00b77d6e5f  call rax
00007b00b77d6e61  movaps xmm13, [rsp]
00007b00b77d6e66  add rsp, 0x40
00007b00b77d6e6a  vmovaps xmm0, [rsp]
00007b00b77d6e6f  vmovaps xmm1, [rsp+0x10]
00007b00b77d6e75  vmovaps xmm2, [rsp+0x20]
00007b00b77d6e7b  vmovaps xmm3, [rsp+0x30]
00007b00b77d6e81  vmovaps xmm4, [rsp+0x40]
00007b00b77d6e87  vmovaps xmm5, [rsp+0x50]
00007b00b77d6e8d  vmovaps xmm6, [rsp+0x60]
00007b00b77d6e93  vmovaps xmm7, [rsp+0x70]
00007b00b77d6e99  vmovaps xmm8, [rsp+0x80]
00007b00b77d6ea2  vmovaps xmm9, [rsp+0x90]
00007b00b77d6eab  vmovaps xmm10, [rsp+0xA0]
00007b00b77d6eb4  vmovaps xmm11, [rsp+0xB0]
00007b00b77d6ebd  vmovaps xmm12, [rsp+0xC0]
00007b00b77d6ec6  vmovaps xmm14, [rsp+0xD0]
00007b00b77d6ecf  vmovaps xmm15, [rsp+0xE0]
00007b00b77d6ed8  add rsp, 0xF0
00007b00b77d6edf  pop r11
00007b00b77d6ee1  pop r10
00007b00b77d6ee3  pop r9
00007b00b77d6ee5  pop r8
00007b00b77d6ee7  pop rsi
00007b00b77d6ee8  pop rdi
00007b00b77d6ee9  pop rdx
00007b00b77d6eea  pop rcx
00007b00b77d6eeb  pop rax
00007b00b77d6eec  add rsp, 0x08
00007b00b77d6ef0  jmp 0x00007B00B77D6305
00007b00b77d6ef5  sub rsp, 0x08
00007b00b77d6ef9  push rax
00007b00b77d6efa  push rcx
00007b00b77d6efb  push rdx
00007b00b77d6efc  push rdi
00007b00b77d6efd  push rsi
00007b00b77d6efe  push r8
00007b00b77d6f00  push r9
00007b00b77d6f02  push r10
00007b00b77d6f04  push r11
00007b00b77d6f06  sub rsp, 0xF0
00007b00b77d6f0d  vmovaps [rsp], xmm0
00007b00b77d6f12  vmovaps [rsp+0x10], xmm1
00007b00b77d6f18  vmovaps [rsp+0x20], xmm2
00007b00b77d6f1e  vmovaps [rsp+0x30], xmm3
00007b00b77d6f24  vmovaps [rsp+0x40], xmm4
00007b00b77d6f2a  vmovaps [rsp+0x50], xmm5
00007b00b77d6f30  vmovaps [rsp+0x60], xmm6
00007b00b77d6f36  vmovaps [rsp+0x70], xmm7
00007b00b77d6f3c  vmovaps [rsp+0x80], xmm8
00007b00b77d6f45  vmovaps [rsp+0x90], xmm9
00007b00b77d6f4e  vmovaps [rsp+0xA0], xmm10
00007b00b77d6f57  vmovaps [rsp+0xB0], xmm11
00007b00b77d6f60  vmovaps [rsp+0xC0], xmm13
00007b00b77d6f69  vmovaps [rsp+0xD0], xmm14
00007b00b77d6f72  vmovaps [rsp+0xE0], xmm15
00007b00b77d6f7b  sub rsp, 0x40
00007b00b77d6f7f  lea rdi, [rsp]
00007b00b77d6f83  lea rsi, [rsp+0x10]
00007b00b77d6f88  lea rdx, [rsp+0x20]
00007b00b77d6f8d  lea rcx, [rsp+0x30]
00007b00b77d6f92  mov r8d, 0x00
00007b00b77d6f98  lea r9, [r15+0x3A8]
00007b00b77d6f9f  movaps [rdi], xmm12
00007b00b77d6fa3  movaps [rsi], xmm15
00007b00b77d6fa7  movaps [rdx], xmm1
00007b00b77d6faa  movaps [rcx], xmm14
00007b00b77d6fae  mov rax, 0x612A23581A50
00007b00b77d6fb8  call rax
00007b00b77d6fba  movaps xmm12, [rsp]
00007b00b77d6fbf  add rsp, 0x40
00007b00b77d6fc3  vmovaps xmm0, [rsp]
00007b00b77d6fc8  vmovaps xmm1, [rsp+0x10]
00007b00b77d6fce  vmovaps xmm2, [rsp+0x20]
00007b00b77d6fd4  vmovaps xmm3, [rsp+0x30]
00007b00b77d6fda  vmovaps xmm4, [rsp+0x40]
00007b00b77d6fe0  vmovaps xmm5, [rsp+0x50]
00007b00b77d6fe6  vmovaps xmm6, [rsp+0x60]
00007b00b77d6fec  vmovaps xmm7, [rsp+0x70]
00007b00b77d6ff2  vmovaps xmm8, [rsp+0x80]
00007b00b77d6ffb  vmovaps xmm9, [rsp+0x90]
00007b00b77d7004  vmovaps xmm10, [rsp+0xA0]
00007b00b77d700d  vmovaps xmm11, [rsp+0xB0]
00007b00b77d7016  vmovaps xmm13, [rsp+0xC0]
00007b00b77d701f  vmovaps xmm14, [rsp+0xD0]
00007b00b77d7028  vmovaps xmm15, [rsp+0xE0]
00007b00b77d7031  add rsp, 0xF0
00007b00b77d7038  pop r11
00007b00b77d703a  pop r10
00007b00b77d703c  pop r9
00007b00b77d703e  pop r8
00007b00b77d7040  pop rsi
00007b00b77d7041  pop rdi
00007b00b77d7042  pop rdx
00007b00b77d7043  pop rcx
00007b00b77d7044  pop rax
00007b00b77d7045  add rsp, 0x08
00007b00b77d7049  jmp 0x00007B00B77D6333
00007b00b77d704e  call 0x00007B00B76D64F0
00007b00b77d7053  jmp 0x00007B00B77D641F
00007b00b77d7058  sub rsp, 0x08
00007b00b77d705c  push rax
00007b00b77d705d  push rcx
00007b00b77d705e  push rdx
00007b00b77d705f  push rdi
00007b00b77d7060  push rsi
00007b00b77d7061  push r8
00007b00b77d7063  push r9
00007b00b77d7065  push r10
00007b00b77d7067  push r11
00007b00b77d7069  sub rsp, 0xF0
00007b00b77d7070  vmovaps [rsp], xmm0
00007b00b77d7075  vmovaps [rsp+0x10], xmm1
00007b00b77d707b  vmovaps [rsp+0x20], xmm2
00007b00b77d7081  vmovaps [rsp+0x30], xmm3
00007b00b77d7087  vmovaps [rsp+0x40], xmm4
00007b00b77d708d  vmovaps [rsp+0x50], xmm5
00007b00b77d7093  vmovaps [rsp+0x60], xmm6
00007b00b77d7099  vmovaps [rsp+0x70], xmm7
00007b00b77d709f  vmovaps [rsp+0x80], xmm8
00007b00b77d70a8  vmovaps [rsp+0x90], xmm9
00007b00b77d70b1  vmovaps [rsp+0xA0], xmm10
00007b00b77d70ba  vmovaps [rsp+0xB0], xmm11
00007b00b77d70c3  vmovaps [rsp+0xC0], xmm12
00007b00b77d70cc  vmovaps [rsp+0xD0], xmm14
00007b00b77d70d5  vmovaps [rsp+0xE0], xmm15
00007b00b77d70de  sub rsp, 0x40
00007b00b77d70e2  lea rdi, [rsp]
00007b00b77d70e6  lea rsi, [rsp+0x10]
00007b00b77d70eb  lea rdx, [rsp+0x20]
00007b00b77d70f0  lea rcx, [rsp+0x30]
00007b00b77d70f5  mov r8d, 0x00
00007b00b77d70fb  lea r9, [r15+0x3A8]
00007b00b77d7102  movaps [rdi], xmm13
00007b00b77d7106  movaps [rsi], xmm1
00007b00b77d7109  movaps [rdx], xmm15
00007b00b77d710d  movaps [rcx], xmm14
00007b00b77d7111  mov rax, 0x612A23581A50
00007b00b77d711b  call rax
00007b00b77d711d  movaps xmm13, [rsp]
00007b00b77d7122  add rsp, 0x40
00007b00b77d7126  vmovaps xmm0, [rsp]
00007b00b77d712b  vmovaps xmm1, [rsp+0x10]
00007b00b77d7131  vmovaps xmm2, [rsp+0x20]
00007b00b77d7137  vmovaps xmm3, [rsp+0x30]
00007b00b77d713d  vmovaps xmm4, [rsp+0x40]
00007b00b77d7143  vmovaps xmm5, [rsp+0x50]
00007b00b77d7149  vmovaps xmm6, [rsp+0x60]
00007b00b77d714f  vmovaps xmm7, [rsp+0x70]
00007b00b77d7155  vmovaps xmm8, [rsp+0x80]
00007b00b77d715e  vmovaps xmm9, [rsp+0x90]
00007b00b77d7167  vmovaps xmm10, [rsp+0xA0]
00007b00b77d7170  vmovaps xmm11, [rsp+0xB0]
00007b00b77d7179  vmovaps xmm12, [rsp+0xC0]
00007b00b77d7182  vmovaps xmm14, [rsp+0xD0]
00007b00b77d718b  vmovaps xmm15, [rsp+0xE0]
00007b00b77d7194  add rsp, 0xF0
00007b00b77d719b  pop r11
00007b00b77d719d  pop r10
00007b00b77d719f  pop r9
00007b00b77d71a1  pop r8
00007b00b77d71a3  pop rsi
00007b00b77d71a4  pop rdi
00007b00b77d71a5  pop rdx
00007b00b77d71a6  pop rcx
00007b00b77d71a7  pop rax
00007b00b77d71a8  add rsp, 0x08
00007b00b77d71ac  jmp 0x00007B00B77D648E
00007b00b77d71b1  call 0x00007B00B76D64F0
00007b00b77d71b6  jmp 0x00007B00B77D64A3
00007b00b77d71bb  sub rsp, 0x08
00007b00b77d71bf  push rax
00007b00b77d71c0  push rcx
00007b00b77d71c1  push rdx
00007b00b77d71c2  push rdi
00007b00b77d71c3  push rsi
00007b00b77d71c4  push r8
00007b00b77d71c6  push r9
00007b00b77d71c8  push r10
00007b00b77d71ca  push r11
00007b00b77d71cc  sub rsp, 0xF0
00007b00b77d71d3  vmovaps [rsp], xmm0
00007b00b77d71d8  vmovaps [rsp+0x10], xmm1
00007b00b77d71de  vmovaps [rsp+0x20], xmm2
00007b00b77d71e4  vmovaps [rsp+0x30], xmm3
00007b00b77d71ea  vmovaps [rsp+0x40], xmm4
00007b00b77d71f0  vmovaps [rsp+0x50], xmm5
00007b00b77d71f6  vmovaps [rsp+0x60], xmm6
00007b00b77d71fc  vmovaps [rsp+0x70], xmm7
00007b00b77d7202  vmovaps [rsp+0x80], xmm8
00007b00b77d720b  vmovaps [rsp+0x90], xmm9
00007b00b77d7214  vmovaps [rsp+0xA0], xmm10
00007b00b77d721d  vmovaps [rsp+0xB0], xmm11
00007b00b77d7226  vmovaps [rsp+0xC0], xmm13
00007b00b77d722f  vmovaps [rsp+0xD0], xmm14
00007b00b77d7238  vmovaps [rsp+0xE0], xmm15
00007b00b77d7241  sub rsp, 0x40
00007b00b77d7245  lea rdi, [rsp]
00007b00b77d7249  lea rsi, [rsp+0x10]
00007b00b77d724e  lea rdx, [rsp+0x20]
00007b00b77d7253  lea rcx, [rsp+0x30]
00007b00b77d7258  mov r8d, 0x00
00007b00b77d725e  lea r9, [r15+0x3A8]
00007b00b77d7265  movaps [rdi], xmm12
00007b00b77d7269  movaps [rsi], xmm15
00007b00b77d726d  movaps [rdx], xmm1
00007b00b77d7270  movaps [rcx], xmm14
00007b00b77d7274  mov rax, 0x612A23581A50
00007b00b77d727e  call rax
00007b00b77d7280  movaps xmm12, [rsp]
00007b00b77d7285  add rsp, 0x40
00007b00b77d7289  vmovaps xmm0, [rsp]
00007b00b77d728e  vmovaps xmm1, [rsp+0x10]
00007b00b77d7294  vmovaps xmm2, [rsp+0x20]
00007b00b77d729a  vmovaps xmm3, [rsp+0x30]
00007b00b77d72a0  vmovaps xmm4, [rsp+0x40]
00007b00b77d72a6  vmovaps xmm5, [rsp+0x50]
00007b00b77d72ac  vmovaps xmm6, [rsp+0x60]
00007b00b77d72b2  vmovaps xmm7, [rsp+0x70]
00007b00b77d72b8  vmovaps xmm8, [rsp+0x80]
00007b00b77d72c1  vmovaps xmm9, [rsp+0x90]
00007b00b77d72ca  vmovaps xmm10, [rsp+0xA0]
00007b00b77d72d3  vmovaps xmm11, [rsp+0xB0]
00007b00b77d72dc  vmovaps xmm13, [rsp+0xC0]
00007b00b77d72e5  vmovaps xmm14, [rsp+0xD0]
00007b00b77d72ee  vmovaps xmm15, [rsp+0xE0]
00007b00b77d72f7  add rsp, 0xF0
00007b00b77d72fe  pop r11
00007b00b77d7300  pop r10
00007b00b77d7302  pop r9
00007b00b77d7304  pop r8
00007b00b77d7306  pop rsi
00007b00b77d7307  pop rdi
00007b00b77d7308  pop rdx
00007b00b77d7309  pop rcx
00007b00b77d730a  pop rax
00007b00b77d730b  add rsp, 0x08
00007b00b77d730f  jmp 0x00007B00B77D64CF
00007b00b77d7314  sub rsp, 0x08
00007b00b77d7318  push rax
00007b00b77d7319  push rcx
00007b00b77d731a  push rdx
00007b00b77d731b  push rdi
00007b00b77d731c  push rsi
00007b00b77d731d  push r8
00007b00b77d731f  push r9
00007b00b77d7321  push r10
00007b00b77d7323  push r11
00007b00b77d7325  sub rsp, 0xF0
00007b00b77d732c  vmovaps [rsp], xmm0
00007b00b77d7331  vmovaps [rsp+0x10], xmm1
00007b00b77d7337  vmovaps [rsp+0x20], xmm2
00007b00b77d733d  vmovaps [rsp+0x30], xmm3
00007b00b77d7343  vmovaps [rsp+0x40], xmm4
00007b00b77d7349  vmovaps [rsp+0x50], xmm5
00007b00b77d734f  vmovaps [rsp+0x60], xmm6
00007b00b77d7355  vmovaps [rsp+0x70], xmm7
00007b00b77d735b  vmovaps [rsp+0x80], xmm8
00007b00b77d7364  vmovaps [rsp+0x90], xmm9
00007b00b77d736d  vmovaps [rsp+0xA0], xmm10
00007b00b77d7376  vmovaps [rsp+0xB0], xmm11
00007b00b77d737f  vmovaps [rsp+0xC0], xmm12
00007b00b77d7388  vmovaps [rsp+0xD0], xmm14
00007b00b77d7391  vmovaps [rsp+0xE0], xmm15
00007b00b77d739a  sub rsp, 0x40
00007b00b77d739e  lea rdi, [rsp]
00007b00b77d73a2  lea rsi, [rsp+0x10]
00007b00b77d73a7  lea rdx, [rsp+0x20]
00007b00b77d73ac  lea rcx, [rsp+0x30]
00007b00b77d73b1  mov r8d, 0x00
00007b00b77d73b7  lea r9, [r15+0x3A8]
00007b00b77d73be  movaps [rdi], xmm13
00007b00b77d73c2  movaps [rsi], xmm1
00007b00b77d73c5  movaps [rdx], xmm15
00007b00b77d73c9  movaps [rcx], xmm14
00007b00b77d73cd  mov rax, 0x612A23581A50
00007b00b77d73d7  call rax
00007b00b77d73d9  movaps xmm13, [rsp]
00007b00b77d73de  add rsp, 0x40
00007b00b77d73e2  vmovaps xmm0, [rsp]
00007b00b77d73e7  vmovaps xmm1, [rsp+0x10]
00007b00b77d73ed  vmovaps xmm2, [rsp+0x20]
00007b00b77d73f3  vmovaps xmm3, [rsp+0x30]
00007b00b77d73f9  vmovaps xmm4, [rsp+0x40]
00007b00b77d73ff  vmovaps xmm5, [rsp+0x50]
00007b00b77d7405  vmovaps xmm6, [rsp+0x60]
00007b00b77d740b  vmovaps xmm7, [rsp+0x70]
00007b00b77d7411  vmovaps xmm8, [rsp+0x80]
00007b00b77d741a  vmovaps xmm9, [rsp+0x90]
00007b00b77d7423  vmovaps xmm10, [rsp+0xA0]
00007b00b77d742c  vmovaps xmm11, [rsp+0xB0]
00007b00b77d7435  vmovaps xmm12, [rsp+0xC0]
00007b00b77d743e  vmovaps xmm14, [rsp+0xD0]
00007b00b77d7447  vmovaps xmm15, [rsp+0xE0]
00007b00b77d7450  add rsp, 0xF0
00007b00b77d7457  pop r11
00007b00b77d7459  pop r10
00007b00b77d745b  pop r9
00007b00b77d745d  pop r8
00007b00b77d745f  pop rsi
00007b00b77d7460  pop rdi
00007b00b77d7461  pop rdx
00007b00b77d7462  pop rcx
00007b00b77d7463  pop rax
00007b00b77d7464  add rsp, 0x08
00007b00b77d7468  jmp 0x00007B00B77D665F
00007b00b77d746d  sub rsp, 0x08
00007b00b77d7471  push rax
00007b00b77d7472  push rcx
00007b00b77d7473  push rdx
00007b00b77d7474  push rdi
00007b00b77d7475  push rsi
00007b00b77d7476  push r8
00007b00b77d7478  push r9
00007b00b77d747a  push r10
00007b00b77d747c  push r11
00007b00b77d747e  sub rsp, 0xF0
00007b00b77d7485  vmovaps [rsp], xmm0
00007b00b77d748a  vmovaps [rsp+0x10], xmm1
00007b00b77d7490  vmovaps [rsp+0x20], xmm2
00007b00b77d7496  vmovaps [rsp+0x30], xmm3
00007b00b77d749c  vmovaps [rsp+0x40], xmm4
00007b00b77d74a2  vmovaps [rsp+0x50], xmm5
00007b00b77d74a8  vmovaps [rsp+0x60], xmm6
00007b00b77d74ae  vmovaps [rsp+0x70], xmm7
00007b00b77d74b4  vmovaps [rsp+0x80], xmm8
00007b00b77d74bd  vmovaps [rsp+0x90], xmm9
00007b00b77d74c6  vmovaps [rsp+0xA0], xmm10
00007b00b77d74cf  vmovaps [rsp+0xB0], xmm11
00007b00b77d74d8  vmovaps [rsp+0xC0], xmm12
00007b00b77d74e1  vmovaps [rsp+0xD0], xmm13
00007b00b77d74ea  vmovaps [rsp+0xE0], xmm15
00007b00b77d74f3  sub rsp, 0x40
00007b00b77d74f7  lea rdi, [rsp]
00007b00b77d74fb  lea rsi, [rsp+0x10]
00007b00b77d7500  lea rdx, [rsp+0x20]
00007b00b77d7505  lea rcx, [rsp+0x30]
00007b00b77d750a  mov r8d, 0x00
00007b00b77d7510  lea r9, [r15+0x3A8]
00007b00b77d7517  movaps [rdi], xmm14
00007b00b77d751b  movaps [rsi], xmm15
00007b00b77d751f  movaps [rdx], xmm2
00007b00b77d7522  movaps [rcx], xmm1
00007b00b77d7525  mov rax, 0x612A23581A50
00007b00b77d752f  call rax
00007b00b77d7531  movaps xmm14, [rsp]
00007b00b77d7536  add rsp, 0x40
00007b00b77d753a  vmovaps xmm0, [rsp]
00007b00b77d753f  vmovaps xmm1, [rsp+0x10]
00007b00b77d7545  vmovaps xmm2, [rsp+0x20]
00007b00b77d754b  vmovaps xmm3, [rsp+0x30]
00007b00b77d7551  vmovaps xmm4, [rsp+0x40]
00007b00b77d7557  vmovaps xmm5, [rsp+0x50]
00007b00b77d755d  vmovaps xmm6, [rsp+0x60]
00007b00b77d7563  vmovaps xmm7, [rsp+0x70]
00007b00b77d7569  vmovaps xmm8, [rsp+0x80]
00007b00b77d7572  vmovaps xmm9, [rsp+0x90]
00007b00b77d757b  vmovaps xmm10, [rsp+0xA0]
00007b00b77d7584  vmovaps xmm11, [rsp+0xB0]
00007b00b77d758d  vmovaps xmm12, [rsp+0xC0]
00007b00b77d7596  vmovaps xmm13, [rsp+0xD0]
00007b00b77d759f  vmovaps xmm15, [rsp+0xE0]
00007b00b77d75a8  add rsp, 0xF0
00007b00b77d75af  pop r11
00007b00b77d75b1  pop r10
00007b00b77d75b3  pop r9
00007b00b77d75b5  pop r8
00007b00b77d75b7  pop rsi
00007b00b77d75b8  pop rdi
00007b00b77d75b9  pop rdx
00007b00b77d75ba  pop rcx
00007b00b77d75bb  pop rax
00007b00b77d75bc  add rsp, 0x08
00007b00b77d75c0  jmp 0x00007B00B77D6691
00007b00b77d75c5  sub rsp, 0x08
00007b00b77d75c9  push rax
00007b00b77d75ca  push rcx
00007b00b77d75cb  push rdx
00007b00b77d75cc  push rdi
00007b00b77d75cd  push rsi
00007b00b77d75ce  push r8
00007b00b77d75d0  push r9
00007b00b77d75d2  push r10
00007b00b77d75d4  push r11
00007b00b77d75d6  sub rsp, 0xF0
00007b00b77d75dd  vmovaps [rsp], xmm0
00007b00b77d75e2  vmovaps [rsp+0x10], xmm1
00007b00b77d75e8  vmovaps [rsp+0x20], xmm3
00007b00b77d75ee  vmovaps [rsp+0x30], xmm4
00007b00b77d75f4  vmovaps [rsp+0x40], xmm5
00007b00b77d75fa  vmovaps [rsp+0x50], xmm6
00007b00b77d7600  vmovaps [rsp+0x60], xmm7
00007b00b77d7606  vmovaps [rsp+0x70], xmm8
00007b00b77d760c  vmovaps [rsp+0x80], xmm9
00007b00b77d7615  vmovaps [rsp+0x90], xmm10
00007b00b77d761e  vmovaps [rsp+0xA0], xmm11
00007b00b77d7627  vmovaps [rsp+0xB0], xmm12
00007b00b77d7630  vmovaps [rsp+0xC0], xmm13
00007b00b77d7639  vmovaps [rsp+0xD0], xmm14
00007b00b77d7642  vmovaps [rsp+0xE0], xmm15
00007b00b77d764b  sub rsp, 0x40
00007b00b77d764f  lea rdi, [rsp]
00007b00b77d7653  lea rsi, [rsp+0x10]
00007b00b77d7658  lea rdx, [rsp+0x20]
00007b00b77d765d  lea rcx, [rsp+0x30]
00007b00b77d7662  mov r8d, 0x00
00007b00b77d7668  lea r9, [r15+0x3A8]
00007b00b77d766f  movaps [rdi], xmm2
00007b00b77d7672  movaps [rsi], xmm15
00007b00b77d7676  movaps [rdx], xmm12
00007b00b77d767a  movaps [rcx], xmm1
00007b00b77d767d  mov rax, 0x612A23581A50
00007b00b77d7687  call rax
00007b00b77d7689  movaps xmm2, [rsp]
00007b00b77d768d  add rsp, 0x40
00007b00b77d7691  vmovaps xmm0, [rsp]
00007b00b77d7696  vmovaps xmm1, [rsp+0x10]
00007b00b77d769c  vmovaps xmm3, [rsp+0x20]
00007b00b77d76a2  vmovaps xmm4, [rsp+0x30]
00007b00b77d76a8  vmovaps xmm5, [rsp+0x40]
00007b00b77d76ae  vmovaps xmm6, [rsp+0x50]
00007b00b77d76b4  vmovaps xmm7, [rsp+0x60]
00007b00b77d76ba  vmovaps xmm8, [rsp+0x70]
00007b00b77d76c0  vmovaps xmm9, [rsp+0x80]
00007b00b77d76c9  vmovaps xmm10, [rsp+0x90]
00007b00b77d76d2  vmovaps xmm11, [rsp+0xA0]
00007b00b77d76db  vmovaps xmm12, [rsp+0xB0]
00007b00b77d76e4  vmovaps xmm13, [rsp+0xC0]
00007b00b77d76ed  vmovaps xmm14, [rsp+0xD0]
00007b00b77d76f6  vmovaps xmm15, [rsp+0xE0]
00007b00b77d76ff  add rsp, 0xF0
00007b00b77d7706  pop r11
00007b00b77d7708  pop r10
00007b00b77d770a  pop r9
00007b00b77d770c  pop r8
00007b00b77d770e  pop rsi
00007b00b77d770f  pop rdi
00007b00b77d7710  pop rdx
00007b00b77d7711  pop rcx
00007b00b77d7712  pop rax
00007b00b77d7713  add rsp, 0x08
00007b00b77d7717  jmp 0x00007B00B77D66CE
00007b00b77d771c  sub rsp, 0x08
00007b00b77d7720  push rax
00007b00b77d7721  push rcx
00007b00b77d7722  push rdx
00007b00b77d7723  push rdi
00007b00b77d7724  push rsi
00007b00b77d7725  push r8
00007b00b77d7727  push r9
00007b00b77d7729  push r10
00007b00b77d772b  push r11
00007b00b77d772d  sub rsp, 0xF0
00007b00b77d7734  vmovaps [rsp], xmm0
00007b00b77d7739  vmovaps [rsp+0x10], xmm1
00007b00b77d773f  vmovaps [rsp+0x20], xmm2
00007b00b77d7745  vmovaps [rsp+0x30], xmm3
00007b00b77d774b  vmovaps [rsp+0x40], xmm4
00007b00b77d7751  vmovaps [rsp+0x50], xmm5
00007b00b77d7757  vmovaps [rsp+0x60], xmm6
00007b00b77d775d  vmovaps [rsp+0x70], xmm7
00007b00b77d7763  vmovaps [rsp+0x80], xmm8
00007b00b77d776c  vmovaps [rsp+0x90], xmm9
00007b00b77d7775  vmovaps [rsp+0xA0], xmm10
00007b00b77d777e  vmovaps [rsp+0xB0], xmm11
00007b00b77d7787  vmovaps [rsp+0xC0], xmm13
00007b00b77d7790  vmovaps [rsp+0xD0], xmm14
00007b00b77d7799  vmovaps [rsp+0xE0], xmm15
00007b00b77d77a2  sub rsp, 0x40
00007b00b77d77a6  lea rdi, [rsp]
00007b00b77d77aa  lea rsi, [rsp+0x10]
00007b00b77d77af  lea rdx, [rsp+0x20]
00007b00b77d77b4  lea rcx, [rsp+0x30]
00007b00b77d77b9  mov r8d, 0x00
00007b00b77d77bf  lea r9, [r15+0x3A8]
00007b00b77d77c6  movaps [rdi], xmm12
00007b00b77d77ca  movaps [rsi], xmm14
00007b00b77d77ce  movaps [rdx], xmm3
00007b00b77d77d1  movaps [rcx], xmm15
00007b00b77d77d5  mov rax, 0x612A23581A50
00007b00b77d77df  call rax
00007b00b77d77e1  movaps xmm12, [rsp]
00007b00b77d77e6  add rsp, 0x40
00007b00b77d77ea  vmovaps xmm0, [rsp]
00007b00b77d77ef  vmovaps xmm1, [rsp+0x10]
00007b00b77d77f5  vmovaps xmm2, [rsp+0x20]
00007b00b77d77fb  vmovaps xmm3, [rsp+0x30]
00007b00b77d7801  vmovaps xmm4, [rsp+0x40]
00007b00b77d7807  vmovaps xmm5, [rsp+0x50]
00007b00b77d780d  vmovaps xmm6, [rsp+0x60]
00007b00b77d7813  vmovaps xmm7, [rsp+0x70]
00007b00b77d7819  vmovaps xmm8, [rsp+0x80]
00007b00b77d7822  vmovaps xmm9, [rsp+0x90]
00007b00b77d782b  vmovaps xmm10, [rsp+0xA0]
00007b00b77d7834  vmovaps xmm11, [rsp+0xB0]
00007b00b77d783d  vmovaps xmm13, [rsp+0xC0]
00007b00b77d7846  vmovaps xmm14, [rsp+0xD0]
00007b00b77d784f  vmovaps xmm15, [rsp+0xE0]
00007b00b77d7858  add rsp, 0xF0
00007b00b77d785f  pop r11
00007b00b77d7861  pop r10
00007b00b77d7863  pop r9
00007b00b77d7865  pop r8
00007b00b77d7867  pop rsi
00007b00b77d7868  pop rdi
00007b00b77d7869  pop rdx
00007b00b77d786a  pop rcx
00007b00b77d786b  pop rax
00007b00b77d786c  add rsp, 0x08
00007b00b77d7870  jmp 0x00007B00B77D6728
00007b00b77d7875  sub rsp, 0x08
00007b00b77d7879  push rax
00007b00b77d787a  push rcx
00007b00b77d787b  push rdx
00007b00b77d787c  push rdi
00007b00b77d787d  push rsi
00007b00b77d787e  push r8
00007b00b77d7880  push r9
00007b00b77d7882  push r10
00007b00b77d7884  push r11
00007b00b77d7886  sub rsp, 0xF0
00007b00b77d788d  vmovaps [rsp], xmm0
00007b00b77d7892  vmovaps [rsp+0x10], xmm1
00007b00b77d7898  vmovaps [rsp+0x20], xmm2
00007b00b77d789e  vmovaps [rsp+0x30], xmm3
00007b00b77d78a4  vmovaps [rsp+0x40], xmm4
00007b00b77d78aa  vmovaps [rsp+0x50], xmm5
00007b00b77d78b0  vmovaps [rsp+0x60], xmm6
00007b00b77d78b6  vmovaps [rsp+0x70], xmm7
00007b00b77d78bc  vmovaps [rsp+0x80], xmm8
00007b00b77d78c5  vmovaps [rsp+0x90], xmm10
00007b00b77d78ce  vmovaps [rsp+0xA0], xmm11
00007b00b77d78d7  vmovaps [rsp+0xB0], xmm12
00007b00b77d78e0  vmovaps [rsp+0xC0], xmm13
00007b00b77d78e9  vmovaps [rsp+0xD0], xmm14
00007b00b77d78f2  vmovaps [rsp+0xE0], xmm15
00007b00b77d78fb  sub rsp, 0x40
00007b00b77d78ff  lea rdi, [rsp]
00007b00b77d7903  lea rsi, [rsp+0x10]
00007b00b77d7908  lea rdx, [rsp+0x20]
00007b00b77d790d  lea rcx, [rsp+0x30]
00007b00b77d7912  mov r8d, 0x00
00007b00b77d7918  lea r9, [r15+0x3A8]
00007b00b77d791f  movaps [rdi], xmm9
00007b00b77d7923  movaps [rsi], xmm13
00007b00b77d7927  movaps [rdx], xmm14
00007b00b77d792b  movaps [rcx], xmm6
00007b00b77d792e  mov rax, 0x612A23581A50
00007b00b77d7938  call rax
00007b00b77d793a  movaps xmm9, [rsp]
00007b00b77d793f  add rsp, 0x40
00007b00b77d7943  vmovaps xmm0, [rsp]
00007b00b77d7948  vmovaps xmm1, [rsp+0x10]
00007b00b77d794e  vmovaps xmm2, [rsp+0x20]
00007b00b77d7954  vmovaps xmm3, [rsp+0x30]
00007b00b77d795a  vmovaps xmm4, [rsp+0x40]
00007b00b77d7960  vmovaps xmm5, [rsp+0x50]
00007b00b77d7966  vmovaps xmm6, [rsp+0x60]
00007b00b77d796c  vmovaps xmm7, [rsp+0x70]
00007b00b77d7972  vmovaps xmm8, [rsp+0x80]
00007b00b77d797b  vmovaps xmm10, [rsp+0x90]
00007b00b77d7984  vmovaps xmm11, [rsp+0xA0]
00007b00b77d798d  vmovaps xmm12, [rsp+0xB0]
00007b00b77d7996  vmovaps xmm13, [rsp+0xC0]
00007b00b77d799f  vmovaps xmm14, [rsp+0xD0]
00007b00b77d79a8  vmovaps xmm15, [rsp+0xE0]
00007b00b77d79b1  add rsp, 0xF0
00007b00b77d79b8  pop r11
00007b00b77d79ba  pop r10
00007b00b77d79bc  pop r9
00007b00b77d79be  pop r8
00007b00b77d79c0  pop rsi
00007b00b77d79c1  pop rdi
00007b00b77d79c2  pop rdx
00007b00b77d79c3  pop rcx
00007b00b77d79c4  pop rax
00007b00b77d79c5  add rsp, 0x08
00007b00b77d79c9  jmp 0x00007B00B77D67D2
00007b00b77d79ce  sub rsp, 0x08
00007b00b77d79d2  push rax
00007b00b77d79d3  push rcx
00007b00b77d79d4  push rdx
00007b00b77d79d5  push rdi
00007b00b77d79d6  push rsi
00007b00b77d79d7  push r8
00007b00b77d79d9  push r9
00007b00b77d79db  push r10
00007b00b77d79dd  push r11
00007b00b77d79df  sub rsp, 0xF0
00007b00b77d79e6  vmovaps [rsp], xmm0
00007b00b77d79eb  vmovaps [rsp+0x10], xmm1
00007b00b77d79f1  vmovaps [rsp+0x20], xmm2
00007b00b77d79f7  vmovaps [rsp+0x30], xmm4
00007b00b77d79fd  vmovaps [rsp+0x40], xmm5
00007b00b77d7a03  vmovaps [rsp+0x50], xmm6
00007b00b77d7a09  vmovaps [rsp+0x60], xmm7
00007b00b77d7a0f  vmovaps [rsp+0x70], xmm8
00007b00b77d7a15  vmovaps [rsp+0x80], xmm9
00007b00b77d7a1e  vmovaps [rsp+0x90], xmm10
00007b00b77d7a27  vmovaps [rsp+0xA0], xmm11
00007b00b77d7a30  vmovaps [rsp+0xB0], xmm12
00007b00b77d7a39  vmovaps [rsp+0xC0], xmm13
00007b00b77d7a42  vmovaps [rsp+0xD0], xmm14
00007b00b77d7a4b  vmovaps [rsp+0xE0], xmm15
00007b00b77d7a54  sub rsp, 0x40
00007b00b77d7a58  lea rdi, [rsp]
00007b00b77d7a5c  lea rsi, [rsp+0x10]
00007b00b77d7a61  lea rdx, [rsp+0x20]
00007b00b77d7a66  lea rcx, [rsp+0x30]
00007b00b77d7a6b  mov r8d, 0x00
00007b00b77d7a71  lea r9, [r15+0x3A8]
00007b00b77d7a78  movaps [rdi], xmm3
00007b00b77d7a7b  movaps [rsi], xmm13
00007b00b77d7a7f  movaps [rdx], xmm6
00007b00b77d7a82  movaps [rcx], xmm14
00007b00b77d7a86  mov rax, 0x612A23581A50
00007b00b77d7a90  call rax
00007b00b77d7a92  movaps xmm3, [rsp]
00007b00b77d7a96  add rsp, 0x40
00007b00b77d7a9a  vmovaps xmm0, [rsp]
00007b00b77d7a9f  vmovaps xmm1, [rsp+0x10]
00007b00b77d7aa5  vmovaps xmm2, [rsp+0x20]
00007b00b77d7aab  vmovaps xmm4, [rsp+0x30]
00007b00b77d7ab1  vmovaps xmm5, [rsp+0x40]
00007b00b77d7ab7  vmovaps xmm6, [rsp+0x50]
00007b00b77d7abd  vmovaps xmm7, [rsp+0x60]
00007b00b77d7ac3  vmovaps xmm8, [rsp+0x70]
00007b00b77d7ac9  vmovaps xmm9, [rsp+0x80]
00007b00b77d7ad2  vmovaps xmm10, [rsp+0x90]
00007b00b77d7adb  vmovaps xmm11, [rsp+0xA0]
00007b00b77d7ae4  vmovaps xmm12, [rsp+0xB0]
00007b00b77d7aed  vmovaps xmm13, [rsp+0xC0]
00007b00b77d7af6  vmovaps xmm14, [rsp+0xD0]
00007b00b77d7aff  vmovaps xmm15, [rsp+0xE0]
00007b00b77d7b08  add rsp, 0xF0
00007b00b77d7b0f  pop r11
00007b00b77d7b11  pop r10
00007b00b77d7b13  pop r9
00007b00b77d7b15  pop r8
00007b00b77d7b17  pop rsi
00007b00b77d7b18  pop rdi
00007b00b77d7b19  pop rdx
00007b00b77d7b1a  pop rcx
00007b00b77d7b1b  pop rax
00007b00b77d7b1c  add rsp, 0x08
00007b00b77d7b20  jmp 0x00007B00B77D680F
00007b00b77d7b25  sub rsp, 0x08
00007b00b77d7b29  push rax
00007b00b77d7b2a  push rcx
00007b00b77d7b2b  push rdx
00007b00b77d7b2c  push rdi
00007b00b77d7b2d  push rsi
00007b00b77d7b2e  push r8
00007b00b77d7b30  push r9
00007b00b77d7b32  push r10
00007b00b77d7b34  push r11
00007b00b77d7b36  sub rsp, 0xF0
00007b00b77d7b3d  vmovaps [rsp], xmm0
00007b00b77d7b42  vmovaps [rsp+0x10], xmm1
00007b00b77d7b48  vmovaps [rsp+0x20], xmm2
00007b00b77d7b4e  vmovaps [rsp+0x30], xmm3
00007b00b77d7b54  vmovaps [rsp+0x40], xmm4
00007b00b77d7b5a  vmovaps [rsp+0x50], xmm5
00007b00b77d7b60  vmovaps [rsp+0x60], xmm7
00007b00b77d7b66  vmovaps [rsp+0x70], xmm8
00007b00b77d7b6c  vmovaps [rsp+0x80], xmm9
00007b00b77d7b75  vmovaps [rsp+0x90], xmm10
00007b00b77d7b7e  vmovaps [rsp+0xA0], xmm11
00007b00b77d7b87  vmovaps [rsp+0xB0], xmm12
00007b00b77d7b90  vmovaps [rsp+0xC0], xmm13
00007b00b77d7b99  vmovaps [rsp+0xD0], xmm14
00007b00b77d7ba2  vmovaps [rsp+0xE0], xmm15
00007b00b77d7bab  sub rsp, 0x40
00007b00b77d7baf  lea rdi, [rsp]
00007b00b77d7bb3  lea rsi, [rsp+0x10]
00007b00b77d7bb8  lea rdx, [rsp+0x20]
00007b00b77d7bbd  lea rcx, [rsp+0x30]
00007b00b77d7bc2  mov r8d, 0x00
00007b00b77d7bc8  lea r9, [r15+0x3A8]
00007b00b77d7bcf  movaps [rdi], xmm6
00007b00b77d7bd2  movaps [rsi], xmm2
00007b00b77d7bd5  movaps [rdx], xmm14
00007b00b77d7bd9  movaps [rcx], xmm1
00007b00b77d7bdc  mov rax, 0x612A23581A50
00007b00b77d7be6  call rax
00007b00b77d7be8  movaps xmm6, [rsp]
00007b00b77d7bec  add rsp, 0x40
00007b00b77d7bf0  vmovaps xmm0, [rsp]
00007b00b77d7bf5  vmovaps xmm1, [rsp+0x10]
00007b00b77d7bfb  vmovaps xmm2, [rsp+0x20]
00007b00b77d7c01  vmovaps xmm3, [rsp+0x30]
00007b00b77d7c07  vmovaps xmm4, [rsp+0x40]
00007b00b77d7c0d  vmovaps xmm5, [rsp+0x50]
00007b00b77d7c13  vmovaps xmm7, [rsp+0x60]
00007b00b77d7c19  vmovaps xmm8, [rsp+0x70]
00007b00b77d7c1f  vmovaps xmm9, [rsp+0x80]
00007b00b77d7c28  vmovaps xmm10, [rsp+0x90]
00007b00b77d7c31  vmovaps xmm11, [rsp+0xA0]
00007b00b77d7c3a  vmovaps xmm12, [rsp+0xB0]
00007b00b77d7c43  vmovaps xmm13, [rsp+0xC0]
00007b00b77d7c4c  vmovaps xmm14, [rsp+0xD0]
00007b00b77d7c55  vmovaps xmm15, [rsp+0xE0]
00007b00b77d7c5e  add rsp, 0xF0
00007b00b77d7c65  pop r11
00007b00b77d7c67  pop r10
00007b00b77d7c69  pop r9
00007b00b77d7c6b  pop r8
00007b00b77d7c6d  pop rsi
00007b00b77d7c6e  pop rdi
00007b00b77d7c6f  pop rdx
00007b00b77d7c70  pop rcx
00007b00b77d7c71  pop rax
00007b00b77d7c72  add rsp, 0x08
00007b00b77d7c76  jmp 0x00007B00B77D683C
00007b00b77d7c7b  sub rsp, 0x08
00007b00b77d7c7f  push rax
00007b00b77d7c80  push rcx
00007b00b77d7c81  push rdx
00007b00b77d7c82  push rdi
00007b00b77d7c83  push rsi
00007b00b77d7c84  push r8
00007b00b77d7c86  push r9
00007b00b77d7c88  push r10
00007b00b77d7c8a  push r11
00007b00b77d7c8c  sub rsp, 0xF0
00007b00b77d7c93  vmovaps [rsp], xmm0
00007b00b77d7c98  vmovaps [rsp+0x10], xmm1
00007b00b77d7c9e  vmovaps [rsp+0x20], xmm2
00007b00b77d7ca4  vmovaps [rsp+0x30], xmm3
00007b00b77d7caa  vmovaps [rsp+0x40], xmm4
00007b00b77d7cb0  vmovaps [rsp+0x50], xmm5
00007b00b77d7cb6  vmovaps [rsp+0x60], xmm6
00007b00b77d7cbc  vmovaps [rsp+0x70], xmm7
00007b00b77d7cc2  vmovaps [rsp+0x80], xmm8
00007b00b77d7ccb  vmovaps [rsp+0x90], xmm9
00007b00b77d7cd4  vmovaps [rsp+0xA0], xmm10
00007b00b77d7cdd  vmovaps [rsp+0xB0], xmm11
00007b00b77d7ce6  vmovaps [rsp+0xC0], xmm12
00007b00b77d7cef  vmovaps [rsp+0xD0], xmm14
00007b00b77d7cf8  vmovaps [rsp+0xE0], xmm15
00007b00b77d7d01  sub rsp, 0x40
00007b00b77d7d05  lea rdi, [rsp]
00007b00b77d7d09  lea rsi, [rsp+0x10]
00007b00b77d7d0e  lea rdx, [rsp+0x20]
00007b00b77d7d13  lea rcx, [rsp+0x30]
00007b00b77d7d18  mov r8d, 0x00
00007b00b77d7d1e  lea r9, [r15+0x3A8]
00007b00b77d7d25  movaps [rdi], xmm13
00007b00b77d7d29  movaps [rsi], xmm12
00007b00b77d7d2d  movaps [rdx], xmm14
00007b00b77d7d31  movaps [rcx], xmm1
00007b00b77d7d34  mov rax, 0x612A23581A50
00007b00b77d7d3e  call rax
00007b00b77d7d40  movaps xmm13, [rsp]
00007b00b77d7d45  add rsp, 0x40
00007b00b77d7d49  vmovaps xmm0, [rsp]
00007b00b77d7d4e  vmovaps xmm1, [rsp+0x10]
00007b00b77d7d54  vmovaps xmm2, [rsp+0x20]
00007b00b77d7d5a  vmovaps xmm3, [rsp+0x30]
00007b00b77d7d60  vmovaps xmm4, [rsp+0x40]
00007b00b77d7d66  vmovaps xmm5, [rsp+0x50]
00007b00b77d7d6c  vmovaps xmm6, [rsp+0x60]
00007b00b77d7d72  vmovaps xmm7, [rsp+0x70]
00007b00b77d7d78  vmovaps xmm8, [rsp+0x80]
00007b00b77d7d81  vmovaps xmm9, [rsp+0x90]
00007b00b77d7d8a  vmovaps xmm10, [rsp+0xA0]
00007b00b77d7d93  vmovaps xmm11, [rsp+0xB0]
00007b00b77d7d9c  vmovaps xmm12, [rsp+0xC0]
00007b00b77d7da5  vmovaps xmm14, [rsp+0xD0]
00007b00b77d7dae  vmovaps xmm15, [rsp+0xE0]
00007b00b77d7db7  add rsp, 0xF0
00007b00b77d7dbe  pop r11
00007b00b77d7dc0  pop r10
00007b00b77d7dc2  pop r9
00007b00b77d7dc4  pop r8
00007b00b77d7dc6  pop rsi
00007b00b77d7dc7  pop rdi
00007b00b77d7dc8  pop rdx
00007b00b77d7dc9  pop rcx
00007b00b77d7dca  pop rax
00007b00b77d7dcb  add rsp, 0x08
00007b00b77d7dcf  jmp 0x00007B00B77D686E
00007b00b77d7dd4  sub rsp, 0x08
00007b00b77d7dd8  push rax
00007b00b77d7dd9  push rcx
00007b00b77d7dda  push rdx
00007b00b77d7ddb  push rdi
00007b00b77d7ddc  push rsi
00007b00b77d7ddd  push r8
00007b00b77d7ddf  push r9
00007b00b77d7de1  push r10
00007b00b77d7de3  push r11
00007b00b77d7de5  sub rsp, 0xF0
00007b00b77d7dec  vmovaps [rsp], xmm0
00007b00b77d7df1  vmovaps [rsp+0x10], xmm1
00007b00b77d7df7  vmovaps [rsp+0x20], xmm2
00007b00b77d7dfd  vmovaps [rsp+0x30], xmm3
00007b00b77d7e03  vmovaps [rsp+0x40], xmm4
00007b00b77d7e09  vmovaps [rsp+0x50], xmm5
00007b00b77d7e0f  vmovaps [rsp+0x60], xmm6
00007b00b77d7e15  vmovaps [rsp+0x70], xmm7
00007b00b77d7e1b  vmovaps [rsp+0x80], xmm8
00007b00b77d7e24  vmovaps [rsp+0x90], xmm9
00007b00b77d7e2d  vmovaps [rsp+0xA0], xmm10
00007b00b77d7e36  vmovaps [rsp+0xB0], xmm11
00007b00b77d7e3f  vmovaps [rsp+0xC0], xmm13
00007b00b77d7e48  vmovaps [rsp+0xD0], xmm14
00007b00b77d7e51  vmovaps [rsp+0xE0], xmm15
00007b00b77d7e5a  sub rsp, 0x40
00007b00b77d7e5e  lea rdi, [rsp]
00007b00b77d7e62  lea rsi, [rsp+0x10]
00007b00b77d7e67  lea rdx, [rsp+0x20]
00007b00b77d7e6c  lea rcx, [rsp+0x30]
00007b00b77d7e71  mov r8d, 0x00
00007b00b77d7e77  lea r9, [r15+0x3A8]
00007b00b77d7e7e  movaps [rdi], xmm12
00007b00b77d7e82  movaps [rsi], xmm3
00007b00b77d7e85  movaps [rdx], xmm14
00007b00b77d7e89  movaps [rcx], xmm5
00007b00b77d7e8c  mov rax, 0x612A23581A50
00007b00b77d7e96  call rax
00007b00b77d7e98  movaps xmm12, [rsp]
00007b00b77d7e9d  add rsp, 0x40
00007b00b77d7ea1  vmovaps xmm0, [rsp]
00007b00b77d7ea6  vmovaps xmm1, [rsp+0x10]
00007b00b77d7eac  vmovaps xmm2, [rsp+0x20]
00007b00b77d7eb2  vmovaps xmm3, [rsp+0x30]
00007b00b77d7eb8  vmovaps xmm4, [rsp+0x40]
00007b00b77d7ebe  vmovaps xmm5, [rsp+0x50]
00007b00b77d7ec4  vmovaps xmm6, [rsp+0x60]
00007b00b77d7eca  vmovaps xmm7, [rsp+0x70]
00007b00b77d7ed0  vmovaps xmm8, [rsp+0x80]
00007b00b77d7ed9  vmovaps xmm9, [rsp+0x90]
00007b00b77d7ee2  vmovaps xmm10, [rsp+0xA0]
00007b00b77d7eeb  vmovaps xmm11, [rsp+0xB0]
00007b00b77d7ef4  vmovaps xmm13, [rsp+0xC0]
00007b00b77d7efd  vmovaps xmm14, [rsp+0xD0]
00007b00b77d7f06  vmovaps xmm15, [rsp+0xE0]
00007b00b77d7f0f  add rsp, 0xF0
00007b00b77d7f16  pop r11
00007b00b77d7f18  pop r10
00007b00b77d7f1a  pop r9
00007b00b77d7f1c  pop r8
00007b00b77d7f1e  pop rsi
00007b00b77d7f1f  pop rdi
00007b00b77d7f20  pop rdx
00007b00b77d7f21  pop rcx
00007b00b77d7f22  pop rax
00007b00b77d7f23  add rsp, 0x08
00007b00b77d7f27  jmp 0x00007B00B77D68CB
00007b00b77d7f2c  sub rsp, 0x08
00007b00b77d7f30  push rax
00007b00b77d7f31  push rcx
00007b00b77d7f32  push rdx
00007b00b77d7f33  push rdi
00007b00b77d7f34  push rsi
00007b00b77d7f35  push r8
00007b00b77d7f37  push r9
00007b00b77d7f39  push r10
00007b00b77d7f3b  push r11
00007b00b77d7f3d  sub rsp, 0xF0
00007b00b77d7f44  vmovaps [rsp], xmm0
00007b00b77d7f49  vmovaps [rsp+0x10], xmm1
00007b00b77d7f4f  vmovaps [rsp+0x20], xmm2
00007b00b77d7f55  vmovaps [rsp+0x30], xmm3
00007b00b77d7f5b  vmovaps [rsp+0x40], xmm4
00007b00b77d7f61  vmovaps [rsp+0x50], xmm5
00007b00b77d7f67  vmovaps [rsp+0x60], xmm6
00007b00b77d7f6d  vmovaps [rsp+0x70], xmm7
00007b00b77d7f73  vmovaps [rsp+0x80], xmm8
00007b00b77d7f7c  vmovaps [rsp+0x90], xmm9
00007b00b77d7f85  vmovaps [rsp+0xA0], xmm11
00007b00b77d7f8e  vmovaps [rsp+0xB0], xmm12
00007b00b77d7f97  vmovaps [rsp+0xC0], xmm13
00007b00b77d7fa0  vmovaps [rsp+0xD0], xmm14
00007b00b77d7fa9  vmovaps [rsp+0xE0], xmm15
00007b00b77d7fb2  sub rsp, 0x40
00007b00b77d7fb6  lea rdi, [rsp]
00007b00b77d7fba  lea rsi, [rsp+0x10]
00007b00b77d7fbf  lea rdx, [rsp+0x20]
00007b00b77d7fc4  lea rcx, [rsp+0x30]
00007b00b77d7fc9  mov r8d, 0x00
00007b00b77d7fcf  lea r9, [r15+0x3A8]
00007b00b77d7fd6  movaps [rdi], xmm10
00007b00b77d7fda  movaps [rsi], xmm9
00007b00b77d7fde  movaps [rdx], xmm7
00007b00b77d7fe1  movaps [rcx], xmm14
00007b00b77d7fe5  mov rax, 0x612A23581A50
00007b00b77d7fef  call rax
00007b00b77d7ff1  movaps xmm10, [rsp]
00007b00b77d7ff6  add rsp, 0x40
00007b00b77d7ffa  vmovaps xmm0, [rsp]
00007b00b77d7fff  vmovaps xmm1, [rsp+0x10]
00007b00b77d8005  vmovaps xmm2, [rsp+0x20]
00007b00b77d800b  vmovaps xmm3, [rsp+0x30]
00007b00b77d8011  vmovaps xmm4, [rsp+0x40]
00007b00b77d8017  vmovaps xmm5, [rsp+0x50]
00007b00b77d801d  vmovaps xmm6, [rsp+0x60]
00007b00b77d8023  vmovaps xmm7, [rsp+0x70]
00007b00b77d8029  vmovaps xmm8, [rsp+0x80]
00007b00b77d8032  vmovaps xmm9, [rsp+0x90]
00007b00b77d803b  vmovaps xmm11, [rsp+0xA0]
00007b00b77d8044  vmovaps xmm12, [rsp+0xB0]
00007b00b77d804d  vmovaps xmm13, [rsp+0xC0]
00007b00b77d8056  vmovaps xmm14, [rsp+0xD0]
00007b00b77d805f  vmovaps xmm15, [rsp+0xE0]
00007b00b77d8068  add rsp, 0xF0
00007b00b77d806f  pop r11
00007b00b77d8071  pop r10
00007b00b77d8073  pop r9
00007b00b77d8075  pop r8
00007b00b77d8077  pop rsi
00007b00b77d8078  pop rdi
00007b00b77d8079  pop rdx
00007b00b77d807a  pop rcx
00007b00b77d807b  pop rax
00007b00b77d807c  add rsp, 0x08
00007b00b77d8080  jmp 0x00007B00B77D68F1
00007b00b77d8085  call 0x00007B00B76E45A0
00007b00b77d808a  jmp 0x00007B00B77D68FE
00007b00b77d808f  sub rsp, 0x08
00007b00b77d8093  push rax
00007b00b77d8094  push rcx
00007b00b77d8095  push rdx
00007b00b77d8096  push rdi
00007b00b77d8097  push rsi
00007b00b77d8098  push r8
00007b00b77d809a  push r9
00007b00b77d809c  push r10
00007b00b77d809e  push r11
00007b00b77d80a0  sub rsp, 0xF0
00007b00b77d80a7  vmovaps [rsp], xmm0
00007b00b77d80ac  vmovaps [rsp+0x10], xmm1
00007b00b77d80b2  vmovaps [rsp+0x20], xmm2
00007b00b77d80b8  vmovaps [rsp+0x30], xmm3
00007b00b77d80be  vmovaps [rsp+0x40], xmm4
00007b00b77d80c4  vmovaps [rsp+0x50], xmm6
00007b00b77d80ca  vmovaps [rsp+0x60], xmm7
00007b00b77d80d0  vmovaps [rsp+0x70], xmm8
00007b00b77d80d6  vmovaps [rsp+0x80], xmm9
00007b00b77d80df  vmovaps [rsp+0x90], xmm10
00007b00b77d80e8  vmovaps [rsp+0xA0], xmm11
00007b00b77d80f1  vmovaps [rsp+0xB0], xmm12
00007b00b77d80fa  vmovaps [rsp+0xC0], xmm13
00007b00b77d8103  vmovaps [rsp+0xD0], xmm14
00007b00b77d810c  vmovaps [rsp+0xE0], xmm15
00007b00b77d8115  sub rsp, 0x40
00007b00b77d8119  lea rdi, [rsp]
00007b00b77d811d  lea rsi, [rsp+0x10]
00007b00b77d8122  lea rdx, [rsp+0x20]
00007b00b77d8127  lea rcx, [rsp+0x30]
00007b00b77d812c  mov r8d, 0x00
00007b00b77d8132  lea r9, [r15+0x3A8]
00007b00b77d8139  movaps [rdi], xmm5
00007b00b77d813c  movaps [rsi], xmm6
00007b00b77d813f  movaps [rdx], xmm7
00007b00b77d8142  movaps [rcx], xmm9
00007b00b77d8146  mov rax, 0x612A23581A50
00007b00b77d8150  call rax
00007b00b77d8152  movaps xmm5, [rsp]
00007b00b77d8156  add rsp, 0x40
00007b00b77d815a  vmovaps xmm0, [rsp]
00007b00b77d815f  vmovaps xmm1, [rsp+0x10]
00007b00b77d8165  vmovaps xmm2, [rsp+0x20]
00007b00b77d816b  vmovaps xmm3, [rsp+0x30]
00007b00b77d8171  vmovaps xmm4, [rsp+0x40]
00007b00b77d8177  vmovaps xmm6, [rsp+0x50]
00007b00b77d817d  vmovaps xmm7, [rsp+0x60]
00007b00b77d8183  vmovaps xmm8, [rsp+0x70]
00007b00b77d8189  vmovaps xmm9, [rsp+0x80]
00007b00b77d8192  vmovaps xmm10, [rsp+0x90]
00007b00b77d819b  vmovaps xmm11, [rsp+0xA0]
00007b00b77d81a4  vmovaps xmm12, [rsp+0xB0]
00007b00b77d81ad  vmovaps xmm13, [rsp+0xC0]
00007b00b77d81b6  vmovaps xmm14, [rsp+0xD0]
00007b00b77d81bf  vmovaps xmm15, [rsp+0xE0]
00007b00b77d81c8  add rsp, 0xF0
00007b00b77d81cf  pop r11
00007b00b77d81d1  pop r10
00007b00b77d81d3  pop r9
00007b00b77d81d5  pop r8
00007b00b77d81d7  pop rsi
00007b00b77d81d8  pop rdi
00007b00b77d81d9  pop rdx
00007b00b77d81da  pop rcx
00007b00b77d81db  pop rax
00007b00b77d81dc  add rsp, 0x08
00007b00b77d81e0  jmp 0x00007B00B77D6930
00007b00b77d81e5  sub rsp, 0x08
00007b00b77d81e9  push rax
00007b00b77d81ea  push rcx
00007b00b77d81eb  push rdx
00007b00b77d81ec  push rdi
00007b00b77d81ed  push rsi
00007b00b77d81ee  push r8
00007b00b77d81f0  push r9
00007b00b77d81f2  push r10
00007b00b77d81f4  push r11
00007b00b77d81f6  sub rsp, 0xF0
00007b00b77d81fd  vmovaps [rsp], xmm0
00007b00b77d8202  vmovaps [rsp+0x10], xmm1
00007b00b77d8208  vmovaps [rsp+0x20], xmm2
00007b00b77d820e  vmovaps [rsp+0x30], xmm3
00007b00b77d8214  vmovaps [rsp+0x40], xmm4
00007b00b77d821a  vmovaps [rsp+0x50], xmm5
00007b00b77d8220  vmovaps [rsp+0x60], xmm6
00007b00b77d8226  vmovaps [rsp+0x70], xmm8
00007b00b77d822c  vmovaps [rsp+0x80], xmm9
00007b00b77d8235  vmovaps [rsp+0x90], xmm10
00007b00b77d823e  vmovaps [rsp+0xA0], xmm11
00007b00b77d8247  vmovaps [rsp+0xB0], xmm12
00007b00b77d8250  vmovaps [rsp+0xC0], xmm13
00007b00b77d8259  vmovaps [rsp+0xD0], xmm14
00007b00b77d8262  vmovaps [rsp+0xE0], xmm15
00007b00b77d826b  sub rsp, 0x40
00007b00b77d826f  lea rdi, [rsp]
00007b00b77d8273  lea rsi, [rsp+0x10]
00007b00b77d8278  lea rdx, [rsp+0x20]
00007b00b77d827d  lea rcx, [rsp+0x30]
00007b00b77d8282  mov r8d, 0x00
00007b00b77d8288  lea r9, [r15+0x3A8]
00007b00b77d828f  movaps [rdi], xmm7
00007b00b77d8292  movaps [rsi], xmm13
00007b00b77d8296  movaps [rdx], xmm1
00007b00b77d8299  movaps [rcx], xmm9
00007b00b77d829d  mov rax, 0x612A23581A50
00007b00b77d82a7  call rax
00007b00b77d82a9  movaps xmm7, [rsp]
00007b00b77d82ad  add rsp, 0x40
00007b00b77d82b1  vmovaps xmm0, [rsp]
00007b00b77d82b6  vmovaps xmm1, [rsp+0x10]
00007b00b77d82bc  vmovaps xmm2, [rsp+0x20]
00007b00b77d82c2  vmovaps xmm3, [rsp+0x30]
00007b00b77d82c8  vmovaps xmm4, [rsp+0x40]
00007b00b77d82ce  vmovaps xmm5, [rsp+0x50]
00007b00b77d82d4  vmovaps xmm6, [rsp+0x60]
00007b00b77d82da  vmovaps xmm8, [rsp+0x70]
00007b00b77d82e0  vmovaps xmm9, [rsp+0x80]
00007b00b77d82e9  vmovaps xmm10, [rsp+0x90]
00007b00b77d82f2  vmovaps xmm11, [rsp+0xA0]
00007b00b77d82fb  vmovaps xmm12, [rsp+0xB0]
00007b00b77d8304  vmovaps xmm13, [rsp+0xC0]
00007b00b77d830d  vmovaps xmm14, [rsp+0xD0]
00007b00b77d8316  vmovaps xmm15, [rsp+0xE0]
00007b00b77d831f  add rsp, 0xF0
00007b00b77d8326  pop r11
00007b00b77d8328  pop r10
00007b00b77d832a  pop r9
00007b00b77d832c  pop r8
00007b00b77d832e  pop rsi
00007b00b77d832f  pop rdi
00007b00b77d8330  pop rdx
00007b00b77d8331  pop rcx
00007b00b77d8332  pop rax
00007b00b77d8333  add rsp, 0x08
00007b00b77d8337  jmp 0x00007B00B77D6955
00007b00b77d833c  call 0x00007B00B76E3320
00007b00b77d8341  jmp 0x00007B00B77D6978
00007b00b77d8346  call 0x00007B00B76DE950
00007b00b77d834b  jmp 0x00007B00B77D6982
00007b00b77d8350  sub rsp, 0x08
00007b00b77d8354  push rax
00007b00b77d8355  push rcx
00007b00b77d8356  push rdx
00007b00b77d8357  push rdi
00007b00b77d8358  push rsi
00007b00b77d8359  push r8
00007b00b77d835b  push r9
00007b00b77d835d  push r10
00007b00b77d835f  push r11
00007b00b77d8361  sub rsp, 0xF0
00007b00b77d8368  vmovaps [rsp], xmm0
00007b00b77d836d  vmovaps [rsp+0x10], xmm1
00007b00b77d8373  vmovaps [rsp+0x20], xmm3
00007b00b77d8379  vmovaps [rsp+0x30], xmm4
00007b00b77d837f  vmovaps [rsp+0x40], xmm5
00007b00b77d8385  vmovaps [rsp+0x50], xmm6
00007b00b77d838b  vmovaps [rsp+0x60], xmm7
00007b00b77d8391  vmovaps [rsp+0x70], xmm8
00007b00b77d8397  vmovaps [rsp+0x80], xmm9
00007b00b77d83a0  vmovaps [rsp+0x90], xmm10
00007b00b77d83a9  vmovaps [rsp+0xA0], xmm11
00007b00b77d83b2  vmovaps [rsp+0xB0], xmm12
00007b00b77d83bb  vmovaps [rsp+0xC0], xmm13
00007b00b77d83c4  vmovaps [rsp+0xD0], xmm14
00007b00b77d83cd  vmovaps [rsp+0xE0], xmm15
00007b00b77d83d6  sub rsp, 0x40
00007b00b77d83da  lea rdi, [rsp]
00007b00b77d83de  lea rsi, [rsp+0x10]
00007b00b77d83e3  lea rdx, [rsp+0x20]
00007b00b77d83e8  lea rcx, [rsp+0x30]
00007b00b77d83ed  mov r8d, 0x00
00007b00b77d83f3  lea r9, [r15+0x3A8]
00007b00b77d83fa  movaps [rdi], xmm2
00007b00b77d83fd  movaps [rsi], xmm12
00007b00b77d8401  movaps [rdx], xmm6
00007b00b77d8404  movaps [rcx], xmm3
00007b00b77d8407  mov rax, 0x612A23581A50
00007b00b77d8411  call rax
00007b00b77d8413  movaps xmm2, [rsp]
00007b00b77d8417  add rsp, 0x40
00007b00b77d841b  vmovaps xmm0, [rsp]
00007b00b77d8420  vmovaps xmm1, [rsp+0x10]
00007b00b77d8426  vmovaps xmm3, [rsp+0x20]
00007b00b77d842c  vmovaps xmm4, [rsp+0x30]
00007b00b77d8432  vmovaps xmm5, [rsp+0x40]
00007b00b77d8438  vmovaps xmm6, [rsp+0x50]
00007b00b77d843e  vmovaps xmm7, [rsp+0x60]
00007b00b77d8444  vmovaps xmm8, [rsp+0x70]
00007b00b77d844a  vmovaps xmm9, [rsp+0x80]
00007b00b77d8453  vmovaps xmm10, [rsp+0x90]
00007b00b77d845c  vmovaps xmm11, [rsp+0xA0]
00007b00b77d8465  vmovaps xmm12, [rsp+0xB0]
00007b00b77d846e  vmovaps xmm13, [rsp+0xC0]
00007b00b77d8477  vmovaps xmm14, [rsp+0xD0]
00007b00b77d8480  vmovaps xmm15, [rsp+0xE0]
00007b00b77d8489  add rsp, 0xF0
00007b00b77d8490  pop r11
00007b00b77d8492  pop r10
00007b00b77d8494  pop r9
00007b00b77d8496  pop r8
00007b00b77d8498  pop rsi
00007b00b77d8499  pop rdi
00007b00b77d849a  pop rdx
00007b00b77d849b  pop rcx
00007b00b77d849c  pop rax
00007b00b77d849d  add rsp, 0x08
00007b00b77d84a1  jmp 0x00007B00B77D69C8
00007b00b77d84a6  sub rsp, 0x08
00007b00b77d84aa  push rax
00007b00b77d84ab  push rcx
00007b00b77d84ac  push rdx
00007b00b77d84ad  push rdi
00007b00b77d84ae  push rsi
00007b00b77d84af  push r8
00007b00b77d84b1  push r9
00007b00b77d84b3  push r10
00007b00b77d84b5  push r11
00007b00b77d84b7  sub rsp, 0xF0
00007b00b77d84be  vmovaps [rsp], xmm0
00007b00b77d84c3  vmovaps [rsp+0x10], xmm1
00007b00b77d84c9  vmovaps [rsp+0x20], xmm2
00007b00b77d84cf  vmovaps [rsp+0x30], xmm3
00007b00b77d84d5  vmovaps [rsp+0x40], xmm4
00007b00b77d84db  vmovaps [rsp+0x50], xmm5
00007b00b77d84e1  vmovaps [rsp+0x60], xmm7
00007b00b77d84e7  vmovaps [rsp+0x70], xmm8
00007b00b77d84ed  vmovaps [rsp+0x80], xmm9
00007b00b77d84f6  vmovaps [rsp+0x90], xmm10
00007b00b77d84ff  vmovaps [rsp+0xA0], xmm11
00007b00b77d8508  vmovaps [rsp+0xB0], xmm12
00007b00b77d8511  vmovaps [rsp+0xC0], xmm13
00007b00b77d851a  vmovaps [rsp+0xD0], xmm14
00007b00b77d8523  vmovaps [rsp+0xE0], xmm15
00007b00b77d852c  sub rsp, 0x40
00007b00b77d8530  lea rdi, [rsp]
00007b00b77d8534  lea rsi, [rsp+0x10]
00007b00b77d8539  lea rdx, [rsp+0x20]
00007b00b77d853e  lea rcx, [rsp+0x30]
00007b00b77d8543  mov r8d, 0x00
00007b00b77d8549  lea r9, [r15+0x3A8]
00007b00b77d8550  movaps [rdi], xmm6
00007b00b77d8553  movaps [rsi], xmm10
00007b00b77d8557  movaps [rdx], xmm12
00007b00b77d855b  movaps [rcx], xmm1
00007b00b77d855e  mov rax, 0x612A23581A50
00007b00b77d8568  call rax
00007b00b77d856a  movaps xmm6, [rsp]
00007b00b77d856e  add rsp, 0x40
00007b00b77d8572  vmovaps xmm0, [rsp]
00007b00b77d8577  vmovaps xmm1, [rsp+0x10]
00007b00b77d857d  vmovaps xmm2, [rsp+0x20]
00007b00b77d8583  vmovaps xmm3, [rsp+0x30]
00007b00b77d8589  vmovaps xmm4, [rsp+0x40]
00007b00b77d858f  vmovaps xmm5, [rsp+0x50]
00007b00b77d8595  vmovaps xmm7, [rsp+0x60]
00007b00b77d859b  vmovaps xmm8, [rsp+0x70]
00007b00b77d85a1  vmovaps xmm9, [rsp+0x80]
00007b00b77d85aa  vmovaps xmm10, [rsp+0x90]
00007b00b77d85b3  vmovaps xmm11, [rsp+0xA0]
00007b00b77d85bc  vmovaps xmm12, [rsp+0xB0]
00007b00b77d85c5  vmovaps xmm13, [rsp+0xC0]
00007b00b77d85ce  vmovaps xmm14, [rsp+0xD0]
00007b00b77d85d7  vmovaps xmm15, [rsp+0xE0]
00007b00b77d85e0  add rsp, 0xF0
00007b00b77d85e7  pop r11
00007b00b77d85e9  pop r10
00007b00b77d85eb  pop r9
00007b00b77d85ed  pop r8
00007b00b77d85ef  pop rsi
00007b00b77d85f0  pop rdi
00007b00b77d85f1  pop rdx
00007b00b77d85f2  pop rcx
00007b00b77d85f3  pop rax
00007b00b77d85f4  add rsp, 0x08
00007b00b77d85f8  jmp 0x00007B00B77D69F6
00007b00b77d85fd  sub rsp, 0x08
00007b00b77d8601  push rax
00007b00b77d8602  push rcx
00007b00b77d8603  push rdx
00007b00b77d8604  push rdi
00007b00b77d8605  push rsi
00007b00b77d8606  push r8
00007b00b77d8608  push r9
00007b00b77d860a  push r10
00007b00b77d860c  push r11
00007b00b77d860e  sub rsp, 0xF0
00007b00b77d8615  vmovaps [rsp], xmm0
00007b00b77d861a  vmovaps [rsp+0x10], xmm1
00007b00b77d8620  vmovaps [rsp+0x20], xmm2
00007b00b77d8626  vmovaps [rsp+0x30], xmm3
00007b00b77d862c  vmovaps [rsp+0x40], xmm4
00007b00b77d8632  vmovaps [rsp+0x50], xmm5
00007b00b77d8638  vmovaps [rsp+0x60], xmm6
00007b00b77d863e  vmovaps [rsp+0x70], xmm7
00007b00b77d8644  vmovaps [rsp+0x80], xmm8
00007b00b77d864d  vmovaps [rsp+0x90], xmm9
00007b00b77d8656  vmovaps [rsp+0xA0], xmm11
00007b00b77d865f  vmovaps [rsp+0xB0], xmm12
00007b00b77d8668  vmovaps [rsp+0xC0], xmm13
00007b00b77d8671  vmovaps [rsp+0xD0], xmm14
00007b00b77d867a  vmovaps [rsp+0xE0], xmm15
00007b00b77d8683  sub rsp, 0x40
00007b00b77d8687  lea rdi, [rsp]
00007b00b77d868b  lea rsi, [rsp+0x10]
00007b00b77d8690  lea rdx, [rsp+0x20]
00007b00b77d8695  lea rcx, [rsp+0x30]
00007b00b77d869a  mov r8d, 0x00
00007b00b77d86a0  lea r9, [r15+0x3A8]
00007b00b77d86a7  movaps [rdi], xmm10
00007b00b77d86ab  movaps [rsi], xmm5
00007b00b77d86ae  movaps [rdx], xmm12
00007b00b77d86b2  movaps [rcx], xmm1
00007b00b77d86b5  mov rax, 0x612A23581A50
00007b00b77d86bf  call rax
00007b00b77d86c1  movaps xmm10, [rsp]
00007b00b77d86c6  add rsp, 0x40
00007b00b77d86ca  vmovaps xmm0, [rsp]
00007b00b77d86cf  vmovaps xmm1, [rsp+0x10]
00007b00b77d86d5  vmovaps xmm2, [rsp+0x20]
00007b00b77d86db  vmovaps xmm3, [rsp+0x30]
00007b00b77d86e1  vmovaps xmm4, [rsp+0x40]
00007b00b77d86e7  vmovaps xmm5, [rsp+0x50]
00007b00b77d86ed  vmovaps xmm6, [rsp+0x60]
00007b00b77d86f3  vmovaps xmm7, [rsp+0x70]
00007b00b77d86f9  vmovaps xmm8, [rsp+0x80]
00007b00b77d8702  vmovaps xmm9, [rsp+0x90]
00007b00b77d870b  vmovaps xmm11, [rsp+0xA0]
00007b00b77d8714  vmovaps xmm12, [rsp+0xB0]
00007b00b77d871d  vmovaps xmm13, [rsp+0xC0]
00007b00b77d8726  vmovaps xmm14, [rsp+0xD0]
00007b00b77d872f  vmovaps xmm15, [rsp+0xE0]
00007b00b77d8738  add rsp, 0xF0
00007b00b77d873f  pop r11
00007b00b77d8741  pop r10
00007b00b77d8743  pop r9
00007b00b77d8745  pop r8
00007b00b77d8747  pop rsi
00007b00b77d8748  pop rdi
00007b00b77d8749  pop rdx
00007b00b77d874a  pop rcx
00007b00b77d874b  pop rax
00007b00b77d874c  add rsp, 0x08
00007b00b77d8750  jmp 0x00007B00B77D6A25
00007b00b77d8755  sub rsp, 0x08
00007b00b77d8759  push rax
00007b00b77d875a  push rcx
00007b00b77d875b  push rdx
00007b00b77d875c  push rdi
00007b00b77d875d  push rsi
00007b00b77d875e  push r8
00007b00b77d8760  push r9
00007b00b77d8762  push r10
00007b00b77d8764  push r11
00007b00b77d8766  sub rsp, 0xF0
00007b00b77d876d  vmovaps [rsp], xmm0
00007b00b77d8772  vmovaps [rsp+0x10], xmm1
00007b00b77d8778  vmovaps [rsp+0x20], xmm2
00007b00b77d877e  vmovaps [rsp+0x30], xmm3
00007b00b77d8784  vmovaps [rsp+0x40], xmm4
00007b00b77d878a  vmovaps [rsp+0x50], xmm5
00007b00b77d8790  vmovaps [rsp+0x60], xmm6
00007b00b77d8796  vmovaps [rsp+0x70], xmm7
00007b00b77d879c  vmovaps [rsp+0x80], xmm8
00007b00b77d87a5  vmovaps [rsp+0x90], xmm9
00007b00b77d87ae  vmovaps [rsp+0xA0], xmm10
00007b00b77d87b7  vmovaps [rsp+0xB0], xmm11
00007b00b77d87c0  vmovaps [rsp+0xC0], xmm13
00007b00b77d87c9  vmovaps [rsp+0xD0], xmm14
00007b00b77d87d2  vmovaps [rsp+0xE0], xmm15
00007b00b77d87db  sub rsp, 0x40
00007b00b77d87df  lea rdi, [rsp]
00007b00b77d87e3  lea rsi, [rsp+0x10]
00007b00b77d87e8  lea rdx, [rsp+0x20]
00007b00b77d87ed  lea rcx, [rsp+0x30]
00007b00b77d87f2  mov r8d, 0x00
00007b00b77d87f8  lea r9, [r15+0x3A8]
00007b00b77d87ff  movaps [rdi], xmm12
00007b00b77d8803  movaps [rsi], xmm7
00007b00b77d8806  movaps [rdx], xmm15
00007b00b77d880a  movaps [rcx], xmm1
00007b00b77d880d  mov rax, 0x612A23581A50
00007b00b77d8817  call rax
00007b00b77d8819  movaps xmm12, [rsp]
00007b00b77d881e  add rsp, 0x40
00007b00b77d8822  vmovaps xmm0, [rsp]
00007b00b77d8827  vmovaps xmm1, [rsp+0x10]
00007b00b77d882d  vmovaps xmm2, [rsp+0x20]
00007b00b77d8833  vmovaps xmm3, [rsp+0x30]
00007b00b77d8839  vmovaps xmm4, [rsp+0x40]
00007b00b77d883f  vmovaps xmm5, [rsp+0x50]
00007b00b77d8845  vmovaps xmm6, [rsp+0x60]
00007b00b77d884b  vmovaps xmm7, [rsp+0x70]
00007b00b77d8851  vmovaps xmm8, [rsp+0x80]
00007b00b77d885a  vmovaps xmm9, [rsp+0x90]
00007b00b77d8863  vmovaps xmm10, [rsp+0xA0]
00007b00b77d886c  vmovaps xmm11, [rsp+0xB0]
00007b00b77d8875  vmovaps xmm13, [rsp+0xC0]
00007b00b77d887e  vmovaps xmm14, [rsp+0xD0]
00007b00b77d8887  vmovaps xmm15, [rsp+0xE0]
00007b00b77d8890  add rsp, 0xF0
00007b00b77d8897  pop r11
00007b00b77d8899  pop r10
00007b00b77d889b  pop r9
00007b00b77d889d  pop r8
00007b00b77d889f  pop rsi
00007b00b77d88a0  pop rdi
00007b00b77d88a1  pop rdx
00007b00b77d88a2  pop rcx
00007b00b77d88a3  pop rax
00007b00b77d88a4  add rsp, 0x08
00007b00b77d88a8  jmp 0x00007B00B77D6A4E
00007b00b77d88ad  call 0x00007B00B76D64F0
00007b00b77d88b2  jmp 0x00007B00B77D6A58
00007b00b77d88b7  call 0x00007B00B76E5820
00007b00b77d88bc  jmp 0x00007B00B77D6A62
00007b00b77d88c1  sub rsp, 0x08
00007b00b77d88c5  push rax
00007b00b77d88c6  push rcx
00007b00b77d88c7  push rdx
00007b00b77d88c8  push rdi
00007b00b77d88c9  push rsi
00007b00b77d88ca  push r8
00007b00b77d88cc  push r9
00007b00b77d88ce  push r10
00007b00b77d88d0  push r11
00007b00b77d88d2  sub rsp, 0xF0
00007b00b77d88d9  vmovaps [rsp], xmm0
00007b00b77d88de  vmovaps [rsp+0x10], xmm1
00007b00b77d88e4  vmovaps [rsp+0x20], xmm2
00007b00b77d88ea  vmovaps [rsp+0x30], xmm3
00007b00b77d88f0  vmovaps [rsp+0x40], xmm4
00007b00b77d88f6  vmovaps [rsp+0x50], xmm5
00007b00b77d88fc  vmovaps [rsp+0x60], xmm6
00007b00b77d8902  vmovaps [rsp+0x70], xmm8
00007b00b77d8908  vmovaps [rsp+0x80], xmm9
00007b00b77d8911  vmovaps [rsp+0x90], xmm10
00007b00b77d891a  vmovaps [rsp+0xA0], xmm11
00007b00b77d8923  vmovaps [rsp+0xB0], xmm12
00007b00b77d892c  vmovaps [rsp+0xC0], xmm13
00007b00b77d8935  vmovaps [rsp+0xD0], xmm14
00007b00b77d893e  vmovaps [rsp+0xE0], xmm15
00007b00b77d8947  sub rsp, 0x40
00007b00b77d894b  lea rdi, [rsp]
00007b00b77d894f  lea rsi, [rsp+0x10]
00007b00b77d8954  lea rdx, [rsp+0x20]
00007b00b77d8959  lea rcx, [rsp+0x30]
00007b00b77d895e  mov r8d, 0x00
00007b00b77d8964  lea r9, [r15+0x3A8]
00007b00b77d896b  movaps [rdi], xmm7
00007b00b77d896e  movaps [rsi], xmm2
00007b00b77d8971  movaps [rdx], xmm9
00007b00b77d8975  movaps [rcx], xmm11
00007b00b77d8979  mov rax, 0x612A23581A50
00007b00b77d8983  call rax
00007b00b77d8985  movaps xmm7, [rsp]
00007b00b77d8989  add rsp, 0x40
00007b00b77d898d  vmovaps xmm0, [rsp]
00007b00b77d8992  vmovaps xmm1, [rsp+0x10]
00007b00b77d8998  vmovaps xmm2, [rsp+0x20]
00007b00b77d899e  vmovaps xmm3, [rsp+0x30]
00007b00b77d89a4  vmovaps xmm4, [rsp+0x40]
00007b00b77d89aa  vmovaps xmm5, [rsp+0x50]
00007b00b77d89b0  vmovaps xmm6, [rsp+0x60]
00007b00b77d89b6  vmovaps xmm8, [rsp+0x70]
00007b00b77d89bc  vmovaps xmm9, [rsp+0x80]
00007b00b77d89c5  vmovaps xmm10, [rsp+0x90]
00007b00b77d89ce  vmovaps xmm11, [rsp+0xA0]
00007b00b77d89d7  vmovaps xmm12, [rsp+0xB0]
00007b00b77d89e0  vmovaps xmm13, [rsp+0xC0]
00007b00b77d89e9  vmovaps xmm14, [rsp+0xD0]
00007b00b77d89f2  vmovaps xmm15, [rsp+0xE0]
00007b00b77d89fb  add rsp, 0xF0
00007b00b77d8a02  pop r11
00007b00b77d8a04  pop r10
00007b00b77d8a06  pop r9
00007b00b77d8a08  pop r8
00007b00b77d8a0a  pop rsi
00007b00b77d8a0b  pop rdi
00007b00b77d8a0c  pop rdx
00007b00b77d8a0d  pop rcx
00007b00b77d8a0e  pop rax
00007b00b77d8a0f  add rsp, 0x08
00007b00b77d8a13  jmp 0x00007B00B77D6A96
00007b00b77d8a18  sub rsp, 0x08
00007b00b77d8a1c  push rax
00007b00b77d8a1d  push rcx
00007b00b77d8a1e  push rdx
00007b00b77d8a1f  push rdi
00007b00b77d8a20  push rsi
00007b00b77d8a21  push r8
00007b00b77d8a23  push r9
00007b00b77d8a25  push r10
00007b00b77d8a27  push r11
00007b00b77d8a29  sub rsp, 0xF0
00007b00b77d8a30  vmovaps [rsp], xmm0
00007b00b77d8a35  vmovaps [rsp+0x10], xmm1
00007b00b77d8a3b  vmovaps [rsp+0x20], xmm2
00007b00b77d8a41  vmovaps [rsp+0x30], xmm3
00007b00b77d8a47  vmovaps [rsp+0x40], xmm4
00007b00b77d8a4d  vmovaps [rsp+0x50], xmm5
00007b00b77d8a53  vmovaps [rsp+0x60], xmm6
00007b00b77d8a59  vmovaps [rsp+0x70], xmm7
00007b00b77d8a5f  vmovaps [rsp+0x80], xmm8
00007b00b77d8a68  vmovaps [rsp+0x90], xmm10
00007b00b77d8a71  vmovaps [rsp+0xA0], xmm11
00007b00b77d8a7a  vmovaps [rsp+0xB0], xmm12
00007b00b77d8a83  vmovaps [rsp+0xC0], xmm13
00007b00b77d8a8c  vmovaps [rsp+0xD0], xmm14
00007b00b77d8a95  vmovaps [rsp+0xE0], xmm15
00007b00b77d8a9e  sub rsp, 0x40
00007b00b77d8aa2  lea rdi, [rsp]
00007b00b77d8aa6  lea rsi, [rsp+0x10]
00007b00b77d8aab  lea rdx, [rsp+0x20]
00007b00b77d8ab0  lea rcx, [rsp+0x30]
00007b00b77d8ab5  mov r8d, 0x00
00007b00b77d8abb  lea r9, [r15+0x3A8]
00007b00b77d8ac2  movaps [rdi], xmm9
00007b00b77d8ac6  movaps [rsi], xmm6
00007b00b77d8ac9  movaps [rdx], xmm1
00007b00b77d8acc  movaps [rcx], xmm11
00007b00b77d8ad0  mov rax, 0x612A23581A50
00007b00b77d8ada  call rax
00007b00b77d8adc  movaps xmm9, [rsp]
00007b00b77d8ae1  add rsp, 0x40
00007b00b77d8ae5  vmovaps xmm0, [rsp]
00007b00b77d8aea  vmovaps xmm1, [rsp+0x10]
00007b00b77d8af0  vmovaps xmm2, [rsp+0x20]
00007b00b77d8af6  vmovaps xmm3, [rsp+0x30]
00007b00b77d8afc  vmovaps xmm4, [rsp+0x40]
00007b00b77d8b02  vmovaps xmm5, [rsp+0x50]
00007b00b77d8b08  vmovaps xmm6, [rsp+0x60]
00007b00b77d8b0e  vmovaps xmm7, [rsp+0x70]
00007b00b77d8b14  vmovaps xmm8, [rsp+0x80]
00007b00b77d8b1d  vmovaps xmm10, [rsp+0x90]
00007b00b77d8b26  vmovaps xmm11, [rsp+0xA0]
00007b00b77d8b2f  vmovaps xmm12, [rsp+0xB0]
00007b00b77d8b38  vmovaps xmm13, [rsp+0xC0]
00007b00b77d8b41  vmovaps xmm14, [rsp+0xD0]
00007b00b77d8b4a  vmovaps xmm15, [rsp+0xE0]
00007b00b77d8b53  add rsp, 0xF0
00007b00b77d8b5a  pop r11
00007b00b77d8b5c  pop r10
00007b00b77d8b5e  pop r9
00007b00b77d8b60  pop r8
00007b00b77d8b62  pop rsi
00007b00b77d8b63  pop rdi
00007b00b77d8b64  pop rdx
00007b00b77d8b65  pop rcx
00007b00b77d8b66  pop rax
00007b00b77d8b67  add rsp, 0x08
00007b00b77d8b6b  jmp 0x00007B00B77D6ABC
00007b00b77d8b70  sub rsp, 0x08
00007b00b77d8b74  push rax
00007b00b77d8b75  push rcx
00007b00b77d8b76  push rdx
00007b00b77d8b77  push rdi
00007b00b77d8b78  push rsi
00007b00b77d8b79  push r8
00007b00b77d8b7b  push r9
00007b00b77d8b7d  push r10
00007b00b77d8b7f  push r11
00007b00b77d8b81  sub rsp, 0xF0
00007b00b77d8b88  vmovaps [rsp], xmm0
00007b00b77d8b8d  vmovaps [rsp+0x10], xmm1
00007b00b77d8b93  vmovaps [rsp+0x20], xmm2
00007b00b77d8b99  vmovaps [rsp+0x30], xmm3
00007b00b77d8b9f  vmovaps [rsp+0x40], xmm4
00007b00b77d8ba5  vmovaps [rsp+0x50], xmm5
00007b00b77d8bab  vmovaps [rsp+0x60], xmm6
00007b00b77d8bb1  vmovaps [rsp+0x70], xmm7
00007b00b77d8bb7  vmovaps [rsp+0x80], xmm8
00007b00b77d8bc0  vmovaps [rsp+0x90], xmm9
00007b00b77d8bc9  vmovaps [rsp+0xA0], xmm10
00007b00b77d8bd2  vmovaps [rsp+0xB0], xmm12
00007b00b77d8bdb  vmovaps [rsp+0xC0], xmm13
00007b00b77d8be4  vmovaps [rsp+0xD0], xmm14
00007b00b77d8bed  vmovaps [rsp+0xE0], xmm15
00007b00b77d8bf6  sub rsp, 0x40
00007b00b77d8bfa  lea rdi, [rsp]
00007b00b77d8bfe  lea rsi, [rsp+0x10]
00007b00b77d8c03  lea rdx, [rsp+0x20]
00007b00b77d8c08  lea rcx, [rsp+0x30]
00007b00b77d8c0d  mov r8d, 0x00
00007b00b77d8c13  lea r9, [r15+0x3A8]
00007b00b77d8c1a  movaps [rdi], xmm11
00007b00b77d8c1e  movaps [rsi], xmm10
00007b00b77d8c22  movaps [rdx], xmm8
00007b00b77d8c26  movaps [rcx], xmm1
00007b00b77d8c29  mov rax, 0x612A23581A50
00007b00b77d8c33  call rax
00007b00b77d8c35  movaps xmm11, [rsp]
00007b00b77d8c3a  add rsp, 0x40
00007b00b77d8c3e  vmovaps xmm0, [rsp]
00007b00b77d8c43  vmovaps xmm1, [rsp+0x10]
00007b00b77d8c49  vmovaps xmm2, [rsp+0x20]
00007b00b77d8c4f  vmovaps xmm3, [rsp+0x30]
00007b00b77d8c55  vmovaps xmm4, [rsp+0x40]
00007b00b77d8c5b  vmovaps xmm5, [rsp+0x50]
00007b00b77d8c61  vmovaps xmm6, [rsp+0x60]
00007b00b77d8c67  vmovaps xmm7, [rsp+0x70]
00007b00b77d8c6d  vmovaps xmm8, [rsp+0x80]
00007b00b77d8c76  vmovaps xmm9, [rsp+0x90]
00007b00b77d8c7f  vmovaps xmm10, [rsp+0xA0]
00007b00b77d8c88  vmovaps xmm12, [rsp+0xB0]
00007b00b77d8c91  vmovaps xmm13, [rsp+0xC0]
00007b00b77d8c9a  vmovaps xmm14, [rsp+0xD0]
00007b00b77d8ca3  vmovaps xmm15, [rsp+0xE0]
00007b00b77d8cac  add rsp, 0xF0
00007b00b77d8cb3  pop r11
00007b00b77d8cb5  pop r10
00007b00b77d8cb7  pop r9
00007b00b77d8cb9  pop r8
00007b00b77d8cbb  pop rsi
00007b00b77d8cbc  pop rdi
00007b00b77d8cbd  pop rdx
00007b00b77d8cbe  pop rcx
00007b00b77d8cbf  pop rax
00007b00b77d8cc0  add rsp, 0x08
00007b00b77d8cc4  jmp 0x00007B00B77D6AE2
00007b00b77d8cc9  sub rsp, 0x08
00007b00b77d8ccd  push rax
00007b00b77d8cce  push rcx
00007b00b77d8ccf  push rdx
00007b00b77d8cd0  push rdi
00007b00b77d8cd1  push rsi
00007b00b77d8cd2  push r8
00007b00b77d8cd4  push r9
00007b00b77d8cd6  push r10
00007b00b77d8cd8  push r11
00007b00b77d8cda  sub rsp, 0xF0
00007b00b77d8ce1  vmovaps [rsp], xmm0
00007b00b77d8ce6  vmovaps [rsp+0x10], xmm1
00007b00b77d8cec  vmovaps [rsp+0x20], xmm2
00007b00b77d8cf2  vmovaps [rsp+0x30], xmm3
00007b00b77d8cf8  vmovaps [rsp+0x40], xmm4
00007b00b77d8cfe  vmovaps [rsp+0x50], xmm5
00007b00b77d8d04  vmovaps [rsp+0x60], xmm6
00007b00b77d8d0a  vmovaps [rsp+0x70], xmm7
00007b00b77d8d10  vmovaps [rsp+0x80], xmm8
00007b00b77d8d19  vmovaps [rsp+0x90], xmm9
00007b00b77d8d22  vmovaps [rsp+0xA0], xmm11
00007b00b77d8d2b  vmovaps [rsp+0xB0], xmm12
00007b00b77d8d34  vmovaps [rsp+0xC0], xmm13
00007b00b77d8d3d  vmovaps [rsp+0xD0], xmm14
00007b00b77d8d46  vmovaps [rsp+0xE0], xmm15
00007b00b77d8d4f  sub rsp, 0x40
00007b00b77d8d53  lea rdi, [rsp]
00007b00b77d8d57  lea rsi, [rsp+0x10]
00007b00b77d8d5c  lea rdx, [rsp+0x20]
00007b00b77d8d61  lea rcx, [rsp+0x30]
00007b00b77d8d66  mov r8d, 0x00
00007b00b77d8d6c  lea r9, [r15+0x3A8]
00007b00b77d8d73  movaps [rdi], xmm10
00007b00b77d8d77  movaps [rsi], xmm12
00007b00b77d8d7b  movaps [rdx], xmm13
00007b00b77d8d7f  movaps [rcx], xmm1
00007b00b77d8d82  mov rax, 0x612A23581A50
00007b00b77d8d8c  call rax
00007b00b77d8d8e  movaps xmm10, [rsp]
00007b00b77d8d93  add rsp, 0x40
00007b00b77d8d97  vmovaps xmm0, [rsp]
00007b00b77d8d9c  vmovaps xmm1, [rsp+0x10]
00007b00b77d8da2  vmovaps xmm2, [rsp+0x20]
00007b00b77d8da8  vmovaps xmm3, [rsp+0x30]
00007b00b77d8dae  vmovaps xmm4, [rsp+0x40]
00007b00b77d8db4  vmovaps xmm5, [rsp+0x50]
00007b00b77d8dba  vmovaps xmm6, [rsp+0x60]
00007b00b77d8dc0  vmovaps xmm7, [rsp+0x70]
00007b00b77d8dc6  vmovaps xmm8, [rsp+0x80]
00007b00b77d8dcf  vmovaps xmm9, [rsp+0x90]
00007b00b77d8dd8  vmovaps xmm11, [rsp+0xA0]
00007b00b77d8de1  vmovaps xmm12, [rsp+0xB0]
00007b00b77d8dea  vmovaps xmm13, [rsp+0xC0]
00007b00b77d8df3  vmovaps xmm14, [rsp+0xD0]
00007b00b77d8dfc  vmovaps xmm15, [rsp+0xE0]
00007b00b77d8e05  add rsp, 0xF0
00007b00b77d8e0c  pop r11
00007b00b77d8e0e  pop r10
00007b00b77d8e10  pop r9
00007b00b77d8e12  pop r8
00007b00b77d8e14  pop rsi
00007b00b77d8e15  pop rdi
00007b00b77d8e16  pop rdx
00007b00b77d8e17  pop rcx
00007b00b77d8e18  pop rax
00007b00b77d8e19  add rsp, 0x08
00007b00b77d8e1d  jmp 0x00007B00B77D6B08
00007b00b77d8e22  call 0x00007B00B76D64F0
00007b00b77d8e27  jmp 0x00007B00B77D6B12
00007b00b77d8e2c  call 0x00007B00B76E3320
00007b00b77d8e31  jmp 0x00007B00B77D6B1C
00007b00b77d8e36  sub rsp, 0x08
00007b00b77d8e3a  push rax
00007b00b77d8e3b  push rcx
00007b00b77d8e3c  push rdx
00007b00b77d8e3d  push rdi
00007b00b77d8e3e  push rsi
00007b00b77d8e3f  push r8
00007b00b77d8e41  push r9
00007b00b77d8e43  push r10
00007b00b77d8e45  push r11
00007b00b77d8e47  sub rsp, 0xF0
00007b00b77d8e4e  vmovaps [rsp], xmm0
00007b00b77d8e53  vmovaps [rsp+0x10], xmm1
00007b00b77d8e59  vmovaps [rsp+0x20], xmm2
00007b00b77d8e5f  vmovaps [rsp+0x30], xmm3
00007b00b77d8e65  vmovaps [rsp+0x40], xmm4
00007b00b77d8e6b  vmovaps [rsp+0x50], xmm5
00007b00b77d8e71  vmovaps [rsp+0x60], xmm6
00007b00b77d8e77  vmovaps [rsp+0x70], xmm7
00007b00b77d8e7d  vmovaps [rsp+0x80], xmm9
00007b00b77d8e86  vmovaps [rsp+0x90], xmm10
00007b00b77d8e8f  vmovaps [rsp+0xA0], xmm11
00007b00b77d8e98  vmovaps [rsp+0xB0], xmm12
00007b00b77d8ea1  vmovaps [rsp+0xC0], xmm13
00007b00b77d8eaa  vmovaps [rsp+0xD0], xmm14
00007b00b77d8eb3  vmovaps [rsp+0xE0], xmm15
00007b00b77d8ebc  sub rsp, 0x40
00007b00b77d8ec0  lea rdi, [rsp]
00007b00b77d8ec4  lea rsi, [rsp+0x10]
00007b00b77d8ec9  lea rdx, [rsp+0x20]
00007b00b77d8ece  lea rcx, [rsp+0x30]
00007b00b77d8ed3  mov r8d, 0x00
00007b00b77d8ed9  lea r9, [r15+0x3A8]
00007b00b77d8ee0  movaps [rdi], xmm8
00007b00b77d8ee4  movaps [rsi], xmm7
00007b00b77d8ee7  movaps [rdx], xmm4
00007b00b77d8eea  movaps [rcx], xmm12
00007b00b77d8eee  mov rax, 0x612A23581A50
00007b00b77d8ef8  call rax
00007b00b77d8efa  movaps xmm8, [rsp]
00007b00b77d8eff  add rsp, 0x40
00007b00b77d8f03  vmovaps xmm0, [rsp]
00007b00b77d8f08  vmovaps xmm1, [rsp+0x10]
00007b00b77d8f0e  vmovaps xmm2, [rsp+0x20]
00007b00b77d8f14  vmovaps xmm3, [rsp+0x30]
00007b00b77d8f1a  vmovaps xmm4, [rsp+0x40]
00007b00b77d8f20  vmovaps xmm5, [rsp+0x50]
00007b00b77d8f26  vmovaps xmm6, [rsp+0x60]
00007b00b77d8f2c  vmovaps xmm7, [rsp+0x70]
00007b00b77d8f32  vmovaps xmm9, [rsp+0x80]
00007b00b77d8f3b  vmovaps xmm10, [rsp+0x90]
00007b00b77d8f44  vmovaps xmm11, [rsp+0xA0]
00007b00b77d8f4d  vmovaps xmm12, [rsp+0xB0]
00007b00b77d8f56  vmovaps xmm13, [rsp+0xC0]
00007b00b77d8f5f  vmovaps xmm14, [rsp+0xD0]
00007b00b77d8f68  vmovaps xmm15, [rsp+0xE0]
00007b00b77d8f71  add rsp, 0xF0
00007b00b77d8f78  pop r11
00007b00b77d8f7a  pop r10
00007b00b77d8f7c  pop r9
00007b00b77d8f7e  pop r8
00007b00b77d8f80  pop rsi
00007b00b77d8f81  pop rdi
00007b00b77d8f82  pop rdx
00007b00b77d8f83  pop rcx
00007b00b77d8f84  pop rax
00007b00b77d8f85  add rsp, 0x08
00007b00b77d8f89  jmp 0x00007B00B77D6B45
00007b00b77d8f8e  sub rsp, 0x08
00007b00b77d8f92  push rax
00007b00b77d8f93  push rcx
00007b00b77d8f94  push rdx
00007b00b77d8f95  push rdi
00007b00b77d8f96  push rsi
00007b00b77d8f97  push r8
00007b00b77d8f99  push r9
00007b00b77d8f9b  push r10
00007b00b77d8f9d  push r11
00007b00b77d8f9f  sub rsp, 0xF0
00007b00b77d8fa6  vmovaps [rsp], xmm0
00007b00b77d8fab  vmovaps [rsp+0x10], xmm1
00007b00b77d8fb1  vmovaps [rsp+0x20], xmm2
00007b00b77d8fb7  vmovaps [rsp+0x30], xmm3
00007b00b77d8fbd  vmovaps [rsp+0x40], xmm4
00007b00b77d8fc3  vmovaps [rsp+0x50], xmm5
00007b00b77d8fc9  vmovaps [rsp+0x60], xmm6
00007b00b77d8fcf  vmovaps [rsp+0x70], xmm8
00007b00b77d8fd5  vmovaps [rsp+0x80], xmm9
00007b00b77d8fde  vmovaps [rsp+0x90], xmm10
00007b00b77d8fe7  vmovaps [rsp+0xA0], xmm11
00007b00b77d8ff0  vmovaps [rsp+0xB0], xmm12
00007b00b77d8ff9  vmovaps [rsp+0xC0], xmm13
00007b00b77d9002  vmovaps [rsp+0xD0], xmm14
00007b00b77d900b  vmovaps [rsp+0xE0], xmm15
00007b00b77d9014  sub rsp, 0x40
00007b00b77d9018  lea rdi, [rsp]
00007b00b77d901c  lea rsi, [rsp+0x10]
00007b00b77d9021  lea rdx, [rsp+0x20]
00007b00b77d9026  lea rcx, [rsp+0x30]
00007b00b77d902b  mov r8d, 0x00
00007b00b77d9031  lea r9, [r15+0x3A8]
00007b00b77d9038  movaps [rdi], xmm7
00007b00b77d903b  movaps [rsi], xmm9
00007b00b77d903f  movaps [rdx], xmm14
00007b00b77d9043  movaps [rcx], xmm12
00007b00b77d9047  mov rax, 0x612A23581A50
00007b00b77d9051  call rax
00007b00b77d9053  movaps xmm7, [rsp]
00007b00b77d9057  add rsp, 0x40
00007b00b77d905b  vmovaps xmm0, [rsp]
00007b00b77d9060  vmovaps xmm1, [rsp+0x10]
00007b00b77d9066  vmovaps xmm2, [rsp+0x20]
00007b00b77d906c  vmovaps xmm3, [rsp+0x30]
00007b00b77d9072  vmovaps xmm4, [rsp+0x40]
00007b00b77d9078  vmovaps xmm5, [rsp+0x50]
00007b00b77d907e  vmovaps xmm6, [rsp+0x60]
00007b00b77d9084  vmovaps xmm8, [rsp+0x70]
00007b00b77d908a  vmovaps xmm9, [rsp+0x80]
00007b00b77d9093  vmovaps xmm10, [rsp+0x90]
00007b00b77d909c  vmovaps xmm11, [rsp+0xA0]
00007b00b77d90a5  vmovaps xmm12, [rsp+0xB0]
00007b00b77d90ae  vmovaps xmm13, [rsp+0xC0]
00007b00b77d90b7  vmovaps xmm14, [rsp+0xD0]
00007b00b77d90c0  vmovaps xmm15, [rsp+0xE0]
00007b00b77d90c9  add rsp, 0xF0
00007b00b77d90d0  pop r11
00007b00b77d90d2  pop r10
00007b00b77d90d4  pop r9
00007b00b77d90d6  pop r8
00007b00b77d90d8  pop rsi
00007b00b77d90d9  pop rdi
00007b00b77d90da  pop rdx
00007b00b77d90db  pop rcx
00007b00b77d90dc  pop rax
00007b00b77d90dd  add rsp, 0x08
00007b00b77d90e1  jmp 0x00007B00B77D6B6D
00007b00b77d90e6  sub rsp, 0x08
00007b00b77d90ea  push rax
00007b00b77d90eb  push rcx
00007b00b77d90ec  push rdx
00007b00b77d90ed  push rdi
00007b00b77d90ee  push rsi
00007b00b77d90ef  push r8
00007b00b77d90f1  push r9
00007b00b77d90f3  push r10
00007b00b77d90f5  push r11
00007b00b77d90f7  sub rsp, 0xF0
00007b00b77d90fe  vmovaps [rsp], xmm0
00007b00b77d9103  vmovaps [rsp+0x10], xmm1
00007b00b77d9109  vmovaps [rsp+0x20], xmm2
00007b00b77d910f  vmovaps [rsp+0x30], xmm3
00007b00b77d9115  vmovaps [rsp+0x40], xmm4
00007b00b77d911b  vmovaps [rsp+0x50], xmm5
00007b00b77d9121  vmovaps [rsp+0x60], xmm6
00007b00b77d9127  vmovaps [rsp+0x70], xmm7
00007b00b77d912d  vmovaps [rsp+0x80], xmm8
00007b00b77d9136  vmovaps [rsp+0x90], xmm9
00007b00b77d913f  vmovaps [rsp+0xA0], xmm10
00007b00b77d9148  vmovaps [rsp+0xB0], xmm11
00007b00b77d9151  vmovaps [rsp+0xC0], xmm13
00007b00b77d915a  vmovaps [rsp+0xD0], xmm14
00007b00b77d9163  vmovaps [rsp+0xE0], xmm15
00007b00b77d916c  sub rsp, 0x40
00007b00b77d9170  lea rdi, [rsp]
00007b00b77d9174  lea rsi, [rsp+0x10]
00007b00b77d9179  lea rdx, [rsp+0x20]
00007b00b77d917e  lea rcx, [rsp+0x30]
00007b00b77d9183  mov r8d, 0x00
00007b00b77d9189  lea r9, [r15+0x3A8]
00007b00b77d9190  movaps [rdi], xmm12
00007b00b77d9194  movaps [rsi], xmm11
00007b00b77d9198  movaps [rdx], xmm15
00007b00b77d919c  movaps [rcx], xmm14
00007b00b77d91a0  mov rax, 0x612A23581A50
00007b00b77d91aa  call rax
00007b00b77d91ac  movaps xmm12, [rsp]
00007b00b77d91b1  add rsp, 0x40
00007b00b77d91b5  vmovaps xmm0, [rsp]
00007b00b77d91ba  vmovaps xmm1, [rsp+0x10]
00007b00b77d91c0  vmovaps xmm2, [rsp+0x20]
00007b00b77d91c6  vmovaps xmm3, [rsp+0x30]
00007b00b77d91cc  vmovaps xmm4, [rsp+0x40]
00007b00b77d91d2  vmovaps xmm5, [rsp+0x50]
00007b00b77d91d8  vmovaps xmm6, [rsp+0x60]
00007b00b77d91de  vmovaps xmm7, [rsp+0x70]
00007b00b77d91e4  vmovaps xmm8, [rsp+0x80]
00007b00b77d91ed  vmovaps xmm9, [rsp+0x90]
00007b00b77d91f6  vmovaps xmm10, [rsp+0xA0]
00007b00b77d91ff  vmovaps xmm11, [rsp+0xB0]
00007b00b77d9208  vmovaps xmm13, [rsp+0xC0]
00007b00b77d9211  vmovaps xmm14, [rsp+0xD0]
00007b00b77d921a  vmovaps xmm15, [rsp+0xE0]
00007b00b77d9223  add rsp, 0xF0
00007b00b77d922a  pop r11
00007b00b77d922c  pop r10
00007b00b77d922e  pop r9
00007b00b77d9230  pop r8
00007b00b77d9232  pop rsi
00007b00b77d9233  pop rdi
00007b00b77d9234  pop rdx
00007b00b77d9235  pop rcx
00007b00b77d9236  pop rax
00007b00b77d9237  add rsp, 0x08
00007b00b77d923b  jmp 0x00007B00B77D6B96
00007b00b77d9240  sub rsp, 0x08
00007b00b77d9244  push rax
00007b00b77d9245  push rcx
00007b00b77d9246  push rdx
00007b00b77d9247  push rdi
00007b00b77d9248  push rsi
00007b00b77d9249  push r8
00007b00b77d924b  push r9
00007b00b77d924d  push r10
00007b00b77d924f  push r11
00007b00b77d9251  sub rsp, 0xF0
00007b00b77d9258  vmovaps [rsp], xmm0
00007b00b77d925d  vmovaps [rsp+0x10], xmm1
00007b00b77d9263  vmovaps [rsp+0x20], xmm2
00007b00b77d9269  vmovaps [rsp+0x30], xmm3
00007b00b77d926f  vmovaps [rsp+0x40], xmm4
00007b00b77d9275  vmovaps [rsp+0x50], xmm5
00007b00b77d927b  vmovaps [rsp+0x60], xmm6
00007b00b77d9281  vmovaps [rsp+0x70], xmm7
00007b00b77d9287  vmovaps [rsp+0x80], xmm8
00007b00b77d9290  vmovaps [rsp+0x90], xmm9
00007b00b77d9299  vmovaps [rsp+0xA0], xmm10
00007b00b77d92a2  vmovaps [rsp+0xB0], xmm12
00007b00b77d92ab  vmovaps [rsp+0xC0], xmm13
00007b00b77d92b4  vmovaps [rsp+0xD0], xmm14
00007b00b77d92bd  vmovaps [rsp+0xE0], xmm15
00007b00b77d92c6  sub rsp, 0x40
00007b00b77d92ca  lea rdi, [rsp]
00007b00b77d92ce  lea rsi, [rsp+0x10]
00007b00b77d92d3  lea rdx, [rsp+0x20]
00007b00b77d92d8  lea rcx, [rsp+0x30]
00007b00b77d92dd  mov r8d, 0x00
00007b00b77d92e3  lea r9, [r15+0x3A8]
00007b00b77d92ea  movaps [rdi], xmm11
00007b00b77d92ee  movaps [rsi], xmm10
00007b00b77d92f2  movaps [rdx], xmm13
00007b00b77d92f6  movaps [rcx], xmm15
00007b00b77d92fa  mov rax, 0x612A23581A50
00007b00b77d9304  call rax
00007b00b77d9306  movaps xmm11, [rsp]
00007b00b77d930b  add rsp, 0x40
00007b00b77d930f  vmovaps xmm0, [rsp]
00007b00b77d9314  vmovaps xmm1, [rsp+0x10]
00007b00b77d931a  vmovaps xmm2, [rsp+0x20]
00007b00b77d9320  vmovaps xmm3, [rsp+0x30]
00007b00b77d9326  vmovaps xmm4, [rsp+0x40]
00007b00b77d932c  vmovaps xmm5, [rsp+0x50]
00007b00b77d9332  vmovaps xmm6, [rsp+0x60]
00007b00b77d9338  vmovaps xmm7, [rsp+0x70]
00007b00b77d933e  vmovaps xmm8, [rsp+0x80]
00007b00b77d9347  vmovaps xmm9, [rsp+0x90]
00007b00b77d9350  vmovaps xmm10, [rsp+0xA0]
00007b00b77d9359  vmovaps xmm12, [rsp+0xB0]
00007b00b77d9362  vmovaps xmm13, [rsp+0xC0]
00007b00b77d936b  vmovaps xmm14, [rsp+0xD0]
00007b00b77d9374  vmovaps xmm15, [rsp+0xE0]
00007b00b77d937d  add rsp, 0xF0
00007b00b77d9384  pop r11
00007b00b77d9386  pop r10
00007b00b77d9388  pop r9
00007b00b77d938a  pop r8
00007b00b77d938c  pop rsi
00007b00b77d938d  pop rdi
00007b00b77d938e  pop rdx
00007b00b77d938f  pop rcx
00007b00b77d9390  pop rax
00007b00b77d9391  add rsp, 0x08
00007b00b77d9395  jmp 0x00007B00B77D6BBF
00007b00b77d939a  call 0x00007B00B76E5820
00007b00b77d939f  jmp 0x00007B00B77D6BCC
00007b00b77d93a4  call 0x00007B00B76E45A0
00007b00b77d93a9  jmp 0x00007B00B77D6BD9
00007b00b77d93ae  sub rsp, 0x08
00007b00b77d93b2  push rax
00007b00b77d93b3  push rcx
00007b00b77d93b4  push rdx
00007b00b77d93b5  push rdi
00007b00b77d93b6  push rsi
00007b00b77d93b7  push r8
00007b00b77d93b9  push r9
00007b00b77d93bb  push r10
00007b00b77d93bd  push r11
00007b00b77d93bf  sub rsp, 0xF0
00007b00b77d93c6  vmovaps [rsp], xmm0
00007b00b77d93cb  vmovaps [rsp+0x10], xmm1
00007b00b77d93d1  vmovaps [rsp+0x20], xmm2
00007b00b77d93d7  vmovaps [rsp+0x30], xmm3
00007b00b77d93dd  vmovaps [rsp+0x40], xmm4
00007b00b77d93e3  vmovaps [rsp+0x50], xmm5
00007b00b77d93e9  vmovaps [rsp+0x60], xmm6
00007b00b77d93ef  vmovaps [rsp+0x70], xmm7
00007b00b77d93f5  vmovaps [rsp+0x80], xmm8
00007b00b77d93fe  vmovaps [rsp+0x90], xmm9
00007b00b77d9407  vmovaps [rsp+0xA0], xmm11
00007b00b77d9410  vmovaps [rsp+0xB0], xmm12
00007b00b77d9419  vmovaps [rsp+0xC0], xmm13
00007b00b77d9422  vmovaps [rsp+0xD0], xmm14
00007b00b77d942b  vmovaps [rsp+0xE0], xmm15
00007b00b77d9434  sub rsp, 0x40
00007b00b77d9438  lea rdi, [rsp]
00007b00b77d943c  lea rsi, [rsp+0x10]
00007b00b77d9441  lea rdx, [rsp+0x20]
00007b00b77d9446  lea rcx, [rsp+0x30]
00007b00b77d944b  mov r8d, 0x00
00007b00b77d9451  lea r9, [r15+0x3A8]
00007b00b77d9458  movaps [rdi], xmm10
00007b00b77d945c  movaps [rsi], xmm8
00007b00b77d9460  movaps [rdx], xmm1
00007b00b77d9463  movaps [rcx], xmm13
00007b00b77d9467  mov rax, 0x612A23581A50
00007b00b77d9471  call rax
00007b00b77d9473  movaps xmm10, [rsp]
00007b00b77d9478  add rsp, 0x40
00007b00b77d947c  vmovaps xmm0, [rsp]
00007b00b77d9481  vmovaps xmm1, [rsp+0x10]
00007b00b77d9487  vmovaps xmm2, [rsp+0x20]
00007b00b77d948d  vmovaps xmm3, [rsp+0x30]
00007b00b77d9493  vmovaps xmm4, [rsp+0x40]
00007b00b77d9499  vmovaps xmm5, [rsp+0x50]
00007b00b77d949f  vmovaps xmm6, [rsp+0x60]
00007b00b77d94a5  vmovaps xmm7, [rsp+0x70]
00007b00b77d94ab  vmovaps xmm8, [rsp+0x80]
00007b00b77d94b4  vmovaps xmm9, [rsp+0x90]
00007b00b77d94bd  vmovaps xmm11, [rsp+0xA0]
00007b00b77d94c6  vmovaps xmm12, [rsp+0xB0]
00007b00b77d94cf  vmovaps xmm13, [rsp+0xC0]
00007b00b77d94d8  vmovaps xmm14, [rsp+0xD0]
00007b00b77d94e1  vmovaps xmm15, [rsp+0xE0]
00007b00b77d94ea  add rsp, 0xF0
00007b00b77d94f1  pop r11
00007b00b77d94f3  pop r10
00007b00b77d94f5  pop r9
00007b00b77d94f7  pop r8
00007b00b77d94f9  pop rsi
00007b00b77d94fa  pop rdi
00007b00b77d94fb  pop rdx
00007b00b77d94fc  pop rcx
00007b00b77d94fd  pop rax
00007b00b77d94fe  add rsp, 0x08
00007b00b77d9502  jmp 0x00007B00B77D6C0F
00007b00b77d9507  call 0x00007B00B76D64F0
00007b00b77d950c  jmp 0x00007B00B77D6C21
00007b00b77d9511  sub rsp, 0x08
00007b00b77d9515  push rax
00007b00b77d9516  push rcx
00007b00b77d9517  push rdx
00007b00b77d9518  push rdi
00007b00b77d9519  push rsi
00007b00b77d951a  push r8
00007b00b77d951c  push r9
00007b00b77d951e  push r10
00007b00b77d9520  push r11
00007b00b77d9522  sub rsp, 0xF0
00007b00b77d9529  vmovaps [rsp], xmm0
00007b00b77d952e  vmovaps [rsp+0x10], xmm1
00007b00b77d9534  vmovaps [rsp+0x20], xmm2
00007b00b77d953a  vmovaps [rsp+0x30], xmm3
00007b00b77d9540  vmovaps [rsp+0x40], xmm4
00007b00b77d9546  vmovaps [rsp+0x50], xmm5
00007b00b77d954c  vmovaps [rsp+0x60], xmm6
00007b00b77d9552  vmovaps [rsp+0x70], xmm7
00007b00b77d9558  vmovaps [rsp+0x80], xmm8
00007b00b77d9561  vmovaps [rsp+0x90], xmm10
00007b00b77d956a  vmovaps [rsp+0xA0], xmm11
00007b00b77d9573  vmovaps [rsp+0xB0], xmm12
00007b00b77d957c  vmovaps [rsp+0xC0], xmm13
00007b00b77d9585  vmovaps [rsp+0xD0], xmm14
00007b00b77d958e  vmovaps [rsp+0xE0], xmm15
00007b00b77d9597  sub rsp, 0x40
00007b00b77d959b  lea rdi, [rsp]
00007b00b77d959f  lea rsi, [rsp+0x10]
00007b00b77d95a4  lea rdx, [rsp+0x20]
00007b00b77d95a9  lea rcx, [rsp+0x30]
00007b00b77d95ae  mov r8d, 0x00
00007b00b77d95b4  lea r9, [r15+0x3A8]
00007b00b77d95bb  movaps [rdi], xmm9
00007b00b77d95bf  movaps [rsi], xmm7
00007b00b77d95c2  movaps [rdx], xmm14
00007b00b77d95c6  movaps [rcx], xmm13
00007b00b77d95ca  mov rax, 0x612A23581A50
00007b00b77d95d4  call rax
00007b00b77d95d6  movaps xmm9, [rsp]
00007b00b77d95db  add rsp, 0x40
00007b00b77d95df  vmovaps xmm0, [rsp]
00007b00b77d95e4  vmovaps xmm1, [rsp+0x10]
00007b00b77d95ea  vmovaps xmm2, [rsp+0x20]
00007b00b77d95f0  vmovaps xmm3, [rsp+0x30]
00007b00b77d95f6  vmovaps xmm4, [rsp+0x40]
00007b00b77d95fc  vmovaps xmm5, [rsp+0x50]
00007b00b77d9602  vmovaps xmm6, [rsp+0x60]
00007b00b77d9608  vmovaps xmm7, [rsp+0x70]
00007b00b77d960e  vmovaps xmm8, [rsp+0x80]
00007b00b77d9617  vmovaps xmm10, [rsp+0x90]
00007b00b77d9620  vmovaps xmm11, [rsp+0xA0]
00007b00b77d9629  vmovaps xmm12, [rsp+0xB0]
00007b00b77d9632  vmovaps xmm13, [rsp+0xC0]
00007b00b77d963b  vmovaps xmm14, [rsp+0xD0]
00007b00b77d9644  vmovaps xmm15, [rsp+0xE0]
00007b00b77d964d  add rsp, 0xF0
00007b00b77d9654  pop r11
00007b00b77d9656  pop r10
00007b00b77d9658  pop r9
00007b00b77d965a  pop r8
00007b00b77d965c  pop rsi
00007b00b77d965d  pop rdi
00007b00b77d965e  pop rdx
00007b00b77d965f  pop rcx
00007b00b77d9660  pop rax
00007b00b77d9661  add rsp, 0x08
00007b00b77d9665  jmp 0x00007B00B77D6C4F
00007b00b77d966a  sub rsp, 0x08
00007b00b77d966e  push rax
00007b00b77d966f  push rcx
00007b00b77d9670  push rdx
00007b00b77d9671  push rdi
00007b00b77d9672  push rsi
00007b00b77d9673  push r8
00007b00b77d9675  push r9
00007b00b77d9677  push r10
00007b00b77d9679  push r11
00007b00b77d967b  sub rsp, 0xF0
00007b00b77d9682  vmovaps [rsp], xmm0
00007b00b77d9687  vmovaps [rsp+0x10], xmm1
00007b00b77d968d  vmovaps [rsp+0x20], xmm2
00007b00b77d9693  vmovaps [rsp+0x30], xmm3
00007b00b77d9699  vmovaps [rsp+0x40], xmm4
00007b00b77d969f  vmovaps [rsp+0x50], xmm5
00007b00b77d96a5  vmovaps [rsp+0x60], xmm6
00007b00b77d96ab  vmovaps [rsp+0x70], xmm7
00007b00b77d96b1  vmovaps [rsp+0x80], xmm8
00007b00b77d96ba  vmovaps [rsp+0x90], xmm9
00007b00b77d96c3  vmovaps [rsp+0xA0], xmm10
00007b00b77d96cc  vmovaps [rsp+0xB0], xmm11
00007b00b77d96d5  vmovaps [rsp+0xC0], xmm12
00007b00b77d96de  vmovaps [rsp+0xD0], xmm14
00007b00b77d96e7  vmovaps [rsp+0xE0], xmm15
00007b00b77d96f0  sub rsp, 0x40
00007b00b77d96f4  lea rdi, [rsp]
00007b00b77d96f8  lea rsi, [rsp+0x10]
00007b00b77d96fd  lea rdx, [rsp+0x20]
00007b00b77d9702  lea rcx, [rsp+0x30]
00007b00b77d9707  mov r8d, 0x00
00007b00b77d970d  lea r9, [r15+0x3A8]
00007b00b77d9714  movaps [rdi], xmm13
00007b00b77d9718  movaps [rsi], xmm12
00007b00b77d971c  movaps [rdx], xmm15
00007b00b77d9720  movaps [rcx], xmm14
00007b00b77d9724  mov rax, 0x612A23581A50
00007b00b77d972e  call rax
00007b00b77d9730  movaps xmm13, [rsp]
00007b00b77d9735  add rsp, 0x40
00007b00b77d9739  vmovaps xmm0, [rsp]
00007b00b77d973e  vmovaps xmm1, [rsp+0x10]
00007b00b77d9744  vmovaps xmm2, [rsp+0x20]
00007b00b77d974a  vmovaps xmm3, [rsp+0x30]
00007b00b77d9750  vmovaps xmm4, [rsp+0x40]
00007b00b77d9756  vmovaps xmm5, [rsp+0x50]
00007b00b77d975c  vmovaps xmm6, [rsp+0x60]
00007b00b77d9762  vmovaps xmm7, [rsp+0x70]
00007b00b77d9768  vmovaps xmm8, [rsp+0x80]
00007b00b77d9771  vmovaps xmm9, [rsp+0x90]
00007b00b77d977a  vmovaps xmm10, [rsp+0xA0]
00007b00b77d9783  vmovaps xmm11, [rsp+0xB0]
00007b00b77d978c  vmovaps xmm12, [rsp+0xC0]
00007b00b77d9795  vmovaps xmm14, [rsp+0xD0]
00007b00b77d979e  vmovaps xmm15, [rsp+0xE0]
00007b00b77d97a7  add rsp, 0xF0
00007b00b77d97ae  pop r11
00007b00b77d97b0  pop r10
00007b00b77d97b2  pop r9
00007b00b77d97b4  pop r8
00007b00b77d97b6  pop rsi
00007b00b77d97b7  pop rdi
00007b00b77d97b8  pop rdx
00007b00b77d97b9  pop rcx
00007b00b77d97ba  pop rax
00007b00b77d97bb  add rsp, 0x08
00007b00b77d97bf  jmp 0x00007B00B77D6C7D
00007b00b77d97c4  sub rsp, 0x08
00007b00b77d97c8  push rax
00007b00b77d97c9  push rcx
00007b00b77d97ca  push rdx
00007b00b77d97cb  push rdi
00007b00b77d97cc  push rsi
00007b00b77d97cd  push r8
00007b00b77d97cf  push r9
00007b00b77d97d1  push r10
00007b00b77d97d3  push r11
00007b00b77d97d5  sub rsp, 0xF0
00007b00b77d97dc  vmovaps [rsp], xmm0
00007b00b77d97e1  vmovaps [rsp+0x10], xmm1
00007b00b77d97e7  vmovaps [rsp+0x20], xmm2
00007b00b77d97ed  vmovaps [rsp+0x30], xmm3
00007b00b77d97f3  vmovaps [rsp+0x40], xmm4
00007b00b77d97f9  vmovaps [rsp+0x50], xmm5
00007b00b77d97ff  vmovaps [rsp+0x60], xmm6
00007b00b77d9805  vmovaps [rsp+0x70], xmm7
00007b00b77d980b  vmovaps [rsp+0x80], xmm8
00007b00b77d9814  vmovaps [rsp+0x90], xmm9
00007b00b77d981d  vmovaps [rsp+0xA0], xmm10
00007b00b77d9826  vmovaps [rsp+0xB0], xmm11
00007b00b77d982f  vmovaps [rsp+0xC0], xmm12
00007b00b77d9838  vmovaps [rsp+0xD0], xmm13
00007b00b77d9841  vmovaps [rsp+0xE0], xmm15
00007b00b77d984a  sub rsp, 0x40
00007b00b77d984e  lea rdi, [rsp]
00007b00b77d9852  lea rsi, [rsp+0x10]
00007b00b77d9857  lea rdx, [rsp+0x20]
00007b00b77d985c  lea rcx, [rsp+0x30]
00007b00b77d9861  mov r8d, 0x00
00007b00b77d9867  lea r9, [r15+0x3A8]
00007b00b77d986e  movaps [rdi], xmm14
00007b00b77d9872  movaps [rsi], xmm11
00007b00b77d9876  movaps [rdx], xmm1
00007b00b77d9879  movaps [rcx], xmm15
00007b00b77d987d  mov rax, 0x612A23581A50
00007b00b77d9887  call rax
00007b00b77d9889  movaps xmm14, [rsp]
00007b00b77d988e  add rsp, 0x40
00007b00b77d9892  vmovaps xmm0, [rsp]
00007b00b77d9897  vmovaps xmm1, [rsp+0x10]
00007b00b77d989d  vmovaps xmm2, [rsp+0x20]
00007b00b77d98a3  vmovaps xmm3, [rsp+0x30]
00007b00b77d98a9  vmovaps xmm4, [rsp+0x40]
00007b00b77d98af  vmovaps xmm5, [rsp+0x50]
00007b00b77d98b5  vmovaps xmm6, [rsp+0x60]
00007b00b77d98bb  vmovaps xmm7, [rsp+0x70]
00007b00b77d98c1  vmovaps xmm8, [rsp+0x80]
00007b00b77d98ca  vmovaps xmm9, [rsp+0x90]
00007b00b77d98d3  vmovaps xmm10, [rsp+0xA0]
00007b00b77d98dc  vmovaps xmm11, [rsp+0xB0]
00007b00b77d98e5  vmovaps xmm12, [rsp+0xC0]
00007b00b77d98ee  vmovaps xmm13, [rsp+0xD0]
00007b00b77d98f7  vmovaps xmm15, [rsp+0xE0]
00007b00b77d9900  add rsp, 0xF0
00007b00b77d9907  pop r11
00007b00b77d9909  pop r10
00007b00b77d990b  pop r9
00007b00b77d990d  pop r8
00007b00b77d990f  pop rsi
00007b00b77d9910  pop rdi
00007b00b77d9911  pop rdx
00007b00b77d9912  pop rcx
00007b00b77d9913  pop rax
00007b00b77d9914  add rsp, 0x08
00007b00b77d9918  jmp 0x00007B00B77D6CAB
00007b00b77d991d  call 0x00007B00B76ACF70
00007b00b77d9922  jmp 0x00007B00B77D6CB9
00007b00b77d9927  call 0x00007B00B760C380
00007b00b77d992c  jmp 0x00007B00B77D6CC3
00007b00b77d9931  call 0x00007B00B7608C20
00007b00b77d9936  jmp 0x00007B00B77D6CCD
00007b00b77d993b  call 0x00007B00B760D600
00007b00b77d9940  jmp 0x00007B00B77D6CD7
00007b00b77d9945  int3
00007b00b77d9946  nop [rax+rax*1], ax
00007b00b77d994f  nop
00007b00b77d9950  mov eax, [r15+0x48]
00007b00b77d9954  lea r14d, [eax+0x01]
00007b00b77d9959  mov [rsp+0x10], r14d
00007b00b77d995e  mov r14d, r14d
00007b00b77d9961  mov [r15+0x48], r14
00007b00b77d9965  xor eax, eax
00007b00b77d9967  mov r14d, [rsp+0x10]
00007b00b77d996c  cmp r14d, 0x1F4
00007b00b77d9973  cmc
00007b00b77d9974  lahf
00007b00b77d9975  seto al
00007b00b77d9978  mov [r15+0x108], eax
00007b00b77d997f  mov eax, [r15+0x108]
00007b00b77d9986  sahf
00007b00b77d9987  jnz 0x00007B00B77D99B9
00007b00b77d9989  cmp dword ptr [r15+0x318], 0x00
00007b00b77d9991  jz 0x00007B00B77DD2E0
00007b00b77d9997  nop [rax+rax*1], ax
00007b00b77d99a0  nop [rax+rax*1], eax
00007b00b77d99a8  mov eax, 0x410670
00007b00b77d99ad  mov [r15+0x100], rax
00007b00b77d99b4  jmp 0x00007B00B75FE110
00007b00b77d99b9  cmp dword ptr [r15+0x318], 0x00
00007b00b77d99c1  jz 0x00007B00B77D99F0
00007b00b77d99c7  nop [rax+rax*1], ax
00007b00b77d99d0  nop [rax+rax*1], eax
00007b00b77d99d8  mov eax, 0x4104EC
00007b00b77d99dd  mov [r15+0x100], rax
00007b00b77d99e4  jmp 0x00007B00B75FE110
00007b00b77d99e9  int3
00007b00b77d99ea  int3
00007b00b77d99eb  nop [rax+rax*1], eax
00007b00b77d99f0  mov rax, [r15+0x40]
00007b00b77d99f4  vxorps xmm1, xmm1, xmm1
00007b00b77d99f8  vpbroadcastq xmm1, xmm1
00007b00b77d99fd  vxorps xmm15, xmm15, xmm15
00007b00b77d9a02  vpbroadcastq xmm15, xmm15
00007b00b77d9a07  lea r14, [rax+0x30]
00007b00b77d9a0b  mov r12, [r13+r14*1]
00007b00b77d9a10  lea r14, [rax+0x38]
00007b00b77d9a14  mov r11, [r13+r14*1]
00007b00b77d9a19  movq xmm14, r12
00007b00b77d9a1e  movq xmm13, r11
00007b00b77d9a23  movq xmm14, xmm14
00007b00b77d9a28  movq xmm13, xmm13
00007b00b77d9a2d  vmovaps [rsp+0x10], xmm13
00007b00b77d9a33  movq xmm13, xmm13
00007b00b77d9a38  movaps [r15+0x270], xmm13
00007b00b77d9a40  movaps xmm13, [r15+0x160]
00007b00b77d9a48  vmovaps [rsp+0x20], xmm13
00007b00b77d9a4e  vmovaps xmm12, [rsp+0x20]
00007b00b77d9a54  por xmm13, xmm12
00007b00b77d9a59  lea r14, [rax+0x20]
00007b00b77d9a5d  mov r12, [r13+r14*1]
00007b00b77d9a62  lea r14, [rax+0x28]
00007b00b77d9a66  mov r11, [r13+r14*1]
00007b00b77d9a6b  movq xmm12, r12
00007b00b77d9a70  movq xmm11, r11
00007b00b77d9a75  movq xmm12, xmm12
00007b00b77d9a7a  movq xmm11, xmm11
00007b00b77d9a7f  movaps xmm10, [r15+0x2D0]
00007b00b77d9a87  vmovaps [rsp+0x20], xmm10
00007b00b77d9a8d  vmovaps xmm9, [rsp+0x20]
00007b00b77d9a93  por xmm10, xmm9
00007b00b77d9a98  movaps xmm9, [r15+0x300]
00007b00b77d9aa0  vmovaps [rsp+0x20], xmm9
00007b00b77d9aa6  vmovaps xmm8, [rsp+0x20]
00007b00b77d9aac  por xmm9, xmm8
00007b00b77d9ab1  movaps xmm8, [r15+0x2B0]
00007b00b77d9ab9  vmovaps [rsp+0x20], xmm8
00007b00b77d9abf  vmovaps xmm7, [rsp+0x20]
00007b00b77d9ac5  por xmm8, xmm7
00007b00b77d9aca  movaps xmm7, [r15+0x180]
00007b00b77d9ad2  vmovaps [rsp+0x20], xmm7
00007b00b77d9ad8  vmovaps xmm6, [rsp+0x20]
00007b00b77d9ade  por xmm7, xmm6
00007b00b77d9ae2  lea r14, [rax+0x10]
00007b00b77d9ae6  mov r12, [r13+r14*1]
00007b00b77d9aeb  lea r14, [rax+0x18]
00007b00b77d9aef  mov r11, [r13+r14*1]
00007b00b77d9af4  movq xmm6, r12
00007b00b77d9af9  movq xmm5, r11
00007b00b77d9afe  movq xmm6, xmm6
00007b00b77d9b02  movq xmm5, xmm5
00007b00b77d9b06  movaps xmm4, [r15+0x200]
00007b00b77d9b0e  vmovaps [rsp+0x20], xmm4
00007b00b77d9b14  vmovaps xmm3, [rsp+0x20]
00007b00b77d9b1a  por xmm4, xmm3
00007b00b77d9b1e  movaps xmm3, [r15+0x1F0]
00007b00b77d9b26  vmovaps [rsp+0x20], xmm3
00007b00b77d9b2c  vmovaps xmm2, [rsp+0x20]
00007b00b77d9b32  por xmm3, xmm2
00007b00b77d9b36  movaps xmm2, [r15+0x2E0]
00007b00b77d9b3e  vmovaps [rsp+0x20], xmm2
00007b00b77d9b44  vmovaps [rsp+0x30], xmm1
00007b00b77d9b4a  vmovaps xmm1, [rsp+0x20]
00007b00b77d9b50  por xmm2, xmm1
00007b00b77d9b54  movaps xmm1, [r15+0x2A0]
00007b00b77d9b5c  vmovaps [rsp+0x20], xmm1
00007b00b77d9b62  vmovaps [rsp+0x40], xmm15
00007b00b77d9b68  vmovaps xmm15, [rsp+0x20]
00007b00b77d9b6e  por xmm1, xmm15
00007b00b77d9b73  movaps xmm15, [r15+0x280]
00007b00b77d9b7b  vmovaps [rsp+0x20], xmm15
00007b00b77d9b81  vmovaps [rsp+0x50], xmm1
00007b00b77d9b87  vmovaps xmm1, [rsp+0x20]
00007b00b77d9b8d  por xmm15, xmm1
00007b00b77d9b92  movaps xmm1, [r15+0x1C0]
00007b00b77d9b9a  vmovaps [rsp+0x20], xmm1
00007b00b77d9ba0  vmovaps [rsp+0x60], xmm15
00007b00b77d9ba6  vmovaps xmm15, [rsp+0x20]
00007b00b77d9bac  por xmm1, xmm15
00007b00b77d9bb1  movaps xmm15, [r15+0x210]
00007b00b77d9bb9  vmovaps [rsp+0x20], xmm15
00007b00b77d9bbf  vmovaps [rsp+0x70], xmm1
00007b00b77d9bc5  vmovaps xmm1, [rsp+0x20]
00007b00b77d9bcb  por xmm15, xmm1
00007b00b77d9bd0  mov r14, [r13+rax*1]
00007b00b77d9bd5  vmovq xmm1, r14
00007b00b77d9bda  vpbroadcastq xmm1, xmm1
00007b00b77d9bdf  vmovaps [rsp+0x20], xmm1
00007b00b77d9be5  vxorps xmm1, xmm1, xmm1
00007b00b77d9be9  vpbroadcastq xmm1, xmm1
00007b00b77d9bee  mov r14, [r15+0xF8]
00007b00b77d9bf5  vmovaps [rsp+0x80], xmm1
00007b00b77d9bfe  movups xmm1, [r13+r14*1]
00007b00b77d9c04  vmovaps [rsp+0x90], xmm1
00007b00b77d9c0d  vxorps xmm1, xmm1, xmm1
00007b00b77d9c11  vpbroadcastq xmm1, xmm1
00007b00b77d9c16  lea r12, [rax+0x08]
00007b00b77d9c1a  mov rax, [r13+r12*1]
00007b00b77d9c1f  vmovaps [rsp+0xA0], xmm1
00007b00b77d9c28  movq xmm1, rax
00007b00b77d9c2d  movaps [r15+0x240], xmm1
00007b00b77d9c35  mov rax, [r15+0x50]
00007b00b77d9c39  mov [r15+0x60], rax
00007b00b77d9c3d  mov qword ptr [r15+0x58], 0x40
00007b00b77d9c45  vmovaps xmm1, [rsp+0x30]
00007b00b77d9c4b  vmovaps [rsp+0x30], xmm15
00007b00b77d9c51  vmovaps xmm15, [rsp+0x90]
00007b00b77d9c5a  vmovaps [rsp+0x90], xmm14
00007b00b77d9c63  vmovaps xmm14, [rsp+0x20]
00007b00b77d9c69  vmovaps [rsp+0x20], xmm13
00007b00b77d9c6f  vmovaps [rsp+0xB0], xmm12
00007b00b77d9c78  movaps xmm13, xmm1
00007b00b77d9c7c  vfmadd231pd xmm13, xmm15, xmm14
00007b00b77d9c81  vcmppd xmm12, xmm13, xmm13, 0x03
00007b00b77d9c87  vptest xmm12, xmm12
00007b00b77d9c8c  jnz 0x00007B00B77DA72F
00007b00b77d9c92  movaps xmm1, [r15+0x250]
00007b00b77d9c9a  vmovaps xmm15, [rsp+0x40]
00007b00b77d9ca0  vmovaps [rsp+0x40], xmm13
00007b00b77d9ca6  movaps xmm12, xmm15
00007b00b77d9caa  vfmadd231pd xmm12, xmm1, xmm14
00007b00b77d9caf  vcmppd xmm13, xmm12, xmm12, 0x03
00007b00b77d9cb5  vptest xmm13, xmm13
00007b00b77d9cba  jnz 0x00007B00B77DA888
00007b00b77d9cc0  movaps xmm15, [r15+0x1E0]
00007b00b77d9cc8  vmovaps [rsp+0xC0], xmm15
00007b00b77d9cd1  vmovaps xmm13, [rsp+0xC0]
00007b00b77d9cda  por xmm15, xmm13
00007b00b77d9cdf  movaps xmm13, [r15+0x1D0]
00007b00b77d9ce7  vmovaps [rsp+0xC0], xmm13
00007b00b77d9cf0  vmovaps [rsp+0xD0], xmm1
00007b00b77d9cf9  vmovaps xmm1, [rsp+0xC0]
00007b00b77d9d02  por xmm13, xmm1
00007b00b77d9d07  movaps xmm1, [r15+0x2C0]
00007b00b77d9d0f  vmovaps [rsp+0xC0], xmm1
00007b00b77d9d18  vmovaps [rsp+0xE0], xmm15
00007b00b77d9d21  vmovaps xmm15, [rsp+0xC0]
00007b00b77d9d2a  por xmm1, xmm15
00007b00b77d9d2f  movaps xmm15, [r15+0x290]
00007b00b77d9d37  vmovaps [rsp+0xC0], xmm15
00007b00b77d9d40  vmovaps [rsp+0xF0], xmm1
00007b00b77d9d49  vmovaps xmm1, [rsp+0xC0]
00007b00b77d9d52  por xmm15, xmm1
00007b00b77d9d57  movaps xmm1, [r15+0x260]
00007b00b77d9d5f  vmovaps [rsp+0xC0], xmm1
00007b00b77d9d68  vmovaps [rsp+0x100], xmm15
00007b00b77d9d71  vmovaps xmm15, [rsp+0xC0]
00007b00b77d9d7a  por xmm1, xmm15
00007b00b77d9d7f  vmovaps xmm15, [rsp+0xD0]
00007b00b77d9d88  vmovaps [rsp+0xC0], xmm1
00007b00b77d9d91  vmovaps xmm1, [rsp+0xD0]
00007b00b77d9d9a  por xmm15, xmm1
00007b00b77d9d9f  lea r12, [r14+0xC0]
00007b00b77d9da6  movups xmm1, [r13+r12*1]
00007b00b77d9dac  mov [rsp+0xD0], rax
00007b00b77d9db4  xor eax, eax
00007b00b77d9db6  mov r12d, 0x40
00007b00b77d9dbc  mov r11d, 0x200
00007b00b77d9dc2  cmp r12, r11
00007b00b77d9dc5  cmc
00007b00b77d9dc6  lahf
00007b00b77d9dc7  seto al
00007b00b77d9dca  mov [r15+0x108], eax
00007b00b77d9dd1  vmovaps [rsp+0x110], xmm1
00007b00b77d9dda  vmovaps xmm1, [rsp+0x80]
00007b00b77d9de3  vmovaps [rsp+0x80], xmm15
00007b00b77d9dec  vmovaps xmm15, [rsp+0x110]
00007b00b77d9df5  vmovaps [rsp+0x110], xmm13
00007b00b77d9dfe  vmovaps [rsp+0x120], xmm12
00007b00b77d9e07  movaps xmm13, xmm1
00007b00b77d9e0b  vfmadd231pd xmm13, xmm15, xmm14
00007b00b77d9e10  vcmppd xmm12, xmm13, xmm13, 0x03
00007b00b77d9e16  vptest xmm12, xmm12
00007b00b77d9e1b  jnz 0x00007B00B77DA9EB
00007b00b77d9e21  lea rax, [r14+0xB0]
00007b00b77d9e28  movups xmm1, [r13+rax*1]
00007b00b77d9e2e  vmovaps xmm15, [rsp+0xA0]
00007b00b77d9e37  vmovaps [rsp+0xA0], xmm13
00007b00b77d9e40  movaps xmm12, xmm15
00007b00b77d9e44  vfmadd231pd xmm12, xmm1, xmm14
00007b00b77d9e49  vcmppd xmm13, xmm12, xmm12, 0x03
00007b00b77d9e4f  vptest xmm13, xmm13
00007b00b77d9e54  jnz 0x00007B00B77DAB4E
00007b00b77d9e5a  vmovaps xmm1, [rsp+0x30]
00007b00b77d9e60  vmovaps xmm15, [rsp+0x30]
00007b00b77d9e66  por xmm1, xmm15
00007b00b77d9e6b  movaps [r15+0x210], xmm1
00007b00b77d9e73  vmovaps xmm15, [rsp+0x70]
00007b00b77d9e79  vmovaps xmm14, [rsp+0x70]
00007b00b77d9e7f  por xmm15, xmm14
00007b00b77d9e84  movaps [r15+0x1C0], xmm15
00007b00b77d9e8c  vmovaps xmm14, [rsp+0x60]
00007b00b77d9e92  vmovaps xmm13, [rsp+0x60]
00007b00b77d9e98  por xmm14, xmm13
00007b00b77d9e9d  movaps [r15+0x280], xmm14
00007b00b77d9ea5  vmovaps xmm13, [rsp+0x50]
00007b00b77d9eab  vmovaps [rsp+0x30], xmm1
00007b00b77d9eb1  vmovaps xmm1, [rsp+0x50]
00007b00b77d9eb7  por xmm13, xmm1
00007b00b77d9ebc  movaps [r15+0x2A0], xmm13
00007b00b77d9ec4  vmovaps [rsp+0x50], xmm2
00007b00b77d9eca  vmovaps xmm1, [rsp+0x50]
00007b00b77d9ed0  por xmm2, xmm1
00007b00b77d9ed4  movaps [r15+0x2E0], xmm2
00007b00b77d9edc  vmovaps [rsp+0x50], xmm3
00007b00b77d9ee2  vmovaps xmm1, [rsp+0x50]
00007b00b77d9ee8  por xmm3, xmm1
00007b00b77d9eec  movaps [r15+0x1F0], xmm3
00007b00b77d9ef4  vmovaps xmm1, [rsp+0x80]
00007b00b77d9efd  vmovaps [rsp+0x50], xmm15
00007b00b77d9f03  vmovaps xmm15, [rsp+0x80]
00007b00b77d9f0c  por xmm1, xmm15
00007b00b77d9f11  movaps [r15+0x250], xmm1
00007b00b77d9f19  vmovaps xmm1, [rsp+0xC0]
00007b00b77d9f22  vmovaps xmm15, [rsp+0xC0]
00007b00b77d9f2b  por xmm1, xmm15
00007b00b77d9f30  movaps [r15+0x260], xmm1
00007b00b77d9f38  vmovaps xmm15, [rsp+0x100]
00007b00b77d9f41  vmovaps [rsp+0x60], xmm1
00007b00b77d9f47  vmovaps xmm1, [rsp+0x100]
00007b00b77d9f50  por xmm15, xmm1
00007b00b77d9f55  movaps [r15+0x290], xmm15
00007b00b77d9f5d  vmovaps xmm1, [rsp+0xF0]
00007b00b77d9f66  vmovaps [rsp+0x70], xmm15
00007b00b77d9f6c  vmovaps xmm15, [rsp+0xF0]
00007b00b77d9f75  por xmm1, xmm15
00007b00b77d9f7a  movaps [r15+0x2C0], xmm1
00007b00b77d9f82  movq xmm15, qword ptr [r15+0x240]
00007b00b77d9f8b  vmovaps [rsp+0x80], xmm15
00007b00b77d9f94  vpermilpd xmm15, xmm15, 0x00
00007b00b77d9f9a  vmovaps [rsp+0xC0], xmm1
00007b00b77d9fa3  vmovaps xmm1, [rsp+0x40]
00007b00b77d9fa9  vmovaps [rsp+0x40], xmm15
00007b00b77d9faf  vmovaps xmm15, [rsp+0x30]
00007b00b77d9fb5  vmovaps [rsp+0x30], xmm14
00007b00b77d9fbb  vmovaps xmm14, [rsp+0x40]
00007b00b77d9fc1  vmovaps [rsp+0x40], xmm13
00007b00b77d9fc7  vmovaps [rsp+0xF0], xmm12
00007b00b77d9fd0  movaps xmm13, xmm1
00007b00b77d9fd4  vfmadd231pd xmm13, xmm15, xmm14
00007b00b77d9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007b00b77d9fdf  vptest xmm12, xmm12
00007b00b77d9fe4  jnz 0x00007B00B77DACA7
00007b00b77d9fea  vmovaps xmm1, [rsp+0x80]
00007b00b77d9ff3  vpermilpd xmm1, xmm1, 0x00
00007b00b77d9ff9  vmovaps xmm15, [rsp+0xA0]
00007b00b77da002  movaps xmm14, xmm15
00007b00b77da006  vfmadd231pd xmm14, xmm2, xmm1
00007b00b77da00b  vcmppd xmm12, xmm14, xmm14, 0x03
00007b00b77da011  vptest xmm12, xmm12
00007b00b77da016  jnz 0x00007B00B77DAE00
00007b00b77da01c  vmovaps xmm1, [rsp+0x80]
00007b00b77da025  vpermilpd xmm1, xmm1, 0x00
00007b00b77da02b  vmovaps xmm15, [rsp+0x120]
00007b00b77da034  vmovaps xmm12, [rsp+0x50]
00007b00b77da03a  vmovaps [rsp+0x50], xmm14
00007b00b77da040  movaps xmm2, xmm15
00007b00b77da044  vfmadd231pd xmm2, xmm12, xmm1
00007b00b77da049  vcmppd xmm14, xmm2, xmm2, 0x03
00007b00b77da04e  vptest xmm14, xmm14
00007b00b77da053  jnz 0x00007B00B77DAF58
00007b00b77da059  vmovaps xmm1, [rsp+0x110]
00007b00b77da062  vmovaps xmm15, [rsp+0x110]
00007b00b77da06b  por xmm1, xmm15
00007b00b77da070  movaps [r15+0x1D0], xmm1
00007b00b77da078  vmovaps xmm15, [rsp+0x80]
00007b00b77da081  vpermilpd xmm15, xmm15, 0x00
00007b00b77da087  vmovaps xmm14, [rsp+0xF0]
00007b00b77da090  vmovaps [rsp+0x80], xmm1
00007b00b77da099  movaps xmm12, xmm14
00007b00b77da09d  vfmadd231pd xmm12, xmm3, xmm15
00007b00b77da0a2  vcmppd xmm1, xmm12, xmm12, 0x03
00007b00b77da0a8  vptest xmm1, xmm1
00007b00b77da0ad  jnz 0x00007B00B77DB0AF
00007b00b77da0b3  vmovaps [rsp+0xA0], xmm4
00007b00b77da0bc  vmovaps xmm1, [rsp+0xA0]
00007b00b77da0c5  por xmm4, xmm1
00007b00b77da0c9  movaps [r15+0x200], xmm4
00007b00b77da0d1  vmovaps xmm1, [rsp+0xE0]
00007b00b77da0da  vmovaps xmm15, [rsp+0xE0]
00007b00b77da0e3  por xmm1, xmm15
00007b00b77da0e8  movaps [r15+0x1E0], xmm1
00007b00b77da0f0  vmovaps [rsp+0xA0], xmm8
00007b00b77da0f9  vmovaps xmm1, [rsp+0xA0]
00007b00b77da102  por xmm8, xmm1
00007b00b77da107  movaps [r15+0x2B0], xmm8
00007b00b77da10f  vmovaps [rsp+0xA0], xmm9
00007b00b77da118  vmovaps xmm1, [rsp+0xA0]
00007b00b77da121  por xmm9, xmm1
00007b00b77da126  movaps [r15+0x300], xmm9
00007b00b77da12e  vmovaps [rsp+0xA0], xmm6
00007b00b77da137  vpermilpd xmm6, xmm6, 0x00
00007b00b77da13d  vmovaps xmm14, [rsp+0x60]
00007b00b77da143  movaps xmm9, xmm13
00007b00b77da147  vfmadd231pd xmm9, xmm14, xmm6
00007b00b77da14c  vcmppd xmm3, xmm9, xmm9, 0x03
00007b00b77da152  vptest xmm3, xmm3
00007b00b77da157  jnz 0x00007B00B77DB208
00007b00b77da15d  vmovaps xmm14, [rsp+0xA0]
00007b00b77da166  vpermilpd xmm14, xmm14, 0x00
00007b00b77da16c  vmovaps xmm13, [rsp+0x50]
00007b00b77da172  vmovaps xmm6, [rsp+0xC0]
00007b00b77da17b  vmovaps [rsp+0x50], xmm1
00007b00b77da181  movaps xmm3, xmm13
00007b00b77da185  vfmadd231pd xmm3, xmm6, xmm14
00007b00b77da18a  vcmppd xmm1, xmm3, xmm3, 0x03
00007b00b77da18f  vptest xmm1, xmm1
00007b00b77da194  jnz 0x00007B00B77DB361
00007b00b77da19a  vmovaps xmm1, [rsp+0xA0]
00007b00b77da1a3  vpermilpd xmm1, xmm1, 0x00
00007b00b77da1a9  vmovaps xmm14, [rsp+0x30]
00007b00b77da1af  movaps xmm6, xmm2
00007b00b77da1b2  vfmadd231pd xmm6, xmm14, xmm1
00007b00b77da1b7  vcmppd xmm13, xmm6, xmm6, 0x03
00007b00b77da1bc  vptest xmm13, xmm13
00007b00b77da1c1  jnz 0x00007B00B77DB4B8
00007b00b77da1c7  vmovaps xmm1, [rsp+0xA0]
00007b00b77da1d0  vpermilpd xmm1, xmm1, 0x00
00007b00b77da1d6  vmovaps xmm14, [rsp+0x80]
00007b00b77da1df  movaps xmm13, xmm12
00007b00b77da1e3  vfmadd231pd xmm13, xmm14, xmm1
00007b00b77da1e8  vcmppd xmm2, xmm13, xmm13, 0x03
00007b00b77da1ee  vptest xmm2, xmm2
00007b00b77da1f3  jnz 0x00007B00B77DB60E
00007b00b77da1f9  vmovaps [rsp+0x30], xmm7
00007b00b77da1ff  vmovaps xmm1, [rsp+0x30]
00007b00b77da205  por xmm7, xmm1
00007b00b77da209  movaps [r15+0x180], xmm7
00007b00b77da211  vmovaps [rsp+0x30], xmm10
00007b00b77da217  vmovaps xmm1, [rsp+0x30]
00007b00b77da21d  por xmm10, xmm1
00007b00b77da222  movaps [r15+0x2D0], xmm10
00007b00b77da22a  vmovaps [rsp+0x30], xmm5
00007b00b77da230  vpermilpd xmm5, xmm5, 0x00
00007b00b77da236  vmovaps xmm14, [rsp+0x50]
00007b00b77da23c  movaps xmm12, xmm3
00007b00b77da240  vfmadd231pd xmm12, xmm14, xmm5
00007b00b77da245  vcmppd xmm10, xmm12, xmm12, 0x03
00007b00b77da24b  vptest xmm10, xmm10
00007b00b77da250  jnz 0x00007B00B77DB767
00007b00b77da256  vmovaps xmm14, [rsp+0x30]
00007b00b77da25c  vpermilpd xmm14, xmm14, 0x00
00007b00b77da262  movaps xmm10, xmm9
00007b00b77da266  vfmadd231pd xmm10, xmm7, xmm14
00007b00b77da26b  vcmppd xmm5, xmm10, xmm10, 0x03
00007b00b77da271  vptest xmm5, xmm5
00007b00b77da276  jnz 0x00007B00B77DB8BF
00007b00b77da27c  lea rax, [r14+0x80]
00007b00b77da283  movups xmm14, [r13+rax*1]
00007b00b77da289  movaps [r15+0x2F0], xmm14
00007b00b77da291  vmovaps xmm9, [rsp+0x30]
00007b00b77da297  vpermilpd xmm9, xmm9, 0x00
00007b00b77da29d  vmovaps xmm7, [rsp+0x70]
00007b00b77da2a3  movaps xmm5, xmm6
00007b00b77da2a6  vfmadd231pd xmm5, xmm7, xmm9
00007b00b77da2ab  vcmppd xmm3, xmm5, xmm5, 0x03
00007b00b77da2b0  vptest xmm3, xmm3
00007b00b77da2b5  jnz 0x00007B00B77DBA22
00007b00b77da2bb  vmovaps xmm9, [rsp+0x30]
00007b00b77da2c1  vpermilpd xmm9, xmm9, 0x00
00007b00b77da2c7  movaps xmm7, xmm13
00007b00b77da2cb  vfmadd231pd xmm7, xmm1, xmm9
00007b00b77da2d0  vcmppd xmm6, xmm7, xmm7, 0x03
00007b00b77da2d5  vptest xmm6, xmm6
00007b00b77da2da  jnz 0x00007B00B77DBB78
00007b00b77da2e0  vmovaps xmm1, [rsp+0x20]
00007b00b77da2e6  vmovaps xmm13, [rsp+0x20]
00007b00b77da2ec  por xmm1, xmm13
00007b00b77da2f1  movaps [r15+0x160], xmm1
00007b00b77da2f9  lea rax, [r14+0x40]
00007b00b77da2fd  movups xmm13, [r13+rax*1]
00007b00b77da303  lea rax, [r14+0x50]
00007b00b77da307  movups xmm9, [r13+rax*1]
00007b00b77da30d  movaps [r15+0x1B0], xmm13
00007b00b77da315  movaps [r15+0x1A0], xmm9
00007b00b77da31d  movaps xmm6, [r15+0x190]
00007b00b77da325  vmovaps xmm3, [rsp+0xB0]
00007b00b77da32e  vpermilpd xmm3, xmm3, 0x00
00007b00b77da334  vmovaps [rsp+0x20], xmm1
00007b00b77da33a  movaps xmm2, xmm12
00007b00b77da33e  vfmadd231pd xmm2, xmm6, xmm3
00007b00b77da343  vcmppd xmm1, xmm2, xmm2, 0x03
00007b00b77da348  vptest xmm1, xmm1
00007b00b77da34d  jnz 0x00007B00B77DBCE3
00007b00b77da353  vmovaps xmm1, [rsp+0xB0]
00007b00b77da35c  vpermilpd xmm1, xmm1, 0x00
00007b00b77da362  vmovaps xmm12, [rsp+0x20]
00007b00b77da368  movaps xmm6, xmm10
00007b00b77da36c  vfmadd231pd xmm6, xmm12, xmm1
00007b00b77da371  vcmppd xmm3, xmm6, xmm6, 0x03
00007b00b77da376  vptest xmm3, xmm3
00007b00b77da37b  jnz 0x00007B00B77DBE39
00007b00b77da381  vmovaps xmm1, [rsp+0xB0]
00007b00b77da38a  vpermilpd xmm1, xmm1, 0x00
00007b00b77da390  vmovaps xmm12, [rsp+0x40]
00007b00b77da396  movaps xmm10, xmm5
00007b00b77da39a  vfmadd231pd xmm10, xmm12, xmm1
00007b00b77da39f  vcmppd xmm3, xmm10, xmm10, 0x03
00007b00b77da3a5  vptest xmm3, xmm3
00007b00b77da3aa  jnz 0x00007B00B77DBF90
00007b00b77da3b0  vmovaps xmm1, [rsp+0xB0]
00007b00b77da3b9  vpermilpd xmm1, xmm1, 0x00
00007b00b77da3bf  movaps xmm12, xmm7
00007b00b77da3c3  vfmadd231pd xmm12, xmm15, xmm1
00007b00b77da3c8  vcmppd xmm5, xmm12, xmm12, 0x03
00007b00b77da3ce  vptest xmm5, xmm5
00007b00b77da3d3  jnz 0x00007B00B77DC0E8
00007b00b77da3d9  lea rax, [r14+0x60]
00007b00b77da3dd  movups xmm1, [r13+rax*1]
00007b00b77da3e3  lea rax, [r14+0x70]
00007b00b77da3e7  movups xmm15, [r13+rax*1]
00007b00b77da3ed  movaps [r15+0x150], xmm1
00007b00b77da3f5  movaps [r15+0x120], xmm15
00007b00b77da3fd  vmovaps [rsp+0x20], xmm11
00007b00b77da403  vpermilpd xmm11, xmm11, 0x00
00007b00b77da409  movaps xmm7, xmm2
00007b00b77da40c  vfmadd231pd xmm7, xmm9, xmm11
00007b00b77da411  vcmppd xmm5, xmm7, xmm7, 0x03
00007b00b77da416  vptest xmm5, xmm5
00007b00b77da41b  jnz 0x00007B00B77DC254
00007b00b77da421  vmovaps xmm11, [rsp+0x20]
00007b00b77da427  vpermilpd xmm11, xmm11, 0x00
00007b00b77da42d  movaps xmm9, xmm6
00007b00b77da431  vfmadd231pd xmm9, xmm1, xmm11
00007b00b77da436  vcmppd xmm5, xmm9, xmm9, 0x03
00007b00b77da43c  vptest xmm5, xmm5
00007b00b77da441  jnz 0x00007B00B77DC3AB
00007b00b77da447  vmovaps xmm1, [rsp+0x20]
00007b00b77da44d  vpermilpd xmm1, xmm1, 0x00
00007b00b77da453  movaps xmm11, xmm10
00007b00b77da457  vfmadd231pd xmm11, xmm8, xmm1
00007b00b77da45c  vcmppd xmm6, xmm11, xmm11, 0x03
00007b00b77da462  vptest xmm6, xmm6
00007b00b77da467  jnz 0x00007B00B77DC503
00007b00b77da46d  vmovaps xmm1, [rsp+0x20]
00007b00b77da473  vpermilpd xmm1, xmm1, 0x00
00007b00b77da479  movaps xmm10, xmm12
00007b00b77da47d  vfmadd231pd xmm10, xmm13, xmm1
00007b00b77da482  vcmppd xmm8, xmm10, xmm10, 0x03
00007b00b77da488  vptest xmm8, xmm8
00007b00b77da48d  jnz 0x00007B00B77DC65C
00007b00b77da493  lea rax, [r14+0x20]
00007b00b77da497  movups xmm1, [r13+rax*1]
00007b00b77da49d  lea rax, [r14+0x30]
00007b00b77da4a1  movups xmm13, [r13+rax*1]
00007b00b77da4a7  vmovaps xmm12, [rsp+0x90]
00007b00b77da4b0  vpermilpd xmm12, xmm12, 0x00
00007b00b77da4b6  movaps xmm8, xmm7
00007b00b77da4ba  vfmadd231pd xmm8, xmm4, xmm12
00007b00b77da4bf  vcmppd xmm6, xmm8, xmm8, 0x03
00007b00b77da4c5  vptest xmm6, xmm6
00007b00b77da4ca  jnz 0x00007B00B77DC7C9
00007b00b77da4d0  vmovaps xmm12, [rsp+0x90]
00007b00b77da4d9  vpermilpd xmm12, xmm12, 0x00
00007b00b77da4df  movaps xmm7, xmm9
00007b00b77da4e3  vfmadd231pd xmm7, xmm14, xmm12
00007b00b77da4e8  vcmppd xmm6, xmm7, xmm7, 0x03
00007b00b77da4ed  vptest xmm6, xmm6
00007b00b77da4f2  jnz 0x00007B00B77DC921
00007b00b77da4f8  vmovaps xmm14, [rsp+0x90]
00007b00b77da501  vpermilpd xmm14, xmm14, 0x00
00007b00b77da507  movaps xmm12, xmm11
00007b00b77da50b  vfmadd231pd xmm12, xmm15, xmm14
00007b00b77da510  vcmppd xmm9, xmm12, xmm12, 0x03
00007b00b77da516  vptest xmm9, xmm9
00007b00b77da51b  jnz 0x00007B00B77DCA79
00007b00b77da521  vmovaps xmm15, [rsp+0x90]
00007b00b77da52a  vpermilpd xmm15, xmm15, 0x00
00007b00b77da530  movaps xmm11, xmm10
00007b00b77da534  vfmadd231pd xmm11, xmm13, xmm15
00007b00b77da539  vcmppd xmm14, xmm11, xmm11, 0x03
00007b00b77da53f  vptest xmm14, xmm14
00007b00b77da544  jnz 0x00007B00B77DCBD3
00007b00b77da54a  lea rax, [r14+0x90]
00007b00b77da551  movups xmm15, [r13+rax*1]
00007b00b77da557  lea rax, [r14+0xA0]
00007b00b77da55e  movups xmm14, [r13+rax*1]
00007b00b77da564  movaps [r15+0x140], xmm15
00007b00b77da56c  movaps [r15+0x130], xmm14
00007b00b77da574  vmovaps xmm13, [rsp+0x10]
00007b00b77da57a  vpermilpd xmm13, xmm13, 0x00
00007b00b77da580  movaps xmm10, xmm8
00007b00b77da584  vfmadd231pd xmm10, xmm1, xmm13
00007b00b77da589  vcmppd xmm9, xmm10, xmm10, 0x03
00007b00b77da58f  vptest xmm9, xmm9
00007b00b77da594  jnz 0x00007B00B77DCD41
00007b00b77da59a  movaps [r15+0x220], xmm10
00007b00b77da5a2  lea rax, [r14+0x10]
00007b00b77da5a6  movups xmm1, [r13+rax*1]
00007b00b77da5ac  movaps [r15+0x240], xmm1
00007b00b77da5b4  vmovaps xmm13, [rsp+0x10]
00007b00b77da5ba  vpermilpd xmm13, xmm13, 0x00
00007b00b77da5c0  movaps xmm9, xmm7
00007b00b77da5c4  vfmadd231pd xmm9, xmm14, xmm13
00007b00b77da5c9  vcmppd xmm8, xmm9, xmm9, 0x03
00007b00b77da5cf  vptest xmm8, xmm8
00007b00b77da5d4  jnz 0x00007B00B77DCEA4
00007b00b77da5da  movaps [r15+0x110], xmm9
00007b00b77da5e2  vmovaps xmm14, [rsp+0x10]
00007b00b77da5e8  vpermilpd xmm14, xmm14, 0x00
00007b00b77da5ee  movaps xmm13, xmm12
00007b00b77da5f2  vfmadd231pd xmm13, xmm15, xmm14
00007b00b77da5f7  vcmppd xmm8, xmm13, xmm13, 0x03
00007b00b77da5fd  vptest xmm8, xmm8
00007b00b77da602  jnz 0x00007B00B77DCFFD
00007b00b77da608  movaps [r15+0x170], xmm13
00007b00b77da610  vmovaps xmm15, [rsp+0x10]
00007b00b77da616  vpermilpd xmm15, xmm15, 0x00
00007b00b77da61c  movaps xmm14, xmm11
00007b00b77da620  vfmadd231pd xmm14, xmm1, xmm15
00007b00b77da625  vcmppd xmm12, xmm14, xmm14, 0x03
00007b00b77da62b  vptest xmm12, xmm12
00007b00b77da630  jnz 0x00007B00B77DD157
00007b00b77da636  movaps [r15+0x230], xmm14
00007b00b77da63e  mov rax, [rsp+0xD0]
00007b00b77da646  movups [r13+rax*1], xmm9
00007b00b77da64c  lea r14, [rax+0x10]
00007b00b77da650  movups [r13+r14*1], xmm13
00007b00b77da656  lea r14, [rax+0x20]
00007b00b77da65a  movups [r13+r14*1], xmm10
00007b00b77da660  lea r14, [rax+0x30]
00007b00b77da664  movups [r13+r14*1], xmm14
00007b00b77da66a  mov eax, [r15+0x108]
00007b00b77da671  sahf
00007b00b77da672  jnz 0x00007B00B77DA6A4
00007b00b77da674  cmp dword ptr [r15+0x318], 0x00
00007b00b77da67c  jz 0x00007B00B77D9950
00007b00b77da682  nop [rax+rax*1], ax
00007b00b77da68b  nop [rax+rax*1], eax
00007b00b77da693  mov eax, 0x410664
00007b00b77da698  mov [r15+0x100], rax
00007b00b77da69f  jmp 0x00007B00B75FE110
00007b00b77da6a4  cmp dword ptr [r15+0x318], 0x00
00007b00b77da6ac  jz 0x00007B00B77D6050
00007b00b77da6b2  nop [rax+rax*1], ax
00007b00b77da6bb  nop [rax+rax*1], eax
00007b00b77da6c3  mov eax, 0x4104F0
00007b00b77da6c8  mov [r15+0x100], rax
00007b00b77da6cf  jmp 0x00007B00B75FE110
00007b00b77da6d4  int3
00007b00b77da6d5  call 0x00007B00B76E27E0
00007b00b77da6da  jmp 0x00007B00B77D9A10
00007b00b77da6df  call 0x00007B00B76E1570
00007b00b77da6e4  jmp 0x00007B00B77D9A19
00007b00b77da6e9  call 0x00007B00B76E27E0
00007b00b77da6ee  jmp 0x00007B00B77D9A62
00007b00b77da6f3  call 0x00007B00B76E1570
00007b00b77da6f8  jmp 0x00007B00B77D9A6B
00007b00b77da6fd  call 0x00007B00B76E27E0
00007b00b77da702  jmp 0x00007B00B77D9AEB
00007b00b77da707  call 0x00007B00B76E1570
00007b00b77da70c  jmp 0x00007B00B77D9AF4
00007b00b77da711  call 0x00007B00B760DC20
00007b00b77da716  jmp 0x00007B00B77D9BD5
00007b00b77da71b  call 0x00007B00B76D64F0
00007b00b77da720  jmp 0x00007B00B77D9C04
00007b00b77da725  call 0x00007B00B76B47C0
00007b00b77da72a  jmp 0x00007B00B77D9C1F
00007b00b77da72f  sub rsp, 0x08
00007b00b77da733  push rax
00007b00b77da734  push rcx
00007b00b77da735  push rdx
00007b00b77da736  push rdi
00007b00b77da737  push rsi
00007b00b77da738  push r8
00007b00b77da73a  push r9
00007b00b77da73c  push r10
00007b00b77da73e  push r11
00007b00b77da740  sub rsp, 0xF0
00007b00b77da747  vmovaps [rsp], xmm0
00007b00b77da74c  vmovaps [rsp+0x10], xmm1
00007b00b77da752  vmovaps [rsp+0x20], xmm2
00007b00b77da758  vmovaps [rsp+0x30], xmm3
00007b00b77da75e  vmovaps [rsp+0x40], xmm4
00007b00b77da764  vmovaps [rsp+0x50], xmm5
00007b00b77da76a  vmovaps [rsp+0x60], xmm6
00007b00b77da770  vmovaps [rsp+0x70], xmm7
00007b00b77da776  vmovaps [rsp+0x80], xmm8
00007b00b77da77f  vmovaps [rsp+0x90], xmm9
00007b00b77da788  vmovaps [rsp+0xA0], xmm10
00007b00b77da791  vmovaps [rsp+0xB0], xmm11
00007b00b77da79a  vmovaps [rsp+0xC0], xmm12
00007b00b77da7a3  vmovaps [rsp+0xD0], xmm14
00007b00b77da7ac  vmovaps [rsp+0xE0], xmm15
00007b00b77da7b5  sub rsp, 0x40
00007b00b77da7b9  lea rdi, [rsp]
00007b00b77da7bd  lea rsi, [rsp+0x10]
00007b00b77da7c2  lea rdx, [rsp+0x20]
00007b00b77da7c7  lea rcx, [rsp+0x30]
00007b00b77da7cc  mov r8d, 0x00
00007b00b77da7d2  lea r9, [r15+0x3A8]
00007b00b77da7d9  movaps [rdi], xmm13
00007b00b77da7dd  movaps [rsi], xmm1
00007b00b77da7e0  movaps [rdx], xmm15
00007b00b77da7e4  movaps [rcx], xmm14
00007b00b77da7e8  mov rax, 0x612A23581A50
00007b00b77da7f2  call rax
00007b00b77da7f4  movaps xmm13, [rsp]
00007b00b77da7f9  add rsp, 0x40
00007b00b77da7fd  vmovaps xmm0, [rsp]
00007b00b77da802  vmovaps xmm1, [rsp+0x10]
00007b00b77da808  vmovaps xmm2, [rsp+0x20]
00007b00b77da80e  vmovaps xmm3, [rsp+0x30]
00007b00b77da814  vmovaps xmm4, [rsp+0x40]
00007b00b77da81a  vmovaps xmm5, [rsp+0x50]
00007b00b77da820  vmovaps xmm6, [rsp+0x60]
00007b00b77da826  vmovaps xmm7, [rsp+0x70]
00007b00b77da82c  vmovaps xmm8, [rsp+0x80]
00007b00b77da835  vmovaps xmm9, [rsp+0x90]
00007b00b77da83e  vmovaps xmm10, [rsp+0xA0]
00007b00b77da847  vmovaps xmm11, [rsp+0xB0]
00007b00b77da850  vmovaps xmm12, [rsp+0xC0]
00007b00b77da859  vmovaps xmm14, [rsp+0xD0]
00007b00b77da862  vmovaps xmm15, [rsp+0xE0]
00007b00b77da86b  add rsp, 0xF0
00007b00b77da872  pop r11
00007b00b77da874  pop r10
00007b00b77da876  pop r9
00007b00b77da878  pop r8
00007b00b77da87a  pop rsi
00007b00b77da87b  pop rdi
00007b00b77da87c  pop rdx
00007b00b77da87d  pop rcx
00007b00b77da87e  pop rax
00007b00b77da87f  add rsp, 0x08
00007b00b77da883  jmp 0x00007B00B77D9C92
00007b00b77da888  sub rsp, 0x08
00007b00b77da88c  push rax
00007b00b77da88d  push rcx
00007b00b77da88e  push rdx
00007b00b77da88f  push rdi
00007b00b77da890  push rsi
00007b00b77da891  push r8
00007b00b77da893  push r9
00007b00b77da895  push r10
00007b00b77da897  push r11
00007b00b77da899  sub rsp, 0xF0
00007b00b77da8a0  vmovaps [rsp], xmm0
00007b00b77da8a5  vmovaps [rsp+0x10], xmm1
00007b00b77da8ab  vmovaps [rsp+0x20], xmm2
00007b00b77da8b1  vmovaps [rsp+0x30], xmm3
00007b00b77da8b7  vmovaps [rsp+0x40], xmm4
00007b00b77da8bd  vmovaps [rsp+0x50], xmm5
00007b00b77da8c3  vmovaps [rsp+0x60], xmm6
00007b00b77da8c9  vmovaps [rsp+0x70], xmm7
00007b00b77da8cf  vmovaps [rsp+0x80], xmm8
00007b00b77da8d8  vmovaps [rsp+0x90], xmm9
00007b00b77da8e1  vmovaps [rsp+0xA0], xmm10
00007b00b77da8ea  vmovaps [rsp+0xB0], xmm11
00007b00b77da8f3  vmovaps [rsp+0xC0], xmm13
00007b00b77da8fc  vmovaps [rsp+0xD0], xmm14
00007b00b77da905  vmovaps [rsp+0xE0], xmm15
00007b00b77da90e  sub rsp, 0x40
00007b00b77da912  lea rdi, [rsp]
00007b00b77da916  lea rsi, [rsp+0x10]
00007b00b77da91b  lea rdx, [rsp+0x20]
00007b00b77da920  lea rcx, [rsp+0x30]
00007b00b77da925  mov r8d, 0x00
00007b00b77da92b  lea r9, [r15+0x3A8]
00007b00b77da932  movaps [rdi], xmm12
00007b00b77da936  movaps [rsi], xmm15
00007b00b77da93a  movaps [rdx], xmm1
00007b00b77da93d  movaps [rcx], xmm14
00007b00b77da941  mov rax, 0x612A23581A50
00007b00b77da94b  call rax
00007b00b77da94d  movaps xmm12, [rsp]
00007b00b77da952  add rsp, 0x40
00007b00b77da956  vmovaps xmm0, [rsp]
00007b00b77da95b  vmovaps xmm1, [rsp+0x10]
00007b00b77da961  vmovaps xmm2, [rsp+0x20]
00007b00b77da967  vmovaps xmm3, [rsp+0x30]
00007b00b77da96d  vmovaps xmm4, [rsp+0x40]
00007b00b77da973  vmovaps xmm5, [rsp+0x50]
00007b00b77da979  vmovaps xmm6, [rsp+0x60]
00007b00b77da97f  vmovaps xmm7, [rsp+0x70]
00007b00b77da985  vmovaps xmm8, [rsp+0x80]
00007b00b77da98e  vmovaps xmm9, [rsp+0x90]
00007b00b77da997  vmovaps xmm10, [rsp+0xA0]
00007b00b77da9a0  vmovaps xmm11, [rsp+0xB0]
00007b00b77da9a9  vmovaps xmm13, [rsp+0xC0]
00007b00b77da9b2  vmovaps xmm14, [rsp+0xD0]
00007b00b77da9bb  vmovaps xmm15, [rsp+0xE0]
00007b00b77da9c4  add rsp, 0xF0
00007b00b77da9cb  pop r11
00007b00b77da9cd  pop r10
00007b00b77da9cf  pop r9
00007b00b77da9d1  pop r8
00007b00b77da9d3  pop rsi
00007b00b77da9d4  pop rdi
00007b00b77da9d5  pop rdx
00007b00b77da9d6  pop rcx
00007b00b77da9d7  pop rax
00007b00b77da9d8  add rsp, 0x08
00007b00b77da9dc  jmp 0x00007B00B77D9CC0
00007b00b77da9e1  call 0x00007B00B76B52F0
00007b00b77da9e6  jmp 0x00007B00B77D9DAC
00007b00b77da9eb  sub rsp, 0x08
00007b00b77da9ef  push rax
00007b00b77da9f0  push rcx
00007b00b77da9f1  push rdx
00007b00b77da9f2  push rdi
00007b00b77da9f3  push rsi
00007b00b77da9f4  push r8
00007b00b77da9f6  push r9
00007b00b77da9f8  push r10
00007b00b77da9fa  push r11
00007b00b77da9fc  sub rsp, 0xF0
00007b00b77daa03  vmovaps [rsp], xmm0
00007b00b77daa08  vmovaps [rsp+0x10], xmm1
00007b00b77daa0e  vmovaps [rsp+0x20], xmm2
00007b00b77daa14  vmovaps [rsp+0x30], xmm3
00007b00b77daa1a  vmovaps [rsp+0x40], xmm4
00007b00b77daa20  vmovaps [rsp+0x50], xmm5
00007b00b77daa26  vmovaps [rsp+0x60], xmm6
00007b00b77daa2c  vmovaps [rsp+0x70], xmm7
00007b00b77daa32  vmovaps [rsp+0x80], xmm8
00007b00b77daa3b  vmovaps [rsp+0x90], xmm9
00007b00b77daa44  vmovaps [rsp+0xA0], xmm10
00007b00b77daa4d  vmovaps [rsp+0xB0], xmm11
00007b00b77daa56  vmovaps [rsp+0xC0], xmm12
00007b00b77daa5f  vmovaps [rsp+0xD0], xmm14
00007b00b77daa68  vmovaps [rsp+0xE0], xmm15
00007b00b77daa71  sub rsp, 0x40
00007b00b77daa75  lea rdi, [rsp]
00007b00b77daa79  lea rsi, [rsp+0x10]
00007b00b77daa7e  lea rdx, [rsp+0x20]
00007b00b77daa83  lea rcx, [rsp+0x30]
00007b00b77daa88  mov r8d, 0x00
00007b00b77daa8e  lea r9, [r15+0x3A8]
00007b00b77daa95  movaps [rdi], xmm13
00007b00b77daa99  movaps [rsi], xmm1
00007b00b77daa9c  movaps [rdx], xmm15
00007b00b77daaa0  movaps [rcx], xmm14
00007b00b77daaa4  mov rax, 0x612A23581A50
00007b00b77daaae  call rax
00007b00b77daab0  movaps xmm13, [rsp]
00007b00b77daab5  add rsp, 0x40
00007b00b77daab9  vmovaps xmm0, [rsp]
00007b00b77daabe  vmovaps xmm1, [rsp+0x10]
00007b00b77daac4  vmovaps xmm2, [rsp+0x20]
00007b00b77daaca  vmovaps xmm3, [rsp+0x30]
00007b00b77daad0  vmovaps xmm4, [rsp+0x40]
00007b00b77daad6  vmovaps xmm5, [rsp+0x50]
00007b00b77daadc  vmovaps xmm6, [rsp+0x60]
00007b00b77daae2  vmovaps xmm7, [rsp+0x70]
00007b00b77daae8  vmovaps xmm8, [rsp+0x80]
00007b00b77daaf1  vmovaps xmm9, [rsp+0x90]
00007b00b77daafa  vmovaps xmm10, [rsp+0xA0]
00007b00b77dab03  vmovaps xmm11, [rsp+0xB0]
00007b00b77dab0c  vmovaps xmm12, [rsp+0xC0]
00007b00b77dab15  vmovaps xmm14, [rsp+0xD0]
00007b00b77dab1e  vmovaps xmm15, [rsp+0xE0]
00007b00b77dab27  add rsp, 0xF0
00007b00b77dab2e  pop r11
00007b00b77dab30  pop r10
00007b00b77dab32  pop r9
00007b00b77dab34  pop r8
00007b00b77dab36  pop rsi
00007b00b77dab37  pop rdi
00007b00b77dab38  pop rdx
00007b00b77dab39  pop rcx
00007b00b77dab3a  pop rax
00007b00b77dab3b  add rsp, 0x08
00007b00b77dab3f  jmp 0x00007B00B77D9E21
00007b00b77dab44  call 0x00007B00B75FF430
00007b00b77dab49  jmp 0x00007B00B77D9E2E
00007b00b77dab4e  sub rsp, 0x08
00007b00b77dab52  push rax
00007b00b77dab53  push rcx
00007b00b77dab54  push rdx
00007b00b77dab55  push rdi
00007b00b77dab56  push rsi
00007b00b77dab57  push r8
00007b00b77dab59  push r9
00007b00b77dab5b  push r10
00007b00b77dab5d  push r11
00007b00b77dab5f  sub rsp, 0xF0
00007b00b77dab66  vmovaps [rsp], xmm0
00007b00b77dab6b  vmovaps [rsp+0x10], xmm1
00007b00b77dab71  vmovaps [rsp+0x20], xmm2
00007b00b77dab77  vmovaps [rsp+0x30], xmm3
00007b00b77dab7d  vmovaps [rsp+0x40], xmm4
00007b00b77dab83  vmovaps [rsp+0x50], xmm5
00007b00b77dab89  vmovaps [rsp+0x60], xmm6
00007b00b77dab8f  vmovaps [rsp+0x70], xmm7
00007b00b77dab95  vmovaps [rsp+0x80], xmm8
00007b00b77dab9e  vmovaps [rsp+0x90], xmm9
00007b00b77daba7  vmovaps [rsp+0xA0], xmm10
00007b00b77dabb0  vmovaps [rsp+0xB0], xmm11
00007b00b77dabb9  vmovaps [rsp+0xC0], xmm13
00007b00b77dabc2  vmovaps [rsp+0xD0], xmm14
00007b00b77dabcb  vmovaps [rsp+0xE0], xmm15
00007b00b77dabd4  sub rsp, 0x40
00007b00b77dabd8  lea rdi, [rsp]
00007b00b77dabdc  lea rsi, [rsp+0x10]
00007b00b77dabe1  lea rdx, [rsp+0x20]
00007b00b77dabe6  lea rcx, [rsp+0x30]
00007b00b77dabeb  mov r8d, 0x00
00007b00b77dabf1  lea r9, [r15+0x3A8]
00007b00b77dabf8  movaps [rdi], xmm12
00007b00b77dabfc  movaps [rsi], xmm15
00007b00b77dac00  movaps [rdx], xmm1
00007b00b77dac03  movaps [rcx], xmm14
00007b00b77dac07  mov rax, 0x612A23581A50
00007b00b77dac11  call rax
00007b00b77dac13  movaps xmm12, [rsp]
00007b00b77dac18  add rsp, 0x40
00007b00b77dac1c  vmovaps xmm0, [rsp]
00007b00b77dac21  vmovaps xmm1, [rsp+0x10]
00007b00b77dac27  vmovaps xmm2, [rsp+0x20]
00007b00b77dac2d  vmovaps xmm3, [rsp+0x30]
00007b00b77dac33  vmovaps xmm4, [rsp+0x40]
00007b00b77dac39  vmovaps xmm5, [rsp+0x50]
00007b00b77dac3f  vmovaps xmm6, [rsp+0x60]
00007b00b77dac45  vmovaps xmm7, [rsp+0x70]
00007b00b77dac4b  vmovaps xmm8, [rsp+0x80]
00007b00b77dac54  vmovaps xmm9, [rsp+0x90]
00007b00b77dac5d  vmovaps xmm10, [rsp+0xA0]
00007b00b77dac66  vmovaps xmm11, [rsp+0xB0]
00007b00b77dac6f  vmovaps xmm13, [rsp+0xC0]
00007b00b77dac78  vmovaps xmm14, [rsp+0xD0]
00007b00b77dac81  vmovaps xmm15, [rsp+0xE0]
00007b00b77dac8a  add rsp, 0xF0
00007b00b77dac91  pop r11
00007b00b77dac93  pop r10
00007b00b77dac95  pop r9
00007b00b77dac97  pop r8
00007b00b77dac99  pop rsi
00007b00b77dac9a  pop rdi
00007b00b77dac9b  pop rdx
00007b00b77dac9c  pop rcx
00007b00b77dac9d  pop rax
00007b00b77dac9e  add rsp, 0x08
00007b00b77daca2  jmp 0x00007B00B77D9E5A
00007b00b77daca7  sub rsp, 0x08
00007b00b77dacab  push rax
00007b00b77dacac  push rcx
00007b00b77dacad  push rdx
00007b00b77dacae  push rdi
00007b00b77dacaf  push rsi
00007b00b77dacb0  push r8
00007b00b77dacb2  push r9
00007b00b77dacb4  push r10
00007b00b77dacb6  push r11
00007b00b77dacb8  sub rsp, 0xF0
00007b00b77dacbf  vmovaps [rsp], xmm0
00007b00b77dacc4  vmovaps [rsp+0x10], xmm1
00007b00b77dacca  vmovaps [rsp+0x20], xmm2
00007b00b77dacd0  vmovaps [rsp+0x30], xmm3
00007b00b77dacd6  vmovaps [rsp+0x40], xmm4
00007b00b77dacdc  vmovaps [rsp+0x50], xmm5
00007b00b77dace2  vmovaps [rsp+0x60], xmm6
00007b00b77dace8  vmovaps [rsp+0x70], xmm7
00007b00b77dacee  vmovaps [rsp+0x80], xmm8
00007b00b77dacf7  vmovaps [rsp+0x90], xmm9
00007b00b77dad00  vmovaps [rsp+0xA0], xmm10
00007b00b77dad09  vmovaps [rsp+0xB0], xmm11
00007b00b77dad12  vmovaps [rsp+0xC0], xmm12
00007b00b77dad1b  vmovaps [rsp+0xD0], xmm14
00007b00b77dad24  vmovaps [rsp+0xE0], xmm15
00007b00b77dad2d  sub rsp, 0x40
00007b00b77dad31  lea rdi, [rsp]
00007b00b77dad35  lea rsi, [rsp+0x10]
00007b00b77dad3a  lea rdx, [rsp+0x20]
00007b00b77dad3f  lea rcx, [rsp+0x30]
00007b00b77dad44  mov r8d, 0x00
00007b00b77dad4a  lea r9, [r15+0x3A8]
00007b00b77dad51  movaps [rdi], xmm13
00007b00b77dad55  movaps [rsi], xmm1
00007b00b77dad58  movaps [rdx], xmm15
00007b00b77dad5c  movaps [rcx], xmm14
00007b00b77dad60  mov rax, 0x612A23581A50
00007b00b77dad6a  call rax
00007b00b77dad6c  movaps xmm13, [rsp]
00007b00b77dad71  add rsp, 0x40
00007b00b77dad75  vmovaps xmm0, [rsp]
00007b00b77dad7a  vmovaps xmm1, [rsp+0x10]
00007b00b77dad80  vmovaps xmm2, [rsp+0x20]
00007b00b77dad86  vmovaps xmm3, [rsp+0x30]
00007b00b77dad8c  vmovaps xmm4, [rsp+0x40]
00007b00b77dad92  vmovaps xmm5, [rsp+0x50]
00007b00b77dad98  vmovaps xmm6, [rsp+0x60]
00007b00b77dad9e  vmovaps xmm7, [rsp+0x70]
00007b00b77dada4  vmovaps xmm8, [rsp+0x80]
00007b00b77dadad  vmovaps xmm9, [rsp+0x90]
00007b00b77dadb6  vmovaps xmm10, [rsp+0xA0]
00007b00b77dadbf  vmovaps xmm11, [rsp+0xB0]
00007b00b77dadc8  vmovaps xmm12, [rsp+0xC0]
00007b00b77dadd1  vmovaps xmm14, [rsp+0xD0]
00007b00b77dadda  vmovaps xmm15, [rsp+0xE0]
00007b00b77dade3  add rsp, 0xF0
00007b00b77dadea  pop r11
00007b00b77dadec  pop r10
00007b00b77dadee  pop r9
00007b00b77dadf0  pop r8
00007b00b77dadf2  pop rsi
00007b00b77dadf3  pop rdi
00007b00b77dadf4  pop rdx
00007b00b77dadf5  pop rcx
00007b00b77dadf6  pop rax
00007b00b77dadf7  add rsp, 0x08
00007b00b77dadfb  jmp 0x00007B00B77D9FEA
00007b00b77dae00  sub rsp, 0x08
00007b00b77dae04  push rax
00007b00b77dae05  push rcx
00007b00b77dae06  push rdx
00007b00b77dae07  push rdi
00007b00b77dae08  push rsi
00007b00b77dae09  push r8
00007b00b77dae0b  push r9
00007b00b77dae0d  push r10
00007b00b77dae0f  push r11
00007b00b77dae11  sub rsp, 0xF0
00007b00b77dae18  vmovaps [rsp], xmm0
00007b00b77dae1d  vmovaps [rsp+0x10], xmm1
00007b00b77dae23  vmovaps [rsp+0x20], xmm2
00007b00b77dae29  vmovaps [rsp+0x30], xmm3
00007b00b77dae2f  vmovaps [rsp+0x40], xmm4
00007b00b77dae35  vmovaps [rsp+0x50], xmm5
00007b00b77dae3b  vmovaps [rsp+0x60], xmm6
00007b00b77dae41  vmovaps [rsp+0x70], xmm7
00007b00b77dae47  vmovaps [rsp+0x80], xmm8
00007b00b77dae50  vmovaps [rsp+0x90], xmm9
00007b00b77dae59  vmovaps [rsp+0xA0], xmm10
00007b00b77dae62  vmovaps [rsp+0xB0], xmm11
00007b00b77dae6b  vmovaps [rsp+0xC0], xmm12
00007b00b77dae74  vmovaps [rsp+0xD0], xmm13
00007b00b77dae7d  vmovaps [rsp+0xE0], xmm15
00007b00b77dae86  sub rsp, 0x40
00007b00b77dae8a  lea rdi, [rsp]
00007b00b77dae8e  lea rsi, [rsp+0x10]
00007b00b77dae93  lea rdx, [rsp+0x20]
00007b00b77dae98  lea rcx, [rsp+0x30]
00007b00b77dae9d  mov r8d, 0x00
00007b00b77daea3  lea r9, [r15+0x3A8]
00007b00b77daeaa  movaps [rdi], xmm14
00007b00b77daeae  movaps [rsi], xmm15
00007b00b77daeb2  movaps [rdx], xmm2
00007b00b77daeb5  movaps [rcx], xmm1
00007b00b77daeb8  mov rax, 0x612A23581A50
00007b00b77daec2  call rax
00007b00b77daec4  movaps xmm14, [rsp]
00007b00b77daec9  add rsp, 0x40
00007b00b77daecd  vmovaps xmm0, [rsp]
00007b00b77daed2  vmovaps xmm1, [rsp+0x10]
00007b00b77daed8  vmovaps xmm2, [rsp+0x20]
00007b00b77daede  vmovaps xmm3, [rsp+0x30]
00007b00b77daee4  vmovaps xmm4, [rsp+0x40]
00007b00b77daeea  vmovaps xmm5, [rsp+0x50]
00007b00b77daef0  vmovaps xmm6, [rsp+0x60]
00007b00b77daef6  vmovaps xmm7, [rsp+0x70]
00007b00b77daefc  vmovaps xmm8, [rsp+0x80]
00007b00b77daf05  vmovaps xmm9, [rsp+0x90]
00007b00b77daf0e  vmovaps xmm10, [rsp+0xA0]
00007b00b77daf17  vmovaps xmm11, [rsp+0xB0]
00007b00b77daf20  vmovaps xmm12, [rsp+0xC0]
00007b00b77daf29  vmovaps xmm13, [rsp+0xD0]
00007b00b77daf32  vmovaps xmm15, [rsp+0xE0]
00007b00b77daf3b  add rsp, 0xF0
00007b00b77daf42  pop r11
00007b00b77daf44  pop r10
00007b00b77daf46  pop r9
00007b00b77daf48  pop r8
00007b00b77daf4a  pop rsi
00007b00b77daf4b  pop rdi
00007b00b77daf4c  pop rdx
00007b00b77daf4d  pop rcx
00007b00b77daf4e  pop rax
00007b00b77daf4f  add rsp, 0x08
00007b00b77daf53  jmp 0x00007B00B77DA01C
00007b00b77daf58  sub rsp, 0x08
00007b00b77daf5c  push rax
00007b00b77daf5d  push rcx
00007b00b77daf5e  push rdx
00007b00b77daf5f  push rdi
00007b00b77daf60  push rsi
00007b00b77daf61  push r8
00007b00b77daf63  push r9
00007b00b77daf65  push r10
00007b00b77daf67  push r11
00007b00b77daf69  sub rsp, 0xF0
00007b00b77daf70  vmovaps [rsp], xmm0
00007b00b77daf75  vmovaps [rsp+0x10], xmm1
00007b00b77daf7b  vmovaps [rsp+0x20], xmm3
00007b00b77daf81  vmovaps [rsp+0x30], xmm4
00007b00b77daf87  vmovaps [rsp+0x40], xmm5
00007b00b77daf8d  vmovaps [rsp+0x50], xmm6
00007b00b77daf93  vmovaps [rsp+0x60], xmm7
00007b00b77daf99  vmovaps [rsp+0x70], xmm8
00007b00b77daf9f  vmovaps [rsp+0x80], xmm9
00007b00b77dafa8  vmovaps [rsp+0x90], xmm10
00007b00b77dafb1  vmovaps [rsp+0xA0], xmm11
00007b00b77dafba  vmovaps [rsp+0xB0], xmm12
00007b00b77dafc3  vmovaps [rsp+0xC0], xmm13
00007b00b77dafcc  vmovaps [rsp+0xD0], xmm14
00007b00b77dafd5  vmovaps [rsp+0xE0], xmm15
00007b00b77dafde  sub rsp, 0x40
00007b00b77dafe2  lea rdi, [rsp]
00007b00b77dafe6  lea rsi, [rsp+0x10]
00007b00b77dafeb  lea rdx, [rsp+0x20]
00007b00b77daff0  lea rcx, [rsp+0x30]
00007b00b77daff5  mov r8d, 0x00
00007b00b77daffb  lea r9, [r15+0x3A8]
00007b00b77db002  movaps [rdi], xmm2
00007b00b77db005  movaps [rsi], xmm15
00007b00b77db009  movaps [rdx], xmm12
00007b00b77db00d  movaps [rcx], xmm1
00007b00b77db010  mov rax, 0x612A23581A50
00007b00b77db01a  call rax
00007b00b77db01c  movaps xmm2, [rsp]
00007b00b77db020  add rsp, 0x40
00007b00b77db024  vmovaps xmm0, [rsp]
00007b00b77db029  vmovaps xmm1, [rsp+0x10]
00007b00b77db02f  vmovaps xmm3, [rsp+0x20]
00007b00b77db035  vmovaps xmm4, [rsp+0x30]
00007b00b77db03b  vmovaps xmm5, [rsp+0x40]
00007b00b77db041  vmovaps xmm6, [rsp+0x50]
00007b00b77db047  vmovaps xmm7, [rsp+0x60]
00007b00b77db04d  vmovaps xmm8, [rsp+0x70]
00007b00b77db053  vmovaps xmm9, [rsp+0x80]
00007b00b77db05c  vmovaps xmm10, [rsp+0x90]
00007b00b77db065  vmovaps xmm11, [rsp+0xA0]
00007b00b77db06e  vmovaps xmm12, [rsp+0xB0]
00007b00b77db077  vmovaps xmm13, [rsp+0xC0]
00007b00b77db080  vmovaps xmm14, [rsp+0xD0]
00007b00b77db089  vmovaps xmm15, [rsp+0xE0]
00007b00b77db092  add rsp, 0xF0
00007b00b77db099  pop r11
00007b00b77db09b  pop r10
00007b00b77db09d  pop r9
00007b00b77db09f  pop r8
00007b00b77db0a1  pop rsi
00007b00b77db0a2  pop rdi
00007b00b77db0a3  pop rdx
00007b00b77db0a4  pop rcx
00007b00b77db0a5  pop rax
00007b00b77db0a6  add rsp, 0x08
00007b00b77db0aa  jmp 0x00007B00B77DA059
00007b00b77db0af  sub rsp, 0x08
00007b00b77db0b3  push rax
00007b00b77db0b4  push rcx
00007b00b77db0b5  push rdx
00007b00b77db0b6  push rdi
00007b00b77db0b7  push rsi
00007b00b77db0b8  push r8
00007b00b77db0ba  push r9
00007b00b77db0bc  push r10
00007b00b77db0be  push r11
00007b00b77db0c0  sub rsp, 0xF0
00007b00b77db0c7  vmovaps [rsp], xmm0
00007b00b77db0cc  vmovaps [rsp+0x10], xmm1
00007b00b77db0d2  vmovaps [rsp+0x20], xmm2
00007b00b77db0d8  vmovaps [rsp+0x30], xmm3
00007b00b77db0de  vmovaps [rsp+0x40], xmm4
00007b00b77db0e4  vmovaps [rsp+0x50], xmm5
00007b00b77db0ea  vmovaps [rsp+0x60], xmm6
00007b00b77db0f0  vmovaps [rsp+0x70], xmm7
00007b00b77db0f6  vmovaps [rsp+0x80], xmm8
00007b00b77db0ff  vmovaps [rsp+0x90], xmm9
00007b00b77db108  vmovaps [rsp+0xA0], xmm10
00007b00b77db111  vmovaps [rsp+0xB0], xmm11
00007b00b77db11a  vmovaps [rsp+0xC0], xmm13
00007b00b77db123  vmovaps [rsp+0xD0], xmm14
00007b00b77db12c  vmovaps [rsp+0xE0], xmm15
00007b00b77db135  sub rsp, 0x40
00007b00b77db139  lea rdi, [rsp]
00007b00b77db13d  lea rsi, [rsp+0x10]
00007b00b77db142  lea rdx, [rsp+0x20]
00007b00b77db147  lea rcx, [rsp+0x30]
00007b00b77db14c  mov r8d, 0x00
00007b00b77db152  lea r9, [r15+0x3A8]
00007b00b77db159  movaps [rdi], xmm12
00007b00b77db15d  movaps [rsi], xmm14
00007b00b77db161  movaps [rdx], xmm3
00007b00b77db164  movaps [rcx], xmm15
00007b00b77db168  mov rax, 0x612A23581A50
00007b00b77db172  call rax
00007b00b77db174  movaps xmm12, [rsp]
00007b00b77db179  add rsp, 0x40
00007b00b77db17d  vmovaps xmm0, [rsp]
00007b00b77db182  vmovaps xmm1, [rsp+0x10]
00007b00b77db188  vmovaps xmm2, [rsp+0x20]
00007b00b77db18e  vmovaps xmm3, [rsp+0x30]
00007b00b77db194  vmovaps xmm4, [rsp+0x40]
00007b00b77db19a  vmovaps xmm5, [rsp+0x50]
00007b00b77db1a0  vmovaps xmm6, [rsp+0x60]
00007b00b77db1a6  vmovaps xmm7, [rsp+0x70]
00007b00b77db1ac  vmovaps xmm8, [rsp+0x80]
00007b00b77db1b5  vmovaps xmm9, [rsp+0x90]
00007b00b77db1be  vmovaps xmm10, [rsp+0xA0]
00007b00b77db1c7  vmovaps xmm11, [rsp+0xB0]
00007b00b77db1d0  vmovaps xmm13, [rsp+0xC0]
00007b00b77db1d9  vmovaps xmm14, [rsp+0xD0]
00007b00b77db1e2  vmovaps xmm15, [rsp+0xE0]
00007b00b77db1eb  add rsp, 0xF0
00007b00b77db1f2  pop r11
00007b00b77db1f4  pop r10
00007b00b77db1f6  pop r9
00007b00b77db1f8  pop r8
00007b00b77db1fa  pop rsi
00007b00b77db1fb  pop rdi
00007b00b77db1fc  pop rdx
00007b00b77db1fd  pop rcx
00007b00b77db1fe  pop rax
00007b00b77db1ff  add rsp, 0x08
00007b00b77db203  jmp 0x00007B00B77DA0B3
00007b00b77db208  sub rsp, 0x08
00007b00b77db20c  push rax
00007b00b77db20d  push rcx
00007b00b77db20e  push rdx
00007b00b77db20f  push rdi
00007b00b77db210  push rsi
00007b00b77db211  push r8
00007b00b77db213  push r9
00007b00b77db215  push r10
00007b00b77db217  push r11
00007b00b77db219  sub rsp, 0xF0
00007b00b77db220  vmovaps [rsp], xmm0
00007b00b77db225  vmovaps [rsp+0x10], xmm1
00007b00b77db22b  vmovaps [rsp+0x20], xmm2
00007b00b77db231  vmovaps [rsp+0x30], xmm3
00007b00b77db237  vmovaps [rsp+0x40], xmm4
00007b00b77db23d  vmovaps [rsp+0x50], xmm5
00007b00b77db243  vmovaps [rsp+0x60], xmm6
00007b00b77db249  vmovaps [rsp+0x70], xmm7
00007b00b77db24f  vmovaps [rsp+0x80], xmm8
00007b00b77db258  vmovaps [rsp+0x90], xmm10
00007b00b77db261  vmovaps [rsp+0xA0], xmm11
00007b00b77db26a  vmovaps [rsp+0xB0], xmm12
00007b00b77db273  vmovaps [rsp+0xC0], xmm13
00007b00b77db27c  vmovaps [rsp+0xD0], xmm14
00007b00b77db285  vmovaps [rsp+0xE0], xmm15
00007b00b77db28e  sub rsp, 0x40
00007b00b77db292  lea rdi, [rsp]
00007b00b77db296  lea rsi, [rsp+0x10]
00007b00b77db29b  lea rdx, [rsp+0x20]
00007b00b77db2a0  lea rcx, [rsp+0x30]
00007b00b77db2a5  mov r8d, 0x00
00007b00b77db2ab  lea r9, [r15+0x3A8]
00007b00b77db2b2  movaps [rdi], xmm9
00007b00b77db2b6  movaps [rsi], xmm13
00007b00b77db2ba  movaps [rdx], xmm14
00007b00b77db2be  movaps [rcx], xmm6
00007b00b77db2c1  mov rax, 0x612A23581A50
00007b00b77db2cb  call rax
00007b00b77db2cd  movaps xmm9, [rsp]
00007b00b77db2d2  add rsp, 0x40
00007b00b77db2d6  vmovaps xmm0, [rsp]
00007b00b77db2db  vmovaps xmm1, [rsp+0x10]
00007b00b77db2e1  vmovaps xmm2, [rsp+0x20]
00007b00b77db2e7  vmovaps xmm3, [rsp+0x30]
00007b00b77db2ed  vmovaps xmm4, [rsp+0x40]
00007b00b77db2f3  vmovaps xmm5, [rsp+0x50]
00007b00b77db2f9  vmovaps xmm6, [rsp+0x60]
00007b00b77db2ff  vmovaps xmm7, [rsp+0x70]
00007b00b77db305  vmovaps xmm8, [rsp+0x80]
00007b00b77db30e  vmovaps xmm10, [rsp+0x90]
00007b00b77db317  vmovaps xmm11, [rsp+0xA0]
00007b00b77db320  vmovaps xmm12, [rsp+0xB0]
00007b00b77db329  vmovaps xmm13, [rsp+0xC0]
00007b00b77db332  vmovaps xmm14, [rsp+0xD0]
00007b00b77db33b  vmovaps xmm15, [rsp+0xE0]
00007b00b77db344  add rsp, 0xF0
00007b00b77db34b  pop r11
00007b00b77db34d  pop r10
00007b00b77db34f  pop r9
00007b00b77db351  pop r8
00007b00b77db353  pop rsi
00007b00b77db354  pop rdi
00007b00b77db355  pop rdx
00007b00b77db356  pop rcx
00007b00b77db357  pop rax
00007b00b77db358  add rsp, 0x08
00007b00b77db35c  jmp 0x00007B00B77DA15D
00007b00b77db361  sub rsp, 0x08
00007b00b77db365  push rax
00007b00b77db366  push rcx
00007b00b77db367  push rdx
00007b00b77db368  push rdi
00007b00b77db369  push rsi
00007b00b77db36a  push r8
00007b00b77db36c  push r9
00007b00b77db36e  push r10
00007b00b77db370  push r11
00007b00b77db372  sub rsp, 0xF0
00007b00b77db379  vmovaps [rsp], xmm0
00007b00b77db37e  vmovaps [rsp+0x10], xmm1
00007b00b77db384  vmovaps [rsp+0x20], xmm2
00007b00b77db38a  vmovaps [rsp+0x30], xmm4
00007b00b77db390  vmovaps [rsp+0x40], xmm5
00007b00b77db396  vmovaps [rsp+0x50], xmm6
00007b00b77db39c  vmovaps [rsp+0x60], xmm7
00007b00b77db3a2  vmovaps [rsp+0x70], xmm8
00007b00b77db3a8  vmovaps [rsp+0x80], xmm9
00007b00b77db3b1  vmovaps [rsp+0x90], xmm10
00007b00b77db3ba  vmovaps [rsp+0xA0], xmm11
00007b00b77db3c3  vmovaps [rsp+0xB0], xmm12
00007b00b77db3cc  vmovaps [rsp+0xC0], xmm13
00007b00b77db3d5  vmovaps [rsp+0xD0], xmm14
00007b00b77db3de  vmovaps [rsp+0xE0], xmm15
00007b00b77db3e7  sub rsp, 0x40
00007b00b77db3eb  lea rdi, [rsp]
00007b00b77db3ef  lea rsi, [rsp+0x10]
00007b00b77db3f4  lea rdx, [rsp+0x20]
00007b00b77db3f9  lea rcx, [rsp+0x30]
00007b00b77db3fe  mov r8d, 0x00
00007b00b77db404  lea r9, [r15+0x3A8]
00007b00b77db40b  movaps [rdi], xmm3
00007b00b77db40e  movaps [rsi], xmm13
00007b00b77db412  movaps [rdx], xmm6
00007b00b77db415  movaps [rcx], xmm14
00007b00b77db419  mov rax, 0x612A23581A50
00007b00b77db423  call rax
00007b00b77db425  movaps xmm3, [rsp]
00007b00b77db429  add rsp, 0x40
00007b00b77db42d  vmovaps xmm0, [rsp]
00007b00b77db432  vmovaps xmm1, [rsp+0x10]
00007b00b77db438  vmovaps xmm2, [rsp+0x20]
00007b00b77db43e  vmovaps xmm4, [rsp+0x30]
00007b00b77db444  vmovaps xmm5, [rsp+0x40]
00007b00b77db44a  vmovaps xmm6, [rsp+0x50]
00007b00b77db450  vmovaps xmm7, [rsp+0x60]
00007b00b77db456  vmovaps xmm8, [rsp+0x70]
00007b00b77db45c  vmovaps xmm9, [rsp+0x80]
00007b00b77db465  vmovaps xmm10, [rsp+0x90]
00007b00b77db46e  vmovaps xmm11, [rsp+0xA0]
00007b00b77db477  vmovaps xmm12, [rsp+0xB0]
00007b00b77db480  vmovaps xmm13, [rsp+0xC0]
00007b00b77db489  vmovaps xmm14, [rsp+0xD0]
00007b00b77db492  vmovaps xmm15, [rsp+0xE0]
00007b00b77db49b  add rsp, 0xF0
00007b00b77db4a2  pop r11
00007b00b77db4a4  pop r10
00007b00b77db4a6  pop r9
00007b00b77db4a8  pop r8
00007b00b77db4aa  pop rsi
00007b00b77db4ab  pop rdi
00007b00b77db4ac  pop rdx
00007b00b77db4ad  pop rcx
00007b00b77db4ae  pop rax
00007b00b77db4af  add rsp, 0x08
00007b00b77db4b3  jmp 0x00007B00B77DA19A
00007b00b77db4b8  sub rsp, 0x08
00007b00b77db4bc  push rax
00007b00b77db4bd  push rcx
00007b00b77db4be  push rdx
00007b00b77db4bf  push rdi
00007b00b77db4c0  push rsi
00007b00b77db4c1  push r8
00007b00b77db4c3  push r9
00007b00b77db4c5  push r10
00007b00b77db4c7  push r11
00007b00b77db4c9  sub rsp, 0xF0
00007b00b77db4d0  vmovaps [rsp], xmm0
00007b00b77db4d5  vmovaps [rsp+0x10], xmm1
00007b00b77db4db  vmovaps [rsp+0x20], xmm2
00007b00b77db4e1  vmovaps [rsp+0x30], xmm3
00007b00b77db4e7  vmovaps [rsp+0x40], xmm4
00007b00b77db4ed  vmovaps [rsp+0x50], xmm5
00007b00b77db4f3  vmovaps [rsp+0x60], xmm7
00007b00b77db4f9  vmovaps [rsp+0x70], xmm8
00007b00b77db4ff  vmovaps [rsp+0x80], xmm9
00007b00b77db508  vmovaps [rsp+0x90], xmm10
00007b00b77db511  vmovaps [rsp+0xA0], xmm11
00007b00b77db51a  vmovaps [rsp+0xB0], xmm12
00007b00b77db523  vmovaps [rsp+0xC0], xmm13
00007b00b77db52c  vmovaps [rsp+0xD0], xmm14
00007b00b77db535  vmovaps [rsp+0xE0], xmm15
00007b00b77db53e  sub rsp, 0x40
00007b00b77db542  lea rdi, [rsp]
00007b00b77db546  lea rsi, [rsp+0x10]
00007b00b77db54b  lea rdx, [rsp+0x20]
00007b00b77db550  lea rcx, [rsp+0x30]
00007b00b77db555  mov r8d, 0x00
00007b00b77db55b  lea r9, [r15+0x3A8]
00007b00b77db562  movaps [rdi], xmm6
00007b00b77db565  movaps [rsi], xmm2
00007b00b77db568  movaps [rdx], xmm14
00007b00b77db56c  movaps [rcx], xmm1
00007b00b77db56f  mov rax, 0x612A23581A50
00007b00b77db579  call rax
00007b00b77db57b  movaps xmm6, [rsp]
00007b00b77db57f  add rsp, 0x40
00007b00b77db583  vmovaps xmm0, [rsp]
00007b00b77db588  vmovaps xmm1, [rsp+0x10]
00007b00b77db58e  vmovaps xmm2, [rsp+0x20]
00007b00b77db594  vmovaps xmm3, [rsp+0x30]
00007b00b77db59a  vmovaps xmm4, [rsp+0x40]
00007b00b77db5a0  vmovaps xmm5, [rsp+0x50]
00007b00b77db5a6  vmovaps xmm7, [rsp+0x60]
00007b00b77db5ac  vmovaps xmm8, [rsp+0x70]
00007b00b77db5b2  vmovaps xmm9, [rsp+0x80]
00007b00b77db5bb  vmovaps xmm10, [rsp+0x90]
00007b00b77db5c4  vmovaps xmm11, [rsp+0xA0]
00007b00b77db5cd  vmovaps xmm12, [rsp+0xB0]
00007b00b77db5d6  vmovaps xmm13, [rsp+0xC0]
00007b00b77db5df  vmovaps xmm14, [rsp+0xD0]
00007b00b77db5e8  vmovaps xmm15, [rsp+0xE0]
00007b00b77db5f1  add rsp, 0xF0
00007b00b77db5f8  pop r11
00007b00b77db5fa  pop r10
00007b00b77db5fc  pop r9
00007b00b77db5fe  pop r8
00007b00b77db600  pop rsi
00007b00b77db601  pop rdi
00007b00b77db602  pop rdx
00007b00b77db603  pop rcx
00007b00b77db604  pop rax
00007b00b77db605  add rsp, 0x08
00007b00b77db609  jmp 0x00007B00B77DA1C7
00007b00b77db60e  sub rsp, 0x08
00007b00b77db612  push rax
00007b00b77db613  push rcx
00007b00b77db614  push rdx
00007b00b77db615  push rdi
00007b00b77db616  push rsi
00007b00b77db617  push r8
00007b00b77db619  push r9
00007b00b77db61b  push r10
00007b00b77db61d  push r11
00007b00b77db61f  sub rsp, 0xF0
00007b00b77db626  vmovaps [rsp], xmm0
00007b00b77db62b  vmovaps [rsp+0x10], xmm1
00007b00b77db631  vmovaps [rsp+0x20], xmm2
00007b00b77db637  vmovaps [rsp+0x30], xmm3
00007b00b77db63d  vmovaps [rsp+0x40], xmm4
00007b00b77db643  vmovaps [rsp+0x50], xmm5
00007b00b77db649  vmovaps [rsp+0x60], xmm6
00007b00b77db64f  vmovaps [rsp+0x70], xmm7
00007b00b77db655  vmovaps [rsp+0x80], xmm8
00007b00b77db65e  vmovaps [rsp+0x90], xmm9
00007b00b77db667  vmovaps [rsp+0xA0], xmm10
00007b00b77db670  vmovaps [rsp+0xB0], xmm11
00007b00b77db679  vmovaps [rsp+0xC0], xmm12
00007b00b77db682  vmovaps [rsp+0xD0], xmm14
00007b00b77db68b  vmovaps [rsp+0xE0], xmm15
00007b00b77db694  sub rsp, 0x40
00007b00b77db698  lea rdi, [rsp]
00007b00b77db69c  lea rsi, [rsp+0x10]
00007b00b77db6a1  lea rdx, [rsp+0x20]
00007b00b77db6a6  lea rcx, [rsp+0x30]
00007b00b77db6ab  mov r8d, 0x00
00007b00b77db6b1  lea r9, [r15+0x3A8]
00007b00b77db6b8  movaps [rdi], xmm13
00007b00b77db6bc  movaps [rsi], xmm12
00007b00b77db6c0  movaps [rdx], xmm14
00007b00b77db6c4  movaps [rcx], xmm1
00007b00b77db6c7  mov rax, 0x612A23581A50
00007b00b77db6d1  call rax
00007b00b77db6d3  movaps xmm13, [rsp]
00007b00b77db6d8  add rsp, 0x40
00007b00b77db6dc  vmovaps xmm0, [rsp]
00007b00b77db6e1  vmovaps xmm1, [rsp+0x10]
00007b00b77db6e7  vmovaps xmm2, [rsp+0x20]
00007b00b77db6ed  vmovaps xmm3, [rsp+0x30]
00007b00b77db6f3  vmovaps xmm4, [rsp+0x40]
00007b00b77db6f9  vmovaps xmm5, [rsp+0x50]
00007b00b77db6ff  vmovaps xmm6, [rsp+0x60]
00007b00b77db705  vmovaps xmm7, [rsp+0x70]
00007b00b77db70b  vmovaps xmm8, [rsp+0x80]
00007b00b77db714  vmovaps xmm9, [rsp+0x90]
00007b00b77db71d  vmovaps xmm10, [rsp+0xA0]
00007b00b77db726  vmovaps xmm11, [rsp+0xB0]
00007b00b77db72f  vmovaps xmm12, [rsp+0xC0]
00007b00b77db738  vmovaps xmm14, [rsp+0xD0]
00007b00b77db741  vmovaps xmm15, [rsp+0xE0]
00007b00b77db74a  add rsp, 0xF0
00007b00b77db751  pop r11
00007b00b77db753  pop r10
00007b00b77db755  pop r9
00007b00b77db757  pop r8
00007b00b77db759  pop rsi
00007b00b77db75a  pop rdi
00007b00b77db75b  pop rdx
00007b00b77db75c  pop rcx
00007b00b77db75d  pop rax
00007b00b77db75e  add rsp, 0x08
00007b00b77db762  jmp 0x00007B00B77DA1F9
00007b00b77db767  sub rsp, 0x08
00007b00b77db76b  push rax
00007b00b77db76c  push rcx
00007b00b77db76d  push rdx
00007b00b77db76e  push rdi
00007b00b77db76f  push rsi
00007b00b77db770  push r8
00007b00b77db772  push r9
00007b00b77db774  push r10
00007b00b77db776  push r11
00007b00b77db778  sub rsp, 0xF0
00007b00b77db77f  vmovaps [rsp], xmm0
00007b00b77db784  vmovaps [rsp+0x10], xmm1
00007b00b77db78a  vmovaps [rsp+0x20], xmm2
00007b00b77db790  vmovaps [rsp+0x30], xmm3
00007b00b77db796  vmovaps [rsp+0x40], xmm4
00007b00b77db79c  vmovaps [rsp+0x50], xmm5
00007b00b77db7a2  vmovaps [rsp+0x60], xmm6
00007b00b77db7a8  vmovaps [rsp+0x70], xmm7
00007b00b77db7ae  vmovaps [rsp+0x80], xmm8
00007b00b77db7b7  vmovaps [rsp+0x90], xmm9
00007b00b77db7c0  vmovaps [rsp+0xA0], xmm10
00007b00b77db7c9  vmovaps [rsp+0xB0], xmm11
00007b00b77db7d2  vmovaps [rsp+0xC0], xmm13
00007b00b77db7db  vmovaps [rsp+0xD0], xmm14
00007b00b77db7e4  vmovaps [rsp+0xE0], xmm15
00007b00b77db7ed  sub rsp, 0x40
00007b00b77db7f1  lea rdi, [rsp]
00007b00b77db7f5  lea rsi, [rsp+0x10]
00007b00b77db7fa  lea rdx, [rsp+0x20]
00007b00b77db7ff  lea rcx, [rsp+0x30]
00007b00b77db804  mov r8d, 0x00
00007b00b77db80a  lea r9, [r15+0x3A8]
00007b00b77db811  movaps [rdi], xmm12
00007b00b77db815  movaps [rsi], xmm3
00007b00b77db818  movaps [rdx], xmm14
00007b00b77db81c  movaps [rcx], xmm5
00007b00b77db81f  mov rax, 0x612A23581A50
00007b00b77db829  call rax
00007b00b77db82b  movaps xmm12, [rsp]
00007b00b77db830  add rsp, 0x40
00007b00b77db834  vmovaps xmm0, [rsp]
00007b00b77db839  vmovaps xmm1, [rsp+0x10]
00007b00b77db83f  vmovaps xmm2, [rsp+0x20]
00007b00b77db845  vmovaps xmm3, [rsp+0x30]
00007b00b77db84b  vmovaps xmm4, [rsp+0x40]
00007b00b77db851  vmovaps xmm5, [rsp+0x50]
00007b00b77db857  vmovaps xmm6, [rsp+0x60]
00007b00b77db85d  vmovaps xmm7, [rsp+0x70]
00007b00b77db863  vmovaps xmm8, [rsp+0x80]
00007b00b77db86c  vmovaps xmm9, [rsp+0x90]
00007b00b77db875  vmovaps xmm10, [rsp+0xA0]
00007b00b77db87e  vmovaps xmm11, [rsp+0xB0]
00007b00b77db887  vmovaps xmm13, [rsp+0xC0]
00007b00b77db890  vmovaps xmm14, [rsp+0xD0]
00007b00b77db899  vmovaps xmm15, [rsp+0xE0]
00007b00b77db8a2  add rsp, 0xF0
00007b00b77db8a9  pop r11
00007b00b77db8ab  pop r10
00007b00b77db8ad  pop r9
00007b00b77db8af  pop r8
00007b00b77db8b1  pop rsi
00007b00b77db8b2  pop rdi
00007b00b77db8b3  pop rdx
00007b00b77db8b4  pop rcx
00007b00b77db8b5  pop rax
00007b00b77db8b6  add rsp, 0x08
00007b00b77db8ba  jmp 0x00007B00B77DA256
00007b00b77db8bf  sub rsp, 0x08
00007b00b77db8c3  push rax
00007b00b77db8c4  push rcx
00007b00b77db8c5  push rdx
00007b00b77db8c6  push rdi
00007b00b77db8c7  push rsi
00007b00b77db8c8  push r8
00007b00b77db8ca  push r9
00007b00b77db8cc  push r10
00007b00b77db8ce  push r11
00007b00b77db8d0  sub rsp, 0xF0
00007b00b77db8d7  vmovaps [rsp], xmm0
00007b00b77db8dc  vmovaps [rsp+0x10], xmm1
00007b00b77db8e2  vmovaps [rsp+0x20], xmm2
00007b00b77db8e8  vmovaps [rsp+0x30], xmm3
00007b00b77db8ee  vmovaps [rsp+0x40], xmm4
00007b00b77db8f4  vmovaps [rsp+0x50], xmm5
00007b00b77db8fa  vmovaps [rsp+0x60], xmm6
00007b00b77db900  vmovaps [rsp+0x70], xmm7
00007b00b77db906  vmovaps [rsp+0x80], xmm8
00007b00b77db90f  vmovaps [rsp+0x90], xmm9
00007b00b77db918  vmovaps [rsp+0xA0], xmm11
00007b00b77db921  vmovaps [rsp+0xB0], xmm12
00007b00b77db92a  vmovaps [rsp+0xC0], xmm13
00007b00b77db933  vmovaps [rsp+0xD0], xmm14
00007b00b77db93c  vmovaps [rsp+0xE0], xmm15
00007b00b77db945  sub rsp, 0x40
00007b00b77db949  lea rdi, [rsp]
00007b00b77db94d  lea rsi, [rsp+0x10]
00007b00b77db952  lea rdx, [rsp+0x20]
00007b00b77db957  lea rcx, [rsp+0x30]
00007b00b77db95c  mov r8d, 0x00
00007b00b77db962  lea r9, [r15+0x3A8]
00007b00b77db969  movaps [rdi], xmm10
00007b00b77db96d  movaps [rsi], xmm9
00007b00b77db971  movaps [rdx], xmm7
00007b00b77db974  movaps [rcx], xmm14
00007b00b77db978  mov rax, 0x612A23581A50
00007b00b77db982  call rax
00007b00b77db984  movaps xmm10, [rsp]
00007b00b77db989  add rsp, 0x40
00007b00b77db98d  vmovaps xmm0, [rsp]
00007b00b77db992  vmovaps xmm1, [rsp+0x10]
00007b00b77db998  vmovaps xmm2, [rsp+0x20]
00007b00b77db99e  vmovaps xmm3, [rsp+0x30]
00007b00b77db9a4  vmovaps xmm4, [rsp+0x40]
00007b00b77db9aa  vmovaps xmm5, [rsp+0x50]
00007b00b77db9b0  vmovaps xmm6, [rsp+0x60]
00007b00b77db9b6  vmovaps xmm7, [rsp+0x70]
00007b00b77db9bc  vmovaps xmm8, [rsp+0x80]
00007b00b77db9c5  vmovaps xmm9, [rsp+0x90]
00007b00b77db9ce  vmovaps xmm11, [rsp+0xA0]
00007b00b77db9d7  vmovaps xmm12, [rsp+0xB0]
00007b00b77db9e0  vmovaps xmm13, [rsp+0xC0]
00007b00b77db9e9  vmovaps xmm14, [rsp+0xD0]
00007b00b77db9f2  vmovaps xmm15, [rsp+0xE0]
00007b00b77db9fb  add rsp, 0xF0
00007b00b77dba02  pop r11
00007b00b77dba04  pop r10
00007b00b77dba06  pop r9
00007b00b77dba08  pop r8
00007b00b77dba0a  pop rsi
00007b00b77dba0b  pop rdi
00007b00b77dba0c  pop rdx
00007b00b77dba0d  pop rcx
00007b00b77dba0e  pop rax
00007b00b77dba0f  add rsp, 0x08
00007b00b77dba13  jmp 0x00007B00B77DA27C
00007b00b77dba18  call 0x00007B00B760D4E0
00007b00b77dba1d  jmp 0x00007B00B77DA289
00007b00b77dba22  sub rsp, 0x08
00007b00b77dba26  push rax
00007b00b77dba27  push rcx
00007b00b77dba28  push rdx
00007b00b77dba29  push rdi
00007b00b77dba2a  push rsi
00007b00b77dba2b  push r8
00007b00b77dba2d  push r9
00007b00b77dba2f  push r10
00007b00b77dba31  push r11
00007b00b77dba33  sub rsp, 0xF0
00007b00b77dba3a  vmovaps [rsp], xmm0
00007b00b77dba3f  vmovaps [rsp+0x10], xmm1
00007b00b77dba45  vmovaps [rsp+0x20], xmm2
00007b00b77dba4b  vmovaps [rsp+0x30], xmm3
00007b00b77dba51  vmovaps [rsp+0x40], xmm4
00007b00b77dba57  vmovaps [rsp+0x50], xmm6
00007b00b77dba5d  vmovaps [rsp+0x60], xmm7
00007b00b77dba63  vmovaps [rsp+0x70], xmm8
00007b00b77dba69  vmovaps [rsp+0x80], xmm9
00007b00b77dba72  vmovaps [rsp+0x90], xmm10
00007b00b77dba7b  vmovaps [rsp+0xA0], xmm11
00007b00b77dba84  vmovaps [rsp+0xB0], xmm12
00007b00b77dba8d  vmovaps [rsp+0xC0], xmm13
00007b00b77dba96  vmovaps [rsp+0xD0], xmm14
00007b00b77dba9f  vmovaps [rsp+0xE0], xmm15
00007b00b77dbaa8  sub rsp, 0x40
00007b00b77dbaac  lea rdi, [rsp]
00007b00b77dbab0  lea rsi, [rsp+0x10]
00007b00b77dbab5  lea rdx, [rsp+0x20]
00007b00b77dbaba  lea rcx, [rsp+0x30]
00007b00b77dbabf  mov r8d, 0x00
00007b00b77dbac5  lea r9, [r15+0x3A8]
00007b00b77dbacc  movaps [rdi], xmm5
00007b00b77dbacf  movaps [rsi], xmm6
00007b00b77dbad2  movaps [rdx], xmm7
00007b00b77dbad5  movaps [rcx], xmm9
00007b00b77dbad9  mov rax, 0x612A23581A50
00007b00b77dbae3  call rax
00007b00b77dbae5  movaps xmm5, [rsp]
00007b00b77dbae9  add rsp, 0x40
00007b00b77dbaed  vmovaps xmm0, [rsp]
00007b00b77dbaf2  vmovaps xmm1, [rsp+0x10]
00007b00b77dbaf8  vmovaps xmm2, [rsp+0x20]
00007b00b77dbafe  vmovaps xmm3, [rsp+0x30]
00007b00b77dbb04  vmovaps xmm4, [rsp+0x40]
00007b00b77dbb0a  vmovaps xmm6, [rsp+0x50]
00007b00b77dbb10  vmovaps xmm7, [rsp+0x60]
00007b00b77dbb16  vmovaps xmm8, [rsp+0x70]
00007b00b77dbb1c  vmovaps xmm9, [rsp+0x80]
00007b00b77dbb25  vmovaps xmm10, [rsp+0x90]
00007b00b77dbb2e  vmovaps xmm11, [rsp+0xA0]
00007b00b77dbb37  vmovaps xmm12, [rsp+0xB0]
00007b00b77dbb40  vmovaps xmm13, [rsp+0xC0]
00007b00b77dbb49  vmovaps xmm14, [rsp+0xD0]
00007b00b77dbb52  vmovaps xmm15, [rsp+0xE0]
00007b00b77dbb5b  add rsp, 0xF0
00007b00b77dbb62  pop r11
00007b00b77dbb64  pop r10
00007b00b77dbb66  pop r9
00007b00b77dbb68  pop r8
00007b00b77dbb6a  pop rsi
00007b00b77dbb6b  pop rdi
00007b00b77dbb6c  pop rdx
00007b00b77dbb6d  pop rcx
00007b00b77dbb6e  pop rax
00007b00b77dbb6f  add rsp, 0x08
00007b00b77dbb73  jmp 0x00007B00B77DA2BB
00007b00b77dbb78  sub rsp, 0x08
00007b00b77dbb7c  push rax
00007b00b77dbb7d  push rcx
00007b00b77dbb7e  push rdx
00007b00b77dbb7f  push rdi
00007b00b77dbb80  push rsi
00007b00b77dbb81  push r8
00007b00b77dbb83  push r9
00007b00b77dbb85  push r10
00007b00b77dbb87  push r11
00007b00b77dbb89  sub rsp, 0xF0
00007b00b77dbb90  vmovaps [rsp], xmm0
00007b00b77dbb95  vmovaps [rsp+0x10], xmm1
00007b00b77dbb9b  vmovaps [rsp+0x20], xmm2
00007b00b77dbba1  vmovaps [rsp+0x30], xmm3
00007b00b77dbba7  vmovaps [rsp+0x40], xmm4
00007b00b77dbbad  vmovaps [rsp+0x50], xmm5
00007b00b77dbbb3  vmovaps [rsp+0x60], xmm6
00007b00b77dbbb9  vmovaps [rsp+0x70], xmm8
00007b00b77dbbbf  vmovaps [rsp+0x80], xmm9
00007b00b77dbbc8  vmovaps [rsp+0x90], xmm10
00007b00b77dbbd1  vmovaps [rsp+0xA0], xmm11
00007b00b77dbbda  vmovaps [rsp+0xB0], xmm12
00007b00b77dbbe3  vmovaps [rsp+0xC0], xmm13
00007b00b77dbbec  vmovaps [rsp+0xD0], xmm14
00007b00b77dbbf5  vmovaps [rsp+0xE0], xmm15
00007b00b77dbbfe  sub rsp, 0x40
00007b00b77dbc02  lea rdi, [rsp]
00007b00b77dbc06  lea rsi, [rsp+0x10]
00007b00b77dbc0b  lea rdx, [rsp+0x20]
00007b00b77dbc10  lea rcx, [rsp+0x30]
00007b00b77dbc15  mov r8d, 0x00
00007b00b77dbc1b  lea r9, [r15+0x3A8]
00007b00b77dbc22  movaps [rdi], xmm7
00007b00b77dbc25  movaps [rsi], xmm13
00007b00b77dbc29  movaps [rdx], xmm1
00007b00b77dbc2c  movaps [rcx], xmm9
00007b00b77dbc30  mov rax, 0x612A23581A50
00007b00b77dbc3a  call rax
00007b00b77dbc3c  movaps xmm7, [rsp]
00007b00b77dbc40  add rsp, 0x40
00007b00b77dbc44  vmovaps xmm0, [rsp]
00007b00b77dbc49  vmovaps xmm1, [rsp+0x10]
00007b00b77dbc4f  vmovaps xmm2, [rsp+0x20]
00007b00b77dbc55  vmovaps xmm3, [rsp+0x30]
00007b00b77dbc5b  vmovaps xmm4, [rsp+0x40]
00007b00b77dbc61  vmovaps xmm5, [rsp+0x50]
00007b00b77dbc67  vmovaps xmm6, [rsp+0x60]
00007b00b77dbc6d  vmovaps xmm8, [rsp+0x70]
00007b00b77dbc73  vmovaps xmm9, [rsp+0x80]
00007b00b77dbc7c  vmovaps xmm10, [rsp+0x90]
00007b00b77dbc85  vmovaps xmm11, [rsp+0xA0]
00007b00b77dbc8e  vmovaps xmm12, [rsp+0xB0]
00007b00b77dbc97  vmovaps xmm13, [rsp+0xC0]
00007b00b77dbca0  vmovaps xmm14, [rsp+0xD0]
00007b00b77dbca9  vmovaps xmm15, [rsp+0xE0]
00007b00b77dbcb2  add rsp, 0xF0
00007b00b77dbcb9  pop r11
00007b00b77dbcbb  pop r10
00007b00b77dbcbd  pop r9
00007b00b77dbcbf  pop r8
00007b00b77dbcc1  pop rsi
00007b00b77dbcc2  pop rdi
00007b00b77dbcc3  pop rdx
00007b00b77dbcc4  pop rcx
00007b00b77dbcc5  pop rax
00007b00b77dbcc6  add rsp, 0x08
00007b00b77dbcca  jmp 0x00007B00B77DA2E0
00007b00b77dbccf  call 0x00007B00B760C260
00007b00b77dbcd4  jmp 0x00007B00B77DA303
00007b00b77dbcd9  call 0x00007B00B7607890
00007b00b77dbcde  jmp 0x00007B00B77DA30D
00007b00b77dbce3  sub rsp, 0x08
00007b00b77dbce7  push rax
00007b00b77dbce8  push rcx
00007b00b77dbce9  push rdx
00007b00b77dbcea  push rdi
00007b00b77dbceb  push rsi
00007b00b77dbcec  push r8
00007b00b77dbcee  push r9
00007b00b77dbcf0  push r10
00007b00b77dbcf2  push r11
00007b00b77dbcf4  sub rsp, 0xF0
00007b00b77dbcfb  vmovaps [rsp], xmm0
00007b00b77dbd00  vmovaps [rsp+0x10], xmm1
00007b00b77dbd06  vmovaps [rsp+0x20], xmm3
00007b00b77dbd0c  vmovaps [rsp+0x30], xmm4
00007b00b77dbd12  vmovaps [rsp+0x40], xmm5
00007b00b77dbd18  vmovaps [rsp+0x50], xmm6
00007b00b77dbd1e  vmovaps [rsp+0x60], xmm7
00007b00b77dbd24  vmovaps [rsp+0x70], xmm8
00007b00b77dbd2a  vmovaps [rsp+0x80], xmm9
00007b00b77dbd33  vmovaps [rsp+0x90], xmm10
00007b00b77dbd3c  vmovaps [rsp+0xA0], xmm11
00007b00b77dbd45  vmovaps [rsp+0xB0], xmm12
00007b00b77dbd4e  vmovaps [rsp+0xC0], xmm13
00007b00b77dbd57  vmovaps [rsp+0xD0], xmm14
00007b00b77dbd60  vmovaps [rsp+0xE0], xmm15
00007b00b77dbd69  sub rsp, 0x40
00007b00b77dbd6d  lea rdi, [rsp]
00007b00b77dbd71  lea rsi, [rsp+0x10]
00007b00b77dbd76  lea rdx, [rsp+0x20]
00007b00b77dbd7b  lea rcx, [rsp+0x30]
00007b00b77dbd80  mov r8d, 0x00
00007b00b77dbd86  lea r9, [r15+0x3A8]
00007b00b77dbd8d  movaps [rdi], xmm2
00007b00b77dbd90  movaps [rsi], xmm12
00007b00b77dbd94  movaps [rdx], xmm6
00007b00b77dbd97  movaps [rcx], xmm3
00007b00b77dbd9a  mov rax, 0x612A23581A50
00007b00b77dbda4  call rax
00007b00b77dbda6  movaps xmm2, [rsp]
00007b00b77dbdaa  add rsp, 0x40
00007b00b77dbdae  vmovaps xmm0, [rsp]
00007b00b77dbdb3  vmovaps xmm1, [rsp+0x10]
00007b00b77dbdb9  vmovaps xmm3, [rsp+0x20]
00007b00b77dbdbf  vmovaps xmm4, [rsp+0x30]
00007b00b77dbdc5  vmovaps xmm5, [rsp+0x40]
00007b00b77dbdcb  vmovaps xmm6, [rsp+0x50]
00007b00b77dbdd1  vmovaps xmm7, [rsp+0x60]
00007b00b77dbdd7  vmovaps xmm8, [rsp+0x70]
00007b00b77dbddd  vmovaps xmm9, [rsp+0x80]
00007b00b77dbde6  vmovaps xmm10, [rsp+0x90]
00007b00b77dbdef  vmovaps xmm11, [rsp+0xA0]
00007b00b77dbdf8  vmovaps xmm12, [rsp+0xB0]
00007b00b77dbe01  vmovaps xmm13, [rsp+0xC0]
00007b00b77dbe0a  vmovaps xmm14, [rsp+0xD0]
00007b00b77dbe13  vmovaps xmm15, [rsp+0xE0]
00007b00b77dbe1c  add rsp, 0xF0
00007b00b77dbe23  pop r11
00007b00b77dbe25  pop r10
00007b00b77dbe27  pop r9
00007b00b77dbe29  pop r8
00007b00b77dbe2b  pop rsi
00007b00b77dbe2c  pop rdi
00007b00b77dbe2d  pop rdx
00007b00b77dbe2e  pop rcx
00007b00b77dbe2f  pop rax
00007b00b77dbe30  add rsp, 0x08
00007b00b77dbe34  jmp 0x00007B00B77DA353
00007b00b77dbe39  sub rsp, 0x08
00007b00b77dbe3d  push rax
00007b00b77dbe3e  push rcx
00007b00b77dbe3f  push rdx
00007b00b77dbe40  push rdi
00007b00b77dbe41  push rsi
00007b00b77dbe42  push r8
00007b00b77dbe44  push r9
00007b00b77dbe46  push r10
00007b00b77dbe48  push r11
00007b00b77dbe4a  sub rsp, 0xF0
00007b00b77dbe51  vmovaps [rsp], xmm0
00007b00b77dbe56  vmovaps [rsp+0x10], xmm1
00007b00b77dbe5c  vmovaps [rsp+0x20], xmm2
00007b00b77dbe62  vmovaps [rsp+0x30], xmm3
00007b00b77dbe68  vmovaps [rsp+0x40], xmm4
00007b00b77dbe6e  vmovaps [rsp+0x50], xmm5
00007b00b77dbe74  vmovaps [rsp+0x60], xmm7
00007b00b77dbe7a  vmovaps [rsp+0x70], xmm8
00007b00b77dbe80  vmovaps [rsp+0x80], xmm9
00007b00b77dbe89  vmovaps [rsp+0x90], xmm10
00007b00b77dbe92  vmovaps [rsp+0xA0], xmm11
00007b00b77dbe9b  vmovaps [rsp+0xB0], xmm12
00007b00b77dbea4  vmovaps [rsp+0xC0], xmm13
00007b00b77dbead  vmovaps [rsp+0xD0], xmm14
00007b00b77dbeb6  vmovaps [rsp+0xE0], xmm15
00007b00b77dbebf  sub rsp, 0x40
00007b00b77dbec3  lea rdi, [rsp]
00007b00b77dbec7  lea rsi, [rsp+0x10]
00007b00b77dbecc  lea rdx, [rsp+0x20]
00007b00b77dbed1  lea rcx, [rsp+0x30]
00007b00b77dbed6  mov r8d, 0x00
00007b00b77dbedc  lea r9, [r15+0x3A8]
00007b00b77dbee3  movaps [rdi], xmm6
00007b00b77dbee6  movaps [rsi], xmm10
00007b00b77dbeea  movaps [rdx], xmm12
00007b00b77dbeee  movaps [rcx], xmm1
00007b00b77dbef1  mov rax, 0x612A23581A50
00007b00b77dbefb  call rax
00007b00b77dbefd  movaps xmm6, [rsp]
00007b00b77dbf01  add rsp, 0x40
00007b00b77dbf05  vmovaps xmm0, [rsp]
00007b00b77dbf0a  vmovaps xmm1, [rsp+0x10]
00007b00b77dbf10  vmovaps xmm2, [rsp+0x20]
00007b00b77dbf16  vmovaps xmm3, [rsp+0x30]
00007b00b77dbf1c  vmovaps xmm4, [rsp+0x40]
00007b00b77dbf22  vmovaps xmm5, [rsp+0x50]
00007b00b77dbf28  vmovaps xmm7, [rsp+0x60]
00007b00b77dbf2e  vmovaps xmm8, [rsp+0x70]
00007b00b77dbf34  vmovaps xmm9, [rsp+0x80]
00007b00b77dbf3d  vmovaps xmm10, [rsp+0x90]
00007b00b77dbf46  vmovaps xmm11, [rsp+0xA0]
00007b00b77dbf4f  vmovaps xmm12, [rsp+0xB0]
00007b00b77dbf58  vmovaps xmm13, [rsp+0xC0]
00007b00b77dbf61  vmovaps xmm14, [rsp+0xD0]
00007b00b77dbf6a  vmovaps xmm15, [rsp+0xE0]
00007b00b77dbf73  add rsp, 0xF0
00007b00b77dbf7a  pop r11
00007b00b77dbf7c  pop r10
00007b00b77dbf7e  pop r9
00007b00b77dbf80  pop r8
00007b00b77dbf82  pop rsi
00007b00b77dbf83  pop rdi
00007b00b77dbf84  pop rdx
00007b00b77dbf85  pop rcx
00007b00b77dbf86  pop rax
00007b00b77dbf87  add rsp, 0x08
00007b00b77dbf8b  jmp 0x00007B00B77DA381
00007b00b77dbf90  sub rsp, 0x08
00007b00b77dbf94  push rax
00007b00b77dbf95  push rcx
00007b00b77dbf96  push rdx
00007b00b77dbf97  push rdi
00007b00b77dbf98  push rsi
00007b00b77dbf99  push r8
00007b00b77dbf9b  push r9
00007b00b77dbf9d  push r10
00007b00b77dbf9f  push r11
00007b00b77dbfa1  sub rsp, 0xF0
00007b00b77dbfa8  vmovaps [rsp], xmm0
00007b00b77dbfad  vmovaps [rsp+0x10], xmm1
00007b00b77dbfb3  vmovaps [rsp+0x20], xmm2
00007b00b77dbfb9  vmovaps [rsp+0x30], xmm3
00007b00b77dbfbf  vmovaps [rsp+0x40], xmm4
00007b00b77dbfc5  vmovaps [rsp+0x50], xmm5
00007b00b77dbfcb  vmovaps [rsp+0x60], xmm6
00007b00b77dbfd1  vmovaps [rsp+0x70], xmm7
00007b00b77dbfd7  vmovaps [rsp+0x80], xmm8
00007b00b77dbfe0  vmovaps [rsp+0x90], xmm9
00007b00b77dbfe9  vmovaps [rsp+0xA0], xmm11
00007b00b77dbff2  vmovaps [rsp+0xB0], xmm12
00007b00b77dbffb  vmovaps [rsp+0xC0], xmm13
00007b00b77dc004  vmovaps [rsp+0xD0], xmm14
00007b00b77dc00d  vmovaps [rsp+0xE0], xmm15
00007b00b77dc016  sub rsp, 0x40
00007b00b77dc01a  lea rdi, [rsp]
00007b00b77dc01e  lea rsi, [rsp+0x10]
00007b00b77dc023  lea rdx, [rsp+0x20]
00007b00b77dc028  lea rcx, [rsp+0x30]
00007b00b77dc02d  mov r8d, 0x00
00007b00b77dc033  lea r9, [r15+0x3A8]
00007b00b77dc03a  movaps [rdi], xmm10
00007b00b77dc03e  movaps [rsi], xmm5
00007b00b77dc041  movaps [rdx], xmm12
00007b00b77dc045  movaps [rcx], xmm1
00007b00b77dc048  mov rax, 0x612A23581A50
00007b00b77dc052  call rax
00007b00b77dc054  movaps xmm10, [rsp]
00007b00b77dc059  add rsp, 0x40
00007b00b77dc05d  vmovaps xmm0, [rsp]
00007b00b77dc062  vmovaps xmm1, [rsp+0x10]
00007b00b77dc068  vmovaps xmm2, [rsp+0x20]
00007b00b77dc06e  vmovaps xmm3, [rsp+0x30]
00007b00b77dc074  vmovaps xmm4, [rsp+0x40]
00007b00b77dc07a  vmovaps xmm5, [rsp+0x50]
00007b00b77dc080  vmovaps xmm6, [rsp+0x60]
00007b00b77dc086  vmovaps xmm7, [rsp+0x70]
00007b00b77dc08c  vmovaps xmm8, [rsp+0x80]
00007b00b77dc095  vmovaps xmm9, [rsp+0x90]
00007b00b77dc09e  vmovaps xmm11, [rsp+0xA0]
00007b00b77dc0a7  vmovaps xmm12, [rsp+0xB0]
00007b00b77dc0b0  vmovaps xmm13, [rsp+0xC0]
00007b00b77dc0b9  vmovaps xmm14, [rsp+0xD0]
00007b00b77dc0c2  vmovaps xmm15, [rsp+0xE0]
00007b00b77dc0cb  add rsp, 0xF0
00007b00b77dc0d2  pop r11
00007b00b77dc0d4  pop r10
00007b00b77dc0d6  pop r9
00007b00b77dc0d8  pop r8
00007b00b77dc0da  pop rsi
00007b00b77dc0db  pop rdi
00007b00b77dc0dc  pop rdx
00007b00b77dc0dd  pop rcx
00007b00b77dc0de  pop rax
00007b00b77dc0df  add rsp, 0x08
00007b00b77dc0e3  jmp 0x00007B00B77DA3B0
00007b00b77dc0e8  sub rsp, 0x08
00007b00b77dc0ec  push rax
00007b00b77dc0ed  push rcx
00007b00b77dc0ee  push rdx
00007b00b77dc0ef  push rdi
00007b00b77dc0f0  push rsi
00007b00b77dc0f1  push r8
00007b00b77dc0f3  push r9
00007b00b77dc0f5  push r10
00007b00b77dc0f7  push r11
00007b00b77dc0f9  sub rsp, 0xF0
00007b00b77dc100  vmovaps [rsp], xmm0
00007b00b77dc105  vmovaps [rsp+0x10], xmm1
00007b00b77dc10b  vmovaps [rsp+0x20], xmm2
00007b00b77dc111  vmovaps [rsp+0x30], xmm3
00007b00b77dc117  vmovaps [rsp+0x40], xmm4
00007b00b77dc11d  vmovaps [rsp+0x50], xmm5
00007b00b77dc123  vmovaps [rsp+0x60], xmm6
00007b00b77dc129  vmovaps [rsp+0x70], xmm7
00007b00b77dc12f  vmovaps [rsp+0x80], xmm8
00007b00b77dc138  vmovaps [rsp+0x90], xmm9
00007b00b77dc141  vmovaps [rsp+0xA0], xmm10
00007b00b77dc14a  vmovaps [rsp+0xB0], xmm11
00007b00b77dc153  vmovaps [rsp+0xC0], xmm13
00007b00b77dc15c  vmovaps [rsp+0xD0], xmm14
00007b00b77dc165  vmovaps [rsp+0xE0], xmm15
00007b00b77dc16e  sub rsp, 0x40
00007b00b77dc172  lea rdi, [rsp]
00007b00b77dc176  lea rsi, [rsp+0x10]
00007b00b77dc17b  lea rdx, [rsp+0x20]
00007b00b77dc180  lea rcx, [rsp+0x30]
00007b00b77dc185  mov r8d, 0x00
00007b00b77dc18b  lea r9, [r15+0x3A8]
00007b00b77dc192  movaps [rdi], xmm12
00007b00b77dc196  movaps [rsi], xmm7
00007b00b77dc199  movaps [rdx], xmm15
00007b00b77dc19d  movaps [rcx], xmm1
00007b00b77dc1a0  mov rax, 0x612A23581A50
00007b00b77dc1aa  call rax
00007b00b77dc1ac  movaps xmm12, [rsp]
00007b00b77dc1b1  add rsp, 0x40
00007b00b77dc1b5  vmovaps xmm0, [rsp]
00007b00b77dc1ba  vmovaps xmm1, [rsp+0x10]
00007b00b77dc1c0  vmovaps xmm2, [rsp+0x20]
00007b00b77dc1c6  vmovaps xmm3, [rsp+0x30]
00007b00b77dc1cc  vmovaps xmm4, [rsp+0x40]
00007b00b77dc1d2  vmovaps xmm5, [rsp+0x50]
00007b00b77dc1d8  vmovaps xmm6, [rsp+0x60]
00007b00b77dc1de  vmovaps xmm7, [rsp+0x70]
00007b00b77dc1e4  vmovaps xmm8, [rsp+0x80]
00007b00b77dc1ed  vmovaps xmm9, [rsp+0x90]
00007b00b77dc1f6  vmovaps xmm10, [rsp+0xA0]
00007b00b77dc1ff  vmovaps xmm11, [rsp+0xB0]
00007b00b77dc208  vmovaps xmm13, [rsp+0xC0]
00007b00b77dc211  vmovaps xmm14, [rsp+0xD0]
00007b00b77dc21a  vmovaps xmm15, [rsp+0xE0]
00007b00b77dc223  add rsp, 0xF0
00007b00b77dc22a  pop r11
00007b00b77dc22c  pop r10
00007b00b77dc22e  pop r9
00007b00b77dc230  pop r8
00007b00b77dc232  pop rsi
00007b00b77dc233  pop rdi
00007b00b77dc234  pop rdx
00007b00b77dc235  pop rcx
00007b00b77dc236  pop rax
00007b00b77dc237  add rsp, 0x08
00007b00b77dc23b  jmp 0x00007B00B77DA3D9
00007b00b77dc240  call 0x00007B00B75FF430
00007b00b77dc245  jmp 0x00007B00B77DA3E3
00007b00b77dc24a  call 0x00007B00B760E760
00007b00b77dc24f  jmp 0x00007B00B77DA3ED
00007b00b77dc254  sub rsp, 0x08
00007b00b77dc258  push rax
00007b00b77dc259  push rcx
00007b00b77dc25a  push rdx
00007b00b77dc25b  push rdi
00007b00b77dc25c  push rsi
00007b00b77dc25d  push r8
00007b00b77dc25f  push r9
00007b00b77dc261  push r10
00007b00b77dc263  push r11
00007b00b77dc265  sub rsp, 0xF0
00007b00b77dc26c  vmovaps [rsp], xmm0
00007b00b77dc271  vmovaps [rsp+0x10], xmm1
00007b00b77dc277  vmovaps [rsp+0x20], xmm2
00007b00b77dc27d  vmovaps [rsp+0x30], xmm3
00007b00b77dc283  vmovaps [rsp+0x40], xmm4
00007b00b77dc289  vmovaps [rsp+0x50], xmm5
00007b00b77dc28f  vmovaps [rsp+0x60], xmm6
00007b00b77dc295  vmovaps [rsp+0x70], xmm8
00007b00b77dc29b  vmovaps [rsp+0x80], xmm9
00007b00b77dc2a4  vmovaps [rsp+0x90], xmm10
00007b00b77dc2ad  vmovaps [rsp+0xA0], xmm11
00007b00b77dc2b6  vmovaps [rsp+0xB0], xmm12
00007b00b77dc2bf  vmovaps [rsp+0xC0], xmm13
00007b00b77dc2c8  vmovaps [rsp+0xD0], xmm14
00007b00b77dc2d1  vmovaps [rsp+0xE0], xmm15
00007b00b77dc2da  sub rsp, 0x40
00007b00b77dc2de  lea rdi, [rsp]
00007b00b77dc2e2  lea rsi, [rsp+0x10]
00007b00b77dc2e7  lea rdx, [rsp+0x20]
00007b00b77dc2ec  lea rcx, [rsp+0x30]
00007b00b77dc2f1  mov r8d, 0x00
00007b00b77dc2f7  lea r9, [r15+0x3A8]
00007b00b77dc2fe  movaps [rdi], xmm7
00007b00b77dc301  movaps [rsi], xmm2
00007b00b77dc304  movaps [rdx], xmm9
00007b00b77dc308  movaps [rcx], xmm11
00007b00b77dc30c  mov rax, 0x612A23581A50
00007b00b77dc316  call rax
00007b00b77dc318  movaps xmm7, [rsp]
00007b00b77dc31c  add rsp, 0x40
00007b00b77dc320  vmovaps xmm0, [rsp]
00007b00b77dc325  vmovaps xmm1, [rsp+0x10]
00007b00b77dc32b  vmovaps xmm2, [rsp+0x20]
00007b00b77dc331  vmovaps xmm3, [rsp+0x30]
00007b00b77dc337  vmovaps xmm4, [rsp+0x40]
00007b00b77dc33d  vmovaps xmm5, [rsp+0x50]
00007b00b77dc343  vmovaps xmm6, [rsp+0x60]
00007b00b77dc349  vmovaps xmm8, [rsp+0x70]
00007b00b77dc34f  vmovaps xmm9, [rsp+0x80]
00007b00b77dc358  vmovaps xmm10, [rsp+0x90]
00007b00b77dc361  vmovaps xmm11, [rsp+0xA0]
00007b00b77dc36a  vmovaps xmm12, [rsp+0xB0]
00007b00b77dc373  vmovaps xmm13, [rsp+0xC0]
00007b00b77dc37c  vmovaps xmm14, [rsp+0xD0]
00007b00b77dc385  vmovaps xmm15, [rsp+0xE0]
00007b00b77dc38e  add rsp, 0xF0
00007b00b77dc395  pop r11
00007b00b77dc397  pop r10
00007b00b77dc399  pop r9
00007b00b77dc39b  pop r8
00007b00b77dc39d  pop rsi
00007b00b77dc39e  pop rdi
00007b00b77dc39f  pop rdx
00007b00b77dc3a0  pop rcx
00007b00b77dc3a1  pop rax
00007b00b77dc3a2  add rsp, 0x08
00007b00b77dc3a6  jmp 0x00007B00B77DA421
00007b00b77dc3ab  sub rsp, 0x08
00007b00b77dc3af  push rax
00007b00b77dc3b0  push rcx
00007b00b77dc3b1  push rdx
00007b00b77dc3b2  push rdi
00007b00b77dc3b3  push rsi
00007b00b77dc3b4  push r8
00007b00b77dc3b6  push r9
00007b00b77dc3b8  push r10
00007b00b77dc3ba  push r11
00007b00b77dc3bc  sub rsp, 0xF0
00007b00b77dc3c3  vmovaps [rsp], xmm0
00007b00b77dc3c8  vmovaps [rsp+0x10], xmm1
00007b00b77dc3ce  vmovaps [rsp+0x20], xmm2
00007b00b77dc3d4  vmovaps [rsp+0x30], xmm3
00007b00b77dc3da  vmovaps [rsp+0x40], xmm4
00007b00b77dc3e0  vmovaps [rsp+0x50], xmm5
00007b00b77dc3e6  vmovaps [rsp+0x60], xmm6
00007b00b77dc3ec  vmovaps [rsp+0x70], xmm7
00007b00b77dc3f2  vmovaps [rsp+0x80], xmm8
00007b00b77dc3fb  vmovaps [rsp+0x90], xmm10
00007b00b77dc404  vmovaps [rsp+0xA0], xmm11
00007b00b77dc40d  vmovaps [rsp+0xB0], xmm12
00007b00b77dc416  vmovaps [rsp+0xC0], xmm13
00007b00b77dc41f  vmovaps [rsp+0xD0], xmm14
00007b00b77dc428  vmovaps [rsp+0xE0], xmm15
00007b00b77dc431  sub rsp, 0x40
00007b00b77dc435  lea rdi, [rsp]
00007b00b77dc439  lea rsi, [rsp+0x10]
00007b00b77dc43e  lea rdx, [rsp+0x20]
00007b00b77dc443  lea rcx, [rsp+0x30]
00007b00b77dc448  mov r8d, 0x00
00007b00b77dc44e  lea r9, [r15+0x3A8]
00007b00b77dc455  movaps [rdi], xmm9
00007b00b77dc459  movaps [rsi], xmm6
00007b00b77dc45c  movaps [rdx], xmm1
00007b00b77dc45f  movaps [rcx], xmm11
00007b00b77dc463  mov rax, 0x612A23581A50
00007b00b77dc46d  call rax
00007b00b77dc46f  movaps xmm9, [rsp]
00007b00b77dc474  add rsp, 0x40
00007b00b77dc478  vmovaps xmm0, [rsp]
00007b00b77dc47d  vmovaps xmm1, [rsp+0x10]
00007b00b77dc483  vmovaps xmm2, [rsp+0x20]
00007b00b77dc489  vmovaps xmm3, [rsp+0x30]
00007b00b77dc48f  vmovaps xmm4, [rsp+0x40]
00007b00b77dc495  vmovaps xmm5, [rsp+0x50]
00007b00b77dc49b  vmovaps xmm6, [rsp+0x60]
00007b00b77dc4a1  vmovaps xmm7, [rsp+0x70]
00007b00b77dc4a7  vmovaps xmm8, [rsp+0x80]
00007b00b77dc4b0  vmovaps xmm10, [rsp+0x90]
00007b00b77dc4b9  vmovaps xmm11, [rsp+0xA0]
00007b00b77dc4c2  vmovaps xmm12, [rsp+0xB0]
00007b00b77dc4cb  vmovaps xmm13, [rsp+0xC0]
00007b00b77dc4d4  vmovaps xmm14, [rsp+0xD0]
00007b00b77dc4dd  vmovaps xmm15, [rsp+0xE0]
00007b00b77dc4e6  add rsp, 0xF0
00007b00b77dc4ed  pop r11
00007b00b77dc4ef  pop r10
00007b00b77dc4f1  pop r9
00007b00b77dc4f3  pop r8
00007b00b77dc4f5  pop rsi
00007b00b77dc4f6  pop rdi
00007b00b77dc4f7  pop rdx
00007b00b77dc4f8  pop rcx
00007b00b77dc4f9  pop rax
00007b00b77dc4fa  add rsp, 0x08
00007b00b77dc4fe  jmp 0x00007B00B77DA447
00007b00b77dc503  sub rsp, 0x08
00007b00b77dc507  push rax
00007b00b77dc508  push rcx
00007b00b77dc509  push rdx
00007b00b77dc50a  push rdi
00007b00b77dc50b  push rsi
00007b00b77dc50c  push r8
00007b00b77dc50e  push r9
00007b00b77dc510  push r10
00007b00b77dc512  push r11
00007b00b77dc514  sub rsp, 0xF0
00007b00b77dc51b  vmovaps [rsp], xmm0
00007b00b77dc520  vmovaps [rsp+0x10], xmm1
00007b00b77dc526  vmovaps [rsp+0x20], xmm2
00007b00b77dc52c  vmovaps [rsp+0x30], xmm3
00007b00b77dc532  vmovaps [rsp+0x40], xmm4
00007b00b77dc538  vmovaps [rsp+0x50], xmm5
00007b00b77dc53e  vmovaps [rsp+0x60], xmm6
00007b00b77dc544  vmovaps [rsp+0x70], xmm7
00007b00b77dc54a  vmovaps [rsp+0x80], xmm8
00007b00b77dc553  vmovaps [rsp+0x90], xmm9
00007b00b77dc55c  vmovaps [rsp+0xA0], xmm10
00007b00b77dc565  vmovaps [rsp+0xB0], xmm12
00007b00b77dc56e  vmovaps [rsp+0xC0], xmm13
00007b00b77dc577  vmovaps [rsp+0xD0], xmm14
00007b00b77dc580  vmovaps [rsp+0xE0], xmm15
00007b00b77dc589  sub rsp, 0x40
00007b00b77dc58d  lea rdi, [rsp]
00007b00b77dc591  lea rsi, [rsp+0x10]
00007b00b77dc596  lea rdx, [rsp+0x20]
00007b00b77dc59b  lea rcx, [rsp+0x30]
00007b00b77dc5a0  mov r8d, 0x00
00007b00b77dc5a6  lea r9, [r15+0x3A8]
00007b00b77dc5ad  movaps [rdi], xmm11
00007b00b77dc5b1  movaps [rsi], xmm10
00007b00b77dc5b5  movaps [rdx], xmm8
00007b00b77dc5b9  movaps [rcx], xmm1
00007b00b77dc5bc  mov rax, 0x612A23581A50
00007b00b77dc5c6  call rax
00007b00b77dc5c8  movaps xmm11, [rsp]
00007b00b77dc5cd  add rsp, 0x40
00007b00b77dc5d1  vmovaps xmm0, [rsp]
00007b00b77dc5d6  vmovaps xmm1, [rsp+0x10]
00007b00b77dc5dc  vmovaps xmm2, [rsp+0x20]
00007b00b77dc5e2  vmovaps xmm3, [rsp+0x30]
00007b00b77dc5e8  vmovaps xmm4, [rsp+0x40]
00007b00b77dc5ee  vmovaps xmm5, [rsp+0x50]
00007b00b77dc5f4  vmovaps xmm6, [rsp+0x60]
00007b00b77dc5fa  vmovaps xmm7, [rsp+0x70]
00007b00b77dc600  vmovaps xmm8, [rsp+0x80]
00007b00b77dc609  vmovaps xmm9, [rsp+0x90]
00007b00b77dc612  vmovaps xmm10, [rsp+0xA0]
00007b00b77dc61b  vmovaps xmm12, [rsp+0xB0]
00007b00b77dc624  vmovaps xmm13, [rsp+0xC0]
00007b00b77dc62d  vmovaps xmm14, [rsp+0xD0]
00007b00b77dc636  vmovaps xmm15, [rsp+0xE0]
00007b00b77dc63f  add rsp, 0xF0
00007b00b77dc646  pop r11
00007b00b77dc648  pop r10
00007b00b77dc64a  pop r9
00007b00b77dc64c  pop r8
00007b00b77dc64e  pop rsi
00007b00b77dc64f  pop rdi
00007b00b77dc650  pop rdx
00007b00b77dc651  pop rcx
00007b00b77dc652  pop rax
00007b00b77dc653  add rsp, 0x08
00007b00b77dc657  jmp 0x00007B00B77DA46D
00007b00b77dc65c  sub rsp, 0x08
00007b00b77dc660  push rax
00007b00b77dc661  push rcx
00007b00b77dc662  push rdx
00007b00b77dc663  push rdi
00007b00b77dc664  push rsi
00007b00b77dc665  push r8
00007b00b77dc667  push r9
00007b00b77dc669  push r10
00007b00b77dc66b  push r11
00007b00b77dc66d  sub rsp, 0xF0
00007b00b77dc674  vmovaps [rsp], xmm0
00007b00b77dc679  vmovaps [rsp+0x10], xmm1
00007b00b77dc67f  vmovaps [rsp+0x20], xmm2
00007b00b77dc685  vmovaps [rsp+0x30], xmm3
00007b00b77dc68b  vmovaps [rsp+0x40], xmm4
00007b00b77dc691  vmovaps [rsp+0x50], xmm5
00007b00b77dc697  vmovaps [rsp+0x60], xmm6
00007b00b77dc69d  vmovaps [rsp+0x70], xmm7
00007b00b77dc6a3  vmovaps [rsp+0x80], xmm8
00007b00b77dc6ac  vmovaps [rsp+0x90], xmm9
00007b00b77dc6b5  vmovaps [rsp+0xA0], xmm11
00007b00b77dc6be  vmovaps [rsp+0xB0], xmm12
00007b00b77dc6c7  vmovaps [rsp+0xC0], xmm13
00007b00b77dc6d0  vmovaps [rsp+0xD0], xmm14
00007b00b77dc6d9  vmovaps [rsp+0xE0], xmm15
00007b00b77dc6e2  sub rsp, 0x40
00007b00b77dc6e6  lea rdi, [rsp]
00007b00b77dc6ea  lea rsi, [rsp+0x10]
00007b00b77dc6ef  lea rdx, [rsp+0x20]
00007b00b77dc6f4  lea rcx, [rsp+0x30]
00007b00b77dc6f9  mov r8d, 0x00
00007b00b77dc6ff  lea r9, [r15+0x3A8]
00007b00b77dc706  movaps [rdi], xmm10
00007b00b77dc70a  movaps [rsi], xmm12
00007b00b77dc70e  movaps [rdx], xmm13
00007b00b77dc712  movaps [rcx], xmm1
00007b00b77dc715  mov rax, 0x612A23581A50
00007b00b77dc71f  call rax
00007b00b77dc721  movaps xmm10, [rsp]
00007b00b77dc726  add rsp, 0x40
00007b00b77dc72a  vmovaps xmm0, [rsp]
00007b00b77dc72f  vmovaps xmm1, [rsp+0x10]
00007b00b77dc735  vmovaps xmm2, [rsp+0x20]
00007b00b77dc73b  vmovaps xmm3, [rsp+0x30]
00007b00b77dc741  vmovaps xmm4, [rsp+0x40]
00007b00b77dc747  vmovaps xmm5, [rsp+0x50]
00007b00b77dc74d  vmovaps xmm6, [rsp+0x60]
00007b00b77dc753  vmovaps xmm7, [rsp+0x70]
00007b00b77dc759  vmovaps xmm8, [rsp+0x80]
00007b00b77dc762  vmovaps xmm9, [rsp+0x90]
00007b00b77dc76b  vmovaps xmm11, [rsp+0xA0]
00007b00b77dc774  vmovaps xmm12, [rsp+0xB0]
00007b00b77dc77d  vmovaps xmm13, [rsp+0xC0]
00007b00b77dc786  vmovaps xmm14, [rsp+0xD0]
00007b00b77dc78f  vmovaps xmm15, [rsp+0xE0]
00007b00b77dc798  add rsp, 0xF0
00007b00b77dc79f  pop r11
00007b00b77dc7a1  pop r10
00007b00b77dc7a3  pop r9
00007b00b77dc7a5  pop r8
00007b00b77dc7a7  pop rsi
00007b00b77dc7a8  pop rdi
00007b00b77dc7a9  pop rdx
00007b00b77dc7aa  pop rcx
00007b00b77dc7ab  pop rax
00007b00b77dc7ac  add rsp, 0x08
00007b00b77dc7b0  jmp 0x00007B00B77DA493
00007b00b77dc7b5  call 0x00007B00B75FF430
00007b00b77dc7ba  jmp 0x00007B00B77DA49D
00007b00b77dc7bf  call 0x00007B00B760C260
00007b00b77dc7c4  jmp 0x00007B00B77DA4A7
00007b00b77dc7c9  sub rsp, 0x08
00007b00b77dc7cd  push rax
00007b00b77dc7ce  push rcx
00007b00b77dc7cf  push rdx
00007b00b77dc7d0  push rdi
00007b00b77dc7d1  push rsi
00007b00b77dc7d2  push r8
00007b00b77dc7d4  push r9
00007b00b77dc7d6  push r10
00007b00b77dc7d8  push r11
00007b00b77dc7da  sub rsp, 0xF0
00007b00b77dc7e1  vmovaps [rsp], xmm0
00007b00b77dc7e6  vmovaps [rsp+0x10], xmm1
00007b00b77dc7ec  vmovaps [rsp+0x20], xmm2
00007b00b77dc7f2  vmovaps [rsp+0x30], xmm3
00007b00b77dc7f8  vmovaps [rsp+0x40], xmm4
00007b00b77dc7fe  vmovaps [rsp+0x50], xmm5
00007b00b77dc804  vmovaps [rsp+0x60], xmm6
00007b00b77dc80a  vmovaps [rsp+0x70], xmm7
00007b00b77dc810  vmovaps [rsp+0x80], xmm9
00007b00b77dc819  vmovaps [rsp+0x90], xmm10
00007b00b77dc822  vmovaps [rsp+0xA0], xmm11
00007b00b77dc82b  vmovaps [rsp+0xB0], xmm12
00007b00b77dc834  vmovaps [rsp+0xC0], xmm13
00007b00b77dc83d  vmovaps [rsp+0xD0], xmm14
00007b00b77dc846  vmovaps [rsp+0xE0], xmm15
00007b00b77dc84f  sub rsp, 0x40
00007b00b77dc853  lea rdi, [rsp]
00007b00b77dc857  lea rsi, [rsp+0x10]
00007b00b77dc85c  lea rdx, [rsp+0x20]
00007b00b77dc861  lea rcx, [rsp+0x30]
00007b00b77dc866  mov r8d, 0x00
00007b00b77dc86c  lea r9, [r15+0x3A8]
00007b00b77dc873  movaps [rdi], xmm8
00007b00b77dc877  movaps [rsi], xmm7
00007b00b77dc87a  movaps [rdx], xmm4
00007b00b77dc87d  movaps [rcx], xmm12
00007b00b77dc881  mov rax, 0x612A23581A50
00007b00b77dc88b  call rax
00007b00b77dc88d  movaps xmm8, [rsp]
00007b00b77dc892  add rsp, 0x40
00007b00b77dc896  vmovaps xmm0, [rsp]
00007b00b77dc89b  vmovaps xmm1, [rsp+0x10]
00007b00b77dc8a1  vmovaps xmm2, [rsp+0x20]
00007b00b77dc8a7  vmovaps xmm3, [rsp+0x30]
00007b00b77dc8ad  vmovaps xmm4, [rsp+0x40]
00007b00b77dc8b3  vmovaps xmm5, [rsp+0x50]
00007b00b77dc8b9  vmovaps xmm6, [rsp+0x60]
00007b00b77dc8bf  vmovaps xmm7, [rsp+0x70]
00007b00b77dc8c5  vmovaps xmm9, [rsp+0x80]
00007b00b77dc8ce  vmovaps xmm10, [rsp+0x90]
00007b00b77dc8d7  vmovaps xmm11, [rsp+0xA0]
00007b00b77dc8e0  vmovaps xmm12, [rsp+0xB0]
00007b00b77dc8e9  vmovaps xmm13, [rsp+0xC0]
00007b00b77dc8f2  vmovaps xmm14, [rsp+0xD0]
00007b00b77dc8fb  vmovaps xmm15, [rsp+0xE0]
00007b00b77dc904  add rsp, 0xF0
00007b00b77dc90b  pop r11
00007b00b77dc90d  pop r10
00007b00b77dc90f  pop r9
00007b00b77dc911  pop r8
00007b00b77dc913  pop rsi
00007b00b77dc914  pop rdi
00007b00b77dc915  pop rdx
00007b00b77dc916  pop rcx
00007b00b77dc917  pop rax
00007b00b77dc918  add rsp, 0x08
00007b00b77dc91c  jmp 0x00007B00B77DA4D0
00007b00b77dc921  sub rsp, 0x08
00007b00b77dc925  push rax
00007b00b77dc926  push rcx
00007b00b77dc927  push rdx
00007b00b77dc928  push rdi
00007b00b77dc929  push rsi
00007b00b77dc92a  push r8
00007b00b77dc92c  push r9
00007b00b77dc92e  push r10
00007b00b77dc930  push r11
00007b00b77dc932  sub rsp, 0xF0
00007b00b77dc939  vmovaps [rsp], xmm0
00007b00b77dc93e  vmovaps [rsp+0x10], xmm1
00007b00b77dc944  vmovaps [rsp+0x20], xmm2
00007b00b77dc94a  vmovaps [rsp+0x30], xmm3
00007b00b77dc950  vmovaps [rsp+0x40], xmm4
00007b00b77dc956  vmovaps [rsp+0x50], xmm5
00007b00b77dc95c  vmovaps [rsp+0x60], xmm6
00007b00b77dc962  vmovaps [rsp+0x70], xmm8
00007b00b77dc968  vmovaps [rsp+0x80], xmm9
00007b00b77dc971  vmovaps [rsp+0x90], xmm10
00007b00b77dc97a  vmovaps [rsp+0xA0], xmm11
00007b00b77dc983  vmovaps [rsp+0xB0], xmm12
00007b00b77dc98c  vmovaps [rsp+0xC0], xmm13
00007b00b77dc995  vmovaps [rsp+0xD0], xmm14
00007b00b77dc99e  vmovaps [rsp+0xE0], xmm15
00007b00b77dc9a7  sub rsp, 0x40
00007b00b77dc9ab  lea rdi, [rsp]
00007b00b77dc9af  lea rsi, [rsp+0x10]
00007b00b77dc9b4  lea rdx, [rsp+0x20]
00007b00b77dc9b9  lea rcx, [rsp+0x30]
00007b00b77dc9be  mov r8d, 0x00
00007b00b77dc9c4  lea r9, [r15+0x3A8]
00007b00b77dc9cb  movaps [rdi], xmm7
00007b00b77dc9ce  movaps [rsi], xmm9
00007b00b77dc9d2  movaps [rdx], xmm14
00007b00b77dc9d6  movaps [rcx], xmm12
00007b00b77dc9da  mov rax, 0x612A23581A50
00007b00b77dc9e4  call rax
00007b00b77dc9e6  movaps xmm7, [rsp]
00007b00b77dc9ea  add rsp, 0x40
00007b00b77dc9ee  vmovaps xmm0, [rsp]
00007b00b77dc9f3  vmovaps xmm1, [rsp+0x10]
00007b00b77dc9f9  vmovaps xmm2, [rsp+0x20]
00007b00b77dc9ff  vmovaps xmm3, [rsp+0x30]
00007b00b77dca05  vmovaps xmm4, [rsp+0x40]
00007b00b77dca0b  vmovaps xmm5, [rsp+0x50]
00007b00b77dca11  vmovaps xmm6, [rsp+0x60]
00007b00b77dca17  vmovaps xmm8, [rsp+0x70]
00007b00b77dca1d  vmovaps xmm9, [rsp+0x80]
00007b00b77dca26  vmovaps xmm10, [rsp+0x90]
00007b00b77dca2f  vmovaps xmm11, [rsp+0xA0]
00007b00b77dca38  vmovaps xmm12, [rsp+0xB0]
00007b00b77dca41  vmovaps xmm13, [rsp+0xC0]
00007b00b77dca4a  vmovaps xmm14, [rsp+0xD0]
00007b00b77dca53  vmovaps xmm15, [rsp+0xE0]
00007b00b77dca5c  add rsp, 0xF0
00007b00b77dca63  pop r11
00007b00b77dca65  pop r10
00007b00b77dca67  pop r9
00007b00b77dca69  pop r8
00007b00b77dca6b  pop rsi
00007b00b77dca6c  pop rdi
00007b00b77dca6d  pop rdx
00007b00b77dca6e  pop rcx
00007b00b77dca6f  pop rax
00007b00b77dca70  add rsp, 0x08
00007b00b77dca74  jmp 0x00007B00B77DA4F8
00007b00b77dca79  sub rsp, 0x08
00007b00b77dca7d  push rax
00007b00b77dca7e  push rcx
00007b00b77dca7f  push rdx
00007b00b77dca80  push rdi
00007b00b77dca81  push rsi
00007b00b77dca82  push r8
00007b00b77dca84  push r9
00007b00b77dca86  push r10
00007b00b77dca88  push r11
00007b00b77dca8a  sub rsp, 0xF0
00007b00b77dca91  vmovaps [rsp], xmm0
00007b00b77dca96  vmovaps [rsp+0x10], xmm1
00007b00b77dca9c  vmovaps [rsp+0x20], xmm2
00007b00b77dcaa2  vmovaps [rsp+0x30], xmm3
00007b00b77dcaa8  vmovaps [rsp+0x40], xmm4
00007b00b77dcaae  vmovaps [rsp+0x50], xmm5
00007b00b77dcab4  vmovaps [rsp+0x60], xmm6
00007b00b77dcaba  vmovaps [rsp+0x70], xmm7
00007b00b77dcac0  vmovaps [rsp+0x80], xmm8
00007b00b77dcac9  vmovaps [rsp+0x90], xmm9
00007b00b77dcad2  vmovaps [rsp+0xA0], xmm10
00007b00b77dcadb  vmovaps [rsp+0xB0], xmm11
00007b00b77dcae4  vmovaps [rsp+0xC0], xmm13
00007b00b77dcaed  vmovaps [rsp+0xD0], xmm14
00007b00b77dcaf6  vmovaps [rsp+0xE0], xmm15
00007b00b77dcaff  sub rsp, 0x40
00007b00b77dcb03  lea rdi, [rsp]
00007b00b77dcb07  lea rsi, [rsp+0x10]
00007b00b77dcb0c  lea rdx, [rsp+0x20]
00007b00b77dcb11  lea rcx, [rsp+0x30]
00007b00b77dcb16  mov r8d, 0x00
00007b00b77dcb1c  lea r9, [r15+0x3A8]
00007b00b77dcb23  movaps [rdi], xmm12
00007b00b77dcb27  movaps [rsi], xmm11
00007b00b77dcb2b  movaps [rdx], xmm15
00007b00b77dcb2f  movaps [rcx], xmm14
00007b00b77dcb33  mov rax, 0x612A23581A50
00007b00b77dcb3d  call rax
00007b00b77dcb3f  movaps xmm12, [rsp]
00007b00b77dcb44  add rsp, 0x40
00007b00b77dcb48  vmovaps xmm0, [rsp]
00007b00b77dcb4d  vmovaps xmm1, [rsp+0x10]
00007b00b77dcb53  vmovaps xmm2, [rsp+0x20]
00007b00b77dcb59  vmovaps xmm3, [rsp+0x30]
00007b00b77dcb5f  vmovaps xmm4, [rsp+0x40]
00007b00b77dcb65  vmovaps xmm5, [rsp+0x50]
00007b00b77dcb6b  vmovaps xmm6, [rsp+0x60]
00007b00b77dcb71  vmovaps xmm7, [rsp+0x70]
00007b00b77dcb77  vmovaps xmm8, [rsp+0x80]
00007b00b77dcb80  vmovaps xmm9, [rsp+0x90]
00007b00b77dcb89  vmovaps xmm10, [rsp+0xA0]
00007b00b77dcb92  vmovaps xmm11, [rsp+0xB0]
00007b00b77dcb9b  vmovaps xmm13, [rsp+0xC0]
00007b00b77dcba4  vmovaps xmm14, [rsp+0xD0]
00007b00b77dcbad  vmovaps xmm15, [rsp+0xE0]
00007b00b77dcbb6  add rsp, 0xF0
00007b00b77dcbbd  pop r11
00007b00b77dcbbf  pop r10
00007b00b77dcbc1  pop r9
00007b00b77dcbc3  pop r8
00007b00b77dcbc5  pop rsi
00007b00b77dcbc6  pop rdi
00007b00b77dcbc7  pop rdx
00007b00b77dcbc8  pop rcx
00007b00b77dcbc9  pop rax
00007b00b77dcbca  add rsp, 0x08
00007b00b77dcbce  jmp 0x00007B00B77DA521
00007b00b77dcbd3  sub rsp, 0x08
00007b00b77dcbd7  push rax
00007b00b77dcbd8  push rcx
00007b00b77dcbd9  push rdx
00007b00b77dcbda  push rdi
00007b00b77dcbdb  push rsi
00007b00b77dcbdc  push r8
00007b00b77dcbde  push r9
00007b00b77dcbe0  push r10
00007b00b77dcbe2  push r11
00007b00b77dcbe4  sub rsp, 0xF0
00007b00b77dcbeb  vmovaps [rsp], xmm0
00007b00b77dcbf0  vmovaps [rsp+0x10], xmm1
00007b00b77dcbf6  vmovaps [rsp+0x20], xmm2
00007b00b77dcbfc  vmovaps [rsp+0x30], xmm3
00007b00b77dcc02  vmovaps [rsp+0x40], xmm4
00007b00b77dcc08  vmovaps [rsp+0x50], xmm5
00007b00b77dcc0e  vmovaps [rsp+0x60], xmm6
00007b00b77dcc14  vmovaps [rsp+0x70], xmm7
00007b00b77dcc1a  vmovaps [rsp+0x80], xmm8
00007b00b77dcc23  vmovaps [rsp+0x90], xmm9
00007b00b77dcc2c  vmovaps [rsp+0xA0], xmm10
00007b00b77dcc35  vmovaps [rsp+0xB0], xmm12
00007b00b77dcc3e  vmovaps [rsp+0xC0], xmm13
00007b00b77dcc47  vmovaps [rsp+0xD0], xmm14
00007b00b77dcc50  vmovaps [rsp+0xE0], xmm15
00007b00b77dcc59  sub rsp, 0x40
00007b00b77dcc5d  lea rdi, [rsp]
00007b00b77dcc61  lea rsi, [rsp+0x10]
00007b00b77dcc66  lea rdx, [rsp+0x20]
00007b00b77dcc6b  lea rcx, [rsp+0x30]
00007b00b77dcc70  mov r8d, 0x00
00007b00b77dcc76  lea r9, [r15+0x3A8]
00007b00b77dcc7d  movaps [rdi], xmm11
00007b00b77dcc81  movaps [rsi], xmm10
00007b00b77dcc85  movaps [rdx], xmm13
00007b00b77dcc89  movaps [rcx], xmm15
00007b00b77dcc8d  mov rax, 0x612A23581A50
00007b00b77dcc97  call rax
00007b00b77dcc99  movaps xmm11, [rsp]
00007b00b77dcc9e  add rsp, 0x40
00007b00b77dcca2  vmovaps xmm0, [rsp]
00007b00b77dcca7  vmovaps xmm1, [rsp+0x10]
00007b00b77dccad  vmovaps xmm2, [rsp+0x20]
00007b00b77dccb3  vmovaps xmm3, [rsp+0x30]
00007b00b77dccb9  vmovaps xmm4, [rsp+0x40]
00007b00b77dccbf  vmovaps xmm5, [rsp+0x50]
00007b00b77dccc5  vmovaps xmm6, [rsp+0x60]
00007b00b77dcccb  vmovaps xmm7, [rsp+0x70]
00007b00b77dccd1  vmovaps xmm8, [rsp+0x80]
00007b00b77dccda  vmovaps xmm9, [rsp+0x90]
00007b00b77dcce3  vmovaps xmm10, [rsp+0xA0]
00007b00b77dccec  vmovaps xmm12, [rsp+0xB0]
00007b00b77dccf5  vmovaps xmm13, [rsp+0xC0]
00007b00b77dccfe  vmovaps xmm14, [rsp+0xD0]
00007b00b77dcd07  vmovaps xmm15, [rsp+0xE0]
00007b00b77dcd10  add rsp, 0xF0
00007b00b77dcd17  pop r11
00007b00b77dcd19  pop r10
00007b00b77dcd1b  pop r9
00007b00b77dcd1d  pop r8
00007b00b77dcd1f  pop rsi
00007b00b77dcd20  pop rdi
00007b00b77dcd21  pop rdx
00007b00b77dcd22  pop rcx
00007b00b77dcd23  pop rax
00007b00b77dcd24  add rsp, 0x08
00007b00b77dcd28  jmp 0x00007B00B77DA54A
00007b00b77dcd2d  call 0x00007B00B760E760
00007b00b77dcd32  jmp 0x00007B00B77DA557
00007b00b77dcd37  call 0x00007B00B760D4E0
00007b00b77dcd3c  jmp 0x00007B00B77DA564
00007b00b77dcd41  sub rsp, 0x08
00007b00b77dcd45  push rax
00007b00b77dcd46  push rcx
00007b00b77dcd47  push rdx
00007b00b77dcd48  push rdi
00007b00b77dcd49  push rsi
00007b00b77dcd4a  push r8
00007b00b77dcd4c  push r9
00007b00b77dcd4e  push r10
00007b00b77dcd50  push r11
00007b00b77dcd52  sub rsp, 0xF0
00007b00b77dcd59  vmovaps [rsp], xmm0
00007b00b77dcd5e  vmovaps [rsp+0x10], xmm1
00007b00b77dcd64  vmovaps [rsp+0x20], xmm2
00007b00b77dcd6a  vmovaps [rsp+0x30], xmm3
00007b00b77dcd70  vmovaps [rsp+0x40], xmm4
00007b00b77dcd76  vmovaps [rsp+0x50], xmm5
00007b00b77dcd7c  vmovaps [rsp+0x60], xmm6
00007b00b77dcd82  vmovaps [rsp+0x70], xmm7
00007b00b77dcd88  vmovaps [rsp+0x80], xmm8
00007b00b77dcd91  vmovaps [rsp+0x90], xmm9
00007b00b77dcd9a  vmovaps [rsp+0xA0], xmm11
00007b00b77dcda3  vmovaps [rsp+0xB0], xmm12
00007b00b77dcdac  vmovaps [rsp+0xC0], xmm13
00007b00b77dcdb5  vmovaps [rsp+0xD0], xmm14
00007b00b77dcdbe  vmovaps [rsp+0xE0], xmm15
00007b00b77dcdc7  sub rsp, 0x40
00007b00b77dcdcb  lea rdi, [rsp]
00007b00b77dcdcf  lea rsi, [rsp+0x10]
00007b00b77dcdd4  lea rdx, [rsp+0x20]
00007b00b77dcdd9  lea rcx, [rsp+0x30]
00007b00b77dcdde  mov r8d, 0x00
00007b00b77dcde4  lea r9, [r15+0x3A8]
00007b00b77dcdeb  movaps [rdi], xmm10
00007b00b77dcdef  movaps [rsi], xmm8
00007b00b77dcdf3  movaps [rdx], xmm1
00007b00b77dcdf6  movaps [rcx], xmm13
00007b00b77dcdfa  mov rax, 0x612A23581A50
00007b00b77dce04  call rax
00007b00b77dce06  movaps xmm10, [rsp]
00007b00b77dce0b  add rsp, 0x40
00007b00b77dce0f  vmovaps xmm0, [rsp]
00007b00b77dce14  vmovaps xmm1, [rsp+0x10]
00007b00b77dce1a  vmovaps xmm2, [rsp+0x20]
00007b00b77dce20  vmovaps xmm3, [rsp+0x30]
00007b00b77dce26  vmovaps xmm4, [rsp+0x40]
00007b00b77dce2c  vmovaps xmm5, [rsp+0x50]
00007b00b77dce32  vmovaps xmm6, [rsp+0x60]
00007b00b77dce38  vmovaps xmm7, [rsp+0x70]
00007b00b77dce3e  vmovaps xmm8, [rsp+0x80]
00007b00b77dce47  vmovaps xmm9, [rsp+0x90]
00007b00b77dce50  vmovaps xmm11, [rsp+0xA0]
00007b00b77dce59  vmovaps xmm12, [rsp+0xB0]
00007b00b77dce62  vmovaps xmm13, [rsp+0xC0]
00007b00b77dce6b  vmovaps xmm14, [rsp+0xD0]
00007b00b77dce74  vmovaps xmm15, [rsp+0xE0]
00007b00b77dce7d  add rsp, 0xF0
00007b00b77dce84  pop r11
00007b00b77dce86  pop r10
00007b00b77dce88  pop r9
00007b00b77dce8a  pop r8
00007b00b77dce8c  pop rsi
00007b00b77dce8d  pop rdi
00007b00b77dce8e  pop rdx
00007b00b77dce8f  pop rcx
00007b00b77dce90  pop rax
00007b00b77dce91  add rsp, 0x08
00007b00b77dce95  jmp 0x00007B00B77DA59A
00007b00b77dce9a  call 0x00007B00B75FF430
00007b00b77dce9f  jmp 0x00007B00B77DA5AC
00007b00b77dcea4  sub rsp, 0x08
00007b00b77dcea8  push rax
00007b00b77dcea9  push rcx
00007b00b77dceaa  push rdx
00007b00b77dceab  push rdi
00007b00b77dceac  push rsi
00007b00b77dcead  push r8
00007b00b77dceaf  push r9
00007b00b77dceb1  push r10
00007b00b77dceb3  push r11
00007b00b77dceb5  sub rsp, 0xF0
00007b00b77dcebc  vmovaps [rsp], xmm0
00007b00b77dcec1  vmovaps [rsp+0x10], xmm1
00007b00b77dcec7  vmovaps [rsp+0x20], xmm2
00007b00b77dcecd  vmovaps [rsp+0x30], xmm3
00007b00b77dced3  vmovaps [rsp+0x40], xmm4
00007b00b77dced9  vmovaps [rsp+0x50], xmm5
00007b00b77dcedf  vmovaps [rsp+0x60], xmm6
00007b00b77dcee5  vmovaps [rsp+0x70], xmm7
00007b00b77dceeb  vmovaps [rsp+0x80], xmm8
00007b00b77dcef4  vmovaps [rsp+0x90], xmm10
00007b00b77dcefd  vmovaps [rsp+0xA0], xmm11
00007b00b77dcf06  vmovaps [rsp+0xB0], xmm12
00007b00b77dcf0f  vmovaps [rsp+0xC0], xmm13
00007b00b77dcf18  vmovaps [rsp+0xD0], xmm14
00007b00b77dcf21  vmovaps [rsp+0xE0], xmm15
00007b00b77dcf2a  sub rsp, 0x40
00007b00b77dcf2e  lea rdi, [rsp]
00007b00b77dcf32  lea rsi, [rsp+0x10]
00007b00b77dcf37  lea rdx, [rsp+0x20]
00007b00b77dcf3c  lea rcx, [rsp+0x30]
00007b00b77dcf41  mov r8d, 0x00
00007b00b77dcf47  lea r9, [r15+0x3A8]
00007b00b77dcf4e  movaps [rdi], xmm9
00007b00b77dcf52  movaps [rsi], xmm7
00007b00b77dcf55  movaps [rdx], xmm14
00007b00b77dcf59  movaps [rcx], xmm13
00007b00b77dcf5d  mov rax, 0x612A23581A50
00007b00b77dcf67  call rax
00007b00b77dcf69  movaps xmm9, [rsp]
00007b00b77dcf6e  add rsp, 0x40
00007b00b77dcf72  vmovaps xmm0, [rsp]
00007b00b77dcf77  vmovaps xmm1, [rsp+0x10]
00007b00b77dcf7d  vmovaps xmm2, [rsp+0x20]
00007b00b77dcf83  vmovaps xmm3, [rsp+0x30]
00007b00b77dcf89  vmovaps xmm4, [rsp+0x40]
00007b00b77dcf8f  vmovaps xmm5, [rsp+0x50]
00007b00b77dcf95  vmovaps xmm6, [rsp+0x60]
00007b00b77dcf9b  vmovaps xmm7, [rsp+0x70]
00007b00b77dcfa1  vmovaps xmm8, [rsp+0x80]
00007b00b77dcfaa  vmovaps xmm10, [rsp+0x90]
00007b00b77dcfb3  vmovaps xmm11, [rsp+0xA0]
00007b00b77dcfbc  vmovaps xmm12, [rsp+0xB0]
00007b00b77dcfc5  vmovaps xmm13, [rsp+0xC0]
00007b00b77dcfce  vmovaps xmm14, [rsp+0xD0]
00007b00b77dcfd7  vmovaps xmm15, [rsp+0xE0]
00007b00b77dcfe0  add rsp, 0xF0
00007b00b77dcfe7  pop r11
00007b00b77dcfe9  pop r10
00007b00b77dcfeb  pop r9
00007b00b77dcfed  pop r8
00007b00b77dcfef  pop rsi
00007b00b77dcff0  pop rdi
00007b00b77dcff1  pop rdx
00007b00b77dcff2  pop rcx
00007b00b77dcff3  pop rax
00007b00b77dcff4  add rsp, 0x08
00007b00b77dcff8  jmp 0x00007B00B77DA5DA
00007b00b77dcffd  sub rsp, 0x08
00007b00b77dd001  push rax
00007b00b77dd002  push rcx
00007b00b77dd003  push rdx
00007b00b77dd004  push rdi
00007b00b77dd005  push rsi
00007b00b77dd006  push r8
00007b00b77dd008  push r9
00007b00b77dd00a  push r10
00007b00b77dd00c  push r11
00007b00b77dd00e  sub rsp, 0xF0
00007b00b77dd015  vmovaps [rsp], xmm0
00007b00b77dd01a  vmovaps [rsp+0x10], xmm1
00007b00b77dd020  vmovaps [rsp+0x20], xmm2
00007b00b77dd026  vmovaps [rsp+0x30], xmm3
00007b00b77dd02c  vmovaps [rsp+0x40], xmm4
00007b00b77dd032  vmovaps [rsp+0x50], xmm5
00007b00b77dd038  vmovaps [rsp+0x60], xmm6
00007b00b77dd03e  vmovaps [rsp+0x70], xmm7
00007b00b77dd044  vmovaps [rsp+0x80], xmm8
00007b00b77dd04d  vmovaps [rsp+0x90], xmm9
00007b00b77dd056  vmovaps [rsp+0xA0], xmm10
00007b00b77dd05f  vmovaps [rsp+0xB0], xmm11
00007b00b77dd068  vmovaps [rsp+0xC0], xmm12
00007b00b77dd071  vmovaps [rsp+0xD0], xmm14
00007b00b77dd07a  vmovaps [rsp+0xE0], xmm15
00007b00b77dd083  sub rsp, 0x40
00007b00b77dd087  lea rdi, [rsp]
00007b00b77dd08b  lea rsi, [rsp+0x10]
00007b00b77dd090  lea rdx, [rsp+0x20]
00007b00b77dd095  lea rcx, [rsp+0x30]
00007b00b77dd09a  mov r8d, 0x00
00007b00b77dd0a0  lea r9, [r15+0x3A8]
00007b00b77dd0a7  movaps [rdi], xmm13
00007b00b77dd0ab  movaps [rsi], xmm12
00007b00b77dd0af  movaps [rdx], xmm15
00007b00b77dd0b3  movaps [rcx], xmm14
00007b00b77dd0b7  mov rax, 0x612A23581A50
00007b00b77dd0c1  call rax
00007b00b77dd0c3  movaps xmm13, [rsp]
00007b00b77dd0c8  add rsp, 0x40
00007b00b77dd0cc  vmovaps xmm0, [rsp]
00007b00b77dd0d1  vmovaps xmm1, [rsp+0x10]
00007b00b77dd0d7  vmovaps xmm2, [rsp+0x20]
00007b00b77dd0dd  vmovaps xmm3, [rsp+0x30]
00007b00b77dd0e3  vmovaps xmm4, [rsp+0x40]
00007b00b77dd0e9  vmovaps xmm5, [rsp+0x50]
00007b00b77dd0ef  vmovaps xmm6, [rsp+0x60]
00007b00b77dd0f5  vmovaps xmm7, [rsp+0x70]
00007b00b77dd0fb  vmovaps xmm8, [rsp+0x80]
00007b00b77dd104  vmovaps xmm9, [rsp+0x90]
00007b00b77dd10d  vmovaps xmm10, [rsp+0xA0]
00007b00b77dd116  vmovaps xmm11, [rsp+0xB0]
00007b00b77dd11f  vmovaps xmm12, [rsp+0xC0]
00007b00b77dd128  vmovaps xmm14, [rsp+0xD0]
00007b00b77dd131  vmovaps xmm15, [rsp+0xE0]
00007b00b77dd13a  add rsp, 0xF0
00007b00b77dd141  pop r11
00007b00b77dd143  pop r10
00007b00b77dd145  pop r9
00007b00b77dd147  pop r8
00007b00b77dd149  pop rsi
00007b00b77dd14a  pop rdi
00007b00b77dd14b  pop rdx
00007b00b77dd14c  pop rcx
00007b00b77dd14d  pop rax
00007b00b77dd14e  add rsp, 0x08
00007b00b77dd152  jmp 0x00007B00B77DA608
00007b00b77dd157  sub rsp, 0x08
00007b00b77dd15b  push rax
00007b00b77dd15c  push rcx
00007b00b77dd15d  push rdx
00007b00b77dd15e  push rdi
00007b00b77dd15f  push rsi
00007b00b77dd160  push r8
00007b00b77dd162  push r9
00007b00b77dd164  push r10
00007b00b77dd166  push r11
00007b00b77dd168  sub rsp, 0xF0
00007b00b77dd16f  vmovaps [rsp], xmm0
00007b00b77dd174  vmovaps [rsp+0x10], xmm1
00007b00b77dd17a  vmovaps [rsp+0x20], xmm2
00007b00b77dd180  vmovaps [rsp+0x30], xmm3
00007b00b77dd186  vmovaps [rsp+0x40], xmm4
00007b00b77dd18c  vmovaps [rsp+0x50], xmm5
00007b00b77dd192  vmovaps [rsp+0x60], xmm6
00007b00b77dd198  vmovaps [rsp+0x70], xmm7
00007b00b77dd19e  vmovaps [rsp+0x80], xmm8
00007b00b77dd1a7  vmovaps [rsp+0x90], xmm9
00007b00b77dd1b0  vmovaps [rsp+0xA0], xmm10
00007b00b77dd1b9  vmovaps [rsp+0xB0], xmm11
00007b00b77dd1c2  vmovaps [rsp+0xC0], xmm12
00007b00b77dd1cb  vmovaps [rsp+0xD0], xmm13
00007b00b77dd1d4  vmovaps [rsp+0xE0], xmm15
00007b00b77dd1dd  sub rsp, 0x40
00007b00b77dd1e1  lea rdi, [rsp]
00007b00b77dd1e5  lea rsi, [rsp+0x10]
00007b00b77dd1ea  lea rdx, [rsp+0x20]
00007b00b77dd1ef  lea rcx, [rsp+0x30]
00007b00b77dd1f4  mov r8d, 0x00
00007b00b77dd1fa  lea r9, [r15+0x3A8]
00007b00b77dd201  movaps [rdi], xmm14
00007b00b77dd205  movaps [rsi], xmm11
00007b00b77dd209  movaps [rdx], xmm1
00007b00b77dd20c  movaps [rcx], xmm15
00007b00b77dd210  mov rax, 0x612A23581A50
00007b00b77dd21a  call rax
00007b00b77dd21c  movaps xmm14, [rsp]
00007b00b77dd221  add rsp, 0x40
00007b00b77dd225  vmovaps xmm0, [rsp]
00007b00b77dd22a  vmovaps xmm1, [rsp+0x10]
00007b00b77dd230  vmovaps xmm2, [rsp+0x20]
00007b00b77dd236  vmovaps xmm3, [rsp+0x30]
00007b00b77dd23c  vmovaps xmm4, [rsp+0x40]
00007b00b77dd242  vmovaps xmm5, [rsp+0x50]
00007b00b77dd248  vmovaps xmm6, [rsp+0x60]
00007b00b77dd24e  vmovaps xmm7, [rsp+0x70]
00007b00b77dd254  vmovaps xmm8, [rsp+0x80]
00007b00b77dd25d  vmovaps xmm9, [rsp+0x90]
00007b00b77dd266  vmovaps xmm10, [rsp+0xA0]
00007b00b77dd26f  vmovaps xmm11, [rsp+0xB0]
00007b00b77dd278  vmovaps xmm12, [rsp+0xC0]
00007b00b77dd281  vmovaps xmm13, [rsp+0xD0]
00007b00b77dd28a  vmovaps xmm15, [rsp+0xE0]
00007b00b77dd293  add rsp, 0xF0
00007b00b77dd29a  pop r11
00007b00b77dd29c  pop r10
00007b00b77dd29e  pop r9
00007b00b77dd2a0  pop r8
00007b00b77dd2a2  pop rsi
00007b00b77dd2a3  pop rdi
00007b00b77dd2a4  pop rdx
00007b00b77dd2a5  pop rcx
00007b00b77dd2a6  pop rax
00007b00b77dd2a7  add rsp, 0x08
00007b00b77dd2ab  jmp 0x00007B00B77DA636
00007b00b77dd2b0  call 0x00007B00B76079B0
00007b00b77dd2b5  jmp 0x00007B00B77DA64C
00007b00b77dd2ba  call 0x00007B00B76E3440
00007b00b77dd2bf  jmp 0x00007B00B77DA656
00007b00b77dd2c4  call 0x00007B00B76DFCE0
00007b00b77dd2c9  jmp 0x00007B00B77DA660
00007b00b77dd2ce  call 0x00007B00B76E46C0
00007b00b77dd2d3  jmp 0x00007B00B77DA66A
00007b00b77dd2d8  int3
00007b00b77dd2d9  nop [rax], eax
00007b00b77dd2e0  mov qword ptr [r15+0x40], 0x430000
00007b00b77dd2e8  mov eax, 0x430C50
00007b00b77dd2ed  mov r14, [r13+rax*1]
00007b00b77dd2f2  movq xmm1, r14
00007b00b77dd2f7  mov rax, [r15+0x50]
00007b00b77dd2fb  movups xmm15, [r13+rax*1]
00007b00b77dd301  movaps [r15+0x120], xmm15
00007b00b77dd309  mov qword ptr [r15+0x48], 0x10
00007b00b77dd311  xor eax, eax
00007b00b77dd313  mov r14d, 0x10
00007b00b77dd319  mov r12d, 0x200
00007b00b77dd31f  cmp r14, r12
00007b00b77dd322  cmc
00007b00b77dd323  lahf
00007b00b77dd324  seto al
00007b00b77dd327  mov [r15+0x108], eax
00007b00b77dd32e  pextrq rax, xmm15, 0x01
00007b00b77dd335  movq xmm14, rax
00007b00b77dd33a  movaps [r15+0x130], xmm14
00007b00b77dd342  movq rax, xmm1
00007b00b77dd347  movq r14, xmm15
00007b00b77dd34c  vmovq xmm1, rax
00007b00b77dd351  vmovq xmm15, r14
00007b00b77dd356  movaps xmm13, xmm1
00007b00b77dd35a  addsd xmm13, xmm15
00007b00b77dd35f  ucomisd xmm13, xmm13
00007b00b77dd364  jp 0x00007B00B77DD423
00007b00b77dd36a  movq xmm13, xmm13
00007b00b77dd36f  movq rax, xmm13
00007b00b77dd374  movq r14, xmm14
00007b00b77dd379  vmovq xmm1, rax
00007b00b77dd37e  vmovq xmm15, r14
00007b00b77dd383  movaps xmm14, xmm1
00007b00b77dd387  addsd xmm14, xmm15
00007b00b77dd38c  ucomisd xmm14, xmm14
00007b00b77dd391  jp 0x00007B00B77DD46B
00007b00b77dd397  movq xmm14, xmm14
00007b00b77dd39c  movaps [r15+0x110], xmm14
00007b00b77dd3a4  mov eax, [r15+0x108]
00007b00b77dd3ab  sahf
00007b00b77dd3ac  jnz 0x00007B00B77DD3DE
00007b00b77dd3ae  cmp dword ptr [r15+0x318], 0x00
00007b00b77dd3b6  jz 0x00007B00B77DD680
00007b00b77dd3bc  nop [rax+rax*1], ax
00007b00b77dd3c5  nop [rax+rax*1], eax
00007b00b77dd3cd  mov eax, 0x410698
00007b00b77dd3d2  mov [r15+0x100], rax
00007b00b77dd3d9  jmp 0x00007B00B75FE110
00007b00b77dd3de  cmp dword ptr [r15+0x318], 0x00
00007b00b77dd3e6  jz 0x00007B00B77DD4C0
00007b00b77dd3ec  nop [rax+rax*1], ax
00007b00b77dd3f5  nop [rax+rax*1], eax
00007b00b77dd3fd  mov eax, 0x41067C
00007b00b77dd402  mov [r15+0x100], rax
00007b00b77dd409  jmp 0x00007B00B75FE110
00007b00b77dd40e  int3
00007b00b77dd40f  call 0x00007B00B760DC20
00007b00b77dd414  jmp 0x00007B00B77DD2F2
00007b00b77dd419  call 0x00007B00B760E760
00007b00b77dd41e  jmp 0x00007B00B77DD301
00007b00b77dd423  ucomisd xmm1, xmm15
00007b00b77dd428  jp 0x00007B00B77DD437
00007b00b77dd42a  movaps xmm13, [0x00007B00B73FE060]
00007b00b77dd432  jmp 0x00007B00B77DD36A
00007b00b77dd437  vxorps xmm0, xmm1, xmm15
00007b00b77dd43c  pextrw eax, xmm0, 0x03
00007b00b77dd441  and eax, 0x7FF8
00007b00b77dd446  cmp eax, 0x08
00007b00b77dd449  jnz 0x00007B00B77DD36A
00007b00b77dd44f  movq rax, xmm15
00007b00b77dd454  shl rax, 0x0D
00007b00b77dd458  jbe 0x00007B00B77DD36A
00007b00b77dd45e  vorps xmm13, xmm15, [0x00007B00B73FE070]
00007b00b77dd466  jmp 0x00007B00B77DD36A
00007b00b77dd46b  ucomisd xmm1, xmm15
00007b00b77dd470  jp 0x00007B00B77DD47F
00007b00b77dd472  movaps xmm14, [0x00007B00B73FE060]
00007b00b77dd47a  jmp 0x00007B00B77DD397
00007b00b77dd47f  vxorps xmm0, xmm1, xmm15
00007b00b77dd484  pextrw eax, xmm0, 0x03
00007b00b77dd489  and eax, 0x7FF8
00007b00b77dd48e  cmp eax, 0x08
00007b00b77dd491  jnz 0x00007B00B77DD397
00007b00b77dd497  movq rax, xmm15
00007b00b77dd49c  shl rax, 0x0D
00007b00b77dd4a0  jbe 0x00007B00B77DD397
00007b00b77dd4a6  vorps xmm14, xmm15, [0x00007B00B73FE070]
00007b00b77dd4ae  jmp 0x00007B00B77DD397
00007b00b77dd4b3  int3
00007b00b77dd4b4  nop [rax+rax*1], ax
00007b00b77dd4bd  nop [rax], eax
00007b00b77dd4c0  mov rax, [r15+0x48]
00007b00b77dd4c4  mov r14, [r15+0x50]
00007b00b77dd4c8  lea r12, [r14+rax*1]
00007b00b77dd4cc  movups xmm1, [r13+r12*1]
00007b00b77dd4d2  movaps [r15+0x120], xmm1
00007b00b77dd4da  lea r14, [rax+0x10]
00007b00b77dd4de  mov [r15+0x48], r14
00007b00b77dd4e2  xor eax, eax
00007b00b77dd4e4  mov r12d, 0x200
00007b00b77dd4ea  cmp r14, r12
00007b00b77dd4ed  cmc
00007b00b77dd4ee  lahf
00007b00b77dd4ef  seto al
00007b00b77dd4f2  mov [r15+0x108], eax
00007b00b77dd4f9  pextrq rax, xmm1, 0x01
00007b00b77dd500  movq xmm15, rax
00007b00b77dd505  movaps [r15+0x130], xmm15
00007b00b77dd50d  movaps xmm14, [r15+0x110]
00007b00b77dd515  movq rax, xmm14
00007b00b77dd51a  movq r14, xmm1
00007b00b77dd51f  vmovq xmm1, rax
00007b00b77dd524  vmovq xmm14, r14
00007b00b77dd529  movaps xmm13, xmm1
00007b00b77dd52d  addsd xmm13, xmm14
00007b00b77dd532  ucomisd xmm13, xmm13
00007b00b77dd537  jp 0x00007B00B77DD5EC
00007b00b77dd53d  movq xmm13, xmm13
00007b00b77dd542  movq rax, xmm13
00007b00b77dd547  movq r14, xmm15
00007b00b77dd54c  vmovq xmm1, rax
00007b00b77dd551  vmovq xmm15, r14
00007b00b77dd556  movaps xmm14, xmm1
00007b00b77dd55a  addsd xmm14, xmm15
00007b00b77dd55f  ucomisd xmm14, xmm14
00007b00b77dd564  jp 0x00007B00B77DD634
00007b00b77dd56a  movq xmm14, xmm14
00007b00b77dd56f  movaps [r15+0x110], xmm14
00007b00b77dd577  mov eax, [r15+0x108]
00007b00b77dd57e  sahf
00007b00b77dd57f  jnz 0x00007B00B77DD5B1
00007b00b77dd581  cmp dword ptr [r15+0x318], 0x00
00007b00b77dd589  jz 0x00007B00B77DD680
00007b00b77dd58f  nop [rax+rax*1], ax
00007b00b77dd598  nop [rax+rax*1], eax
00007b00b77dd5a0  mov eax, 0x410698
00007b00b77dd5a5  mov [r15+0x100], rax
00007b00b77dd5ac  jmp 0x00007B00B75FE110
00007b00b77dd5b1  cmp dword ptr [r15+0x318], 0x00
00007b00b77dd5b9  jz 0x00007B00B77DD4C0
00007b00b77dd5bf  nop [rax+rax*1], ax
00007b00b77dd5c8  nop [rax+rax*1], eax
00007b00b77dd5d0  mov eax, 0x41067C
00007b00b77dd5d5  mov [r15+0x100], rax
00007b00b77dd5dc  jmp 0x00007B00B75FE110
00007b00b77dd5e1  int3
00007b00b77dd5e2  call 0x00007B00B76B52F0
00007b00b77dd5e7  jmp 0x00007B00B77DD4D2
00007b00b77dd5ec  ucomisd xmm1, xmm14
00007b00b77dd5f1  jp 0x00007B00B77DD600
00007b00b77dd5f3  movaps xmm13, [0x00007B00B73FE060]
00007b00b77dd5fb  jmp 0x00007B00B77DD53D
00007b00b77dd600  vxorps xmm0, xmm1, xmm14
00007b00b77dd605  pextrw eax, xmm0, 0x03
00007b00b77dd60a  and eax, 0x7FF8
00007b00b77dd60f  cmp eax, 0x08
00007b00b77dd612  jnz 0x00007B00B77DD53D
00007b00b77dd618  movq rax, xmm14
00007b00b77dd61d  shl rax, 0x0D
00007b00b77dd621  jbe 0x00007B00B77DD53D
00007b00b77dd627  vorps xmm13, xmm14, [0x00007B00B73FE070]
00007b00b77dd62f  jmp 0x00007B00B77DD53D
00007b00b77dd634  ucomisd xmm1, xmm15
00007b00b77dd639  jp 0x00007B00B77DD648
00007b00b77dd63b  movaps xmm14, [0x00007B00B73FE060]
00007b00b77dd643  jmp 0x00007B00B77DD56A
00007b00b77dd648  vxorps xmm0, xmm1, xmm15
00007b00b77dd64d  pextrw eax, xmm0, 0x03
00007b00b77dd652  and eax, 0x7FF8
00007b00b77dd657  cmp eax, 0x08
00007b00b77dd65a  jnz 0x00007B00B77DD56A
00007b00b77dd660  movq rax, xmm15
00007b00b77dd665  shl rax, 0x0D
00007b00b77dd669  jbe 0x00007B00B77DD56A
00007b00b77dd66f  vorps xmm14, xmm15, [0x00007B00B73FE070]
00007b00b77dd677  jmp 0x00007B00B77DD56A
00007b00b77dd67c  int3
00007b00b77dd67d  nop [rax], eax
00007b00b77dd680  mov rax, [r15+0xF8]
00007b00b77dd687  lea r14, [rax+0x1A0]
00007b00b77dd68e  mov r12, [r13+r14*1]
00007b00b77dd693  lea r14, [rax+0x1A8]
00007b00b77dd69a  mov r11, [r13+r14*1]
00007b00b77dd69f  mov [r15+0xA0], r12
00007b00b77dd6a6  mov [r15+0x98], r11
00007b00b77dd6ad  mov r14, [r15+0x40]
00007b00b77dd6b1  lea r12, [r14+0xC50]
00007b00b77dd6b8  movaps xmm1, [r15+0x110]
00007b00b77dd6c0  movq r14, xmm1
00007b00b77dd6c5  mov [r13+r12*1], r14
00007b00b77dd6ca  lea r14, [rax+0x190]
00007b00b77dd6d1  mov r12, [r13+r14*1]
00007b00b77dd6d6  lea r14, [rax+0x198]
00007b00b77dd6dd  mov r11, [r13+r14*1]
00007b00b77dd6e2  mov [r15+0xE8], r12
00007b00b77dd6e9  mov [r15+0xF0], r11
00007b00b77dd6f0  lea r14, [rax+0x180]
00007b00b77dd6f7  mov r12, [r13+r14*1]
00007b00b77dd6fc  lea r14, [rax+0x188]
00007b00b77dd703  mov r10, [r13+r14*1]
00007b00b77dd708  movq xmm1, r12
00007b00b77dd70d  movq xmm15, r10
00007b00b77dd712  movq xmm1, xmm1
00007b00b77dd716  movq xmm1, xmm1
00007b00b77dd71a  movaps [r15+0x1A0], xmm1
00007b00b77dd722  movq xmm15, xmm15
00007b00b77dd727  movq xmm15, xmm15
00007b00b77dd72c  movaps [r15+0x190], xmm15
00007b00b77dd734  lea r14, [rax+0x170]
00007b00b77dd73b  mov r12, [r13+r14*1]
00007b00b77dd740  lea r14, [rax+0x178]
00007b00b77dd747  mov r10, [r13+r14*1]
00007b00b77dd74c  movq xmm1, r12
00007b00b77dd751  movq xmm15, r10
00007b00b77dd756  movq xmm1, xmm1
00007b00b77dd75a  movq xmm1, xmm1
00007b00b77dd75e  movaps [r15+0x1C0], xmm1
00007b00b77dd766  movq xmm15, xmm15
00007b00b77dd76b  movq xmm15, xmm15
00007b00b77dd770  movaps [r15+0x1B0], xmm15
00007b00b77dd778  lea r14, [rax+0x160]
00007b00b77dd77f  mov r12, [r13+r14*1]
00007b00b77dd784  lea r14, [rax+0x168]
00007b00b77dd78b  mov r10, [r13+r14*1]
00007b00b77dd790  movq xmm1, r12
00007b00b77dd795  movq xmm15, r10
00007b00b77dd79a  movq xmm1, xmm1
00007b00b77dd79e  movq xmm1, xmm1
00007b00b77dd7a2  movaps [r15+0x1E0], xmm1
00007b00b77dd7aa  movq xmm15, xmm15
00007b00b77dd7af  movq xmm15, xmm15
00007b00b77dd7b4  movaps [r15+0x1D0], xmm15
00007b00b77dd7bc  lea r14, [rax+0x150]
00007b00b77dd7c3  mov r12, [r13+r14*1]
00007b00b77dd7c8  lea r14, [rax+0x158]
00007b00b77dd7cf  mov r10, [r13+r14*1]
00007b00b77dd7d4  movq xmm1, r12
00007b00b77dd7d9  movq xmm15, r10
00007b00b77dd7de  movq xmm1, xmm1
00007b00b77dd7e2  movq xmm1, xmm1
00007b00b77dd7e6  movaps [r15+0x200], xmm1
00007b00b77dd7ee  movq xmm15, xmm15
00007b00b77dd7f3  movq xmm15, xmm15
00007b00b77dd7f8  movaps [r15+0x1F0], xmm15
00007b00b77dd800  lea r14, [rax+0x1B0]
00007b00b77dd807  mov [r15+0xF8], r14
00007b00b77dd80e  mov [r15+0x100], r11
00007b00b77dd815  jmp 0x00007B00B77CE5C0
00007b00b77dd81a  int3
00007b00b77dd81b  call 0x00007B00B76E27E0
00007b00b77dd820  jmp 0x00007B00B77DD693
00007b00b77dd825  call 0x00007B00B76E1570
00007b00b77dd82a  jmp 0x00007B00B77DD69F
00007b00b77dd82f  call 0x00007B00B76C3FE0
00007b00b77dd834  jmp 0x00007B00B77DD6CA
00007b00b77dd839  call 0x00007B00B76E27E0
00007b00b77dd83e  jmp 0x00007B00B77DD6D6
00007b00b77dd843  call 0x00007B00B76E1570
00007b00b77dd848  jmp 0x00007B00B77DD6E2
00007b00b77dd84d  call 0x00007B00B76E27E0
00007b00b77dd852  jmp 0x00007B00B77DD6FC
00007b00b77dd857  call 0x00007B00B76E0300
00007b00b77dd85c  jmp 0x00007B00B77DD708
00007b00b77dd861  call 0x00007B00B76E27E0
00007b00b77dd866  jmp 0x00007B00B77DD740
00007b00b77dd86b  call 0x00007B00B76E0300
00007b00b77dd870  jmp 0x00007B00B77DD74C
00007b00b77dd875  call 0x00007B00B76E27E0
00007b00b77dd87a  jmp 0x00007B00B77DD784
00007b00b77dd87f  call 0x00007B00B76E0300
00007b00b77dd884  jmp 0x00007B00B77DD790
00007b00b77dd889  call 0x00007B00B76E27E0
00007b00b77dd88e  jmp 0x00007B00B77DD7C8
00007b00b77dd893  call 0x00007B00B76E0300
00007b00b77dd898  jmp 0x00007B00B77DD7D4
00007b00b77dd89d  int3
00007b00b77dd89e  nop
00007b00b77dd8a0  mov qword ptr [r15+0x100], 0x04
00007b00b77dd8ab  mov esi, 0x00
00007b00b77dd8b0  mov edx, 0x09
00007b00b77dd8b5  mov rdi, 0x7FFCFE3153F0
00007b00b77dd8bf  mov rax, 0x612A23414970
00007b00b77dd8c9  call rax
00007b00b77dd8cb  cmp dword ptr [r15+0x318], 0x00
00007b00b77dd8d3  jnz 0x00007B00B75FE110
00007b00b77dd8d9  jmp 0x00007B00B75FE0A0
00007b00b77dd8de  int3
00007b00b77dd8df  int3
