0000761a4a3ce69b  nop [rax+rax*1], eax
0000761a4a3ce6a0  mov qword ptr [r15+0x08], 0xB71B00
0000761a4a3ce6a8  mov qword ptr [r15+0x20], 0x420090
0000761a4a3ce6b0  mov qword ptr [r15+0x10], 0x00
0000761a4a3ce6b8  mov qword ptr [r15], 0x01
0000761a4a3ce6bf  xor eax, eax
0000761a4a3ce6c1  mov r14d, 0x01
0000761a4a3ce6c7  mov r12d, 0x07
0000761a4a3ce6cd  cmp r14, r12
0000761a4a3ce6d0  cmc
0000761a4a3ce6d1  lahf
0000761a4a3ce6d2  seto al
0000761a4a3ce6d5  mov [r15+0x108], eax
0000761a4a3ce6dc  mov eax, [r15+0x108]
0000761a4a3ce6e3  sahf
0000761a4a3ce6e4  cmc
0000761a4a3ce6e5  jnbe 0x0000761A4A3CE717
0000761a4a3ce6e7  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ce6ef  jz 0x0000761A4A3CE750
0000761a4a3ce6f5  nop [rax+rax*1], ax
0000761a4a3ce6fe  nop [rax+rax*1], eax
0000761a4a3ce706  mov eax, 0x41004C
0000761a4a3ce70b  mov [r15+0x100], rax
0000761a4a3ce712  jmp 0x0000761A4A1FE110
0000761a4a3ce717  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ce71f  jz 0x0000761A4A3CEC10
0000761a4a3ce725  nop [rax+rax*1], ax
0000761a4a3ce72e  nop [rax+rax*1], eax
0000761a4a3ce736  mov eax, 0x410050
0000761a4a3ce73b  mov [r15+0x100], rax
0000761a4a3ce742  jmp 0x0000761A4A1FE110
0000761a4a3ce747  int3
0000761a4a3ce748  int3
0000761a4a3ce749  nop [rax], eax
0000761a4a3ce750  mov rax, [r15+0x10]
0000761a4a3ce754  lea r14, [rax+0x03]
0000761a4a3ce758  mov [r15+0x10], r14
0000761a4a3ce75c  mov rax, [r15]
0000761a4a3ce75f  mov [rsp+0x10], rax
0000761a4a3ce764  xor eax, eax
0000761a4a3ce766  mov r14, [rsp+0x10]
0000761a4a3ce76b  mov r12d, 0x05
0000761a4a3ce771  cmp r14, r12
0000761a4a3ce774  cmc
0000761a4a3ce775  lahf
0000761a4a3ce776  seto al
0000761a4a3ce779  mov [r15+0x108], eax
0000761a4a3ce780  mov eax, [r15+0x108]
0000761a4a3ce787  cmp al, 0x81
0000761a4a3ce789  sahf
0000761a4a3ce78a  jl 0x0000761A4A3CE7BC
0000761a4a3ce78c  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ce794  jz 0x0000761A4A3CEB70
0000761a4a3ce79a  nop [rax+rax*1], ax
0000761a4a3ce7a3  nop [rax+rax*1], eax
0000761a4a3ce7ab  mov eax, 0x410058
0000761a4a3ce7b0  mov [r15+0x100], rax
0000761a4a3ce7b7  jmp 0x0000761A4A1FE110
0000761a4a3ce7bc  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ce7c4  jz 0x0000761A4A3CE7F0
0000761a4a3ce7ca  nop [rax+rax*1], ax
0000761a4a3ce7d3  nop [rax+rax*1], eax
0000761a4a3ce7db  mov eax, 0x41005C
0000761a4a3ce7e0  mov [r15+0x100], rax
0000761a4a3ce7e7  jmp 0x0000761A4A1FE110
0000761a4a3ce7ec  int3
0000761a4a3ce7ed  int3
0000761a4a3ce7ee  nop
0000761a4a3ce7f0  mov rax, [r15]
0000761a4a3ce7f3  and rax, 0x01
0000761a4a3ce7f7  mov [r15+0x18], rax
0000761a4a3ce7fb  test rax, rax
0000761a4a3ce7fe  setz al
0000761a4a3ce801  movzx rax, al
0000761a4a3ce805  mov [rsp+0x414], al
0000761a4a3ce80c  cmp byte ptr [rsp+0x414], 0x00
0000761a4a3ce814  jz 0x0000761A4A3CE846
0000761a4a3ce816  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ce81e  jz 0x0000761A4A3CEA50
0000761a4a3ce824  nop [rax+rax*1], ax
0000761a4a3ce82d  nop [rax+rax*1], eax
0000761a4a3ce835  mov eax, 0x410068
0000761a4a3ce83a  mov [r15+0x100], rax
0000761a4a3ce841  jmp 0x0000761A4A1FE110
0000761a4a3ce846  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ce84e  jz 0x0000761A4A3CE880
0000761a4a3ce854  nop [rax+rax*1], ax
0000761a4a3ce85d  nop [rax+rax*1], eax
0000761a4a3ce865  mov eax, 0x410064
0000761a4a3ce86a  mov [r15+0x100], rax
0000761a4a3ce871  jmp 0x0000761A4A1FE110
0000761a4a3ce876  int3
0000761a4a3ce877  int3
0000761a4a3ce878  nop [rax+rax*1], eax
0000761a4a3ce880  mov rax, [r15+0x10]
0000761a4a3ce884  lea r14, [rax+0x07]
0000761a4a3ce888  mov [r15+0x10], r14
0000761a4a3ce88c  mov eax, [r15]
0000761a4a3ce88f  mov eax, eax
0000761a4a3ce891  bt rax, 0x01
0000761a4a3ce896  setb al
0000761a4a3ce899  mov [rsp+0x414], al
0000761a4a3ce8a0  cmp byte ptr [rsp+0x414], 0x00
0000761a4a3ce8a8  jz 0x0000761A4A3CE8DA
0000761a4a3ce8aa  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ce8b2  jz 0x0000761A4A3CEAD0
0000761a4a3ce8b8  nop [rax+rax*1], ax
0000761a4a3ce8c1  nop [rax+rax*1], eax
0000761a4a3ce8c9  mov eax, 0x410070
0000761a4a3ce8ce  mov [r15+0x100], rax
0000761a4a3ce8d5  jmp 0x0000761A4A1FE110
0000761a4a3ce8da  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ce8e2  jz 0x0000761A4A3CE910
0000761a4a3ce8e8  nop [rax+rax*1], ax
0000761a4a3ce8f1  nop [rax+rax*1], eax
0000761a4a3ce8f9  mov eax, 0x41006C
0000761a4a3ce8fe  mov [r15+0x100], rax
0000761a4a3ce905  jmp 0x0000761A4A1FE110
0000761a4a3ce90a  int3
0000761a4a3ce90b  int3
0000761a4a3ce90c  nop [rax], eax
0000761a4a3ce910  mov rax, [r15+0x10]
0000761a4a3ce914  lea r14, [rax+0x0B]
0000761a4a3ce918  mov [r15+0x10], r14
0000761a4a3ce91c  mov rax, [r15+0x08]
0000761a4a3ce920  mov [rsp+0x10], rax
0000761a4a3ce925  xor eax, eax
0000761a4a3ce927  mov r14, [rsp+0x10]
0000761a4a3ce92c  mov r12d, 0x01
0000761a4a3ce932  sub r14, r12
0000761a4a3ce935  cmc
0000761a4a3ce936  lahf
0000761a4a3ce937  seto al
0000761a4a3ce93a  mov [r15+0x108], eax
0000761a4a3ce941  mov [r15+0x08], r14
0000761a4a3ce945  mov eax, [r15+0x108]
0000761a4a3ce94c  sahf
0000761a4a3ce94d  jnz 0x0000761A4A3CE97F
0000761a4a3ce94f  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ce957  jz 0x0000761A4A3CECB0
0000761a4a3ce95d  nop [rax+rax*1], ax
0000761a4a3ce966  nop [rax+rax*1], eax
0000761a4a3ce96e  mov eax, 0x410078
0000761a4a3ce973  mov [r15+0x100], rax
0000761a4a3ce97a  jmp 0x0000761A4A1FE110
0000761a4a3ce97f  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ce987  jz 0x0000761A4A3CE9C0
0000761a4a3ce98d  nop [rax+rax*1], ax
0000761a4a3ce996  nop [rax+rax*1], eax
0000761a4a3ce99e  mov eax, 0x410040
0000761a4a3ce9a3  mov [r15+0x100], rax
0000761a4a3ce9aa  jmp 0x0000761A4A1FE110
0000761a4a3ce9af  int3
0000761a4a3ce9b0  int3
0000761a4a3ce9b1  nop [rax+rax*1], ax
0000761a4a3ce9ba  nop [rax+rax*1], ax
0000761a4a3ce9c0  mov rax, [r15]
0000761a4a3ce9c3  lea r14, [rax+0x01]
0000761a4a3ce9c7  mov [r15], r14
0000761a4a3ce9ca  xor eax, eax
0000761a4a3ce9cc  mov r12d, 0x07
0000761a4a3ce9d2  cmp r14, r12
0000761a4a3ce9d5  cmc
0000761a4a3ce9d6  lahf
0000761a4a3ce9d7  seto al
0000761a4a3ce9da  mov [r15+0x108], eax
0000761a4a3ce9e1  mov eax, [r15+0x108]
0000761a4a3ce9e8  sahf
0000761a4a3ce9e9  cmc
0000761a4a3ce9ea  jnbe 0x0000761A4A3CEA1C
0000761a4a3ce9ec  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ce9f4  jz 0x0000761A4A3CE750
0000761a4a3ce9fa  nop [rax+rax*1], ax
0000761a4a3cea03  nop [rax+rax*1], eax
0000761a4a3cea0b  mov eax, 0x41004C
0000761a4a3cea10  mov [r15+0x100], rax
0000761a4a3cea17  jmp 0x0000761A4A1FE110
0000761a4a3cea1c  cmp dword ptr [r15+0x318], 0x00
0000761a4a3cea24  jz 0x0000761A4A3CEC10
0000761a4a3cea2a  nop [rax+rax*1], ax
0000761a4a3cea33  nop [rax+rax*1], eax
0000761a4a3cea3b  mov eax, 0x410050
0000761a4a3cea40  mov [r15+0x100], rax
0000761a4a3cea47  jmp 0x0000761A4A1FE110
0000761a4a3cea4c  int3
0000761a4a3cea4d  int3
0000761a4a3cea4e  nop
0000761a4a3cea50  mov eax, [r15]
0000761a4a3cea53  mov eax, eax
0000761a4a3cea55  bt rax, 0x01
0000761a4a3cea5a  setb al
0000761a4a3cea5d  mov [rsp+0x414], al
0000761a4a3cea64  cmp byte ptr [rsp+0x414], 0x00
0000761a4a3cea6c  jz 0x0000761A4A3CEA9E
0000761a4a3cea6e  cmp dword ptr [r15+0x318], 0x00
0000761a4a3cea76  jz 0x0000761A4A3CEAD0
0000761a4a3cea7c  nop [rax+rax*1], ax
0000761a4a3cea85  nop [rax+rax*1], eax
0000761a4a3cea8d  mov eax, 0x410070
0000761a4a3cea92  mov [r15+0x100], rax
0000761a4a3cea99  jmp 0x0000761A4A1FE110
0000761a4a3cea9e  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ceaa6  jz 0x0000761A4A3CE910
0000761a4a3ceaac  nop [rax+rax*1], ax
0000761a4a3ceab5  nop [rax+rax*1], eax
0000761a4a3ceabd  mov eax, 0x41006C
0000761a4a3ceac2  mov [r15+0x100], rax
0000761a4a3ceac9  jmp 0x0000761A4A1FE110
0000761a4a3ceace  int3
0000761a4a3ceacf  int3
0000761a4a3cead0  mov rax, [r15+0x08]
0000761a4a3cead4  mov [rsp+0x10], rax
0000761a4a3cead9  xor eax, eax
0000761a4a3ceadb  mov r14, [rsp+0x10]
0000761a4a3ceae0  mov r12d, 0x01
0000761a4a3ceae6  sub r14, r12
0000761a4a3ceae9  cmc
0000761a4a3ceaea  lahf
0000761a4a3ceaeb  seto al
0000761a4a3ceaee  mov [r15+0x108], eax
0000761a4a3ceaf5  mov [r15+0x08], r14
0000761a4a3ceaf9  mov eax, [r15+0x108]
0000761a4a3ceb00  sahf
0000761a4a3ceb01  jnz 0x0000761A4A3CEB33
0000761a4a3ceb03  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ceb0b  jz 0x0000761A4A3CECB0
0000761a4a3ceb11  nop [rax+rax*1], ax
0000761a4a3ceb1a  nop [rax+rax*1], eax
0000761a4a3ceb22  mov eax, 0x410078
0000761a4a3ceb27  mov [r15+0x100], rax
0000761a4a3ceb2e  jmp 0x0000761A4A1FE110
0000761a4a3ceb33  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ceb3b  jz 0x0000761A4A3CE9C0
0000761a4a3ceb41  nop [rax+rax*1], ax
0000761a4a3ceb4a  nop [rax+rax*1], eax
0000761a4a3ceb52  mov eax, 0x410040
0000761a4a3ceb57  mov [r15+0x100], rax
0000761a4a3ceb5e  jmp 0x0000761A4A1FE110
0000761a4a3ceb63  int3
0000761a4a3ceb64  int3
0000761a4a3ceb65  nop [rax+rax*1], ax
0000761a4a3ceb6e  nop
0000761a4a3ceb70  mov rax, [r15+0x10]
0000761a4a3ceb74  lea r14, [rax+0x05]
0000761a4a3ceb78  mov [r15+0x10], r14
0000761a4a3ceb7c  mov rax, [r15]
0000761a4a3ceb7f  and rax, 0x01
0000761a4a3ceb83  mov [r15+0x18], rax
0000761a4a3ceb87  test rax, rax
0000761a4a3ceb8a  setz al
0000761a4a3ceb8d  movzx rax, al
0000761a4a3ceb91  mov [rsp+0x414], al
0000761a4a3ceb98  cmp byte ptr [rsp+0x414], 0x00
0000761a4a3ceba0  jz 0x0000761A4A3CEBD2
0000761a4a3ceba2  cmp dword ptr [r15+0x318], 0x00
0000761a4a3cebaa  jz 0x0000761A4A3CEA50
0000761a4a3cebb0  nop [rax+rax*1], ax
0000761a4a3cebb9  nop [rax+rax*1], eax
0000761a4a3cebc1  mov eax, 0x410068
0000761a4a3cebc6  mov [r15+0x100], rax
0000761a4a3cebcd  jmp 0x0000761A4A1FE110
0000761a4a3cebd2  cmp dword ptr [r15+0x318], 0x00
0000761a4a3cebda  jz 0x0000761A4A3CE880
0000761a4a3cebe0  nop [rax+rax*1], ax
0000761a4a3cebe9  nop [rax+rax*1], eax
0000761a4a3cebf1  mov eax, 0x410064
0000761a4a3cebf6  mov [r15+0x100], rax
0000761a4a3cebfd  jmp 0x0000761A4A1FE110
0000761a4a3cec02  int3
0000761a4a3cec03  int3
0000761a4a3cec04  nop [rax+rax*1], ax
0000761a4a3cec0d  nop [rax], eax
0000761a4a3cec10  mov rax, [r15]
0000761a4a3cec13  mov [rsp+0x10], rax
0000761a4a3cec18  xor eax, eax
0000761a4a3cec1a  mov r14, [rsp+0x10]
0000761a4a3cec1f  mov r12d, 0x05
0000761a4a3cec25  cmp r14, r12
0000761a4a3cec28  cmc
0000761a4a3cec29  lahf
0000761a4a3cec2a  seto al
0000761a4a3cec2d  mov [r15+0x108], eax
0000761a4a3cec34  mov eax, [r15+0x108]
0000761a4a3cec3b  cmp al, 0x81
0000761a4a3cec3d  sahf
0000761a4a3cec3e  jl 0x0000761A4A3CEC70
0000761a4a3cec40  cmp dword ptr [r15+0x318], 0x00
0000761a4a3cec48  jz 0x0000761A4A3CEB70
0000761a4a3cec4e  nop [rax+rax*1], ax
0000761a4a3cec57  nop [rax+rax*1], eax
0000761a4a3cec5f  mov eax, 0x410058
0000761a4a3cec64  mov [r15+0x100], rax
0000761a4a3cec6b  jmp 0x0000761A4A1FE110
0000761a4a3cec70  cmp dword ptr [r15+0x318], 0x00
0000761a4a3cec78  jz 0x0000761A4A3CE7F0
0000761a4a3cec7e  nop [rax+rax*1], ax
0000761a4a3cec87  nop [rax+rax*1], eax
0000761a4a3cec8f  mov eax, 0x41005C
0000761a4a3cec94  mov [r15+0x100], rax
0000761a4a3cec9b  jmp 0x0000761A4A1FE110
0000761a4a3ceca0  int3
0000761a4a3ceca1  int3
0000761a4a3ceca2  nop [rax+rax*1], ax
0000761a4a3cecab  nop [rax+rax*1], eax
0000761a4a3cecb0  mov rax, [r15+0x10]
0000761a4a3cecb4  mov [r15], rax
0000761a4a3cecb7  mov r14, [r15+0x20]
0000761a4a3cecbb  mov [r13+r14*1], rax
0000761a4a3cecc0  mov rax, [r15+0xF0]
0000761a4a3cecc7  mov [r15+0x100], rax
0000761a4a3cecce  jmp 0x0000761A4A3CE5C0
0000761a4a3cecd3  int3
0000761a4a3cecd4  call 0x0000761A4A2D5EB0
0000761a4a3cecd9  jmp 0x0000761A4A3CECC0
0000761a4a3cecde  int3
0000761a4a3cecdf  nop
0000761a4a3cece0  mov qword ptr [r15+0x100], 0x04
0000761a4a3ceceb  mov esi, 0x00
0000761a4a3cecf0  mov edx, 0x09
0000761a4a3cecf5  mov rdi, 0x7FFFEAA99C70
0000761a4a3cecff  mov rax, 0x5FCB91944970
0000761a4a3ced09  call rax
0000761a4a3ced0b  cmp dword ptr [r15+0x318], 0x00
0000761a4a3ced13  jnz 0x0000761A4A1FE110
0000761a4a3ced19  jmp 0x0000761A4A1FE0A0
0000761a4a3ced1e  int3
0000761a4a3ced1f  int3
