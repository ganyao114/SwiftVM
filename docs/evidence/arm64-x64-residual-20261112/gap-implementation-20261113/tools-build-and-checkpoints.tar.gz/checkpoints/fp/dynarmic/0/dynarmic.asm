00007fa65edce69b  nop [rax+rax*1], eax
00007fa65edce6a0  mov qword ptr [r15+0x20], 0x420060
00007fa65edce6a8  mov qword ptr [r15], 0x00
00007fa65edce6af  vmovaps xmm1, [0x00007FA65E9FE010]
00007fa65edce6b7  movq xmm1, xmm1
00007fa65edce6bb  vmovaps xmm15, [0x00007FA65E9FE020]
00007fa65edce6c3  movq xmm15, xmm15
00007fa65edce6c8  movaps [r15+0x120], xmm15
00007fa65edce6d0  movq rax, xmm1
00007fa65edce6d5  movq r14, xmm15
00007fa65edce6da  vmovq xmm1, rax
00007fa65edce6df  vmovq xmm15, r14
00007fa65edce6e4  movaps xmm14, xmm1
00007fa65edce6e8  addsd xmm14, xmm15
00007fa65edce6ed  ucomisd xmm14, xmm14
00007fa65edce6f2  jp 0x00007FA65EDCE791
00007fa65edce6f8  movq xmm14, xmm14
00007fa65edce6fd  movaps [r15+0x110], xmm14
00007fa65edce705  xor eax, eax
00007fa65edce707  mov r14d, 0xF4240
00007fa65edce70d  mov r12d, 0x01
00007fa65edce713  sub r14, r12
00007fa65edce716  cmc
00007fa65edce717  lahf
00007fa65edce718  seto al
00007fa65edce71b  mov [r15+0x108], eax
00007fa65edce722  mov [r15+0x08], r14
00007fa65edce726  mov eax, [r15+0x108]
00007fa65edce72d  sahf
00007fa65edce72e  jnz 0x00007FA65EDCE760
00007fa65edce730  cmp dword ptr [r15+0x318], 0x00
00007fa65edce738  jz 0x00007FA65EDCE910
00007fa65edce73e  nop [rax+rax*1], ax
00007fa65edce747  nop [rax+rax*1], eax
00007fa65edce74f  mov eax, 0x410050
00007fa65edce754  mov [r15+0x100], rax
00007fa65edce75b  jmp 0x00007FA65EBFE110
00007fa65edce760  cmp dword ptr [r15+0x318], 0x00
00007fa65edce768  jz 0x00007FA65EDCE7E0
00007fa65edce76e  nop [rax+rax*1], ax
00007fa65edce777  nop [rax+rax*1], eax
00007fa65edce77f  mov eax, 0x410044
00007fa65edce784  mov [r15+0x100], rax
00007fa65edce78b  jmp 0x00007FA65EBFE110
00007fa65edce790  int3
00007fa65edce791  ucomisd xmm1, xmm15
00007fa65edce796  jp 0x00007FA65EDCE7A5
00007fa65edce798  movaps xmm14, [0x00007FA65E9FE030]
00007fa65edce7a0  jmp 0x00007FA65EDCE6F8
00007fa65edce7a5  vxorps xmm0, xmm1, xmm15
00007fa65edce7aa  pextrw eax, xmm0, 0x03
00007fa65edce7af  and eax, 0x7FF8
00007fa65edce7b4  cmp eax, 0x08
00007fa65edce7b7  jnz 0x00007FA65EDCE6F8
00007fa65edce7bd  movq rax, xmm15
00007fa65edce7c2  shl rax, 0x0D
00007fa65edce7c6  jbe 0x00007FA65EDCE6F8
00007fa65edce7cc  vorps xmm14, xmm15, [0x00007FA65E9FE040]
00007fa65edce7d4  jmp 0x00007FA65EDCE6F8
00007fa65edce7d9  int3
00007fa65edce7da  nop [rax+rax*1], ax
00007fa65edce7e0  movaps xmm1, [r15+0x110]
00007fa65edce7e8  movq rax, xmm1
00007fa65edce7ed  movaps xmm1, [r15+0x120]
00007fa65edce7f5  movq r14, xmm1
00007fa65edce7fa  vmovq xmm1, rax
00007fa65edce7ff  vmovq xmm15, r14
00007fa65edce804  movaps xmm14, xmm1
00007fa65edce808  addsd xmm14, xmm15
00007fa65edce80d  ucomisd xmm14, xmm14
00007fa65edce812  jp 0x00007FA65EDCE8B9
00007fa65edce818  movq xmm14, xmm14
00007fa65edce81d  movaps [r15+0x110], xmm14
00007fa65edce825  mov rax, [r15+0x08]
00007fa65edce829  mov [rsp+0x10], rax
00007fa65edce82e  xor eax, eax
00007fa65edce830  mov r14, [rsp+0x10]
00007fa65edce835  mov r12d, 0x01
00007fa65edce83b  sub r14, r12
00007fa65edce83e  cmc
00007fa65edce83f  lahf
00007fa65edce840  seto al
00007fa65edce843  mov [r15+0x108], eax
00007fa65edce84a  mov [r15+0x08], r14
00007fa65edce84e  mov eax, [r15+0x108]
00007fa65edce855  sahf
00007fa65edce856  jnz 0x00007FA65EDCE888
00007fa65edce858  cmp dword ptr [r15+0x318], 0x00
00007fa65edce860  jz 0x00007FA65EDCE910
00007fa65edce866  nop [rax+rax*1], ax
00007fa65edce86f  nop [rax+rax*1], eax
00007fa65edce877  mov eax, 0x410050
00007fa65edce87c  mov [r15+0x100], rax
00007fa65edce883  jmp 0x00007FA65EBFE110
00007fa65edce888  cmp dword ptr [r15+0x318], 0x00
00007fa65edce890  jz 0x00007FA65EDCE7E0
00007fa65edce896  nop [rax+rax*1], ax
00007fa65edce89f  nop [rax+rax*1], eax
00007fa65edce8a7  mov eax, 0x410044
00007fa65edce8ac  mov [r15+0x100], rax
00007fa65edce8b3  jmp 0x00007FA65EBFE110
00007fa65edce8b8  int3
00007fa65edce8b9  ucomisd xmm1, xmm15
00007fa65edce8be  jp 0x00007FA65EDCE8CD
00007fa65edce8c0  movaps xmm14, [0x00007FA65E9FE030]
00007fa65edce8c8  jmp 0x00007FA65EDCE818
00007fa65edce8cd  vxorps xmm0, xmm1, xmm15
00007fa65edce8d2  pextrw eax, xmm0, 0x03
00007fa65edce8d7  and eax, 0x7FF8
00007fa65edce8dc  cmp eax, 0x08
00007fa65edce8df  jnz 0x00007FA65EDCE818
00007fa65edce8e5  movq rax, xmm15
00007fa65edce8ea  shl rax, 0x0D
00007fa65edce8ee  jbe 0x00007FA65EDCE818
00007fa65edce8f4  vorps xmm14, xmm15, [0x00007FA65E9FE040]
00007fa65edce8fc  jmp 0x00007FA65EDCE818
00007fa65edce901  int3
00007fa65edce902  nop [rax+rax*1], ax
00007fa65edce90b  nop [rax+rax*1], eax
00007fa65edce910  mov rax, [r15+0x20]
00007fa65edce914  movaps xmm1, [r15+0x110]
00007fa65edce91c  movq r14, xmm1
00007fa65edce921  mov [r13+rax*1], r14
00007fa65edce926  mov rax, [r15+0xF0]
00007fa65edce92d  mov [r15+0x100], rax
00007fa65edce934  jmp 0x00007FA65EDCE5C0
00007fa65edce939  int3
00007fa65edce93a  call 0x00007FA65EC0E120
00007fa65edce93f  jmp 0x00007FA65EDCE926
00007fa65edce944  int3
00007fa65edce945  nop [rax+rax*1], ax
00007fa65edce94e  nop
00007fa65edce950  mov qword ptr [r15+0x100], 0x04
00007fa65edce95b  mov esi, 0x00
00007fa65edce960  mov edx, 0x09
00007fa65edce965  mov rdi, 0x7FFEB5989970
00007fa65edce96f  mov rax, 0x5883B0B78970
00007fa65edce979  call rax
00007fa65edce97b  cmp dword ptr [r15+0x318], 0x00
00007fa65edce983  jnz 0x00007FA65EBFE110
00007fa65edce989  jmp 0x00007FA65EBFE0A0
00007fa65edce98e  int3
00007fa65edce98f  int3
