00007005ebbce69b  nop [rax+rax*1], eax
00007005ebbce6a0  mov rax, [r15+0xF8]
00007005ebbce6a7  lea r14, [rax-0x20]
00007005ebbce6ab  mov r12, [r15+0xF0]
00007005ebbce6b2  mov [r13+r14*1], r12
00007005ebbce6b7  mov [r15+0xF8], r14
00007005ebbce6be  lea r14, [rax-0x10]
00007005ebbce6c2  mov r12, [r15+0xA0]
00007005ebbce6c9  mov r11, [r15+0x98]
00007005ebbce6d0  mov [r13+r14*1], r12
00007005ebbce6d5  lea r14, [rax-0x08]
00007005ebbce6d9  mov [r13+r14*1], r11
00007005ebbce6de  mov qword ptr [r15+0xA0], 0x00
00007005ebbce6e9  mov qword ptr [r15+0x98], 0x4202A0
00007005ebbce6f4  mov eax, [r15+0xA0]
00007005ebbce6fb  lea r14d, [eax+0x11]
00007005ebbce700  mov r14d, r14d
00007005ebbce703  mov [r15], r14
00007005ebbce706  mov qword ptr [r15+0xF0], 0x410184
00007005ebbce711  mov r14d, [r15+0x320]
00007005ebbce718  mov eax, 0x410184
00007005ebbce71d  mov rcx, 0x7005EBBCE800
00007005ebbce727  mov [r15+r14*8+0x328], rax
00007005ebbce72f  mov [r15+r14*8+0x368], rcx
00007005ebbce737  add r14d, 0x01
00007005ebbce73b  and r14d, 0x07
00007005ebbce73f  mov [r15+0x320], r14d
00007005ebbce746  cmp dword ptr [r15+0x318], 0x00
00007005ebbce74e  jz 0x00007005EBBCE7A0
00007005ebbce754  nop [rax+rax*1], ax
00007005ebbce75d  nop [rax+rax*1], eax
00007005ebbce765  mov eax, 0x41021C
00007005ebbce76a  mov [r15+0x100], rax
00007005ebbce771  jmp 0x00007005EB9FE110
00007005ebbce776  int3
00007005ebbce777  call 0x00007005EBAE2CE0
00007005ebbce77c  jmp 0x00007005EBBCE6B7
00007005ebbce781  call 0x00007005EBAE2CE0
00007005ebbce786  jmp 0x00007005EBBCE6D5
00007005ebbce78b  call 0x00007005EBAE1A60
00007005ebbce790  jmp 0x00007005EBBCE6DE
00007005ebbce795  int3
00007005ebbce796  nop [rax+rax*1], ax
00007005ebbce79f  nop
00007005ebbce7a0  mov eax, 0x846CA68B
00007005ebbce7a5  mov eax, eax
00007005ebbce7a7  mov [r15+0x48], rax
00007005ebbce7ab  mov eax, [r15]
00007005ebbce7ae  imul eax, eax, 0x7FEB352D
00007005ebbce7b4  mov [rsp+0x10], eax
00007005ebbce7b8  shr eax, 0x0F
00007005ebbce7bb  mov r14d, [rsp+0x10]
00007005ebbce7c0  xor r14d, eax
00007005ebbce7c3  imul r14d, r14d, 0x846CA68B
00007005ebbce7ca  mov [rsp+0x10], r14d
00007005ebbce7cf  mov r14d, r14d
00007005ebbce7d2  mov [r15+0x40], r14
00007005ebbce7d6  mov eax, [rsp+0x10]
00007005ebbce7da  shr eax, 0x10
00007005ebbce7dd  mov r14d, [rsp+0x10]
00007005ebbce7e2  xor r14d, eax
00007005ebbce7e5  mov r14d, r14d
00007005ebbce7e8  mov [r15], r14
00007005ebbce7eb  mov rax, [r15+0xF0]
00007005ebbce7f2  mov [r15+0x100], rax
00007005ebbce7f9  jmp 0x00007005EBBCE5C0
00007005ebbce7fe  int3
00007005ebbce7ff  int3
00007005ebbce800  mov rax, [r15+0xA0]
00007005ebbce807  mov [rsp+0x10], rax
00007005ebbce80c  shl rax, 0x02
00007005ebbce810  mov r14, [r15+0x98]
00007005ebbce817  lea r12, [r14+rax*1]
00007005ebbce81b  mov eax, [r15]
00007005ebbce81e  mov [r13+r12*1], eax
00007005ebbce823  mov rax, [rsp+0x10]
00007005ebbce828  lea r14, [rax+0x01]
00007005ebbce82c  mov [r15+0xA0], r14
00007005ebbce833  xor eax, eax
00007005ebbce835  mov r12d, 0x400
00007005ebbce83b  cmp r14, r12
00007005ebbce83e  cmc
00007005ebbce83f  lahf
00007005ebbce840  seto al
00007005ebbce843  mov [r15+0x108], eax
00007005ebbce84a  mov eax, [r15+0x108]
00007005ebbce851  sahf
00007005ebbce852  jnz 0x00007005EBBCE884
00007005ebbce854  cmp dword ptr [r15+0x318], 0x00
00007005ebbce85c  jz 0x00007005EBBCE950
00007005ebbce862  nop [rax+rax*1], ax
00007005ebbce86b  nop [rax+rax*1], eax
00007005ebbce873  mov eax, 0x410194
00007005ebbce878  mov [r15+0x100], rax
00007005ebbce87f  jmp 0x00007005EB9FE110
00007005ebbce884  cmp dword ptr [r15+0x318], 0x00
00007005ebbce88c  jz 0x00007005EBBCE8C0
00007005ebbce892  nop [rax+rax*1], ax
00007005ebbce89b  nop [rax+rax*1], eax
00007005ebbce8a3  mov eax, 0x41017C
00007005ebbce8a8  mov [r15+0x100], rax
00007005ebbce8af  jmp 0x00007005EB9FE110
00007005ebbce8b4  int3
00007005ebbce8b5  call 0x00007005EBAB4B70
00007005ebbce8ba  jmp 0x00007005EBBCE823
00007005ebbce8bf  int3
00007005ebbce8c0  mov eax, [r15+0xA0]
00007005ebbce8c7  lea r14d, [eax+0x11]
00007005ebbce8cc  mov r14d, r14d
00007005ebbce8cf  mov [r15], r14
00007005ebbce8d2  mov qword ptr [r15+0xF0], 0x410184
00007005ebbce8dd  mov r14d, [r15+0x320]
00007005ebbce8e4  mov eax, 0x410184
00007005ebbce8e9  mov rcx, 0x7005EBBCE800
00007005ebbce8f3  mov [r15+r14*8+0x328], rax
00007005ebbce8fb  mov [r15+r14*8+0x368], rcx
00007005ebbce903  add r14d, 0x01
00007005ebbce907  and r14d, 0x07
00007005ebbce90b  mov [r15+0x320], r14d
00007005ebbce912  cmp dword ptr [r15+0x318], 0x00
00007005ebbce91a  jz 0x00007005EBBCE7A0
00007005ebbce920  nop [rax+rax*1], ax
00007005ebbce929  nop [rax+rax*1], eax
00007005ebbce931  mov eax, 0x41021C
00007005ebbce936  mov [r15+0x100], rax
00007005ebbce93d  jmp 0x00007005EB9FE110
00007005ebbce942  int3
00007005ebbce943  int3
00007005ebbce944  nop [rax+rax*1], ax
00007005ebbce94d  nop [rax], eax
00007005ebbce950  mov qword ptr [r15+0x40], 0x01
00007005ebbce958  cmp dword ptr [r15+0x318], 0x00
00007005ebbce960  jz 0x00007005EBBCE990
00007005ebbce966  nop [rax+rax*1], ax
00007005ebbce96f  nop [rax+rax*1], eax
00007005ebbce977  mov eax, 0x4101B0
00007005ebbce97c  mov [r15+0x100], rax
00007005ebbce983  jmp 0x00007005EB9FE110
00007005ebbce988  int3
00007005ebbce989  int3
00007005ebbce98a  nop [rax+rax*1], ax
00007005ebbce990  mov rax, [r15+0x40]
00007005ebbce994  mov [rsp+0x10], rax
00007005ebbce999  shl rax, 0x02
00007005ebbce99d  mov r14, [r15+0x98]
00007005ebbce9a4  lea r12, [r14+rax*1]
00007005ebbce9a8  mov eax, [r13+r12*1]
00007005ebbce9ad  mov [rsp+0x20], eax
00007005ebbce9b1  mov eax, eax
00007005ebbce9b3  mov [r15+0x48], rax
00007005ebbce9b7  mov rax, [rsp+0x10]
00007005ebbce9bc  mov [r15+0x50], rax
00007005ebbce9c0  mov eax, [r15+0x50]
00007005ebbce9c4  lea r12d, [eax-0x01]
00007005ebbce9c9  mov r12d, r12d
00007005ebbce9cc  mov [r15+0x58], r12
00007005ebbce9d0  mov rax, [r15+0x58]
00007005ebbce9d4  mov r12d, eax
00007005ebbce9d7  mov r12d, r12d
00007005ebbce9da  shl r12, 0x02
00007005ebbce9de  lea rax, [r14+r12*1]
00007005ebbce9e2  mov r14d, [r13+rax*1]
00007005ebbce9e7  mov [rsp+0x10], r14d
00007005ebbce9ec  mov r14d, r14d
00007005ebbce9ef  mov [r15+0x60], r14
00007005ebbce9f3  xor eax, eax
00007005ebbce9f5  mov r14d, [rsp+0x10]
00007005ebbce9fa  mov r12d, [rsp+0x20]
00007005ebbce9ff  cmp r14d, r12d
00007005ebbcea02  cmc
00007005ebbcea03  lahf
00007005ebbcea04  seto al
00007005ebbcea07  mov [r15+0x108], eax
00007005ebbcea0e  mov eax, [r15+0x108]
00007005ebbcea15  sahf
00007005ebbcea16  cmc
00007005ebbcea17  jbe 0x00007005EBBCEA49
00007005ebbcea19  cmp dword ptr [r15+0x318], 0x00
00007005ebbcea21  jz 0x00007005EBBCEA90
00007005ebbcea27  nop [rax+rax*1], ax
00007005ebbcea30  nop [rax+rax*1], eax
00007005ebbcea38  mov eax, 0x4101C8
00007005ebbcea3d  mov [r15+0x100], rax
00007005ebbcea44  jmp 0x00007005EB9FE110
00007005ebbcea49  cmp dword ptr [r15+0x318], 0x00
00007005ebbcea51  jz 0x00007005EBBCED30
00007005ebbcea57  nop [rax+rax*1], ax
00007005ebbcea60  nop [rax+rax*1], eax
00007005ebbcea68  mov eax, 0x4101A0
00007005ebbcea6d  mov [r15+0x100], rax
00007005ebbcea74  jmp 0x00007005EB9FE110
00007005ebbcea79  int3
00007005ebbcea7a  call 0x00007005EBAB4690
00007005ebbcea7f  jmp 0x00007005EBBCE9AD
00007005ebbcea84  call 0x00007005EBA0DAE0
00007005ebbcea89  jmp 0x00007005EBBCE9E7
00007005ebbcea8e  int3
00007005ebbcea8f  nop
00007005ebbcea90  mov rax, [r15+0x50]
00007005ebbcea94  mov [rsp+0x10], rax
00007005ebbcea99  shl rax, 0x02
00007005ebbcea9d  mov r14, [r15+0x98]
00007005ebbceaa4  lea r12, [r14+rax*1]
00007005ebbceaa8  mov eax, [r15+0x60]
00007005ebbceaac  mov [r13+r12*1], eax
00007005ebbceab1  mov rax, [rsp+0x10]
00007005ebbceab6  lea r14, [rax-0x01]
00007005ebbceaba  mov [r15+0x50], r14
00007005ebbceabe  mov rax, [r15+0x58]
00007005ebbceac2  test rax, rax
00007005ebbceac5  setz al
00007005ebbceac8  movzx rax, al
00007005ebbceacc  mov [rsp+0x414], al
00007005ebbcead3  cmp byte ptr [rsp+0x414], 0x00
00007005ebbceadb  jz 0x00007005EBBCEB0D
00007005ebbceadd  cmp dword ptr [r15+0x318], 0x00
00007005ebbceae5  jz 0x00007005EBBCEB50
00007005ebbceaeb  nop [rax+rax*1], ax
00007005ebbceaf4  nop [rax+rax*1], eax
00007005ebbceafc  mov eax, 0x4101D4
00007005ebbceb01  mov [r15+0x100], rax
00007005ebbceb08  jmp 0x00007005EB9FE110
00007005ebbceb0d  cmp dword ptr [r15+0x318], 0x00
00007005ebbceb15  jz 0x00007005EBBCEC50
00007005ebbceb1b  nop [rax+rax*1], ax
00007005ebbceb24  nop [rax+rax*1], eax
00007005ebbceb2c  mov eax, 0x4101B8
00007005ebbceb31  mov [r15+0x100], rax
00007005ebbceb38  jmp 0x00007005EB9FE110
00007005ebbceb3d  int3
00007005ebbceb3e  call 0x00007005EBAB4B70
00007005ebbceb43  jmp 0x00007005EBBCEAB1
00007005ebbceb48  int3
00007005ebbceb49  nop [rax], eax
00007005ebbceb50  cmp dword ptr [r15+0x318], 0x00
00007005ebbceb58  jz 0x00007005EBBCEB90
00007005ebbceb5e  nop [rax+rax*1], ax
00007005ebbceb67  nop [rax+rax*1], eax
00007005ebbceb6f  mov eax, 0x41019C
00007005ebbceb74  mov [r15+0x100], rax
00007005ebbceb7b  jmp 0x00007005EB9FE110
00007005ebbceb80  int3
00007005ebbceb81  int3
00007005ebbceb82  nop [rax+rax*1], ax
00007005ebbceb8b  nop [rax+rax*1], eax
00007005ebbceb90  mov qword ptr [r15+0x50], 0x00
00007005ebbceb98  mov rax, [r15+0x40]
00007005ebbceb9c  lea r14, [rax+0x01]
00007005ebbceba0  mov [r15+0x40], r14
00007005ebbceba4  mov rax, [r15+0x98]
00007005ebbcebab  mov r12d, [r15+0x48]
00007005ebbcebaf  mov [r13+rax*1], r12d
00007005ebbcebb4  xor eax, eax
00007005ebbcebb6  mov r12d, 0x400
00007005ebbcebbc  cmp r14, r12
00007005ebbcebbf  cmc
00007005ebbcebc0  lahf
00007005ebbcebc1  seto al
00007005ebbcebc4  mov [r15+0x108], eax
00007005ebbcebcb  mov eax, [r15+0x108]
00007005ebbcebd2  sahf
00007005ebbcebd3  jz 0x00007005EBBCEC05
00007005ebbcebd5  cmp dword ptr [r15+0x318], 0x00
00007005ebbcebdd  jz 0x00007005EBBCE990
00007005ebbcebe3  nop [rax+rax*1], ax
00007005ebbcebec  nop [rax+rax*1], eax
00007005ebbcebf4  mov eax, 0x4101B0
00007005ebbcebf9  mov [r15+0x100], rax
00007005ebbcec00  jmp 0x00007005EB9FE110
00007005ebbcec05  cmp dword ptr [r15+0x318], 0x00
00007005ebbcec0d  jz 0x00007005EBBCEDF0
00007005ebbcec13  nop [rax+rax*1], ax
00007005ebbcec1c  nop [rax+rax*1], eax
00007005ebbcec24  mov eax, 0x4101D8
00007005ebbcec29  mov [r15+0x100], rax
00007005ebbcec30  jmp 0x00007005EB9FE110
00007005ebbcec35  int3
00007005ebbcec36  call 0x00007005EBA0BAE0
00007005ebbcec3b  jmp 0x00007005EBBCEBB4
00007005ebbcec40  int3
00007005ebbcec41  nop [rax+rax*1], ax
00007005ebbcec4a  nop [rax+rax*1], ax
00007005ebbcec50  mov eax, [r15+0x50]
00007005ebbcec54  lea r14d, [eax-0x01]
00007005ebbcec59  mov r14d, r14d
00007005ebbcec5c  mov [r15+0x58], r14
00007005ebbcec60  mov rax, [r15+0x58]
00007005ebbcec64  mov r14d, eax
00007005ebbcec67  mov r14d, r14d
00007005ebbcec6a  shl r14, 0x02
00007005ebbcec6e  mov rax, [r15+0x98]
00007005ebbcec75  lea r12, [rax+r14*1]
00007005ebbcec79  mov eax, [r13+r12*1]
00007005ebbcec7e  mov [rsp+0x10], eax
00007005ebbcec82  mov eax, eax
00007005ebbcec84  mov [r15+0x60], rax
00007005ebbcec88  mov eax, [r15+0x48]
00007005ebbcec8c  mov [rsp+0x20], eax
00007005ebbcec90  xor eax, eax
00007005ebbcec92  mov r14d, [rsp+0x10]
00007005ebbcec97  mov r12d, [rsp+0x20]
00007005ebbcec9c  cmp r14d, r12d
00007005ebbcec9f  cmc
00007005ebbceca0  lahf
00007005ebbceca1  seto al
00007005ebbceca4  mov [r15+0x108], eax
00007005ebbcecab  mov eax, [r15+0x108]
00007005ebbcecb2  sahf
00007005ebbcecb3  cmc
00007005ebbcecb4  jbe 0x00007005EBBCECE6
00007005ebbcecb6  cmp dword ptr [r15+0x318], 0x00
00007005ebbcecbe  jz 0x00007005EBBCEA90
00007005ebbcecc4  nop [rax+rax*1], ax
00007005ebbceccd  nop [rax+rax*1], eax
00007005ebbcecd5  mov eax, 0x4101C8
00007005ebbcecda  mov [r15+0x100], rax
00007005ebbcece1  jmp 0x00007005EB9FE110
00007005ebbcece6  cmp dword ptr [r15+0x318], 0x00
00007005ebbcecee  jz 0x00007005EBBCED30
00007005ebbcecf4  nop [rax+rax*1], ax
00007005ebbcecfd  nop [rax+rax*1], eax
00007005ebbced05  mov eax, 0x4101A0
00007005ebbced0a  mov [r15+0x100], rax
00007005ebbced11  jmp 0x00007005EB9FE110
00007005ebbced16  int3
00007005ebbced17  call 0x00007005EBAB4690
00007005ebbced1c  jmp 0x00007005EBBCEC7E
00007005ebbced21  int3
00007005ebbced22  nop [rax+rax*1], ax
00007005ebbced2b  nop [rax+rax*1], eax
00007005ebbced30  mov rax, [r15+0x40]
00007005ebbced34  lea r14, [rax+0x01]
00007005ebbced38  mov [r15+0x40], r14
00007005ebbced3c  mov rax, [r15+0x50]
00007005ebbced40  mov r12d, eax
00007005ebbced43  mov r12d, r12d
00007005ebbced46  shl r12, 0x02
00007005ebbced4a  mov rax, [r15+0x98]
00007005ebbced51  lea r11, [rax+r12*1]
00007005ebbced55  mov eax, [r15+0x48]
00007005ebbced59  mov [r13+r11*1], eax
00007005ebbced5e  xor eax, eax
00007005ebbced60  mov r12d, 0x400
00007005ebbced66  cmp r14, r12
00007005ebbced69  cmc
00007005ebbced6a  lahf
00007005ebbced6b  seto al
00007005ebbced6e  mov [r15+0x108], eax
00007005ebbced75  mov eax, [r15+0x108]
00007005ebbced7c  sahf
00007005ebbced7d  jz 0x00007005EBBCEDAF
00007005ebbced7f  cmp dword ptr [r15+0x318], 0x00
00007005ebbced87  jz 0x00007005EBBCE990
00007005ebbced8d  nop [rax+rax*1], ax
00007005ebbced96  nop [rax+rax*1], eax
00007005ebbced9e  mov eax, 0x4101B0
00007005ebbceda3  mov [r15+0x100], rax
00007005ebbcedaa  jmp 0x00007005EB9FE110
00007005ebbcedaf  cmp dword ptr [r15+0x318], 0x00
00007005ebbcedb7  jz 0x00007005EBBCEDF0
00007005ebbcedbd  nop [rax+rax*1], ax
00007005ebbcedc6  nop [rax+rax*1], eax
00007005ebbcedce  mov eax, 0x4101D8
00007005ebbcedd3  mov [r15+0x100], rax
00007005ebbcedda  jmp 0x00007005EB9FE110
00007005ebbceddf  int3
00007005ebbcede0  call 0x00007005EBAA4270
00007005ebbcede5  jmp 0x00007005EBBCED5E
00007005ebbcedea  int3
00007005ebbcedeb  nop [rax+rax*1], eax
00007005ebbcedf0  mov qword ptr [r15+0x40], 0x420000
00007005ebbcedf8  mov eax, 0x420288
00007005ebbcedfd  mov r14, [r13+rax*1]
00007005ebbcee02  mov rax, [r15+0x98]
00007005ebbcee09  mov r12d, [r13+rax*1]
00007005ebbcee0e  lea r11, [rax+0x04]
00007005ebbcee12  mov eax, [r13+r11*1]
00007005ebbcee17  mov r12d, r12d
00007005ebbcee1a  mov [r15+0x68], r12
00007005ebbcee1e  mov eax, eax
00007005ebbcee20  mov [r15+0x60], rax
00007005ebbcee24  mov rax, [r15+0x68]
00007005ebbcee28  mov [r15+0x68], rax
00007005ebbcee2c  mov qword ptr [r15+0x58], 0x02
00007005ebbcee34  mov [rsp+0x10], rax
00007005ebbcee39  xor eax, eax
00007005ebbcee3b  mov r12d, 0x02
00007005ebbcee41  mov r11d, 0x400
00007005ebbcee47  cmp r12, r11
00007005ebbcee4a  cmc
00007005ebbcee4b  lahf
00007005ebbcee4c  seto al
00007005ebbcee4f  mov [r15+0x108], eax
00007005ebbcee56  mov rax, [r15+0x60]
00007005ebbcee5a  mov r12d, 0x02
00007005ebbcee60  imul rax, r12
00007005ebbcee64  mov [r15+0x50], rax
00007005ebbcee68  mov rax, [rsp+0x10]
00007005ebbcee6d  lea r12, [rax+r14*1]
00007005ebbcee71  mov [r15+0x48], r12
00007005ebbcee75  mov eax, [r15+0x108]
00007005ebbcee7c  sahf
00007005ebbcee7d  jnz 0x00007005EBBCEEAF
00007005ebbcee7f  cmp dword ptr [r15+0x318], 0x00
00007005ebbcee87  jz 0x00007005EBBCF020
00007005ebbcee8d  nop [rax+rax*1], ax
00007005ebbcee96  nop [rax+rax*1], eax
00007005ebbcee9e  mov eax, 0x410208
00007005ebbceea3  mov [r15+0x100], rax
00007005ebbceeaa  jmp 0x00007005EB9FE110
00007005ebbceeaf  cmp dword ptr [r15+0x318], 0x00
00007005ebbceeb7  jz 0x00007005EBBCEF00
00007005ebbceebd  nop [rax+rax*1], ax
00007005ebbceec6  nop [rax+rax*1], eax
00007005ebbceece  mov eax, 0x4101E8
00007005ebbceed3  mov [r15+0x100], rax
00007005ebbceeda  jmp 0x00007005EB9FE110
00007005ebbceedf  int3
00007005ebbceee0  call 0x00007005EBA0DC20
00007005ebbceee5  jmp 0x00007005EBBCEE02
00007005ebbceeea  call 0x00007005EBA0B5E0
00007005ebbceeef  jmp 0x00007005EBBCEE0E
00007005ebbceef4  call 0x00007005EBAA3D90
00007005ebbceef9  jmp 0x00007005EBBCEE17
00007005ebbceefe  int3
00007005ebbceeff  nop
00007005ebbcef00  mov rax, [r15+0x98]
00007005ebbcef07  mov r14, [r15+0x58]
00007005ebbcef0b  mov [rsp+0x10], r14
00007005ebbcef10  shl r14, 0x02
00007005ebbcef14  lea r12, [rax+r14*1]
00007005ebbcef18  mov eax, [r13+r12*1]
00007005ebbcef1d  lea r14, [r12+0x04]
00007005ebbcef22  mov r12d, [r13+r14*1]
00007005ebbcef27  mov eax, eax
00007005ebbcef29  mov [r15+0x68], rax
00007005ebbcef2d  mov r12d, r12d
00007005ebbcef30  mov [r15+0x60], r12
00007005ebbcef34  mov rax, [r15+0x68]
00007005ebbcef38  mov [rsp+0x20], rax
00007005ebbcef3d  mov r14, [rsp+0x10]
00007005ebbcef42  imul rax, r14
00007005ebbcef46  mov r12, [rsp+0x20]
00007005ebbcef4b  lea r11, [r12+rax*1]
00007005ebbcef4f  mov [r15+0x68], r11
00007005ebbcef53  lea rax, [r14+0x02]
00007005ebbcef57  mov [r15+0x58], rax
00007005ebbcef5b  mov [rsp+0x10], rax
00007005ebbcef60  xor eax, eax
00007005ebbcef62  mov r14, [rsp+0x10]
00007005ebbcef67  mov r12d, 0x400
00007005ebbcef6d  cmp r14, r12
00007005ebbcef70  cmc
00007005ebbcef71  lahf
00007005ebbcef72  seto al
00007005ebbcef75  mov [r15+0x108], eax
00007005ebbcef7c  mov rax, [r15+0x50]
00007005ebbcef80  mov r12, [r15+0x60]
00007005ebbcef84  imul r14, r12
00007005ebbcef88  lea r12, [rax+r14*1]
00007005ebbcef8c  mov [r15+0x50], r12
00007005ebbcef90  mov rax, [r15+0x48]
00007005ebbcef94  lea r14, [r11+rax*1]
00007005ebbcef98  mov [r15+0x48], r14
00007005ebbcef9c  mov eax, [r15+0x108]
00007005ebbcefa3  sahf
00007005ebbcefa4  jnz 0x00007005EBBCEFD6
00007005ebbcefa6  cmp dword ptr [r15+0x318], 0x00
00007005ebbcefae  jz 0x00007005EBBCF020
00007005ebbcefb4  nop [rax+rax*1], ax
00007005ebbcefbd  nop [rax+rax*1], eax
00007005ebbcefc5  mov eax, 0x410208
00007005ebbcefca  mov [r15+0x100], rax
00007005ebbcefd1  jmp 0x00007005EB9FE110
00007005ebbcefd6  cmp dword ptr [r15+0x318], 0x00
00007005ebbcefde  jz 0x00007005EBBCEF00
00007005ebbcefe4  nop [rax+rax*1], ax
00007005ebbcefed  nop [rax+rax*1], eax
00007005ebbceff5  mov eax, 0x4101E8
00007005ebbceffa  mov [r15+0x100], rax
00007005ebbcf001  jmp 0x00007005EB9FE110
00007005ebbcf006  int3
00007005ebbcf007  call 0x00007005EBAB4690
00007005ebbcf00c  jmp 0x00007005EBBCEF1D
00007005ebbcf011  call 0x00007005EBAE26A0
00007005ebbcf016  jmp 0x00007005EBBCEF27
00007005ebbcf01b  int3
00007005ebbcf01c  nop [rax], eax
00007005ebbcf020  mov rax, [r15+0xF8]
00007005ebbcf027  lea r14, [rax+0x10]
00007005ebbcf02b  mov r12, [r13+r14*1]
00007005ebbcf030  lea r14, [rax+0x18]
00007005ebbcf034  mov r11, [r13+r14*1]
00007005ebbcf039  mov [r15+0xA0], r12
00007005ebbcf040  mov [r15+0x98], r11
00007005ebbcf047  mov r14, [r15+0x50]
00007005ebbcf04b  mov r12, [r15+0x48]
00007005ebbcf04f  lea r11, [r14+r12*1]
00007005ebbcf053  mov [r15+0x48], r11
00007005ebbcf057  mov r14, [r15+0x40]
00007005ebbcf05b  lea r12, [r14+0x288]
00007005ebbcf062  mov [r13+r12*1], r11
00007005ebbcf067  mov r14, [r13+rax*1]
00007005ebbcf06c  mov [r15+0xF0], r14
00007005ebbcf073  lea r12, [rax+0x20]
00007005ebbcf077  mov [r15+0xF8], r12
00007005ebbcf07e  mov [r15+0x100], r14
00007005ebbcf085  jmp 0x00007005EBBCE5C0
00007005ebbcf08a  int3
00007005ebbcf08b  call 0x00007005EBAE27E0
00007005ebbcf090  jmp 0x00007005EBBCF030
00007005ebbcf095  call 0x00007005EBAE1570
00007005ebbcf09a  jmp 0x00007005EBBCF039
00007005ebbcf09f  call 0x00007005EBAC0860
00007005ebbcf0a4  jmp 0x00007005EBBCF067
00007005ebbcf0a9  call 0x00007005EBA0DC20
00007005ebbcf0ae  jmp 0x00007005EBBCF06C
00007005ebbcf0b3  int3
00007005ebbcf0b4  nop [rax+rax*1], ax
00007005ebbcf0bd  nop [rax], eax
00007005ebbcf0c0  mov qword ptr [r15+0x100], 0x04
00007005ebbcf0cb  mov esi, 0x00
00007005ebbcf0d0  mov edx, 0x09
00007005ebbcf0d5  mov rdi, 0x7FFF21EF2840
00007005ebbcf0df  mov rax, 0x638C77F6F970
00007005ebbcf0e9  call rax
00007005ebbcf0eb  cmp dword ptr [r15+0x318], 0x00
00007005ebbcf0f3  jnz 0x00007005EB9FE110
00007005ebbcf0f9  jmp 0x00007005EB9FE0A0
00007005ebbcf0fe  int3
00007005ebbcf0ff  int3
