0000782edbbce69b  nop [rax+rax*1], eax
0000782edbbce6a0  mov rax, [r15+0xF8]
0000782edbbce6a7  lea r14, [rax-0xA0]
0000782edbbce6ae  mov [r15+0xF8], r14
0000782edbbce6b5  lea rax, [r14+0x90]
0000782edbbce6bc  mov r12, [r15+0xA0]
0000782edbbce6c3  mov r11, [r15+0x98]
0000782edbbce6ca  mov [r13+rax*1], r12
0000782edbbce6cf  lea rax, [r14+0x98]
0000782edbbce6d6  mov [r13+rax*1], r11
0000782edbbce6db  mov eax, 0x420670
0000782edbbce6e0  movups xmm1, [r13+rax*1]
0000782edbbce6e6  mov eax, 0x420610
0000782edbbce6eb  movups xmm15, [r13+rax*1]
0000782edbbce6f1  mov eax, 0x420690
0000782edbbce6f6  movups xmm14, [r13+rax*1]
0000782edbbce6fc  mov eax, 0x420630
0000782edbbce701  movups xmm13, [r13+rax*1]
0000782edbbce707  mov qword ptr [r15+0x98], 0x4308A0
0000782edbbce712  mov eax, 0x4206A0
0000782edbbce717  movups xmm12, [r13+rax*1]
0000782edbbce71d  mov eax, 0x4308A0
0000782edbbce722  movups [r13+rax*1], xmm1
0000782edbbce728  mov eax, 0x4308B0
0000782edbbce72d  movups [r13+rax*1], xmm15
0000782edbbce733  mov eax, 0x4308C0
0000782edbbce738  movups [r13+rax*1], xmm14
0000782edbbce73e  mov eax, 0x4308D0
0000782edbbce743  movups [r13+rax*1], xmm13
0000782edbbce749  mov eax, 0x420600
0000782edbbce74e  movups xmm14, [r13+rax*1]
0000782edbbce754  mov eax, 0x4205F0
0000782edbbce759  movups xmm13, [r13+rax*1]
0000782edbbce75f  mov eax, 0x4309A0
0000782edbbce764  movups [r13+rax*1], xmm1
0000782edbbce76a  mov eax, 0x4309B0
0000782edbbce76f  movups [r13+rax*1], xmm15
0000782edbbce775  mov eax, 0x4308E0
0000782edbbce77a  movups [r13+rax*1], xmm12
0000782edbbce780  mov eax, 0x4308F0
0000782edbbce785  movups [r13+rax*1], xmm14
0000782edbbce78b  mov eax, 0x4205E0
0000782edbbce790  movups xmm1, [r13+rax*1]
0000782edbbce796  mov eax, 0x420640
0000782edbbce79b  movups xmm15, [r13+rax*1]
0000782edbbce7a1  mov eax, 0x430900
0000782edbbce7a6  movups [r13+rax*1], xmm13
0000782edbbce7ac  mov eax, 0x430910
0000782edbbce7b1  movups [r13+rax*1], xmm1
0000782edbbce7b7  mov eax, 0x420650
0000782edbbce7bc  movups xmm1, [r13+rax*1]
0000782edbbce7c2  mov eax, 0x420620
0000782edbbce7c7  movups xmm14, [r13+rax*1]
0000782edbbce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
0000782edbbce7d5  mov eax, 0x430920
0000782edbbce7da  movups [r13+rax*1], xmm15
0000782edbbce7e0  mov eax, 0x430930
0000782edbbce7e5  movups [r13+rax*1], xmm1
0000782edbbce7eb  mov eax, 0x4206C0
0000782edbbce7f0  movups xmm1, [r13+rax*1]
0000782edbbce7f6  mov eax, 0x4206D0
0000782edbbce7fb  movups xmm15, [r13+rax*1]
0000782edbbce801  movaps [r15+0x150], xmm15
0000782edbbce809  mov qword ptr [r15+0xA0], 0x3E8
0000782edbbce814  mov eax, 0x430940
0000782edbbce819  movups [r13+rax*1], xmm14
0000782edbbce81f  mov eax, 0x430950
0000782edbbce824  movups [r13+rax*1], xmm1
0000782edbbce82a  mov eax, 0x4206B0
0000782edbbce82f  movups xmm1, [r13+rax*1]
0000782edbbce835  mov eax, 0x420660
0000782edbbce83a  movups xmm14, [r13+rax*1]
0000782edbbce840  movaps [r15+0x140], xmm14
0000782edbbce848  lea rax, [r14+0x80]
0000782edbbce84f  mov r12, [r15+0xF0]
0000782edbbce856  mov [r13+rax*1], r12
0000782edbbce85b  mov eax, 0x430960
0000782edbbce860  movups [r13+rax*1], xmm15
0000782edbbce866  mov eax, 0x430970
0000782edbbce86b  movups [r13+rax*1], xmm1
0000782edbbce871  mov eax, 0x420680
0000782edbbce876  movups xmm1, [r13+rax*1]
0000782edbbce87c  mov eax, 0x4206E0
0000782edbbce881  mov r12, [r13+rax*1]
0000782edbbce886  movq xmm15, r12
0000782edbbce88b  mov qword ptr [r15+0x40], 0x4206E8
0000782edbbce893  mov eax, 0x430980
0000782edbbce898  movups [r13+rax*1], xmm14
0000782edbbce89e  mov eax, 0x430990
0000782edbbce8a3  movups [r13+rax*1], xmm1
0000782edbbce8a9  mov eax, 0x420748
0000782edbbce8ae  movups xmm1, [r13+rax*1]
0000782edbbce8b4  movq rax, xmm15
0000782edbbce8b9  mov r12d, 0x4309C0
0000782edbbce8bf  mov [r13+r12*1], rax
0000782edbbce8c4  mov eax, 0x420728
0000782edbbce8c9  movups xmm15, [r13+rax*1]
0000782edbbce8cf  mov eax, 0x420738
0000782edbbce8d4  movups xmm14, [r13+rax*1]
0000782edbbce8da  lea rax, [r14+0x60]
0000782edbbce8de  movups [r13+rax*1], xmm1
0000782edbbce8e4  mov eax, 0x4309C8
0000782edbbce8e9  mov r12d, 0x421DF8D3
0000782edbbce8ef  mov [r13+rax*1], r12d
0000782edbbce8f4  lea rax, [r14+0x40]
0000782edbbce8f8  movups [r13+rax*1], xmm15
0000782edbbce8fe  lea rax, [r14+0x50]
0000782edbbce902  movups [r13+rax*1], xmm14
0000782edbbce908  mov eax, 0x4206E8
0000782edbbce90d  movups xmm1, [r13+rax*1]
0000782edbbce913  mov eax, 0x4206F8
0000782edbbce918  movups xmm15, [r13+rax*1]
0000782edbbce91e  movaps [r15+0x120], xmm15
0000782edbbce926  movups [r13+r14*1], xmm1
0000782edbbce92c  lea rax, [r14+0x10]
0000782edbbce930  movups [r13+rax*1], xmm15
0000782edbbce936  mov eax, 0x420708
0000782edbbce93b  movups xmm1, [r13+rax*1]
0000782edbbce941  mov eax, 0x420718
0000782edbbce946  movups xmm15, [r13+rax*1]
0000782edbbce94c  movaps [r15+0x110], xmm1
0000782edbbce954  movaps [r15+0x130], xmm15
0000782edbbce95c  lea rax, [r14+0x20]
0000782edbbce960  movups [r13+rax*1], xmm1
0000782edbbce966  lea rax, [r14+0x30]
0000782edbbce96a  movups [r13+rax*1], xmm15
0000782edbbce970  mov [r15], r14
0000782edbbce973  mov qword ptr [r15+0x08], 0x4308A0
0000782edbbce97b  mov qword ptr [r15+0x10], 0x12C
0000782edbbce983  mov qword ptr [r15+0xF0], 0x410274
0000782edbbce98e  mov r14d, [r15+0x320]
0000782edbbce995  mov eax, 0x410274
0000782edbbce99a  mov rcx, 0x782EDBBD0670
0000782edbbce9a4  mov [r15+r14*8+0x328], rax
0000782edbbce9ac  mov [r15+r14*8+0x368], rcx
0000782edbbce9b4  add r14d, 0x01
0000782edbbce9b8  and r14d, 0x07
0000782edbbce9bc  mov [r15+0x320], r14d
0000782edbbce9c3  cmp dword ptr [r15+0x318], 0x00
0000782edbbce9cb  jz 0x0000782EDBBCEC20
0000782edbbce9d1  nop [rax+rax*1], ax
0000782edbbce9da  nop [rax+rax*1], eax
0000782edbbce9e2  mov eax, 0x410338
0000782edbbce9e7  mov [r15+0x100], rax
0000782edbbce9ee  jmp 0x0000782EDB9FE110
0000782edbbce9f3  int3
0000782edbbce9f4  call 0x0000782EDBA0BC20
0000782edbbce9f9  jmp 0x0000782EDBBCE6CF
0000782edbbce9fe  call 0x0000782EDBA0A9A0
0000782edbbcea03  jmp 0x0000782EDBBCE6DB
0000782edbbcea08  call 0x0000782EDB9FF430
0000782edbbcea0d  jmp 0x0000782EDBBCE6E6
0000782edbbcea12  call 0x0000782EDBA0E760
0000782edbbcea17  jmp 0x0000782EDBBCE6F1
0000782edbbcea1c  call 0x0000782EDBA0D4E0
0000782edbbcea21  jmp 0x0000782EDBBCE6FC
0000782edbbcea26  call 0x0000782EDBA0C260
0000782edbbcea2b  jmp 0x0000782EDBBCE707
0000782edbbcea30  call 0x0000782EDBA0AFE0
0000782edbbcea35  jmp 0x0000782EDBBCE71D
0000782edbbcea3a  call 0x0000782EDB9FF540
0000782edbbcea3f  jmp 0x0000782EDBBCE728
0000782edbbcea44  call 0x0000782EDBA0E880
0000782edbbcea49  jmp 0x0000782EDBBCE733
0000782edbbcea4e  call 0x0000782EDBA0D600
0000782edbbcea53  jmp 0x0000782EDBBCE73E
0000782edbbcea58  call 0x0000782EDBA0C380
0000782edbbcea5d  jmp 0x0000782EDBBCE749
0000782edbbcea62  call 0x0000782EDBA0D4E0
0000782edbbcea67  jmp 0x0000782EDBBCE754
0000782edbbcea6c  call 0x0000782EDBA0C260
0000782edbbcea71  jmp 0x0000782EDBBCE75F
0000782edbbcea76  call 0x0000782EDB9FF540
0000782edbbcea7b  jmp 0x0000782EDBBCE76A
0000782edbbcea80  call 0x0000782EDBA0E880
0000782edbbcea85  jmp 0x0000782EDBBCE775
0000782edbbcea8a  call 0x0000782EDBA0B100
0000782edbbcea8f  jmp 0x0000782EDBBCE780
0000782edbbcea94  call 0x0000782EDBA0D600
0000782edbbcea99  jmp 0x0000782EDBBCE78B
0000782edbbcea9e  call 0x0000782EDB9FF430
0000782edbbceaa3  jmp 0x0000782EDBBCE796
0000782edbbceaa8  call 0x0000782EDBA0E760
0000782edbbceaad  jmp 0x0000782EDBBCE7A1
0000782edbbceab2  call 0x0000782EDBA0C380
0000782edbbceab7  jmp 0x0000782EDBBCE7AC
0000782edbbceabc  call 0x0000782EDB9FF540
0000782edbbceac1  jmp 0x0000782EDBBCE7B7
0000782edbbceac6  call 0x0000782EDB9FF430
0000782edbbceacb  jmp 0x0000782EDBBCE7C2
0000782edbbcead0  call 0x0000782EDBA0D4E0
0000782edbbcead5  jmp 0x0000782EDBBCE7CD
0000782edbbceada  call 0x0000782EDBA0E880
0000782edbbceadf  jmp 0x0000782EDBBCE7E0
0000782edbbceae4  call 0x0000782EDB9FF540
0000782edbbceae9  jmp 0x0000782EDBBCE7EB
0000782edbbceaee  call 0x0000782EDB9FF430
0000782edbbceaf3  jmp 0x0000782EDBBCE7F6
0000782edbbceaf8  call 0x0000782EDBA0E760
0000782edbbceafd  jmp 0x0000782EDBBCE801
0000782edbbceb02  call 0x0000782EDBA0D600
0000782edbbceb07  jmp 0x0000782EDBBCE81F
0000782edbbceb0c  call 0x0000782EDB9FF540
0000782edbbceb11  jmp 0x0000782EDBBCE82A
0000782edbbceb16  call 0x0000782EDB9FF430
0000782edbbceb1b  jmp 0x0000782EDBBCE835
0000782edbbceb20  call 0x0000782EDBA0D4E0
0000782edbbceb25  jmp 0x0000782EDBBCE840
0000782edbbceb2a  call 0x0000782EDBA0BC20
0000782edbbceb2f  jmp 0x0000782EDBBCE85B
0000782edbbceb34  call 0x0000782EDBA0E880
0000782edbbceb39  jmp 0x0000782EDBBCE866
0000782edbbceb3e  call 0x0000782EDB9FF540
0000782edbbceb43  jmp 0x0000782EDBBCE871
0000782edbbceb48  call 0x0000782EDB9FF430
0000782edbbceb4d  jmp 0x0000782EDBBCE87C
0000782edbbceb52  call 0x0000782EDBA0B720
0000782edbbceb57  jmp 0x0000782EDBBCE886
0000782edbbceb5c  call 0x0000782EDBA0D600
0000782edbbceb61  jmp 0x0000782EDBBCE89E
0000782edbbceb66  call 0x0000782EDB9FF540
0000782edbbceb6b  jmp 0x0000782EDBBCE8A9
0000782edbbceb70  call 0x0000782EDB9FF430
0000782edbbceb75  jmp 0x0000782EDBBCE8B4
0000782edbbceb7a  call 0x0000782EDBAB4CB0
0000782edbbceb7f  jmp 0x0000782EDBBCE8C4
0000782edbbceb84  call 0x0000782EDBA0E760
0000782edbbceb89  jmp 0x0000782EDBBCE8CF
0000782edbbceb8e  call 0x0000782EDBA0D4E0
0000782edbbceb93  jmp 0x0000782EDBBCE8DA
0000782edbbceb98  call 0x0000782EDB9FF540
0000782edbbceb9d  jmp 0x0000782EDBBCE8E4
0000782edbbceba2  call 0x0000782EDBA0BAE0
0000782edbbceba7  jmp 0x0000782EDBBCE8F4
0000782edbbcebac  call 0x0000782EDBA0E880
0000782edbbcebb1  jmp 0x0000782EDBBCE8FE
0000782edbbcebb6  call 0x0000782EDBA0D600
0000782edbbcebbb  jmp 0x0000782EDBBCE908
0000782edbbcebc0  call 0x0000782EDB9FF430
0000782edbbcebc5  jmp 0x0000782EDBBCE913
0000782edbbcebca  call 0x0000782EDBA0E760
0000782edbbcebcf  jmp 0x0000782EDBBCE91E
0000782edbbcebd4  call 0x0000782EDBAD6600
0000782edbbcebd9  jmp 0x0000782EDBBCE92C
0000782edbbcebde  call 0x0000782EDBA0E880
0000782edbbcebe3  jmp 0x0000782EDBBCE936
0000782edbbcebe8  call 0x0000782EDB9FF430
0000782edbbcebed  jmp 0x0000782EDBBCE941
0000782edbbcebf2  call 0x0000782EDBA0E760
0000782edbbcebf7  jmp 0x0000782EDBBCE94C
0000782edbbcebfc  call 0x0000782EDB9FF540
0000782edbbcec01  jmp 0x0000782EDBBCE966
0000782edbbcec06  call 0x0000782EDBA0E880
0000782edbbcec0b  jmp 0x0000782EDBBCE970
0000782edbbcec10  int3
0000782edbbcec11  nop [rax+rax*1], ax
0000782edbbcec1a  nop [rax+rax*1], ax
0000782edbbcec20  mov rax, [r15]
0000782edbbcec23  lea r14, [rax+0x20]
0000782edbbcec27  mov r12, [r13+r14*1]
0000782edbbcec2c  mov r14, [r15+0x10]
0000782edbbcec30  lea r11, [r12+r14*1]
0000782edbbcec34  mov [r15+0x40], r11
0000782edbbcec38  lea r12, [rax+0x20]
0000782edbbcec3c  mov [r13+r12*1], r11
0000782edbbcec41  test r14, r14
0000782edbbcec44  setz r14b
0000782edbbcec48  movzx r14, r14b
0000782edbbcec4c  mov [rsp+0x414], r14b
0000782edbbcec54  cmp byte ptr [rsp+0x414], 0x00
0000782edbbcec5c  jz 0x0000782EDBBCEC8E
0000782edbbcec5e  cmp dword ptr [r15+0x318], 0x00
0000782edbbcec66  mov eax, 0x4105B0
0000782edbbcec6b  mov [r15+0x100], rax
0000782edbbcec72  jz 0x0000782EDB9FE0A0
0000782edbbcec78  nop [rax+rax*1], eax
0000782edbbcec7d  mov eax, 0x4105B0
0000782edbbcec82  mov [r15+0x100], rax
0000782edbbcec89  jmp 0x0000782EDB9FE110
0000782edbbcec8e  cmp dword ptr [r15+0x318], 0x00
0000782edbbcec96  jz 0x0000782EDBBCECE0
0000782edbbcec9c  nop [rax+rax*1], ax
0000782edbbceca5  nop [rax+rax*1], eax
0000782edbbcecad  mov eax, 0x410348
0000782edbbcecb2  mov [r15+0x100], rax
0000782edbbcecb9  jmp 0x0000782EDB9FE110
0000782edbbcecbe  int3
0000782edbbcecbf  call 0x0000782EDBAE27E0
0000782edbbcecc4  jmp 0x0000782EDBBCEC2C
0000782edbbcecc9  call 0x0000782EDBAC0860
0000782edbbcecce  jmp 0x0000782EDBBCEC41
0000782edbbcecd3  int3
0000782edbbcecd4  nop [rax+rax*1], ax
0000782edbbcecdd  nop [rax], eax
0000782edbbcece0  mov rax, [r15+0xF8]
0000782edbbcece7  lea r14, [rax-0x150]
0000782edbbcecee  mov [r15+0xF8], r14
0000782edbbcecf5  mov rax, [r15]
0000782edbbcecf8  lea r12, [rax+0x68]
0000782edbbcecfc  mov r11, [r13+r12*1]
0000782edbbced01  mov [r15+0x88], r11
0000782edbbced08  lea r12, [rax+0x28]
0000782edbbced0c  mov [r15+0x40], r12
0000782edbbced10  mov [r15+0x48], r14
0000782edbbced14  mov qword ptr [r15+0x50], 0x420758
0000782edbbced1c  lea rax, [r14+0x100]
0000782edbbced23  mov r12, [r15+0xE8]
0000782edbbced2a  mov r11, [r15+0xD8]
0000782edbbced31  mov [r13+rax*1], r12
0000782edbbced36  lea rax, [r14+0x108]
0000782edbbced3d  mov [r13+rax*1], r11
0000782edbbced42  lea rax, [r14+0x110]
0000782edbbced49  mov r12, [r15+0xD0]
0000782edbbced50  mov r11, [r15+0xC8]
0000782edbbced57  mov [r13+rax*1], r12
0000782edbbced5c  lea rax, [r14+0x118]
0000782edbbced63  mov [r13+rax*1], r11
0000782edbbced68  lea rax, [r14+0x120]
0000782edbbced6f  mov r12, [r15+0xC0]
0000782edbbced76  mov r11, [r15+0xB8]
0000782edbbced7d  mov [r13+rax*1], r12
0000782edbbced82  lea rax, [r14+0x128]
0000782edbbced89  mov [r13+rax*1], r11
0000782edbbced8e  lea rax, [r14+0x130]
0000782edbbced95  mov r12, [r15+0xB0]
0000782edbbced9c  mov r11, [r15+0xA8]
0000782edbbceda3  mov [r13+rax*1], r12
0000782edbbceda8  lea rax, [r14+0x138]
0000782edbbcedaf  mov [r13+rax*1], r11
0000782edbbcedb4  lea rax, [r14+0x140]
0000782edbbcedbb  mov r12, [r15+0xA0]
0000782edbbcedc2  mov r11, [r15+0x98]
0000782edbbcedc9  mov [r13+rax*1], r12
0000782edbbcedce  lea rax, [r14+0x148]
0000782edbbcedd5  mov [r13+rax*1], r11
0000782edbbcedda  cmp dword ptr [r15+0x318], 0x00
0000782edbbcede2  jz 0x0000782EDBBCEE80
0000782edbbcede8  nop [rax+rax*1], ax
0000782edbbcedf1  nop [rax+rax*1], eax
0000782edbbcedf9  mov eax, 0x410380
0000782edbbcedfe  mov [r15+0x100], rax
0000782edbbcee05  jmp 0x0000782EDB9FE110
0000782edbbcee0a  int3
0000782edbbcee0b  call 0x0000782EDBAC0370
0000782edbbcee10  jmp 0x0000782EDBBCED01
0000782edbbcee15  call 0x0000782EDBA0BC20
0000782edbbcee1a  jmp 0x0000782EDBBCED36
0000782edbbcee1f  call 0x0000782EDBA0A9A0
0000782edbbcee24  jmp 0x0000782EDBBCED42
0000782edbbcee29  call 0x0000782EDBA0BC20
0000782edbbcee2e  jmp 0x0000782EDBBCED5C
0000782edbbcee33  call 0x0000782EDBA0A9A0
0000782edbbcee38  jmp 0x0000782EDBBCED68
0000782edbbcee3d  call 0x0000782EDBA0BC20
0000782edbbcee42  jmp 0x0000782EDBBCED82
0000782edbbcee47  call 0x0000782EDBA0A9A0
0000782edbbcee4c  jmp 0x0000782EDBBCED8E
0000782edbbcee51  call 0x0000782EDBA0BC20
0000782edbbcee56  jmp 0x0000782EDBBCEDA8
0000782edbbcee5b  call 0x0000782EDBA0A9A0
0000782edbbcee60  jmp 0x0000782EDBBCEDB4
0000782edbbcee65  call 0x0000782EDBA0BC20
0000782edbbcee6a  jmp 0x0000782EDBBCEDCE
0000782edbbcee6f  call 0x0000782EDBA0A9A0
0000782edbbcee74  jmp 0x0000782EDBBCEDDA
0000782edbbcee79  int3
0000782edbbcee7a  nop [rax+rax*1], ax
0000782edbbcee80  mov rax, [r15+0x08]
0000782edbbcee84  movzx r14d, byte ptr [r13+rax*1]
0000782edbbcee8a  movzx r14d, r14b
0000782edbbcee8e  mov [rsp+0x10], r14d
0000782edbbcee93  mov r14d, r14d
0000782edbbcee96  mov [r15+0x58], r14
0000782edbbcee9a  lea r14, [rax+0x01]
0000782edbbcee9e  mov [r15+0x08], r14
0000782edbbceea2  mov rax, [r15+0x88]
0000782edbbceea9  lea r14, [rax+0x01]
0000782edbbceead  mov r12, [r15]
0000782edbbceeb0  lea r11, [r12+0x68]
0000782edbbceeb5  mov [r13+r11*1], r14
0000782edbbceeba  lea r14, [r12+rax*1]
0000782edbbceebe  mov [r15+0x60], r14
0000782edbbceec2  lea rax, [r14+0x28]
0000782edbbceec6  mov r11d, [rsp+0x10]
0000782edbbceecb  movzx r14d, r11b
0000782edbbceecf  mov [r13+rax*1], r14b
0000782edbbceed4  lea rax, [r12+0x68]
0000782edbbceed9  mov r14, [r13+rax*1]
0000782edbbceede  mov [r15+0x88], r14
0000782edbbceee5  xor eax, eax
0000782edbbceee7  mov r12d, 0x40
0000782edbbceeed  cmp r14, r12
0000782edbbceef0  cmc
0000782edbbceef1  lahf
0000782edbbceef2  seto al
0000782edbbceef5  mov [r15+0x108], eax
0000782edbbceefc  mov eax, [r15+0x108]
0000782edbbcef03  sahf
0000782edbbcef04  jnz 0x0000782EDBBCEF36
0000782edbbcef06  cmp dword ptr [r15+0x318], 0x00
0000782edbbcef0e  jz 0x0000782EDBBCF020
0000782edbbcef14  nop [rax+rax*1], ax
0000782edbbcef1d  nop [rax+rax*1], eax
0000782edbbcef25  mov eax, 0x4103A0
0000782edbbcef2a  mov [r15+0x100], rax
0000782edbbcef31  jmp 0x0000782EDB9FE110
0000782edbbcef36  cmp dword ptr [r15+0x318], 0x00
0000782edbbcef3e  jz 0x0000782EDBBCEF90
0000782edbbcef44  nop [rax+rax*1], ax
0000782edbbcef4d  nop [rax+rax*1], eax
0000782edbbcef55  mov eax, 0x410378
0000782edbbcef5a  mov [r15+0x100], rax
0000782edbbcef61  jmp 0x0000782EDB9FE110
0000782edbbcef66  int3
0000782edbbcef67  call 0x0000782EDBA0D860
0000782edbbcef6c  jmp 0x0000782EDBBCEE8A
0000782edbbcef71  call 0x0000782EDBAB36E0
0000782edbbcef76  jmp 0x0000782EDBBCEEBA
0000782edbbcef7b  call 0x0000782EDBA0DD60
0000782edbbcef80  jmp 0x0000782EDBBCEED4
0000782edbbcef85  call 0x0000782EDBA0DC20
0000782edbbcef8a  jmp 0x0000782EDBBCEEDE
0000782edbbcef8f  int3
0000782edbbcef90  mov rax, [r15+0x10]
0000782edbbcef94  lea r14, [rax-0x01]
0000782edbbcef98  mov [r15+0x10], r14
0000782edbbcef9c  test r14, r14
0000782edbbcef9f  setz r14b
0000782edbbcefa3  movzx r14, r14b
0000782edbbcefa7  mov [rsp+0x414], r14b
0000782edbbcefaf  cmp byte ptr [rsp+0x414], 0x00
0000782edbbcefb7  jz 0x0000782EDBBCEFE9
0000782edbbcefb9  cmp dword ptr [r15+0x318], 0x00
0000782edbbcefc1  jz 0x0000782EDBBD0520
0000782edbbcefc7  nop [rax+rax*1], ax
0000782edbbcefd0  nop [rax+rax*1], eax
0000782edbbcefd8  mov eax, 0x410598
0000782edbbcefdd  mov [r15+0x100], rax
0000782edbbcefe4  jmp 0x0000782EDB9FE110
0000782edbbcefe9  cmp dword ptr [r15+0x318], 0x00
0000782edbbceff1  jz 0x0000782EDBBCEE80
0000782edbbceff7  nop [rax+rax*1], ax
0000782edbbcf000  nop [rax+rax*1], eax
0000782edbbcf008  mov eax, 0x410380
0000782edbbcf00d  mov [r15+0x100], rax
0000782edbbcf014  jmp 0x0000782EDB9FE110
0000782edbbcf019  int3
0000782edbbcf01a  int3
0000782edbbcf01b  nop [rax+rax*1], eax
0000782edbbcf020  mov rax, [r15+0x40]
0000782edbbcf024  movzx r14d, byte ptr [r13+rax*1]
0000782edbbcf02a  movaps xmm1, [r15+0x110]
0000782edbbcf032  pinsrb xmm1, r14d, 0x00
0000782edbbcf039  lea r14, [rax+0x01]
0000782edbbcf03d  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf043  movaps xmm15, [r15+0x120]
0000782edbbcf04b  pinsrb xmm15, r12d, 0x00
0000782edbbcf052  lea r14, [rax+0x02]
0000782edbbcf056  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf05c  movaps xmm14, [r15+0x130]
0000782edbbcf064  pinsrb xmm14, r12d, 0x00
0000782edbbcf06b  lea r14, [rax+0x03]
0000782edbbcf06f  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf075  movaps xmm13, [r15+0x140]
0000782edbbcf07d  pinsrb xmm13, r12d, 0x00
0000782edbbcf084  lea r14, [rax+0x04]
0000782edbbcf088  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf08e  pinsrb xmm1, r12d, 0x01
0000782edbbcf095  lea r14, [rax+0x05]
0000782edbbcf099  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf09f  pinsrb xmm15, r12d, 0x01
0000782edbbcf0a6  lea r14, [rax+0x06]
0000782edbbcf0aa  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf0b0  pinsrb xmm14, r12d, 0x01
0000782edbbcf0b7  lea r14, [rax+0x07]
0000782edbbcf0bb  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf0c1  pinsrb xmm13, r12d, 0x01
0000782edbbcf0c8  lea r14, [rax+0x08]
0000782edbbcf0cc  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf0d2  pinsrb xmm1, r12d, 0x02
0000782edbbcf0d9  lea r14, [rax+0x09]
0000782edbbcf0dd  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf0e3  pinsrb xmm15, r12d, 0x02
0000782edbbcf0ea  lea r14, [rax+0x0A]
0000782edbbcf0ee  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf0f4  pinsrb xmm14, r12d, 0x02
0000782edbbcf0fb  lea r14, [rax+0x0B]
0000782edbbcf0ff  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf105  pinsrb xmm13, r12d, 0x02
0000782edbbcf10c  lea r14, [rax+0x0C]
0000782edbbcf110  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf116  pinsrb xmm1, r12d, 0x03
0000782edbbcf11d  lea r14, [rax+0x0D]
0000782edbbcf121  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf127  pinsrb xmm15, r12d, 0x03
0000782edbbcf12e  lea r14, [rax+0x0E]
0000782edbbcf132  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf138  pinsrb xmm14, r12d, 0x03
0000782edbbcf13f  lea r14, [rax+0x0F]
0000782edbbcf143  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf149  pinsrb xmm13, r12d, 0x03
0000782edbbcf150  lea r14, [rax+0x10]
0000782edbbcf154  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf15a  pinsrb xmm1, r12d, 0x04
0000782edbbcf161  lea r14, [rax+0x11]
0000782edbbcf165  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf16b  pinsrb xmm15, r12d, 0x04
0000782edbbcf172  lea r14, [rax+0x12]
0000782edbbcf176  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf17c  pinsrb xmm14, r12d, 0x04
0000782edbbcf183  lea r14, [rax+0x13]
0000782edbbcf187  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf18d  pinsrb xmm13, r12d, 0x04
0000782edbbcf194  lea r14, [rax+0x14]
0000782edbbcf198  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf19e  pinsrb xmm1, r12d, 0x05
0000782edbbcf1a5  lea r14, [rax+0x15]
0000782edbbcf1a9  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf1af  pinsrb xmm15, r12d, 0x05
0000782edbbcf1b6  lea r14, [rax+0x16]
0000782edbbcf1ba  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf1c0  pinsrb xmm14, r12d, 0x05
0000782edbbcf1c7  lea r14, [rax+0x17]
0000782edbbcf1cb  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf1d1  pinsrb xmm13, r12d, 0x05
0000782edbbcf1d8  lea r14, [rax+0x18]
0000782edbbcf1dc  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf1e2  pinsrb xmm1, r12d, 0x06
0000782edbbcf1e9  lea r14, [rax+0x19]
0000782edbbcf1ed  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf1f3  pinsrb xmm15, r12d, 0x06
0000782edbbcf1fa  lea r14, [rax+0x1A]
0000782edbbcf1fe  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf204  pinsrb xmm14, r12d, 0x06
0000782edbbcf20b  lea r14, [rax+0x1B]
0000782edbbcf20f  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf215  pinsrb xmm13, r12d, 0x06
0000782edbbcf21c  lea r14, [rax+0x1C]
0000782edbbcf220  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf226  pinsrb xmm1, r12d, 0x07
0000782edbbcf22d  lea r14, [rax+0x1D]
0000782edbbcf231  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf237  pinsrb xmm15, r12d, 0x07
0000782edbbcf23e  lea r14, [rax+0x1E]
0000782edbbcf242  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf248  pinsrb xmm14, r12d, 0x07
0000782edbbcf24f  lea r14, [rax+0x1F]
0000782edbbcf253  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf259  pinsrb xmm13, r12d, 0x07
0000782edbbcf260  lea r14, [rax+0x20]
0000782edbbcf264  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf26a  pinsrb xmm1, r12d, 0x08
0000782edbbcf271  lea r14, [rax+0x21]
0000782edbbcf275  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf27b  pinsrb xmm15, r12d, 0x08
0000782edbbcf282  lea r14, [rax+0x22]
0000782edbbcf286  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf28c  pinsrb xmm14, r12d, 0x08
0000782edbbcf293  lea r14, [rax+0x23]
0000782edbbcf297  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf29d  pinsrb xmm13, r12d, 0x08
0000782edbbcf2a4  lea r14, [rax+0x24]
0000782edbbcf2a8  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf2ae  pinsrb xmm1, r12d, 0x09
0000782edbbcf2b5  lea r14, [rax+0x25]
0000782edbbcf2b9  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf2bf  pinsrb xmm15, r12d, 0x09
0000782edbbcf2c6  lea r14, [rax+0x26]
0000782edbbcf2ca  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf2d0  pinsrb xmm14, r12d, 0x09
0000782edbbcf2d7  lea r14, [rax+0x27]
0000782edbbcf2db  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf2e1  pinsrb xmm13, r12d, 0x09
0000782edbbcf2e8  lea r14, [rax+0x28]
0000782edbbcf2ec  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf2f2  pinsrb xmm1, r12d, 0x0A
0000782edbbcf2f9  lea r14, [rax+0x29]
0000782edbbcf2fd  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf303  pinsrb xmm15, r12d, 0x0A
0000782edbbcf30a  lea r14, [rax+0x2A]
0000782edbbcf30e  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf314  pinsrb xmm14, r12d, 0x0A
0000782edbbcf31b  lea r14, [rax+0x2B]
0000782edbbcf31f  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf325  pinsrb xmm13, r12d, 0x0A
0000782edbbcf32c  lea r14, [rax+0x2C]
0000782edbbcf330  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf336  pinsrb xmm1, r12d, 0x0B
0000782edbbcf33d  lea r14, [rax+0x2D]
0000782edbbcf341  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf347  pinsrb xmm15, r12d, 0x0B
0000782edbbcf34e  lea r14, [rax+0x2E]
0000782edbbcf352  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf358  pinsrb xmm14, r12d, 0x0B
0000782edbbcf35f  lea r14, [rax+0x2F]
0000782edbbcf363  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf369  pinsrb xmm13, r12d, 0x0B
0000782edbbcf370  lea r14, [rax+0x30]
0000782edbbcf374  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf37a  pinsrb xmm1, r12d, 0x0C
0000782edbbcf381  lea r14, [rax+0x31]
0000782edbbcf385  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf38b  pinsrb xmm15, r12d, 0x0C
0000782edbbcf392  lea r14, [rax+0x32]
0000782edbbcf396  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf39c  pinsrb xmm14, r12d, 0x0C
0000782edbbcf3a3  lea r14, [rax+0x33]
0000782edbbcf3a7  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf3ad  pinsrb xmm13, r12d, 0x0C
0000782edbbcf3b4  lea r14, [rax+0x34]
0000782edbbcf3b8  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf3be  pinsrb xmm1, r12d, 0x0D
0000782edbbcf3c5  lea r14, [rax+0x35]
0000782edbbcf3c9  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf3cf  pinsrb xmm15, r12d, 0x0D
0000782edbbcf3d6  lea r14, [rax+0x36]
0000782edbbcf3da  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf3e0  pinsrb xmm14, r12d, 0x0D
0000782edbbcf3e7  lea r14, [rax+0x37]
0000782edbbcf3eb  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf3f1  pinsrb xmm13, r12d, 0x0D
0000782edbbcf3f8  lea r14, [rax+0x38]
0000782edbbcf3fc  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf402  pinsrb xmm1, r12d, 0x0E
0000782edbbcf409  lea r14, [rax+0x39]
0000782edbbcf40d  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf413  pinsrb xmm15, r12d, 0x0E
0000782edbbcf41a  lea r14, [rax+0x3A]
0000782edbbcf41e  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf424  pinsrb xmm14, r12d, 0x0E
0000782edbbcf42b  lea r14, [rax+0x3B]
0000782edbbcf42f  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf435  pinsrb xmm13, r12d, 0x0E
0000782edbbcf43c  lea r14, [rax+0x3C]
0000782edbbcf440  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf446  pinsrb xmm1, r12d, 0x0F
0000782edbbcf44d  movaps [r15+0x110], xmm1
0000782edbbcf455  lea r14, [rax+0x3D]
0000782edbbcf459  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf45f  pinsrb xmm15, r12d, 0x0F
0000782edbbcf466  movaps [r15+0x120], xmm15
0000782edbbcf46e  lea r14, [rax+0x3E]
0000782edbbcf472  movzx r12d, byte ptr [r13+r14*1]
0000782edbbcf478  pinsrb xmm14, r12d, 0x0F
0000782edbbcf47f  movaps [r15+0x130], xmm14
0000782edbbcf487  lea r14, [rax+0x3F]
0000782edbbcf48b  movzx eax, byte ptr [r13+r14*1]
0000782edbbcf491  pinsrb xmm13, eax, 0x0F
0000782edbbcf498  movaps [r15+0x140], xmm13
0000782edbbcf4a0  movq xmm1, qword ptr [r15+0x120]
0000782edbbcf4a9  pmovzxbw xmm1, xmm1
0000782edbbcf4ae  psllw xmm1, 0x00
0000782edbbcf4b3  movaps [r15+0x150], xmm1
0000782edbbcf4bb  movq xmm1, qword ptr [r15+0x130]
0000782edbbcf4c4  pmovzxbw xmm1, xmm1
0000782edbbcf4c9  psllw xmm1, 0x00
0000782edbbcf4ce  movaps [r15+0x160], xmm1
0000782edbbcf4d6  movq xmm1, qword ptr [r15+0x110]
0000782edbbcf4df  pmovzxbw xmm1, xmm1
0000782edbbcf4e4  psllw xmm1, 0x00
0000782edbbcf4e9  movaps [r15+0x170], xmm1
0000782edbbcf4f1  movaps xmm15, [r15+0x110]
0000782edbbcf4f9  pextrq rax, xmm15, 0x01
0000782edbbcf500  movq xmm15, rax
0000782edbbcf505  pmovzxbw xmm15, xmm15
0000782edbbcf50b  psllw xmm15, 0x00
0000782edbbcf511  movaps [r15+0x180], xmm15
0000782edbbcf519  movaps xmm14, [r15+0x120]
0000782edbbcf521  pextrq rax, xmm14, 0x01
0000782edbbcf528  movq xmm14, rax
0000782edbbcf52d  pmovzxbw xmm14, xmm14
0000782edbbcf533  psllw xmm14, 0x00
0000782edbbcf539  movaps [r15+0x210], xmm14
0000782edbbcf541  movaps xmm13, [r15+0x130]
0000782edbbcf549  pextrq rax, xmm13, 0x01
0000782edbbcf550  movq xmm13, rax
0000782edbbcf555  pmovzxbw xmm13, xmm13
0000782edbbcf55b  psllw xmm13, 0x00
0000782edbbcf561  movaps [r15+0x220], xmm13
0000782edbbcf569  movq xmm12, qword ptr [r15+0x140]
0000782edbbcf572  pmovzxbw xmm12, xmm12
0000782edbbcf578  psllw xmm12, 0x00
0000782edbbcf57e  movaps [r15+0x250], xmm12
0000782edbbcf586  movaps xmm12, [r15+0x140]
0000782edbbcf58e  pextrq rax, xmm12, 0x01
0000782edbbcf595  movq xmm12, rax
0000782edbbcf59a  pmovzxbw xmm12, xmm12
0000782edbbcf5a0  psllw xmm12, 0x00
0000782edbbcf5a6  movaps [r15+0x110], xmm12
0000782edbbcf5ae  movq xmm11, qword ptr [r15+0x150]
0000782edbbcf5b7  pmovzxwd xmm11, xmm11
0000782edbbcf5bd  pslld xmm11, 0x10
0000782edbbcf5c3  movq xmm10, qword ptr [r15+0x160]
0000782edbbcf5cc  pmovzxwd xmm10, xmm10
0000782edbbcf5d2  pslld xmm10, 0x08
0000782edbbcf5d8  pextrq rax, xmm1, 0x01
0000782edbbcf5df  movq xmm1, rax
0000782edbbcf5e4  pmovzxwd xmm1, xmm1
0000782edbbcf5e9  pslld xmm1, 0x00
0000782edbbcf5ee  movaps [r15+0x260], xmm1
0000782edbbcf5f6  pextrq rax, xmm15, 0x01
0000782edbbcf5fd  movq xmm15, rax
0000782edbbcf602  pmovzxwd xmm15, xmm15
0000782edbbcf608  pslld xmm15, 0x00
0000782edbbcf60e  movaps [r15+0x270], xmm15
0000782edbbcf616  movq xmm9, qword ptr [r15+0x170]
0000782edbbcf61f  pmovzxwd xmm9, xmm9
0000782edbbcf625  pslld xmm9, 0x00
0000782edbbcf62b  pextrq rax, xmm14, 0x01
0000782edbbcf632  movq xmm14, rax
0000782edbbcf637  pmovzxwd xmm14, xmm14
0000782edbbcf63d  pslld xmm14, 0x10
0000782edbbcf643  movaps [r15+0x280], xmm14
0000782edbbcf64b  movq xmm8, qword ptr [r15+0x180]
0000782edbbcf654  pmovzxwd xmm8, xmm8
0000782edbbcf65a  pslld xmm8, 0x00
0000782edbbcf660  movq xmm7, qword ptr [r15+0x210]
0000782edbbcf669  pmovzxwd xmm7, xmm7
0000782edbbcf66e  pslld xmm7, 0x10
0000782edbbcf673  movaps xmm6, [r15+0x150]
0000782edbbcf67b  pextrq rax, xmm6, 0x01
0000782edbbcf682  movq xmm6, rax
0000782edbbcf687  pmovzxwd xmm6, xmm6
0000782edbbcf68c  pslld xmm6, 0x10
0000782edbbcf691  por xmm11, xmm10
0000782edbbcf696  movaps [r15+0x230], xmm11
0000782edbbcf69e  pextrq rax, xmm13, 0x01
0000782edbbcf6a5  movq xmm13, rax
0000782edbbcf6aa  pmovzxwd xmm13, xmm13
0000782edbbcf6b0  pslld xmm13, 0x08
0000782edbbcf6b6  movaps [r15+0x240], xmm13
0000782edbbcf6be  movq xmm10, qword ptr [r15+0x220]
0000782edbbcf6c7  pmovzxwd xmm10, xmm10
0000782edbbcf6cd  pslld xmm10, 0x08
0000782edbbcf6d3  movaps xmm5, [r15+0x160]
0000782edbbcf6db  pextrq rax, xmm5, 0x01
0000782edbbcf6e2  movq xmm5, rax
0000782edbbcf6e7  pmovzxwd xmm5, xmm5
0000782edbbcf6ec  pslld xmm5, 0x08
0000782edbbcf6f1  pslld xmm9, 0x18
0000782edbbcf6f7  pslld xmm15, 0x18
0000782edbbcf6fd  pslld xmm8, 0x18
0000782edbbcf703  movq xmm4, qword ptr [r15+0x250]
0000782edbbcf70c  pmovzxwd xmm4, xmm4
0000782edbbcf711  pslld xmm4, 0x00
0000782edbbcf716  por xmm14, xmm13
0000782edbbcf71b  por xmm7, xmm10
0000782edbbcf720  movaps [r15+0x210], xmm7
0000782edbbcf728  pslld xmm1, 0x18
0000782edbbcf72d  movaps [r15+0x220], xmm1
0000782edbbcf735  por xmm6, xmm5
0000782edbbcf739  por xmm11, xmm9
0000782edbbcf73e  movaps [r15+0x160], xmm11
0000782edbbcf746  pextrq rax, xmm12, 0x01
0000782edbbcf74d  movq xmm13, rax
0000782edbbcf752  pmovzxwd xmm13, xmm13
0000782edbbcf758  pslld xmm13, 0x00
0000782edbbcf75e  movaps [r15+0x170], xmm13
0000782edbbcf766  movq xmm12, qword ptr [r15+0x110]
0000782edbbcf76f  pmovzxwd xmm12, xmm12
0000782edbbcf775  pslld xmm12, 0x00
0000782edbbcf77b  por xmm14, xmm15
0000782edbbcf780  por xmm7, xmm8
0000782edbbcf785  movaps xmm15, [r15+0x250]
0000782edbbcf78d  pextrq rax, xmm15, 0x01
0000782edbbcf794  movq xmm15, rax
0000782edbbcf799  pmovzxwd xmm15, xmm15
0000782edbbcf79f  pslld xmm15, 0x00
0000782edbbcf7a5  movaps [r15+0x180], xmm15
0000782edbbcf7ad  por xmm6, xmm1
0000782edbbcf7b1  movaps [r15+0x150], xmm6
0000782edbbcf7b9  por xmm11, xmm4
0000782edbbcf7be  movaps [r15+0x140], xmm11
0000782edbbcf7c6  por xmm7, xmm12
0000782edbbcf7cb  movaps [r15+0x110], xmm7
0000782edbbcf7d3  por xmm14, xmm13
0000782edbbcf7d8  movaps [r15+0x120], xmm14
0000782edbbcf7e0  por xmm6, xmm15
0000782edbbcf7e5  movaps [r15+0x130], xmm6
0000782edbbcf7ed  mov rax, [r15+0xF8]
0000782edbbcf7f4  lea r14, [rax+0x20]
0000782edbbcf7f8  movups [r13+r14*1], xmm7
0000782edbbcf7fe  lea r14, [rax+0x30]
0000782edbbcf802  movups [r13+r14*1], xmm14
0000782edbbcf808  movups [r13+rax*1], xmm11
0000782edbbcf80e  lea r14, [rax+0x10]
0000782edbbcf812  movups [r13+r14*1], xmm6
0000782edbbcf818  mov r14d, [r13+rax*1]
0000782edbbcf81d  mov rax, [r15+0x48]
0000782edbbcf821  mov [r15+0x68], rax
0000782edbbcf825  mov qword ptr [r15+0x58], 0x04
0000782edbbcf82d  lea r12, [rax+0x04]
0000782edbbcf831  mov r11d, [r13+r12*1]
0000782edbbcf836  mov [rsp+0x10], r11d
0000782edbbcf83b  mov r11d, r11d
0000782edbbcf83e  mov [r15+0x70], r11
0000782edbbcf842  lea r12, [rax+0x38]
0000782edbbcf846  mov r11d, [r13+r12*1]
0000782edbbcf84b  lea r12, [rax+0x24]
0000782edbbcf84f  mov r10d, [r13+r12*1]
0000782edbbcf854  mov [rsp+0x20], r10d
0000782edbbcf859  mov r10d, r10d
0000782edbbcf85c  mov [r15+0x90], r10
0000782edbbcf863  mov [rsp+0x30], rax
0000782edbbcf868  xor eax, eax
0000782edbbcf86a  mov r12d, 0x04
0000782edbbcf870  mov r10d, 0xC0
0000782edbbcf876  cmp r12, r10
0000782edbbcf879  cmc
0000782edbbcf87a  lahf
0000782edbbcf87b  seto al
0000782edbbcf87e  mov [r15+0x108], eax
0000782edbbcf885  mov eax, [rsp+0x10]
0000782edbbcf889  mov r12d, [rsp+0x10]
0000782edbbcf88e  shrd eax, r12d, 0x07
0000782edbbcf893  mov [rsp+0x10], r11d
0000782edbbcf898  mov r10d, [rsp+0x10]
0000782edbbcf89d  shrd r11d, r10d, 0x11
0000782edbbcf8a2  mov r9d, [rsp+0x20]
0000782edbbcf8a7  lea r8d, [r9d+r14d*1]
0000782edbbcf8ac  rorx r14d, r12d, 0x12
0000782edbbcf8b2  xor eax, r14d
0000782edbbcf8b5  rorx r14d, r10d, 0x13
0000782edbbcf8bb  xor r11d, r14d
0000782edbbcf8be  mov [rsp+0x10], r11d
0000782edbbcf8c3  mov r11d, r11d
0000782edbbcf8c6  mov [r15+0x88], r11
0000782edbbcf8cd  mov [rsp+0x20], r12d
0000782edbbcf8d2  shr r12d, 0x03
0000782edbbcf8d6  xor eax, r12d
0000782edbbcf8d9  mov [rsp+0x40], eax
0000782edbbcf8dd  mov eax, eax
0000782edbbcf8df  mov [r15+0x80], rax
0000782edbbcf8e6  shr r10d, 0x0A
0000782edbbcf8ea  mov eax, [rsp+0x10]
0000782edbbcf8ee  xor eax, r10d
0000782edbbcf8f1  mov [rsp+0x10], eax
0000782edbbcf8f5  mov eax, eax
0000782edbbcf8f7  mov [r15+0x78], rax
0000782edbbcf8fb  mov eax, [rsp+0x40]
0000782edbbcf8ff  lea r14d, [r8d+eax*1]
0000782edbbcf904  mov eax, [rsp+0x10]
0000782edbbcf908  lea r12d, [r14d+eax*1]
0000782edbbcf90d  mov rax, [rsp+0x30]
0000782edbbcf912  lea r14, [rax+0x40]
0000782edbbcf916  mov [r13+r14*1], r12d
0000782edbbcf91b  mov eax, [rsp+0x20]
0000782edbbcf91f  mov eax, eax
0000782edbbcf921  mov [r15+0x60], rax
0000782edbbcf925  mov eax, [r15+0x108]
0000782edbbcf92c  sahf
0000782edbbcf92d  jnz 0x0000782EDBBCF95F
0000782edbbcf92f  cmp dword ptr [r15+0x318], 0x00
0000782edbbcf937  jz 0x0000782EDBBCFE20
0000782edbbcf93d  nop [rax+rax*1], ax
0000782edbbcf946  nop [rax+rax*1], eax
0000782edbbcf94e  mov eax, 0x41049C
0000782edbbcf953  mov [r15+0x100], rax
0000782edbbcf95a  jmp 0x0000782EDB9FE110
0000782edbbcf95f  cmp dword ptr [r15+0x318], 0x00
0000782edbbcf967  jz 0x0000782EDBBCFC70
0000782edbbcf96d  nop [rax+rax*1], ax
0000782edbbcf976  nop [rax+rax*1], eax
0000782edbbcf97e  mov eax, 0x410454
0000782edbbcf983  mov [r15+0x100], rax
0000782edbbcf98a  jmp 0x0000782EDB9FE110
0000782edbbcf98f  int3
0000782edbbcf990  call 0x0000782EDBA0D860
0000782edbbcf995  jmp 0x0000782EDBBCF02A
0000782edbbcf99a  call 0x0000782EDBAE2420
0000782edbbcf99f  jmp 0x0000782EDBBCF043
0000782edbbcf9a4  call 0x0000782EDBAE2420
0000782edbbcf9a9  jmp 0x0000782EDBBCF05C
0000782edbbcf9ae  call 0x0000782EDBAE2420
0000782edbbcf9b3  jmp 0x0000782EDBBCF075
0000782edbbcf9b8  call 0x0000782EDBAE2420
0000782edbbcf9bd  jmp 0x0000782EDBBCF08E
0000782edbbcf9c2  call 0x0000782EDBAE2420
0000782edbbcf9c7  jmp 0x0000782EDBBCF09F
0000782edbbcf9cc  call 0x0000782EDBAE2420
0000782edbbcf9d1  jmp 0x0000782EDBBCF0B0
0000782edbbcf9d6  call 0x0000782EDBAE2420
0000782edbbcf9db  jmp 0x0000782EDBBCF0C1
0000782edbbcf9e0  call 0x0000782EDBAE2420
0000782edbbcf9e5  jmp 0x0000782EDBBCF0D2
0000782edbbcf9ea  call 0x0000782EDBAE2420
0000782edbbcf9ef  jmp 0x0000782EDBBCF0E3
0000782edbbcf9f4  call 0x0000782EDBAE2420
0000782edbbcf9f9  jmp 0x0000782EDBBCF0F4
0000782edbbcf9fe  call 0x0000782EDBAE2420
0000782edbbcfa03  jmp 0x0000782EDBBCF105
0000782edbbcfa08  call 0x0000782EDBAE2420
0000782edbbcfa0d  jmp 0x0000782EDBBCF116
0000782edbbcfa12  call 0x0000782EDBAE2420
0000782edbbcfa17  jmp 0x0000782EDBBCF127
0000782edbbcfa1c  call 0x0000782EDBAE2420
0000782edbbcfa21  jmp 0x0000782EDBBCF138
0000782edbbcfa26  call 0x0000782EDBAE2420
0000782edbbcfa2b  jmp 0x0000782EDBBCF149
0000782edbbcfa30  call 0x0000782EDBAE2420
0000782edbbcfa35  jmp 0x0000782EDBBCF15A
0000782edbbcfa3a  call 0x0000782EDBAE2420
0000782edbbcfa3f  jmp 0x0000782EDBBCF16B
0000782edbbcfa44  call 0x0000782EDBAE2420
0000782edbbcfa49  jmp 0x0000782EDBBCF17C
0000782edbbcfa4e  call 0x0000782EDBAE2420
0000782edbbcfa53  jmp 0x0000782EDBBCF18D
0000782edbbcfa58  call 0x0000782EDBAE2420
0000782edbbcfa5d  jmp 0x0000782EDBBCF19E
0000782edbbcfa62  call 0x0000782EDBAE2420
0000782edbbcfa67  jmp 0x0000782EDBBCF1AF
0000782edbbcfa6c  call 0x0000782EDBAE2420
0000782edbbcfa71  jmp 0x0000782EDBBCF1C0
0000782edbbcfa76  call 0x0000782EDBAE2420
0000782edbbcfa7b  jmp 0x0000782EDBBCF1D1
0000782edbbcfa80  call 0x0000782EDBAE2420
0000782edbbcfa85  jmp 0x0000782EDBBCF1E2
0000782edbbcfa8a  call 0x0000782EDBAE2420
0000782edbbcfa8f  jmp 0x0000782EDBBCF1F3
0000782edbbcfa94  call 0x0000782EDBAE2420
0000782edbbcfa99  jmp 0x0000782EDBBCF204
0000782edbbcfa9e  call 0x0000782EDBAE2420
0000782edbbcfaa3  jmp 0x0000782EDBBCF215
0000782edbbcfaa8  call 0x0000782EDBAE2420
0000782edbbcfaad  jmp 0x0000782EDBBCF226
0000782edbbcfab2  call 0x0000782EDBAE2420
0000782edbbcfab7  jmp 0x0000782EDBBCF237
0000782edbbcfabc  call 0x0000782EDBAE2420
0000782edbbcfac1  jmp 0x0000782EDBBCF248
0000782edbbcfac6  call 0x0000782EDBAE2420
0000782edbbcfacb  jmp 0x0000782EDBBCF259
0000782edbbcfad0  call 0x0000782EDBAE2420
0000782edbbcfad5  jmp 0x0000782EDBBCF26A
0000782edbbcfada  call 0x0000782EDBAE2420
0000782edbbcfadf  jmp 0x0000782EDBBCF27B
0000782edbbcfae4  call 0x0000782EDBAE2420
0000782edbbcfae9  jmp 0x0000782EDBBCF28C
0000782edbbcfaee  call 0x0000782EDBAE2420
0000782edbbcfaf3  jmp 0x0000782EDBBCF29D
0000782edbbcfaf8  call 0x0000782EDBAE2420
0000782edbbcfafd  jmp 0x0000782EDBBCF2AE
0000782edbbcfb02  call 0x0000782EDBAE2420
0000782edbbcfb07  jmp 0x0000782EDBBCF2BF
0000782edbbcfb0c  call 0x0000782EDBAE2420
0000782edbbcfb11  jmp 0x0000782EDBBCF2D0
0000782edbbcfb16  call 0x0000782EDBAE2420
0000782edbbcfb1b  jmp 0x0000782EDBBCF2E1
0000782edbbcfb20  call 0x0000782EDBAE2420
0000782edbbcfb25  jmp 0x0000782EDBBCF2F2
0000782edbbcfb2a  call 0x0000782EDBAE2420
0000782edbbcfb2f  jmp 0x0000782EDBBCF303
0000782edbbcfb34  call 0x0000782EDBAE2420
0000782edbbcfb39  jmp 0x0000782EDBBCF314
0000782edbbcfb3e  call 0x0000782EDBAE2420
0000782edbbcfb43  jmp 0x0000782EDBBCF325
0000782edbbcfb48  call 0x0000782EDBAE2420
0000782edbbcfb4d  jmp 0x0000782EDBBCF336
0000782edbbcfb52  call 0x0000782EDBAE2420
0000782edbbcfb57  jmp 0x0000782EDBBCF347
0000782edbbcfb5c  call 0x0000782EDBAE2420
0000782edbbcfb61  jmp 0x0000782EDBBCF358
0000782edbbcfb66  call 0x0000782EDBAE2420
0000782edbbcfb6b  jmp 0x0000782EDBBCF369
0000782edbbcfb70  call 0x0000782EDBAE2420
0000782edbbcfb75  jmp 0x0000782EDBBCF37A
0000782edbbcfb7a  call 0x0000782EDBAE2420
0000782edbbcfb7f  jmp 0x0000782EDBBCF38B
0000782edbbcfb84  call 0x0000782EDBAE2420
0000782edbbcfb89  jmp 0x0000782EDBBCF39C
0000782edbbcfb8e  call 0x0000782EDBAE2420
0000782edbbcfb93  jmp 0x0000782EDBBCF3AD
0000782edbbcfb98  call 0x0000782EDBAE2420
0000782edbbcfb9d  jmp 0x0000782EDBBCF3BE
0000782edbbcfba2  call 0x0000782EDBAE2420
0000782edbbcfba7  jmp 0x0000782EDBBCF3CF
0000782edbbcfbac  call 0x0000782EDBAE2420
0000782edbbcfbb1  jmp 0x0000782EDBBCF3E0
0000782edbbcfbb6  call 0x0000782EDBAE2420
0000782edbbcfbbb  jmp 0x0000782EDBBCF3F1
0000782edbbcfbc0  call 0x0000782EDBAE2420
0000782edbbcfbc5  jmp 0x0000782EDBBCF402
0000782edbbcfbca  call 0x0000782EDBAE2420
0000782edbbcfbcf  jmp 0x0000782EDBBCF413
0000782edbbcfbd4  call 0x0000782EDBAE2420
0000782edbbcfbd9  jmp 0x0000782EDBBCF424
0000782edbbcfbde  call 0x0000782EDBAE2420
0000782edbbcfbe3  jmp 0x0000782EDBBCF435
0000782edbbcfbe8  call 0x0000782EDBAE2420
0000782edbbcfbed  jmp 0x0000782EDBBCF446
0000782edbbcfbf2  call 0x0000782EDBAE2420
0000782edbbcfbf7  jmp 0x0000782EDBBCF45F
0000782edbbcfbfc  call 0x0000782EDBAE2420
0000782edbbcfc01  jmp 0x0000782EDBBCF478
0000782edbbcfc06  call 0x0000782EDBAD5610
0000782edbbcfc0b  jmp 0x0000782EDBBCF491
0000782edbbcfc10  call 0x0000782EDBADC580
0000782edbbcfc15  jmp 0x0000782EDBBCF7FE
0000782edbbcfc1a  call 0x0000782EDBAE46C0
0000782edbbcfc1f  jmp 0x0000782EDBBCF808
0000782edbbcfc24  call 0x0000782EDBA09E90
0000782edbbcfc29  jmp 0x0000782EDBBCF80E
0000782edbbcfc2e  call 0x0000782EDBADB310
0000782edbbcfc33  jmp 0x0000782EDBBCF818
0000782edbbcfc38  call 0x0000782EDBA0DAE0
0000782edbbcfc3d  jmp 0x0000782EDBBCF81D
0000782edbbcfc42  call 0x0000782EDBAC0230
0000782edbbcfc47  jmp 0x0000782EDBBCF836
0000782edbbcfc4c  call 0x0000782EDBAC0230
0000782edbbcfc51  jmp 0x0000782EDBBCF84B
0000782edbbcfc56  call 0x0000782EDBABEFC0
0000782edbbcfc5b  jmp 0x0000782EDBBCF854
0000782edbbcfc60  call 0x0000782EDBAE2BA0
0000782edbbcfc65  jmp 0x0000782EDBBCF91B
0000782edbbcfc6a  int3
0000782edbbcfc6b  nop [rax+rax*1], eax
0000782edbbcfc70  mov rax, [r15+0x48]
0000782edbbcfc74  mov r14, [r15+0x58]
0000782edbbcfc78  lea r12, [rax+r14*1]
0000782edbbcfc7c  mov [r15+0x68], r12
0000782edbbcfc80  lea rax, [r14+0x04]
0000782edbbcfc84  mov [r15+0x58], rax
0000782edbbcfc88  lea r14, [r12+0x04]
0000782edbbcfc8d  mov r11d, [r13+r14*1]
0000782edbbcfc92  mov [rsp+0x10], r11d
0000782edbbcfc97  mov r11d, r11d
0000782edbbcfc9a  mov [r15+0x70], r11
0000782edbbcfc9e  lea r14, [r12+0x38]
0000782edbbcfca3  mov r11d, [r13+r14*1]
0000782edbbcfca8  lea r14, [r12+0x24]
0000782edbbcfcad  mov r10d, [r13+r14*1]
0000782edbbcfcb2  mov [rsp+0x20], r10d
0000782edbbcfcb7  mov r10d, r10d
0000782edbbcfcba  mov [r15+0x90], r10
0000782edbbcfcc1  mov [rsp+0x30], rax
0000782edbbcfcc6  xor eax, eax
0000782edbbcfcc8  mov r14, [rsp+0x30]
0000782edbbcfccd  mov r10d, 0xC0
0000782edbbcfcd3  cmp r14, r10
0000782edbbcfcd6  cmc
0000782edbbcfcd7  lahf
0000782edbbcfcd8  seto al
0000782edbbcfcdb  mov [r15+0x108], eax
0000782edbbcfce2  mov eax, [rsp+0x10]
0000782edbbcfce6  mov r14d, [rsp+0x10]
0000782edbbcfceb  shrd eax, r14d, 0x07
0000782edbbcfcf0  mov [rsp+0x10], r11d
0000782edbbcfcf5  mov r10d, [rsp+0x10]
0000782edbbcfcfa  shrd r11d, r10d, 0x11
0000782edbbcfcff  mov r9d, [r15+0x60]
0000782edbbcfd03  mov r8d, [rsp+0x20]
0000782edbbcfd08  lea ebp, [r8d+r9d*1]
0000782edbbcfd0d  rorx r9d, r14d, 0x12
0000782edbbcfd13  xor eax, r9d
0000782edbbcfd16  rorx r9d, r10d, 0x13
0000782edbbcfd1c  xor r11d, r9d
0000782edbbcfd1f  mov [rsp+0x10], r11d
0000782edbbcfd24  mov r11d, r11d
0000782edbbcfd27  mov [r15+0x88], r11
0000782edbbcfd2e  mov [rsp+0x20], r14d
0000782edbbcfd33  shr r14d, 0x03
0000782edbbcfd37  xor eax, r14d
0000782edbbcfd3a  mov [rsp+0x30], eax
0000782edbbcfd3e  mov eax, eax
0000782edbbcfd40  mov [r15+0x80], rax
0000782edbbcfd47  shr r10d, 0x0A
0000782edbbcfd4b  mov eax, [rsp+0x10]
0000782edbbcfd4f  xor eax, r10d
0000782edbbcfd52  mov [rsp+0x10], eax
0000782edbbcfd56  mov eax, eax
0000782edbbcfd58  mov [r15+0x78], rax
0000782edbbcfd5c  mov eax, [rsp+0x30]
0000782edbbcfd60  lea r14d, [ebp+eax*1]
0000782edbbcfd66  mov eax, [rsp+0x10]
0000782edbbcfd6a  lea r11d, [r14d+eax*1]
0000782edbbcfd6f  lea rax, [r12+0x40]
0000782edbbcfd74  mov [r13+rax*1], r11d
0000782edbbcfd79  mov eax, [rsp+0x20]
0000782edbbcfd7d  mov eax, eax
0000782edbbcfd7f  mov [r15+0x60], rax
0000782edbbcfd83  mov eax, [r15+0x108]
0000782edbbcfd8a  sahf
0000782edbbcfd8b  jnz 0x0000782EDBBCFDBD
0000782edbbcfd8d  cmp dword ptr [r15+0x318], 0x00
0000782edbbcfd95  jz 0x0000782EDBBCFE20
0000782edbbcfd9b  nop [rax+rax*1], ax
0000782edbbcfda4  nop [rax+rax*1], eax
0000782edbbcfdac  mov eax, 0x41049C
0000782edbbcfdb1  mov [r15+0x100], rax
0000782edbbcfdb8  jmp 0x0000782EDB9FE110
0000782edbbcfdbd  cmp dword ptr [r15+0x318], 0x00
0000782edbbcfdc5  jz 0x0000782EDBBCFC70
0000782edbbcfdcb  nop [rax+rax*1], ax
0000782edbbcfdd4  nop [rax+rax*1], eax
0000782edbbcfddc  mov eax, 0x410454
0000782edbbcfde1  mov [r15+0x100], rax
0000782edbbcfde8  jmp 0x0000782EDB9FE110
0000782edbbcfded  int3
0000782edbbcfdee  call 0x0000782EDBAE1430
0000782edbbcfdf3  jmp 0x0000782EDBBCFC92
0000782edbbcfdf8  call 0x0000782EDBAE1430
0000782edbbcfdfd  jmp 0x0000782EDBBCFCA8
0000782edbbcfe02  call 0x0000782EDBAE01C0
0000782edbbcfe07  jmp 0x0000782EDBBCFCB2
0000782edbbcfe0c  call 0x0000782EDBA0A860
0000782edbbcfe11  jmp 0x0000782EDBBCFD79
0000782edbbcfe16  int3
0000782edbbcfe17  nop [rax+rax*1], ax
0000782edbbcfe20  mov rax, [r15]
0000782edbbcfe23  mov r14d, [r13+rax*1]
0000782edbbcfe28  lea r12, [rax+0x04]
0000782edbbcfe2c  mov r11d, [r13+r12*1]
0000782edbbcfe31  mov [rsp+0x10], r14d
0000782edbbcfe36  mov r14d, r14d
0000782edbbcfe39  mov [r15+0x78], r14
0000782edbbcfe3d  mov [rsp+0x20], r11d
0000782edbbcfe42  mov r11d, r11d
0000782edbbcfe45  mov [r15+0x80], r11
0000782edbbcfe4c  lea r14, [rax+0x08]
0000782edbbcfe50  mov r12d, [r13+r14*1]
0000782edbbcfe55  lea r14, [rax+0x0C]
0000782edbbcfe59  mov r11d, [r13+r14*1]
0000782edbbcfe5e  mov [rsp+0x30], r12d
0000782edbbcfe63  mov r12d, r12d
0000782edbbcfe66  mov [r15+0x70], r12
0000782edbbcfe6a  mov [rsp+0x40], r11d
0000782edbbcfe6f  mov r11d, r11d
0000782edbbcfe72  mov [r15+0x68], r11
0000782edbbcfe76  lea r14, [rax+0x18]
0000782edbbcfe7a  mov r12d, [r13+r14*1]
0000782edbbcfe7f  lea r14, [rax+0x1C]
0000782edbbcfe83  mov r11d, [r13+r14*1]
0000782edbbcfe88  mov [rsp+0x50], r12d
0000782edbbcfe8d  mov r12d, r12d
0000782edbbcfe90  mov [r15+0x58], r12
0000782edbbcfe94  mov [rsp+0x60], r11d
0000782edbbcfe99  mov r11d, r11d
0000782edbbcfe9c  mov [r15+0x60], r11
0000782edbbcfea0  lea r14, [rax+0x10]
0000782edbbcfea4  mov r12d, [r13+r14*1]
0000782edbbcfea9  lea r14, [rax+0x14]
0000782edbbcfead  mov eax, [r13+r14*1]
0000782edbbcfeb2  mov [rsp+0x70], r12d
0000782edbbcfeb7  mov r12d, r12d
0000782edbbcfeba  mov [r15+0x18], r12
0000782edbbcfebe  mov [rsp+0x80], eax
0000782edbbcfec5  mov eax, eax
0000782edbbcfec7  mov [r15+0x90], rax
0000782edbbcfece  mov eax, [rsp+0x70]
0000782edbbcfed2  mov eax, eax
0000782edbbcfed4  mov [r15+0x30], rax
0000782edbbcfed8  mov eax, [rsp+0x50]
0000782edbbcfedc  mov eax, eax
0000782edbbcfede  mov [r15+0xA0], rax
0000782edbbcfee5  mov eax, [rsp+0x30]
0000782edbbcfee9  mov eax, eax
0000782edbbcfeeb  mov [r15+0x28], rax
0000782edbbcfeef  mov eax, [rsp+0x20]
0000782edbbcfef3  mov eax, eax
0000782edbbcfef5  mov [r15+0x98], rax
0000782edbbcfefc  mov eax, [rsp+0x10]
0000782edbbcff00  mov eax, eax
0000782edbbcff02  mov [r15+0x38], rax
0000782edbbcff06  mov eax, [rsp+0x70]
0000782edbbcff0a  mov r14d, [rsp+0x70]
0000782edbbcff0f  shrd eax, r14d, 0x06
0000782edbbcff14  mov [rsp+0x70], r14d
0000782edbbcff19  mov r12d, [rsp+0x80]
0000782edbbcff21  and r14d, r12d
0000782edbbcff24  mov r11d, [rsp+0x10]
0000782edbbcff29  mov r10d, [rsp+0x10]
0000782edbbcff2e  shrd r11d, r10d, 0x02
0000782edbbcff33  mov [rsp+0x10], r12d
0000782edbbcff38  mov r12d, r12d
0000782edbbcff3b  mov [r15+0x20], r12
0000782edbbcff3f  mov r12, [r15+0x50]
0000782edbbcff43  mov r9d, [r13+r12*1]
0000782edbbcff48  mov r12d, [rsp+0x50]
0000782edbbcff4d  mov r8d, [rsp+0x70]
0000782edbbcff52  andn ebp, r8d, r12d
0000782edbbcff57  mov edi, [rsp+0x60]
0000782edbbcff5b  lea esi, [r14d+edi*1]
0000782edbbcff60  rorx r14d, r8d, 0x0B
0000782edbbcff66  xor eax, r14d
0000782edbbcff69  rorx r14d, r10d, 0x0D
0000782edbbcff6f  xor r11d, r14d
0000782edbbcff72  lea edi, [esi+ebp*1]
0000782edbbcff76  mov r14, [r15+0x48]
0000782edbbcff7a  mov ebp, [r13+r14*1]
0000782edbbcff7f  mov r14d, [rsp+0x30]
0000782edbbcff84  mov esi, [rsp+0x20]
0000782edbbcff88  and r14d, esi
0000782edbbcff8b  mov [rsp+0x20], r14d
0000782edbbcff90  mov r14d, r14d
0000782edbbcff93  mov [r15+0xD8], r14
0000782edbbcff9a  lea r14d, [edi+r9d*1]
0000782edbbcff9f  mov r9d, [rsp+0x30]
0000782edbbcffa4  xor r9d, esi
0000782edbbcffa7  rorx edi, r8d, 0x19
0000782edbbcffad  xor eax, edi
0000782edbbcffaf  and r9d, r10d
0000782edbbcffb2  rorx edi, r10d, 0x16
0000782edbbcffb8  xor r11d, edi
0000782edbbcffbb  mov [rsp+0x30], r11d
0000782edbbcffc0  mov r11d, r11d
0000782edbbcffc3  mov [r15+0xD0], r11
0000782edbbcffca  lea r11d, [r14d+ebp*1]
0000782edbbcffcf  mov r10d, [rsp+0x20]
0000782edbbcffd4  xor r9d, r10d
0000782edbbcffd7  lea r14d, [r11d+eax*1]
0000782edbbcffdc  mov qword ptr [r15+0x88], 0x04
0000782edbbcffe7  mov eax, [rsp+0x30]
0000782edbbcffeb  lea r11d, [r9d+eax*1]
0000782edbbcfff0  mov eax, [rsp+0x40]
0000782edbbcfff4  lea r10d, [r14d+eax*1]
0000782edbbcfff9  mov r10d, r10d
0000782edbbcfffc  mov [r15+0xB8], r10
0000782edbbd0003  xor eax, eax
0000782edbbd0005  mov r10d, 0x04
0000782edbbd000b  mov r9d, 0x100
0000782edbbd0011  cmp r10, r9
0000782edbbd0014  cmc
0000782edbbd0015  lahf
0000782edbbd0016  seto al
0000782edbbd0019  mov [r15+0x108], eax
0000782edbbd0020  lea eax, [r11d+r14d*1]
0000782edbbd0025  mov eax, eax
0000782edbbd0027  mov [r15+0xA8], rax
0000782edbbd002e  mov r12d, r12d
0000782edbbd0031  mov [r15+0xB0], r12
0000782edbbd0038  mov eax, [rsp+0x10]
0000782edbbd003c  mov eax, eax
0000782edbbd003e  mov [r15+0xC0], rax
0000782edbbd0045  mov r8d, r8d
0000782edbbd0048  mov [r15+0xC8], r8
0000782edbbd004f  mov eax, [r15+0x108]
0000782edbbd0056  sahf
0000782edbbd0057  jnz 0x0000782EDBBD0089
0000782edbbd0059  cmp dword ptr [r15+0x318], 0x00
0000782edbbd0061  jz 0x0000782EDBBD0350
0000782edbbd0067  nop [rax+rax*1], ax
0000782edbbd0070  nop [rax+rax*1], eax
0000782edbbd0078  mov eax, 0x41055C
0000782edbbd007d  mov [r15+0x100], rax
0000782edbbd0084  jmp 0x0000782EDB9FE110
0000782edbbd0089  cmp dword ptr [r15+0x318], 0x00
0000782edbbd0091  jz 0x0000782EDBBD0120
0000782edbbd0097  nop [rax+rax*1], ax
0000782edbbd00a0  nop [rax+rax*1], eax
0000782edbbd00a8  mov eax, 0x4104D0
0000782edbbd00ad  mov [r15+0x100], rax
0000782edbbd00b4  jmp 0x0000782EDB9FE110
0000782edbbd00b9  int3
0000782edbbd00ba  call 0x0000782EDBA0DAE0
0000782edbbd00bf  jmp 0x0000782EDBBCFE28
0000782edbbd00c4  call 0x0000782EDBAC0230
0000782edbbd00c9  jmp 0x0000782EDBBCFE31
0000782edbbd00ce  call 0x0000782EDBAE26A0
0000782edbbd00d3  jmp 0x0000782EDBBCFE55
0000782edbbd00d8  call 0x0000782EDBAE1430
0000782edbbd00dd  jmp 0x0000782EDBBCFE5E
0000782edbbd00e2  call 0x0000782EDBAE26A0
0000782edbbd00e7  jmp 0x0000782EDBBCFE7F
0000782edbbd00ec  call 0x0000782EDBAE1430
0000782edbbd00f1  jmp 0x0000782EDBBCFE88
0000782edbbd00f6  call 0x0000782EDBAE26A0
0000782edbbd00fb  jmp 0x0000782EDBBCFEA9
0000782edbbd0100  call 0x0000782EDBAD5890
0000782edbbd0105  jmp 0x0000782EDBBCFEB2
0000782edbbd010a  call 0x0000782EDBABDD50
0000782edbbd010f  jmp 0x0000782EDBBCFF48
0000782edbbd0114  call 0x0000782EDBADA580
0000782edbbd0119  jmp 0x0000782EDBBCFF7F
0000782edbbd011e  int3
0000782edbbd011f  nop
0000782edbbd0120  mov eax, [r15+0xB8]
0000782edbbd0127  mov [rsp+0x10], eax
0000782edbbd012b  mov eax, eax
0000782edbbd012d  mov [r15+0x30], rax
0000782edbbd0131  mov eax, [r15+0xC0]
0000782edbbd0138  mov [rsp+0x20], eax
0000782edbbd013c  mov eax, eax
0000782edbbd013e  mov [r15+0xA0], rax
0000782edbbd0145  mov eax, [r15+0x28]
0000782edbbd0149  mov r14d, [r15+0x98]
0000782edbbd0150  mov [rsp+0x30], r14d
0000782edbbd0155  mov r14d, r14d
0000782edbbd0158  mov [r15+0x28], r14
0000782edbbd015c  mov r14d, [r15+0x38]
0000782edbbd0160  mov [rsp+0x40], r14d
0000782edbbd0165  mov r14d, r14d
0000782edbbd0168  mov [r15+0x98], r14
0000782edbbd016f  mov r14d, [r15+0xA8]
0000782edbbd0176  mov [rsp+0x50], r14d
0000782edbbd017b  mov r14d, r14d
0000782edbbd017e  mov [r15+0x38], r14
0000782edbbd0182  mov r14d, [rsp+0x10]
0000782edbbd0187  mov r12d, [rsp+0x10]
0000782edbbd018c  shrd r14d, r12d, 0x06
0000782edbbd0191  mov r11d, [r15+0xC8]
0000782edbbd0198  mov [rsp+0x10], r12d
0000782edbbd019d  and r12d, r11d
0000782edbbd01a0  mov r10d, [rsp+0x50]
0000782edbbd01a5  mov r9d, [rsp+0x50]
0000782edbbd01aa  shrd r10d, r9d, 0x02
0000782edbbd01af  mov [rsp+0x50], r11d
0000782edbbd01b4  mov r11d, r11d
0000782edbbd01b7  mov [r15+0x20], r11
0000782edbbd01bb  mov r11, [r15+0x88]
0000782edbbd01c2  mov r8, [r15+0x50]
0000782edbbd01c6  lea rbp, [r8+r11*1]
0000782edbbd01ca  mov r8d, [r13+rbp*1]
0000782edbbd01cf  mov ebp, [rsp+0x20]
0000782edbbd01d3  mov edi, [rsp+0x10]
0000782edbbd01d7  andn esi, edi, ebp
0000782edbbd01dc  mov edx, [r15+0xB0]
0000782edbbd01e3  lea ecx, [r12d+edx*1]
0000782edbbd01e8  rorx r12d, edi, 0x0B
0000782edbbd01ee  xor r14d, r12d
0000782edbbd01f1  rorx r12d, r9d, 0x0D
0000782edbbd01f7  xor r10d, r12d
0000782edbbd01fa  lea r12d, [ecx+esi*1]
0000782edbbd01ff  mov rsi, [r15+0x48]
0000782edbbd0203  lea rdx, [rsi+r11*1]
0000782edbbd0207  mov esi, [r13+rdx*1]
0000782edbbd020c  mov edx, [rsp+0x30]
0000782edbbd0210  mov ecx, [rsp+0x40]
0000782edbbd0214  and edx, ecx
0000782edbbd0216  mov [rsp+0x10], edx
0000782edbbd021a  mov edx, edx
0000782edbbd021c  mov [r15+0xD8], rdx
0000782edbbd0223  lea edx, [r12d+r8d*1]
0000782edbbd0228  mov r12d, [rsp+0x30]
0000782edbbd022d  xor r12d, ecx
0000782edbbd0230  rorx r8d, edi, 0x19
0000782edbbd0236  xor r14d, r8d
0000782edbbd0239  and r12d, r9d
0000782edbbd023c  rorx r8d, r9d, 0x16
0000782edbbd0242  xor r10d, r8d
0000782edbbd0245  mov [rsp+0x20], r10d
0000782edbbd024a  mov r10d, r10d
0000782edbbd024d  mov [r15+0xD0], r10
0000782edbbd0254  lea r10d, [edx+esi*1]
0000782edbbd0259  mov r9d, [rsp+0x10]
0000782edbbd025e  xor r12d, r9d
0000782edbbd0261  lea r9d, [r10d+r14d*1]
0000782edbbd0266  lea r14, [r11+0x04]
0000782edbbd026a  mov [r15+0x88], r14
0000782edbbd0271  mov r11d, [rsp+0x20]
0000782edbbd0276  lea r10d, [r12d+r11d*1]
0000782edbbd027b  lea r11d, [r9d+eax*1]
0000782edbbd0280  mov r11d, r11d
0000782edbbd0283  mov [r15+0xB8], r11
0000782edbbd028a  xor eax, eax
0000782edbbd028c  mov r12d, 0x100
0000782edbbd0292  cmp r14, r12
0000782edbbd0295  cmc
0000782edbbd0296  lahf
0000782edbbd0297  seto al
0000782edbbd029a  mov [r15+0x108], eax
0000782edbbd02a1  lea eax, [r10d+r9d*1]
0000782edbbd02a6  mov eax, eax
0000782edbbd02a8  mov [r15+0xA8], rax
0000782edbbd02af  mov ebp, ebp
0000782edbbd02b1  mov [r15+0xB0], rbp
0000782edbbd02b8  mov eax, [rsp+0x50]
0000782edbbd02bc  mov eax, eax
0000782edbbd02be  mov [r15+0xC0], rax
0000782edbbd02c5  mov edi, edi
0000782edbbd02c7  mov [r15+0xC8], rdi
0000782edbbd02ce  mov eax, [r15+0x108]
0000782edbbd02d5  sahf
0000782edbbd02d6  jnz 0x0000782EDBBD0308
0000782edbbd02d8  cmp dword ptr [r15+0x318], 0x00
0000782edbbd02e0  jz 0x0000782EDBBD0350
0000782edbbd02e6  nop [rax+rax*1], ax
0000782edbbd02ef  nop [rax+rax*1], eax
0000782edbbd02f7  mov eax, 0x41055C
0000782edbbd02fc  mov [r15+0x100], rax
0000782edbbd0303  jmp 0x0000782EDB9FE110
0000782edbbd0308  cmp dword ptr [r15+0x318], 0x00
0000782edbbd0310  jz 0x0000782EDBBD0120
0000782edbbd0316  nop [rax+rax*1], ax
0000782edbbd031f  nop [rax+rax*1], eax
0000782edbbd0327  mov eax, 0x4104D0
0000782edbbd032c  mov [r15+0x100], rax
0000782edbbd0333  jmp 0x0000782EDB9FE110
0000782edbbd0338  int3
0000782edbbd0339  call 0x0000782EDBA49010
0000782edbbd033e  jmp 0x0000782EDBBD01CF
0000782edbbd0343  call 0x0000782EDBA25930
0000782edbbd0348  jmp 0x0000782EDBBD020C
0000782edbbd034d  int3
0000782edbbd034e  nop
0000782edbbd0350  mov eax, [r15+0x98]
0000782edbbd0357  mov r14d, [r15+0x70]
0000782edbbd035b  lea r12d, [eax+r14d*1]
0000782edbbd0360  mov eax, [r15+0x28]
0000782edbbd0364  mov r14d, [r15+0x68]
0000782edbbd0368  lea r11d, [eax+r14d*1]
0000782edbbd036d  mov qword ptr [r15+0x88], 0x00
0000782edbbd0378  mov eax, [r15+0xA8]
0000782edbbd037f  mov r14d, [r15+0x78]
0000782edbbd0383  lea r10d, [eax+r14d*1]
0000782edbbd0388  mov [rsp+0x10], r10d
0000782edbbd038d  mov r10d, r10d
0000782edbbd0390  mov [r15+0x78], r10
0000782edbbd0394  mov eax, [r15+0x38]
0000782edbbd0398  mov r14d, [r15+0x80]
0000782edbbd039f  lea r10d, [eax+r14d*1]
0000782edbbd03a4  mov [rsp+0x20], r10d
0000782edbbd03a9  mov r10d, r10d
0000782edbbd03ac  mov [r15+0x80], r10
0000782edbbd03b3  mov rax, [r15]
0000782edbbd03b6  lea r14, [rax+0x08]
0000782edbbd03ba  mov [r13+r14*1], r12d
0000782edbbd03bf  lea r14, [rax+0x0C]
0000782edbbd03c3  mov [r13+r14*1], r11d
0000782edbbd03c8  mov r14d, [r15+0xB8]
0000782edbbd03cf  mov r12d, [r15+0x18]
0000782edbbd03d3  lea r11d, [r14d+r12d*1]
0000782edbbd03d8  mov [rsp+0x30], r11d
0000782edbbd03dd  mov r11d, r11d
0000782edbbd03e0  mov [r15+0x68], r11
0000782edbbd03e4  mov r14d, [r15+0x30]
0000782edbbd03e8  mov r12d, [r15+0x90]
0000782edbbd03ef  lea r11d, [r14d+r12d*1]
0000782edbbd03f4  mov [rsp+0x40], r11d
0000782edbbd03f9  mov r11d, r11d
0000782edbbd03fc  mov [r15+0x70], r11
0000782edbbd0400  mov r14d, [r15+0x20]
0000782edbbd0404  mov r12d, [r15+0x58]
0000782edbbd0408  lea r11d, [r14d+r12d*1]
0000782edbbd040d  mov [rsp+0x50], r11d
0000782edbbd0412  mov r11d, r11d
0000782edbbd0415  mov [r15+0x58], r11
0000782edbbd0419  mov r14d, [r15+0xA0]
0000782edbbd0420  mov r12d, [r15+0x60]
0000782edbbd0424  lea r11d, [r14d+r12d*1]
0000782edbbd0429  mov [rsp+0x60], r11d
0000782edbbd042e  mov r11d, r11d
0000782edbbd0431  mov [r15+0x60], r11
0000782edbbd0435  mov r14d, [rsp+0x10]
0000782edbbd043a  mov [r13+rax*1], r14d
0000782edbbd043f  lea r14, [rax+0x04]
0000782edbbd0443  mov r12d, [rsp+0x20]
0000782edbbd0448  mov [r13+r14*1], r12d
0000782edbbd044d  lea r14, [rax+0x10]
0000782edbbd0451  mov r12d, [rsp+0x30]
0000782edbbd0456  mov [r13+r14*1], r12d
0000782edbbd045b  lea r14, [rax+0x14]
0000782edbbd045f  mov r12d, [rsp+0x40]
0000782edbbd0464  mov [r13+r14*1], r12d
0000782edbbd0469  lea r14, [rax+0x18]
0000782edbbd046d  mov r12d, [rsp+0x50]
0000782edbbd0472  mov [r13+r14*1], r12d
0000782edbbd0477  lea r14, [rax+0x1C]
0000782edbbd047b  mov r12d, [rsp+0x60]
0000782edbbd0480  mov [r13+r14*1], r12d
0000782edbbd0485  lea r14, [rax+0x68]
0000782edbbd0489  xor eax, eax
0000782edbbd048b  mov [r13+r14*1], rax
0000782edbbd0490  cmp dword ptr [r15+0x318], 0x00
0000782edbbd0498  jz 0x0000782EDBBCEF90
0000782edbbd049e  nop [rax+rax*1], ax
0000782edbbd04a7  nop [rax+rax*1], eax
0000782edbbd04af  mov eax, 0x410378
0000782edbbd04b4  mov [r15+0x100], rax
0000782edbbd04bb  jmp 0x0000782EDB9FE110
0000782edbbd04c0  int3
0000782edbbd04c1  call 0x0000782EDBAE2BA0
0000782edbbd04c6  jmp 0x0000782EDBBD03BF
0000782edbbd04cb  call 0x0000782EDBAE1920
0000782edbbd04d0  jmp 0x0000782EDBBD03C8
0000782edbbd04d5  call 0x0000782EDBA0DFE0
0000782edbbd04da  jmp 0x0000782EDBBD043F
0000782edbbd04df  call 0x0000782EDBAE2BA0
0000782edbbd04e4  jmp 0x0000782EDBBD044D
0000782edbbd04e9  call 0x0000782EDBAE2BA0
0000782edbbd04ee  jmp 0x0000782EDBBD045B
0000782edbbd04f3  call 0x0000782EDBAE2BA0
0000782edbbd04f8  jmp 0x0000782EDBBD0469
0000782edbbd04fd  call 0x0000782EDBAE2BA0
0000782edbbd0502  jmp 0x0000782EDBBD0477
0000782edbbd0507  call 0x0000782EDBAE2BA0
0000782edbbd050c  jmp 0x0000782EDBBD0485
0000782edbbd0511  call 0x0000782EDBAD5EB0
0000782edbbd0516  jmp 0x0000782EDBBD0490
0000782edbbd051b  int3
0000782edbbd051c  nop [rax], eax
0000782edbbd0520  mov rax, [r15+0xF8]
0000782edbbd0527  lea r14, [rax+0x140]
0000782edbbd052e  mov r12, [r13+r14*1]
0000782edbbd0533  lea r14, [rax+0x148]
0000782edbbd053a  mov r11, [r13+r14*1]
0000782edbbd053f  mov [r15+0xA0], r12
0000782edbbd0546  mov [r15+0x98], r11
0000782edbbd054d  lea r14, [rax+0x130]
0000782edbbd0554  mov r12, [r13+r14*1]
0000782edbbd0559  lea r14, [rax+0x138]
0000782edbbd0560  mov r11, [r13+r14*1]
0000782edbbd0565  mov [r15+0xB0], r12
0000782edbbd056c  mov [r15+0xA8], r11
0000782edbbd0573  lea r14, [rax+0x120]
0000782edbbd057a  mov r12, [r13+r14*1]
0000782edbbd057f  lea r14, [rax+0x128]
0000782edbbd0586  mov r11, [r13+r14*1]
0000782edbbd058b  mov [r15+0xC0], r12
0000782edbbd0592  mov [r15+0xB8], r11
0000782edbbd0599  lea r14, [rax+0x110]
0000782edbbd05a0  mov r12, [r13+r14*1]
0000782edbbd05a5  lea r14, [rax+0x118]
0000782edbbd05ac  mov r11, [r13+r14*1]
0000782edbbd05b1  mov [r15+0xD0], r12
0000782edbbd05b8  mov [r15+0xC8], r11
0000782edbbd05bf  lea r14, [rax+0x100]
0000782edbbd05c6  mov r12, [r13+r14*1]
0000782edbbd05cb  lea r14, [rax+0x108]
0000782edbbd05d2  mov r11, [r13+r14*1]
0000782edbbd05d7  mov [r15+0xE8], r12
0000782edbbd05de  mov [r15+0xD8], r11
0000782edbbd05e5  lea r14, [rax+0x150]
0000782edbbd05ec  mov [r15+0xF8], r14
0000782edbbd05f3  mov rax, [r15+0xF0]
0000782edbbd05fa  mov [r15+0x100], rax
0000782edbbd0601  jmp 0x0000782EDBBCE5C0
0000782edbbd0606  int3
0000782edbbd0607  call 0x0000782EDBAE27E0
0000782edbbd060c  jmp 0x0000782EDBBD0533
0000782edbbd0611  call 0x0000782EDBAE1570
0000782edbbd0616  jmp 0x0000782EDBBD053F
0000782edbbd061b  call 0x0000782EDBAE27E0
0000782edbbd0620  jmp 0x0000782EDBBD0559
0000782edbbd0625  call 0x0000782EDBAE1570
0000782edbbd062a  jmp 0x0000782EDBBD0565
0000782edbbd062f  call 0x0000782EDBAE27E0
0000782edbbd0634  jmp 0x0000782EDBBD057F
0000782edbbd0639  call 0x0000782EDBAE1570
0000782edbbd063e  jmp 0x0000782EDBBD058B
0000782edbbd0643  call 0x0000782EDBAE27E0
0000782edbbd0648  jmp 0x0000782EDBBD05A5
0000782edbbd064d  call 0x0000782EDBAE1570
0000782edbbd0652  jmp 0x0000782EDBBD05B1
0000782edbbd0657  call 0x0000782EDBAE27E0
0000782edbbd065c  jmp 0x0000782EDBBD05CB
0000782edbbd0661  call 0x0000782EDBAE1570
0000782edbbd0666  jmp 0x0000782EDBBD05D7
0000782edbbd066b  int3
0000782edbbd066c  nop [rax], eax
0000782edbbd0670  mov eax, [r15+0xA0]
0000782edbbd0677  mov [rsp+0x10], eax
0000782edbbd067b  xor eax, eax
0000782edbbd067d  mov r14d, [rsp+0x10]
0000782edbbd0682  sub r14d, 0x01
0000782edbbd0686  cmc
0000782edbbd0687  lahf
0000782edbbd0688  seto al
0000782edbbd068b  mov [r15+0x108], eax
0000782edbbd0692  mov r14d, r14d
0000782edbbd0695  mov [r15+0xA0], r14
0000782edbbd069c  mov eax, [r15+0x108]
0000782edbbd06a3  sahf
0000782edbbd06a4  jnz 0x0000782EDBBD06D6
0000782edbbd06a6  cmp dword ptr [r15+0x318], 0x00
0000782edbbd06ae  jz 0x0000782EDBBD07A0
0000782edbbd06b4  nop [rax+rax*1], ax
0000782edbbd06bd  nop [rax+rax*1], eax
0000782edbbd06c5  mov eax, 0x41027C
0000782edbbd06ca  mov [r15+0x100], rax
0000782edbbd06d1  jmp 0x0000782EDB9FE110
0000782edbbd06d6  cmp dword ptr [r15+0x318], 0x00
0000782edbbd06de  jz 0x0000782EDBBD0710
0000782edbbd06e4  nop [rax+rax*1], ax
0000782edbbd06ed  nop [rax+rax*1], eax
0000782edbbd06f5  mov eax, 0x410264
0000782edbbd06fa  mov [r15+0x100], rax
0000782edbbd0701  jmp 0x0000782EDB9FE110
0000782edbbd0706  int3
0000782edbbd0707  int3
0000782edbbd0708  nop [rax+rax*1], eax
0000782edbbd0710  mov rax, [r15+0xF8]
0000782edbbd0717  mov [r15], rax
0000782edbbd071a  mov rax, [r15+0x98]
0000782edbbd0721  mov [r15+0x08], rax
0000782edbbd0725  mov qword ptr [r15+0x10], 0x12C
0000782edbbd072d  mov qword ptr [r15+0xF0], 0x410274
0000782edbbd0738  mov r14d, [r15+0x320]
0000782edbbd073f  mov eax, 0x410274
0000782edbbd0744  mov rcx, 0x782EDBBD0670
0000782edbbd074e  mov [r15+r14*8+0x328], rax
0000782edbbd0756  mov [r15+r14*8+0x368], rcx
0000782edbbd075e  add r14d, 0x01
0000782edbbd0762  and r14d, 0x07
0000782edbbd0766  mov [r15+0x320], r14d
0000782edbbd076d  cmp dword ptr [r15+0x318], 0x00
0000782edbbd0775  jz 0x0000782EDBBCEC20
0000782edbbd077b  nop [rax+rax*1], ax
0000782edbbd0784  nop [rax+rax*1], eax
0000782edbbd078c  mov eax, 0x410338
0000782edbbd0791  mov [r15+0x100], rax
0000782edbbd0798  jmp 0x0000782EDB9FE110
0000782edbbd079d  int3
0000782edbbd079e  int3
0000782edbbd079f  nop
0000782edbbd07a0  mov rax, [r15+0xF8]
0000782edbbd07a7  lea r14, [rax+0x20]
0000782edbbd07ab  mov r12, [r13+r14*1]
0000782edbbd07b0  mov [r15+0x98], r12
0000782edbbd07b7  mov qword ptr [r15+0x40], 0x80
0000782edbbd07bf  mov [r15], rax
0000782edbbd07c2  lea r14, [rax+0x8C]
0000782edbbd07c9  mov [r15+0x08], r14
0000782edbbd07cd  mov qword ptr [r15+0x10], 0x01
0000782edbbd07d5  lea r14, [rax+0x8C]
0000782edbbd07dc  mov eax, 0x80
0000782edbbd07e1  mov [r13+r14*1], al
0000782edbbd07e6  mov qword ptr [r15+0xF0], 0x410298
0000782edbbd07f1  mov r14d, [r15+0x320]
0000782edbbd07f8  mov eax, 0x410298
0000782edbbd07fd  mov rcx, 0x782EDBBD0870
0000782edbbd0807  mov [r15+r14*8+0x328], rax
0000782edbbd080f  mov [r15+r14*8+0x368], rcx
0000782edbbd0817  add r14d, 0x01
0000782edbbd081b  and r14d, 0x07
0000782edbbd081f  mov [r15+0x320], r14d
0000782edbbd0826  cmp dword ptr [r15+0x318], 0x00
0000782edbbd082e  jz 0x0000782EDBBCEC20
0000782edbbd0834  nop [rax+rax*1], ax
0000782edbbd083d  nop [rax+rax*1], eax
0000782edbbd0845  mov eax, 0x410338
0000782edbbd084a  mov [r15+0x100], rax
0000782edbbd0851  jmp 0x0000782EDB9FE110
0000782edbbd0856  int3
0000782edbbd0857  call 0x0000782EDBAE27E0
0000782edbbd085c  jmp 0x0000782EDBBD07B0
0000782edbbd0861  call 0x0000782EDBAD5AF0
0000782edbbd0866  jmp 0x0000782EDBBD07E6
0000782edbbd086b  int3
0000782edbbd086c  nop [rax], eax
0000782edbbd0870  mov rax, [r15+0xF8]
0000782edbbd0877  lea r14, [rax+0x68]
0000782edbbd087b  mov r12, [r13+r14*1]
0000782edbbd0880  mov [r15+0x40], r12
0000782edbbd0884  lea r14, [rax+0x88]
0000782edbbd088b  xor eax, eax
0000782edbbd088d  mov [r13+r14*1], al
0000782edbbd0892  xor eax, eax
0000782edbbd0894  mov r14d, 0x38
0000782edbbd089a  cmp r12, r14
0000782edbbd089d  cmc
0000782edbbd089e  lahf
0000782edbbd089f  seto al
0000782edbbd08a2  mov [r15+0x108], eax
0000782edbbd08a9  mov eax, [r15+0x108]
0000782edbbd08b0  sahf
0000782edbbd08b1  jz 0x0000782EDBBD08E3
0000782edbbd08b3  cmp dword ptr [r15+0x318], 0x00
0000782edbbd08bb  jz 0x0000782EDBBD0930
0000782edbbd08c1  nop [rax+rax*1], ax
0000782edbbd08ca  nop [rax+rax*1], eax
0000782edbbd08d2  mov eax, 0x4102A8
0000782edbbd08d7  mov [r15+0x100], rax
0000782edbbd08de  jmp 0x0000782EDB9FE110
0000782edbbd08e3  cmp dword ptr [r15+0x318], 0x00
0000782edbbd08eb  jz 0x0000782EDBBD0A70
0000782edbbd08f1  nop [rax+rax*1], ax
0000782edbbd08fa  nop [rax+rax*1], eax
0000782edbbd0902  mov eax, 0x4102C4
0000782edbbd0907  mov [r15+0x100], rax
0000782edbbd090e  jmp 0x0000782EDB9FE110
0000782edbbd0913  int3
0000782edbbd0914  call 0x0000782EDBAE27E0
0000782edbbd0919  jmp 0x0000782EDBBD0880
0000782edbbd091e  call 0x0000782EDBAD5AF0
0000782edbbd0923  jmp 0x0000782EDBBD0892
0000782edbbd0928  int3
0000782edbbd0929  nop [rax], eax
0000782edbbd0930  mov rax, [r15+0xF8]
0000782edbbd0937  mov [r15], rax
0000782edbbd093a  lea r14, [rax+0x88]
0000782edbbd0941  mov [r15+0x08], r14
0000782edbbd0945  mov qword ptr [r15+0x10], 0x01
0000782edbbd094d  mov qword ptr [r15+0xF0], 0x4102B8
0000782edbbd0958  mov r14d, [r15+0x320]
0000782edbbd095f  mov eax, 0x4102B8
0000782edbbd0964  mov rcx, 0x782EDBBD09C0
0000782edbbd096e  mov [r15+r14*8+0x328], rax
0000782edbbd0976  mov [r15+r14*8+0x368], rcx
0000782edbbd097e  add r14d, 0x01
0000782edbbd0982  and r14d, 0x07
0000782edbbd0986  mov [r15+0x320], r14d
0000782edbbd098d  cmp dword ptr [r15+0x318], 0x00
0000782edbbd0995  jz 0x0000782EDBBCEC20
0000782edbbd099b  nop [rax+rax*1], ax
0000782edbbd09a4  nop [rax+rax*1], eax
0000782edbbd09ac  mov eax, 0x410338
0000782edbbd09b1  mov [r15+0x100], rax
0000782edbbd09b8  jmp 0x0000782EDB9FE110
0000782edbbd09bd  int3
0000782edbbd09be  int3
0000782edbbd09bf  nop
0000782edbbd09c0  mov rax, [r15+0xF8]
0000782edbbd09c7  lea r14, [rax+0x68]
0000782edbbd09cb  mov rax, [r13+r14*1]
0000782edbbd09d0  mov [r15+0x40], rax
0000782edbbd09d4  mov [rsp+0x10], rax
0000782edbbd09d9  xor eax, eax
0000782edbbd09db  mov r14, [rsp+0x10]
0000782edbbd09e0  mov r12d, 0x38
0000782edbbd09e6  cmp r14, r12
0000782edbbd09e9  cmc
0000782edbbd09ea  lahf
0000782edbbd09eb  seto al
0000782edbbd09ee  mov [r15+0x108], eax
0000782edbbd09f5  mov eax, [r15+0x108]
0000782edbbd09fc  sahf
0000782edbbd09fd  jnz 0x0000782EDBBD0A2F
0000782edbbd09ff  cmp dword ptr [r15+0x318], 0x00
0000782edbbd0a07  jz 0x0000782EDBBD0A70
0000782edbbd0a0d  nop [rax+rax*1], ax
0000782edbbd0a16  nop [rax+rax*1], eax
0000782edbbd0a1e  mov eax, 0x4102C4
0000782edbbd0a23  mov [r15+0x100], rax
0000782edbbd0a2a  jmp 0x0000782EDB9FE110
0000782edbbd0a2f  cmp dword ptr [r15+0x318], 0x00
0000782edbbd0a37  jz 0x0000782EDBBD0930
0000782edbbd0a3d  nop [rax+rax*1], ax
0000782edbbd0a46  nop [rax+rax*1], eax
0000782edbbd0a4e  mov eax, 0x4102A8
0000782edbbd0a53  mov [r15+0x100], rax
0000782edbbd0a5a  jmp 0x0000782EDB9FE110
0000782edbbd0a5f  int3
0000782edbbd0a60  call 0x0000782EDBAD59C0
0000782edbbd0a65  jmp 0x0000782EDBBD09D0
0000782edbbd0a6a  int3
0000782edbbd0a6b  nop [rax+rax*1], eax
0000782edbbd0a70  mov rax, [r15+0x98]
0000782edbbd0a77  rorx r14, rax, 0x3D
0000782edbbd0a7d  and r14, 0xFFFFFFFFFFFFFFF8
0000782edbbd0a81  mov rax, [r15+0xF8]
0000782edbbd0a88  mov [r15], rax
0000782edbbd0a8b  lea r12, [rax+0x78]
0000782edbbd0a8f  mov [r15+0x08], r12
0000782edbbd0a93  mov qword ptr [r15+0x10], 0x08
0000782edbbd0a9b  bswap r14
0000782edbbd0a9e  mov [r15+0x40], r14
0000782edbbd0aa2  lea r12, [rax+0x78]
0000782edbbd0aa6  mov [r13+r12*1], r14
0000782edbbd0aab  mov qword ptr [r15+0xF0], 0x4102E0
0000782edbbd0ab6  mov r14d, [r15+0x320]
0000782edbbd0abd  mov eax, 0x4102E0
0000782edbbd0ac2  mov rcx, 0x782EDBBD0B30
0000782edbbd0acc  mov [r15+r14*8+0x328], rax
0000782edbbd0ad4  mov [r15+r14*8+0x368], rcx
0000782edbbd0adc  add r14d, 0x01
0000782edbbd0ae0  and r14d, 0x07
0000782edbbd0ae4  mov [r15+0x320], r14d
0000782edbbd0aeb  cmp dword ptr [r15+0x318], 0x00
0000782edbbd0af3  jz 0x0000782EDBBCEC20
0000782edbbd0af9  nop [rax+rax*1], ax
0000782edbbd0b02  nop [rax+rax*1], eax
0000782edbbd0b0a  mov eax, 0x410338
0000782edbbd0b0f  mov [r15+0x100], rax
0000782edbbd0b16  jmp 0x0000782EDB9FE110
0000782edbbd0b1b  int3
0000782edbbd0b1c  call 0x0000782EDBAC3FE0
0000782edbbd0b21  jmp 0x0000782EDBBD0AAB
0000782edbbd0b26  int3
0000782edbbd0b27  nop [rax+rax*1], ax
0000782edbbd0b30  mov rax, [r15+0xF8]
0000782edbbd0b37  mov r14d, [r13+rax*1]
0000782edbbd0b3c  lea r12, [rax+0x04]
0000782edbbd0b40  mov r11d, [r13+r12*1]
0000782edbbd0b45  lea r12, [rax+0x08]
0000782edbbd0b49  mov r10d, [r13+r12*1]
0000782edbbd0b4e  lea r12, [rax+0x0C]
0000782edbbd0b52  mov r9d, [r13+r12*1]
0000782edbbd0b57  mov qword ptr [r15+0x48], 0x430860
0000782edbbd0b5f  lea r12, [rax+0x80]
0000782edbbd0b66  mov r8, [r13+r12*1]
0000782edbbd0b6b  mov [r15+0xF0], r8
0000782edbbd0b72  bswap r14d
0000782edbbd0b75  bswap r11d
0000782edbbd0b78  mov r12d, 0x430860
0000782edbbd0b7e  mov [r13+r12*1], r14d
0000782edbbd0b83  mov r14d, 0x430864
0000782edbbd0b89  mov [r13+r14*1], r11d
0000782edbbd0b8e  bswap r10d
0000782edbbd0b91  bswap r9d
0000782edbbd0b94  lea r14, [rax+0x10]
0000782edbbd0b98  mov r12d, [r13+r14*1]
0000782edbbd0b9d  lea r14, [rax+0x14]
0000782edbbd0ba1  mov r11d, [r13+r14*1]
0000782edbbd0ba6  mov r14d, 0x430868
0000782edbbd0bac  mov [r13+r14*1], r10d
0000782edbbd0bb1  mov r14d, 0x43086C
0000782edbbd0bb7  mov [r13+r14*1], r9d
0000782edbbd0bbc  lea r14, [rax+0x90]
0000782edbbd0bc3  mov r10, [r13+r14*1]
0000782edbbd0bc8  lea r14, [rax+0x98]
0000782edbbd0bcf  mov r9, [r13+r14*1]
0000782edbbd0bd4  mov [r15+0xA0], r10
0000782edbbd0bdb  mov [r15+0x98], r9
0000782edbbd0be2  bswap r12d
0000782edbbd0be5  bswap r11d
0000782edbbd0be8  mov [rsp+0x10], r11d
0000782edbbd0bed  mov r11d, r11d
0000782edbbd0bf0  mov [r15+0x58], r11
0000782edbbd0bf4  lea r14, [rax+0x18]
0000782edbbd0bf8  mov r11d, [r13+r14*1]
0000782edbbd0bfd  lea r14, [rax+0x1C]
0000782edbbd0c01  mov r10d, [r13+r14*1]
0000782edbbd0c06  mov [rsp+0x20], r10d
0000782edbbd0c0b  mov r10d, r10d
0000782edbbd0c0e  mov [r15+0x60], r10
0000782edbbd0c12  mov r14d, 0x430870
0000782edbbd0c18  mov [r13+r14*1], r12d
0000782edbbd0c1d  mov r14d, 0x430874
0000782edbbd0c23  mov r12d, [rsp+0x10]
0000782edbbd0c28  mov [r13+r14*1], r12d
0000782edbbd0c2d  bswap r11d
0000782edbbd0c30  mov [rsp+0x10], r11d
0000782edbbd0c35  mov r11d, r11d
0000782edbbd0c38  mov [r15+0x40], r11
0000782edbbd0c3c  mov r14d, [rsp+0x20]
0000782edbbd0c41  bswap r14d
0000782edbbd0c44  mov [rsp+0x20], r14d
0000782edbbd0c49  mov r14d, r14d
0000782edbbd0c4c  mov [r15+0x50], r14
0000782edbbd0c50  mov r14d, 0x430878
0000782edbbd0c56  mov r12d, [rsp+0x10]
0000782edbbd0c5b  mov [r13+r14*1], r12d
0000782edbbd0c60  mov r14d, 0x43087C
0000782edbbd0c66  mov r12d, [rsp+0x20]
0000782edbbd0c6b  mov [r13+r14*1], r12d
0000782edbbd0c70  lea r14, [rax+0xA0]
0000782edbbd0c77  mov [r15+0xF8], r14
0000782edbbd0c7e  mov [r15+0x100], r8
0000782edbbd0c85  jmp 0x0000782EDBBCE5C0
0000782edbbd0c8a  int3
0000782edbbd0c8b  call 0x0000782EDBA0DAE0
0000782edbbd0c90  jmp 0x0000782EDBBD0B3C
0000782edbbd0c95  call 0x0000782EDBAC0230
0000782edbbd0c9a  jmp 0x0000782EDBBD0B45
0000782edbbd0c9f  call 0x0000782EDBABEFC0
0000782edbbd0ca4  jmp 0x0000782EDBBD0B4E
0000782edbbd0ca9  call 0x0000782EDBABDD50
0000782edbbd0cae  jmp 0x0000782EDBBD0B57
0000782edbbd0cb3  call 0x0000782EDBABCC20
0000782edbbd0cb8  jmp 0x0000782EDBBD0B6B
0000782edbbd0cbd  call 0x0000782EDBAC3EA0
0000782edbbd0cc2  jmp 0x0000782EDBBD0B83
0000782edbbd0cc7  call 0x0000782EDBAE1920
0000782edbbd0ccc  jmp 0x0000782EDBBD0B8E
0000782edbbd0cd1  call 0x0000782EDBAE26A0
0000782edbbd0cd6  jmp 0x0000782EDBBD0B9D
0000782edbbd0cdb  call 0x0000782EDBAE1430
0000782edbbd0ce0  jmp 0x0000782EDBBD0BA6
0000782edbbd0ce5  call 0x0000782EDBAE06B0
0000782edbbd0cea  jmp 0x0000782EDBBD0BB1
0000782edbbd0cef  call 0x0000782EDBADF440
0000782edbbd0cf4  jmp 0x0000782EDBBD0BBC
0000782edbbd0cf9  call 0x0000782EDBAE0300
0000782edbbd0cfe  jmp 0x0000782EDBBD0BC8
0000782edbbd0d03  call 0x0000782EDBADF090
0000782edbbd0d08  jmp 0x0000782EDBBD0BD4
0000782edbbd0d0d  call 0x0000782EDBAE1430
0000782edbbd0d12  jmp 0x0000782EDBBD0BFD
0000782edbbd0d17  call 0x0000782EDBAE01C0
0000782edbbd0d1c  jmp 0x0000782EDBBD0C06
0000782edbbd0d21  call 0x0000782EDBAE2BA0
0000782edbbd0d26  jmp 0x0000782EDBBD0C1D
0000782edbbd0d2b  call 0x0000782EDBAE2BA0
0000782edbbd0d30  jmp 0x0000782EDBBD0C2D
0000782edbbd0d35  call 0x0000782EDBAE2BA0
0000782edbbd0d3a  jmp 0x0000782EDBBD0C60
0000782edbbd0d3f  call 0x0000782EDBAE2BA0
0000782edbbd0d44  jmp 0x0000782EDBBD0C70
0000782edbbd0d49  int3
0000782edbbd0d4a  nop [rax+rax*1], ax
0000782edbbd0d50  mov qword ptr [r15+0x100], 0x04
0000782edbbd0d5b  mov esi, 0x00
0000782edbbd0d60  mov edx, 0x09
0000782edbbd0d65  mov rdi, 0x7FFC908E1550
0000782edbbd0d6f  mov rax, 0x59F18BF68970
0000782edbbd0d79  call rax
0000782edbbd0d7b  cmp dword ptr [r15+0x318], 0x00
0000782edbbd0d83  jnz 0x0000782EDB9FE110
0000782edbbd0d89  jmp 0x0000782EDB9FE0A0
0000782edbbd0d8e  int3
0000782edbbd0d8f  int3
