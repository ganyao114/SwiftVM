000074af503ce69b  nop [rax+rax*1], eax
000074af503ce6a0  mov qword ptr [r15+0x40], 0x4201C0
000074af503ce6a8  mov qword ptr [r15+0x48], 0x4203C0
000074af503ce6b0  mov qword ptr [r15+0x60], 0x01
000074af503ce6b8  xorps xmm1, xmm1
000074af503ce6bb  mov eax, 0x41
000074af503ce6c0  vcvtusi2sd xmm1, xmm1, eax
000074af503ce6c6  mulsd xmm1, [0x000074AF4FFFE010]
000074af503ce6ce  movq xmm1, xmm1
000074af503ce6d2  movaps [r15+0x120], xmm1
000074af503ce6da  mov eax, [r15+0x60]
000074af503ce6de  xorps xmm15, xmm15
000074af503ce6e2  vcvtusi2sd xmm15, xmm15, eax
000074af503ce6e8  mulsd xmm15, [0x000074AF4FFFE020]
000074af503ce6f1  movq xmm15, xmm15
000074af503ce6f6  movaps [r15+0x110], xmm15
000074af503ce6fe  mov rax, [r15+0x60]
000074af503ce702  mov [rsp+0x10], rax
000074af503ce707  xor eax, eax
000074af503ce709  mov r14, [rsp+0x10]
000074af503ce70e  mov r12d, 0x40
000074af503ce714  cmp r14, r12
000074af503ce717  cmc
000074af503ce718  lahf
000074af503ce719  seto al
000074af503ce71c  mov [r15+0x108], eax
000074af503ce723  mov qword ptr [r15+0x50], 0x40
000074af503ce72b  movq rax, xmm1
000074af503ce730  mov r12d, 0x4203C0
000074af503ce736  mov [r13+r12*1], rax
000074af503ce73b  movq rax, xmm15
000074af503ce740  mov r12d, 0x4201C0
000074af503ce746  mov [r13+r12*1], rax
000074af503ce74b  mov [r15+0x58], r14
000074af503ce74f  mov eax, [r15+0x108]
000074af503ce756  sahf
000074af503ce757  jnz 0x000074AF503CE789
000074af503ce759  cmp dword ptr [r15+0x318], 0x00
000074af503ce761  jz 0x000074AF503CE910
000074af503ce767  nop [rax+rax*1], ax
000074af503ce770  nop [rax+rax*1], eax
000074af503ce778  mov eax, 0x410074
000074af503ce77d  mov [r15+0x100], rax
000074af503ce784  jmp 0x000074AF501FE110
000074af503ce789  cmp dword ptr [r15+0x318], 0x00
000074af503ce791  jz 0x000074AF503CE7D0
000074af503ce797  nop [rax+rax*1], ax
000074af503ce7a0  nop [rax+rax*1], eax
000074af503ce7a8  mov eax, 0x41004C
000074af503ce7ad  mov [r15+0x100], rax
000074af503ce7b4  jmp 0x000074AF501FE110
000074af503ce7b9  int3
000074af503ce7ba  call 0x000074AF502B4CB0
000074af503ce7bf  jmp 0x000074AF503CE73B
000074af503ce7c4  call 0x000074AF502B4CB0
000074af503ce7c9  jmp 0x000074AF503CE74B
000074af503ce7ce  int3
000074af503ce7cf  nop
000074af503ce7d0  mov rax, [r15+0x58]
000074af503ce7d4  lea r14, [rax+0x01]
000074af503ce7d8  mov [r15+0x60], r14
000074af503ce7dc  mov r14d, [r15+0x50]
000074af503ce7e0  xorps xmm1, xmm1
000074af503ce7e3  vcvtusi2sd xmm1, xmm1, r14d
000074af503ce7e9  mulsd xmm1, [0x000074AF4FFFE010]
000074af503ce7f1  movq xmm1, xmm1
000074af503ce7f5  movaps [r15+0x120], xmm1
000074af503ce7fd  rorx r12, rax, 0x3D
000074af503ce803  and r12, 0xFFFFFFFFFFFFFFF8
000074af503ce807  mov eax, [r15+0x60]
000074af503ce80b  xorps xmm15, xmm15
000074af503ce80f  vcvtusi2sd xmm15, xmm15, eax
000074af503ce815  mulsd xmm15, [0x000074AF4FFFE020]
000074af503ce81e  movq xmm15, xmm15
000074af503ce823  movaps [r15+0x110], xmm15
000074af503ce82b  mov rax, [r15+0x60]
000074af503ce82f  mov [rsp+0x10], rax
000074af503ce834  xor eax, eax
000074af503ce836  mov r11, [rsp+0x10]
000074af503ce83b  mov r10d, 0x40
000074af503ce841  cmp r11, r10
000074af503ce844  cmc
000074af503ce845  lahf
000074af503ce846  seto al
000074af503ce849  mov [r15+0x108], eax
000074af503ce850  lea eax, [r14d-0x01]
000074af503ce855  mov eax, eax
000074af503ce857  mov [r15+0x50], rax
000074af503ce85b  mov rax, [r15+0x48]
000074af503ce85f  lea r14, [rax+r12*1]
000074af503ce863  movq rax, xmm1
000074af503ce868  mov [r13+r14*1], rax
000074af503ce86d  mov rax, [r15+0x40]
000074af503ce871  lea r14, [rax+r12*1]
000074af503ce875  movq rax, xmm15
000074af503ce87a  mov [r13+r14*1], rax
000074af503ce87f  mov [r15+0x58], r11
000074af503ce883  mov eax, [r15+0x108]
000074af503ce88a  sahf
000074af503ce88b  jnz 0x000074AF503CE8BD
000074af503ce88d  cmp dword ptr [r15+0x318], 0x00
000074af503ce895  jz 0x000074AF503CE910
000074af503ce89b  nop [rax+rax*1], ax
000074af503ce8a4  nop [rax+rax*1], eax
000074af503ce8ac  mov eax, 0x410074
000074af503ce8b1  mov [r15+0x100], rax
000074af503ce8b8  jmp 0x000074AF501FE110
000074af503ce8bd  cmp dword ptr [r15+0x318], 0x00
000074af503ce8c5  jz 0x000074AF503CE7D0
000074af503ce8cb  nop [rax+rax*1], ax
000074af503ce8d4  nop [rax+rax*1], eax
000074af503ce8dc  mov eax, 0x41004C
000074af503ce8e1  mov [r15+0x100], rax
000074af503ce8e8  jmp 0x000074AF501FE110
000074af503ce8ed  int3
000074af503ce8ee  call 0x000074AF502D5EB0
000074af503ce8f3  jmp 0x000074AF503CE86D
000074af503ce8f8  call 0x000074AF502D5EB0
000074af503ce8fd  jmp 0x000074AF503CE87F
000074af503ce902  int3
000074af503ce903  nop [rax+rax*1], ax
000074af503ce90c  nop [rax], eax
000074af503ce910  vxorps xmm1, xmm1, xmm1
000074af503ce914  movq xmm1, xmm1
000074af503ce918  movaps [r15+0x110], xmm1
000074af503ce920  mov qword ptr [r15+0x58], 0x00
000074af503ce928  mov qword ptr [r15+0x50], 0x4205C0
000074af503ce930  mov qword ptr [r15+0x60], 0x00
000074af503ce938  mov qword ptr [r15+0x68], 0x4205C0
000074af503ce940  mov rax, [r15+0x40]
000074af503ce944  mov r14, [r13+rax*1]
000074af503ce949  lea r12, [rax+0x08]
000074af503ce94d  mov r11, [r13+r12*1]
000074af503ce952  movq xmm15, r14
000074af503ce957  movq xmm14, r11
000074af503ce95c  movq xmm15, xmm15
000074af503ce961  movq xmm15, xmm15
000074af503ce966  movaps [r15+0x120], xmm15
000074af503ce96e  movq xmm14, xmm14
000074af503ce973  movq xmm14, xmm14
000074af503ce978  movaps [r15+0x130], xmm14
000074af503ce980  lea r14, [rax+0x10]
000074af503ce984  mov r12, [r13+r14*1]
000074af503ce989  lea r14, [rax+0x18]
000074af503ce98d  mov r11, [r13+r14*1]
000074af503ce992  movq xmm15, r12
000074af503ce997  movq xmm14, r11
000074af503ce99c  movq xmm15, xmm15
000074af503ce9a1  movq xmm15, xmm15
000074af503ce9a6  movaps [r15+0x140], xmm15
000074af503ce9ae  movq xmm14, xmm14
000074af503ce9b3  movq xmm14, xmm14
000074af503ce9b8  movaps [r15+0x150], xmm14
000074af503ce9c0  lea r14, [rax+0x20]
000074af503ce9c4  mov r12, [r13+r14*1]
000074af503ce9c9  lea r14, [rax+0x28]
000074af503ce9cd  mov r11, [r13+r14*1]
000074af503ce9d2  movq xmm15, r12
000074af503ce9d7  movq xmm14, r11
000074af503ce9dc  movq xmm15, xmm15
000074af503ce9e1  movq xmm15, xmm15
000074af503ce9e6  movaps [r15+0x160], xmm15
000074af503ce9ee  movq xmm14, xmm14
000074af503ce9f3  movq xmm14, xmm14
000074af503ce9f8  movaps [r15+0x170], xmm14
000074af503cea00  lea r14, [rax+0x30]
000074af503cea04  mov r12, [r13+r14*1]
000074af503cea09  lea r14, [rax+0x38]
000074af503cea0d  mov rax, [r13+r14*1]
000074af503cea12  movq xmm15, r12
000074af503cea17  movq xmm14, rax
000074af503cea1c  movq xmm15, xmm15
000074af503cea21  movq xmm15, xmm15
000074af503cea26  movaps [r15+0x180], xmm15
000074af503cea2e  movq xmm14, xmm14
000074af503cea33  movq xmm14, xmm14
000074af503cea38  movaps [r15+0x210], xmm14
000074af503cea40  mov rax, [r15+0x48]
000074af503cea44  mov [r15+0x78], rax
000074af503cea48  mov r14, [r13+rax*1]
000074af503cea4d  movq xmm15, r14
000074af503cea52  lea r14, [rax+0x40]
000074af503cea56  mov r12, [r13+r14*1]
000074af503cea5b  movq xmm14, r12
000074af503cea60  lea r14, [rax+0x80]
000074af503cea67  mov r12, [r13+r14*1]
000074af503cea6c  movq xmm13, r12
000074af503cea71  movaps xmm12, [r15+0x120]
000074af503cea79  movq r14, xmm12
000074af503cea7e  movq r12, xmm15
000074af503cea83  vmovq xmm15, r14
000074af503cea88  vmovq xmm12, r12
000074af503cea8d  movaps xmm11, xmm15
000074af503cea91  mulsd xmm11, xmm12
000074af503cea96  ucomisd xmm11, xmm11
000074af503cea9b  jp 0x000074AF503CEEFC
000074af503ceaa1  movq xmm11, xmm11
000074af503ceaa6  movaps xmm15, [r15+0x130]
000074af503ceaae  movq r14, xmm15
000074af503ceab3  movq r12, xmm14
000074af503ceab8  vmovq xmm15, r14
000074af503ceabd  vmovq xmm14, r12
000074af503ceac2  movaps xmm12, xmm15
000074af503ceac6  mulsd xmm12, xmm14
000074af503ceacb  ucomisd xmm12, xmm12
000074af503cead0  jp 0x000074AF503CEF48
000074af503cead6  movq xmm12, xmm12
000074af503ceadb  movq r14, xmm11
000074af503ceae0  movq r12, xmm1
000074af503ceae5  vmovq xmm1, r14
000074af503ceaea  vmovq xmm15, r12
000074af503ceaef  movaps xmm14, xmm1
000074af503ceaf3  addsd xmm14, xmm15
000074af503ceaf8  ucomisd xmm14, xmm14
000074af503ceafd  jp 0x000074AF503CEF94
000074af503ceb03  movq xmm14, xmm14
000074af503ceb08  movq r14, xmm14
000074af503ceb0d  movq r12, xmm12
000074af503ceb12  vmovq xmm1, r14
000074af503ceb17  vmovq xmm15, r12
000074af503ceb1c  movaps xmm14, xmm1
000074af503ceb20  addsd xmm14, xmm15
000074af503ceb25  ucomisd xmm14, xmm14
000074af503ceb2a  jp 0x000074AF503CEFE0
000074af503ceb30  movq xmm14, xmm14
000074af503ceb35  movaps xmm1, [r15+0x140]
000074af503ceb3d  movq r14, xmm1
000074af503ceb42  movq r12, xmm13
000074af503ceb47  vmovq xmm1, r14
000074af503ceb4c  vmovq xmm15, r12
000074af503ceb51  movaps xmm13, xmm1
000074af503ceb55  mulsd xmm13, xmm15
000074af503ceb5a  ucomisd xmm13, xmm13
000074af503ceb5f  jp 0x000074AF503CF02C
000074af503ceb65  movq xmm13, xmm13
000074af503ceb6a  lea r14, [rax+0xC0]
000074af503ceb71  mov r12, [r13+r14*1]
000074af503ceb76  movq xmm1, r12
000074af503ceb7b  movq r14, xmm14
000074af503ceb80  movq r12, xmm13
000074af503ceb85  vmovq xmm15, r14
000074af503ceb8a  vmovq xmm14, r12
000074af503ceb8f  movaps xmm13, xmm15
000074af503ceb93  addsd xmm13, xmm14
000074af503ceb98  ucomisd xmm13, xmm13
000074af503ceb9d  jp 0x000074AF503CF082
000074af503ceba3  movq xmm13, xmm13
000074af503ceba8  movaps xmm15, [r15+0x150]
000074af503cebb0  movq r14, xmm15
000074af503cebb5  movq r12, xmm1
000074af503cebba  vmovq xmm1, r14
000074af503cebbf  vmovq xmm15, r12
000074af503cebc4  movaps xmm14, xmm1
000074af503cebc8  mulsd xmm14, xmm15
000074af503cebcd  ucomisd xmm14, xmm14
000074af503cebd2  jp 0x000074AF503CF0CE
000074af503cebd8  movq xmm14, xmm14
000074af503cebdd  lea r14, [rax+0x100]
000074af503cebe4  mov r12, [r13+r14*1]
000074af503cebe9  movq xmm1, r12
000074af503cebee  movq r14, xmm13
000074af503cebf3  movq r12, xmm14
000074af503cebf8  vmovq xmm15, r14
000074af503cebfd  vmovq xmm14, r12
000074af503cec02  movaps xmm13, xmm15
000074af503cec06  addsd xmm13, xmm14
000074af503cec0b  ucomisd xmm13, xmm13
000074af503cec10  jp 0x000074AF503CF124
000074af503cec16  movq xmm13, xmm13
000074af503cec1b  movaps xmm15, [r15+0x160]
000074af503cec23  movq r14, xmm15
000074af503cec28  movq r12, xmm1
000074af503cec2d  vmovq xmm1, r14
000074af503cec32  vmovq xmm15, r12
000074af503cec37  movaps xmm14, xmm1
000074af503cec3b  mulsd xmm14, xmm15
000074af503cec40  ucomisd xmm14, xmm14
000074af503cec45  jp 0x000074AF503CF170
000074af503cec4b  movq xmm14, xmm14
000074af503cec50  lea r14, [rax+0x140]
000074af503cec57  mov r12, [r13+r14*1]
000074af503cec5c  movq xmm1, r12
000074af503cec61  movq r14, xmm13
000074af503cec66  movq r12, xmm14
000074af503cec6b  vmovq xmm15, r14
000074af503cec70  vmovq xmm14, r12
000074af503cec75  movaps xmm13, xmm15
000074af503cec79  addsd xmm13, xmm14
000074af503cec7e  ucomisd xmm13, xmm13
000074af503cec83  jp 0x000074AF503CF1C6
000074af503cec89  movq xmm13, xmm13
000074af503cec8e  movaps xmm15, [r15+0x170]
000074af503cec96  movq r14, xmm15
000074af503cec9b  movq r12, xmm1
000074af503ceca0  vmovq xmm1, r14
000074af503ceca5  vmovq xmm15, r12
000074af503cecaa  movaps xmm14, xmm1
000074af503cecae  mulsd xmm14, xmm15
000074af503cecb3  ucomisd xmm14, xmm14
000074af503cecb8  jp 0x000074AF503CF212
000074af503cecbe  movq xmm14, xmm14
000074af503cecc3  lea r14, [rax+0x180]
000074af503cecca  mov r12, [r13+r14*1]
000074af503ceccf  movq xmm1, r12
000074af503cecd4  movq r14, xmm13
000074af503cecd9  movq r12, xmm14
000074af503cecde  vmovq xmm15, r14
000074af503cece3  vmovq xmm14, r12
000074af503cece8  movaps xmm13, xmm15
000074af503cecec  addsd xmm13, xmm14
000074af503cecf1  ucomisd xmm13, xmm13
000074af503cecf6  jp 0x000074AF503CF268
000074af503cecfc  movq xmm13, xmm13
000074af503ced01  movaps xmm15, [r15+0x180]
000074af503ced09  movq r14, xmm15
000074af503ced0e  movq r12, xmm1
000074af503ced13  vmovq xmm1, r14
000074af503ced18  vmovq xmm15, r12
000074af503ced1d  movaps xmm14, xmm1
000074af503ced21  mulsd xmm14, xmm15
000074af503ced26  ucomisd xmm14, xmm14
000074af503ced2b  jp 0x000074AF503CF2B4
000074af503ced31  movq xmm14, xmm14
000074af503ced36  lea r14, [rax+0x1C0]
000074af503ced3d  mov rax, [r13+r14*1]
000074af503ced42  movq xmm1, rax
000074af503ced47  movaps [r15+0x240], xmm1
000074af503ced4f  movq rax, xmm13
000074af503ced54  movq r14, xmm14
000074af503ced59  vmovq xmm15, rax
000074af503ced5e  vmovq xmm14, r14
000074af503ced63  movaps xmm13, xmm15
000074af503ced67  addsd xmm13, xmm14
000074af503ced6c  ucomisd xmm13, xmm13
000074af503ced71  jp 0x000074AF503CF30A
000074af503ced77  movq xmm13, xmm13
000074af503ced7c  movaps xmm15, [r15+0x210]
000074af503ced84  movq rax, xmm15
000074af503ced89  movq r14, xmm1
000074af503ced8e  vmovq xmm1, rax
000074af503ced93  vmovq xmm15, r14
000074af503ced98  movaps xmm14, xmm1
000074af503ced9c  mulsd xmm14, xmm15
000074af503ceda1  ucomisd xmm14, xmm14
000074af503ceda6  jp 0x000074AF503CF352
000074af503cedac  movq xmm14, xmm14
000074af503cedb1  movaps [r15+0x230], xmm14
000074af503cedb9  movq rax, xmm13
000074af503cedbe  movq r14, xmm14
000074af503cedc3  vmovq xmm1, rax
000074af503cedc8  vmovq xmm15, r14
000074af503cedcd  movaps xmm14, xmm1
000074af503cedd1  addsd xmm14, xmm15
000074af503cedd6  ucomisd xmm14, xmm14
000074af503ceddb  jp 0x000074AF503CF39A
000074af503cede1  movq xmm14, xmm14
000074af503cede6  movaps [r15+0x220], xmm14
000074af503cedee  movq rax, xmm14
000074af503cedf3  mov r14d, 0x4205C0
000074af503cedf9  mov [r13+r14*1], rax
000074af503cedfe  mov qword ptr [r15+0x70], 0x08
000074af503cee06  xor eax, eax
000074af503cee08  mov r14d, 0x08
000074af503cee0e  mov r12d, 0x40
000074af503cee14  cmp r14, r12
000074af503cee17  cmc
000074af503cee18  lahf
000074af503cee19  seto al
000074af503cee1c  mov [r15+0x108], eax
000074af503cee23  mov eax, [r15+0x108]
000074af503cee2a  sahf
000074af503cee2b  jnz 0x000074AF503CEE5D
000074af503cee2d  cmp dword ptr [r15+0x318], 0x00
000074af503cee35  jz 0x000074AF503CFD40
000074af503cee3b  nop [rax+rax*1], ax
000074af503cee44  nop [rax+rax*1], eax
000074af503cee4c  mov eax, 0x410118
000074af503cee51  mov [r15+0x100], rax
000074af503cee58  jmp 0x000074AF501FE110
000074af503cee5d  cmp dword ptr [r15+0x318], 0x00
000074af503cee65  jz 0x000074AF503CF3F0
000074af503cee6b  nop [rax+rax*1], ax
000074af503cee74  nop [rax+rax*1], eax
000074af503cee7c  mov eax, 0x4100A4
000074af503cee81  mov [r15+0x100], rax
000074af503cee88  jmp 0x000074AF501FE110
000074af503cee8d  int3
000074af503cee8e  call 0x000074AF5020DC20
000074af503cee93  jmp 0x000074AF503CE949
000074af503cee98  call 0x000074AF502C0370
000074af503cee9d  jmp 0x000074AF503CE952
000074af503ceea2  call 0x000074AF502E27E0
000074af503ceea7  jmp 0x000074AF503CE989
000074af503ceeac  call 0x000074AF502E1570
000074af503ceeb1  jmp 0x000074AF503CE992
000074af503ceeb6  call 0x000074AF502E27E0
000074af503ceebb  jmp 0x000074AF503CE9C9
000074af503ceec0  call 0x000074AF502E1570
000074af503ceec5  jmp 0x000074AF503CE9D2
000074af503ceeca  call 0x000074AF502E27E0
000074af503ceecf  jmp 0x000074AF503CEA09
000074af503ceed4  call 0x000074AF502D59C0
000074af503ceed9  jmp 0x000074AF503CEA12
000074af503ceede  call 0x000074AF5020DC20
000074af503ceee3  jmp 0x000074AF503CEA4D
000074af503ceee8  call 0x000074AF502E27E0
000074af503ceeed  jmp 0x000074AF503CEA5B
000074af503ceef2  call 0x000074AF502E27E0
000074af503ceef7  jmp 0x000074AF503CEA6C
000074af503ceefc  ucomisd xmm15, xmm12
000074af503cef01  jp 0x000074AF503CEF10
000074af503cef03  movaps xmm11, [0x000074AF4FFFE030]
000074af503cef0b  jmp 0x000074AF503CEAA1
000074af503cef10  vxorps xmm0, xmm15, xmm12
000074af503cef15  pextrw r14d, xmm0, 0x03
000074af503cef1b  and r14d, 0x7FF8
000074af503cef22  cmp r14d, 0x08
000074af503cef26  jnz 0x000074AF503CEAA1
000074af503cef2c  movq r14, xmm12
000074af503cef31  shl r14, 0x0D
000074af503cef35  jbe 0x000074AF503CEAA1
000074af503cef3b  vorps xmm11, xmm12, [0x000074AF4FFFE040]
000074af503cef43  jmp 0x000074AF503CEAA1
000074af503cef48  ucomisd xmm15, xmm14
000074af503cef4d  jp 0x000074AF503CEF5C
000074af503cef4f  movaps xmm12, [0x000074AF4FFFE030]
000074af503cef57  jmp 0x000074AF503CEAD6
000074af503cef5c  vxorps xmm0, xmm15, xmm14
000074af503cef61  pextrw r14d, xmm0, 0x03
000074af503cef67  and r14d, 0x7FF8
000074af503cef6e  cmp r14d, 0x08
000074af503cef72  jnz 0x000074AF503CEAD6
000074af503cef78  movq r14, xmm14
000074af503cef7d  shl r14, 0x0D
000074af503cef81  jbe 0x000074AF503CEAD6
000074af503cef87  vorps xmm12, xmm14, [0x000074AF4FFFE040]
000074af503cef8f  jmp 0x000074AF503CEAD6
000074af503cef94  ucomisd xmm1, xmm15
000074af503cef99  jp 0x000074AF503CEFA8
000074af503cef9b  movaps xmm14, [0x000074AF4FFFE030]
000074af503cefa3  jmp 0x000074AF503CEB03
000074af503cefa8  vxorps xmm0, xmm1, xmm15
000074af503cefad  pextrw r14d, xmm0, 0x03
000074af503cefb3  and r14d, 0x7FF8
000074af503cefba  cmp r14d, 0x08
000074af503cefbe  jnz 0x000074AF503CEB03
000074af503cefc4  movq r14, xmm15
000074af503cefc9  shl r14, 0x0D
000074af503cefcd  jbe 0x000074AF503CEB03
000074af503cefd3  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cefdb  jmp 0x000074AF503CEB03
000074af503cefe0  ucomisd xmm1, xmm15
000074af503cefe5  jp 0x000074AF503CEFF4
000074af503cefe7  movaps xmm14, [0x000074AF4FFFE030]
000074af503cefef  jmp 0x000074AF503CEB30
000074af503ceff4  vxorps xmm0, xmm1, xmm15
000074af503ceff9  pextrw r14d, xmm0, 0x03
000074af503cefff  and r14d, 0x7FF8
000074af503cf006  cmp r14d, 0x08
000074af503cf00a  jnz 0x000074AF503CEB30
000074af503cf010  movq r14, xmm15
000074af503cf015  shl r14, 0x0D
000074af503cf019  jbe 0x000074AF503CEB30
000074af503cf01f  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cf027  jmp 0x000074AF503CEB30
000074af503cf02c  ucomisd xmm1, xmm15
000074af503cf031  jp 0x000074AF503CF040
000074af503cf033  movaps xmm13, [0x000074AF4FFFE030]
000074af503cf03b  jmp 0x000074AF503CEB65
000074af503cf040  vxorps xmm0, xmm1, xmm15
000074af503cf045  pextrw r14d, xmm0, 0x03
000074af503cf04b  and r14d, 0x7FF8
000074af503cf052  cmp r14d, 0x08
000074af503cf056  jnz 0x000074AF503CEB65
000074af503cf05c  movq r14, xmm15
000074af503cf061  shl r14, 0x0D
000074af503cf065  jbe 0x000074AF503CEB65
000074af503cf06b  vorps xmm13, xmm15, [0x000074AF4FFFE040]
000074af503cf073  jmp 0x000074AF503CEB65
000074af503cf078  call 0x000074AF502E27E0
000074af503cf07d  jmp 0x000074AF503CEB76
000074af503cf082  ucomisd xmm15, xmm14
000074af503cf087  jp 0x000074AF503CF096
000074af503cf089  movaps xmm13, [0x000074AF4FFFE030]
000074af503cf091  jmp 0x000074AF503CEBA3
000074af503cf096  vxorps xmm0, xmm15, xmm14
000074af503cf09b  pextrw r14d, xmm0, 0x03
000074af503cf0a1  and r14d, 0x7FF8
000074af503cf0a8  cmp r14d, 0x08
000074af503cf0ac  jnz 0x000074AF503CEBA3
000074af503cf0b2  movq r14, xmm14
000074af503cf0b7  shl r14, 0x0D
000074af503cf0bb  jbe 0x000074AF503CEBA3
000074af503cf0c1  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503cf0c9  jmp 0x000074AF503CEBA3
000074af503cf0ce  ucomisd xmm1, xmm15
000074af503cf0d3  jp 0x000074AF503CF0E2
000074af503cf0d5  movaps xmm14, [0x000074AF4FFFE030]
000074af503cf0dd  jmp 0x000074AF503CEBD8
000074af503cf0e2  vxorps xmm0, xmm1, xmm15
000074af503cf0e7  pextrw r14d, xmm0, 0x03
000074af503cf0ed  and r14d, 0x7FF8
000074af503cf0f4  cmp r14d, 0x08
000074af503cf0f8  jnz 0x000074AF503CEBD8
000074af503cf0fe  movq r14, xmm15
000074af503cf103  shl r14, 0x0D
000074af503cf107  jbe 0x000074AF503CEBD8
000074af503cf10d  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cf115  jmp 0x000074AF503CEBD8
000074af503cf11a  call 0x000074AF502E27E0
000074af503cf11f  jmp 0x000074AF503CEBE9
000074af503cf124  ucomisd xmm15, xmm14
000074af503cf129  jp 0x000074AF503CF138
000074af503cf12b  movaps xmm13, [0x000074AF4FFFE030]
000074af503cf133  jmp 0x000074AF503CEC16
000074af503cf138  vxorps xmm0, xmm15, xmm14
000074af503cf13d  pextrw r14d, xmm0, 0x03
000074af503cf143  and r14d, 0x7FF8
000074af503cf14a  cmp r14d, 0x08
000074af503cf14e  jnz 0x000074AF503CEC16
000074af503cf154  movq r14, xmm14
000074af503cf159  shl r14, 0x0D
000074af503cf15d  jbe 0x000074AF503CEC16
000074af503cf163  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503cf16b  jmp 0x000074AF503CEC16
000074af503cf170  ucomisd xmm1, xmm15
000074af503cf175  jp 0x000074AF503CF184
000074af503cf177  movaps xmm14, [0x000074AF4FFFE030]
000074af503cf17f  jmp 0x000074AF503CEC4B
000074af503cf184  vxorps xmm0, xmm1, xmm15
000074af503cf189  pextrw r14d, xmm0, 0x03
000074af503cf18f  and r14d, 0x7FF8
000074af503cf196  cmp r14d, 0x08
000074af503cf19a  jnz 0x000074AF503CEC4B
000074af503cf1a0  movq r14, xmm15
000074af503cf1a5  shl r14, 0x0D
000074af503cf1a9  jbe 0x000074AF503CEC4B
000074af503cf1af  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cf1b7  jmp 0x000074AF503CEC4B
000074af503cf1bc  call 0x000074AF502E27E0
000074af503cf1c1  jmp 0x000074AF503CEC5C
000074af503cf1c6  ucomisd xmm15, xmm14
000074af503cf1cb  jp 0x000074AF503CF1DA
000074af503cf1cd  movaps xmm13, [0x000074AF4FFFE030]
000074af503cf1d5  jmp 0x000074AF503CEC89
000074af503cf1da  vxorps xmm0, xmm15, xmm14
000074af503cf1df  pextrw r14d, xmm0, 0x03
000074af503cf1e5  and r14d, 0x7FF8
000074af503cf1ec  cmp r14d, 0x08
000074af503cf1f0  jnz 0x000074AF503CEC89
000074af503cf1f6  movq r14, xmm14
000074af503cf1fb  shl r14, 0x0D
000074af503cf1ff  jbe 0x000074AF503CEC89
000074af503cf205  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503cf20d  jmp 0x000074AF503CEC89
000074af503cf212  ucomisd xmm1, xmm15
000074af503cf217  jp 0x000074AF503CF226
000074af503cf219  movaps xmm14, [0x000074AF4FFFE030]
000074af503cf221  jmp 0x000074AF503CECBE
000074af503cf226  vxorps xmm0, xmm1, xmm15
000074af503cf22b  pextrw r14d, xmm0, 0x03
000074af503cf231  and r14d, 0x7FF8
000074af503cf238  cmp r14d, 0x08
000074af503cf23c  jnz 0x000074AF503CECBE
000074af503cf242  movq r14, xmm15
000074af503cf247  shl r14, 0x0D
000074af503cf24b  jbe 0x000074AF503CECBE
000074af503cf251  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cf259  jmp 0x000074AF503CECBE
000074af503cf25e  call 0x000074AF502E27E0
000074af503cf263  jmp 0x000074AF503CECCF
000074af503cf268  ucomisd xmm15, xmm14
000074af503cf26d  jp 0x000074AF503CF27C
000074af503cf26f  movaps xmm13, [0x000074AF4FFFE030]
000074af503cf277  jmp 0x000074AF503CECFC
000074af503cf27c  vxorps xmm0, xmm15, xmm14
000074af503cf281  pextrw r14d, xmm0, 0x03
000074af503cf287  and r14d, 0x7FF8
000074af503cf28e  cmp r14d, 0x08
000074af503cf292  jnz 0x000074AF503CECFC
000074af503cf298  movq r14, xmm14
000074af503cf29d  shl r14, 0x0D
000074af503cf2a1  jbe 0x000074AF503CECFC
000074af503cf2a7  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503cf2af  jmp 0x000074AF503CECFC
000074af503cf2b4  ucomisd xmm1, xmm15
000074af503cf2b9  jp 0x000074AF503CF2C8
000074af503cf2bb  movaps xmm14, [0x000074AF4FFFE030]
000074af503cf2c3  jmp 0x000074AF503CED31
000074af503cf2c8  vxorps xmm0, xmm1, xmm15
000074af503cf2cd  pextrw r14d, xmm0, 0x03
000074af503cf2d3  and r14d, 0x7FF8
000074af503cf2da  cmp r14d, 0x08
000074af503cf2de  jnz 0x000074AF503CED31
000074af503cf2e4  movq r14, xmm15
000074af503cf2e9  shl r14, 0x0D
000074af503cf2ed  jbe 0x000074AF503CED31
000074af503cf2f3  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cf2fb  jmp 0x000074AF503CED31
000074af503cf300  call 0x000074AF502D59C0
000074af503cf305  jmp 0x000074AF503CED42
000074af503cf30a  ucomisd xmm15, xmm14
000074af503cf30f  jp 0x000074AF503CF31E
000074af503cf311  movaps xmm13, [0x000074AF4FFFE030]
000074af503cf319  jmp 0x000074AF503CED77
000074af503cf31e  vxorps xmm0, xmm15, xmm14
000074af503cf323  pextrw eax, xmm0, 0x03
000074af503cf328  and eax, 0x7FF8
000074af503cf32d  cmp eax, 0x08
000074af503cf330  jnz 0x000074AF503CED77
000074af503cf336  movq rax, xmm14
000074af503cf33b  shl rax, 0x0D
000074af503cf33f  jbe 0x000074AF503CED77
000074af503cf345  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503cf34d  jmp 0x000074AF503CED77
000074af503cf352  ucomisd xmm1, xmm15
000074af503cf357  jp 0x000074AF503CF366
000074af503cf359  movaps xmm14, [0x000074AF4FFFE030]
000074af503cf361  jmp 0x000074AF503CEDAC
000074af503cf366  vxorps xmm0, xmm1, xmm15
000074af503cf36b  pextrw eax, xmm0, 0x03
000074af503cf370  and eax, 0x7FF8
000074af503cf375  cmp eax, 0x08
000074af503cf378  jnz 0x000074AF503CEDAC
000074af503cf37e  movq rax, xmm15
000074af503cf383  shl rax, 0x0D
000074af503cf387  jbe 0x000074AF503CEDAC
000074af503cf38d  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cf395  jmp 0x000074AF503CEDAC
000074af503cf39a  ucomisd xmm1, xmm15
000074af503cf39f  jp 0x000074AF503CF3AE
000074af503cf3a1  movaps xmm14, [0x000074AF4FFFE030]
000074af503cf3a9  jmp 0x000074AF503CEDE1
000074af503cf3ae  vxorps xmm0, xmm1, xmm15
000074af503cf3b3  pextrw eax, xmm0, 0x03
000074af503cf3b8  and eax, 0x7FF8
000074af503cf3bd  cmp eax, 0x08
000074af503cf3c0  jnz 0x000074AF503CEDE1
000074af503cf3c6  movq rax, xmm15
000074af503cf3cb  shl rax, 0x0D
000074af503cf3cf  jbe 0x000074AF503CEDE1
000074af503cf3d5  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cf3dd  jmp 0x000074AF503CEDE1
000074af503cf3e2  call 0x000074AF502D5EB0
000074af503cf3e7  jmp 0x000074AF503CEDFE
000074af503cf3ec  int3
000074af503cf3ed  nop [rax], eax
000074af503cf3f0  mov rax, [r15+0x48]
000074af503cf3f4  mov r14, [r15+0x70]
000074af503cf3f8  lea r12, [rax+r14*1]
000074af503cf3fc  mov [r15+0x78], r12
000074af503cf400  mov rax, [r13+r12*1]
000074af503cf405  movq xmm1, rax
000074af503cf40a  lea rax, [r12+0x40]
000074af503cf40f  mov r11, [r13+rax*1]
000074af503cf414  movq xmm15, r11
000074af503cf419  lea rax, [r12+0x80]
000074af503cf421  mov r11, [r13+rax*1]
000074af503cf426  movq xmm14, r11
000074af503cf42b  movaps xmm13, [r15+0x120]
000074af503cf433  movq rax, xmm13
000074af503cf438  movq r11, xmm1
000074af503cf43d  vmovq xmm1, rax
000074af503cf442  vmovq xmm13, r11
000074af503cf447  movaps xmm12, xmm1
000074af503cf44b  mulsd xmm12, xmm13
000074af503cf450  ucomisd xmm12, xmm12
000074af503cf455  jp 0x000074AF503CF879
000074af503cf45b  movq xmm12, xmm12
000074af503cf460  movaps xmm1, [r15+0x130]
000074af503cf468  movq rax, xmm1
000074af503cf46d  movq r11, xmm15
000074af503cf472  vmovq xmm1, rax
000074af503cf477  vmovq xmm15, r11
000074af503cf47c  movaps xmm13, xmm1
000074af503cf480  mulsd xmm13, xmm15
000074af503cf485  ucomisd xmm13, xmm13
000074af503cf48a  jp 0x000074AF503CF8C1
000074af503cf490  movq xmm13, xmm13
000074af503cf495  movq rax, xmm12
000074af503cf49a  movaps xmm1, [r15+0x110]
000074af503cf4a2  movq r11, xmm1
000074af503cf4a7  vmovq xmm1, rax
000074af503cf4ac  vmovq xmm15, r11
000074af503cf4b1  movaps xmm12, xmm1
000074af503cf4b5  addsd xmm12, xmm15
000074af503cf4ba  ucomisd xmm12, xmm12
000074af503cf4bf  jp 0x000074AF503CF909
000074af503cf4c5  movq xmm12, xmm12
000074af503cf4ca  movq rax, xmm12
000074af503cf4cf  movq r11, xmm13
000074af503cf4d4  vmovq xmm1, rax
000074af503cf4d9  vmovq xmm15, r11
000074af503cf4de  movaps xmm13, xmm1
000074af503cf4e2  addsd xmm13, xmm15
000074af503cf4e7  ucomisd xmm13, xmm13
000074af503cf4ec  jp 0x000074AF503CF951
000074af503cf4f2  movq xmm13, xmm13
000074af503cf4f7  movaps xmm1, [r15+0x140]
000074af503cf4ff  movq rax, xmm1
000074af503cf504  movq r11, xmm14
000074af503cf509  vmovq xmm1, rax
000074af503cf50e  vmovq xmm15, r11
000074af503cf513  movaps xmm14, xmm1
000074af503cf517  mulsd xmm14, xmm15
000074af503cf51c  ucomisd xmm14, xmm14
000074af503cf521  jp 0x000074AF503CF999
000074af503cf527  movq xmm14, xmm14
000074af503cf52c  lea rax, [r12+0xC0]
000074af503cf534  mov r11, [r13+rax*1]
000074af503cf539  movq xmm1, r11
000074af503cf53e  movq rax, xmm13
000074af503cf543  movq r11, xmm14
000074af503cf548  vmovq xmm15, rax
000074af503cf54d  vmovq xmm14, r11
000074af503cf552  movaps xmm13, xmm15
000074af503cf556  addsd xmm13, xmm14
000074af503cf55b  ucomisd xmm13, xmm13
000074af503cf560  jp 0x000074AF503CF9EB
000074af503cf566  movq xmm13, xmm13
000074af503cf56b  movaps xmm15, [r15+0x150]
000074af503cf573  movq rax, xmm15
000074af503cf578  movq r11, xmm1
000074af503cf57d  vmovq xmm1, rax
000074af503cf582  vmovq xmm15, r11
000074af503cf587  movaps xmm14, xmm1
000074af503cf58b  mulsd xmm14, xmm15
000074af503cf590  ucomisd xmm14, xmm14
000074af503cf595  jp 0x000074AF503CFA33
000074af503cf59b  movq xmm14, xmm14
000074af503cf5a0  lea rax, [r12+0x100]
000074af503cf5a8  mov r11, [r13+rax*1]
000074af503cf5ad  movq xmm1, r11
000074af503cf5b2  movq rax, xmm13
000074af503cf5b7  movq r11, xmm14
000074af503cf5bc  vmovq xmm15, rax
000074af503cf5c1  vmovq xmm14, r11
000074af503cf5c6  movaps xmm13, xmm15
000074af503cf5ca  addsd xmm13, xmm14
000074af503cf5cf  ucomisd xmm13, xmm13
000074af503cf5d4  jp 0x000074AF503CFA85
000074af503cf5da  movq xmm13, xmm13
000074af503cf5df  movaps xmm15, [r15+0x160]
000074af503cf5e7  movq rax, xmm15
000074af503cf5ec  movq r11, xmm1
000074af503cf5f1  vmovq xmm1, rax
000074af503cf5f6  vmovq xmm15, r11
000074af503cf5fb  movaps xmm14, xmm1
000074af503cf5ff  mulsd xmm14, xmm15
000074af503cf604  ucomisd xmm14, xmm14
000074af503cf609  jp 0x000074AF503CFACD
000074af503cf60f  movq xmm14, xmm14
000074af503cf614  lea rax, [r12+0x140]
000074af503cf61c  mov r11, [r13+rax*1]
000074af503cf621  movq xmm1, r11
000074af503cf626  movq rax, xmm13
000074af503cf62b  movq r11, xmm14
000074af503cf630  vmovq xmm15, rax
000074af503cf635  vmovq xmm14, r11
000074af503cf63a  movaps xmm13, xmm15
000074af503cf63e  addsd xmm13, xmm14
000074af503cf643  ucomisd xmm13, xmm13
000074af503cf648  jp 0x000074AF503CFB1F
000074af503cf64e  movq xmm13, xmm13
000074af503cf653  movaps xmm15, [r15+0x170]
000074af503cf65b  movq rax, xmm15
000074af503cf660  movq r11, xmm1
000074af503cf665  vmovq xmm1, rax
000074af503cf66a  vmovq xmm15, r11
000074af503cf66f  movaps xmm14, xmm1
000074af503cf673  mulsd xmm14, xmm15
000074af503cf678  ucomisd xmm14, xmm14
000074af503cf67d  jp 0x000074AF503CFB67
000074af503cf683  movq xmm14, xmm14
000074af503cf688  lea rax, [r12+0x180]
000074af503cf690  mov r11, [r13+rax*1]
000074af503cf695  movq xmm1, r11
000074af503cf69a  movq rax, xmm13
000074af503cf69f  movq r11, xmm14
000074af503cf6a4  vmovq xmm15, rax
000074af503cf6a9  vmovq xmm14, r11
000074af503cf6ae  movaps xmm13, xmm15
000074af503cf6b2  addsd xmm13, xmm14
000074af503cf6b7  ucomisd xmm13, xmm13
000074af503cf6bc  jp 0x000074AF503CFBB9
000074af503cf6c2  movq xmm13, xmm13
000074af503cf6c7  movaps xmm15, [r15+0x180]
000074af503cf6cf  movq rax, xmm15
000074af503cf6d4  movq r11, xmm1
000074af503cf6d9  vmovq xmm1, rax
000074af503cf6de  vmovq xmm15, r11
000074af503cf6e3  movaps xmm14, xmm1
000074af503cf6e7  mulsd xmm14, xmm15
000074af503cf6ec  ucomisd xmm14, xmm14
000074af503cf6f1  jp 0x000074AF503CFC01
000074af503cf6f7  movq xmm14, xmm14
000074af503cf6fc  lea rax, [r12+0x1C0]
000074af503cf704  mov r12, [r13+rax*1]
000074af503cf709  movq xmm1, r12
000074af503cf70e  movaps [r15+0x240], xmm1
000074af503cf716  movq rax, xmm13
000074af503cf71b  movq r12, xmm14
000074af503cf720  vmovq xmm15, rax
000074af503cf725  vmovq xmm14, r12
000074af503cf72a  movaps xmm13, xmm15
000074af503cf72e  addsd xmm13, xmm14
000074af503cf733  ucomisd xmm13, xmm13
000074af503cf738  jp 0x000074AF503CFC53
000074af503cf73e  movq xmm13, xmm13
000074af503cf743  movaps xmm15, [r15+0x210]
000074af503cf74b  movq rax, xmm15
000074af503cf750  movq r12, xmm1
000074af503cf755  vmovq xmm1, rax
000074af503cf75a  vmovq xmm15, r12
000074af503cf75f  movaps xmm14, xmm1
000074af503cf763  mulsd xmm14, xmm15
000074af503cf768  ucomisd xmm14, xmm14
000074af503cf76d  jp 0x000074AF503CFC9B
000074af503cf773  movq xmm14, xmm14
000074af503cf778  movaps [r15+0x230], xmm14
000074af503cf780  movq rax, xmm13
000074af503cf785  movq r12, xmm14
000074af503cf78a  vmovq xmm1, rax
000074af503cf78f  vmovq xmm15, r12
000074af503cf794  movaps xmm14, xmm1
000074af503cf798  addsd xmm14, xmm15
000074af503cf79d  ucomisd xmm14, xmm14
000074af503cf7a2  jp 0x000074AF503CFCE3
000074af503cf7a8  movq xmm14, xmm14
000074af503cf7ad  movaps [r15+0x220], xmm14
000074af503cf7b5  mov rax, [r15+0x68]
000074af503cf7b9  lea r12, [rax+r14*1]
000074af503cf7bd  movq rax, xmm14
000074af503cf7c2  mov [r13+r12*1], rax
000074af503cf7c7  lea rax, [r14+0x08]
000074af503cf7cb  mov [r15+0x70], rax
000074af503cf7cf  mov [rsp+0x10], rax
000074af503cf7d4  xor eax, eax
000074af503cf7d6  mov r14, [rsp+0x10]
000074af503cf7db  mov r12d, 0x40
000074af503cf7e1  cmp r14, r12
000074af503cf7e4  cmc
000074af503cf7e5  lahf
000074af503cf7e6  seto al
000074af503cf7e9  mov [r15+0x108], eax
000074af503cf7f0  mov eax, [r15+0x108]
000074af503cf7f7  sahf
000074af503cf7f8  jnz 0x000074AF503CF82A
000074af503cf7fa  cmp dword ptr [r15+0x318], 0x00
000074af503cf802  jz 0x000074AF503CFD40
000074af503cf808  nop [rax+rax*1], ax
000074af503cf811  nop [rax+rax*1], eax
000074af503cf819  mov eax, 0x410118
000074af503cf81e  mov [r15+0x100], rax
000074af503cf825  jmp 0x000074AF501FE110
000074af503cf82a  cmp dword ptr [r15+0x318], 0x00
000074af503cf832  jz 0x000074AF503CF3F0
000074af503cf838  nop [rax+rax*1], ax
000074af503cf841  nop [rax+rax*1], eax
000074af503cf849  mov eax, 0x4100A4
000074af503cf84e  mov [r15+0x100], rax
000074af503cf855  jmp 0x000074AF501FE110
000074af503cf85a  int3
000074af503cf85b  call 0x000074AF502B47C0
000074af503cf860  jmp 0x000074AF503CF405
000074af503cf865  call 0x000074AF5020A4B0
000074af503cf86a  jmp 0x000074AF503CF414
000074af503cf86f  call 0x000074AF5020A4B0
000074af503cf874  jmp 0x000074AF503CF426
000074af503cf879  ucomisd xmm1, xmm13
000074af503cf87e  jp 0x000074AF503CF88D
000074af503cf880  movaps xmm12, [0x000074AF4FFFE030]
000074af503cf888  jmp 0x000074AF503CF45B
000074af503cf88d  vxorps xmm0, xmm1, xmm13
000074af503cf892  pextrw eax, xmm0, 0x03
000074af503cf897  and eax, 0x7FF8
000074af503cf89c  cmp eax, 0x08
000074af503cf89f  jnz 0x000074AF503CF45B
000074af503cf8a5  movq rax, xmm13
000074af503cf8aa  shl rax, 0x0D
000074af503cf8ae  jbe 0x000074AF503CF45B
000074af503cf8b4  vorps xmm12, xmm13, [0x000074AF4FFFE040]
000074af503cf8bc  jmp 0x000074AF503CF45B
000074af503cf8c1  ucomisd xmm1, xmm15
000074af503cf8c6  jp 0x000074AF503CF8D5
000074af503cf8c8  movaps xmm13, [0x000074AF4FFFE030]
000074af503cf8d0  jmp 0x000074AF503CF490
000074af503cf8d5  vxorps xmm0, xmm1, xmm15
000074af503cf8da  pextrw eax, xmm0, 0x03
000074af503cf8df  and eax, 0x7FF8
000074af503cf8e4  cmp eax, 0x08
000074af503cf8e7  jnz 0x000074AF503CF490
000074af503cf8ed  movq rax, xmm15
000074af503cf8f2  shl rax, 0x0D
000074af503cf8f6  jbe 0x000074AF503CF490
000074af503cf8fc  vorps xmm13, xmm15, [0x000074AF4FFFE040]
000074af503cf904  jmp 0x000074AF503CF490
000074af503cf909  ucomisd xmm1, xmm15
000074af503cf90e  jp 0x000074AF503CF91D
000074af503cf910  movaps xmm12, [0x000074AF4FFFE030]
000074af503cf918  jmp 0x000074AF503CF4C5
000074af503cf91d  vxorps xmm0, xmm1, xmm15
000074af503cf922  pextrw eax, xmm0, 0x03
000074af503cf927  and eax, 0x7FF8
000074af503cf92c  cmp eax, 0x08
000074af503cf92f  jnz 0x000074AF503CF4C5
000074af503cf935  movq rax, xmm15
000074af503cf93a  shl rax, 0x0D
000074af503cf93e  jbe 0x000074AF503CF4C5
000074af503cf944  vorps xmm12, xmm15, [0x000074AF4FFFE040]
000074af503cf94c  jmp 0x000074AF503CF4C5
000074af503cf951  ucomisd xmm1, xmm15
000074af503cf956  jp 0x000074AF503CF965
000074af503cf958  movaps xmm13, [0x000074AF4FFFE030]
000074af503cf960  jmp 0x000074AF503CF4F2
000074af503cf965  vxorps xmm0, xmm1, xmm15
000074af503cf96a  pextrw eax, xmm0, 0x03
000074af503cf96f  and eax, 0x7FF8
000074af503cf974  cmp eax, 0x08
000074af503cf977  jnz 0x000074AF503CF4F2
000074af503cf97d  movq rax, xmm15
000074af503cf982  shl rax, 0x0D
000074af503cf986  jbe 0x000074AF503CF4F2
000074af503cf98c  vorps xmm13, xmm15, [0x000074AF4FFFE040]
000074af503cf994  jmp 0x000074AF503CF4F2
000074af503cf999  ucomisd xmm1, xmm15
000074af503cf99e  jp 0x000074AF503CF9AD
000074af503cf9a0  movaps xmm14, [0x000074AF4FFFE030]
000074af503cf9a8  jmp 0x000074AF503CF527
000074af503cf9ad  vxorps xmm0, xmm1, xmm15
000074af503cf9b2  pextrw eax, xmm0, 0x03
000074af503cf9b7  and eax, 0x7FF8
000074af503cf9bc  cmp eax, 0x08
000074af503cf9bf  jnz 0x000074AF503CF527
000074af503cf9c5  movq rax, xmm15
000074af503cf9ca  shl rax, 0x0D
000074af503cf9ce  jbe 0x000074AF503CF527
000074af503cf9d4  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cf9dc  jmp 0x000074AF503CF527
000074af503cf9e1  call 0x000074AF5020A4B0
000074af503cf9e6  jmp 0x000074AF503CF539
000074af503cf9eb  ucomisd xmm15, xmm14
000074af503cf9f0  jp 0x000074AF503CF9FF
000074af503cf9f2  movaps xmm13, [0x000074AF4FFFE030]
000074af503cf9fa  jmp 0x000074AF503CF566
000074af503cf9ff  vxorps xmm0, xmm15, xmm14
000074af503cfa04  pextrw eax, xmm0, 0x03
000074af503cfa09  and eax, 0x7FF8
000074af503cfa0e  cmp eax, 0x08
000074af503cfa11  jnz 0x000074AF503CF566
000074af503cfa17  movq rax, xmm14
000074af503cfa1c  shl rax, 0x0D
000074af503cfa20  jbe 0x000074AF503CF566
000074af503cfa26  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503cfa2e  jmp 0x000074AF503CF566
000074af503cfa33  ucomisd xmm1, xmm15
000074af503cfa38  jp 0x000074AF503CFA47
000074af503cfa3a  movaps xmm14, [0x000074AF4FFFE030]
000074af503cfa42  jmp 0x000074AF503CF59B
000074af503cfa47  vxorps xmm0, xmm1, xmm15
000074af503cfa4c  pextrw eax, xmm0, 0x03
000074af503cfa51  and eax, 0x7FF8
000074af503cfa56  cmp eax, 0x08
000074af503cfa59  jnz 0x000074AF503CF59B
000074af503cfa5f  movq rax, xmm15
000074af503cfa64  shl rax, 0x0D
000074af503cfa68  jbe 0x000074AF503CF59B
000074af503cfa6e  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cfa76  jmp 0x000074AF503CF59B
000074af503cfa7b  call 0x000074AF5020A4B0
000074af503cfa80  jmp 0x000074AF503CF5AD
000074af503cfa85  ucomisd xmm15, xmm14
000074af503cfa8a  jp 0x000074AF503CFA99
000074af503cfa8c  movaps xmm13, [0x000074AF4FFFE030]
000074af503cfa94  jmp 0x000074AF503CF5DA
000074af503cfa99  vxorps xmm0, xmm15, xmm14
000074af503cfa9e  pextrw eax, xmm0, 0x03
000074af503cfaa3  and eax, 0x7FF8
000074af503cfaa8  cmp eax, 0x08
000074af503cfaab  jnz 0x000074AF503CF5DA
000074af503cfab1  movq rax, xmm14
000074af503cfab6  shl rax, 0x0D
000074af503cfaba  jbe 0x000074AF503CF5DA
000074af503cfac0  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503cfac8  jmp 0x000074AF503CF5DA
000074af503cfacd  ucomisd xmm1, xmm15
000074af503cfad2  jp 0x000074AF503CFAE1
000074af503cfad4  movaps xmm14, [0x000074AF4FFFE030]
000074af503cfadc  jmp 0x000074AF503CF60F
000074af503cfae1  vxorps xmm0, xmm1, xmm15
000074af503cfae6  pextrw eax, xmm0, 0x03
000074af503cfaeb  and eax, 0x7FF8
000074af503cfaf0  cmp eax, 0x08
000074af503cfaf3  jnz 0x000074AF503CF60F
000074af503cfaf9  movq rax, xmm15
000074af503cfafe  shl rax, 0x0D
000074af503cfb02  jbe 0x000074AF503CF60F
000074af503cfb08  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cfb10  jmp 0x000074AF503CF60F
000074af503cfb15  call 0x000074AF5020A4B0
000074af503cfb1a  jmp 0x000074AF503CF621
000074af503cfb1f  ucomisd xmm15, xmm14
000074af503cfb24  jp 0x000074AF503CFB33
000074af503cfb26  movaps xmm13, [0x000074AF4FFFE030]
000074af503cfb2e  jmp 0x000074AF503CF64E
000074af503cfb33  vxorps xmm0, xmm15, xmm14
000074af503cfb38  pextrw eax, xmm0, 0x03
000074af503cfb3d  and eax, 0x7FF8
000074af503cfb42  cmp eax, 0x08
000074af503cfb45  jnz 0x000074AF503CF64E
000074af503cfb4b  movq rax, xmm14
000074af503cfb50  shl rax, 0x0D
000074af503cfb54  jbe 0x000074AF503CF64E
000074af503cfb5a  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503cfb62  jmp 0x000074AF503CF64E
000074af503cfb67  ucomisd xmm1, xmm15
000074af503cfb6c  jp 0x000074AF503CFB7B
000074af503cfb6e  movaps xmm14, [0x000074AF4FFFE030]
000074af503cfb76  jmp 0x000074AF503CF683
000074af503cfb7b  vxorps xmm0, xmm1, xmm15
000074af503cfb80  pextrw eax, xmm0, 0x03
000074af503cfb85  and eax, 0x7FF8
000074af503cfb8a  cmp eax, 0x08
000074af503cfb8d  jnz 0x000074AF503CF683
000074af503cfb93  movq rax, xmm15
000074af503cfb98  shl rax, 0x0D
000074af503cfb9c  jbe 0x000074AF503CF683
000074af503cfba2  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cfbaa  jmp 0x000074AF503CF683
000074af503cfbaf  call 0x000074AF5020A4B0
000074af503cfbb4  jmp 0x000074AF503CF695
000074af503cfbb9  ucomisd xmm15, xmm14
000074af503cfbbe  jp 0x000074AF503CFBCD
000074af503cfbc0  movaps xmm13, [0x000074AF4FFFE030]
000074af503cfbc8  jmp 0x000074AF503CF6C2
000074af503cfbcd  vxorps xmm0, xmm15, xmm14
000074af503cfbd2  pextrw eax, xmm0, 0x03
000074af503cfbd7  and eax, 0x7FF8
000074af503cfbdc  cmp eax, 0x08
000074af503cfbdf  jnz 0x000074AF503CF6C2
000074af503cfbe5  movq rax, xmm14
000074af503cfbea  shl rax, 0x0D
000074af503cfbee  jbe 0x000074AF503CF6C2
000074af503cfbf4  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503cfbfc  jmp 0x000074AF503CF6C2
000074af503cfc01  ucomisd xmm1, xmm15
000074af503cfc06  jp 0x000074AF503CFC15
000074af503cfc08  movaps xmm14, [0x000074AF4FFFE030]
000074af503cfc10  jmp 0x000074AF503CF6F7
000074af503cfc15  vxorps xmm0, xmm1, xmm15
000074af503cfc1a  pextrw eax, xmm0, 0x03
000074af503cfc1f  and eax, 0x7FF8
000074af503cfc24  cmp eax, 0x08
000074af503cfc27  jnz 0x000074AF503CF6F7
000074af503cfc2d  movq rax, xmm15
000074af503cfc32  shl rax, 0x0D
000074af503cfc36  jbe 0x000074AF503CF6F7
000074af503cfc3c  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cfc44  jmp 0x000074AF503CF6F7
000074af503cfc49  call 0x000074AF5020B720
000074af503cfc4e  jmp 0x000074AF503CF709
000074af503cfc53  ucomisd xmm15, xmm14
000074af503cfc58  jp 0x000074AF503CFC67
000074af503cfc5a  movaps xmm13, [0x000074AF4FFFE030]
000074af503cfc62  jmp 0x000074AF503CF73E
000074af503cfc67  vxorps xmm0, xmm15, xmm14
000074af503cfc6c  pextrw eax, xmm0, 0x03
000074af503cfc71  and eax, 0x7FF8
000074af503cfc76  cmp eax, 0x08
000074af503cfc79  jnz 0x000074AF503CF73E
000074af503cfc7f  movq rax, xmm14
000074af503cfc84  shl rax, 0x0D
000074af503cfc88  jbe 0x000074AF503CF73E
000074af503cfc8e  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503cfc96  jmp 0x000074AF503CF73E
000074af503cfc9b  ucomisd xmm1, xmm15
000074af503cfca0  jp 0x000074AF503CFCAF
000074af503cfca2  movaps xmm14, [0x000074AF4FFFE030]
000074af503cfcaa  jmp 0x000074AF503CF773
000074af503cfcaf  vxorps xmm0, xmm1, xmm15
000074af503cfcb4  pextrw eax, xmm0, 0x03
000074af503cfcb9  and eax, 0x7FF8
000074af503cfcbe  cmp eax, 0x08
000074af503cfcc1  jnz 0x000074AF503CF773
000074af503cfcc7  movq rax, xmm15
000074af503cfccc  shl rax, 0x0D
000074af503cfcd0  jbe 0x000074AF503CF773
000074af503cfcd6  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cfcde  jmp 0x000074AF503CF773
000074af503cfce3  ucomisd xmm1, xmm15
000074af503cfce8  jp 0x000074AF503CFCF7
000074af503cfcea  movaps xmm14, [0x000074AF4FFFE030]
000074af503cfcf2  jmp 0x000074AF503CF7A8
000074af503cfcf7  vxorps xmm0, xmm1, xmm15
000074af503cfcfc  pextrw eax, xmm0, 0x03
000074af503cfd01  and eax, 0x7FF8
000074af503cfd06  cmp eax, 0x08
000074af503cfd09  jnz 0x000074AF503CF7A8
000074af503cfd0f  movq rax, xmm15
000074af503cfd14  shl rax, 0x0D
000074af503cfd18  jbe 0x000074AF503CF7A8
000074af503cfd1e  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503cfd26  jmp 0x000074AF503CF7A8
000074af503cfd2b  call 0x000074AF502B4CB0
000074af503cfd30  jmp 0x000074AF503CF7C7
000074af503cfd35  int3
000074af503cfd36  nop [rax+rax*1], ax
000074af503cfd3f  nop
000074af503cfd40  mov rax, [r15+0x60]
000074af503cfd44  lea r14, [rax+0x01]
000074af503cfd48  mov [r15+0x60], r14
000074af503cfd4c  mov rax, [r15+0x68]
000074af503cfd50  lea r12, [rax+0x40]
000074af503cfd54  mov [r15+0x68], r12
000074af503cfd58  xor eax, eax
000074af503cfd5a  mov r12d, 0x08
000074af503cfd60  cmp r14, r12
000074af503cfd63  cmc
000074af503cfd64  lahf
000074af503cfd65  seto al
000074af503cfd68  mov [r15+0x108], eax
000074af503cfd6f  mov eax, [r15+0x108]
000074af503cfd76  sahf
000074af503cfd77  jnz 0x000074AF503CFDA9
000074af503cfd79  cmp dword ptr [r15+0x318], 0x00
000074af503cfd81  jz 0x000074AF503D08A0
000074af503cfd87  nop [rax+rax*1], ax
000074af503cfd90  nop [rax+rax*1], eax
000074af503cfd98  mov eax, 0x410128
000074af503cfd9d  mov [r15+0x100], rax
000074af503cfda4  jmp 0x000074AF501FE110
000074af503cfda9  cmp dword ptr [r15+0x318], 0x00
000074af503cfdb1  jz 0x000074AF503CFDE0
000074af503cfdb7  nop [rax+rax*1], ax
000074af503cfdc0  nop [rax+rax*1], eax
000074af503cfdc8  mov eax, 0x41008C
000074af503cfdcd  mov [r15+0x100], rax
000074af503cfdd4  jmp 0x000074AF501FE110
000074af503cfdd9  int3
000074af503cfdda  int3
000074af503cfddb  nop [rax+rax*1], eax
000074af503cfde0  mov rax, [r15+0x40]
000074af503cfde4  mov r14, [r15+0x60]
000074af503cfde8  shl r14, 0x06
000074af503cfdec  lea r12, [rax+r14*1]
000074af503cfdf0  mov rax, [r13+r12*1]
000074af503cfdf5  lea r14, [r12+0x08]
000074af503cfdfa  mov r11, [r13+r14*1]
000074af503cfdff  movq xmm1, rax
000074af503cfe04  movq xmm15, r11
000074af503cfe09  movq xmm1, xmm1
000074af503cfe0d  movq xmm1, xmm1
000074af503cfe11  movaps [r15+0x120], xmm1
000074af503cfe19  movq xmm15, xmm15
000074af503cfe1e  movq xmm15, xmm15
000074af503cfe23  movaps [r15+0x130], xmm15
000074af503cfe2b  lea rax, [r12+0x10]
000074af503cfe30  mov r14, [r13+rax*1]
000074af503cfe35  lea rax, [r12+0x18]
000074af503cfe3a  mov r11, [r13+rax*1]
000074af503cfe3f  movq xmm1, r14
000074af503cfe44  movq xmm15, r11
000074af503cfe49  movq xmm1, xmm1
000074af503cfe4d  movq xmm1, xmm1
000074af503cfe51  movaps [r15+0x140], xmm1
000074af503cfe59  movq xmm15, xmm15
000074af503cfe5e  movq xmm15, xmm15
000074af503cfe63  movaps [r15+0x150], xmm15
000074af503cfe6b  lea rax, [r12+0x20]
000074af503cfe70  mov r14, [r13+rax*1]
000074af503cfe75  lea rax, [r12+0x28]
000074af503cfe7a  mov r11, [r13+rax*1]
000074af503cfe7f  movq xmm1, r14
000074af503cfe84  movq xmm15, r11
000074af503cfe89  movq xmm1, xmm1
000074af503cfe8d  movq xmm1, xmm1
000074af503cfe91  movaps [r15+0x160], xmm1
000074af503cfe99  movq xmm15, xmm15
000074af503cfe9e  movq xmm15, xmm15
000074af503cfea3  movaps [r15+0x170], xmm15
000074af503cfeab  lea rax, [r12+0x30]
000074af503cfeb0  mov r14, [r13+rax*1]
000074af503cfeb5  lea rax, [r12+0x38]
000074af503cfeba  mov r12, [r13+rax*1]
000074af503cfebf  movq xmm1, r14
000074af503cfec4  movq xmm15, r12
000074af503cfec9  movq xmm1, xmm1
000074af503cfecd  movq xmm1, xmm1
000074af503cfed1  movaps [r15+0x180], xmm1
000074af503cfed9  movq xmm15, xmm15
000074af503cfede  movq xmm15, xmm15
000074af503cfee3  movaps [r15+0x210], xmm15
000074af503cfeeb  mov rax, [r15+0x48]
000074af503cfeef  mov [r15+0x78], rax
000074af503cfef3  mov r14, [r13+rax*1]
000074af503cfef8  movq xmm1, r14
000074af503cfefd  lea r14, [rax+0x40]
000074af503cff01  mov r12, [r13+r14*1]
000074af503cff06  movq xmm15, r12
000074af503cff0b  lea r14, [rax+0x80]
000074af503cff12  mov r12, [r13+r14*1]
000074af503cff17  movq xmm14, r12
000074af503cff1c  movaps xmm13, [r15+0x120]
000074af503cff24  movq r14, xmm13
000074af503cff29  movq r12, xmm1
000074af503cff2e  vmovq xmm1, r14
000074af503cff33  vmovq xmm13, r12
000074af503cff38  movaps xmm12, xmm1
000074af503cff3c  mulsd xmm12, xmm13
000074af503cff41  ucomisd xmm12, xmm12
000074af503cff46  jp 0x000074AF503D03AD
000074af503cff4c  movq xmm12, xmm12
000074af503cff51  movaps xmm1, [r15+0x130]
000074af503cff59  movq r14, xmm1
000074af503cff5e  movq r12, xmm15
000074af503cff63  vmovq xmm1, r14
000074af503cff68  vmovq xmm15, r12
000074af503cff6d  movaps xmm13, xmm1
000074af503cff71  mulsd xmm13, xmm15
000074af503cff76  ucomisd xmm13, xmm13
000074af503cff7b  jp 0x000074AF503D03F9
000074af503cff81  movq xmm13, xmm13
000074af503cff86  movq r14, xmm12
000074af503cff8b  movaps xmm1, [r15+0x110]
000074af503cff93  movq r12, xmm1
000074af503cff98  vmovq xmm1, r14
000074af503cff9d  vmovq xmm15, r12
000074af503cffa2  movaps xmm12, xmm1
000074af503cffa6  addsd xmm12, xmm15
000074af503cffab  ucomisd xmm12, xmm12
000074af503cffb0  jp 0x000074AF503D0445
000074af503cffb6  movq xmm12, xmm12
000074af503cffbb  movq r14, xmm12
000074af503cffc0  movq r12, xmm13
000074af503cffc5  vmovq xmm1, r14
000074af503cffca  vmovq xmm15, r12
000074af503cffcf  movaps xmm13, xmm1
000074af503cffd3  addsd xmm13, xmm15
000074af503cffd8  ucomisd xmm13, xmm13
000074af503cffdd  jp 0x000074AF503D0491
000074af503cffe3  movq xmm13, xmm13
000074af503cffe8  movaps xmm1, [r15+0x140]
000074af503cfff0  movq r14, xmm1
000074af503cfff5  movq r12, xmm14
000074af503cfffa  vmovq xmm1, r14
000074af503cffff  vmovq xmm15, r12
000074af503d0004  movaps xmm14, xmm1
000074af503d0008  mulsd xmm14, xmm15
000074af503d000d  ucomisd xmm14, xmm14
000074af503d0012  jp 0x000074AF503D04DD
000074af503d0018  movq xmm14, xmm14
000074af503d001d  lea r14, [rax+0xC0]
000074af503d0024  mov r12, [r13+r14*1]
000074af503d0029  movq xmm1, r12
000074af503d002e  movq r14, xmm13
000074af503d0033  movq r12, xmm14
000074af503d0038  vmovq xmm15, r14
000074af503d003d  vmovq xmm14, r12
000074af503d0042  movaps xmm13, xmm15
000074af503d0046  addsd xmm13, xmm14
000074af503d004b  ucomisd xmm13, xmm13
000074af503d0050  jp 0x000074AF503D0533
000074af503d0056  movq xmm13, xmm13
000074af503d005b  movaps xmm15, [r15+0x150]
000074af503d0063  movq r14, xmm15
000074af503d0068  movq r12, xmm1
000074af503d006d  vmovq xmm1, r14
000074af503d0072  vmovq xmm15, r12
000074af503d0077  movaps xmm14, xmm1
000074af503d007b  mulsd xmm14, xmm15
000074af503d0080  ucomisd xmm14, xmm14
000074af503d0085  jp 0x000074AF503D057F
000074af503d008b  movq xmm14, xmm14
000074af503d0090  lea r14, [rax+0x100]
000074af503d0097  mov r12, [r13+r14*1]
000074af503d009c  movq xmm1, r12
000074af503d00a1  movq r14, xmm13
000074af503d00a6  movq r12, xmm14
000074af503d00ab  vmovq xmm15, r14
000074af503d00b0  vmovq xmm14, r12
000074af503d00b5  movaps xmm13, xmm15
000074af503d00b9  addsd xmm13, xmm14
000074af503d00be  ucomisd xmm13, xmm13
000074af503d00c3  jp 0x000074AF503D05D5
000074af503d00c9  movq xmm13, xmm13
000074af503d00ce  movaps xmm15, [r15+0x160]
000074af503d00d6  movq r14, xmm15
000074af503d00db  movq r12, xmm1
000074af503d00e0  vmovq xmm1, r14
000074af503d00e5  vmovq xmm15, r12
000074af503d00ea  movaps xmm14, xmm1
000074af503d00ee  mulsd xmm14, xmm15
000074af503d00f3  ucomisd xmm14, xmm14
000074af503d00f8  jp 0x000074AF503D0621
000074af503d00fe  movq xmm14, xmm14
000074af503d0103  lea r14, [rax+0x140]
000074af503d010a  mov r12, [r13+r14*1]
000074af503d010f  movq xmm1, r12
000074af503d0114  movq r14, xmm13
000074af503d0119  movq r12, xmm14
000074af503d011e  vmovq xmm15, r14
000074af503d0123  vmovq xmm14, r12
000074af503d0128  movaps xmm13, xmm15
000074af503d012c  addsd xmm13, xmm14
000074af503d0131  ucomisd xmm13, xmm13
000074af503d0136  jp 0x000074AF503D0677
000074af503d013c  movq xmm13, xmm13
000074af503d0141  movaps xmm15, [r15+0x170]
000074af503d0149  movq r14, xmm15
000074af503d014e  movq r12, xmm1
000074af503d0153  vmovq xmm1, r14
000074af503d0158  vmovq xmm15, r12
000074af503d015d  movaps xmm14, xmm1
000074af503d0161  mulsd xmm14, xmm15
000074af503d0166  ucomisd xmm14, xmm14
000074af503d016b  jp 0x000074AF503D06C3
000074af503d0171  movq xmm14, xmm14
000074af503d0176  lea r14, [rax+0x180]
000074af503d017d  mov r12, [r13+r14*1]
000074af503d0182  movq xmm1, r12
000074af503d0187  movq r14, xmm13
000074af503d018c  movq r12, xmm14
000074af503d0191  vmovq xmm15, r14
000074af503d0196  vmovq xmm14, r12
000074af503d019b  movaps xmm13, xmm15
000074af503d019f  addsd xmm13, xmm14
000074af503d01a4  ucomisd xmm13, xmm13
000074af503d01a9  jp 0x000074AF503D0719
000074af503d01af  movq xmm13, xmm13
000074af503d01b4  movaps xmm15, [r15+0x180]
000074af503d01bc  movq r14, xmm15
000074af503d01c1  movq r12, xmm1
000074af503d01c6  vmovq xmm1, r14
000074af503d01cb  vmovq xmm15, r12
000074af503d01d0  movaps xmm14, xmm1
000074af503d01d4  mulsd xmm14, xmm15
000074af503d01d9  ucomisd xmm14, xmm14
000074af503d01de  jp 0x000074AF503D0765
000074af503d01e4  movq xmm14, xmm14
000074af503d01e9  lea r14, [rax+0x1C0]
000074af503d01f0  mov rax, [r13+r14*1]
000074af503d01f5  movq xmm1, rax
000074af503d01fa  movaps [r15+0x240], xmm1
000074af503d0202  movq rax, xmm13
000074af503d0207  movq r14, xmm14
000074af503d020c  vmovq xmm15, rax
000074af503d0211  vmovq xmm14, r14
000074af503d0216  movaps xmm13, xmm15
000074af503d021a  addsd xmm13, xmm14
000074af503d021f  ucomisd xmm13, xmm13
000074af503d0224  jp 0x000074AF503D07BB
000074af503d022a  movq xmm13, xmm13
000074af503d022f  movaps xmm15, [r15+0x210]
000074af503d0237  movq rax, xmm15
000074af503d023c  movq r14, xmm1
000074af503d0241  vmovq xmm1, rax
000074af503d0246  vmovq xmm15, r14
000074af503d024b  movaps xmm14, xmm1
000074af503d024f  mulsd xmm14, xmm15
000074af503d0254  ucomisd xmm14, xmm14
000074af503d0259  jp 0x000074AF503D0803
000074af503d025f  movq xmm14, xmm14
000074af503d0264  movaps [r15+0x230], xmm14
000074af503d026c  movq rax, xmm13
000074af503d0271  movq r14, xmm14
000074af503d0276  vmovq xmm1, rax
000074af503d027b  vmovq xmm15, r14
000074af503d0280  movaps xmm14, xmm1
000074af503d0284  addsd xmm14, xmm15
000074af503d0289  ucomisd xmm14, xmm14
000074af503d028e  jp 0x000074AF503D084B
000074af503d0294  movq xmm14, xmm14
000074af503d0299  movaps [r15+0x220], xmm14
000074af503d02a1  mov rax, [r15+0x68]
000074af503d02a5  movq r14, xmm14
000074af503d02aa  mov [r13+rax*1], r14
000074af503d02af  mov qword ptr [r15+0x70], 0x08
000074af503d02b7  xor eax, eax
000074af503d02b9  mov r14d, 0x08
000074af503d02bf  mov r12d, 0x40
000074af503d02c5  cmp r14, r12
000074af503d02c8  cmc
000074af503d02c9  lahf
000074af503d02ca  seto al
000074af503d02cd  mov [r15+0x108], eax
000074af503d02d4  mov eax, [r15+0x108]
000074af503d02db  sahf
000074af503d02dc  jnz 0x000074AF503D030E
000074af503d02de  cmp dword ptr [r15+0x318], 0x00
000074af503d02e6  jz 0x000074AF503CFD40
000074af503d02ec  nop [rax+rax*1], ax
000074af503d02f5  nop [rax+rax*1], eax
000074af503d02fd  mov eax, 0x410118
000074af503d0302  mov [r15+0x100], rax
000074af503d0309  jmp 0x000074AF501FE110
000074af503d030e  cmp dword ptr [r15+0x318], 0x00
000074af503d0316  jz 0x000074AF503CF3F0
000074af503d031c  nop [rax+rax*1], ax
000074af503d0325  nop [rax+rax*1], eax
000074af503d032d  mov eax, 0x4100A4
000074af503d0332  mov [r15+0x100], rax
000074af503d0339  jmp 0x000074AF501FE110
000074af503d033e  int3
000074af503d033f  call 0x000074AF502B47C0
000074af503d0344  jmp 0x000074AF503CFDF5
000074af503d0349  call 0x000074AF502E1570
000074af503d034e  jmp 0x000074AF503CFDFF
000074af503d0353  call 0x000074AF5020DC20
000074af503d0358  jmp 0x000074AF503CFE35
000074af503d035d  call 0x000074AF5020A4B0
000074af503d0362  jmp 0x000074AF503CFE3F
000074af503d0367  call 0x000074AF5020DC20
000074af503d036c  jmp 0x000074AF503CFE75
000074af503d0371  call 0x000074AF5020A4B0
000074af503d0376  jmp 0x000074AF503CFE7F
000074af503d037b  call 0x000074AF5020DC20
000074af503d0380  jmp 0x000074AF503CFEB5
000074af503d0385  call 0x000074AF5020B720
000074af503d038a  jmp 0x000074AF503CFEBF
000074af503d038f  call 0x000074AF5020DC20
000074af503d0394  jmp 0x000074AF503CFEF8
000074af503d0399  call 0x000074AF502E27E0
000074af503d039e  jmp 0x000074AF503CFF06
000074af503d03a3  call 0x000074AF502E27E0
000074af503d03a8  jmp 0x000074AF503CFF17
000074af503d03ad  ucomisd xmm1, xmm13
000074af503d03b2  jp 0x000074AF503D03C1
000074af503d03b4  movaps xmm12, [0x000074AF4FFFE030]
000074af503d03bc  jmp 0x000074AF503CFF4C
000074af503d03c1  vxorps xmm0, xmm1, xmm13
000074af503d03c6  pextrw r14d, xmm0, 0x03
000074af503d03cc  and r14d, 0x7FF8
000074af503d03d3  cmp r14d, 0x08
000074af503d03d7  jnz 0x000074AF503CFF4C
000074af503d03dd  movq r14, xmm13
000074af503d03e2  shl r14, 0x0D
000074af503d03e6  jbe 0x000074AF503CFF4C
000074af503d03ec  vorps xmm12, xmm13, [0x000074AF4FFFE040]
000074af503d03f4  jmp 0x000074AF503CFF4C
000074af503d03f9  ucomisd xmm1, xmm15
000074af503d03fe  jp 0x000074AF503D040D
000074af503d0400  movaps xmm13, [0x000074AF4FFFE030]
000074af503d0408  jmp 0x000074AF503CFF81
000074af503d040d  vxorps xmm0, xmm1, xmm15
000074af503d0412  pextrw r14d, xmm0, 0x03
000074af503d0418  and r14d, 0x7FF8
000074af503d041f  cmp r14d, 0x08
000074af503d0423  jnz 0x000074AF503CFF81
000074af503d0429  movq r14, xmm15
000074af503d042e  shl r14, 0x0D
000074af503d0432  jbe 0x000074AF503CFF81
000074af503d0438  vorps xmm13, xmm15, [0x000074AF4FFFE040]
000074af503d0440  jmp 0x000074AF503CFF81
000074af503d0445  ucomisd xmm1, xmm15
000074af503d044a  jp 0x000074AF503D0459
000074af503d044c  movaps xmm12, [0x000074AF4FFFE030]
000074af503d0454  jmp 0x000074AF503CFFB6
000074af503d0459  vxorps xmm0, xmm1, xmm15
000074af503d045e  pextrw r14d, xmm0, 0x03
000074af503d0464  and r14d, 0x7FF8
000074af503d046b  cmp r14d, 0x08
000074af503d046f  jnz 0x000074AF503CFFB6
000074af503d0475  movq r14, xmm15
000074af503d047a  shl r14, 0x0D
000074af503d047e  jbe 0x000074AF503CFFB6
000074af503d0484  vorps xmm12, xmm15, [0x000074AF4FFFE040]
000074af503d048c  jmp 0x000074AF503CFFB6
000074af503d0491  ucomisd xmm1, xmm15
000074af503d0496  jp 0x000074AF503D04A5
000074af503d0498  movaps xmm13, [0x000074AF4FFFE030]
000074af503d04a0  jmp 0x000074AF503CFFE3
000074af503d04a5  vxorps xmm0, xmm1, xmm15
000074af503d04aa  pextrw r14d, xmm0, 0x03
000074af503d04b0  and r14d, 0x7FF8
000074af503d04b7  cmp r14d, 0x08
000074af503d04bb  jnz 0x000074AF503CFFE3
000074af503d04c1  movq r14, xmm15
000074af503d04c6  shl r14, 0x0D
000074af503d04ca  jbe 0x000074AF503CFFE3
000074af503d04d0  vorps xmm13, xmm15, [0x000074AF4FFFE040]
000074af503d04d8  jmp 0x000074AF503CFFE3
000074af503d04dd  ucomisd xmm1, xmm15
000074af503d04e2  jp 0x000074AF503D04F1
000074af503d04e4  movaps xmm14, [0x000074AF4FFFE030]
000074af503d04ec  jmp 0x000074AF503D0018
000074af503d04f1  vxorps xmm0, xmm1, xmm15
000074af503d04f6  pextrw r14d, xmm0, 0x03
000074af503d04fc  and r14d, 0x7FF8
000074af503d0503  cmp r14d, 0x08
000074af503d0507  jnz 0x000074AF503D0018
000074af503d050d  movq r14, xmm15
000074af503d0512  shl r14, 0x0D
000074af503d0516  jbe 0x000074AF503D0018
000074af503d051c  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d0524  jmp 0x000074AF503D0018
000074af503d0529  call 0x000074AF502E27E0
000074af503d052e  jmp 0x000074AF503D0029
000074af503d0533  ucomisd xmm15, xmm14
000074af503d0538  jp 0x000074AF503D0547
000074af503d053a  movaps xmm13, [0x000074AF4FFFE030]
000074af503d0542  jmp 0x000074AF503D0056
000074af503d0547  vxorps xmm0, xmm15, xmm14
000074af503d054c  pextrw r14d, xmm0, 0x03
000074af503d0552  and r14d, 0x7FF8
000074af503d0559  cmp r14d, 0x08
000074af503d055d  jnz 0x000074AF503D0056
000074af503d0563  movq r14, xmm14
000074af503d0568  shl r14, 0x0D
000074af503d056c  jbe 0x000074AF503D0056
000074af503d0572  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503d057a  jmp 0x000074AF503D0056
000074af503d057f  ucomisd xmm1, xmm15
000074af503d0584  jp 0x000074AF503D0593
000074af503d0586  movaps xmm14, [0x000074AF4FFFE030]
000074af503d058e  jmp 0x000074AF503D008B
000074af503d0593  vxorps xmm0, xmm1, xmm15
000074af503d0598  pextrw r14d, xmm0, 0x03
000074af503d059e  and r14d, 0x7FF8
000074af503d05a5  cmp r14d, 0x08
000074af503d05a9  jnz 0x000074AF503D008B
000074af503d05af  movq r14, xmm15
000074af503d05b4  shl r14, 0x0D
000074af503d05b8  jbe 0x000074AF503D008B
000074af503d05be  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d05c6  jmp 0x000074AF503D008B
000074af503d05cb  call 0x000074AF502E27E0
000074af503d05d0  jmp 0x000074AF503D009C
000074af503d05d5  ucomisd xmm15, xmm14
000074af503d05da  jp 0x000074AF503D05E9
000074af503d05dc  movaps xmm13, [0x000074AF4FFFE030]
000074af503d05e4  jmp 0x000074AF503D00C9
000074af503d05e9  vxorps xmm0, xmm15, xmm14
000074af503d05ee  pextrw r14d, xmm0, 0x03
000074af503d05f4  and r14d, 0x7FF8
000074af503d05fb  cmp r14d, 0x08
000074af503d05ff  jnz 0x000074AF503D00C9
000074af503d0605  movq r14, xmm14
000074af503d060a  shl r14, 0x0D
000074af503d060e  jbe 0x000074AF503D00C9
000074af503d0614  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503d061c  jmp 0x000074AF503D00C9
000074af503d0621  ucomisd xmm1, xmm15
000074af503d0626  jp 0x000074AF503D0635
000074af503d0628  movaps xmm14, [0x000074AF4FFFE030]
000074af503d0630  jmp 0x000074AF503D00FE
000074af503d0635  vxorps xmm0, xmm1, xmm15
000074af503d063a  pextrw r14d, xmm0, 0x03
000074af503d0640  and r14d, 0x7FF8
000074af503d0647  cmp r14d, 0x08
000074af503d064b  jnz 0x000074AF503D00FE
000074af503d0651  movq r14, xmm15
000074af503d0656  shl r14, 0x0D
000074af503d065a  jbe 0x000074AF503D00FE
000074af503d0660  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d0668  jmp 0x000074AF503D00FE
000074af503d066d  call 0x000074AF502E27E0
000074af503d0672  jmp 0x000074AF503D010F
000074af503d0677  ucomisd xmm15, xmm14
000074af503d067c  jp 0x000074AF503D068B
000074af503d067e  movaps xmm13, [0x000074AF4FFFE030]
000074af503d0686  jmp 0x000074AF503D013C
000074af503d068b  vxorps xmm0, xmm15, xmm14
000074af503d0690  pextrw r14d, xmm0, 0x03
000074af503d0696  and r14d, 0x7FF8
000074af503d069d  cmp r14d, 0x08
000074af503d06a1  jnz 0x000074AF503D013C
000074af503d06a7  movq r14, xmm14
000074af503d06ac  shl r14, 0x0D
000074af503d06b0  jbe 0x000074AF503D013C
000074af503d06b6  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503d06be  jmp 0x000074AF503D013C
000074af503d06c3  ucomisd xmm1, xmm15
000074af503d06c8  jp 0x000074AF503D06D7
000074af503d06ca  movaps xmm14, [0x000074AF4FFFE030]
000074af503d06d2  jmp 0x000074AF503D0171
000074af503d06d7  vxorps xmm0, xmm1, xmm15
000074af503d06dc  pextrw r14d, xmm0, 0x03
000074af503d06e2  and r14d, 0x7FF8
000074af503d06e9  cmp r14d, 0x08
000074af503d06ed  jnz 0x000074AF503D0171
000074af503d06f3  movq r14, xmm15
000074af503d06f8  shl r14, 0x0D
000074af503d06fc  jbe 0x000074AF503D0171
000074af503d0702  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d070a  jmp 0x000074AF503D0171
000074af503d070f  call 0x000074AF502E27E0
000074af503d0714  jmp 0x000074AF503D0182
000074af503d0719  ucomisd xmm15, xmm14
000074af503d071e  jp 0x000074AF503D072D
000074af503d0720  movaps xmm13, [0x000074AF4FFFE030]
000074af503d0728  jmp 0x000074AF503D01AF
000074af503d072d  vxorps xmm0, xmm15, xmm14
000074af503d0732  pextrw r14d, xmm0, 0x03
000074af503d0738  and r14d, 0x7FF8
000074af503d073f  cmp r14d, 0x08
000074af503d0743  jnz 0x000074AF503D01AF
000074af503d0749  movq r14, xmm14
000074af503d074e  shl r14, 0x0D
000074af503d0752  jbe 0x000074AF503D01AF
000074af503d0758  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503d0760  jmp 0x000074AF503D01AF
000074af503d0765  ucomisd xmm1, xmm15
000074af503d076a  jp 0x000074AF503D0779
000074af503d076c  movaps xmm14, [0x000074AF4FFFE030]
000074af503d0774  jmp 0x000074AF503D01E4
000074af503d0779  vxorps xmm0, xmm1, xmm15
000074af503d077e  pextrw r14d, xmm0, 0x03
000074af503d0784  and r14d, 0x7FF8
000074af503d078b  cmp r14d, 0x08
000074af503d078f  jnz 0x000074AF503D01E4
000074af503d0795  movq r14, xmm15
000074af503d079a  shl r14, 0x0D
000074af503d079e  jbe 0x000074AF503D01E4
000074af503d07a4  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d07ac  jmp 0x000074AF503D01E4
000074af503d07b1  call 0x000074AF502D59C0
000074af503d07b6  jmp 0x000074AF503D01F5
000074af503d07bb  ucomisd xmm15, xmm14
000074af503d07c0  jp 0x000074AF503D07CF
000074af503d07c2  movaps xmm13, [0x000074AF4FFFE030]
000074af503d07ca  jmp 0x000074AF503D022A
000074af503d07cf  vxorps xmm0, xmm15, xmm14
000074af503d07d4  pextrw eax, xmm0, 0x03
000074af503d07d9  and eax, 0x7FF8
000074af503d07de  cmp eax, 0x08
000074af503d07e1  jnz 0x000074AF503D022A
000074af503d07e7  movq rax, xmm14
000074af503d07ec  shl rax, 0x0D
000074af503d07f0  jbe 0x000074AF503D022A
000074af503d07f6  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503d07fe  jmp 0x000074AF503D022A
000074af503d0803  ucomisd xmm1, xmm15
000074af503d0808  jp 0x000074AF503D0817
000074af503d080a  movaps xmm14, [0x000074AF4FFFE030]
000074af503d0812  jmp 0x000074AF503D025F
000074af503d0817  vxorps xmm0, xmm1, xmm15
000074af503d081c  pextrw eax, xmm0, 0x03
000074af503d0821  and eax, 0x7FF8
000074af503d0826  cmp eax, 0x08
000074af503d0829  jnz 0x000074AF503D025F
000074af503d082f  movq rax, xmm15
000074af503d0834  shl rax, 0x0D
000074af503d0838  jbe 0x000074AF503D025F
000074af503d083e  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d0846  jmp 0x000074AF503D025F
000074af503d084b  ucomisd xmm1, xmm15
000074af503d0850  jp 0x000074AF503D085F
000074af503d0852  movaps xmm14, [0x000074AF4FFFE030]
000074af503d085a  jmp 0x000074AF503D0294
000074af503d085f  vxorps xmm0, xmm1, xmm15
000074af503d0864  pextrw eax, xmm0, 0x03
000074af503d0869  and eax, 0x7FF8
000074af503d086e  cmp eax, 0x08
000074af503d0871  jnz 0x000074AF503D0294
000074af503d0877  movq rax, xmm15
000074af503d087c  shl rax, 0x0D
000074af503d0880  jbe 0x000074AF503D0294
000074af503d0886  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d088e  jmp 0x000074AF503D0294
000074af503d0893  call 0x000074AF5020E120
000074af503d0898  jmp 0x000074AF503D02AF
000074af503d089d  int3
000074af503d089e  nop
000074af503d08a0  mov eax, [r15+0x58]
000074af503d08a4  lea r14d, [eax+0x01]
000074af503d08a9  mov [rsp+0x10], r14d
000074af503d08ae  mov r14d, r14d
000074af503d08b1  mov [r15+0x58], r14
000074af503d08b5  xor eax, eax
000074af503d08b7  mov r14d, [rsp+0x10]
000074af503d08bc  cmp r14d, 0x1F4
000074af503d08c3  cmc
000074af503d08c4  lahf
000074af503d08c5  seto al
000074af503d08c8  mov [r15+0x108], eax
000074af503d08cf  mov eax, [r15+0x108]
000074af503d08d6  sahf
000074af503d08d7  jnz 0x000074AF503D0909
000074af503d08d9  cmp dword ptr [r15+0x318], 0x00
000074af503d08e1  jz 0x000074AF503D1410
000074af503d08e7  nop [rax+rax*1], ax
000074af503d08f0  nop [rax+rax*1], eax
000074af503d08f8  mov eax, 0x410134
000074af503d08fd  mov [r15+0x100], rax
000074af503d0904  jmp 0x000074AF501FE110
000074af503d0909  cmp dword ptr [r15+0x318], 0x00
000074af503d0911  jz 0x000074AF503D0940
000074af503d0917  nop [rax+rax*1], ax
000074af503d0920  nop [rax+rax*1], eax
000074af503d0928  mov eax, 0x410084
000074af503d092d  mov [r15+0x100], rax
000074af503d0934  jmp 0x000074AF501FE110
000074af503d0939  int3
000074af503d093a  int3
000074af503d093b  nop [rax+rax*1], eax
000074af503d0940  mov qword ptr [r15+0x60], 0x00
000074af503d0948  mov rax, [r15+0x50]
000074af503d094c  mov [r15+0x68], rax
000074af503d0950  mov r14, [r15+0x40]
000074af503d0954  mov r12, [r13+r14*1]
000074af503d0959  lea r11, [r14+0x08]
000074af503d095d  mov r10, [r13+r11*1]
000074af503d0962  movq xmm1, r12
000074af503d0967  movq xmm15, r10
000074af503d096c  movq xmm1, xmm1
000074af503d0970  movq xmm1, xmm1
000074af503d0974  movaps [r15+0x120], xmm1
000074af503d097c  movq xmm15, xmm15
000074af503d0981  movq xmm15, xmm15
000074af503d0986  movaps [r15+0x130], xmm15
000074af503d098e  lea r12, [r14+0x10]
000074af503d0992  mov r11, [r13+r12*1]
000074af503d0997  lea r12, [r14+0x18]
000074af503d099b  mov r10, [r13+r12*1]
000074af503d09a0  movq xmm1, r11
000074af503d09a5  movq xmm15, r10
000074af503d09aa  movq xmm1, xmm1
000074af503d09ae  movq xmm1, xmm1
000074af503d09b2  movaps [r15+0x140], xmm1
000074af503d09ba  movq xmm15, xmm15
000074af503d09bf  movq xmm15, xmm15
000074af503d09c4  movaps [r15+0x150], xmm15
000074af503d09cc  lea r12, [r14+0x20]
000074af503d09d0  mov r11, [r13+r12*1]
000074af503d09d5  lea r12, [r14+0x28]
000074af503d09d9  mov r10, [r13+r12*1]
000074af503d09de  movq xmm1, r11
000074af503d09e3  movq xmm15, r10
000074af503d09e8  movq xmm1, xmm1
000074af503d09ec  movq xmm1, xmm1
000074af503d09f0  movaps [r15+0x160], xmm1
000074af503d09f8  movq xmm15, xmm15
000074af503d09fd  movq xmm15, xmm15
000074af503d0a02  movaps [r15+0x170], xmm15
000074af503d0a0a  lea r12, [r14+0x30]
000074af503d0a0e  mov r11, [r13+r12*1]
000074af503d0a13  lea r12, [r14+0x38]
000074af503d0a17  mov r14, [r13+r12*1]
000074af503d0a1c  movq xmm1, r11
000074af503d0a21  movq xmm15, r14
000074af503d0a26  movq xmm1, xmm1
000074af503d0a2a  movq xmm1, xmm1
000074af503d0a2e  movaps [r15+0x180], xmm1
000074af503d0a36  movq xmm15, xmm15
000074af503d0a3b  movq xmm15, xmm15
000074af503d0a40  movaps [r15+0x210], xmm15
000074af503d0a48  mov r14, [r15+0x48]
000074af503d0a4c  mov [r15+0x78], r14
000074af503d0a50  mov r12, [r13+r14*1]
000074af503d0a55  movq xmm1, r12
000074af503d0a5a  lea r12, [r14+0x40]
000074af503d0a5e  mov r11, [r13+r12*1]
000074af503d0a63  movq xmm15, r11
000074af503d0a68  lea r12, [r14+0x80]
000074af503d0a6f  mov r11, [r13+r12*1]
000074af503d0a74  movq xmm14, r11
000074af503d0a79  movaps xmm13, [r15+0x120]
000074af503d0a81  movq r12, xmm13
000074af503d0a86  movq r11, xmm1
000074af503d0a8b  vmovq xmm1, r12
000074af503d0a90  vmovq xmm13, r11
000074af503d0a95  movaps xmm12, xmm1
000074af503d0a99  mulsd xmm12, xmm13
000074af503d0a9e  ucomisd xmm12, xmm12
000074af503d0aa3  jp 0x000074AF503D0F06
000074af503d0aa9  movq xmm12, xmm12
000074af503d0aae  movaps xmm1, [r15+0x130]
000074af503d0ab6  movq r12, xmm1
000074af503d0abb  movq r11, xmm15
000074af503d0ac0  vmovq xmm1, r12
000074af503d0ac5  vmovq xmm15, r11
000074af503d0aca  movaps xmm13, xmm1
000074af503d0ace  mulsd xmm13, xmm15
000074af503d0ad3  ucomisd xmm13, xmm13
000074af503d0ad8  jp 0x000074AF503D0F52
000074af503d0ade  movq xmm13, xmm13
000074af503d0ae3  movq r12, xmm12
000074af503d0ae8  movaps xmm1, [r15+0x110]
000074af503d0af0  movq r11, xmm1
000074af503d0af5  vmovq xmm1, r12
000074af503d0afa  vmovq xmm15, r11
000074af503d0aff  movaps xmm12, xmm1
000074af503d0b03  addsd xmm12, xmm15
000074af503d0b08  ucomisd xmm12, xmm12
000074af503d0b0d  jp 0x000074AF503D0F9E
000074af503d0b13  movq xmm12, xmm12
000074af503d0b18  movq r12, xmm12
000074af503d0b1d  movq r11, xmm13
000074af503d0b22  vmovq xmm1, r12
000074af503d0b27  vmovq xmm15, r11
000074af503d0b2c  movaps xmm13, xmm1
000074af503d0b30  addsd xmm13, xmm15
000074af503d0b35  ucomisd xmm13, xmm13
000074af503d0b3a  jp 0x000074AF503D0FEA
000074af503d0b40  movq xmm13, xmm13
000074af503d0b45  movaps xmm1, [r15+0x140]
000074af503d0b4d  movq r12, xmm1
000074af503d0b52  movq r11, xmm14
000074af503d0b57  vmovq xmm1, r12
000074af503d0b5c  vmovq xmm15, r11
000074af503d0b61  movaps xmm14, xmm1
000074af503d0b65  mulsd xmm14, xmm15
000074af503d0b6a  ucomisd xmm14, xmm14
000074af503d0b6f  jp 0x000074AF503D1036
000074af503d0b75  movq xmm14, xmm14
000074af503d0b7a  lea r12, [r14+0xC0]
000074af503d0b81  mov r11, [r13+r12*1]
000074af503d0b86  movq xmm1, r11
000074af503d0b8b  movq r12, xmm13
000074af503d0b90  movq r11, xmm14
000074af503d0b95  vmovq xmm15, r12
000074af503d0b9a  vmovq xmm14, r11
000074af503d0b9f  movaps xmm13, xmm15
000074af503d0ba3  addsd xmm13, xmm14
000074af503d0ba8  ucomisd xmm13, xmm13
000074af503d0bad  jp 0x000074AF503D108C
000074af503d0bb3  movq xmm13, xmm13
000074af503d0bb8  movaps xmm15, [r15+0x150]
000074af503d0bc0  movq r12, xmm15
000074af503d0bc5  movq r11, xmm1
000074af503d0bca  vmovq xmm1, r12
000074af503d0bcf  vmovq xmm15, r11
000074af503d0bd4  movaps xmm14, xmm1
000074af503d0bd8  mulsd xmm14, xmm15
000074af503d0bdd  ucomisd xmm14, xmm14
000074af503d0be2  jp 0x000074AF503D10D8
000074af503d0be8  movq xmm14, xmm14
000074af503d0bed  lea r12, [r14+0x100]
000074af503d0bf4  mov r11, [r13+r12*1]
000074af503d0bf9  movq xmm1, r11
000074af503d0bfe  movq r12, xmm13
000074af503d0c03  movq r11, xmm14
000074af503d0c08  vmovq xmm15, r12
000074af503d0c0d  vmovq xmm14, r11
000074af503d0c12  movaps xmm13, xmm15
000074af503d0c16  addsd xmm13, xmm14
000074af503d0c1b  ucomisd xmm13, xmm13
000074af503d0c20  jp 0x000074AF503D112E
000074af503d0c26  movq xmm13, xmm13
000074af503d0c2b  movaps xmm15, [r15+0x160]
000074af503d0c33  movq r12, xmm15
000074af503d0c38  movq r11, xmm1
000074af503d0c3d  vmovq xmm1, r12
000074af503d0c42  vmovq xmm15, r11
000074af503d0c47  movaps xmm14, xmm1
000074af503d0c4b  mulsd xmm14, xmm15
000074af503d0c50  ucomisd xmm14, xmm14
000074af503d0c55  jp 0x000074AF503D117A
000074af503d0c5b  movq xmm14, xmm14
000074af503d0c60  lea r12, [r14+0x140]
000074af503d0c67  mov r11, [r13+r12*1]
000074af503d0c6c  movq xmm1, r11
000074af503d0c71  movq r12, xmm13
000074af503d0c76  movq r11, xmm14
000074af503d0c7b  vmovq xmm15, r12
000074af503d0c80  vmovq xmm14, r11
000074af503d0c85  movaps xmm13, xmm15
000074af503d0c89  addsd xmm13, xmm14
000074af503d0c8e  ucomisd xmm13, xmm13
000074af503d0c93  jp 0x000074AF503D11D0
000074af503d0c99  movq xmm13, xmm13
000074af503d0c9e  movaps xmm15, [r15+0x170]
000074af503d0ca6  movq r12, xmm15
000074af503d0cab  movq r11, xmm1
000074af503d0cb0  vmovq xmm1, r12
000074af503d0cb5  vmovq xmm15, r11
000074af503d0cba  movaps xmm14, xmm1
000074af503d0cbe  mulsd xmm14, xmm15
000074af503d0cc3  ucomisd xmm14, xmm14
000074af503d0cc8  jp 0x000074AF503D121C
000074af503d0cce  movq xmm14, xmm14
000074af503d0cd3  lea r12, [r14+0x180]
000074af503d0cda  mov r11, [r13+r12*1]
000074af503d0cdf  movq xmm1, r11
000074af503d0ce4  movq r12, xmm13
000074af503d0ce9  movq r11, xmm14
000074af503d0cee  vmovq xmm15, r12
000074af503d0cf3  vmovq xmm14, r11
000074af503d0cf8  movaps xmm13, xmm15
000074af503d0cfc  addsd xmm13, xmm14
000074af503d0d01  ucomisd xmm13, xmm13
000074af503d0d06  jp 0x000074AF503D1272
000074af503d0d0c  movq xmm13, xmm13
000074af503d0d11  movaps xmm15, [r15+0x180]
000074af503d0d19  movq r12, xmm15
000074af503d0d1e  movq r11, xmm1
000074af503d0d23  vmovq xmm1, r12
000074af503d0d28  vmovq xmm15, r11
000074af503d0d2d  movaps xmm14, xmm1
000074af503d0d31  mulsd xmm14, xmm15
000074af503d0d36  ucomisd xmm14, xmm14
000074af503d0d3b  jp 0x000074AF503D12BE
000074af503d0d41  movq xmm14, xmm14
000074af503d0d46  lea r12, [r14+0x1C0]
000074af503d0d4d  mov r14, [r13+r12*1]
000074af503d0d52  movq xmm1, r14
000074af503d0d57  movaps [r15+0x240], xmm1
000074af503d0d5f  movq r14, xmm13
000074af503d0d64  movq r12, xmm14
000074af503d0d69  vmovq xmm15, r14
000074af503d0d6e  vmovq xmm14, r12
000074af503d0d73  movaps xmm13, xmm15
000074af503d0d77  addsd xmm13, xmm14
000074af503d0d7c  ucomisd xmm13, xmm13
000074af503d0d81  jp 0x000074AF503D1314
000074af503d0d87  movq xmm13, xmm13
000074af503d0d8c  movaps xmm15, [r15+0x210]
000074af503d0d94  movq r14, xmm15
000074af503d0d99  movq r12, xmm1
000074af503d0d9e  vmovq xmm1, r14
000074af503d0da3  vmovq xmm15, r12
000074af503d0da8  movaps xmm14, xmm1
000074af503d0dac  mulsd xmm14, xmm15
000074af503d0db1  ucomisd xmm14, xmm14
000074af503d0db6  jp 0x000074AF503D1360
000074af503d0dbc  movq xmm14, xmm14
000074af503d0dc1  movaps [r15+0x230], xmm14
000074af503d0dc9  movq r14, xmm13
000074af503d0dce  movq r12, xmm14
000074af503d0dd3  vmovq xmm1, r14
000074af503d0dd8  vmovq xmm15, r12
000074af503d0ddd  movaps xmm14, xmm1
000074af503d0de1  addsd xmm14, xmm15
000074af503d0de6  ucomisd xmm14, xmm14
000074af503d0deb  jp 0x000074AF503D13AC
000074af503d0df1  movq xmm14, xmm14
000074af503d0df6  movaps [r15+0x220], xmm14
000074af503d0dfe  movq r14, xmm14
000074af503d0e03  mov [r13+rax*1], r14
000074af503d0e08  mov qword ptr [r15+0x70], 0x08
000074af503d0e10  xor eax, eax
000074af503d0e12  mov r14d, 0x08
000074af503d0e18  mov r12d, 0x40
000074af503d0e1e  cmp r14, r12
000074af503d0e21  cmc
000074af503d0e22  lahf
000074af503d0e23  seto al
000074af503d0e26  mov [r15+0x108], eax
000074af503d0e2d  mov eax, [r15+0x108]
000074af503d0e34  sahf
000074af503d0e35  jnz 0x000074AF503D0E67
000074af503d0e37  cmp dword ptr [r15+0x318], 0x00
000074af503d0e3f  jz 0x000074AF503CFD40
000074af503d0e45  nop [rax+rax*1], ax
000074af503d0e4e  nop [rax+rax*1], eax
000074af503d0e56  mov eax, 0x410118
000074af503d0e5b  mov [r15+0x100], rax
000074af503d0e62  jmp 0x000074AF501FE110
000074af503d0e67  cmp dword ptr [r15+0x318], 0x00
000074af503d0e6f  jz 0x000074AF503CF3F0
000074af503d0e75  nop [rax+rax*1], ax
000074af503d0e7e  nop [rax+rax*1], eax
000074af503d0e86  mov eax, 0x4100A4
000074af503d0e8b  mov [r15+0x100], rax
000074af503d0e92  jmp 0x000074AF501FE110
000074af503d0e97  int3
000074af503d0e98  call 0x000074AF502E27E0
000074af503d0e9d  jmp 0x000074AF503D0959
000074af503d0ea2  call 0x000074AF502AE800
000074af503d0ea7  jmp 0x000074AF503D0962
000074af503d0eac  call 0x000074AF502C0370
000074af503d0eb1  jmp 0x000074AF503D0997
000074af503d0eb6  call 0x000074AF502BF100
000074af503d0ebb  jmp 0x000074AF503D09A0
000074af503d0ec0  call 0x000074AF502C0370
000074af503d0ec5  jmp 0x000074AF503D09D5
000074af503d0eca  call 0x000074AF502BF100
000074af503d0ecf  jmp 0x000074AF503D09DE
000074af503d0ed4  call 0x000074AF502C0370
000074af503d0ed9  jmp 0x000074AF503D0A13
000074af503d0ede  call 0x000074AF502C3AE0
000074af503d0ee3  jmp 0x000074AF503D0A1C
000074af503d0ee8  call 0x000074AF502E27E0
000074af503d0eed  jmp 0x000074AF503D0A55
000074af503d0ef2  call 0x000074AF502C0370
000074af503d0ef7  jmp 0x000074AF503D0A63
000074af503d0efc  call 0x000074AF502C0370
000074af503d0f01  jmp 0x000074AF503D0A74
000074af503d0f06  ucomisd xmm1, xmm13
000074af503d0f0b  jp 0x000074AF503D0F1A
000074af503d0f0d  movaps xmm12, [0x000074AF4FFFE030]
000074af503d0f15  jmp 0x000074AF503D0AA9
000074af503d0f1a  vxorps xmm0, xmm1, xmm13
000074af503d0f1f  pextrw r12d, xmm0, 0x03
000074af503d0f25  and r12d, 0x7FF8
000074af503d0f2c  cmp r12d, 0x08
000074af503d0f30  jnz 0x000074AF503D0AA9
000074af503d0f36  movq r12, xmm13
000074af503d0f3b  shl r12, 0x0D
000074af503d0f3f  jbe 0x000074AF503D0AA9
000074af503d0f45  vorps xmm12, xmm13, [0x000074AF4FFFE040]
000074af503d0f4d  jmp 0x000074AF503D0AA9
000074af503d0f52  ucomisd xmm1, xmm15
000074af503d0f57  jp 0x000074AF503D0F66
000074af503d0f59  movaps xmm13, [0x000074AF4FFFE030]
000074af503d0f61  jmp 0x000074AF503D0ADE
000074af503d0f66  vxorps xmm0, xmm1, xmm15
000074af503d0f6b  pextrw r12d, xmm0, 0x03
000074af503d0f71  and r12d, 0x7FF8
000074af503d0f78  cmp r12d, 0x08
000074af503d0f7c  jnz 0x000074AF503D0ADE
000074af503d0f82  movq r12, xmm15
000074af503d0f87  shl r12, 0x0D
000074af503d0f8b  jbe 0x000074AF503D0ADE
000074af503d0f91  vorps xmm13, xmm15, [0x000074AF4FFFE040]
000074af503d0f99  jmp 0x000074AF503D0ADE
000074af503d0f9e  ucomisd xmm1, xmm15
000074af503d0fa3  jp 0x000074AF503D0FB2
000074af503d0fa5  movaps xmm12, [0x000074AF4FFFE030]
000074af503d0fad  jmp 0x000074AF503D0B13
000074af503d0fb2  vxorps xmm0, xmm1, xmm15
000074af503d0fb7  pextrw r12d, xmm0, 0x03
000074af503d0fbd  and r12d, 0x7FF8
000074af503d0fc4  cmp r12d, 0x08
000074af503d0fc8  jnz 0x000074AF503D0B13
000074af503d0fce  movq r12, xmm15
000074af503d0fd3  shl r12, 0x0D
000074af503d0fd7  jbe 0x000074AF503D0B13
000074af503d0fdd  vorps xmm12, xmm15, [0x000074AF4FFFE040]
000074af503d0fe5  jmp 0x000074AF503D0B13
000074af503d0fea  ucomisd xmm1, xmm15
000074af503d0fef  jp 0x000074AF503D0FFE
000074af503d0ff1  movaps xmm13, [0x000074AF4FFFE030]
000074af503d0ff9  jmp 0x000074AF503D0B40
000074af503d0ffe  vxorps xmm0, xmm1, xmm15
000074af503d1003  pextrw r12d, xmm0, 0x03
000074af503d1009  and r12d, 0x7FF8
000074af503d1010  cmp r12d, 0x08
000074af503d1014  jnz 0x000074AF503D0B40
000074af503d101a  movq r12, xmm15
000074af503d101f  shl r12, 0x0D
000074af503d1023  jbe 0x000074AF503D0B40
000074af503d1029  vorps xmm13, xmm15, [0x000074AF4FFFE040]
000074af503d1031  jmp 0x000074AF503D0B40
000074af503d1036  ucomisd xmm1, xmm15
000074af503d103b  jp 0x000074AF503D104A
000074af503d103d  movaps xmm14, [0x000074AF4FFFE030]
000074af503d1045  jmp 0x000074AF503D0B75
000074af503d104a  vxorps xmm0, xmm1, xmm15
000074af503d104f  pextrw r12d, xmm0, 0x03
000074af503d1055  and r12d, 0x7FF8
000074af503d105c  cmp r12d, 0x08
000074af503d1060  jnz 0x000074AF503D0B75
000074af503d1066  movq r12, xmm15
000074af503d106b  shl r12, 0x0D
000074af503d106f  jbe 0x000074AF503D0B75
000074af503d1075  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d107d  jmp 0x000074AF503D0B75
000074af503d1082  call 0x000074AF502C0370
000074af503d1087  jmp 0x000074AF503D0B86
000074af503d108c  ucomisd xmm15, xmm14
000074af503d1091  jp 0x000074AF503D10A0
000074af503d1093  movaps xmm13, [0x000074AF4FFFE030]
000074af503d109b  jmp 0x000074AF503D0BB3
000074af503d10a0  vxorps xmm0, xmm15, xmm14
000074af503d10a5  pextrw r12d, xmm0, 0x03
000074af503d10ab  and r12d, 0x7FF8
000074af503d10b2  cmp r12d, 0x08
000074af503d10b6  jnz 0x000074AF503D0BB3
000074af503d10bc  movq r12, xmm14
000074af503d10c1  shl r12, 0x0D
000074af503d10c5  jbe 0x000074AF503D0BB3
000074af503d10cb  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503d10d3  jmp 0x000074AF503D0BB3
000074af503d10d8  ucomisd xmm1, xmm15
000074af503d10dd  jp 0x000074AF503D10EC
000074af503d10df  movaps xmm14, [0x000074AF4FFFE030]
000074af503d10e7  jmp 0x000074AF503D0BE8
000074af503d10ec  vxorps xmm0, xmm1, xmm15
000074af503d10f1  pextrw r12d, xmm0, 0x03
000074af503d10f7  and r12d, 0x7FF8
000074af503d10fe  cmp r12d, 0x08
000074af503d1102  jnz 0x000074AF503D0BE8
000074af503d1108  movq r12, xmm15
000074af503d110d  shl r12, 0x0D
000074af503d1111  jbe 0x000074AF503D0BE8
000074af503d1117  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d111f  jmp 0x000074AF503D0BE8
000074af503d1124  call 0x000074AF502C0370
000074af503d1129  jmp 0x000074AF503D0BF9
000074af503d112e  ucomisd xmm15, xmm14
000074af503d1133  jp 0x000074AF503D1142
000074af503d1135  movaps xmm13, [0x000074AF4FFFE030]
000074af503d113d  jmp 0x000074AF503D0C26
000074af503d1142  vxorps xmm0, xmm15, xmm14
000074af503d1147  pextrw r12d, xmm0, 0x03
000074af503d114d  and r12d, 0x7FF8
000074af503d1154  cmp r12d, 0x08
000074af503d1158  jnz 0x000074AF503D0C26
000074af503d115e  movq r12, xmm14
000074af503d1163  shl r12, 0x0D
000074af503d1167  jbe 0x000074AF503D0C26
000074af503d116d  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503d1175  jmp 0x000074AF503D0C26
000074af503d117a  ucomisd xmm1, xmm15
000074af503d117f  jp 0x000074AF503D118E
000074af503d1181  movaps xmm14, [0x000074AF4FFFE030]
000074af503d1189  jmp 0x000074AF503D0C5B
000074af503d118e  vxorps xmm0, xmm1, xmm15
000074af503d1193  pextrw r12d, xmm0, 0x03
000074af503d1199  and r12d, 0x7FF8
000074af503d11a0  cmp r12d, 0x08
000074af503d11a4  jnz 0x000074AF503D0C5B
000074af503d11aa  movq r12, xmm15
000074af503d11af  shl r12, 0x0D
000074af503d11b3  jbe 0x000074AF503D0C5B
000074af503d11b9  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d11c1  jmp 0x000074AF503D0C5B
000074af503d11c6  call 0x000074AF502C0370
000074af503d11cb  jmp 0x000074AF503D0C6C
000074af503d11d0  ucomisd xmm15, xmm14
000074af503d11d5  jp 0x000074AF503D11E4
000074af503d11d7  movaps xmm13, [0x000074AF4FFFE030]
000074af503d11df  jmp 0x000074AF503D0C99
000074af503d11e4  vxorps xmm0, xmm15, xmm14
000074af503d11e9  pextrw r12d, xmm0, 0x03
000074af503d11ef  and r12d, 0x7FF8
000074af503d11f6  cmp r12d, 0x08
000074af503d11fa  jnz 0x000074AF503D0C99
000074af503d1200  movq r12, xmm14
000074af503d1205  shl r12, 0x0D
000074af503d1209  jbe 0x000074AF503D0C99
000074af503d120f  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503d1217  jmp 0x000074AF503D0C99
000074af503d121c  ucomisd xmm1, xmm15
000074af503d1221  jp 0x000074AF503D1230
000074af503d1223  movaps xmm14, [0x000074AF4FFFE030]
000074af503d122b  jmp 0x000074AF503D0CCE
000074af503d1230  vxorps xmm0, xmm1, xmm15
000074af503d1235  pextrw r12d, xmm0, 0x03
000074af503d123b  and r12d, 0x7FF8
000074af503d1242  cmp r12d, 0x08
000074af503d1246  jnz 0x000074AF503D0CCE
000074af503d124c  movq r12, xmm15
000074af503d1251  shl r12, 0x0D
000074af503d1255  jbe 0x000074AF503D0CCE
000074af503d125b  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d1263  jmp 0x000074AF503D0CCE
000074af503d1268  call 0x000074AF502C0370
000074af503d126d  jmp 0x000074AF503D0CDF
000074af503d1272  ucomisd xmm15, xmm14
000074af503d1277  jp 0x000074AF503D1286
000074af503d1279  movaps xmm13, [0x000074AF4FFFE030]
000074af503d1281  jmp 0x000074AF503D0D0C
000074af503d1286  vxorps xmm0, xmm15, xmm14
000074af503d128b  pextrw r12d, xmm0, 0x03
000074af503d1291  and r12d, 0x7FF8
000074af503d1298  cmp r12d, 0x08
000074af503d129c  jnz 0x000074AF503D0D0C
000074af503d12a2  movq r12, xmm14
000074af503d12a7  shl r12, 0x0D
000074af503d12ab  jbe 0x000074AF503D0D0C
000074af503d12b1  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503d12b9  jmp 0x000074AF503D0D0C
000074af503d12be  ucomisd xmm1, xmm15
000074af503d12c3  jp 0x000074AF503D12D2
000074af503d12c5  movaps xmm14, [0x000074AF4FFFE030]
000074af503d12cd  jmp 0x000074AF503D0D41
000074af503d12d2  vxorps xmm0, xmm1, xmm15
000074af503d12d7  pextrw r12d, xmm0, 0x03
000074af503d12dd  and r12d, 0x7FF8
000074af503d12e4  cmp r12d, 0x08
000074af503d12e8  jnz 0x000074AF503D0D41
000074af503d12ee  movq r12, xmm15
000074af503d12f3  shl r12, 0x0D
000074af503d12f7  jbe 0x000074AF503D0D41
000074af503d12fd  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d1305  jmp 0x000074AF503D0D41
000074af503d130a  call 0x000074AF502C3AE0
000074af503d130f  jmp 0x000074AF503D0D52
000074af503d1314  ucomisd xmm15, xmm14
000074af503d1319  jp 0x000074AF503D1328
000074af503d131b  movaps xmm13, [0x000074AF4FFFE030]
000074af503d1323  jmp 0x000074AF503D0D87
000074af503d1328  vxorps xmm0, xmm15, xmm14
000074af503d132d  pextrw r14d, xmm0, 0x03
000074af503d1333  and r14d, 0x7FF8
000074af503d133a  cmp r14d, 0x08
000074af503d133e  jnz 0x000074AF503D0D87
000074af503d1344  movq r14, xmm14
000074af503d1349  shl r14, 0x0D
000074af503d134d  jbe 0x000074AF503D0D87
000074af503d1353  vorps xmm13, xmm14, [0x000074AF4FFFE040]
000074af503d135b  jmp 0x000074AF503D0D87
000074af503d1360  ucomisd xmm1, xmm15
000074af503d1365  jp 0x000074AF503D1374
000074af503d1367  movaps xmm14, [0x000074AF4FFFE030]
000074af503d136f  jmp 0x000074AF503D0DBC
000074af503d1374  vxorps xmm0, xmm1, xmm15
000074af503d1379  pextrw r14d, xmm0, 0x03
000074af503d137f  and r14d, 0x7FF8
000074af503d1386  cmp r14d, 0x08
000074af503d138a  jnz 0x000074AF503D0DBC
000074af503d1390  movq r14, xmm15
000074af503d1395  shl r14, 0x0D
000074af503d1399  jbe 0x000074AF503D0DBC
000074af503d139f  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d13a7  jmp 0x000074AF503D0DBC
000074af503d13ac  ucomisd xmm1, xmm15
000074af503d13b1  jp 0x000074AF503D13C0
000074af503d13b3  movaps xmm14, [0x000074AF4FFFE030]
000074af503d13bb  jmp 0x000074AF503D0DF1
000074af503d13c0  vxorps xmm0, xmm1, xmm15
000074af503d13c5  pextrw r14d, xmm0, 0x03
000074af503d13cb  and r14d, 0x7FF8
000074af503d13d2  cmp r14d, 0x08
000074af503d13d6  jnz 0x000074AF503D0DF1
000074af503d13dc  movq r14, xmm15
000074af503d13e1  shl r14, 0x0D
000074af503d13e5  jbe 0x000074AF503D0DF1
000074af503d13eb  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d13f3  jmp 0x000074AF503D0DF1
000074af503d13f8  call 0x000074AF5020E120
000074af503d13fd  jmp 0x000074AF503D0E08
000074af503d1402  int3
000074af503d1403  nop [rax+rax*1], ax
000074af503d140c  nop [rax], eax
000074af503d1410  mov qword ptr [r15+0x40], 0x420000
000074af503d1418  mov eax, 0x4201B8
000074af503d141d  mov r14, [r13+rax*1]
000074af503d1422  movq xmm1, r14
000074af503d1427  mov rax, [r15+0x50]
000074af503d142b  mov r14, [r13+rax*1]
000074af503d1430  movq xmm15, r14
000074af503d1435  movaps [r15+0x120], xmm15
000074af503d143d  mov qword ptr [r15+0x48], 0x08
000074af503d1445  xor eax, eax
000074af503d1447  mov r14d, 0x08
000074af503d144d  mov r12d, 0x200
000074af503d1453  cmp r14, r12
000074af503d1456  cmc
000074af503d1457  lahf
000074af503d1458  seto al
000074af503d145b  mov [r15+0x108], eax
000074af503d1462  movq rax, xmm1
000074af503d1467  movq r14, xmm15
000074af503d146c  vmovq xmm1, rax
000074af503d1471  vmovq xmm15, r14
000074af503d1476  movaps xmm14, xmm1
000074af503d147a  addsd xmm14, xmm15
000074af503d147f  ucomisd xmm14, xmm14
000074af503d1484  jp 0x000074AF503D1516
000074af503d148a  movq xmm14, xmm14
000074af503d148f  movaps [r15+0x110], xmm14
000074af503d1497  mov eax, [r15+0x108]
000074af503d149e  sahf
000074af503d149f  jnz 0x000074AF503D14D1
000074af503d14a1  cmp dword ptr [r15+0x318], 0x00
000074af503d14a9  jz 0x000074AF503D16A0
000074af503d14af  nop [rax+rax*1], ax
000074af503d14b8  nop [rax+rax*1], eax
000074af503d14c0  mov eax, 0x410154
000074af503d14c5  mov [r15+0x100], rax
000074af503d14cc  jmp 0x000074AF501FE110
000074af503d14d1  cmp dword ptr [r15+0x318], 0x00
000074af503d14d9  jz 0x000074AF503D1560
000074af503d14df  nop [rax+rax*1], ax
000074af503d14e8  nop [rax+rax*1], eax
000074af503d14f0  mov eax, 0x410140
000074af503d14f5  mov [r15+0x100], rax
000074af503d14fc  jmp 0x000074AF501FE110
000074af503d1501  int3
000074af503d1502  call 0x000074AF5020DC20
000074af503d1507  jmp 0x000074AF503D1422
000074af503d150c  call 0x000074AF5020DC20
000074af503d1511  jmp 0x000074AF503D1430
000074af503d1516  ucomisd xmm1, xmm15
000074af503d151b  jp 0x000074AF503D152A
000074af503d151d  movaps xmm14, [0x000074AF4FFFE030]
000074af503d1525  jmp 0x000074AF503D148A
000074af503d152a  vxorps xmm0, xmm1, xmm15
000074af503d152f  pextrw eax, xmm0, 0x03
000074af503d1534  and eax, 0x7FF8
000074af503d1539  cmp eax, 0x08
000074af503d153c  jnz 0x000074AF503D148A
000074af503d1542  movq rax, xmm15
000074af503d1547  shl rax, 0x0D
000074af503d154b  jbe 0x000074AF503D148A
000074af503d1551  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d1559  jmp 0x000074AF503D148A
000074af503d155e  int3
000074af503d155f  nop
000074af503d1560  mov rax, [r15+0x48]
000074af503d1564  mov r14, [r15+0x50]
000074af503d1568  lea r12, [r14+rax*1]
000074af503d156c  mov r14, [r13+r12*1]
000074af503d1571  movq xmm1, r14
000074af503d1576  movaps [r15+0x120], xmm1
000074af503d157e  lea r14, [rax+0x08]
000074af503d1582  mov [r15+0x48], r14
000074af503d1586  xor eax, eax
000074af503d1588  mov r12d, 0x200
000074af503d158e  cmp r14, r12
000074af503d1591  cmc
000074af503d1592  lahf
000074af503d1593  seto al
000074af503d1596  mov [r15+0x108], eax
000074af503d159d  movaps xmm15, [r15+0x110]
000074af503d15a5  movq rax, xmm15
000074af503d15aa  movq r14, xmm1
000074af503d15af  vmovq xmm1, rax
000074af503d15b4  vmovq xmm15, r14
000074af503d15b9  movaps xmm14, xmm1
000074af503d15bd  addsd xmm14, xmm15
000074af503d15c2  ucomisd xmm14, xmm14
000074af503d15c7  jp 0x000074AF503D164F
000074af503d15cd  movq xmm14, xmm14
000074af503d15d2  movaps [r15+0x110], xmm14
000074af503d15da  mov eax, [r15+0x108]
000074af503d15e1  sahf
000074af503d15e2  jnz 0x000074AF503D1614
000074af503d15e4  cmp dword ptr [r15+0x318], 0x00
000074af503d15ec  jz 0x000074AF503D16A0
000074af503d15f2  nop [rax+rax*1], ax
000074af503d15fb  nop [rax+rax*1], eax
000074af503d1603  mov eax, 0x410154
000074af503d1608  mov [r15+0x100], rax
000074af503d160f  jmp 0x000074AF501FE110
000074af503d1614  cmp dword ptr [r15+0x318], 0x00
000074af503d161c  jz 0x000074AF503D1560
000074af503d1622  nop [rax+rax*1], ax
000074af503d162b  nop [rax+rax*1], eax
000074af503d1633  mov eax, 0x410140
000074af503d1638  mov [r15+0x100], rax
000074af503d163f  jmp 0x000074AF501FE110
000074af503d1644  int3
000074af503d1645  call 0x000074AF502C3AE0
000074af503d164a  jmp 0x000074AF503D1571
000074af503d164f  ucomisd xmm1, xmm15
000074af503d1654  jp 0x000074AF503D1663
000074af503d1656  movaps xmm14, [0x000074AF4FFFE030]
000074af503d165e  jmp 0x000074AF503D15CD
000074af503d1663  vxorps xmm0, xmm1, xmm15
000074af503d1668  pextrw eax, xmm0, 0x03
000074af503d166d  and eax, 0x7FF8
000074af503d1672  cmp eax, 0x08
000074af503d1675  jnz 0x000074AF503D15CD
000074af503d167b  movq rax, xmm15
000074af503d1680  shl rax, 0x0D
000074af503d1684  jbe 0x000074AF503D15CD
000074af503d168a  vorps xmm14, xmm15, [0x000074AF4FFFE040]
000074af503d1692  jmp 0x000074AF503D15CD
000074af503d1697  int3
000074af503d1698  nop [rax+rax*1], eax
000074af503d16a0  mov rax, [r15+0x40]
000074af503d16a4  lea r14, [rax+0x1B8]
000074af503d16ab  movaps xmm1, [r15+0x110]
000074af503d16b3  movq rax, xmm1
000074af503d16b8  mov [r13+r14*1], rax
000074af503d16bd  mov rax, [r15+0xF0]
000074af503d16c4  mov [r15+0x100], rax
000074af503d16cb  jmp 0x000074AF503CE5C0
000074af503d16d0  int3
000074af503d16d1  call 0x000074AF502D5EB0
000074af503d16d6  jmp 0x000074AF503D16BD
000074af503d16db  int3
000074af503d16dc  nop [rax], eax
000074af503d16e0  mov qword ptr [r15+0x100], 0x04
000074af503d16eb  mov esi, 0x00
000074af503d16f0  mov edx, 0x09
000074af503d16f5  mov rdi, 0x7FFD2CB90160
000074af503d16ff  mov rax, 0x63CC6B757970
000074af503d1709  call rax
000074af503d170b  cmp dword ptr [r15+0x318], 0x00
000074af503d1713  jnz 0x000074AF501FE110
000074af503d1719  jmp 0x000074AF501FE0A0
000074af503d171e  int3
000074af503d171f  int3
