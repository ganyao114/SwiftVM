00007431745ce69b  nop [rax+rax*1], eax
00007431745ce6a0  vmovaps xmm1, [0x00007431741FE010]
00007431745ce6a8  movq xmm1, xmm1
00007431745ce6ac  movaps [r15+0x110], xmm1
00007431745ce6b4  vmovaps xmm1, [0x00007431741FE020]
00007431745ce6bc  movq xmm1, xmm1
00007431745ce6c0  movaps [r15+0x120], xmm1
00007431745ce6c8  mov eax, 0x4204C0
00007431745ce6cd  mov r14, [r13+rax*1]
00007431745ce6d2  movq xmm1, r14
00007431745ce6d7  movaps [r15+0x130], xmm1
00007431745ce6df  vmovaps xmm1, [0x00007431741FE030]
00007431745ce6e7  vpbroadcastq xmm1, xmm1
00007431745ce6ec  movaps [r15+0x140], xmm1
00007431745ce6f4  mov qword ptr [r15+0x40], 0x02
00007431745ce6fc  vmovaps xmm15, [0x00007431741FE040]
00007431745ce704  movq xmm15, xmm15
00007431745ce709  movaps [r15+0x150], xmm15
00007431745ce711  mov qword ptr [r15+0x58], 0x420000
00007431745ce719  vmovaps xmm15, [0x00007431741FE050]
00007431745ce721  vpbroadcastq xmm15, xmm15
00007431745ce726  movaps [r15+0x160], xmm15
00007431745ce72e  mov rax, [r15+0x40]
00007431745ce732  vmovq xmm14, rax
00007431745ce737  vpbroadcastq xmm14, xmm14
00007431745ce73c  movaps [r15+0x170], xmm14
00007431745ce744  mov eax, 0x4204D0
00007431745ce749  movups xmm13, [r13+rax*1]
00007431745ce74f  mov qword ptr [r15+0x40], 0x430518
00007431745ce757  mov qword ptr [r15+0x50], 0x430720
00007431745ce75f  vpmovqd xmm12, xmm13
00007431745ce765  pxor xmm11, xmm11
00007431745ce76a  punpcklqdq xmm12, xmm11
00007431745ce76f  movaps [r15+0x210], xmm12
00007431745ce777  movq xmm12, qword ptr [r15+0x120]
00007431745ce780  movq xmm11, qword ptr [r15+0x130]
00007431745ce789  psubd xmm12, xmm11
00007431745ce78e  movq xmm12, xmm12
00007431745ce793  paddq xmm13, xmm14
00007431745ce798  movaps [r15+0x180], xmm13
00007431745ce7a0  movq xmm14, qword ptr [r15+0x150]
00007431745ce7a9  paddd xmm11, xmm14
00007431745ce7ae  movq xmm11, xmm11
00007431745ce7b3  movq xmm11, xmm11
00007431745ce7b8  movaps [r15+0x130], xmm11
00007431745ce7c0  pmovzxdq xmm12, xmm12
00007431745ce7c6  psllq xmm12, 0x00
00007431745ce7cc  movq xmm14, qword ptr [r15+0x210]
00007431745ce7d5  movq xmm13, qword ptr [r15+0x110]
00007431745ce7de  paddd xmm14, xmm13
00007431745ce7e3  movq xmm14, xmm14
00007431745ce7e8  vcvtuqq2pd xmm12, xmm12
00007431745ce7ee  pmovzxdq xmm14, xmm14
00007431745ce7f4  psllq xmm14, 0x00
00007431745ce7fa  vcvtuqq2pd xmm14, xmm14
00007431745ce800  movaps xmm13, xmm12
00007431745ce804  mulpd xmm13, xmm1
00007431745ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007431745ce80f  ptest xmm11, xmm11
00007431745ce815  jnz 0x00007431745CE8FF
00007431745ce81b  movaps [r15+0x220], xmm13
00007431745ce823  mov eax, 0x430720
00007431745ce828  movups [r13+rax*1], xmm13
00007431745ce82e  movaps xmm1, xmm14
00007431745ce832  mulpd xmm1, xmm15
00007431745ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007431745ce83c  ptest xmm13, xmm13
00007431745ce842  jnz 0x00007431745CEA4C
00007431745ce848  movaps [r15+0x210], xmm1
00007431745ce850  mov eax, 0x430518
00007431745ce855  movups [r13+rax*1], xmm1
00007431745ce85b  mov qword ptr [r15+0x48], 0x10
00007431745ce863  xor eax, eax
00007431745ce865  mov r14d, 0x10
00007431745ce86b  mov r12d, 0x200
00007431745ce871  cmp r14, r12
00007431745ce874  cmc
00007431745ce875  lahf
00007431745ce876  seto al
00007431745ce879  mov [r15+0x108], eax
00007431745ce880  mov eax, [r15+0x108]
00007431745ce887  sahf
00007431745ce888  jnz 0x00007431745CE8BA
00007431745ce88a  cmp dword ptr [r15+0x318], 0x00
00007431745ce892  jz 0x00007431745CEFF0
00007431745ce898  nop [rax+rax*1], ax
00007431745ce8a1  nop [rax+rax*1], eax
00007431745ce8a9  mov eax, 0x4101EC
00007431745ce8ae  mov [r15+0x100], rax
00007431745ce8b5  jmp 0x00007431743FE110
00007431745ce8ba  cmp dword ptr [r15+0x318], 0x00
00007431745ce8c2  jz 0x00007431745CEBA0
00007431745ce8c8  nop [rax+rax*1], ax
00007431745ce8d1  nop [rax+rax*1], eax
00007431745ce8d9  mov eax, 0x4101AC
00007431745ce8de  mov [r15+0x100], rax
00007431745ce8e5  jmp 0x00007431743FE110
00007431745ce8ea  int3
00007431745ce8eb  call 0x000074317440DC20
00007431745ce8f0  jmp 0x00007431745CE6D2
00007431745ce8f5  call 0x000074317440C260
00007431745ce8fa  jmp 0x00007431745CE74F
00007431745ce8ff  sub rsp, 0x08
00007431745ce903  push rax
00007431745ce904  push rcx
00007431745ce905  push rdx
00007431745ce906  push rdi
00007431745ce907  push rsi
00007431745ce908  push r8
00007431745ce90a  push r9
00007431745ce90c  push r10
00007431745ce90e  push r11
00007431745ce910  sub rsp, 0xF0
00007431745ce917  vmovaps [rsp], xmm0
00007431745ce91c  vmovaps [rsp+0x10], xmm1
00007431745ce922  vmovaps [rsp+0x20], xmm2
00007431745ce928  vmovaps [rsp+0x30], xmm3
00007431745ce92e  vmovaps [rsp+0x40], xmm4
00007431745ce934  vmovaps [rsp+0x50], xmm5
00007431745ce93a  vmovaps [rsp+0x60], xmm6
00007431745ce940  vmovaps [rsp+0x70], xmm7
00007431745ce946  vmovaps [rsp+0x80], xmm8
00007431745ce94f  vmovaps [rsp+0x90], xmm9
00007431745ce958  vmovaps [rsp+0xA0], xmm10
00007431745ce961  vmovaps [rsp+0xB0], xmm11
00007431745ce96a  vmovaps [rsp+0xC0], xmm12
00007431745ce973  vmovaps [rsp+0xD0], xmm14
00007431745ce97c  vmovaps [rsp+0xE0], xmm15
00007431745ce985  sub rsp, 0x30
00007431745ce989  movaps [rsp], xmm13
00007431745ce98e  movaps [rsp+0x10], xmm12
00007431745ce994  movaps [rsp+0x20], xmm1
00007431745ce999  lea rdi, [rsp]
00007431745ce99d  mov esi, 0x00
00007431745ce9a2  mov rax, 0x56C40959E530
00007431745ce9ac  call rax
00007431745ce9ae  movaps xmm13, [rsp]
00007431745ce9b3  add rsp, 0x30
00007431745ce9b7  vmovaps xmm0, [rsp]
00007431745ce9bc  vmovaps xmm1, [rsp+0x10]
00007431745ce9c2  vmovaps xmm2, [rsp+0x20]
00007431745ce9c8  vmovaps xmm3, [rsp+0x30]
00007431745ce9ce  vmovaps xmm4, [rsp+0x40]
00007431745ce9d4  vmovaps xmm5, [rsp+0x50]
00007431745ce9da  vmovaps xmm6, [rsp+0x60]
00007431745ce9e0  vmovaps xmm7, [rsp+0x70]
00007431745ce9e6  vmovaps xmm8, [rsp+0x80]
00007431745ce9ef  vmovaps xmm9, [rsp+0x90]
00007431745ce9f8  vmovaps xmm10, [rsp+0xA0]
00007431745cea01  vmovaps xmm11, [rsp+0xB0]
00007431745cea0a  vmovaps xmm12, [rsp+0xC0]
00007431745cea13  vmovaps xmm14, [rsp+0xD0]
00007431745cea1c  vmovaps xmm15, [rsp+0xE0]
00007431745cea25  add rsp, 0xF0
00007431745cea2c  pop r11
00007431745cea2e  pop r10
00007431745cea30  pop r9
00007431745cea32  pop r8
00007431745cea34  pop rsi
00007431745cea35  pop rdi
00007431745cea36  pop rdx
00007431745cea37  pop rcx
00007431745cea38  pop rax
00007431745cea39  add rsp, 0x08
00007431745cea3d  jmp 0x00007431745CE81B
00007431745cea42  call 0x000074317440C380
00007431745cea47  jmp 0x00007431745CE82E
00007431745cea4c  sub rsp, 0x08
00007431745cea50  push rax
00007431745cea51  push rcx
00007431745cea52  push rdx
00007431745cea53  push rdi
00007431745cea54  push rsi
00007431745cea55  push r8
00007431745cea57  push r9
00007431745cea59  push r10
00007431745cea5b  push r11
00007431745cea5d  sub rsp, 0xF0
00007431745cea64  vmovaps [rsp], xmm0
00007431745cea69  vmovaps [rsp+0x10], xmm2
00007431745cea6f  vmovaps [rsp+0x20], xmm3
00007431745cea75  vmovaps [rsp+0x30], xmm4
00007431745cea7b  vmovaps [rsp+0x40], xmm5
00007431745cea81  vmovaps [rsp+0x50], xmm6
00007431745cea87  vmovaps [rsp+0x60], xmm7
00007431745cea8d  vmovaps [rsp+0x70], xmm8
00007431745cea93  vmovaps [rsp+0x80], xmm9
00007431745cea9c  vmovaps [rsp+0x90], xmm10
00007431745ceaa5  vmovaps [rsp+0xA0], xmm11
00007431745ceaae  vmovaps [rsp+0xB0], xmm12
00007431745ceab7  vmovaps [rsp+0xC0], xmm13
00007431745ceac0  vmovaps [rsp+0xD0], xmm14
00007431745ceac9  vmovaps [rsp+0xE0], xmm15
00007431745cead2  sub rsp, 0x30
00007431745cead6  movaps [rsp], xmm1
00007431745ceada  movaps [rsp+0x10], xmm14
00007431745ceae0  movaps [rsp+0x20], xmm15
00007431745ceae6  lea rdi, [rsp]
00007431745ceaea  mov esi, 0x00
00007431745ceaef  mov rax, 0x56C40959E530
00007431745ceaf9  call rax
00007431745ceafb  movaps xmm1, [rsp]
00007431745ceaff  add rsp, 0x30
00007431745ceb03  vmovaps xmm0, [rsp]
00007431745ceb08  vmovaps xmm2, [rsp+0x10]
00007431745ceb0e  vmovaps xmm3, [rsp+0x20]
00007431745ceb14  vmovaps xmm4, [rsp+0x30]
00007431745ceb1a  vmovaps xmm5, [rsp+0x40]
00007431745ceb20  vmovaps xmm6, [rsp+0x50]
00007431745ceb26  vmovaps xmm7, [rsp+0x60]
00007431745ceb2c  vmovaps xmm8, [rsp+0x70]
00007431745ceb32  vmovaps xmm9, [rsp+0x80]
00007431745ceb3b  vmovaps xmm10, [rsp+0x90]
00007431745ceb44  vmovaps xmm11, [rsp+0xA0]
00007431745ceb4d  vmovaps xmm12, [rsp+0xB0]
00007431745ceb56  vmovaps xmm13, [rsp+0xC0]
00007431745ceb5f  vmovaps xmm14, [rsp+0xD0]
00007431745ceb68  vmovaps xmm15, [rsp+0xE0]
00007431745ceb71  add rsp, 0xF0
00007431745ceb78  pop r11
00007431745ceb7a  pop r10
00007431745ceb7c  pop r9
00007431745ceb7e  pop r8
00007431745ceb80  pop rsi
00007431745ceb81  pop rdi
00007431745ceb82  pop rdx
00007431745ceb83  pop rcx
00007431745ceb84  pop rax
00007431745ceb85  add rsp, 0x08
00007431745ceb89  jmp 0x00007431745CE848
00007431745ceb8e  call 0x00007431743FF540
00007431745ceb93  jmp 0x00007431745CE85B
00007431745ceb98  int3
00007431745ceb99  nop [rax], eax
00007431745ceba0  movaps xmm1, [r15+0x180]
00007431745ceba8  vpmovqd xmm15, xmm1
00007431745cebae  pxor xmm14, xmm14
00007431745cebb3  punpcklqdq xmm15, xmm14
00007431745cebb8  movaps [r15+0x210], xmm15
00007431745cebc0  movq xmm15, qword ptr [r15+0x120]
00007431745cebc9  movq xmm14, qword ptr [r15+0x130]
00007431745cebd2  psubd xmm15, xmm14
00007431745cebd7  movq xmm15, xmm15
00007431745cebdc  movaps xmm13, [r15+0x170]
00007431745cebe4  paddq xmm1, xmm13
00007431745cebe9  movaps [r15+0x180], xmm1
00007431745cebf1  movq xmm1, qword ptr [r15+0x150]
00007431745cebfa  paddd xmm14, xmm1
00007431745cebff  movq xmm14, xmm14
00007431745cec04  movq xmm14, xmm14
00007431745cec09  movaps [r15+0x130], xmm14
00007431745cec11  pmovzxdq xmm15, xmm15
00007431745cec17  psllq xmm15, 0x00
00007431745cec1d  movq xmm1, qword ptr [r15+0x210]
00007431745cec26  movq xmm14, qword ptr [r15+0x110]
00007431745cec2f  paddd xmm1, xmm14
00007431745cec34  movq xmm1, xmm1
00007431745cec38  vcvtuqq2pd xmm15, xmm15
00007431745cec3e  pmovzxdq xmm1, xmm1
00007431745cec43  psllq xmm1, 0x00
00007431745cec48  vcvtuqq2pd xmm1, xmm1
00007431745cec4e  movaps xmm14, [r15+0x140]
00007431745cec56  movaps xmm13, xmm15
00007431745cec5a  mulpd xmm13, xmm14
00007431745cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007431745cec65  ptest xmm12, xmm12
00007431745cec6b  jnz 0x00007431745CED4E
00007431745cec71  movaps [r15+0x220], xmm13
00007431745cec79  mov rax, [r15+0x48]
00007431745cec7d  mov r14, [r15+0x50]
00007431745cec81  lea r12, [r14+rax*1]
00007431745cec85  movups [r13+r12*1], xmm13
00007431745cec8b  movaps xmm15, [r15+0x160]
00007431745cec93  movaps xmm14, xmm1
00007431745cec97  mulpd xmm14, xmm15
00007431745cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007431745ceca2  ptest xmm13, xmm13
00007431745ceca8  jnz 0x00007431745CEE9C
00007431745cecae  movaps [r15+0x210], xmm14
00007431745cecb6  mov r14, [r15+0x40]
00007431745cecba  lea r12, [r14+rax*1]
00007431745cecbe  movups [r13+r12*1], xmm14
00007431745cecc4  lea r14, [rax+0x10]
00007431745cecc8  mov [r15+0x48], r14
00007431745ceccc  xor eax, eax
00007431745cecce  mov r12d, 0x200
00007431745cecd4  cmp r14, r12
00007431745cecd7  cmc
00007431745cecd8  lahf
00007431745cecd9  seto al
00007431745cecdc  mov [r15+0x108], eax
00007431745cece3  mov eax, [r15+0x108]
00007431745cecea  sahf
00007431745ceceb  jnz 0x00007431745CED1D
00007431745ceced  cmp dword ptr [r15+0x318], 0x00
00007431745cecf5  jz 0x00007431745CEFF0
00007431745cecfb  nop [rax+rax*1], ax
00007431745ced04  nop [rax+rax*1], eax
00007431745ced0c  mov eax, 0x4101EC
00007431745ced11  mov [r15+0x100], rax
00007431745ced18  jmp 0x00007431743FE110
00007431745ced1d  cmp dword ptr [r15+0x318], 0x00
00007431745ced25  jz 0x00007431745CEBA0
00007431745ced2b  nop [rax+rax*1], ax
00007431745ced34  nop [rax+rax*1], eax
00007431745ced3c  mov eax, 0x4101AC
00007431745ced41  mov [r15+0x100], rax
00007431745ced48  jmp 0x00007431743FE110
00007431745ced4d  int3
00007431745ced4e  sub rsp, 0x08
00007431745ced52  push rax
00007431745ced53  push rcx
00007431745ced54  push rdx
00007431745ced55  push rdi
00007431745ced56  push rsi
00007431745ced57  push r8
00007431745ced59  push r9
00007431745ced5b  push r10
00007431745ced5d  push r11
00007431745ced5f  sub rsp, 0xF0
00007431745ced66  vmovaps [rsp], xmm0
00007431745ced6b  vmovaps [rsp+0x10], xmm1
00007431745ced71  vmovaps [rsp+0x20], xmm2
00007431745ced77  vmovaps [rsp+0x30], xmm3
00007431745ced7d  vmovaps [rsp+0x40], xmm4
00007431745ced83  vmovaps [rsp+0x50], xmm5
00007431745ced89  vmovaps [rsp+0x60], xmm6
00007431745ced8f  vmovaps [rsp+0x70], xmm7
00007431745ced95  vmovaps [rsp+0x80], xmm8
00007431745ced9e  vmovaps [rsp+0x90], xmm9
00007431745ceda7  vmovaps [rsp+0xA0], xmm10
00007431745cedb0  vmovaps [rsp+0xB0], xmm11
00007431745cedb9  vmovaps [rsp+0xC0], xmm12
00007431745cedc2  vmovaps [rsp+0xD0], xmm14
00007431745cedcb  vmovaps [rsp+0xE0], xmm15
00007431745cedd4  sub rsp, 0x30
00007431745cedd8  movaps [rsp], xmm13
00007431745ceddd  movaps [rsp+0x10], xmm15
00007431745cede3  movaps [rsp+0x20], xmm14
00007431745cede9  lea rdi, [rsp]
00007431745ceded  mov esi, 0x00
00007431745cedf2  mov rax, 0x56C40959E530
00007431745cedfc  call rax
00007431745cedfe  movaps xmm13, [rsp]
00007431745cee03  add rsp, 0x30
00007431745cee07  vmovaps xmm0, [rsp]
00007431745cee0c  vmovaps xmm1, [rsp+0x10]
00007431745cee12  vmovaps xmm2, [rsp+0x20]
00007431745cee18  vmovaps xmm3, [rsp+0x30]
00007431745cee1e  vmovaps xmm4, [rsp+0x40]
00007431745cee24  vmovaps xmm5, [rsp+0x50]
00007431745cee2a  vmovaps xmm6, [rsp+0x60]
00007431745cee30  vmovaps xmm7, [rsp+0x70]
00007431745cee36  vmovaps xmm8, [rsp+0x80]
00007431745cee3f  vmovaps xmm9, [rsp+0x90]
00007431745cee48  vmovaps xmm10, [rsp+0xA0]
00007431745cee51  vmovaps xmm11, [rsp+0xB0]
00007431745cee5a  vmovaps xmm12, [rsp+0xC0]
00007431745cee63  vmovaps xmm14, [rsp+0xD0]
00007431745cee6c  vmovaps xmm15, [rsp+0xE0]
00007431745cee75  add rsp, 0xF0
00007431745cee7c  pop r11
00007431745cee7e  pop r10
00007431745cee80  pop r9
00007431745cee82  pop r8
00007431745cee84  pop rsi
00007431745cee85  pop rdi
00007431745cee86  pop rdx
00007431745cee87  pop rcx
00007431745cee88  pop rax
00007431745cee89  add rsp, 0x08
00007431745cee8d  jmp 0x00007431745CEC71
00007431745cee92  call 0x00007431744C2240
00007431745cee97  jmp 0x00007431745CEC8B
00007431745cee9c  sub rsp, 0x08
00007431745ceea0  push rax
00007431745ceea1  push rcx
00007431745ceea2  push rdx
00007431745ceea3  push rdi
00007431745ceea4  push rsi
00007431745ceea5  push r8
00007431745ceea7  push r9
00007431745ceea9  push r10
00007431745ceeab  push r11
00007431745ceead  sub rsp, 0xF0
00007431745ceeb4  vmovaps [rsp], xmm0
00007431745ceeb9  vmovaps [rsp+0x10], xmm1
00007431745ceebf  vmovaps [rsp+0x20], xmm2
00007431745ceec5  vmovaps [rsp+0x30], xmm3
00007431745ceecb  vmovaps [rsp+0x40], xmm4
00007431745ceed1  vmovaps [rsp+0x50], xmm5
00007431745ceed7  vmovaps [rsp+0x60], xmm6
00007431745ceedd  vmovaps [rsp+0x70], xmm7
00007431745ceee3  vmovaps [rsp+0x80], xmm8
00007431745ceeec  vmovaps [rsp+0x90], xmm9
00007431745ceef5  vmovaps [rsp+0xA0], xmm10
00007431745ceefe  vmovaps [rsp+0xB0], xmm11
00007431745cef07  vmovaps [rsp+0xC0], xmm12
00007431745cef10  vmovaps [rsp+0xD0], xmm13
00007431745cef19  vmovaps [rsp+0xE0], xmm15
00007431745cef22  sub rsp, 0x30
00007431745cef26  movaps [rsp], xmm14
00007431745cef2b  movaps [rsp+0x10], xmm1
00007431745cef30  movaps [rsp+0x20], xmm15
00007431745cef36  lea rdi, [rsp]
00007431745cef3a  mov esi, 0x00
00007431745cef3f  mov rax, 0x56C40959E530
00007431745cef49  call rax
00007431745cef4b  movaps xmm14, [rsp]
00007431745cef50  add rsp, 0x30
00007431745cef54  vmovaps xmm0, [rsp]
00007431745cef59  vmovaps xmm1, [rsp+0x10]
00007431745cef5f  vmovaps xmm2, [rsp+0x20]
00007431745cef65  vmovaps xmm3, [rsp+0x30]
00007431745cef6b  vmovaps xmm4, [rsp+0x40]
00007431745cef71  vmovaps xmm5, [rsp+0x50]
00007431745cef77  vmovaps xmm6, [rsp+0x60]
00007431745cef7d  vmovaps xmm7, [rsp+0x70]
00007431745cef83  vmovaps xmm8, [rsp+0x80]
00007431745cef8c  vmovaps xmm9, [rsp+0x90]
00007431745cef95  vmovaps xmm10, [rsp+0xA0]
00007431745cef9e  vmovaps xmm11, [rsp+0xB0]
00007431745cefa7  vmovaps xmm12, [rsp+0xC0]
00007431745cefb0  vmovaps xmm13, [rsp+0xD0]
00007431745cefb9  vmovaps xmm15, [rsp+0xE0]
00007431745cefc2  add rsp, 0xF0
00007431745cefc9  pop r11
00007431745cefcb  pop r10
00007431745cefcd  pop r9
00007431745cefcf  pop r8
00007431745cefd1  pop rsi
00007431745cefd2  pop rdi
00007431745cefd3  pop rdx
00007431745cefd4  pop rcx
00007431745cefd5  pop rax
00007431745cefd6  add rsp, 0x08
00007431745cefda  jmp 0x00007431745CECAE
00007431745cefdf  call 0x00007431744C34C0
00007431745cefe4  jmp 0x00007431745CECC4
00007431745cefe9  int3
00007431745cefea  nop [rax+rax*1], ax
00007431745ceff0  mov rax, [r15+0xF8]
00007431745ceff7  lea r14, [rax-0x150]
00007431745ceffe  mov [r15+0xF8], r14
00007431745cf005  mov rax, [r15+0x50]
00007431745cf009  lea r12, [rax+0x80]
00007431745cf010  movups xmm1, [r13+r12*1]
00007431745cf016  lea r12, [rax+0x90]
00007431745cf01d  movups xmm15, [r13+r12*1]
00007431745cf023  mov qword ptr [r15+0x48], 0x00
00007431745cf02b  lea r12, [rax+0x40]
00007431745cf02f  movups xmm14, [r13+r12*1]
00007431745cf035  lea r12, [rax+0x50]
00007431745cf039  movups xmm13, [r13+r12*1]
00007431745cf03f  lea r12, [r14+0x120]
00007431745cf046  movq xmm12, qword ptr [r15+0x1C0]
00007431745cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007431745cf058  movq r11, xmm12
00007431745cf05d  movq r10, xmm11
00007431745cf062  mov [r13+r12*1], r11
00007431745cf067  lea r12, [r14+0x128]
00007431745cf06e  mov [r13+r12*1], r10
00007431745cf073  vxorps xmm12, xmm12, xmm12
00007431745cf078  vpbroadcastq xmm12, xmm12
00007431745cf07d  lea r12, [r14+0x100]
00007431745cf084  movq xmm11, qword ptr [r15+0x200]
00007431745cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007431745cf096  movq r11, xmm11
00007431745cf09b  movq r10, xmm10
00007431745cf0a0  mov [r13+r12*1], r11
00007431745cf0a5  lea r12, [r14+0x108]
00007431745cf0ac  mov [r13+r12*1], r10
00007431745cf0b1  lea r12, [r14+0xE0]
00007431745cf0b8  movups [r13+r12*1], xmm15
00007431745cf0be  lea r12, [r14+0xF0]
00007431745cf0c5  movups [r13+r12*1], xmm1
00007431745cf0cb  lea r12, [rax+0xC0]
00007431745cf0d2  movups xmm1, [r13+r12*1]
00007431745cf0d8  lea r12, [rax+0xD0]
00007431745cf0df  movups xmm15, [r13+r12*1]
00007431745cf0e5  lea r12, [r14+0x110]
00007431745cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007431745cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007431745cf0fe  movq r11, xmm11
00007431745cf103  movq r10, xmm10
00007431745cf108  mov [r13+r12*1], r11
00007431745cf10d  lea r12, [r14+0x118]
00007431745cf114  mov [r13+r12*1], r10
00007431745cf119  movups xmm11, [r13+rax*1]
00007431745cf11f  lea r12, [rax+0x10]
00007431745cf123  movups xmm10, [r13+r12*1]
00007431745cf129  lea r12, [r14+0x130]
00007431745cf130  movq xmm9, qword ptr [r15+0x1A0]
00007431745cf139  movq xmm8, qword ptr [r15+0x190]
00007431745cf142  movq r11, xmm9
00007431745cf147  movq r10, xmm8
00007431745cf14c  mov [r13+r12*1], r11
00007431745cf151  lea r12, [r14+0x138]
00007431745cf158  mov [r13+r12*1], r10
00007431745cf15d  lea r12, [rax+0x140]
00007431745cf164  movups xmm9, [r13+r12*1]
00007431745cf16a  lea r12, [rax+0x150]
00007431745cf171  movups xmm8, [r13+r12*1]
00007431745cf177  lea r12, [r14+0xC0]
00007431745cf17e  movups [r13+r12*1], xmm15
00007431745cf184  lea r12, [r14+0xD0]
00007431745cf18b  movups [r13+r12*1], xmm1
00007431745cf191  lea r12, [rax+0x100]
00007431745cf198  movups xmm1, [r13+r12*1]
00007431745cf19e  lea r12, [rax+0x110]
00007431745cf1a5  movups xmm15, [r13+r12*1]
00007431745cf1ab  lea r12, [r14+0x140]
00007431745cf1b2  mov r11, [r15+0xE8]
00007431745cf1b9  mov [r13+r12*1], r11
00007431745cf1be  lea r12, [rax+0x180]
00007431745cf1c5  movups xmm7, [r13+r12*1]
00007431745cf1cb  lea r12, [rax+0x190]
00007431745cf1d2  movups xmm6, [r13+r12*1]
00007431745cf1d8  lea r12, [rax+0x1C0]
00007431745cf1df  movups xmm5, [r13+r12*1]
00007431745cf1e5  lea r12, [rax+0x1D0]
00007431745cf1ec  movups xmm4, [r13+r12*1]
00007431745cf1f2  lea r12, [r14+0x20]
00007431745cf1f6  movups [r13+r12*1], xmm1
00007431745cf1fc  lea r12, [r14+0x30]
00007431745cf200  movups [r13+r12*1], xmm13
00007431745cf206  lea r12, [rax+0x60]
00007431745cf20a  movups xmm1, [r13+r12*1]
00007431745cf210  lea r12, [rax+0x70]
00007431745cf214  movups xmm13, [r13+r12*1]
00007431745cf21a  lea r12, [rax+0x20]
00007431745cf21e  movups xmm3, [r13+r12*1]
00007431745cf224  lea r12, [rax+0x30]
00007431745cf228  movups xmm2, [r13+r12*1]
00007431745cf22e  movaps [r15+0x1F0], xmm2
00007431745cf236  lea r12, [r14+0x60]
00007431745cf23a  movups [r13+r12*1], xmm11
00007431745cf240  lea r12, [r14+0x70]
00007431745cf244  movups [r13+r12*1], xmm5
00007431745cf24a  lea r12, [rax+0xE0]
00007431745cf251  movups xmm11, [r13+r12*1]
00007431745cf257  lea r12, [rax+0xF0]
00007431745cf25e  movups xmm5, [r13+r12*1]
00007431745cf264  lea r12, [r14+0xA0]
00007431745cf26b  movups [r13+r12*1], xmm13
00007431745cf271  lea r12, [r14+0xB0]
00007431745cf278  movups [r13+r12*1], xmm1
00007431745cf27e  lea r12, [rax+0xA0]
00007431745cf285  movups xmm1, [r13+r12*1]
00007431745cf28b  lea r12, [rax+0xB0]
00007431745cf292  movups xmm13, [r13+r12*1]
00007431745cf298  lea r12, [rax+0x120]
00007431745cf29f  vmovaps [rsp+0x10], xmm1
00007431745cf2a5  movups xmm1, [r13+r12*1]
00007431745cf2ab  lea r12, [rax+0x130]
00007431745cf2b2  vmovaps [rsp+0x20], xmm1
00007431745cf2b8  movups xmm1, [r13+r12*1]
00007431745cf2be  lea r12, [rax+0x160]
00007431745cf2c5  vmovaps [rsp+0x30], xmm1
00007431745cf2cb  movups xmm1, [r13+r12*1]
00007431745cf2d1  lea r12, [rax+0x170]
00007431745cf2d8  vmovaps [rsp+0x40], xmm1
00007431745cf2de  movups xmm1, [r13+r12*1]
00007431745cf2e4  movaps [r15+0x2B0], xmm1
00007431745cf2ec  lea r12, [r14+0x80]
00007431745cf2f3  movups [r13+r12*1], xmm13
00007431745cf2f9  lea r12, [r14+0x90]
00007431745cf300  vmovaps xmm13, [rsp+0x10]
00007431745cf306  movups [r13+r12*1], xmm13
00007431745cf30c  lea r12, [rax+0x1A0]
00007431745cf313  movups xmm13, [r13+r12*1]
00007431745cf319  lea r12, [rax+0x1B0]
00007431745cf320  vmovaps [rsp+0x10], xmm1
00007431745cf326  movups xmm1, [r13+r12*1]
00007431745cf32c  movaps [r15+0x290], xmm13
00007431745cf334  movaps [r15+0x1E0], xmm1
00007431745cf33c  lea r12, [rax+0x1E0]
00007431745cf343  vmovaps [rsp+0x50], xmm1
00007431745cf349  movups xmm1, [r13+r12*1]
00007431745cf34f  lea r12, [rax+0x1F0]
00007431745cf356  vmovaps [rsp+0x60], xmm1
00007431745cf35c  movups xmm1, [r13+r12*1]
00007431745cf362  mov qword ptr [r15+0x50], 0x430920
00007431745cf36a  lea rax, [r14+0x40]
00007431745cf36e  vmovaps [rsp+0x70], xmm1
00007431745cf374  vmovaps xmm1, [rsp+0x40]
00007431745cf37a  movups [r13+rax*1], xmm1
00007431745cf380  lea rax, [r14+0x50]
00007431745cf384  movups [r13+rax*1], xmm10
00007431745cf38a  vmovaps xmm1, [rsp+0x70]
00007431745cf390  movups [r13+r14*1], xmm1
00007431745cf396  lea rax, [r14+0x10]
00007431745cf39a  vmovaps xmm1, [rsp+0x60]
00007431745cf3a0  movups [r13+rax*1], xmm1
00007431745cf3a6  mov rax, [r15+0x40]
00007431745cf3aa  vmovaps [rsp+0x40], xmm3
00007431745cf3b0  vmovaps xmm1, [rsp+0x40]
00007431745cf3b6  por xmm3, xmm1
00007431745cf3ba  vmovaps [rsp+0x40], xmm6
00007431745cf3c0  vmovaps xmm10, [rsp+0x40]
00007431745cf3c6  por xmm6, xmm10
00007431745cf3cb  lea r12, [rax+0x30]
00007431745cf3cf  mov r11, [r13+r12*1]
00007431745cf3d4  lea r12, [rax+0x38]
00007431745cf3d8  mov r10, [r13+r12*1]
00007431745cf3dd  movq xmm10, r11
00007431745cf3e2  vmovaps [rsp+0x40], xmm1
00007431745cf3e8  movq xmm1, r10
00007431745cf3ed  movq xmm10, xmm10
00007431745cf3f2  vmovaps [rsp+0x60], xmm10
00007431745cf3f8  movq xmm10, xmm10
00007431745cf3fd  movaps [r15+0x130], xmm10
00007431745cf405  movq xmm1, xmm1
00007431745cf409  vmovaps [rsp+0x70], xmm1
00007431745cf40f  movq xmm1, xmm1
00007431745cf413  movaps [r15+0x280], xmm1
00007431745cf41b  vmovaps [rsp+0x80], xmm9
00007431745cf424  vmovaps xmm1, [rsp+0x80]
00007431745cf42d  por xmm9, xmm1
00007431745cf432  lea r12, [rax+0x20]
00007431745cf436  mov r11, [r13+r12*1]
00007431745cf43b  lea r12, [rax+0x28]
00007431745cf43f  mov r10, [r13+r12*1]
00007431745cf444  movq xmm1, r11
00007431745cf449  movq xmm10, r10
00007431745cf44e  movq xmm1, xmm1
00007431745cf452  vmovaps [rsp+0x80], xmm1
00007431745cf45b  movq xmm1, xmm1
00007431745cf45f  movaps [r15+0x150], xmm1
00007431745cf467  movq xmm10, xmm10
00007431745cf46c  vmovaps [rsp+0x90], xmm10
00007431745cf475  movq xmm10, xmm10
00007431745cf47a  movaps [r15+0x140], xmm10
00007431745cf482  lea r12, [rax+0x10]
00007431745cf486  mov r11, [r13+r12*1]
00007431745cf48b  lea r12, [rax+0x18]
00007431745cf48f  mov r10, [r13+r12*1]
00007431745cf494  movq xmm1, r11
00007431745cf499  movq xmm10, r10
00007431745cf49e  movq xmm1, xmm1
00007431745cf4a2  vmovaps [rsp+0xA0], xmm1
00007431745cf4ab  movq xmm1, xmm1
00007431745cf4af  movaps [r15+0x170], xmm1
00007431745cf4b7  movq xmm10, xmm10
00007431745cf4bc  vmovaps [rsp+0xB0], xmm10
00007431745cf4c5  movq xmm10, xmm10
00007431745cf4ca  movaps [r15+0x160], xmm10
00007431745cf4d2  mov r12, [r13+rax*1]
00007431745cf4d7  vmovq xmm1, r12
00007431745cf4dc  vpbroadcastq xmm1, xmm1
00007431745cf4e1  lea r12, [rax+0x08]
00007431745cf4e5  mov rax, [r13+r12*1]
00007431745cf4ea  movq xmm10, rax
00007431745cf4ef  movaps [r15+0x230], xmm10
00007431745cf4f7  lea rax, [r14+0x50]
00007431745cf4fb  movups xmm10, [r13+rax*1]
00007431745cf501  lea rax, [r14+0x60]
00007431745cf505  vmovaps [rsp+0xC0], xmm1
00007431745cf50e  movups xmm1, [r13+rax*1]
00007431745cf514  lea rax, [r14+0x30]
00007431745cf518  vmovaps [rsp+0xD0], xmm1
00007431745cf521  movups xmm1, [r13+rax*1]
00007431745cf527  mov qword ptr [r15+0x60], 0x430920
00007431745cf52f  mov qword ptr [r15+0x58], 0x40
00007431745cf537  vmovaps [rsp+0xE0], xmm1
00007431745cf540  vmovaps [rsp+0xF0], xmm15
00007431745cf549  vmovaps xmm15, [rsp+0xC0]
00007431745cf552  vmovaps [rsp+0xC0], xmm14
00007431745cf55b  vmovaps xmm14, [rsp+0x40]
00007431745cf561  vmovaps [rsp+0x40], xmm13
00007431745cf567  movaps xmm1, xmm15
00007431745cf56b  mulpd xmm1, xmm14
00007431745cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007431745cf575  ptest xmm13, xmm13
00007431745cf57b  jnz 0x00007431745D0682
00007431745cf581  movq xmm14, qword ptr [r15+0x230]
00007431745cf58a  vmovaps [rsp+0x100], xmm14
00007431745cf593  vpermilpd xmm14, xmm14, 0x00
00007431745cf599  vmovaps [rsp+0x110], xmm1
00007431745cf5a2  vmovaps xmm1, [rsp+0xE0]
00007431745cf5ab  vmovaps [rsp+0xE0], xmm15
00007431745cf5b4  movaps xmm13, xmm1
00007431745cf5b8  mulpd xmm13, xmm14
00007431745cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007431745cf5c3  ptest xmm15, xmm15
00007431745cf5c9  jnz 0x00007431745D07C4
00007431745cf5cf  vxorps xmm1, xmm1, xmm1
00007431745cf5d3  vpbroadcastq xmm1, xmm1
00007431745cf5d8  vmovaps xmm14, [rsp+0xE0]
00007431745cf5e1  vmovaps [rsp+0xE0], xmm1
00007431745cf5ea  vmovaps xmm1, [rsp+0xD0]
00007431745cf5f3  vmovaps [rsp+0xD0], xmm13
00007431745cf5fc  movaps xmm15, xmm14
00007431745cf600  mulpd xmm15, xmm1
00007431745cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007431745cf60b  ptest xmm13, xmm13
00007431745cf611  jnz 0x00007431745D0907
00007431745cf617  movaps xmm1, xmm14
00007431745cf61b  mulpd xmm1, xmm10
00007431745cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007431745cf625  ptest xmm13, xmm13
00007431745cf62b  jnz 0x00007431745D0A4A
00007431745cf631  movaps xmm13, xmm14
00007431745cf635  mulpd xmm13, xmm2
00007431745cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007431745cf640  ptest xmm10, xmm10
00007431745cf646  jnz 0x00007431745D0B8C
00007431745cf64c  vmovaps [rsp+0x120], xmm7
00007431745cf655  vmovaps xmm14, [rsp+0x120]
00007431745cf65e  por xmm7, xmm14
00007431745cf663  vmovaps xmm14, [rsp+0xC0]
00007431745cf66c  vmovaps xmm10, [rsp+0xC0]
00007431745cf675  por xmm14, xmm10
00007431745cf67a  vmovaps xmm2, [rsp+0x100]
00007431745cf683  vpermilpd xmm2, xmm2, 0x00
00007431745cf689  vmovaps [rsp+0xC0], xmm1
00007431745cf692  vmovaps [rsp+0x120], xmm15
00007431745cf69b  movaps xmm1, xmm10
00007431745cf69f  mulpd xmm1, xmm2
00007431745cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007431745cf6a8  ptest xmm15, xmm15
00007431745cf6ae  jnz 0x00007431745D0CCF
00007431745cf6b4  xor eax, eax
00007431745cf6b6  mov r12d, 0x40
00007431745cf6bc  mov r11d, 0x200
00007431745cf6c2  cmp r12, r11
00007431745cf6c5  cmc
00007431745cf6c6  lahf
00007431745cf6c7  seto al
00007431745cf6ca  mov [r15+0x108], eax
00007431745cf6d1  vmovaps xmm10, [rsp+0x110]
00007431745cf6da  vmovaps xmm2, [rsp+0xE0]
00007431745cf6e3  vmovaps [rsp+0xE0], xmm1
00007431745cf6ec  movaps xmm15, xmm10
00007431745cf6f0  addpd xmm15, xmm2
00007431745cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007431745cf6fb  ptest xmm1, xmm1
00007431745cf700  jnz 0x00007431745D0E10
00007431745cf706  vmovaps xmm10, [rsp+0x120]
00007431745cf70f  vmovaps [rsp+0x110], xmm15
00007431745cf718  movaps xmm1, xmm10
00007431745cf71c  addpd xmm1, xmm12
00007431745cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007431745cf726  ptest xmm15, xmm15
00007431745cf72c  jnz 0x00007431745D0F53
00007431745cf732  vmovaps xmm10, [rsp+0xC0]
00007431745cf73b  vmovaps [rsp+0xC0], xmm1
00007431745cf744  movaps xmm15, xmm10
00007431745cf748  addpd xmm15, xmm12
00007431745cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007431745cf753  ptest xmm1, xmm1
00007431745cf758  jnz 0x00007431745D1095
00007431745cf75e  vmovaps xmm1, [rsp+0x30]
00007431745cf764  vmovaps xmm12, [rsp+0x30]
00007431745cf76a  por xmm1, xmm12
00007431745cf76f  vmovaps xmm12, [rsp+0x20]
00007431745cf775  vmovaps xmm10, [rsp+0x20]
00007431745cf77b  por xmm12, xmm10
00007431745cf780  vmovaps [rsp+0x20], xmm5
00007431745cf786  vmovaps xmm10, [rsp+0x20]
00007431745cf78c  por xmm5, xmm10
00007431745cf791  vmovaps [rsp+0x20], xmm11
00007431745cf797  vmovaps xmm10, [rsp+0x20]
00007431745cf79d  por xmm11, xmm10
00007431745cf7a2  vmovaps [rsp+0x20], xmm4
00007431745cf7a8  vmovaps xmm10, [rsp+0x20]
00007431745cf7ae  por xmm4, xmm10
00007431745cf7b3  vmovaps [rsp+0x20], xmm8
00007431745cf7b9  vmovaps xmm10, [rsp+0x20]
00007431745cf7bf  por xmm8, xmm10
00007431745cf7c4  vmovaps xmm10, [rsp+0xF0]
00007431745cf7cd  vmovaps [rsp+0x20], xmm1
00007431745cf7d3  vmovaps xmm1, [rsp+0xF0]
00007431745cf7dc  por xmm10, xmm1
00007431745cf7e1  lea rax, [r14+0xA0]
00007431745cf7e8  movups xmm1, [r13+rax*1]
00007431745cf7ee  lea rax, [r14+0xB0]
00007431745cf7f5  vmovaps [rsp+0x30], xmm1
00007431745cf7fb  movups xmm1, [r13+rax*1]
00007431745cf801  vmovaps [rsp+0xF0], xmm1
00007431745cf80a  vmovaps [rsp+0x120], xmm15
00007431745cf813  movaps xmm1, xmm13
00007431745cf817  addpd xmm1, xmm2
00007431745cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007431745cf820  ptest xmm15, xmm15
00007431745cf826  jnz 0x00007431745D11ED
00007431745cf82c  lea rax, [r14+0xF0]
00007431745cf833  movups xmm15, [r13+rax*1]
00007431745cf839  vmovaps xmm2, [rsp+0xC0]
00007431745cf842  vmovaps [rsp+0xC0], xmm1
00007431745cf84b  vmovaps xmm1, [rsp+0xE0]
00007431745cf854  vmovaps [rsp+0xE0], xmm15
00007431745cf85d  movaps xmm13, xmm2
00007431745cf861  addpd xmm13, xmm1
00007431745cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007431745cf86c  ptest xmm15, xmm15
00007431745cf872  jnz 0x00007431745D1338
00007431745cf878  vmovaps xmm15, [rsp+0x120]
00007431745cf881  vmovaps xmm2, [rsp+0xD0]
00007431745cf88a  vmovaps [rsp+0xD0], xmm14
00007431745cf893  movaps xmm1, xmm15
00007431745cf897  addpd xmm1, xmm2
00007431745cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007431745cf8a0  ptest xmm14, xmm14
00007431745cf8a6  jnz 0x00007431745D147A
00007431745cf8ac  vmovaps xmm15, [rsp+0x100]
00007431745cf8b5  vpermilpd xmm15, xmm15, 0x00
00007431745cf8bb  vmovaps xmm2, [rsp+0xF0]
00007431745cf8c4  vmovaps [rsp+0xF0], xmm1
00007431745cf8cd  movaps xmm14, xmm2
00007431745cf8d1  mulpd xmm14, xmm15
00007431745cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007431745cf8dc  ptest xmm1, xmm1
00007431745cf8e1  jnz 0x00007431745D15BB
00007431745cf8e7  vmovaps xmm1, [rsp+0xA0]
00007431745cf8f0  vpermilpd xmm1, xmm1, 0x00
00007431745cf8f6  vmovaps xmm2, [rsp+0xE0]
00007431745cf8ff  vmovaps [rsp+0xE0], xmm14
00007431745cf908  movaps xmm15, xmm2
00007431745cf90c  mulpd xmm15, xmm1
00007431745cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007431745cf917  ptest xmm14, xmm14
00007431745cf91d  jnz 0x00007431745D16FE
00007431745cf923  lea rax, [r14+0xE0]
00007431745cf92a  movups xmm1, [r13+rax*1]
00007431745cf930  vmovaps xmm14, [rsp+0x100]
00007431745cf939  vpermilpd xmm14, xmm14, 0x00
00007431745cf93f  vmovaps [rsp+0x100], xmm1
00007431745cf948  vmovaps xmm1, [rsp+0x30]
00007431745cf94e  vmovaps [rsp+0x30], xmm15
00007431745cf954  movaps xmm2, xmm1
00007431745cf957  mulpd xmm2, xmm14
00007431745cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007431745cf961  ptest xmm15, xmm15
00007431745cf967  jnz 0x00007431745D184A
00007431745cf96d  vmovaps [rsp+0x120], xmm10
00007431745cf976  vmovaps xmm1, [rsp+0x120]
00007431745cf97f  por xmm10, xmm1
00007431745cf984  movaps [r15+0x300], xmm10
00007431745cf98c  vmovaps [rsp+0x120], xmm8
00007431745cf995  vmovaps xmm1, [rsp+0x120]
00007431745cf99e  por xmm8, xmm1
00007431745cf9a3  movaps [r15+0x190], xmm8
00007431745cf9ab  vmovaps xmm1, [rsp+0xA0]
00007431745cf9b4  vpermilpd xmm1, xmm1, 0x00
00007431745cf9ba  vmovaps xmm14, [rsp+0x100]
00007431745cf9c3  vmovaps [rsp+0x100], xmm13
00007431745cf9cc  movaps xmm15, xmm14
00007431745cf9d0  mulpd xmm15, xmm1
00007431745cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007431745cf9db  ptest xmm13, xmm13
00007431745cf9e1  jnz 0x00007431745D198B
00007431745cf9e7  lea rax, [r14+0x90]
00007431745cf9ee  movups xmm1, [r13+rax*1]
00007431745cf9f4  vmovaps [rsp+0x120], xmm4
00007431745cf9fd  vmovaps xmm14, [rsp+0x120]
00007431745cfa06  por xmm4, xmm14
00007431745cfa0b  movaps [r15+0x1C0], xmm4
00007431745cfa13  vmovaps [rsp+0x120], xmm11
00007431745cfa1c  vmovaps xmm14, [rsp+0x120]
00007431745cfa25  por xmm11, xmm14
00007431745cfa2a  movaps [r15+0x200], xmm11
00007431745cfa32  vmovaps [rsp+0x120], xmm5
00007431745cfa3b  vmovaps xmm14, [rsp+0x120]
00007431745cfa44  por xmm5, xmm14
00007431745cfa49  movaps [r15+0x2D0], xmm5
00007431745cfa51  vmovaps [rsp+0x120], xmm12
00007431745cfa5a  vmovaps xmm14, [rsp+0x120]
00007431745cfa63  por xmm12, xmm14
00007431745cfa68  movaps [r15+0x2E0], xmm12
00007431745cfa70  vmovaps xmm13, [rsp+0x110]
00007431745cfa79  vmovaps [rsp+0x110], xmm1
00007431745cfa82  vmovaps xmm1, [rsp+0xE0]
00007431745cfa8b  vmovaps [rsp+0xE0], xmm15
00007431745cfa94  movaps xmm14, xmm13
00007431745cfa98  addpd xmm14, xmm1
00007431745cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007431745cfaa3  ptest xmm15, xmm15
00007431745cfaa9  jnz 0x00007431745D1AD8
00007431745cfaaf  vmovaps xmm1, [rsp+0xA0]
00007431745cfab8  vpermilpd xmm1, xmm1, 0x00
00007431745cfabe  vmovaps xmm13, [rsp+0x110]
00007431745cfac7  vmovaps [rsp+0x110], xmm14
00007431745cfad0  movaps xmm15, xmm13
00007431745cfad4  mulpd xmm15, xmm1
00007431745cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007431745cfadf  ptest xmm14, xmm14
00007431745cfae5  jnz 0x00007431745D1C1B
00007431745cfaeb  lea rax, [r14+0x80]
00007431745cfaf2  movups xmm1, [r13+rax*1]
00007431745cfaf8  vmovaps xmm13, [rsp+0xC0]
00007431745cfb01  vmovaps [rsp+0xC0], xmm1
00007431745cfb0a  movaps xmm14, xmm13
00007431745cfb0e  addpd xmm14, xmm2
00007431745cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007431745cfb19  ptest xmm1, xmm1
00007431745cfb1e  jnz 0x00007431745D1D68
00007431745cfb24  vmovaps xmm13, [rsp+0x100]
00007431745cfb2d  vmovaps xmm2, [rsp+0x30]
00007431745cfb33  vmovaps [rsp+0x30], xmm15
00007431745cfb39  movaps xmm1, xmm13
00007431745cfb3d  addpd xmm1, xmm2
00007431745cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007431745cfb46  ptest xmm15, xmm15
00007431745cfb4c  jnz 0x00007431745D1EAB
00007431745cfb52  vmovaps xmm15, [rsp+0x20]
00007431745cfb58  vmovaps xmm13, [rsp+0x20]
00007431745cfb5e  por xmm15, xmm13
00007431745cfb63  movaps [r15+0x2F0], xmm15
00007431745cfb6b  vmovaps xmm13, [rsp+0xA0]
00007431745cfb74  vpermilpd xmm13, xmm13, 0x00
00007431745cfb7a  vmovaps [rsp+0x20], xmm1
00007431745cfb80  vmovaps xmm1, [rsp+0xC0]
00007431745cfb89  vmovaps [rsp+0xA0], xmm15
00007431745cfb92  movaps xmm2, xmm1
00007431745cfb95  mulpd xmm2, xmm13
00007431745cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007431745cfb9f  ptest xmm15, xmm15
00007431745cfba5  jnz 0x00007431745D1FEC
00007431745cfbab  lea rax, [r14+0xD0]
00007431745cfbb2  movups xmm1, [r13+rax*1]
00007431745cfbb8  vmovaps xmm13, [rsp+0xF0]
00007431745cfbc1  vmovaps [rsp+0xC0], xmm1
00007431745cfbca  vmovaps xmm1, [rsp+0xE0]
00007431745cfbd3  vmovaps [rsp+0xE0], xmm14
00007431745cfbdc  movaps xmm15, xmm13
00007431745cfbe0  addpd xmm15, xmm1
00007431745cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007431745cfbeb  ptest xmm14, xmm14
00007431745cfbf1  jnz 0x00007431745D2137
00007431745cfbf7  vmovaps xmm1, [rsp+0xB0]
00007431745cfc00  vpermilpd xmm1, xmm1, 0x00
00007431745cfc06  movaps xmm14, xmm11
00007431745cfc0a  mulpd xmm14, xmm1
00007431745cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007431745cfc15  ptest xmm13, xmm13
00007431745cfc1b  jnz 0x00007431745D227A
00007431745cfc21  movaps [r15+0x260], xmm14
00007431745cfc29  vxorps xmm1, xmm1, xmm1
00007431745cfc2d  vpbroadcastq xmm1, xmm1
00007431745cfc32  movaps [r15+0x1B0], xmm1
00007431745cfc3a  vmovaps xmm1, [rsp+0xB0]
00007431745cfc43  vpermilpd xmm1, xmm1, 0x00
00007431745cfc49  vmovaps xmm11, [rsp+0xC0]
00007431745cfc52  vmovaps [rsp+0xC0], xmm15
00007431745cfc5b  movaps xmm13, xmm11
00007431745cfc5f  mulpd xmm13, xmm1
00007431745cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007431745cfc6a  ptest xmm15, xmm15
00007431745cfc70  jnz 0x00007431745D23BD
00007431745cfc76  lea rax, [r14+0xC0]
00007431745cfc7d  movups xmm1, [r13+rax*1]
00007431745cfc83  vmovaps xmm11, [rsp+0x110]
00007431745cfc8c  vmovaps [rsp+0xF0], xmm1
00007431745cfc95  vmovaps xmm1, [rsp+0x30]
00007431745cfc9b  vmovaps [rsp+0x30], xmm14
00007431745cfca1  movaps xmm15, xmm11
00007431745cfca5  addpd xmm15, xmm1
00007431745cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007431745cfcb0  ptest xmm14, xmm14
00007431745cfcb6  jnz 0x00007431745D250A
00007431745cfcbc  vmovaps [rsp+0x100], xmm9
00007431745cfcc5  vmovaps xmm1, [rsp+0x100]
00007431745cfcce  por xmm9, xmm1
00007431745cfcd3  movaps [r15+0x270], xmm9
00007431745cfcdb  vmovaps [rsp+0x100], xmm6
00007431745cfce4  vmovaps xmm1, [rsp+0x100]
00007431745cfced  por xmm6, xmm1
00007431745cfcf1  movaps [r15+0x1A0], xmm6
00007431745cfcf9  vmovaps xmm14, [rsp+0xB0]
00007431745cfd02  vpermilpd xmm14, xmm14, 0x00
00007431745cfd08  vmovaps xmm6, [rsp+0xF0]
00007431745cfd11  vmovaps [rsp+0xF0], xmm1
00007431745cfd1a  movaps xmm11, xmm6
00007431745cfd1e  mulpd xmm11, xmm14
00007431745cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007431745cfd29  ptest xmm1, xmm1
00007431745cfd2e  jnz 0x00007431745D264D
00007431745cfd34  lea rax, [r14+0x20]
00007431745cfd38  movups xmm1, [r13+rax*1]
00007431745cfd3e  movaps [r15+0x110], xmm1
00007431745cfd46  vmovaps xmm6, [rsp+0xE0]
00007431745cfd4f  vmovaps [rsp+0xE0], xmm1
00007431745cfd58  movaps xmm14, xmm6
00007431745cfd5c  addpd xmm14, xmm2
00007431745cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007431745cfd67  ptest xmm1, xmm1
00007431745cfd6c  jnz 0x00007431745D279A
00007431745cfd72  vmovaps xmm1, [rsp+0xB0]
00007431745cfd7b  vpermilpd xmm1, xmm1, 0x00
00007431745cfd81  movaps xmm6, xmm5
00007431745cfd84  mulpd xmm6, xmm1
00007431745cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007431745cfd8d  ptest xmm2, xmm2
00007431745cfd92  jnz 0x00007431745D28DC
00007431745cfd98  vmovaps xmm5, [rsp+0x20]
00007431745cfd9e  movaps xmm1, xmm5
00007431745cfda1  addpd xmm1, xmm13
00007431745cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007431745cfdab  ptest xmm2, xmm2
00007431745cfdb0  jnz 0x00007431745D2A1C
00007431745cfdb6  vmovaps xmm13, [rsp+0x80]
00007431745cfdbf  vpermilpd xmm13, xmm13, 0x00
00007431745cfdc5  vmovaps xmm2, [rsp+0xE0]
00007431745cfdce  vmovaps [rsp+0x20], xmm1
00007431745cfdd4  movaps xmm5, xmm2
00007431745cfdd7  mulpd xmm5, xmm13
00007431745cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007431745cfde1  ptest xmm1, xmm1
00007431745cfde6  jnz 0x00007431745D2B5D
00007431745cfdec  vmovaps xmm1, [rsp+0x80]
00007431745cfdf5  vpermilpd xmm1, xmm1, 0x00
00007431745cfdfb  movaps xmm13, xmm10
00007431745cfdff  mulpd xmm13, xmm1
00007431745cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007431745cfe0a  ptest xmm2, xmm2
00007431745cfe0f  jnz 0x00007431745D2C9E
00007431745cfe15  vmovaps xmm10, [rsp+0x30]
00007431745cfe1b  movaps xmm1, xmm15
00007431745cfe1f  addpd xmm1, xmm10
00007431745cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007431745cfe29  ptest xmm2, xmm2
00007431745cfe2e  jnz 0x00007431745D2DE1
00007431745cfe34  vmovaps xmm10, [rsp+0xC0]
00007431745cfe3d  movaps xmm15, xmm10
00007431745cfe41  addpd xmm15, xmm11
00007431745cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007431745cfe4c  ptest xmm2, xmm2
00007431745cfe51  jnz 0x00007431745D2F23
00007431745cfe57  vmovaps xmm11, [rsp+0x80]
00007431745cfe60  vpermilpd xmm11, xmm11, 0x00
00007431745cfe66  movaps xmm10, xmm12
00007431745cfe6a  mulpd xmm10, xmm11
00007431745cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007431745cfe75  ptest xmm2, xmm2
00007431745cfe7a  jnz 0x00007431745D3067
00007431745cfe80  vmovaps xmm12, [rsp+0x80]
00007431745cfe89  vpermilpd xmm12, xmm12, 0x00
00007431745cfe8f  vmovaps xmm2, [rsp+0xA0]
00007431745cfe98  vmovaps [rsp+0x30], xmm1
00007431745cfe9e  movaps xmm11, xmm2
00007431745cfea2  mulpd xmm11, xmm12
00007431745cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007431745cfead  ptest xmm1, xmm1
00007431745cfeb2  jnz 0x00007431745D31AB
00007431745cfeb8  movaps xmm1, xmm14
00007431745cfebc  addpd xmm1, xmm6
00007431745cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007431745cfec5  ptest xmm12, xmm12
00007431745cfecb  jnz 0x00007431745D32EE
00007431745cfed1  vmovaps xmm12, [rsp+0x20]
00007431745cfed7  movaps xmm14, xmm12
00007431745cfedb  addpd xmm14, xmm5
00007431745cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007431745cfee6  ptest xmm6, xmm6
00007431745cfeeb  jnz 0x00007431745D342F
00007431745cfef1  vmovaps xmm12, [rsp+0x90]
00007431745cfefa  vpermilpd xmm12, xmm12, 0x00
00007431745cff00  movaps xmm6, xmm9
00007431745cff04  mulpd xmm6, xmm12
00007431745cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007431745cff0e  ptest xmm5, xmm5
00007431745cff13  jnz 0x00007431745D3572
00007431745cff19  movaps xmm12, xmm15
00007431745cff1d  addpd xmm12, xmm13
00007431745cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007431745cff28  ptest xmm9, xmm9
00007431745cff2e  jnz 0x00007431745D36B4
00007431745cff34  vmovaps xmm13, [rsp+0x30]
00007431745cff3a  movaps xmm15, xmm13
00007431745cff3e  addpd xmm15, xmm10
00007431745cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007431745cff49  ptest xmm9, xmm9
00007431745cff4f  jnz 0x00007431745D37F8
00007431745cff55  vmovaps xmm13, [rsp+0xD0]
00007431745cff5e  vmovaps xmm10, [rsp+0xD0]
00007431745cff67  por xmm13, xmm10
00007431745cff6c  movaps [r15+0x250], xmm13
00007431745cff74  vmovaps [rsp+0x20], xmm7
00007431745cff7a  vmovaps xmm13, [rsp+0x20]
00007431745cff80  por xmm7, xmm13
00007431745cff85  movaps [r15+0x2A0], xmm7
00007431745cff8d  vmovaps [rsp+0x20], xmm3
00007431745cff93  vmovaps xmm13, [rsp+0x20]
00007431745cff99  por xmm3, xmm13
00007431745cff9e  movaps [r15+0x1D0], xmm3
00007431745cffa6  lea rax, [r14+0x40]
00007431745cffaa  movups xmm13, [r13+rax*1]
00007431745cffb0  movaps [r15+0x2C0], xmm13
00007431745cffb8  vmovaps xmm10, [rsp+0x90]
00007431745cffc1  vpermilpd xmm10, xmm10, 0x00
00007431745cffc7  movaps xmm9, xmm8
00007431745cffcb  mulpd xmm9, xmm10
00007431745cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007431745cffd6  ptest xmm5, xmm5
00007431745cffdb  jnz 0x00007431745D3946
00007431745cffe1  movaps xmm10, xmm1
00007431745cffe5  addpd xmm10, xmm11
00007431745cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007431745cfff0  ptest xmm8, xmm8
00007431745cfff6  jnz 0x00007431745D3A8A
00007431745cfffc  movaps xmm1, xmm14
00007431745d0000  addpd xmm1, xmm6
00007431745d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007431745d0009  ptest xmm11, xmm11
00007431745d000f  jnz 0x00007431745D3BCD
00007431745d0015  vmovaps xmm14, [rsp+0x90]
00007431745d001e  vpermilpd xmm14, xmm14, 0x00
00007431745d0024  movaps xmm11, xmm13
00007431745d0028  mulpd xmm11, xmm14
00007431745d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007431745d0033  ptest xmm8, xmm8
00007431745d0039  jnz 0x00007431745D3D0E
00007431745d003f  vmovaps xmm14, [rsp+0x90]
00007431745d0048  vpermilpd xmm14, xmm14, 0x00
00007431745d004e  vmovaps xmm8, [rsp+0x10]
00007431745d0054  movaps xmm13, xmm8
00007431745d0058  mulpd xmm13, xmm14
00007431745d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007431745d0063  ptest xmm6, xmm6
00007431745d0068  jnz 0x00007431745D3E52
00007431745d006e  vmovaps xmm14, [rsp+0x60]
00007431745d0074  vpermilpd xmm14, xmm14, 0x00
00007431745d007a  movaps xmm8, xmm7
00007431745d007e  mulpd xmm8, xmm14
00007431745d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007431745d0089  ptest xmm6, xmm6
00007431745d008e  jnz 0x00007431745D3F96
00007431745d0094  movaps xmm14, xmm12
00007431745d0098  addpd xmm14, xmm9
00007431745d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007431745d00a3  ptest xmm7, xmm7
00007431745d00a8  jnz 0x00007431745D40D9
00007431745d00ae  vmovaps xmm12, [rsp+0x60]
00007431745d00b4  vpermilpd xmm12, xmm12, 0x00
00007431745d00ba  vmovaps xmm7, [rsp+0xF0]
00007431745d00c3  movaps xmm9, xmm7
00007431745d00c7  mulpd xmm9, xmm12
00007431745d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007431745d00d2  ptest xmm6, xmm6
00007431745d00d7  jnz 0x00007431745D421D
00007431745d00dd  movaps xmm12, xmm15
00007431745d00e1  addpd xmm12, xmm11
00007431745d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007431745d00ec  ptest xmm7, xmm7
00007431745d00f1  jnz 0x00007431745D4360
00007431745d00f7  vmovaps xmm15, [rsp+0x60]
00007431745d00fd  vpermilpd xmm15, xmm15, 0x00
00007431745d0103  vmovaps xmm7, [rsp+0x40]
00007431745d0109  movaps xmm11, xmm7
00007431745d010d  mulpd xmm11, xmm15
00007431745d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007431745d0118  ptest xmm6, xmm6
00007431745d011d  jnz 0x00007431745D44A4
00007431745d0123  movaps xmm15, xmm10
00007431745d0127  addpd xmm15, xmm13
00007431745d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007431745d0132  ptest xmm7, xmm7
00007431745d0137  jnz 0x00007431745D45E7
00007431745d013d  vmovaps xmm13, [rsp+0x60]
00007431745d0143  vpermilpd xmm13, xmm13, 0x00
00007431745d0149  vmovaps xmm7, [rsp+0x50]
00007431745d014f  movaps xmm10, xmm7
00007431745d0153  mulpd xmm10, xmm13
00007431745d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007431745d015e  ptest xmm6, xmm6
00007431745d0163  jnz 0x00007431745D472B
00007431745d0169  movaps xmm13, xmm1
00007431745d016d  addpd xmm13, xmm8
00007431745d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007431745d0178  ptest xmm7, xmm7
00007431745d017d  jnz 0x00007431745D486E
00007431745d0183  lea rax, [r14+0x70]
00007431745d0187  movups xmm1, [r13+rax*1]
00007431745d018d  movaps [r15+0x240], xmm1
00007431745d0195  movaps xmm8, xmm14
00007431745d0199  addpd xmm8, xmm9
00007431745d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007431745d01a4  ptest xmm7, xmm7
00007431745d01a9  jnz 0x00007431745D49BB
00007431745d01af  movaps [r15+0x170], xmm8
00007431745d01b7  vmovaps xmm14, [rsp+0x70]
00007431745d01bd  vpermilpd xmm14, xmm14, 0x00
00007431745d01c3  movaps xmm9, xmm1
00007431745d01c7  mulpd xmm9, xmm14
00007431745d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007431745d01d2  ptest xmm7, xmm7
00007431745d01d7  jnz 0x00007431745D4AFF
00007431745d01dd  vmovaps xmm1, [rsp+0x70]
00007431745d01e3  vpermilpd xmm1, xmm1, 0x00
00007431745d01e9  movaps xmm14, xmm4
00007431745d01ed  mulpd xmm14, xmm1
00007431745d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007431745d01f8  ptest xmm7, xmm7
00007431745d01fd  jnz 0x00007431745D4C42
00007431745d0203  movaps [r15+0x180], xmm14
00007431745d020b  movaps xmm1, xmm12
00007431745d020f  addpd xmm1, xmm11
00007431745d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007431745d0219  ptest xmm7, xmm7
00007431745d021e  jnz 0x00007431745D4D84
00007431745d0224  movaps [r15+0x210], xmm1
00007431745d022c  movups xmm12, [r13+r14*1]
00007431745d0232  lea rax, [r14+0x10]
00007431745d0236  movups xmm11, [r13+rax*1]
00007431745d023c  movaps [r15+0x230], xmm11
00007431745d0244  movaps xmm7, xmm15
00007431745d0248  addpd xmm7, xmm10
00007431745d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007431745d0252  ptest xmm6, xmm6
00007431745d0257  jnz 0x00007431745D4EDA
00007431745d025d  movaps [r15+0x130], xmm7
00007431745d0265  vmovaps xmm15, [rsp+0x70]
00007431745d026b  vpermilpd xmm15, xmm15, 0x00
00007431745d0271  movaps xmm10, xmm11
00007431745d0275  mulpd xmm10, xmm15
00007431745d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007431745d0280  ptest xmm6, xmm6
00007431745d0285  jnz 0x00007431745D501C
00007431745d028b  movaps [r15+0x220], xmm10
00007431745d0293  vmovaps xmm15, [rsp+0x70]
00007431745d0299  vpermilpd xmm15, xmm15, 0x00
00007431745d029f  movaps xmm11, xmm12
00007431745d02a3  mulpd xmm11, xmm15
00007431745d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007431745d02ae  ptest xmm6, xmm6
00007431745d02b3  jnz 0x00007431745D5160
00007431745d02b9  movaps xmm15, xmm13
00007431745d02bd  addpd xmm15, xmm9
00007431745d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007431745d02c8  ptest xmm12, xmm12
00007431745d02ce  jnz 0x00007431745D52A4
00007431745d02d4  movaps [r15+0x140], xmm15
00007431745d02dc  movaps xmm13, xmm8
00007431745d02e0  addpd xmm13, xmm14
00007431745d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007431745d02eb  ptest xmm12, xmm12
00007431745d02f1  jnz 0x00007431745D53E8
00007431745d02f7  movaps [r15+0x150], xmm13
00007431745d02ff  movaps xmm14, xmm1
00007431745d0303  addpd xmm14, xmm10
00007431745d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007431745d030e  ptest xmm12, xmm12
00007431745d0314  jnz 0x00007431745D552C
00007431745d031a  movaps [r15+0x160], xmm14
00007431745d0322  movaps xmm1, xmm7
00007431745d0325  addpd xmm1, xmm11
00007431745d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007431745d032f  ptest xmm12, xmm12
00007431745d0335  jnz 0x00007431745D566F
00007431745d033b  movaps [r15+0x120], xmm1
00007431745d0343  mov eax, 0x430920
00007431745d0348  movups [r13+rax*1], xmm15
00007431745d034e  mov eax, 0x430930
00007431745d0353  movups [r13+rax*1], xmm13
00007431745d0359  mov eax, 0x430940
00007431745d035e  movups [r13+rax*1], xmm14
00007431745d0364  mov eax, 0x430950
00007431745d0369  movups [r13+rax*1], xmm1
00007431745d036f  mov eax, [r15+0x108]
00007431745d0376  sahf
00007431745d0377  jnz 0x00007431745D03A9
00007431745d0379  cmp dword ptr [r15+0x318], 0x00
00007431745d0381  jz 0x00007431745DB900
00007431745d0387  nop [rax+rax*1], ax
00007431745d0390  nop [rax+rax*1], eax
00007431745d0398  mov eax, 0x410444
00007431745d039d  mov [r15+0x100], rax
00007431745d03a4  jmp 0x00007431743FE110
00007431745d03a9  cmp dword ptr [r15+0x318], 0x00
00007431745d03b1  jz 0x00007431745D57E0
00007431745d03b7  nop [rax+rax*1], ax
00007431745d03c0  nop [rax+rax*1], eax
00007431745d03c8  mov eax, 0x410278
00007431745d03cd  mov [r15+0x100], rax
00007431745d03d4  jmp 0x00007431743FE110
00007431745d03d9  int3
00007431745d03da  call 0x00007431744B52F0
00007431745d03df  jmp 0x00007431745CF016
00007431745d03e4  call 0x00007431744C4620
00007431745d03e9  jmp 0x00007431745CF023
00007431745d03ee  call 0x00007431744C33A0
00007431745d03f3  jmp 0x00007431745CF035
00007431745d03f8  call 0x00007431744C2120
00007431745d03fd  jmp 0x00007431745CF03F
00007431745d0402  call 0x00007431744C0860
00007431745d0407  jmp 0x00007431745CF067
00007431745d040c  call 0x00007431744BF5F0
00007431745d0411  jmp 0x00007431745CF073
00007431745d0416  call 0x00007431744C0860
00007431745d041b  jmp 0x00007431745CF0A5
00007431745d0420  call 0x00007431744BF5F0
00007431745d0425  jmp 0x00007431745CF0B1
00007431745d042a  call 0x00007431744C4740
00007431745d042f  jmp 0x00007431745CF0BE
00007431745d0434  call 0x00007431744B5400
00007431745d0439  jmp 0x00007431745CF0CB
00007431745d043e  call 0x00007431744B52F0
00007431745d0443  jmp 0x00007431745CF0D8
00007431745d0448  call 0x00007431744C4620
00007431745d044d  jmp 0x00007431745CF0E5
00007431745d0452  call 0x00007431744C0860
00007431745d0457  jmp 0x00007431745CF10D
00007431745d045c  call 0x00007431744BF5F0
00007431745d0461  jmp 0x00007431745CF119
00007431745d0466  call 0x0000743174409D70
00007431745d046b  jmp 0x00007431745CF11F
00007431745d0470  call 0x00007431744BE9C0
00007431745d0475  jmp 0x00007431745CF129
00007431745d047a  call 0x00007431744C0860
00007431745d047f  jmp 0x00007431745CF151
00007431745d0484  call 0x00007431744BF5F0
00007431745d0489  jmp 0x00007431745CF15D
00007431745d048e  call 0x00007431744BD750
00007431745d0493  jmp 0x00007431745CF16A
00007431745d0498  call 0x00007431744BC4E0
00007431745d049d  jmp 0x00007431745CF177
00007431745d04a2  call 0x00007431744C4740
00007431745d04a7  jmp 0x00007431745CF184
00007431745d04ac  call 0x00007431744B5400
00007431745d04b1  jmp 0x00007431745CF191
00007431745d04b6  call 0x00007431744B52F0
00007431745d04bb  jmp 0x00007431745CF19E
00007431745d04c0  call 0x00007431744C4620
00007431745d04c5  jmp 0x00007431745CF1AB
00007431745d04ca  call 0x00007431744C0860
00007431745d04cf  jmp 0x00007431745CF1BE
00007431745d04d4  call 0x00007431744BB270
00007431745d04d9  jmp 0x00007431745CF1CB
00007431745d04de  call 0x00007431744BA000
00007431745d04e3  jmp 0x00007431745CF1D8
00007431745d04e8  call 0x00007431744B8D90
00007431745d04ed  jmp 0x00007431745CF1E5
00007431745d04f2  call 0x00007431744B8A20
00007431745d04f7  jmp 0x00007431745CF1F2
00007431745d04fc  call 0x00007431744B5400
00007431745d0501  jmp 0x00007431745CF1FC
00007431745d0506  call 0x00007431744C2240
00007431745d050b  jmp 0x00007431745CF206
00007431745d0510  call 0x00007431744B52F0
00007431745d0515  jmp 0x00007431745CF210
00007431745d051a  call 0x00007431744C2120
00007431745d051f  jmp 0x00007431745CF21A
00007431745d0524  call 0x00007431744B77B0
00007431745d0529  jmp 0x00007431745CF224
00007431745d052e  call 0x00007431744B6550
00007431745d0533  jmp 0x00007431745CF22E
00007431745d0538  call 0x00007431744BFD50
00007431745d053d  jmp 0x00007431745CF240
00007431745d0542  call 0x00007431744B8EA0
00007431745d0547  jmp 0x00007431745CF24A
00007431745d054c  call 0x00007431744BFC30
00007431745d0551  jmp 0x00007431745CF257
00007431745d0556  call 0x00007431744B8D90
00007431745d055b  jmp 0x00007431745CF264
00007431745d0560  call 0x00007431744C2240
00007431745d0565  jmp 0x00007431745CF271
00007431745d056a  call 0x00007431744B5400
00007431745d056f  jmp 0x00007431745CF27E
00007431745d0574  call 0x00007431744B52F0
00007431745d0579  jmp 0x00007431745CF28B
00007431745d057e  call 0x00007431744C2120
00007431745d0583  jmp 0x00007431745CF298
00007431745d0588  call 0x00007431744B52F0
00007431745d058d  jmp 0x00007431745CF2AB
00007431745d0592  call 0x00007431744B52F0
00007431745d0597  jmp 0x00007431745CF2BE
00007431745d059c  call 0x00007431744B52F0
00007431745d05a1  jmp 0x00007431745CF2D1
00007431745d05a6  call 0x00007431744B52F0
00007431745d05ab  jmp 0x00007431745CF2E4
00007431745d05b0  call 0x00007431744C2240
00007431745d05b5  jmp 0x00007431745CF2F9
00007431745d05ba  call 0x00007431744C2240
00007431745d05bf  jmp 0x00007431745CF30C
00007431745d05c4  call 0x00007431744C2120
00007431745d05c9  jmp 0x00007431745CF319
00007431745d05ce  call 0x00007431744B52F0
00007431745d05d3  jmp 0x00007431745CF32C
00007431745d05d8  call 0x00007431744B52F0
00007431745d05dd  jmp 0x00007431745CF34F
00007431745d05e2  call 0x00007431744B52F0
00007431745d05e7  jmp 0x00007431745CF362
00007431745d05ec  call 0x00007431743FF540
00007431745d05f1  jmp 0x00007431745CF380
00007431745d05f6  call 0x0000743174408C20
00007431745d05fb  jmp 0x00007431745CF38A
00007431745d0600  call 0x00007431744D6600
00007431745d0605  jmp 0x00007431745CF396
00007431745d060a  call 0x00007431743FF540
00007431745d060f  jmp 0x00007431745CF3A6
00007431745d0614  call 0x00007431744C0370
00007431745d0619  jmp 0x00007431745CF3D4
00007431745d061e  call 0x00007431744BF100
00007431745d0623  jmp 0x00007431745CF3DD
00007431745d0628  call 0x00007431744C0370
00007431745d062d  jmp 0x00007431745CF43B
00007431745d0632  call 0x00007431744BF100
00007431745d0637  jmp 0x00007431745CF444
00007431745d063c  call 0x00007431744C0370
00007431745d0641  jmp 0x00007431745CF48B
00007431745d0646  call 0x00007431744BF100
00007431745d064b  jmp 0x00007431745CF494
00007431745d0650  call 0x000074317440B720
00007431745d0655  jmp 0x00007431745CF4D7
00007431745d065a  call 0x00007431744B47C0
00007431745d065f  jmp 0x00007431745CF4EA
00007431745d0664  call 0x0000743174408B00
00007431745d0669  jmp 0x00007431745CF501
00007431745d066e  call 0x00007431743FF430
00007431745d0673  jmp 0x00007431745CF514
00007431745d0678  call 0x00007431743FF430
00007431745d067d  jmp 0x00007431745CF527
00007431745d0682  sub rsp, 0x08
00007431745d0686  push rax
00007431745d0687  push rcx
00007431745d0688  push rdx
00007431745d0689  push rdi
00007431745d068a  push rsi
00007431745d068b  push r8
00007431745d068d  push r9
00007431745d068f  push r10
00007431745d0691  push r11
00007431745d0693  sub rsp, 0xF0
00007431745d069a  vmovaps [rsp], xmm0
00007431745d069f  vmovaps [rsp+0x10], xmm2
00007431745d06a5  vmovaps [rsp+0x20], xmm3
00007431745d06ab  vmovaps [rsp+0x30], xmm4
00007431745d06b1  vmovaps [rsp+0x40], xmm5
00007431745d06b7  vmovaps [rsp+0x50], xmm6
00007431745d06bd  vmovaps [rsp+0x60], xmm7
00007431745d06c3  vmovaps [rsp+0x70], xmm8
00007431745d06c9  vmovaps [rsp+0x80], xmm9
00007431745d06d2  vmovaps [rsp+0x90], xmm10
00007431745d06db  vmovaps [rsp+0xA0], xmm11
00007431745d06e4  vmovaps [rsp+0xB0], xmm12
00007431745d06ed  vmovaps [rsp+0xC0], xmm13
00007431745d06f6  vmovaps [rsp+0xD0], xmm14
00007431745d06ff  vmovaps [rsp+0xE0], xmm15
00007431745d0708  sub rsp, 0x30
00007431745d070c  movaps [rsp], xmm1
00007431745d0710  movaps [rsp+0x10], xmm15
00007431745d0716  movaps [rsp+0x20], xmm14
00007431745d071c  lea rdi, [rsp]
00007431745d0720  mov esi, 0x00
00007431745d0725  mov rax, 0x56C40959E530
00007431745d072f  call rax
00007431745d0731  movaps xmm1, [rsp]
00007431745d0735  add rsp, 0x30
00007431745d0739  vmovaps xmm0, [rsp]
00007431745d073e  vmovaps xmm2, [rsp+0x10]
00007431745d0744  vmovaps xmm3, [rsp+0x20]
00007431745d074a  vmovaps xmm4, [rsp+0x30]
00007431745d0750  vmovaps xmm5, [rsp+0x40]
00007431745d0756  vmovaps xmm6, [rsp+0x50]
00007431745d075c  vmovaps xmm7, [rsp+0x60]
00007431745d0762  vmovaps xmm8, [rsp+0x70]
00007431745d0768  vmovaps xmm9, [rsp+0x80]
00007431745d0771  vmovaps xmm10, [rsp+0x90]
00007431745d077a  vmovaps xmm11, [rsp+0xA0]
00007431745d0783  vmovaps xmm12, [rsp+0xB0]
00007431745d078c  vmovaps xmm13, [rsp+0xC0]
00007431745d0795  vmovaps xmm14, [rsp+0xD0]
00007431745d079e  vmovaps xmm15, [rsp+0xE0]
00007431745d07a7  add rsp, 0xF0
00007431745d07ae  pop r11
00007431745d07b0  pop r10
00007431745d07b2  pop r9
00007431745d07b4  pop r8
00007431745d07b6  pop rsi
00007431745d07b7  pop rdi
00007431745d07b8  pop rdx
00007431745d07b9  pop rcx
00007431745d07ba  pop rax
00007431745d07bb  add rsp, 0x08
00007431745d07bf  jmp 0x00007431745CF581
00007431745d07c4  sub rsp, 0x08
00007431745d07c8  push rax
00007431745d07c9  push rcx
00007431745d07ca  push rdx
00007431745d07cb  push rdi
00007431745d07cc  push rsi
00007431745d07cd  push r8
00007431745d07cf  push r9
00007431745d07d1  push r10
00007431745d07d3  push r11
00007431745d07d5  sub rsp, 0xF0
00007431745d07dc  vmovaps [rsp], xmm0
00007431745d07e1  vmovaps [rsp+0x10], xmm1
00007431745d07e7  vmovaps [rsp+0x20], xmm2
00007431745d07ed  vmovaps [rsp+0x30], xmm3
00007431745d07f3  vmovaps [rsp+0x40], xmm4
00007431745d07f9  vmovaps [rsp+0x50], xmm5
00007431745d07ff  vmovaps [rsp+0x60], xmm6
00007431745d0805  vmovaps [rsp+0x70], xmm7
00007431745d080b  vmovaps [rsp+0x80], xmm8
00007431745d0814  vmovaps [rsp+0x90], xmm9
00007431745d081d  vmovaps [rsp+0xA0], xmm10
00007431745d0826  vmovaps [rsp+0xB0], xmm11
00007431745d082f  vmovaps [rsp+0xC0], xmm12
00007431745d0838  vmovaps [rsp+0xD0], xmm14
00007431745d0841  vmovaps [rsp+0xE0], xmm15
00007431745d084a  sub rsp, 0x30
00007431745d084e  movaps [rsp], xmm13
00007431745d0853  movaps [rsp+0x10], xmm1
00007431745d0858  movaps [rsp+0x20], xmm14
00007431745d085e  lea rdi, [rsp]
00007431745d0862  mov esi, 0x00
00007431745d0867  mov rax, 0x56C40959E530
00007431745d0871  call rax
00007431745d0873  movaps xmm13, [rsp]
00007431745d0878  add rsp, 0x30
00007431745d087c  vmovaps xmm0, [rsp]
00007431745d0881  vmovaps xmm1, [rsp+0x10]
00007431745d0887  vmovaps xmm2, [rsp+0x20]
00007431745d088d  vmovaps xmm3, [rsp+0x30]
00007431745d0893  vmovaps xmm4, [rsp+0x40]
00007431745d0899  vmovaps xmm5, [rsp+0x50]
00007431745d089f  vmovaps xmm6, [rsp+0x60]
00007431745d08a5  vmovaps xmm7, [rsp+0x70]
00007431745d08ab  vmovaps xmm8, [rsp+0x80]
00007431745d08b4  vmovaps xmm9, [rsp+0x90]
00007431745d08bd  vmovaps xmm10, [rsp+0xA0]
00007431745d08c6  vmovaps xmm11, [rsp+0xB0]
00007431745d08cf  vmovaps xmm12, [rsp+0xC0]
00007431745d08d8  vmovaps xmm14, [rsp+0xD0]
00007431745d08e1  vmovaps xmm15, [rsp+0xE0]
00007431745d08ea  add rsp, 0xF0
00007431745d08f1  pop r11
00007431745d08f3  pop r10
00007431745d08f5  pop r9
00007431745d08f7  pop r8
00007431745d08f9  pop rsi
00007431745d08fa  pop rdi
00007431745d08fb  pop rdx
00007431745d08fc  pop rcx
00007431745d08fd  pop rax
00007431745d08fe  add rsp, 0x08
00007431745d0902  jmp 0x00007431745CF5CF
00007431745d0907  sub rsp, 0x08
00007431745d090b  push rax
00007431745d090c  push rcx
00007431745d090d  push rdx
00007431745d090e  push rdi
00007431745d090f  push rsi
00007431745d0910  push r8
00007431745d0912  push r9
00007431745d0914  push r10
00007431745d0916  push r11
00007431745d0918  sub rsp, 0xF0
00007431745d091f  vmovaps [rsp], xmm0
00007431745d0924  vmovaps [rsp+0x10], xmm1
00007431745d092a  vmovaps [rsp+0x20], xmm2
00007431745d0930  vmovaps [rsp+0x30], xmm3
00007431745d0936  vmovaps [rsp+0x40], xmm4
00007431745d093c  vmovaps [rsp+0x50], xmm5
00007431745d0942  vmovaps [rsp+0x60], xmm6
00007431745d0948  vmovaps [rsp+0x70], xmm7
00007431745d094e  vmovaps [rsp+0x80], xmm8
00007431745d0957  vmovaps [rsp+0x90], xmm9
00007431745d0960  vmovaps [rsp+0xA0], xmm10
00007431745d0969  vmovaps [rsp+0xB0], xmm11
00007431745d0972  vmovaps [rsp+0xC0], xmm12
00007431745d097b  vmovaps [rsp+0xD0], xmm13
00007431745d0984  vmovaps [rsp+0xE0], xmm14
00007431745d098d  sub rsp, 0x30
00007431745d0991  movaps [rsp], xmm15
00007431745d0996  movaps [rsp+0x10], xmm14
00007431745d099c  movaps [rsp+0x20], xmm1
00007431745d09a1  lea rdi, [rsp]
00007431745d09a5  mov esi, 0x00
00007431745d09aa  mov rax, 0x56C40959E530
00007431745d09b4  call rax
00007431745d09b6  movaps xmm15, [rsp]
00007431745d09bb  add rsp, 0x30
00007431745d09bf  vmovaps xmm0, [rsp]
00007431745d09c4  vmovaps xmm1, [rsp+0x10]
00007431745d09ca  vmovaps xmm2, [rsp+0x20]
00007431745d09d0  vmovaps xmm3, [rsp+0x30]
00007431745d09d6  vmovaps xmm4, [rsp+0x40]
00007431745d09dc  vmovaps xmm5, [rsp+0x50]
00007431745d09e2  vmovaps xmm6, [rsp+0x60]
00007431745d09e8  vmovaps xmm7, [rsp+0x70]
00007431745d09ee  vmovaps xmm8, [rsp+0x80]
00007431745d09f7  vmovaps xmm9, [rsp+0x90]
00007431745d0a00  vmovaps xmm10, [rsp+0xA0]
00007431745d0a09  vmovaps xmm11, [rsp+0xB0]
00007431745d0a12  vmovaps xmm12, [rsp+0xC0]
00007431745d0a1b  vmovaps xmm13, [rsp+0xD0]
00007431745d0a24  vmovaps xmm14, [rsp+0xE0]
00007431745d0a2d  add rsp, 0xF0
00007431745d0a34  pop r11
00007431745d0a36  pop r10
00007431745d0a38  pop r9
00007431745d0a3a  pop r8
00007431745d0a3c  pop rsi
00007431745d0a3d  pop rdi
00007431745d0a3e  pop rdx
00007431745d0a3f  pop rcx
00007431745d0a40  pop rax
00007431745d0a41  add rsp, 0x08
00007431745d0a45  jmp 0x00007431745CF617
00007431745d0a4a  sub rsp, 0x08
00007431745d0a4e  push rax
00007431745d0a4f  push rcx
00007431745d0a50  push rdx
00007431745d0a51  push rdi
00007431745d0a52  push rsi
00007431745d0a53  push r8
00007431745d0a55  push r9
00007431745d0a57  push r10
00007431745d0a59  push r11
00007431745d0a5b  sub rsp, 0xF0
00007431745d0a62  vmovaps [rsp], xmm0
00007431745d0a67  vmovaps [rsp+0x10], xmm2
00007431745d0a6d  vmovaps [rsp+0x20], xmm3
00007431745d0a73  vmovaps [rsp+0x30], xmm4
00007431745d0a79  vmovaps [rsp+0x40], xmm5
00007431745d0a7f  vmovaps [rsp+0x50], xmm6
00007431745d0a85  vmovaps [rsp+0x60], xmm7
00007431745d0a8b  vmovaps [rsp+0x70], xmm8
00007431745d0a91  vmovaps [rsp+0x80], xmm9
00007431745d0a9a  vmovaps [rsp+0x90], xmm10
00007431745d0aa3  vmovaps [rsp+0xA0], xmm11
00007431745d0aac  vmovaps [rsp+0xB0], xmm12
00007431745d0ab5  vmovaps [rsp+0xC0], xmm13
00007431745d0abe  vmovaps [rsp+0xD0], xmm14
00007431745d0ac7  vmovaps [rsp+0xE0], xmm15
00007431745d0ad0  sub rsp, 0x30
00007431745d0ad4  movaps [rsp], xmm1
00007431745d0ad8  movaps [rsp+0x10], xmm14
00007431745d0ade  movaps [rsp+0x20], xmm10
00007431745d0ae4  lea rdi, [rsp]
00007431745d0ae8  mov esi, 0x00
00007431745d0aed  mov rax, 0x56C40959E530
00007431745d0af7  call rax
00007431745d0af9  movaps xmm1, [rsp]
00007431745d0afd  add rsp, 0x30
00007431745d0b01  vmovaps xmm0, [rsp]
00007431745d0b06  vmovaps xmm2, [rsp+0x10]
00007431745d0b0c  vmovaps xmm3, [rsp+0x20]
00007431745d0b12  vmovaps xmm4, [rsp+0x30]
00007431745d0b18  vmovaps xmm5, [rsp+0x40]
00007431745d0b1e  vmovaps xmm6, [rsp+0x50]
00007431745d0b24  vmovaps xmm7, [rsp+0x60]
00007431745d0b2a  vmovaps xmm8, [rsp+0x70]
00007431745d0b30  vmovaps xmm9, [rsp+0x80]
00007431745d0b39  vmovaps xmm10, [rsp+0x90]
00007431745d0b42  vmovaps xmm11, [rsp+0xA0]
00007431745d0b4b  vmovaps xmm12, [rsp+0xB0]
00007431745d0b54  vmovaps xmm13, [rsp+0xC0]
00007431745d0b5d  vmovaps xmm14, [rsp+0xD0]
00007431745d0b66  vmovaps xmm15, [rsp+0xE0]
00007431745d0b6f  add rsp, 0xF0
00007431745d0b76  pop r11
00007431745d0b78  pop r10
00007431745d0b7a  pop r9
00007431745d0b7c  pop r8
00007431745d0b7e  pop rsi
00007431745d0b7f  pop rdi
00007431745d0b80  pop rdx
00007431745d0b81  pop rcx
00007431745d0b82  pop rax
00007431745d0b83  add rsp, 0x08
00007431745d0b87  jmp 0x00007431745CF631
00007431745d0b8c  sub rsp, 0x08
00007431745d0b90  push rax
00007431745d0b91  push rcx
00007431745d0b92  push rdx
00007431745d0b93  push rdi
00007431745d0b94  push rsi
00007431745d0b95  push r8
00007431745d0b97  push r9
00007431745d0b99  push r10
00007431745d0b9b  push r11
00007431745d0b9d  sub rsp, 0xF0
00007431745d0ba4  vmovaps [rsp], xmm0
00007431745d0ba9  vmovaps [rsp+0x10], xmm1
00007431745d0baf  vmovaps [rsp+0x20], xmm2
00007431745d0bb5  vmovaps [rsp+0x30], xmm3
00007431745d0bbb  vmovaps [rsp+0x40], xmm4
00007431745d0bc1  vmovaps [rsp+0x50], xmm5
00007431745d0bc7  vmovaps [rsp+0x60], xmm6
00007431745d0bcd  vmovaps [rsp+0x70], xmm7
00007431745d0bd3  vmovaps [rsp+0x80], xmm8
00007431745d0bdc  vmovaps [rsp+0x90], xmm9
00007431745d0be5  vmovaps [rsp+0xA0], xmm10
00007431745d0bee  vmovaps [rsp+0xB0], xmm11
00007431745d0bf7  vmovaps [rsp+0xC0], xmm12
00007431745d0c00  vmovaps [rsp+0xD0], xmm14
00007431745d0c09  vmovaps [rsp+0xE0], xmm15
00007431745d0c12  sub rsp, 0x30
00007431745d0c16  movaps [rsp], xmm13
00007431745d0c1b  movaps [rsp+0x10], xmm14
00007431745d0c21  movaps [rsp+0x20], xmm2
00007431745d0c26  lea rdi, [rsp]
00007431745d0c2a  mov esi, 0x00
00007431745d0c2f  mov rax, 0x56C40959E530
00007431745d0c39  call rax
00007431745d0c3b  movaps xmm13, [rsp]
00007431745d0c40  add rsp, 0x30
00007431745d0c44  vmovaps xmm0, [rsp]
00007431745d0c49  vmovaps xmm1, [rsp+0x10]
00007431745d0c4f  vmovaps xmm2, [rsp+0x20]
00007431745d0c55  vmovaps xmm3, [rsp+0x30]
00007431745d0c5b  vmovaps xmm4, [rsp+0x40]
00007431745d0c61  vmovaps xmm5, [rsp+0x50]
00007431745d0c67  vmovaps xmm6, [rsp+0x60]
00007431745d0c6d  vmovaps xmm7, [rsp+0x70]
00007431745d0c73  vmovaps xmm8, [rsp+0x80]
00007431745d0c7c  vmovaps xmm9, [rsp+0x90]
00007431745d0c85  vmovaps xmm10, [rsp+0xA0]
00007431745d0c8e  vmovaps xmm11, [rsp+0xB0]
00007431745d0c97  vmovaps xmm12, [rsp+0xC0]
00007431745d0ca0  vmovaps xmm14, [rsp+0xD0]
00007431745d0ca9  vmovaps xmm15, [rsp+0xE0]
00007431745d0cb2  add rsp, 0xF0
00007431745d0cb9  pop r11
00007431745d0cbb  pop r10
00007431745d0cbd  pop r9
00007431745d0cbf  pop r8
00007431745d0cc1  pop rsi
00007431745d0cc2  pop rdi
00007431745d0cc3  pop rdx
00007431745d0cc4  pop rcx
00007431745d0cc5  pop rax
00007431745d0cc6  add rsp, 0x08
00007431745d0cca  jmp 0x00007431745CF64C
00007431745d0ccf  sub rsp, 0x08
00007431745d0cd3  push rax
00007431745d0cd4  push rcx
00007431745d0cd5  push rdx
00007431745d0cd6  push rdi
00007431745d0cd7  push rsi
00007431745d0cd8  push r8
00007431745d0cda  push r9
00007431745d0cdc  push r10
00007431745d0cde  push r11
00007431745d0ce0  sub rsp, 0xF0
00007431745d0ce7  vmovaps [rsp], xmm0
00007431745d0cec  vmovaps [rsp+0x10], xmm2
00007431745d0cf2  vmovaps [rsp+0x20], xmm3
00007431745d0cf8  vmovaps [rsp+0x30], xmm4
00007431745d0cfe  vmovaps [rsp+0x40], xmm5
00007431745d0d04  vmovaps [rsp+0x50], xmm6
00007431745d0d0a  vmovaps [rsp+0x60], xmm7
00007431745d0d10  vmovaps [rsp+0x70], xmm8
00007431745d0d16  vmovaps [rsp+0x80], xmm9
00007431745d0d1f  vmovaps [rsp+0x90], xmm10
00007431745d0d28  vmovaps [rsp+0xA0], xmm11
00007431745d0d31  vmovaps [rsp+0xB0], xmm12
00007431745d0d3a  vmovaps [rsp+0xC0], xmm13
00007431745d0d43  vmovaps [rsp+0xD0], xmm14
00007431745d0d4c  vmovaps [rsp+0xE0], xmm15
00007431745d0d55  sub rsp, 0x30
00007431745d0d59  movaps [rsp], xmm1
00007431745d0d5d  movaps [rsp+0x10], xmm10
00007431745d0d63  movaps [rsp+0x20], xmm2
00007431745d0d68  lea rdi, [rsp]
00007431745d0d6c  mov esi, 0x00
00007431745d0d71  mov rax, 0x56C40959E530
00007431745d0d7b  call rax
00007431745d0d7d  movaps xmm1, [rsp]
00007431745d0d81  add rsp, 0x30
00007431745d0d85  vmovaps xmm0, [rsp]
00007431745d0d8a  vmovaps xmm2, [rsp+0x10]
00007431745d0d90  vmovaps xmm3, [rsp+0x20]
00007431745d0d96  vmovaps xmm4, [rsp+0x30]
00007431745d0d9c  vmovaps xmm5, [rsp+0x40]
00007431745d0da2  vmovaps xmm6, [rsp+0x50]
00007431745d0da8  vmovaps xmm7, [rsp+0x60]
00007431745d0dae  vmovaps xmm8, [rsp+0x70]
00007431745d0db4  vmovaps xmm9, [rsp+0x80]
00007431745d0dbd  vmovaps xmm10, [rsp+0x90]
00007431745d0dc6  vmovaps xmm11, [rsp+0xA0]
00007431745d0dcf  vmovaps xmm12, [rsp+0xB0]
00007431745d0dd8  vmovaps xmm13, [rsp+0xC0]
00007431745d0de1  vmovaps xmm14, [rsp+0xD0]
00007431745d0dea  vmovaps xmm15, [rsp+0xE0]
00007431745d0df3  add rsp, 0xF0
00007431745d0dfa  pop r11
00007431745d0dfc  pop r10
00007431745d0dfe  pop r9
00007431745d0e00  pop r8
00007431745d0e02  pop rsi
00007431745d0e03  pop rdi
00007431745d0e04  pop rdx
00007431745d0e05  pop rcx
00007431745d0e06  pop rax
00007431745d0e07  add rsp, 0x08
00007431745d0e0b  jmp 0x00007431745CF6B4
00007431745d0e10  sub rsp, 0x08
00007431745d0e14  push rax
00007431745d0e15  push rcx
00007431745d0e16  push rdx
00007431745d0e17  push rdi
00007431745d0e18  push rsi
00007431745d0e19  push r8
00007431745d0e1b  push r9
00007431745d0e1d  push r10
00007431745d0e1f  push r11
00007431745d0e21  sub rsp, 0xF0
00007431745d0e28  vmovaps [rsp], xmm0
00007431745d0e2d  vmovaps [rsp+0x10], xmm1
00007431745d0e33  vmovaps [rsp+0x20], xmm2
00007431745d0e39  vmovaps [rsp+0x30], xmm3
00007431745d0e3f  vmovaps [rsp+0x40], xmm4
00007431745d0e45  vmovaps [rsp+0x50], xmm5
00007431745d0e4b  vmovaps [rsp+0x60], xmm6
00007431745d0e51  vmovaps [rsp+0x70], xmm7
00007431745d0e57  vmovaps [rsp+0x80], xmm8
00007431745d0e60  vmovaps [rsp+0x90], xmm9
00007431745d0e69  vmovaps [rsp+0xA0], xmm10
00007431745d0e72  vmovaps [rsp+0xB0], xmm11
00007431745d0e7b  vmovaps [rsp+0xC0], xmm12
00007431745d0e84  vmovaps [rsp+0xD0], xmm13
00007431745d0e8d  vmovaps [rsp+0xE0], xmm14
00007431745d0e96  sub rsp, 0x30
00007431745d0e9a  movaps [rsp], xmm15
00007431745d0e9f  movaps [rsp+0x10], xmm10
00007431745d0ea5  movaps [rsp+0x20], xmm2
00007431745d0eaa  lea rdi, [rsp]
00007431745d0eae  mov esi, 0x00
00007431745d0eb3  mov rax, 0x56C40959E530
00007431745d0ebd  call rax
00007431745d0ebf  movaps xmm15, [rsp]
00007431745d0ec4  add rsp, 0x30
00007431745d0ec8  vmovaps xmm0, [rsp]
00007431745d0ecd  vmovaps xmm1, [rsp+0x10]
00007431745d0ed3  vmovaps xmm2, [rsp+0x20]
00007431745d0ed9  vmovaps xmm3, [rsp+0x30]
00007431745d0edf  vmovaps xmm4, [rsp+0x40]
00007431745d0ee5  vmovaps xmm5, [rsp+0x50]
00007431745d0eeb  vmovaps xmm6, [rsp+0x60]
00007431745d0ef1  vmovaps xmm7, [rsp+0x70]
00007431745d0ef7  vmovaps xmm8, [rsp+0x80]
00007431745d0f00  vmovaps xmm9, [rsp+0x90]
00007431745d0f09  vmovaps xmm10, [rsp+0xA0]
00007431745d0f12  vmovaps xmm11, [rsp+0xB0]
00007431745d0f1b  vmovaps xmm12, [rsp+0xC0]
00007431745d0f24  vmovaps xmm13, [rsp+0xD0]
00007431745d0f2d  vmovaps xmm14, [rsp+0xE0]
00007431745d0f36  add rsp, 0xF0
00007431745d0f3d  pop r11
00007431745d0f3f  pop r10
00007431745d0f41  pop r9
00007431745d0f43  pop r8
00007431745d0f45  pop rsi
00007431745d0f46  pop rdi
00007431745d0f47  pop rdx
00007431745d0f48  pop rcx
00007431745d0f49  pop rax
00007431745d0f4a  add rsp, 0x08
00007431745d0f4e  jmp 0x00007431745CF706
00007431745d0f53  sub rsp, 0x08
00007431745d0f57  push rax
00007431745d0f58  push rcx
00007431745d0f59  push rdx
00007431745d0f5a  push rdi
00007431745d0f5b  push rsi
00007431745d0f5c  push r8
00007431745d0f5e  push r9
00007431745d0f60  push r10
00007431745d0f62  push r11
00007431745d0f64  sub rsp, 0xF0
00007431745d0f6b  vmovaps [rsp], xmm0
00007431745d0f70  vmovaps [rsp+0x10], xmm2
00007431745d0f76  vmovaps [rsp+0x20], xmm3
00007431745d0f7c  vmovaps [rsp+0x30], xmm4
00007431745d0f82  vmovaps [rsp+0x40], xmm5
00007431745d0f88  vmovaps [rsp+0x50], xmm6
00007431745d0f8e  vmovaps [rsp+0x60], xmm7
00007431745d0f94  vmovaps [rsp+0x70], xmm8
00007431745d0f9a  vmovaps [rsp+0x80], xmm9
00007431745d0fa3  vmovaps [rsp+0x90], xmm10
00007431745d0fac  vmovaps [rsp+0xA0], xmm11
00007431745d0fb5  vmovaps [rsp+0xB0], xmm12
00007431745d0fbe  vmovaps [rsp+0xC0], xmm13
00007431745d0fc7  vmovaps [rsp+0xD0], xmm14
00007431745d0fd0  vmovaps [rsp+0xE0], xmm15
00007431745d0fd9  sub rsp, 0x30
00007431745d0fdd  movaps [rsp], xmm1
00007431745d0fe1  movaps [rsp+0x10], xmm10
00007431745d0fe7  movaps [rsp+0x20], xmm12
00007431745d0fed  lea rdi, [rsp]
00007431745d0ff1  mov esi, 0x00
00007431745d0ff6  mov rax, 0x56C40959E530
00007431745d1000  call rax
00007431745d1002  movaps xmm1, [rsp]
00007431745d1006  add rsp, 0x30
00007431745d100a  vmovaps xmm0, [rsp]
00007431745d100f  vmovaps xmm2, [rsp+0x10]
00007431745d1015  vmovaps xmm3, [rsp+0x20]
00007431745d101b  vmovaps xmm4, [rsp+0x30]
00007431745d1021  vmovaps xmm5, [rsp+0x40]
00007431745d1027  vmovaps xmm6, [rsp+0x50]
00007431745d102d  vmovaps xmm7, [rsp+0x60]
00007431745d1033  vmovaps xmm8, [rsp+0x70]
00007431745d1039  vmovaps xmm9, [rsp+0x80]
00007431745d1042  vmovaps xmm10, [rsp+0x90]
00007431745d104b  vmovaps xmm11, [rsp+0xA0]
00007431745d1054  vmovaps xmm12, [rsp+0xB0]
00007431745d105d  vmovaps xmm13, [rsp+0xC0]
00007431745d1066  vmovaps xmm14, [rsp+0xD0]
00007431745d106f  vmovaps xmm15, [rsp+0xE0]
00007431745d1078  add rsp, 0xF0
00007431745d107f  pop r11
00007431745d1081  pop r10
00007431745d1083  pop r9
00007431745d1085  pop r8
00007431745d1087  pop rsi
00007431745d1088  pop rdi
00007431745d1089  pop rdx
00007431745d108a  pop rcx
00007431745d108b  pop rax
00007431745d108c  add rsp, 0x08
00007431745d1090  jmp 0x00007431745CF732
00007431745d1095  sub rsp, 0x08
00007431745d1099  push rax
00007431745d109a  push rcx
00007431745d109b  push rdx
00007431745d109c  push rdi
00007431745d109d  push rsi
00007431745d109e  push r8
00007431745d10a0  push r9
00007431745d10a2  push r10
00007431745d10a4  push r11
00007431745d10a6  sub rsp, 0xF0
00007431745d10ad  vmovaps [rsp], xmm0
00007431745d10b2  vmovaps [rsp+0x10], xmm1
00007431745d10b8  vmovaps [rsp+0x20], xmm2
00007431745d10be  vmovaps [rsp+0x30], xmm3
00007431745d10c4  vmovaps [rsp+0x40], xmm4
00007431745d10ca  vmovaps [rsp+0x50], xmm5
00007431745d10d0  vmovaps [rsp+0x60], xmm6
00007431745d10d6  vmovaps [rsp+0x70], xmm7
00007431745d10dc  vmovaps [rsp+0x80], xmm8
00007431745d10e5  vmovaps [rsp+0x90], xmm9
00007431745d10ee  vmovaps [rsp+0xA0], xmm10
00007431745d10f7  vmovaps [rsp+0xB0], xmm11
00007431745d1100  vmovaps [rsp+0xC0], xmm12
00007431745d1109  vmovaps [rsp+0xD0], xmm13
00007431745d1112  vmovaps [rsp+0xE0], xmm14
00007431745d111b  sub rsp, 0x30
00007431745d111f  movaps [rsp], xmm15
00007431745d1124  movaps [rsp+0x10], xmm10
00007431745d112a  movaps [rsp+0x20], xmm12
00007431745d1130  lea rdi, [rsp]
00007431745d1134  mov esi, 0x00
00007431745d1139  mov rax, 0x56C40959E530
00007431745d1143  call rax
00007431745d1145  movaps xmm15, [rsp]
00007431745d114a  add rsp, 0x30
00007431745d114e  vmovaps xmm0, [rsp]
00007431745d1153  vmovaps xmm1, [rsp+0x10]
00007431745d1159  vmovaps xmm2, [rsp+0x20]
00007431745d115f  vmovaps xmm3, [rsp+0x30]
00007431745d1165  vmovaps xmm4, [rsp+0x40]
00007431745d116b  vmovaps xmm5, [rsp+0x50]
00007431745d1171  vmovaps xmm6, [rsp+0x60]
00007431745d1177  vmovaps xmm7, [rsp+0x70]
00007431745d117d  vmovaps xmm8, [rsp+0x80]
00007431745d1186  vmovaps xmm9, [rsp+0x90]
00007431745d118f  vmovaps xmm10, [rsp+0xA0]
00007431745d1198  vmovaps xmm11, [rsp+0xB0]
00007431745d11a1  vmovaps xmm12, [rsp+0xC0]
00007431745d11aa  vmovaps xmm13, [rsp+0xD0]
00007431745d11b3  vmovaps xmm14, [rsp+0xE0]
00007431745d11bc  add rsp, 0xF0
00007431745d11c3  pop r11
00007431745d11c5  pop r10
00007431745d11c7  pop r9
00007431745d11c9  pop r8
00007431745d11cb  pop rsi
00007431745d11cc  pop rdi
00007431745d11cd  pop rdx
00007431745d11ce  pop rcx
00007431745d11cf  pop rax
00007431745d11d0  add rsp, 0x08
00007431745d11d4  jmp 0x00007431745CF75E
00007431745d11d9  call 0x00007431743FF430
00007431745d11de  jmp 0x00007431745CF7EE
00007431745d11e3  call 0x00007431743FF430
00007431745d11e8  jmp 0x00007431745CF801
00007431745d11ed  sub rsp, 0x08
00007431745d11f1  push rax
00007431745d11f2  push rcx
00007431745d11f3  push rdx
00007431745d11f4  push rdi
00007431745d11f5  push rsi
00007431745d11f6  push r8
00007431745d11f8  push r9
00007431745d11fa  push r10
00007431745d11fc  push r11
00007431745d11fe  sub rsp, 0xF0
00007431745d1205  vmovaps [rsp], xmm0
00007431745d120a  vmovaps [rsp+0x10], xmm2
00007431745d1210  vmovaps [rsp+0x20], xmm3
00007431745d1216  vmovaps [rsp+0x30], xmm4
00007431745d121c  vmovaps [rsp+0x40], xmm5
00007431745d1222  vmovaps [rsp+0x50], xmm6
00007431745d1228  vmovaps [rsp+0x60], xmm7
00007431745d122e  vmovaps [rsp+0x70], xmm8
00007431745d1234  vmovaps [rsp+0x80], xmm9
00007431745d123d  vmovaps [rsp+0x90], xmm10
00007431745d1246  vmovaps [rsp+0xA0], xmm11
00007431745d124f  vmovaps [rsp+0xB0], xmm12
00007431745d1258  vmovaps [rsp+0xC0], xmm13
00007431745d1261  vmovaps [rsp+0xD0], xmm14
00007431745d126a  vmovaps [rsp+0xE0], xmm15
00007431745d1273  sub rsp, 0x30
00007431745d1277  movaps [rsp], xmm1
00007431745d127b  movaps [rsp+0x10], xmm13
00007431745d1281  movaps [rsp+0x20], xmm2
00007431745d1286  lea rdi, [rsp]
00007431745d128a  mov esi, 0x00
00007431745d128f  mov rax, 0x56C40959E530
00007431745d1299  call rax
00007431745d129b  movaps xmm1, [rsp]
00007431745d129f  add rsp, 0x30
00007431745d12a3  vmovaps xmm0, [rsp]
00007431745d12a8  vmovaps xmm2, [rsp+0x10]
00007431745d12ae  vmovaps xmm3, [rsp+0x20]
00007431745d12b4  vmovaps xmm4, [rsp+0x30]
00007431745d12ba  vmovaps xmm5, [rsp+0x40]
00007431745d12c0  vmovaps xmm6, [rsp+0x50]
00007431745d12c6  vmovaps xmm7, [rsp+0x60]
00007431745d12cc  vmovaps xmm8, [rsp+0x70]
00007431745d12d2  vmovaps xmm9, [rsp+0x80]
00007431745d12db  vmovaps xmm10, [rsp+0x90]
00007431745d12e4  vmovaps xmm11, [rsp+0xA0]
00007431745d12ed  vmovaps xmm12, [rsp+0xB0]
00007431745d12f6  vmovaps xmm13, [rsp+0xC0]
00007431745d12ff  vmovaps xmm14, [rsp+0xD0]
00007431745d1308  vmovaps xmm15, [rsp+0xE0]
00007431745d1311  add rsp, 0xF0
00007431745d1318  pop r11
00007431745d131a  pop r10
00007431745d131c  pop r9
00007431745d131e  pop r8
00007431745d1320  pop rsi
00007431745d1321  pop rdi
00007431745d1322  pop rdx
00007431745d1323  pop rcx
00007431745d1324  pop rax
00007431745d1325  add rsp, 0x08
00007431745d1329  jmp 0x00007431745CF82C
00007431745d132e  call 0x000074317440E760
00007431745d1333  jmp 0x00007431745CF839
00007431745d1338  sub rsp, 0x08
00007431745d133c  push rax
00007431745d133d  push rcx
00007431745d133e  push rdx
00007431745d133f  push rdi
00007431745d1340  push rsi
00007431745d1341  push r8
00007431745d1343  push r9
00007431745d1345  push r10
00007431745d1347  push r11
00007431745d1349  sub rsp, 0xF0
00007431745d1350  vmovaps [rsp], xmm0
00007431745d1355  vmovaps [rsp+0x10], xmm1
00007431745d135b  vmovaps [rsp+0x20], xmm2
00007431745d1361  vmovaps [rsp+0x30], xmm3
00007431745d1367  vmovaps [rsp+0x40], xmm4
00007431745d136d  vmovaps [rsp+0x50], xmm5
00007431745d1373  vmovaps [rsp+0x60], xmm6
00007431745d1379  vmovaps [rsp+0x70], xmm7
00007431745d137f  vmovaps [rsp+0x80], xmm8
00007431745d1388  vmovaps [rsp+0x90], xmm9
00007431745d1391  vmovaps [rsp+0xA0], xmm10
00007431745d139a  vmovaps [rsp+0xB0], xmm11
00007431745d13a3  vmovaps [rsp+0xC0], xmm12
00007431745d13ac  vmovaps [rsp+0xD0], xmm14
00007431745d13b5  vmovaps [rsp+0xE0], xmm15
00007431745d13be  sub rsp, 0x30
00007431745d13c2  movaps [rsp], xmm13
00007431745d13c7  movaps [rsp+0x10], xmm2
00007431745d13cc  movaps [rsp+0x20], xmm1
00007431745d13d1  lea rdi, [rsp]
00007431745d13d5  mov esi, 0x00
00007431745d13da  mov rax, 0x56C40959E530
00007431745d13e4  call rax
00007431745d13e6  movaps xmm13, [rsp]
00007431745d13eb  add rsp, 0x30
00007431745d13ef  vmovaps xmm0, [rsp]
00007431745d13f4  vmovaps xmm1, [rsp+0x10]
00007431745d13fa  vmovaps xmm2, [rsp+0x20]
00007431745d1400  vmovaps xmm3, [rsp+0x30]
00007431745d1406  vmovaps xmm4, [rsp+0x40]
00007431745d140c  vmovaps xmm5, [rsp+0x50]
00007431745d1412  vmovaps xmm6, [rsp+0x60]
00007431745d1418  vmovaps xmm7, [rsp+0x70]
00007431745d141e  vmovaps xmm8, [rsp+0x80]
00007431745d1427  vmovaps xmm9, [rsp+0x90]
00007431745d1430  vmovaps xmm10, [rsp+0xA0]
00007431745d1439  vmovaps xmm11, [rsp+0xB0]
00007431745d1442  vmovaps xmm12, [rsp+0xC0]
00007431745d144b  vmovaps xmm14, [rsp+0xD0]
00007431745d1454  vmovaps xmm15, [rsp+0xE0]
00007431745d145d  add rsp, 0xF0
00007431745d1464  pop r11
00007431745d1466  pop r10
00007431745d1468  pop r9
00007431745d146a  pop r8
00007431745d146c  pop rsi
00007431745d146d  pop rdi
00007431745d146e  pop rdx
00007431745d146f  pop rcx
00007431745d1470  pop rax
00007431745d1471  add rsp, 0x08
00007431745d1475  jmp 0x00007431745CF878
00007431745d147a  sub rsp, 0x08
00007431745d147e  push rax
00007431745d147f  push rcx
00007431745d1480  push rdx
00007431745d1481  push rdi
00007431745d1482  push rsi
00007431745d1483  push r8
00007431745d1485  push r9
00007431745d1487  push r10
00007431745d1489  push r11
00007431745d148b  sub rsp, 0xF0
00007431745d1492  vmovaps [rsp], xmm0
00007431745d1497  vmovaps [rsp+0x10], xmm2
00007431745d149d  vmovaps [rsp+0x20], xmm3
00007431745d14a3  vmovaps [rsp+0x30], xmm4
00007431745d14a9  vmovaps [rsp+0x40], xmm5
00007431745d14af  vmovaps [rsp+0x50], xmm6
00007431745d14b5  vmovaps [rsp+0x60], xmm7
00007431745d14bb  vmovaps [rsp+0x70], xmm8
00007431745d14c1  vmovaps [rsp+0x80], xmm9
00007431745d14ca  vmovaps [rsp+0x90], xmm10
00007431745d14d3  vmovaps [rsp+0xA0], xmm11
00007431745d14dc  vmovaps [rsp+0xB0], xmm12
00007431745d14e5  vmovaps [rsp+0xC0], xmm13
00007431745d14ee  vmovaps [rsp+0xD0], xmm14
00007431745d14f7  vmovaps [rsp+0xE0], xmm15
00007431745d1500  sub rsp, 0x30
00007431745d1504  movaps [rsp], xmm1
00007431745d1508  movaps [rsp+0x10], xmm15
00007431745d150e  movaps [rsp+0x20], xmm2
00007431745d1513  lea rdi, [rsp]
00007431745d1517  mov esi, 0x00
00007431745d151c  mov rax, 0x56C40959E530
00007431745d1526  call rax
00007431745d1528  movaps xmm1, [rsp]
00007431745d152c  add rsp, 0x30
00007431745d1530  vmovaps xmm0, [rsp]
00007431745d1535  vmovaps xmm2, [rsp+0x10]
00007431745d153b  vmovaps xmm3, [rsp+0x20]
00007431745d1541  vmovaps xmm4, [rsp+0x30]
00007431745d1547  vmovaps xmm5, [rsp+0x40]
00007431745d154d  vmovaps xmm6, [rsp+0x50]
00007431745d1553  vmovaps xmm7, [rsp+0x60]
00007431745d1559  vmovaps xmm8, [rsp+0x70]
00007431745d155f  vmovaps xmm9, [rsp+0x80]
00007431745d1568  vmovaps xmm10, [rsp+0x90]
00007431745d1571  vmovaps xmm11, [rsp+0xA0]
00007431745d157a  vmovaps xmm12, [rsp+0xB0]
00007431745d1583  vmovaps xmm13, [rsp+0xC0]
00007431745d158c  vmovaps xmm14, [rsp+0xD0]
00007431745d1595  vmovaps xmm15, [rsp+0xE0]
00007431745d159e  add rsp, 0xF0
00007431745d15a5  pop r11
00007431745d15a7  pop r10
00007431745d15a9  pop r9
00007431745d15ab  pop r8
00007431745d15ad  pop rsi
00007431745d15ae  pop rdi
00007431745d15af  pop rdx
00007431745d15b0  pop rcx
00007431745d15b1  pop rax
00007431745d15b2  add rsp, 0x08
00007431745d15b6  jmp 0x00007431745CF8AC
00007431745d15bb  sub rsp, 0x08
00007431745d15bf  push rax
00007431745d15c0  push rcx
00007431745d15c1  push rdx
00007431745d15c2  push rdi
00007431745d15c3  push rsi
00007431745d15c4  push r8
00007431745d15c6  push r9
00007431745d15c8  push r10
00007431745d15ca  push r11
00007431745d15cc  sub rsp, 0xF0
00007431745d15d3  vmovaps [rsp], xmm0
00007431745d15d8  vmovaps [rsp+0x10], xmm1
00007431745d15de  vmovaps [rsp+0x20], xmm2
00007431745d15e4  vmovaps [rsp+0x30], xmm3
00007431745d15ea  vmovaps [rsp+0x40], xmm4
00007431745d15f0  vmovaps [rsp+0x50], xmm5
00007431745d15f6  vmovaps [rsp+0x60], xmm6
00007431745d15fc  vmovaps [rsp+0x70], xmm7
00007431745d1602  vmovaps [rsp+0x80], xmm8
00007431745d160b  vmovaps [rsp+0x90], xmm9
00007431745d1614  vmovaps [rsp+0xA0], xmm10
00007431745d161d  vmovaps [rsp+0xB0], xmm11
00007431745d1626  vmovaps [rsp+0xC0], xmm12
00007431745d162f  vmovaps [rsp+0xD0], xmm13
00007431745d1638  vmovaps [rsp+0xE0], xmm15
00007431745d1641  sub rsp, 0x30
00007431745d1645  movaps [rsp], xmm14
00007431745d164a  movaps [rsp+0x10], xmm2
00007431745d164f  movaps [rsp+0x20], xmm15
00007431745d1655  lea rdi, [rsp]
00007431745d1659  mov esi, 0x00
00007431745d165e  mov rax, 0x56C40959E530
00007431745d1668  call rax
00007431745d166a  movaps xmm14, [rsp]
00007431745d166f  add rsp, 0x30
00007431745d1673  vmovaps xmm0, [rsp]
00007431745d1678  vmovaps xmm1, [rsp+0x10]
00007431745d167e  vmovaps xmm2, [rsp+0x20]
00007431745d1684  vmovaps xmm3, [rsp+0x30]
00007431745d168a  vmovaps xmm4, [rsp+0x40]
00007431745d1690  vmovaps xmm5, [rsp+0x50]
00007431745d1696  vmovaps xmm6, [rsp+0x60]
00007431745d169c  vmovaps xmm7, [rsp+0x70]
00007431745d16a2  vmovaps xmm8, [rsp+0x80]
00007431745d16ab  vmovaps xmm9, [rsp+0x90]
00007431745d16b4  vmovaps xmm10, [rsp+0xA0]
00007431745d16bd  vmovaps xmm11, [rsp+0xB0]
00007431745d16c6  vmovaps xmm12, [rsp+0xC0]
00007431745d16cf  vmovaps xmm13, [rsp+0xD0]
00007431745d16d8  vmovaps xmm15, [rsp+0xE0]
00007431745d16e1  add rsp, 0xF0
00007431745d16e8  pop r11
00007431745d16ea  pop r10
00007431745d16ec  pop r9
00007431745d16ee  pop r8
00007431745d16f0  pop rsi
00007431745d16f1  pop rdi
00007431745d16f2  pop rdx
00007431745d16f3  pop rcx
00007431745d16f4  pop rax
00007431745d16f5  add rsp, 0x08
00007431745d16f9  jmp 0x00007431745CF8E7
00007431745d16fe  sub rsp, 0x08
00007431745d1702  push rax
00007431745d1703  push rcx
00007431745d1704  push rdx
00007431745d1705  push rdi
00007431745d1706  push rsi
00007431745d1707  push r8
00007431745d1709  push r9
00007431745d170b  push r10
00007431745d170d  push r11
00007431745d170f  sub rsp, 0xF0
00007431745d1716  vmovaps [rsp], xmm0
00007431745d171b  vmovaps [rsp+0x10], xmm1
00007431745d1721  vmovaps [rsp+0x20], xmm2
00007431745d1727  vmovaps [rsp+0x30], xmm3
00007431745d172d  vmovaps [rsp+0x40], xmm4
00007431745d1733  vmovaps [rsp+0x50], xmm5
00007431745d1739  vmovaps [rsp+0x60], xmm6
00007431745d173f  vmovaps [rsp+0x70], xmm7
00007431745d1745  vmovaps [rsp+0x80], xmm8
00007431745d174e  vmovaps [rsp+0x90], xmm9
00007431745d1757  vmovaps [rsp+0xA0], xmm10
00007431745d1760  vmovaps [rsp+0xB0], xmm11
00007431745d1769  vmovaps [rsp+0xC0], xmm12
00007431745d1772  vmovaps [rsp+0xD0], xmm13
00007431745d177b  vmovaps [rsp+0xE0], xmm14
00007431745d1784  sub rsp, 0x30
00007431745d1788  movaps [rsp], xmm15
00007431745d178d  movaps [rsp+0x10], xmm2
00007431745d1792  movaps [rsp+0x20], xmm1
00007431745d1797  lea rdi, [rsp]
00007431745d179b  mov esi, 0x00
00007431745d17a0  mov rax, 0x56C40959E530
00007431745d17aa  call rax
00007431745d17ac  movaps xmm15, [rsp]
00007431745d17b1  add rsp, 0x30
00007431745d17b5  vmovaps xmm0, [rsp]
00007431745d17ba  vmovaps xmm1, [rsp+0x10]
00007431745d17c0  vmovaps xmm2, [rsp+0x20]
00007431745d17c6  vmovaps xmm3, [rsp+0x30]
00007431745d17cc  vmovaps xmm4, [rsp+0x40]
00007431745d17d2  vmovaps xmm5, [rsp+0x50]
00007431745d17d8  vmovaps xmm6, [rsp+0x60]
00007431745d17de  vmovaps xmm7, [rsp+0x70]
00007431745d17e4  vmovaps xmm8, [rsp+0x80]
00007431745d17ed  vmovaps xmm9, [rsp+0x90]
00007431745d17f6  vmovaps xmm10, [rsp+0xA0]
00007431745d17ff  vmovaps xmm11, [rsp+0xB0]
00007431745d1808  vmovaps xmm12, [rsp+0xC0]
00007431745d1811  vmovaps xmm13, [rsp+0xD0]
00007431745d181a  vmovaps xmm14, [rsp+0xE0]
00007431745d1823  add rsp, 0xF0
00007431745d182a  pop r11
00007431745d182c  pop r10
00007431745d182e  pop r9
00007431745d1830  pop r8
00007431745d1832  pop rsi
00007431745d1833  pop rdi
00007431745d1834  pop rdx
00007431745d1835  pop rcx
00007431745d1836  pop rax
00007431745d1837  add rsp, 0x08
00007431745d183b  jmp 0x00007431745CF923
00007431745d1840  call 0x00007431743FF430
00007431745d1845  jmp 0x00007431745CF930
00007431745d184a  sub rsp, 0x08
00007431745d184e  push rax
00007431745d184f  push rcx
00007431745d1850  push rdx
00007431745d1851  push rdi
00007431745d1852  push rsi
00007431745d1853  push r8
00007431745d1855  push r9
00007431745d1857  push r10
00007431745d1859  push r11
00007431745d185b  sub rsp, 0xF0
00007431745d1862  vmovaps [rsp], xmm0
00007431745d1867  vmovaps [rsp+0x10], xmm1
00007431745d186d  vmovaps [rsp+0x20], xmm3
00007431745d1873  vmovaps [rsp+0x30], xmm4
00007431745d1879  vmovaps [rsp+0x40], xmm5
00007431745d187f  vmovaps [rsp+0x50], xmm6
00007431745d1885  vmovaps [rsp+0x60], xmm7
00007431745d188b  vmovaps [rsp+0x70], xmm8
00007431745d1891  vmovaps [rsp+0x80], xmm9
00007431745d189a  vmovaps [rsp+0x90], xmm10
00007431745d18a3  vmovaps [rsp+0xA0], xmm11
00007431745d18ac  vmovaps [rsp+0xB0], xmm12
00007431745d18b5  vmovaps [rsp+0xC0], xmm13
00007431745d18be  vmovaps [rsp+0xD0], xmm14
00007431745d18c7  vmovaps [rsp+0xE0], xmm15
00007431745d18d0  sub rsp, 0x30
00007431745d18d4  movaps [rsp], xmm2
00007431745d18d8  movaps [rsp+0x10], xmm1
00007431745d18dd  movaps [rsp+0x20], xmm14
00007431745d18e3  lea rdi, [rsp]
00007431745d18e7  mov esi, 0x00
00007431745d18ec  mov rax, 0x56C40959E530
00007431745d18f6  call rax
00007431745d18f8  movaps xmm2, [rsp]
00007431745d18fc  add rsp, 0x30
00007431745d1900  vmovaps xmm0, [rsp]
00007431745d1905  vmovaps xmm1, [rsp+0x10]
00007431745d190b  vmovaps xmm3, [rsp+0x20]
00007431745d1911  vmovaps xmm4, [rsp+0x30]
00007431745d1917  vmovaps xmm5, [rsp+0x40]
00007431745d191d  vmovaps xmm6, [rsp+0x50]
00007431745d1923  vmovaps xmm7, [rsp+0x60]
00007431745d1929  vmovaps xmm8, [rsp+0x70]
00007431745d192f  vmovaps xmm9, [rsp+0x80]
00007431745d1938  vmovaps xmm10, [rsp+0x90]
00007431745d1941  vmovaps xmm11, [rsp+0xA0]
00007431745d194a  vmovaps xmm12, [rsp+0xB0]
00007431745d1953  vmovaps xmm13, [rsp+0xC0]
00007431745d195c  vmovaps xmm14, [rsp+0xD0]
00007431745d1965  vmovaps xmm15, [rsp+0xE0]
00007431745d196e  add rsp, 0xF0
00007431745d1975  pop r11
00007431745d1977  pop r10
00007431745d1979  pop r9
00007431745d197b  pop r8
00007431745d197d  pop rsi
00007431745d197e  pop rdi
00007431745d197f  pop rdx
00007431745d1980  pop rcx
00007431745d1981  pop rax
00007431745d1982  add rsp, 0x08
00007431745d1986  jmp 0x00007431745CF96D
00007431745d198b  sub rsp, 0x08
00007431745d198f  push rax
00007431745d1990  push rcx
00007431745d1991  push rdx
00007431745d1992  push rdi
00007431745d1993  push rsi
00007431745d1994  push r8
00007431745d1996  push r9
00007431745d1998  push r10
00007431745d199a  push r11
00007431745d199c  sub rsp, 0xF0
00007431745d19a3  vmovaps [rsp], xmm0
00007431745d19a8  vmovaps [rsp+0x10], xmm1
00007431745d19ae  vmovaps [rsp+0x20], xmm2
00007431745d19b4  vmovaps [rsp+0x30], xmm3
00007431745d19ba  vmovaps [rsp+0x40], xmm4
00007431745d19c0  vmovaps [rsp+0x50], xmm5
00007431745d19c6  vmovaps [rsp+0x60], xmm6
00007431745d19cc  vmovaps [rsp+0x70], xmm7
00007431745d19d2  vmovaps [rsp+0x80], xmm8
00007431745d19db  vmovaps [rsp+0x90], xmm9
00007431745d19e4  vmovaps [rsp+0xA0], xmm10
00007431745d19ed  vmovaps [rsp+0xB0], xmm11
00007431745d19f6  vmovaps [rsp+0xC0], xmm12
00007431745d19ff  vmovaps [rsp+0xD0], xmm13
00007431745d1a08  vmovaps [rsp+0xE0], xmm14
00007431745d1a11  sub rsp, 0x30
00007431745d1a15  movaps [rsp], xmm15
00007431745d1a1a  movaps [rsp+0x10], xmm14
00007431745d1a20  movaps [rsp+0x20], xmm1
00007431745d1a25  lea rdi, [rsp]
00007431745d1a29  mov esi, 0x00
00007431745d1a2e  mov rax, 0x56C40959E530
00007431745d1a38  call rax
00007431745d1a3a  movaps xmm15, [rsp]
00007431745d1a3f  add rsp, 0x30
00007431745d1a43  vmovaps xmm0, [rsp]
00007431745d1a48  vmovaps xmm1, [rsp+0x10]
00007431745d1a4e  vmovaps xmm2, [rsp+0x20]
00007431745d1a54  vmovaps xmm3, [rsp+0x30]
00007431745d1a5a  vmovaps xmm4, [rsp+0x40]
00007431745d1a60  vmovaps xmm5, [rsp+0x50]
00007431745d1a66  vmovaps xmm6, [rsp+0x60]
00007431745d1a6c  vmovaps xmm7, [rsp+0x70]
00007431745d1a72  vmovaps xmm8, [rsp+0x80]
00007431745d1a7b  vmovaps xmm9, [rsp+0x90]
00007431745d1a84  vmovaps xmm10, [rsp+0xA0]
00007431745d1a8d  vmovaps xmm11, [rsp+0xB0]
00007431745d1a96  vmovaps xmm12, [rsp+0xC0]
00007431745d1a9f  vmovaps xmm13, [rsp+0xD0]
00007431745d1aa8  vmovaps xmm14, [rsp+0xE0]
00007431745d1ab1  add rsp, 0xF0
00007431745d1ab8  pop r11
00007431745d1aba  pop r10
00007431745d1abc  pop r9
00007431745d1abe  pop r8
00007431745d1ac0  pop rsi
00007431745d1ac1  pop rdi
00007431745d1ac2  pop rdx
00007431745d1ac3  pop rcx
00007431745d1ac4  pop rax
00007431745d1ac5  add rsp, 0x08
00007431745d1ac9  jmp 0x00007431745CF9E7
00007431745d1ace  call 0x00007431743FF430
00007431745d1ad3  jmp 0x00007431745CF9F4
00007431745d1ad8  sub rsp, 0x08
00007431745d1adc  push rax
00007431745d1add  push rcx
00007431745d1ade  push rdx
00007431745d1adf  push rdi
00007431745d1ae0  push rsi
00007431745d1ae1  push r8
00007431745d1ae3  push r9
00007431745d1ae5  push r10
00007431745d1ae7  push r11
00007431745d1ae9  sub rsp, 0xF0
00007431745d1af0  vmovaps [rsp], xmm0
00007431745d1af5  vmovaps [rsp+0x10], xmm1
00007431745d1afb  vmovaps [rsp+0x20], xmm2
00007431745d1b01  vmovaps [rsp+0x30], xmm3
00007431745d1b07  vmovaps [rsp+0x40], xmm4
00007431745d1b0d  vmovaps [rsp+0x50], xmm5
00007431745d1b13  vmovaps [rsp+0x60], xmm6
00007431745d1b19  vmovaps [rsp+0x70], xmm7
00007431745d1b1f  vmovaps [rsp+0x80], xmm8
00007431745d1b28  vmovaps [rsp+0x90], xmm9
00007431745d1b31  vmovaps [rsp+0xA0], xmm10
00007431745d1b3a  vmovaps [rsp+0xB0], xmm11
00007431745d1b43  vmovaps [rsp+0xC0], xmm12
00007431745d1b4c  vmovaps [rsp+0xD0], xmm13
00007431745d1b55  vmovaps [rsp+0xE0], xmm15
00007431745d1b5e  sub rsp, 0x30
00007431745d1b62  movaps [rsp], xmm14
00007431745d1b67  movaps [rsp+0x10], xmm13
00007431745d1b6d  movaps [rsp+0x20], xmm1
00007431745d1b72  lea rdi, [rsp]
00007431745d1b76  mov esi, 0x00
00007431745d1b7b  mov rax, 0x56C40959E530
00007431745d1b85  call rax
00007431745d1b87  movaps xmm14, [rsp]
00007431745d1b8c  add rsp, 0x30
00007431745d1b90  vmovaps xmm0, [rsp]
00007431745d1b95  vmovaps xmm1, [rsp+0x10]
00007431745d1b9b  vmovaps xmm2, [rsp+0x20]
00007431745d1ba1  vmovaps xmm3, [rsp+0x30]
00007431745d1ba7  vmovaps xmm4, [rsp+0x40]
00007431745d1bad  vmovaps xmm5, [rsp+0x50]
00007431745d1bb3  vmovaps xmm6, [rsp+0x60]
00007431745d1bb9  vmovaps xmm7, [rsp+0x70]
00007431745d1bbf  vmovaps xmm8, [rsp+0x80]
00007431745d1bc8  vmovaps xmm9, [rsp+0x90]
00007431745d1bd1  vmovaps xmm10, [rsp+0xA0]
00007431745d1bda  vmovaps xmm11, [rsp+0xB0]
00007431745d1be3  vmovaps xmm12, [rsp+0xC0]
00007431745d1bec  vmovaps xmm13, [rsp+0xD0]
00007431745d1bf5  vmovaps xmm15, [rsp+0xE0]
00007431745d1bfe  add rsp, 0xF0
00007431745d1c05  pop r11
00007431745d1c07  pop r10
00007431745d1c09  pop r9
00007431745d1c0b  pop r8
00007431745d1c0d  pop rsi
00007431745d1c0e  pop rdi
00007431745d1c0f  pop rdx
00007431745d1c10  pop rcx
00007431745d1c11  pop rax
00007431745d1c12  add rsp, 0x08
00007431745d1c16  jmp 0x00007431745CFAAF
00007431745d1c1b  sub rsp, 0x08
00007431745d1c1f  push rax
00007431745d1c20  push rcx
00007431745d1c21  push rdx
00007431745d1c22  push rdi
00007431745d1c23  push rsi
00007431745d1c24  push r8
00007431745d1c26  push r9
00007431745d1c28  push r10
00007431745d1c2a  push r11
00007431745d1c2c  sub rsp, 0xF0
00007431745d1c33  vmovaps [rsp], xmm0
00007431745d1c38  vmovaps [rsp+0x10], xmm1
00007431745d1c3e  vmovaps [rsp+0x20], xmm2
00007431745d1c44  vmovaps [rsp+0x30], xmm3
00007431745d1c4a  vmovaps [rsp+0x40], xmm4
00007431745d1c50  vmovaps [rsp+0x50], xmm5
00007431745d1c56  vmovaps [rsp+0x60], xmm6
00007431745d1c5c  vmovaps [rsp+0x70], xmm7
00007431745d1c62  vmovaps [rsp+0x80], xmm8
00007431745d1c6b  vmovaps [rsp+0x90], xmm9
00007431745d1c74  vmovaps [rsp+0xA0], xmm10
00007431745d1c7d  vmovaps [rsp+0xB0], xmm11
00007431745d1c86  vmovaps [rsp+0xC0], xmm12
00007431745d1c8f  vmovaps [rsp+0xD0], xmm13
00007431745d1c98  vmovaps [rsp+0xE0], xmm14
00007431745d1ca1  sub rsp, 0x30
00007431745d1ca5  movaps [rsp], xmm15
00007431745d1caa  movaps [rsp+0x10], xmm13
00007431745d1cb0  movaps [rsp+0x20], xmm1
00007431745d1cb5  lea rdi, [rsp]
00007431745d1cb9  mov esi, 0x00
00007431745d1cbe  mov rax, 0x56C40959E530
00007431745d1cc8  call rax
00007431745d1cca  movaps xmm15, [rsp]
00007431745d1ccf  add rsp, 0x30
00007431745d1cd3  vmovaps xmm0, [rsp]
00007431745d1cd8  vmovaps xmm1, [rsp+0x10]
00007431745d1cde  vmovaps xmm2, [rsp+0x20]
00007431745d1ce4  vmovaps xmm3, [rsp+0x30]
00007431745d1cea  vmovaps xmm4, [rsp+0x40]
00007431745d1cf0  vmovaps xmm5, [rsp+0x50]
00007431745d1cf6  vmovaps xmm6, [rsp+0x60]
00007431745d1cfc  vmovaps xmm7, [rsp+0x70]
00007431745d1d02  vmovaps xmm8, [rsp+0x80]
00007431745d1d0b  vmovaps xmm9, [rsp+0x90]
00007431745d1d14  vmovaps xmm10, [rsp+0xA0]
00007431745d1d1d  vmovaps xmm11, [rsp+0xB0]
00007431745d1d26  vmovaps xmm12, [rsp+0xC0]
00007431745d1d2f  vmovaps xmm13, [rsp+0xD0]
00007431745d1d38  vmovaps xmm14, [rsp+0xE0]
00007431745d1d41  add rsp, 0xF0
00007431745d1d48  pop r11
00007431745d1d4a  pop r10
00007431745d1d4c  pop r9
00007431745d1d4e  pop r8
00007431745d1d50  pop rsi
00007431745d1d51  pop rdi
00007431745d1d52  pop rdx
00007431745d1d53  pop rcx
00007431745d1d54  pop rax
00007431745d1d55  add rsp, 0x08
00007431745d1d59  jmp 0x00007431745CFAEB
00007431745d1d5e  call 0x00007431743FF430
00007431745d1d63  jmp 0x00007431745CFAF8
00007431745d1d68  sub rsp, 0x08
00007431745d1d6c  push rax
00007431745d1d6d  push rcx
00007431745d1d6e  push rdx
00007431745d1d6f  push rdi
00007431745d1d70  push rsi
00007431745d1d71  push r8
00007431745d1d73  push r9
00007431745d1d75  push r10
00007431745d1d77  push r11
00007431745d1d79  sub rsp, 0xF0
00007431745d1d80  vmovaps [rsp], xmm0
00007431745d1d85  vmovaps [rsp+0x10], xmm1
00007431745d1d8b  vmovaps [rsp+0x20], xmm2
00007431745d1d91  vmovaps [rsp+0x30], xmm3
00007431745d1d97  vmovaps [rsp+0x40], xmm4
00007431745d1d9d  vmovaps [rsp+0x50], xmm5
00007431745d1da3  vmovaps [rsp+0x60], xmm6
00007431745d1da9  vmovaps [rsp+0x70], xmm7
00007431745d1daf  vmovaps [rsp+0x80], xmm8
00007431745d1db8  vmovaps [rsp+0x90], xmm9
00007431745d1dc1  vmovaps [rsp+0xA0], xmm10
00007431745d1dca  vmovaps [rsp+0xB0], xmm11
00007431745d1dd3  vmovaps [rsp+0xC0], xmm12
00007431745d1ddc  vmovaps [rsp+0xD0], xmm13
00007431745d1de5  vmovaps [rsp+0xE0], xmm15
00007431745d1dee  sub rsp, 0x30
00007431745d1df2  movaps [rsp], xmm14
00007431745d1df7  movaps [rsp+0x10], xmm13
00007431745d1dfd  movaps [rsp+0x20], xmm2
00007431745d1e02  lea rdi, [rsp]
00007431745d1e06  mov esi, 0x00
00007431745d1e0b  mov rax, 0x56C40959E530
00007431745d1e15  call rax
00007431745d1e17  movaps xmm14, [rsp]
00007431745d1e1c  add rsp, 0x30
00007431745d1e20  vmovaps xmm0, [rsp]
00007431745d1e25  vmovaps xmm1, [rsp+0x10]
00007431745d1e2b  vmovaps xmm2, [rsp+0x20]
00007431745d1e31  vmovaps xmm3, [rsp+0x30]
00007431745d1e37  vmovaps xmm4, [rsp+0x40]
00007431745d1e3d  vmovaps xmm5, [rsp+0x50]
00007431745d1e43  vmovaps xmm6, [rsp+0x60]
00007431745d1e49  vmovaps xmm7, [rsp+0x70]
00007431745d1e4f  vmovaps xmm8, [rsp+0x80]
00007431745d1e58  vmovaps xmm9, [rsp+0x90]
00007431745d1e61  vmovaps xmm10, [rsp+0xA0]
00007431745d1e6a  vmovaps xmm11, [rsp+0xB0]
00007431745d1e73  vmovaps xmm12, [rsp+0xC0]
00007431745d1e7c  vmovaps xmm13, [rsp+0xD0]
00007431745d1e85  vmovaps xmm15, [rsp+0xE0]
00007431745d1e8e  add rsp, 0xF0
00007431745d1e95  pop r11
00007431745d1e97  pop r10
00007431745d1e99  pop r9
00007431745d1e9b  pop r8
00007431745d1e9d  pop rsi
00007431745d1e9e  pop rdi
00007431745d1e9f  pop rdx
00007431745d1ea0  pop rcx
00007431745d1ea1  pop rax
00007431745d1ea2  add rsp, 0x08
00007431745d1ea6  jmp 0x00007431745CFB24
00007431745d1eab  sub rsp, 0x08
00007431745d1eaf  push rax
00007431745d1eb0  push rcx
00007431745d1eb1  push rdx
00007431745d1eb2  push rdi
00007431745d1eb3  push rsi
00007431745d1eb4  push r8
00007431745d1eb6  push r9
00007431745d1eb8  push r10
00007431745d1eba  push r11
00007431745d1ebc  sub rsp, 0xF0
00007431745d1ec3  vmovaps [rsp], xmm0
00007431745d1ec8  vmovaps [rsp+0x10], xmm2
00007431745d1ece  vmovaps [rsp+0x20], xmm3
00007431745d1ed4  vmovaps [rsp+0x30], xmm4
00007431745d1eda  vmovaps [rsp+0x40], xmm5
00007431745d1ee0  vmovaps [rsp+0x50], xmm6
00007431745d1ee6  vmovaps [rsp+0x60], xmm7
00007431745d1eec  vmovaps [rsp+0x70], xmm8
00007431745d1ef2  vmovaps [rsp+0x80], xmm9
00007431745d1efb  vmovaps [rsp+0x90], xmm10
00007431745d1f04  vmovaps [rsp+0xA0], xmm11
00007431745d1f0d  vmovaps [rsp+0xB0], xmm12
00007431745d1f16  vmovaps [rsp+0xC0], xmm13
00007431745d1f1f  vmovaps [rsp+0xD0], xmm14
00007431745d1f28  vmovaps [rsp+0xE0], xmm15
00007431745d1f31  sub rsp, 0x30
00007431745d1f35  movaps [rsp], xmm1
00007431745d1f39  movaps [rsp+0x10], xmm13
00007431745d1f3f  movaps [rsp+0x20], xmm2
00007431745d1f44  lea rdi, [rsp]
00007431745d1f48  mov esi, 0x00
00007431745d1f4d  mov rax, 0x56C40959E530
00007431745d1f57  call rax
00007431745d1f59  movaps xmm1, [rsp]
00007431745d1f5d  add rsp, 0x30
00007431745d1f61  vmovaps xmm0, [rsp]
00007431745d1f66  vmovaps xmm2, [rsp+0x10]
00007431745d1f6c  vmovaps xmm3, [rsp+0x20]
00007431745d1f72  vmovaps xmm4, [rsp+0x30]
00007431745d1f78  vmovaps xmm5, [rsp+0x40]
00007431745d1f7e  vmovaps xmm6, [rsp+0x50]
00007431745d1f84  vmovaps xmm7, [rsp+0x60]
00007431745d1f8a  vmovaps xmm8, [rsp+0x70]
00007431745d1f90  vmovaps xmm9, [rsp+0x80]
00007431745d1f99  vmovaps xmm10, [rsp+0x90]
00007431745d1fa2  vmovaps xmm11, [rsp+0xA0]
00007431745d1fab  vmovaps xmm12, [rsp+0xB0]
00007431745d1fb4  vmovaps xmm13, [rsp+0xC0]
00007431745d1fbd  vmovaps xmm14, [rsp+0xD0]
00007431745d1fc6  vmovaps xmm15, [rsp+0xE0]
00007431745d1fcf  add rsp, 0xF0
00007431745d1fd6  pop r11
00007431745d1fd8  pop r10
00007431745d1fda  pop r9
00007431745d1fdc  pop r8
00007431745d1fde  pop rsi
00007431745d1fdf  pop rdi
00007431745d1fe0  pop rdx
00007431745d1fe1  pop rcx
00007431745d1fe2  pop rax
00007431745d1fe3  add rsp, 0x08
00007431745d1fe7  jmp 0x00007431745CFB52
00007431745d1fec  sub rsp, 0x08
00007431745d1ff0  push rax
00007431745d1ff1  push rcx
00007431745d1ff2  push rdx
00007431745d1ff3  push rdi
00007431745d1ff4  push rsi
00007431745d1ff5  push r8
00007431745d1ff7  push r9
00007431745d1ff9  push r10
00007431745d1ffb  push r11
00007431745d1ffd  sub rsp, 0xF0
00007431745d2004  vmovaps [rsp], xmm0
00007431745d2009  vmovaps [rsp+0x10], xmm1
00007431745d200f  vmovaps [rsp+0x20], xmm3
00007431745d2015  vmovaps [rsp+0x30], xmm4
00007431745d201b  vmovaps [rsp+0x40], xmm5
00007431745d2021  vmovaps [rsp+0x50], xmm6
00007431745d2027  vmovaps [rsp+0x60], xmm7
00007431745d202d  vmovaps [rsp+0x70], xmm8
00007431745d2033  vmovaps [rsp+0x80], xmm9
00007431745d203c  vmovaps [rsp+0x90], xmm10
00007431745d2045  vmovaps [rsp+0xA0], xmm11
00007431745d204e  vmovaps [rsp+0xB0], xmm12
00007431745d2057  vmovaps [rsp+0xC0], xmm13
00007431745d2060  vmovaps [rsp+0xD0], xmm14
00007431745d2069  vmovaps [rsp+0xE0], xmm15
00007431745d2072  sub rsp, 0x30
00007431745d2076  movaps [rsp], xmm2
00007431745d207a  movaps [rsp+0x10], xmm1
00007431745d207f  movaps [rsp+0x20], xmm13
00007431745d2085  lea rdi, [rsp]
00007431745d2089  mov esi, 0x00
00007431745d208e  mov rax, 0x56C40959E530
00007431745d2098  call rax
00007431745d209a  movaps xmm2, [rsp]
00007431745d209e  add rsp, 0x30
00007431745d20a2  vmovaps xmm0, [rsp]
00007431745d20a7  vmovaps xmm1, [rsp+0x10]
00007431745d20ad  vmovaps xmm3, [rsp+0x20]
00007431745d20b3  vmovaps xmm4, [rsp+0x30]
00007431745d20b9  vmovaps xmm5, [rsp+0x40]
00007431745d20bf  vmovaps xmm6, [rsp+0x50]
00007431745d20c5  vmovaps xmm7, [rsp+0x60]
00007431745d20cb  vmovaps xmm8, [rsp+0x70]
00007431745d20d1  vmovaps xmm9, [rsp+0x80]
00007431745d20da  vmovaps xmm10, [rsp+0x90]
00007431745d20e3  vmovaps xmm11, [rsp+0xA0]
00007431745d20ec  vmovaps xmm12, [rsp+0xB0]
00007431745d20f5  vmovaps xmm13, [rsp+0xC0]
00007431745d20fe  vmovaps xmm14, [rsp+0xD0]
00007431745d2107  vmovaps xmm15, [rsp+0xE0]
00007431745d2110  add rsp, 0xF0
00007431745d2117  pop r11
00007431745d2119  pop r10
00007431745d211b  pop r9
00007431745d211d  pop r8
00007431745d211f  pop rsi
00007431745d2120  pop rdi
00007431745d2121  pop rdx
00007431745d2122  pop rcx
00007431745d2123  pop rax
00007431745d2124  add rsp, 0x08
00007431745d2128  jmp 0x00007431745CFBAB
00007431745d212d  call 0x00007431743FF430
00007431745d2132  jmp 0x00007431745CFBB8
00007431745d2137  sub rsp, 0x08
00007431745d213b  push rax
00007431745d213c  push rcx
00007431745d213d  push rdx
00007431745d213e  push rdi
00007431745d213f  push rsi
00007431745d2140  push r8
00007431745d2142  push r9
00007431745d2144  push r10
00007431745d2146  push r11
00007431745d2148  sub rsp, 0xF0
00007431745d214f  vmovaps [rsp], xmm0
00007431745d2154  vmovaps [rsp+0x10], xmm1
00007431745d215a  vmovaps [rsp+0x20], xmm2
00007431745d2160  vmovaps [rsp+0x30], xmm3
00007431745d2166  vmovaps [rsp+0x40], xmm4
00007431745d216c  vmovaps [rsp+0x50], xmm5
00007431745d2172  vmovaps [rsp+0x60], xmm6
00007431745d2178  vmovaps [rsp+0x70], xmm7
00007431745d217e  vmovaps [rsp+0x80], xmm8
00007431745d2187  vmovaps [rsp+0x90], xmm9
00007431745d2190  vmovaps [rsp+0xA0], xmm10
00007431745d2199  vmovaps [rsp+0xB0], xmm11
00007431745d21a2  vmovaps [rsp+0xC0], xmm12
00007431745d21ab  vmovaps [rsp+0xD0], xmm13
00007431745d21b4  vmovaps [rsp+0xE0], xmm14
00007431745d21bd  sub rsp, 0x30
00007431745d21c1  movaps [rsp], xmm15
00007431745d21c6  movaps [rsp+0x10], xmm13
00007431745d21cc  movaps [rsp+0x20], xmm1
00007431745d21d1  lea rdi, [rsp]
00007431745d21d5  mov esi, 0x00
00007431745d21da  mov rax, 0x56C40959E530
00007431745d21e4  call rax
00007431745d21e6  movaps xmm15, [rsp]
00007431745d21eb  add rsp, 0x30
00007431745d21ef  vmovaps xmm0, [rsp]
00007431745d21f4  vmovaps xmm1, [rsp+0x10]
00007431745d21fa  vmovaps xmm2, [rsp+0x20]
00007431745d2200  vmovaps xmm3, [rsp+0x30]
00007431745d2206  vmovaps xmm4, [rsp+0x40]
00007431745d220c  vmovaps xmm5, [rsp+0x50]
00007431745d2212  vmovaps xmm6, [rsp+0x60]
00007431745d2218  vmovaps xmm7, [rsp+0x70]
00007431745d221e  vmovaps xmm8, [rsp+0x80]
00007431745d2227  vmovaps xmm9, [rsp+0x90]
00007431745d2230  vmovaps xmm10, [rsp+0xA0]
00007431745d2239  vmovaps xmm11, [rsp+0xB0]
00007431745d2242  vmovaps xmm12, [rsp+0xC0]
00007431745d224b  vmovaps xmm13, [rsp+0xD0]
00007431745d2254  vmovaps xmm14, [rsp+0xE0]
00007431745d225d  add rsp, 0xF0
00007431745d2264  pop r11
00007431745d2266  pop r10
00007431745d2268  pop r9
00007431745d226a  pop r8
00007431745d226c  pop rsi
00007431745d226d  pop rdi
00007431745d226e  pop rdx
00007431745d226f  pop rcx
00007431745d2270  pop rax
00007431745d2271  add rsp, 0x08
00007431745d2275  jmp 0x00007431745CFBF7
00007431745d227a  sub rsp, 0x08
00007431745d227e  push rax
00007431745d227f  push rcx
00007431745d2280  push rdx
00007431745d2281  push rdi
00007431745d2282  push rsi
00007431745d2283  push r8
00007431745d2285  push r9
00007431745d2287  push r10
00007431745d2289  push r11
00007431745d228b  sub rsp, 0xF0
00007431745d2292  vmovaps [rsp], xmm0
00007431745d2297  vmovaps [rsp+0x10], xmm1
00007431745d229d  vmovaps [rsp+0x20], xmm2
00007431745d22a3  vmovaps [rsp+0x30], xmm3
00007431745d22a9  vmovaps [rsp+0x40], xmm4
00007431745d22af  vmovaps [rsp+0x50], xmm5
00007431745d22b5  vmovaps [rsp+0x60], xmm6
00007431745d22bb  vmovaps [rsp+0x70], xmm7
00007431745d22c1  vmovaps [rsp+0x80], xmm8
00007431745d22ca  vmovaps [rsp+0x90], xmm9
00007431745d22d3  vmovaps [rsp+0xA0], xmm10
00007431745d22dc  vmovaps [rsp+0xB0], xmm11
00007431745d22e5  vmovaps [rsp+0xC0], xmm12
00007431745d22ee  vmovaps [rsp+0xD0], xmm13
00007431745d22f7  vmovaps [rsp+0xE0], xmm15
00007431745d2300  sub rsp, 0x30
00007431745d2304  movaps [rsp], xmm14
00007431745d2309  movaps [rsp+0x10], xmm11
00007431745d230f  movaps [rsp+0x20], xmm1
00007431745d2314  lea rdi, [rsp]
00007431745d2318  mov esi, 0x00
00007431745d231d  mov rax, 0x56C40959E530
00007431745d2327  call rax
00007431745d2329  movaps xmm14, [rsp]
00007431745d232e  add rsp, 0x30
00007431745d2332  vmovaps xmm0, [rsp]
00007431745d2337  vmovaps xmm1, [rsp+0x10]
00007431745d233d  vmovaps xmm2, [rsp+0x20]
00007431745d2343  vmovaps xmm3, [rsp+0x30]
00007431745d2349  vmovaps xmm4, [rsp+0x40]
00007431745d234f  vmovaps xmm5, [rsp+0x50]
00007431745d2355  vmovaps xmm6, [rsp+0x60]
00007431745d235b  vmovaps xmm7, [rsp+0x70]
00007431745d2361  vmovaps xmm8, [rsp+0x80]
00007431745d236a  vmovaps xmm9, [rsp+0x90]
00007431745d2373  vmovaps xmm10, [rsp+0xA0]
00007431745d237c  vmovaps xmm11, [rsp+0xB0]
00007431745d2385  vmovaps xmm12, [rsp+0xC0]
00007431745d238e  vmovaps xmm13, [rsp+0xD0]
00007431745d2397  vmovaps xmm15, [rsp+0xE0]
00007431745d23a0  add rsp, 0xF0
00007431745d23a7  pop r11
00007431745d23a9  pop r10
00007431745d23ab  pop r9
00007431745d23ad  pop r8
00007431745d23af  pop rsi
00007431745d23b0  pop rdi
00007431745d23b1  pop rdx
00007431745d23b2  pop rcx
00007431745d23b3  pop rax
00007431745d23b4  add rsp, 0x08
00007431745d23b8  jmp 0x00007431745CFC21
00007431745d23bd  sub rsp, 0x08
00007431745d23c1  push rax
00007431745d23c2  push rcx
00007431745d23c3  push rdx
00007431745d23c4  push rdi
00007431745d23c5  push rsi
00007431745d23c6  push r8
00007431745d23c8  push r9
00007431745d23ca  push r10
00007431745d23cc  push r11
00007431745d23ce  sub rsp, 0xF0
00007431745d23d5  vmovaps [rsp], xmm0
00007431745d23da  vmovaps [rsp+0x10], xmm1
00007431745d23e0  vmovaps [rsp+0x20], xmm2
00007431745d23e6  vmovaps [rsp+0x30], xmm3
00007431745d23ec  vmovaps [rsp+0x40], xmm4
00007431745d23f2  vmovaps [rsp+0x50], xmm5
00007431745d23f8  vmovaps [rsp+0x60], xmm6
00007431745d23fe  vmovaps [rsp+0x70], xmm7
00007431745d2404  vmovaps [rsp+0x80], xmm8
00007431745d240d  vmovaps [rsp+0x90], xmm9
00007431745d2416  vmovaps [rsp+0xA0], xmm10
00007431745d241f  vmovaps [rsp+0xB0], xmm11
00007431745d2428  vmovaps [rsp+0xC0], xmm12
00007431745d2431  vmovaps [rsp+0xD0], xmm14
00007431745d243a  vmovaps [rsp+0xE0], xmm15
00007431745d2443  sub rsp, 0x30
00007431745d2447  movaps [rsp], xmm13
00007431745d244c  movaps [rsp+0x10], xmm11
00007431745d2452  movaps [rsp+0x20], xmm1
00007431745d2457  lea rdi, [rsp]
00007431745d245b  mov esi, 0x00
00007431745d2460  mov rax, 0x56C40959E530
00007431745d246a  call rax
00007431745d246c  movaps xmm13, [rsp]
00007431745d2471  add rsp, 0x30
00007431745d2475  vmovaps xmm0, [rsp]
00007431745d247a  vmovaps xmm1, [rsp+0x10]
00007431745d2480  vmovaps xmm2, [rsp+0x20]
00007431745d2486  vmovaps xmm3, [rsp+0x30]
00007431745d248c  vmovaps xmm4, [rsp+0x40]
00007431745d2492  vmovaps xmm5, [rsp+0x50]
00007431745d2498  vmovaps xmm6, [rsp+0x60]
00007431745d249e  vmovaps xmm7, [rsp+0x70]
00007431745d24a4  vmovaps xmm8, [rsp+0x80]
00007431745d24ad  vmovaps xmm9, [rsp+0x90]
00007431745d24b6  vmovaps xmm10, [rsp+0xA0]
00007431745d24bf  vmovaps xmm11, [rsp+0xB0]
00007431745d24c8  vmovaps xmm12, [rsp+0xC0]
00007431745d24d1  vmovaps xmm14, [rsp+0xD0]
00007431745d24da  vmovaps xmm15, [rsp+0xE0]
00007431745d24e3  add rsp, 0xF0
00007431745d24ea  pop r11
00007431745d24ec  pop r10
00007431745d24ee  pop r9
00007431745d24f0  pop r8
00007431745d24f2  pop rsi
00007431745d24f3  pop rdi
00007431745d24f4  pop rdx
00007431745d24f5  pop rcx
00007431745d24f6  pop rax
00007431745d24f7  add rsp, 0x08
00007431745d24fb  jmp 0x00007431745CFC76
00007431745d2500  call 0x00007431743FF430
00007431745d2505  jmp 0x00007431745CFC83
00007431745d250a  sub rsp, 0x08
00007431745d250e  push rax
00007431745d250f  push rcx
00007431745d2510  push rdx
00007431745d2511  push rdi
00007431745d2512  push rsi
00007431745d2513  push r8
00007431745d2515  push r9
00007431745d2517  push r10
00007431745d2519  push r11
00007431745d251b  sub rsp, 0xF0
00007431745d2522  vmovaps [rsp], xmm0
00007431745d2527  vmovaps [rsp+0x10], xmm1
00007431745d252d  vmovaps [rsp+0x20], xmm2
00007431745d2533  vmovaps [rsp+0x30], xmm3
00007431745d2539  vmovaps [rsp+0x40], xmm4
00007431745d253f  vmovaps [rsp+0x50], xmm5
00007431745d2545  vmovaps [rsp+0x60], xmm6
00007431745d254b  vmovaps [rsp+0x70], xmm7
00007431745d2551  vmovaps [rsp+0x80], xmm8
00007431745d255a  vmovaps [rsp+0x90], xmm9
00007431745d2563  vmovaps [rsp+0xA0], xmm10
00007431745d256c  vmovaps [rsp+0xB0], xmm11
00007431745d2575  vmovaps [rsp+0xC0], xmm12
00007431745d257e  vmovaps [rsp+0xD0], xmm13
00007431745d2587  vmovaps [rsp+0xE0], xmm14
00007431745d2590  sub rsp, 0x30
00007431745d2594  movaps [rsp], xmm15
00007431745d2599  movaps [rsp+0x10], xmm11
00007431745d259f  movaps [rsp+0x20], xmm1
00007431745d25a4  lea rdi, [rsp]
00007431745d25a8  mov esi, 0x00
00007431745d25ad  mov rax, 0x56C40959E530
00007431745d25b7  call rax
00007431745d25b9  movaps xmm15, [rsp]
00007431745d25be  add rsp, 0x30
00007431745d25c2  vmovaps xmm0, [rsp]
00007431745d25c7  vmovaps xmm1, [rsp+0x10]
00007431745d25cd  vmovaps xmm2, [rsp+0x20]
00007431745d25d3  vmovaps xmm3, [rsp+0x30]
00007431745d25d9  vmovaps xmm4, [rsp+0x40]
00007431745d25df  vmovaps xmm5, [rsp+0x50]
00007431745d25e5  vmovaps xmm6, [rsp+0x60]
00007431745d25eb  vmovaps xmm7, [rsp+0x70]
00007431745d25f1  vmovaps xmm8, [rsp+0x80]
00007431745d25fa  vmovaps xmm9, [rsp+0x90]
00007431745d2603  vmovaps xmm10, [rsp+0xA0]
00007431745d260c  vmovaps xmm11, [rsp+0xB0]
00007431745d2615  vmovaps xmm12, [rsp+0xC0]
00007431745d261e  vmovaps xmm13, [rsp+0xD0]
00007431745d2627  vmovaps xmm14, [rsp+0xE0]
00007431745d2630  add rsp, 0xF0
00007431745d2637  pop r11
00007431745d2639  pop r10
00007431745d263b  pop r9
00007431745d263d  pop r8
00007431745d263f  pop rsi
00007431745d2640  pop rdi
00007431745d2641  pop rdx
00007431745d2642  pop rcx
00007431745d2643  pop rax
00007431745d2644  add rsp, 0x08
00007431745d2648  jmp 0x00007431745CFCBC
00007431745d264d  sub rsp, 0x08
00007431745d2651  push rax
00007431745d2652  push rcx
00007431745d2653  push rdx
00007431745d2654  push rdi
00007431745d2655  push rsi
00007431745d2656  push r8
00007431745d2658  push r9
00007431745d265a  push r10
00007431745d265c  push r11
00007431745d265e  sub rsp, 0xF0
00007431745d2665  vmovaps [rsp], xmm0
00007431745d266a  vmovaps [rsp+0x10], xmm1
00007431745d2670  vmovaps [rsp+0x20], xmm2
00007431745d2676  vmovaps [rsp+0x30], xmm3
00007431745d267c  vmovaps [rsp+0x40], xmm4
00007431745d2682  vmovaps [rsp+0x50], xmm5
00007431745d2688  vmovaps [rsp+0x60], xmm6
00007431745d268e  vmovaps [rsp+0x70], xmm7
00007431745d2694  vmovaps [rsp+0x80], xmm8
00007431745d269d  vmovaps [rsp+0x90], xmm9
00007431745d26a6  vmovaps [rsp+0xA0], xmm10
00007431745d26af  vmovaps [rsp+0xB0], xmm12
00007431745d26b8  vmovaps [rsp+0xC0], xmm13
00007431745d26c1  vmovaps [rsp+0xD0], xmm14
00007431745d26ca  vmovaps [rsp+0xE0], xmm15
00007431745d26d3  sub rsp, 0x30
00007431745d26d7  movaps [rsp], xmm11
00007431745d26dc  movaps [rsp+0x10], xmm6
00007431745d26e1  movaps [rsp+0x20], xmm14
00007431745d26e7  lea rdi, [rsp]
00007431745d26eb  mov esi, 0x00
00007431745d26f0  mov rax, 0x56C40959E530
00007431745d26fa  call rax
00007431745d26fc  movaps xmm11, [rsp]
00007431745d2701  add rsp, 0x30
00007431745d2705  vmovaps xmm0, [rsp]
00007431745d270a  vmovaps xmm1, [rsp+0x10]
00007431745d2710  vmovaps xmm2, [rsp+0x20]
00007431745d2716  vmovaps xmm3, [rsp+0x30]
00007431745d271c  vmovaps xmm4, [rsp+0x40]
00007431745d2722  vmovaps xmm5, [rsp+0x50]
00007431745d2728  vmovaps xmm6, [rsp+0x60]
00007431745d272e  vmovaps xmm7, [rsp+0x70]
00007431745d2734  vmovaps xmm8, [rsp+0x80]
00007431745d273d  vmovaps xmm9, [rsp+0x90]
00007431745d2746  vmovaps xmm10, [rsp+0xA0]
00007431745d274f  vmovaps xmm12, [rsp+0xB0]
00007431745d2758  vmovaps xmm13, [rsp+0xC0]
00007431745d2761  vmovaps xmm14, [rsp+0xD0]
00007431745d276a  vmovaps xmm15, [rsp+0xE0]
00007431745d2773  add rsp, 0xF0
00007431745d277a  pop r11
00007431745d277c  pop r10
00007431745d277e  pop r9
00007431745d2780  pop r8
00007431745d2782  pop rsi
00007431745d2783  pop rdi
00007431745d2784  pop rdx
00007431745d2785  pop rcx
00007431745d2786  pop rax
00007431745d2787  add rsp, 0x08
00007431745d278b  jmp 0x00007431745CFD34
00007431745d2790  call 0x00007431743FF430
00007431745d2795  jmp 0x00007431745CFD3E
00007431745d279a  sub rsp, 0x08
00007431745d279e  push rax
00007431745d279f  push rcx
00007431745d27a0  push rdx
00007431745d27a1  push rdi
00007431745d27a2  push rsi
00007431745d27a3  push r8
00007431745d27a5  push r9
00007431745d27a7  push r10
00007431745d27a9  push r11
00007431745d27ab  sub rsp, 0xF0
00007431745d27b2  vmovaps [rsp], xmm0
00007431745d27b7  vmovaps [rsp+0x10], xmm1
00007431745d27bd  vmovaps [rsp+0x20], xmm2
00007431745d27c3  vmovaps [rsp+0x30], xmm3
00007431745d27c9  vmovaps [rsp+0x40], xmm4
00007431745d27cf  vmovaps [rsp+0x50], xmm5
00007431745d27d5  vmovaps [rsp+0x60], xmm6
00007431745d27db  vmovaps [rsp+0x70], xmm7
00007431745d27e1  vmovaps [rsp+0x80], xmm8
00007431745d27ea  vmovaps [rsp+0x90], xmm9
00007431745d27f3  vmovaps [rsp+0xA0], xmm10
00007431745d27fc  vmovaps [rsp+0xB0], xmm11
00007431745d2805  vmovaps [rsp+0xC0], xmm12
00007431745d280e  vmovaps [rsp+0xD0], xmm13
00007431745d2817  vmovaps [rsp+0xE0], xmm15
00007431745d2820  sub rsp, 0x30
00007431745d2824  movaps [rsp], xmm14
00007431745d2829  movaps [rsp+0x10], xmm6
00007431745d282e  movaps [rsp+0x20], xmm2
00007431745d2833  lea rdi, [rsp]
00007431745d2837  mov esi, 0x00
00007431745d283c  mov rax, 0x56C40959E530
00007431745d2846  call rax
00007431745d2848  movaps xmm14, [rsp]
00007431745d284d  add rsp, 0x30
00007431745d2851  vmovaps xmm0, [rsp]
00007431745d2856  vmovaps xmm1, [rsp+0x10]
00007431745d285c  vmovaps xmm2, [rsp+0x20]
00007431745d2862  vmovaps xmm3, [rsp+0x30]
00007431745d2868  vmovaps xmm4, [rsp+0x40]
00007431745d286e  vmovaps xmm5, [rsp+0x50]
00007431745d2874  vmovaps xmm6, [rsp+0x60]
00007431745d287a  vmovaps xmm7, [rsp+0x70]
00007431745d2880  vmovaps xmm8, [rsp+0x80]
00007431745d2889  vmovaps xmm9, [rsp+0x90]
00007431745d2892  vmovaps xmm10, [rsp+0xA0]
00007431745d289b  vmovaps xmm11, [rsp+0xB0]
00007431745d28a4  vmovaps xmm12, [rsp+0xC0]
00007431745d28ad  vmovaps xmm13, [rsp+0xD0]
00007431745d28b6  vmovaps xmm15, [rsp+0xE0]
00007431745d28bf  add rsp, 0xF0
00007431745d28c6  pop r11
00007431745d28c8  pop r10
00007431745d28ca  pop r9
00007431745d28cc  pop r8
00007431745d28ce  pop rsi
00007431745d28cf  pop rdi
00007431745d28d0  pop rdx
00007431745d28d1  pop rcx
00007431745d28d2  pop rax
00007431745d28d3  add rsp, 0x08
00007431745d28d7  jmp 0x00007431745CFD72
00007431745d28dc  sub rsp, 0x08
00007431745d28e0  push rax
00007431745d28e1  push rcx
00007431745d28e2  push rdx
00007431745d28e3  push rdi
00007431745d28e4  push rsi
00007431745d28e5  push r8
00007431745d28e7  push r9
00007431745d28e9  push r10
00007431745d28eb  push r11
00007431745d28ed  sub rsp, 0xF0
00007431745d28f4  vmovaps [rsp], xmm0
00007431745d28f9  vmovaps [rsp+0x10], xmm1
00007431745d28ff  vmovaps [rsp+0x20], xmm2
00007431745d2905  vmovaps [rsp+0x30], xmm3
00007431745d290b  vmovaps [rsp+0x40], xmm4
00007431745d2911  vmovaps [rsp+0x50], xmm5
00007431745d2917  vmovaps [rsp+0x60], xmm7
00007431745d291d  vmovaps [rsp+0x70], xmm8
00007431745d2923  vmovaps [rsp+0x80], xmm9
00007431745d292c  vmovaps [rsp+0x90], xmm10
00007431745d2935  vmovaps [rsp+0xA0], xmm11
00007431745d293e  vmovaps [rsp+0xB0], xmm12
00007431745d2947  vmovaps [rsp+0xC0], xmm13
00007431745d2950  vmovaps [rsp+0xD0], xmm14
00007431745d2959  vmovaps [rsp+0xE0], xmm15
00007431745d2962  sub rsp, 0x30
00007431745d2966  movaps [rsp], xmm6
00007431745d296a  movaps [rsp+0x10], xmm5
00007431745d296f  movaps [rsp+0x20], xmm1
00007431745d2974  lea rdi, [rsp]
00007431745d2978  mov esi, 0x00
00007431745d297d  mov rax, 0x56C40959E530
00007431745d2987  call rax
00007431745d2989  movaps xmm6, [rsp]
00007431745d298d  add rsp, 0x30
00007431745d2991  vmovaps xmm0, [rsp]
00007431745d2996  vmovaps xmm1, [rsp+0x10]
00007431745d299c  vmovaps xmm2, [rsp+0x20]
00007431745d29a2  vmovaps xmm3, [rsp+0x30]
00007431745d29a8  vmovaps xmm4, [rsp+0x40]
00007431745d29ae  vmovaps xmm5, [rsp+0x50]
00007431745d29b4  vmovaps xmm7, [rsp+0x60]
00007431745d29ba  vmovaps xmm8, [rsp+0x70]
00007431745d29c0  vmovaps xmm9, [rsp+0x80]
00007431745d29c9  vmovaps xmm10, [rsp+0x90]
00007431745d29d2  vmovaps xmm11, [rsp+0xA0]
00007431745d29db  vmovaps xmm12, [rsp+0xB0]
00007431745d29e4  vmovaps xmm13, [rsp+0xC0]
00007431745d29ed  vmovaps xmm14, [rsp+0xD0]
00007431745d29f6  vmovaps xmm15, [rsp+0xE0]
00007431745d29ff  add rsp, 0xF0
00007431745d2a06  pop r11
00007431745d2a08  pop r10
00007431745d2a0a  pop r9
00007431745d2a0c  pop r8
00007431745d2a0e  pop rsi
00007431745d2a0f  pop rdi
00007431745d2a10  pop rdx
00007431745d2a11  pop rcx
00007431745d2a12  pop rax
00007431745d2a13  add rsp, 0x08
00007431745d2a17  jmp 0x00007431745CFD98
00007431745d2a1c  sub rsp, 0x08
00007431745d2a20  push rax
00007431745d2a21  push rcx
00007431745d2a22  push rdx
00007431745d2a23  push rdi
00007431745d2a24  push rsi
00007431745d2a25  push r8
00007431745d2a27  push r9
00007431745d2a29  push r10
00007431745d2a2b  push r11
00007431745d2a2d  sub rsp, 0xF0
00007431745d2a34  vmovaps [rsp], xmm0
00007431745d2a39  vmovaps [rsp+0x10], xmm2
00007431745d2a3f  vmovaps [rsp+0x20], xmm3
00007431745d2a45  vmovaps [rsp+0x30], xmm4
00007431745d2a4b  vmovaps [rsp+0x40], xmm5
00007431745d2a51  vmovaps [rsp+0x50], xmm6
00007431745d2a57  vmovaps [rsp+0x60], xmm7
00007431745d2a5d  vmovaps [rsp+0x70], xmm8
00007431745d2a63  vmovaps [rsp+0x80], xmm9
00007431745d2a6c  vmovaps [rsp+0x90], xmm10
00007431745d2a75  vmovaps [rsp+0xA0], xmm11
00007431745d2a7e  vmovaps [rsp+0xB0], xmm12
00007431745d2a87  vmovaps [rsp+0xC0], xmm13
00007431745d2a90  vmovaps [rsp+0xD0], xmm14
00007431745d2a99  vmovaps [rsp+0xE0], xmm15
00007431745d2aa2  sub rsp, 0x30
00007431745d2aa6  movaps [rsp], xmm1
00007431745d2aaa  movaps [rsp+0x10], xmm5
00007431745d2aaf  movaps [rsp+0x20], xmm13
00007431745d2ab5  lea rdi, [rsp]
00007431745d2ab9  mov esi, 0x00
00007431745d2abe  mov rax, 0x56C40959E530
00007431745d2ac8  call rax
00007431745d2aca  movaps xmm1, [rsp]
00007431745d2ace  add rsp, 0x30
00007431745d2ad2  vmovaps xmm0, [rsp]
00007431745d2ad7  vmovaps xmm2, [rsp+0x10]
00007431745d2add  vmovaps xmm3, [rsp+0x20]
00007431745d2ae3  vmovaps xmm4, [rsp+0x30]
00007431745d2ae9  vmovaps xmm5, [rsp+0x40]
00007431745d2aef  vmovaps xmm6, [rsp+0x50]
00007431745d2af5  vmovaps xmm7, [rsp+0x60]
00007431745d2afb  vmovaps xmm8, [rsp+0x70]
00007431745d2b01  vmovaps xmm9, [rsp+0x80]
00007431745d2b0a  vmovaps xmm10, [rsp+0x90]
00007431745d2b13  vmovaps xmm11, [rsp+0xA0]
00007431745d2b1c  vmovaps xmm12, [rsp+0xB0]
00007431745d2b25  vmovaps xmm13, [rsp+0xC0]
00007431745d2b2e  vmovaps xmm14, [rsp+0xD0]
00007431745d2b37  vmovaps xmm15, [rsp+0xE0]
00007431745d2b40  add rsp, 0xF0
00007431745d2b47  pop r11
00007431745d2b49  pop r10
00007431745d2b4b  pop r9
00007431745d2b4d  pop r8
00007431745d2b4f  pop rsi
00007431745d2b50  pop rdi
00007431745d2b51  pop rdx
00007431745d2b52  pop rcx
00007431745d2b53  pop rax
00007431745d2b54  add rsp, 0x08
00007431745d2b58  jmp 0x00007431745CFDB6
00007431745d2b5d  sub rsp, 0x08
00007431745d2b61  push rax
00007431745d2b62  push rcx
00007431745d2b63  push rdx
00007431745d2b64  push rdi
00007431745d2b65  push rsi
00007431745d2b66  push r8
00007431745d2b68  push r9
00007431745d2b6a  push r10
00007431745d2b6c  push r11
00007431745d2b6e  sub rsp, 0xF0
00007431745d2b75  vmovaps [rsp], xmm0
00007431745d2b7a  vmovaps [rsp+0x10], xmm1
00007431745d2b80  vmovaps [rsp+0x20], xmm2
00007431745d2b86  vmovaps [rsp+0x30], xmm3
00007431745d2b8c  vmovaps [rsp+0x40], xmm4
00007431745d2b92  vmovaps [rsp+0x50], xmm6
00007431745d2b98  vmovaps [rsp+0x60], xmm7
00007431745d2b9e  vmovaps [rsp+0x70], xmm8
00007431745d2ba4  vmovaps [rsp+0x80], xmm9
00007431745d2bad  vmovaps [rsp+0x90], xmm10
00007431745d2bb6  vmovaps [rsp+0xA0], xmm11
00007431745d2bbf  vmovaps [rsp+0xB0], xmm12
00007431745d2bc8  vmovaps [rsp+0xC0], xmm13
00007431745d2bd1  vmovaps [rsp+0xD0], xmm14
00007431745d2bda  vmovaps [rsp+0xE0], xmm15
00007431745d2be3  sub rsp, 0x30
00007431745d2be7  movaps [rsp], xmm5
00007431745d2beb  movaps [rsp+0x10], xmm2
00007431745d2bf0  movaps [rsp+0x20], xmm13
00007431745d2bf6  lea rdi, [rsp]
00007431745d2bfa  mov esi, 0x00
00007431745d2bff  mov rax, 0x56C40959E530
00007431745d2c09  call rax
00007431745d2c0b  movaps xmm5, [rsp]
00007431745d2c0f  add rsp, 0x30
00007431745d2c13  vmovaps xmm0, [rsp]
00007431745d2c18  vmovaps xmm1, [rsp+0x10]
00007431745d2c1e  vmovaps xmm2, [rsp+0x20]
00007431745d2c24  vmovaps xmm3, [rsp+0x30]
00007431745d2c2a  vmovaps xmm4, [rsp+0x40]
00007431745d2c30  vmovaps xmm6, [rsp+0x50]
00007431745d2c36  vmovaps xmm7, [rsp+0x60]
00007431745d2c3c  vmovaps xmm8, [rsp+0x70]
00007431745d2c42  vmovaps xmm9, [rsp+0x80]
00007431745d2c4b  vmovaps xmm10, [rsp+0x90]
00007431745d2c54  vmovaps xmm11, [rsp+0xA0]
00007431745d2c5d  vmovaps xmm12, [rsp+0xB0]
00007431745d2c66  vmovaps xmm13, [rsp+0xC0]
00007431745d2c6f  vmovaps xmm14, [rsp+0xD0]
00007431745d2c78  vmovaps xmm15, [rsp+0xE0]
00007431745d2c81  add rsp, 0xF0
00007431745d2c88  pop r11
00007431745d2c8a  pop r10
00007431745d2c8c  pop r9
00007431745d2c8e  pop r8
00007431745d2c90  pop rsi
00007431745d2c91  pop rdi
00007431745d2c92  pop rdx
00007431745d2c93  pop rcx
00007431745d2c94  pop rax
00007431745d2c95  add rsp, 0x08
00007431745d2c99  jmp 0x00007431745CFDEC
00007431745d2c9e  sub rsp, 0x08
00007431745d2ca2  push rax
00007431745d2ca3  push rcx
00007431745d2ca4  push rdx
00007431745d2ca5  push rdi
00007431745d2ca6  push rsi
00007431745d2ca7  push r8
00007431745d2ca9  push r9
00007431745d2cab  push r10
00007431745d2cad  push r11
00007431745d2caf  sub rsp, 0xF0
00007431745d2cb6  vmovaps [rsp], xmm0
00007431745d2cbb  vmovaps [rsp+0x10], xmm1
00007431745d2cc1  vmovaps [rsp+0x20], xmm2
00007431745d2cc7  vmovaps [rsp+0x30], xmm3
00007431745d2ccd  vmovaps [rsp+0x40], xmm4
00007431745d2cd3  vmovaps [rsp+0x50], xmm5
00007431745d2cd9  vmovaps [rsp+0x60], xmm6
00007431745d2cdf  vmovaps [rsp+0x70], xmm7
00007431745d2ce5  vmovaps [rsp+0x80], xmm8
00007431745d2cee  vmovaps [rsp+0x90], xmm9
00007431745d2cf7  vmovaps [rsp+0xA0], xmm10
00007431745d2d00  vmovaps [rsp+0xB0], xmm11
00007431745d2d09  vmovaps [rsp+0xC0], xmm12
00007431745d2d12  vmovaps [rsp+0xD0], xmm14
00007431745d2d1b  vmovaps [rsp+0xE0], xmm15
00007431745d2d24  sub rsp, 0x30
00007431745d2d28  movaps [rsp], xmm13
00007431745d2d2d  movaps [rsp+0x10], xmm10
00007431745d2d33  movaps [rsp+0x20], xmm1
00007431745d2d38  lea rdi, [rsp]
00007431745d2d3c  mov esi, 0x00
00007431745d2d41  mov rax, 0x56C40959E530
00007431745d2d4b  call rax
00007431745d2d4d  movaps xmm13, [rsp]
00007431745d2d52  add rsp, 0x30
00007431745d2d56  vmovaps xmm0, [rsp]
00007431745d2d5b  vmovaps xmm1, [rsp+0x10]
00007431745d2d61  vmovaps xmm2, [rsp+0x20]
00007431745d2d67  vmovaps xmm3, [rsp+0x30]
00007431745d2d6d  vmovaps xmm4, [rsp+0x40]
00007431745d2d73  vmovaps xmm5, [rsp+0x50]
00007431745d2d79  vmovaps xmm6, [rsp+0x60]
00007431745d2d7f  vmovaps xmm7, [rsp+0x70]
00007431745d2d85  vmovaps xmm8, [rsp+0x80]
00007431745d2d8e  vmovaps xmm9, [rsp+0x90]
00007431745d2d97  vmovaps xmm10, [rsp+0xA0]
00007431745d2da0  vmovaps xmm11, [rsp+0xB0]
00007431745d2da9  vmovaps xmm12, [rsp+0xC0]
00007431745d2db2  vmovaps xmm14, [rsp+0xD0]
00007431745d2dbb  vmovaps xmm15, [rsp+0xE0]
00007431745d2dc4  add rsp, 0xF0
00007431745d2dcb  pop r11
00007431745d2dcd  pop r10
00007431745d2dcf  pop r9
00007431745d2dd1  pop r8
00007431745d2dd3  pop rsi
00007431745d2dd4  pop rdi
00007431745d2dd5  pop rdx
00007431745d2dd6  pop rcx
00007431745d2dd7  pop rax
00007431745d2dd8  add rsp, 0x08
00007431745d2ddc  jmp 0x00007431745CFE15
00007431745d2de1  sub rsp, 0x08
00007431745d2de5  push rax
00007431745d2de6  push rcx
00007431745d2de7  push rdx
00007431745d2de8  push rdi
00007431745d2de9  push rsi
00007431745d2dea  push r8
00007431745d2dec  push r9
00007431745d2dee  push r10
00007431745d2df0  push r11
00007431745d2df2  sub rsp, 0xF0
00007431745d2df9  vmovaps [rsp], xmm0
00007431745d2dfe  vmovaps [rsp+0x10], xmm2
00007431745d2e04  vmovaps [rsp+0x20], xmm3
00007431745d2e0a  vmovaps [rsp+0x30], xmm4
00007431745d2e10  vmovaps [rsp+0x40], xmm5
00007431745d2e16  vmovaps [rsp+0x50], xmm6
00007431745d2e1c  vmovaps [rsp+0x60], xmm7
00007431745d2e22  vmovaps [rsp+0x70], xmm8
00007431745d2e28  vmovaps [rsp+0x80], xmm9
00007431745d2e31  vmovaps [rsp+0x90], xmm10
00007431745d2e3a  vmovaps [rsp+0xA0], xmm11
00007431745d2e43  vmovaps [rsp+0xB0], xmm12
00007431745d2e4c  vmovaps [rsp+0xC0], xmm13
00007431745d2e55  vmovaps [rsp+0xD0], xmm14
00007431745d2e5e  vmovaps [rsp+0xE0], xmm15
00007431745d2e67  sub rsp, 0x30
00007431745d2e6b  movaps [rsp], xmm1
00007431745d2e6f  movaps [rsp+0x10], xmm15
00007431745d2e75  movaps [rsp+0x20], xmm10
00007431745d2e7b  lea rdi, [rsp]
00007431745d2e7f  mov esi, 0x00
00007431745d2e84  mov rax, 0x56C40959E530
00007431745d2e8e  call rax
00007431745d2e90  movaps xmm1, [rsp]
00007431745d2e94  add rsp, 0x30
00007431745d2e98  vmovaps xmm0, [rsp]
00007431745d2e9d  vmovaps xmm2, [rsp+0x10]
00007431745d2ea3  vmovaps xmm3, [rsp+0x20]
00007431745d2ea9  vmovaps xmm4, [rsp+0x30]
00007431745d2eaf  vmovaps xmm5, [rsp+0x40]
00007431745d2eb5  vmovaps xmm6, [rsp+0x50]
00007431745d2ebb  vmovaps xmm7, [rsp+0x60]
00007431745d2ec1  vmovaps xmm8, [rsp+0x70]
00007431745d2ec7  vmovaps xmm9, [rsp+0x80]
00007431745d2ed0  vmovaps xmm10, [rsp+0x90]
00007431745d2ed9  vmovaps xmm11, [rsp+0xA0]
00007431745d2ee2  vmovaps xmm12, [rsp+0xB0]
00007431745d2eeb  vmovaps xmm13, [rsp+0xC0]
00007431745d2ef4  vmovaps xmm14, [rsp+0xD0]
00007431745d2efd  vmovaps xmm15, [rsp+0xE0]
00007431745d2f06  add rsp, 0xF0
00007431745d2f0d  pop r11
00007431745d2f0f  pop r10
00007431745d2f11  pop r9
00007431745d2f13  pop r8
00007431745d2f15  pop rsi
00007431745d2f16  pop rdi
00007431745d2f17  pop rdx
00007431745d2f18  pop rcx
00007431745d2f19  pop rax
00007431745d2f1a  add rsp, 0x08
00007431745d2f1e  jmp 0x00007431745CFE34
00007431745d2f23  sub rsp, 0x08
00007431745d2f27  push rax
00007431745d2f28  push rcx
00007431745d2f29  push rdx
00007431745d2f2a  push rdi
00007431745d2f2b  push rsi
00007431745d2f2c  push r8
00007431745d2f2e  push r9
00007431745d2f30  push r10
00007431745d2f32  push r11
00007431745d2f34  sub rsp, 0xF0
00007431745d2f3b  vmovaps [rsp], xmm0
00007431745d2f40  vmovaps [rsp+0x10], xmm1
00007431745d2f46  vmovaps [rsp+0x20], xmm2
00007431745d2f4c  vmovaps [rsp+0x30], xmm3
00007431745d2f52  vmovaps [rsp+0x40], xmm4
00007431745d2f58  vmovaps [rsp+0x50], xmm5
00007431745d2f5e  vmovaps [rsp+0x60], xmm6
00007431745d2f64  vmovaps [rsp+0x70], xmm7
00007431745d2f6a  vmovaps [rsp+0x80], xmm8
00007431745d2f73  vmovaps [rsp+0x90], xmm9
00007431745d2f7c  vmovaps [rsp+0xA0], xmm10
00007431745d2f85  vmovaps [rsp+0xB0], xmm11
00007431745d2f8e  vmovaps [rsp+0xC0], xmm12
00007431745d2f97  vmovaps [rsp+0xD0], xmm13
00007431745d2fa0  vmovaps [rsp+0xE0], xmm14
00007431745d2fa9  sub rsp, 0x30
00007431745d2fad  movaps [rsp], xmm15
00007431745d2fb2  movaps [rsp+0x10], xmm10
00007431745d2fb8  movaps [rsp+0x20], xmm11
00007431745d2fbe  lea rdi, [rsp]
00007431745d2fc2  mov esi, 0x00
00007431745d2fc7  mov rax, 0x56C40959E530
00007431745d2fd1  call rax
00007431745d2fd3  movaps xmm15, [rsp]
00007431745d2fd8  add rsp, 0x30
00007431745d2fdc  vmovaps xmm0, [rsp]
00007431745d2fe1  vmovaps xmm1, [rsp+0x10]
00007431745d2fe7  vmovaps xmm2, [rsp+0x20]
00007431745d2fed  vmovaps xmm3, [rsp+0x30]
00007431745d2ff3  vmovaps xmm4, [rsp+0x40]
00007431745d2ff9  vmovaps xmm5, [rsp+0x50]
00007431745d2fff  vmovaps xmm6, [rsp+0x60]
00007431745d3005  vmovaps xmm7, [rsp+0x70]
00007431745d300b  vmovaps xmm8, [rsp+0x80]
00007431745d3014  vmovaps xmm9, [rsp+0x90]
00007431745d301d  vmovaps xmm10, [rsp+0xA0]
00007431745d3026  vmovaps xmm11, [rsp+0xB0]
00007431745d302f  vmovaps xmm12, [rsp+0xC0]
00007431745d3038  vmovaps xmm13, [rsp+0xD0]
00007431745d3041  vmovaps xmm14, [rsp+0xE0]
00007431745d304a  add rsp, 0xF0
00007431745d3051  pop r11
00007431745d3053  pop r10
00007431745d3055  pop r9
00007431745d3057  pop r8
00007431745d3059  pop rsi
00007431745d305a  pop rdi
00007431745d305b  pop rdx
00007431745d305c  pop rcx
00007431745d305d  pop rax
00007431745d305e  add rsp, 0x08
00007431745d3062  jmp 0x00007431745CFE57
00007431745d3067  sub rsp, 0x08
00007431745d306b  push rax
00007431745d306c  push rcx
00007431745d306d  push rdx
00007431745d306e  push rdi
00007431745d306f  push rsi
00007431745d3070  push r8
00007431745d3072  push r9
00007431745d3074  push r10
00007431745d3076  push r11
00007431745d3078  sub rsp, 0xF0
00007431745d307f  vmovaps [rsp], xmm0
00007431745d3084  vmovaps [rsp+0x10], xmm1
00007431745d308a  vmovaps [rsp+0x20], xmm2
00007431745d3090  vmovaps [rsp+0x30], xmm3
00007431745d3096  vmovaps [rsp+0x40], xmm4
00007431745d309c  vmovaps [rsp+0x50], xmm5
00007431745d30a2  vmovaps [rsp+0x60], xmm6
00007431745d30a8  vmovaps [rsp+0x70], xmm7
00007431745d30ae  vmovaps [rsp+0x80], xmm8
00007431745d30b7  vmovaps [rsp+0x90], xmm9
00007431745d30c0  vmovaps [rsp+0xA0], xmm11
00007431745d30c9  vmovaps [rsp+0xB0], xmm12
00007431745d30d2  vmovaps [rsp+0xC0], xmm13
00007431745d30db  vmovaps [rsp+0xD0], xmm14
00007431745d30e4  vmovaps [rsp+0xE0], xmm15
00007431745d30ed  sub rsp, 0x30
00007431745d30f1  movaps [rsp], xmm10
00007431745d30f6  movaps [rsp+0x10], xmm12
00007431745d30fc  movaps [rsp+0x20], xmm11
00007431745d3102  lea rdi, [rsp]
00007431745d3106  mov esi, 0x00
00007431745d310b  mov rax, 0x56C40959E530
00007431745d3115  call rax
00007431745d3117  movaps xmm10, [rsp]
00007431745d311c  add rsp, 0x30
00007431745d3120  vmovaps xmm0, [rsp]
00007431745d3125  vmovaps xmm1, [rsp+0x10]
00007431745d312b  vmovaps xmm2, [rsp+0x20]
00007431745d3131  vmovaps xmm3, [rsp+0x30]
00007431745d3137  vmovaps xmm4, [rsp+0x40]
00007431745d313d  vmovaps xmm5, [rsp+0x50]
00007431745d3143  vmovaps xmm6, [rsp+0x60]
00007431745d3149  vmovaps xmm7, [rsp+0x70]
00007431745d314f  vmovaps xmm8, [rsp+0x80]
00007431745d3158  vmovaps xmm9, [rsp+0x90]
00007431745d3161  vmovaps xmm11, [rsp+0xA0]
00007431745d316a  vmovaps xmm12, [rsp+0xB0]
00007431745d3173  vmovaps xmm13, [rsp+0xC0]
00007431745d317c  vmovaps xmm14, [rsp+0xD0]
00007431745d3185  vmovaps xmm15, [rsp+0xE0]
00007431745d318e  add rsp, 0xF0
00007431745d3195  pop r11
00007431745d3197  pop r10
00007431745d3199  pop r9
00007431745d319b  pop r8
00007431745d319d  pop rsi
00007431745d319e  pop rdi
00007431745d319f  pop rdx
00007431745d31a0  pop rcx
00007431745d31a1  pop rax
00007431745d31a2  add rsp, 0x08
00007431745d31a6  jmp 0x00007431745CFE80
00007431745d31ab  sub rsp, 0x08
00007431745d31af  push rax
00007431745d31b0  push rcx
00007431745d31b1  push rdx
00007431745d31b2  push rdi
00007431745d31b3  push rsi
00007431745d31b4  push r8
00007431745d31b6  push r9
00007431745d31b8  push r10
00007431745d31ba  push r11
00007431745d31bc  sub rsp, 0xF0
00007431745d31c3  vmovaps [rsp], xmm0
00007431745d31c8  vmovaps [rsp+0x10], xmm1
00007431745d31ce  vmovaps [rsp+0x20], xmm2
00007431745d31d4  vmovaps [rsp+0x30], xmm3
00007431745d31da  vmovaps [rsp+0x40], xmm4
00007431745d31e0  vmovaps [rsp+0x50], xmm5
00007431745d31e6  vmovaps [rsp+0x60], xmm6
00007431745d31ec  vmovaps [rsp+0x70], xmm7
00007431745d31f2  vmovaps [rsp+0x80], xmm8
00007431745d31fb  vmovaps [rsp+0x90], xmm9
00007431745d3204  vmovaps [rsp+0xA0], xmm10
00007431745d320d  vmovaps [rsp+0xB0], xmm12
00007431745d3216  vmovaps [rsp+0xC0], xmm13
00007431745d321f  vmovaps [rsp+0xD0], xmm14
00007431745d3228  vmovaps [rsp+0xE0], xmm15
00007431745d3231  sub rsp, 0x30
00007431745d3235  movaps [rsp], xmm11
00007431745d323a  movaps [rsp+0x10], xmm2
00007431745d323f  movaps [rsp+0x20], xmm12
00007431745d3245  lea rdi, [rsp]
00007431745d3249  mov esi, 0x00
00007431745d324e  mov rax, 0x56C40959E530
00007431745d3258  call rax
00007431745d325a  movaps xmm11, [rsp]
00007431745d325f  add rsp, 0x30
00007431745d3263  vmovaps xmm0, [rsp]
00007431745d3268  vmovaps xmm1, [rsp+0x10]
00007431745d326e  vmovaps xmm2, [rsp+0x20]
00007431745d3274  vmovaps xmm3, [rsp+0x30]
00007431745d327a  vmovaps xmm4, [rsp+0x40]
00007431745d3280  vmovaps xmm5, [rsp+0x50]
00007431745d3286  vmovaps xmm6, [rsp+0x60]
00007431745d328c  vmovaps xmm7, [rsp+0x70]
00007431745d3292  vmovaps xmm8, [rsp+0x80]
00007431745d329b  vmovaps xmm9, [rsp+0x90]
00007431745d32a4  vmovaps xmm10, [rsp+0xA0]
00007431745d32ad  vmovaps xmm12, [rsp+0xB0]
00007431745d32b6  vmovaps xmm13, [rsp+0xC0]
00007431745d32bf  vmovaps xmm14, [rsp+0xD0]
00007431745d32c8  vmovaps xmm15, [rsp+0xE0]
00007431745d32d1  add rsp, 0xF0
00007431745d32d8  pop r11
00007431745d32da  pop r10
00007431745d32dc  pop r9
00007431745d32de  pop r8
00007431745d32e0  pop rsi
00007431745d32e1  pop rdi
00007431745d32e2  pop rdx
00007431745d32e3  pop rcx
00007431745d32e4  pop rax
00007431745d32e5  add rsp, 0x08
00007431745d32e9  jmp 0x00007431745CFEB8
00007431745d32ee  sub rsp, 0x08
00007431745d32f2  push rax
00007431745d32f3  push rcx
00007431745d32f4  push rdx
00007431745d32f5  push rdi
00007431745d32f6  push rsi
00007431745d32f7  push r8
00007431745d32f9  push r9
00007431745d32fb  push r10
00007431745d32fd  push r11
00007431745d32ff  sub rsp, 0xF0
00007431745d3306  vmovaps [rsp], xmm0
00007431745d330b  vmovaps [rsp+0x10], xmm2
00007431745d3311  vmovaps [rsp+0x20], xmm3
00007431745d3317  vmovaps [rsp+0x30], xmm4
00007431745d331d  vmovaps [rsp+0x40], xmm5
00007431745d3323  vmovaps [rsp+0x50], xmm6
00007431745d3329  vmovaps [rsp+0x60], xmm7
00007431745d332f  vmovaps [rsp+0x70], xmm8
00007431745d3335  vmovaps [rsp+0x80], xmm9
00007431745d333e  vmovaps [rsp+0x90], xmm10
00007431745d3347  vmovaps [rsp+0xA0], xmm11
00007431745d3350  vmovaps [rsp+0xB0], xmm12
00007431745d3359  vmovaps [rsp+0xC0], xmm13
00007431745d3362  vmovaps [rsp+0xD0], xmm14
00007431745d336b  vmovaps [rsp+0xE0], xmm15
00007431745d3374  sub rsp, 0x30
00007431745d3378  movaps [rsp], xmm1
00007431745d337c  movaps [rsp+0x10], xmm14
00007431745d3382  movaps [rsp+0x20], xmm6
00007431745d3387  lea rdi, [rsp]
00007431745d338b  mov esi, 0x00
00007431745d3390  mov rax, 0x56C40959E530
00007431745d339a  call rax
00007431745d339c  movaps xmm1, [rsp]
00007431745d33a0  add rsp, 0x30
00007431745d33a4  vmovaps xmm0, [rsp]
00007431745d33a9  vmovaps xmm2, [rsp+0x10]
00007431745d33af  vmovaps xmm3, [rsp+0x20]
00007431745d33b5  vmovaps xmm4, [rsp+0x30]
00007431745d33bb  vmovaps xmm5, [rsp+0x40]
00007431745d33c1  vmovaps xmm6, [rsp+0x50]
00007431745d33c7  vmovaps xmm7, [rsp+0x60]
00007431745d33cd  vmovaps xmm8, [rsp+0x70]
00007431745d33d3  vmovaps xmm9, [rsp+0x80]
00007431745d33dc  vmovaps xmm10, [rsp+0x90]
00007431745d33e5  vmovaps xmm11, [rsp+0xA0]
00007431745d33ee  vmovaps xmm12, [rsp+0xB0]
00007431745d33f7  vmovaps xmm13, [rsp+0xC0]
00007431745d3400  vmovaps xmm14, [rsp+0xD0]
00007431745d3409  vmovaps xmm15, [rsp+0xE0]
00007431745d3412  add rsp, 0xF0
00007431745d3419  pop r11
00007431745d341b  pop r10
00007431745d341d  pop r9
00007431745d341f  pop r8
00007431745d3421  pop rsi
00007431745d3422  pop rdi
00007431745d3423  pop rdx
00007431745d3424  pop rcx
00007431745d3425  pop rax
00007431745d3426  add rsp, 0x08
00007431745d342a  jmp 0x00007431745CFED1
00007431745d342f  sub rsp, 0x08
00007431745d3433  push rax
00007431745d3434  push rcx
00007431745d3435  push rdx
00007431745d3436  push rdi
00007431745d3437  push rsi
00007431745d3438  push r8
00007431745d343a  push r9
00007431745d343c  push r10
00007431745d343e  push r11
00007431745d3440  sub rsp, 0xF0
00007431745d3447  vmovaps [rsp], xmm0
00007431745d344c  vmovaps [rsp+0x10], xmm1
00007431745d3452  vmovaps [rsp+0x20], xmm2
00007431745d3458  vmovaps [rsp+0x30], xmm3
00007431745d345e  vmovaps [rsp+0x40], xmm4
00007431745d3464  vmovaps [rsp+0x50], xmm5
00007431745d346a  vmovaps [rsp+0x60], xmm6
00007431745d3470  vmovaps [rsp+0x70], xmm7
00007431745d3476  vmovaps [rsp+0x80], xmm8
00007431745d347f  vmovaps [rsp+0x90], xmm9
00007431745d3488  vmovaps [rsp+0xA0], xmm10
00007431745d3491  vmovaps [rsp+0xB0], xmm11
00007431745d349a  vmovaps [rsp+0xC0], xmm12
00007431745d34a3  vmovaps [rsp+0xD0], xmm13
00007431745d34ac  vmovaps [rsp+0xE0], xmm15
00007431745d34b5  sub rsp, 0x30
00007431745d34b9  movaps [rsp], xmm14
00007431745d34be  movaps [rsp+0x10], xmm12
00007431745d34c4  movaps [rsp+0x20], xmm5
00007431745d34c9  lea rdi, [rsp]
00007431745d34cd  mov esi, 0x00
00007431745d34d2  mov rax, 0x56C40959E530
00007431745d34dc  call rax
00007431745d34de  movaps xmm14, [rsp]
00007431745d34e3  add rsp, 0x30
00007431745d34e7  vmovaps xmm0, [rsp]
00007431745d34ec  vmovaps xmm1, [rsp+0x10]
00007431745d34f2  vmovaps xmm2, [rsp+0x20]
00007431745d34f8  vmovaps xmm3, [rsp+0x30]
00007431745d34fe  vmovaps xmm4, [rsp+0x40]
00007431745d3504  vmovaps xmm5, [rsp+0x50]
00007431745d350a  vmovaps xmm6, [rsp+0x60]
00007431745d3510  vmovaps xmm7, [rsp+0x70]
00007431745d3516  vmovaps xmm8, [rsp+0x80]
00007431745d351f  vmovaps xmm9, [rsp+0x90]
00007431745d3528  vmovaps xmm10, [rsp+0xA0]
00007431745d3531  vmovaps xmm11, [rsp+0xB0]
00007431745d353a  vmovaps xmm12, [rsp+0xC0]
00007431745d3543  vmovaps xmm13, [rsp+0xD0]
00007431745d354c  vmovaps xmm15, [rsp+0xE0]
00007431745d3555  add rsp, 0xF0
00007431745d355c  pop r11
00007431745d355e  pop r10
00007431745d3560  pop r9
00007431745d3562  pop r8
00007431745d3564  pop rsi
00007431745d3565  pop rdi
00007431745d3566  pop rdx
00007431745d3567  pop rcx
00007431745d3568  pop rax
00007431745d3569  add rsp, 0x08
00007431745d356d  jmp 0x00007431745CFEF1
00007431745d3572  sub rsp, 0x08
00007431745d3576  push rax
00007431745d3577  push rcx
00007431745d3578  push rdx
00007431745d3579  push rdi
00007431745d357a  push rsi
00007431745d357b  push r8
00007431745d357d  push r9
00007431745d357f  push r10
00007431745d3581  push r11
00007431745d3583  sub rsp, 0xF0
00007431745d358a  vmovaps [rsp], xmm0
00007431745d358f  vmovaps [rsp+0x10], xmm1
00007431745d3595  vmovaps [rsp+0x20], xmm2
00007431745d359b  vmovaps [rsp+0x30], xmm3
00007431745d35a1  vmovaps [rsp+0x40], xmm4
00007431745d35a7  vmovaps [rsp+0x50], xmm5
00007431745d35ad  vmovaps [rsp+0x60], xmm7
00007431745d35b3  vmovaps [rsp+0x70], xmm8
00007431745d35b9  vmovaps [rsp+0x80], xmm9
00007431745d35c2  vmovaps [rsp+0x90], xmm10
00007431745d35cb  vmovaps [rsp+0xA0], xmm11
00007431745d35d4  vmovaps [rsp+0xB0], xmm12
00007431745d35dd  vmovaps [rsp+0xC0], xmm13
00007431745d35e6  vmovaps [rsp+0xD0], xmm14
00007431745d35ef  vmovaps [rsp+0xE0], xmm15
00007431745d35f8  sub rsp, 0x30
00007431745d35fc  movaps [rsp], xmm6
00007431745d3600  movaps [rsp+0x10], xmm9
00007431745d3606  movaps [rsp+0x20], xmm12
00007431745d360c  lea rdi, [rsp]
00007431745d3610  mov esi, 0x00
00007431745d3615  mov rax, 0x56C40959E530
00007431745d361f  call rax
00007431745d3621  movaps xmm6, [rsp]
00007431745d3625  add rsp, 0x30
00007431745d3629  vmovaps xmm0, [rsp]
00007431745d362e  vmovaps xmm1, [rsp+0x10]
00007431745d3634  vmovaps xmm2, [rsp+0x20]
00007431745d363a  vmovaps xmm3, [rsp+0x30]
00007431745d3640  vmovaps xmm4, [rsp+0x40]
00007431745d3646  vmovaps xmm5, [rsp+0x50]
00007431745d364c  vmovaps xmm7, [rsp+0x60]
00007431745d3652  vmovaps xmm8, [rsp+0x70]
00007431745d3658  vmovaps xmm9, [rsp+0x80]
00007431745d3661  vmovaps xmm10, [rsp+0x90]
00007431745d366a  vmovaps xmm11, [rsp+0xA0]
00007431745d3673  vmovaps xmm12, [rsp+0xB0]
00007431745d367c  vmovaps xmm13, [rsp+0xC0]
00007431745d3685  vmovaps xmm14, [rsp+0xD0]
00007431745d368e  vmovaps xmm15, [rsp+0xE0]
00007431745d3697  add rsp, 0xF0
00007431745d369e  pop r11
00007431745d36a0  pop r10
00007431745d36a2  pop r9
00007431745d36a4  pop r8
00007431745d36a6  pop rsi
00007431745d36a7  pop rdi
00007431745d36a8  pop rdx
00007431745d36a9  pop rcx
00007431745d36aa  pop rax
00007431745d36ab  add rsp, 0x08
00007431745d36af  jmp 0x00007431745CFF19
00007431745d36b4  sub rsp, 0x08
00007431745d36b8  push rax
00007431745d36b9  push rcx
00007431745d36ba  push rdx
00007431745d36bb  push rdi
00007431745d36bc  push rsi
00007431745d36bd  push r8
00007431745d36bf  push r9
00007431745d36c1  push r10
00007431745d36c3  push r11
00007431745d36c5  sub rsp, 0xF0
00007431745d36cc  vmovaps [rsp], xmm0
00007431745d36d1  vmovaps [rsp+0x10], xmm1
00007431745d36d7  vmovaps [rsp+0x20], xmm2
00007431745d36dd  vmovaps [rsp+0x30], xmm3
00007431745d36e3  vmovaps [rsp+0x40], xmm4
00007431745d36e9  vmovaps [rsp+0x50], xmm5
00007431745d36ef  vmovaps [rsp+0x60], xmm6
00007431745d36f5  vmovaps [rsp+0x70], xmm7
00007431745d36fb  vmovaps [rsp+0x80], xmm8
00007431745d3704  vmovaps [rsp+0x90], xmm9
00007431745d370d  vmovaps [rsp+0xA0], xmm10
00007431745d3716  vmovaps [rsp+0xB0], xmm11
00007431745d371f  vmovaps [rsp+0xC0], xmm13
00007431745d3728  vmovaps [rsp+0xD0], xmm14
00007431745d3731  vmovaps [rsp+0xE0], xmm15
00007431745d373a  sub rsp, 0x30
00007431745d373e  movaps [rsp], xmm12
00007431745d3743  movaps [rsp+0x10], xmm15
00007431745d3749  movaps [rsp+0x20], xmm13
00007431745d374f  lea rdi, [rsp]
00007431745d3753  mov esi, 0x00
00007431745d3758  mov rax, 0x56C40959E530
00007431745d3762  call rax
00007431745d3764  movaps xmm12, [rsp]
00007431745d3769  add rsp, 0x30
00007431745d376d  vmovaps xmm0, [rsp]
00007431745d3772  vmovaps xmm1, [rsp+0x10]
00007431745d3778  vmovaps xmm2, [rsp+0x20]
00007431745d377e  vmovaps xmm3, [rsp+0x30]
00007431745d3784  vmovaps xmm4, [rsp+0x40]
00007431745d378a  vmovaps xmm5, [rsp+0x50]
00007431745d3790  vmovaps xmm6, [rsp+0x60]
00007431745d3796  vmovaps xmm7, [rsp+0x70]
00007431745d379c  vmovaps xmm8, [rsp+0x80]
00007431745d37a5  vmovaps xmm9, [rsp+0x90]
00007431745d37ae  vmovaps xmm10, [rsp+0xA0]
00007431745d37b7  vmovaps xmm11, [rsp+0xB0]
00007431745d37c0  vmovaps xmm13, [rsp+0xC0]
00007431745d37c9  vmovaps xmm14, [rsp+0xD0]
00007431745d37d2  vmovaps xmm15, [rsp+0xE0]
00007431745d37db  add rsp, 0xF0
00007431745d37e2  pop r11
00007431745d37e4  pop r10
00007431745d37e6  pop r9
00007431745d37e8  pop r8
00007431745d37ea  pop rsi
00007431745d37eb  pop rdi
00007431745d37ec  pop rdx
00007431745d37ed  pop rcx
00007431745d37ee  pop rax
00007431745d37ef  add rsp, 0x08
00007431745d37f3  jmp 0x00007431745CFF34
00007431745d37f8  sub rsp, 0x08
00007431745d37fc  push rax
00007431745d37fd  push rcx
00007431745d37fe  push rdx
00007431745d37ff  push rdi
00007431745d3800  push rsi
00007431745d3801  push r8
00007431745d3803  push r9
00007431745d3805  push r10
00007431745d3807  push r11
00007431745d3809  sub rsp, 0xF0
00007431745d3810  vmovaps [rsp], xmm0
00007431745d3815  vmovaps [rsp+0x10], xmm1
00007431745d381b  vmovaps [rsp+0x20], xmm2
00007431745d3821  vmovaps [rsp+0x30], xmm3
00007431745d3827  vmovaps [rsp+0x40], xmm4
00007431745d382d  vmovaps [rsp+0x50], xmm5
00007431745d3833  vmovaps [rsp+0x60], xmm6
00007431745d3839  vmovaps [rsp+0x70], xmm7
00007431745d383f  vmovaps [rsp+0x80], xmm8
00007431745d3848  vmovaps [rsp+0x90], xmm9
00007431745d3851  vmovaps [rsp+0xA0], xmm10
00007431745d385a  vmovaps [rsp+0xB0], xmm11
00007431745d3863  vmovaps [rsp+0xC0], xmm12
00007431745d386c  vmovaps [rsp+0xD0], xmm13
00007431745d3875  vmovaps [rsp+0xE0], xmm14
00007431745d387e  sub rsp, 0x30
00007431745d3882  movaps [rsp], xmm15
00007431745d3887  movaps [rsp+0x10], xmm13
00007431745d388d  movaps [rsp+0x20], xmm10
00007431745d3893  lea rdi, [rsp]
00007431745d3897  mov esi, 0x00
00007431745d389c  mov rax, 0x56C40959E530
00007431745d38a6  call rax
00007431745d38a8  movaps xmm15, [rsp]
00007431745d38ad  add rsp, 0x30
00007431745d38b1  vmovaps xmm0, [rsp]
00007431745d38b6  vmovaps xmm1, [rsp+0x10]
00007431745d38bc  vmovaps xmm2, [rsp+0x20]
00007431745d38c2  vmovaps xmm3, [rsp+0x30]
00007431745d38c8  vmovaps xmm4, [rsp+0x40]
00007431745d38ce  vmovaps xmm5, [rsp+0x50]
00007431745d38d4  vmovaps xmm6, [rsp+0x60]
00007431745d38da  vmovaps xmm7, [rsp+0x70]
00007431745d38e0  vmovaps xmm8, [rsp+0x80]
00007431745d38e9  vmovaps xmm9, [rsp+0x90]
00007431745d38f2  vmovaps xmm10, [rsp+0xA0]
00007431745d38fb  vmovaps xmm11, [rsp+0xB0]
00007431745d3904  vmovaps xmm12, [rsp+0xC0]
00007431745d390d  vmovaps xmm13, [rsp+0xD0]
00007431745d3916  vmovaps xmm14, [rsp+0xE0]
00007431745d391f  add rsp, 0xF0
00007431745d3926  pop r11
00007431745d3928  pop r10
00007431745d392a  pop r9
00007431745d392c  pop r8
00007431745d392e  pop rsi
00007431745d392f  pop rdi
00007431745d3930  pop rdx
00007431745d3931  pop rcx
00007431745d3932  pop rax
00007431745d3933  add rsp, 0x08
00007431745d3937  jmp 0x00007431745CFF55
00007431745d393c  call 0x000074317440C260
00007431745d3941  jmp 0x00007431745CFFB0
00007431745d3946  sub rsp, 0x08
00007431745d394a  push rax
00007431745d394b  push rcx
00007431745d394c  push rdx
00007431745d394d  push rdi
00007431745d394e  push rsi
00007431745d394f  push r8
00007431745d3951  push r9
00007431745d3953  push r10
00007431745d3955  push r11
00007431745d3957  sub rsp, 0xF0
00007431745d395e  vmovaps [rsp], xmm0
00007431745d3963  vmovaps [rsp+0x10], xmm1
00007431745d3969  vmovaps [rsp+0x20], xmm2
00007431745d396f  vmovaps [rsp+0x30], xmm3
00007431745d3975  vmovaps [rsp+0x40], xmm4
00007431745d397b  vmovaps [rsp+0x50], xmm5
00007431745d3981  vmovaps [rsp+0x60], xmm6
00007431745d3987  vmovaps [rsp+0x70], xmm7
00007431745d398d  vmovaps [rsp+0x80], xmm8
00007431745d3996  vmovaps [rsp+0x90], xmm10
00007431745d399f  vmovaps [rsp+0xA0], xmm11
00007431745d39a8  vmovaps [rsp+0xB0], xmm12
00007431745d39b1  vmovaps [rsp+0xC0], xmm13
00007431745d39ba  vmovaps [rsp+0xD0], xmm14
00007431745d39c3  vmovaps [rsp+0xE0], xmm15
00007431745d39cc  sub rsp, 0x30
00007431745d39d0  movaps [rsp], xmm9
00007431745d39d5  movaps [rsp+0x10], xmm8
00007431745d39db  movaps [rsp+0x20], xmm10
00007431745d39e1  lea rdi, [rsp]
00007431745d39e5  mov esi, 0x00
00007431745d39ea  mov rax, 0x56C40959E530
00007431745d39f4  call rax
00007431745d39f6  movaps xmm9, [rsp]
00007431745d39fb  add rsp, 0x30
00007431745d39ff  vmovaps xmm0, [rsp]
00007431745d3a04  vmovaps xmm1, [rsp+0x10]
00007431745d3a0a  vmovaps xmm2, [rsp+0x20]
00007431745d3a10  vmovaps xmm3, [rsp+0x30]
00007431745d3a16  vmovaps xmm4, [rsp+0x40]
00007431745d3a1c  vmovaps xmm5, [rsp+0x50]
00007431745d3a22  vmovaps xmm6, [rsp+0x60]
00007431745d3a28  vmovaps xmm7, [rsp+0x70]
00007431745d3a2e  vmovaps xmm8, [rsp+0x80]
00007431745d3a37  vmovaps xmm10, [rsp+0x90]
00007431745d3a40  vmovaps xmm11, [rsp+0xA0]
00007431745d3a49  vmovaps xmm12, [rsp+0xB0]
00007431745d3a52  vmovaps xmm13, [rsp+0xC0]
00007431745d3a5b  vmovaps xmm14, [rsp+0xD0]
00007431745d3a64  vmovaps xmm15, [rsp+0xE0]
00007431745d3a6d  add rsp, 0xF0
00007431745d3a74  pop r11
00007431745d3a76  pop r10
00007431745d3a78  pop r9
00007431745d3a7a  pop r8
00007431745d3a7c  pop rsi
00007431745d3a7d  pop rdi
00007431745d3a7e  pop rdx
00007431745d3a7f  pop rcx
00007431745d3a80  pop rax
00007431745d3a81  add rsp, 0x08
00007431745d3a85  jmp 0x00007431745CFFE1
00007431745d3a8a  sub rsp, 0x08
00007431745d3a8e  push rax
00007431745d3a8f  push rcx
00007431745d3a90  push rdx
00007431745d3a91  push rdi
00007431745d3a92  push rsi
00007431745d3a93  push r8
00007431745d3a95  push r9
00007431745d3a97  push r10
00007431745d3a99  push r11
00007431745d3a9b  sub rsp, 0xF0
00007431745d3aa2  vmovaps [rsp], xmm0
00007431745d3aa7  vmovaps [rsp+0x10], xmm1
00007431745d3aad  vmovaps [rsp+0x20], xmm2
00007431745d3ab3  vmovaps [rsp+0x30], xmm3
00007431745d3ab9  vmovaps [rsp+0x40], xmm4
00007431745d3abf  vmovaps [rsp+0x50], xmm5
00007431745d3ac5  vmovaps [rsp+0x60], xmm6
00007431745d3acb  vmovaps [rsp+0x70], xmm7
00007431745d3ad1  vmovaps [rsp+0x80], xmm8
00007431745d3ada  vmovaps [rsp+0x90], xmm9
00007431745d3ae3  vmovaps [rsp+0xA0], xmm11
00007431745d3aec  vmovaps [rsp+0xB0], xmm12
00007431745d3af5  vmovaps [rsp+0xC0], xmm13
00007431745d3afe  vmovaps [rsp+0xD0], xmm14
00007431745d3b07  vmovaps [rsp+0xE0], xmm15
00007431745d3b10  sub rsp, 0x30
00007431745d3b14  movaps [rsp], xmm10
00007431745d3b19  movaps [rsp+0x10], xmm1
00007431745d3b1e  movaps [rsp+0x20], xmm11
00007431745d3b24  lea rdi, [rsp]
00007431745d3b28  mov esi, 0x00
00007431745d3b2d  mov rax, 0x56C40959E530
00007431745d3b37  call rax
00007431745d3b39  movaps xmm10, [rsp]
00007431745d3b3e  add rsp, 0x30
00007431745d3b42  vmovaps xmm0, [rsp]
00007431745d3b47  vmovaps xmm1, [rsp+0x10]
00007431745d3b4d  vmovaps xmm2, [rsp+0x20]
00007431745d3b53  vmovaps xmm3, [rsp+0x30]
00007431745d3b59  vmovaps xmm4, [rsp+0x40]
00007431745d3b5f  vmovaps xmm5, [rsp+0x50]
00007431745d3b65  vmovaps xmm6, [rsp+0x60]
00007431745d3b6b  vmovaps xmm7, [rsp+0x70]
00007431745d3b71  vmovaps xmm8, [rsp+0x80]
00007431745d3b7a  vmovaps xmm9, [rsp+0x90]
00007431745d3b83  vmovaps xmm11, [rsp+0xA0]
00007431745d3b8c  vmovaps xmm12, [rsp+0xB0]
00007431745d3b95  vmovaps xmm13, [rsp+0xC0]
00007431745d3b9e  vmovaps xmm14, [rsp+0xD0]
00007431745d3ba7  vmovaps xmm15, [rsp+0xE0]
00007431745d3bb0  add rsp, 0xF0
00007431745d3bb7  pop r11
00007431745d3bb9  pop r10
00007431745d3bbb  pop r9
00007431745d3bbd  pop r8
00007431745d3bbf  pop rsi
00007431745d3bc0  pop rdi
00007431745d3bc1  pop rdx
00007431745d3bc2  pop rcx
00007431745d3bc3  pop rax
00007431745d3bc4  add rsp, 0x08
00007431745d3bc8  jmp 0x00007431745CFFFC
00007431745d3bcd  sub rsp, 0x08
00007431745d3bd1  push rax
00007431745d3bd2  push rcx
00007431745d3bd3  push rdx
00007431745d3bd4  push rdi
00007431745d3bd5  push rsi
00007431745d3bd6  push r8
00007431745d3bd8  push r9
00007431745d3bda  push r10
00007431745d3bdc  push r11
00007431745d3bde  sub rsp, 0xF0
00007431745d3be5  vmovaps [rsp], xmm0
00007431745d3bea  vmovaps [rsp+0x10], xmm2
00007431745d3bf0  vmovaps [rsp+0x20], xmm3
00007431745d3bf6  vmovaps [rsp+0x30], xmm4
00007431745d3bfc  vmovaps [rsp+0x40], xmm5
00007431745d3c02  vmovaps [rsp+0x50], xmm6
00007431745d3c08  vmovaps [rsp+0x60], xmm7
00007431745d3c0e  vmovaps [rsp+0x70], xmm8
00007431745d3c14  vmovaps [rsp+0x80], xmm9
00007431745d3c1d  vmovaps [rsp+0x90], xmm10
00007431745d3c26  vmovaps [rsp+0xA0], xmm11
00007431745d3c2f  vmovaps [rsp+0xB0], xmm12
00007431745d3c38  vmovaps [rsp+0xC0], xmm13
00007431745d3c41  vmovaps [rsp+0xD0], xmm14
00007431745d3c4a  vmovaps [rsp+0xE0], xmm15
00007431745d3c53  sub rsp, 0x30
00007431745d3c57  movaps [rsp], xmm1
00007431745d3c5b  movaps [rsp+0x10], xmm14
00007431745d3c61  movaps [rsp+0x20], xmm6
00007431745d3c66  lea rdi, [rsp]
00007431745d3c6a  mov esi, 0x00
00007431745d3c6f  mov rax, 0x56C40959E530
00007431745d3c79  call rax
00007431745d3c7b  movaps xmm1, [rsp]
00007431745d3c7f  add rsp, 0x30
00007431745d3c83  vmovaps xmm0, [rsp]
00007431745d3c88  vmovaps xmm2, [rsp+0x10]
00007431745d3c8e  vmovaps xmm3, [rsp+0x20]
00007431745d3c94  vmovaps xmm4, [rsp+0x30]
00007431745d3c9a  vmovaps xmm5, [rsp+0x40]
00007431745d3ca0  vmovaps xmm6, [rsp+0x50]
00007431745d3ca6  vmovaps xmm7, [rsp+0x60]
00007431745d3cac  vmovaps xmm8, [rsp+0x70]
00007431745d3cb2  vmovaps xmm9, [rsp+0x80]
00007431745d3cbb  vmovaps xmm10, [rsp+0x90]
00007431745d3cc4  vmovaps xmm11, [rsp+0xA0]
00007431745d3ccd  vmovaps xmm12, [rsp+0xB0]
00007431745d3cd6  vmovaps xmm13, [rsp+0xC0]
00007431745d3cdf  vmovaps xmm14, [rsp+0xD0]
00007431745d3ce8  vmovaps xmm15, [rsp+0xE0]
00007431745d3cf1  add rsp, 0xF0
00007431745d3cf8  pop r11
00007431745d3cfa  pop r10
00007431745d3cfc  pop r9
00007431745d3cfe  pop r8
00007431745d3d00  pop rsi
00007431745d3d01  pop rdi
00007431745d3d02  pop rdx
00007431745d3d03  pop rcx
00007431745d3d04  pop rax
00007431745d3d05  add rsp, 0x08
00007431745d3d09  jmp 0x00007431745D0015
00007431745d3d0e  sub rsp, 0x08
00007431745d3d12  push rax
00007431745d3d13  push rcx
00007431745d3d14  push rdx
00007431745d3d15  push rdi
00007431745d3d16  push rsi
00007431745d3d17  push r8
00007431745d3d19  push r9
00007431745d3d1b  push r10
00007431745d3d1d  push r11
00007431745d3d1f  sub rsp, 0xF0
00007431745d3d26  vmovaps [rsp], xmm0
00007431745d3d2b  vmovaps [rsp+0x10], xmm1
00007431745d3d31  vmovaps [rsp+0x20], xmm2
00007431745d3d37  vmovaps [rsp+0x30], xmm3
00007431745d3d3d  vmovaps [rsp+0x40], xmm4
00007431745d3d43  vmovaps [rsp+0x50], xmm5
00007431745d3d49  vmovaps [rsp+0x60], xmm6
00007431745d3d4f  vmovaps [rsp+0x70], xmm7
00007431745d3d55  vmovaps [rsp+0x80], xmm8
00007431745d3d5e  vmovaps [rsp+0x90], xmm9
00007431745d3d67  vmovaps [rsp+0xA0], xmm10
00007431745d3d70  vmovaps [rsp+0xB0], xmm12
00007431745d3d79  vmovaps [rsp+0xC0], xmm13
00007431745d3d82  vmovaps [rsp+0xD0], xmm14
00007431745d3d8b  vmovaps [rsp+0xE0], xmm15
00007431745d3d94  sub rsp, 0x30
00007431745d3d98  movaps [rsp], xmm11
00007431745d3d9d  movaps [rsp+0x10], xmm13
00007431745d3da3  movaps [rsp+0x20], xmm14
00007431745d3da9  lea rdi, [rsp]
00007431745d3dad  mov esi, 0x00
00007431745d3db2  mov rax, 0x56C40959E530
00007431745d3dbc  call rax
00007431745d3dbe  movaps xmm11, [rsp]
00007431745d3dc3  add rsp, 0x30
00007431745d3dc7  vmovaps xmm0, [rsp]
00007431745d3dcc  vmovaps xmm1, [rsp+0x10]
00007431745d3dd2  vmovaps xmm2, [rsp+0x20]
00007431745d3dd8  vmovaps xmm3, [rsp+0x30]
00007431745d3dde  vmovaps xmm4, [rsp+0x40]
00007431745d3de4  vmovaps xmm5, [rsp+0x50]
00007431745d3dea  vmovaps xmm6, [rsp+0x60]
00007431745d3df0  vmovaps xmm7, [rsp+0x70]
00007431745d3df6  vmovaps xmm8, [rsp+0x80]
00007431745d3dff  vmovaps xmm9, [rsp+0x90]
00007431745d3e08  vmovaps xmm10, [rsp+0xA0]
00007431745d3e11  vmovaps xmm12, [rsp+0xB0]
00007431745d3e1a  vmovaps xmm13, [rsp+0xC0]
00007431745d3e23  vmovaps xmm14, [rsp+0xD0]
00007431745d3e2c  vmovaps xmm15, [rsp+0xE0]
00007431745d3e35  add rsp, 0xF0
00007431745d3e3c  pop r11
00007431745d3e3e  pop r10
00007431745d3e40  pop r9
00007431745d3e42  pop r8
00007431745d3e44  pop rsi
00007431745d3e45  pop rdi
00007431745d3e46  pop rdx
00007431745d3e47  pop rcx
00007431745d3e48  pop rax
00007431745d3e49  add rsp, 0x08
00007431745d3e4d  jmp 0x00007431745D003F
00007431745d3e52  sub rsp, 0x08
00007431745d3e56  push rax
00007431745d3e57  push rcx
00007431745d3e58  push rdx
00007431745d3e59  push rdi
00007431745d3e5a  push rsi
00007431745d3e5b  push r8
00007431745d3e5d  push r9
00007431745d3e5f  push r10
00007431745d3e61  push r11
00007431745d3e63  sub rsp, 0xF0
00007431745d3e6a  vmovaps [rsp], xmm0
00007431745d3e6f  vmovaps [rsp+0x10], xmm1
00007431745d3e75  vmovaps [rsp+0x20], xmm2
00007431745d3e7b  vmovaps [rsp+0x30], xmm3
00007431745d3e81  vmovaps [rsp+0x40], xmm4
00007431745d3e87  vmovaps [rsp+0x50], xmm5
00007431745d3e8d  vmovaps [rsp+0x60], xmm6
00007431745d3e93  vmovaps [rsp+0x70], xmm7
00007431745d3e99  vmovaps [rsp+0x80], xmm8
00007431745d3ea2  vmovaps [rsp+0x90], xmm9
00007431745d3eab  vmovaps [rsp+0xA0], xmm10
00007431745d3eb4  vmovaps [rsp+0xB0], xmm11
00007431745d3ebd  vmovaps [rsp+0xC0], xmm12
00007431745d3ec6  vmovaps [rsp+0xD0], xmm14
00007431745d3ecf  vmovaps [rsp+0xE0], xmm15
00007431745d3ed8  sub rsp, 0x30
00007431745d3edc  movaps [rsp], xmm13
00007431745d3ee1  movaps [rsp+0x10], xmm8
00007431745d3ee7  movaps [rsp+0x20], xmm14
00007431745d3eed  lea rdi, [rsp]
00007431745d3ef1  mov esi, 0x00
00007431745d3ef6  mov rax, 0x56C40959E530
00007431745d3f00  call rax
00007431745d3f02  movaps xmm13, [rsp]
00007431745d3f07  add rsp, 0x30
00007431745d3f0b  vmovaps xmm0, [rsp]
00007431745d3f10  vmovaps xmm1, [rsp+0x10]
00007431745d3f16  vmovaps xmm2, [rsp+0x20]
00007431745d3f1c  vmovaps xmm3, [rsp+0x30]
00007431745d3f22  vmovaps xmm4, [rsp+0x40]
00007431745d3f28  vmovaps xmm5, [rsp+0x50]
00007431745d3f2e  vmovaps xmm6, [rsp+0x60]
00007431745d3f34  vmovaps xmm7, [rsp+0x70]
00007431745d3f3a  vmovaps xmm8, [rsp+0x80]
00007431745d3f43  vmovaps xmm9, [rsp+0x90]
00007431745d3f4c  vmovaps xmm10, [rsp+0xA0]
00007431745d3f55  vmovaps xmm11, [rsp+0xB0]
00007431745d3f5e  vmovaps xmm12, [rsp+0xC0]
00007431745d3f67  vmovaps xmm14, [rsp+0xD0]
00007431745d3f70  vmovaps xmm15, [rsp+0xE0]
00007431745d3f79  add rsp, 0xF0
00007431745d3f80  pop r11
00007431745d3f82  pop r10
00007431745d3f84  pop r9
00007431745d3f86  pop r8
00007431745d3f88  pop rsi
00007431745d3f89  pop rdi
00007431745d3f8a  pop rdx
00007431745d3f8b  pop rcx
00007431745d3f8c  pop rax
00007431745d3f8d  add rsp, 0x08
00007431745d3f91  jmp 0x00007431745D006E
00007431745d3f96  sub rsp, 0x08
00007431745d3f9a  push rax
00007431745d3f9b  push rcx
00007431745d3f9c  push rdx
00007431745d3f9d  push rdi
00007431745d3f9e  push rsi
00007431745d3f9f  push r8
00007431745d3fa1  push r9
00007431745d3fa3  push r10
00007431745d3fa5  push r11
00007431745d3fa7  sub rsp, 0xF0
00007431745d3fae  vmovaps [rsp], xmm0
00007431745d3fb3  vmovaps [rsp+0x10], xmm1
00007431745d3fb9  vmovaps [rsp+0x20], xmm2
00007431745d3fbf  vmovaps [rsp+0x30], xmm3
00007431745d3fc5  vmovaps [rsp+0x40], xmm4
00007431745d3fcb  vmovaps [rsp+0x50], xmm5
00007431745d3fd1  vmovaps [rsp+0x60], xmm6
00007431745d3fd7  vmovaps [rsp+0x70], xmm7
00007431745d3fdd  vmovaps [rsp+0x80], xmm9
00007431745d3fe6  vmovaps [rsp+0x90], xmm10
00007431745d3fef  vmovaps [rsp+0xA0], xmm11
00007431745d3ff8  vmovaps [rsp+0xB0], xmm12
00007431745d4001  vmovaps [rsp+0xC0], xmm13
00007431745d400a  vmovaps [rsp+0xD0], xmm14
00007431745d4013  vmovaps [rsp+0xE0], xmm15
00007431745d401c  sub rsp, 0x30
00007431745d4020  movaps [rsp], xmm8
00007431745d4025  movaps [rsp+0x10], xmm7
00007431745d402a  movaps [rsp+0x20], xmm14
00007431745d4030  lea rdi, [rsp]
00007431745d4034  mov esi, 0x00
00007431745d4039  mov rax, 0x56C40959E530
00007431745d4043  call rax
00007431745d4045  movaps xmm8, [rsp]
00007431745d404a  add rsp, 0x30
00007431745d404e  vmovaps xmm0, [rsp]
00007431745d4053  vmovaps xmm1, [rsp+0x10]
00007431745d4059  vmovaps xmm2, [rsp+0x20]
00007431745d405f  vmovaps xmm3, [rsp+0x30]
00007431745d4065  vmovaps xmm4, [rsp+0x40]
00007431745d406b  vmovaps xmm5, [rsp+0x50]
00007431745d4071  vmovaps xmm6, [rsp+0x60]
00007431745d4077  vmovaps xmm7, [rsp+0x70]
00007431745d407d  vmovaps xmm9, [rsp+0x80]
00007431745d4086  vmovaps xmm10, [rsp+0x90]
00007431745d408f  vmovaps xmm11, [rsp+0xA0]
00007431745d4098  vmovaps xmm12, [rsp+0xB0]
00007431745d40a1  vmovaps xmm13, [rsp+0xC0]
00007431745d40aa  vmovaps xmm14, [rsp+0xD0]
00007431745d40b3  vmovaps xmm15, [rsp+0xE0]
00007431745d40bc  add rsp, 0xF0
00007431745d40c3  pop r11
00007431745d40c5  pop r10
00007431745d40c7  pop r9
00007431745d40c9  pop r8
00007431745d40cb  pop rsi
00007431745d40cc  pop rdi
00007431745d40cd  pop rdx
00007431745d40ce  pop rcx
00007431745d40cf  pop rax
00007431745d40d0  add rsp, 0x08
00007431745d40d4  jmp 0x00007431745D0094
00007431745d40d9  sub rsp, 0x08
00007431745d40dd  push rax
00007431745d40de  push rcx
00007431745d40df  push rdx
00007431745d40e0  push rdi
00007431745d40e1  push rsi
00007431745d40e2  push r8
00007431745d40e4  push r9
00007431745d40e6  push r10
00007431745d40e8  push r11
00007431745d40ea  sub rsp, 0xF0
00007431745d40f1  vmovaps [rsp], xmm0
00007431745d40f6  vmovaps [rsp+0x10], xmm1
00007431745d40fc  vmovaps [rsp+0x20], xmm2
00007431745d4102  vmovaps [rsp+0x30], xmm3
00007431745d4108  vmovaps [rsp+0x40], xmm4
00007431745d410e  vmovaps [rsp+0x50], xmm5
00007431745d4114  vmovaps [rsp+0x60], xmm6
00007431745d411a  vmovaps [rsp+0x70], xmm7
00007431745d4120  vmovaps [rsp+0x80], xmm8
00007431745d4129  vmovaps [rsp+0x90], xmm9
00007431745d4132  vmovaps [rsp+0xA0], xmm10
00007431745d413b  vmovaps [rsp+0xB0], xmm11
00007431745d4144  vmovaps [rsp+0xC0], xmm12
00007431745d414d  vmovaps [rsp+0xD0], xmm13
00007431745d4156  vmovaps [rsp+0xE0], xmm15
00007431745d415f  sub rsp, 0x30
00007431745d4163  movaps [rsp], xmm14
00007431745d4168  movaps [rsp+0x10], xmm12
00007431745d416e  movaps [rsp+0x20], xmm9
00007431745d4174  lea rdi, [rsp]
00007431745d4178  mov esi, 0x00
00007431745d417d  mov rax, 0x56C40959E530
00007431745d4187  call rax
00007431745d4189  movaps xmm14, [rsp]
00007431745d418e  add rsp, 0x30
00007431745d4192  vmovaps xmm0, [rsp]
00007431745d4197  vmovaps xmm1, [rsp+0x10]
00007431745d419d  vmovaps xmm2, [rsp+0x20]
00007431745d41a3  vmovaps xmm3, [rsp+0x30]
00007431745d41a9  vmovaps xmm4, [rsp+0x40]
00007431745d41af  vmovaps xmm5, [rsp+0x50]
00007431745d41b5  vmovaps xmm6, [rsp+0x60]
00007431745d41bb  vmovaps xmm7, [rsp+0x70]
00007431745d41c1  vmovaps xmm8, [rsp+0x80]
00007431745d41ca  vmovaps xmm9, [rsp+0x90]
00007431745d41d3  vmovaps xmm10, [rsp+0xA0]
00007431745d41dc  vmovaps xmm11, [rsp+0xB0]
00007431745d41e5  vmovaps xmm12, [rsp+0xC0]
00007431745d41ee  vmovaps xmm13, [rsp+0xD0]
00007431745d41f7  vmovaps xmm15, [rsp+0xE0]
00007431745d4200  add rsp, 0xF0
00007431745d4207  pop r11
00007431745d4209  pop r10
00007431745d420b  pop r9
00007431745d420d  pop r8
00007431745d420f  pop rsi
00007431745d4210  pop rdi
00007431745d4211  pop rdx
00007431745d4212  pop rcx
00007431745d4213  pop rax
00007431745d4214  add rsp, 0x08
00007431745d4218  jmp 0x00007431745D00AE
00007431745d421d  sub rsp, 0x08
00007431745d4221  push rax
00007431745d4222  push rcx
00007431745d4223  push rdx
00007431745d4224  push rdi
00007431745d4225  push rsi
00007431745d4226  push r8
00007431745d4228  push r9
00007431745d422a  push r10
00007431745d422c  push r11
00007431745d422e  sub rsp, 0xF0
00007431745d4235  vmovaps [rsp], xmm0
00007431745d423a  vmovaps [rsp+0x10], xmm1
00007431745d4240  vmovaps [rsp+0x20], xmm2
00007431745d4246  vmovaps [rsp+0x30], xmm3
00007431745d424c  vmovaps [rsp+0x40], xmm4
00007431745d4252  vmovaps [rsp+0x50], xmm5
00007431745d4258  vmovaps [rsp+0x60], xmm6
00007431745d425e  vmovaps [rsp+0x70], xmm7
00007431745d4264  vmovaps [rsp+0x80], xmm8
00007431745d426d  vmovaps [rsp+0x90], xmm10
00007431745d4276  vmovaps [rsp+0xA0], xmm11
00007431745d427f  vmovaps [rsp+0xB0], xmm12
00007431745d4288  vmovaps [rsp+0xC0], xmm13
00007431745d4291  vmovaps [rsp+0xD0], xmm14
00007431745d429a  vmovaps [rsp+0xE0], xmm15
00007431745d42a3  sub rsp, 0x30
00007431745d42a7  movaps [rsp], xmm9
00007431745d42ac  movaps [rsp+0x10], xmm7
00007431745d42b1  movaps [rsp+0x20], xmm12
00007431745d42b7  lea rdi, [rsp]
00007431745d42bb  mov esi, 0x00
00007431745d42c0  mov rax, 0x56C40959E530
00007431745d42ca  call rax
00007431745d42cc  movaps xmm9, [rsp]
00007431745d42d1  add rsp, 0x30
00007431745d42d5  vmovaps xmm0, [rsp]
00007431745d42da  vmovaps xmm1, [rsp+0x10]
00007431745d42e0  vmovaps xmm2, [rsp+0x20]
00007431745d42e6  vmovaps xmm3, [rsp+0x30]
00007431745d42ec  vmovaps xmm4, [rsp+0x40]
00007431745d42f2  vmovaps xmm5, [rsp+0x50]
00007431745d42f8  vmovaps xmm6, [rsp+0x60]
00007431745d42fe  vmovaps xmm7, [rsp+0x70]
00007431745d4304  vmovaps xmm8, [rsp+0x80]
00007431745d430d  vmovaps xmm10, [rsp+0x90]
00007431745d4316  vmovaps xmm11, [rsp+0xA0]
00007431745d431f  vmovaps xmm12, [rsp+0xB0]
00007431745d4328  vmovaps xmm13, [rsp+0xC0]
00007431745d4331  vmovaps xmm14, [rsp+0xD0]
00007431745d433a  vmovaps xmm15, [rsp+0xE0]
00007431745d4343  add rsp, 0xF0
00007431745d434a  pop r11
00007431745d434c  pop r10
00007431745d434e  pop r9
00007431745d4350  pop r8
00007431745d4352  pop rsi
00007431745d4353  pop rdi
00007431745d4354  pop rdx
00007431745d4355  pop rcx
00007431745d4356  pop rax
00007431745d4357  add rsp, 0x08
00007431745d435b  jmp 0x00007431745D00DD
00007431745d4360  sub rsp, 0x08
00007431745d4364  push rax
00007431745d4365  push rcx
00007431745d4366  push rdx
00007431745d4367  push rdi
00007431745d4368  push rsi
00007431745d4369  push r8
00007431745d436b  push r9
00007431745d436d  push r10
00007431745d436f  push r11
00007431745d4371  sub rsp, 0xF0
00007431745d4378  vmovaps [rsp], xmm0
00007431745d437d  vmovaps [rsp+0x10], xmm1
00007431745d4383  vmovaps [rsp+0x20], xmm2
00007431745d4389  vmovaps [rsp+0x30], xmm3
00007431745d438f  vmovaps [rsp+0x40], xmm4
00007431745d4395  vmovaps [rsp+0x50], xmm5
00007431745d439b  vmovaps [rsp+0x60], xmm6
00007431745d43a1  vmovaps [rsp+0x70], xmm7
00007431745d43a7  vmovaps [rsp+0x80], xmm8
00007431745d43b0  vmovaps [rsp+0x90], xmm9
00007431745d43b9  vmovaps [rsp+0xA0], xmm10
00007431745d43c2  vmovaps [rsp+0xB0], xmm11
00007431745d43cb  vmovaps [rsp+0xC0], xmm13
00007431745d43d4  vmovaps [rsp+0xD0], xmm14
00007431745d43dd  vmovaps [rsp+0xE0], xmm15
00007431745d43e6  sub rsp, 0x30
00007431745d43ea  movaps [rsp], xmm12
00007431745d43ef  movaps [rsp+0x10], xmm15
00007431745d43f5  movaps [rsp+0x20], xmm11
00007431745d43fb  lea rdi, [rsp]
00007431745d43ff  mov esi, 0x00
00007431745d4404  mov rax, 0x56C40959E530
00007431745d440e  call rax
00007431745d4410  movaps xmm12, [rsp]
00007431745d4415  add rsp, 0x30
00007431745d4419  vmovaps xmm0, [rsp]
00007431745d441e  vmovaps xmm1, [rsp+0x10]
00007431745d4424  vmovaps xmm2, [rsp+0x20]
00007431745d442a  vmovaps xmm3, [rsp+0x30]
00007431745d4430  vmovaps xmm4, [rsp+0x40]
00007431745d4436  vmovaps xmm5, [rsp+0x50]
00007431745d443c  vmovaps xmm6, [rsp+0x60]
00007431745d4442  vmovaps xmm7, [rsp+0x70]
00007431745d4448  vmovaps xmm8, [rsp+0x80]
00007431745d4451  vmovaps xmm9, [rsp+0x90]
00007431745d445a  vmovaps xmm10, [rsp+0xA0]
00007431745d4463  vmovaps xmm11, [rsp+0xB0]
00007431745d446c  vmovaps xmm13, [rsp+0xC0]
00007431745d4475  vmovaps xmm14, [rsp+0xD0]
00007431745d447e  vmovaps xmm15, [rsp+0xE0]
00007431745d4487  add rsp, 0xF0
00007431745d448e  pop r11
00007431745d4490  pop r10
00007431745d4492  pop r9
00007431745d4494  pop r8
00007431745d4496  pop rsi
00007431745d4497  pop rdi
00007431745d4498  pop rdx
00007431745d4499  pop rcx
00007431745d449a  pop rax
00007431745d449b  add rsp, 0x08
00007431745d449f  jmp 0x00007431745D00F7
00007431745d44a4  sub rsp, 0x08
00007431745d44a8  push rax
00007431745d44a9  push rcx
00007431745d44aa  push rdx
00007431745d44ab  push rdi
00007431745d44ac  push rsi
00007431745d44ad  push r8
00007431745d44af  push r9
00007431745d44b1  push r10
00007431745d44b3  push r11
00007431745d44b5  sub rsp, 0xF0
00007431745d44bc  vmovaps [rsp], xmm0
00007431745d44c1  vmovaps [rsp+0x10], xmm1
00007431745d44c7  vmovaps [rsp+0x20], xmm2
00007431745d44cd  vmovaps [rsp+0x30], xmm3
00007431745d44d3  vmovaps [rsp+0x40], xmm4
00007431745d44d9  vmovaps [rsp+0x50], xmm5
00007431745d44df  vmovaps [rsp+0x60], xmm6
00007431745d44e5  vmovaps [rsp+0x70], xmm7
00007431745d44eb  vmovaps [rsp+0x80], xmm8
00007431745d44f4  vmovaps [rsp+0x90], xmm9
00007431745d44fd  vmovaps [rsp+0xA0], xmm10
00007431745d4506  vmovaps [rsp+0xB0], xmm12
00007431745d450f  vmovaps [rsp+0xC0], xmm13
00007431745d4518  vmovaps [rsp+0xD0], xmm14
00007431745d4521  vmovaps [rsp+0xE0], xmm15
00007431745d452a  sub rsp, 0x30
00007431745d452e  movaps [rsp], xmm11
00007431745d4533  movaps [rsp+0x10], xmm7
00007431745d4538  movaps [rsp+0x20], xmm15
00007431745d453e  lea rdi, [rsp]
00007431745d4542  mov esi, 0x00
00007431745d4547  mov rax, 0x56C40959E530
00007431745d4551  call rax
00007431745d4553  movaps xmm11, [rsp]
00007431745d4558  add rsp, 0x30
00007431745d455c  vmovaps xmm0, [rsp]
00007431745d4561  vmovaps xmm1, [rsp+0x10]
00007431745d4567  vmovaps xmm2, [rsp+0x20]
00007431745d456d  vmovaps xmm3, [rsp+0x30]
00007431745d4573  vmovaps xmm4, [rsp+0x40]
00007431745d4579  vmovaps xmm5, [rsp+0x50]
00007431745d457f  vmovaps xmm6, [rsp+0x60]
00007431745d4585  vmovaps xmm7, [rsp+0x70]
00007431745d458b  vmovaps xmm8, [rsp+0x80]
00007431745d4594  vmovaps xmm9, [rsp+0x90]
00007431745d459d  vmovaps xmm10, [rsp+0xA0]
00007431745d45a6  vmovaps xmm12, [rsp+0xB0]
00007431745d45af  vmovaps xmm13, [rsp+0xC0]
00007431745d45b8  vmovaps xmm14, [rsp+0xD0]
00007431745d45c1  vmovaps xmm15, [rsp+0xE0]
00007431745d45ca  add rsp, 0xF0
00007431745d45d1  pop r11
00007431745d45d3  pop r10
00007431745d45d5  pop r9
00007431745d45d7  pop r8
00007431745d45d9  pop rsi
00007431745d45da  pop rdi
00007431745d45db  pop rdx
00007431745d45dc  pop rcx
00007431745d45dd  pop rax
00007431745d45de  add rsp, 0x08
00007431745d45e2  jmp 0x00007431745D0123
00007431745d45e7  sub rsp, 0x08
00007431745d45eb  push rax
00007431745d45ec  push rcx
00007431745d45ed  push rdx
00007431745d45ee  push rdi
00007431745d45ef  push rsi
00007431745d45f0  push r8
00007431745d45f2  push r9
00007431745d45f4  push r10
00007431745d45f6  push r11
00007431745d45f8  sub rsp, 0xF0
00007431745d45ff  vmovaps [rsp], xmm0
00007431745d4604  vmovaps [rsp+0x10], xmm1
00007431745d460a  vmovaps [rsp+0x20], xmm2
00007431745d4610  vmovaps [rsp+0x30], xmm3
00007431745d4616  vmovaps [rsp+0x40], xmm4
00007431745d461c  vmovaps [rsp+0x50], xmm5
00007431745d4622  vmovaps [rsp+0x60], xmm6
00007431745d4628  vmovaps [rsp+0x70], xmm7
00007431745d462e  vmovaps [rsp+0x80], xmm8
00007431745d4637  vmovaps [rsp+0x90], xmm9
00007431745d4640  vmovaps [rsp+0xA0], xmm10
00007431745d4649  vmovaps [rsp+0xB0], xmm11
00007431745d4652  vmovaps [rsp+0xC0], xmm12
00007431745d465b  vmovaps [rsp+0xD0], xmm13
00007431745d4664  vmovaps [rsp+0xE0], xmm14
00007431745d466d  sub rsp, 0x30
00007431745d4671  movaps [rsp], xmm15
00007431745d4676  movaps [rsp+0x10], xmm10
00007431745d467c  movaps [rsp+0x20], xmm13
00007431745d4682  lea rdi, [rsp]
00007431745d4686  mov esi, 0x00
00007431745d468b  mov rax, 0x56C40959E530
00007431745d4695  call rax
00007431745d4697  movaps xmm15, [rsp]
00007431745d469c  add rsp, 0x30
00007431745d46a0  vmovaps xmm0, [rsp]
00007431745d46a5  vmovaps xmm1, [rsp+0x10]
00007431745d46ab  vmovaps xmm2, [rsp+0x20]
00007431745d46b1  vmovaps xmm3, [rsp+0x30]
00007431745d46b7  vmovaps xmm4, [rsp+0x40]
00007431745d46bd  vmovaps xmm5, [rsp+0x50]
00007431745d46c3  vmovaps xmm6, [rsp+0x60]
00007431745d46c9  vmovaps xmm7, [rsp+0x70]
00007431745d46cf  vmovaps xmm8, [rsp+0x80]
00007431745d46d8  vmovaps xmm9, [rsp+0x90]
00007431745d46e1  vmovaps xmm10, [rsp+0xA0]
00007431745d46ea  vmovaps xmm11, [rsp+0xB0]
00007431745d46f3  vmovaps xmm12, [rsp+0xC0]
00007431745d46fc  vmovaps xmm13, [rsp+0xD0]
00007431745d4705  vmovaps xmm14, [rsp+0xE0]
00007431745d470e  add rsp, 0xF0
00007431745d4715  pop r11
00007431745d4717  pop r10
00007431745d4719  pop r9
00007431745d471b  pop r8
00007431745d471d  pop rsi
00007431745d471e  pop rdi
00007431745d471f  pop rdx
00007431745d4720  pop rcx
00007431745d4721  pop rax
00007431745d4722  add rsp, 0x08
00007431745d4726  jmp 0x00007431745D013D
00007431745d472b  sub rsp, 0x08
00007431745d472f  push rax
00007431745d4730  push rcx
00007431745d4731  push rdx
00007431745d4732  push rdi
00007431745d4733  push rsi
00007431745d4734  push r8
00007431745d4736  push r9
00007431745d4738  push r10
00007431745d473a  push r11
00007431745d473c  sub rsp, 0xF0
00007431745d4743  vmovaps [rsp], xmm0
00007431745d4748  vmovaps [rsp+0x10], xmm1
00007431745d474e  vmovaps [rsp+0x20], xmm2
00007431745d4754  vmovaps [rsp+0x30], xmm3
00007431745d475a  vmovaps [rsp+0x40], xmm4
00007431745d4760  vmovaps [rsp+0x50], xmm5
00007431745d4766  vmovaps [rsp+0x60], xmm6
00007431745d476c  vmovaps [rsp+0x70], xmm7
00007431745d4772  vmovaps [rsp+0x80], xmm8
00007431745d477b  vmovaps [rsp+0x90], xmm9
00007431745d4784  vmovaps [rsp+0xA0], xmm11
00007431745d478d  vmovaps [rsp+0xB0], xmm12
00007431745d4796  vmovaps [rsp+0xC0], xmm13
00007431745d479f  vmovaps [rsp+0xD0], xmm14
00007431745d47a8  vmovaps [rsp+0xE0], xmm15
00007431745d47b1  sub rsp, 0x30
00007431745d47b5  movaps [rsp], xmm10
00007431745d47ba  movaps [rsp+0x10], xmm7
00007431745d47bf  movaps [rsp+0x20], xmm13
00007431745d47c5  lea rdi, [rsp]
00007431745d47c9  mov esi, 0x00
00007431745d47ce  mov rax, 0x56C40959E530
00007431745d47d8  call rax
00007431745d47da  movaps xmm10, [rsp]
00007431745d47df  add rsp, 0x30
00007431745d47e3  vmovaps xmm0, [rsp]
00007431745d47e8  vmovaps xmm1, [rsp+0x10]
00007431745d47ee  vmovaps xmm2, [rsp+0x20]
00007431745d47f4  vmovaps xmm3, [rsp+0x30]
00007431745d47fa  vmovaps xmm4, [rsp+0x40]
00007431745d4800  vmovaps xmm5, [rsp+0x50]
00007431745d4806  vmovaps xmm6, [rsp+0x60]
00007431745d480c  vmovaps xmm7, [rsp+0x70]
00007431745d4812  vmovaps xmm8, [rsp+0x80]
00007431745d481b  vmovaps xmm9, [rsp+0x90]
00007431745d4824  vmovaps xmm11, [rsp+0xA0]
00007431745d482d  vmovaps xmm12, [rsp+0xB0]
00007431745d4836  vmovaps xmm13, [rsp+0xC0]
00007431745d483f  vmovaps xmm14, [rsp+0xD0]
00007431745d4848  vmovaps xmm15, [rsp+0xE0]
00007431745d4851  add rsp, 0xF0
00007431745d4858  pop r11
00007431745d485a  pop r10
00007431745d485c  pop r9
00007431745d485e  pop r8
00007431745d4860  pop rsi
00007431745d4861  pop rdi
00007431745d4862  pop rdx
00007431745d4863  pop rcx
00007431745d4864  pop rax
00007431745d4865  add rsp, 0x08
00007431745d4869  jmp 0x00007431745D0169
00007431745d486e  sub rsp, 0x08
00007431745d4872  push rax
00007431745d4873  push rcx
00007431745d4874  push rdx
00007431745d4875  push rdi
00007431745d4876  push rsi
00007431745d4877  push r8
00007431745d4879  push r9
00007431745d487b  push r10
00007431745d487d  push r11
00007431745d487f  sub rsp, 0xF0
00007431745d4886  vmovaps [rsp], xmm0
00007431745d488b  vmovaps [rsp+0x10], xmm1
00007431745d4891  vmovaps [rsp+0x20], xmm2
00007431745d4897  vmovaps [rsp+0x30], xmm3
00007431745d489d  vmovaps [rsp+0x40], xmm4
00007431745d48a3  vmovaps [rsp+0x50], xmm5
00007431745d48a9  vmovaps [rsp+0x60], xmm6
00007431745d48af  vmovaps [rsp+0x70], xmm7
00007431745d48b5  vmovaps [rsp+0x80], xmm8
00007431745d48be  vmovaps [rsp+0x90], xmm9
00007431745d48c7  vmovaps [rsp+0xA0], xmm10
00007431745d48d0  vmovaps [rsp+0xB0], xmm11
00007431745d48d9  vmovaps [rsp+0xC0], xmm12
00007431745d48e2  vmovaps [rsp+0xD0], xmm14
00007431745d48eb  vmovaps [rsp+0xE0], xmm15
00007431745d48f4  sub rsp, 0x30
00007431745d48f8  movaps [rsp], xmm13
00007431745d48fd  movaps [rsp+0x10], xmm1
00007431745d4902  movaps [rsp+0x20], xmm8
00007431745d4908  lea rdi, [rsp]
00007431745d490c  mov esi, 0x00
00007431745d4911  mov rax, 0x56C40959E530
00007431745d491b  call rax
00007431745d491d  movaps xmm13, [rsp]
00007431745d4922  add rsp, 0x30
00007431745d4926  vmovaps xmm0, [rsp]
00007431745d492b  vmovaps xmm1, [rsp+0x10]
00007431745d4931  vmovaps xmm2, [rsp+0x20]
00007431745d4937  vmovaps xmm3, [rsp+0x30]
00007431745d493d  vmovaps xmm4, [rsp+0x40]
00007431745d4943  vmovaps xmm5, [rsp+0x50]
00007431745d4949  vmovaps xmm6, [rsp+0x60]
00007431745d494f  vmovaps xmm7, [rsp+0x70]
00007431745d4955  vmovaps xmm8, [rsp+0x80]
00007431745d495e  vmovaps xmm9, [rsp+0x90]
00007431745d4967  vmovaps xmm10, [rsp+0xA0]
00007431745d4970  vmovaps xmm11, [rsp+0xB0]
00007431745d4979  vmovaps xmm12, [rsp+0xC0]
00007431745d4982  vmovaps xmm14, [rsp+0xD0]
00007431745d498b  vmovaps xmm15, [rsp+0xE0]
00007431745d4994  add rsp, 0xF0
00007431745d499b  pop r11
00007431745d499d  pop r10
00007431745d499f  pop r9
00007431745d49a1  pop r8
00007431745d49a3  pop rsi
00007431745d49a4  pop rdi
00007431745d49a5  pop rdx
00007431745d49a6  pop rcx
00007431745d49a7  pop rax
00007431745d49a8  add rsp, 0x08
00007431745d49ac  jmp 0x00007431745D0183
00007431745d49b1  call 0x00007431743FF430
00007431745d49b6  jmp 0x00007431745D018D
00007431745d49bb  sub rsp, 0x08
00007431745d49bf  push rax
00007431745d49c0  push rcx
00007431745d49c1  push rdx
00007431745d49c2  push rdi
00007431745d49c3  push rsi
00007431745d49c4  push r8
00007431745d49c6  push r9
00007431745d49c8  push r10
00007431745d49ca  push r11
00007431745d49cc  sub rsp, 0xF0
00007431745d49d3  vmovaps [rsp], xmm0
00007431745d49d8  vmovaps [rsp+0x10], xmm1
00007431745d49de  vmovaps [rsp+0x20], xmm2
00007431745d49e4  vmovaps [rsp+0x30], xmm3
00007431745d49ea  vmovaps [rsp+0x40], xmm4
00007431745d49f0  vmovaps [rsp+0x50], xmm5
00007431745d49f6  vmovaps [rsp+0x60], xmm6
00007431745d49fc  vmovaps [rsp+0x70], xmm7
00007431745d4a02  vmovaps [rsp+0x80], xmm9
00007431745d4a0b  vmovaps [rsp+0x90], xmm10
00007431745d4a14  vmovaps [rsp+0xA0], xmm11
00007431745d4a1d  vmovaps [rsp+0xB0], xmm12
00007431745d4a26  vmovaps [rsp+0xC0], xmm13
00007431745d4a2f  vmovaps [rsp+0xD0], xmm14
00007431745d4a38  vmovaps [rsp+0xE0], xmm15
00007431745d4a41  sub rsp, 0x30
00007431745d4a45  movaps [rsp], xmm8
00007431745d4a4a  movaps [rsp+0x10], xmm14
00007431745d4a50  movaps [rsp+0x20], xmm9
00007431745d4a56  lea rdi, [rsp]
00007431745d4a5a  mov esi, 0x00
00007431745d4a5f  mov rax, 0x56C40959E530
00007431745d4a69  call rax
00007431745d4a6b  movaps xmm8, [rsp]
00007431745d4a70  add rsp, 0x30
00007431745d4a74  vmovaps xmm0, [rsp]
00007431745d4a79  vmovaps xmm1, [rsp+0x10]
00007431745d4a7f  vmovaps xmm2, [rsp+0x20]
00007431745d4a85  vmovaps xmm3, [rsp+0x30]
00007431745d4a8b  vmovaps xmm4, [rsp+0x40]
00007431745d4a91  vmovaps xmm5, [rsp+0x50]
00007431745d4a97  vmovaps xmm6, [rsp+0x60]
00007431745d4a9d  vmovaps xmm7, [rsp+0x70]
00007431745d4aa3  vmovaps xmm9, [rsp+0x80]
00007431745d4aac  vmovaps xmm10, [rsp+0x90]
00007431745d4ab5  vmovaps xmm11, [rsp+0xA0]
00007431745d4abe  vmovaps xmm12, [rsp+0xB0]
00007431745d4ac7  vmovaps xmm13, [rsp+0xC0]
00007431745d4ad0  vmovaps xmm14, [rsp+0xD0]
00007431745d4ad9  vmovaps xmm15, [rsp+0xE0]
00007431745d4ae2  add rsp, 0xF0
00007431745d4ae9  pop r11
00007431745d4aeb  pop r10
00007431745d4aed  pop r9
00007431745d4aef  pop r8
00007431745d4af1  pop rsi
00007431745d4af2  pop rdi
00007431745d4af3  pop rdx
00007431745d4af4  pop rcx
00007431745d4af5  pop rax
00007431745d4af6  add rsp, 0x08
00007431745d4afa  jmp 0x00007431745D01AF
00007431745d4aff  sub rsp, 0x08
00007431745d4b03  push rax
00007431745d4b04  push rcx
00007431745d4b05  push rdx
00007431745d4b06  push rdi
00007431745d4b07  push rsi
00007431745d4b08  push r8
00007431745d4b0a  push r9
00007431745d4b0c  push r10
00007431745d4b0e  push r11
00007431745d4b10  sub rsp, 0xF0
00007431745d4b17  vmovaps [rsp], xmm0
00007431745d4b1c  vmovaps [rsp+0x10], xmm1
00007431745d4b22  vmovaps [rsp+0x20], xmm2
00007431745d4b28  vmovaps [rsp+0x30], xmm3
00007431745d4b2e  vmovaps [rsp+0x40], xmm4
00007431745d4b34  vmovaps [rsp+0x50], xmm5
00007431745d4b3a  vmovaps [rsp+0x60], xmm6
00007431745d4b40  vmovaps [rsp+0x70], xmm7
00007431745d4b46  vmovaps [rsp+0x80], xmm8
00007431745d4b4f  vmovaps [rsp+0x90], xmm10
00007431745d4b58  vmovaps [rsp+0xA0], xmm11
00007431745d4b61  vmovaps [rsp+0xB0], xmm12
00007431745d4b6a  vmovaps [rsp+0xC0], xmm13
00007431745d4b73  vmovaps [rsp+0xD0], xmm14
00007431745d4b7c  vmovaps [rsp+0xE0], xmm15
00007431745d4b85  sub rsp, 0x30
00007431745d4b89  movaps [rsp], xmm9
00007431745d4b8e  movaps [rsp+0x10], xmm1
00007431745d4b93  movaps [rsp+0x20], xmm14
00007431745d4b99  lea rdi, [rsp]
00007431745d4b9d  mov esi, 0x00
00007431745d4ba2  mov rax, 0x56C40959E530
00007431745d4bac  call rax
00007431745d4bae  movaps xmm9, [rsp]
00007431745d4bb3  add rsp, 0x30
00007431745d4bb7  vmovaps xmm0, [rsp]
00007431745d4bbc  vmovaps xmm1, [rsp+0x10]
00007431745d4bc2  vmovaps xmm2, [rsp+0x20]
00007431745d4bc8  vmovaps xmm3, [rsp+0x30]
00007431745d4bce  vmovaps xmm4, [rsp+0x40]
00007431745d4bd4  vmovaps xmm5, [rsp+0x50]
00007431745d4bda  vmovaps xmm6, [rsp+0x60]
00007431745d4be0  vmovaps xmm7, [rsp+0x70]
00007431745d4be6  vmovaps xmm8, [rsp+0x80]
00007431745d4bef  vmovaps xmm10, [rsp+0x90]
00007431745d4bf8  vmovaps xmm11, [rsp+0xA0]
00007431745d4c01  vmovaps xmm12, [rsp+0xB0]
00007431745d4c0a  vmovaps xmm13, [rsp+0xC0]
00007431745d4c13  vmovaps xmm14, [rsp+0xD0]
00007431745d4c1c  vmovaps xmm15, [rsp+0xE0]
00007431745d4c25  add rsp, 0xF0
00007431745d4c2c  pop r11
00007431745d4c2e  pop r10
00007431745d4c30  pop r9
00007431745d4c32  pop r8
00007431745d4c34  pop rsi
00007431745d4c35  pop rdi
00007431745d4c36  pop rdx
00007431745d4c37  pop rcx
00007431745d4c38  pop rax
00007431745d4c39  add rsp, 0x08
00007431745d4c3d  jmp 0x00007431745D01DD
00007431745d4c42  sub rsp, 0x08
00007431745d4c46  push rax
00007431745d4c47  push rcx
00007431745d4c48  push rdx
00007431745d4c49  push rdi
00007431745d4c4a  push rsi
00007431745d4c4b  push r8
00007431745d4c4d  push r9
00007431745d4c4f  push r10
00007431745d4c51  push r11
00007431745d4c53  sub rsp, 0xF0
00007431745d4c5a  vmovaps [rsp], xmm0
00007431745d4c5f  vmovaps [rsp+0x10], xmm1
00007431745d4c65  vmovaps [rsp+0x20], xmm2
00007431745d4c6b  vmovaps [rsp+0x30], xmm3
00007431745d4c71  vmovaps [rsp+0x40], xmm4
00007431745d4c77  vmovaps [rsp+0x50], xmm5
00007431745d4c7d  vmovaps [rsp+0x60], xmm6
00007431745d4c83  vmovaps [rsp+0x70], xmm7
00007431745d4c89  vmovaps [rsp+0x80], xmm8
00007431745d4c92  vmovaps [rsp+0x90], xmm9
00007431745d4c9b  vmovaps [rsp+0xA0], xmm10
00007431745d4ca4  vmovaps [rsp+0xB0], xmm11
00007431745d4cad  vmovaps [rsp+0xC0], xmm12
00007431745d4cb6  vmovaps [rsp+0xD0], xmm13
00007431745d4cbf  vmovaps [rsp+0xE0], xmm15
00007431745d4cc8  sub rsp, 0x30
00007431745d4ccc  movaps [rsp], xmm14
00007431745d4cd1  movaps [rsp+0x10], xmm4
00007431745d4cd6  movaps [rsp+0x20], xmm1
00007431745d4cdb  lea rdi, [rsp]
00007431745d4cdf  mov esi, 0x00
00007431745d4ce4  mov rax, 0x56C40959E530
00007431745d4cee  call rax
00007431745d4cf0  movaps xmm14, [rsp]
00007431745d4cf5  add rsp, 0x30
00007431745d4cf9  vmovaps xmm0, [rsp]
00007431745d4cfe  vmovaps xmm1, [rsp+0x10]
00007431745d4d04  vmovaps xmm2, [rsp+0x20]
00007431745d4d0a  vmovaps xmm3, [rsp+0x30]
00007431745d4d10  vmovaps xmm4, [rsp+0x40]
00007431745d4d16  vmovaps xmm5, [rsp+0x50]
00007431745d4d1c  vmovaps xmm6, [rsp+0x60]
00007431745d4d22  vmovaps xmm7, [rsp+0x70]
00007431745d4d28  vmovaps xmm8, [rsp+0x80]
00007431745d4d31  vmovaps xmm9, [rsp+0x90]
00007431745d4d3a  vmovaps xmm10, [rsp+0xA0]
00007431745d4d43  vmovaps xmm11, [rsp+0xB0]
00007431745d4d4c  vmovaps xmm12, [rsp+0xC0]
00007431745d4d55  vmovaps xmm13, [rsp+0xD0]
00007431745d4d5e  vmovaps xmm15, [rsp+0xE0]
00007431745d4d67  add rsp, 0xF0
00007431745d4d6e  pop r11
00007431745d4d70  pop r10
00007431745d4d72  pop r9
00007431745d4d74  pop r8
00007431745d4d76  pop rsi
00007431745d4d77  pop rdi
00007431745d4d78  pop rdx
00007431745d4d79  pop rcx
00007431745d4d7a  pop rax
00007431745d4d7b  add rsp, 0x08
00007431745d4d7f  jmp 0x00007431745D0203
00007431745d4d84  sub rsp, 0x08
00007431745d4d88  push rax
00007431745d4d89  push rcx
00007431745d4d8a  push rdx
00007431745d4d8b  push rdi
00007431745d4d8c  push rsi
00007431745d4d8d  push r8
00007431745d4d8f  push r9
00007431745d4d91  push r10
00007431745d4d93  push r11
00007431745d4d95  sub rsp, 0xF0
00007431745d4d9c  vmovaps [rsp], xmm0
00007431745d4da1  vmovaps [rsp+0x10], xmm2
00007431745d4da7  vmovaps [rsp+0x20], xmm3
00007431745d4dad  vmovaps [rsp+0x30], xmm4
00007431745d4db3  vmovaps [rsp+0x40], xmm5
00007431745d4db9  vmovaps [rsp+0x50], xmm6
00007431745d4dbf  vmovaps [rsp+0x60], xmm7
00007431745d4dc5  vmovaps [rsp+0x70], xmm8
00007431745d4dcb  vmovaps [rsp+0x80], xmm9
00007431745d4dd4  vmovaps [rsp+0x90], xmm10
00007431745d4ddd  vmovaps [rsp+0xA0], xmm11
00007431745d4de6  vmovaps [rsp+0xB0], xmm12
00007431745d4def  vmovaps [rsp+0xC0], xmm13
00007431745d4df8  vmovaps [rsp+0xD0], xmm14
00007431745d4e01  vmovaps [rsp+0xE0], xmm15
00007431745d4e0a  sub rsp, 0x30
00007431745d4e0e  movaps [rsp], xmm1
00007431745d4e12  movaps [rsp+0x10], xmm12
00007431745d4e18  movaps [rsp+0x20], xmm11
00007431745d4e1e  lea rdi, [rsp]
00007431745d4e22  mov esi, 0x00
00007431745d4e27  mov rax, 0x56C40959E530
00007431745d4e31  call rax
00007431745d4e33  movaps xmm1, [rsp]
00007431745d4e37  add rsp, 0x30
00007431745d4e3b  vmovaps xmm0, [rsp]
00007431745d4e40  vmovaps xmm2, [rsp+0x10]
00007431745d4e46  vmovaps xmm3, [rsp+0x20]
00007431745d4e4c  vmovaps xmm4, [rsp+0x30]
00007431745d4e52  vmovaps xmm5, [rsp+0x40]
00007431745d4e58  vmovaps xmm6, [rsp+0x50]
00007431745d4e5e  vmovaps xmm7, [rsp+0x60]
00007431745d4e64  vmovaps xmm8, [rsp+0x70]
00007431745d4e6a  vmovaps xmm9, [rsp+0x80]
00007431745d4e73  vmovaps xmm10, [rsp+0x90]
00007431745d4e7c  vmovaps xmm11, [rsp+0xA0]
00007431745d4e85  vmovaps xmm12, [rsp+0xB0]
00007431745d4e8e  vmovaps xmm13, [rsp+0xC0]
00007431745d4e97  vmovaps xmm14, [rsp+0xD0]
00007431745d4ea0  vmovaps xmm15, [rsp+0xE0]
00007431745d4ea9  add rsp, 0xF0
00007431745d4eb0  pop r11
00007431745d4eb2  pop r10
00007431745d4eb4  pop r9
00007431745d4eb6  pop r8
00007431745d4eb8  pop rsi
00007431745d4eb9  pop rdi
00007431745d4eba  pop rdx
00007431745d4ebb  pop rcx
00007431745d4ebc  pop rax
00007431745d4ebd  add rsp, 0x08
00007431745d4ec1  jmp 0x00007431745D0224
00007431745d4ec6  call 0x00007431744E20A0
00007431745d4ecb  jmp 0x00007431745D0232
00007431745d4ed0  call 0x0000743174409D70
00007431745d4ed5  jmp 0x00007431745D023C
00007431745d4eda  sub rsp, 0x08
00007431745d4ede  push rax
00007431745d4edf  push rcx
00007431745d4ee0  push rdx
00007431745d4ee1  push rdi
00007431745d4ee2  push rsi
00007431745d4ee3  push r8
00007431745d4ee5  push r9
00007431745d4ee7  push r10
00007431745d4ee9  push r11
00007431745d4eeb  sub rsp, 0xF0
00007431745d4ef2  vmovaps [rsp], xmm0
00007431745d4ef7  vmovaps [rsp+0x10], xmm1
00007431745d4efd  vmovaps [rsp+0x20], xmm2
00007431745d4f03  vmovaps [rsp+0x30], xmm3
00007431745d4f09  vmovaps [rsp+0x40], xmm4
00007431745d4f0f  vmovaps [rsp+0x50], xmm5
00007431745d4f15  vmovaps [rsp+0x60], xmm6
00007431745d4f1b  vmovaps [rsp+0x70], xmm8
00007431745d4f21  vmovaps [rsp+0x80], xmm9
00007431745d4f2a  vmovaps [rsp+0x90], xmm10
00007431745d4f33  vmovaps [rsp+0xA0], xmm11
00007431745d4f3c  vmovaps [rsp+0xB0], xmm12
00007431745d4f45  vmovaps [rsp+0xC0], xmm13
00007431745d4f4e  vmovaps [rsp+0xD0], xmm14
00007431745d4f57  vmovaps [rsp+0xE0], xmm15
00007431745d4f60  sub rsp, 0x30
00007431745d4f64  movaps [rsp], xmm7
00007431745d4f68  movaps [rsp+0x10], xmm15
00007431745d4f6e  movaps [rsp+0x20], xmm10
00007431745d4f74  lea rdi, [rsp]
00007431745d4f78  mov esi, 0x00
00007431745d4f7d  mov rax, 0x56C40959E530
00007431745d4f87  call rax
00007431745d4f89  movaps xmm7, [rsp]
00007431745d4f8d  add rsp, 0x30
00007431745d4f91  vmovaps xmm0, [rsp]
00007431745d4f96  vmovaps xmm1, [rsp+0x10]
00007431745d4f9c  vmovaps xmm2, [rsp+0x20]
00007431745d4fa2  vmovaps xmm3, [rsp+0x30]
00007431745d4fa8  vmovaps xmm4, [rsp+0x40]
00007431745d4fae  vmovaps xmm5, [rsp+0x50]
00007431745d4fb4  vmovaps xmm6, [rsp+0x60]
00007431745d4fba  vmovaps xmm8, [rsp+0x70]
00007431745d4fc0  vmovaps xmm9, [rsp+0x80]
00007431745d4fc9  vmovaps xmm10, [rsp+0x90]
00007431745d4fd2  vmovaps xmm11, [rsp+0xA0]
00007431745d4fdb  vmovaps xmm12, [rsp+0xB0]
00007431745d4fe4  vmovaps xmm13, [rsp+0xC0]
00007431745d4fed  vmovaps xmm14, [rsp+0xD0]
00007431745d4ff6  vmovaps xmm15, [rsp+0xE0]
00007431745d4fff  add rsp, 0xF0
00007431745d5006  pop r11
00007431745d5008  pop r10
00007431745d500a  pop r9
00007431745d500c  pop r8
00007431745d500e  pop rsi
00007431745d500f  pop rdi
00007431745d5010  pop rdx
00007431745d5011  pop rcx
00007431745d5012  pop rax
00007431745d5013  add rsp, 0x08
00007431745d5017  jmp 0x00007431745D025D
00007431745d501c  sub rsp, 0x08
00007431745d5020  push rax
00007431745d5021  push rcx
00007431745d5022  push rdx
00007431745d5023  push rdi
00007431745d5024  push rsi
00007431745d5025  push r8
00007431745d5027  push r9
00007431745d5029  push r10
00007431745d502b  push r11
00007431745d502d  sub rsp, 0xF0
00007431745d5034  vmovaps [rsp], xmm0
00007431745d5039  vmovaps [rsp+0x10], xmm1
00007431745d503f  vmovaps [rsp+0x20], xmm2
00007431745d5045  vmovaps [rsp+0x30], xmm3
00007431745d504b  vmovaps [rsp+0x40], xmm4
00007431745d5051  vmovaps [rsp+0x50], xmm5
00007431745d5057  vmovaps [rsp+0x60], xmm6
00007431745d505d  vmovaps [rsp+0x70], xmm7
00007431745d5063  vmovaps [rsp+0x80], xmm8
00007431745d506c  vmovaps [rsp+0x90], xmm9
00007431745d5075  vmovaps [rsp+0xA0], xmm11
00007431745d507e  vmovaps [rsp+0xB0], xmm12
00007431745d5087  vmovaps [rsp+0xC0], xmm13
00007431745d5090  vmovaps [rsp+0xD0], xmm14
00007431745d5099  vmovaps [rsp+0xE0], xmm15
00007431745d50a2  sub rsp, 0x30
00007431745d50a6  movaps [rsp], xmm10
00007431745d50ab  movaps [rsp+0x10], xmm11
00007431745d50b1  movaps [rsp+0x20], xmm15
00007431745d50b7  lea rdi, [rsp]
00007431745d50bb  mov esi, 0x00
00007431745d50c0  mov rax, 0x56C40959E530
00007431745d50ca  call rax
00007431745d50cc  movaps xmm10, [rsp]
00007431745d50d1  add rsp, 0x30
00007431745d50d5  vmovaps xmm0, [rsp]
00007431745d50da  vmovaps xmm1, [rsp+0x10]
00007431745d50e0  vmovaps xmm2, [rsp+0x20]
00007431745d50e6  vmovaps xmm3, [rsp+0x30]
00007431745d50ec  vmovaps xmm4, [rsp+0x40]
00007431745d50f2  vmovaps xmm5, [rsp+0x50]
00007431745d50f8  vmovaps xmm6, [rsp+0x60]
00007431745d50fe  vmovaps xmm7, [rsp+0x70]
00007431745d5104  vmovaps xmm8, [rsp+0x80]
00007431745d510d  vmovaps xmm9, [rsp+0x90]
00007431745d5116  vmovaps xmm11, [rsp+0xA0]
00007431745d511f  vmovaps xmm12, [rsp+0xB0]
00007431745d5128  vmovaps xmm13, [rsp+0xC0]
00007431745d5131  vmovaps xmm14, [rsp+0xD0]
00007431745d513a  vmovaps xmm15, [rsp+0xE0]
00007431745d5143  add rsp, 0xF0
00007431745d514a  pop r11
00007431745d514c  pop r10
00007431745d514e  pop r9
00007431745d5150  pop r8
00007431745d5152  pop rsi
00007431745d5153  pop rdi
00007431745d5154  pop rdx
00007431745d5155  pop rcx
00007431745d5156  pop rax
00007431745d5157  add rsp, 0x08
00007431745d515b  jmp 0x00007431745D028B
00007431745d5160  sub rsp, 0x08
00007431745d5164  push rax
00007431745d5165  push rcx
00007431745d5166  push rdx
00007431745d5167  push rdi
00007431745d5168  push rsi
00007431745d5169  push r8
00007431745d516b  push r9
00007431745d516d  push r10
00007431745d516f  push r11
00007431745d5171  sub rsp, 0xF0
00007431745d5178  vmovaps [rsp], xmm0
00007431745d517d  vmovaps [rsp+0x10], xmm1
00007431745d5183  vmovaps [rsp+0x20], xmm2
00007431745d5189  vmovaps [rsp+0x30], xmm3
00007431745d518f  vmovaps [rsp+0x40], xmm4
00007431745d5195  vmovaps [rsp+0x50], xmm5
00007431745d519b  vmovaps [rsp+0x60], xmm6
00007431745d51a1  vmovaps [rsp+0x70], xmm7
00007431745d51a7  vmovaps [rsp+0x80], xmm8
00007431745d51b0  vmovaps [rsp+0x90], xmm9
00007431745d51b9  vmovaps [rsp+0xA0], xmm10
00007431745d51c2  vmovaps [rsp+0xB0], xmm12
00007431745d51cb  vmovaps [rsp+0xC0], xmm13
00007431745d51d4  vmovaps [rsp+0xD0], xmm14
00007431745d51dd  vmovaps [rsp+0xE0], xmm15
00007431745d51e6  sub rsp, 0x30
00007431745d51ea  movaps [rsp], xmm11
00007431745d51ef  movaps [rsp+0x10], xmm12
00007431745d51f5  movaps [rsp+0x20], xmm15
00007431745d51fb  lea rdi, [rsp]
00007431745d51ff  mov esi, 0x00
00007431745d5204  mov rax, 0x56C40959E530
00007431745d520e  call rax
00007431745d5210  movaps xmm11, [rsp]
00007431745d5215  add rsp, 0x30
00007431745d5219  vmovaps xmm0, [rsp]
00007431745d521e  vmovaps xmm1, [rsp+0x10]
00007431745d5224  vmovaps xmm2, [rsp+0x20]
00007431745d522a  vmovaps xmm3, [rsp+0x30]
00007431745d5230  vmovaps xmm4, [rsp+0x40]
00007431745d5236  vmovaps xmm5, [rsp+0x50]
00007431745d523c  vmovaps xmm6, [rsp+0x60]
00007431745d5242  vmovaps xmm7, [rsp+0x70]
00007431745d5248  vmovaps xmm8, [rsp+0x80]
00007431745d5251  vmovaps xmm9, [rsp+0x90]
00007431745d525a  vmovaps xmm10, [rsp+0xA0]
00007431745d5263  vmovaps xmm12, [rsp+0xB0]
00007431745d526c  vmovaps xmm13, [rsp+0xC0]
00007431745d5275  vmovaps xmm14, [rsp+0xD0]
00007431745d527e  vmovaps xmm15, [rsp+0xE0]
00007431745d5287  add rsp, 0xF0
00007431745d528e  pop r11
00007431745d5290  pop r10
00007431745d5292  pop r9
00007431745d5294  pop r8
00007431745d5296  pop rsi
00007431745d5297  pop rdi
00007431745d5298  pop rdx
00007431745d5299  pop rcx
00007431745d529a  pop rax
00007431745d529b  add rsp, 0x08
00007431745d529f  jmp 0x00007431745D02B9
00007431745d52a4  sub rsp, 0x08
00007431745d52a8  push rax
00007431745d52a9  push rcx
00007431745d52aa  push rdx
00007431745d52ab  push rdi
00007431745d52ac  push rsi
00007431745d52ad  push r8
00007431745d52af  push r9
00007431745d52b1  push r10
00007431745d52b3  push r11
00007431745d52b5  sub rsp, 0xF0
00007431745d52bc  vmovaps [rsp], xmm0
00007431745d52c1  vmovaps [rsp+0x10], xmm1
00007431745d52c7  vmovaps [rsp+0x20], xmm2
00007431745d52cd  vmovaps [rsp+0x30], xmm3
00007431745d52d3  vmovaps [rsp+0x40], xmm4
00007431745d52d9  vmovaps [rsp+0x50], xmm5
00007431745d52df  vmovaps [rsp+0x60], xmm6
00007431745d52e5  vmovaps [rsp+0x70], xmm7
00007431745d52eb  vmovaps [rsp+0x80], xmm8
00007431745d52f4  vmovaps [rsp+0x90], xmm9
00007431745d52fd  vmovaps [rsp+0xA0], xmm10
00007431745d5306  vmovaps [rsp+0xB0], xmm11
00007431745d530f  vmovaps [rsp+0xC0], xmm12
00007431745d5318  vmovaps [rsp+0xD0], xmm13
00007431745d5321  vmovaps [rsp+0xE0], xmm14
00007431745d532a  sub rsp, 0x30
00007431745d532e  movaps [rsp], xmm15
00007431745d5333  movaps [rsp+0x10], xmm13
00007431745d5339  movaps [rsp+0x20], xmm9
00007431745d533f  lea rdi, [rsp]
00007431745d5343  mov esi, 0x00
00007431745d5348  mov rax, 0x56C40959E530
00007431745d5352  call rax
00007431745d5354  movaps xmm15, [rsp]
00007431745d5359  add rsp, 0x30
00007431745d535d  vmovaps xmm0, [rsp]
00007431745d5362  vmovaps xmm1, [rsp+0x10]
00007431745d5368  vmovaps xmm2, [rsp+0x20]
00007431745d536e  vmovaps xmm3, [rsp+0x30]
00007431745d5374  vmovaps xmm4, [rsp+0x40]
00007431745d537a  vmovaps xmm5, [rsp+0x50]
00007431745d5380  vmovaps xmm6, [rsp+0x60]
00007431745d5386  vmovaps xmm7, [rsp+0x70]
00007431745d538c  vmovaps xmm8, [rsp+0x80]
00007431745d5395  vmovaps xmm9, [rsp+0x90]
00007431745d539e  vmovaps xmm10, [rsp+0xA0]
00007431745d53a7  vmovaps xmm11, [rsp+0xB0]
00007431745d53b0  vmovaps xmm12, [rsp+0xC0]
00007431745d53b9  vmovaps xmm13, [rsp+0xD0]
00007431745d53c2  vmovaps xmm14, [rsp+0xE0]
00007431745d53cb  add rsp, 0xF0
00007431745d53d2  pop r11
00007431745d53d4  pop r10
00007431745d53d6  pop r9
00007431745d53d8  pop r8
00007431745d53da  pop rsi
00007431745d53db  pop rdi
00007431745d53dc  pop rdx
00007431745d53dd  pop rcx
00007431745d53de  pop rax
00007431745d53df  add rsp, 0x08
00007431745d53e3  jmp 0x00007431745D02D4
00007431745d53e8  sub rsp, 0x08
00007431745d53ec  push rax
00007431745d53ed  push rcx
00007431745d53ee  push rdx
00007431745d53ef  push rdi
00007431745d53f0  push rsi
00007431745d53f1  push r8
00007431745d53f3  push r9
00007431745d53f5  push r10
00007431745d53f7  push r11
00007431745d53f9  sub rsp, 0xF0
00007431745d5400  vmovaps [rsp], xmm0
00007431745d5405  vmovaps [rsp+0x10], xmm1
00007431745d540b  vmovaps [rsp+0x20], xmm2
00007431745d5411  vmovaps [rsp+0x30], xmm3
00007431745d5417  vmovaps [rsp+0x40], xmm4
00007431745d541d  vmovaps [rsp+0x50], xmm5
00007431745d5423  vmovaps [rsp+0x60], xmm6
00007431745d5429  vmovaps [rsp+0x70], xmm7
00007431745d542f  vmovaps [rsp+0x80], xmm8
00007431745d5438  vmovaps [rsp+0x90], xmm9
00007431745d5441  vmovaps [rsp+0xA0], xmm10
00007431745d544a  vmovaps [rsp+0xB0], xmm11
00007431745d5453  vmovaps [rsp+0xC0], xmm12
00007431745d545c  vmovaps [rsp+0xD0], xmm14
00007431745d5465  vmovaps [rsp+0xE0], xmm15
00007431745d546e  sub rsp, 0x30
00007431745d5472  movaps [rsp], xmm13
00007431745d5477  movaps [rsp+0x10], xmm8
00007431745d547d  movaps [rsp+0x20], xmm14
00007431745d5483  lea rdi, [rsp]
00007431745d5487  mov esi, 0x00
00007431745d548c  mov rax, 0x56C40959E530
00007431745d5496  call rax
00007431745d5498  movaps xmm13, [rsp]
00007431745d549d  add rsp, 0x30
00007431745d54a1  vmovaps xmm0, [rsp]
00007431745d54a6  vmovaps xmm1, [rsp+0x10]
00007431745d54ac  vmovaps xmm2, [rsp+0x20]
00007431745d54b2  vmovaps xmm3, [rsp+0x30]
00007431745d54b8  vmovaps xmm4, [rsp+0x40]
00007431745d54be  vmovaps xmm5, [rsp+0x50]
00007431745d54c4  vmovaps xmm6, [rsp+0x60]
00007431745d54ca  vmovaps xmm7, [rsp+0x70]
00007431745d54d0  vmovaps xmm8, [rsp+0x80]
00007431745d54d9  vmovaps xmm9, [rsp+0x90]
00007431745d54e2  vmovaps xmm10, [rsp+0xA0]
00007431745d54eb  vmovaps xmm11, [rsp+0xB0]
00007431745d54f4  vmovaps xmm12, [rsp+0xC0]
00007431745d54fd  vmovaps xmm14, [rsp+0xD0]
00007431745d5506  vmovaps xmm15, [rsp+0xE0]
00007431745d550f  add rsp, 0xF0
00007431745d5516  pop r11
00007431745d5518  pop r10
00007431745d551a  pop r9
00007431745d551c  pop r8
00007431745d551e  pop rsi
00007431745d551f  pop rdi
00007431745d5520  pop rdx
00007431745d5521  pop rcx
00007431745d5522  pop rax
00007431745d5523  add rsp, 0x08
00007431745d5527  jmp 0x00007431745D02F7
00007431745d552c  sub rsp, 0x08
00007431745d5530  push rax
00007431745d5531  push rcx
00007431745d5532  push rdx
00007431745d5533  push rdi
00007431745d5534  push rsi
00007431745d5535  push r8
00007431745d5537  push r9
00007431745d5539  push r10
00007431745d553b  push r11
00007431745d553d  sub rsp, 0xF0
00007431745d5544  vmovaps [rsp], xmm0
00007431745d5549  vmovaps [rsp+0x10], xmm1
00007431745d554f  vmovaps [rsp+0x20], xmm2
00007431745d5555  vmovaps [rsp+0x30], xmm3
00007431745d555b  vmovaps [rsp+0x40], xmm4
00007431745d5561  vmovaps [rsp+0x50], xmm5
00007431745d5567  vmovaps [rsp+0x60], xmm6
00007431745d556d  vmovaps [rsp+0x70], xmm7
00007431745d5573  vmovaps [rsp+0x80], xmm8
00007431745d557c  vmovaps [rsp+0x90], xmm9
00007431745d5585  vmovaps [rsp+0xA0], xmm10
00007431745d558e  vmovaps [rsp+0xB0], xmm11
00007431745d5597  vmovaps [rsp+0xC0], xmm12
00007431745d55a0  vmovaps [rsp+0xD0], xmm13
00007431745d55a9  vmovaps [rsp+0xE0], xmm15
00007431745d55b2  sub rsp, 0x30
00007431745d55b6  movaps [rsp], xmm14
00007431745d55bb  movaps [rsp+0x10], xmm1
00007431745d55c0  movaps [rsp+0x20], xmm10
00007431745d55c6  lea rdi, [rsp]
00007431745d55ca  mov esi, 0x00
00007431745d55cf  mov rax, 0x56C40959E530
00007431745d55d9  call rax
00007431745d55db  movaps xmm14, [rsp]
00007431745d55e0  add rsp, 0x30
00007431745d55e4  vmovaps xmm0, [rsp]
00007431745d55e9  vmovaps xmm1, [rsp+0x10]
00007431745d55ef  vmovaps xmm2, [rsp+0x20]
00007431745d55f5  vmovaps xmm3, [rsp+0x30]
00007431745d55fb  vmovaps xmm4, [rsp+0x40]
00007431745d5601  vmovaps xmm5, [rsp+0x50]
00007431745d5607  vmovaps xmm6, [rsp+0x60]
00007431745d560d  vmovaps xmm7, [rsp+0x70]
00007431745d5613  vmovaps xmm8, [rsp+0x80]
00007431745d561c  vmovaps xmm9, [rsp+0x90]
00007431745d5625  vmovaps xmm10, [rsp+0xA0]
00007431745d562e  vmovaps xmm11, [rsp+0xB0]
00007431745d5637  vmovaps xmm12, [rsp+0xC0]
00007431745d5640  vmovaps xmm13, [rsp+0xD0]
00007431745d5649  vmovaps xmm15, [rsp+0xE0]
00007431745d5652  add rsp, 0xF0
00007431745d5659  pop r11
00007431745d565b  pop r10
00007431745d565d  pop r9
00007431745d565f  pop r8
00007431745d5661  pop rsi
00007431745d5662  pop rdi
00007431745d5663  pop rdx
00007431745d5664  pop rcx
00007431745d5665  pop rax
00007431745d5666  add rsp, 0x08
00007431745d566a  jmp 0x00007431745D031A
00007431745d566f  sub rsp, 0x08
00007431745d5673  push rax
00007431745d5674  push rcx
00007431745d5675  push rdx
00007431745d5676  push rdi
00007431745d5677  push rsi
00007431745d5678  push r8
00007431745d567a  push r9
00007431745d567c  push r10
00007431745d567e  push r11
00007431745d5680  sub rsp, 0xF0
00007431745d5687  vmovaps [rsp], xmm0
00007431745d568c  vmovaps [rsp+0x10], xmm2
00007431745d5692  vmovaps [rsp+0x20], xmm3
00007431745d5698  vmovaps [rsp+0x30], xmm4
00007431745d569e  vmovaps [rsp+0x40], xmm5
00007431745d56a4  vmovaps [rsp+0x50], xmm6
00007431745d56aa  vmovaps [rsp+0x60], xmm7
00007431745d56b0  vmovaps [rsp+0x70], xmm8
00007431745d56b6  vmovaps [rsp+0x80], xmm9
00007431745d56bf  vmovaps [rsp+0x90], xmm10
00007431745d56c8  vmovaps [rsp+0xA0], xmm11
00007431745d56d1  vmovaps [rsp+0xB0], xmm12
00007431745d56da  vmovaps [rsp+0xC0], xmm13
00007431745d56e3  vmovaps [rsp+0xD0], xmm14
00007431745d56ec  vmovaps [rsp+0xE0], xmm15
00007431745d56f5  sub rsp, 0x30
00007431745d56f9  movaps [rsp], xmm1
00007431745d56fd  movaps [rsp+0x10], xmm7
00007431745d5702  movaps [rsp+0x20], xmm11
00007431745d5708  lea rdi, [rsp]
00007431745d570c  mov esi, 0x00
00007431745d5711  mov rax, 0x56C40959E530
00007431745d571b  call rax
00007431745d571d  movaps xmm1, [rsp]
00007431745d5721  add rsp, 0x30
00007431745d5725  vmovaps xmm0, [rsp]
00007431745d572a  vmovaps xmm2, [rsp+0x10]
00007431745d5730  vmovaps xmm3, [rsp+0x20]
00007431745d5736  vmovaps xmm4, [rsp+0x30]
00007431745d573c  vmovaps xmm5, [rsp+0x40]
00007431745d5742  vmovaps xmm6, [rsp+0x50]
00007431745d5748  vmovaps xmm7, [rsp+0x60]
00007431745d574e  vmovaps xmm8, [rsp+0x70]
00007431745d5754  vmovaps xmm9, [rsp+0x80]
00007431745d575d  vmovaps xmm10, [rsp+0x90]
00007431745d5766  vmovaps xmm11, [rsp+0xA0]
00007431745d576f  vmovaps xmm12, [rsp+0xB0]
00007431745d5778  vmovaps xmm13, [rsp+0xC0]
00007431745d5781  vmovaps xmm14, [rsp+0xD0]
00007431745d578a  vmovaps xmm15, [rsp+0xE0]
00007431745d5793  add rsp, 0xF0
00007431745d579a  pop r11
00007431745d579c  pop r10
00007431745d579e  pop r9
00007431745d57a0  pop r8
00007431745d57a2  pop rsi
00007431745d57a3  pop rdi
00007431745d57a4  pop rdx
00007431745d57a5  pop rcx
00007431745d57a6  pop rax
00007431745d57a7  add rsp, 0x08
00007431745d57ab  jmp 0x00007431745D033B
00007431745d57b0  call 0x000074317440E880
00007431745d57b5  jmp 0x00007431745D034E
00007431745d57ba  call 0x000074317440C380
00007431745d57bf  jmp 0x00007431745D0359
00007431745d57c4  call 0x000074317440D600
00007431745d57c9  jmp 0x00007431745D0364
00007431745d57ce  call 0x00007431743FF540
00007431745d57d3  jmp 0x00007431745D036F
00007431745d57d8  int3
00007431745d57d9  nop [rax], eax
00007431745d57e0  mov rax, [r15+0x40]
00007431745d57e4  mov r14, [r15+0x58]
00007431745d57e8  lea r12, [rax+r14*1]
00007431745d57ec  movaps xmm1, [r15+0x1D0]
00007431745d57f4  vmovaps [rsp+0x10], xmm1
00007431745d57fa  vmovaps xmm15, [rsp+0x10]
00007431745d5800  por xmm1, xmm15
00007431745d5805  movaps xmm14, [r15+0x1A0]
00007431745d580d  vmovaps [rsp+0x10], xmm14
00007431745d5813  vmovaps xmm13, [rsp+0x10]
00007431745d5819  por xmm14, xmm13
00007431745d581e  lea rax, [r12+0x30]
00007431745d5823  mov r11, [r13+rax*1]
00007431745d5828  lea rax, [r12+0x38]
00007431745d582d  mov r10, [r13+rax*1]
00007431745d5832  movq xmm13, r11
00007431745d5837  movq xmm12, r10
00007431745d583c  movq xmm13, xmm13
00007431745d5841  vmovaps [rsp+0x10], xmm13
00007431745d5847  movq xmm13, xmm13
00007431745d584c  movaps [r15+0x130], xmm13
00007431745d5854  movq xmm12, xmm12
00007431745d5859  vmovaps [rsp+0x20], xmm12
00007431745d585f  movq xmm12, xmm12
00007431745d5864  movaps [r15+0x280], xmm12
00007431745d586c  movaps xmm13, [r15+0x270]
00007431745d5874  vmovaps [rsp+0x30], xmm13
00007431745d587a  vmovaps xmm12, [rsp+0x30]
00007431745d5880  por xmm13, xmm12
00007431745d5885  lea rax, [r12+0x20]
00007431745d588a  mov r11, [r13+rax*1]
00007431745d588f  lea rax, [r12+0x28]
00007431745d5894  mov r10, [r13+rax*1]
00007431745d5899  movq xmm12, r11
00007431745d589e  movq xmm11, r10
00007431745d58a3  movq xmm12, xmm12
00007431745d58a8  vmovaps [rsp+0x30], xmm12
00007431745d58ae  movq xmm12, xmm12
00007431745d58b3  movaps [r15+0x150], xmm12
00007431745d58bb  movq xmm11, xmm11
00007431745d58c0  vmovaps [rsp+0x40], xmm11
00007431745d58c6  movq xmm11, xmm11
00007431745d58cb  movaps [r15+0x140], xmm11
00007431745d58d3  lea rax, [r12+0x10]
00007431745d58d8  mov r11, [r13+rax*1]
00007431745d58dd  lea rax, [r12+0x18]
00007431745d58e2  mov r10, [r13+rax*1]
00007431745d58e7  movq xmm12, r11
00007431745d58ec  movq xmm11, r10
00007431745d58f1  movq xmm12, xmm12
00007431745d58f6  vmovaps [rsp+0x50], xmm12
00007431745d58fc  movq xmm12, xmm12
00007431745d5901  movaps [r15+0x170], xmm12
00007431745d5909  movq xmm11, xmm11
00007431745d590e  vmovaps [rsp+0x60], xmm11
00007431745d5914  movq xmm11, xmm11
00007431745d5919  movaps [r15+0x160], xmm11
00007431745d5921  mov rax, [r13+r12*1]
00007431745d5926  vmovq xmm12, rax
00007431745d592b  vpbroadcastq xmm12, xmm12
00007431745d5930  lea rax, [r12+0x08]
00007431745d5935  mov r12, [r13+rax*1]
00007431745d593a  movq xmm11, r12
00007431745d593f  movaps [r15+0x230], xmm11
00007431745d5947  mov rax, [r15+0xF8]
00007431745d594e  lea r12, [rax+0x50]
00007431745d5952  movups xmm11, [r13+r12*1]
00007431745d5958  lea r12, [rax+0x60]
00007431745d595c  movups xmm10, [r13+r12*1]
00007431745d5962  lea r12, [rax+0x30]
00007431745d5966  movups xmm9, [r13+r12*1]
00007431745d596c  mov r12, [r15+0x50]
00007431745d5970  lea r11, [r12+r14*1]
00007431745d5974  mov [r15+0x60], r11
00007431745d5978  lea r12, [r14+0x40]
00007431745d597c  mov [r15+0x58], r12
00007431745d5980  movaps xmm8, xmm12
00007431745d5984  mulpd xmm8, xmm15
00007431745d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007431745d598f  ptest xmm7, xmm7
00007431745d5994  jnz 0x00007431745D67B7
00007431745d599a  movq xmm15, qword ptr [r15+0x230]
00007431745d59a3  vmovaps [rsp+0x70], xmm15
00007431745d59a9  vpermilpd xmm15, xmm15, 0x00
00007431745d59af  movaps xmm7, xmm9
00007431745d59b3  mulpd xmm7, xmm15
00007431745d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007431745d59bd  ptest xmm6, xmm6
00007431745d59c2  jnz 0x00007431745D68FB
00007431745d59c8  vxorps xmm15, xmm15, xmm15
00007431745d59cd  vpbroadcastq xmm15, xmm15
00007431745d59d2  movaps xmm9, xmm12
00007431745d59d6  mulpd xmm9, xmm10
00007431745d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007431745d59e1  ptest xmm6, xmm6
00007431745d59e6  jnz 0x00007431745D6A3D
00007431745d59ec  movaps xmm10, xmm12
00007431745d59f0  mulpd xmm10, xmm11
00007431745d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007431745d59fb  ptest xmm6, xmm6
00007431745d5a00  jnz 0x00007431745D6B81
00007431745d5a06  movaps xmm11, [r15+0x1F0]
00007431745d5a0e  movaps xmm6, xmm12
00007431745d5a12  mulpd xmm6, xmm11
00007431745d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007431745d5a1c  ptest xmm5, xmm5
00007431745d5a21  jnz 0x00007431745D6CC5
00007431745d5a27  movaps xmm12, [r15+0x2A0]
00007431745d5a2f  vmovaps [rsp+0x80], xmm12
00007431745d5a38  vmovaps xmm11, [rsp+0x80]
00007431745d5a41  por xmm12, xmm11
00007431745d5a46  movaps xmm11, [r15+0x250]
00007431745d5a4e  vmovaps [rsp+0x80], xmm11
00007431745d5a57  vmovaps xmm5, [rsp+0x80]
00007431745d5a60  por xmm11, xmm5
00007431745d5a65  vmovaps xmm4, [rsp+0x70]
00007431745d5a6b  vpermilpd xmm4, xmm4, 0x00
00007431745d5a71  movaps xmm3, xmm5
00007431745d5a74  mulpd xmm3, xmm4
00007431745d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007431745d5a7d  ptest xmm2, xmm2
00007431745d5a82  jnz 0x00007431745D6E07
00007431745d5a88  mov [rsp+0x80], rax
00007431745d5a90  xor eax, eax
00007431745d5a92  mov r14d, 0x200
00007431745d5a98  cmp r12, r14
00007431745d5a9b  cmc
00007431745d5a9c  lahf
00007431745d5a9d  seto al
00007431745d5aa0  mov [r15+0x108], eax
00007431745d5aa7  movaps xmm5, xmm8
00007431745d5aab  addpd xmm5, xmm15
00007431745d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007431745d5ab5  ptest xmm4, xmm4
00007431745d5aba  jnz 0x00007431745D6F47
00007431745d5ac0  movaps xmm8, [r15+0x1B0]
00007431745d5ac8  movaps xmm4, xmm9
00007431745d5acc  addpd xmm4, xmm8
00007431745d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007431745d5ad6  ptest xmm2, xmm2
00007431745d5adb  jnz 0x00007431745D7089
00007431745d5ae1  movaps xmm9, xmm10
00007431745d5ae5  addpd xmm9, xmm8
00007431745d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007431745d5af0  ptest xmm2, xmm2
00007431745d5af5  jnz 0x00007431745D71CB
00007431745d5afb  movaps xmm10, [r15+0x2F0]
00007431745d5b03  vmovaps [rsp+0x90], xmm10
00007431745d5b0c  vmovaps xmm8, [rsp+0x90]
00007431745d5b15  por xmm10, xmm8
00007431745d5b1a  movaps xmm8, [r15+0x2E0]
00007431745d5b22  vmovaps [rsp+0x90], xmm8
00007431745d5b2b  vmovaps xmm2, [rsp+0x90]
00007431745d5b34  por xmm8, xmm2
00007431745d5b39  movaps xmm2, [r15+0x2D0]
00007431745d5b41  vmovaps [rsp+0x90], xmm2
00007431745d5b4a  vmovaps [rsp+0xA0], xmm1
00007431745d5b53  vmovaps xmm1, [rsp+0x90]
00007431745d5b5c  por xmm2, xmm1
00007431745d5b60  movaps xmm1, [r15+0x200]
00007431745d5b68  vmovaps [rsp+0x90], xmm1
00007431745d5b71  vmovaps [rsp+0xB0], xmm15
00007431745d5b7a  vmovaps xmm15, [rsp+0x90]
00007431745d5b83  por xmm1, xmm15
00007431745d5b88  movaps xmm15, [r15+0x1C0]
00007431745d5b90  vmovaps [rsp+0x90], xmm15
00007431745d5b99  vmovaps [rsp+0xC0], xmm1
00007431745d5ba2  vmovaps xmm1, [rsp+0x90]
00007431745d5bab  por xmm15, xmm1
00007431745d5bb0  movaps xmm1, [r15+0x190]
00007431745d5bb8  vmovaps [rsp+0x90], xmm1
00007431745d5bc1  vmovaps [rsp+0xD0], xmm15
00007431745d5bca  vmovaps xmm15, [rsp+0x90]
00007431745d5bd3  por xmm1, xmm15
00007431745d5bd8  movaps xmm15, [r15+0x300]
00007431745d5be0  vmovaps [rsp+0x90], xmm15
00007431745d5be9  vmovaps [rsp+0xE0], xmm1
00007431745d5bf2  vmovaps xmm1, [rsp+0x90]
00007431745d5bfb  por xmm15, xmm1
00007431745d5c00  mov rax, [rsp+0x80]
00007431745d5c08  lea r14, [rax+0xA0]
00007431745d5c0f  movups xmm1, [r13+r14*1]
00007431745d5c15  lea r14, [rax+0xB0]
00007431745d5c1c  vmovaps [rsp+0x80], xmm1
00007431745d5c25  movups xmm1, [r13+r14*1]
00007431745d5c2b  vmovaps [rsp+0x90], xmm1
00007431745d5c34  vmovaps [rsp+0xF0], xmm15
00007431745d5c3d  vmovaps xmm15, [rsp+0xB0]
00007431745d5c46  vmovaps [rsp+0xB0], xmm14
00007431745d5c4f  movaps xmm1, xmm6
00007431745d5c52  addpd xmm1, xmm15
00007431745d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007431745d5c5c  ptest xmm14, xmm14
00007431745d5c62  jnz 0x00007431745D7323
00007431745d5c68  lea r14, [rax+0xF0]
00007431745d5c6f  movups xmm15, [r13+r14*1]
00007431745d5c75  movaps xmm14, xmm4
00007431745d5c79  addpd xmm14, xmm3
00007431745d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007431745d5c84  ptest xmm6, xmm6
00007431745d5c89  jnz 0x00007431745D746E
00007431745d5c8f  movaps xmm6, xmm9
00007431745d5c93  addpd xmm6, xmm7
00007431745d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007431745d5c9c  ptest xmm4, xmm4
00007431745d5ca1  jnz 0x00007431745D75B0
00007431745d5ca7  vmovaps xmm9, [rsp+0x70]
00007431745d5cad  vpermilpd xmm9, xmm9, 0x00
00007431745d5cb3  vmovaps xmm4, [rsp+0x90]
00007431745d5cbc  movaps xmm7, xmm4
00007431745d5cbf  mulpd xmm7, xmm9
00007431745d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007431745d5cc9  ptest xmm3, xmm3
00007431745d5cce  jnz 0x00007431745D76F1
00007431745d5cd4  vmovaps xmm9, [rsp+0x50]
00007431745d5cda  vpermilpd xmm9, xmm9, 0x00
00007431745d5ce0  movaps xmm4, xmm15
00007431745d5ce4  mulpd xmm4, xmm9
00007431745d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007431745d5cee  ptest xmm3, xmm3
00007431745d5cf3  jnz 0x00007431745D7832
00007431745d5cf9  lea r14, [rax+0xE0]
00007431745d5d00  movups xmm15, [r13+r14*1]
00007431745d5d06  vmovaps xmm9, [rsp+0x70]
00007431745d5d0c  vpermilpd xmm9, xmm9, 0x00
00007431745d5d12  vmovaps [rsp+0x70], xmm1
00007431745d5d18  vmovaps xmm1, [rsp+0x80]
00007431745d5d21  vmovaps [rsp+0x80], xmm15
00007431745d5d2a  movaps xmm3, xmm1
00007431745d5d2d  mulpd xmm3, xmm9
00007431745d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007431745d5d37  ptest xmm15, xmm15
00007431745d5d3d  jnz 0x00007431745D797E
00007431745d5d43  vmovaps xmm1, [rsp+0xF0]
00007431745d5d4c  vmovaps xmm15, [rsp+0xF0]
00007431745d5d55  por xmm1, xmm15
00007431745d5d5a  movaps [r15+0x300], xmm1
00007431745d5d62  vmovaps xmm15, [rsp+0xE0]
00007431745d5d6b  vmovaps xmm9, [rsp+0xE0]
00007431745d5d74  por xmm15, xmm9
00007431745d5d79  movaps [r15+0x190], xmm15
00007431745d5d81  vmovaps xmm9, [rsp+0x50]
00007431745d5d87  vpermilpd xmm9, xmm9, 0x00
00007431745d5d8d  vmovaps [rsp+0x90], xmm1
00007431745d5d96  vmovaps [rsp+0xE0], xmm15
00007431745d5d9f  vmovaps xmm15, [rsp+0x80]
00007431745d5da8  vmovaps [rsp+0x80], xmm14
00007431745d5db1  movaps xmm1, xmm15
00007431745d5db5  mulpd xmm1, xmm9
00007431745d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007431745d5dbf  ptest xmm14, xmm14
00007431745d5dc5  jnz 0x00007431745D7ABF
00007431745d5dcb  lea r14, [rax+0x90]
00007431745d5dd2  movups xmm15, [r13+r14*1]
00007431745d5dd8  vmovaps xmm14, [rsp+0xD0]
00007431745d5de1  vmovaps xmm9, [rsp+0xD0]
00007431745d5dea  por xmm14, xmm9
00007431745d5def  movaps [r15+0x1C0], xmm14
00007431745d5df7  vmovaps xmm9, [rsp+0xC0]
00007431745d5e00  vmovaps [rsp+0xD0], xmm1
00007431745d5e09  vmovaps xmm1, [rsp+0xC0]
00007431745d5e12  por xmm9, xmm1
00007431745d5e17  movaps [r15+0x200], xmm9
00007431745d5e1f  vmovaps [rsp+0xC0], xmm2
00007431745d5e28  vmovaps xmm1, [rsp+0xC0]
00007431745d5e31  por xmm2, xmm1
00007431745d5e35  movaps [r15+0x2D0], xmm2
00007431745d5e3d  vmovaps [rsp+0xC0], xmm8
00007431745d5e46  vmovaps xmm1, [rsp+0xC0]
00007431745d5e4f  por xmm8, xmm1
00007431745d5e54  movaps [r15+0x2E0], xmm8
00007431745d5e5c  vmovaps [rsp+0xC0], xmm15
00007431745d5e65  movaps xmm1, xmm5
00007431745d5e68  addpd xmm1, xmm7
00007431745d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007431745d5e71  ptest xmm15, xmm15
00007431745d5e77  jnz 0x00007431745D7C0B
00007431745d5e7d  vmovaps xmm15, [rsp+0x50]
00007431745d5e83  vpermilpd xmm15, xmm15, 0x00
00007431745d5e89  vmovaps xmm5, [rsp+0xC0]
00007431745d5e92  vmovaps [rsp+0xC0], xmm1
00007431745d5e9b  movaps xmm7, xmm5
00007431745d5e9e  mulpd xmm7, xmm15
00007431745d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007431745d5ea8  ptest xmm1, xmm1
00007431745d5ead  jnz 0x00007431745D7D4B
00007431745d5eb3  lea r14, [rax+0x80]
00007431745d5eba  movups xmm1, [r13+r14*1]
00007431745d5ec0  vmovaps xmm5, [rsp+0x70]
00007431745d5ec6  vmovaps [rsp+0x70], xmm1
00007431745d5ecc  movaps xmm15, xmm5
00007431745d5ed0  addpd xmm15, xmm3
00007431745d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007431745d5edb  ptest xmm1, xmm1
00007431745d5ee0  jnz 0x00007431745D7E96
00007431745d5ee6  vmovaps xmm5, [rsp+0x80]
00007431745d5eef  movaps xmm1, xmm5
00007431745d5ef2  addpd xmm1, xmm4
00007431745d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007431745d5efb  ptest xmm3, xmm3
00007431745d5f00  jnz 0x00007431745D7FD8
00007431745d5f06  vmovaps [rsp+0x80], xmm10
00007431745d5f0f  vmovaps xmm5, [rsp+0x80]
00007431745d5f18  por xmm10, xmm5
00007431745d5f1d  movaps [r15+0x2F0], xmm10
00007431745d5f25  vmovaps xmm5, [rsp+0x50]
00007431745d5f2b  vpermilpd xmm5, xmm5, 0x00
00007431745d5f31  vmovaps xmm3, [rsp+0x70]
00007431745d5f37  vmovaps [rsp+0x50], xmm1
00007431745d5f3d  movaps xmm4, xmm3
00007431745d5f40  mulpd xmm4, xmm5
00007431745d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007431745d5f49  ptest xmm1, xmm1
00007431745d5f4e  jnz 0x00007431745D8118
00007431745d5f54  lea r14, [rax+0xD0]
00007431745d5f5b  movups xmm1, [r13+r14*1]
00007431745d5f61  vmovaps xmm3, [rsp+0xD0]
00007431745d5f6a  vmovaps [rsp+0x70], xmm1
00007431745d5f70  movaps xmm5, xmm6
00007431745d5f73  addpd xmm5, xmm3
00007431745d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007431745d5f7c  ptest xmm1, xmm1
00007431745d5f81  jnz 0x00007431745D8262
00007431745d5f87  vmovaps xmm1, [rsp+0x60]
00007431745d5f8d  vpermilpd xmm1, xmm1, 0x00
00007431745d5f93  movaps xmm6, xmm9
00007431745d5f97  mulpd xmm6, xmm1
00007431745d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007431745d5fa0  ptest xmm3, xmm3
00007431745d5fa5  jnz 0x00007431745D83A2
00007431745d5fab  movaps [r15+0x260], xmm6
00007431745d5fb3  vxorps xmm1, xmm1, xmm1
00007431745d5fb7  vpbroadcastq xmm1, xmm1
00007431745d5fbc  movaps [r15+0x1B0], xmm1
00007431745d5fc4  vmovaps xmm1, [rsp+0x60]
00007431745d5fca  vpermilpd xmm1, xmm1, 0x00
00007431745d5fd0  vmovaps xmm3, [rsp+0x70]
00007431745d5fd6  vmovaps [rsp+0x70], xmm15
00007431745d5fdc  movaps xmm9, xmm3
00007431745d5fe0  mulpd xmm9, xmm1
00007431745d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007431745d5feb  ptest xmm15, xmm15
00007431745d5ff1  jnz 0x00007431745D84E3
00007431745d5ff7  lea r14, [rax+0xC0]
00007431745d5ffe  movups xmm1, [r13+r14*1]
00007431745d6004  vmovaps xmm3, [rsp+0xC0]
00007431745d600d  vmovaps [rsp+0x80], xmm1
00007431745d6016  movaps xmm15, xmm3
00007431745d601a  addpd xmm15, xmm7
00007431745d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007431745d6025  ptest xmm1, xmm1
00007431745d602a  jnz 0x00007431745D862F
00007431745d6030  vmovaps [rsp+0xC0], xmm13
00007431745d6039  vmovaps xmm1, [rsp+0xC0]
00007431745d6042  por xmm13, xmm1
00007431745d6047  movaps [r15+0x270], xmm13
00007431745d604f  vmovaps xmm1, [rsp+0xB0]
00007431745d6058  vmovaps xmm7, [rsp+0xB0]
00007431745d6061  por xmm1, xmm7
00007431745d6065  movaps [r15+0x1A0], xmm1
00007431745d606d  vmovaps xmm1, [rsp+0x60]
00007431745d6073  vpermilpd xmm1, xmm1, 0x00
00007431745d6079  vmovaps [rsp+0xB0], xmm1
00007431745d6082  vmovaps xmm1, [rsp+0x80]
00007431745d608b  vmovaps [rsp+0x80], xmm15
00007431745d6094  vmovaps xmm15, [rsp+0xB0]
00007431745d609d  vmovaps [rsp+0xB0], xmm14
00007431745d60a6  movaps xmm3, xmm1
00007431745d60a9  mulpd xmm3, xmm15
00007431745d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007431745d60b3  ptest xmm14, xmm14
00007431745d60b9  jnz 0x00007431745D8771
00007431745d60bf  lea r14, [rax+0x20]
00007431745d60c3  movups xmm1, [r13+r14*1]
00007431745d60c9  movaps [r15+0x110], xmm1
00007431745d60d1  vmovaps xmm14, [rsp+0x70]
00007431745d60d7  vmovaps [rsp+0x70], xmm1
00007431745d60dd  movaps xmm15, xmm14
00007431745d60e1  addpd xmm15, xmm4
00007431745d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007431745d60ec  ptest xmm1, xmm1
00007431745d60f1  jnz 0x00007431745D88BC
00007431745d60f7  vmovaps xmm1, [rsp+0x60]
00007431745d60fd  vpermilpd xmm1, xmm1, 0x00
00007431745d6103  movaps xmm14, xmm2
00007431745d6107  mulpd xmm14, xmm1
00007431745d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007431745d6112  ptest xmm4, xmm4
00007431745d6117  jnz 0x00007431745D89FF
00007431745d611d  vmovaps xmm4, [rsp+0x50]
00007431745d6123  movaps xmm1, xmm4
00007431745d6126  addpd xmm1, xmm9
00007431745d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007431745d6130  ptest xmm2, xmm2
00007431745d6135  jnz 0x00007431745D8B41
00007431745d613b  vmovaps xmm9, [rsp+0x30]
00007431745d6141  vpermilpd xmm9, xmm9, 0x00
00007431745d6147  vmovaps xmm2, [rsp+0x70]
00007431745d614d  vmovaps [rsp+0x50], xmm1
00007431745d6153  movaps xmm4, xmm2
00007431745d6156  mulpd xmm4, xmm9
00007431745d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007431745d6160  ptest xmm1, xmm1
00007431745d6165  jnz 0x00007431745D8C82
00007431745d616b  vmovaps xmm1, [rsp+0x30]
00007431745d6171  vpermilpd xmm1, xmm1, 0x00
00007431745d6177  vmovaps xmm2, [rsp+0x90]
00007431745d6180  vmovaps [rsp+0x60], xmm15
00007431745d6186  movaps xmm9, xmm2
00007431745d618a  mulpd xmm9, xmm1
00007431745d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007431745d6195  ptest xmm15, xmm15
00007431745d619b  jnz 0x00007431745D8DC3
00007431745d61a1  vmovaps xmm15, [rsp+0x80]
00007431745d61aa  movaps xmm1, xmm15
00007431745d61ae  addpd xmm1, xmm6
00007431745d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007431745d61b7  ptest xmm2, xmm2
00007431745d61bc  jnz 0x00007431745D8F05
00007431745d61c2  movaps xmm15, xmm5
00007431745d61c6  addpd xmm15, xmm3
00007431745d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007431745d61d1  ptest xmm6, xmm6
00007431745d61d6  jnz 0x00007431745D9046
00007431745d61dc  vmovaps xmm6, [rsp+0x30]
00007431745d61e2  vpermilpd xmm6, xmm6, 0x00
00007431745d61e8  movaps xmm5, xmm8
00007431745d61ec  mulpd xmm5, xmm6
00007431745d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007431745d61f5  ptest xmm3, xmm3
00007431745d61fa  jnz 0x00007431745D9188
00007431745d6200  vmovaps xmm8, [rsp+0x30]
00007431745d6206  vpermilpd xmm8, xmm8, 0x00
00007431745d620c  movaps xmm6, xmm10
00007431745d6210  mulpd xmm6, xmm8
00007431745d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007431745d621a  ptest xmm3, xmm3
00007431745d621f  jnz 0x00007431745D92C9
00007431745d6225  vmovaps xmm8, [rsp+0x60]
00007431745d622b  movaps xmm10, xmm8
00007431745d622f  addpd xmm10, xmm14
00007431745d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007431745d623a  ptest xmm3, xmm3
00007431745d623f  jnz 0x00007431745D940B
00007431745d6245  vmovaps xmm8, [rsp+0x50]
00007431745d624b  movaps xmm14, xmm8
00007431745d624f  addpd xmm14, xmm4
00007431745d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007431745d625a  ptest xmm3, xmm3
00007431745d625f  jnz 0x00007431745D954F
00007431745d6265  vmovaps xmm8, [rsp+0x40]
00007431745d626b  vpermilpd xmm8, xmm8, 0x00
00007431745d6271  movaps xmm4, xmm13
00007431745d6275  mulpd xmm4, xmm8
00007431745d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007431745d627f  ptest xmm3, xmm3
00007431745d6284  jnz 0x00007431745D9692
00007431745d628a  movaps xmm13, xmm15
00007431745d628e  addpd xmm13, xmm9
00007431745d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007431745d6299  ptest xmm8, xmm8
00007431745d629f  jnz 0x00007431745D97D4
00007431745d62a5  movaps xmm15, xmm1
00007431745d62a9  addpd xmm15, xmm5
00007431745d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007431745d62b4  ptest xmm9, xmm9
00007431745d62ba  jnz 0x00007431745D9918
00007431745d62c0  vmovaps [rsp+0x30], xmm11
00007431745d62c6  vmovaps xmm1, [rsp+0x30]
00007431745d62cc  por xmm11, xmm1
00007431745d62d1  movaps [r15+0x250], xmm11
00007431745d62d9  vmovaps [rsp+0x30], xmm12
00007431745d62df  vmovaps xmm1, [rsp+0x30]
00007431745d62e5  por xmm12, xmm1
00007431745d62ea  movaps [r15+0x2A0], xmm12
00007431745d62f2  vmovaps xmm1, [rsp+0xA0]
00007431745d62fb  vmovaps xmm11, [rsp+0xA0]
00007431745d6304  por xmm1, xmm11
00007431745d6309  movaps [r15+0x1D0], xmm1
00007431745d6311  lea r14, [rax+0x40]
00007431745d6315  movups xmm1, [r13+r14*1]
00007431745d631b  movaps [r15+0x2C0], xmm1
00007431745d6323  vmovaps xmm11, [rsp+0x40]
00007431745d6329  vpermilpd xmm11, xmm11, 0x00
00007431745d632f  vmovaps xmm8, [rsp+0xE0]
00007431745d6338  movaps xmm9, xmm8
00007431745d633c  mulpd xmm9, xmm11
00007431745d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007431745d6347  ptest xmm5, xmm5
00007431745d634c  jnz 0x00007431745D9A64
00007431745d6352  movaps xmm11, xmm10
00007431745d6356  addpd xmm11, xmm6
00007431745d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007431745d6361  ptest xmm8, xmm8
00007431745d6367  jnz 0x00007431745D9BA8
00007431745d636d  movaps xmm10, xmm14
00007431745d6371  addpd xmm10, xmm4
00007431745d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007431745d637c  ptest xmm8, xmm8
00007431745d6382  jnz 0x00007431745D9CEB
00007431745d6388  vmovaps xmm14, [rsp+0x40]
00007431745d638e  vpermilpd xmm14, xmm14, 0x00
00007431745d6394  movaps xmm8, xmm1
00007431745d6398  mulpd xmm8, xmm14
00007431745d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007431745d63a3  ptest xmm6, xmm6
00007431745d63a8  jnz 0x00007431745D9E2E
00007431745d63ae  movaps xmm1, [r15+0x2B0]
00007431745d63b6  vmovaps xmm14, [rsp+0x40]
00007431745d63bc  vpermilpd xmm14, xmm14, 0x00
00007431745d63c2  movaps xmm6, xmm1
00007431745d63c5  mulpd xmm6, xmm14
00007431745d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007431745d63cf  ptest xmm5, xmm5
00007431745d63d4  jnz 0x00007431745D9F71
00007431745d63da  vmovaps xmm1, [rsp+0x10]
00007431745d63e0  vpermilpd xmm1, xmm1, 0x00
00007431745d63e6  movaps xmm14, xmm12
00007431745d63ea  mulpd xmm14, xmm1
00007431745d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007431745d63f5  ptest xmm5, xmm5
00007431745d63fa  jnz 0x00007431745DA0B2
00007431745d6400  movaps xmm1, xmm13
00007431745d6404  addpd xmm1, xmm9
00007431745d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007431745d640e  ptest xmm12, xmm12
00007431745d6414  jnz 0x00007431745DA1F5
00007431745d641a  vmovaps xmm13, [rsp+0x10]
00007431745d6420  vpermilpd xmm13, xmm13, 0x00
00007431745d6426  movaps xmm12, xmm7
00007431745d642a  mulpd xmm12, xmm13
00007431745d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007431745d6435  ptest xmm9, xmm9
00007431745d643b  jnz 0x00007431745DA337
00007431745d6441  movaps xmm13, xmm15
00007431745d6445  addpd xmm13, xmm8
00007431745d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007431745d6450  ptest xmm9, xmm9
00007431745d6456  jnz 0x00007431745DA47A
00007431745d645c  movaps xmm15, [r15+0x290]
00007431745d6464  vmovaps xmm9, [rsp+0x10]
00007431745d646a  vpermilpd xmm9, xmm9, 0x00
00007431745d6470  movaps xmm8, xmm15
00007431745d6474  mulpd xmm8, xmm9
00007431745d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007431745d647f  ptest xmm7, xmm7
00007431745d6484  jnz 0x00007431745DA5BE
00007431745d648a  movaps xmm15, xmm11
00007431745d648e  addpd xmm15, xmm6
00007431745d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007431745d6499  ptest xmm9, xmm9
00007431745d649f  jnz 0x00007431745DA702
00007431745d64a5  movaps xmm11, [r15+0x1E0]
00007431745d64ad  vmovaps xmm9, [rsp+0x10]
00007431745d64b3  vpermilpd xmm9, xmm9, 0x00
00007431745d64b9  movaps xmm7, xmm11
00007431745d64bd  mulpd xmm7, xmm9
00007431745d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007431745d64c7  ptest xmm6, xmm6
00007431745d64cc  jnz 0x00007431745DA845
00007431745d64d2  movaps xmm11, xmm10
00007431745d64d6  addpd xmm11, xmm14
00007431745d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007431745d64e1  ptest xmm9, xmm9
00007431745d64e7  jnz 0x00007431745DA987
00007431745d64ed  lea r14, [rax+0x70]
00007431745d64f1  movups xmm14, [r13+r14*1]
00007431745d64f7  movaps [r15+0x240], xmm14
00007431745d64ff  movaps xmm10, xmm1
00007431745d6503  addpd xmm10, xmm12
00007431745d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007431745d650e  ptest xmm9, xmm9
00007431745d6514  jnz 0x00007431745DAAD5
00007431745d651a  movaps [r15+0x170], xmm10
00007431745d6522  vmovaps xmm1, [rsp+0x20]
00007431745d6528  vpermilpd xmm1, xmm1, 0x00
00007431745d652e  movaps xmm12, xmm14
00007431745d6532  mulpd xmm12, xmm1
00007431745d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007431745d653d  ptest xmm9, xmm9
00007431745d6543  jnz 0x00007431745DAC18
00007431745d6549  vmovaps xmm1, [rsp+0x20]
00007431745d654f  vpermilpd xmm1, xmm1, 0x00
00007431745d6555  vmovaps xmm9, [rsp+0xB0]
00007431745d655e  movaps xmm14, xmm9
00007431745d6562  mulpd xmm14, xmm1
00007431745d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007431745d656d  ptest xmm6, xmm6
00007431745d6572  jnz 0x00007431745DAD5B
00007431745d6578  movaps [r15+0x180], xmm14
00007431745d6580  movaps xmm1, xmm13
00007431745d6584  addpd xmm1, xmm8
00007431745d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007431745d658e  ptest xmm9, xmm9
00007431745d6594  jnz 0x00007431745DAE9E
00007431745d659a  movaps [r15+0x210], xmm1
00007431745d65a2  movups xmm13, [r13+rax*1]
00007431745d65a8  lea r14, [rax+0x10]
00007431745d65ac  movups xmm9, [r13+r14*1]
00007431745d65b2  movaps [r15+0x230], xmm9
00007431745d65ba  movaps xmm8, xmm15
00007431745d65be  addpd xmm8, xmm7
00007431745d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007431745d65c9  ptest xmm6, xmm6
00007431745d65ce  jnz 0x00007431745DAFF4
00007431745d65d4  movaps [r15+0x130], xmm8
00007431745d65dc  vmovaps xmm15, [rsp+0x20]
00007431745d65e2  vpermilpd xmm15, xmm15, 0x00
00007431745d65e8  movaps xmm7, xmm9
00007431745d65ec  mulpd xmm7, xmm15
00007431745d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007431745d65f6  ptest xmm6, xmm6
00007431745d65fb  jnz 0x00007431745DB137
00007431745d6601  movaps [r15+0x220], xmm7
00007431745d6609  vmovaps xmm15, [rsp+0x20]
00007431745d660f  vpermilpd xmm15, xmm15, 0x00
00007431745d6615  movaps xmm9, xmm13
00007431745d6619  mulpd xmm9, xmm15
00007431745d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007431745d6624  ptest xmm6, xmm6
00007431745d6629  jnz 0x00007431745DB279
00007431745d662f  movaps xmm15, xmm11
00007431745d6633  addpd xmm15, xmm12
00007431745d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007431745d663e  ptest xmm13, xmm13
00007431745d6644  jnz 0x00007431745DB3BD
00007431745d664a  movaps [r15+0x140], xmm15
00007431745d6652  movaps xmm13, xmm10
00007431745d6656  addpd xmm13, xmm14
00007431745d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007431745d6661  ptest xmm12, xmm12
00007431745d6667  jnz 0x00007431745DB501
00007431745d666d  movaps [r15+0x150], xmm13
00007431745d6675  movaps xmm14, xmm1
00007431745d6679  addpd xmm14, xmm7
00007431745d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007431745d6684  ptest xmm12, xmm12
00007431745d668a  jnz 0x00007431745DB645
00007431745d6690  movaps [r15+0x160], xmm14
00007431745d6698  movaps xmm1, xmm8
00007431745d669c  addpd xmm1, xmm9
00007431745d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007431745d66a6  ptest xmm12, xmm12
00007431745d66ac  jnz 0x00007431745DB787
00007431745d66b2  movaps [r15+0x120], xmm1
00007431745d66ba  movups [r13+r11*1], xmm15
00007431745d66c0  lea rax, [r11+0x10]
00007431745d66c4  movups [r13+rax*1], xmm13
00007431745d66ca  lea rax, [r11+0x20]
00007431745d66ce  movups [r13+rax*1], xmm14
00007431745d66d4  lea rax, [r11+0x30]
00007431745d66d8  movups [r13+rax*1], xmm1
00007431745d66de  mov eax, [r15+0x108]
00007431745d66e5  sahf
00007431745d66e6  jnz 0x00007431745D6718
00007431745d66e8  cmp dword ptr [r15+0x318], 0x00
00007431745d66f0  jz 0x00007431745DB900
00007431745d66f6  nop [rax+rax*1], ax
00007431745d66ff  nop [rax+rax*1], eax
00007431745d6707  mov eax, 0x410444
00007431745d670c  mov [r15+0x100], rax
00007431745d6713  jmp 0x00007431743FE110
00007431745d6718  cmp dword ptr [r15+0x318], 0x00
00007431745d6720  jz 0x00007431745D57E0
00007431745d6726  nop [rax+rax*1], ax
00007431745d672f  nop [rax+rax*1], eax
00007431745d6737  mov eax, 0x410278
00007431745d673c  mov [r15+0x100], rax
00007431745d6743  jmp 0x00007431743FE110
00007431745d6748  int3
00007431745d6749  call 0x000074317440A4B0
00007431745d674e  jmp 0x00007431745D5828
00007431745d6753  call 0x0000743174409240
00007431745d6758  jmp 0x00007431745D5832
00007431745d675d  call 0x000074317440A4B0
00007431745d6762  jmp 0x00007431745D588F
00007431745d6767  call 0x0000743174409240
00007431745d676c  jmp 0x00007431745D5899
00007431745d6771  call 0x000074317440A4B0
00007431745d6776  jmp 0x00007431745D58DD
00007431745d677b  call 0x0000743174409240
00007431745d6780  jmp 0x00007431745D58E7
00007431745d6785  call 0x00007431744B47C0
00007431745d678a  jmp 0x00007431745D5926
00007431745d678f  call 0x000074317440B720
00007431745d6794  jmp 0x00007431745D593A
00007431745d6799  call 0x00007431744BFC30
00007431745d679e  jmp 0x00007431745D5958
00007431745d67a3  call 0x00007431744BE9C0
00007431745d67a8  jmp 0x00007431745D5962
00007431745d67ad  call 0x00007431744BD750
00007431745d67b2  jmp 0x00007431745D596C
00007431745d67b7  sub rsp, 0x08
00007431745d67bb  push rax
00007431745d67bc  push rcx
00007431745d67bd  push rdx
00007431745d67be  push rdi
00007431745d67bf  push rsi
00007431745d67c0  push r8
00007431745d67c2  push r9
00007431745d67c4  push r10
00007431745d67c6  push r11
00007431745d67c8  sub rsp, 0xF0
00007431745d67cf  vmovaps [rsp], xmm0
00007431745d67d4  vmovaps [rsp+0x10], xmm1
00007431745d67da  vmovaps [rsp+0x20], xmm2
00007431745d67e0  vmovaps [rsp+0x30], xmm3
00007431745d67e6  vmovaps [rsp+0x40], xmm4
00007431745d67ec  vmovaps [rsp+0x50], xmm5
00007431745d67f2  vmovaps [rsp+0x60], xmm6
00007431745d67f8  vmovaps [rsp+0x70], xmm7
00007431745d67fe  vmovaps [rsp+0x80], xmm9
00007431745d6807  vmovaps [rsp+0x90], xmm10
00007431745d6810  vmovaps [rsp+0xA0], xmm11
00007431745d6819  vmovaps [rsp+0xB0], xmm12
00007431745d6822  vmovaps [rsp+0xC0], xmm13
00007431745d682b  vmovaps [rsp+0xD0], xmm14
00007431745d6834  vmovaps [rsp+0xE0], xmm15
00007431745d683d  sub rsp, 0x30
00007431745d6841  movaps [rsp], xmm8
00007431745d6846  movaps [rsp+0x10], xmm12
00007431745d684c  movaps [rsp+0x20], xmm15
00007431745d6852  lea rdi, [rsp]
00007431745d6856  mov esi, 0x00
00007431745d685b  mov rax, 0x56C40959E530
00007431745d6865  call rax
00007431745d6867  movaps xmm8, [rsp]
00007431745d686c  add rsp, 0x30
00007431745d6870  vmovaps xmm0, [rsp]
00007431745d6875  vmovaps xmm1, [rsp+0x10]
00007431745d687b  vmovaps xmm2, [rsp+0x20]
00007431745d6881  vmovaps xmm3, [rsp+0x30]
00007431745d6887  vmovaps xmm4, [rsp+0x40]
00007431745d688d  vmovaps xmm5, [rsp+0x50]
00007431745d6893  vmovaps xmm6, [rsp+0x60]
00007431745d6899  vmovaps xmm7, [rsp+0x70]
00007431745d689f  vmovaps xmm9, [rsp+0x80]
00007431745d68a8  vmovaps xmm10, [rsp+0x90]
00007431745d68b1  vmovaps xmm11, [rsp+0xA0]
00007431745d68ba  vmovaps xmm12, [rsp+0xB0]
00007431745d68c3  vmovaps xmm13, [rsp+0xC0]
00007431745d68cc  vmovaps xmm14, [rsp+0xD0]
00007431745d68d5  vmovaps xmm15, [rsp+0xE0]
00007431745d68de  add rsp, 0xF0
00007431745d68e5  pop r11
00007431745d68e7  pop r10
00007431745d68e9  pop r9
00007431745d68eb  pop r8
00007431745d68ed  pop rsi
00007431745d68ee  pop rdi
00007431745d68ef  pop rdx
00007431745d68f0  pop rcx
00007431745d68f1  pop rax
00007431745d68f2  add rsp, 0x08
00007431745d68f6  jmp 0x00007431745D599A
00007431745d68fb  sub rsp, 0x08
00007431745d68ff  push rax
00007431745d6900  push rcx
00007431745d6901  push rdx
00007431745d6902  push rdi
00007431745d6903  push rsi
00007431745d6904  push r8
00007431745d6906  push r9
00007431745d6908  push r10
00007431745d690a  push r11
00007431745d690c  sub rsp, 0xF0
00007431745d6913  vmovaps [rsp], xmm0
00007431745d6918  vmovaps [rsp+0x10], xmm1
00007431745d691e  vmovaps [rsp+0x20], xmm2
00007431745d6924  vmovaps [rsp+0x30], xmm3
00007431745d692a  vmovaps [rsp+0x40], xmm4
00007431745d6930  vmovaps [rsp+0x50], xmm5
00007431745d6936  vmovaps [rsp+0x60], xmm6
00007431745d693c  vmovaps [rsp+0x70], xmm8
00007431745d6942  vmovaps [rsp+0x80], xmm9
00007431745d694b  vmovaps [rsp+0x90], xmm10
00007431745d6954  vmovaps [rsp+0xA0], xmm11
00007431745d695d  vmovaps [rsp+0xB0], xmm12
00007431745d6966  vmovaps [rsp+0xC0], xmm13
00007431745d696f  vmovaps [rsp+0xD0], xmm14
00007431745d6978  vmovaps [rsp+0xE0], xmm15
00007431745d6981  sub rsp, 0x30
00007431745d6985  movaps [rsp], xmm7
00007431745d6989  movaps [rsp+0x10], xmm9
00007431745d698f  movaps [rsp+0x20], xmm15
00007431745d6995  lea rdi, [rsp]
00007431745d6999  mov esi, 0x00
00007431745d699e  mov rax, 0x56C40959E530
00007431745d69a8  call rax
00007431745d69aa  movaps xmm7, [rsp]
00007431745d69ae  add rsp, 0x30
00007431745d69b2  vmovaps xmm0, [rsp]
00007431745d69b7  vmovaps xmm1, [rsp+0x10]
00007431745d69bd  vmovaps xmm2, [rsp+0x20]
00007431745d69c3  vmovaps xmm3, [rsp+0x30]
00007431745d69c9  vmovaps xmm4, [rsp+0x40]
00007431745d69cf  vmovaps xmm5, [rsp+0x50]
00007431745d69d5  vmovaps xmm6, [rsp+0x60]
00007431745d69db  vmovaps xmm8, [rsp+0x70]
00007431745d69e1  vmovaps xmm9, [rsp+0x80]
00007431745d69ea  vmovaps xmm10, [rsp+0x90]
00007431745d69f3  vmovaps xmm11, [rsp+0xA0]
00007431745d69fc  vmovaps xmm12, [rsp+0xB0]
00007431745d6a05  vmovaps xmm13, [rsp+0xC0]
00007431745d6a0e  vmovaps xmm14, [rsp+0xD0]
00007431745d6a17  vmovaps xmm15, [rsp+0xE0]
00007431745d6a20  add rsp, 0xF0
00007431745d6a27  pop r11
00007431745d6a29  pop r10
00007431745d6a2b  pop r9
00007431745d6a2d  pop r8
00007431745d6a2f  pop rsi
00007431745d6a30  pop rdi
00007431745d6a31  pop rdx
00007431745d6a32  pop rcx
00007431745d6a33  pop rax
00007431745d6a34  add rsp, 0x08
00007431745d6a38  jmp 0x00007431745D59C8
00007431745d6a3d  sub rsp, 0x08
00007431745d6a41  push rax
00007431745d6a42  push rcx
00007431745d6a43  push rdx
00007431745d6a44  push rdi
00007431745d6a45  push rsi
00007431745d6a46  push r8
00007431745d6a48  push r9
00007431745d6a4a  push r10
00007431745d6a4c  push r11
00007431745d6a4e  sub rsp, 0xF0
00007431745d6a55  vmovaps [rsp], xmm0
00007431745d6a5a  vmovaps [rsp+0x10], xmm1
00007431745d6a60  vmovaps [rsp+0x20], xmm2
00007431745d6a66  vmovaps [rsp+0x30], xmm3
00007431745d6a6c  vmovaps [rsp+0x40], xmm4
00007431745d6a72  vmovaps [rsp+0x50], xmm5
00007431745d6a78  vmovaps [rsp+0x60], xmm6
00007431745d6a7e  vmovaps [rsp+0x70], xmm7
00007431745d6a84  vmovaps [rsp+0x80], xmm8
00007431745d6a8d  vmovaps [rsp+0x90], xmm10
00007431745d6a96  vmovaps [rsp+0xA0], xmm11
00007431745d6a9f  vmovaps [rsp+0xB0], xmm12
00007431745d6aa8  vmovaps [rsp+0xC0], xmm13
00007431745d6ab1  vmovaps [rsp+0xD0], xmm14
00007431745d6aba  vmovaps [rsp+0xE0], xmm15
00007431745d6ac3  sub rsp, 0x30
00007431745d6ac7  movaps [rsp], xmm9
00007431745d6acc  movaps [rsp+0x10], xmm12
00007431745d6ad2  movaps [rsp+0x20], xmm10
00007431745d6ad8  lea rdi, [rsp]
00007431745d6adc  mov esi, 0x00
00007431745d6ae1  mov rax, 0x56C40959E530
00007431745d6aeb  call rax
00007431745d6aed  movaps xmm9, [rsp]
00007431745d6af2  add rsp, 0x30
00007431745d6af6  vmovaps xmm0, [rsp]
00007431745d6afb  vmovaps xmm1, [rsp+0x10]
00007431745d6b01  vmovaps xmm2, [rsp+0x20]
00007431745d6b07  vmovaps xmm3, [rsp+0x30]
00007431745d6b0d  vmovaps xmm4, [rsp+0x40]
00007431745d6b13  vmovaps xmm5, [rsp+0x50]
00007431745d6b19  vmovaps xmm6, [rsp+0x60]
00007431745d6b1f  vmovaps xmm7, [rsp+0x70]
00007431745d6b25  vmovaps xmm8, [rsp+0x80]
00007431745d6b2e  vmovaps xmm10, [rsp+0x90]
00007431745d6b37  vmovaps xmm11, [rsp+0xA0]
00007431745d6b40  vmovaps xmm12, [rsp+0xB0]
00007431745d6b49  vmovaps xmm13, [rsp+0xC0]
00007431745d6b52  vmovaps xmm14, [rsp+0xD0]
00007431745d6b5b  vmovaps xmm15, [rsp+0xE0]
00007431745d6b64  add rsp, 0xF0
00007431745d6b6b  pop r11
00007431745d6b6d  pop r10
00007431745d6b6f  pop r9
00007431745d6b71  pop r8
00007431745d6b73  pop rsi
00007431745d6b74  pop rdi
00007431745d6b75  pop rdx
00007431745d6b76  pop rcx
00007431745d6b77  pop rax
00007431745d6b78  add rsp, 0x08
00007431745d6b7c  jmp 0x00007431745D59EC
00007431745d6b81  sub rsp, 0x08
00007431745d6b85  push rax
00007431745d6b86  push rcx
00007431745d6b87  push rdx
00007431745d6b88  push rdi
00007431745d6b89  push rsi
00007431745d6b8a  push r8
00007431745d6b8c  push r9
00007431745d6b8e  push r10
00007431745d6b90  push r11
00007431745d6b92  sub rsp, 0xF0
00007431745d6b99  vmovaps [rsp], xmm0
00007431745d6b9e  vmovaps [rsp+0x10], xmm1
00007431745d6ba4  vmovaps [rsp+0x20], xmm2
00007431745d6baa  vmovaps [rsp+0x30], xmm3
00007431745d6bb0  vmovaps [rsp+0x40], xmm4
00007431745d6bb6  vmovaps [rsp+0x50], xmm5
00007431745d6bbc  vmovaps [rsp+0x60], xmm6
00007431745d6bc2  vmovaps [rsp+0x70], xmm7
00007431745d6bc8  vmovaps [rsp+0x80], xmm8
00007431745d6bd1  vmovaps [rsp+0x90], xmm9
00007431745d6bda  vmovaps [rsp+0xA0], xmm11
00007431745d6be3  vmovaps [rsp+0xB0], xmm12
00007431745d6bec  vmovaps [rsp+0xC0], xmm13
00007431745d6bf5  vmovaps [rsp+0xD0], xmm14
00007431745d6bfe  vmovaps [rsp+0xE0], xmm15
00007431745d6c07  sub rsp, 0x30
00007431745d6c0b  movaps [rsp], xmm10
00007431745d6c10  movaps [rsp+0x10], xmm12
00007431745d6c16  movaps [rsp+0x20], xmm11
00007431745d6c1c  lea rdi, [rsp]
00007431745d6c20  mov esi, 0x00
00007431745d6c25  mov rax, 0x56C40959E530
00007431745d6c2f  call rax
00007431745d6c31  movaps xmm10, [rsp]
00007431745d6c36  add rsp, 0x30
00007431745d6c3a  vmovaps xmm0, [rsp]
00007431745d6c3f  vmovaps xmm1, [rsp+0x10]
00007431745d6c45  vmovaps xmm2, [rsp+0x20]
00007431745d6c4b  vmovaps xmm3, [rsp+0x30]
00007431745d6c51  vmovaps xmm4, [rsp+0x40]
00007431745d6c57  vmovaps xmm5, [rsp+0x50]
00007431745d6c5d  vmovaps xmm6, [rsp+0x60]
00007431745d6c63  vmovaps xmm7, [rsp+0x70]
00007431745d6c69  vmovaps xmm8, [rsp+0x80]
00007431745d6c72  vmovaps xmm9, [rsp+0x90]
00007431745d6c7b  vmovaps xmm11, [rsp+0xA0]
00007431745d6c84  vmovaps xmm12, [rsp+0xB0]
00007431745d6c8d  vmovaps xmm13, [rsp+0xC0]
00007431745d6c96  vmovaps xmm14, [rsp+0xD0]
00007431745d6c9f  vmovaps xmm15, [rsp+0xE0]
00007431745d6ca8  add rsp, 0xF0
00007431745d6caf  pop r11
00007431745d6cb1  pop r10
00007431745d6cb3  pop r9
00007431745d6cb5  pop r8
00007431745d6cb7  pop rsi
00007431745d6cb8  pop rdi
00007431745d6cb9  pop rdx
00007431745d6cba  pop rcx
00007431745d6cbb  pop rax
00007431745d6cbc  add rsp, 0x08
00007431745d6cc0  jmp 0x00007431745D5A06
00007431745d6cc5  sub rsp, 0x08
00007431745d6cc9  push rax
00007431745d6cca  push rcx
00007431745d6ccb  push rdx
00007431745d6ccc  push rdi
00007431745d6ccd  push rsi
00007431745d6cce  push r8
00007431745d6cd0  push r9
00007431745d6cd2  push r10
00007431745d6cd4  push r11
00007431745d6cd6  sub rsp, 0xF0
00007431745d6cdd  vmovaps [rsp], xmm0
00007431745d6ce2  vmovaps [rsp+0x10], xmm1
00007431745d6ce8  vmovaps [rsp+0x20], xmm2
00007431745d6cee  vmovaps [rsp+0x30], xmm3
00007431745d6cf4  vmovaps [rsp+0x40], xmm4
00007431745d6cfa  vmovaps [rsp+0x50], xmm5
00007431745d6d00  vmovaps [rsp+0x60], xmm7
00007431745d6d06  vmovaps [rsp+0x70], xmm8
00007431745d6d0c  vmovaps [rsp+0x80], xmm9
00007431745d6d15  vmovaps [rsp+0x90], xmm10
00007431745d6d1e  vmovaps [rsp+0xA0], xmm11
00007431745d6d27  vmovaps [rsp+0xB0], xmm12
00007431745d6d30  vmovaps [rsp+0xC0], xmm13
00007431745d6d39  vmovaps [rsp+0xD0], xmm14
00007431745d6d42  vmovaps [rsp+0xE0], xmm15
00007431745d6d4b  sub rsp, 0x30
00007431745d6d4f  movaps [rsp], xmm6
00007431745d6d53  movaps [rsp+0x10], xmm12
00007431745d6d59  movaps [rsp+0x20], xmm11
00007431745d6d5f  lea rdi, [rsp]
00007431745d6d63  mov esi, 0x00
00007431745d6d68  mov rax, 0x56C40959E530
00007431745d6d72  call rax
00007431745d6d74  movaps xmm6, [rsp]
00007431745d6d78  add rsp, 0x30
00007431745d6d7c  vmovaps xmm0, [rsp]
00007431745d6d81  vmovaps xmm1, [rsp+0x10]
00007431745d6d87  vmovaps xmm2, [rsp+0x20]
00007431745d6d8d  vmovaps xmm3, [rsp+0x30]
00007431745d6d93  vmovaps xmm4, [rsp+0x40]
00007431745d6d99  vmovaps xmm5, [rsp+0x50]
00007431745d6d9f  vmovaps xmm7, [rsp+0x60]
00007431745d6da5  vmovaps xmm8, [rsp+0x70]
00007431745d6dab  vmovaps xmm9, [rsp+0x80]
00007431745d6db4  vmovaps xmm10, [rsp+0x90]
00007431745d6dbd  vmovaps xmm11, [rsp+0xA0]
00007431745d6dc6  vmovaps xmm12, [rsp+0xB0]
00007431745d6dcf  vmovaps xmm13, [rsp+0xC0]
00007431745d6dd8  vmovaps xmm14, [rsp+0xD0]
00007431745d6de1  vmovaps xmm15, [rsp+0xE0]
00007431745d6dea  add rsp, 0xF0
00007431745d6df1  pop r11
00007431745d6df3  pop r10
00007431745d6df5  pop r9
00007431745d6df7  pop r8
00007431745d6df9  pop rsi
00007431745d6dfa  pop rdi
00007431745d6dfb  pop rdx
00007431745d6dfc  pop rcx
00007431745d6dfd  pop rax
00007431745d6dfe  add rsp, 0x08
00007431745d6e02  jmp 0x00007431745D5A27
00007431745d6e07  sub rsp, 0x08
00007431745d6e0b  push rax
00007431745d6e0c  push rcx
00007431745d6e0d  push rdx
00007431745d6e0e  push rdi
00007431745d6e0f  push rsi
00007431745d6e10  push r8
00007431745d6e12  push r9
00007431745d6e14  push r10
00007431745d6e16  push r11
00007431745d6e18  sub rsp, 0xF0
00007431745d6e1f  vmovaps [rsp], xmm0
00007431745d6e24  vmovaps [rsp+0x10], xmm1
00007431745d6e2a  vmovaps [rsp+0x20], xmm2
00007431745d6e30  vmovaps [rsp+0x30], xmm4
00007431745d6e36  vmovaps [rsp+0x40], xmm5
00007431745d6e3c  vmovaps [rsp+0x50], xmm6
00007431745d6e42  vmovaps [rsp+0x60], xmm7
00007431745d6e48  vmovaps [rsp+0x70], xmm8
00007431745d6e4e  vmovaps [rsp+0x80], xmm9
00007431745d6e57  vmovaps [rsp+0x90], xmm10
00007431745d6e60  vmovaps [rsp+0xA0], xmm11
00007431745d6e69  vmovaps [rsp+0xB0], xmm12
00007431745d6e72  vmovaps [rsp+0xC0], xmm13
00007431745d6e7b  vmovaps [rsp+0xD0], xmm14
00007431745d6e84  vmovaps [rsp+0xE0], xmm15
00007431745d6e8d  sub rsp, 0x30
00007431745d6e91  movaps [rsp], xmm3
00007431745d6e95  movaps [rsp+0x10], xmm5
00007431745d6e9a  movaps [rsp+0x20], xmm4
00007431745d6e9f  lea rdi, [rsp]
00007431745d6ea3  mov esi, 0x00
00007431745d6ea8  mov rax, 0x56C40959E530
00007431745d6eb2  call rax
00007431745d6eb4  movaps xmm3, [rsp]
00007431745d6eb8  add rsp, 0x30
00007431745d6ebc  vmovaps xmm0, [rsp]
00007431745d6ec1  vmovaps xmm1, [rsp+0x10]
00007431745d6ec7  vmovaps xmm2, [rsp+0x20]
00007431745d6ecd  vmovaps xmm4, [rsp+0x30]
00007431745d6ed3  vmovaps xmm5, [rsp+0x40]
00007431745d6ed9  vmovaps xmm6, [rsp+0x50]
00007431745d6edf  vmovaps xmm7, [rsp+0x60]
00007431745d6ee5  vmovaps xmm8, [rsp+0x70]
00007431745d6eeb  vmovaps xmm9, [rsp+0x80]
00007431745d6ef4  vmovaps xmm10, [rsp+0x90]
00007431745d6efd  vmovaps xmm11, [rsp+0xA0]
00007431745d6f06  vmovaps xmm12, [rsp+0xB0]
00007431745d6f0f  vmovaps xmm13, [rsp+0xC0]
00007431745d6f18  vmovaps xmm14, [rsp+0xD0]
00007431745d6f21  vmovaps xmm15, [rsp+0xE0]
00007431745d6f2a  add rsp, 0xF0
00007431745d6f31  pop r11
00007431745d6f33  pop r10
00007431745d6f35  pop r9
00007431745d6f37  pop r8
00007431745d6f39  pop rsi
00007431745d6f3a  pop rdi
00007431745d6f3b  pop rdx
00007431745d6f3c  pop rcx
00007431745d6f3d  pop rax
00007431745d6f3e  add rsp, 0x08
00007431745d6f42  jmp 0x00007431745D5A88
00007431745d6f47  sub rsp, 0x08
00007431745d6f4b  push rax
00007431745d6f4c  push rcx
00007431745d6f4d  push rdx
00007431745d6f4e  push rdi
00007431745d6f4f  push rsi
00007431745d6f50  push r8
00007431745d6f52  push r9
00007431745d6f54  push r10
00007431745d6f56  push r11
00007431745d6f58  sub rsp, 0xF0
00007431745d6f5f  vmovaps [rsp], xmm0
00007431745d6f64  vmovaps [rsp+0x10], xmm1
00007431745d6f6a  vmovaps [rsp+0x20], xmm2
00007431745d6f70  vmovaps [rsp+0x30], xmm3
00007431745d6f76  vmovaps [rsp+0x40], xmm4
00007431745d6f7c  vmovaps [rsp+0x50], xmm6
00007431745d6f82  vmovaps [rsp+0x60], xmm7
00007431745d6f88  vmovaps [rsp+0x70], xmm8
00007431745d6f8e  vmovaps [rsp+0x80], xmm9
00007431745d6f97  vmovaps [rsp+0x90], xmm10
00007431745d6fa0  vmovaps [rsp+0xA0], xmm11
00007431745d6fa9  vmovaps [rsp+0xB0], xmm12
00007431745d6fb2  vmovaps [rsp+0xC0], xmm13
00007431745d6fbb  vmovaps [rsp+0xD0], xmm14
00007431745d6fc4  vmovaps [rsp+0xE0], xmm15
00007431745d6fcd  sub rsp, 0x30
00007431745d6fd1  movaps [rsp], xmm5
00007431745d6fd5  movaps [rsp+0x10], xmm8
00007431745d6fdb  movaps [rsp+0x20], xmm15
00007431745d6fe1  lea rdi, [rsp]
00007431745d6fe5  mov esi, 0x00
00007431745d6fea  mov rax, 0x56C40959E530
00007431745d6ff4  call rax
00007431745d6ff6  movaps xmm5, [rsp]
00007431745d6ffa  add rsp, 0x30
00007431745d6ffe  vmovaps xmm0, [rsp]
00007431745d7003  vmovaps xmm1, [rsp+0x10]
00007431745d7009  vmovaps xmm2, [rsp+0x20]
00007431745d700f  vmovaps xmm3, [rsp+0x30]
00007431745d7015  vmovaps xmm4, [rsp+0x40]
00007431745d701b  vmovaps xmm6, [rsp+0x50]
00007431745d7021  vmovaps xmm7, [rsp+0x60]
00007431745d7027  vmovaps xmm8, [rsp+0x70]
00007431745d702d  vmovaps xmm9, [rsp+0x80]
00007431745d7036  vmovaps xmm10, [rsp+0x90]
00007431745d703f  vmovaps xmm11, [rsp+0xA0]
00007431745d7048  vmovaps xmm12, [rsp+0xB0]
00007431745d7051  vmovaps xmm13, [rsp+0xC0]
00007431745d705a  vmovaps xmm14, [rsp+0xD0]
00007431745d7063  vmovaps xmm15, [rsp+0xE0]
00007431745d706c  add rsp, 0xF0
00007431745d7073  pop r11
00007431745d7075  pop r10
00007431745d7077  pop r9
00007431745d7079  pop r8
00007431745d707b  pop rsi
00007431745d707c  pop rdi
00007431745d707d  pop rdx
00007431745d707e  pop rcx
00007431745d707f  pop rax
00007431745d7080  add rsp, 0x08
00007431745d7084  jmp 0x00007431745D5AC0
00007431745d7089  sub rsp, 0x08
00007431745d708d  push rax
00007431745d708e  push rcx
00007431745d708f  push rdx
00007431745d7090  push rdi
00007431745d7091  push rsi
00007431745d7092  push r8
00007431745d7094  push r9
00007431745d7096  push r10
00007431745d7098  push r11
00007431745d709a  sub rsp, 0xF0
00007431745d70a1  vmovaps [rsp], xmm0
00007431745d70a6  vmovaps [rsp+0x10], xmm1
00007431745d70ac  vmovaps [rsp+0x20], xmm2
00007431745d70b2  vmovaps [rsp+0x30], xmm3
00007431745d70b8  vmovaps [rsp+0x40], xmm5
00007431745d70be  vmovaps [rsp+0x50], xmm6
00007431745d70c4  vmovaps [rsp+0x60], xmm7
00007431745d70ca  vmovaps [rsp+0x70], xmm8
00007431745d70d0  vmovaps [rsp+0x80], xmm9
00007431745d70d9  vmovaps [rsp+0x90], xmm10
00007431745d70e2  vmovaps [rsp+0xA0], xmm11
00007431745d70eb  vmovaps [rsp+0xB0], xmm12
00007431745d70f4  vmovaps [rsp+0xC0], xmm13
00007431745d70fd  vmovaps [rsp+0xD0], xmm14
00007431745d7106  vmovaps [rsp+0xE0], xmm15
00007431745d710f  sub rsp, 0x30
00007431745d7113  movaps [rsp], xmm4
00007431745d7117  movaps [rsp+0x10], xmm9
00007431745d711d  movaps [rsp+0x20], xmm8
00007431745d7123  lea rdi, [rsp]
00007431745d7127  mov esi, 0x00
00007431745d712c  mov rax, 0x56C40959E530
00007431745d7136  call rax
00007431745d7138  movaps xmm4, [rsp]
00007431745d713c  add rsp, 0x30
00007431745d7140  vmovaps xmm0, [rsp]
00007431745d7145  vmovaps xmm1, [rsp+0x10]
00007431745d714b  vmovaps xmm2, [rsp+0x20]
00007431745d7151  vmovaps xmm3, [rsp+0x30]
00007431745d7157  vmovaps xmm5, [rsp+0x40]
00007431745d715d  vmovaps xmm6, [rsp+0x50]
00007431745d7163  vmovaps xmm7, [rsp+0x60]
00007431745d7169  vmovaps xmm8, [rsp+0x70]
00007431745d716f  vmovaps xmm9, [rsp+0x80]
00007431745d7178  vmovaps xmm10, [rsp+0x90]
00007431745d7181  vmovaps xmm11, [rsp+0xA0]
00007431745d718a  vmovaps xmm12, [rsp+0xB0]
00007431745d7193  vmovaps xmm13, [rsp+0xC0]
00007431745d719c  vmovaps xmm14, [rsp+0xD0]
00007431745d71a5  vmovaps xmm15, [rsp+0xE0]
00007431745d71ae  add rsp, 0xF0
00007431745d71b5  pop r11
00007431745d71b7  pop r10
00007431745d71b9  pop r9
00007431745d71bb  pop r8
00007431745d71bd  pop rsi
00007431745d71be  pop rdi
00007431745d71bf  pop rdx
00007431745d71c0  pop rcx
00007431745d71c1  pop rax
00007431745d71c2  add rsp, 0x08
00007431745d71c6  jmp 0x00007431745D5AE1
00007431745d71cb  sub rsp, 0x08
00007431745d71cf  push rax
00007431745d71d0  push rcx
00007431745d71d1  push rdx
00007431745d71d2  push rdi
00007431745d71d3  push rsi
00007431745d71d4  push r8
00007431745d71d6  push r9
00007431745d71d8  push r10
00007431745d71da  push r11
00007431745d71dc  sub rsp, 0xF0
00007431745d71e3  vmovaps [rsp], xmm0
00007431745d71e8  vmovaps [rsp+0x10], xmm1
00007431745d71ee  vmovaps [rsp+0x20], xmm2
00007431745d71f4  vmovaps [rsp+0x30], xmm3
00007431745d71fa  vmovaps [rsp+0x40], xmm4
00007431745d7200  vmovaps [rsp+0x50], xmm5
00007431745d7206  vmovaps [rsp+0x60], xmm6
00007431745d720c  vmovaps [rsp+0x70], xmm7
00007431745d7212  vmovaps [rsp+0x80], xmm8
00007431745d721b  vmovaps [rsp+0x90], xmm10
00007431745d7224  vmovaps [rsp+0xA0], xmm11
00007431745d722d  vmovaps [rsp+0xB0], xmm12
00007431745d7236  vmovaps [rsp+0xC0], xmm13
00007431745d723f  vmovaps [rsp+0xD0], xmm14
00007431745d7248  vmovaps [rsp+0xE0], xmm15
00007431745d7251  sub rsp, 0x30
00007431745d7255  movaps [rsp], xmm9
00007431745d725a  movaps [rsp+0x10], xmm10
00007431745d7260  movaps [rsp+0x20], xmm8
00007431745d7266  lea rdi, [rsp]
00007431745d726a  mov esi, 0x00
00007431745d726f  mov rax, 0x56C40959E530
00007431745d7279  call rax
00007431745d727b  movaps xmm9, [rsp]
00007431745d7280  add rsp, 0x30
00007431745d7284  vmovaps xmm0, [rsp]
00007431745d7289  vmovaps xmm1, [rsp+0x10]
00007431745d728f  vmovaps xmm2, [rsp+0x20]
00007431745d7295  vmovaps xmm3, [rsp+0x30]
00007431745d729b  vmovaps xmm4, [rsp+0x40]
00007431745d72a1  vmovaps xmm5, [rsp+0x50]
00007431745d72a7  vmovaps xmm6, [rsp+0x60]
00007431745d72ad  vmovaps xmm7, [rsp+0x70]
00007431745d72b3  vmovaps xmm8, [rsp+0x80]
00007431745d72bc  vmovaps xmm10, [rsp+0x90]
00007431745d72c5  vmovaps xmm11, [rsp+0xA0]
00007431745d72ce  vmovaps xmm12, [rsp+0xB0]
00007431745d72d7  vmovaps xmm13, [rsp+0xC0]
00007431745d72e0  vmovaps xmm14, [rsp+0xD0]
00007431745d72e9  vmovaps xmm15, [rsp+0xE0]
00007431745d72f2  add rsp, 0xF0
00007431745d72f9  pop r11
00007431745d72fb  pop r10
00007431745d72fd  pop r9
00007431745d72ff  pop r8
00007431745d7301  pop rsi
00007431745d7302  pop rdi
00007431745d7303  pop rdx
00007431745d7304  pop rcx
00007431745d7305  pop rax
00007431745d7306  add rsp, 0x08
00007431745d730a  jmp 0x00007431745D5AFB
00007431745d730f  call 0x00007431744D64F0
00007431745d7314  jmp 0x00007431745D5C15
00007431745d7319  call 0x00007431744D64F0
00007431745d731e  jmp 0x00007431745D5C2B
00007431745d7323  sub rsp, 0x08
00007431745d7327  push rax
00007431745d7328  push rcx
00007431745d7329  push rdx
00007431745d732a  push rdi
00007431745d732b  push rsi
00007431745d732c  push r8
00007431745d732e  push r9
00007431745d7330  push r10
00007431745d7332  push r11
00007431745d7334  sub rsp, 0xF0
00007431745d733b  vmovaps [rsp], xmm0
00007431745d7340  vmovaps [rsp+0x10], xmm2
00007431745d7346  vmovaps [rsp+0x20], xmm3
00007431745d734c  vmovaps [rsp+0x30], xmm4
00007431745d7352  vmovaps [rsp+0x40], xmm5
00007431745d7358  vmovaps [rsp+0x50], xmm6
00007431745d735e  vmovaps [rsp+0x60], xmm7
00007431745d7364  vmovaps [rsp+0x70], xmm8
00007431745d736a  vmovaps [rsp+0x80], xmm9
00007431745d7373  vmovaps [rsp+0x90], xmm10
00007431745d737c  vmovaps [rsp+0xA0], xmm11
00007431745d7385  vmovaps [rsp+0xB0], xmm12
00007431745d738e  vmovaps [rsp+0xC0], xmm13
00007431745d7397  vmovaps [rsp+0xD0], xmm14
00007431745d73a0  vmovaps [rsp+0xE0], xmm15
00007431745d73a9  sub rsp, 0x30
00007431745d73ad  movaps [rsp], xmm1
00007431745d73b1  movaps [rsp+0x10], xmm6
00007431745d73b6  movaps [rsp+0x20], xmm15
00007431745d73bc  lea rdi, [rsp]
00007431745d73c0  mov esi, 0x00
00007431745d73c5  mov rax, 0x56C40959E530
00007431745d73cf  call rax
00007431745d73d1  movaps xmm1, [rsp]
00007431745d73d5  add rsp, 0x30
00007431745d73d9  vmovaps xmm0, [rsp]
00007431745d73de  vmovaps xmm2, [rsp+0x10]
00007431745d73e4  vmovaps xmm3, [rsp+0x20]
00007431745d73ea  vmovaps xmm4, [rsp+0x30]
00007431745d73f0  vmovaps xmm5, [rsp+0x40]
00007431745d73f6  vmovaps xmm6, [rsp+0x50]
00007431745d73fc  vmovaps xmm7, [rsp+0x60]
00007431745d7402  vmovaps xmm8, [rsp+0x70]
00007431745d7408  vmovaps xmm9, [rsp+0x80]
00007431745d7411  vmovaps xmm10, [rsp+0x90]
00007431745d741a  vmovaps xmm11, [rsp+0xA0]
00007431745d7423  vmovaps xmm12, [rsp+0xB0]
00007431745d742c  vmovaps xmm13, [rsp+0xC0]
00007431745d7435  vmovaps xmm14, [rsp+0xD0]
00007431745d743e  vmovaps xmm15, [rsp+0xE0]
00007431745d7447  add rsp, 0xF0
00007431745d744e  pop r11
00007431745d7450  pop r10
00007431745d7452  pop r9
00007431745d7454  pop r8
00007431745d7456  pop rsi
00007431745d7457  pop rdi
00007431745d7458  pop rdx
00007431745d7459  pop rcx
00007431745d745a  pop rax
00007431745d745b  add rsp, 0x08
00007431745d745f  jmp 0x00007431745D5C68
00007431745d7464  call 0x00007431744E5820
00007431745d7469  jmp 0x00007431745D5C75
00007431745d746e  sub rsp, 0x08
00007431745d7472  push rax
00007431745d7473  push rcx
00007431745d7474  push rdx
00007431745d7475  push rdi
00007431745d7476  push rsi
00007431745d7477  push r8
00007431745d7479  push r9
00007431745d747b  push r10
00007431745d747d  push r11
00007431745d747f  sub rsp, 0xF0
00007431745d7486  vmovaps [rsp], xmm0
00007431745d748b  vmovaps [rsp+0x10], xmm1
00007431745d7491  vmovaps [rsp+0x20], xmm2
00007431745d7497  vmovaps [rsp+0x30], xmm3
00007431745d749d  vmovaps [rsp+0x40], xmm4
00007431745d74a3  vmovaps [rsp+0x50], xmm5
00007431745d74a9  vmovaps [rsp+0x60], xmm6
00007431745d74af  vmovaps [rsp+0x70], xmm7
00007431745d74b5  vmovaps [rsp+0x80], xmm8
00007431745d74be  vmovaps [rsp+0x90], xmm9
00007431745d74c7  vmovaps [rsp+0xA0], xmm10
00007431745d74d0  vmovaps [rsp+0xB0], xmm11
00007431745d74d9  vmovaps [rsp+0xC0], xmm12
00007431745d74e2  vmovaps [rsp+0xD0], xmm13
00007431745d74eb  vmovaps [rsp+0xE0], xmm15
00007431745d74f4  sub rsp, 0x30
00007431745d74f8  movaps [rsp], xmm14
00007431745d74fd  movaps [rsp+0x10], xmm4
00007431745d7502  movaps [rsp+0x20], xmm3
00007431745d7507  lea rdi, [rsp]
00007431745d750b  mov esi, 0x00
00007431745d7510  mov rax, 0x56C40959E530
00007431745d751a  call rax
00007431745d751c  movaps xmm14, [rsp]
00007431745d7521  add rsp, 0x30
00007431745d7525  vmovaps xmm0, [rsp]
00007431745d752a  vmovaps xmm1, [rsp+0x10]
00007431745d7530  vmovaps xmm2, [rsp+0x20]
00007431745d7536  vmovaps xmm3, [rsp+0x30]
00007431745d753c  vmovaps xmm4, [rsp+0x40]
00007431745d7542  vmovaps xmm5, [rsp+0x50]
00007431745d7548  vmovaps xmm6, [rsp+0x60]
00007431745d754e  vmovaps xmm7, [rsp+0x70]
00007431745d7554  vmovaps xmm8, [rsp+0x80]
00007431745d755d  vmovaps xmm9, [rsp+0x90]
00007431745d7566  vmovaps xmm10, [rsp+0xA0]
00007431745d756f  vmovaps xmm11, [rsp+0xB0]
00007431745d7578  vmovaps xmm12, [rsp+0xC0]
00007431745d7581  vmovaps xmm13, [rsp+0xD0]
00007431745d758a  vmovaps xmm15, [rsp+0xE0]
00007431745d7593  add rsp, 0xF0
00007431745d759a  pop r11
00007431745d759c  pop r10
00007431745d759e  pop r9
00007431745d75a0  pop r8
00007431745d75a2  pop rsi
00007431745d75a3  pop rdi
00007431745d75a4  pop rdx
00007431745d75a5  pop rcx
00007431745d75a6  pop rax
00007431745d75a7  add rsp, 0x08
00007431745d75ab  jmp 0x00007431745D5C8F
00007431745d75b0  sub rsp, 0x08
00007431745d75b4  push rax
00007431745d75b5  push rcx
00007431745d75b6  push rdx
00007431745d75b7  push rdi
00007431745d75b8  push rsi
00007431745d75b9  push r8
00007431745d75bb  push r9
00007431745d75bd  push r10
00007431745d75bf  push r11
00007431745d75c1  sub rsp, 0xF0
00007431745d75c8  vmovaps [rsp], xmm0
00007431745d75cd  vmovaps [rsp+0x10], xmm1
00007431745d75d3  vmovaps [rsp+0x20], xmm2
00007431745d75d9  vmovaps [rsp+0x30], xmm3
00007431745d75df  vmovaps [rsp+0x40], xmm4
00007431745d75e5  vmovaps [rsp+0x50], xmm5
00007431745d75eb  vmovaps [rsp+0x60], xmm7
00007431745d75f1  vmovaps [rsp+0x70], xmm8
00007431745d75f7  vmovaps [rsp+0x80], xmm9
00007431745d7600  vmovaps [rsp+0x90], xmm10
00007431745d7609  vmovaps [rsp+0xA0], xmm11
00007431745d7612  vmovaps [rsp+0xB0], xmm12
00007431745d761b  vmovaps [rsp+0xC0], xmm13
00007431745d7624  vmovaps [rsp+0xD0], xmm14
00007431745d762d  vmovaps [rsp+0xE0], xmm15
00007431745d7636  sub rsp, 0x30
00007431745d763a  movaps [rsp], xmm6
00007431745d763e  movaps [rsp+0x10], xmm9
00007431745d7644  movaps [rsp+0x20], xmm7
00007431745d7649  lea rdi, [rsp]
00007431745d764d  mov esi, 0x00
00007431745d7652  mov rax, 0x56C40959E530
00007431745d765c  call rax
00007431745d765e  movaps xmm6, [rsp]
00007431745d7662  add rsp, 0x30
00007431745d7666  vmovaps xmm0, [rsp]
00007431745d766b  vmovaps xmm1, [rsp+0x10]
00007431745d7671  vmovaps xmm2, [rsp+0x20]
00007431745d7677  vmovaps xmm3, [rsp+0x30]
00007431745d767d  vmovaps xmm4, [rsp+0x40]
00007431745d7683  vmovaps xmm5, [rsp+0x50]
00007431745d7689  vmovaps xmm7, [rsp+0x60]
00007431745d768f  vmovaps xmm8, [rsp+0x70]
00007431745d7695  vmovaps xmm9, [rsp+0x80]
00007431745d769e  vmovaps xmm10, [rsp+0x90]
00007431745d76a7  vmovaps xmm11, [rsp+0xA0]
00007431745d76b0  vmovaps xmm12, [rsp+0xB0]
00007431745d76b9  vmovaps xmm13, [rsp+0xC0]
00007431745d76c2  vmovaps xmm14, [rsp+0xD0]
00007431745d76cb  vmovaps xmm15, [rsp+0xE0]
00007431745d76d4  add rsp, 0xF0
00007431745d76db  pop r11
00007431745d76dd  pop r10
00007431745d76df  pop r9
00007431745d76e1  pop r8
00007431745d76e3  pop rsi
00007431745d76e4  pop rdi
00007431745d76e5  pop rdx
00007431745d76e6  pop rcx
00007431745d76e7  pop rax
00007431745d76e8  add rsp, 0x08
00007431745d76ec  jmp 0x00007431745D5CA7
00007431745d76f1  sub rsp, 0x08
00007431745d76f5  push rax
00007431745d76f6  push rcx
00007431745d76f7  push rdx
00007431745d76f8  push rdi
00007431745d76f9  push rsi
00007431745d76fa  push r8
00007431745d76fc  push r9
00007431745d76fe  push r10
00007431745d7700  push r11
00007431745d7702  sub rsp, 0xF0
00007431745d7709  vmovaps [rsp], xmm0
00007431745d770e  vmovaps [rsp+0x10], xmm1
00007431745d7714  vmovaps [rsp+0x20], xmm2
00007431745d771a  vmovaps [rsp+0x30], xmm3
00007431745d7720  vmovaps [rsp+0x40], xmm4
00007431745d7726  vmovaps [rsp+0x50], xmm5
00007431745d772c  vmovaps [rsp+0x60], xmm6
00007431745d7732  vmovaps [rsp+0x70], xmm8
00007431745d7738  vmovaps [rsp+0x80], xmm9
00007431745d7741  vmovaps [rsp+0x90], xmm10
00007431745d774a  vmovaps [rsp+0xA0], xmm11
00007431745d7753  vmovaps [rsp+0xB0], xmm12
00007431745d775c  vmovaps [rsp+0xC0], xmm13
00007431745d7765  vmovaps [rsp+0xD0], xmm14
00007431745d776e  vmovaps [rsp+0xE0], xmm15
00007431745d7777  sub rsp, 0x30
00007431745d777b  movaps [rsp], xmm7
00007431745d777f  movaps [rsp+0x10], xmm4
00007431745d7784  movaps [rsp+0x20], xmm9
00007431745d778a  lea rdi, [rsp]
00007431745d778e  mov esi, 0x00
00007431745d7793  mov rax, 0x56C40959E530
00007431745d779d  call rax
00007431745d779f  movaps xmm7, [rsp]
00007431745d77a3  add rsp, 0x30
00007431745d77a7  vmovaps xmm0, [rsp]
00007431745d77ac  vmovaps xmm1, [rsp+0x10]
00007431745d77b2  vmovaps xmm2, [rsp+0x20]
00007431745d77b8  vmovaps xmm3, [rsp+0x30]
00007431745d77be  vmovaps xmm4, [rsp+0x40]
00007431745d77c4  vmovaps xmm5, [rsp+0x50]
00007431745d77ca  vmovaps xmm6, [rsp+0x60]
00007431745d77d0  vmovaps xmm8, [rsp+0x70]
00007431745d77d6  vmovaps xmm9, [rsp+0x80]
00007431745d77df  vmovaps xmm10, [rsp+0x90]
00007431745d77e8  vmovaps xmm11, [rsp+0xA0]
00007431745d77f1  vmovaps xmm12, [rsp+0xB0]
00007431745d77fa  vmovaps xmm13, [rsp+0xC0]
00007431745d7803  vmovaps xmm14, [rsp+0xD0]
00007431745d780c  vmovaps xmm15, [rsp+0xE0]
00007431745d7815  add rsp, 0xF0
00007431745d781c  pop r11
00007431745d781e  pop r10
00007431745d7820  pop r9
00007431745d7822  pop r8
00007431745d7824  pop rsi
00007431745d7825  pop rdi
00007431745d7826  pop rdx
00007431745d7827  pop rcx
00007431745d7828  pop rax
00007431745d7829  add rsp, 0x08
00007431745d782d  jmp 0x00007431745D5CD4
00007431745d7832  sub rsp, 0x08
00007431745d7836  push rax
00007431745d7837  push rcx
00007431745d7838  push rdx
00007431745d7839  push rdi
00007431745d783a  push rsi
00007431745d783b  push r8
00007431745d783d  push r9
00007431745d783f  push r10
00007431745d7841  push r11
00007431745d7843  sub rsp, 0xF0
00007431745d784a  vmovaps [rsp], xmm0
00007431745d784f  vmovaps [rsp+0x10], xmm1
00007431745d7855  vmovaps [rsp+0x20], xmm2
00007431745d785b  vmovaps [rsp+0x30], xmm3
00007431745d7861  vmovaps [rsp+0x40], xmm5
00007431745d7867  vmovaps [rsp+0x50], xmm6
00007431745d786d  vmovaps [rsp+0x60], xmm7
00007431745d7873  vmovaps [rsp+0x70], xmm8
00007431745d7879  vmovaps [rsp+0x80], xmm9
00007431745d7882  vmovaps [rsp+0x90], xmm10
00007431745d788b  vmovaps [rsp+0xA0], xmm11
00007431745d7894  vmovaps [rsp+0xB0], xmm12
00007431745d789d  vmovaps [rsp+0xC0], xmm13
00007431745d78a6  vmovaps [rsp+0xD0], xmm14
00007431745d78af  vmovaps [rsp+0xE0], xmm15
00007431745d78b8  sub rsp, 0x30
00007431745d78bc  movaps [rsp], xmm4
00007431745d78c0  movaps [rsp+0x10], xmm15
00007431745d78c6  movaps [rsp+0x20], xmm9
00007431745d78cc  lea rdi, [rsp]
00007431745d78d0  mov esi, 0x00
00007431745d78d5  mov rax, 0x56C40959E530
00007431745d78df  call rax
00007431745d78e1  movaps xmm4, [rsp]
00007431745d78e5  add rsp, 0x30
00007431745d78e9  vmovaps xmm0, [rsp]
00007431745d78ee  vmovaps xmm1, [rsp+0x10]
00007431745d78f4  vmovaps xmm2, [rsp+0x20]
00007431745d78fa  vmovaps xmm3, [rsp+0x30]
00007431745d7900  vmovaps xmm5, [rsp+0x40]
00007431745d7906  vmovaps xmm6, [rsp+0x50]
00007431745d790c  vmovaps xmm7, [rsp+0x60]
00007431745d7912  vmovaps xmm8, [rsp+0x70]
00007431745d7918  vmovaps xmm9, [rsp+0x80]
00007431745d7921  vmovaps xmm10, [rsp+0x90]
00007431745d792a  vmovaps xmm11, [rsp+0xA0]
00007431745d7933  vmovaps xmm12, [rsp+0xB0]
00007431745d793c  vmovaps xmm13, [rsp+0xC0]
00007431745d7945  vmovaps xmm14, [rsp+0xD0]
00007431745d794e  vmovaps xmm15, [rsp+0xE0]
00007431745d7957  add rsp, 0xF0
00007431745d795e  pop r11
00007431745d7960  pop r10
00007431745d7962  pop r9
00007431745d7964  pop r8
00007431745d7966  pop rsi
00007431745d7967  pop rdi
00007431745d7968  pop rdx
00007431745d7969  pop rcx
00007431745d796a  pop rax
00007431745d796b  add rsp, 0x08
00007431745d796f  jmp 0x00007431745D5CF9
00007431745d7974  call 0x00007431744E5820
00007431745d7979  jmp 0x00007431745D5D06
00007431745d797e  sub rsp, 0x08
00007431745d7982  push rax
00007431745d7983  push rcx
00007431745d7984  push rdx
00007431745d7985  push rdi
00007431745d7986  push rsi
00007431745d7987  push r8
00007431745d7989  push r9
00007431745d798b  push r10
00007431745d798d  push r11
00007431745d798f  sub rsp, 0xF0
00007431745d7996  vmovaps [rsp], xmm0
00007431745d799b  vmovaps [rsp+0x10], xmm1
00007431745d79a1  vmovaps [rsp+0x20], xmm2
00007431745d79a7  vmovaps [rsp+0x30], xmm4
00007431745d79ad  vmovaps [rsp+0x40], xmm5
00007431745d79b3  vmovaps [rsp+0x50], xmm6
00007431745d79b9  vmovaps [rsp+0x60], xmm7
00007431745d79bf  vmovaps [rsp+0x70], xmm8
00007431745d79c5  vmovaps [rsp+0x80], xmm9
00007431745d79ce  vmovaps [rsp+0x90], xmm10
00007431745d79d7  vmovaps [rsp+0xA0], xmm11
00007431745d79e0  vmovaps [rsp+0xB0], xmm12
00007431745d79e9  vmovaps [rsp+0xC0], xmm13
00007431745d79f2  vmovaps [rsp+0xD0], xmm14
00007431745d79fb  vmovaps [rsp+0xE0], xmm15
00007431745d7a04  sub rsp, 0x30
00007431745d7a08  movaps [rsp], xmm3
00007431745d7a0c  movaps [rsp+0x10], xmm1
00007431745d7a11  movaps [rsp+0x20], xmm9
00007431745d7a17  lea rdi, [rsp]
00007431745d7a1b  mov esi, 0x00
00007431745d7a20  mov rax, 0x56C40959E530
00007431745d7a2a  call rax
00007431745d7a2c  movaps xmm3, [rsp]
00007431745d7a30  add rsp, 0x30
00007431745d7a34  vmovaps xmm0, [rsp]
00007431745d7a39  vmovaps xmm1, [rsp+0x10]
00007431745d7a3f  vmovaps xmm2, [rsp+0x20]
00007431745d7a45  vmovaps xmm4, [rsp+0x30]
00007431745d7a4b  vmovaps xmm5, [rsp+0x40]
00007431745d7a51  vmovaps xmm6, [rsp+0x50]
00007431745d7a57  vmovaps xmm7, [rsp+0x60]
00007431745d7a5d  vmovaps xmm8, [rsp+0x70]
00007431745d7a63  vmovaps xmm9, [rsp+0x80]
00007431745d7a6c  vmovaps xmm10, [rsp+0x90]
00007431745d7a75  vmovaps xmm11, [rsp+0xA0]
00007431745d7a7e  vmovaps xmm12, [rsp+0xB0]
00007431745d7a87  vmovaps xmm13, [rsp+0xC0]
00007431745d7a90  vmovaps xmm14, [rsp+0xD0]
00007431745d7a99  vmovaps xmm15, [rsp+0xE0]
00007431745d7aa2  add rsp, 0xF0
00007431745d7aa9  pop r11
00007431745d7aab  pop r10
00007431745d7aad  pop r9
00007431745d7aaf  pop r8
00007431745d7ab1  pop rsi
00007431745d7ab2  pop rdi
00007431745d7ab3  pop rdx
00007431745d7ab4  pop rcx
00007431745d7ab5  pop rax
00007431745d7ab6  add rsp, 0x08
00007431745d7aba  jmp 0x00007431745D5D43
00007431745d7abf  sub rsp, 0x08
00007431745d7ac3  push rax
00007431745d7ac4  push rcx
00007431745d7ac5  push rdx
00007431745d7ac6  push rdi
00007431745d7ac7  push rsi
00007431745d7ac8  push r8
00007431745d7aca  push r9
00007431745d7acc  push r10
00007431745d7ace  push r11
00007431745d7ad0  sub rsp, 0xF0
00007431745d7ad7  vmovaps [rsp], xmm0
00007431745d7adc  vmovaps [rsp+0x10], xmm2
00007431745d7ae2  vmovaps [rsp+0x20], xmm3
00007431745d7ae8  vmovaps [rsp+0x30], xmm4
00007431745d7aee  vmovaps [rsp+0x40], xmm5
00007431745d7af4  vmovaps [rsp+0x50], xmm6
00007431745d7afa  vmovaps [rsp+0x60], xmm7
00007431745d7b00  vmovaps [rsp+0x70], xmm8
00007431745d7b06  vmovaps [rsp+0x80], xmm9
00007431745d7b0f  vmovaps [rsp+0x90], xmm10
00007431745d7b18  vmovaps [rsp+0xA0], xmm11
00007431745d7b21  vmovaps [rsp+0xB0], xmm12
00007431745d7b2a  vmovaps [rsp+0xC0], xmm13
00007431745d7b33  vmovaps [rsp+0xD0], xmm14
00007431745d7b3c  vmovaps [rsp+0xE0], xmm15
00007431745d7b45  sub rsp, 0x30
00007431745d7b49  movaps [rsp], xmm1
00007431745d7b4d  movaps [rsp+0x10], xmm15
00007431745d7b53  movaps [rsp+0x20], xmm9
00007431745d7b59  lea rdi, [rsp]
00007431745d7b5d  mov esi, 0x00
00007431745d7b62  mov rax, 0x56C40959E530
00007431745d7b6c  call rax
00007431745d7b6e  movaps xmm1, [rsp]
00007431745d7b72  add rsp, 0x30
00007431745d7b76  vmovaps xmm0, [rsp]
00007431745d7b7b  vmovaps xmm2, [rsp+0x10]
00007431745d7b81  vmovaps xmm3, [rsp+0x20]
00007431745d7b87  vmovaps xmm4, [rsp+0x30]
00007431745d7b8d  vmovaps xmm5, [rsp+0x40]
00007431745d7b93  vmovaps xmm6, [rsp+0x50]
00007431745d7b99  vmovaps xmm7, [rsp+0x60]
00007431745d7b9f  vmovaps xmm8, [rsp+0x70]
00007431745d7ba5  vmovaps xmm9, [rsp+0x80]
00007431745d7bae  vmovaps xmm10, [rsp+0x90]
00007431745d7bb7  vmovaps xmm11, [rsp+0xA0]
00007431745d7bc0  vmovaps xmm12, [rsp+0xB0]
00007431745d7bc9  vmovaps xmm13, [rsp+0xC0]
00007431745d7bd2  vmovaps xmm14, [rsp+0xD0]
00007431745d7bdb  vmovaps xmm15, [rsp+0xE0]
00007431745d7be4  add rsp, 0xF0
00007431745d7beb  pop r11
00007431745d7bed  pop r10
00007431745d7bef  pop r9
00007431745d7bf1  pop r8
00007431745d7bf3  pop rsi
00007431745d7bf4  pop rdi
00007431745d7bf5  pop rdx
00007431745d7bf6  pop rcx
00007431745d7bf7  pop rax
00007431745d7bf8  add rsp, 0x08
00007431745d7bfc  jmp 0x00007431745D5DCB
00007431745d7c01  call 0x00007431744E5820
00007431745d7c06  jmp 0x00007431745D5DD8
00007431745d7c0b  sub rsp, 0x08
00007431745d7c0f  push rax
00007431745d7c10  push rcx
00007431745d7c11  push rdx
00007431745d7c12  push rdi
00007431745d7c13  push rsi
00007431745d7c14  push r8
00007431745d7c16  push r9
00007431745d7c18  push r10
00007431745d7c1a  push r11
00007431745d7c1c  sub rsp, 0xF0
00007431745d7c23  vmovaps [rsp], xmm0
00007431745d7c28  vmovaps [rsp+0x10], xmm2
00007431745d7c2e  vmovaps [rsp+0x20], xmm3
00007431745d7c34  vmovaps [rsp+0x30], xmm4
00007431745d7c3a  vmovaps [rsp+0x40], xmm5
00007431745d7c40  vmovaps [rsp+0x50], xmm6
00007431745d7c46  vmovaps [rsp+0x60], xmm7
00007431745d7c4c  vmovaps [rsp+0x70], xmm8
00007431745d7c52  vmovaps [rsp+0x80], xmm9
00007431745d7c5b  vmovaps [rsp+0x90], xmm10
00007431745d7c64  vmovaps [rsp+0xA0], xmm11
00007431745d7c6d  vmovaps [rsp+0xB0], xmm12
00007431745d7c76  vmovaps [rsp+0xC0], xmm13
00007431745d7c7f  vmovaps [rsp+0xD0], xmm14
00007431745d7c88  vmovaps [rsp+0xE0], xmm15
00007431745d7c91  sub rsp, 0x30
00007431745d7c95  movaps [rsp], xmm1
00007431745d7c99  movaps [rsp+0x10], xmm5
00007431745d7c9e  movaps [rsp+0x20], xmm7
00007431745d7ca3  lea rdi, [rsp]
00007431745d7ca7  mov esi, 0x00
00007431745d7cac  mov rax, 0x56C40959E530
00007431745d7cb6  call rax
00007431745d7cb8  movaps xmm1, [rsp]
00007431745d7cbc  add rsp, 0x30
00007431745d7cc0  vmovaps xmm0, [rsp]
00007431745d7cc5  vmovaps xmm2, [rsp+0x10]
00007431745d7ccb  vmovaps xmm3, [rsp+0x20]
00007431745d7cd1  vmovaps xmm4, [rsp+0x30]
00007431745d7cd7  vmovaps xmm5, [rsp+0x40]
00007431745d7cdd  vmovaps xmm6, [rsp+0x50]
00007431745d7ce3  vmovaps xmm7, [rsp+0x60]
00007431745d7ce9  vmovaps xmm8, [rsp+0x70]
00007431745d7cef  vmovaps xmm9, [rsp+0x80]
00007431745d7cf8  vmovaps xmm10, [rsp+0x90]
00007431745d7d01  vmovaps xmm11, [rsp+0xA0]
00007431745d7d0a  vmovaps xmm12, [rsp+0xB0]
00007431745d7d13  vmovaps xmm13, [rsp+0xC0]
00007431745d7d1c  vmovaps xmm14, [rsp+0xD0]
00007431745d7d25  vmovaps xmm15, [rsp+0xE0]
00007431745d7d2e  add rsp, 0xF0
00007431745d7d35  pop r11
00007431745d7d37  pop r10
00007431745d7d39  pop r9
00007431745d7d3b  pop r8
00007431745d7d3d  pop rsi
00007431745d7d3e  pop rdi
00007431745d7d3f  pop rdx
00007431745d7d40  pop rcx
00007431745d7d41  pop rax
00007431745d7d42  add rsp, 0x08
00007431745d7d46  jmp 0x00007431745D5E7D
00007431745d7d4b  sub rsp, 0x08
00007431745d7d4f  push rax
00007431745d7d50  push rcx
00007431745d7d51  push rdx
00007431745d7d52  push rdi
00007431745d7d53  push rsi
00007431745d7d54  push r8
00007431745d7d56  push r9
00007431745d7d58  push r10
00007431745d7d5a  push r11
00007431745d7d5c  sub rsp, 0xF0
00007431745d7d63  vmovaps [rsp], xmm0
00007431745d7d68  vmovaps [rsp+0x10], xmm1
00007431745d7d6e  vmovaps [rsp+0x20], xmm2
00007431745d7d74  vmovaps [rsp+0x30], xmm3
00007431745d7d7a  vmovaps [rsp+0x40], xmm4
00007431745d7d80  vmovaps [rsp+0x50], xmm5
00007431745d7d86  vmovaps [rsp+0x60], xmm6
00007431745d7d8c  vmovaps [rsp+0x70], xmm8
00007431745d7d92  vmovaps [rsp+0x80], xmm9
00007431745d7d9b  vmovaps [rsp+0x90], xmm10
00007431745d7da4  vmovaps [rsp+0xA0], xmm11
00007431745d7dad  vmovaps [rsp+0xB0], xmm12
00007431745d7db6  vmovaps [rsp+0xC0], xmm13
00007431745d7dbf  vmovaps [rsp+0xD0], xmm14
00007431745d7dc8  vmovaps [rsp+0xE0], xmm15
00007431745d7dd1  sub rsp, 0x30
00007431745d7dd5  movaps [rsp], xmm7
00007431745d7dd9  movaps [rsp+0x10], xmm5
00007431745d7dde  movaps [rsp+0x20], xmm15
00007431745d7de4  lea rdi, [rsp]
00007431745d7de8  mov esi, 0x00
00007431745d7ded  mov rax, 0x56C40959E530
00007431745d7df7  call rax
00007431745d7df9  movaps xmm7, [rsp]
00007431745d7dfd  add rsp, 0x30
00007431745d7e01  vmovaps xmm0, [rsp]
00007431745d7e06  vmovaps xmm1, [rsp+0x10]
00007431745d7e0c  vmovaps xmm2, [rsp+0x20]
00007431745d7e12  vmovaps xmm3, [rsp+0x30]
00007431745d7e18  vmovaps xmm4, [rsp+0x40]
00007431745d7e1e  vmovaps xmm5, [rsp+0x50]
00007431745d7e24  vmovaps xmm6, [rsp+0x60]
00007431745d7e2a  vmovaps xmm8, [rsp+0x70]
00007431745d7e30  vmovaps xmm9, [rsp+0x80]
00007431745d7e39  vmovaps xmm10, [rsp+0x90]
00007431745d7e42  vmovaps xmm11, [rsp+0xA0]
00007431745d7e4b  vmovaps xmm12, [rsp+0xB0]
00007431745d7e54  vmovaps xmm13, [rsp+0xC0]
00007431745d7e5d  vmovaps xmm14, [rsp+0xD0]
00007431745d7e66  vmovaps xmm15, [rsp+0xE0]
00007431745d7e6f  add rsp, 0xF0
00007431745d7e76  pop r11
00007431745d7e78  pop r10
00007431745d7e7a  pop r9
00007431745d7e7c  pop r8
00007431745d7e7e  pop rsi
00007431745d7e7f  pop rdi
00007431745d7e80  pop rdx
00007431745d7e81  pop rcx
00007431745d7e82  pop rax
00007431745d7e83  add rsp, 0x08
00007431745d7e87  jmp 0x00007431745D5EB3
00007431745d7e8c  call 0x00007431744D64F0
00007431745d7e91  jmp 0x00007431745D5EC0
00007431745d7e96  sub rsp, 0x08
00007431745d7e9a  push rax
00007431745d7e9b  push rcx
00007431745d7e9c  push rdx
00007431745d7e9d  push rdi
00007431745d7e9e  push rsi
00007431745d7e9f  push r8
00007431745d7ea1  push r9
00007431745d7ea3  push r10
00007431745d7ea5  push r11
00007431745d7ea7  sub rsp, 0xF0
00007431745d7eae  vmovaps [rsp], xmm0
00007431745d7eb3  vmovaps [rsp+0x10], xmm1
00007431745d7eb9  vmovaps [rsp+0x20], xmm2
00007431745d7ebf  vmovaps [rsp+0x30], xmm3
00007431745d7ec5  vmovaps [rsp+0x40], xmm4
00007431745d7ecb  vmovaps [rsp+0x50], xmm5
00007431745d7ed1  vmovaps [rsp+0x60], xmm6
00007431745d7ed7  vmovaps [rsp+0x70], xmm7
00007431745d7edd  vmovaps [rsp+0x80], xmm8
00007431745d7ee6  vmovaps [rsp+0x90], xmm9
00007431745d7eef  vmovaps [rsp+0xA0], xmm10
00007431745d7ef8  vmovaps [rsp+0xB0], xmm11
00007431745d7f01  vmovaps [rsp+0xC0], xmm12
00007431745d7f0a  vmovaps [rsp+0xD0], xmm13
00007431745d7f13  vmovaps [rsp+0xE0], xmm14
00007431745d7f1c  sub rsp, 0x30
00007431745d7f20  movaps [rsp], xmm15
00007431745d7f25  movaps [rsp+0x10], xmm5
00007431745d7f2a  movaps [rsp+0x20], xmm3
00007431745d7f2f  lea rdi, [rsp]
00007431745d7f33  mov esi, 0x00
00007431745d7f38  mov rax, 0x56C40959E530
00007431745d7f42  call rax
00007431745d7f44  movaps xmm15, [rsp]
00007431745d7f49  add rsp, 0x30
00007431745d7f4d  vmovaps xmm0, [rsp]
00007431745d7f52  vmovaps xmm1, [rsp+0x10]
00007431745d7f58  vmovaps xmm2, [rsp+0x20]
00007431745d7f5e  vmovaps xmm3, [rsp+0x30]
00007431745d7f64  vmovaps xmm4, [rsp+0x40]
00007431745d7f6a  vmovaps xmm5, [rsp+0x50]
00007431745d7f70  vmovaps xmm6, [rsp+0x60]
00007431745d7f76  vmovaps xmm7, [rsp+0x70]
00007431745d7f7c  vmovaps xmm8, [rsp+0x80]
00007431745d7f85  vmovaps xmm9, [rsp+0x90]
00007431745d7f8e  vmovaps xmm10, [rsp+0xA0]
00007431745d7f97  vmovaps xmm11, [rsp+0xB0]
00007431745d7fa0  vmovaps xmm12, [rsp+0xC0]
00007431745d7fa9  vmovaps xmm13, [rsp+0xD0]
00007431745d7fb2  vmovaps xmm14, [rsp+0xE0]
00007431745d7fbb  add rsp, 0xF0
00007431745d7fc2  pop r11
00007431745d7fc4  pop r10
00007431745d7fc6  pop r9
00007431745d7fc8  pop r8
00007431745d7fca  pop rsi
00007431745d7fcb  pop rdi
00007431745d7fcc  pop rdx
00007431745d7fcd  pop rcx
00007431745d7fce  pop rax
00007431745d7fcf  add rsp, 0x08
00007431745d7fd3  jmp 0x00007431745D5EE6
00007431745d7fd8  sub rsp, 0x08
00007431745d7fdc  push rax
00007431745d7fdd  push rcx
00007431745d7fde  push rdx
00007431745d7fdf  push rdi
00007431745d7fe0  push rsi
00007431745d7fe1  push r8
00007431745d7fe3  push r9
00007431745d7fe5  push r10
00007431745d7fe7  push r11
00007431745d7fe9  sub rsp, 0xF0
00007431745d7ff0  vmovaps [rsp], xmm0
00007431745d7ff5  vmovaps [rsp+0x10], xmm2
00007431745d7ffb  vmovaps [rsp+0x20], xmm3
00007431745d8001  vmovaps [rsp+0x30], xmm4
00007431745d8007  vmovaps [rsp+0x40], xmm5
00007431745d800d  vmovaps [rsp+0x50], xmm6
00007431745d8013  vmovaps [rsp+0x60], xmm7
00007431745d8019  vmovaps [rsp+0x70], xmm8
00007431745d801f  vmovaps [rsp+0x80], xmm9
00007431745d8028  vmovaps [rsp+0x90], xmm10
00007431745d8031  vmovaps [rsp+0xA0], xmm11
00007431745d803a  vmovaps [rsp+0xB0], xmm12
00007431745d8043  vmovaps [rsp+0xC0], xmm13
00007431745d804c  vmovaps [rsp+0xD0], xmm14
00007431745d8055  vmovaps [rsp+0xE0], xmm15
00007431745d805e  sub rsp, 0x30
00007431745d8062  movaps [rsp], xmm1
00007431745d8066  movaps [rsp+0x10], xmm5
00007431745d806b  movaps [rsp+0x20], xmm4
00007431745d8070  lea rdi, [rsp]
00007431745d8074  mov esi, 0x00
00007431745d8079  mov rax, 0x56C40959E530
00007431745d8083  call rax
00007431745d8085  movaps xmm1, [rsp]
00007431745d8089  add rsp, 0x30
00007431745d808d  vmovaps xmm0, [rsp]
00007431745d8092  vmovaps xmm2, [rsp+0x10]
00007431745d8098  vmovaps xmm3, [rsp+0x20]
00007431745d809e  vmovaps xmm4, [rsp+0x30]
00007431745d80a4  vmovaps xmm5, [rsp+0x40]
00007431745d80aa  vmovaps xmm6, [rsp+0x50]
00007431745d80b0  vmovaps xmm7, [rsp+0x60]
00007431745d80b6  vmovaps xmm8, [rsp+0x70]
00007431745d80bc  vmovaps xmm9, [rsp+0x80]
00007431745d80c5  vmovaps xmm10, [rsp+0x90]
00007431745d80ce  vmovaps xmm11, [rsp+0xA0]
00007431745d80d7  vmovaps xmm12, [rsp+0xB0]
00007431745d80e0  vmovaps xmm13, [rsp+0xC0]
00007431745d80e9  vmovaps xmm14, [rsp+0xD0]
00007431745d80f2  vmovaps xmm15, [rsp+0xE0]
00007431745d80fb  add rsp, 0xF0
00007431745d8102  pop r11
00007431745d8104  pop r10
00007431745d8106  pop r9
00007431745d8108  pop r8
00007431745d810a  pop rsi
00007431745d810b  pop rdi
00007431745d810c  pop rdx
00007431745d810d  pop rcx
00007431745d810e  pop rax
00007431745d810f  add rsp, 0x08
00007431745d8113  jmp 0x00007431745D5F06
00007431745d8118  sub rsp, 0x08
00007431745d811c  push rax
00007431745d811d  push rcx
00007431745d811e  push rdx
00007431745d811f  push rdi
00007431745d8120  push rsi
00007431745d8121  push r8
00007431745d8123  push r9
00007431745d8125  push r10
00007431745d8127  push r11
00007431745d8129  sub rsp, 0xF0
00007431745d8130  vmovaps [rsp], xmm0
00007431745d8135  vmovaps [rsp+0x10], xmm1
00007431745d813b  vmovaps [rsp+0x20], xmm2
00007431745d8141  vmovaps [rsp+0x30], xmm3
00007431745d8147  vmovaps [rsp+0x40], xmm5
00007431745d814d  vmovaps [rsp+0x50], xmm6
00007431745d8153  vmovaps [rsp+0x60], xmm7
00007431745d8159  vmovaps [rsp+0x70], xmm8
00007431745d815f  vmovaps [rsp+0x80], xmm9
00007431745d8168  vmovaps [rsp+0x90], xmm10
00007431745d8171  vmovaps [rsp+0xA0], xmm11
00007431745d817a  vmovaps [rsp+0xB0], xmm12
00007431745d8183  vmovaps [rsp+0xC0], xmm13
00007431745d818c  vmovaps [rsp+0xD0], xmm14
00007431745d8195  vmovaps [rsp+0xE0], xmm15
00007431745d819e  sub rsp, 0x30
00007431745d81a2  movaps [rsp], xmm4
00007431745d81a6  movaps [rsp+0x10], xmm3
00007431745d81ab  movaps [rsp+0x20], xmm5
00007431745d81b0  lea rdi, [rsp]
00007431745d81b4  mov esi, 0x00
00007431745d81b9  mov rax, 0x56C40959E530
00007431745d81c3  call rax
00007431745d81c5  movaps xmm4, [rsp]
00007431745d81c9  add rsp, 0x30
00007431745d81cd  vmovaps xmm0, [rsp]
00007431745d81d2  vmovaps xmm1, [rsp+0x10]
00007431745d81d8  vmovaps xmm2, [rsp+0x20]
00007431745d81de  vmovaps xmm3, [rsp+0x30]
00007431745d81e4  vmovaps xmm5, [rsp+0x40]
00007431745d81ea  vmovaps xmm6, [rsp+0x50]
00007431745d81f0  vmovaps xmm7, [rsp+0x60]
00007431745d81f6  vmovaps xmm8, [rsp+0x70]
00007431745d81fc  vmovaps xmm9, [rsp+0x80]
00007431745d8205  vmovaps xmm10, [rsp+0x90]
00007431745d820e  vmovaps xmm11, [rsp+0xA0]
00007431745d8217  vmovaps xmm12, [rsp+0xB0]
00007431745d8220  vmovaps xmm13, [rsp+0xC0]
00007431745d8229  vmovaps xmm14, [rsp+0xD0]
00007431745d8232  vmovaps xmm15, [rsp+0xE0]
00007431745d823b  add rsp, 0xF0
00007431745d8242  pop r11
00007431745d8244  pop r10
00007431745d8246  pop r9
00007431745d8248  pop r8
00007431745d824a  pop rsi
00007431745d824b  pop rdi
00007431745d824c  pop rdx
00007431745d824d  pop rcx
00007431745d824e  pop rax
00007431745d824f  add rsp, 0x08
00007431745d8253  jmp 0x00007431745D5F54
00007431745d8258  call 0x00007431744D64F0
00007431745d825d  jmp 0x00007431745D5F61
00007431745d8262  sub rsp, 0x08
00007431745d8266  push rax
00007431745d8267  push rcx
00007431745d8268  push rdx
00007431745d8269  push rdi
00007431745d826a  push rsi
00007431745d826b  push r8
00007431745d826d  push r9
00007431745d826f  push r10
00007431745d8271  push r11
00007431745d8273  sub rsp, 0xF0
00007431745d827a  vmovaps [rsp], xmm0
00007431745d827f  vmovaps [rsp+0x10], xmm1
00007431745d8285  vmovaps [rsp+0x20], xmm2
00007431745d828b  vmovaps [rsp+0x30], xmm3
00007431745d8291  vmovaps [rsp+0x40], xmm4
00007431745d8297  vmovaps [rsp+0x50], xmm6
00007431745d829d  vmovaps [rsp+0x60], xmm7
00007431745d82a3  vmovaps [rsp+0x70], xmm8
00007431745d82a9  vmovaps [rsp+0x80], xmm9
00007431745d82b2  vmovaps [rsp+0x90], xmm10
00007431745d82bb  vmovaps [rsp+0xA0], xmm11
00007431745d82c4  vmovaps [rsp+0xB0], xmm12
00007431745d82cd  vmovaps [rsp+0xC0], xmm13
00007431745d82d6  vmovaps [rsp+0xD0], xmm14
00007431745d82df  vmovaps [rsp+0xE0], xmm15
00007431745d82e8  sub rsp, 0x30
00007431745d82ec  movaps [rsp], xmm5
00007431745d82f0  movaps [rsp+0x10], xmm6
00007431745d82f5  movaps [rsp+0x20], xmm3
00007431745d82fa  lea rdi, [rsp]
00007431745d82fe  mov esi, 0x00
00007431745d8303  mov rax, 0x56C40959E530
00007431745d830d  call rax
00007431745d830f  movaps xmm5, [rsp]
00007431745d8313  add rsp, 0x30
00007431745d8317  vmovaps xmm0, [rsp]
00007431745d831c  vmovaps xmm1, [rsp+0x10]
00007431745d8322  vmovaps xmm2, [rsp+0x20]
00007431745d8328  vmovaps xmm3, [rsp+0x30]
00007431745d832e  vmovaps xmm4, [rsp+0x40]
00007431745d8334  vmovaps xmm6, [rsp+0x50]
00007431745d833a  vmovaps xmm7, [rsp+0x60]
00007431745d8340  vmovaps xmm8, [rsp+0x70]
00007431745d8346  vmovaps xmm9, [rsp+0x80]
00007431745d834f  vmovaps xmm10, [rsp+0x90]
00007431745d8358  vmovaps xmm11, [rsp+0xA0]
00007431745d8361  vmovaps xmm12, [rsp+0xB0]
00007431745d836a  vmovaps xmm13, [rsp+0xC0]
00007431745d8373  vmovaps xmm14, [rsp+0xD0]
00007431745d837c  vmovaps xmm15, [rsp+0xE0]
00007431745d8385  add rsp, 0xF0
00007431745d838c  pop r11
00007431745d838e  pop r10
00007431745d8390  pop r9
00007431745d8392  pop r8
00007431745d8394  pop rsi
00007431745d8395  pop rdi
00007431745d8396  pop rdx
00007431745d8397  pop rcx
00007431745d8398  pop rax
00007431745d8399  add rsp, 0x08
00007431745d839d  jmp 0x00007431745D5F87
00007431745d83a2  sub rsp, 0x08
00007431745d83a6  push rax
00007431745d83a7  push rcx
00007431745d83a8  push rdx
00007431745d83a9  push rdi
00007431745d83aa  push rsi
00007431745d83ab  push r8
00007431745d83ad  push r9
00007431745d83af  push r10
00007431745d83b1  push r11
00007431745d83b3  sub rsp, 0xF0
00007431745d83ba  vmovaps [rsp], xmm0
00007431745d83bf  vmovaps [rsp+0x10], xmm1
00007431745d83c5  vmovaps [rsp+0x20], xmm2
00007431745d83cb  vmovaps [rsp+0x30], xmm3
00007431745d83d1  vmovaps [rsp+0x40], xmm4
00007431745d83d7  vmovaps [rsp+0x50], xmm5
00007431745d83dd  vmovaps [rsp+0x60], xmm7
00007431745d83e3  vmovaps [rsp+0x70], xmm8
00007431745d83e9  vmovaps [rsp+0x80], xmm9
00007431745d83f2  vmovaps [rsp+0x90], xmm10
00007431745d83fb  vmovaps [rsp+0xA0], xmm11
00007431745d8404  vmovaps [rsp+0xB0], xmm12
00007431745d840d  vmovaps [rsp+0xC0], xmm13
00007431745d8416  vmovaps [rsp+0xD0], xmm14
00007431745d841f  vmovaps [rsp+0xE0], xmm15
00007431745d8428  sub rsp, 0x30
00007431745d842c  movaps [rsp], xmm6
00007431745d8430  movaps [rsp+0x10], xmm9
00007431745d8436  movaps [rsp+0x20], xmm1
00007431745d843b  lea rdi, [rsp]
00007431745d843f  mov esi, 0x00
00007431745d8444  mov rax, 0x56C40959E530
00007431745d844e  call rax
00007431745d8450  movaps xmm6, [rsp]
00007431745d8454  add rsp, 0x30
00007431745d8458  vmovaps xmm0, [rsp]
00007431745d845d  vmovaps xmm1, [rsp+0x10]
00007431745d8463  vmovaps xmm2, [rsp+0x20]
00007431745d8469  vmovaps xmm3, [rsp+0x30]
00007431745d846f  vmovaps xmm4, [rsp+0x40]
00007431745d8475  vmovaps xmm5, [rsp+0x50]
00007431745d847b  vmovaps xmm7, [rsp+0x60]
00007431745d8481  vmovaps xmm8, [rsp+0x70]
00007431745d8487  vmovaps xmm9, [rsp+0x80]
00007431745d8490  vmovaps xmm10, [rsp+0x90]
00007431745d8499  vmovaps xmm11, [rsp+0xA0]
00007431745d84a2  vmovaps xmm12, [rsp+0xB0]
00007431745d84ab  vmovaps xmm13, [rsp+0xC0]
00007431745d84b4  vmovaps xmm14, [rsp+0xD0]
00007431745d84bd  vmovaps xmm15, [rsp+0xE0]
00007431745d84c6  add rsp, 0xF0
00007431745d84cd  pop r11
00007431745d84cf  pop r10
00007431745d84d1  pop r9
00007431745d84d3  pop r8
00007431745d84d5  pop rsi
00007431745d84d6  pop rdi
00007431745d84d7  pop rdx
00007431745d84d8  pop rcx
00007431745d84d9  pop rax
00007431745d84da  add rsp, 0x08
00007431745d84de  jmp 0x00007431745D5FAB
00007431745d84e3  sub rsp, 0x08
00007431745d84e7  push rax
00007431745d84e8  push rcx
00007431745d84e9  push rdx
00007431745d84ea  push rdi
00007431745d84eb  push rsi
00007431745d84ec  push r8
00007431745d84ee  push r9
00007431745d84f0  push r10
00007431745d84f2  push r11
00007431745d84f4  sub rsp, 0xF0
00007431745d84fb  vmovaps [rsp], xmm0
00007431745d8500  vmovaps [rsp+0x10], xmm1
00007431745d8506  vmovaps [rsp+0x20], xmm2
00007431745d850c  vmovaps [rsp+0x30], xmm3
00007431745d8512  vmovaps [rsp+0x40], xmm4
00007431745d8518  vmovaps [rsp+0x50], xmm5
00007431745d851e  vmovaps [rsp+0x60], xmm6
00007431745d8524  vmovaps [rsp+0x70], xmm7
00007431745d852a  vmovaps [rsp+0x80], xmm8
00007431745d8533  vmovaps [rsp+0x90], xmm10
00007431745d853c  vmovaps [rsp+0xA0], xmm11
00007431745d8545  vmovaps [rsp+0xB0], xmm12
00007431745d854e  vmovaps [rsp+0xC0], xmm13
00007431745d8557  vmovaps [rsp+0xD0], xmm14
00007431745d8560  vmovaps [rsp+0xE0], xmm15
00007431745d8569  sub rsp, 0x30
00007431745d856d  movaps [rsp], xmm9
00007431745d8572  movaps [rsp+0x10], xmm3
00007431745d8577  movaps [rsp+0x20], xmm1
00007431745d857c  lea rdi, [rsp]
00007431745d8580  mov esi, 0x00
00007431745d8585  mov rax, 0x56C40959E530
00007431745d858f  call rax
00007431745d8591  movaps xmm9, [rsp]
00007431745d8596  add rsp, 0x30
00007431745d859a  vmovaps xmm0, [rsp]
00007431745d859f  vmovaps xmm1, [rsp+0x10]
00007431745d85a5  vmovaps xmm2, [rsp+0x20]
00007431745d85ab  vmovaps xmm3, [rsp+0x30]
00007431745d85b1  vmovaps xmm4, [rsp+0x40]
00007431745d85b7  vmovaps xmm5, [rsp+0x50]
00007431745d85bd  vmovaps xmm6, [rsp+0x60]
00007431745d85c3  vmovaps xmm7, [rsp+0x70]
00007431745d85c9  vmovaps xmm8, [rsp+0x80]
00007431745d85d2  vmovaps xmm10, [rsp+0x90]
00007431745d85db  vmovaps xmm11, [rsp+0xA0]
00007431745d85e4  vmovaps xmm12, [rsp+0xB0]
00007431745d85ed  vmovaps xmm13, [rsp+0xC0]
00007431745d85f6  vmovaps xmm14, [rsp+0xD0]
00007431745d85ff  vmovaps xmm15, [rsp+0xE0]
00007431745d8608  add rsp, 0xF0
00007431745d860f  pop r11
00007431745d8611  pop r10
00007431745d8613  pop r9
00007431745d8615  pop r8
00007431745d8617  pop rsi
00007431745d8618  pop rdi
00007431745d8619  pop rdx
00007431745d861a  pop rcx
00007431745d861b  pop rax
00007431745d861c  add rsp, 0x08
00007431745d8620  jmp 0x00007431745D5FF7
00007431745d8625  call 0x00007431744D64F0
00007431745d862a  jmp 0x00007431745D6004
00007431745d862f  sub rsp, 0x08
00007431745d8633  push rax
00007431745d8634  push rcx
00007431745d8635  push rdx
00007431745d8636  push rdi
00007431745d8637  push rsi
00007431745d8638  push r8
00007431745d863a  push r9
00007431745d863c  push r10
00007431745d863e  push r11
00007431745d8640  sub rsp, 0xF0
00007431745d8647  vmovaps [rsp], xmm0
00007431745d864c  vmovaps [rsp+0x10], xmm1
00007431745d8652  vmovaps [rsp+0x20], xmm2
00007431745d8658  vmovaps [rsp+0x30], xmm3
00007431745d865e  vmovaps [rsp+0x40], xmm4
00007431745d8664  vmovaps [rsp+0x50], xmm5
00007431745d866a  vmovaps [rsp+0x60], xmm6
00007431745d8670  vmovaps [rsp+0x70], xmm7
00007431745d8676  vmovaps [rsp+0x80], xmm8
00007431745d867f  vmovaps [rsp+0x90], xmm9
00007431745d8688  vmovaps [rsp+0xA0], xmm10
00007431745d8691  vmovaps [rsp+0xB0], xmm11
00007431745d869a  vmovaps [rsp+0xC0], xmm12
00007431745d86a3  vmovaps [rsp+0xD0], xmm13
00007431745d86ac  vmovaps [rsp+0xE0], xmm14
00007431745d86b5  sub rsp, 0x30
00007431745d86b9  movaps [rsp], xmm15
00007431745d86be  movaps [rsp+0x10], xmm3
00007431745d86c3  movaps [rsp+0x20], xmm7
00007431745d86c8  lea rdi, [rsp]
00007431745d86cc  mov esi, 0x00
00007431745d86d1  mov rax, 0x56C40959E530
00007431745d86db  call rax
00007431745d86dd  movaps xmm15, [rsp]
00007431745d86e2  add rsp, 0x30
00007431745d86e6  vmovaps xmm0, [rsp]
00007431745d86eb  vmovaps xmm1, [rsp+0x10]
00007431745d86f1  vmovaps xmm2, [rsp+0x20]
00007431745d86f7  vmovaps xmm3, [rsp+0x30]
00007431745d86fd  vmovaps xmm4, [rsp+0x40]
00007431745d8703  vmovaps xmm5, [rsp+0x50]
00007431745d8709  vmovaps xmm6, [rsp+0x60]
00007431745d870f  vmovaps xmm7, [rsp+0x70]
00007431745d8715  vmovaps xmm8, [rsp+0x80]
00007431745d871e  vmovaps xmm9, [rsp+0x90]
00007431745d8727  vmovaps xmm10, [rsp+0xA0]
00007431745d8730  vmovaps xmm11, [rsp+0xB0]
00007431745d8739  vmovaps xmm12, [rsp+0xC0]
00007431745d8742  vmovaps xmm13, [rsp+0xD0]
00007431745d874b  vmovaps xmm14, [rsp+0xE0]
00007431745d8754  add rsp, 0xF0
00007431745d875b  pop r11
00007431745d875d  pop r10
00007431745d875f  pop r9
00007431745d8761  pop r8
00007431745d8763  pop rsi
00007431745d8764  pop rdi
00007431745d8765  pop rdx
00007431745d8766  pop rcx
00007431745d8767  pop rax
00007431745d8768  add rsp, 0x08
00007431745d876c  jmp 0x00007431745D6030
00007431745d8771  sub rsp, 0x08
00007431745d8775  push rax
00007431745d8776  push rcx
00007431745d8777  push rdx
00007431745d8778  push rdi
00007431745d8779  push rsi
00007431745d877a  push r8
00007431745d877c  push r9
00007431745d877e  push r10
00007431745d8780  push r11
00007431745d8782  sub rsp, 0xF0
00007431745d8789  vmovaps [rsp], xmm0
00007431745d878e  vmovaps [rsp+0x10], xmm1
00007431745d8794  vmovaps [rsp+0x20], xmm2
00007431745d879a  vmovaps [rsp+0x30], xmm4
00007431745d87a0  vmovaps [rsp+0x40], xmm5
00007431745d87a6  vmovaps [rsp+0x50], xmm6
00007431745d87ac  vmovaps [rsp+0x60], xmm7
00007431745d87b2  vmovaps [rsp+0x70], xmm8
00007431745d87b8  vmovaps [rsp+0x80], xmm9
00007431745d87c1  vmovaps [rsp+0x90], xmm10
00007431745d87ca  vmovaps [rsp+0xA0], xmm11
00007431745d87d3  vmovaps [rsp+0xB0], xmm12
00007431745d87dc  vmovaps [rsp+0xC0], xmm13
00007431745d87e5  vmovaps [rsp+0xD0], xmm14
00007431745d87ee  vmovaps [rsp+0xE0], xmm15
00007431745d87f7  sub rsp, 0x30
00007431745d87fb  movaps [rsp], xmm3
00007431745d87ff  movaps [rsp+0x10], xmm1
00007431745d8804  movaps [rsp+0x20], xmm15
00007431745d880a  lea rdi, [rsp]
00007431745d880e  mov esi, 0x00
00007431745d8813  mov rax, 0x56C40959E530
00007431745d881d  call rax
00007431745d881f  movaps xmm3, [rsp]
00007431745d8823  add rsp, 0x30
00007431745d8827  vmovaps xmm0, [rsp]
00007431745d882c  vmovaps xmm1, [rsp+0x10]
00007431745d8832  vmovaps xmm2, [rsp+0x20]
00007431745d8838  vmovaps xmm4, [rsp+0x30]
00007431745d883e  vmovaps xmm5, [rsp+0x40]
00007431745d8844  vmovaps xmm6, [rsp+0x50]
00007431745d884a  vmovaps xmm7, [rsp+0x60]
00007431745d8850  vmovaps xmm8, [rsp+0x70]
00007431745d8856  vmovaps xmm9, [rsp+0x80]
00007431745d885f  vmovaps xmm10, [rsp+0x90]
00007431745d8868  vmovaps xmm11, [rsp+0xA0]
00007431745d8871  vmovaps xmm12, [rsp+0xB0]
00007431745d887a  vmovaps xmm13, [rsp+0xC0]
00007431745d8883  vmovaps xmm14, [rsp+0xD0]
00007431745d888c  vmovaps xmm15, [rsp+0xE0]
00007431745d8895  add rsp, 0xF0
00007431745d889c  pop r11
00007431745d889e  pop r10
00007431745d88a0  pop r9
00007431745d88a2  pop r8
00007431745d88a4  pop rsi
00007431745d88a5  pop rdi
00007431745d88a6  pop rdx
00007431745d88a7  pop rcx
00007431745d88a8  pop rax
00007431745d88a9  add rsp, 0x08
00007431745d88ad  jmp 0x00007431745D60BF
00007431745d88b2  call 0x00007431744D64F0
00007431745d88b7  jmp 0x00007431745D60C9
00007431745d88bc  sub rsp, 0x08
00007431745d88c0  push rax
00007431745d88c1  push rcx
00007431745d88c2  push rdx
00007431745d88c3  push rdi
00007431745d88c4  push rsi
00007431745d88c5  push r8
00007431745d88c7  push r9
00007431745d88c9  push r10
00007431745d88cb  push r11
00007431745d88cd  sub rsp, 0xF0
00007431745d88d4  vmovaps [rsp], xmm0
00007431745d88d9  vmovaps [rsp+0x10], xmm1
00007431745d88df  vmovaps [rsp+0x20], xmm2
00007431745d88e5  vmovaps [rsp+0x30], xmm3
00007431745d88eb  vmovaps [rsp+0x40], xmm4
00007431745d88f1  vmovaps [rsp+0x50], xmm5
00007431745d88f7  vmovaps [rsp+0x60], xmm6
00007431745d88fd  vmovaps [rsp+0x70], xmm7
00007431745d8903  vmovaps [rsp+0x80], xmm8
00007431745d890c  vmovaps [rsp+0x90], xmm9
00007431745d8915  vmovaps [rsp+0xA0], xmm10
00007431745d891e  vmovaps [rsp+0xB0], xmm11
00007431745d8927  vmovaps [rsp+0xC0], xmm12
00007431745d8930  vmovaps [rsp+0xD0], xmm13
00007431745d8939  vmovaps [rsp+0xE0], xmm14
00007431745d8942  sub rsp, 0x30
00007431745d8946  movaps [rsp], xmm15
00007431745d894b  movaps [rsp+0x10], xmm14
00007431745d8951  movaps [rsp+0x20], xmm4
00007431745d8956  lea rdi, [rsp]
00007431745d895a  mov esi, 0x00
00007431745d895f  mov rax, 0x56C40959E530
00007431745d8969  call rax
00007431745d896b  movaps xmm15, [rsp]
00007431745d8970  add rsp, 0x30
00007431745d8974  vmovaps xmm0, [rsp]
00007431745d8979  vmovaps xmm1, [rsp+0x10]
00007431745d897f  vmovaps xmm2, [rsp+0x20]
00007431745d8985  vmovaps xmm3, [rsp+0x30]
00007431745d898b  vmovaps xmm4, [rsp+0x40]
00007431745d8991  vmovaps xmm5, [rsp+0x50]
00007431745d8997  vmovaps xmm6, [rsp+0x60]
00007431745d899d  vmovaps xmm7, [rsp+0x70]
00007431745d89a3  vmovaps xmm8, [rsp+0x80]
00007431745d89ac  vmovaps xmm9, [rsp+0x90]
00007431745d89b5  vmovaps xmm10, [rsp+0xA0]
00007431745d89be  vmovaps xmm11, [rsp+0xB0]
00007431745d89c7  vmovaps xmm12, [rsp+0xC0]
00007431745d89d0  vmovaps xmm13, [rsp+0xD0]
00007431745d89d9  vmovaps xmm14, [rsp+0xE0]
00007431745d89e2  add rsp, 0xF0
00007431745d89e9  pop r11
00007431745d89eb  pop r10
00007431745d89ed  pop r9
00007431745d89ef  pop r8
00007431745d89f1  pop rsi
00007431745d89f2  pop rdi
00007431745d89f3  pop rdx
00007431745d89f4  pop rcx
00007431745d89f5  pop rax
00007431745d89f6  add rsp, 0x08
00007431745d89fa  jmp 0x00007431745D60F7
00007431745d89ff  sub rsp, 0x08
00007431745d8a03  push rax
00007431745d8a04  push rcx
00007431745d8a05  push rdx
00007431745d8a06  push rdi
00007431745d8a07  push rsi
00007431745d8a08  push r8
00007431745d8a0a  push r9
00007431745d8a0c  push r10
00007431745d8a0e  push r11
00007431745d8a10  sub rsp, 0xF0
00007431745d8a17  vmovaps [rsp], xmm0
00007431745d8a1c  vmovaps [rsp+0x10], xmm1
00007431745d8a22  vmovaps [rsp+0x20], xmm2
00007431745d8a28  vmovaps [rsp+0x30], xmm3
00007431745d8a2e  vmovaps [rsp+0x40], xmm4
00007431745d8a34  vmovaps [rsp+0x50], xmm5
00007431745d8a3a  vmovaps [rsp+0x60], xmm6
00007431745d8a40  vmovaps [rsp+0x70], xmm7
00007431745d8a46  vmovaps [rsp+0x80], xmm8
00007431745d8a4f  vmovaps [rsp+0x90], xmm9
00007431745d8a58  vmovaps [rsp+0xA0], xmm10
00007431745d8a61  vmovaps [rsp+0xB0], xmm11
00007431745d8a6a  vmovaps [rsp+0xC0], xmm12
00007431745d8a73  vmovaps [rsp+0xD0], xmm13
00007431745d8a7c  vmovaps [rsp+0xE0], xmm15
00007431745d8a85  sub rsp, 0x30
00007431745d8a89  movaps [rsp], xmm14
00007431745d8a8e  movaps [rsp+0x10], xmm2
00007431745d8a93  movaps [rsp+0x20], xmm1
00007431745d8a98  lea rdi, [rsp]
00007431745d8a9c  mov esi, 0x00
00007431745d8aa1  mov rax, 0x56C40959E530
00007431745d8aab  call rax
00007431745d8aad  movaps xmm14, [rsp]
00007431745d8ab2  add rsp, 0x30
00007431745d8ab6  vmovaps xmm0, [rsp]
00007431745d8abb  vmovaps xmm1, [rsp+0x10]
00007431745d8ac1  vmovaps xmm2, [rsp+0x20]
00007431745d8ac7  vmovaps xmm3, [rsp+0x30]
00007431745d8acd  vmovaps xmm4, [rsp+0x40]
00007431745d8ad3  vmovaps xmm5, [rsp+0x50]
00007431745d8ad9  vmovaps xmm6, [rsp+0x60]
00007431745d8adf  vmovaps xmm7, [rsp+0x70]
00007431745d8ae5  vmovaps xmm8, [rsp+0x80]
00007431745d8aee  vmovaps xmm9, [rsp+0x90]
00007431745d8af7  vmovaps xmm10, [rsp+0xA0]
00007431745d8b00  vmovaps xmm11, [rsp+0xB0]
00007431745d8b09  vmovaps xmm12, [rsp+0xC0]
00007431745d8b12  vmovaps xmm13, [rsp+0xD0]
00007431745d8b1b  vmovaps xmm15, [rsp+0xE0]
00007431745d8b24  add rsp, 0xF0
00007431745d8b2b  pop r11
00007431745d8b2d  pop r10
00007431745d8b2f  pop r9
00007431745d8b31  pop r8
00007431745d8b33  pop rsi
00007431745d8b34  pop rdi
00007431745d8b35  pop rdx
00007431745d8b36  pop rcx
00007431745d8b37  pop rax
00007431745d8b38  add rsp, 0x08
00007431745d8b3c  jmp 0x00007431745D611D
00007431745d8b41  sub rsp, 0x08
00007431745d8b45  push rax
00007431745d8b46  push rcx
00007431745d8b47  push rdx
00007431745d8b48  push rdi
00007431745d8b49  push rsi
00007431745d8b4a  push r8
00007431745d8b4c  push r9
00007431745d8b4e  push r10
00007431745d8b50  push r11
00007431745d8b52  sub rsp, 0xF0
00007431745d8b59  vmovaps [rsp], xmm0
00007431745d8b5e  vmovaps [rsp+0x10], xmm2
00007431745d8b64  vmovaps [rsp+0x20], xmm3
00007431745d8b6a  vmovaps [rsp+0x30], xmm4
00007431745d8b70  vmovaps [rsp+0x40], xmm5
00007431745d8b76  vmovaps [rsp+0x50], xmm6
00007431745d8b7c  vmovaps [rsp+0x60], xmm7
00007431745d8b82  vmovaps [rsp+0x70], xmm8
00007431745d8b88  vmovaps [rsp+0x80], xmm9
00007431745d8b91  vmovaps [rsp+0x90], xmm10
00007431745d8b9a  vmovaps [rsp+0xA0], xmm11
00007431745d8ba3  vmovaps [rsp+0xB0], xmm12
00007431745d8bac  vmovaps [rsp+0xC0], xmm13
00007431745d8bb5  vmovaps [rsp+0xD0], xmm14
00007431745d8bbe  vmovaps [rsp+0xE0], xmm15
00007431745d8bc7  sub rsp, 0x30
00007431745d8bcb  movaps [rsp], xmm1
00007431745d8bcf  movaps [rsp+0x10], xmm4
00007431745d8bd4  movaps [rsp+0x20], xmm9
00007431745d8bda  lea rdi, [rsp]
00007431745d8bde  mov esi, 0x00
00007431745d8be3  mov rax, 0x56C40959E530
00007431745d8bed  call rax
00007431745d8bef  movaps xmm1, [rsp]
00007431745d8bf3  add rsp, 0x30
00007431745d8bf7  vmovaps xmm0, [rsp]
00007431745d8bfc  vmovaps xmm2, [rsp+0x10]
00007431745d8c02  vmovaps xmm3, [rsp+0x20]
00007431745d8c08  vmovaps xmm4, [rsp+0x30]
00007431745d8c0e  vmovaps xmm5, [rsp+0x40]
00007431745d8c14  vmovaps xmm6, [rsp+0x50]
00007431745d8c1a  vmovaps xmm7, [rsp+0x60]
00007431745d8c20  vmovaps xmm8, [rsp+0x70]
00007431745d8c26  vmovaps xmm9, [rsp+0x80]
00007431745d8c2f  vmovaps xmm10, [rsp+0x90]
00007431745d8c38  vmovaps xmm11, [rsp+0xA0]
00007431745d8c41  vmovaps xmm12, [rsp+0xB0]
00007431745d8c4a  vmovaps xmm13, [rsp+0xC0]
00007431745d8c53  vmovaps xmm14, [rsp+0xD0]
00007431745d8c5c  vmovaps xmm15, [rsp+0xE0]
00007431745d8c65  add rsp, 0xF0
00007431745d8c6c  pop r11
00007431745d8c6e  pop r10
00007431745d8c70  pop r9
00007431745d8c72  pop r8
00007431745d8c74  pop rsi
00007431745d8c75  pop rdi
00007431745d8c76  pop rdx
00007431745d8c77  pop rcx
00007431745d8c78  pop rax
00007431745d8c79  add rsp, 0x08
00007431745d8c7d  jmp 0x00007431745D613B
00007431745d8c82  sub rsp, 0x08
00007431745d8c86  push rax
00007431745d8c87  push rcx
00007431745d8c88  push rdx
00007431745d8c89  push rdi
00007431745d8c8a  push rsi
00007431745d8c8b  push r8
00007431745d8c8d  push r9
00007431745d8c8f  push r10
00007431745d8c91  push r11
00007431745d8c93  sub rsp, 0xF0
00007431745d8c9a  vmovaps [rsp], xmm0
00007431745d8c9f  vmovaps [rsp+0x10], xmm1
00007431745d8ca5  vmovaps [rsp+0x20], xmm2
00007431745d8cab  vmovaps [rsp+0x30], xmm3
00007431745d8cb1  vmovaps [rsp+0x40], xmm5
00007431745d8cb7  vmovaps [rsp+0x50], xmm6
00007431745d8cbd  vmovaps [rsp+0x60], xmm7
00007431745d8cc3  vmovaps [rsp+0x70], xmm8
00007431745d8cc9  vmovaps [rsp+0x80], xmm9
00007431745d8cd2  vmovaps [rsp+0x90], xmm10
00007431745d8cdb  vmovaps [rsp+0xA0], xmm11
00007431745d8ce4  vmovaps [rsp+0xB0], xmm12
00007431745d8ced  vmovaps [rsp+0xC0], xmm13
00007431745d8cf6  vmovaps [rsp+0xD0], xmm14
00007431745d8cff  vmovaps [rsp+0xE0], xmm15
00007431745d8d08  sub rsp, 0x30
00007431745d8d0c  movaps [rsp], xmm4
00007431745d8d10  movaps [rsp+0x10], xmm2
00007431745d8d15  movaps [rsp+0x20], xmm9
00007431745d8d1b  lea rdi, [rsp]
00007431745d8d1f  mov esi, 0x00
00007431745d8d24  mov rax, 0x56C40959E530
00007431745d8d2e  call rax
00007431745d8d30  movaps xmm4, [rsp]
00007431745d8d34  add rsp, 0x30
00007431745d8d38  vmovaps xmm0, [rsp]
00007431745d8d3d  vmovaps xmm1, [rsp+0x10]
00007431745d8d43  vmovaps xmm2, [rsp+0x20]
00007431745d8d49  vmovaps xmm3, [rsp+0x30]
00007431745d8d4f  vmovaps xmm5, [rsp+0x40]
00007431745d8d55  vmovaps xmm6, [rsp+0x50]
00007431745d8d5b  vmovaps xmm7, [rsp+0x60]
00007431745d8d61  vmovaps xmm8, [rsp+0x70]
00007431745d8d67  vmovaps xmm9, [rsp+0x80]
00007431745d8d70  vmovaps xmm10, [rsp+0x90]
00007431745d8d79  vmovaps xmm11, [rsp+0xA0]
00007431745d8d82  vmovaps xmm12, [rsp+0xB0]
00007431745d8d8b  vmovaps xmm13, [rsp+0xC0]
00007431745d8d94  vmovaps xmm14, [rsp+0xD0]
00007431745d8d9d  vmovaps xmm15, [rsp+0xE0]
00007431745d8da6  add rsp, 0xF0
00007431745d8dad  pop r11
00007431745d8daf  pop r10
00007431745d8db1  pop r9
00007431745d8db3  pop r8
00007431745d8db5  pop rsi
00007431745d8db6  pop rdi
00007431745d8db7  pop rdx
00007431745d8db8  pop rcx
00007431745d8db9  pop rax
00007431745d8dba  add rsp, 0x08
00007431745d8dbe  jmp 0x00007431745D616B
00007431745d8dc3  sub rsp, 0x08
00007431745d8dc7  push rax
00007431745d8dc8  push rcx
00007431745d8dc9  push rdx
00007431745d8dca  push rdi
00007431745d8dcb  push rsi
00007431745d8dcc  push r8
00007431745d8dce  push r9
00007431745d8dd0  push r10
00007431745d8dd2  push r11
00007431745d8dd4  sub rsp, 0xF0
00007431745d8ddb  vmovaps [rsp], xmm0
00007431745d8de0  vmovaps [rsp+0x10], xmm1
00007431745d8de6  vmovaps [rsp+0x20], xmm2
00007431745d8dec  vmovaps [rsp+0x30], xmm3
00007431745d8df2  vmovaps [rsp+0x40], xmm4
00007431745d8df8  vmovaps [rsp+0x50], xmm5
00007431745d8dfe  vmovaps [rsp+0x60], xmm6
00007431745d8e04  vmovaps [rsp+0x70], xmm7
00007431745d8e0a  vmovaps [rsp+0x80], xmm8
00007431745d8e13  vmovaps [rsp+0x90], xmm10
00007431745d8e1c  vmovaps [rsp+0xA0], xmm11
00007431745d8e25  vmovaps [rsp+0xB0], xmm12
00007431745d8e2e  vmovaps [rsp+0xC0], xmm13
00007431745d8e37  vmovaps [rsp+0xD0], xmm14
00007431745d8e40  vmovaps [rsp+0xE0], xmm15
00007431745d8e49  sub rsp, 0x30
00007431745d8e4d  movaps [rsp], xmm9
00007431745d8e52  movaps [rsp+0x10], xmm2
00007431745d8e57  movaps [rsp+0x20], xmm1
00007431745d8e5c  lea rdi, [rsp]
00007431745d8e60  mov esi, 0x00
00007431745d8e65  mov rax, 0x56C40959E530
00007431745d8e6f  call rax
00007431745d8e71  movaps xmm9, [rsp]
00007431745d8e76  add rsp, 0x30
00007431745d8e7a  vmovaps xmm0, [rsp]
00007431745d8e7f  vmovaps xmm1, [rsp+0x10]
00007431745d8e85  vmovaps xmm2, [rsp+0x20]
00007431745d8e8b  vmovaps xmm3, [rsp+0x30]
00007431745d8e91  vmovaps xmm4, [rsp+0x40]
00007431745d8e97  vmovaps xmm5, [rsp+0x50]
00007431745d8e9d  vmovaps xmm6, [rsp+0x60]
00007431745d8ea3  vmovaps xmm7, [rsp+0x70]
00007431745d8ea9  vmovaps xmm8, [rsp+0x80]
00007431745d8eb2  vmovaps xmm10, [rsp+0x90]
00007431745d8ebb  vmovaps xmm11, [rsp+0xA0]
00007431745d8ec4  vmovaps xmm12, [rsp+0xB0]
00007431745d8ecd  vmovaps xmm13, [rsp+0xC0]
00007431745d8ed6  vmovaps xmm14, [rsp+0xD0]
00007431745d8edf  vmovaps xmm15, [rsp+0xE0]
00007431745d8ee8  add rsp, 0xF0
00007431745d8eef  pop r11
00007431745d8ef1  pop r10
00007431745d8ef3  pop r9
00007431745d8ef5  pop r8
00007431745d8ef7  pop rsi
00007431745d8ef8  pop rdi
00007431745d8ef9  pop rdx
00007431745d8efa  pop rcx
00007431745d8efb  pop rax
00007431745d8efc  add rsp, 0x08
00007431745d8f00  jmp 0x00007431745D61A1
00007431745d8f05  sub rsp, 0x08
00007431745d8f09  push rax
00007431745d8f0a  push rcx
00007431745d8f0b  push rdx
00007431745d8f0c  push rdi
00007431745d8f0d  push rsi
00007431745d8f0e  push r8
00007431745d8f10  push r9
00007431745d8f12  push r10
00007431745d8f14  push r11
00007431745d8f16  sub rsp, 0xF0
00007431745d8f1d  vmovaps [rsp], xmm0
00007431745d8f22  vmovaps [rsp+0x10], xmm2
00007431745d8f28  vmovaps [rsp+0x20], xmm3
00007431745d8f2e  vmovaps [rsp+0x30], xmm4
00007431745d8f34  vmovaps [rsp+0x40], xmm5
00007431745d8f3a  vmovaps [rsp+0x50], xmm6
00007431745d8f40  vmovaps [rsp+0x60], xmm7
00007431745d8f46  vmovaps [rsp+0x70], xmm8
00007431745d8f4c  vmovaps [rsp+0x80], xmm9
00007431745d8f55  vmovaps [rsp+0x90], xmm10
00007431745d8f5e  vmovaps [rsp+0xA0], xmm11
00007431745d8f67  vmovaps [rsp+0xB0], xmm12
00007431745d8f70  vmovaps [rsp+0xC0], xmm13
00007431745d8f79  vmovaps [rsp+0xD0], xmm14
00007431745d8f82  vmovaps [rsp+0xE0], xmm15
00007431745d8f8b  sub rsp, 0x30
00007431745d8f8f  movaps [rsp], xmm1
00007431745d8f93  movaps [rsp+0x10], xmm15
00007431745d8f99  movaps [rsp+0x20], xmm6
00007431745d8f9e  lea rdi, [rsp]
00007431745d8fa2  mov esi, 0x00
00007431745d8fa7  mov rax, 0x56C40959E530
00007431745d8fb1  call rax
00007431745d8fb3  movaps xmm1, [rsp]
00007431745d8fb7  add rsp, 0x30
00007431745d8fbb  vmovaps xmm0, [rsp]
00007431745d8fc0  vmovaps xmm2, [rsp+0x10]
00007431745d8fc6  vmovaps xmm3, [rsp+0x20]
00007431745d8fcc  vmovaps xmm4, [rsp+0x30]
00007431745d8fd2  vmovaps xmm5, [rsp+0x40]
00007431745d8fd8  vmovaps xmm6, [rsp+0x50]
00007431745d8fde  vmovaps xmm7, [rsp+0x60]
00007431745d8fe4  vmovaps xmm8, [rsp+0x70]
00007431745d8fea  vmovaps xmm9, [rsp+0x80]
00007431745d8ff3  vmovaps xmm10, [rsp+0x90]
00007431745d8ffc  vmovaps xmm11, [rsp+0xA0]
00007431745d9005  vmovaps xmm12, [rsp+0xB0]
00007431745d900e  vmovaps xmm13, [rsp+0xC0]
00007431745d9017  vmovaps xmm14, [rsp+0xD0]
00007431745d9020  vmovaps xmm15, [rsp+0xE0]
00007431745d9029  add rsp, 0xF0
00007431745d9030  pop r11
00007431745d9032  pop r10
00007431745d9034  pop r9
00007431745d9036  pop r8
00007431745d9038  pop rsi
00007431745d9039  pop rdi
00007431745d903a  pop rdx
00007431745d903b  pop rcx
00007431745d903c  pop rax
00007431745d903d  add rsp, 0x08
00007431745d9041  jmp 0x00007431745D61C2
00007431745d9046  sub rsp, 0x08
00007431745d904a  push rax
00007431745d904b  push rcx
00007431745d904c  push rdx
00007431745d904d  push rdi
00007431745d904e  push rsi
00007431745d904f  push r8
00007431745d9051  push r9
00007431745d9053  push r10
00007431745d9055  push r11
00007431745d9057  sub rsp, 0xF0
00007431745d905e  vmovaps [rsp], xmm0
00007431745d9063  vmovaps [rsp+0x10], xmm1
00007431745d9069  vmovaps [rsp+0x20], xmm2
00007431745d906f  vmovaps [rsp+0x30], xmm3
00007431745d9075  vmovaps [rsp+0x40], xmm4
00007431745d907b  vmovaps [rsp+0x50], xmm5
00007431745d9081  vmovaps [rsp+0x60], xmm6
00007431745d9087  vmovaps [rsp+0x70], xmm7
00007431745d908d  vmovaps [rsp+0x80], xmm8
00007431745d9096  vmovaps [rsp+0x90], xmm9
00007431745d909f  vmovaps [rsp+0xA0], xmm10
00007431745d90a8  vmovaps [rsp+0xB0], xmm11
00007431745d90b1  vmovaps [rsp+0xC0], xmm12
00007431745d90ba  vmovaps [rsp+0xD0], xmm13
00007431745d90c3  vmovaps [rsp+0xE0], xmm14
00007431745d90cc  sub rsp, 0x30
00007431745d90d0  movaps [rsp], xmm15
00007431745d90d5  movaps [rsp+0x10], xmm5
00007431745d90da  movaps [rsp+0x20], xmm3
00007431745d90df  lea rdi, [rsp]
00007431745d90e3  mov esi, 0x00
00007431745d90e8  mov rax, 0x56C40959E530
00007431745d90f2  call rax
00007431745d90f4  movaps xmm15, [rsp]
00007431745d90f9  add rsp, 0x30
00007431745d90fd  vmovaps xmm0, [rsp]
00007431745d9102  vmovaps xmm1, [rsp+0x10]
00007431745d9108  vmovaps xmm2, [rsp+0x20]
00007431745d910e  vmovaps xmm3, [rsp+0x30]
00007431745d9114  vmovaps xmm4, [rsp+0x40]
00007431745d911a  vmovaps xmm5, [rsp+0x50]
00007431745d9120  vmovaps xmm6, [rsp+0x60]
00007431745d9126  vmovaps xmm7, [rsp+0x70]
00007431745d912c  vmovaps xmm8, [rsp+0x80]
00007431745d9135  vmovaps xmm9, [rsp+0x90]
00007431745d913e  vmovaps xmm10, [rsp+0xA0]
00007431745d9147  vmovaps xmm11, [rsp+0xB0]
00007431745d9150  vmovaps xmm12, [rsp+0xC0]
00007431745d9159  vmovaps xmm13, [rsp+0xD0]
00007431745d9162  vmovaps xmm14, [rsp+0xE0]
00007431745d916b  add rsp, 0xF0
00007431745d9172  pop r11
00007431745d9174  pop r10
00007431745d9176  pop r9
00007431745d9178  pop r8
00007431745d917a  pop rsi
00007431745d917b  pop rdi
00007431745d917c  pop rdx
00007431745d917d  pop rcx
00007431745d917e  pop rax
00007431745d917f  add rsp, 0x08
00007431745d9183  jmp 0x00007431745D61DC
00007431745d9188  sub rsp, 0x08
00007431745d918c  push rax
00007431745d918d  push rcx
00007431745d918e  push rdx
00007431745d918f  push rdi
00007431745d9190  push rsi
00007431745d9191  push r8
00007431745d9193  push r9
00007431745d9195  push r10
00007431745d9197  push r11
00007431745d9199  sub rsp, 0xF0
00007431745d91a0  vmovaps [rsp], xmm0
00007431745d91a5  vmovaps [rsp+0x10], xmm1
00007431745d91ab  vmovaps [rsp+0x20], xmm2
00007431745d91b1  vmovaps [rsp+0x30], xmm3
00007431745d91b7  vmovaps [rsp+0x40], xmm4
00007431745d91bd  vmovaps [rsp+0x50], xmm6
00007431745d91c3  vmovaps [rsp+0x60], xmm7
00007431745d91c9  vmovaps [rsp+0x70], xmm8
00007431745d91cf  vmovaps [rsp+0x80], xmm9
00007431745d91d8  vmovaps [rsp+0x90], xmm10
00007431745d91e1  vmovaps [rsp+0xA0], xmm11
00007431745d91ea  vmovaps [rsp+0xB0], xmm12
00007431745d91f3  vmovaps [rsp+0xC0], xmm13
00007431745d91fc  vmovaps [rsp+0xD0], xmm14
00007431745d9205  vmovaps [rsp+0xE0], xmm15
00007431745d920e  sub rsp, 0x30
00007431745d9212  movaps [rsp], xmm5
00007431745d9216  movaps [rsp+0x10], xmm8
00007431745d921c  movaps [rsp+0x20], xmm6
00007431745d9221  lea rdi, [rsp]
00007431745d9225  mov esi, 0x00
00007431745d922a  mov rax, 0x56C40959E530
00007431745d9234  call rax
00007431745d9236  movaps xmm5, [rsp]
00007431745d923a  add rsp, 0x30
00007431745d923e  vmovaps xmm0, [rsp]
00007431745d9243  vmovaps xmm1, [rsp+0x10]
00007431745d9249  vmovaps xmm2, [rsp+0x20]
00007431745d924f  vmovaps xmm3, [rsp+0x30]
00007431745d9255  vmovaps xmm4, [rsp+0x40]
00007431745d925b  vmovaps xmm6, [rsp+0x50]
00007431745d9261  vmovaps xmm7, [rsp+0x60]
00007431745d9267  vmovaps xmm8, [rsp+0x70]
00007431745d926d  vmovaps xmm9, [rsp+0x80]
00007431745d9276  vmovaps xmm10, [rsp+0x90]
00007431745d927f  vmovaps xmm11, [rsp+0xA0]
00007431745d9288  vmovaps xmm12, [rsp+0xB0]
00007431745d9291  vmovaps xmm13, [rsp+0xC0]
00007431745d929a  vmovaps xmm14, [rsp+0xD0]
00007431745d92a3  vmovaps xmm15, [rsp+0xE0]
00007431745d92ac  add rsp, 0xF0
00007431745d92b3  pop r11
00007431745d92b5  pop r10
00007431745d92b7  pop r9
00007431745d92b9  pop r8
00007431745d92bb  pop rsi
00007431745d92bc  pop rdi
00007431745d92bd  pop rdx
00007431745d92be  pop rcx
00007431745d92bf  pop rax
00007431745d92c0  add rsp, 0x08
00007431745d92c4  jmp 0x00007431745D6200
00007431745d92c9  sub rsp, 0x08
00007431745d92cd  push rax
00007431745d92ce  push rcx
00007431745d92cf  push rdx
00007431745d92d0  push rdi
00007431745d92d1  push rsi
00007431745d92d2  push r8
00007431745d92d4  push r9
00007431745d92d6  push r10
00007431745d92d8  push r11
00007431745d92da  sub rsp, 0xF0
00007431745d92e1  vmovaps [rsp], xmm0
00007431745d92e6  vmovaps [rsp+0x10], xmm1
00007431745d92ec  vmovaps [rsp+0x20], xmm2
00007431745d92f2  vmovaps [rsp+0x30], xmm3
00007431745d92f8  vmovaps [rsp+0x40], xmm4
00007431745d92fe  vmovaps [rsp+0x50], xmm5
00007431745d9304  vmovaps [rsp+0x60], xmm7
00007431745d930a  vmovaps [rsp+0x70], xmm8
00007431745d9310  vmovaps [rsp+0x80], xmm9
00007431745d9319  vmovaps [rsp+0x90], xmm10
00007431745d9322  vmovaps [rsp+0xA0], xmm11
00007431745d932b  vmovaps [rsp+0xB0], xmm12
00007431745d9334  vmovaps [rsp+0xC0], xmm13
00007431745d933d  vmovaps [rsp+0xD0], xmm14
00007431745d9346  vmovaps [rsp+0xE0], xmm15
00007431745d934f  sub rsp, 0x30
00007431745d9353  movaps [rsp], xmm6
00007431745d9357  movaps [rsp+0x10], xmm10
00007431745d935d  movaps [rsp+0x20], xmm8
00007431745d9363  lea rdi, [rsp]
00007431745d9367  mov esi, 0x00
00007431745d936c  mov rax, 0x56C40959E530
00007431745d9376  call rax
00007431745d9378  movaps xmm6, [rsp]
00007431745d937c  add rsp, 0x30
00007431745d9380  vmovaps xmm0, [rsp]
00007431745d9385  vmovaps xmm1, [rsp+0x10]
00007431745d938b  vmovaps xmm2, [rsp+0x20]
00007431745d9391  vmovaps xmm3, [rsp+0x30]
00007431745d9397  vmovaps xmm4, [rsp+0x40]
00007431745d939d  vmovaps xmm5, [rsp+0x50]
00007431745d93a3  vmovaps xmm7, [rsp+0x60]
00007431745d93a9  vmovaps xmm8, [rsp+0x70]
00007431745d93af  vmovaps xmm9, [rsp+0x80]
00007431745d93b8  vmovaps xmm10, [rsp+0x90]
00007431745d93c1  vmovaps xmm11, [rsp+0xA0]
00007431745d93ca  vmovaps xmm12, [rsp+0xB0]
00007431745d93d3  vmovaps xmm13, [rsp+0xC0]
00007431745d93dc  vmovaps xmm14, [rsp+0xD0]
00007431745d93e5  vmovaps xmm15, [rsp+0xE0]
00007431745d93ee  add rsp, 0xF0
00007431745d93f5  pop r11
00007431745d93f7  pop r10
00007431745d93f9  pop r9
00007431745d93fb  pop r8
00007431745d93fd  pop rsi
00007431745d93fe  pop rdi
00007431745d93ff  pop rdx
00007431745d9400  pop rcx
00007431745d9401  pop rax
00007431745d9402  add rsp, 0x08
00007431745d9406  jmp 0x00007431745D6225
00007431745d940b  sub rsp, 0x08
00007431745d940f  push rax
00007431745d9410  push rcx
00007431745d9411  push rdx
00007431745d9412  push rdi
00007431745d9413  push rsi
00007431745d9414  push r8
00007431745d9416  push r9
00007431745d9418  push r10
00007431745d941a  push r11
00007431745d941c  sub rsp, 0xF0
00007431745d9423  vmovaps [rsp], xmm0
00007431745d9428  vmovaps [rsp+0x10], xmm1
00007431745d942e  vmovaps [rsp+0x20], xmm2
00007431745d9434  vmovaps [rsp+0x30], xmm3
00007431745d943a  vmovaps [rsp+0x40], xmm4
00007431745d9440  vmovaps [rsp+0x50], xmm5
00007431745d9446  vmovaps [rsp+0x60], xmm6
00007431745d944c  vmovaps [rsp+0x70], xmm7
00007431745d9452  vmovaps [rsp+0x80], xmm8
00007431745d945b  vmovaps [rsp+0x90], xmm9
00007431745d9464  vmovaps [rsp+0xA0], xmm11
00007431745d946d  vmovaps [rsp+0xB0], xmm12
00007431745d9476  vmovaps [rsp+0xC0], xmm13
00007431745d947f  vmovaps [rsp+0xD0], xmm14
00007431745d9488  vmovaps [rsp+0xE0], xmm15
00007431745d9491  sub rsp, 0x30
00007431745d9495  movaps [rsp], xmm10
00007431745d949a  movaps [rsp+0x10], xmm8
00007431745d94a0  movaps [rsp+0x20], xmm14
00007431745d94a6  lea rdi, [rsp]
00007431745d94aa  mov esi, 0x00
00007431745d94af  mov rax, 0x56C40959E530
00007431745d94b9  call rax
00007431745d94bb  movaps xmm10, [rsp]
00007431745d94c0  add rsp, 0x30
00007431745d94c4  vmovaps xmm0, [rsp]
00007431745d94c9  vmovaps xmm1, [rsp+0x10]
00007431745d94cf  vmovaps xmm2, [rsp+0x20]
00007431745d94d5  vmovaps xmm3, [rsp+0x30]
00007431745d94db  vmovaps xmm4, [rsp+0x40]
00007431745d94e1  vmovaps xmm5, [rsp+0x50]
00007431745d94e7  vmovaps xmm6, [rsp+0x60]
00007431745d94ed  vmovaps xmm7, [rsp+0x70]
00007431745d94f3  vmovaps xmm8, [rsp+0x80]
00007431745d94fc  vmovaps xmm9, [rsp+0x90]
00007431745d9505  vmovaps xmm11, [rsp+0xA0]
00007431745d950e  vmovaps xmm12, [rsp+0xB0]
00007431745d9517  vmovaps xmm13, [rsp+0xC0]
00007431745d9520  vmovaps xmm14, [rsp+0xD0]
00007431745d9529  vmovaps xmm15, [rsp+0xE0]
00007431745d9532  add rsp, 0xF0
00007431745d9539  pop r11
00007431745d953b  pop r10
00007431745d953d  pop r9
00007431745d953f  pop r8
00007431745d9541  pop rsi
00007431745d9542  pop rdi
00007431745d9543  pop rdx
00007431745d9544  pop rcx
00007431745d9545  pop rax
00007431745d9546  add rsp, 0x08
00007431745d954a  jmp 0x00007431745D6245
00007431745d954f  sub rsp, 0x08
00007431745d9553  push rax
00007431745d9554  push rcx
00007431745d9555  push rdx
00007431745d9556  push rdi
00007431745d9557  push rsi
00007431745d9558  push r8
00007431745d955a  push r9
00007431745d955c  push r10
00007431745d955e  push r11
00007431745d9560  sub rsp, 0xF0
00007431745d9567  vmovaps [rsp], xmm0
00007431745d956c  vmovaps [rsp+0x10], xmm1
00007431745d9572  vmovaps [rsp+0x20], xmm2
00007431745d9578  vmovaps [rsp+0x30], xmm3
00007431745d957e  vmovaps [rsp+0x40], xmm4
00007431745d9584  vmovaps [rsp+0x50], xmm5
00007431745d958a  vmovaps [rsp+0x60], xmm6
00007431745d9590  vmovaps [rsp+0x70], xmm7
00007431745d9596  vmovaps [rsp+0x80], xmm8
00007431745d959f  vmovaps [rsp+0x90], xmm9
00007431745d95a8  vmovaps [rsp+0xA0], xmm10
00007431745d95b1  vmovaps [rsp+0xB0], xmm11
00007431745d95ba  vmovaps [rsp+0xC0], xmm12
00007431745d95c3  vmovaps [rsp+0xD0], xmm13
00007431745d95cc  vmovaps [rsp+0xE0], xmm15
00007431745d95d5  sub rsp, 0x30
00007431745d95d9  movaps [rsp], xmm14
00007431745d95de  movaps [rsp+0x10], xmm8
00007431745d95e4  movaps [rsp+0x20], xmm4
00007431745d95e9  lea rdi, [rsp]
00007431745d95ed  mov esi, 0x00
00007431745d95f2  mov rax, 0x56C40959E530
00007431745d95fc  call rax
00007431745d95fe  movaps xmm14, [rsp]
00007431745d9603  add rsp, 0x30
00007431745d9607  vmovaps xmm0, [rsp]
00007431745d960c  vmovaps xmm1, [rsp+0x10]
00007431745d9612  vmovaps xmm2, [rsp+0x20]
00007431745d9618  vmovaps xmm3, [rsp+0x30]
00007431745d961e  vmovaps xmm4, [rsp+0x40]
00007431745d9624  vmovaps xmm5, [rsp+0x50]
00007431745d962a  vmovaps xmm6, [rsp+0x60]
00007431745d9630  vmovaps xmm7, [rsp+0x70]
00007431745d9636  vmovaps xmm8, [rsp+0x80]
00007431745d963f  vmovaps xmm9, [rsp+0x90]
00007431745d9648  vmovaps xmm10, [rsp+0xA0]
00007431745d9651  vmovaps xmm11, [rsp+0xB0]
00007431745d965a  vmovaps xmm12, [rsp+0xC0]
00007431745d9663  vmovaps xmm13, [rsp+0xD0]
00007431745d966c  vmovaps xmm15, [rsp+0xE0]
00007431745d9675  add rsp, 0xF0
00007431745d967c  pop r11
00007431745d967e  pop r10
00007431745d9680  pop r9
00007431745d9682  pop r8
00007431745d9684  pop rsi
00007431745d9685  pop rdi
00007431745d9686  pop rdx
00007431745d9687  pop rcx
00007431745d9688  pop rax
00007431745d9689  add rsp, 0x08
00007431745d968d  jmp 0x00007431745D6265
00007431745d9692  sub rsp, 0x08
00007431745d9696  push rax
00007431745d9697  push rcx
00007431745d9698  push rdx
00007431745d9699  push rdi
00007431745d969a  push rsi
00007431745d969b  push r8
00007431745d969d  push r9
00007431745d969f  push r10
00007431745d96a1  push r11
00007431745d96a3  sub rsp, 0xF0
00007431745d96aa  vmovaps [rsp], xmm0
00007431745d96af  vmovaps [rsp+0x10], xmm1
00007431745d96b5  vmovaps [rsp+0x20], xmm2
00007431745d96bb  vmovaps [rsp+0x30], xmm3
00007431745d96c1  vmovaps [rsp+0x40], xmm5
00007431745d96c7  vmovaps [rsp+0x50], xmm6
00007431745d96cd  vmovaps [rsp+0x60], xmm7
00007431745d96d3  vmovaps [rsp+0x70], xmm8
00007431745d96d9  vmovaps [rsp+0x80], xmm9
00007431745d96e2  vmovaps [rsp+0x90], xmm10
00007431745d96eb  vmovaps [rsp+0xA0], xmm11
00007431745d96f4  vmovaps [rsp+0xB0], xmm12
00007431745d96fd  vmovaps [rsp+0xC0], xmm13
00007431745d9706  vmovaps [rsp+0xD0], xmm14
00007431745d970f  vmovaps [rsp+0xE0], xmm15
00007431745d9718  sub rsp, 0x30
00007431745d971c  movaps [rsp], xmm4
00007431745d9720  movaps [rsp+0x10], xmm13
00007431745d9726  movaps [rsp+0x20], xmm8
00007431745d972c  lea rdi, [rsp]
00007431745d9730  mov esi, 0x00
00007431745d9735  mov rax, 0x56C40959E530
00007431745d973f  call rax
00007431745d9741  movaps xmm4, [rsp]
00007431745d9745  add rsp, 0x30
00007431745d9749  vmovaps xmm0, [rsp]
00007431745d974e  vmovaps xmm1, [rsp+0x10]
00007431745d9754  vmovaps xmm2, [rsp+0x20]
00007431745d975a  vmovaps xmm3, [rsp+0x30]
00007431745d9760  vmovaps xmm5, [rsp+0x40]
00007431745d9766  vmovaps xmm6, [rsp+0x50]
00007431745d976c  vmovaps xmm7, [rsp+0x60]
00007431745d9772  vmovaps xmm8, [rsp+0x70]
00007431745d9778  vmovaps xmm9, [rsp+0x80]
00007431745d9781  vmovaps xmm10, [rsp+0x90]
00007431745d978a  vmovaps xmm11, [rsp+0xA0]
00007431745d9793  vmovaps xmm12, [rsp+0xB0]
00007431745d979c  vmovaps xmm13, [rsp+0xC0]
00007431745d97a5  vmovaps xmm14, [rsp+0xD0]
00007431745d97ae  vmovaps xmm15, [rsp+0xE0]
00007431745d97b7  add rsp, 0xF0
00007431745d97be  pop r11
00007431745d97c0  pop r10
00007431745d97c2  pop r9
00007431745d97c4  pop r8
00007431745d97c6  pop rsi
00007431745d97c7  pop rdi
00007431745d97c8  pop rdx
00007431745d97c9  pop rcx
00007431745d97ca  pop rax
00007431745d97cb  add rsp, 0x08
00007431745d97cf  jmp 0x00007431745D628A
00007431745d97d4  sub rsp, 0x08
00007431745d97d8  push rax
00007431745d97d9  push rcx
00007431745d97da  push rdx
00007431745d97db  push rdi
00007431745d97dc  push rsi
00007431745d97dd  push r8
00007431745d97df  push r9
00007431745d97e1  push r10
00007431745d97e3  push r11
00007431745d97e5  sub rsp, 0xF0
00007431745d97ec  vmovaps [rsp], xmm0
00007431745d97f1  vmovaps [rsp+0x10], xmm1
00007431745d97f7  vmovaps [rsp+0x20], xmm2
00007431745d97fd  vmovaps [rsp+0x30], xmm3
00007431745d9803  vmovaps [rsp+0x40], xmm4
00007431745d9809  vmovaps [rsp+0x50], xmm5
00007431745d980f  vmovaps [rsp+0x60], xmm6
00007431745d9815  vmovaps [rsp+0x70], xmm7
00007431745d981b  vmovaps [rsp+0x80], xmm8
00007431745d9824  vmovaps [rsp+0x90], xmm9
00007431745d982d  vmovaps [rsp+0xA0], xmm10
00007431745d9836  vmovaps [rsp+0xB0], xmm11
00007431745d983f  vmovaps [rsp+0xC0], xmm12
00007431745d9848  vmovaps [rsp+0xD0], xmm14
00007431745d9851  vmovaps [rsp+0xE0], xmm15
00007431745d985a  sub rsp, 0x30
00007431745d985e  movaps [rsp], xmm13
00007431745d9863  movaps [rsp+0x10], xmm15
00007431745d9869  movaps [rsp+0x20], xmm9
00007431745d986f  lea rdi, [rsp]
00007431745d9873  mov esi, 0x00
00007431745d9878  mov rax, 0x56C40959E530
00007431745d9882  call rax
00007431745d9884  movaps xmm13, [rsp]
00007431745d9889  add rsp, 0x30
00007431745d988d  vmovaps xmm0, [rsp]
00007431745d9892  vmovaps xmm1, [rsp+0x10]
00007431745d9898  vmovaps xmm2, [rsp+0x20]
00007431745d989e  vmovaps xmm3, [rsp+0x30]
00007431745d98a4  vmovaps xmm4, [rsp+0x40]
00007431745d98aa  vmovaps xmm5, [rsp+0x50]
00007431745d98b0  vmovaps xmm6, [rsp+0x60]
00007431745d98b6  vmovaps xmm7, [rsp+0x70]
00007431745d98bc  vmovaps xmm8, [rsp+0x80]
00007431745d98c5  vmovaps xmm9, [rsp+0x90]
00007431745d98ce  vmovaps xmm10, [rsp+0xA0]
00007431745d98d7  vmovaps xmm11, [rsp+0xB0]
00007431745d98e0  vmovaps xmm12, [rsp+0xC0]
00007431745d98e9  vmovaps xmm14, [rsp+0xD0]
00007431745d98f2  vmovaps xmm15, [rsp+0xE0]
00007431745d98fb  add rsp, 0xF0
00007431745d9902  pop r11
00007431745d9904  pop r10
00007431745d9906  pop r9
00007431745d9908  pop r8
00007431745d990a  pop rsi
00007431745d990b  pop rdi
00007431745d990c  pop rdx
00007431745d990d  pop rcx
00007431745d990e  pop rax
00007431745d990f  add rsp, 0x08
00007431745d9913  jmp 0x00007431745D62A5
00007431745d9918  sub rsp, 0x08
00007431745d991c  push rax
00007431745d991d  push rcx
00007431745d991e  push rdx
00007431745d991f  push rdi
00007431745d9920  push rsi
00007431745d9921  push r8
00007431745d9923  push r9
00007431745d9925  push r10
00007431745d9927  push r11
00007431745d9929  sub rsp, 0xF0
00007431745d9930  vmovaps [rsp], xmm0
00007431745d9935  vmovaps [rsp+0x10], xmm1
00007431745d993b  vmovaps [rsp+0x20], xmm2
00007431745d9941  vmovaps [rsp+0x30], xmm3
00007431745d9947  vmovaps [rsp+0x40], xmm4
00007431745d994d  vmovaps [rsp+0x50], xmm5
00007431745d9953  vmovaps [rsp+0x60], xmm6
00007431745d9959  vmovaps [rsp+0x70], xmm7
00007431745d995f  vmovaps [rsp+0x80], xmm8
00007431745d9968  vmovaps [rsp+0x90], xmm9
00007431745d9971  vmovaps [rsp+0xA0], xmm10
00007431745d997a  vmovaps [rsp+0xB0], xmm11
00007431745d9983  vmovaps [rsp+0xC0], xmm12
00007431745d998c  vmovaps [rsp+0xD0], xmm13
00007431745d9995  vmovaps [rsp+0xE0], xmm14
00007431745d999e  sub rsp, 0x30
00007431745d99a2  movaps [rsp], xmm15
00007431745d99a7  movaps [rsp+0x10], xmm1
00007431745d99ac  movaps [rsp+0x20], xmm5
00007431745d99b1  lea rdi, [rsp]
00007431745d99b5  mov esi, 0x00
00007431745d99ba  mov rax, 0x56C40959E530
00007431745d99c4  call rax
00007431745d99c6  movaps xmm15, [rsp]
00007431745d99cb  add rsp, 0x30
00007431745d99cf  vmovaps xmm0, [rsp]
00007431745d99d4  vmovaps xmm1, [rsp+0x10]
00007431745d99da  vmovaps xmm2, [rsp+0x20]
00007431745d99e0  vmovaps xmm3, [rsp+0x30]
00007431745d99e6  vmovaps xmm4, [rsp+0x40]
00007431745d99ec  vmovaps xmm5, [rsp+0x50]
00007431745d99f2  vmovaps xmm6, [rsp+0x60]
00007431745d99f8  vmovaps xmm7, [rsp+0x70]
00007431745d99fe  vmovaps xmm8, [rsp+0x80]
00007431745d9a07  vmovaps xmm9, [rsp+0x90]
00007431745d9a10  vmovaps xmm10, [rsp+0xA0]
00007431745d9a19  vmovaps xmm11, [rsp+0xB0]
00007431745d9a22  vmovaps xmm12, [rsp+0xC0]
00007431745d9a2b  vmovaps xmm13, [rsp+0xD0]
00007431745d9a34  vmovaps xmm14, [rsp+0xE0]
00007431745d9a3d  add rsp, 0xF0
00007431745d9a44  pop r11
00007431745d9a46  pop r10
00007431745d9a48  pop r9
00007431745d9a4a  pop r8
00007431745d9a4c  pop rsi
00007431745d9a4d  pop rdi
00007431745d9a4e  pop rdx
00007431745d9a4f  pop rcx
00007431745d9a50  pop rax
00007431745d9a51  add rsp, 0x08
00007431745d9a55  jmp 0x00007431745D62C0
00007431745d9a5a  call 0x00007431744D64F0
00007431745d9a5f  jmp 0x00007431745D631B
00007431745d9a64  sub rsp, 0x08
00007431745d9a68  push rax
00007431745d9a69  push rcx
00007431745d9a6a  push rdx
00007431745d9a6b  push rdi
00007431745d9a6c  push rsi
00007431745d9a6d  push r8
00007431745d9a6f  push r9
00007431745d9a71  push r10
00007431745d9a73  push r11
00007431745d9a75  sub rsp, 0xF0
00007431745d9a7c  vmovaps [rsp], xmm0
00007431745d9a81  vmovaps [rsp+0x10], xmm1
00007431745d9a87  vmovaps [rsp+0x20], xmm2
00007431745d9a8d  vmovaps [rsp+0x30], xmm3
00007431745d9a93  vmovaps [rsp+0x40], xmm4
00007431745d9a99  vmovaps [rsp+0x50], xmm5
00007431745d9a9f  vmovaps [rsp+0x60], xmm6
00007431745d9aa5  vmovaps [rsp+0x70], xmm7
00007431745d9aab  vmovaps [rsp+0x80], xmm8
00007431745d9ab4  vmovaps [rsp+0x90], xmm10
00007431745d9abd  vmovaps [rsp+0xA0], xmm11
00007431745d9ac6  vmovaps [rsp+0xB0], xmm12
00007431745d9acf  vmovaps [rsp+0xC0], xmm13
00007431745d9ad8  vmovaps [rsp+0xD0], xmm14
00007431745d9ae1  vmovaps [rsp+0xE0], xmm15
00007431745d9aea  sub rsp, 0x30
00007431745d9aee  movaps [rsp], xmm9
00007431745d9af3  movaps [rsp+0x10], xmm8
00007431745d9af9  movaps [rsp+0x20], xmm11
00007431745d9aff  lea rdi, [rsp]
00007431745d9b03  mov esi, 0x00
00007431745d9b08  mov rax, 0x56C40959E530
00007431745d9b12  call rax
00007431745d9b14  movaps xmm9, [rsp]
00007431745d9b19  add rsp, 0x30
00007431745d9b1d  vmovaps xmm0, [rsp]
00007431745d9b22  vmovaps xmm1, [rsp+0x10]
00007431745d9b28  vmovaps xmm2, [rsp+0x20]
00007431745d9b2e  vmovaps xmm3, [rsp+0x30]
00007431745d9b34  vmovaps xmm4, [rsp+0x40]
00007431745d9b3a  vmovaps xmm5, [rsp+0x50]
00007431745d9b40  vmovaps xmm6, [rsp+0x60]
00007431745d9b46  vmovaps xmm7, [rsp+0x70]
00007431745d9b4c  vmovaps xmm8, [rsp+0x80]
00007431745d9b55  vmovaps xmm10, [rsp+0x90]
00007431745d9b5e  vmovaps xmm11, [rsp+0xA0]
00007431745d9b67  vmovaps xmm12, [rsp+0xB0]
00007431745d9b70  vmovaps xmm13, [rsp+0xC0]
00007431745d9b79  vmovaps xmm14, [rsp+0xD0]
00007431745d9b82  vmovaps xmm15, [rsp+0xE0]
00007431745d9b8b  add rsp, 0xF0
00007431745d9b92  pop r11
00007431745d9b94  pop r10
00007431745d9b96  pop r9
00007431745d9b98  pop r8
00007431745d9b9a  pop rsi
00007431745d9b9b  pop rdi
00007431745d9b9c  pop rdx
00007431745d9b9d  pop rcx
00007431745d9b9e  pop rax
00007431745d9b9f  add rsp, 0x08
00007431745d9ba3  jmp 0x00007431745D6352
00007431745d9ba8  sub rsp, 0x08
00007431745d9bac  push rax
00007431745d9bad  push rcx
00007431745d9bae  push rdx
00007431745d9baf  push rdi
00007431745d9bb0  push rsi
00007431745d9bb1  push r8
00007431745d9bb3  push r9
00007431745d9bb5  push r10
00007431745d9bb7  push r11
00007431745d9bb9  sub rsp, 0xF0
00007431745d9bc0  vmovaps [rsp], xmm0
00007431745d9bc5  vmovaps [rsp+0x10], xmm1
00007431745d9bcb  vmovaps [rsp+0x20], xmm2
00007431745d9bd1  vmovaps [rsp+0x30], xmm3
00007431745d9bd7  vmovaps [rsp+0x40], xmm4
00007431745d9bdd  vmovaps [rsp+0x50], xmm5
00007431745d9be3  vmovaps [rsp+0x60], xmm6
00007431745d9be9  vmovaps [rsp+0x70], xmm7
00007431745d9bef  vmovaps [rsp+0x80], xmm8
00007431745d9bf8  vmovaps [rsp+0x90], xmm9
00007431745d9c01  vmovaps [rsp+0xA0], xmm10
00007431745d9c0a  vmovaps [rsp+0xB0], xmm12
00007431745d9c13  vmovaps [rsp+0xC0], xmm13
00007431745d9c1c  vmovaps [rsp+0xD0], xmm14
00007431745d9c25  vmovaps [rsp+0xE0], xmm15
00007431745d9c2e  sub rsp, 0x30
00007431745d9c32  movaps [rsp], xmm11
00007431745d9c37  movaps [rsp+0x10], xmm10
00007431745d9c3d  movaps [rsp+0x20], xmm6
00007431745d9c42  lea rdi, [rsp]
00007431745d9c46  mov esi, 0x00
00007431745d9c4b  mov rax, 0x56C40959E530
00007431745d9c55  call rax
00007431745d9c57  movaps xmm11, [rsp]
00007431745d9c5c  add rsp, 0x30
00007431745d9c60  vmovaps xmm0, [rsp]
00007431745d9c65  vmovaps xmm1, [rsp+0x10]
00007431745d9c6b  vmovaps xmm2, [rsp+0x20]
00007431745d9c71  vmovaps xmm3, [rsp+0x30]
00007431745d9c77  vmovaps xmm4, [rsp+0x40]
00007431745d9c7d  vmovaps xmm5, [rsp+0x50]
00007431745d9c83  vmovaps xmm6, [rsp+0x60]
00007431745d9c89  vmovaps xmm7, [rsp+0x70]
00007431745d9c8f  vmovaps xmm8, [rsp+0x80]
00007431745d9c98  vmovaps xmm9, [rsp+0x90]
00007431745d9ca1  vmovaps xmm10, [rsp+0xA0]
00007431745d9caa  vmovaps xmm12, [rsp+0xB0]
00007431745d9cb3  vmovaps xmm13, [rsp+0xC0]
00007431745d9cbc  vmovaps xmm14, [rsp+0xD0]
00007431745d9cc5  vmovaps xmm15, [rsp+0xE0]
00007431745d9cce  add rsp, 0xF0
00007431745d9cd5  pop r11
00007431745d9cd7  pop r10
00007431745d9cd9  pop r9
00007431745d9cdb  pop r8
00007431745d9cdd  pop rsi
00007431745d9cde  pop rdi
00007431745d9cdf  pop rdx
00007431745d9ce0  pop rcx
00007431745d9ce1  pop rax
00007431745d9ce2  add rsp, 0x08
00007431745d9ce6  jmp 0x00007431745D636D
00007431745d9ceb  sub rsp, 0x08
00007431745d9cef  push rax
00007431745d9cf0  push rcx
00007431745d9cf1  push rdx
00007431745d9cf2  push rdi
00007431745d9cf3  push rsi
00007431745d9cf4  push r8
00007431745d9cf6  push r9
00007431745d9cf8  push r10
00007431745d9cfa  push r11
00007431745d9cfc  sub rsp, 0xF0
00007431745d9d03  vmovaps [rsp], xmm0
00007431745d9d08  vmovaps [rsp+0x10], xmm1
00007431745d9d0e  vmovaps [rsp+0x20], xmm2
00007431745d9d14  vmovaps [rsp+0x30], xmm3
00007431745d9d1a  vmovaps [rsp+0x40], xmm4
00007431745d9d20  vmovaps [rsp+0x50], xmm5
00007431745d9d26  vmovaps [rsp+0x60], xmm6
00007431745d9d2c  vmovaps [rsp+0x70], xmm7
00007431745d9d32  vmovaps [rsp+0x80], xmm8
00007431745d9d3b  vmovaps [rsp+0x90], xmm9
00007431745d9d44  vmovaps [rsp+0xA0], xmm11
00007431745d9d4d  vmovaps [rsp+0xB0], xmm12
00007431745d9d56  vmovaps [rsp+0xC0], xmm13
00007431745d9d5f  vmovaps [rsp+0xD0], xmm14
00007431745d9d68  vmovaps [rsp+0xE0], xmm15
00007431745d9d71  sub rsp, 0x30
00007431745d9d75  movaps [rsp], xmm10
00007431745d9d7a  movaps [rsp+0x10], xmm14
00007431745d9d80  movaps [rsp+0x20], xmm4
00007431745d9d85  lea rdi, [rsp]
00007431745d9d89  mov esi, 0x00
00007431745d9d8e  mov rax, 0x56C40959E530
00007431745d9d98  call rax
00007431745d9d9a  movaps xmm10, [rsp]
00007431745d9d9f  add rsp, 0x30
00007431745d9da3  vmovaps xmm0, [rsp]
00007431745d9da8  vmovaps xmm1, [rsp+0x10]
00007431745d9dae  vmovaps xmm2, [rsp+0x20]
00007431745d9db4  vmovaps xmm3, [rsp+0x30]
00007431745d9dba  vmovaps xmm4, [rsp+0x40]
00007431745d9dc0  vmovaps xmm5, [rsp+0x50]
00007431745d9dc6  vmovaps xmm6, [rsp+0x60]
00007431745d9dcc  vmovaps xmm7, [rsp+0x70]
00007431745d9dd2  vmovaps xmm8, [rsp+0x80]
00007431745d9ddb  vmovaps xmm9, [rsp+0x90]
00007431745d9de4  vmovaps xmm11, [rsp+0xA0]
00007431745d9ded  vmovaps xmm12, [rsp+0xB0]
00007431745d9df6  vmovaps xmm13, [rsp+0xC0]
00007431745d9dff  vmovaps xmm14, [rsp+0xD0]
00007431745d9e08  vmovaps xmm15, [rsp+0xE0]
00007431745d9e11  add rsp, 0xF0
00007431745d9e18  pop r11
00007431745d9e1a  pop r10
00007431745d9e1c  pop r9
00007431745d9e1e  pop r8
00007431745d9e20  pop rsi
00007431745d9e21  pop rdi
00007431745d9e22  pop rdx
00007431745d9e23  pop rcx
00007431745d9e24  pop rax
00007431745d9e25  add rsp, 0x08
00007431745d9e29  jmp 0x00007431745D6388
00007431745d9e2e  sub rsp, 0x08
00007431745d9e32  push rax
00007431745d9e33  push rcx
00007431745d9e34  push rdx
00007431745d9e35  push rdi
00007431745d9e36  push rsi
00007431745d9e37  push r8
00007431745d9e39  push r9
00007431745d9e3b  push r10
00007431745d9e3d  push r11
00007431745d9e3f  sub rsp, 0xF0
00007431745d9e46  vmovaps [rsp], xmm0
00007431745d9e4b  vmovaps [rsp+0x10], xmm1
00007431745d9e51  vmovaps [rsp+0x20], xmm2
00007431745d9e57  vmovaps [rsp+0x30], xmm3
00007431745d9e5d  vmovaps [rsp+0x40], xmm4
00007431745d9e63  vmovaps [rsp+0x50], xmm5
00007431745d9e69  vmovaps [rsp+0x60], xmm6
00007431745d9e6f  vmovaps [rsp+0x70], xmm7
00007431745d9e75  vmovaps [rsp+0x80], xmm9
00007431745d9e7e  vmovaps [rsp+0x90], xmm10
00007431745d9e87  vmovaps [rsp+0xA0], xmm11
00007431745d9e90  vmovaps [rsp+0xB0], xmm12
00007431745d9e99  vmovaps [rsp+0xC0], xmm13
00007431745d9ea2  vmovaps [rsp+0xD0], xmm14
00007431745d9eab  vmovaps [rsp+0xE0], xmm15
00007431745d9eb4  sub rsp, 0x30
00007431745d9eb8  movaps [rsp], xmm8
00007431745d9ebd  movaps [rsp+0x10], xmm1
00007431745d9ec2  movaps [rsp+0x20], xmm14
00007431745d9ec8  lea rdi, [rsp]
00007431745d9ecc  mov esi, 0x00
00007431745d9ed1  mov rax, 0x56C40959E530
00007431745d9edb  call rax
00007431745d9edd  movaps xmm8, [rsp]
00007431745d9ee2  add rsp, 0x30
00007431745d9ee6  vmovaps xmm0, [rsp]
00007431745d9eeb  vmovaps xmm1, [rsp+0x10]
00007431745d9ef1  vmovaps xmm2, [rsp+0x20]
00007431745d9ef7  vmovaps xmm3, [rsp+0x30]
00007431745d9efd  vmovaps xmm4, [rsp+0x40]
00007431745d9f03  vmovaps xmm5, [rsp+0x50]
00007431745d9f09  vmovaps xmm6, [rsp+0x60]
00007431745d9f0f  vmovaps xmm7, [rsp+0x70]
00007431745d9f15  vmovaps xmm9, [rsp+0x80]
00007431745d9f1e  vmovaps xmm10, [rsp+0x90]
00007431745d9f27  vmovaps xmm11, [rsp+0xA0]
00007431745d9f30  vmovaps xmm12, [rsp+0xB0]
00007431745d9f39  vmovaps xmm13, [rsp+0xC0]
00007431745d9f42  vmovaps xmm14, [rsp+0xD0]
00007431745d9f4b  vmovaps xmm15, [rsp+0xE0]
00007431745d9f54  add rsp, 0xF0
00007431745d9f5b  pop r11
00007431745d9f5d  pop r10
00007431745d9f5f  pop r9
00007431745d9f61  pop r8
00007431745d9f63  pop rsi
00007431745d9f64  pop rdi
00007431745d9f65  pop rdx
00007431745d9f66  pop rcx
00007431745d9f67  pop rax
00007431745d9f68  add rsp, 0x08
00007431745d9f6c  jmp 0x00007431745D63AE
00007431745d9f71  sub rsp, 0x08
00007431745d9f75  push rax
00007431745d9f76  push rcx
00007431745d9f77  push rdx
00007431745d9f78  push rdi
00007431745d9f79  push rsi
00007431745d9f7a  push r8
00007431745d9f7c  push r9
00007431745d9f7e  push r10
00007431745d9f80  push r11
00007431745d9f82  sub rsp, 0xF0
00007431745d9f89  vmovaps [rsp], xmm0
00007431745d9f8e  vmovaps [rsp+0x10], xmm1
00007431745d9f94  vmovaps [rsp+0x20], xmm2
00007431745d9f9a  vmovaps [rsp+0x30], xmm3
00007431745d9fa0  vmovaps [rsp+0x40], xmm4
00007431745d9fa6  vmovaps [rsp+0x50], xmm5
00007431745d9fac  vmovaps [rsp+0x60], xmm7
00007431745d9fb2  vmovaps [rsp+0x70], xmm8
00007431745d9fb8  vmovaps [rsp+0x80], xmm9
00007431745d9fc1  vmovaps [rsp+0x90], xmm10
00007431745d9fca  vmovaps [rsp+0xA0], xmm11
00007431745d9fd3  vmovaps [rsp+0xB0], xmm12
00007431745d9fdc  vmovaps [rsp+0xC0], xmm13
00007431745d9fe5  vmovaps [rsp+0xD0], xmm14
00007431745d9fee  vmovaps [rsp+0xE0], xmm15
00007431745d9ff7  sub rsp, 0x30
00007431745d9ffb  movaps [rsp], xmm6
00007431745d9fff  movaps [rsp+0x10], xmm1
00007431745da004  movaps [rsp+0x20], xmm14
00007431745da00a  lea rdi, [rsp]
00007431745da00e  mov esi, 0x00
00007431745da013  mov rax, 0x56C40959E530
00007431745da01d  call rax
00007431745da01f  movaps xmm6, [rsp]
00007431745da023  add rsp, 0x30
00007431745da027  vmovaps xmm0, [rsp]
00007431745da02c  vmovaps xmm1, [rsp+0x10]
00007431745da032  vmovaps xmm2, [rsp+0x20]
00007431745da038  vmovaps xmm3, [rsp+0x30]
00007431745da03e  vmovaps xmm4, [rsp+0x40]
00007431745da044  vmovaps xmm5, [rsp+0x50]
00007431745da04a  vmovaps xmm7, [rsp+0x60]
00007431745da050  vmovaps xmm8, [rsp+0x70]
00007431745da056  vmovaps xmm9, [rsp+0x80]
00007431745da05f  vmovaps xmm10, [rsp+0x90]
00007431745da068  vmovaps xmm11, [rsp+0xA0]
00007431745da071  vmovaps xmm12, [rsp+0xB0]
00007431745da07a  vmovaps xmm13, [rsp+0xC0]
00007431745da083  vmovaps xmm14, [rsp+0xD0]
00007431745da08c  vmovaps xmm15, [rsp+0xE0]
00007431745da095  add rsp, 0xF0
00007431745da09c  pop r11
00007431745da09e  pop r10
00007431745da0a0  pop r9
00007431745da0a2  pop r8
00007431745da0a4  pop rsi
00007431745da0a5  pop rdi
00007431745da0a6  pop rdx
00007431745da0a7  pop rcx
00007431745da0a8  pop rax
00007431745da0a9  add rsp, 0x08
00007431745da0ad  jmp 0x00007431745D63DA
00007431745da0b2  sub rsp, 0x08
00007431745da0b6  push rax
00007431745da0b7  push rcx
00007431745da0b8  push rdx
00007431745da0b9  push rdi
00007431745da0ba  push rsi
00007431745da0bb  push r8
00007431745da0bd  push r9
00007431745da0bf  push r10
00007431745da0c1  push r11
00007431745da0c3  sub rsp, 0xF0
00007431745da0ca  vmovaps [rsp], xmm0
00007431745da0cf  vmovaps [rsp+0x10], xmm1
00007431745da0d5  vmovaps [rsp+0x20], xmm2
00007431745da0db  vmovaps [rsp+0x30], xmm3
00007431745da0e1  vmovaps [rsp+0x40], xmm4
00007431745da0e7  vmovaps [rsp+0x50], xmm5
00007431745da0ed  vmovaps [rsp+0x60], xmm6
00007431745da0f3  vmovaps [rsp+0x70], xmm7
00007431745da0f9  vmovaps [rsp+0x80], xmm8
00007431745da102  vmovaps [rsp+0x90], xmm9
00007431745da10b  vmovaps [rsp+0xA0], xmm10
00007431745da114  vmovaps [rsp+0xB0], xmm11
00007431745da11d  vmovaps [rsp+0xC0], xmm12
00007431745da126  vmovaps [rsp+0xD0], xmm13
00007431745da12f  vmovaps [rsp+0xE0], xmm15
00007431745da138  sub rsp, 0x30
00007431745da13c  movaps [rsp], xmm14
00007431745da141  movaps [rsp+0x10], xmm12
00007431745da147  movaps [rsp+0x20], xmm1
00007431745da14c  lea rdi, [rsp]
00007431745da150  mov esi, 0x00
00007431745da155  mov rax, 0x56C40959E530
00007431745da15f  call rax
00007431745da161  movaps xmm14, [rsp]
00007431745da166  add rsp, 0x30
00007431745da16a  vmovaps xmm0, [rsp]
00007431745da16f  vmovaps xmm1, [rsp+0x10]
00007431745da175  vmovaps xmm2, [rsp+0x20]
00007431745da17b  vmovaps xmm3, [rsp+0x30]
00007431745da181  vmovaps xmm4, [rsp+0x40]
00007431745da187  vmovaps xmm5, [rsp+0x50]
00007431745da18d  vmovaps xmm6, [rsp+0x60]
00007431745da193  vmovaps xmm7, [rsp+0x70]
00007431745da199  vmovaps xmm8, [rsp+0x80]
00007431745da1a2  vmovaps xmm9, [rsp+0x90]
00007431745da1ab  vmovaps xmm10, [rsp+0xA0]
00007431745da1b4  vmovaps xmm11, [rsp+0xB0]
00007431745da1bd  vmovaps xmm12, [rsp+0xC0]
00007431745da1c6  vmovaps xmm13, [rsp+0xD0]
00007431745da1cf  vmovaps xmm15, [rsp+0xE0]
00007431745da1d8  add rsp, 0xF0
00007431745da1df  pop r11
00007431745da1e1  pop r10
00007431745da1e3  pop r9
00007431745da1e5  pop r8
00007431745da1e7  pop rsi
00007431745da1e8  pop rdi
00007431745da1e9  pop rdx
00007431745da1ea  pop rcx
00007431745da1eb  pop rax
00007431745da1ec  add rsp, 0x08
00007431745da1f0  jmp 0x00007431745D6400
00007431745da1f5  sub rsp, 0x08
00007431745da1f9  push rax
00007431745da1fa  push rcx
00007431745da1fb  push rdx
00007431745da1fc  push rdi
00007431745da1fd  push rsi
00007431745da1fe  push r8
00007431745da200  push r9
00007431745da202  push r10
00007431745da204  push r11
00007431745da206  sub rsp, 0xF0
00007431745da20d  vmovaps [rsp], xmm0
00007431745da212  vmovaps [rsp+0x10], xmm2
00007431745da218  vmovaps [rsp+0x20], xmm3
00007431745da21e  vmovaps [rsp+0x30], xmm4
00007431745da224  vmovaps [rsp+0x40], xmm5
00007431745da22a  vmovaps [rsp+0x50], xmm6
00007431745da230  vmovaps [rsp+0x60], xmm7
00007431745da236  vmovaps [rsp+0x70], xmm8
00007431745da23c  vmovaps [rsp+0x80], xmm9
00007431745da245  vmovaps [rsp+0x90], xmm10
00007431745da24e  vmovaps [rsp+0xA0], xmm11
00007431745da257  vmovaps [rsp+0xB0], xmm12
00007431745da260  vmovaps [rsp+0xC0], xmm13
00007431745da269  vmovaps [rsp+0xD0], xmm14
00007431745da272  vmovaps [rsp+0xE0], xmm15
00007431745da27b  sub rsp, 0x30
00007431745da27f  movaps [rsp], xmm1
00007431745da283  movaps [rsp+0x10], xmm13
00007431745da289  movaps [rsp+0x20], xmm9
00007431745da28f  lea rdi, [rsp]
00007431745da293  mov esi, 0x00
00007431745da298  mov rax, 0x56C40959E530
00007431745da2a2  call rax
00007431745da2a4  movaps xmm1, [rsp]
00007431745da2a8  add rsp, 0x30
00007431745da2ac  vmovaps xmm0, [rsp]
00007431745da2b1  vmovaps xmm2, [rsp+0x10]
00007431745da2b7  vmovaps xmm3, [rsp+0x20]
00007431745da2bd  vmovaps xmm4, [rsp+0x30]
00007431745da2c3  vmovaps xmm5, [rsp+0x40]
00007431745da2c9  vmovaps xmm6, [rsp+0x50]
00007431745da2cf  vmovaps xmm7, [rsp+0x60]
00007431745da2d5  vmovaps xmm8, [rsp+0x70]
00007431745da2db  vmovaps xmm9, [rsp+0x80]
00007431745da2e4  vmovaps xmm10, [rsp+0x90]
00007431745da2ed  vmovaps xmm11, [rsp+0xA0]
00007431745da2f6  vmovaps xmm12, [rsp+0xB0]
00007431745da2ff  vmovaps xmm13, [rsp+0xC0]
00007431745da308  vmovaps xmm14, [rsp+0xD0]
00007431745da311  vmovaps xmm15, [rsp+0xE0]
00007431745da31a  add rsp, 0xF0
00007431745da321  pop r11
00007431745da323  pop r10
00007431745da325  pop r9
00007431745da327  pop r8
00007431745da329  pop rsi
00007431745da32a  pop rdi
00007431745da32b  pop rdx
00007431745da32c  pop rcx
00007431745da32d  pop rax
00007431745da32e  add rsp, 0x08
00007431745da332  jmp 0x00007431745D641A
00007431745da337  sub rsp, 0x08
00007431745da33b  push rax
00007431745da33c  push rcx
00007431745da33d  push rdx
00007431745da33e  push rdi
00007431745da33f  push rsi
00007431745da340  push r8
00007431745da342  push r9
00007431745da344  push r10
00007431745da346  push r11
00007431745da348  sub rsp, 0xF0
00007431745da34f  vmovaps [rsp], xmm0
00007431745da354  vmovaps [rsp+0x10], xmm1
00007431745da35a  vmovaps [rsp+0x20], xmm2
00007431745da360  vmovaps [rsp+0x30], xmm3
00007431745da366  vmovaps [rsp+0x40], xmm4
00007431745da36c  vmovaps [rsp+0x50], xmm5
00007431745da372  vmovaps [rsp+0x60], xmm6
00007431745da378  vmovaps [rsp+0x70], xmm7
00007431745da37e  vmovaps [rsp+0x80], xmm8
00007431745da387  vmovaps [rsp+0x90], xmm9
00007431745da390  vmovaps [rsp+0xA0], xmm10
00007431745da399  vmovaps [rsp+0xB0], xmm11
00007431745da3a2  vmovaps [rsp+0xC0], xmm13
00007431745da3ab  vmovaps [rsp+0xD0], xmm14
00007431745da3b4  vmovaps [rsp+0xE0], xmm15
00007431745da3bd  sub rsp, 0x30
00007431745da3c1  movaps [rsp], xmm12
00007431745da3c6  movaps [rsp+0x10], xmm7
00007431745da3cb  movaps [rsp+0x20], xmm13
00007431745da3d1  lea rdi, [rsp]
00007431745da3d5  mov esi, 0x00
00007431745da3da  mov rax, 0x56C40959E530
00007431745da3e4  call rax
00007431745da3e6  movaps xmm12, [rsp]
00007431745da3eb  add rsp, 0x30
00007431745da3ef  vmovaps xmm0, [rsp]
00007431745da3f4  vmovaps xmm1, [rsp+0x10]
00007431745da3fa  vmovaps xmm2, [rsp+0x20]
00007431745da400  vmovaps xmm3, [rsp+0x30]
00007431745da406  vmovaps xmm4, [rsp+0x40]
00007431745da40c  vmovaps xmm5, [rsp+0x50]
00007431745da412  vmovaps xmm6, [rsp+0x60]
00007431745da418  vmovaps xmm7, [rsp+0x70]
00007431745da41e  vmovaps xmm8, [rsp+0x80]
00007431745da427  vmovaps xmm9, [rsp+0x90]
00007431745da430  vmovaps xmm10, [rsp+0xA0]
00007431745da439  vmovaps xmm11, [rsp+0xB0]
00007431745da442  vmovaps xmm13, [rsp+0xC0]
00007431745da44b  vmovaps xmm14, [rsp+0xD0]
00007431745da454  vmovaps xmm15, [rsp+0xE0]
00007431745da45d  add rsp, 0xF0
00007431745da464  pop r11
00007431745da466  pop r10
00007431745da468  pop r9
00007431745da46a  pop r8
00007431745da46c  pop rsi
00007431745da46d  pop rdi
00007431745da46e  pop rdx
00007431745da46f  pop rcx
00007431745da470  pop rax
00007431745da471  add rsp, 0x08
00007431745da475  jmp 0x00007431745D6441
00007431745da47a  sub rsp, 0x08
00007431745da47e  push rax
00007431745da47f  push rcx
00007431745da480  push rdx
00007431745da481  push rdi
00007431745da482  push rsi
00007431745da483  push r8
00007431745da485  push r9
00007431745da487  push r10
00007431745da489  push r11
00007431745da48b  sub rsp, 0xF0
00007431745da492  vmovaps [rsp], xmm0
00007431745da497  vmovaps [rsp+0x10], xmm1
00007431745da49d  vmovaps [rsp+0x20], xmm2
00007431745da4a3  vmovaps [rsp+0x30], xmm3
00007431745da4a9  vmovaps [rsp+0x40], xmm4
00007431745da4af  vmovaps [rsp+0x50], xmm5
00007431745da4b5  vmovaps [rsp+0x60], xmm6
00007431745da4bb  vmovaps [rsp+0x70], xmm7
00007431745da4c1  vmovaps [rsp+0x80], xmm8
00007431745da4ca  vmovaps [rsp+0x90], xmm9
00007431745da4d3  vmovaps [rsp+0xA0], xmm10
00007431745da4dc  vmovaps [rsp+0xB0], xmm11
00007431745da4e5  vmovaps [rsp+0xC0], xmm12
00007431745da4ee  vmovaps [rsp+0xD0], xmm14
00007431745da4f7  vmovaps [rsp+0xE0], xmm15
00007431745da500  sub rsp, 0x30
00007431745da504  movaps [rsp], xmm13
00007431745da509  movaps [rsp+0x10], xmm15
00007431745da50f  movaps [rsp+0x20], xmm8
00007431745da515  lea rdi, [rsp]
00007431745da519  mov esi, 0x00
00007431745da51e  mov rax, 0x56C40959E530
00007431745da528  call rax
00007431745da52a  movaps xmm13, [rsp]
00007431745da52f  add rsp, 0x30
00007431745da533  vmovaps xmm0, [rsp]
00007431745da538  vmovaps xmm1, [rsp+0x10]
00007431745da53e  vmovaps xmm2, [rsp+0x20]
00007431745da544  vmovaps xmm3, [rsp+0x30]
00007431745da54a  vmovaps xmm4, [rsp+0x40]
00007431745da550  vmovaps xmm5, [rsp+0x50]
00007431745da556  vmovaps xmm6, [rsp+0x60]
00007431745da55c  vmovaps xmm7, [rsp+0x70]
00007431745da562  vmovaps xmm8, [rsp+0x80]
00007431745da56b  vmovaps xmm9, [rsp+0x90]
00007431745da574  vmovaps xmm10, [rsp+0xA0]
00007431745da57d  vmovaps xmm11, [rsp+0xB0]
00007431745da586  vmovaps xmm12, [rsp+0xC0]
00007431745da58f  vmovaps xmm14, [rsp+0xD0]
00007431745da598  vmovaps xmm15, [rsp+0xE0]
00007431745da5a1  add rsp, 0xF0
00007431745da5a8  pop r11
00007431745da5aa  pop r10
00007431745da5ac  pop r9
00007431745da5ae  pop r8
00007431745da5b0  pop rsi
00007431745da5b1  pop rdi
00007431745da5b2  pop rdx
00007431745da5b3  pop rcx
00007431745da5b4  pop rax
00007431745da5b5  add rsp, 0x08
00007431745da5b9  jmp 0x00007431745D645C
00007431745da5be  sub rsp, 0x08
00007431745da5c2  push rax
00007431745da5c3  push rcx
00007431745da5c4  push rdx
00007431745da5c5  push rdi
00007431745da5c6  push rsi
00007431745da5c7  push r8
00007431745da5c9  push r9
00007431745da5cb  push r10
00007431745da5cd  push r11
00007431745da5cf  sub rsp, 0xF0
00007431745da5d6  vmovaps [rsp], xmm0
00007431745da5db  vmovaps [rsp+0x10], xmm1
00007431745da5e1  vmovaps [rsp+0x20], xmm2
00007431745da5e7  vmovaps [rsp+0x30], xmm3
00007431745da5ed  vmovaps [rsp+0x40], xmm4
00007431745da5f3  vmovaps [rsp+0x50], xmm5
00007431745da5f9  vmovaps [rsp+0x60], xmm6
00007431745da5ff  vmovaps [rsp+0x70], xmm7
00007431745da605  vmovaps [rsp+0x80], xmm9
00007431745da60e  vmovaps [rsp+0x90], xmm10
00007431745da617  vmovaps [rsp+0xA0], xmm11
00007431745da620  vmovaps [rsp+0xB0], xmm12
00007431745da629  vmovaps [rsp+0xC0], xmm13
00007431745da632  vmovaps [rsp+0xD0], xmm14
00007431745da63b  vmovaps [rsp+0xE0], xmm15
00007431745da644  sub rsp, 0x30
00007431745da648  movaps [rsp], xmm8
00007431745da64d  movaps [rsp+0x10], xmm15
00007431745da653  movaps [rsp+0x20], xmm9
00007431745da659  lea rdi, [rsp]
00007431745da65d  mov esi, 0x00
00007431745da662  mov rax, 0x56C40959E530
00007431745da66c  call rax
00007431745da66e  movaps xmm8, [rsp]
00007431745da673  add rsp, 0x30
00007431745da677  vmovaps xmm0, [rsp]
00007431745da67c  vmovaps xmm1, [rsp+0x10]
00007431745da682  vmovaps xmm2, [rsp+0x20]
00007431745da688  vmovaps xmm3, [rsp+0x30]
00007431745da68e  vmovaps xmm4, [rsp+0x40]
00007431745da694  vmovaps xmm5, [rsp+0x50]
00007431745da69a  vmovaps xmm6, [rsp+0x60]
00007431745da6a0  vmovaps xmm7, [rsp+0x70]
00007431745da6a6  vmovaps xmm9, [rsp+0x80]
00007431745da6af  vmovaps xmm10, [rsp+0x90]
00007431745da6b8  vmovaps xmm11, [rsp+0xA0]
00007431745da6c1  vmovaps xmm12, [rsp+0xB0]
00007431745da6ca  vmovaps xmm13, [rsp+0xC0]
00007431745da6d3  vmovaps xmm14, [rsp+0xD0]
00007431745da6dc  vmovaps xmm15, [rsp+0xE0]
00007431745da6e5  add rsp, 0xF0
00007431745da6ec  pop r11
00007431745da6ee  pop r10
00007431745da6f0  pop r9
00007431745da6f2  pop r8
00007431745da6f4  pop rsi
00007431745da6f5  pop rdi
00007431745da6f6  pop rdx
00007431745da6f7  pop rcx
00007431745da6f8  pop rax
00007431745da6f9  add rsp, 0x08
00007431745da6fd  jmp 0x00007431745D648A
00007431745da702  sub rsp, 0x08
00007431745da706  push rax
00007431745da707  push rcx
00007431745da708  push rdx
00007431745da709  push rdi
00007431745da70a  push rsi
00007431745da70b  push r8
00007431745da70d  push r9
00007431745da70f  push r10
00007431745da711  push r11
00007431745da713  sub rsp, 0xF0
00007431745da71a  vmovaps [rsp], xmm0
00007431745da71f  vmovaps [rsp+0x10], xmm1
00007431745da725  vmovaps [rsp+0x20], xmm2
00007431745da72b  vmovaps [rsp+0x30], xmm3
00007431745da731  vmovaps [rsp+0x40], xmm4
00007431745da737  vmovaps [rsp+0x50], xmm5
00007431745da73d  vmovaps [rsp+0x60], xmm6
00007431745da743  vmovaps [rsp+0x70], xmm7
00007431745da749  vmovaps [rsp+0x80], xmm8
00007431745da752  vmovaps [rsp+0x90], xmm9
00007431745da75b  vmovaps [rsp+0xA0], xmm10
00007431745da764  vmovaps [rsp+0xB0], xmm11
00007431745da76d  vmovaps [rsp+0xC0], xmm12
00007431745da776  vmovaps [rsp+0xD0], xmm13
00007431745da77f  vmovaps [rsp+0xE0], xmm14
00007431745da788  sub rsp, 0x30
00007431745da78c  movaps [rsp], xmm15
00007431745da791  movaps [rsp+0x10], xmm11
00007431745da797  movaps [rsp+0x20], xmm6
00007431745da79c  lea rdi, [rsp]
00007431745da7a0  mov esi, 0x00
00007431745da7a5  mov rax, 0x56C40959E530
00007431745da7af  call rax
00007431745da7b1  movaps xmm15, [rsp]
00007431745da7b6  add rsp, 0x30
00007431745da7ba  vmovaps xmm0, [rsp]
00007431745da7bf  vmovaps xmm1, [rsp+0x10]
00007431745da7c5  vmovaps xmm2, [rsp+0x20]
00007431745da7cb  vmovaps xmm3, [rsp+0x30]
00007431745da7d1  vmovaps xmm4, [rsp+0x40]
00007431745da7d7  vmovaps xmm5, [rsp+0x50]
00007431745da7dd  vmovaps xmm6, [rsp+0x60]
00007431745da7e3  vmovaps xmm7, [rsp+0x70]
00007431745da7e9  vmovaps xmm8, [rsp+0x80]
00007431745da7f2  vmovaps xmm9, [rsp+0x90]
00007431745da7fb  vmovaps xmm10, [rsp+0xA0]
00007431745da804  vmovaps xmm11, [rsp+0xB0]
00007431745da80d  vmovaps xmm12, [rsp+0xC0]
00007431745da816  vmovaps xmm13, [rsp+0xD0]
00007431745da81f  vmovaps xmm14, [rsp+0xE0]
00007431745da828  add rsp, 0xF0
00007431745da82f  pop r11
00007431745da831  pop r10
00007431745da833  pop r9
00007431745da835  pop r8
00007431745da837  pop rsi
00007431745da838  pop rdi
00007431745da839  pop rdx
00007431745da83a  pop rcx
00007431745da83b  pop rax
00007431745da83c  add rsp, 0x08
00007431745da840  jmp 0x00007431745D64A5
00007431745da845  sub rsp, 0x08
00007431745da849  push rax
00007431745da84a  push rcx
00007431745da84b  push rdx
00007431745da84c  push rdi
00007431745da84d  push rsi
00007431745da84e  push r8
00007431745da850  push r9
00007431745da852  push r10
00007431745da854  push r11
00007431745da856  sub rsp, 0xF0
00007431745da85d  vmovaps [rsp], xmm0
00007431745da862  vmovaps [rsp+0x10], xmm1
00007431745da868  vmovaps [rsp+0x20], xmm2
00007431745da86e  vmovaps [rsp+0x30], xmm3
00007431745da874  vmovaps [rsp+0x40], xmm4
00007431745da87a  vmovaps [rsp+0x50], xmm5
00007431745da880  vmovaps [rsp+0x60], xmm6
00007431745da886  vmovaps [rsp+0x70], xmm8
00007431745da88c  vmovaps [rsp+0x80], xmm9
00007431745da895  vmovaps [rsp+0x90], xmm10
00007431745da89e  vmovaps [rsp+0xA0], xmm11
00007431745da8a7  vmovaps [rsp+0xB0], xmm12
00007431745da8b0  vmovaps [rsp+0xC0], xmm13
00007431745da8b9  vmovaps [rsp+0xD0], xmm14
00007431745da8c2  vmovaps [rsp+0xE0], xmm15
00007431745da8cb  sub rsp, 0x30
00007431745da8cf  movaps [rsp], xmm7
00007431745da8d3  movaps [rsp+0x10], xmm11
00007431745da8d9  movaps [rsp+0x20], xmm9
00007431745da8df  lea rdi, [rsp]
00007431745da8e3  mov esi, 0x00
00007431745da8e8  mov rax, 0x56C40959E530
00007431745da8f2  call rax
00007431745da8f4  movaps xmm7, [rsp]
00007431745da8f8  add rsp, 0x30
00007431745da8fc  vmovaps xmm0, [rsp]
00007431745da901  vmovaps xmm1, [rsp+0x10]
00007431745da907  vmovaps xmm2, [rsp+0x20]
00007431745da90d  vmovaps xmm3, [rsp+0x30]
00007431745da913  vmovaps xmm4, [rsp+0x40]
00007431745da919  vmovaps xmm5, [rsp+0x50]
00007431745da91f  vmovaps xmm6, [rsp+0x60]
00007431745da925  vmovaps xmm8, [rsp+0x70]
00007431745da92b  vmovaps xmm9, [rsp+0x80]
00007431745da934  vmovaps xmm10, [rsp+0x90]
00007431745da93d  vmovaps xmm11, [rsp+0xA0]
00007431745da946  vmovaps xmm12, [rsp+0xB0]
00007431745da94f  vmovaps xmm13, [rsp+0xC0]
00007431745da958  vmovaps xmm14, [rsp+0xD0]
00007431745da961  vmovaps xmm15, [rsp+0xE0]
00007431745da96a  add rsp, 0xF0
00007431745da971  pop r11
00007431745da973  pop r10
00007431745da975  pop r9
00007431745da977  pop r8
00007431745da979  pop rsi
00007431745da97a  pop rdi
00007431745da97b  pop rdx
00007431745da97c  pop rcx
00007431745da97d  pop rax
00007431745da97e  add rsp, 0x08
00007431745da982  jmp 0x00007431745D64D2
00007431745da987  sub rsp, 0x08
00007431745da98b  push rax
00007431745da98c  push rcx
00007431745da98d  push rdx
00007431745da98e  push rdi
00007431745da98f  push rsi
00007431745da990  push r8
00007431745da992  push r9
00007431745da994  push r10
00007431745da996  push r11
00007431745da998  sub rsp, 0xF0
00007431745da99f  vmovaps [rsp], xmm0
00007431745da9a4  vmovaps [rsp+0x10], xmm1
00007431745da9aa  vmovaps [rsp+0x20], xmm2
00007431745da9b0  vmovaps [rsp+0x30], xmm3
00007431745da9b6  vmovaps [rsp+0x40], xmm4
00007431745da9bc  vmovaps [rsp+0x50], xmm5
00007431745da9c2  vmovaps [rsp+0x60], xmm6
00007431745da9c8  vmovaps [rsp+0x70], xmm7
00007431745da9ce  vmovaps [rsp+0x80], xmm8
00007431745da9d7  vmovaps [rsp+0x90], xmm9
00007431745da9e0  vmovaps [rsp+0xA0], xmm10
00007431745da9e9  vmovaps [rsp+0xB0], xmm12
00007431745da9f2  vmovaps [rsp+0xC0], xmm13
00007431745da9fb  vmovaps [rsp+0xD0], xmm14
00007431745daa04  vmovaps [rsp+0xE0], xmm15
00007431745daa0d  sub rsp, 0x30
00007431745daa11  movaps [rsp], xmm11
00007431745daa16  movaps [rsp+0x10], xmm10
00007431745daa1c  movaps [rsp+0x20], xmm14
00007431745daa22  lea rdi, [rsp]
00007431745daa26  mov esi, 0x00
00007431745daa2b  mov rax, 0x56C40959E530
00007431745daa35  call rax
00007431745daa37  movaps xmm11, [rsp]
00007431745daa3c  add rsp, 0x30
00007431745daa40  vmovaps xmm0, [rsp]
00007431745daa45  vmovaps xmm1, [rsp+0x10]
00007431745daa4b  vmovaps xmm2, [rsp+0x20]
00007431745daa51  vmovaps xmm3, [rsp+0x30]
00007431745daa57  vmovaps xmm4, [rsp+0x40]
00007431745daa5d  vmovaps xmm5, [rsp+0x50]
00007431745daa63  vmovaps xmm6, [rsp+0x60]
00007431745daa69  vmovaps xmm7, [rsp+0x70]
00007431745daa6f  vmovaps xmm8, [rsp+0x80]
00007431745daa78  vmovaps xmm9, [rsp+0x90]
00007431745daa81  vmovaps xmm10, [rsp+0xA0]
00007431745daa8a  vmovaps xmm12, [rsp+0xB0]
00007431745daa93  vmovaps xmm13, [rsp+0xC0]
00007431745daa9c  vmovaps xmm14, [rsp+0xD0]
00007431745daaa5  vmovaps xmm15, [rsp+0xE0]
00007431745daaae  add rsp, 0xF0
00007431745daab5  pop r11
00007431745daab7  pop r10
00007431745daab9  pop r9
00007431745daabb  pop r8
00007431745daabd  pop rsi
00007431745daabe  pop rdi
00007431745daabf  pop rdx
00007431745daac0  pop rcx
00007431745daac1  pop rax
00007431745daac2  add rsp, 0x08
00007431745daac6  jmp 0x00007431745D64ED
00007431745daacb  call 0x00007431744E45A0
00007431745daad0  jmp 0x00007431745D64F7
00007431745daad5  sub rsp, 0x08
00007431745daad9  push rax
00007431745daada  push rcx
00007431745daadb  push rdx
00007431745daadc  push rdi
00007431745daadd  push rsi
00007431745daade  push r8
00007431745daae0  push r9
00007431745daae2  push r10
00007431745daae4  push r11
00007431745daae6  sub rsp, 0xF0
00007431745daaed  vmovaps [rsp], xmm0
00007431745daaf2  vmovaps [rsp+0x10], xmm1
00007431745daaf8  vmovaps [rsp+0x20], xmm2
00007431745daafe  vmovaps [rsp+0x30], xmm3
00007431745dab04  vmovaps [rsp+0x40], xmm4
00007431745dab0a  vmovaps [rsp+0x50], xmm5
00007431745dab10  vmovaps [rsp+0x60], xmm6
00007431745dab16  vmovaps [rsp+0x70], xmm7
00007431745dab1c  vmovaps [rsp+0x80], xmm8
00007431745dab25  vmovaps [rsp+0x90], xmm9
00007431745dab2e  vmovaps [rsp+0xA0], xmm11
00007431745dab37  vmovaps [rsp+0xB0], xmm12
00007431745dab40  vmovaps [rsp+0xC0], xmm13
00007431745dab49  vmovaps [rsp+0xD0], xmm14
00007431745dab52  vmovaps [rsp+0xE0], xmm15
00007431745dab5b  sub rsp, 0x30
00007431745dab5f  movaps [rsp], xmm10
00007431745dab64  movaps [rsp+0x10], xmm1
00007431745dab69  movaps [rsp+0x20], xmm12
00007431745dab6f  lea rdi, [rsp]
00007431745dab73  mov esi, 0x00
00007431745dab78  mov rax, 0x56C40959E530
00007431745dab82  call rax
00007431745dab84  movaps xmm10, [rsp]
00007431745dab89  add rsp, 0x30
00007431745dab8d  vmovaps xmm0, [rsp]
00007431745dab92  vmovaps xmm1, [rsp+0x10]
00007431745dab98  vmovaps xmm2, [rsp+0x20]
00007431745dab9e  vmovaps xmm3, [rsp+0x30]
00007431745daba4  vmovaps xmm4, [rsp+0x40]
00007431745dabaa  vmovaps xmm5, [rsp+0x50]
00007431745dabb0  vmovaps xmm6, [rsp+0x60]
00007431745dabb6  vmovaps xmm7, [rsp+0x70]
00007431745dabbc  vmovaps xmm8, [rsp+0x80]
00007431745dabc5  vmovaps xmm9, [rsp+0x90]
00007431745dabce  vmovaps xmm11, [rsp+0xA0]
00007431745dabd7  vmovaps xmm12, [rsp+0xB0]
00007431745dabe0  vmovaps xmm13, [rsp+0xC0]
00007431745dabe9  vmovaps xmm14, [rsp+0xD0]
00007431745dabf2  vmovaps xmm15, [rsp+0xE0]
00007431745dabfb  add rsp, 0xF0
00007431745dac02  pop r11
00007431745dac04  pop r10
00007431745dac06  pop r9
00007431745dac08  pop r8
00007431745dac0a  pop rsi
00007431745dac0b  pop rdi
00007431745dac0c  pop rdx
00007431745dac0d  pop rcx
00007431745dac0e  pop rax
00007431745dac0f  add rsp, 0x08
00007431745dac13  jmp 0x00007431745D651A
00007431745dac18  sub rsp, 0x08
00007431745dac1c  push rax
00007431745dac1d  push rcx
00007431745dac1e  push rdx
00007431745dac1f  push rdi
00007431745dac20  push rsi
00007431745dac21  push r8
00007431745dac23  push r9
00007431745dac25  push r10
00007431745dac27  push r11
00007431745dac29  sub rsp, 0xF0
00007431745dac30  vmovaps [rsp], xmm0
00007431745dac35  vmovaps [rsp+0x10], xmm1
00007431745dac3b  vmovaps [rsp+0x20], xmm2
00007431745dac41  vmovaps [rsp+0x30], xmm3
00007431745dac47  vmovaps [rsp+0x40], xmm4
00007431745dac4d  vmovaps [rsp+0x50], xmm5
00007431745dac53  vmovaps [rsp+0x60], xmm6
00007431745dac59  vmovaps [rsp+0x70], xmm7
00007431745dac5f  vmovaps [rsp+0x80], xmm8
00007431745dac68  vmovaps [rsp+0x90], xmm9
00007431745dac71  vmovaps [rsp+0xA0], xmm10
00007431745dac7a  vmovaps [rsp+0xB0], xmm11
00007431745dac83  vmovaps [rsp+0xC0], xmm13
00007431745dac8c  vmovaps [rsp+0xD0], xmm14
00007431745dac95  vmovaps [rsp+0xE0], xmm15
00007431745dac9e  sub rsp, 0x30
00007431745daca2  movaps [rsp], xmm12
00007431745daca7  movaps [rsp+0x10], xmm14
00007431745dacad  movaps [rsp+0x20], xmm1
00007431745dacb2  lea rdi, [rsp]
00007431745dacb6  mov esi, 0x00
00007431745dacbb  mov rax, 0x56C40959E530
00007431745dacc5  call rax
00007431745dacc7  movaps xmm12, [rsp]
00007431745daccc  add rsp, 0x30
00007431745dacd0  vmovaps xmm0, [rsp]
00007431745dacd5  vmovaps xmm1, [rsp+0x10]
00007431745dacdb  vmovaps xmm2, [rsp+0x20]
00007431745dace1  vmovaps xmm3, [rsp+0x30]
00007431745dace7  vmovaps xmm4, [rsp+0x40]
00007431745daced  vmovaps xmm5, [rsp+0x50]
00007431745dacf3  vmovaps xmm6, [rsp+0x60]
00007431745dacf9  vmovaps xmm7, [rsp+0x70]
00007431745dacff  vmovaps xmm8, [rsp+0x80]
00007431745dad08  vmovaps xmm9, [rsp+0x90]
00007431745dad11  vmovaps xmm10, [rsp+0xA0]
00007431745dad1a  vmovaps xmm11, [rsp+0xB0]
00007431745dad23  vmovaps xmm13, [rsp+0xC0]
00007431745dad2c  vmovaps xmm14, [rsp+0xD0]
00007431745dad35  vmovaps xmm15, [rsp+0xE0]
00007431745dad3e  add rsp, 0xF0
00007431745dad45  pop r11
00007431745dad47  pop r10
00007431745dad49  pop r9
00007431745dad4b  pop r8
00007431745dad4d  pop rsi
00007431745dad4e  pop rdi
00007431745dad4f  pop rdx
00007431745dad50  pop rcx
00007431745dad51  pop rax
00007431745dad52  add rsp, 0x08
00007431745dad56  jmp 0x00007431745D6549
00007431745dad5b  sub rsp, 0x08
00007431745dad5f  push rax
00007431745dad60  push rcx
00007431745dad61  push rdx
00007431745dad62  push rdi
00007431745dad63  push rsi
00007431745dad64  push r8
00007431745dad66  push r9
00007431745dad68  push r10
00007431745dad6a  push r11
00007431745dad6c  sub rsp, 0xF0
00007431745dad73  vmovaps [rsp], xmm0
00007431745dad78  vmovaps [rsp+0x10], xmm1
00007431745dad7e  vmovaps [rsp+0x20], xmm2
00007431745dad84  vmovaps [rsp+0x30], xmm3
00007431745dad8a  vmovaps [rsp+0x40], xmm4
00007431745dad90  vmovaps [rsp+0x50], xmm5
00007431745dad96  vmovaps [rsp+0x60], xmm6
00007431745dad9c  vmovaps [rsp+0x70], xmm7
00007431745dada2  vmovaps [rsp+0x80], xmm8
00007431745dadab  vmovaps [rsp+0x90], xmm9
00007431745dadb4  vmovaps [rsp+0xA0], xmm10
00007431745dadbd  vmovaps [rsp+0xB0], xmm11
00007431745dadc6  vmovaps [rsp+0xC0], xmm12
00007431745dadcf  vmovaps [rsp+0xD0], xmm13
00007431745dadd8  vmovaps [rsp+0xE0], xmm15
00007431745dade1  sub rsp, 0x30
00007431745dade5  movaps [rsp], xmm14
00007431745dadea  movaps [rsp+0x10], xmm9
00007431745dadf0  movaps [rsp+0x20], xmm1
00007431745dadf5  lea rdi, [rsp]
00007431745dadf9  mov esi, 0x00
00007431745dadfe  mov rax, 0x56C40959E530
00007431745dae08  call rax
00007431745dae0a  movaps xmm14, [rsp]
00007431745dae0f  add rsp, 0x30
00007431745dae13  vmovaps xmm0, [rsp]
00007431745dae18  vmovaps xmm1, [rsp+0x10]
00007431745dae1e  vmovaps xmm2, [rsp+0x20]
00007431745dae24  vmovaps xmm3, [rsp+0x30]
00007431745dae2a  vmovaps xmm4, [rsp+0x40]
00007431745dae30  vmovaps xmm5, [rsp+0x50]
00007431745dae36  vmovaps xmm6, [rsp+0x60]
00007431745dae3c  vmovaps xmm7, [rsp+0x70]
00007431745dae42  vmovaps xmm8, [rsp+0x80]
00007431745dae4b  vmovaps xmm9, [rsp+0x90]
00007431745dae54  vmovaps xmm10, [rsp+0xA0]
00007431745dae5d  vmovaps xmm11, [rsp+0xB0]
00007431745dae66  vmovaps xmm12, [rsp+0xC0]
00007431745dae6f  vmovaps xmm13, [rsp+0xD0]
00007431745dae78  vmovaps xmm15, [rsp+0xE0]
00007431745dae81  add rsp, 0xF0
00007431745dae88  pop r11
00007431745dae8a  pop r10
00007431745dae8c  pop r9
00007431745dae8e  pop r8
00007431745dae90  pop rsi
00007431745dae91  pop rdi
00007431745dae92  pop rdx
00007431745dae93  pop rcx
00007431745dae94  pop rax
00007431745dae95  add rsp, 0x08
00007431745dae99  jmp 0x00007431745D6578
00007431745dae9e  sub rsp, 0x08
00007431745daea2  push rax
00007431745daea3  push rcx
00007431745daea4  push rdx
00007431745daea5  push rdi
00007431745daea6  push rsi
00007431745daea7  push r8
00007431745daea9  push r9
00007431745daeab  push r10
00007431745daead  push r11
00007431745daeaf  sub rsp, 0xF0
00007431745daeb6  vmovaps [rsp], xmm0
00007431745daebb  vmovaps [rsp+0x10], xmm2
00007431745daec1  vmovaps [rsp+0x20], xmm3
00007431745daec7  vmovaps [rsp+0x30], xmm4
00007431745daecd  vmovaps [rsp+0x40], xmm5
00007431745daed3  vmovaps [rsp+0x50], xmm6
00007431745daed9  vmovaps [rsp+0x60], xmm7
00007431745daedf  vmovaps [rsp+0x70], xmm8
00007431745daee5  vmovaps [rsp+0x80], xmm9
00007431745daeee  vmovaps [rsp+0x90], xmm10
00007431745daef7  vmovaps [rsp+0xA0], xmm11
00007431745daf00  vmovaps [rsp+0xB0], xmm12
00007431745daf09  vmovaps [rsp+0xC0], xmm13
00007431745daf12  vmovaps [rsp+0xD0], xmm14
00007431745daf1b  vmovaps [rsp+0xE0], xmm15
00007431745daf24  sub rsp, 0x30
00007431745daf28  movaps [rsp], xmm1
00007431745daf2c  movaps [rsp+0x10], xmm13
00007431745daf32  movaps [rsp+0x20], xmm8
00007431745daf38  lea rdi, [rsp]
00007431745daf3c  mov esi, 0x00
00007431745daf41  mov rax, 0x56C40959E530
00007431745daf4b  call rax
00007431745daf4d  movaps xmm1, [rsp]
00007431745daf51  add rsp, 0x30
00007431745daf55  vmovaps xmm0, [rsp]
00007431745daf5a  vmovaps xmm2, [rsp+0x10]
00007431745daf60  vmovaps xmm3, [rsp+0x20]
00007431745daf66  vmovaps xmm4, [rsp+0x30]
00007431745daf6c  vmovaps xmm5, [rsp+0x40]
00007431745daf72  vmovaps xmm6, [rsp+0x50]
00007431745daf78  vmovaps xmm7, [rsp+0x60]
00007431745daf7e  vmovaps xmm8, [rsp+0x70]
00007431745daf84  vmovaps xmm9, [rsp+0x80]
00007431745daf8d  vmovaps xmm10, [rsp+0x90]
00007431745daf96  vmovaps xmm11, [rsp+0xA0]
00007431745daf9f  vmovaps xmm12, [rsp+0xB0]
00007431745dafa8  vmovaps xmm13, [rsp+0xC0]
00007431745dafb1  vmovaps xmm14, [rsp+0xD0]
00007431745dafba  vmovaps xmm15, [rsp+0xE0]
00007431745dafc3  add rsp, 0xF0
00007431745dafca  pop r11
00007431745dafcc  pop r10
00007431745dafce  pop r9
00007431745dafd0  pop r8
00007431745dafd2  pop rsi
00007431745dafd3  pop rdi
00007431745dafd4  pop rdx
00007431745dafd5  pop rcx
00007431745dafd6  pop rax
00007431745dafd7  add rsp, 0x08
00007431745dafdb  jmp 0x00007431745D659A
00007431745dafe0  call 0x000074317440C260
00007431745dafe5  jmp 0x00007431745D65A8
00007431745dafea  call 0x00007431744DE950
00007431745dafef  jmp 0x00007431745D65B2
00007431745daff4  sub rsp, 0x08
00007431745daff8  push rax
00007431745daff9  push rcx
00007431745daffa  push rdx
00007431745daffb  push rdi
00007431745daffc  push rsi
00007431745daffd  push r8
00007431745dafff  push r9
00007431745db001  push r10
00007431745db003  push r11
00007431745db005  sub rsp, 0xF0
00007431745db00c  vmovaps [rsp], xmm0
00007431745db011  vmovaps [rsp+0x10], xmm1
00007431745db017  vmovaps [rsp+0x20], xmm2
00007431745db01d  vmovaps [rsp+0x30], xmm3
00007431745db023  vmovaps [rsp+0x40], xmm4
00007431745db029  vmovaps [rsp+0x50], xmm5
00007431745db02f  vmovaps [rsp+0x60], xmm6
00007431745db035  vmovaps [rsp+0x70], xmm7
00007431745db03b  vmovaps [rsp+0x80], xmm9
00007431745db044  vmovaps [rsp+0x90], xmm10
00007431745db04d  vmovaps [rsp+0xA0], xmm11
00007431745db056  vmovaps [rsp+0xB0], xmm12
00007431745db05f  vmovaps [rsp+0xC0], xmm13
00007431745db068  vmovaps [rsp+0xD0], xmm14
00007431745db071  vmovaps [rsp+0xE0], xmm15
00007431745db07a  sub rsp, 0x30
00007431745db07e  movaps [rsp], xmm8
00007431745db083  movaps [rsp+0x10], xmm15
00007431745db089  movaps [rsp+0x20], xmm7
00007431745db08e  lea rdi, [rsp]
00007431745db092  mov esi, 0x00
00007431745db097  mov rax, 0x56C40959E530
00007431745db0a1  call rax
00007431745db0a3  movaps xmm8, [rsp]
00007431745db0a8  add rsp, 0x30
00007431745db0ac  vmovaps xmm0, [rsp]
00007431745db0b1  vmovaps xmm1, [rsp+0x10]
00007431745db0b7  vmovaps xmm2, [rsp+0x20]
00007431745db0bd  vmovaps xmm3, [rsp+0x30]
00007431745db0c3  vmovaps xmm4, [rsp+0x40]
00007431745db0c9  vmovaps xmm5, [rsp+0x50]
00007431745db0cf  vmovaps xmm6, [rsp+0x60]
00007431745db0d5  vmovaps xmm7, [rsp+0x70]
00007431745db0db  vmovaps xmm9, [rsp+0x80]
00007431745db0e4  vmovaps xmm10, [rsp+0x90]
00007431745db0ed  vmovaps xmm11, [rsp+0xA0]
00007431745db0f6  vmovaps xmm12, [rsp+0xB0]
00007431745db0ff  vmovaps xmm13, [rsp+0xC0]
00007431745db108  vmovaps xmm14, [rsp+0xD0]
00007431745db111  vmovaps xmm15, [rsp+0xE0]
00007431745db11a  add rsp, 0xF0
00007431745db121  pop r11
00007431745db123  pop r10
00007431745db125  pop r9
00007431745db127  pop r8
00007431745db129  pop rsi
00007431745db12a  pop rdi
00007431745db12b  pop rdx
00007431745db12c  pop rcx
00007431745db12d  pop rax
00007431745db12e  add rsp, 0x08
00007431745db132  jmp 0x00007431745D65D4
00007431745db137  sub rsp, 0x08
00007431745db13b  push rax
00007431745db13c  push rcx
00007431745db13d  push rdx
00007431745db13e  push rdi
00007431745db13f  push rsi
00007431745db140  push r8
00007431745db142  push r9
00007431745db144  push r10
00007431745db146  push r11
00007431745db148  sub rsp, 0xF0
00007431745db14f  vmovaps [rsp], xmm0
00007431745db154  vmovaps [rsp+0x10], xmm1
00007431745db15a  vmovaps [rsp+0x20], xmm2
00007431745db160  vmovaps [rsp+0x30], xmm3
00007431745db166  vmovaps [rsp+0x40], xmm4
00007431745db16c  vmovaps [rsp+0x50], xmm5
00007431745db172  vmovaps [rsp+0x60], xmm6
00007431745db178  vmovaps [rsp+0x70], xmm8
00007431745db17e  vmovaps [rsp+0x80], xmm9
00007431745db187  vmovaps [rsp+0x90], xmm10
00007431745db190  vmovaps [rsp+0xA0], xmm11
00007431745db199  vmovaps [rsp+0xB0], xmm12
00007431745db1a2  vmovaps [rsp+0xC0], xmm13
00007431745db1ab  vmovaps [rsp+0xD0], xmm14
00007431745db1b4  vmovaps [rsp+0xE0], xmm15
00007431745db1bd  sub rsp, 0x30
00007431745db1c1  movaps [rsp], xmm7
00007431745db1c5  movaps [rsp+0x10], xmm9
00007431745db1cb  movaps [rsp+0x20], xmm15
00007431745db1d1  lea rdi, [rsp]
00007431745db1d5  mov esi, 0x00
00007431745db1da  mov rax, 0x56C40959E530
00007431745db1e4  call rax
00007431745db1e6  movaps xmm7, [rsp]
00007431745db1ea  add rsp, 0x30
00007431745db1ee  vmovaps xmm0, [rsp]
00007431745db1f3  vmovaps xmm1, [rsp+0x10]
00007431745db1f9  vmovaps xmm2, [rsp+0x20]
00007431745db1ff  vmovaps xmm3, [rsp+0x30]
00007431745db205  vmovaps xmm4, [rsp+0x40]
00007431745db20b  vmovaps xmm5, [rsp+0x50]
00007431745db211  vmovaps xmm6, [rsp+0x60]
00007431745db217  vmovaps xmm8, [rsp+0x70]
00007431745db21d  vmovaps xmm9, [rsp+0x80]
00007431745db226  vmovaps xmm10, [rsp+0x90]
00007431745db22f  vmovaps xmm11, [rsp+0xA0]
00007431745db238  vmovaps xmm12, [rsp+0xB0]
00007431745db241  vmovaps xmm13, [rsp+0xC0]
00007431745db24a  vmovaps xmm14, [rsp+0xD0]
00007431745db253  vmovaps xmm15, [rsp+0xE0]
00007431745db25c  add rsp, 0xF0
00007431745db263  pop r11
00007431745db265  pop r10
00007431745db267  pop r9
00007431745db269  pop r8
00007431745db26b  pop rsi
00007431745db26c  pop rdi
00007431745db26d  pop rdx
00007431745db26e  pop rcx
00007431745db26f  pop rax
00007431745db270  add rsp, 0x08
00007431745db274  jmp 0x00007431745D6601
00007431745db279  sub rsp, 0x08
00007431745db27d  push rax
00007431745db27e  push rcx
00007431745db27f  push rdx
00007431745db280  push rdi
00007431745db281  push rsi
00007431745db282  push r8
00007431745db284  push r9
00007431745db286  push r10
00007431745db288  push r11
00007431745db28a  sub rsp, 0xF0
00007431745db291  vmovaps [rsp], xmm0
00007431745db296  vmovaps [rsp+0x10], xmm1
00007431745db29c  vmovaps [rsp+0x20], xmm2
00007431745db2a2  vmovaps [rsp+0x30], xmm3
00007431745db2a8  vmovaps [rsp+0x40], xmm4
00007431745db2ae  vmovaps [rsp+0x50], xmm5
00007431745db2b4  vmovaps [rsp+0x60], xmm6
00007431745db2ba  vmovaps [rsp+0x70], xmm7
00007431745db2c0  vmovaps [rsp+0x80], xmm8
00007431745db2c9  vmovaps [rsp+0x90], xmm10
00007431745db2d2  vmovaps [rsp+0xA0], xmm11
00007431745db2db  vmovaps [rsp+0xB0], xmm12
00007431745db2e4  vmovaps [rsp+0xC0], xmm13
00007431745db2ed  vmovaps [rsp+0xD0], xmm14
00007431745db2f6  vmovaps [rsp+0xE0], xmm15
00007431745db2ff  sub rsp, 0x30
00007431745db303  movaps [rsp], xmm9
00007431745db308  movaps [rsp+0x10], xmm13
00007431745db30e  movaps [rsp+0x20], xmm15
00007431745db314  lea rdi, [rsp]
00007431745db318  mov esi, 0x00
00007431745db31d  mov rax, 0x56C40959E530
00007431745db327  call rax
00007431745db329  movaps xmm9, [rsp]
00007431745db32e  add rsp, 0x30
00007431745db332  vmovaps xmm0, [rsp]
00007431745db337  vmovaps xmm1, [rsp+0x10]
00007431745db33d  vmovaps xmm2, [rsp+0x20]
00007431745db343  vmovaps xmm3, [rsp+0x30]
00007431745db349  vmovaps xmm4, [rsp+0x40]
00007431745db34f  vmovaps xmm5, [rsp+0x50]
00007431745db355  vmovaps xmm6, [rsp+0x60]
00007431745db35b  vmovaps xmm7, [rsp+0x70]
00007431745db361  vmovaps xmm8, [rsp+0x80]
00007431745db36a  vmovaps xmm10, [rsp+0x90]
00007431745db373  vmovaps xmm11, [rsp+0xA0]
00007431745db37c  vmovaps xmm12, [rsp+0xB0]
00007431745db385  vmovaps xmm13, [rsp+0xC0]
00007431745db38e  vmovaps xmm14, [rsp+0xD0]
00007431745db397  vmovaps xmm15, [rsp+0xE0]
00007431745db3a0  add rsp, 0xF0
00007431745db3a7  pop r11
00007431745db3a9  pop r10
00007431745db3ab  pop r9
00007431745db3ad  pop r8
00007431745db3af  pop rsi
00007431745db3b0  pop rdi
00007431745db3b1  pop rdx
00007431745db3b2  pop rcx
00007431745db3b3  pop rax
00007431745db3b4  add rsp, 0x08
00007431745db3b8  jmp 0x00007431745D662F
00007431745db3bd  sub rsp, 0x08
00007431745db3c1  push rax
00007431745db3c2  push rcx
00007431745db3c3  push rdx
00007431745db3c4  push rdi
00007431745db3c5  push rsi
00007431745db3c6  push r8
00007431745db3c8  push r9
00007431745db3ca  push r10
00007431745db3cc  push r11
00007431745db3ce  sub rsp, 0xF0
00007431745db3d5  vmovaps [rsp], xmm0
00007431745db3da  vmovaps [rsp+0x10], xmm1
00007431745db3e0  vmovaps [rsp+0x20], xmm2
00007431745db3e6  vmovaps [rsp+0x30], xmm3
00007431745db3ec  vmovaps [rsp+0x40], xmm4
00007431745db3f2  vmovaps [rsp+0x50], xmm5
00007431745db3f8  vmovaps [rsp+0x60], xmm6
00007431745db3fe  vmovaps [rsp+0x70], xmm7
00007431745db404  vmovaps [rsp+0x80], xmm8
00007431745db40d  vmovaps [rsp+0x90], xmm9
00007431745db416  vmovaps [rsp+0xA0], xmm10
00007431745db41f  vmovaps [rsp+0xB0], xmm11
00007431745db428  vmovaps [rsp+0xC0], xmm12
00007431745db431  vmovaps [rsp+0xD0], xmm13
00007431745db43a  vmovaps [rsp+0xE0], xmm14
00007431745db443  sub rsp, 0x30
00007431745db447  movaps [rsp], xmm15
00007431745db44c  movaps [rsp+0x10], xmm11
00007431745db452  movaps [rsp+0x20], xmm12
00007431745db458  lea rdi, [rsp]
00007431745db45c  mov esi, 0x00
00007431745db461  mov rax, 0x56C40959E530
00007431745db46b  call rax
00007431745db46d  movaps xmm15, [rsp]
00007431745db472  add rsp, 0x30
00007431745db476  vmovaps xmm0, [rsp]
00007431745db47b  vmovaps xmm1, [rsp+0x10]
00007431745db481  vmovaps xmm2, [rsp+0x20]
00007431745db487  vmovaps xmm3, [rsp+0x30]
00007431745db48d  vmovaps xmm4, [rsp+0x40]
00007431745db493  vmovaps xmm5, [rsp+0x50]
00007431745db499  vmovaps xmm6, [rsp+0x60]
00007431745db49f  vmovaps xmm7, [rsp+0x70]
00007431745db4a5  vmovaps xmm8, [rsp+0x80]
00007431745db4ae  vmovaps xmm9, [rsp+0x90]
00007431745db4b7  vmovaps xmm10, [rsp+0xA0]
00007431745db4c0  vmovaps xmm11, [rsp+0xB0]
00007431745db4c9  vmovaps xmm12, [rsp+0xC0]
00007431745db4d2  vmovaps xmm13, [rsp+0xD0]
00007431745db4db  vmovaps xmm14, [rsp+0xE0]
00007431745db4e4  add rsp, 0xF0
00007431745db4eb  pop r11
00007431745db4ed  pop r10
00007431745db4ef  pop r9
00007431745db4f1  pop r8
00007431745db4f3  pop rsi
00007431745db4f4  pop rdi
00007431745db4f5  pop rdx
00007431745db4f6  pop rcx
00007431745db4f7  pop rax
00007431745db4f8  add rsp, 0x08
00007431745db4fc  jmp 0x00007431745D664A
00007431745db501  sub rsp, 0x08
00007431745db505  push rax
00007431745db506  push rcx
00007431745db507  push rdx
00007431745db508  push rdi
00007431745db509  push rsi
00007431745db50a  push r8
00007431745db50c  push r9
00007431745db50e  push r10
00007431745db510  push r11
00007431745db512  sub rsp, 0xF0
00007431745db519  vmovaps [rsp], xmm0
00007431745db51e  vmovaps [rsp+0x10], xmm1
00007431745db524  vmovaps [rsp+0x20], xmm2
00007431745db52a  vmovaps [rsp+0x30], xmm3
00007431745db530  vmovaps [rsp+0x40], xmm4
00007431745db536  vmovaps [rsp+0x50], xmm5
00007431745db53c  vmovaps [rsp+0x60], xmm6
00007431745db542  vmovaps [rsp+0x70], xmm7
00007431745db548  vmovaps [rsp+0x80], xmm8
00007431745db551  vmovaps [rsp+0x90], xmm9
00007431745db55a  vmovaps [rsp+0xA0], xmm10
00007431745db563  vmovaps [rsp+0xB0], xmm11
00007431745db56c  vmovaps [rsp+0xC0], xmm12
00007431745db575  vmovaps [rsp+0xD0], xmm14
00007431745db57e  vmovaps [rsp+0xE0], xmm15
00007431745db587  sub rsp, 0x30
00007431745db58b  movaps [rsp], xmm13
00007431745db590  movaps [rsp+0x10], xmm10
00007431745db596  movaps [rsp+0x20], xmm14
00007431745db59c  lea rdi, [rsp]
00007431745db5a0  mov esi, 0x00
00007431745db5a5  mov rax, 0x56C40959E530
00007431745db5af  call rax
00007431745db5b1  movaps xmm13, [rsp]
00007431745db5b6  add rsp, 0x30
00007431745db5ba  vmovaps xmm0, [rsp]
00007431745db5bf  vmovaps xmm1, [rsp+0x10]
00007431745db5c5  vmovaps xmm2, [rsp+0x20]
00007431745db5cb  vmovaps xmm3, [rsp+0x30]
00007431745db5d1  vmovaps xmm4, [rsp+0x40]
00007431745db5d7  vmovaps xmm5, [rsp+0x50]
00007431745db5dd  vmovaps xmm6, [rsp+0x60]
00007431745db5e3  vmovaps xmm7, [rsp+0x70]
00007431745db5e9  vmovaps xmm8, [rsp+0x80]
00007431745db5f2  vmovaps xmm9, [rsp+0x90]
00007431745db5fb  vmovaps xmm10, [rsp+0xA0]
00007431745db604  vmovaps xmm11, [rsp+0xB0]
00007431745db60d  vmovaps xmm12, [rsp+0xC0]
00007431745db616  vmovaps xmm14, [rsp+0xD0]
00007431745db61f  vmovaps xmm15, [rsp+0xE0]
00007431745db628  add rsp, 0xF0
00007431745db62f  pop r11
00007431745db631  pop r10
00007431745db633  pop r9
00007431745db635  pop r8
00007431745db637  pop rsi
00007431745db638  pop rdi
00007431745db639  pop rdx
00007431745db63a  pop rcx
00007431745db63b  pop rax
00007431745db63c  add rsp, 0x08
00007431745db640  jmp 0x00007431745D666D
00007431745db645  sub rsp, 0x08
00007431745db649  push rax
00007431745db64a  push rcx
00007431745db64b  push rdx
00007431745db64c  push rdi
00007431745db64d  push rsi
00007431745db64e  push r8
00007431745db650  push r9
00007431745db652  push r10
00007431745db654  push r11
00007431745db656  sub rsp, 0xF0
00007431745db65d  vmovaps [rsp], xmm0
00007431745db662  vmovaps [rsp+0x10], xmm1
00007431745db668  vmovaps [rsp+0x20], xmm2
00007431745db66e  vmovaps [rsp+0x30], xmm3
00007431745db674  vmovaps [rsp+0x40], xmm4
00007431745db67a  vmovaps [rsp+0x50], xmm5
00007431745db680  vmovaps [rsp+0x60], xmm6
00007431745db686  vmovaps [rsp+0x70], xmm7
00007431745db68c  vmovaps [rsp+0x80], xmm8
00007431745db695  vmovaps [rsp+0x90], xmm9
00007431745db69e  vmovaps [rsp+0xA0], xmm10
00007431745db6a7  vmovaps [rsp+0xB0], xmm11
00007431745db6b0  vmovaps [rsp+0xC0], xmm12
00007431745db6b9  vmovaps [rsp+0xD0], xmm13
00007431745db6c2  vmovaps [rsp+0xE0], xmm15
00007431745db6cb  sub rsp, 0x30
00007431745db6cf  movaps [rsp], xmm14
00007431745db6d4  movaps [rsp+0x10], xmm1
00007431745db6d9  movaps [rsp+0x20], xmm7
00007431745db6de  lea rdi, [rsp]
00007431745db6e2  mov esi, 0x00
00007431745db6e7  mov rax, 0x56C40959E530
00007431745db6f1  call rax
00007431745db6f3  movaps xmm14, [rsp]
00007431745db6f8  add rsp, 0x30
00007431745db6fc  vmovaps xmm0, [rsp]
00007431745db701  vmovaps xmm1, [rsp+0x10]
00007431745db707  vmovaps xmm2, [rsp+0x20]
00007431745db70d  vmovaps xmm3, [rsp+0x30]
00007431745db713  vmovaps xmm4, [rsp+0x40]
00007431745db719  vmovaps xmm5, [rsp+0x50]
00007431745db71f  vmovaps xmm6, [rsp+0x60]
00007431745db725  vmovaps xmm7, [rsp+0x70]
00007431745db72b  vmovaps xmm8, [rsp+0x80]
00007431745db734  vmovaps xmm9, [rsp+0x90]
00007431745db73d  vmovaps xmm10, [rsp+0xA0]
00007431745db746  vmovaps xmm11, [rsp+0xB0]
00007431745db74f  vmovaps xmm12, [rsp+0xC0]
00007431745db758  vmovaps xmm13, [rsp+0xD0]
00007431745db761  vmovaps xmm15, [rsp+0xE0]
00007431745db76a  add rsp, 0xF0
00007431745db771  pop r11
00007431745db773  pop r10
00007431745db775  pop r9
00007431745db777  pop r8
00007431745db779  pop rsi
00007431745db77a  pop rdi
00007431745db77b  pop rdx
00007431745db77c  pop rcx
00007431745db77d  pop rax
00007431745db77e  add rsp, 0x08
00007431745db782  jmp 0x00007431745D6690
00007431745db787  sub rsp, 0x08
00007431745db78b  push rax
00007431745db78c  push rcx
00007431745db78d  push rdx
00007431745db78e  push rdi
00007431745db78f  push rsi
00007431745db790  push r8
00007431745db792  push r9
00007431745db794  push r10
00007431745db796  push r11
00007431745db798  sub rsp, 0xF0
00007431745db79f  vmovaps [rsp], xmm0
00007431745db7a4  vmovaps [rsp+0x10], xmm2
00007431745db7aa  vmovaps [rsp+0x20], xmm3
00007431745db7b0  vmovaps [rsp+0x30], xmm4
00007431745db7b6  vmovaps [rsp+0x40], xmm5
00007431745db7bc  vmovaps [rsp+0x50], xmm6
00007431745db7c2  vmovaps [rsp+0x60], xmm7
00007431745db7c8  vmovaps [rsp+0x70], xmm8
00007431745db7ce  vmovaps [rsp+0x80], xmm9
00007431745db7d7  vmovaps [rsp+0x90], xmm10
00007431745db7e0  vmovaps [rsp+0xA0], xmm11
00007431745db7e9  vmovaps [rsp+0xB0], xmm12
00007431745db7f2  vmovaps [rsp+0xC0], xmm13
00007431745db7fb  vmovaps [rsp+0xD0], xmm14
00007431745db804  vmovaps [rsp+0xE0], xmm15
00007431745db80d  sub rsp, 0x30
00007431745db811  movaps [rsp], xmm1
00007431745db815  movaps [rsp+0x10], xmm8
00007431745db81b  movaps [rsp+0x20], xmm9
00007431745db821  lea rdi, [rsp]
00007431745db825  mov esi, 0x00
00007431745db82a  mov rax, 0x56C40959E530
00007431745db834  call rax
00007431745db836  movaps xmm1, [rsp]
00007431745db83a  add rsp, 0x30
00007431745db83e  vmovaps xmm0, [rsp]
00007431745db843  vmovaps xmm2, [rsp+0x10]
00007431745db849  vmovaps xmm3, [rsp+0x20]
00007431745db84f  vmovaps xmm4, [rsp+0x30]
00007431745db855  vmovaps xmm5, [rsp+0x40]
00007431745db85b  vmovaps xmm6, [rsp+0x50]
00007431745db861  vmovaps xmm7, [rsp+0x60]
00007431745db867  vmovaps xmm8, [rsp+0x70]
00007431745db86d  vmovaps xmm9, [rsp+0x80]
00007431745db876  vmovaps xmm10, [rsp+0x90]
00007431745db87f  vmovaps xmm11, [rsp+0xA0]
00007431745db888  vmovaps xmm12, [rsp+0xB0]
00007431745db891  vmovaps xmm13, [rsp+0xC0]
00007431745db89a  vmovaps xmm14, [rsp+0xD0]
00007431745db8a3  vmovaps xmm15, [rsp+0xE0]
00007431745db8ac  add rsp, 0xF0
00007431745db8b3  pop r11
00007431745db8b5  pop r10
00007431745db8b7  pop r9
00007431745db8b9  pop r8
00007431745db8bb  pop rsi
00007431745db8bc  pop rdi
00007431745db8bd  pop rdx
00007431745db8be  pop rcx
00007431745db8bf  pop rax
00007431745db8c0  add rsp, 0x08
00007431745db8c4  jmp 0x00007431745D66B2
00007431745db8c9  call 0x00007431744B3E40
00007431745db8ce  jmp 0x00007431745D66C0
00007431745db8d3  call 0x000074317440C380
00007431745db8d8  jmp 0x00007431745D66CA
00007431745db8dd  call 0x000074317440D600
00007431745db8e2  jmp 0x00007431745D66D4
00007431745db8e7  call 0x00007431743FF540
00007431745db8ec  jmp 0x00007431745D66DE
00007431745db8f1  int3
00007431745db8f2  nop [rax+rax*1], ax
00007431745db8fb  nop [rax+rax*1], eax
00007431745db900  mov eax, [r15+0x48]
00007431745db904  lea r14d, [eax+0x01]
00007431745db909  mov [rsp+0x10], r14d
00007431745db90e  mov r14d, r14d
00007431745db911  mov [r15+0x48], r14
00007431745db915  xor eax, eax
00007431745db917  mov r14d, [rsp+0x10]
00007431745db91c  cmp r14d, 0x1F4
00007431745db923  cmc
00007431745db924  lahf
00007431745db925  seto al
00007431745db928  mov [r15+0x108], eax
00007431745db92f  mov eax, [r15+0x108]
00007431745db936  sahf
00007431745db937  jnz 0x00007431745DB969
00007431745db939  cmp dword ptr [r15+0x318], 0x00
00007431745db941  jz 0x00007431745E1AB0
00007431745db947  nop [rax+rax*1], ax
00007431745db950  nop [rax+rax*1], eax
00007431745db958  mov eax, 0x410450
00007431745db95d  mov [r15+0x100], rax
00007431745db964  jmp 0x00007431743FE110
00007431745db969  cmp dword ptr [r15+0x318], 0x00
00007431745db971  jz 0x00007431745DB9A0
00007431745db977  nop [rax+rax*1], ax
00007431745db980  nop [rax+rax*1], eax
00007431745db988  mov eax, 0x410274
00007431745db98d  mov [r15+0x100], rax
00007431745db994  jmp 0x00007431743FE110
00007431745db999  int3
00007431745db99a  int3
00007431745db99b  nop [rax+rax*1], eax
00007431745db9a0  mov rax, [r15+0x40]
00007431745db9a4  movaps xmm1, [r15+0x1D0]
00007431745db9ac  vmovaps [rsp+0x10], xmm1
00007431745db9b2  vmovaps xmm15, [rsp+0x10]
00007431745db9b8  por xmm1, xmm15
00007431745db9bd  movaps xmm14, [r15+0x1A0]
00007431745db9c5  vmovaps [rsp+0x10], xmm14
00007431745db9cb  vmovaps xmm13, [rsp+0x10]
00007431745db9d1  por xmm14, xmm13
00007431745db9d6  lea r14, [rax+0x30]
00007431745db9da  mov r12, [r13+r14*1]
00007431745db9df  lea r14, [rax+0x38]
00007431745db9e3  mov r11, [r13+r14*1]
00007431745db9e8  movq xmm13, r12
00007431745db9ed  movq xmm12, r11
00007431745db9f2  movq xmm13, xmm13
00007431745db9f7  vmovaps [rsp+0x10], xmm13
00007431745db9fd  movq xmm13, xmm13
00007431745dba02  movaps [r15+0x130], xmm13
00007431745dba0a  movq xmm12, xmm12
00007431745dba0f  vmovaps [rsp+0x20], xmm12
00007431745dba15  movq xmm12, xmm12
00007431745dba1a  movaps [r15+0x280], xmm12
00007431745dba22  movaps xmm13, [r15+0x270]
00007431745dba2a  vmovaps [rsp+0x30], xmm13
00007431745dba30  vmovaps xmm12, [rsp+0x30]
00007431745dba36  por xmm13, xmm12
00007431745dba3b  lea r14, [rax+0x20]
00007431745dba3f  mov r12, [r13+r14*1]
00007431745dba44  lea r14, [rax+0x28]
00007431745dba48  mov r11, [r13+r14*1]
00007431745dba4d  movq xmm12, r12
00007431745dba52  movq xmm11, r11
00007431745dba57  movq xmm12, xmm12
00007431745dba5c  vmovaps [rsp+0x30], xmm12
00007431745dba62  movq xmm12, xmm12
00007431745dba67  movaps [r15+0x150], xmm12
00007431745dba6f  movq xmm11, xmm11
00007431745dba74  vmovaps [rsp+0x40], xmm11
00007431745dba7a  movq xmm11, xmm11
00007431745dba7f  movaps [r15+0x140], xmm11
00007431745dba87  lea r14, [rax+0x10]
00007431745dba8b  mov r12, [r13+r14*1]
00007431745dba90  lea r14, [rax+0x18]
00007431745dba94  mov r11, [r13+r14*1]
00007431745dba99  movq xmm12, r12
00007431745dba9e  movq xmm11, r11
00007431745dbaa3  movq xmm12, xmm12
00007431745dbaa8  vmovaps [rsp+0x50], xmm12
00007431745dbaae  movq xmm12, xmm12
00007431745dbab3  movaps [r15+0x170], xmm12
00007431745dbabb  movq xmm11, xmm11
00007431745dbac0  vmovaps [rsp+0x60], xmm11
00007431745dbac6  movq xmm11, xmm11
00007431745dbacb  movaps [r15+0x160], xmm11
00007431745dbad3  mov r14, [r13+rax*1]
00007431745dbad8  vmovq xmm12, r14
00007431745dbadd  vpbroadcastq xmm12, xmm12
00007431745dbae2  lea r14, [rax+0x08]
00007431745dbae6  mov rax, [r13+r14*1]
00007431745dbaeb  movq xmm11, rax
00007431745dbaf0  movaps [r15+0x230], xmm11
00007431745dbaf8  mov rax, [r15+0xF8]
00007431745dbaff  lea r14, [rax+0x50]
00007431745dbb03  movups xmm11, [r13+r14*1]
00007431745dbb09  lea r14, [rax+0x60]
00007431745dbb0d  movups xmm10, [r13+r14*1]
00007431745dbb13  lea r14, [rax+0x30]
00007431745dbb17  movups xmm9, [r13+r14*1]
00007431745dbb1d  mov r14, [r15+0x50]
00007431745dbb21  mov [r15+0x60], r14
00007431745dbb25  mov qword ptr [r15+0x58], 0x40
00007431745dbb2d  movaps xmm8, xmm12
00007431745dbb31  mulpd xmm8, xmm15
00007431745dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007431745dbb3c  ptest xmm7, xmm7
00007431745dbb41  jnz 0x00007431745DC96A
00007431745dbb47  movq xmm15, qword ptr [r15+0x230]
00007431745dbb50  vmovaps [rsp+0x70], xmm15
00007431745dbb56  vpermilpd xmm15, xmm15, 0x00
00007431745dbb5c  movaps xmm7, xmm9
00007431745dbb60  mulpd xmm7, xmm15
00007431745dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007431745dbb6a  ptest xmm6, xmm6
00007431745dbb6f  jnz 0x00007431745DCAAE
00007431745dbb75  vxorps xmm15, xmm15, xmm15
00007431745dbb7a  vpbroadcastq xmm15, xmm15
00007431745dbb7f  movaps xmm9, xmm12
00007431745dbb83  mulpd xmm9, xmm10
00007431745dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007431745dbb8e  ptest xmm6, xmm6
00007431745dbb93  jnz 0x00007431745DCBF0
00007431745dbb99  movaps xmm10, xmm12
00007431745dbb9d  mulpd xmm10, xmm11
00007431745dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007431745dbba8  ptest xmm6, xmm6
00007431745dbbad  jnz 0x00007431745DCD34
00007431745dbbb3  movaps xmm11, [r15+0x1F0]
00007431745dbbbb  movaps xmm6, xmm12
00007431745dbbbf  mulpd xmm6, xmm11
00007431745dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007431745dbbc9  ptest xmm5, xmm5
00007431745dbbce  jnz 0x00007431745DCE78
00007431745dbbd4  movaps xmm12, [r15+0x2A0]
00007431745dbbdc  vmovaps [rsp+0x80], xmm12
00007431745dbbe5  vmovaps xmm11, [rsp+0x80]
00007431745dbbee  por xmm12, xmm11
00007431745dbbf3  movaps xmm11, [r15+0x250]
00007431745dbbfb  vmovaps [rsp+0x80], xmm11
00007431745dbc04  vmovaps xmm5, [rsp+0x80]
00007431745dbc0d  por xmm11, xmm5
00007431745dbc12  vmovaps xmm4, [rsp+0x70]
00007431745dbc18  vpermilpd xmm4, xmm4, 0x00
00007431745dbc1e  movaps xmm3, xmm5
00007431745dbc21  mulpd xmm3, xmm4
00007431745dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007431745dbc2a  ptest xmm2, xmm2
00007431745dbc2f  jnz 0x00007431745DCFBA
00007431745dbc35  mov [rsp+0x80], rax
00007431745dbc3d  xor eax, eax
00007431745dbc3f  mov r12d, 0x40
00007431745dbc45  mov r11d, 0x200
00007431745dbc4b  cmp r12, r11
00007431745dbc4e  cmc
00007431745dbc4f  lahf
00007431745dbc50  seto al
00007431745dbc53  mov [r15+0x108], eax
00007431745dbc5a  movaps xmm5, xmm8
00007431745dbc5e  addpd xmm5, xmm15
00007431745dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007431745dbc68  ptest xmm4, xmm4
00007431745dbc6d  jnz 0x00007431745DD0FA
00007431745dbc73  movaps xmm8, [r15+0x1B0]
00007431745dbc7b  movaps xmm4, xmm9
00007431745dbc7f  addpd xmm4, xmm8
00007431745dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007431745dbc89  ptest xmm2, xmm2
00007431745dbc8e  jnz 0x00007431745DD23C
00007431745dbc94  movaps xmm9, xmm10
00007431745dbc98  addpd xmm9, xmm8
00007431745dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007431745dbca3  ptest xmm2, xmm2
00007431745dbca8  jnz 0x00007431745DD37E
00007431745dbcae  movaps xmm10, [r15+0x2F0]
00007431745dbcb6  vmovaps [rsp+0x90], xmm10
00007431745dbcbf  vmovaps xmm8, [rsp+0x90]
00007431745dbcc8  por xmm10, xmm8
00007431745dbccd  movaps xmm8, [r15+0x2E0]
00007431745dbcd5  vmovaps [rsp+0x90], xmm8
00007431745dbcde  vmovaps xmm2, [rsp+0x90]
00007431745dbce7  por xmm8, xmm2
00007431745dbcec  movaps xmm2, [r15+0x2D0]
00007431745dbcf4  vmovaps [rsp+0x90], xmm2
00007431745dbcfd  vmovaps [rsp+0xA0], xmm1
00007431745dbd06  vmovaps xmm1, [rsp+0x90]
00007431745dbd0f  por xmm2, xmm1
00007431745dbd13  movaps xmm1, [r15+0x200]
00007431745dbd1b  vmovaps [rsp+0x90], xmm1
00007431745dbd24  vmovaps [rsp+0xB0], xmm15
00007431745dbd2d  vmovaps xmm15, [rsp+0x90]
00007431745dbd36  por xmm1, xmm15
00007431745dbd3b  movaps xmm15, [r15+0x1C0]
00007431745dbd43  vmovaps [rsp+0x90], xmm15
00007431745dbd4c  vmovaps [rsp+0xC0], xmm1
00007431745dbd55  vmovaps xmm1, [rsp+0x90]
00007431745dbd5e  por xmm15, xmm1
00007431745dbd63  movaps xmm1, [r15+0x190]
00007431745dbd6b  vmovaps [rsp+0x90], xmm1
00007431745dbd74  vmovaps [rsp+0xD0], xmm15
00007431745dbd7d  vmovaps xmm15, [rsp+0x90]
00007431745dbd86  por xmm1, xmm15
00007431745dbd8b  movaps xmm15, [r15+0x300]
00007431745dbd93  vmovaps [rsp+0x90], xmm15
00007431745dbd9c  vmovaps [rsp+0xE0], xmm1
00007431745dbda5  vmovaps xmm1, [rsp+0x90]
00007431745dbdae  por xmm15, xmm1
00007431745dbdb3  mov rax, [rsp+0x80]
00007431745dbdbb  lea r12, [rax+0xA0]
00007431745dbdc2  movups xmm1, [r13+r12*1]
00007431745dbdc8  lea r12, [rax+0xB0]
00007431745dbdcf  vmovaps [rsp+0x80], xmm1
00007431745dbdd8  movups xmm1, [r13+r12*1]
00007431745dbdde  vmovaps [rsp+0x90], xmm1
00007431745dbde7  vmovaps [rsp+0xF0], xmm15
00007431745dbdf0  vmovaps xmm15, [rsp+0xB0]
00007431745dbdf9  vmovaps [rsp+0xB0], xmm14
00007431745dbe02  movaps xmm1, xmm6
00007431745dbe05  addpd xmm1, xmm15
00007431745dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007431745dbe0f  ptest xmm14, xmm14
00007431745dbe15  jnz 0x00007431745DD4D6
00007431745dbe1b  lea r12, [rax+0xF0]
00007431745dbe22  movups xmm15, [r13+r12*1]
00007431745dbe28  movaps xmm14, xmm4
00007431745dbe2c  addpd xmm14, xmm3
00007431745dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007431745dbe37  ptest xmm6, xmm6
00007431745dbe3c  jnz 0x00007431745DD621
00007431745dbe42  movaps xmm6, xmm9
00007431745dbe46  addpd xmm6, xmm7
00007431745dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007431745dbe4f  ptest xmm4, xmm4
00007431745dbe54  jnz 0x00007431745DD763
00007431745dbe5a  vmovaps xmm9, [rsp+0x70]
00007431745dbe60  vpermilpd xmm9, xmm9, 0x00
00007431745dbe66  vmovaps xmm4, [rsp+0x90]
00007431745dbe6f  movaps xmm7, xmm4
00007431745dbe72  mulpd xmm7, xmm9
00007431745dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007431745dbe7c  ptest xmm3, xmm3
00007431745dbe81  jnz 0x00007431745DD8A4
00007431745dbe87  vmovaps xmm9, [rsp+0x50]
00007431745dbe8d  vpermilpd xmm9, xmm9, 0x00
00007431745dbe93  movaps xmm4, xmm15
00007431745dbe97  mulpd xmm4, xmm9
00007431745dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007431745dbea1  ptest xmm3, xmm3
00007431745dbea6  jnz 0x00007431745DD9E5
00007431745dbeac  lea r12, [rax+0xE0]
00007431745dbeb3  movups xmm15, [r13+r12*1]
00007431745dbeb9  vmovaps xmm9, [rsp+0x70]
00007431745dbebf  vpermilpd xmm9, xmm9, 0x00
00007431745dbec5  vmovaps [rsp+0x70], xmm1
00007431745dbecb  vmovaps xmm1, [rsp+0x80]
00007431745dbed4  vmovaps [rsp+0x80], xmm15
00007431745dbedd  movaps xmm3, xmm1
00007431745dbee0  mulpd xmm3, xmm9
00007431745dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007431745dbeea  ptest xmm15, xmm15
00007431745dbef0  jnz 0x00007431745DDB31
00007431745dbef6  vmovaps xmm1, [rsp+0xF0]
00007431745dbeff  vmovaps xmm15, [rsp+0xF0]
00007431745dbf08  por xmm1, xmm15
00007431745dbf0d  movaps [r15+0x300], xmm1
00007431745dbf15  vmovaps xmm15, [rsp+0xE0]
00007431745dbf1e  vmovaps xmm9, [rsp+0xE0]
00007431745dbf27  por xmm15, xmm9
00007431745dbf2c  movaps [r15+0x190], xmm15
00007431745dbf34  vmovaps xmm9, [rsp+0x50]
00007431745dbf3a  vpermilpd xmm9, xmm9, 0x00
00007431745dbf40  vmovaps [rsp+0x90], xmm1
00007431745dbf49  vmovaps [rsp+0xE0], xmm15
00007431745dbf52  vmovaps xmm15, [rsp+0x80]
00007431745dbf5b  vmovaps [rsp+0x80], xmm14
00007431745dbf64  movaps xmm1, xmm15
00007431745dbf68  mulpd xmm1, xmm9
00007431745dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007431745dbf72  ptest xmm14, xmm14
00007431745dbf78  jnz 0x00007431745DDC72
00007431745dbf7e  lea r12, [rax+0x90]
00007431745dbf85  movups xmm15, [r13+r12*1]
00007431745dbf8b  vmovaps xmm14, [rsp+0xD0]
00007431745dbf94  vmovaps xmm9, [rsp+0xD0]
00007431745dbf9d  por xmm14, xmm9
00007431745dbfa2  movaps [r15+0x1C0], xmm14
00007431745dbfaa  vmovaps xmm9, [rsp+0xC0]
00007431745dbfb3  vmovaps [rsp+0xD0], xmm1
00007431745dbfbc  vmovaps xmm1, [rsp+0xC0]
00007431745dbfc5  por xmm9, xmm1
00007431745dbfca  movaps [r15+0x200], xmm9
00007431745dbfd2  vmovaps [rsp+0xC0], xmm2
00007431745dbfdb  vmovaps xmm1, [rsp+0xC0]
00007431745dbfe4  por xmm2, xmm1
00007431745dbfe8  movaps [r15+0x2D0], xmm2
00007431745dbff0  vmovaps [rsp+0xC0], xmm8
00007431745dbff9  vmovaps xmm1, [rsp+0xC0]
00007431745dc002  por xmm8, xmm1
00007431745dc007  movaps [r15+0x2E0], xmm8
00007431745dc00f  vmovaps [rsp+0xC0], xmm15
00007431745dc018  movaps xmm1, xmm5
00007431745dc01b  addpd xmm1, xmm7
00007431745dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007431745dc024  ptest xmm15, xmm15
00007431745dc02a  jnz 0x00007431745DDDBE
00007431745dc030  vmovaps xmm15, [rsp+0x50]
00007431745dc036  vpermilpd xmm15, xmm15, 0x00
00007431745dc03c  vmovaps xmm5, [rsp+0xC0]
00007431745dc045  vmovaps [rsp+0xC0], xmm1
00007431745dc04e  movaps xmm7, xmm5
00007431745dc051  mulpd xmm7, xmm15
00007431745dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007431745dc05b  ptest xmm1, xmm1
00007431745dc060  jnz 0x00007431745DDEFE
00007431745dc066  lea r12, [rax+0x80]
00007431745dc06d  movups xmm1, [r13+r12*1]
00007431745dc073  vmovaps xmm5, [rsp+0x70]
00007431745dc079  vmovaps [rsp+0x70], xmm1
00007431745dc07f  movaps xmm15, xmm5
00007431745dc083  addpd xmm15, xmm3
00007431745dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007431745dc08e  ptest xmm1, xmm1
00007431745dc093  jnz 0x00007431745DE049
00007431745dc099  vmovaps xmm5, [rsp+0x80]
00007431745dc0a2  movaps xmm1, xmm5
00007431745dc0a5  addpd xmm1, xmm4
00007431745dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007431745dc0ae  ptest xmm3, xmm3
00007431745dc0b3  jnz 0x00007431745DE18B
00007431745dc0b9  vmovaps [rsp+0x80], xmm10
00007431745dc0c2  vmovaps xmm5, [rsp+0x80]
00007431745dc0cb  por xmm10, xmm5
00007431745dc0d0  movaps [r15+0x2F0], xmm10
00007431745dc0d8  vmovaps xmm5, [rsp+0x50]
00007431745dc0de  vpermilpd xmm5, xmm5, 0x00
00007431745dc0e4  vmovaps xmm3, [rsp+0x70]
00007431745dc0ea  vmovaps [rsp+0x50], xmm1
00007431745dc0f0  movaps xmm4, xmm3
00007431745dc0f3  mulpd xmm4, xmm5
00007431745dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007431745dc0fc  ptest xmm1, xmm1
00007431745dc101  jnz 0x00007431745DE2CB
00007431745dc107  lea r12, [rax+0xD0]
00007431745dc10e  movups xmm1, [r13+r12*1]
00007431745dc114  vmovaps xmm3, [rsp+0xD0]
00007431745dc11d  vmovaps [rsp+0x70], xmm1
00007431745dc123  movaps xmm5, xmm6
00007431745dc126  addpd xmm5, xmm3
00007431745dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007431745dc12f  ptest xmm1, xmm1
00007431745dc134  jnz 0x00007431745DE415
00007431745dc13a  vmovaps xmm1, [rsp+0x60]
00007431745dc140  vpermilpd xmm1, xmm1, 0x00
00007431745dc146  movaps xmm6, xmm9
00007431745dc14a  mulpd xmm6, xmm1
00007431745dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007431745dc153  ptest xmm3, xmm3
00007431745dc158  jnz 0x00007431745DE555
00007431745dc15e  movaps [r15+0x260], xmm6
00007431745dc166  vxorps xmm1, xmm1, xmm1
00007431745dc16a  vpbroadcastq xmm1, xmm1
00007431745dc16f  movaps [r15+0x1B0], xmm1
00007431745dc177  vmovaps xmm1, [rsp+0x60]
00007431745dc17d  vpermilpd xmm1, xmm1, 0x00
00007431745dc183  vmovaps xmm3, [rsp+0x70]
00007431745dc189  vmovaps [rsp+0x70], xmm15
00007431745dc18f  movaps xmm9, xmm3
00007431745dc193  mulpd xmm9, xmm1
00007431745dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007431745dc19e  ptest xmm15, xmm15
00007431745dc1a4  jnz 0x00007431745DE696
00007431745dc1aa  lea r12, [rax+0xC0]
00007431745dc1b1  movups xmm1, [r13+r12*1]
00007431745dc1b7  vmovaps xmm3, [rsp+0xC0]
00007431745dc1c0  vmovaps [rsp+0x80], xmm1
00007431745dc1c9  movaps xmm15, xmm3
00007431745dc1cd  addpd xmm15, xmm7
00007431745dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007431745dc1d8  ptest xmm1, xmm1
00007431745dc1dd  jnz 0x00007431745DE7E2
00007431745dc1e3  vmovaps [rsp+0xC0], xmm13
00007431745dc1ec  vmovaps xmm1, [rsp+0xC0]
00007431745dc1f5  por xmm13, xmm1
00007431745dc1fa  movaps [r15+0x270], xmm13
00007431745dc202  vmovaps xmm1, [rsp+0xB0]
00007431745dc20b  vmovaps xmm7, [rsp+0xB0]
00007431745dc214  por xmm1, xmm7
00007431745dc218  movaps [r15+0x1A0], xmm1
00007431745dc220  vmovaps xmm1, [rsp+0x60]
00007431745dc226  vpermilpd xmm1, xmm1, 0x00
00007431745dc22c  vmovaps [rsp+0xB0], xmm1
00007431745dc235  vmovaps xmm1, [rsp+0x80]
00007431745dc23e  vmovaps [rsp+0x80], xmm15
00007431745dc247  vmovaps xmm15, [rsp+0xB0]
00007431745dc250  vmovaps [rsp+0xB0], xmm14
00007431745dc259  movaps xmm3, xmm1
00007431745dc25c  mulpd xmm3, xmm15
00007431745dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007431745dc266  ptest xmm14, xmm14
00007431745dc26c  jnz 0x00007431745DE924
00007431745dc272  lea r12, [rax+0x20]
00007431745dc276  movups xmm1, [r13+r12*1]
00007431745dc27c  movaps [r15+0x110], xmm1
00007431745dc284  vmovaps xmm14, [rsp+0x70]
00007431745dc28a  vmovaps [rsp+0x70], xmm1
00007431745dc290  movaps xmm15, xmm14
00007431745dc294  addpd xmm15, xmm4
00007431745dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007431745dc29f  ptest xmm1, xmm1
00007431745dc2a4  jnz 0x00007431745DEA6F
00007431745dc2aa  vmovaps xmm1, [rsp+0x60]
00007431745dc2b0  vpermilpd xmm1, xmm1, 0x00
00007431745dc2b6  movaps xmm14, xmm2
00007431745dc2ba  mulpd xmm14, xmm1
00007431745dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007431745dc2c5  ptest xmm4, xmm4
00007431745dc2ca  jnz 0x00007431745DEBB2
00007431745dc2d0  vmovaps xmm4, [rsp+0x50]
00007431745dc2d6  movaps xmm1, xmm4
00007431745dc2d9  addpd xmm1, xmm9
00007431745dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007431745dc2e3  ptest xmm2, xmm2
00007431745dc2e8  jnz 0x00007431745DECF4
00007431745dc2ee  vmovaps xmm9, [rsp+0x30]
00007431745dc2f4  vpermilpd xmm9, xmm9, 0x00
00007431745dc2fa  vmovaps xmm2, [rsp+0x70]
00007431745dc300  vmovaps [rsp+0x50], xmm1
00007431745dc306  movaps xmm4, xmm2
00007431745dc309  mulpd xmm4, xmm9
00007431745dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007431745dc313  ptest xmm1, xmm1
00007431745dc318  jnz 0x00007431745DEE35
00007431745dc31e  vmovaps xmm1, [rsp+0x30]
00007431745dc324  vpermilpd xmm1, xmm1, 0x00
00007431745dc32a  vmovaps xmm2, [rsp+0x90]
00007431745dc333  vmovaps [rsp+0x60], xmm15
00007431745dc339  movaps xmm9, xmm2
00007431745dc33d  mulpd xmm9, xmm1
00007431745dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007431745dc348  ptest xmm15, xmm15
00007431745dc34e  jnz 0x00007431745DEF76
00007431745dc354  vmovaps xmm15, [rsp+0x80]
00007431745dc35d  movaps xmm1, xmm15
00007431745dc361  addpd xmm1, xmm6
00007431745dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007431745dc36a  ptest xmm2, xmm2
00007431745dc36f  jnz 0x00007431745DF0B8
00007431745dc375  movaps xmm15, xmm5
00007431745dc379  addpd xmm15, xmm3
00007431745dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007431745dc384  ptest xmm6, xmm6
00007431745dc389  jnz 0x00007431745DF1F9
00007431745dc38f  vmovaps xmm6, [rsp+0x30]
00007431745dc395  vpermilpd xmm6, xmm6, 0x00
00007431745dc39b  movaps xmm5, xmm8
00007431745dc39f  mulpd xmm5, xmm6
00007431745dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007431745dc3a8  ptest xmm3, xmm3
00007431745dc3ad  jnz 0x00007431745DF33B
00007431745dc3b3  vmovaps xmm8, [rsp+0x30]
00007431745dc3b9  vpermilpd xmm8, xmm8, 0x00
00007431745dc3bf  movaps xmm6, xmm10
00007431745dc3c3  mulpd xmm6, xmm8
00007431745dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007431745dc3cd  ptest xmm3, xmm3
00007431745dc3d2  jnz 0x00007431745DF47C
00007431745dc3d8  vmovaps xmm8, [rsp+0x60]
00007431745dc3de  movaps xmm10, xmm8
00007431745dc3e2  addpd xmm10, xmm14
00007431745dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007431745dc3ed  ptest xmm3, xmm3
00007431745dc3f2  jnz 0x00007431745DF5BE
00007431745dc3f8  vmovaps xmm8, [rsp+0x50]
00007431745dc3fe  movaps xmm14, xmm8
00007431745dc402  addpd xmm14, xmm4
00007431745dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007431745dc40d  ptest xmm3, xmm3
00007431745dc412  jnz 0x00007431745DF702
00007431745dc418  vmovaps xmm8, [rsp+0x40]
00007431745dc41e  vpermilpd xmm8, xmm8, 0x00
00007431745dc424  movaps xmm4, xmm13
00007431745dc428  mulpd xmm4, xmm8
00007431745dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007431745dc432  ptest xmm3, xmm3
00007431745dc437  jnz 0x00007431745DF845
00007431745dc43d  movaps xmm13, xmm15
00007431745dc441  addpd xmm13, xmm9
00007431745dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007431745dc44c  ptest xmm8, xmm8
00007431745dc452  jnz 0x00007431745DF987
00007431745dc458  movaps xmm15, xmm1
00007431745dc45c  addpd xmm15, xmm5
00007431745dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007431745dc467  ptest xmm9, xmm9
00007431745dc46d  jnz 0x00007431745DFACB
00007431745dc473  vmovaps [rsp+0x30], xmm11
00007431745dc479  vmovaps xmm1, [rsp+0x30]
00007431745dc47f  por xmm11, xmm1
00007431745dc484  movaps [r15+0x250], xmm11
00007431745dc48c  vmovaps [rsp+0x30], xmm12
00007431745dc492  vmovaps xmm1, [rsp+0x30]
00007431745dc498  por xmm12, xmm1
00007431745dc49d  movaps [r15+0x2A0], xmm12
00007431745dc4a5  vmovaps xmm1, [rsp+0xA0]
00007431745dc4ae  vmovaps xmm11, [rsp+0xA0]
00007431745dc4b7  por xmm1, xmm11
00007431745dc4bc  movaps [r15+0x1D0], xmm1
00007431745dc4c4  lea r12, [rax+0x40]
00007431745dc4c8  movups xmm1, [r13+r12*1]
00007431745dc4ce  movaps [r15+0x2C0], xmm1
00007431745dc4d6  vmovaps xmm11, [rsp+0x40]
00007431745dc4dc  vpermilpd xmm11, xmm11, 0x00
00007431745dc4e2  vmovaps xmm8, [rsp+0xE0]
00007431745dc4eb  movaps xmm9, xmm8
00007431745dc4ef  mulpd xmm9, xmm11
00007431745dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007431745dc4fa  ptest xmm5, xmm5
00007431745dc4ff  jnz 0x00007431745DFC17
00007431745dc505  movaps xmm11, xmm10
00007431745dc509  addpd xmm11, xmm6
00007431745dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007431745dc514  ptest xmm8, xmm8
00007431745dc51a  jnz 0x00007431745DFD5B
00007431745dc520  movaps xmm10, xmm14
00007431745dc524  addpd xmm10, xmm4
00007431745dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007431745dc52f  ptest xmm8, xmm8
00007431745dc535  jnz 0x00007431745DFE9E
00007431745dc53b  vmovaps xmm14, [rsp+0x40]
00007431745dc541  vpermilpd xmm14, xmm14, 0x00
00007431745dc547  movaps xmm8, xmm1
00007431745dc54b  mulpd xmm8, xmm14
00007431745dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007431745dc556  ptest xmm6, xmm6
00007431745dc55b  jnz 0x00007431745DFFE1
00007431745dc561  movaps xmm1, [r15+0x2B0]
00007431745dc569  vmovaps xmm14, [rsp+0x40]
00007431745dc56f  vpermilpd xmm14, xmm14, 0x00
00007431745dc575  movaps xmm6, xmm1
00007431745dc578  mulpd xmm6, xmm14
00007431745dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007431745dc582  ptest xmm5, xmm5
00007431745dc587  jnz 0x00007431745E0124
00007431745dc58d  vmovaps xmm1, [rsp+0x10]
00007431745dc593  vpermilpd xmm1, xmm1, 0x00
00007431745dc599  movaps xmm14, xmm12
00007431745dc59d  mulpd xmm14, xmm1
00007431745dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007431745dc5a8  ptest xmm5, xmm5
00007431745dc5ad  jnz 0x00007431745E0265
00007431745dc5b3  movaps xmm1, xmm13
00007431745dc5b7  addpd xmm1, xmm9
00007431745dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007431745dc5c1  ptest xmm12, xmm12
00007431745dc5c7  jnz 0x00007431745E03A8
00007431745dc5cd  vmovaps xmm13, [rsp+0x10]
00007431745dc5d3  vpermilpd xmm13, xmm13, 0x00
00007431745dc5d9  movaps xmm12, xmm7
00007431745dc5dd  mulpd xmm12, xmm13
00007431745dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007431745dc5e8  ptest xmm9, xmm9
00007431745dc5ee  jnz 0x00007431745E04EA
00007431745dc5f4  movaps xmm13, xmm15
00007431745dc5f8  addpd xmm13, xmm8
00007431745dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007431745dc603  ptest xmm9, xmm9
00007431745dc609  jnz 0x00007431745E062D
00007431745dc60f  movaps xmm15, [r15+0x290]
00007431745dc617  vmovaps xmm9, [rsp+0x10]
00007431745dc61d  vpermilpd xmm9, xmm9, 0x00
00007431745dc623  movaps xmm8, xmm15
00007431745dc627  mulpd xmm8, xmm9
00007431745dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007431745dc632  ptest xmm7, xmm7
00007431745dc637  jnz 0x00007431745E0771
00007431745dc63d  movaps xmm15, xmm11
00007431745dc641  addpd xmm15, xmm6
00007431745dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007431745dc64c  ptest xmm9, xmm9
00007431745dc652  jnz 0x00007431745E08B5
00007431745dc658  movaps xmm11, [r15+0x1E0]
00007431745dc660  vmovaps xmm9, [rsp+0x10]
00007431745dc666  vpermilpd xmm9, xmm9, 0x00
00007431745dc66c  movaps xmm7, xmm11
00007431745dc670  mulpd xmm7, xmm9
00007431745dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007431745dc67a  ptest xmm6, xmm6
00007431745dc67f  jnz 0x00007431745E09F8
00007431745dc685  movaps xmm11, xmm10
00007431745dc689  addpd xmm11, xmm14
00007431745dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007431745dc694  ptest xmm9, xmm9
00007431745dc69a  jnz 0x00007431745E0B3A
00007431745dc6a0  lea r12, [rax+0x70]
00007431745dc6a4  movups xmm14, [r13+r12*1]
00007431745dc6aa  movaps [r15+0x240], xmm14
00007431745dc6b2  movaps xmm10, xmm1
00007431745dc6b6  addpd xmm10, xmm12
00007431745dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007431745dc6c1  ptest xmm9, xmm9
00007431745dc6c7  jnz 0x00007431745E0C88
00007431745dc6cd  movaps [r15+0x170], xmm10
00007431745dc6d5  vmovaps xmm1, [rsp+0x20]
00007431745dc6db  vpermilpd xmm1, xmm1, 0x00
00007431745dc6e1  movaps xmm12, xmm14
00007431745dc6e5  mulpd xmm12, xmm1
00007431745dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007431745dc6f0  ptest xmm9, xmm9
00007431745dc6f6  jnz 0x00007431745E0DCB
00007431745dc6fc  vmovaps xmm1, [rsp+0x20]
00007431745dc702  vpermilpd xmm1, xmm1, 0x00
00007431745dc708  vmovaps xmm9, [rsp+0xB0]
00007431745dc711  movaps xmm14, xmm9
00007431745dc715  mulpd xmm14, xmm1
00007431745dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007431745dc720  ptest xmm6, xmm6
00007431745dc725  jnz 0x00007431745E0F0E
00007431745dc72b  movaps [r15+0x180], xmm14
00007431745dc733  movaps xmm1, xmm13
00007431745dc737  addpd xmm1, xmm8
00007431745dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007431745dc741  ptest xmm9, xmm9
00007431745dc747  jnz 0x00007431745E1051
00007431745dc74d  movaps [r15+0x210], xmm1
00007431745dc755  movups xmm13, [r13+rax*1]
00007431745dc75b  lea r12, [rax+0x10]
00007431745dc75f  movups xmm9, [r13+r12*1]
00007431745dc765  movaps [r15+0x230], xmm9
00007431745dc76d  movaps xmm8, xmm15
00007431745dc771  addpd xmm8, xmm7
00007431745dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007431745dc77c  ptest xmm6, xmm6
00007431745dc781  jnz 0x00007431745E11A7
00007431745dc787  movaps [r15+0x130], xmm8
00007431745dc78f  vmovaps xmm15, [rsp+0x20]
00007431745dc795  vpermilpd xmm15, xmm15, 0x00
00007431745dc79b  movaps xmm7, xmm9
00007431745dc79f  mulpd xmm7, xmm15
00007431745dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007431745dc7a9  ptest xmm6, xmm6
00007431745dc7ae  jnz 0x00007431745E12EA
00007431745dc7b4  movaps [r15+0x220], xmm7
00007431745dc7bc  vmovaps xmm15, [rsp+0x20]
00007431745dc7c2  vpermilpd xmm15, xmm15, 0x00
00007431745dc7c8  movaps xmm9, xmm13
00007431745dc7cc  mulpd xmm9, xmm15
00007431745dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007431745dc7d7  ptest xmm6, xmm6
00007431745dc7dc  jnz 0x00007431745E142C
00007431745dc7e2  movaps xmm15, xmm11
00007431745dc7e6  addpd xmm15, xmm12
00007431745dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007431745dc7f1  ptest xmm13, xmm13
00007431745dc7f7  jnz 0x00007431745E1570
00007431745dc7fd  movaps [r15+0x140], xmm15
00007431745dc805  movaps xmm13, xmm10
00007431745dc809  addpd xmm13, xmm14
00007431745dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007431745dc814  ptest xmm12, xmm12
00007431745dc81a  jnz 0x00007431745E16B4
00007431745dc820  movaps [r15+0x150], xmm13
00007431745dc828  movaps xmm14, xmm1
00007431745dc82c  addpd xmm14, xmm7
00007431745dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007431745dc837  ptest xmm12, xmm12
00007431745dc83d  jnz 0x00007431745E17F8
00007431745dc843  movaps [r15+0x160], xmm14
00007431745dc84b  movaps xmm1, xmm8
00007431745dc84f  addpd xmm1, xmm9
00007431745dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007431745dc859  ptest xmm12, xmm12
00007431745dc85f  jnz 0x00007431745E193A
00007431745dc865  movaps [r15+0x120], xmm1
00007431745dc86d  movups [r13+r14*1], xmm15
00007431745dc873  lea rax, [r14+0x10]
00007431745dc877  movups [r13+rax*1], xmm13
00007431745dc87d  lea rax, [r14+0x20]
00007431745dc881  movups [r13+rax*1], xmm14
00007431745dc887  lea rax, [r14+0x30]
00007431745dc88b  movups [r13+rax*1], xmm1
00007431745dc891  mov eax, [r15+0x108]
00007431745dc898  sahf
00007431745dc899  jnz 0x00007431745DC8CB
00007431745dc89b  cmp dword ptr [r15+0x318], 0x00
00007431745dc8a3  jz 0x00007431745DB900
00007431745dc8a9  nop [rax+rax*1], ax
00007431745dc8b2  nop [rax+rax*1], eax
00007431745dc8ba  mov eax, 0x410444
00007431745dc8bf  mov [r15+0x100], rax
00007431745dc8c6  jmp 0x00007431743FE110
00007431745dc8cb  cmp dword ptr [r15+0x318], 0x00
00007431745dc8d3  jz 0x00007431745D57E0
00007431745dc8d9  nop [rax+rax*1], ax
00007431745dc8e2  nop [rax+rax*1], eax
00007431745dc8ea  mov eax, 0x410278
00007431745dc8ef  mov [r15+0x100], rax
00007431745dc8f6  jmp 0x00007431743FE110
00007431745dc8fb  int3
00007431745dc8fc  call 0x00007431744E27E0
00007431745dc901  jmp 0x00007431745DB9DF
00007431745dc906  call 0x00007431744E1570
00007431745dc90b  jmp 0x00007431745DB9E8
00007431745dc910  call 0x00007431744E27E0
00007431745dc915  jmp 0x00007431745DBA44
00007431745dc91a  call 0x00007431744E1570
00007431745dc91f  jmp 0x00007431745DBA4D
00007431745dc924  call 0x00007431744E27E0
00007431745dc929  jmp 0x00007431745DBA90
00007431745dc92e  call 0x00007431744E1570
00007431745dc933  jmp 0x00007431745DBA99
00007431745dc938  call 0x000074317440DC20
00007431745dc93d  jmp 0x00007431745DBAD8
00007431745dc942  call 0x00007431744D59C0
00007431745dc947  jmp 0x00007431745DBAEB
00007431745dc94c  call 0x00007431744E0E30
00007431745dc951  jmp 0x00007431745DBB09
00007431745dc956  call 0x00007431744DFBC0
00007431745dc95b  jmp 0x00007431745DBB13
00007431745dc960  call 0x00007431744DE950
00007431745dc965  jmp 0x00007431745DBB1D
00007431745dc96a  sub rsp, 0x08
00007431745dc96e  push rax
00007431745dc96f  push rcx
00007431745dc970  push rdx
00007431745dc971  push rdi
00007431745dc972  push rsi
00007431745dc973  push r8
00007431745dc975  push r9
00007431745dc977  push r10
00007431745dc979  push r11
00007431745dc97b  sub rsp, 0xF0
00007431745dc982  vmovaps [rsp], xmm0
00007431745dc987  vmovaps [rsp+0x10], xmm1
00007431745dc98d  vmovaps [rsp+0x20], xmm2
00007431745dc993  vmovaps [rsp+0x30], xmm3
00007431745dc999  vmovaps [rsp+0x40], xmm4
00007431745dc99f  vmovaps [rsp+0x50], xmm5
00007431745dc9a5  vmovaps [rsp+0x60], xmm6
00007431745dc9ab  vmovaps [rsp+0x70], xmm7
00007431745dc9b1  vmovaps [rsp+0x80], xmm9
00007431745dc9ba  vmovaps [rsp+0x90], xmm10
00007431745dc9c3  vmovaps [rsp+0xA0], xmm11
00007431745dc9cc  vmovaps [rsp+0xB0], xmm12
00007431745dc9d5  vmovaps [rsp+0xC0], xmm13
00007431745dc9de  vmovaps [rsp+0xD0], xmm14
00007431745dc9e7  vmovaps [rsp+0xE0], xmm15
00007431745dc9f0  sub rsp, 0x30
00007431745dc9f4  movaps [rsp], xmm8
00007431745dc9f9  movaps [rsp+0x10], xmm12
00007431745dc9ff  movaps [rsp+0x20], xmm15
00007431745dca05  lea rdi, [rsp]
00007431745dca09  mov esi, 0x00
00007431745dca0e  mov rax, 0x56C40959E530
00007431745dca18  call rax
00007431745dca1a  movaps xmm8, [rsp]
00007431745dca1f  add rsp, 0x30
00007431745dca23  vmovaps xmm0, [rsp]
00007431745dca28  vmovaps xmm1, [rsp+0x10]
00007431745dca2e  vmovaps xmm2, [rsp+0x20]
00007431745dca34  vmovaps xmm3, [rsp+0x30]
00007431745dca3a  vmovaps xmm4, [rsp+0x40]
00007431745dca40  vmovaps xmm5, [rsp+0x50]
00007431745dca46  vmovaps xmm6, [rsp+0x60]
00007431745dca4c  vmovaps xmm7, [rsp+0x70]
00007431745dca52  vmovaps xmm9, [rsp+0x80]
00007431745dca5b  vmovaps xmm10, [rsp+0x90]
00007431745dca64  vmovaps xmm11, [rsp+0xA0]
00007431745dca6d  vmovaps xmm12, [rsp+0xB0]
00007431745dca76  vmovaps xmm13, [rsp+0xC0]
00007431745dca7f  vmovaps xmm14, [rsp+0xD0]
00007431745dca88  vmovaps xmm15, [rsp+0xE0]
00007431745dca91  add rsp, 0xF0
00007431745dca98  pop r11
00007431745dca9a  pop r10
00007431745dca9c  pop r9
00007431745dca9e  pop r8
00007431745dcaa0  pop rsi
00007431745dcaa1  pop rdi
00007431745dcaa2  pop rdx
00007431745dcaa3  pop rcx
00007431745dcaa4  pop rax
00007431745dcaa5  add rsp, 0x08
00007431745dcaa9  jmp 0x00007431745DBB47
00007431745dcaae  sub rsp, 0x08
00007431745dcab2  push rax
00007431745dcab3  push rcx
00007431745dcab4  push rdx
00007431745dcab5  push rdi
00007431745dcab6  push rsi
00007431745dcab7  push r8
00007431745dcab9  push r9
00007431745dcabb  push r10
00007431745dcabd  push r11
00007431745dcabf  sub rsp, 0xF0
00007431745dcac6  vmovaps [rsp], xmm0
00007431745dcacb  vmovaps [rsp+0x10], xmm1
00007431745dcad1  vmovaps [rsp+0x20], xmm2
00007431745dcad7  vmovaps [rsp+0x30], xmm3
00007431745dcadd  vmovaps [rsp+0x40], xmm4
00007431745dcae3  vmovaps [rsp+0x50], xmm5
00007431745dcae9  vmovaps [rsp+0x60], xmm6
00007431745dcaef  vmovaps [rsp+0x70], xmm8
00007431745dcaf5  vmovaps [rsp+0x80], xmm9
00007431745dcafe  vmovaps [rsp+0x90], xmm10
00007431745dcb07  vmovaps [rsp+0xA0], xmm11
00007431745dcb10  vmovaps [rsp+0xB0], xmm12
00007431745dcb19  vmovaps [rsp+0xC0], xmm13
00007431745dcb22  vmovaps [rsp+0xD0], xmm14
00007431745dcb2b  vmovaps [rsp+0xE0], xmm15
00007431745dcb34  sub rsp, 0x30
00007431745dcb38  movaps [rsp], xmm7
00007431745dcb3c  movaps [rsp+0x10], xmm9
00007431745dcb42  movaps [rsp+0x20], xmm15
00007431745dcb48  lea rdi, [rsp]
00007431745dcb4c  mov esi, 0x00
00007431745dcb51  mov rax, 0x56C40959E530
00007431745dcb5b  call rax
00007431745dcb5d  movaps xmm7, [rsp]
00007431745dcb61  add rsp, 0x30
00007431745dcb65  vmovaps xmm0, [rsp]
00007431745dcb6a  vmovaps xmm1, [rsp+0x10]
00007431745dcb70  vmovaps xmm2, [rsp+0x20]
00007431745dcb76  vmovaps xmm3, [rsp+0x30]
00007431745dcb7c  vmovaps xmm4, [rsp+0x40]
00007431745dcb82  vmovaps xmm5, [rsp+0x50]
00007431745dcb88  vmovaps xmm6, [rsp+0x60]
00007431745dcb8e  vmovaps xmm8, [rsp+0x70]
00007431745dcb94  vmovaps xmm9, [rsp+0x80]
00007431745dcb9d  vmovaps xmm10, [rsp+0x90]
00007431745dcba6  vmovaps xmm11, [rsp+0xA0]
00007431745dcbaf  vmovaps xmm12, [rsp+0xB0]
00007431745dcbb8  vmovaps xmm13, [rsp+0xC0]
00007431745dcbc1  vmovaps xmm14, [rsp+0xD0]
00007431745dcbca  vmovaps xmm15, [rsp+0xE0]
00007431745dcbd3  add rsp, 0xF0
00007431745dcbda  pop r11
00007431745dcbdc  pop r10
00007431745dcbde  pop r9
00007431745dcbe0  pop r8
00007431745dcbe2  pop rsi
00007431745dcbe3  pop rdi
00007431745dcbe4  pop rdx
00007431745dcbe5  pop rcx
00007431745dcbe6  pop rax
00007431745dcbe7  add rsp, 0x08
00007431745dcbeb  jmp 0x00007431745DBB75
00007431745dcbf0  sub rsp, 0x08
00007431745dcbf4  push rax
00007431745dcbf5  push rcx
00007431745dcbf6  push rdx
00007431745dcbf7  push rdi
00007431745dcbf8  push rsi
00007431745dcbf9  push r8
00007431745dcbfb  push r9
00007431745dcbfd  push r10
00007431745dcbff  push r11
00007431745dcc01  sub rsp, 0xF0
00007431745dcc08  vmovaps [rsp], xmm0
00007431745dcc0d  vmovaps [rsp+0x10], xmm1
00007431745dcc13  vmovaps [rsp+0x20], xmm2
00007431745dcc19  vmovaps [rsp+0x30], xmm3
00007431745dcc1f  vmovaps [rsp+0x40], xmm4
00007431745dcc25  vmovaps [rsp+0x50], xmm5
00007431745dcc2b  vmovaps [rsp+0x60], xmm6
00007431745dcc31  vmovaps [rsp+0x70], xmm7
00007431745dcc37  vmovaps [rsp+0x80], xmm8
00007431745dcc40  vmovaps [rsp+0x90], xmm10
00007431745dcc49  vmovaps [rsp+0xA0], xmm11
00007431745dcc52  vmovaps [rsp+0xB0], xmm12
00007431745dcc5b  vmovaps [rsp+0xC0], xmm13
00007431745dcc64  vmovaps [rsp+0xD0], xmm14
00007431745dcc6d  vmovaps [rsp+0xE0], xmm15
00007431745dcc76  sub rsp, 0x30
00007431745dcc7a  movaps [rsp], xmm9
00007431745dcc7f  movaps [rsp+0x10], xmm12
00007431745dcc85  movaps [rsp+0x20], xmm10
00007431745dcc8b  lea rdi, [rsp]
00007431745dcc8f  mov esi, 0x00
00007431745dcc94  mov rax, 0x56C40959E530
00007431745dcc9e  call rax
00007431745dcca0  movaps xmm9, [rsp]
00007431745dcca5  add rsp, 0x30
00007431745dcca9  vmovaps xmm0, [rsp]
00007431745dccae  vmovaps xmm1, [rsp+0x10]
00007431745dccb4  vmovaps xmm2, [rsp+0x20]
00007431745dccba  vmovaps xmm3, [rsp+0x30]
00007431745dccc0  vmovaps xmm4, [rsp+0x40]
00007431745dccc6  vmovaps xmm5, [rsp+0x50]
00007431745dcccc  vmovaps xmm6, [rsp+0x60]
00007431745dccd2  vmovaps xmm7, [rsp+0x70]
00007431745dccd8  vmovaps xmm8, [rsp+0x80]
00007431745dcce1  vmovaps xmm10, [rsp+0x90]
00007431745dccea  vmovaps xmm11, [rsp+0xA0]
00007431745dccf3  vmovaps xmm12, [rsp+0xB0]
00007431745dccfc  vmovaps xmm13, [rsp+0xC0]
00007431745dcd05  vmovaps xmm14, [rsp+0xD0]
00007431745dcd0e  vmovaps xmm15, [rsp+0xE0]
00007431745dcd17  add rsp, 0xF0
00007431745dcd1e  pop r11
00007431745dcd20  pop r10
00007431745dcd22  pop r9
00007431745dcd24  pop r8
00007431745dcd26  pop rsi
00007431745dcd27  pop rdi
00007431745dcd28  pop rdx
00007431745dcd29  pop rcx
00007431745dcd2a  pop rax
00007431745dcd2b  add rsp, 0x08
00007431745dcd2f  jmp 0x00007431745DBB99
00007431745dcd34  sub rsp, 0x08
00007431745dcd38  push rax
00007431745dcd39  push rcx
00007431745dcd3a  push rdx
00007431745dcd3b  push rdi
00007431745dcd3c  push rsi
00007431745dcd3d  push r8
00007431745dcd3f  push r9
00007431745dcd41  push r10
00007431745dcd43  push r11
00007431745dcd45  sub rsp, 0xF0
00007431745dcd4c  vmovaps [rsp], xmm0
00007431745dcd51  vmovaps [rsp+0x10], xmm1
00007431745dcd57  vmovaps [rsp+0x20], xmm2
00007431745dcd5d  vmovaps [rsp+0x30], xmm3
00007431745dcd63  vmovaps [rsp+0x40], xmm4
00007431745dcd69  vmovaps [rsp+0x50], xmm5
00007431745dcd6f  vmovaps [rsp+0x60], xmm6
00007431745dcd75  vmovaps [rsp+0x70], xmm7
00007431745dcd7b  vmovaps [rsp+0x80], xmm8
00007431745dcd84  vmovaps [rsp+0x90], xmm9
00007431745dcd8d  vmovaps [rsp+0xA0], xmm11
00007431745dcd96  vmovaps [rsp+0xB0], xmm12
00007431745dcd9f  vmovaps [rsp+0xC0], xmm13
00007431745dcda8  vmovaps [rsp+0xD0], xmm14
00007431745dcdb1  vmovaps [rsp+0xE0], xmm15
00007431745dcdba  sub rsp, 0x30
00007431745dcdbe  movaps [rsp], xmm10
00007431745dcdc3  movaps [rsp+0x10], xmm12
00007431745dcdc9  movaps [rsp+0x20], xmm11
00007431745dcdcf  lea rdi, [rsp]
00007431745dcdd3  mov esi, 0x00
00007431745dcdd8  mov rax, 0x56C40959E530
00007431745dcde2  call rax
00007431745dcde4  movaps xmm10, [rsp]
00007431745dcde9  add rsp, 0x30
00007431745dcded  vmovaps xmm0, [rsp]
00007431745dcdf2  vmovaps xmm1, [rsp+0x10]
00007431745dcdf8  vmovaps xmm2, [rsp+0x20]
00007431745dcdfe  vmovaps xmm3, [rsp+0x30]
00007431745dce04  vmovaps xmm4, [rsp+0x40]
00007431745dce0a  vmovaps xmm5, [rsp+0x50]
00007431745dce10  vmovaps xmm6, [rsp+0x60]
00007431745dce16  vmovaps xmm7, [rsp+0x70]
00007431745dce1c  vmovaps xmm8, [rsp+0x80]
00007431745dce25  vmovaps xmm9, [rsp+0x90]
00007431745dce2e  vmovaps xmm11, [rsp+0xA0]
00007431745dce37  vmovaps xmm12, [rsp+0xB0]
00007431745dce40  vmovaps xmm13, [rsp+0xC0]
00007431745dce49  vmovaps xmm14, [rsp+0xD0]
00007431745dce52  vmovaps xmm15, [rsp+0xE0]
00007431745dce5b  add rsp, 0xF0
00007431745dce62  pop r11
00007431745dce64  pop r10
00007431745dce66  pop r9
00007431745dce68  pop r8
00007431745dce6a  pop rsi
00007431745dce6b  pop rdi
00007431745dce6c  pop rdx
00007431745dce6d  pop rcx
00007431745dce6e  pop rax
00007431745dce6f  add rsp, 0x08
00007431745dce73  jmp 0x00007431745DBBB3
00007431745dce78  sub rsp, 0x08
00007431745dce7c  push rax
00007431745dce7d  push rcx
00007431745dce7e  push rdx
00007431745dce7f  push rdi
00007431745dce80  push rsi
00007431745dce81  push r8
00007431745dce83  push r9
00007431745dce85  push r10
00007431745dce87  push r11
00007431745dce89  sub rsp, 0xF0
00007431745dce90  vmovaps [rsp], xmm0
00007431745dce95  vmovaps [rsp+0x10], xmm1
00007431745dce9b  vmovaps [rsp+0x20], xmm2
00007431745dcea1  vmovaps [rsp+0x30], xmm3
00007431745dcea7  vmovaps [rsp+0x40], xmm4
00007431745dcead  vmovaps [rsp+0x50], xmm5
00007431745dceb3  vmovaps [rsp+0x60], xmm7
00007431745dceb9  vmovaps [rsp+0x70], xmm8
00007431745dcebf  vmovaps [rsp+0x80], xmm9
00007431745dcec8  vmovaps [rsp+0x90], xmm10
00007431745dced1  vmovaps [rsp+0xA0], xmm11
00007431745dceda  vmovaps [rsp+0xB0], xmm12
00007431745dcee3  vmovaps [rsp+0xC0], xmm13
00007431745dceec  vmovaps [rsp+0xD0], xmm14
00007431745dcef5  vmovaps [rsp+0xE0], xmm15
00007431745dcefe  sub rsp, 0x30
00007431745dcf02  movaps [rsp], xmm6
00007431745dcf06  movaps [rsp+0x10], xmm12
00007431745dcf0c  movaps [rsp+0x20], xmm11
00007431745dcf12  lea rdi, [rsp]
00007431745dcf16  mov esi, 0x00
00007431745dcf1b  mov rax, 0x56C40959E530
00007431745dcf25  call rax
00007431745dcf27  movaps xmm6, [rsp]
00007431745dcf2b  add rsp, 0x30
00007431745dcf2f  vmovaps xmm0, [rsp]
00007431745dcf34  vmovaps xmm1, [rsp+0x10]
00007431745dcf3a  vmovaps xmm2, [rsp+0x20]
00007431745dcf40  vmovaps xmm3, [rsp+0x30]
00007431745dcf46  vmovaps xmm4, [rsp+0x40]
00007431745dcf4c  vmovaps xmm5, [rsp+0x50]
00007431745dcf52  vmovaps xmm7, [rsp+0x60]
00007431745dcf58  vmovaps xmm8, [rsp+0x70]
00007431745dcf5e  vmovaps xmm9, [rsp+0x80]
00007431745dcf67  vmovaps xmm10, [rsp+0x90]
00007431745dcf70  vmovaps xmm11, [rsp+0xA0]
00007431745dcf79  vmovaps xmm12, [rsp+0xB0]
00007431745dcf82  vmovaps xmm13, [rsp+0xC0]
00007431745dcf8b  vmovaps xmm14, [rsp+0xD0]
00007431745dcf94  vmovaps xmm15, [rsp+0xE0]
00007431745dcf9d  add rsp, 0xF0
00007431745dcfa4  pop r11
00007431745dcfa6  pop r10
00007431745dcfa8  pop r9
00007431745dcfaa  pop r8
00007431745dcfac  pop rsi
00007431745dcfad  pop rdi
00007431745dcfae  pop rdx
00007431745dcfaf  pop rcx
00007431745dcfb0  pop rax
00007431745dcfb1  add rsp, 0x08
00007431745dcfb5  jmp 0x00007431745DBBD4
00007431745dcfba  sub rsp, 0x08
00007431745dcfbe  push rax
00007431745dcfbf  push rcx
00007431745dcfc0  push rdx
00007431745dcfc1  push rdi
00007431745dcfc2  push rsi
00007431745dcfc3  push r8
00007431745dcfc5  push r9
00007431745dcfc7  push r10
00007431745dcfc9  push r11
00007431745dcfcb  sub rsp, 0xF0
00007431745dcfd2  vmovaps [rsp], xmm0
00007431745dcfd7  vmovaps [rsp+0x10], xmm1
00007431745dcfdd  vmovaps [rsp+0x20], xmm2
00007431745dcfe3  vmovaps [rsp+0x30], xmm4
00007431745dcfe9  vmovaps [rsp+0x40], xmm5
00007431745dcfef  vmovaps [rsp+0x50], xmm6
00007431745dcff5  vmovaps [rsp+0x60], xmm7
00007431745dcffb  vmovaps [rsp+0x70], xmm8
00007431745dd001  vmovaps [rsp+0x80], xmm9
00007431745dd00a  vmovaps [rsp+0x90], xmm10
00007431745dd013  vmovaps [rsp+0xA0], xmm11
00007431745dd01c  vmovaps [rsp+0xB0], xmm12
00007431745dd025  vmovaps [rsp+0xC0], xmm13
00007431745dd02e  vmovaps [rsp+0xD0], xmm14
00007431745dd037  vmovaps [rsp+0xE0], xmm15
00007431745dd040  sub rsp, 0x30
00007431745dd044  movaps [rsp], xmm3
00007431745dd048  movaps [rsp+0x10], xmm5
00007431745dd04d  movaps [rsp+0x20], xmm4
00007431745dd052  lea rdi, [rsp]
00007431745dd056  mov esi, 0x00
00007431745dd05b  mov rax, 0x56C40959E530
00007431745dd065  call rax
00007431745dd067  movaps xmm3, [rsp]
00007431745dd06b  add rsp, 0x30
00007431745dd06f  vmovaps xmm0, [rsp]
00007431745dd074  vmovaps xmm1, [rsp+0x10]
00007431745dd07a  vmovaps xmm2, [rsp+0x20]
00007431745dd080  vmovaps xmm4, [rsp+0x30]
00007431745dd086  vmovaps xmm5, [rsp+0x40]
00007431745dd08c  vmovaps xmm6, [rsp+0x50]
00007431745dd092  vmovaps xmm7, [rsp+0x60]
00007431745dd098  vmovaps xmm8, [rsp+0x70]
00007431745dd09e  vmovaps xmm9, [rsp+0x80]
00007431745dd0a7  vmovaps xmm10, [rsp+0x90]
00007431745dd0b0  vmovaps xmm11, [rsp+0xA0]
00007431745dd0b9  vmovaps xmm12, [rsp+0xB0]
00007431745dd0c2  vmovaps xmm13, [rsp+0xC0]
00007431745dd0cb  vmovaps xmm14, [rsp+0xD0]
00007431745dd0d4  vmovaps xmm15, [rsp+0xE0]
00007431745dd0dd  add rsp, 0xF0
00007431745dd0e4  pop r11
00007431745dd0e6  pop r10
00007431745dd0e8  pop r9
00007431745dd0ea  pop r8
00007431745dd0ec  pop rsi
00007431745dd0ed  pop rdi
00007431745dd0ee  pop rdx
00007431745dd0ef  pop rcx
00007431745dd0f0  pop rax
00007431745dd0f1  add rsp, 0x08
00007431745dd0f5  jmp 0x00007431745DBC35
00007431745dd0fa  sub rsp, 0x08
00007431745dd0fe  push rax
00007431745dd0ff  push rcx
00007431745dd100  push rdx
00007431745dd101  push rdi
00007431745dd102  push rsi
00007431745dd103  push r8
00007431745dd105  push r9
00007431745dd107  push r10
00007431745dd109  push r11
00007431745dd10b  sub rsp, 0xF0
00007431745dd112  vmovaps [rsp], xmm0
00007431745dd117  vmovaps [rsp+0x10], xmm1
00007431745dd11d  vmovaps [rsp+0x20], xmm2
00007431745dd123  vmovaps [rsp+0x30], xmm3
00007431745dd129  vmovaps [rsp+0x40], xmm4
00007431745dd12f  vmovaps [rsp+0x50], xmm6
00007431745dd135  vmovaps [rsp+0x60], xmm7
00007431745dd13b  vmovaps [rsp+0x70], xmm8
00007431745dd141  vmovaps [rsp+0x80], xmm9
00007431745dd14a  vmovaps [rsp+0x90], xmm10
00007431745dd153  vmovaps [rsp+0xA0], xmm11
00007431745dd15c  vmovaps [rsp+0xB0], xmm12
00007431745dd165  vmovaps [rsp+0xC0], xmm13
00007431745dd16e  vmovaps [rsp+0xD0], xmm14
00007431745dd177  vmovaps [rsp+0xE0], xmm15
00007431745dd180  sub rsp, 0x30
00007431745dd184  movaps [rsp], xmm5
00007431745dd188  movaps [rsp+0x10], xmm8
00007431745dd18e  movaps [rsp+0x20], xmm15
00007431745dd194  lea rdi, [rsp]
00007431745dd198  mov esi, 0x00
00007431745dd19d  mov rax, 0x56C40959E530
00007431745dd1a7  call rax
00007431745dd1a9  movaps xmm5, [rsp]
00007431745dd1ad  add rsp, 0x30
00007431745dd1b1  vmovaps xmm0, [rsp]
00007431745dd1b6  vmovaps xmm1, [rsp+0x10]
00007431745dd1bc  vmovaps xmm2, [rsp+0x20]
00007431745dd1c2  vmovaps xmm3, [rsp+0x30]
00007431745dd1c8  vmovaps xmm4, [rsp+0x40]
00007431745dd1ce  vmovaps xmm6, [rsp+0x50]
00007431745dd1d4  vmovaps xmm7, [rsp+0x60]
00007431745dd1da  vmovaps xmm8, [rsp+0x70]
00007431745dd1e0  vmovaps xmm9, [rsp+0x80]
00007431745dd1e9  vmovaps xmm10, [rsp+0x90]
00007431745dd1f2  vmovaps xmm11, [rsp+0xA0]
00007431745dd1fb  vmovaps xmm12, [rsp+0xB0]
00007431745dd204  vmovaps xmm13, [rsp+0xC0]
00007431745dd20d  vmovaps xmm14, [rsp+0xD0]
00007431745dd216  vmovaps xmm15, [rsp+0xE0]
00007431745dd21f  add rsp, 0xF0
00007431745dd226  pop r11
00007431745dd228  pop r10
00007431745dd22a  pop r9
00007431745dd22c  pop r8
00007431745dd22e  pop rsi
00007431745dd22f  pop rdi
00007431745dd230  pop rdx
00007431745dd231  pop rcx
00007431745dd232  pop rax
00007431745dd233  add rsp, 0x08
00007431745dd237  jmp 0x00007431745DBC73
00007431745dd23c  sub rsp, 0x08
00007431745dd240  push rax
00007431745dd241  push rcx
00007431745dd242  push rdx
00007431745dd243  push rdi
00007431745dd244  push rsi
00007431745dd245  push r8
00007431745dd247  push r9
00007431745dd249  push r10
00007431745dd24b  push r11
00007431745dd24d  sub rsp, 0xF0
00007431745dd254  vmovaps [rsp], xmm0
00007431745dd259  vmovaps [rsp+0x10], xmm1
00007431745dd25f  vmovaps [rsp+0x20], xmm2
00007431745dd265  vmovaps [rsp+0x30], xmm3
00007431745dd26b  vmovaps [rsp+0x40], xmm5
00007431745dd271  vmovaps [rsp+0x50], xmm6
00007431745dd277  vmovaps [rsp+0x60], xmm7
00007431745dd27d  vmovaps [rsp+0x70], xmm8
00007431745dd283  vmovaps [rsp+0x80], xmm9
00007431745dd28c  vmovaps [rsp+0x90], xmm10
00007431745dd295  vmovaps [rsp+0xA0], xmm11
00007431745dd29e  vmovaps [rsp+0xB0], xmm12
00007431745dd2a7  vmovaps [rsp+0xC0], xmm13
00007431745dd2b0  vmovaps [rsp+0xD0], xmm14
00007431745dd2b9  vmovaps [rsp+0xE0], xmm15
00007431745dd2c2  sub rsp, 0x30
00007431745dd2c6  movaps [rsp], xmm4
00007431745dd2ca  movaps [rsp+0x10], xmm9
00007431745dd2d0  movaps [rsp+0x20], xmm8
00007431745dd2d6  lea rdi, [rsp]
00007431745dd2da  mov esi, 0x00
00007431745dd2df  mov rax, 0x56C40959E530
00007431745dd2e9  call rax
00007431745dd2eb  movaps xmm4, [rsp]
00007431745dd2ef  add rsp, 0x30
00007431745dd2f3  vmovaps xmm0, [rsp]
00007431745dd2f8  vmovaps xmm1, [rsp+0x10]
00007431745dd2fe  vmovaps xmm2, [rsp+0x20]
00007431745dd304  vmovaps xmm3, [rsp+0x30]
00007431745dd30a  vmovaps xmm5, [rsp+0x40]
00007431745dd310  vmovaps xmm6, [rsp+0x50]
00007431745dd316  vmovaps xmm7, [rsp+0x60]
00007431745dd31c  vmovaps xmm8, [rsp+0x70]
00007431745dd322  vmovaps xmm9, [rsp+0x80]
00007431745dd32b  vmovaps xmm10, [rsp+0x90]
00007431745dd334  vmovaps xmm11, [rsp+0xA0]
00007431745dd33d  vmovaps xmm12, [rsp+0xB0]
00007431745dd346  vmovaps xmm13, [rsp+0xC0]
00007431745dd34f  vmovaps xmm14, [rsp+0xD0]
00007431745dd358  vmovaps xmm15, [rsp+0xE0]
00007431745dd361  add rsp, 0xF0
00007431745dd368  pop r11
00007431745dd36a  pop r10
00007431745dd36c  pop r9
00007431745dd36e  pop r8
00007431745dd370  pop rsi
00007431745dd371  pop rdi
00007431745dd372  pop rdx
00007431745dd373  pop rcx
00007431745dd374  pop rax
00007431745dd375  add rsp, 0x08
00007431745dd379  jmp 0x00007431745DBC94
00007431745dd37e  sub rsp, 0x08
00007431745dd382  push rax
00007431745dd383  push rcx
00007431745dd384  push rdx
00007431745dd385  push rdi
00007431745dd386  push rsi
00007431745dd387  push r8
00007431745dd389  push r9
00007431745dd38b  push r10
00007431745dd38d  push r11
00007431745dd38f  sub rsp, 0xF0
00007431745dd396  vmovaps [rsp], xmm0
00007431745dd39b  vmovaps [rsp+0x10], xmm1
00007431745dd3a1  vmovaps [rsp+0x20], xmm2
00007431745dd3a7  vmovaps [rsp+0x30], xmm3
00007431745dd3ad  vmovaps [rsp+0x40], xmm4
00007431745dd3b3  vmovaps [rsp+0x50], xmm5
00007431745dd3b9  vmovaps [rsp+0x60], xmm6
00007431745dd3bf  vmovaps [rsp+0x70], xmm7
00007431745dd3c5  vmovaps [rsp+0x80], xmm8
00007431745dd3ce  vmovaps [rsp+0x90], xmm10
00007431745dd3d7  vmovaps [rsp+0xA0], xmm11
00007431745dd3e0  vmovaps [rsp+0xB0], xmm12
00007431745dd3e9  vmovaps [rsp+0xC0], xmm13
00007431745dd3f2  vmovaps [rsp+0xD0], xmm14
00007431745dd3fb  vmovaps [rsp+0xE0], xmm15
00007431745dd404  sub rsp, 0x30
00007431745dd408  movaps [rsp], xmm9
00007431745dd40d  movaps [rsp+0x10], xmm10
00007431745dd413  movaps [rsp+0x20], xmm8
00007431745dd419  lea rdi, [rsp]
00007431745dd41d  mov esi, 0x00
00007431745dd422  mov rax, 0x56C40959E530
00007431745dd42c  call rax
00007431745dd42e  movaps xmm9, [rsp]
00007431745dd433  add rsp, 0x30
00007431745dd437  vmovaps xmm0, [rsp]
00007431745dd43c  vmovaps xmm1, [rsp+0x10]
00007431745dd442  vmovaps xmm2, [rsp+0x20]
00007431745dd448  vmovaps xmm3, [rsp+0x30]
00007431745dd44e  vmovaps xmm4, [rsp+0x40]
00007431745dd454  vmovaps xmm5, [rsp+0x50]
00007431745dd45a  vmovaps xmm6, [rsp+0x60]
00007431745dd460  vmovaps xmm7, [rsp+0x70]
00007431745dd466  vmovaps xmm8, [rsp+0x80]
00007431745dd46f  vmovaps xmm10, [rsp+0x90]
00007431745dd478  vmovaps xmm11, [rsp+0xA0]
00007431745dd481  vmovaps xmm12, [rsp+0xB0]
00007431745dd48a  vmovaps xmm13, [rsp+0xC0]
00007431745dd493  vmovaps xmm14, [rsp+0xD0]
00007431745dd49c  vmovaps xmm15, [rsp+0xE0]
00007431745dd4a5  add rsp, 0xF0
00007431745dd4ac  pop r11
00007431745dd4ae  pop r10
00007431745dd4b0  pop r9
00007431745dd4b2  pop r8
00007431745dd4b4  pop rsi
00007431745dd4b5  pop rdi
00007431745dd4b6  pop rdx
00007431745dd4b7  pop rcx
00007431745dd4b8  pop rax
00007431745dd4b9  add rsp, 0x08
00007431745dd4bd  jmp 0x00007431745DBCAE
00007431745dd4c2  call 0x00007431744B52F0
00007431745dd4c7  jmp 0x00007431745DBDC8
00007431745dd4cc  call 0x00007431744B52F0
00007431745dd4d1  jmp 0x00007431745DBDDE
00007431745dd4d6  sub rsp, 0x08
00007431745dd4da  push rax
00007431745dd4db  push rcx
00007431745dd4dc  push rdx
00007431745dd4dd  push rdi
00007431745dd4de  push rsi
00007431745dd4df  push r8
00007431745dd4e1  push r9
00007431745dd4e3  push r10
00007431745dd4e5  push r11
00007431745dd4e7  sub rsp, 0xF0
00007431745dd4ee  vmovaps [rsp], xmm0
00007431745dd4f3  vmovaps [rsp+0x10], xmm2
00007431745dd4f9  vmovaps [rsp+0x20], xmm3
00007431745dd4ff  vmovaps [rsp+0x30], xmm4
00007431745dd505  vmovaps [rsp+0x40], xmm5
00007431745dd50b  vmovaps [rsp+0x50], xmm6
00007431745dd511  vmovaps [rsp+0x60], xmm7
00007431745dd517  vmovaps [rsp+0x70], xmm8
00007431745dd51d  vmovaps [rsp+0x80], xmm9
00007431745dd526  vmovaps [rsp+0x90], xmm10
00007431745dd52f  vmovaps [rsp+0xA0], xmm11
00007431745dd538  vmovaps [rsp+0xB0], xmm12
00007431745dd541  vmovaps [rsp+0xC0], xmm13
00007431745dd54a  vmovaps [rsp+0xD0], xmm14
00007431745dd553  vmovaps [rsp+0xE0], xmm15
00007431745dd55c  sub rsp, 0x30
00007431745dd560  movaps [rsp], xmm1
00007431745dd564  movaps [rsp+0x10], xmm6
00007431745dd569  movaps [rsp+0x20], xmm15
00007431745dd56f  lea rdi, [rsp]
00007431745dd573  mov esi, 0x00
00007431745dd578  mov rax, 0x56C40959E530
00007431745dd582  call rax
00007431745dd584  movaps xmm1, [rsp]
00007431745dd588  add rsp, 0x30
00007431745dd58c  vmovaps xmm0, [rsp]
00007431745dd591  vmovaps xmm2, [rsp+0x10]
00007431745dd597  vmovaps xmm3, [rsp+0x20]
00007431745dd59d  vmovaps xmm4, [rsp+0x30]
00007431745dd5a3  vmovaps xmm5, [rsp+0x40]
00007431745dd5a9  vmovaps xmm6, [rsp+0x50]
00007431745dd5af  vmovaps xmm7, [rsp+0x60]
00007431745dd5b5  vmovaps xmm8, [rsp+0x70]
00007431745dd5bb  vmovaps xmm9, [rsp+0x80]
00007431745dd5c4  vmovaps xmm10, [rsp+0x90]
00007431745dd5cd  vmovaps xmm11, [rsp+0xA0]
00007431745dd5d6  vmovaps xmm12, [rsp+0xB0]
00007431745dd5df  vmovaps xmm13, [rsp+0xC0]
00007431745dd5e8  vmovaps xmm14, [rsp+0xD0]
00007431745dd5f1  vmovaps xmm15, [rsp+0xE0]
00007431745dd5fa  add rsp, 0xF0
00007431745dd601  pop r11
00007431745dd603  pop r10
00007431745dd605  pop r9
00007431745dd607  pop r8
00007431745dd609  pop rsi
00007431745dd60a  pop rdi
00007431745dd60b  pop rdx
00007431745dd60c  pop rcx
00007431745dd60d  pop rax
00007431745dd60e  add rsp, 0x08
00007431745dd612  jmp 0x00007431745DBE1B
00007431745dd617  call 0x00007431744C4620
00007431745dd61c  jmp 0x00007431745DBE28
00007431745dd621  sub rsp, 0x08
00007431745dd625  push rax
00007431745dd626  push rcx
00007431745dd627  push rdx
00007431745dd628  push rdi
00007431745dd629  push rsi
00007431745dd62a  push r8
00007431745dd62c  push r9
00007431745dd62e  push r10
00007431745dd630  push r11
00007431745dd632  sub rsp, 0xF0
00007431745dd639  vmovaps [rsp], xmm0
00007431745dd63e  vmovaps [rsp+0x10], xmm1
00007431745dd644  vmovaps [rsp+0x20], xmm2
00007431745dd64a  vmovaps [rsp+0x30], xmm3
00007431745dd650  vmovaps [rsp+0x40], xmm4
00007431745dd656  vmovaps [rsp+0x50], xmm5
00007431745dd65c  vmovaps [rsp+0x60], xmm6
00007431745dd662  vmovaps [rsp+0x70], xmm7
00007431745dd668  vmovaps [rsp+0x80], xmm8
00007431745dd671  vmovaps [rsp+0x90], xmm9
00007431745dd67a  vmovaps [rsp+0xA0], xmm10
00007431745dd683  vmovaps [rsp+0xB0], xmm11
00007431745dd68c  vmovaps [rsp+0xC0], xmm12
00007431745dd695  vmovaps [rsp+0xD0], xmm13
00007431745dd69e  vmovaps [rsp+0xE0], xmm15
00007431745dd6a7  sub rsp, 0x30
00007431745dd6ab  movaps [rsp], xmm14
00007431745dd6b0  movaps [rsp+0x10], xmm4
00007431745dd6b5  movaps [rsp+0x20], xmm3
00007431745dd6ba  lea rdi, [rsp]
00007431745dd6be  mov esi, 0x00
00007431745dd6c3  mov rax, 0x56C40959E530
00007431745dd6cd  call rax
00007431745dd6cf  movaps xmm14, [rsp]
00007431745dd6d4  add rsp, 0x30
00007431745dd6d8  vmovaps xmm0, [rsp]
00007431745dd6dd  vmovaps xmm1, [rsp+0x10]
00007431745dd6e3  vmovaps xmm2, [rsp+0x20]
00007431745dd6e9  vmovaps xmm3, [rsp+0x30]
00007431745dd6ef  vmovaps xmm4, [rsp+0x40]
00007431745dd6f5  vmovaps xmm5, [rsp+0x50]
00007431745dd6fb  vmovaps xmm6, [rsp+0x60]
00007431745dd701  vmovaps xmm7, [rsp+0x70]
00007431745dd707  vmovaps xmm8, [rsp+0x80]
00007431745dd710  vmovaps xmm9, [rsp+0x90]
00007431745dd719  vmovaps xmm10, [rsp+0xA0]
00007431745dd722  vmovaps xmm11, [rsp+0xB0]
00007431745dd72b  vmovaps xmm12, [rsp+0xC0]
00007431745dd734  vmovaps xmm13, [rsp+0xD0]
00007431745dd73d  vmovaps xmm15, [rsp+0xE0]
00007431745dd746  add rsp, 0xF0
00007431745dd74d  pop r11
00007431745dd74f  pop r10
00007431745dd751  pop r9
00007431745dd753  pop r8
00007431745dd755  pop rsi
00007431745dd756  pop rdi
00007431745dd757  pop rdx
00007431745dd758  pop rcx
00007431745dd759  pop rax
00007431745dd75a  add rsp, 0x08
00007431745dd75e  jmp 0x00007431745DBE42
00007431745dd763  sub rsp, 0x08
00007431745dd767  push rax
00007431745dd768  push rcx
00007431745dd769  push rdx
00007431745dd76a  push rdi
00007431745dd76b  push rsi
00007431745dd76c  push r8
00007431745dd76e  push r9
00007431745dd770  push r10
00007431745dd772  push r11
00007431745dd774  sub rsp, 0xF0
00007431745dd77b  vmovaps [rsp], xmm0
00007431745dd780  vmovaps [rsp+0x10], xmm1
00007431745dd786  vmovaps [rsp+0x20], xmm2
00007431745dd78c  vmovaps [rsp+0x30], xmm3
00007431745dd792  vmovaps [rsp+0x40], xmm4
00007431745dd798  vmovaps [rsp+0x50], xmm5
00007431745dd79e  vmovaps [rsp+0x60], xmm7
00007431745dd7a4  vmovaps [rsp+0x70], xmm8
00007431745dd7aa  vmovaps [rsp+0x80], xmm9
00007431745dd7b3  vmovaps [rsp+0x90], xmm10
00007431745dd7bc  vmovaps [rsp+0xA0], xmm11
00007431745dd7c5  vmovaps [rsp+0xB0], xmm12
00007431745dd7ce  vmovaps [rsp+0xC0], xmm13
00007431745dd7d7  vmovaps [rsp+0xD0], xmm14
00007431745dd7e0  vmovaps [rsp+0xE0], xmm15
00007431745dd7e9  sub rsp, 0x30
00007431745dd7ed  movaps [rsp], xmm6
00007431745dd7f1  movaps [rsp+0x10], xmm9
00007431745dd7f7  movaps [rsp+0x20], xmm7
00007431745dd7fc  lea rdi, [rsp]
00007431745dd800  mov esi, 0x00
00007431745dd805  mov rax, 0x56C40959E530
00007431745dd80f  call rax
00007431745dd811  movaps xmm6, [rsp]
00007431745dd815  add rsp, 0x30
00007431745dd819  vmovaps xmm0, [rsp]
00007431745dd81e  vmovaps xmm1, [rsp+0x10]
00007431745dd824  vmovaps xmm2, [rsp+0x20]
00007431745dd82a  vmovaps xmm3, [rsp+0x30]
00007431745dd830  vmovaps xmm4, [rsp+0x40]
00007431745dd836  vmovaps xmm5, [rsp+0x50]
00007431745dd83c  vmovaps xmm7, [rsp+0x60]
00007431745dd842  vmovaps xmm8, [rsp+0x70]
00007431745dd848  vmovaps xmm9, [rsp+0x80]
00007431745dd851  vmovaps xmm10, [rsp+0x90]
00007431745dd85a  vmovaps xmm11, [rsp+0xA0]
00007431745dd863  vmovaps xmm12, [rsp+0xB0]
00007431745dd86c  vmovaps xmm13, [rsp+0xC0]
00007431745dd875  vmovaps xmm14, [rsp+0xD0]
00007431745dd87e  vmovaps xmm15, [rsp+0xE0]
00007431745dd887  add rsp, 0xF0
00007431745dd88e  pop r11
00007431745dd890  pop r10
00007431745dd892  pop r9
00007431745dd894  pop r8
00007431745dd896  pop rsi
00007431745dd897  pop rdi
00007431745dd898  pop rdx
00007431745dd899  pop rcx
00007431745dd89a  pop rax
00007431745dd89b  add rsp, 0x08
00007431745dd89f  jmp 0x00007431745DBE5A
00007431745dd8a4  sub rsp, 0x08
00007431745dd8a8  push rax
00007431745dd8a9  push rcx
00007431745dd8aa  push rdx
00007431745dd8ab  push rdi
00007431745dd8ac  push rsi
00007431745dd8ad  push r8
00007431745dd8af  push r9
00007431745dd8b1  push r10
00007431745dd8b3  push r11
00007431745dd8b5  sub rsp, 0xF0
00007431745dd8bc  vmovaps [rsp], xmm0
00007431745dd8c1  vmovaps [rsp+0x10], xmm1
00007431745dd8c7  vmovaps [rsp+0x20], xmm2
00007431745dd8cd  vmovaps [rsp+0x30], xmm3
00007431745dd8d3  vmovaps [rsp+0x40], xmm4
00007431745dd8d9  vmovaps [rsp+0x50], xmm5
00007431745dd8df  vmovaps [rsp+0x60], xmm6
00007431745dd8e5  vmovaps [rsp+0x70], xmm8
00007431745dd8eb  vmovaps [rsp+0x80], xmm9
00007431745dd8f4  vmovaps [rsp+0x90], xmm10
00007431745dd8fd  vmovaps [rsp+0xA0], xmm11
00007431745dd906  vmovaps [rsp+0xB0], xmm12
00007431745dd90f  vmovaps [rsp+0xC0], xmm13
00007431745dd918  vmovaps [rsp+0xD0], xmm14
00007431745dd921  vmovaps [rsp+0xE0], xmm15
00007431745dd92a  sub rsp, 0x30
00007431745dd92e  movaps [rsp], xmm7
00007431745dd932  movaps [rsp+0x10], xmm4
00007431745dd937  movaps [rsp+0x20], xmm9
00007431745dd93d  lea rdi, [rsp]
00007431745dd941  mov esi, 0x00
00007431745dd946  mov rax, 0x56C40959E530
00007431745dd950  call rax
00007431745dd952  movaps xmm7, [rsp]
00007431745dd956  add rsp, 0x30
00007431745dd95a  vmovaps xmm0, [rsp]
00007431745dd95f  vmovaps xmm1, [rsp+0x10]
00007431745dd965  vmovaps xmm2, [rsp+0x20]
00007431745dd96b  vmovaps xmm3, [rsp+0x30]
00007431745dd971  vmovaps xmm4, [rsp+0x40]
00007431745dd977  vmovaps xmm5, [rsp+0x50]
00007431745dd97d  vmovaps xmm6, [rsp+0x60]
00007431745dd983  vmovaps xmm8, [rsp+0x70]
00007431745dd989  vmovaps xmm9, [rsp+0x80]
00007431745dd992  vmovaps xmm10, [rsp+0x90]
00007431745dd99b  vmovaps xmm11, [rsp+0xA0]
00007431745dd9a4  vmovaps xmm12, [rsp+0xB0]
00007431745dd9ad  vmovaps xmm13, [rsp+0xC0]
00007431745dd9b6  vmovaps xmm14, [rsp+0xD0]
00007431745dd9bf  vmovaps xmm15, [rsp+0xE0]
00007431745dd9c8  add rsp, 0xF0
00007431745dd9cf  pop r11
00007431745dd9d1  pop r10
00007431745dd9d3  pop r9
00007431745dd9d5  pop r8
00007431745dd9d7  pop rsi
00007431745dd9d8  pop rdi
00007431745dd9d9  pop rdx
00007431745dd9da  pop rcx
00007431745dd9db  pop rax
00007431745dd9dc  add rsp, 0x08
00007431745dd9e0  jmp 0x00007431745DBE87
00007431745dd9e5  sub rsp, 0x08
00007431745dd9e9  push rax
00007431745dd9ea  push rcx
00007431745dd9eb  push rdx
00007431745dd9ec  push rdi
00007431745dd9ed  push rsi
00007431745dd9ee  push r8
00007431745dd9f0  push r9
00007431745dd9f2  push r10
00007431745dd9f4  push r11
00007431745dd9f6  sub rsp, 0xF0
00007431745dd9fd  vmovaps [rsp], xmm0
00007431745dda02  vmovaps [rsp+0x10], xmm1
00007431745dda08  vmovaps [rsp+0x20], xmm2
00007431745dda0e  vmovaps [rsp+0x30], xmm3
00007431745dda14  vmovaps [rsp+0x40], xmm5
00007431745dda1a  vmovaps [rsp+0x50], xmm6
00007431745dda20  vmovaps [rsp+0x60], xmm7
00007431745dda26  vmovaps [rsp+0x70], xmm8
00007431745dda2c  vmovaps [rsp+0x80], xmm9
00007431745dda35  vmovaps [rsp+0x90], xmm10
00007431745dda3e  vmovaps [rsp+0xA0], xmm11
00007431745dda47  vmovaps [rsp+0xB0], xmm12
00007431745dda50  vmovaps [rsp+0xC0], xmm13
00007431745dda59  vmovaps [rsp+0xD0], xmm14
00007431745dda62  vmovaps [rsp+0xE0], xmm15
00007431745dda6b  sub rsp, 0x30
00007431745dda6f  movaps [rsp], xmm4
00007431745dda73  movaps [rsp+0x10], xmm15
00007431745dda79  movaps [rsp+0x20], xmm9
00007431745dda7f  lea rdi, [rsp]
00007431745dda83  mov esi, 0x00
00007431745dda88  mov rax, 0x56C40959E530
00007431745dda92  call rax
00007431745dda94  movaps xmm4, [rsp]
00007431745dda98  add rsp, 0x30
00007431745dda9c  vmovaps xmm0, [rsp]
00007431745ddaa1  vmovaps xmm1, [rsp+0x10]
00007431745ddaa7  vmovaps xmm2, [rsp+0x20]
00007431745ddaad  vmovaps xmm3, [rsp+0x30]
00007431745ddab3  vmovaps xmm5, [rsp+0x40]
00007431745ddab9  vmovaps xmm6, [rsp+0x50]
00007431745ddabf  vmovaps xmm7, [rsp+0x60]
00007431745ddac5  vmovaps xmm8, [rsp+0x70]
00007431745ddacb  vmovaps xmm9, [rsp+0x80]
00007431745ddad4  vmovaps xmm10, [rsp+0x90]
00007431745ddadd  vmovaps xmm11, [rsp+0xA0]
00007431745ddae6  vmovaps xmm12, [rsp+0xB0]
00007431745ddaef  vmovaps xmm13, [rsp+0xC0]
00007431745ddaf8  vmovaps xmm14, [rsp+0xD0]
00007431745ddb01  vmovaps xmm15, [rsp+0xE0]
00007431745ddb0a  add rsp, 0xF0
00007431745ddb11  pop r11
00007431745ddb13  pop r10
00007431745ddb15  pop r9
00007431745ddb17  pop r8
00007431745ddb19  pop rsi
00007431745ddb1a  pop rdi
00007431745ddb1b  pop rdx
00007431745ddb1c  pop rcx
00007431745ddb1d  pop rax
00007431745ddb1e  add rsp, 0x08
00007431745ddb22  jmp 0x00007431745DBEAC
00007431745ddb27  call 0x00007431744C4620
00007431745ddb2c  jmp 0x00007431745DBEB9
00007431745ddb31  sub rsp, 0x08
00007431745ddb35  push rax
00007431745ddb36  push rcx
00007431745ddb37  push rdx
00007431745ddb38  push rdi
00007431745ddb39  push rsi
00007431745ddb3a  push r8
00007431745ddb3c  push r9
00007431745ddb3e  push r10
00007431745ddb40  push r11
00007431745ddb42  sub rsp, 0xF0
00007431745ddb49  vmovaps [rsp], xmm0
00007431745ddb4e  vmovaps [rsp+0x10], xmm1
00007431745ddb54  vmovaps [rsp+0x20], xmm2
00007431745ddb5a  vmovaps [rsp+0x30], xmm4
00007431745ddb60  vmovaps [rsp+0x40], xmm5
00007431745ddb66  vmovaps [rsp+0x50], xmm6
00007431745ddb6c  vmovaps [rsp+0x60], xmm7
00007431745ddb72  vmovaps [rsp+0x70], xmm8
00007431745ddb78  vmovaps [rsp+0x80], xmm9
00007431745ddb81  vmovaps [rsp+0x90], xmm10
00007431745ddb8a  vmovaps [rsp+0xA0], xmm11
00007431745ddb93  vmovaps [rsp+0xB0], xmm12
00007431745ddb9c  vmovaps [rsp+0xC0], xmm13
00007431745ddba5  vmovaps [rsp+0xD0], xmm14
00007431745ddbae  vmovaps [rsp+0xE0], xmm15
00007431745ddbb7  sub rsp, 0x30
00007431745ddbbb  movaps [rsp], xmm3
00007431745ddbbf  movaps [rsp+0x10], xmm1
00007431745ddbc4  movaps [rsp+0x20], xmm9
00007431745ddbca  lea rdi, [rsp]
00007431745ddbce  mov esi, 0x00
00007431745ddbd3  mov rax, 0x56C40959E530
00007431745ddbdd  call rax
00007431745ddbdf  movaps xmm3, [rsp]
00007431745ddbe3  add rsp, 0x30
00007431745ddbe7  vmovaps xmm0, [rsp]
00007431745ddbec  vmovaps xmm1, [rsp+0x10]
00007431745ddbf2  vmovaps xmm2, [rsp+0x20]
00007431745ddbf8  vmovaps xmm4, [rsp+0x30]
00007431745ddbfe  vmovaps xmm5, [rsp+0x40]
00007431745ddc04  vmovaps xmm6, [rsp+0x50]
00007431745ddc0a  vmovaps xmm7, [rsp+0x60]
00007431745ddc10  vmovaps xmm8, [rsp+0x70]
00007431745ddc16  vmovaps xmm9, [rsp+0x80]
00007431745ddc1f  vmovaps xmm10, [rsp+0x90]
00007431745ddc28  vmovaps xmm11, [rsp+0xA0]
00007431745ddc31  vmovaps xmm12, [rsp+0xB0]
00007431745ddc3a  vmovaps xmm13, [rsp+0xC0]
00007431745ddc43  vmovaps xmm14, [rsp+0xD0]
00007431745ddc4c  vmovaps xmm15, [rsp+0xE0]
00007431745ddc55  add rsp, 0xF0
00007431745ddc5c  pop r11
00007431745ddc5e  pop r10
00007431745ddc60  pop r9
00007431745ddc62  pop r8
00007431745ddc64  pop rsi
00007431745ddc65  pop rdi
00007431745ddc66  pop rdx
00007431745ddc67  pop rcx
00007431745ddc68  pop rax
00007431745ddc69  add rsp, 0x08
00007431745ddc6d  jmp 0x00007431745DBEF6
00007431745ddc72  sub rsp, 0x08
00007431745ddc76  push rax
00007431745ddc77  push rcx
00007431745ddc78  push rdx
00007431745ddc79  push rdi
00007431745ddc7a  push rsi
00007431745ddc7b  push r8
00007431745ddc7d  push r9
00007431745ddc7f  push r10
00007431745ddc81  push r11
00007431745ddc83  sub rsp, 0xF0
00007431745ddc8a  vmovaps [rsp], xmm0
00007431745ddc8f  vmovaps [rsp+0x10], xmm2
00007431745ddc95  vmovaps [rsp+0x20], xmm3
00007431745ddc9b  vmovaps [rsp+0x30], xmm4
00007431745ddca1  vmovaps [rsp+0x40], xmm5
00007431745ddca7  vmovaps [rsp+0x50], xmm6
00007431745ddcad  vmovaps [rsp+0x60], xmm7
00007431745ddcb3  vmovaps [rsp+0x70], xmm8
00007431745ddcb9  vmovaps [rsp+0x80], xmm9
00007431745ddcc2  vmovaps [rsp+0x90], xmm10
00007431745ddccb  vmovaps [rsp+0xA0], xmm11
00007431745ddcd4  vmovaps [rsp+0xB0], xmm12
00007431745ddcdd  vmovaps [rsp+0xC0], xmm13
00007431745ddce6  vmovaps [rsp+0xD0], xmm14
00007431745ddcef  vmovaps [rsp+0xE0], xmm15
00007431745ddcf8  sub rsp, 0x30
00007431745ddcfc  movaps [rsp], xmm1
00007431745ddd00  movaps [rsp+0x10], xmm15
00007431745ddd06  movaps [rsp+0x20], xmm9
00007431745ddd0c  lea rdi, [rsp]
00007431745ddd10  mov esi, 0x00
00007431745ddd15  mov rax, 0x56C40959E530
00007431745ddd1f  call rax
00007431745ddd21  movaps xmm1, [rsp]
00007431745ddd25  add rsp, 0x30
00007431745ddd29  vmovaps xmm0, [rsp]
00007431745ddd2e  vmovaps xmm2, [rsp+0x10]
00007431745ddd34  vmovaps xmm3, [rsp+0x20]
00007431745ddd3a  vmovaps xmm4, [rsp+0x30]
00007431745ddd40  vmovaps xmm5, [rsp+0x40]
00007431745ddd46  vmovaps xmm6, [rsp+0x50]
00007431745ddd4c  vmovaps xmm7, [rsp+0x60]
00007431745ddd52  vmovaps xmm8, [rsp+0x70]
00007431745ddd58  vmovaps xmm9, [rsp+0x80]
00007431745ddd61  vmovaps xmm10, [rsp+0x90]
00007431745ddd6a  vmovaps xmm11, [rsp+0xA0]
00007431745ddd73  vmovaps xmm12, [rsp+0xB0]
00007431745ddd7c  vmovaps xmm13, [rsp+0xC0]
00007431745ddd85  vmovaps xmm14, [rsp+0xD0]
00007431745ddd8e  vmovaps xmm15, [rsp+0xE0]
00007431745ddd97  add rsp, 0xF0
00007431745ddd9e  pop r11
00007431745ddda0  pop r10
00007431745ddda2  pop r9
00007431745ddda4  pop r8
00007431745ddda6  pop rsi
00007431745ddda7  pop rdi
00007431745ddda8  pop rdx
00007431745ddda9  pop rcx
00007431745dddaa  pop rax
00007431745dddab  add rsp, 0x08
00007431745dddaf  jmp 0x00007431745DBF7E
00007431745dddb4  call 0x00007431744C4620
00007431745dddb9  jmp 0x00007431745DBF8B
00007431745dddbe  sub rsp, 0x08
00007431745dddc2  push rax
00007431745dddc3  push rcx
00007431745dddc4  push rdx
00007431745dddc5  push rdi
00007431745dddc6  push rsi
00007431745dddc7  push r8
00007431745dddc9  push r9
00007431745dddcb  push r10
00007431745dddcd  push r11
00007431745dddcf  sub rsp, 0xF0
00007431745dddd6  vmovaps [rsp], xmm0
00007431745ddddb  vmovaps [rsp+0x10], xmm2
00007431745ddde1  vmovaps [rsp+0x20], xmm3
00007431745ddde7  vmovaps [rsp+0x30], xmm4
00007431745ddded  vmovaps [rsp+0x40], xmm5
00007431745dddf3  vmovaps [rsp+0x50], xmm6
00007431745dddf9  vmovaps [rsp+0x60], xmm7
00007431745dddff  vmovaps [rsp+0x70], xmm8
00007431745dde05  vmovaps [rsp+0x80], xmm9
00007431745dde0e  vmovaps [rsp+0x90], xmm10
00007431745dde17  vmovaps [rsp+0xA0], xmm11
00007431745dde20  vmovaps [rsp+0xB0], xmm12
00007431745dde29  vmovaps [rsp+0xC0], xmm13
00007431745dde32  vmovaps [rsp+0xD0], xmm14
00007431745dde3b  vmovaps [rsp+0xE0], xmm15
00007431745dde44  sub rsp, 0x30
00007431745dde48  movaps [rsp], xmm1
00007431745dde4c  movaps [rsp+0x10], xmm5
00007431745dde51  movaps [rsp+0x20], xmm7
00007431745dde56  lea rdi, [rsp]
00007431745dde5a  mov esi, 0x00
00007431745dde5f  mov rax, 0x56C40959E530
00007431745dde69  call rax
00007431745dde6b  movaps xmm1, [rsp]
00007431745dde6f  add rsp, 0x30
00007431745dde73  vmovaps xmm0, [rsp]
00007431745dde78  vmovaps xmm2, [rsp+0x10]
00007431745dde7e  vmovaps xmm3, [rsp+0x20]
00007431745dde84  vmovaps xmm4, [rsp+0x30]
00007431745dde8a  vmovaps xmm5, [rsp+0x40]
00007431745dde90  vmovaps xmm6, [rsp+0x50]
00007431745dde96  vmovaps xmm7, [rsp+0x60]
00007431745dde9c  vmovaps xmm8, [rsp+0x70]
00007431745ddea2  vmovaps xmm9, [rsp+0x80]
00007431745ddeab  vmovaps xmm10, [rsp+0x90]
00007431745ddeb4  vmovaps xmm11, [rsp+0xA0]
00007431745ddebd  vmovaps xmm12, [rsp+0xB0]
00007431745ddec6  vmovaps xmm13, [rsp+0xC0]
00007431745ddecf  vmovaps xmm14, [rsp+0xD0]
00007431745dded8  vmovaps xmm15, [rsp+0xE0]
00007431745ddee1  add rsp, 0xF0
00007431745ddee8  pop r11
00007431745ddeea  pop r10
00007431745ddeec  pop r9
00007431745ddeee  pop r8
00007431745ddef0  pop rsi
00007431745ddef1  pop rdi
00007431745ddef2  pop rdx
00007431745ddef3  pop rcx
00007431745ddef4  pop rax
00007431745ddef5  add rsp, 0x08
00007431745ddef9  jmp 0x00007431745DC030
00007431745ddefe  sub rsp, 0x08
00007431745ddf02  push rax
00007431745ddf03  push rcx
00007431745ddf04  push rdx
00007431745ddf05  push rdi
00007431745ddf06  push rsi
00007431745ddf07  push r8
00007431745ddf09  push r9
00007431745ddf0b  push r10
00007431745ddf0d  push r11
00007431745ddf0f  sub rsp, 0xF0
00007431745ddf16  vmovaps [rsp], xmm0
00007431745ddf1b  vmovaps [rsp+0x10], xmm1
00007431745ddf21  vmovaps [rsp+0x20], xmm2
00007431745ddf27  vmovaps [rsp+0x30], xmm3
00007431745ddf2d  vmovaps [rsp+0x40], xmm4
00007431745ddf33  vmovaps [rsp+0x50], xmm5
00007431745ddf39  vmovaps [rsp+0x60], xmm6
00007431745ddf3f  vmovaps [rsp+0x70], xmm8
00007431745ddf45  vmovaps [rsp+0x80], xmm9
00007431745ddf4e  vmovaps [rsp+0x90], xmm10
00007431745ddf57  vmovaps [rsp+0xA0], xmm11
00007431745ddf60  vmovaps [rsp+0xB0], xmm12
00007431745ddf69  vmovaps [rsp+0xC0], xmm13
00007431745ddf72  vmovaps [rsp+0xD0], xmm14
00007431745ddf7b  vmovaps [rsp+0xE0], xmm15
00007431745ddf84  sub rsp, 0x30
00007431745ddf88  movaps [rsp], xmm7
00007431745ddf8c  movaps [rsp+0x10], xmm5
00007431745ddf91  movaps [rsp+0x20], xmm15
00007431745ddf97  lea rdi, [rsp]
00007431745ddf9b  mov esi, 0x00
00007431745ddfa0  mov rax, 0x56C40959E530
00007431745ddfaa  call rax
00007431745ddfac  movaps xmm7, [rsp]
00007431745ddfb0  add rsp, 0x30
00007431745ddfb4  vmovaps xmm0, [rsp]
00007431745ddfb9  vmovaps xmm1, [rsp+0x10]
00007431745ddfbf  vmovaps xmm2, [rsp+0x20]
00007431745ddfc5  vmovaps xmm3, [rsp+0x30]
00007431745ddfcb  vmovaps xmm4, [rsp+0x40]
00007431745ddfd1  vmovaps xmm5, [rsp+0x50]
00007431745ddfd7  vmovaps xmm6, [rsp+0x60]
00007431745ddfdd  vmovaps xmm8, [rsp+0x70]
00007431745ddfe3  vmovaps xmm9, [rsp+0x80]
00007431745ddfec  vmovaps xmm10, [rsp+0x90]
00007431745ddff5  vmovaps xmm11, [rsp+0xA0]
00007431745ddffe  vmovaps xmm12, [rsp+0xB0]
00007431745de007  vmovaps xmm13, [rsp+0xC0]
00007431745de010  vmovaps xmm14, [rsp+0xD0]
00007431745de019  vmovaps xmm15, [rsp+0xE0]
00007431745de022  add rsp, 0xF0
00007431745de029  pop r11
00007431745de02b  pop r10
00007431745de02d  pop r9
00007431745de02f  pop r8
00007431745de031  pop rsi
00007431745de032  pop rdi
00007431745de033  pop rdx
00007431745de034  pop rcx
00007431745de035  pop rax
00007431745de036  add rsp, 0x08
00007431745de03a  jmp 0x00007431745DC066
00007431745de03f  call 0x00007431744B52F0
00007431745de044  jmp 0x00007431745DC073
00007431745de049  sub rsp, 0x08
00007431745de04d  push rax
00007431745de04e  push rcx
00007431745de04f  push rdx
00007431745de050  push rdi
00007431745de051  push rsi
00007431745de052  push r8
00007431745de054  push r9
00007431745de056  push r10
00007431745de058  push r11
00007431745de05a  sub rsp, 0xF0
00007431745de061  vmovaps [rsp], xmm0
00007431745de066  vmovaps [rsp+0x10], xmm1
00007431745de06c  vmovaps [rsp+0x20], xmm2
00007431745de072  vmovaps [rsp+0x30], xmm3
00007431745de078  vmovaps [rsp+0x40], xmm4
00007431745de07e  vmovaps [rsp+0x50], xmm5
00007431745de084  vmovaps [rsp+0x60], xmm6
00007431745de08a  vmovaps [rsp+0x70], xmm7
00007431745de090  vmovaps [rsp+0x80], xmm8
00007431745de099  vmovaps [rsp+0x90], xmm9
00007431745de0a2  vmovaps [rsp+0xA0], xmm10
00007431745de0ab  vmovaps [rsp+0xB0], xmm11
00007431745de0b4  vmovaps [rsp+0xC0], xmm12
00007431745de0bd  vmovaps [rsp+0xD0], xmm13
00007431745de0c6  vmovaps [rsp+0xE0], xmm14
00007431745de0cf  sub rsp, 0x30
00007431745de0d3  movaps [rsp], xmm15
00007431745de0d8  movaps [rsp+0x10], xmm5
00007431745de0dd  movaps [rsp+0x20], xmm3
00007431745de0e2  lea rdi, [rsp]
00007431745de0e6  mov esi, 0x00
00007431745de0eb  mov rax, 0x56C40959E530
00007431745de0f5  call rax
00007431745de0f7  movaps xmm15, [rsp]
00007431745de0fc  add rsp, 0x30
00007431745de100  vmovaps xmm0, [rsp]
00007431745de105  vmovaps xmm1, [rsp+0x10]
00007431745de10b  vmovaps xmm2, [rsp+0x20]
00007431745de111  vmovaps xmm3, [rsp+0x30]
00007431745de117  vmovaps xmm4, [rsp+0x40]
00007431745de11d  vmovaps xmm5, [rsp+0x50]
00007431745de123  vmovaps xmm6, [rsp+0x60]
00007431745de129  vmovaps xmm7, [rsp+0x70]
00007431745de12f  vmovaps xmm8, [rsp+0x80]
00007431745de138  vmovaps xmm9, [rsp+0x90]
00007431745de141  vmovaps xmm10, [rsp+0xA0]
00007431745de14a  vmovaps xmm11, [rsp+0xB0]
00007431745de153  vmovaps xmm12, [rsp+0xC0]
00007431745de15c  vmovaps xmm13, [rsp+0xD0]
00007431745de165  vmovaps xmm14, [rsp+0xE0]
00007431745de16e  add rsp, 0xF0
00007431745de175  pop r11
00007431745de177  pop r10
00007431745de179  pop r9
00007431745de17b  pop r8
00007431745de17d  pop rsi
00007431745de17e  pop rdi
00007431745de17f  pop rdx
00007431745de180  pop rcx
00007431745de181  pop rax
00007431745de182  add rsp, 0x08
00007431745de186  jmp 0x00007431745DC099
00007431745de18b  sub rsp, 0x08
00007431745de18f  push rax
00007431745de190  push rcx
00007431745de191  push rdx
00007431745de192  push rdi
00007431745de193  push rsi
00007431745de194  push r8
00007431745de196  push r9
00007431745de198  push r10
00007431745de19a  push r11
00007431745de19c  sub rsp, 0xF0
00007431745de1a3  vmovaps [rsp], xmm0
00007431745de1a8  vmovaps [rsp+0x10], xmm2
00007431745de1ae  vmovaps [rsp+0x20], xmm3
00007431745de1b4  vmovaps [rsp+0x30], xmm4
00007431745de1ba  vmovaps [rsp+0x40], xmm5
00007431745de1c0  vmovaps [rsp+0x50], xmm6
00007431745de1c6  vmovaps [rsp+0x60], xmm7
00007431745de1cc  vmovaps [rsp+0x70], xmm8
00007431745de1d2  vmovaps [rsp+0x80], xmm9
00007431745de1db  vmovaps [rsp+0x90], xmm10
00007431745de1e4  vmovaps [rsp+0xA0], xmm11
00007431745de1ed  vmovaps [rsp+0xB0], xmm12
00007431745de1f6  vmovaps [rsp+0xC0], xmm13
00007431745de1ff  vmovaps [rsp+0xD0], xmm14
00007431745de208  vmovaps [rsp+0xE0], xmm15
00007431745de211  sub rsp, 0x30
00007431745de215  movaps [rsp], xmm1
00007431745de219  movaps [rsp+0x10], xmm5
00007431745de21e  movaps [rsp+0x20], xmm4
00007431745de223  lea rdi, [rsp]
00007431745de227  mov esi, 0x00
00007431745de22c  mov rax, 0x56C40959E530
00007431745de236  call rax
00007431745de238  movaps xmm1, [rsp]
00007431745de23c  add rsp, 0x30
00007431745de240  vmovaps xmm0, [rsp]
00007431745de245  vmovaps xmm2, [rsp+0x10]
00007431745de24b  vmovaps xmm3, [rsp+0x20]
00007431745de251  vmovaps xmm4, [rsp+0x30]
00007431745de257  vmovaps xmm5, [rsp+0x40]
00007431745de25d  vmovaps xmm6, [rsp+0x50]
00007431745de263  vmovaps xmm7, [rsp+0x60]
00007431745de269  vmovaps xmm8, [rsp+0x70]
00007431745de26f  vmovaps xmm9, [rsp+0x80]
00007431745de278  vmovaps xmm10, [rsp+0x90]
00007431745de281  vmovaps xmm11, [rsp+0xA0]
00007431745de28a  vmovaps xmm12, [rsp+0xB0]
00007431745de293  vmovaps xmm13, [rsp+0xC0]
00007431745de29c  vmovaps xmm14, [rsp+0xD0]
00007431745de2a5  vmovaps xmm15, [rsp+0xE0]
00007431745de2ae  add rsp, 0xF0
00007431745de2b5  pop r11
00007431745de2b7  pop r10
00007431745de2b9  pop r9
00007431745de2bb  pop r8
00007431745de2bd  pop rsi
00007431745de2be  pop rdi
00007431745de2bf  pop rdx
00007431745de2c0  pop rcx
00007431745de2c1  pop rax
00007431745de2c2  add rsp, 0x08
00007431745de2c6  jmp 0x00007431745DC0B9
00007431745de2cb  sub rsp, 0x08
00007431745de2cf  push rax
00007431745de2d0  push rcx
00007431745de2d1  push rdx
00007431745de2d2  push rdi
00007431745de2d3  push rsi
00007431745de2d4  push r8
00007431745de2d6  push r9
00007431745de2d8  push r10
00007431745de2da  push r11
00007431745de2dc  sub rsp, 0xF0
00007431745de2e3  vmovaps [rsp], xmm0
00007431745de2e8  vmovaps [rsp+0x10], xmm1
00007431745de2ee  vmovaps [rsp+0x20], xmm2
00007431745de2f4  vmovaps [rsp+0x30], xmm3
00007431745de2fa  vmovaps [rsp+0x40], xmm5
00007431745de300  vmovaps [rsp+0x50], xmm6
00007431745de306  vmovaps [rsp+0x60], xmm7
00007431745de30c  vmovaps [rsp+0x70], xmm8
00007431745de312  vmovaps [rsp+0x80], xmm9
00007431745de31b  vmovaps [rsp+0x90], xmm10
00007431745de324  vmovaps [rsp+0xA0], xmm11
00007431745de32d  vmovaps [rsp+0xB0], xmm12
00007431745de336  vmovaps [rsp+0xC0], xmm13
00007431745de33f  vmovaps [rsp+0xD0], xmm14
00007431745de348  vmovaps [rsp+0xE0], xmm15
00007431745de351  sub rsp, 0x30
00007431745de355  movaps [rsp], xmm4
00007431745de359  movaps [rsp+0x10], xmm3
00007431745de35e  movaps [rsp+0x20], xmm5
00007431745de363  lea rdi, [rsp]
00007431745de367  mov esi, 0x00
00007431745de36c  mov rax, 0x56C40959E530
00007431745de376  call rax
00007431745de378  movaps xmm4, [rsp]
00007431745de37c  add rsp, 0x30
00007431745de380  vmovaps xmm0, [rsp]
00007431745de385  vmovaps xmm1, [rsp+0x10]
00007431745de38b  vmovaps xmm2, [rsp+0x20]
00007431745de391  vmovaps xmm3, [rsp+0x30]
00007431745de397  vmovaps xmm5, [rsp+0x40]
00007431745de39d  vmovaps xmm6, [rsp+0x50]
00007431745de3a3  vmovaps xmm7, [rsp+0x60]
00007431745de3a9  vmovaps xmm8, [rsp+0x70]
00007431745de3af  vmovaps xmm9, [rsp+0x80]
00007431745de3b8  vmovaps xmm10, [rsp+0x90]
00007431745de3c1  vmovaps xmm11, [rsp+0xA0]
00007431745de3ca  vmovaps xmm12, [rsp+0xB0]
00007431745de3d3  vmovaps xmm13, [rsp+0xC0]
00007431745de3dc  vmovaps xmm14, [rsp+0xD0]
00007431745de3e5  vmovaps xmm15, [rsp+0xE0]
00007431745de3ee  add rsp, 0xF0
00007431745de3f5  pop r11
00007431745de3f7  pop r10
00007431745de3f9  pop r9
00007431745de3fb  pop r8
00007431745de3fd  pop rsi
00007431745de3fe  pop rdi
00007431745de3ff  pop rdx
00007431745de400  pop rcx
00007431745de401  pop rax
00007431745de402  add rsp, 0x08
00007431745de406  jmp 0x00007431745DC107
00007431745de40b  call 0x00007431744B52F0
00007431745de410  jmp 0x00007431745DC114
00007431745de415  sub rsp, 0x08
00007431745de419  push rax
00007431745de41a  push rcx
00007431745de41b  push rdx
00007431745de41c  push rdi
00007431745de41d  push rsi
00007431745de41e  push r8
00007431745de420  push r9
00007431745de422  push r10
00007431745de424  push r11
00007431745de426  sub rsp, 0xF0
00007431745de42d  vmovaps [rsp], xmm0
00007431745de432  vmovaps [rsp+0x10], xmm1
00007431745de438  vmovaps [rsp+0x20], xmm2
00007431745de43e  vmovaps [rsp+0x30], xmm3
00007431745de444  vmovaps [rsp+0x40], xmm4
00007431745de44a  vmovaps [rsp+0x50], xmm6
00007431745de450  vmovaps [rsp+0x60], xmm7
00007431745de456  vmovaps [rsp+0x70], xmm8
00007431745de45c  vmovaps [rsp+0x80], xmm9
00007431745de465  vmovaps [rsp+0x90], xmm10
00007431745de46e  vmovaps [rsp+0xA0], xmm11
00007431745de477  vmovaps [rsp+0xB0], xmm12
00007431745de480  vmovaps [rsp+0xC0], xmm13
00007431745de489  vmovaps [rsp+0xD0], xmm14
00007431745de492  vmovaps [rsp+0xE0], xmm15
00007431745de49b  sub rsp, 0x30
00007431745de49f  movaps [rsp], xmm5
00007431745de4a3  movaps [rsp+0x10], xmm6
00007431745de4a8  movaps [rsp+0x20], xmm3
00007431745de4ad  lea rdi, [rsp]
00007431745de4b1  mov esi, 0x00
00007431745de4b6  mov rax, 0x56C40959E530
00007431745de4c0  call rax
00007431745de4c2  movaps xmm5, [rsp]
00007431745de4c6  add rsp, 0x30
00007431745de4ca  vmovaps xmm0, [rsp]
00007431745de4cf  vmovaps xmm1, [rsp+0x10]
00007431745de4d5  vmovaps xmm2, [rsp+0x20]
00007431745de4db  vmovaps xmm3, [rsp+0x30]
00007431745de4e1  vmovaps xmm4, [rsp+0x40]
00007431745de4e7  vmovaps xmm6, [rsp+0x50]
00007431745de4ed  vmovaps xmm7, [rsp+0x60]
00007431745de4f3  vmovaps xmm8, [rsp+0x70]
00007431745de4f9  vmovaps xmm9, [rsp+0x80]
00007431745de502  vmovaps xmm10, [rsp+0x90]
00007431745de50b  vmovaps xmm11, [rsp+0xA0]
00007431745de514  vmovaps xmm12, [rsp+0xB0]
00007431745de51d  vmovaps xmm13, [rsp+0xC0]
00007431745de526  vmovaps xmm14, [rsp+0xD0]
00007431745de52f  vmovaps xmm15, [rsp+0xE0]
00007431745de538  add rsp, 0xF0
00007431745de53f  pop r11
00007431745de541  pop r10
00007431745de543  pop r9
00007431745de545  pop r8
00007431745de547  pop rsi
00007431745de548  pop rdi
00007431745de549  pop rdx
00007431745de54a  pop rcx
00007431745de54b  pop rax
00007431745de54c  add rsp, 0x08
00007431745de550  jmp 0x00007431745DC13A
00007431745de555  sub rsp, 0x08
00007431745de559  push rax
00007431745de55a  push rcx
00007431745de55b  push rdx
00007431745de55c  push rdi
00007431745de55d  push rsi
00007431745de55e  push r8
00007431745de560  push r9
00007431745de562  push r10
00007431745de564  push r11
00007431745de566  sub rsp, 0xF0
00007431745de56d  vmovaps [rsp], xmm0
00007431745de572  vmovaps [rsp+0x10], xmm1
00007431745de578  vmovaps [rsp+0x20], xmm2
00007431745de57e  vmovaps [rsp+0x30], xmm3
00007431745de584  vmovaps [rsp+0x40], xmm4
00007431745de58a  vmovaps [rsp+0x50], xmm5
00007431745de590  vmovaps [rsp+0x60], xmm7
00007431745de596  vmovaps [rsp+0x70], xmm8
00007431745de59c  vmovaps [rsp+0x80], xmm9
00007431745de5a5  vmovaps [rsp+0x90], xmm10
00007431745de5ae  vmovaps [rsp+0xA0], xmm11
00007431745de5b7  vmovaps [rsp+0xB0], xmm12
00007431745de5c0  vmovaps [rsp+0xC0], xmm13
00007431745de5c9  vmovaps [rsp+0xD0], xmm14
00007431745de5d2  vmovaps [rsp+0xE0], xmm15
00007431745de5db  sub rsp, 0x30
00007431745de5df  movaps [rsp], xmm6
00007431745de5e3  movaps [rsp+0x10], xmm9
00007431745de5e9  movaps [rsp+0x20], xmm1
00007431745de5ee  lea rdi, [rsp]
00007431745de5f2  mov esi, 0x00
00007431745de5f7  mov rax, 0x56C40959E530
00007431745de601  call rax
00007431745de603  movaps xmm6, [rsp]
00007431745de607  add rsp, 0x30
00007431745de60b  vmovaps xmm0, [rsp]
00007431745de610  vmovaps xmm1, [rsp+0x10]
00007431745de616  vmovaps xmm2, [rsp+0x20]
00007431745de61c  vmovaps xmm3, [rsp+0x30]
00007431745de622  vmovaps xmm4, [rsp+0x40]
00007431745de628  vmovaps xmm5, [rsp+0x50]
00007431745de62e  vmovaps xmm7, [rsp+0x60]
00007431745de634  vmovaps xmm8, [rsp+0x70]
00007431745de63a  vmovaps xmm9, [rsp+0x80]
00007431745de643  vmovaps xmm10, [rsp+0x90]
00007431745de64c  vmovaps xmm11, [rsp+0xA0]
00007431745de655  vmovaps xmm12, [rsp+0xB0]
00007431745de65e  vmovaps xmm13, [rsp+0xC0]
00007431745de667  vmovaps xmm14, [rsp+0xD0]
00007431745de670  vmovaps xmm15, [rsp+0xE0]
00007431745de679  add rsp, 0xF0
00007431745de680  pop r11
00007431745de682  pop r10
00007431745de684  pop r9
00007431745de686  pop r8
00007431745de688  pop rsi
00007431745de689  pop rdi
00007431745de68a  pop rdx
00007431745de68b  pop rcx
00007431745de68c  pop rax
00007431745de68d  add rsp, 0x08
00007431745de691  jmp 0x00007431745DC15E
00007431745de696  sub rsp, 0x08
00007431745de69a  push rax
00007431745de69b  push rcx
00007431745de69c  push rdx
00007431745de69d  push rdi
00007431745de69e  push rsi
00007431745de69f  push r8
00007431745de6a1  push r9
00007431745de6a3  push r10
00007431745de6a5  push r11
00007431745de6a7  sub rsp, 0xF0
00007431745de6ae  vmovaps [rsp], xmm0
00007431745de6b3  vmovaps [rsp+0x10], xmm1
00007431745de6b9  vmovaps [rsp+0x20], xmm2
00007431745de6bf  vmovaps [rsp+0x30], xmm3
00007431745de6c5  vmovaps [rsp+0x40], xmm4
00007431745de6cb  vmovaps [rsp+0x50], xmm5
00007431745de6d1  vmovaps [rsp+0x60], xmm6
00007431745de6d7  vmovaps [rsp+0x70], xmm7
00007431745de6dd  vmovaps [rsp+0x80], xmm8
00007431745de6e6  vmovaps [rsp+0x90], xmm10
00007431745de6ef  vmovaps [rsp+0xA0], xmm11
00007431745de6f8  vmovaps [rsp+0xB0], xmm12
00007431745de701  vmovaps [rsp+0xC0], xmm13
00007431745de70a  vmovaps [rsp+0xD0], xmm14
00007431745de713  vmovaps [rsp+0xE0], xmm15
00007431745de71c  sub rsp, 0x30
00007431745de720  movaps [rsp], xmm9
00007431745de725  movaps [rsp+0x10], xmm3
00007431745de72a  movaps [rsp+0x20], xmm1
00007431745de72f  lea rdi, [rsp]
00007431745de733  mov esi, 0x00
00007431745de738  mov rax, 0x56C40959E530
00007431745de742  call rax
00007431745de744  movaps xmm9, [rsp]
00007431745de749  add rsp, 0x30
00007431745de74d  vmovaps xmm0, [rsp]
00007431745de752  vmovaps xmm1, [rsp+0x10]
00007431745de758  vmovaps xmm2, [rsp+0x20]
00007431745de75e  vmovaps xmm3, [rsp+0x30]
00007431745de764  vmovaps xmm4, [rsp+0x40]
00007431745de76a  vmovaps xmm5, [rsp+0x50]
00007431745de770  vmovaps xmm6, [rsp+0x60]
00007431745de776  vmovaps xmm7, [rsp+0x70]
00007431745de77c  vmovaps xmm8, [rsp+0x80]
00007431745de785  vmovaps xmm10, [rsp+0x90]
00007431745de78e  vmovaps xmm11, [rsp+0xA0]
00007431745de797  vmovaps xmm12, [rsp+0xB0]
00007431745de7a0  vmovaps xmm13, [rsp+0xC0]
00007431745de7a9  vmovaps xmm14, [rsp+0xD0]
00007431745de7b2  vmovaps xmm15, [rsp+0xE0]
00007431745de7bb  add rsp, 0xF0
00007431745de7c2  pop r11
00007431745de7c4  pop r10
00007431745de7c6  pop r9
00007431745de7c8  pop r8
00007431745de7ca  pop rsi
00007431745de7cb  pop rdi
00007431745de7cc  pop rdx
00007431745de7cd  pop rcx
00007431745de7ce  pop rax
00007431745de7cf  add rsp, 0x08
00007431745de7d3  jmp 0x00007431745DC1AA
00007431745de7d8  call 0x00007431744B52F0
00007431745de7dd  jmp 0x00007431745DC1B7
00007431745de7e2  sub rsp, 0x08
00007431745de7e6  push rax
00007431745de7e7  push rcx
00007431745de7e8  push rdx
00007431745de7e9  push rdi
00007431745de7ea  push rsi
00007431745de7eb  push r8
00007431745de7ed  push r9
00007431745de7ef  push r10
00007431745de7f1  push r11
00007431745de7f3  sub rsp, 0xF0
00007431745de7fa  vmovaps [rsp], xmm0
00007431745de7ff  vmovaps [rsp+0x10], xmm1
00007431745de805  vmovaps [rsp+0x20], xmm2
00007431745de80b  vmovaps [rsp+0x30], xmm3
00007431745de811  vmovaps [rsp+0x40], xmm4
00007431745de817  vmovaps [rsp+0x50], xmm5
00007431745de81d  vmovaps [rsp+0x60], xmm6
00007431745de823  vmovaps [rsp+0x70], xmm7
00007431745de829  vmovaps [rsp+0x80], xmm8
00007431745de832  vmovaps [rsp+0x90], xmm9
00007431745de83b  vmovaps [rsp+0xA0], xmm10
00007431745de844  vmovaps [rsp+0xB0], xmm11
00007431745de84d  vmovaps [rsp+0xC0], xmm12
00007431745de856  vmovaps [rsp+0xD0], xmm13
00007431745de85f  vmovaps [rsp+0xE0], xmm14
00007431745de868  sub rsp, 0x30
00007431745de86c  movaps [rsp], xmm15
00007431745de871  movaps [rsp+0x10], xmm3
00007431745de876  movaps [rsp+0x20], xmm7
00007431745de87b  lea rdi, [rsp]
00007431745de87f  mov esi, 0x00
00007431745de884  mov rax, 0x56C40959E530
00007431745de88e  call rax
00007431745de890  movaps xmm15, [rsp]
00007431745de895  add rsp, 0x30
00007431745de899  vmovaps xmm0, [rsp]
00007431745de89e  vmovaps xmm1, [rsp+0x10]
00007431745de8a4  vmovaps xmm2, [rsp+0x20]
00007431745de8aa  vmovaps xmm3, [rsp+0x30]
00007431745de8b0  vmovaps xmm4, [rsp+0x40]
00007431745de8b6  vmovaps xmm5, [rsp+0x50]
00007431745de8bc  vmovaps xmm6, [rsp+0x60]
00007431745de8c2  vmovaps xmm7, [rsp+0x70]
00007431745de8c8  vmovaps xmm8, [rsp+0x80]
00007431745de8d1  vmovaps xmm9, [rsp+0x90]
00007431745de8da  vmovaps xmm10, [rsp+0xA0]
00007431745de8e3  vmovaps xmm11, [rsp+0xB0]
00007431745de8ec  vmovaps xmm12, [rsp+0xC0]
00007431745de8f5  vmovaps xmm13, [rsp+0xD0]
00007431745de8fe  vmovaps xmm14, [rsp+0xE0]
00007431745de907  add rsp, 0xF0
00007431745de90e  pop r11
00007431745de910  pop r10
00007431745de912  pop r9
00007431745de914  pop r8
00007431745de916  pop rsi
00007431745de917  pop rdi
00007431745de918  pop rdx
00007431745de919  pop rcx
00007431745de91a  pop rax
00007431745de91b  add rsp, 0x08
00007431745de91f  jmp 0x00007431745DC1E3
00007431745de924  sub rsp, 0x08
00007431745de928  push rax
00007431745de929  push rcx
00007431745de92a  push rdx
00007431745de92b  push rdi
00007431745de92c  push rsi
00007431745de92d  push r8
00007431745de92f  push r9
00007431745de931  push r10
00007431745de933  push r11
00007431745de935  sub rsp, 0xF0
00007431745de93c  vmovaps [rsp], xmm0
00007431745de941  vmovaps [rsp+0x10], xmm1
00007431745de947  vmovaps [rsp+0x20], xmm2
00007431745de94d  vmovaps [rsp+0x30], xmm4
00007431745de953  vmovaps [rsp+0x40], xmm5
00007431745de959  vmovaps [rsp+0x50], xmm6
00007431745de95f  vmovaps [rsp+0x60], xmm7
00007431745de965  vmovaps [rsp+0x70], xmm8
00007431745de96b  vmovaps [rsp+0x80], xmm9
00007431745de974  vmovaps [rsp+0x90], xmm10
00007431745de97d  vmovaps [rsp+0xA0], xmm11
00007431745de986  vmovaps [rsp+0xB0], xmm12
00007431745de98f  vmovaps [rsp+0xC0], xmm13
00007431745de998  vmovaps [rsp+0xD0], xmm14
00007431745de9a1  vmovaps [rsp+0xE0], xmm15
00007431745de9aa  sub rsp, 0x30
00007431745de9ae  movaps [rsp], xmm3
00007431745de9b2  movaps [rsp+0x10], xmm1
00007431745de9b7  movaps [rsp+0x20], xmm15
00007431745de9bd  lea rdi, [rsp]
00007431745de9c1  mov esi, 0x00
00007431745de9c6  mov rax, 0x56C40959E530
00007431745de9d0  call rax
00007431745de9d2  movaps xmm3, [rsp]
00007431745de9d6  add rsp, 0x30
00007431745de9da  vmovaps xmm0, [rsp]
00007431745de9df  vmovaps xmm1, [rsp+0x10]
00007431745de9e5  vmovaps xmm2, [rsp+0x20]
00007431745de9eb  vmovaps xmm4, [rsp+0x30]
00007431745de9f1  vmovaps xmm5, [rsp+0x40]
00007431745de9f7  vmovaps xmm6, [rsp+0x50]
00007431745de9fd  vmovaps xmm7, [rsp+0x60]
00007431745dea03  vmovaps xmm8, [rsp+0x70]
00007431745dea09  vmovaps xmm9, [rsp+0x80]
00007431745dea12  vmovaps xmm10, [rsp+0x90]
00007431745dea1b  vmovaps xmm11, [rsp+0xA0]
00007431745dea24  vmovaps xmm12, [rsp+0xB0]
00007431745dea2d  vmovaps xmm13, [rsp+0xC0]
00007431745dea36  vmovaps xmm14, [rsp+0xD0]
00007431745dea3f  vmovaps xmm15, [rsp+0xE0]
00007431745dea48  add rsp, 0xF0
00007431745dea4f  pop r11
00007431745dea51  pop r10
00007431745dea53  pop r9
00007431745dea55  pop r8
00007431745dea57  pop rsi
00007431745dea58  pop rdi
00007431745dea59  pop rdx
00007431745dea5a  pop rcx
00007431745dea5b  pop rax
00007431745dea5c  add rsp, 0x08
00007431745dea60  jmp 0x00007431745DC272
00007431745dea65  call 0x00007431744B52F0
00007431745dea6a  jmp 0x00007431745DC27C
00007431745dea6f  sub rsp, 0x08
00007431745dea73  push rax
00007431745dea74  push rcx
00007431745dea75  push rdx
00007431745dea76  push rdi
00007431745dea77  push rsi
00007431745dea78  push r8
00007431745dea7a  push r9
00007431745dea7c  push r10
00007431745dea7e  push r11
00007431745dea80  sub rsp, 0xF0
00007431745dea87  vmovaps [rsp], xmm0
00007431745dea8c  vmovaps [rsp+0x10], xmm1
00007431745dea92  vmovaps [rsp+0x20], xmm2
00007431745dea98  vmovaps [rsp+0x30], xmm3
00007431745dea9e  vmovaps [rsp+0x40], xmm4
00007431745deaa4  vmovaps [rsp+0x50], xmm5
00007431745deaaa  vmovaps [rsp+0x60], xmm6
00007431745deab0  vmovaps [rsp+0x70], xmm7
00007431745deab6  vmovaps [rsp+0x80], xmm8
00007431745deabf  vmovaps [rsp+0x90], xmm9
00007431745deac8  vmovaps [rsp+0xA0], xmm10
00007431745dead1  vmovaps [rsp+0xB0], xmm11
00007431745deada  vmovaps [rsp+0xC0], xmm12
00007431745deae3  vmovaps [rsp+0xD0], xmm13
00007431745deaec  vmovaps [rsp+0xE0], xmm14
00007431745deaf5  sub rsp, 0x30
00007431745deaf9  movaps [rsp], xmm15
00007431745deafe  movaps [rsp+0x10], xmm14
00007431745deb04  movaps [rsp+0x20], xmm4
00007431745deb09  lea rdi, [rsp]
00007431745deb0d  mov esi, 0x00
00007431745deb12  mov rax, 0x56C40959E530
00007431745deb1c  call rax
00007431745deb1e  movaps xmm15, [rsp]
00007431745deb23  add rsp, 0x30
00007431745deb27  vmovaps xmm0, [rsp]
00007431745deb2c  vmovaps xmm1, [rsp+0x10]
00007431745deb32  vmovaps xmm2, [rsp+0x20]
00007431745deb38  vmovaps xmm3, [rsp+0x30]
00007431745deb3e  vmovaps xmm4, [rsp+0x40]
00007431745deb44  vmovaps xmm5, [rsp+0x50]
00007431745deb4a  vmovaps xmm6, [rsp+0x60]
00007431745deb50  vmovaps xmm7, [rsp+0x70]
00007431745deb56  vmovaps xmm8, [rsp+0x80]
00007431745deb5f  vmovaps xmm9, [rsp+0x90]
00007431745deb68  vmovaps xmm10, [rsp+0xA0]
00007431745deb71  vmovaps xmm11, [rsp+0xB0]
00007431745deb7a  vmovaps xmm12, [rsp+0xC0]
00007431745deb83  vmovaps xmm13, [rsp+0xD0]
00007431745deb8c  vmovaps xmm14, [rsp+0xE0]
00007431745deb95  add rsp, 0xF0
00007431745deb9c  pop r11
00007431745deb9e  pop r10
00007431745deba0  pop r9
00007431745deba2  pop r8
00007431745deba4  pop rsi
00007431745deba5  pop rdi
00007431745deba6  pop rdx
00007431745deba7  pop rcx
00007431745deba8  pop rax
00007431745deba9  add rsp, 0x08
00007431745debad  jmp 0x00007431745DC2AA
00007431745debb2  sub rsp, 0x08
00007431745debb6  push rax
00007431745debb7  push rcx
00007431745debb8  push rdx
00007431745debb9  push rdi
00007431745debba  push rsi
00007431745debbb  push r8
00007431745debbd  push r9
00007431745debbf  push r10
00007431745debc1  push r11
00007431745debc3  sub rsp, 0xF0
00007431745debca  vmovaps [rsp], xmm0
00007431745debcf  vmovaps [rsp+0x10], xmm1
00007431745debd5  vmovaps [rsp+0x20], xmm2
00007431745debdb  vmovaps [rsp+0x30], xmm3
00007431745debe1  vmovaps [rsp+0x40], xmm4
00007431745debe7  vmovaps [rsp+0x50], xmm5
00007431745debed  vmovaps [rsp+0x60], xmm6
00007431745debf3  vmovaps [rsp+0x70], xmm7
00007431745debf9  vmovaps [rsp+0x80], xmm8
00007431745dec02  vmovaps [rsp+0x90], xmm9
00007431745dec0b  vmovaps [rsp+0xA0], xmm10
00007431745dec14  vmovaps [rsp+0xB0], xmm11
00007431745dec1d  vmovaps [rsp+0xC0], xmm12
00007431745dec26  vmovaps [rsp+0xD0], xmm13
00007431745dec2f  vmovaps [rsp+0xE0], xmm15
00007431745dec38  sub rsp, 0x30
00007431745dec3c  movaps [rsp], xmm14
00007431745dec41  movaps [rsp+0x10], xmm2
00007431745dec46  movaps [rsp+0x20], xmm1
00007431745dec4b  lea rdi, [rsp]
00007431745dec4f  mov esi, 0x00
00007431745dec54  mov rax, 0x56C40959E530
00007431745dec5e  call rax
00007431745dec60  movaps xmm14, [rsp]
00007431745dec65  add rsp, 0x30
00007431745dec69  vmovaps xmm0, [rsp]
00007431745dec6e  vmovaps xmm1, [rsp+0x10]
00007431745dec74  vmovaps xmm2, [rsp+0x20]
00007431745dec7a  vmovaps xmm3, [rsp+0x30]
00007431745dec80  vmovaps xmm4, [rsp+0x40]
00007431745dec86  vmovaps xmm5, [rsp+0x50]
00007431745dec8c  vmovaps xmm6, [rsp+0x60]
00007431745dec92  vmovaps xmm7, [rsp+0x70]
00007431745dec98  vmovaps xmm8, [rsp+0x80]
00007431745deca1  vmovaps xmm9, [rsp+0x90]
00007431745decaa  vmovaps xmm10, [rsp+0xA0]
00007431745decb3  vmovaps xmm11, [rsp+0xB0]
00007431745decbc  vmovaps xmm12, [rsp+0xC0]
00007431745decc5  vmovaps xmm13, [rsp+0xD0]
00007431745decce  vmovaps xmm15, [rsp+0xE0]
00007431745decd7  add rsp, 0xF0
00007431745decde  pop r11
00007431745dece0  pop r10
00007431745dece2  pop r9
00007431745dece4  pop r8
00007431745dece6  pop rsi
00007431745dece7  pop rdi
00007431745dece8  pop rdx
00007431745dece9  pop rcx
00007431745decea  pop rax
00007431745deceb  add rsp, 0x08
00007431745decef  jmp 0x00007431745DC2D0
00007431745decf4  sub rsp, 0x08
00007431745decf8  push rax
00007431745decf9  push rcx
00007431745decfa  push rdx
00007431745decfb  push rdi
00007431745decfc  push rsi
00007431745decfd  push r8
00007431745decff  push r9
00007431745ded01  push r10
00007431745ded03  push r11
00007431745ded05  sub rsp, 0xF0
00007431745ded0c  vmovaps [rsp], xmm0
00007431745ded11  vmovaps [rsp+0x10], xmm2
00007431745ded17  vmovaps [rsp+0x20], xmm3
00007431745ded1d  vmovaps [rsp+0x30], xmm4
00007431745ded23  vmovaps [rsp+0x40], xmm5
00007431745ded29  vmovaps [rsp+0x50], xmm6
00007431745ded2f  vmovaps [rsp+0x60], xmm7
00007431745ded35  vmovaps [rsp+0x70], xmm8
00007431745ded3b  vmovaps [rsp+0x80], xmm9
00007431745ded44  vmovaps [rsp+0x90], xmm10
00007431745ded4d  vmovaps [rsp+0xA0], xmm11
00007431745ded56  vmovaps [rsp+0xB0], xmm12
00007431745ded5f  vmovaps [rsp+0xC0], xmm13
00007431745ded68  vmovaps [rsp+0xD0], xmm14
00007431745ded71  vmovaps [rsp+0xE0], xmm15
00007431745ded7a  sub rsp, 0x30
00007431745ded7e  movaps [rsp], xmm1
00007431745ded82  movaps [rsp+0x10], xmm4
00007431745ded87  movaps [rsp+0x20], xmm9
00007431745ded8d  lea rdi, [rsp]
00007431745ded91  mov esi, 0x00
00007431745ded96  mov rax, 0x56C40959E530
00007431745deda0  call rax
00007431745deda2  movaps xmm1, [rsp]
00007431745deda6  add rsp, 0x30
00007431745dedaa  vmovaps xmm0, [rsp]
00007431745dedaf  vmovaps xmm2, [rsp+0x10]
00007431745dedb5  vmovaps xmm3, [rsp+0x20]
00007431745dedbb  vmovaps xmm4, [rsp+0x30]
00007431745dedc1  vmovaps xmm5, [rsp+0x40]
00007431745dedc7  vmovaps xmm6, [rsp+0x50]
00007431745dedcd  vmovaps xmm7, [rsp+0x60]
00007431745dedd3  vmovaps xmm8, [rsp+0x70]
00007431745dedd9  vmovaps xmm9, [rsp+0x80]
00007431745dede2  vmovaps xmm10, [rsp+0x90]
00007431745dedeb  vmovaps xmm11, [rsp+0xA0]
00007431745dedf4  vmovaps xmm12, [rsp+0xB0]
00007431745dedfd  vmovaps xmm13, [rsp+0xC0]
00007431745dee06  vmovaps xmm14, [rsp+0xD0]
00007431745dee0f  vmovaps xmm15, [rsp+0xE0]
00007431745dee18  add rsp, 0xF0
00007431745dee1f  pop r11
00007431745dee21  pop r10
00007431745dee23  pop r9
00007431745dee25  pop r8
00007431745dee27  pop rsi
00007431745dee28  pop rdi
00007431745dee29  pop rdx
00007431745dee2a  pop rcx
00007431745dee2b  pop rax
00007431745dee2c  add rsp, 0x08
00007431745dee30  jmp 0x00007431745DC2EE
00007431745dee35  sub rsp, 0x08
00007431745dee39  push rax
00007431745dee3a  push rcx
00007431745dee3b  push rdx
00007431745dee3c  push rdi
00007431745dee3d  push rsi
00007431745dee3e  push r8
00007431745dee40  push r9
00007431745dee42  push r10
00007431745dee44  push r11
00007431745dee46  sub rsp, 0xF0
00007431745dee4d  vmovaps [rsp], xmm0
00007431745dee52  vmovaps [rsp+0x10], xmm1
00007431745dee58  vmovaps [rsp+0x20], xmm2
00007431745dee5e  vmovaps [rsp+0x30], xmm3
00007431745dee64  vmovaps [rsp+0x40], xmm5
00007431745dee6a  vmovaps [rsp+0x50], xmm6
00007431745dee70  vmovaps [rsp+0x60], xmm7
00007431745dee76  vmovaps [rsp+0x70], xmm8
00007431745dee7c  vmovaps [rsp+0x80], xmm9
00007431745dee85  vmovaps [rsp+0x90], xmm10
00007431745dee8e  vmovaps [rsp+0xA0], xmm11
00007431745dee97  vmovaps [rsp+0xB0], xmm12
00007431745deea0  vmovaps [rsp+0xC0], xmm13
00007431745deea9  vmovaps [rsp+0xD0], xmm14
00007431745deeb2  vmovaps [rsp+0xE0], xmm15
00007431745deebb  sub rsp, 0x30
00007431745deebf  movaps [rsp], xmm4
00007431745deec3  movaps [rsp+0x10], xmm2
00007431745deec8  movaps [rsp+0x20], xmm9
00007431745deece  lea rdi, [rsp]
00007431745deed2  mov esi, 0x00
00007431745deed7  mov rax, 0x56C40959E530
00007431745deee1  call rax
00007431745deee3  movaps xmm4, [rsp]
00007431745deee7  add rsp, 0x30
00007431745deeeb  vmovaps xmm0, [rsp]
00007431745deef0  vmovaps xmm1, [rsp+0x10]
00007431745deef6  vmovaps xmm2, [rsp+0x20]
00007431745deefc  vmovaps xmm3, [rsp+0x30]
00007431745def02  vmovaps xmm5, [rsp+0x40]
00007431745def08  vmovaps xmm6, [rsp+0x50]
00007431745def0e  vmovaps xmm7, [rsp+0x60]
00007431745def14  vmovaps xmm8, [rsp+0x70]
00007431745def1a  vmovaps xmm9, [rsp+0x80]
00007431745def23  vmovaps xmm10, [rsp+0x90]
00007431745def2c  vmovaps xmm11, [rsp+0xA0]
00007431745def35  vmovaps xmm12, [rsp+0xB0]
00007431745def3e  vmovaps xmm13, [rsp+0xC0]
00007431745def47  vmovaps xmm14, [rsp+0xD0]
00007431745def50  vmovaps xmm15, [rsp+0xE0]
00007431745def59  add rsp, 0xF0
00007431745def60  pop r11
00007431745def62  pop r10
00007431745def64  pop r9
00007431745def66  pop r8
00007431745def68  pop rsi
00007431745def69  pop rdi
00007431745def6a  pop rdx
00007431745def6b  pop rcx
00007431745def6c  pop rax
00007431745def6d  add rsp, 0x08
00007431745def71  jmp 0x00007431745DC31E
00007431745def76  sub rsp, 0x08
00007431745def7a  push rax
00007431745def7b  push rcx
00007431745def7c  push rdx
00007431745def7d  push rdi
00007431745def7e  push rsi
00007431745def7f  push r8
00007431745def81  push r9
00007431745def83  push r10
00007431745def85  push r11
00007431745def87  sub rsp, 0xF0
00007431745def8e  vmovaps [rsp], xmm0
00007431745def93  vmovaps [rsp+0x10], xmm1
00007431745def99  vmovaps [rsp+0x20], xmm2
00007431745def9f  vmovaps [rsp+0x30], xmm3
00007431745defa5  vmovaps [rsp+0x40], xmm4
00007431745defab  vmovaps [rsp+0x50], xmm5
00007431745defb1  vmovaps [rsp+0x60], xmm6
00007431745defb7  vmovaps [rsp+0x70], xmm7
00007431745defbd  vmovaps [rsp+0x80], xmm8
00007431745defc6  vmovaps [rsp+0x90], xmm10
00007431745defcf  vmovaps [rsp+0xA0], xmm11
00007431745defd8  vmovaps [rsp+0xB0], xmm12
00007431745defe1  vmovaps [rsp+0xC0], xmm13
00007431745defea  vmovaps [rsp+0xD0], xmm14
00007431745deff3  vmovaps [rsp+0xE0], xmm15
00007431745deffc  sub rsp, 0x30
00007431745df000  movaps [rsp], xmm9
00007431745df005  movaps [rsp+0x10], xmm2
00007431745df00a  movaps [rsp+0x20], xmm1
00007431745df00f  lea rdi, [rsp]
00007431745df013  mov esi, 0x00
00007431745df018  mov rax, 0x56C40959E530
00007431745df022  call rax
00007431745df024  movaps xmm9, [rsp]
00007431745df029  add rsp, 0x30
00007431745df02d  vmovaps xmm0, [rsp]
00007431745df032  vmovaps xmm1, [rsp+0x10]
00007431745df038  vmovaps xmm2, [rsp+0x20]
00007431745df03e  vmovaps xmm3, [rsp+0x30]
00007431745df044  vmovaps xmm4, [rsp+0x40]
00007431745df04a  vmovaps xmm5, [rsp+0x50]
00007431745df050  vmovaps xmm6, [rsp+0x60]
00007431745df056  vmovaps xmm7, [rsp+0x70]
00007431745df05c  vmovaps xmm8, [rsp+0x80]
00007431745df065  vmovaps xmm10, [rsp+0x90]
00007431745df06e  vmovaps xmm11, [rsp+0xA0]
00007431745df077  vmovaps xmm12, [rsp+0xB0]
00007431745df080  vmovaps xmm13, [rsp+0xC0]
00007431745df089  vmovaps xmm14, [rsp+0xD0]
00007431745df092  vmovaps xmm15, [rsp+0xE0]
00007431745df09b  add rsp, 0xF0
00007431745df0a2  pop r11
00007431745df0a4  pop r10
00007431745df0a6  pop r9
00007431745df0a8  pop r8
00007431745df0aa  pop rsi
00007431745df0ab  pop rdi
00007431745df0ac  pop rdx
00007431745df0ad  pop rcx
00007431745df0ae  pop rax
00007431745df0af  add rsp, 0x08
00007431745df0b3  jmp 0x00007431745DC354
00007431745df0b8  sub rsp, 0x08
00007431745df0bc  push rax
00007431745df0bd  push rcx
00007431745df0be  push rdx
00007431745df0bf  push rdi
00007431745df0c0  push rsi
00007431745df0c1  push r8
00007431745df0c3  push r9
00007431745df0c5  push r10
00007431745df0c7  push r11
00007431745df0c9  sub rsp, 0xF0
00007431745df0d0  vmovaps [rsp], xmm0
00007431745df0d5  vmovaps [rsp+0x10], xmm2
00007431745df0db  vmovaps [rsp+0x20], xmm3
00007431745df0e1  vmovaps [rsp+0x30], xmm4
00007431745df0e7  vmovaps [rsp+0x40], xmm5
00007431745df0ed  vmovaps [rsp+0x50], xmm6
00007431745df0f3  vmovaps [rsp+0x60], xmm7
00007431745df0f9  vmovaps [rsp+0x70], xmm8
00007431745df0ff  vmovaps [rsp+0x80], xmm9
00007431745df108  vmovaps [rsp+0x90], xmm10
00007431745df111  vmovaps [rsp+0xA0], xmm11
00007431745df11a  vmovaps [rsp+0xB0], xmm12
00007431745df123  vmovaps [rsp+0xC0], xmm13
00007431745df12c  vmovaps [rsp+0xD0], xmm14
00007431745df135  vmovaps [rsp+0xE0], xmm15
00007431745df13e  sub rsp, 0x30
00007431745df142  movaps [rsp], xmm1
00007431745df146  movaps [rsp+0x10], xmm15
00007431745df14c  movaps [rsp+0x20], xmm6
00007431745df151  lea rdi, [rsp]
00007431745df155  mov esi, 0x00
00007431745df15a  mov rax, 0x56C40959E530
00007431745df164  call rax
00007431745df166  movaps xmm1, [rsp]
00007431745df16a  add rsp, 0x30
00007431745df16e  vmovaps xmm0, [rsp]
00007431745df173  vmovaps xmm2, [rsp+0x10]
00007431745df179  vmovaps xmm3, [rsp+0x20]
00007431745df17f  vmovaps xmm4, [rsp+0x30]
00007431745df185  vmovaps xmm5, [rsp+0x40]
00007431745df18b  vmovaps xmm6, [rsp+0x50]
00007431745df191  vmovaps xmm7, [rsp+0x60]
00007431745df197  vmovaps xmm8, [rsp+0x70]
00007431745df19d  vmovaps xmm9, [rsp+0x80]
00007431745df1a6  vmovaps xmm10, [rsp+0x90]
00007431745df1af  vmovaps xmm11, [rsp+0xA0]
00007431745df1b8  vmovaps xmm12, [rsp+0xB0]
00007431745df1c1  vmovaps xmm13, [rsp+0xC0]
00007431745df1ca  vmovaps xmm14, [rsp+0xD0]
00007431745df1d3  vmovaps xmm15, [rsp+0xE0]
00007431745df1dc  add rsp, 0xF0
00007431745df1e3  pop r11
00007431745df1e5  pop r10
00007431745df1e7  pop r9
00007431745df1e9  pop r8
00007431745df1eb  pop rsi
00007431745df1ec  pop rdi
00007431745df1ed  pop rdx
00007431745df1ee  pop rcx
00007431745df1ef  pop rax
00007431745df1f0  add rsp, 0x08
00007431745df1f4  jmp 0x00007431745DC375
00007431745df1f9  sub rsp, 0x08
00007431745df1fd  push rax
00007431745df1fe  push rcx
00007431745df1ff  push rdx
00007431745df200  push rdi
00007431745df201  push rsi
00007431745df202  push r8
00007431745df204  push r9
00007431745df206  push r10
00007431745df208  push r11
00007431745df20a  sub rsp, 0xF0
00007431745df211  vmovaps [rsp], xmm0
00007431745df216  vmovaps [rsp+0x10], xmm1
00007431745df21c  vmovaps [rsp+0x20], xmm2
00007431745df222  vmovaps [rsp+0x30], xmm3
00007431745df228  vmovaps [rsp+0x40], xmm4
00007431745df22e  vmovaps [rsp+0x50], xmm5
00007431745df234  vmovaps [rsp+0x60], xmm6
00007431745df23a  vmovaps [rsp+0x70], xmm7
00007431745df240  vmovaps [rsp+0x80], xmm8
00007431745df249  vmovaps [rsp+0x90], xmm9
00007431745df252  vmovaps [rsp+0xA0], xmm10
00007431745df25b  vmovaps [rsp+0xB0], xmm11
00007431745df264  vmovaps [rsp+0xC0], xmm12
00007431745df26d  vmovaps [rsp+0xD0], xmm13
00007431745df276  vmovaps [rsp+0xE0], xmm14
00007431745df27f  sub rsp, 0x30
00007431745df283  movaps [rsp], xmm15
00007431745df288  movaps [rsp+0x10], xmm5
00007431745df28d  movaps [rsp+0x20], xmm3
00007431745df292  lea rdi, [rsp]
00007431745df296  mov esi, 0x00
00007431745df29b  mov rax, 0x56C40959E530
00007431745df2a5  call rax
00007431745df2a7  movaps xmm15, [rsp]
00007431745df2ac  add rsp, 0x30
00007431745df2b0  vmovaps xmm0, [rsp]
00007431745df2b5  vmovaps xmm1, [rsp+0x10]
00007431745df2bb  vmovaps xmm2, [rsp+0x20]
00007431745df2c1  vmovaps xmm3, [rsp+0x30]
00007431745df2c7  vmovaps xmm4, [rsp+0x40]
00007431745df2cd  vmovaps xmm5, [rsp+0x50]
00007431745df2d3  vmovaps xmm6, [rsp+0x60]
00007431745df2d9  vmovaps xmm7, [rsp+0x70]
00007431745df2df  vmovaps xmm8, [rsp+0x80]
00007431745df2e8  vmovaps xmm9, [rsp+0x90]
00007431745df2f1  vmovaps xmm10, [rsp+0xA0]
00007431745df2fa  vmovaps xmm11, [rsp+0xB0]
00007431745df303  vmovaps xmm12, [rsp+0xC0]
00007431745df30c  vmovaps xmm13, [rsp+0xD0]
00007431745df315  vmovaps xmm14, [rsp+0xE0]
00007431745df31e  add rsp, 0xF0
00007431745df325  pop r11
00007431745df327  pop r10
00007431745df329  pop r9
00007431745df32b  pop r8
00007431745df32d  pop rsi
00007431745df32e  pop rdi
00007431745df32f  pop rdx
00007431745df330  pop rcx
00007431745df331  pop rax
00007431745df332  add rsp, 0x08
00007431745df336  jmp 0x00007431745DC38F
00007431745df33b  sub rsp, 0x08
00007431745df33f  push rax
00007431745df340  push rcx
00007431745df341  push rdx
00007431745df342  push rdi
00007431745df343  push rsi
00007431745df344  push r8
00007431745df346  push r9
00007431745df348  push r10
00007431745df34a  push r11
00007431745df34c  sub rsp, 0xF0
00007431745df353  vmovaps [rsp], xmm0
00007431745df358  vmovaps [rsp+0x10], xmm1
00007431745df35e  vmovaps [rsp+0x20], xmm2
00007431745df364  vmovaps [rsp+0x30], xmm3
00007431745df36a  vmovaps [rsp+0x40], xmm4
00007431745df370  vmovaps [rsp+0x50], xmm6
00007431745df376  vmovaps [rsp+0x60], xmm7
00007431745df37c  vmovaps [rsp+0x70], xmm8
00007431745df382  vmovaps [rsp+0x80], xmm9
00007431745df38b  vmovaps [rsp+0x90], xmm10
00007431745df394  vmovaps [rsp+0xA0], xmm11
00007431745df39d  vmovaps [rsp+0xB0], xmm12
00007431745df3a6  vmovaps [rsp+0xC0], xmm13
00007431745df3af  vmovaps [rsp+0xD0], xmm14
00007431745df3b8  vmovaps [rsp+0xE0], xmm15
00007431745df3c1  sub rsp, 0x30
00007431745df3c5  movaps [rsp], xmm5
00007431745df3c9  movaps [rsp+0x10], xmm8
00007431745df3cf  movaps [rsp+0x20], xmm6
00007431745df3d4  lea rdi, [rsp]
00007431745df3d8  mov esi, 0x00
00007431745df3dd  mov rax, 0x56C40959E530
00007431745df3e7  call rax
00007431745df3e9  movaps xmm5, [rsp]
00007431745df3ed  add rsp, 0x30
00007431745df3f1  vmovaps xmm0, [rsp]
00007431745df3f6  vmovaps xmm1, [rsp+0x10]
00007431745df3fc  vmovaps xmm2, [rsp+0x20]
00007431745df402  vmovaps xmm3, [rsp+0x30]
00007431745df408  vmovaps xmm4, [rsp+0x40]
00007431745df40e  vmovaps xmm6, [rsp+0x50]
00007431745df414  vmovaps xmm7, [rsp+0x60]
00007431745df41a  vmovaps xmm8, [rsp+0x70]
00007431745df420  vmovaps xmm9, [rsp+0x80]
00007431745df429  vmovaps xmm10, [rsp+0x90]
00007431745df432  vmovaps xmm11, [rsp+0xA0]
00007431745df43b  vmovaps xmm12, [rsp+0xB0]
00007431745df444  vmovaps xmm13, [rsp+0xC0]
00007431745df44d  vmovaps xmm14, [rsp+0xD0]
00007431745df456  vmovaps xmm15, [rsp+0xE0]
00007431745df45f  add rsp, 0xF0
00007431745df466  pop r11
00007431745df468  pop r10
00007431745df46a  pop r9
00007431745df46c  pop r8
00007431745df46e  pop rsi
00007431745df46f  pop rdi
00007431745df470  pop rdx
00007431745df471  pop rcx
00007431745df472  pop rax
00007431745df473  add rsp, 0x08
00007431745df477  jmp 0x00007431745DC3B3
00007431745df47c  sub rsp, 0x08
00007431745df480  push rax
00007431745df481  push rcx
00007431745df482  push rdx
00007431745df483  push rdi
00007431745df484  push rsi
00007431745df485  push r8
00007431745df487  push r9
00007431745df489  push r10
00007431745df48b  push r11
00007431745df48d  sub rsp, 0xF0
00007431745df494  vmovaps [rsp], xmm0
00007431745df499  vmovaps [rsp+0x10], xmm1
00007431745df49f  vmovaps [rsp+0x20], xmm2
00007431745df4a5  vmovaps [rsp+0x30], xmm3
00007431745df4ab  vmovaps [rsp+0x40], xmm4
00007431745df4b1  vmovaps [rsp+0x50], xmm5
00007431745df4b7  vmovaps [rsp+0x60], xmm7
00007431745df4bd  vmovaps [rsp+0x70], xmm8
00007431745df4c3  vmovaps [rsp+0x80], xmm9
00007431745df4cc  vmovaps [rsp+0x90], xmm10
00007431745df4d5  vmovaps [rsp+0xA0], xmm11
00007431745df4de  vmovaps [rsp+0xB0], xmm12
00007431745df4e7  vmovaps [rsp+0xC0], xmm13
00007431745df4f0  vmovaps [rsp+0xD0], xmm14
00007431745df4f9  vmovaps [rsp+0xE0], xmm15
00007431745df502  sub rsp, 0x30
00007431745df506  movaps [rsp], xmm6
00007431745df50a  movaps [rsp+0x10], xmm10
00007431745df510  movaps [rsp+0x20], xmm8
00007431745df516  lea rdi, [rsp]
00007431745df51a  mov esi, 0x00
00007431745df51f  mov rax, 0x56C40959E530
00007431745df529  call rax
00007431745df52b  movaps xmm6, [rsp]
00007431745df52f  add rsp, 0x30
00007431745df533  vmovaps xmm0, [rsp]
00007431745df538  vmovaps xmm1, [rsp+0x10]
00007431745df53e  vmovaps xmm2, [rsp+0x20]
00007431745df544  vmovaps xmm3, [rsp+0x30]
00007431745df54a  vmovaps xmm4, [rsp+0x40]
00007431745df550  vmovaps xmm5, [rsp+0x50]
00007431745df556  vmovaps xmm7, [rsp+0x60]
00007431745df55c  vmovaps xmm8, [rsp+0x70]
00007431745df562  vmovaps xmm9, [rsp+0x80]
00007431745df56b  vmovaps xmm10, [rsp+0x90]
00007431745df574  vmovaps xmm11, [rsp+0xA0]
00007431745df57d  vmovaps xmm12, [rsp+0xB0]
00007431745df586  vmovaps xmm13, [rsp+0xC0]
00007431745df58f  vmovaps xmm14, [rsp+0xD0]
00007431745df598  vmovaps xmm15, [rsp+0xE0]
00007431745df5a1  add rsp, 0xF0
00007431745df5a8  pop r11
00007431745df5aa  pop r10
00007431745df5ac  pop r9
00007431745df5ae  pop r8
00007431745df5b0  pop rsi
00007431745df5b1  pop rdi
00007431745df5b2  pop rdx
00007431745df5b3  pop rcx
00007431745df5b4  pop rax
00007431745df5b5  add rsp, 0x08
00007431745df5b9  jmp 0x00007431745DC3D8
00007431745df5be  sub rsp, 0x08
00007431745df5c2  push rax
00007431745df5c3  push rcx
00007431745df5c4  push rdx
00007431745df5c5  push rdi
00007431745df5c6  push rsi
00007431745df5c7  push r8
00007431745df5c9  push r9
00007431745df5cb  push r10
00007431745df5cd  push r11
00007431745df5cf  sub rsp, 0xF0
00007431745df5d6  vmovaps [rsp], xmm0
00007431745df5db  vmovaps [rsp+0x10], xmm1
00007431745df5e1  vmovaps [rsp+0x20], xmm2
00007431745df5e7  vmovaps [rsp+0x30], xmm3
00007431745df5ed  vmovaps [rsp+0x40], xmm4
00007431745df5f3  vmovaps [rsp+0x50], xmm5
00007431745df5f9  vmovaps [rsp+0x60], xmm6
00007431745df5ff  vmovaps [rsp+0x70], xmm7
00007431745df605  vmovaps [rsp+0x80], xmm8
00007431745df60e  vmovaps [rsp+0x90], xmm9
00007431745df617  vmovaps [rsp+0xA0], xmm11
00007431745df620  vmovaps [rsp+0xB0], xmm12
00007431745df629  vmovaps [rsp+0xC0], xmm13
00007431745df632  vmovaps [rsp+0xD0], xmm14
00007431745df63b  vmovaps [rsp+0xE0], xmm15
00007431745df644  sub rsp, 0x30
00007431745df648  movaps [rsp], xmm10
00007431745df64d  movaps [rsp+0x10], xmm8
00007431745df653  movaps [rsp+0x20], xmm14
00007431745df659  lea rdi, [rsp]
00007431745df65d  mov esi, 0x00
00007431745df662  mov rax, 0x56C40959E530
00007431745df66c  call rax
00007431745df66e  movaps xmm10, [rsp]
00007431745df673  add rsp, 0x30
00007431745df677  vmovaps xmm0, [rsp]
00007431745df67c  vmovaps xmm1, [rsp+0x10]
00007431745df682  vmovaps xmm2, [rsp+0x20]
00007431745df688  vmovaps xmm3, [rsp+0x30]
00007431745df68e  vmovaps xmm4, [rsp+0x40]
00007431745df694  vmovaps xmm5, [rsp+0x50]
00007431745df69a  vmovaps xmm6, [rsp+0x60]
00007431745df6a0  vmovaps xmm7, [rsp+0x70]
00007431745df6a6  vmovaps xmm8, [rsp+0x80]
00007431745df6af  vmovaps xmm9, [rsp+0x90]
00007431745df6b8  vmovaps xmm11, [rsp+0xA0]
00007431745df6c1  vmovaps xmm12, [rsp+0xB0]
00007431745df6ca  vmovaps xmm13, [rsp+0xC0]
00007431745df6d3  vmovaps xmm14, [rsp+0xD0]
00007431745df6dc  vmovaps xmm15, [rsp+0xE0]
00007431745df6e5  add rsp, 0xF0
00007431745df6ec  pop r11
00007431745df6ee  pop r10
00007431745df6f0  pop r9
00007431745df6f2  pop r8
00007431745df6f4  pop rsi
00007431745df6f5  pop rdi
00007431745df6f6  pop rdx
00007431745df6f7  pop rcx
00007431745df6f8  pop rax
00007431745df6f9  add rsp, 0x08
00007431745df6fd  jmp 0x00007431745DC3F8
00007431745df702  sub rsp, 0x08
00007431745df706  push rax
00007431745df707  push rcx
00007431745df708  push rdx
00007431745df709  push rdi
00007431745df70a  push rsi
00007431745df70b  push r8
00007431745df70d  push r9
00007431745df70f  push r10
00007431745df711  push r11
00007431745df713  sub rsp, 0xF0
00007431745df71a  vmovaps [rsp], xmm0
00007431745df71f  vmovaps [rsp+0x10], xmm1
00007431745df725  vmovaps [rsp+0x20], xmm2
00007431745df72b  vmovaps [rsp+0x30], xmm3
00007431745df731  vmovaps [rsp+0x40], xmm4
00007431745df737  vmovaps [rsp+0x50], xmm5
00007431745df73d  vmovaps [rsp+0x60], xmm6
00007431745df743  vmovaps [rsp+0x70], xmm7
00007431745df749  vmovaps [rsp+0x80], xmm8
00007431745df752  vmovaps [rsp+0x90], xmm9
00007431745df75b  vmovaps [rsp+0xA0], xmm10
00007431745df764  vmovaps [rsp+0xB0], xmm11
00007431745df76d  vmovaps [rsp+0xC0], xmm12
00007431745df776  vmovaps [rsp+0xD0], xmm13
00007431745df77f  vmovaps [rsp+0xE0], xmm15
00007431745df788  sub rsp, 0x30
00007431745df78c  movaps [rsp], xmm14
00007431745df791  movaps [rsp+0x10], xmm8
00007431745df797  movaps [rsp+0x20], xmm4
00007431745df79c  lea rdi, [rsp]
00007431745df7a0  mov esi, 0x00
00007431745df7a5  mov rax, 0x56C40959E530
00007431745df7af  call rax
00007431745df7b1  movaps xmm14, [rsp]
00007431745df7b6  add rsp, 0x30
00007431745df7ba  vmovaps xmm0, [rsp]
00007431745df7bf  vmovaps xmm1, [rsp+0x10]
00007431745df7c5  vmovaps xmm2, [rsp+0x20]
00007431745df7cb  vmovaps xmm3, [rsp+0x30]
00007431745df7d1  vmovaps xmm4, [rsp+0x40]
00007431745df7d7  vmovaps xmm5, [rsp+0x50]
00007431745df7dd  vmovaps xmm6, [rsp+0x60]
00007431745df7e3  vmovaps xmm7, [rsp+0x70]
00007431745df7e9  vmovaps xmm8, [rsp+0x80]
00007431745df7f2  vmovaps xmm9, [rsp+0x90]
00007431745df7fb  vmovaps xmm10, [rsp+0xA0]
00007431745df804  vmovaps xmm11, [rsp+0xB0]
00007431745df80d  vmovaps xmm12, [rsp+0xC0]
00007431745df816  vmovaps xmm13, [rsp+0xD0]
00007431745df81f  vmovaps xmm15, [rsp+0xE0]
00007431745df828  add rsp, 0xF0
00007431745df82f  pop r11
00007431745df831  pop r10
00007431745df833  pop r9
00007431745df835  pop r8
00007431745df837  pop rsi
00007431745df838  pop rdi
00007431745df839  pop rdx
00007431745df83a  pop rcx
00007431745df83b  pop rax
00007431745df83c  add rsp, 0x08
00007431745df840  jmp 0x00007431745DC418
00007431745df845  sub rsp, 0x08
00007431745df849  push rax
00007431745df84a  push rcx
00007431745df84b  push rdx
00007431745df84c  push rdi
00007431745df84d  push rsi
00007431745df84e  push r8
00007431745df850  push r9
00007431745df852  push r10
00007431745df854  push r11
00007431745df856  sub rsp, 0xF0
00007431745df85d  vmovaps [rsp], xmm0
00007431745df862  vmovaps [rsp+0x10], xmm1
00007431745df868  vmovaps [rsp+0x20], xmm2
00007431745df86e  vmovaps [rsp+0x30], xmm3
00007431745df874  vmovaps [rsp+0x40], xmm5
00007431745df87a  vmovaps [rsp+0x50], xmm6
00007431745df880  vmovaps [rsp+0x60], xmm7
00007431745df886  vmovaps [rsp+0x70], xmm8
00007431745df88c  vmovaps [rsp+0x80], xmm9
00007431745df895  vmovaps [rsp+0x90], xmm10
00007431745df89e  vmovaps [rsp+0xA0], xmm11
00007431745df8a7  vmovaps [rsp+0xB0], xmm12
00007431745df8b0  vmovaps [rsp+0xC0], xmm13
00007431745df8b9  vmovaps [rsp+0xD0], xmm14
00007431745df8c2  vmovaps [rsp+0xE0], xmm15
00007431745df8cb  sub rsp, 0x30
00007431745df8cf  movaps [rsp], xmm4
00007431745df8d3  movaps [rsp+0x10], xmm13
00007431745df8d9  movaps [rsp+0x20], xmm8
00007431745df8df  lea rdi, [rsp]
00007431745df8e3  mov esi, 0x00
00007431745df8e8  mov rax, 0x56C40959E530
00007431745df8f2  call rax
00007431745df8f4  movaps xmm4, [rsp]
00007431745df8f8  add rsp, 0x30
00007431745df8fc  vmovaps xmm0, [rsp]
00007431745df901  vmovaps xmm1, [rsp+0x10]
00007431745df907  vmovaps xmm2, [rsp+0x20]
00007431745df90d  vmovaps xmm3, [rsp+0x30]
00007431745df913  vmovaps xmm5, [rsp+0x40]
00007431745df919  vmovaps xmm6, [rsp+0x50]
00007431745df91f  vmovaps xmm7, [rsp+0x60]
00007431745df925  vmovaps xmm8, [rsp+0x70]
00007431745df92b  vmovaps xmm9, [rsp+0x80]
00007431745df934  vmovaps xmm10, [rsp+0x90]
00007431745df93d  vmovaps xmm11, [rsp+0xA0]
00007431745df946  vmovaps xmm12, [rsp+0xB0]
00007431745df94f  vmovaps xmm13, [rsp+0xC0]
00007431745df958  vmovaps xmm14, [rsp+0xD0]
00007431745df961  vmovaps xmm15, [rsp+0xE0]
00007431745df96a  add rsp, 0xF0
00007431745df971  pop r11
00007431745df973  pop r10
00007431745df975  pop r9
00007431745df977  pop r8
00007431745df979  pop rsi
00007431745df97a  pop rdi
00007431745df97b  pop rdx
00007431745df97c  pop rcx
00007431745df97d  pop rax
00007431745df97e  add rsp, 0x08
00007431745df982  jmp 0x00007431745DC43D
00007431745df987  sub rsp, 0x08
00007431745df98b  push rax
00007431745df98c  push rcx
00007431745df98d  push rdx
00007431745df98e  push rdi
00007431745df98f  push rsi
00007431745df990  push r8
00007431745df992  push r9
00007431745df994  push r10
00007431745df996  push r11
00007431745df998  sub rsp, 0xF0
00007431745df99f  vmovaps [rsp], xmm0
00007431745df9a4  vmovaps [rsp+0x10], xmm1
00007431745df9aa  vmovaps [rsp+0x20], xmm2
00007431745df9b0  vmovaps [rsp+0x30], xmm3
00007431745df9b6  vmovaps [rsp+0x40], xmm4
00007431745df9bc  vmovaps [rsp+0x50], xmm5
00007431745df9c2  vmovaps [rsp+0x60], xmm6
00007431745df9c8  vmovaps [rsp+0x70], xmm7
00007431745df9ce  vmovaps [rsp+0x80], xmm8
00007431745df9d7  vmovaps [rsp+0x90], xmm9
00007431745df9e0  vmovaps [rsp+0xA0], xmm10
00007431745df9e9  vmovaps [rsp+0xB0], xmm11
00007431745df9f2  vmovaps [rsp+0xC0], xmm12
00007431745df9fb  vmovaps [rsp+0xD0], xmm14
00007431745dfa04  vmovaps [rsp+0xE0], xmm15
00007431745dfa0d  sub rsp, 0x30
00007431745dfa11  movaps [rsp], xmm13
00007431745dfa16  movaps [rsp+0x10], xmm15
00007431745dfa1c  movaps [rsp+0x20], xmm9
00007431745dfa22  lea rdi, [rsp]
00007431745dfa26  mov esi, 0x00
00007431745dfa2b  mov rax, 0x56C40959E530
00007431745dfa35  call rax
00007431745dfa37  movaps xmm13, [rsp]
00007431745dfa3c  add rsp, 0x30
00007431745dfa40  vmovaps xmm0, [rsp]
00007431745dfa45  vmovaps xmm1, [rsp+0x10]
00007431745dfa4b  vmovaps xmm2, [rsp+0x20]
00007431745dfa51  vmovaps xmm3, [rsp+0x30]
00007431745dfa57  vmovaps xmm4, [rsp+0x40]
00007431745dfa5d  vmovaps xmm5, [rsp+0x50]
00007431745dfa63  vmovaps xmm6, [rsp+0x60]
00007431745dfa69  vmovaps xmm7, [rsp+0x70]
00007431745dfa6f  vmovaps xmm8, [rsp+0x80]
00007431745dfa78  vmovaps xmm9, [rsp+0x90]
00007431745dfa81  vmovaps xmm10, [rsp+0xA0]
00007431745dfa8a  vmovaps xmm11, [rsp+0xB0]
00007431745dfa93  vmovaps xmm12, [rsp+0xC0]
00007431745dfa9c  vmovaps xmm14, [rsp+0xD0]
00007431745dfaa5  vmovaps xmm15, [rsp+0xE0]
00007431745dfaae  add rsp, 0xF0
00007431745dfab5  pop r11
00007431745dfab7  pop r10
00007431745dfab9  pop r9
00007431745dfabb  pop r8
00007431745dfabd  pop rsi
00007431745dfabe  pop rdi
00007431745dfabf  pop rdx
00007431745dfac0  pop rcx
00007431745dfac1  pop rax
00007431745dfac2  add rsp, 0x08
00007431745dfac6  jmp 0x00007431745DC458
00007431745dfacb  sub rsp, 0x08
00007431745dfacf  push rax
00007431745dfad0  push rcx
00007431745dfad1  push rdx
00007431745dfad2  push rdi
00007431745dfad3  push rsi
00007431745dfad4  push r8
00007431745dfad6  push r9
00007431745dfad8  push r10
00007431745dfada  push r11
00007431745dfadc  sub rsp, 0xF0
00007431745dfae3  vmovaps [rsp], xmm0
00007431745dfae8  vmovaps [rsp+0x10], xmm1
00007431745dfaee  vmovaps [rsp+0x20], xmm2
00007431745dfaf4  vmovaps [rsp+0x30], xmm3
00007431745dfafa  vmovaps [rsp+0x40], xmm4
00007431745dfb00  vmovaps [rsp+0x50], xmm5
00007431745dfb06  vmovaps [rsp+0x60], xmm6
00007431745dfb0c  vmovaps [rsp+0x70], xmm7
00007431745dfb12  vmovaps [rsp+0x80], xmm8
00007431745dfb1b  vmovaps [rsp+0x90], xmm9
00007431745dfb24  vmovaps [rsp+0xA0], xmm10
00007431745dfb2d  vmovaps [rsp+0xB0], xmm11
00007431745dfb36  vmovaps [rsp+0xC0], xmm12
00007431745dfb3f  vmovaps [rsp+0xD0], xmm13
00007431745dfb48  vmovaps [rsp+0xE0], xmm14
00007431745dfb51  sub rsp, 0x30
00007431745dfb55  movaps [rsp], xmm15
00007431745dfb5a  movaps [rsp+0x10], xmm1
00007431745dfb5f  movaps [rsp+0x20], xmm5
00007431745dfb64  lea rdi, [rsp]
00007431745dfb68  mov esi, 0x00
00007431745dfb6d  mov rax, 0x56C40959E530
00007431745dfb77  call rax
00007431745dfb79  movaps xmm15, [rsp]
00007431745dfb7e  add rsp, 0x30
00007431745dfb82  vmovaps xmm0, [rsp]
00007431745dfb87  vmovaps xmm1, [rsp+0x10]
00007431745dfb8d  vmovaps xmm2, [rsp+0x20]
00007431745dfb93  vmovaps xmm3, [rsp+0x30]
00007431745dfb99  vmovaps xmm4, [rsp+0x40]
00007431745dfb9f  vmovaps xmm5, [rsp+0x50]
00007431745dfba5  vmovaps xmm6, [rsp+0x60]
00007431745dfbab  vmovaps xmm7, [rsp+0x70]
00007431745dfbb1  vmovaps xmm8, [rsp+0x80]
00007431745dfbba  vmovaps xmm9, [rsp+0x90]
00007431745dfbc3  vmovaps xmm10, [rsp+0xA0]
00007431745dfbcc  vmovaps xmm11, [rsp+0xB0]
00007431745dfbd5  vmovaps xmm12, [rsp+0xC0]
00007431745dfbde  vmovaps xmm13, [rsp+0xD0]
00007431745dfbe7  vmovaps xmm14, [rsp+0xE0]
00007431745dfbf0  add rsp, 0xF0
00007431745dfbf7  pop r11
00007431745dfbf9  pop r10
00007431745dfbfb  pop r9
00007431745dfbfd  pop r8
00007431745dfbff  pop rsi
00007431745dfc00  pop rdi
00007431745dfc01  pop rdx
00007431745dfc02  pop rcx
00007431745dfc03  pop rax
00007431745dfc04  add rsp, 0x08
00007431745dfc08  jmp 0x00007431745DC473
00007431745dfc0d  call 0x00007431744B52F0
00007431745dfc12  jmp 0x00007431745DC4CE
00007431745dfc17  sub rsp, 0x08
00007431745dfc1b  push rax
00007431745dfc1c  push rcx
00007431745dfc1d  push rdx
00007431745dfc1e  push rdi
00007431745dfc1f  push rsi
00007431745dfc20  push r8
00007431745dfc22  push r9
00007431745dfc24  push r10
00007431745dfc26  push r11
00007431745dfc28  sub rsp, 0xF0
00007431745dfc2f  vmovaps [rsp], xmm0
00007431745dfc34  vmovaps [rsp+0x10], xmm1
00007431745dfc3a  vmovaps [rsp+0x20], xmm2
00007431745dfc40  vmovaps [rsp+0x30], xmm3
00007431745dfc46  vmovaps [rsp+0x40], xmm4
00007431745dfc4c  vmovaps [rsp+0x50], xmm5
00007431745dfc52  vmovaps [rsp+0x60], xmm6
00007431745dfc58  vmovaps [rsp+0x70], xmm7
00007431745dfc5e  vmovaps [rsp+0x80], xmm8
00007431745dfc67  vmovaps [rsp+0x90], xmm10
00007431745dfc70  vmovaps [rsp+0xA0], xmm11
00007431745dfc79  vmovaps [rsp+0xB0], xmm12
00007431745dfc82  vmovaps [rsp+0xC0], xmm13
00007431745dfc8b  vmovaps [rsp+0xD0], xmm14
00007431745dfc94  vmovaps [rsp+0xE0], xmm15
00007431745dfc9d  sub rsp, 0x30
00007431745dfca1  movaps [rsp], xmm9
00007431745dfca6  movaps [rsp+0x10], xmm8
00007431745dfcac  movaps [rsp+0x20], xmm11
00007431745dfcb2  lea rdi, [rsp]
00007431745dfcb6  mov esi, 0x00
00007431745dfcbb  mov rax, 0x56C40959E530
00007431745dfcc5  call rax
00007431745dfcc7  movaps xmm9, [rsp]
00007431745dfccc  add rsp, 0x30
00007431745dfcd0  vmovaps xmm0, [rsp]
00007431745dfcd5  vmovaps xmm1, [rsp+0x10]
00007431745dfcdb  vmovaps xmm2, [rsp+0x20]
00007431745dfce1  vmovaps xmm3, [rsp+0x30]
00007431745dfce7  vmovaps xmm4, [rsp+0x40]
00007431745dfced  vmovaps xmm5, [rsp+0x50]
00007431745dfcf3  vmovaps xmm6, [rsp+0x60]
00007431745dfcf9  vmovaps xmm7, [rsp+0x70]
00007431745dfcff  vmovaps xmm8, [rsp+0x80]
00007431745dfd08  vmovaps xmm10, [rsp+0x90]
00007431745dfd11  vmovaps xmm11, [rsp+0xA0]
00007431745dfd1a  vmovaps xmm12, [rsp+0xB0]
00007431745dfd23  vmovaps xmm13, [rsp+0xC0]
00007431745dfd2c  vmovaps xmm14, [rsp+0xD0]
00007431745dfd35  vmovaps xmm15, [rsp+0xE0]
00007431745dfd3e  add rsp, 0xF0
00007431745dfd45  pop r11
00007431745dfd47  pop r10
00007431745dfd49  pop r9
00007431745dfd4b  pop r8
00007431745dfd4d  pop rsi
00007431745dfd4e  pop rdi
00007431745dfd4f  pop rdx
00007431745dfd50  pop rcx
00007431745dfd51  pop rax
00007431745dfd52  add rsp, 0x08
00007431745dfd56  jmp 0x00007431745DC505
00007431745dfd5b  sub rsp, 0x08
00007431745dfd5f  push rax
00007431745dfd60  push rcx
00007431745dfd61  push rdx
00007431745dfd62  push rdi
00007431745dfd63  push rsi
00007431745dfd64  push r8
00007431745dfd66  push r9
00007431745dfd68  push r10
00007431745dfd6a  push r11
00007431745dfd6c  sub rsp, 0xF0
00007431745dfd73  vmovaps [rsp], xmm0
00007431745dfd78  vmovaps [rsp+0x10], xmm1
00007431745dfd7e  vmovaps [rsp+0x20], xmm2
00007431745dfd84  vmovaps [rsp+0x30], xmm3
00007431745dfd8a  vmovaps [rsp+0x40], xmm4
00007431745dfd90  vmovaps [rsp+0x50], xmm5
00007431745dfd96  vmovaps [rsp+0x60], xmm6
00007431745dfd9c  vmovaps [rsp+0x70], xmm7
00007431745dfda2  vmovaps [rsp+0x80], xmm8
00007431745dfdab  vmovaps [rsp+0x90], xmm9
00007431745dfdb4  vmovaps [rsp+0xA0], xmm10
00007431745dfdbd  vmovaps [rsp+0xB0], xmm12
00007431745dfdc6  vmovaps [rsp+0xC0], xmm13
00007431745dfdcf  vmovaps [rsp+0xD0], xmm14
00007431745dfdd8  vmovaps [rsp+0xE0], xmm15
00007431745dfde1  sub rsp, 0x30
00007431745dfde5  movaps [rsp], xmm11
00007431745dfdea  movaps [rsp+0x10], xmm10
00007431745dfdf0  movaps [rsp+0x20], xmm6
00007431745dfdf5  lea rdi, [rsp]
00007431745dfdf9  mov esi, 0x00
00007431745dfdfe  mov rax, 0x56C40959E530
00007431745dfe08  call rax
00007431745dfe0a  movaps xmm11, [rsp]
00007431745dfe0f  add rsp, 0x30
00007431745dfe13  vmovaps xmm0, [rsp]
00007431745dfe18  vmovaps xmm1, [rsp+0x10]
00007431745dfe1e  vmovaps xmm2, [rsp+0x20]
00007431745dfe24  vmovaps xmm3, [rsp+0x30]
00007431745dfe2a  vmovaps xmm4, [rsp+0x40]
00007431745dfe30  vmovaps xmm5, [rsp+0x50]
00007431745dfe36  vmovaps xmm6, [rsp+0x60]
00007431745dfe3c  vmovaps xmm7, [rsp+0x70]
00007431745dfe42  vmovaps xmm8, [rsp+0x80]
00007431745dfe4b  vmovaps xmm9, [rsp+0x90]
00007431745dfe54  vmovaps xmm10, [rsp+0xA0]
00007431745dfe5d  vmovaps xmm12, [rsp+0xB0]
00007431745dfe66  vmovaps xmm13, [rsp+0xC0]
00007431745dfe6f  vmovaps xmm14, [rsp+0xD0]
00007431745dfe78  vmovaps xmm15, [rsp+0xE0]
00007431745dfe81  add rsp, 0xF0
00007431745dfe88  pop r11
00007431745dfe8a  pop r10
00007431745dfe8c  pop r9
00007431745dfe8e  pop r8
00007431745dfe90  pop rsi
00007431745dfe91  pop rdi
00007431745dfe92  pop rdx
00007431745dfe93  pop rcx
00007431745dfe94  pop rax
00007431745dfe95  add rsp, 0x08
00007431745dfe99  jmp 0x00007431745DC520
00007431745dfe9e  sub rsp, 0x08
00007431745dfea2  push rax
00007431745dfea3  push rcx
00007431745dfea4  push rdx
00007431745dfea5  push rdi
00007431745dfea6  push rsi
00007431745dfea7  push r8
00007431745dfea9  push r9
00007431745dfeab  push r10
00007431745dfead  push r11
00007431745dfeaf  sub rsp, 0xF0
00007431745dfeb6  vmovaps [rsp], xmm0
00007431745dfebb  vmovaps [rsp+0x10], xmm1
00007431745dfec1  vmovaps [rsp+0x20], xmm2
00007431745dfec7  vmovaps [rsp+0x30], xmm3
00007431745dfecd  vmovaps [rsp+0x40], xmm4
00007431745dfed3  vmovaps [rsp+0x50], xmm5
00007431745dfed9  vmovaps [rsp+0x60], xmm6
00007431745dfedf  vmovaps [rsp+0x70], xmm7
00007431745dfee5  vmovaps [rsp+0x80], xmm8
00007431745dfeee  vmovaps [rsp+0x90], xmm9
00007431745dfef7  vmovaps [rsp+0xA0], xmm11
00007431745dff00  vmovaps [rsp+0xB0], xmm12
00007431745dff09  vmovaps [rsp+0xC0], xmm13
00007431745dff12  vmovaps [rsp+0xD0], xmm14
00007431745dff1b  vmovaps [rsp+0xE0], xmm15
00007431745dff24  sub rsp, 0x30
00007431745dff28  movaps [rsp], xmm10
00007431745dff2d  movaps [rsp+0x10], xmm14
00007431745dff33  movaps [rsp+0x20], xmm4
00007431745dff38  lea rdi, [rsp]
00007431745dff3c  mov esi, 0x00
00007431745dff41  mov rax, 0x56C40959E530
00007431745dff4b  call rax
00007431745dff4d  movaps xmm10, [rsp]
00007431745dff52  add rsp, 0x30
00007431745dff56  vmovaps xmm0, [rsp]
00007431745dff5b  vmovaps xmm1, [rsp+0x10]
00007431745dff61  vmovaps xmm2, [rsp+0x20]
00007431745dff67  vmovaps xmm3, [rsp+0x30]
00007431745dff6d  vmovaps xmm4, [rsp+0x40]
00007431745dff73  vmovaps xmm5, [rsp+0x50]
00007431745dff79  vmovaps xmm6, [rsp+0x60]
00007431745dff7f  vmovaps xmm7, [rsp+0x70]
00007431745dff85  vmovaps xmm8, [rsp+0x80]
00007431745dff8e  vmovaps xmm9, [rsp+0x90]
00007431745dff97  vmovaps xmm11, [rsp+0xA0]
00007431745dffa0  vmovaps xmm12, [rsp+0xB0]
00007431745dffa9  vmovaps xmm13, [rsp+0xC0]
00007431745dffb2  vmovaps xmm14, [rsp+0xD0]
00007431745dffbb  vmovaps xmm15, [rsp+0xE0]
00007431745dffc4  add rsp, 0xF0
00007431745dffcb  pop r11
00007431745dffcd  pop r10
00007431745dffcf  pop r9
00007431745dffd1  pop r8
00007431745dffd3  pop rsi
00007431745dffd4  pop rdi
00007431745dffd5  pop rdx
00007431745dffd6  pop rcx
00007431745dffd7  pop rax
00007431745dffd8  add rsp, 0x08
00007431745dffdc  jmp 0x00007431745DC53B
00007431745dffe1  sub rsp, 0x08
00007431745dffe5  push rax
00007431745dffe6  push rcx
00007431745dffe7  push rdx
00007431745dffe8  push rdi
00007431745dffe9  push rsi
00007431745dffea  push r8
00007431745dffec  push r9
00007431745dffee  push r10
00007431745dfff0  push r11
00007431745dfff2  sub rsp, 0xF0
00007431745dfff9  vmovaps [rsp], xmm0
00007431745dfffe  vmovaps [rsp+0x10], xmm1
00007431745e0004  vmovaps [rsp+0x20], xmm2
00007431745e000a  vmovaps [rsp+0x30], xmm3
00007431745e0010  vmovaps [rsp+0x40], xmm4
00007431745e0016  vmovaps [rsp+0x50], xmm5
00007431745e001c  vmovaps [rsp+0x60], xmm6
00007431745e0022  vmovaps [rsp+0x70], xmm7
00007431745e0028  vmovaps [rsp+0x80], xmm9
00007431745e0031  vmovaps [rsp+0x90], xmm10
00007431745e003a  vmovaps [rsp+0xA0], xmm11
00007431745e0043  vmovaps [rsp+0xB0], xmm12
00007431745e004c  vmovaps [rsp+0xC0], xmm13
00007431745e0055  vmovaps [rsp+0xD0], xmm14
00007431745e005e  vmovaps [rsp+0xE0], xmm15
00007431745e0067  sub rsp, 0x30
00007431745e006b  movaps [rsp], xmm8
00007431745e0070  movaps [rsp+0x10], xmm1
00007431745e0075  movaps [rsp+0x20], xmm14
00007431745e007b  lea rdi, [rsp]
00007431745e007f  mov esi, 0x00
00007431745e0084  mov rax, 0x56C40959E530
00007431745e008e  call rax
00007431745e0090  movaps xmm8, [rsp]
00007431745e0095  add rsp, 0x30
00007431745e0099  vmovaps xmm0, [rsp]
00007431745e009e  vmovaps xmm1, [rsp+0x10]
00007431745e00a4  vmovaps xmm2, [rsp+0x20]
00007431745e00aa  vmovaps xmm3, [rsp+0x30]
00007431745e00b0  vmovaps xmm4, [rsp+0x40]
00007431745e00b6  vmovaps xmm5, [rsp+0x50]
00007431745e00bc  vmovaps xmm6, [rsp+0x60]
00007431745e00c2  vmovaps xmm7, [rsp+0x70]
00007431745e00c8  vmovaps xmm9, [rsp+0x80]
00007431745e00d1  vmovaps xmm10, [rsp+0x90]
00007431745e00da  vmovaps xmm11, [rsp+0xA0]
00007431745e00e3  vmovaps xmm12, [rsp+0xB0]
00007431745e00ec  vmovaps xmm13, [rsp+0xC0]
00007431745e00f5  vmovaps xmm14, [rsp+0xD0]
00007431745e00fe  vmovaps xmm15, [rsp+0xE0]
00007431745e0107  add rsp, 0xF0
00007431745e010e  pop r11
00007431745e0110  pop r10
00007431745e0112  pop r9
00007431745e0114  pop r8
00007431745e0116  pop rsi
00007431745e0117  pop rdi
00007431745e0118  pop rdx
00007431745e0119  pop rcx
00007431745e011a  pop rax
00007431745e011b  add rsp, 0x08
00007431745e011f  jmp 0x00007431745DC561
00007431745e0124  sub rsp, 0x08
00007431745e0128  push rax
00007431745e0129  push rcx
00007431745e012a  push rdx
00007431745e012b  push rdi
00007431745e012c  push rsi
00007431745e012d  push r8
00007431745e012f  push r9
00007431745e0131  push r10
00007431745e0133  push r11
00007431745e0135  sub rsp, 0xF0
00007431745e013c  vmovaps [rsp], xmm0
00007431745e0141  vmovaps [rsp+0x10], xmm1
00007431745e0147  vmovaps [rsp+0x20], xmm2
00007431745e014d  vmovaps [rsp+0x30], xmm3
00007431745e0153  vmovaps [rsp+0x40], xmm4
00007431745e0159  vmovaps [rsp+0x50], xmm5
00007431745e015f  vmovaps [rsp+0x60], xmm7
00007431745e0165  vmovaps [rsp+0x70], xmm8
00007431745e016b  vmovaps [rsp+0x80], xmm9
00007431745e0174  vmovaps [rsp+0x90], xmm10
00007431745e017d  vmovaps [rsp+0xA0], xmm11
00007431745e0186  vmovaps [rsp+0xB0], xmm12
00007431745e018f  vmovaps [rsp+0xC0], xmm13
00007431745e0198  vmovaps [rsp+0xD0], xmm14
00007431745e01a1  vmovaps [rsp+0xE0], xmm15
00007431745e01aa  sub rsp, 0x30
00007431745e01ae  movaps [rsp], xmm6
00007431745e01b2  movaps [rsp+0x10], xmm1
00007431745e01b7  movaps [rsp+0x20], xmm14
00007431745e01bd  lea rdi, [rsp]
00007431745e01c1  mov esi, 0x00
00007431745e01c6  mov rax, 0x56C40959E530
00007431745e01d0  call rax
00007431745e01d2  movaps xmm6, [rsp]
00007431745e01d6  add rsp, 0x30
00007431745e01da  vmovaps xmm0, [rsp]
00007431745e01df  vmovaps xmm1, [rsp+0x10]
00007431745e01e5  vmovaps xmm2, [rsp+0x20]
00007431745e01eb  vmovaps xmm3, [rsp+0x30]
00007431745e01f1  vmovaps xmm4, [rsp+0x40]
00007431745e01f7  vmovaps xmm5, [rsp+0x50]
00007431745e01fd  vmovaps xmm7, [rsp+0x60]
00007431745e0203  vmovaps xmm8, [rsp+0x70]
00007431745e0209  vmovaps xmm9, [rsp+0x80]
00007431745e0212  vmovaps xmm10, [rsp+0x90]
00007431745e021b  vmovaps xmm11, [rsp+0xA0]
00007431745e0224  vmovaps xmm12, [rsp+0xB0]
00007431745e022d  vmovaps xmm13, [rsp+0xC0]
00007431745e0236  vmovaps xmm14, [rsp+0xD0]
00007431745e023f  vmovaps xmm15, [rsp+0xE0]
00007431745e0248  add rsp, 0xF0
00007431745e024f  pop r11
00007431745e0251  pop r10
00007431745e0253  pop r9
00007431745e0255  pop r8
00007431745e0257  pop rsi
00007431745e0258  pop rdi
00007431745e0259  pop rdx
00007431745e025a  pop rcx
00007431745e025b  pop rax
00007431745e025c  add rsp, 0x08
00007431745e0260  jmp 0x00007431745DC58D
00007431745e0265  sub rsp, 0x08
00007431745e0269  push rax
00007431745e026a  push rcx
00007431745e026b  push rdx
00007431745e026c  push rdi
00007431745e026d  push rsi
00007431745e026e  push r8
00007431745e0270  push r9
00007431745e0272  push r10
00007431745e0274  push r11
00007431745e0276  sub rsp, 0xF0
00007431745e027d  vmovaps [rsp], xmm0
00007431745e0282  vmovaps [rsp+0x10], xmm1
00007431745e0288  vmovaps [rsp+0x20], xmm2
00007431745e028e  vmovaps [rsp+0x30], xmm3
00007431745e0294  vmovaps [rsp+0x40], xmm4
00007431745e029a  vmovaps [rsp+0x50], xmm5
00007431745e02a0  vmovaps [rsp+0x60], xmm6
00007431745e02a6  vmovaps [rsp+0x70], xmm7
00007431745e02ac  vmovaps [rsp+0x80], xmm8
00007431745e02b5  vmovaps [rsp+0x90], xmm9
00007431745e02be  vmovaps [rsp+0xA0], xmm10
00007431745e02c7  vmovaps [rsp+0xB0], xmm11
00007431745e02d0  vmovaps [rsp+0xC0], xmm12
00007431745e02d9  vmovaps [rsp+0xD0], xmm13
00007431745e02e2  vmovaps [rsp+0xE0], xmm15
00007431745e02eb  sub rsp, 0x30
00007431745e02ef  movaps [rsp], xmm14
00007431745e02f4  movaps [rsp+0x10], xmm12
00007431745e02fa  movaps [rsp+0x20], xmm1
00007431745e02ff  lea rdi, [rsp]
00007431745e0303  mov esi, 0x00
00007431745e0308  mov rax, 0x56C40959E530
00007431745e0312  call rax
00007431745e0314  movaps xmm14, [rsp]
00007431745e0319  add rsp, 0x30
00007431745e031d  vmovaps xmm0, [rsp]
00007431745e0322  vmovaps xmm1, [rsp+0x10]
00007431745e0328  vmovaps xmm2, [rsp+0x20]
00007431745e032e  vmovaps xmm3, [rsp+0x30]
00007431745e0334  vmovaps xmm4, [rsp+0x40]
00007431745e033a  vmovaps xmm5, [rsp+0x50]
00007431745e0340  vmovaps xmm6, [rsp+0x60]
00007431745e0346  vmovaps xmm7, [rsp+0x70]
00007431745e034c  vmovaps xmm8, [rsp+0x80]
00007431745e0355  vmovaps xmm9, [rsp+0x90]
00007431745e035e  vmovaps xmm10, [rsp+0xA0]
00007431745e0367  vmovaps xmm11, [rsp+0xB0]
00007431745e0370  vmovaps xmm12, [rsp+0xC0]
00007431745e0379  vmovaps xmm13, [rsp+0xD0]
00007431745e0382  vmovaps xmm15, [rsp+0xE0]
00007431745e038b  add rsp, 0xF0
00007431745e0392  pop r11
00007431745e0394  pop r10
00007431745e0396  pop r9
00007431745e0398  pop r8
00007431745e039a  pop rsi
00007431745e039b  pop rdi
00007431745e039c  pop rdx
00007431745e039d  pop rcx
00007431745e039e  pop rax
00007431745e039f  add rsp, 0x08
00007431745e03a3  jmp 0x00007431745DC5B3
00007431745e03a8  sub rsp, 0x08
00007431745e03ac  push rax
00007431745e03ad  push rcx
00007431745e03ae  push rdx
00007431745e03af  push rdi
00007431745e03b0  push rsi
00007431745e03b1  push r8
00007431745e03b3  push r9
00007431745e03b5  push r10
00007431745e03b7  push r11
00007431745e03b9  sub rsp, 0xF0
00007431745e03c0  vmovaps [rsp], xmm0
00007431745e03c5  vmovaps [rsp+0x10], xmm2
00007431745e03cb  vmovaps [rsp+0x20], xmm3
00007431745e03d1  vmovaps [rsp+0x30], xmm4
00007431745e03d7  vmovaps [rsp+0x40], xmm5
00007431745e03dd  vmovaps [rsp+0x50], xmm6
00007431745e03e3  vmovaps [rsp+0x60], xmm7
00007431745e03e9  vmovaps [rsp+0x70], xmm8
00007431745e03ef  vmovaps [rsp+0x80], xmm9
00007431745e03f8  vmovaps [rsp+0x90], xmm10
00007431745e0401  vmovaps [rsp+0xA0], xmm11
00007431745e040a  vmovaps [rsp+0xB0], xmm12
00007431745e0413  vmovaps [rsp+0xC0], xmm13
00007431745e041c  vmovaps [rsp+0xD0], xmm14
00007431745e0425  vmovaps [rsp+0xE0], xmm15
00007431745e042e  sub rsp, 0x30
00007431745e0432  movaps [rsp], xmm1
00007431745e0436  movaps [rsp+0x10], xmm13
00007431745e043c  movaps [rsp+0x20], xmm9
00007431745e0442  lea rdi, [rsp]
00007431745e0446  mov esi, 0x00
00007431745e044b  mov rax, 0x56C40959E530
00007431745e0455  call rax
00007431745e0457  movaps xmm1, [rsp]
00007431745e045b  add rsp, 0x30
00007431745e045f  vmovaps xmm0, [rsp]
00007431745e0464  vmovaps xmm2, [rsp+0x10]
00007431745e046a  vmovaps xmm3, [rsp+0x20]
00007431745e0470  vmovaps xmm4, [rsp+0x30]
00007431745e0476  vmovaps xmm5, [rsp+0x40]
00007431745e047c  vmovaps xmm6, [rsp+0x50]
00007431745e0482  vmovaps xmm7, [rsp+0x60]
00007431745e0488  vmovaps xmm8, [rsp+0x70]
00007431745e048e  vmovaps xmm9, [rsp+0x80]
00007431745e0497  vmovaps xmm10, [rsp+0x90]
00007431745e04a0  vmovaps xmm11, [rsp+0xA0]
00007431745e04a9  vmovaps xmm12, [rsp+0xB0]
00007431745e04b2  vmovaps xmm13, [rsp+0xC0]
00007431745e04bb  vmovaps xmm14, [rsp+0xD0]
00007431745e04c4  vmovaps xmm15, [rsp+0xE0]
00007431745e04cd  add rsp, 0xF0
00007431745e04d4  pop r11
00007431745e04d6  pop r10
00007431745e04d8  pop r9
00007431745e04da  pop r8
00007431745e04dc  pop rsi
00007431745e04dd  pop rdi
00007431745e04de  pop rdx
00007431745e04df  pop rcx
00007431745e04e0  pop rax
00007431745e04e1  add rsp, 0x08
00007431745e04e5  jmp 0x00007431745DC5CD
00007431745e04ea  sub rsp, 0x08
00007431745e04ee  push rax
00007431745e04ef  push rcx
00007431745e04f0  push rdx
00007431745e04f1  push rdi
00007431745e04f2  push rsi
00007431745e04f3  push r8
00007431745e04f5  push r9
00007431745e04f7  push r10
00007431745e04f9  push r11
00007431745e04fb  sub rsp, 0xF0
00007431745e0502  vmovaps [rsp], xmm0
00007431745e0507  vmovaps [rsp+0x10], xmm1
00007431745e050d  vmovaps [rsp+0x20], xmm2
00007431745e0513  vmovaps [rsp+0x30], xmm3
00007431745e0519  vmovaps [rsp+0x40], xmm4
00007431745e051f  vmovaps [rsp+0x50], xmm5
00007431745e0525  vmovaps [rsp+0x60], xmm6
00007431745e052b  vmovaps [rsp+0x70], xmm7
00007431745e0531  vmovaps [rsp+0x80], xmm8
00007431745e053a  vmovaps [rsp+0x90], xmm9
00007431745e0543  vmovaps [rsp+0xA0], xmm10
00007431745e054c  vmovaps [rsp+0xB0], xmm11
00007431745e0555  vmovaps [rsp+0xC0], xmm13
00007431745e055e  vmovaps [rsp+0xD0], xmm14
00007431745e0567  vmovaps [rsp+0xE0], xmm15
00007431745e0570  sub rsp, 0x30
00007431745e0574  movaps [rsp], xmm12
00007431745e0579  movaps [rsp+0x10], xmm7
00007431745e057e  movaps [rsp+0x20], xmm13
00007431745e0584  lea rdi, [rsp]
00007431745e0588  mov esi, 0x00
00007431745e058d  mov rax, 0x56C40959E530
00007431745e0597  call rax
00007431745e0599  movaps xmm12, [rsp]
00007431745e059e  add rsp, 0x30
00007431745e05a2  vmovaps xmm0, [rsp]
00007431745e05a7  vmovaps xmm1, [rsp+0x10]
00007431745e05ad  vmovaps xmm2, [rsp+0x20]
00007431745e05b3  vmovaps xmm3, [rsp+0x30]
00007431745e05b9  vmovaps xmm4, [rsp+0x40]
00007431745e05bf  vmovaps xmm5, [rsp+0x50]
00007431745e05c5  vmovaps xmm6, [rsp+0x60]
00007431745e05cb  vmovaps xmm7, [rsp+0x70]
00007431745e05d1  vmovaps xmm8, [rsp+0x80]
00007431745e05da  vmovaps xmm9, [rsp+0x90]
00007431745e05e3  vmovaps xmm10, [rsp+0xA0]
00007431745e05ec  vmovaps xmm11, [rsp+0xB0]
00007431745e05f5  vmovaps xmm13, [rsp+0xC0]
00007431745e05fe  vmovaps xmm14, [rsp+0xD0]
00007431745e0607  vmovaps xmm15, [rsp+0xE0]
00007431745e0610  add rsp, 0xF0
00007431745e0617  pop r11
00007431745e0619  pop r10
00007431745e061b  pop r9
00007431745e061d  pop r8
00007431745e061f  pop rsi
00007431745e0620  pop rdi
00007431745e0621  pop rdx
00007431745e0622  pop rcx
00007431745e0623  pop rax
00007431745e0624  add rsp, 0x08
00007431745e0628  jmp 0x00007431745DC5F4
00007431745e062d  sub rsp, 0x08
00007431745e0631  push rax
00007431745e0632  push rcx
00007431745e0633  push rdx
00007431745e0634  push rdi
00007431745e0635  push rsi
00007431745e0636  push r8
00007431745e0638  push r9
00007431745e063a  push r10
00007431745e063c  push r11
00007431745e063e  sub rsp, 0xF0
00007431745e0645  vmovaps [rsp], xmm0
00007431745e064a  vmovaps [rsp+0x10], xmm1
00007431745e0650  vmovaps [rsp+0x20], xmm2
00007431745e0656  vmovaps [rsp+0x30], xmm3
00007431745e065c  vmovaps [rsp+0x40], xmm4
00007431745e0662  vmovaps [rsp+0x50], xmm5
00007431745e0668  vmovaps [rsp+0x60], xmm6
00007431745e066e  vmovaps [rsp+0x70], xmm7
00007431745e0674  vmovaps [rsp+0x80], xmm8
00007431745e067d  vmovaps [rsp+0x90], xmm9
00007431745e0686  vmovaps [rsp+0xA0], xmm10
00007431745e068f  vmovaps [rsp+0xB0], xmm11
00007431745e0698  vmovaps [rsp+0xC0], xmm12
00007431745e06a1  vmovaps [rsp+0xD0], xmm14
00007431745e06aa  vmovaps [rsp+0xE0], xmm15
00007431745e06b3  sub rsp, 0x30
00007431745e06b7  movaps [rsp], xmm13
00007431745e06bc  movaps [rsp+0x10], xmm15
00007431745e06c2  movaps [rsp+0x20], xmm8
00007431745e06c8  lea rdi, [rsp]
00007431745e06cc  mov esi, 0x00
00007431745e06d1  mov rax, 0x56C40959E530
00007431745e06db  call rax
00007431745e06dd  movaps xmm13, [rsp]
00007431745e06e2  add rsp, 0x30
00007431745e06e6  vmovaps xmm0, [rsp]
00007431745e06eb  vmovaps xmm1, [rsp+0x10]
00007431745e06f1  vmovaps xmm2, [rsp+0x20]
00007431745e06f7  vmovaps xmm3, [rsp+0x30]
00007431745e06fd  vmovaps xmm4, [rsp+0x40]
00007431745e0703  vmovaps xmm5, [rsp+0x50]
00007431745e0709  vmovaps xmm6, [rsp+0x60]
00007431745e070f  vmovaps xmm7, [rsp+0x70]
00007431745e0715  vmovaps xmm8, [rsp+0x80]
00007431745e071e  vmovaps xmm9, [rsp+0x90]
00007431745e0727  vmovaps xmm10, [rsp+0xA0]
00007431745e0730  vmovaps xmm11, [rsp+0xB0]
00007431745e0739  vmovaps xmm12, [rsp+0xC0]
00007431745e0742  vmovaps xmm14, [rsp+0xD0]
00007431745e074b  vmovaps xmm15, [rsp+0xE0]
00007431745e0754  add rsp, 0xF0
00007431745e075b  pop r11
00007431745e075d  pop r10
00007431745e075f  pop r9
00007431745e0761  pop r8
00007431745e0763  pop rsi
00007431745e0764  pop rdi
00007431745e0765  pop rdx
00007431745e0766  pop rcx
00007431745e0767  pop rax
00007431745e0768  add rsp, 0x08
00007431745e076c  jmp 0x00007431745DC60F
00007431745e0771  sub rsp, 0x08
00007431745e0775  push rax
00007431745e0776  push rcx
00007431745e0777  push rdx
00007431745e0778  push rdi
00007431745e0779  push rsi
00007431745e077a  push r8
00007431745e077c  push r9
00007431745e077e  push r10
00007431745e0780  push r11
00007431745e0782  sub rsp, 0xF0
00007431745e0789  vmovaps [rsp], xmm0
00007431745e078e  vmovaps [rsp+0x10], xmm1
00007431745e0794  vmovaps [rsp+0x20], xmm2
00007431745e079a  vmovaps [rsp+0x30], xmm3
00007431745e07a0  vmovaps [rsp+0x40], xmm4
00007431745e07a6  vmovaps [rsp+0x50], xmm5
00007431745e07ac  vmovaps [rsp+0x60], xmm6
00007431745e07b2  vmovaps [rsp+0x70], xmm7
00007431745e07b8  vmovaps [rsp+0x80], xmm9
00007431745e07c1  vmovaps [rsp+0x90], xmm10
00007431745e07ca  vmovaps [rsp+0xA0], xmm11
00007431745e07d3  vmovaps [rsp+0xB0], xmm12
00007431745e07dc  vmovaps [rsp+0xC0], xmm13
00007431745e07e5  vmovaps [rsp+0xD0], xmm14
00007431745e07ee  vmovaps [rsp+0xE0], xmm15
00007431745e07f7  sub rsp, 0x30
00007431745e07fb  movaps [rsp], xmm8
00007431745e0800  movaps [rsp+0x10], xmm15
00007431745e0806  movaps [rsp+0x20], xmm9
00007431745e080c  lea rdi, [rsp]
00007431745e0810  mov esi, 0x00
00007431745e0815  mov rax, 0x56C40959E530
00007431745e081f  call rax
00007431745e0821  movaps xmm8, [rsp]
00007431745e0826  add rsp, 0x30
00007431745e082a  vmovaps xmm0, [rsp]
00007431745e082f  vmovaps xmm1, [rsp+0x10]
00007431745e0835  vmovaps xmm2, [rsp+0x20]
00007431745e083b  vmovaps xmm3, [rsp+0x30]
00007431745e0841  vmovaps xmm4, [rsp+0x40]
00007431745e0847  vmovaps xmm5, [rsp+0x50]
00007431745e084d  vmovaps xmm6, [rsp+0x60]
00007431745e0853  vmovaps xmm7, [rsp+0x70]
00007431745e0859  vmovaps xmm9, [rsp+0x80]
00007431745e0862  vmovaps xmm10, [rsp+0x90]
00007431745e086b  vmovaps xmm11, [rsp+0xA0]
00007431745e0874  vmovaps xmm12, [rsp+0xB0]
00007431745e087d  vmovaps xmm13, [rsp+0xC0]
00007431745e0886  vmovaps xmm14, [rsp+0xD0]
00007431745e088f  vmovaps xmm15, [rsp+0xE0]
00007431745e0898  add rsp, 0xF0
00007431745e089f  pop r11
00007431745e08a1  pop r10
00007431745e08a3  pop r9
00007431745e08a5  pop r8
00007431745e08a7  pop rsi
00007431745e08a8  pop rdi
00007431745e08a9  pop rdx
00007431745e08aa  pop rcx
00007431745e08ab  pop rax
00007431745e08ac  add rsp, 0x08
00007431745e08b0  jmp 0x00007431745DC63D
00007431745e08b5  sub rsp, 0x08
00007431745e08b9  push rax
00007431745e08ba  push rcx
00007431745e08bb  push rdx
00007431745e08bc  push rdi
00007431745e08bd  push rsi
00007431745e08be  push r8
00007431745e08c0  push r9
00007431745e08c2  push r10
00007431745e08c4  push r11
00007431745e08c6  sub rsp, 0xF0
00007431745e08cd  vmovaps [rsp], xmm0
00007431745e08d2  vmovaps [rsp+0x10], xmm1
00007431745e08d8  vmovaps [rsp+0x20], xmm2
00007431745e08de  vmovaps [rsp+0x30], xmm3
00007431745e08e4  vmovaps [rsp+0x40], xmm4
00007431745e08ea  vmovaps [rsp+0x50], xmm5
00007431745e08f0  vmovaps [rsp+0x60], xmm6
00007431745e08f6  vmovaps [rsp+0x70], xmm7
00007431745e08fc  vmovaps [rsp+0x80], xmm8
00007431745e0905  vmovaps [rsp+0x90], xmm9
00007431745e090e  vmovaps [rsp+0xA0], xmm10
00007431745e0917  vmovaps [rsp+0xB0], xmm11
00007431745e0920  vmovaps [rsp+0xC0], xmm12
00007431745e0929  vmovaps [rsp+0xD0], xmm13
00007431745e0932  vmovaps [rsp+0xE0], xmm14
00007431745e093b  sub rsp, 0x30
00007431745e093f  movaps [rsp], xmm15
00007431745e0944  movaps [rsp+0x10], xmm11
00007431745e094a  movaps [rsp+0x20], xmm6
00007431745e094f  lea rdi, [rsp]
00007431745e0953  mov esi, 0x00
00007431745e0958  mov rax, 0x56C40959E530
00007431745e0962  call rax
00007431745e0964  movaps xmm15, [rsp]
00007431745e0969  add rsp, 0x30
00007431745e096d  vmovaps xmm0, [rsp]
00007431745e0972  vmovaps xmm1, [rsp+0x10]
00007431745e0978  vmovaps xmm2, [rsp+0x20]
00007431745e097e  vmovaps xmm3, [rsp+0x30]
00007431745e0984  vmovaps xmm4, [rsp+0x40]
00007431745e098a  vmovaps xmm5, [rsp+0x50]
00007431745e0990  vmovaps xmm6, [rsp+0x60]
00007431745e0996  vmovaps xmm7, [rsp+0x70]
00007431745e099c  vmovaps xmm8, [rsp+0x80]
00007431745e09a5  vmovaps xmm9, [rsp+0x90]
00007431745e09ae  vmovaps xmm10, [rsp+0xA0]
00007431745e09b7  vmovaps xmm11, [rsp+0xB0]
00007431745e09c0  vmovaps xmm12, [rsp+0xC0]
00007431745e09c9  vmovaps xmm13, [rsp+0xD0]
00007431745e09d2  vmovaps xmm14, [rsp+0xE0]
00007431745e09db  add rsp, 0xF0
00007431745e09e2  pop r11
00007431745e09e4  pop r10
00007431745e09e6  pop r9
00007431745e09e8  pop r8
00007431745e09ea  pop rsi
00007431745e09eb  pop rdi
00007431745e09ec  pop rdx
00007431745e09ed  pop rcx
00007431745e09ee  pop rax
00007431745e09ef  add rsp, 0x08
00007431745e09f3  jmp 0x00007431745DC658
00007431745e09f8  sub rsp, 0x08
00007431745e09fc  push rax
00007431745e09fd  push rcx
00007431745e09fe  push rdx
00007431745e09ff  push rdi
00007431745e0a00  push rsi
00007431745e0a01  push r8
00007431745e0a03  push r9
00007431745e0a05  push r10
00007431745e0a07  push r11
00007431745e0a09  sub rsp, 0xF0
00007431745e0a10  vmovaps [rsp], xmm0
00007431745e0a15  vmovaps [rsp+0x10], xmm1
00007431745e0a1b  vmovaps [rsp+0x20], xmm2
00007431745e0a21  vmovaps [rsp+0x30], xmm3
00007431745e0a27  vmovaps [rsp+0x40], xmm4
00007431745e0a2d  vmovaps [rsp+0x50], xmm5
00007431745e0a33  vmovaps [rsp+0x60], xmm6
00007431745e0a39  vmovaps [rsp+0x70], xmm8
00007431745e0a3f  vmovaps [rsp+0x80], xmm9
00007431745e0a48  vmovaps [rsp+0x90], xmm10
00007431745e0a51  vmovaps [rsp+0xA0], xmm11
00007431745e0a5a  vmovaps [rsp+0xB0], xmm12
00007431745e0a63  vmovaps [rsp+0xC0], xmm13
00007431745e0a6c  vmovaps [rsp+0xD0], xmm14
00007431745e0a75  vmovaps [rsp+0xE0], xmm15
00007431745e0a7e  sub rsp, 0x30
00007431745e0a82  movaps [rsp], xmm7
00007431745e0a86  movaps [rsp+0x10], xmm11
00007431745e0a8c  movaps [rsp+0x20], xmm9
00007431745e0a92  lea rdi, [rsp]
00007431745e0a96  mov esi, 0x00
00007431745e0a9b  mov rax, 0x56C40959E530
00007431745e0aa5  call rax
00007431745e0aa7  movaps xmm7, [rsp]
00007431745e0aab  add rsp, 0x30
00007431745e0aaf  vmovaps xmm0, [rsp]
00007431745e0ab4  vmovaps xmm1, [rsp+0x10]
00007431745e0aba  vmovaps xmm2, [rsp+0x20]
00007431745e0ac0  vmovaps xmm3, [rsp+0x30]
00007431745e0ac6  vmovaps xmm4, [rsp+0x40]
00007431745e0acc  vmovaps xmm5, [rsp+0x50]
00007431745e0ad2  vmovaps xmm6, [rsp+0x60]
00007431745e0ad8  vmovaps xmm8, [rsp+0x70]
00007431745e0ade  vmovaps xmm9, [rsp+0x80]
00007431745e0ae7  vmovaps xmm10, [rsp+0x90]
00007431745e0af0  vmovaps xmm11, [rsp+0xA0]
00007431745e0af9  vmovaps xmm12, [rsp+0xB0]
00007431745e0b02  vmovaps xmm13, [rsp+0xC0]
00007431745e0b0b  vmovaps xmm14, [rsp+0xD0]
00007431745e0b14  vmovaps xmm15, [rsp+0xE0]
00007431745e0b1d  add rsp, 0xF0
00007431745e0b24  pop r11
00007431745e0b26  pop r10
00007431745e0b28  pop r9
00007431745e0b2a  pop r8
00007431745e0b2c  pop rsi
00007431745e0b2d  pop rdi
00007431745e0b2e  pop rdx
00007431745e0b2f  pop rcx
00007431745e0b30  pop rax
00007431745e0b31  add rsp, 0x08
00007431745e0b35  jmp 0x00007431745DC685
00007431745e0b3a  sub rsp, 0x08
00007431745e0b3e  push rax
00007431745e0b3f  push rcx
00007431745e0b40  push rdx
00007431745e0b41  push rdi
00007431745e0b42  push rsi
00007431745e0b43  push r8
00007431745e0b45  push r9
00007431745e0b47  push r10
00007431745e0b49  push r11
00007431745e0b4b  sub rsp, 0xF0
00007431745e0b52  vmovaps [rsp], xmm0
00007431745e0b57  vmovaps [rsp+0x10], xmm1
00007431745e0b5d  vmovaps [rsp+0x20], xmm2
00007431745e0b63  vmovaps [rsp+0x30], xmm3
00007431745e0b69  vmovaps [rsp+0x40], xmm4
00007431745e0b6f  vmovaps [rsp+0x50], xmm5
00007431745e0b75  vmovaps [rsp+0x60], xmm6
00007431745e0b7b  vmovaps [rsp+0x70], xmm7
00007431745e0b81  vmovaps [rsp+0x80], xmm8
00007431745e0b8a  vmovaps [rsp+0x90], xmm9
00007431745e0b93  vmovaps [rsp+0xA0], xmm10
00007431745e0b9c  vmovaps [rsp+0xB0], xmm12
00007431745e0ba5  vmovaps [rsp+0xC0], xmm13
00007431745e0bae  vmovaps [rsp+0xD0], xmm14
00007431745e0bb7  vmovaps [rsp+0xE0], xmm15
00007431745e0bc0  sub rsp, 0x30
00007431745e0bc4  movaps [rsp], xmm11
00007431745e0bc9  movaps [rsp+0x10], xmm10
00007431745e0bcf  movaps [rsp+0x20], xmm14
00007431745e0bd5  lea rdi, [rsp]
00007431745e0bd9  mov esi, 0x00
00007431745e0bde  mov rax, 0x56C40959E530
00007431745e0be8  call rax
00007431745e0bea  movaps xmm11, [rsp]
00007431745e0bef  add rsp, 0x30
00007431745e0bf3  vmovaps xmm0, [rsp]
00007431745e0bf8  vmovaps xmm1, [rsp+0x10]
00007431745e0bfe  vmovaps xmm2, [rsp+0x20]
00007431745e0c04  vmovaps xmm3, [rsp+0x30]
00007431745e0c0a  vmovaps xmm4, [rsp+0x40]
00007431745e0c10  vmovaps xmm5, [rsp+0x50]
00007431745e0c16  vmovaps xmm6, [rsp+0x60]
00007431745e0c1c  vmovaps xmm7, [rsp+0x70]
00007431745e0c22  vmovaps xmm8, [rsp+0x80]
00007431745e0c2b  vmovaps xmm9, [rsp+0x90]
00007431745e0c34  vmovaps xmm10, [rsp+0xA0]
00007431745e0c3d  vmovaps xmm12, [rsp+0xB0]
00007431745e0c46  vmovaps xmm13, [rsp+0xC0]
00007431745e0c4f  vmovaps xmm14, [rsp+0xD0]
00007431745e0c58  vmovaps xmm15, [rsp+0xE0]
00007431745e0c61  add rsp, 0xF0
00007431745e0c68  pop r11
00007431745e0c6a  pop r10
00007431745e0c6c  pop r9
00007431745e0c6e  pop r8
00007431745e0c70  pop rsi
00007431745e0c71  pop rdi
00007431745e0c72  pop rdx
00007431745e0c73  pop rcx
00007431745e0c74  pop rax
00007431745e0c75  add rsp, 0x08
00007431745e0c79  jmp 0x00007431745DC6A0
00007431745e0c7e  call 0x00007431744C33A0
00007431745e0c83  jmp 0x00007431745DC6AA
00007431745e0c88  sub rsp, 0x08
00007431745e0c8c  push rax
00007431745e0c8d  push rcx
00007431745e0c8e  push rdx
00007431745e0c8f  push rdi
00007431745e0c90  push rsi
00007431745e0c91  push r8
00007431745e0c93  push r9
00007431745e0c95  push r10
00007431745e0c97  push r11
00007431745e0c99  sub rsp, 0xF0
00007431745e0ca0  vmovaps [rsp], xmm0
00007431745e0ca5  vmovaps [rsp+0x10], xmm1
00007431745e0cab  vmovaps [rsp+0x20], xmm2
00007431745e0cb1  vmovaps [rsp+0x30], xmm3
00007431745e0cb7  vmovaps [rsp+0x40], xmm4
00007431745e0cbd  vmovaps [rsp+0x50], xmm5
00007431745e0cc3  vmovaps [rsp+0x60], xmm6
00007431745e0cc9  vmovaps [rsp+0x70], xmm7
00007431745e0ccf  vmovaps [rsp+0x80], xmm8
00007431745e0cd8  vmovaps [rsp+0x90], xmm9
00007431745e0ce1  vmovaps [rsp+0xA0], xmm11
00007431745e0cea  vmovaps [rsp+0xB0], xmm12
00007431745e0cf3  vmovaps [rsp+0xC0], xmm13
00007431745e0cfc  vmovaps [rsp+0xD0], xmm14
00007431745e0d05  vmovaps [rsp+0xE0], xmm15
00007431745e0d0e  sub rsp, 0x30
00007431745e0d12  movaps [rsp], xmm10
00007431745e0d17  movaps [rsp+0x10], xmm1
00007431745e0d1c  movaps [rsp+0x20], xmm12
00007431745e0d22  lea rdi, [rsp]
00007431745e0d26  mov esi, 0x00
00007431745e0d2b  mov rax, 0x56C40959E530
00007431745e0d35  call rax
00007431745e0d37  movaps xmm10, [rsp]
00007431745e0d3c  add rsp, 0x30
00007431745e0d40  vmovaps xmm0, [rsp]
00007431745e0d45  vmovaps xmm1, [rsp+0x10]
00007431745e0d4b  vmovaps xmm2, [rsp+0x20]
00007431745e0d51  vmovaps xmm3, [rsp+0x30]
00007431745e0d57  vmovaps xmm4, [rsp+0x40]
00007431745e0d5d  vmovaps xmm5, [rsp+0x50]
00007431745e0d63  vmovaps xmm6, [rsp+0x60]
00007431745e0d69  vmovaps xmm7, [rsp+0x70]
00007431745e0d6f  vmovaps xmm8, [rsp+0x80]
00007431745e0d78  vmovaps xmm9, [rsp+0x90]
00007431745e0d81  vmovaps xmm11, [rsp+0xA0]
00007431745e0d8a  vmovaps xmm12, [rsp+0xB0]
00007431745e0d93  vmovaps xmm13, [rsp+0xC0]
00007431745e0d9c  vmovaps xmm14, [rsp+0xD0]
00007431745e0da5  vmovaps xmm15, [rsp+0xE0]
00007431745e0dae  add rsp, 0xF0
00007431745e0db5  pop r11
00007431745e0db7  pop r10
00007431745e0db9  pop r9
00007431745e0dbb  pop r8
00007431745e0dbd  pop rsi
00007431745e0dbe  pop rdi
00007431745e0dbf  pop rdx
00007431745e0dc0  pop rcx
00007431745e0dc1  pop rax
00007431745e0dc2  add rsp, 0x08
00007431745e0dc6  jmp 0x00007431745DC6CD
00007431745e0dcb  sub rsp, 0x08
00007431745e0dcf  push rax
00007431745e0dd0  push rcx
00007431745e0dd1  push rdx
00007431745e0dd2  push rdi
00007431745e0dd3  push rsi
00007431745e0dd4  push r8
00007431745e0dd6  push r9
00007431745e0dd8  push r10
00007431745e0dda  push r11
00007431745e0ddc  sub rsp, 0xF0
00007431745e0de3  vmovaps [rsp], xmm0
00007431745e0de8  vmovaps [rsp+0x10], xmm1
00007431745e0dee  vmovaps [rsp+0x20], xmm2
00007431745e0df4  vmovaps [rsp+0x30], xmm3
00007431745e0dfa  vmovaps [rsp+0x40], xmm4
00007431745e0e00  vmovaps [rsp+0x50], xmm5
00007431745e0e06  vmovaps [rsp+0x60], xmm6
00007431745e0e0c  vmovaps [rsp+0x70], xmm7
00007431745e0e12  vmovaps [rsp+0x80], xmm8
00007431745e0e1b  vmovaps [rsp+0x90], xmm9
00007431745e0e24  vmovaps [rsp+0xA0], xmm10
00007431745e0e2d  vmovaps [rsp+0xB0], xmm11
00007431745e0e36  vmovaps [rsp+0xC0], xmm13
00007431745e0e3f  vmovaps [rsp+0xD0], xmm14
00007431745e0e48  vmovaps [rsp+0xE0], xmm15
00007431745e0e51  sub rsp, 0x30
00007431745e0e55  movaps [rsp], xmm12
00007431745e0e5a  movaps [rsp+0x10], xmm14
00007431745e0e60  movaps [rsp+0x20], xmm1
00007431745e0e65  lea rdi, [rsp]
00007431745e0e69  mov esi, 0x00
00007431745e0e6e  mov rax, 0x56C40959E530
00007431745e0e78  call rax
00007431745e0e7a  movaps xmm12, [rsp]
00007431745e0e7f  add rsp, 0x30
00007431745e0e83  vmovaps xmm0, [rsp]
00007431745e0e88  vmovaps xmm1, [rsp+0x10]
00007431745e0e8e  vmovaps xmm2, [rsp+0x20]
00007431745e0e94  vmovaps xmm3, [rsp+0x30]
00007431745e0e9a  vmovaps xmm4, [rsp+0x40]
00007431745e0ea0  vmovaps xmm5, [rsp+0x50]
00007431745e0ea6  vmovaps xmm6, [rsp+0x60]
00007431745e0eac  vmovaps xmm7, [rsp+0x70]
00007431745e0eb2  vmovaps xmm8, [rsp+0x80]
00007431745e0ebb  vmovaps xmm9, [rsp+0x90]
00007431745e0ec4  vmovaps xmm10, [rsp+0xA0]
00007431745e0ecd  vmovaps xmm11, [rsp+0xB0]
00007431745e0ed6  vmovaps xmm13, [rsp+0xC0]
00007431745e0edf  vmovaps xmm14, [rsp+0xD0]
00007431745e0ee8  vmovaps xmm15, [rsp+0xE0]
00007431745e0ef1  add rsp, 0xF0
00007431745e0ef8  pop r11
00007431745e0efa  pop r10
00007431745e0efc  pop r9
00007431745e0efe  pop r8
00007431745e0f00  pop rsi
00007431745e0f01  pop rdi
00007431745e0f02  pop rdx
00007431745e0f03  pop rcx
00007431745e0f04  pop rax
00007431745e0f05  add rsp, 0x08
00007431745e0f09  jmp 0x00007431745DC6FC
00007431745e0f0e  sub rsp, 0x08
00007431745e0f12  push rax
00007431745e0f13  push rcx
00007431745e0f14  push rdx
00007431745e0f15  push rdi
00007431745e0f16  push rsi
00007431745e0f17  push r8
00007431745e0f19  push r9
00007431745e0f1b  push r10
00007431745e0f1d  push r11
00007431745e0f1f  sub rsp, 0xF0
00007431745e0f26  vmovaps [rsp], xmm0
00007431745e0f2b  vmovaps [rsp+0x10], xmm1
00007431745e0f31  vmovaps [rsp+0x20], xmm2
00007431745e0f37  vmovaps [rsp+0x30], xmm3
00007431745e0f3d  vmovaps [rsp+0x40], xmm4
00007431745e0f43  vmovaps [rsp+0x50], xmm5
00007431745e0f49  vmovaps [rsp+0x60], xmm6
00007431745e0f4f  vmovaps [rsp+0x70], xmm7
00007431745e0f55  vmovaps [rsp+0x80], xmm8
00007431745e0f5e  vmovaps [rsp+0x90], xmm9
00007431745e0f67  vmovaps [rsp+0xA0], xmm10
00007431745e0f70  vmovaps [rsp+0xB0], xmm11
00007431745e0f79  vmovaps [rsp+0xC0], xmm12
00007431745e0f82  vmovaps [rsp+0xD0], xmm13
00007431745e0f8b  vmovaps [rsp+0xE0], xmm15
00007431745e0f94  sub rsp, 0x30
00007431745e0f98  movaps [rsp], xmm14
00007431745e0f9d  movaps [rsp+0x10], xmm9
00007431745e0fa3  movaps [rsp+0x20], xmm1
00007431745e0fa8  lea rdi, [rsp]
00007431745e0fac  mov esi, 0x00
00007431745e0fb1  mov rax, 0x56C40959E530
00007431745e0fbb  call rax
00007431745e0fbd  movaps xmm14, [rsp]
00007431745e0fc2  add rsp, 0x30
00007431745e0fc6  vmovaps xmm0, [rsp]
00007431745e0fcb  vmovaps xmm1, [rsp+0x10]
00007431745e0fd1  vmovaps xmm2, [rsp+0x20]
00007431745e0fd7  vmovaps xmm3, [rsp+0x30]
00007431745e0fdd  vmovaps xmm4, [rsp+0x40]
00007431745e0fe3  vmovaps xmm5, [rsp+0x50]
00007431745e0fe9  vmovaps xmm6, [rsp+0x60]
00007431745e0fef  vmovaps xmm7, [rsp+0x70]
00007431745e0ff5  vmovaps xmm8, [rsp+0x80]
00007431745e0ffe  vmovaps xmm9, [rsp+0x90]
00007431745e1007  vmovaps xmm10, [rsp+0xA0]
00007431745e1010  vmovaps xmm11, [rsp+0xB0]
00007431745e1019  vmovaps xmm12, [rsp+0xC0]
00007431745e1022  vmovaps xmm13, [rsp+0xD0]
00007431745e102b  vmovaps xmm15, [rsp+0xE0]
00007431745e1034  add rsp, 0xF0
00007431745e103b  pop r11
00007431745e103d  pop r10
00007431745e103f  pop r9
00007431745e1041  pop r8
00007431745e1043  pop rsi
00007431745e1044  pop rdi
00007431745e1045  pop rdx
00007431745e1046  pop rcx
00007431745e1047  pop rax
00007431745e1048  add rsp, 0x08
00007431745e104c  jmp 0x00007431745DC72B
00007431745e1051  sub rsp, 0x08
00007431745e1055  push rax
00007431745e1056  push rcx
00007431745e1057  push rdx
00007431745e1058  push rdi
00007431745e1059  push rsi
00007431745e105a  push r8
00007431745e105c  push r9
00007431745e105e  push r10
00007431745e1060  push r11
00007431745e1062  sub rsp, 0xF0
00007431745e1069  vmovaps [rsp], xmm0
00007431745e106e  vmovaps [rsp+0x10], xmm2
00007431745e1074  vmovaps [rsp+0x20], xmm3
00007431745e107a  vmovaps [rsp+0x30], xmm4
00007431745e1080  vmovaps [rsp+0x40], xmm5
00007431745e1086  vmovaps [rsp+0x50], xmm6
00007431745e108c  vmovaps [rsp+0x60], xmm7
00007431745e1092  vmovaps [rsp+0x70], xmm8
00007431745e1098  vmovaps [rsp+0x80], xmm9
00007431745e10a1  vmovaps [rsp+0x90], xmm10
00007431745e10aa  vmovaps [rsp+0xA0], xmm11
00007431745e10b3  vmovaps [rsp+0xB0], xmm12
00007431745e10bc  vmovaps [rsp+0xC0], xmm13
00007431745e10c5  vmovaps [rsp+0xD0], xmm14
00007431745e10ce  vmovaps [rsp+0xE0], xmm15
00007431745e10d7  sub rsp, 0x30
00007431745e10db  movaps [rsp], xmm1
00007431745e10df  movaps [rsp+0x10], xmm13
00007431745e10e5  movaps [rsp+0x20], xmm8
00007431745e10eb  lea rdi, [rsp]
00007431745e10ef  mov esi, 0x00
00007431745e10f4  mov rax, 0x56C40959E530
00007431745e10fe  call rax
00007431745e1100  movaps xmm1, [rsp]
00007431745e1104  add rsp, 0x30
00007431745e1108  vmovaps xmm0, [rsp]
00007431745e110d  vmovaps xmm2, [rsp+0x10]
00007431745e1113  vmovaps xmm3, [rsp+0x20]
00007431745e1119  vmovaps xmm4, [rsp+0x30]
00007431745e111f  vmovaps xmm5, [rsp+0x40]
00007431745e1125  vmovaps xmm6, [rsp+0x50]
00007431745e112b  vmovaps xmm7, [rsp+0x60]
00007431745e1131  vmovaps xmm8, [rsp+0x70]
00007431745e1137  vmovaps xmm9, [rsp+0x80]
00007431745e1140  vmovaps xmm10, [rsp+0x90]
00007431745e1149  vmovaps xmm11, [rsp+0xA0]
00007431745e1152  vmovaps xmm12, [rsp+0xB0]
00007431745e115b  vmovaps xmm13, [rsp+0xC0]
00007431745e1164  vmovaps xmm14, [rsp+0xD0]
00007431745e116d  vmovaps xmm15, [rsp+0xE0]
00007431745e1176  add rsp, 0xF0
00007431745e117d  pop r11
00007431745e117f  pop r10
00007431745e1181  pop r9
00007431745e1183  pop r8
00007431745e1185  pop rsi
00007431745e1186  pop rdi
00007431745e1187  pop rdx
00007431745e1188  pop rcx
00007431745e1189  pop rax
00007431745e118a  add rsp, 0x08
00007431745e118e  jmp 0x00007431745DC74D
00007431745e1193  call 0x000074317440C260
00007431745e1198  jmp 0x00007431745DC75B
00007431745e119d  call 0x00007431744BD750
00007431745e11a2  jmp 0x00007431745DC765
00007431745e11a7  sub rsp, 0x08
00007431745e11ab  push rax
00007431745e11ac  push rcx
00007431745e11ad  push rdx
00007431745e11ae  push rdi
00007431745e11af  push rsi
00007431745e11b0  push r8
00007431745e11b2  push r9
00007431745e11b4  push r10
00007431745e11b6  push r11
00007431745e11b8  sub rsp, 0xF0
00007431745e11bf  vmovaps [rsp], xmm0
00007431745e11c4  vmovaps [rsp+0x10], xmm1
00007431745e11ca  vmovaps [rsp+0x20], xmm2
00007431745e11d0  vmovaps [rsp+0x30], xmm3
00007431745e11d6  vmovaps [rsp+0x40], xmm4
00007431745e11dc  vmovaps [rsp+0x50], xmm5
00007431745e11e2  vmovaps [rsp+0x60], xmm6
00007431745e11e8  vmovaps [rsp+0x70], xmm7
00007431745e11ee  vmovaps [rsp+0x80], xmm9
00007431745e11f7  vmovaps [rsp+0x90], xmm10
00007431745e1200  vmovaps [rsp+0xA0], xmm11
00007431745e1209  vmovaps [rsp+0xB0], xmm12
00007431745e1212  vmovaps [rsp+0xC0], xmm13
00007431745e121b  vmovaps [rsp+0xD0], xmm14
00007431745e1224  vmovaps [rsp+0xE0], xmm15
00007431745e122d  sub rsp, 0x30
00007431745e1231  movaps [rsp], xmm8
00007431745e1236  movaps [rsp+0x10], xmm15
00007431745e123c  movaps [rsp+0x20], xmm7
00007431745e1241  lea rdi, [rsp]
00007431745e1245  mov esi, 0x00
00007431745e124a  mov rax, 0x56C40959E530
00007431745e1254  call rax
00007431745e1256  movaps xmm8, [rsp]
00007431745e125b  add rsp, 0x30
00007431745e125f  vmovaps xmm0, [rsp]
00007431745e1264  vmovaps xmm1, [rsp+0x10]
00007431745e126a  vmovaps xmm2, [rsp+0x20]
00007431745e1270  vmovaps xmm3, [rsp+0x30]
00007431745e1276  vmovaps xmm4, [rsp+0x40]
00007431745e127c  vmovaps xmm5, [rsp+0x50]
00007431745e1282  vmovaps xmm6, [rsp+0x60]
00007431745e1288  vmovaps xmm7, [rsp+0x70]
00007431745e128e  vmovaps xmm9, [rsp+0x80]
00007431745e1297  vmovaps xmm10, [rsp+0x90]
00007431745e12a0  vmovaps xmm11, [rsp+0xA0]
00007431745e12a9  vmovaps xmm12, [rsp+0xB0]
00007431745e12b2  vmovaps xmm13, [rsp+0xC0]
00007431745e12bb  vmovaps xmm14, [rsp+0xD0]
00007431745e12c4  vmovaps xmm15, [rsp+0xE0]
00007431745e12cd  add rsp, 0xF0
00007431745e12d4  pop r11
00007431745e12d6  pop r10
00007431745e12d8  pop r9
00007431745e12da  pop r8
00007431745e12dc  pop rsi
00007431745e12dd  pop rdi
00007431745e12de  pop rdx
00007431745e12df  pop rcx
00007431745e12e0  pop rax
00007431745e12e1  add rsp, 0x08
00007431745e12e5  jmp 0x00007431745DC787
00007431745e12ea  sub rsp, 0x08
00007431745e12ee  push rax
00007431745e12ef  push rcx
00007431745e12f0  push rdx
00007431745e12f1  push rdi
00007431745e12f2  push rsi
00007431745e12f3  push r8
00007431745e12f5  push r9
00007431745e12f7  push r10
00007431745e12f9  push r11
00007431745e12fb  sub rsp, 0xF0
00007431745e1302  vmovaps [rsp], xmm0
00007431745e1307  vmovaps [rsp+0x10], xmm1
00007431745e130d  vmovaps [rsp+0x20], xmm2
00007431745e1313  vmovaps [rsp+0x30], xmm3
00007431745e1319  vmovaps [rsp+0x40], xmm4
00007431745e131f  vmovaps [rsp+0x50], xmm5
00007431745e1325  vmovaps [rsp+0x60], xmm6
00007431745e132b  vmovaps [rsp+0x70], xmm8
00007431745e1331  vmovaps [rsp+0x80], xmm9
00007431745e133a  vmovaps [rsp+0x90], xmm10
00007431745e1343  vmovaps [rsp+0xA0], xmm11
00007431745e134c  vmovaps [rsp+0xB0], xmm12
00007431745e1355  vmovaps [rsp+0xC0], xmm13
00007431745e135e  vmovaps [rsp+0xD0], xmm14
00007431745e1367  vmovaps [rsp+0xE0], xmm15
00007431745e1370  sub rsp, 0x30
00007431745e1374  movaps [rsp], xmm7
00007431745e1378  movaps [rsp+0x10], xmm9
00007431745e137e  movaps [rsp+0x20], xmm15
00007431745e1384  lea rdi, [rsp]
00007431745e1388  mov esi, 0x00
00007431745e138d  mov rax, 0x56C40959E530
00007431745e1397  call rax
00007431745e1399  movaps xmm7, [rsp]
00007431745e139d  add rsp, 0x30
00007431745e13a1  vmovaps xmm0, [rsp]
00007431745e13a6  vmovaps xmm1, [rsp+0x10]
00007431745e13ac  vmovaps xmm2, [rsp+0x20]
00007431745e13b2  vmovaps xmm3, [rsp+0x30]
00007431745e13b8  vmovaps xmm4, [rsp+0x40]
00007431745e13be  vmovaps xmm5, [rsp+0x50]
00007431745e13c4  vmovaps xmm6, [rsp+0x60]
00007431745e13ca  vmovaps xmm8, [rsp+0x70]
00007431745e13d0  vmovaps xmm9, [rsp+0x80]
00007431745e13d9  vmovaps xmm10, [rsp+0x90]
00007431745e13e2  vmovaps xmm11, [rsp+0xA0]
00007431745e13eb  vmovaps xmm12, [rsp+0xB0]
00007431745e13f4  vmovaps xmm13, [rsp+0xC0]
00007431745e13fd  vmovaps xmm14, [rsp+0xD0]
00007431745e1406  vmovaps xmm15, [rsp+0xE0]
00007431745e140f  add rsp, 0xF0
00007431745e1416  pop r11
00007431745e1418  pop r10
00007431745e141a  pop r9
00007431745e141c  pop r8
00007431745e141e  pop rsi
00007431745e141f  pop rdi
00007431745e1420  pop rdx
00007431745e1421  pop rcx
00007431745e1422  pop rax
00007431745e1423  add rsp, 0x08
00007431745e1427  jmp 0x00007431745DC7B4
00007431745e142c  sub rsp, 0x08
00007431745e1430  push rax
00007431745e1431  push rcx
00007431745e1432  push rdx
00007431745e1433  push rdi
00007431745e1434  push rsi
00007431745e1435  push r8
00007431745e1437  push r9
00007431745e1439  push r10
00007431745e143b  push r11
00007431745e143d  sub rsp, 0xF0
00007431745e1444  vmovaps [rsp], xmm0
00007431745e1449  vmovaps [rsp+0x10], xmm1
00007431745e144f  vmovaps [rsp+0x20], xmm2
00007431745e1455  vmovaps [rsp+0x30], xmm3
00007431745e145b  vmovaps [rsp+0x40], xmm4
00007431745e1461  vmovaps [rsp+0x50], xmm5
00007431745e1467  vmovaps [rsp+0x60], xmm6
00007431745e146d  vmovaps [rsp+0x70], xmm7
00007431745e1473  vmovaps [rsp+0x80], xmm8
00007431745e147c  vmovaps [rsp+0x90], xmm10
00007431745e1485  vmovaps [rsp+0xA0], xmm11
00007431745e148e  vmovaps [rsp+0xB0], xmm12
00007431745e1497  vmovaps [rsp+0xC0], xmm13
00007431745e14a0  vmovaps [rsp+0xD0], xmm14
00007431745e14a9  vmovaps [rsp+0xE0], xmm15
00007431745e14b2  sub rsp, 0x30
00007431745e14b6  movaps [rsp], xmm9
00007431745e14bb  movaps [rsp+0x10], xmm13
00007431745e14c1  movaps [rsp+0x20], xmm15
00007431745e14c7  lea rdi, [rsp]
00007431745e14cb  mov esi, 0x00
00007431745e14d0  mov rax, 0x56C40959E530
00007431745e14da  call rax
00007431745e14dc  movaps xmm9, [rsp]
00007431745e14e1  add rsp, 0x30
00007431745e14e5  vmovaps xmm0, [rsp]
00007431745e14ea  vmovaps xmm1, [rsp+0x10]
00007431745e14f0  vmovaps xmm2, [rsp+0x20]
00007431745e14f6  vmovaps xmm3, [rsp+0x30]
00007431745e14fc  vmovaps xmm4, [rsp+0x40]
00007431745e1502  vmovaps xmm5, [rsp+0x50]
00007431745e1508  vmovaps xmm6, [rsp+0x60]
00007431745e150e  vmovaps xmm7, [rsp+0x70]
00007431745e1514  vmovaps xmm8, [rsp+0x80]
00007431745e151d  vmovaps xmm10, [rsp+0x90]
00007431745e1526  vmovaps xmm11, [rsp+0xA0]
00007431745e152f  vmovaps xmm12, [rsp+0xB0]
00007431745e1538  vmovaps xmm13, [rsp+0xC0]
00007431745e1541  vmovaps xmm14, [rsp+0xD0]
00007431745e154a  vmovaps xmm15, [rsp+0xE0]
00007431745e1553  add rsp, 0xF0
00007431745e155a  pop r11
00007431745e155c  pop r10
00007431745e155e  pop r9
00007431745e1560  pop r8
00007431745e1562  pop rsi
00007431745e1563  pop rdi
00007431745e1564  pop rdx
00007431745e1565  pop rcx
00007431745e1566  pop rax
00007431745e1567  add rsp, 0x08
00007431745e156b  jmp 0x00007431745DC7E2
00007431745e1570  sub rsp, 0x08
00007431745e1574  push rax
00007431745e1575  push rcx
00007431745e1576  push rdx
00007431745e1577  push rdi
00007431745e1578  push rsi
00007431745e1579  push r8
00007431745e157b  push r9
00007431745e157d  push r10
00007431745e157f  push r11
00007431745e1581  sub rsp, 0xF0
00007431745e1588  vmovaps [rsp], xmm0
00007431745e158d  vmovaps [rsp+0x10], xmm1
00007431745e1593  vmovaps [rsp+0x20], xmm2
00007431745e1599  vmovaps [rsp+0x30], xmm3
00007431745e159f  vmovaps [rsp+0x40], xmm4
00007431745e15a5  vmovaps [rsp+0x50], xmm5
00007431745e15ab  vmovaps [rsp+0x60], xmm6
00007431745e15b1  vmovaps [rsp+0x70], xmm7
00007431745e15b7  vmovaps [rsp+0x80], xmm8
00007431745e15c0  vmovaps [rsp+0x90], xmm9
00007431745e15c9  vmovaps [rsp+0xA0], xmm10
00007431745e15d2  vmovaps [rsp+0xB0], xmm11
00007431745e15db  vmovaps [rsp+0xC0], xmm12
00007431745e15e4  vmovaps [rsp+0xD0], xmm13
00007431745e15ed  vmovaps [rsp+0xE0], xmm14
00007431745e15f6  sub rsp, 0x30
00007431745e15fa  movaps [rsp], xmm15
00007431745e15ff  movaps [rsp+0x10], xmm11
00007431745e1605  movaps [rsp+0x20], xmm12
00007431745e160b  lea rdi, [rsp]
00007431745e160f  mov esi, 0x00
00007431745e1614  mov rax, 0x56C40959E530
00007431745e161e  call rax
00007431745e1620  movaps xmm15, [rsp]
00007431745e1625  add rsp, 0x30
00007431745e1629  vmovaps xmm0, [rsp]
00007431745e162e  vmovaps xmm1, [rsp+0x10]
00007431745e1634  vmovaps xmm2, [rsp+0x20]
00007431745e163a  vmovaps xmm3, [rsp+0x30]
00007431745e1640  vmovaps xmm4, [rsp+0x40]
00007431745e1646  vmovaps xmm5, [rsp+0x50]
00007431745e164c  vmovaps xmm6, [rsp+0x60]
00007431745e1652  vmovaps xmm7, [rsp+0x70]
00007431745e1658  vmovaps xmm8, [rsp+0x80]
00007431745e1661  vmovaps xmm9, [rsp+0x90]
00007431745e166a  vmovaps xmm10, [rsp+0xA0]
00007431745e1673  vmovaps xmm11, [rsp+0xB0]
00007431745e167c  vmovaps xmm12, [rsp+0xC0]
00007431745e1685  vmovaps xmm13, [rsp+0xD0]
00007431745e168e  vmovaps xmm14, [rsp+0xE0]
00007431745e1697  add rsp, 0xF0
00007431745e169e  pop r11
00007431745e16a0  pop r10
00007431745e16a2  pop r9
00007431745e16a4  pop r8
00007431745e16a6  pop rsi
00007431745e16a7  pop rdi
00007431745e16a8  pop rdx
00007431745e16a9  pop rcx
00007431745e16aa  pop rax
00007431745e16ab  add rsp, 0x08
00007431745e16af  jmp 0x00007431745DC7FD
00007431745e16b4  sub rsp, 0x08
00007431745e16b8  push rax
00007431745e16b9  push rcx
00007431745e16ba  push rdx
00007431745e16bb  push rdi
00007431745e16bc  push rsi
00007431745e16bd  push r8
00007431745e16bf  push r9
00007431745e16c1  push r10
00007431745e16c3  push r11
00007431745e16c5  sub rsp, 0xF0
00007431745e16cc  vmovaps [rsp], xmm0
00007431745e16d1  vmovaps [rsp+0x10], xmm1
00007431745e16d7  vmovaps [rsp+0x20], xmm2
00007431745e16dd  vmovaps [rsp+0x30], xmm3
00007431745e16e3  vmovaps [rsp+0x40], xmm4
00007431745e16e9  vmovaps [rsp+0x50], xmm5
00007431745e16ef  vmovaps [rsp+0x60], xmm6
00007431745e16f5  vmovaps [rsp+0x70], xmm7
00007431745e16fb  vmovaps [rsp+0x80], xmm8
00007431745e1704  vmovaps [rsp+0x90], xmm9
00007431745e170d  vmovaps [rsp+0xA0], xmm10
00007431745e1716  vmovaps [rsp+0xB0], xmm11
00007431745e171f  vmovaps [rsp+0xC0], xmm12
00007431745e1728  vmovaps [rsp+0xD0], xmm14
00007431745e1731  vmovaps [rsp+0xE0], xmm15
00007431745e173a  sub rsp, 0x30
00007431745e173e  movaps [rsp], xmm13
00007431745e1743  movaps [rsp+0x10], xmm10
00007431745e1749  movaps [rsp+0x20], xmm14
00007431745e174f  lea rdi, [rsp]
00007431745e1753  mov esi, 0x00
00007431745e1758  mov rax, 0x56C40959E530
00007431745e1762  call rax
00007431745e1764  movaps xmm13, [rsp]
00007431745e1769  add rsp, 0x30
00007431745e176d  vmovaps xmm0, [rsp]
00007431745e1772  vmovaps xmm1, [rsp+0x10]
00007431745e1778  vmovaps xmm2, [rsp+0x20]
00007431745e177e  vmovaps xmm3, [rsp+0x30]
00007431745e1784  vmovaps xmm4, [rsp+0x40]
00007431745e178a  vmovaps xmm5, [rsp+0x50]
00007431745e1790  vmovaps xmm6, [rsp+0x60]
00007431745e1796  vmovaps xmm7, [rsp+0x70]
00007431745e179c  vmovaps xmm8, [rsp+0x80]
00007431745e17a5  vmovaps xmm9, [rsp+0x90]
00007431745e17ae  vmovaps xmm10, [rsp+0xA0]
00007431745e17b7  vmovaps xmm11, [rsp+0xB0]
00007431745e17c0  vmovaps xmm12, [rsp+0xC0]
00007431745e17c9  vmovaps xmm14, [rsp+0xD0]
00007431745e17d2  vmovaps xmm15, [rsp+0xE0]
00007431745e17db  add rsp, 0xF0
00007431745e17e2  pop r11
00007431745e17e4  pop r10
00007431745e17e6  pop r9
00007431745e17e8  pop r8
00007431745e17ea  pop rsi
00007431745e17eb  pop rdi
00007431745e17ec  pop rdx
00007431745e17ed  pop rcx
00007431745e17ee  pop rax
00007431745e17ef  add rsp, 0x08
00007431745e17f3  jmp 0x00007431745DC820
00007431745e17f8  sub rsp, 0x08
00007431745e17fc  push rax
00007431745e17fd  push rcx
00007431745e17fe  push rdx
00007431745e17ff  push rdi
00007431745e1800  push rsi
00007431745e1801  push r8
00007431745e1803  push r9
00007431745e1805  push r10
00007431745e1807  push r11
00007431745e1809  sub rsp, 0xF0
00007431745e1810  vmovaps [rsp], xmm0
00007431745e1815  vmovaps [rsp+0x10], xmm1
00007431745e181b  vmovaps [rsp+0x20], xmm2
00007431745e1821  vmovaps [rsp+0x30], xmm3
00007431745e1827  vmovaps [rsp+0x40], xmm4
00007431745e182d  vmovaps [rsp+0x50], xmm5
00007431745e1833  vmovaps [rsp+0x60], xmm6
00007431745e1839  vmovaps [rsp+0x70], xmm7
00007431745e183f  vmovaps [rsp+0x80], xmm8
00007431745e1848  vmovaps [rsp+0x90], xmm9
00007431745e1851  vmovaps [rsp+0xA0], xmm10
00007431745e185a  vmovaps [rsp+0xB0], xmm11
00007431745e1863  vmovaps [rsp+0xC0], xmm12
00007431745e186c  vmovaps [rsp+0xD0], xmm13
00007431745e1875  vmovaps [rsp+0xE0], xmm15
00007431745e187e  sub rsp, 0x30
00007431745e1882  movaps [rsp], xmm14
00007431745e1887  movaps [rsp+0x10], xmm1
00007431745e188c  movaps [rsp+0x20], xmm7
00007431745e1891  lea rdi, [rsp]
00007431745e1895  mov esi, 0x00
00007431745e189a  mov rax, 0x56C40959E530
00007431745e18a4  call rax
00007431745e18a6  movaps xmm14, [rsp]
00007431745e18ab  add rsp, 0x30
00007431745e18af  vmovaps xmm0, [rsp]
00007431745e18b4  vmovaps xmm1, [rsp+0x10]
00007431745e18ba  vmovaps xmm2, [rsp+0x20]
00007431745e18c0  vmovaps xmm3, [rsp+0x30]
00007431745e18c6  vmovaps xmm4, [rsp+0x40]
00007431745e18cc  vmovaps xmm5, [rsp+0x50]
00007431745e18d2  vmovaps xmm6, [rsp+0x60]
00007431745e18d8  vmovaps xmm7, [rsp+0x70]
00007431745e18de  vmovaps xmm8, [rsp+0x80]
00007431745e18e7  vmovaps xmm9, [rsp+0x90]
00007431745e18f0  vmovaps xmm10, [rsp+0xA0]
00007431745e18f9  vmovaps xmm11, [rsp+0xB0]
00007431745e1902  vmovaps xmm12, [rsp+0xC0]
00007431745e190b  vmovaps xmm13, [rsp+0xD0]
00007431745e1914  vmovaps xmm15, [rsp+0xE0]
00007431745e191d  add rsp, 0xF0
00007431745e1924  pop r11
00007431745e1926  pop r10
00007431745e1928  pop r9
00007431745e192a  pop r8
00007431745e192c  pop rsi
00007431745e192d  pop rdi
00007431745e192e  pop rdx
00007431745e192f  pop rcx
00007431745e1930  pop rax
00007431745e1931  add rsp, 0x08
00007431745e1935  jmp 0x00007431745DC843
00007431745e193a  sub rsp, 0x08
00007431745e193e  push rax
00007431745e193f  push rcx
00007431745e1940  push rdx
00007431745e1941  push rdi
00007431745e1942  push rsi
00007431745e1943  push r8
00007431745e1945  push r9
00007431745e1947  push r10
00007431745e1949  push r11
00007431745e194b  sub rsp, 0xF0
00007431745e1952  vmovaps [rsp], xmm0
00007431745e1957  vmovaps [rsp+0x10], xmm2
00007431745e195d  vmovaps [rsp+0x20], xmm3
00007431745e1963  vmovaps [rsp+0x30], xmm4
00007431745e1969  vmovaps [rsp+0x40], xmm5
00007431745e196f  vmovaps [rsp+0x50], xmm6
00007431745e1975  vmovaps [rsp+0x60], xmm7
00007431745e197b  vmovaps [rsp+0x70], xmm8
00007431745e1981  vmovaps [rsp+0x80], xmm9
00007431745e198a  vmovaps [rsp+0x90], xmm10
00007431745e1993  vmovaps [rsp+0xA0], xmm11
00007431745e199c  vmovaps [rsp+0xB0], xmm12
00007431745e19a5  vmovaps [rsp+0xC0], xmm13
00007431745e19ae  vmovaps [rsp+0xD0], xmm14
00007431745e19b7  vmovaps [rsp+0xE0], xmm15
00007431745e19c0  sub rsp, 0x30
00007431745e19c4  movaps [rsp], xmm1
00007431745e19c8  movaps [rsp+0x10], xmm8
00007431745e19ce  movaps [rsp+0x20], xmm9
00007431745e19d4  lea rdi, [rsp]
00007431745e19d8  mov esi, 0x00
00007431745e19dd  mov rax, 0x56C40959E530
00007431745e19e7  call rax
00007431745e19e9  movaps xmm1, [rsp]
00007431745e19ed  add rsp, 0x30
00007431745e19f1  vmovaps xmm0, [rsp]
00007431745e19f6  vmovaps xmm2, [rsp+0x10]
00007431745e19fc  vmovaps xmm3, [rsp+0x20]
00007431745e1a02  vmovaps xmm4, [rsp+0x30]
00007431745e1a08  vmovaps xmm5, [rsp+0x40]
00007431745e1a0e  vmovaps xmm6, [rsp+0x50]
00007431745e1a14  vmovaps xmm7, [rsp+0x60]
00007431745e1a1a  vmovaps xmm8, [rsp+0x70]
00007431745e1a20  vmovaps xmm9, [rsp+0x80]
00007431745e1a29  vmovaps xmm10, [rsp+0x90]
00007431745e1a32  vmovaps xmm11, [rsp+0xA0]
00007431745e1a3b  vmovaps xmm12, [rsp+0xB0]
00007431745e1a44  vmovaps xmm13, [rsp+0xC0]
00007431745e1a4d  vmovaps xmm14, [rsp+0xD0]
00007431745e1a56  vmovaps xmm15, [rsp+0xE0]
00007431745e1a5f  add rsp, 0xF0
00007431745e1a66  pop r11
00007431745e1a68  pop r10
00007431745e1a6a  pop r9
00007431745e1a6c  pop r8
00007431745e1a6e  pop rsi
00007431745e1a6f  pop rdi
00007431745e1a70  pop rdx
00007431745e1a71  pop rcx
00007431745e1a72  pop rax
00007431745e1a73  add rsp, 0x08
00007431745e1a77  jmp 0x00007431745DC865
00007431745e1a7c  call 0x00007431744E5940
00007431745e1a81  jmp 0x00007431745DC873
00007431745e1a86  call 0x000074317440C380
00007431745e1a8b  jmp 0x00007431745DC87D
00007431745e1a90  call 0x000074317440D600
00007431745e1a95  jmp 0x00007431745DC887
00007431745e1a9a  call 0x00007431743FF540
00007431745e1a9f  jmp 0x00007431745DC891
00007431745e1aa4  int3
00007431745e1aa5  nop [rax+rax*1], ax
00007431745e1aae  nop
00007431745e1ab0  mov rax, [r15+0xF8]
00007431745e1ab7  lea r14, [rax+0x140]
00007431745e1abe  mov r12, [r13+r14*1]
00007431745e1ac3  mov [r15+0xE8], r12
00007431745e1aca  lea r14, [rax+0x130]
00007431745e1ad1  mov r12, [r13+r14*1]
00007431745e1ad6  lea r14, [rax+0x138]
00007431745e1add  mov r11, [r13+r14*1]
00007431745e1ae2  movq xmm1, r12
00007431745e1ae7  movq xmm15, r11
00007431745e1aec  movq xmm1, xmm1
00007431745e1af0  movq xmm1, xmm1
00007431745e1af4  movaps [r15+0x1A0], xmm1
00007431745e1afc  movq xmm15, xmm15
00007431745e1b01  movq xmm15, xmm15
00007431745e1b06  movaps [r15+0x190], xmm15
00007431745e1b0e  lea r14, [rax+0x120]
00007431745e1b15  mov r12, [r13+r14*1]
00007431745e1b1a  lea r14, [rax+0x128]
00007431745e1b21  mov r11, [r13+r14*1]
00007431745e1b26  movq xmm1, r12
00007431745e1b2b  movq xmm15, r11
00007431745e1b30  movq xmm1, xmm1
00007431745e1b34  movq xmm1, xmm1
00007431745e1b38  movaps [r15+0x1C0], xmm1
00007431745e1b40  movq xmm15, xmm15
00007431745e1b45  movq xmm15, xmm15
00007431745e1b4a  movaps [r15+0x1B0], xmm15
00007431745e1b52  lea r14, [rax+0x110]
00007431745e1b59  mov r12, [r13+r14*1]
00007431745e1b5e  lea r14, [rax+0x118]
00007431745e1b65  mov r11, [r13+r14*1]
00007431745e1b6a  movq xmm1, r12
00007431745e1b6f  movq xmm15, r11
00007431745e1b74  movq xmm1, xmm1
00007431745e1b78  movq xmm1, xmm1
00007431745e1b7c  movaps [r15+0x1E0], xmm1
00007431745e1b84  movq xmm15, xmm15
00007431745e1b89  movq xmm15, xmm15
00007431745e1b8e  movaps [r15+0x1D0], xmm15
00007431745e1b96  lea r14, [rax+0x100]
00007431745e1b9d  mov r12, [r13+r14*1]
00007431745e1ba2  lea r14, [rax+0x108]
00007431745e1ba9  mov r11, [r13+r14*1]
00007431745e1bae  movq xmm1, r12
00007431745e1bb3  movq xmm15, r11
00007431745e1bb8  movq xmm1, xmm1
00007431745e1bbc  movq xmm1, xmm1
00007431745e1bc0  movaps [r15+0x200], xmm1
00007431745e1bc8  movq xmm15, xmm15
00007431745e1bcd  movq xmm15, xmm15
00007431745e1bd2  movaps [r15+0x1F0], xmm15
00007431745e1bda  mov qword ptr [r15+0x40], 0x430000
00007431745e1be2  mov r14d, 0x430510
00007431745e1be8  mov r12, [r13+r14*1]
00007431745e1bed  movq xmm1, r12
00007431745e1bf2  lea r14, [rax+0x150]
00007431745e1bf9  mov [r15+0xF8], r14
00007431745e1c00  mov rax, [r15+0x50]
00007431745e1c04  movups xmm15, [r13+rax*1]
00007431745e1c0a  movaps [r15+0x120], xmm15
00007431745e1c12  mov qword ptr [r15+0x48], 0x10
00007431745e1c1a  xor eax, eax
00007431745e1c1c  mov r14d, 0x10
00007431745e1c22  mov r12d, 0x200
00007431745e1c28  cmp r14, r12
00007431745e1c2b  cmc
00007431745e1c2c  lahf
00007431745e1c2d  seto al
00007431745e1c30  mov [r15+0x108], eax
00007431745e1c37  pextrq rax, xmm15, 0x01
00007431745e1c3e  movq xmm14, rax
00007431745e1c43  movaps [r15+0x130], xmm14
00007431745e1c4b  movq rax, xmm1
00007431745e1c50  movq r14, xmm15
00007431745e1c55  vmovq xmm1, rax
00007431745e1c5a  vmovq xmm15, r14
00007431745e1c5f  movaps xmm13, xmm1
00007431745e1c63  addsd xmm13, xmm15
00007431745e1c68  ucomisd xmm13, xmm13
00007431745e1c6d  jp 0x00007431745E1D86
00007431745e1c73  movq xmm13, xmm13
00007431745e1c78  movq rax, xmm13
00007431745e1c7d  movq r14, xmm14
00007431745e1c82  vmovq xmm1, rax
00007431745e1c87  vmovq xmm15, r14
00007431745e1c8c  movaps xmm14, xmm1
00007431745e1c90  addsd xmm14, xmm15
00007431745e1c95  ucomisd xmm14, xmm14
00007431745e1c9a  jp 0x00007431745E1DCE
00007431745e1ca0  movq xmm14, xmm14
00007431745e1ca5  movaps [r15+0x110], xmm14
00007431745e1cad  mov eax, [r15+0x108]
00007431745e1cb4  sahf
00007431745e1cb5  jnz 0x00007431745E1CE7
00007431745e1cb7  cmp dword ptr [r15+0x318], 0x00
00007431745e1cbf  jz 0x00007431745E1FE0
00007431745e1cc5  nop [rax+rax*1], ax
00007431745e1cce  nop [rax+rax*1], eax
00007431745e1cd6  mov eax, 0x410490
00007431745e1cdb  mov [r15+0x100], rax
00007431745e1ce2  jmp 0x00007431743FE110
00007431745e1ce7  cmp dword ptr [r15+0x318], 0x00
00007431745e1cef  jz 0x00007431745E1E20
00007431745e1cf5  nop [rax+rax*1], ax
00007431745e1cfe  nop [rax+rax*1], eax
00007431745e1d06  mov eax, 0x410474
00007431745e1d0b  mov [r15+0x100], rax
00007431745e1d12  jmp 0x00007431743FE110
00007431745e1d17  int3
00007431745e1d18  call 0x00007431744E27E0
00007431745e1d1d  jmp 0x00007431745E1AC3
00007431745e1d22  call 0x00007431744E27E0
00007431745e1d27  jmp 0x00007431745E1AD6
00007431745e1d2c  call 0x00007431744E1570
00007431745e1d31  jmp 0x00007431745E1AE2
00007431745e1d36  call 0x00007431744E27E0
00007431745e1d3b  jmp 0x00007431745E1B1A
00007431745e1d40  call 0x00007431744E1570
00007431745e1d45  jmp 0x00007431745E1B26
00007431745e1d4a  call 0x00007431744E27E0
00007431745e1d4f  jmp 0x00007431745E1B5E
00007431745e1d54  call 0x00007431744E1570
00007431745e1d59  jmp 0x00007431745E1B6A
00007431745e1d5e  call 0x00007431744E27E0
00007431745e1d63  jmp 0x00007431745E1BA2
00007431745e1d68  call 0x00007431744E1570
00007431745e1d6d  jmp 0x00007431745E1BAE
00007431745e1d72  call 0x00007431744E27E0
00007431745e1d77  jmp 0x00007431745E1BED
00007431745e1d7c  call 0x000074317440E760
00007431745e1d81  jmp 0x00007431745E1C0A
00007431745e1d86  ucomisd xmm1, xmm15
00007431745e1d8b  jp 0x00007431745E1D9A
00007431745e1d8d  movaps xmm13, [0x00007431741FE060]
00007431745e1d95  jmp 0x00007431745E1C73
00007431745e1d9a  vxorps xmm0, xmm1, xmm15
00007431745e1d9f  pextrw eax, xmm0, 0x03
00007431745e1da4  and eax, 0x7FF8
00007431745e1da9  cmp eax, 0x08
00007431745e1dac  jnz 0x00007431745E1C73
00007431745e1db2  movq rax, xmm15
00007431745e1db7  shl rax, 0x0D
00007431745e1dbb  jbe 0x00007431745E1C73
00007431745e1dc1  vorps xmm13, xmm15, [0x00007431741FE070]
00007431745e1dc9  jmp 0x00007431745E1C73
00007431745e1dce  ucomisd xmm1, xmm15
00007431745e1dd3  jp 0x00007431745E1DE2
00007431745e1dd5  movaps xmm14, [0x00007431741FE060]
00007431745e1ddd  jmp 0x00007431745E1CA0
00007431745e1de2  vxorps xmm0, xmm1, xmm15
00007431745e1de7  pextrw eax, xmm0, 0x03
00007431745e1dec  and eax, 0x7FF8
00007431745e1df1  cmp eax, 0x08
00007431745e1df4  jnz 0x00007431745E1CA0
00007431745e1dfa  movq rax, xmm15
00007431745e1dff  shl rax, 0x0D
00007431745e1e03  jbe 0x00007431745E1CA0
00007431745e1e09  vorps xmm14, xmm15, [0x00007431741FE070]
00007431745e1e11  jmp 0x00007431745E1CA0
00007431745e1e16  int3
00007431745e1e17  nop [rax+rax*1], ax
00007431745e1e20  mov rax, [r15+0x48]
00007431745e1e24  mov r14, [r15+0x50]
00007431745e1e28  lea r12, [r14+rax*1]
00007431745e1e2c  movups xmm1, [r13+r12*1]
00007431745e1e32  movaps [r15+0x120], xmm1
00007431745e1e3a  lea r14, [rax+0x10]
00007431745e1e3e  mov [r15+0x48], r14
00007431745e1e42  xor eax, eax
00007431745e1e44  mov r12d, 0x200
00007431745e1e4a  cmp r14, r12
00007431745e1e4d  cmc
00007431745e1e4e  lahf
00007431745e1e4f  seto al
00007431745e1e52  mov [r15+0x108], eax
00007431745e1e59  pextrq rax, xmm1, 0x01
00007431745e1e60  movq xmm15, rax
00007431745e1e65  movaps [r15+0x130], xmm15
00007431745e1e6d  movaps xmm14, [r15+0x110]
00007431745e1e75  movq rax, xmm14
00007431745e1e7a  movq r14, xmm1
00007431745e1e7f  vmovq xmm1, rax
00007431745e1e84  vmovq xmm14, r14
00007431745e1e89  movaps xmm13, xmm1
00007431745e1e8d  addsd xmm13, xmm14
00007431745e1e92  ucomisd xmm13, xmm13
00007431745e1e97  jp 0x00007431745E1F4C
00007431745e1e9d  movq xmm13, xmm13
00007431745e1ea2  movq rax, xmm13
00007431745e1ea7  movq r14, xmm15
00007431745e1eac  vmovq xmm1, rax
00007431745e1eb1  vmovq xmm15, r14
00007431745e1eb6  movaps xmm14, xmm1
00007431745e1eba  addsd xmm14, xmm15
00007431745e1ebf  ucomisd xmm14, xmm14
00007431745e1ec4  jp 0x00007431745E1F94
00007431745e1eca  movq xmm14, xmm14
00007431745e1ecf  movaps [r15+0x110], xmm14
00007431745e1ed7  mov eax, [r15+0x108]
00007431745e1ede  sahf
00007431745e1edf  jnz 0x00007431745E1F11
00007431745e1ee1  cmp dword ptr [r15+0x318], 0x00
00007431745e1ee9  jz 0x00007431745E1FE0
00007431745e1eef  nop [rax+rax*1], ax
00007431745e1ef8  nop [rax+rax*1], eax
00007431745e1f00  mov eax, 0x410490
00007431745e1f05  mov [r15+0x100], rax
00007431745e1f0c  jmp 0x00007431743FE110
00007431745e1f11  cmp dword ptr [r15+0x318], 0x00
00007431745e1f19  jz 0x00007431745E1E20
00007431745e1f1f  nop [rax+rax*1], ax
00007431745e1f28  nop [rax+rax*1], eax
00007431745e1f30  mov eax, 0x410474
00007431745e1f35  mov [r15+0x100], rax
00007431745e1f3c  jmp 0x00007431743FE110
00007431745e1f41  int3
00007431745e1f42  call 0x00007431744B52F0
00007431745e1f47  jmp 0x00007431745E1E32
00007431745e1f4c  ucomisd xmm1, xmm14
00007431745e1f51  jp 0x00007431745E1F60
00007431745e1f53  movaps xmm13, [0x00007431741FE060]
00007431745e1f5b  jmp 0x00007431745E1E9D
00007431745e1f60  vxorps xmm0, xmm1, xmm14
00007431745e1f65  pextrw eax, xmm0, 0x03
00007431745e1f6a  and eax, 0x7FF8
00007431745e1f6f  cmp eax, 0x08
00007431745e1f72  jnz 0x00007431745E1E9D
00007431745e1f78  movq rax, xmm14
00007431745e1f7d  shl rax, 0x0D
00007431745e1f81  jbe 0x00007431745E1E9D
00007431745e1f87  vorps xmm13, xmm14, [0x00007431741FE070]
00007431745e1f8f  jmp 0x00007431745E1E9D
00007431745e1f94  ucomisd xmm1, xmm15
00007431745e1f99  jp 0x00007431745E1FA8
00007431745e1f9b  movaps xmm14, [0x00007431741FE060]
00007431745e1fa3  jmp 0x00007431745E1ECA
00007431745e1fa8  vxorps xmm0, xmm1, xmm15
00007431745e1fad  pextrw eax, xmm0, 0x03
00007431745e1fb2  and eax, 0x7FF8
00007431745e1fb7  cmp eax, 0x08
00007431745e1fba  jnz 0x00007431745E1ECA
00007431745e1fc0  movq rax, xmm15
00007431745e1fc5  shl rax, 0x0D
00007431745e1fc9  jbe 0x00007431745E1ECA
00007431745e1fcf  vorps xmm14, xmm15, [0x00007431741FE070]
00007431745e1fd7  jmp 0x00007431745E1ECA
00007431745e1fdc  int3
00007431745e1fdd  nop [rax], eax
00007431745e1fe0  mov rax, [r15+0x40]
00007431745e1fe4  lea r14, [rax+0x510]
00007431745e1feb  movaps xmm1, [r15+0x110]
00007431745e1ff3  movq rax, xmm1
00007431745e1ff8  mov [r13+r14*1], rax
00007431745e1ffd  mov rax, [r15+0xF0]
00007431745e2004  mov [r15+0x100], rax
00007431745e200b  jmp 0x00007431745CE5C0
00007431745e2010  int3
00007431745e2011  call 0x00007431744D5EB0
00007431745e2016  jmp 0x00007431745E1FFD
00007431745e201b  int3
00007431745e201c  nop [rax], eax
00007431745e2020  mov qword ptr [r15+0x100], 0x04
00007431745e202b  mov esi, 0x00
00007431745e2030  mov edx, 0x09
00007431745e2035  mov rdi, 0x7FFE18E324E0
00007431745e203f  mov rax, 0x56C409431970
00007431745e2049  call rax
00007431745e204b  cmp dword ptr [r15+0x318], 0x00
00007431745e2053  jnz 0x00007431743FE110
00007431745e2059  jmp 0x00007431743FE0A0
00007431745e205e  int3
00007431745e205f  int3
