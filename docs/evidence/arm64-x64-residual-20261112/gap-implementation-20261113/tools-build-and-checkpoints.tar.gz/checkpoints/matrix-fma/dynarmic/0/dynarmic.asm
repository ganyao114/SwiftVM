000070d6f3dce69b  nop [rax+rax*1], eax
000070d6f3dce6a0  vmovaps xmm1, [0x000070D6F39FE010]
000070d6f3dce6a8  movq xmm1, xmm1
000070d6f3dce6ac  movaps [r15+0x110], xmm1
000070d6f3dce6b4  vmovaps xmm1, [0x000070D6F39FE020]
000070d6f3dce6bc  movq xmm1, xmm1
000070d6f3dce6c0  movaps [r15+0x120], xmm1
000070d6f3dce6c8  mov eax, 0x420470
000070d6f3dce6cd  mov r14, [r13+rax*1]
000070d6f3dce6d2  movq xmm1, r14
000070d6f3dce6d7  movaps [r15+0x130], xmm1
000070d6f3dce6df  vmovaps xmm1, [0x000070D6F39FE030]
000070d6f3dce6e7  vpbroadcastq xmm1, xmm1
000070d6f3dce6ec  movaps [r15+0x140], xmm1
000070d6f3dce6f4  mov qword ptr [r15+0x40], 0x02
000070d6f3dce6fc  vmovaps xmm15, [0x000070D6F39FE040]
000070d6f3dce704  movq xmm15, xmm15
000070d6f3dce709  movaps [r15+0x150], xmm15
000070d6f3dce711  mov qword ptr [r15+0x58], 0x420000
000070d6f3dce719  vmovaps xmm15, [0x000070D6F39FE050]
000070d6f3dce721  vpbroadcastq xmm15, xmm15
000070d6f3dce726  movaps [r15+0x160], xmm15
000070d6f3dce72e  mov rax, [r15+0x40]
000070d6f3dce732  vmovq xmm14, rax
000070d6f3dce737  vpbroadcastq xmm14, xmm14
000070d6f3dce73c  movaps [r15+0x170], xmm14
000070d6f3dce744  mov eax, 0x420480
000070d6f3dce749  movups xmm13, [r13+rax*1]
000070d6f3dce74f  mov qword ptr [r15+0x40], 0x4304C8
000070d6f3dce757  mov qword ptr [r15+0x50], 0x4306D0
000070d6f3dce75f  vpmovqd xmm12, xmm13
000070d6f3dce765  pxor xmm11, xmm11
000070d6f3dce76a  punpcklqdq xmm12, xmm11
000070d6f3dce76f  movaps [r15+0x210], xmm12
000070d6f3dce777  movq xmm12, qword ptr [r15+0x120]
000070d6f3dce780  movq xmm11, qword ptr [r15+0x130]
000070d6f3dce789  psubd xmm12, xmm11
000070d6f3dce78e  movq xmm12, xmm12
000070d6f3dce793  paddq xmm13, xmm14
000070d6f3dce798  movaps [r15+0x180], xmm13
000070d6f3dce7a0  movq xmm14, qword ptr [r15+0x150]
000070d6f3dce7a9  paddd xmm11, xmm14
000070d6f3dce7ae  movq xmm11, xmm11
000070d6f3dce7b3  movq xmm11, xmm11
000070d6f3dce7b8  movaps [r15+0x130], xmm11
000070d6f3dce7c0  pmovzxdq xmm12, xmm12
000070d6f3dce7c6  psllq xmm12, 0x00
000070d6f3dce7cc  movq xmm14, qword ptr [r15+0x210]
000070d6f3dce7d5  movq xmm13, qword ptr [r15+0x110]
000070d6f3dce7de  paddd xmm14, xmm13
000070d6f3dce7e3  movq xmm14, xmm14
000070d6f3dce7e8  vcvtuqq2pd xmm12, xmm12
000070d6f3dce7ee  pmovzxdq xmm14, xmm14
000070d6f3dce7f4  psllq xmm14, 0x00
000070d6f3dce7fa  vcvtuqq2pd xmm14, xmm14
000070d6f3dce800  movaps xmm13, xmm12
000070d6f3dce804  mulpd xmm13, xmm1
000070d6f3dce809  vcmppd xmm11, xmm13, xmm13, 0x03
000070d6f3dce80f  ptest xmm11, xmm11
000070d6f3dce815  jnz 0x000070D6F3DCE8FF
000070d6f3dce81b  movaps [r15+0x220], xmm13
000070d6f3dce823  mov eax, 0x4306D0
000070d6f3dce828  movups [r13+rax*1], xmm13
000070d6f3dce82e  movaps xmm1, xmm14
000070d6f3dce832  mulpd xmm1, xmm15
000070d6f3dce837  vcmppd xmm13, xmm1, xmm1, 0x03
000070d6f3dce83c  ptest xmm13, xmm13
000070d6f3dce842  jnz 0x000070D6F3DCEA4C
000070d6f3dce848  movaps [r15+0x210], xmm1
000070d6f3dce850  mov eax, 0x4304C8
000070d6f3dce855  movups [r13+rax*1], xmm1
000070d6f3dce85b  mov qword ptr [r15+0x48], 0x10
000070d6f3dce863  xor eax, eax
000070d6f3dce865  mov r14d, 0x10
000070d6f3dce86b  mov r12d, 0x200
000070d6f3dce871  cmp r14, r12
000070d6f3dce874  cmc
000070d6f3dce875  lahf
000070d6f3dce876  seto al
000070d6f3dce879  mov [r15+0x108], eax
000070d6f3dce880  mov eax, [r15+0x108]
000070d6f3dce887  sahf
000070d6f3dce888  jnz 0x000070D6F3DCE8BA
000070d6f3dce88a  cmp dword ptr [r15+0x318], 0x00
000070d6f3dce892  jz 0x000070D6F3DCEFF0
000070d6f3dce898  nop [rax+rax*1], ax
000070d6f3dce8a1  nop [rax+rax*1], eax
000070d6f3dce8a9  mov eax, 0x4101EC
000070d6f3dce8ae  mov [r15+0x100], rax
000070d6f3dce8b5  jmp 0x000070D6F3BFE110
000070d6f3dce8ba  cmp dword ptr [r15+0x318], 0x00
000070d6f3dce8c2  jz 0x000070D6F3DCEBA0
000070d6f3dce8c8  nop [rax+rax*1], ax
000070d6f3dce8d1  nop [rax+rax*1], eax
000070d6f3dce8d9  mov eax, 0x4101AC
000070d6f3dce8de  mov [r15+0x100], rax
000070d6f3dce8e5  jmp 0x000070D6F3BFE110
000070d6f3dce8ea  int3
000070d6f3dce8eb  call 0x000070D6F3C0DC20
000070d6f3dce8f0  jmp 0x000070D6F3DCE6D2
000070d6f3dce8f5  call 0x000070D6F3C0C260
000070d6f3dce8fa  jmp 0x000070D6F3DCE74F
000070d6f3dce8ff  sub rsp, 0x08
000070d6f3dce903  push rax
000070d6f3dce904  push rcx
000070d6f3dce905  push rdx
000070d6f3dce906  push rdi
000070d6f3dce907  push rsi
000070d6f3dce908  push r8
000070d6f3dce90a  push r9
000070d6f3dce90c  push r10
000070d6f3dce90e  push r11
000070d6f3dce910  sub rsp, 0xF0
000070d6f3dce917  vmovaps [rsp], xmm0
000070d6f3dce91c  vmovaps [rsp+0x10], xmm1
000070d6f3dce922  vmovaps [rsp+0x20], xmm2
000070d6f3dce928  vmovaps [rsp+0x30], xmm3
000070d6f3dce92e  vmovaps [rsp+0x40], xmm4
000070d6f3dce934  vmovaps [rsp+0x50], xmm5
000070d6f3dce93a  vmovaps [rsp+0x60], xmm6
000070d6f3dce940  vmovaps [rsp+0x70], xmm7
000070d6f3dce946  vmovaps [rsp+0x80], xmm8
000070d6f3dce94f  vmovaps [rsp+0x90], xmm9
000070d6f3dce958  vmovaps [rsp+0xA0], xmm10
000070d6f3dce961  vmovaps [rsp+0xB0], xmm11
000070d6f3dce96a  vmovaps [rsp+0xC0], xmm12
000070d6f3dce973  vmovaps [rsp+0xD0], xmm14
000070d6f3dce97c  vmovaps [rsp+0xE0], xmm15
000070d6f3dce985  sub rsp, 0x30
000070d6f3dce989  movaps [rsp], xmm13
000070d6f3dce98e  movaps [rsp+0x10], xmm12
000070d6f3dce994  movaps [rsp+0x20], xmm1
000070d6f3dce999  lea rdi, [rsp]
000070d6f3dce99d  mov esi, 0x00
000070d6f3dce9a2  mov rax, 0x61D08D40E530
000070d6f3dce9ac  call rax
000070d6f3dce9ae  movaps xmm13, [rsp]
000070d6f3dce9b3  add rsp, 0x30
000070d6f3dce9b7  vmovaps xmm0, [rsp]
000070d6f3dce9bc  vmovaps xmm1, [rsp+0x10]
000070d6f3dce9c2  vmovaps xmm2, [rsp+0x20]
000070d6f3dce9c8  vmovaps xmm3, [rsp+0x30]
000070d6f3dce9ce  vmovaps xmm4, [rsp+0x40]
000070d6f3dce9d4  vmovaps xmm5, [rsp+0x50]
000070d6f3dce9da  vmovaps xmm6, [rsp+0x60]
000070d6f3dce9e0  vmovaps xmm7, [rsp+0x70]
000070d6f3dce9e6  vmovaps xmm8, [rsp+0x80]
000070d6f3dce9ef  vmovaps xmm9, [rsp+0x90]
000070d6f3dce9f8  vmovaps xmm10, [rsp+0xA0]
000070d6f3dcea01  vmovaps xmm11, [rsp+0xB0]
000070d6f3dcea0a  vmovaps xmm12, [rsp+0xC0]
000070d6f3dcea13  vmovaps xmm14, [rsp+0xD0]
000070d6f3dcea1c  vmovaps xmm15, [rsp+0xE0]
000070d6f3dcea25  add rsp, 0xF0
000070d6f3dcea2c  pop r11
000070d6f3dcea2e  pop r10
000070d6f3dcea30  pop r9
000070d6f3dcea32  pop r8
000070d6f3dcea34  pop rsi
000070d6f3dcea35  pop rdi
000070d6f3dcea36  pop rdx
000070d6f3dcea37  pop rcx
000070d6f3dcea38  pop rax
000070d6f3dcea39  add rsp, 0x08
000070d6f3dcea3d  jmp 0x000070D6F3DCE81B
000070d6f3dcea42  call 0x000070D6F3C0C380
000070d6f3dcea47  jmp 0x000070D6F3DCE82E
000070d6f3dcea4c  sub rsp, 0x08
000070d6f3dcea50  push rax
000070d6f3dcea51  push rcx
000070d6f3dcea52  push rdx
000070d6f3dcea53  push rdi
000070d6f3dcea54  push rsi
000070d6f3dcea55  push r8
000070d6f3dcea57  push r9
000070d6f3dcea59  push r10
000070d6f3dcea5b  push r11
000070d6f3dcea5d  sub rsp, 0xF0
000070d6f3dcea64  vmovaps [rsp], xmm0
000070d6f3dcea69  vmovaps [rsp+0x10], xmm2
000070d6f3dcea6f  vmovaps [rsp+0x20], xmm3
000070d6f3dcea75  vmovaps [rsp+0x30], xmm4
000070d6f3dcea7b  vmovaps [rsp+0x40], xmm5
000070d6f3dcea81  vmovaps [rsp+0x50], xmm6
000070d6f3dcea87  vmovaps [rsp+0x60], xmm7
000070d6f3dcea8d  vmovaps [rsp+0x70], xmm8
000070d6f3dcea93  vmovaps [rsp+0x80], xmm9
000070d6f3dcea9c  vmovaps [rsp+0x90], xmm10
000070d6f3dceaa5  vmovaps [rsp+0xA0], xmm11
000070d6f3dceaae  vmovaps [rsp+0xB0], xmm12
000070d6f3dceab7  vmovaps [rsp+0xC0], xmm13
000070d6f3dceac0  vmovaps [rsp+0xD0], xmm14
000070d6f3dceac9  vmovaps [rsp+0xE0], xmm15
000070d6f3dcead2  sub rsp, 0x30
000070d6f3dcead6  movaps [rsp], xmm1
000070d6f3dceada  movaps [rsp+0x10], xmm14
000070d6f3dceae0  movaps [rsp+0x20], xmm15
000070d6f3dceae6  lea rdi, [rsp]
000070d6f3dceaea  mov esi, 0x00
000070d6f3dceaef  mov rax, 0x61D08D40E530
000070d6f3dceaf9  call rax
000070d6f3dceafb  movaps xmm1, [rsp]
000070d6f3dceaff  add rsp, 0x30
000070d6f3dceb03  vmovaps xmm0, [rsp]
000070d6f3dceb08  vmovaps xmm2, [rsp+0x10]
000070d6f3dceb0e  vmovaps xmm3, [rsp+0x20]
000070d6f3dceb14  vmovaps xmm4, [rsp+0x30]
000070d6f3dceb1a  vmovaps xmm5, [rsp+0x40]
000070d6f3dceb20  vmovaps xmm6, [rsp+0x50]
000070d6f3dceb26  vmovaps xmm7, [rsp+0x60]
000070d6f3dceb2c  vmovaps xmm8, [rsp+0x70]
000070d6f3dceb32  vmovaps xmm9, [rsp+0x80]
000070d6f3dceb3b  vmovaps xmm10, [rsp+0x90]
000070d6f3dceb44  vmovaps xmm11, [rsp+0xA0]
000070d6f3dceb4d  vmovaps xmm12, [rsp+0xB0]
000070d6f3dceb56  vmovaps xmm13, [rsp+0xC0]
000070d6f3dceb5f  vmovaps xmm14, [rsp+0xD0]
000070d6f3dceb68  vmovaps xmm15, [rsp+0xE0]
000070d6f3dceb71  add rsp, 0xF0
000070d6f3dceb78  pop r11
000070d6f3dceb7a  pop r10
000070d6f3dceb7c  pop r9
000070d6f3dceb7e  pop r8
000070d6f3dceb80  pop rsi
000070d6f3dceb81  pop rdi
000070d6f3dceb82  pop rdx
000070d6f3dceb83  pop rcx
000070d6f3dceb84  pop rax
000070d6f3dceb85  add rsp, 0x08
000070d6f3dceb89  jmp 0x000070D6F3DCE848
000070d6f3dceb8e  call 0x000070D6F3BFF540
000070d6f3dceb93  jmp 0x000070D6F3DCE85B
000070d6f3dceb98  int3
000070d6f3dceb99  nop [rax], eax
000070d6f3dceba0  movaps xmm1, [r15+0x180]
000070d6f3dceba8  vpmovqd xmm15, xmm1
000070d6f3dcebae  pxor xmm14, xmm14
000070d6f3dcebb3  punpcklqdq xmm15, xmm14
000070d6f3dcebb8  movaps [r15+0x210], xmm15
000070d6f3dcebc0  movq xmm15, qword ptr [r15+0x120]
000070d6f3dcebc9  movq xmm14, qword ptr [r15+0x130]
000070d6f3dcebd2  psubd xmm15, xmm14
000070d6f3dcebd7  movq xmm15, xmm15
000070d6f3dcebdc  movaps xmm13, [r15+0x170]
000070d6f3dcebe4  paddq xmm1, xmm13
000070d6f3dcebe9  movaps [r15+0x180], xmm1
000070d6f3dcebf1  movq xmm1, qword ptr [r15+0x150]
000070d6f3dcebfa  paddd xmm14, xmm1
000070d6f3dcebff  movq xmm14, xmm14
000070d6f3dcec04  movq xmm14, xmm14
000070d6f3dcec09  movaps [r15+0x130], xmm14
000070d6f3dcec11  pmovzxdq xmm15, xmm15
000070d6f3dcec17  psllq xmm15, 0x00
000070d6f3dcec1d  movq xmm1, qword ptr [r15+0x210]
000070d6f3dcec26  movq xmm14, qword ptr [r15+0x110]
000070d6f3dcec2f  paddd xmm1, xmm14
000070d6f3dcec34  movq xmm1, xmm1
000070d6f3dcec38  vcvtuqq2pd xmm15, xmm15
000070d6f3dcec3e  pmovzxdq xmm1, xmm1
000070d6f3dcec43  psllq xmm1, 0x00
000070d6f3dcec48  vcvtuqq2pd xmm1, xmm1
000070d6f3dcec4e  movaps xmm14, [r15+0x140]
000070d6f3dcec56  movaps xmm13, xmm15
000070d6f3dcec5a  mulpd xmm13, xmm14
000070d6f3dcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000070d6f3dcec65  ptest xmm12, xmm12
000070d6f3dcec6b  jnz 0x000070D6F3DCED4E
000070d6f3dcec71  movaps [r15+0x220], xmm13
000070d6f3dcec79  mov rax, [r15+0x48]
000070d6f3dcec7d  mov r14, [r15+0x50]
000070d6f3dcec81  lea r12, [r14+rax*1]
000070d6f3dcec85  movups [r13+r12*1], xmm13
000070d6f3dcec8b  movaps xmm15, [r15+0x160]
000070d6f3dcec93  movaps xmm14, xmm1
000070d6f3dcec97  mulpd xmm14, xmm15
000070d6f3dcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000070d6f3dceca2  ptest xmm13, xmm13
000070d6f3dceca8  jnz 0x000070D6F3DCEE9C
000070d6f3dcecae  movaps [r15+0x210], xmm14
000070d6f3dcecb6  mov r14, [r15+0x40]
000070d6f3dcecba  lea r12, [r14+rax*1]
000070d6f3dcecbe  movups [r13+r12*1], xmm14
000070d6f3dcecc4  lea r14, [rax+0x10]
000070d6f3dcecc8  mov [r15+0x48], r14
000070d6f3dceccc  xor eax, eax
000070d6f3dcecce  mov r12d, 0x200
000070d6f3dcecd4  cmp r14, r12
000070d6f3dcecd7  cmc
000070d6f3dcecd8  lahf
000070d6f3dcecd9  seto al
000070d6f3dcecdc  mov [r15+0x108], eax
000070d6f3dcece3  mov eax, [r15+0x108]
000070d6f3dcecea  sahf
000070d6f3dceceb  jnz 0x000070D6F3DCED1D
000070d6f3dceced  cmp dword ptr [r15+0x318], 0x00
000070d6f3dcecf5  jz 0x000070D6F3DCEFF0
000070d6f3dcecfb  nop [rax+rax*1], ax
000070d6f3dced04  nop [rax+rax*1], eax
000070d6f3dced0c  mov eax, 0x4101EC
000070d6f3dced11  mov [r15+0x100], rax
000070d6f3dced18  jmp 0x000070D6F3BFE110
000070d6f3dced1d  cmp dword ptr [r15+0x318], 0x00
000070d6f3dced25  jz 0x000070D6F3DCEBA0
000070d6f3dced2b  nop [rax+rax*1], ax
000070d6f3dced34  nop [rax+rax*1], eax
000070d6f3dced3c  mov eax, 0x4101AC
000070d6f3dced41  mov [r15+0x100], rax
000070d6f3dced48  jmp 0x000070D6F3BFE110
000070d6f3dced4d  int3
000070d6f3dced4e  sub rsp, 0x08
000070d6f3dced52  push rax
000070d6f3dced53  push rcx
000070d6f3dced54  push rdx
000070d6f3dced55  push rdi
000070d6f3dced56  push rsi
000070d6f3dced57  push r8
000070d6f3dced59  push r9
000070d6f3dced5b  push r10
000070d6f3dced5d  push r11
000070d6f3dced5f  sub rsp, 0xF0
000070d6f3dced66  vmovaps [rsp], xmm0
000070d6f3dced6b  vmovaps [rsp+0x10], xmm1
000070d6f3dced71  vmovaps [rsp+0x20], xmm2
000070d6f3dced77  vmovaps [rsp+0x30], xmm3
000070d6f3dced7d  vmovaps [rsp+0x40], xmm4
000070d6f3dced83  vmovaps [rsp+0x50], xmm5
000070d6f3dced89  vmovaps [rsp+0x60], xmm6
000070d6f3dced8f  vmovaps [rsp+0x70], xmm7
000070d6f3dced95  vmovaps [rsp+0x80], xmm8
000070d6f3dced9e  vmovaps [rsp+0x90], xmm9
000070d6f3dceda7  vmovaps [rsp+0xA0], xmm10
000070d6f3dcedb0  vmovaps [rsp+0xB0], xmm11
000070d6f3dcedb9  vmovaps [rsp+0xC0], xmm12
000070d6f3dcedc2  vmovaps [rsp+0xD0], xmm14
000070d6f3dcedcb  vmovaps [rsp+0xE0], xmm15
000070d6f3dcedd4  sub rsp, 0x30
000070d6f3dcedd8  movaps [rsp], xmm13
000070d6f3dceddd  movaps [rsp+0x10], xmm15
000070d6f3dcede3  movaps [rsp+0x20], xmm14
000070d6f3dcede9  lea rdi, [rsp]
000070d6f3dceded  mov esi, 0x00
000070d6f3dcedf2  mov rax, 0x61D08D40E530
000070d6f3dcedfc  call rax
000070d6f3dcedfe  movaps xmm13, [rsp]
000070d6f3dcee03  add rsp, 0x30
000070d6f3dcee07  vmovaps xmm0, [rsp]
000070d6f3dcee0c  vmovaps xmm1, [rsp+0x10]
000070d6f3dcee12  vmovaps xmm2, [rsp+0x20]
000070d6f3dcee18  vmovaps xmm3, [rsp+0x30]
000070d6f3dcee1e  vmovaps xmm4, [rsp+0x40]
000070d6f3dcee24  vmovaps xmm5, [rsp+0x50]
000070d6f3dcee2a  vmovaps xmm6, [rsp+0x60]
000070d6f3dcee30  vmovaps xmm7, [rsp+0x70]
000070d6f3dcee36  vmovaps xmm8, [rsp+0x80]
000070d6f3dcee3f  vmovaps xmm9, [rsp+0x90]
000070d6f3dcee48  vmovaps xmm10, [rsp+0xA0]
000070d6f3dcee51  vmovaps xmm11, [rsp+0xB0]
000070d6f3dcee5a  vmovaps xmm12, [rsp+0xC0]
000070d6f3dcee63  vmovaps xmm14, [rsp+0xD0]
000070d6f3dcee6c  vmovaps xmm15, [rsp+0xE0]
000070d6f3dcee75  add rsp, 0xF0
000070d6f3dcee7c  pop r11
000070d6f3dcee7e  pop r10
000070d6f3dcee80  pop r9
000070d6f3dcee82  pop r8
000070d6f3dcee84  pop rsi
000070d6f3dcee85  pop rdi
000070d6f3dcee86  pop rdx
000070d6f3dcee87  pop rcx
000070d6f3dcee88  pop rax
000070d6f3dcee89  add rsp, 0x08
000070d6f3dcee8d  jmp 0x000070D6F3DCEC71
000070d6f3dcee92  call 0x000070D6F3CC2240
000070d6f3dcee97  jmp 0x000070D6F3DCEC8B
000070d6f3dcee9c  sub rsp, 0x08
000070d6f3dceea0  push rax
000070d6f3dceea1  push rcx
000070d6f3dceea2  push rdx
000070d6f3dceea3  push rdi
000070d6f3dceea4  push rsi
000070d6f3dceea5  push r8
000070d6f3dceea7  push r9
000070d6f3dceea9  push r10
000070d6f3dceeab  push r11
000070d6f3dceead  sub rsp, 0xF0
000070d6f3dceeb4  vmovaps [rsp], xmm0
000070d6f3dceeb9  vmovaps [rsp+0x10], xmm1
000070d6f3dceebf  vmovaps [rsp+0x20], xmm2
000070d6f3dceec5  vmovaps [rsp+0x30], xmm3
000070d6f3dceecb  vmovaps [rsp+0x40], xmm4
000070d6f3dceed1  vmovaps [rsp+0x50], xmm5
000070d6f3dceed7  vmovaps [rsp+0x60], xmm6
000070d6f3dceedd  vmovaps [rsp+0x70], xmm7
000070d6f3dceee3  vmovaps [rsp+0x80], xmm8
000070d6f3dceeec  vmovaps [rsp+0x90], xmm9
000070d6f3dceef5  vmovaps [rsp+0xA0], xmm10
000070d6f3dceefe  vmovaps [rsp+0xB0], xmm11
000070d6f3dcef07  vmovaps [rsp+0xC0], xmm12
000070d6f3dcef10  vmovaps [rsp+0xD0], xmm13
000070d6f3dcef19  vmovaps [rsp+0xE0], xmm15
000070d6f3dcef22  sub rsp, 0x30
000070d6f3dcef26  movaps [rsp], xmm14
000070d6f3dcef2b  movaps [rsp+0x10], xmm1
000070d6f3dcef30  movaps [rsp+0x20], xmm15
000070d6f3dcef36  lea rdi, [rsp]
000070d6f3dcef3a  mov esi, 0x00
000070d6f3dcef3f  mov rax, 0x61D08D40E530
000070d6f3dcef49  call rax
000070d6f3dcef4b  movaps xmm14, [rsp]
000070d6f3dcef50  add rsp, 0x30
000070d6f3dcef54  vmovaps xmm0, [rsp]
000070d6f3dcef59  vmovaps xmm1, [rsp+0x10]
000070d6f3dcef5f  vmovaps xmm2, [rsp+0x20]
000070d6f3dcef65  vmovaps xmm3, [rsp+0x30]
000070d6f3dcef6b  vmovaps xmm4, [rsp+0x40]
000070d6f3dcef71  vmovaps xmm5, [rsp+0x50]
000070d6f3dcef77  vmovaps xmm6, [rsp+0x60]
000070d6f3dcef7d  vmovaps xmm7, [rsp+0x70]
000070d6f3dcef83  vmovaps xmm8, [rsp+0x80]
000070d6f3dcef8c  vmovaps xmm9, [rsp+0x90]
000070d6f3dcef95  vmovaps xmm10, [rsp+0xA0]
000070d6f3dcef9e  vmovaps xmm11, [rsp+0xB0]
000070d6f3dcefa7  vmovaps xmm12, [rsp+0xC0]
000070d6f3dcefb0  vmovaps xmm13, [rsp+0xD0]
000070d6f3dcefb9  vmovaps xmm15, [rsp+0xE0]
000070d6f3dcefc2  add rsp, 0xF0
000070d6f3dcefc9  pop r11
000070d6f3dcefcb  pop r10
000070d6f3dcefcd  pop r9
000070d6f3dcefcf  pop r8
000070d6f3dcefd1  pop rsi
000070d6f3dcefd2  pop rdi
000070d6f3dcefd3  pop rdx
000070d6f3dcefd4  pop rcx
000070d6f3dcefd5  pop rax
000070d6f3dcefd6  add rsp, 0x08
000070d6f3dcefda  jmp 0x000070D6F3DCECAE
000070d6f3dcefdf  call 0x000070D6F3CC34C0
000070d6f3dcefe4  jmp 0x000070D6F3DCECC4
000070d6f3dcefe9  int3
000070d6f3dcefea  nop [rax+rax*1], ax
000070d6f3dceff0  mov rax, [r15+0xF8]
000070d6f3dceff7  lea r14, [rax-0x120]
000070d6f3dceffe  mov [r15+0xF8], r14
000070d6f3dcf005  mov rax, [r15+0x50]
000070d6f3dcf009  movups xmm1, [r13+rax*1]
000070d6f3dcf00f  lea r12, [rax+0x10]
000070d6f3dcf013  movups xmm15, [r13+r12*1]
000070d6f3dcf019  mov qword ptr [r15+0x48], 0x00
000070d6f3dcf021  lea r12, [r14+0xD0]
000070d6f3dcf028  movq xmm14, qword ptr [r15+0x200]
000070d6f3dcf031  movq xmm13, qword ptr [r15+0x1F0]
000070d6f3dcf03a  movq r11, xmm14
000070d6f3dcf03f  movq r10, xmm13
000070d6f3dcf044  mov [r13+r12*1], r11
000070d6f3dcf049  lea r12, [r14+0xD8]
000070d6f3dcf050  mov [r13+r12*1], r10
000070d6f3dcf055  lea r12, [rax+0x80]
000070d6f3dcf05c  movups xmm14, [r13+r12*1]
000070d6f3dcf062  lea r12, [rax+0x90]
000070d6f3dcf069  movups xmm13, [r13+r12*1]
000070d6f3dcf06f  lea r12, [r14+0xE0]
000070d6f3dcf076  movq xmm12, qword ptr [r15+0x1E0]
000070d6f3dcf07f  movq xmm11, qword ptr [r15+0x1D0]
000070d6f3dcf088  movq r11, xmm12
000070d6f3dcf08d  movq r10, xmm11
000070d6f3dcf092  mov [r13+r12*1], r11
000070d6f3dcf097  lea r12, [r14+0xE8]
000070d6f3dcf09e  mov [r13+r12*1], r10
000070d6f3dcf0a3  lea r12, [rax+0xC0]
000070d6f3dcf0aa  movups xmm12, [r13+r12*1]
000070d6f3dcf0b0  lea r12, [rax+0xD0]
000070d6f3dcf0b7  movups xmm11, [r13+r12*1]
000070d6f3dcf0bd  movups [r13+r14*1], xmm1
000070d6f3dcf0c3  lea r12, [rax+0x20]
000070d6f3dcf0c7  movups xmm1, [r13+r12*1]
000070d6f3dcf0cd  lea r12, [rax+0x30]
000070d6f3dcf0d1  movups xmm10, [r13+r12*1]
000070d6f3dcf0d7  lea r12, [r14+0xF0]
000070d6f3dcf0de  movq xmm9, qword ptr [r15+0x1C0]
000070d6f3dcf0e7  movq xmm8, qword ptr [r15+0x1B0]
000070d6f3dcf0f0  movq r11, xmm9
000070d6f3dcf0f5  movq r10, xmm8
000070d6f3dcf0fa  mov [r13+r12*1], r11
000070d6f3dcf0ff  lea r12, [r14+0xF8]
000070d6f3dcf106  mov [r13+r12*1], r10
000070d6f3dcf10b  lea r12, [rax+0x40]
000070d6f3dcf10f  movups xmm9, [r13+r12*1]
000070d6f3dcf115  lea r12, [rax+0x50]
000070d6f3dcf119  movups xmm8, [r13+r12*1]
000070d6f3dcf11f  lea r12, [r14+0x100]
000070d6f3dcf126  movq xmm7, qword ptr [r15+0x1A0]
000070d6f3dcf12f  movq xmm6, qword ptr [r15+0x190]
000070d6f3dcf138  movq r11, xmm7
000070d6f3dcf13d  movq r10, xmm6
000070d6f3dcf142  mov [r13+r12*1], r11
000070d6f3dcf147  lea r12, [r14+0x108]
000070d6f3dcf14e  mov [r13+r12*1], r10
000070d6f3dcf153  lea r12, [rax+0x100]
000070d6f3dcf15a  movups xmm7, [r13+r12*1]
000070d6f3dcf160  lea r12, [rax+0x110]
000070d6f3dcf167  movups xmm6, [r13+r12*1]
000070d6f3dcf16d  lea r12, [r14+0xB0]
000070d6f3dcf174  movups [r13+r12*1], xmm10
000070d6f3dcf17a  lea r12, [r14+0xC0]
000070d6f3dcf181  movups [r13+r12*1], xmm1
000070d6f3dcf187  lea r12, [rax+0x140]
000070d6f3dcf18e  movups xmm1, [r13+r12*1]
000070d6f3dcf194  lea r12, [rax+0x150]
000070d6f3dcf19b  movups xmm10, [r13+r12*1]
000070d6f3dcf1a1  lea r12, [r14+0x110]
000070d6f3dcf1a8  mov r11, [r15+0xE8]
000070d6f3dcf1af  mov [r13+r12*1], r11
000070d6f3dcf1b4  lea r12, [rax+0x180]
000070d6f3dcf1bb  movups xmm5, [r13+r12*1]
000070d6f3dcf1c1  lea r12, [rax+0x190]
000070d6f3dcf1c8  movups xmm4, [r13+r12*1]
000070d6f3dcf1ce  lea r12, [rax+0x1C0]
000070d6f3dcf1d5  movups xmm3, [r13+r12*1]
000070d6f3dcf1db  lea r12, [rax+0x1D0]
000070d6f3dcf1e2  movups xmm2, [r13+r12*1]
000070d6f3dcf1e8  lea r12, [rax+0x60]
000070d6f3dcf1ec  vmovaps [rsp+0x10], xmm1
000070d6f3dcf1f2  movups xmm1, [r13+r12*1]
000070d6f3dcf1f8  lea r12, [rax+0x70]
000070d6f3dcf1fc  vmovaps [rsp+0x20], xmm1
000070d6f3dcf202  movups xmm1, [r13+r12*1]
000070d6f3dcf208  lea r12, [r14+0x70]
000070d6f3dcf20c  movups [r13+r12*1], xmm4
000070d6f3dcf212  lea r12, [r14+0x80]
000070d6f3dcf219  movups [r13+r12*1], xmm5
000070d6f3dcf21f  lea r12, [rax+0xA0]
000070d6f3dcf226  movups xmm5, [r13+r12*1]
000070d6f3dcf22c  lea r12, [rax+0xB0]
000070d6f3dcf233  movups xmm4, [r13+r12*1]
000070d6f3dcf239  lea r12, [r14+0x90]
000070d6f3dcf240  movups [r13+r12*1], xmm2
000070d6f3dcf246  lea r12, [r14+0xA0]
000070d6f3dcf24d  movups [r13+r12*1], xmm3
000070d6f3dcf253  lea r12, [rax+0xE0]
000070d6f3dcf25a  movups xmm3, [r13+r12*1]
000070d6f3dcf260  lea r12, [rax+0xF0]
000070d6f3dcf267  movups xmm2, [r13+r12*1]
000070d6f3dcf26d  lea r12, [rax+0x120]
000070d6f3dcf274  vmovaps [rsp+0x30], xmm1
000070d6f3dcf27a  movups xmm1, [r13+r12*1]
000070d6f3dcf280  lea r12, [rax+0x130]
000070d6f3dcf287  vmovaps [rsp+0x40], xmm1
000070d6f3dcf28d  movups xmm1, [r13+r12*1]
000070d6f3dcf293  lea r12, [rax+0x160]
000070d6f3dcf29a  vmovaps [rsp+0x50], xmm1
000070d6f3dcf2a0  movups xmm1, [r13+r12*1]
000070d6f3dcf2a6  lea r12, [rax+0x170]
000070d6f3dcf2ad  vmovaps [rsp+0x60], xmm1
000070d6f3dcf2b3  movups xmm1, [r13+r12*1]
000070d6f3dcf2b9  lea r12, [rax+0x1A0]
000070d6f3dcf2c0  vmovaps [rsp+0x70], xmm1
000070d6f3dcf2c6  movups xmm1, [r13+r12*1]
000070d6f3dcf2cc  lea r12, [rax+0x1B0]
000070d6f3dcf2d3  vmovaps [rsp+0x80], xmm1
000070d6f3dcf2dc  movups xmm1, [r13+r12*1]
000070d6f3dcf2e2  lea r12, [rax+0x1E0]
000070d6f3dcf2e9  vmovaps [rsp+0x90], xmm1
000070d6f3dcf2f2  movups xmm1, [r13+r12*1]
000070d6f3dcf2f8  lea r12, [rax+0x1F0]
000070d6f3dcf2ff  vmovaps [rsp+0xA0], xmm1
000070d6f3dcf308  movups xmm1, [r13+r12*1]
000070d6f3dcf30e  mov qword ptr [r15+0x50], 0x4308D0
000070d6f3dcf316  lea rax, [r14+0x50]
000070d6f3dcf31a  vmovaps [rsp+0xB0], xmm1
000070d6f3dcf323  vmovaps xmm1, [rsp+0x60]
000070d6f3dcf329  movups [r13+rax*1], xmm1
000070d6f3dcf32f  lea rax, [r14+0x60]
000070d6f3dcf333  vmovaps xmm1, [rsp+0x10]
000070d6f3dcf339  movups [r13+rax*1], xmm1
000070d6f3dcf33f  lea rax, [r14+0x40]
000070d6f3dcf343  vmovaps xmm1, [rsp+0x70]
000070d6f3dcf349  movups [r13+rax*1], xmm1
000070d6f3dcf34f  lea rax, [r14+0x20]
000070d6f3dcf353  vmovaps xmm1, [rsp+0xA0]
000070d6f3dcf35c  movups [r13+rax*1], xmm1
000070d6f3dcf362  lea rax, [r14+0x30]
000070d6f3dcf366  vmovaps xmm1, [rsp+0x90]
000070d6f3dcf36f  movups [r13+rax*1], xmm1
000070d6f3dcf375  lea rax, [r14+0x10]
000070d6f3dcf379  vmovaps xmm1, [rsp+0xB0]
000070d6f3dcf382  movups [r13+rax*1], xmm1
000070d6f3dcf388  mov rax, [r15+0x40]
000070d6f3dcf38c  vxorps xmm1, xmm1, xmm1
000070d6f3dcf390  vpbroadcastq xmm1, xmm1
000070d6f3dcf395  vmovaps [rsp+0x10], xmm1
000070d6f3dcf39b  vxorps xmm1, xmm1, xmm1
000070d6f3dcf39f  vpbroadcastq xmm1, xmm1
000070d6f3dcf3a4  lea r12, [rax+0x30]
000070d6f3dcf3a8  mov r11, [r13+r12*1]
000070d6f3dcf3ad  lea r12, [rax+0x38]
000070d6f3dcf3b1  mov r10, [r13+r12*1]
000070d6f3dcf3b6  vmovaps [rsp+0x60], xmm1
000070d6f3dcf3bc  movq xmm1, r11
000070d6f3dcf3c1  vmovaps [rsp+0x70], xmm1
000070d6f3dcf3c7  movq xmm1, r10
000070d6f3dcf3cc  vmovaps [rsp+0x90], xmm1
000070d6f3dcf3d5  vmovaps xmm1, [rsp+0x70]
000070d6f3dcf3db  movq xmm1, xmm1
000070d6f3dcf3df  vmovaps [rsp+0x70], xmm1
000070d6f3dcf3e5  vmovaps xmm1, [rsp+0x90]
000070d6f3dcf3ee  movq xmm1, xmm1
000070d6f3dcf3f2  vmovaps [rsp+0x90], xmm1
000070d6f3dcf3fb  movq xmm1, xmm1
000070d6f3dcf3ff  movaps [r15+0x270], xmm1
000070d6f3dcf407  vmovaps [rsp+0xA0], xmm7
000070d6f3dcf410  vmovaps xmm1, [rsp+0xA0]
000070d6f3dcf419  por xmm7, xmm1
000070d6f3dcf41d  lea r12, [rax+0x20]
000070d6f3dcf421  mov r11, [r13+r12*1]
000070d6f3dcf426  lea r12, [rax+0x28]
000070d6f3dcf42a  mov r10, [r13+r12*1]
000070d6f3dcf42f  movq xmm1, r11
000070d6f3dcf434  vmovaps [rsp+0xA0], xmm1
000070d6f3dcf43d  movq xmm1, r10
000070d6f3dcf442  vmovaps [rsp+0xB0], xmm1
000070d6f3dcf44b  vmovaps xmm1, [rsp+0xA0]
000070d6f3dcf454  movq xmm1, xmm1
000070d6f3dcf458  vmovaps [rsp+0xA0], xmm1
000070d6f3dcf461  vmovaps xmm1, [rsp+0xB0]
000070d6f3dcf46a  movq xmm1, xmm1
000070d6f3dcf46e  vmovaps [rsp+0xB0], xmm2
000070d6f3dcf477  vmovaps [rsp+0xC0], xmm1
000070d6f3dcf480  vmovaps xmm1, [rsp+0xB0]
000070d6f3dcf489  por xmm2, xmm1
000070d6f3dcf48d  vmovaps xmm1, [rsp+0x40]
000070d6f3dcf493  vmovaps [rsp+0xB0], xmm15
000070d6f3dcf49c  vmovaps xmm15, [rsp+0x40]
000070d6f3dcf4a2  por xmm1, xmm15
000070d6f3dcf4a7  vmovaps [rsp+0x40], xmm3
000070d6f3dcf4ad  vmovaps xmm15, [rsp+0x40]
000070d6f3dcf4b3  por xmm3, xmm15
000070d6f3dcf4b8  vmovaps [rsp+0x40], xmm10
000070d6f3dcf4be  vmovaps xmm15, [rsp+0x40]
000070d6f3dcf4c4  por xmm10, xmm15
000070d6f3dcf4c9  vmovaps [rsp+0x40], xmm12
000070d6f3dcf4cf  vmovaps xmm15, [rsp+0x40]
000070d6f3dcf4d5  por xmm12, xmm15
000070d6f3dcf4da  lea r12, [rax+0x10]
000070d6f3dcf4de  mov r11, [r13+r12*1]
000070d6f3dcf4e3  lea r12, [rax+0x18]
000070d6f3dcf4e7  mov r10, [r13+r12*1]
000070d6f3dcf4ec  movq xmm15, r11
000070d6f3dcf4f1  vmovaps [rsp+0x40], xmm1
000070d6f3dcf4f7  movq xmm1, r10
000070d6f3dcf4fc  movq xmm15, xmm15
000070d6f3dcf501  movq xmm1, xmm1
000070d6f3dcf505  vmovaps [rsp+0xD0], xmm1
000070d6f3dcf50e  vmovaps xmm1, [rsp+0x80]
000070d6f3dcf517  vmovaps [rsp+0xE0], xmm15
000070d6f3dcf520  vmovaps xmm15, [rsp+0x80]
000070d6f3dcf529  por xmm1, xmm15
000070d6f3dcf52e  vmovaps xmm15, [rsp+0x30]
000070d6f3dcf534  vmovaps [rsp+0x80], xmm1
000070d6f3dcf53d  vmovaps xmm1, [rsp+0x30]
000070d6f3dcf543  por xmm15, xmm1
000070d6f3dcf548  vmovaps xmm1, [rsp+0x20]
000070d6f3dcf54e  vmovaps [rsp+0x30], xmm15
000070d6f3dcf554  vmovaps xmm15, [rsp+0x20]
000070d6f3dcf55a  por xmm1, xmm15
000070d6f3dcf55f  vmovaps [rsp+0x20], xmm6
000070d6f3dcf565  vmovaps xmm15, [rsp+0x20]
000070d6f3dcf56b  por xmm6, xmm15
000070d6f3dcf570  vmovaps [rsp+0x20], xmm13
000070d6f3dcf576  vmovaps xmm15, [rsp+0x20]
000070d6f3dcf57c  por xmm13, xmm15
000070d6f3dcf581  vmovaps [rsp+0x20], xmm8
000070d6f3dcf587  vmovaps xmm15, [rsp+0x20]
000070d6f3dcf58d  por xmm8, xmm15
000070d6f3dcf592  vmovaps [rsp+0x20], xmm9
000070d6f3dcf598  vmovaps xmm15, [rsp+0x20]
000070d6f3dcf59e  por xmm9, xmm15
000070d6f3dcf5a3  mov r12, [r13+rax*1]
000070d6f3dcf5a8  vmovq xmm15, r12
000070d6f3dcf5ad  vpbroadcastq xmm15, xmm15
000070d6f3dcf5b2  vmovaps [rsp+0x20], xmm1
000070d6f3dcf5b8  vxorps xmm1, xmm1, xmm1
000070d6f3dcf5bc  vpbroadcastq xmm1, xmm1
000070d6f3dcf5c1  vmovaps [rsp+0xF0], xmm1
000070d6f3dcf5ca  movups xmm1, [r13+r14*1]
000070d6f3dcf5d0  vmovaps [rsp+0x100], xmm1
000070d6f3dcf5d9  vxorps xmm1, xmm1, xmm1
000070d6f3dcf5dd  vpbroadcastq xmm1, xmm1
000070d6f3dcf5e2  lea r12, [rax+0x08]
000070d6f3dcf5e6  mov rax, [r13+r12*1]
000070d6f3dcf5eb  vmovaps [rsp+0x110], xmm1
000070d6f3dcf5f4  movq xmm1, rax
000070d6f3dcf5f9  movaps [r15+0x240], xmm1
000070d6f3dcf601  mov qword ptr [r15+0x60], 0x4308D0
000070d6f3dcf609  mov qword ptr [r15+0x58], 0x40
000070d6f3dcf611  vmovaps xmm1, [rsp+0x10]
000070d6f3dcf617  vmovaps [rsp+0x10], xmm15
000070d6f3dcf61d  vmovaps xmm15, [rsp+0x100]
000070d6f3dcf626  vmovaps [rsp+0x100], xmm14
000070d6f3dcf62f  vmovaps xmm14, [rsp+0x10]
000070d6f3dcf635  vmovaps [rsp+0x10], xmm13
000070d6f3dcf63b  vmovaps [rsp+0x120], xmm12
000070d6f3dcf644  movaps xmm13, xmm1
000070d6f3dcf648  vfmadd231pd xmm13, xmm15, xmm14
000070d6f3dcf64d  vcmppd xmm12, xmm13, xmm13, 0x03
000070d6f3dcf653  vptest xmm12, xmm12
000070d6f3dcf658  jnz 0x000070D6F3DD0283
000070d6f3dcf65e  vmovaps xmm1, [rsp+0x60]
000070d6f3dcf664  vmovaps xmm15, [rsp+0xB0]
000070d6f3dcf66d  vmovaps [rsp+0x60], xmm13
000070d6f3dcf673  movaps xmm12, xmm1
000070d6f3dcf677  vfmadd231pd xmm12, xmm15, xmm14
000070d6f3dcf67c  vcmppd xmm13, xmm12, xmm12, 0x03
000070d6f3dcf682  vptest xmm13, xmm13
000070d6f3dcf687  jnz 0x000070D6F3DD03DC
000070d6f3dcf68d  vmovaps xmm1, [rsp+0x50]
000070d6f3dcf693  vmovaps xmm13, [rsp+0x50]
000070d6f3dcf699  por xmm1, xmm13
000070d6f3dcf69e  vmovaps [rsp+0x50], xmm4
000070d6f3dcf6a4  vmovaps xmm13, [rsp+0x50]
000070d6f3dcf6aa  por xmm4, xmm13
000070d6f3dcf6af  vmovaps [rsp+0x50], xmm5
000070d6f3dcf6b5  vmovaps xmm13, [rsp+0x50]
000070d6f3dcf6bb  por xmm5, xmm13
000070d6f3dcf6c0  vmovaps [rsp+0x50], xmm11
000070d6f3dcf6c6  vmovaps xmm13, [rsp+0x50]
000070d6f3dcf6cc  por xmm11, xmm13
000070d6f3dcf6d1  vmovaps xmm13, [rsp+0x100]
000070d6f3dcf6da  vmovaps [rsp+0x50], xmm1
000070d6f3dcf6e0  vmovaps xmm1, [rsp+0x100]
000070d6f3dcf6e9  por xmm13, xmm1
000070d6f3dcf6ee  vmovaps [rsp+0xB0], xmm15
000070d6f3dcf6f7  vmovaps xmm1, [rsp+0xB0]
000070d6f3dcf700  por xmm15, xmm1
000070d6f3dcf705  lea rax, [r14+0xC0]
000070d6f3dcf70c  movups xmm1, [r13+rax*1]
000070d6f3dcf712  xor eax, eax
000070d6f3dcf714  mov r12d, 0x40
000070d6f3dcf71a  mov r11d, 0x200
000070d6f3dcf720  cmp r12, r11
000070d6f3dcf723  cmc
000070d6f3dcf724  lahf
000070d6f3dcf725  seto al
000070d6f3dcf728  mov [r15+0x108], eax
000070d6f3dcf72f  vmovaps [rsp+0xB0], xmm1
000070d6f3dcf738  vmovaps xmm1, [rsp+0xF0]
000070d6f3dcf741  vmovaps [rsp+0xF0], xmm15
000070d6f3dcf74a  vmovaps xmm15, [rsp+0xB0]
000070d6f3dcf753  vmovaps [rsp+0xB0], xmm13
000070d6f3dcf75c  vmovaps [rsp+0x100], xmm12
000070d6f3dcf765  movaps xmm13, xmm1
000070d6f3dcf769  vfmadd231pd xmm13, xmm15, xmm14
000070d6f3dcf76e  vcmppd xmm12, xmm13, xmm13, 0x03
000070d6f3dcf774  vptest xmm12, xmm12
000070d6f3dcf779  jnz 0x000070D6F3DD053F
000070d6f3dcf77f  lea rax, [r14+0xB0]
000070d6f3dcf786  movups xmm1, [r13+rax*1]
000070d6f3dcf78c  vmovaps xmm15, [rsp+0x110]
000070d6f3dcf795  vmovaps [rsp+0x110], xmm13
000070d6f3dcf79e  movaps xmm12, xmm15
000070d6f3dcf7a2  vfmadd231pd xmm12, xmm1, xmm14
000070d6f3dcf7a7  vcmppd xmm13, xmm12, xmm12, 0x03
000070d6f3dcf7ad  vptest xmm13, xmm13
000070d6f3dcf7b2  jnz 0x000070D6F3DD06A2
000070d6f3dcf7b8  vmovaps [rsp+0x130], xmm9
000070d6f3dcf7c1  vmovaps xmm1, [rsp+0x130]
000070d6f3dcf7ca  por xmm9, xmm1
000070d6f3dcf7cf  movaps [r15+0x210], xmm9
000070d6f3dcf7d7  vmovaps [rsp+0x130], xmm8
000070d6f3dcf7e0  vmovaps xmm1, [rsp+0x130]
000070d6f3dcf7e9  por xmm8, xmm1
000070d6f3dcf7ee  movaps [r15+0x1C0], xmm8
000070d6f3dcf7f6  vmovaps xmm1, [rsp+0x10]
000070d6f3dcf7fc  vmovaps xmm15, [rsp+0x10]
000070d6f3dcf802  por xmm1, xmm15
000070d6f3dcf807  movaps [r15+0x280], xmm1
000070d6f3dcf80f  vmovaps [rsp+0x10], xmm6
000070d6f3dcf815  vmovaps xmm14, [rsp+0x10]
000070d6f3dcf81b  por xmm6, xmm14
000070d6f3dcf820  movaps [r15+0x2A0], xmm6
000070d6f3dcf828  vmovaps xmm15, [rsp+0x20]
000070d6f3dcf82e  vmovaps xmm14, [rsp+0x20]
000070d6f3dcf834  por xmm15, xmm14
000070d6f3dcf839  movaps [r15+0x2E0], xmm15
000070d6f3dcf841  vmovaps xmm14, [rsp+0x30]
000070d6f3dcf847  vmovaps xmm13, [rsp+0x30]
000070d6f3dcf84d  por xmm14, xmm13
000070d6f3dcf852  movaps [r15+0x1F0], xmm14
000070d6f3dcf85a  vmovaps xmm13, [rsp+0xF0]
000070d6f3dcf863  vmovaps [rsp+0x10], xmm1
000070d6f3dcf869  vmovaps xmm1, [rsp+0xF0]
000070d6f3dcf872  por xmm13, xmm1
000070d6f3dcf877  movaps [r15+0x250], xmm13
000070d6f3dcf87f  vmovaps xmm1, [rsp+0xB0]
000070d6f3dcf888  vmovaps xmm13, [rsp+0xB0]
000070d6f3dcf891  por xmm1, xmm13
000070d6f3dcf896  movaps [r15+0x260], xmm1
000070d6f3dcf89e  vmovaps [rsp+0x20], xmm11
000070d6f3dcf8a4  vmovaps xmm13, [rsp+0x20]
000070d6f3dcf8aa  por xmm11, xmm13
000070d6f3dcf8af  movaps [r15+0x290], xmm11
000070d6f3dcf8b7  vmovaps [rsp+0x20], xmm5
000070d6f3dcf8bd  vmovaps xmm13, [rsp+0x20]
000070d6f3dcf8c3  por xmm5, xmm13
000070d6f3dcf8c8  movaps [r15+0x2C0], xmm5
000070d6f3dcf8d0  movq xmm13, qword ptr [r15+0x240]
000070d6f3dcf8d9  vmovaps [rsp+0x20], xmm13
000070d6f3dcf8df  vpermilpd xmm13, xmm13, 0x00
000070d6f3dcf8e5  vmovaps [rsp+0x30], xmm1
000070d6f3dcf8eb  vmovaps xmm1, [rsp+0x60]
000070d6f3dcf8f1  vmovaps [rsp+0x60], xmm15
000070d6f3dcf8f7  vmovaps [rsp+0xB0], xmm14
000070d6f3dcf900  movaps xmm15, xmm1
000070d6f3dcf904  vfmadd231pd xmm15, xmm9, xmm13
000070d6f3dcf909  vcmppd xmm14, xmm15, xmm15, 0x03
000070d6f3dcf90f  vptest xmm14, xmm14
000070d6f3dcf914  jnz 0x000070D6F3DD07FB
000070d6f3dcf91a  vmovaps xmm1, [rsp+0x20]
000070d6f3dcf920  vpermilpd xmm1, xmm1, 0x00
000070d6f3dcf926  vmovaps xmm14, [rsp+0x110]
000070d6f3dcf92f  vmovaps xmm13, [rsp+0x60]
000070d6f3dcf935  vmovaps [rsp+0x60], xmm15
000070d6f3dcf93b  movaps xmm9, xmm14
000070d6f3dcf93f  vfmadd231pd xmm9, xmm13, xmm1
000070d6f3dcf944  vcmppd xmm15, xmm9, xmm9, 0x03
000070d6f3dcf94a  vptest xmm15, xmm15
000070d6f3dcf94f  jnz 0x000070D6F3DD0954
000070d6f3dcf955  vmovaps xmm1, [rsp+0x20]
000070d6f3dcf95b  vpermilpd xmm1, xmm1, 0x00
000070d6f3dcf961  vmovaps xmm15, [rsp+0x100]
000070d6f3dcf96a  movaps xmm14, xmm15
000070d6f3dcf96e  vfmadd231pd xmm14, xmm8, xmm1
000070d6f3dcf973  vcmppd xmm13, xmm14, xmm14, 0x03
000070d6f3dcf979  vptest xmm13, xmm13
000070d6f3dcf97e  jnz 0x000070D6F3DD0AAD
000070d6f3dcf984  vmovaps [rsp+0xF0], xmm4
000070d6f3dcf98d  vmovaps xmm1, [rsp+0xF0]
000070d6f3dcf996  por xmm4, xmm1
000070d6f3dcf99a  movaps [r15+0x1D0], xmm4
000070d6f3dcf9a2  vmovaps xmm1, [rsp+0x20]
000070d6f3dcf9a8  vpermilpd xmm1, xmm1, 0x00
000070d6f3dcf9ae  vmovaps xmm13, [rsp+0xB0]
000070d6f3dcf9b7  movaps xmm15, xmm12
000070d6f3dcf9bb  vfmadd231pd xmm15, xmm13, xmm1
000070d6f3dcf9c0  vcmppd xmm8, xmm15, xmm15, 0x03
000070d6f3dcf9c6  vptest xmm8, xmm8
000070d6f3dcf9cb  jnz 0x000070D6F3DD0C06
000070d6f3dcf9d1  vmovaps xmm1, [rsp+0x80]
000070d6f3dcf9da  vmovaps xmm13, [rsp+0x80]
000070d6f3dcf9e3  por xmm1, xmm13
000070d6f3dcf9e8  movaps [r15+0x200], xmm1
000070d6f3dcf9f0  vmovaps xmm13, [rsp+0x50]
000070d6f3dcf9f6  vmovaps xmm12, [rsp+0x50]
000070d6f3dcf9fc  por xmm13, xmm12
000070d6f3dcfa01  movaps [r15+0x1E0], xmm13
000070d6f3dcfa09  vmovaps [rsp+0x20], xmm10
000070d6f3dcfa0f  vmovaps xmm13, [rsp+0x20]
000070d6f3dcfa15  por xmm10, xmm13
000070d6f3dcfa1a  movaps [r15+0x2B0], xmm10
000070d6f3dcfa22  vmovaps [rsp+0x20], xmm3
000070d6f3dcfa28  vmovaps xmm13, [rsp+0x20]
000070d6f3dcfa2e  por xmm3, xmm13
000070d6f3dcfa33  movaps [r15+0x300], xmm3
000070d6f3dcfa3b  vmovaps xmm8, [rsp+0xE0]
000070d6f3dcfa44  vpermilpd xmm8, xmm8, 0x00
000070d6f3dcfa4a  vmovaps xmm3, [rsp+0x60]
000070d6f3dcfa50  vmovaps [rsp+0x20], xmm1
000070d6f3dcfa56  vmovaps xmm1, [rsp+0x30]
000070d6f3dcfa5c  vmovaps [rsp+0x30], xmm15
000070d6f3dcfa62  vmovaps [rsp+0x50], xmm14
000070d6f3dcfa68  movaps xmm15, xmm3
000070d6f3dcfa6c  vfmadd231pd xmm15, xmm1, xmm8
000070d6f3dcfa71  vcmppd xmm14, xmm15, xmm15, 0x03
000070d6f3dcfa77  vptest xmm14, xmm14
000070d6f3dcfa7c  jnz 0x000070D6F3DD0D5F
000070d6f3dcfa82  vmovaps xmm1, [rsp+0xE0]
000070d6f3dcfa8b  vpermilpd xmm1, xmm1, 0x00
000070d6f3dcfa91  movaps xmm8, xmm9
000070d6f3dcfa95  vfmadd231pd xmm8, xmm5, xmm1
000070d6f3dcfa9a  vcmppd xmm14, xmm8, xmm8, 0x03
000070d6f3dcfaa0  vptest xmm14, xmm14
000070d6f3dcfaa5  jnz 0x000070D6F3DD0EB7
000070d6f3dcfaab  vmovaps xmm1, [rsp+0xE0]
000070d6f3dcfab4  vpermilpd xmm1, xmm1, 0x00
000070d6f3dcfaba  vmovaps xmm14, [rsp+0x50]
000070d6f3dcfac0  vmovaps xmm9, [rsp+0x10]
000070d6f3dcfac6  movaps xmm5, xmm14
000070d6f3dcfaca  vfmadd231pd xmm5, xmm9, xmm1
000070d6f3dcfacf  vcmppd xmm3, xmm5, xmm5, 0x03
000070d6f3dcfad4  vptest xmm3, xmm3
000070d6f3dcfad9  jnz 0x000070D6F3DD100F
000070d6f3dcfadf  vmovaps xmm1, [rsp+0xE0]
000070d6f3dcfae8  vpermilpd xmm1, xmm1, 0x00
000070d6f3dcfaee  vmovaps xmm14, [rsp+0x30]
000070d6f3dcfaf4  movaps xmm9, xmm14
000070d6f3dcfaf8  vfmadd231pd xmm9, xmm4, xmm1
000070d6f3dcfafd  vcmppd xmm3, xmm9, xmm9, 0x03
000070d6f3dcfb03  vptest xmm3, xmm3
000070d6f3dcfb08  jnz 0x000070D6F3DD1166
000070d6f3dcfb0e  vmovaps xmm1, [rsp+0x120]
000070d6f3dcfb17  vmovaps xmm14, [rsp+0x120]
000070d6f3dcfb20  por xmm1, xmm14
000070d6f3dcfb25  movaps [r15+0x180], xmm1
000070d6f3dcfb2d  vmovaps xmm14, [rsp+0x40]
000070d6f3dcfb33  vmovaps xmm4, [rsp+0x40]
000070d6f3dcfb39  por xmm14, xmm4
000070d6f3dcfb3e  movaps [r15+0x2D0], xmm14
000070d6f3dcfb46  vmovaps [rsp+0x10], xmm2
000070d6f3dcfb4c  vmovaps xmm4, [rsp+0x10]
000070d6f3dcfb52  por xmm2, xmm4
000070d6f3dcfb56  movaps [r15+0x2F0], xmm2
000070d6f3dcfb5e  vmovaps xmm3, [rsp+0xD0]
000070d6f3dcfb67  vpermilpd xmm3, xmm3, 0x00
000070d6f3dcfb6d  vmovaps [rsp+0x10], xmm1
000070d6f3dcfb73  movaps xmm2, xmm8
000070d6f3dcfb77  vfmadd231pd xmm2, xmm13, xmm3
000070d6f3dcfb7c  vcmppd xmm1, xmm2, xmm2, 0x03
000070d6f3dcfb81  vptest xmm1, xmm1
000070d6f3dcfb86  jnz 0x000070D6F3DD12BE
000070d6f3dcfb8c  vmovaps xmm1, [rsp+0xD0]
000070d6f3dcfb95  vpermilpd xmm1, xmm1, 0x00
000070d6f3dcfb9b  vmovaps xmm13, [rsp+0x10]
000070d6f3dcfba1  movaps xmm8, xmm15
000070d6f3dcfba5  vfmadd231pd xmm8, xmm13, xmm1
000070d6f3dcfbaa  vcmppd xmm3, xmm8, xmm8, 0x03
000070d6f3dcfbb0  vptest xmm3, xmm3
000070d6f3dcfbb5  jnz 0x000070D6F3DD1415
000070d6f3dcfbbb  lea rax, [r14+0x80]
000070d6f3dcfbc2  movups xmm1, [r13+rax*1]
000070d6f3dcfbc8  movaps [r15+0x190], xmm1
000070d6f3dcfbd0  vmovaps xmm15, [rsp+0xD0]
000070d6f3dcfbd9  vpermilpd xmm15, xmm15, 0x00
000070d6f3dcfbdf  movaps xmm13, xmm5
000070d6f3dcfbe3  vfmadd231pd xmm13, xmm11, xmm15
000070d6f3dcfbe8  vcmppd xmm3, xmm13, xmm13, 0x03
000070d6f3dcfbee  vptest xmm3, xmm3
000070d6f3dcfbf3  jnz 0x000070D6F3DD1578
000070d6f3dcfbf9  vmovaps xmm15, [rsp+0xD0]
000070d6f3dcfc02  vpermilpd xmm15, xmm15, 0x00
000070d6f3dcfc08  movaps xmm11, xmm9
000070d6f3dcfc0c  vfmadd231pd xmm11, xmm4, xmm15
000070d6f3dcfc11  vcmppd xmm5, xmm11, xmm11, 0x03
000070d6f3dcfc17  vptest xmm5, xmm5
000070d6f3dcfc1c  jnz 0x000070D6F3DD16D1
000070d6f3dcfc22  vmovaps [rsp+0x10], xmm7
000070d6f3dcfc28  vmovaps xmm9, [rsp+0x10]
000070d6f3dcfc2e  por xmm7, xmm9
000070d6f3dcfc33  movaps [r15+0x160], xmm7
000070d6f3dcfc3b  lea rax, [r14+0x40]
000070d6f3dcfc3f  movups xmm15, [r13+rax*1]
000070d6f3dcfc45  lea rax, [r14+0x50]
000070d6f3dcfc49  movups xmm9, [r13+rax*1]
000070d6f3dcfc4f  movaps [r15+0x1B0], xmm15
000070d6f3dcfc57  movaps [r15+0x1A0], xmm9
000070d6f3dcfc5f  vmovaps xmm5, [rsp+0xA0]
000070d6f3dcfc68  vpermilpd xmm5, xmm5, 0x00
000070d6f3dcfc6e  movaps xmm4, xmm2
000070d6f3dcfc71  vfmadd231pd xmm4, xmm14, xmm5
000070d6f3dcfc76  vcmppd xmm3, xmm4, xmm4, 0x03
000070d6f3dcfc7b  vptest xmm3, xmm3
000070d6f3dcfc80  jnz 0x000070D6F3DD183E
000070d6f3dcfc86  vmovaps xmm14, [rsp+0xA0]
000070d6f3dcfc8f  vpermilpd xmm14, xmm14, 0x00
000070d6f3dcfc95  movaps xmm5, xmm8
000070d6f3dcfc99  vfmadd231pd xmm5, xmm7, xmm14
000070d6f3dcfc9e  vcmppd xmm3, xmm5, xmm5, 0x03
000070d6f3dcfca3  vptest xmm3, xmm3
000070d6f3dcfca8  jnz 0x000070D6F3DD1994
000070d6f3dcfcae  vmovaps xmm14, [rsp+0xA0]
000070d6f3dcfcb7  vpermilpd xmm14, xmm14, 0x00
000070d6f3dcfcbd  movaps xmm8, xmm13
000070d6f3dcfcc1  vfmadd231pd xmm8, xmm6, xmm14
000070d6f3dcfcc6  vcmppd xmm7, xmm8, xmm8, 0x03
000070d6f3dcfccc  vptest xmm7, xmm7
000070d6f3dcfcd1  jnz 0x000070D6F3DD1AEB
000070d6f3dcfcd7  vmovaps xmm14, [rsp+0xA0]
000070d6f3dcfce0  vpermilpd xmm14, xmm14, 0x00
000070d6f3dcfce6  movaps xmm13, xmm11
000070d6f3dcfcea  vfmadd231pd xmm13, xmm12, xmm14
000070d6f3dcfcef  vcmppd xmm7, xmm13, xmm13, 0x03
000070d6f3dcfcf5  vptest xmm7, xmm7
000070d6f3dcfcfa  jnz 0x000070D6F3DD1C44
000070d6f3dcfd00  lea rax, [r14+0x60]
000070d6f3dcfd04  movups xmm14, [r13+rax*1]
000070d6f3dcfd0a  lea rax, [r14+0x70]
000070d6f3dcfd0e  movups xmm12, [r13+rax*1]
000070d6f3dcfd14  movaps [r15+0x150], xmm14
000070d6f3dcfd1c  movaps [r15+0x120], xmm12
000070d6f3dcfd24  vmovaps xmm11, [rsp+0xC0]
000070d6f3dcfd2d  vpermilpd xmm11, xmm11, 0x00
000070d6f3dcfd33  movaps xmm7, xmm4
000070d6f3dcfd36  vfmadd231pd xmm7, xmm9, xmm11
000070d6f3dcfd3b  vcmppd xmm6, xmm7, xmm7, 0x03
000070d6f3dcfd40  vptest xmm6, xmm6
000070d6f3dcfd45  jnz 0x000070D6F3DD1DB2
000070d6f3dcfd4b  vmovaps xmm11, [rsp+0xC0]
000070d6f3dcfd54  vpermilpd xmm11, xmm11, 0x00
000070d6f3dcfd5a  movaps xmm9, xmm5
000070d6f3dcfd5e  vfmadd231pd xmm9, xmm14, xmm11
000070d6f3dcfd63  vcmppd xmm6, xmm9, xmm9, 0x03
000070d6f3dcfd69  vptest xmm6, xmm6
000070d6f3dcfd6e  jnz 0x000070D6F3DD1F09
000070d6f3dcfd74  vmovaps xmm14, [rsp+0xC0]
000070d6f3dcfd7d  vpermilpd xmm14, xmm14, 0x00
000070d6f3dcfd83  movaps xmm11, xmm8
000070d6f3dcfd87  vfmadd231pd xmm11, xmm10, xmm14
000070d6f3dcfd8c  vcmppd xmm6, xmm11, xmm11, 0x03
000070d6f3dcfd92  vptest xmm6, xmm6
000070d6f3dcfd97  jnz 0x000070D6F3DD2062
000070d6f3dcfd9d  vmovaps xmm14, [rsp+0xC0]
000070d6f3dcfda6  vpermilpd xmm14, xmm14, 0x00
000070d6f3dcfdac  movaps xmm10, xmm13
000070d6f3dcfdb0  vfmadd231pd xmm10, xmm15, xmm14
000070d6f3dcfdb5  vcmppd xmm8, xmm10, xmm10, 0x03
000070d6f3dcfdbb  vptest xmm8, xmm8
000070d6f3dcfdc0  jnz 0x000070D6F3DD21BC
000070d6f3dcfdc6  lea rax, [r14+0x20]
000070d6f3dcfdca  movups xmm15, [r13+rax*1]
000070d6f3dcfdd0  lea rax, [r14+0x30]
000070d6f3dcfdd4  movups xmm14, [r13+rax*1]
000070d6f3dcfdda  vmovaps xmm13, [rsp+0x70]
000070d6f3dcfde0  vpermilpd xmm13, xmm13, 0x00
000070d6f3dcfde6  vmovaps xmm8, [rsp+0x20]
000070d6f3dcfdec  movaps xmm6, xmm7
000070d6f3dcfdef  vfmadd231pd xmm6, xmm8, xmm13
000070d6f3dcfdf4  vcmppd xmm5, xmm6, xmm6, 0x03
000070d6f3dcfdf9  vptest xmm5, xmm5
000070d6f3dcfdfe  jnz 0x000070D6F3DD232A
000070d6f3dcfe04  vmovaps xmm13, [rsp+0x70]
000070d6f3dcfe0a  vpermilpd xmm13, xmm13, 0x00
000070d6f3dcfe10  movaps xmm8, xmm9
000070d6f3dcfe14  vfmadd231pd xmm8, xmm1, xmm13
000070d6f3dcfe19  vcmppd xmm7, xmm8, xmm8, 0x03
000070d6f3dcfe1f  vptest xmm7, xmm7
000070d6f3dcfe24  jnz 0x000070D6F3DD2481
000070d6f3dcfe2a  vmovaps xmm1, [rsp+0x70]
000070d6f3dcfe30  vpermilpd xmm1, xmm1, 0x00
000070d6f3dcfe36  movaps xmm13, xmm11
000070d6f3dcfe3a  vfmadd231pd xmm13, xmm12, xmm1
000070d6f3dcfe3f  vcmppd xmm9, xmm13, xmm13, 0x03
000070d6f3dcfe45  vptest xmm9, xmm9
000070d6f3dcfe4a  jnz 0x000070D6F3DD25DA
000070d6f3dcfe50  vmovaps xmm1, [rsp+0x70]
000070d6f3dcfe56  vpermilpd xmm1, xmm1, 0x00
000070d6f3dcfe5c  movaps xmm12, xmm10
000070d6f3dcfe60  vfmadd231pd xmm12, xmm14, xmm1
000070d6f3dcfe65  vcmppd xmm11, xmm12, xmm12, 0x03
000070d6f3dcfe6b  vptest xmm11, xmm11
000070d6f3dcfe70  jnz 0x000070D6F3DD2733
000070d6f3dcfe76  lea rax, [r14+0x90]
000070d6f3dcfe7d  movups xmm1, [r13+rax*1]
000070d6f3dcfe83  lea rax, [r14+0xA0]
000070d6f3dcfe8a  movups xmm14, [r13+rax*1]
000070d6f3dcfe90  movaps [r15+0x140], xmm1
000070d6f3dcfe98  movaps [r15+0x130], xmm14
000070d6f3dcfea0  vmovaps xmm11, [rsp+0x90]
000070d6f3dcfea9  vpermilpd xmm11, xmm11, 0x00
000070d6f3dcfeaf  movaps xmm10, xmm6
000070d6f3dcfeb3  vfmadd231pd xmm10, xmm15, xmm11
000070d6f3dcfeb8  vcmppd xmm9, xmm10, xmm10, 0x03
000070d6f3dcfebe  vptest xmm9, xmm9
000070d6f3dcfec3  jnz 0x000070D6F3DD28A0
000070d6f3dcfec9  movaps [r15+0x220], xmm10
000070d6f3dcfed1  lea rax, [r14+0x10]
000070d6f3dcfed5  movups xmm15, [r13+rax*1]
000070d6f3dcfedb  movaps [r15+0x240], xmm15
000070d6f3dcfee3  vmovaps xmm11, [rsp+0x90]
000070d6f3dcfeec  vpermilpd xmm11, xmm11, 0x00
000070d6f3dcfef2  movaps xmm9, xmm8
000070d6f3dcfef6  vfmadd231pd xmm9, xmm14, xmm11
000070d6f3dcfefb  vcmppd xmm7, xmm9, xmm9, 0x03
000070d6f3dcff01  vptest xmm7, xmm7
000070d6f3dcff06  jnz 0x000070D6F3DD2A03
000070d6f3dcff0c  movaps [r15+0x110], xmm9
000070d6f3dcff14  vmovaps xmm14, [rsp+0x90]
000070d6f3dcff1d  vpermilpd xmm14, xmm14, 0x00
000070d6f3dcff23  movaps xmm11, xmm13
000070d6f3dcff27  vfmadd231pd xmm11, xmm1, xmm14
000070d6f3dcff2c  vcmppd xmm8, xmm11, xmm11, 0x03
000070d6f3dcff32  vptest xmm8, xmm8
000070d6f3dcff37  jnz 0x000070D6F3DD2B5D
000070d6f3dcff3d  movaps [r15+0x170], xmm11
000070d6f3dcff45  vmovaps xmm1, [rsp+0x90]
000070d6f3dcff4e  vpermilpd xmm1, xmm1, 0x00
000070d6f3dcff54  movaps xmm14, xmm12
000070d6f3dcff58  vfmadd231pd xmm14, xmm15, xmm1
000070d6f3dcff5d  vcmppd xmm13, xmm14, xmm14, 0x03
000070d6f3dcff63  vptest xmm13, xmm13
000070d6f3dcff68  jnz 0x000070D6F3DD2CB6
000070d6f3dcff6e  movaps [r15+0x230], xmm14
000070d6f3dcff76  mov eax, 0x4308D0
000070d6f3dcff7b  movups [r13+rax*1], xmm9
000070d6f3dcff81  mov eax, 0x4308E0
000070d6f3dcff86  movups [r13+rax*1], xmm11
000070d6f3dcff8c  mov eax, 0x4308F0
000070d6f3dcff91  movups [r13+rax*1], xmm10
000070d6f3dcff97  mov eax, 0x430900
000070d6f3dcff9c  movups [r13+rax*1], xmm14
000070d6f3dcffa2  mov eax, [r15+0x108]
000070d6f3dcffa9  sahf
000070d6f3dcffaa  jnz 0x000070D6F3DCFFDC
000070d6f3dcffac  cmp dword ptr [r15+0x318], 0x00
000070d6f3dcffb4  jz 0x000070D6F3DD67A0
000070d6f3dcffba  nop [rax+rax*1], ax
000070d6f3dcffc3  nop [rax+rax*1], eax
000070d6f3dcffcb  mov eax, 0x4103F0
000070d6f3dcffd0  mov [r15+0x100], rax
000070d6f3dcffd7  jmp 0x000070D6F3BFE110
000070d6f3dcffdc  cmp dword ptr [r15+0x318], 0x00
000070d6f3dcffe4  jz 0x000070D6F3DD2E40
000070d6f3dcffea  nop [rax+rax*1], ax
000070d6f3dcfff3  nop [rax+rax*1], eax
000070d6f3dcfffb  mov eax, 0x410274
000070d6f3dd0000  mov [r15+0x100], rax
000070d6f3dd0007  jmp 0x000070D6F3BFE110
000070d6f3dd000c  int3
000070d6f3dd000d  call 0x000070D6F3BFF430
000070d6f3dd0012  jmp 0x000070D6F3DCF00F
000070d6f3dd0017  call 0x000070D6F3CC4620
000070d6f3dd001c  jmp 0x000070D6F3DCF019
000070d6f3dd0021  call 0x000070D6F3CC0860
000070d6f3dd0026  jmp 0x000070D6F3DCF049
000070d6f3dd002b  call 0x000070D6F3CBF5F0
000070d6f3dd0030  jmp 0x000070D6F3DCF055
000070d6f3dd0035  call 0x000070D6F3CC33A0
000070d6f3dd003a  jmp 0x000070D6F3DCF062
000070d6f3dd003f  call 0x000070D6F3CC2120
000070d6f3dd0044  jmp 0x000070D6F3DCF06F
000070d6f3dd0049  call 0x000070D6F3CC0860
000070d6f3dd004e  jmp 0x000070D6F3DCF097
000070d6f3dd0053  call 0x000070D6F3CBF5F0
000070d6f3dd0058  jmp 0x000070D6F3DCF0A3
000070d6f3dd005d  call 0x000070D6F3CC0EA0
000070d6f3dd0062  jmp 0x000070D6F3DCF0B0
000070d6f3dd0067  call 0x000070D6F3CBFC30
000070d6f3dd006c  jmp 0x000070D6F3DCF0BD
000070d6f3dd0071  call 0x000070D6F3CD6600
000070d6f3dd0076  jmp 0x000070D6F3DCF0C3
000070d6f3dd007b  call 0x000070D6F3CB52F0
000070d6f3dd0080  jmp 0x000070D6F3DCF0CD
000070d6f3dd0085  call 0x000070D6F3CBE9C0
000070d6f3dd008a  jmp 0x000070D6F3DCF0D7
000070d6f3dd008f  call 0x000070D6F3CC0860
000070d6f3dd0094  jmp 0x000070D6F3DCF0FF
000070d6f3dd0099  call 0x000070D6F3CBF5F0
000070d6f3dd009e  jmp 0x000070D6F3DCF10B
000070d6f3dd00a3  call 0x000070D6F3CBD750
000070d6f3dd00a8  jmp 0x000070D6F3DCF115
000070d6f3dd00ad  call 0x000070D6F3CBC4E0
000070d6f3dd00b2  jmp 0x000070D6F3DCF11F
000070d6f3dd00b7  call 0x000070D6F3CC0860
000070d6f3dd00bc  jmp 0x000070D6F3DCF147
000070d6f3dd00c1  call 0x000070D6F3CBF5F0
000070d6f3dd00c6  jmp 0x000070D6F3DCF153
000070d6f3dd00cb  call 0x000070D6F3CBB270
000070d6f3dd00d0  jmp 0x000070D6F3DCF160
000070d6f3dd00d5  call 0x000070D6F3CBA000
000070d6f3dd00da  jmp 0x000070D6F3DCF16D
000070d6f3dd00df  call 0x000070D6F3CBEAE0
000070d6f3dd00e4  jmp 0x000070D6F3DCF17A
000070d6f3dd00e9  call 0x000070D6F3CB5400
000070d6f3dd00ee  jmp 0x000070D6F3DCF187
000070d6f3dd00f3  call 0x000070D6F3CB52F0
000070d6f3dd00f8  jmp 0x000070D6F3DCF194
000070d6f3dd00fd  call 0x000070D6F3CBE9C0
000070d6f3dd0102  jmp 0x000070D6F3DCF1A1
000070d6f3dd0107  call 0x000070D6F3CC0860
000070d6f3dd010c  jmp 0x000070D6F3DCF1B4
000070d6f3dd0111  call 0x000070D6F3CB8D90
000070d6f3dd0116  jmp 0x000070D6F3DCF1C1
000070d6f3dd011b  call 0x000070D6F3CB8A20
000070d6f3dd0120  jmp 0x000070D6F3DCF1CE
000070d6f3dd0125  call 0x000070D6F3CB77B0
000070d6f3dd012a  jmp 0x000070D6F3DCF1DB
000070d6f3dd012f  call 0x000070D6F3CB6550
000070d6f3dd0134  jmp 0x000070D6F3DCF1E8
000070d6f3dd0139  call 0x000070D6F3CB52F0
000070d6f3dd013e  jmp 0x000070D6F3DCF1F8
000070d6f3dd0143  call 0x000070D6F3CB52F0
000070d6f3dd0148  jmp 0x000070D6F3DCF208
000070d6f3dd014d  call 0x000070D6F3CB8B30
000070d6f3dd0152  jmp 0x000070D6F3DCF212
000070d6f3dd0157  call 0x000070D6F3CB8EA0
000070d6f3dd015c  jmp 0x000070D6F3DCF21F
000070d6f3dd0161  call 0x000070D6F3CB8D90
000070d6f3dd0166  jmp 0x000070D6F3DCF22C
000070d6f3dd016b  call 0x000070D6F3CB8A20
000070d6f3dd0170  jmp 0x000070D6F3DCF239
000070d6f3dd0175  call 0x000070D6F3CB6660
000070d6f3dd017a  jmp 0x000070D6F3DCF246
000070d6f3dd017f  call 0x000070D6F3CB78C0
000070d6f3dd0184  jmp 0x000070D6F3DCF253
000070d6f3dd0189  call 0x000070D6F3CB77B0
000070d6f3dd018e  jmp 0x000070D6F3DCF260
000070d6f3dd0193  call 0x000070D6F3CB6550
000070d6f3dd0198  jmp 0x000070D6F3DCF26D
000070d6f3dd019d  call 0x000070D6F3CB52F0
000070d6f3dd01a2  jmp 0x000070D6F3DCF280
000070d6f3dd01a7  call 0x000070D6F3CB52F0
000070d6f3dd01ac  jmp 0x000070D6F3DCF293
000070d6f3dd01b1  call 0x000070D6F3CB52F0
000070d6f3dd01b6  jmp 0x000070D6F3DCF2A6
000070d6f3dd01bb  call 0x000070D6F3CB52F0
000070d6f3dd01c0  jmp 0x000070D6F3DCF2B9
000070d6f3dd01c5  call 0x000070D6F3CB52F0
000070d6f3dd01ca  jmp 0x000070D6F3DCF2CC
000070d6f3dd01cf  call 0x000070D6F3CB52F0
000070d6f3dd01d4  jmp 0x000070D6F3DCF2E2
000070d6f3dd01d9  call 0x000070D6F3CB52F0
000070d6f3dd01de  jmp 0x000070D6F3DCF2F8
000070d6f3dd01e3  call 0x000070D6F3CB52F0
000070d6f3dd01e8  jmp 0x000070D6F3DCF30E
000070d6f3dd01ed  call 0x000070D6F3BFF540
000070d6f3dd01f2  jmp 0x000070D6F3DCF32F
000070d6f3dd01f7  call 0x000070D6F3BFF540
000070d6f3dd01fc  jmp 0x000070D6F3DCF33F
000070d6f3dd0201  call 0x000070D6F3BFF540
000070d6f3dd0206  jmp 0x000070D6F3DCF34F
000070d6f3dd020b  call 0x000070D6F3BFF540
000070d6f3dd0210  jmp 0x000070D6F3DCF362
000070d6f3dd0215  call 0x000070D6F3BFF540
000070d6f3dd021a  jmp 0x000070D6F3DCF375
000070d6f3dd021f  call 0x000070D6F3BFF540
000070d6f3dd0224  jmp 0x000070D6F3DCF388
000070d6f3dd0229  call 0x000070D6F3CC0370
000070d6f3dd022e  jmp 0x000070D6F3DCF3AD
000070d6f3dd0233  call 0x000070D6F3CBF100
000070d6f3dd0238  jmp 0x000070D6F3DCF3B6
000070d6f3dd023d  call 0x000070D6F3CC0370
000070d6f3dd0242  jmp 0x000070D6F3DCF426
000070d6f3dd0247  call 0x000070D6F3CBF100
000070d6f3dd024c  jmp 0x000070D6F3DCF42F
000070d6f3dd0251  call 0x000070D6F3CC0370
000070d6f3dd0256  jmp 0x000070D6F3DCF4E3
000070d6f3dd025b  call 0x000070D6F3CBF100
000070d6f3dd0260  jmp 0x000070D6F3DCF4EC
000070d6f3dd0265  call 0x000070D6F3C0B720
000070d6f3dd026a  jmp 0x000070D6F3DCF5A8
000070d6f3dd026f  call 0x000070D6F3CD64F0
000070d6f3dd0274  jmp 0x000070D6F3DCF5D0
000070d6f3dd0279  call 0x000070D6F3CB47C0
000070d6f3dd027e  jmp 0x000070D6F3DCF5EB
000070d6f3dd0283  sub rsp, 0x08
000070d6f3dd0287  push rax
000070d6f3dd0288  push rcx
000070d6f3dd0289  push rdx
000070d6f3dd028a  push rdi
000070d6f3dd028b  push rsi
000070d6f3dd028c  push r8
000070d6f3dd028e  push r9
000070d6f3dd0290  push r10
000070d6f3dd0292  push r11
000070d6f3dd0294  sub rsp, 0xF0
000070d6f3dd029b  vmovaps [rsp], xmm0
000070d6f3dd02a0  vmovaps [rsp+0x10], xmm1
000070d6f3dd02a6  vmovaps [rsp+0x20], xmm2
000070d6f3dd02ac  vmovaps [rsp+0x30], xmm3
000070d6f3dd02b2  vmovaps [rsp+0x40], xmm4
000070d6f3dd02b8  vmovaps [rsp+0x50], xmm5
000070d6f3dd02be  vmovaps [rsp+0x60], xmm6
000070d6f3dd02c4  vmovaps [rsp+0x70], xmm7
000070d6f3dd02ca  vmovaps [rsp+0x80], xmm8
000070d6f3dd02d3  vmovaps [rsp+0x90], xmm9
000070d6f3dd02dc  vmovaps [rsp+0xA0], xmm10
000070d6f3dd02e5  vmovaps [rsp+0xB0], xmm11
000070d6f3dd02ee  vmovaps [rsp+0xC0], xmm12
000070d6f3dd02f7  vmovaps [rsp+0xD0], xmm14
000070d6f3dd0300  vmovaps [rsp+0xE0], xmm15
000070d6f3dd0309  sub rsp, 0x40
000070d6f3dd030d  lea rdi, [rsp]
000070d6f3dd0311  lea rsi, [rsp+0x10]
000070d6f3dd0316  lea rdx, [rsp+0x20]
000070d6f3dd031b  lea rcx, [rsp+0x30]
000070d6f3dd0320  mov r8d, 0x00
000070d6f3dd0326  lea r9, [r15+0x3A8]
000070d6f3dd032d  movaps [rdi], xmm13
000070d6f3dd0331  movaps [rsi], xmm1
000070d6f3dd0334  movaps [rdx], xmm15
000070d6f3dd0338  movaps [rcx], xmm14
000070d6f3dd033c  mov rax, 0x61D08D40EA50
000070d6f3dd0346  call rax
000070d6f3dd0348  movaps xmm13, [rsp]
000070d6f3dd034d  add rsp, 0x40
000070d6f3dd0351  vmovaps xmm0, [rsp]
000070d6f3dd0356  vmovaps xmm1, [rsp+0x10]
000070d6f3dd035c  vmovaps xmm2, [rsp+0x20]
000070d6f3dd0362  vmovaps xmm3, [rsp+0x30]
000070d6f3dd0368  vmovaps xmm4, [rsp+0x40]
000070d6f3dd036e  vmovaps xmm5, [rsp+0x50]
000070d6f3dd0374  vmovaps xmm6, [rsp+0x60]
000070d6f3dd037a  vmovaps xmm7, [rsp+0x70]
000070d6f3dd0380  vmovaps xmm8, [rsp+0x80]
000070d6f3dd0389  vmovaps xmm9, [rsp+0x90]
000070d6f3dd0392  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd039b  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd03a4  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd03ad  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd03b6  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd03bf  add rsp, 0xF0
000070d6f3dd03c6  pop r11
000070d6f3dd03c8  pop r10
000070d6f3dd03ca  pop r9
000070d6f3dd03cc  pop r8
000070d6f3dd03ce  pop rsi
000070d6f3dd03cf  pop rdi
000070d6f3dd03d0  pop rdx
000070d6f3dd03d1  pop rcx
000070d6f3dd03d2  pop rax
000070d6f3dd03d3  add rsp, 0x08
000070d6f3dd03d7  jmp 0x000070D6F3DCF65E
000070d6f3dd03dc  sub rsp, 0x08
000070d6f3dd03e0  push rax
000070d6f3dd03e1  push rcx
000070d6f3dd03e2  push rdx
000070d6f3dd03e3  push rdi
000070d6f3dd03e4  push rsi
000070d6f3dd03e5  push r8
000070d6f3dd03e7  push r9
000070d6f3dd03e9  push r10
000070d6f3dd03eb  push r11
000070d6f3dd03ed  sub rsp, 0xF0
000070d6f3dd03f4  vmovaps [rsp], xmm0
000070d6f3dd03f9  vmovaps [rsp+0x10], xmm1
000070d6f3dd03ff  vmovaps [rsp+0x20], xmm2
000070d6f3dd0405  vmovaps [rsp+0x30], xmm3
000070d6f3dd040b  vmovaps [rsp+0x40], xmm4
000070d6f3dd0411  vmovaps [rsp+0x50], xmm5
000070d6f3dd0417  vmovaps [rsp+0x60], xmm6
000070d6f3dd041d  vmovaps [rsp+0x70], xmm7
000070d6f3dd0423  vmovaps [rsp+0x80], xmm8
000070d6f3dd042c  vmovaps [rsp+0x90], xmm9
000070d6f3dd0435  vmovaps [rsp+0xA0], xmm10
000070d6f3dd043e  vmovaps [rsp+0xB0], xmm11
000070d6f3dd0447  vmovaps [rsp+0xC0], xmm13
000070d6f3dd0450  vmovaps [rsp+0xD0], xmm14
000070d6f3dd0459  vmovaps [rsp+0xE0], xmm15
000070d6f3dd0462  sub rsp, 0x40
000070d6f3dd0466  lea rdi, [rsp]
000070d6f3dd046a  lea rsi, [rsp+0x10]
000070d6f3dd046f  lea rdx, [rsp+0x20]
000070d6f3dd0474  lea rcx, [rsp+0x30]
000070d6f3dd0479  mov r8d, 0x00
000070d6f3dd047f  lea r9, [r15+0x3A8]
000070d6f3dd0486  movaps [rdi], xmm12
000070d6f3dd048a  movaps [rsi], xmm1
000070d6f3dd048d  movaps [rdx], xmm15
000070d6f3dd0491  movaps [rcx], xmm14
000070d6f3dd0495  mov rax, 0x61D08D40EA50
000070d6f3dd049f  call rax
000070d6f3dd04a1  movaps xmm12, [rsp]
000070d6f3dd04a6  add rsp, 0x40
000070d6f3dd04aa  vmovaps xmm0, [rsp]
000070d6f3dd04af  vmovaps xmm1, [rsp+0x10]
000070d6f3dd04b5  vmovaps xmm2, [rsp+0x20]
000070d6f3dd04bb  vmovaps xmm3, [rsp+0x30]
000070d6f3dd04c1  vmovaps xmm4, [rsp+0x40]
000070d6f3dd04c7  vmovaps xmm5, [rsp+0x50]
000070d6f3dd04cd  vmovaps xmm6, [rsp+0x60]
000070d6f3dd04d3  vmovaps xmm7, [rsp+0x70]
000070d6f3dd04d9  vmovaps xmm8, [rsp+0x80]
000070d6f3dd04e2  vmovaps xmm9, [rsp+0x90]
000070d6f3dd04eb  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd04f4  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd04fd  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd0506  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd050f  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd0518  add rsp, 0xF0
000070d6f3dd051f  pop r11
000070d6f3dd0521  pop r10
000070d6f3dd0523  pop r9
000070d6f3dd0525  pop r8
000070d6f3dd0527  pop rsi
000070d6f3dd0528  pop rdi
000070d6f3dd0529  pop rdx
000070d6f3dd052a  pop rcx
000070d6f3dd052b  pop rax
000070d6f3dd052c  add rsp, 0x08
000070d6f3dd0530  jmp 0x000070D6F3DCF68D
000070d6f3dd0535  call 0x000070D6F3BFF430
000070d6f3dd053a  jmp 0x000070D6F3DCF712
000070d6f3dd053f  sub rsp, 0x08
000070d6f3dd0543  push rax
000070d6f3dd0544  push rcx
000070d6f3dd0545  push rdx
000070d6f3dd0546  push rdi
000070d6f3dd0547  push rsi
000070d6f3dd0548  push r8
000070d6f3dd054a  push r9
000070d6f3dd054c  push r10
000070d6f3dd054e  push r11
000070d6f3dd0550  sub rsp, 0xF0
000070d6f3dd0557  vmovaps [rsp], xmm0
000070d6f3dd055c  vmovaps [rsp+0x10], xmm1
000070d6f3dd0562  vmovaps [rsp+0x20], xmm2
000070d6f3dd0568  vmovaps [rsp+0x30], xmm3
000070d6f3dd056e  vmovaps [rsp+0x40], xmm4
000070d6f3dd0574  vmovaps [rsp+0x50], xmm5
000070d6f3dd057a  vmovaps [rsp+0x60], xmm6
000070d6f3dd0580  vmovaps [rsp+0x70], xmm7
000070d6f3dd0586  vmovaps [rsp+0x80], xmm8
000070d6f3dd058f  vmovaps [rsp+0x90], xmm9
000070d6f3dd0598  vmovaps [rsp+0xA0], xmm10
000070d6f3dd05a1  vmovaps [rsp+0xB0], xmm11
000070d6f3dd05aa  vmovaps [rsp+0xC0], xmm12
000070d6f3dd05b3  vmovaps [rsp+0xD0], xmm14
000070d6f3dd05bc  vmovaps [rsp+0xE0], xmm15
000070d6f3dd05c5  sub rsp, 0x40
000070d6f3dd05c9  lea rdi, [rsp]
000070d6f3dd05cd  lea rsi, [rsp+0x10]
000070d6f3dd05d2  lea rdx, [rsp+0x20]
000070d6f3dd05d7  lea rcx, [rsp+0x30]
000070d6f3dd05dc  mov r8d, 0x00
000070d6f3dd05e2  lea r9, [r15+0x3A8]
000070d6f3dd05e9  movaps [rdi], xmm13
000070d6f3dd05ed  movaps [rsi], xmm1
000070d6f3dd05f0  movaps [rdx], xmm15
000070d6f3dd05f4  movaps [rcx], xmm14
000070d6f3dd05f8  mov rax, 0x61D08D40EA50
000070d6f3dd0602  call rax
000070d6f3dd0604  movaps xmm13, [rsp]
000070d6f3dd0609  add rsp, 0x40
000070d6f3dd060d  vmovaps xmm0, [rsp]
000070d6f3dd0612  vmovaps xmm1, [rsp+0x10]
000070d6f3dd0618  vmovaps xmm2, [rsp+0x20]
000070d6f3dd061e  vmovaps xmm3, [rsp+0x30]
000070d6f3dd0624  vmovaps xmm4, [rsp+0x40]
000070d6f3dd062a  vmovaps xmm5, [rsp+0x50]
000070d6f3dd0630  vmovaps xmm6, [rsp+0x60]
000070d6f3dd0636  vmovaps xmm7, [rsp+0x70]
000070d6f3dd063c  vmovaps xmm8, [rsp+0x80]
000070d6f3dd0645  vmovaps xmm9, [rsp+0x90]
000070d6f3dd064e  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd0657  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd0660  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd0669  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd0672  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd067b  add rsp, 0xF0
000070d6f3dd0682  pop r11
000070d6f3dd0684  pop r10
000070d6f3dd0686  pop r9
000070d6f3dd0688  pop r8
000070d6f3dd068a  pop rsi
000070d6f3dd068b  pop rdi
000070d6f3dd068c  pop rdx
000070d6f3dd068d  pop rcx
000070d6f3dd068e  pop rax
000070d6f3dd068f  add rsp, 0x08
000070d6f3dd0693  jmp 0x000070D6F3DCF77F
000070d6f3dd0698  call 0x000070D6F3BFF430
000070d6f3dd069d  jmp 0x000070D6F3DCF78C
000070d6f3dd06a2  sub rsp, 0x08
000070d6f3dd06a6  push rax
000070d6f3dd06a7  push rcx
000070d6f3dd06a8  push rdx
000070d6f3dd06a9  push rdi
000070d6f3dd06aa  push rsi
000070d6f3dd06ab  push r8
000070d6f3dd06ad  push r9
000070d6f3dd06af  push r10
000070d6f3dd06b1  push r11
000070d6f3dd06b3  sub rsp, 0xF0
000070d6f3dd06ba  vmovaps [rsp], xmm0
000070d6f3dd06bf  vmovaps [rsp+0x10], xmm1
000070d6f3dd06c5  vmovaps [rsp+0x20], xmm2
000070d6f3dd06cb  vmovaps [rsp+0x30], xmm3
000070d6f3dd06d1  vmovaps [rsp+0x40], xmm4
000070d6f3dd06d7  vmovaps [rsp+0x50], xmm5
000070d6f3dd06dd  vmovaps [rsp+0x60], xmm6
000070d6f3dd06e3  vmovaps [rsp+0x70], xmm7
000070d6f3dd06e9  vmovaps [rsp+0x80], xmm8
000070d6f3dd06f2  vmovaps [rsp+0x90], xmm9
000070d6f3dd06fb  vmovaps [rsp+0xA0], xmm10
000070d6f3dd0704  vmovaps [rsp+0xB0], xmm11
000070d6f3dd070d  vmovaps [rsp+0xC0], xmm13
000070d6f3dd0716  vmovaps [rsp+0xD0], xmm14
000070d6f3dd071f  vmovaps [rsp+0xE0], xmm15
000070d6f3dd0728  sub rsp, 0x40
000070d6f3dd072c  lea rdi, [rsp]
000070d6f3dd0730  lea rsi, [rsp+0x10]
000070d6f3dd0735  lea rdx, [rsp+0x20]
000070d6f3dd073a  lea rcx, [rsp+0x30]
000070d6f3dd073f  mov r8d, 0x00
000070d6f3dd0745  lea r9, [r15+0x3A8]
000070d6f3dd074c  movaps [rdi], xmm12
000070d6f3dd0750  movaps [rsi], xmm15
000070d6f3dd0754  movaps [rdx], xmm1
000070d6f3dd0757  movaps [rcx], xmm14
000070d6f3dd075b  mov rax, 0x61D08D40EA50
000070d6f3dd0765  call rax
000070d6f3dd0767  movaps xmm12, [rsp]
000070d6f3dd076c  add rsp, 0x40
000070d6f3dd0770  vmovaps xmm0, [rsp]
000070d6f3dd0775  vmovaps xmm1, [rsp+0x10]
000070d6f3dd077b  vmovaps xmm2, [rsp+0x20]
000070d6f3dd0781  vmovaps xmm3, [rsp+0x30]
000070d6f3dd0787  vmovaps xmm4, [rsp+0x40]
000070d6f3dd078d  vmovaps xmm5, [rsp+0x50]
000070d6f3dd0793  vmovaps xmm6, [rsp+0x60]
000070d6f3dd0799  vmovaps xmm7, [rsp+0x70]
000070d6f3dd079f  vmovaps xmm8, [rsp+0x80]
000070d6f3dd07a8  vmovaps xmm9, [rsp+0x90]
000070d6f3dd07b1  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd07ba  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd07c3  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd07cc  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd07d5  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd07de  add rsp, 0xF0
000070d6f3dd07e5  pop r11
000070d6f3dd07e7  pop r10
000070d6f3dd07e9  pop r9
000070d6f3dd07eb  pop r8
000070d6f3dd07ed  pop rsi
000070d6f3dd07ee  pop rdi
000070d6f3dd07ef  pop rdx
000070d6f3dd07f0  pop rcx
000070d6f3dd07f1  pop rax
000070d6f3dd07f2  add rsp, 0x08
000070d6f3dd07f6  jmp 0x000070D6F3DCF7B8
000070d6f3dd07fb  sub rsp, 0x08
000070d6f3dd07ff  push rax
000070d6f3dd0800  push rcx
000070d6f3dd0801  push rdx
000070d6f3dd0802  push rdi
000070d6f3dd0803  push rsi
000070d6f3dd0804  push r8
000070d6f3dd0806  push r9
000070d6f3dd0808  push r10
000070d6f3dd080a  push r11
000070d6f3dd080c  sub rsp, 0xF0
000070d6f3dd0813  vmovaps [rsp], xmm0
000070d6f3dd0818  vmovaps [rsp+0x10], xmm1
000070d6f3dd081e  vmovaps [rsp+0x20], xmm2
000070d6f3dd0824  vmovaps [rsp+0x30], xmm3
000070d6f3dd082a  vmovaps [rsp+0x40], xmm4
000070d6f3dd0830  vmovaps [rsp+0x50], xmm5
000070d6f3dd0836  vmovaps [rsp+0x60], xmm6
000070d6f3dd083c  vmovaps [rsp+0x70], xmm7
000070d6f3dd0842  vmovaps [rsp+0x80], xmm8
000070d6f3dd084b  vmovaps [rsp+0x90], xmm9
000070d6f3dd0854  vmovaps [rsp+0xA0], xmm10
000070d6f3dd085d  vmovaps [rsp+0xB0], xmm11
000070d6f3dd0866  vmovaps [rsp+0xC0], xmm12
000070d6f3dd086f  vmovaps [rsp+0xD0], xmm13
000070d6f3dd0878  vmovaps [rsp+0xE0], xmm14
000070d6f3dd0881  sub rsp, 0x40
000070d6f3dd0885  lea rdi, [rsp]
000070d6f3dd0889  lea rsi, [rsp+0x10]
000070d6f3dd088e  lea rdx, [rsp+0x20]
000070d6f3dd0893  lea rcx, [rsp+0x30]
000070d6f3dd0898  mov r8d, 0x00
000070d6f3dd089e  lea r9, [r15+0x3A8]
000070d6f3dd08a5  movaps [rdi], xmm15
000070d6f3dd08a9  movaps [rsi], xmm1
000070d6f3dd08ac  movaps [rdx], xmm9
000070d6f3dd08b0  movaps [rcx], xmm13
000070d6f3dd08b4  mov rax, 0x61D08D40EA50
000070d6f3dd08be  call rax
000070d6f3dd08c0  movaps xmm15, [rsp]
000070d6f3dd08c5  add rsp, 0x40
000070d6f3dd08c9  vmovaps xmm0, [rsp]
000070d6f3dd08ce  vmovaps xmm1, [rsp+0x10]
000070d6f3dd08d4  vmovaps xmm2, [rsp+0x20]
000070d6f3dd08da  vmovaps xmm3, [rsp+0x30]
000070d6f3dd08e0  vmovaps xmm4, [rsp+0x40]
000070d6f3dd08e6  vmovaps xmm5, [rsp+0x50]
000070d6f3dd08ec  vmovaps xmm6, [rsp+0x60]
000070d6f3dd08f2  vmovaps xmm7, [rsp+0x70]
000070d6f3dd08f8  vmovaps xmm8, [rsp+0x80]
000070d6f3dd0901  vmovaps xmm9, [rsp+0x90]
000070d6f3dd090a  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd0913  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd091c  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd0925  vmovaps xmm13, [rsp+0xD0]
000070d6f3dd092e  vmovaps xmm14, [rsp+0xE0]
000070d6f3dd0937  add rsp, 0xF0
000070d6f3dd093e  pop r11
000070d6f3dd0940  pop r10
000070d6f3dd0942  pop r9
000070d6f3dd0944  pop r8
000070d6f3dd0946  pop rsi
000070d6f3dd0947  pop rdi
000070d6f3dd0948  pop rdx
000070d6f3dd0949  pop rcx
000070d6f3dd094a  pop rax
000070d6f3dd094b  add rsp, 0x08
000070d6f3dd094f  jmp 0x000070D6F3DCF91A
000070d6f3dd0954  sub rsp, 0x08
000070d6f3dd0958  push rax
000070d6f3dd0959  push rcx
000070d6f3dd095a  push rdx
000070d6f3dd095b  push rdi
000070d6f3dd095c  push rsi
000070d6f3dd095d  push r8
000070d6f3dd095f  push r9
000070d6f3dd0961  push r10
000070d6f3dd0963  push r11
000070d6f3dd0965  sub rsp, 0xF0
000070d6f3dd096c  vmovaps [rsp], xmm0
000070d6f3dd0971  vmovaps [rsp+0x10], xmm1
000070d6f3dd0977  vmovaps [rsp+0x20], xmm2
000070d6f3dd097d  vmovaps [rsp+0x30], xmm3
000070d6f3dd0983  vmovaps [rsp+0x40], xmm4
000070d6f3dd0989  vmovaps [rsp+0x50], xmm5
000070d6f3dd098f  vmovaps [rsp+0x60], xmm6
000070d6f3dd0995  vmovaps [rsp+0x70], xmm7
000070d6f3dd099b  vmovaps [rsp+0x80], xmm8
000070d6f3dd09a4  vmovaps [rsp+0x90], xmm10
000070d6f3dd09ad  vmovaps [rsp+0xA0], xmm11
000070d6f3dd09b6  vmovaps [rsp+0xB0], xmm12
000070d6f3dd09bf  vmovaps [rsp+0xC0], xmm13
000070d6f3dd09c8  vmovaps [rsp+0xD0], xmm14
000070d6f3dd09d1  vmovaps [rsp+0xE0], xmm15
000070d6f3dd09da  sub rsp, 0x40
000070d6f3dd09de  lea rdi, [rsp]
000070d6f3dd09e2  lea rsi, [rsp+0x10]
000070d6f3dd09e7  lea rdx, [rsp+0x20]
000070d6f3dd09ec  lea rcx, [rsp+0x30]
000070d6f3dd09f1  mov r8d, 0x00
000070d6f3dd09f7  lea r9, [r15+0x3A8]
000070d6f3dd09fe  movaps [rdi], xmm9
000070d6f3dd0a02  movaps [rsi], xmm14
000070d6f3dd0a06  movaps [rdx], xmm13
000070d6f3dd0a0a  movaps [rcx], xmm1
000070d6f3dd0a0d  mov rax, 0x61D08D40EA50
000070d6f3dd0a17  call rax
000070d6f3dd0a19  movaps xmm9, [rsp]
000070d6f3dd0a1e  add rsp, 0x40
000070d6f3dd0a22  vmovaps xmm0, [rsp]
000070d6f3dd0a27  vmovaps xmm1, [rsp+0x10]
000070d6f3dd0a2d  vmovaps xmm2, [rsp+0x20]
000070d6f3dd0a33  vmovaps xmm3, [rsp+0x30]
000070d6f3dd0a39  vmovaps xmm4, [rsp+0x40]
000070d6f3dd0a3f  vmovaps xmm5, [rsp+0x50]
000070d6f3dd0a45  vmovaps xmm6, [rsp+0x60]
000070d6f3dd0a4b  vmovaps xmm7, [rsp+0x70]
000070d6f3dd0a51  vmovaps xmm8, [rsp+0x80]
000070d6f3dd0a5a  vmovaps xmm10, [rsp+0x90]
000070d6f3dd0a63  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd0a6c  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd0a75  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd0a7e  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd0a87  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd0a90  add rsp, 0xF0
000070d6f3dd0a97  pop r11
000070d6f3dd0a99  pop r10
000070d6f3dd0a9b  pop r9
000070d6f3dd0a9d  pop r8
000070d6f3dd0a9f  pop rsi
000070d6f3dd0aa0  pop rdi
000070d6f3dd0aa1  pop rdx
000070d6f3dd0aa2  pop rcx
000070d6f3dd0aa3  pop rax
000070d6f3dd0aa4  add rsp, 0x08
000070d6f3dd0aa8  jmp 0x000070D6F3DCF955
000070d6f3dd0aad  sub rsp, 0x08
000070d6f3dd0ab1  push rax
000070d6f3dd0ab2  push rcx
000070d6f3dd0ab3  push rdx
000070d6f3dd0ab4  push rdi
000070d6f3dd0ab5  push rsi
000070d6f3dd0ab6  push r8
000070d6f3dd0ab8  push r9
000070d6f3dd0aba  push r10
000070d6f3dd0abc  push r11
000070d6f3dd0abe  sub rsp, 0xF0
000070d6f3dd0ac5  vmovaps [rsp], xmm0
000070d6f3dd0aca  vmovaps [rsp+0x10], xmm1
000070d6f3dd0ad0  vmovaps [rsp+0x20], xmm2
000070d6f3dd0ad6  vmovaps [rsp+0x30], xmm3
000070d6f3dd0adc  vmovaps [rsp+0x40], xmm4
000070d6f3dd0ae2  vmovaps [rsp+0x50], xmm5
000070d6f3dd0ae8  vmovaps [rsp+0x60], xmm6
000070d6f3dd0aee  vmovaps [rsp+0x70], xmm7
000070d6f3dd0af4  vmovaps [rsp+0x80], xmm8
000070d6f3dd0afd  vmovaps [rsp+0x90], xmm9
000070d6f3dd0b06  vmovaps [rsp+0xA0], xmm10
000070d6f3dd0b0f  vmovaps [rsp+0xB0], xmm11
000070d6f3dd0b18  vmovaps [rsp+0xC0], xmm12
000070d6f3dd0b21  vmovaps [rsp+0xD0], xmm13
000070d6f3dd0b2a  vmovaps [rsp+0xE0], xmm15
000070d6f3dd0b33  sub rsp, 0x40
000070d6f3dd0b37  lea rdi, [rsp]
000070d6f3dd0b3b  lea rsi, [rsp+0x10]
000070d6f3dd0b40  lea rdx, [rsp+0x20]
000070d6f3dd0b45  lea rcx, [rsp+0x30]
000070d6f3dd0b4a  mov r8d, 0x00
000070d6f3dd0b50  lea r9, [r15+0x3A8]
000070d6f3dd0b57  movaps [rdi], xmm14
000070d6f3dd0b5b  movaps [rsi], xmm15
000070d6f3dd0b5f  movaps [rdx], xmm8
000070d6f3dd0b63  movaps [rcx], xmm1
000070d6f3dd0b66  mov rax, 0x61D08D40EA50
000070d6f3dd0b70  call rax
000070d6f3dd0b72  movaps xmm14, [rsp]
000070d6f3dd0b77  add rsp, 0x40
000070d6f3dd0b7b  vmovaps xmm0, [rsp]
000070d6f3dd0b80  vmovaps xmm1, [rsp+0x10]
000070d6f3dd0b86  vmovaps xmm2, [rsp+0x20]
000070d6f3dd0b8c  vmovaps xmm3, [rsp+0x30]
000070d6f3dd0b92  vmovaps xmm4, [rsp+0x40]
000070d6f3dd0b98  vmovaps xmm5, [rsp+0x50]
000070d6f3dd0b9e  vmovaps xmm6, [rsp+0x60]
000070d6f3dd0ba4  vmovaps xmm7, [rsp+0x70]
000070d6f3dd0baa  vmovaps xmm8, [rsp+0x80]
000070d6f3dd0bb3  vmovaps xmm9, [rsp+0x90]
000070d6f3dd0bbc  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd0bc5  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd0bce  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd0bd7  vmovaps xmm13, [rsp+0xD0]
000070d6f3dd0be0  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd0be9  add rsp, 0xF0
000070d6f3dd0bf0  pop r11
000070d6f3dd0bf2  pop r10
000070d6f3dd0bf4  pop r9
000070d6f3dd0bf6  pop r8
000070d6f3dd0bf8  pop rsi
000070d6f3dd0bf9  pop rdi
000070d6f3dd0bfa  pop rdx
000070d6f3dd0bfb  pop rcx
000070d6f3dd0bfc  pop rax
000070d6f3dd0bfd  add rsp, 0x08
000070d6f3dd0c01  jmp 0x000070D6F3DCF984
000070d6f3dd0c06  sub rsp, 0x08
000070d6f3dd0c0a  push rax
000070d6f3dd0c0b  push rcx
000070d6f3dd0c0c  push rdx
000070d6f3dd0c0d  push rdi
000070d6f3dd0c0e  push rsi
000070d6f3dd0c0f  push r8
000070d6f3dd0c11  push r9
000070d6f3dd0c13  push r10
000070d6f3dd0c15  push r11
000070d6f3dd0c17  sub rsp, 0xF0
000070d6f3dd0c1e  vmovaps [rsp], xmm0
000070d6f3dd0c23  vmovaps [rsp+0x10], xmm1
000070d6f3dd0c29  vmovaps [rsp+0x20], xmm2
000070d6f3dd0c2f  vmovaps [rsp+0x30], xmm3
000070d6f3dd0c35  vmovaps [rsp+0x40], xmm4
000070d6f3dd0c3b  vmovaps [rsp+0x50], xmm5
000070d6f3dd0c41  vmovaps [rsp+0x60], xmm6
000070d6f3dd0c47  vmovaps [rsp+0x70], xmm7
000070d6f3dd0c4d  vmovaps [rsp+0x80], xmm8
000070d6f3dd0c56  vmovaps [rsp+0x90], xmm9
000070d6f3dd0c5f  vmovaps [rsp+0xA0], xmm10
000070d6f3dd0c68  vmovaps [rsp+0xB0], xmm11
000070d6f3dd0c71  vmovaps [rsp+0xC0], xmm12
000070d6f3dd0c7a  vmovaps [rsp+0xD0], xmm13
000070d6f3dd0c83  vmovaps [rsp+0xE0], xmm14
000070d6f3dd0c8c  sub rsp, 0x40
000070d6f3dd0c90  lea rdi, [rsp]
000070d6f3dd0c94  lea rsi, [rsp+0x10]
000070d6f3dd0c99  lea rdx, [rsp+0x20]
000070d6f3dd0c9e  lea rcx, [rsp+0x30]
000070d6f3dd0ca3  mov r8d, 0x00
000070d6f3dd0ca9  lea r9, [r15+0x3A8]
000070d6f3dd0cb0  movaps [rdi], xmm15
000070d6f3dd0cb4  movaps [rsi], xmm12
000070d6f3dd0cb8  movaps [rdx], xmm13
000070d6f3dd0cbc  movaps [rcx], xmm1
000070d6f3dd0cbf  mov rax, 0x61D08D40EA50
000070d6f3dd0cc9  call rax
000070d6f3dd0ccb  movaps xmm15, [rsp]
000070d6f3dd0cd0  add rsp, 0x40
000070d6f3dd0cd4  vmovaps xmm0, [rsp]
000070d6f3dd0cd9  vmovaps xmm1, [rsp+0x10]
000070d6f3dd0cdf  vmovaps xmm2, [rsp+0x20]
000070d6f3dd0ce5  vmovaps xmm3, [rsp+0x30]
000070d6f3dd0ceb  vmovaps xmm4, [rsp+0x40]
000070d6f3dd0cf1  vmovaps xmm5, [rsp+0x50]
000070d6f3dd0cf7  vmovaps xmm6, [rsp+0x60]
000070d6f3dd0cfd  vmovaps xmm7, [rsp+0x70]
000070d6f3dd0d03  vmovaps xmm8, [rsp+0x80]
000070d6f3dd0d0c  vmovaps xmm9, [rsp+0x90]
000070d6f3dd0d15  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd0d1e  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd0d27  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd0d30  vmovaps xmm13, [rsp+0xD0]
000070d6f3dd0d39  vmovaps xmm14, [rsp+0xE0]
000070d6f3dd0d42  add rsp, 0xF0
000070d6f3dd0d49  pop r11
000070d6f3dd0d4b  pop r10
000070d6f3dd0d4d  pop r9
000070d6f3dd0d4f  pop r8
000070d6f3dd0d51  pop rsi
000070d6f3dd0d52  pop rdi
000070d6f3dd0d53  pop rdx
000070d6f3dd0d54  pop rcx
000070d6f3dd0d55  pop rax
000070d6f3dd0d56  add rsp, 0x08
000070d6f3dd0d5a  jmp 0x000070D6F3DCF9D1
000070d6f3dd0d5f  sub rsp, 0x08
000070d6f3dd0d63  push rax
000070d6f3dd0d64  push rcx
000070d6f3dd0d65  push rdx
000070d6f3dd0d66  push rdi
000070d6f3dd0d67  push rsi
000070d6f3dd0d68  push r8
000070d6f3dd0d6a  push r9
000070d6f3dd0d6c  push r10
000070d6f3dd0d6e  push r11
000070d6f3dd0d70  sub rsp, 0xF0
000070d6f3dd0d77  vmovaps [rsp], xmm0
000070d6f3dd0d7c  vmovaps [rsp+0x10], xmm1
000070d6f3dd0d82  vmovaps [rsp+0x20], xmm2
000070d6f3dd0d88  vmovaps [rsp+0x30], xmm3
000070d6f3dd0d8e  vmovaps [rsp+0x40], xmm4
000070d6f3dd0d94  vmovaps [rsp+0x50], xmm5
000070d6f3dd0d9a  vmovaps [rsp+0x60], xmm6
000070d6f3dd0da0  vmovaps [rsp+0x70], xmm7
000070d6f3dd0da6  vmovaps [rsp+0x80], xmm8
000070d6f3dd0daf  vmovaps [rsp+0x90], xmm9
000070d6f3dd0db8  vmovaps [rsp+0xA0], xmm10
000070d6f3dd0dc1  vmovaps [rsp+0xB0], xmm11
000070d6f3dd0dca  vmovaps [rsp+0xC0], xmm12
000070d6f3dd0dd3  vmovaps [rsp+0xD0], xmm13
000070d6f3dd0ddc  vmovaps [rsp+0xE0], xmm14
000070d6f3dd0de5  sub rsp, 0x40
000070d6f3dd0de9  lea rdi, [rsp]
000070d6f3dd0ded  lea rsi, [rsp+0x10]
000070d6f3dd0df2  lea rdx, [rsp+0x20]
000070d6f3dd0df7  lea rcx, [rsp+0x30]
000070d6f3dd0dfc  mov r8d, 0x00
000070d6f3dd0e02  lea r9, [r15+0x3A8]
000070d6f3dd0e09  movaps [rdi], xmm15
000070d6f3dd0e0d  movaps [rsi], xmm3
000070d6f3dd0e10  movaps [rdx], xmm1
000070d6f3dd0e13  movaps [rcx], xmm8
000070d6f3dd0e17  mov rax, 0x61D08D40EA50
000070d6f3dd0e21  call rax
000070d6f3dd0e23  movaps xmm15, [rsp]
000070d6f3dd0e28  add rsp, 0x40
000070d6f3dd0e2c  vmovaps xmm0, [rsp]
000070d6f3dd0e31  vmovaps xmm1, [rsp+0x10]
000070d6f3dd0e37  vmovaps xmm2, [rsp+0x20]
000070d6f3dd0e3d  vmovaps xmm3, [rsp+0x30]
000070d6f3dd0e43  vmovaps xmm4, [rsp+0x40]
000070d6f3dd0e49  vmovaps xmm5, [rsp+0x50]
000070d6f3dd0e4f  vmovaps xmm6, [rsp+0x60]
000070d6f3dd0e55  vmovaps xmm7, [rsp+0x70]
000070d6f3dd0e5b  vmovaps xmm8, [rsp+0x80]
000070d6f3dd0e64  vmovaps xmm9, [rsp+0x90]
000070d6f3dd0e6d  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd0e76  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd0e7f  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd0e88  vmovaps xmm13, [rsp+0xD0]
000070d6f3dd0e91  vmovaps xmm14, [rsp+0xE0]
000070d6f3dd0e9a  add rsp, 0xF0
000070d6f3dd0ea1  pop r11
000070d6f3dd0ea3  pop r10
000070d6f3dd0ea5  pop r9
000070d6f3dd0ea7  pop r8
000070d6f3dd0ea9  pop rsi
000070d6f3dd0eaa  pop rdi
000070d6f3dd0eab  pop rdx
000070d6f3dd0eac  pop rcx
000070d6f3dd0ead  pop rax
000070d6f3dd0eae  add rsp, 0x08
000070d6f3dd0eb2  jmp 0x000070D6F3DCFA82
000070d6f3dd0eb7  sub rsp, 0x08
000070d6f3dd0ebb  push rax
000070d6f3dd0ebc  push rcx
000070d6f3dd0ebd  push rdx
000070d6f3dd0ebe  push rdi
000070d6f3dd0ebf  push rsi
000070d6f3dd0ec0  push r8
000070d6f3dd0ec2  push r9
000070d6f3dd0ec4  push r10
000070d6f3dd0ec6  push r11
000070d6f3dd0ec8  sub rsp, 0xF0
000070d6f3dd0ecf  vmovaps [rsp], xmm0
000070d6f3dd0ed4  vmovaps [rsp+0x10], xmm1
000070d6f3dd0eda  vmovaps [rsp+0x20], xmm2
000070d6f3dd0ee0  vmovaps [rsp+0x30], xmm3
000070d6f3dd0ee6  vmovaps [rsp+0x40], xmm4
000070d6f3dd0eec  vmovaps [rsp+0x50], xmm5
000070d6f3dd0ef2  vmovaps [rsp+0x60], xmm6
000070d6f3dd0ef8  vmovaps [rsp+0x70], xmm7
000070d6f3dd0efe  vmovaps [rsp+0x80], xmm9
000070d6f3dd0f07  vmovaps [rsp+0x90], xmm10
000070d6f3dd0f10  vmovaps [rsp+0xA0], xmm11
000070d6f3dd0f19  vmovaps [rsp+0xB0], xmm12
000070d6f3dd0f22  vmovaps [rsp+0xC0], xmm13
000070d6f3dd0f2b  vmovaps [rsp+0xD0], xmm14
000070d6f3dd0f34  vmovaps [rsp+0xE0], xmm15
000070d6f3dd0f3d  sub rsp, 0x40
000070d6f3dd0f41  lea rdi, [rsp]
000070d6f3dd0f45  lea rsi, [rsp+0x10]
000070d6f3dd0f4a  lea rdx, [rsp+0x20]
000070d6f3dd0f4f  lea rcx, [rsp+0x30]
000070d6f3dd0f54  mov r8d, 0x00
000070d6f3dd0f5a  lea r9, [r15+0x3A8]
000070d6f3dd0f61  movaps [rdi], xmm8
000070d6f3dd0f65  movaps [rsi], xmm9
000070d6f3dd0f69  movaps [rdx], xmm5
000070d6f3dd0f6c  movaps [rcx], xmm1
000070d6f3dd0f6f  mov rax, 0x61D08D40EA50
000070d6f3dd0f79  call rax
000070d6f3dd0f7b  movaps xmm8, [rsp]
000070d6f3dd0f80  add rsp, 0x40
000070d6f3dd0f84  vmovaps xmm0, [rsp]
000070d6f3dd0f89  vmovaps xmm1, [rsp+0x10]
000070d6f3dd0f8f  vmovaps xmm2, [rsp+0x20]
000070d6f3dd0f95  vmovaps xmm3, [rsp+0x30]
000070d6f3dd0f9b  vmovaps xmm4, [rsp+0x40]
000070d6f3dd0fa1  vmovaps xmm5, [rsp+0x50]
000070d6f3dd0fa7  vmovaps xmm6, [rsp+0x60]
000070d6f3dd0fad  vmovaps xmm7, [rsp+0x70]
000070d6f3dd0fb3  vmovaps xmm9, [rsp+0x80]
000070d6f3dd0fbc  vmovaps xmm10, [rsp+0x90]
000070d6f3dd0fc5  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd0fce  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd0fd7  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd0fe0  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd0fe9  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd0ff2  add rsp, 0xF0
000070d6f3dd0ff9  pop r11
000070d6f3dd0ffb  pop r10
000070d6f3dd0ffd  pop r9
000070d6f3dd0fff  pop r8
000070d6f3dd1001  pop rsi
000070d6f3dd1002  pop rdi
000070d6f3dd1003  pop rdx
000070d6f3dd1004  pop rcx
000070d6f3dd1005  pop rax
000070d6f3dd1006  add rsp, 0x08
000070d6f3dd100a  jmp 0x000070D6F3DCFAAB
000070d6f3dd100f  sub rsp, 0x08
000070d6f3dd1013  push rax
000070d6f3dd1014  push rcx
000070d6f3dd1015  push rdx
000070d6f3dd1016  push rdi
000070d6f3dd1017  push rsi
000070d6f3dd1018  push r8
000070d6f3dd101a  push r9
000070d6f3dd101c  push r10
000070d6f3dd101e  push r11
000070d6f3dd1020  sub rsp, 0xF0
000070d6f3dd1027  vmovaps [rsp], xmm0
000070d6f3dd102c  vmovaps [rsp+0x10], xmm1
000070d6f3dd1032  vmovaps [rsp+0x20], xmm2
000070d6f3dd1038  vmovaps [rsp+0x30], xmm3
000070d6f3dd103e  vmovaps [rsp+0x40], xmm4
000070d6f3dd1044  vmovaps [rsp+0x50], xmm6
000070d6f3dd104a  vmovaps [rsp+0x60], xmm7
000070d6f3dd1050  vmovaps [rsp+0x70], xmm8
000070d6f3dd1056  vmovaps [rsp+0x80], xmm9
000070d6f3dd105f  vmovaps [rsp+0x90], xmm10
000070d6f3dd1068  vmovaps [rsp+0xA0], xmm11
000070d6f3dd1071  vmovaps [rsp+0xB0], xmm12
000070d6f3dd107a  vmovaps [rsp+0xC0], xmm13
000070d6f3dd1083  vmovaps [rsp+0xD0], xmm14
000070d6f3dd108c  vmovaps [rsp+0xE0], xmm15
000070d6f3dd1095  sub rsp, 0x40
000070d6f3dd1099  lea rdi, [rsp]
000070d6f3dd109d  lea rsi, [rsp+0x10]
000070d6f3dd10a2  lea rdx, [rsp+0x20]
000070d6f3dd10a7  lea rcx, [rsp+0x30]
000070d6f3dd10ac  mov r8d, 0x00
000070d6f3dd10b2  lea r9, [r15+0x3A8]
000070d6f3dd10b9  movaps [rdi], xmm5
000070d6f3dd10bc  movaps [rsi], xmm14
000070d6f3dd10c0  movaps [rdx], xmm9
000070d6f3dd10c4  movaps [rcx], xmm1
000070d6f3dd10c7  mov rax, 0x61D08D40EA50
000070d6f3dd10d1  call rax
000070d6f3dd10d3  movaps xmm5, [rsp]
000070d6f3dd10d7  add rsp, 0x40
000070d6f3dd10db  vmovaps xmm0, [rsp]
000070d6f3dd10e0  vmovaps xmm1, [rsp+0x10]
000070d6f3dd10e6  vmovaps xmm2, [rsp+0x20]
000070d6f3dd10ec  vmovaps xmm3, [rsp+0x30]
000070d6f3dd10f2  vmovaps xmm4, [rsp+0x40]
000070d6f3dd10f8  vmovaps xmm6, [rsp+0x50]
000070d6f3dd10fe  vmovaps xmm7, [rsp+0x60]
000070d6f3dd1104  vmovaps xmm8, [rsp+0x70]
000070d6f3dd110a  vmovaps xmm9, [rsp+0x80]
000070d6f3dd1113  vmovaps xmm10, [rsp+0x90]
000070d6f3dd111c  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd1125  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd112e  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd1137  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd1140  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd1149  add rsp, 0xF0
000070d6f3dd1150  pop r11
000070d6f3dd1152  pop r10
000070d6f3dd1154  pop r9
000070d6f3dd1156  pop r8
000070d6f3dd1158  pop rsi
000070d6f3dd1159  pop rdi
000070d6f3dd115a  pop rdx
000070d6f3dd115b  pop rcx
000070d6f3dd115c  pop rax
000070d6f3dd115d  add rsp, 0x08
000070d6f3dd1161  jmp 0x000070D6F3DCFADF
000070d6f3dd1166  sub rsp, 0x08
000070d6f3dd116a  push rax
000070d6f3dd116b  push rcx
000070d6f3dd116c  push rdx
000070d6f3dd116d  push rdi
000070d6f3dd116e  push rsi
000070d6f3dd116f  push r8
000070d6f3dd1171  push r9
000070d6f3dd1173  push r10
000070d6f3dd1175  push r11
000070d6f3dd1177  sub rsp, 0xF0
000070d6f3dd117e  vmovaps [rsp], xmm0
000070d6f3dd1183  vmovaps [rsp+0x10], xmm1
000070d6f3dd1189  vmovaps [rsp+0x20], xmm2
000070d6f3dd118f  vmovaps [rsp+0x30], xmm3
000070d6f3dd1195  vmovaps [rsp+0x40], xmm4
000070d6f3dd119b  vmovaps [rsp+0x50], xmm5
000070d6f3dd11a1  vmovaps [rsp+0x60], xmm6
000070d6f3dd11a7  vmovaps [rsp+0x70], xmm7
000070d6f3dd11ad  vmovaps [rsp+0x80], xmm8
000070d6f3dd11b6  vmovaps [rsp+0x90], xmm10
000070d6f3dd11bf  vmovaps [rsp+0xA0], xmm11
000070d6f3dd11c8  vmovaps [rsp+0xB0], xmm12
000070d6f3dd11d1  vmovaps [rsp+0xC0], xmm13
000070d6f3dd11da  vmovaps [rsp+0xD0], xmm14
000070d6f3dd11e3  vmovaps [rsp+0xE0], xmm15
000070d6f3dd11ec  sub rsp, 0x40
000070d6f3dd11f0  lea rdi, [rsp]
000070d6f3dd11f4  lea rsi, [rsp+0x10]
000070d6f3dd11f9  lea rdx, [rsp+0x20]
000070d6f3dd11fe  lea rcx, [rsp+0x30]
000070d6f3dd1203  mov r8d, 0x00
000070d6f3dd1209  lea r9, [r15+0x3A8]
000070d6f3dd1210  movaps [rdi], xmm9
000070d6f3dd1214  movaps [rsi], xmm14
000070d6f3dd1218  movaps [rdx], xmm4
000070d6f3dd121b  movaps [rcx], xmm1
000070d6f3dd121e  mov rax, 0x61D08D40EA50
000070d6f3dd1228  call rax
000070d6f3dd122a  movaps xmm9, [rsp]
000070d6f3dd122f  add rsp, 0x40
000070d6f3dd1233  vmovaps xmm0, [rsp]
000070d6f3dd1238  vmovaps xmm1, [rsp+0x10]
000070d6f3dd123e  vmovaps xmm2, [rsp+0x20]
000070d6f3dd1244  vmovaps xmm3, [rsp+0x30]
000070d6f3dd124a  vmovaps xmm4, [rsp+0x40]
000070d6f3dd1250  vmovaps xmm5, [rsp+0x50]
000070d6f3dd1256  vmovaps xmm6, [rsp+0x60]
000070d6f3dd125c  vmovaps xmm7, [rsp+0x70]
000070d6f3dd1262  vmovaps xmm8, [rsp+0x80]
000070d6f3dd126b  vmovaps xmm10, [rsp+0x90]
000070d6f3dd1274  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd127d  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd1286  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd128f  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd1298  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd12a1  add rsp, 0xF0
000070d6f3dd12a8  pop r11
000070d6f3dd12aa  pop r10
000070d6f3dd12ac  pop r9
000070d6f3dd12ae  pop r8
000070d6f3dd12b0  pop rsi
000070d6f3dd12b1  pop rdi
000070d6f3dd12b2  pop rdx
000070d6f3dd12b3  pop rcx
000070d6f3dd12b4  pop rax
000070d6f3dd12b5  add rsp, 0x08
000070d6f3dd12b9  jmp 0x000070D6F3DCFB0E
000070d6f3dd12be  sub rsp, 0x08
000070d6f3dd12c2  push rax
000070d6f3dd12c3  push rcx
000070d6f3dd12c4  push rdx
000070d6f3dd12c5  push rdi
000070d6f3dd12c6  push rsi
000070d6f3dd12c7  push r8
000070d6f3dd12c9  push r9
000070d6f3dd12cb  push r10
000070d6f3dd12cd  push r11
000070d6f3dd12cf  sub rsp, 0xF0
000070d6f3dd12d6  vmovaps [rsp], xmm0
000070d6f3dd12db  vmovaps [rsp+0x10], xmm1
000070d6f3dd12e1  vmovaps [rsp+0x20], xmm3
000070d6f3dd12e7  vmovaps [rsp+0x30], xmm4
000070d6f3dd12ed  vmovaps [rsp+0x40], xmm5
000070d6f3dd12f3  vmovaps [rsp+0x50], xmm6
000070d6f3dd12f9  vmovaps [rsp+0x60], xmm7
000070d6f3dd12ff  vmovaps [rsp+0x70], xmm8
000070d6f3dd1305  vmovaps [rsp+0x80], xmm9
000070d6f3dd130e  vmovaps [rsp+0x90], xmm10
000070d6f3dd1317  vmovaps [rsp+0xA0], xmm11
000070d6f3dd1320  vmovaps [rsp+0xB0], xmm12
000070d6f3dd1329  vmovaps [rsp+0xC0], xmm13
000070d6f3dd1332  vmovaps [rsp+0xD0], xmm14
000070d6f3dd133b  vmovaps [rsp+0xE0], xmm15
000070d6f3dd1344  sub rsp, 0x40
000070d6f3dd1348  lea rdi, [rsp]
000070d6f3dd134c  lea rsi, [rsp+0x10]
000070d6f3dd1351  lea rdx, [rsp+0x20]
000070d6f3dd1356  lea rcx, [rsp+0x30]
000070d6f3dd135b  mov r8d, 0x00
000070d6f3dd1361  lea r9, [r15+0x3A8]
000070d6f3dd1368  movaps [rdi], xmm2
000070d6f3dd136b  movaps [rsi], xmm8
000070d6f3dd136f  movaps [rdx], xmm13
000070d6f3dd1373  movaps [rcx], xmm3
000070d6f3dd1376  mov rax, 0x61D08D40EA50
000070d6f3dd1380  call rax
000070d6f3dd1382  movaps xmm2, [rsp]
000070d6f3dd1386  add rsp, 0x40
000070d6f3dd138a  vmovaps xmm0, [rsp]
000070d6f3dd138f  vmovaps xmm1, [rsp+0x10]
000070d6f3dd1395  vmovaps xmm3, [rsp+0x20]
000070d6f3dd139b  vmovaps xmm4, [rsp+0x30]
000070d6f3dd13a1  vmovaps xmm5, [rsp+0x40]
000070d6f3dd13a7  vmovaps xmm6, [rsp+0x50]
000070d6f3dd13ad  vmovaps xmm7, [rsp+0x60]
000070d6f3dd13b3  vmovaps xmm8, [rsp+0x70]
000070d6f3dd13b9  vmovaps xmm9, [rsp+0x80]
000070d6f3dd13c2  vmovaps xmm10, [rsp+0x90]
000070d6f3dd13cb  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd13d4  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd13dd  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd13e6  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd13ef  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd13f8  add rsp, 0xF0
000070d6f3dd13ff  pop r11
000070d6f3dd1401  pop r10
000070d6f3dd1403  pop r9
000070d6f3dd1405  pop r8
000070d6f3dd1407  pop rsi
000070d6f3dd1408  pop rdi
000070d6f3dd1409  pop rdx
000070d6f3dd140a  pop rcx
000070d6f3dd140b  pop rax
000070d6f3dd140c  add rsp, 0x08
000070d6f3dd1410  jmp 0x000070D6F3DCFB8C
000070d6f3dd1415  sub rsp, 0x08
000070d6f3dd1419  push rax
000070d6f3dd141a  push rcx
000070d6f3dd141b  push rdx
000070d6f3dd141c  push rdi
000070d6f3dd141d  push rsi
000070d6f3dd141e  push r8
000070d6f3dd1420  push r9
000070d6f3dd1422  push r10
000070d6f3dd1424  push r11
000070d6f3dd1426  sub rsp, 0xF0
000070d6f3dd142d  vmovaps [rsp], xmm0
000070d6f3dd1432  vmovaps [rsp+0x10], xmm1
000070d6f3dd1438  vmovaps [rsp+0x20], xmm2
000070d6f3dd143e  vmovaps [rsp+0x30], xmm3
000070d6f3dd1444  vmovaps [rsp+0x40], xmm4
000070d6f3dd144a  vmovaps [rsp+0x50], xmm5
000070d6f3dd1450  vmovaps [rsp+0x60], xmm6
000070d6f3dd1456  vmovaps [rsp+0x70], xmm7
000070d6f3dd145c  vmovaps [rsp+0x80], xmm9
000070d6f3dd1465  vmovaps [rsp+0x90], xmm10
000070d6f3dd146e  vmovaps [rsp+0xA0], xmm11
000070d6f3dd1477  vmovaps [rsp+0xB0], xmm12
000070d6f3dd1480  vmovaps [rsp+0xC0], xmm13
000070d6f3dd1489  vmovaps [rsp+0xD0], xmm14
000070d6f3dd1492  vmovaps [rsp+0xE0], xmm15
000070d6f3dd149b  sub rsp, 0x40
000070d6f3dd149f  lea rdi, [rsp]
000070d6f3dd14a3  lea rsi, [rsp+0x10]
000070d6f3dd14a8  lea rdx, [rsp+0x20]
000070d6f3dd14ad  lea rcx, [rsp+0x30]
000070d6f3dd14b2  mov r8d, 0x00
000070d6f3dd14b8  lea r9, [r15+0x3A8]
000070d6f3dd14bf  movaps [rdi], xmm8
000070d6f3dd14c3  movaps [rsi], xmm15
000070d6f3dd14c7  movaps [rdx], xmm13
000070d6f3dd14cb  movaps [rcx], xmm1
000070d6f3dd14ce  mov rax, 0x61D08D40EA50
000070d6f3dd14d8  call rax
000070d6f3dd14da  movaps xmm8, [rsp]
000070d6f3dd14df  add rsp, 0x40
000070d6f3dd14e3  vmovaps xmm0, [rsp]
000070d6f3dd14e8  vmovaps xmm1, [rsp+0x10]
000070d6f3dd14ee  vmovaps xmm2, [rsp+0x20]
000070d6f3dd14f4  vmovaps xmm3, [rsp+0x30]
000070d6f3dd14fa  vmovaps xmm4, [rsp+0x40]
000070d6f3dd1500  vmovaps xmm5, [rsp+0x50]
000070d6f3dd1506  vmovaps xmm6, [rsp+0x60]
000070d6f3dd150c  vmovaps xmm7, [rsp+0x70]
000070d6f3dd1512  vmovaps xmm9, [rsp+0x80]
000070d6f3dd151b  vmovaps xmm10, [rsp+0x90]
000070d6f3dd1524  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd152d  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd1536  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd153f  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd1548  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd1551  add rsp, 0xF0
000070d6f3dd1558  pop r11
000070d6f3dd155a  pop r10
000070d6f3dd155c  pop r9
000070d6f3dd155e  pop r8
000070d6f3dd1560  pop rsi
000070d6f3dd1561  pop rdi
000070d6f3dd1562  pop rdx
000070d6f3dd1563  pop rcx
000070d6f3dd1564  pop rax
000070d6f3dd1565  add rsp, 0x08
000070d6f3dd1569  jmp 0x000070D6F3DCFBBB
000070d6f3dd156e  call 0x000070D6F3BFF430
000070d6f3dd1573  jmp 0x000070D6F3DCFBC8
000070d6f3dd1578  sub rsp, 0x08
000070d6f3dd157c  push rax
000070d6f3dd157d  push rcx
000070d6f3dd157e  push rdx
000070d6f3dd157f  push rdi
000070d6f3dd1580  push rsi
000070d6f3dd1581  push r8
000070d6f3dd1583  push r9
000070d6f3dd1585  push r10
000070d6f3dd1587  push r11
000070d6f3dd1589  sub rsp, 0xF0
000070d6f3dd1590  vmovaps [rsp], xmm0
000070d6f3dd1595  vmovaps [rsp+0x10], xmm1
000070d6f3dd159b  vmovaps [rsp+0x20], xmm2
000070d6f3dd15a1  vmovaps [rsp+0x30], xmm3
000070d6f3dd15a7  vmovaps [rsp+0x40], xmm4
000070d6f3dd15ad  vmovaps [rsp+0x50], xmm5
000070d6f3dd15b3  vmovaps [rsp+0x60], xmm6
000070d6f3dd15b9  vmovaps [rsp+0x70], xmm7
000070d6f3dd15bf  vmovaps [rsp+0x80], xmm8
000070d6f3dd15c8  vmovaps [rsp+0x90], xmm9
000070d6f3dd15d1  vmovaps [rsp+0xA0], xmm10
000070d6f3dd15da  vmovaps [rsp+0xB0], xmm11
000070d6f3dd15e3  vmovaps [rsp+0xC0], xmm12
000070d6f3dd15ec  vmovaps [rsp+0xD0], xmm14
000070d6f3dd15f5  vmovaps [rsp+0xE0], xmm15
000070d6f3dd15fe  sub rsp, 0x40
000070d6f3dd1602  lea rdi, [rsp]
000070d6f3dd1606  lea rsi, [rsp+0x10]
000070d6f3dd160b  lea rdx, [rsp+0x20]
000070d6f3dd1610  lea rcx, [rsp+0x30]
000070d6f3dd1615  mov r8d, 0x00
000070d6f3dd161b  lea r9, [r15+0x3A8]
000070d6f3dd1622  movaps [rdi], xmm13
000070d6f3dd1626  movaps [rsi], xmm5
000070d6f3dd1629  movaps [rdx], xmm11
000070d6f3dd162d  movaps [rcx], xmm15
000070d6f3dd1631  mov rax, 0x61D08D40EA50
000070d6f3dd163b  call rax
000070d6f3dd163d  movaps xmm13, [rsp]
000070d6f3dd1642  add rsp, 0x40
000070d6f3dd1646  vmovaps xmm0, [rsp]
000070d6f3dd164b  vmovaps xmm1, [rsp+0x10]
000070d6f3dd1651  vmovaps xmm2, [rsp+0x20]
000070d6f3dd1657  vmovaps xmm3, [rsp+0x30]
000070d6f3dd165d  vmovaps xmm4, [rsp+0x40]
000070d6f3dd1663  vmovaps xmm5, [rsp+0x50]
000070d6f3dd1669  vmovaps xmm6, [rsp+0x60]
000070d6f3dd166f  vmovaps xmm7, [rsp+0x70]
000070d6f3dd1675  vmovaps xmm8, [rsp+0x80]
000070d6f3dd167e  vmovaps xmm9, [rsp+0x90]
000070d6f3dd1687  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd1690  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd1699  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd16a2  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd16ab  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd16b4  add rsp, 0xF0
000070d6f3dd16bb  pop r11
000070d6f3dd16bd  pop r10
000070d6f3dd16bf  pop r9
000070d6f3dd16c1  pop r8
000070d6f3dd16c3  pop rsi
000070d6f3dd16c4  pop rdi
000070d6f3dd16c5  pop rdx
000070d6f3dd16c6  pop rcx
000070d6f3dd16c7  pop rax
000070d6f3dd16c8  add rsp, 0x08
000070d6f3dd16cc  jmp 0x000070D6F3DCFBF9
000070d6f3dd16d1  sub rsp, 0x08
000070d6f3dd16d5  push rax
000070d6f3dd16d6  push rcx
000070d6f3dd16d7  push rdx
000070d6f3dd16d8  push rdi
000070d6f3dd16d9  push rsi
000070d6f3dd16da  push r8
000070d6f3dd16dc  push r9
000070d6f3dd16de  push r10
000070d6f3dd16e0  push r11
000070d6f3dd16e2  sub rsp, 0xF0
000070d6f3dd16e9  vmovaps [rsp], xmm0
000070d6f3dd16ee  vmovaps [rsp+0x10], xmm1
000070d6f3dd16f4  vmovaps [rsp+0x20], xmm2
000070d6f3dd16fa  vmovaps [rsp+0x30], xmm3
000070d6f3dd1700  vmovaps [rsp+0x40], xmm4
000070d6f3dd1706  vmovaps [rsp+0x50], xmm5
000070d6f3dd170c  vmovaps [rsp+0x60], xmm6
000070d6f3dd1712  vmovaps [rsp+0x70], xmm7
000070d6f3dd1718  vmovaps [rsp+0x80], xmm8
000070d6f3dd1721  vmovaps [rsp+0x90], xmm9
000070d6f3dd172a  vmovaps [rsp+0xA0], xmm10
000070d6f3dd1733  vmovaps [rsp+0xB0], xmm12
000070d6f3dd173c  vmovaps [rsp+0xC0], xmm13
000070d6f3dd1745  vmovaps [rsp+0xD0], xmm14
000070d6f3dd174e  vmovaps [rsp+0xE0], xmm15
000070d6f3dd1757  sub rsp, 0x40
000070d6f3dd175b  lea rdi, [rsp]
000070d6f3dd175f  lea rsi, [rsp+0x10]
000070d6f3dd1764  lea rdx, [rsp+0x20]
000070d6f3dd1769  lea rcx, [rsp+0x30]
000070d6f3dd176e  mov r8d, 0x00
000070d6f3dd1774  lea r9, [r15+0x3A8]
000070d6f3dd177b  movaps [rdi], xmm11
000070d6f3dd177f  movaps [rsi], xmm9
000070d6f3dd1783  movaps [rdx], xmm4
000070d6f3dd1786  movaps [rcx], xmm15
000070d6f3dd178a  mov rax, 0x61D08D40EA50
000070d6f3dd1794  call rax
000070d6f3dd1796  movaps xmm11, [rsp]
000070d6f3dd179b  add rsp, 0x40
000070d6f3dd179f  vmovaps xmm0, [rsp]
000070d6f3dd17a4  vmovaps xmm1, [rsp+0x10]
000070d6f3dd17aa  vmovaps xmm2, [rsp+0x20]
000070d6f3dd17b0  vmovaps xmm3, [rsp+0x30]
000070d6f3dd17b6  vmovaps xmm4, [rsp+0x40]
000070d6f3dd17bc  vmovaps xmm5, [rsp+0x50]
000070d6f3dd17c2  vmovaps xmm6, [rsp+0x60]
000070d6f3dd17c8  vmovaps xmm7, [rsp+0x70]
000070d6f3dd17ce  vmovaps xmm8, [rsp+0x80]
000070d6f3dd17d7  vmovaps xmm9, [rsp+0x90]
000070d6f3dd17e0  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd17e9  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd17f2  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd17fb  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd1804  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd180d  add rsp, 0xF0
000070d6f3dd1814  pop r11
000070d6f3dd1816  pop r10
000070d6f3dd1818  pop r9
000070d6f3dd181a  pop r8
000070d6f3dd181c  pop rsi
000070d6f3dd181d  pop rdi
000070d6f3dd181e  pop rdx
000070d6f3dd181f  pop rcx
000070d6f3dd1820  pop rax
000070d6f3dd1821  add rsp, 0x08
000070d6f3dd1825  jmp 0x000070D6F3DCFC22
000070d6f3dd182a  call 0x000070D6F3C0E760
000070d6f3dd182f  jmp 0x000070D6F3DCFC45
000070d6f3dd1834  call 0x000070D6F3C07890
000070d6f3dd1839  jmp 0x000070D6F3DCFC4F
000070d6f3dd183e  sub rsp, 0x08
000070d6f3dd1842  push rax
000070d6f3dd1843  push rcx
000070d6f3dd1844  push rdx
000070d6f3dd1845  push rdi
000070d6f3dd1846  push rsi
000070d6f3dd1847  push r8
000070d6f3dd1849  push r9
000070d6f3dd184b  push r10
000070d6f3dd184d  push r11
000070d6f3dd184f  sub rsp, 0xF0
000070d6f3dd1856  vmovaps [rsp], xmm0
000070d6f3dd185b  vmovaps [rsp+0x10], xmm1
000070d6f3dd1861  vmovaps [rsp+0x20], xmm2
000070d6f3dd1867  vmovaps [rsp+0x30], xmm3
000070d6f3dd186d  vmovaps [rsp+0x40], xmm5
000070d6f3dd1873  vmovaps [rsp+0x50], xmm6
000070d6f3dd1879  vmovaps [rsp+0x60], xmm7
000070d6f3dd187f  vmovaps [rsp+0x70], xmm8
000070d6f3dd1885  vmovaps [rsp+0x80], xmm9
000070d6f3dd188e  vmovaps [rsp+0x90], xmm10
000070d6f3dd1897  vmovaps [rsp+0xA0], xmm11
000070d6f3dd18a0  vmovaps [rsp+0xB0], xmm12
000070d6f3dd18a9  vmovaps [rsp+0xC0], xmm13
000070d6f3dd18b2  vmovaps [rsp+0xD0], xmm14
000070d6f3dd18bb  vmovaps [rsp+0xE0], xmm15
000070d6f3dd18c4  sub rsp, 0x40
000070d6f3dd18c8  lea rdi, [rsp]
000070d6f3dd18cc  lea rsi, [rsp+0x10]
000070d6f3dd18d1  lea rdx, [rsp+0x20]
000070d6f3dd18d6  lea rcx, [rsp+0x30]
000070d6f3dd18db  mov r8d, 0x00
000070d6f3dd18e1  lea r9, [r15+0x3A8]
000070d6f3dd18e8  movaps [rdi], xmm4
000070d6f3dd18eb  movaps [rsi], xmm2
000070d6f3dd18ee  movaps [rdx], xmm14
000070d6f3dd18f2  movaps [rcx], xmm5
000070d6f3dd18f5  mov rax, 0x61D08D40EA50
000070d6f3dd18ff  call rax
000070d6f3dd1901  movaps xmm4, [rsp]
000070d6f3dd1905  add rsp, 0x40
000070d6f3dd1909  vmovaps xmm0, [rsp]
000070d6f3dd190e  vmovaps xmm1, [rsp+0x10]
000070d6f3dd1914  vmovaps xmm2, [rsp+0x20]
000070d6f3dd191a  vmovaps xmm3, [rsp+0x30]
000070d6f3dd1920  vmovaps xmm5, [rsp+0x40]
000070d6f3dd1926  vmovaps xmm6, [rsp+0x50]
000070d6f3dd192c  vmovaps xmm7, [rsp+0x60]
000070d6f3dd1932  vmovaps xmm8, [rsp+0x70]
000070d6f3dd1938  vmovaps xmm9, [rsp+0x80]
000070d6f3dd1941  vmovaps xmm10, [rsp+0x90]
000070d6f3dd194a  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd1953  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd195c  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd1965  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd196e  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd1977  add rsp, 0xF0
000070d6f3dd197e  pop r11
000070d6f3dd1980  pop r10
000070d6f3dd1982  pop r9
000070d6f3dd1984  pop r8
000070d6f3dd1986  pop rsi
000070d6f3dd1987  pop rdi
000070d6f3dd1988  pop rdx
000070d6f3dd1989  pop rcx
000070d6f3dd198a  pop rax
000070d6f3dd198b  add rsp, 0x08
000070d6f3dd198f  jmp 0x000070D6F3DCFC86
000070d6f3dd1994  sub rsp, 0x08
000070d6f3dd1998  push rax
000070d6f3dd1999  push rcx
000070d6f3dd199a  push rdx
000070d6f3dd199b  push rdi
000070d6f3dd199c  push rsi
000070d6f3dd199d  push r8
000070d6f3dd199f  push r9
000070d6f3dd19a1  push r10
000070d6f3dd19a3  push r11
000070d6f3dd19a5  sub rsp, 0xF0
000070d6f3dd19ac  vmovaps [rsp], xmm0
000070d6f3dd19b1  vmovaps [rsp+0x10], xmm1
000070d6f3dd19b7  vmovaps [rsp+0x20], xmm2
000070d6f3dd19bd  vmovaps [rsp+0x30], xmm3
000070d6f3dd19c3  vmovaps [rsp+0x40], xmm4
000070d6f3dd19c9  vmovaps [rsp+0x50], xmm6
000070d6f3dd19cf  vmovaps [rsp+0x60], xmm7
000070d6f3dd19d5  vmovaps [rsp+0x70], xmm8
000070d6f3dd19db  vmovaps [rsp+0x80], xmm9
000070d6f3dd19e4  vmovaps [rsp+0x90], xmm10
000070d6f3dd19ed  vmovaps [rsp+0xA0], xmm11
000070d6f3dd19f6  vmovaps [rsp+0xB0], xmm12
000070d6f3dd19ff  vmovaps [rsp+0xC0], xmm13
000070d6f3dd1a08  vmovaps [rsp+0xD0], xmm14
000070d6f3dd1a11  vmovaps [rsp+0xE0], xmm15
000070d6f3dd1a1a  sub rsp, 0x40
000070d6f3dd1a1e  lea rdi, [rsp]
000070d6f3dd1a22  lea rsi, [rsp+0x10]
000070d6f3dd1a27  lea rdx, [rsp+0x20]
000070d6f3dd1a2c  lea rcx, [rsp+0x30]
000070d6f3dd1a31  mov r8d, 0x00
000070d6f3dd1a37  lea r9, [r15+0x3A8]
000070d6f3dd1a3e  movaps [rdi], xmm5
000070d6f3dd1a41  movaps [rsi], xmm8
000070d6f3dd1a45  movaps [rdx], xmm7
000070d6f3dd1a48  movaps [rcx], xmm14
000070d6f3dd1a4c  mov rax, 0x61D08D40EA50
000070d6f3dd1a56  call rax
000070d6f3dd1a58  movaps xmm5, [rsp]
000070d6f3dd1a5c  add rsp, 0x40
000070d6f3dd1a60  vmovaps xmm0, [rsp]
000070d6f3dd1a65  vmovaps xmm1, [rsp+0x10]
000070d6f3dd1a6b  vmovaps xmm2, [rsp+0x20]
000070d6f3dd1a71  vmovaps xmm3, [rsp+0x30]
000070d6f3dd1a77  vmovaps xmm4, [rsp+0x40]
000070d6f3dd1a7d  vmovaps xmm6, [rsp+0x50]
000070d6f3dd1a83  vmovaps xmm7, [rsp+0x60]
000070d6f3dd1a89  vmovaps xmm8, [rsp+0x70]
000070d6f3dd1a8f  vmovaps xmm9, [rsp+0x80]
000070d6f3dd1a98  vmovaps xmm10, [rsp+0x90]
000070d6f3dd1aa1  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd1aaa  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd1ab3  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd1abc  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd1ac5  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd1ace  add rsp, 0xF0
000070d6f3dd1ad5  pop r11
000070d6f3dd1ad7  pop r10
000070d6f3dd1ad9  pop r9
000070d6f3dd1adb  pop r8
000070d6f3dd1add  pop rsi
000070d6f3dd1ade  pop rdi
000070d6f3dd1adf  pop rdx
000070d6f3dd1ae0  pop rcx
000070d6f3dd1ae1  pop rax
000070d6f3dd1ae2  add rsp, 0x08
000070d6f3dd1ae6  jmp 0x000070D6F3DCFCAE
000070d6f3dd1aeb  sub rsp, 0x08
000070d6f3dd1aef  push rax
000070d6f3dd1af0  push rcx
000070d6f3dd1af1  push rdx
000070d6f3dd1af2  push rdi
000070d6f3dd1af3  push rsi
000070d6f3dd1af4  push r8
000070d6f3dd1af6  push r9
000070d6f3dd1af8  push r10
000070d6f3dd1afa  push r11
000070d6f3dd1afc  sub rsp, 0xF0
000070d6f3dd1b03  vmovaps [rsp], xmm0
000070d6f3dd1b08  vmovaps [rsp+0x10], xmm1
000070d6f3dd1b0e  vmovaps [rsp+0x20], xmm2
000070d6f3dd1b14  vmovaps [rsp+0x30], xmm3
000070d6f3dd1b1a  vmovaps [rsp+0x40], xmm4
000070d6f3dd1b20  vmovaps [rsp+0x50], xmm5
000070d6f3dd1b26  vmovaps [rsp+0x60], xmm6
000070d6f3dd1b2c  vmovaps [rsp+0x70], xmm7
000070d6f3dd1b32  vmovaps [rsp+0x80], xmm9
000070d6f3dd1b3b  vmovaps [rsp+0x90], xmm10
000070d6f3dd1b44  vmovaps [rsp+0xA0], xmm11
000070d6f3dd1b4d  vmovaps [rsp+0xB0], xmm12
000070d6f3dd1b56  vmovaps [rsp+0xC0], xmm13
000070d6f3dd1b5f  vmovaps [rsp+0xD0], xmm14
000070d6f3dd1b68  vmovaps [rsp+0xE0], xmm15
000070d6f3dd1b71  sub rsp, 0x40
000070d6f3dd1b75  lea rdi, [rsp]
000070d6f3dd1b79  lea rsi, [rsp+0x10]
000070d6f3dd1b7e  lea rdx, [rsp+0x20]
000070d6f3dd1b83  lea rcx, [rsp+0x30]
000070d6f3dd1b88  mov r8d, 0x00
000070d6f3dd1b8e  lea r9, [r15+0x3A8]
000070d6f3dd1b95  movaps [rdi], xmm8
000070d6f3dd1b99  movaps [rsi], xmm13
000070d6f3dd1b9d  movaps [rdx], xmm6
000070d6f3dd1ba0  movaps [rcx], xmm14
000070d6f3dd1ba4  mov rax, 0x61D08D40EA50
000070d6f3dd1bae  call rax
000070d6f3dd1bb0  movaps xmm8, [rsp]
000070d6f3dd1bb5  add rsp, 0x40
000070d6f3dd1bb9  vmovaps xmm0, [rsp]
000070d6f3dd1bbe  vmovaps xmm1, [rsp+0x10]
000070d6f3dd1bc4  vmovaps xmm2, [rsp+0x20]
000070d6f3dd1bca  vmovaps xmm3, [rsp+0x30]
000070d6f3dd1bd0  vmovaps xmm4, [rsp+0x40]
000070d6f3dd1bd6  vmovaps xmm5, [rsp+0x50]
000070d6f3dd1bdc  vmovaps xmm6, [rsp+0x60]
000070d6f3dd1be2  vmovaps xmm7, [rsp+0x70]
000070d6f3dd1be8  vmovaps xmm9, [rsp+0x80]
000070d6f3dd1bf1  vmovaps xmm10, [rsp+0x90]
000070d6f3dd1bfa  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd1c03  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd1c0c  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd1c15  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd1c1e  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd1c27  add rsp, 0xF0
000070d6f3dd1c2e  pop r11
000070d6f3dd1c30  pop r10
000070d6f3dd1c32  pop r9
000070d6f3dd1c34  pop r8
000070d6f3dd1c36  pop rsi
000070d6f3dd1c37  pop rdi
000070d6f3dd1c38  pop rdx
000070d6f3dd1c39  pop rcx
000070d6f3dd1c3a  pop rax
000070d6f3dd1c3b  add rsp, 0x08
000070d6f3dd1c3f  jmp 0x000070D6F3DCFCD7
000070d6f3dd1c44  sub rsp, 0x08
000070d6f3dd1c48  push rax
000070d6f3dd1c49  push rcx
000070d6f3dd1c4a  push rdx
000070d6f3dd1c4b  push rdi
000070d6f3dd1c4c  push rsi
000070d6f3dd1c4d  push r8
000070d6f3dd1c4f  push r9
000070d6f3dd1c51  push r10
000070d6f3dd1c53  push r11
000070d6f3dd1c55  sub rsp, 0xF0
000070d6f3dd1c5c  vmovaps [rsp], xmm0
000070d6f3dd1c61  vmovaps [rsp+0x10], xmm1
000070d6f3dd1c67  vmovaps [rsp+0x20], xmm2
000070d6f3dd1c6d  vmovaps [rsp+0x30], xmm3
000070d6f3dd1c73  vmovaps [rsp+0x40], xmm4
000070d6f3dd1c79  vmovaps [rsp+0x50], xmm5
000070d6f3dd1c7f  vmovaps [rsp+0x60], xmm6
000070d6f3dd1c85  vmovaps [rsp+0x70], xmm7
000070d6f3dd1c8b  vmovaps [rsp+0x80], xmm8
000070d6f3dd1c94  vmovaps [rsp+0x90], xmm9
000070d6f3dd1c9d  vmovaps [rsp+0xA0], xmm10
000070d6f3dd1ca6  vmovaps [rsp+0xB0], xmm11
000070d6f3dd1caf  vmovaps [rsp+0xC0], xmm12
000070d6f3dd1cb8  vmovaps [rsp+0xD0], xmm14
000070d6f3dd1cc1  vmovaps [rsp+0xE0], xmm15
000070d6f3dd1cca  sub rsp, 0x40
000070d6f3dd1cce  lea rdi, [rsp]
000070d6f3dd1cd2  lea rsi, [rsp+0x10]
000070d6f3dd1cd7  lea rdx, [rsp+0x20]
000070d6f3dd1cdc  lea rcx, [rsp+0x30]
000070d6f3dd1ce1  mov r8d, 0x00
000070d6f3dd1ce7  lea r9, [r15+0x3A8]
000070d6f3dd1cee  movaps [rdi], xmm13
000070d6f3dd1cf2  movaps [rsi], xmm11
000070d6f3dd1cf6  movaps [rdx], xmm12
000070d6f3dd1cfa  movaps [rcx], xmm14
000070d6f3dd1cfe  mov rax, 0x61D08D40EA50
000070d6f3dd1d08  call rax
000070d6f3dd1d0a  movaps xmm13, [rsp]
000070d6f3dd1d0f  add rsp, 0x40
000070d6f3dd1d13  vmovaps xmm0, [rsp]
000070d6f3dd1d18  vmovaps xmm1, [rsp+0x10]
000070d6f3dd1d1e  vmovaps xmm2, [rsp+0x20]
000070d6f3dd1d24  vmovaps xmm3, [rsp+0x30]
000070d6f3dd1d2a  vmovaps xmm4, [rsp+0x40]
000070d6f3dd1d30  vmovaps xmm5, [rsp+0x50]
000070d6f3dd1d36  vmovaps xmm6, [rsp+0x60]
000070d6f3dd1d3c  vmovaps xmm7, [rsp+0x70]
000070d6f3dd1d42  vmovaps xmm8, [rsp+0x80]
000070d6f3dd1d4b  vmovaps xmm9, [rsp+0x90]
000070d6f3dd1d54  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd1d5d  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd1d66  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd1d6f  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd1d78  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd1d81  add rsp, 0xF0
000070d6f3dd1d88  pop r11
000070d6f3dd1d8a  pop r10
000070d6f3dd1d8c  pop r9
000070d6f3dd1d8e  pop r8
000070d6f3dd1d90  pop rsi
000070d6f3dd1d91  pop rdi
000070d6f3dd1d92  pop rdx
000070d6f3dd1d93  pop rcx
000070d6f3dd1d94  pop rax
000070d6f3dd1d95  add rsp, 0x08
000070d6f3dd1d99  jmp 0x000070D6F3DCFD00
000070d6f3dd1d9e  call 0x000070D6F3C0D4E0
000070d6f3dd1da3  jmp 0x000070D6F3DCFD0A
000070d6f3dd1da8  call 0x000070D6F3C0AFE0
000070d6f3dd1dad  jmp 0x000070D6F3DCFD14
000070d6f3dd1db2  sub rsp, 0x08
000070d6f3dd1db6  push rax
000070d6f3dd1db7  push rcx
000070d6f3dd1db8  push rdx
000070d6f3dd1db9  push rdi
000070d6f3dd1dba  push rsi
000070d6f3dd1dbb  push r8
000070d6f3dd1dbd  push r9
000070d6f3dd1dbf  push r10
000070d6f3dd1dc1  push r11
000070d6f3dd1dc3  sub rsp, 0xF0
000070d6f3dd1dca  vmovaps [rsp], xmm0
000070d6f3dd1dcf  vmovaps [rsp+0x10], xmm1
000070d6f3dd1dd5  vmovaps [rsp+0x20], xmm2
000070d6f3dd1ddb  vmovaps [rsp+0x30], xmm3
000070d6f3dd1de1  vmovaps [rsp+0x40], xmm4
000070d6f3dd1de7  vmovaps [rsp+0x50], xmm5
000070d6f3dd1ded  vmovaps [rsp+0x60], xmm6
000070d6f3dd1df3  vmovaps [rsp+0x70], xmm8
000070d6f3dd1df9  vmovaps [rsp+0x80], xmm9
000070d6f3dd1e02  vmovaps [rsp+0x90], xmm10
000070d6f3dd1e0b  vmovaps [rsp+0xA0], xmm11
000070d6f3dd1e14  vmovaps [rsp+0xB0], xmm12
000070d6f3dd1e1d  vmovaps [rsp+0xC0], xmm13
000070d6f3dd1e26  vmovaps [rsp+0xD0], xmm14
000070d6f3dd1e2f  vmovaps [rsp+0xE0], xmm15
000070d6f3dd1e38  sub rsp, 0x40
000070d6f3dd1e3c  lea rdi, [rsp]
000070d6f3dd1e40  lea rsi, [rsp+0x10]
000070d6f3dd1e45  lea rdx, [rsp+0x20]
000070d6f3dd1e4a  lea rcx, [rsp+0x30]
000070d6f3dd1e4f  mov r8d, 0x00
000070d6f3dd1e55  lea r9, [r15+0x3A8]
000070d6f3dd1e5c  movaps [rdi], xmm7
000070d6f3dd1e5f  movaps [rsi], xmm4
000070d6f3dd1e62  movaps [rdx], xmm9
000070d6f3dd1e66  movaps [rcx], xmm11
000070d6f3dd1e6a  mov rax, 0x61D08D40EA50
000070d6f3dd1e74  call rax
000070d6f3dd1e76  movaps xmm7, [rsp]
000070d6f3dd1e7a  add rsp, 0x40
000070d6f3dd1e7e  vmovaps xmm0, [rsp]
000070d6f3dd1e83  vmovaps xmm1, [rsp+0x10]
000070d6f3dd1e89  vmovaps xmm2, [rsp+0x20]
000070d6f3dd1e8f  vmovaps xmm3, [rsp+0x30]
000070d6f3dd1e95  vmovaps xmm4, [rsp+0x40]
000070d6f3dd1e9b  vmovaps xmm5, [rsp+0x50]
000070d6f3dd1ea1  vmovaps xmm6, [rsp+0x60]
000070d6f3dd1ea7  vmovaps xmm8, [rsp+0x70]
000070d6f3dd1ead  vmovaps xmm9, [rsp+0x80]
000070d6f3dd1eb6  vmovaps xmm10, [rsp+0x90]
000070d6f3dd1ebf  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd1ec8  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd1ed1  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd1eda  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd1ee3  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd1eec  add rsp, 0xF0
000070d6f3dd1ef3  pop r11
000070d6f3dd1ef5  pop r10
000070d6f3dd1ef7  pop r9
000070d6f3dd1ef9  pop r8
000070d6f3dd1efb  pop rsi
000070d6f3dd1efc  pop rdi
000070d6f3dd1efd  pop rdx
000070d6f3dd1efe  pop rcx
000070d6f3dd1eff  pop rax
000070d6f3dd1f00  add rsp, 0x08
000070d6f3dd1f04  jmp 0x000070D6F3DCFD4B
000070d6f3dd1f09  sub rsp, 0x08
000070d6f3dd1f0d  push rax
000070d6f3dd1f0e  push rcx
000070d6f3dd1f0f  push rdx
000070d6f3dd1f10  push rdi
000070d6f3dd1f11  push rsi
000070d6f3dd1f12  push r8
000070d6f3dd1f14  push r9
000070d6f3dd1f16  push r10
000070d6f3dd1f18  push r11
000070d6f3dd1f1a  sub rsp, 0xF0
000070d6f3dd1f21  vmovaps [rsp], xmm0
000070d6f3dd1f26  vmovaps [rsp+0x10], xmm1
000070d6f3dd1f2c  vmovaps [rsp+0x20], xmm2
000070d6f3dd1f32  vmovaps [rsp+0x30], xmm3
000070d6f3dd1f38  vmovaps [rsp+0x40], xmm4
000070d6f3dd1f3e  vmovaps [rsp+0x50], xmm5
000070d6f3dd1f44  vmovaps [rsp+0x60], xmm6
000070d6f3dd1f4a  vmovaps [rsp+0x70], xmm7
000070d6f3dd1f50  vmovaps [rsp+0x80], xmm8
000070d6f3dd1f59  vmovaps [rsp+0x90], xmm10
000070d6f3dd1f62  vmovaps [rsp+0xA0], xmm11
000070d6f3dd1f6b  vmovaps [rsp+0xB0], xmm12
000070d6f3dd1f74  vmovaps [rsp+0xC0], xmm13
000070d6f3dd1f7d  vmovaps [rsp+0xD0], xmm14
000070d6f3dd1f86  vmovaps [rsp+0xE0], xmm15
000070d6f3dd1f8f  sub rsp, 0x40
000070d6f3dd1f93  lea rdi, [rsp]
000070d6f3dd1f97  lea rsi, [rsp+0x10]
000070d6f3dd1f9c  lea rdx, [rsp+0x20]
000070d6f3dd1fa1  lea rcx, [rsp+0x30]
000070d6f3dd1fa6  mov r8d, 0x00
000070d6f3dd1fac  lea r9, [r15+0x3A8]
000070d6f3dd1fb3  movaps [rdi], xmm9
000070d6f3dd1fb7  movaps [rsi], xmm5
000070d6f3dd1fba  movaps [rdx], xmm14
000070d6f3dd1fbe  movaps [rcx], xmm11
000070d6f3dd1fc2  mov rax, 0x61D08D40EA50
000070d6f3dd1fcc  call rax
000070d6f3dd1fce  movaps xmm9, [rsp]
000070d6f3dd1fd3  add rsp, 0x40
000070d6f3dd1fd7  vmovaps xmm0, [rsp]
000070d6f3dd1fdc  vmovaps xmm1, [rsp+0x10]
000070d6f3dd1fe2  vmovaps xmm2, [rsp+0x20]
000070d6f3dd1fe8  vmovaps xmm3, [rsp+0x30]
000070d6f3dd1fee  vmovaps xmm4, [rsp+0x40]
000070d6f3dd1ff4  vmovaps xmm5, [rsp+0x50]
000070d6f3dd1ffa  vmovaps xmm6, [rsp+0x60]
000070d6f3dd2000  vmovaps xmm7, [rsp+0x70]
000070d6f3dd2006  vmovaps xmm8, [rsp+0x80]
000070d6f3dd200f  vmovaps xmm10, [rsp+0x90]
000070d6f3dd2018  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd2021  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd202a  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd2033  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd203c  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd2045  add rsp, 0xF0
000070d6f3dd204c  pop r11
000070d6f3dd204e  pop r10
000070d6f3dd2050  pop r9
000070d6f3dd2052  pop r8
000070d6f3dd2054  pop rsi
000070d6f3dd2055  pop rdi
000070d6f3dd2056  pop rdx
000070d6f3dd2057  pop rcx
000070d6f3dd2058  pop rax
000070d6f3dd2059  add rsp, 0x08
000070d6f3dd205d  jmp 0x000070D6F3DCFD74
000070d6f3dd2062  sub rsp, 0x08
000070d6f3dd2066  push rax
000070d6f3dd2067  push rcx
000070d6f3dd2068  push rdx
000070d6f3dd2069  push rdi
000070d6f3dd206a  push rsi
000070d6f3dd206b  push r8
000070d6f3dd206d  push r9
000070d6f3dd206f  push r10
000070d6f3dd2071  push r11
000070d6f3dd2073  sub rsp, 0xF0
000070d6f3dd207a  vmovaps [rsp], xmm0
000070d6f3dd207f  vmovaps [rsp+0x10], xmm1
000070d6f3dd2085  vmovaps [rsp+0x20], xmm2
000070d6f3dd208b  vmovaps [rsp+0x30], xmm3
000070d6f3dd2091  vmovaps [rsp+0x40], xmm4
000070d6f3dd2097  vmovaps [rsp+0x50], xmm5
000070d6f3dd209d  vmovaps [rsp+0x60], xmm6
000070d6f3dd20a3  vmovaps [rsp+0x70], xmm7
000070d6f3dd20a9  vmovaps [rsp+0x80], xmm8
000070d6f3dd20b2  vmovaps [rsp+0x90], xmm9
000070d6f3dd20bb  vmovaps [rsp+0xA0], xmm10
000070d6f3dd20c4  vmovaps [rsp+0xB0], xmm12
000070d6f3dd20cd  vmovaps [rsp+0xC0], xmm13
000070d6f3dd20d6  vmovaps [rsp+0xD0], xmm14
000070d6f3dd20df  vmovaps [rsp+0xE0], xmm15
000070d6f3dd20e8  sub rsp, 0x40
000070d6f3dd20ec  lea rdi, [rsp]
000070d6f3dd20f0  lea rsi, [rsp+0x10]
000070d6f3dd20f5  lea rdx, [rsp+0x20]
000070d6f3dd20fa  lea rcx, [rsp+0x30]
000070d6f3dd20ff  mov r8d, 0x00
000070d6f3dd2105  lea r9, [r15+0x3A8]
000070d6f3dd210c  movaps [rdi], xmm11
000070d6f3dd2110  movaps [rsi], xmm8
000070d6f3dd2114  movaps [rdx], xmm10
000070d6f3dd2118  movaps [rcx], xmm14
000070d6f3dd211c  mov rax, 0x61D08D40EA50
000070d6f3dd2126  call rax
000070d6f3dd2128  movaps xmm11, [rsp]
000070d6f3dd212d  add rsp, 0x40
000070d6f3dd2131  vmovaps xmm0, [rsp]
000070d6f3dd2136  vmovaps xmm1, [rsp+0x10]
000070d6f3dd213c  vmovaps xmm2, [rsp+0x20]
000070d6f3dd2142  vmovaps xmm3, [rsp+0x30]
000070d6f3dd2148  vmovaps xmm4, [rsp+0x40]
000070d6f3dd214e  vmovaps xmm5, [rsp+0x50]
000070d6f3dd2154  vmovaps xmm6, [rsp+0x60]
000070d6f3dd215a  vmovaps xmm7, [rsp+0x70]
000070d6f3dd2160  vmovaps xmm8, [rsp+0x80]
000070d6f3dd2169  vmovaps xmm9, [rsp+0x90]
000070d6f3dd2172  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd217b  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd2184  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd218d  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd2196  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd219f  add rsp, 0xF0
000070d6f3dd21a6  pop r11
000070d6f3dd21a8  pop r10
000070d6f3dd21aa  pop r9
000070d6f3dd21ac  pop r8
000070d6f3dd21ae  pop rsi
000070d6f3dd21af  pop rdi
000070d6f3dd21b0  pop rdx
000070d6f3dd21b1  pop rcx
000070d6f3dd21b2  pop rax
000070d6f3dd21b3  add rsp, 0x08
000070d6f3dd21b7  jmp 0x000070D6F3DCFD9D
000070d6f3dd21bc  sub rsp, 0x08
000070d6f3dd21c0  push rax
000070d6f3dd21c1  push rcx
000070d6f3dd21c2  push rdx
000070d6f3dd21c3  push rdi
000070d6f3dd21c4  push rsi
000070d6f3dd21c5  push r8
000070d6f3dd21c7  push r9
000070d6f3dd21c9  push r10
000070d6f3dd21cb  push r11
000070d6f3dd21cd  sub rsp, 0xF0
000070d6f3dd21d4  vmovaps [rsp], xmm0
000070d6f3dd21d9  vmovaps [rsp+0x10], xmm1
000070d6f3dd21df  vmovaps [rsp+0x20], xmm2
000070d6f3dd21e5  vmovaps [rsp+0x30], xmm3
000070d6f3dd21eb  vmovaps [rsp+0x40], xmm4
000070d6f3dd21f1  vmovaps [rsp+0x50], xmm5
000070d6f3dd21f7  vmovaps [rsp+0x60], xmm6
000070d6f3dd21fd  vmovaps [rsp+0x70], xmm7
000070d6f3dd2203  vmovaps [rsp+0x80], xmm8
000070d6f3dd220c  vmovaps [rsp+0x90], xmm9
000070d6f3dd2215  vmovaps [rsp+0xA0], xmm11
000070d6f3dd221e  vmovaps [rsp+0xB0], xmm12
000070d6f3dd2227  vmovaps [rsp+0xC0], xmm13
000070d6f3dd2230  vmovaps [rsp+0xD0], xmm14
000070d6f3dd2239  vmovaps [rsp+0xE0], xmm15
000070d6f3dd2242  sub rsp, 0x40
000070d6f3dd2246  lea rdi, [rsp]
000070d6f3dd224a  lea rsi, [rsp+0x10]
000070d6f3dd224f  lea rdx, [rsp+0x20]
000070d6f3dd2254  lea rcx, [rsp+0x30]
000070d6f3dd2259  mov r8d, 0x00
000070d6f3dd225f  lea r9, [r15+0x3A8]
000070d6f3dd2266  movaps [rdi], xmm10
000070d6f3dd226a  movaps [rsi], xmm13
000070d6f3dd226e  movaps [rdx], xmm15
000070d6f3dd2272  movaps [rcx], xmm14
000070d6f3dd2276  mov rax, 0x61D08D40EA50
000070d6f3dd2280  call rax
000070d6f3dd2282  movaps xmm10, [rsp]
000070d6f3dd2287  add rsp, 0x40
000070d6f3dd228b  vmovaps xmm0, [rsp]
000070d6f3dd2290  vmovaps xmm1, [rsp+0x10]
000070d6f3dd2296  vmovaps xmm2, [rsp+0x20]
000070d6f3dd229c  vmovaps xmm3, [rsp+0x30]
000070d6f3dd22a2  vmovaps xmm4, [rsp+0x40]
000070d6f3dd22a8  vmovaps xmm5, [rsp+0x50]
000070d6f3dd22ae  vmovaps xmm6, [rsp+0x60]
000070d6f3dd22b4  vmovaps xmm7, [rsp+0x70]
000070d6f3dd22ba  vmovaps xmm8, [rsp+0x80]
000070d6f3dd22c3  vmovaps xmm9, [rsp+0x90]
000070d6f3dd22cc  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd22d5  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd22de  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd22e7  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd22f0  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd22f9  add rsp, 0xF0
000070d6f3dd2300  pop r11
000070d6f3dd2302  pop r10
000070d6f3dd2304  pop r9
000070d6f3dd2306  pop r8
000070d6f3dd2308  pop rsi
000070d6f3dd2309  pop rdi
000070d6f3dd230a  pop rdx
000070d6f3dd230b  pop rcx
000070d6f3dd230c  pop rax
000070d6f3dd230d  add rsp, 0x08
000070d6f3dd2311  jmp 0x000070D6F3DCFDC6
000070d6f3dd2316  call 0x000070D6F3C0E760
000070d6f3dd231b  jmp 0x000070D6F3DCFDD0
000070d6f3dd2320  call 0x000070D6F3C0D4E0
000070d6f3dd2325  jmp 0x000070D6F3DCFDDA
000070d6f3dd232a  sub rsp, 0x08
000070d6f3dd232e  push rax
000070d6f3dd232f  push rcx
000070d6f3dd2330  push rdx
000070d6f3dd2331  push rdi
000070d6f3dd2332  push rsi
000070d6f3dd2333  push r8
000070d6f3dd2335  push r9
000070d6f3dd2337  push r10
000070d6f3dd2339  push r11
000070d6f3dd233b  sub rsp, 0xF0
000070d6f3dd2342  vmovaps [rsp], xmm0
000070d6f3dd2347  vmovaps [rsp+0x10], xmm1
000070d6f3dd234d  vmovaps [rsp+0x20], xmm2
000070d6f3dd2353  vmovaps [rsp+0x30], xmm3
000070d6f3dd2359  vmovaps [rsp+0x40], xmm4
000070d6f3dd235f  vmovaps [rsp+0x50], xmm5
000070d6f3dd2365  vmovaps [rsp+0x60], xmm7
000070d6f3dd236b  vmovaps [rsp+0x70], xmm8
000070d6f3dd2371  vmovaps [rsp+0x80], xmm9
000070d6f3dd237a  vmovaps [rsp+0x90], xmm10
000070d6f3dd2383  vmovaps [rsp+0xA0], xmm11
000070d6f3dd238c  vmovaps [rsp+0xB0], xmm12
000070d6f3dd2395  vmovaps [rsp+0xC0], xmm13
000070d6f3dd239e  vmovaps [rsp+0xD0], xmm14
000070d6f3dd23a7  vmovaps [rsp+0xE0], xmm15
000070d6f3dd23b0  sub rsp, 0x40
000070d6f3dd23b4  lea rdi, [rsp]
000070d6f3dd23b8  lea rsi, [rsp+0x10]
000070d6f3dd23bd  lea rdx, [rsp+0x20]
000070d6f3dd23c2  lea rcx, [rsp+0x30]
000070d6f3dd23c7  mov r8d, 0x00
000070d6f3dd23cd  lea r9, [r15+0x3A8]
000070d6f3dd23d4  movaps [rdi], xmm6
000070d6f3dd23d7  movaps [rsi], xmm7
000070d6f3dd23da  movaps [rdx], xmm8
000070d6f3dd23de  movaps [rcx], xmm13
000070d6f3dd23e2  mov rax, 0x61D08D40EA50
000070d6f3dd23ec  call rax
000070d6f3dd23ee  movaps xmm6, [rsp]
000070d6f3dd23f2  add rsp, 0x40
000070d6f3dd23f6  vmovaps xmm0, [rsp]
000070d6f3dd23fb  vmovaps xmm1, [rsp+0x10]
000070d6f3dd2401  vmovaps xmm2, [rsp+0x20]
000070d6f3dd2407  vmovaps xmm3, [rsp+0x30]
000070d6f3dd240d  vmovaps xmm4, [rsp+0x40]
000070d6f3dd2413  vmovaps xmm5, [rsp+0x50]
000070d6f3dd2419  vmovaps xmm7, [rsp+0x60]
000070d6f3dd241f  vmovaps xmm8, [rsp+0x70]
000070d6f3dd2425  vmovaps xmm9, [rsp+0x80]
000070d6f3dd242e  vmovaps xmm10, [rsp+0x90]
000070d6f3dd2437  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd2440  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd2449  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd2452  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd245b  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd2464  add rsp, 0xF0
000070d6f3dd246b  pop r11
000070d6f3dd246d  pop r10
000070d6f3dd246f  pop r9
000070d6f3dd2471  pop r8
000070d6f3dd2473  pop rsi
000070d6f3dd2474  pop rdi
000070d6f3dd2475  pop rdx
000070d6f3dd2476  pop rcx
000070d6f3dd2477  pop rax
000070d6f3dd2478  add rsp, 0x08
000070d6f3dd247c  jmp 0x000070D6F3DCFE04
000070d6f3dd2481  sub rsp, 0x08
000070d6f3dd2485  push rax
000070d6f3dd2486  push rcx
000070d6f3dd2487  push rdx
000070d6f3dd2488  push rdi
000070d6f3dd2489  push rsi
000070d6f3dd248a  push r8
000070d6f3dd248c  push r9
000070d6f3dd248e  push r10
000070d6f3dd2490  push r11
000070d6f3dd2492  sub rsp, 0xF0
000070d6f3dd2499  vmovaps [rsp], xmm0
000070d6f3dd249e  vmovaps [rsp+0x10], xmm1
000070d6f3dd24a4  vmovaps [rsp+0x20], xmm2
000070d6f3dd24aa  vmovaps [rsp+0x30], xmm3
000070d6f3dd24b0  vmovaps [rsp+0x40], xmm4
000070d6f3dd24b6  vmovaps [rsp+0x50], xmm5
000070d6f3dd24bc  vmovaps [rsp+0x60], xmm6
000070d6f3dd24c2  vmovaps [rsp+0x70], xmm7
000070d6f3dd24c8  vmovaps [rsp+0x80], xmm9
000070d6f3dd24d1  vmovaps [rsp+0x90], xmm10
000070d6f3dd24da  vmovaps [rsp+0xA0], xmm11
000070d6f3dd24e3  vmovaps [rsp+0xB0], xmm12
000070d6f3dd24ec  vmovaps [rsp+0xC0], xmm13
000070d6f3dd24f5  vmovaps [rsp+0xD0], xmm14
000070d6f3dd24fe  vmovaps [rsp+0xE0], xmm15
000070d6f3dd2507  sub rsp, 0x40
000070d6f3dd250b  lea rdi, [rsp]
000070d6f3dd250f  lea rsi, [rsp+0x10]
000070d6f3dd2514  lea rdx, [rsp+0x20]
000070d6f3dd2519  lea rcx, [rsp+0x30]
000070d6f3dd251e  mov r8d, 0x00
000070d6f3dd2524  lea r9, [r15+0x3A8]
000070d6f3dd252b  movaps [rdi], xmm8
000070d6f3dd252f  movaps [rsi], xmm9
000070d6f3dd2533  movaps [rdx], xmm1
000070d6f3dd2536  movaps [rcx], xmm13
000070d6f3dd253a  mov rax, 0x61D08D40EA50
000070d6f3dd2544  call rax
000070d6f3dd2546  movaps xmm8, [rsp]
000070d6f3dd254b  add rsp, 0x40
000070d6f3dd254f  vmovaps xmm0, [rsp]
000070d6f3dd2554  vmovaps xmm1, [rsp+0x10]
000070d6f3dd255a  vmovaps xmm2, [rsp+0x20]
000070d6f3dd2560  vmovaps xmm3, [rsp+0x30]
000070d6f3dd2566  vmovaps xmm4, [rsp+0x40]
000070d6f3dd256c  vmovaps xmm5, [rsp+0x50]
000070d6f3dd2572  vmovaps xmm6, [rsp+0x60]
000070d6f3dd2578  vmovaps xmm7, [rsp+0x70]
000070d6f3dd257e  vmovaps xmm9, [rsp+0x80]
000070d6f3dd2587  vmovaps xmm10, [rsp+0x90]
000070d6f3dd2590  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd2599  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd25a2  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd25ab  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd25b4  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd25bd  add rsp, 0xF0
000070d6f3dd25c4  pop r11
000070d6f3dd25c6  pop r10
000070d6f3dd25c8  pop r9
000070d6f3dd25ca  pop r8
000070d6f3dd25cc  pop rsi
000070d6f3dd25cd  pop rdi
000070d6f3dd25ce  pop rdx
000070d6f3dd25cf  pop rcx
000070d6f3dd25d0  pop rax
000070d6f3dd25d1  add rsp, 0x08
000070d6f3dd25d5  jmp 0x000070D6F3DCFE2A
000070d6f3dd25da  sub rsp, 0x08
000070d6f3dd25de  push rax
000070d6f3dd25df  push rcx
000070d6f3dd25e0  push rdx
000070d6f3dd25e1  push rdi
000070d6f3dd25e2  push rsi
000070d6f3dd25e3  push r8
000070d6f3dd25e5  push r9
000070d6f3dd25e7  push r10
000070d6f3dd25e9  push r11
000070d6f3dd25eb  sub rsp, 0xF0
000070d6f3dd25f2  vmovaps [rsp], xmm0
000070d6f3dd25f7  vmovaps [rsp+0x10], xmm1
000070d6f3dd25fd  vmovaps [rsp+0x20], xmm2
000070d6f3dd2603  vmovaps [rsp+0x30], xmm3
000070d6f3dd2609  vmovaps [rsp+0x40], xmm4
000070d6f3dd260f  vmovaps [rsp+0x50], xmm5
000070d6f3dd2615  vmovaps [rsp+0x60], xmm6
000070d6f3dd261b  vmovaps [rsp+0x70], xmm7
000070d6f3dd2621  vmovaps [rsp+0x80], xmm8
000070d6f3dd262a  vmovaps [rsp+0x90], xmm9
000070d6f3dd2633  vmovaps [rsp+0xA0], xmm10
000070d6f3dd263c  vmovaps [rsp+0xB0], xmm11
000070d6f3dd2645  vmovaps [rsp+0xC0], xmm12
000070d6f3dd264e  vmovaps [rsp+0xD0], xmm14
000070d6f3dd2657  vmovaps [rsp+0xE0], xmm15
000070d6f3dd2660  sub rsp, 0x40
000070d6f3dd2664  lea rdi, [rsp]
000070d6f3dd2668  lea rsi, [rsp+0x10]
000070d6f3dd266d  lea rdx, [rsp+0x20]
000070d6f3dd2672  lea rcx, [rsp+0x30]
000070d6f3dd2677  mov r8d, 0x00
000070d6f3dd267d  lea r9, [r15+0x3A8]
000070d6f3dd2684  movaps [rdi], xmm13
000070d6f3dd2688  movaps [rsi], xmm11
000070d6f3dd268c  movaps [rdx], xmm12
000070d6f3dd2690  movaps [rcx], xmm1
000070d6f3dd2693  mov rax, 0x61D08D40EA50
000070d6f3dd269d  call rax
000070d6f3dd269f  movaps xmm13, [rsp]
000070d6f3dd26a4  add rsp, 0x40
000070d6f3dd26a8  vmovaps xmm0, [rsp]
000070d6f3dd26ad  vmovaps xmm1, [rsp+0x10]
000070d6f3dd26b3  vmovaps xmm2, [rsp+0x20]
000070d6f3dd26b9  vmovaps xmm3, [rsp+0x30]
000070d6f3dd26bf  vmovaps xmm4, [rsp+0x40]
000070d6f3dd26c5  vmovaps xmm5, [rsp+0x50]
000070d6f3dd26cb  vmovaps xmm6, [rsp+0x60]
000070d6f3dd26d1  vmovaps xmm7, [rsp+0x70]
000070d6f3dd26d7  vmovaps xmm8, [rsp+0x80]
000070d6f3dd26e0  vmovaps xmm9, [rsp+0x90]
000070d6f3dd26e9  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd26f2  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd26fb  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd2704  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd270d  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd2716  add rsp, 0xF0
000070d6f3dd271d  pop r11
000070d6f3dd271f  pop r10
000070d6f3dd2721  pop r9
000070d6f3dd2723  pop r8
000070d6f3dd2725  pop rsi
000070d6f3dd2726  pop rdi
000070d6f3dd2727  pop rdx
000070d6f3dd2728  pop rcx
000070d6f3dd2729  pop rax
000070d6f3dd272a  add rsp, 0x08
000070d6f3dd272e  jmp 0x000070D6F3DCFE50
000070d6f3dd2733  sub rsp, 0x08
000070d6f3dd2737  push rax
000070d6f3dd2738  push rcx
000070d6f3dd2739  push rdx
000070d6f3dd273a  push rdi
000070d6f3dd273b  push rsi
000070d6f3dd273c  push r8
000070d6f3dd273e  push r9
000070d6f3dd2740  push r10
000070d6f3dd2742  push r11
000070d6f3dd2744  sub rsp, 0xF0
000070d6f3dd274b  vmovaps [rsp], xmm0
000070d6f3dd2750  vmovaps [rsp+0x10], xmm1
000070d6f3dd2756  vmovaps [rsp+0x20], xmm2
000070d6f3dd275c  vmovaps [rsp+0x30], xmm3
000070d6f3dd2762  vmovaps [rsp+0x40], xmm4
000070d6f3dd2768  vmovaps [rsp+0x50], xmm5
000070d6f3dd276e  vmovaps [rsp+0x60], xmm6
000070d6f3dd2774  vmovaps [rsp+0x70], xmm7
000070d6f3dd277a  vmovaps [rsp+0x80], xmm8
000070d6f3dd2783  vmovaps [rsp+0x90], xmm9
000070d6f3dd278c  vmovaps [rsp+0xA0], xmm10
000070d6f3dd2795  vmovaps [rsp+0xB0], xmm11
000070d6f3dd279e  vmovaps [rsp+0xC0], xmm13
000070d6f3dd27a7  vmovaps [rsp+0xD0], xmm14
000070d6f3dd27b0  vmovaps [rsp+0xE0], xmm15
000070d6f3dd27b9  sub rsp, 0x40
000070d6f3dd27bd  lea rdi, [rsp]
000070d6f3dd27c1  lea rsi, [rsp+0x10]
000070d6f3dd27c6  lea rdx, [rsp+0x20]
000070d6f3dd27cb  lea rcx, [rsp+0x30]
000070d6f3dd27d0  mov r8d, 0x00
000070d6f3dd27d6  lea r9, [r15+0x3A8]
000070d6f3dd27dd  movaps [rdi], xmm12
000070d6f3dd27e1  movaps [rsi], xmm10
000070d6f3dd27e5  movaps [rdx], xmm14
000070d6f3dd27e9  movaps [rcx], xmm1
000070d6f3dd27ec  mov rax, 0x61D08D40EA50
000070d6f3dd27f6  call rax
000070d6f3dd27f8  movaps xmm12, [rsp]
000070d6f3dd27fd  add rsp, 0x40
000070d6f3dd2801  vmovaps xmm0, [rsp]
000070d6f3dd2806  vmovaps xmm1, [rsp+0x10]
000070d6f3dd280c  vmovaps xmm2, [rsp+0x20]
000070d6f3dd2812  vmovaps xmm3, [rsp+0x30]
000070d6f3dd2818  vmovaps xmm4, [rsp+0x40]
000070d6f3dd281e  vmovaps xmm5, [rsp+0x50]
000070d6f3dd2824  vmovaps xmm6, [rsp+0x60]
000070d6f3dd282a  vmovaps xmm7, [rsp+0x70]
000070d6f3dd2830  vmovaps xmm8, [rsp+0x80]
000070d6f3dd2839  vmovaps xmm9, [rsp+0x90]
000070d6f3dd2842  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd284b  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd2854  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd285d  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd2866  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd286f  add rsp, 0xF0
000070d6f3dd2876  pop r11
000070d6f3dd2878  pop r10
000070d6f3dd287a  pop r9
000070d6f3dd287c  pop r8
000070d6f3dd287e  pop rsi
000070d6f3dd287f  pop rdi
000070d6f3dd2880  pop rdx
000070d6f3dd2881  pop rcx
000070d6f3dd2882  pop rax
000070d6f3dd2883  add rsp, 0x08
000070d6f3dd2887  jmp 0x000070D6F3DCFE76
000070d6f3dd288c  call 0x000070D6F3BFF430
000070d6f3dd2891  jmp 0x000070D6F3DCFE83
000070d6f3dd2896  call 0x000070D6F3C0D4E0
000070d6f3dd289b  jmp 0x000070D6F3DCFE90
000070d6f3dd28a0  sub rsp, 0x08
000070d6f3dd28a4  push rax
000070d6f3dd28a5  push rcx
000070d6f3dd28a6  push rdx
000070d6f3dd28a7  push rdi
000070d6f3dd28a8  push rsi
000070d6f3dd28a9  push r8
000070d6f3dd28ab  push r9
000070d6f3dd28ad  push r10
000070d6f3dd28af  push r11
000070d6f3dd28b1  sub rsp, 0xF0
000070d6f3dd28b8  vmovaps [rsp], xmm0
000070d6f3dd28bd  vmovaps [rsp+0x10], xmm1
000070d6f3dd28c3  vmovaps [rsp+0x20], xmm2
000070d6f3dd28c9  vmovaps [rsp+0x30], xmm3
000070d6f3dd28cf  vmovaps [rsp+0x40], xmm4
000070d6f3dd28d5  vmovaps [rsp+0x50], xmm5
000070d6f3dd28db  vmovaps [rsp+0x60], xmm6
000070d6f3dd28e1  vmovaps [rsp+0x70], xmm7
000070d6f3dd28e7  vmovaps [rsp+0x80], xmm8
000070d6f3dd28f0  vmovaps [rsp+0x90], xmm9
000070d6f3dd28f9  vmovaps [rsp+0xA0], xmm11
000070d6f3dd2902  vmovaps [rsp+0xB0], xmm12
000070d6f3dd290b  vmovaps [rsp+0xC0], xmm13
000070d6f3dd2914  vmovaps [rsp+0xD0], xmm14
000070d6f3dd291d  vmovaps [rsp+0xE0], xmm15
000070d6f3dd2926  sub rsp, 0x40
000070d6f3dd292a  lea rdi, [rsp]
000070d6f3dd292e  lea rsi, [rsp+0x10]
000070d6f3dd2933  lea rdx, [rsp+0x20]
000070d6f3dd2938  lea rcx, [rsp+0x30]
000070d6f3dd293d  mov r8d, 0x00
000070d6f3dd2943  lea r9, [r15+0x3A8]
000070d6f3dd294a  movaps [rdi], xmm10
000070d6f3dd294e  movaps [rsi], xmm6
000070d6f3dd2951  movaps [rdx], xmm15
000070d6f3dd2955  movaps [rcx], xmm11
000070d6f3dd2959  mov rax, 0x61D08D40EA50
000070d6f3dd2963  call rax
000070d6f3dd2965  movaps xmm10, [rsp]
000070d6f3dd296a  add rsp, 0x40
000070d6f3dd296e  vmovaps xmm0, [rsp]
000070d6f3dd2973  vmovaps xmm1, [rsp+0x10]
000070d6f3dd2979  vmovaps xmm2, [rsp+0x20]
000070d6f3dd297f  vmovaps xmm3, [rsp+0x30]
000070d6f3dd2985  vmovaps xmm4, [rsp+0x40]
000070d6f3dd298b  vmovaps xmm5, [rsp+0x50]
000070d6f3dd2991  vmovaps xmm6, [rsp+0x60]
000070d6f3dd2997  vmovaps xmm7, [rsp+0x70]
000070d6f3dd299d  vmovaps xmm8, [rsp+0x80]
000070d6f3dd29a6  vmovaps xmm9, [rsp+0x90]
000070d6f3dd29af  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd29b8  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd29c1  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd29ca  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd29d3  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd29dc  add rsp, 0xF0
000070d6f3dd29e3  pop r11
000070d6f3dd29e5  pop r10
000070d6f3dd29e7  pop r9
000070d6f3dd29e9  pop r8
000070d6f3dd29eb  pop rsi
000070d6f3dd29ec  pop rdi
000070d6f3dd29ed  pop rdx
000070d6f3dd29ee  pop rcx
000070d6f3dd29ef  pop rax
000070d6f3dd29f0  add rsp, 0x08
000070d6f3dd29f4  jmp 0x000070D6F3DCFEC9
000070d6f3dd29f9  call 0x000070D6F3C0E760
000070d6f3dd29fe  jmp 0x000070D6F3DCFEDB
000070d6f3dd2a03  sub rsp, 0x08
000070d6f3dd2a07  push rax
000070d6f3dd2a08  push rcx
000070d6f3dd2a09  push rdx
000070d6f3dd2a0a  push rdi
000070d6f3dd2a0b  push rsi
000070d6f3dd2a0c  push r8
000070d6f3dd2a0e  push r9
000070d6f3dd2a10  push r10
000070d6f3dd2a12  push r11
000070d6f3dd2a14  sub rsp, 0xF0
000070d6f3dd2a1b  vmovaps [rsp], xmm0
000070d6f3dd2a20  vmovaps [rsp+0x10], xmm1
000070d6f3dd2a26  vmovaps [rsp+0x20], xmm2
000070d6f3dd2a2c  vmovaps [rsp+0x30], xmm3
000070d6f3dd2a32  vmovaps [rsp+0x40], xmm4
000070d6f3dd2a38  vmovaps [rsp+0x50], xmm5
000070d6f3dd2a3e  vmovaps [rsp+0x60], xmm6
000070d6f3dd2a44  vmovaps [rsp+0x70], xmm7
000070d6f3dd2a4a  vmovaps [rsp+0x80], xmm8
000070d6f3dd2a53  vmovaps [rsp+0x90], xmm10
000070d6f3dd2a5c  vmovaps [rsp+0xA0], xmm11
000070d6f3dd2a65  vmovaps [rsp+0xB0], xmm12
000070d6f3dd2a6e  vmovaps [rsp+0xC0], xmm13
000070d6f3dd2a77  vmovaps [rsp+0xD0], xmm14
000070d6f3dd2a80  vmovaps [rsp+0xE0], xmm15
000070d6f3dd2a89  sub rsp, 0x40
000070d6f3dd2a8d  lea rdi, [rsp]
000070d6f3dd2a91  lea rsi, [rsp+0x10]
000070d6f3dd2a96  lea rdx, [rsp+0x20]
000070d6f3dd2a9b  lea rcx, [rsp+0x30]
000070d6f3dd2aa0  mov r8d, 0x00
000070d6f3dd2aa6  lea r9, [r15+0x3A8]
000070d6f3dd2aad  movaps [rdi], xmm9
000070d6f3dd2ab1  movaps [rsi], xmm8
000070d6f3dd2ab5  movaps [rdx], xmm14
000070d6f3dd2ab9  movaps [rcx], xmm11
000070d6f3dd2abd  mov rax, 0x61D08D40EA50
000070d6f3dd2ac7  call rax
000070d6f3dd2ac9  movaps xmm9, [rsp]
000070d6f3dd2ace  add rsp, 0x40
000070d6f3dd2ad2  vmovaps xmm0, [rsp]
000070d6f3dd2ad7  vmovaps xmm1, [rsp+0x10]
000070d6f3dd2add  vmovaps xmm2, [rsp+0x20]
000070d6f3dd2ae3  vmovaps xmm3, [rsp+0x30]
000070d6f3dd2ae9  vmovaps xmm4, [rsp+0x40]
000070d6f3dd2aef  vmovaps xmm5, [rsp+0x50]
000070d6f3dd2af5  vmovaps xmm6, [rsp+0x60]
000070d6f3dd2afb  vmovaps xmm7, [rsp+0x70]
000070d6f3dd2b01  vmovaps xmm8, [rsp+0x80]
000070d6f3dd2b0a  vmovaps xmm10, [rsp+0x90]
000070d6f3dd2b13  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd2b1c  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd2b25  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd2b2e  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd2b37  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd2b40  add rsp, 0xF0
000070d6f3dd2b47  pop r11
000070d6f3dd2b49  pop r10
000070d6f3dd2b4b  pop r9
000070d6f3dd2b4d  pop r8
000070d6f3dd2b4f  pop rsi
000070d6f3dd2b50  pop rdi
000070d6f3dd2b51  pop rdx
000070d6f3dd2b52  pop rcx
000070d6f3dd2b53  pop rax
000070d6f3dd2b54  add rsp, 0x08
000070d6f3dd2b58  jmp 0x000070D6F3DCFF0C
000070d6f3dd2b5d  sub rsp, 0x08
000070d6f3dd2b61  push rax
000070d6f3dd2b62  push rcx
000070d6f3dd2b63  push rdx
000070d6f3dd2b64  push rdi
000070d6f3dd2b65  push rsi
000070d6f3dd2b66  push r8
000070d6f3dd2b68  push r9
000070d6f3dd2b6a  push r10
000070d6f3dd2b6c  push r11
000070d6f3dd2b6e  sub rsp, 0xF0
000070d6f3dd2b75  vmovaps [rsp], xmm0
000070d6f3dd2b7a  vmovaps [rsp+0x10], xmm1
000070d6f3dd2b80  vmovaps [rsp+0x20], xmm2
000070d6f3dd2b86  vmovaps [rsp+0x30], xmm3
000070d6f3dd2b8c  vmovaps [rsp+0x40], xmm4
000070d6f3dd2b92  vmovaps [rsp+0x50], xmm5
000070d6f3dd2b98  vmovaps [rsp+0x60], xmm6
000070d6f3dd2b9e  vmovaps [rsp+0x70], xmm7
000070d6f3dd2ba4  vmovaps [rsp+0x80], xmm8
000070d6f3dd2bad  vmovaps [rsp+0x90], xmm9
000070d6f3dd2bb6  vmovaps [rsp+0xA0], xmm10
000070d6f3dd2bbf  vmovaps [rsp+0xB0], xmm12
000070d6f3dd2bc8  vmovaps [rsp+0xC0], xmm13
000070d6f3dd2bd1  vmovaps [rsp+0xD0], xmm14
000070d6f3dd2bda  vmovaps [rsp+0xE0], xmm15
000070d6f3dd2be3  sub rsp, 0x40
000070d6f3dd2be7  lea rdi, [rsp]
000070d6f3dd2beb  lea rsi, [rsp+0x10]
000070d6f3dd2bf0  lea rdx, [rsp+0x20]
000070d6f3dd2bf5  lea rcx, [rsp+0x30]
000070d6f3dd2bfa  mov r8d, 0x00
000070d6f3dd2c00  lea r9, [r15+0x3A8]
000070d6f3dd2c07  movaps [rdi], xmm11
000070d6f3dd2c0b  movaps [rsi], xmm13
000070d6f3dd2c0f  movaps [rdx], xmm1
000070d6f3dd2c12  movaps [rcx], xmm14
000070d6f3dd2c16  mov rax, 0x61D08D40EA50
000070d6f3dd2c20  call rax
000070d6f3dd2c22  movaps xmm11, [rsp]
000070d6f3dd2c27  add rsp, 0x40
000070d6f3dd2c2b  vmovaps xmm0, [rsp]
000070d6f3dd2c30  vmovaps xmm1, [rsp+0x10]
000070d6f3dd2c36  vmovaps xmm2, [rsp+0x20]
000070d6f3dd2c3c  vmovaps xmm3, [rsp+0x30]
000070d6f3dd2c42  vmovaps xmm4, [rsp+0x40]
000070d6f3dd2c48  vmovaps xmm5, [rsp+0x50]
000070d6f3dd2c4e  vmovaps xmm6, [rsp+0x60]
000070d6f3dd2c54  vmovaps xmm7, [rsp+0x70]
000070d6f3dd2c5a  vmovaps xmm8, [rsp+0x80]
000070d6f3dd2c63  vmovaps xmm9, [rsp+0x90]
000070d6f3dd2c6c  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd2c75  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd2c7e  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd2c87  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd2c90  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd2c99  add rsp, 0xF0
000070d6f3dd2ca0  pop r11
000070d6f3dd2ca2  pop r10
000070d6f3dd2ca4  pop r9
000070d6f3dd2ca6  pop r8
000070d6f3dd2ca8  pop rsi
000070d6f3dd2ca9  pop rdi
000070d6f3dd2caa  pop rdx
000070d6f3dd2cab  pop rcx
000070d6f3dd2cac  pop rax
000070d6f3dd2cad  add rsp, 0x08
000070d6f3dd2cb1  jmp 0x000070D6F3DCFF3D
000070d6f3dd2cb6  sub rsp, 0x08
000070d6f3dd2cba  push rax
000070d6f3dd2cbb  push rcx
000070d6f3dd2cbc  push rdx
000070d6f3dd2cbd  push rdi
000070d6f3dd2cbe  push rsi
000070d6f3dd2cbf  push r8
000070d6f3dd2cc1  push r9
000070d6f3dd2cc3  push r10
000070d6f3dd2cc5  push r11
000070d6f3dd2cc7  sub rsp, 0xF0
000070d6f3dd2cce  vmovaps [rsp], xmm0
000070d6f3dd2cd3  vmovaps [rsp+0x10], xmm1
000070d6f3dd2cd9  vmovaps [rsp+0x20], xmm2
000070d6f3dd2cdf  vmovaps [rsp+0x30], xmm3
000070d6f3dd2ce5  vmovaps [rsp+0x40], xmm4
000070d6f3dd2ceb  vmovaps [rsp+0x50], xmm5
000070d6f3dd2cf1  vmovaps [rsp+0x60], xmm6
000070d6f3dd2cf7  vmovaps [rsp+0x70], xmm7
000070d6f3dd2cfd  vmovaps [rsp+0x80], xmm8
000070d6f3dd2d06  vmovaps [rsp+0x90], xmm9
000070d6f3dd2d0f  vmovaps [rsp+0xA0], xmm10
000070d6f3dd2d18  vmovaps [rsp+0xB0], xmm11
000070d6f3dd2d21  vmovaps [rsp+0xC0], xmm12
000070d6f3dd2d2a  vmovaps [rsp+0xD0], xmm13
000070d6f3dd2d33  vmovaps [rsp+0xE0], xmm15
000070d6f3dd2d3c  sub rsp, 0x40
000070d6f3dd2d40  lea rdi, [rsp]
000070d6f3dd2d44  lea rsi, [rsp+0x10]
000070d6f3dd2d49  lea rdx, [rsp+0x20]
000070d6f3dd2d4e  lea rcx, [rsp+0x30]
000070d6f3dd2d53  mov r8d, 0x00
000070d6f3dd2d59  lea r9, [r15+0x3A8]
000070d6f3dd2d60  movaps [rdi], xmm14
000070d6f3dd2d64  movaps [rsi], xmm12
000070d6f3dd2d68  movaps [rdx], xmm15
000070d6f3dd2d6c  movaps [rcx], xmm1
000070d6f3dd2d6f  mov rax, 0x61D08D40EA50
000070d6f3dd2d79  call rax
000070d6f3dd2d7b  movaps xmm14, [rsp]
000070d6f3dd2d80  add rsp, 0x40
000070d6f3dd2d84  vmovaps xmm0, [rsp]
000070d6f3dd2d89  vmovaps xmm1, [rsp+0x10]
000070d6f3dd2d8f  vmovaps xmm2, [rsp+0x20]
000070d6f3dd2d95  vmovaps xmm3, [rsp+0x30]
000070d6f3dd2d9b  vmovaps xmm4, [rsp+0x40]
000070d6f3dd2da1  vmovaps xmm5, [rsp+0x50]
000070d6f3dd2da7  vmovaps xmm6, [rsp+0x60]
000070d6f3dd2dad  vmovaps xmm7, [rsp+0x70]
000070d6f3dd2db3  vmovaps xmm8, [rsp+0x80]
000070d6f3dd2dbc  vmovaps xmm9, [rsp+0x90]
000070d6f3dd2dc5  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd2dce  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd2dd7  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd2de0  vmovaps xmm13, [rsp+0xD0]
000070d6f3dd2de9  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd2df2  add rsp, 0xF0
000070d6f3dd2df9  pop r11
000070d6f3dd2dfb  pop r10
000070d6f3dd2dfd  pop r9
000070d6f3dd2dff  pop r8
000070d6f3dd2e01  pop rsi
000070d6f3dd2e02  pop rdi
000070d6f3dd2e03  pop rdx
000070d6f3dd2e04  pop rcx
000070d6f3dd2e05  pop rax
000070d6f3dd2e06  add rsp, 0x08
000070d6f3dd2e0a  jmp 0x000070D6F3DCFF6E
000070d6f3dd2e0f  call 0x000070D6F3C079B0
000070d6f3dd2e14  jmp 0x000070D6F3DCFF81
000070d6f3dd2e19  call 0x000070D6F3C09E90
000070d6f3dd2e1e  jmp 0x000070D6F3DCFF8C
000070d6f3dd2e23  call 0x000070D6F3C08C20
000070d6f3dd2e28  jmp 0x000070D6F3DCFF97
000070d6f3dd2e2d  call 0x000070D6F3C0D600
000070d6f3dd2e32  jmp 0x000070D6F3DCFFA2
000070d6f3dd2e37  int3
000070d6f3dd2e38  nop [rax+rax*1], eax
000070d6f3dd2e40  mov rax, [r15+0x40]
000070d6f3dd2e44  mov r14, [r15+0x58]
000070d6f3dd2e48  lea r12, [rax+r14*1]
000070d6f3dd2e4c  vxorps xmm1, xmm1, xmm1
000070d6f3dd2e50  vpbroadcastq xmm1, xmm1
000070d6f3dd2e55  vxorps xmm15, xmm15, xmm15
000070d6f3dd2e5a  vpbroadcastq xmm15, xmm15
000070d6f3dd2e5f  lea rax, [r12+0x30]
000070d6f3dd2e64  mov r11, [r13+rax*1]
000070d6f3dd2e69  lea rax, [r12+0x38]
000070d6f3dd2e6e  mov r10, [r13+rax*1]
000070d6f3dd2e73  movq xmm14, r11
000070d6f3dd2e78  movq xmm13, r10
000070d6f3dd2e7d  movq xmm14, xmm14
000070d6f3dd2e82  movq xmm13, xmm13
000070d6f3dd2e87  vmovaps [rsp+0x10], xmm13
000070d6f3dd2e8d  movq xmm13, xmm13
000070d6f3dd2e92  movaps [r15+0x270], xmm13
000070d6f3dd2e9a  movaps xmm13, [r15+0x160]
000070d6f3dd2ea2  vmovaps [rsp+0x20], xmm13
000070d6f3dd2ea8  vmovaps xmm12, [rsp+0x20]
000070d6f3dd2eae  por xmm13, xmm12
000070d6f3dd2eb3  lea rax, [r12+0x20]
000070d6f3dd2eb8  mov r11, [r13+rax*1]
000070d6f3dd2ebd  lea rax, [r12+0x28]
000070d6f3dd2ec2  mov r10, [r13+rax*1]
000070d6f3dd2ec7  movq xmm12, r11
000070d6f3dd2ecc  movq xmm11, r10
000070d6f3dd2ed1  movq xmm12, xmm12
000070d6f3dd2ed6  movq xmm11, xmm11
000070d6f3dd2edb  movaps xmm10, [r15+0x2F0]
000070d6f3dd2ee3  vmovaps [rsp+0x20], xmm10
000070d6f3dd2ee9  vmovaps xmm9, [rsp+0x20]
000070d6f3dd2eef  por xmm10, xmm9
000070d6f3dd2ef4  movaps xmm9, [r15+0x2D0]
000070d6f3dd2efc  vmovaps [rsp+0x20], xmm9
000070d6f3dd2f02  vmovaps xmm8, [rsp+0x20]
000070d6f3dd2f08  por xmm9, xmm8
000070d6f3dd2f0d  movaps xmm8, [r15+0x300]
000070d6f3dd2f15  vmovaps [rsp+0x20], xmm8
000070d6f3dd2f1b  vmovaps xmm7, [rsp+0x20]
000070d6f3dd2f21  por xmm8, xmm7
000070d6f3dd2f26  movaps xmm7, [r15+0x2B0]
000070d6f3dd2f2e  vmovaps [rsp+0x20], xmm7
000070d6f3dd2f34  vmovaps xmm6, [rsp+0x20]
000070d6f3dd2f3a  por xmm7, xmm6
000070d6f3dd2f3e  movaps xmm6, [r15+0x180]
000070d6f3dd2f46  vmovaps [rsp+0x20], xmm6
000070d6f3dd2f4c  vmovaps xmm5, [rsp+0x20]
000070d6f3dd2f52  por xmm6, xmm5
000070d6f3dd2f56  lea rax, [r12+0x10]
000070d6f3dd2f5b  mov r11, [r13+rax*1]
000070d6f3dd2f60  lea rax, [r12+0x18]
000070d6f3dd2f65  mov r10, [r13+rax*1]
000070d6f3dd2f6a  movq xmm5, r11
000070d6f3dd2f6f  movq xmm4, r10
000070d6f3dd2f74  movq xmm5, xmm5
000070d6f3dd2f78  movq xmm4, xmm4
000070d6f3dd2f7c  movaps xmm3, [r15+0x200]
000070d6f3dd2f84  vmovaps [rsp+0x20], xmm3
000070d6f3dd2f8a  vmovaps xmm2, [rsp+0x20]
000070d6f3dd2f90  por xmm3, xmm2
000070d6f3dd2f94  movaps xmm2, [r15+0x1F0]
000070d6f3dd2f9c  vmovaps [rsp+0x20], xmm2
000070d6f3dd2fa2  vmovaps [rsp+0x30], xmm1
000070d6f3dd2fa8  vmovaps xmm1, [rsp+0x20]
000070d6f3dd2fae  por xmm2, xmm1
000070d6f3dd2fb2  movaps xmm1, [r15+0x2E0]
000070d6f3dd2fba  vmovaps [rsp+0x20], xmm1
000070d6f3dd2fc0  vmovaps [rsp+0x40], xmm15
000070d6f3dd2fc6  vmovaps xmm15, [rsp+0x20]
000070d6f3dd2fcc  por xmm1, xmm15
000070d6f3dd2fd1  movaps xmm15, [r15+0x2A0]
000070d6f3dd2fd9  vmovaps [rsp+0x20], xmm15
000070d6f3dd2fdf  vmovaps [rsp+0x50], xmm1
000070d6f3dd2fe5  vmovaps xmm1, [rsp+0x20]
000070d6f3dd2feb  por xmm15, xmm1
000070d6f3dd2ff0  movaps xmm1, [r15+0x280]
000070d6f3dd2ff8  vmovaps [rsp+0x20], xmm1
000070d6f3dd2ffe  vmovaps [rsp+0x60], xmm15
000070d6f3dd3004  vmovaps xmm15, [rsp+0x20]
000070d6f3dd300a  por xmm1, xmm15
000070d6f3dd300f  movaps xmm15, [r15+0x1C0]
000070d6f3dd3017  vmovaps [rsp+0x20], xmm15
000070d6f3dd301d  vmovaps [rsp+0x70], xmm1
000070d6f3dd3023  vmovaps xmm1, [rsp+0x20]
000070d6f3dd3029  por xmm15, xmm1
000070d6f3dd302e  movaps xmm1, [r15+0x210]
000070d6f3dd3036  vmovaps [rsp+0x20], xmm1
000070d6f3dd303c  vmovaps [rsp+0x80], xmm15
000070d6f3dd3045  vmovaps xmm15, [rsp+0x20]
000070d6f3dd304b  por xmm1, xmm15
000070d6f3dd3050  mov rax, [r13+r12*1]
000070d6f3dd3055  vmovq xmm15, rax
000070d6f3dd305a  vpbroadcastq xmm15, xmm15
000070d6f3dd305f  vmovaps [rsp+0x20], xmm1
000070d6f3dd3065  vxorps xmm1, xmm1, xmm1
000070d6f3dd3069  vpbroadcastq xmm1, xmm1
000070d6f3dd306e  mov rax, [r15+0xF8]
000070d6f3dd3075  vmovaps [rsp+0x90], xmm1
000070d6f3dd307e  movups xmm1, [r13+rax*1]
000070d6f3dd3084  vmovaps [rsp+0xA0], xmm1
000070d6f3dd308d  vxorps xmm1, xmm1, xmm1
000070d6f3dd3091  vpbroadcastq xmm1, xmm1
000070d6f3dd3096  lea r11, [r12+0x08]
000070d6f3dd309b  mov r12, [r13+r11*1]
000070d6f3dd30a0  vmovaps [rsp+0xB0], xmm1
000070d6f3dd30a9  movq xmm1, r12
000070d6f3dd30ae  movaps [r15+0x240], xmm1
000070d6f3dd30b6  mov r12, [r15+0x50]
000070d6f3dd30ba  lea r11, [r12+r14*1]
000070d6f3dd30be  mov [r15+0x60], r11
000070d6f3dd30c2  lea r12, [r14+0x40]
000070d6f3dd30c6  mov [r15+0x58], r12
000070d6f3dd30ca  vmovaps xmm1, [rsp+0x30]
000070d6f3dd30d0  vmovaps [rsp+0x30], xmm15
000070d6f3dd30d6  vmovaps xmm15, [rsp+0xA0]
000070d6f3dd30df  vmovaps [rsp+0xA0], xmm14
000070d6f3dd30e8  vmovaps xmm14, [rsp+0x30]
000070d6f3dd30ee  vmovaps [rsp+0x30], xmm13
000070d6f3dd30f4  vmovaps [rsp+0xC0], xmm12
000070d6f3dd30fd  movaps xmm13, xmm1
000070d6f3dd3101  vfmadd231pd xmm13, xmm15, xmm14
000070d6f3dd3106  vcmppd xmm12, xmm13, xmm13, 0x03
000070d6f3dd310c  vptest xmm12, xmm12
000070d6f3dd3111  jnz 0x000070D6F3DD3BEA
000070d6f3dd3117  movaps xmm1, [r15+0x250]
000070d6f3dd311f  vmovaps xmm15, [rsp+0x40]
000070d6f3dd3125  vmovaps [rsp+0x40], xmm13
000070d6f3dd312b  movaps xmm12, xmm15
000070d6f3dd312f  vfmadd231pd xmm12, xmm1, xmm14
000070d6f3dd3134  vcmppd xmm13, xmm12, xmm12, 0x03
000070d6f3dd313a  vptest xmm13, xmm13
000070d6f3dd313f  jnz 0x000070D6F3DD3D43
000070d6f3dd3145  movaps xmm15, [r15+0x1E0]
000070d6f3dd314d  vmovaps [rsp+0xD0], xmm15
000070d6f3dd3156  vmovaps xmm13, [rsp+0xD0]
000070d6f3dd315f  por xmm15, xmm13
000070d6f3dd3164  movaps xmm13, [r15+0x1D0]
000070d6f3dd316c  vmovaps [rsp+0xD0], xmm13
000070d6f3dd3175  vmovaps [rsp+0xE0], xmm1
000070d6f3dd317e  vmovaps xmm1, [rsp+0xD0]
000070d6f3dd3187  por xmm13, xmm1
000070d6f3dd318c  movaps xmm1, [r15+0x2C0]
000070d6f3dd3194  vmovaps [rsp+0xD0], xmm1
000070d6f3dd319d  vmovaps [rsp+0xF0], xmm15
000070d6f3dd31a6  vmovaps xmm15, [rsp+0xD0]
000070d6f3dd31af  por xmm1, xmm15
000070d6f3dd31b4  movaps xmm15, [r15+0x290]
000070d6f3dd31bc  vmovaps [rsp+0xD0], xmm15
000070d6f3dd31c5  vmovaps [rsp+0x100], xmm1
000070d6f3dd31ce  vmovaps xmm1, [rsp+0xD0]
000070d6f3dd31d7  por xmm15, xmm1
000070d6f3dd31dc  movaps xmm1, [r15+0x260]
000070d6f3dd31e4  vmovaps [rsp+0xD0], xmm1
000070d6f3dd31ed  vmovaps [rsp+0x110], xmm15
000070d6f3dd31f6  vmovaps xmm15, [rsp+0xD0]
000070d6f3dd31ff  por xmm1, xmm15
000070d6f3dd3204  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd320d  vmovaps [rsp+0xD0], xmm1
000070d6f3dd3216  vmovaps xmm1, [rsp+0xE0]
000070d6f3dd321f  por xmm15, xmm1
000070d6f3dd3224  lea r14, [rax+0xC0]
000070d6f3dd322b  movups xmm1, [r13+r14*1]
000070d6f3dd3231  mov [rsp+0xE0], rax
000070d6f3dd3239  xor eax, eax
000070d6f3dd323b  mov r14d, 0x200
000070d6f3dd3241  cmp r12, r14
000070d6f3dd3244  cmc
000070d6f3dd3245  lahf
000070d6f3dd3246  seto al
000070d6f3dd3249  mov [r15+0x108], eax
000070d6f3dd3250  vmovaps [rsp+0x120], xmm1
000070d6f3dd3259  vmovaps xmm1, [rsp+0x90]
000070d6f3dd3262  vmovaps [rsp+0x90], xmm15
000070d6f3dd326b  vmovaps xmm15, [rsp+0x120]
000070d6f3dd3274  vmovaps [rsp+0x120], xmm13
000070d6f3dd327d  vmovaps [rsp+0x130], xmm12
000070d6f3dd3286  movaps xmm13, xmm1
000070d6f3dd328a  vfmadd231pd xmm13, xmm15, xmm14
000070d6f3dd328f  vcmppd xmm12, xmm13, xmm13, 0x03
000070d6f3dd3295  vptest xmm12, xmm12
000070d6f3dd329a  jnz 0x000070D6F3DD3EA6
000070d6f3dd32a0  mov rax, [rsp+0xE0]
000070d6f3dd32a8  lea r14, [rax+0xB0]
000070d6f3dd32af  movups xmm1, [r13+r14*1]
000070d6f3dd32b5  vmovaps xmm15, [rsp+0xB0]
000070d6f3dd32be  vmovaps [rsp+0xB0], xmm13
000070d6f3dd32c7  movaps xmm12, xmm15
000070d6f3dd32cb  vfmadd231pd xmm12, xmm1, xmm14
000070d6f3dd32d0  vcmppd xmm13, xmm12, xmm12, 0x03
000070d6f3dd32d6  vptest xmm13, xmm13
000070d6f3dd32db  jnz 0x000070D6F3DD4009
000070d6f3dd32e1  vmovaps xmm1, [rsp+0x20]
000070d6f3dd32e7  vmovaps xmm15, [rsp+0x20]
000070d6f3dd32ed  por xmm1, xmm15
000070d6f3dd32f2  movaps [r15+0x210], xmm1
000070d6f3dd32fa  vmovaps xmm15, [rsp+0x80]
000070d6f3dd3303  vmovaps xmm14, [rsp+0x80]
000070d6f3dd330c  por xmm15, xmm14
000070d6f3dd3311  movaps [r15+0x1C0], xmm15
000070d6f3dd3319  vmovaps xmm14, [rsp+0x70]
000070d6f3dd331f  vmovaps xmm13, [rsp+0x70]
000070d6f3dd3325  por xmm14, xmm13
000070d6f3dd332a  movaps [r15+0x280], xmm14
000070d6f3dd3332  vmovaps xmm13, [rsp+0x60]
000070d6f3dd3338  vmovaps [rsp+0x20], xmm1
000070d6f3dd333e  vmovaps xmm1, [rsp+0x60]
000070d6f3dd3344  por xmm13, xmm1
000070d6f3dd3349  movaps [r15+0x2A0], xmm13
000070d6f3dd3351  vmovaps xmm1, [rsp+0x50]
000070d6f3dd3357  vmovaps [rsp+0x60], xmm15
000070d6f3dd335d  vmovaps xmm15, [rsp+0x50]
000070d6f3dd3363  por xmm1, xmm15
000070d6f3dd3368  movaps [r15+0x2E0], xmm1
000070d6f3dd3370  vmovaps [rsp+0x50], xmm2
000070d6f3dd3376  vmovaps xmm15, [rsp+0x50]
000070d6f3dd337c  por xmm2, xmm15
000070d6f3dd3381  movaps [r15+0x1F0], xmm2
000070d6f3dd3389  vmovaps xmm15, [rsp+0x90]
000070d6f3dd3392  vmovaps [rsp+0x50], xmm1
000070d6f3dd3398  vmovaps xmm1, [rsp+0x90]
000070d6f3dd33a1  por xmm15, xmm1
000070d6f3dd33a6  movaps [r15+0x250], xmm15
000070d6f3dd33ae  vmovaps xmm1, [rsp+0xD0]
000070d6f3dd33b7  vmovaps xmm15, [rsp+0xD0]
000070d6f3dd33c0  por xmm1, xmm15
000070d6f3dd33c5  movaps [r15+0x260], xmm1
000070d6f3dd33cd  vmovaps xmm15, [rsp+0x110]
000070d6f3dd33d6  vmovaps [rsp+0x70], xmm1
000070d6f3dd33dc  vmovaps xmm1, [rsp+0x110]
000070d6f3dd33e5  por xmm15, xmm1
000070d6f3dd33ea  movaps [r15+0x290], xmm15
000070d6f3dd33f2  vmovaps xmm1, [rsp+0x100]
000070d6f3dd33fb  vmovaps [rsp+0x80], xmm15
000070d6f3dd3404  vmovaps xmm15, [rsp+0x100]
000070d6f3dd340d  por xmm1, xmm15
000070d6f3dd3412  movaps [r15+0x2C0], xmm1
000070d6f3dd341a  movq xmm15, qword ptr [r15+0x240]
000070d6f3dd3423  vmovaps [rsp+0x90], xmm15
000070d6f3dd342c  vpermilpd xmm15, xmm15, 0x00
000070d6f3dd3432  vmovaps [rsp+0xD0], xmm1
000070d6f3dd343b  vmovaps xmm1, [rsp+0x40]
000070d6f3dd3441  vmovaps [rsp+0x40], xmm15
000070d6f3dd3447  vmovaps xmm15, [rsp+0x20]
000070d6f3dd344d  vmovaps [rsp+0x20], xmm14
000070d6f3dd3453  vmovaps xmm14, [rsp+0x40]
000070d6f3dd3459  vmovaps [rsp+0x40], xmm13
000070d6f3dd345f  vmovaps [rsp+0xE0], xmm12
000070d6f3dd3468  movaps xmm13, xmm1
000070d6f3dd346c  vfmadd231pd xmm13, xmm15, xmm14
000070d6f3dd3471  vcmppd xmm12, xmm13, xmm13, 0x03
000070d6f3dd3477  vptest xmm12, xmm12
000070d6f3dd347c  jnz 0x000070D6F3DD4162
000070d6f3dd3482  vmovaps xmm1, [rsp+0x90]
000070d6f3dd348b  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd3491  vmovaps xmm15, [rsp+0xB0]
000070d6f3dd349a  vmovaps xmm14, [rsp+0x50]
000070d6f3dd34a0  vmovaps [rsp+0x50], xmm13
000070d6f3dd34a6  movaps xmm12, xmm15
000070d6f3dd34aa  vfmadd231pd xmm12, xmm14, xmm1
000070d6f3dd34af  vcmppd xmm13, xmm12, xmm12, 0x03
000070d6f3dd34b5  vptest xmm13, xmm13
000070d6f3dd34ba  jnz 0x000070D6F3DD42BB
000070d6f3dd34c0  vmovaps xmm1, [rsp+0x90]
000070d6f3dd34c9  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd34cf  vmovaps xmm15, [rsp+0x130]
000070d6f3dd34d8  vmovaps xmm14, [rsp+0x60]
000070d6f3dd34de  vmovaps [rsp+0x60], xmm12
000070d6f3dd34e4  movaps xmm13, xmm15
000070d6f3dd34e8  vfmadd231pd xmm13, xmm14, xmm1
000070d6f3dd34ed  vcmppd xmm12, xmm13, xmm13, 0x03
000070d6f3dd34f3  vptest xmm12, xmm12
000070d6f3dd34f8  jnz 0x000070D6F3DD4414
000070d6f3dd34fe  vmovaps xmm1, [rsp+0x120]
000070d6f3dd3507  vmovaps xmm15, [rsp+0x120]
000070d6f3dd3510  por xmm1, xmm15
000070d6f3dd3515  movaps [r15+0x1D0], xmm1
000070d6f3dd351d  vmovaps xmm15, [rsp+0x90]
000070d6f3dd3526  vpermilpd xmm15, xmm15, 0x00
000070d6f3dd352c  vmovaps xmm14, [rsp+0xE0]
000070d6f3dd3535  vmovaps [rsp+0x90], xmm1
000070d6f3dd353e  movaps xmm12, xmm14
000070d6f3dd3542  vfmadd231pd xmm12, xmm2, xmm15
000070d6f3dd3547  vcmppd xmm1, xmm12, xmm12, 0x03
000070d6f3dd354d  vptest xmm1, xmm1
000070d6f3dd3552  jnz 0x000070D6F3DD456D
000070d6f3dd3558  vmovaps [rsp+0xB0], xmm3
000070d6f3dd3561  vmovaps xmm1, [rsp+0xB0]
000070d6f3dd356a  por xmm3, xmm1
000070d6f3dd356e  movaps [r15+0x200], xmm3
000070d6f3dd3576  vmovaps xmm1, [rsp+0xF0]
000070d6f3dd357f  vmovaps xmm15, [rsp+0xF0]
000070d6f3dd3588  por xmm1, xmm15
000070d6f3dd358d  movaps [r15+0x1E0], xmm1
000070d6f3dd3595  vmovaps [rsp+0xB0], xmm7
000070d6f3dd359e  vmovaps xmm1, [rsp+0xB0]
000070d6f3dd35a7  por xmm7, xmm1
000070d6f3dd35ab  movaps [r15+0x2B0], xmm7
000070d6f3dd35b3  vmovaps [rsp+0xB0], xmm8
000070d6f3dd35bc  vmovaps xmm1, [rsp+0xB0]
000070d6f3dd35c5  por xmm8, xmm1
000070d6f3dd35ca  movaps [r15+0x300], xmm8
000070d6f3dd35d2  vmovaps [rsp+0xB0], xmm5
000070d6f3dd35db  vpermilpd xmm5, xmm5, 0x00
000070d6f3dd35e1  vmovaps xmm14, [rsp+0x50]
000070d6f3dd35e7  vmovaps xmm8, [rsp+0x70]
000070d6f3dd35ed  vmovaps [rsp+0x50], xmm1
000070d6f3dd35f3  movaps xmm2, xmm14
000070d6f3dd35f7  vfmadd231pd xmm2, xmm8, xmm5
000070d6f3dd35fc  vcmppd xmm1, xmm2, xmm2, 0x03
000070d6f3dd3601  vptest xmm1, xmm1
000070d6f3dd3606  jnz 0x000070D6F3DD46C6
000070d6f3dd360c  vmovaps xmm1, [rsp+0xB0]
000070d6f3dd3615  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd361b  vmovaps xmm14, [rsp+0x60]
000070d6f3dd3621  vmovaps xmm8, [rsp+0xD0]
000070d6f3dd362a  vmovaps [rsp+0x60], xmm15
000070d6f3dd3630  movaps xmm5, xmm14
000070d6f3dd3634  vfmadd231pd xmm5, xmm8, xmm1
000070d6f3dd3639  vcmppd xmm15, xmm5, xmm5, 0x03
000070d6f3dd363e  vptest xmm15, xmm15
000070d6f3dd3643  jnz 0x000070D6F3DD481D
000070d6f3dd3649  vmovaps xmm1, [rsp+0xB0]
000070d6f3dd3652  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd3658  vmovaps xmm14, [rsp+0x20]
000070d6f3dd365e  movaps xmm15, xmm13
000070d6f3dd3662  vfmadd231pd xmm15, xmm14, xmm1
000070d6f3dd3667  vcmppd xmm8, xmm15, xmm15, 0x03
000070d6f3dd366d  vptest xmm8, xmm8
000070d6f3dd3672  jnz 0x000070D6F3DD4974
000070d6f3dd3678  vmovaps xmm1, [rsp+0xB0]
000070d6f3dd3681  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd3687  vmovaps xmm14, [rsp+0x90]
000070d6f3dd3690  movaps xmm13, xmm12
000070d6f3dd3694  vfmadd231pd xmm13, xmm14, xmm1
000070d6f3dd3699  vcmppd xmm8, xmm13, xmm13, 0x03
000070d6f3dd369f  vptest xmm8, xmm8
000070d6f3dd36a4  jnz 0x000070D6F3DD4ACD
000070d6f3dd36aa  vmovaps [rsp+0x20], xmm6
000070d6f3dd36b0  vmovaps xmm1, [rsp+0x20]
000070d6f3dd36b6  por xmm6, xmm1
000070d6f3dd36ba  movaps [r15+0x180], xmm6
000070d6f3dd36c2  vmovaps [rsp+0x20], xmm9
000070d6f3dd36c8  vmovaps xmm1, [rsp+0x20]
000070d6f3dd36ce  por xmm9, xmm1
000070d6f3dd36d3  movaps [r15+0x2D0], xmm9
000070d6f3dd36db  vmovaps [rsp+0x20], xmm10
000070d6f3dd36e1  vmovaps xmm1, [rsp+0x20]
000070d6f3dd36e7  por xmm10, xmm1
000070d6f3dd36ec  movaps [r15+0x2F0], xmm10
000070d6f3dd36f4  vmovaps [rsp+0x20], xmm4
000070d6f3dd36fa  vpermilpd xmm4, xmm4, 0x00
000070d6f3dd3700  vmovaps xmm14, [rsp+0x50]
000070d6f3dd3706  movaps xmm12, xmm5
000070d6f3dd370a  vfmadd231pd xmm12, xmm14, xmm4
000070d6f3dd370f  vcmppd xmm10, xmm12, xmm12, 0x03
000070d6f3dd3715  vptest xmm10, xmm10
000070d6f3dd371a  jnz 0x000070D6F3DD4C26
000070d6f3dd3720  vmovaps xmm14, [rsp+0x20]
000070d6f3dd3726  vpermilpd xmm14, xmm14, 0x00
000070d6f3dd372c  movaps xmm10, xmm2
000070d6f3dd3730  vfmadd231pd xmm10, xmm6, xmm14
000070d6f3dd3735  vcmppd xmm8, xmm10, xmm10, 0x03
000070d6f3dd373b  vptest xmm8, xmm8
000070d6f3dd3740  jnz 0x000070D6F3DD4D7E
000070d6f3dd3746  lea r14, [rax+0x80]
000070d6f3dd374d  movups xmm14, [r13+r14*1]
000070d6f3dd3753  movaps [r15+0x190], xmm14
000070d6f3dd375b  vmovaps xmm8, [rsp+0x20]
000070d6f3dd3761  vpermilpd xmm8, xmm8, 0x00
000070d6f3dd3767  vmovaps xmm6, [rsp+0x80]
000070d6f3dd3770  movaps xmm5, xmm15
000070d6f3dd3774  vfmadd231pd xmm5, xmm6, xmm8
000070d6f3dd3779  vcmppd xmm4, xmm5, xmm5, 0x03
000070d6f3dd377e  vptest xmm4, xmm4
000070d6f3dd3783  jnz 0x000070D6F3DD4EE0
000070d6f3dd3789  vmovaps xmm15, [rsp+0x20]
000070d6f3dd378f  vpermilpd xmm15, xmm15, 0x00
000070d6f3dd3795  movaps xmm8, xmm13
000070d6f3dd3799  vfmadd231pd xmm8, xmm1, xmm15
000070d6f3dd379e  vcmppd xmm6, xmm8, xmm8, 0x03
000070d6f3dd37a4  vptest xmm6, xmm6
000070d6f3dd37a9  jnz 0x000070D6F3DD5037
000070d6f3dd37af  vmovaps xmm1, [rsp+0x30]
000070d6f3dd37b5  vmovaps xmm15, [rsp+0x30]
000070d6f3dd37bb  por xmm1, xmm15
000070d6f3dd37c0  movaps [r15+0x160], xmm1
000070d6f3dd37c8  lea r14, [rax+0x40]
000070d6f3dd37cc  movups xmm15, [r13+r14*1]
000070d6f3dd37d2  lea r14, [rax+0x50]
000070d6f3dd37d6  movups xmm13, [r13+r14*1]
000070d6f3dd37dc  movaps [r15+0x1B0], xmm15
000070d6f3dd37e4  movaps [r15+0x1A0], xmm13
000070d6f3dd37ec  vmovaps xmm6, [rsp+0xC0]
000070d6f3dd37f5  vpermilpd xmm6, xmm6, 0x00
000070d6f3dd37fb  movaps xmm4, xmm12
000070d6f3dd37ff  vfmadd231pd xmm4, xmm9, xmm6
000070d6f3dd3804  vcmppd xmm2, xmm4, xmm4, 0x03
000070d6f3dd3809  vptest xmm2, xmm2
000070d6f3dd380e  jnz 0x000070D6F3DD51A4
000070d6f3dd3814  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd381d  vpermilpd xmm12, xmm12, 0x00
000070d6f3dd3823  movaps xmm9, xmm10
000070d6f3dd3827  vfmadd231pd xmm9, xmm1, xmm12
000070d6f3dd382c  vcmppd xmm6, xmm9, xmm9, 0x03
000070d6f3dd3832  vptest xmm6, xmm6
000070d6f3dd3837  jnz 0x000070D6F3DD52FB
000070d6f3dd383d  vmovaps xmm1, [rsp+0xC0]
000070d6f3dd3846  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd384c  vmovaps xmm12, [rsp+0x40]
000070d6f3dd3852  movaps xmm10, xmm5
000070d6f3dd3856  vfmadd231pd xmm10, xmm12, xmm1
000070d6f3dd385b  vcmppd xmm6, xmm10, xmm10, 0x03
000070d6f3dd3861  vptest xmm6, xmm6
000070d6f3dd3866  jnz 0x000070D6F3DD5454
000070d6f3dd386c  vmovaps xmm1, [rsp+0xC0]
000070d6f3dd3875  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd387b  vmovaps xmm12, [rsp+0x60]
000070d6f3dd3881  movaps xmm6, xmm8
000070d6f3dd3885  vfmadd231pd xmm6, xmm12, xmm1
000070d6f3dd388a  vcmppd xmm5, xmm6, xmm6, 0x03
000070d6f3dd388f  vptest xmm5, xmm5
000070d6f3dd3894  jnz 0x000070D6F3DD55AC
000070d6f3dd389a  lea r14, [rax+0x60]
000070d6f3dd389e  movups xmm1, [r13+r14*1]
000070d6f3dd38a4  lea r14, [rax+0x70]
000070d6f3dd38a8  movups xmm12, [r13+r14*1]
000070d6f3dd38ae  movaps [r15+0x150], xmm1
000070d6f3dd38b6  movaps [r15+0x120], xmm12
000070d6f3dd38be  vmovaps [rsp+0x20], xmm11
000070d6f3dd38c4  vpermilpd xmm11, xmm11, 0x00
000070d6f3dd38ca  movaps xmm8, xmm4
000070d6f3dd38ce  vfmadd231pd xmm8, xmm13, xmm11
000070d6f3dd38d3  vcmppd xmm5, xmm8, xmm8, 0x03
000070d6f3dd38d9  vptest xmm5, xmm5
000070d6f3dd38de  jnz 0x000070D6F3DD5717
000070d6f3dd38e4  vmovaps xmm13, [rsp+0x20]
000070d6f3dd38ea  vpermilpd xmm13, xmm13, 0x00
000070d6f3dd38f0  movaps xmm11, xmm9
000070d6f3dd38f4  vfmadd231pd xmm11, xmm1, xmm13
000070d6f3dd38f9  vcmppd xmm5, xmm11, xmm11, 0x03
000070d6f3dd38ff  vptest xmm5, xmm5
000070d6f3dd3904  jnz 0x000070D6F3DD5870
000070d6f3dd390a  vmovaps xmm1, [rsp+0x20]
000070d6f3dd3910  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd3916  movaps xmm13, xmm10
000070d6f3dd391a  vfmadd231pd xmm13, xmm7, xmm1
000070d6f3dd391f  vcmppd xmm9, xmm13, xmm13, 0x03
000070d6f3dd3925  vptest xmm9, xmm9
000070d6f3dd392a  jnz 0x000070D6F3DD59C9
000070d6f3dd3930  vmovaps xmm1, [rsp+0x20]
000070d6f3dd3936  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd393c  movaps xmm10, xmm6
000070d6f3dd3940  vfmadd231pd xmm10, xmm15, xmm1
000070d6f3dd3945  vcmppd xmm9, xmm10, xmm10, 0x03
000070d6f3dd394b  vptest xmm9, xmm9
000070d6f3dd3950  jnz 0x000070D6F3DD5B21
000070d6f3dd3956  lea r14, [rax+0x20]
000070d6f3dd395a  movups xmm1, [r13+r14*1]
000070d6f3dd3960  lea r14, [rax+0x30]
000070d6f3dd3964  movups xmm15, [r13+r14*1]
000070d6f3dd396a  vmovaps xmm9, [rsp+0xA0]
000070d6f3dd3973  vpermilpd xmm9, xmm9, 0x00
000070d6f3dd3979  movaps xmm7, xmm8
000070d6f3dd397d  vfmadd231pd xmm7, xmm3, xmm9
000070d6f3dd3982  vcmppd xmm6, xmm7, xmm7, 0x03
000070d6f3dd3987  vptest xmm6, xmm6
000070d6f3dd398c  jnz 0x000070D6F3DD5C8D
000070d6f3dd3992  vmovaps xmm9, [rsp+0xA0]
000070d6f3dd399b  vpermilpd xmm9, xmm9, 0x00
000070d6f3dd39a1  movaps xmm8, xmm11
000070d6f3dd39a5  vfmadd231pd xmm8, xmm14, xmm9
000070d6f3dd39aa  vcmppd xmm6, xmm8, xmm8, 0x03
000070d6f3dd39b0  vptest xmm6, xmm6
000070d6f3dd39b5  jnz 0x000070D6F3DD5DE4
000070d6f3dd39bb  vmovaps xmm14, [rsp+0xA0]
000070d6f3dd39c4  vpermilpd xmm14, xmm14, 0x00
000070d6f3dd39ca  movaps xmm11, xmm13
000070d6f3dd39ce  vfmadd231pd xmm11, xmm12, xmm14
000070d6f3dd39d3  vcmppd xmm9, xmm11, xmm11, 0x03
000070d6f3dd39d9  vptest xmm9, xmm9
000070d6f3dd39de  jnz 0x000070D6F3DD5F3E
000070d6f3dd39e4  vmovaps xmm14, [rsp+0xA0]
000070d6f3dd39ed  vpermilpd xmm14, xmm14, 0x00
000070d6f3dd39f3  movaps xmm12, xmm10
000070d6f3dd39f7  vfmadd231pd xmm12, xmm15, xmm14
000070d6f3dd39fc  vcmppd xmm13, xmm12, xmm12, 0x03
000070d6f3dd3a02  vptest xmm13, xmm13
000070d6f3dd3a07  jnz 0x000070D6F3DD6098
000070d6f3dd3a0d  lea r14, [rax+0x90]
000070d6f3dd3a14  movups xmm15, [r13+r14*1]
000070d6f3dd3a1a  lea r14, [rax+0xA0]
000070d6f3dd3a21  movups xmm14, [r13+r14*1]
000070d6f3dd3a27  movaps [r15+0x140], xmm15
000070d6f3dd3a2f  movaps [r15+0x130], xmm14
000070d6f3dd3a37  vmovaps xmm13, [rsp+0x10]
000070d6f3dd3a3d  vpermilpd xmm13, xmm13, 0x00
000070d6f3dd3a43  movaps xmm10, xmm7
000070d6f3dd3a47  vfmadd231pd xmm10, xmm1, xmm13
000070d6f3dd3a4c  vcmppd xmm9, xmm10, xmm10, 0x03
000070d6f3dd3a52  vptest xmm9, xmm9
000070d6f3dd3a57  jnz 0x000070D6F3DD6206
000070d6f3dd3a5d  movaps [r15+0x220], xmm10
000070d6f3dd3a65  lea r14, [rax+0x10]
000070d6f3dd3a69  movups xmm1, [r13+r14*1]
000070d6f3dd3a6f  movaps [r15+0x240], xmm1
000070d6f3dd3a77  vmovaps xmm13, [rsp+0x10]
000070d6f3dd3a7d  vpermilpd xmm13, xmm13, 0x00
000070d6f3dd3a83  movaps xmm9, xmm8
000070d6f3dd3a87  vfmadd231pd xmm9, xmm14, xmm13
000070d6f3dd3a8c  vcmppd xmm7, xmm9, xmm9, 0x03
000070d6f3dd3a92  vptest xmm7, xmm7
000070d6f3dd3a97  jnz 0x000070D6F3DD6368
000070d6f3dd3a9d  movaps [r15+0x110], xmm9
000070d6f3dd3aa5  vmovaps xmm14, [rsp+0x10]
000070d6f3dd3aab  vpermilpd xmm14, xmm14, 0x00
000070d6f3dd3ab1  movaps xmm13, xmm11
000070d6f3dd3ab5  vfmadd231pd xmm13, xmm15, xmm14
000070d6f3dd3aba  vcmppd xmm8, xmm13, xmm13, 0x03
000070d6f3dd3ac0  vptest xmm8, xmm8
000070d6f3dd3ac5  jnz 0x000070D6F3DD64C2
000070d6f3dd3acb  movaps [r15+0x170], xmm13
000070d6f3dd3ad3  vmovaps xmm15, [rsp+0x10]
000070d6f3dd3ad9  vpermilpd xmm15, xmm15, 0x00
000070d6f3dd3adf  movaps xmm14, xmm12
000070d6f3dd3ae3  vfmadd231pd xmm14, xmm1, xmm15
000070d6f3dd3ae8  vcmppd xmm11, xmm14, xmm14, 0x03
000070d6f3dd3aee  vptest xmm11, xmm11
000070d6f3dd3af3  jnz 0x000070D6F3DD661C
000070d6f3dd3af9  movaps [r15+0x230], xmm14
000070d6f3dd3b01  movups [r13+r11*1], xmm9
000070d6f3dd3b07  lea rax, [r11+0x10]
000070d6f3dd3b0b  movups [r13+rax*1], xmm13
000070d6f3dd3b11  lea rax, [r11+0x20]
000070d6f3dd3b15  movups [r13+rax*1], xmm10
000070d6f3dd3b1b  lea rax, [r11+0x30]
000070d6f3dd3b1f  movups [r13+rax*1], xmm14
000070d6f3dd3b25  mov eax, [r15+0x108]
000070d6f3dd3b2c  sahf
000070d6f3dd3b2d  jnz 0x000070D6F3DD3B5F
000070d6f3dd3b2f  cmp dword ptr [r15+0x318], 0x00
000070d6f3dd3b37  jz 0x000070D6F3DD67A0
000070d6f3dd3b3d  nop [rax+rax*1], ax
000070d6f3dd3b46  nop [rax+rax*1], eax
000070d6f3dd3b4e  mov eax, 0x4103F0
000070d6f3dd3b53  mov [r15+0x100], rax
000070d6f3dd3b5a  jmp 0x000070D6F3BFE110
000070d6f3dd3b5f  cmp dword ptr [r15+0x318], 0x00
000070d6f3dd3b67  jz 0x000070D6F3DD2E40
000070d6f3dd3b6d  nop [rax+rax*1], ax
000070d6f3dd3b76  nop [rax+rax*1], eax
000070d6f3dd3b7e  mov eax, 0x410274
000070d6f3dd3b83  mov [r15+0x100], rax
000070d6f3dd3b8a  jmp 0x000070D6F3BFE110
000070d6f3dd3b8f  int3
000070d6f3dd3b90  call 0x000070D6F3C0A4B0
000070d6f3dd3b95  jmp 0x000070D6F3DD2E69
000070d6f3dd3b9a  call 0x000070D6F3C09240
000070d6f3dd3b9f  jmp 0x000070D6F3DD2E73
000070d6f3dd3ba4  call 0x000070D6F3C0A4B0
000070d6f3dd3ba9  jmp 0x000070D6F3DD2EBD
000070d6f3dd3bae  call 0x000070D6F3C09240
000070d6f3dd3bb3  jmp 0x000070D6F3DD2EC7
000070d6f3dd3bb8  call 0x000070D6F3C0A4B0
000070d6f3dd3bbd  jmp 0x000070D6F3DD2F60
000070d6f3dd3bc2  call 0x000070D6F3C09240
000070d6f3dd3bc7  jmp 0x000070D6F3DD2F6A
000070d6f3dd3bcc  call 0x000070D6F3CB47C0
000070d6f3dd3bd1  jmp 0x000070D6F3DD3055
000070d6f3dd3bd6  call 0x000070D6F3BFF430
000070d6f3dd3bdb  jmp 0x000070D6F3DD3084
000070d6f3dd3be0  call 0x000070D6F3CB0CE0
000070d6f3dd3be5  jmp 0x000070D6F3DD30A0
000070d6f3dd3bea  sub rsp, 0x08
000070d6f3dd3bee  push rax
000070d6f3dd3bef  push rcx
000070d6f3dd3bf0  push rdx
000070d6f3dd3bf1  push rdi
000070d6f3dd3bf2  push rsi
000070d6f3dd3bf3  push r8
000070d6f3dd3bf5  push r9
000070d6f3dd3bf7  push r10
000070d6f3dd3bf9  push r11
000070d6f3dd3bfb  sub rsp, 0xF0
000070d6f3dd3c02  vmovaps [rsp], xmm0
000070d6f3dd3c07  vmovaps [rsp+0x10], xmm1
000070d6f3dd3c0d  vmovaps [rsp+0x20], xmm2
000070d6f3dd3c13  vmovaps [rsp+0x30], xmm3
000070d6f3dd3c19  vmovaps [rsp+0x40], xmm4
000070d6f3dd3c1f  vmovaps [rsp+0x50], xmm5
000070d6f3dd3c25  vmovaps [rsp+0x60], xmm6
000070d6f3dd3c2b  vmovaps [rsp+0x70], xmm7
000070d6f3dd3c31  vmovaps [rsp+0x80], xmm8
000070d6f3dd3c3a  vmovaps [rsp+0x90], xmm9
000070d6f3dd3c43  vmovaps [rsp+0xA0], xmm10
000070d6f3dd3c4c  vmovaps [rsp+0xB0], xmm11
000070d6f3dd3c55  vmovaps [rsp+0xC0], xmm12
000070d6f3dd3c5e  vmovaps [rsp+0xD0], xmm14
000070d6f3dd3c67  vmovaps [rsp+0xE0], xmm15
000070d6f3dd3c70  sub rsp, 0x40
000070d6f3dd3c74  lea rdi, [rsp]
000070d6f3dd3c78  lea rsi, [rsp+0x10]
000070d6f3dd3c7d  lea rdx, [rsp+0x20]
000070d6f3dd3c82  lea rcx, [rsp+0x30]
000070d6f3dd3c87  mov r8d, 0x00
000070d6f3dd3c8d  lea r9, [r15+0x3A8]
000070d6f3dd3c94  movaps [rdi], xmm13
000070d6f3dd3c98  movaps [rsi], xmm1
000070d6f3dd3c9b  movaps [rdx], xmm15
000070d6f3dd3c9f  movaps [rcx], xmm14
000070d6f3dd3ca3  mov rax, 0x61D08D40EA50
000070d6f3dd3cad  call rax
000070d6f3dd3caf  movaps xmm13, [rsp]
000070d6f3dd3cb4  add rsp, 0x40
000070d6f3dd3cb8  vmovaps xmm0, [rsp]
000070d6f3dd3cbd  vmovaps xmm1, [rsp+0x10]
000070d6f3dd3cc3  vmovaps xmm2, [rsp+0x20]
000070d6f3dd3cc9  vmovaps xmm3, [rsp+0x30]
000070d6f3dd3ccf  vmovaps xmm4, [rsp+0x40]
000070d6f3dd3cd5  vmovaps xmm5, [rsp+0x50]
000070d6f3dd3cdb  vmovaps xmm6, [rsp+0x60]
000070d6f3dd3ce1  vmovaps xmm7, [rsp+0x70]
000070d6f3dd3ce7  vmovaps xmm8, [rsp+0x80]
000070d6f3dd3cf0  vmovaps xmm9, [rsp+0x90]
000070d6f3dd3cf9  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd3d02  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd3d0b  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd3d14  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd3d1d  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd3d26  add rsp, 0xF0
000070d6f3dd3d2d  pop r11
000070d6f3dd3d2f  pop r10
000070d6f3dd3d31  pop r9
000070d6f3dd3d33  pop r8
000070d6f3dd3d35  pop rsi
000070d6f3dd3d36  pop rdi
000070d6f3dd3d37  pop rdx
000070d6f3dd3d38  pop rcx
000070d6f3dd3d39  pop rax
000070d6f3dd3d3a  add rsp, 0x08
000070d6f3dd3d3e  jmp 0x000070D6F3DD3117
000070d6f3dd3d43  sub rsp, 0x08
000070d6f3dd3d47  push rax
000070d6f3dd3d48  push rcx
000070d6f3dd3d49  push rdx
000070d6f3dd3d4a  push rdi
000070d6f3dd3d4b  push rsi
000070d6f3dd3d4c  push r8
000070d6f3dd3d4e  push r9
000070d6f3dd3d50  push r10
000070d6f3dd3d52  push r11
000070d6f3dd3d54  sub rsp, 0xF0
000070d6f3dd3d5b  vmovaps [rsp], xmm0
000070d6f3dd3d60  vmovaps [rsp+0x10], xmm1
000070d6f3dd3d66  vmovaps [rsp+0x20], xmm2
000070d6f3dd3d6c  vmovaps [rsp+0x30], xmm3
000070d6f3dd3d72  vmovaps [rsp+0x40], xmm4
000070d6f3dd3d78  vmovaps [rsp+0x50], xmm5
000070d6f3dd3d7e  vmovaps [rsp+0x60], xmm6
000070d6f3dd3d84  vmovaps [rsp+0x70], xmm7
000070d6f3dd3d8a  vmovaps [rsp+0x80], xmm8
000070d6f3dd3d93  vmovaps [rsp+0x90], xmm9
000070d6f3dd3d9c  vmovaps [rsp+0xA0], xmm10
000070d6f3dd3da5  vmovaps [rsp+0xB0], xmm11
000070d6f3dd3dae  vmovaps [rsp+0xC0], xmm13
000070d6f3dd3db7  vmovaps [rsp+0xD0], xmm14
000070d6f3dd3dc0  vmovaps [rsp+0xE0], xmm15
000070d6f3dd3dc9  sub rsp, 0x40
000070d6f3dd3dcd  lea rdi, [rsp]
000070d6f3dd3dd1  lea rsi, [rsp+0x10]
000070d6f3dd3dd6  lea rdx, [rsp+0x20]
000070d6f3dd3ddb  lea rcx, [rsp+0x30]
000070d6f3dd3de0  mov r8d, 0x00
000070d6f3dd3de6  lea r9, [r15+0x3A8]
000070d6f3dd3ded  movaps [rdi], xmm12
000070d6f3dd3df1  movaps [rsi], xmm15
000070d6f3dd3df5  movaps [rdx], xmm1
000070d6f3dd3df8  movaps [rcx], xmm14
000070d6f3dd3dfc  mov rax, 0x61D08D40EA50
000070d6f3dd3e06  call rax
000070d6f3dd3e08  movaps xmm12, [rsp]
000070d6f3dd3e0d  add rsp, 0x40
000070d6f3dd3e11  vmovaps xmm0, [rsp]
000070d6f3dd3e16  vmovaps xmm1, [rsp+0x10]
000070d6f3dd3e1c  vmovaps xmm2, [rsp+0x20]
000070d6f3dd3e22  vmovaps xmm3, [rsp+0x30]
000070d6f3dd3e28  vmovaps xmm4, [rsp+0x40]
000070d6f3dd3e2e  vmovaps xmm5, [rsp+0x50]
000070d6f3dd3e34  vmovaps xmm6, [rsp+0x60]
000070d6f3dd3e3a  vmovaps xmm7, [rsp+0x70]
000070d6f3dd3e40  vmovaps xmm8, [rsp+0x80]
000070d6f3dd3e49  vmovaps xmm9, [rsp+0x90]
000070d6f3dd3e52  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd3e5b  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd3e64  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd3e6d  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd3e76  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd3e7f  add rsp, 0xF0
000070d6f3dd3e86  pop r11
000070d6f3dd3e88  pop r10
000070d6f3dd3e8a  pop r9
000070d6f3dd3e8c  pop r8
000070d6f3dd3e8e  pop rsi
000070d6f3dd3e8f  pop rdi
000070d6f3dd3e90  pop rdx
000070d6f3dd3e91  pop rcx
000070d6f3dd3e92  pop rax
000070d6f3dd3e93  add rsp, 0x08
000070d6f3dd3e97  jmp 0x000070D6F3DD3145
000070d6f3dd3e9c  call 0x000070D6F3CD64F0
000070d6f3dd3ea1  jmp 0x000070D6F3DD3231
000070d6f3dd3ea6  sub rsp, 0x08
000070d6f3dd3eaa  push rax
000070d6f3dd3eab  push rcx
000070d6f3dd3eac  push rdx
000070d6f3dd3ead  push rdi
000070d6f3dd3eae  push rsi
000070d6f3dd3eaf  push r8
000070d6f3dd3eb1  push r9
000070d6f3dd3eb3  push r10
000070d6f3dd3eb5  push r11
000070d6f3dd3eb7  sub rsp, 0xF0
000070d6f3dd3ebe  vmovaps [rsp], xmm0
000070d6f3dd3ec3  vmovaps [rsp+0x10], xmm1
000070d6f3dd3ec9  vmovaps [rsp+0x20], xmm2
000070d6f3dd3ecf  vmovaps [rsp+0x30], xmm3
000070d6f3dd3ed5  vmovaps [rsp+0x40], xmm4
000070d6f3dd3edb  vmovaps [rsp+0x50], xmm5
000070d6f3dd3ee1  vmovaps [rsp+0x60], xmm6
000070d6f3dd3ee7  vmovaps [rsp+0x70], xmm7
000070d6f3dd3eed  vmovaps [rsp+0x80], xmm8
000070d6f3dd3ef6  vmovaps [rsp+0x90], xmm9
000070d6f3dd3eff  vmovaps [rsp+0xA0], xmm10
000070d6f3dd3f08  vmovaps [rsp+0xB0], xmm11
000070d6f3dd3f11  vmovaps [rsp+0xC0], xmm12
000070d6f3dd3f1a  vmovaps [rsp+0xD0], xmm14
000070d6f3dd3f23  vmovaps [rsp+0xE0], xmm15
000070d6f3dd3f2c  sub rsp, 0x40
000070d6f3dd3f30  lea rdi, [rsp]
000070d6f3dd3f34  lea rsi, [rsp+0x10]
000070d6f3dd3f39  lea rdx, [rsp+0x20]
000070d6f3dd3f3e  lea rcx, [rsp+0x30]
000070d6f3dd3f43  mov r8d, 0x00
000070d6f3dd3f49  lea r9, [r15+0x3A8]
000070d6f3dd3f50  movaps [rdi], xmm13
000070d6f3dd3f54  movaps [rsi], xmm1
000070d6f3dd3f57  movaps [rdx], xmm15
000070d6f3dd3f5b  movaps [rcx], xmm14
000070d6f3dd3f5f  mov rax, 0x61D08D40EA50
000070d6f3dd3f69  call rax
000070d6f3dd3f6b  movaps xmm13, [rsp]
000070d6f3dd3f70  add rsp, 0x40
000070d6f3dd3f74  vmovaps xmm0, [rsp]
000070d6f3dd3f79  vmovaps xmm1, [rsp+0x10]
000070d6f3dd3f7f  vmovaps xmm2, [rsp+0x20]
000070d6f3dd3f85  vmovaps xmm3, [rsp+0x30]
000070d6f3dd3f8b  vmovaps xmm4, [rsp+0x40]
000070d6f3dd3f91  vmovaps xmm5, [rsp+0x50]
000070d6f3dd3f97  vmovaps xmm6, [rsp+0x60]
000070d6f3dd3f9d  vmovaps xmm7, [rsp+0x70]
000070d6f3dd3fa3  vmovaps xmm8, [rsp+0x80]
000070d6f3dd3fac  vmovaps xmm9, [rsp+0x90]
000070d6f3dd3fb5  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd3fbe  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd3fc7  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd3fd0  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd3fd9  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd3fe2  add rsp, 0xF0
000070d6f3dd3fe9  pop r11
000070d6f3dd3feb  pop r10
000070d6f3dd3fed  pop r9
000070d6f3dd3fef  pop r8
000070d6f3dd3ff1  pop rsi
000070d6f3dd3ff2  pop rdi
000070d6f3dd3ff3  pop rdx
000070d6f3dd3ff4  pop rcx
000070d6f3dd3ff5  pop rax
000070d6f3dd3ff6  add rsp, 0x08
000070d6f3dd3ffa  jmp 0x000070D6F3DD32A0
000070d6f3dd3fff  call 0x000070D6F3CD64F0
000070d6f3dd4004  jmp 0x000070D6F3DD32B5
000070d6f3dd4009  sub rsp, 0x08
000070d6f3dd400d  push rax
000070d6f3dd400e  push rcx
000070d6f3dd400f  push rdx
000070d6f3dd4010  push rdi
000070d6f3dd4011  push rsi
000070d6f3dd4012  push r8
000070d6f3dd4014  push r9
000070d6f3dd4016  push r10
000070d6f3dd4018  push r11
000070d6f3dd401a  sub rsp, 0xF0
000070d6f3dd4021  vmovaps [rsp], xmm0
000070d6f3dd4026  vmovaps [rsp+0x10], xmm1
000070d6f3dd402c  vmovaps [rsp+0x20], xmm2
000070d6f3dd4032  vmovaps [rsp+0x30], xmm3
000070d6f3dd4038  vmovaps [rsp+0x40], xmm4
000070d6f3dd403e  vmovaps [rsp+0x50], xmm5
000070d6f3dd4044  vmovaps [rsp+0x60], xmm6
000070d6f3dd404a  vmovaps [rsp+0x70], xmm7
000070d6f3dd4050  vmovaps [rsp+0x80], xmm8
000070d6f3dd4059  vmovaps [rsp+0x90], xmm9
000070d6f3dd4062  vmovaps [rsp+0xA0], xmm10
000070d6f3dd406b  vmovaps [rsp+0xB0], xmm11
000070d6f3dd4074  vmovaps [rsp+0xC0], xmm13
000070d6f3dd407d  vmovaps [rsp+0xD0], xmm14
000070d6f3dd4086  vmovaps [rsp+0xE0], xmm15
000070d6f3dd408f  sub rsp, 0x40
000070d6f3dd4093  lea rdi, [rsp]
000070d6f3dd4097  lea rsi, [rsp+0x10]
000070d6f3dd409c  lea rdx, [rsp+0x20]
000070d6f3dd40a1  lea rcx, [rsp+0x30]
000070d6f3dd40a6  mov r8d, 0x00
000070d6f3dd40ac  lea r9, [r15+0x3A8]
000070d6f3dd40b3  movaps [rdi], xmm12
000070d6f3dd40b7  movaps [rsi], xmm15
000070d6f3dd40bb  movaps [rdx], xmm1
000070d6f3dd40be  movaps [rcx], xmm14
000070d6f3dd40c2  mov rax, 0x61D08D40EA50
000070d6f3dd40cc  call rax
000070d6f3dd40ce  movaps xmm12, [rsp]
000070d6f3dd40d3  add rsp, 0x40
000070d6f3dd40d7  vmovaps xmm0, [rsp]
000070d6f3dd40dc  vmovaps xmm1, [rsp+0x10]
000070d6f3dd40e2  vmovaps xmm2, [rsp+0x20]
000070d6f3dd40e8  vmovaps xmm3, [rsp+0x30]
000070d6f3dd40ee  vmovaps xmm4, [rsp+0x40]
000070d6f3dd40f4  vmovaps xmm5, [rsp+0x50]
000070d6f3dd40fa  vmovaps xmm6, [rsp+0x60]
000070d6f3dd4100  vmovaps xmm7, [rsp+0x70]
000070d6f3dd4106  vmovaps xmm8, [rsp+0x80]
000070d6f3dd410f  vmovaps xmm9, [rsp+0x90]
000070d6f3dd4118  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd4121  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd412a  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd4133  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd413c  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd4145  add rsp, 0xF0
000070d6f3dd414c  pop r11
000070d6f3dd414e  pop r10
000070d6f3dd4150  pop r9
000070d6f3dd4152  pop r8
000070d6f3dd4154  pop rsi
000070d6f3dd4155  pop rdi
000070d6f3dd4156  pop rdx
000070d6f3dd4157  pop rcx
000070d6f3dd4158  pop rax
000070d6f3dd4159  add rsp, 0x08
000070d6f3dd415d  jmp 0x000070D6F3DD32E1
000070d6f3dd4162  sub rsp, 0x08
000070d6f3dd4166  push rax
000070d6f3dd4167  push rcx
000070d6f3dd4168  push rdx
000070d6f3dd4169  push rdi
000070d6f3dd416a  push rsi
000070d6f3dd416b  push r8
000070d6f3dd416d  push r9
000070d6f3dd416f  push r10
000070d6f3dd4171  push r11
000070d6f3dd4173  sub rsp, 0xF0
000070d6f3dd417a  vmovaps [rsp], xmm0
000070d6f3dd417f  vmovaps [rsp+0x10], xmm1
000070d6f3dd4185  vmovaps [rsp+0x20], xmm2
000070d6f3dd418b  vmovaps [rsp+0x30], xmm3
000070d6f3dd4191  vmovaps [rsp+0x40], xmm4
000070d6f3dd4197  vmovaps [rsp+0x50], xmm5
000070d6f3dd419d  vmovaps [rsp+0x60], xmm6
000070d6f3dd41a3  vmovaps [rsp+0x70], xmm7
000070d6f3dd41a9  vmovaps [rsp+0x80], xmm8
000070d6f3dd41b2  vmovaps [rsp+0x90], xmm9
000070d6f3dd41bb  vmovaps [rsp+0xA0], xmm10
000070d6f3dd41c4  vmovaps [rsp+0xB0], xmm11
000070d6f3dd41cd  vmovaps [rsp+0xC0], xmm12
000070d6f3dd41d6  vmovaps [rsp+0xD0], xmm14
000070d6f3dd41df  vmovaps [rsp+0xE0], xmm15
000070d6f3dd41e8  sub rsp, 0x40
000070d6f3dd41ec  lea rdi, [rsp]
000070d6f3dd41f0  lea rsi, [rsp+0x10]
000070d6f3dd41f5  lea rdx, [rsp+0x20]
000070d6f3dd41fa  lea rcx, [rsp+0x30]
000070d6f3dd41ff  mov r8d, 0x00
000070d6f3dd4205  lea r9, [r15+0x3A8]
000070d6f3dd420c  movaps [rdi], xmm13
000070d6f3dd4210  movaps [rsi], xmm1
000070d6f3dd4213  movaps [rdx], xmm15
000070d6f3dd4217  movaps [rcx], xmm14
000070d6f3dd421b  mov rax, 0x61D08D40EA50
000070d6f3dd4225  call rax
000070d6f3dd4227  movaps xmm13, [rsp]
000070d6f3dd422c  add rsp, 0x40
000070d6f3dd4230  vmovaps xmm0, [rsp]
000070d6f3dd4235  vmovaps xmm1, [rsp+0x10]
000070d6f3dd423b  vmovaps xmm2, [rsp+0x20]
000070d6f3dd4241  vmovaps xmm3, [rsp+0x30]
000070d6f3dd4247  vmovaps xmm4, [rsp+0x40]
000070d6f3dd424d  vmovaps xmm5, [rsp+0x50]
000070d6f3dd4253  vmovaps xmm6, [rsp+0x60]
000070d6f3dd4259  vmovaps xmm7, [rsp+0x70]
000070d6f3dd425f  vmovaps xmm8, [rsp+0x80]
000070d6f3dd4268  vmovaps xmm9, [rsp+0x90]
000070d6f3dd4271  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd427a  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd4283  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd428c  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd4295  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd429e  add rsp, 0xF0
000070d6f3dd42a5  pop r11
000070d6f3dd42a7  pop r10
000070d6f3dd42a9  pop r9
000070d6f3dd42ab  pop r8
000070d6f3dd42ad  pop rsi
000070d6f3dd42ae  pop rdi
000070d6f3dd42af  pop rdx
000070d6f3dd42b0  pop rcx
000070d6f3dd42b1  pop rax
000070d6f3dd42b2  add rsp, 0x08
000070d6f3dd42b6  jmp 0x000070D6F3DD3482
000070d6f3dd42bb  sub rsp, 0x08
000070d6f3dd42bf  push rax
000070d6f3dd42c0  push rcx
000070d6f3dd42c1  push rdx
000070d6f3dd42c2  push rdi
000070d6f3dd42c3  push rsi
000070d6f3dd42c4  push r8
000070d6f3dd42c6  push r9
000070d6f3dd42c8  push r10
000070d6f3dd42ca  push r11
000070d6f3dd42cc  sub rsp, 0xF0
000070d6f3dd42d3  vmovaps [rsp], xmm0
000070d6f3dd42d8  vmovaps [rsp+0x10], xmm1
000070d6f3dd42de  vmovaps [rsp+0x20], xmm2
000070d6f3dd42e4  vmovaps [rsp+0x30], xmm3
000070d6f3dd42ea  vmovaps [rsp+0x40], xmm4
000070d6f3dd42f0  vmovaps [rsp+0x50], xmm5
000070d6f3dd42f6  vmovaps [rsp+0x60], xmm6
000070d6f3dd42fc  vmovaps [rsp+0x70], xmm7
000070d6f3dd4302  vmovaps [rsp+0x80], xmm8
000070d6f3dd430b  vmovaps [rsp+0x90], xmm9
000070d6f3dd4314  vmovaps [rsp+0xA0], xmm10
000070d6f3dd431d  vmovaps [rsp+0xB0], xmm11
000070d6f3dd4326  vmovaps [rsp+0xC0], xmm13
000070d6f3dd432f  vmovaps [rsp+0xD0], xmm14
000070d6f3dd4338  vmovaps [rsp+0xE0], xmm15
000070d6f3dd4341  sub rsp, 0x40
000070d6f3dd4345  lea rdi, [rsp]
000070d6f3dd4349  lea rsi, [rsp+0x10]
000070d6f3dd434e  lea rdx, [rsp+0x20]
000070d6f3dd4353  lea rcx, [rsp+0x30]
000070d6f3dd4358  mov r8d, 0x00
000070d6f3dd435e  lea r9, [r15+0x3A8]
000070d6f3dd4365  movaps [rdi], xmm12
000070d6f3dd4369  movaps [rsi], xmm15
000070d6f3dd436d  movaps [rdx], xmm14
000070d6f3dd4371  movaps [rcx], xmm1
000070d6f3dd4374  mov rax, 0x61D08D40EA50
000070d6f3dd437e  call rax
000070d6f3dd4380  movaps xmm12, [rsp]
000070d6f3dd4385  add rsp, 0x40
000070d6f3dd4389  vmovaps xmm0, [rsp]
000070d6f3dd438e  vmovaps xmm1, [rsp+0x10]
000070d6f3dd4394  vmovaps xmm2, [rsp+0x20]
000070d6f3dd439a  vmovaps xmm3, [rsp+0x30]
000070d6f3dd43a0  vmovaps xmm4, [rsp+0x40]
000070d6f3dd43a6  vmovaps xmm5, [rsp+0x50]
000070d6f3dd43ac  vmovaps xmm6, [rsp+0x60]
000070d6f3dd43b2  vmovaps xmm7, [rsp+0x70]
000070d6f3dd43b8  vmovaps xmm8, [rsp+0x80]
000070d6f3dd43c1  vmovaps xmm9, [rsp+0x90]
000070d6f3dd43ca  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd43d3  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd43dc  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd43e5  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd43ee  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd43f7  add rsp, 0xF0
000070d6f3dd43fe  pop r11
000070d6f3dd4400  pop r10
000070d6f3dd4402  pop r9
000070d6f3dd4404  pop r8
000070d6f3dd4406  pop rsi
000070d6f3dd4407  pop rdi
000070d6f3dd4408  pop rdx
000070d6f3dd4409  pop rcx
000070d6f3dd440a  pop rax
000070d6f3dd440b  add rsp, 0x08
000070d6f3dd440f  jmp 0x000070D6F3DD34C0
000070d6f3dd4414  sub rsp, 0x08
000070d6f3dd4418  push rax
000070d6f3dd4419  push rcx
000070d6f3dd441a  push rdx
000070d6f3dd441b  push rdi
000070d6f3dd441c  push rsi
000070d6f3dd441d  push r8
000070d6f3dd441f  push r9
000070d6f3dd4421  push r10
000070d6f3dd4423  push r11
000070d6f3dd4425  sub rsp, 0xF0
000070d6f3dd442c  vmovaps [rsp], xmm0
000070d6f3dd4431  vmovaps [rsp+0x10], xmm1
000070d6f3dd4437  vmovaps [rsp+0x20], xmm2
000070d6f3dd443d  vmovaps [rsp+0x30], xmm3
000070d6f3dd4443  vmovaps [rsp+0x40], xmm4
000070d6f3dd4449  vmovaps [rsp+0x50], xmm5
000070d6f3dd444f  vmovaps [rsp+0x60], xmm6
000070d6f3dd4455  vmovaps [rsp+0x70], xmm7
000070d6f3dd445b  vmovaps [rsp+0x80], xmm8
000070d6f3dd4464  vmovaps [rsp+0x90], xmm9
000070d6f3dd446d  vmovaps [rsp+0xA0], xmm10
000070d6f3dd4476  vmovaps [rsp+0xB0], xmm11
000070d6f3dd447f  vmovaps [rsp+0xC0], xmm12
000070d6f3dd4488  vmovaps [rsp+0xD0], xmm14
000070d6f3dd4491  vmovaps [rsp+0xE0], xmm15
000070d6f3dd449a  sub rsp, 0x40
000070d6f3dd449e  lea rdi, [rsp]
000070d6f3dd44a2  lea rsi, [rsp+0x10]
000070d6f3dd44a7  lea rdx, [rsp+0x20]
000070d6f3dd44ac  lea rcx, [rsp+0x30]
000070d6f3dd44b1  mov r8d, 0x00
000070d6f3dd44b7  lea r9, [r15+0x3A8]
000070d6f3dd44be  movaps [rdi], xmm13
000070d6f3dd44c2  movaps [rsi], xmm15
000070d6f3dd44c6  movaps [rdx], xmm14
000070d6f3dd44ca  movaps [rcx], xmm1
000070d6f3dd44cd  mov rax, 0x61D08D40EA50
000070d6f3dd44d7  call rax
000070d6f3dd44d9  movaps xmm13, [rsp]
000070d6f3dd44de  add rsp, 0x40
000070d6f3dd44e2  vmovaps xmm0, [rsp]
000070d6f3dd44e7  vmovaps xmm1, [rsp+0x10]
000070d6f3dd44ed  vmovaps xmm2, [rsp+0x20]
000070d6f3dd44f3  vmovaps xmm3, [rsp+0x30]
000070d6f3dd44f9  vmovaps xmm4, [rsp+0x40]
000070d6f3dd44ff  vmovaps xmm5, [rsp+0x50]
000070d6f3dd4505  vmovaps xmm6, [rsp+0x60]
000070d6f3dd450b  vmovaps xmm7, [rsp+0x70]
000070d6f3dd4511  vmovaps xmm8, [rsp+0x80]
000070d6f3dd451a  vmovaps xmm9, [rsp+0x90]
000070d6f3dd4523  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd452c  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd4535  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd453e  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd4547  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd4550  add rsp, 0xF0
000070d6f3dd4557  pop r11
000070d6f3dd4559  pop r10
000070d6f3dd455b  pop r9
000070d6f3dd455d  pop r8
000070d6f3dd455f  pop rsi
000070d6f3dd4560  pop rdi
000070d6f3dd4561  pop rdx
000070d6f3dd4562  pop rcx
000070d6f3dd4563  pop rax
000070d6f3dd4564  add rsp, 0x08
000070d6f3dd4568  jmp 0x000070D6F3DD34FE
000070d6f3dd456d  sub rsp, 0x08
000070d6f3dd4571  push rax
000070d6f3dd4572  push rcx
000070d6f3dd4573  push rdx
000070d6f3dd4574  push rdi
000070d6f3dd4575  push rsi
000070d6f3dd4576  push r8
000070d6f3dd4578  push r9
000070d6f3dd457a  push r10
000070d6f3dd457c  push r11
000070d6f3dd457e  sub rsp, 0xF0
000070d6f3dd4585  vmovaps [rsp], xmm0
000070d6f3dd458a  vmovaps [rsp+0x10], xmm1
000070d6f3dd4590  vmovaps [rsp+0x20], xmm2
000070d6f3dd4596  vmovaps [rsp+0x30], xmm3
000070d6f3dd459c  vmovaps [rsp+0x40], xmm4
000070d6f3dd45a2  vmovaps [rsp+0x50], xmm5
000070d6f3dd45a8  vmovaps [rsp+0x60], xmm6
000070d6f3dd45ae  vmovaps [rsp+0x70], xmm7
000070d6f3dd45b4  vmovaps [rsp+0x80], xmm8
000070d6f3dd45bd  vmovaps [rsp+0x90], xmm9
000070d6f3dd45c6  vmovaps [rsp+0xA0], xmm10
000070d6f3dd45cf  vmovaps [rsp+0xB0], xmm11
000070d6f3dd45d8  vmovaps [rsp+0xC0], xmm13
000070d6f3dd45e1  vmovaps [rsp+0xD0], xmm14
000070d6f3dd45ea  vmovaps [rsp+0xE0], xmm15
000070d6f3dd45f3  sub rsp, 0x40
000070d6f3dd45f7  lea rdi, [rsp]
000070d6f3dd45fb  lea rsi, [rsp+0x10]
000070d6f3dd4600  lea rdx, [rsp+0x20]
000070d6f3dd4605  lea rcx, [rsp+0x30]
000070d6f3dd460a  mov r8d, 0x00
000070d6f3dd4610  lea r9, [r15+0x3A8]
000070d6f3dd4617  movaps [rdi], xmm12
000070d6f3dd461b  movaps [rsi], xmm14
000070d6f3dd461f  movaps [rdx], xmm2
000070d6f3dd4622  movaps [rcx], xmm15
000070d6f3dd4626  mov rax, 0x61D08D40EA50
000070d6f3dd4630  call rax
000070d6f3dd4632  movaps xmm12, [rsp]
000070d6f3dd4637  add rsp, 0x40
000070d6f3dd463b  vmovaps xmm0, [rsp]
000070d6f3dd4640  vmovaps xmm1, [rsp+0x10]
000070d6f3dd4646  vmovaps xmm2, [rsp+0x20]
000070d6f3dd464c  vmovaps xmm3, [rsp+0x30]
000070d6f3dd4652  vmovaps xmm4, [rsp+0x40]
000070d6f3dd4658  vmovaps xmm5, [rsp+0x50]
000070d6f3dd465e  vmovaps xmm6, [rsp+0x60]
000070d6f3dd4664  vmovaps xmm7, [rsp+0x70]
000070d6f3dd466a  vmovaps xmm8, [rsp+0x80]
000070d6f3dd4673  vmovaps xmm9, [rsp+0x90]
000070d6f3dd467c  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd4685  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd468e  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd4697  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd46a0  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd46a9  add rsp, 0xF0
000070d6f3dd46b0  pop r11
000070d6f3dd46b2  pop r10
000070d6f3dd46b4  pop r9
000070d6f3dd46b6  pop r8
000070d6f3dd46b8  pop rsi
000070d6f3dd46b9  pop rdi
000070d6f3dd46ba  pop rdx
000070d6f3dd46bb  pop rcx
000070d6f3dd46bc  pop rax
000070d6f3dd46bd  add rsp, 0x08
000070d6f3dd46c1  jmp 0x000070D6F3DD3558
000070d6f3dd46c6  sub rsp, 0x08
000070d6f3dd46ca  push rax
000070d6f3dd46cb  push rcx
000070d6f3dd46cc  push rdx
000070d6f3dd46cd  push rdi
000070d6f3dd46ce  push rsi
000070d6f3dd46cf  push r8
000070d6f3dd46d1  push r9
000070d6f3dd46d3  push r10
000070d6f3dd46d5  push r11
000070d6f3dd46d7  sub rsp, 0xF0
000070d6f3dd46de  vmovaps [rsp], xmm0
000070d6f3dd46e3  vmovaps [rsp+0x10], xmm1
000070d6f3dd46e9  vmovaps [rsp+0x20], xmm3
000070d6f3dd46ef  vmovaps [rsp+0x30], xmm4
000070d6f3dd46f5  vmovaps [rsp+0x40], xmm5
000070d6f3dd46fb  vmovaps [rsp+0x50], xmm6
000070d6f3dd4701  vmovaps [rsp+0x60], xmm7
000070d6f3dd4707  vmovaps [rsp+0x70], xmm8
000070d6f3dd470d  vmovaps [rsp+0x80], xmm9
000070d6f3dd4716  vmovaps [rsp+0x90], xmm10
000070d6f3dd471f  vmovaps [rsp+0xA0], xmm11
000070d6f3dd4728  vmovaps [rsp+0xB0], xmm12
000070d6f3dd4731  vmovaps [rsp+0xC0], xmm13
000070d6f3dd473a  vmovaps [rsp+0xD0], xmm14
000070d6f3dd4743  vmovaps [rsp+0xE0], xmm15
000070d6f3dd474c  sub rsp, 0x40
000070d6f3dd4750  lea rdi, [rsp]
000070d6f3dd4754  lea rsi, [rsp+0x10]
000070d6f3dd4759  lea rdx, [rsp+0x20]
000070d6f3dd475e  lea rcx, [rsp+0x30]
000070d6f3dd4763  mov r8d, 0x00
000070d6f3dd4769  lea r9, [r15+0x3A8]
000070d6f3dd4770  movaps [rdi], xmm2
000070d6f3dd4773  movaps [rsi], xmm14
000070d6f3dd4777  movaps [rdx], xmm8
000070d6f3dd477b  movaps [rcx], xmm5
000070d6f3dd477e  mov rax, 0x61D08D40EA50
000070d6f3dd4788  call rax
000070d6f3dd478a  movaps xmm2, [rsp]
000070d6f3dd478e  add rsp, 0x40
000070d6f3dd4792  vmovaps xmm0, [rsp]
000070d6f3dd4797  vmovaps xmm1, [rsp+0x10]
000070d6f3dd479d  vmovaps xmm3, [rsp+0x20]
000070d6f3dd47a3  vmovaps xmm4, [rsp+0x30]
000070d6f3dd47a9  vmovaps xmm5, [rsp+0x40]
000070d6f3dd47af  vmovaps xmm6, [rsp+0x50]
000070d6f3dd47b5  vmovaps xmm7, [rsp+0x60]
000070d6f3dd47bb  vmovaps xmm8, [rsp+0x70]
000070d6f3dd47c1  vmovaps xmm9, [rsp+0x80]
000070d6f3dd47ca  vmovaps xmm10, [rsp+0x90]
000070d6f3dd47d3  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd47dc  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd47e5  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd47ee  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd47f7  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd4800  add rsp, 0xF0
000070d6f3dd4807  pop r11
000070d6f3dd4809  pop r10
000070d6f3dd480b  pop r9
000070d6f3dd480d  pop r8
000070d6f3dd480f  pop rsi
000070d6f3dd4810  pop rdi
000070d6f3dd4811  pop rdx
000070d6f3dd4812  pop rcx
000070d6f3dd4813  pop rax
000070d6f3dd4814  add rsp, 0x08
000070d6f3dd4818  jmp 0x000070D6F3DD360C
000070d6f3dd481d  sub rsp, 0x08
000070d6f3dd4821  push rax
000070d6f3dd4822  push rcx
000070d6f3dd4823  push rdx
000070d6f3dd4824  push rdi
000070d6f3dd4825  push rsi
000070d6f3dd4826  push r8
000070d6f3dd4828  push r9
000070d6f3dd482a  push r10
000070d6f3dd482c  push r11
000070d6f3dd482e  sub rsp, 0xF0
000070d6f3dd4835  vmovaps [rsp], xmm0
000070d6f3dd483a  vmovaps [rsp+0x10], xmm1
000070d6f3dd4840  vmovaps [rsp+0x20], xmm2
000070d6f3dd4846  vmovaps [rsp+0x30], xmm3
000070d6f3dd484c  vmovaps [rsp+0x40], xmm4
000070d6f3dd4852  vmovaps [rsp+0x50], xmm6
000070d6f3dd4858  vmovaps [rsp+0x60], xmm7
000070d6f3dd485e  vmovaps [rsp+0x70], xmm8
000070d6f3dd4864  vmovaps [rsp+0x80], xmm9
000070d6f3dd486d  vmovaps [rsp+0x90], xmm10
000070d6f3dd4876  vmovaps [rsp+0xA0], xmm11
000070d6f3dd487f  vmovaps [rsp+0xB0], xmm12
000070d6f3dd4888  vmovaps [rsp+0xC0], xmm13
000070d6f3dd4891  vmovaps [rsp+0xD0], xmm14
000070d6f3dd489a  vmovaps [rsp+0xE0], xmm15
000070d6f3dd48a3  sub rsp, 0x40
000070d6f3dd48a7  lea rdi, [rsp]
000070d6f3dd48ab  lea rsi, [rsp+0x10]
000070d6f3dd48b0  lea rdx, [rsp+0x20]
000070d6f3dd48b5  lea rcx, [rsp+0x30]
000070d6f3dd48ba  mov r8d, 0x00
000070d6f3dd48c0  lea r9, [r15+0x3A8]
000070d6f3dd48c7  movaps [rdi], xmm5
000070d6f3dd48ca  movaps [rsi], xmm14
000070d6f3dd48ce  movaps [rdx], xmm8
000070d6f3dd48d2  movaps [rcx], xmm1
000070d6f3dd48d5  mov rax, 0x61D08D40EA50
000070d6f3dd48df  call rax
000070d6f3dd48e1  movaps xmm5, [rsp]
000070d6f3dd48e5  add rsp, 0x40
000070d6f3dd48e9  vmovaps xmm0, [rsp]
000070d6f3dd48ee  vmovaps xmm1, [rsp+0x10]
000070d6f3dd48f4  vmovaps xmm2, [rsp+0x20]
000070d6f3dd48fa  vmovaps xmm3, [rsp+0x30]
000070d6f3dd4900  vmovaps xmm4, [rsp+0x40]
000070d6f3dd4906  vmovaps xmm6, [rsp+0x50]
000070d6f3dd490c  vmovaps xmm7, [rsp+0x60]
000070d6f3dd4912  vmovaps xmm8, [rsp+0x70]
000070d6f3dd4918  vmovaps xmm9, [rsp+0x80]
000070d6f3dd4921  vmovaps xmm10, [rsp+0x90]
000070d6f3dd492a  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd4933  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd493c  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd4945  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd494e  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd4957  add rsp, 0xF0
000070d6f3dd495e  pop r11
000070d6f3dd4960  pop r10
000070d6f3dd4962  pop r9
000070d6f3dd4964  pop r8
000070d6f3dd4966  pop rsi
000070d6f3dd4967  pop rdi
000070d6f3dd4968  pop rdx
000070d6f3dd4969  pop rcx
000070d6f3dd496a  pop rax
000070d6f3dd496b  add rsp, 0x08
000070d6f3dd496f  jmp 0x000070D6F3DD3649
000070d6f3dd4974  sub rsp, 0x08
000070d6f3dd4978  push rax
000070d6f3dd4979  push rcx
000070d6f3dd497a  push rdx
000070d6f3dd497b  push rdi
000070d6f3dd497c  push rsi
000070d6f3dd497d  push r8
000070d6f3dd497f  push r9
000070d6f3dd4981  push r10
000070d6f3dd4983  push r11
000070d6f3dd4985  sub rsp, 0xF0
000070d6f3dd498c  vmovaps [rsp], xmm0
000070d6f3dd4991  vmovaps [rsp+0x10], xmm1
000070d6f3dd4997  vmovaps [rsp+0x20], xmm2
000070d6f3dd499d  vmovaps [rsp+0x30], xmm3
000070d6f3dd49a3  vmovaps [rsp+0x40], xmm4
000070d6f3dd49a9  vmovaps [rsp+0x50], xmm5
000070d6f3dd49af  vmovaps [rsp+0x60], xmm6
000070d6f3dd49b5  vmovaps [rsp+0x70], xmm7
000070d6f3dd49bb  vmovaps [rsp+0x80], xmm8
000070d6f3dd49c4  vmovaps [rsp+0x90], xmm9
000070d6f3dd49cd  vmovaps [rsp+0xA0], xmm10
000070d6f3dd49d6  vmovaps [rsp+0xB0], xmm11
000070d6f3dd49df  vmovaps [rsp+0xC0], xmm12
000070d6f3dd49e8  vmovaps [rsp+0xD0], xmm13
000070d6f3dd49f1  vmovaps [rsp+0xE0], xmm14
000070d6f3dd49fa  sub rsp, 0x40
000070d6f3dd49fe  lea rdi, [rsp]
000070d6f3dd4a02  lea rsi, [rsp+0x10]
000070d6f3dd4a07  lea rdx, [rsp+0x20]
000070d6f3dd4a0c  lea rcx, [rsp+0x30]
000070d6f3dd4a11  mov r8d, 0x00
000070d6f3dd4a17  lea r9, [r15+0x3A8]
000070d6f3dd4a1e  movaps [rdi], xmm15
000070d6f3dd4a22  movaps [rsi], xmm13
000070d6f3dd4a26  movaps [rdx], xmm14
000070d6f3dd4a2a  movaps [rcx], xmm1
000070d6f3dd4a2d  mov rax, 0x61D08D40EA50
000070d6f3dd4a37  call rax
000070d6f3dd4a39  movaps xmm15, [rsp]
000070d6f3dd4a3e  add rsp, 0x40
000070d6f3dd4a42  vmovaps xmm0, [rsp]
000070d6f3dd4a47  vmovaps xmm1, [rsp+0x10]
000070d6f3dd4a4d  vmovaps xmm2, [rsp+0x20]
000070d6f3dd4a53  vmovaps xmm3, [rsp+0x30]
000070d6f3dd4a59  vmovaps xmm4, [rsp+0x40]
000070d6f3dd4a5f  vmovaps xmm5, [rsp+0x50]
000070d6f3dd4a65  vmovaps xmm6, [rsp+0x60]
000070d6f3dd4a6b  vmovaps xmm7, [rsp+0x70]
000070d6f3dd4a71  vmovaps xmm8, [rsp+0x80]
000070d6f3dd4a7a  vmovaps xmm9, [rsp+0x90]
000070d6f3dd4a83  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd4a8c  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd4a95  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd4a9e  vmovaps xmm13, [rsp+0xD0]
000070d6f3dd4aa7  vmovaps xmm14, [rsp+0xE0]
000070d6f3dd4ab0  add rsp, 0xF0
000070d6f3dd4ab7  pop r11
000070d6f3dd4ab9  pop r10
000070d6f3dd4abb  pop r9
000070d6f3dd4abd  pop r8
000070d6f3dd4abf  pop rsi
000070d6f3dd4ac0  pop rdi
000070d6f3dd4ac1  pop rdx
000070d6f3dd4ac2  pop rcx
000070d6f3dd4ac3  pop rax
000070d6f3dd4ac4  add rsp, 0x08
000070d6f3dd4ac8  jmp 0x000070D6F3DD3678
000070d6f3dd4acd  sub rsp, 0x08
000070d6f3dd4ad1  push rax
000070d6f3dd4ad2  push rcx
000070d6f3dd4ad3  push rdx
000070d6f3dd4ad4  push rdi
000070d6f3dd4ad5  push rsi
000070d6f3dd4ad6  push r8
000070d6f3dd4ad8  push r9
000070d6f3dd4ada  push r10
000070d6f3dd4adc  push r11
000070d6f3dd4ade  sub rsp, 0xF0
000070d6f3dd4ae5  vmovaps [rsp], xmm0
000070d6f3dd4aea  vmovaps [rsp+0x10], xmm1
000070d6f3dd4af0  vmovaps [rsp+0x20], xmm2
000070d6f3dd4af6  vmovaps [rsp+0x30], xmm3
000070d6f3dd4afc  vmovaps [rsp+0x40], xmm4
000070d6f3dd4b02  vmovaps [rsp+0x50], xmm5
000070d6f3dd4b08  vmovaps [rsp+0x60], xmm6
000070d6f3dd4b0e  vmovaps [rsp+0x70], xmm7
000070d6f3dd4b14  vmovaps [rsp+0x80], xmm8
000070d6f3dd4b1d  vmovaps [rsp+0x90], xmm9
000070d6f3dd4b26  vmovaps [rsp+0xA0], xmm10
000070d6f3dd4b2f  vmovaps [rsp+0xB0], xmm11
000070d6f3dd4b38  vmovaps [rsp+0xC0], xmm12
000070d6f3dd4b41  vmovaps [rsp+0xD0], xmm14
000070d6f3dd4b4a  vmovaps [rsp+0xE0], xmm15
000070d6f3dd4b53  sub rsp, 0x40
000070d6f3dd4b57  lea rdi, [rsp]
000070d6f3dd4b5b  lea rsi, [rsp+0x10]
000070d6f3dd4b60  lea rdx, [rsp+0x20]
000070d6f3dd4b65  lea rcx, [rsp+0x30]
000070d6f3dd4b6a  mov r8d, 0x00
000070d6f3dd4b70  lea r9, [r15+0x3A8]
000070d6f3dd4b77  movaps [rdi], xmm13
000070d6f3dd4b7b  movaps [rsi], xmm12
000070d6f3dd4b7f  movaps [rdx], xmm14
000070d6f3dd4b83  movaps [rcx], xmm1
000070d6f3dd4b86  mov rax, 0x61D08D40EA50
000070d6f3dd4b90  call rax
000070d6f3dd4b92  movaps xmm13, [rsp]
000070d6f3dd4b97  add rsp, 0x40
000070d6f3dd4b9b  vmovaps xmm0, [rsp]
000070d6f3dd4ba0  vmovaps xmm1, [rsp+0x10]
000070d6f3dd4ba6  vmovaps xmm2, [rsp+0x20]
000070d6f3dd4bac  vmovaps xmm3, [rsp+0x30]
000070d6f3dd4bb2  vmovaps xmm4, [rsp+0x40]
000070d6f3dd4bb8  vmovaps xmm5, [rsp+0x50]
000070d6f3dd4bbe  vmovaps xmm6, [rsp+0x60]
000070d6f3dd4bc4  vmovaps xmm7, [rsp+0x70]
000070d6f3dd4bca  vmovaps xmm8, [rsp+0x80]
000070d6f3dd4bd3  vmovaps xmm9, [rsp+0x90]
000070d6f3dd4bdc  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd4be5  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd4bee  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd4bf7  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd4c00  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd4c09  add rsp, 0xF0
000070d6f3dd4c10  pop r11
000070d6f3dd4c12  pop r10
000070d6f3dd4c14  pop r9
000070d6f3dd4c16  pop r8
000070d6f3dd4c18  pop rsi
000070d6f3dd4c19  pop rdi
000070d6f3dd4c1a  pop rdx
000070d6f3dd4c1b  pop rcx
000070d6f3dd4c1c  pop rax
000070d6f3dd4c1d  add rsp, 0x08
000070d6f3dd4c21  jmp 0x000070D6F3DD36AA
000070d6f3dd4c26  sub rsp, 0x08
000070d6f3dd4c2a  push rax
000070d6f3dd4c2b  push rcx
000070d6f3dd4c2c  push rdx
000070d6f3dd4c2d  push rdi
000070d6f3dd4c2e  push rsi
000070d6f3dd4c2f  push r8
000070d6f3dd4c31  push r9
000070d6f3dd4c33  push r10
000070d6f3dd4c35  push r11
000070d6f3dd4c37  sub rsp, 0xF0
000070d6f3dd4c3e  vmovaps [rsp], xmm0
000070d6f3dd4c43  vmovaps [rsp+0x10], xmm1
000070d6f3dd4c49  vmovaps [rsp+0x20], xmm2
000070d6f3dd4c4f  vmovaps [rsp+0x30], xmm3
000070d6f3dd4c55  vmovaps [rsp+0x40], xmm4
000070d6f3dd4c5b  vmovaps [rsp+0x50], xmm5
000070d6f3dd4c61  vmovaps [rsp+0x60], xmm6
000070d6f3dd4c67  vmovaps [rsp+0x70], xmm7
000070d6f3dd4c6d  vmovaps [rsp+0x80], xmm8
000070d6f3dd4c76  vmovaps [rsp+0x90], xmm9
000070d6f3dd4c7f  vmovaps [rsp+0xA0], xmm10
000070d6f3dd4c88  vmovaps [rsp+0xB0], xmm11
000070d6f3dd4c91  vmovaps [rsp+0xC0], xmm13
000070d6f3dd4c9a  vmovaps [rsp+0xD0], xmm14
000070d6f3dd4ca3  vmovaps [rsp+0xE0], xmm15
000070d6f3dd4cac  sub rsp, 0x40
000070d6f3dd4cb0  lea rdi, [rsp]
000070d6f3dd4cb4  lea rsi, [rsp+0x10]
000070d6f3dd4cb9  lea rdx, [rsp+0x20]
000070d6f3dd4cbe  lea rcx, [rsp+0x30]
000070d6f3dd4cc3  mov r8d, 0x00
000070d6f3dd4cc9  lea r9, [r15+0x3A8]
000070d6f3dd4cd0  movaps [rdi], xmm12
000070d6f3dd4cd4  movaps [rsi], xmm5
000070d6f3dd4cd7  movaps [rdx], xmm14
000070d6f3dd4cdb  movaps [rcx], xmm4
000070d6f3dd4cde  mov rax, 0x61D08D40EA50
000070d6f3dd4ce8  call rax
000070d6f3dd4cea  movaps xmm12, [rsp]
000070d6f3dd4cef  add rsp, 0x40
000070d6f3dd4cf3  vmovaps xmm0, [rsp]
000070d6f3dd4cf8  vmovaps xmm1, [rsp+0x10]
000070d6f3dd4cfe  vmovaps xmm2, [rsp+0x20]
000070d6f3dd4d04  vmovaps xmm3, [rsp+0x30]
000070d6f3dd4d0a  vmovaps xmm4, [rsp+0x40]
000070d6f3dd4d10  vmovaps xmm5, [rsp+0x50]
000070d6f3dd4d16  vmovaps xmm6, [rsp+0x60]
000070d6f3dd4d1c  vmovaps xmm7, [rsp+0x70]
000070d6f3dd4d22  vmovaps xmm8, [rsp+0x80]
000070d6f3dd4d2b  vmovaps xmm9, [rsp+0x90]
000070d6f3dd4d34  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd4d3d  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd4d46  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd4d4f  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd4d58  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd4d61  add rsp, 0xF0
000070d6f3dd4d68  pop r11
000070d6f3dd4d6a  pop r10
000070d6f3dd4d6c  pop r9
000070d6f3dd4d6e  pop r8
000070d6f3dd4d70  pop rsi
000070d6f3dd4d71  pop rdi
000070d6f3dd4d72  pop rdx
000070d6f3dd4d73  pop rcx
000070d6f3dd4d74  pop rax
000070d6f3dd4d75  add rsp, 0x08
000070d6f3dd4d79  jmp 0x000070D6F3DD3720
000070d6f3dd4d7e  sub rsp, 0x08
000070d6f3dd4d82  push rax
000070d6f3dd4d83  push rcx
000070d6f3dd4d84  push rdx
000070d6f3dd4d85  push rdi
000070d6f3dd4d86  push rsi
000070d6f3dd4d87  push r8
000070d6f3dd4d89  push r9
000070d6f3dd4d8b  push r10
000070d6f3dd4d8d  push r11
000070d6f3dd4d8f  sub rsp, 0xF0
000070d6f3dd4d96  vmovaps [rsp], xmm0
000070d6f3dd4d9b  vmovaps [rsp+0x10], xmm1
000070d6f3dd4da1  vmovaps [rsp+0x20], xmm2
000070d6f3dd4da7  vmovaps [rsp+0x30], xmm3
000070d6f3dd4dad  vmovaps [rsp+0x40], xmm4
000070d6f3dd4db3  vmovaps [rsp+0x50], xmm5
000070d6f3dd4db9  vmovaps [rsp+0x60], xmm6
000070d6f3dd4dbf  vmovaps [rsp+0x70], xmm7
000070d6f3dd4dc5  vmovaps [rsp+0x80], xmm8
000070d6f3dd4dce  vmovaps [rsp+0x90], xmm9
000070d6f3dd4dd7  vmovaps [rsp+0xA0], xmm11
000070d6f3dd4de0  vmovaps [rsp+0xB0], xmm12
000070d6f3dd4de9  vmovaps [rsp+0xC0], xmm13
000070d6f3dd4df2  vmovaps [rsp+0xD0], xmm14
000070d6f3dd4dfb  vmovaps [rsp+0xE0], xmm15
000070d6f3dd4e04  sub rsp, 0x40
000070d6f3dd4e08  lea rdi, [rsp]
000070d6f3dd4e0c  lea rsi, [rsp+0x10]
000070d6f3dd4e11  lea rdx, [rsp+0x20]
000070d6f3dd4e16  lea rcx, [rsp+0x30]
000070d6f3dd4e1b  mov r8d, 0x00
000070d6f3dd4e21  lea r9, [r15+0x3A8]
000070d6f3dd4e28  movaps [rdi], xmm10
000070d6f3dd4e2c  movaps [rsi], xmm2
000070d6f3dd4e2f  movaps [rdx], xmm6
000070d6f3dd4e32  movaps [rcx], xmm14
000070d6f3dd4e36  mov rax, 0x61D08D40EA50
000070d6f3dd4e40  call rax
000070d6f3dd4e42  movaps xmm10, [rsp]
000070d6f3dd4e47  add rsp, 0x40
000070d6f3dd4e4b  vmovaps xmm0, [rsp]
000070d6f3dd4e50  vmovaps xmm1, [rsp+0x10]
000070d6f3dd4e56  vmovaps xmm2, [rsp+0x20]
000070d6f3dd4e5c  vmovaps xmm3, [rsp+0x30]
000070d6f3dd4e62  vmovaps xmm4, [rsp+0x40]
000070d6f3dd4e68  vmovaps xmm5, [rsp+0x50]
000070d6f3dd4e6e  vmovaps xmm6, [rsp+0x60]
000070d6f3dd4e74  vmovaps xmm7, [rsp+0x70]
000070d6f3dd4e7a  vmovaps xmm8, [rsp+0x80]
000070d6f3dd4e83  vmovaps xmm9, [rsp+0x90]
000070d6f3dd4e8c  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd4e95  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd4e9e  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd4ea7  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd4eb0  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd4eb9  add rsp, 0xF0
000070d6f3dd4ec0  pop r11
000070d6f3dd4ec2  pop r10
000070d6f3dd4ec4  pop r9
000070d6f3dd4ec6  pop r8
000070d6f3dd4ec8  pop rsi
000070d6f3dd4ec9  pop rdi
000070d6f3dd4eca  pop rdx
000070d6f3dd4ecb  pop rcx
000070d6f3dd4ecc  pop rax
000070d6f3dd4ecd  add rsp, 0x08
000070d6f3dd4ed1  jmp 0x000070D6F3DD3746
000070d6f3dd4ed6  call 0x000070D6F3CE45A0
000070d6f3dd4edb  jmp 0x000070D6F3DD3753
000070d6f3dd4ee0  sub rsp, 0x08
000070d6f3dd4ee4  push rax
000070d6f3dd4ee5  push rcx
000070d6f3dd4ee6  push rdx
000070d6f3dd4ee7  push rdi
000070d6f3dd4ee8  push rsi
000070d6f3dd4ee9  push r8
000070d6f3dd4eeb  push r9
000070d6f3dd4eed  push r10
000070d6f3dd4eef  push r11
000070d6f3dd4ef1  sub rsp, 0xF0
000070d6f3dd4ef8  vmovaps [rsp], xmm0
000070d6f3dd4efd  vmovaps [rsp+0x10], xmm1
000070d6f3dd4f03  vmovaps [rsp+0x20], xmm2
000070d6f3dd4f09  vmovaps [rsp+0x30], xmm3
000070d6f3dd4f0f  vmovaps [rsp+0x40], xmm4
000070d6f3dd4f15  vmovaps [rsp+0x50], xmm6
000070d6f3dd4f1b  vmovaps [rsp+0x60], xmm7
000070d6f3dd4f21  vmovaps [rsp+0x70], xmm8
000070d6f3dd4f27  vmovaps [rsp+0x80], xmm9
000070d6f3dd4f30  vmovaps [rsp+0x90], xmm10
000070d6f3dd4f39  vmovaps [rsp+0xA0], xmm11
000070d6f3dd4f42  vmovaps [rsp+0xB0], xmm12
000070d6f3dd4f4b  vmovaps [rsp+0xC0], xmm13
000070d6f3dd4f54  vmovaps [rsp+0xD0], xmm14
000070d6f3dd4f5d  vmovaps [rsp+0xE0], xmm15
000070d6f3dd4f66  sub rsp, 0x40
000070d6f3dd4f6a  lea rdi, [rsp]
000070d6f3dd4f6e  lea rsi, [rsp+0x10]
000070d6f3dd4f73  lea rdx, [rsp+0x20]
000070d6f3dd4f78  lea rcx, [rsp+0x30]
000070d6f3dd4f7d  mov r8d, 0x00
000070d6f3dd4f83  lea r9, [r15+0x3A8]
000070d6f3dd4f8a  movaps [rdi], xmm5
000070d6f3dd4f8d  movaps [rsi], xmm15
000070d6f3dd4f91  movaps [rdx], xmm6
000070d6f3dd4f94  movaps [rcx], xmm8
000070d6f3dd4f98  mov rax, 0x61D08D40EA50
000070d6f3dd4fa2  call rax
000070d6f3dd4fa4  movaps xmm5, [rsp]
000070d6f3dd4fa8  add rsp, 0x40
000070d6f3dd4fac  vmovaps xmm0, [rsp]
000070d6f3dd4fb1  vmovaps xmm1, [rsp+0x10]
000070d6f3dd4fb7  vmovaps xmm2, [rsp+0x20]
000070d6f3dd4fbd  vmovaps xmm3, [rsp+0x30]
000070d6f3dd4fc3  vmovaps xmm4, [rsp+0x40]
000070d6f3dd4fc9  vmovaps xmm6, [rsp+0x50]
000070d6f3dd4fcf  vmovaps xmm7, [rsp+0x60]
000070d6f3dd4fd5  vmovaps xmm8, [rsp+0x70]
000070d6f3dd4fdb  vmovaps xmm9, [rsp+0x80]
000070d6f3dd4fe4  vmovaps xmm10, [rsp+0x90]
000070d6f3dd4fed  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd4ff6  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd4fff  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd5008  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd5011  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd501a  add rsp, 0xF0
000070d6f3dd5021  pop r11
000070d6f3dd5023  pop r10
000070d6f3dd5025  pop r9
000070d6f3dd5027  pop r8
000070d6f3dd5029  pop rsi
000070d6f3dd502a  pop rdi
000070d6f3dd502b  pop rdx
000070d6f3dd502c  pop rcx
000070d6f3dd502d  pop rax
000070d6f3dd502e  add rsp, 0x08
000070d6f3dd5032  jmp 0x000070D6F3DD3789
000070d6f3dd5037  sub rsp, 0x08
000070d6f3dd503b  push rax
000070d6f3dd503c  push rcx
000070d6f3dd503d  push rdx
000070d6f3dd503e  push rdi
000070d6f3dd503f  push rsi
000070d6f3dd5040  push r8
000070d6f3dd5042  push r9
000070d6f3dd5044  push r10
000070d6f3dd5046  push r11
000070d6f3dd5048  sub rsp, 0xF0
000070d6f3dd504f  vmovaps [rsp], xmm0
000070d6f3dd5054  vmovaps [rsp+0x10], xmm1
000070d6f3dd505a  vmovaps [rsp+0x20], xmm2
000070d6f3dd5060  vmovaps [rsp+0x30], xmm3
000070d6f3dd5066  vmovaps [rsp+0x40], xmm4
000070d6f3dd506c  vmovaps [rsp+0x50], xmm5
000070d6f3dd5072  vmovaps [rsp+0x60], xmm6
000070d6f3dd5078  vmovaps [rsp+0x70], xmm7
000070d6f3dd507e  vmovaps [rsp+0x80], xmm9
000070d6f3dd5087  vmovaps [rsp+0x90], xmm10
000070d6f3dd5090  vmovaps [rsp+0xA0], xmm11
000070d6f3dd5099  vmovaps [rsp+0xB0], xmm12
000070d6f3dd50a2  vmovaps [rsp+0xC0], xmm13
000070d6f3dd50ab  vmovaps [rsp+0xD0], xmm14
000070d6f3dd50b4  vmovaps [rsp+0xE0], xmm15
000070d6f3dd50bd  sub rsp, 0x40
000070d6f3dd50c1  lea rdi, [rsp]
000070d6f3dd50c5  lea rsi, [rsp+0x10]
000070d6f3dd50ca  lea rdx, [rsp+0x20]
000070d6f3dd50cf  lea rcx, [rsp+0x30]
000070d6f3dd50d4  mov r8d, 0x00
000070d6f3dd50da  lea r9, [r15+0x3A8]
000070d6f3dd50e1  movaps [rdi], xmm8
000070d6f3dd50e5  movaps [rsi], xmm13
000070d6f3dd50e9  movaps [rdx], xmm1
000070d6f3dd50ec  movaps [rcx], xmm15
000070d6f3dd50f0  mov rax, 0x61D08D40EA50
000070d6f3dd50fa  call rax
000070d6f3dd50fc  movaps xmm8, [rsp]
000070d6f3dd5101  add rsp, 0x40
000070d6f3dd5105  vmovaps xmm0, [rsp]
000070d6f3dd510a  vmovaps xmm1, [rsp+0x10]
000070d6f3dd5110  vmovaps xmm2, [rsp+0x20]
000070d6f3dd5116  vmovaps xmm3, [rsp+0x30]
000070d6f3dd511c  vmovaps xmm4, [rsp+0x40]
000070d6f3dd5122  vmovaps xmm5, [rsp+0x50]
000070d6f3dd5128  vmovaps xmm6, [rsp+0x60]
000070d6f3dd512e  vmovaps xmm7, [rsp+0x70]
000070d6f3dd5134  vmovaps xmm9, [rsp+0x80]
000070d6f3dd513d  vmovaps xmm10, [rsp+0x90]
000070d6f3dd5146  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd514f  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd5158  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd5161  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd516a  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd5173  add rsp, 0xF0
000070d6f3dd517a  pop r11
000070d6f3dd517c  pop r10
000070d6f3dd517e  pop r9
000070d6f3dd5180  pop r8
000070d6f3dd5182  pop rsi
000070d6f3dd5183  pop rdi
000070d6f3dd5184  pop rdx
000070d6f3dd5185  pop rcx
000070d6f3dd5186  pop rax
000070d6f3dd5187  add rsp, 0x08
000070d6f3dd518b  jmp 0x000070D6F3DD37AF
000070d6f3dd5190  call 0x000070D6F3CE5820
000070d6f3dd5195  jmp 0x000070D6F3DD37D2
000070d6f3dd519a  call 0x000070D6F3CE3320
000070d6f3dd519f  jmp 0x000070D6F3DD37DC
000070d6f3dd51a4  sub rsp, 0x08
000070d6f3dd51a8  push rax
000070d6f3dd51a9  push rcx
000070d6f3dd51aa  push rdx
000070d6f3dd51ab  push rdi
000070d6f3dd51ac  push rsi
000070d6f3dd51ad  push r8
000070d6f3dd51af  push r9
000070d6f3dd51b1  push r10
000070d6f3dd51b3  push r11
000070d6f3dd51b5  sub rsp, 0xF0
000070d6f3dd51bc  vmovaps [rsp], xmm0
000070d6f3dd51c1  vmovaps [rsp+0x10], xmm1
000070d6f3dd51c7  vmovaps [rsp+0x20], xmm2
000070d6f3dd51cd  vmovaps [rsp+0x30], xmm3
000070d6f3dd51d3  vmovaps [rsp+0x40], xmm5
000070d6f3dd51d9  vmovaps [rsp+0x50], xmm6
000070d6f3dd51df  vmovaps [rsp+0x60], xmm7
000070d6f3dd51e5  vmovaps [rsp+0x70], xmm8
000070d6f3dd51eb  vmovaps [rsp+0x80], xmm9
000070d6f3dd51f4  vmovaps [rsp+0x90], xmm10
000070d6f3dd51fd  vmovaps [rsp+0xA0], xmm11
000070d6f3dd5206  vmovaps [rsp+0xB0], xmm12
000070d6f3dd520f  vmovaps [rsp+0xC0], xmm13
000070d6f3dd5218  vmovaps [rsp+0xD0], xmm14
000070d6f3dd5221  vmovaps [rsp+0xE0], xmm15
000070d6f3dd522a  sub rsp, 0x40
000070d6f3dd522e  lea rdi, [rsp]
000070d6f3dd5232  lea rsi, [rsp+0x10]
000070d6f3dd5237  lea rdx, [rsp+0x20]
000070d6f3dd523c  lea rcx, [rsp+0x30]
000070d6f3dd5241  mov r8d, 0x00
000070d6f3dd5247  lea r9, [r15+0x3A8]
000070d6f3dd524e  movaps [rdi], xmm4
000070d6f3dd5251  movaps [rsi], xmm12
000070d6f3dd5255  movaps [rdx], xmm9
000070d6f3dd5259  movaps [rcx], xmm6
000070d6f3dd525c  mov rax, 0x61D08D40EA50
000070d6f3dd5266  call rax
000070d6f3dd5268  movaps xmm4, [rsp]
000070d6f3dd526c  add rsp, 0x40
000070d6f3dd5270  vmovaps xmm0, [rsp]
000070d6f3dd5275  vmovaps xmm1, [rsp+0x10]
000070d6f3dd527b  vmovaps xmm2, [rsp+0x20]
000070d6f3dd5281  vmovaps xmm3, [rsp+0x30]
000070d6f3dd5287  vmovaps xmm5, [rsp+0x40]
000070d6f3dd528d  vmovaps xmm6, [rsp+0x50]
000070d6f3dd5293  vmovaps xmm7, [rsp+0x60]
000070d6f3dd5299  vmovaps xmm8, [rsp+0x70]
000070d6f3dd529f  vmovaps xmm9, [rsp+0x80]
000070d6f3dd52a8  vmovaps xmm10, [rsp+0x90]
000070d6f3dd52b1  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd52ba  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd52c3  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd52cc  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd52d5  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd52de  add rsp, 0xF0
000070d6f3dd52e5  pop r11
000070d6f3dd52e7  pop r10
000070d6f3dd52e9  pop r9
000070d6f3dd52eb  pop r8
000070d6f3dd52ed  pop rsi
000070d6f3dd52ee  pop rdi
000070d6f3dd52ef  pop rdx
000070d6f3dd52f0  pop rcx
000070d6f3dd52f1  pop rax
000070d6f3dd52f2  add rsp, 0x08
000070d6f3dd52f6  jmp 0x000070D6F3DD3814
000070d6f3dd52fb  sub rsp, 0x08
000070d6f3dd52ff  push rax
000070d6f3dd5300  push rcx
000070d6f3dd5301  push rdx
000070d6f3dd5302  push rdi
000070d6f3dd5303  push rsi
000070d6f3dd5304  push r8
000070d6f3dd5306  push r9
000070d6f3dd5308  push r10
000070d6f3dd530a  push r11
000070d6f3dd530c  sub rsp, 0xF0
000070d6f3dd5313  vmovaps [rsp], xmm0
000070d6f3dd5318  vmovaps [rsp+0x10], xmm1
000070d6f3dd531e  vmovaps [rsp+0x20], xmm2
000070d6f3dd5324  vmovaps [rsp+0x30], xmm3
000070d6f3dd532a  vmovaps [rsp+0x40], xmm4
000070d6f3dd5330  vmovaps [rsp+0x50], xmm5
000070d6f3dd5336  vmovaps [rsp+0x60], xmm6
000070d6f3dd533c  vmovaps [rsp+0x70], xmm7
000070d6f3dd5342  vmovaps [rsp+0x80], xmm8
000070d6f3dd534b  vmovaps [rsp+0x90], xmm10
000070d6f3dd5354  vmovaps [rsp+0xA0], xmm11
000070d6f3dd535d  vmovaps [rsp+0xB0], xmm12
000070d6f3dd5366  vmovaps [rsp+0xC0], xmm13
000070d6f3dd536f  vmovaps [rsp+0xD0], xmm14
000070d6f3dd5378  vmovaps [rsp+0xE0], xmm15
000070d6f3dd5381  sub rsp, 0x40
000070d6f3dd5385  lea rdi, [rsp]
000070d6f3dd5389  lea rsi, [rsp+0x10]
000070d6f3dd538e  lea rdx, [rsp+0x20]
000070d6f3dd5393  lea rcx, [rsp+0x30]
000070d6f3dd5398  mov r8d, 0x00
000070d6f3dd539e  lea r9, [r15+0x3A8]
000070d6f3dd53a5  movaps [rdi], xmm9
000070d6f3dd53a9  movaps [rsi], xmm10
000070d6f3dd53ad  movaps [rdx], xmm1
000070d6f3dd53b0  movaps [rcx], xmm12
000070d6f3dd53b4  mov rax, 0x61D08D40EA50
000070d6f3dd53be  call rax
000070d6f3dd53c0  movaps xmm9, [rsp]
000070d6f3dd53c5  add rsp, 0x40
000070d6f3dd53c9  vmovaps xmm0, [rsp]
000070d6f3dd53ce  vmovaps xmm1, [rsp+0x10]
000070d6f3dd53d4  vmovaps xmm2, [rsp+0x20]
000070d6f3dd53da  vmovaps xmm3, [rsp+0x30]
000070d6f3dd53e0  vmovaps xmm4, [rsp+0x40]
000070d6f3dd53e6  vmovaps xmm5, [rsp+0x50]
000070d6f3dd53ec  vmovaps xmm6, [rsp+0x60]
000070d6f3dd53f2  vmovaps xmm7, [rsp+0x70]
000070d6f3dd53f8  vmovaps xmm8, [rsp+0x80]
000070d6f3dd5401  vmovaps xmm10, [rsp+0x90]
000070d6f3dd540a  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd5413  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd541c  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd5425  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd542e  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd5437  add rsp, 0xF0
000070d6f3dd543e  pop r11
000070d6f3dd5440  pop r10
000070d6f3dd5442  pop r9
000070d6f3dd5444  pop r8
000070d6f3dd5446  pop rsi
000070d6f3dd5447  pop rdi
000070d6f3dd5448  pop rdx
000070d6f3dd5449  pop rcx
000070d6f3dd544a  pop rax
000070d6f3dd544b  add rsp, 0x08
000070d6f3dd544f  jmp 0x000070D6F3DD383D
000070d6f3dd5454  sub rsp, 0x08
000070d6f3dd5458  push rax
000070d6f3dd5459  push rcx
000070d6f3dd545a  push rdx
000070d6f3dd545b  push rdi
000070d6f3dd545c  push rsi
000070d6f3dd545d  push r8
000070d6f3dd545f  push r9
000070d6f3dd5461  push r10
000070d6f3dd5463  push r11
000070d6f3dd5465  sub rsp, 0xF0
000070d6f3dd546c  vmovaps [rsp], xmm0
000070d6f3dd5471  vmovaps [rsp+0x10], xmm1
000070d6f3dd5477  vmovaps [rsp+0x20], xmm2
000070d6f3dd547d  vmovaps [rsp+0x30], xmm3
000070d6f3dd5483  vmovaps [rsp+0x40], xmm4
000070d6f3dd5489  vmovaps [rsp+0x50], xmm5
000070d6f3dd548f  vmovaps [rsp+0x60], xmm6
000070d6f3dd5495  vmovaps [rsp+0x70], xmm7
000070d6f3dd549b  vmovaps [rsp+0x80], xmm8
000070d6f3dd54a4  vmovaps [rsp+0x90], xmm9
000070d6f3dd54ad  vmovaps [rsp+0xA0], xmm11
000070d6f3dd54b6  vmovaps [rsp+0xB0], xmm12
000070d6f3dd54bf  vmovaps [rsp+0xC0], xmm13
000070d6f3dd54c8  vmovaps [rsp+0xD0], xmm14
000070d6f3dd54d1  vmovaps [rsp+0xE0], xmm15
000070d6f3dd54da  sub rsp, 0x40
000070d6f3dd54de  lea rdi, [rsp]
000070d6f3dd54e2  lea rsi, [rsp+0x10]
000070d6f3dd54e7  lea rdx, [rsp+0x20]
000070d6f3dd54ec  lea rcx, [rsp+0x30]
000070d6f3dd54f1  mov r8d, 0x00
000070d6f3dd54f7  lea r9, [r15+0x3A8]
000070d6f3dd54fe  movaps [rdi], xmm10
000070d6f3dd5502  movaps [rsi], xmm5
000070d6f3dd5505  movaps [rdx], xmm12
000070d6f3dd5509  movaps [rcx], xmm1
000070d6f3dd550c  mov rax, 0x61D08D40EA50
000070d6f3dd5516  call rax
000070d6f3dd5518  movaps xmm10, [rsp]
000070d6f3dd551d  add rsp, 0x40
000070d6f3dd5521  vmovaps xmm0, [rsp]
000070d6f3dd5526  vmovaps xmm1, [rsp+0x10]
000070d6f3dd552c  vmovaps xmm2, [rsp+0x20]
000070d6f3dd5532  vmovaps xmm3, [rsp+0x30]
000070d6f3dd5538  vmovaps xmm4, [rsp+0x40]
000070d6f3dd553e  vmovaps xmm5, [rsp+0x50]
000070d6f3dd5544  vmovaps xmm6, [rsp+0x60]
000070d6f3dd554a  vmovaps xmm7, [rsp+0x70]
000070d6f3dd5550  vmovaps xmm8, [rsp+0x80]
000070d6f3dd5559  vmovaps xmm9, [rsp+0x90]
000070d6f3dd5562  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd556b  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd5574  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd557d  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd5586  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd558f  add rsp, 0xF0
000070d6f3dd5596  pop r11
000070d6f3dd5598  pop r10
000070d6f3dd559a  pop r9
000070d6f3dd559c  pop r8
000070d6f3dd559e  pop rsi
000070d6f3dd559f  pop rdi
000070d6f3dd55a0  pop rdx
000070d6f3dd55a1  pop rcx
000070d6f3dd55a2  pop rax
000070d6f3dd55a3  add rsp, 0x08
000070d6f3dd55a7  jmp 0x000070D6F3DD386C
000070d6f3dd55ac  sub rsp, 0x08
000070d6f3dd55b0  push rax
000070d6f3dd55b1  push rcx
000070d6f3dd55b2  push rdx
000070d6f3dd55b3  push rdi
000070d6f3dd55b4  push rsi
000070d6f3dd55b5  push r8
000070d6f3dd55b7  push r9
000070d6f3dd55b9  push r10
000070d6f3dd55bb  push r11
000070d6f3dd55bd  sub rsp, 0xF0
000070d6f3dd55c4  vmovaps [rsp], xmm0
000070d6f3dd55c9  vmovaps [rsp+0x10], xmm1
000070d6f3dd55cf  vmovaps [rsp+0x20], xmm2
000070d6f3dd55d5  vmovaps [rsp+0x30], xmm3
000070d6f3dd55db  vmovaps [rsp+0x40], xmm4
000070d6f3dd55e1  vmovaps [rsp+0x50], xmm5
000070d6f3dd55e7  vmovaps [rsp+0x60], xmm7
000070d6f3dd55ed  vmovaps [rsp+0x70], xmm8
000070d6f3dd55f3  vmovaps [rsp+0x80], xmm9
000070d6f3dd55fc  vmovaps [rsp+0x90], xmm10
000070d6f3dd5605  vmovaps [rsp+0xA0], xmm11
000070d6f3dd560e  vmovaps [rsp+0xB0], xmm12
000070d6f3dd5617  vmovaps [rsp+0xC0], xmm13
000070d6f3dd5620  vmovaps [rsp+0xD0], xmm14
000070d6f3dd5629  vmovaps [rsp+0xE0], xmm15
000070d6f3dd5632  sub rsp, 0x40
000070d6f3dd5636  lea rdi, [rsp]
000070d6f3dd563a  lea rsi, [rsp+0x10]
000070d6f3dd563f  lea rdx, [rsp+0x20]
000070d6f3dd5644  lea rcx, [rsp+0x30]
000070d6f3dd5649  mov r8d, 0x00
000070d6f3dd564f  lea r9, [r15+0x3A8]
000070d6f3dd5656  movaps [rdi], xmm6
000070d6f3dd5659  movaps [rsi], xmm8
000070d6f3dd565d  movaps [rdx], xmm12
000070d6f3dd5661  movaps [rcx], xmm1
000070d6f3dd5664  mov rax, 0x61D08D40EA50
000070d6f3dd566e  call rax
000070d6f3dd5670  movaps xmm6, [rsp]
000070d6f3dd5674  add rsp, 0x40
000070d6f3dd5678  vmovaps xmm0, [rsp]
000070d6f3dd567d  vmovaps xmm1, [rsp+0x10]
000070d6f3dd5683  vmovaps xmm2, [rsp+0x20]
000070d6f3dd5689  vmovaps xmm3, [rsp+0x30]
000070d6f3dd568f  vmovaps xmm4, [rsp+0x40]
000070d6f3dd5695  vmovaps xmm5, [rsp+0x50]
000070d6f3dd569b  vmovaps xmm7, [rsp+0x60]
000070d6f3dd56a1  vmovaps xmm8, [rsp+0x70]
000070d6f3dd56a7  vmovaps xmm9, [rsp+0x80]
000070d6f3dd56b0  vmovaps xmm10, [rsp+0x90]
000070d6f3dd56b9  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd56c2  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd56cb  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd56d4  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd56dd  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd56e6  add rsp, 0xF0
000070d6f3dd56ed  pop r11
000070d6f3dd56ef  pop r10
000070d6f3dd56f1  pop r9
000070d6f3dd56f3  pop r8
000070d6f3dd56f5  pop rsi
000070d6f3dd56f6  pop rdi
000070d6f3dd56f7  pop rdx
000070d6f3dd56f8  pop rcx
000070d6f3dd56f9  pop rax
000070d6f3dd56fa  add rsp, 0x08
000070d6f3dd56fe  jmp 0x000070D6F3DD389A
000070d6f3dd5703  call 0x000070D6F3CD64F0
000070d6f3dd5708  jmp 0x000070D6F3DD38A4
000070d6f3dd570d  call 0x000070D6F3CE20A0
000070d6f3dd5712  jmp 0x000070D6F3DD38AE
000070d6f3dd5717  sub rsp, 0x08
000070d6f3dd571b  push rax
000070d6f3dd571c  push rcx
000070d6f3dd571d  push rdx
000070d6f3dd571e  push rdi
000070d6f3dd571f  push rsi
000070d6f3dd5720  push r8
000070d6f3dd5722  push r9
000070d6f3dd5724  push r10
000070d6f3dd5726  push r11
000070d6f3dd5728  sub rsp, 0xF0
000070d6f3dd572f  vmovaps [rsp], xmm0
000070d6f3dd5734  vmovaps [rsp+0x10], xmm1
000070d6f3dd573a  vmovaps [rsp+0x20], xmm2
000070d6f3dd5740  vmovaps [rsp+0x30], xmm3
000070d6f3dd5746  vmovaps [rsp+0x40], xmm4
000070d6f3dd574c  vmovaps [rsp+0x50], xmm5
000070d6f3dd5752  vmovaps [rsp+0x60], xmm6
000070d6f3dd5758  vmovaps [rsp+0x70], xmm7
000070d6f3dd575e  vmovaps [rsp+0x80], xmm9
000070d6f3dd5767  vmovaps [rsp+0x90], xmm10
000070d6f3dd5770  vmovaps [rsp+0xA0], xmm11
000070d6f3dd5779  vmovaps [rsp+0xB0], xmm12
000070d6f3dd5782  vmovaps [rsp+0xC0], xmm13
000070d6f3dd578b  vmovaps [rsp+0xD0], xmm14
000070d6f3dd5794  vmovaps [rsp+0xE0], xmm15
000070d6f3dd579d  sub rsp, 0x40
000070d6f3dd57a1  lea rdi, [rsp]
000070d6f3dd57a5  lea rsi, [rsp+0x10]
000070d6f3dd57aa  lea rdx, [rsp+0x20]
000070d6f3dd57af  lea rcx, [rsp+0x30]
000070d6f3dd57b4  mov r8d, 0x00
000070d6f3dd57ba  lea r9, [r15+0x3A8]
000070d6f3dd57c1  movaps [rdi], xmm8
000070d6f3dd57c5  movaps [rsi], xmm4
000070d6f3dd57c8  movaps [rdx], xmm13
000070d6f3dd57cc  movaps [rcx], xmm11
000070d6f3dd57d0  mov rax, 0x61D08D40EA50
000070d6f3dd57da  call rax
000070d6f3dd57dc  movaps xmm8, [rsp]
000070d6f3dd57e1  add rsp, 0x40
000070d6f3dd57e5  vmovaps xmm0, [rsp]
000070d6f3dd57ea  vmovaps xmm1, [rsp+0x10]
000070d6f3dd57f0  vmovaps xmm2, [rsp+0x20]
000070d6f3dd57f6  vmovaps xmm3, [rsp+0x30]
000070d6f3dd57fc  vmovaps xmm4, [rsp+0x40]
000070d6f3dd5802  vmovaps xmm5, [rsp+0x50]
000070d6f3dd5808  vmovaps xmm6, [rsp+0x60]
000070d6f3dd580e  vmovaps xmm7, [rsp+0x70]
000070d6f3dd5814  vmovaps xmm9, [rsp+0x80]
000070d6f3dd581d  vmovaps xmm10, [rsp+0x90]
000070d6f3dd5826  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd582f  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd5838  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd5841  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd584a  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd5853  add rsp, 0xF0
000070d6f3dd585a  pop r11
000070d6f3dd585c  pop r10
000070d6f3dd585e  pop r9
000070d6f3dd5860  pop r8
000070d6f3dd5862  pop rsi
000070d6f3dd5863  pop rdi
000070d6f3dd5864  pop rdx
000070d6f3dd5865  pop rcx
000070d6f3dd5866  pop rax
000070d6f3dd5867  add rsp, 0x08
000070d6f3dd586b  jmp 0x000070D6F3DD38E4
000070d6f3dd5870  sub rsp, 0x08
000070d6f3dd5874  push rax
000070d6f3dd5875  push rcx
000070d6f3dd5876  push rdx
000070d6f3dd5877  push rdi
000070d6f3dd5878  push rsi
000070d6f3dd5879  push r8
000070d6f3dd587b  push r9
000070d6f3dd587d  push r10
000070d6f3dd587f  push r11
000070d6f3dd5881  sub rsp, 0xF0
000070d6f3dd5888  vmovaps [rsp], xmm0
000070d6f3dd588d  vmovaps [rsp+0x10], xmm1
000070d6f3dd5893  vmovaps [rsp+0x20], xmm2
000070d6f3dd5899  vmovaps [rsp+0x30], xmm3
000070d6f3dd589f  vmovaps [rsp+0x40], xmm4
000070d6f3dd58a5  vmovaps [rsp+0x50], xmm5
000070d6f3dd58ab  vmovaps [rsp+0x60], xmm6
000070d6f3dd58b1  vmovaps [rsp+0x70], xmm7
000070d6f3dd58b7  vmovaps [rsp+0x80], xmm8
000070d6f3dd58c0  vmovaps [rsp+0x90], xmm9
000070d6f3dd58c9  vmovaps [rsp+0xA0], xmm10
000070d6f3dd58d2  vmovaps [rsp+0xB0], xmm12
000070d6f3dd58db  vmovaps [rsp+0xC0], xmm13
000070d6f3dd58e4  vmovaps [rsp+0xD0], xmm14
000070d6f3dd58ed  vmovaps [rsp+0xE0], xmm15
000070d6f3dd58f6  sub rsp, 0x40
000070d6f3dd58fa  lea rdi, [rsp]
000070d6f3dd58fe  lea rsi, [rsp+0x10]
000070d6f3dd5903  lea rdx, [rsp+0x20]
000070d6f3dd5908  lea rcx, [rsp+0x30]
000070d6f3dd590d  mov r8d, 0x00
000070d6f3dd5913  lea r9, [r15+0x3A8]
000070d6f3dd591a  movaps [rdi], xmm11
000070d6f3dd591e  movaps [rsi], xmm9
000070d6f3dd5922  movaps [rdx], xmm1
000070d6f3dd5925  movaps [rcx], xmm13
000070d6f3dd5929  mov rax, 0x61D08D40EA50
000070d6f3dd5933  call rax
000070d6f3dd5935  movaps xmm11, [rsp]
000070d6f3dd593a  add rsp, 0x40
000070d6f3dd593e  vmovaps xmm0, [rsp]
000070d6f3dd5943  vmovaps xmm1, [rsp+0x10]
000070d6f3dd5949  vmovaps xmm2, [rsp+0x20]
000070d6f3dd594f  vmovaps xmm3, [rsp+0x30]
000070d6f3dd5955  vmovaps xmm4, [rsp+0x40]
000070d6f3dd595b  vmovaps xmm5, [rsp+0x50]
000070d6f3dd5961  vmovaps xmm6, [rsp+0x60]
000070d6f3dd5967  vmovaps xmm7, [rsp+0x70]
000070d6f3dd596d  vmovaps xmm8, [rsp+0x80]
000070d6f3dd5976  vmovaps xmm9, [rsp+0x90]
000070d6f3dd597f  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd5988  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd5991  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd599a  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd59a3  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd59ac  add rsp, 0xF0
000070d6f3dd59b3  pop r11
000070d6f3dd59b5  pop r10
000070d6f3dd59b7  pop r9
000070d6f3dd59b9  pop r8
000070d6f3dd59bb  pop rsi
000070d6f3dd59bc  pop rdi
000070d6f3dd59bd  pop rdx
000070d6f3dd59be  pop rcx
000070d6f3dd59bf  pop rax
000070d6f3dd59c0  add rsp, 0x08
000070d6f3dd59c4  jmp 0x000070D6F3DD390A
000070d6f3dd59c9  sub rsp, 0x08
000070d6f3dd59cd  push rax
000070d6f3dd59ce  push rcx
000070d6f3dd59cf  push rdx
000070d6f3dd59d0  push rdi
000070d6f3dd59d1  push rsi
000070d6f3dd59d2  push r8
000070d6f3dd59d4  push r9
000070d6f3dd59d6  push r10
000070d6f3dd59d8  push r11
000070d6f3dd59da  sub rsp, 0xF0
000070d6f3dd59e1  vmovaps [rsp], xmm0
000070d6f3dd59e6  vmovaps [rsp+0x10], xmm1
000070d6f3dd59ec  vmovaps [rsp+0x20], xmm2
000070d6f3dd59f2  vmovaps [rsp+0x30], xmm3
000070d6f3dd59f8  vmovaps [rsp+0x40], xmm4
000070d6f3dd59fe  vmovaps [rsp+0x50], xmm5
000070d6f3dd5a04  vmovaps [rsp+0x60], xmm6
000070d6f3dd5a0a  vmovaps [rsp+0x70], xmm7
000070d6f3dd5a10  vmovaps [rsp+0x80], xmm8
000070d6f3dd5a19  vmovaps [rsp+0x90], xmm9
000070d6f3dd5a22  vmovaps [rsp+0xA0], xmm10
000070d6f3dd5a2b  vmovaps [rsp+0xB0], xmm11
000070d6f3dd5a34  vmovaps [rsp+0xC0], xmm12
000070d6f3dd5a3d  vmovaps [rsp+0xD0], xmm14
000070d6f3dd5a46  vmovaps [rsp+0xE0], xmm15
000070d6f3dd5a4f  sub rsp, 0x40
000070d6f3dd5a53  lea rdi, [rsp]
000070d6f3dd5a57  lea rsi, [rsp+0x10]
000070d6f3dd5a5c  lea rdx, [rsp+0x20]
000070d6f3dd5a61  lea rcx, [rsp+0x30]
000070d6f3dd5a66  mov r8d, 0x00
000070d6f3dd5a6c  lea r9, [r15+0x3A8]
000070d6f3dd5a73  movaps [rdi], xmm13
000070d6f3dd5a77  movaps [rsi], xmm10
000070d6f3dd5a7b  movaps [rdx], xmm7
000070d6f3dd5a7e  movaps [rcx], xmm1
000070d6f3dd5a81  mov rax, 0x61D08D40EA50
000070d6f3dd5a8b  call rax
000070d6f3dd5a8d  movaps xmm13, [rsp]
000070d6f3dd5a92  add rsp, 0x40
000070d6f3dd5a96  vmovaps xmm0, [rsp]
000070d6f3dd5a9b  vmovaps xmm1, [rsp+0x10]
000070d6f3dd5aa1  vmovaps xmm2, [rsp+0x20]
000070d6f3dd5aa7  vmovaps xmm3, [rsp+0x30]
000070d6f3dd5aad  vmovaps xmm4, [rsp+0x40]
000070d6f3dd5ab3  vmovaps xmm5, [rsp+0x50]
000070d6f3dd5ab9  vmovaps xmm6, [rsp+0x60]
000070d6f3dd5abf  vmovaps xmm7, [rsp+0x70]
000070d6f3dd5ac5  vmovaps xmm8, [rsp+0x80]
000070d6f3dd5ace  vmovaps xmm9, [rsp+0x90]
000070d6f3dd5ad7  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd5ae0  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd5ae9  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd5af2  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd5afb  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd5b04  add rsp, 0xF0
000070d6f3dd5b0b  pop r11
000070d6f3dd5b0d  pop r10
000070d6f3dd5b0f  pop r9
000070d6f3dd5b11  pop r8
000070d6f3dd5b13  pop rsi
000070d6f3dd5b14  pop rdi
000070d6f3dd5b15  pop rdx
000070d6f3dd5b16  pop rcx
000070d6f3dd5b17  pop rax
000070d6f3dd5b18  add rsp, 0x08
000070d6f3dd5b1c  jmp 0x000070D6F3DD3930
000070d6f3dd5b21  sub rsp, 0x08
000070d6f3dd5b25  push rax
000070d6f3dd5b26  push rcx
000070d6f3dd5b27  push rdx
000070d6f3dd5b28  push rdi
000070d6f3dd5b29  push rsi
000070d6f3dd5b2a  push r8
000070d6f3dd5b2c  push r9
000070d6f3dd5b2e  push r10
000070d6f3dd5b30  push r11
000070d6f3dd5b32  sub rsp, 0xF0
000070d6f3dd5b39  vmovaps [rsp], xmm0
000070d6f3dd5b3e  vmovaps [rsp+0x10], xmm1
000070d6f3dd5b44  vmovaps [rsp+0x20], xmm2
000070d6f3dd5b4a  vmovaps [rsp+0x30], xmm3
000070d6f3dd5b50  vmovaps [rsp+0x40], xmm4
000070d6f3dd5b56  vmovaps [rsp+0x50], xmm5
000070d6f3dd5b5c  vmovaps [rsp+0x60], xmm6
000070d6f3dd5b62  vmovaps [rsp+0x70], xmm7
000070d6f3dd5b68  vmovaps [rsp+0x80], xmm8
000070d6f3dd5b71  vmovaps [rsp+0x90], xmm9
000070d6f3dd5b7a  vmovaps [rsp+0xA0], xmm11
000070d6f3dd5b83  vmovaps [rsp+0xB0], xmm12
000070d6f3dd5b8c  vmovaps [rsp+0xC0], xmm13
000070d6f3dd5b95  vmovaps [rsp+0xD0], xmm14
000070d6f3dd5b9e  vmovaps [rsp+0xE0], xmm15
000070d6f3dd5ba7  sub rsp, 0x40
000070d6f3dd5bab  lea rdi, [rsp]
000070d6f3dd5baf  lea rsi, [rsp+0x10]
000070d6f3dd5bb4  lea rdx, [rsp+0x20]
000070d6f3dd5bb9  lea rcx, [rsp+0x30]
000070d6f3dd5bbe  mov r8d, 0x00
000070d6f3dd5bc4  lea r9, [r15+0x3A8]
000070d6f3dd5bcb  movaps [rdi], xmm10
000070d6f3dd5bcf  movaps [rsi], xmm6
000070d6f3dd5bd2  movaps [rdx], xmm15
000070d6f3dd5bd6  movaps [rcx], xmm1
000070d6f3dd5bd9  mov rax, 0x61D08D40EA50
000070d6f3dd5be3  call rax
000070d6f3dd5be5  movaps xmm10, [rsp]
000070d6f3dd5bea  add rsp, 0x40
000070d6f3dd5bee  vmovaps xmm0, [rsp]
000070d6f3dd5bf3  vmovaps xmm1, [rsp+0x10]
000070d6f3dd5bf9  vmovaps xmm2, [rsp+0x20]
000070d6f3dd5bff  vmovaps xmm3, [rsp+0x30]
000070d6f3dd5c05  vmovaps xmm4, [rsp+0x40]
000070d6f3dd5c0b  vmovaps xmm5, [rsp+0x50]
000070d6f3dd5c11  vmovaps xmm6, [rsp+0x60]
000070d6f3dd5c17  vmovaps xmm7, [rsp+0x70]
000070d6f3dd5c1d  vmovaps xmm8, [rsp+0x80]
000070d6f3dd5c26  vmovaps xmm9, [rsp+0x90]
000070d6f3dd5c2f  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd5c38  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd5c41  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd5c4a  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd5c53  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd5c5c  add rsp, 0xF0
000070d6f3dd5c63  pop r11
000070d6f3dd5c65  pop r10
000070d6f3dd5c67  pop r9
000070d6f3dd5c69  pop r8
000070d6f3dd5c6b  pop rsi
000070d6f3dd5c6c  pop rdi
000070d6f3dd5c6d  pop rdx
000070d6f3dd5c6e  pop rcx
000070d6f3dd5c6f  pop rax
000070d6f3dd5c70  add rsp, 0x08
000070d6f3dd5c74  jmp 0x000070D6F3DD3956
000070d6f3dd5c79  call 0x000070D6F3CD64F0
000070d6f3dd5c7e  jmp 0x000070D6F3DD3960
000070d6f3dd5c83  call 0x000070D6F3CE5820
000070d6f3dd5c88  jmp 0x000070D6F3DD396A
000070d6f3dd5c8d  sub rsp, 0x08
000070d6f3dd5c91  push rax
000070d6f3dd5c92  push rcx
000070d6f3dd5c93  push rdx
000070d6f3dd5c94  push rdi
000070d6f3dd5c95  push rsi
000070d6f3dd5c96  push r8
000070d6f3dd5c98  push r9
000070d6f3dd5c9a  push r10
000070d6f3dd5c9c  push r11
000070d6f3dd5c9e  sub rsp, 0xF0
000070d6f3dd5ca5  vmovaps [rsp], xmm0
000070d6f3dd5caa  vmovaps [rsp+0x10], xmm1
000070d6f3dd5cb0  vmovaps [rsp+0x20], xmm2
000070d6f3dd5cb6  vmovaps [rsp+0x30], xmm3
000070d6f3dd5cbc  vmovaps [rsp+0x40], xmm4
000070d6f3dd5cc2  vmovaps [rsp+0x50], xmm5
000070d6f3dd5cc8  vmovaps [rsp+0x60], xmm6
000070d6f3dd5cce  vmovaps [rsp+0x70], xmm8
000070d6f3dd5cd4  vmovaps [rsp+0x80], xmm9
000070d6f3dd5cdd  vmovaps [rsp+0x90], xmm10
000070d6f3dd5ce6  vmovaps [rsp+0xA0], xmm11
000070d6f3dd5cef  vmovaps [rsp+0xB0], xmm12
000070d6f3dd5cf8  vmovaps [rsp+0xC0], xmm13
000070d6f3dd5d01  vmovaps [rsp+0xD0], xmm14
000070d6f3dd5d0a  vmovaps [rsp+0xE0], xmm15
000070d6f3dd5d13  sub rsp, 0x40
000070d6f3dd5d17  lea rdi, [rsp]
000070d6f3dd5d1b  lea rsi, [rsp+0x10]
000070d6f3dd5d20  lea rdx, [rsp+0x20]
000070d6f3dd5d25  lea rcx, [rsp+0x30]
000070d6f3dd5d2a  mov r8d, 0x00
000070d6f3dd5d30  lea r9, [r15+0x3A8]
000070d6f3dd5d37  movaps [rdi], xmm7
000070d6f3dd5d3a  movaps [rsi], xmm8
000070d6f3dd5d3e  movaps [rdx], xmm3
000070d6f3dd5d41  movaps [rcx], xmm9
000070d6f3dd5d45  mov rax, 0x61D08D40EA50
000070d6f3dd5d4f  call rax
000070d6f3dd5d51  movaps xmm7, [rsp]
000070d6f3dd5d55  add rsp, 0x40
000070d6f3dd5d59  vmovaps xmm0, [rsp]
000070d6f3dd5d5e  vmovaps xmm1, [rsp+0x10]
000070d6f3dd5d64  vmovaps xmm2, [rsp+0x20]
000070d6f3dd5d6a  vmovaps xmm3, [rsp+0x30]
000070d6f3dd5d70  vmovaps xmm4, [rsp+0x40]
000070d6f3dd5d76  vmovaps xmm5, [rsp+0x50]
000070d6f3dd5d7c  vmovaps xmm6, [rsp+0x60]
000070d6f3dd5d82  vmovaps xmm8, [rsp+0x70]
000070d6f3dd5d88  vmovaps xmm9, [rsp+0x80]
000070d6f3dd5d91  vmovaps xmm10, [rsp+0x90]
000070d6f3dd5d9a  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd5da3  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd5dac  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd5db5  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd5dbe  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd5dc7  add rsp, 0xF0
000070d6f3dd5dce  pop r11
000070d6f3dd5dd0  pop r10
000070d6f3dd5dd2  pop r9
000070d6f3dd5dd4  pop r8
000070d6f3dd5dd6  pop rsi
000070d6f3dd5dd7  pop rdi
000070d6f3dd5dd8  pop rdx
000070d6f3dd5dd9  pop rcx
000070d6f3dd5dda  pop rax
000070d6f3dd5ddb  add rsp, 0x08
000070d6f3dd5ddf  jmp 0x000070D6F3DD3992
000070d6f3dd5de4  sub rsp, 0x08
000070d6f3dd5de8  push rax
000070d6f3dd5de9  push rcx
000070d6f3dd5dea  push rdx
000070d6f3dd5deb  push rdi
000070d6f3dd5dec  push rsi
000070d6f3dd5ded  push r8
000070d6f3dd5def  push r9
000070d6f3dd5df1  push r10
000070d6f3dd5df3  push r11
000070d6f3dd5df5  sub rsp, 0xF0
000070d6f3dd5dfc  vmovaps [rsp], xmm0
000070d6f3dd5e01  vmovaps [rsp+0x10], xmm1
000070d6f3dd5e07  vmovaps [rsp+0x20], xmm2
000070d6f3dd5e0d  vmovaps [rsp+0x30], xmm3
000070d6f3dd5e13  vmovaps [rsp+0x40], xmm4
000070d6f3dd5e19  vmovaps [rsp+0x50], xmm5
000070d6f3dd5e1f  vmovaps [rsp+0x60], xmm6
000070d6f3dd5e25  vmovaps [rsp+0x70], xmm7
000070d6f3dd5e2b  vmovaps [rsp+0x80], xmm9
000070d6f3dd5e34  vmovaps [rsp+0x90], xmm10
000070d6f3dd5e3d  vmovaps [rsp+0xA0], xmm11
000070d6f3dd5e46  vmovaps [rsp+0xB0], xmm12
000070d6f3dd5e4f  vmovaps [rsp+0xC0], xmm13
000070d6f3dd5e58  vmovaps [rsp+0xD0], xmm14
000070d6f3dd5e61  vmovaps [rsp+0xE0], xmm15
000070d6f3dd5e6a  sub rsp, 0x40
000070d6f3dd5e6e  lea rdi, [rsp]
000070d6f3dd5e72  lea rsi, [rsp+0x10]
000070d6f3dd5e77  lea rdx, [rsp+0x20]
000070d6f3dd5e7c  lea rcx, [rsp+0x30]
000070d6f3dd5e81  mov r8d, 0x00
000070d6f3dd5e87  lea r9, [r15+0x3A8]
000070d6f3dd5e8e  movaps [rdi], xmm8
000070d6f3dd5e92  movaps [rsi], xmm11
000070d6f3dd5e96  movaps [rdx], xmm14
000070d6f3dd5e9a  movaps [rcx], xmm9
000070d6f3dd5e9e  mov rax, 0x61D08D40EA50
000070d6f3dd5ea8  call rax
000070d6f3dd5eaa  movaps xmm8, [rsp]
000070d6f3dd5eaf  add rsp, 0x40
000070d6f3dd5eb3  vmovaps xmm0, [rsp]
000070d6f3dd5eb8  vmovaps xmm1, [rsp+0x10]
000070d6f3dd5ebe  vmovaps xmm2, [rsp+0x20]
000070d6f3dd5ec4  vmovaps xmm3, [rsp+0x30]
000070d6f3dd5eca  vmovaps xmm4, [rsp+0x40]
000070d6f3dd5ed0  vmovaps xmm5, [rsp+0x50]
000070d6f3dd5ed6  vmovaps xmm6, [rsp+0x60]
000070d6f3dd5edc  vmovaps xmm7, [rsp+0x70]
000070d6f3dd5ee2  vmovaps xmm9, [rsp+0x80]
000070d6f3dd5eeb  vmovaps xmm10, [rsp+0x90]
000070d6f3dd5ef4  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd5efd  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd5f06  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd5f0f  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd5f18  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd5f21  add rsp, 0xF0
000070d6f3dd5f28  pop r11
000070d6f3dd5f2a  pop r10
000070d6f3dd5f2c  pop r9
000070d6f3dd5f2e  pop r8
000070d6f3dd5f30  pop rsi
000070d6f3dd5f31  pop rdi
000070d6f3dd5f32  pop rdx
000070d6f3dd5f33  pop rcx
000070d6f3dd5f34  pop rax
000070d6f3dd5f35  add rsp, 0x08
000070d6f3dd5f39  jmp 0x000070D6F3DD39BB
000070d6f3dd5f3e  sub rsp, 0x08
000070d6f3dd5f42  push rax
000070d6f3dd5f43  push rcx
000070d6f3dd5f44  push rdx
000070d6f3dd5f45  push rdi
000070d6f3dd5f46  push rsi
000070d6f3dd5f47  push r8
000070d6f3dd5f49  push r9
000070d6f3dd5f4b  push r10
000070d6f3dd5f4d  push r11
000070d6f3dd5f4f  sub rsp, 0xF0
000070d6f3dd5f56  vmovaps [rsp], xmm0
000070d6f3dd5f5b  vmovaps [rsp+0x10], xmm1
000070d6f3dd5f61  vmovaps [rsp+0x20], xmm2
000070d6f3dd5f67  vmovaps [rsp+0x30], xmm3
000070d6f3dd5f6d  vmovaps [rsp+0x40], xmm4
000070d6f3dd5f73  vmovaps [rsp+0x50], xmm5
000070d6f3dd5f79  vmovaps [rsp+0x60], xmm6
000070d6f3dd5f7f  vmovaps [rsp+0x70], xmm7
000070d6f3dd5f85  vmovaps [rsp+0x80], xmm8
000070d6f3dd5f8e  vmovaps [rsp+0x90], xmm9
000070d6f3dd5f97  vmovaps [rsp+0xA0], xmm10
000070d6f3dd5fa0  vmovaps [rsp+0xB0], xmm12
000070d6f3dd5fa9  vmovaps [rsp+0xC0], xmm13
000070d6f3dd5fb2  vmovaps [rsp+0xD0], xmm14
000070d6f3dd5fbb  vmovaps [rsp+0xE0], xmm15
000070d6f3dd5fc4  sub rsp, 0x40
000070d6f3dd5fc8  lea rdi, [rsp]
000070d6f3dd5fcc  lea rsi, [rsp+0x10]
000070d6f3dd5fd1  lea rdx, [rsp+0x20]
000070d6f3dd5fd6  lea rcx, [rsp+0x30]
000070d6f3dd5fdb  mov r8d, 0x00
000070d6f3dd5fe1  lea r9, [r15+0x3A8]
000070d6f3dd5fe8  movaps [rdi], xmm11
000070d6f3dd5fec  movaps [rsi], xmm13
000070d6f3dd5ff0  movaps [rdx], xmm12
000070d6f3dd5ff4  movaps [rcx], xmm14
000070d6f3dd5ff8  mov rax, 0x61D08D40EA50
000070d6f3dd6002  call rax
000070d6f3dd6004  movaps xmm11, [rsp]
000070d6f3dd6009  add rsp, 0x40
000070d6f3dd600d  vmovaps xmm0, [rsp]
000070d6f3dd6012  vmovaps xmm1, [rsp+0x10]
000070d6f3dd6018  vmovaps xmm2, [rsp+0x20]
000070d6f3dd601e  vmovaps xmm3, [rsp+0x30]
000070d6f3dd6024  vmovaps xmm4, [rsp+0x40]
000070d6f3dd602a  vmovaps xmm5, [rsp+0x50]
000070d6f3dd6030  vmovaps xmm6, [rsp+0x60]
000070d6f3dd6036  vmovaps xmm7, [rsp+0x70]
000070d6f3dd603c  vmovaps xmm8, [rsp+0x80]
000070d6f3dd6045  vmovaps xmm9, [rsp+0x90]
000070d6f3dd604e  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd6057  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd6060  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd6069  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd6072  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd607b  add rsp, 0xF0
000070d6f3dd6082  pop r11
000070d6f3dd6084  pop r10
000070d6f3dd6086  pop r9
000070d6f3dd6088  pop r8
000070d6f3dd608a  pop rsi
000070d6f3dd608b  pop rdi
000070d6f3dd608c  pop rdx
000070d6f3dd608d  pop rcx
000070d6f3dd608e  pop rax
000070d6f3dd608f  add rsp, 0x08
000070d6f3dd6093  jmp 0x000070D6F3DD39E4
000070d6f3dd6098  sub rsp, 0x08
000070d6f3dd609c  push rax
000070d6f3dd609d  push rcx
000070d6f3dd609e  push rdx
000070d6f3dd609f  push rdi
000070d6f3dd60a0  push rsi
000070d6f3dd60a1  push r8
000070d6f3dd60a3  push r9
000070d6f3dd60a5  push r10
000070d6f3dd60a7  push r11
000070d6f3dd60a9  sub rsp, 0xF0
000070d6f3dd60b0  vmovaps [rsp], xmm0
000070d6f3dd60b5  vmovaps [rsp+0x10], xmm1
000070d6f3dd60bb  vmovaps [rsp+0x20], xmm2
000070d6f3dd60c1  vmovaps [rsp+0x30], xmm3
000070d6f3dd60c7  vmovaps [rsp+0x40], xmm4
000070d6f3dd60cd  vmovaps [rsp+0x50], xmm5
000070d6f3dd60d3  vmovaps [rsp+0x60], xmm6
000070d6f3dd60d9  vmovaps [rsp+0x70], xmm7
000070d6f3dd60df  vmovaps [rsp+0x80], xmm8
000070d6f3dd60e8  vmovaps [rsp+0x90], xmm9
000070d6f3dd60f1  vmovaps [rsp+0xA0], xmm10
000070d6f3dd60fa  vmovaps [rsp+0xB0], xmm11
000070d6f3dd6103  vmovaps [rsp+0xC0], xmm13
000070d6f3dd610c  vmovaps [rsp+0xD0], xmm14
000070d6f3dd6115  vmovaps [rsp+0xE0], xmm15
000070d6f3dd611e  sub rsp, 0x40
000070d6f3dd6122  lea rdi, [rsp]
000070d6f3dd6126  lea rsi, [rsp+0x10]
000070d6f3dd612b  lea rdx, [rsp+0x20]
000070d6f3dd6130  lea rcx, [rsp+0x30]
000070d6f3dd6135  mov r8d, 0x00
000070d6f3dd613b  lea r9, [r15+0x3A8]
000070d6f3dd6142  movaps [rdi], xmm12
000070d6f3dd6146  movaps [rsi], xmm10
000070d6f3dd614a  movaps [rdx], xmm15
000070d6f3dd614e  movaps [rcx], xmm14
000070d6f3dd6152  mov rax, 0x61D08D40EA50
000070d6f3dd615c  call rax
000070d6f3dd615e  movaps xmm12, [rsp]
000070d6f3dd6163  add rsp, 0x40
000070d6f3dd6167  vmovaps xmm0, [rsp]
000070d6f3dd616c  vmovaps xmm1, [rsp+0x10]
000070d6f3dd6172  vmovaps xmm2, [rsp+0x20]
000070d6f3dd6178  vmovaps xmm3, [rsp+0x30]
000070d6f3dd617e  vmovaps xmm4, [rsp+0x40]
000070d6f3dd6184  vmovaps xmm5, [rsp+0x50]
000070d6f3dd618a  vmovaps xmm6, [rsp+0x60]
000070d6f3dd6190  vmovaps xmm7, [rsp+0x70]
000070d6f3dd6196  vmovaps xmm8, [rsp+0x80]
000070d6f3dd619f  vmovaps xmm9, [rsp+0x90]
000070d6f3dd61a8  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd61b1  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd61ba  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd61c3  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd61cc  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd61d5  add rsp, 0xF0
000070d6f3dd61dc  pop r11
000070d6f3dd61de  pop r10
000070d6f3dd61e0  pop r9
000070d6f3dd61e2  pop r8
000070d6f3dd61e4  pop rsi
000070d6f3dd61e5  pop rdi
000070d6f3dd61e6  pop rdx
000070d6f3dd61e7  pop rcx
000070d6f3dd61e8  pop rax
000070d6f3dd61e9  add rsp, 0x08
000070d6f3dd61ed  jmp 0x000070D6F3DD3A0D
000070d6f3dd61f2  call 0x000070D6F3CE5820
000070d6f3dd61f7  jmp 0x000070D6F3DD3A1A
000070d6f3dd61fc  call 0x000070D6F3CE45A0
000070d6f3dd6201  jmp 0x000070D6F3DD3A27
000070d6f3dd6206  sub rsp, 0x08
000070d6f3dd620a  push rax
000070d6f3dd620b  push rcx
000070d6f3dd620c  push rdx
000070d6f3dd620d  push rdi
000070d6f3dd620e  push rsi
000070d6f3dd620f  push r8
000070d6f3dd6211  push r9
000070d6f3dd6213  push r10
000070d6f3dd6215  push r11
000070d6f3dd6217  sub rsp, 0xF0
000070d6f3dd621e  vmovaps [rsp], xmm0
000070d6f3dd6223  vmovaps [rsp+0x10], xmm1
000070d6f3dd6229  vmovaps [rsp+0x20], xmm2
000070d6f3dd622f  vmovaps [rsp+0x30], xmm3
000070d6f3dd6235  vmovaps [rsp+0x40], xmm4
000070d6f3dd623b  vmovaps [rsp+0x50], xmm5
000070d6f3dd6241  vmovaps [rsp+0x60], xmm6
000070d6f3dd6247  vmovaps [rsp+0x70], xmm7
000070d6f3dd624d  vmovaps [rsp+0x80], xmm8
000070d6f3dd6256  vmovaps [rsp+0x90], xmm9
000070d6f3dd625f  vmovaps [rsp+0xA0], xmm11
000070d6f3dd6268  vmovaps [rsp+0xB0], xmm12
000070d6f3dd6271  vmovaps [rsp+0xC0], xmm13
000070d6f3dd627a  vmovaps [rsp+0xD0], xmm14
000070d6f3dd6283  vmovaps [rsp+0xE0], xmm15
000070d6f3dd628c  sub rsp, 0x40
000070d6f3dd6290  lea rdi, [rsp]
000070d6f3dd6294  lea rsi, [rsp+0x10]
000070d6f3dd6299  lea rdx, [rsp+0x20]
000070d6f3dd629e  lea rcx, [rsp+0x30]
000070d6f3dd62a3  mov r8d, 0x00
000070d6f3dd62a9  lea r9, [r15+0x3A8]
000070d6f3dd62b0  movaps [rdi], xmm10
000070d6f3dd62b4  movaps [rsi], xmm7
000070d6f3dd62b7  movaps [rdx], xmm1
000070d6f3dd62ba  movaps [rcx], xmm13
000070d6f3dd62be  mov rax, 0x61D08D40EA50
000070d6f3dd62c8  call rax
000070d6f3dd62ca  movaps xmm10, [rsp]
000070d6f3dd62cf  add rsp, 0x40
000070d6f3dd62d3  vmovaps xmm0, [rsp]
000070d6f3dd62d8  vmovaps xmm1, [rsp+0x10]
000070d6f3dd62de  vmovaps xmm2, [rsp+0x20]
000070d6f3dd62e4  vmovaps xmm3, [rsp+0x30]
000070d6f3dd62ea  vmovaps xmm4, [rsp+0x40]
000070d6f3dd62f0  vmovaps xmm5, [rsp+0x50]
000070d6f3dd62f6  vmovaps xmm6, [rsp+0x60]
000070d6f3dd62fc  vmovaps xmm7, [rsp+0x70]
000070d6f3dd6302  vmovaps xmm8, [rsp+0x80]
000070d6f3dd630b  vmovaps xmm9, [rsp+0x90]
000070d6f3dd6314  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd631d  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd6326  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd632f  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd6338  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd6341  add rsp, 0xF0
000070d6f3dd6348  pop r11
000070d6f3dd634a  pop r10
000070d6f3dd634c  pop r9
000070d6f3dd634e  pop r8
000070d6f3dd6350  pop rsi
000070d6f3dd6351  pop rdi
000070d6f3dd6352  pop rdx
000070d6f3dd6353  pop rcx
000070d6f3dd6354  pop rax
000070d6f3dd6355  add rsp, 0x08
000070d6f3dd6359  jmp 0x000070D6F3DD3A5D
000070d6f3dd635e  call 0x000070D6F3CD64F0
000070d6f3dd6363  jmp 0x000070D6F3DD3A6F
000070d6f3dd6368  sub rsp, 0x08
000070d6f3dd636c  push rax
000070d6f3dd636d  push rcx
000070d6f3dd636e  push rdx
000070d6f3dd636f  push rdi
000070d6f3dd6370  push rsi
000070d6f3dd6371  push r8
000070d6f3dd6373  push r9
000070d6f3dd6375  push r10
000070d6f3dd6377  push r11
000070d6f3dd6379  sub rsp, 0xF0
000070d6f3dd6380  vmovaps [rsp], xmm0
000070d6f3dd6385  vmovaps [rsp+0x10], xmm1
000070d6f3dd638b  vmovaps [rsp+0x20], xmm2
000070d6f3dd6391  vmovaps [rsp+0x30], xmm3
000070d6f3dd6397  vmovaps [rsp+0x40], xmm4
000070d6f3dd639d  vmovaps [rsp+0x50], xmm5
000070d6f3dd63a3  vmovaps [rsp+0x60], xmm6
000070d6f3dd63a9  vmovaps [rsp+0x70], xmm7
000070d6f3dd63af  vmovaps [rsp+0x80], xmm8
000070d6f3dd63b8  vmovaps [rsp+0x90], xmm10
000070d6f3dd63c1  vmovaps [rsp+0xA0], xmm11
000070d6f3dd63ca  vmovaps [rsp+0xB0], xmm12
000070d6f3dd63d3  vmovaps [rsp+0xC0], xmm13
000070d6f3dd63dc  vmovaps [rsp+0xD0], xmm14
000070d6f3dd63e5  vmovaps [rsp+0xE0], xmm15
000070d6f3dd63ee  sub rsp, 0x40
000070d6f3dd63f2  lea rdi, [rsp]
000070d6f3dd63f6  lea rsi, [rsp+0x10]
000070d6f3dd63fb  lea rdx, [rsp+0x20]
000070d6f3dd6400  lea rcx, [rsp+0x30]
000070d6f3dd6405  mov r8d, 0x00
000070d6f3dd640b  lea r9, [r15+0x3A8]
000070d6f3dd6412  movaps [rdi], xmm9
000070d6f3dd6416  movaps [rsi], xmm8
000070d6f3dd641a  movaps [rdx], xmm14
000070d6f3dd641e  movaps [rcx], xmm13
000070d6f3dd6422  mov rax, 0x61D08D40EA50
000070d6f3dd642c  call rax
000070d6f3dd642e  movaps xmm9, [rsp]
000070d6f3dd6433  add rsp, 0x40
000070d6f3dd6437  vmovaps xmm0, [rsp]
000070d6f3dd643c  vmovaps xmm1, [rsp+0x10]
000070d6f3dd6442  vmovaps xmm2, [rsp+0x20]
000070d6f3dd6448  vmovaps xmm3, [rsp+0x30]
000070d6f3dd644e  vmovaps xmm4, [rsp+0x40]
000070d6f3dd6454  vmovaps xmm5, [rsp+0x50]
000070d6f3dd645a  vmovaps xmm6, [rsp+0x60]
000070d6f3dd6460  vmovaps xmm7, [rsp+0x70]
000070d6f3dd6466  vmovaps xmm8, [rsp+0x80]
000070d6f3dd646f  vmovaps xmm10, [rsp+0x90]
000070d6f3dd6478  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd6481  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd648a  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd6493  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd649c  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd64a5  add rsp, 0xF0
000070d6f3dd64ac  pop r11
000070d6f3dd64ae  pop r10
000070d6f3dd64b0  pop r9
000070d6f3dd64b2  pop r8
000070d6f3dd64b4  pop rsi
000070d6f3dd64b5  pop rdi
000070d6f3dd64b6  pop rdx
000070d6f3dd64b7  pop rcx
000070d6f3dd64b8  pop rax
000070d6f3dd64b9  add rsp, 0x08
000070d6f3dd64bd  jmp 0x000070D6F3DD3A9D
000070d6f3dd64c2  sub rsp, 0x08
000070d6f3dd64c6  push rax
000070d6f3dd64c7  push rcx
000070d6f3dd64c8  push rdx
000070d6f3dd64c9  push rdi
000070d6f3dd64ca  push rsi
000070d6f3dd64cb  push r8
000070d6f3dd64cd  push r9
000070d6f3dd64cf  push r10
000070d6f3dd64d1  push r11
000070d6f3dd64d3  sub rsp, 0xF0
000070d6f3dd64da  vmovaps [rsp], xmm0
000070d6f3dd64df  vmovaps [rsp+0x10], xmm1
000070d6f3dd64e5  vmovaps [rsp+0x20], xmm2
000070d6f3dd64eb  vmovaps [rsp+0x30], xmm3
000070d6f3dd64f1  vmovaps [rsp+0x40], xmm4
000070d6f3dd64f7  vmovaps [rsp+0x50], xmm5
000070d6f3dd64fd  vmovaps [rsp+0x60], xmm6
000070d6f3dd6503  vmovaps [rsp+0x70], xmm7
000070d6f3dd6509  vmovaps [rsp+0x80], xmm8
000070d6f3dd6512  vmovaps [rsp+0x90], xmm9
000070d6f3dd651b  vmovaps [rsp+0xA0], xmm10
000070d6f3dd6524  vmovaps [rsp+0xB0], xmm11
000070d6f3dd652d  vmovaps [rsp+0xC0], xmm12
000070d6f3dd6536  vmovaps [rsp+0xD0], xmm14
000070d6f3dd653f  vmovaps [rsp+0xE0], xmm15
000070d6f3dd6548  sub rsp, 0x40
000070d6f3dd654c  lea rdi, [rsp]
000070d6f3dd6550  lea rsi, [rsp+0x10]
000070d6f3dd6555  lea rdx, [rsp+0x20]
000070d6f3dd655a  lea rcx, [rsp+0x30]
000070d6f3dd655f  mov r8d, 0x00
000070d6f3dd6565  lea r9, [r15+0x3A8]
000070d6f3dd656c  movaps [rdi], xmm13
000070d6f3dd6570  movaps [rsi], xmm11
000070d6f3dd6574  movaps [rdx], xmm15
000070d6f3dd6578  movaps [rcx], xmm14
000070d6f3dd657c  mov rax, 0x61D08D40EA50
000070d6f3dd6586  call rax
000070d6f3dd6588  movaps xmm13, [rsp]
000070d6f3dd658d  add rsp, 0x40
000070d6f3dd6591  vmovaps xmm0, [rsp]
000070d6f3dd6596  vmovaps xmm1, [rsp+0x10]
000070d6f3dd659c  vmovaps xmm2, [rsp+0x20]
000070d6f3dd65a2  vmovaps xmm3, [rsp+0x30]
000070d6f3dd65a8  vmovaps xmm4, [rsp+0x40]
000070d6f3dd65ae  vmovaps xmm5, [rsp+0x50]
000070d6f3dd65b4  vmovaps xmm6, [rsp+0x60]
000070d6f3dd65ba  vmovaps xmm7, [rsp+0x70]
000070d6f3dd65c0  vmovaps xmm8, [rsp+0x80]
000070d6f3dd65c9  vmovaps xmm9, [rsp+0x90]
000070d6f3dd65d2  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd65db  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd65e4  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd65ed  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd65f6  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd65ff  add rsp, 0xF0
000070d6f3dd6606  pop r11
000070d6f3dd6608  pop r10
000070d6f3dd660a  pop r9
000070d6f3dd660c  pop r8
000070d6f3dd660e  pop rsi
000070d6f3dd660f  pop rdi
000070d6f3dd6610  pop rdx
000070d6f3dd6611  pop rcx
000070d6f3dd6612  pop rax
000070d6f3dd6613  add rsp, 0x08
000070d6f3dd6617  jmp 0x000070D6F3DD3ACB
000070d6f3dd661c  sub rsp, 0x08
000070d6f3dd6620  push rax
000070d6f3dd6621  push rcx
000070d6f3dd6622  push rdx
000070d6f3dd6623  push rdi
000070d6f3dd6624  push rsi
000070d6f3dd6625  push r8
000070d6f3dd6627  push r9
000070d6f3dd6629  push r10
000070d6f3dd662b  push r11
000070d6f3dd662d  sub rsp, 0xF0
000070d6f3dd6634  vmovaps [rsp], xmm0
000070d6f3dd6639  vmovaps [rsp+0x10], xmm1
000070d6f3dd663f  vmovaps [rsp+0x20], xmm2
000070d6f3dd6645  vmovaps [rsp+0x30], xmm3
000070d6f3dd664b  vmovaps [rsp+0x40], xmm4
000070d6f3dd6651  vmovaps [rsp+0x50], xmm5
000070d6f3dd6657  vmovaps [rsp+0x60], xmm6
000070d6f3dd665d  vmovaps [rsp+0x70], xmm7
000070d6f3dd6663  vmovaps [rsp+0x80], xmm8
000070d6f3dd666c  vmovaps [rsp+0x90], xmm9
000070d6f3dd6675  vmovaps [rsp+0xA0], xmm10
000070d6f3dd667e  vmovaps [rsp+0xB0], xmm11
000070d6f3dd6687  vmovaps [rsp+0xC0], xmm12
000070d6f3dd6690  vmovaps [rsp+0xD0], xmm13
000070d6f3dd6699  vmovaps [rsp+0xE0], xmm15
000070d6f3dd66a2  sub rsp, 0x40
000070d6f3dd66a6  lea rdi, [rsp]
000070d6f3dd66aa  lea rsi, [rsp+0x10]
000070d6f3dd66af  lea rdx, [rsp+0x20]
000070d6f3dd66b4  lea rcx, [rsp+0x30]
000070d6f3dd66b9  mov r8d, 0x00
000070d6f3dd66bf  lea r9, [r15+0x3A8]
000070d6f3dd66c6  movaps [rdi], xmm14
000070d6f3dd66ca  movaps [rsi], xmm12
000070d6f3dd66ce  movaps [rdx], xmm1
000070d6f3dd66d1  movaps [rcx], xmm15
000070d6f3dd66d5  mov rax, 0x61D08D40EA50
000070d6f3dd66df  call rax
000070d6f3dd66e1  movaps xmm14, [rsp]
000070d6f3dd66e6  add rsp, 0x40
000070d6f3dd66ea  vmovaps xmm0, [rsp]
000070d6f3dd66ef  vmovaps xmm1, [rsp+0x10]
000070d6f3dd66f5  vmovaps xmm2, [rsp+0x20]
000070d6f3dd66fb  vmovaps xmm3, [rsp+0x30]
000070d6f3dd6701  vmovaps xmm4, [rsp+0x40]
000070d6f3dd6707  vmovaps xmm5, [rsp+0x50]
000070d6f3dd670d  vmovaps xmm6, [rsp+0x60]
000070d6f3dd6713  vmovaps xmm7, [rsp+0x70]
000070d6f3dd6719  vmovaps xmm8, [rsp+0x80]
000070d6f3dd6722  vmovaps xmm9, [rsp+0x90]
000070d6f3dd672b  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd6734  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd673d  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd6746  vmovaps xmm13, [rsp+0xD0]
000070d6f3dd674f  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd6758  add rsp, 0xF0
000070d6f3dd675f  pop r11
000070d6f3dd6761  pop r10
000070d6f3dd6763  pop r9
000070d6f3dd6765  pop r8
000070d6f3dd6767  pop rsi
000070d6f3dd6768  pop rdi
000070d6f3dd6769  pop rdx
000070d6f3dd676a  pop rcx
000070d6f3dd676b  pop rax
000070d6f3dd676c  add rsp, 0x08
000070d6f3dd6770  jmp 0x000070D6F3DD3AF9
000070d6f3dd6775  call 0x000070D6F3CACF70
000070d6f3dd677a  jmp 0x000070D6F3DD3B07
000070d6f3dd677f  call 0x000070D6F3C0C380
000070d6f3dd6784  jmp 0x000070D6F3DD3B11
000070d6f3dd6789  call 0x000070D6F3C08C20
000070d6f3dd678e  jmp 0x000070D6F3DD3B1B
000070d6f3dd6793  call 0x000070D6F3C0D600
000070d6f3dd6798  jmp 0x000070D6F3DD3B25
000070d6f3dd679d  int3
000070d6f3dd679e  nop
000070d6f3dd67a0  mov eax, [r15+0x48]
000070d6f3dd67a4  lea r14d, [eax+0x01]
000070d6f3dd67a9  mov [rsp+0x10], r14d
000070d6f3dd67ae  mov r14d, r14d
000070d6f3dd67b1  mov [r15+0x48], r14
000070d6f3dd67b5  xor eax, eax
000070d6f3dd67b7  mov r14d, [rsp+0x10]
000070d6f3dd67bc  cmp r14d, 0x1F4
000070d6f3dd67c3  cmc
000070d6f3dd67c4  lahf
000070d6f3dd67c5  seto al
000070d6f3dd67c8  mov [r15+0x108], eax
000070d6f3dd67cf  mov eax, [r15+0x108]
000070d6f3dd67d6  sahf
000070d6f3dd67d7  jnz 0x000070D6F3DD6809
000070d6f3dd67d9  cmp dword ptr [r15+0x318], 0x00
000070d6f3dd67e1  jz 0x000070D6F3DDA1A0
000070d6f3dd67e7  nop [rax+rax*1], ax
000070d6f3dd67f0  nop [rax+rax*1], eax
000070d6f3dd67f8  mov eax, 0x4103FC
000070d6f3dd67fd  mov [r15+0x100], rax
000070d6f3dd6804  jmp 0x000070D6F3BFE110
000070d6f3dd6809  cmp dword ptr [r15+0x318], 0x00
000070d6f3dd6811  jz 0x000070D6F3DD6840
000070d6f3dd6817  nop [rax+rax*1], ax
000070d6f3dd6820  nop [rax+rax*1], eax
000070d6f3dd6828  mov eax, 0x410270
000070d6f3dd682d  mov [r15+0x100], rax
000070d6f3dd6834  jmp 0x000070D6F3BFE110
000070d6f3dd6839  int3
000070d6f3dd683a  int3
000070d6f3dd683b  nop [rax+rax*1], eax
000070d6f3dd6840  mov rax, [r15+0x40]
000070d6f3dd6844  vxorps xmm1, xmm1, xmm1
000070d6f3dd6848  vpbroadcastq xmm1, xmm1
000070d6f3dd684d  vxorps xmm15, xmm15, xmm15
000070d6f3dd6852  vpbroadcastq xmm15, xmm15
000070d6f3dd6857  lea r14, [rax+0x30]
000070d6f3dd685b  mov r12, [r13+r14*1]
000070d6f3dd6860  lea r14, [rax+0x38]
000070d6f3dd6864  mov r11, [r13+r14*1]
000070d6f3dd6869  movq xmm14, r12
000070d6f3dd686e  movq xmm13, r11
000070d6f3dd6873  movq xmm14, xmm14
000070d6f3dd6878  movq xmm13, xmm13
000070d6f3dd687d  vmovaps [rsp+0x10], xmm13
000070d6f3dd6883  movq xmm13, xmm13
000070d6f3dd6888  movaps [r15+0x270], xmm13
000070d6f3dd6890  movaps xmm13, [r15+0x160]
000070d6f3dd6898  vmovaps [rsp+0x20], xmm13
000070d6f3dd689e  vmovaps xmm12, [rsp+0x20]
000070d6f3dd68a4  por xmm13, xmm12
000070d6f3dd68a9  lea r14, [rax+0x20]
000070d6f3dd68ad  mov r12, [r13+r14*1]
000070d6f3dd68b2  lea r14, [rax+0x28]
000070d6f3dd68b6  mov r11, [r13+r14*1]
000070d6f3dd68bb  movq xmm12, r12
000070d6f3dd68c0  movq xmm11, r11
000070d6f3dd68c5  movq xmm12, xmm12
000070d6f3dd68ca  movq xmm11, xmm11
000070d6f3dd68cf  movaps xmm10, [r15+0x2F0]
000070d6f3dd68d7  vmovaps [rsp+0x20], xmm10
000070d6f3dd68dd  vmovaps xmm9, [rsp+0x20]
000070d6f3dd68e3  por xmm10, xmm9
000070d6f3dd68e8  movaps xmm9, [r15+0x2D0]
000070d6f3dd68f0  vmovaps [rsp+0x20], xmm9
000070d6f3dd68f6  vmovaps xmm8, [rsp+0x20]
000070d6f3dd68fc  por xmm9, xmm8
000070d6f3dd6901  movaps xmm8, [r15+0x300]
000070d6f3dd6909  vmovaps [rsp+0x20], xmm8
000070d6f3dd690f  vmovaps xmm7, [rsp+0x20]
000070d6f3dd6915  por xmm8, xmm7
000070d6f3dd691a  movaps xmm7, [r15+0x2B0]
000070d6f3dd6922  vmovaps [rsp+0x20], xmm7
000070d6f3dd6928  vmovaps xmm6, [rsp+0x20]
000070d6f3dd692e  por xmm7, xmm6
000070d6f3dd6932  movaps xmm6, [r15+0x180]
000070d6f3dd693a  vmovaps [rsp+0x20], xmm6
000070d6f3dd6940  vmovaps xmm5, [rsp+0x20]
000070d6f3dd6946  por xmm6, xmm5
000070d6f3dd694a  lea r14, [rax+0x10]
000070d6f3dd694e  mov r12, [r13+r14*1]
000070d6f3dd6953  lea r14, [rax+0x18]
000070d6f3dd6957  mov r11, [r13+r14*1]
000070d6f3dd695c  movq xmm5, r12
000070d6f3dd6961  movq xmm4, r11
000070d6f3dd6966  movq xmm5, xmm5
000070d6f3dd696a  movq xmm4, xmm4
000070d6f3dd696e  movaps xmm3, [r15+0x200]
000070d6f3dd6976  vmovaps [rsp+0x20], xmm3
000070d6f3dd697c  vmovaps xmm2, [rsp+0x20]
000070d6f3dd6982  por xmm3, xmm2
000070d6f3dd6986  movaps xmm2, [r15+0x1F0]
000070d6f3dd698e  vmovaps [rsp+0x20], xmm2
000070d6f3dd6994  vmovaps [rsp+0x30], xmm1
000070d6f3dd699a  vmovaps xmm1, [rsp+0x20]
000070d6f3dd69a0  por xmm2, xmm1
000070d6f3dd69a4  movaps xmm1, [r15+0x2E0]
000070d6f3dd69ac  vmovaps [rsp+0x20], xmm1
000070d6f3dd69b2  vmovaps [rsp+0x40], xmm15
000070d6f3dd69b8  vmovaps xmm15, [rsp+0x20]
000070d6f3dd69be  por xmm1, xmm15
000070d6f3dd69c3  movaps xmm15, [r15+0x2A0]
000070d6f3dd69cb  vmovaps [rsp+0x20], xmm15
000070d6f3dd69d1  vmovaps [rsp+0x50], xmm1
000070d6f3dd69d7  vmovaps xmm1, [rsp+0x20]
000070d6f3dd69dd  por xmm15, xmm1
000070d6f3dd69e2  movaps xmm1, [r15+0x280]
000070d6f3dd69ea  vmovaps [rsp+0x20], xmm1
000070d6f3dd69f0  vmovaps [rsp+0x60], xmm15
000070d6f3dd69f6  vmovaps xmm15, [rsp+0x20]
000070d6f3dd69fc  por xmm1, xmm15
000070d6f3dd6a01  movaps xmm15, [r15+0x1C0]
000070d6f3dd6a09  vmovaps [rsp+0x20], xmm15
000070d6f3dd6a0f  vmovaps [rsp+0x70], xmm1
000070d6f3dd6a15  vmovaps xmm1, [rsp+0x20]
000070d6f3dd6a1b  por xmm15, xmm1
000070d6f3dd6a20  movaps xmm1, [r15+0x210]
000070d6f3dd6a28  vmovaps [rsp+0x20], xmm1
000070d6f3dd6a2e  vmovaps [rsp+0x80], xmm15
000070d6f3dd6a37  vmovaps xmm15, [rsp+0x20]
000070d6f3dd6a3d  por xmm1, xmm15
000070d6f3dd6a42  mov r14, [r13+rax*1]
000070d6f3dd6a47  vmovq xmm15, r14
000070d6f3dd6a4c  vpbroadcastq xmm15, xmm15
000070d6f3dd6a51  vmovaps [rsp+0x20], xmm1
000070d6f3dd6a57  vxorps xmm1, xmm1, xmm1
000070d6f3dd6a5b  vpbroadcastq xmm1, xmm1
000070d6f3dd6a60  mov r14, [r15+0xF8]
000070d6f3dd6a67  vmovaps [rsp+0x90], xmm1
000070d6f3dd6a70  movups xmm1, [r13+r14*1]
000070d6f3dd6a76  vmovaps [rsp+0xA0], xmm1
000070d6f3dd6a7f  vxorps xmm1, xmm1, xmm1
000070d6f3dd6a83  vpbroadcastq xmm1, xmm1
000070d6f3dd6a88  lea r12, [rax+0x08]
000070d6f3dd6a8c  mov rax, [r13+r12*1]
000070d6f3dd6a91  vmovaps [rsp+0xB0], xmm1
000070d6f3dd6a9a  movq xmm1, rax
000070d6f3dd6a9f  movaps [r15+0x240], xmm1
000070d6f3dd6aa7  mov rax, [r15+0x50]
000070d6f3dd6aab  mov [r15+0x60], rax
000070d6f3dd6aaf  mov qword ptr [r15+0x58], 0x40
000070d6f3dd6ab7  vmovaps xmm1, [rsp+0x30]
000070d6f3dd6abd  vmovaps [rsp+0x30], xmm15
000070d6f3dd6ac3  vmovaps xmm15, [rsp+0xA0]
000070d6f3dd6acc  vmovaps [rsp+0xA0], xmm14
000070d6f3dd6ad5  vmovaps xmm14, [rsp+0x30]
000070d6f3dd6adb  vmovaps [rsp+0x30], xmm13
000070d6f3dd6ae1  vmovaps [rsp+0xC0], xmm12
000070d6f3dd6aea  movaps xmm13, xmm1
000070d6f3dd6aee  vfmadd231pd xmm13, xmm15, xmm14
000070d6f3dd6af3  vcmppd xmm12, xmm13, xmm13, 0x03
000070d6f3dd6af9  vptest xmm12, xmm12
000070d6f3dd6afe  jnz 0x000070D6F3DD75DD
000070d6f3dd6b04  movaps xmm1, [r15+0x250]
000070d6f3dd6b0c  vmovaps xmm15, [rsp+0x40]
000070d6f3dd6b12  vmovaps [rsp+0x40], xmm13
000070d6f3dd6b18  movaps xmm12, xmm15
000070d6f3dd6b1c  vfmadd231pd xmm12, xmm1, xmm14
000070d6f3dd6b21  vcmppd xmm13, xmm12, xmm12, 0x03
000070d6f3dd6b27  vptest xmm13, xmm13
000070d6f3dd6b2c  jnz 0x000070D6F3DD7736
000070d6f3dd6b32  movaps xmm15, [r15+0x1E0]
000070d6f3dd6b3a  vmovaps [rsp+0xD0], xmm15
000070d6f3dd6b43  vmovaps xmm13, [rsp+0xD0]
000070d6f3dd6b4c  por xmm15, xmm13
000070d6f3dd6b51  movaps xmm13, [r15+0x1D0]
000070d6f3dd6b59  vmovaps [rsp+0xD0], xmm13
000070d6f3dd6b62  vmovaps [rsp+0xE0], xmm1
000070d6f3dd6b6b  vmovaps xmm1, [rsp+0xD0]
000070d6f3dd6b74  por xmm13, xmm1
000070d6f3dd6b79  movaps xmm1, [r15+0x2C0]
000070d6f3dd6b81  vmovaps [rsp+0xD0], xmm1
000070d6f3dd6b8a  vmovaps [rsp+0xF0], xmm15
000070d6f3dd6b93  vmovaps xmm15, [rsp+0xD0]
000070d6f3dd6b9c  por xmm1, xmm15
000070d6f3dd6ba1  movaps xmm15, [r15+0x290]
000070d6f3dd6ba9  vmovaps [rsp+0xD0], xmm15
000070d6f3dd6bb2  vmovaps [rsp+0x100], xmm1
000070d6f3dd6bbb  vmovaps xmm1, [rsp+0xD0]
000070d6f3dd6bc4  por xmm15, xmm1
000070d6f3dd6bc9  movaps xmm1, [r15+0x260]
000070d6f3dd6bd1  vmovaps [rsp+0xD0], xmm1
000070d6f3dd6bda  vmovaps [rsp+0x110], xmm15
000070d6f3dd6be3  vmovaps xmm15, [rsp+0xD0]
000070d6f3dd6bec  por xmm1, xmm15
000070d6f3dd6bf1  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd6bfa  vmovaps [rsp+0xD0], xmm1
000070d6f3dd6c03  vmovaps xmm1, [rsp+0xE0]
000070d6f3dd6c0c  por xmm15, xmm1
000070d6f3dd6c11  lea r12, [r14+0xC0]
000070d6f3dd6c18  movups xmm1, [r13+r12*1]
000070d6f3dd6c1e  mov [rsp+0xE0], rax
000070d6f3dd6c26  xor eax, eax
000070d6f3dd6c28  mov r12d, 0x40
000070d6f3dd6c2e  mov r11d, 0x200
000070d6f3dd6c34  cmp r12, r11
000070d6f3dd6c37  cmc
000070d6f3dd6c38  lahf
000070d6f3dd6c39  seto al
000070d6f3dd6c3c  mov [r15+0x108], eax
000070d6f3dd6c43  vmovaps [rsp+0x120], xmm1
000070d6f3dd6c4c  vmovaps xmm1, [rsp+0x90]
000070d6f3dd6c55  vmovaps [rsp+0x90], xmm15
000070d6f3dd6c5e  vmovaps xmm15, [rsp+0x120]
000070d6f3dd6c67  vmovaps [rsp+0x120], xmm13
000070d6f3dd6c70  vmovaps [rsp+0x130], xmm12
000070d6f3dd6c79  movaps xmm13, xmm1
000070d6f3dd6c7d  vfmadd231pd xmm13, xmm15, xmm14
000070d6f3dd6c82  vcmppd xmm12, xmm13, xmm13, 0x03
000070d6f3dd6c88  vptest xmm12, xmm12
000070d6f3dd6c8d  jnz 0x000070D6F3DD7899
000070d6f3dd6c93  lea rax, [r14+0xB0]
000070d6f3dd6c9a  movups xmm1, [r13+rax*1]
000070d6f3dd6ca0  vmovaps xmm15, [rsp+0xB0]
000070d6f3dd6ca9  vmovaps [rsp+0xB0], xmm13
000070d6f3dd6cb2  movaps xmm12, xmm15
000070d6f3dd6cb6  vfmadd231pd xmm12, xmm1, xmm14
000070d6f3dd6cbb  vcmppd xmm13, xmm12, xmm12, 0x03
000070d6f3dd6cc1  vptest xmm13, xmm13
000070d6f3dd6cc6  jnz 0x000070D6F3DD79FC
000070d6f3dd6ccc  vmovaps xmm1, [rsp+0x20]
000070d6f3dd6cd2  vmovaps xmm15, [rsp+0x20]
000070d6f3dd6cd8  por xmm1, xmm15
000070d6f3dd6cdd  movaps [r15+0x210], xmm1
000070d6f3dd6ce5  vmovaps xmm15, [rsp+0x80]
000070d6f3dd6cee  vmovaps xmm14, [rsp+0x80]
000070d6f3dd6cf7  por xmm15, xmm14
000070d6f3dd6cfc  movaps [r15+0x1C0], xmm15
000070d6f3dd6d04  vmovaps xmm14, [rsp+0x70]
000070d6f3dd6d0a  vmovaps xmm13, [rsp+0x70]
000070d6f3dd6d10  por xmm14, xmm13
000070d6f3dd6d15  movaps [r15+0x280], xmm14
000070d6f3dd6d1d  vmovaps xmm13, [rsp+0x60]
000070d6f3dd6d23  vmovaps [rsp+0x20], xmm1
000070d6f3dd6d29  vmovaps xmm1, [rsp+0x60]
000070d6f3dd6d2f  por xmm13, xmm1
000070d6f3dd6d34  movaps [r15+0x2A0], xmm13
000070d6f3dd6d3c  vmovaps xmm1, [rsp+0x50]
000070d6f3dd6d42  vmovaps [rsp+0x60], xmm15
000070d6f3dd6d48  vmovaps xmm15, [rsp+0x50]
000070d6f3dd6d4e  por xmm1, xmm15
000070d6f3dd6d53  movaps [r15+0x2E0], xmm1
000070d6f3dd6d5b  vmovaps [rsp+0x50], xmm2
000070d6f3dd6d61  vmovaps xmm15, [rsp+0x50]
000070d6f3dd6d67  por xmm2, xmm15
000070d6f3dd6d6c  movaps [r15+0x1F0], xmm2
000070d6f3dd6d74  vmovaps xmm15, [rsp+0x90]
000070d6f3dd6d7d  vmovaps [rsp+0x50], xmm1
000070d6f3dd6d83  vmovaps xmm1, [rsp+0x90]
000070d6f3dd6d8c  por xmm15, xmm1
000070d6f3dd6d91  movaps [r15+0x250], xmm15
000070d6f3dd6d99  vmovaps xmm1, [rsp+0xD0]
000070d6f3dd6da2  vmovaps xmm15, [rsp+0xD0]
000070d6f3dd6dab  por xmm1, xmm15
000070d6f3dd6db0  movaps [r15+0x260], xmm1
000070d6f3dd6db8  vmovaps xmm15, [rsp+0x110]
000070d6f3dd6dc1  vmovaps [rsp+0x70], xmm1
000070d6f3dd6dc7  vmovaps xmm1, [rsp+0x110]
000070d6f3dd6dd0  por xmm15, xmm1
000070d6f3dd6dd5  movaps [r15+0x290], xmm15
000070d6f3dd6ddd  vmovaps xmm1, [rsp+0x100]
000070d6f3dd6de6  vmovaps [rsp+0x80], xmm15
000070d6f3dd6def  vmovaps xmm15, [rsp+0x100]
000070d6f3dd6df8  por xmm1, xmm15
000070d6f3dd6dfd  movaps [r15+0x2C0], xmm1
000070d6f3dd6e05  movq xmm15, qword ptr [r15+0x240]
000070d6f3dd6e0e  vmovaps [rsp+0x90], xmm15
000070d6f3dd6e17  vpermilpd xmm15, xmm15, 0x00
000070d6f3dd6e1d  vmovaps [rsp+0xD0], xmm1
000070d6f3dd6e26  vmovaps xmm1, [rsp+0x40]
000070d6f3dd6e2c  vmovaps [rsp+0x40], xmm15
000070d6f3dd6e32  vmovaps xmm15, [rsp+0x20]
000070d6f3dd6e38  vmovaps [rsp+0x20], xmm14
000070d6f3dd6e3e  vmovaps xmm14, [rsp+0x40]
000070d6f3dd6e44  vmovaps [rsp+0x40], xmm13
000070d6f3dd6e4a  vmovaps [rsp+0x100], xmm12
000070d6f3dd6e53  movaps xmm13, xmm1
000070d6f3dd6e57  vfmadd231pd xmm13, xmm15, xmm14
000070d6f3dd6e5c  vcmppd xmm12, xmm13, xmm13, 0x03
000070d6f3dd6e62  vptest xmm12, xmm12
000070d6f3dd6e67  jnz 0x000070D6F3DD7B55
000070d6f3dd6e6d  vmovaps xmm1, [rsp+0x90]
000070d6f3dd6e76  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd6e7c  vmovaps xmm15, [rsp+0xB0]
000070d6f3dd6e85  vmovaps xmm14, [rsp+0x50]
000070d6f3dd6e8b  vmovaps [rsp+0x50], xmm13
000070d6f3dd6e91  movaps xmm12, xmm15
000070d6f3dd6e95  vfmadd231pd xmm12, xmm14, xmm1
000070d6f3dd6e9a  vcmppd xmm13, xmm12, xmm12, 0x03
000070d6f3dd6ea0  vptest xmm13, xmm13
000070d6f3dd6ea5  jnz 0x000070D6F3DD7CAE
000070d6f3dd6eab  vmovaps xmm1, [rsp+0x90]
000070d6f3dd6eb4  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd6eba  vmovaps xmm15, [rsp+0x130]
000070d6f3dd6ec3  vmovaps xmm14, [rsp+0x60]
000070d6f3dd6ec9  vmovaps [rsp+0x60], xmm12
000070d6f3dd6ecf  movaps xmm13, xmm15
000070d6f3dd6ed3  vfmadd231pd xmm13, xmm14, xmm1
000070d6f3dd6ed8  vcmppd xmm12, xmm13, xmm13, 0x03
000070d6f3dd6ede  vptest xmm12, xmm12
000070d6f3dd6ee3  jnz 0x000070D6F3DD7E07
000070d6f3dd6ee9  vmovaps xmm1, [rsp+0x120]
000070d6f3dd6ef2  vmovaps xmm15, [rsp+0x120]
000070d6f3dd6efb  por xmm1, xmm15
000070d6f3dd6f00  movaps [r15+0x1D0], xmm1
000070d6f3dd6f08  vmovaps xmm15, [rsp+0x90]
000070d6f3dd6f11  vpermilpd xmm15, xmm15, 0x00
000070d6f3dd6f17  vmovaps xmm14, [rsp+0x100]
000070d6f3dd6f20  vmovaps [rsp+0x90], xmm1
000070d6f3dd6f29  movaps xmm12, xmm14
000070d6f3dd6f2d  vfmadd231pd xmm12, xmm2, xmm15
000070d6f3dd6f32  vcmppd xmm1, xmm12, xmm12, 0x03
000070d6f3dd6f38  vptest xmm1, xmm1
000070d6f3dd6f3d  jnz 0x000070D6F3DD7F60
000070d6f3dd6f43  vmovaps [rsp+0xB0], xmm3
000070d6f3dd6f4c  vmovaps xmm1, [rsp+0xB0]
000070d6f3dd6f55  por xmm3, xmm1
000070d6f3dd6f59  movaps [r15+0x200], xmm3
000070d6f3dd6f61  vmovaps xmm1, [rsp+0xF0]
000070d6f3dd6f6a  vmovaps xmm15, [rsp+0xF0]
000070d6f3dd6f73  por xmm1, xmm15
000070d6f3dd6f78  movaps [r15+0x1E0], xmm1
000070d6f3dd6f80  vmovaps [rsp+0xB0], xmm7
000070d6f3dd6f89  vmovaps xmm1, [rsp+0xB0]
000070d6f3dd6f92  por xmm7, xmm1
000070d6f3dd6f96  movaps [r15+0x2B0], xmm7
000070d6f3dd6f9e  vmovaps [rsp+0xB0], xmm8
000070d6f3dd6fa7  vmovaps xmm1, [rsp+0xB0]
000070d6f3dd6fb0  por xmm8, xmm1
000070d6f3dd6fb5  movaps [r15+0x300], xmm8
000070d6f3dd6fbd  vmovaps [rsp+0xB0], xmm5
000070d6f3dd6fc6  vpermilpd xmm5, xmm5, 0x00
000070d6f3dd6fcc  vmovaps xmm14, [rsp+0x50]
000070d6f3dd6fd2  vmovaps xmm8, [rsp+0x70]
000070d6f3dd6fd8  vmovaps [rsp+0x50], xmm1
000070d6f3dd6fde  movaps xmm2, xmm14
000070d6f3dd6fe2  vfmadd231pd xmm2, xmm8, xmm5
000070d6f3dd6fe7  vcmppd xmm1, xmm2, xmm2, 0x03
000070d6f3dd6fec  vptest xmm1, xmm1
000070d6f3dd6ff1  jnz 0x000070D6F3DD80B9
000070d6f3dd6ff7  vmovaps xmm1, [rsp+0xB0]
000070d6f3dd7000  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd7006  vmovaps xmm14, [rsp+0x60]
000070d6f3dd700c  vmovaps xmm8, [rsp+0xD0]
000070d6f3dd7015  vmovaps [rsp+0x60], xmm15
000070d6f3dd701b  movaps xmm5, xmm14
000070d6f3dd701f  vfmadd231pd xmm5, xmm8, xmm1
000070d6f3dd7024  vcmppd xmm15, xmm5, xmm5, 0x03
000070d6f3dd7029  vptest xmm15, xmm15
000070d6f3dd702e  jnz 0x000070D6F3DD8210
000070d6f3dd7034  vmovaps xmm1, [rsp+0xB0]
000070d6f3dd703d  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd7043  vmovaps xmm14, [rsp+0x20]
000070d6f3dd7049  movaps xmm15, xmm13
000070d6f3dd704d  vfmadd231pd xmm15, xmm14, xmm1
000070d6f3dd7052  vcmppd xmm8, xmm15, xmm15, 0x03
000070d6f3dd7058  vptest xmm8, xmm8
000070d6f3dd705d  jnz 0x000070D6F3DD8367
000070d6f3dd7063  vmovaps xmm1, [rsp+0xB0]
000070d6f3dd706c  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd7072  vmovaps xmm14, [rsp+0x90]
000070d6f3dd707b  movaps xmm13, xmm12
000070d6f3dd707f  vfmadd231pd xmm13, xmm14, xmm1
000070d6f3dd7084  vcmppd xmm8, xmm13, xmm13, 0x03
000070d6f3dd708a  vptest xmm8, xmm8
000070d6f3dd708f  jnz 0x000070D6F3DD84C0
000070d6f3dd7095  vmovaps [rsp+0x20], xmm6
000070d6f3dd709b  vmovaps xmm1, [rsp+0x20]
000070d6f3dd70a1  por xmm6, xmm1
000070d6f3dd70a5  movaps [r15+0x180], xmm6
000070d6f3dd70ad  vmovaps [rsp+0x20], xmm9
000070d6f3dd70b3  vmovaps xmm1, [rsp+0x20]
000070d6f3dd70b9  por xmm9, xmm1
000070d6f3dd70be  movaps [r15+0x2D0], xmm9
000070d6f3dd70c6  vmovaps [rsp+0x20], xmm10
000070d6f3dd70cc  vmovaps xmm1, [rsp+0x20]
000070d6f3dd70d2  por xmm10, xmm1
000070d6f3dd70d7  movaps [r15+0x2F0], xmm10
000070d6f3dd70df  vmovaps [rsp+0x20], xmm4
000070d6f3dd70e5  vpermilpd xmm4, xmm4, 0x00
000070d6f3dd70eb  vmovaps xmm14, [rsp+0x50]
000070d6f3dd70f1  movaps xmm12, xmm5
000070d6f3dd70f5  vfmadd231pd xmm12, xmm14, xmm4
000070d6f3dd70fa  vcmppd xmm10, xmm12, xmm12, 0x03
000070d6f3dd7100  vptest xmm10, xmm10
000070d6f3dd7105  jnz 0x000070D6F3DD8619
000070d6f3dd710b  vmovaps xmm14, [rsp+0x20]
000070d6f3dd7111  vpermilpd xmm14, xmm14, 0x00
000070d6f3dd7117  movaps xmm10, xmm2
000070d6f3dd711b  vfmadd231pd xmm10, xmm6, xmm14
000070d6f3dd7120  vcmppd xmm8, xmm10, xmm10, 0x03
000070d6f3dd7126  vptest xmm8, xmm8
000070d6f3dd712b  jnz 0x000070D6F3DD8771
000070d6f3dd7131  lea rax, [r14+0x80]
000070d6f3dd7138  movups xmm14, [r13+rax*1]
000070d6f3dd713e  movaps [r15+0x190], xmm14
000070d6f3dd7146  vmovaps xmm8, [rsp+0x20]
000070d6f3dd714c  vpermilpd xmm8, xmm8, 0x00
000070d6f3dd7152  vmovaps xmm6, [rsp+0x80]
000070d6f3dd715b  movaps xmm5, xmm15
000070d6f3dd715f  vfmadd231pd xmm5, xmm6, xmm8
000070d6f3dd7164  vcmppd xmm4, xmm5, xmm5, 0x03
000070d6f3dd7169  vptest xmm4, xmm4
000070d6f3dd716e  jnz 0x000070D6F3DD88D3
000070d6f3dd7174  vmovaps xmm15, [rsp+0x20]
000070d6f3dd717a  vpermilpd xmm15, xmm15, 0x00
000070d6f3dd7180  movaps xmm8, xmm13
000070d6f3dd7184  vfmadd231pd xmm8, xmm1, xmm15
000070d6f3dd7189  vcmppd xmm6, xmm8, xmm8, 0x03
000070d6f3dd718f  vptest xmm6, xmm6
000070d6f3dd7194  jnz 0x000070D6F3DD8A2A
000070d6f3dd719a  vmovaps xmm1, [rsp+0x30]
000070d6f3dd71a0  vmovaps xmm15, [rsp+0x30]
000070d6f3dd71a6  por xmm1, xmm15
000070d6f3dd71ab  movaps [r15+0x160], xmm1
000070d6f3dd71b3  lea rax, [r14+0x40]
000070d6f3dd71b7  movups xmm15, [r13+rax*1]
000070d6f3dd71bd  lea rax, [r14+0x50]
000070d6f3dd71c1  movups xmm13, [r13+rax*1]
000070d6f3dd71c7  movaps [r15+0x1B0], xmm15
000070d6f3dd71cf  movaps [r15+0x1A0], xmm13
000070d6f3dd71d7  vmovaps xmm6, [rsp+0xC0]
000070d6f3dd71e0  vpermilpd xmm6, xmm6, 0x00
000070d6f3dd71e6  movaps xmm4, xmm12
000070d6f3dd71ea  vfmadd231pd xmm4, xmm9, xmm6
000070d6f3dd71ef  vcmppd xmm2, xmm4, xmm4, 0x03
000070d6f3dd71f4  vptest xmm2, xmm2
000070d6f3dd71f9  jnz 0x000070D6F3DD8B97
000070d6f3dd71ff  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd7208  vpermilpd xmm12, xmm12, 0x00
000070d6f3dd720e  movaps xmm9, xmm10
000070d6f3dd7212  vfmadd231pd xmm9, xmm1, xmm12
000070d6f3dd7217  vcmppd xmm6, xmm9, xmm9, 0x03
000070d6f3dd721d  vptest xmm6, xmm6
000070d6f3dd7222  jnz 0x000070D6F3DD8CEE
000070d6f3dd7228  vmovaps xmm1, [rsp+0xC0]
000070d6f3dd7231  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd7237  vmovaps xmm12, [rsp+0x40]
000070d6f3dd723d  movaps xmm10, xmm5
000070d6f3dd7241  vfmadd231pd xmm10, xmm12, xmm1
000070d6f3dd7246  vcmppd xmm6, xmm10, xmm10, 0x03
000070d6f3dd724c  vptest xmm6, xmm6
000070d6f3dd7251  jnz 0x000070D6F3DD8E47
000070d6f3dd7257  vmovaps xmm1, [rsp+0xC0]
000070d6f3dd7260  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd7266  vmovaps xmm12, [rsp+0x60]
000070d6f3dd726c  movaps xmm6, xmm8
000070d6f3dd7270  vfmadd231pd xmm6, xmm12, xmm1
000070d6f3dd7275  vcmppd xmm5, xmm6, xmm6, 0x03
000070d6f3dd727a  vptest xmm5, xmm5
000070d6f3dd727f  jnz 0x000070D6F3DD8F9F
000070d6f3dd7285  lea rax, [r14+0x60]
000070d6f3dd7289  movups xmm1, [r13+rax*1]
000070d6f3dd728f  lea rax, [r14+0x70]
000070d6f3dd7293  movups xmm12, [r13+rax*1]
000070d6f3dd7299  movaps [r15+0x150], xmm1
000070d6f3dd72a1  movaps [r15+0x120], xmm12
000070d6f3dd72a9  vmovaps [rsp+0x20], xmm11
000070d6f3dd72af  vpermilpd xmm11, xmm11, 0x00
000070d6f3dd72b5  movaps xmm8, xmm4
000070d6f3dd72b9  vfmadd231pd xmm8, xmm13, xmm11
000070d6f3dd72be  vcmppd xmm5, xmm8, xmm8, 0x03
000070d6f3dd72c4  vptest xmm5, xmm5
000070d6f3dd72c9  jnz 0x000070D6F3DD910A
000070d6f3dd72cf  vmovaps xmm13, [rsp+0x20]
000070d6f3dd72d5  vpermilpd xmm13, xmm13, 0x00
000070d6f3dd72db  movaps xmm11, xmm9
000070d6f3dd72df  vfmadd231pd xmm11, xmm1, xmm13
000070d6f3dd72e4  vcmppd xmm5, xmm11, xmm11, 0x03
000070d6f3dd72ea  vptest xmm5, xmm5
000070d6f3dd72ef  jnz 0x000070D6F3DD9263
000070d6f3dd72f5  vmovaps xmm1, [rsp+0x20]
000070d6f3dd72fb  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd7301  movaps xmm13, xmm10
000070d6f3dd7305  vfmadd231pd xmm13, xmm7, xmm1
000070d6f3dd730a  vcmppd xmm9, xmm13, xmm13, 0x03
000070d6f3dd7310  vptest xmm9, xmm9
000070d6f3dd7315  jnz 0x000070D6F3DD93BC
000070d6f3dd731b  vmovaps xmm1, [rsp+0x20]
000070d6f3dd7321  vpermilpd xmm1, xmm1, 0x00
000070d6f3dd7327  movaps xmm10, xmm6
000070d6f3dd732b  vfmadd231pd xmm10, xmm15, xmm1
000070d6f3dd7330  vcmppd xmm9, xmm10, xmm10, 0x03
000070d6f3dd7336  vptest xmm9, xmm9
000070d6f3dd733b  jnz 0x000070D6F3DD9514
000070d6f3dd7341  lea rax, [r14+0x20]
000070d6f3dd7345  movups xmm1, [r13+rax*1]
000070d6f3dd734b  lea rax, [r14+0x30]
000070d6f3dd734f  movups xmm15, [r13+rax*1]
000070d6f3dd7355  vmovaps xmm9, [rsp+0xA0]
000070d6f3dd735e  vpermilpd xmm9, xmm9, 0x00
000070d6f3dd7364  movaps xmm7, xmm8
000070d6f3dd7368  vfmadd231pd xmm7, xmm3, xmm9
000070d6f3dd736d  vcmppd xmm6, xmm7, xmm7, 0x03
000070d6f3dd7372  vptest xmm6, xmm6
000070d6f3dd7377  jnz 0x000070D6F3DD9680
000070d6f3dd737d  vmovaps xmm9, [rsp+0xA0]
000070d6f3dd7386  vpermilpd xmm9, xmm9, 0x00
000070d6f3dd738c  movaps xmm8, xmm11
000070d6f3dd7390  vfmadd231pd xmm8, xmm14, xmm9
000070d6f3dd7395  vcmppd xmm6, xmm8, xmm8, 0x03
000070d6f3dd739b  vptest xmm6, xmm6
000070d6f3dd73a0  jnz 0x000070D6F3DD97D7
000070d6f3dd73a6  vmovaps xmm14, [rsp+0xA0]
000070d6f3dd73af  vpermilpd xmm14, xmm14, 0x00
000070d6f3dd73b5  movaps xmm11, xmm13
000070d6f3dd73b9  vfmadd231pd xmm11, xmm12, xmm14
000070d6f3dd73be  vcmppd xmm9, xmm11, xmm11, 0x03
000070d6f3dd73c4  vptest xmm9, xmm9
000070d6f3dd73c9  jnz 0x000070D6F3DD9931
000070d6f3dd73cf  vmovaps xmm14, [rsp+0xA0]
000070d6f3dd73d8  vpermilpd xmm14, xmm14, 0x00
000070d6f3dd73de  movaps xmm12, xmm10
000070d6f3dd73e2  vfmadd231pd xmm12, xmm15, xmm14
000070d6f3dd73e7  vcmppd xmm13, xmm12, xmm12, 0x03
000070d6f3dd73ed  vptest xmm13, xmm13
000070d6f3dd73f2  jnz 0x000070D6F3DD9A8B
000070d6f3dd73f8  lea rax, [r14+0x90]
000070d6f3dd73ff  movups xmm15, [r13+rax*1]
000070d6f3dd7405  lea rax, [r14+0xA0]
000070d6f3dd740c  movups xmm14, [r13+rax*1]
000070d6f3dd7412  movaps [r15+0x140], xmm15
000070d6f3dd741a  movaps [r15+0x130], xmm14
000070d6f3dd7422  vmovaps xmm13, [rsp+0x10]
000070d6f3dd7428  vpermilpd xmm13, xmm13, 0x00
000070d6f3dd742e  movaps xmm10, xmm7
000070d6f3dd7432  vfmadd231pd xmm10, xmm1, xmm13
000070d6f3dd7437  vcmppd xmm9, xmm10, xmm10, 0x03
000070d6f3dd743d  vptest xmm9, xmm9
000070d6f3dd7442  jnz 0x000070D6F3DD9BF9
000070d6f3dd7448  movaps [r15+0x220], xmm10
000070d6f3dd7450  lea rax, [r14+0x10]
000070d6f3dd7454  movups xmm1, [r13+rax*1]
000070d6f3dd745a  movaps [r15+0x240], xmm1
000070d6f3dd7462  vmovaps xmm13, [rsp+0x10]
000070d6f3dd7468  vpermilpd xmm13, xmm13, 0x00
000070d6f3dd746e  movaps xmm9, xmm8
000070d6f3dd7472  vfmadd231pd xmm9, xmm14, xmm13
000070d6f3dd7477  vcmppd xmm7, xmm9, xmm9, 0x03
000070d6f3dd747d  vptest xmm7, xmm7
000070d6f3dd7482  jnz 0x000070D6F3DD9D5B
000070d6f3dd7488  movaps [r15+0x110], xmm9
000070d6f3dd7490  vmovaps xmm14, [rsp+0x10]
000070d6f3dd7496  vpermilpd xmm14, xmm14, 0x00
000070d6f3dd749c  movaps xmm13, xmm11
000070d6f3dd74a0  vfmadd231pd xmm13, xmm15, xmm14
000070d6f3dd74a5  vcmppd xmm8, xmm13, xmm13, 0x03
000070d6f3dd74ab  vptest xmm8, xmm8
000070d6f3dd74b0  jnz 0x000070D6F3DD9EB5
000070d6f3dd74b6  movaps [r15+0x170], xmm13
000070d6f3dd74be  vmovaps xmm15, [rsp+0x10]
000070d6f3dd74c4  vpermilpd xmm15, xmm15, 0x00
000070d6f3dd74ca  movaps xmm14, xmm12
000070d6f3dd74ce  vfmadd231pd xmm14, xmm1, xmm15
000070d6f3dd74d3  vcmppd xmm11, xmm14, xmm14, 0x03
000070d6f3dd74d9  vptest xmm11, xmm11
000070d6f3dd74de  jnz 0x000070D6F3DDA00F
000070d6f3dd74e4  movaps [r15+0x230], xmm14
000070d6f3dd74ec  mov rax, [rsp+0xE0]
000070d6f3dd74f4  movups [r13+rax*1], xmm9
000070d6f3dd74fa  lea r14, [rax+0x10]
000070d6f3dd74fe  movups [r13+r14*1], xmm13
000070d6f3dd7504  lea r14, [rax+0x20]
000070d6f3dd7508  movups [r13+r14*1], xmm10
000070d6f3dd750e  lea r14, [rax+0x30]
000070d6f3dd7512  movups [r13+r14*1], xmm14
000070d6f3dd7518  mov eax, [r15+0x108]
000070d6f3dd751f  sahf
000070d6f3dd7520  jnz 0x000070D6F3DD7552
000070d6f3dd7522  cmp dword ptr [r15+0x318], 0x00
000070d6f3dd752a  jz 0x000070D6F3DD67A0
000070d6f3dd7530  nop [rax+rax*1], ax
000070d6f3dd7539  nop [rax+rax*1], eax
000070d6f3dd7541  mov eax, 0x4103F0
000070d6f3dd7546  mov [r15+0x100], rax
000070d6f3dd754d  jmp 0x000070D6F3BFE110
000070d6f3dd7552  cmp dword ptr [r15+0x318], 0x00
000070d6f3dd755a  jz 0x000070D6F3DD2E40
000070d6f3dd7560  nop [rax+rax*1], ax
000070d6f3dd7569  nop [rax+rax*1], eax
000070d6f3dd7571  mov eax, 0x410274
000070d6f3dd7576  mov [r15+0x100], rax
000070d6f3dd757d  jmp 0x000070D6F3BFE110
000070d6f3dd7582  int3
000070d6f3dd7583  call 0x000070D6F3CE27E0
000070d6f3dd7588  jmp 0x000070D6F3DD6860
000070d6f3dd758d  call 0x000070D6F3CE1570
000070d6f3dd7592  jmp 0x000070D6F3DD6869
000070d6f3dd7597  call 0x000070D6F3CE27E0
000070d6f3dd759c  jmp 0x000070D6F3DD68B2
000070d6f3dd75a1  call 0x000070D6F3CE1570
000070d6f3dd75a6  jmp 0x000070D6F3DD68BB
000070d6f3dd75ab  call 0x000070D6F3CE27E0
000070d6f3dd75b0  jmp 0x000070D6F3DD6953
000070d6f3dd75b5  call 0x000070D6F3CE1570
000070d6f3dd75ba  jmp 0x000070D6F3DD695C
000070d6f3dd75bf  call 0x000070D6F3C0DC20
000070d6f3dd75c4  jmp 0x000070D6F3DD6A47
000070d6f3dd75c9  call 0x000070D6F3CD64F0
000070d6f3dd75ce  jmp 0x000070D6F3DD6A76
000070d6f3dd75d3  call 0x000070D6F3CB47C0
000070d6f3dd75d8  jmp 0x000070D6F3DD6A91
000070d6f3dd75dd  sub rsp, 0x08
000070d6f3dd75e1  push rax
000070d6f3dd75e2  push rcx
000070d6f3dd75e3  push rdx
000070d6f3dd75e4  push rdi
000070d6f3dd75e5  push rsi
000070d6f3dd75e6  push r8
000070d6f3dd75e8  push r9
000070d6f3dd75ea  push r10
000070d6f3dd75ec  push r11
000070d6f3dd75ee  sub rsp, 0xF0
000070d6f3dd75f5  vmovaps [rsp], xmm0
000070d6f3dd75fa  vmovaps [rsp+0x10], xmm1
000070d6f3dd7600  vmovaps [rsp+0x20], xmm2
000070d6f3dd7606  vmovaps [rsp+0x30], xmm3
000070d6f3dd760c  vmovaps [rsp+0x40], xmm4
000070d6f3dd7612  vmovaps [rsp+0x50], xmm5
000070d6f3dd7618  vmovaps [rsp+0x60], xmm6
000070d6f3dd761e  vmovaps [rsp+0x70], xmm7
000070d6f3dd7624  vmovaps [rsp+0x80], xmm8
000070d6f3dd762d  vmovaps [rsp+0x90], xmm9
000070d6f3dd7636  vmovaps [rsp+0xA0], xmm10
000070d6f3dd763f  vmovaps [rsp+0xB0], xmm11
000070d6f3dd7648  vmovaps [rsp+0xC0], xmm12
000070d6f3dd7651  vmovaps [rsp+0xD0], xmm14
000070d6f3dd765a  vmovaps [rsp+0xE0], xmm15
000070d6f3dd7663  sub rsp, 0x40
000070d6f3dd7667  lea rdi, [rsp]
000070d6f3dd766b  lea rsi, [rsp+0x10]
000070d6f3dd7670  lea rdx, [rsp+0x20]
000070d6f3dd7675  lea rcx, [rsp+0x30]
000070d6f3dd767a  mov r8d, 0x00
000070d6f3dd7680  lea r9, [r15+0x3A8]
000070d6f3dd7687  movaps [rdi], xmm13
000070d6f3dd768b  movaps [rsi], xmm1
000070d6f3dd768e  movaps [rdx], xmm15
000070d6f3dd7692  movaps [rcx], xmm14
000070d6f3dd7696  mov rax, 0x61D08D40EA50
000070d6f3dd76a0  call rax
000070d6f3dd76a2  movaps xmm13, [rsp]
000070d6f3dd76a7  add rsp, 0x40
000070d6f3dd76ab  vmovaps xmm0, [rsp]
000070d6f3dd76b0  vmovaps xmm1, [rsp+0x10]
000070d6f3dd76b6  vmovaps xmm2, [rsp+0x20]
000070d6f3dd76bc  vmovaps xmm3, [rsp+0x30]
000070d6f3dd76c2  vmovaps xmm4, [rsp+0x40]
000070d6f3dd76c8  vmovaps xmm5, [rsp+0x50]
000070d6f3dd76ce  vmovaps xmm6, [rsp+0x60]
000070d6f3dd76d4  vmovaps xmm7, [rsp+0x70]
000070d6f3dd76da  vmovaps xmm8, [rsp+0x80]
000070d6f3dd76e3  vmovaps xmm9, [rsp+0x90]
000070d6f3dd76ec  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd76f5  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd76fe  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd7707  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd7710  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd7719  add rsp, 0xF0
000070d6f3dd7720  pop r11
000070d6f3dd7722  pop r10
000070d6f3dd7724  pop r9
000070d6f3dd7726  pop r8
000070d6f3dd7728  pop rsi
000070d6f3dd7729  pop rdi
000070d6f3dd772a  pop rdx
000070d6f3dd772b  pop rcx
000070d6f3dd772c  pop rax
000070d6f3dd772d  add rsp, 0x08
000070d6f3dd7731  jmp 0x000070D6F3DD6B04
000070d6f3dd7736  sub rsp, 0x08
000070d6f3dd773a  push rax
000070d6f3dd773b  push rcx
000070d6f3dd773c  push rdx
000070d6f3dd773d  push rdi
000070d6f3dd773e  push rsi
000070d6f3dd773f  push r8
000070d6f3dd7741  push r9
000070d6f3dd7743  push r10
000070d6f3dd7745  push r11
000070d6f3dd7747  sub rsp, 0xF0
000070d6f3dd774e  vmovaps [rsp], xmm0
000070d6f3dd7753  vmovaps [rsp+0x10], xmm1
000070d6f3dd7759  vmovaps [rsp+0x20], xmm2
000070d6f3dd775f  vmovaps [rsp+0x30], xmm3
000070d6f3dd7765  vmovaps [rsp+0x40], xmm4
000070d6f3dd776b  vmovaps [rsp+0x50], xmm5
000070d6f3dd7771  vmovaps [rsp+0x60], xmm6
000070d6f3dd7777  vmovaps [rsp+0x70], xmm7
000070d6f3dd777d  vmovaps [rsp+0x80], xmm8
000070d6f3dd7786  vmovaps [rsp+0x90], xmm9
000070d6f3dd778f  vmovaps [rsp+0xA0], xmm10
000070d6f3dd7798  vmovaps [rsp+0xB0], xmm11
000070d6f3dd77a1  vmovaps [rsp+0xC0], xmm13
000070d6f3dd77aa  vmovaps [rsp+0xD0], xmm14
000070d6f3dd77b3  vmovaps [rsp+0xE0], xmm15
000070d6f3dd77bc  sub rsp, 0x40
000070d6f3dd77c0  lea rdi, [rsp]
000070d6f3dd77c4  lea rsi, [rsp+0x10]
000070d6f3dd77c9  lea rdx, [rsp+0x20]
000070d6f3dd77ce  lea rcx, [rsp+0x30]
000070d6f3dd77d3  mov r8d, 0x00
000070d6f3dd77d9  lea r9, [r15+0x3A8]
000070d6f3dd77e0  movaps [rdi], xmm12
000070d6f3dd77e4  movaps [rsi], xmm15
000070d6f3dd77e8  movaps [rdx], xmm1
000070d6f3dd77eb  movaps [rcx], xmm14
000070d6f3dd77ef  mov rax, 0x61D08D40EA50
000070d6f3dd77f9  call rax
000070d6f3dd77fb  movaps xmm12, [rsp]
000070d6f3dd7800  add rsp, 0x40
000070d6f3dd7804  vmovaps xmm0, [rsp]
000070d6f3dd7809  vmovaps xmm1, [rsp+0x10]
000070d6f3dd780f  vmovaps xmm2, [rsp+0x20]
000070d6f3dd7815  vmovaps xmm3, [rsp+0x30]
000070d6f3dd781b  vmovaps xmm4, [rsp+0x40]
000070d6f3dd7821  vmovaps xmm5, [rsp+0x50]
000070d6f3dd7827  vmovaps xmm6, [rsp+0x60]
000070d6f3dd782d  vmovaps xmm7, [rsp+0x70]
000070d6f3dd7833  vmovaps xmm8, [rsp+0x80]
000070d6f3dd783c  vmovaps xmm9, [rsp+0x90]
000070d6f3dd7845  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd784e  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd7857  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd7860  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd7869  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd7872  add rsp, 0xF0
000070d6f3dd7879  pop r11
000070d6f3dd787b  pop r10
000070d6f3dd787d  pop r9
000070d6f3dd787f  pop r8
000070d6f3dd7881  pop rsi
000070d6f3dd7882  pop rdi
000070d6f3dd7883  pop rdx
000070d6f3dd7884  pop rcx
000070d6f3dd7885  pop rax
000070d6f3dd7886  add rsp, 0x08
000070d6f3dd788a  jmp 0x000070D6F3DD6B32
000070d6f3dd788f  call 0x000070D6F3CB52F0
000070d6f3dd7894  jmp 0x000070D6F3DD6C1E
000070d6f3dd7899  sub rsp, 0x08
000070d6f3dd789d  push rax
000070d6f3dd789e  push rcx
000070d6f3dd789f  push rdx
000070d6f3dd78a0  push rdi
000070d6f3dd78a1  push rsi
000070d6f3dd78a2  push r8
000070d6f3dd78a4  push r9
000070d6f3dd78a6  push r10
000070d6f3dd78a8  push r11
000070d6f3dd78aa  sub rsp, 0xF0
000070d6f3dd78b1  vmovaps [rsp], xmm0
000070d6f3dd78b6  vmovaps [rsp+0x10], xmm1
000070d6f3dd78bc  vmovaps [rsp+0x20], xmm2
000070d6f3dd78c2  vmovaps [rsp+0x30], xmm3
000070d6f3dd78c8  vmovaps [rsp+0x40], xmm4
000070d6f3dd78ce  vmovaps [rsp+0x50], xmm5
000070d6f3dd78d4  vmovaps [rsp+0x60], xmm6
000070d6f3dd78da  vmovaps [rsp+0x70], xmm7
000070d6f3dd78e0  vmovaps [rsp+0x80], xmm8
000070d6f3dd78e9  vmovaps [rsp+0x90], xmm9
000070d6f3dd78f2  vmovaps [rsp+0xA0], xmm10
000070d6f3dd78fb  vmovaps [rsp+0xB0], xmm11
000070d6f3dd7904  vmovaps [rsp+0xC0], xmm12
000070d6f3dd790d  vmovaps [rsp+0xD0], xmm14
000070d6f3dd7916  vmovaps [rsp+0xE0], xmm15
000070d6f3dd791f  sub rsp, 0x40
000070d6f3dd7923  lea rdi, [rsp]
000070d6f3dd7927  lea rsi, [rsp+0x10]
000070d6f3dd792c  lea rdx, [rsp+0x20]
000070d6f3dd7931  lea rcx, [rsp+0x30]
000070d6f3dd7936  mov r8d, 0x00
000070d6f3dd793c  lea r9, [r15+0x3A8]
000070d6f3dd7943  movaps [rdi], xmm13
000070d6f3dd7947  movaps [rsi], xmm1
000070d6f3dd794a  movaps [rdx], xmm15
000070d6f3dd794e  movaps [rcx], xmm14
000070d6f3dd7952  mov rax, 0x61D08D40EA50
000070d6f3dd795c  call rax
000070d6f3dd795e  movaps xmm13, [rsp]
000070d6f3dd7963  add rsp, 0x40
000070d6f3dd7967  vmovaps xmm0, [rsp]
000070d6f3dd796c  vmovaps xmm1, [rsp+0x10]
000070d6f3dd7972  vmovaps xmm2, [rsp+0x20]
000070d6f3dd7978  vmovaps xmm3, [rsp+0x30]
000070d6f3dd797e  vmovaps xmm4, [rsp+0x40]
000070d6f3dd7984  vmovaps xmm5, [rsp+0x50]
000070d6f3dd798a  vmovaps xmm6, [rsp+0x60]
000070d6f3dd7990  vmovaps xmm7, [rsp+0x70]
000070d6f3dd7996  vmovaps xmm8, [rsp+0x80]
000070d6f3dd799f  vmovaps xmm9, [rsp+0x90]
000070d6f3dd79a8  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd79b1  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd79ba  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd79c3  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd79cc  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd79d5  add rsp, 0xF0
000070d6f3dd79dc  pop r11
000070d6f3dd79de  pop r10
000070d6f3dd79e0  pop r9
000070d6f3dd79e2  pop r8
000070d6f3dd79e4  pop rsi
000070d6f3dd79e5  pop rdi
000070d6f3dd79e6  pop rdx
000070d6f3dd79e7  pop rcx
000070d6f3dd79e8  pop rax
000070d6f3dd79e9  add rsp, 0x08
000070d6f3dd79ed  jmp 0x000070D6F3DD6C93
000070d6f3dd79f2  call 0x000070D6F3BFF430
000070d6f3dd79f7  jmp 0x000070D6F3DD6CA0
000070d6f3dd79fc  sub rsp, 0x08
000070d6f3dd7a00  push rax
000070d6f3dd7a01  push rcx
000070d6f3dd7a02  push rdx
000070d6f3dd7a03  push rdi
000070d6f3dd7a04  push rsi
000070d6f3dd7a05  push r8
000070d6f3dd7a07  push r9
000070d6f3dd7a09  push r10
000070d6f3dd7a0b  push r11
000070d6f3dd7a0d  sub rsp, 0xF0
000070d6f3dd7a14  vmovaps [rsp], xmm0
000070d6f3dd7a19  vmovaps [rsp+0x10], xmm1
000070d6f3dd7a1f  vmovaps [rsp+0x20], xmm2
000070d6f3dd7a25  vmovaps [rsp+0x30], xmm3
000070d6f3dd7a2b  vmovaps [rsp+0x40], xmm4
000070d6f3dd7a31  vmovaps [rsp+0x50], xmm5
000070d6f3dd7a37  vmovaps [rsp+0x60], xmm6
000070d6f3dd7a3d  vmovaps [rsp+0x70], xmm7
000070d6f3dd7a43  vmovaps [rsp+0x80], xmm8
000070d6f3dd7a4c  vmovaps [rsp+0x90], xmm9
000070d6f3dd7a55  vmovaps [rsp+0xA0], xmm10
000070d6f3dd7a5e  vmovaps [rsp+0xB0], xmm11
000070d6f3dd7a67  vmovaps [rsp+0xC0], xmm13
000070d6f3dd7a70  vmovaps [rsp+0xD0], xmm14
000070d6f3dd7a79  vmovaps [rsp+0xE0], xmm15
000070d6f3dd7a82  sub rsp, 0x40
000070d6f3dd7a86  lea rdi, [rsp]
000070d6f3dd7a8a  lea rsi, [rsp+0x10]
000070d6f3dd7a8f  lea rdx, [rsp+0x20]
000070d6f3dd7a94  lea rcx, [rsp+0x30]
000070d6f3dd7a99  mov r8d, 0x00
000070d6f3dd7a9f  lea r9, [r15+0x3A8]
000070d6f3dd7aa6  movaps [rdi], xmm12
000070d6f3dd7aaa  movaps [rsi], xmm15
000070d6f3dd7aae  movaps [rdx], xmm1
000070d6f3dd7ab1  movaps [rcx], xmm14
000070d6f3dd7ab5  mov rax, 0x61D08D40EA50
000070d6f3dd7abf  call rax
000070d6f3dd7ac1  movaps xmm12, [rsp]
000070d6f3dd7ac6  add rsp, 0x40
000070d6f3dd7aca  vmovaps xmm0, [rsp]
000070d6f3dd7acf  vmovaps xmm1, [rsp+0x10]
000070d6f3dd7ad5  vmovaps xmm2, [rsp+0x20]
000070d6f3dd7adb  vmovaps xmm3, [rsp+0x30]
000070d6f3dd7ae1  vmovaps xmm4, [rsp+0x40]
000070d6f3dd7ae7  vmovaps xmm5, [rsp+0x50]
000070d6f3dd7aed  vmovaps xmm6, [rsp+0x60]
000070d6f3dd7af3  vmovaps xmm7, [rsp+0x70]
000070d6f3dd7af9  vmovaps xmm8, [rsp+0x80]
000070d6f3dd7b02  vmovaps xmm9, [rsp+0x90]
000070d6f3dd7b0b  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd7b14  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd7b1d  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd7b26  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd7b2f  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd7b38  add rsp, 0xF0
000070d6f3dd7b3f  pop r11
000070d6f3dd7b41  pop r10
000070d6f3dd7b43  pop r9
000070d6f3dd7b45  pop r8
000070d6f3dd7b47  pop rsi
000070d6f3dd7b48  pop rdi
000070d6f3dd7b49  pop rdx
000070d6f3dd7b4a  pop rcx
000070d6f3dd7b4b  pop rax
000070d6f3dd7b4c  add rsp, 0x08
000070d6f3dd7b50  jmp 0x000070D6F3DD6CCC
000070d6f3dd7b55  sub rsp, 0x08
000070d6f3dd7b59  push rax
000070d6f3dd7b5a  push rcx
000070d6f3dd7b5b  push rdx
000070d6f3dd7b5c  push rdi
000070d6f3dd7b5d  push rsi
000070d6f3dd7b5e  push r8
000070d6f3dd7b60  push r9
000070d6f3dd7b62  push r10
000070d6f3dd7b64  push r11
000070d6f3dd7b66  sub rsp, 0xF0
000070d6f3dd7b6d  vmovaps [rsp], xmm0
000070d6f3dd7b72  vmovaps [rsp+0x10], xmm1
000070d6f3dd7b78  vmovaps [rsp+0x20], xmm2
000070d6f3dd7b7e  vmovaps [rsp+0x30], xmm3
000070d6f3dd7b84  vmovaps [rsp+0x40], xmm4
000070d6f3dd7b8a  vmovaps [rsp+0x50], xmm5
000070d6f3dd7b90  vmovaps [rsp+0x60], xmm6
000070d6f3dd7b96  vmovaps [rsp+0x70], xmm7
000070d6f3dd7b9c  vmovaps [rsp+0x80], xmm8
000070d6f3dd7ba5  vmovaps [rsp+0x90], xmm9
000070d6f3dd7bae  vmovaps [rsp+0xA0], xmm10
000070d6f3dd7bb7  vmovaps [rsp+0xB0], xmm11
000070d6f3dd7bc0  vmovaps [rsp+0xC0], xmm12
000070d6f3dd7bc9  vmovaps [rsp+0xD0], xmm14
000070d6f3dd7bd2  vmovaps [rsp+0xE0], xmm15
000070d6f3dd7bdb  sub rsp, 0x40
000070d6f3dd7bdf  lea rdi, [rsp]
000070d6f3dd7be3  lea rsi, [rsp+0x10]
000070d6f3dd7be8  lea rdx, [rsp+0x20]
000070d6f3dd7bed  lea rcx, [rsp+0x30]
000070d6f3dd7bf2  mov r8d, 0x00
000070d6f3dd7bf8  lea r9, [r15+0x3A8]
000070d6f3dd7bff  movaps [rdi], xmm13
000070d6f3dd7c03  movaps [rsi], xmm1
000070d6f3dd7c06  movaps [rdx], xmm15
000070d6f3dd7c0a  movaps [rcx], xmm14
000070d6f3dd7c0e  mov rax, 0x61D08D40EA50
000070d6f3dd7c18  call rax
000070d6f3dd7c1a  movaps xmm13, [rsp]
000070d6f3dd7c1f  add rsp, 0x40
000070d6f3dd7c23  vmovaps xmm0, [rsp]
000070d6f3dd7c28  vmovaps xmm1, [rsp+0x10]
000070d6f3dd7c2e  vmovaps xmm2, [rsp+0x20]
000070d6f3dd7c34  vmovaps xmm3, [rsp+0x30]
000070d6f3dd7c3a  vmovaps xmm4, [rsp+0x40]
000070d6f3dd7c40  vmovaps xmm5, [rsp+0x50]
000070d6f3dd7c46  vmovaps xmm6, [rsp+0x60]
000070d6f3dd7c4c  vmovaps xmm7, [rsp+0x70]
000070d6f3dd7c52  vmovaps xmm8, [rsp+0x80]
000070d6f3dd7c5b  vmovaps xmm9, [rsp+0x90]
000070d6f3dd7c64  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd7c6d  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd7c76  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd7c7f  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd7c88  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd7c91  add rsp, 0xF0
000070d6f3dd7c98  pop r11
000070d6f3dd7c9a  pop r10
000070d6f3dd7c9c  pop r9
000070d6f3dd7c9e  pop r8
000070d6f3dd7ca0  pop rsi
000070d6f3dd7ca1  pop rdi
000070d6f3dd7ca2  pop rdx
000070d6f3dd7ca3  pop rcx
000070d6f3dd7ca4  pop rax
000070d6f3dd7ca5  add rsp, 0x08
000070d6f3dd7ca9  jmp 0x000070D6F3DD6E6D
000070d6f3dd7cae  sub rsp, 0x08
000070d6f3dd7cb2  push rax
000070d6f3dd7cb3  push rcx
000070d6f3dd7cb4  push rdx
000070d6f3dd7cb5  push rdi
000070d6f3dd7cb6  push rsi
000070d6f3dd7cb7  push r8
000070d6f3dd7cb9  push r9
000070d6f3dd7cbb  push r10
000070d6f3dd7cbd  push r11
000070d6f3dd7cbf  sub rsp, 0xF0
000070d6f3dd7cc6  vmovaps [rsp], xmm0
000070d6f3dd7ccb  vmovaps [rsp+0x10], xmm1
000070d6f3dd7cd1  vmovaps [rsp+0x20], xmm2
000070d6f3dd7cd7  vmovaps [rsp+0x30], xmm3
000070d6f3dd7cdd  vmovaps [rsp+0x40], xmm4
000070d6f3dd7ce3  vmovaps [rsp+0x50], xmm5
000070d6f3dd7ce9  vmovaps [rsp+0x60], xmm6
000070d6f3dd7cef  vmovaps [rsp+0x70], xmm7
000070d6f3dd7cf5  vmovaps [rsp+0x80], xmm8
000070d6f3dd7cfe  vmovaps [rsp+0x90], xmm9
000070d6f3dd7d07  vmovaps [rsp+0xA0], xmm10
000070d6f3dd7d10  vmovaps [rsp+0xB0], xmm11
000070d6f3dd7d19  vmovaps [rsp+0xC0], xmm13
000070d6f3dd7d22  vmovaps [rsp+0xD0], xmm14
000070d6f3dd7d2b  vmovaps [rsp+0xE0], xmm15
000070d6f3dd7d34  sub rsp, 0x40
000070d6f3dd7d38  lea rdi, [rsp]
000070d6f3dd7d3c  lea rsi, [rsp+0x10]
000070d6f3dd7d41  lea rdx, [rsp+0x20]
000070d6f3dd7d46  lea rcx, [rsp+0x30]
000070d6f3dd7d4b  mov r8d, 0x00
000070d6f3dd7d51  lea r9, [r15+0x3A8]
000070d6f3dd7d58  movaps [rdi], xmm12
000070d6f3dd7d5c  movaps [rsi], xmm15
000070d6f3dd7d60  movaps [rdx], xmm14
000070d6f3dd7d64  movaps [rcx], xmm1
000070d6f3dd7d67  mov rax, 0x61D08D40EA50
000070d6f3dd7d71  call rax
000070d6f3dd7d73  movaps xmm12, [rsp]
000070d6f3dd7d78  add rsp, 0x40
000070d6f3dd7d7c  vmovaps xmm0, [rsp]
000070d6f3dd7d81  vmovaps xmm1, [rsp+0x10]
000070d6f3dd7d87  vmovaps xmm2, [rsp+0x20]
000070d6f3dd7d8d  vmovaps xmm3, [rsp+0x30]
000070d6f3dd7d93  vmovaps xmm4, [rsp+0x40]
000070d6f3dd7d99  vmovaps xmm5, [rsp+0x50]
000070d6f3dd7d9f  vmovaps xmm6, [rsp+0x60]
000070d6f3dd7da5  vmovaps xmm7, [rsp+0x70]
000070d6f3dd7dab  vmovaps xmm8, [rsp+0x80]
000070d6f3dd7db4  vmovaps xmm9, [rsp+0x90]
000070d6f3dd7dbd  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd7dc6  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd7dcf  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd7dd8  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd7de1  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd7dea  add rsp, 0xF0
000070d6f3dd7df1  pop r11
000070d6f3dd7df3  pop r10
000070d6f3dd7df5  pop r9
000070d6f3dd7df7  pop r8
000070d6f3dd7df9  pop rsi
000070d6f3dd7dfa  pop rdi
000070d6f3dd7dfb  pop rdx
000070d6f3dd7dfc  pop rcx
000070d6f3dd7dfd  pop rax
000070d6f3dd7dfe  add rsp, 0x08
000070d6f3dd7e02  jmp 0x000070D6F3DD6EAB
000070d6f3dd7e07  sub rsp, 0x08
000070d6f3dd7e0b  push rax
000070d6f3dd7e0c  push rcx
000070d6f3dd7e0d  push rdx
000070d6f3dd7e0e  push rdi
000070d6f3dd7e0f  push rsi
000070d6f3dd7e10  push r8
000070d6f3dd7e12  push r9
000070d6f3dd7e14  push r10
000070d6f3dd7e16  push r11
000070d6f3dd7e18  sub rsp, 0xF0
000070d6f3dd7e1f  vmovaps [rsp], xmm0
000070d6f3dd7e24  vmovaps [rsp+0x10], xmm1
000070d6f3dd7e2a  vmovaps [rsp+0x20], xmm2
000070d6f3dd7e30  vmovaps [rsp+0x30], xmm3
000070d6f3dd7e36  vmovaps [rsp+0x40], xmm4
000070d6f3dd7e3c  vmovaps [rsp+0x50], xmm5
000070d6f3dd7e42  vmovaps [rsp+0x60], xmm6
000070d6f3dd7e48  vmovaps [rsp+0x70], xmm7
000070d6f3dd7e4e  vmovaps [rsp+0x80], xmm8
000070d6f3dd7e57  vmovaps [rsp+0x90], xmm9
000070d6f3dd7e60  vmovaps [rsp+0xA0], xmm10
000070d6f3dd7e69  vmovaps [rsp+0xB0], xmm11
000070d6f3dd7e72  vmovaps [rsp+0xC0], xmm12
000070d6f3dd7e7b  vmovaps [rsp+0xD0], xmm14
000070d6f3dd7e84  vmovaps [rsp+0xE0], xmm15
000070d6f3dd7e8d  sub rsp, 0x40
000070d6f3dd7e91  lea rdi, [rsp]
000070d6f3dd7e95  lea rsi, [rsp+0x10]
000070d6f3dd7e9a  lea rdx, [rsp+0x20]
000070d6f3dd7e9f  lea rcx, [rsp+0x30]
000070d6f3dd7ea4  mov r8d, 0x00
000070d6f3dd7eaa  lea r9, [r15+0x3A8]
000070d6f3dd7eb1  movaps [rdi], xmm13
000070d6f3dd7eb5  movaps [rsi], xmm15
000070d6f3dd7eb9  movaps [rdx], xmm14
000070d6f3dd7ebd  movaps [rcx], xmm1
000070d6f3dd7ec0  mov rax, 0x61D08D40EA50
000070d6f3dd7eca  call rax
000070d6f3dd7ecc  movaps xmm13, [rsp]
000070d6f3dd7ed1  add rsp, 0x40
000070d6f3dd7ed5  vmovaps xmm0, [rsp]
000070d6f3dd7eda  vmovaps xmm1, [rsp+0x10]
000070d6f3dd7ee0  vmovaps xmm2, [rsp+0x20]
000070d6f3dd7ee6  vmovaps xmm3, [rsp+0x30]
000070d6f3dd7eec  vmovaps xmm4, [rsp+0x40]
000070d6f3dd7ef2  vmovaps xmm5, [rsp+0x50]
000070d6f3dd7ef8  vmovaps xmm6, [rsp+0x60]
000070d6f3dd7efe  vmovaps xmm7, [rsp+0x70]
000070d6f3dd7f04  vmovaps xmm8, [rsp+0x80]
000070d6f3dd7f0d  vmovaps xmm9, [rsp+0x90]
000070d6f3dd7f16  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd7f1f  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd7f28  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd7f31  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd7f3a  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd7f43  add rsp, 0xF0
000070d6f3dd7f4a  pop r11
000070d6f3dd7f4c  pop r10
000070d6f3dd7f4e  pop r9
000070d6f3dd7f50  pop r8
000070d6f3dd7f52  pop rsi
000070d6f3dd7f53  pop rdi
000070d6f3dd7f54  pop rdx
000070d6f3dd7f55  pop rcx
000070d6f3dd7f56  pop rax
000070d6f3dd7f57  add rsp, 0x08
000070d6f3dd7f5b  jmp 0x000070D6F3DD6EE9
000070d6f3dd7f60  sub rsp, 0x08
000070d6f3dd7f64  push rax
000070d6f3dd7f65  push rcx
000070d6f3dd7f66  push rdx
000070d6f3dd7f67  push rdi
000070d6f3dd7f68  push rsi
000070d6f3dd7f69  push r8
000070d6f3dd7f6b  push r9
000070d6f3dd7f6d  push r10
000070d6f3dd7f6f  push r11
000070d6f3dd7f71  sub rsp, 0xF0
000070d6f3dd7f78  vmovaps [rsp], xmm0
000070d6f3dd7f7d  vmovaps [rsp+0x10], xmm1
000070d6f3dd7f83  vmovaps [rsp+0x20], xmm2
000070d6f3dd7f89  vmovaps [rsp+0x30], xmm3
000070d6f3dd7f8f  vmovaps [rsp+0x40], xmm4
000070d6f3dd7f95  vmovaps [rsp+0x50], xmm5
000070d6f3dd7f9b  vmovaps [rsp+0x60], xmm6
000070d6f3dd7fa1  vmovaps [rsp+0x70], xmm7
000070d6f3dd7fa7  vmovaps [rsp+0x80], xmm8
000070d6f3dd7fb0  vmovaps [rsp+0x90], xmm9
000070d6f3dd7fb9  vmovaps [rsp+0xA0], xmm10
000070d6f3dd7fc2  vmovaps [rsp+0xB0], xmm11
000070d6f3dd7fcb  vmovaps [rsp+0xC0], xmm13
000070d6f3dd7fd4  vmovaps [rsp+0xD0], xmm14
000070d6f3dd7fdd  vmovaps [rsp+0xE0], xmm15
000070d6f3dd7fe6  sub rsp, 0x40
000070d6f3dd7fea  lea rdi, [rsp]
000070d6f3dd7fee  lea rsi, [rsp+0x10]
000070d6f3dd7ff3  lea rdx, [rsp+0x20]
000070d6f3dd7ff8  lea rcx, [rsp+0x30]
000070d6f3dd7ffd  mov r8d, 0x00
000070d6f3dd8003  lea r9, [r15+0x3A8]
000070d6f3dd800a  movaps [rdi], xmm12
000070d6f3dd800e  movaps [rsi], xmm14
000070d6f3dd8012  movaps [rdx], xmm2
000070d6f3dd8015  movaps [rcx], xmm15
000070d6f3dd8019  mov rax, 0x61D08D40EA50
000070d6f3dd8023  call rax
000070d6f3dd8025  movaps xmm12, [rsp]
000070d6f3dd802a  add rsp, 0x40
000070d6f3dd802e  vmovaps xmm0, [rsp]
000070d6f3dd8033  vmovaps xmm1, [rsp+0x10]
000070d6f3dd8039  vmovaps xmm2, [rsp+0x20]
000070d6f3dd803f  vmovaps xmm3, [rsp+0x30]
000070d6f3dd8045  vmovaps xmm4, [rsp+0x40]
000070d6f3dd804b  vmovaps xmm5, [rsp+0x50]
000070d6f3dd8051  vmovaps xmm6, [rsp+0x60]
000070d6f3dd8057  vmovaps xmm7, [rsp+0x70]
000070d6f3dd805d  vmovaps xmm8, [rsp+0x80]
000070d6f3dd8066  vmovaps xmm9, [rsp+0x90]
000070d6f3dd806f  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd8078  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd8081  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd808a  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd8093  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd809c  add rsp, 0xF0
000070d6f3dd80a3  pop r11
000070d6f3dd80a5  pop r10
000070d6f3dd80a7  pop r9
000070d6f3dd80a9  pop r8
000070d6f3dd80ab  pop rsi
000070d6f3dd80ac  pop rdi
000070d6f3dd80ad  pop rdx
000070d6f3dd80ae  pop rcx
000070d6f3dd80af  pop rax
000070d6f3dd80b0  add rsp, 0x08
000070d6f3dd80b4  jmp 0x000070D6F3DD6F43
000070d6f3dd80b9  sub rsp, 0x08
000070d6f3dd80bd  push rax
000070d6f3dd80be  push rcx
000070d6f3dd80bf  push rdx
000070d6f3dd80c0  push rdi
000070d6f3dd80c1  push rsi
000070d6f3dd80c2  push r8
000070d6f3dd80c4  push r9
000070d6f3dd80c6  push r10
000070d6f3dd80c8  push r11
000070d6f3dd80ca  sub rsp, 0xF0
000070d6f3dd80d1  vmovaps [rsp], xmm0
000070d6f3dd80d6  vmovaps [rsp+0x10], xmm1
000070d6f3dd80dc  vmovaps [rsp+0x20], xmm3
000070d6f3dd80e2  vmovaps [rsp+0x30], xmm4
000070d6f3dd80e8  vmovaps [rsp+0x40], xmm5
000070d6f3dd80ee  vmovaps [rsp+0x50], xmm6
000070d6f3dd80f4  vmovaps [rsp+0x60], xmm7
000070d6f3dd80fa  vmovaps [rsp+0x70], xmm8
000070d6f3dd8100  vmovaps [rsp+0x80], xmm9
000070d6f3dd8109  vmovaps [rsp+0x90], xmm10
000070d6f3dd8112  vmovaps [rsp+0xA0], xmm11
000070d6f3dd811b  vmovaps [rsp+0xB0], xmm12
000070d6f3dd8124  vmovaps [rsp+0xC0], xmm13
000070d6f3dd812d  vmovaps [rsp+0xD0], xmm14
000070d6f3dd8136  vmovaps [rsp+0xE0], xmm15
000070d6f3dd813f  sub rsp, 0x40
000070d6f3dd8143  lea rdi, [rsp]
000070d6f3dd8147  lea rsi, [rsp+0x10]
000070d6f3dd814c  lea rdx, [rsp+0x20]
000070d6f3dd8151  lea rcx, [rsp+0x30]
000070d6f3dd8156  mov r8d, 0x00
000070d6f3dd815c  lea r9, [r15+0x3A8]
000070d6f3dd8163  movaps [rdi], xmm2
000070d6f3dd8166  movaps [rsi], xmm14
000070d6f3dd816a  movaps [rdx], xmm8
000070d6f3dd816e  movaps [rcx], xmm5
000070d6f3dd8171  mov rax, 0x61D08D40EA50
000070d6f3dd817b  call rax
000070d6f3dd817d  movaps xmm2, [rsp]
000070d6f3dd8181  add rsp, 0x40
000070d6f3dd8185  vmovaps xmm0, [rsp]
000070d6f3dd818a  vmovaps xmm1, [rsp+0x10]
000070d6f3dd8190  vmovaps xmm3, [rsp+0x20]
000070d6f3dd8196  vmovaps xmm4, [rsp+0x30]
000070d6f3dd819c  vmovaps xmm5, [rsp+0x40]
000070d6f3dd81a2  vmovaps xmm6, [rsp+0x50]
000070d6f3dd81a8  vmovaps xmm7, [rsp+0x60]
000070d6f3dd81ae  vmovaps xmm8, [rsp+0x70]
000070d6f3dd81b4  vmovaps xmm9, [rsp+0x80]
000070d6f3dd81bd  vmovaps xmm10, [rsp+0x90]
000070d6f3dd81c6  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd81cf  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd81d8  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd81e1  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd81ea  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd81f3  add rsp, 0xF0
000070d6f3dd81fa  pop r11
000070d6f3dd81fc  pop r10
000070d6f3dd81fe  pop r9
000070d6f3dd8200  pop r8
000070d6f3dd8202  pop rsi
000070d6f3dd8203  pop rdi
000070d6f3dd8204  pop rdx
000070d6f3dd8205  pop rcx
000070d6f3dd8206  pop rax
000070d6f3dd8207  add rsp, 0x08
000070d6f3dd820b  jmp 0x000070D6F3DD6FF7
000070d6f3dd8210  sub rsp, 0x08
000070d6f3dd8214  push rax
000070d6f3dd8215  push rcx
000070d6f3dd8216  push rdx
000070d6f3dd8217  push rdi
000070d6f3dd8218  push rsi
000070d6f3dd8219  push r8
000070d6f3dd821b  push r9
000070d6f3dd821d  push r10
000070d6f3dd821f  push r11
000070d6f3dd8221  sub rsp, 0xF0
000070d6f3dd8228  vmovaps [rsp], xmm0
000070d6f3dd822d  vmovaps [rsp+0x10], xmm1
000070d6f3dd8233  vmovaps [rsp+0x20], xmm2
000070d6f3dd8239  vmovaps [rsp+0x30], xmm3
000070d6f3dd823f  vmovaps [rsp+0x40], xmm4
000070d6f3dd8245  vmovaps [rsp+0x50], xmm6
000070d6f3dd824b  vmovaps [rsp+0x60], xmm7
000070d6f3dd8251  vmovaps [rsp+0x70], xmm8
000070d6f3dd8257  vmovaps [rsp+0x80], xmm9
000070d6f3dd8260  vmovaps [rsp+0x90], xmm10
000070d6f3dd8269  vmovaps [rsp+0xA0], xmm11
000070d6f3dd8272  vmovaps [rsp+0xB0], xmm12
000070d6f3dd827b  vmovaps [rsp+0xC0], xmm13
000070d6f3dd8284  vmovaps [rsp+0xD0], xmm14
000070d6f3dd828d  vmovaps [rsp+0xE0], xmm15
000070d6f3dd8296  sub rsp, 0x40
000070d6f3dd829a  lea rdi, [rsp]
000070d6f3dd829e  lea rsi, [rsp+0x10]
000070d6f3dd82a3  lea rdx, [rsp+0x20]
000070d6f3dd82a8  lea rcx, [rsp+0x30]
000070d6f3dd82ad  mov r8d, 0x00
000070d6f3dd82b3  lea r9, [r15+0x3A8]
000070d6f3dd82ba  movaps [rdi], xmm5
000070d6f3dd82bd  movaps [rsi], xmm14
000070d6f3dd82c1  movaps [rdx], xmm8
000070d6f3dd82c5  movaps [rcx], xmm1
000070d6f3dd82c8  mov rax, 0x61D08D40EA50
000070d6f3dd82d2  call rax
000070d6f3dd82d4  movaps xmm5, [rsp]
000070d6f3dd82d8  add rsp, 0x40
000070d6f3dd82dc  vmovaps xmm0, [rsp]
000070d6f3dd82e1  vmovaps xmm1, [rsp+0x10]
000070d6f3dd82e7  vmovaps xmm2, [rsp+0x20]
000070d6f3dd82ed  vmovaps xmm3, [rsp+0x30]
000070d6f3dd82f3  vmovaps xmm4, [rsp+0x40]
000070d6f3dd82f9  vmovaps xmm6, [rsp+0x50]
000070d6f3dd82ff  vmovaps xmm7, [rsp+0x60]
000070d6f3dd8305  vmovaps xmm8, [rsp+0x70]
000070d6f3dd830b  vmovaps xmm9, [rsp+0x80]
000070d6f3dd8314  vmovaps xmm10, [rsp+0x90]
000070d6f3dd831d  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd8326  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd832f  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd8338  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd8341  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd834a  add rsp, 0xF0
000070d6f3dd8351  pop r11
000070d6f3dd8353  pop r10
000070d6f3dd8355  pop r9
000070d6f3dd8357  pop r8
000070d6f3dd8359  pop rsi
000070d6f3dd835a  pop rdi
000070d6f3dd835b  pop rdx
000070d6f3dd835c  pop rcx
000070d6f3dd835d  pop rax
000070d6f3dd835e  add rsp, 0x08
000070d6f3dd8362  jmp 0x000070D6F3DD7034
000070d6f3dd8367  sub rsp, 0x08
000070d6f3dd836b  push rax
000070d6f3dd836c  push rcx
000070d6f3dd836d  push rdx
000070d6f3dd836e  push rdi
000070d6f3dd836f  push rsi
000070d6f3dd8370  push r8
000070d6f3dd8372  push r9
000070d6f3dd8374  push r10
000070d6f3dd8376  push r11
000070d6f3dd8378  sub rsp, 0xF0
000070d6f3dd837f  vmovaps [rsp], xmm0
000070d6f3dd8384  vmovaps [rsp+0x10], xmm1
000070d6f3dd838a  vmovaps [rsp+0x20], xmm2
000070d6f3dd8390  vmovaps [rsp+0x30], xmm3
000070d6f3dd8396  vmovaps [rsp+0x40], xmm4
000070d6f3dd839c  vmovaps [rsp+0x50], xmm5
000070d6f3dd83a2  vmovaps [rsp+0x60], xmm6
000070d6f3dd83a8  vmovaps [rsp+0x70], xmm7
000070d6f3dd83ae  vmovaps [rsp+0x80], xmm8
000070d6f3dd83b7  vmovaps [rsp+0x90], xmm9
000070d6f3dd83c0  vmovaps [rsp+0xA0], xmm10
000070d6f3dd83c9  vmovaps [rsp+0xB0], xmm11
000070d6f3dd83d2  vmovaps [rsp+0xC0], xmm12
000070d6f3dd83db  vmovaps [rsp+0xD0], xmm13
000070d6f3dd83e4  vmovaps [rsp+0xE0], xmm14
000070d6f3dd83ed  sub rsp, 0x40
000070d6f3dd83f1  lea rdi, [rsp]
000070d6f3dd83f5  lea rsi, [rsp+0x10]
000070d6f3dd83fa  lea rdx, [rsp+0x20]
000070d6f3dd83ff  lea rcx, [rsp+0x30]
000070d6f3dd8404  mov r8d, 0x00
000070d6f3dd840a  lea r9, [r15+0x3A8]
000070d6f3dd8411  movaps [rdi], xmm15
000070d6f3dd8415  movaps [rsi], xmm13
000070d6f3dd8419  movaps [rdx], xmm14
000070d6f3dd841d  movaps [rcx], xmm1
000070d6f3dd8420  mov rax, 0x61D08D40EA50
000070d6f3dd842a  call rax
000070d6f3dd842c  movaps xmm15, [rsp]
000070d6f3dd8431  add rsp, 0x40
000070d6f3dd8435  vmovaps xmm0, [rsp]
000070d6f3dd843a  vmovaps xmm1, [rsp+0x10]
000070d6f3dd8440  vmovaps xmm2, [rsp+0x20]
000070d6f3dd8446  vmovaps xmm3, [rsp+0x30]
000070d6f3dd844c  vmovaps xmm4, [rsp+0x40]
000070d6f3dd8452  vmovaps xmm5, [rsp+0x50]
000070d6f3dd8458  vmovaps xmm6, [rsp+0x60]
000070d6f3dd845e  vmovaps xmm7, [rsp+0x70]
000070d6f3dd8464  vmovaps xmm8, [rsp+0x80]
000070d6f3dd846d  vmovaps xmm9, [rsp+0x90]
000070d6f3dd8476  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd847f  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd8488  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd8491  vmovaps xmm13, [rsp+0xD0]
000070d6f3dd849a  vmovaps xmm14, [rsp+0xE0]
000070d6f3dd84a3  add rsp, 0xF0
000070d6f3dd84aa  pop r11
000070d6f3dd84ac  pop r10
000070d6f3dd84ae  pop r9
000070d6f3dd84b0  pop r8
000070d6f3dd84b2  pop rsi
000070d6f3dd84b3  pop rdi
000070d6f3dd84b4  pop rdx
000070d6f3dd84b5  pop rcx
000070d6f3dd84b6  pop rax
000070d6f3dd84b7  add rsp, 0x08
000070d6f3dd84bb  jmp 0x000070D6F3DD7063
000070d6f3dd84c0  sub rsp, 0x08
000070d6f3dd84c4  push rax
000070d6f3dd84c5  push rcx
000070d6f3dd84c6  push rdx
000070d6f3dd84c7  push rdi
000070d6f3dd84c8  push rsi
000070d6f3dd84c9  push r8
000070d6f3dd84cb  push r9
000070d6f3dd84cd  push r10
000070d6f3dd84cf  push r11
000070d6f3dd84d1  sub rsp, 0xF0
000070d6f3dd84d8  vmovaps [rsp], xmm0
000070d6f3dd84dd  vmovaps [rsp+0x10], xmm1
000070d6f3dd84e3  vmovaps [rsp+0x20], xmm2
000070d6f3dd84e9  vmovaps [rsp+0x30], xmm3
000070d6f3dd84ef  vmovaps [rsp+0x40], xmm4
000070d6f3dd84f5  vmovaps [rsp+0x50], xmm5
000070d6f3dd84fb  vmovaps [rsp+0x60], xmm6
000070d6f3dd8501  vmovaps [rsp+0x70], xmm7
000070d6f3dd8507  vmovaps [rsp+0x80], xmm8
000070d6f3dd8510  vmovaps [rsp+0x90], xmm9
000070d6f3dd8519  vmovaps [rsp+0xA0], xmm10
000070d6f3dd8522  vmovaps [rsp+0xB0], xmm11
000070d6f3dd852b  vmovaps [rsp+0xC0], xmm12
000070d6f3dd8534  vmovaps [rsp+0xD0], xmm14
000070d6f3dd853d  vmovaps [rsp+0xE0], xmm15
000070d6f3dd8546  sub rsp, 0x40
000070d6f3dd854a  lea rdi, [rsp]
000070d6f3dd854e  lea rsi, [rsp+0x10]
000070d6f3dd8553  lea rdx, [rsp+0x20]
000070d6f3dd8558  lea rcx, [rsp+0x30]
000070d6f3dd855d  mov r8d, 0x00
000070d6f3dd8563  lea r9, [r15+0x3A8]
000070d6f3dd856a  movaps [rdi], xmm13
000070d6f3dd856e  movaps [rsi], xmm12
000070d6f3dd8572  movaps [rdx], xmm14
000070d6f3dd8576  movaps [rcx], xmm1
000070d6f3dd8579  mov rax, 0x61D08D40EA50
000070d6f3dd8583  call rax
000070d6f3dd8585  movaps xmm13, [rsp]
000070d6f3dd858a  add rsp, 0x40
000070d6f3dd858e  vmovaps xmm0, [rsp]
000070d6f3dd8593  vmovaps xmm1, [rsp+0x10]
000070d6f3dd8599  vmovaps xmm2, [rsp+0x20]
000070d6f3dd859f  vmovaps xmm3, [rsp+0x30]
000070d6f3dd85a5  vmovaps xmm4, [rsp+0x40]
000070d6f3dd85ab  vmovaps xmm5, [rsp+0x50]
000070d6f3dd85b1  vmovaps xmm6, [rsp+0x60]
000070d6f3dd85b7  vmovaps xmm7, [rsp+0x70]
000070d6f3dd85bd  vmovaps xmm8, [rsp+0x80]
000070d6f3dd85c6  vmovaps xmm9, [rsp+0x90]
000070d6f3dd85cf  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd85d8  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd85e1  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd85ea  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd85f3  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd85fc  add rsp, 0xF0
000070d6f3dd8603  pop r11
000070d6f3dd8605  pop r10
000070d6f3dd8607  pop r9
000070d6f3dd8609  pop r8
000070d6f3dd860b  pop rsi
000070d6f3dd860c  pop rdi
000070d6f3dd860d  pop rdx
000070d6f3dd860e  pop rcx
000070d6f3dd860f  pop rax
000070d6f3dd8610  add rsp, 0x08
000070d6f3dd8614  jmp 0x000070D6F3DD7095
000070d6f3dd8619  sub rsp, 0x08
000070d6f3dd861d  push rax
000070d6f3dd861e  push rcx
000070d6f3dd861f  push rdx
000070d6f3dd8620  push rdi
000070d6f3dd8621  push rsi
000070d6f3dd8622  push r8
000070d6f3dd8624  push r9
000070d6f3dd8626  push r10
000070d6f3dd8628  push r11
000070d6f3dd862a  sub rsp, 0xF0
000070d6f3dd8631  vmovaps [rsp], xmm0
000070d6f3dd8636  vmovaps [rsp+0x10], xmm1
000070d6f3dd863c  vmovaps [rsp+0x20], xmm2
000070d6f3dd8642  vmovaps [rsp+0x30], xmm3
000070d6f3dd8648  vmovaps [rsp+0x40], xmm4
000070d6f3dd864e  vmovaps [rsp+0x50], xmm5
000070d6f3dd8654  vmovaps [rsp+0x60], xmm6
000070d6f3dd865a  vmovaps [rsp+0x70], xmm7
000070d6f3dd8660  vmovaps [rsp+0x80], xmm8
000070d6f3dd8669  vmovaps [rsp+0x90], xmm9
000070d6f3dd8672  vmovaps [rsp+0xA0], xmm10
000070d6f3dd867b  vmovaps [rsp+0xB0], xmm11
000070d6f3dd8684  vmovaps [rsp+0xC0], xmm13
000070d6f3dd868d  vmovaps [rsp+0xD0], xmm14
000070d6f3dd8696  vmovaps [rsp+0xE0], xmm15
000070d6f3dd869f  sub rsp, 0x40
000070d6f3dd86a3  lea rdi, [rsp]
000070d6f3dd86a7  lea rsi, [rsp+0x10]
000070d6f3dd86ac  lea rdx, [rsp+0x20]
000070d6f3dd86b1  lea rcx, [rsp+0x30]
000070d6f3dd86b6  mov r8d, 0x00
000070d6f3dd86bc  lea r9, [r15+0x3A8]
000070d6f3dd86c3  movaps [rdi], xmm12
000070d6f3dd86c7  movaps [rsi], xmm5
000070d6f3dd86ca  movaps [rdx], xmm14
000070d6f3dd86ce  movaps [rcx], xmm4
000070d6f3dd86d1  mov rax, 0x61D08D40EA50
000070d6f3dd86db  call rax
000070d6f3dd86dd  movaps xmm12, [rsp]
000070d6f3dd86e2  add rsp, 0x40
000070d6f3dd86e6  vmovaps xmm0, [rsp]
000070d6f3dd86eb  vmovaps xmm1, [rsp+0x10]
000070d6f3dd86f1  vmovaps xmm2, [rsp+0x20]
000070d6f3dd86f7  vmovaps xmm3, [rsp+0x30]
000070d6f3dd86fd  vmovaps xmm4, [rsp+0x40]
000070d6f3dd8703  vmovaps xmm5, [rsp+0x50]
000070d6f3dd8709  vmovaps xmm6, [rsp+0x60]
000070d6f3dd870f  vmovaps xmm7, [rsp+0x70]
000070d6f3dd8715  vmovaps xmm8, [rsp+0x80]
000070d6f3dd871e  vmovaps xmm9, [rsp+0x90]
000070d6f3dd8727  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd8730  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd8739  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd8742  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd874b  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd8754  add rsp, 0xF0
000070d6f3dd875b  pop r11
000070d6f3dd875d  pop r10
000070d6f3dd875f  pop r9
000070d6f3dd8761  pop r8
000070d6f3dd8763  pop rsi
000070d6f3dd8764  pop rdi
000070d6f3dd8765  pop rdx
000070d6f3dd8766  pop rcx
000070d6f3dd8767  pop rax
000070d6f3dd8768  add rsp, 0x08
000070d6f3dd876c  jmp 0x000070D6F3DD710B
000070d6f3dd8771  sub rsp, 0x08
000070d6f3dd8775  push rax
000070d6f3dd8776  push rcx
000070d6f3dd8777  push rdx
000070d6f3dd8778  push rdi
000070d6f3dd8779  push rsi
000070d6f3dd877a  push r8
000070d6f3dd877c  push r9
000070d6f3dd877e  push r10
000070d6f3dd8780  push r11
000070d6f3dd8782  sub rsp, 0xF0
000070d6f3dd8789  vmovaps [rsp], xmm0
000070d6f3dd878e  vmovaps [rsp+0x10], xmm1
000070d6f3dd8794  vmovaps [rsp+0x20], xmm2
000070d6f3dd879a  vmovaps [rsp+0x30], xmm3
000070d6f3dd87a0  vmovaps [rsp+0x40], xmm4
000070d6f3dd87a6  vmovaps [rsp+0x50], xmm5
000070d6f3dd87ac  vmovaps [rsp+0x60], xmm6
000070d6f3dd87b2  vmovaps [rsp+0x70], xmm7
000070d6f3dd87b8  vmovaps [rsp+0x80], xmm8
000070d6f3dd87c1  vmovaps [rsp+0x90], xmm9
000070d6f3dd87ca  vmovaps [rsp+0xA0], xmm11
000070d6f3dd87d3  vmovaps [rsp+0xB0], xmm12
000070d6f3dd87dc  vmovaps [rsp+0xC0], xmm13
000070d6f3dd87e5  vmovaps [rsp+0xD0], xmm14
000070d6f3dd87ee  vmovaps [rsp+0xE0], xmm15
000070d6f3dd87f7  sub rsp, 0x40
000070d6f3dd87fb  lea rdi, [rsp]
000070d6f3dd87ff  lea rsi, [rsp+0x10]
000070d6f3dd8804  lea rdx, [rsp+0x20]
000070d6f3dd8809  lea rcx, [rsp+0x30]
000070d6f3dd880e  mov r8d, 0x00
000070d6f3dd8814  lea r9, [r15+0x3A8]
000070d6f3dd881b  movaps [rdi], xmm10
000070d6f3dd881f  movaps [rsi], xmm2
000070d6f3dd8822  movaps [rdx], xmm6
000070d6f3dd8825  movaps [rcx], xmm14
000070d6f3dd8829  mov rax, 0x61D08D40EA50
000070d6f3dd8833  call rax
000070d6f3dd8835  movaps xmm10, [rsp]
000070d6f3dd883a  add rsp, 0x40
000070d6f3dd883e  vmovaps xmm0, [rsp]
000070d6f3dd8843  vmovaps xmm1, [rsp+0x10]
000070d6f3dd8849  vmovaps xmm2, [rsp+0x20]
000070d6f3dd884f  vmovaps xmm3, [rsp+0x30]
000070d6f3dd8855  vmovaps xmm4, [rsp+0x40]
000070d6f3dd885b  vmovaps xmm5, [rsp+0x50]
000070d6f3dd8861  vmovaps xmm6, [rsp+0x60]
000070d6f3dd8867  vmovaps xmm7, [rsp+0x70]
000070d6f3dd886d  vmovaps xmm8, [rsp+0x80]
000070d6f3dd8876  vmovaps xmm9, [rsp+0x90]
000070d6f3dd887f  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd8888  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd8891  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd889a  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd88a3  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd88ac  add rsp, 0xF0
000070d6f3dd88b3  pop r11
000070d6f3dd88b5  pop r10
000070d6f3dd88b7  pop r9
000070d6f3dd88b9  pop r8
000070d6f3dd88bb  pop rsi
000070d6f3dd88bc  pop rdi
000070d6f3dd88bd  pop rdx
000070d6f3dd88be  pop rcx
000070d6f3dd88bf  pop rax
000070d6f3dd88c0  add rsp, 0x08
000070d6f3dd88c4  jmp 0x000070D6F3DD7131
000070d6f3dd88c9  call 0x000070D6F3C0D4E0
000070d6f3dd88ce  jmp 0x000070D6F3DD713E
000070d6f3dd88d3  sub rsp, 0x08
000070d6f3dd88d7  push rax
000070d6f3dd88d8  push rcx
000070d6f3dd88d9  push rdx
000070d6f3dd88da  push rdi
000070d6f3dd88db  push rsi
000070d6f3dd88dc  push r8
000070d6f3dd88de  push r9
000070d6f3dd88e0  push r10
000070d6f3dd88e2  push r11
000070d6f3dd88e4  sub rsp, 0xF0
000070d6f3dd88eb  vmovaps [rsp], xmm0
000070d6f3dd88f0  vmovaps [rsp+0x10], xmm1
000070d6f3dd88f6  vmovaps [rsp+0x20], xmm2
000070d6f3dd88fc  vmovaps [rsp+0x30], xmm3
000070d6f3dd8902  vmovaps [rsp+0x40], xmm4
000070d6f3dd8908  vmovaps [rsp+0x50], xmm6
000070d6f3dd890e  vmovaps [rsp+0x60], xmm7
000070d6f3dd8914  vmovaps [rsp+0x70], xmm8
000070d6f3dd891a  vmovaps [rsp+0x80], xmm9
000070d6f3dd8923  vmovaps [rsp+0x90], xmm10
000070d6f3dd892c  vmovaps [rsp+0xA0], xmm11
000070d6f3dd8935  vmovaps [rsp+0xB0], xmm12
000070d6f3dd893e  vmovaps [rsp+0xC0], xmm13
000070d6f3dd8947  vmovaps [rsp+0xD0], xmm14
000070d6f3dd8950  vmovaps [rsp+0xE0], xmm15
000070d6f3dd8959  sub rsp, 0x40
000070d6f3dd895d  lea rdi, [rsp]
000070d6f3dd8961  lea rsi, [rsp+0x10]
000070d6f3dd8966  lea rdx, [rsp+0x20]
000070d6f3dd896b  lea rcx, [rsp+0x30]
000070d6f3dd8970  mov r8d, 0x00
000070d6f3dd8976  lea r9, [r15+0x3A8]
000070d6f3dd897d  movaps [rdi], xmm5
000070d6f3dd8980  movaps [rsi], xmm15
000070d6f3dd8984  movaps [rdx], xmm6
000070d6f3dd8987  movaps [rcx], xmm8
000070d6f3dd898b  mov rax, 0x61D08D40EA50
000070d6f3dd8995  call rax
000070d6f3dd8997  movaps xmm5, [rsp]
000070d6f3dd899b  add rsp, 0x40
000070d6f3dd899f  vmovaps xmm0, [rsp]
000070d6f3dd89a4  vmovaps xmm1, [rsp+0x10]
000070d6f3dd89aa  vmovaps xmm2, [rsp+0x20]
000070d6f3dd89b0  vmovaps xmm3, [rsp+0x30]
000070d6f3dd89b6  vmovaps xmm4, [rsp+0x40]
000070d6f3dd89bc  vmovaps xmm6, [rsp+0x50]
000070d6f3dd89c2  vmovaps xmm7, [rsp+0x60]
000070d6f3dd89c8  vmovaps xmm8, [rsp+0x70]
000070d6f3dd89ce  vmovaps xmm9, [rsp+0x80]
000070d6f3dd89d7  vmovaps xmm10, [rsp+0x90]
000070d6f3dd89e0  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd89e9  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd89f2  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd89fb  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd8a04  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd8a0d  add rsp, 0xF0
000070d6f3dd8a14  pop r11
000070d6f3dd8a16  pop r10
000070d6f3dd8a18  pop r9
000070d6f3dd8a1a  pop r8
000070d6f3dd8a1c  pop rsi
000070d6f3dd8a1d  pop rdi
000070d6f3dd8a1e  pop rdx
000070d6f3dd8a1f  pop rcx
000070d6f3dd8a20  pop rax
000070d6f3dd8a21  add rsp, 0x08
000070d6f3dd8a25  jmp 0x000070D6F3DD7174
000070d6f3dd8a2a  sub rsp, 0x08
000070d6f3dd8a2e  push rax
000070d6f3dd8a2f  push rcx
000070d6f3dd8a30  push rdx
000070d6f3dd8a31  push rdi
000070d6f3dd8a32  push rsi
000070d6f3dd8a33  push r8
000070d6f3dd8a35  push r9
000070d6f3dd8a37  push r10
000070d6f3dd8a39  push r11
000070d6f3dd8a3b  sub rsp, 0xF0
000070d6f3dd8a42  vmovaps [rsp], xmm0
000070d6f3dd8a47  vmovaps [rsp+0x10], xmm1
000070d6f3dd8a4d  vmovaps [rsp+0x20], xmm2
000070d6f3dd8a53  vmovaps [rsp+0x30], xmm3
000070d6f3dd8a59  vmovaps [rsp+0x40], xmm4
000070d6f3dd8a5f  vmovaps [rsp+0x50], xmm5
000070d6f3dd8a65  vmovaps [rsp+0x60], xmm6
000070d6f3dd8a6b  vmovaps [rsp+0x70], xmm7
000070d6f3dd8a71  vmovaps [rsp+0x80], xmm9
000070d6f3dd8a7a  vmovaps [rsp+0x90], xmm10
000070d6f3dd8a83  vmovaps [rsp+0xA0], xmm11
000070d6f3dd8a8c  vmovaps [rsp+0xB0], xmm12
000070d6f3dd8a95  vmovaps [rsp+0xC0], xmm13
000070d6f3dd8a9e  vmovaps [rsp+0xD0], xmm14
000070d6f3dd8aa7  vmovaps [rsp+0xE0], xmm15
000070d6f3dd8ab0  sub rsp, 0x40
000070d6f3dd8ab4  lea rdi, [rsp]
000070d6f3dd8ab8  lea rsi, [rsp+0x10]
000070d6f3dd8abd  lea rdx, [rsp+0x20]
000070d6f3dd8ac2  lea rcx, [rsp+0x30]
000070d6f3dd8ac7  mov r8d, 0x00
000070d6f3dd8acd  lea r9, [r15+0x3A8]
000070d6f3dd8ad4  movaps [rdi], xmm8
000070d6f3dd8ad8  movaps [rsi], xmm13
000070d6f3dd8adc  movaps [rdx], xmm1
000070d6f3dd8adf  movaps [rcx], xmm15
000070d6f3dd8ae3  mov rax, 0x61D08D40EA50
000070d6f3dd8aed  call rax
000070d6f3dd8aef  movaps xmm8, [rsp]
000070d6f3dd8af4  add rsp, 0x40
000070d6f3dd8af8  vmovaps xmm0, [rsp]
000070d6f3dd8afd  vmovaps xmm1, [rsp+0x10]
000070d6f3dd8b03  vmovaps xmm2, [rsp+0x20]
000070d6f3dd8b09  vmovaps xmm3, [rsp+0x30]
000070d6f3dd8b0f  vmovaps xmm4, [rsp+0x40]
000070d6f3dd8b15  vmovaps xmm5, [rsp+0x50]
000070d6f3dd8b1b  vmovaps xmm6, [rsp+0x60]
000070d6f3dd8b21  vmovaps xmm7, [rsp+0x70]
000070d6f3dd8b27  vmovaps xmm9, [rsp+0x80]
000070d6f3dd8b30  vmovaps xmm10, [rsp+0x90]
000070d6f3dd8b39  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd8b42  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd8b4b  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd8b54  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd8b5d  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd8b66  add rsp, 0xF0
000070d6f3dd8b6d  pop r11
000070d6f3dd8b6f  pop r10
000070d6f3dd8b71  pop r9
000070d6f3dd8b73  pop r8
000070d6f3dd8b75  pop rsi
000070d6f3dd8b76  pop rdi
000070d6f3dd8b77  pop rdx
000070d6f3dd8b78  pop rcx
000070d6f3dd8b79  pop rax
000070d6f3dd8b7a  add rsp, 0x08
000070d6f3dd8b7e  jmp 0x000070D6F3DD719A
000070d6f3dd8b83  call 0x000070D6F3C0E760
000070d6f3dd8b88  jmp 0x000070D6F3DD71BD
000070d6f3dd8b8d  call 0x000070D6F3C0C260
000070d6f3dd8b92  jmp 0x000070D6F3DD71C7
000070d6f3dd8b97  sub rsp, 0x08
000070d6f3dd8b9b  push rax
000070d6f3dd8b9c  push rcx
000070d6f3dd8b9d  push rdx
000070d6f3dd8b9e  push rdi
000070d6f3dd8b9f  push rsi
000070d6f3dd8ba0  push r8
000070d6f3dd8ba2  push r9
000070d6f3dd8ba4  push r10
000070d6f3dd8ba6  push r11
000070d6f3dd8ba8  sub rsp, 0xF0
000070d6f3dd8baf  vmovaps [rsp], xmm0
000070d6f3dd8bb4  vmovaps [rsp+0x10], xmm1
000070d6f3dd8bba  vmovaps [rsp+0x20], xmm2
000070d6f3dd8bc0  vmovaps [rsp+0x30], xmm3
000070d6f3dd8bc6  vmovaps [rsp+0x40], xmm5
000070d6f3dd8bcc  vmovaps [rsp+0x50], xmm6
000070d6f3dd8bd2  vmovaps [rsp+0x60], xmm7
000070d6f3dd8bd8  vmovaps [rsp+0x70], xmm8
000070d6f3dd8bde  vmovaps [rsp+0x80], xmm9
000070d6f3dd8be7  vmovaps [rsp+0x90], xmm10
000070d6f3dd8bf0  vmovaps [rsp+0xA0], xmm11
000070d6f3dd8bf9  vmovaps [rsp+0xB0], xmm12
000070d6f3dd8c02  vmovaps [rsp+0xC0], xmm13
000070d6f3dd8c0b  vmovaps [rsp+0xD0], xmm14
000070d6f3dd8c14  vmovaps [rsp+0xE0], xmm15
000070d6f3dd8c1d  sub rsp, 0x40
000070d6f3dd8c21  lea rdi, [rsp]
000070d6f3dd8c25  lea rsi, [rsp+0x10]
000070d6f3dd8c2a  lea rdx, [rsp+0x20]
000070d6f3dd8c2f  lea rcx, [rsp+0x30]
000070d6f3dd8c34  mov r8d, 0x00
000070d6f3dd8c3a  lea r9, [r15+0x3A8]
000070d6f3dd8c41  movaps [rdi], xmm4
000070d6f3dd8c44  movaps [rsi], xmm12
000070d6f3dd8c48  movaps [rdx], xmm9
000070d6f3dd8c4c  movaps [rcx], xmm6
000070d6f3dd8c4f  mov rax, 0x61D08D40EA50
000070d6f3dd8c59  call rax
000070d6f3dd8c5b  movaps xmm4, [rsp]
000070d6f3dd8c5f  add rsp, 0x40
000070d6f3dd8c63  vmovaps xmm0, [rsp]
000070d6f3dd8c68  vmovaps xmm1, [rsp+0x10]
000070d6f3dd8c6e  vmovaps xmm2, [rsp+0x20]
000070d6f3dd8c74  vmovaps xmm3, [rsp+0x30]
000070d6f3dd8c7a  vmovaps xmm5, [rsp+0x40]
000070d6f3dd8c80  vmovaps xmm6, [rsp+0x50]
000070d6f3dd8c86  vmovaps xmm7, [rsp+0x60]
000070d6f3dd8c8c  vmovaps xmm8, [rsp+0x70]
000070d6f3dd8c92  vmovaps xmm9, [rsp+0x80]
000070d6f3dd8c9b  vmovaps xmm10, [rsp+0x90]
000070d6f3dd8ca4  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd8cad  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd8cb6  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd8cbf  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd8cc8  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd8cd1  add rsp, 0xF0
000070d6f3dd8cd8  pop r11
000070d6f3dd8cda  pop r10
000070d6f3dd8cdc  pop r9
000070d6f3dd8cde  pop r8
000070d6f3dd8ce0  pop rsi
000070d6f3dd8ce1  pop rdi
000070d6f3dd8ce2  pop rdx
000070d6f3dd8ce3  pop rcx
000070d6f3dd8ce4  pop rax
000070d6f3dd8ce5  add rsp, 0x08
000070d6f3dd8ce9  jmp 0x000070D6F3DD71FF
000070d6f3dd8cee  sub rsp, 0x08
000070d6f3dd8cf2  push rax
000070d6f3dd8cf3  push rcx
000070d6f3dd8cf4  push rdx
000070d6f3dd8cf5  push rdi
000070d6f3dd8cf6  push rsi
000070d6f3dd8cf7  push r8
000070d6f3dd8cf9  push r9
000070d6f3dd8cfb  push r10
000070d6f3dd8cfd  push r11
000070d6f3dd8cff  sub rsp, 0xF0
000070d6f3dd8d06  vmovaps [rsp], xmm0
000070d6f3dd8d0b  vmovaps [rsp+0x10], xmm1
000070d6f3dd8d11  vmovaps [rsp+0x20], xmm2
000070d6f3dd8d17  vmovaps [rsp+0x30], xmm3
000070d6f3dd8d1d  vmovaps [rsp+0x40], xmm4
000070d6f3dd8d23  vmovaps [rsp+0x50], xmm5
000070d6f3dd8d29  vmovaps [rsp+0x60], xmm6
000070d6f3dd8d2f  vmovaps [rsp+0x70], xmm7
000070d6f3dd8d35  vmovaps [rsp+0x80], xmm8
000070d6f3dd8d3e  vmovaps [rsp+0x90], xmm10
000070d6f3dd8d47  vmovaps [rsp+0xA0], xmm11
000070d6f3dd8d50  vmovaps [rsp+0xB0], xmm12
000070d6f3dd8d59  vmovaps [rsp+0xC0], xmm13
000070d6f3dd8d62  vmovaps [rsp+0xD0], xmm14
000070d6f3dd8d6b  vmovaps [rsp+0xE0], xmm15
000070d6f3dd8d74  sub rsp, 0x40
000070d6f3dd8d78  lea rdi, [rsp]
000070d6f3dd8d7c  lea rsi, [rsp+0x10]
000070d6f3dd8d81  lea rdx, [rsp+0x20]
000070d6f3dd8d86  lea rcx, [rsp+0x30]
000070d6f3dd8d8b  mov r8d, 0x00
000070d6f3dd8d91  lea r9, [r15+0x3A8]
000070d6f3dd8d98  movaps [rdi], xmm9
000070d6f3dd8d9c  movaps [rsi], xmm10
000070d6f3dd8da0  movaps [rdx], xmm1
000070d6f3dd8da3  movaps [rcx], xmm12
000070d6f3dd8da7  mov rax, 0x61D08D40EA50
000070d6f3dd8db1  call rax
000070d6f3dd8db3  movaps xmm9, [rsp]
000070d6f3dd8db8  add rsp, 0x40
000070d6f3dd8dbc  vmovaps xmm0, [rsp]
000070d6f3dd8dc1  vmovaps xmm1, [rsp+0x10]
000070d6f3dd8dc7  vmovaps xmm2, [rsp+0x20]
000070d6f3dd8dcd  vmovaps xmm3, [rsp+0x30]
000070d6f3dd8dd3  vmovaps xmm4, [rsp+0x40]
000070d6f3dd8dd9  vmovaps xmm5, [rsp+0x50]
000070d6f3dd8ddf  vmovaps xmm6, [rsp+0x60]
000070d6f3dd8de5  vmovaps xmm7, [rsp+0x70]
000070d6f3dd8deb  vmovaps xmm8, [rsp+0x80]
000070d6f3dd8df4  vmovaps xmm10, [rsp+0x90]
000070d6f3dd8dfd  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd8e06  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd8e0f  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd8e18  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd8e21  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd8e2a  add rsp, 0xF0
000070d6f3dd8e31  pop r11
000070d6f3dd8e33  pop r10
000070d6f3dd8e35  pop r9
000070d6f3dd8e37  pop r8
000070d6f3dd8e39  pop rsi
000070d6f3dd8e3a  pop rdi
000070d6f3dd8e3b  pop rdx
000070d6f3dd8e3c  pop rcx
000070d6f3dd8e3d  pop rax
000070d6f3dd8e3e  add rsp, 0x08
000070d6f3dd8e42  jmp 0x000070D6F3DD7228
000070d6f3dd8e47  sub rsp, 0x08
000070d6f3dd8e4b  push rax
000070d6f3dd8e4c  push rcx
000070d6f3dd8e4d  push rdx
000070d6f3dd8e4e  push rdi
000070d6f3dd8e4f  push rsi
000070d6f3dd8e50  push r8
000070d6f3dd8e52  push r9
000070d6f3dd8e54  push r10
000070d6f3dd8e56  push r11
000070d6f3dd8e58  sub rsp, 0xF0
000070d6f3dd8e5f  vmovaps [rsp], xmm0
000070d6f3dd8e64  vmovaps [rsp+0x10], xmm1
000070d6f3dd8e6a  vmovaps [rsp+0x20], xmm2
000070d6f3dd8e70  vmovaps [rsp+0x30], xmm3
000070d6f3dd8e76  vmovaps [rsp+0x40], xmm4
000070d6f3dd8e7c  vmovaps [rsp+0x50], xmm5
000070d6f3dd8e82  vmovaps [rsp+0x60], xmm6
000070d6f3dd8e88  vmovaps [rsp+0x70], xmm7
000070d6f3dd8e8e  vmovaps [rsp+0x80], xmm8
000070d6f3dd8e97  vmovaps [rsp+0x90], xmm9
000070d6f3dd8ea0  vmovaps [rsp+0xA0], xmm11
000070d6f3dd8ea9  vmovaps [rsp+0xB0], xmm12
000070d6f3dd8eb2  vmovaps [rsp+0xC0], xmm13
000070d6f3dd8ebb  vmovaps [rsp+0xD0], xmm14
000070d6f3dd8ec4  vmovaps [rsp+0xE0], xmm15
000070d6f3dd8ecd  sub rsp, 0x40
000070d6f3dd8ed1  lea rdi, [rsp]
000070d6f3dd8ed5  lea rsi, [rsp+0x10]
000070d6f3dd8eda  lea rdx, [rsp+0x20]
000070d6f3dd8edf  lea rcx, [rsp+0x30]
000070d6f3dd8ee4  mov r8d, 0x00
000070d6f3dd8eea  lea r9, [r15+0x3A8]
000070d6f3dd8ef1  movaps [rdi], xmm10
000070d6f3dd8ef5  movaps [rsi], xmm5
000070d6f3dd8ef8  movaps [rdx], xmm12
000070d6f3dd8efc  movaps [rcx], xmm1
000070d6f3dd8eff  mov rax, 0x61D08D40EA50
000070d6f3dd8f09  call rax
000070d6f3dd8f0b  movaps xmm10, [rsp]
000070d6f3dd8f10  add rsp, 0x40
000070d6f3dd8f14  vmovaps xmm0, [rsp]
000070d6f3dd8f19  vmovaps xmm1, [rsp+0x10]
000070d6f3dd8f1f  vmovaps xmm2, [rsp+0x20]
000070d6f3dd8f25  vmovaps xmm3, [rsp+0x30]
000070d6f3dd8f2b  vmovaps xmm4, [rsp+0x40]
000070d6f3dd8f31  vmovaps xmm5, [rsp+0x50]
000070d6f3dd8f37  vmovaps xmm6, [rsp+0x60]
000070d6f3dd8f3d  vmovaps xmm7, [rsp+0x70]
000070d6f3dd8f43  vmovaps xmm8, [rsp+0x80]
000070d6f3dd8f4c  vmovaps xmm9, [rsp+0x90]
000070d6f3dd8f55  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd8f5e  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd8f67  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd8f70  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd8f79  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd8f82  add rsp, 0xF0
000070d6f3dd8f89  pop r11
000070d6f3dd8f8b  pop r10
000070d6f3dd8f8d  pop r9
000070d6f3dd8f8f  pop r8
000070d6f3dd8f91  pop rsi
000070d6f3dd8f92  pop rdi
000070d6f3dd8f93  pop rdx
000070d6f3dd8f94  pop rcx
000070d6f3dd8f95  pop rax
000070d6f3dd8f96  add rsp, 0x08
000070d6f3dd8f9a  jmp 0x000070D6F3DD7257
000070d6f3dd8f9f  sub rsp, 0x08
000070d6f3dd8fa3  push rax
000070d6f3dd8fa4  push rcx
000070d6f3dd8fa5  push rdx
000070d6f3dd8fa6  push rdi
000070d6f3dd8fa7  push rsi
000070d6f3dd8fa8  push r8
000070d6f3dd8faa  push r9
000070d6f3dd8fac  push r10
000070d6f3dd8fae  push r11
000070d6f3dd8fb0  sub rsp, 0xF0
000070d6f3dd8fb7  vmovaps [rsp], xmm0
000070d6f3dd8fbc  vmovaps [rsp+0x10], xmm1
000070d6f3dd8fc2  vmovaps [rsp+0x20], xmm2
000070d6f3dd8fc8  vmovaps [rsp+0x30], xmm3
000070d6f3dd8fce  vmovaps [rsp+0x40], xmm4
000070d6f3dd8fd4  vmovaps [rsp+0x50], xmm5
000070d6f3dd8fda  vmovaps [rsp+0x60], xmm7
000070d6f3dd8fe0  vmovaps [rsp+0x70], xmm8
000070d6f3dd8fe6  vmovaps [rsp+0x80], xmm9
000070d6f3dd8fef  vmovaps [rsp+0x90], xmm10
000070d6f3dd8ff8  vmovaps [rsp+0xA0], xmm11
000070d6f3dd9001  vmovaps [rsp+0xB0], xmm12
000070d6f3dd900a  vmovaps [rsp+0xC0], xmm13
000070d6f3dd9013  vmovaps [rsp+0xD0], xmm14
000070d6f3dd901c  vmovaps [rsp+0xE0], xmm15
000070d6f3dd9025  sub rsp, 0x40
000070d6f3dd9029  lea rdi, [rsp]
000070d6f3dd902d  lea rsi, [rsp+0x10]
000070d6f3dd9032  lea rdx, [rsp+0x20]
000070d6f3dd9037  lea rcx, [rsp+0x30]
000070d6f3dd903c  mov r8d, 0x00
000070d6f3dd9042  lea r9, [r15+0x3A8]
000070d6f3dd9049  movaps [rdi], xmm6
000070d6f3dd904c  movaps [rsi], xmm8
000070d6f3dd9050  movaps [rdx], xmm12
000070d6f3dd9054  movaps [rcx], xmm1
000070d6f3dd9057  mov rax, 0x61D08D40EA50
000070d6f3dd9061  call rax
000070d6f3dd9063  movaps xmm6, [rsp]
000070d6f3dd9067  add rsp, 0x40
000070d6f3dd906b  vmovaps xmm0, [rsp]
000070d6f3dd9070  vmovaps xmm1, [rsp+0x10]
000070d6f3dd9076  vmovaps xmm2, [rsp+0x20]
000070d6f3dd907c  vmovaps xmm3, [rsp+0x30]
000070d6f3dd9082  vmovaps xmm4, [rsp+0x40]
000070d6f3dd9088  vmovaps xmm5, [rsp+0x50]
000070d6f3dd908e  vmovaps xmm7, [rsp+0x60]
000070d6f3dd9094  vmovaps xmm8, [rsp+0x70]
000070d6f3dd909a  vmovaps xmm9, [rsp+0x80]
000070d6f3dd90a3  vmovaps xmm10, [rsp+0x90]
000070d6f3dd90ac  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd90b5  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd90be  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd90c7  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd90d0  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd90d9  add rsp, 0xF0
000070d6f3dd90e0  pop r11
000070d6f3dd90e2  pop r10
000070d6f3dd90e4  pop r9
000070d6f3dd90e6  pop r8
000070d6f3dd90e8  pop rsi
000070d6f3dd90e9  pop rdi
000070d6f3dd90ea  pop rdx
000070d6f3dd90eb  pop rcx
000070d6f3dd90ec  pop rax
000070d6f3dd90ed  add rsp, 0x08
000070d6f3dd90f1  jmp 0x000070D6F3DD7285
000070d6f3dd90f6  call 0x000070D6F3BFF430
000070d6f3dd90fb  jmp 0x000070D6F3DD728F
000070d6f3dd9100  call 0x000070D6F3C0AFE0
000070d6f3dd9105  jmp 0x000070D6F3DD7299
000070d6f3dd910a  sub rsp, 0x08
000070d6f3dd910e  push rax
000070d6f3dd910f  push rcx
000070d6f3dd9110  push rdx
000070d6f3dd9111  push rdi
000070d6f3dd9112  push rsi
000070d6f3dd9113  push r8
000070d6f3dd9115  push r9
000070d6f3dd9117  push r10
000070d6f3dd9119  push r11
000070d6f3dd911b  sub rsp, 0xF0
000070d6f3dd9122  vmovaps [rsp], xmm0
000070d6f3dd9127  vmovaps [rsp+0x10], xmm1
000070d6f3dd912d  vmovaps [rsp+0x20], xmm2
000070d6f3dd9133  vmovaps [rsp+0x30], xmm3
000070d6f3dd9139  vmovaps [rsp+0x40], xmm4
000070d6f3dd913f  vmovaps [rsp+0x50], xmm5
000070d6f3dd9145  vmovaps [rsp+0x60], xmm6
000070d6f3dd914b  vmovaps [rsp+0x70], xmm7
000070d6f3dd9151  vmovaps [rsp+0x80], xmm9
000070d6f3dd915a  vmovaps [rsp+0x90], xmm10
000070d6f3dd9163  vmovaps [rsp+0xA0], xmm11
000070d6f3dd916c  vmovaps [rsp+0xB0], xmm12
000070d6f3dd9175  vmovaps [rsp+0xC0], xmm13
000070d6f3dd917e  vmovaps [rsp+0xD0], xmm14
000070d6f3dd9187  vmovaps [rsp+0xE0], xmm15
000070d6f3dd9190  sub rsp, 0x40
000070d6f3dd9194  lea rdi, [rsp]
000070d6f3dd9198  lea rsi, [rsp+0x10]
000070d6f3dd919d  lea rdx, [rsp+0x20]
000070d6f3dd91a2  lea rcx, [rsp+0x30]
000070d6f3dd91a7  mov r8d, 0x00
000070d6f3dd91ad  lea r9, [r15+0x3A8]
000070d6f3dd91b4  movaps [rdi], xmm8
000070d6f3dd91b8  movaps [rsi], xmm4
000070d6f3dd91bb  movaps [rdx], xmm13
000070d6f3dd91bf  movaps [rcx], xmm11
000070d6f3dd91c3  mov rax, 0x61D08D40EA50
000070d6f3dd91cd  call rax
000070d6f3dd91cf  movaps xmm8, [rsp]
000070d6f3dd91d4  add rsp, 0x40
000070d6f3dd91d8  vmovaps xmm0, [rsp]
000070d6f3dd91dd  vmovaps xmm1, [rsp+0x10]
000070d6f3dd91e3  vmovaps xmm2, [rsp+0x20]
000070d6f3dd91e9  vmovaps xmm3, [rsp+0x30]
000070d6f3dd91ef  vmovaps xmm4, [rsp+0x40]
000070d6f3dd91f5  vmovaps xmm5, [rsp+0x50]
000070d6f3dd91fb  vmovaps xmm6, [rsp+0x60]
000070d6f3dd9201  vmovaps xmm7, [rsp+0x70]
000070d6f3dd9207  vmovaps xmm9, [rsp+0x80]
000070d6f3dd9210  vmovaps xmm10, [rsp+0x90]
000070d6f3dd9219  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd9222  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd922b  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd9234  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd923d  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd9246  add rsp, 0xF0
000070d6f3dd924d  pop r11
000070d6f3dd924f  pop r10
000070d6f3dd9251  pop r9
000070d6f3dd9253  pop r8
000070d6f3dd9255  pop rsi
000070d6f3dd9256  pop rdi
000070d6f3dd9257  pop rdx
000070d6f3dd9258  pop rcx
000070d6f3dd9259  pop rax
000070d6f3dd925a  add rsp, 0x08
000070d6f3dd925e  jmp 0x000070D6F3DD72CF
000070d6f3dd9263  sub rsp, 0x08
000070d6f3dd9267  push rax
000070d6f3dd9268  push rcx
000070d6f3dd9269  push rdx
000070d6f3dd926a  push rdi
000070d6f3dd926b  push rsi
000070d6f3dd926c  push r8
000070d6f3dd926e  push r9
000070d6f3dd9270  push r10
000070d6f3dd9272  push r11
000070d6f3dd9274  sub rsp, 0xF0
000070d6f3dd927b  vmovaps [rsp], xmm0
000070d6f3dd9280  vmovaps [rsp+0x10], xmm1
000070d6f3dd9286  vmovaps [rsp+0x20], xmm2
000070d6f3dd928c  vmovaps [rsp+0x30], xmm3
000070d6f3dd9292  vmovaps [rsp+0x40], xmm4
000070d6f3dd9298  vmovaps [rsp+0x50], xmm5
000070d6f3dd929e  vmovaps [rsp+0x60], xmm6
000070d6f3dd92a4  vmovaps [rsp+0x70], xmm7
000070d6f3dd92aa  vmovaps [rsp+0x80], xmm8
000070d6f3dd92b3  vmovaps [rsp+0x90], xmm9
000070d6f3dd92bc  vmovaps [rsp+0xA0], xmm10
000070d6f3dd92c5  vmovaps [rsp+0xB0], xmm12
000070d6f3dd92ce  vmovaps [rsp+0xC0], xmm13
000070d6f3dd92d7  vmovaps [rsp+0xD0], xmm14
000070d6f3dd92e0  vmovaps [rsp+0xE0], xmm15
000070d6f3dd92e9  sub rsp, 0x40
000070d6f3dd92ed  lea rdi, [rsp]
000070d6f3dd92f1  lea rsi, [rsp+0x10]
000070d6f3dd92f6  lea rdx, [rsp+0x20]
000070d6f3dd92fb  lea rcx, [rsp+0x30]
000070d6f3dd9300  mov r8d, 0x00
000070d6f3dd9306  lea r9, [r15+0x3A8]
000070d6f3dd930d  movaps [rdi], xmm11
000070d6f3dd9311  movaps [rsi], xmm9
000070d6f3dd9315  movaps [rdx], xmm1
000070d6f3dd9318  movaps [rcx], xmm13
000070d6f3dd931c  mov rax, 0x61D08D40EA50
000070d6f3dd9326  call rax
000070d6f3dd9328  movaps xmm11, [rsp]
000070d6f3dd932d  add rsp, 0x40
000070d6f3dd9331  vmovaps xmm0, [rsp]
000070d6f3dd9336  vmovaps xmm1, [rsp+0x10]
000070d6f3dd933c  vmovaps xmm2, [rsp+0x20]
000070d6f3dd9342  vmovaps xmm3, [rsp+0x30]
000070d6f3dd9348  vmovaps xmm4, [rsp+0x40]
000070d6f3dd934e  vmovaps xmm5, [rsp+0x50]
000070d6f3dd9354  vmovaps xmm6, [rsp+0x60]
000070d6f3dd935a  vmovaps xmm7, [rsp+0x70]
000070d6f3dd9360  vmovaps xmm8, [rsp+0x80]
000070d6f3dd9369  vmovaps xmm9, [rsp+0x90]
000070d6f3dd9372  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd937b  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd9384  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd938d  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd9396  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd939f  add rsp, 0xF0
000070d6f3dd93a6  pop r11
000070d6f3dd93a8  pop r10
000070d6f3dd93aa  pop r9
000070d6f3dd93ac  pop r8
000070d6f3dd93ae  pop rsi
000070d6f3dd93af  pop rdi
000070d6f3dd93b0  pop rdx
000070d6f3dd93b1  pop rcx
000070d6f3dd93b2  pop rax
000070d6f3dd93b3  add rsp, 0x08
000070d6f3dd93b7  jmp 0x000070D6F3DD72F5
000070d6f3dd93bc  sub rsp, 0x08
000070d6f3dd93c0  push rax
000070d6f3dd93c1  push rcx
000070d6f3dd93c2  push rdx
000070d6f3dd93c3  push rdi
000070d6f3dd93c4  push rsi
000070d6f3dd93c5  push r8
000070d6f3dd93c7  push r9
000070d6f3dd93c9  push r10
000070d6f3dd93cb  push r11
000070d6f3dd93cd  sub rsp, 0xF0
000070d6f3dd93d4  vmovaps [rsp], xmm0
000070d6f3dd93d9  vmovaps [rsp+0x10], xmm1
000070d6f3dd93df  vmovaps [rsp+0x20], xmm2
000070d6f3dd93e5  vmovaps [rsp+0x30], xmm3
000070d6f3dd93eb  vmovaps [rsp+0x40], xmm4
000070d6f3dd93f1  vmovaps [rsp+0x50], xmm5
000070d6f3dd93f7  vmovaps [rsp+0x60], xmm6
000070d6f3dd93fd  vmovaps [rsp+0x70], xmm7
000070d6f3dd9403  vmovaps [rsp+0x80], xmm8
000070d6f3dd940c  vmovaps [rsp+0x90], xmm9
000070d6f3dd9415  vmovaps [rsp+0xA0], xmm10
000070d6f3dd941e  vmovaps [rsp+0xB0], xmm11
000070d6f3dd9427  vmovaps [rsp+0xC0], xmm12
000070d6f3dd9430  vmovaps [rsp+0xD0], xmm14
000070d6f3dd9439  vmovaps [rsp+0xE0], xmm15
000070d6f3dd9442  sub rsp, 0x40
000070d6f3dd9446  lea rdi, [rsp]
000070d6f3dd944a  lea rsi, [rsp+0x10]
000070d6f3dd944f  lea rdx, [rsp+0x20]
000070d6f3dd9454  lea rcx, [rsp+0x30]
000070d6f3dd9459  mov r8d, 0x00
000070d6f3dd945f  lea r9, [r15+0x3A8]
000070d6f3dd9466  movaps [rdi], xmm13
000070d6f3dd946a  movaps [rsi], xmm10
000070d6f3dd946e  movaps [rdx], xmm7
000070d6f3dd9471  movaps [rcx], xmm1
000070d6f3dd9474  mov rax, 0x61D08D40EA50
000070d6f3dd947e  call rax
000070d6f3dd9480  movaps xmm13, [rsp]
000070d6f3dd9485  add rsp, 0x40
000070d6f3dd9489  vmovaps xmm0, [rsp]
000070d6f3dd948e  vmovaps xmm1, [rsp+0x10]
000070d6f3dd9494  vmovaps xmm2, [rsp+0x20]
000070d6f3dd949a  vmovaps xmm3, [rsp+0x30]
000070d6f3dd94a0  vmovaps xmm4, [rsp+0x40]
000070d6f3dd94a6  vmovaps xmm5, [rsp+0x50]
000070d6f3dd94ac  vmovaps xmm6, [rsp+0x60]
000070d6f3dd94b2  vmovaps xmm7, [rsp+0x70]
000070d6f3dd94b8  vmovaps xmm8, [rsp+0x80]
000070d6f3dd94c1  vmovaps xmm9, [rsp+0x90]
000070d6f3dd94ca  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd94d3  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd94dc  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd94e5  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd94ee  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd94f7  add rsp, 0xF0
000070d6f3dd94fe  pop r11
000070d6f3dd9500  pop r10
000070d6f3dd9502  pop r9
000070d6f3dd9504  pop r8
000070d6f3dd9506  pop rsi
000070d6f3dd9507  pop rdi
000070d6f3dd9508  pop rdx
000070d6f3dd9509  pop rcx
000070d6f3dd950a  pop rax
000070d6f3dd950b  add rsp, 0x08
000070d6f3dd950f  jmp 0x000070D6F3DD731B
000070d6f3dd9514  sub rsp, 0x08
000070d6f3dd9518  push rax
000070d6f3dd9519  push rcx
000070d6f3dd951a  push rdx
000070d6f3dd951b  push rdi
000070d6f3dd951c  push rsi
000070d6f3dd951d  push r8
000070d6f3dd951f  push r9
000070d6f3dd9521  push r10
000070d6f3dd9523  push r11
000070d6f3dd9525  sub rsp, 0xF0
000070d6f3dd952c  vmovaps [rsp], xmm0
000070d6f3dd9531  vmovaps [rsp+0x10], xmm1
000070d6f3dd9537  vmovaps [rsp+0x20], xmm2
000070d6f3dd953d  vmovaps [rsp+0x30], xmm3
000070d6f3dd9543  vmovaps [rsp+0x40], xmm4
000070d6f3dd9549  vmovaps [rsp+0x50], xmm5
000070d6f3dd954f  vmovaps [rsp+0x60], xmm6
000070d6f3dd9555  vmovaps [rsp+0x70], xmm7
000070d6f3dd955b  vmovaps [rsp+0x80], xmm8
000070d6f3dd9564  vmovaps [rsp+0x90], xmm9
000070d6f3dd956d  vmovaps [rsp+0xA0], xmm11
000070d6f3dd9576  vmovaps [rsp+0xB0], xmm12
000070d6f3dd957f  vmovaps [rsp+0xC0], xmm13
000070d6f3dd9588  vmovaps [rsp+0xD0], xmm14
000070d6f3dd9591  vmovaps [rsp+0xE0], xmm15
000070d6f3dd959a  sub rsp, 0x40
000070d6f3dd959e  lea rdi, [rsp]
000070d6f3dd95a2  lea rsi, [rsp+0x10]
000070d6f3dd95a7  lea rdx, [rsp+0x20]
000070d6f3dd95ac  lea rcx, [rsp+0x30]
000070d6f3dd95b1  mov r8d, 0x00
000070d6f3dd95b7  lea r9, [r15+0x3A8]
000070d6f3dd95be  movaps [rdi], xmm10
000070d6f3dd95c2  movaps [rsi], xmm6
000070d6f3dd95c5  movaps [rdx], xmm15
000070d6f3dd95c9  movaps [rcx], xmm1
000070d6f3dd95cc  mov rax, 0x61D08D40EA50
000070d6f3dd95d6  call rax
000070d6f3dd95d8  movaps xmm10, [rsp]
000070d6f3dd95dd  add rsp, 0x40
000070d6f3dd95e1  vmovaps xmm0, [rsp]
000070d6f3dd95e6  vmovaps xmm1, [rsp+0x10]
000070d6f3dd95ec  vmovaps xmm2, [rsp+0x20]
000070d6f3dd95f2  vmovaps xmm3, [rsp+0x30]
000070d6f3dd95f8  vmovaps xmm4, [rsp+0x40]
000070d6f3dd95fe  vmovaps xmm5, [rsp+0x50]
000070d6f3dd9604  vmovaps xmm6, [rsp+0x60]
000070d6f3dd960a  vmovaps xmm7, [rsp+0x70]
000070d6f3dd9610  vmovaps xmm8, [rsp+0x80]
000070d6f3dd9619  vmovaps xmm9, [rsp+0x90]
000070d6f3dd9622  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd962b  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd9634  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd963d  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd9646  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd964f  add rsp, 0xF0
000070d6f3dd9656  pop r11
000070d6f3dd9658  pop r10
000070d6f3dd965a  pop r9
000070d6f3dd965c  pop r8
000070d6f3dd965e  pop rsi
000070d6f3dd965f  pop rdi
000070d6f3dd9660  pop rdx
000070d6f3dd9661  pop rcx
000070d6f3dd9662  pop rax
000070d6f3dd9663  add rsp, 0x08
000070d6f3dd9667  jmp 0x000070D6F3DD7341
000070d6f3dd966c  call 0x000070D6F3BFF430
000070d6f3dd9671  jmp 0x000070D6F3DD734B
000070d6f3dd9676  call 0x000070D6F3C0E760
000070d6f3dd967b  jmp 0x000070D6F3DD7355
000070d6f3dd9680  sub rsp, 0x08
000070d6f3dd9684  push rax
000070d6f3dd9685  push rcx
000070d6f3dd9686  push rdx
000070d6f3dd9687  push rdi
000070d6f3dd9688  push rsi
000070d6f3dd9689  push r8
000070d6f3dd968b  push r9
000070d6f3dd968d  push r10
000070d6f3dd968f  push r11
000070d6f3dd9691  sub rsp, 0xF0
000070d6f3dd9698  vmovaps [rsp], xmm0
000070d6f3dd969d  vmovaps [rsp+0x10], xmm1
000070d6f3dd96a3  vmovaps [rsp+0x20], xmm2
000070d6f3dd96a9  vmovaps [rsp+0x30], xmm3
000070d6f3dd96af  vmovaps [rsp+0x40], xmm4
000070d6f3dd96b5  vmovaps [rsp+0x50], xmm5
000070d6f3dd96bb  vmovaps [rsp+0x60], xmm6
000070d6f3dd96c1  vmovaps [rsp+0x70], xmm8
000070d6f3dd96c7  vmovaps [rsp+0x80], xmm9
000070d6f3dd96d0  vmovaps [rsp+0x90], xmm10
000070d6f3dd96d9  vmovaps [rsp+0xA0], xmm11
000070d6f3dd96e2  vmovaps [rsp+0xB0], xmm12
000070d6f3dd96eb  vmovaps [rsp+0xC0], xmm13
000070d6f3dd96f4  vmovaps [rsp+0xD0], xmm14
000070d6f3dd96fd  vmovaps [rsp+0xE0], xmm15
000070d6f3dd9706  sub rsp, 0x40
000070d6f3dd970a  lea rdi, [rsp]
000070d6f3dd970e  lea rsi, [rsp+0x10]
000070d6f3dd9713  lea rdx, [rsp+0x20]
000070d6f3dd9718  lea rcx, [rsp+0x30]
000070d6f3dd971d  mov r8d, 0x00
000070d6f3dd9723  lea r9, [r15+0x3A8]
000070d6f3dd972a  movaps [rdi], xmm7
000070d6f3dd972d  movaps [rsi], xmm8
000070d6f3dd9731  movaps [rdx], xmm3
000070d6f3dd9734  movaps [rcx], xmm9
000070d6f3dd9738  mov rax, 0x61D08D40EA50
000070d6f3dd9742  call rax
000070d6f3dd9744  movaps xmm7, [rsp]
000070d6f3dd9748  add rsp, 0x40
000070d6f3dd974c  vmovaps xmm0, [rsp]
000070d6f3dd9751  vmovaps xmm1, [rsp+0x10]
000070d6f3dd9757  vmovaps xmm2, [rsp+0x20]
000070d6f3dd975d  vmovaps xmm3, [rsp+0x30]
000070d6f3dd9763  vmovaps xmm4, [rsp+0x40]
000070d6f3dd9769  vmovaps xmm5, [rsp+0x50]
000070d6f3dd976f  vmovaps xmm6, [rsp+0x60]
000070d6f3dd9775  vmovaps xmm8, [rsp+0x70]
000070d6f3dd977b  vmovaps xmm9, [rsp+0x80]
000070d6f3dd9784  vmovaps xmm10, [rsp+0x90]
000070d6f3dd978d  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd9796  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd979f  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd97a8  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd97b1  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd97ba  add rsp, 0xF0
000070d6f3dd97c1  pop r11
000070d6f3dd97c3  pop r10
000070d6f3dd97c5  pop r9
000070d6f3dd97c7  pop r8
000070d6f3dd97c9  pop rsi
000070d6f3dd97ca  pop rdi
000070d6f3dd97cb  pop rdx
000070d6f3dd97cc  pop rcx
000070d6f3dd97cd  pop rax
000070d6f3dd97ce  add rsp, 0x08
000070d6f3dd97d2  jmp 0x000070D6F3DD737D
000070d6f3dd97d7  sub rsp, 0x08
000070d6f3dd97db  push rax
000070d6f3dd97dc  push rcx
000070d6f3dd97dd  push rdx
000070d6f3dd97de  push rdi
000070d6f3dd97df  push rsi
000070d6f3dd97e0  push r8
000070d6f3dd97e2  push r9
000070d6f3dd97e4  push r10
000070d6f3dd97e6  push r11
000070d6f3dd97e8  sub rsp, 0xF0
000070d6f3dd97ef  vmovaps [rsp], xmm0
000070d6f3dd97f4  vmovaps [rsp+0x10], xmm1
000070d6f3dd97fa  vmovaps [rsp+0x20], xmm2
000070d6f3dd9800  vmovaps [rsp+0x30], xmm3
000070d6f3dd9806  vmovaps [rsp+0x40], xmm4
000070d6f3dd980c  vmovaps [rsp+0x50], xmm5
000070d6f3dd9812  vmovaps [rsp+0x60], xmm6
000070d6f3dd9818  vmovaps [rsp+0x70], xmm7
000070d6f3dd981e  vmovaps [rsp+0x80], xmm9
000070d6f3dd9827  vmovaps [rsp+0x90], xmm10
000070d6f3dd9830  vmovaps [rsp+0xA0], xmm11
000070d6f3dd9839  vmovaps [rsp+0xB0], xmm12
000070d6f3dd9842  vmovaps [rsp+0xC0], xmm13
000070d6f3dd984b  vmovaps [rsp+0xD0], xmm14
000070d6f3dd9854  vmovaps [rsp+0xE0], xmm15
000070d6f3dd985d  sub rsp, 0x40
000070d6f3dd9861  lea rdi, [rsp]
000070d6f3dd9865  lea rsi, [rsp+0x10]
000070d6f3dd986a  lea rdx, [rsp+0x20]
000070d6f3dd986f  lea rcx, [rsp+0x30]
000070d6f3dd9874  mov r8d, 0x00
000070d6f3dd987a  lea r9, [r15+0x3A8]
000070d6f3dd9881  movaps [rdi], xmm8
000070d6f3dd9885  movaps [rsi], xmm11
000070d6f3dd9889  movaps [rdx], xmm14
000070d6f3dd988d  movaps [rcx], xmm9
000070d6f3dd9891  mov rax, 0x61D08D40EA50
000070d6f3dd989b  call rax
000070d6f3dd989d  movaps xmm8, [rsp]
000070d6f3dd98a2  add rsp, 0x40
000070d6f3dd98a6  vmovaps xmm0, [rsp]
000070d6f3dd98ab  vmovaps xmm1, [rsp+0x10]
000070d6f3dd98b1  vmovaps xmm2, [rsp+0x20]
000070d6f3dd98b7  vmovaps xmm3, [rsp+0x30]
000070d6f3dd98bd  vmovaps xmm4, [rsp+0x40]
000070d6f3dd98c3  vmovaps xmm5, [rsp+0x50]
000070d6f3dd98c9  vmovaps xmm6, [rsp+0x60]
000070d6f3dd98cf  vmovaps xmm7, [rsp+0x70]
000070d6f3dd98d5  vmovaps xmm9, [rsp+0x80]
000070d6f3dd98de  vmovaps xmm10, [rsp+0x90]
000070d6f3dd98e7  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd98f0  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd98f9  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd9902  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd990b  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd9914  add rsp, 0xF0
000070d6f3dd991b  pop r11
000070d6f3dd991d  pop r10
000070d6f3dd991f  pop r9
000070d6f3dd9921  pop r8
000070d6f3dd9923  pop rsi
000070d6f3dd9924  pop rdi
000070d6f3dd9925  pop rdx
000070d6f3dd9926  pop rcx
000070d6f3dd9927  pop rax
000070d6f3dd9928  add rsp, 0x08
000070d6f3dd992c  jmp 0x000070D6F3DD73A6
000070d6f3dd9931  sub rsp, 0x08
000070d6f3dd9935  push rax
000070d6f3dd9936  push rcx
000070d6f3dd9937  push rdx
000070d6f3dd9938  push rdi
000070d6f3dd9939  push rsi
000070d6f3dd993a  push r8
000070d6f3dd993c  push r9
000070d6f3dd993e  push r10
000070d6f3dd9940  push r11
000070d6f3dd9942  sub rsp, 0xF0
000070d6f3dd9949  vmovaps [rsp], xmm0
000070d6f3dd994e  vmovaps [rsp+0x10], xmm1
000070d6f3dd9954  vmovaps [rsp+0x20], xmm2
000070d6f3dd995a  vmovaps [rsp+0x30], xmm3
000070d6f3dd9960  vmovaps [rsp+0x40], xmm4
000070d6f3dd9966  vmovaps [rsp+0x50], xmm5
000070d6f3dd996c  vmovaps [rsp+0x60], xmm6
000070d6f3dd9972  vmovaps [rsp+0x70], xmm7
000070d6f3dd9978  vmovaps [rsp+0x80], xmm8
000070d6f3dd9981  vmovaps [rsp+0x90], xmm9
000070d6f3dd998a  vmovaps [rsp+0xA0], xmm10
000070d6f3dd9993  vmovaps [rsp+0xB0], xmm12
000070d6f3dd999c  vmovaps [rsp+0xC0], xmm13
000070d6f3dd99a5  vmovaps [rsp+0xD0], xmm14
000070d6f3dd99ae  vmovaps [rsp+0xE0], xmm15
000070d6f3dd99b7  sub rsp, 0x40
000070d6f3dd99bb  lea rdi, [rsp]
000070d6f3dd99bf  lea rsi, [rsp+0x10]
000070d6f3dd99c4  lea rdx, [rsp+0x20]
000070d6f3dd99c9  lea rcx, [rsp+0x30]
000070d6f3dd99ce  mov r8d, 0x00
000070d6f3dd99d4  lea r9, [r15+0x3A8]
000070d6f3dd99db  movaps [rdi], xmm11
000070d6f3dd99df  movaps [rsi], xmm13
000070d6f3dd99e3  movaps [rdx], xmm12
000070d6f3dd99e7  movaps [rcx], xmm14
000070d6f3dd99eb  mov rax, 0x61D08D40EA50
000070d6f3dd99f5  call rax
000070d6f3dd99f7  movaps xmm11, [rsp]
000070d6f3dd99fc  add rsp, 0x40
000070d6f3dd9a00  vmovaps xmm0, [rsp]
000070d6f3dd9a05  vmovaps xmm1, [rsp+0x10]
000070d6f3dd9a0b  vmovaps xmm2, [rsp+0x20]
000070d6f3dd9a11  vmovaps xmm3, [rsp+0x30]
000070d6f3dd9a17  vmovaps xmm4, [rsp+0x40]
000070d6f3dd9a1d  vmovaps xmm5, [rsp+0x50]
000070d6f3dd9a23  vmovaps xmm6, [rsp+0x60]
000070d6f3dd9a29  vmovaps xmm7, [rsp+0x70]
000070d6f3dd9a2f  vmovaps xmm8, [rsp+0x80]
000070d6f3dd9a38  vmovaps xmm9, [rsp+0x90]
000070d6f3dd9a41  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd9a4a  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd9a53  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd9a5c  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd9a65  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd9a6e  add rsp, 0xF0
000070d6f3dd9a75  pop r11
000070d6f3dd9a77  pop r10
000070d6f3dd9a79  pop r9
000070d6f3dd9a7b  pop r8
000070d6f3dd9a7d  pop rsi
000070d6f3dd9a7e  pop rdi
000070d6f3dd9a7f  pop rdx
000070d6f3dd9a80  pop rcx
000070d6f3dd9a81  pop rax
000070d6f3dd9a82  add rsp, 0x08
000070d6f3dd9a86  jmp 0x000070D6F3DD73CF
000070d6f3dd9a8b  sub rsp, 0x08
000070d6f3dd9a8f  push rax
000070d6f3dd9a90  push rcx
000070d6f3dd9a91  push rdx
000070d6f3dd9a92  push rdi
000070d6f3dd9a93  push rsi
000070d6f3dd9a94  push r8
000070d6f3dd9a96  push r9
000070d6f3dd9a98  push r10
000070d6f3dd9a9a  push r11
000070d6f3dd9a9c  sub rsp, 0xF0
000070d6f3dd9aa3  vmovaps [rsp], xmm0
000070d6f3dd9aa8  vmovaps [rsp+0x10], xmm1
000070d6f3dd9aae  vmovaps [rsp+0x20], xmm2
000070d6f3dd9ab4  vmovaps [rsp+0x30], xmm3
000070d6f3dd9aba  vmovaps [rsp+0x40], xmm4
000070d6f3dd9ac0  vmovaps [rsp+0x50], xmm5
000070d6f3dd9ac6  vmovaps [rsp+0x60], xmm6
000070d6f3dd9acc  vmovaps [rsp+0x70], xmm7
000070d6f3dd9ad2  vmovaps [rsp+0x80], xmm8
000070d6f3dd9adb  vmovaps [rsp+0x90], xmm9
000070d6f3dd9ae4  vmovaps [rsp+0xA0], xmm10
000070d6f3dd9aed  vmovaps [rsp+0xB0], xmm11
000070d6f3dd9af6  vmovaps [rsp+0xC0], xmm13
000070d6f3dd9aff  vmovaps [rsp+0xD0], xmm14
000070d6f3dd9b08  vmovaps [rsp+0xE0], xmm15
000070d6f3dd9b11  sub rsp, 0x40
000070d6f3dd9b15  lea rdi, [rsp]
000070d6f3dd9b19  lea rsi, [rsp+0x10]
000070d6f3dd9b1e  lea rdx, [rsp+0x20]
000070d6f3dd9b23  lea rcx, [rsp+0x30]
000070d6f3dd9b28  mov r8d, 0x00
000070d6f3dd9b2e  lea r9, [r15+0x3A8]
000070d6f3dd9b35  movaps [rdi], xmm12
000070d6f3dd9b39  movaps [rsi], xmm10
000070d6f3dd9b3d  movaps [rdx], xmm15
000070d6f3dd9b41  movaps [rcx], xmm14
000070d6f3dd9b45  mov rax, 0x61D08D40EA50
000070d6f3dd9b4f  call rax
000070d6f3dd9b51  movaps xmm12, [rsp]
000070d6f3dd9b56  add rsp, 0x40
000070d6f3dd9b5a  vmovaps xmm0, [rsp]
000070d6f3dd9b5f  vmovaps xmm1, [rsp+0x10]
000070d6f3dd9b65  vmovaps xmm2, [rsp+0x20]
000070d6f3dd9b6b  vmovaps xmm3, [rsp+0x30]
000070d6f3dd9b71  vmovaps xmm4, [rsp+0x40]
000070d6f3dd9b77  vmovaps xmm5, [rsp+0x50]
000070d6f3dd9b7d  vmovaps xmm6, [rsp+0x60]
000070d6f3dd9b83  vmovaps xmm7, [rsp+0x70]
000070d6f3dd9b89  vmovaps xmm8, [rsp+0x80]
000070d6f3dd9b92  vmovaps xmm9, [rsp+0x90]
000070d6f3dd9b9b  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd9ba4  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd9bad  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd9bb6  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd9bbf  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd9bc8  add rsp, 0xF0
000070d6f3dd9bcf  pop r11
000070d6f3dd9bd1  pop r10
000070d6f3dd9bd3  pop r9
000070d6f3dd9bd5  pop r8
000070d6f3dd9bd7  pop rsi
000070d6f3dd9bd8  pop rdi
000070d6f3dd9bd9  pop rdx
000070d6f3dd9bda  pop rcx
000070d6f3dd9bdb  pop rax
000070d6f3dd9bdc  add rsp, 0x08
000070d6f3dd9be0  jmp 0x000070D6F3DD73F8
000070d6f3dd9be5  call 0x000070D6F3C0E760
000070d6f3dd9bea  jmp 0x000070D6F3DD7405
000070d6f3dd9bef  call 0x000070D6F3C0D4E0
000070d6f3dd9bf4  jmp 0x000070D6F3DD7412
000070d6f3dd9bf9  sub rsp, 0x08
000070d6f3dd9bfd  push rax
000070d6f3dd9bfe  push rcx
000070d6f3dd9bff  push rdx
000070d6f3dd9c00  push rdi
000070d6f3dd9c01  push rsi
000070d6f3dd9c02  push r8
000070d6f3dd9c04  push r9
000070d6f3dd9c06  push r10
000070d6f3dd9c08  push r11
000070d6f3dd9c0a  sub rsp, 0xF0
000070d6f3dd9c11  vmovaps [rsp], xmm0
000070d6f3dd9c16  vmovaps [rsp+0x10], xmm1
000070d6f3dd9c1c  vmovaps [rsp+0x20], xmm2
000070d6f3dd9c22  vmovaps [rsp+0x30], xmm3
000070d6f3dd9c28  vmovaps [rsp+0x40], xmm4
000070d6f3dd9c2e  vmovaps [rsp+0x50], xmm5
000070d6f3dd9c34  vmovaps [rsp+0x60], xmm6
000070d6f3dd9c3a  vmovaps [rsp+0x70], xmm7
000070d6f3dd9c40  vmovaps [rsp+0x80], xmm8
000070d6f3dd9c49  vmovaps [rsp+0x90], xmm9
000070d6f3dd9c52  vmovaps [rsp+0xA0], xmm11
000070d6f3dd9c5b  vmovaps [rsp+0xB0], xmm12
000070d6f3dd9c64  vmovaps [rsp+0xC0], xmm13
000070d6f3dd9c6d  vmovaps [rsp+0xD0], xmm14
000070d6f3dd9c76  vmovaps [rsp+0xE0], xmm15
000070d6f3dd9c7f  sub rsp, 0x40
000070d6f3dd9c83  lea rdi, [rsp]
000070d6f3dd9c87  lea rsi, [rsp+0x10]
000070d6f3dd9c8c  lea rdx, [rsp+0x20]
000070d6f3dd9c91  lea rcx, [rsp+0x30]
000070d6f3dd9c96  mov r8d, 0x00
000070d6f3dd9c9c  lea r9, [r15+0x3A8]
000070d6f3dd9ca3  movaps [rdi], xmm10
000070d6f3dd9ca7  movaps [rsi], xmm7
000070d6f3dd9caa  movaps [rdx], xmm1
000070d6f3dd9cad  movaps [rcx], xmm13
000070d6f3dd9cb1  mov rax, 0x61D08D40EA50
000070d6f3dd9cbb  call rax
000070d6f3dd9cbd  movaps xmm10, [rsp]
000070d6f3dd9cc2  add rsp, 0x40
000070d6f3dd9cc6  vmovaps xmm0, [rsp]
000070d6f3dd9ccb  vmovaps xmm1, [rsp+0x10]
000070d6f3dd9cd1  vmovaps xmm2, [rsp+0x20]
000070d6f3dd9cd7  vmovaps xmm3, [rsp+0x30]
000070d6f3dd9cdd  vmovaps xmm4, [rsp+0x40]
000070d6f3dd9ce3  vmovaps xmm5, [rsp+0x50]
000070d6f3dd9ce9  vmovaps xmm6, [rsp+0x60]
000070d6f3dd9cef  vmovaps xmm7, [rsp+0x70]
000070d6f3dd9cf5  vmovaps xmm8, [rsp+0x80]
000070d6f3dd9cfe  vmovaps xmm9, [rsp+0x90]
000070d6f3dd9d07  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd9d10  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd9d19  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd9d22  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd9d2b  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd9d34  add rsp, 0xF0
000070d6f3dd9d3b  pop r11
000070d6f3dd9d3d  pop r10
000070d6f3dd9d3f  pop r9
000070d6f3dd9d41  pop r8
000070d6f3dd9d43  pop rsi
000070d6f3dd9d44  pop rdi
000070d6f3dd9d45  pop rdx
000070d6f3dd9d46  pop rcx
000070d6f3dd9d47  pop rax
000070d6f3dd9d48  add rsp, 0x08
000070d6f3dd9d4c  jmp 0x000070D6F3DD7448
000070d6f3dd9d51  call 0x000070D6F3BFF430
000070d6f3dd9d56  jmp 0x000070D6F3DD745A
000070d6f3dd9d5b  sub rsp, 0x08
000070d6f3dd9d5f  push rax
000070d6f3dd9d60  push rcx
000070d6f3dd9d61  push rdx
000070d6f3dd9d62  push rdi
000070d6f3dd9d63  push rsi
000070d6f3dd9d64  push r8
000070d6f3dd9d66  push r9
000070d6f3dd9d68  push r10
000070d6f3dd9d6a  push r11
000070d6f3dd9d6c  sub rsp, 0xF0
000070d6f3dd9d73  vmovaps [rsp], xmm0
000070d6f3dd9d78  vmovaps [rsp+0x10], xmm1
000070d6f3dd9d7e  vmovaps [rsp+0x20], xmm2
000070d6f3dd9d84  vmovaps [rsp+0x30], xmm3
000070d6f3dd9d8a  vmovaps [rsp+0x40], xmm4
000070d6f3dd9d90  vmovaps [rsp+0x50], xmm5
000070d6f3dd9d96  vmovaps [rsp+0x60], xmm6
000070d6f3dd9d9c  vmovaps [rsp+0x70], xmm7
000070d6f3dd9da2  vmovaps [rsp+0x80], xmm8
000070d6f3dd9dab  vmovaps [rsp+0x90], xmm10
000070d6f3dd9db4  vmovaps [rsp+0xA0], xmm11
000070d6f3dd9dbd  vmovaps [rsp+0xB0], xmm12
000070d6f3dd9dc6  vmovaps [rsp+0xC0], xmm13
000070d6f3dd9dcf  vmovaps [rsp+0xD0], xmm14
000070d6f3dd9dd8  vmovaps [rsp+0xE0], xmm15
000070d6f3dd9de1  sub rsp, 0x40
000070d6f3dd9de5  lea rdi, [rsp]
000070d6f3dd9de9  lea rsi, [rsp+0x10]
000070d6f3dd9dee  lea rdx, [rsp+0x20]
000070d6f3dd9df3  lea rcx, [rsp+0x30]
000070d6f3dd9df8  mov r8d, 0x00
000070d6f3dd9dfe  lea r9, [r15+0x3A8]
000070d6f3dd9e05  movaps [rdi], xmm9
000070d6f3dd9e09  movaps [rsi], xmm8
000070d6f3dd9e0d  movaps [rdx], xmm14
000070d6f3dd9e11  movaps [rcx], xmm13
000070d6f3dd9e15  mov rax, 0x61D08D40EA50
000070d6f3dd9e1f  call rax
000070d6f3dd9e21  movaps xmm9, [rsp]
000070d6f3dd9e26  add rsp, 0x40
000070d6f3dd9e2a  vmovaps xmm0, [rsp]
000070d6f3dd9e2f  vmovaps xmm1, [rsp+0x10]
000070d6f3dd9e35  vmovaps xmm2, [rsp+0x20]
000070d6f3dd9e3b  vmovaps xmm3, [rsp+0x30]
000070d6f3dd9e41  vmovaps xmm4, [rsp+0x40]
000070d6f3dd9e47  vmovaps xmm5, [rsp+0x50]
000070d6f3dd9e4d  vmovaps xmm6, [rsp+0x60]
000070d6f3dd9e53  vmovaps xmm7, [rsp+0x70]
000070d6f3dd9e59  vmovaps xmm8, [rsp+0x80]
000070d6f3dd9e62  vmovaps xmm10, [rsp+0x90]
000070d6f3dd9e6b  vmovaps xmm11, [rsp+0xA0]
000070d6f3dd9e74  vmovaps xmm12, [rsp+0xB0]
000070d6f3dd9e7d  vmovaps xmm13, [rsp+0xC0]
000070d6f3dd9e86  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd9e8f  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd9e98  add rsp, 0xF0
000070d6f3dd9e9f  pop r11
000070d6f3dd9ea1  pop r10
000070d6f3dd9ea3  pop r9
000070d6f3dd9ea5  pop r8
000070d6f3dd9ea7  pop rsi
000070d6f3dd9ea8  pop rdi
000070d6f3dd9ea9  pop rdx
000070d6f3dd9eaa  pop rcx
000070d6f3dd9eab  pop rax
000070d6f3dd9eac  add rsp, 0x08
000070d6f3dd9eb0  jmp 0x000070D6F3DD7488
000070d6f3dd9eb5  sub rsp, 0x08
000070d6f3dd9eb9  push rax
000070d6f3dd9eba  push rcx
000070d6f3dd9ebb  push rdx
000070d6f3dd9ebc  push rdi
000070d6f3dd9ebd  push rsi
000070d6f3dd9ebe  push r8
000070d6f3dd9ec0  push r9
000070d6f3dd9ec2  push r10
000070d6f3dd9ec4  push r11
000070d6f3dd9ec6  sub rsp, 0xF0
000070d6f3dd9ecd  vmovaps [rsp], xmm0
000070d6f3dd9ed2  vmovaps [rsp+0x10], xmm1
000070d6f3dd9ed8  vmovaps [rsp+0x20], xmm2
000070d6f3dd9ede  vmovaps [rsp+0x30], xmm3
000070d6f3dd9ee4  vmovaps [rsp+0x40], xmm4
000070d6f3dd9eea  vmovaps [rsp+0x50], xmm5
000070d6f3dd9ef0  vmovaps [rsp+0x60], xmm6
000070d6f3dd9ef6  vmovaps [rsp+0x70], xmm7
000070d6f3dd9efc  vmovaps [rsp+0x80], xmm8
000070d6f3dd9f05  vmovaps [rsp+0x90], xmm9
000070d6f3dd9f0e  vmovaps [rsp+0xA0], xmm10
000070d6f3dd9f17  vmovaps [rsp+0xB0], xmm11
000070d6f3dd9f20  vmovaps [rsp+0xC0], xmm12
000070d6f3dd9f29  vmovaps [rsp+0xD0], xmm14
000070d6f3dd9f32  vmovaps [rsp+0xE0], xmm15
000070d6f3dd9f3b  sub rsp, 0x40
000070d6f3dd9f3f  lea rdi, [rsp]
000070d6f3dd9f43  lea rsi, [rsp+0x10]
000070d6f3dd9f48  lea rdx, [rsp+0x20]
000070d6f3dd9f4d  lea rcx, [rsp+0x30]
000070d6f3dd9f52  mov r8d, 0x00
000070d6f3dd9f58  lea r9, [r15+0x3A8]
000070d6f3dd9f5f  movaps [rdi], xmm13
000070d6f3dd9f63  movaps [rsi], xmm11
000070d6f3dd9f67  movaps [rdx], xmm15
000070d6f3dd9f6b  movaps [rcx], xmm14
000070d6f3dd9f6f  mov rax, 0x61D08D40EA50
000070d6f3dd9f79  call rax
000070d6f3dd9f7b  movaps xmm13, [rsp]
000070d6f3dd9f80  add rsp, 0x40
000070d6f3dd9f84  vmovaps xmm0, [rsp]
000070d6f3dd9f89  vmovaps xmm1, [rsp+0x10]
000070d6f3dd9f8f  vmovaps xmm2, [rsp+0x20]
000070d6f3dd9f95  vmovaps xmm3, [rsp+0x30]
000070d6f3dd9f9b  vmovaps xmm4, [rsp+0x40]
000070d6f3dd9fa1  vmovaps xmm5, [rsp+0x50]
000070d6f3dd9fa7  vmovaps xmm6, [rsp+0x60]
000070d6f3dd9fad  vmovaps xmm7, [rsp+0x70]
000070d6f3dd9fb3  vmovaps xmm8, [rsp+0x80]
000070d6f3dd9fbc  vmovaps xmm9, [rsp+0x90]
000070d6f3dd9fc5  vmovaps xmm10, [rsp+0xA0]
000070d6f3dd9fce  vmovaps xmm11, [rsp+0xB0]
000070d6f3dd9fd7  vmovaps xmm12, [rsp+0xC0]
000070d6f3dd9fe0  vmovaps xmm14, [rsp+0xD0]
000070d6f3dd9fe9  vmovaps xmm15, [rsp+0xE0]
000070d6f3dd9ff2  add rsp, 0xF0
000070d6f3dd9ff9  pop r11
000070d6f3dd9ffb  pop r10
000070d6f3dd9ffd  pop r9
000070d6f3dd9fff  pop r8
000070d6f3dda001  pop rsi
000070d6f3dda002  pop rdi
000070d6f3dda003  pop rdx
000070d6f3dda004  pop rcx
000070d6f3dda005  pop rax
000070d6f3dda006  add rsp, 0x08
000070d6f3dda00a  jmp 0x000070D6F3DD74B6
000070d6f3dda00f  sub rsp, 0x08
000070d6f3dda013  push rax
000070d6f3dda014  push rcx
000070d6f3dda015  push rdx
000070d6f3dda016  push rdi
000070d6f3dda017  push rsi
000070d6f3dda018  push r8
000070d6f3dda01a  push r9
000070d6f3dda01c  push r10
000070d6f3dda01e  push r11
000070d6f3dda020  sub rsp, 0xF0
000070d6f3dda027  vmovaps [rsp], xmm0
000070d6f3dda02c  vmovaps [rsp+0x10], xmm1
000070d6f3dda032  vmovaps [rsp+0x20], xmm2
000070d6f3dda038  vmovaps [rsp+0x30], xmm3
000070d6f3dda03e  vmovaps [rsp+0x40], xmm4
000070d6f3dda044  vmovaps [rsp+0x50], xmm5
000070d6f3dda04a  vmovaps [rsp+0x60], xmm6
000070d6f3dda050  vmovaps [rsp+0x70], xmm7
000070d6f3dda056  vmovaps [rsp+0x80], xmm8
000070d6f3dda05f  vmovaps [rsp+0x90], xmm9
000070d6f3dda068  vmovaps [rsp+0xA0], xmm10
000070d6f3dda071  vmovaps [rsp+0xB0], xmm11
000070d6f3dda07a  vmovaps [rsp+0xC0], xmm12
000070d6f3dda083  vmovaps [rsp+0xD0], xmm13
000070d6f3dda08c  vmovaps [rsp+0xE0], xmm15
000070d6f3dda095  sub rsp, 0x40
000070d6f3dda099  lea rdi, [rsp]
000070d6f3dda09d  lea rsi, [rsp+0x10]
000070d6f3dda0a2  lea rdx, [rsp+0x20]
000070d6f3dda0a7  lea rcx, [rsp+0x30]
000070d6f3dda0ac  mov r8d, 0x00
000070d6f3dda0b2  lea r9, [r15+0x3A8]
000070d6f3dda0b9  movaps [rdi], xmm14
000070d6f3dda0bd  movaps [rsi], xmm12
000070d6f3dda0c1  movaps [rdx], xmm1
000070d6f3dda0c4  movaps [rcx], xmm15
000070d6f3dda0c8  mov rax, 0x61D08D40EA50
000070d6f3dda0d2  call rax
000070d6f3dda0d4  movaps xmm14, [rsp]
000070d6f3dda0d9  add rsp, 0x40
000070d6f3dda0dd  vmovaps xmm0, [rsp]
000070d6f3dda0e2  vmovaps xmm1, [rsp+0x10]
000070d6f3dda0e8  vmovaps xmm2, [rsp+0x20]
000070d6f3dda0ee  vmovaps xmm3, [rsp+0x30]
000070d6f3dda0f4  vmovaps xmm4, [rsp+0x40]
000070d6f3dda0fa  vmovaps xmm5, [rsp+0x50]
000070d6f3dda100  vmovaps xmm6, [rsp+0x60]
000070d6f3dda106  vmovaps xmm7, [rsp+0x70]
000070d6f3dda10c  vmovaps xmm8, [rsp+0x80]
000070d6f3dda115  vmovaps xmm9, [rsp+0x90]
000070d6f3dda11e  vmovaps xmm10, [rsp+0xA0]
000070d6f3dda127  vmovaps xmm11, [rsp+0xB0]
000070d6f3dda130  vmovaps xmm12, [rsp+0xC0]
000070d6f3dda139  vmovaps xmm13, [rsp+0xD0]
000070d6f3dda142  vmovaps xmm15, [rsp+0xE0]
000070d6f3dda14b  add rsp, 0xF0
000070d6f3dda152  pop r11
000070d6f3dda154  pop r10
000070d6f3dda156  pop r9
000070d6f3dda158  pop r8
000070d6f3dda15a  pop rsi
000070d6f3dda15b  pop rdi
000070d6f3dda15c  pop rdx
000070d6f3dda15d  pop rcx
000070d6f3dda15e  pop rax
000070d6f3dda15f  add rsp, 0x08
000070d6f3dda163  jmp 0x000070D6F3DD74E4
000070d6f3dda168  call 0x000070D6F3C079B0
000070d6f3dda16d  jmp 0x000070D6F3DD74FA
000070d6f3dda172  call 0x000070D6F3CE3440
000070d6f3dda177  jmp 0x000070D6F3DD7504
000070d6f3dda17c  call 0x000070D6F3CDFCE0
000070d6f3dda181  jmp 0x000070D6F3DD750E
000070d6f3dda186  call 0x000070D6F3CE46C0
000070d6f3dda18b  jmp 0x000070D6F3DD7518
000070d6f3dda190  int3
000070d6f3dda191  nop [rax+rax*1], ax
000070d6f3dda19a  nop [rax+rax*1], ax
000070d6f3dda1a0  mov rax, [r15+0xF8]
000070d6f3dda1a7  lea r14, [rax+0x110]
000070d6f3dda1ae  mov r12, [r13+r14*1]
000070d6f3dda1b3  mov [r15+0xE8], r12
000070d6f3dda1ba  lea r14, [rax+0x100]
000070d6f3dda1c1  mov r12, [r13+r14*1]
000070d6f3dda1c6  lea r14, [rax+0x108]
000070d6f3dda1cd  mov r11, [r13+r14*1]
000070d6f3dda1d2  movq xmm1, r12
000070d6f3dda1d7  movq xmm15, r11
000070d6f3dda1dc  movq xmm1, xmm1
000070d6f3dda1e0  movq xmm1, xmm1
000070d6f3dda1e4  movaps [r15+0x1A0], xmm1
000070d6f3dda1ec  movq xmm15, xmm15
000070d6f3dda1f1  movq xmm15, xmm15
000070d6f3dda1f6  movaps [r15+0x190], xmm15
000070d6f3dda1fe  lea r14, [rax+0xF0]
000070d6f3dda205  mov r12, [r13+r14*1]
000070d6f3dda20a  lea r14, [rax+0xF8]
000070d6f3dda211  mov r11, [r13+r14*1]
000070d6f3dda216  movq xmm1, r12
000070d6f3dda21b  movq xmm15, r11
000070d6f3dda220  movq xmm1, xmm1
000070d6f3dda224  movq xmm1, xmm1
000070d6f3dda228  movaps [r15+0x1C0], xmm1
000070d6f3dda230  movq xmm15, xmm15
000070d6f3dda235  movq xmm15, xmm15
000070d6f3dda23a  movaps [r15+0x1B0], xmm15
000070d6f3dda242  lea r14, [rax+0xE0]
000070d6f3dda249  mov r12, [r13+r14*1]
000070d6f3dda24e  lea r14, [rax+0xE8]
000070d6f3dda255  mov r11, [r13+r14*1]
000070d6f3dda25a  movq xmm1, r12
000070d6f3dda25f  movq xmm15, r11
000070d6f3dda264  movq xmm1, xmm1
000070d6f3dda268  movq xmm1, xmm1
000070d6f3dda26c  movaps [r15+0x1E0], xmm1
000070d6f3dda274  movq xmm15, xmm15
000070d6f3dda279  movq xmm15, xmm15
000070d6f3dda27e  movaps [r15+0x1D0], xmm15
000070d6f3dda286  lea r14, [rax+0xD0]
000070d6f3dda28d  mov r12, [r13+r14*1]
000070d6f3dda292  lea r14, [rax+0xD8]
000070d6f3dda299  mov r11, [r13+r14*1]
000070d6f3dda29e  movq xmm1, r12
000070d6f3dda2a3  movq xmm15, r11
000070d6f3dda2a8  movq xmm1, xmm1
000070d6f3dda2ac  movq xmm1, xmm1
000070d6f3dda2b0  movaps [r15+0x200], xmm1
000070d6f3dda2b8  movq xmm15, xmm15
000070d6f3dda2bd  movq xmm15, xmm15
000070d6f3dda2c2  movaps [r15+0x1F0], xmm15
000070d6f3dda2ca  mov qword ptr [r15+0x40], 0x430000
000070d6f3dda2d2  mov r14d, 0x4304C0
000070d6f3dda2d8  mov r12, [r13+r14*1]
000070d6f3dda2dd  movq xmm1, r12
000070d6f3dda2e2  lea r14, [rax+0x120]
000070d6f3dda2e9  mov [r15+0xF8], r14
000070d6f3dda2f0  mov rax, [r15+0x50]
000070d6f3dda2f4  movups xmm15, [r13+rax*1]
000070d6f3dda2fa  movaps [r15+0x120], xmm15
000070d6f3dda302  mov qword ptr [r15+0x48], 0x10
000070d6f3dda30a  xor eax, eax
000070d6f3dda30c  mov r14d, 0x10
000070d6f3dda312  mov r12d, 0x200
000070d6f3dda318  cmp r14, r12
000070d6f3dda31b  cmc
000070d6f3dda31c  lahf
000070d6f3dda31d  seto al
000070d6f3dda320  mov [r15+0x108], eax
000070d6f3dda327  pextrq rax, xmm15, 0x01
000070d6f3dda32e  movq xmm14, rax
000070d6f3dda333  movaps [r15+0x130], xmm14
000070d6f3dda33b  movq rax, xmm1
000070d6f3dda340  movq r14, xmm15
000070d6f3dda345  vmovq xmm1, rax
000070d6f3dda34a  vmovq xmm15, r14
000070d6f3dda34f  movaps xmm13, xmm1
000070d6f3dda353  addsd xmm13, xmm15
000070d6f3dda358  ucomisd xmm13, xmm13
000070d6f3dda35d  jp 0x000070D6F3DDA476
000070d6f3dda363  movq xmm13, xmm13
000070d6f3dda368  movq rax, xmm13
000070d6f3dda36d  movq r14, xmm14
000070d6f3dda372  vmovq xmm1, rax
000070d6f3dda377  vmovq xmm15, r14
000070d6f3dda37c  movaps xmm14, xmm1
000070d6f3dda380  addsd xmm14, xmm15
000070d6f3dda385  ucomisd xmm14, xmm14
000070d6f3dda38a  jp 0x000070D6F3DDA4BE
000070d6f3dda390  movq xmm14, xmm14
000070d6f3dda395  movaps [r15+0x110], xmm14
000070d6f3dda39d  mov eax, [r15+0x108]
000070d6f3dda3a4  sahf
000070d6f3dda3a5  jnz 0x000070D6F3DDA3D7
000070d6f3dda3a7  cmp dword ptr [r15+0x318], 0x00
000070d6f3dda3af  jz 0x000070D6F3DDA6D0
000070d6f3dda3b5  nop [rax+rax*1], ax
000070d6f3dda3be  nop [rax+rax*1], eax
000070d6f3dda3c6  mov eax, 0x41043C
000070d6f3dda3cb  mov [r15+0x100], rax
000070d6f3dda3d2  jmp 0x000070D6F3BFE110
000070d6f3dda3d7  cmp dword ptr [r15+0x318], 0x00
000070d6f3dda3df  jz 0x000070D6F3DDA510
000070d6f3dda3e5  nop [rax+rax*1], ax
000070d6f3dda3ee  nop [rax+rax*1], eax
000070d6f3dda3f6  mov eax, 0x410420
000070d6f3dda3fb  mov [r15+0x100], rax
000070d6f3dda402  jmp 0x000070D6F3BFE110
000070d6f3dda407  int3
000070d6f3dda408  call 0x000070D6F3CE27E0
000070d6f3dda40d  jmp 0x000070D6F3DDA1B3
000070d6f3dda412  call 0x000070D6F3CE27E0
000070d6f3dda417  jmp 0x000070D6F3DDA1C6
000070d6f3dda41c  call 0x000070D6F3CE1570
000070d6f3dda421  jmp 0x000070D6F3DDA1D2
000070d6f3dda426  call 0x000070D6F3CE27E0
000070d6f3dda42b  jmp 0x000070D6F3DDA20A
000070d6f3dda430  call 0x000070D6F3CE1570
000070d6f3dda435  jmp 0x000070D6F3DDA216
000070d6f3dda43a  call 0x000070D6F3CE27E0
000070d6f3dda43f  jmp 0x000070D6F3DDA24E
000070d6f3dda444  call 0x000070D6F3CE1570
000070d6f3dda449  jmp 0x000070D6F3DDA25A
000070d6f3dda44e  call 0x000070D6F3CE27E0
000070d6f3dda453  jmp 0x000070D6F3DDA292
000070d6f3dda458  call 0x000070D6F3CE1570
000070d6f3dda45d  jmp 0x000070D6F3DDA29E
000070d6f3dda462  call 0x000070D6F3CE27E0
000070d6f3dda467  jmp 0x000070D6F3DDA2DD
000070d6f3dda46c  call 0x000070D6F3C0E760
000070d6f3dda471  jmp 0x000070D6F3DDA2FA
000070d6f3dda476  ucomisd xmm1, xmm15
000070d6f3dda47b  jp 0x000070D6F3DDA48A
000070d6f3dda47d  movaps xmm13, [0x000070D6F39FE060]
000070d6f3dda485  jmp 0x000070D6F3DDA363
000070d6f3dda48a  vxorps xmm0, xmm1, xmm15
000070d6f3dda48f  pextrw eax, xmm0, 0x03
000070d6f3dda494  and eax, 0x7FF8
000070d6f3dda499  cmp eax, 0x08
000070d6f3dda49c  jnz 0x000070D6F3DDA363
000070d6f3dda4a2  movq rax, xmm15
000070d6f3dda4a7  shl rax, 0x0D
000070d6f3dda4ab  jbe 0x000070D6F3DDA363
000070d6f3dda4b1  vorps xmm13, xmm15, [0x000070D6F39FE070]
000070d6f3dda4b9  jmp 0x000070D6F3DDA363
000070d6f3dda4be  ucomisd xmm1, xmm15
000070d6f3dda4c3  jp 0x000070D6F3DDA4D2
000070d6f3dda4c5  movaps xmm14, [0x000070D6F39FE060]
000070d6f3dda4cd  jmp 0x000070D6F3DDA390
000070d6f3dda4d2  vxorps xmm0, xmm1, xmm15
000070d6f3dda4d7  pextrw eax, xmm0, 0x03
000070d6f3dda4dc  and eax, 0x7FF8
000070d6f3dda4e1  cmp eax, 0x08
000070d6f3dda4e4  jnz 0x000070D6F3DDA390
000070d6f3dda4ea  movq rax, xmm15
000070d6f3dda4ef  shl rax, 0x0D
000070d6f3dda4f3  jbe 0x000070D6F3DDA390
000070d6f3dda4f9  vorps xmm14, xmm15, [0x000070D6F39FE070]
000070d6f3dda501  jmp 0x000070D6F3DDA390
000070d6f3dda506  int3
000070d6f3dda507  nop [rax+rax*1], ax
000070d6f3dda510  mov rax, [r15+0x48]
000070d6f3dda514  mov r14, [r15+0x50]
000070d6f3dda518  lea r12, [r14+rax*1]
000070d6f3dda51c  movups xmm1, [r13+r12*1]
000070d6f3dda522  movaps [r15+0x120], xmm1
000070d6f3dda52a  lea r14, [rax+0x10]
000070d6f3dda52e  mov [r15+0x48], r14
000070d6f3dda532  xor eax, eax
000070d6f3dda534  mov r12d, 0x200
000070d6f3dda53a  cmp r14, r12
000070d6f3dda53d  cmc
000070d6f3dda53e  lahf
000070d6f3dda53f  seto al
000070d6f3dda542  mov [r15+0x108], eax
000070d6f3dda549  pextrq rax, xmm1, 0x01
000070d6f3dda550  movq xmm15, rax
000070d6f3dda555  movaps [r15+0x130], xmm15
000070d6f3dda55d  movaps xmm14, [r15+0x110]
000070d6f3dda565  movq rax, xmm14
000070d6f3dda56a  movq r14, xmm1
000070d6f3dda56f  vmovq xmm1, rax
000070d6f3dda574  vmovq xmm14, r14
000070d6f3dda579  movaps xmm13, xmm1
000070d6f3dda57d  addsd xmm13, xmm14
000070d6f3dda582  ucomisd xmm13, xmm13
000070d6f3dda587  jp 0x000070D6F3DDA63C
000070d6f3dda58d  movq xmm13, xmm13
000070d6f3dda592  movq rax, xmm13
000070d6f3dda597  movq r14, xmm15
000070d6f3dda59c  vmovq xmm1, rax
000070d6f3dda5a1  vmovq xmm15, r14
000070d6f3dda5a6  movaps xmm14, xmm1
000070d6f3dda5aa  addsd xmm14, xmm15
000070d6f3dda5af  ucomisd xmm14, xmm14
000070d6f3dda5b4  jp 0x000070D6F3DDA684
000070d6f3dda5ba  movq xmm14, xmm14
000070d6f3dda5bf  movaps [r15+0x110], xmm14
000070d6f3dda5c7  mov eax, [r15+0x108]
000070d6f3dda5ce  sahf
000070d6f3dda5cf  jnz 0x000070D6F3DDA601
000070d6f3dda5d1  cmp dword ptr [r15+0x318], 0x00
000070d6f3dda5d9  jz 0x000070D6F3DDA6D0
000070d6f3dda5df  nop [rax+rax*1], ax
000070d6f3dda5e8  nop [rax+rax*1], eax
000070d6f3dda5f0  mov eax, 0x41043C
000070d6f3dda5f5  mov [r15+0x100], rax
000070d6f3dda5fc  jmp 0x000070D6F3BFE110
000070d6f3dda601  cmp dword ptr [r15+0x318], 0x00
000070d6f3dda609  jz 0x000070D6F3DDA510
000070d6f3dda60f  nop [rax+rax*1], ax
000070d6f3dda618  nop [rax+rax*1], eax
000070d6f3dda620  mov eax, 0x410420
000070d6f3dda625  mov [r15+0x100], rax
000070d6f3dda62c  jmp 0x000070D6F3BFE110
000070d6f3dda631  int3
000070d6f3dda632  call 0x000070D6F3CB52F0
000070d6f3dda637  jmp 0x000070D6F3DDA522
000070d6f3dda63c  ucomisd xmm1, xmm14
000070d6f3dda641  jp 0x000070D6F3DDA650
000070d6f3dda643  movaps xmm13, [0x000070D6F39FE060]
000070d6f3dda64b  jmp 0x000070D6F3DDA58D
000070d6f3dda650  vxorps xmm0, xmm1, xmm14
000070d6f3dda655  pextrw eax, xmm0, 0x03
000070d6f3dda65a  and eax, 0x7FF8
000070d6f3dda65f  cmp eax, 0x08
000070d6f3dda662  jnz 0x000070D6F3DDA58D
000070d6f3dda668  movq rax, xmm14
000070d6f3dda66d  shl rax, 0x0D
000070d6f3dda671  jbe 0x000070D6F3DDA58D
000070d6f3dda677  vorps xmm13, xmm14, [0x000070D6F39FE070]
000070d6f3dda67f  jmp 0x000070D6F3DDA58D
000070d6f3dda684  ucomisd xmm1, xmm15
000070d6f3dda689  jp 0x000070D6F3DDA698
000070d6f3dda68b  movaps xmm14, [0x000070D6F39FE060]
000070d6f3dda693  jmp 0x000070D6F3DDA5BA
000070d6f3dda698  vxorps xmm0, xmm1, xmm15
000070d6f3dda69d  pextrw eax, xmm0, 0x03
000070d6f3dda6a2  and eax, 0x7FF8
000070d6f3dda6a7  cmp eax, 0x08
000070d6f3dda6aa  jnz 0x000070D6F3DDA5BA
000070d6f3dda6b0  movq rax, xmm15
000070d6f3dda6b5  shl rax, 0x0D
000070d6f3dda6b9  jbe 0x000070D6F3DDA5BA
000070d6f3dda6bf  vorps xmm14, xmm15, [0x000070D6F39FE070]
000070d6f3dda6c7  jmp 0x000070D6F3DDA5BA
000070d6f3dda6cc  int3
000070d6f3dda6cd  nop [rax], eax
000070d6f3dda6d0  mov rax, [r15+0x40]
000070d6f3dda6d4  lea r14, [rax+0x4C0]
000070d6f3dda6db  movaps xmm1, [r15+0x110]
000070d6f3dda6e3  movq rax, xmm1
000070d6f3dda6e8  mov [r13+r14*1], rax
000070d6f3dda6ed  mov rax, [r15+0xF0]
000070d6f3dda6f4  mov [r15+0x100], rax
000070d6f3dda6fb  jmp 0x000070D6F3DCE5C0
000070d6f3dda700  int3
000070d6f3dda701  call 0x000070D6F3CD5EB0
000070d6f3dda706  jmp 0x000070D6F3DDA6ED
000070d6f3dda70b  int3
000070d6f3dda70c  nop [rax], eax
000070d6f3dda710  mov qword ptr [r15+0x100], 0x04
000070d6f3dda71b  mov esi, 0x00
000070d6f3dda720  mov edx, 0x09
000070d6f3dda725  mov rdi, 0x7FFCEBE48C50
000070d6f3dda72f  mov rax, 0x61D08D2A1970
000070d6f3dda739  call rax
000070d6f3dda73b  cmp dword ptr [r15+0x318], 0x00
000070d6f3dda743  jnz 0x000070D6F3BFE110
000070d6f3dda749  jmp 0x000070D6F3BFE0A0
000070d6f3dda74e  int3
000070d6f3dda74f  int3
