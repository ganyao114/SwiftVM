00007cf1505ce69b  nop [rax+rax*1], eax
00007cf1505ce6a0  mov qword ptr [r15+0x20], 0x420070
00007cf1505ce6a8  xor eax, eax
00007cf1505ce6aa  mov r14d, 0xB71B00
00007cf1505ce6b0  mov r12d, 0x01
00007cf1505ce6b6  sub r14, r12
00007cf1505ce6b9  cmc
00007cf1505ce6ba  lahf
00007cf1505ce6bb  seto al
00007cf1505ce6be  mov [r15+0x108], eax
00007cf1505ce6c5  mov [r15+0x08], r14
00007cf1505ce6c9  mov qword ptr [r15+0x10], 0x03
00007cf1505ce6d1  mov eax, 0x03
00007cf1505ce6d6  mov r14d, 0x03
00007cf1505ce6dc  shrd rax, r14, 0x0D
00007cf1505ce6e1  mov [rsp+0x10], rax
00007cf1505ce6e6  mov r14, [rsp+0x10]
00007cf1505ce6eb  shrd rax, r14, 0x33
00007cf1505ce6f0  mov [r15+0x18], rax
00007cf1505ce6f4  mov [r15], rax
00007cf1505ce6f7  mov eax, [r15+0x108]
00007cf1505ce6fe  sahf
00007cf1505ce6ff  jnz 0x00007CF1505CE731
00007cf1505ce701  cmp dword ptr [r15+0x318], 0x00
00007cf1505ce709  jz 0x00007CF1505CE860
00007cf1505ce70f  nop [rax+rax*1], ax
00007cf1505ce718  nop [rax+rax*1], eax
00007cf1505ce720  mov eax, 0x410064
00007cf1505ce725  mov [r15+0x100], rax
00007cf1505ce72c  jmp 0x00007CF1503FE110
00007cf1505ce731  cmp dword ptr [r15+0x318], 0x00
00007cf1505ce739  jz 0x00007CF1505CE770
00007cf1505ce73f  nop [rax+rax*1], ax
00007cf1505ce748  nop [rax+rax*1], eax
00007cf1505ce750  mov eax, 0x41003C
00007cf1505ce755  mov [r15+0x100], rax
00007cf1505ce75c  jmp 0x00007CF1503FE110
00007cf1505ce761  int3
00007cf1505ce762  int3
00007cf1505ce763  nop [rax+rax*1], ax
00007cf1505ce76c  nop [rax], eax
00007cf1505ce770  mov rax, [r15+0x08]
00007cf1505ce774  mov [rsp+0x10], rax
00007cf1505ce779  xor eax, eax
00007cf1505ce77b  mov r14, [rsp+0x10]
00007cf1505ce780  mov r12d, 0x01
00007cf1505ce786  sub r14, r12
00007cf1505ce789  cmc
00007cf1505ce78a  lahf
00007cf1505ce78b  seto al
00007cf1505ce78e  mov [r15+0x108], eax
00007cf1505ce795  mov [r15+0x08], r14
00007cf1505ce799  mov rax, [r15]
00007cf1505ce79c  lea r14, [rax+0x08]
00007cf1505ce7a0  lea rax, [r14-0x05]
00007cf1505ce7a4  mov [r15+0x10], rax
00007cf1505ce7a8  mov [rsp+0x10], rax
00007cf1505ce7ad  shr rax, 0x07
00007cf1505ce7b1  mov r14, [rsp+0x10]
00007cf1505ce7b6  xor r14, rax
00007cf1505ce7b9  mov rax, [rsp+0x10]
00007cf1505ce7be  shr rax, 0x07
00007cf1505ce7c2  xor r14, rax
00007cf1505ce7c5  mov [rsp+0x10], r14
00007cf1505ce7ca  mov rax, [rsp+0x10]
00007cf1505ce7cf  shrd r14, rax, 0x0D
00007cf1505ce7d4  mov [rsp+0x10], r14
00007cf1505ce7d9  mov rax, [rsp+0x10]
00007cf1505ce7de  shrd r14, rax, 0x33
00007cf1505ce7e3  mov [r15+0x18], r14
00007cf1505ce7e7  mov [r15], r14
00007cf1505ce7ea  mov eax, [r15+0x108]
00007cf1505ce7f1  sahf
00007cf1505ce7f2  jnz 0x00007CF1505CE824
00007cf1505ce7f4  cmp dword ptr [r15+0x318], 0x00
00007cf1505ce7fc  jz 0x00007CF1505CE860
00007cf1505ce802  nop [rax+rax*1], ax
00007cf1505ce80b  nop [rax+rax*1], eax
00007cf1505ce813  mov eax, 0x410064
00007cf1505ce818  mov [r15+0x100], rax
00007cf1505ce81f  jmp 0x00007CF1503FE110
00007cf1505ce824  cmp dword ptr [r15+0x318], 0x00
00007cf1505ce82c  jz 0x00007CF1505CE770
00007cf1505ce832  nop [rax+rax*1], ax
00007cf1505ce83b  nop [rax+rax*1], eax
00007cf1505ce843  mov eax, 0x41003C
00007cf1505ce848  mov [r15+0x100], rax
00007cf1505ce84f  jmp 0x00007CF1503FE110
00007cf1505ce854  int3
00007cf1505ce855  int3
00007cf1505ce856  nop [rax+rax*1], ax
00007cf1505ce85f  nop
00007cf1505ce860  mov rax, [r15+0x20]
00007cf1505ce864  mov r14, [r15]
00007cf1505ce867  mov [r13+rax*1], r14
00007cf1505ce86c  mov rax, [r15+0xF0]
00007cf1505ce873  mov [r15+0x100], rax
00007cf1505ce87a  jmp 0x00007CF1505CE5C0
00007cf1505ce87f  int3
00007cf1505ce880  call 0x00007CF15040E120
00007cf1505ce885  jmp 0x00007CF1505CE86C
00007cf1505ce88a  int3
00007cf1505ce88b  nop [rax+rax*1], eax
00007cf1505ce890  mov qword ptr [r15+0x100], 0x04
00007cf1505ce89b  mov esi, 0x00
00007cf1505ce8a0  mov edx, 0x09
00007cf1505ce8a5  mov rdi, 0x7FFDB5F467D0
00007cf1505ce8af  mov rax, 0x571DD858A970
00007cf1505ce8b9  call rax
00007cf1505ce8bb  cmp dword ptr [r15+0x318], 0x00
00007cf1505ce8c3  jnz 0x00007CF1503FE110
00007cf1505ce8c9  jmp 0x00007CF1503FE0A0
00007cf1505ce8ce  int3
00007cf1505ce8cf  int3
