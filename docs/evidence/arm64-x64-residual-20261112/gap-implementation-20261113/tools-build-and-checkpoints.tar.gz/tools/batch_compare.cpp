#include "tests/correctness/case.h"
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
using namespace swift::tests::correctness;
int main(int argc,char** argv) {
 if(argc!=5)return 2;
 try {
  std::vector<std::filesystem::path> files;
  for(const auto& f:std::filesystem::directory_iterator(argv[1]))if(f.path().extension()==".svmcase")files.push_back(f.path());
  std::sort(files.begin(),files.end());std::map<std::string,unsigned> counts;unsigned native=0,failed=0;
  std::ofstream records(argv[4]);
  for(const auto& path:files){
   const auto name=path.stem().string()+".json";
   const auto c=ReadCase(path.string());
   const auto expected=ReadObservation((std::filesystem::path(argv[2])/name).string());
   const auto actual=ReadObservation((std::filesystem::path(argv[3])/name).string());
   const auto comparison=Compare(c,expected,actual);
   ++counts[comparison.category];native+=actual.native_executed;
   failed+=comparison.category!="agreement" || !actual.native_executed;
   records<<"{\"case\":"<<std::quoted(path.filename().string())<<",\"native_executed\":"<<(actual.native_executed?"true":"false")<<",\"comparison\":"<<ToJSON(comparison)<<"}\n";
  }
  std::cout<<"{\"total\":"<<files.size()<<",\"native_executed\":"<<native<<",\"failures\":"<<failed<<",\"counts\":{";
  bool first=true;for(const auto& [key,value]:counts){if(!first)std::cout<<',';first=false;std::cout<<std::quoted(key)<<':'<<value;}
  std::cout<<"}}\n";return failed?1:0;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}
}
