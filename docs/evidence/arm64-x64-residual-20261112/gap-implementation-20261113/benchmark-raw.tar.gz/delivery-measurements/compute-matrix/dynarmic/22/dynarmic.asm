000079bd661ce69b  nop [rax+rax*1], eax
000079bd661ce6a0  vmovaps xmm1, [0x000079BD65DFE010]
000079bd661ce6a8  movq xmm1, xmm1
000079bd661ce6ac  movaps [r15+0x110], xmm1
000079bd661ce6b4  vmovaps xmm1, [0x000079BD65DFE020]
000079bd661ce6bc  movq xmm1, xmm1
000079bd661ce6c0  movaps [r15+0x120], xmm1
000079bd661ce6c8  mov eax, 0x4204C0
000079bd661ce6cd  mov r14, [r13+rax*1]
000079bd661ce6d2  movq xmm1, r14
000079bd661ce6d7  movaps [r15+0x130], xmm1
000079bd661ce6df  vmovaps xmm1, [0x000079BD65DFE030]
000079bd661ce6e7  vpbroadcastq xmm1, xmm1
000079bd661ce6ec  movaps [r15+0x140], xmm1
000079bd661ce6f4  mov qword ptr [r15+0x40], 0x02
000079bd661ce6fc  vmovaps xmm15, [0x000079BD65DFE040]
000079bd661ce704  movq xmm15, xmm15
000079bd661ce709  movaps [r15+0x150], xmm15
000079bd661ce711  mov qword ptr [r15+0x58], 0x420000
000079bd661ce719  vmovaps xmm15, [0x000079BD65DFE050]
000079bd661ce721  vpbroadcastq xmm15, xmm15
000079bd661ce726  movaps [r15+0x160], xmm15
000079bd661ce72e  mov rax, [r15+0x40]
000079bd661ce732  vmovq xmm14, rax
000079bd661ce737  vpbroadcastq xmm14, xmm14
000079bd661ce73c  movaps [r15+0x170], xmm14
000079bd661ce744  mov eax, 0x4204D0
000079bd661ce749  movups xmm13, [r13+rax*1]
000079bd661ce74f  mov qword ptr [r15+0x40], 0x430518
000079bd661ce757  mov qword ptr [r15+0x50], 0x430720
000079bd661ce75f  vpmovqd xmm12, xmm13
000079bd661ce765  pxor xmm11, xmm11
000079bd661ce76a  punpcklqdq xmm12, xmm11
000079bd661ce76f  movaps [r15+0x210], xmm12
000079bd661ce777  movq xmm12, qword ptr [r15+0x120]
000079bd661ce780  movq xmm11, qword ptr [r15+0x130]
000079bd661ce789  psubd xmm12, xmm11
000079bd661ce78e  movq xmm12, xmm12
000079bd661ce793  paddq xmm13, xmm14
000079bd661ce798  movaps [r15+0x180], xmm13
000079bd661ce7a0  movq xmm14, qword ptr [r15+0x150]
000079bd661ce7a9  paddd xmm11, xmm14
000079bd661ce7ae  movq xmm11, xmm11
000079bd661ce7b3  movq xmm11, xmm11
000079bd661ce7b8  movaps [r15+0x130], xmm11
000079bd661ce7c0  pmovzxdq xmm12, xmm12
000079bd661ce7c6  psllq xmm12, 0x00
000079bd661ce7cc  movq xmm14, qword ptr [r15+0x210]
000079bd661ce7d5  movq xmm13, qword ptr [r15+0x110]
000079bd661ce7de  paddd xmm14, xmm13
000079bd661ce7e3  movq xmm14, xmm14
000079bd661ce7e8  vcvtuqq2pd xmm12, xmm12
000079bd661ce7ee  pmovzxdq xmm14, xmm14
000079bd661ce7f4  psllq xmm14, 0x00
000079bd661ce7fa  vcvtuqq2pd xmm14, xmm14
000079bd661ce800  movaps xmm13, xmm12
000079bd661ce804  mulpd xmm13, xmm1
000079bd661ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000079bd661ce80f  ptest xmm11, xmm11
000079bd661ce815  jnz 0x000079BD661CE8FF
000079bd661ce81b  movaps [r15+0x220], xmm13
000079bd661ce823  mov eax, 0x430720
000079bd661ce828  movups [r13+rax*1], xmm13
000079bd661ce82e  movaps xmm1, xmm14
000079bd661ce832  mulpd xmm1, xmm15
000079bd661ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000079bd661ce83c  ptest xmm13, xmm13
000079bd661ce842  jnz 0x000079BD661CEA4C
000079bd661ce848  movaps [r15+0x210], xmm1
000079bd661ce850  mov eax, 0x430518
000079bd661ce855  movups [r13+rax*1], xmm1
000079bd661ce85b  mov qword ptr [r15+0x48], 0x10
000079bd661ce863  xor eax, eax
000079bd661ce865  mov r14d, 0x10
000079bd661ce86b  mov r12d, 0x200
000079bd661ce871  cmp r14, r12
000079bd661ce874  cmc
000079bd661ce875  lahf
000079bd661ce876  seto al
000079bd661ce879  mov [r15+0x108], eax
000079bd661ce880  mov eax, [r15+0x108]
000079bd661ce887  sahf
000079bd661ce888  jnz 0x000079BD661CE8BA
000079bd661ce88a  cmp dword ptr [r15+0x318], 0x00
000079bd661ce892  jz 0x000079BD661CEFF0
000079bd661ce898  nop [rax+rax*1], ax
000079bd661ce8a1  nop [rax+rax*1], eax
000079bd661ce8a9  mov eax, 0x4101EC
000079bd661ce8ae  mov [r15+0x100], rax
000079bd661ce8b5  jmp 0x000079BD65FFE110
000079bd661ce8ba  cmp dword ptr [r15+0x318], 0x00
000079bd661ce8c2  jz 0x000079BD661CEBA0
000079bd661ce8c8  nop [rax+rax*1], ax
000079bd661ce8d1  nop [rax+rax*1], eax
000079bd661ce8d9  mov eax, 0x4101AC
000079bd661ce8de  mov [r15+0x100], rax
000079bd661ce8e5  jmp 0x000079BD65FFE110
000079bd661ce8ea  int3
000079bd661ce8eb  call 0x000079BD6600DC20
000079bd661ce8f0  jmp 0x000079BD661CE6D2
000079bd661ce8f5  call 0x000079BD6600C260
000079bd661ce8fa  jmp 0x000079BD661CE74F
000079bd661ce8ff  sub rsp, 0x08
000079bd661ce903  push rax
000079bd661ce904  push rcx
000079bd661ce905  push rdx
000079bd661ce906  push rdi
000079bd661ce907  push rsi
000079bd661ce908  push r8
000079bd661ce90a  push r9
000079bd661ce90c  push r10
000079bd661ce90e  push r11
000079bd661ce910  sub rsp, 0xF0
000079bd661ce917  vmovaps [rsp], xmm0
000079bd661ce91c  vmovaps [rsp+0x10], xmm1
000079bd661ce922  vmovaps [rsp+0x20], xmm2
000079bd661ce928  vmovaps [rsp+0x30], xmm3
000079bd661ce92e  vmovaps [rsp+0x40], xmm4
000079bd661ce934  vmovaps [rsp+0x50], xmm5
000079bd661ce93a  vmovaps [rsp+0x60], xmm6
000079bd661ce940  vmovaps [rsp+0x70], xmm7
000079bd661ce946  vmovaps [rsp+0x80], xmm8
000079bd661ce94f  vmovaps [rsp+0x90], xmm9
000079bd661ce958  vmovaps [rsp+0xA0], xmm10
000079bd661ce961  vmovaps [rsp+0xB0], xmm11
000079bd661ce96a  vmovaps [rsp+0xC0], xmm12
000079bd661ce973  vmovaps [rsp+0xD0], xmm14
000079bd661ce97c  vmovaps [rsp+0xE0], xmm15
000079bd661ce985  sub rsp, 0x30
000079bd661ce989  movaps [rsp], xmm13
000079bd661ce98e  movaps [rsp+0x10], xmm12
000079bd661ce994  movaps [rsp+0x20], xmm1
000079bd661ce999  lea rdi, [rsp]
000079bd661ce99d  mov esi, 0x00
000079bd661ce9a2  mov rax, 0x56EBD57B0530
000079bd661ce9ac  call rax
000079bd661ce9ae  movaps xmm13, [rsp]
000079bd661ce9b3  add rsp, 0x30
000079bd661ce9b7  vmovaps xmm0, [rsp]
000079bd661ce9bc  vmovaps xmm1, [rsp+0x10]
000079bd661ce9c2  vmovaps xmm2, [rsp+0x20]
000079bd661ce9c8  vmovaps xmm3, [rsp+0x30]
000079bd661ce9ce  vmovaps xmm4, [rsp+0x40]
000079bd661ce9d4  vmovaps xmm5, [rsp+0x50]
000079bd661ce9da  vmovaps xmm6, [rsp+0x60]
000079bd661ce9e0  vmovaps xmm7, [rsp+0x70]
000079bd661ce9e6  vmovaps xmm8, [rsp+0x80]
000079bd661ce9ef  vmovaps xmm9, [rsp+0x90]
000079bd661ce9f8  vmovaps xmm10, [rsp+0xA0]
000079bd661cea01  vmovaps xmm11, [rsp+0xB0]
000079bd661cea0a  vmovaps xmm12, [rsp+0xC0]
000079bd661cea13  vmovaps xmm14, [rsp+0xD0]
000079bd661cea1c  vmovaps xmm15, [rsp+0xE0]
000079bd661cea25  add rsp, 0xF0
000079bd661cea2c  pop r11
000079bd661cea2e  pop r10
000079bd661cea30  pop r9
000079bd661cea32  pop r8
000079bd661cea34  pop rsi
000079bd661cea35  pop rdi
000079bd661cea36  pop rdx
000079bd661cea37  pop rcx
000079bd661cea38  pop rax
000079bd661cea39  add rsp, 0x08
000079bd661cea3d  jmp 0x000079BD661CE81B
000079bd661cea42  call 0x000079BD6600C380
000079bd661cea47  jmp 0x000079BD661CE82E
000079bd661cea4c  sub rsp, 0x08
000079bd661cea50  push rax
000079bd661cea51  push rcx
000079bd661cea52  push rdx
000079bd661cea53  push rdi
000079bd661cea54  push rsi
000079bd661cea55  push r8
000079bd661cea57  push r9
000079bd661cea59  push r10
000079bd661cea5b  push r11
000079bd661cea5d  sub rsp, 0xF0
000079bd661cea64  vmovaps [rsp], xmm0
000079bd661cea69  vmovaps [rsp+0x10], xmm2
000079bd661cea6f  vmovaps [rsp+0x20], xmm3
000079bd661cea75  vmovaps [rsp+0x30], xmm4
000079bd661cea7b  vmovaps [rsp+0x40], xmm5
000079bd661cea81  vmovaps [rsp+0x50], xmm6
000079bd661cea87  vmovaps [rsp+0x60], xmm7
000079bd661cea8d  vmovaps [rsp+0x70], xmm8
000079bd661cea93  vmovaps [rsp+0x80], xmm9
000079bd661cea9c  vmovaps [rsp+0x90], xmm10
000079bd661ceaa5  vmovaps [rsp+0xA0], xmm11
000079bd661ceaae  vmovaps [rsp+0xB0], xmm12
000079bd661ceab7  vmovaps [rsp+0xC0], xmm13
000079bd661ceac0  vmovaps [rsp+0xD0], xmm14
000079bd661ceac9  vmovaps [rsp+0xE0], xmm15
000079bd661cead2  sub rsp, 0x30
000079bd661cead6  movaps [rsp], xmm1
000079bd661ceada  movaps [rsp+0x10], xmm14
000079bd661ceae0  movaps [rsp+0x20], xmm15
000079bd661ceae6  lea rdi, [rsp]
000079bd661ceaea  mov esi, 0x00
000079bd661ceaef  mov rax, 0x56EBD57B0530
000079bd661ceaf9  call rax
000079bd661ceafb  movaps xmm1, [rsp]
000079bd661ceaff  add rsp, 0x30
000079bd661ceb03  vmovaps xmm0, [rsp]
000079bd661ceb08  vmovaps xmm2, [rsp+0x10]
000079bd661ceb0e  vmovaps xmm3, [rsp+0x20]
000079bd661ceb14  vmovaps xmm4, [rsp+0x30]
000079bd661ceb1a  vmovaps xmm5, [rsp+0x40]
000079bd661ceb20  vmovaps xmm6, [rsp+0x50]
000079bd661ceb26  vmovaps xmm7, [rsp+0x60]
000079bd661ceb2c  vmovaps xmm8, [rsp+0x70]
000079bd661ceb32  vmovaps xmm9, [rsp+0x80]
000079bd661ceb3b  vmovaps xmm10, [rsp+0x90]
000079bd661ceb44  vmovaps xmm11, [rsp+0xA0]
000079bd661ceb4d  vmovaps xmm12, [rsp+0xB0]
000079bd661ceb56  vmovaps xmm13, [rsp+0xC0]
000079bd661ceb5f  vmovaps xmm14, [rsp+0xD0]
000079bd661ceb68  vmovaps xmm15, [rsp+0xE0]
000079bd661ceb71  add rsp, 0xF0
000079bd661ceb78  pop r11
000079bd661ceb7a  pop r10
000079bd661ceb7c  pop r9
000079bd661ceb7e  pop r8
000079bd661ceb80  pop rsi
000079bd661ceb81  pop rdi
000079bd661ceb82  pop rdx
000079bd661ceb83  pop rcx
000079bd661ceb84  pop rax
000079bd661ceb85  add rsp, 0x08
000079bd661ceb89  jmp 0x000079BD661CE848
000079bd661ceb8e  call 0x000079BD65FFF540
000079bd661ceb93  jmp 0x000079BD661CE85B
000079bd661ceb98  int3
000079bd661ceb99  nop [rax], eax
000079bd661ceba0  movaps xmm1, [r15+0x180]
000079bd661ceba8  vpmovqd xmm15, xmm1
000079bd661cebae  pxor xmm14, xmm14
000079bd661cebb3  punpcklqdq xmm15, xmm14
000079bd661cebb8  movaps [r15+0x210], xmm15
000079bd661cebc0  movq xmm15, qword ptr [r15+0x120]
000079bd661cebc9  movq xmm14, qword ptr [r15+0x130]
000079bd661cebd2  psubd xmm15, xmm14
000079bd661cebd7  movq xmm15, xmm15
000079bd661cebdc  movaps xmm13, [r15+0x170]
000079bd661cebe4  paddq xmm1, xmm13
000079bd661cebe9  movaps [r15+0x180], xmm1
000079bd661cebf1  movq xmm1, qword ptr [r15+0x150]
000079bd661cebfa  paddd xmm14, xmm1
000079bd661cebff  movq xmm14, xmm14
000079bd661cec04  movq xmm14, xmm14
000079bd661cec09  movaps [r15+0x130], xmm14
000079bd661cec11  pmovzxdq xmm15, xmm15
000079bd661cec17  psllq xmm15, 0x00
000079bd661cec1d  movq xmm1, qword ptr [r15+0x210]
000079bd661cec26  movq xmm14, qword ptr [r15+0x110]
000079bd661cec2f  paddd xmm1, xmm14
000079bd661cec34  movq xmm1, xmm1
000079bd661cec38  vcvtuqq2pd xmm15, xmm15
000079bd661cec3e  pmovzxdq xmm1, xmm1
000079bd661cec43  psllq xmm1, 0x00
000079bd661cec48  vcvtuqq2pd xmm1, xmm1
000079bd661cec4e  movaps xmm14, [r15+0x140]
000079bd661cec56  movaps xmm13, xmm15
000079bd661cec5a  mulpd xmm13, xmm14
000079bd661cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000079bd661cec65  ptest xmm12, xmm12
000079bd661cec6b  jnz 0x000079BD661CED4E
000079bd661cec71  movaps [r15+0x220], xmm13
000079bd661cec79  mov rax, [r15+0x48]
000079bd661cec7d  mov r14, [r15+0x50]
000079bd661cec81  lea r12, [r14+rax*1]
000079bd661cec85  movups [r13+r12*1], xmm13
000079bd661cec8b  movaps xmm15, [r15+0x160]
000079bd661cec93  movaps xmm14, xmm1
000079bd661cec97  mulpd xmm14, xmm15
000079bd661cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000079bd661ceca2  ptest xmm13, xmm13
000079bd661ceca8  jnz 0x000079BD661CEE9C
000079bd661cecae  movaps [r15+0x210], xmm14
000079bd661cecb6  mov r14, [r15+0x40]
000079bd661cecba  lea r12, [r14+rax*1]
000079bd661cecbe  movups [r13+r12*1], xmm14
000079bd661cecc4  lea r14, [rax+0x10]
000079bd661cecc8  mov [r15+0x48], r14
000079bd661ceccc  xor eax, eax
000079bd661cecce  mov r12d, 0x200
000079bd661cecd4  cmp r14, r12
000079bd661cecd7  cmc
000079bd661cecd8  lahf
000079bd661cecd9  seto al
000079bd661cecdc  mov [r15+0x108], eax
000079bd661cece3  mov eax, [r15+0x108]
000079bd661cecea  sahf
000079bd661ceceb  jnz 0x000079BD661CED1D
000079bd661ceced  cmp dword ptr [r15+0x318], 0x00
000079bd661cecf5  jz 0x000079BD661CEFF0
000079bd661cecfb  nop [rax+rax*1], ax
000079bd661ced04  nop [rax+rax*1], eax
000079bd661ced0c  mov eax, 0x4101EC
000079bd661ced11  mov [r15+0x100], rax
000079bd661ced18  jmp 0x000079BD65FFE110
000079bd661ced1d  cmp dword ptr [r15+0x318], 0x00
000079bd661ced25  jz 0x000079BD661CEBA0
000079bd661ced2b  nop [rax+rax*1], ax
000079bd661ced34  nop [rax+rax*1], eax
000079bd661ced3c  mov eax, 0x4101AC
000079bd661ced41  mov [r15+0x100], rax
000079bd661ced48  jmp 0x000079BD65FFE110
000079bd661ced4d  int3
000079bd661ced4e  sub rsp, 0x08
000079bd661ced52  push rax
000079bd661ced53  push rcx
000079bd661ced54  push rdx
000079bd661ced55  push rdi
000079bd661ced56  push rsi
000079bd661ced57  push r8
000079bd661ced59  push r9
000079bd661ced5b  push r10
000079bd661ced5d  push r11
000079bd661ced5f  sub rsp, 0xF0
000079bd661ced66  vmovaps [rsp], xmm0
000079bd661ced6b  vmovaps [rsp+0x10], xmm1
000079bd661ced71  vmovaps [rsp+0x20], xmm2
000079bd661ced77  vmovaps [rsp+0x30], xmm3
000079bd661ced7d  vmovaps [rsp+0x40], xmm4
000079bd661ced83  vmovaps [rsp+0x50], xmm5
000079bd661ced89  vmovaps [rsp+0x60], xmm6
000079bd661ced8f  vmovaps [rsp+0x70], xmm7
000079bd661ced95  vmovaps [rsp+0x80], xmm8
000079bd661ced9e  vmovaps [rsp+0x90], xmm9
000079bd661ceda7  vmovaps [rsp+0xA0], xmm10
000079bd661cedb0  vmovaps [rsp+0xB0], xmm11
000079bd661cedb9  vmovaps [rsp+0xC0], xmm12
000079bd661cedc2  vmovaps [rsp+0xD0], xmm14
000079bd661cedcb  vmovaps [rsp+0xE0], xmm15
000079bd661cedd4  sub rsp, 0x30
000079bd661cedd8  movaps [rsp], xmm13
000079bd661ceddd  movaps [rsp+0x10], xmm15
000079bd661cede3  movaps [rsp+0x20], xmm14
000079bd661cede9  lea rdi, [rsp]
000079bd661ceded  mov esi, 0x00
000079bd661cedf2  mov rax, 0x56EBD57B0530
000079bd661cedfc  call rax
000079bd661cedfe  movaps xmm13, [rsp]
000079bd661cee03  add rsp, 0x30
000079bd661cee07  vmovaps xmm0, [rsp]
000079bd661cee0c  vmovaps xmm1, [rsp+0x10]
000079bd661cee12  vmovaps xmm2, [rsp+0x20]
000079bd661cee18  vmovaps xmm3, [rsp+0x30]
000079bd661cee1e  vmovaps xmm4, [rsp+0x40]
000079bd661cee24  vmovaps xmm5, [rsp+0x50]
000079bd661cee2a  vmovaps xmm6, [rsp+0x60]
000079bd661cee30  vmovaps xmm7, [rsp+0x70]
000079bd661cee36  vmovaps xmm8, [rsp+0x80]
000079bd661cee3f  vmovaps xmm9, [rsp+0x90]
000079bd661cee48  vmovaps xmm10, [rsp+0xA0]
000079bd661cee51  vmovaps xmm11, [rsp+0xB0]
000079bd661cee5a  vmovaps xmm12, [rsp+0xC0]
000079bd661cee63  vmovaps xmm14, [rsp+0xD0]
000079bd661cee6c  vmovaps xmm15, [rsp+0xE0]
000079bd661cee75  add rsp, 0xF0
000079bd661cee7c  pop r11
000079bd661cee7e  pop r10
000079bd661cee80  pop r9
000079bd661cee82  pop r8
000079bd661cee84  pop rsi
000079bd661cee85  pop rdi
000079bd661cee86  pop rdx
000079bd661cee87  pop rcx
000079bd661cee88  pop rax
000079bd661cee89  add rsp, 0x08
000079bd661cee8d  jmp 0x000079BD661CEC71
000079bd661cee92  call 0x000079BD660C2240
000079bd661cee97  jmp 0x000079BD661CEC8B
000079bd661cee9c  sub rsp, 0x08
000079bd661ceea0  push rax
000079bd661ceea1  push rcx
000079bd661ceea2  push rdx
000079bd661ceea3  push rdi
000079bd661ceea4  push rsi
000079bd661ceea5  push r8
000079bd661ceea7  push r9
000079bd661ceea9  push r10
000079bd661ceeab  push r11
000079bd661ceead  sub rsp, 0xF0
000079bd661ceeb4  vmovaps [rsp], xmm0
000079bd661ceeb9  vmovaps [rsp+0x10], xmm1
000079bd661ceebf  vmovaps [rsp+0x20], xmm2
000079bd661ceec5  vmovaps [rsp+0x30], xmm3
000079bd661ceecb  vmovaps [rsp+0x40], xmm4
000079bd661ceed1  vmovaps [rsp+0x50], xmm5
000079bd661ceed7  vmovaps [rsp+0x60], xmm6
000079bd661ceedd  vmovaps [rsp+0x70], xmm7
000079bd661ceee3  vmovaps [rsp+0x80], xmm8
000079bd661ceeec  vmovaps [rsp+0x90], xmm9
000079bd661ceef5  vmovaps [rsp+0xA0], xmm10
000079bd661ceefe  vmovaps [rsp+0xB0], xmm11
000079bd661cef07  vmovaps [rsp+0xC0], xmm12
000079bd661cef10  vmovaps [rsp+0xD0], xmm13
000079bd661cef19  vmovaps [rsp+0xE0], xmm15
000079bd661cef22  sub rsp, 0x30
000079bd661cef26  movaps [rsp], xmm14
000079bd661cef2b  movaps [rsp+0x10], xmm1
000079bd661cef30  movaps [rsp+0x20], xmm15
000079bd661cef36  lea rdi, [rsp]
000079bd661cef3a  mov esi, 0x00
000079bd661cef3f  mov rax, 0x56EBD57B0530
000079bd661cef49  call rax
000079bd661cef4b  movaps xmm14, [rsp]
000079bd661cef50  add rsp, 0x30
000079bd661cef54  vmovaps xmm0, [rsp]
000079bd661cef59  vmovaps xmm1, [rsp+0x10]
000079bd661cef5f  vmovaps xmm2, [rsp+0x20]
000079bd661cef65  vmovaps xmm3, [rsp+0x30]
000079bd661cef6b  vmovaps xmm4, [rsp+0x40]
000079bd661cef71  vmovaps xmm5, [rsp+0x50]
000079bd661cef77  vmovaps xmm6, [rsp+0x60]
000079bd661cef7d  vmovaps xmm7, [rsp+0x70]
000079bd661cef83  vmovaps xmm8, [rsp+0x80]
000079bd661cef8c  vmovaps xmm9, [rsp+0x90]
000079bd661cef95  vmovaps xmm10, [rsp+0xA0]
000079bd661cef9e  vmovaps xmm11, [rsp+0xB0]
000079bd661cefa7  vmovaps xmm12, [rsp+0xC0]
000079bd661cefb0  vmovaps xmm13, [rsp+0xD0]
000079bd661cefb9  vmovaps xmm15, [rsp+0xE0]
000079bd661cefc2  add rsp, 0xF0
000079bd661cefc9  pop r11
000079bd661cefcb  pop r10
000079bd661cefcd  pop r9
000079bd661cefcf  pop r8
000079bd661cefd1  pop rsi
000079bd661cefd2  pop rdi
000079bd661cefd3  pop rdx
000079bd661cefd4  pop rcx
000079bd661cefd5  pop rax
000079bd661cefd6  add rsp, 0x08
000079bd661cefda  jmp 0x000079BD661CECAE
000079bd661cefdf  call 0x000079BD660C34C0
000079bd661cefe4  jmp 0x000079BD661CECC4
000079bd661cefe9  int3
000079bd661cefea  nop [rax+rax*1], ax
000079bd661ceff0  mov rax, [r15+0xF8]
000079bd661ceff7  lea r14, [rax-0x150]
000079bd661ceffe  mov [r15+0xF8], r14
000079bd661cf005  mov rax, [r15+0x50]
000079bd661cf009  lea r12, [rax+0x80]
000079bd661cf010  movups xmm1, [r13+r12*1]
000079bd661cf016  lea r12, [rax+0x90]
000079bd661cf01d  movups xmm15, [r13+r12*1]
000079bd661cf023  mov qword ptr [r15+0x48], 0x00
000079bd661cf02b  lea r12, [rax+0x40]
000079bd661cf02f  movups xmm14, [r13+r12*1]
000079bd661cf035  lea r12, [rax+0x50]
000079bd661cf039  movups xmm13, [r13+r12*1]
000079bd661cf03f  lea r12, [r14+0x120]
000079bd661cf046  movq xmm12, qword ptr [r15+0x1C0]
000079bd661cf04f  movq xmm11, qword ptr [r15+0x1B0]
000079bd661cf058  movq r11, xmm12
000079bd661cf05d  movq r10, xmm11
000079bd661cf062  mov [r13+r12*1], r11
000079bd661cf067  lea r12, [r14+0x128]
000079bd661cf06e  mov [r13+r12*1], r10
000079bd661cf073  vxorps xmm12, xmm12, xmm12
000079bd661cf078  vpbroadcastq xmm12, xmm12
000079bd661cf07d  lea r12, [r14+0x100]
000079bd661cf084  movq xmm11, qword ptr [r15+0x200]
000079bd661cf08d  movq xmm10, qword ptr [r15+0x1F0]
000079bd661cf096  movq r11, xmm11
000079bd661cf09b  movq r10, xmm10
000079bd661cf0a0  mov [r13+r12*1], r11
000079bd661cf0a5  lea r12, [r14+0x108]
000079bd661cf0ac  mov [r13+r12*1], r10
000079bd661cf0b1  lea r12, [r14+0xE0]
000079bd661cf0b8  movups [r13+r12*1], xmm15
000079bd661cf0be  lea r12, [r14+0xF0]
000079bd661cf0c5  movups [r13+r12*1], xmm1
000079bd661cf0cb  lea r12, [rax+0xC0]
000079bd661cf0d2  movups xmm1, [r13+r12*1]
000079bd661cf0d8  lea r12, [rax+0xD0]
000079bd661cf0df  movups xmm15, [r13+r12*1]
000079bd661cf0e5  lea r12, [r14+0x110]
000079bd661cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000079bd661cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000079bd661cf0fe  movq r11, xmm11
000079bd661cf103  movq r10, xmm10
000079bd661cf108  mov [r13+r12*1], r11
000079bd661cf10d  lea r12, [r14+0x118]
000079bd661cf114  mov [r13+r12*1], r10
000079bd661cf119  movups xmm11, [r13+rax*1]
000079bd661cf11f  lea r12, [rax+0x10]
000079bd661cf123  movups xmm10, [r13+r12*1]
000079bd661cf129  lea r12, [r14+0x130]
000079bd661cf130  movq xmm9, qword ptr [r15+0x1A0]
000079bd661cf139  movq xmm8, qword ptr [r15+0x190]
000079bd661cf142  movq r11, xmm9
000079bd661cf147  movq r10, xmm8
000079bd661cf14c  mov [r13+r12*1], r11
000079bd661cf151  lea r12, [r14+0x138]
000079bd661cf158  mov [r13+r12*1], r10
000079bd661cf15d  lea r12, [rax+0x140]
000079bd661cf164  movups xmm9, [r13+r12*1]
000079bd661cf16a  lea r12, [rax+0x150]
000079bd661cf171  movups xmm8, [r13+r12*1]
000079bd661cf177  lea r12, [r14+0xC0]
000079bd661cf17e  movups [r13+r12*1], xmm15
000079bd661cf184  lea r12, [r14+0xD0]
000079bd661cf18b  movups [r13+r12*1], xmm1
000079bd661cf191  lea r12, [rax+0x100]
000079bd661cf198  movups xmm1, [r13+r12*1]
000079bd661cf19e  lea r12, [rax+0x110]
000079bd661cf1a5  movups xmm15, [r13+r12*1]
000079bd661cf1ab  lea r12, [r14+0x140]
000079bd661cf1b2  mov r11, [r15+0xE8]
000079bd661cf1b9  mov [r13+r12*1], r11
000079bd661cf1be  lea r12, [rax+0x180]
000079bd661cf1c5  movups xmm7, [r13+r12*1]
000079bd661cf1cb  lea r12, [rax+0x190]
000079bd661cf1d2  movups xmm6, [r13+r12*1]
000079bd661cf1d8  lea r12, [rax+0x1C0]
000079bd661cf1df  movups xmm5, [r13+r12*1]
000079bd661cf1e5  lea r12, [rax+0x1D0]
000079bd661cf1ec  movups xmm4, [r13+r12*1]
000079bd661cf1f2  lea r12, [r14+0x20]
000079bd661cf1f6  movups [r13+r12*1], xmm1
000079bd661cf1fc  lea r12, [r14+0x30]
000079bd661cf200  movups [r13+r12*1], xmm13
000079bd661cf206  lea r12, [rax+0x60]
000079bd661cf20a  movups xmm1, [r13+r12*1]
000079bd661cf210  lea r12, [rax+0x70]
000079bd661cf214  movups xmm13, [r13+r12*1]
000079bd661cf21a  lea r12, [rax+0x20]
000079bd661cf21e  movups xmm3, [r13+r12*1]
000079bd661cf224  lea r12, [rax+0x30]
000079bd661cf228  movups xmm2, [r13+r12*1]
000079bd661cf22e  movaps [r15+0x1F0], xmm2
000079bd661cf236  lea r12, [r14+0x60]
000079bd661cf23a  movups [r13+r12*1], xmm11
000079bd661cf240  lea r12, [r14+0x70]
000079bd661cf244  movups [r13+r12*1], xmm5
000079bd661cf24a  lea r12, [rax+0xE0]
000079bd661cf251  movups xmm11, [r13+r12*1]
000079bd661cf257  lea r12, [rax+0xF0]
000079bd661cf25e  movups xmm5, [r13+r12*1]
000079bd661cf264  lea r12, [r14+0xA0]
000079bd661cf26b  movups [r13+r12*1], xmm13
000079bd661cf271  lea r12, [r14+0xB0]
000079bd661cf278  movups [r13+r12*1], xmm1
000079bd661cf27e  lea r12, [rax+0xA0]
000079bd661cf285  movups xmm1, [r13+r12*1]
000079bd661cf28b  lea r12, [rax+0xB0]
000079bd661cf292  movups xmm13, [r13+r12*1]
000079bd661cf298  lea r12, [rax+0x120]
000079bd661cf29f  vmovaps [rsp+0x10], xmm1
000079bd661cf2a5  movups xmm1, [r13+r12*1]
000079bd661cf2ab  lea r12, [rax+0x130]
000079bd661cf2b2  vmovaps [rsp+0x20], xmm1
000079bd661cf2b8  movups xmm1, [r13+r12*1]
000079bd661cf2be  lea r12, [rax+0x160]
000079bd661cf2c5  vmovaps [rsp+0x30], xmm1
000079bd661cf2cb  movups xmm1, [r13+r12*1]
000079bd661cf2d1  lea r12, [rax+0x170]
000079bd661cf2d8  vmovaps [rsp+0x40], xmm1
000079bd661cf2de  movups xmm1, [r13+r12*1]
000079bd661cf2e4  movaps [r15+0x2B0], xmm1
000079bd661cf2ec  lea r12, [r14+0x80]
000079bd661cf2f3  movups [r13+r12*1], xmm13
000079bd661cf2f9  lea r12, [r14+0x90]
000079bd661cf300  vmovaps xmm13, [rsp+0x10]
000079bd661cf306  movups [r13+r12*1], xmm13
000079bd661cf30c  lea r12, [rax+0x1A0]
000079bd661cf313  movups xmm13, [r13+r12*1]
000079bd661cf319  lea r12, [rax+0x1B0]
000079bd661cf320  vmovaps [rsp+0x10], xmm1
000079bd661cf326  movups xmm1, [r13+r12*1]
000079bd661cf32c  movaps [r15+0x290], xmm13
000079bd661cf334  movaps [r15+0x1E0], xmm1
000079bd661cf33c  lea r12, [rax+0x1E0]
000079bd661cf343  vmovaps [rsp+0x50], xmm1
000079bd661cf349  movups xmm1, [r13+r12*1]
000079bd661cf34f  lea r12, [rax+0x1F0]
000079bd661cf356  vmovaps [rsp+0x60], xmm1
000079bd661cf35c  movups xmm1, [r13+r12*1]
000079bd661cf362  mov qword ptr [r15+0x50], 0x430920
000079bd661cf36a  lea rax, [r14+0x40]
000079bd661cf36e  vmovaps [rsp+0x70], xmm1
000079bd661cf374  vmovaps xmm1, [rsp+0x40]
000079bd661cf37a  movups [r13+rax*1], xmm1
000079bd661cf380  lea rax, [r14+0x50]
000079bd661cf384  movups [r13+rax*1], xmm10
000079bd661cf38a  vmovaps xmm1, [rsp+0x70]
000079bd661cf390  movups [r13+r14*1], xmm1
000079bd661cf396  lea rax, [r14+0x10]
000079bd661cf39a  vmovaps xmm1, [rsp+0x60]
000079bd661cf3a0  movups [r13+rax*1], xmm1
000079bd661cf3a6  mov rax, [r15+0x40]
000079bd661cf3aa  vmovaps [rsp+0x40], xmm3
000079bd661cf3b0  vmovaps xmm1, [rsp+0x40]
000079bd661cf3b6  por xmm3, xmm1
000079bd661cf3ba  vmovaps [rsp+0x40], xmm6
000079bd661cf3c0  vmovaps xmm10, [rsp+0x40]
000079bd661cf3c6  por xmm6, xmm10
000079bd661cf3cb  lea r12, [rax+0x30]
000079bd661cf3cf  mov r11, [r13+r12*1]
000079bd661cf3d4  lea r12, [rax+0x38]
000079bd661cf3d8  mov r10, [r13+r12*1]
000079bd661cf3dd  movq xmm10, r11
000079bd661cf3e2  vmovaps [rsp+0x40], xmm1
000079bd661cf3e8  movq xmm1, r10
000079bd661cf3ed  movq xmm10, xmm10
000079bd661cf3f2  vmovaps [rsp+0x60], xmm10
000079bd661cf3f8  movq xmm10, xmm10
000079bd661cf3fd  movaps [r15+0x130], xmm10
000079bd661cf405  movq xmm1, xmm1
000079bd661cf409  vmovaps [rsp+0x70], xmm1
000079bd661cf40f  movq xmm1, xmm1
000079bd661cf413  movaps [r15+0x280], xmm1
000079bd661cf41b  vmovaps [rsp+0x80], xmm9
000079bd661cf424  vmovaps xmm1, [rsp+0x80]
000079bd661cf42d  por xmm9, xmm1
000079bd661cf432  lea r12, [rax+0x20]
000079bd661cf436  mov r11, [r13+r12*1]
000079bd661cf43b  lea r12, [rax+0x28]
000079bd661cf43f  mov r10, [r13+r12*1]
000079bd661cf444  movq xmm1, r11
000079bd661cf449  movq xmm10, r10
000079bd661cf44e  movq xmm1, xmm1
000079bd661cf452  vmovaps [rsp+0x80], xmm1
000079bd661cf45b  movq xmm1, xmm1
000079bd661cf45f  movaps [r15+0x150], xmm1
000079bd661cf467  movq xmm10, xmm10
000079bd661cf46c  vmovaps [rsp+0x90], xmm10
000079bd661cf475  movq xmm10, xmm10
000079bd661cf47a  movaps [r15+0x140], xmm10
000079bd661cf482  lea r12, [rax+0x10]
000079bd661cf486  mov r11, [r13+r12*1]
000079bd661cf48b  lea r12, [rax+0x18]
000079bd661cf48f  mov r10, [r13+r12*1]
000079bd661cf494  movq xmm1, r11
000079bd661cf499  movq xmm10, r10
000079bd661cf49e  movq xmm1, xmm1
000079bd661cf4a2  vmovaps [rsp+0xA0], xmm1
000079bd661cf4ab  movq xmm1, xmm1
000079bd661cf4af  movaps [r15+0x170], xmm1
000079bd661cf4b7  movq xmm10, xmm10
000079bd661cf4bc  vmovaps [rsp+0xB0], xmm10
000079bd661cf4c5  movq xmm10, xmm10
000079bd661cf4ca  movaps [r15+0x160], xmm10
000079bd661cf4d2  mov r12, [r13+rax*1]
000079bd661cf4d7  vmovq xmm1, r12
000079bd661cf4dc  vpbroadcastq xmm1, xmm1
000079bd661cf4e1  lea r12, [rax+0x08]
000079bd661cf4e5  mov rax, [r13+r12*1]
000079bd661cf4ea  movq xmm10, rax
000079bd661cf4ef  movaps [r15+0x230], xmm10
000079bd661cf4f7  lea rax, [r14+0x50]
000079bd661cf4fb  movups xmm10, [r13+rax*1]
000079bd661cf501  lea rax, [r14+0x60]
000079bd661cf505  vmovaps [rsp+0xC0], xmm1
000079bd661cf50e  movups xmm1, [r13+rax*1]
000079bd661cf514  lea rax, [r14+0x30]
000079bd661cf518  vmovaps [rsp+0xD0], xmm1
000079bd661cf521  movups xmm1, [r13+rax*1]
000079bd661cf527  mov qword ptr [r15+0x60], 0x430920
000079bd661cf52f  mov qword ptr [r15+0x58], 0x40
000079bd661cf537  vmovaps [rsp+0xE0], xmm1
000079bd661cf540  vmovaps [rsp+0xF0], xmm15
000079bd661cf549  vmovaps xmm15, [rsp+0xC0]
000079bd661cf552  vmovaps [rsp+0xC0], xmm14
000079bd661cf55b  vmovaps xmm14, [rsp+0x40]
000079bd661cf561  vmovaps [rsp+0x40], xmm13
000079bd661cf567  movaps xmm1, xmm15
000079bd661cf56b  mulpd xmm1, xmm14
000079bd661cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000079bd661cf575  ptest xmm13, xmm13
000079bd661cf57b  jnz 0x000079BD661D0682
000079bd661cf581  movq xmm14, qword ptr [r15+0x230]
000079bd661cf58a  vmovaps [rsp+0x100], xmm14
000079bd661cf593  vpermilpd xmm14, xmm14, 0x00
000079bd661cf599  vmovaps [rsp+0x110], xmm1
000079bd661cf5a2  vmovaps xmm1, [rsp+0xE0]
000079bd661cf5ab  vmovaps [rsp+0xE0], xmm15
000079bd661cf5b4  movaps xmm13, xmm1
000079bd661cf5b8  mulpd xmm13, xmm14
000079bd661cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000079bd661cf5c3  ptest xmm15, xmm15
000079bd661cf5c9  jnz 0x000079BD661D07C4
000079bd661cf5cf  vxorps xmm1, xmm1, xmm1
000079bd661cf5d3  vpbroadcastq xmm1, xmm1
000079bd661cf5d8  vmovaps xmm14, [rsp+0xE0]
000079bd661cf5e1  vmovaps [rsp+0xE0], xmm1
000079bd661cf5ea  vmovaps xmm1, [rsp+0xD0]
000079bd661cf5f3  vmovaps [rsp+0xD0], xmm13
000079bd661cf5fc  movaps xmm15, xmm14
000079bd661cf600  mulpd xmm15, xmm1
000079bd661cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000079bd661cf60b  ptest xmm13, xmm13
000079bd661cf611  jnz 0x000079BD661D0907
000079bd661cf617  movaps xmm1, xmm14
000079bd661cf61b  mulpd xmm1, xmm10
000079bd661cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000079bd661cf625  ptest xmm13, xmm13
000079bd661cf62b  jnz 0x000079BD661D0A4A
000079bd661cf631  movaps xmm13, xmm14
000079bd661cf635  mulpd xmm13, xmm2
000079bd661cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000079bd661cf640  ptest xmm10, xmm10
000079bd661cf646  jnz 0x000079BD661D0B8C
000079bd661cf64c  vmovaps [rsp+0x120], xmm7
000079bd661cf655  vmovaps xmm14, [rsp+0x120]
000079bd661cf65e  por xmm7, xmm14
000079bd661cf663  vmovaps xmm14, [rsp+0xC0]
000079bd661cf66c  vmovaps xmm10, [rsp+0xC0]
000079bd661cf675  por xmm14, xmm10
000079bd661cf67a  vmovaps xmm2, [rsp+0x100]
000079bd661cf683  vpermilpd xmm2, xmm2, 0x00
000079bd661cf689  vmovaps [rsp+0xC0], xmm1
000079bd661cf692  vmovaps [rsp+0x120], xmm15
000079bd661cf69b  movaps xmm1, xmm10
000079bd661cf69f  mulpd xmm1, xmm2
000079bd661cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000079bd661cf6a8  ptest xmm15, xmm15
000079bd661cf6ae  jnz 0x000079BD661D0CCF
000079bd661cf6b4  xor eax, eax
000079bd661cf6b6  mov r12d, 0x40
000079bd661cf6bc  mov r11d, 0x200
000079bd661cf6c2  cmp r12, r11
000079bd661cf6c5  cmc
000079bd661cf6c6  lahf
000079bd661cf6c7  seto al
000079bd661cf6ca  mov [r15+0x108], eax
000079bd661cf6d1  vmovaps xmm10, [rsp+0x110]
000079bd661cf6da  vmovaps xmm2, [rsp+0xE0]
000079bd661cf6e3  vmovaps [rsp+0xE0], xmm1
000079bd661cf6ec  movaps xmm15, xmm10
000079bd661cf6f0  addpd xmm15, xmm2
000079bd661cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000079bd661cf6fb  ptest xmm1, xmm1
000079bd661cf700  jnz 0x000079BD661D0E10
000079bd661cf706  vmovaps xmm10, [rsp+0x120]
000079bd661cf70f  vmovaps [rsp+0x110], xmm15
000079bd661cf718  movaps xmm1, xmm10
000079bd661cf71c  addpd xmm1, xmm12
000079bd661cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000079bd661cf726  ptest xmm15, xmm15
000079bd661cf72c  jnz 0x000079BD661D0F53
000079bd661cf732  vmovaps xmm10, [rsp+0xC0]
000079bd661cf73b  vmovaps [rsp+0xC0], xmm1
000079bd661cf744  movaps xmm15, xmm10
000079bd661cf748  addpd xmm15, xmm12
000079bd661cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000079bd661cf753  ptest xmm1, xmm1
000079bd661cf758  jnz 0x000079BD661D1095
000079bd661cf75e  vmovaps xmm1, [rsp+0x30]
000079bd661cf764  vmovaps xmm12, [rsp+0x30]
000079bd661cf76a  por xmm1, xmm12
000079bd661cf76f  vmovaps xmm12, [rsp+0x20]
000079bd661cf775  vmovaps xmm10, [rsp+0x20]
000079bd661cf77b  por xmm12, xmm10
000079bd661cf780  vmovaps [rsp+0x20], xmm5
000079bd661cf786  vmovaps xmm10, [rsp+0x20]
000079bd661cf78c  por xmm5, xmm10
000079bd661cf791  vmovaps [rsp+0x20], xmm11
000079bd661cf797  vmovaps xmm10, [rsp+0x20]
000079bd661cf79d  por xmm11, xmm10
000079bd661cf7a2  vmovaps [rsp+0x20], xmm4
000079bd661cf7a8  vmovaps xmm10, [rsp+0x20]
000079bd661cf7ae  por xmm4, xmm10
000079bd661cf7b3  vmovaps [rsp+0x20], xmm8
000079bd661cf7b9  vmovaps xmm10, [rsp+0x20]
000079bd661cf7bf  por xmm8, xmm10
000079bd661cf7c4  vmovaps xmm10, [rsp+0xF0]
000079bd661cf7cd  vmovaps [rsp+0x20], xmm1
000079bd661cf7d3  vmovaps xmm1, [rsp+0xF0]
000079bd661cf7dc  por xmm10, xmm1
000079bd661cf7e1  lea rax, [r14+0xA0]
000079bd661cf7e8  movups xmm1, [r13+rax*1]
000079bd661cf7ee  lea rax, [r14+0xB0]
000079bd661cf7f5  vmovaps [rsp+0x30], xmm1
000079bd661cf7fb  movups xmm1, [r13+rax*1]
000079bd661cf801  vmovaps [rsp+0xF0], xmm1
000079bd661cf80a  vmovaps [rsp+0x120], xmm15
000079bd661cf813  movaps xmm1, xmm13
000079bd661cf817  addpd xmm1, xmm2
000079bd661cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000079bd661cf820  ptest xmm15, xmm15
000079bd661cf826  jnz 0x000079BD661D11ED
000079bd661cf82c  lea rax, [r14+0xF0]
000079bd661cf833  movups xmm15, [r13+rax*1]
000079bd661cf839  vmovaps xmm2, [rsp+0xC0]
000079bd661cf842  vmovaps [rsp+0xC0], xmm1
000079bd661cf84b  vmovaps xmm1, [rsp+0xE0]
000079bd661cf854  vmovaps [rsp+0xE0], xmm15
000079bd661cf85d  movaps xmm13, xmm2
000079bd661cf861  addpd xmm13, xmm1
000079bd661cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000079bd661cf86c  ptest xmm15, xmm15
000079bd661cf872  jnz 0x000079BD661D1338
000079bd661cf878  vmovaps xmm15, [rsp+0x120]
000079bd661cf881  vmovaps xmm2, [rsp+0xD0]
000079bd661cf88a  vmovaps [rsp+0xD0], xmm14
000079bd661cf893  movaps xmm1, xmm15
000079bd661cf897  addpd xmm1, xmm2
000079bd661cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000079bd661cf8a0  ptest xmm14, xmm14
000079bd661cf8a6  jnz 0x000079BD661D147A
000079bd661cf8ac  vmovaps xmm15, [rsp+0x100]
000079bd661cf8b5  vpermilpd xmm15, xmm15, 0x00
000079bd661cf8bb  vmovaps xmm2, [rsp+0xF0]
000079bd661cf8c4  vmovaps [rsp+0xF0], xmm1
000079bd661cf8cd  movaps xmm14, xmm2
000079bd661cf8d1  mulpd xmm14, xmm15
000079bd661cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000079bd661cf8dc  ptest xmm1, xmm1
000079bd661cf8e1  jnz 0x000079BD661D15BB
000079bd661cf8e7  vmovaps xmm1, [rsp+0xA0]
000079bd661cf8f0  vpermilpd xmm1, xmm1, 0x00
000079bd661cf8f6  vmovaps xmm2, [rsp+0xE0]
000079bd661cf8ff  vmovaps [rsp+0xE0], xmm14
000079bd661cf908  movaps xmm15, xmm2
000079bd661cf90c  mulpd xmm15, xmm1
000079bd661cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000079bd661cf917  ptest xmm14, xmm14
000079bd661cf91d  jnz 0x000079BD661D16FE
000079bd661cf923  lea rax, [r14+0xE0]
000079bd661cf92a  movups xmm1, [r13+rax*1]
000079bd661cf930  vmovaps xmm14, [rsp+0x100]
000079bd661cf939  vpermilpd xmm14, xmm14, 0x00
000079bd661cf93f  vmovaps [rsp+0x100], xmm1
000079bd661cf948  vmovaps xmm1, [rsp+0x30]
000079bd661cf94e  vmovaps [rsp+0x30], xmm15
000079bd661cf954  movaps xmm2, xmm1
000079bd661cf957  mulpd xmm2, xmm14
000079bd661cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000079bd661cf961  ptest xmm15, xmm15
000079bd661cf967  jnz 0x000079BD661D184A
000079bd661cf96d  vmovaps [rsp+0x120], xmm10
000079bd661cf976  vmovaps xmm1, [rsp+0x120]
000079bd661cf97f  por xmm10, xmm1
000079bd661cf984  movaps [r15+0x300], xmm10
000079bd661cf98c  vmovaps [rsp+0x120], xmm8
000079bd661cf995  vmovaps xmm1, [rsp+0x120]
000079bd661cf99e  por xmm8, xmm1
000079bd661cf9a3  movaps [r15+0x190], xmm8
000079bd661cf9ab  vmovaps xmm1, [rsp+0xA0]
000079bd661cf9b4  vpermilpd xmm1, xmm1, 0x00
000079bd661cf9ba  vmovaps xmm14, [rsp+0x100]
000079bd661cf9c3  vmovaps [rsp+0x100], xmm13
000079bd661cf9cc  movaps xmm15, xmm14
000079bd661cf9d0  mulpd xmm15, xmm1
000079bd661cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000079bd661cf9db  ptest xmm13, xmm13
000079bd661cf9e1  jnz 0x000079BD661D198B
000079bd661cf9e7  lea rax, [r14+0x90]
000079bd661cf9ee  movups xmm1, [r13+rax*1]
000079bd661cf9f4  vmovaps [rsp+0x120], xmm4
000079bd661cf9fd  vmovaps xmm14, [rsp+0x120]
000079bd661cfa06  por xmm4, xmm14
000079bd661cfa0b  movaps [r15+0x1C0], xmm4
000079bd661cfa13  vmovaps [rsp+0x120], xmm11
000079bd661cfa1c  vmovaps xmm14, [rsp+0x120]
000079bd661cfa25  por xmm11, xmm14
000079bd661cfa2a  movaps [r15+0x200], xmm11
000079bd661cfa32  vmovaps [rsp+0x120], xmm5
000079bd661cfa3b  vmovaps xmm14, [rsp+0x120]
000079bd661cfa44  por xmm5, xmm14
000079bd661cfa49  movaps [r15+0x2D0], xmm5
000079bd661cfa51  vmovaps [rsp+0x120], xmm12
000079bd661cfa5a  vmovaps xmm14, [rsp+0x120]
000079bd661cfa63  por xmm12, xmm14
000079bd661cfa68  movaps [r15+0x2E0], xmm12
000079bd661cfa70  vmovaps xmm13, [rsp+0x110]
000079bd661cfa79  vmovaps [rsp+0x110], xmm1
000079bd661cfa82  vmovaps xmm1, [rsp+0xE0]
000079bd661cfa8b  vmovaps [rsp+0xE0], xmm15
000079bd661cfa94  movaps xmm14, xmm13
000079bd661cfa98  addpd xmm14, xmm1
000079bd661cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000079bd661cfaa3  ptest xmm15, xmm15
000079bd661cfaa9  jnz 0x000079BD661D1AD8
000079bd661cfaaf  vmovaps xmm1, [rsp+0xA0]
000079bd661cfab8  vpermilpd xmm1, xmm1, 0x00
000079bd661cfabe  vmovaps xmm13, [rsp+0x110]
000079bd661cfac7  vmovaps [rsp+0x110], xmm14
000079bd661cfad0  movaps xmm15, xmm13
000079bd661cfad4  mulpd xmm15, xmm1
000079bd661cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000079bd661cfadf  ptest xmm14, xmm14
000079bd661cfae5  jnz 0x000079BD661D1C1B
000079bd661cfaeb  lea rax, [r14+0x80]
000079bd661cfaf2  movups xmm1, [r13+rax*1]
000079bd661cfaf8  vmovaps xmm13, [rsp+0xC0]
000079bd661cfb01  vmovaps [rsp+0xC0], xmm1
000079bd661cfb0a  movaps xmm14, xmm13
000079bd661cfb0e  addpd xmm14, xmm2
000079bd661cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000079bd661cfb19  ptest xmm1, xmm1
000079bd661cfb1e  jnz 0x000079BD661D1D68
000079bd661cfb24  vmovaps xmm13, [rsp+0x100]
000079bd661cfb2d  vmovaps xmm2, [rsp+0x30]
000079bd661cfb33  vmovaps [rsp+0x30], xmm15
000079bd661cfb39  movaps xmm1, xmm13
000079bd661cfb3d  addpd xmm1, xmm2
000079bd661cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000079bd661cfb46  ptest xmm15, xmm15
000079bd661cfb4c  jnz 0x000079BD661D1EAB
000079bd661cfb52  vmovaps xmm15, [rsp+0x20]
000079bd661cfb58  vmovaps xmm13, [rsp+0x20]
000079bd661cfb5e  por xmm15, xmm13
000079bd661cfb63  movaps [r15+0x2F0], xmm15
000079bd661cfb6b  vmovaps xmm13, [rsp+0xA0]
000079bd661cfb74  vpermilpd xmm13, xmm13, 0x00
000079bd661cfb7a  vmovaps [rsp+0x20], xmm1
000079bd661cfb80  vmovaps xmm1, [rsp+0xC0]
000079bd661cfb89  vmovaps [rsp+0xA0], xmm15
000079bd661cfb92  movaps xmm2, xmm1
000079bd661cfb95  mulpd xmm2, xmm13
000079bd661cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000079bd661cfb9f  ptest xmm15, xmm15
000079bd661cfba5  jnz 0x000079BD661D1FEC
000079bd661cfbab  lea rax, [r14+0xD0]
000079bd661cfbb2  movups xmm1, [r13+rax*1]
000079bd661cfbb8  vmovaps xmm13, [rsp+0xF0]
000079bd661cfbc1  vmovaps [rsp+0xC0], xmm1
000079bd661cfbca  vmovaps xmm1, [rsp+0xE0]
000079bd661cfbd3  vmovaps [rsp+0xE0], xmm14
000079bd661cfbdc  movaps xmm15, xmm13
000079bd661cfbe0  addpd xmm15, xmm1
000079bd661cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000079bd661cfbeb  ptest xmm14, xmm14
000079bd661cfbf1  jnz 0x000079BD661D2137
000079bd661cfbf7  vmovaps xmm1, [rsp+0xB0]
000079bd661cfc00  vpermilpd xmm1, xmm1, 0x00
000079bd661cfc06  movaps xmm14, xmm11
000079bd661cfc0a  mulpd xmm14, xmm1
000079bd661cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000079bd661cfc15  ptest xmm13, xmm13
000079bd661cfc1b  jnz 0x000079BD661D227A
000079bd661cfc21  movaps [r15+0x260], xmm14
000079bd661cfc29  vxorps xmm1, xmm1, xmm1
000079bd661cfc2d  vpbroadcastq xmm1, xmm1
000079bd661cfc32  movaps [r15+0x1B0], xmm1
000079bd661cfc3a  vmovaps xmm1, [rsp+0xB0]
000079bd661cfc43  vpermilpd xmm1, xmm1, 0x00
000079bd661cfc49  vmovaps xmm11, [rsp+0xC0]
000079bd661cfc52  vmovaps [rsp+0xC0], xmm15
000079bd661cfc5b  movaps xmm13, xmm11
000079bd661cfc5f  mulpd xmm13, xmm1
000079bd661cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000079bd661cfc6a  ptest xmm15, xmm15
000079bd661cfc70  jnz 0x000079BD661D23BD
000079bd661cfc76  lea rax, [r14+0xC0]
000079bd661cfc7d  movups xmm1, [r13+rax*1]
000079bd661cfc83  vmovaps xmm11, [rsp+0x110]
000079bd661cfc8c  vmovaps [rsp+0xF0], xmm1
000079bd661cfc95  vmovaps xmm1, [rsp+0x30]
000079bd661cfc9b  vmovaps [rsp+0x30], xmm14
000079bd661cfca1  movaps xmm15, xmm11
000079bd661cfca5  addpd xmm15, xmm1
000079bd661cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000079bd661cfcb0  ptest xmm14, xmm14
000079bd661cfcb6  jnz 0x000079BD661D250A
000079bd661cfcbc  vmovaps [rsp+0x100], xmm9
000079bd661cfcc5  vmovaps xmm1, [rsp+0x100]
000079bd661cfcce  por xmm9, xmm1
000079bd661cfcd3  movaps [r15+0x270], xmm9
000079bd661cfcdb  vmovaps [rsp+0x100], xmm6
000079bd661cfce4  vmovaps xmm1, [rsp+0x100]
000079bd661cfced  por xmm6, xmm1
000079bd661cfcf1  movaps [r15+0x1A0], xmm6
000079bd661cfcf9  vmovaps xmm14, [rsp+0xB0]
000079bd661cfd02  vpermilpd xmm14, xmm14, 0x00
000079bd661cfd08  vmovaps xmm6, [rsp+0xF0]
000079bd661cfd11  vmovaps [rsp+0xF0], xmm1
000079bd661cfd1a  movaps xmm11, xmm6
000079bd661cfd1e  mulpd xmm11, xmm14
000079bd661cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000079bd661cfd29  ptest xmm1, xmm1
000079bd661cfd2e  jnz 0x000079BD661D264D
000079bd661cfd34  lea rax, [r14+0x20]
000079bd661cfd38  movups xmm1, [r13+rax*1]
000079bd661cfd3e  movaps [r15+0x110], xmm1
000079bd661cfd46  vmovaps xmm6, [rsp+0xE0]
000079bd661cfd4f  vmovaps [rsp+0xE0], xmm1
000079bd661cfd58  movaps xmm14, xmm6
000079bd661cfd5c  addpd xmm14, xmm2
000079bd661cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000079bd661cfd67  ptest xmm1, xmm1
000079bd661cfd6c  jnz 0x000079BD661D279A
000079bd661cfd72  vmovaps xmm1, [rsp+0xB0]
000079bd661cfd7b  vpermilpd xmm1, xmm1, 0x00
000079bd661cfd81  movaps xmm6, xmm5
000079bd661cfd84  mulpd xmm6, xmm1
000079bd661cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000079bd661cfd8d  ptest xmm2, xmm2
000079bd661cfd92  jnz 0x000079BD661D28DC
000079bd661cfd98  vmovaps xmm5, [rsp+0x20]
000079bd661cfd9e  movaps xmm1, xmm5
000079bd661cfda1  addpd xmm1, xmm13
000079bd661cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000079bd661cfdab  ptest xmm2, xmm2
000079bd661cfdb0  jnz 0x000079BD661D2A1C
000079bd661cfdb6  vmovaps xmm13, [rsp+0x80]
000079bd661cfdbf  vpermilpd xmm13, xmm13, 0x00
000079bd661cfdc5  vmovaps xmm2, [rsp+0xE0]
000079bd661cfdce  vmovaps [rsp+0x20], xmm1
000079bd661cfdd4  movaps xmm5, xmm2
000079bd661cfdd7  mulpd xmm5, xmm13
000079bd661cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000079bd661cfde1  ptest xmm1, xmm1
000079bd661cfde6  jnz 0x000079BD661D2B5D
000079bd661cfdec  vmovaps xmm1, [rsp+0x80]
000079bd661cfdf5  vpermilpd xmm1, xmm1, 0x00
000079bd661cfdfb  movaps xmm13, xmm10
000079bd661cfdff  mulpd xmm13, xmm1
000079bd661cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000079bd661cfe0a  ptest xmm2, xmm2
000079bd661cfe0f  jnz 0x000079BD661D2C9E
000079bd661cfe15  vmovaps xmm10, [rsp+0x30]
000079bd661cfe1b  movaps xmm1, xmm15
000079bd661cfe1f  addpd xmm1, xmm10
000079bd661cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000079bd661cfe29  ptest xmm2, xmm2
000079bd661cfe2e  jnz 0x000079BD661D2DE1
000079bd661cfe34  vmovaps xmm10, [rsp+0xC0]
000079bd661cfe3d  movaps xmm15, xmm10
000079bd661cfe41  addpd xmm15, xmm11
000079bd661cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000079bd661cfe4c  ptest xmm2, xmm2
000079bd661cfe51  jnz 0x000079BD661D2F23
000079bd661cfe57  vmovaps xmm11, [rsp+0x80]
000079bd661cfe60  vpermilpd xmm11, xmm11, 0x00
000079bd661cfe66  movaps xmm10, xmm12
000079bd661cfe6a  mulpd xmm10, xmm11
000079bd661cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000079bd661cfe75  ptest xmm2, xmm2
000079bd661cfe7a  jnz 0x000079BD661D3067
000079bd661cfe80  vmovaps xmm12, [rsp+0x80]
000079bd661cfe89  vpermilpd xmm12, xmm12, 0x00
000079bd661cfe8f  vmovaps xmm2, [rsp+0xA0]
000079bd661cfe98  vmovaps [rsp+0x30], xmm1
000079bd661cfe9e  movaps xmm11, xmm2
000079bd661cfea2  mulpd xmm11, xmm12
000079bd661cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000079bd661cfead  ptest xmm1, xmm1
000079bd661cfeb2  jnz 0x000079BD661D31AB
000079bd661cfeb8  movaps xmm1, xmm14
000079bd661cfebc  addpd xmm1, xmm6
000079bd661cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000079bd661cfec5  ptest xmm12, xmm12
000079bd661cfecb  jnz 0x000079BD661D32EE
000079bd661cfed1  vmovaps xmm12, [rsp+0x20]
000079bd661cfed7  movaps xmm14, xmm12
000079bd661cfedb  addpd xmm14, xmm5
000079bd661cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000079bd661cfee6  ptest xmm6, xmm6
000079bd661cfeeb  jnz 0x000079BD661D342F
000079bd661cfef1  vmovaps xmm12, [rsp+0x90]
000079bd661cfefa  vpermilpd xmm12, xmm12, 0x00
000079bd661cff00  movaps xmm6, xmm9
000079bd661cff04  mulpd xmm6, xmm12
000079bd661cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000079bd661cff0e  ptest xmm5, xmm5
000079bd661cff13  jnz 0x000079BD661D3572
000079bd661cff19  movaps xmm12, xmm15
000079bd661cff1d  addpd xmm12, xmm13
000079bd661cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000079bd661cff28  ptest xmm9, xmm9
000079bd661cff2e  jnz 0x000079BD661D36B4
000079bd661cff34  vmovaps xmm13, [rsp+0x30]
000079bd661cff3a  movaps xmm15, xmm13
000079bd661cff3e  addpd xmm15, xmm10
000079bd661cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000079bd661cff49  ptest xmm9, xmm9
000079bd661cff4f  jnz 0x000079BD661D37F8
000079bd661cff55  vmovaps xmm13, [rsp+0xD0]
000079bd661cff5e  vmovaps xmm10, [rsp+0xD0]
000079bd661cff67  por xmm13, xmm10
000079bd661cff6c  movaps [r15+0x250], xmm13
000079bd661cff74  vmovaps [rsp+0x20], xmm7
000079bd661cff7a  vmovaps xmm13, [rsp+0x20]
000079bd661cff80  por xmm7, xmm13
000079bd661cff85  movaps [r15+0x2A0], xmm7
000079bd661cff8d  vmovaps [rsp+0x20], xmm3
000079bd661cff93  vmovaps xmm13, [rsp+0x20]
000079bd661cff99  por xmm3, xmm13
000079bd661cff9e  movaps [r15+0x1D0], xmm3
000079bd661cffa6  lea rax, [r14+0x40]
000079bd661cffaa  movups xmm13, [r13+rax*1]
000079bd661cffb0  movaps [r15+0x2C0], xmm13
000079bd661cffb8  vmovaps xmm10, [rsp+0x90]
000079bd661cffc1  vpermilpd xmm10, xmm10, 0x00
000079bd661cffc7  movaps xmm9, xmm8
000079bd661cffcb  mulpd xmm9, xmm10
000079bd661cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000079bd661cffd6  ptest xmm5, xmm5
000079bd661cffdb  jnz 0x000079BD661D3946
000079bd661cffe1  movaps xmm10, xmm1
000079bd661cffe5  addpd xmm10, xmm11
000079bd661cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000079bd661cfff0  ptest xmm8, xmm8
000079bd661cfff6  jnz 0x000079BD661D3A8A
000079bd661cfffc  movaps xmm1, xmm14
000079bd661d0000  addpd xmm1, xmm6
000079bd661d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000079bd661d0009  ptest xmm11, xmm11
000079bd661d000f  jnz 0x000079BD661D3BCD
000079bd661d0015  vmovaps xmm14, [rsp+0x90]
000079bd661d001e  vpermilpd xmm14, xmm14, 0x00
000079bd661d0024  movaps xmm11, xmm13
000079bd661d0028  mulpd xmm11, xmm14
000079bd661d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000079bd661d0033  ptest xmm8, xmm8
000079bd661d0039  jnz 0x000079BD661D3D0E
000079bd661d003f  vmovaps xmm14, [rsp+0x90]
000079bd661d0048  vpermilpd xmm14, xmm14, 0x00
000079bd661d004e  vmovaps xmm8, [rsp+0x10]
000079bd661d0054  movaps xmm13, xmm8
000079bd661d0058  mulpd xmm13, xmm14
000079bd661d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000079bd661d0063  ptest xmm6, xmm6
000079bd661d0068  jnz 0x000079BD661D3E52
000079bd661d006e  vmovaps xmm14, [rsp+0x60]
000079bd661d0074  vpermilpd xmm14, xmm14, 0x00
000079bd661d007a  movaps xmm8, xmm7
000079bd661d007e  mulpd xmm8, xmm14
000079bd661d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000079bd661d0089  ptest xmm6, xmm6
000079bd661d008e  jnz 0x000079BD661D3F96
000079bd661d0094  movaps xmm14, xmm12
000079bd661d0098  addpd xmm14, xmm9
000079bd661d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000079bd661d00a3  ptest xmm7, xmm7
000079bd661d00a8  jnz 0x000079BD661D40D9
000079bd661d00ae  vmovaps xmm12, [rsp+0x60]
000079bd661d00b4  vpermilpd xmm12, xmm12, 0x00
000079bd661d00ba  vmovaps xmm7, [rsp+0xF0]
000079bd661d00c3  movaps xmm9, xmm7
000079bd661d00c7  mulpd xmm9, xmm12
000079bd661d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000079bd661d00d2  ptest xmm6, xmm6
000079bd661d00d7  jnz 0x000079BD661D421D
000079bd661d00dd  movaps xmm12, xmm15
000079bd661d00e1  addpd xmm12, xmm11
000079bd661d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000079bd661d00ec  ptest xmm7, xmm7
000079bd661d00f1  jnz 0x000079BD661D4360
000079bd661d00f7  vmovaps xmm15, [rsp+0x60]
000079bd661d00fd  vpermilpd xmm15, xmm15, 0x00
000079bd661d0103  vmovaps xmm7, [rsp+0x40]
000079bd661d0109  movaps xmm11, xmm7
000079bd661d010d  mulpd xmm11, xmm15
000079bd661d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000079bd661d0118  ptest xmm6, xmm6
000079bd661d011d  jnz 0x000079BD661D44A4
000079bd661d0123  movaps xmm15, xmm10
000079bd661d0127  addpd xmm15, xmm13
000079bd661d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000079bd661d0132  ptest xmm7, xmm7
000079bd661d0137  jnz 0x000079BD661D45E7
000079bd661d013d  vmovaps xmm13, [rsp+0x60]
000079bd661d0143  vpermilpd xmm13, xmm13, 0x00
000079bd661d0149  vmovaps xmm7, [rsp+0x50]
000079bd661d014f  movaps xmm10, xmm7
000079bd661d0153  mulpd xmm10, xmm13
000079bd661d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000079bd661d015e  ptest xmm6, xmm6
000079bd661d0163  jnz 0x000079BD661D472B
000079bd661d0169  movaps xmm13, xmm1
000079bd661d016d  addpd xmm13, xmm8
000079bd661d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000079bd661d0178  ptest xmm7, xmm7
000079bd661d017d  jnz 0x000079BD661D486E
000079bd661d0183  lea rax, [r14+0x70]
000079bd661d0187  movups xmm1, [r13+rax*1]
000079bd661d018d  movaps [r15+0x240], xmm1
000079bd661d0195  movaps xmm8, xmm14
000079bd661d0199  addpd xmm8, xmm9
000079bd661d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000079bd661d01a4  ptest xmm7, xmm7
000079bd661d01a9  jnz 0x000079BD661D49BB
000079bd661d01af  movaps [r15+0x170], xmm8
000079bd661d01b7  vmovaps xmm14, [rsp+0x70]
000079bd661d01bd  vpermilpd xmm14, xmm14, 0x00
000079bd661d01c3  movaps xmm9, xmm1
000079bd661d01c7  mulpd xmm9, xmm14
000079bd661d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000079bd661d01d2  ptest xmm7, xmm7
000079bd661d01d7  jnz 0x000079BD661D4AFF
000079bd661d01dd  vmovaps xmm1, [rsp+0x70]
000079bd661d01e3  vpermilpd xmm1, xmm1, 0x00
000079bd661d01e9  movaps xmm14, xmm4
000079bd661d01ed  mulpd xmm14, xmm1
000079bd661d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000079bd661d01f8  ptest xmm7, xmm7
000079bd661d01fd  jnz 0x000079BD661D4C42
000079bd661d0203  movaps [r15+0x180], xmm14
000079bd661d020b  movaps xmm1, xmm12
000079bd661d020f  addpd xmm1, xmm11
000079bd661d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000079bd661d0219  ptest xmm7, xmm7
000079bd661d021e  jnz 0x000079BD661D4D84
000079bd661d0224  movaps [r15+0x210], xmm1
000079bd661d022c  movups xmm12, [r13+r14*1]
000079bd661d0232  lea rax, [r14+0x10]
000079bd661d0236  movups xmm11, [r13+rax*1]
000079bd661d023c  movaps [r15+0x230], xmm11
000079bd661d0244  movaps xmm7, xmm15
000079bd661d0248  addpd xmm7, xmm10
000079bd661d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000079bd661d0252  ptest xmm6, xmm6
000079bd661d0257  jnz 0x000079BD661D4EDA
000079bd661d025d  movaps [r15+0x130], xmm7
000079bd661d0265  vmovaps xmm15, [rsp+0x70]
000079bd661d026b  vpermilpd xmm15, xmm15, 0x00
000079bd661d0271  movaps xmm10, xmm11
000079bd661d0275  mulpd xmm10, xmm15
000079bd661d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000079bd661d0280  ptest xmm6, xmm6
000079bd661d0285  jnz 0x000079BD661D501C
000079bd661d028b  movaps [r15+0x220], xmm10
000079bd661d0293  vmovaps xmm15, [rsp+0x70]
000079bd661d0299  vpermilpd xmm15, xmm15, 0x00
000079bd661d029f  movaps xmm11, xmm12
000079bd661d02a3  mulpd xmm11, xmm15
000079bd661d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000079bd661d02ae  ptest xmm6, xmm6
000079bd661d02b3  jnz 0x000079BD661D5160
000079bd661d02b9  movaps xmm15, xmm13
000079bd661d02bd  addpd xmm15, xmm9
000079bd661d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000079bd661d02c8  ptest xmm12, xmm12
000079bd661d02ce  jnz 0x000079BD661D52A4
000079bd661d02d4  movaps [r15+0x140], xmm15
000079bd661d02dc  movaps xmm13, xmm8
000079bd661d02e0  addpd xmm13, xmm14
000079bd661d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000079bd661d02eb  ptest xmm12, xmm12
000079bd661d02f1  jnz 0x000079BD661D53E8
000079bd661d02f7  movaps [r15+0x150], xmm13
000079bd661d02ff  movaps xmm14, xmm1
000079bd661d0303  addpd xmm14, xmm10
000079bd661d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000079bd661d030e  ptest xmm12, xmm12
000079bd661d0314  jnz 0x000079BD661D552C
000079bd661d031a  movaps [r15+0x160], xmm14
000079bd661d0322  movaps xmm1, xmm7
000079bd661d0325  addpd xmm1, xmm11
000079bd661d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000079bd661d032f  ptest xmm12, xmm12
000079bd661d0335  jnz 0x000079BD661D566F
000079bd661d033b  movaps [r15+0x120], xmm1
000079bd661d0343  mov eax, 0x430920
000079bd661d0348  movups [r13+rax*1], xmm15
000079bd661d034e  mov eax, 0x430930
000079bd661d0353  movups [r13+rax*1], xmm13
000079bd661d0359  mov eax, 0x430940
000079bd661d035e  movups [r13+rax*1], xmm14
000079bd661d0364  mov eax, 0x430950
000079bd661d0369  movups [r13+rax*1], xmm1
000079bd661d036f  mov eax, [r15+0x108]
000079bd661d0376  sahf
000079bd661d0377  jnz 0x000079BD661D03A9
000079bd661d0379  cmp dword ptr [r15+0x318], 0x00
000079bd661d0381  jz 0x000079BD661DB900
000079bd661d0387  nop [rax+rax*1], ax
000079bd661d0390  nop [rax+rax*1], eax
000079bd661d0398  mov eax, 0x410444
000079bd661d039d  mov [r15+0x100], rax
000079bd661d03a4  jmp 0x000079BD65FFE110
000079bd661d03a9  cmp dword ptr [r15+0x318], 0x00
000079bd661d03b1  jz 0x000079BD661D57E0
000079bd661d03b7  nop [rax+rax*1], ax
000079bd661d03c0  nop [rax+rax*1], eax
000079bd661d03c8  mov eax, 0x410278
000079bd661d03cd  mov [r15+0x100], rax
000079bd661d03d4  jmp 0x000079BD65FFE110
000079bd661d03d9  int3
000079bd661d03da  call 0x000079BD660B52F0
000079bd661d03df  jmp 0x000079BD661CF016
000079bd661d03e4  call 0x000079BD660C4620
000079bd661d03e9  jmp 0x000079BD661CF023
000079bd661d03ee  call 0x000079BD660C33A0
000079bd661d03f3  jmp 0x000079BD661CF035
000079bd661d03f8  call 0x000079BD660C2120
000079bd661d03fd  jmp 0x000079BD661CF03F
000079bd661d0402  call 0x000079BD660C0860
000079bd661d0407  jmp 0x000079BD661CF067
000079bd661d040c  call 0x000079BD660BF5F0
000079bd661d0411  jmp 0x000079BD661CF073
000079bd661d0416  call 0x000079BD660C0860
000079bd661d041b  jmp 0x000079BD661CF0A5
000079bd661d0420  call 0x000079BD660BF5F0
000079bd661d0425  jmp 0x000079BD661CF0B1
000079bd661d042a  call 0x000079BD660C4740
000079bd661d042f  jmp 0x000079BD661CF0BE
000079bd661d0434  call 0x000079BD660B5400
000079bd661d0439  jmp 0x000079BD661CF0CB
000079bd661d043e  call 0x000079BD660B52F0
000079bd661d0443  jmp 0x000079BD661CF0D8
000079bd661d0448  call 0x000079BD660C4620
000079bd661d044d  jmp 0x000079BD661CF0E5
000079bd661d0452  call 0x000079BD660C0860
000079bd661d0457  jmp 0x000079BD661CF10D
000079bd661d045c  call 0x000079BD660BF5F0
000079bd661d0461  jmp 0x000079BD661CF119
000079bd661d0466  call 0x000079BD66009D70
000079bd661d046b  jmp 0x000079BD661CF11F
000079bd661d0470  call 0x000079BD660BE9C0
000079bd661d0475  jmp 0x000079BD661CF129
000079bd661d047a  call 0x000079BD660C0860
000079bd661d047f  jmp 0x000079BD661CF151
000079bd661d0484  call 0x000079BD660BF5F0
000079bd661d0489  jmp 0x000079BD661CF15D
000079bd661d048e  call 0x000079BD660BD750
000079bd661d0493  jmp 0x000079BD661CF16A
000079bd661d0498  call 0x000079BD660BC4E0
000079bd661d049d  jmp 0x000079BD661CF177
000079bd661d04a2  call 0x000079BD660C4740
000079bd661d04a7  jmp 0x000079BD661CF184
000079bd661d04ac  call 0x000079BD660B5400
000079bd661d04b1  jmp 0x000079BD661CF191
000079bd661d04b6  call 0x000079BD660B52F0
000079bd661d04bb  jmp 0x000079BD661CF19E
000079bd661d04c0  call 0x000079BD660C4620
000079bd661d04c5  jmp 0x000079BD661CF1AB
000079bd661d04ca  call 0x000079BD660C0860
000079bd661d04cf  jmp 0x000079BD661CF1BE
000079bd661d04d4  call 0x000079BD660BB270
000079bd661d04d9  jmp 0x000079BD661CF1CB
000079bd661d04de  call 0x000079BD660BA000
000079bd661d04e3  jmp 0x000079BD661CF1D8
000079bd661d04e8  call 0x000079BD660B8D90
000079bd661d04ed  jmp 0x000079BD661CF1E5
000079bd661d04f2  call 0x000079BD660B8A20
000079bd661d04f7  jmp 0x000079BD661CF1F2
000079bd661d04fc  call 0x000079BD660B5400
000079bd661d0501  jmp 0x000079BD661CF1FC
000079bd661d0506  call 0x000079BD660C2240
000079bd661d050b  jmp 0x000079BD661CF206
000079bd661d0510  call 0x000079BD660B52F0
000079bd661d0515  jmp 0x000079BD661CF210
000079bd661d051a  call 0x000079BD660C2120
000079bd661d051f  jmp 0x000079BD661CF21A
000079bd661d0524  call 0x000079BD660B77B0
000079bd661d0529  jmp 0x000079BD661CF224
000079bd661d052e  call 0x000079BD660B6550
000079bd661d0533  jmp 0x000079BD661CF22E
000079bd661d0538  call 0x000079BD660BFD50
000079bd661d053d  jmp 0x000079BD661CF240
000079bd661d0542  call 0x000079BD660B8EA0
000079bd661d0547  jmp 0x000079BD661CF24A
000079bd661d054c  call 0x000079BD660BFC30
000079bd661d0551  jmp 0x000079BD661CF257
000079bd661d0556  call 0x000079BD660B8D90
000079bd661d055b  jmp 0x000079BD661CF264
000079bd661d0560  call 0x000079BD660C2240
000079bd661d0565  jmp 0x000079BD661CF271
000079bd661d056a  call 0x000079BD660B5400
000079bd661d056f  jmp 0x000079BD661CF27E
000079bd661d0574  call 0x000079BD660B52F0
000079bd661d0579  jmp 0x000079BD661CF28B
000079bd661d057e  call 0x000079BD660C2120
000079bd661d0583  jmp 0x000079BD661CF298
000079bd661d0588  call 0x000079BD660B52F0
000079bd661d058d  jmp 0x000079BD661CF2AB
000079bd661d0592  call 0x000079BD660B52F0
000079bd661d0597  jmp 0x000079BD661CF2BE
000079bd661d059c  call 0x000079BD660B52F0
000079bd661d05a1  jmp 0x000079BD661CF2D1
000079bd661d05a6  call 0x000079BD660B52F0
000079bd661d05ab  jmp 0x000079BD661CF2E4
000079bd661d05b0  call 0x000079BD660C2240
000079bd661d05b5  jmp 0x000079BD661CF2F9
000079bd661d05ba  call 0x000079BD660C2240
000079bd661d05bf  jmp 0x000079BD661CF30C
000079bd661d05c4  call 0x000079BD660C2120
000079bd661d05c9  jmp 0x000079BD661CF319
000079bd661d05ce  call 0x000079BD660B52F0
000079bd661d05d3  jmp 0x000079BD661CF32C
000079bd661d05d8  call 0x000079BD660B52F0
000079bd661d05dd  jmp 0x000079BD661CF34F
000079bd661d05e2  call 0x000079BD660B52F0
000079bd661d05e7  jmp 0x000079BD661CF362
000079bd661d05ec  call 0x000079BD65FFF540
000079bd661d05f1  jmp 0x000079BD661CF380
000079bd661d05f6  call 0x000079BD66008C20
000079bd661d05fb  jmp 0x000079BD661CF38A
000079bd661d0600  call 0x000079BD660D6600
000079bd661d0605  jmp 0x000079BD661CF396
000079bd661d060a  call 0x000079BD65FFF540
000079bd661d060f  jmp 0x000079BD661CF3A6
000079bd661d0614  call 0x000079BD660C0370
000079bd661d0619  jmp 0x000079BD661CF3D4
000079bd661d061e  call 0x000079BD660BF100
000079bd661d0623  jmp 0x000079BD661CF3DD
000079bd661d0628  call 0x000079BD660C0370
000079bd661d062d  jmp 0x000079BD661CF43B
000079bd661d0632  call 0x000079BD660BF100
000079bd661d0637  jmp 0x000079BD661CF444
000079bd661d063c  call 0x000079BD660C0370
000079bd661d0641  jmp 0x000079BD661CF48B
000079bd661d0646  call 0x000079BD660BF100
000079bd661d064b  jmp 0x000079BD661CF494
000079bd661d0650  call 0x000079BD6600B720
000079bd661d0655  jmp 0x000079BD661CF4D7
000079bd661d065a  call 0x000079BD660B47C0
000079bd661d065f  jmp 0x000079BD661CF4EA
000079bd661d0664  call 0x000079BD66008B00
000079bd661d0669  jmp 0x000079BD661CF501
000079bd661d066e  call 0x000079BD65FFF430
000079bd661d0673  jmp 0x000079BD661CF514
000079bd661d0678  call 0x000079BD65FFF430
000079bd661d067d  jmp 0x000079BD661CF527
000079bd661d0682  sub rsp, 0x08
000079bd661d0686  push rax
000079bd661d0687  push rcx
000079bd661d0688  push rdx
000079bd661d0689  push rdi
000079bd661d068a  push rsi
000079bd661d068b  push r8
000079bd661d068d  push r9
000079bd661d068f  push r10
000079bd661d0691  push r11
000079bd661d0693  sub rsp, 0xF0
000079bd661d069a  vmovaps [rsp], xmm0
000079bd661d069f  vmovaps [rsp+0x10], xmm2
000079bd661d06a5  vmovaps [rsp+0x20], xmm3
000079bd661d06ab  vmovaps [rsp+0x30], xmm4
000079bd661d06b1  vmovaps [rsp+0x40], xmm5
000079bd661d06b7  vmovaps [rsp+0x50], xmm6
000079bd661d06bd  vmovaps [rsp+0x60], xmm7
000079bd661d06c3  vmovaps [rsp+0x70], xmm8
000079bd661d06c9  vmovaps [rsp+0x80], xmm9
000079bd661d06d2  vmovaps [rsp+0x90], xmm10
000079bd661d06db  vmovaps [rsp+0xA0], xmm11
000079bd661d06e4  vmovaps [rsp+0xB0], xmm12
000079bd661d06ed  vmovaps [rsp+0xC0], xmm13
000079bd661d06f6  vmovaps [rsp+0xD0], xmm14
000079bd661d06ff  vmovaps [rsp+0xE0], xmm15
000079bd661d0708  sub rsp, 0x30
000079bd661d070c  movaps [rsp], xmm1
000079bd661d0710  movaps [rsp+0x10], xmm15
000079bd661d0716  movaps [rsp+0x20], xmm14
000079bd661d071c  lea rdi, [rsp]
000079bd661d0720  mov esi, 0x00
000079bd661d0725  mov rax, 0x56EBD57B0530
000079bd661d072f  call rax
000079bd661d0731  movaps xmm1, [rsp]
000079bd661d0735  add rsp, 0x30
000079bd661d0739  vmovaps xmm0, [rsp]
000079bd661d073e  vmovaps xmm2, [rsp+0x10]
000079bd661d0744  vmovaps xmm3, [rsp+0x20]
000079bd661d074a  vmovaps xmm4, [rsp+0x30]
000079bd661d0750  vmovaps xmm5, [rsp+0x40]
000079bd661d0756  vmovaps xmm6, [rsp+0x50]
000079bd661d075c  vmovaps xmm7, [rsp+0x60]
000079bd661d0762  vmovaps xmm8, [rsp+0x70]
000079bd661d0768  vmovaps xmm9, [rsp+0x80]
000079bd661d0771  vmovaps xmm10, [rsp+0x90]
000079bd661d077a  vmovaps xmm11, [rsp+0xA0]
000079bd661d0783  vmovaps xmm12, [rsp+0xB0]
000079bd661d078c  vmovaps xmm13, [rsp+0xC0]
000079bd661d0795  vmovaps xmm14, [rsp+0xD0]
000079bd661d079e  vmovaps xmm15, [rsp+0xE0]
000079bd661d07a7  add rsp, 0xF0
000079bd661d07ae  pop r11
000079bd661d07b0  pop r10
000079bd661d07b2  pop r9
000079bd661d07b4  pop r8
000079bd661d07b6  pop rsi
000079bd661d07b7  pop rdi
000079bd661d07b8  pop rdx
000079bd661d07b9  pop rcx
000079bd661d07ba  pop rax
000079bd661d07bb  add rsp, 0x08
000079bd661d07bf  jmp 0x000079BD661CF581
000079bd661d07c4  sub rsp, 0x08
000079bd661d07c8  push rax
000079bd661d07c9  push rcx
000079bd661d07ca  push rdx
000079bd661d07cb  push rdi
000079bd661d07cc  push rsi
000079bd661d07cd  push r8
000079bd661d07cf  push r9
000079bd661d07d1  push r10
000079bd661d07d3  push r11
000079bd661d07d5  sub rsp, 0xF0
000079bd661d07dc  vmovaps [rsp], xmm0
000079bd661d07e1  vmovaps [rsp+0x10], xmm1
000079bd661d07e7  vmovaps [rsp+0x20], xmm2
000079bd661d07ed  vmovaps [rsp+0x30], xmm3
000079bd661d07f3  vmovaps [rsp+0x40], xmm4
000079bd661d07f9  vmovaps [rsp+0x50], xmm5
000079bd661d07ff  vmovaps [rsp+0x60], xmm6
000079bd661d0805  vmovaps [rsp+0x70], xmm7
000079bd661d080b  vmovaps [rsp+0x80], xmm8
000079bd661d0814  vmovaps [rsp+0x90], xmm9
000079bd661d081d  vmovaps [rsp+0xA0], xmm10
000079bd661d0826  vmovaps [rsp+0xB0], xmm11
000079bd661d082f  vmovaps [rsp+0xC0], xmm12
000079bd661d0838  vmovaps [rsp+0xD0], xmm14
000079bd661d0841  vmovaps [rsp+0xE0], xmm15
000079bd661d084a  sub rsp, 0x30
000079bd661d084e  movaps [rsp], xmm13
000079bd661d0853  movaps [rsp+0x10], xmm1
000079bd661d0858  movaps [rsp+0x20], xmm14
000079bd661d085e  lea rdi, [rsp]
000079bd661d0862  mov esi, 0x00
000079bd661d0867  mov rax, 0x56EBD57B0530
000079bd661d0871  call rax
000079bd661d0873  movaps xmm13, [rsp]
000079bd661d0878  add rsp, 0x30
000079bd661d087c  vmovaps xmm0, [rsp]
000079bd661d0881  vmovaps xmm1, [rsp+0x10]
000079bd661d0887  vmovaps xmm2, [rsp+0x20]
000079bd661d088d  vmovaps xmm3, [rsp+0x30]
000079bd661d0893  vmovaps xmm4, [rsp+0x40]
000079bd661d0899  vmovaps xmm5, [rsp+0x50]
000079bd661d089f  vmovaps xmm6, [rsp+0x60]
000079bd661d08a5  vmovaps xmm7, [rsp+0x70]
000079bd661d08ab  vmovaps xmm8, [rsp+0x80]
000079bd661d08b4  vmovaps xmm9, [rsp+0x90]
000079bd661d08bd  vmovaps xmm10, [rsp+0xA0]
000079bd661d08c6  vmovaps xmm11, [rsp+0xB0]
000079bd661d08cf  vmovaps xmm12, [rsp+0xC0]
000079bd661d08d8  vmovaps xmm14, [rsp+0xD0]
000079bd661d08e1  vmovaps xmm15, [rsp+0xE0]
000079bd661d08ea  add rsp, 0xF0
000079bd661d08f1  pop r11
000079bd661d08f3  pop r10
000079bd661d08f5  pop r9
000079bd661d08f7  pop r8
000079bd661d08f9  pop rsi
000079bd661d08fa  pop rdi
000079bd661d08fb  pop rdx
000079bd661d08fc  pop rcx
000079bd661d08fd  pop rax
000079bd661d08fe  add rsp, 0x08
000079bd661d0902  jmp 0x000079BD661CF5CF
000079bd661d0907  sub rsp, 0x08
000079bd661d090b  push rax
000079bd661d090c  push rcx
000079bd661d090d  push rdx
000079bd661d090e  push rdi
000079bd661d090f  push rsi
000079bd661d0910  push r8
000079bd661d0912  push r9
000079bd661d0914  push r10
000079bd661d0916  push r11
000079bd661d0918  sub rsp, 0xF0
000079bd661d091f  vmovaps [rsp], xmm0
000079bd661d0924  vmovaps [rsp+0x10], xmm1
000079bd661d092a  vmovaps [rsp+0x20], xmm2
000079bd661d0930  vmovaps [rsp+0x30], xmm3
000079bd661d0936  vmovaps [rsp+0x40], xmm4
000079bd661d093c  vmovaps [rsp+0x50], xmm5
000079bd661d0942  vmovaps [rsp+0x60], xmm6
000079bd661d0948  vmovaps [rsp+0x70], xmm7
000079bd661d094e  vmovaps [rsp+0x80], xmm8
000079bd661d0957  vmovaps [rsp+0x90], xmm9
000079bd661d0960  vmovaps [rsp+0xA0], xmm10
000079bd661d0969  vmovaps [rsp+0xB0], xmm11
000079bd661d0972  vmovaps [rsp+0xC0], xmm12
000079bd661d097b  vmovaps [rsp+0xD0], xmm13
000079bd661d0984  vmovaps [rsp+0xE0], xmm14
000079bd661d098d  sub rsp, 0x30
000079bd661d0991  movaps [rsp], xmm15
000079bd661d0996  movaps [rsp+0x10], xmm14
000079bd661d099c  movaps [rsp+0x20], xmm1
000079bd661d09a1  lea rdi, [rsp]
000079bd661d09a5  mov esi, 0x00
000079bd661d09aa  mov rax, 0x56EBD57B0530
000079bd661d09b4  call rax
000079bd661d09b6  movaps xmm15, [rsp]
000079bd661d09bb  add rsp, 0x30
000079bd661d09bf  vmovaps xmm0, [rsp]
000079bd661d09c4  vmovaps xmm1, [rsp+0x10]
000079bd661d09ca  vmovaps xmm2, [rsp+0x20]
000079bd661d09d0  vmovaps xmm3, [rsp+0x30]
000079bd661d09d6  vmovaps xmm4, [rsp+0x40]
000079bd661d09dc  vmovaps xmm5, [rsp+0x50]
000079bd661d09e2  vmovaps xmm6, [rsp+0x60]
000079bd661d09e8  vmovaps xmm7, [rsp+0x70]
000079bd661d09ee  vmovaps xmm8, [rsp+0x80]
000079bd661d09f7  vmovaps xmm9, [rsp+0x90]
000079bd661d0a00  vmovaps xmm10, [rsp+0xA0]
000079bd661d0a09  vmovaps xmm11, [rsp+0xB0]
000079bd661d0a12  vmovaps xmm12, [rsp+0xC0]
000079bd661d0a1b  vmovaps xmm13, [rsp+0xD0]
000079bd661d0a24  vmovaps xmm14, [rsp+0xE0]
000079bd661d0a2d  add rsp, 0xF0
000079bd661d0a34  pop r11
000079bd661d0a36  pop r10
000079bd661d0a38  pop r9
000079bd661d0a3a  pop r8
000079bd661d0a3c  pop rsi
000079bd661d0a3d  pop rdi
000079bd661d0a3e  pop rdx
000079bd661d0a3f  pop rcx
000079bd661d0a40  pop rax
000079bd661d0a41  add rsp, 0x08
000079bd661d0a45  jmp 0x000079BD661CF617
000079bd661d0a4a  sub rsp, 0x08
000079bd661d0a4e  push rax
000079bd661d0a4f  push rcx
000079bd661d0a50  push rdx
000079bd661d0a51  push rdi
000079bd661d0a52  push rsi
000079bd661d0a53  push r8
000079bd661d0a55  push r9
000079bd661d0a57  push r10
000079bd661d0a59  push r11
000079bd661d0a5b  sub rsp, 0xF0
000079bd661d0a62  vmovaps [rsp], xmm0
000079bd661d0a67  vmovaps [rsp+0x10], xmm2
000079bd661d0a6d  vmovaps [rsp+0x20], xmm3
000079bd661d0a73  vmovaps [rsp+0x30], xmm4
000079bd661d0a79  vmovaps [rsp+0x40], xmm5
000079bd661d0a7f  vmovaps [rsp+0x50], xmm6
000079bd661d0a85  vmovaps [rsp+0x60], xmm7
000079bd661d0a8b  vmovaps [rsp+0x70], xmm8
000079bd661d0a91  vmovaps [rsp+0x80], xmm9
000079bd661d0a9a  vmovaps [rsp+0x90], xmm10
000079bd661d0aa3  vmovaps [rsp+0xA0], xmm11
000079bd661d0aac  vmovaps [rsp+0xB0], xmm12
000079bd661d0ab5  vmovaps [rsp+0xC0], xmm13
000079bd661d0abe  vmovaps [rsp+0xD0], xmm14
000079bd661d0ac7  vmovaps [rsp+0xE0], xmm15
000079bd661d0ad0  sub rsp, 0x30
000079bd661d0ad4  movaps [rsp], xmm1
000079bd661d0ad8  movaps [rsp+0x10], xmm14
000079bd661d0ade  movaps [rsp+0x20], xmm10
000079bd661d0ae4  lea rdi, [rsp]
000079bd661d0ae8  mov esi, 0x00
000079bd661d0aed  mov rax, 0x56EBD57B0530
000079bd661d0af7  call rax
000079bd661d0af9  movaps xmm1, [rsp]
000079bd661d0afd  add rsp, 0x30
000079bd661d0b01  vmovaps xmm0, [rsp]
000079bd661d0b06  vmovaps xmm2, [rsp+0x10]
000079bd661d0b0c  vmovaps xmm3, [rsp+0x20]
000079bd661d0b12  vmovaps xmm4, [rsp+0x30]
000079bd661d0b18  vmovaps xmm5, [rsp+0x40]
000079bd661d0b1e  vmovaps xmm6, [rsp+0x50]
000079bd661d0b24  vmovaps xmm7, [rsp+0x60]
000079bd661d0b2a  vmovaps xmm8, [rsp+0x70]
000079bd661d0b30  vmovaps xmm9, [rsp+0x80]
000079bd661d0b39  vmovaps xmm10, [rsp+0x90]
000079bd661d0b42  vmovaps xmm11, [rsp+0xA0]
000079bd661d0b4b  vmovaps xmm12, [rsp+0xB0]
000079bd661d0b54  vmovaps xmm13, [rsp+0xC0]
000079bd661d0b5d  vmovaps xmm14, [rsp+0xD0]
000079bd661d0b66  vmovaps xmm15, [rsp+0xE0]
000079bd661d0b6f  add rsp, 0xF0
000079bd661d0b76  pop r11
000079bd661d0b78  pop r10
000079bd661d0b7a  pop r9
000079bd661d0b7c  pop r8
000079bd661d0b7e  pop rsi
000079bd661d0b7f  pop rdi
000079bd661d0b80  pop rdx
000079bd661d0b81  pop rcx
000079bd661d0b82  pop rax
000079bd661d0b83  add rsp, 0x08
000079bd661d0b87  jmp 0x000079BD661CF631
000079bd661d0b8c  sub rsp, 0x08
000079bd661d0b90  push rax
000079bd661d0b91  push rcx
000079bd661d0b92  push rdx
000079bd661d0b93  push rdi
000079bd661d0b94  push rsi
000079bd661d0b95  push r8
000079bd661d0b97  push r9
000079bd661d0b99  push r10
000079bd661d0b9b  push r11
000079bd661d0b9d  sub rsp, 0xF0
000079bd661d0ba4  vmovaps [rsp], xmm0
000079bd661d0ba9  vmovaps [rsp+0x10], xmm1
000079bd661d0baf  vmovaps [rsp+0x20], xmm2
000079bd661d0bb5  vmovaps [rsp+0x30], xmm3
000079bd661d0bbb  vmovaps [rsp+0x40], xmm4
000079bd661d0bc1  vmovaps [rsp+0x50], xmm5
000079bd661d0bc7  vmovaps [rsp+0x60], xmm6
000079bd661d0bcd  vmovaps [rsp+0x70], xmm7
000079bd661d0bd3  vmovaps [rsp+0x80], xmm8
000079bd661d0bdc  vmovaps [rsp+0x90], xmm9
000079bd661d0be5  vmovaps [rsp+0xA0], xmm10
000079bd661d0bee  vmovaps [rsp+0xB0], xmm11
000079bd661d0bf7  vmovaps [rsp+0xC0], xmm12
000079bd661d0c00  vmovaps [rsp+0xD0], xmm14
000079bd661d0c09  vmovaps [rsp+0xE0], xmm15
000079bd661d0c12  sub rsp, 0x30
000079bd661d0c16  movaps [rsp], xmm13
000079bd661d0c1b  movaps [rsp+0x10], xmm14
000079bd661d0c21  movaps [rsp+0x20], xmm2
000079bd661d0c26  lea rdi, [rsp]
000079bd661d0c2a  mov esi, 0x00
000079bd661d0c2f  mov rax, 0x56EBD57B0530
000079bd661d0c39  call rax
000079bd661d0c3b  movaps xmm13, [rsp]
000079bd661d0c40  add rsp, 0x30
000079bd661d0c44  vmovaps xmm0, [rsp]
000079bd661d0c49  vmovaps xmm1, [rsp+0x10]
000079bd661d0c4f  vmovaps xmm2, [rsp+0x20]
000079bd661d0c55  vmovaps xmm3, [rsp+0x30]
000079bd661d0c5b  vmovaps xmm4, [rsp+0x40]
000079bd661d0c61  vmovaps xmm5, [rsp+0x50]
000079bd661d0c67  vmovaps xmm6, [rsp+0x60]
000079bd661d0c6d  vmovaps xmm7, [rsp+0x70]
000079bd661d0c73  vmovaps xmm8, [rsp+0x80]
000079bd661d0c7c  vmovaps xmm9, [rsp+0x90]
000079bd661d0c85  vmovaps xmm10, [rsp+0xA0]
000079bd661d0c8e  vmovaps xmm11, [rsp+0xB0]
000079bd661d0c97  vmovaps xmm12, [rsp+0xC0]
000079bd661d0ca0  vmovaps xmm14, [rsp+0xD0]
000079bd661d0ca9  vmovaps xmm15, [rsp+0xE0]
000079bd661d0cb2  add rsp, 0xF0
000079bd661d0cb9  pop r11
000079bd661d0cbb  pop r10
000079bd661d0cbd  pop r9
000079bd661d0cbf  pop r8
000079bd661d0cc1  pop rsi
000079bd661d0cc2  pop rdi
000079bd661d0cc3  pop rdx
000079bd661d0cc4  pop rcx
000079bd661d0cc5  pop rax
000079bd661d0cc6  add rsp, 0x08
000079bd661d0cca  jmp 0x000079BD661CF64C
000079bd661d0ccf  sub rsp, 0x08
000079bd661d0cd3  push rax
000079bd661d0cd4  push rcx
000079bd661d0cd5  push rdx
000079bd661d0cd6  push rdi
000079bd661d0cd7  push rsi
000079bd661d0cd8  push r8
000079bd661d0cda  push r9
000079bd661d0cdc  push r10
000079bd661d0cde  push r11
000079bd661d0ce0  sub rsp, 0xF0
000079bd661d0ce7  vmovaps [rsp], xmm0
000079bd661d0cec  vmovaps [rsp+0x10], xmm2
000079bd661d0cf2  vmovaps [rsp+0x20], xmm3
000079bd661d0cf8  vmovaps [rsp+0x30], xmm4
000079bd661d0cfe  vmovaps [rsp+0x40], xmm5
000079bd661d0d04  vmovaps [rsp+0x50], xmm6
000079bd661d0d0a  vmovaps [rsp+0x60], xmm7
000079bd661d0d10  vmovaps [rsp+0x70], xmm8
000079bd661d0d16  vmovaps [rsp+0x80], xmm9
000079bd661d0d1f  vmovaps [rsp+0x90], xmm10
000079bd661d0d28  vmovaps [rsp+0xA0], xmm11
000079bd661d0d31  vmovaps [rsp+0xB0], xmm12
000079bd661d0d3a  vmovaps [rsp+0xC0], xmm13
000079bd661d0d43  vmovaps [rsp+0xD0], xmm14
000079bd661d0d4c  vmovaps [rsp+0xE0], xmm15
000079bd661d0d55  sub rsp, 0x30
000079bd661d0d59  movaps [rsp], xmm1
000079bd661d0d5d  movaps [rsp+0x10], xmm10
000079bd661d0d63  movaps [rsp+0x20], xmm2
000079bd661d0d68  lea rdi, [rsp]
000079bd661d0d6c  mov esi, 0x00
000079bd661d0d71  mov rax, 0x56EBD57B0530
000079bd661d0d7b  call rax
000079bd661d0d7d  movaps xmm1, [rsp]
000079bd661d0d81  add rsp, 0x30
000079bd661d0d85  vmovaps xmm0, [rsp]
000079bd661d0d8a  vmovaps xmm2, [rsp+0x10]
000079bd661d0d90  vmovaps xmm3, [rsp+0x20]
000079bd661d0d96  vmovaps xmm4, [rsp+0x30]
000079bd661d0d9c  vmovaps xmm5, [rsp+0x40]
000079bd661d0da2  vmovaps xmm6, [rsp+0x50]
000079bd661d0da8  vmovaps xmm7, [rsp+0x60]
000079bd661d0dae  vmovaps xmm8, [rsp+0x70]
000079bd661d0db4  vmovaps xmm9, [rsp+0x80]
000079bd661d0dbd  vmovaps xmm10, [rsp+0x90]
000079bd661d0dc6  vmovaps xmm11, [rsp+0xA0]
000079bd661d0dcf  vmovaps xmm12, [rsp+0xB0]
000079bd661d0dd8  vmovaps xmm13, [rsp+0xC0]
000079bd661d0de1  vmovaps xmm14, [rsp+0xD0]
000079bd661d0dea  vmovaps xmm15, [rsp+0xE0]
000079bd661d0df3  add rsp, 0xF0
000079bd661d0dfa  pop r11
000079bd661d0dfc  pop r10
000079bd661d0dfe  pop r9
000079bd661d0e00  pop r8
000079bd661d0e02  pop rsi
000079bd661d0e03  pop rdi
000079bd661d0e04  pop rdx
000079bd661d0e05  pop rcx
000079bd661d0e06  pop rax
000079bd661d0e07  add rsp, 0x08
000079bd661d0e0b  jmp 0x000079BD661CF6B4
000079bd661d0e10  sub rsp, 0x08
000079bd661d0e14  push rax
000079bd661d0e15  push rcx
000079bd661d0e16  push rdx
000079bd661d0e17  push rdi
000079bd661d0e18  push rsi
000079bd661d0e19  push r8
000079bd661d0e1b  push r9
000079bd661d0e1d  push r10
000079bd661d0e1f  push r11
000079bd661d0e21  sub rsp, 0xF0
000079bd661d0e28  vmovaps [rsp], xmm0
000079bd661d0e2d  vmovaps [rsp+0x10], xmm1
000079bd661d0e33  vmovaps [rsp+0x20], xmm2
000079bd661d0e39  vmovaps [rsp+0x30], xmm3
000079bd661d0e3f  vmovaps [rsp+0x40], xmm4
000079bd661d0e45  vmovaps [rsp+0x50], xmm5
000079bd661d0e4b  vmovaps [rsp+0x60], xmm6
000079bd661d0e51  vmovaps [rsp+0x70], xmm7
000079bd661d0e57  vmovaps [rsp+0x80], xmm8
000079bd661d0e60  vmovaps [rsp+0x90], xmm9
000079bd661d0e69  vmovaps [rsp+0xA0], xmm10
000079bd661d0e72  vmovaps [rsp+0xB0], xmm11
000079bd661d0e7b  vmovaps [rsp+0xC0], xmm12
000079bd661d0e84  vmovaps [rsp+0xD0], xmm13
000079bd661d0e8d  vmovaps [rsp+0xE0], xmm14
000079bd661d0e96  sub rsp, 0x30
000079bd661d0e9a  movaps [rsp], xmm15
000079bd661d0e9f  movaps [rsp+0x10], xmm10
000079bd661d0ea5  movaps [rsp+0x20], xmm2
000079bd661d0eaa  lea rdi, [rsp]
000079bd661d0eae  mov esi, 0x00
000079bd661d0eb3  mov rax, 0x56EBD57B0530
000079bd661d0ebd  call rax
000079bd661d0ebf  movaps xmm15, [rsp]
000079bd661d0ec4  add rsp, 0x30
000079bd661d0ec8  vmovaps xmm0, [rsp]
000079bd661d0ecd  vmovaps xmm1, [rsp+0x10]
000079bd661d0ed3  vmovaps xmm2, [rsp+0x20]
000079bd661d0ed9  vmovaps xmm3, [rsp+0x30]
000079bd661d0edf  vmovaps xmm4, [rsp+0x40]
000079bd661d0ee5  vmovaps xmm5, [rsp+0x50]
000079bd661d0eeb  vmovaps xmm6, [rsp+0x60]
000079bd661d0ef1  vmovaps xmm7, [rsp+0x70]
000079bd661d0ef7  vmovaps xmm8, [rsp+0x80]
000079bd661d0f00  vmovaps xmm9, [rsp+0x90]
000079bd661d0f09  vmovaps xmm10, [rsp+0xA0]
000079bd661d0f12  vmovaps xmm11, [rsp+0xB0]
000079bd661d0f1b  vmovaps xmm12, [rsp+0xC0]
000079bd661d0f24  vmovaps xmm13, [rsp+0xD0]
000079bd661d0f2d  vmovaps xmm14, [rsp+0xE0]
000079bd661d0f36  add rsp, 0xF0
000079bd661d0f3d  pop r11
000079bd661d0f3f  pop r10
000079bd661d0f41  pop r9
000079bd661d0f43  pop r8
000079bd661d0f45  pop rsi
000079bd661d0f46  pop rdi
000079bd661d0f47  pop rdx
000079bd661d0f48  pop rcx
000079bd661d0f49  pop rax
000079bd661d0f4a  add rsp, 0x08
000079bd661d0f4e  jmp 0x000079BD661CF706
000079bd661d0f53  sub rsp, 0x08
000079bd661d0f57  push rax
000079bd661d0f58  push rcx
000079bd661d0f59  push rdx
000079bd661d0f5a  push rdi
000079bd661d0f5b  push rsi
000079bd661d0f5c  push r8
000079bd661d0f5e  push r9
000079bd661d0f60  push r10
000079bd661d0f62  push r11
000079bd661d0f64  sub rsp, 0xF0
000079bd661d0f6b  vmovaps [rsp], xmm0
000079bd661d0f70  vmovaps [rsp+0x10], xmm2
000079bd661d0f76  vmovaps [rsp+0x20], xmm3
000079bd661d0f7c  vmovaps [rsp+0x30], xmm4
000079bd661d0f82  vmovaps [rsp+0x40], xmm5
000079bd661d0f88  vmovaps [rsp+0x50], xmm6
000079bd661d0f8e  vmovaps [rsp+0x60], xmm7
000079bd661d0f94  vmovaps [rsp+0x70], xmm8
000079bd661d0f9a  vmovaps [rsp+0x80], xmm9
000079bd661d0fa3  vmovaps [rsp+0x90], xmm10
000079bd661d0fac  vmovaps [rsp+0xA0], xmm11
000079bd661d0fb5  vmovaps [rsp+0xB0], xmm12
000079bd661d0fbe  vmovaps [rsp+0xC0], xmm13
000079bd661d0fc7  vmovaps [rsp+0xD0], xmm14
000079bd661d0fd0  vmovaps [rsp+0xE0], xmm15
000079bd661d0fd9  sub rsp, 0x30
000079bd661d0fdd  movaps [rsp], xmm1
000079bd661d0fe1  movaps [rsp+0x10], xmm10
000079bd661d0fe7  movaps [rsp+0x20], xmm12
000079bd661d0fed  lea rdi, [rsp]
000079bd661d0ff1  mov esi, 0x00
000079bd661d0ff6  mov rax, 0x56EBD57B0530
000079bd661d1000  call rax
000079bd661d1002  movaps xmm1, [rsp]
000079bd661d1006  add rsp, 0x30
000079bd661d100a  vmovaps xmm0, [rsp]
000079bd661d100f  vmovaps xmm2, [rsp+0x10]
000079bd661d1015  vmovaps xmm3, [rsp+0x20]
000079bd661d101b  vmovaps xmm4, [rsp+0x30]
000079bd661d1021  vmovaps xmm5, [rsp+0x40]
000079bd661d1027  vmovaps xmm6, [rsp+0x50]
000079bd661d102d  vmovaps xmm7, [rsp+0x60]
000079bd661d1033  vmovaps xmm8, [rsp+0x70]
000079bd661d1039  vmovaps xmm9, [rsp+0x80]
000079bd661d1042  vmovaps xmm10, [rsp+0x90]
000079bd661d104b  vmovaps xmm11, [rsp+0xA0]
000079bd661d1054  vmovaps xmm12, [rsp+0xB0]
000079bd661d105d  vmovaps xmm13, [rsp+0xC0]
000079bd661d1066  vmovaps xmm14, [rsp+0xD0]
000079bd661d106f  vmovaps xmm15, [rsp+0xE0]
000079bd661d1078  add rsp, 0xF0
000079bd661d107f  pop r11
000079bd661d1081  pop r10
000079bd661d1083  pop r9
000079bd661d1085  pop r8
000079bd661d1087  pop rsi
000079bd661d1088  pop rdi
000079bd661d1089  pop rdx
000079bd661d108a  pop rcx
000079bd661d108b  pop rax
000079bd661d108c  add rsp, 0x08
000079bd661d1090  jmp 0x000079BD661CF732
000079bd661d1095  sub rsp, 0x08
000079bd661d1099  push rax
000079bd661d109a  push rcx
000079bd661d109b  push rdx
000079bd661d109c  push rdi
000079bd661d109d  push rsi
000079bd661d109e  push r8
000079bd661d10a0  push r9
000079bd661d10a2  push r10
000079bd661d10a4  push r11
000079bd661d10a6  sub rsp, 0xF0
000079bd661d10ad  vmovaps [rsp], xmm0
000079bd661d10b2  vmovaps [rsp+0x10], xmm1
000079bd661d10b8  vmovaps [rsp+0x20], xmm2
000079bd661d10be  vmovaps [rsp+0x30], xmm3
000079bd661d10c4  vmovaps [rsp+0x40], xmm4
000079bd661d10ca  vmovaps [rsp+0x50], xmm5
000079bd661d10d0  vmovaps [rsp+0x60], xmm6
000079bd661d10d6  vmovaps [rsp+0x70], xmm7
000079bd661d10dc  vmovaps [rsp+0x80], xmm8
000079bd661d10e5  vmovaps [rsp+0x90], xmm9
000079bd661d10ee  vmovaps [rsp+0xA0], xmm10
000079bd661d10f7  vmovaps [rsp+0xB0], xmm11
000079bd661d1100  vmovaps [rsp+0xC0], xmm12
000079bd661d1109  vmovaps [rsp+0xD0], xmm13
000079bd661d1112  vmovaps [rsp+0xE0], xmm14
000079bd661d111b  sub rsp, 0x30
000079bd661d111f  movaps [rsp], xmm15
000079bd661d1124  movaps [rsp+0x10], xmm10
000079bd661d112a  movaps [rsp+0x20], xmm12
000079bd661d1130  lea rdi, [rsp]
000079bd661d1134  mov esi, 0x00
000079bd661d1139  mov rax, 0x56EBD57B0530
000079bd661d1143  call rax
000079bd661d1145  movaps xmm15, [rsp]
000079bd661d114a  add rsp, 0x30
000079bd661d114e  vmovaps xmm0, [rsp]
000079bd661d1153  vmovaps xmm1, [rsp+0x10]
000079bd661d1159  vmovaps xmm2, [rsp+0x20]
000079bd661d115f  vmovaps xmm3, [rsp+0x30]
000079bd661d1165  vmovaps xmm4, [rsp+0x40]
000079bd661d116b  vmovaps xmm5, [rsp+0x50]
000079bd661d1171  vmovaps xmm6, [rsp+0x60]
000079bd661d1177  vmovaps xmm7, [rsp+0x70]
000079bd661d117d  vmovaps xmm8, [rsp+0x80]
000079bd661d1186  vmovaps xmm9, [rsp+0x90]
000079bd661d118f  vmovaps xmm10, [rsp+0xA0]
000079bd661d1198  vmovaps xmm11, [rsp+0xB0]
000079bd661d11a1  vmovaps xmm12, [rsp+0xC0]
000079bd661d11aa  vmovaps xmm13, [rsp+0xD0]
000079bd661d11b3  vmovaps xmm14, [rsp+0xE0]
000079bd661d11bc  add rsp, 0xF0
000079bd661d11c3  pop r11
000079bd661d11c5  pop r10
000079bd661d11c7  pop r9
000079bd661d11c9  pop r8
000079bd661d11cb  pop rsi
000079bd661d11cc  pop rdi
000079bd661d11cd  pop rdx
000079bd661d11ce  pop rcx
000079bd661d11cf  pop rax
000079bd661d11d0  add rsp, 0x08
000079bd661d11d4  jmp 0x000079BD661CF75E
000079bd661d11d9  call 0x000079BD65FFF430
000079bd661d11de  jmp 0x000079BD661CF7EE
000079bd661d11e3  call 0x000079BD65FFF430
000079bd661d11e8  jmp 0x000079BD661CF801
000079bd661d11ed  sub rsp, 0x08
000079bd661d11f1  push rax
000079bd661d11f2  push rcx
000079bd661d11f3  push rdx
000079bd661d11f4  push rdi
000079bd661d11f5  push rsi
000079bd661d11f6  push r8
000079bd661d11f8  push r9
000079bd661d11fa  push r10
000079bd661d11fc  push r11
000079bd661d11fe  sub rsp, 0xF0
000079bd661d1205  vmovaps [rsp], xmm0
000079bd661d120a  vmovaps [rsp+0x10], xmm2
000079bd661d1210  vmovaps [rsp+0x20], xmm3
000079bd661d1216  vmovaps [rsp+0x30], xmm4
000079bd661d121c  vmovaps [rsp+0x40], xmm5
000079bd661d1222  vmovaps [rsp+0x50], xmm6
000079bd661d1228  vmovaps [rsp+0x60], xmm7
000079bd661d122e  vmovaps [rsp+0x70], xmm8
000079bd661d1234  vmovaps [rsp+0x80], xmm9
000079bd661d123d  vmovaps [rsp+0x90], xmm10
000079bd661d1246  vmovaps [rsp+0xA0], xmm11
000079bd661d124f  vmovaps [rsp+0xB0], xmm12
000079bd661d1258  vmovaps [rsp+0xC0], xmm13
000079bd661d1261  vmovaps [rsp+0xD0], xmm14
000079bd661d126a  vmovaps [rsp+0xE0], xmm15
000079bd661d1273  sub rsp, 0x30
000079bd661d1277  movaps [rsp], xmm1
000079bd661d127b  movaps [rsp+0x10], xmm13
000079bd661d1281  movaps [rsp+0x20], xmm2
000079bd661d1286  lea rdi, [rsp]
000079bd661d128a  mov esi, 0x00
000079bd661d128f  mov rax, 0x56EBD57B0530
000079bd661d1299  call rax
000079bd661d129b  movaps xmm1, [rsp]
000079bd661d129f  add rsp, 0x30
000079bd661d12a3  vmovaps xmm0, [rsp]
000079bd661d12a8  vmovaps xmm2, [rsp+0x10]
000079bd661d12ae  vmovaps xmm3, [rsp+0x20]
000079bd661d12b4  vmovaps xmm4, [rsp+0x30]
000079bd661d12ba  vmovaps xmm5, [rsp+0x40]
000079bd661d12c0  vmovaps xmm6, [rsp+0x50]
000079bd661d12c6  vmovaps xmm7, [rsp+0x60]
000079bd661d12cc  vmovaps xmm8, [rsp+0x70]
000079bd661d12d2  vmovaps xmm9, [rsp+0x80]
000079bd661d12db  vmovaps xmm10, [rsp+0x90]
000079bd661d12e4  vmovaps xmm11, [rsp+0xA0]
000079bd661d12ed  vmovaps xmm12, [rsp+0xB0]
000079bd661d12f6  vmovaps xmm13, [rsp+0xC0]
000079bd661d12ff  vmovaps xmm14, [rsp+0xD0]
000079bd661d1308  vmovaps xmm15, [rsp+0xE0]
000079bd661d1311  add rsp, 0xF0
000079bd661d1318  pop r11
000079bd661d131a  pop r10
000079bd661d131c  pop r9
000079bd661d131e  pop r8
000079bd661d1320  pop rsi
000079bd661d1321  pop rdi
000079bd661d1322  pop rdx
000079bd661d1323  pop rcx
000079bd661d1324  pop rax
000079bd661d1325  add rsp, 0x08
000079bd661d1329  jmp 0x000079BD661CF82C
000079bd661d132e  call 0x000079BD6600E760
000079bd661d1333  jmp 0x000079BD661CF839
000079bd661d1338  sub rsp, 0x08
000079bd661d133c  push rax
000079bd661d133d  push rcx
000079bd661d133e  push rdx
000079bd661d133f  push rdi
000079bd661d1340  push rsi
000079bd661d1341  push r8
000079bd661d1343  push r9
000079bd661d1345  push r10
000079bd661d1347  push r11
000079bd661d1349  sub rsp, 0xF0
000079bd661d1350  vmovaps [rsp], xmm0
000079bd661d1355  vmovaps [rsp+0x10], xmm1
000079bd661d135b  vmovaps [rsp+0x20], xmm2
000079bd661d1361  vmovaps [rsp+0x30], xmm3
000079bd661d1367  vmovaps [rsp+0x40], xmm4
000079bd661d136d  vmovaps [rsp+0x50], xmm5
000079bd661d1373  vmovaps [rsp+0x60], xmm6
000079bd661d1379  vmovaps [rsp+0x70], xmm7
000079bd661d137f  vmovaps [rsp+0x80], xmm8
000079bd661d1388  vmovaps [rsp+0x90], xmm9
000079bd661d1391  vmovaps [rsp+0xA0], xmm10
000079bd661d139a  vmovaps [rsp+0xB0], xmm11
000079bd661d13a3  vmovaps [rsp+0xC0], xmm12
000079bd661d13ac  vmovaps [rsp+0xD0], xmm14
000079bd661d13b5  vmovaps [rsp+0xE0], xmm15
000079bd661d13be  sub rsp, 0x30
000079bd661d13c2  movaps [rsp], xmm13
000079bd661d13c7  movaps [rsp+0x10], xmm2
000079bd661d13cc  movaps [rsp+0x20], xmm1
000079bd661d13d1  lea rdi, [rsp]
000079bd661d13d5  mov esi, 0x00
000079bd661d13da  mov rax, 0x56EBD57B0530
000079bd661d13e4  call rax
000079bd661d13e6  movaps xmm13, [rsp]
000079bd661d13eb  add rsp, 0x30
000079bd661d13ef  vmovaps xmm0, [rsp]
000079bd661d13f4  vmovaps xmm1, [rsp+0x10]
000079bd661d13fa  vmovaps xmm2, [rsp+0x20]
000079bd661d1400  vmovaps xmm3, [rsp+0x30]
000079bd661d1406  vmovaps xmm4, [rsp+0x40]
000079bd661d140c  vmovaps xmm5, [rsp+0x50]
000079bd661d1412  vmovaps xmm6, [rsp+0x60]
000079bd661d1418  vmovaps xmm7, [rsp+0x70]
000079bd661d141e  vmovaps xmm8, [rsp+0x80]
000079bd661d1427  vmovaps xmm9, [rsp+0x90]
000079bd661d1430  vmovaps xmm10, [rsp+0xA0]
000079bd661d1439  vmovaps xmm11, [rsp+0xB0]
000079bd661d1442  vmovaps xmm12, [rsp+0xC0]
000079bd661d144b  vmovaps xmm14, [rsp+0xD0]
000079bd661d1454  vmovaps xmm15, [rsp+0xE0]
000079bd661d145d  add rsp, 0xF0
000079bd661d1464  pop r11
000079bd661d1466  pop r10
000079bd661d1468  pop r9
000079bd661d146a  pop r8
000079bd661d146c  pop rsi
000079bd661d146d  pop rdi
000079bd661d146e  pop rdx
000079bd661d146f  pop rcx
000079bd661d1470  pop rax
000079bd661d1471  add rsp, 0x08
000079bd661d1475  jmp 0x000079BD661CF878
000079bd661d147a  sub rsp, 0x08
000079bd661d147e  push rax
000079bd661d147f  push rcx
000079bd661d1480  push rdx
000079bd661d1481  push rdi
000079bd661d1482  push rsi
000079bd661d1483  push r8
000079bd661d1485  push r9
000079bd661d1487  push r10
000079bd661d1489  push r11
000079bd661d148b  sub rsp, 0xF0
000079bd661d1492  vmovaps [rsp], xmm0
000079bd661d1497  vmovaps [rsp+0x10], xmm2
000079bd661d149d  vmovaps [rsp+0x20], xmm3
000079bd661d14a3  vmovaps [rsp+0x30], xmm4
000079bd661d14a9  vmovaps [rsp+0x40], xmm5
000079bd661d14af  vmovaps [rsp+0x50], xmm6
000079bd661d14b5  vmovaps [rsp+0x60], xmm7
000079bd661d14bb  vmovaps [rsp+0x70], xmm8
000079bd661d14c1  vmovaps [rsp+0x80], xmm9
000079bd661d14ca  vmovaps [rsp+0x90], xmm10
000079bd661d14d3  vmovaps [rsp+0xA0], xmm11
000079bd661d14dc  vmovaps [rsp+0xB0], xmm12
000079bd661d14e5  vmovaps [rsp+0xC0], xmm13
000079bd661d14ee  vmovaps [rsp+0xD0], xmm14
000079bd661d14f7  vmovaps [rsp+0xE0], xmm15
000079bd661d1500  sub rsp, 0x30
000079bd661d1504  movaps [rsp], xmm1
000079bd661d1508  movaps [rsp+0x10], xmm15
000079bd661d150e  movaps [rsp+0x20], xmm2
000079bd661d1513  lea rdi, [rsp]
000079bd661d1517  mov esi, 0x00
000079bd661d151c  mov rax, 0x56EBD57B0530
000079bd661d1526  call rax
000079bd661d1528  movaps xmm1, [rsp]
000079bd661d152c  add rsp, 0x30
000079bd661d1530  vmovaps xmm0, [rsp]
000079bd661d1535  vmovaps xmm2, [rsp+0x10]
000079bd661d153b  vmovaps xmm3, [rsp+0x20]
000079bd661d1541  vmovaps xmm4, [rsp+0x30]
000079bd661d1547  vmovaps xmm5, [rsp+0x40]
000079bd661d154d  vmovaps xmm6, [rsp+0x50]
000079bd661d1553  vmovaps xmm7, [rsp+0x60]
000079bd661d1559  vmovaps xmm8, [rsp+0x70]
000079bd661d155f  vmovaps xmm9, [rsp+0x80]
000079bd661d1568  vmovaps xmm10, [rsp+0x90]
000079bd661d1571  vmovaps xmm11, [rsp+0xA0]
000079bd661d157a  vmovaps xmm12, [rsp+0xB0]
000079bd661d1583  vmovaps xmm13, [rsp+0xC0]
000079bd661d158c  vmovaps xmm14, [rsp+0xD0]
000079bd661d1595  vmovaps xmm15, [rsp+0xE0]
000079bd661d159e  add rsp, 0xF0
000079bd661d15a5  pop r11
000079bd661d15a7  pop r10
000079bd661d15a9  pop r9
000079bd661d15ab  pop r8
000079bd661d15ad  pop rsi
000079bd661d15ae  pop rdi
000079bd661d15af  pop rdx
000079bd661d15b0  pop rcx
000079bd661d15b1  pop rax
000079bd661d15b2  add rsp, 0x08
000079bd661d15b6  jmp 0x000079BD661CF8AC
000079bd661d15bb  sub rsp, 0x08
000079bd661d15bf  push rax
000079bd661d15c0  push rcx
000079bd661d15c1  push rdx
000079bd661d15c2  push rdi
000079bd661d15c3  push rsi
000079bd661d15c4  push r8
000079bd661d15c6  push r9
000079bd661d15c8  push r10
000079bd661d15ca  push r11
000079bd661d15cc  sub rsp, 0xF0
000079bd661d15d3  vmovaps [rsp], xmm0
000079bd661d15d8  vmovaps [rsp+0x10], xmm1
000079bd661d15de  vmovaps [rsp+0x20], xmm2
000079bd661d15e4  vmovaps [rsp+0x30], xmm3
000079bd661d15ea  vmovaps [rsp+0x40], xmm4
000079bd661d15f0  vmovaps [rsp+0x50], xmm5
000079bd661d15f6  vmovaps [rsp+0x60], xmm6
000079bd661d15fc  vmovaps [rsp+0x70], xmm7
000079bd661d1602  vmovaps [rsp+0x80], xmm8
000079bd661d160b  vmovaps [rsp+0x90], xmm9
000079bd661d1614  vmovaps [rsp+0xA0], xmm10
000079bd661d161d  vmovaps [rsp+0xB0], xmm11
000079bd661d1626  vmovaps [rsp+0xC0], xmm12
000079bd661d162f  vmovaps [rsp+0xD0], xmm13
000079bd661d1638  vmovaps [rsp+0xE0], xmm15
000079bd661d1641  sub rsp, 0x30
000079bd661d1645  movaps [rsp], xmm14
000079bd661d164a  movaps [rsp+0x10], xmm2
000079bd661d164f  movaps [rsp+0x20], xmm15
000079bd661d1655  lea rdi, [rsp]
000079bd661d1659  mov esi, 0x00
000079bd661d165e  mov rax, 0x56EBD57B0530
000079bd661d1668  call rax
000079bd661d166a  movaps xmm14, [rsp]
000079bd661d166f  add rsp, 0x30
000079bd661d1673  vmovaps xmm0, [rsp]
000079bd661d1678  vmovaps xmm1, [rsp+0x10]
000079bd661d167e  vmovaps xmm2, [rsp+0x20]
000079bd661d1684  vmovaps xmm3, [rsp+0x30]
000079bd661d168a  vmovaps xmm4, [rsp+0x40]
000079bd661d1690  vmovaps xmm5, [rsp+0x50]
000079bd661d1696  vmovaps xmm6, [rsp+0x60]
000079bd661d169c  vmovaps xmm7, [rsp+0x70]
000079bd661d16a2  vmovaps xmm8, [rsp+0x80]
000079bd661d16ab  vmovaps xmm9, [rsp+0x90]
000079bd661d16b4  vmovaps xmm10, [rsp+0xA0]
000079bd661d16bd  vmovaps xmm11, [rsp+0xB0]
000079bd661d16c6  vmovaps xmm12, [rsp+0xC0]
000079bd661d16cf  vmovaps xmm13, [rsp+0xD0]
000079bd661d16d8  vmovaps xmm15, [rsp+0xE0]
000079bd661d16e1  add rsp, 0xF0
000079bd661d16e8  pop r11
000079bd661d16ea  pop r10
000079bd661d16ec  pop r9
000079bd661d16ee  pop r8
000079bd661d16f0  pop rsi
000079bd661d16f1  pop rdi
000079bd661d16f2  pop rdx
000079bd661d16f3  pop rcx
000079bd661d16f4  pop rax
000079bd661d16f5  add rsp, 0x08
000079bd661d16f9  jmp 0x000079BD661CF8E7
000079bd661d16fe  sub rsp, 0x08
000079bd661d1702  push rax
000079bd661d1703  push rcx
000079bd661d1704  push rdx
000079bd661d1705  push rdi
000079bd661d1706  push rsi
000079bd661d1707  push r8
000079bd661d1709  push r9
000079bd661d170b  push r10
000079bd661d170d  push r11
000079bd661d170f  sub rsp, 0xF0
000079bd661d1716  vmovaps [rsp], xmm0
000079bd661d171b  vmovaps [rsp+0x10], xmm1
000079bd661d1721  vmovaps [rsp+0x20], xmm2
000079bd661d1727  vmovaps [rsp+0x30], xmm3
000079bd661d172d  vmovaps [rsp+0x40], xmm4
000079bd661d1733  vmovaps [rsp+0x50], xmm5
000079bd661d1739  vmovaps [rsp+0x60], xmm6
000079bd661d173f  vmovaps [rsp+0x70], xmm7
000079bd661d1745  vmovaps [rsp+0x80], xmm8
000079bd661d174e  vmovaps [rsp+0x90], xmm9
000079bd661d1757  vmovaps [rsp+0xA0], xmm10
000079bd661d1760  vmovaps [rsp+0xB0], xmm11
000079bd661d1769  vmovaps [rsp+0xC0], xmm12
000079bd661d1772  vmovaps [rsp+0xD0], xmm13
000079bd661d177b  vmovaps [rsp+0xE0], xmm14
000079bd661d1784  sub rsp, 0x30
000079bd661d1788  movaps [rsp], xmm15
000079bd661d178d  movaps [rsp+0x10], xmm2
000079bd661d1792  movaps [rsp+0x20], xmm1
000079bd661d1797  lea rdi, [rsp]
000079bd661d179b  mov esi, 0x00
000079bd661d17a0  mov rax, 0x56EBD57B0530
000079bd661d17aa  call rax
000079bd661d17ac  movaps xmm15, [rsp]
000079bd661d17b1  add rsp, 0x30
000079bd661d17b5  vmovaps xmm0, [rsp]
000079bd661d17ba  vmovaps xmm1, [rsp+0x10]
000079bd661d17c0  vmovaps xmm2, [rsp+0x20]
000079bd661d17c6  vmovaps xmm3, [rsp+0x30]
000079bd661d17cc  vmovaps xmm4, [rsp+0x40]
000079bd661d17d2  vmovaps xmm5, [rsp+0x50]
000079bd661d17d8  vmovaps xmm6, [rsp+0x60]
000079bd661d17de  vmovaps xmm7, [rsp+0x70]
000079bd661d17e4  vmovaps xmm8, [rsp+0x80]
000079bd661d17ed  vmovaps xmm9, [rsp+0x90]
000079bd661d17f6  vmovaps xmm10, [rsp+0xA0]
000079bd661d17ff  vmovaps xmm11, [rsp+0xB0]
000079bd661d1808  vmovaps xmm12, [rsp+0xC0]
000079bd661d1811  vmovaps xmm13, [rsp+0xD0]
000079bd661d181a  vmovaps xmm14, [rsp+0xE0]
000079bd661d1823  add rsp, 0xF0
000079bd661d182a  pop r11
000079bd661d182c  pop r10
000079bd661d182e  pop r9
000079bd661d1830  pop r8
000079bd661d1832  pop rsi
000079bd661d1833  pop rdi
000079bd661d1834  pop rdx
000079bd661d1835  pop rcx
000079bd661d1836  pop rax
000079bd661d1837  add rsp, 0x08
000079bd661d183b  jmp 0x000079BD661CF923
000079bd661d1840  call 0x000079BD65FFF430
000079bd661d1845  jmp 0x000079BD661CF930
000079bd661d184a  sub rsp, 0x08
000079bd661d184e  push rax
000079bd661d184f  push rcx
000079bd661d1850  push rdx
000079bd661d1851  push rdi
000079bd661d1852  push rsi
000079bd661d1853  push r8
000079bd661d1855  push r9
000079bd661d1857  push r10
000079bd661d1859  push r11
000079bd661d185b  sub rsp, 0xF0
000079bd661d1862  vmovaps [rsp], xmm0
000079bd661d1867  vmovaps [rsp+0x10], xmm1
000079bd661d186d  vmovaps [rsp+0x20], xmm3
000079bd661d1873  vmovaps [rsp+0x30], xmm4
000079bd661d1879  vmovaps [rsp+0x40], xmm5
000079bd661d187f  vmovaps [rsp+0x50], xmm6
000079bd661d1885  vmovaps [rsp+0x60], xmm7
000079bd661d188b  vmovaps [rsp+0x70], xmm8
000079bd661d1891  vmovaps [rsp+0x80], xmm9
000079bd661d189a  vmovaps [rsp+0x90], xmm10
000079bd661d18a3  vmovaps [rsp+0xA0], xmm11
000079bd661d18ac  vmovaps [rsp+0xB0], xmm12
000079bd661d18b5  vmovaps [rsp+0xC0], xmm13
000079bd661d18be  vmovaps [rsp+0xD0], xmm14
000079bd661d18c7  vmovaps [rsp+0xE0], xmm15
000079bd661d18d0  sub rsp, 0x30
000079bd661d18d4  movaps [rsp], xmm2
000079bd661d18d8  movaps [rsp+0x10], xmm1
000079bd661d18dd  movaps [rsp+0x20], xmm14
000079bd661d18e3  lea rdi, [rsp]
000079bd661d18e7  mov esi, 0x00
000079bd661d18ec  mov rax, 0x56EBD57B0530
000079bd661d18f6  call rax
000079bd661d18f8  movaps xmm2, [rsp]
000079bd661d18fc  add rsp, 0x30
000079bd661d1900  vmovaps xmm0, [rsp]
000079bd661d1905  vmovaps xmm1, [rsp+0x10]
000079bd661d190b  vmovaps xmm3, [rsp+0x20]
000079bd661d1911  vmovaps xmm4, [rsp+0x30]
000079bd661d1917  vmovaps xmm5, [rsp+0x40]
000079bd661d191d  vmovaps xmm6, [rsp+0x50]
000079bd661d1923  vmovaps xmm7, [rsp+0x60]
000079bd661d1929  vmovaps xmm8, [rsp+0x70]
000079bd661d192f  vmovaps xmm9, [rsp+0x80]
000079bd661d1938  vmovaps xmm10, [rsp+0x90]
000079bd661d1941  vmovaps xmm11, [rsp+0xA0]
000079bd661d194a  vmovaps xmm12, [rsp+0xB0]
000079bd661d1953  vmovaps xmm13, [rsp+0xC0]
000079bd661d195c  vmovaps xmm14, [rsp+0xD0]
000079bd661d1965  vmovaps xmm15, [rsp+0xE0]
000079bd661d196e  add rsp, 0xF0
000079bd661d1975  pop r11
000079bd661d1977  pop r10
000079bd661d1979  pop r9
000079bd661d197b  pop r8
000079bd661d197d  pop rsi
000079bd661d197e  pop rdi
000079bd661d197f  pop rdx
000079bd661d1980  pop rcx
000079bd661d1981  pop rax
000079bd661d1982  add rsp, 0x08
000079bd661d1986  jmp 0x000079BD661CF96D
000079bd661d198b  sub rsp, 0x08
000079bd661d198f  push rax
000079bd661d1990  push rcx
000079bd661d1991  push rdx
000079bd661d1992  push rdi
000079bd661d1993  push rsi
000079bd661d1994  push r8
000079bd661d1996  push r9
000079bd661d1998  push r10
000079bd661d199a  push r11
000079bd661d199c  sub rsp, 0xF0
000079bd661d19a3  vmovaps [rsp], xmm0
000079bd661d19a8  vmovaps [rsp+0x10], xmm1
000079bd661d19ae  vmovaps [rsp+0x20], xmm2
000079bd661d19b4  vmovaps [rsp+0x30], xmm3
000079bd661d19ba  vmovaps [rsp+0x40], xmm4
000079bd661d19c0  vmovaps [rsp+0x50], xmm5
000079bd661d19c6  vmovaps [rsp+0x60], xmm6
000079bd661d19cc  vmovaps [rsp+0x70], xmm7
000079bd661d19d2  vmovaps [rsp+0x80], xmm8
000079bd661d19db  vmovaps [rsp+0x90], xmm9
000079bd661d19e4  vmovaps [rsp+0xA0], xmm10
000079bd661d19ed  vmovaps [rsp+0xB0], xmm11
000079bd661d19f6  vmovaps [rsp+0xC0], xmm12
000079bd661d19ff  vmovaps [rsp+0xD0], xmm13
000079bd661d1a08  vmovaps [rsp+0xE0], xmm14
000079bd661d1a11  sub rsp, 0x30
000079bd661d1a15  movaps [rsp], xmm15
000079bd661d1a1a  movaps [rsp+0x10], xmm14
000079bd661d1a20  movaps [rsp+0x20], xmm1
000079bd661d1a25  lea rdi, [rsp]
000079bd661d1a29  mov esi, 0x00
000079bd661d1a2e  mov rax, 0x56EBD57B0530
000079bd661d1a38  call rax
000079bd661d1a3a  movaps xmm15, [rsp]
000079bd661d1a3f  add rsp, 0x30
000079bd661d1a43  vmovaps xmm0, [rsp]
000079bd661d1a48  vmovaps xmm1, [rsp+0x10]
000079bd661d1a4e  vmovaps xmm2, [rsp+0x20]
000079bd661d1a54  vmovaps xmm3, [rsp+0x30]
000079bd661d1a5a  vmovaps xmm4, [rsp+0x40]
000079bd661d1a60  vmovaps xmm5, [rsp+0x50]
000079bd661d1a66  vmovaps xmm6, [rsp+0x60]
000079bd661d1a6c  vmovaps xmm7, [rsp+0x70]
000079bd661d1a72  vmovaps xmm8, [rsp+0x80]
000079bd661d1a7b  vmovaps xmm9, [rsp+0x90]
000079bd661d1a84  vmovaps xmm10, [rsp+0xA0]
000079bd661d1a8d  vmovaps xmm11, [rsp+0xB0]
000079bd661d1a96  vmovaps xmm12, [rsp+0xC0]
000079bd661d1a9f  vmovaps xmm13, [rsp+0xD0]
000079bd661d1aa8  vmovaps xmm14, [rsp+0xE0]
000079bd661d1ab1  add rsp, 0xF0
000079bd661d1ab8  pop r11
000079bd661d1aba  pop r10
000079bd661d1abc  pop r9
000079bd661d1abe  pop r8
000079bd661d1ac0  pop rsi
000079bd661d1ac1  pop rdi
000079bd661d1ac2  pop rdx
000079bd661d1ac3  pop rcx
000079bd661d1ac4  pop rax
000079bd661d1ac5  add rsp, 0x08
000079bd661d1ac9  jmp 0x000079BD661CF9E7
000079bd661d1ace  call 0x000079BD65FFF430
000079bd661d1ad3  jmp 0x000079BD661CF9F4
000079bd661d1ad8  sub rsp, 0x08
000079bd661d1adc  push rax
000079bd661d1add  push rcx
000079bd661d1ade  push rdx
000079bd661d1adf  push rdi
000079bd661d1ae0  push rsi
000079bd661d1ae1  push r8
000079bd661d1ae3  push r9
000079bd661d1ae5  push r10
000079bd661d1ae7  push r11
000079bd661d1ae9  sub rsp, 0xF0
000079bd661d1af0  vmovaps [rsp], xmm0
000079bd661d1af5  vmovaps [rsp+0x10], xmm1
000079bd661d1afb  vmovaps [rsp+0x20], xmm2
000079bd661d1b01  vmovaps [rsp+0x30], xmm3
000079bd661d1b07  vmovaps [rsp+0x40], xmm4
000079bd661d1b0d  vmovaps [rsp+0x50], xmm5
000079bd661d1b13  vmovaps [rsp+0x60], xmm6
000079bd661d1b19  vmovaps [rsp+0x70], xmm7
000079bd661d1b1f  vmovaps [rsp+0x80], xmm8
000079bd661d1b28  vmovaps [rsp+0x90], xmm9
000079bd661d1b31  vmovaps [rsp+0xA0], xmm10
000079bd661d1b3a  vmovaps [rsp+0xB0], xmm11
000079bd661d1b43  vmovaps [rsp+0xC0], xmm12
000079bd661d1b4c  vmovaps [rsp+0xD0], xmm13
000079bd661d1b55  vmovaps [rsp+0xE0], xmm15
000079bd661d1b5e  sub rsp, 0x30
000079bd661d1b62  movaps [rsp], xmm14
000079bd661d1b67  movaps [rsp+0x10], xmm13
000079bd661d1b6d  movaps [rsp+0x20], xmm1
000079bd661d1b72  lea rdi, [rsp]
000079bd661d1b76  mov esi, 0x00
000079bd661d1b7b  mov rax, 0x56EBD57B0530
000079bd661d1b85  call rax
000079bd661d1b87  movaps xmm14, [rsp]
000079bd661d1b8c  add rsp, 0x30
000079bd661d1b90  vmovaps xmm0, [rsp]
000079bd661d1b95  vmovaps xmm1, [rsp+0x10]
000079bd661d1b9b  vmovaps xmm2, [rsp+0x20]
000079bd661d1ba1  vmovaps xmm3, [rsp+0x30]
000079bd661d1ba7  vmovaps xmm4, [rsp+0x40]
000079bd661d1bad  vmovaps xmm5, [rsp+0x50]
000079bd661d1bb3  vmovaps xmm6, [rsp+0x60]
000079bd661d1bb9  vmovaps xmm7, [rsp+0x70]
000079bd661d1bbf  vmovaps xmm8, [rsp+0x80]
000079bd661d1bc8  vmovaps xmm9, [rsp+0x90]
000079bd661d1bd1  vmovaps xmm10, [rsp+0xA0]
000079bd661d1bda  vmovaps xmm11, [rsp+0xB0]
000079bd661d1be3  vmovaps xmm12, [rsp+0xC0]
000079bd661d1bec  vmovaps xmm13, [rsp+0xD0]
000079bd661d1bf5  vmovaps xmm15, [rsp+0xE0]
000079bd661d1bfe  add rsp, 0xF0
000079bd661d1c05  pop r11
000079bd661d1c07  pop r10
000079bd661d1c09  pop r9
000079bd661d1c0b  pop r8
000079bd661d1c0d  pop rsi
000079bd661d1c0e  pop rdi
000079bd661d1c0f  pop rdx
000079bd661d1c10  pop rcx
000079bd661d1c11  pop rax
000079bd661d1c12  add rsp, 0x08
000079bd661d1c16  jmp 0x000079BD661CFAAF
000079bd661d1c1b  sub rsp, 0x08
000079bd661d1c1f  push rax
000079bd661d1c20  push rcx
000079bd661d1c21  push rdx
000079bd661d1c22  push rdi
000079bd661d1c23  push rsi
000079bd661d1c24  push r8
000079bd661d1c26  push r9
000079bd661d1c28  push r10
000079bd661d1c2a  push r11
000079bd661d1c2c  sub rsp, 0xF0
000079bd661d1c33  vmovaps [rsp], xmm0
000079bd661d1c38  vmovaps [rsp+0x10], xmm1
000079bd661d1c3e  vmovaps [rsp+0x20], xmm2
000079bd661d1c44  vmovaps [rsp+0x30], xmm3
000079bd661d1c4a  vmovaps [rsp+0x40], xmm4
000079bd661d1c50  vmovaps [rsp+0x50], xmm5
000079bd661d1c56  vmovaps [rsp+0x60], xmm6
000079bd661d1c5c  vmovaps [rsp+0x70], xmm7
000079bd661d1c62  vmovaps [rsp+0x80], xmm8
000079bd661d1c6b  vmovaps [rsp+0x90], xmm9
000079bd661d1c74  vmovaps [rsp+0xA0], xmm10
000079bd661d1c7d  vmovaps [rsp+0xB0], xmm11
000079bd661d1c86  vmovaps [rsp+0xC0], xmm12
000079bd661d1c8f  vmovaps [rsp+0xD0], xmm13
000079bd661d1c98  vmovaps [rsp+0xE0], xmm14
000079bd661d1ca1  sub rsp, 0x30
000079bd661d1ca5  movaps [rsp], xmm15
000079bd661d1caa  movaps [rsp+0x10], xmm13
000079bd661d1cb0  movaps [rsp+0x20], xmm1
000079bd661d1cb5  lea rdi, [rsp]
000079bd661d1cb9  mov esi, 0x00
000079bd661d1cbe  mov rax, 0x56EBD57B0530
000079bd661d1cc8  call rax
000079bd661d1cca  movaps xmm15, [rsp]
000079bd661d1ccf  add rsp, 0x30
000079bd661d1cd3  vmovaps xmm0, [rsp]
000079bd661d1cd8  vmovaps xmm1, [rsp+0x10]
000079bd661d1cde  vmovaps xmm2, [rsp+0x20]
000079bd661d1ce4  vmovaps xmm3, [rsp+0x30]
000079bd661d1cea  vmovaps xmm4, [rsp+0x40]
000079bd661d1cf0  vmovaps xmm5, [rsp+0x50]
000079bd661d1cf6  vmovaps xmm6, [rsp+0x60]
000079bd661d1cfc  vmovaps xmm7, [rsp+0x70]
000079bd661d1d02  vmovaps xmm8, [rsp+0x80]
000079bd661d1d0b  vmovaps xmm9, [rsp+0x90]
000079bd661d1d14  vmovaps xmm10, [rsp+0xA0]
000079bd661d1d1d  vmovaps xmm11, [rsp+0xB0]
000079bd661d1d26  vmovaps xmm12, [rsp+0xC0]
000079bd661d1d2f  vmovaps xmm13, [rsp+0xD0]
000079bd661d1d38  vmovaps xmm14, [rsp+0xE0]
000079bd661d1d41  add rsp, 0xF0
000079bd661d1d48  pop r11
000079bd661d1d4a  pop r10
000079bd661d1d4c  pop r9
000079bd661d1d4e  pop r8
000079bd661d1d50  pop rsi
000079bd661d1d51  pop rdi
000079bd661d1d52  pop rdx
000079bd661d1d53  pop rcx
000079bd661d1d54  pop rax
000079bd661d1d55  add rsp, 0x08
000079bd661d1d59  jmp 0x000079BD661CFAEB
000079bd661d1d5e  call 0x000079BD65FFF430
000079bd661d1d63  jmp 0x000079BD661CFAF8
000079bd661d1d68  sub rsp, 0x08
000079bd661d1d6c  push rax
000079bd661d1d6d  push rcx
000079bd661d1d6e  push rdx
000079bd661d1d6f  push rdi
000079bd661d1d70  push rsi
000079bd661d1d71  push r8
000079bd661d1d73  push r9
000079bd661d1d75  push r10
000079bd661d1d77  push r11
000079bd661d1d79  sub rsp, 0xF0
000079bd661d1d80  vmovaps [rsp], xmm0
000079bd661d1d85  vmovaps [rsp+0x10], xmm1
000079bd661d1d8b  vmovaps [rsp+0x20], xmm2
000079bd661d1d91  vmovaps [rsp+0x30], xmm3
000079bd661d1d97  vmovaps [rsp+0x40], xmm4
000079bd661d1d9d  vmovaps [rsp+0x50], xmm5
000079bd661d1da3  vmovaps [rsp+0x60], xmm6
000079bd661d1da9  vmovaps [rsp+0x70], xmm7
000079bd661d1daf  vmovaps [rsp+0x80], xmm8
000079bd661d1db8  vmovaps [rsp+0x90], xmm9
000079bd661d1dc1  vmovaps [rsp+0xA0], xmm10
000079bd661d1dca  vmovaps [rsp+0xB0], xmm11
000079bd661d1dd3  vmovaps [rsp+0xC0], xmm12
000079bd661d1ddc  vmovaps [rsp+0xD0], xmm13
000079bd661d1de5  vmovaps [rsp+0xE0], xmm15
000079bd661d1dee  sub rsp, 0x30
000079bd661d1df2  movaps [rsp], xmm14
000079bd661d1df7  movaps [rsp+0x10], xmm13
000079bd661d1dfd  movaps [rsp+0x20], xmm2
000079bd661d1e02  lea rdi, [rsp]
000079bd661d1e06  mov esi, 0x00
000079bd661d1e0b  mov rax, 0x56EBD57B0530
000079bd661d1e15  call rax
000079bd661d1e17  movaps xmm14, [rsp]
000079bd661d1e1c  add rsp, 0x30
000079bd661d1e20  vmovaps xmm0, [rsp]
000079bd661d1e25  vmovaps xmm1, [rsp+0x10]
000079bd661d1e2b  vmovaps xmm2, [rsp+0x20]
000079bd661d1e31  vmovaps xmm3, [rsp+0x30]
000079bd661d1e37  vmovaps xmm4, [rsp+0x40]
000079bd661d1e3d  vmovaps xmm5, [rsp+0x50]
000079bd661d1e43  vmovaps xmm6, [rsp+0x60]
000079bd661d1e49  vmovaps xmm7, [rsp+0x70]
000079bd661d1e4f  vmovaps xmm8, [rsp+0x80]
000079bd661d1e58  vmovaps xmm9, [rsp+0x90]
000079bd661d1e61  vmovaps xmm10, [rsp+0xA0]
000079bd661d1e6a  vmovaps xmm11, [rsp+0xB0]
000079bd661d1e73  vmovaps xmm12, [rsp+0xC0]
000079bd661d1e7c  vmovaps xmm13, [rsp+0xD0]
000079bd661d1e85  vmovaps xmm15, [rsp+0xE0]
000079bd661d1e8e  add rsp, 0xF0
000079bd661d1e95  pop r11
000079bd661d1e97  pop r10
000079bd661d1e99  pop r9
000079bd661d1e9b  pop r8
000079bd661d1e9d  pop rsi
000079bd661d1e9e  pop rdi
000079bd661d1e9f  pop rdx
000079bd661d1ea0  pop rcx
000079bd661d1ea1  pop rax
000079bd661d1ea2  add rsp, 0x08
000079bd661d1ea6  jmp 0x000079BD661CFB24
000079bd661d1eab  sub rsp, 0x08
000079bd661d1eaf  push rax
000079bd661d1eb0  push rcx
000079bd661d1eb1  push rdx
000079bd661d1eb2  push rdi
000079bd661d1eb3  push rsi
000079bd661d1eb4  push r8
000079bd661d1eb6  push r9
000079bd661d1eb8  push r10
000079bd661d1eba  push r11
000079bd661d1ebc  sub rsp, 0xF0
000079bd661d1ec3  vmovaps [rsp], xmm0
000079bd661d1ec8  vmovaps [rsp+0x10], xmm2
000079bd661d1ece  vmovaps [rsp+0x20], xmm3
000079bd661d1ed4  vmovaps [rsp+0x30], xmm4
000079bd661d1eda  vmovaps [rsp+0x40], xmm5
000079bd661d1ee0  vmovaps [rsp+0x50], xmm6
000079bd661d1ee6  vmovaps [rsp+0x60], xmm7
000079bd661d1eec  vmovaps [rsp+0x70], xmm8
000079bd661d1ef2  vmovaps [rsp+0x80], xmm9
000079bd661d1efb  vmovaps [rsp+0x90], xmm10
000079bd661d1f04  vmovaps [rsp+0xA0], xmm11
000079bd661d1f0d  vmovaps [rsp+0xB0], xmm12
000079bd661d1f16  vmovaps [rsp+0xC0], xmm13
000079bd661d1f1f  vmovaps [rsp+0xD0], xmm14
000079bd661d1f28  vmovaps [rsp+0xE0], xmm15
000079bd661d1f31  sub rsp, 0x30
000079bd661d1f35  movaps [rsp], xmm1
000079bd661d1f39  movaps [rsp+0x10], xmm13
000079bd661d1f3f  movaps [rsp+0x20], xmm2
000079bd661d1f44  lea rdi, [rsp]
000079bd661d1f48  mov esi, 0x00
000079bd661d1f4d  mov rax, 0x56EBD57B0530
000079bd661d1f57  call rax
000079bd661d1f59  movaps xmm1, [rsp]
000079bd661d1f5d  add rsp, 0x30
000079bd661d1f61  vmovaps xmm0, [rsp]
000079bd661d1f66  vmovaps xmm2, [rsp+0x10]
000079bd661d1f6c  vmovaps xmm3, [rsp+0x20]
000079bd661d1f72  vmovaps xmm4, [rsp+0x30]
000079bd661d1f78  vmovaps xmm5, [rsp+0x40]
000079bd661d1f7e  vmovaps xmm6, [rsp+0x50]
000079bd661d1f84  vmovaps xmm7, [rsp+0x60]
000079bd661d1f8a  vmovaps xmm8, [rsp+0x70]
000079bd661d1f90  vmovaps xmm9, [rsp+0x80]
000079bd661d1f99  vmovaps xmm10, [rsp+0x90]
000079bd661d1fa2  vmovaps xmm11, [rsp+0xA0]
000079bd661d1fab  vmovaps xmm12, [rsp+0xB0]
000079bd661d1fb4  vmovaps xmm13, [rsp+0xC0]
000079bd661d1fbd  vmovaps xmm14, [rsp+0xD0]
000079bd661d1fc6  vmovaps xmm15, [rsp+0xE0]
000079bd661d1fcf  add rsp, 0xF0
000079bd661d1fd6  pop r11
000079bd661d1fd8  pop r10
000079bd661d1fda  pop r9
000079bd661d1fdc  pop r8
000079bd661d1fde  pop rsi
000079bd661d1fdf  pop rdi
000079bd661d1fe0  pop rdx
000079bd661d1fe1  pop rcx
000079bd661d1fe2  pop rax
000079bd661d1fe3  add rsp, 0x08
000079bd661d1fe7  jmp 0x000079BD661CFB52
000079bd661d1fec  sub rsp, 0x08
000079bd661d1ff0  push rax
000079bd661d1ff1  push rcx
000079bd661d1ff2  push rdx
000079bd661d1ff3  push rdi
000079bd661d1ff4  push rsi
000079bd661d1ff5  push r8
000079bd661d1ff7  push r9
000079bd661d1ff9  push r10
000079bd661d1ffb  push r11
000079bd661d1ffd  sub rsp, 0xF0
000079bd661d2004  vmovaps [rsp], xmm0
000079bd661d2009  vmovaps [rsp+0x10], xmm1
000079bd661d200f  vmovaps [rsp+0x20], xmm3
000079bd661d2015  vmovaps [rsp+0x30], xmm4
000079bd661d201b  vmovaps [rsp+0x40], xmm5
000079bd661d2021  vmovaps [rsp+0x50], xmm6
000079bd661d2027  vmovaps [rsp+0x60], xmm7
000079bd661d202d  vmovaps [rsp+0x70], xmm8
000079bd661d2033  vmovaps [rsp+0x80], xmm9
000079bd661d203c  vmovaps [rsp+0x90], xmm10
000079bd661d2045  vmovaps [rsp+0xA0], xmm11
000079bd661d204e  vmovaps [rsp+0xB0], xmm12
000079bd661d2057  vmovaps [rsp+0xC0], xmm13
000079bd661d2060  vmovaps [rsp+0xD0], xmm14
000079bd661d2069  vmovaps [rsp+0xE0], xmm15
000079bd661d2072  sub rsp, 0x30
000079bd661d2076  movaps [rsp], xmm2
000079bd661d207a  movaps [rsp+0x10], xmm1
000079bd661d207f  movaps [rsp+0x20], xmm13
000079bd661d2085  lea rdi, [rsp]
000079bd661d2089  mov esi, 0x00
000079bd661d208e  mov rax, 0x56EBD57B0530
000079bd661d2098  call rax
000079bd661d209a  movaps xmm2, [rsp]
000079bd661d209e  add rsp, 0x30
000079bd661d20a2  vmovaps xmm0, [rsp]
000079bd661d20a7  vmovaps xmm1, [rsp+0x10]
000079bd661d20ad  vmovaps xmm3, [rsp+0x20]
000079bd661d20b3  vmovaps xmm4, [rsp+0x30]
000079bd661d20b9  vmovaps xmm5, [rsp+0x40]
000079bd661d20bf  vmovaps xmm6, [rsp+0x50]
000079bd661d20c5  vmovaps xmm7, [rsp+0x60]
000079bd661d20cb  vmovaps xmm8, [rsp+0x70]
000079bd661d20d1  vmovaps xmm9, [rsp+0x80]
000079bd661d20da  vmovaps xmm10, [rsp+0x90]
000079bd661d20e3  vmovaps xmm11, [rsp+0xA0]
000079bd661d20ec  vmovaps xmm12, [rsp+0xB0]
000079bd661d20f5  vmovaps xmm13, [rsp+0xC0]
000079bd661d20fe  vmovaps xmm14, [rsp+0xD0]
000079bd661d2107  vmovaps xmm15, [rsp+0xE0]
000079bd661d2110  add rsp, 0xF0
000079bd661d2117  pop r11
000079bd661d2119  pop r10
000079bd661d211b  pop r9
000079bd661d211d  pop r8
000079bd661d211f  pop rsi
000079bd661d2120  pop rdi
000079bd661d2121  pop rdx
000079bd661d2122  pop rcx
000079bd661d2123  pop rax
000079bd661d2124  add rsp, 0x08
000079bd661d2128  jmp 0x000079BD661CFBAB
000079bd661d212d  call 0x000079BD65FFF430
000079bd661d2132  jmp 0x000079BD661CFBB8
000079bd661d2137  sub rsp, 0x08
000079bd661d213b  push rax
000079bd661d213c  push rcx
000079bd661d213d  push rdx
000079bd661d213e  push rdi
000079bd661d213f  push rsi
000079bd661d2140  push r8
000079bd661d2142  push r9
000079bd661d2144  push r10
000079bd661d2146  push r11
000079bd661d2148  sub rsp, 0xF0
000079bd661d214f  vmovaps [rsp], xmm0
000079bd661d2154  vmovaps [rsp+0x10], xmm1
000079bd661d215a  vmovaps [rsp+0x20], xmm2
000079bd661d2160  vmovaps [rsp+0x30], xmm3
000079bd661d2166  vmovaps [rsp+0x40], xmm4
000079bd661d216c  vmovaps [rsp+0x50], xmm5
000079bd661d2172  vmovaps [rsp+0x60], xmm6
000079bd661d2178  vmovaps [rsp+0x70], xmm7
000079bd661d217e  vmovaps [rsp+0x80], xmm8
000079bd661d2187  vmovaps [rsp+0x90], xmm9
000079bd661d2190  vmovaps [rsp+0xA0], xmm10
000079bd661d2199  vmovaps [rsp+0xB0], xmm11
000079bd661d21a2  vmovaps [rsp+0xC0], xmm12
000079bd661d21ab  vmovaps [rsp+0xD0], xmm13
000079bd661d21b4  vmovaps [rsp+0xE0], xmm14
000079bd661d21bd  sub rsp, 0x30
000079bd661d21c1  movaps [rsp], xmm15
000079bd661d21c6  movaps [rsp+0x10], xmm13
000079bd661d21cc  movaps [rsp+0x20], xmm1
000079bd661d21d1  lea rdi, [rsp]
000079bd661d21d5  mov esi, 0x00
000079bd661d21da  mov rax, 0x56EBD57B0530
000079bd661d21e4  call rax
000079bd661d21e6  movaps xmm15, [rsp]
000079bd661d21eb  add rsp, 0x30
000079bd661d21ef  vmovaps xmm0, [rsp]
000079bd661d21f4  vmovaps xmm1, [rsp+0x10]
000079bd661d21fa  vmovaps xmm2, [rsp+0x20]
000079bd661d2200  vmovaps xmm3, [rsp+0x30]
000079bd661d2206  vmovaps xmm4, [rsp+0x40]
000079bd661d220c  vmovaps xmm5, [rsp+0x50]
000079bd661d2212  vmovaps xmm6, [rsp+0x60]
000079bd661d2218  vmovaps xmm7, [rsp+0x70]
000079bd661d221e  vmovaps xmm8, [rsp+0x80]
000079bd661d2227  vmovaps xmm9, [rsp+0x90]
000079bd661d2230  vmovaps xmm10, [rsp+0xA0]
000079bd661d2239  vmovaps xmm11, [rsp+0xB0]
000079bd661d2242  vmovaps xmm12, [rsp+0xC0]
000079bd661d224b  vmovaps xmm13, [rsp+0xD0]
000079bd661d2254  vmovaps xmm14, [rsp+0xE0]
000079bd661d225d  add rsp, 0xF0
000079bd661d2264  pop r11
000079bd661d2266  pop r10
000079bd661d2268  pop r9
000079bd661d226a  pop r8
000079bd661d226c  pop rsi
000079bd661d226d  pop rdi
000079bd661d226e  pop rdx
000079bd661d226f  pop rcx
000079bd661d2270  pop rax
000079bd661d2271  add rsp, 0x08
000079bd661d2275  jmp 0x000079BD661CFBF7
000079bd661d227a  sub rsp, 0x08
000079bd661d227e  push rax
000079bd661d227f  push rcx
000079bd661d2280  push rdx
000079bd661d2281  push rdi
000079bd661d2282  push rsi
000079bd661d2283  push r8
000079bd661d2285  push r9
000079bd661d2287  push r10
000079bd661d2289  push r11
000079bd661d228b  sub rsp, 0xF0
000079bd661d2292  vmovaps [rsp], xmm0
000079bd661d2297  vmovaps [rsp+0x10], xmm1
000079bd661d229d  vmovaps [rsp+0x20], xmm2
000079bd661d22a3  vmovaps [rsp+0x30], xmm3
000079bd661d22a9  vmovaps [rsp+0x40], xmm4
000079bd661d22af  vmovaps [rsp+0x50], xmm5
000079bd661d22b5  vmovaps [rsp+0x60], xmm6
000079bd661d22bb  vmovaps [rsp+0x70], xmm7
000079bd661d22c1  vmovaps [rsp+0x80], xmm8
000079bd661d22ca  vmovaps [rsp+0x90], xmm9
000079bd661d22d3  vmovaps [rsp+0xA0], xmm10
000079bd661d22dc  vmovaps [rsp+0xB0], xmm11
000079bd661d22e5  vmovaps [rsp+0xC0], xmm12
000079bd661d22ee  vmovaps [rsp+0xD0], xmm13
000079bd661d22f7  vmovaps [rsp+0xE0], xmm15
000079bd661d2300  sub rsp, 0x30
000079bd661d2304  movaps [rsp], xmm14
000079bd661d2309  movaps [rsp+0x10], xmm11
000079bd661d230f  movaps [rsp+0x20], xmm1
000079bd661d2314  lea rdi, [rsp]
000079bd661d2318  mov esi, 0x00
000079bd661d231d  mov rax, 0x56EBD57B0530
000079bd661d2327  call rax
000079bd661d2329  movaps xmm14, [rsp]
000079bd661d232e  add rsp, 0x30
000079bd661d2332  vmovaps xmm0, [rsp]
000079bd661d2337  vmovaps xmm1, [rsp+0x10]
000079bd661d233d  vmovaps xmm2, [rsp+0x20]
000079bd661d2343  vmovaps xmm3, [rsp+0x30]
000079bd661d2349  vmovaps xmm4, [rsp+0x40]
000079bd661d234f  vmovaps xmm5, [rsp+0x50]
000079bd661d2355  vmovaps xmm6, [rsp+0x60]
000079bd661d235b  vmovaps xmm7, [rsp+0x70]
000079bd661d2361  vmovaps xmm8, [rsp+0x80]
000079bd661d236a  vmovaps xmm9, [rsp+0x90]
000079bd661d2373  vmovaps xmm10, [rsp+0xA0]
000079bd661d237c  vmovaps xmm11, [rsp+0xB0]
000079bd661d2385  vmovaps xmm12, [rsp+0xC0]
000079bd661d238e  vmovaps xmm13, [rsp+0xD0]
000079bd661d2397  vmovaps xmm15, [rsp+0xE0]
000079bd661d23a0  add rsp, 0xF0
000079bd661d23a7  pop r11
000079bd661d23a9  pop r10
000079bd661d23ab  pop r9
000079bd661d23ad  pop r8
000079bd661d23af  pop rsi
000079bd661d23b0  pop rdi
000079bd661d23b1  pop rdx
000079bd661d23b2  pop rcx
000079bd661d23b3  pop rax
000079bd661d23b4  add rsp, 0x08
000079bd661d23b8  jmp 0x000079BD661CFC21
000079bd661d23bd  sub rsp, 0x08
000079bd661d23c1  push rax
000079bd661d23c2  push rcx
000079bd661d23c3  push rdx
000079bd661d23c4  push rdi
000079bd661d23c5  push rsi
000079bd661d23c6  push r8
000079bd661d23c8  push r9
000079bd661d23ca  push r10
000079bd661d23cc  push r11
000079bd661d23ce  sub rsp, 0xF0
000079bd661d23d5  vmovaps [rsp], xmm0
000079bd661d23da  vmovaps [rsp+0x10], xmm1
000079bd661d23e0  vmovaps [rsp+0x20], xmm2
000079bd661d23e6  vmovaps [rsp+0x30], xmm3
000079bd661d23ec  vmovaps [rsp+0x40], xmm4
000079bd661d23f2  vmovaps [rsp+0x50], xmm5
000079bd661d23f8  vmovaps [rsp+0x60], xmm6
000079bd661d23fe  vmovaps [rsp+0x70], xmm7
000079bd661d2404  vmovaps [rsp+0x80], xmm8
000079bd661d240d  vmovaps [rsp+0x90], xmm9
000079bd661d2416  vmovaps [rsp+0xA0], xmm10
000079bd661d241f  vmovaps [rsp+0xB0], xmm11
000079bd661d2428  vmovaps [rsp+0xC0], xmm12
000079bd661d2431  vmovaps [rsp+0xD0], xmm14
000079bd661d243a  vmovaps [rsp+0xE0], xmm15
000079bd661d2443  sub rsp, 0x30
000079bd661d2447  movaps [rsp], xmm13
000079bd661d244c  movaps [rsp+0x10], xmm11
000079bd661d2452  movaps [rsp+0x20], xmm1
000079bd661d2457  lea rdi, [rsp]
000079bd661d245b  mov esi, 0x00
000079bd661d2460  mov rax, 0x56EBD57B0530
000079bd661d246a  call rax
000079bd661d246c  movaps xmm13, [rsp]
000079bd661d2471  add rsp, 0x30
000079bd661d2475  vmovaps xmm0, [rsp]
000079bd661d247a  vmovaps xmm1, [rsp+0x10]
000079bd661d2480  vmovaps xmm2, [rsp+0x20]
000079bd661d2486  vmovaps xmm3, [rsp+0x30]
000079bd661d248c  vmovaps xmm4, [rsp+0x40]
000079bd661d2492  vmovaps xmm5, [rsp+0x50]
000079bd661d2498  vmovaps xmm6, [rsp+0x60]
000079bd661d249e  vmovaps xmm7, [rsp+0x70]
000079bd661d24a4  vmovaps xmm8, [rsp+0x80]
000079bd661d24ad  vmovaps xmm9, [rsp+0x90]
000079bd661d24b6  vmovaps xmm10, [rsp+0xA0]
000079bd661d24bf  vmovaps xmm11, [rsp+0xB0]
000079bd661d24c8  vmovaps xmm12, [rsp+0xC0]
000079bd661d24d1  vmovaps xmm14, [rsp+0xD0]
000079bd661d24da  vmovaps xmm15, [rsp+0xE0]
000079bd661d24e3  add rsp, 0xF0
000079bd661d24ea  pop r11
000079bd661d24ec  pop r10
000079bd661d24ee  pop r9
000079bd661d24f0  pop r8
000079bd661d24f2  pop rsi
000079bd661d24f3  pop rdi
000079bd661d24f4  pop rdx
000079bd661d24f5  pop rcx
000079bd661d24f6  pop rax
000079bd661d24f7  add rsp, 0x08
000079bd661d24fb  jmp 0x000079BD661CFC76
000079bd661d2500  call 0x000079BD65FFF430
000079bd661d2505  jmp 0x000079BD661CFC83
000079bd661d250a  sub rsp, 0x08
000079bd661d250e  push rax
000079bd661d250f  push rcx
000079bd661d2510  push rdx
000079bd661d2511  push rdi
000079bd661d2512  push rsi
000079bd661d2513  push r8
000079bd661d2515  push r9
000079bd661d2517  push r10
000079bd661d2519  push r11
000079bd661d251b  sub rsp, 0xF0
000079bd661d2522  vmovaps [rsp], xmm0
000079bd661d2527  vmovaps [rsp+0x10], xmm1
000079bd661d252d  vmovaps [rsp+0x20], xmm2
000079bd661d2533  vmovaps [rsp+0x30], xmm3
000079bd661d2539  vmovaps [rsp+0x40], xmm4
000079bd661d253f  vmovaps [rsp+0x50], xmm5
000079bd661d2545  vmovaps [rsp+0x60], xmm6
000079bd661d254b  vmovaps [rsp+0x70], xmm7
000079bd661d2551  vmovaps [rsp+0x80], xmm8
000079bd661d255a  vmovaps [rsp+0x90], xmm9
000079bd661d2563  vmovaps [rsp+0xA0], xmm10
000079bd661d256c  vmovaps [rsp+0xB0], xmm11
000079bd661d2575  vmovaps [rsp+0xC0], xmm12
000079bd661d257e  vmovaps [rsp+0xD0], xmm13
000079bd661d2587  vmovaps [rsp+0xE0], xmm14
000079bd661d2590  sub rsp, 0x30
000079bd661d2594  movaps [rsp], xmm15
000079bd661d2599  movaps [rsp+0x10], xmm11
000079bd661d259f  movaps [rsp+0x20], xmm1
000079bd661d25a4  lea rdi, [rsp]
000079bd661d25a8  mov esi, 0x00
000079bd661d25ad  mov rax, 0x56EBD57B0530
000079bd661d25b7  call rax
000079bd661d25b9  movaps xmm15, [rsp]
000079bd661d25be  add rsp, 0x30
000079bd661d25c2  vmovaps xmm0, [rsp]
000079bd661d25c7  vmovaps xmm1, [rsp+0x10]
000079bd661d25cd  vmovaps xmm2, [rsp+0x20]
000079bd661d25d3  vmovaps xmm3, [rsp+0x30]
000079bd661d25d9  vmovaps xmm4, [rsp+0x40]
000079bd661d25df  vmovaps xmm5, [rsp+0x50]
000079bd661d25e5  vmovaps xmm6, [rsp+0x60]
000079bd661d25eb  vmovaps xmm7, [rsp+0x70]
000079bd661d25f1  vmovaps xmm8, [rsp+0x80]
000079bd661d25fa  vmovaps xmm9, [rsp+0x90]
000079bd661d2603  vmovaps xmm10, [rsp+0xA0]
000079bd661d260c  vmovaps xmm11, [rsp+0xB0]
000079bd661d2615  vmovaps xmm12, [rsp+0xC0]
000079bd661d261e  vmovaps xmm13, [rsp+0xD0]
000079bd661d2627  vmovaps xmm14, [rsp+0xE0]
000079bd661d2630  add rsp, 0xF0
000079bd661d2637  pop r11
000079bd661d2639  pop r10
000079bd661d263b  pop r9
000079bd661d263d  pop r8
000079bd661d263f  pop rsi
000079bd661d2640  pop rdi
000079bd661d2641  pop rdx
000079bd661d2642  pop rcx
000079bd661d2643  pop rax
000079bd661d2644  add rsp, 0x08
000079bd661d2648  jmp 0x000079BD661CFCBC
000079bd661d264d  sub rsp, 0x08
000079bd661d2651  push rax
000079bd661d2652  push rcx
000079bd661d2653  push rdx
000079bd661d2654  push rdi
000079bd661d2655  push rsi
000079bd661d2656  push r8
000079bd661d2658  push r9
000079bd661d265a  push r10
000079bd661d265c  push r11
000079bd661d265e  sub rsp, 0xF0
000079bd661d2665  vmovaps [rsp], xmm0
000079bd661d266a  vmovaps [rsp+0x10], xmm1
000079bd661d2670  vmovaps [rsp+0x20], xmm2
000079bd661d2676  vmovaps [rsp+0x30], xmm3
000079bd661d267c  vmovaps [rsp+0x40], xmm4
000079bd661d2682  vmovaps [rsp+0x50], xmm5
000079bd661d2688  vmovaps [rsp+0x60], xmm6
000079bd661d268e  vmovaps [rsp+0x70], xmm7
000079bd661d2694  vmovaps [rsp+0x80], xmm8
000079bd661d269d  vmovaps [rsp+0x90], xmm9
000079bd661d26a6  vmovaps [rsp+0xA0], xmm10
000079bd661d26af  vmovaps [rsp+0xB0], xmm12
000079bd661d26b8  vmovaps [rsp+0xC0], xmm13
000079bd661d26c1  vmovaps [rsp+0xD0], xmm14
000079bd661d26ca  vmovaps [rsp+0xE0], xmm15
000079bd661d26d3  sub rsp, 0x30
000079bd661d26d7  movaps [rsp], xmm11
000079bd661d26dc  movaps [rsp+0x10], xmm6
000079bd661d26e1  movaps [rsp+0x20], xmm14
000079bd661d26e7  lea rdi, [rsp]
000079bd661d26eb  mov esi, 0x00
000079bd661d26f0  mov rax, 0x56EBD57B0530
000079bd661d26fa  call rax
000079bd661d26fc  movaps xmm11, [rsp]
000079bd661d2701  add rsp, 0x30
000079bd661d2705  vmovaps xmm0, [rsp]
000079bd661d270a  vmovaps xmm1, [rsp+0x10]
000079bd661d2710  vmovaps xmm2, [rsp+0x20]
000079bd661d2716  vmovaps xmm3, [rsp+0x30]
000079bd661d271c  vmovaps xmm4, [rsp+0x40]
000079bd661d2722  vmovaps xmm5, [rsp+0x50]
000079bd661d2728  vmovaps xmm6, [rsp+0x60]
000079bd661d272e  vmovaps xmm7, [rsp+0x70]
000079bd661d2734  vmovaps xmm8, [rsp+0x80]
000079bd661d273d  vmovaps xmm9, [rsp+0x90]
000079bd661d2746  vmovaps xmm10, [rsp+0xA0]
000079bd661d274f  vmovaps xmm12, [rsp+0xB0]
000079bd661d2758  vmovaps xmm13, [rsp+0xC0]
000079bd661d2761  vmovaps xmm14, [rsp+0xD0]
000079bd661d276a  vmovaps xmm15, [rsp+0xE0]
000079bd661d2773  add rsp, 0xF0
000079bd661d277a  pop r11
000079bd661d277c  pop r10
000079bd661d277e  pop r9
000079bd661d2780  pop r8
000079bd661d2782  pop rsi
000079bd661d2783  pop rdi
000079bd661d2784  pop rdx
000079bd661d2785  pop rcx
000079bd661d2786  pop rax
000079bd661d2787  add rsp, 0x08
000079bd661d278b  jmp 0x000079BD661CFD34
000079bd661d2790  call 0x000079BD65FFF430
000079bd661d2795  jmp 0x000079BD661CFD3E
000079bd661d279a  sub rsp, 0x08
000079bd661d279e  push rax
000079bd661d279f  push rcx
000079bd661d27a0  push rdx
000079bd661d27a1  push rdi
000079bd661d27a2  push rsi
000079bd661d27a3  push r8
000079bd661d27a5  push r9
000079bd661d27a7  push r10
000079bd661d27a9  push r11
000079bd661d27ab  sub rsp, 0xF0
000079bd661d27b2  vmovaps [rsp], xmm0
000079bd661d27b7  vmovaps [rsp+0x10], xmm1
000079bd661d27bd  vmovaps [rsp+0x20], xmm2
000079bd661d27c3  vmovaps [rsp+0x30], xmm3
000079bd661d27c9  vmovaps [rsp+0x40], xmm4
000079bd661d27cf  vmovaps [rsp+0x50], xmm5
000079bd661d27d5  vmovaps [rsp+0x60], xmm6
000079bd661d27db  vmovaps [rsp+0x70], xmm7
000079bd661d27e1  vmovaps [rsp+0x80], xmm8
000079bd661d27ea  vmovaps [rsp+0x90], xmm9
000079bd661d27f3  vmovaps [rsp+0xA0], xmm10
000079bd661d27fc  vmovaps [rsp+0xB0], xmm11
000079bd661d2805  vmovaps [rsp+0xC0], xmm12
000079bd661d280e  vmovaps [rsp+0xD0], xmm13
000079bd661d2817  vmovaps [rsp+0xE0], xmm15
000079bd661d2820  sub rsp, 0x30
000079bd661d2824  movaps [rsp], xmm14
000079bd661d2829  movaps [rsp+0x10], xmm6
000079bd661d282e  movaps [rsp+0x20], xmm2
000079bd661d2833  lea rdi, [rsp]
000079bd661d2837  mov esi, 0x00
000079bd661d283c  mov rax, 0x56EBD57B0530
000079bd661d2846  call rax
000079bd661d2848  movaps xmm14, [rsp]
000079bd661d284d  add rsp, 0x30
000079bd661d2851  vmovaps xmm0, [rsp]
000079bd661d2856  vmovaps xmm1, [rsp+0x10]
000079bd661d285c  vmovaps xmm2, [rsp+0x20]
000079bd661d2862  vmovaps xmm3, [rsp+0x30]
000079bd661d2868  vmovaps xmm4, [rsp+0x40]
000079bd661d286e  vmovaps xmm5, [rsp+0x50]
000079bd661d2874  vmovaps xmm6, [rsp+0x60]
000079bd661d287a  vmovaps xmm7, [rsp+0x70]
000079bd661d2880  vmovaps xmm8, [rsp+0x80]
000079bd661d2889  vmovaps xmm9, [rsp+0x90]
000079bd661d2892  vmovaps xmm10, [rsp+0xA0]
000079bd661d289b  vmovaps xmm11, [rsp+0xB0]
000079bd661d28a4  vmovaps xmm12, [rsp+0xC0]
000079bd661d28ad  vmovaps xmm13, [rsp+0xD0]
000079bd661d28b6  vmovaps xmm15, [rsp+0xE0]
000079bd661d28bf  add rsp, 0xF0
000079bd661d28c6  pop r11
000079bd661d28c8  pop r10
000079bd661d28ca  pop r9
000079bd661d28cc  pop r8
000079bd661d28ce  pop rsi
000079bd661d28cf  pop rdi
000079bd661d28d0  pop rdx
000079bd661d28d1  pop rcx
000079bd661d28d2  pop rax
000079bd661d28d3  add rsp, 0x08
000079bd661d28d7  jmp 0x000079BD661CFD72
000079bd661d28dc  sub rsp, 0x08
000079bd661d28e0  push rax
000079bd661d28e1  push rcx
000079bd661d28e2  push rdx
000079bd661d28e3  push rdi
000079bd661d28e4  push rsi
000079bd661d28e5  push r8
000079bd661d28e7  push r9
000079bd661d28e9  push r10
000079bd661d28eb  push r11
000079bd661d28ed  sub rsp, 0xF0
000079bd661d28f4  vmovaps [rsp], xmm0
000079bd661d28f9  vmovaps [rsp+0x10], xmm1
000079bd661d28ff  vmovaps [rsp+0x20], xmm2
000079bd661d2905  vmovaps [rsp+0x30], xmm3
000079bd661d290b  vmovaps [rsp+0x40], xmm4
000079bd661d2911  vmovaps [rsp+0x50], xmm5
000079bd661d2917  vmovaps [rsp+0x60], xmm7
000079bd661d291d  vmovaps [rsp+0x70], xmm8
000079bd661d2923  vmovaps [rsp+0x80], xmm9
000079bd661d292c  vmovaps [rsp+0x90], xmm10
000079bd661d2935  vmovaps [rsp+0xA0], xmm11
000079bd661d293e  vmovaps [rsp+0xB0], xmm12
000079bd661d2947  vmovaps [rsp+0xC0], xmm13
000079bd661d2950  vmovaps [rsp+0xD0], xmm14
000079bd661d2959  vmovaps [rsp+0xE0], xmm15
000079bd661d2962  sub rsp, 0x30
000079bd661d2966  movaps [rsp], xmm6
000079bd661d296a  movaps [rsp+0x10], xmm5
000079bd661d296f  movaps [rsp+0x20], xmm1
000079bd661d2974  lea rdi, [rsp]
000079bd661d2978  mov esi, 0x00
000079bd661d297d  mov rax, 0x56EBD57B0530
000079bd661d2987  call rax
000079bd661d2989  movaps xmm6, [rsp]
000079bd661d298d  add rsp, 0x30
000079bd661d2991  vmovaps xmm0, [rsp]
000079bd661d2996  vmovaps xmm1, [rsp+0x10]
000079bd661d299c  vmovaps xmm2, [rsp+0x20]
000079bd661d29a2  vmovaps xmm3, [rsp+0x30]
000079bd661d29a8  vmovaps xmm4, [rsp+0x40]
000079bd661d29ae  vmovaps xmm5, [rsp+0x50]
000079bd661d29b4  vmovaps xmm7, [rsp+0x60]
000079bd661d29ba  vmovaps xmm8, [rsp+0x70]
000079bd661d29c0  vmovaps xmm9, [rsp+0x80]
000079bd661d29c9  vmovaps xmm10, [rsp+0x90]
000079bd661d29d2  vmovaps xmm11, [rsp+0xA0]
000079bd661d29db  vmovaps xmm12, [rsp+0xB0]
000079bd661d29e4  vmovaps xmm13, [rsp+0xC0]
000079bd661d29ed  vmovaps xmm14, [rsp+0xD0]
000079bd661d29f6  vmovaps xmm15, [rsp+0xE0]
000079bd661d29ff  add rsp, 0xF0
000079bd661d2a06  pop r11
000079bd661d2a08  pop r10
000079bd661d2a0a  pop r9
000079bd661d2a0c  pop r8
000079bd661d2a0e  pop rsi
000079bd661d2a0f  pop rdi
000079bd661d2a10  pop rdx
000079bd661d2a11  pop rcx
000079bd661d2a12  pop rax
000079bd661d2a13  add rsp, 0x08
000079bd661d2a17  jmp 0x000079BD661CFD98
000079bd661d2a1c  sub rsp, 0x08
000079bd661d2a20  push rax
000079bd661d2a21  push rcx
000079bd661d2a22  push rdx
000079bd661d2a23  push rdi
000079bd661d2a24  push rsi
000079bd661d2a25  push r8
000079bd661d2a27  push r9
000079bd661d2a29  push r10
000079bd661d2a2b  push r11
000079bd661d2a2d  sub rsp, 0xF0
000079bd661d2a34  vmovaps [rsp], xmm0
000079bd661d2a39  vmovaps [rsp+0x10], xmm2
000079bd661d2a3f  vmovaps [rsp+0x20], xmm3
000079bd661d2a45  vmovaps [rsp+0x30], xmm4
000079bd661d2a4b  vmovaps [rsp+0x40], xmm5
000079bd661d2a51  vmovaps [rsp+0x50], xmm6
000079bd661d2a57  vmovaps [rsp+0x60], xmm7
000079bd661d2a5d  vmovaps [rsp+0x70], xmm8
000079bd661d2a63  vmovaps [rsp+0x80], xmm9
000079bd661d2a6c  vmovaps [rsp+0x90], xmm10
000079bd661d2a75  vmovaps [rsp+0xA0], xmm11
000079bd661d2a7e  vmovaps [rsp+0xB0], xmm12
000079bd661d2a87  vmovaps [rsp+0xC0], xmm13
000079bd661d2a90  vmovaps [rsp+0xD0], xmm14
000079bd661d2a99  vmovaps [rsp+0xE0], xmm15
000079bd661d2aa2  sub rsp, 0x30
000079bd661d2aa6  movaps [rsp], xmm1
000079bd661d2aaa  movaps [rsp+0x10], xmm5
000079bd661d2aaf  movaps [rsp+0x20], xmm13
000079bd661d2ab5  lea rdi, [rsp]
000079bd661d2ab9  mov esi, 0x00
000079bd661d2abe  mov rax, 0x56EBD57B0530
000079bd661d2ac8  call rax
000079bd661d2aca  movaps xmm1, [rsp]
000079bd661d2ace  add rsp, 0x30
000079bd661d2ad2  vmovaps xmm0, [rsp]
000079bd661d2ad7  vmovaps xmm2, [rsp+0x10]
000079bd661d2add  vmovaps xmm3, [rsp+0x20]
000079bd661d2ae3  vmovaps xmm4, [rsp+0x30]
000079bd661d2ae9  vmovaps xmm5, [rsp+0x40]
000079bd661d2aef  vmovaps xmm6, [rsp+0x50]
000079bd661d2af5  vmovaps xmm7, [rsp+0x60]
000079bd661d2afb  vmovaps xmm8, [rsp+0x70]
000079bd661d2b01  vmovaps xmm9, [rsp+0x80]
000079bd661d2b0a  vmovaps xmm10, [rsp+0x90]
000079bd661d2b13  vmovaps xmm11, [rsp+0xA0]
000079bd661d2b1c  vmovaps xmm12, [rsp+0xB0]
000079bd661d2b25  vmovaps xmm13, [rsp+0xC0]
000079bd661d2b2e  vmovaps xmm14, [rsp+0xD0]
000079bd661d2b37  vmovaps xmm15, [rsp+0xE0]
000079bd661d2b40  add rsp, 0xF0
000079bd661d2b47  pop r11
000079bd661d2b49  pop r10
000079bd661d2b4b  pop r9
000079bd661d2b4d  pop r8
000079bd661d2b4f  pop rsi
000079bd661d2b50  pop rdi
000079bd661d2b51  pop rdx
000079bd661d2b52  pop rcx
000079bd661d2b53  pop rax
000079bd661d2b54  add rsp, 0x08
000079bd661d2b58  jmp 0x000079BD661CFDB6
000079bd661d2b5d  sub rsp, 0x08
000079bd661d2b61  push rax
000079bd661d2b62  push rcx
000079bd661d2b63  push rdx
000079bd661d2b64  push rdi
000079bd661d2b65  push rsi
000079bd661d2b66  push r8
000079bd661d2b68  push r9
000079bd661d2b6a  push r10
000079bd661d2b6c  push r11
000079bd661d2b6e  sub rsp, 0xF0
000079bd661d2b75  vmovaps [rsp], xmm0
000079bd661d2b7a  vmovaps [rsp+0x10], xmm1
000079bd661d2b80  vmovaps [rsp+0x20], xmm2
000079bd661d2b86  vmovaps [rsp+0x30], xmm3
000079bd661d2b8c  vmovaps [rsp+0x40], xmm4
000079bd661d2b92  vmovaps [rsp+0x50], xmm6
000079bd661d2b98  vmovaps [rsp+0x60], xmm7
000079bd661d2b9e  vmovaps [rsp+0x70], xmm8
000079bd661d2ba4  vmovaps [rsp+0x80], xmm9
000079bd661d2bad  vmovaps [rsp+0x90], xmm10
000079bd661d2bb6  vmovaps [rsp+0xA0], xmm11
000079bd661d2bbf  vmovaps [rsp+0xB0], xmm12
000079bd661d2bc8  vmovaps [rsp+0xC0], xmm13
000079bd661d2bd1  vmovaps [rsp+0xD0], xmm14
000079bd661d2bda  vmovaps [rsp+0xE0], xmm15
000079bd661d2be3  sub rsp, 0x30
000079bd661d2be7  movaps [rsp], xmm5
000079bd661d2beb  movaps [rsp+0x10], xmm2
000079bd661d2bf0  movaps [rsp+0x20], xmm13
000079bd661d2bf6  lea rdi, [rsp]
000079bd661d2bfa  mov esi, 0x00
000079bd661d2bff  mov rax, 0x56EBD57B0530
000079bd661d2c09  call rax
000079bd661d2c0b  movaps xmm5, [rsp]
000079bd661d2c0f  add rsp, 0x30
000079bd661d2c13  vmovaps xmm0, [rsp]
000079bd661d2c18  vmovaps xmm1, [rsp+0x10]
000079bd661d2c1e  vmovaps xmm2, [rsp+0x20]
000079bd661d2c24  vmovaps xmm3, [rsp+0x30]
000079bd661d2c2a  vmovaps xmm4, [rsp+0x40]
000079bd661d2c30  vmovaps xmm6, [rsp+0x50]
000079bd661d2c36  vmovaps xmm7, [rsp+0x60]
000079bd661d2c3c  vmovaps xmm8, [rsp+0x70]
000079bd661d2c42  vmovaps xmm9, [rsp+0x80]
000079bd661d2c4b  vmovaps xmm10, [rsp+0x90]
000079bd661d2c54  vmovaps xmm11, [rsp+0xA0]
000079bd661d2c5d  vmovaps xmm12, [rsp+0xB0]
000079bd661d2c66  vmovaps xmm13, [rsp+0xC0]
000079bd661d2c6f  vmovaps xmm14, [rsp+0xD0]
000079bd661d2c78  vmovaps xmm15, [rsp+0xE0]
000079bd661d2c81  add rsp, 0xF0
000079bd661d2c88  pop r11
000079bd661d2c8a  pop r10
000079bd661d2c8c  pop r9
000079bd661d2c8e  pop r8
000079bd661d2c90  pop rsi
000079bd661d2c91  pop rdi
000079bd661d2c92  pop rdx
000079bd661d2c93  pop rcx
000079bd661d2c94  pop rax
000079bd661d2c95  add rsp, 0x08
000079bd661d2c99  jmp 0x000079BD661CFDEC
000079bd661d2c9e  sub rsp, 0x08
000079bd661d2ca2  push rax
000079bd661d2ca3  push rcx
000079bd661d2ca4  push rdx
000079bd661d2ca5  push rdi
000079bd661d2ca6  push rsi
000079bd661d2ca7  push r8
000079bd661d2ca9  push r9
000079bd661d2cab  push r10
000079bd661d2cad  push r11
000079bd661d2caf  sub rsp, 0xF0
000079bd661d2cb6  vmovaps [rsp], xmm0
000079bd661d2cbb  vmovaps [rsp+0x10], xmm1
000079bd661d2cc1  vmovaps [rsp+0x20], xmm2
000079bd661d2cc7  vmovaps [rsp+0x30], xmm3
000079bd661d2ccd  vmovaps [rsp+0x40], xmm4
000079bd661d2cd3  vmovaps [rsp+0x50], xmm5
000079bd661d2cd9  vmovaps [rsp+0x60], xmm6
000079bd661d2cdf  vmovaps [rsp+0x70], xmm7
000079bd661d2ce5  vmovaps [rsp+0x80], xmm8
000079bd661d2cee  vmovaps [rsp+0x90], xmm9
000079bd661d2cf7  vmovaps [rsp+0xA0], xmm10
000079bd661d2d00  vmovaps [rsp+0xB0], xmm11
000079bd661d2d09  vmovaps [rsp+0xC0], xmm12
000079bd661d2d12  vmovaps [rsp+0xD0], xmm14
000079bd661d2d1b  vmovaps [rsp+0xE0], xmm15
000079bd661d2d24  sub rsp, 0x30
000079bd661d2d28  movaps [rsp], xmm13
000079bd661d2d2d  movaps [rsp+0x10], xmm10
000079bd661d2d33  movaps [rsp+0x20], xmm1
000079bd661d2d38  lea rdi, [rsp]
000079bd661d2d3c  mov esi, 0x00
000079bd661d2d41  mov rax, 0x56EBD57B0530
000079bd661d2d4b  call rax
000079bd661d2d4d  movaps xmm13, [rsp]
000079bd661d2d52  add rsp, 0x30
000079bd661d2d56  vmovaps xmm0, [rsp]
000079bd661d2d5b  vmovaps xmm1, [rsp+0x10]
000079bd661d2d61  vmovaps xmm2, [rsp+0x20]
000079bd661d2d67  vmovaps xmm3, [rsp+0x30]
000079bd661d2d6d  vmovaps xmm4, [rsp+0x40]
000079bd661d2d73  vmovaps xmm5, [rsp+0x50]
000079bd661d2d79  vmovaps xmm6, [rsp+0x60]
000079bd661d2d7f  vmovaps xmm7, [rsp+0x70]
000079bd661d2d85  vmovaps xmm8, [rsp+0x80]
000079bd661d2d8e  vmovaps xmm9, [rsp+0x90]
000079bd661d2d97  vmovaps xmm10, [rsp+0xA0]
000079bd661d2da0  vmovaps xmm11, [rsp+0xB0]
000079bd661d2da9  vmovaps xmm12, [rsp+0xC0]
000079bd661d2db2  vmovaps xmm14, [rsp+0xD0]
000079bd661d2dbb  vmovaps xmm15, [rsp+0xE0]
000079bd661d2dc4  add rsp, 0xF0
000079bd661d2dcb  pop r11
000079bd661d2dcd  pop r10
000079bd661d2dcf  pop r9
000079bd661d2dd1  pop r8
000079bd661d2dd3  pop rsi
000079bd661d2dd4  pop rdi
000079bd661d2dd5  pop rdx
000079bd661d2dd6  pop rcx
000079bd661d2dd7  pop rax
000079bd661d2dd8  add rsp, 0x08
000079bd661d2ddc  jmp 0x000079BD661CFE15
000079bd661d2de1  sub rsp, 0x08
000079bd661d2de5  push rax
000079bd661d2de6  push rcx
000079bd661d2de7  push rdx
000079bd661d2de8  push rdi
000079bd661d2de9  push rsi
000079bd661d2dea  push r8
000079bd661d2dec  push r9
000079bd661d2dee  push r10
000079bd661d2df0  push r11
000079bd661d2df2  sub rsp, 0xF0
000079bd661d2df9  vmovaps [rsp], xmm0
000079bd661d2dfe  vmovaps [rsp+0x10], xmm2
000079bd661d2e04  vmovaps [rsp+0x20], xmm3
000079bd661d2e0a  vmovaps [rsp+0x30], xmm4
000079bd661d2e10  vmovaps [rsp+0x40], xmm5
000079bd661d2e16  vmovaps [rsp+0x50], xmm6
000079bd661d2e1c  vmovaps [rsp+0x60], xmm7
000079bd661d2e22  vmovaps [rsp+0x70], xmm8
000079bd661d2e28  vmovaps [rsp+0x80], xmm9
000079bd661d2e31  vmovaps [rsp+0x90], xmm10
000079bd661d2e3a  vmovaps [rsp+0xA0], xmm11
000079bd661d2e43  vmovaps [rsp+0xB0], xmm12
000079bd661d2e4c  vmovaps [rsp+0xC0], xmm13
000079bd661d2e55  vmovaps [rsp+0xD0], xmm14
000079bd661d2e5e  vmovaps [rsp+0xE0], xmm15
000079bd661d2e67  sub rsp, 0x30
000079bd661d2e6b  movaps [rsp], xmm1
000079bd661d2e6f  movaps [rsp+0x10], xmm15
000079bd661d2e75  movaps [rsp+0x20], xmm10
000079bd661d2e7b  lea rdi, [rsp]
000079bd661d2e7f  mov esi, 0x00
000079bd661d2e84  mov rax, 0x56EBD57B0530
000079bd661d2e8e  call rax
000079bd661d2e90  movaps xmm1, [rsp]
000079bd661d2e94  add rsp, 0x30
000079bd661d2e98  vmovaps xmm0, [rsp]
000079bd661d2e9d  vmovaps xmm2, [rsp+0x10]
000079bd661d2ea3  vmovaps xmm3, [rsp+0x20]
000079bd661d2ea9  vmovaps xmm4, [rsp+0x30]
000079bd661d2eaf  vmovaps xmm5, [rsp+0x40]
000079bd661d2eb5  vmovaps xmm6, [rsp+0x50]
000079bd661d2ebb  vmovaps xmm7, [rsp+0x60]
000079bd661d2ec1  vmovaps xmm8, [rsp+0x70]
000079bd661d2ec7  vmovaps xmm9, [rsp+0x80]
000079bd661d2ed0  vmovaps xmm10, [rsp+0x90]
000079bd661d2ed9  vmovaps xmm11, [rsp+0xA0]
000079bd661d2ee2  vmovaps xmm12, [rsp+0xB0]
000079bd661d2eeb  vmovaps xmm13, [rsp+0xC0]
000079bd661d2ef4  vmovaps xmm14, [rsp+0xD0]
000079bd661d2efd  vmovaps xmm15, [rsp+0xE0]
000079bd661d2f06  add rsp, 0xF0
000079bd661d2f0d  pop r11
000079bd661d2f0f  pop r10
000079bd661d2f11  pop r9
000079bd661d2f13  pop r8
000079bd661d2f15  pop rsi
000079bd661d2f16  pop rdi
000079bd661d2f17  pop rdx
000079bd661d2f18  pop rcx
000079bd661d2f19  pop rax
000079bd661d2f1a  add rsp, 0x08
000079bd661d2f1e  jmp 0x000079BD661CFE34
000079bd661d2f23  sub rsp, 0x08
000079bd661d2f27  push rax
000079bd661d2f28  push rcx
000079bd661d2f29  push rdx
000079bd661d2f2a  push rdi
000079bd661d2f2b  push rsi
000079bd661d2f2c  push r8
000079bd661d2f2e  push r9
000079bd661d2f30  push r10
000079bd661d2f32  push r11
000079bd661d2f34  sub rsp, 0xF0
000079bd661d2f3b  vmovaps [rsp], xmm0
000079bd661d2f40  vmovaps [rsp+0x10], xmm1
000079bd661d2f46  vmovaps [rsp+0x20], xmm2
000079bd661d2f4c  vmovaps [rsp+0x30], xmm3
000079bd661d2f52  vmovaps [rsp+0x40], xmm4
000079bd661d2f58  vmovaps [rsp+0x50], xmm5
000079bd661d2f5e  vmovaps [rsp+0x60], xmm6
000079bd661d2f64  vmovaps [rsp+0x70], xmm7
000079bd661d2f6a  vmovaps [rsp+0x80], xmm8
000079bd661d2f73  vmovaps [rsp+0x90], xmm9
000079bd661d2f7c  vmovaps [rsp+0xA0], xmm10
000079bd661d2f85  vmovaps [rsp+0xB0], xmm11
000079bd661d2f8e  vmovaps [rsp+0xC0], xmm12
000079bd661d2f97  vmovaps [rsp+0xD0], xmm13
000079bd661d2fa0  vmovaps [rsp+0xE0], xmm14
000079bd661d2fa9  sub rsp, 0x30
000079bd661d2fad  movaps [rsp], xmm15
000079bd661d2fb2  movaps [rsp+0x10], xmm10
000079bd661d2fb8  movaps [rsp+0x20], xmm11
000079bd661d2fbe  lea rdi, [rsp]
000079bd661d2fc2  mov esi, 0x00
000079bd661d2fc7  mov rax, 0x56EBD57B0530
000079bd661d2fd1  call rax
000079bd661d2fd3  movaps xmm15, [rsp]
000079bd661d2fd8  add rsp, 0x30
000079bd661d2fdc  vmovaps xmm0, [rsp]
000079bd661d2fe1  vmovaps xmm1, [rsp+0x10]
000079bd661d2fe7  vmovaps xmm2, [rsp+0x20]
000079bd661d2fed  vmovaps xmm3, [rsp+0x30]
000079bd661d2ff3  vmovaps xmm4, [rsp+0x40]
000079bd661d2ff9  vmovaps xmm5, [rsp+0x50]
000079bd661d2fff  vmovaps xmm6, [rsp+0x60]
000079bd661d3005  vmovaps xmm7, [rsp+0x70]
000079bd661d300b  vmovaps xmm8, [rsp+0x80]
000079bd661d3014  vmovaps xmm9, [rsp+0x90]
000079bd661d301d  vmovaps xmm10, [rsp+0xA0]
000079bd661d3026  vmovaps xmm11, [rsp+0xB0]
000079bd661d302f  vmovaps xmm12, [rsp+0xC0]
000079bd661d3038  vmovaps xmm13, [rsp+0xD0]
000079bd661d3041  vmovaps xmm14, [rsp+0xE0]
000079bd661d304a  add rsp, 0xF0
000079bd661d3051  pop r11
000079bd661d3053  pop r10
000079bd661d3055  pop r9
000079bd661d3057  pop r8
000079bd661d3059  pop rsi
000079bd661d305a  pop rdi
000079bd661d305b  pop rdx
000079bd661d305c  pop rcx
000079bd661d305d  pop rax
000079bd661d305e  add rsp, 0x08
000079bd661d3062  jmp 0x000079BD661CFE57
000079bd661d3067  sub rsp, 0x08
000079bd661d306b  push rax
000079bd661d306c  push rcx
000079bd661d306d  push rdx
000079bd661d306e  push rdi
000079bd661d306f  push rsi
000079bd661d3070  push r8
000079bd661d3072  push r9
000079bd661d3074  push r10
000079bd661d3076  push r11
000079bd661d3078  sub rsp, 0xF0
000079bd661d307f  vmovaps [rsp], xmm0
000079bd661d3084  vmovaps [rsp+0x10], xmm1
000079bd661d308a  vmovaps [rsp+0x20], xmm2
000079bd661d3090  vmovaps [rsp+0x30], xmm3
000079bd661d3096  vmovaps [rsp+0x40], xmm4
000079bd661d309c  vmovaps [rsp+0x50], xmm5
000079bd661d30a2  vmovaps [rsp+0x60], xmm6
000079bd661d30a8  vmovaps [rsp+0x70], xmm7
000079bd661d30ae  vmovaps [rsp+0x80], xmm8
000079bd661d30b7  vmovaps [rsp+0x90], xmm9
000079bd661d30c0  vmovaps [rsp+0xA0], xmm11
000079bd661d30c9  vmovaps [rsp+0xB0], xmm12
000079bd661d30d2  vmovaps [rsp+0xC0], xmm13
000079bd661d30db  vmovaps [rsp+0xD0], xmm14
000079bd661d30e4  vmovaps [rsp+0xE0], xmm15
000079bd661d30ed  sub rsp, 0x30
000079bd661d30f1  movaps [rsp], xmm10
000079bd661d30f6  movaps [rsp+0x10], xmm12
000079bd661d30fc  movaps [rsp+0x20], xmm11
000079bd661d3102  lea rdi, [rsp]
000079bd661d3106  mov esi, 0x00
000079bd661d310b  mov rax, 0x56EBD57B0530
000079bd661d3115  call rax
000079bd661d3117  movaps xmm10, [rsp]
000079bd661d311c  add rsp, 0x30
000079bd661d3120  vmovaps xmm0, [rsp]
000079bd661d3125  vmovaps xmm1, [rsp+0x10]
000079bd661d312b  vmovaps xmm2, [rsp+0x20]
000079bd661d3131  vmovaps xmm3, [rsp+0x30]
000079bd661d3137  vmovaps xmm4, [rsp+0x40]
000079bd661d313d  vmovaps xmm5, [rsp+0x50]
000079bd661d3143  vmovaps xmm6, [rsp+0x60]
000079bd661d3149  vmovaps xmm7, [rsp+0x70]
000079bd661d314f  vmovaps xmm8, [rsp+0x80]
000079bd661d3158  vmovaps xmm9, [rsp+0x90]
000079bd661d3161  vmovaps xmm11, [rsp+0xA0]
000079bd661d316a  vmovaps xmm12, [rsp+0xB0]
000079bd661d3173  vmovaps xmm13, [rsp+0xC0]
000079bd661d317c  vmovaps xmm14, [rsp+0xD0]
000079bd661d3185  vmovaps xmm15, [rsp+0xE0]
000079bd661d318e  add rsp, 0xF0
000079bd661d3195  pop r11
000079bd661d3197  pop r10
000079bd661d3199  pop r9
000079bd661d319b  pop r8
000079bd661d319d  pop rsi
000079bd661d319e  pop rdi
000079bd661d319f  pop rdx
000079bd661d31a0  pop rcx
000079bd661d31a1  pop rax
000079bd661d31a2  add rsp, 0x08
000079bd661d31a6  jmp 0x000079BD661CFE80
000079bd661d31ab  sub rsp, 0x08
000079bd661d31af  push rax
000079bd661d31b0  push rcx
000079bd661d31b1  push rdx
000079bd661d31b2  push rdi
000079bd661d31b3  push rsi
000079bd661d31b4  push r8
000079bd661d31b6  push r9
000079bd661d31b8  push r10
000079bd661d31ba  push r11
000079bd661d31bc  sub rsp, 0xF0
000079bd661d31c3  vmovaps [rsp], xmm0
000079bd661d31c8  vmovaps [rsp+0x10], xmm1
000079bd661d31ce  vmovaps [rsp+0x20], xmm2
000079bd661d31d4  vmovaps [rsp+0x30], xmm3
000079bd661d31da  vmovaps [rsp+0x40], xmm4
000079bd661d31e0  vmovaps [rsp+0x50], xmm5
000079bd661d31e6  vmovaps [rsp+0x60], xmm6
000079bd661d31ec  vmovaps [rsp+0x70], xmm7
000079bd661d31f2  vmovaps [rsp+0x80], xmm8
000079bd661d31fb  vmovaps [rsp+0x90], xmm9
000079bd661d3204  vmovaps [rsp+0xA0], xmm10
000079bd661d320d  vmovaps [rsp+0xB0], xmm12
000079bd661d3216  vmovaps [rsp+0xC0], xmm13
000079bd661d321f  vmovaps [rsp+0xD0], xmm14
000079bd661d3228  vmovaps [rsp+0xE0], xmm15
000079bd661d3231  sub rsp, 0x30
000079bd661d3235  movaps [rsp], xmm11
000079bd661d323a  movaps [rsp+0x10], xmm2
000079bd661d323f  movaps [rsp+0x20], xmm12
000079bd661d3245  lea rdi, [rsp]
000079bd661d3249  mov esi, 0x00
000079bd661d324e  mov rax, 0x56EBD57B0530
000079bd661d3258  call rax
000079bd661d325a  movaps xmm11, [rsp]
000079bd661d325f  add rsp, 0x30
000079bd661d3263  vmovaps xmm0, [rsp]
000079bd661d3268  vmovaps xmm1, [rsp+0x10]
000079bd661d326e  vmovaps xmm2, [rsp+0x20]
000079bd661d3274  vmovaps xmm3, [rsp+0x30]
000079bd661d327a  vmovaps xmm4, [rsp+0x40]
000079bd661d3280  vmovaps xmm5, [rsp+0x50]
000079bd661d3286  vmovaps xmm6, [rsp+0x60]
000079bd661d328c  vmovaps xmm7, [rsp+0x70]
000079bd661d3292  vmovaps xmm8, [rsp+0x80]
000079bd661d329b  vmovaps xmm9, [rsp+0x90]
000079bd661d32a4  vmovaps xmm10, [rsp+0xA0]
000079bd661d32ad  vmovaps xmm12, [rsp+0xB0]
000079bd661d32b6  vmovaps xmm13, [rsp+0xC0]
000079bd661d32bf  vmovaps xmm14, [rsp+0xD0]
000079bd661d32c8  vmovaps xmm15, [rsp+0xE0]
000079bd661d32d1  add rsp, 0xF0
000079bd661d32d8  pop r11
000079bd661d32da  pop r10
000079bd661d32dc  pop r9
000079bd661d32de  pop r8
000079bd661d32e0  pop rsi
000079bd661d32e1  pop rdi
000079bd661d32e2  pop rdx
000079bd661d32e3  pop rcx
000079bd661d32e4  pop rax
000079bd661d32e5  add rsp, 0x08
000079bd661d32e9  jmp 0x000079BD661CFEB8
000079bd661d32ee  sub rsp, 0x08
000079bd661d32f2  push rax
000079bd661d32f3  push rcx
000079bd661d32f4  push rdx
000079bd661d32f5  push rdi
000079bd661d32f6  push rsi
000079bd661d32f7  push r8
000079bd661d32f9  push r9
000079bd661d32fb  push r10
000079bd661d32fd  push r11
000079bd661d32ff  sub rsp, 0xF0
000079bd661d3306  vmovaps [rsp], xmm0
000079bd661d330b  vmovaps [rsp+0x10], xmm2
000079bd661d3311  vmovaps [rsp+0x20], xmm3
000079bd661d3317  vmovaps [rsp+0x30], xmm4
000079bd661d331d  vmovaps [rsp+0x40], xmm5
000079bd661d3323  vmovaps [rsp+0x50], xmm6
000079bd661d3329  vmovaps [rsp+0x60], xmm7
000079bd661d332f  vmovaps [rsp+0x70], xmm8
000079bd661d3335  vmovaps [rsp+0x80], xmm9
000079bd661d333e  vmovaps [rsp+0x90], xmm10
000079bd661d3347  vmovaps [rsp+0xA0], xmm11
000079bd661d3350  vmovaps [rsp+0xB0], xmm12
000079bd661d3359  vmovaps [rsp+0xC0], xmm13
000079bd661d3362  vmovaps [rsp+0xD0], xmm14
000079bd661d336b  vmovaps [rsp+0xE0], xmm15
000079bd661d3374  sub rsp, 0x30
000079bd661d3378  movaps [rsp], xmm1
000079bd661d337c  movaps [rsp+0x10], xmm14
000079bd661d3382  movaps [rsp+0x20], xmm6
000079bd661d3387  lea rdi, [rsp]
000079bd661d338b  mov esi, 0x00
000079bd661d3390  mov rax, 0x56EBD57B0530
000079bd661d339a  call rax
000079bd661d339c  movaps xmm1, [rsp]
000079bd661d33a0  add rsp, 0x30
000079bd661d33a4  vmovaps xmm0, [rsp]
000079bd661d33a9  vmovaps xmm2, [rsp+0x10]
000079bd661d33af  vmovaps xmm3, [rsp+0x20]
000079bd661d33b5  vmovaps xmm4, [rsp+0x30]
000079bd661d33bb  vmovaps xmm5, [rsp+0x40]
000079bd661d33c1  vmovaps xmm6, [rsp+0x50]
000079bd661d33c7  vmovaps xmm7, [rsp+0x60]
000079bd661d33cd  vmovaps xmm8, [rsp+0x70]
000079bd661d33d3  vmovaps xmm9, [rsp+0x80]
000079bd661d33dc  vmovaps xmm10, [rsp+0x90]
000079bd661d33e5  vmovaps xmm11, [rsp+0xA0]
000079bd661d33ee  vmovaps xmm12, [rsp+0xB0]
000079bd661d33f7  vmovaps xmm13, [rsp+0xC0]
000079bd661d3400  vmovaps xmm14, [rsp+0xD0]
000079bd661d3409  vmovaps xmm15, [rsp+0xE0]
000079bd661d3412  add rsp, 0xF0
000079bd661d3419  pop r11
000079bd661d341b  pop r10
000079bd661d341d  pop r9
000079bd661d341f  pop r8
000079bd661d3421  pop rsi
000079bd661d3422  pop rdi
000079bd661d3423  pop rdx
000079bd661d3424  pop rcx
000079bd661d3425  pop rax
000079bd661d3426  add rsp, 0x08
000079bd661d342a  jmp 0x000079BD661CFED1
000079bd661d342f  sub rsp, 0x08
000079bd661d3433  push rax
000079bd661d3434  push rcx
000079bd661d3435  push rdx
000079bd661d3436  push rdi
000079bd661d3437  push rsi
000079bd661d3438  push r8
000079bd661d343a  push r9
000079bd661d343c  push r10
000079bd661d343e  push r11
000079bd661d3440  sub rsp, 0xF0
000079bd661d3447  vmovaps [rsp], xmm0
000079bd661d344c  vmovaps [rsp+0x10], xmm1
000079bd661d3452  vmovaps [rsp+0x20], xmm2
000079bd661d3458  vmovaps [rsp+0x30], xmm3
000079bd661d345e  vmovaps [rsp+0x40], xmm4
000079bd661d3464  vmovaps [rsp+0x50], xmm5
000079bd661d346a  vmovaps [rsp+0x60], xmm6
000079bd661d3470  vmovaps [rsp+0x70], xmm7
000079bd661d3476  vmovaps [rsp+0x80], xmm8
000079bd661d347f  vmovaps [rsp+0x90], xmm9
000079bd661d3488  vmovaps [rsp+0xA0], xmm10
000079bd661d3491  vmovaps [rsp+0xB0], xmm11
000079bd661d349a  vmovaps [rsp+0xC0], xmm12
000079bd661d34a3  vmovaps [rsp+0xD0], xmm13
000079bd661d34ac  vmovaps [rsp+0xE0], xmm15
000079bd661d34b5  sub rsp, 0x30
000079bd661d34b9  movaps [rsp], xmm14
000079bd661d34be  movaps [rsp+0x10], xmm12
000079bd661d34c4  movaps [rsp+0x20], xmm5
000079bd661d34c9  lea rdi, [rsp]
000079bd661d34cd  mov esi, 0x00
000079bd661d34d2  mov rax, 0x56EBD57B0530
000079bd661d34dc  call rax
000079bd661d34de  movaps xmm14, [rsp]
000079bd661d34e3  add rsp, 0x30
000079bd661d34e7  vmovaps xmm0, [rsp]
000079bd661d34ec  vmovaps xmm1, [rsp+0x10]
000079bd661d34f2  vmovaps xmm2, [rsp+0x20]
000079bd661d34f8  vmovaps xmm3, [rsp+0x30]
000079bd661d34fe  vmovaps xmm4, [rsp+0x40]
000079bd661d3504  vmovaps xmm5, [rsp+0x50]
000079bd661d350a  vmovaps xmm6, [rsp+0x60]
000079bd661d3510  vmovaps xmm7, [rsp+0x70]
000079bd661d3516  vmovaps xmm8, [rsp+0x80]
000079bd661d351f  vmovaps xmm9, [rsp+0x90]
000079bd661d3528  vmovaps xmm10, [rsp+0xA0]
000079bd661d3531  vmovaps xmm11, [rsp+0xB0]
000079bd661d353a  vmovaps xmm12, [rsp+0xC0]
000079bd661d3543  vmovaps xmm13, [rsp+0xD0]
000079bd661d354c  vmovaps xmm15, [rsp+0xE0]
000079bd661d3555  add rsp, 0xF0
000079bd661d355c  pop r11
000079bd661d355e  pop r10
000079bd661d3560  pop r9
000079bd661d3562  pop r8
000079bd661d3564  pop rsi
000079bd661d3565  pop rdi
000079bd661d3566  pop rdx
000079bd661d3567  pop rcx
000079bd661d3568  pop rax
000079bd661d3569  add rsp, 0x08
000079bd661d356d  jmp 0x000079BD661CFEF1
000079bd661d3572  sub rsp, 0x08
000079bd661d3576  push rax
000079bd661d3577  push rcx
000079bd661d3578  push rdx
000079bd661d3579  push rdi
000079bd661d357a  push rsi
000079bd661d357b  push r8
000079bd661d357d  push r9
000079bd661d357f  push r10
000079bd661d3581  push r11
000079bd661d3583  sub rsp, 0xF0
000079bd661d358a  vmovaps [rsp], xmm0
000079bd661d358f  vmovaps [rsp+0x10], xmm1
000079bd661d3595  vmovaps [rsp+0x20], xmm2
000079bd661d359b  vmovaps [rsp+0x30], xmm3
000079bd661d35a1  vmovaps [rsp+0x40], xmm4
000079bd661d35a7  vmovaps [rsp+0x50], xmm5
000079bd661d35ad  vmovaps [rsp+0x60], xmm7
000079bd661d35b3  vmovaps [rsp+0x70], xmm8
000079bd661d35b9  vmovaps [rsp+0x80], xmm9
000079bd661d35c2  vmovaps [rsp+0x90], xmm10
000079bd661d35cb  vmovaps [rsp+0xA0], xmm11
000079bd661d35d4  vmovaps [rsp+0xB0], xmm12
000079bd661d35dd  vmovaps [rsp+0xC0], xmm13
000079bd661d35e6  vmovaps [rsp+0xD0], xmm14
000079bd661d35ef  vmovaps [rsp+0xE0], xmm15
000079bd661d35f8  sub rsp, 0x30
000079bd661d35fc  movaps [rsp], xmm6
000079bd661d3600  movaps [rsp+0x10], xmm9
000079bd661d3606  movaps [rsp+0x20], xmm12
000079bd661d360c  lea rdi, [rsp]
000079bd661d3610  mov esi, 0x00
000079bd661d3615  mov rax, 0x56EBD57B0530
000079bd661d361f  call rax
000079bd661d3621  movaps xmm6, [rsp]
000079bd661d3625  add rsp, 0x30
000079bd661d3629  vmovaps xmm0, [rsp]
000079bd661d362e  vmovaps xmm1, [rsp+0x10]
000079bd661d3634  vmovaps xmm2, [rsp+0x20]
000079bd661d363a  vmovaps xmm3, [rsp+0x30]
000079bd661d3640  vmovaps xmm4, [rsp+0x40]
000079bd661d3646  vmovaps xmm5, [rsp+0x50]
000079bd661d364c  vmovaps xmm7, [rsp+0x60]
000079bd661d3652  vmovaps xmm8, [rsp+0x70]
000079bd661d3658  vmovaps xmm9, [rsp+0x80]
000079bd661d3661  vmovaps xmm10, [rsp+0x90]
000079bd661d366a  vmovaps xmm11, [rsp+0xA0]
000079bd661d3673  vmovaps xmm12, [rsp+0xB0]
000079bd661d367c  vmovaps xmm13, [rsp+0xC0]
000079bd661d3685  vmovaps xmm14, [rsp+0xD0]
000079bd661d368e  vmovaps xmm15, [rsp+0xE0]
000079bd661d3697  add rsp, 0xF0
000079bd661d369e  pop r11
000079bd661d36a0  pop r10
000079bd661d36a2  pop r9
000079bd661d36a4  pop r8
000079bd661d36a6  pop rsi
000079bd661d36a7  pop rdi
000079bd661d36a8  pop rdx
000079bd661d36a9  pop rcx
000079bd661d36aa  pop rax
000079bd661d36ab  add rsp, 0x08
000079bd661d36af  jmp 0x000079BD661CFF19
000079bd661d36b4  sub rsp, 0x08
000079bd661d36b8  push rax
000079bd661d36b9  push rcx
000079bd661d36ba  push rdx
000079bd661d36bb  push rdi
000079bd661d36bc  push rsi
000079bd661d36bd  push r8
000079bd661d36bf  push r9
000079bd661d36c1  push r10
000079bd661d36c3  push r11
000079bd661d36c5  sub rsp, 0xF0
000079bd661d36cc  vmovaps [rsp], xmm0
000079bd661d36d1  vmovaps [rsp+0x10], xmm1
000079bd661d36d7  vmovaps [rsp+0x20], xmm2
000079bd661d36dd  vmovaps [rsp+0x30], xmm3
000079bd661d36e3  vmovaps [rsp+0x40], xmm4
000079bd661d36e9  vmovaps [rsp+0x50], xmm5
000079bd661d36ef  vmovaps [rsp+0x60], xmm6
000079bd661d36f5  vmovaps [rsp+0x70], xmm7
000079bd661d36fb  vmovaps [rsp+0x80], xmm8
000079bd661d3704  vmovaps [rsp+0x90], xmm9
000079bd661d370d  vmovaps [rsp+0xA0], xmm10
000079bd661d3716  vmovaps [rsp+0xB0], xmm11
000079bd661d371f  vmovaps [rsp+0xC0], xmm13
000079bd661d3728  vmovaps [rsp+0xD0], xmm14
000079bd661d3731  vmovaps [rsp+0xE0], xmm15
000079bd661d373a  sub rsp, 0x30
000079bd661d373e  movaps [rsp], xmm12
000079bd661d3743  movaps [rsp+0x10], xmm15
000079bd661d3749  movaps [rsp+0x20], xmm13
000079bd661d374f  lea rdi, [rsp]
000079bd661d3753  mov esi, 0x00
000079bd661d3758  mov rax, 0x56EBD57B0530
000079bd661d3762  call rax
000079bd661d3764  movaps xmm12, [rsp]
000079bd661d3769  add rsp, 0x30
000079bd661d376d  vmovaps xmm0, [rsp]
000079bd661d3772  vmovaps xmm1, [rsp+0x10]
000079bd661d3778  vmovaps xmm2, [rsp+0x20]
000079bd661d377e  vmovaps xmm3, [rsp+0x30]
000079bd661d3784  vmovaps xmm4, [rsp+0x40]
000079bd661d378a  vmovaps xmm5, [rsp+0x50]
000079bd661d3790  vmovaps xmm6, [rsp+0x60]
000079bd661d3796  vmovaps xmm7, [rsp+0x70]
000079bd661d379c  vmovaps xmm8, [rsp+0x80]
000079bd661d37a5  vmovaps xmm9, [rsp+0x90]
000079bd661d37ae  vmovaps xmm10, [rsp+0xA0]
000079bd661d37b7  vmovaps xmm11, [rsp+0xB0]
000079bd661d37c0  vmovaps xmm13, [rsp+0xC0]
000079bd661d37c9  vmovaps xmm14, [rsp+0xD0]
000079bd661d37d2  vmovaps xmm15, [rsp+0xE0]
000079bd661d37db  add rsp, 0xF0
000079bd661d37e2  pop r11
000079bd661d37e4  pop r10
000079bd661d37e6  pop r9
000079bd661d37e8  pop r8
000079bd661d37ea  pop rsi
000079bd661d37eb  pop rdi
000079bd661d37ec  pop rdx
000079bd661d37ed  pop rcx
000079bd661d37ee  pop rax
000079bd661d37ef  add rsp, 0x08
000079bd661d37f3  jmp 0x000079BD661CFF34
000079bd661d37f8  sub rsp, 0x08
000079bd661d37fc  push rax
000079bd661d37fd  push rcx
000079bd661d37fe  push rdx
000079bd661d37ff  push rdi
000079bd661d3800  push rsi
000079bd661d3801  push r8
000079bd661d3803  push r9
000079bd661d3805  push r10
000079bd661d3807  push r11
000079bd661d3809  sub rsp, 0xF0
000079bd661d3810  vmovaps [rsp], xmm0
000079bd661d3815  vmovaps [rsp+0x10], xmm1
000079bd661d381b  vmovaps [rsp+0x20], xmm2
000079bd661d3821  vmovaps [rsp+0x30], xmm3
000079bd661d3827  vmovaps [rsp+0x40], xmm4
000079bd661d382d  vmovaps [rsp+0x50], xmm5
000079bd661d3833  vmovaps [rsp+0x60], xmm6
000079bd661d3839  vmovaps [rsp+0x70], xmm7
000079bd661d383f  vmovaps [rsp+0x80], xmm8
000079bd661d3848  vmovaps [rsp+0x90], xmm9
000079bd661d3851  vmovaps [rsp+0xA0], xmm10
000079bd661d385a  vmovaps [rsp+0xB0], xmm11
000079bd661d3863  vmovaps [rsp+0xC0], xmm12
000079bd661d386c  vmovaps [rsp+0xD0], xmm13
000079bd661d3875  vmovaps [rsp+0xE0], xmm14
000079bd661d387e  sub rsp, 0x30
000079bd661d3882  movaps [rsp], xmm15
000079bd661d3887  movaps [rsp+0x10], xmm13
000079bd661d388d  movaps [rsp+0x20], xmm10
000079bd661d3893  lea rdi, [rsp]
000079bd661d3897  mov esi, 0x00
000079bd661d389c  mov rax, 0x56EBD57B0530
000079bd661d38a6  call rax
000079bd661d38a8  movaps xmm15, [rsp]
000079bd661d38ad  add rsp, 0x30
000079bd661d38b1  vmovaps xmm0, [rsp]
000079bd661d38b6  vmovaps xmm1, [rsp+0x10]
000079bd661d38bc  vmovaps xmm2, [rsp+0x20]
000079bd661d38c2  vmovaps xmm3, [rsp+0x30]
000079bd661d38c8  vmovaps xmm4, [rsp+0x40]
000079bd661d38ce  vmovaps xmm5, [rsp+0x50]
000079bd661d38d4  vmovaps xmm6, [rsp+0x60]
000079bd661d38da  vmovaps xmm7, [rsp+0x70]
000079bd661d38e0  vmovaps xmm8, [rsp+0x80]
000079bd661d38e9  vmovaps xmm9, [rsp+0x90]
000079bd661d38f2  vmovaps xmm10, [rsp+0xA0]
000079bd661d38fb  vmovaps xmm11, [rsp+0xB0]
000079bd661d3904  vmovaps xmm12, [rsp+0xC0]
000079bd661d390d  vmovaps xmm13, [rsp+0xD0]
000079bd661d3916  vmovaps xmm14, [rsp+0xE0]
000079bd661d391f  add rsp, 0xF0
000079bd661d3926  pop r11
000079bd661d3928  pop r10
000079bd661d392a  pop r9
000079bd661d392c  pop r8
000079bd661d392e  pop rsi
000079bd661d392f  pop rdi
000079bd661d3930  pop rdx
000079bd661d3931  pop rcx
000079bd661d3932  pop rax
000079bd661d3933  add rsp, 0x08
000079bd661d3937  jmp 0x000079BD661CFF55
000079bd661d393c  call 0x000079BD6600C260
000079bd661d3941  jmp 0x000079BD661CFFB0
000079bd661d3946  sub rsp, 0x08
000079bd661d394a  push rax
000079bd661d394b  push rcx
000079bd661d394c  push rdx
000079bd661d394d  push rdi
000079bd661d394e  push rsi
000079bd661d394f  push r8
000079bd661d3951  push r9
000079bd661d3953  push r10
000079bd661d3955  push r11
000079bd661d3957  sub rsp, 0xF0
000079bd661d395e  vmovaps [rsp], xmm0
000079bd661d3963  vmovaps [rsp+0x10], xmm1
000079bd661d3969  vmovaps [rsp+0x20], xmm2
000079bd661d396f  vmovaps [rsp+0x30], xmm3
000079bd661d3975  vmovaps [rsp+0x40], xmm4
000079bd661d397b  vmovaps [rsp+0x50], xmm5
000079bd661d3981  vmovaps [rsp+0x60], xmm6
000079bd661d3987  vmovaps [rsp+0x70], xmm7
000079bd661d398d  vmovaps [rsp+0x80], xmm8
000079bd661d3996  vmovaps [rsp+0x90], xmm10
000079bd661d399f  vmovaps [rsp+0xA0], xmm11
000079bd661d39a8  vmovaps [rsp+0xB0], xmm12
000079bd661d39b1  vmovaps [rsp+0xC0], xmm13
000079bd661d39ba  vmovaps [rsp+0xD0], xmm14
000079bd661d39c3  vmovaps [rsp+0xE0], xmm15
000079bd661d39cc  sub rsp, 0x30
000079bd661d39d0  movaps [rsp], xmm9
000079bd661d39d5  movaps [rsp+0x10], xmm8
000079bd661d39db  movaps [rsp+0x20], xmm10
000079bd661d39e1  lea rdi, [rsp]
000079bd661d39e5  mov esi, 0x00
000079bd661d39ea  mov rax, 0x56EBD57B0530
000079bd661d39f4  call rax
000079bd661d39f6  movaps xmm9, [rsp]
000079bd661d39fb  add rsp, 0x30
000079bd661d39ff  vmovaps xmm0, [rsp]
000079bd661d3a04  vmovaps xmm1, [rsp+0x10]
000079bd661d3a0a  vmovaps xmm2, [rsp+0x20]
000079bd661d3a10  vmovaps xmm3, [rsp+0x30]
000079bd661d3a16  vmovaps xmm4, [rsp+0x40]
000079bd661d3a1c  vmovaps xmm5, [rsp+0x50]
000079bd661d3a22  vmovaps xmm6, [rsp+0x60]
000079bd661d3a28  vmovaps xmm7, [rsp+0x70]
000079bd661d3a2e  vmovaps xmm8, [rsp+0x80]
000079bd661d3a37  vmovaps xmm10, [rsp+0x90]
000079bd661d3a40  vmovaps xmm11, [rsp+0xA0]
000079bd661d3a49  vmovaps xmm12, [rsp+0xB0]
000079bd661d3a52  vmovaps xmm13, [rsp+0xC0]
000079bd661d3a5b  vmovaps xmm14, [rsp+0xD0]
000079bd661d3a64  vmovaps xmm15, [rsp+0xE0]
000079bd661d3a6d  add rsp, 0xF0
000079bd661d3a74  pop r11
000079bd661d3a76  pop r10
000079bd661d3a78  pop r9
000079bd661d3a7a  pop r8
000079bd661d3a7c  pop rsi
000079bd661d3a7d  pop rdi
000079bd661d3a7e  pop rdx
000079bd661d3a7f  pop rcx
000079bd661d3a80  pop rax
000079bd661d3a81  add rsp, 0x08
000079bd661d3a85  jmp 0x000079BD661CFFE1
000079bd661d3a8a  sub rsp, 0x08
000079bd661d3a8e  push rax
000079bd661d3a8f  push rcx
000079bd661d3a90  push rdx
000079bd661d3a91  push rdi
000079bd661d3a92  push rsi
000079bd661d3a93  push r8
000079bd661d3a95  push r9
000079bd661d3a97  push r10
000079bd661d3a99  push r11
000079bd661d3a9b  sub rsp, 0xF0
000079bd661d3aa2  vmovaps [rsp], xmm0
000079bd661d3aa7  vmovaps [rsp+0x10], xmm1
000079bd661d3aad  vmovaps [rsp+0x20], xmm2
000079bd661d3ab3  vmovaps [rsp+0x30], xmm3
000079bd661d3ab9  vmovaps [rsp+0x40], xmm4
000079bd661d3abf  vmovaps [rsp+0x50], xmm5
000079bd661d3ac5  vmovaps [rsp+0x60], xmm6
000079bd661d3acb  vmovaps [rsp+0x70], xmm7
000079bd661d3ad1  vmovaps [rsp+0x80], xmm8
000079bd661d3ada  vmovaps [rsp+0x90], xmm9
000079bd661d3ae3  vmovaps [rsp+0xA0], xmm11
000079bd661d3aec  vmovaps [rsp+0xB0], xmm12
000079bd661d3af5  vmovaps [rsp+0xC0], xmm13
000079bd661d3afe  vmovaps [rsp+0xD0], xmm14
000079bd661d3b07  vmovaps [rsp+0xE0], xmm15
000079bd661d3b10  sub rsp, 0x30
000079bd661d3b14  movaps [rsp], xmm10
000079bd661d3b19  movaps [rsp+0x10], xmm1
000079bd661d3b1e  movaps [rsp+0x20], xmm11
000079bd661d3b24  lea rdi, [rsp]
000079bd661d3b28  mov esi, 0x00
000079bd661d3b2d  mov rax, 0x56EBD57B0530
000079bd661d3b37  call rax
000079bd661d3b39  movaps xmm10, [rsp]
000079bd661d3b3e  add rsp, 0x30
000079bd661d3b42  vmovaps xmm0, [rsp]
000079bd661d3b47  vmovaps xmm1, [rsp+0x10]
000079bd661d3b4d  vmovaps xmm2, [rsp+0x20]
000079bd661d3b53  vmovaps xmm3, [rsp+0x30]
000079bd661d3b59  vmovaps xmm4, [rsp+0x40]
000079bd661d3b5f  vmovaps xmm5, [rsp+0x50]
000079bd661d3b65  vmovaps xmm6, [rsp+0x60]
000079bd661d3b6b  vmovaps xmm7, [rsp+0x70]
000079bd661d3b71  vmovaps xmm8, [rsp+0x80]
000079bd661d3b7a  vmovaps xmm9, [rsp+0x90]
000079bd661d3b83  vmovaps xmm11, [rsp+0xA0]
000079bd661d3b8c  vmovaps xmm12, [rsp+0xB0]
000079bd661d3b95  vmovaps xmm13, [rsp+0xC0]
000079bd661d3b9e  vmovaps xmm14, [rsp+0xD0]
000079bd661d3ba7  vmovaps xmm15, [rsp+0xE0]
000079bd661d3bb0  add rsp, 0xF0
000079bd661d3bb7  pop r11
000079bd661d3bb9  pop r10
000079bd661d3bbb  pop r9
000079bd661d3bbd  pop r8
000079bd661d3bbf  pop rsi
000079bd661d3bc0  pop rdi
000079bd661d3bc1  pop rdx
000079bd661d3bc2  pop rcx
000079bd661d3bc3  pop rax
000079bd661d3bc4  add rsp, 0x08
000079bd661d3bc8  jmp 0x000079BD661CFFFC
000079bd661d3bcd  sub rsp, 0x08
000079bd661d3bd1  push rax
000079bd661d3bd2  push rcx
000079bd661d3bd3  push rdx
000079bd661d3bd4  push rdi
000079bd661d3bd5  push rsi
000079bd661d3bd6  push r8
000079bd661d3bd8  push r9
000079bd661d3bda  push r10
000079bd661d3bdc  push r11
000079bd661d3bde  sub rsp, 0xF0
000079bd661d3be5  vmovaps [rsp], xmm0
000079bd661d3bea  vmovaps [rsp+0x10], xmm2
000079bd661d3bf0  vmovaps [rsp+0x20], xmm3
000079bd661d3bf6  vmovaps [rsp+0x30], xmm4
000079bd661d3bfc  vmovaps [rsp+0x40], xmm5
000079bd661d3c02  vmovaps [rsp+0x50], xmm6
000079bd661d3c08  vmovaps [rsp+0x60], xmm7
000079bd661d3c0e  vmovaps [rsp+0x70], xmm8
000079bd661d3c14  vmovaps [rsp+0x80], xmm9
000079bd661d3c1d  vmovaps [rsp+0x90], xmm10
000079bd661d3c26  vmovaps [rsp+0xA0], xmm11
000079bd661d3c2f  vmovaps [rsp+0xB0], xmm12
000079bd661d3c38  vmovaps [rsp+0xC0], xmm13
000079bd661d3c41  vmovaps [rsp+0xD0], xmm14
000079bd661d3c4a  vmovaps [rsp+0xE0], xmm15
000079bd661d3c53  sub rsp, 0x30
000079bd661d3c57  movaps [rsp], xmm1
000079bd661d3c5b  movaps [rsp+0x10], xmm14
000079bd661d3c61  movaps [rsp+0x20], xmm6
000079bd661d3c66  lea rdi, [rsp]
000079bd661d3c6a  mov esi, 0x00
000079bd661d3c6f  mov rax, 0x56EBD57B0530
000079bd661d3c79  call rax
000079bd661d3c7b  movaps xmm1, [rsp]
000079bd661d3c7f  add rsp, 0x30
000079bd661d3c83  vmovaps xmm0, [rsp]
000079bd661d3c88  vmovaps xmm2, [rsp+0x10]
000079bd661d3c8e  vmovaps xmm3, [rsp+0x20]
000079bd661d3c94  vmovaps xmm4, [rsp+0x30]
000079bd661d3c9a  vmovaps xmm5, [rsp+0x40]
000079bd661d3ca0  vmovaps xmm6, [rsp+0x50]
000079bd661d3ca6  vmovaps xmm7, [rsp+0x60]
000079bd661d3cac  vmovaps xmm8, [rsp+0x70]
000079bd661d3cb2  vmovaps xmm9, [rsp+0x80]
000079bd661d3cbb  vmovaps xmm10, [rsp+0x90]
000079bd661d3cc4  vmovaps xmm11, [rsp+0xA0]
000079bd661d3ccd  vmovaps xmm12, [rsp+0xB0]
000079bd661d3cd6  vmovaps xmm13, [rsp+0xC0]
000079bd661d3cdf  vmovaps xmm14, [rsp+0xD0]
000079bd661d3ce8  vmovaps xmm15, [rsp+0xE0]
000079bd661d3cf1  add rsp, 0xF0
000079bd661d3cf8  pop r11
000079bd661d3cfa  pop r10
000079bd661d3cfc  pop r9
000079bd661d3cfe  pop r8
000079bd661d3d00  pop rsi
000079bd661d3d01  pop rdi
000079bd661d3d02  pop rdx
000079bd661d3d03  pop rcx
000079bd661d3d04  pop rax
000079bd661d3d05  add rsp, 0x08
000079bd661d3d09  jmp 0x000079BD661D0015
000079bd661d3d0e  sub rsp, 0x08
000079bd661d3d12  push rax
000079bd661d3d13  push rcx
000079bd661d3d14  push rdx
000079bd661d3d15  push rdi
000079bd661d3d16  push rsi
000079bd661d3d17  push r8
000079bd661d3d19  push r9
000079bd661d3d1b  push r10
000079bd661d3d1d  push r11
000079bd661d3d1f  sub rsp, 0xF0
000079bd661d3d26  vmovaps [rsp], xmm0
000079bd661d3d2b  vmovaps [rsp+0x10], xmm1
000079bd661d3d31  vmovaps [rsp+0x20], xmm2
000079bd661d3d37  vmovaps [rsp+0x30], xmm3
000079bd661d3d3d  vmovaps [rsp+0x40], xmm4
000079bd661d3d43  vmovaps [rsp+0x50], xmm5
000079bd661d3d49  vmovaps [rsp+0x60], xmm6
000079bd661d3d4f  vmovaps [rsp+0x70], xmm7
000079bd661d3d55  vmovaps [rsp+0x80], xmm8
000079bd661d3d5e  vmovaps [rsp+0x90], xmm9
000079bd661d3d67  vmovaps [rsp+0xA0], xmm10
000079bd661d3d70  vmovaps [rsp+0xB0], xmm12
000079bd661d3d79  vmovaps [rsp+0xC0], xmm13
000079bd661d3d82  vmovaps [rsp+0xD0], xmm14
000079bd661d3d8b  vmovaps [rsp+0xE0], xmm15
000079bd661d3d94  sub rsp, 0x30
000079bd661d3d98  movaps [rsp], xmm11
000079bd661d3d9d  movaps [rsp+0x10], xmm13
000079bd661d3da3  movaps [rsp+0x20], xmm14
000079bd661d3da9  lea rdi, [rsp]
000079bd661d3dad  mov esi, 0x00
000079bd661d3db2  mov rax, 0x56EBD57B0530
000079bd661d3dbc  call rax
000079bd661d3dbe  movaps xmm11, [rsp]
000079bd661d3dc3  add rsp, 0x30
000079bd661d3dc7  vmovaps xmm0, [rsp]
000079bd661d3dcc  vmovaps xmm1, [rsp+0x10]
000079bd661d3dd2  vmovaps xmm2, [rsp+0x20]
000079bd661d3dd8  vmovaps xmm3, [rsp+0x30]
000079bd661d3dde  vmovaps xmm4, [rsp+0x40]
000079bd661d3de4  vmovaps xmm5, [rsp+0x50]
000079bd661d3dea  vmovaps xmm6, [rsp+0x60]
000079bd661d3df0  vmovaps xmm7, [rsp+0x70]
000079bd661d3df6  vmovaps xmm8, [rsp+0x80]
000079bd661d3dff  vmovaps xmm9, [rsp+0x90]
000079bd661d3e08  vmovaps xmm10, [rsp+0xA0]
000079bd661d3e11  vmovaps xmm12, [rsp+0xB0]
000079bd661d3e1a  vmovaps xmm13, [rsp+0xC0]
000079bd661d3e23  vmovaps xmm14, [rsp+0xD0]
000079bd661d3e2c  vmovaps xmm15, [rsp+0xE0]
000079bd661d3e35  add rsp, 0xF0
000079bd661d3e3c  pop r11
000079bd661d3e3e  pop r10
000079bd661d3e40  pop r9
000079bd661d3e42  pop r8
000079bd661d3e44  pop rsi
000079bd661d3e45  pop rdi
000079bd661d3e46  pop rdx
000079bd661d3e47  pop rcx
000079bd661d3e48  pop rax
000079bd661d3e49  add rsp, 0x08
000079bd661d3e4d  jmp 0x000079BD661D003F
000079bd661d3e52  sub rsp, 0x08
000079bd661d3e56  push rax
000079bd661d3e57  push rcx
000079bd661d3e58  push rdx
000079bd661d3e59  push rdi
000079bd661d3e5a  push rsi
000079bd661d3e5b  push r8
000079bd661d3e5d  push r9
000079bd661d3e5f  push r10
000079bd661d3e61  push r11
000079bd661d3e63  sub rsp, 0xF0
000079bd661d3e6a  vmovaps [rsp], xmm0
000079bd661d3e6f  vmovaps [rsp+0x10], xmm1
000079bd661d3e75  vmovaps [rsp+0x20], xmm2
000079bd661d3e7b  vmovaps [rsp+0x30], xmm3
000079bd661d3e81  vmovaps [rsp+0x40], xmm4
000079bd661d3e87  vmovaps [rsp+0x50], xmm5
000079bd661d3e8d  vmovaps [rsp+0x60], xmm6
000079bd661d3e93  vmovaps [rsp+0x70], xmm7
000079bd661d3e99  vmovaps [rsp+0x80], xmm8
000079bd661d3ea2  vmovaps [rsp+0x90], xmm9
000079bd661d3eab  vmovaps [rsp+0xA0], xmm10
000079bd661d3eb4  vmovaps [rsp+0xB0], xmm11
000079bd661d3ebd  vmovaps [rsp+0xC0], xmm12
000079bd661d3ec6  vmovaps [rsp+0xD0], xmm14
000079bd661d3ecf  vmovaps [rsp+0xE0], xmm15
000079bd661d3ed8  sub rsp, 0x30
000079bd661d3edc  movaps [rsp], xmm13
000079bd661d3ee1  movaps [rsp+0x10], xmm8
000079bd661d3ee7  movaps [rsp+0x20], xmm14
000079bd661d3eed  lea rdi, [rsp]
000079bd661d3ef1  mov esi, 0x00
000079bd661d3ef6  mov rax, 0x56EBD57B0530
000079bd661d3f00  call rax
000079bd661d3f02  movaps xmm13, [rsp]
000079bd661d3f07  add rsp, 0x30
000079bd661d3f0b  vmovaps xmm0, [rsp]
000079bd661d3f10  vmovaps xmm1, [rsp+0x10]
000079bd661d3f16  vmovaps xmm2, [rsp+0x20]
000079bd661d3f1c  vmovaps xmm3, [rsp+0x30]
000079bd661d3f22  vmovaps xmm4, [rsp+0x40]
000079bd661d3f28  vmovaps xmm5, [rsp+0x50]
000079bd661d3f2e  vmovaps xmm6, [rsp+0x60]
000079bd661d3f34  vmovaps xmm7, [rsp+0x70]
000079bd661d3f3a  vmovaps xmm8, [rsp+0x80]
000079bd661d3f43  vmovaps xmm9, [rsp+0x90]
000079bd661d3f4c  vmovaps xmm10, [rsp+0xA0]
000079bd661d3f55  vmovaps xmm11, [rsp+0xB0]
000079bd661d3f5e  vmovaps xmm12, [rsp+0xC0]
000079bd661d3f67  vmovaps xmm14, [rsp+0xD0]
000079bd661d3f70  vmovaps xmm15, [rsp+0xE0]
000079bd661d3f79  add rsp, 0xF0
000079bd661d3f80  pop r11
000079bd661d3f82  pop r10
000079bd661d3f84  pop r9
000079bd661d3f86  pop r8
000079bd661d3f88  pop rsi
000079bd661d3f89  pop rdi
000079bd661d3f8a  pop rdx
000079bd661d3f8b  pop rcx
000079bd661d3f8c  pop rax
000079bd661d3f8d  add rsp, 0x08
000079bd661d3f91  jmp 0x000079BD661D006E
000079bd661d3f96  sub rsp, 0x08
000079bd661d3f9a  push rax
000079bd661d3f9b  push rcx
000079bd661d3f9c  push rdx
000079bd661d3f9d  push rdi
000079bd661d3f9e  push rsi
000079bd661d3f9f  push r8
000079bd661d3fa1  push r9
000079bd661d3fa3  push r10
000079bd661d3fa5  push r11
000079bd661d3fa7  sub rsp, 0xF0
000079bd661d3fae  vmovaps [rsp], xmm0
000079bd661d3fb3  vmovaps [rsp+0x10], xmm1
000079bd661d3fb9  vmovaps [rsp+0x20], xmm2
000079bd661d3fbf  vmovaps [rsp+0x30], xmm3
000079bd661d3fc5  vmovaps [rsp+0x40], xmm4
000079bd661d3fcb  vmovaps [rsp+0x50], xmm5
000079bd661d3fd1  vmovaps [rsp+0x60], xmm6
000079bd661d3fd7  vmovaps [rsp+0x70], xmm7
000079bd661d3fdd  vmovaps [rsp+0x80], xmm9
000079bd661d3fe6  vmovaps [rsp+0x90], xmm10
000079bd661d3fef  vmovaps [rsp+0xA0], xmm11
000079bd661d3ff8  vmovaps [rsp+0xB0], xmm12
000079bd661d4001  vmovaps [rsp+0xC0], xmm13
000079bd661d400a  vmovaps [rsp+0xD0], xmm14
000079bd661d4013  vmovaps [rsp+0xE0], xmm15
000079bd661d401c  sub rsp, 0x30
000079bd661d4020  movaps [rsp], xmm8
000079bd661d4025  movaps [rsp+0x10], xmm7
000079bd661d402a  movaps [rsp+0x20], xmm14
000079bd661d4030  lea rdi, [rsp]
000079bd661d4034  mov esi, 0x00
000079bd661d4039  mov rax, 0x56EBD57B0530
000079bd661d4043  call rax
000079bd661d4045  movaps xmm8, [rsp]
000079bd661d404a  add rsp, 0x30
000079bd661d404e  vmovaps xmm0, [rsp]
000079bd661d4053  vmovaps xmm1, [rsp+0x10]
000079bd661d4059  vmovaps xmm2, [rsp+0x20]
000079bd661d405f  vmovaps xmm3, [rsp+0x30]
000079bd661d4065  vmovaps xmm4, [rsp+0x40]
000079bd661d406b  vmovaps xmm5, [rsp+0x50]
000079bd661d4071  vmovaps xmm6, [rsp+0x60]
000079bd661d4077  vmovaps xmm7, [rsp+0x70]
000079bd661d407d  vmovaps xmm9, [rsp+0x80]
000079bd661d4086  vmovaps xmm10, [rsp+0x90]
000079bd661d408f  vmovaps xmm11, [rsp+0xA0]
000079bd661d4098  vmovaps xmm12, [rsp+0xB0]
000079bd661d40a1  vmovaps xmm13, [rsp+0xC0]
000079bd661d40aa  vmovaps xmm14, [rsp+0xD0]
000079bd661d40b3  vmovaps xmm15, [rsp+0xE0]
000079bd661d40bc  add rsp, 0xF0
000079bd661d40c3  pop r11
000079bd661d40c5  pop r10
000079bd661d40c7  pop r9
000079bd661d40c9  pop r8
000079bd661d40cb  pop rsi
000079bd661d40cc  pop rdi
000079bd661d40cd  pop rdx
000079bd661d40ce  pop rcx
000079bd661d40cf  pop rax
000079bd661d40d0  add rsp, 0x08
000079bd661d40d4  jmp 0x000079BD661D0094
000079bd661d40d9  sub rsp, 0x08
000079bd661d40dd  push rax
000079bd661d40de  push rcx
000079bd661d40df  push rdx
000079bd661d40e0  push rdi
000079bd661d40e1  push rsi
000079bd661d40e2  push r8
000079bd661d40e4  push r9
000079bd661d40e6  push r10
000079bd661d40e8  push r11
000079bd661d40ea  sub rsp, 0xF0
000079bd661d40f1  vmovaps [rsp], xmm0
000079bd661d40f6  vmovaps [rsp+0x10], xmm1
000079bd661d40fc  vmovaps [rsp+0x20], xmm2
000079bd661d4102  vmovaps [rsp+0x30], xmm3
000079bd661d4108  vmovaps [rsp+0x40], xmm4
000079bd661d410e  vmovaps [rsp+0x50], xmm5
000079bd661d4114  vmovaps [rsp+0x60], xmm6
000079bd661d411a  vmovaps [rsp+0x70], xmm7
000079bd661d4120  vmovaps [rsp+0x80], xmm8
000079bd661d4129  vmovaps [rsp+0x90], xmm9
000079bd661d4132  vmovaps [rsp+0xA0], xmm10
000079bd661d413b  vmovaps [rsp+0xB0], xmm11
000079bd661d4144  vmovaps [rsp+0xC0], xmm12
000079bd661d414d  vmovaps [rsp+0xD0], xmm13
000079bd661d4156  vmovaps [rsp+0xE0], xmm15
000079bd661d415f  sub rsp, 0x30
000079bd661d4163  movaps [rsp], xmm14
000079bd661d4168  movaps [rsp+0x10], xmm12
000079bd661d416e  movaps [rsp+0x20], xmm9
000079bd661d4174  lea rdi, [rsp]
000079bd661d4178  mov esi, 0x00
000079bd661d417d  mov rax, 0x56EBD57B0530
000079bd661d4187  call rax
000079bd661d4189  movaps xmm14, [rsp]
000079bd661d418e  add rsp, 0x30
000079bd661d4192  vmovaps xmm0, [rsp]
000079bd661d4197  vmovaps xmm1, [rsp+0x10]
000079bd661d419d  vmovaps xmm2, [rsp+0x20]
000079bd661d41a3  vmovaps xmm3, [rsp+0x30]
000079bd661d41a9  vmovaps xmm4, [rsp+0x40]
000079bd661d41af  vmovaps xmm5, [rsp+0x50]
000079bd661d41b5  vmovaps xmm6, [rsp+0x60]
000079bd661d41bb  vmovaps xmm7, [rsp+0x70]
000079bd661d41c1  vmovaps xmm8, [rsp+0x80]
000079bd661d41ca  vmovaps xmm9, [rsp+0x90]
000079bd661d41d3  vmovaps xmm10, [rsp+0xA0]
000079bd661d41dc  vmovaps xmm11, [rsp+0xB0]
000079bd661d41e5  vmovaps xmm12, [rsp+0xC0]
000079bd661d41ee  vmovaps xmm13, [rsp+0xD0]
000079bd661d41f7  vmovaps xmm15, [rsp+0xE0]
000079bd661d4200  add rsp, 0xF0
000079bd661d4207  pop r11
000079bd661d4209  pop r10
000079bd661d420b  pop r9
000079bd661d420d  pop r8
000079bd661d420f  pop rsi
000079bd661d4210  pop rdi
000079bd661d4211  pop rdx
000079bd661d4212  pop rcx
000079bd661d4213  pop rax
000079bd661d4214  add rsp, 0x08
000079bd661d4218  jmp 0x000079BD661D00AE
000079bd661d421d  sub rsp, 0x08
000079bd661d4221  push rax
000079bd661d4222  push rcx
000079bd661d4223  push rdx
000079bd661d4224  push rdi
000079bd661d4225  push rsi
000079bd661d4226  push r8
000079bd661d4228  push r9
000079bd661d422a  push r10
000079bd661d422c  push r11
000079bd661d422e  sub rsp, 0xF0
000079bd661d4235  vmovaps [rsp], xmm0
000079bd661d423a  vmovaps [rsp+0x10], xmm1
000079bd661d4240  vmovaps [rsp+0x20], xmm2
000079bd661d4246  vmovaps [rsp+0x30], xmm3
000079bd661d424c  vmovaps [rsp+0x40], xmm4
000079bd661d4252  vmovaps [rsp+0x50], xmm5
000079bd661d4258  vmovaps [rsp+0x60], xmm6
000079bd661d425e  vmovaps [rsp+0x70], xmm7
000079bd661d4264  vmovaps [rsp+0x80], xmm8
000079bd661d426d  vmovaps [rsp+0x90], xmm10
000079bd661d4276  vmovaps [rsp+0xA0], xmm11
000079bd661d427f  vmovaps [rsp+0xB0], xmm12
000079bd661d4288  vmovaps [rsp+0xC0], xmm13
000079bd661d4291  vmovaps [rsp+0xD0], xmm14
000079bd661d429a  vmovaps [rsp+0xE0], xmm15
000079bd661d42a3  sub rsp, 0x30
000079bd661d42a7  movaps [rsp], xmm9
000079bd661d42ac  movaps [rsp+0x10], xmm7
000079bd661d42b1  movaps [rsp+0x20], xmm12
000079bd661d42b7  lea rdi, [rsp]
000079bd661d42bb  mov esi, 0x00
000079bd661d42c0  mov rax, 0x56EBD57B0530
000079bd661d42ca  call rax
000079bd661d42cc  movaps xmm9, [rsp]
000079bd661d42d1  add rsp, 0x30
000079bd661d42d5  vmovaps xmm0, [rsp]
000079bd661d42da  vmovaps xmm1, [rsp+0x10]
000079bd661d42e0  vmovaps xmm2, [rsp+0x20]
000079bd661d42e6  vmovaps xmm3, [rsp+0x30]
000079bd661d42ec  vmovaps xmm4, [rsp+0x40]
000079bd661d42f2  vmovaps xmm5, [rsp+0x50]
000079bd661d42f8  vmovaps xmm6, [rsp+0x60]
000079bd661d42fe  vmovaps xmm7, [rsp+0x70]
000079bd661d4304  vmovaps xmm8, [rsp+0x80]
000079bd661d430d  vmovaps xmm10, [rsp+0x90]
000079bd661d4316  vmovaps xmm11, [rsp+0xA0]
000079bd661d431f  vmovaps xmm12, [rsp+0xB0]
000079bd661d4328  vmovaps xmm13, [rsp+0xC0]
000079bd661d4331  vmovaps xmm14, [rsp+0xD0]
000079bd661d433a  vmovaps xmm15, [rsp+0xE0]
000079bd661d4343  add rsp, 0xF0
000079bd661d434a  pop r11
000079bd661d434c  pop r10
000079bd661d434e  pop r9
000079bd661d4350  pop r8
000079bd661d4352  pop rsi
000079bd661d4353  pop rdi
000079bd661d4354  pop rdx
000079bd661d4355  pop rcx
000079bd661d4356  pop rax
000079bd661d4357  add rsp, 0x08
000079bd661d435b  jmp 0x000079BD661D00DD
000079bd661d4360  sub rsp, 0x08
000079bd661d4364  push rax
000079bd661d4365  push rcx
000079bd661d4366  push rdx
000079bd661d4367  push rdi
000079bd661d4368  push rsi
000079bd661d4369  push r8
000079bd661d436b  push r9
000079bd661d436d  push r10
000079bd661d436f  push r11
000079bd661d4371  sub rsp, 0xF0
000079bd661d4378  vmovaps [rsp], xmm0
000079bd661d437d  vmovaps [rsp+0x10], xmm1
000079bd661d4383  vmovaps [rsp+0x20], xmm2
000079bd661d4389  vmovaps [rsp+0x30], xmm3
000079bd661d438f  vmovaps [rsp+0x40], xmm4
000079bd661d4395  vmovaps [rsp+0x50], xmm5
000079bd661d439b  vmovaps [rsp+0x60], xmm6
000079bd661d43a1  vmovaps [rsp+0x70], xmm7
000079bd661d43a7  vmovaps [rsp+0x80], xmm8
000079bd661d43b0  vmovaps [rsp+0x90], xmm9
000079bd661d43b9  vmovaps [rsp+0xA0], xmm10
000079bd661d43c2  vmovaps [rsp+0xB0], xmm11
000079bd661d43cb  vmovaps [rsp+0xC0], xmm13
000079bd661d43d4  vmovaps [rsp+0xD0], xmm14
000079bd661d43dd  vmovaps [rsp+0xE0], xmm15
000079bd661d43e6  sub rsp, 0x30
000079bd661d43ea  movaps [rsp], xmm12
000079bd661d43ef  movaps [rsp+0x10], xmm15
000079bd661d43f5  movaps [rsp+0x20], xmm11
000079bd661d43fb  lea rdi, [rsp]
000079bd661d43ff  mov esi, 0x00
000079bd661d4404  mov rax, 0x56EBD57B0530
000079bd661d440e  call rax
000079bd661d4410  movaps xmm12, [rsp]
000079bd661d4415  add rsp, 0x30
000079bd661d4419  vmovaps xmm0, [rsp]
000079bd661d441e  vmovaps xmm1, [rsp+0x10]
000079bd661d4424  vmovaps xmm2, [rsp+0x20]
000079bd661d442a  vmovaps xmm3, [rsp+0x30]
000079bd661d4430  vmovaps xmm4, [rsp+0x40]
000079bd661d4436  vmovaps xmm5, [rsp+0x50]
000079bd661d443c  vmovaps xmm6, [rsp+0x60]
000079bd661d4442  vmovaps xmm7, [rsp+0x70]
000079bd661d4448  vmovaps xmm8, [rsp+0x80]
000079bd661d4451  vmovaps xmm9, [rsp+0x90]
000079bd661d445a  vmovaps xmm10, [rsp+0xA0]
000079bd661d4463  vmovaps xmm11, [rsp+0xB0]
000079bd661d446c  vmovaps xmm13, [rsp+0xC0]
000079bd661d4475  vmovaps xmm14, [rsp+0xD0]
000079bd661d447e  vmovaps xmm15, [rsp+0xE0]
000079bd661d4487  add rsp, 0xF0
000079bd661d448e  pop r11
000079bd661d4490  pop r10
000079bd661d4492  pop r9
000079bd661d4494  pop r8
000079bd661d4496  pop rsi
000079bd661d4497  pop rdi
000079bd661d4498  pop rdx
000079bd661d4499  pop rcx
000079bd661d449a  pop rax
000079bd661d449b  add rsp, 0x08
000079bd661d449f  jmp 0x000079BD661D00F7
000079bd661d44a4  sub rsp, 0x08
000079bd661d44a8  push rax
000079bd661d44a9  push rcx
000079bd661d44aa  push rdx
000079bd661d44ab  push rdi
000079bd661d44ac  push rsi
000079bd661d44ad  push r8
000079bd661d44af  push r9
000079bd661d44b1  push r10
000079bd661d44b3  push r11
000079bd661d44b5  sub rsp, 0xF0
000079bd661d44bc  vmovaps [rsp], xmm0
000079bd661d44c1  vmovaps [rsp+0x10], xmm1
000079bd661d44c7  vmovaps [rsp+0x20], xmm2
000079bd661d44cd  vmovaps [rsp+0x30], xmm3
000079bd661d44d3  vmovaps [rsp+0x40], xmm4
000079bd661d44d9  vmovaps [rsp+0x50], xmm5
000079bd661d44df  vmovaps [rsp+0x60], xmm6
000079bd661d44e5  vmovaps [rsp+0x70], xmm7
000079bd661d44eb  vmovaps [rsp+0x80], xmm8
000079bd661d44f4  vmovaps [rsp+0x90], xmm9
000079bd661d44fd  vmovaps [rsp+0xA0], xmm10
000079bd661d4506  vmovaps [rsp+0xB0], xmm12
000079bd661d450f  vmovaps [rsp+0xC0], xmm13
000079bd661d4518  vmovaps [rsp+0xD0], xmm14
000079bd661d4521  vmovaps [rsp+0xE0], xmm15
000079bd661d452a  sub rsp, 0x30
000079bd661d452e  movaps [rsp], xmm11
000079bd661d4533  movaps [rsp+0x10], xmm7
000079bd661d4538  movaps [rsp+0x20], xmm15
000079bd661d453e  lea rdi, [rsp]
000079bd661d4542  mov esi, 0x00
000079bd661d4547  mov rax, 0x56EBD57B0530
000079bd661d4551  call rax
000079bd661d4553  movaps xmm11, [rsp]
000079bd661d4558  add rsp, 0x30
000079bd661d455c  vmovaps xmm0, [rsp]
000079bd661d4561  vmovaps xmm1, [rsp+0x10]
000079bd661d4567  vmovaps xmm2, [rsp+0x20]
000079bd661d456d  vmovaps xmm3, [rsp+0x30]
000079bd661d4573  vmovaps xmm4, [rsp+0x40]
000079bd661d4579  vmovaps xmm5, [rsp+0x50]
000079bd661d457f  vmovaps xmm6, [rsp+0x60]
000079bd661d4585  vmovaps xmm7, [rsp+0x70]
000079bd661d458b  vmovaps xmm8, [rsp+0x80]
000079bd661d4594  vmovaps xmm9, [rsp+0x90]
000079bd661d459d  vmovaps xmm10, [rsp+0xA0]
000079bd661d45a6  vmovaps xmm12, [rsp+0xB0]
000079bd661d45af  vmovaps xmm13, [rsp+0xC0]
000079bd661d45b8  vmovaps xmm14, [rsp+0xD0]
000079bd661d45c1  vmovaps xmm15, [rsp+0xE0]
000079bd661d45ca  add rsp, 0xF0
000079bd661d45d1  pop r11
000079bd661d45d3  pop r10
000079bd661d45d5  pop r9
000079bd661d45d7  pop r8
000079bd661d45d9  pop rsi
000079bd661d45da  pop rdi
000079bd661d45db  pop rdx
000079bd661d45dc  pop rcx
000079bd661d45dd  pop rax
000079bd661d45de  add rsp, 0x08
000079bd661d45e2  jmp 0x000079BD661D0123
000079bd661d45e7  sub rsp, 0x08
000079bd661d45eb  push rax
000079bd661d45ec  push rcx
000079bd661d45ed  push rdx
000079bd661d45ee  push rdi
000079bd661d45ef  push rsi
000079bd661d45f0  push r8
000079bd661d45f2  push r9
000079bd661d45f4  push r10
000079bd661d45f6  push r11
000079bd661d45f8  sub rsp, 0xF0
000079bd661d45ff  vmovaps [rsp], xmm0
000079bd661d4604  vmovaps [rsp+0x10], xmm1
000079bd661d460a  vmovaps [rsp+0x20], xmm2
000079bd661d4610  vmovaps [rsp+0x30], xmm3
000079bd661d4616  vmovaps [rsp+0x40], xmm4
000079bd661d461c  vmovaps [rsp+0x50], xmm5
000079bd661d4622  vmovaps [rsp+0x60], xmm6
000079bd661d4628  vmovaps [rsp+0x70], xmm7
000079bd661d462e  vmovaps [rsp+0x80], xmm8
000079bd661d4637  vmovaps [rsp+0x90], xmm9
000079bd661d4640  vmovaps [rsp+0xA0], xmm10
000079bd661d4649  vmovaps [rsp+0xB0], xmm11
000079bd661d4652  vmovaps [rsp+0xC0], xmm12
000079bd661d465b  vmovaps [rsp+0xD0], xmm13
000079bd661d4664  vmovaps [rsp+0xE0], xmm14
000079bd661d466d  sub rsp, 0x30
000079bd661d4671  movaps [rsp], xmm15
000079bd661d4676  movaps [rsp+0x10], xmm10
000079bd661d467c  movaps [rsp+0x20], xmm13
000079bd661d4682  lea rdi, [rsp]
000079bd661d4686  mov esi, 0x00
000079bd661d468b  mov rax, 0x56EBD57B0530
000079bd661d4695  call rax
000079bd661d4697  movaps xmm15, [rsp]
000079bd661d469c  add rsp, 0x30
000079bd661d46a0  vmovaps xmm0, [rsp]
000079bd661d46a5  vmovaps xmm1, [rsp+0x10]
000079bd661d46ab  vmovaps xmm2, [rsp+0x20]
000079bd661d46b1  vmovaps xmm3, [rsp+0x30]
000079bd661d46b7  vmovaps xmm4, [rsp+0x40]
000079bd661d46bd  vmovaps xmm5, [rsp+0x50]
000079bd661d46c3  vmovaps xmm6, [rsp+0x60]
000079bd661d46c9  vmovaps xmm7, [rsp+0x70]
000079bd661d46cf  vmovaps xmm8, [rsp+0x80]
000079bd661d46d8  vmovaps xmm9, [rsp+0x90]
000079bd661d46e1  vmovaps xmm10, [rsp+0xA0]
000079bd661d46ea  vmovaps xmm11, [rsp+0xB0]
000079bd661d46f3  vmovaps xmm12, [rsp+0xC0]
000079bd661d46fc  vmovaps xmm13, [rsp+0xD0]
000079bd661d4705  vmovaps xmm14, [rsp+0xE0]
000079bd661d470e  add rsp, 0xF0
000079bd661d4715  pop r11
000079bd661d4717  pop r10
000079bd661d4719  pop r9
000079bd661d471b  pop r8
000079bd661d471d  pop rsi
000079bd661d471e  pop rdi
000079bd661d471f  pop rdx
000079bd661d4720  pop rcx
000079bd661d4721  pop rax
000079bd661d4722  add rsp, 0x08
000079bd661d4726  jmp 0x000079BD661D013D
000079bd661d472b  sub rsp, 0x08
000079bd661d472f  push rax
000079bd661d4730  push rcx
000079bd661d4731  push rdx
000079bd661d4732  push rdi
000079bd661d4733  push rsi
000079bd661d4734  push r8
000079bd661d4736  push r9
000079bd661d4738  push r10
000079bd661d473a  push r11
000079bd661d473c  sub rsp, 0xF0
000079bd661d4743  vmovaps [rsp], xmm0
000079bd661d4748  vmovaps [rsp+0x10], xmm1
000079bd661d474e  vmovaps [rsp+0x20], xmm2
000079bd661d4754  vmovaps [rsp+0x30], xmm3
000079bd661d475a  vmovaps [rsp+0x40], xmm4
000079bd661d4760  vmovaps [rsp+0x50], xmm5
000079bd661d4766  vmovaps [rsp+0x60], xmm6
000079bd661d476c  vmovaps [rsp+0x70], xmm7
000079bd661d4772  vmovaps [rsp+0x80], xmm8
000079bd661d477b  vmovaps [rsp+0x90], xmm9
000079bd661d4784  vmovaps [rsp+0xA0], xmm11
000079bd661d478d  vmovaps [rsp+0xB0], xmm12
000079bd661d4796  vmovaps [rsp+0xC0], xmm13
000079bd661d479f  vmovaps [rsp+0xD0], xmm14
000079bd661d47a8  vmovaps [rsp+0xE0], xmm15
000079bd661d47b1  sub rsp, 0x30
000079bd661d47b5  movaps [rsp], xmm10
000079bd661d47ba  movaps [rsp+0x10], xmm7
000079bd661d47bf  movaps [rsp+0x20], xmm13
000079bd661d47c5  lea rdi, [rsp]
000079bd661d47c9  mov esi, 0x00
000079bd661d47ce  mov rax, 0x56EBD57B0530
000079bd661d47d8  call rax
000079bd661d47da  movaps xmm10, [rsp]
000079bd661d47df  add rsp, 0x30
000079bd661d47e3  vmovaps xmm0, [rsp]
000079bd661d47e8  vmovaps xmm1, [rsp+0x10]
000079bd661d47ee  vmovaps xmm2, [rsp+0x20]
000079bd661d47f4  vmovaps xmm3, [rsp+0x30]
000079bd661d47fa  vmovaps xmm4, [rsp+0x40]
000079bd661d4800  vmovaps xmm5, [rsp+0x50]
000079bd661d4806  vmovaps xmm6, [rsp+0x60]
000079bd661d480c  vmovaps xmm7, [rsp+0x70]
000079bd661d4812  vmovaps xmm8, [rsp+0x80]
000079bd661d481b  vmovaps xmm9, [rsp+0x90]
000079bd661d4824  vmovaps xmm11, [rsp+0xA0]
000079bd661d482d  vmovaps xmm12, [rsp+0xB0]
000079bd661d4836  vmovaps xmm13, [rsp+0xC0]
000079bd661d483f  vmovaps xmm14, [rsp+0xD0]
000079bd661d4848  vmovaps xmm15, [rsp+0xE0]
000079bd661d4851  add rsp, 0xF0
000079bd661d4858  pop r11
000079bd661d485a  pop r10
000079bd661d485c  pop r9
000079bd661d485e  pop r8
000079bd661d4860  pop rsi
000079bd661d4861  pop rdi
000079bd661d4862  pop rdx
000079bd661d4863  pop rcx
000079bd661d4864  pop rax
000079bd661d4865  add rsp, 0x08
000079bd661d4869  jmp 0x000079BD661D0169
000079bd661d486e  sub rsp, 0x08
000079bd661d4872  push rax
000079bd661d4873  push rcx
000079bd661d4874  push rdx
000079bd661d4875  push rdi
000079bd661d4876  push rsi
000079bd661d4877  push r8
000079bd661d4879  push r9
000079bd661d487b  push r10
000079bd661d487d  push r11
000079bd661d487f  sub rsp, 0xF0
000079bd661d4886  vmovaps [rsp], xmm0
000079bd661d488b  vmovaps [rsp+0x10], xmm1
000079bd661d4891  vmovaps [rsp+0x20], xmm2
000079bd661d4897  vmovaps [rsp+0x30], xmm3
000079bd661d489d  vmovaps [rsp+0x40], xmm4
000079bd661d48a3  vmovaps [rsp+0x50], xmm5
000079bd661d48a9  vmovaps [rsp+0x60], xmm6
000079bd661d48af  vmovaps [rsp+0x70], xmm7
000079bd661d48b5  vmovaps [rsp+0x80], xmm8
000079bd661d48be  vmovaps [rsp+0x90], xmm9
000079bd661d48c7  vmovaps [rsp+0xA0], xmm10
000079bd661d48d0  vmovaps [rsp+0xB0], xmm11
000079bd661d48d9  vmovaps [rsp+0xC0], xmm12
000079bd661d48e2  vmovaps [rsp+0xD0], xmm14
000079bd661d48eb  vmovaps [rsp+0xE0], xmm15
000079bd661d48f4  sub rsp, 0x30
000079bd661d48f8  movaps [rsp], xmm13
000079bd661d48fd  movaps [rsp+0x10], xmm1
000079bd661d4902  movaps [rsp+0x20], xmm8
000079bd661d4908  lea rdi, [rsp]
000079bd661d490c  mov esi, 0x00
000079bd661d4911  mov rax, 0x56EBD57B0530
000079bd661d491b  call rax
000079bd661d491d  movaps xmm13, [rsp]
000079bd661d4922  add rsp, 0x30
000079bd661d4926  vmovaps xmm0, [rsp]
000079bd661d492b  vmovaps xmm1, [rsp+0x10]
000079bd661d4931  vmovaps xmm2, [rsp+0x20]
000079bd661d4937  vmovaps xmm3, [rsp+0x30]
000079bd661d493d  vmovaps xmm4, [rsp+0x40]
000079bd661d4943  vmovaps xmm5, [rsp+0x50]
000079bd661d4949  vmovaps xmm6, [rsp+0x60]
000079bd661d494f  vmovaps xmm7, [rsp+0x70]
000079bd661d4955  vmovaps xmm8, [rsp+0x80]
000079bd661d495e  vmovaps xmm9, [rsp+0x90]
000079bd661d4967  vmovaps xmm10, [rsp+0xA0]
000079bd661d4970  vmovaps xmm11, [rsp+0xB0]
000079bd661d4979  vmovaps xmm12, [rsp+0xC0]
000079bd661d4982  vmovaps xmm14, [rsp+0xD0]
000079bd661d498b  vmovaps xmm15, [rsp+0xE0]
000079bd661d4994  add rsp, 0xF0
000079bd661d499b  pop r11
000079bd661d499d  pop r10
000079bd661d499f  pop r9
000079bd661d49a1  pop r8
000079bd661d49a3  pop rsi
000079bd661d49a4  pop rdi
000079bd661d49a5  pop rdx
000079bd661d49a6  pop rcx
000079bd661d49a7  pop rax
000079bd661d49a8  add rsp, 0x08
000079bd661d49ac  jmp 0x000079BD661D0183
000079bd661d49b1  call 0x000079BD65FFF430
000079bd661d49b6  jmp 0x000079BD661D018D
000079bd661d49bb  sub rsp, 0x08
000079bd661d49bf  push rax
000079bd661d49c0  push rcx
000079bd661d49c1  push rdx
000079bd661d49c2  push rdi
000079bd661d49c3  push rsi
000079bd661d49c4  push r8
000079bd661d49c6  push r9
000079bd661d49c8  push r10
000079bd661d49ca  push r11
000079bd661d49cc  sub rsp, 0xF0
000079bd661d49d3  vmovaps [rsp], xmm0
000079bd661d49d8  vmovaps [rsp+0x10], xmm1
000079bd661d49de  vmovaps [rsp+0x20], xmm2
000079bd661d49e4  vmovaps [rsp+0x30], xmm3
000079bd661d49ea  vmovaps [rsp+0x40], xmm4
000079bd661d49f0  vmovaps [rsp+0x50], xmm5
000079bd661d49f6  vmovaps [rsp+0x60], xmm6
000079bd661d49fc  vmovaps [rsp+0x70], xmm7
000079bd661d4a02  vmovaps [rsp+0x80], xmm9
000079bd661d4a0b  vmovaps [rsp+0x90], xmm10
000079bd661d4a14  vmovaps [rsp+0xA0], xmm11
000079bd661d4a1d  vmovaps [rsp+0xB0], xmm12
000079bd661d4a26  vmovaps [rsp+0xC0], xmm13
000079bd661d4a2f  vmovaps [rsp+0xD0], xmm14
000079bd661d4a38  vmovaps [rsp+0xE0], xmm15
000079bd661d4a41  sub rsp, 0x30
000079bd661d4a45  movaps [rsp], xmm8
000079bd661d4a4a  movaps [rsp+0x10], xmm14
000079bd661d4a50  movaps [rsp+0x20], xmm9
000079bd661d4a56  lea rdi, [rsp]
000079bd661d4a5a  mov esi, 0x00
000079bd661d4a5f  mov rax, 0x56EBD57B0530
000079bd661d4a69  call rax
000079bd661d4a6b  movaps xmm8, [rsp]
000079bd661d4a70  add rsp, 0x30
000079bd661d4a74  vmovaps xmm0, [rsp]
000079bd661d4a79  vmovaps xmm1, [rsp+0x10]
000079bd661d4a7f  vmovaps xmm2, [rsp+0x20]
000079bd661d4a85  vmovaps xmm3, [rsp+0x30]
000079bd661d4a8b  vmovaps xmm4, [rsp+0x40]
000079bd661d4a91  vmovaps xmm5, [rsp+0x50]
000079bd661d4a97  vmovaps xmm6, [rsp+0x60]
000079bd661d4a9d  vmovaps xmm7, [rsp+0x70]
000079bd661d4aa3  vmovaps xmm9, [rsp+0x80]
000079bd661d4aac  vmovaps xmm10, [rsp+0x90]
000079bd661d4ab5  vmovaps xmm11, [rsp+0xA0]
000079bd661d4abe  vmovaps xmm12, [rsp+0xB0]
000079bd661d4ac7  vmovaps xmm13, [rsp+0xC0]
000079bd661d4ad0  vmovaps xmm14, [rsp+0xD0]
000079bd661d4ad9  vmovaps xmm15, [rsp+0xE0]
000079bd661d4ae2  add rsp, 0xF0
000079bd661d4ae9  pop r11
000079bd661d4aeb  pop r10
000079bd661d4aed  pop r9
000079bd661d4aef  pop r8
000079bd661d4af1  pop rsi
000079bd661d4af2  pop rdi
000079bd661d4af3  pop rdx
000079bd661d4af4  pop rcx
000079bd661d4af5  pop rax
000079bd661d4af6  add rsp, 0x08
000079bd661d4afa  jmp 0x000079BD661D01AF
000079bd661d4aff  sub rsp, 0x08
000079bd661d4b03  push rax
000079bd661d4b04  push rcx
000079bd661d4b05  push rdx
000079bd661d4b06  push rdi
000079bd661d4b07  push rsi
000079bd661d4b08  push r8
000079bd661d4b0a  push r9
000079bd661d4b0c  push r10
000079bd661d4b0e  push r11
000079bd661d4b10  sub rsp, 0xF0
000079bd661d4b17  vmovaps [rsp], xmm0
000079bd661d4b1c  vmovaps [rsp+0x10], xmm1
000079bd661d4b22  vmovaps [rsp+0x20], xmm2
000079bd661d4b28  vmovaps [rsp+0x30], xmm3
000079bd661d4b2e  vmovaps [rsp+0x40], xmm4
000079bd661d4b34  vmovaps [rsp+0x50], xmm5
000079bd661d4b3a  vmovaps [rsp+0x60], xmm6
000079bd661d4b40  vmovaps [rsp+0x70], xmm7
000079bd661d4b46  vmovaps [rsp+0x80], xmm8
000079bd661d4b4f  vmovaps [rsp+0x90], xmm10
000079bd661d4b58  vmovaps [rsp+0xA0], xmm11
000079bd661d4b61  vmovaps [rsp+0xB0], xmm12
000079bd661d4b6a  vmovaps [rsp+0xC0], xmm13
000079bd661d4b73  vmovaps [rsp+0xD0], xmm14
000079bd661d4b7c  vmovaps [rsp+0xE0], xmm15
000079bd661d4b85  sub rsp, 0x30
000079bd661d4b89  movaps [rsp], xmm9
000079bd661d4b8e  movaps [rsp+0x10], xmm1
000079bd661d4b93  movaps [rsp+0x20], xmm14
000079bd661d4b99  lea rdi, [rsp]
000079bd661d4b9d  mov esi, 0x00
000079bd661d4ba2  mov rax, 0x56EBD57B0530
000079bd661d4bac  call rax
000079bd661d4bae  movaps xmm9, [rsp]
000079bd661d4bb3  add rsp, 0x30
000079bd661d4bb7  vmovaps xmm0, [rsp]
000079bd661d4bbc  vmovaps xmm1, [rsp+0x10]
000079bd661d4bc2  vmovaps xmm2, [rsp+0x20]
000079bd661d4bc8  vmovaps xmm3, [rsp+0x30]
000079bd661d4bce  vmovaps xmm4, [rsp+0x40]
000079bd661d4bd4  vmovaps xmm5, [rsp+0x50]
000079bd661d4bda  vmovaps xmm6, [rsp+0x60]
000079bd661d4be0  vmovaps xmm7, [rsp+0x70]
000079bd661d4be6  vmovaps xmm8, [rsp+0x80]
000079bd661d4bef  vmovaps xmm10, [rsp+0x90]
000079bd661d4bf8  vmovaps xmm11, [rsp+0xA0]
000079bd661d4c01  vmovaps xmm12, [rsp+0xB0]
000079bd661d4c0a  vmovaps xmm13, [rsp+0xC0]
000079bd661d4c13  vmovaps xmm14, [rsp+0xD0]
000079bd661d4c1c  vmovaps xmm15, [rsp+0xE0]
000079bd661d4c25  add rsp, 0xF0
000079bd661d4c2c  pop r11
000079bd661d4c2e  pop r10
000079bd661d4c30  pop r9
000079bd661d4c32  pop r8
000079bd661d4c34  pop rsi
000079bd661d4c35  pop rdi
000079bd661d4c36  pop rdx
000079bd661d4c37  pop rcx
000079bd661d4c38  pop rax
000079bd661d4c39  add rsp, 0x08
000079bd661d4c3d  jmp 0x000079BD661D01DD
000079bd661d4c42  sub rsp, 0x08
000079bd661d4c46  push rax
000079bd661d4c47  push rcx
000079bd661d4c48  push rdx
000079bd661d4c49  push rdi
000079bd661d4c4a  push rsi
000079bd661d4c4b  push r8
000079bd661d4c4d  push r9
000079bd661d4c4f  push r10
000079bd661d4c51  push r11
000079bd661d4c53  sub rsp, 0xF0
000079bd661d4c5a  vmovaps [rsp], xmm0
000079bd661d4c5f  vmovaps [rsp+0x10], xmm1
000079bd661d4c65  vmovaps [rsp+0x20], xmm2
000079bd661d4c6b  vmovaps [rsp+0x30], xmm3
000079bd661d4c71  vmovaps [rsp+0x40], xmm4
000079bd661d4c77  vmovaps [rsp+0x50], xmm5
000079bd661d4c7d  vmovaps [rsp+0x60], xmm6
000079bd661d4c83  vmovaps [rsp+0x70], xmm7
000079bd661d4c89  vmovaps [rsp+0x80], xmm8
000079bd661d4c92  vmovaps [rsp+0x90], xmm9
000079bd661d4c9b  vmovaps [rsp+0xA0], xmm10
000079bd661d4ca4  vmovaps [rsp+0xB0], xmm11
000079bd661d4cad  vmovaps [rsp+0xC0], xmm12
000079bd661d4cb6  vmovaps [rsp+0xD0], xmm13
000079bd661d4cbf  vmovaps [rsp+0xE0], xmm15
000079bd661d4cc8  sub rsp, 0x30
000079bd661d4ccc  movaps [rsp], xmm14
000079bd661d4cd1  movaps [rsp+0x10], xmm4
000079bd661d4cd6  movaps [rsp+0x20], xmm1
000079bd661d4cdb  lea rdi, [rsp]
000079bd661d4cdf  mov esi, 0x00
000079bd661d4ce4  mov rax, 0x56EBD57B0530
000079bd661d4cee  call rax
000079bd661d4cf0  movaps xmm14, [rsp]
000079bd661d4cf5  add rsp, 0x30
000079bd661d4cf9  vmovaps xmm0, [rsp]
000079bd661d4cfe  vmovaps xmm1, [rsp+0x10]
000079bd661d4d04  vmovaps xmm2, [rsp+0x20]
000079bd661d4d0a  vmovaps xmm3, [rsp+0x30]
000079bd661d4d10  vmovaps xmm4, [rsp+0x40]
000079bd661d4d16  vmovaps xmm5, [rsp+0x50]
000079bd661d4d1c  vmovaps xmm6, [rsp+0x60]
000079bd661d4d22  vmovaps xmm7, [rsp+0x70]
000079bd661d4d28  vmovaps xmm8, [rsp+0x80]
000079bd661d4d31  vmovaps xmm9, [rsp+0x90]
000079bd661d4d3a  vmovaps xmm10, [rsp+0xA0]
000079bd661d4d43  vmovaps xmm11, [rsp+0xB0]
000079bd661d4d4c  vmovaps xmm12, [rsp+0xC0]
000079bd661d4d55  vmovaps xmm13, [rsp+0xD0]
000079bd661d4d5e  vmovaps xmm15, [rsp+0xE0]
000079bd661d4d67  add rsp, 0xF0
000079bd661d4d6e  pop r11
000079bd661d4d70  pop r10
000079bd661d4d72  pop r9
000079bd661d4d74  pop r8
000079bd661d4d76  pop rsi
000079bd661d4d77  pop rdi
000079bd661d4d78  pop rdx
000079bd661d4d79  pop rcx
000079bd661d4d7a  pop rax
000079bd661d4d7b  add rsp, 0x08
000079bd661d4d7f  jmp 0x000079BD661D0203
000079bd661d4d84  sub rsp, 0x08
000079bd661d4d88  push rax
000079bd661d4d89  push rcx
000079bd661d4d8a  push rdx
000079bd661d4d8b  push rdi
000079bd661d4d8c  push rsi
000079bd661d4d8d  push r8
000079bd661d4d8f  push r9
000079bd661d4d91  push r10
000079bd661d4d93  push r11
000079bd661d4d95  sub rsp, 0xF0
000079bd661d4d9c  vmovaps [rsp], xmm0
000079bd661d4da1  vmovaps [rsp+0x10], xmm2
000079bd661d4da7  vmovaps [rsp+0x20], xmm3
000079bd661d4dad  vmovaps [rsp+0x30], xmm4
000079bd661d4db3  vmovaps [rsp+0x40], xmm5
000079bd661d4db9  vmovaps [rsp+0x50], xmm6
000079bd661d4dbf  vmovaps [rsp+0x60], xmm7
000079bd661d4dc5  vmovaps [rsp+0x70], xmm8
000079bd661d4dcb  vmovaps [rsp+0x80], xmm9
000079bd661d4dd4  vmovaps [rsp+0x90], xmm10
000079bd661d4ddd  vmovaps [rsp+0xA0], xmm11
000079bd661d4de6  vmovaps [rsp+0xB0], xmm12
000079bd661d4def  vmovaps [rsp+0xC0], xmm13
000079bd661d4df8  vmovaps [rsp+0xD0], xmm14
000079bd661d4e01  vmovaps [rsp+0xE0], xmm15
000079bd661d4e0a  sub rsp, 0x30
000079bd661d4e0e  movaps [rsp], xmm1
000079bd661d4e12  movaps [rsp+0x10], xmm12
000079bd661d4e18  movaps [rsp+0x20], xmm11
000079bd661d4e1e  lea rdi, [rsp]
000079bd661d4e22  mov esi, 0x00
000079bd661d4e27  mov rax, 0x56EBD57B0530
000079bd661d4e31  call rax
000079bd661d4e33  movaps xmm1, [rsp]
000079bd661d4e37  add rsp, 0x30
000079bd661d4e3b  vmovaps xmm0, [rsp]
000079bd661d4e40  vmovaps xmm2, [rsp+0x10]
000079bd661d4e46  vmovaps xmm3, [rsp+0x20]
000079bd661d4e4c  vmovaps xmm4, [rsp+0x30]
000079bd661d4e52  vmovaps xmm5, [rsp+0x40]
000079bd661d4e58  vmovaps xmm6, [rsp+0x50]
000079bd661d4e5e  vmovaps xmm7, [rsp+0x60]
000079bd661d4e64  vmovaps xmm8, [rsp+0x70]
000079bd661d4e6a  vmovaps xmm9, [rsp+0x80]
000079bd661d4e73  vmovaps xmm10, [rsp+0x90]
000079bd661d4e7c  vmovaps xmm11, [rsp+0xA0]
000079bd661d4e85  vmovaps xmm12, [rsp+0xB0]
000079bd661d4e8e  vmovaps xmm13, [rsp+0xC0]
000079bd661d4e97  vmovaps xmm14, [rsp+0xD0]
000079bd661d4ea0  vmovaps xmm15, [rsp+0xE0]
000079bd661d4ea9  add rsp, 0xF0
000079bd661d4eb0  pop r11
000079bd661d4eb2  pop r10
000079bd661d4eb4  pop r9
000079bd661d4eb6  pop r8
000079bd661d4eb8  pop rsi
000079bd661d4eb9  pop rdi
000079bd661d4eba  pop rdx
000079bd661d4ebb  pop rcx
000079bd661d4ebc  pop rax
000079bd661d4ebd  add rsp, 0x08
000079bd661d4ec1  jmp 0x000079BD661D0224
000079bd661d4ec6  call 0x000079BD660E20A0
000079bd661d4ecb  jmp 0x000079BD661D0232
000079bd661d4ed0  call 0x000079BD66009D70
000079bd661d4ed5  jmp 0x000079BD661D023C
000079bd661d4eda  sub rsp, 0x08
000079bd661d4ede  push rax
000079bd661d4edf  push rcx
000079bd661d4ee0  push rdx
000079bd661d4ee1  push rdi
000079bd661d4ee2  push rsi
000079bd661d4ee3  push r8
000079bd661d4ee5  push r9
000079bd661d4ee7  push r10
000079bd661d4ee9  push r11
000079bd661d4eeb  sub rsp, 0xF0
000079bd661d4ef2  vmovaps [rsp], xmm0
000079bd661d4ef7  vmovaps [rsp+0x10], xmm1
000079bd661d4efd  vmovaps [rsp+0x20], xmm2
000079bd661d4f03  vmovaps [rsp+0x30], xmm3
000079bd661d4f09  vmovaps [rsp+0x40], xmm4
000079bd661d4f0f  vmovaps [rsp+0x50], xmm5
000079bd661d4f15  vmovaps [rsp+0x60], xmm6
000079bd661d4f1b  vmovaps [rsp+0x70], xmm8
000079bd661d4f21  vmovaps [rsp+0x80], xmm9
000079bd661d4f2a  vmovaps [rsp+0x90], xmm10
000079bd661d4f33  vmovaps [rsp+0xA0], xmm11
000079bd661d4f3c  vmovaps [rsp+0xB0], xmm12
000079bd661d4f45  vmovaps [rsp+0xC0], xmm13
000079bd661d4f4e  vmovaps [rsp+0xD0], xmm14
000079bd661d4f57  vmovaps [rsp+0xE0], xmm15
000079bd661d4f60  sub rsp, 0x30
000079bd661d4f64  movaps [rsp], xmm7
000079bd661d4f68  movaps [rsp+0x10], xmm15
000079bd661d4f6e  movaps [rsp+0x20], xmm10
000079bd661d4f74  lea rdi, [rsp]
000079bd661d4f78  mov esi, 0x00
000079bd661d4f7d  mov rax, 0x56EBD57B0530
000079bd661d4f87  call rax
000079bd661d4f89  movaps xmm7, [rsp]
000079bd661d4f8d  add rsp, 0x30
000079bd661d4f91  vmovaps xmm0, [rsp]
000079bd661d4f96  vmovaps xmm1, [rsp+0x10]
000079bd661d4f9c  vmovaps xmm2, [rsp+0x20]
000079bd661d4fa2  vmovaps xmm3, [rsp+0x30]
000079bd661d4fa8  vmovaps xmm4, [rsp+0x40]
000079bd661d4fae  vmovaps xmm5, [rsp+0x50]
000079bd661d4fb4  vmovaps xmm6, [rsp+0x60]
000079bd661d4fba  vmovaps xmm8, [rsp+0x70]
000079bd661d4fc0  vmovaps xmm9, [rsp+0x80]
000079bd661d4fc9  vmovaps xmm10, [rsp+0x90]
000079bd661d4fd2  vmovaps xmm11, [rsp+0xA0]
000079bd661d4fdb  vmovaps xmm12, [rsp+0xB0]
000079bd661d4fe4  vmovaps xmm13, [rsp+0xC0]
000079bd661d4fed  vmovaps xmm14, [rsp+0xD0]
000079bd661d4ff6  vmovaps xmm15, [rsp+0xE0]
000079bd661d4fff  add rsp, 0xF0
000079bd661d5006  pop r11
000079bd661d5008  pop r10
000079bd661d500a  pop r9
000079bd661d500c  pop r8
000079bd661d500e  pop rsi
000079bd661d500f  pop rdi
000079bd661d5010  pop rdx
000079bd661d5011  pop rcx
000079bd661d5012  pop rax
000079bd661d5013  add rsp, 0x08
000079bd661d5017  jmp 0x000079BD661D025D
000079bd661d501c  sub rsp, 0x08
000079bd661d5020  push rax
000079bd661d5021  push rcx
000079bd661d5022  push rdx
000079bd661d5023  push rdi
000079bd661d5024  push rsi
000079bd661d5025  push r8
000079bd661d5027  push r9
000079bd661d5029  push r10
000079bd661d502b  push r11
000079bd661d502d  sub rsp, 0xF0
000079bd661d5034  vmovaps [rsp], xmm0
000079bd661d5039  vmovaps [rsp+0x10], xmm1
000079bd661d503f  vmovaps [rsp+0x20], xmm2
000079bd661d5045  vmovaps [rsp+0x30], xmm3
000079bd661d504b  vmovaps [rsp+0x40], xmm4
000079bd661d5051  vmovaps [rsp+0x50], xmm5
000079bd661d5057  vmovaps [rsp+0x60], xmm6
000079bd661d505d  vmovaps [rsp+0x70], xmm7
000079bd661d5063  vmovaps [rsp+0x80], xmm8
000079bd661d506c  vmovaps [rsp+0x90], xmm9
000079bd661d5075  vmovaps [rsp+0xA0], xmm11
000079bd661d507e  vmovaps [rsp+0xB0], xmm12
000079bd661d5087  vmovaps [rsp+0xC0], xmm13
000079bd661d5090  vmovaps [rsp+0xD0], xmm14
000079bd661d5099  vmovaps [rsp+0xE0], xmm15
000079bd661d50a2  sub rsp, 0x30
000079bd661d50a6  movaps [rsp], xmm10
000079bd661d50ab  movaps [rsp+0x10], xmm11
000079bd661d50b1  movaps [rsp+0x20], xmm15
000079bd661d50b7  lea rdi, [rsp]
000079bd661d50bb  mov esi, 0x00
000079bd661d50c0  mov rax, 0x56EBD57B0530
000079bd661d50ca  call rax
000079bd661d50cc  movaps xmm10, [rsp]
000079bd661d50d1  add rsp, 0x30
000079bd661d50d5  vmovaps xmm0, [rsp]
000079bd661d50da  vmovaps xmm1, [rsp+0x10]
000079bd661d50e0  vmovaps xmm2, [rsp+0x20]
000079bd661d50e6  vmovaps xmm3, [rsp+0x30]
000079bd661d50ec  vmovaps xmm4, [rsp+0x40]
000079bd661d50f2  vmovaps xmm5, [rsp+0x50]
000079bd661d50f8  vmovaps xmm6, [rsp+0x60]
000079bd661d50fe  vmovaps xmm7, [rsp+0x70]
000079bd661d5104  vmovaps xmm8, [rsp+0x80]
000079bd661d510d  vmovaps xmm9, [rsp+0x90]
000079bd661d5116  vmovaps xmm11, [rsp+0xA0]
000079bd661d511f  vmovaps xmm12, [rsp+0xB0]
000079bd661d5128  vmovaps xmm13, [rsp+0xC0]
000079bd661d5131  vmovaps xmm14, [rsp+0xD0]
000079bd661d513a  vmovaps xmm15, [rsp+0xE0]
000079bd661d5143  add rsp, 0xF0
000079bd661d514a  pop r11
000079bd661d514c  pop r10
000079bd661d514e  pop r9
000079bd661d5150  pop r8
000079bd661d5152  pop rsi
000079bd661d5153  pop rdi
000079bd661d5154  pop rdx
000079bd661d5155  pop rcx
000079bd661d5156  pop rax
000079bd661d5157  add rsp, 0x08
000079bd661d515b  jmp 0x000079BD661D028B
000079bd661d5160  sub rsp, 0x08
000079bd661d5164  push rax
000079bd661d5165  push rcx
000079bd661d5166  push rdx
000079bd661d5167  push rdi
000079bd661d5168  push rsi
000079bd661d5169  push r8
000079bd661d516b  push r9
000079bd661d516d  push r10
000079bd661d516f  push r11
000079bd661d5171  sub rsp, 0xF0
000079bd661d5178  vmovaps [rsp], xmm0
000079bd661d517d  vmovaps [rsp+0x10], xmm1
000079bd661d5183  vmovaps [rsp+0x20], xmm2
000079bd661d5189  vmovaps [rsp+0x30], xmm3
000079bd661d518f  vmovaps [rsp+0x40], xmm4
000079bd661d5195  vmovaps [rsp+0x50], xmm5
000079bd661d519b  vmovaps [rsp+0x60], xmm6
000079bd661d51a1  vmovaps [rsp+0x70], xmm7
000079bd661d51a7  vmovaps [rsp+0x80], xmm8
000079bd661d51b0  vmovaps [rsp+0x90], xmm9
000079bd661d51b9  vmovaps [rsp+0xA0], xmm10
000079bd661d51c2  vmovaps [rsp+0xB0], xmm12
000079bd661d51cb  vmovaps [rsp+0xC0], xmm13
000079bd661d51d4  vmovaps [rsp+0xD0], xmm14
000079bd661d51dd  vmovaps [rsp+0xE0], xmm15
000079bd661d51e6  sub rsp, 0x30
000079bd661d51ea  movaps [rsp], xmm11
000079bd661d51ef  movaps [rsp+0x10], xmm12
000079bd661d51f5  movaps [rsp+0x20], xmm15
000079bd661d51fb  lea rdi, [rsp]
000079bd661d51ff  mov esi, 0x00
000079bd661d5204  mov rax, 0x56EBD57B0530
000079bd661d520e  call rax
000079bd661d5210  movaps xmm11, [rsp]
000079bd661d5215  add rsp, 0x30
000079bd661d5219  vmovaps xmm0, [rsp]
000079bd661d521e  vmovaps xmm1, [rsp+0x10]
000079bd661d5224  vmovaps xmm2, [rsp+0x20]
000079bd661d522a  vmovaps xmm3, [rsp+0x30]
000079bd661d5230  vmovaps xmm4, [rsp+0x40]
000079bd661d5236  vmovaps xmm5, [rsp+0x50]
000079bd661d523c  vmovaps xmm6, [rsp+0x60]
000079bd661d5242  vmovaps xmm7, [rsp+0x70]
000079bd661d5248  vmovaps xmm8, [rsp+0x80]
000079bd661d5251  vmovaps xmm9, [rsp+0x90]
000079bd661d525a  vmovaps xmm10, [rsp+0xA0]
000079bd661d5263  vmovaps xmm12, [rsp+0xB0]
000079bd661d526c  vmovaps xmm13, [rsp+0xC0]
000079bd661d5275  vmovaps xmm14, [rsp+0xD0]
000079bd661d527e  vmovaps xmm15, [rsp+0xE0]
000079bd661d5287  add rsp, 0xF0
000079bd661d528e  pop r11
000079bd661d5290  pop r10
000079bd661d5292  pop r9
000079bd661d5294  pop r8
000079bd661d5296  pop rsi
000079bd661d5297  pop rdi
000079bd661d5298  pop rdx
000079bd661d5299  pop rcx
000079bd661d529a  pop rax
000079bd661d529b  add rsp, 0x08
000079bd661d529f  jmp 0x000079BD661D02B9
000079bd661d52a4  sub rsp, 0x08
000079bd661d52a8  push rax
000079bd661d52a9  push rcx
000079bd661d52aa  push rdx
000079bd661d52ab  push rdi
000079bd661d52ac  push rsi
000079bd661d52ad  push r8
000079bd661d52af  push r9
000079bd661d52b1  push r10
000079bd661d52b3  push r11
000079bd661d52b5  sub rsp, 0xF0
000079bd661d52bc  vmovaps [rsp], xmm0
000079bd661d52c1  vmovaps [rsp+0x10], xmm1
000079bd661d52c7  vmovaps [rsp+0x20], xmm2
000079bd661d52cd  vmovaps [rsp+0x30], xmm3
000079bd661d52d3  vmovaps [rsp+0x40], xmm4
000079bd661d52d9  vmovaps [rsp+0x50], xmm5
000079bd661d52df  vmovaps [rsp+0x60], xmm6
000079bd661d52e5  vmovaps [rsp+0x70], xmm7
000079bd661d52eb  vmovaps [rsp+0x80], xmm8
000079bd661d52f4  vmovaps [rsp+0x90], xmm9
000079bd661d52fd  vmovaps [rsp+0xA0], xmm10
000079bd661d5306  vmovaps [rsp+0xB0], xmm11
000079bd661d530f  vmovaps [rsp+0xC0], xmm12
000079bd661d5318  vmovaps [rsp+0xD0], xmm13
000079bd661d5321  vmovaps [rsp+0xE0], xmm14
000079bd661d532a  sub rsp, 0x30
000079bd661d532e  movaps [rsp], xmm15
000079bd661d5333  movaps [rsp+0x10], xmm13
000079bd661d5339  movaps [rsp+0x20], xmm9
000079bd661d533f  lea rdi, [rsp]
000079bd661d5343  mov esi, 0x00
000079bd661d5348  mov rax, 0x56EBD57B0530
000079bd661d5352  call rax
000079bd661d5354  movaps xmm15, [rsp]
000079bd661d5359  add rsp, 0x30
000079bd661d535d  vmovaps xmm0, [rsp]
000079bd661d5362  vmovaps xmm1, [rsp+0x10]
000079bd661d5368  vmovaps xmm2, [rsp+0x20]
000079bd661d536e  vmovaps xmm3, [rsp+0x30]
000079bd661d5374  vmovaps xmm4, [rsp+0x40]
000079bd661d537a  vmovaps xmm5, [rsp+0x50]
000079bd661d5380  vmovaps xmm6, [rsp+0x60]
000079bd661d5386  vmovaps xmm7, [rsp+0x70]
000079bd661d538c  vmovaps xmm8, [rsp+0x80]
000079bd661d5395  vmovaps xmm9, [rsp+0x90]
000079bd661d539e  vmovaps xmm10, [rsp+0xA0]
000079bd661d53a7  vmovaps xmm11, [rsp+0xB0]
000079bd661d53b0  vmovaps xmm12, [rsp+0xC0]
000079bd661d53b9  vmovaps xmm13, [rsp+0xD0]
000079bd661d53c2  vmovaps xmm14, [rsp+0xE0]
000079bd661d53cb  add rsp, 0xF0
000079bd661d53d2  pop r11
000079bd661d53d4  pop r10
000079bd661d53d6  pop r9
000079bd661d53d8  pop r8
000079bd661d53da  pop rsi
000079bd661d53db  pop rdi
000079bd661d53dc  pop rdx
000079bd661d53dd  pop rcx
000079bd661d53de  pop rax
000079bd661d53df  add rsp, 0x08
000079bd661d53e3  jmp 0x000079BD661D02D4
000079bd661d53e8  sub rsp, 0x08
000079bd661d53ec  push rax
000079bd661d53ed  push rcx
000079bd661d53ee  push rdx
000079bd661d53ef  push rdi
000079bd661d53f0  push rsi
000079bd661d53f1  push r8
000079bd661d53f3  push r9
000079bd661d53f5  push r10
000079bd661d53f7  push r11
000079bd661d53f9  sub rsp, 0xF0
000079bd661d5400  vmovaps [rsp], xmm0
000079bd661d5405  vmovaps [rsp+0x10], xmm1
000079bd661d540b  vmovaps [rsp+0x20], xmm2
000079bd661d5411  vmovaps [rsp+0x30], xmm3
000079bd661d5417  vmovaps [rsp+0x40], xmm4
000079bd661d541d  vmovaps [rsp+0x50], xmm5
000079bd661d5423  vmovaps [rsp+0x60], xmm6
000079bd661d5429  vmovaps [rsp+0x70], xmm7
000079bd661d542f  vmovaps [rsp+0x80], xmm8
000079bd661d5438  vmovaps [rsp+0x90], xmm9
000079bd661d5441  vmovaps [rsp+0xA0], xmm10
000079bd661d544a  vmovaps [rsp+0xB0], xmm11
000079bd661d5453  vmovaps [rsp+0xC0], xmm12
000079bd661d545c  vmovaps [rsp+0xD0], xmm14
000079bd661d5465  vmovaps [rsp+0xE0], xmm15
000079bd661d546e  sub rsp, 0x30
000079bd661d5472  movaps [rsp], xmm13
000079bd661d5477  movaps [rsp+0x10], xmm8
000079bd661d547d  movaps [rsp+0x20], xmm14
000079bd661d5483  lea rdi, [rsp]
000079bd661d5487  mov esi, 0x00
000079bd661d548c  mov rax, 0x56EBD57B0530
000079bd661d5496  call rax
000079bd661d5498  movaps xmm13, [rsp]
000079bd661d549d  add rsp, 0x30
000079bd661d54a1  vmovaps xmm0, [rsp]
000079bd661d54a6  vmovaps xmm1, [rsp+0x10]
000079bd661d54ac  vmovaps xmm2, [rsp+0x20]
000079bd661d54b2  vmovaps xmm3, [rsp+0x30]
000079bd661d54b8  vmovaps xmm4, [rsp+0x40]
000079bd661d54be  vmovaps xmm5, [rsp+0x50]
000079bd661d54c4  vmovaps xmm6, [rsp+0x60]
000079bd661d54ca  vmovaps xmm7, [rsp+0x70]
000079bd661d54d0  vmovaps xmm8, [rsp+0x80]
000079bd661d54d9  vmovaps xmm9, [rsp+0x90]
000079bd661d54e2  vmovaps xmm10, [rsp+0xA0]
000079bd661d54eb  vmovaps xmm11, [rsp+0xB0]
000079bd661d54f4  vmovaps xmm12, [rsp+0xC0]
000079bd661d54fd  vmovaps xmm14, [rsp+0xD0]
000079bd661d5506  vmovaps xmm15, [rsp+0xE0]
000079bd661d550f  add rsp, 0xF0
000079bd661d5516  pop r11
000079bd661d5518  pop r10
000079bd661d551a  pop r9
000079bd661d551c  pop r8
000079bd661d551e  pop rsi
000079bd661d551f  pop rdi
000079bd661d5520  pop rdx
000079bd661d5521  pop rcx
000079bd661d5522  pop rax
000079bd661d5523  add rsp, 0x08
000079bd661d5527  jmp 0x000079BD661D02F7
000079bd661d552c  sub rsp, 0x08
000079bd661d5530  push rax
000079bd661d5531  push rcx
000079bd661d5532  push rdx
000079bd661d5533  push rdi
000079bd661d5534  push rsi
000079bd661d5535  push r8
000079bd661d5537  push r9
000079bd661d5539  push r10
000079bd661d553b  push r11
000079bd661d553d  sub rsp, 0xF0
000079bd661d5544  vmovaps [rsp], xmm0
000079bd661d5549  vmovaps [rsp+0x10], xmm1
000079bd661d554f  vmovaps [rsp+0x20], xmm2
000079bd661d5555  vmovaps [rsp+0x30], xmm3
000079bd661d555b  vmovaps [rsp+0x40], xmm4
000079bd661d5561  vmovaps [rsp+0x50], xmm5
000079bd661d5567  vmovaps [rsp+0x60], xmm6
000079bd661d556d  vmovaps [rsp+0x70], xmm7
000079bd661d5573  vmovaps [rsp+0x80], xmm8
000079bd661d557c  vmovaps [rsp+0x90], xmm9
000079bd661d5585  vmovaps [rsp+0xA0], xmm10
000079bd661d558e  vmovaps [rsp+0xB0], xmm11
000079bd661d5597  vmovaps [rsp+0xC0], xmm12
000079bd661d55a0  vmovaps [rsp+0xD0], xmm13
000079bd661d55a9  vmovaps [rsp+0xE0], xmm15
000079bd661d55b2  sub rsp, 0x30
000079bd661d55b6  movaps [rsp], xmm14
000079bd661d55bb  movaps [rsp+0x10], xmm1
000079bd661d55c0  movaps [rsp+0x20], xmm10
000079bd661d55c6  lea rdi, [rsp]
000079bd661d55ca  mov esi, 0x00
000079bd661d55cf  mov rax, 0x56EBD57B0530
000079bd661d55d9  call rax
000079bd661d55db  movaps xmm14, [rsp]
000079bd661d55e0  add rsp, 0x30
000079bd661d55e4  vmovaps xmm0, [rsp]
000079bd661d55e9  vmovaps xmm1, [rsp+0x10]
000079bd661d55ef  vmovaps xmm2, [rsp+0x20]
000079bd661d55f5  vmovaps xmm3, [rsp+0x30]
000079bd661d55fb  vmovaps xmm4, [rsp+0x40]
000079bd661d5601  vmovaps xmm5, [rsp+0x50]
000079bd661d5607  vmovaps xmm6, [rsp+0x60]
000079bd661d560d  vmovaps xmm7, [rsp+0x70]
000079bd661d5613  vmovaps xmm8, [rsp+0x80]
000079bd661d561c  vmovaps xmm9, [rsp+0x90]
000079bd661d5625  vmovaps xmm10, [rsp+0xA0]
000079bd661d562e  vmovaps xmm11, [rsp+0xB0]
000079bd661d5637  vmovaps xmm12, [rsp+0xC0]
000079bd661d5640  vmovaps xmm13, [rsp+0xD0]
000079bd661d5649  vmovaps xmm15, [rsp+0xE0]
000079bd661d5652  add rsp, 0xF0
000079bd661d5659  pop r11
000079bd661d565b  pop r10
000079bd661d565d  pop r9
000079bd661d565f  pop r8
000079bd661d5661  pop rsi
000079bd661d5662  pop rdi
000079bd661d5663  pop rdx
000079bd661d5664  pop rcx
000079bd661d5665  pop rax
000079bd661d5666  add rsp, 0x08
000079bd661d566a  jmp 0x000079BD661D031A
000079bd661d566f  sub rsp, 0x08
000079bd661d5673  push rax
000079bd661d5674  push rcx
000079bd661d5675  push rdx
000079bd661d5676  push rdi
000079bd661d5677  push rsi
000079bd661d5678  push r8
000079bd661d567a  push r9
000079bd661d567c  push r10
000079bd661d567e  push r11
000079bd661d5680  sub rsp, 0xF0
000079bd661d5687  vmovaps [rsp], xmm0
000079bd661d568c  vmovaps [rsp+0x10], xmm2
000079bd661d5692  vmovaps [rsp+0x20], xmm3
000079bd661d5698  vmovaps [rsp+0x30], xmm4
000079bd661d569e  vmovaps [rsp+0x40], xmm5
000079bd661d56a4  vmovaps [rsp+0x50], xmm6
000079bd661d56aa  vmovaps [rsp+0x60], xmm7
000079bd661d56b0  vmovaps [rsp+0x70], xmm8
000079bd661d56b6  vmovaps [rsp+0x80], xmm9
000079bd661d56bf  vmovaps [rsp+0x90], xmm10
000079bd661d56c8  vmovaps [rsp+0xA0], xmm11
000079bd661d56d1  vmovaps [rsp+0xB0], xmm12
000079bd661d56da  vmovaps [rsp+0xC0], xmm13
000079bd661d56e3  vmovaps [rsp+0xD0], xmm14
000079bd661d56ec  vmovaps [rsp+0xE0], xmm15
000079bd661d56f5  sub rsp, 0x30
000079bd661d56f9  movaps [rsp], xmm1
000079bd661d56fd  movaps [rsp+0x10], xmm7
000079bd661d5702  movaps [rsp+0x20], xmm11
000079bd661d5708  lea rdi, [rsp]
000079bd661d570c  mov esi, 0x00
000079bd661d5711  mov rax, 0x56EBD57B0530
000079bd661d571b  call rax
000079bd661d571d  movaps xmm1, [rsp]
000079bd661d5721  add rsp, 0x30
000079bd661d5725  vmovaps xmm0, [rsp]
000079bd661d572a  vmovaps xmm2, [rsp+0x10]
000079bd661d5730  vmovaps xmm3, [rsp+0x20]
000079bd661d5736  vmovaps xmm4, [rsp+0x30]
000079bd661d573c  vmovaps xmm5, [rsp+0x40]
000079bd661d5742  vmovaps xmm6, [rsp+0x50]
000079bd661d5748  vmovaps xmm7, [rsp+0x60]
000079bd661d574e  vmovaps xmm8, [rsp+0x70]
000079bd661d5754  vmovaps xmm9, [rsp+0x80]
000079bd661d575d  vmovaps xmm10, [rsp+0x90]
000079bd661d5766  vmovaps xmm11, [rsp+0xA0]
000079bd661d576f  vmovaps xmm12, [rsp+0xB0]
000079bd661d5778  vmovaps xmm13, [rsp+0xC0]
000079bd661d5781  vmovaps xmm14, [rsp+0xD0]
000079bd661d578a  vmovaps xmm15, [rsp+0xE0]
000079bd661d5793  add rsp, 0xF0
000079bd661d579a  pop r11
000079bd661d579c  pop r10
000079bd661d579e  pop r9
000079bd661d57a0  pop r8
000079bd661d57a2  pop rsi
000079bd661d57a3  pop rdi
000079bd661d57a4  pop rdx
000079bd661d57a5  pop rcx
000079bd661d57a6  pop rax
000079bd661d57a7  add rsp, 0x08
000079bd661d57ab  jmp 0x000079BD661D033B
000079bd661d57b0  call 0x000079BD6600E880
000079bd661d57b5  jmp 0x000079BD661D034E
000079bd661d57ba  call 0x000079BD6600C380
000079bd661d57bf  jmp 0x000079BD661D0359
000079bd661d57c4  call 0x000079BD6600D600
000079bd661d57c9  jmp 0x000079BD661D0364
000079bd661d57ce  call 0x000079BD65FFF540
000079bd661d57d3  jmp 0x000079BD661D036F
000079bd661d57d8  int3
000079bd661d57d9  nop [rax], eax
000079bd661d57e0  mov rax, [r15+0x40]
000079bd661d57e4  mov r14, [r15+0x58]
000079bd661d57e8  lea r12, [rax+r14*1]
000079bd661d57ec  movaps xmm1, [r15+0x1D0]
000079bd661d57f4  vmovaps [rsp+0x10], xmm1
000079bd661d57fa  vmovaps xmm15, [rsp+0x10]
000079bd661d5800  por xmm1, xmm15
000079bd661d5805  movaps xmm14, [r15+0x1A0]
000079bd661d580d  vmovaps [rsp+0x10], xmm14
000079bd661d5813  vmovaps xmm13, [rsp+0x10]
000079bd661d5819  por xmm14, xmm13
000079bd661d581e  lea rax, [r12+0x30]
000079bd661d5823  mov r11, [r13+rax*1]
000079bd661d5828  lea rax, [r12+0x38]
000079bd661d582d  mov r10, [r13+rax*1]
000079bd661d5832  movq xmm13, r11
000079bd661d5837  movq xmm12, r10
000079bd661d583c  movq xmm13, xmm13
000079bd661d5841  vmovaps [rsp+0x10], xmm13
000079bd661d5847  movq xmm13, xmm13
000079bd661d584c  movaps [r15+0x130], xmm13
000079bd661d5854  movq xmm12, xmm12
000079bd661d5859  vmovaps [rsp+0x20], xmm12
000079bd661d585f  movq xmm12, xmm12
000079bd661d5864  movaps [r15+0x280], xmm12
000079bd661d586c  movaps xmm13, [r15+0x270]
000079bd661d5874  vmovaps [rsp+0x30], xmm13
000079bd661d587a  vmovaps xmm12, [rsp+0x30]
000079bd661d5880  por xmm13, xmm12
000079bd661d5885  lea rax, [r12+0x20]
000079bd661d588a  mov r11, [r13+rax*1]
000079bd661d588f  lea rax, [r12+0x28]
000079bd661d5894  mov r10, [r13+rax*1]
000079bd661d5899  movq xmm12, r11
000079bd661d589e  movq xmm11, r10
000079bd661d58a3  movq xmm12, xmm12
000079bd661d58a8  vmovaps [rsp+0x30], xmm12
000079bd661d58ae  movq xmm12, xmm12
000079bd661d58b3  movaps [r15+0x150], xmm12
000079bd661d58bb  movq xmm11, xmm11
000079bd661d58c0  vmovaps [rsp+0x40], xmm11
000079bd661d58c6  movq xmm11, xmm11
000079bd661d58cb  movaps [r15+0x140], xmm11
000079bd661d58d3  lea rax, [r12+0x10]
000079bd661d58d8  mov r11, [r13+rax*1]
000079bd661d58dd  lea rax, [r12+0x18]
000079bd661d58e2  mov r10, [r13+rax*1]
000079bd661d58e7  movq xmm12, r11
000079bd661d58ec  movq xmm11, r10
000079bd661d58f1  movq xmm12, xmm12
000079bd661d58f6  vmovaps [rsp+0x50], xmm12
000079bd661d58fc  movq xmm12, xmm12
000079bd661d5901  movaps [r15+0x170], xmm12
000079bd661d5909  movq xmm11, xmm11
000079bd661d590e  vmovaps [rsp+0x60], xmm11
000079bd661d5914  movq xmm11, xmm11
000079bd661d5919  movaps [r15+0x160], xmm11
000079bd661d5921  mov rax, [r13+r12*1]
000079bd661d5926  vmovq xmm12, rax
000079bd661d592b  vpbroadcastq xmm12, xmm12
000079bd661d5930  lea rax, [r12+0x08]
000079bd661d5935  mov r12, [r13+rax*1]
000079bd661d593a  movq xmm11, r12
000079bd661d593f  movaps [r15+0x230], xmm11
000079bd661d5947  mov rax, [r15+0xF8]
000079bd661d594e  lea r12, [rax+0x50]
000079bd661d5952  movups xmm11, [r13+r12*1]
000079bd661d5958  lea r12, [rax+0x60]
000079bd661d595c  movups xmm10, [r13+r12*1]
000079bd661d5962  lea r12, [rax+0x30]
000079bd661d5966  movups xmm9, [r13+r12*1]
000079bd661d596c  mov r12, [r15+0x50]
000079bd661d5970  lea r11, [r12+r14*1]
000079bd661d5974  mov [r15+0x60], r11
000079bd661d5978  lea r12, [r14+0x40]
000079bd661d597c  mov [r15+0x58], r12
000079bd661d5980  movaps xmm8, xmm12
000079bd661d5984  mulpd xmm8, xmm15
000079bd661d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000079bd661d598f  ptest xmm7, xmm7
000079bd661d5994  jnz 0x000079BD661D67B7
000079bd661d599a  movq xmm15, qword ptr [r15+0x230]
000079bd661d59a3  vmovaps [rsp+0x70], xmm15
000079bd661d59a9  vpermilpd xmm15, xmm15, 0x00
000079bd661d59af  movaps xmm7, xmm9
000079bd661d59b3  mulpd xmm7, xmm15
000079bd661d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000079bd661d59bd  ptest xmm6, xmm6
000079bd661d59c2  jnz 0x000079BD661D68FB
000079bd661d59c8  vxorps xmm15, xmm15, xmm15
000079bd661d59cd  vpbroadcastq xmm15, xmm15
000079bd661d59d2  movaps xmm9, xmm12
000079bd661d59d6  mulpd xmm9, xmm10
000079bd661d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000079bd661d59e1  ptest xmm6, xmm6
000079bd661d59e6  jnz 0x000079BD661D6A3D
000079bd661d59ec  movaps xmm10, xmm12
000079bd661d59f0  mulpd xmm10, xmm11
000079bd661d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000079bd661d59fb  ptest xmm6, xmm6
000079bd661d5a00  jnz 0x000079BD661D6B81
000079bd661d5a06  movaps xmm11, [r15+0x1F0]
000079bd661d5a0e  movaps xmm6, xmm12
000079bd661d5a12  mulpd xmm6, xmm11
000079bd661d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000079bd661d5a1c  ptest xmm5, xmm5
000079bd661d5a21  jnz 0x000079BD661D6CC5
000079bd661d5a27  movaps xmm12, [r15+0x2A0]
000079bd661d5a2f  vmovaps [rsp+0x80], xmm12
000079bd661d5a38  vmovaps xmm11, [rsp+0x80]
000079bd661d5a41  por xmm12, xmm11
000079bd661d5a46  movaps xmm11, [r15+0x250]
000079bd661d5a4e  vmovaps [rsp+0x80], xmm11
000079bd661d5a57  vmovaps xmm5, [rsp+0x80]
000079bd661d5a60  por xmm11, xmm5
000079bd661d5a65  vmovaps xmm4, [rsp+0x70]
000079bd661d5a6b  vpermilpd xmm4, xmm4, 0x00
000079bd661d5a71  movaps xmm3, xmm5
000079bd661d5a74  mulpd xmm3, xmm4
000079bd661d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000079bd661d5a7d  ptest xmm2, xmm2
000079bd661d5a82  jnz 0x000079BD661D6E07
000079bd661d5a88  mov [rsp+0x80], rax
000079bd661d5a90  xor eax, eax
000079bd661d5a92  mov r14d, 0x200
000079bd661d5a98  cmp r12, r14
000079bd661d5a9b  cmc
000079bd661d5a9c  lahf
000079bd661d5a9d  seto al
000079bd661d5aa0  mov [r15+0x108], eax
000079bd661d5aa7  movaps xmm5, xmm8
000079bd661d5aab  addpd xmm5, xmm15
000079bd661d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000079bd661d5ab5  ptest xmm4, xmm4
000079bd661d5aba  jnz 0x000079BD661D6F47
000079bd661d5ac0  movaps xmm8, [r15+0x1B0]
000079bd661d5ac8  movaps xmm4, xmm9
000079bd661d5acc  addpd xmm4, xmm8
000079bd661d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000079bd661d5ad6  ptest xmm2, xmm2
000079bd661d5adb  jnz 0x000079BD661D7089
000079bd661d5ae1  movaps xmm9, xmm10
000079bd661d5ae5  addpd xmm9, xmm8
000079bd661d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000079bd661d5af0  ptest xmm2, xmm2
000079bd661d5af5  jnz 0x000079BD661D71CB
000079bd661d5afb  movaps xmm10, [r15+0x2F0]
000079bd661d5b03  vmovaps [rsp+0x90], xmm10
000079bd661d5b0c  vmovaps xmm8, [rsp+0x90]
000079bd661d5b15  por xmm10, xmm8
000079bd661d5b1a  movaps xmm8, [r15+0x2E0]
000079bd661d5b22  vmovaps [rsp+0x90], xmm8
000079bd661d5b2b  vmovaps xmm2, [rsp+0x90]
000079bd661d5b34  por xmm8, xmm2
000079bd661d5b39  movaps xmm2, [r15+0x2D0]
000079bd661d5b41  vmovaps [rsp+0x90], xmm2
000079bd661d5b4a  vmovaps [rsp+0xA0], xmm1
000079bd661d5b53  vmovaps xmm1, [rsp+0x90]
000079bd661d5b5c  por xmm2, xmm1
000079bd661d5b60  movaps xmm1, [r15+0x200]
000079bd661d5b68  vmovaps [rsp+0x90], xmm1
000079bd661d5b71  vmovaps [rsp+0xB0], xmm15
000079bd661d5b7a  vmovaps xmm15, [rsp+0x90]
000079bd661d5b83  por xmm1, xmm15
000079bd661d5b88  movaps xmm15, [r15+0x1C0]
000079bd661d5b90  vmovaps [rsp+0x90], xmm15
000079bd661d5b99  vmovaps [rsp+0xC0], xmm1
000079bd661d5ba2  vmovaps xmm1, [rsp+0x90]
000079bd661d5bab  por xmm15, xmm1
000079bd661d5bb0  movaps xmm1, [r15+0x190]
000079bd661d5bb8  vmovaps [rsp+0x90], xmm1
000079bd661d5bc1  vmovaps [rsp+0xD0], xmm15
000079bd661d5bca  vmovaps xmm15, [rsp+0x90]
000079bd661d5bd3  por xmm1, xmm15
000079bd661d5bd8  movaps xmm15, [r15+0x300]
000079bd661d5be0  vmovaps [rsp+0x90], xmm15
000079bd661d5be9  vmovaps [rsp+0xE0], xmm1
000079bd661d5bf2  vmovaps xmm1, [rsp+0x90]
000079bd661d5bfb  por xmm15, xmm1
000079bd661d5c00  mov rax, [rsp+0x80]
000079bd661d5c08  lea r14, [rax+0xA0]
000079bd661d5c0f  movups xmm1, [r13+r14*1]
000079bd661d5c15  lea r14, [rax+0xB0]
000079bd661d5c1c  vmovaps [rsp+0x80], xmm1
000079bd661d5c25  movups xmm1, [r13+r14*1]
000079bd661d5c2b  vmovaps [rsp+0x90], xmm1
000079bd661d5c34  vmovaps [rsp+0xF0], xmm15
000079bd661d5c3d  vmovaps xmm15, [rsp+0xB0]
000079bd661d5c46  vmovaps [rsp+0xB0], xmm14
000079bd661d5c4f  movaps xmm1, xmm6
000079bd661d5c52  addpd xmm1, xmm15
000079bd661d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000079bd661d5c5c  ptest xmm14, xmm14
000079bd661d5c62  jnz 0x000079BD661D7323
000079bd661d5c68  lea r14, [rax+0xF0]
000079bd661d5c6f  movups xmm15, [r13+r14*1]
000079bd661d5c75  movaps xmm14, xmm4
000079bd661d5c79  addpd xmm14, xmm3
000079bd661d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000079bd661d5c84  ptest xmm6, xmm6
000079bd661d5c89  jnz 0x000079BD661D746E
000079bd661d5c8f  movaps xmm6, xmm9
000079bd661d5c93  addpd xmm6, xmm7
000079bd661d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000079bd661d5c9c  ptest xmm4, xmm4
000079bd661d5ca1  jnz 0x000079BD661D75B0
000079bd661d5ca7  vmovaps xmm9, [rsp+0x70]
000079bd661d5cad  vpermilpd xmm9, xmm9, 0x00
000079bd661d5cb3  vmovaps xmm4, [rsp+0x90]
000079bd661d5cbc  movaps xmm7, xmm4
000079bd661d5cbf  mulpd xmm7, xmm9
000079bd661d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000079bd661d5cc9  ptest xmm3, xmm3
000079bd661d5cce  jnz 0x000079BD661D76F1
000079bd661d5cd4  vmovaps xmm9, [rsp+0x50]
000079bd661d5cda  vpermilpd xmm9, xmm9, 0x00
000079bd661d5ce0  movaps xmm4, xmm15
000079bd661d5ce4  mulpd xmm4, xmm9
000079bd661d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000079bd661d5cee  ptest xmm3, xmm3
000079bd661d5cf3  jnz 0x000079BD661D7832
000079bd661d5cf9  lea r14, [rax+0xE0]
000079bd661d5d00  movups xmm15, [r13+r14*1]
000079bd661d5d06  vmovaps xmm9, [rsp+0x70]
000079bd661d5d0c  vpermilpd xmm9, xmm9, 0x00
000079bd661d5d12  vmovaps [rsp+0x70], xmm1
000079bd661d5d18  vmovaps xmm1, [rsp+0x80]
000079bd661d5d21  vmovaps [rsp+0x80], xmm15
000079bd661d5d2a  movaps xmm3, xmm1
000079bd661d5d2d  mulpd xmm3, xmm9
000079bd661d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000079bd661d5d37  ptest xmm15, xmm15
000079bd661d5d3d  jnz 0x000079BD661D797E
000079bd661d5d43  vmovaps xmm1, [rsp+0xF0]
000079bd661d5d4c  vmovaps xmm15, [rsp+0xF0]
000079bd661d5d55  por xmm1, xmm15
000079bd661d5d5a  movaps [r15+0x300], xmm1
000079bd661d5d62  vmovaps xmm15, [rsp+0xE0]
000079bd661d5d6b  vmovaps xmm9, [rsp+0xE0]
000079bd661d5d74  por xmm15, xmm9
000079bd661d5d79  movaps [r15+0x190], xmm15
000079bd661d5d81  vmovaps xmm9, [rsp+0x50]
000079bd661d5d87  vpermilpd xmm9, xmm9, 0x00
000079bd661d5d8d  vmovaps [rsp+0x90], xmm1
000079bd661d5d96  vmovaps [rsp+0xE0], xmm15
000079bd661d5d9f  vmovaps xmm15, [rsp+0x80]
000079bd661d5da8  vmovaps [rsp+0x80], xmm14
000079bd661d5db1  movaps xmm1, xmm15
000079bd661d5db5  mulpd xmm1, xmm9
000079bd661d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000079bd661d5dbf  ptest xmm14, xmm14
000079bd661d5dc5  jnz 0x000079BD661D7ABF
000079bd661d5dcb  lea r14, [rax+0x90]
000079bd661d5dd2  movups xmm15, [r13+r14*1]
000079bd661d5dd8  vmovaps xmm14, [rsp+0xD0]
000079bd661d5de1  vmovaps xmm9, [rsp+0xD0]
000079bd661d5dea  por xmm14, xmm9
000079bd661d5def  movaps [r15+0x1C0], xmm14
000079bd661d5df7  vmovaps xmm9, [rsp+0xC0]
000079bd661d5e00  vmovaps [rsp+0xD0], xmm1
000079bd661d5e09  vmovaps xmm1, [rsp+0xC0]
000079bd661d5e12  por xmm9, xmm1
000079bd661d5e17  movaps [r15+0x200], xmm9
000079bd661d5e1f  vmovaps [rsp+0xC0], xmm2
000079bd661d5e28  vmovaps xmm1, [rsp+0xC0]
000079bd661d5e31  por xmm2, xmm1
000079bd661d5e35  movaps [r15+0x2D0], xmm2
000079bd661d5e3d  vmovaps [rsp+0xC0], xmm8
000079bd661d5e46  vmovaps xmm1, [rsp+0xC0]
000079bd661d5e4f  por xmm8, xmm1
000079bd661d5e54  movaps [r15+0x2E0], xmm8
000079bd661d5e5c  vmovaps [rsp+0xC0], xmm15
000079bd661d5e65  movaps xmm1, xmm5
000079bd661d5e68  addpd xmm1, xmm7
000079bd661d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000079bd661d5e71  ptest xmm15, xmm15
000079bd661d5e77  jnz 0x000079BD661D7C0B
000079bd661d5e7d  vmovaps xmm15, [rsp+0x50]
000079bd661d5e83  vpermilpd xmm15, xmm15, 0x00
000079bd661d5e89  vmovaps xmm5, [rsp+0xC0]
000079bd661d5e92  vmovaps [rsp+0xC0], xmm1
000079bd661d5e9b  movaps xmm7, xmm5
000079bd661d5e9e  mulpd xmm7, xmm15
000079bd661d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000079bd661d5ea8  ptest xmm1, xmm1
000079bd661d5ead  jnz 0x000079BD661D7D4B
000079bd661d5eb3  lea r14, [rax+0x80]
000079bd661d5eba  movups xmm1, [r13+r14*1]
000079bd661d5ec0  vmovaps xmm5, [rsp+0x70]
000079bd661d5ec6  vmovaps [rsp+0x70], xmm1
000079bd661d5ecc  movaps xmm15, xmm5
000079bd661d5ed0  addpd xmm15, xmm3
000079bd661d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000079bd661d5edb  ptest xmm1, xmm1
000079bd661d5ee0  jnz 0x000079BD661D7E96
000079bd661d5ee6  vmovaps xmm5, [rsp+0x80]
000079bd661d5eef  movaps xmm1, xmm5
000079bd661d5ef2  addpd xmm1, xmm4
000079bd661d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000079bd661d5efb  ptest xmm3, xmm3
000079bd661d5f00  jnz 0x000079BD661D7FD8
000079bd661d5f06  vmovaps [rsp+0x80], xmm10
000079bd661d5f0f  vmovaps xmm5, [rsp+0x80]
000079bd661d5f18  por xmm10, xmm5
000079bd661d5f1d  movaps [r15+0x2F0], xmm10
000079bd661d5f25  vmovaps xmm5, [rsp+0x50]
000079bd661d5f2b  vpermilpd xmm5, xmm5, 0x00
000079bd661d5f31  vmovaps xmm3, [rsp+0x70]
000079bd661d5f37  vmovaps [rsp+0x50], xmm1
000079bd661d5f3d  movaps xmm4, xmm3
000079bd661d5f40  mulpd xmm4, xmm5
000079bd661d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000079bd661d5f49  ptest xmm1, xmm1
000079bd661d5f4e  jnz 0x000079BD661D8118
000079bd661d5f54  lea r14, [rax+0xD0]
000079bd661d5f5b  movups xmm1, [r13+r14*1]
000079bd661d5f61  vmovaps xmm3, [rsp+0xD0]
000079bd661d5f6a  vmovaps [rsp+0x70], xmm1
000079bd661d5f70  movaps xmm5, xmm6
000079bd661d5f73  addpd xmm5, xmm3
000079bd661d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000079bd661d5f7c  ptest xmm1, xmm1
000079bd661d5f81  jnz 0x000079BD661D8262
000079bd661d5f87  vmovaps xmm1, [rsp+0x60]
000079bd661d5f8d  vpermilpd xmm1, xmm1, 0x00
000079bd661d5f93  movaps xmm6, xmm9
000079bd661d5f97  mulpd xmm6, xmm1
000079bd661d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000079bd661d5fa0  ptest xmm3, xmm3
000079bd661d5fa5  jnz 0x000079BD661D83A2
000079bd661d5fab  movaps [r15+0x260], xmm6
000079bd661d5fb3  vxorps xmm1, xmm1, xmm1
000079bd661d5fb7  vpbroadcastq xmm1, xmm1
000079bd661d5fbc  movaps [r15+0x1B0], xmm1
000079bd661d5fc4  vmovaps xmm1, [rsp+0x60]
000079bd661d5fca  vpermilpd xmm1, xmm1, 0x00
000079bd661d5fd0  vmovaps xmm3, [rsp+0x70]
000079bd661d5fd6  vmovaps [rsp+0x70], xmm15
000079bd661d5fdc  movaps xmm9, xmm3
000079bd661d5fe0  mulpd xmm9, xmm1
000079bd661d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000079bd661d5feb  ptest xmm15, xmm15
000079bd661d5ff1  jnz 0x000079BD661D84E3
000079bd661d5ff7  lea r14, [rax+0xC0]
000079bd661d5ffe  movups xmm1, [r13+r14*1]
000079bd661d6004  vmovaps xmm3, [rsp+0xC0]
000079bd661d600d  vmovaps [rsp+0x80], xmm1
000079bd661d6016  movaps xmm15, xmm3
000079bd661d601a  addpd xmm15, xmm7
000079bd661d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000079bd661d6025  ptest xmm1, xmm1
000079bd661d602a  jnz 0x000079BD661D862F
000079bd661d6030  vmovaps [rsp+0xC0], xmm13
000079bd661d6039  vmovaps xmm1, [rsp+0xC0]
000079bd661d6042  por xmm13, xmm1
000079bd661d6047  movaps [r15+0x270], xmm13
000079bd661d604f  vmovaps xmm1, [rsp+0xB0]
000079bd661d6058  vmovaps xmm7, [rsp+0xB0]
000079bd661d6061  por xmm1, xmm7
000079bd661d6065  movaps [r15+0x1A0], xmm1
000079bd661d606d  vmovaps xmm1, [rsp+0x60]
000079bd661d6073  vpermilpd xmm1, xmm1, 0x00
000079bd661d6079  vmovaps [rsp+0xB0], xmm1
000079bd661d6082  vmovaps xmm1, [rsp+0x80]
000079bd661d608b  vmovaps [rsp+0x80], xmm15
000079bd661d6094  vmovaps xmm15, [rsp+0xB0]
000079bd661d609d  vmovaps [rsp+0xB0], xmm14
000079bd661d60a6  movaps xmm3, xmm1
000079bd661d60a9  mulpd xmm3, xmm15
000079bd661d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000079bd661d60b3  ptest xmm14, xmm14
000079bd661d60b9  jnz 0x000079BD661D8771
000079bd661d60bf  lea r14, [rax+0x20]
000079bd661d60c3  movups xmm1, [r13+r14*1]
000079bd661d60c9  movaps [r15+0x110], xmm1
000079bd661d60d1  vmovaps xmm14, [rsp+0x70]
000079bd661d60d7  vmovaps [rsp+0x70], xmm1
000079bd661d60dd  movaps xmm15, xmm14
000079bd661d60e1  addpd xmm15, xmm4
000079bd661d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000079bd661d60ec  ptest xmm1, xmm1
000079bd661d60f1  jnz 0x000079BD661D88BC
000079bd661d60f7  vmovaps xmm1, [rsp+0x60]
000079bd661d60fd  vpermilpd xmm1, xmm1, 0x00
000079bd661d6103  movaps xmm14, xmm2
000079bd661d6107  mulpd xmm14, xmm1
000079bd661d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000079bd661d6112  ptest xmm4, xmm4
000079bd661d6117  jnz 0x000079BD661D89FF
000079bd661d611d  vmovaps xmm4, [rsp+0x50]
000079bd661d6123  movaps xmm1, xmm4
000079bd661d6126  addpd xmm1, xmm9
000079bd661d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000079bd661d6130  ptest xmm2, xmm2
000079bd661d6135  jnz 0x000079BD661D8B41
000079bd661d613b  vmovaps xmm9, [rsp+0x30]
000079bd661d6141  vpermilpd xmm9, xmm9, 0x00
000079bd661d6147  vmovaps xmm2, [rsp+0x70]
000079bd661d614d  vmovaps [rsp+0x50], xmm1
000079bd661d6153  movaps xmm4, xmm2
000079bd661d6156  mulpd xmm4, xmm9
000079bd661d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000079bd661d6160  ptest xmm1, xmm1
000079bd661d6165  jnz 0x000079BD661D8C82
000079bd661d616b  vmovaps xmm1, [rsp+0x30]
000079bd661d6171  vpermilpd xmm1, xmm1, 0x00
000079bd661d6177  vmovaps xmm2, [rsp+0x90]
000079bd661d6180  vmovaps [rsp+0x60], xmm15
000079bd661d6186  movaps xmm9, xmm2
000079bd661d618a  mulpd xmm9, xmm1
000079bd661d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000079bd661d6195  ptest xmm15, xmm15
000079bd661d619b  jnz 0x000079BD661D8DC3
000079bd661d61a1  vmovaps xmm15, [rsp+0x80]
000079bd661d61aa  movaps xmm1, xmm15
000079bd661d61ae  addpd xmm1, xmm6
000079bd661d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000079bd661d61b7  ptest xmm2, xmm2
000079bd661d61bc  jnz 0x000079BD661D8F05
000079bd661d61c2  movaps xmm15, xmm5
000079bd661d61c6  addpd xmm15, xmm3
000079bd661d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000079bd661d61d1  ptest xmm6, xmm6
000079bd661d61d6  jnz 0x000079BD661D9046
000079bd661d61dc  vmovaps xmm6, [rsp+0x30]
000079bd661d61e2  vpermilpd xmm6, xmm6, 0x00
000079bd661d61e8  movaps xmm5, xmm8
000079bd661d61ec  mulpd xmm5, xmm6
000079bd661d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000079bd661d61f5  ptest xmm3, xmm3
000079bd661d61fa  jnz 0x000079BD661D9188
000079bd661d6200  vmovaps xmm8, [rsp+0x30]
000079bd661d6206  vpermilpd xmm8, xmm8, 0x00
000079bd661d620c  movaps xmm6, xmm10
000079bd661d6210  mulpd xmm6, xmm8
000079bd661d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000079bd661d621a  ptest xmm3, xmm3
000079bd661d621f  jnz 0x000079BD661D92C9
000079bd661d6225  vmovaps xmm8, [rsp+0x60]
000079bd661d622b  movaps xmm10, xmm8
000079bd661d622f  addpd xmm10, xmm14
000079bd661d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000079bd661d623a  ptest xmm3, xmm3
000079bd661d623f  jnz 0x000079BD661D940B
000079bd661d6245  vmovaps xmm8, [rsp+0x50]
000079bd661d624b  movaps xmm14, xmm8
000079bd661d624f  addpd xmm14, xmm4
000079bd661d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000079bd661d625a  ptest xmm3, xmm3
000079bd661d625f  jnz 0x000079BD661D954F
000079bd661d6265  vmovaps xmm8, [rsp+0x40]
000079bd661d626b  vpermilpd xmm8, xmm8, 0x00
000079bd661d6271  movaps xmm4, xmm13
000079bd661d6275  mulpd xmm4, xmm8
000079bd661d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000079bd661d627f  ptest xmm3, xmm3
000079bd661d6284  jnz 0x000079BD661D9692
000079bd661d628a  movaps xmm13, xmm15
000079bd661d628e  addpd xmm13, xmm9
000079bd661d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000079bd661d6299  ptest xmm8, xmm8
000079bd661d629f  jnz 0x000079BD661D97D4
000079bd661d62a5  movaps xmm15, xmm1
000079bd661d62a9  addpd xmm15, xmm5
000079bd661d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000079bd661d62b4  ptest xmm9, xmm9
000079bd661d62ba  jnz 0x000079BD661D9918
000079bd661d62c0  vmovaps [rsp+0x30], xmm11
000079bd661d62c6  vmovaps xmm1, [rsp+0x30]
000079bd661d62cc  por xmm11, xmm1
000079bd661d62d1  movaps [r15+0x250], xmm11
000079bd661d62d9  vmovaps [rsp+0x30], xmm12
000079bd661d62df  vmovaps xmm1, [rsp+0x30]
000079bd661d62e5  por xmm12, xmm1
000079bd661d62ea  movaps [r15+0x2A0], xmm12
000079bd661d62f2  vmovaps xmm1, [rsp+0xA0]
000079bd661d62fb  vmovaps xmm11, [rsp+0xA0]
000079bd661d6304  por xmm1, xmm11
000079bd661d6309  movaps [r15+0x1D0], xmm1
000079bd661d6311  lea r14, [rax+0x40]
000079bd661d6315  movups xmm1, [r13+r14*1]
000079bd661d631b  movaps [r15+0x2C0], xmm1
000079bd661d6323  vmovaps xmm11, [rsp+0x40]
000079bd661d6329  vpermilpd xmm11, xmm11, 0x00
000079bd661d632f  vmovaps xmm8, [rsp+0xE0]
000079bd661d6338  movaps xmm9, xmm8
000079bd661d633c  mulpd xmm9, xmm11
000079bd661d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000079bd661d6347  ptest xmm5, xmm5
000079bd661d634c  jnz 0x000079BD661D9A64
000079bd661d6352  movaps xmm11, xmm10
000079bd661d6356  addpd xmm11, xmm6
000079bd661d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000079bd661d6361  ptest xmm8, xmm8
000079bd661d6367  jnz 0x000079BD661D9BA8
000079bd661d636d  movaps xmm10, xmm14
000079bd661d6371  addpd xmm10, xmm4
000079bd661d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000079bd661d637c  ptest xmm8, xmm8
000079bd661d6382  jnz 0x000079BD661D9CEB
000079bd661d6388  vmovaps xmm14, [rsp+0x40]
000079bd661d638e  vpermilpd xmm14, xmm14, 0x00
000079bd661d6394  movaps xmm8, xmm1
000079bd661d6398  mulpd xmm8, xmm14
000079bd661d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000079bd661d63a3  ptest xmm6, xmm6
000079bd661d63a8  jnz 0x000079BD661D9E2E
000079bd661d63ae  movaps xmm1, [r15+0x2B0]
000079bd661d63b6  vmovaps xmm14, [rsp+0x40]
000079bd661d63bc  vpermilpd xmm14, xmm14, 0x00
000079bd661d63c2  movaps xmm6, xmm1
000079bd661d63c5  mulpd xmm6, xmm14
000079bd661d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000079bd661d63cf  ptest xmm5, xmm5
000079bd661d63d4  jnz 0x000079BD661D9F71
000079bd661d63da  vmovaps xmm1, [rsp+0x10]
000079bd661d63e0  vpermilpd xmm1, xmm1, 0x00
000079bd661d63e6  movaps xmm14, xmm12
000079bd661d63ea  mulpd xmm14, xmm1
000079bd661d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000079bd661d63f5  ptest xmm5, xmm5
000079bd661d63fa  jnz 0x000079BD661DA0B2
000079bd661d6400  movaps xmm1, xmm13
000079bd661d6404  addpd xmm1, xmm9
000079bd661d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000079bd661d640e  ptest xmm12, xmm12
000079bd661d6414  jnz 0x000079BD661DA1F5
000079bd661d641a  vmovaps xmm13, [rsp+0x10]
000079bd661d6420  vpermilpd xmm13, xmm13, 0x00
000079bd661d6426  movaps xmm12, xmm7
000079bd661d642a  mulpd xmm12, xmm13
000079bd661d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000079bd661d6435  ptest xmm9, xmm9
000079bd661d643b  jnz 0x000079BD661DA337
000079bd661d6441  movaps xmm13, xmm15
000079bd661d6445  addpd xmm13, xmm8
000079bd661d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000079bd661d6450  ptest xmm9, xmm9
000079bd661d6456  jnz 0x000079BD661DA47A
000079bd661d645c  movaps xmm15, [r15+0x290]
000079bd661d6464  vmovaps xmm9, [rsp+0x10]
000079bd661d646a  vpermilpd xmm9, xmm9, 0x00
000079bd661d6470  movaps xmm8, xmm15
000079bd661d6474  mulpd xmm8, xmm9
000079bd661d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000079bd661d647f  ptest xmm7, xmm7
000079bd661d6484  jnz 0x000079BD661DA5BE
000079bd661d648a  movaps xmm15, xmm11
000079bd661d648e  addpd xmm15, xmm6
000079bd661d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000079bd661d6499  ptest xmm9, xmm9
000079bd661d649f  jnz 0x000079BD661DA702
000079bd661d64a5  movaps xmm11, [r15+0x1E0]
000079bd661d64ad  vmovaps xmm9, [rsp+0x10]
000079bd661d64b3  vpermilpd xmm9, xmm9, 0x00
000079bd661d64b9  movaps xmm7, xmm11
000079bd661d64bd  mulpd xmm7, xmm9
000079bd661d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000079bd661d64c7  ptest xmm6, xmm6
000079bd661d64cc  jnz 0x000079BD661DA845
000079bd661d64d2  movaps xmm11, xmm10
000079bd661d64d6  addpd xmm11, xmm14
000079bd661d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000079bd661d64e1  ptest xmm9, xmm9
000079bd661d64e7  jnz 0x000079BD661DA987
000079bd661d64ed  lea r14, [rax+0x70]
000079bd661d64f1  movups xmm14, [r13+r14*1]
000079bd661d64f7  movaps [r15+0x240], xmm14
000079bd661d64ff  movaps xmm10, xmm1
000079bd661d6503  addpd xmm10, xmm12
000079bd661d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000079bd661d650e  ptest xmm9, xmm9
000079bd661d6514  jnz 0x000079BD661DAAD5
000079bd661d651a  movaps [r15+0x170], xmm10
000079bd661d6522  vmovaps xmm1, [rsp+0x20]
000079bd661d6528  vpermilpd xmm1, xmm1, 0x00
000079bd661d652e  movaps xmm12, xmm14
000079bd661d6532  mulpd xmm12, xmm1
000079bd661d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000079bd661d653d  ptest xmm9, xmm9
000079bd661d6543  jnz 0x000079BD661DAC18
000079bd661d6549  vmovaps xmm1, [rsp+0x20]
000079bd661d654f  vpermilpd xmm1, xmm1, 0x00
000079bd661d6555  vmovaps xmm9, [rsp+0xB0]
000079bd661d655e  movaps xmm14, xmm9
000079bd661d6562  mulpd xmm14, xmm1
000079bd661d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000079bd661d656d  ptest xmm6, xmm6
000079bd661d6572  jnz 0x000079BD661DAD5B
000079bd661d6578  movaps [r15+0x180], xmm14
000079bd661d6580  movaps xmm1, xmm13
000079bd661d6584  addpd xmm1, xmm8
000079bd661d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000079bd661d658e  ptest xmm9, xmm9
000079bd661d6594  jnz 0x000079BD661DAE9E
000079bd661d659a  movaps [r15+0x210], xmm1
000079bd661d65a2  movups xmm13, [r13+rax*1]
000079bd661d65a8  lea r14, [rax+0x10]
000079bd661d65ac  movups xmm9, [r13+r14*1]
000079bd661d65b2  movaps [r15+0x230], xmm9
000079bd661d65ba  movaps xmm8, xmm15
000079bd661d65be  addpd xmm8, xmm7
000079bd661d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000079bd661d65c9  ptest xmm6, xmm6
000079bd661d65ce  jnz 0x000079BD661DAFF4
000079bd661d65d4  movaps [r15+0x130], xmm8
000079bd661d65dc  vmovaps xmm15, [rsp+0x20]
000079bd661d65e2  vpermilpd xmm15, xmm15, 0x00
000079bd661d65e8  movaps xmm7, xmm9
000079bd661d65ec  mulpd xmm7, xmm15
000079bd661d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000079bd661d65f6  ptest xmm6, xmm6
000079bd661d65fb  jnz 0x000079BD661DB137
000079bd661d6601  movaps [r15+0x220], xmm7
000079bd661d6609  vmovaps xmm15, [rsp+0x20]
000079bd661d660f  vpermilpd xmm15, xmm15, 0x00
000079bd661d6615  movaps xmm9, xmm13
000079bd661d6619  mulpd xmm9, xmm15
000079bd661d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000079bd661d6624  ptest xmm6, xmm6
000079bd661d6629  jnz 0x000079BD661DB279
000079bd661d662f  movaps xmm15, xmm11
000079bd661d6633  addpd xmm15, xmm12
000079bd661d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000079bd661d663e  ptest xmm13, xmm13
000079bd661d6644  jnz 0x000079BD661DB3BD
000079bd661d664a  movaps [r15+0x140], xmm15
000079bd661d6652  movaps xmm13, xmm10
000079bd661d6656  addpd xmm13, xmm14
000079bd661d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000079bd661d6661  ptest xmm12, xmm12
000079bd661d6667  jnz 0x000079BD661DB501
000079bd661d666d  movaps [r15+0x150], xmm13
000079bd661d6675  movaps xmm14, xmm1
000079bd661d6679  addpd xmm14, xmm7
000079bd661d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000079bd661d6684  ptest xmm12, xmm12
000079bd661d668a  jnz 0x000079BD661DB645
000079bd661d6690  movaps [r15+0x160], xmm14
000079bd661d6698  movaps xmm1, xmm8
000079bd661d669c  addpd xmm1, xmm9
000079bd661d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000079bd661d66a6  ptest xmm12, xmm12
000079bd661d66ac  jnz 0x000079BD661DB787
000079bd661d66b2  movaps [r15+0x120], xmm1
000079bd661d66ba  movups [r13+r11*1], xmm15
000079bd661d66c0  lea rax, [r11+0x10]
000079bd661d66c4  movups [r13+rax*1], xmm13
000079bd661d66ca  lea rax, [r11+0x20]
000079bd661d66ce  movups [r13+rax*1], xmm14
000079bd661d66d4  lea rax, [r11+0x30]
000079bd661d66d8  movups [r13+rax*1], xmm1
000079bd661d66de  mov eax, [r15+0x108]
000079bd661d66e5  sahf
000079bd661d66e6  jnz 0x000079BD661D6718
000079bd661d66e8  cmp dword ptr [r15+0x318], 0x00
000079bd661d66f0  jz 0x000079BD661DB900
000079bd661d66f6  nop [rax+rax*1], ax
000079bd661d66ff  nop [rax+rax*1], eax
000079bd661d6707  mov eax, 0x410444
000079bd661d670c  mov [r15+0x100], rax
000079bd661d6713  jmp 0x000079BD65FFE110
000079bd661d6718  cmp dword ptr [r15+0x318], 0x00
000079bd661d6720  jz 0x000079BD661D57E0
000079bd661d6726  nop [rax+rax*1], ax
000079bd661d672f  nop [rax+rax*1], eax
000079bd661d6737  mov eax, 0x410278
000079bd661d673c  mov [r15+0x100], rax
000079bd661d6743  jmp 0x000079BD65FFE110
000079bd661d6748  int3
000079bd661d6749  call 0x000079BD6600A4B0
000079bd661d674e  jmp 0x000079BD661D5828
000079bd661d6753  call 0x000079BD66009240
000079bd661d6758  jmp 0x000079BD661D5832
000079bd661d675d  call 0x000079BD6600A4B0
000079bd661d6762  jmp 0x000079BD661D588F
000079bd661d6767  call 0x000079BD66009240
000079bd661d676c  jmp 0x000079BD661D5899
000079bd661d6771  call 0x000079BD6600A4B0
000079bd661d6776  jmp 0x000079BD661D58DD
000079bd661d677b  call 0x000079BD66009240
000079bd661d6780  jmp 0x000079BD661D58E7
000079bd661d6785  call 0x000079BD660B47C0
000079bd661d678a  jmp 0x000079BD661D5926
000079bd661d678f  call 0x000079BD6600B720
000079bd661d6794  jmp 0x000079BD661D593A
000079bd661d6799  call 0x000079BD660BFC30
000079bd661d679e  jmp 0x000079BD661D5958
000079bd661d67a3  call 0x000079BD660BE9C0
000079bd661d67a8  jmp 0x000079BD661D5962
000079bd661d67ad  call 0x000079BD660BD750
000079bd661d67b2  jmp 0x000079BD661D596C
000079bd661d67b7  sub rsp, 0x08
000079bd661d67bb  push rax
000079bd661d67bc  push rcx
000079bd661d67bd  push rdx
000079bd661d67be  push rdi
000079bd661d67bf  push rsi
000079bd661d67c0  push r8
000079bd661d67c2  push r9
000079bd661d67c4  push r10
000079bd661d67c6  push r11
000079bd661d67c8  sub rsp, 0xF0
000079bd661d67cf  vmovaps [rsp], xmm0
000079bd661d67d4  vmovaps [rsp+0x10], xmm1
000079bd661d67da  vmovaps [rsp+0x20], xmm2
000079bd661d67e0  vmovaps [rsp+0x30], xmm3
000079bd661d67e6  vmovaps [rsp+0x40], xmm4
000079bd661d67ec  vmovaps [rsp+0x50], xmm5
000079bd661d67f2  vmovaps [rsp+0x60], xmm6
000079bd661d67f8  vmovaps [rsp+0x70], xmm7
000079bd661d67fe  vmovaps [rsp+0x80], xmm9
000079bd661d6807  vmovaps [rsp+0x90], xmm10
000079bd661d6810  vmovaps [rsp+0xA0], xmm11
000079bd661d6819  vmovaps [rsp+0xB0], xmm12
000079bd661d6822  vmovaps [rsp+0xC0], xmm13
000079bd661d682b  vmovaps [rsp+0xD0], xmm14
000079bd661d6834  vmovaps [rsp+0xE0], xmm15
000079bd661d683d  sub rsp, 0x30
000079bd661d6841  movaps [rsp], xmm8
000079bd661d6846  movaps [rsp+0x10], xmm12
000079bd661d684c  movaps [rsp+0x20], xmm15
000079bd661d6852  lea rdi, [rsp]
000079bd661d6856  mov esi, 0x00
000079bd661d685b  mov rax, 0x56EBD57B0530
000079bd661d6865  call rax
000079bd661d6867  movaps xmm8, [rsp]
000079bd661d686c  add rsp, 0x30
000079bd661d6870  vmovaps xmm0, [rsp]
000079bd661d6875  vmovaps xmm1, [rsp+0x10]
000079bd661d687b  vmovaps xmm2, [rsp+0x20]
000079bd661d6881  vmovaps xmm3, [rsp+0x30]
000079bd661d6887  vmovaps xmm4, [rsp+0x40]
000079bd661d688d  vmovaps xmm5, [rsp+0x50]
000079bd661d6893  vmovaps xmm6, [rsp+0x60]
000079bd661d6899  vmovaps xmm7, [rsp+0x70]
000079bd661d689f  vmovaps xmm9, [rsp+0x80]
000079bd661d68a8  vmovaps xmm10, [rsp+0x90]
000079bd661d68b1  vmovaps xmm11, [rsp+0xA0]
000079bd661d68ba  vmovaps xmm12, [rsp+0xB0]
000079bd661d68c3  vmovaps xmm13, [rsp+0xC0]
000079bd661d68cc  vmovaps xmm14, [rsp+0xD0]
000079bd661d68d5  vmovaps xmm15, [rsp+0xE0]
000079bd661d68de  add rsp, 0xF0
000079bd661d68e5  pop r11
000079bd661d68e7  pop r10
000079bd661d68e9  pop r9
000079bd661d68eb  pop r8
000079bd661d68ed  pop rsi
000079bd661d68ee  pop rdi
000079bd661d68ef  pop rdx
000079bd661d68f0  pop rcx
000079bd661d68f1  pop rax
000079bd661d68f2  add rsp, 0x08
000079bd661d68f6  jmp 0x000079BD661D599A
000079bd661d68fb  sub rsp, 0x08
000079bd661d68ff  push rax
000079bd661d6900  push rcx
000079bd661d6901  push rdx
000079bd661d6902  push rdi
000079bd661d6903  push rsi
000079bd661d6904  push r8
000079bd661d6906  push r9
000079bd661d6908  push r10
000079bd661d690a  push r11
000079bd661d690c  sub rsp, 0xF0
000079bd661d6913  vmovaps [rsp], xmm0
000079bd661d6918  vmovaps [rsp+0x10], xmm1
000079bd661d691e  vmovaps [rsp+0x20], xmm2
000079bd661d6924  vmovaps [rsp+0x30], xmm3
000079bd661d692a  vmovaps [rsp+0x40], xmm4
000079bd661d6930  vmovaps [rsp+0x50], xmm5
000079bd661d6936  vmovaps [rsp+0x60], xmm6
000079bd661d693c  vmovaps [rsp+0x70], xmm8
000079bd661d6942  vmovaps [rsp+0x80], xmm9
000079bd661d694b  vmovaps [rsp+0x90], xmm10
000079bd661d6954  vmovaps [rsp+0xA0], xmm11
000079bd661d695d  vmovaps [rsp+0xB0], xmm12
000079bd661d6966  vmovaps [rsp+0xC0], xmm13
000079bd661d696f  vmovaps [rsp+0xD0], xmm14
000079bd661d6978  vmovaps [rsp+0xE0], xmm15
000079bd661d6981  sub rsp, 0x30
000079bd661d6985  movaps [rsp], xmm7
000079bd661d6989  movaps [rsp+0x10], xmm9
000079bd661d698f  movaps [rsp+0x20], xmm15
000079bd661d6995  lea rdi, [rsp]
000079bd661d6999  mov esi, 0x00
000079bd661d699e  mov rax, 0x56EBD57B0530
000079bd661d69a8  call rax
000079bd661d69aa  movaps xmm7, [rsp]
000079bd661d69ae  add rsp, 0x30
000079bd661d69b2  vmovaps xmm0, [rsp]
000079bd661d69b7  vmovaps xmm1, [rsp+0x10]
000079bd661d69bd  vmovaps xmm2, [rsp+0x20]
000079bd661d69c3  vmovaps xmm3, [rsp+0x30]
000079bd661d69c9  vmovaps xmm4, [rsp+0x40]
000079bd661d69cf  vmovaps xmm5, [rsp+0x50]
000079bd661d69d5  vmovaps xmm6, [rsp+0x60]
000079bd661d69db  vmovaps xmm8, [rsp+0x70]
000079bd661d69e1  vmovaps xmm9, [rsp+0x80]
000079bd661d69ea  vmovaps xmm10, [rsp+0x90]
000079bd661d69f3  vmovaps xmm11, [rsp+0xA0]
000079bd661d69fc  vmovaps xmm12, [rsp+0xB0]
000079bd661d6a05  vmovaps xmm13, [rsp+0xC0]
000079bd661d6a0e  vmovaps xmm14, [rsp+0xD0]
000079bd661d6a17  vmovaps xmm15, [rsp+0xE0]
000079bd661d6a20  add rsp, 0xF0
000079bd661d6a27  pop r11
000079bd661d6a29  pop r10
000079bd661d6a2b  pop r9
000079bd661d6a2d  pop r8
000079bd661d6a2f  pop rsi
000079bd661d6a30  pop rdi
000079bd661d6a31  pop rdx
000079bd661d6a32  pop rcx
000079bd661d6a33  pop rax
000079bd661d6a34  add rsp, 0x08
000079bd661d6a38  jmp 0x000079BD661D59C8
000079bd661d6a3d  sub rsp, 0x08
000079bd661d6a41  push rax
000079bd661d6a42  push rcx
000079bd661d6a43  push rdx
000079bd661d6a44  push rdi
000079bd661d6a45  push rsi
000079bd661d6a46  push r8
000079bd661d6a48  push r9
000079bd661d6a4a  push r10
000079bd661d6a4c  push r11
000079bd661d6a4e  sub rsp, 0xF0
000079bd661d6a55  vmovaps [rsp], xmm0
000079bd661d6a5a  vmovaps [rsp+0x10], xmm1
000079bd661d6a60  vmovaps [rsp+0x20], xmm2
000079bd661d6a66  vmovaps [rsp+0x30], xmm3
000079bd661d6a6c  vmovaps [rsp+0x40], xmm4
000079bd661d6a72  vmovaps [rsp+0x50], xmm5
000079bd661d6a78  vmovaps [rsp+0x60], xmm6
000079bd661d6a7e  vmovaps [rsp+0x70], xmm7
000079bd661d6a84  vmovaps [rsp+0x80], xmm8
000079bd661d6a8d  vmovaps [rsp+0x90], xmm10
000079bd661d6a96  vmovaps [rsp+0xA0], xmm11
000079bd661d6a9f  vmovaps [rsp+0xB0], xmm12
000079bd661d6aa8  vmovaps [rsp+0xC0], xmm13
000079bd661d6ab1  vmovaps [rsp+0xD0], xmm14
000079bd661d6aba  vmovaps [rsp+0xE0], xmm15
000079bd661d6ac3  sub rsp, 0x30
000079bd661d6ac7  movaps [rsp], xmm9
000079bd661d6acc  movaps [rsp+0x10], xmm12
000079bd661d6ad2  movaps [rsp+0x20], xmm10
000079bd661d6ad8  lea rdi, [rsp]
000079bd661d6adc  mov esi, 0x00
000079bd661d6ae1  mov rax, 0x56EBD57B0530
000079bd661d6aeb  call rax
000079bd661d6aed  movaps xmm9, [rsp]
000079bd661d6af2  add rsp, 0x30
000079bd661d6af6  vmovaps xmm0, [rsp]
000079bd661d6afb  vmovaps xmm1, [rsp+0x10]
000079bd661d6b01  vmovaps xmm2, [rsp+0x20]
000079bd661d6b07  vmovaps xmm3, [rsp+0x30]
000079bd661d6b0d  vmovaps xmm4, [rsp+0x40]
000079bd661d6b13  vmovaps xmm5, [rsp+0x50]
000079bd661d6b19  vmovaps xmm6, [rsp+0x60]
000079bd661d6b1f  vmovaps xmm7, [rsp+0x70]
000079bd661d6b25  vmovaps xmm8, [rsp+0x80]
000079bd661d6b2e  vmovaps xmm10, [rsp+0x90]
000079bd661d6b37  vmovaps xmm11, [rsp+0xA0]
000079bd661d6b40  vmovaps xmm12, [rsp+0xB0]
000079bd661d6b49  vmovaps xmm13, [rsp+0xC0]
000079bd661d6b52  vmovaps xmm14, [rsp+0xD0]
000079bd661d6b5b  vmovaps xmm15, [rsp+0xE0]
000079bd661d6b64  add rsp, 0xF0
000079bd661d6b6b  pop r11
000079bd661d6b6d  pop r10
000079bd661d6b6f  pop r9
000079bd661d6b71  pop r8
000079bd661d6b73  pop rsi
000079bd661d6b74  pop rdi
000079bd661d6b75  pop rdx
000079bd661d6b76  pop rcx
000079bd661d6b77  pop rax
000079bd661d6b78  add rsp, 0x08
000079bd661d6b7c  jmp 0x000079BD661D59EC
000079bd661d6b81  sub rsp, 0x08
000079bd661d6b85  push rax
000079bd661d6b86  push rcx
000079bd661d6b87  push rdx
000079bd661d6b88  push rdi
000079bd661d6b89  push rsi
000079bd661d6b8a  push r8
000079bd661d6b8c  push r9
000079bd661d6b8e  push r10
000079bd661d6b90  push r11
000079bd661d6b92  sub rsp, 0xF0
000079bd661d6b99  vmovaps [rsp], xmm0
000079bd661d6b9e  vmovaps [rsp+0x10], xmm1
000079bd661d6ba4  vmovaps [rsp+0x20], xmm2
000079bd661d6baa  vmovaps [rsp+0x30], xmm3
000079bd661d6bb0  vmovaps [rsp+0x40], xmm4
000079bd661d6bb6  vmovaps [rsp+0x50], xmm5
000079bd661d6bbc  vmovaps [rsp+0x60], xmm6
000079bd661d6bc2  vmovaps [rsp+0x70], xmm7
000079bd661d6bc8  vmovaps [rsp+0x80], xmm8
000079bd661d6bd1  vmovaps [rsp+0x90], xmm9
000079bd661d6bda  vmovaps [rsp+0xA0], xmm11
000079bd661d6be3  vmovaps [rsp+0xB0], xmm12
000079bd661d6bec  vmovaps [rsp+0xC0], xmm13
000079bd661d6bf5  vmovaps [rsp+0xD0], xmm14
000079bd661d6bfe  vmovaps [rsp+0xE0], xmm15
000079bd661d6c07  sub rsp, 0x30
000079bd661d6c0b  movaps [rsp], xmm10
000079bd661d6c10  movaps [rsp+0x10], xmm12
000079bd661d6c16  movaps [rsp+0x20], xmm11
000079bd661d6c1c  lea rdi, [rsp]
000079bd661d6c20  mov esi, 0x00
000079bd661d6c25  mov rax, 0x56EBD57B0530
000079bd661d6c2f  call rax
000079bd661d6c31  movaps xmm10, [rsp]
000079bd661d6c36  add rsp, 0x30
000079bd661d6c3a  vmovaps xmm0, [rsp]
000079bd661d6c3f  vmovaps xmm1, [rsp+0x10]
000079bd661d6c45  vmovaps xmm2, [rsp+0x20]
000079bd661d6c4b  vmovaps xmm3, [rsp+0x30]
000079bd661d6c51  vmovaps xmm4, [rsp+0x40]
000079bd661d6c57  vmovaps xmm5, [rsp+0x50]
000079bd661d6c5d  vmovaps xmm6, [rsp+0x60]
000079bd661d6c63  vmovaps xmm7, [rsp+0x70]
000079bd661d6c69  vmovaps xmm8, [rsp+0x80]
000079bd661d6c72  vmovaps xmm9, [rsp+0x90]
000079bd661d6c7b  vmovaps xmm11, [rsp+0xA0]
000079bd661d6c84  vmovaps xmm12, [rsp+0xB0]
000079bd661d6c8d  vmovaps xmm13, [rsp+0xC0]
000079bd661d6c96  vmovaps xmm14, [rsp+0xD0]
000079bd661d6c9f  vmovaps xmm15, [rsp+0xE0]
000079bd661d6ca8  add rsp, 0xF0
000079bd661d6caf  pop r11
000079bd661d6cb1  pop r10
000079bd661d6cb3  pop r9
000079bd661d6cb5  pop r8
000079bd661d6cb7  pop rsi
000079bd661d6cb8  pop rdi
000079bd661d6cb9  pop rdx
000079bd661d6cba  pop rcx
000079bd661d6cbb  pop rax
000079bd661d6cbc  add rsp, 0x08
000079bd661d6cc0  jmp 0x000079BD661D5A06
000079bd661d6cc5  sub rsp, 0x08
000079bd661d6cc9  push rax
000079bd661d6cca  push rcx
000079bd661d6ccb  push rdx
000079bd661d6ccc  push rdi
000079bd661d6ccd  push rsi
000079bd661d6cce  push r8
000079bd661d6cd0  push r9
000079bd661d6cd2  push r10
000079bd661d6cd4  push r11
000079bd661d6cd6  sub rsp, 0xF0
000079bd661d6cdd  vmovaps [rsp], xmm0
000079bd661d6ce2  vmovaps [rsp+0x10], xmm1
000079bd661d6ce8  vmovaps [rsp+0x20], xmm2
000079bd661d6cee  vmovaps [rsp+0x30], xmm3
000079bd661d6cf4  vmovaps [rsp+0x40], xmm4
000079bd661d6cfa  vmovaps [rsp+0x50], xmm5
000079bd661d6d00  vmovaps [rsp+0x60], xmm7
000079bd661d6d06  vmovaps [rsp+0x70], xmm8
000079bd661d6d0c  vmovaps [rsp+0x80], xmm9
000079bd661d6d15  vmovaps [rsp+0x90], xmm10
000079bd661d6d1e  vmovaps [rsp+0xA0], xmm11
000079bd661d6d27  vmovaps [rsp+0xB0], xmm12
000079bd661d6d30  vmovaps [rsp+0xC0], xmm13
000079bd661d6d39  vmovaps [rsp+0xD0], xmm14
000079bd661d6d42  vmovaps [rsp+0xE0], xmm15
000079bd661d6d4b  sub rsp, 0x30
000079bd661d6d4f  movaps [rsp], xmm6
000079bd661d6d53  movaps [rsp+0x10], xmm12
000079bd661d6d59  movaps [rsp+0x20], xmm11
000079bd661d6d5f  lea rdi, [rsp]
000079bd661d6d63  mov esi, 0x00
000079bd661d6d68  mov rax, 0x56EBD57B0530
000079bd661d6d72  call rax
000079bd661d6d74  movaps xmm6, [rsp]
000079bd661d6d78  add rsp, 0x30
000079bd661d6d7c  vmovaps xmm0, [rsp]
000079bd661d6d81  vmovaps xmm1, [rsp+0x10]
000079bd661d6d87  vmovaps xmm2, [rsp+0x20]
000079bd661d6d8d  vmovaps xmm3, [rsp+0x30]
000079bd661d6d93  vmovaps xmm4, [rsp+0x40]
000079bd661d6d99  vmovaps xmm5, [rsp+0x50]
000079bd661d6d9f  vmovaps xmm7, [rsp+0x60]
000079bd661d6da5  vmovaps xmm8, [rsp+0x70]
000079bd661d6dab  vmovaps xmm9, [rsp+0x80]
000079bd661d6db4  vmovaps xmm10, [rsp+0x90]
000079bd661d6dbd  vmovaps xmm11, [rsp+0xA0]
000079bd661d6dc6  vmovaps xmm12, [rsp+0xB0]
000079bd661d6dcf  vmovaps xmm13, [rsp+0xC0]
000079bd661d6dd8  vmovaps xmm14, [rsp+0xD0]
000079bd661d6de1  vmovaps xmm15, [rsp+0xE0]
000079bd661d6dea  add rsp, 0xF0
000079bd661d6df1  pop r11
000079bd661d6df3  pop r10
000079bd661d6df5  pop r9
000079bd661d6df7  pop r8
000079bd661d6df9  pop rsi
000079bd661d6dfa  pop rdi
000079bd661d6dfb  pop rdx
000079bd661d6dfc  pop rcx
000079bd661d6dfd  pop rax
000079bd661d6dfe  add rsp, 0x08
000079bd661d6e02  jmp 0x000079BD661D5A27
000079bd661d6e07  sub rsp, 0x08
000079bd661d6e0b  push rax
000079bd661d6e0c  push rcx
000079bd661d6e0d  push rdx
000079bd661d6e0e  push rdi
000079bd661d6e0f  push rsi
000079bd661d6e10  push r8
000079bd661d6e12  push r9
000079bd661d6e14  push r10
000079bd661d6e16  push r11
000079bd661d6e18  sub rsp, 0xF0
000079bd661d6e1f  vmovaps [rsp], xmm0
000079bd661d6e24  vmovaps [rsp+0x10], xmm1
000079bd661d6e2a  vmovaps [rsp+0x20], xmm2
000079bd661d6e30  vmovaps [rsp+0x30], xmm4
000079bd661d6e36  vmovaps [rsp+0x40], xmm5
000079bd661d6e3c  vmovaps [rsp+0x50], xmm6
000079bd661d6e42  vmovaps [rsp+0x60], xmm7
000079bd661d6e48  vmovaps [rsp+0x70], xmm8
000079bd661d6e4e  vmovaps [rsp+0x80], xmm9
000079bd661d6e57  vmovaps [rsp+0x90], xmm10
000079bd661d6e60  vmovaps [rsp+0xA0], xmm11
000079bd661d6e69  vmovaps [rsp+0xB0], xmm12
000079bd661d6e72  vmovaps [rsp+0xC0], xmm13
000079bd661d6e7b  vmovaps [rsp+0xD0], xmm14
000079bd661d6e84  vmovaps [rsp+0xE0], xmm15
000079bd661d6e8d  sub rsp, 0x30
000079bd661d6e91  movaps [rsp], xmm3
000079bd661d6e95  movaps [rsp+0x10], xmm5
000079bd661d6e9a  movaps [rsp+0x20], xmm4
000079bd661d6e9f  lea rdi, [rsp]
000079bd661d6ea3  mov esi, 0x00
000079bd661d6ea8  mov rax, 0x56EBD57B0530
000079bd661d6eb2  call rax
000079bd661d6eb4  movaps xmm3, [rsp]
000079bd661d6eb8  add rsp, 0x30
000079bd661d6ebc  vmovaps xmm0, [rsp]
000079bd661d6ec1  vmovaps xmm1, [rsp+0x10]
000079bd661d6ec7  vmovaps xmm2, [rsp+0x20]
000079bd661d6ecd  vmovaps xmm4, [rsp+0x30]
000079bd661d6ed3  vmovaps xmm5, [rsp+0x40]
000079bd661d6ed9  vmovaps xmm6, [rsp+0x50]
000079bd661d6edf  vmovaps xmm7, [rsp+0x60]
000079bd661d6ee5  vmovaps xmm8, [rsp+0x70]
000079bd661d6eeb  vmovaps xmm9, [rsp+0x80]
000079bd661d6ef4  vmovaps xmm10, [rsp+0x90]
000079bd661d6efd  vmovaps xmm11, [rsp+0xA0]
000079bd661d6f06  vmovaps xmm12, [rsp+0xB0]
000079bd661d6f0f  vmovaps xmm13, [rsp+0xC0]
000079bd661d6f18  vmovaps xmm14, [rsp+0xD0]
000079bd661d6f21  vmovaps xmm15, [rsp+0xE0]
000079bd661d6f2a  add rsp, 0xF0
000079bd661d6f31  pop r11
000079bd661d6f33  pop r10
000079bd661d6f35  pop r9
000079bd661d6f37  pop r8
000079bd661d6f39  pop rsi
000079bd661d6f3a  pop rdi
000079bd661d6f3b  pop rdx
000079bd661d6f3c  pop rcx
000079bd661d6f3d  pop rax
000079bd661d6f3e  add rsp, 0x08
000079bd661d6f42  jmp 0x000079BD661D5A88
000079bd661d6f47  sub rsp, 0x08
000079bd661d6f4b  push rax
000079bd661d6f4c  push rcx
000079bd661d6f4d  push rdx
000079bd661d6f4e  push rdi
000079bd661d6f4f  push rsi
000079bd661d6f50  push r8
000079bd661d6f52  push r9
000079bd661d6f54  push r10
000079bd661d6f56  push r11
000079bd661d6f58  sub rsp, 0xF0
000079bd661d6f5f  vmovaps [rsp], xmm0
000079bd661d6f64  vmovaps [rsp+0x10], xmm1
000079bd661d6f6a  vmovaps [rsp+0x20], xmm2
000079bd661d6f70  vmovaps [rsp+0x30], xmm3
000079bd661d6f76  vmovaps [rsp+0x40], xmm4
000079bd661d6f7c  vmovaps [rsp+0x50], xmm6
000079bd661d6f82  vmovaps [rsp+0x60], xmm7
000079bd661d6f88  vmovaps [rsp+0x70], xmm8
000079bd661d6f8e  vmovaps [rsp+0x80], xmm9
000079bd661d6f97  vmovaps [rsp+0x90], xmm10
000079bd661d6fa0  vmovaps [rsp+0xA0], xmm11
000079bd661d6fa9  vmovaps [rsp+0xB0], xmm12
000079bd661d6fb2  vmovaps [rsp+0xC0], xmm13
000079bd661d6fbb  vmovaps [rsp+0xD0], xmm14
000079bd661d6fc4  vmovaps [rsp+0xE0], xmm15
000079bd661d6fcd  sub rsp, 0x30
000079bd661d6fd1  movaps [rsp], xmm5
000079bd661d6fd5  movaps [rsp+0x10], xmm8
000079bd661d6fdb  movaps [rsp+0x20], xmm15
000079bd661d6fe1  lea rdi, [rsp]
000079bd661d6fe5  mov esi, 0x00
000079bd661d6fea  mov rax, 0x56EBD57B0530
000079bd661d6ff4  call rax
000079bd661d6ff6  movaps xmm5, [rsp]
000079bd661d6ffa  add rsp, 0x30
000079bd661d6ffe  vmovaps xmm0, [rsp]
000079bd661d7003  vmovaps xmm1, [rsp+0x10]
000079bd661d7009  vmovaps xmm2, [rsp+0x20]
000079bd661d700f  vmovaps xmm3, [rsp+0x30]
000079bd661d7015  vmovaps xmm4, [rsp+0x40]
000079bd661d701b  vmovaps xmm6, [rsp+0x50]
000079bd661d7021  vmovaps xmm7, [rsp+0x60]
000079bd661d7027  vmovaps xmm8, [rsp+0x70]
000079bd661d702d  vmovaps xmm9, [rsp+0x80]
000079bd661d7036  vmovaps xmm10, [rsp+0x90]
000079bd661d703f  vmovaps xmm11, [rsp+0xA0]
000079bd661d7048  vmovaps xmm12, [rsp+0xB0]
000079bd661d7051  vmovaps xmm13, [rsp+0xC0]
000079bd661d705a  vmovaps xmm14, [rsp+0xD0]
000079bd661d7063  vmovaps xmm15, [rsp+0xE0]
000079bd661d706c  add rsp, 0xF0
000079bd661d7073  pop r11
000079bd661d7075  pop r10
000079bd661d7077  pop r9
000079bd661d7079  pop r8
000079bd661d707b  pop rsi
000079bd661d707c  pop rdi
000079bd661d707d  pop rdx
000079bd661d707e  pop rcx
000079bd661d707f  pop rax
000079bd661d7080  add rsp, 0x08
000079bd661d7084  jmp 0x000079BD661D5AC0
000079bd661d7089  sub rsp, 0x08
000079bd661d708d  push rax
000079bd661d708e  push rcx
000079bd661d708f  push rdx
000079bd661d7090  push rdi
000079bd661d7091  push rsi
000079bd661d7092  push r8
000079bd661d7094  push r9
000079bd661d7096  push r10
000079bd661d7098  push r11
000079bd661d709a  sub rsp, 0xF0
000079bd661d70a1  vmovaps [rsp], xmm0
000079bd661d70a6  vmovaps [rsp+0x10], xmm1
000079bd661d70ac  vmovaps [rsp+0x20], xmm2
000079bd661d70b2  vmovaps [rsp+0x30], xmm3
000079bd661d70b8  vmovaps [rsp+0x40], xmm5
000079bd661d70be  vmovaps [rsp+0x50], xmm6
000079bd661d70c4  vmovaps [rsp+0x60], xmm7
000079bd661d70ca  vmovaps [rsp+0x70], xmm8
000079bd661d70d0  vmovaps [rsp+0x80], xmm9
000079bd661d70d9  vmovaps [rsp+0x90], xmm10
000079bd661d70e2  vmovaps [rsp+0xA0], xmm11
000079bd661d70eb  vmovaps [rsp+0xB0], xmm12
000079bd661d70f4  vmovaps [rsp+0xC0], xmm13
000079bd661d70fd  vmovaps [rsp+0xD0], xmm14
000079bd661d7106  vmovaps [rsp+0xE0], xmm15
000079bd661d710f  sub rsp, 0x30
000079bd661d7113  movaps [rsp], xmm4
000079bd661d7117  movaps [rsp+0x10], xmm9
000079bd661d711d  movaps [rsp+0x20], xmm8
000079bd661d7123  lea rdi, [rsp]
000079bd661d7127  mov esi, 0x00
000079bd661d712c  mov rax, 0x56EBD57B0530
000079bd661d7136  call rax
000079bd661d7138  movaps xmm4, [rsp]
000079bd661d713c  add rsp, 0x30
000079bd661d7140  vmovaps xmm0, [rsp]
000079bd661d7145  vmovaps xmm1, [rsp+0x10]
000079bd661d714b  vmovaps xmm2, [rsp+0x20]
000079bd661d7151  vmovaps xmm3, [rsp+0x30]
000079bd661d7157  vmovaps xmm5, [rsp+0x40]
000079bd661d715d  vmovaps xmm6, [rsp+0x50]
000079bd661d7163  vmovaps xmm7, [rsp+0x60]
000079bd661d7169  vmovaps xmm8, [rsp+0x70]
000079bd661d716f  vmovaps xmm9, [rsp+0x80]
000079bd661d7178  vmovaps xmm10, [rsp+0x90]
000079bd661d7181  vmovaps xmm11, [rsp+0xA0]
000079bd661d718a  vmovaps xmm12, [rsp+0xB0]
000079bd661d7193  vmovaps xmm13, [rsp+0xC0]
000079bd661d719c  vmovaps xmm14, [rsp+0xD0]
000079bd661d71a5  vmovaps xmm15, [rsp+0xE0]
000079bd661d71ae  add rsp, 0xF0
000079bd661d71b5  pop r11
000079bd661d71b7  pop r10
000079bd661d71b9  pop r9
000079bd661d71bb  pop r8
000079bd661d71bd  pop rsi
000079bd661d71be  pop rdi
000079bd661d71bf  pop rdx
000079bd661d71c0  pop rcx
000079bd661d71c1  pop rax
000079bd661d71c2  add rsp, 0x08
000079bd661d71c6  jmp 0x000079BD661D5AE1
000079bd661d71cb  sub rsp, 0x08
000079bd661d71cf  push rax
000079bd661d71d0  push rcx
000079bd661d71d1  push rdx
000079bd661d71d2  push rdi
000079bd661d71d3  push rsi
000079bd661d71d4  push r8
000079bd661d71d6  push r9
000079bd661d71d8  push r10
000079bd661d71da  push r11
000079bd661d71dc  sub rsp, 0xF0
000079bd661d71e3  vmovaps [rsp], xmm0
000079bd661d71e8  vmovaps [rsp+0x10], xmm1
000079bd661d71ee  vmovaps [rsp+0x20], xmm2
000079bd661d71f4  vmovaps [rsp+0x30], xmm3
000079bd661d71fa  vmovaps [rsp+0x40], xmm4
000079bd661d7200  vmovaps [rsp+0x50], xmm5
000079bd661d7206  vmovaps [rsp+0x60], xmm6
000079bd661d720c  vmovaps [rsp+0x70], xmm7
000079bd661d7212  vmovaps [rsp+0x80], xmm8
000079bd661d721b  vmovaps [rsp+0x90], xmm10
000079bd661d7224  vmovaps [rsp+0xA0], xmm11
000079bd661d722d  vmovaps [rsp+0xB0], xmm12
000079bd661d7236  vmovaps [rsp+0xC0], xmm13
000079bd661d723f  vmovaps [rsp+0xD0], xmm14
000079bd661d7248  vmovaps [rsp+0xE0], xmm15
000079bd661d7251  sub rsp, 0x30
000079bd661d7255  movaps [rsp], xmm9
000079bd661d725a  movaps [rsp+0x10], xmm10
000079bd661d7260  movaps [rsp+0x20], xmm8
000079bd661d7266  lea rdi, [rsp]
000079bd661d726a  mov esi, 0x00
000079bd661d726f  mov rax, 0x56EBD57B0530
000079bd661d7279  call rax
000079bd661d727b  movaps xmm9, [rsp]
000079bd661d7280  add rsp, 0x30
000079bd661d7284  vmovaps xmm0, [rsp]
000079bd661d7289  vmovaps xmm1, [rsp+0x10]
000079bd661d728f  vmovaps xmm2, [rsp+0x20]
000079bd661d7295  vmovaps xmm3, [rsp+0x30]
000079bd661d729b  vmovaps xmm4, [rsp+0x40]
000079bd661d72a1  vmovaps xmm5, [rsp+0x50]
000079bd661d72a7  vmovaps xmm6, [rsp+0x60]
000079bd661d72ad  vmovaps xmm7, [rsp+0x70]
000079bd661d72b3  vmovaps xmm8, [rsp+0x80]
000079bd661d72bc  vmovaps xmm10, [rsp+0x90]
000079bd661d72c5  vmovaps xmm11, [rsp+0xA0]
000079bd661d72ce  vmovaps xmm12, [rsp+0xB0]
000079bd661d72d7  vmovaps xmm13, [rsp+0xC0]
000079bd661d72e0  vmovaps xmm14, [rsp+0xD0]
000079bd661d72e9  vmovaps xmm15, [rsp+0xE0]
000079bd661d72f2  add rsp, 0xF0
000079bd661d72f9  pop r11
000079bd661d72fb  pop r10
000079bd661d72fd  pop r9
000079bd661d72ff  pop r8
000079bd661d7301  pop rsi
000079bd661d7302  pop rdi
000079bd661d7303  pop rdx
000079bd661d7304  pop rcx
000079bd661d7305  pop rax
000079bd661d7306  add rsp, 0x08
000079bd661d730a  jmp 0x000079BD661D5AFB
000079bd661d730f  call 0x000079BD660D64F0
000079bd661d7314  jmp 0x000079BD661D5C15
000079bd661d7319  call 0x000079BD660D64F0
000079bd661d731e  jmp 0x000079BD661D5C2B
000079bd661d7323  sub rsp, 0x08
000079bd661d7327  push rax
000079bd661d7328  push rcx
000079bd661d7329  push rdx
000079bd661d732a  push rdi
000079bd661d732b  push rsi
000079bd661d732c  push r8
000079bd661d732e  push r9
000079bd661d7330  push r10
000079bd661d7332  push r11
000079bd661d7334  sub rsp, 0xF0
000079bd661d733b  vmovaps [rsp], xmm0
000079bd661d7340  vmovaps [rsp+0x10], xmm2
000079bd661d7346  vmovaps [rsp+0x20], xmm3
000079bd661d734c  vmovaps [rsp+0x30], xmm4
000079bd661d7352  vmovaps [rsp+0x40], xmm5
000079bd661d7358  vmovaps [rsp+0x50], xmm6
000079bd661d735e  vmovaps [rsp+0x60], xmm7
000079bd661d7364  vmovaps [rsp+0x70], xmm8
000079bd661d736a  vmovaps [rsp+0x80], xmm9
000079bd661d7373  vmovaps [rsp+0x90], xmm10
000079bd661d737c  vmovaps [rsp+0xA0], xmm11
000079bd661d7385  vmovaps [rsp+0xB0], xmm12
000079bd661d738e  vmovaps [rsp+0xC0], xmm13
000079bd661d7397  vmovaps [rsp+0xD0], xmm14
000079bd661d73a0  vmovaps [rsp+0xE0], xmm15
000079bd661d73a9  sub rsp, 0x30
000079bd661d73ad  movaps [rsp], xmm1
000079bd661d73b1  movaps [rsp+0x10], xmm6
000079bd661d73b6  movaps [rsp+0x20], xmm15
000079bd661d73bc  lea rdi, [rsp]
000079bd661d73c0  mov esi, 0x00
000079bd661d73c5  mov rax, 0x56EBD57B0530
000079bd661d73cf  call rax
000079bd661d73d1  movaps xmm1, [rsp]
000079bd661d73d5  add rsp, 0x30
000079bd661d73d9  vmovaps xmm0, [rsp]
000079bd661d73de  vmovaps xmm2, [rsp+0x10]
000079bd661d73e4  vmovaps xmm3, [rsp+0x20]
000079bd661d73ea  vmovaps xmm4, [rsp+0x30]
000079bd661d73f0  vmovaps xmm5, [rsp+0x40]
000079bd661d73f6  vmovaps xmm6, [rsp+0x50]
000079bd661d73fc  vmovaps xmm7, [rsp+0x60]
000079bd661d7402  vmovaps xmm8, [rsp+0x70]
000079bd661d7408  vmovaps xmm9, [rsp+0x80]
000079bd661d7411  vmovaps xmm10, [rsp+0x90]
000079bd661d741a  vmovaps xmm11, [rsp+0xA0]
000079bd661d7423  vmovaps xmm12, [rsp+0xB0]
000079bd661d742c  vmovaps xmm13, [rsp+0xC0]
000079bd661d7435  vmovaps xmm14, [rsp+0xD0]
000079bd661d743e  vmovaps xmm15, [rsp+0xE0]
000079bd661d7447  add rsp, 0xF0
000079bd661d744e  pop r11
000079bd661d7450  pop r10
000079bd661d7452  pop r9
000079bd661d7454  pop r8
000079bd661d7456  pop rsi
000079bd661d7457  pop rdi
000079bd661d7458  pop rdx
000079bd661d7459  pop rcx
000079bd661d745a  pop rax
000079bd661d745b  add rsp, 0x08
000079bd661d745f  jmp 0x000079BD661D5C68
000079bd661d7464  call 0x000079BD660E5820
000079bd661d7469  jmp 0x000079BD661D5C75
000079bd661d746e  sub rsp, 0x08
000079bd661d7472  push rax
000079bd661d7473  push rcx
000079bd661d7474  push rdx
000079bd661d7475  push rdi
000079bd661d7476  push rsi
000079bd661d7477  push r8
000079bd661d7479  push r9
000079bd661d747b  push r10
000079bd661d747d  push r11
000079bd661d747f  sub rsp, 0xF0
000079bd661d7486  vmovaps [rsp], xmm0
000079bd661d748b  vmovaps [rsp+0x10], xmm1
000079bd661d7491  vmovaps [rsp+0x20], xmm2
000079bd661d7497  vmovaps [rsp+0x30], xmm3
000079bd661d749d  vmovaps [rsp+0x40], xmm4
000079bd661d74a3  vmovaps [rsp+0x50], xmm5
000079bd661d74a9  vmovaps [rsp+0x60], xmm6
000079bd661d74af  vmovaps [rsp+0x70], xmm7
000079bd661d74b5  vmovaps [rsp+0x80], xmm8
000079bd661d74be  vmovaps [rsp+0x90], xmm9
000079bd661d74c7  vmovaps [rsp+0xA0], xmm10
000079bd661d74d0  vmovaps [rsp+0xB0], xmm11
000079bd661d74d9  vmovaps [rsp+0xC0], xmm12
000079bd661d74e2  vmovaps [rsp+0xD0], xmm13
000079bd661d74eb  vmovaps [rsp+0xE0], xmm15
000079bd661d74f4  sub rsp, 0x30
000079bd661d74f8  movaps [rsp], xmm14
000079bd661d74fd  movaps [rsp+0x10], xmm4
000079bd661d7502  movaps [rsp+0x20], xmm3
000079bd661d7507  lea rdi, [rsp]
000079bd661d750b  mov esi, 0x00
000079bd661d7510  mov rax, 0x56EBD57B0530
000079bd661d751a  call rax
000079bd661d751c  movaps xmm14, [rsp]
000079bd661d7521  add rsp, 0x30
000079bd661d7525  vmovaps xmm0, [rsp]
000079bd661d752a  vmovaps xmm1, [rsp+0x10]
000079bd661d7530  vmovaps xmm2, [rsp+0x20]
000079bd661d7536  vmovaps xmm3, [rsp+0x30]
000079bd661d753c  vmovaps xmm4, [rsp+0x40]
000079bd661d7542  vmovaps xmm5, [rsp+0x50]
000079bd661d7548  vmovaps xmm6, [rsp+0x60]
000079bd661d754e  vmovaps xmm7, [rsp+0x70]
000079bd661d7554  vmovaps xmm8, [rsp+0x80]
000079bd661d755d  vmovaps xmm9, [rsp+0x90]
000079bd661d7566  vmovaps xmm10, [rsp+0xA0]
000079bd661d756f  vmovaps xmm11, [rsp+0xB0]
000079bd661d7578  vmovaps xmm12, [rsp+0xC0]
000079bd661d7581  vmovaps xmm13, [rsp+0xD0]
000079bd661d758a  vmovaps xmm15, [rsp+0xE0]
000079bd661d7593  add rsp, 0xF0
000079bd661d759a  pop r11
000079bd661d759c  pop r10
000079bd661d759e  pop r9
000079bd661d75a0  pop r8
000079bd661d75a2  pop rsi
000079bd661d75a3  pop rdi
000079bd661d75a4  pop rdx
000079bd661d75a5  pop rcx
000079bd661d75a6  pop rax
000079bd661d75a7  add rsp, 0x08
000079bd661d75ab  jmp 0x000079BD661D5C8F
000079bd661d75b0  sub rsp, 0x08
000079bd661d75b4  push rax
000079bd661d75b5  push rcx
000079bd661d75b6  push rdx
000079bd661d75b7  push rdi
000079bd661d75b8  push rsi
000079bd661d75b9  push r8
000079bd661d75bb  push r9
000079bd661d75bd  push r10
000079bd661d75bf  push r11
000079bd661d75c1  sub rsp, 0xF0
000079bd661d75c8  vmovaps [rsp], xmm0
000079bd661d75cd  vmovaps [rsp+0x10], xmm1
000079bd661d75d3  vmovaps [rsp+0x20], xmm2
000079bd661d75d9  vmovaps [rsp+0x30], xmm3
000079bd661d75df  vmovaps [rsp+0x40], xmm4
000079bd661d75e5  vmovaps [rsp+0x50], xmm5
000079bd661d75eb  vmovaps [rsp+0x60], xmm7
000079bd661d75f1  vmovaps [rsp+0x70], xmm8
000079bd661d75f7  vmovaps [rsp+0x80], xmm9
000079bd661d7600  vmovaps [rsp+0x90], xmm10
000079bd661d7609  vmovaps [rsp+0xA0], xmm11
000079bd661d7612  vmovaps [rsp+0xB0], xmm12
000079bd661d761b  vmovaps [rsp+0xC0], xmm13
000079bd661d7624  vmovaps [rsp+0xD0], xmm14
000079bd661d762d  vmovaps [rsp+0xE0], xmm15
000079bd661d7636  sub rsp, 0x30
000079bd661d763a  movaps [rsp], xmm6
000079bd661d763e  movaps [rsp+0x10], xmm9
000079bd661d7644  movaps [rsp+0x20], xmm7
000079bd661d7649  lea rdi, [rsp]
000079bd661d764d  mov esi, 0x00
000079bd661d7652  mov rax, 0x56EBD57B0530
000079bd661d765c  call rax
000079bd661d765e  movaps xmm6, [rsp]
000079bd661d7662  add rsp, 0x30
000079bd661d7666  vmovaps xmm0, [rsp]
000079bd661d766b  vmovaps xmm1, [rsp+0x10]
000079bd661d7671  vmovaps xmm2, [rsp+0x20]
000079bd661d7677  vmovaps xmm3, [rsp+0x30]
000079bd661d767d  vmovaps xmm4, [rsp+0x40]
000079bd661d7683  vmovaps xmm5, [rsp+0x50]
000079bd661d7689  vmovaps xmm7, [rsp+0x60]
000079bd661d768f  vmovaps xmm8, [rsp+0x70]
000079bd661d7695  vmovaps xmm9, [rsp+0x80]
000079bd661d769e  vmovaps xmm10, [rsp+0x90]
000079bd661d76a7  vmovaps xmm11, [rsp+0xA0]
000079bd661d76b0  vmovaps xmm12, [rsp+0xB0]
000079bd661d76b9  vmovaps xmm13, [rsp+0xC0]
000079bd661d76c2  vmovaps xmm14, [rsp+0xD0]
000079bd661d76cb  vmovaps xmm15, [rsp+0xE0]
000079bd661d76d4  add rsp, 0xF0
000079bd661d76db  pop r11
000079bd661d76dd  pop r10
000079bd661d76df  pop r9
000079bd661d76e1  pop r8
000079bd661d76e3  pop rsi
000079bd661d76e4  pop rdi
000079bd661d76e5  pop rdx
000079bd661d76e6  pop rcx
000079bd661d76e7  pop rax
000079bd661d76e8  add rsp, 0x08
000079bd661d76ec  jmp 0x000079BD661D5CA7
000079bd661d76f1  sub rsp, 0x08
000079bd661d76f5  push rax
000079bd661d76f6  push rcx
000079bd661d76f7  push rdx
000079bd661d76f8  push rdi
000079bd661d76f9  push rsi
000079bd661d76fa  push r8
000079bd661d76fc  push r9
000079bd661d76fe  push r10
000079bd661d7700  push r11
000079bd661d7702  sub rsp, 0xF0
000079bd661d7709  vmovaps [rsp], xmm0
000079bd661d770e  vmovaps [rsp+0x10], xmm1
000079bd661d7714  vmovaps [rsp+0x20], xmm2
000079bd661d771a  vmovaps [rsp+0x30], xmm3
000079bd661d7720  vmovaps [rsp+0x40], xmm4
000079bd661d7726  vmovaps [rsp+0x50], xmm5
000079bd661d772c  vmovaps [rsp+0x60], xmm6
000079bd661d7732  vmovaps [rsp+0x70], xmm8
000079bd661d7738  vmovaps [rsp+0x80], xmm9
000079bd661d7741  vmovaps [rsp+0x90], xmm10
000079bd661d774a  vmovaps [rsp+0xA0], xmm11
000079bd661d7753  vmovaps [rsp+0xB0], xmm12
000079bd661d775c  vmovaps [rsp+0xC0], xmm13
000079bd661d7765  vmovaps [rsp+0xD0], xmm14
000079bd661d776e  vmovaps [rsp+0xE0], xmm15
000079bd661d7777  sub rsp, 0x30
000079bd661d777b  movaps [rsp], xmm7
000079bd661d777f  movaps [rsp+0x10], xmm4
000079bd661d7784  movaps [rsp+0x20], xmm9
000079bd661d778a  lea rdi, [rsp]
000079bd661d778e  mov esi, 0x00
000079bd661d7793  mov rax, 0x56EBD57B0530
000079bd661d779d  call rax
000079bd661d779f  movaps xmm7, [rsp]
000079bd661d77a3  add rsp, 0x30
000079bd661d77a7  vmovaps xmm0, [rsp]
000079bd661d77ac  vmovaps xmm1, [rsp+0x10]
000079bd661d77b2  vmovaps xmm2, [rsp+0x20]
000079bd661d77b8  vmovaps xmm3, [rsp+0x30]
000079bd661d77be  vmovaps xmm4, [rsp+0x40]
000079bd661d77c4  vmovaps xmm5, [rsp+0x50]
000079bd661d77ca  vmovaps xmm6, [rsp+0x60]
000079bd661d77d0  vmovaps xmm8, [rsp+0x70]
000079bd661d77d6  vmovaps xmm9, [rsp+0x80]
000079bd661d77df  vmovaps xmm10, [rsp+0x90]
000079bd661d77e8  vmovaps xmm11, [rsp+0xA0]
000079bd661d77f1  vmovaps xmm12, [rsp+0xB0]
000079bd661d77fa  vmovaps xmm13, [rsp+0xC0]
000079bd661d7803  vmovaps xmm14, [rsp+0xD0]
000079bd661d780c  vmovaps xmm15, [rsp+0xE0]
000079bd661d7815  add rsp, 0xF0
000079bd661d781c  pop r11
000079bd661d781e  pop r10
000079bd661d7820  pop r9
000079bd661d7822  pop r8
000079bd661d7824  pop rsi
000079bd661d7825  pop rdi
000079bd661d7826  pop rdx
000079bd661d7827  pop rcx
000079bd661d7828  pop rax
000079bd661d7829  add rsp, 0x08
000079bd661d782d  jmp 0x000079BD661D5CD4
000079bd661d7832  sub rsp, 0x08
000079bd661d7836  push rax
000079bd661d7837  push rcx
000079bd661d7838  push rdx
000079bd661d7839  push rdi
000079bd661d783a  push rsi
000079bd661d783b  push r8
000079bd661d783d  push r9
000079bd661d783f  push r10
000079bd661d7841  push r11
000079bd661d7843  sub rsp, 0xF0
000079bd661d784a  vmovaps [rsp], xmm0
000079bd661d784f  vmovaps [rsp+0x10], xmm1
000079bd661d7855  vmovaps [rsp+0x20], xmm2
000079bd661d785b  vmovaps [rsp+0x30], xmm3
000079bd661d7861  vmovaps [rsp+0x40], xmm5
000079bd661d7867  vmovaps [rsp+0x50], xmm6
000079bd661d786d  vmovaps [rsp+0x60], xmm7
000079bd661d7873  vmovaps [rsp+0x70], xmm8
000079bd661d7879  vmovaps [rsp+0x80], xmm9
000079bd661d7882  vmovaps [rsp+0x90], xmm10
000079bd661d788b  vmovaps [rsp+0xA0], xmm11
000079bd661d7894  vmovaps [rsp+0xB0], xmm12
000079bd661d789d  vmovaps [rsp+0xC0], xmm13
000079bd661d78a6  vmovaps [rsp+0xD0], xmm14
000079bd661d78af  vmovaps [rsp+0xE0], xmm15
000079bd661d78b8  sub rsp, 0x30
000079bd661d78bc  movaps [rsp], xmm4
000079bd661d78c0  movaps [rsp+0x10], xmm15
000079bd661d78c6  movaps [rsp+0x20], xmm9
000079bd661d78cc  lea rdi, [rsp]
000079bd661d78d0  mov esi, 0x00
000079bd661d78d5  mov rax, 0x56EBD57B0530
000079bd661d78df  call rax
000079bd661d78e1  movaps xmm4, [rsp]
000079bd661d78e5  add rsp, 0x30
000079bd661d78e9  vmovaps xmm0, [rsp]
000079bd661d78ee  vmovaps xmm1, [rsp+0x10]
000079bd661d78f4  vmovaps xmm2, [rsp+0x20]
000079bd661d78fa  vmovaps xmm3, [rsp+0x30]
000079bd661d7900  vmovaps xmm5, [rsp+0x40]
000079bd661d7906  vmovaps xmm6, [rsp+0x50]
000079bd661d790c  vmovaps xmm7, [rsp+0x60]
000079bd661d7912  vmovaps xmm8, [rsp+0x70]
000079bd661d7918  vmovaps xmm9, [rsp+0x80]
000079bd661d7921  vmovaps xmm10, [rsp+0x90]
000079bd661d792a  vmovaps xmm11, [rsp+0xA0]
000079bd661d7933  vmovaps xmm12, [rsp+0xB0]
000079bd661d793c  vmovaps xmm13, [rsp+0xC0]
000079bd661d7945  vmovaps xmm14, [rsp+0xD0]
000079bd661d794e  vmovaps xmm15, [rsp+0xE0]
000079bd661d7957  add rsp, 0xF0
000079bd661d795e  pop r11
000079bd661d7960  pop r10
000079bd661d7962  pop r9
000079bd661d7964  pop r8
000079bd661d7966  pop rsi
000079bd661d7967  pop rdi
000079bd661d7968  pop rdx
000079bd661d7969  pop rcx
000079bd661d796a  pop rax
000079bd661d796b  add rsp, 0x08
000079bd661d796f  jmp 0x000079BD661D5CF9
000079bd661d7974  call 0x000079BD660E5820
000079bd661d7979  jmp 0x000079BD661D5D06
000079bd661d797e  sub rsp, 0x08
000079bd661d7982  push rax
000079bd661d7983  push rcx
000079bd661d7984  push rdx
000079bd661d7985  push rdi
000079bd661d7986  push rsi
000079bd661d7987  push r8
000079bd661d7989  push r9
000079bd661d798b  push r10
000079bd661d798d  push r11
000079bd661d798f  sub rsp, 0xF0
000079bd661d7996  vmovaps [rsp], xmm0
000079bd661d799b  vmovaps [rsp+0x10], xmm1
000079bd661d79a1  vmovaps [rsp+0x20], xmm2
000079bd661d79a7  vmovaps [rsp+0x30], xmm4
000079bd661d79ad  vmovaps [rsp+0x40], xmm5
000079bd661d79b3  vmovaps [rsp+0x50], xmm6
000079bd661d79b9  vmovaps [rsp+0x60], xmm7
000079bd661d79bf  vmovaps [rsp+0x70], xmm8
000079bd661d79c5  vmovaps [rsp+0x80], xmm9
000079bd661d79ce  vmovaps [rsp+0x90], xmm10
000079bd661d79d7  vmovaps [rsp+0xA0], xmm11
000079bd661d79e0  vmovaps [rsp+0xB0], xmm12
000079bd661d79e9  vmovaps [rsp+0xC0], xmm13
000079bd661d79f2  vmovaps [rsp+0xD0], xmm14
000079bd661d79fb  vmovaps [rsp+0xE0], xmm15
000079bd661d7a04  sub rsp, 0x30
000079bd661d7a08  movaps [rsp], xmm3
000079bd661d7a0c  movaps [rsp+0x10], xmm1
000079bd661d7a11  movaps [rsp+0x20], xmm9
000079bd661d7a17  lea rdi, [rsp]
000079bd661d7a1b  mov esi, 0x00
000079bd661d7a20  mov rax, 0x56EBD57B0530
000079bd661d7a2a  call rax
000079bd661d7a2c  movaps xmm3, [rsp]
000079bd661d7a30  add rsp, 0x30
000079bd661d7a34  vmovaps xmm0, [rsp]
000079bd661d7a39  vmovaps xmm1, [rsp+0x10]
000079bd661d7a3f  vmovaps xmm2, [rsp+0x20]
000079bd661d7a45  vmovaps xmm4, [rsp+0x30]
000079bd661d7a4b  vmovaps xmm5, [rsp+0x40]
000079bd661d7a51  vmovaps xmm6, [rsp+0x50]
000079bd661d7a57  vmovaps xmm7, [rsp+0x60]
000079bd661d7a5d  vmovaps xmm8, [rsp+0x70]
000079bd661d7a63  vmovaps xmm9, [rsp+0x80]
000079bd661d7a6c  vmovaps xmm10, [rsp+0x90]
000079bd661d7a75  vmovaps xmm11, [rsp+0xA0]
000079bd661d7a7e  vmovaps xmm12, [rsp+0xB0]
000079bd661d7a87  vmovaps xmm13, [rsp+0xC0]
000079bd661d7a90  vmovaps xmm14, [rsp+0xD0]
000079bd661d7a99  vmovaps xmm15, [rsp+0xE0]
000079bd661d7aa2  add rsp, 0xF0
000079bd661d7aa9  pop r11
000079bd661d7aab  pop r10
000079bd661d7aad  pop r9
000079bd661d7aaf  pop r8
000079bd661d7ab1  pop rsi
000079bd661d7ab2  pop rdi
000079bd661d7ab3  pop rdx
000079bd661d7ab4  pop rcx
000079bd661d7ab5  pop rax
000079bd661d7ab6  add rsp, 0x08
000079bd661d7aba  jmp 0x000079BD661D5D43
000079bd661d7abf  sub rsp, 0x08
000079bd661d7ac3  push rax
000079bd661d7ac4  push rcx
000079bd661d7ac5  push rdx
000079bd661d7ac6  push rdi
000079bd661d7ac7  push rsi
000079bd661d7ac8  push r8
000079bd661d7aca  push r9
000079bd661d7acc  push r10
000079bd661d7ace  push r11
000079bd661d7ad0  sub rsp, 0xF0
000079bd661d7ad7  vmovaps [rsp], xmm0
000079bd661d7adc  vmovaps [rsp+0x10], xmm2
000079bd661d7ae2  vmovaps [rsp+0x20], xmm3
000079bd661d7ae8  vmovaps [rsp+0x30], xmm4
000079bd661d7aee  vmovaps [rsp+0x40], xmm5
000079bd661d7af4  vmovaps [rsp+0x50], xmm6
000079bd661d7afa  vmovaps [rsp+0x60], xmm7
000079bd661d7b00  vmovaps [rsp+0x70], xmm8
000079bd661d7b06  vmovaps [rsp+0x80], xmm9
000079bd661d7b0f  vmovaps [rsp+0x90], xmm10
000079bd661d7b18  vmovaps [rsp+0xA0], xmm11
000079bd661d7b21  vmovaps [rsp+0xB0], xmm12
000079bd661d7b2a  vmovaps [rsp+0xC0], xmm13
000079bd661d7b33  vmovaps [rsp+0xD0], xmm14
000079bd661d7b3c  vmovaps [rsp+0xE0], xmm15
000079bd661d7b45  sub rsp, 0x30
000079bd661d7b49  movaps [rsp], xmm1
000079bd661d7b4d  movaps [rsp+0x10], xmm15
000079bd661d7b53  movaps [rsp+0x20], xmm9
000079bd661d7b59  lea rdi, [rsp]
000079bd661d7b5d  mov esi, 0x00
000079bd661d7b62  mov rax, 0x56EBD57B0530
000079bd661d7b6c  call rax
000079bd661d7b6e  movaps xmm1, [rsp]
000079bd661d7b72  add rsp, 0x30
000079bd661d7b76  vmovaps xmm0, [rsp]
000079bd661d7b7b  vmovaps xmm2, [rsp+0x10]
000079bd661d7b81  vmovaps xmm3, [rsp+0x20]
000079bd661d7b87  vmovaps xmm4, [rsp+0x30]
000079bd661d7b8d  vmovaps xmm5, [rsp+0x40]
000079bd661d7b93  vmovaps xmm6, [rsp+0x50]
000079bd661d7b99  vmovaps xmm7, [rsp+0x60]
000079bd661d7b9f  vmovaps xmm8, [rsp+0x70]
000079bd661d7ba5  vmovaps xmm9, [rsp+0x80]
000079bd661d7bae  vmovaps xmm10, [rsp+0x90]
000079bd661d7bb7  vmovaps xmm11, [rsp+0xA0]
000079bd661d7bc0  vmovaps xmm12, [rsp+0xB0]
000079bd661d7bc9  vmovaps xmm13, [rsp+0xC0]
000079bd661d7bd2  vmovaps xmm14, [rsp+0xD0]
000079bd661d7bdb  vmovaps xmm15, [rsp+0xE0]
000079bd661d7be4  add rsp, 0xF0
000079bd661d7beb  pop r11
000079bd661d7bed  pop r10
000079bd661d7bef  pop r9
000079bd661d7bf1  pop r8
000079bd661d7bf3  pop rsi
000079bd661d7bf4  pop rdi
000079bd661d7bf5  pop rdx
000079bd661d7bf6  pop rcx
000079bd661d7bf7  pop rax
000079bd661d7bf8  add rsp, 0x08
000079bd661d7bfc  jmp 0x000079BD661D5DCB
000079bd661d7c01  call 0x000079BD660E5820
000079bd661d7c06  jmp 0x000079BD661D5DD8
000079bd661d7c0b  sub rsp, 0x08
000079bd661d7c0f  push rax
000079bd661d7c10  push rcx
000079bd661d7c11  push rdx
000079bd661d7c12  push rdi
000079bd661d7c13  push rsi
000079bd661d7c14  push r8
000079bd661d7c16  push r9
000079bd661d7c18  push r10
000079bd661d7c1a  push r11
000079bd661d7c1c  sub rsp, 0xF0
000079bd661d7c23  vmovaps [rsp], xmm0
000079bd661d7c28  vmovaps [rsp+0x10], xmm2
000079bd661d7c2e  vmovaps [rsp+0x20], xmm3
000079bd661d7c34  vmovaps [rsp+0x30], xmm4
000079bd661d7c3a  vmovaps [rsp+0x40], xmm5
000079bd661d7c40  vmovaps [rsp+0x50], xmm6
000079bd661d7c46  vmovaps [rsp+0x60], xmm7
000079bd661d7c4c  vmovaps [rsp+0x70], xmm8
000079bd661d7c52  vmovaps [rsp+0x80], xmm9
000079bd661d7c5b  vmovaps [rsp+0x90], xmm10
000079bd661d7c64  vmovaps [rsp+0xA0], xmm11
000079bd661d7c6d  vmovaps [rsp+0xB0], xmm12
000079bd661d7c76  vmovaps [rsp+0xC0], xmm13
000079bd661d7c7f  vmovaps [rsp+0xD0], xmm14
000079bd661d7c88  vmovaps [rsp+0xE0], xmm15
000079bd661d7c91  sub rsp, 0x30
000079bd661d7c95  movaps [rsp], xmm1
000079bd661d7c99  movaps [rsp+0x10], xmm5
000079bd661d7c9e  movaps [rsp+0x20], xmm7
000079bd661d7ca3  lea rdi, [rsp]
000079bd661d7ca7  mov esi, 0x00
000079bd661d7cac  mov rax, 0x56EBD57B0530
000079bd661d7cb6  call rax
000079bd661d7cb8  movaps xmm1, [rsp]
000079bd661d7cbc  add rsp, 0x30
000079bd661d7cc0  vmovaps xmm0, [rsp]
000079bd661d7cc5  vmovaps xmm2, [rsp+0x10]
000079bd661d7ccb  vmovaps xmm3, [rsp+0x20]
000079bd661d7cd1  vmovaps xmm4, [rsp+0x30]
000079bd661d7cd7  vmovaps xmm5, [rsp+0x40]
000079bd661d7cdd  vmovaps xmm6, [rsp+0x50]
000079bd661d7ce3  vmovaps xmm7, [rsp+0x60]
000079bd661d7ce9  vmovaps xmm8, [rsp+0x70]
000079bd661d7cef  vmovaps xmm9, [rsp+0x80]
000079bd661d7cf8  vmovaps xmm10, [rsp+0x90]
000079bd661d7d01  vmovaps xmm11, [rsp+0xA0]
000079bd661d7d0a  vmovaps xmm12, [rsp+0xB0]
000079bd661d7d13  vmovaps xmm13, [rsp+0xC0]
000079bd661d7d1c  vmovaps xmm14, [rsp+0xD0]
000079bd661d7d25  vmovaps xmm15, [rsp+0xE0]
000079bd661d7d2e  add rsp, 0xF0
000079bd661d7d35  pop r11
000079bd661d7d37  pop r10
000079bd661d7d39  pop r9
000079bd661d7d3b  pop r8
000079bd661d7d3d  pop rsi
000079bd661d7d3e  pop rdi
000079bd661d7d3f  pop rdx
000079bd661d7d40  pop rcx
000079bd661d7d41  pop rax
000079bd661d7d42  add rsp, 0x08
000079bd661d7d46  jmp 0x000079BD661D5E7D
000079bd661d7d4b  sub rsp, 0x08
000079bd661d7d4f  push rax
000079bd661d7d50  push rcx
000079bd661d7d51  push rdx
000079bd661d7d52  push rdi
000079bd661d7d53  push rsi
000079bd661d7d54  push r8
000079bd661d7d56  push r9
000079bd661d7d58  push r10
000079bd661d7d5a  push r11
000079bd661d7d5c  sub rsp, 0xF0
000079bd661d7d63  vmovaps [rsp], xmm0
000079bd661d7d68  vmovaps [rsp+0x10], xmm1
000079bd661d7d6e  vmovaps [rsp+0x20], xmm2
000079bd661d7d74  vmovaps [rsp+0x30], xmm3
000079bd661d7d7a  vmovaps [rsp+0x40], xmm4
000079bd661d7d80  vmovaps [rsp+0x50], xmm5
000079bd661d7d86  vmovaps [rsp+0x60], xmm6
000079bd661d7d8c  vmovaps [rsp+0x70], xmm8
000079bd661d7d92  vmovaps [rsp+0x80], xmm9
000079bd661d7d9b  vmovaps [rsp+0x90], xmm10
000079bd661d7da4  vmovaps [rsp+0xA0], xmm11
000079bd661d7dad  vmovaps [rsp+0xB0], xmm12
000079bd661d7db6  vmovaps [rsp+0xC0], xmm13
000079bd661d7dbf  vmovaps [rsp+0xD0], xmm14
000079bd661d7dc8  vmovaps [rsp+0xE0], xmm15
000079bd661d7dd1  sub rsp, 0x30
000079bd661d7dd5  movaps [rsp], xmm7
000079bd661d7dd9  movaps [rsp+0x10], xmm5
000079bd661d7dde  movaps [rsp+0x20], xmm15
000079bd661d7de4  lea rdi, [rsp]
000079bd661d7de8  mov esi, 0x00
000079bd661d7ded  mov rax, 0x56EBD57B0530
000079bd661d7df7  call rax
000079bd661d7df9  movaps xmm7, [rsp]
000079bd661d7dfd  add rsp, 0x30
000079bd661d7e01  vmovaps xmm0, [rsp]
000079bd661d7e06  vmovaps xmm1, [rsp+0x10]
000079bd661d7e0c  vmovaps xmm2, [rsp+0x20]
000079bd661d7e12  vmovaps xmm3, [rsp+0x30]
000079bd661d7e18  vmovaps xmm4, [rsp+0x40]
000079bd661d7e1e  vmovaps xmm5, [rsp+0x50]
000079bd661d7e24  vmovaps xmm6, [rsp+0x60]
000079bd661d7e2a  vmovaps xmm8, [rsp+0x70]
000079bd661d7e30  vmovaps xmm9, [rsp+0x80]
000079bd661d7e39  vmovaps xmm10, [rsp+0x90]
000079bd661d7e42  vmovaps xmm11, [rsp+0xA0]
000079bd661d7e4b  vmovaps xmm12, [rsp+0xB0]
000079bd661d7e54  vmovaps xmm13, [rsp+0xC0]
000079bd661d7e5d  vmovaps xmm14, [rsp+0xD0]
000079bd661d7e66  vmovaps xmm15, [rsp+0xE0]
000079bd661d7e6f  add rsp, 0xF0
000079bd661d7e76  pop r11
000079bd661d7e78  pop r10
000079bd661d7e7a  pop r9
000079bd661d7e7c  pop r8
000079bd661d7e7e  pop rsi
000079bd661d7e7f  pop rdi
000079bd661d7e80  pop rdx
000079bd661d7e81  pop rcx
000079bd661d7e82  pop rax
000079bd661d7e83  add rsp, 0x08
000079bd661d7e87  jmp 0x000079BD661D5EB3
000079bd661d7e8c  call 0x000079BD660D64F0
000079bd661d7e91  jmp 0x000079BD661D5EC0
000079bd661d7e96  sub rsp, 0x08
000079bd661d7e9a  push rax
000079bd661d7e9b  push rcx
000079bd661d7e9c  push rdx
000079bd661d7e9d  push rdi
000079bd661d7e9e  push rsi
000079bd661d7e9f  push r8
000079bd661d7ea1  push r9
000079bd661d7ea3  push r10
000079bd661d7ea5  push r11
000079bd661d7ea7  sub rsp, 0xF0
000079bd661d7eae  vmovaps [rsp], xmm0
000079bd661d7eb3  vmovaps [rsp+0x10], xmm1
000079bd661d7eb9  vmovaps [rsp+0x20], xmm2
000079bd661d7ebf  vmovaps [rsp+0x30], xmm3
000079bd661d7ec5  vmovaps [rsp+0x40], xmm4
000079bd661d7ecb  vmovaps [rsp+0x50], xmm5
000079bd661d7ed1  vmovaps [rsp+0x60], xmm6
000079bd661d7ed7  vmovaps [rsp+0x70], xmm7
000079bd661d7edd  vmovaps [rsp+0x80], xmm8
000079bd661d7ee6  vmovaps [rsp+0x90], xmm9
000079bd661d7eef  vmovaps [rsp+0xA0], xmm10
000079bd661d7ef8  vmovaps [rsp+0xB0], xmm11
000079bd661d7f01  vmovaps [rsp+0xC0], xmm12
000079bd661d7f0a  vmovaps [rsp+0xD0], xmm13
000079bd661d7f13  vmovaps [rsp+0xE0], xmm14
000079bd661d7f1c  sub rsp, 0x30
000079bd661d7f20  movaps [rsp], xmm15
000079bd661d7f25  movaps [rsp+0x10], xmm5
000079bd661d7f2a  movaps [rsp+0x20], xmm3
000079bd661d7f2f  lea rdi, [rsp]
000079bd661d7f33  mov esi, 0x00
000079bd661d7f38  mov rax, 0x56EBD57B0530
000079bd661d7f42  call rax
000079bd661d7f44  movaps xmm15, [rsp]
000079bd661d7f49  add rsp, 0x30
000079bd661d7f4d  vmovaps xmm0, [rsp]
000079bd661d7f52  vmovaps xmm1, [rsp+0x10]
000079bd661d7f58  vmovaps xmm2, [rsp+0x20]
000079bd661d7f5e  vmovaps xmm3, [rsp+0x30]
000079bd661d7f64  vmovaps xmm4, [rsp+0x40]
000079bd661d7f6a  vmovaps xmm5, [rsp+0x50]
000079bd661d7f70  vmovaps xmm6, [rsp+0x60]
000079bd661d7f76  vmovaps xmm7, [rsp+0x70]
000079bd661d7f7c  vmovaps xmm8, [rsp+0x80]
000079bd661d7f85  vmovaps xmm9, [rsp+0x90]
000079bd661d7f8e  vmovaps xmm10, [rsp+0xA0]
000079bd661d7f97  vmovaps xmm11, [rsp+0xB0]
000079bd661d7fa0  vmovaps xmm12, [rsp+0xC0]
000079bd661d7fa9  vmovaps xmm13, [rsp+0xD0]
000079bd661d7fb2  vmovaps xmm14, [rsp+0xE0]
000079bd661d7fbb  add rsp, 0xF0
000079bd661d7fc2  pop r11
000079bd661d7fc4  pop r10
000079bd661d7fc6  pop r9
000079bd661d7fc8  pop r8
000079bd661d7fca  pop rsi
000079bd661d7fcb  pop rdi
000079bd661d7fcc  pop rdx
000079bd661d7fcd  pop rcx
000079bd661d7fce  pop rax
000079bd661d7fcf  add rsp, 0x08
000079bd661d7fd3  jmp 0x000079BD661D5EE6
000079bd661d7fd8  sub rsp, 0x08
000079bd661d7fdc  push rax
000079bd661d7fdd  push rcx
000079bd661d7fde  push rdx
000079bd661d7fdf  push rdi
000079bd661d7fe0  push rsi
000079bd661d7fe1  push r8
000079bd661d7fe3  push r9
000079bd661d7fe5  push r10
000079bd661d7fe7  push r11
000079bd661d7fe9  sub rsp, 0xF0
000079bd661d7ff0  vmovaps [rsp], xmm0
000079bd661d7ff5  vmovaps [rsp+0x10], xmm2
000079bd661d7ffb  vmovaps [rsp+0x20], xmm3
000079bd661d8001  vmovaps [rsp+0x30], xmm4
000079bd661d8007  vmovaps [rsp+0x40], xmm5
000079bd661d800d  vmovaps [rsp+0x50], xmm6
000079bd661d8013  vmovaps [rsp+0x60], xmm7
000079bd661d8019  vmovaps [rsp+0x70], xmm8
000079bd661d801f  vmovaps [rsp+0x80], xmm9
000079bd661d8028  vmovaps [rsp+0x90], xmm10
000079bd661d8031  vmovaps [rsp+0xA0], xmm11
000079bd661d803a  vmovaps [rsp+0xB0], xmm12
000079bd661d8043  vmovaps [rsp+0xC0], xmm13
000079bd661d804c  vmovaps [rsp+0xD0], xmm14
000079bd661d8055  vmovaps [rsp+0xE0], xmm15
000079bd661d805e  sub rsp, 0x30
000079bd661d8062  movaps [rsp], xmm1
000079bd661d8066  movaps [rsp+0x10], xmm5
000079bd661d806b  movaps [rsp+0x20], xmm4
000079bd661d8070  lea rdi, [rsp]
000079bd661d8074  mov esi, 0x00
000079bd661d8079  mov rax, 0x56EBD57B0530
000079bd661d8083  call rax
000079bd661d8085  movaps xmm1, [rsp]
000079bd661d8089  add rsp, 0x30
000079bd661d808d  vmovaps xmm0, [rsp]
000079bd661d8092  vmovaps xmm2, [rsp+0x10]
000079bd661d8098  vmovaps xmm3, [rsp+0x20]
000079bd661d809e  vmovaps xmm4, [rsp+0x30]
000079bd661d80a4  vmovaps xmm5, [rsp+0x40]
000079bd661d80aa  vmovaps xmm6, [rsp+0x50]
000079bd661d80b0  vmovaps xmm7, [rsp+0x60]
000079bd661d80b6  vmovaps xmm8, [rsp+0x70]
000079bd661d80bc  vmovaps xmm9, [rsp+0x80]
000079bd661d80c5  vmovaps xmm10, [rsp+0x90]
000079bd661d80ce  vmovaps xmm11, [rsp+0xA0]
000079bd661d80d7  vmovaps xmm12, [rsp+0xB0]
000079bd661d80e0  vmovaps xmm13, [rsp+0xC0]
000079bd661d80e9  vmovaps xmm14, [rsp+0xD0]
000079bd661d80f2  vmovaps xmm15, [rsp+0xE0]
000079bd661d80fb  add rsp, 0xF0
000079bd661d8102  pop r11
000079bd661d8104  pop r10
000079bd661d8106  pop r9
000079bd661d8108  pop r8
000079bd661d810a  pop rsi
000079bd661d810b  pop rdi
000079bd661d810c  pop rdx
000079bd661d810d  pop rcx
000079bd661d810e  pop rax
000079bd661d810f  add rsp, 0x08
000079bd661d8113  jmp 0x000079BD661D5F06
000079bd661d8118  sub rsp, 0x08
000079bd661d811c  push rax
000079bd661d811d  push rcx
000079bd661d811e  push rdx
000079bd661d811f  push rdi
000079bd661d8120  push rsi
000079bd661d8121  push r8
000079bd661d8123  push r9
000079bd661d8125  push r10
000079bd661d8127  push r11
000079bd661d8129  sub rsp, 0xF0
000079bd661d8130  vmovaps [rsp], xmm0
000079bd661d8135  vmovaps [rsp+0x10], xmm1
000079bd661d813b  vmovaps [rsp+0x20], xmm2
000079bd661d8141  vmovaps [rsp+0x30], xmm3
000079bd661d8147  vmovaps [rsp+0x40], xmm5
000079bd661d814d  vmovaps [rsp+0x50], xmm6
000079bd661d8153  vmovaps [rsp+0x60], xmm7
000079bd661d8159  vmovaps [rsp+0x70], xmm8
000079bd661d815f  vmovaps [rsp+0x80], xmm9
000079bd661d8168  vmovaps [rsp+0x90], xmm10
000079bd661d8171  vmovaps [rsp+0xA0], xmm11
000079bd661d817a  vmovaps [rsp+0xB0], xmm12
000079bd661d8183  vmovaps [rsp+0xC0], xmm13
000079bd661d818c  vmovaps [rsp+0xD0], xmm14
000079bd661d8195  vmovaps [rsp+0xE0], xmm15
000079bd661d819e  sub rsp, 0x30
000079bd661d81a2  movaps [rsp], xmm4
000079bd661d81a6  movaps [rsp+0x10], xmm3
000079bd661d81ab  movaps [rsp+0x20], xmm5
000079bd661d81b0  lea rdi, [rsp]
000079bd661d81b4  mov esi, 0x00
000079bd661d81b9  mov rax, 0x56EBD57B0530
000079bd661d81c3  call rax
000079bd661d81c5  movaps xmm4, [rsp]
000079bd661d81c9  add rsp, 0x30
000079bd661d81cd  vmovaps xmm0, [rsp]
000079bd661d81d2  vmovaps xmm1, [rsp+0x10]
000079bd661d81d8  vmovaps xmm2, [rsp+0x20]
000079bd661d81de  vmovaps xmm3, [rsp+0x30]
000079bd661d81e4  vmovaps xmm5, [rsp+0x40]
000079bd661d81ea  vmovaps xmm6, [rsp+0x50]
000079bd661d81f0  vmovaps xmm7, [rsp+0x60]
000079bd661d81f6  vmovaps xmm8, [rsp+0x70]
000079bd661d81fc  vmovaps xmm9, [rsp+0x80]
000079bd661d8205  vmovaps xmm10, [rsp+0x90]
000079bd661d820e  vmovaps xmm11, [rsp+0xA0]
000079bd661d8217  vmovaps xmm12, [rsp+0xB0]
000079bd661d8220  vmovaps xmm13, [rsp+0xC0]
000079bd661d8229  vmovaps xmm14, [rsp+0xD0]
000079bd661d8232  vmovaps xmm15, [rsp+0xE0]
000079bd661d823b  add rsp, 0xF0
000079bd661d8242  pop r11
000079bd661d8244  pop r10
000079bd661d8246  pop r9
000079bd661d8248  pop r8
000079bd661d824a  pop rsi
000079bd661d824b  pop rdi
000079bd661d824c  pop rdx
000079bd661d824d  pop rcx
000079bd661d824e  pop rax
000079bd661d824f  add rsp, 0x08
000079bd661d8253  jmp 0x000079BD661D5F54
000079bd661d8258  call 0x000079BD660D64F0
000079bd661d825d  jmp 0x000079BD661D5F61
000079bd661d8262  sub rsp, 0x08
000079bd661d8266  push rax
000079bd661d8267  push rcx
000079bd661d8268  push rdx
000079bd661d8269  push rdi
000079bd661d826a  push rsi
000079bd661d826b  push r8
000079bd661d826d  push r9
000079bd661d826f  push r10
000079bd661d8271  push r11
000079bd661d8273  sub rsp, 0xF0
000079bd661d827a  vmovaps [rsp], xmm0
000079bd661d827f  vmovaps [rsp+0x10], xmm1
000079bd661d8285  vmovaps [rsp+0x20], xmm2
000079bd661d828b  vmovaps [rsp+0x30], xmm3
000079bd661d8291  vmovaps [rsp+0x40], xmm4
000079bd661d8297  vmovaps [rsp+0x50], xmm6
000079bd661d829d  vmovaps [rsp+0x60], xmm7
000079bd661d82a3  vmovaps [rsp+0x70], xmm8
000079bd661d82a9  vmovaps [rsp+0x80], xmm9
000079bd661d82b2  vmovaps [rsp+0x90], xmm10
000079bd661d82bb  vmovaps [rsp+0xA0], xmm11
000079bd661d82c4  vmovaps [rsp+0xB0], xmm12
000079bd661d82cd  vmovaps [rsp+0xC0], xmm13
000079bd661d82d6  vmovaps [rsp+0xD0], xmm14
000079bd661d82df  vmovaps [rsp+0xE0], xmm15
000079bd661d82e8  sub rsp, 0x30
000079bd661d82ec  movaps [rsp], xmm5
000079bd661d82f0  movaps [rsp+0x10], xmm6
000079bd661d82f5  movaps [rsp+0x20], xmm3
000079bd661d82fa  lea rdi, [rsp]
000079bd661d82fe  mov esi, 0x00
000079bd661d8303  mov rax, 0x56EBD57B0530
000079bd661d830d  call rax
000079bd661d830f  movaps xmm5, [rsp]
000079bd661d8313  add rsp, 0x30
000079bd661d8317  vmovaps xmm0, [rsp]
000079bd661d831c  vmovaps xmm1, [rsp+0x10]
000079bd661d8322  vmovaps xmm2, [rsp+0x20]
000079bd661d8328  vmovaps xmm3, [rsp+0x30]
000079bd661d832e  vmovaps xmm4, [rsp+0x40]
000079bd661d8334  vmovaps xmm6, [rsp+0x50]
000079bd661d833a  vmovaps xmm7, [rsp+0x60]
000079bd661d8340  vmovaps xmm8, [rsp+0x70]
000079bd661d8346  vmovaps xmm9, [rsp+0x80]
000079bd661d834f  vmovaps xmm10, [rsp+0x90]
000079bd661d8358  vmovaps xmm11, [rsp+0xA0]
000079bd661d8361  vmovaps xmm12, [rsp+0xB0]
000079bd661d836a  vmovaps xmm13, [rsp+0xC0]
000079bd661d8373  vmovaps xmm14, [rsp+0xD0]
000079bd661d837c  vmovaps xmm15, [rsp+0xE0]
000079bd661d8385  add rsp, 0xF0
000079bd661d838c  pop r11
000079bd661d838e  pop r10
000079bd661d8390  pop r9
000079bd661d8392  pop r8
000079bd661d8394  pop rsi
000079bd661d8395  pop rdi
000079bd661d8396  pop rdx
000079bd661d8397  pop rcx
000079bd661d8398  pop rax
000079bd661d8399  add rsp, 0x08
000079bd661d839d  jmp 0x000079BD661D5F87
000079bd661d83a2  sub rsp, 0x08
000079bd661d83a6  push rax
000079bd661d83a7  push rcx
000079bd661d83a8  push rdx
000079bd661d83a9  push rdi
000079bd661d83aa  push rsi
000079bd661d83ab  push r8
000079bd661d83ad  push r9
000079bd661d83af  push r10
000079bd661d83b1  push r11
000079bd661d83b3  sub rsp, 0xF0
000079bd661d83ba  vmovaps [rsp], xmm0
000079bd661d83bf  vmovaps [rsp+0x10], xmm1
000079bd661d83c5  vmovaps [rsp+0x20], xmm2
000079bd661d83cb  vmovaps [rsp+0x30], xmm3
000079bd661d83d1  vmovaps [rsp+0x40], xmm4
000079bd661d83d7  vmovaps [rsp+0x50], xmm5
000079bd661d83dd  vmovaps [rsp+0x60], xmm7
000079bd661d83e3  vmovaps [rsp+0x70], xmm8
000079bd661d83e9  vmovaps [rsp+0x80], xmm9
000079bd661d83f2  vmovaps [rsp+0x90], xmm10
000079bd661d83fb  vmovaps [rsp+0xA0], xmm11
000079bd661d8404  vmovaps [rsp+0xB0], xmm12
000079bd661d840d  vmovaps [rsp+0xC0], xmm13
000079bd661d8416  vmovaps [rsp+0xD0], xmm14
000079bd661d841f  vmovaps [rsp+0xE0], xmm15
000079bd661d8428  sub rsp, 0x30
000079bd661d842c  movaps [rsp], xmm6
000079bd661d8430  movaps [rsp+0x10], xmm9
000079bd661d8436  movaps [rsp+0x20], xmm1
000079bd661d843b  lea rdi, [rsp]
000079bd661d843f  mov esi, 0x00
000079bd661d8444  mov rax, 0x56EBD57B0530
000079bd661d844e  call rax
000079bd661d8450  movaps xmm6, [rsp]
000079bd661d8454  add rsp, 0x30
000079bd661d8458  vmovaps xmm0, [rsp]
000079bd661d845d  vmovaps xmm1, [rsp+0x10]
000079bd661d8463  vmovaps xmm2, [rsp+0x20]
000079bd661d8469  vmovaps xmm3, [rsp+0x30]
000079bd661d846f  vmovaps xmm4, [rsp+0x40]
000079bd661d8475  vmovaps xmm5, [rsp+0x50]
000079bd661d847b  vmovaps xmm7, [rsp+0x60]
000079bd661d8481  vmovaps xmm8, [rsp+0x70]
000079bd661d8487  vmovaps xmm9, [rsp+0x80]
000079bd661d8490  vmovaps xmm10, [rsp+0x90]
000079bd661d8499  vmovaps xmm11, [rsp+0xA0]
000079bd661d84a2  vmovaps xmm12, [rsp+0xB0]
000079bd661d84ab  vmovaps xmm13, [rsp+0xC0]
000079bd661d84b4  vmovaps xmm14, [rsp+0xD0]
000079bd661d84bd  vmovaps xmm15, [rsp+0xE0]
000079bd661d84c6  add rsp, 0xF0
000079bd661d84cd  pop r11
000079bd661d84cf  pop r10
000079bd661d84d1  pop r9
000079bd661d84d3  pop r8
000079bd661d84d5  pop rsi
000079bd661d84d6  pop rdi
000079bd661d84d7  pop rdx
000079bd661d84d8  pop rcx
000079bd661d84d9  pop rax
000079bd661d84da  add rsp, 0x08
000079bd661d84de  jmp 0x000079BD661D5FAB
000079bd661d84e3  sub rsp, 0x08
000079bd661d84e7  push rax
000079bd661d84e8  push rcx
000079bd661d84e9  push rdx
000079bd661d84ea  push rdi
000079bd661d84eb  push rsi
000079bd661d84ec  push r8
000079bd661d84ee  push r9
000079bd661d84f0  push r10
000079bd661d84f2  push r11
000079bd661d84f4  sub rsp, 0xF0
000079bd661d84fb  vmovaps [rsp], xmm0
000079bd661d8500  vmovaps [rsp+0x10], xmm1
000079bd661d8506  vmovaps [rsp+0x20], xmm2
000079bd661d850c  vmovaps [rsp+0x30], xmm3
000079bd661d8512  vmovaps [rsp+0x40], xmm4
000079bd661d8518  vmovaps [rsp+0x50], xmm5
000079bd661d851e  vmovaps [rsp+0x60], xmm6
000079bd661d8524  vmovaps [rsp+0x70], xmm7
000079bd661d852a  vmovaps [rsp+0x80], xmm8
000079bd661d8533  vmovaps [rsp+0x90], xmm10
000079bd661d853c  vmovaps [rsp+0xA0], xmm11
000079bd661d8545  vmovaps [rsp+0xB0], xmm12
000079bd661d854e  vmovaps [rsp+0xC0], xmm13
000079bd661d8557  vmovaps [rsp+0xD0], xmm14
000079bd661d8560  vmovaps [rsp+0xE0], xmm15
000079bd661d8569  sub rsp, 0x30
000079bd661d856d  movaps [rsp], xmm9
000079bd661d8572  movaps [rsp+0x10], xmm3
000079bd661d8577  movaps [rsp+0x20], xmm1
000079bd661d857c  lea rdi, [rsp]
000079bd661d8580  mov esi, 0x00
000079bd661d8585  mov rax, 0x56EBD57B0530
000079bd661d858f  call rax
000079bd661d8591  movaps xmm9, [rsp]
000079bd661d8596  add rsp, 0x30
000079bd661d859a  vmovaps xmm0, [rsp]
000079bd661d859f  vmovaps xmm1, [rsp+0x10]
000079bd661d85a5  vmovaps xmm2, [rsp+0x20]
000079bd661d85ab  vmovaps xmm3, [rsp+0x30]
000079bd661d85b1  vmovaps xmm4, [rsp+0x40]
000079bd661d85b7  vmovaps xmm5, [rsp+0x50]
000079bd661d85bd  vmovaps xmm6, [rsp+0x60]
000079bd661d85c3  vmovaps xmm7, [rsp+0x70]
000079bd661d85c9  vmovaps xmm8, [rsp+0x80]
000079bd661d85d2  vmovaps xmm10, [rsp+0x90]
000079bd661d85db  vmovaps xmm11, [rsp+0xA0]
000079bd661d85e4  vmovaps xmm12, [rsp+0xB0]
000079bd661d85ed  vmovaps xmm13, [rsp+0xC0]
000079bd661d85f6  vmovaps xmm14, [rsp+0xD0]
000079bd661d85ff  vmovaps xmm15, [rsp+0xE0]
000079bd661d8608  add rsp, 0xF0
000079bd661d860f  pop r11
000079bd661d8611  pop r10
000079bd661d8613  pop r9
000079bd661d8615  pop r8
000079bd661d8617  pop rsi
000079bd661d8618  pop rdi
000079bd661d8619  pop rdx
000079bd661d861a  pop rcx
000079bd661d861b  pop rax
000079bd661d861c  add rsp, 0x08
000079bd661d8620  jmp 0x000079BD661D5FF7
000079bd661d8625  call 0x000079BD660D64F0
000079bd661d862a  jmp 0x000079BD661D6004
000079bd661d862f  sub rsp, 0x08
000079bd661d8633  push rax
000079bd661d8634  push rcx
000079bd661d8635  push rdx
000079bd661d8636  push rdi
000079bd661d8637  push rsi
000079bd661d8638  push r8
000079bd661d863a  push r9
000079bd661d863c  push r10
000079bd661d863e  push r11
000079bd661d8640  sub rsp, 0xF0
000079bd661d8647  vmovaps [rsp], xmm0
000079bd661d864c  vmovaps [rsp+0x10], xmm1
000079bd661d8652  vmovaps [rsp+0x20], xmm2
000079bd661d8658  vmovaps [rsp+0x30], xmm3
000079bd661d865e  vmovaps [rsp+0x40], xmm4
000079bd661d8664  vmovaps [rsp+0x50], xmm5
000079bd661d866a  vmovaps [rsp+0x60], xmm6
000079bd661d8670  vmovaps [rsp+0x70], xmm7
000079bd661d8676  vmovaps [rsp+0x80], xmm8
000079bd661d867f  vmovaps [rsp+0x90], xmm9
000079bd661d8688  vmovaps [rsp+0xA0], xmm10
000079bd661d8691  vmovaps [rsp+0xB0], xmm11
000079bd661d869a  vmovaps [rsp+0xC0], xmm12
000079bd661d86a3  vmovaps [rsp+0xD0], xmm13
000079bd661d86ac  vmovaps [rsp+0xE0], xmm14
000079bd661d86b5  sub rsp, 0x30
000079bd661d86b9  movaps [rsp], xmm15
000079bd661d86be  movaps [rsp+0x10], xmm3
000079bd661d86c3  movaps [rsp+0x20], xmm7
000079bd661d86c8  lea rdi, [rsp]
000079bd661d86cc  mov esi, 0x00
000079bd661d86d1  mov rax, 0x56EBD57B0530
000079bd661d86db  call rax
000079bd661d86dd  movaps xmm15, [rsp]
000079bd661d86e2  add rsp, 0x30
000079bd661d86e6  vmovaps xmm0, [rsp]
000079bd661d86eb  vmovaps xmm1, [rsp+0x10]
000079bd661d86f1  vmovaps xmm2, [rsp+0x20]
000079bd661d86f7  vmovaps xmm3, [rsp+0x30]
000079bd661d86fd  vmovaps xmm4, [rsp+0x40]
000079bd661d8703  vmovaps xmm5, [rsp+0x50]
000079bd661d8709  vmovaps xmm6, [rsp+0x60]
000079bd661d870f  vmovaps xmm7, [rsp+0x70]
000079bd661d8715  vmovaps xmm8, [rsp+0x80]
000079bd661d871e  vmovaps xmm9, [rsp+0x90]
000079bd661d8727  vmovaps xmm10, [rsp+0xA0]
000079bd661d8730  vmovaps xmm11, [rsp+0xB0]
000079bd661d8739  vmovaps xmm12, [rsp+0xC0]
000079bd661d8742  vmovaps xmm13, [rsp+0xD0]
000079bd661d874b  vmovaps xmm14, [rsp+0xE0]
000079bd661d8754  add rsp, 0xF0
000079bd661d875b  pop r11
000079bd661d875d  pop r10
000079bd661d875f  pop r9
000079bd661d8761  pop r8
000079bd661d8763  pop rsi
000079bd661d8764  pop rdi
000079bd661d8765  pop rdx
000079bd661d8766  pop rcx
000079bd661d8767  pop rax
000079bd661d8768  add rsp, 0x08
000079bd661d876c  jmp 0x000079BD661D6030
000079bd661d8771  sub rsp, 0x08
000079bd661d8775  push rax
000079bd661d8776  push rcx
000079bd661d8777  push rdx
000079bd661d8778  push rdi
000079bd661d8779  push rsi
000079bd661d877a  push r8
000079bd661d877c  push r9
000079bd661d877e  push r10
000079bd661d8780  push r11
000079bd661d8782  sub rsp, 0xF0
000079bd661d8789  vmovaps [rsp], xmm0
000079bd661d878e  vmovaps [rsp+0x10], xmm1
000079bd661d8794  vmovaps [rsp+0x20], xmm2
000079bd661d879a  vmovaps [rsp+0x30], xmm4
000079bd661d87a0  vmovaps [rsp+0x40], xmm5
000079bd661d87a6  vmovaps [rsp+0x50], xmm6
000079bd661d87ac  vmovaps [rsp+0x60], xmm7
000079bd661d87b2  vmovaps [rsp+0x70], xmm8
000079bd661d87b8  vmovaps [rsp+0x80], xmm9
000079bd661d87c1  vmovaps [rsp+0x90], xmm10
000079bd661d87ca  vmovaps [rsp+0xA0], xmm11
000079bd661d87d3  vmovaps [rsp+0xB0], xmm12
000079bd661d87dc  vmovaps [rsp+0xC0], xmm13
000079bd661d87e5  vmovaps [rsp+0xD0], xmm14
000079bd661d87ee  vmovaps [rsp+0xE0], xmm15
000079bd661d87f7  sub rsp, 0x30
000079bd661d87fb  movaps [rsp], xmm3
000079bd661d87ff  movaps [rsp+0x10], xmm1
000079bd661d8804  movaps [rsp+0x20], xmm15
000079bd661d880a  lea rdi, [rsp]
000079bd661d880e  mov esi, 0x00
000079bd661d8813  mov rax, 0x56EBD57B0530
000079bd661d881d  call rax
000079bd661d881f  movaps xmm3, [rsp]
000079bd661d8823  add rsp, 0x30
000079bd661d8827  vmovaps xmm0, [rsp]
000079bd661d882c  vmovaps xmm1, [rsp+0x10]
000079bd661d8832  vmovaps xmm2, [rsp+0x20]
000079bd661d8838  vmovaps xmm4, [rsp+0x30]
000079bd661d883e  vmovaps xmm5, [rsp+0x40]
000079bd661d8844  vmovaps xmm6, [rsp+0x50]
000079bd661d884a  vmovaps xmm7, [rsp+0x60]
000079bd661d8850  vmovaps xmm8, [rsp+0x70]
000079bd661d8856  vmovaps xmm9, [rsp+0x80]
000079bd661d885f  vmovaps xmm10, [rsp+0x90]
000079bd661d8868  vmovaps xmm11, [rsp+0xA0]
000079bd661d8871  vmovaps xmm12, [rsp+0xB0]
000079bd661d887a  vmovaps xmm13, [rsp+0xC0]
000079bd661d8883  vmovaps xmm14, [rsp+0xD0]
000079bd661d888c  vmovaps xmm15, [rsp+0xE0]
000079bd661d8895  add rsp, 0xF0
000079bd661d889c  pop r11
000079bd661d889e  pop r10
000079bd661d88a0  pop r9
000079bd661d88a2  pop r8
000079bd661d88a4  pop rsi
000079bd661d88a5  pop rdi
000079bd661d88a6  pop rdx
000079bd661d88a7  pop rcx
000079bd661d88a8  pop rax
000079bd661d88a9  add rsp, 0x08
000079bd661d88ad  jmp 0x000079BD661D60BF
000079bd661d88b2  call 0x000079BD660D64F0
000079bd661d88b7  jmp 0x000079BD661D60C9
000079bd661d88bc  sub rsp, 0x08
000079bd661d88c0  push rax
000079bd661d88c1  push rcx
000079bd661d88c2  push rdx
000079bd661d88c3  push rdi
000079bd661d88c4  push rsi
000079bd661d88c5  push r8
000079bd661d88c7  push r9
000079bd661d88c9  push r10
000079bd661d88cb  push r11
000079bd661d88cd  sub rsp, 0xF0
000079bd661d88d4  vmovaps [rsp], xmm0
000079bd661d88d9  vmovaps [rsp+0x10], xmm1
000079bd661d88df  vmovaps [rsp+0x20], xmm2
000079bd661d88e5  vmovaps [rsp+0x30], xmm3
000079bd661d88eb  vmovaps [rsp+0x40], xmm4
000079bd661d88f1  vmovaps [rsp+0x50], xmm5
000079bd661d88f7  vmovaps [rsp+0x60], xmm6
000079bd661d88fd  vmovaps [rsp+0x70], xmm7
000079bd661d8903  vmovaps [rsp+0x80], xmm8
000079bd661d890c  vmovaps [rsp+0x90], xmm9
000079bd661d8915  vmovaps [rsp+0xA0], xmm10
000079bd661d891e  vmovaps [rsp+0xB0], xmm11
000079bd661d8927  vmovaps [rsp+0xC0], xmm12
000079bd661d8930  vmovaps [rsp+0xD0], xmm13
000079bd661d8939  vmovaps [rsp+0xE0], xmm14
000079bd661d8942  sub rsp, 0x30
000079bd661d8946  movaps [rsp], xmm15
000079bd661d894b  movaps [rsp+0x10], xmm14
000079bd661d8951  movaps [rsp+0x20], xmm4
000079bd661d8956  lea rdi, [rsp]
000079bd661d895a  mov esi, 0x00
000079bd661d895f  mov rax, 0x56EBD57B0530
000079bd661d8969  call rax
000079bd661d896b  movaps xmm15, [rsp]
000079bd661d8970  add rsp, 0x30
000079bd661d8974  vmovaps xmm0, [rsp]
000079bd661d8979  vmovaps xmm1, [rsp+0x10]
000079bd661d897f  vmovaps xmm2, [rsp+0x20]
000079bd661d8985  vmovaps xmm3, [rsp+0x30]
000079bd661d898b  vmovaps xmm4, [rsp+0x40]
000079bd661d8991  vmovaps xmm5, [rsp+0x50]
000079bd661d8997  vmovaps xmm6, [rsp+0x60]
000079bd661d899d  vmovaps xmm7, [rsp+0x70]
000079bd661d89a3  vmovaps xmm8, [rsp+0x80]
000079bd661d89ac  vmovaps xmm9, [rsp+0x90]
000079bd661d89b5  vmovaps xmm10, [rsp+0xA0]
000079bd661d89be  vmovaps xmm11, [rsp+0xB0]
000079bd661d89c7  vmovaps xmm12, [rsp+0xC0]
000079bd661d89d0  vmovaps xmm13, [rsp+0xD0]
000079bd661d89d9  vmovaps xmm14, [rsp+0xE0]
000079bd661d89e2  add rsp, 0xF0
000079bd661d89e9  pop r11
000079bd661d89eb  pop r10
000079bd661d89ed  pop r9
000079bd661d89ef  pop r8
000079bd661d89f1  pop rsi
000079bd661d89f2  pop rdi
000079bd661d89f3  pop rdx
000079bd661d89f4  pop rcx
000079bd661d89f5  pop rax
000079bd661d89f6  add rsp, 0x08
000079bd661d89fa  jmp 0x000079BD661D60F7
000079bd661d89ff  sub rsp, 0x08
000079bd661d8a03  push rax
000079bd661d8a04  push rcx
000079bd661d8a05  push rdx
000079bd661d8a06  push rdi
000079bd661d8a07  push rsi
000079bd661d8a08  push r8
000079bd661d8a0a  push r9
000079bd661d8a0c  push r10
000079bd661d8a0e  push r11
000079bd661d8a10  sub rsp, 0xF0
000079bd661d8a17  vmovaps [rsp], xmm0
000079bd661d8a1c  vmovaps [rsp+0x10], xmm1
000079bd661d8a22  vmovaps [rsp+0x20], xmm2
000079bd661d8a28  vmovaps [rsp+0x30], xmm3
000079bd661d8a2e  vmovaps [rsp+0x40], xmm4
000079bd661d8a34  vmovaps [rsp+0x50], xmm5
000079bd661d8a3a  vmovaps [rsp+0x60], xmm6
000079bd661d8a40  vmovaps [rsp+0x70], xmm7
000079bd661d8a46  vmovaps [rsp+0x80], xmm8
000079bd661d8a4f  vmovaps [rsp+0x90], xmm9
000079bd661d8a58  vmovaps [rsp+0xA0], xmm10
000079bd661d8a61  vmovaps [rsp+0xB0], xmm11
000079bd661d8a6a  vmovaps [rsp+0xC0], xmm12
000079bd661d8a73  vmovaps [rsp+0xD0], xmm13
000079bd661d8a7c  vmovaps [rsp+0xE0], xmm15
000079bd661d8a85  sub rsp, 0x30
000079bd661d8a89  movaps [rsp], xmm14
000079bd661d8a8e  movaps [rsp+0x10], xmm2
000079bd661d8a93  movaps [rsp+0x20], xmm1
000079bd661d8a98  lea rdi, [rsp]
000079bd661d8a9c  mov esi, 0x00
000079bd661d8aa1  mov rax, 0x56EBD57B0530
000079bd661d8aab  call rax
000079bd661d8aad  movaps xmm14, [rsp]
000079bd661d8ab2  add rsp, 0x30
000079bd661d8ab6  vmovaps xmm0, [rsp]
000079bd661d8abb  vmovaps xmm1, [rsp+0x10]
000079bd661d8ac1  vmovaps xmm2, [rsp+0x20]
000079bd661d8ac7  vmovaps xmm3, [rsp+0x30]
000079bd661d8acd  vmovaps xmm4, [rsp+0x40]
000079bd661d8ad3  vmovaps xmm5, [rsp+0x50]
000079bd661d8ad9  vmovaps xmm6, [rsp+0x60]
000079bd661d8adf  vmovaps xmm7, [rsp+0x70]
000079bd661d8ae5  vmovaps xmm8, [rsp+0x80]
000079bd661d8aee  vmovaps xmm9, [rsp+0x90]
000079bd661d8af7  vmovaps xmm10, [rsp+0xA0]
000079bd661d8b00  vmovaps xmm11, [rsp+0xB0]
000079bd661d8b09  vmovaps xmm12, [rsp+0xC0]
000079bd661d8b12  vmovaps xmm13, [rsp+0xD0]
000079bd661d8b1b  vmovaps xmm15, [rsp+0xE0]
000079bd661d8b24  add rsp, 0xF0
000079bd661d8b2b  pop r11
000079bd661d8b2d  pop r10
000079bd661d8b2f  pop r9
000079bd661d8b31  pop r8
000079bd661d8b33  pop rsi
000079bd661d8b34  pop rdi
000079bd661d8b35  pop rdx
000079bd661d8b36  pop rcx
000079bd661d8b37  pop rax
000079bd661d8b38  add rsp, 0x08
000079bd661d8b3c  jmp 0x000079BD661D611D
000079bd661d8b41  sub rsp, 0x08
000079bd661d8b45  push rax
000079bd661d8b46  push rcx
000079bd661d8b47  push rdx
000079bd661d8b48  push rdi
000079bd661d8b49  push rsi
000079bd661d8b4a  push r8
000079bd661d8b4c  push r9
000079bd661d8b4e  push r10
000079bd661d8b50  push r11
000079bd661d8b52  sub rsp, 0xF0
000079bd661d8b59  vmovaps [rsp], xmm0
000079bd661d8b5e  vmovaps [rsp+0x10], xmm2
000079bd661d8b64  vmovaps [rsp+0x20], xmm3
000079bd661d8b6a  vmovaps [rsp+0x30], xmm4
000079bd661d8b70  vmovaps [rsp+0x40], xmm5
000079bd661d8b76  vmovaps [rsp+0x50], xmm6
000079bd661d8b7c  vmovaps [rsp+0x60], xmm7
000079bd661d8b82  vmovaps [rsp+0x70], xmm8
000079bd661d8b88  vmovaps [rsp+0x80], xmm9
000079bd661d8b91  vmovaps [rsp+0x90], xmm10
000079bd661d8b9a  vmovaps [rsp+0xA0], xmm11
000079bd661d8ba3  vmovaps [rsp+0xB0], xmm12
000079bd661d8bac  vmovaps [rsp+0xC0], xmm13
000079bd661d8bb5  vmovaps [rsp+0xD0], xmm14
000079bd661d8bbe  vmovaps [rsp+0xE0], xmm15
000079bd661d8bc7  sub rsp, 0x30
000079bd661d8bcb  movaps [rsp], xmm1
000079bd661d8bcf  movaps [rsp+0x10], xmm4
000079bd661d8bd4  movaps [rsp+0x20], xmm9
000079bd661d8bda  lea rdi, [rsp]
000079bd661d8bde  mov esi, 0x00
000079bd661d8be3  mov rax, 0x56EBD57B0530
000079bd661d8bed  call rax
000079bd661d8bef  movaps xmm1, [rsp]
000079bd661d8bf3  add rsp, 0x30
000079bd661d8bf7  vmovaps xmm0, [rsp]
000079bd661d8bfc  vmovaps xmm2, [rsp+0x10]
000079bd661d8c02  vmovaps xmm3, [rsp+0x20]
000079bd661d8c08  vmovaps xmm4, [rsp+0x30]
000079bd661d8c0e  vmovaps xmm5, [rsp+0x40]
000079bd661d8c14  vmovaps xmm6, [rsp+0x50]
000079bd661d8c1a  vmovaps xmm7, [rsp+0x60]
000079bd661d8c20  vmovaps xmm8, [rsp+0x70]
000079bd661d8c26  vmovaps xmm9, [rsp+0x80]
000079bd661d8c2f  vmovaps xmm10, [rsp+0x90]
000079bd661d8c38  vmovaps xmm11, [rsp+0xA0]
000079bd661d8c41  vmovaps xmm12, [rsp+0xB0]
000079bd661d8c4a  vmovaps xmm13, [rsp+0xC0]
000079bd661d8c53  vmovaps xmm14, [rsp+0xD0]
000079bd661d8c5c  vmovaps xmm15, [rsp+0xE0]
000079bd661d8c65  add rsp, 0xF0
000079bd661d8c6c  pop r11
000079bd661d8c6e  pop r10
000079bd661d8c70  pop r9
000079bd661d8c72  pop r8
000079bd661d8c74  pop rsi
000079bd661d8c75  pop rdi
000079bd661d8c76  pop rdx
000079bd661d8c77  pop rcx
000079bd661d8c78  pop rax
000079bd661d8c79  add rsp, 0x08
000079bd661d8c7d  jmp 0x000079BD661D613B
000079bd661d8c82  sub rsp, 0x08
000079bd661d8c86  push rax
000079bd661d8c87  push rcx
000079bd661d8c88  push rdx
000079bd661d8c89  push rdi
000079bd661d8c8a  push rsi
000079bd661d8c8b  push r8
000079bd661d8c8d  push r9
000079bd661d8c8f  push r10
000079bd661d8c91  push r11
000079bd661d8c93  sub rsp, 0xF0
000079bd661d8c9a  vmovaps [rsp], xmm0
000079bd661d8c9f  vmovaps [rsp+0x10], xmm1
000079bd661d8ca5  vmovaps [rsp+0x20], xmm2
000079bd661d8cab  vmovaps [rsp+0x30], xmm3
000079bd661d8cb1  vmovaps [rsp+0x40], xmm5
000079bd661d8cb7  vmovaps [rsp+0x50], xmm6
000079bd661d8cbd  vmovaps [rsp+0x60], xmm7
000079bd661d8cc3  vmovaps [rsp+0x70], xmm8
000079bd661d8cc9  vmovaps [rsp+0x80], xmm9
000079bd661d8cd2  vmovaps [rsp+0x90], xmm10
000079bd661d8cdb  vmovaps [rsp+0xA0], xmm11
000079bd661d8ce4  vmovaps [rsp+0xB0], xmm12
000079bd661d8ced  vmovaps [rsp+0xC0], xmm13
000079bd661d8cf6  vmovaps [rsp+0xD0], xmm14
000079bd661d8cff  vmovaps [rsp+0xE0], xmm15
000079bd661d8d08  sub rsp, 0x30
000079bd661d8d0c  movaps [rsp], xmm4
000079bd661d8d10  movaps [rsp+0x10], xmm2
000079bd661d8d15  movaps [rsp+0x20], xmm9
000079bd661d8d1b  lea rdi, [rsp]
000079bd661d8d1f  mov esi, 0x00
000079bd661d8d24  mov rax, 0x56EBD57B0530
000079bd661d8d2e  call rax
000079bd661d8d30  movaps xmm4, [rsp]
000079bd661d8d34  add rsp, 0x30
000079bd661d8d38  vmovaps xmm0, [rsp]
000079bd661d8d3d  vmovaps xmm1, [rsp+0x10]
000079bd661d8d43  vmovaps xmm2, [rsp+0x20]
000079bd661d8d49  vmovaps xmm3, [rsp+0x30]
000079bd661d8d4f  vmovaps xmm5, [rsp+0x40]
000079bd661d8d55  vmovaps xmm6, [rsp+0x50]
000079bd661d8d5b  vmovaps xmm7, [rsp+0x60]
000079bd661d8d61  vmovaps xmm8, [rsp+0x70]
000079bd661d8d67  vmovaps xmm9, [rsp+0x80]
000079bd661d8d70  vmovaps xmm10, [rsp+0x90]
000079bd661d8d79  vmovaps xmm11, [rsp+0xA0]
000079bd661d8d82  vmovaps xmm12, [rsp+0xB0]
000079bd661d8d8b  vmovaps xmm13, [rsp+0xC0]
000079bd661d8d94  vmovaps xmm14, [rsp+0xD0]
000079bd661d8d9d  vmovaps xmm15, [rsp+0xE0]
000079bd661d8da6  add rsp, 0xF0
000079bd661d8dad  pop r11
000079bd661d8daf  pop r10
000079bd661d8db1  pop r9
000079bd661d8db3  pop r8
000079bd661d8db5  pop rsi
000079bd661d8db6  pop rdi
000079bd661d8db7  pop rdx
000079bd661d8db8  pop rcx
000079bd661d8db9  pop rax
000079bd661d8dba  add rsp, 0x08
000079bd661d8dbe  jmp 0x000079BD661D616B
000079bd661d8dc3  sub rsp, 0x08
000079bd661d8dc7  push rax
000079bd661d8dc8  push rcx
000079bd661d8dc9  push rdx
000079bd661d8dca  push rdi
000079bd661d8dcb  push rsi
000079bd661d8dcc  push r8
000079bd661d8dce  push r9
000079bd661d8dd0  push r10
000079bd661d8dd2  push r11
000079bd661d8dd4  sub rsp, 0xF0
000079bd661d8ddb  vmovaps [rsp], xmm0
000079bd661d8de0  vmovaps [rsp+0x10], xmm1
000079bd661d8de6  vmovaps [rsp+0x20], xmm2
000079bd661d8dec  vmovaps [rsp+0x30], xmm3
000079bd661d8df2  vmovaps [rsp+0x40], xmm4
000079bd661d8df8  vmovaps [rsp+0x50], xmm5
000079bd661d8dfe  vmovaps [rsp+0x60], xmm6
000079bd661d8e04  vmovaps [rsp+0x70], xmm7
000079bd661d8e0a  vmovaps [rsp+0x80], xmm8
000079bd661d8e13  vmovaps [rsp+0x90], xmm10
000079bd661d8e1c  vmovaps [rsp+0xA0], xmm11
000079bd661d8e25  vmovaps [rsp+0xB0], xmm12
000079bd661d8e2e  vmovaps [rsp+0xC0], xmm13
000079bd661d8e37  vmovaps [rsp+0xD0], xmm14
000079bd661d8e40  vmovaps [rsp+0xE0], xmm15
000079bd661d8e49  sub rsp, 0x30
000079bd661d8e4d  movaps [rsp], xmm9
000079bd661d8e52  movaps [rsp+0x10], xmm2
000079bd661d8e57  movaps [rsp+0x20], xmm1
000079bd661d8e5c  lea rdi, [rsp]
000079bd661d8e60  mov esi, 0x00
000079bd661d8e65  mov rax, 0x56EBD57B0530
000079bd661d8e6f  call rax
000079bd661d8e71  movaps xmm9, [rsp]
000079bd661d8e76  add rsp, 0x30
000079bd661d8e7a  vmovaps xmm0, [rsp]
000079bd661d8e7f  vmovaps xmm1, [rsp+0x10]
000079bd661d8e85  vmovaps xmm2, [rsp+0x20]
000079bd661d8e8b  vmovaps xmm3, [rsp+0x30]
000079bd661d8e91  vmovaps xmm4, [rsp+0x40]
000079bd661d8e97  vmovaps xmm5, [rsp+0x50]
000079bd661d8e9d  vmovaps xmm6, [rsp+0x60]
000079bd661d8ea3  vmovaps xmm7, [rsp+0x70]
000079bd661d8ea9  vmovaps xmm8, [rsp+0x80]
000079bd661d8eb2  vmovaps xmm10, [rsp+0x90]
000079bd661d8ebb  vmovaps xmm11, [rsp+0xA0]
000079bd661d8ec4  vmovaps xmm12, [rsp+0xB0]
000079bd661d8ecd  vmovaps xmm13, [rsp+0xC0]
000079bd661d8ed6  vmovaps xmm14, [rsp+0xD0]
000079bd661d8edf  vmovaps xmm15, [rsp+0xE0]
000079bd661d8ee8  add rsp, 0xF0
000079bd661d8eef  pop r11
000079bd661d8ef1  pop r10
000079bd661d8ef3  pop r9
000079bd661d8ef5  pop r8
000079bd661d8ef7  pop rsi
000079bd661d8ef8  pop rdi
000079bd661d8ef9  pop rdx
000079bd661d8efa  pop rcx
000079bd661d8efb  pop rax
000079bd661d8efc  add rsp, 0x08
000079bd661d8f00  jmp 0x000079BD661D61A1
000079bd661d8f05  sub rsp, 0x08
000079bd661d8f09  push rax
000079bd661d8f0a  push rcx
000079bd661d8f0b  push rdx
000079bd661d8f0c  push rdi
000079bd661d8f0d  push rsi
000079bd661d8f0e  push r8
000079bd661d8f10  push r9
000079bd661d8f12  push r10
000079bd661d8f14  push r11
000079bd661d8f16  sub rsp, 0xF0
000079bd661d8f1d  vmovaps [rsp], xmm0
000079bd661d8f22  vmovaps [rsp+0x10], xmm2
000079bd661d8f28  vmovaps [rsp+0x20], xmm3
000079bd661d8f2e  vmovaps [rsp+0x30], xmm4
000079bd661d8f34  vmovaps [rsp+0x40], xmm5
000079bd661d8f3a  vmovaps [rsp+0x50], xmm6
000079bd661d8f40  vmovaps [rsp+0x60], xmm7
000079bd661d8f46  vmovaps [rsp+0x70], xmm8
000079bd661d8f4c  vmovaps [rsp+0x80], xmm9
000079bd661d8f55  vmovaps [rsp+0x90], xmm10
000079bd661d8f5e  vmovaps [rsp+0xA0], xmm11
000079bd661d8f67  vmovaps [rsp+0xB0], xmm12
000079bd661d8f70  vmovaps [rsp+0xC0], xmm13
000079bd661d8f79  vmovaps [rsp+0xD0], xmm14
000079bd661d8f82  vmovaps [rsp+0xE0], xmm15
000079bd661d8f8b  sub rsp, 0x30
000079bd661d8f8f  movaps [rsp], xmm1
000079bd661d8f93  movaps [rsp+0x10], xmm15
000079bd661d8f99  movaps [rsp+0x20], xmm6
000079bd661d8f9e  lea rdi, [rsp]
000079bd661d8fa2  mov esi, 0x00
000079bd661d8fa7  mov rax, 0x56EBD57B0530
000079bd661d8fb1  call rax
000079bd661d8fb3  movaps xmm1, [rsp]
000079bd661d8fb7  add rsp, 0x30
000079bd661d8fbb  vmovaps xmm0, [rsp]
000079bd661d8fc0  vmovaps xmm2, [rsp+0x10]
000079bd661d8fc6  vmovaps xmm3, [rsp+0x20]
000079bd661d8fcc  vmovaps xmm4, [rsp+0x30]
000079bd661d8fd2  vmovaps xmm5, [rsp+0x40]
000079bd661d8fd8  vmovaps xmm6, [rsp+0x50]
000079bd661d8fde  vmovaps xmm7, [rsp+0x60]
000079bd661d8fe4  vmovaps xmm8, [rsp+0x70]
000079bd661d8fea  vmovaps xmm9, [rsp+0x80]
000079bd661d8ff3  vmovaps xmm10, [rsp+0x90]
000079bd661d8ffc  vmovaps xmm11, [rsp+0xA0]
000079bd661d9005  vmovaps xmm12, [rsp+0xB0]
000079bd661d900e  vmovaps xmm13, [rsp+0xC0]
000079bd661d9017  vmovaps xmm14, [rsp+0xD0]
000079bd661d9020  vmovaps xmm15, [rsp+0xE0]
000079bd661d9029  add rsp, 0xF0
000079bd661d9030  pop r11
000079bd661d9032  pop r10
000079bd661d9034  pop r9
000079bd661d9036  pop r8
000079bd661d9038  pop rsi
000079bd661d9039  pop rdi
000079bd661d903a  pop rdx
000079bd661d903b  pop rcx
000079bd661d903c  pop rax
000079bd661d903d  add rsp, 0x08
000079bd661d9041  jmp 0x000079BD661D61C2
000079bd661d9046  sub rsp, 0x08
000079bd661d904a  push rax
000079bd661d904b  push rcx
000079bd661d904c  push rdx
000079bd661d904d  push rdi
000079bd661d904e  push rsi
000079bd661d904f  push r8
000079bd661d9051  push r9
000079bd661d9053  push r10
000079bd661d9055  push r11
000079bd661d9057  sub rsp, 0xF0
000079bd661d905e  vmovaps [rsp], xmm0
000079bd661d9063  vmovaps [rsp+0x10], xmm1
000079bd661d9069  vmovaps [rsp+0x20], xmm2
000079bd661d906f  vmovaps [rsp+0x30], xmm3
000079bd661d9075  vmovaps [rsp+0x40], xmm4
000079bd661d907b  vmovaps [rsp+0x50], xmm5
000079bd661d9081  vmovaps [rsp+0x60], xmm6
000079bd661d9087  vmovaps [rsp+0x70], xmm7
000079bd661d908d  vmovaps [rsp+0x80], xmm8
000079bd661d9096  vmovaps [rsp+0x90], xmm9
000079bd661d909f  vmovaps [rsp+0xA0], xmm10
000079bd661d90a8  vmovaps [rsp+0xB0], xmm11
000079bd661d90b1  vmovaps [rsp+0xC0], xmm12
000079bd661d90ba  vmovaps [rsp+0xD0], xmm13
000079bd661d90c3  vmovaps [rsp+0xE0], xmm14
000079bd661d90cc  sub rsp, 0x30
000079bd661d90d0  movaps [rsp], xmm15
000079bd661d90d5  movaps [rsp+0x10], xmm5
000079bd661d90da  movaps [rsp+0x20], xmm3
000079bd661d90df  lea rdi, [rsp]
000079bd661d90e3  mov esi, 0x00
000079bd661d90e8  mov rax, 0x56EBD57B0530
000079bd661d90f2  call rax
000079bd661d90f4  movaps xmm15, [rsp]
000079bd661d90f9  add rsp, 0x30
000079bd661d90fd  vmovaps xmm0, [rsp]
000079bd661d9102  vmovaps xmm1, [rsp+0x10]
000079bd661d9108  vmovaps xmm2, [rsp+0x20]
000079bd661d910e  vmovaps xmm3, [rsp+0x30]
000079bd661d9114  vmovaps xmm4, [rsp+0x40]
000079bd661d911a  vmovaps xmm5, [rsp+0x50]
000079bd661d9120  vmovaps xmm6, [rsp+0x60]
000079bd661d9126  vmovaps xmm7, [rsp+0x70]
000079bd661d912c  vmovaps xmm8, [rsp+0x80]
000079bd661d9135  vmovaps xmm9, [rsp+0x90]
000079bd661d913e  vmovaps xmm10, [rsp+0xA0]
000079bd661d9147  vmovaps xmm11, [rsp+0xB0]
000079bd661d9150  vmovaps xmm12, [rsp+0xC0]
000079bd661d9159  vmovaps xmm13, [rsp+0xD0]
000079bd661d9162  vmovaps xmm14, [rsp+0xE0]
000079bd661d916b  add rsp, 0xF0
000079bd661d9172  pop r11
000079bd661d9174  pop r10
000079bd661d9176  pop r9
000079bd661d9178  pop r8
000079bd661d917a  pop rsi
000079bd661d917b  pop rdi
000079bd661d917c  pop rdx
000079bd661d917d  pop rcx
000079bd661d917e  pop rax
000079bd661d917f  add rsp, 0x08
000079bd661d9183  jmp 0x000079BD661D61DC
000079bd661d9188  sub rsp, 0x08
000079bd661d918c  push rax
000079bd661d918d  push rcx
000079bd661d918e  push rdx
000079bd661d918f  push rdi
000079bd661d9190  push rsi
000079bd661d9191  push r8
000079bd661d9193  push r9
000079bd661d9195  push r10
000079bd661d9197  push r11
000079bd661d9199  sub rsp, 0xF0
000079bd661d91a0  vmovaps [rsp], xmm0
000079bd661d91a5  vmovaps [rsp+0x10], xmm1
000079bd661d91ab  vmovaps [rsp+0x20], xmm2
000079bd661d91b1  vmovaps [rsp+0x30], xmm3
000079bd661d91b7  vmovaps [rsp+0x40], xmm4
000079bd661d91bd  vmovaps [rsp+0x50], xmm6
000079bd661d91c3  vmovaps [rsp+0x60], xmm7
000079bd661d91c9  vmovaps [rsp+0x70], xmm8
000079bd661d91cf  vmovaps [rsp+0x80], xmm9
000079bd661d91d8  vmovaps [rsp+0x90], xmm10
000079bd661d91e1  vmovaps [rsp+0xA0], xmm11
000079bd661d91ea  vmovaps [rsp+0xB0], xmm12
000079bd661d91f3  vmovaps [rsp+0xC0], xmm13
000079bd661d91fc  vmovaps [rsp+0xD0], xmm14
000079bd661d9205  vmovaps [rsp+0xE0], xmm15
000079bd661d920e  sub rsp, 0x30
000079bd661d9212  movaps [rsp], xmm5
000079bd661d9216  movaps [rsp+0x10], xmm8
000079bd661d921c  movaps [rsp+0x20], xmm6
000079bd661d9221  lea rdi, [rsp]
000079bd661d9225  mov esi, 0x00
000079bd661d922a  mov rax, 0x56EBD57B0530
000079bd661d9234  call rax
000079bd661d9236  movaps xmm5, [rsp]
000079bd661d923a  add rsp, 0x30
000079bd661d923e  vmovaps xmm0, [rsp]
000079bd661d9243  vmovaps xmm1, [rsp+0x10]
000079bd661d9249  vmovaps xmm2, [rsp+0x20]
000079bd661d924f  vmovaps xmm3, [rsp+0x30]
000079bd661d9255  vmovaps xmm4, [rsp+0x40]
000079bd661d925b  vmovaps xmm6, [rsp+0x50]
000079bd661d9261  vmovaps xmm7, [rsp+0x60]
000079bd661d9267  vmovaps xmm8, [rsp+0x70]
000079bd661d926d  vmovaps xmm9, [rsp+0x80]
000079bd661d9276  vmovaps xmm10, [rsp+0x90]
000079bd661d927f  vmovaps xmm11, [rsp+0xA0]
000079bd661d9288  vmovaps xmm12, [rsp+0xB0]
000079bd661d9291  vmovaps xmm13, [rsp+0xC0]
000079bd661d929a  vmovaps xmm14, [rsp+0xD0]
000079bd661d92a3  vmovaps xmm15, [rsp+0xE0]
000079bd661d92ac  add rsp, 0xF0
000079bd661d92b3  pop r11
000079bd661d92b5  pop r10
000079bd661d92b7  pop r9
000079bd661d92b9  pop r8
000079bd661d92bb  pop rsi
000079bd661d92bc  pop rdi
000079bd661d92bd  pop rdx
000079bd661d92be  pop rcx
000079bd661d92bf  pop rax
000079bd661d92c0  add rsp, 0x08
000079bd661d92c4  jmp 0x000079BD661D6200
000079bd661d92c9  sub rsp, 0x08
000079bd661d92cd  push rax
000079bd661d92ce  push rcx
000079bd661d92cf  push rdx
000079bd661d92d0  push rdi
000079bd661d92d1  push rsi
000079bd661d92d2  push r8
000079bd661d92d4  push r9
000079bd661d92d6  push r10
000079bd661d92d8  push r11
000079bd661d92da  sub rsp, 0xF0
000079bd661d92e1  vmovaps [rsp], xmm0
000079bd661d92e6  vmovaps [rsp+0x10], xmm1
000079bd661d92ec  vmovaps [rsp+0x20], xmm2
000079bd661d92f2  vmovaps [rsp+0x30], xmm3
000079bd661d92f8  vmovaps [rsp+0x40], xmm4
000079bd661d92fe  vmovaps [rsp+0x50], xmm5
000079bd661d9304  vmovaps [rsp+0x60], xmm7
000079bd661d930a  vmovaps [rsp+0x70], xmm8
000079bd661d9310  vmovaps [rsp+0x80], xmm9
000079bd661d9319  vmovaps [rsp+0x90], xmm10
000079bd661d9322  vmovaps [rsp+0xA0], xmm11
000079bd661d932b  vmovaps [rsp+0xB0], xmm12
000079bd661d9334  vmovaps [rsp+0xC0], xmm13
000079bd661d933d  vmovaps [rsp+0xD0], xmm14
000079bd661d9346  vmovaps [rsp+0xE0], xmm15
000079bd661d934f  sub rsp, 0x30
000079bd661d9353  movaps [rsp], xmm6
000079bd661d9357  movaps [rsp+0x10], xmm10
000079bd661d935d  movaps [rsp+0x20], xmm8
000079bd661d9363  lea rdi, [rsp]
000079bd661d9367  mov esi, 0x00
000079bd661d936c  mov rax, 0x56EBD57B0530
000079bd661d9376  call rax
000079bd661d9378  movaps xmm6, [rsp]
000079bd661d937c  add rsp, 0x30
000079bd661d9380  vmovaps xmm0, [rsp]
000079bd661d9385  vmovaps xmm1, [rsp+0x10]
000079bd661d938b  vmovaps xmm2, [rsp+0x20]
000079bd661d9391  vmovaps xmm3, [rsp+0x30]
000079bd661d9397  vmovaps xmm4, [rsp+0x40]
000079bd661d939d  vmovaps xmm5, [rsp+0x50]
000079bd661d93a3  vmovaps xmm7, [rsp+0x60]
000079bd661d93a9  vmovaps xmm8, [rsp+0x70]
000079bd661d93af  vmovaps xmm9, [rsp+0x80]
000079bd661d93b8  vmovaps xmm10, [rsp+0x90]
000079bd661d93c1  vmovaps xmm11, [rsp+0xA0]
000079bd661d93ca  vmovaps xmm12, [rsp+0xB0]
000079bd661d93d3  vmovaps xmm13, [rsp+0xC0]
000079bd661d93dc  vmovaps xmm14, [rsp+0xD0]
000079bd661d93e5  vmovaps xmm15, [rsp+0xE0]
000079bd661d93ee  add rsp, 0xF0
000079bd661d93f5  pop r11
000079bd661d93f7  pop r10
000079bd661d93f9  pop r9
000079bd661d93fb  pop r8
000079bd661d93fd  pop rsi
000079bd661d93fe  pop rdi
000079bd661d93ff  pop rdx
000079bd661d9400  pop rcx
000079bd661d9401  pop rax
000079bd661d9402  add rsp, 0x08
000079bd661d9406  jmp 0x000079BD661D6225
000079bd661d940b  sub rsp, 0x08
000079bd661d940f  push rax
000079bd661d9410  push rcx
000079bd661d9411  push rdx
000079bd661d9412  push rdi
000079bd661d9413  push rsi
000079bd661d9414  push r8
000079bd661d9416  push r9
000079bd661d9418  push r10
000079bd661d941a  push r11
000079bd661d941c  sub rsp, 0xF0
000079bd661d9423  vmovaps [rsp], xmm0
000079bd661d9428  vmovaps [rsp+0x10], xmm1
000079bd661d942e  vmovaps [rsp+0x20], xmm2
000079bd661d9434  vmovaps [rsp+0x30], xmm3
000079bd661d943a  vmovaps [rsp+0x40], xmm4
000079bd661d9440  vmovaps [rsp+0x50], xmm5
000079bd661d9446  vmovaps [rsp+0x60], xmm6
000079bd661d944c  vmovaps [rsp+0x70], xmm7
000079bd661d9452  vmovaps [rsp+0x80], xmm8
000079bd661d945b  vmovaps [rsp+0x90], xmm9
000079bd661d9464  vmovaps [rsp+0xA0], xmm11
000079bd661d946d  vmovaps [rsp+0xB0], xmm12
000079bd661d9476  vmovaps [rsp+0xC0], xmm13
000079bd661d947f  vmovaps [rsp+0xD0], xmm14
000079bd661d9488  vmovaps [rsp+0xE0], xmm15
000079bd661d9491  sub rsp, 0x30
000079bd661d9495  movaps [rsp], xmm10
000079bd661d949a  movaps [rsp+0x10], xmm8
000079bd661d94a0  movaps [rsp+0x20], xmm14
000079bd661d94a6  lea rdi, [rsp]
000079bd661d94aa  mov esi, 0x00
000079bd661d94af  mov rax, 0x56EBD57B0530
000079bd661d94b9  call rax
000079bd661d94bb  movaps xmm10, [rsp]
000079bd661d94c0  add rsp, 0x30
000079bd661d94c4  vmovaps xmm0, [rsp]
000079bd661d94c9  vmovaps xmm1, [rsp+0x10]
000079bd661d94cf  vmovaps xmm2, [rsp+0x20]
000079bd661d94d5  vmovaps xmm3, [rsp+0x30]
000079bd661d94db  vmovaps xmm4, [rsp+0x40]
000079bd661d94e1  vmovaps xmm5, [rsp+0x50]
000079bd661d94e7  vmovaps xmm6, [rsp+0x60]
000079bd661d94ed  vmovaps xmm7, [rsp+0x70]
000079bd661d94f3  vmovaps xmm8, [rsp+0x80]
000079bd661d94fc  vmovaps xmm9, [rsp+0x90]
000079bd661d9505  vmovaps xmm11, [rsp+0xA0]
000079bd661d950e  vmovaps xmm12, [rsp+0xB0]
000079bd661d9517  vmovaps xmm13, [rsp+0xC0]
000079bd661d9520  vmovaps xmm14, [rsp+0xD0]
000079bd661d9529  vmovaps xmm15, [rsp+0xE0]
000079bd661d9532  add rsp, 0xF0
000079bd661d9539  pop r11
000079bd661d953b  pop r10
000079bd661d953d  pop r9
000079bd661d953f  pop r8
000079bd661d9541  pop rsi
000079bd661d9542  pop rdi
000079bd661d9543  pop rdx
000079bd661d9544  pop rcx
000079bd661d9545  pop rax
000079bd661d9546  add rsp, 0x08
000079bd661d954a  jmp 0x000079BD661D6245
000079bd661d954f  sub rsp, 0x08
000079bd661d9553  push rax
000079bd661d9554  push rcx
000079bd661d9555  push rdx
000079bd661d9556  push rdi
000079bd661d9557  push rsi
000079bd661d9558  push r8
000079bd661d955a  push r9
000079bd661d955c  push r10
000079bd661d955e  push r11
000079bd661d9560  sub rsp, 0xF0
000079bd661d9567  vmovaps [rsp], xmm0
000079bd661d956c  vmovaps [rsp+0x10], xmm1
000079bd661d9572  vmovaps [rsp+0x20], xmm2
000079bd661d9578  vmovaps [rsp+0x30], xmm3
000079bd661d957e  vmovaps [rsp+0x40], xmm4
000079bd661d9584  vmovaps [rsp+0x50], xmm5
000079bd661d958a  vmovaps [rsp+0x60], xmm6
000079bd661d9590  vmovaps [rsp+0x70], xmm7
000079bd661d9596  vmovaps [rsp+0x80], xmm8
000079bd661d959f  vmovaps [rsp+0x90], xmm9
000079bd661d95a8  vmovaps [rsp+0xA0], xmm10
000079bd661d95b1  vmovaps [rsp+0xB0], xmm11
000079bd661d95ba  vmovaps [rsp+0xC0], xmm12
000079bd661d95c3  vmovaps [rsp+0xD0], xmm13
000079bd661d95cc  vmovaps [rsp+0xE0], xmm15
000079bd661d95d5  sub rsp, 0x30
000079bd661d95d9  movaps [rsp], xmm14
000079bd661d95de  movaps [rsp+0x10], xmm8
000079bd661d95e4  movaps [rsp+0x20], xmm4
000079bd661d95e9  lea rdi, [rsp]
000079bd661d95ed  mov esi, 0x00
000079bd661d95f2  mov rax, 0x56EBD57B0530
000079bd661d95fc  call rax
000079bd661d95fe  movaps xmm14, [rsp]
000079bd661d9603  add rsp, 0x30
000079bd661d9607  vmovaps xmm0, [rsp]
000079bd661d960c  vmovaps xmm1, [rsp+0x10]
000079bd661d9612  vmovaps xmm2, [rsp+0x20]
000079bd661d9618  vmovaps xmm3, [rsp+0x30]
000079bd661d961e  vmovaps xmm4, [rsp+0x40]
000079bd661d9624  vmovaps xmm5, [rsp+0x50]
000079bd661d962a  vmovaps xmm6, [rsp+0x60]
000079bd661d9630  vmovaps xmm7, [rsp+0x70]
000079bd661d9636  vmovaps xmm8, [rsp+0x80]
000079bd661d963f  vmovaps xmm9, [rsp+0x90]
000079bd661d9648  vmovaps xmm10, [rsp+0xA0]
000079bd661d9651  vmovaps xmm11, [rsp+0xB0]
000079bd661d965a  vmovaps xmm12, [rsp+0xC0]
000079bd661d9663  vmovaps xmm13, [rsp+0xD0]
000079bd661d966c  vmovaps xmm15, [rsp+0xE0]
000079bd661d9675  add rsp, 0xF0
000079bd661d967c  pop r11
000079bd661d967e  pop r10
000079bd661d9680  pop r9
000079bd661d9682  pop r8
000079bd661d9684  pop rsi
000079bd661d9685  pop rdi
000079bd661d9686  pop rdx
000079bd661d9687  pop rcx
000079bd661d9688  pop rax
000079bd661d9689  add rsp, 0x08
000079bd661d968d  jmp 0x000079BD661D6265
000079bd661d9692  sub rsp, 0x08
000079bd661d9696  push rax
000079bd661d9697  push rcx
000079bd661d9698  push rdx
000079bd661d9699  push rdi
000079bd661d969a  push rsi
000079bd661d969b  push r8
000079bd661d969d  push r9
000079bd661d969f  push r10
000079bd661d96a1  push r11
000079bd661d96a3  sub rsp, 0xF0
000079bd661d96aa  vmovaps [rsp], xmm0
000079bd661d96af  vmovaps [rsp+0x10], xmm1
000079bd661d96b5  vmovaps [rsp+0x20], xmm2
000079bd661d96bb  vmovaps [rsp+0x30], xmm3
000079bd661d96c1  vmovaps [rsp+0x40], xmm5
000079bd661d96c7  vmovaps [rsp+0x50], xmm6
000079bd661d96cd  vmovaps [rsp+0x60], xmm7
000079bd661d96d3  vmovaps [rsp+0x70], xmm8
000079bd661d96d9  vmovaps [rsp+0x80], xmm9
000079bd661d96e2  vmovaps [rsp+0x90], xmm10
000079bd661d96eb  vmovaps [rsp+0xA0], xmm11
000079bd661d96f4  vmovaps [rsp+0xB0], xmm12
000079bd661d96fd  vmovaps [rsp+0xC0], xmm13
000079bd661d9706  vmovaps [rsp+0xD0], xmm14
000079bd661d970f  vmovaps [rsp+0xE0], xmm15
000079bd661d9718  sub rsp, 0x30
000079bd661d971c  movaps [rsp], xmm4
000079bd661d9720  movaps [rsp+0x10], xmm13
000079bd661d9726  movaps [rsp+0x20], xmm8
000079bd661d972c  lea rdi, [rsp]
000079bd661d9730  mov esi, 0x00
000079bd661d9735  mov rax, 0x56EBD57B0530
000079bd661d973f  call rax
000079bd661d9741  movaps xmm4, [rsp]
000079bd661d9745  add rsp, 0x30
000079bd661d9749  vmovaps xmm0, [rsp]
000079bd661d974e  vmovaps xmm1, [rsp+0x10]
000079bd661d9754  vmovaps xmm2, [rsp+0x20]
000079bd661d975a  vmovaps xmm3, [rsp+0x30]
000079bd661d9760  vmovaps xmm5, [rsp+0x40]
000079bd661d9766  vmovaps xmm6, [rsp+0x50]
000079bd661d976c  vmovaps xmm7, [rsp+0x60]
000079bd661d9772  vmovaps xmm8, [rsp+0x70]
000079bd661d9778  vmovaps xmm9, [rsp+0x80]
000079bd661d9781  vmovaps xmm10, [rsp+0x90]
000079bd661d978a  vmovaps xmm11, [rsp+0xA0]
000079bd661d9793  vmovaps xmm12, [rsp+0xB0]
000079bd661d979c  vmovaps xmm13, [rsp+0xC0]
000079bd661d97a5  vmovaps xmm14, [rsp+0xD0]
000079bd661d97ae  vmovaps xmm15, [rsp+0xE0]
000079bd661d97b7  add rsp, 0xF0
000079bd661d97be  pop r11
000079bd661d97c0  pop r10
000079bd661d97c2  pop r9
000079bd661d97c4  pop r8
000079bd661d97c6  pop rsi
000079bd661d97c7  pop rdi
000079bd661d97c8  pop rdx
000079bd661d97c9  pop rcx
000079bd661d97ca  pop rax
000079bd661d97cb  add rsp, 0x08
000079bd661d97cf  jmp 0x000079BD661D628A
000079bd661d97d4  sub rsp, 0x08
000079bd661d97d8  push rax
000079bd661d97d9  push rcx
000079bd661d97da  push rdx
000079bd661d97db  push rdi
000079bd661d97dc  push rsi
000079bd661d97dd  push r8
000079bd661d97df  push r9
000079bd661d97e1  push r10
000079bd661d97e3  push r11
000079bd661d97e5  sub rsp, 0xF0
000079bd661d97ec  vmovaps [rsp], xmm0
000079bd661d97f1  vmovaps [rsp+0x10], xmm1
000079bd661d97f7  vmovaps [rsp+0x20], xmm2
000079bd661d97fd  vmovaps [rsp+0x30], xmm3
000079bd661d9803  vmovaps [rsp+0x40], xmm4
000079bd661d9809  vmovaps [rsp+0x50], xmm5
000079bd661d980f  vmovaps [rsp+0x60], xmm6
000079bd661d9815  vmovaps [rsp+0x70], xmm7
000079bd661d981b  vmovaps [rsp+0x80], xmm8
000079bd661d9824  vmovaps [rsp+0x90], xmm9
000079bd661d982d  vmovaps [rsp+0xA0], xmm10
000079bd661d9836  vmovaps [rsp+0xB0], xmm11
000079bd661d983f  vmovaps [rsp+0xC0], xmm12
000079bd661d9848  vmovaps [rsp+0xD0], xmm14
000079bd661d9851  vmovaps [rsp+0xE0], xmm15
000079bd661d985a  sub rsp, 0x30
000079bd661d985e  movaps [rsp], xmm13
000079bd661d9863  movaps [rsp+0x10], xmm15
000079bd661d9869  movaps [rsp+0x20], xmm9
000079bd661d986f  lea rdi, [rsp]
000079bd661d9873  mov esi, 0x00
000079bd661d9878  mov rax, 0x56EBD57B0530
000079bd661d9882  call rax
000079bd661d9884  movaps xmm13, [rsp]
000079bd661d9889  add rsp, 0x30
000079bd661d988d  vmovaps xmm0, [rsp]
000079bd661d9892  vmovaps xmm1, [rsp+0x10]
000079bd661d9898  vmovaps xmm2, [rsp+0x20]
000079bd661d989e  vmovaps xmm3, [rsp+0x30]
000079bd661d98a4  vmovaps xmm4, [rsp+0x40]
000079bd661d98aa  vmovaps xmm5, [rsp+0x50]
000079bd661d98b0  vmovaps xmm6, [rsp+0x60]
000079bd661d98b6  vmovaps xmm7, [rsp+0x70]
000079bd661d98bc  vmovaps xmm8, [rsp+0x80]
000079bd661d98c5  vmovaps xmm9, [rsp+0x90]
000079bd661d98ce  vmovaps xmm10, [rsp+0xA0]
000079bd661d98d7  vmovaps xmm11, [rsp+0xB0]
000079bd661d98e0  vmovaps xmm12, [rsp+0xC0]
000079bd661d98e9  vmovaps xmm14, [rsp+0xD0]
000079bd661d98f2  vmovaps xmm15, [rsp+0xE0]
000079bd661d98fb  add rsp, 0xF0
000079bd661d9902  pop r11
000079bd661d9904  pop r10
000079bd661d9906  pop r9
000079bd661d9908  pop r8
000079bd661d990a  pop rsi
000079bd661d990b  pop rdi
000079bd661d990c  pop rdx
000079bd661d990d  pop rcx
000079bd661d990e  pop rax
000079bd661d990f  add rsp, 0x08
000079bd661d9913  jmp 0x000079BD661D62A5
000079bd661d9918  sub rsp, 0x08
000079bd661d991c  push rax
000079bd661d991d  push rcx
000079bd661d991e  push rdx
000079bd661d991f  push rdi
000079bd661d9920  push rsi
000079bd661d9921  push r8
000079bd661d9923  push r9
000079bd661d9925  push r10
000079bd661d9927  push r11
000079bd661d9929  sub rsp, 0xF0
000079bd661d9930  vmovaps [rsp], xmm0
000079bd661d9935  vmovaps [rsp+0x10], xmm1
000079bd661d993b  vmovaps [rsp+0x20], xmm2
000079bd661d9941  vmovaps [rsp+0x30], xmm3
000079bd661d9947  vmovaps [rsp+0x40], xmm4
000079bd661d994d  vmovaps [rsp+0x50], xmm5
000079bd661d9953  vmovaps [rsp+0x60], xmm6
000079bd661d9959  vmovaps [rsp+0x70], xmm7
000079bd661d995f  vmovaps [rsp+0x80], xmm8
000079bd661d9968  vmovaps [rsp+0x90], xmm9
000079bd661d9971  vmovaps [rsp+0xA0], xmm10
000079bd661d997a  vmovaps [rsp+0xB0], xmm11
000079bd661d9983  vmovaps [rsp+0xC0], xmm12
000079bd661d998c  vmovaps [rsp+0xD0], xmm13
000079bd661d9995  vmovaps [rsp+0xE0], xmm14
000079bd661d999e  sub rsp, 0x30
000079bd661d99a2  movaps [rsp], xmm15
000079bd661d99a7  movaps [rsp+0x10], xmm1
000079bd661d99ac  movaps [rsp+0x20], xmm5
000079bd661d99b1  lea rdi, [rsp]
000079bd661d99b5  mov esi, 0x00
000079bd661d99ba  mov rax, 0x56EBD57B0530
000079bd661d99c4  call rax
000079bd661d99c6  movaps xmm15, [rsp]
000079bd661d99cb  add rsp, 0x30
000079bd661d99cf  vmovaps xmm0, [rsp]
000079bd661d99d4  vmovaps xmm1, [rsp+0x10]
000079bd661d99da  vmovaps xmm2, [rsp+0x20]
000079bd661d99e0  vmovaps xmm3, [rsp+0x30]
000079bd661d99e6  vmovaps xmm4, [rsp+0x40]
000079bd661d99ec  vmovaps xmm5, [rsp+0x50]
000079bd661d99f2  vmovaps xmm6, [rsp+0x60]
000079bd661d99f8  vmovaps xmm7, [rsp+0x70]
000079bd661d99fe  vmovaps xmm8, [rsp+0x80]
000079bd661d9a07  vmovaps xmm9, [rsp+0x90]
000079bd661d9a10  vmovaps xmm10, [rsp+0xA0]
000079bd661d9a19  vmovaps xmm11, [rsp+0xB0]
000079bd661d9a22  vmovaps xmm12, [rsp+0xC0]
000079bd661d9a2b  vmovaps xmm13, [rsp+0xD0]
000079bd661d9a34  vmovaps xmm14, [rsp+0xE0]
000079bd661d9a3d  add rsp, 0xF0
000079bd661d9a44  pop r11
000079bd661d9a46  pop r10
000079bd661d9a48  pop r9
000079bd661d9a4a  pop r8
000079bd661d9a4c  pop rsi
000079bd661d9a4d  pop rdi
000079bd661d9a4e  pop rdx
000079bd661d9a4f  pop rcx
000079bd661d9a50  pop rax
000079bd661d9a51  add rsp, 0x08
000079bd661d9a55  jmp 0x000079BD661D62C0
000079bd661d9a5a  call 0x000079BD660D64F0
000079bd661d9a5f  jmp 0x000079BD661D631B
000079bd661d9a64  sub rsp, 0x08
000079bd661d9a68  push rax
000079bd661d9a69  push rcx
000079bd661d9a6a  push rdx
000079bd661d9a6b  push rdi
000079bd661d9a6c  push rsi
000079bd661d9a6d  push r8
000079bd661d9a6f  push r9
000079bd661d9a71  push r10
000079bd661d9a73  push r11
000079bd661d9a75  sub rsp, 0xF0
000079bd661d9a7c  vmovaps [rsp], xmm0
000079bd661d9a81  vmovaps [rsp+0x10], xmm1
000079bd661d9a87  vmovaps [rsp+0x20], xmm2
000079bd661d9a8d  vmovaps [rsp+0x30], xmm3
000079bd661d9a93  vmovaps [rsp+0x40], xmm4
000079bd661d9a99  vmovaps [rsp+0x50], xmm5
000079bd661d9a9f  vmovaps [rsp+0x60], xmm6
000079bd661d9aa5  vmovaps [rsp+0x70], xmm7
000079bd661d9aab  vmovaps [rsp+0x80], xmm8
000079bd661d9ab4  vmovaps [rsp+0x90], xmm10
000079bd661d9abd  vmovaps [rsp+0xA0], xmm11
000079bd661d9ac6  vmovaps [rsp+0xB0], xmm12
000079bd661d9acf  vmovaps [rsp+0xC0], xmm13
000079bd661d9ad8  vmovaps [rsp+0xD0], xmm14
000079bd661d9ae1  vmovaps [rsp+0xE0], xmm15
000079bd661d9aea  sub rsp, 0x30
000079bd661d9aee  movaps [rsp], xmm9
000079bd661d9af3  movaps [rsp+0x10], xmm8
000079bd661d9af9  movaps [rsp+0x20], xmm11
000079bd661d9aff  lea rdi, [rsp]
000079bd661d9b03  mov esi, 0x00
000079bd661d9b08  mov rax, 0x56EBD57B0530
000079bd661d9b12  call rax
000079bd661d9b14  movaps xmm9, [rsp]
000079bd661d9b19  add rsp, 0x30
000079bd661d9b1d  vmovaps xmm0, [rsp]
000079bd661d9b22  vmovaps xmm1, [rsp+0x10]
000079bd661d9b28  vmovaps xmm2, [rsp+0x20]
000079bd661d9b2e  vmovaps xmm3, [rsp+0x30]
000079bd661d9b34  vmovaps xmm4, [rsp+0x40]
000079bd661d9b3a  vmovaps xmm5, [rsp+0x50]
000079bd661d9b40  vmovaps xmm6, [rsp+0x60]
000079bd661d9b46  vmovaps xmm7, [rsp+0x70]
000079bd661d9b4c  vmovaps xmm8, [rsp+0x80]
000079bd661d9b55  vmovaps xmm10, [rsp+0x90]
000079bd661d9b5e  vmovaps xmm11, [rsp+0xA0]
000079bd661d9b67  vmovaps xmm12, [rsp+0xB0]
000079bd661d9b70  vmovaps xmm13, [rsp+0xC0]
000079bd661d9b79  vmovaps xmm14, [rsp+0xD0]
000079bd661d9b82  vmovaps xmm15, [rsp+0xE0]
000079bd661d9b8b  add rsp, 0xF0
000079bd661d9b92  pop r11
000079bd661d9b94  pop r10
000079bd661d9b96  pop r9
000079bd661d9b98  pop r8
000079bd661d9b9a  pop rsi
000079bd661d9b9b  pop rdi
000079bd661d9b9c  pop rdx
000079bd661d9b9d  pop rcx
000079bd661d9b9e  pop rax
000079bd661d9b9f  add rsp, 0x08
000079bd661d9ba3  jmp 0x000079BD661D6352
000079bd661d9ba8  sub rsp, 0x08
000079bd661d9bac  push rax
000079bd661d9bad  push rcx
000079bd661d9bae  push rdx
000079bd661d9baf  push rdi
000079bd661d9bb0  push rsi
000079bd661d9bb1  push r8
000079bd661d9bb3  push r9
000079bd661d9bb5  push r10
000079bd661d9bb7  push r11
000079bd661d9bb9  sub rsp, 0xF0
000079bd661d9bc0  vmovaps [rsp], xmm0
000079bd661d9bc5  vmovaps [rsp+0x10], xmm1
000079bd661d9bcb  vmovaps [rsp+0x20], xmm2
000079bd661d9bd1  vmovaps [rsp+0x30], xmm3
000079bd661d9bd7  vmovaps [rsp+0x40], xmm4
000079bd661d9bdd  vmovaps [rsp+0x50], xmm5
000079bd661d9be3  vmovaps [rsp+0x60], xmm6
000079bd661d9be9  vmovaps [rsp+0x70], xmm7
000079bd661d9bef  vmovaps [rsp+0x80], xmm8
000079bd661d9bf8  vmovaps [rsp+0x90], xmm9
000079bd661d9c01  vmovaps [rsp+0xA0], xmm10
000079bd661d9c0a  vmovaps [rsp+0xB0], xmm12
000079bd661d9c13  vmovaps [rsp+0xC0], xmm13
000079bd661d9c1c  vmovaps [rsp+0xD0], xmm14
000079bd661d9c25  vmovaps [rsp+0xE0], xmm15
000079bd661d9c2e  sub rsp, 0x30
000079bd661d9c32  movaps [rsp], xmm11
000079bd661d9c37  movaps [rsp+0x10], xmm10
000079bd661d9c3d  movaps [rsp+0x20], xmm6
000079bd661d9c42  lea rdi, [rsp]
000079bd661d9c46  mov esi, 0x00
000079bd661d9c4b  mov rax, 0x56EBD57B0530
000079bd661d9c55  call rax
000079bd661d9c57  movaps xmm11, [rsp]
000079bd661d9c5c  add rsp, 0x30
000079bd661d9c60  vmovaps xmm0, [rsp]
000079bd661d9c65  vmovaps xmm1, [rsp+0x10]
000079bd661d9c6b  vmovaps xmm2, [rsp+0x20]
000079bd661d9c71  vmovaps xmm3, [rsp+0x30]
000079bd661d9c77  vmovaps xmm4, [rsp+0x40]
000079bd661d9c7d  vmovaps xmm5, [rsp+0x50]
000079bd661d9c83  vmovaps xmm6, [rsp+0x60]
000079bd661d9c89  vmovaps xmm7, [rsp+0x70]
000079bd661d9c8f  vmovaps xmm8, [rsp+0x80]
000079bd661d9c98  vmovaps xmm9, [rsp+0x90]
000079bd661d9ca1  vmovaps xmm10, [rsp+0xA0]
000079bd661d9caa  vmovaps xmm12, [rsp+0xB0]
000079bd661d9cb3  vmovaps xmm13, [rsp+0xC0]
000079bd661d9cbc  vmovaps xmm14, [rsp+0xD0]
000079bd661d9cc5  vmovaps xmm15, [rsp+0xE0]
000079bd661d9cce  add rsp, 0xF0
000079bd661d9cd5  pop r11
000079bd661d9cd7  pop r10
000079bd661d9cd9  pop r9
000079bd661d9cdb  pop r8
000079bd661d9cdd  pop rsi
000079bd661d9cde  pop rdi
000079bd661d9cdf  pop rdx
000079bd661d9ce0  pop rcx
000079bd661d9ce1  pop rax
000079bd661d9ce2  add rsp, 0x08
000079bd661d9ce6  jmp 0x000079BD661D636D
000079bd661d9ceb  sub rsp, 0x08
000079bd661d9cef  push rax
000079bd661d9cf0  push rcx
000079bd661d9cf1  push rdx
000079bd661d9cf2  push rdi
000079bd661d9cf3  push rsi
000079bd661d9cf4  push r8
000079bd661d9cf6  push r9
000079bd661d9cf8  push r10
000079bd661d9cfa  push r11
000079bd661d9cfc  sub rsp, 0xF0
000079bd661d9d03  vmovaps [rsp], xmm0
000079bd661d9d08  vmovaps [rsp+0x10], xmm1
000079bd661d9d0e  vmovaps [rsp+0x20], xmm2
000079bd661d9d14  vmovaps [rsp+0x30], xmm3
000079bd661d9d1a  vmovaps [rsp+0x40], xmm4
000079bd661d9d20  vmovaps [rsp+0x50], xmm5
000079bd661d9d26  vmovaps [rsp+0x60], xmm6
000079bd661d9d2c  vmovaps [rsp+0x70], xmm7
000079bd661d9d32  vmovaps [rsp+0x80], xmm8
000079bd661d9d3b  vmovaps [rsp+0x90], xmm9
000079bd661d9d44  vmovaps [rsp+0xA0], xmm11
000079bd661d9d4d  vmovaps [rsp+0xB0], xmm12
000079bd661d9d56  vmovaps [rsp+0xC0], xmm13
000079bd661d9d5f  vmovaps [rsp+0xD0], xmm14
000079bd661d9d68  vmovaps [rsp+0xE0], xmm15
000079bd661d9d71  sub rsp, 0x30
000079bd661d9d75  movaps [rsp], xmm10
000079bd661d9d7a  movaps [rsp+0x10], xmm14
000079bd661d9d80  movaps [rsp+0x20], xmm4
000079bd661d9d85  lea rdi, [rsp]
000079bd661d9d89  mov esi, 0x00
000079bd661d9d8e  mov rax, 0x56EBD57B0530
000079bd661d9d98  call rax
000079bd661d9d9a  movaps xmm10, [rsp]
000079bd661d9d9f  add rsp, 0x30
000079bd661d9da3  vmovaps xmm0, [rsp]
000079bd661d9da8  vmovaps xmm1, [rsp+0x10]
000079bd661d9dae  vmovaps xmm2, [rsp+0x20]
000079bd661d9db4  vmovaps xmm3, [rsp+0x30]
000079bd661d9dba  vmovaps xmm4, [rsp+0x40]
000079bd661d9dc0  vmovaps xmm5, [rsp+0x50]
000079bd661d9dc6  vmovaps xmm6, [rsp+0x60]
000079bd661d9dcc  vmovaps xmm7, [rsp+0x70]
000079bd661d9dd2  vmovaps xmm8, [rsp+0x80]
000079bd661d9ddb  vmovaps xmm9, [rsp+0x90]
000079bd661d9de4  vmovaps xmm11, [rsp+0xA0]
000079bd661d9ded  vmovaps xmm12, [rsp+0xB0]
000079bd661d9df6  vmovaps xmm13, [rsp+0xC0]
000079bd661d9dff  vmovaps xmm14, [rsp+0xD0]
000079bd661d9e08  vmovaps xmm15, [rsp+0xE0]
000079bd661d9e11  add rsp, 0xF0
000079bd661d9e18  pop r11
000079bd661d9e1a  pop r10
000079bd661d9e1c  pop r9
000079bd661d9e1e  pop r8
000079bd661d9e20  pop rsi
000079bd661d9e21  pop rdi
000079bd661d9e22  pop rdx
000079bd661d9e23  pop rcx
000079bd661d9e24  pop rax
000079bd661d9e25  add rsp, 0x08
000079bd661d9e29  jmp 0x000079BD661D6388
000079bd661d9e2e  sub rsp, 0x08
000079bd661d9e32  push rax
000079bd661d9e33  push rcx
000079bd661d9e34  push rdx
000079bd661d9e35  push rdi
000079bd661d9e36  push rsi
000079bd661d9e37  push r8
000079bd661d9e39  push r9
000079bd661d9e3b  push r10
000079bd661d9e3d  push r11
000079bd661d9e3f  sub rsp, 0xF0
000079bd661d9e46  vmovaps [rsp], xmm0
000079bd661d9e4b  vmovaps [rsp+0x10], xmm1
000079bd661d9e51  vmovaps [rsp+0x20], xmm2
000079bd661d9e57  vmovaps [rsp+0x30], xmm3
000079bd661d9e5d  vmovaps [rsp+0x40], xmm4
000079bd661d9e63  vmovaps [rsp+0x50], xmm5
000079bd661d9e69  vmovaps [rsp+0x60], xmm6
000079bd661d9e6f  vmovaps [rsp+0x70], xmm7
000079bd661d9e75  vmovaps [rsp+0x80], xmm9
000079bd661d9e7e  vmovaps [rsp+0x90], xmm10
000079bd661d9e87  vmovaps [rsp+0xA0], xmm11
000079bd661d9e90  vmovaps [rsp+0xB0], xmm12
000079bd661d9e99  vmovaps [rsp+0xC0], xmm13
000079bd661d9ea2  vmovaps [rsp+0xD0], xmm14
000079bd661d9eab  vmovaps [rsp+0xE0], xmm15
000079bd661d9eb4  sub rsp, 0x30
000079bd661d9eb8  movaps [rsp], xmm8
000079bd661d9ebd  movaps [rsp+0x10], xmm1
000079bd661d9ec2  movaps [rsp+0x20], xmm14
000079bd661d9ec8  lea rdi, [rsp]
000079bd661d9ecc  mov esi, 0x00
000079bd661d9ed1  mov rax, 0x56EBD57B0530
000079bd661d9edb  call rax
000079bd661d9edd  movaps xmm8, [rsp]
000079bd661d9ee2  add rsp, 0x30
000079bd661d9ee6  vmovaps xmm0, [rsp]
000079bd661d9eeb  vmovaps xmm1, [rsp+0x10]
000079bd661d9ef1  vmovaps xmm2, [rsp+0x20]
000079bd661d9ef7  vmovaps xmm3, [rsp+0x30]
000079bd661d9efd  vmovaps xmm4, [rsp+0x40]
000079bd661d9f03  vmovaps xmm5, [rsp+0x50]
000079bd661d9f09  vmovaps xmm6, [rsp+0x60]
000079bd661d9f0f  vmovaps xmm7, [rsp+0x70]
000079bd661d9f15  vmovaps xmm9, [rsp+0x80]
000079bd661d9f1e  vmovaps xmm10, [rsp+0x90]
000079bd661d9f27  vmovaps xmm11, [rsp+0xA0]
000079bd661d9f30  vmovaps xmm12, [rsp+0xB0]
000079bd661d9f39  vmovaps xmm13, [rsp+0xC0]
000079bd661d9f42  vmovaps xmm14, [rsp+0xD0]
000079bd661d9f4b  vmovaps xmm15, [rsp+0xE0]
000079bd661d9f54  add rsp, 0xF0
000079bd661d9f5b  pop r11
000079bd661d9f5d  pop r10
000079bd661d9f5f  pop r9
000079bd661d9f61  pop r8
000079bd661d9f63  pop rsi
000079bd661d9f64  pop rdi
000079bd661d9f65  pop rdx
000079bd661d9f66  pop rcx
000079bd661d9f67  pop rax
000079bd661d9f68  add rsp, 0x08
000079bd661d9f6c  jmp 0x000079BD661D63AE
000079bd661d9f71  sub rsp, 0x08
000079bd661d9f75  push rax
000079bd661d9f76  push rcx
000079bd661d9f77  push rdx
000079bd661d9f78  push rdi
000079bd661d9f79  push rsi
000079bd661d9f7a  push r8
000079bd661d9f7c  push r9
000079bd661d9f7e  push r10
000079bd661d9f80  push r11
000079bd661d9f82  sub rsp, 0xF0
000079bd661d9f89  vmovaps [rsp], xmm0
000079bd661d9f8e  vmovaps [rsp+0x10], xmm1
000079bd661d9f94  vmovaps [rsp+0x20], xmm2
000079bd661d9f9a  vmovaps [rsp+0x30], xmm3
000079bd661d9fa0  vmovaps [rsp+0x40], xmm4
000079bd661d9fa6  vmovaps [rsp+0x50], xmm5
000079bd661d9fac  vmovaps [rsp+0x60], xmm7
000079bd661d9fb2  vmovaps [rsp+0x70], xmm8
000079bd661d9fb8  vmovaps [rsp+0x80], xmm9
000079bd661d9fc1  vmovaps [rsp+0x90], xmm10
000079bd661d9fca  vmovaps [rsp+0xA0], xmm11
000079bd661d9fd3  vmovaps [rsp+0xB0], xmm12
000079bd661d9fdc  vmovaps [rsp+0xC0], xmm13
000079bd661d9fe5  vmovaps [rsp+0xD0], xmm14
000079bd661d9fee  vmovaps [rsp+0xE0], xmm15
000079bd661d9ff7  sub rsp, 0x30
000079bd661d9ffb  movaps [rsp], xmm6
000079bd661d9fff  movaps [rsp+0x10], xmm1
000079bd661da004  movaps [rsp+0x20], xmm14
000079bd661da00a  lea rdi, [rsp]
000079bd661da00e  mov esi, 0x00
000079bd661da013  mov rax, 0x56EBD57B0530
000079bd661da01d  call rax
000079bd661da01f  movaps xmm6, [rsp]
000079bd661da023  add rsp, 0x30
000079bd661da027  vmovaps xmm0, [rsp]
000079bd661da02c  vmovaps xmm1, [rsp+0x10]
000079bd661da032  vmovaps xmm2, [rsp+0x20]
000079bd661da038  vmovaps xmm3, [rsp+0x30]
000079bd661da03e  vmovaps xmm4, [rsp+0x40]
000079bd661da044  vmovaps xmm5, [rsp+0x50]
000079bd661da04a  vmovaps xmm7, [rsp+0x60]
000079bd661da050  vmovaps xmm8, [rsp+0x70]
000079bd661da056  vmovaps xmm9, [rsp+0x80]
000079bd661da05f  vmovaps xmm10, [rsp+0x90]
000079bd661da068  vmovaps xmm11, [rsp+0xA0]
000079bd661da071  vmovaps xmm12, [rsp+0xB0]
000079bd661da07a  vmovaps xmm13, [rsp+0xC0]
000079bd661da083  vmovaps xmm14, [rsp+0xD0]
000079bd661da08c  vmovaps xmm15, [rsp+0xE0]
000079bd661da095  add rsp, 0xF0
000079bd661da09c  pop r11
000079bd661da09e  pop r10
000079bd661da0a0  pop r9
000079bd661da0a2  pop r8
000079bd661da0a4  pop rsi
000079bd661da0a5  pop rdi
000079bd661da0a6  pop rdx
000079bd661da0a7  pop rcx
000079bd661da0a8  pop rax
000079bd661da0a9  add rsp, 0x08
000079bd661da0ad  jmp 0x000079BD661D63DA
000079bd661da0b2  sub rsp, 0x08
000079bd661da0b6  push rax
000079bd661da0b7  push rcx
000079bd661da0b8  push rdx
000079bd661da0b9  push rdi
000079bd661da0ba  push rsi
000079bd661da0bb  push r8
000079bd661da0bd  push r9
000079bd661da0bf  push r10
000079bd661da0c1  push r11
000079bd661da0c3  sub rsp, 0xF0
000079bd661da0ca  vmovaps [rsp], xmm0
000079bd661da0cf  vmovaps [rsp+0x10], xmm1
000079bd661da0d5  vmovaps [rsp+0x20], xmm2
000079bd661da0db  vmovaps [rsp+0x30], xmm3
000079bd661da0e1  vmovaps [rsp+0x40], xmm4
000079bd661da0e7  vmovaps [rsp+0x50], xmm5
000079bd661da0ed  vmovaps [rsp+0x60], xmm6
000079bd661da0f3  vmovaps [rsp+0x70], xmm7
000079bd661da0f9  vmovaps [rsp+0x80], xmm8
000079bd661da102  vmovaps [rsp+0x90], xmm9
000079bd661da10b  vmovaps [rsp+0xA0], xmm10
000079bd661da114  vmovaps [rsp+0xB0], xmm11
000079bd661da11d  vmovaps [rsp+0xC0], xmm12
000079bd661da126  vmovaps [rsp+0xD0], xmm13
000079bd661da12f  vmovaps [rsp+0xE0], xmm15
000079bd661da138  sub rsp, 0x30
000079bd661da13c  movaps [rsp], xmm14
000079bd661da141  movaps [rsp+0x10], xmm12
000079bd661da147  movaps [rsp+0x20], xmm1
000079bd661da14c  lea rdi, [rsp]
000079bd661da150  mov esi, 0x00
000079bd661da155  mov rax, 0x56EBD57B0530
000079bd661da15f  call rax
000079bd661da161  movaps xmm14, [rsp]
000079bd661da166  add rsp, 0x30
000079bd661da16a  vmovaps xmm0, [rsp]
000079bd661da16f  vmovaps xmm1, [rsp+0x10]
000079bd661da175  vmovaps xmm2, [rsp+0x20]
000079bd661da17b  vmovaps xmm3, [rsp+0x30]
000079bd661da181  vmovaps xmm4, [rsp+0x40]
000079bd661da187  vmovaps xmm5, [rsp+0x50]
000079bd661da18d  vmovaps xmm6, [rsp+0x60]
000079bd661da193  vmovaps xmm7, [rsp+0x70]
000079bd661da199  vmovaps xmm8, [rsp+0x80]
000079bd661da1a2  vmovaps xmm9, [rsp+0x90]
000079bd661da1ab  vmovaps xmm10, [rsp+0xA0]
000079bd661da1b4  vmovaps xmm11, [rsp+0xB0]
000079bd661da1bd  vmovaps xmm12, [rsp+0xC0]
000079bd661da1c6  vmovaps xmm13, [rsp+0xD0]
000079bd661da1cf  vmovaps xmm15, [rsp+0xE0]
000079bd661da1d8  add rsp, 0xF0
000079bd661da1df  pop r11
000079bd661da1e1  pop r10
000079bd661da1e3  pop r9
000079bd661da1e5  pop r8
000079bd661da1e7  pop rsi
000079bd661da1e8  pop rdi
000079bd661da1e9  pop rdx
000079bd661da1ea  pop rcx
000079bd661da1eb  pop rax
000079bd661da1ec  add rsp, 0x08
000079bd661da1f0  jmp 0x000079BD661D6400
000079bd661da1f5  sub rsp, 0x08
000079bd661da1f9  push rax
000079bd661da1fa  push rcx
000079bd661da1fb  push rdx
000079bd661da1fc  push rdi
000079bd661da1fd  push rsi
000079bd661da1fe  push r8
000079bd661da200  push r9
000079bd661da202  push r10
000079bd661da204  push r11
000079bd661da206  sub rsp, 0xF0
000079bd661da20d  vmovaps [rsp], xmm0
000079bd661da212  vmovaps [rsp+0x10], xmm2
000079bd661da218  vmovaps [rsp+0x20], xmm3
000079bd661da21e  vmovaps [rsp+0x30], xmm4
000079bd661da224  vmovaps [rsp+0x40], xmm5
000079bd661da22a  vmovaps [rsp+0x50], xmm6
000079bd661da230  vmovaps [rsp+0x60], xmm7
000079bd661da236  vmovaps [rsp+0x70], xmm8
000079bd661da23c  vmovaps [rsp+0x80], xmm9
000079bd661da245  vmovaps [rsp+0x90], xmm10
000079bd661da24e  vmovaps [rsp+0xA0], xmm11
000079bd661da257  vmovaps [rsp+0xB0], xmm12
000079bd661da260  vmovaps [rsp+0xC0], xmm13
000079bd661da269  vmovaps [rsp+0xD0], xmm14
000079bd661da272  vmovaps [rsp+0xE0], xmm15
000079bd661da27b  sub rsp, 0x30
000079bd661da27f  movaps [rsp], xmm1
000079bd661da283  movaps [rsp+0x10], xmm13
000079bd661da289  movaps [rsp+0x20], xmm9
000079bd661da28f  lea rdi, [rsp]
000079bd661da293  mov esi, 0x00
000079bd661da298  mov rax, 0x56EBD57B0530
000079bd661da2a2  call rax
000079bd661da2a4  movaps xmm1, [rsp]
000079bd661da2a8  add rsp, 0x30
000079bd661da2ac  vmovaps xmm0, [rsp]
000079bd661da2b1  vmovaps xmm2, [rsp+0x10]
000079bd661da2b7  vmovaps xmm3, [rsp+0x20]
000079bd661da2bd  vmovaps xmm4, [rsp+0x30]
000079bd661da2c3  vmovaps xmm5, [rsp+0x40]
000079bd661da2c9  vmovaps xmm6, [rsp+0x50]
000079bd661da2cf  vmovaps xmm7, [rsp+0x60]
000079bd661da2d5  vmovaps xmm8, [rsp+0x70]
000079bd661da2db  vmovaps xmm9, [rsp+0x80]
000079bd661da2e4  vmovaps xmm10, [rsp+0x90]
000079bd661da2ed  vmovaps xmm11, [rsp+0xA0]
000079bd661da2f6  vmovaps xmm12, [rsp+0xB0]
000079bd661da2ff  vmovaps xmm13, [rsp+0xC0]
000079bd661da308  vmovaps xmm14, [rsp+0xD0]
000079bd661da311  vmovaps xmm15, [rsp+0xE0]
000079bd661da31a  add rsp, 0xF0
000079bd661da321  pop r11
000079bd661da323  pop r10
000079bd661da325  pop r9
000079bd661da327  pop r8
000079bd661da329  pop rsi
000079bd661da32a  pop rdi
000079bd661da32b  pop rdx
000079bd661da32c  pop rcx
000079bd661da32d  pop rax
000079bd661da32e  add rsp, 0x08
000079bd661da332  jmp 0x000079BD661D641A
000079bd661da337  sub rsp, 0x08
000079bd661da33b  push rax
000079bd661da33c  push rcx
000079bd661da33d  push rdx
000079bd661da33e  push rdi
000079bd661da33f  push rsi
000079bd661da340  push r8
000079bd661da342  push r9
000079bd661da344  push r10
000079bd661da346  push r11
000079bd661da348  sub rsp, 0xF0
000079bd661da34f  vmovaps [rsp], xmm0
000079bd661da354  vmovaps [rsp+0x10], xmm1
000079bd661da35a  vmovaps [rsp+0x20], xmm2
000079bd661da360  vmovaps [rsp+0x30], xmm3
000079bd661da366  vmovaps [rsp+0x40], xmm4
000079bd661da36c  vmovaps [rsp+0x50], xmm5
000079bd661da372  vmovaps [rsp+0x60], xmm6
000079bd661da378  vmovaps [rsp+0x70], xmm7
000079bd661da37e  vmovaps [rsp+0x80], xmm8
000079bd661da387  vmovaps [rsp+0x90], xmm9
000079bd661da390  vmovaps [rsp+0xA0], xmm10
000079bd661da399  vmovaps [rsp+0xB0], xmm11
000079bd661da3a2  vmovaps [rsp+0xC0], xmm13
000079bd661da3ab  vmovaps [rsp+0xD0], xmm14
000079bd661da3b4  vmovaps [rsp+0xE0], xmm15
000079bd661da3bd  sub rsp, 0x30
000079bd661da3c1  movaps [rsp], xmm12
000079bd661da3c6  movaps [rsp+0x10], xmm7
000079bd661da3cb  movaps [rsp+0x20], xmm13
000079bd661da3d1  lea rdi, [rsp]
000079bd661da3d5  mov esi, 0x00
000079bd661da3da  mov rax, 0x56EBD57B0530
000079bd661da3e4  call rax
000079bd661da3e6  movaps xmm12, [rsp]
000079bd661da3eb  add rsp, 0x30
000079bd661da3ef  vmovaps xmm0, [rsp]
000079bd661da3f4  vmovaps xmm1, [rsp+0x10]
000079bd661da3fa  vmovaps xmm2, [rsp+0x20]
000079bd661da400  vmovaps xmm3, [rsp+0x30]
000079bd661da406  vmovaps xmm4, [rsp+0x40]
000079bd661da40c  vmovaps xmm5, [rsp+0x50]
000079bd661da412  vmovaps xmm6, [rsp+0x60]
000079bd661da418  vmovaps xmm7, [rsp+0x70]
000079bd661da41e  vmovaps xmm8, [rsp+0x80]
000079bd661da427  vmovaps xmm9, [rsp+0x90]
000079bd661da430  vmovaps xmm10, [rsp+0xA0]
000079bd661da439  vmovaps xmm11, [rsp+0xB0]
000079bd661da442  vmovaps xmm13, [rsp+0xC0]
000079bd661da44b  vmovaps xmm14, [rsp+0xD0]
000079bd661da454  vmovaps xmm15, [rsp+0xE0]
000079bd661da45d  add rsp, 0xF0
000079bd661da464  pop r11
000079bd661da466  pop r10
000079bd661da468  pop r9
000079bd661da46a  pop r8
000079bd661da46c  pop rsi
000079bd661da46d  pop rdi
000079bd661da46e  pop rdx
000079bd661da46f  pop rcx
000079bd661da470  pop rax
000079bd661da471  add rsp, 0x08
000079bd661da475  jmp 0x000079BD661D6441
000079bd661da47a  sub rsp, 0x08
000079bd661da47e  push rax
000079bd661da47f  push rcx
000079bd661da480  push rdx
000079bd661da481  push rdi
000079bd661da482  push rsi
000079bd661da483  push r8
000079bd661da485  push r9
000079bd661da487  push r10
000079bd661da489  push r11
000079bd661da48b  sub rsp, 0xF0
000079bd661da492  vmovaps [rsp], xmm0
000079bd661da497  vmovaps [rsp+0x10], xmm1
000079bd661da49d  vmovaps [rsp+0x20], xmm2
000079bd661da4a3  vmovaps [rsp+0x30], xmm3
000079bd661da4a9  vmovaps [rsp+0x40], xmm4
000079bd661da4af  vmovaps [rsp+0x50], xmm5
000079bd661da4b5  vmovaps [rsp+0x60], xmm6
000079bd661da4bb  vmovaps [rsp+0x70], xmm7
000079bd661da4c1  vmovaps [rsp+0x80], xmm8
000079bd661da4ca  vmovaps [rsp+0x90], xmm9
000079bd661da4d3  vmovaps [rsp+0xA0], xmm10
000079bd661da4dc  vmovaps [rsp+0xB0], xmm11
000079bd661da4e5  vmovaps [rsp+0xC0], xmm12
000079bd661da4ee  vmovaps [rsp+0xD0], xmm14
000079bd661da4f7  vmovaps [rsp+0xE0], xmm15
000079bd661da500  sub rsp, 0x30
000079bd661da504  movaps [rsp], xmm13
000079bd661da509  movaps [rsp+0x10], xmm15
000079bd661da50f  movaps [rsp+0x20], xmm8
000079bd661da515  lea rdi, [rsp]
000079bd661da519  mov esi, 0x00
000079bd661da51e  mov rax, 0x56EBD57B0530
000079bd661da528  call rax
000079bd661da52a  movaps xmm13, [rsp]
000079bd661da52f  add rsp, 0x30
000079bd661da533  vmovaps xmm0, [rsp]
000079bd661da538  vmovaps xmm1, [rsp+0x10]
000079bd661da53e  vmovaps xmm2, [rsp+0x20]
000079bd661da544  vmovaps xmm3, [rsp+0x30]
000079bd661da54a  vmovaps xmm4, [rsp+0x40]
000079bd661da550  vmovaps xmm5, [rsp+0x50]
000079bd661da556  vmovaps xmm6, [rsp+0x60]
000079bd661da55c  vmovaps xmm7, [rsp+0x70]
000079bd661da562  vmovaps xmm8, [rsp+0x80]
000079bd661da56b  vmovaps xmm9, [rsp+0x90]
000079bd661da574  vmovaps xmm10, [rsp+0xA0]
000079bd661da57d  vmovaps xmm11, [rsp+0xB0]
000079bd661da586  vmovaps xmm12, [rsp+0xC0]
000079bd661da58f  vmovaps xmm14, [rsp+0xD0]
000079bd661da598  vmovaps xmm15, [rsp+0xE0]
000079bd661da5a1  add rsp, 0xF0
000079bd661da5a8  pop r11
000079bd661da5aa  pop r10
000079bd661da5ac  pop r9
000079bd661da5ae  pop r8
000079bd661da5b0  pop rsi
000079bd661da5b1  pop rdi
000079bd661da5b2  pop rdx
000079bd661da5b3  pop rcx
000079bd661da5b4  pop rax
000079bd661da5b5  add rsp, 0x08
000079bd661da5b9  jmp 0x000079BD661D645C
000079bd661da5be  sub rsp, 0x08
000079bd661da5c2  push rax
000079bd661da5c3  push rcx
000079bd661da5c4  push rdx
000079bd661da5c5  push rdi
000079bd661da5c6  push rsi
000079bd661da5c7  push r8
000079bd661da5c9  push r9
000079bd661da5cb  push r10
000079bd661da5cd  push r11
000079bd661da5cf  sub rsp, 0xF0
000079bd661da5d6  vmovaps [rsp], xmm0
000079bd661da5db  vmovaps [rsp+0x10], xmm1
000079bd661da5e1  vmovaps [rsp+0x20], xmm2
000079bd661da5e7  vmovaps [rsp+0x30], xmm3
000079bd661da5ed  vmovaps [rsp+0x40], xmm4
000079bd661da5f3  vmovaps [rsp+0x50], xmm5
000079bd661da5f9  vmovaps [rsp+0x60], xmm6
000079bd661da5ff  vmovaps [rsp+0x70], xmm7
000079bd661da605  vmovaps [rsp+0x80], xmm9
000079bd661da60e  vmovaps [rsp+0x90], xmm10
000079bd661da617  vmovaps [rsp+0xA0], xmm11
000079bd661da620  vmovaps [rsp+0xB0], xmm12
000079bd661da629  vmovaps [rsp+0xC0], xmm13
000079bd661da632  vmovaps [rsp+0xD0], xmm14
000079bd661da63b  vmovaps [rsp+0xE0], xmm15
000079bd661da644  sub rsp, 0x30
000079bd661da648  movaps [rsp], xmm8
000079bd661da64d  movaps [rsp+0x10], xmm15
000079bd661da653  movaps [rsp+0x20], xmm9
000079bd661da659  lea rdi, [rsp]
000079bd661da65d  mov esi, 0x00
000079bd661da662  mov rax, 0x56EBD57B0530
000079bd661da66c  call rax
000079bd661da66e  movaps xmm8, [rsp]
000079bd661da673  add rsp, 0x30
000079bd661da677  vmovaps xmm0, [rsp]
000079bd661da67c  vmovaps xmm1, [rsp+0x10]
000079bd661da682  vmovaps xmm2, [rsp+0x20]
000079bd661da688  vmovaps xmm3, [rsp+0x30]
000079bd661da68e  vmovaps xmm4, [rsp+0x40]
000079bd661da694  vmovaps xmm5, [rsp+0x50]
000079bd661da69a  vmovaps xmm6, [rsp+0x60]
000079bd661da6a0  vmovaps xmm7, [rsp+0x70]
000079bd661da6a6  vmovaps xmm9, [rsp+0x80]
000079bd661da6af  vmovaps xmm10, [rsp+0x90]
000079bd661da6b8  vmovaps xmm11, [rsp+0xA0]
000079bd661da6c1  vmovaps xmm12, [rsp+0xB0]
000079bd661da6ca  vmovaps xmm13, [rsp+0xC0]
000079bd661da6d3  vmovaps xmm14, [rsp+0xD0]
000079bd661da6dc  vmovaps xmm15, [rsp+0xE0]
000079bd661da6e5  add rsp, 0xF0
000079bd661da6ec  pop r11
000079bd661da6ee  pop r10
000079bd661da6f0  pop r9
000079bd661da6f2  pop r8
000079bd661da6f4  pop rsi
000079bd661da6f5  pop rdi
000079bd661da6f6  pop rdx
000079bd661da6f7  pop rcx
000079bd661da6f8  pop rax
000079bd661da6f9  add rsp, 0x08
000079bd661da6fd  jmp 0x000079BD661D648A
000079bd661da702  sub rsp, 0x08
000079bd661da706  push rax
000079bd661da707  push rcx
000079bd661da708  push rdx
000079bd661da709  push rdi
000079bd661da70a  push rsi
000079bd661da70b  push r8
000079bd661da70d  push r9
000079bd661da70f  push r10
000079bd661da711  push r11
000079bd661da713  sub rsp, 0xF0
000079bd661da71a  vmovaps [rsp], xmm0
000079bd661da71f  vmovaps [rsp+0x10], xmm1
000079bd661da725  vmovaps [rsp+0x20], xmm2
000079bd661da72b  vmovaps [rsp+0x30], xmm3
000079bd661da731  vmovaps [rsp+0x40], xmm4
000079bd661da737  vmovaps [rsp+0x50], xmm5
000079bd661da73d  vmovaps [rsp+0x60], xmm6
000079bd661da743  vmovaps [rsp+0x70], xmm7
000079bd661da749  vmovaps [rsp+0x80], xmm8
000079bd661da752  vmovaps [rsp+0x90], xmm9
000079bd661da75b  vmovaps [rsp+0xA0], xmm10
000079bd661da764  vmovaps [rsp+0xB0], xmm11
000079bd661da76d  vmovaps [rsp+0xC0], xmm12
000079bd661da776  vmovaps [rsp+0xD0], xmm13
000079bd661da77f  vmovaps [rsp+0xE0], xmm14
000079bd661da788  sub rsp, 0x30
000079bd661da78c  movaps [rsp], xmm15
000079bd661da791  movaps [rsp+0x10], xmm11
000079bd661da797  movaps [rsp+0x20], xmm6
000079bd661da79c  lea rdi, [rsp]
000079bd661da7a0  mov esi, 0x00
000079bd661da7a5  mov rax, 0x56EBD57B0530
000079bd661da7af  call rax
000079bd661da7b1  movaps xmm15, [rsp]
000079bd661da7b6  add rsp, 0x30
000079bd661da7ba  vmovaps xmm0, [rsp]
000079bd661da7bf  vmovaps xmm1, [rsp+0x10]
000079bd661da7c5  vmovaps xmm2, [rsp+0x20]
000079bd661da7cb  vmovaps xmm3, [rsp+0x30]
000079bd661da7d1  vmovaps xmm4, [rsp+0x40]
000079bd661da7d7  vmovaps xmm5, [rsp+0x50]
000079bd661da7dd  vmovaps xmm6, [rsp+0x60]
000079bd661da7e3  vmovaps xmm7, [rsp+0x70]
000079bd661da7e9  vmovaps xmm8, [rsp+0x80]
000079bd661da7f2  vmovaps xmm9, [rsp+0x90]
000079bd661da7fb  vmovaps xmm10, [rsp+0xA0]
000079bd661da804  vmovaps xmm11, [rsp+0xB0]
000079bd661da80d  vmovaps xmm12, [rsp+0xC0]
000079bd661da816  vmovaps xmm13, [rsp+0xD0]
000079bd661da81f  vmovaps xmm14, [rsp+0xE0]
000079bd661da828  add rsp, 0xF0
000079bd661da82f  pop r11
000079bd661da831  pop r10
000079bd661da833  pop r9
000079bd661da835  pop r8
000079bd661da837  pop rsi
000079bd661da838  pop rdi
000079bd661da839  pop rdx
000079bd661da83a  pop rcx
000079bd661da83b  pop rax
000079bd661da83c  add rsp, 0x08
000079bd661da840  jmp 0x000079BD661D64A5
000079bd661da845  sub rsp, 0x08
000079bd661da849  push rax
000079bd661da84a  push rcx
000079bd661da84b  push rdx
000079bd661da84c  push rdi
000079bd661da84d  push rsi
000079bd661da84e  push r8
000079bd661da850  push r9
000079bd661da852  push r10
000079bd661da854  push r11
000079bd661da856  sub rsp, 0xF0
000079bd661da85d  vmovaps [rsp], xmm0
000079bd661da862  vmovaps [rsp+0x10], xmm1
000079bd661da868  vmovaps [rsp+0x20], xmm2
000079bd661da86e  vmovaps [rsp+0x30], xmm3
000079bd661da874  vmovaps [rsp+0x40], xmm4
000079bd661da87a  vmovaps [rsp+0x50], xmm5
000079bd661da880  vmovaps [rsp+0x60], xmm6
000079bd661da886  vmovaps [rsp+0x70], xmm8
000079bd661da88c  vmovaps [rsp+0x80], xmm9
000079bd661da895  vmovaps [rsp+0x90], xmm10
000079bd661da89e  vmovaps [rsp+0xA0], xmm11
000079bd661da8a7  vmovaps [rsp+0xB0], xmm12
000079bd661da8b0  vmovaps [rsp+0xC0], xmm13
000079bd661da8b9  vmovaps [rsp+0xD0], xmm14
000079bd661da8c2  vmovaps [rsp+0xE0], xmm15
000079bd661da8cb  sub rsp, 0x30
000079bd661da8cf  movaps [rsp], xmm7
000079bd661da8d3  movaps [rsp+0x10], xmm11
000079bd661da8d9  movaps [rsp+0x20], xmm9
000079bd661da8df  lea rdi, [rsp]
000079bd661da8e3  mov esi, 0x00
000079bd661da8e8  mov rax, 0x56EBD57B0530
000079bd661da8f2  call rax
000079bd661da8f4  movaps xmm7, [rsp]
000079bd661da8f8  add rsp, 0x30
000079bd661da8fc  vmovaps xmm0, [rsp]
000079bd661da901  vmovaps xmm1, [rsp+0x10]
000079bd661da907  vmovaps xmm2, [rsp+0x20]
000079bd661da90d  vmovaps xmm3, [rsp+0x30]
000079bd661da913  vmovaps xmm4, [rsp+0x40]
000079bd661da919  vmovaps xmm5, [rsp+0x50]
000079bd661da91f  vmovaps xmm6, [rsp+0x60]
000079bd661da925  vmovaps xmm8, [rsp+0x70]
000079bd661da92b  vmovaps xmm9, [rsp+0x80]
000079bd661da934  vmovaps xmm10, [rsp+0x90]
000079bd661da93d  vmovaps xmm11, [rsp+0xA0]
000079bd661da946  vmovaps xmm12, [rsp+0xB0]
000079bd661da94f  vmovaps xmm13, [rsp+0xC0]
000079bd661da958  vmovaps xmm14, [rsp+0xD0]
000079bd661da961  vmovaps xmm15, [rsp+0xE0]
000079bd661da96a  add rsp, 0xF0
000079bd661da971  pop r11
000079bd661da973  pop r10
000079bd661da975  pop r9
000079bd661da977  pop r8
000079bd661da979  pop rsi
000079bd661da97a  pop rdi
000079bd661da97b  pop rdx
000079bd661da97c  pop rcx
000079bd661da97d  pop rax
000079bd661da97e  add rsp, 0x08
000079bd661da982  jmp 0x000079BD661D64D2
000079bd661da987  sub rsp, 0x08
000079bd661da98b  push rax
000079bd661da98c  push rcx
000079bd661da98d  push rdx
000079bd661da98e  push rdi
000079bd661da98f  push rsi
000079bd661da990  push r8
000079bd661da992  push r9
000079bd661da994  push r10
000079bd661da996  push r11
000079bd661da998  sub rsp, 0xF0
000079bd661da99f  vmovaps [rsp], xmm0
000079bd661da9a4  vmovaps [rsp+0x10], xmm1
000079bd661da9aa  vmovaps [rsp+0x20], xmm2
000079bd661da9b0  vmovaps [rsp+0x30], xmm3
000079bd661da9b6  vmovaps [rsp+0x40], xmm4
000079bd661da9bc  vmovaps [rsp+0x50], xmm5
000079bd661da9c2  vmovaps [rsp+0x60], xmm6
000079bd661da9c8  vmovaps [rsp+0x70], xmm7
000079bd661da9ce  vmovaps [rsp+0x80], xmm8
000079bd661da9d7  vmovaps [rsp+0x90], xmm9
000079bd661da9e0  vmovaps [rsp+0xA0], xmm10
000079bd661da9e9  vmovaps [rsp+0xB0], xmm12
000079bd661da9f2  vmovaps [rsp+0xC0], xmm13
000079bd661da9fb  vmovaps [rsp+0xD0], xmm14
000079bd661daa04  vmovaps [rsp+0xE0], xmm15
000079bd661daa0d  sub rsp, 0x30
000079bd661daa11  movaps [rsp], xmm11
000079bd661daa16  movaps [rsp+0x10], xmm10
000079bd661daa1c  movaps [rsp+0x20], xmm14
000079bd661daa22  lea rdi, [rsp]
000079bd661daa26  mov esi, 0x00
000079bd661daa2b  mov rax, 0x56EBD57B0530
000079bd661daa35  call rax
000079bd661daa37  movaps xmm11, [rsp]
000079bd661daa3c  add rsp, 0x30
000079bd661daa40  vmovaps xmm0, [rsp]
000079bd661daa45  vmovaps xmm1, [rsp+0x10]
000079bd661daa4b  vmovaps xmm2, [rsp+0x20]
000079bd661daa51  vmovaps xmm3, [rsp+0x30]
000079bd661daa57  vmovaps xmm4, [rsp+0x40]
000079bd661daa5d  vmovaps xmm5, [rsp+0x50]
000079bd661daa63  vmovaps xmm6, [rsp+0x60]
000079bd661daa69  vmovaps xmm7, [rsp+0x70]
000079bd661daa6f  vmovaps xmm8, [rsp+0x80]
000079bd661daa78  vmovaps xmm9, [rsp+0x90]
000079bd661daa81  vmovaps xmm10, [rsp+0xA0]
000079bd661daa8a  vmovaps xmm12, [rsp+0xB0]
000079bd661daa93  vmovaps xmm13, [rsp+0xC0]
000079bd661daa9c  vmovaps xmm14, [rsp+0xD0]
000079bd661daaa5  vmovaps xmm15, [rsp+0xE0]
000079bd661daaae  add rsp, 0xF0
000079bd661daab5  pop r11
000079bd661daab7  pop r10
000079bd661daab9  pop r9
000079bd661daabb  pop r8
000079bd661daabd  pop rsi
000079bd661daabe  pop rdi
000079bd661daabf  pop rdx
000079bd661daac0  pop rcx
000079bd661daac1  pop rax
000079bd661daac2  add rsp, 0x08
000079bd661daac6  jmp 0x000079BD661D64ED
000079bd661daacb  call 0x000079BD660E45A0
000079bd661daad0  jmp 0x000079BD661D64F7
000079bd661daad5  sub rsp, 0x08
000079bd661daad9  push rax
000079bd661daada  push rcx
000079bd661daadb  push rdx
000079bd661daadc  push rdi
000079bd661daadd  push rsi
000079bd661daade  push r8
000079bd661daae0  push r9
000079bd661daae2  push r10
000079bd661daae4  push r11
000079bd661daae6  sub rsp, 0xF0
000079bd661daaed  vmovaps [rsp], xmm0
000079bd661daaf2  vmovaps [rsp+0x10], xmm1
000079bd661daaf8  vmovaps [rsp+0x20], xmm2
000079bd661daafe  vmovaps [rsp+0x30], xmm3
000079bd661dab04  vmovaps [rsp+0x40], xmm4
000079bd661dab0a  vmovaps [rsp+0x50], xmm5
000079bd661dab10  vmovaps [rsp+0x60], xmm6
000079bd661dab16  vmovaps [rsp+0x70], xmm7
000079bd661dab1c  vmovaps [rsp+0x80], xmm8
000079bd661dab25  vmovaps [rsp+0x90], xmm9
000079bd661dab2e  vmovaps [rsp+0xA0], xmm11
000079bd661dab37  vmovaps [rsp+0xB0], xmm12
000079bd661dab40  vmovaps [rsp+0xC0], xmm13
000079bd661dab49  vmovaps [rsp+0xD0], xmm14
000079bd661dab52  vmovaps [rsp+0xE0], xmm15
000079bd661dab5b  sub rsp, 0x30
000079bd661dab5f  movaps [rsp], xmm10
000079bd661dab64  movaps [rsp+0x10], xmm1
000079bd661dab69  movaps [rsp+0x20], xmm12
000079bd661dab6f  lea rdi, [rsp]
000079bd661dab73  mov esi, 0x00
000079bd661dab78  mov rax, 0x56EBD57B0530
000079bd661dab82  call rax
000079bd661dab84  movaps xmm10, [rsp]
000079bd661dab89  add rsp, 0x30
000079bd661dab8d  vmovaps xmm0, [rsp]
000079bd661dab92  vmovaps xmm1, [rsp+0x10]
000079bd661dab98  vmovaps xmm2, [rsp+0x20]
000079bd661dab9e  vmovaps xmm3, [rsp+0x30]
000079bd661daba4  vmovaps xmm4, [rsp+0x40]
000079bd661dabaa  vmovaps xmm5, [rsp+0x50]
000079bd661dabb0  vmovaps xmm6, [rsp+0x60]
000079bd661dabb6  vmovaps xmm7, [rsp+0x70]
000079bd661dabbc  vmovaps xmm8, [rsp+0x80]
000079bd661dabc5  vmovaps xmm9, [rsp+0x90]
000079bd661dabce  vmovaps xmm11, [rsp+0xA0]
000079bd661dabd7  vmovaps xmm12, [rsp+0xB0]
000079bd661dabe0  vmovaps xmm13, [rsp+0xC0]
000079bd661dabe9  vmovaps xmm14, [rsp+0xD0]
000079bd661dabf2  vmovaps xmm15, [rsp+0xE0]
000079bd661dabfb  add rsp, 0xF0
000079bd661dac02  pop r11
000079bd661dac04  pop r10
000079bd661dac06  pop r9
000079bd661dac08  pop r8
000079bd661dac0a  pop rsi
000079bd661dac0b  pop rdi
000079bd661dac0c  pop rdx
000079bd661dac0d  pop rcx
000079bd661dac0e  pop rax
000079bd661dac0f  add rsp, 0x08
000079bd661dac13  jmp 0x000079BD661D651A
000079bd661dac18  sub rsp, 0x08
000079bd661dac1c  push rax
000079bd661dac1d  push rcx
000079bd661dac1e  push rdx
000079bd661dac1f  push rdi
000079bd661dac20  push rsi
000079bd661dac21  push r8
000079bd661dac23  push r9
000079bd661dac25  push r10
000079bd661dac27  push r11
000079bd661dac29  sub rsp, 0xF0
000079bd661dac30  vmovaps [rsp], xmm0
000079bd661dac35  vmovaps [rsp+0x10], xmm1
000079bd661dac3b  vmovaps [rsp+0x20], xmm2
000079bd661dac41  vmovaps [rsp+0x30], xmm3
000079bd661dac47  vmovaps [rsp+0x40], xmm4
000079bd661dac4d  vmovaps [rsp+0x50], xmm5
000079bd661dac53  vmovaps [rsp+0x60], xmm6
000079bd661dac59  vmovaps [rsp+0x70], xmm7
000079bd661dac5f  vmovaps [rsp+0x80], xmm8
000079bd661dac68  vmovaps [rsp+0x90], xmm9
000079bd661dac71  vmovaps [rsp+0xA0], xmm10
000079bd661dac7a  vmovaps [rsp+0xB0], xmm11
000079bd661dac83  vmovaps [rsp+0xC0], xmm13
000079bd661dac8c  vmovaps [rsp+0xD0], xmm14
000079bd661dac95  vmovaps [rsp+0xE0], xmm15
000079bd661dac9e  sub rsp, 0x30
000079bd661daca2  movaps [rsp], xmm12
000079bd661daca7  movaps [rsp+0x10], xmm14
000079bd661dacad  movaps [rsp+0x20], xmm1
000079bd661dacb2  lea rdi, [rsp]
000079bd661dacb6  mov esi, 0x00
000079bd661dacbb  mov rax, 0x56EBD57B0530
000079bd661dacc5  call rax
000079bd661dacc7  movaps xmm12, [rsp]
000079bd661daccc  add rsp, 0x30
000079bd661dacd0  vmovaps xmm0, [rsp]
000079bd661dacd5  vmovaps xmm1, [rsp+0x10]
000079bd661dacdb  vmovaps xmm2, [rsp+0x20]
000079bd661dace1  vmovaps xmm3, [rsp+0x30]
000079bd661dace7  vmovaps xmm4, [rsp+0x40]
000079bd661daced  vmovaps xmm5, [rsp+0x50]
000079bd661dacf3  vmovaps xmm6, [rsp+0x60]
000079bd661dacf9  vmovaps xmm7, [rsp+0x70]
000079bd661dacff  vmovaps xmm8, [rsp+0x80]
000079bd661dad08  vmovaps xmm9, [rsp+0x90]
000079bd661dad11  vmovaps xmm10, [rsp+0xA0]
000079bd661dad1a  vmovaps xmm11, [rsp+0xB0]
000079bd661dad23  vmovaps xmm13, [rsp+0xC0]
000079bd661dad2c  vmovaps xmm14, [rsp+0xD0]
000079bd661dad35  vmovaps xmm15, [rsp+0xE0]
000079bd661dad3e  add rsp, 0xF0
000079bd661dad45  pop r11
000079bd661dad47  pop r10
000079bd661dad49  pop r9
000079bd661dad4b  pop r8
000079bd661dad4d  pop rsi
000079bd661dad4e  pop rdi
000079bd661dad4f  pop rdx
000079bd661dad50  pop rcx
000079bd661dad51  pop rax
000079bd661dad52  add rsp, 0x08
000079bd661dad56  jmp 0x000079BD661D6549
000079bd661dad5b  sub rsp, 0x08
000079bd661dad5f  push rax
000079bd661dad60  push rcx
000079bd661dad61  push rdx
000079bd661dad62  push rdi
000079bd661dad63  push rsi
000079bd661dad64  push r8
000079bd661dad66  push r9
000079bd661dad68  push r10
000079bd661dad6a  push r11
000079bd661dad6c  sub rsp, 0xF0
000079bd661dad73  vmovaps [rsp], xmm0
000079bd661dad78  vmovaps [rsp+0x10], xmm1
000079bd661dad7e  vmovaps [rsp+0x20], xmm2
000079bd661dad84  vmovaps [rsp+0x30], xmm3
000079bd661dad8a  vmovaps [rsp+0x40], xmm4
000079bd661dad90  vmovaps [rsp+0x50], xmm5
000079bd661dad96  vmovaps [rsp+0x60], xmm6
000079bd661dad9c  vmovaps [rsp+0x70], xmm7
000079bd661dada2  vmovaps [rsp+0x80], xmm8
000079bd661dadab  vmovaps [rsp+0x90], xmm9
000079bd661dadb4  vmovaps [rsp+0xA0], xmm10
000079bd661dadbd  vmovaps [rsp+0xB0], xmm11
000079bd661dadc6  vmovaps [rsp+0xC0], xmm12
000079bd661dadcf  vmovaps [rsp+0xD0], xmm13
000079bd661dadd8  vmovaps [rsp+0xE0], xmm15
000079bd661dade1  sub rsp, 0x30
000079bd661dade5  movaps [rsp], xmm14
000079bd661dadea  movaps [rsp+0x10], xmm9
000079bd661dadf0  movaps [rsp+0x20], xmm1
000079bd661dadf5  lea rdi, [rsp]
000079bd661dadf9  mov esi, 0x00
000079bd661dadfe  mov rax, 0x56EBD57B0530
000079bd661dae08  call rax
000079bd661dae0a  movaps xmm14, [rsp]
000079bd661dae0f  add rsp, 0x30
000079bd661dae13  vmovaps xmm0, [rsp]
000079bd661dae18  vmovaps xmm1, [rsp+0x10]
000079bd661dae1e  vmovaps xmm2, [rsp+0x20]
000079bd661dae24  vmovaps xmm3, [rsp+0x30]
000079bd661dae2a  vmovaps xmm4, [rsp+0x40]
000079bd661dae30  vmovaps xmm5, [rsp+0x50]
000079bd661dae36  vmovaps xmm6, [rsp+0x60]
000079bd661dae3c  vmovaps xmm7, [rsp+0x70]
000079bd661dae42  vmovaps xmm8, [rsp+0x80]
000079bd661dae4b  vmovaps xmm9, [rsp+0x90]
000079bd661dae54  vmovaps xmm10, [rsp+0xA0]
000079bd661dae5d  vmovaps xmm11, [rsp+0xB0]
000079bd661dae66  vmovaps xmm12, [rsp+0xC0]
000079bd661dae6f  vmovaps xmm13, [rsp+0xD0]
000079bd661dae78  vmovaps xmm15, [rsp+0xE0]
000079bd661dae81  add rsp, 0xF0
000079bd661dae88  pop r11
000079bd661dae8a  pop r10
000079bd661dae8c  pop r9
000079bd661dae8e  pop r8
000079bd661dae90  pop rsi
000079bd661dae91  pop rdi
000079bd661dae92  pop rdx
000079bd661dae93  pop rcx
000079bd661dae94  pop rax
000079bd661dae95  add rsp, 0x08
000079bd661dae99  jmp 0x000079BD661D6578
000079bd661dae9e  sub rsp, 0x08
000079bd661daea2  push rax
000079bd661daea3  push rcx
000079bd661daea4  push rdx
000079bd661daea5  push rdi
000079bd661daea6  push rsi
000079bd661daea7  push r8
000079bd661daea9  push r9
000079bd661daeab  push r10
000079bd661daead  push r11
000079bd661daeaf  sub rsp, 0xF0
000079bd661daeb6  vmovaps [rsp], xmm0
000079bd661daebb  vmovaps [rsp+0x10], xmm2
000079bd661daec1  vmovaps [rsp+0x20], xmm3
000079bd661daec7  vmovaps [rsp+0x30], xmm4
000079bd661daecd  vmovaps [rsp+0x40], xmm5
000079bd661daed3  vmovaps [rsp+0x50], xmm6
000079bd661daed9  vmovaps [rsp+0x60], xmm7
000079bd661daedf  vmovaps [rsp+0x70], xmm8
000079bd661daee5  vmovaps [rsp+0x80], xmm9
000079bd661daeee  vmovaps [rsp+0x90], xmm10
000079bd661daef7  vmovaps [rsp+0xA0], xmm11
000079bd661daf00  vmovaps [rsp+0xB0], xmm12
000079bd661daf09  vmovaps [rsp+0xC0], xmm13
000079bd661daf12  vmovaps [rsp+0xD0], xmm14
000079bd661daf1b  vmovaps [rsp+0xE0], xmm15
000079bd661daf24  sub rsp, 0x30
000079bd661daf28  movaps [rsp], xmm1
000079bd661daf2c  movaps [rsp+0x10], xmm13
000079bd661daf32  movaps [rsp+0x20], xmm8
000079bd661daf38  lea rdi, [rsp]
000079bd661daf3c  mov esi, 0x00
000079bd661daf41  mov rax, 0x56EBD57B0530
000079bd661daf4b  call rax
000079bd661daf4d  movaps xmm1, [rsp]
000079bd661daf51  add rsp, 0x30
000079bd661daf55  vmovaps xmm0, [rsp]
000079bd661daf5a  vmovaps xmm2, [rsp+0x10]
000079bd661daf60  vmovaps xmm3, [rsp+0x20]
000079bd661daf66  vmovaps xmm4, [rsp+0x30]
000079bd661daf6c  vmovaps xmm5, [rsp+0x40]
000079bd661daf72  vmovaps xmm6, [rsp+0x50]
000079bd661daf78  vmovaps xmm7, [rsp+0x60]
000079bd661daf7e  vmovaps xmm8, [rsp+0x70]
000079bd661daf84  vmovaps xmm9, [rsp+0x80]
000079bd661daf8d  vmovaps xmm10, [rsp+0x90]
000079bd661daf96  vmovaps xmm11, [rsp+0xA0]
000079bd661daf9f  vmovaps xmm12, [rsp+0xB0]
000079bd661dafa8  vmovaps xmm13, [rsp+0xC0]
000079bd661dafb1  vmovaps xmm14, [rsp+0xD0]
000079bd661dafba  vmovaps xmm15, [rsp+0xE0]
000079bd661dafc3  add rsp, 0xF0
000079bd661dafca  pop r11
000079bd661dafcc  pop r10
000079bd661dafce  pop r9
000079bd661dafd0  pop r8
000079bd661dafd2  pop rsi
000079bd661dafd3  pop rdi
000079bd661dafd4  pop rdx
000079bd661dafd5  pop rcx
000079bd661dafd6  pop rax
000079bd661dafd7  add rsp, 0x08
000079bd661dafdb  jmp 0x000079BD661D659A
000079bd661dafe0  call 0x000079BD6600C260
000079bd661dafe5  jmp 0x000079BD661D65A8
000079bd661dafea  call 0x000079BD660DE950
000079bd661dafef  jmp 0x000079BD661D65B2
000079bd661daff4  sub rsp, 0x08
000079bd661daff8  push rax
000079bd661daff9  push rcx
000079bd661daffa  push rdx
000079bd661daffb  push rdi
000079bd661daffc  push rsi
000079bd661daffd  push r8
000079bd661dafff  push r9
000079bd661db001  push r10
000079bd661db003  push r11
000079bd661db005  sub rsp, 0xF0
000079bd661db00c  vmovaps [rsp], xmm0
000079bd661db011  vmovaps [rsp+0x10], xmm1
000079bd661db017  vmovaps [rsp+0x20], xmm2
000079bd661db01d  vmovaps [rsp+0x30], xmm3
000079bd661db023  vmovaps [rsp+0x40], xmm4
000079bd661db029  vmovaps [rsp+0x50], xmm5
000079bd661db02f  vmovaps [rsp+0x60], xmm6
000079bd661db035  vmovaps [rsp+0x70], xmm7
000079bd661db03b  vmovaps [rsp+0x80], xmm9
000079bd661db044  vmovaps [rsp+0x90], xmm10
000079bd661db04d  vmovaps [rsp+0xA0], xmm11
000079bd661db056  vmovaps [rsp+0xB0], xmm12
000079bd661db05f  vmovaps [rsp+0xC0], xmm13
000079bd661db068  vmovaps [rsp+0xD0], xmm14
000079bd661db071  vmovaps [rsp+0xE0], xmm15
000079bd661db07a  sub rsp, 0x30
000079bd661db07e  movaps [rsp], xmm8
000079bd661db083  movaps [rsp+0x10], xmm15
000079bd661db089  movaps [rsp+0x20], xmm7
000079bd661db08e  lea rdi, [rsp]
000079bd661db092  mov esi, 0x00
000079bd661db097  mov rax, 0x56EBD57B0530
000079bd661db0a1  call rax
000079bd661db0a3  movaps xmm8, [rsp]
000079bd661db0a8  add rsp, 0x30
000079bd661db0ac  vmovaps xmm0, [rsp]
000079bd661db0b1  vmovaps xmm1, [rsp+0x10]
000079bd661db0b7  vmovaps xmm2, [rsp+0x20]
000079bd661db0bd  vmovaps xmm3, [rsp+0x30]
000079bd661db0c3  vmovaps xmm4, [rsp+0x40]
000079bd661db0c9  vmovaps xmm5, [rsp+0x50]
000079bd661db0cf  vmovaps xmm6, [rsp+0x60]
000079bd661db0d5  vmovaps xmm7, [rsp+0x70]
000079bd661db0db  vmovaps xmm9, [rsp+0x80]
000079bd661db0e4  vmovaps xmm10, [rsp+0x90]
000079bd661db0ed  vmovaps xmm11, [rsp+0xA0]
000079bd661db0f6  vmovaps xmm12, [rsp+0xB0]
000079bd661db0ff  vmovaps xmm13, [rsp+0xC0]
000079bd661db108  vmovaps xmm14, [rsp+0xD0]
000079bd661db111  vmovaps xmm15, [rsp+0xE0]
000079bd661db11a  add rsp, 0xF0
000079bd661db121  pop r11
000079bd661db123  pop r10
000079bd661db125  pop r9
000079bd661db127  pop r8
000079bd661db129  pop rsi
000079bd661db12a  pop rdi
000079bd661db12b  pop rdx
000079bd661db12c  pop rcx
000079bd661db12d  pop rax
000079bd661db12e  add rsp, 0x08
000079bd661db132  jmp 0x000079BD661D65D4
000079bd661db137  sub rsp, 0x08
000079bd661db13b  push rax
000079bd661db13c  push rcx
000079bd661db13d  push rdx
000079bd661db13e  push rdi
000079bd661db13f  push rsi
000079bd661db140  push r8
000079bd661db142  push r9
000079bd661db144  push r10
000079bd661db146  push r11
000079bd661db148  sub rsp, 0xF0
000079bd661db14f  vmovaps [rsp], xmm0
000079bd661db154  vmovaps [rsp+0x10], xmm1
000079bd661db15a  vmovaps [rsp+0x20], xmm2
000079bd661db160  vmovaps [rsp+0x30], xmm3
000079bd661db166  vmovaps [rsp+0x40], xmm4
000079bd661db16c  vmovaps [rsp+0x50], xmm5
000079bd661db172  vmovaps [rsp+0x60], xmm6
000079bd661db178  vmovaps [rsp+0x70], xmm8
000079bd661db17e  vmovaps [rsp+0x80], xmm9
000079bd661db187  vmovaps [rsp+0x90], xmm10
000079bd661db190  vmovaps [rsp+0xA0], xmm11
000079bd661db199  vmovaps [rsp+0xB0], xmm12
000079bd661db1a2  vmovaps [rsp+0xC0], xmm13
000079bd661db1ab  vmovaps [rsp+0xD0], xmm14
000079bd661db1b4  vmovaps [rsp+0xE0], xmm15
000079bd661db1bd  sub rsp, 0x30
000079bd661db1c1  movaps [rsp], xmm7
000079bd661db1c5  movaps [rsp+0x10], xmm9
000079bd661db1cb  movaps [rsp+0x20], xmm15
000079bd661db1d1  lea rdi, [rsp]
000079bd661db1d5  mov esi, 0x00
000079bd661db1da  mov rax, 0x56EBD57B0530
000079bd661db1e4  call rax
000079bd661db1e6  movaps xmm7, [rsp]
000079bd661db1ea  add rsp, 0x30
000079bd661db1ee  vmovaps xmm0, [rsp]
000079bd661db1f3  vmovaps xmm1, [rsp+0x10]
000079bd661db1f9  vmovaps xmm2, [rsp+0x20]
000079bd661db1ff  vmovaps xmm3, [rsp+0x30]
000079bd661db205  vmovaps xmm4, [rsp+0x40]
000079bd661db20b  vmovaps xmm5, [rsp+0x50]
000079bd661db211  vmovaps xmm6, [rsp+0x60]
000079bd661db217  vmovaps xmm8, [rsp+0x70]
000079bd661db21d  vmovaps xmm9, [rsp+0x80]
000079bd661db226  vmovaps xmm10, [rsp+0x90]
000079bd661db22f  vmovaps xmm11, [rsp+0xA0]
000079bd661db238  vmovaps xmm12, [rsp+0xB0]
000079bd661db241  vmovaps xmm13, [rsp+0xC0]
000079bd661db24a  vmovaps xmm14, [rsp+0xD0]
000079bd661db253  vmovaps xmm15, [rsp+0xE0]
000079bd661db25c  add rsp, 0xF0
000079bd661db263  pop r11
000079bd661db265  pop r10
000079bd661db267  pop r9
000079bd661db269  pop r8
000079bd661db26b  pop rsi
000079bd661db26c  pop rdi
000079bd661db26d  pop rdx
000079bd661db26e  pop rcx
000079bd661db26f  pop rax
000079bd661db270  add rsp, 0x08
000079bd661db274  jmp 0x000079BD661D6601
000079bd661db279  sub rsp, 0x08
000079bd661db27d  push rax
000079bd661db27e  push rcx
000079bd661db27f  push rdx
000079bd661db280  push rdi
000079bd661db281  push rsi
000079bd661db282  push r8
000079bd661db284  push r9
000079bd661db286  push r10
000079bd661db288  push r11
000079bd661db28a  sub rsp, 0xF0
000079bd661db291  vmovaps [rsp], xmm0
000079bd661db296  vmovaps [rsp+0x10], xmm1
000079bd661db29c  vmovaps [rsp+0x20], xmm2
000079bd661db2a2  vmovaps [rsp+0x30], xmm3
000079bd661db2a8  vmovaps [rsp+0x40], xmm4
000079bd661db2ae  vmovaps [rsp+0x50], xmm5
000079bd661db2b4  vmovaps [rsp+0x60], xmm6
000079bd661db2ba  vmovaps [rsp+0x70], xmm7
000079bd661db2c0  vmovaps [rsp+0x80], xmm8
000079bd661db2c9  vmovaps [rsp+0x90], xmm10
000079bd661db2d2  vmovaps [rsp+0xA0], xmm11
000079bd661db2db  vmovaps [rsp+0xB0], xmm12
000079bd661db2e4  vmovaps [rsp+0xC0], xmm13
000079bd661db2ed  vmovaps [rsp+0xD0], xmm14
000079bd661db2f6  vmovaps [rsp+0xE0], xmm15
000079bd661db2ff  sub rsp, 0x30
000079bd661db303  movaps [rsp], xmm9
000079bd661db308  movaps [rsp+0x10], xmm13
000079bd661db30e  movaps [rsp+0x20], xmm15
000079bd661db314  lea rdi, [rsp]
000079bd661db318  mov esi, 0x00
000079bd661db31d  mov rax, 0x56EBD57B0530
000079bd661db327  call rax
000079bd661db329  movaps xmm9, [rsp]
000079bd661db32e  add rsp, 0x30
000079bd661db332  vmovaps xmm0, [rsp]
000079bd661db337  vmovaps xmm1, [rsp+0x10]
000079bd661db33d  vmovaps xmm2, [rsp+0x20]
000079bd661db343  vmovaps xmm3, [rsp+0x30]
000079bd661db349  vmovaps xmm4, [rsp+0x40]
000079bd661db34f  vmovaps xmm5, [rsp+0x50]
000079bd661db355  vmovaps xmm6, [rsp+0x60]
000079bd661db35b  vmovaps xmm7, [rsp+0x70]
000079bd661db361  vmovaps xmm8, [rsp+0x80]
000079bd661db36a  vmovaps xmm10, [rsp+0x90]
000079bd661db373  vmovaps xmm11, [rsp+0xA0]
000079bd661db37c  vmovaps xmm12, [rsp+0xB0]
000079bd661db385  vmovaps xmm13, [rsp+0xC0]
000079bd661db38e  vmovaps xmm14, [rsp+0xD0]
000079bd661db397  vmovaps xmm15, [rsp+0xE0]
000079bd661db3a0  add rsp, 0xF0
000079bd661db3a7  pop r11
000079bd661db3a9  pop r10
000079bd661db3ab  pop r9
000079bd661db3ad  pop r8
000079bd661db3af  pop rsi
000079bd661db3b0  pop rdi
000079bd661db3b1  pop rdx
000079bd661db3b2  pop rcx
000079bd661db3b3  pop rax
000079bd661db3b4  add rsp, 0x08
000079bd661db3b8  jmp 0x000079BD661D662F
000079bd661db3bd  sub rsp, 0x08
000079bd661db3c1  push rax
000079bd661db3c2  push rcx
000079bd661db3c3  push rdx
000079bd661db3c4  push rdi
000079bd661db3c5  push rsi
000079bd661db3c6  push r8
000079bd661db3c8  push r9
000079bd661db3ca  push r10
000079bd661db3cc  push r11
000079bd661db3ce  sub rsp, 0xF0
000079bd661db3d5  vmovaps [rsp], xmm0
000079bd661db3da  vmovaps [rsp+0x10], xmm1
000079bd661db3e0  vmovaps [rsp+0x20], xmm2
000079bd661db3e6  vmovaps [rsp+0x30], xmm3
000079bd661db3ec  vmovaps [rsp+0x40], xmm4
000079bd661db3f2  vmovaps [rsp+0x50], xmm5
000079bd661db3f8  vmovaps [rsp+0x60], xmm6
000079bd661db3fe  vmovaps [rsp+0x70], xmm7
000079bd661db404  vmovaps [rsp+0x80], xmm8
000079bd661db40d  vmovaps [rsp+0x90], xmm9
000079bd661db416  vmovaps [rsp+0xA0], xmm10
000079bd661db41f  vmovaps [rsp+0xB0], xmm11
000079bd661db428  vmovaps [rsp+0xC0], xmm12
000079bd661db431  vmovaps [rsp+0xD0], xmm13
000079bd661db43a  vmovaps [rsp+0xE0], xmm14
000079bd661db443  sub rsp, 0x30
000079bd661db447  movaps [rsp], xmm15
000079bd661db44c  movaps [rsp+0x10], xmm11
000079bd661db452  movaps [rsp+0x20], xmm12
000079bd661db458  lea rdi, [rsp]
000079bd661db45c  mov esi, 0x00
000079bd661db461  mov rax, 0x56EBD57B0530
000079bd661db46b  call rax
000079bd661db46d  movaps xmm15, [rsp]
000079bd661db472  add rsp, 0x30
000079bd661db476  vmovaps xmm0, [rsp]
000079bd661db47b  vmovaps xmm1, [rsp+0x10]
000079bd661db481  vmovaps xmm2, [rsp+0x20]
000079bd661db487  vmovaps xmm3, [rsp+0x30]
000079bd661db48d  vmovaps xmm4, [rsp+0x40]
000079bd661db493  vmovaps xmm5, [rsp+0x50]
000079bd661db499  vmovaps xmm6, [rsp+0x60]
000079bd661db49f  vmovaps xmm7, [rsp+0x70]
000079bd661db4a5  vmovaps xmm8, [rsp+0x80]
000079bd661db4ae  vmovaps xmm9, [rsp+0x90]
000079bd661db4b7  vmovaps xmm10, [rsp+0xA0]
000079bd661db4c0  vmovaps xmm11, [rsp+0xB0]
000079bd661db4c9  vmovaps xmm12, [rsp+0xC0]
000079bd661db4d2  vmovaps xmm13, [rsp+0xD0]
000079bd661db4db  vmovaps xmm14, [rsp+0xE0]
000079bd661db4e4  add rsp, 0xF0
000079bd661db4eb  pop r11
000079bd661db4ed  pop r10
000079bd661db4ef  pop r9
000079bd661db4f1  pop r8
000079bd661db4f3  pop rsi
000079bd661db4f4  pop rdi
000079bd661db4f5  pop rdx
000079bd661db4f6  pop rcx
000079bd661db4f7  pop rax
000079bd661db4f8  add rsp, 0x08
000079bd661db4fc  jmp 0x000079BD661D664A
000079bd661db501  sub rsp, 0x08
000079bd661db505  push rax
000079bd661db506  push rcx
000079bd661db507  push rdx
000079bd661db508  push rdi
000079bd661db509  push rsi
000079bd661db50a  push r8
000079bd661db50c  push r9
000079bd661db50e  push r10
000079bd661db510  push r11
000079bd661db512  sub rsp, 0xF0
000079bd661db519  vmovaps [rsp], xmm0
000079bd661db51e  vmovaps [rsp+0x10], xmm1
000079bd661db524  vmovaps [rsp+0x20], xmm2
000079bd661db52a  vmovaps [rsp+0x30], xmm3
000079bd661db530  vmovaps [rsp+0x40], xmm4
000079bd661db536  vmovaps [rsp+0x50], xmm5
000079bd661db53c  vmovaps [rsp+0x60], xmm6
000079bd661db542  vmovaps [rsp+0x70], xmm7
000079bd661db548  vmovaps [rsp+0x80], xmm8
000079bd661db551  vmovaps [rsp+0x90], xmm9
000079bd661db55a  vmovaps [rsp+0xA0], xmm10
000079bd661db563  vmovaps [rsp+0xB0], xmm11
000079bd661db56c  vmovaps [rsp+0xC0], xmm12
000079bd661db575  vmovaps [rsp+0xD0], xmm14
000079bd661db57e  vmovaps [rsp+0xE0], xmm15
000079bd661db587  sub rsp, 0x30
000079bd661db58b  movaps [rsp], xmm13
000079bd661db590  movaps [rsp+0x10], xmm10
000079bd661db596  movaps [rsp+0x20], xmm14
000079bd661db59c  lea rdi, [rsp]
000079bd661db5a0  mov esi, 0x00
000079bd661db5a5  mov rax, 0x56EBD57B0530
000079bd661db5af  call rax
000079bd661db5b1  movaps xmm13, [rsp]
000079bd661db5b6  add rsp, 0x30
000079bd661db5ba  vmovaps xmm0, [rsp]
000079bd661db5bf  vmovaps xmm1, [rsp+0x10]
000079bd661db5c5  vmovaps xmm2, [rsp+0x20]
000079bd661db5cb  vmovaps xmm3, [rsp+0x30]
000079bd661db5d1  vmovaps xmm4, [rsp+0x40]
000079bd661db5d7  vmovaps xmm5, [rsp+0x50]
000079bd661db5dd  vmovaps xmm6, [rsp+0x60]
000079bd661db5e3  vmovaps xmm7, [rsp+0x70]
000079bd661db5e9  vmovaps xmm8, [rsp+0x80]
000079bd661db5f2  vmovaps xmm9, [rsp+0x90]
000079bd661db5fb  vmovaps xmm10, [rsp+0xA0]
000079bd661db604  vmovaps xmm11, [rsp+0xB0]
000079bd661db60d  vmovaps xmm12, [rsp+0xC0]
000079bd661db616  vmovaps xmm14, [rsp+0xD0]
000079bd661db61f  vmovaps xmm15, [rsp+0xE0]
000079bd661db628  add rsp, 0xF0
000079bd661db62f  pop r11
000079bd661db631  pop r10
000079bd661db633  pop r9
000079bd661db635  pop r8
000079bd661db637  pop rsi
000079bd661db638  pop rdi
000079bd661db639  pop rdx
000079bd661db63a  pop rcx
000079bd661db63b  pop rax
000079bd661db63c  add rsp, 0x08
000079bd661db640  jmp 0x000079BD661D666D
000079bd661db645  sub rsp, 0x08
000079bd661db649  push rax
000079bd661db64a  push rcx
000079bd661db64b  push rdx
000079bd661db64c  push rdi
000079bd661db64d  push rsi
000079bd661db64e  push r8
000079bd661db650  push r9
000079bd661db652  push r10
000079bd661db654  push r11
000079bd661db656  sub rsp, 0xF0
000079bd661db65d  vmovaps [rsp], xmm0
000079bd661db662  vmovaps [rsp+0x10], xmm1
000079bd661db668  vmovaps [rsp+0x20], xmm2
000079bd661db66e  vmovaps [rsp+0x30], xmm3
000079bd661db674  vmovaps [rsp+0x40], xmm4
000079bd661db67a  vmovaps [rsp+0x50], xmm5
000079bd661db680  vmovaps [rsp+0x60], xmm6
000079bd661db686  vmovaps [rsp+0x70], xmm7
000079bd661db68c  vmovaps [rsp+0x80], xmm8
000079bd661db695  vmovaps [rsp+0x90], xmm9
000079bd661db69e  vmovaps [rsp+0xA0], xmm10
000079bd661db6a7  vmovaps [rsp+0xB0], xmm11
000079bd661db6b0  vmovaps [rsp+0xC0], xmm12
000079bd661db6b9  vmovaps [rsp+0xD0], xmm13
000079bd661db6c2  vmovaps [rsp+0xE0], xmm15
000079bd661db6cb  sub rsp, 0x30
000079bd661db6cf  movaps [rsp], xmm14
000079bd661db6d4  movaps [rsp+0x10], xmm1
000079bd661db6d9  movaps [rsp+0x20], xmm7
000079bd661db6de  lea rdi, [rsp]
000079bd661db6e2  mov esi, 0x00
000079bd661db6e7  mov rax, 0x56EBD57B0530
000079bd661db6f1  call rax
000079bd661db6f3  movaps xmm14, [rsp]
000079bd661db6f8  add rsp, 0x30
000079bd661db6fc  vmovaps xmm0, [rsp]
000079bd661db701  vmovaps xmm1, [rsp+0x10]
000079bd661db707  vmovaps xmm2, [rsp+0x20]
000079bd661db70d  vmovaps xmm3, [rsp+0x30]
000079bd661db713  vmovaps xmm4, [rsp+0x40]
000079bd661db719  vmovaps xmm5, [rsp+0x50]
000079bd661db71f  vmovaps xmm6, [rsp+0x60]
000079bd661db725  vmovaps xmm7, [rsp+0x70]
000079bd661db72b  vmovaps xmm8, [rsp+0x80]
000079bd661db734  vmovaps xmm9, [rsp+0x90]
000079bd661db73d  vmovaps xmm10, [rsp+0xA0]
000079bd661db746  vmovaps xmm11, [rsp+0xB0]
000079bd661db74f  vmovaps xmm12, [rsp+0xC0]
000079bd661db758  vmovaps xmm13, [rsp+0xD0]
000079bd661db761  vmovaps xmm15, [rsp+0xE0]
000079bd661db76a  add rsp, 0xF0
000079bd661db771  pop r11
000079bd661db773  pop r10
000079bd661db775  pop r9
000079bd661db777  pop r8
000079bd661db779  pop rsi
000079bd661db77a  pop rdi
000079bd661db77b  pop rdx
000079bd661db77c  pop rcx
000079bd661db77d  pop rax
000079bd661db77e  add rsp, 0x08
000079bd661db782  jmp 0x000079BD661D6690
000079bd661db787  sub rsp, 0x08
000079bd661db78b  push rax
000079bd661db78c  push rcx
000079bd661db78d  push rdx
000079bd661db78e  push rdi
000079bd661db78f  push rsi
000079bd661db790  push r8
000079bd661db792  push r9
000079bd661db794  push r10
000079bd661db796  push r11
000079bd661db798  sub rsp, 0xF0
000079bd661db79f  vmovaps [rsp], xmm0
000079bd661db7a4  vmovaps [rsp+0x10], xmm2
000079bd661db7aa  vmovaps [rsp+0x20], xmm3
000079bd661db7b0  vmovaps [rsp+0x30], xmm4
000079bd661db7b6  vmovaps [rsp+0x40], xmm5
000079bd661db7bc  vmovaps [rsp+0x50], xmm6
000079bd661db7c2  vmovaps [rsp+0x60], xmm7
000079bd661db7c8  vmovaps [rsp+0x70], xmm8
000079bd661db7ce  vmovaps [rsp+0x80], xmm9
000079bd661db7d7  vmovaps [rsp+0x90], xmm10
000079bd661db7e0  vmovaps [rsp+0xA0], xmm11
000079bd661db7e9  vmovaps [rsp+0xB0], xmm12
000079bd661db7f2  vmovaps [rsp+0xC0], xmm13
000079bd661db7fb  vmovaps [rsp+0xD0], xmm14
000079bd661db804  vmovaps [rsp+0xE0], xmm15
000079bd661db80d  sub rsp, 0x30
000079bd661db811  movaps [rsp], xmm1
000079bd661db815  movaps [rsp+0x10], xmm8
000079bd661db81b  movaps [rsp+0x20], xmm9
000079bd661db821  lea rdi, [rsp]
000079bd661db825  mov esi, 0x00
000079bd661db82a  mov rax, 0x56EBD57B0530
000079bd661db834  call rax
000079bd661db836  movaps xmm1, [rsp]
000079bd661db83a  add rsp, 0x30
000079bd661db83e  vmovaps xmm0, [rsp]
000079bd661db843  vmovaps xmm2, [rsp+0x10]
000079bd661db849  vmovaps xmm3, [rsp+0x20]
000079bd661db84f  vmovaps xmm4, [rsp+0x30]
000079bd661db855  vmovaps xmm5, [rsp+0x40]
000079bd661db85b  vmovaps xmm6, [rsp+0x50]
000079bd661db861  vmovaps xmm7, [rsp+0x60]
000079bd661db867  vmovaps xmm8, [rsp+0x70]
000079bd661db86d  vmovaps xmm9, [rsp+0x80]
000079bd661db876  vmovaps xmm10, [rsp+0x90]
000079bd661db87f  vmovaps xmm11, [rsp+0xA0]
000079bd661db888  vmovaps xmm12, [rsp+0xB0]
000079bd661db891  vmovaps xmm13, [rsp+0xC0]
000079bd661db89a  vmovaps xmm14, [rsp+0xD0]
000079bd661db8a3  vmovaps xmm15, [rsp+0xE0]
000079bd661db8ac  add rsp, 0xF0
000079bd661db8b3  pop r11
000079bd661db8b5  pop r10
000079bd661db8b7  pop r9
000079bd661db8b9  pop r8
000079bd661db8bb  pop rsi
000079bd661db8bc  pop rdi
000079bd661db8bd  pop rdx
000079bd661db8be  pop rcx
000079bd661db8bf  pop rax
000079bd661db8c0  add rsp, 0x08
000079bd661db8c4  jmp 0x000079BD661D66B2
000079bd661db8c9  call 0x000079BD660B3E40
000079bd661db8ce  jmp 0x000079BD661D66C0
000079bd661db8d3  call 0x000079BD6600C380
000079bd661db8d8  jmp 0x000079BD661D66CA
000079bd661db8dd  call 0x000079BD6600D600
000079bd661db8e2  jmp 0x000079BD661D66D4
000079bd661db8e7  call 0x000079BD65FFF540
000079bd661db8ec  jmp 0x000079BD661D66DE
000079bd661db8f1  int3
000079bd661db8f2  nop [rax+rax*1], ax
000079bd661db8fb  nop [rax+rax*1], eax
000079bd661db900  mov eax, [r15+0x48]
000079bd661db904  lea r14d, [eax+0x01]
000079bd661db909  mov [rsp+0x10], r14d
000079bd661db90e  mov r14d, r14d
000079bd661db911  mov [r15+0x48], r14
000079bd661db915  xor eax, eax
000079bd661db917  mov r14d, [rsp+0x10]
000079bd661db91c  cmp r14d, 0x1F4
000079bd661db923  cmc
000079bd661db924  lahf
000079bd661db925  seto al
000079bd661db928  mov [r15+0x108], eax
000079bd661db92f  mov eax, [r15+0x108]
000079bd661db936  sahf
000079bd661db937  jnz 0x000079BD661DB969
000079bd661db939  cmp dword ptr [r15+0x318], 0x00
000079bd661db941  jz 0x000079BD661E1AB0
000079bd661db947  nop [rax+rax*1], ax
000079bd661db950  nop [rax+rax*1], eax
000079bd661db958  mov eax, 0x410450
000079bd661db95d  mov [r15+0x100], rax
000079bd661db964  jmp 0x000079BD65FFE110
000079bd661db969  cmp dword ptr [r15+0x318], 0x00
000079bd661db971  jz 0x000079BD661DB9A0
000079bd661db977  nop [rax+rax*1], ax
000079bd661db980  nop [rax+rax*1], eax
000079bd661db988  mov eax, 0x410274
000079bd661db98d  mov [r15+0x100], rax
000079bd661db994  jmp 0x000079BD65FFE110
000079bd661db999  int3
000079bd661db99a  int3
000079bd661db99b  nop [rax+rax*1], eax
000079bd661db9a0  mov rax, [r15+0x40]
000079bd661db9a4  movaps xmm1, [r15+0x1D0]
000079bd661db9ac  vmovaps [rsp+0x10], xmm1
000079bd661db9b2  vmovaps xmm15, [rsp+0x10]
000079bd661db9b8  por xmm1, xmm15
000079bd661db9bd  movaps xmm14, [r15+0x1A0]
000079bd661db9c5  vmovaps [rsp+0x10], xmm14
000079bd661db9cb  vmovaps xmm13, [rsp+0x10]
000079bd661db9d1  por xmm14, xmm13
000079bd661db9d6  lea r14, [rax+0x30]
000079bd661db9da  mov r12, [r13+r14*1]
000079bd661db9df  lea r14, [rax+0x38]
000079bd661db9e3  mov r11, [r13+r14*1]
000079bd661db9e8  movq xmm13, r12
000079bd661db9ed  movq xmm12, r11
000079bd661db9f2  movq xmm13, xmm13
000079bd661db9f7  vmovaps [rsp+0x10], xmm13
000079bd661db9fd  movq xmm13, xmm13
000079bd661dba02  movaps [r15+0x130], xmm13
000079bd661dba0a  movq xmm12, xmm12
000079bd661dba0f  vmovaps [rsp+0x20], xmm12
000079bd661dba15  movq xmm12, xmm12
000079bd661dba1a  movaps [r15+0x280], xmm12
000079bd661dba22  movaps xmm13, [r15+0x270]
000079bd661dba2a  vmovaps [rsp+0x30], xmm13
000079bd661dba30  vmovaps xmm12, [rsp+0x30]
000079bd661dba36  por xmm13, xmm12
000079bd661dba3b  lea r14, [rax+0x20]
000079bd661dba3f  mov r12, [r13+r14*1]
000079bd661dba44  lea r14, [rax+0x28]
000079bd661dba48  mov r11, [r13+r14*1]
000079bd661dba4d  movq xmm12, r12
000079bd661dba52  movq xmm11, r11
000079bd661dba57  movq xmm12, xmm12
000079bd661dba5c  vmovaps [rsp+0x30], xmm12
000079bd661dba62  movq xmm12, xmm12
000079bd661dba67  movaps [r15+0x150], xmm12
000079bd661dba6f  movq xmm11, xmm11
000079bd661dba74  vmovaps [rsp+0x40], xmm11
000079bd661dba7a  movq xmm11, xmm11
000079bd661dba7f  movaps [r15+0x140], xmm11
000079bd661dba87  lea r14, [rax+0x10]
000079bd661dba8b  mov r12, [r13+r14*1]
000079bd661dba90  lea r14, [rax+0x18]
000079bd661dba94  mov r11, [r13+r14*1]
000079bd661dba99  movq xmm12, r12
000079bd661dba9e  movq xmm11, r11
000079bd661dbaa3  movq xmm12, xmm12
000079bd661dbaa8  vmovaps [rsp+0x50], xmm12
000079bd661dbaae  movq xmm12, xmm12
000079bd661dbab3  movaps [r15+0x170], xmm12
000079bd661dbabb  movq xmm11, xmm11
000079bd661dbac0  vmovaps [rsp+0x60], xmm11
000079bd661dbac6  movq xmm11, xmm11
000079bd661dbacb  movaps [r15+0x160], xmm11
000079bd661dbad3  mov r14, [r13+rax*1]
000079bd661dbad8  vmovq xmm12, r14
000079bd661dbadd  vpbroadcastq xmm12, xmm12
000079bd661dbae2  lea r14, [rax+0x08]
000079bd661dbae6  mov rax, [r13+r14*1]
000079bd661dbaeb  movq xmm11, rax
000079bd661dbaf0  movaps [r15+0x230], xmm11
000079bd661dbaf8  mov rax, [r15+0xF8]
000079bd661dbaff  lea r14, [rax+0x50]
000079bd661dbb03  movups xmm11, [r13+r14*1]
000079bd661dbb09  lea r14, [rax+0x60]
000079bd661dbb0d  movups xmm10, [r13+r14*1]
000079bd661dbb13  lea r14, [rax+0x30]
000079bd661dbb17  movups xmm9, [r13+r14*1]
000079bd661dbb1d  mov r14, [r15+0x50]
000079bd661dbb21  mov [r15+0x60], r14
000079bd661dbb25  mov qword ptr [r15+0x58], 0x40
000079bd661dbb2d  movaps xmm8, xmm12
000079bd661dbb31  mulpd xmm8, xmm15
000079bd661dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000079bd661dbb3c  ptest xmm7, xmm7
000079bd661dbb41  jnz 0x000079BD661DC96A
000079bd661dbb47  movq xmm15, qword ptr [r15+0x230]
000079bd661dbb50  vmovaps [rsp+0x70], xmm15
000079bd661dbb56  vpermilpd xmm15, xmm15, 0x00
000079bd661dbb5c  movaps xmm7, xmm9
000079bd661dbb60  mulpd xmm7, xmm15
000079bd661dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000079bd661dbb6a  ptest xmm6, xmm6
000079bd661dbb6f  jnz 0x000079BD661DCAAE
000079bd661dbb75  vxorps xmm15, xmm15, xmm15
000079bd661dbb7a  vpbroadcastq xmm15, xmm15
000079bd661dbb7f  movaps xmm9, xmm12
000079bd661dbb83  mulpd xmm9, xmm10
000079bd661dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000079bd661dbb8e  ptest xmm6, xmm6
000079bd661dbb93  jnz 0x000079BD661DCBF0
000079bd661dbb99  movaps xmm10, xmm12
000079bd661dbb9d  mulpd xmm10, xmm11
000079bd661dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000079bd661dbba8  ptest xmm6, xmm6
000079bd661dbbad  jnz 0x000079BD661DCD34
000079bd661dbbb3  movaps xmm11, [r15+0x1F0]
000079bd661dbbbb  movaps xmm6, xmm12
000079bd661dbbbf  mulpd xmm6, xmm11
000079bd661dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000079bd661dbbc9  ptest xmm5, xmm5
000079bd661dbbce  jnz 0x000079BD661DCE78
000079bd661dbbd4  movaps xmm12, [r15+0x2A0]
000079bd661dbbdc  vmovaps [rsp+0x80], xmm12
000079bd661dbbe5  vmovaps xmm11, [rsp+0x80]
000079bd661dbbee  por xmm12, xmm11
000079bd661dbbf3  movaps xmm11, [r15+0x250]
000079bd661dbbfb  vmovaps [rsp+0x80], xmm11
000079bd661dbc04  vmovaps xmm5, [rsp+0x80]
000079bd661dbc0d  por xmm11, xmm5
000079bd661dbc12  vmovaps xmm4, [rsp+0x70]
000079bd661dbc18  vpermilpd xmm4, xmm4, 0x00
000079bd661dbc1e  movaps xmm3, xmm5
000079bd661dbc21  mulpd xmm3, xmm4
000079bd661dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000079bd661dbc2a  ptest xmm2, xmm2
000079bd661dbc2f  jnz 0x000079BD661DCFBA
000079bd661dbc35  mov [rsp+0x80], rax
000079bd661dbc3d  xor eax, eax
000079bd661dbc3f  mov r12d, 0x40
000079bd661dbc45  mov r11d, 0x200
000079bd661dbc4b  cmp r12, r11
000079bd661dbc4e  cmc
000079bd661dbc4f  lahf
000079bd661dbc50  seto al
000079bd661dbc53  mov [r15+0x108], eax
000079bd661dbc5a  movaps xmm5, xmm8
000079bd661dbc5e  addpd xmm5, xmm15
000079bd661dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000079bd661dbc68  ptest xmm4, xmm4
000079bd661dbc6d  jnz 0x000079BD661DD0FA
000079bd661dbc73  movaps xmm8, [r15+0x1B0]
000079bd661dbc7b  movaps xmm4, xmm9
000079bd661dbc7f  addpd xmm4, xmm8
000079bd661dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000079bd661dbc89  ptest xmm2, xmm2
000079bd661dbc8e  jnz 0x000079BD661DD23C
000079bd661dbc94  movaps xmm9, xmm10
000079bd661dbc98  addpd xmm9, xmm8
000079bd661dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000079bd661dbca3  ptest xmm2, xmm2
000079bd661dbca8  jnz 0x000079BD661DD37E
000079bd661dbcae  movaps xmm10, [r15+0x2F0]
000079bd661dbcb6  vmovaps [rsp+0x90], xmm10
000079bd661dbcbf  vmovaps xmm8, [rsp+0x90]
000079bd661dbcc8  por xmm10, xmm8
000079bd661dbccd  movaps xmm8, [r15+0x2E0]
000079bd661dbcd5  vmovaps [rsp+0x90], xmm8
000079bd661dbcde  vmovaps xmm2, [rsp+0x90]
000079bd661dbce7  por xmm8, xmm2
000079bd661dbcec  movaps xmm2, [r15+0x2D0]
000079bd661dbcf4  vmovaps [rsp+0x90], xmm2
000079bd661dbcfd  vmovaps [rsp+0xA0], xmm1
000079bd661dbd06  vmovaps xmm1, [rsp+0x90]
000079bd661dbd0f  por xmm2, xmm1
000079bd661dbd13  movaps xmm1, [r15+0x200]
000079bd661dbd1b  vmovaps [rsp+0x90], xmm1
000079bd661dbd24  vmovaps [rsp+0xB0], xmm15
000079bd661dbd2d  vmovaps xmm15, [rsp+0x90]
000079bd661dbd36  por xmm1, xmm15
000079bd661dbd3b  movaps xmm15, [r15+0x1C0]
000079bd661dbd43  vmovaps [rsp+0x90], xmm15
000079bd661dbd4c  vmovaps [rsp+0xC0], xmm1
000079bd661dbd55  vmovaps xmm1, [rsp+0x90]
000079bd661dbd5e  por xmm15, xmm1
000079bd661dbd63  movaps xmm1, [r15+0x190]
000079bd661dbd6b  vmovaps [rsp+0x90], xmm1
000079bd661dbd74  vmovaps [rsp+0xD0], xmm15
000079bd661dbd7d  vmovaps xmm15, [rsp+0x90]
000079bd661dbd86  por xmm1, xmm15
000079bd661dbd8b  movaps xmm15, [r15+0x300]
000079bd661dbd93  vmovaps [rsp+0x90], xmm15
000079bd661dbd9c  vmovaps [rsp+0xE0], xmm1
000079bd661dbda5  vmovaps xmm1, [rsp+0x90]
000079bd661dbdae  por xmm15, xmm1
000079bd661dbdb3  mov rax, [rsp+0x80]
000079bd661dbdbb  lea r12, [rax+0xA0]
000079bd661dbdc2  movups xmm1, [r13+r12*1]
000079bd661dbdc8  lea r12, [rax+0xB0]
000079bd661dbdcf  vmovaps [rsp+0x80], xmm1
000079bd661dbdd8  movups xmm1, [r13+r12*1]
000079bd661dbdde  vmovaps [rsp+0x90], xmm1
000079bd661dbde7  vmovaps [rsp+0xF0], xmm15
000079bd661dbdf0  vmovaps xmm15, [rsp+0xB0]
000079bd661dbdf9  vmovaps [rsp+0xB0], xmm14
000079bd661dbe02  movaps xmm1, xmm6
000079bd661dbe05  addpd xmm1, xmm15
000079bd661dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000079bd661dbe0f  ptest xmm14, xmm14
000079bd661dbe15  jnz 0x000079BD661DD4D6
000079bd661dbe1b  lea r12, [rax+0xF0]
000079bd661dbe22  movups xmm15, [r13+r12*1]
000079bd661dbe28  movaps xmm14, xmm4
000079bd661dbe2c  addpd xmm14, xmm3
000079bd661dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000079bd661dbe37  ptest xmm6, xmm6
000079bd661dbe3c  jnz 0x000079BD661DD621
000079bd661dbe42  movaps xmm6, xmm9
000079bd661dbe46  addpd xmm6, xmm7
000079bd661dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000079bd661dbe4f  ptest xmm4, xmm4
000079bd661dbe54  jnz 0x000079BD661DD763
000079bd661dbe5a  vmovaps xmm9, [rsp+0x70]
000079bd661dbe60  vpermilpd xmm9, xmm9, 0x00
000079bd661dbe66  vmovaps xmm4, [rsp+0x90]
000079bd661dbe6f  movaps xmm7, xmm4
000079bd661dbe72  mulpd xmm7, xmm9
000079bd661dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000079bd661dbe7c  ptest xmm3, xmm3
000079bd661dbe81  jnz 0x000079BD661DD8A4
000079bd661dbe87  vmovaps xmm9, [rsp+0x50]
000079bd661dbe8d  vpermilpd xmm9, xmm9, 0x00
000079bd661dbe93  movaps xmm4, xmm15
000079bd661dbe97  mulpd xmm4, xmm9
000079bd661dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000079bd661dbea1  ptest xmm3, xmm3
000079bd661dbea6  jnz 0x000079BD661DD9E5
000079bd661dbeac  lea r12, [rax+0xE0]
000079bd661dbeb3  movups xmm15, [r13+r12*1]
000079bd661dbeb9  vmovaps xmm9, [rsp+0x70]
000079bd661dbebf  vpermilpd xmm9, xmm9, 0x00
000079bd661dbec5  vmovaps [rsp+0x70], xmm1
000079bd661dbecb  vmovaps xmm1, [rsp+0x80]
000079bd661dbed4  vmovaps [rsp+0x80], xmm15
000079bd661dbedd  movaps xmm3, xmm1
000079bd661dbee0  mulpd xmm3, xmm9
000079bd661dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000079bd661dbeea  ptest xmm15, xmm15
000079bd661dbef0  jnz 0x000079BD661DDB31
000079bd661dbef6  vmovaps xmm1, [rsp+0xF0]
000079bd661dbeff  vmovaps xmm15, [rsp+0xF0]
000079bd661dbf08  por xmm1, xmm15
000079bd661dbf0d  movaps [r15+0x300], xmm1
000079bd661dbf15  vmovaps xmm15, [rsp+0xE0]
000079bd661dbf1e  vmovaps xmm9, [rsp+0xE0]
000079bd661dbf27  por xmm15, xmm9
000079bd661dbf2c  movaps [r15+0x190], xmm15
000079bd661dbf34  vmovaps xmm9, [rsp+0x50]
000079bd661dbf3a  vpermilpd xmm9, xmm9, 0x00
000079bd661dbf40  vmovaps [rsp+0x90], xmm1
000079bd661dbf49  vmovaps [rsp+0xE0], xmm15
000079bd661dbf52  vmovaps xmm15, [rsp+0x80]
000079bd661dbf5b  vmovaps [rsp+0x80], xmm14
000079bd661dbf64  movaps xmm1, xmm15
000079bd661dbf68  mulpd xmm1, xmm9
000079bd661dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000079bd661dbf72  ptest xmm14, xmm14
000079bd661dbf78  jnz 0x000079BD661DDC72
000079bd661dbf7e  lea r12, [rax+0x90]
000079bd661dbf85  movups xmm15, [r13+r12*1]
000079bd661dbf8b  vmovaps xmm14, [rsp+0xD0]
000079bd661dbf94  vmovaps xmm9, [rsp+0xD0]
000079bd661dbf9d  por xmm14, xmm9
000079bd661dbfa2  movaps [r15+0x1C0], xmm14
000079bd661dbfaa  vmovaps xmm9, [rsp+0xC0]
000079bd661dbfb3  vmovaps [rsp+0xD0], xmm1
000079bd661dbfbc  vmovaps xmm1, [rsp+0xC0]
000079bd661dbfc5  por xmm9, xmm1
000079bd661dbfca  movaps [r15+0x200], xmm9
000079bd661dbfd2  vmovaps [rsp+0xC0], xmm2
000079bd661dbfdb  vmovaps xmm1, [rsp+0xC0]
000079bd661dbfe4  por xmm2, xmm1
000079bd661dbfe8  movaps [r15+0x2D0], xmm2
000079bd661dbff0  vmovaps [rsp+0xC0], xmm8
000079bd661dbff9  vmovaps xmm1, [rsp+0xC0]
000079bd661dc002  por xmm8, xmm1
000079bd661dc007  movaps [r15+0x2E0], xmm8
000079bd661dc00f  vmovaps [rsp+0xC0], xmm15
000079bd661dc018  movaps xmm1, xmm5
000079bd661dc01b  addpd xmm1, xmm7
000079bd661dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000079bd661dc024  ptest xmm15, xmm15
000079bd661dc02a  jnz 0x000079BD661DDDBE
000079bd661dc030  vmovaps xmm15, [rsp+0x50]
000079bd661dc036  vpermilpd xmm15, xmm15, 0x00
000079bd661dc03c  vmovaps xmm5, [rsp+0xC0]
000079bd661dc045  vmovaps [rsp+0xC0], xmm1
000079bd661dc04e  movaps xmm7, xmm5
000079bd661dc051  mulpd xmm7, xmm15
000079bd661dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000079bd661dc05b  ptest xmm1, xmm1
000079bd661dc060  jnz 0x000079BD661DDEFE
000079bd661dc066  lea r12, [rax+0x80]
000079bd661dc06d  movups xmm1, [r13+r12*1]
000079bd661dc073  vmovaps xmm5, [rsp+0x70]
000079bd661dc079  vmovaps [rsp+0x70], xmm1
000079bd661dc07f  movaps xmm15, xmm5
000079bd661dc083  addpd xmm15, xmm3
000079bd661dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000079bd661dc08e  ptest xmm1, xmm1
000079bd661dc093  jnz 0x000079BD661DE049
000079bd661dc099  vmovaps xmm5, [rsp+0x80]
000079bd661dc0a2  movaps xmm1, xmm5
000079bd661dc0a5  addpd xmm1, xmm4
000079bd661dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000079bd661dc0ae  ptest xmm3, xmm3
000079bd661dc0b3  jnz 0x000079BD661DE18B
000079bd661dc0b9  vmovaps [rsp+0x80], xmm10
000079bd661dc0c2  vmovaps xmm5, [rsp+0x80]
000079bd661dc0cb  por xmm10, xmm5
000079bd661dc0d0  movaps [r15+0x2F0], xmm10
000079bd661dc0d8  vmovaps xmm5, [rsp+0x50]
000079bd661dc0de  vpermilpd xmm5, xmm5, 0x00
000079bd661dc0e4  vmovaps xmm3, [rsp+0x70]
000079bd661dc0ea  vmovaps [rsp+0x50], xmm1
000079bd661dc0f0  movaps xmm4, xmm3
000079bd661dc0f3  mulpd xmm4, xmm5
000079bd661dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000079bd661dc0fc  ptest xmm1, xmm1
000079bd661dc101  jnz 0x000079BD661DE2CB
000079bd661dc107  lea r12, [rax+0xD0]
000079bd661dc10e  movups xmm1, [r13+r12*1]
000079bd661dc114  vmovaps xmm3, [rsp+0xD0]
000079bd661dc11d  vmovaps [rsp+0x70], xmm1
000079bd661dc123  movaps xmm5, xmm6
000079bd661dc126  addpd xmm5, xmm3
000079bd661dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000079bd661dc12f  ptest xmm1, xmm1
000079bd661dc134  jnz 0x000079BD661DE415
000079bd661dc13a  vmovaps xmm1, [rsp+0x60]
000079bd661dc140  vpermilpd xmm1, xmm1, 0x00
000079bd661dc146  movaps xmm6, xmm9
000079bd661dc14a  mulpd xmm6, xmm1
000079bd661dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000079bd661dc153  ptest xmm3, xmm3
000079bd661dc158  jnz 0x000079BD661DE555
000079bd661dc15e  movaps [r15+0x260], xmm6
000079bd661dc166  vxorps xmm1, xmm1, xmm1
000079bd661dc16a  vpbroadcastq xmm1, xmm1
000079bd661dc16f  movaps [r15+0x1B0], xmm1
000079bd661dc177  vmovaps xmm1, [rsp+0x60]
000079bd661dc17d  vpermilpd xmm1, xmm1, 0x00
000079bd661dc183  vmovaps xmm3, [rsp+0x70]
000079bd661dc189  vmovaps [rsp+0x70], xmm15
000079bd661dc18f  movaps xmm9, xmm3
000079bd661dc193  mulpd xmm9, xmm1
000079bd661dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000079bd661dc19e  ptest xmm15, xmm15
000079bd661dc1a4  jnz 0x000079BD661DE696
000079bd661dc1aa  lea r12, [rax+0xC0]
000079bd661dc1b1  movups xmm1, [r13+r12*1]
000079bd661dc1b7  vmovaps xmm3, [rsp+0xC0]
000079bd661dc1c0  vmovaps [rsp+0x80], xmm1
000079bd661dc1c9  movaps xmm15, xmm3
000079bd661dc1cd  addpd xmm15, xmm7
000079bd661dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000079bd661dc1d8  ptest xmm1, xmm1
000079bd661dc1dd  jnz 0x000079BD661DE7E2
000079bd661dc1e3  vmovaps [rsp+0xC0], xmm13
000079bd661dc1ec  vmovaps xmm1, [rsp+0xC0]
000079bd661dc1f5  por xmm13, xmm1
000079bd661dc1fa  movaps [r15+0x270], xmm13
000079bd661dc202  vmovaps xmm1, [rsp+0xB0]
000079bd661dc20b  vmovaps xmm7, [rsp+0xB0]
000079bd661dc214  por xmm1, xmm7
000079bd661dc218  movaps [r15+0x1A0], xmm1
000079bd661dc220  vmovaps xmm1, [rsp+0x60]
000079bd661dc226  vpermilpd xmm1, xmm1, 0x00
000079bd661dc22c  vmovaps [rsp+0xB0], xmm1
000079bd661dc235  vmovaps xmm1, [rsp+0x80]
000079bd661dc23e  vmovaps [rsp+0x80], xmm15
000079bd661dc247  vmovaps xmm15, [rsp+0xB0]
000079bd661dc250  vmovaps [rsp+0xB0], xmm14
000079bd661dc259  movaps xmm3, xmm1
000079bd661dc25c  mulpd xmm3, xmm15
000079bd661dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000079bd661dc266  ptest xmm14, xmm14
000079bd661dc26c  jnz 0x000079BD661DE924
000079bd661dc272  lea r12, [rax+0x20]
000079bd661dc276  movups xmm1, [r13+r12*1]
000079bd661dc27c  movaps [r15+0x110], xmm1
000079bd661dc284  vmovaps xmm14, [rsp+0x70]
000079bd661dc28a  vmovaps [rsp+0x70], xmm1
000079bd661dc290  movaps xmm15, xmm14
000079bd661dc294  addpd xmm15, xmm4
000079bd661dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000079bd661dc29f  ptest xmm1, xmm1
000079bd661dc2a4  jnz 0x000079BD661DEA6F
000079bd661dc2aa  vmovaps xmm1, [rsp+0x60]
000079bd661dc2b0  vpermilpd xmm1, xmm1, 0x00
000079bd661dc2b6  movaps xmm14, xmm2
000079bd661dc2ba  mulpd xmm14, xmm1
000079bd661dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000079bd661dc2c5  ptest xmm4, xmm4
000079bd661dc2ca  jnz 0x000079BD661DEBB2
000079bd661dc2d0  vmovaps xmm4, [rsp+0x50]
000079bd661dc2d6  movaps xmm1, xmm4
000079bd661dc2d9  addpd xmm1, xmm9
000079bd661dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000079bd661dc2e3  ptest xmm2, xmm2
000079bd661dc2e8  jnz 0x000079BD661DECF4
000079bd661dc2ee  vmovaps xmm9, [rsp+0x30]
000079bd661dc2f4  vpermilpd xmm9, xmm9, 0x00
000079bd661dc2fa  vmovaps xmm2, [rsp+0x70]
000079bd661dc300  vmovaps [rsp+0x50], xmm1
000079bd661dc306  movaps xmm4, xmm2
000079bd661dc309  mulpd xmm4, xmm9
000079bd661dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000079bd661dc313  ptest xmm1, xmm1
000079bd661dc318  jnz 0x000079BD661DEE35
000079bd661dc31e  vmovaps xmm1, [rsp+0x30]
000079bd661dc324  vpermilpd xmm1, xmm1, 0x00
000079bd661dc32a  vmovaps xmm2, [rsp+0x90]
000079bd661dc333  vmovaps [rsp+0x60], xmm15
000079bd661dc339  movaps xmm9, xmm2
000079bd661dc33d  mulpd xmm9, xmm1
000079bd661dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000079bd661dc348  ptest xmm15, xmm15
000079bd661dc34e  jnz 0x000079BD661DEF76
000079bd661dc354  vmovaps xmm15, [rsp+0x80]
000079bd661dc35d  movaps xmm1, xmm15
000079bd661dc361  addpd xmm1, xmm6
000079bd661dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000079bd661dc36a  ptest xmm2, xmm2
000079bd661dc36f  jnz 0x000079BD661DF0B8
000079bd661dc375  movaps xmm15, xmm5
000079bd661dc379  addpd xmm15, xmm3
000079bd661dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000079bd661dc384  ptest xmm6, xmm6
000079bd661dc389  jnz 0x000079BD661DF1F9
000079bd661dc38f  vmovaps xmm6, [rsp+0x30]
000079bd661dc395  vpermilpd xmm6, xmm6, 0x00
000079bd661dc39b  movaps xmm5, xmm8
000079bd661dc39f  mulpd xmm5, xmm6
000079bd661dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000079bd661dc3a8  ptest xmm3, xmm3
000079bd661dc3ad  jnz 0x000079BD661DF33B
000079bd661dc3b3  vmovaps xmm8, [rsp+0x30]
000079bd661dc3b9  vpermilpd xmm8, xmm8, 0x00
000079bd661dc3bf  movaps xmm6, xmm10
000079bd661dc3c3  mulpd xmm6, xmm8
000079bd661dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000079bd661dc3cd  ptest xmm3, xmm3
000079bd661dc3d2  jnz 0x000079BD661DF47C
000079bd661dc3d8  vmovaps xmm8, [rsp+0x60]
000079bd661dc3de  movaps xmm10, xmm8
000079bd661dc3e2  addpd xmm10, xmm14
000079bd661dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000079bd661dc3ed  ptest xmm3, xmm3
000079bd661dc3f2  jnz 0x000079BD661DF5BE
000079bd661dc3f8  vmovaps xmm8, [rsp+0x50]
000079bd661dc3fe  movaps xmm14, xmm8
000079bd661dc402  addpd xmm14, xmm4
000079bd661dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000079bd661dc40d  ptest xmm3, xmm3
000079bd661dc412  jnz 0x000079BD661DF702
000079bd661dc418  vmovaps xmm8, [rsp+0x40]
000079bd661dc41e  vpermilpd xmm8, xmm8, 0x00
000079bd661dc424  movaps xmm4, xmm13
000079bd661dc428  mulpd xmm4, xmm8
000079bd661dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000079bd661dc432  ptest xmm3, xmm3
000079bd661dc437  jnz 0x000079BD661DF845
000079bd661dc43d  movaps xmm13, xmm15
000079bd661dc441  addpd xmm13, xmm9
000079bd661dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000079bd661dc44c  ptest xmm8, xmm8
000079bd661dc452  jnz 0x000079BD661DF987
000079bd661dc458  movaps xmm15, xmm1
000079bd661dc45c  addpd xmm15, xmm5
000079bd661dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000079bd661dc467  ptest xmm9, xmm9
000079bd661dc46d  jnz 0x000079BD661DFACB
000079bd661dc473  vmovaps [rsp+0x30], xmm11
000079bd661dc479  vmovaps xmm1, [rsp+0x30]
000079bd661dc47f  por xmm11, xmm1
000079bd661dc484  movaps [r15+0x250], xmm11
000079bd661dc48c  vmovaps [rsp+0x30], xmm12
000079bd661dc492  vmovaps xmm1, [rsp+0x30]
000079bd661dc498  por xmm12, xmm1
000079bd661dc49d  movaps [r15+0x2A0], xmm12
000079bd661dc4a5  vmovaps xmm1, [rsp+0xA0]
000079bd661dc4ae  vmovaps xmm11, [rsp+0xA0]
000079bd661dc4b7  por xmm1, xmm11
000079bd661dc4bc  movaps [r15+0x1D0], xmm1
000079bd661dc4c4  lea r12, [rax+0x40]
000079bd661dc4c8  movups xmm1, [r13+r12*1]
000079bd661dc4ce  movaps [r15+0x2C0], xmm1
000079bd661dc4d6  vmovaps xmm11, [rsp+0x40]
000079bd661dc4dc  vpermilpd xmm11, xmm11, 0x00
000079bd661dc4e2  vmovaps xmm8, [rsp+0xE0]
000079bd661dc4eb  movaps xmm9, xmm8
000079bd661dc4ef  mulpd xmm9, xmm11
000079bd661dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000079bd661dc4fa  ptest xmm5, xmm5
000079bd661dc4ff  jnz 0x000079BD661DFC17
000079bd661dc505  movaps xmm11, xmm10
000079bd661dc509  addpd xmm11, xmm6
000079bd661dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000079bd661dc514  ptest xmm8, xmm8
000079bd661dc51a  jnz 0x000079BD661DFD5B
000079bd661dc520  movaps xmm10, xmm14
000079bd661dc524  addpd xmm10, xmm4
000079bd661dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000079bd661dc52f  ptest xmm8, xmm8
000079bd661dc535  jnz 0x000079BD661DFE9E
000079bd661dc53b  vmovaps xmm14, [rsp+0x40]
000079bd661dc541  vpermilpd xmm14, xmm14, 0x00
000079bd661dc547  movaps xmm8, xmm1
000079bd661dc54b  mulpd xmm8, xmm14
000079bd661dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000079bd661dc556  ptest xmm6, xmm6
000079bd661dc55b  jnz 0x000079BD661DFFE1
000079bd661dc561  movaps xmm1, [r15+0x2B0]
000079bd661dc569  vmovaps xmm14, [rsp+0x40]
000079bd661dc56f  vpermilpd xmm14, xmm14, 0x00
000079bd661dc575  movaps xmm6, xmm1
000079bd661dc578  mulpd xmm6, xmm14
000079bd661dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000079bd661dc582  ptest xmm5, xmm5
000079bd661dc587  jnz 0x000079BD661E0124
000079bd661dc58d  vmovaps xmm1, [rsp+0x10]
000079bd661dc593  vpermilpd xmm1, xmm1, 0x00
000079bd661dc599  movaps xmm14, xmm12
000079bd661dc59d  mulpd xmm14, xmm1
000079bd661dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000079bd661dc5a8  ptest xmm5, xmm5
000079bd661dc5ad  jnz 0x000079BD661E0265
000079bd661dc5b3  movaps xmm1, xmm13
000079bd661dc5b7  addpd xmm1, xmm9
000079bd661dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000079bd661dc5c1  ptest xmm12, xmm12
000079bd661dc5c7  jnz 0x000079BD661E03A8
000079bd661dc5cd  vmovaps xmm13, [rsp+0x10]
000079bd661dc5d3  vpermilpd xmm13, xmm13, 0x00
000079bd661dc5d9  movaps xmm12, xmm7
000079bd661dc5dd  mulpd xmm12, xmm13
000079bd661dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000079bd661dc5e8  ptest xmm9, xmm9
000079bd661dc5ee  jnz 0x000079BD661E04EA
000079bd661dc5f4  movaps xmm13, xmm15
000079bd661dc5f8  addpd xmm13, xmm8
000079bd661dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000079bd661dc603  ptest xmm9, xmm9
000079bd661dc609  jnz 0x000079BD661E062D
000079bd661dc60f  movaps xmm15, [r15+0x290]
000079bd661dc617  vmovaps xmm9, [rsp+0x10]
000079bd661dc61d  vpermilpd xmm9, xmm9, 0x00
000079bd661dc623  movaps xmm8, xmm15
000079bd661dc627  mulpd xmm8, xmm9
000079bd661dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000079bd661dc632  ptest xmm7, xmm7
000079bd661dc637  jnz 0x000079BD661E0771
000079bd661dc63d  movaps xmm15, xmm11
000079bd661dc641  addpd xmm15, xmm6
000079bd661dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000079bd661dc64c  ptest xmm9, xmm9
000079bd661dc652  jnz 0x000079BD661E08B5
000079bd661dc658  movaps xmm11, [r15+0x1E0]
000079bd661dc660  vmovaps xmm9, [rsp+0x10]
000079bd661dc666  vpermilpd xmm9, xmm9, 0x00
000079bd661dc66c  movaps xmm7, xmm11
000079bd661dc670  mulpd xmm7, xmm9
000079bd661dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000079bd661dc67a  ptest xmm6, xmm6
000079bd661dc67f  jnz 0x000079BD661E09F8
000079bd661dc685  movaps xmm11, xmm10
000079bd661dc689  addpd xmm11, xmm14
000079bd661dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000079bd661dc694  ptest xmm9, xmm9
000079bd661dc69a  jnz 0x000079BD661E0B3A
000079bd661dc6a0  lea r12, [rax+0x70]
000079bd661dc6a4  movups xmm14, [r13+r12*1]
000079bd661dc6aa  movaps [r15+0x240], xmm14
000079bd661dc6b2  movaps xmm10, xmm1
000079bd661dc6b6  addpd xmm10, xmm12
000079bd661dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000079bd661dc6c1  ptest xmm9, xmm9
000079bd661dc6c7  jnz 0x000079BD661E0C88
000079bd661dc6cd  movaps [r15+0x170], xmm10
000079bd661dc6d5  vmovaps xmm1, [rsp+0x20]
000079bd661dc6db  vpermilpd xmm1, xmm1, 0x00
000079bd661dc6e1  movaps xmm12, xmm14
000079bd661dc6e5  mulpd xmm12, xmm1
000079bd661dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000079bd661dc6f0  ptest xmm9, xmm9
000079bd661dc6f6  jnz 0x000079BD661E0DCB
000079bd661dc6fc  vmovaps xmm1, [rsp+0x20]
000079bd661dc702  vpermilpd xmm1, xmm1, 0x00
000079bd661dc708  vmovaps xmm9, [rsp+0xB0]
000079bd661dc711  movaps xmm14, xmm9
000079bd661dc715  mulpd xmm14, xmm1
000079bd661dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000079bd661dc720  ptest xmm6, xmm6
000079bd661dc725  jnz 0x000079BD661E0F0E
000079bd661dc72b  movaps [r15+0x180], xmm14
000079bd661dc733  movaps xmm1, xmm13
000079bd661dc737  addpd xmm1, xmm8
000079bd661dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000079bd661dc741  ptest xmm9, xmm9
000079bd661dc747  jnz 0x000079BD661E1051
000079bd661dc74d  movaps [r15+0x210], xmm1
000079bd661dc755  movups xmm13, [r13+rax*1]
000079bd661dc75b  lea r12, [rax+0x10]
000079bd661dc75f  movups xmm9, [r13+r12*1]
000079bd661dc765  movaps [r15+0x230], xmm9
000079bd661dc76d  movaps xmm8, xmm15
000079bd661dc771  addpd xmm8, xmm7
000079bd661dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000079bd661dc77c  ptest xmm6, xmm6
000079bd661dc781  jnz 0x000079BD661E11A7
000079bd661dc787  movaps [r15+0x130], xmm8
000079bd661dc78f  vmovaps xmm15, [rsp+0x20]
000079bd661dc795  vpermilpd xmm15, xmm15, 0x00
000079bd661dc79b  movaps xmm7, xmm9
000079bd661dc79f  mulpd xmm7, xmm15
000079bd661dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000079bd661dc7a9  ptest xmm6, xmm6
000079bd661dc7ae  jnz 0x000079BD661E12EA
000079bd661dc7b4  movaps [r15+0x220], xmm7
000079bd661dc7bc  vmovaps xmm15, [rsp+0x20]
000079bd661dc7c2  vpermilpd xmm15, xmm15, 0x00
000079bd661dc7c8  movaps xmm9, xmm13
000079bd661dc7cc  mulpd xmm9, xmm15
000079bd661dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000079bd661dc7d7  ptest xmm6, xmm6
000079bd661dc7dc  jnz 0x000079BD661E142C
000079bd661dc7e2  movaps xmm15, xmm11
000079bd661dc7e6  addpd xmm15, xmm12
000079bd661dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000079bd661dc7f1  ptest xmm13, xmm13
000079bd661dc7f7  jnz 0x000079BD661E1570
000079bd661dc7fd  movaps [r15+0x140], xmm15
000079bd661dc805  movaps xmm13, xmm10
000079bd661dc809  addpd xmm13, xmm14
000079bd661dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000079bd661dc814  ptest xmm12, xmm12
000079bd661dc81a  jnz 0x000079BD661E16B4
000079bd661dc820  movaps [r15+0x150], xmm13
000079bd661dc828  movaps xmm14, xmm1
000079bd661dc82c  addpd xmm14, xmm7
000079bd661dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000079bd661dc837  ptest xmm12, xmm12
000079bd661dc83d  jnz 0x000079BD661E17F8
000079bd661dc843  movaps [r15+0x160], xmm14
000079bd661dc84b  movaps xmm1, xmm8
000079bd661dc84f  addpd xmm1, xmm9
000079bd661dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000079bd661dc859  ptest xmm12, xmm12
000079bd661dc85f  jnz 0x000079BD661E193A
000079bd661dc865  movaps [r15+0x120], xmm1
000079bd661dc86d  movups [r13+r14*1], xmm15
000079bd661dc873  lea rax, [r14+0x10]
000079bd661dc877  movups [r13+rax*1], xmm13
000079bd661dc87d  lea rax, [r14+0x20]
000079bd661dc881  movups [r13+rax*1], xmm14
000079bd661dc887  lea rax, [r14+0x30]
000079bd661dc88b  movups [r13+rax*1], xmm1
000079bd661dc891  mov eax, [r15+0x108]
000079bd661dc898  sahf
000079bd661dc899  jnz 0x000079BD661DC8CB
000079bd661dc89b  cmp dword ptr [r15+0x318], 0x00
000079bd661dc8a3  jz 0x000079BD661DB900
000079bd661dc8a9  nop [rax+rax*1], ax
000079bd661dc8b2  nop [rax+rax*1], eax
000079bd661dc8ba  mov eax, 0x410444
000079bd661dc8bf  mov [r15+0x100], rax
000079bd661dc8c6  jmp 0x000079BD65FFE110
000079bd661dc8cb  cmp dword ptr [r15+0x318], 0x00
000079bd661dc8d3  jz 0x000079BD661D57E0
000079bd661dc8d9  nop [rax+rax*1], ax
000079bd661dc8e2  nop [rax+rax*1], eax
000079bd661dc8ea  mov eax, 0x410278
000079bd661dc8ef  mov [r15+0x100], rax
000079bd661dc8f6  jmp 0x000079BD65FFE110
000079bd661dc8fb  int3
000079bd661dc8fc  call 0x000079BD660E27E0
000079bd661dc901  jmp 0x000079BD661DB9DF
000079bd661dc906  call 0x000079BD660E1570
000079bd661dc90b  jmp 0x000079BD661DB9E8
000079bd661dc910  call 0x000079BD660E27E0
000079bd661dc915  jmp 0x000079BD661DBA44
000079bd661dc91a  call 0x000079BD660E1570
000079bd661dc91f  jmp 0x000079BD661DBA4D
000079bd661dc924  call 0x000079BD660E27E0
000079bd661dc929  jmp 0x000079BD661DBA90
000079bd661dc92e  call 0x000079BD660E1570
000079bd661dc933  jmp 0x000079BD661DBA99
000079bd661dc938  call 0x000079BD6600DC20
000079bd661dc93d  jmp 0x000079BD661DBAD8
000079bd661dc942  call 0x000079BD660D59C0
000079bd661dc947  jmp 0x000079BD661DBAEB
000079bd661dc94c  call 0x000079BD660E0E30
000079bd661dc951  jmp 0x000079BD661DBB09
000079bd661dc956  call 0x000079BD660DFBC0
000079bd661dc95b  jmp 0x000079BD661DBB13
000079bd661dc960  call 0x000079BD660DE950
000079bd661dc965  jmp 0x000079BD661DBB1D
000079bd661dc96a  sub rsp, 0x08
000079bd661dc96e  push rax
000079bd661dc96f  push rcx
000079bd661dc970  push rdx
000079bd661dc971  push rdi
000079bd661dc972  push rsi
000079bd661dc973  push r8
000079bd661dc975  push r9
000079bd661dc977  push r10
000079bd661dc979  push r11
000079bd661dc97b  sub rsp, 0xF0
000079bd661dc982  vmovaps [rsp], xmm0
000079bd661dc987  vmovaps [rsp+0x10], xmm1
000079bd661dc98d  vmovaps [rsp+0x20], xmm2
000079bd661dc993  vmovaps [rsp+0x30], xmm3
000079bd661dc999  vmovaps [rsp+0x40], xmm4
000079bd661dc99f  vmovaps [rsp+0x50], xmm5
000079bd661dc9a5  vmovaps [rsp+0x60], xmm6
000079bd661dc9ab  vmovaps [rsp+0x70], xmm7
000079bd661dc9b1  vmovaps [rsp+0x80], xmm9
000079bd661dc9ba  vmovaps [rsp+0x90], xmm10
000079bd661dc9c3  vmovaps [rsp+0xA0], xmm11
000079bd661dc9cc  vmovaps [rsp+0xB0], xmm12
000079bd661dc9d5  vmovaps [rsp+0xC0], xmm13
000079bd661dc9de  vmovaps [rsp+0xD0], xmm14
000079bd661dc9e7  vmovaps [rsp+0xE0], xmm15
000079bd661dc9f0  sub rsp, 0x30
000079bd661dc9f4  movaps [rsp], xmm8
000079bd661dc9f9  movaps [rsp+0x10], xmm12
000079bd661dc9ff  movaps [rsp+0x20], xmm15
000079bd661dca05  lea rdi, [rsp]
000079bd661dca09  mov esi, 0x00
000079bd661dca0e  mov rax, 0x56EBD57B0530
000079bd661dca18  call rax
000079bd661dca1a  movaps xmm8, [rsp]
000079bd661dca1f  add rsp, 0x30
000079bd661dca23  vmovaps xmm0, [rsp]
000079bd661dca28  vmovaps xmm1, [rsp+0x10]
000079bd661dca2e  vmovaps xmm2, [rsp+0x20]
000079bd661dca34  vmovaps xmm3, [rsp+0x30]
000079bd661dca3a  vmovaps xmm4, [rsp+0x40]
000079bd661dca40  vmovaps xmm5, [rsp+0x50]
000079bd661dca46  vmovaps xmm6, [rsp+0x60]
000079bd661dca4c  vmovaps xmm7, [rsp+0x70]
000079bd661dca52  vmovaps xmm9, [rsp+0x80]
000079bd661dca5b  vmovaps xmm10, [rsp+0x90]
000079bd661dca64  vmovaps xmm11, [rsp+0xA0]
000079bd661dca6d  vmovaps xmm12, [rsp+0xB0]
000079bd661dca76  vmovaps xmm13, [rsp+0xC0]
000079bd661dca7f  vmovaps xmm14, [rsp+0xD0]
000079bd661dca88  vmovaps xmm15, [rsp+0xE0]
000079bd661dca91  add rsp, 0xF0
000079bd661dca98  pop r11
000079bd661dca9a  pop r10
000079bd661dca9c  pop r9
000079bd661dca9e  pop r8
000079bd661dcaa0  pop rsi
000079bd661dcaa1  pop rdi
000079bd661dcaa2  pop rdx
000079bd661dcaa3  pop rcx
000079bd661dcaa4  pop rax
000079bd661dcaa5  add rsp, 0x08
000079bd661dcaa9  jmp 0x000079BD661DBB47
000079bd661dcaae  sub rsp, 0x08
000079bd661dcab2  push rax
000079bd661dcab3  push rcx
000079bd661dcab4  push rdx
000079bd661dcab5  push rdi
000079bd661dcab6  push rsi
000079bd661dcab7  push r8
000079bd661dcab9  push r9
000079bd661dcabb  push r10
000079bd661dcabd  push r11
000079bd661dcabf  sub rsp, 0xF0
000079bd661dcac6  vmovaps [rsp], xmm0
000079bd661dcacb  vmovaps [rsp+0x10], xmm1
000079bd661dcad1  vmovaps [rsp+0x20], xmm2
000079bd661dcad7  vmovaps [rsp+0x30], xmm3
000079bd661dcadd  vmovaps [rsp+0x40], xmm4
000079bd661dcae3  vmovaps [rsp+0x50], xmm5
000079bd661dcae9  vmovaps [rsp+0x60], xmm6
000079bd661dcaef  vmovaps [rsp+0x70], xmm8
000079bd661dcaf5  vmovaps [rsp+0x80], xmm9
000079bd661dcafe  vmovaps [rsp+0x90], xmm10
000079bd661dcb07  vmovaps [rsp+0xA0], xmm11
000079bd661dcb10  vmovaps [rsp+0xB0], xmm12
000079bd661dcb19  vmovaps [rsp+0xC0], xmm13
000079bd661dcb22  vmovaps [rsp+0xD0], xmm14
000079bd661dcb2b  vmovaps [rsp+0xE0], xmm15
000079bd661dcb34  sub rsp, 0x30
000079bd661dcb38  movaps [rsp], xmm7
000079bd661dcb3c  movaps [rsp+0x10], xmm9
000079bd661dcb42  movaps [rsp+0x20], xmm15
000079bd661dcb48  lea rdi, [rsp]
000079bd661dcb4c  mov esi, 0x00
000079bd661dcb51  mov rax, 0x56EBD57B0530
000079bd661dcb5b  call rax
000079bd661dcb5d  movaps xmm7, [rsp]
000079bd661dcb61  add rsp, 0x30
000079bd661dcb65  vmovaps xmm0, [rsp]
000079bd661dcb6a  vmovaps xmm1, [rsp+0x10]
000079bd661dcb70  vmovaps xmm2, [rsp+0x20]
000079bd661dcb76  vmovaps xmm3, [rsp+0x30]
000079bd661dcb7c  vmovaps xmm4, [rsp+0x40]
000079bd661dcb82  vmovaps xmm5, [rsp+0x50]
000079bd661dcb88  vmovaps xmm6, [rsp+0x60]
000079bd661dcb8e  vmovaps xmm8, [rsp+0x70]
000079bd661dcb94  vmovaps xmm9, [rsp+0x80]
000079bd661dcb9d  vmovaps xmm10, [rsp+0x90]
000079bd661dcba6  vmovaps xmm11, [rsp+0xA0]
000079bd661dcbaf  vmovaps xmm12, [rsp+0xB0]
000079bd661dcbb8  vmovaps xmm13, [rsp+0xC0]
000079bd661dcbc1  vmovaps xmm14, [rsp+0xD0]
000079bd661dcbca  vmovaps xmm15, [rsp+0xE0]
000079bd661dcbd3  add rsp, 0xF0
000079bd661dcbda  pop r11
000079bd661dcbdc  pop r10
000079bd661dcbde  pop r9
000079bd661dcbe0  pop r8
000079bd661dcbe2  pop rsi
000079bd661dcbe3  pop rdi
000079bd661dcbe4  pop rdx
000079bd661dcbe5  pop rcx
000079bd661dcbe6  pop rax
000079bd661dcbe7  add rsp, 0x08
000079bd661dcbeb  jmp 0x000079BD661DBB75
000079bd661dcbf0  sub rsp, 0x08
000079bd661dcbf4  push rax
000079bd661dcbf5  push rcx
000079bd661dcbf6  push rdx
000079bd661dcbf7  push rdi
000079bd661dcbf8  push rsi
000079bd661dcbf9  push r8
000079bd661dcbfb  push r9
000079bd661dcbfd  push r10
000079bd661dcbff  push r11
000079bd661dcc01  sub rsp, 0xF0
000079bd661dcc08  vmovaps [rsp], xmm0
000079bd661dcc0d  vmovaps [rsp+0x10], xmm1
000079bd661dcc13  vmovaps [rsp+0x20], xmm2
000079bd661dcc19  vmovaps [rsp+0x30], xmm3
000079bd661dcc1f  vmovaps [rsp+0x40], xmm4
000079bd661dcc25  vmovaps [rsp+0x50], xmm5
000079bd661dcc2b  vmovaps [rsp+0x60], xmm6
000079bd661dcc31  vmovaps [rsp+0x70], xmm7
000079bd661dcc37  vmovaps [rsp+0x80], xmm8
000079bd661dcc40  vmovaps [rsp+0x90], xmm10
000079bd661dcc49  vmovaps [rsp+0xA0], xmm11
000079bd661dcc52  vmovaps [rsp+0xB0], xmm12
000079bd661dcc5b  vmovaps [rsp+0xC0], xmm13
000079bd661dcc64  vmovaps [rsp+0xD0], xmm14
000079bd661dcc6d  vmovaps [rsp+0xE0], xmm15
000079bd661dcc76  sub rsp, 0x30
000079bd661dcc7a  movaps [rsp], xmm9
000079bd661dcc7f  movaps [rsp+0x10], xmm12
000079bd661dcc85  movaps [rsp+0x20], xmm10
000079bd661dcc8b  lea rdi, [rsp]
000079bd661dcc8f  mov esi, 0x00
000079bd661dcc94  mov rax, 0x56EBD57B0530
000079bd661dcc9e  call rax
000079bd661dcca0  movaps xmm9, [rsp]
000079bd661dcca5  add rsp, 0x30
000079bd661dcca9  vmovaps xmm0, [rsp]
000079bd661dccae  vmovaps xmm1, [rsp+0x10]
000079bd661dccb4  vmovaps xmm2, [rsp+0x20]
000079bd661dccba  vmovaps xmm3, [rsp+0x30]
000079bd661dccc0  vmovaps xmm4, [rsp+0x40]
000079bd661dccc6  vmovaps xmm5, [rsp+0x50]
000079bd661dcccc  vmovaps xmm6, [rsp+0x60]
000079bd661dccd2  vmovaps xmm7, [rsp+0x70]
000079bd661dccd8  vmovaps xmm8, [rsp+0x80]
000079bd661dcce1  vmovaps xmm10, [rsp+0x90]
000079bd661dccea  vmovaps xmm11, [rsp+0xA0]
000079bd661dccf3  vmovaps xmm12, [rsp+0xB0]
000079bd661dccfc  vmovaps xmm13, [rsp+0xC0]
000079bd661dcd05  vmovaps xmm14, [rsp+0xD0]
000079bd661dcd0e  vmovaps xmm15, [rsp+0xE0]
000079bd661dcd17  add rsp, 0xF0
000079bd661dcd1e  pop r11
000079bd661dcd20  pop r10
000079bd661dcd22  pop r9
000079bd661dcd24  pop r8
000079bd661dcd26  pop rsi
000079bd661dcd27  pop rdi
000079bd661dcd28  pop rdx
000079bd661dcd29  pop rcx
000079bd661dcd2a  pop rax
000079bd661dcd2b  add rsp, 0x08
000079bd661dcd2f  jmp 0x000079BD661DBB99
000079bd661dcd34  sub rsp, 0x08
000079bd661dcd38  push rax
000079bd661dcd39  push rcx
000079bd661dcd3a  push rdx
000079bd661dcd3b  push rdi
000079bd661dcd3c  push rsi
000079bd661dcd3d  push r8
000079bd661dcd3f  push r9
000079bd661dcd41  push r10
000079bd661dcd43  push r11
000079bd661dcd45  sub rsp, 0xF0
000079bd661dcd4c  vmovaps [rsp], xmm0
000079bd661dcd51  vmovaps [rsp+0x10], xmm1
000079bd661dcd57  vmovaps [rsp+0x20], xmm2
000079bd661dcd5d  vmovaps [rsp+0x30], xmm3
000079bd661dcd63  vmovaps [rsp+0x40], xmm4
000079bd661dcd69  vmovaps [rsp+0x50], xmm5
000079bd661dcd6f  vmovaps [rsp+0x60], xmm6
000079bd661dcd75  vmovaps [rsp+0x70], xmm7
000079bd661dcd7b  vmovaps [rsp+0x80], xmm8
000079bd661dcd84  vmovaps [rsp+0x90], xmm9
000079bd661dcd8d  vmovaps [rsp+0xA0], xmm11
000079bd661dcd96  vmovaps [rsp+0xB0], xmm12
000079bd661dcd9f  vmovaps [rsp+0xC0], xmm13
000079bd661dcda8  vmovaps [rsp+0xD0], xmm14
000079bd661dcdb1  vmovaps [rsp+0xE0], xmm15
000079bd661dcdba  sub rsp, 0x30
000079bd661dcdbe  movaps [rsp], xmm10
000079bd661dcdc3  movaps [rsp+0x10], xmm12
000079bd661dcdc9  movaps [rsp+0x20], xmm11
000079bd661dcdcf  lea rdi, [rsp]
000079bd661dcdd3  mov esi, 0x00
000079bd661dcdd8  mov rax, 0x56EBD57B0530
000079bd661dcde2  call rax
000079bd661dcde4  movaps xmm10, [rsp]
000079bd661dcde9  add rsp, 0x30
000079bd661dcded  vmovaps xmm0, [rsp]
000079bd661dcdf2  vmovaps xmm1, [rsp+0x10]
000079bd661dcdf8  vmovaps xmm2, [rsp+0x20]
000079bd661dcdfe  vmovaps xmm3, [rsp+0x30]
000079bd661dce04  vmovaps xmm4, [rsp+0x40]
000079bd661dce0a  vmovaps xmm5, [rsp+0x50]
000079bd661dce10  vmovaps xmm6, [rsp+0x60]
000079bd661dce16  vmovaps xmm7, [rsp+0x70]
000079bd661dce1c  vmovaps xmm8, [rsp+0x80]
000079bd661dce25  vmovaps xmm9, [rsp+0x90]
000079bd661dce2e  vmovaps xmm11, [rsp+0xA0]
000079bd661dce37  vmovaps xmm12, [rsp+0xB0]
000079bd661dce40  vmovaps xmm13, [rsp+0xC0]
000079bd661dce49  vmovaps xmm14, [rsp+0xD0]
000079bd661dce52  vmovaps xmm15, [rsp+0xE0]
000079bd661dce5b  add rsp, 0xF0
000079bd661dce62  pop r11
000079bd661dce64  pop r10
000079bd661dce66  pop r9
000079bd661dce68  pop r8
000079bd661dce6a  pop rsi
000079bd661dce6b  pop rdi
000079bd661dce6c  pop rdx
000079bd661dce6d  pop rcx
000079bd661dce6e  pop rax
000079bd661dce6f  add rsp, 0x08
000079bd661dce73  jmp 0x000079BD661DBBB3
000079bd661dce78  sub rsp, 0x08
000079bd661dce7c  push rax
000079bd661dce7d  push rcx
000079bd661dce7e  push rdx
000079bd661dce7f  push rdi
000079bd661dce80  push rsi
000079bd661dce81  push r8
000079bd661dce83  push r9
000079bd661dce85  push r10
000079bd661dce87  push r11
000079bd661dce89  sub rsp, 0xF0
000079bd661dce90  vmovaps [rsp], xmm0
000079bd661dce95  vmovaps [rsp+0x10], xmm1
000079bd661dce9b  vmovaps [rsp+0x20], xmm2
000079bd661dcea1  vmovaps [rsp+0x30], xmm3
000079bd661dcea7  vmovaps [rsp+0x40], xmm4
000079bd661dcead  vmovaps [rsp+0x50], xmm5
000079bd661dceb3  vmovaps [rsp+0x60], xmm7
000079bd661dceb9  vmovaps [rsp+0x70], xmm8
000079bd661dcebf  vmovaps [rsp+0x80], xmm9
000079bd661dcec8  vmovaps [rsp+0x90], xmm10
000079bd661dced1  vmovaps [rsp+0xA0], xmm11
000079bd661dceda  vmovaps [rsp+0xB0], xmm12
000079bd661dcee3  vmovaps [rsp+0xC0], xmm13
000079bd661dceec  vmovaps [rsp+0xD0], xmm14
000079bd661dcef5  vmovaps [rsp+0xE0], xmm15
000079bd661dcefe  sub rsp, 0x30
000079bd661dcf02  movaps [rsp], xmm6
000079bd661dcf06  movaps [rsp+0x10], xmm12
000079bd661dcf0c  movaps [rsp+0x20], xmm11
000079bd661dcf12  lea rdi, [rsp]
000079bd661dcf16  mov esi, 0x00
000079bd661dcf1b  mov rax, 0x56EBD57B0530
000079bd661dcf25  call rax
000079bd661dcf27  movaps xmm6, [rsp]
000079bd661dcf2b  add rsp, 0x30
000079bd661dcf2f  vmovaps xmm0, [rsp]
000079bd661dcf34  vmovaps xmm1, [rsp+0x10]
000079bd661dcf3a  vmovaps xmm2, [rsp+0x20]
000079bd661dcf40  vmovaps xmm3, [rsp+0x30]
000079bd661dcf46  vmovaps xmm4, [rsp+0x40]
000079bd661dcf4c  vmovaps xmm5, [rsp+0x50]
000079bd661dcf52  vmovaps xmm7, [rsp+0x60]
000079bd661dcf58  vmovaps xmm8, [rsp+0x70]
000079bd661dcf5e  vmovaps xmm9, [rsp+0x80]
000079bd661dcf67  vmovaps xmm10, [rsp+0x90]
000079bd661dcf70  vmovaps xmm11, [rsp+0xA0]
000079bd661dcf79  vmovaps xmm12, [rsp+0xB0]
000079bd661dcf82  vmovaps xmm13, [rsp+0xC0]
000079bd661dcf8b  vmovaps xmm14, [rsp+0xD0]
000079bd661dcf94  vmovaps xmm15, [rsp+0xE0]
000079bd661dcf9d  add rsp, 0xF0
000079bd661dcfa4  pop r11
000079bd661dcfa6  pop r10
000079bd661dcfa8  pop r9
000079bd661dcfaa  pop r8
000079bd661dcfac  pop rsi
000079bd661dcfad  pop rdi
000079bd661dcfae  pop rdx
000079bd661dcfaf  pop rcx
000079bd661dcfb0  pop rax
000079bd661dcfb1  add rsp, 0x08
000079bd661dcfb5  jmp 0x000079BD661DBBD4
000079bd661dcfba  sub rsp, 0x08
000079bd661dcfbe  push rax
000079bd661dcfbf  push rcx
000079bd661dcfc0  push rdx
000079bd661dcfc1  push rdi
000079bd661dcfc2  push rsi
000079bd661dcfc3  push r8
000079bd661dcfc5  push r9
000079bd661dcfc7  push r10
000079bd661dcfc9  push r11
000079bd661dcfcb  sub rsp, 0xF0
000079bd661dcfd2  vmovaps [rsp], xmm0
000079bd661dcfd7  vmovaps [rsp+0x10], xmm1
000079bd661dcfdd  vmovaps [rsp+0x20], xmm2
000079bd661dcfe3  vmovaps [rsp+0x30], xmm4
000079bd661dcfe9  vmovaps [rsp+0x40], xmm5
000079bd661dcfef  vmovaps [rsp+0x50], xmm6
000079bd661dcff5  vmovaps [rsp+0x60], xmm7
000079bd661dcffb  vmovaps [rsp+0x70], xmm8
000079bd661dd001  vmovaps [rsp+0x80], xmm9
000079bd661dd00a  vmovaps [rsp+0x90], xmm10
000079bd661dd013  vmovaps [rsp+0xA0], xmm11
000079bd661dd01c  vmovaps [rsp+0xB0], xmm12
000079bd661dd025  vmovaps [rsp+0xC0], xmm13
000079bd661dd02e  vmovaps [rsp+0xD0], xmm14
000079bd661dd037  vmovaps [rsp+0xE0], xmm15
000079bd661dd040  sub rsp, 0x30
000079bd661dd044  movaps [rsp], xmm3
000079bd661dd048  movaps [rsp+0x10], xmm5
000079bd661dd04d  movaps [rsp+0x20], xmm4
000079bd661dd052  lea rdi, [rsp]
000079bd661dd056  mov esi, 0x00
000079bd661dd05b  mov rax, 0x56EBD57B0530
000079bd661dd065  call rax
000079bd661dd067  movaps xmm3, [rsp]
000079bd661dd06b  add rsp, 0x30
000079bd661dd06f  vmovaps xmm0, [rsp]
000079bd661dd074  vmovaps xmm1, [rsp+0x10]
000079bd661dd07a  vmovaps xmm2, [rsp+0x20]
000079bd661dd080  vmovaps xmm4, [rsp+0x30]
000079bd661dd086  vmovaps xmm5, [rsp+0x40]
000079bd661dd08c  vmovaps xmm6, [rsp+0x50]
000079bd661dd092  vmovaps xmm7, [rsp+0x60]
000079bd661dd098  vmovaps xmm8, [rsp+0x70]
000079bd661dd09e  vmovaps xmm9, [rsp+0x80]
000079bd661dd0a7  vmovaps xmm10, [rsp+0x90]
000079bd661dd0b0  vmovaps xmm11, [rsp+0xA0]
000079bd661dd0b9  vmovaps xmm12, [rsp+0xB0]
000079bd661dd0c2  vmovaps xmm13, [rsp+0xC0]
000079bd661dd0cb  vmovaps xmm14, [rsp+0xD0]
000079bd661dd0d4  vmovaps xmm15, [rsp+0xE0]
000079bd661dd0dd  add rsp, 0xF0
000079bd661dd0e4  pop r11
000079bd661dd0e6  pop r10
000079bd661dd0e8  pop r9
000079bd661dd0ea  pop r8
000079bd661dd0ec  pop rsi
000079bd661dd0ed  pop rdi
000079bd661dd0ee  pop rdx
000079bd661dd0ef  pop rcx
000079bd661dd0f0  pop rax
000079bd661dd0f1  add rsp, 0x08
000079bd661dd0f5  jmp 0x000079BD661DBC35
000079bd661dd0fa  sub rsp, 0x08
000079bd661dd0fe  push rax
000079bd661dd0ff  push rcx
000079bd661dd100  push rdx
000079bd661dd101  push rdi
000079bd661dd102  push rsi
000079bd661dd103  push r8
000079bd661dd105  push r9
000079bd661dd107  push r10
000079bd661dd109  push r11
000079bd661dd10b  sub rsp, 0xF0
000079bd661dd112  vmovaps [rsp], xmm0
000079bd661dd117  vmovaps [rsp+0x10], xmm1
000079bd661dd11d  vmovaps [rsp+0x20], xmm2
000079bd661dd123  vmovaps [rsp+0x30], xmm3
000079bd661dd129  vmovaps [rsp+0x40], xmm4
000079bd661dd12f  vmovaps [rsp+0x50], xmm6
000079bd661dd135  vmovaps [rsp+0x60], xmm7
000079bd661dd13b  vmovaps [rsp+0x70], xmm8
000079bd661dd141  vmovaps [rsp+0x80], xmm9
000079bd661dd14a  vmovaps [rsp+0x90], xmm10
000079bd661dd153  vmovaps [rsp+0xA0], xmm11
000079bd661dd15c  vmovaps [rsp+0xB0], xmm12
000079bd661dd165  vmovaps [rsp+0xC0], xmm13
000079bd661dd16e  vmovaps [rsp+0xD0], xmm14
000079bd661dd177  vmovaps [rsp+0xE0], xmm15
000079bd661dd180  sub rsp, 0x30
000079bd661dd184  movaps [rsp], xmm5
000079bd661dd188  movaps [rsp+0x10], xmm8
000079bd661dd18e  movaps [rsp+0x20], xmm15
000079bd661dd194  lea rdi, [rsp]
000079bd661dd198  mov esi, 0x00
000079bd661dd19d  mov rax, 0x56EBD57B0530
000079bd661dd1a7  call rax
000079bd661dd1a9  movaps xmm5, [rsp]
000079bd661dd1ad  add rsp, 0x30
000079bd661dd1b1  vmovaps xmm0, [rsp]
000079bd661dd1b6  vmovaps xmm1, [rsp+0x10]
000079bd661dd1bc  vmovaps xmm2, [rsp+0x20]
000079bd661dd1c2  vmovaps xmm3, [rsp+0x30]
000079bd661dd1c8  vmovaps xmm4, [rsp+0x40]
000079bd661dd1ce  vmovaps xmm6, [rsp+0x50]
000079bd661dd1d4  vmovaps xmm7, [rsp+0x60]
000079bd661dd1da  vmovaps xmm8, [rsp+0x70]
000079bd661dd1e0  vmovaps xmm9, [rsp+0x80]
000079bd661dd1e9  vmovaps xmm10, [rsp+0x90]
000079bd661dd1f2  vmovaps xmm11, [rsp+0xA0]
000079bd661dd1fb  vmovaps xmm12, [rsp+0xB0]
000079bd661dd204  vmovaps xmm13, [rsp+0xC0]
000079bd661dd20d  vmovaps xmm14, [rsp+0xD0]
000079bd661dd216  vmovaps xmm15, [rsp+0xE0]
000079bd661dd21f  add rsp, 0xF0
000079bd661dd226  pop r11
000079bd661dd228  pop r10
000079bd661dd22a  pop r9
000079bd661dd22c  pop r8
000079bd661dd22e  pop rsi
000079bd661dd22f  pop rdi
000079bd661dd230  pop rdx
000079bd661dd231  pop rcx
000079bd661dd232  pop rax
000079bd661dd233  add rsp, 0x08
000079bd661dd237  jmp 0x000079BD661DBC73
000079bd661dd23c  sub rsp, 0x08
000079bd661dd240  push rax
000079bd661dd241  push rcx
000079bd661dd242  push rdx
000079bd661dd243  push rdi
000079bd661dd244  push rsi
000079bd661dd245  push r8
000079bd661dd247  push r9
000079bd661dd249  push r10
000079bd661dd24b  push r11
000079bd661dd24d  sub rsp, 0xF0
000079bd661dd254  vmovaps [rsp], xmm0
000079bd661dd259  vmovaps [rsp+0x10], xmm1
000079bd661dd25f  vmovaps [rsp+0x20], xmm2
000079bd661dd265  vmovaps [rsp+0x30], xmm3
000079bd661dd26b  vmovaps [rsp+0x40], xmm5
000079bd661dd271  vmovaps [rsp+0x50], xmm6
000079bd661dd277  vmovaps [rsp+0x60], xmm7
000079bd661dd27d  vmovaps [rsp+0x70], xmm8
000079bd661dd283  vmovaps [rsp+0x80], xmm9
000079bd661dd28c  vmovaps [rsp+0x90], xmm10
000079bd661dd295  vmovaps [rsp+0xA0], xmm11
000079bd661dd29e  vmovaps [rsp+0xB0], xmm12
000079bd661dd2a7  vmovaps [rsp+0xC0], xmm13
000079bd661dd2b0  vmovaps [rsp+0xD0], xmm14
000079bd661dd2b9  vmovaps [rsp+0xE0], xmm15
000079bd661dd2c2  sub rsp, 0x30
000079bd661dd2c6  movaps [rsp], xmm4
000079bd661dd2ca  movaps [rsp+0x10], xmm9
000079bd661dd2d0  movaps [rsp+0x20], xmm8
000079bd661dd2d6  lea rdi, [rsp]
000079bd661dd2da  mov esi, 0x00
000079bd661dd2df  mov rax, 0x56EBD57B0530
000079bd661dd2e9  call rax
000079bd661dd2eb  movaps xmm4, [rsp]
000079bd661dd2ef  add rsp, 0x30
000079bd661dd2f3  vmovaps xmm0, [rsp]
000079bd661dd2f8  vmovaps xmm1, [rsp+0x10]
000079bd661dd2fe  vmovaps xmm2, [rsp+0x20]
000079bd661dd304  vmovaps xmm3, [rsp+0x30]
000079bd661dd30a  vmovaps xmm5, [rsp+0x40]
000079bd661dd310  vmovaps xmm6, [rsp+0x50]
000079bd661dd316  vmovaps xmm7, [rsp+0x60]
000079bd661dd31c  vmovaps xmm8, [rsp+0x70]
000079bd661dd322  vmovaps xmm9, [rsp+0x80]
000079bd661dd32b  vmovaps xmm10, [rsp+0x90]
000079bd661dd334  vmovaps xmm11, [rsp+0xA0]
000079bd661dd33d  vmovaps xmm12, [rsp+0xB0]
000079bd661dd346  vmovaps xmm13, [rsp+0xC0]
000079bd661dd34f  vmovaps xmm14, [rsp+0xD0]
000079bd661dd358  vmovaps xmm15, [rsp+0xE0]
000079bd661dd361  add rsp, 0xF0
000079bd661dd368  pop r11
000079bd661dd36a  pop r10
000079bd661dd36c  pop r9
000079bd661dd36e  pop r8
000079bd661dd370  pop rsi
000079bd661dd371  pop rdi
000079bd661dd372  pop rdx
000079bd661dd373  pop rcx
000079bd661dd374  pop rax
000079bd661dd375  add rsp, 0x08
000079bd661dd379  jmp 0x000079BD661DBC94
000079bd661dd37e  sub rsp, 0x08
000079bd661dd382  push rax
000079bd661dd383  push rcx
000079bd661dd384  push rdx
000079bd661dd385  push rdi
000079bd661dd386  push rsi
000079bd661dd387  push r8
000079bd661dd389  push r9
000079bd661dd38b  push r10
000079bd661dd38d  push r11
000079bd661dd38f  sub rsp, 0xF0
000079bd661dd396  vmovaps [rsp], xmm0
000079bd661dd39b  vmovaps [rsp+0x10], xmm1
000079bd661dd3a1  vmovaps [rsp+0x20], xmm2
000079bd661dd3a7  vmovaps [rsp+0x30], xmm3
000079bd661dd3ad  vmovaps [rsp+0x40], xmm4
000079bd661dd3b3  vmovaps [rsp+0x50], xmm5
000079bd661dd3b9  vmovaps [rsp+0x60], xmm6
000079bd661dd3bf  vmovaps [rsp+0x70], xmm7
000079bd661dd3c5  vmovaps [rsp+0x80], xmm8
000079bd661dd3ce  vmovaps [rsp+0x90], xmm10
000079bd661dd3d7  vmovaps [rsp+0xA0], xmm11
000079bd661dd3e0  vmovaps [rsp+0xB0], xmm12
000079bd661dd3e9  vmovaps [rsp+0xC0], xmm13
000079bd661dd3f2  vmovaps [rsp+0xD0], xmm14
000079bd661dd3fb  vmovaps [rsp+0xE0], xmm15
000079bd661dd404  sub rsp, 0x30
000079bd661dd408  movaps [rsp], xmm9
000079bd661dd40d  movaps [rsp+0x10], xmm10
000079bd661dd413  movaps [rsp+0x20], xmm8
000079bd661dd419  lea rdi, [rsp]
000079bd661dd41d  mov esi, 0x00
000079bd661dd422  mov rax, 0x56EBD57B0530
000079bd661dd42c  call rax
000079bd661dd42e  movaps xmm9, [rsp]
000079bd661dd433  add rsp, 0x30
000079bd661dd437  vmovaps xmm0, [rsp]
000079bd661dd43c  vmovaps xmm1, [rsp+0x10]
000079bd661dd442  vmovaps xmm2, [rsp+0x20]
000079bd661dd448  vmovaps xmm3, [rsp+0x30]
000079bd661dd44e  vmovaps xmm4, [rsp+0x40]
000079bd661dd454  vmovaps xmm5, [rsp+0x50]
000079bd661dd45a  vmovaps xmm6, [rsp+0x60]
000079bd661dd460  vmovaps xmm7, [rsp+0x70]
000079bd661dd466  vmovaps xmm8, [rsp+0x80]
000079bd661dd46f  vmovaps xmm10, [rsp+0x90]
000079bd661dd478  vmovaps xmm11, [rsp+0xA0]
000079bd661dd481  vmovaps xmm12, [rsp+0xB0]
000079bd661dd48a  vmovaps xmm13, [rsp+0xC0]
000079bd661dd493  vmovaps xmm14, [rsp+0xD0]
000079bd661dd49c  vmovaps xmm15, [rsp+0xE0]
000079bd661dd4a5  add rsp, 0xF0
000079bd661dd4ac  pop r11
000079bd661dd4ae  pop r10
000079bd661dd4b0  pop r9
000079bd661dd4b2  pop r8
000079bd661dd4b4  pop rsi
000079bd661dd4b5  pop rdi
000079bd661dd4b6  pop rdx
000079bd661dd4b7  pop rcx
000079bd661dd4b8  pop rax
000079bd661dd4b9  add rsp, 0x08
000079bd661dd4bd  jmp 0x000079BD661DBCAE
000079bd661dd4c2  call 0x000079BD660B52F0
000079bd661dd4c7  jmp 0x000079BD661DBDC8
000079bd661dd4cc  call 0x000079BD660B52F0
000079bd661dd4d1  jmp 0x000079BD661DBDDE
000079bd661dd4d6  sub rsp, 0x08
000079bd661dd4da  push rax
000079bd661dd4db  push rcx
000079bd661dd4dc  push rdx
000079bd661dd4dd  push rdi
000079bd661dd4de  push rsi
000079bd661dd4df  push r8
000079bd661dd4e1  push r9
000079bd661dd4e3  push r10
000079bd661dd4e5  push r11
000079bd661dd4e7  sub rsp, 0xF0
000079bd661dd4ee  vmovaps [rsp], xmm0
000079bd661dd4f3  vmovaps [rsp+0x10], xmm2
000079bd661dd4f9  vmovaps [rsp+0x20], xmm3
000079bd661dd4ff  vmovaps [rsp+0x30], xmm4
000079bd661dd505  vmovaps [rsp+0x40], xmm5
000079bd661dd50b  vmovaps [rsp+0x50], xmm6
000079bd661dd511  vmovaps [rsp+0x60], xmm7
000079bd661dd517  vmovaps [rsp+0x70], xmm8
000079bd661dd51d  vmovaps [rsp+0x80], xmm9
000079bd661dd526  vmovaps [rsp+0x90], xmm10
000079bd661dd52f  vmovaps [rsp+0xA0], xmm11
000079bd661dd538  vmovaps [rsp+0xB0], xmm12
000079bd661dd541  vmovaps [rsp+0xC0], xmm13
000079bd661dd54a  vmovaps [rsp+0xD0], xmm14
000079bd661dd553  vmovaps [rsp+0xE0], xmm15
000079bd661dd55c  sub rsp, 0x30
000079bd661dd560  movaps [rsp], xmm1
000079bd661dd564  movaps [rsp+0x10], xmm6
000079bd661dd569  movaps [rsp+0x20], xmm15
000079bd661dd56f  lea rdi, [rsp]
000079bd661dd573  mov esi, 0x00
000079bd661dd578  mov rax, 0x56EBD57B0530
000079bd661dd582  call rax
000079bd661dd584  movaps xmm1, [rsp]
000079bd661dd588  add rsp, 0x30
000079bd661dd58c  vmovaps xmm0, [rsp]
000079bd661dd591  vmovaps xmm2, [rsp+0x10]
000079bd661dd597  vmovaps xmm3, [rsp+0x20]
000079bd661dd59d  vmovaps xmm4, [rsp+0x30]
000079bd661dd5a3  vmovaps xmm5, [rsp+0x40]
000079bd661dd5a9  vmovaps xmm6, [rsp+0x50]
000079bd661dd5af  vmovaps xmm7, [rsp+0x60]
000079bd661dd5b5  vmovaps xmm8, [rsp+0x70]
000079bd661dd5bb  vmovaps xmm9, [rsp+0x80]
000079bd661dd5c4  vmovaps xmm10, [rsp+0x90]
000079bd661dd5cd  vmovaps xmm11, [rsp+0xA0]
000079bd661dd5d6  vmovaps xmm12, [rsp+0xB0]
000079bd661dd5df  vmovaps xmm13, [rsp+0xC0]
000079bd661dd5e8  vmovaps xmm14, [rsp+0xD0]
000079bd661dd5f1  vmovaps xmm15, [rsp+0xE0]
000079bd661dd5fa  add rsp, 0xF0
000079bd661dd601  pop r11
000079bd661dd603  pop r10
000079bd661dd605  pop r9
000079bd661dd607  pop r8
000079bd661dd609  pop rsi
000079bd661dd60a  pop rdi
000079bd661dd60b  pop rdx
000079bd661dd60c  pop rcx
000079bd661dd60d  pop rax
000079bd661dd60e  add rsp, 0x08
000079bd661dd612  jmp 0x000079BD661DBE1B
000079bd661dd617  call 0x000079BD660C4620
000079bd661dd61c  jmp 0x000079BD661DBE28
000079bd661dd621  sub rsp, 0x08
000079bd661dd625  push rax
000079bd661dd626  push rcx
000079bd661dd627  push rdx
000079bd661dd628  push rdi
000079bd661dd629  push rsi
000079bd661dd62a  push r8
000079bd661dd62c  push r9
000079bd661dd62e  push r10
000079bd661dd630  push r11
000079bd661dd632  sub rsp, 0xF0
000079bd661dd639  vmovaps [rsp], xmm0
000079bd661dd63e  vmovaps [rsp+0x10], xmm1
000079bd661dd644  vmovaps [rsp+0x20], xmm2
000079bd661dd64a  vmovaps [rsp+0x30], xmm3
000079bd661dd650  vmovaps [rsp+0x40], xmm4
000079bd661dd656  vmovaps [rsp+0x50], xmm5
000079bd661dd65c  vmovaps [rsp+0x60], xmm6
000079bd661dd662  vmovaps [rsp+0x70], xmm7
000079bd661dd668  vmovaps [rsp+0x80], xmm8
000079bd661dd671  vmovaps [rsp+0x90], xmm9
000079bd661dd67a  vmovaps [rsp+0xA0], xmm10
000079bd661dd683  vmovaps [rsp+0xB0], xmm11
000079bd661dd68c  vmovaps [rsp+0xC0], xmm12
000079bd661dd695  vmovaps [rsp+0xD0], xmm13
000079bd661dd69e  vmovaps [rsp+0xE0], xmm15
000079bd661dd6a7  sub rsp, 0x30
000079bd661dd6ab  movaps [rsp], xmm14
000079bd661dd6b0  movaps [rsp+0x10], xmm4
000079bd661dd6b5  movaps [rsp+0x20], xmm3
000079bd661dd6ba  lea rdi, [rsp]
000079bd661dd6be  mov esi, 0x00
000079bd661dd6c3  mov rax, 0x56EBD57B0530
000079bd661dd6cd  call rax
000079bd661dd6cf  movaps xmm14, [rsp]
000079bd661dd6d4  add rsp, 0x30
000079bd661dd6d8  vmovaps xmm0, [rsp]
000079bd661dd6dd  vmovaps xmm1, [rsp+0x10]
000079bd661dd6e3  vmovaps xmm2, [rsp+0x20]
000079bd661dd6e9  vmovaps xmm3, [rsp+0x30]
000079bd661dd6ef  vmovaps xmm4, [rsp+0x40]
000079bd661dd6f5  vmovaps xmm5, [rsp+0x50]
000079bd661dd6fb  vmovaps xmm6, [rsp+0x60]
000079bd661dd701  vmovaps xmm7, [rsp+0x70]
000079bd661dd707  vmovaps xmm8, [rsp+0x80]
000079bd661dd710  vmovaps xmm9, [rsp+0x90]
000079bd661dd719  vmovaps xmm10, [rsp+0xA0]
000079bd661dd722  vmovaps xmm11, [rsp+0xB0]
000079bd661dd72b  vmovaps xmm12, [rsp+0xC0]
000079bd661dd734  vmovaps xmm13, [rsp+0xD0]
000079bd661dd73d  vmovaps xmm15, [rsp+0xE0]
000079bd661dd746  add rsp, 0xF0
000079bd661dd74d  pop r11
000079bd661dd74f  pop r10
000079bd661dd751  pop r9
000079bd661dd753  pop r8
000079bd661dd755  pop rsi
000079bd661dd756  pop rdi
000079bd661dd757  pop rdx
000079bd661dd758  pop rcx
000079bd661dd759  pop rax
000079bd661dd75a  add rsp, 0x08
000079bd661dd75e  jmp 0x000079BD661DBE42
000079bd661dd763  sub rsp, 0x08
000079bd661dd767  push rax
000079bd661dd768  push rcx
000079bd661dd769  push rdx
000079bd661dd76a  push rdi
000079bd661dd76b  push rsi
000079bd661dd76c  push r8
000079bd661dd76e  push r9
000079bd661dd770  push r10
000079bd661dd772  push r11
000079bd661dd774  sub rsp, 0xF0
000079bd661dd77b  vmovaps [rsp], xmm0
000079bd661dd780  vmovaps [rsp+0x10], xmm1
000079bd661dd786  vmovaps [rsp+0x20], xmm2
000079bd661dd78c  vmovaps [rsp+0x30], xmm3
000079bd661dd792  vmovaps [rsp+0x40], xmm4
000079bd661dd798  vmovaps [rsp+0x50], xmm5
000079bd661dd79e  vmovaps [rsp+0x60], xmm7
000079bd661dd7a4  vmovaps [rsp+0x70], xmm8
000079bd661dd7aa  vmovaps [rsp+0x80], xmm9
000079bd661dd7b3  vmovaps [rsp+0x90], xmm10
000079bd661dd7bc  vmovaps [rsp+0xA0], xmm11
000079bd661dd7c5  vmovaps [rsp+0xB0], xmm12
000079bd661dd7ce  vmovaps [rsp+0xC0], xmm13
000079bd661dd7d7  vmovaps [rsp+0xD0], xmm14
000079bd661dd7e0  vmovaps [rsp+0xE0], xmm15
000079bd661dd7e9  sub rsp, 0x30
000079bd661dd7ed  movaps [rsp], xmm6
000079bd661dd7f1  movaps [rsp+0x10], xmm9
000079bd661dd7f7  movaps [rsp+0x20], xmm7
000079bd661dd7fc  lea rdi, [rsp]
000079bd661dd800  mov esi, 0x00
000079bd661dd805  mov rax, 0x56EBD57B0530
000079bd661dd80f  call rax
000079bd661dd811  movaps xmm6, [rsp]
000079bd661dd815  add rsp, 0x30
000079bd661dd819  vmovaps xmm0, [rsp]
000079bd661dd81e  vmovaps xmm1, [rsp+0x10]
000079bd661dd824  vmovaps xmm2, [rsp+0x20]
000079bd661dd82a  vmovaps xmm3, [rsp+0x30]
000079bd661dd830  vmovaps xmm4, [rsp+0x40]
000079bd661dd836  vmovaps xmm5, [rsp+0x50]
000079bd661dd83c  vmovaps xmm7, [rsp+0x60]
000079bd661dd842  vmovaps xmm8, [rsp+0x70]
000079bd661dd848  vmovaps xmm9, [rsp+0x80]
000079bd661dd851  vmovaps xmm10, [rsp+0x90]
000079bd661dd85a  vmovaps xmm11, [rsp+0xA0]
000079bd661dd863  vmovaps xmm12, [rsp+0xB0]
000079bd661dd86c  vmovaps xmm13, [rsp+0xC0]
000079bd661dd875  vmovaps xmm14, [rsp+0xD0]
000079bd661dd87e  vmovaps xmm15, [rsp+0xE0]
000079bd661dd887  add rsp, 0xF0
000079bd661dd88e  pop r11
000079bd661dd890  pop r10
000079bd661dd892  pop r9
000079bd661dd894  pop r8
000079bd661dd896  pop rsi
000079bd661dd897  pop rdi
000079bd661dd898  pop rdx
000079bd661dd899  pop rcx
000079bd661dd89a  pop rax
000079bd661dd89b  add rsp, 0x08
000079bd661dd89f  jmp 0x000079BD661DBE5A
000079bd661dd8a4  sub rsp, 0x08
000079bd661dd8a8  push rax
000079bd661dd8a9  push rcx
000079bd661dd8aa  push rdx
000079bd661dd8ab  push rdi
000079bd661dd8ac  push rsi
000079bd661dd8ad  push r8
000079bd661dd8af  push r9
000079bd661dd8b1  push r10
000079bd661dd8b3  push r11
000079bd661dd8b5  sub rsp, 0xF0
000079bd661dd8bc  vmovaps [rsp], xmm0
000079bd661dd8c1  vmovaps [rsp+0x10], xmm1
000079bd661dd8c7  vmovaps [rsp+0x20], xmm2
000079bd661dd8cd  vmovaps [rsp+0x30], xmm3
000079bd661dd8d3  vmovaps [rsp+0x40], xmm4
000079bd661dd8d9  vmovaps [rsp+0x50], xmm5
000079bd661dd8df  vmovaps [rsp+0x60], xmm6
000079bd661dd8e5  vmovaps [rsp+0x70], xmm8
000079bd661dd8eb  vmovaps [rsp+0x80], xmm9
000079bd661dd8f4  vmovaps [rsp+0x90], xmm10
000079bd661dd8fd  vmovaps [rsp+0xA0], xmm11
000079bd661dd906  vmovaps [rsp+0xB0], xmm12
000079bd661dd90f  vmovaps [rsp+0xC0], xmm13
000079bd661dd918  vmovaps [rsp+0xD0], xmm14
000079bd661dd921  vmovaps [rsp+0xE0], xmm15
000079bd661dd92a  sub rsp, 0x30
000079bd661dd92e  movaps [rsp], xmm7
000079bd661dd932  movaps [rsp+0x10], xmm4
000079bd661dd937  movaps [rsp+0x20], xmm9
000079bd661dd93d  lea rdi, [rsp]
000079bd661dd941  mov esi, 0x00
000079bd661dd946  mov rax, 0x56EBD57B0530
000079bd661dd950  call rax
000079bd661dd952  movaps xmm7, [rsp]
000079bd661dd956  add rsp, 0x30
000079bd661dd95a  vmovaps xmm0, [rsp]
000079bd661dd95f  vmovaps xmm1, [rsp+0x10]
000079bd661dd965  vmovaps xmm2, [rsp+0x20]
000079bd661dd96b  vmovaps xmm3, [rsp+0x30]
000079bd661dd971  vmovaps xmm4, [rsp+0x40]
000079bd661dd977  vmovaps xmm5, [rsp+0x50]
000079bd661dd97d  vmovaps xmm6, [rsp+0x60]
000079bd661dd983  vmovaps xmm8, [rsp+0x70]
000079bd661dd989  vmovaps xmm9, [rsp+0x80]
000079bd661dd992  vmovaps xmm10, [rsp+0x90]
000079bd661dd99b  vmovaps xmm11, [rsp+0xA0]
000079bd661dd9a4  vmovaps xmm12, [rsp+0xB0]
000079bd661dd9ad  vmovaps xmm13, [rsp+0xC0]
000079bd661dd9b6  vmovaps xmm14, [rsp+0xD0]
000079bd661dd9bf  vmovaps xmm15, [rsp+0xE0]
000079bd661dd9c8  add rsp, 0xF0
000079bd661dd9cf  pop r11
000079bd661dd9d1  pop r10
000079bd661dd9d3  pop r9
000079bd661dd9d5  pop r8
000079bd661dd9d7  pop rsi
000079bd661dd9d8  pop rdi
000079bd661dd9d9  pop rdx
000079bd661dd9da  pop rcx
000079bd661dd9db  pop rax
000079bd661dd9dc  add rsp, 0x08
000079bd661dd9e0  jmp 0x000079BD661DBE87
000079bd661dd9e5  sub rsp, 0x08
000079bd661dd9e9  push rax
000079bd661dd9ea  push rcx
000079bd661dd9eb  push rdx
000079bd661dd9ec  push rdi
000079bd661dd9ed  push rsi
000079bd661dd9ee  push r8
000079bd661dd9f0  push r9
000079bd661dd9f2  push r10
000079bd661dd9f4  push r11
000079bd661dd9f6  sub rsp, 0xF0
000079bd661dd9fd  vmovaps [rsp], xmm0
000079bd661dda02  vmovaps [rsp+0x10], xmm1
000079bd661dda08  vmovaps [rsp+0x20], xmm2
000079bd661dda0e  vmovaps [rsp+0x30], xmm3
000079bd661dda14  vmovaps [rsp+0x40], xmm5
000079bd661dda1a  vmovaps [rsp+0x50], xmm6
000079bd661dda20  vmovaps [rsp+0x60], xmm7
000079bd661dda26  vmovaps [rsp+0x70], xmm8
000079bd661dda2c  vmovaps [rsp+0x80], xmm9
000079bd661dda35  vmovaps [rsp+0x90], xmm10
000079bd661dda3e  vmovaps [rsp+0xA0], xmm11
000079bd661dda47  vmovaps [rsp+0xB0], xmm12
000079bd661dda50  vmovaps [rsp+0xC0], xmm13
000079bd661dda59  vmovaps [rsp+0xD0], xmm14
000079bd661dda62  vmovaps [rsp+0xE0], xmm15
000079bd661dda6b  sub rsp, 0x30
000079bd661dda6f  movaps [rsp], xmm4
000079bd661dda73  movaps [rsp+0x10], xmm15
000079bd661dda79  movaps [rsp+0x20], xmm9
000079bd661dda7f  lea rdi, [rsp]
000079bd661dda83  mov esi, 0x00
000079bd661dda88  mov rax, 0x56EBD57B0530
000079bd661dda92  call rax
000079bd661dda94  movaps xmm4, [rsp]
000079bd661dda98  add rsp, 0x30
000079bd661dda9c  vmovaps xmm0, [rsp]
000079bd661ddaa1  vmovaps xmm1, [rsp+0x10]
000079bd661ddaa7  vmovaps xmm2, [rsp+0x20]
000079bd661ddaad  vmovaps xmm3, [rsp+0x30]
000079bd661ddab3  vmovaps xmm5, [rsp+0x40]
000079bd661ddab9  vmovaps xmm6, [rsp+0x50]
000079bd661ddabf  vmovaps xmm7, [rsp+0x60]
000079bd661ddac5  vmovaps xmm8, [rsp+0x70]
000079bd661ddacb  vmovaps xmm9, [rsp+0x80]
000079bd661ddad4  vmovaps xmm10, [rsp+0x90]
000079bd661ddadd  vmovaps xmm11, [rsp+0xA0]
000079bd661ddae6  vmovaps xmm12, [rsp+0xB0]
000079bd661ddaef  vmovaps xmm13, [rsp+0xC0]
000079bd661ddaf8  vmovaps xmm14, [rsp+0xD0]
000079bd661ddb01  vmovaps xmm15, [rsp+0xE0]
000079bd661ddb0a  add rsp, 0xF0
000079bd661ddb11  pop r11
000079bd661ddb13  pop r10
000079bd661ddb15  pop r9
000079bd661ddb17  pop r8
000079bd661ddb19  pop rsi
000079bd661ddb1a  pop rdi
000079bd661ddb1b  pop rdx
000079bd661ddb1c  pop rcx
000079bd661ddb1d  pop rax
000079bd661ddb1e  add rsp, 0x08
000079bd661ddb22  jmp 0x000079BD661DBEAC
000079bd661ddb27  call 0x000079BD660C4620
000079bd661ddb2c  jmp 0x000079BD661DBEB9
000079bd661ddb31  sub rsp, 0x08
000079bd661ddb35  push rax
000079bd661ddb36  push rcx
000079bd661ddb37  push rdx
000079bd661ddb38  push rdi
000079bd661ddb39  push rsi
000079bd661ddb3a  push r8
000079bd661ddb3c  push r9
000079bd661ddb3e  push r10
000079bd661ddb40  push r11
000079bd661ddb42  sub rsp, 0xF0
000079bd661ddb49  vmovaps [rsp], xmm0
000079bd661ddb4e  vmovaps [rsp+0x10], xmm1
000079bd661ddb54  vmovaps [rsp+0x20], xmm2
000079bd661ddb5a  vmovaps [rsp+0x30], xmm4
000079bd661ddb60  vmovaps [rsp+0x40], xmm5
000079bd661ddb66  vmovaps [rsp+0x50], xmm6
000079bd661ddb6c  vmovaps [rsp+0x60], xmm7
000079bd661ddb72  vmovaps [rsp+0x70], xmm8
000079bd661ddb78  vmovaps [rsp+0x80], xmm9
000079bd661ddb81  vmovaps [rsp+0x90], xmm10
000079bd661ddb8a  vmovaps [rsp+0xA0], xmm11
000079bd661ddb93  vmovaps [rsp+0xB0], xmm12
000079bd661ddb9c  vmovaps [rsp+0xC0], xmm13
000079bd661ddba5  vmovaps [rsp+0xD0], xmm14
000079bd661ddbae  vmovaps [rsp+0xE0], xmm15
000079bd661ddbb7  sub rsp, 0x30
000079bd661ddbbb  movaps [rsp], xmm3
000079bd661ddbbf  movaps [rsp+0x10], xmm1
000079bd661ddbc4  movaps [rsp+0x20], xmm9
000079bd661ddbca  lea rdi, [rsp]
000079bd661ddbce  mov esi, 0x00
000079bd661ddbd3  mov rax, 0x56EBD57B0530
000079bd661ddbdd  call rax
000079bd661ddbdf  movaps xmm3, [rsp]
000079bd661ddbe3  add rsp, 0x30
000079bd661ddbe7  vmovaps xmm0, [rsp]
000079bd661ddbec  vmovaps xmm1, [rsp+0x10]
000079bd661ddbf2  vmovaps xmm2, [rsp+0x20]
000079bd661ddbf8  vmovaps xmm4, [rsp+0x30]
000079bd661ddbfe  vmovaps xmm5, [rsp+0x40]
000079bd661ddc04  vmovaps xmm6, [rsp+0x50]
000079bd661ddc0a  vmovaps xmm7, [rsp+0x60]
000079bd661ddc10  vmovaps xmm8, [rsp+0x70]
000079bd661ddc16  vmovaps xmm9, [rsp+0x80]
000079bd661ddc1f  vmovaps xmm10, [rsp+0x90]
000079bd661ddc28  vmovaps xmm11, [rsp+0xA0]
000079bd661ddc31  vmovaps xmm12, [rsp+0xB0]
000079bd661ddc3a  vmovaps xmm13, [rsp+0xC0]
000079bd661ddc43  vmovaps xmm14, [rsp+0xD0]
000079bd661ddc4c  vmovaps xmm15, [rsp+0xE0]
000079bd661ddc55  add rsp, 0xF0
000079bd661ddc5c  pop r11
000079bd661ddc5e  pop r10
000079bd661ddc60  pop r9
000079bd661ddc62  pop r8
000079bd661ddc64  pop rsi
000079bd661ddc65  pop rdi
000079bd661ddc66  pop rdx
000079bd661ddc67  pop rcx
000079bd661ddc68  pop rax
000079bd661ddc69  add rsp, 0x08
000079bd661ddc6d  jmp 0x000079BD661DBEF6
000079bd661ddc72  sub rsp, 0x08
000079bd661ddc76  push rax
000079bd661ddc77  push rcx
000079bd661ddc78  push rdx
000079bd661ddc79  push rdi
000079bd661ddc7a  push rsi
000079bd661ddc7b  push r8
000079bd661ddc7d  push r9
000079bd661ddc7f  push r10
000079bd661ddc81  push r11
000079bd661ddc83  sub rsp, 0xF0
000079bd661ddc8a  vmovaps [rsp], xmm0
000079bd661ddc8f  vmovaps [rsp+0x10], xmm2
000079bd661ddc95  vmovaps [rsp+0x20], xmm3
000079bd661ddc9b  vmovaps [rsp+0x30], xmm4
000079bd661ddca1  vmovaps [rsp+0x40], xmm5
000079bd661ddca7  vmovaps [rsp+0x50], xmm6
000079bd661ddcad  vmovaps [rsp+0x60], xmm7
000079bd661ddcb3  vmovaps [rsp+0x70], xmm8
000079bd661ddcb9  vmovaps [rsp+0x80], xmm9
000079bd661ddcc2  vmovaps [rsp+0x90], xmm10
000079bd661ddccb  vmovaps [rsp+0xA0], xmm11
000079bd661ddcd4  vmovaps [rsp+0xB0], xmm12
000079bd661ddcdd  vmovaps [rsp+0xC0], xmm13
000079bd661ddce6  vmovaps [rsp+0xD0], xmm14
000079bd661ddcef  vmovaps [rsp+0xE0], xmm15
000079bd661ddcf8  sub rsp, 0x30
000079bd661ddcfc  movaps [rsp], xmm1
000079bd661ddd00  movaps [rsp+0x10], xmm15
000079bd661ddd06  movaps [rsp+0x20], xmm9
000079bd661ddd0c  lea rdi, [rsp]
000079bd661ddd10  mov esi, 0x00
000079bd661ddd15  mov rax, 0x56EBD57B0530
000079bd661ddd1f  call rax
000079bd661ddd21  movaps xmm1, [rsp]
000079bd661ddd25  add rsp, 0x30
000079bd661ddd29  vmovaps xmm0, [rsp]
000079bd661ddd2e  vmovaps xmm2, [rsp+0x10]
000079bd661ddd34  vmovaps xmm3, [rsp+0x20]
000079bd661ddd3a  vmovaps xmm4, [rsp+0x30]
000079bd661ddd40  vmovaps xmm5, [rsp+0x40]
000079bd661ddd46  vmovaps xmm6, [rsp+0x50]
000079bd661ddd4c  vmovaps xmm7, [rsp+0x60]
000079bd661ddd52  vmovaps xmm8, [rsp+0x70]
000079bd661ddd58  vmovaps xmm9, [rsp+0x80]
000079bd661ddd61  vmovaps xmm10, [rsp+0x90]
000079bd661ddd6a  vmovaps xmm11, [rsp+0xA0]
000079bd661ddd73  vmovaps xmm12, [rsp+0xB0]
000079bd661ddd7c  vmovaps xmm13, [rsp+0xC0]
000079bd661ddd85  vmovaps xmm14, [rsp+0xD0]
000079bd661ddd8e  vmovaps xmm15, [rsp+0xE0]
000079bd661ddd97  add rsp, 0xF0
000079bd661ddd9e  pop r11
000079bd661ddda0  pop r10
000079bd661ddda2  pop r9
000079bd661ddda4  pop r8
000079bd661ddda6  pop rsi
000079bd661ddda7  pop rdi
000079bd661ddda8  pop rdx
000079bd661ddda9  pop rcx
000079bd661dddaa  pop rax
000079bd661dddab  add rsp, 0x08
000079bd661dddaf  jmp 0x000079BD661DBF7E
000079bd661dddb4  call 0x000079BD660C4620
000079bd661dddb9  jmp 0x000079BD661DBF8B
000079bd661dddbe  sub rsp, 0x08
000079bd661dddc2  push rax
000079bd661dddc3  push rcx
000079bd661dddc4  push rdx
000079bd661dddc5  push rdi
000079bd661dddc6  push rsi
000079bd661dddc7  push r8
000079bd661dddc9  push r9
000079bd661dddcb  push r10
000079bd661dddcd  push r11
000079bd661dddcf  sub rsp, 0xF0
000079bd661dddd6  vmovaps [rsp], xmm0
000079bd661ddddb  vmovaps [rsp+0x10], xmm2
000079bd661ddde1  vmovaps [rsp+0x20], xmm3
000079bd661ddde7  vmovaps [rsp+0x30], xmm4
000079bd661ddded  vmovaps [rsp+0x40], xmm5
000079bd661dddf3  vmovaps [rsp+0x50], xmm6
000079bd661dddf9  vmovaps [rsp+0x60], xmm7
000079bd661dddff  vmovaps [rsp+0x70], xmm8
000079bd661dde05  vmovaps [rsp+0x80], xmm9
000079bd661dde0e  vmovaps [rsp+0x90], xmm10
000079bd661dde17  vmovaps [rsp+0xA0], xmm11
000079bd661dde20  vmovaps [rsp+0xB0], xmm12
000079bd661dde29  vmovaps [rsp+0xC0], xmm13
000079bd661dde32  vmovaps [rsp+0xD0], xmm14
000079bd661dde3b  vmovaps [rsp+0xE0], xmm15
000079bd661dde44  sub rsp, 0x30
000079bd661dde48  movaps [rsp], xmm1
000079bd661dde4c  movaps [rsp+0x10], xmm5
000079bd661dde51  movaps [rsp+0x20], xmm7
000079bd661dde56  lea rdi, [rsp]
000079bd661dde5a  mov esi, 0x00
000079bd661dde5f  mov rax, 0x56EBD57B0530
000079bd661dde69  call rax
000079bd661dde6b  movaps xmm1, [rsp]
000079bd661dde6f  add rsp, 0x30
000079bd661dde73  vmovaps xmm0, [rsp]
000079bd661dde78  vmovaps xmm2, [rsp+0x10]
000079bd661dde7e  vmovaps xmm3, [rsp+0x20]
000079bd661dde84  vmovaps xmm4, [rsp+0x30]
000079bd661dde8a  vmovaps xmm5, [rsp+0x40]
000079bd661dde90  vmovaps xmm6, [rsp+0x50]
000079bd661dde96  vmovaps xmm7, [rsp+0x60]
000079bd661dde9c  vmovaps xmm8, [rsp+0x70]
000079bd661ddea2  vmovaps xmm9, [rsp+0x80]
000079bd661ddeab  vmovaps xmm10, [rsp+0x90]
000079bd661ddeb4  vmovaps xmm11, [rsp+0xA0]
000079bd661ddebd  vmovaps xmm12, [rsp+0xB0]
000079bd661ddec6  vmovaps xmm13, [rsp+0xC0]
000079bd661ddecf  vmovaps xmm14, [rsp+0xD0]
000079bd661dded8  vmovaps xmm15, [rsp+0xE0]
000079bd661ddee1  add rsp, 0xF0
000079bd661ddee8  pop r11
000079bd661ddeea  pop r10
000079bd661ddeec  pop r9
000079bd661ddeee  pop r8
000079bd661ddef0  pop rsi
000079bd661ddef1  pop rdi
000079bd661ddef2  pop rdx
000079bd661ddef3  pop rcx
000079bd661ddef4  pop rax
000079bd661ddef5  add rsp, 0x08
000079bd661ddef9  jmp 0x000079BD661DC030
000079bd661ddefe  sub rsp, 0x08
000079bd661ddf02  push rax
000079bd661ddf03  push rcx
000079bd661ddf04  push rdx
000079bd661ddf05  push rdi
000079bd661ddf06  push rsi
000079bd661ddf07  push r8
000079bd661ddf09  push r9
000079bd661ddf0b  push r10
000079bd661ddf0d  push r11
000079bd661ddf0f  sub rsp, 0xF0
000079bd661ddf16  vmovaps [rsp], xmm0
000079bd661ddf1b  vmovaps [rsp+0x10], xmm1
000079bd661ddf21  vmovaps [rsp+0x20], xmm2
000079bd661ddf27  vmovaps [rsp+0x30], xmm3
000079bd661ddf2d  vmovaps [rsp+0x40], xmm4
000079bd661ddf33  vmovaps [rsp+0x50], xmm5
000079bd661ddf39  vmovaps [rsp+0x60], xmm6
000079bd661ddf3f  vmovaps [rsp+0x70], xmm8
000079bd661ddf45  vmovaps [rsp+0x80], xmm9
000079bd661ddf4e  vmovaps [rsp+0x90], xmm10
000079bd661ddf57  vmovaps [rsp+0xA0], xmm11
000079bd661ddf60  vmovaps [rsp+0xB0], xmm12
000079bd661ddf69  vmovaps [rsp+0xC0], xmm13
000079bd661ddf72  vmovaps [rsp+0xD0], xmm14
000079bd661ddf7b  vmovaps [rsp+0xE0], xmm15
000079bd661ddf84  sub rsp, 0x30
000079bd661ddf88  movaps [rsp], xmm7
000079bd661ddf8c  movaps [rsp+0x10], xmm5
000079bd661ddf91  movaps [rsp+0x20], xmm15
000079bd661ddf97  lea rdi, [rsp]
000079bd661ddf9b  mov esi, 0x00
000079bd661ddfa0  mov rax, 0x56EBD57B0530
000079bd661ddfaa  call rax
000079bd661ddfac  movaps xmm7, [rsp]
000079bd661ddfb0  add rsp, 0x30
000079bd661ddfb4  vmovaps xmm0, [rsp]
000079bd661ddfb9  vmovaps xmm1, [rsp+0x10]
000079bd661ddfbf  vmovaps xmm2, [rsp+0x20]
000079bd661ddfc5  vmovaps xmm3, [rsp+0x30]
000079bd661ddfcb  vmovaps xmm4, [rsp+0x40]
000079bd661ddfd1  vmovaps xmm5, [rsp+0x50]
000079bd661ddfd7  vmovaps xmm6, [rsp+0x60]
000079bd661ddfdd  vmovaps xmm8, [rsp+0x70]
000079bd661ddfe3  vmovaps xmm9, [rsp+0x80]
000079bd661ddfec  vmovaps xmm10, [rsp+0x90]
000079bd661ddff5  vmovaps xmm11, [rsp+0xA0]
000079bd661ddffe  vmovaps xmm12, [rsp+0xB0]
000079bd661de007  vmovaps xmm13, [rsp+0xC0]
000079bd661de010  vmovaps xmm14, [rsp+0xD0]
000079bd661de019  vmovaps xmm15, [rsp+0xE0]
000079bd661de022  add rsp, 0xF0
000079bd661de029  pop r11
000079bd661de02b  pop r10
000079bd661de02d  pop r9
000079bd661de02f  pop r8
000079bd661de031  pop rsi
000079bd661de032  pop rdi
000079bd661de033  pop rdx
000079bd661de034  pop rcx
000079bd661de035  pop rax
000079bd661de036  add rsp, 0x08
000079bd661de03a  jmp 0x000079BD661DC066
000079bd661de03f  call 0x000079BD660B52F0
000079bd661de044  jmp 0x000079BD661DC073
000079bd661de049  sub rsp, 0x08
000079bd661de04d  push rax
000079bd661de04e  push rcx
000079bd661de04f  push rdx
000079bd661de050  push rdi
000079bd661de051  push rsi
000079bd661de052  push r8
000079bd661de054  push r9
000079bd661de056  push r10
000079bd661de058  push r11
000079bd661de05a  sub rsp, 0xF0
000079bd661de061  vmovaps [rsp], xmm0
000079bd661de066  vmovaps [rsp+0x10], xmm1
000079bd661de06c  vmovaps [rsp+0x20], xmm2
000079bd661de072  vmovaps [rsp+0x30], xmm3
000079bd661de078  vmovaps [rsp+0x40], xmm4
000079bd661de07e  vmovaps [rsp+0x50], xmm5
000079bd661de084  vmovaps [rsp+0x60], xmm6
000079bd661de08a  vmovaps [rsp+0x70], xmm7
000079bd661de090  vmovaps [rsp+0x80], xmm8
000079bd661de099  vmovaps [rsp+0x90], xmm9
000079bd661de0a2  vmovaps [rsp+0xA0], xmm10
000079bd661de0ab  vmovaps [rsp+0xB0], xmm11
000079bd661de0b4  vmovaps [rsp+0xC0], xmm12
000079bd661de0bd  vmovaps [rsp+0xD0], xmm13
000079bd661de0c6  vmovaps [rsp+0xE0], xmm14
000079bd661de0cf  sub rsp, 0x30
000079bd661de0d3  movaps [rsp], xmm15
000079bd661de0d8  movaps [rsp+0x10], xmm5
000079bd661de0dd  movaps [rsp+0x20], xmm3
000079bd661de0e2  lea rdi, [rsp]
000079bd661de0e6  mov esi, 0x00
000079bd661de0eb  mov rax, 0x56EBD57B0530
000079bd661de0f5  call rax
000079bd661de0f7  movaps xmm15, [rsp]
000079bd661de0fc  add rsp, 0x30
000079bd661de100  vmovaps xmm0, [rsp]
000079bd661de105  vmovaps xmm1, [rsp+0x10]
000079bd661de10b  vmovaps xmm2, [rsp+0x20]
000079bd661de111  vmovaps xmm3, [rsp+0x30]
000079bd661de117  vmovaps xmm4, [rsp+0x40]
000079bd661de11d  vmovaps xmm5, [rsp+0x50]
000079bd661de123  vmovaps xmm6, [rsp+0x60]
000079bd661de129  vmovaps xmm7, [rsp+0x70]
000079bd661de12f  vmovaps xmm8, [rsp+0x80]
000079bd661de138  vmovaps xmm9, [rsp+0x90]
000079bd661de141  vmovaps xmm10, [rsp+0xA0]
000079bd661de14a  vmovaps xmm11, [rsp+0xB0]
000079bd661de153  vmovaps xmm12, [rsp+0xC0]
000079bd661de15c  vmovaps xmm13, [rsp+0xD0]
000079bd661de165  vmovaps xmm14, [rsp+0xE0]
000079bd661de16e  add rsp, 0xF0
000079bd661de175  pop r11
000079bd661de177  pop r10
000079bd661de179  pop r9
000079bd661de17b  pop r8
000079bd661de17d  pop rsi
000079bd661de17e  pop rdi
000079bd661de17f  pop rdx
000079bd661de180  pop rcx
000079bd661de181  pop rax
000079bd661de182  add rsp, 0x08
000079bd661de186  jmp 0x000079BD661DC099
000079bd661de18b  sub rsp, 0x08
000079bd661de18f  push rax
000079bd661de190  push rcx
000079bd661de191  push rdx
000079bd661de192  push rdi
000079bd661de193  push rsi
000079bd661de194  push r8
000079bd661de196  push r9
000079bd661de198  push r10
000079bd661de19a  push r11
000079bd661de19c  sub rsp, 0xF0
000079bd661de1a3  vmovaps [rsp], xmm0
000079bd661de1a8  vmovaps [rsp+0x10], xmm2
000079bd661de1ae  vmovaps [rsp+0x20], xmm3
000079bd661de1b4  vmovaps [rsp+0x30], xmm4
000079bd661de1ba  vmovaps [rsp+0x40], xmm5
000079bd661de1c0  vmovaps [rsp+0x50], xmm6
000079bd661de1c6  vmovaps [rsp+0x60], xmm7
000079bd661de1cc  vmovaps [rsp+0x70], xmm8
000079bd661de1d2  vmovaps [rsp+0x80], xmm9
000079bd661de1db  vmovaps [rsp+0x90], xmm10
000079bd661de1e4  vmovaps [rsp+0xA0], xmm11
000079bd661de1ed  vmovaps [rsp+0xB0], xmm12
000079bd661de1f6  vmovaps [rsp+0xC0], xmm13
000079bd661de1ff  vmovaps [rsp+0xD0], xmm14
000079bd661de208  vmovaps [rsp+0xE0], xmm15
000079bd661de211  sub rsp, 0x30
000079bd661de215  movaps [rsp], xmm1
000079bd661de219  movaps [rsp+0x10], xmm5
000079bd661de21e  movaps [rsp+0x20], xmm4
000079bd661de223  lea rdi, [rsp]
000079bd661de227  mov esi, 0x00
000079bd661de22c  mov rax, 0x56EBD57B0530
000079bd661de236  call rax
000079bd661de238  movaps xmm1, [rsp]
000079bd661de23c  add rsp, 0x30
000079bd661de240  vmovaps xmm0, [rsp]
000079bd661de245  vmovaps xmm2, [rsp+0x10]
000079bd661de24b  vmovaps xmm3, [rsp+0x20]
000079bd661de251  vmovaps xmm4, [rsp+0x30]
000079bd661de257  vmovaps xmm5, [rsp+0x40]
000079bd661de25d  vmovaps xmm6, [rsp+0x50]
000079bd661de263  vmovaps xmm7, [rsp+0x60]
000079bd661de269  vmovaps xmm8, [rsp+0x70]
000079bd661de26f  vmovaps xmm9, [rsp+0x80]
000079bd661de278  vmovaps xmm10, [rsp+0x90]
000079bd661de281  vmovaps xmm11, [rsp+0xA0]
000079bd661de28a  vmovaps xmm12, [rsp+0xB0]
000079bd661de293  vmovaps xmm13, [rsp+0xC0]
000079bd661de29c  vmovaps xmm14, [rsp+0xD0]
000079bd661de2a5  vmovaps xmm15, [rsp+0xE0]
000079bd661de2ae  add rsp, 0xF0
000079bd661de2b5  pop r11
000079bd661de2b7  pop r10
000079bd661de2b9  pop r9
000079bd661de2bb  pop r8
000079bd661de2bd  pop rsi
000079bd661de2be  pop rdi
000079bd661de2bf  pop rdx
000079bd661de2c0  pop rcx
000079bd661de2c1  pop rax
000079bd661de2c2  add rsp, 0x08
000079bd661de2c6  jmp 0x000079BD661DC0B9
000079bd661de2cb  sub rsp, 0x08
000079bd661de2cf  push rax
000079bd661de2d0  push rcx
000079bd661de2d1  push rdx
000079bd661de2d2  push rdi
000079bd661de2d3  push rsi
000079bd661de2d4  push r8
000079bd661de2d6  push r9
000079bd661de2d8  push r10
000079bd661de2da  push r11
000079bd661de2dc  sub rsp, 0xF0
000079bd661de2e3  vmovaps [rsp], xmm0
000079bd661de2e8  vmovaps [rsp+0x10], xmm1
000079bd661de2ee  vmovaps [rsp+0x20], xmm2
000079bd661de2f4  vmovaps [rsp+0x30], xmm3
000079bd661de2fa  vmovaps [rsp+0x40], xmm5
000079bd661de300  vmovaps [rsp+0x50], xmm6
000079bd661de306  vmovaps [rsp+0x60], xmm7
000079bd661de30c  vmovaps [rsp+0x70], xmm8
000079bd661de312  vmovaps [rsp+0x80], xmm9
000079bd661de31b  vmovaps [rsp+0x90], xmm10
000079bd661de324  vmovaps [rsp+0xA0], xmm11
000079bd661de32d  vmovaps [rsp+0xB0], xmm12
000079bd661de336  vmovaps [rsp+0xC0], xmm13
000079bd661de33f  vmovaps [rsp+0xD0], xmm14
000079bd661de348  vmovaps [rsp+0xE0], xmm15
000079bd661de351  sub rsp, 0x30
000079bd661de355  movaps [rsp], xmm4
000079bd661de359  movaps [rsp+0x10], xmm3
000079bd661de35e  movaps [rsp+0x20], xmm5
000079bd661de363  lea rdi, [rsp]
000079bd661de367  mov esi, 0x00
000079bd661de36c  mov rax, 0x56EBD57B0530
000079bd661de376  call rax
000079bd661de378  movaps xmm4, [rsp]
000079bd661de37c  add rsp, 0x30
000079bd661de380  vmovaps xmm0, [rsp]
000079bd661de385  vmovaps xmm1, [rsp+0x10]
000079bd661de38b  vmovaps xmm2, [rsp+0x20]
000079bd661de391  vmovaps xmm3, [rsp+0x30]
000079bd661de397  vmovaps xmm5, [rsp+0x40]
000079bd661de39d  vmovaps xmm6, [rsp+0x50]
000079bd661de3a3  vmovaps xmm7, [rsp+0x60]
000079bd661de3a9  vmovaps xmm8, [rsp+0x70]
000079bd661de3af  vmovaps xmm9, [rsp+0x80]
000079bd661de3b8  vmovaps xmm10, [rsp+0x90]
000079bd661de3c1  vmovaps xmm11, [rsp+0xA0]
000079bd661de3ca  vmovaps xmm12, [rsp+0xB0]
000079bd661de3d3  vmovaps xmm13, [rsp+0xC0]
000079bd661de3dc  vmovaps xmm14, [rsp+0xD0]
000079bd661de3e5  vmovaps xmm15, [rsp+0xE0]
000079bd661de3ee  add rsp, 0xF0
000079bd661de3f5  pop r11
000079bd661de3f7  pop r10
000079bd661de3f9  pop r9
000079bd661de3fb  pop r8
000079bd661de3fd  pop rsi
000079bd661de3fe  pop rdi
000079bd661de3ff  pop rdx
000079bd661de400  pop rcx
000079bd661de401  pop rax
000079bd661de402  add rsp, 0x08
000079bd661de406  jmp 0x000079BD661DC107
000079bd661de40b  call 0x000079BD660B52F0
000079bd661de410  jmp 0x000079BD661DC114
000079bd661de415  sub rsp, 0x08
000079bd661de419  push rax
000079bd661de41a  push rcx
000079bd661de41b  push rdx
000079bd661de41c  push rdi
000079bd661de41d  push rsi
000079bd661de41e  push r8
000079bd661de420  push r9
000079bd661de422  push r10
000079bd661de424  push r11
000079bd661de426  sub rsp, 0xF0
000079bd661de42d  vmovaps [rsp], xmm0
000079bd661de432  vmovaps [rsp+0x10], xmm1
000079bd661de438  vmovaps [rsp+0x20], xmm2
000079bd661de43e  vmovaps [rsp+0x30], xmm3
000079bd661de444  vmovaps [rsp+0x40], xmm4
000079bd661de44a  vmovaps [rsp+0x50], xmm6
000079bd661de450  vmovaps [rsp+0x60], xmm7
000079bd661de456  vmovaps [rsp+0x70], xmm8
000079bd661de45c  vmovaps [rsp+0x80], xmm9
000079bd661de465  vmovaps [rsp+0x90], xmm10
000079bd661de46e  vmovaps [rsp+0xA0], xmm11
000079bd661de477  vmovaps [rsp+0xB0], xmm12
000079bd661de480  vmovaps [rsp+0xC0], xmm13
000079bd661de489  vmovaps [rsp+0xD0], xmm14
000079bd661de492  vmovaps [rsp+0xE0], xmm15
000079bd661de49b  sub rsp, 0x30
000079bd661de49f  movaps [rsp], xmm5
000079bd661de4a3  movaps [rsp+0x10], xmm6
000079bd661de4a8  movaps [rsp+0x20], xmm3
000079bd661de4ad  lea rdi, [rsp]
000079bd661de4b1  mov esi, 0x00
000079bd661de4b6  mov rax, 0x56EBD57B0530
000079bd661de4c0  call rax
000079bd661de4c2  movaps xmm5, [rsp]
000079bd661de4c6  add rsp, 0x30
000079bd661de4ca  vmovaps xmm0, [rsp]
000079bd661de4cf  vmovaps xmm1, [rsp+0x10]
000079bd661de4d5  vmovaps xmm2, [rsp+0x20]
000079bd661de4db  vmovaps xmm3, [rsp+0x30]
000079bd661de4e1  vmovaps xmm4, [rsp+0x40]
000079bd661de4e7  vmovaps xmm6, [rsp+0x50]
000079bd661de4ed  vmovaps xmm7, [rsp+0x60]
000079bd661de4f3  vmovaps xmm8, [rsp+0x70]
000079bd661de4f9  vmovaps xmm9, [rsp+0x80]
000079bd661de502  vmovaps xmm10, [rsp+0x90]
000079bd661de50b  vmovaps xmm11, [rsp+0xA0]
000079bd661de514  vmovaps xmm12, [rsp+0xB0]
000079bd661de51d  vmovaps xmm13, [rsp+0xC0]
000079bd661de526  vmovaps xmm14, [rsp+0xD0]
000079bd661de52f  vmovaps xmm15, [rsp+0xE0]
000079bd661de538  add rsp, 0xF0
000079bd661de53f  pop r11
000079bd661de541  pop r10
000079bd661de543  pop r9
000079bd661de545  pop r8
000079bd661de547  pop rsi
000079bd661de548  pop rdi
000079bd661de549  pop rdx
000079bd661de54a  pop rcx
000079bd661de54b  pop rax
000079bd661de54c  add rsp, 0x08
000079bd661de550  jmp 0x000079BD661DC13A
000079bd661de555  sub rsp, 0x08
000079bd661de559  push rax
000079bd661de55a  push rcx
000079bd661de55b  push rdx
000079bd661de55c  push rdi
000079bd661de55d  push rsi
000079bd661de55e  push r8
000079bd661de560  push r9
000079bd661de562  push r10
000079bd661de564  push r11
000079bd661de566  sub rsp, 0xF0
000079bd661de56d  vmovaps [rsp], xmm0
000079bd661de572  vmovaps [rsp+0x10], xmm1
000079bd661de578  vmovaps [rsp+0x20], xmm2
000079bd661de57e  vmovaps [rsp+0x30], xmm3
000079bd661de584  vmovaps [rsp+0x40], xmm4
000079bd661de58a  vmovaps [rsp+0x50], xmm5
000079bd661de590  vmovaps [rsp+0x60], xmm7
000079bd661de596  vmovaps [rsp+0x70], xmm8
000079bd661de59c  vmovaps [rsp+0x80], xmm9
000079bd661de5a5  vmovaps [rsp+0x90], xmm10
000079bd661de5ae  vmovaps [rsp+0xA0], xmm11
000079bd661de5b7  vmovaps [rsp+0xB0], xmm12
000079bd661de5c0  vmovaps [rsp+0xC0], xmm13
000079bd661de5c9  vmovaps [rsp+0xD0], xmm14
000079bd661de5d2  vmovaps [rsp+0xE0], xmm15
000079bd661de5db  sub rsp, 0x30
000079bd661de5df  movaps [rsp], xmm6
000079bd661de5e3  movaps [rsp+0x10], xmm9
000079bd661de5e9  movaps [rsp+0x20], xmm1
000079bd661de5ee  lea rdi, [rsp]
000079bd661de5f2  mov esi, 0x00
000079bd661de5f7  mov rax, 0x56EBD57B0530
000079bd661de601  call rax
000079bd661de603  movaps xmm6, [rsp]
000079bd661de607  add rsp, 0x30
000079bd661de60b  vmovaps xmm0, [rsp]
000079bd661de610  vmovaps xmm1, [rsp+0x10]
000079bd661de616  vmovaps xmm2, [rsp+0x20]
000079bd661de61c  vmovaps xmm3, [rsp+0x30]
000079bd661de622  vmovaps xmm4, [rsp+0x40]
000079bd661de628  vmovaps xmm5, [rsp+0x50]
000079bd661de62e  vmovaps xmm7, [rsp+0x60]
000079bd661de634  vmovaps xmm8, [rsp+0x70]
000079bd661de63a  vmovaps xmm9, [rsp+0x80]
000079bd661de643  vmovaps xmm10, [rsp+0x90]
000079bd661de64c  vmovaps xmm11, [rsp+0xA0]
000079bd661de655  vmovaps xmm12, [rsp+0xB0]
000079bd661de65e  vmovaps xmm13, [rsp+0xC0]
000079bd661de667  vmovaps xmm14, [rsp+0xD0]
000079bd661de670  vmovaps xmm15, [rsp+0xE0]
000079bd661de679  add rsp, 0xF0
000079bd661de680  pop r11
000079bd661de682  pop r10
000079bd661de684  pop r9
000079bd661de686  pop r8
000079bd661de688  pop rsi
000079bd661de689  pop rdi
000079bd661de68a  pop rdx
000079bd661de68b  pop rcx
000079bd661de68c  pop rax
000079bd661de68d  add rsp, 0x08
000079bd661de691  jmp 0x000079BD661DC15E
000079bd661de696  sub rsp, 0x08
000079bd661de69a  push rax
000079bd661de69b  push rcx
000079bd661de69c  push rdx
000079bd661de69d  push rdi
000079bd661de69e  push rsi
000079bd661de69f  push r8
000079bd661de6a1  push r9
000079bd661de6a3  push r10
000079bd661de6a5  push r11
000079bd661de6a7  sub rsp, 0xF0
000079bd661de6ae  vmovaps [rsp], xmm0
000079bd661de6b3  vmovaps [rsp+0x10], xmm1
000079bd661de6b9  vmovaps [rsp+0x20], xmm2
000079bd661de6bf  vmovaps [rsp+0x30], xmm3
000079bd661de6c5  vmovaps [rsp+0x40], xmm4
000079bd661de6cb  vmovaps [rsp+0x50], xmm5
000079bd661de6d1  vmovaps [rsp+0x60], xmm6
000079bd661de6d7  vmovaps [rsp+0x70], xmm7
000079bd661de6dd  vmovaps [rsp+0x80], xmm8
000079bd661de6e6  vmovaps [rsp+0x90], xmm10
000079bd661de6ef  vmovaps [rsp+0xA0], xmm11
000079bd661de6f8  vmovaps [rsp+0xB0], xmm12
000079bd661de701  vmovaps [rsp+0xC0], xmm13
000079bd661de70a  vmovaps [rsp+0xD0], xmm14
000079bd661de713  vmovaps [rsp+0xE0], xmm15
000079bd661de71c  sub rsp, 0x30
000079bd661de720  movaps [rsp], xmm9
000079bd661de725  movaps [rsp+0x10], xmm3
000079bd661de72a  movaps [rsp+0x20], xmm1
000079bd661de72f  lea rdi, [rsp]
000079bd661de733  mov esi, 0x00
000079bd661de738  mov rax, 0x56EBD57B0530
000079bd661de742  call rax
000079bd661de744  movaps xmm9, [rsp]
000079bd661de749  add rsp, 0x30
000079bd661de74d  vmovaps xmm0, [rsp]
000079bd661de752  vmovaps xmm1, [rsp+0x10]
000079bd661de758  vmovaps xmm2, [rsp+0x20]
000079bd661de75e  vmovaps xmm3, [rsp+0x30]
000079bd661de764  vmovaps xmm4, [rsp+0x40]
000079bd661de76a  vmovaps xmm5, [rsp+0x50]
000079bd661de770  vmovaps xmm6, [rsp+0x60]
000079bd661de776  vmovaps xmm7, [rsp+0x70]
000079bd661de77c  vmovaps xmm8, [rsp+0x80]
000079bd661de785  vmovaps xmm10, [rsp+0x90]
000079bd661de78e  vmovaps xmm11, [rsp+0xA0]
000079bd661de797  vmovaps xmm12, [rsp+0xB0]
000079bd661de7a0  vmovaps xmm13, [rsp+0xC0]
000079bd661de7a9  vmovaps xmm14, [rsp+0xD0]
000079bd661de7b2  vmovaps xmm15, [rsp+0xE0]
000079bd661de7bb  add rsp, 0xF0
000079bd661de7c2  pop r11
000079bd661de7c4  pop r10
000079bd661de7c6  pop r9
000079bd661de7c8  pop r8
000079bd661de7ca  pop rsi
000079bd661de7cb  pop rdi
000079bd661de7cc  pop rdx
000079bd661de7cd  pop rcx
000079bd661de7ce  pop rax
000079bd661de7cf  add rsp, 0x08
000079bd661de7d3  jmp 0x000079BD661DC1AA
000079bd661de7d8  call 0x000079BD660B52F0
000079bd661de7dd  jmp 0x000079BD661DC1B7
000079bd661de7e2  sub rsp, 0x08
000079bd661de7e6  push rax
000079bd661de7e7  push rcx
000079bd661de7e8  push rdx
000079bd661de7e9  push rdi
000079bd661de7ea  push rsi
000079bd661de7eb  push r8
000079bd661de7ed  push r9
000079bd661de7ef  push r10
000079bd661de7f1  push r11
000079bd661de7f3  sub rsp, 0xF0
000079bd661de7fa  vmovaps [rsp], xmm0
000079bd661de7ff  vmovaps [rsp+0x10], xmm1
000079bd661de805  vmovaps [rsp+0x20], xmm2
000079bd661de80b  vmovaps [rsp+0x30], xmm3
000079bd661de811  vmovaps [rsp+0x40], xmm4
000079bd661de817  vmovaps [rsp+0x50], xmm5
000079bd661de81d  vmovaps [rsp+0x60], xmm6
000079bd661de823  vmovaps [rsp+0x70], xmm7
000079bd661de829  vmovaps [rsp+0x80], xmm8
000079bd661de832  vmovaps [rsp+0x90], xmm9
000079bd661de83b  vmovaps [rsp+0xA0], xmm10
000079bd661de844  vmovaps [rsp+0xB0], xmm11
000079bd661de84d  vmovaps [rsp+0xC0], xmm12
000079bd661de856  vmovaps [rsp+0xD0], xmm13
000079bd661de85f  vmovaps [rsp+0xE0], xmm14
000079bd661de868  sub rsp, 0x30
000079bd661de86c  movaps [rsp], xmm15
000079bd661de871  movaps [rsp+0x10], xmm3
000079bd661de876  movaps [rsp+0x20], xmm7
000079bd661de87b  lea rdi, [rsp]
000079bd661de87f  mov esi, 0x00
000079bd661de884  mov rax, 0x56EBD57B0530
000079bd661de88e  call rax
000079bd661de890  movaps xmm15, [rsp]
000079bd661de895  add rsp, 0x30
000079bd661de899  vmovaps xmm0, [rsp]
000079bd661de89e  vmovaps xmm1, [rsp+0x10]
000079bd661de8a4  vmovaps xmm2, [rsp+0x20]
000079bd661de8aa  vmovaps xmm3, [rsp+0x30]
000079bd661de8b0  vmovaps xmm4, [rsp+0x40]
000079bd661de8b6  vmovaps xmm5, [rsp+0x50]
000079bd661de8bc  vmovaps xmm6, [rsp+0x60]
000079bd661de8c2  vmovaps xmm7, [rsp+0x70]
000079bd661de8c8  vmovaps xmm8, [rsp+0x80]
000079bd661de8d1  vmovaps xmm9, [rsp+0x90]
000079bd661de8da  vmovaps xmm10, [rsp+0xA0]
000079bd661de8e3  vmovaps xmm11, [rsp+0xB0]
000079bd661de8ec  vmovaps xmm12, [rsp+0xC0]
000079bd661de8f5  vmovaps xmm13, [rsp+0xD0]
000079bd661de8fe  vmovaps xmm14, [rsp+0xE0]
000079bd661de907  add rsp, 0xF0
000079bd661de90e  pop r11
000079bd661de910  pop r10
000079bd661de912  pop r9
000079bd661de914  pop r8
000079bd661de916  pop rsi
000079bd661de917  pop rdi
000079bd661de918  pop rdx
000079bd661de919  pop rcx
000079bd661de91a  pop rax
000079bd661de91b  add rsp, 0x08
000079bd661de91f  jmp 0x000079BD661DC1E3
000079bd661de924  sub rsp, 0x08
000079bd661de928  push rax
000079bd661de929  push rcx
000079bd661de92a  push rdx
000079bd661de92b  push rdi
000079bd661de92c  push rsi
000079bd661de92d  push r8
000079bd661de92f  push r9
000079bd661de931  push r10
000079bd661de933  push r11
000079bd661de935  sub rsp, 0xF0
000079bd661de93c  vmovaps [rsp], xmm0
000079bd661de941  vmovaps [rsp+0x10], xmm1
000079bd661de947  vmovaps [rsp+0x20], xmm2
000079bd661de94d  vmovaps [rsp+0x30], xmm4
000079bd661de953  vmovaps [rsp+0x40], xmm5
000079bd661de959  vmovaps [rsp+0x50], xmm6
000079bd661de95f  vmovaps [rsp+0x60], xmm7
000079bd661de965  vmovaps [rsp+0x70], xmm8
000079bd661de96b  vmovaps [rsp+0x80], xmm9
000079bd661de974  vmovaps [rsp+0x90], xmm10
000079bd661de97d  vmovaps [rsp+0xA0], xmm11
000079bd661de986  vmovaps [rsp+0xB0], xmm12
000079bd661de98f  vmovaps [rsp+0xC0], xmm13
000079bd661de998  vmovaps [rsp+0xD0], xmm14
000079bd661de9a1  vmovaps [rsp+0xE0], xmm15
000079bd661de9aa  sub rsp, 0x30
000079bd661de9ae  movaps [rsp], xmm3
000079bd661de9b2  movaps [rsp+0x10], xmm1
000079bd661de9b7  movaps [rsp+0x20], xmm15
000079bd661de9bd  lea rdi, [rsp]
000079bd661de9c1  mov esi, 0x00
000079bd661de9c6  mov rax, 0x56EBD57B0530
000079bd661de9d0  call rax
000079bd661de9d2  movaps xmm3, [rsp]
000079bd661de9d6  add rsp, 0x30
000079bd661de9da  vmovaps xmm0, [rsp]
000079bd661de9df  vmovaps xmm1, [rsp+0x10]
000079bd661de9e5  vmovaps xmm2, [rsp+0x20]
000079bd661de9eb  vmovaps xmm4, [rsp+0x30]
000079bd661de9f1  vmovaps xmm5, [rsp+0x40]
000079bd661de9f7  vmovaps xmm6, [rsp+0x50]
000079bd661de9fd  vmovaps xmm7, [rsp+0x60]
000079bd661dea03  vmovaps xmm8, [rsp+0x70]
000079bd661dea09  vmovaps xmm9, [rsp+0x80]
000079bd661dea12  vmovaps xmm10, [rsp+0x90]
000079bd661dea1b  vmovaps xmm11, [rsp+0xA0]
000079bd661dea24  vmovaps xmm12, [rsp+0xB0]
000079bd661dea2d  vmovaps xmm13, [rsp+0xC0]
000079bd661dea36  vmovaps xmm14, [rsp+0xD0]
000079bd661dea3f  vmovaps xmm15, [rsp+0xE0]
000079bd661dea48  add rsp, 0xF0
000079bd661dea4f  pop r11
000079bd661dea51  pop r10
000079bd661dea53  pop r9
000079bd661dea55  pop r8
000079bd661dea57  pop rsi
000079bd661dea58  pop rdi
000079bd661dea59  pop rdx
000079bd661dea5a  pop rcx
000079bd661dea5b  pop rax
000079bd661dea5c  add rsp, 0x08
000079bd661dea60  jmp 0x000079BD661DC272
000079bd661dea65  call 0x000079BD660B52F0
000079bd661dea6a  jmp 0x000079BD661DC27C
000079bd661dea6f  sub rsp, 0x08
000079bd661dea73  push rax
000079bd661dea74  push rcx
000079bd661dea75  push rdx
000079bd661dea76  push rdi
000079bd661dea77  push rsi
000079bd661dea78  push r8
000079bd661dea7a  push r9
000079bd661dea7c  push r10
000079bd661dea7e  push r11
000079bd661dea80  sub rsp, 0xF0
000079bd661dea87  vmovaps [rsp], xmm0
000079bd661dea8c  vmovaps [rsp+0x10], xmm1
000079bd661dea92  vmovaps [rsp+0x20], xmm2
000079bd661dea98  vmovaps [rsp+0x30], xmm3
000079bd661dea9e  vmovaps [rsp+0x40], xmm4
000079bd661deaa4  vmovaps [rsp+0x50], xmm5
000079bd661deaaa  vmovaps [rsp+0x60], xmm6
000079bd661deab0  vmovaps [rsp+0x70], xmm7
000079bd661deab6  vmovaps [rsp+0x80], xmm8
000079bd661deabf  vmovaps [rsp+0x90], xmm9
000079bd661deac8  vmovaps [rsp+0xA0], xmm10
000079bd661dead1  vmovaps [rsp+0xB0], xmm11
000079bd661deada  vmovaps [rsp+0xC0], xmm12
000079bd661deae3  vmovaps [rsp+0xD0], xmm13
000079bd661deaec  vmovaps [rsp+0xE0], xmm14
000079bd661deaf5  sub rsp, 0x30
000079bd661deaf9  movaps [rsp], xmm15
000079bd661deafe  movaps [rsp+0x10], xmm14
000079bd661deb04  movaps [rsp+0x20], xmm4
000079bd661deb09  lea rdi, [rsp]
000079bd661deb0d  mov esi, 0x00
000079bd661deb12  mov rax, 0x56EBD57B0530
000079bd661deb1c  call rax
000079bd661deb1e  movaps xmm15, [rsp]
000079bd661deb23  add rsp, 0x30
000079bd661deb27  vmovaps xmm0, [rsp]
000079bd661deb2c  vmovaps xmm1, [rsp+0x10]
000079bd661deb32  vmovaps xmm2, [rsp+0x20]
000079bd661deb38  vmovaps xmm3, [rsp+0x30]
000079bd661deb3e  vmovaps xmm4, [rsp+0x40]
000079bd661deb44  vmovaps xmm5, [rsp+0x50]
000079bd661deb4a  vmovaps xmm6, [rsp+0x60]
000079bd661deb50  vmovaps xmm7, [rsp+0x70]
000079bd661deb56  vmovaps xmm8, [rsp+0x80]
000079bd661deb5f  vmovaps xmm9, [rsp+0x90]
000079bd661deb68  vmovaps xmm10, [rsp+0xA0]
000079bd661deb71  vmovaps xmm11, [rsp+0xB0]
000079bd661deb7a  vmovaps xmm12, [rsp+0xC0]
000079bd661deb83  vmovaps xmm13, [rsp+0xD0]
000079bd661deb8c  vmovaps xmm14, [rsp+0xE0]
000079bd661deb95  add rsp, 0xF0
000079bd661deb9c  pop r11
000079bd661deb9e  pop r10
000079bd661deba0  pop r9
000079bd661deba2  pop r8
000079bd661deba4  pop rsi
000079bd661deba5  pop rdi
000079bd661deba6  pop rdx
000079bd661deba7  pop rcx
000079bd661deba8  pop rax
000079bd661deba9  add rsp, 0x08
000079bd661debad  jmp 0x000079BD661DC2AA
000079bd661debb2  sub rsp, 0x08
000079bd661debb6  push rax
000079bd661debb7  push rcx
000079bd661debb8  push rdx
000079bd661debb9  push rdi
000079bd661debba  push rsi
000079bd661debbb  push r8
000079bd661debbd  push r9
000079bd661debbf  push r10
000079bd661debc1  push r11
000079bd661debc3  sub rsp, 0xF0
000079bd661debca  vmovaps [rsp], xmm0
000079bd661debcf  vmovaps [rsp+0x10], xmm1
000079bd661debd5  vmovaps [rsp+0x20], xmm2
000079bd661debdb  vmovaps [rsp+0x30], xmm3
000079bd661debe1  vmovaps [rsp+0x40], xmm4
000079bd661debe7  vmovaps [rsp+0x50], xmm5
000079bd661debed  vmovaps [rsp+0x60], xmm6
000079bd661debf3  vmovaps [rsp+0x70], xmm7
000079bd661debf9  vmovaps [rsp+0x80], xmm8
000079bd661dec02  vmovaps [rsp+0x90], xmm9
000079bd661dec0b  vmovaps [rsp+0xA0], xmm10
000079bd661dec14  vmovaps [rsp+0xB0], xmm11
000079bd661dec1d  vmovaps [rsp+0xC0], xmm12
000079bd661dec26  vmovaps [rsp+0xD0], xmm13
000079bd661dec2f  vmovaps [rsp+0xE0], xmm15
000079bd661dec38  sub rsp, 0x30
000079bd661dec3c  movaps [rsp], xmm14
000079bd661dec41  movaps [rsp+0x10], xmm2
000079bd661dec46  movaps [rsp+0x20], xmm1
000079bd661dec4b  lea rdi, [rsp]
000079bd661dec4f  mov esi, 0x00
000079bd661dec54  mov rax, 0x56EBD57B0530
000079bd661dec5e  call rax
000079bd661dec60  movaps xmm14, [rsp]
000079bd661dec65  add rsp, 0x30
000079bd661dec69  vmovaps xmm0, [rsp]
000079bd661dec6e  vmovaps xmm1, [rsp+0x10]
000079bd661dec74  vmovaps xmm2, [rsp+0x20]
000079bd661dec7a  vmovaps xmm3, [rsp+0x30]
000079bd661dec80  vmovaps xmm4, [rsp+0x40]
000079bd661dec86  vmovaps xmm5, [rsp+0x50]
000079bd661dec8c  vmovaps xmm6, [rsp+0x60]
000079bd661dec92  vmovaps xmm7, [rsp+0x70]
000079bd661dec98  vmovaps xmm8, [rsp+0x80]
000079bd661deca1  vmovaps xmm9, [rsp+0x90]
000079bd661decaa  vmovaps xmm10, [rsp+0xA0]
000079bd661decb3  vmovaps xmm11, [rsp+0xB0]
000079bd661decbc  vmovaps xmm12, [rsp+0xC0]
000079bd661decc5  vmovaps xmm13, [rsp+0xD0]
000079bd661decce  vmovaps xmm15, [rsp+0xE0]
000079bd661decd7  add rsp, 0xF0
000079bd661decde  pop r11
000079bd661dece0  pop r10
000079bd661dece2  pop r9
000079bd661dece4  pop r8
000079bd661dece6  pop rsi
000079bd661dece7  pop rdi
000079bd661dece8  pop rdx
000079bd661dece9  pop rcx
000079bd661decea  pop rax
000079bd661deceb  add rsp, 0x08
000079bd661decef  jmp 0x000079BD661DC2D0
000079bd661decf4  sub rsp, 0x08
000079bd661decf8  push rax
000079bd661decf9  push rcx
000079bd661decfa  push rdx
000079bd661decfb  push rdi
000079bd661decfc  push rsi
000079bd661decfd  push r8
000079bd661decff  push r9
000079bd661ded01  push r10
000079bd661ded03  push r11
000079bd661ded05  sub rsp, 0xF0
000079bd661ded0c  vmovaps [rsp], xmm0
000079bd661ded11  vmovaps [rsp+0x10], xmm2
000079bd661ded17  vmovaps [rsp+0x20], xmm3
000079bd661ded1d  vmovaps [rsp+0x30], xmm4
000079bd661ded23  vmovaps [rsp+0x40], xmm5
000079bd661ded29  vmovaps [rsp+0x50], xmm6
000079bd661ded2f  vmovaps [rsp+0x60], xmm7
000079bd661ded35  vmovaps [rsp+0x70], xmm8
000079bd661ded3b  vmovaps [rsp+0x80], xmm9
000079bd661ded44  vmovaps [rsp+0x90], xmm10
000079bd661ded4d  vmovaps [rsp+0xA0], xmm11
000079bd661ded56  vmovaps [rsp+0xB0], xmm12
000079bd661ded5f  vmovaps [rsp+0xC0], xmm13
000079bd661ded68  vmovaps [rsp+0xD0], xmm14
000079bd661ded71  vmovaps [rsp+0xE0], xmm15
000079bd661ded7a  sub rsp, 0x30
000079bd661ded7e  movaps [rsp], xmm1
000079bd661ded82  movaps [rsp+0x10], xmm4
000079bd661ded87  movaps [rsp+0x20], xmm9
000079bd661ded8d  lea rdi, [rsp]
000079bd661ded91  mov esi, 0x00
000079bd661ded96  mov rax, 0x56EBD57B0530
000079bd661deda0  call rax
000079bd661deda2  movaps xmm1, [rsp]
000079bd661deda6  add rsp, 0x30
000079bd661dedaa  vmovaps xmm0, [rsp]
000079bd661dedaf  vmovaps xmm2, [rsp+0x10]
000079bd661dedb5  vmovaps xmm3, [rsp+0x20]
000079bd661dedbb  vmovaps xmm4, [rsp+0x30]
000079bd661dedc1  vmovaps xmm5, [rsp+0x40]
000079bd661dedc7  vmovaps xmm6, [rsp+0x50]
000079bd661dedcd  vmovaps xmm7, [rsp+0x60]
000079bd661dedd3  vmovaps xmm8, [rsp+0x70]
000079bd661dedd9  vmovaps xmm9, [rsp+0x80]
000079bd661dede2  vmovaps xmm10, [rsp+0x90]
000079bd661dedeb  vmovaps xmm11, [rsp+0xA0]
000079bd661dedf4  vmovaps xmm12, [rsp+0xB0]
000079bd661dedfd  vmovaps xmm13, [rsp+0xC0]
000079bd661dee06  vmovaps xmm14, [rsp+0xD0]
000079bd661dee0f  vmovaps xmm15, [rsp+0xE0]
000079bd661dee18  add rsp, 0xF0
000079bd661dee1f  pop r11
000079bd661dee21  pop r10
000079bd661dee23  pop r9
000079bd661dee25  pop r8
000079bd661dee27  pop rsi
000079bd661dee28  pop rdi
000079bd661dee29  pop rdx
000079bd661dee2a  pop rcx
000079bd661dee2b  pop rax
000079bd661dee2c  add rsp, 0x08
000079bd661dee30  jmp 0x000079BD661DC2EE
000079bd661dee35  sub rsp, 0x08
000079bd661dee39  push rax
000079bd661dee3a  push rcx
000079bd661dee3b  push rdx
000079bd661dee3c  push rdi
000079bd661dee3d  push rsi
000079bd661dee3e  push r8
000079bd661dee40  push r9
000079bd661dee42  push r10
000079bd661dee44  push r11
000079bd661dee46  sub rsp, 0xF0
000079bd661dee4d  vmovaps [rsp], xmm0
000079bd661dee52  vmovaps [rsp+0x10], xmm1
000079bd661dee58  vmovaps [rsp+0x20], xmm2
000079bd661dee5e  vmovaps [rsp+0x30], xmm3
000079bd661dee64  vmovaps [rsp+0x40], xmm5
000079bd661dee6a  vmovaps [rsp+0x50], xmm6
000079bd661dee70  vmovaps [rsp+0x60], xmm7
000079bd661dee76  vmovaps [rsp+0x70], xmm8
000079bd661dee7c  vmovaps [rsp+0x80], xmm9
000079bd661dee85  vmovaps [rsp+0x90], xmm10
000079bd661dee8e  vmovaps [rsp+0xA0], xmm11
000079bd661dee97  vmovaps [rsp+0xB0], xmm12
000079bd661deea0  vmovaps [rsp+0xC0], xmm13
000079bd661deea9  vmovaps [rsp+0xD0], xmm14
000079bd661deeb2  vmovaps [rsp+0xE0], xmm15
000079bd661deebb  sub rsp, 0x30
000079bd661deebf  movaps [rsp], xmm4
000079bd661deec3  movaps [rsp+0x10], xmm2
000079bd661deec8  movaps [rsp+0x20], xmm9
000079bd661deece  lea rdi, [rsp]
000079bd661deed2  mov esi, 0x00
000079bd661deed7  mov rax, 0x56EBD57B0530
000079bd661deee1  call rax
000079bd661deee3  movaps xmm4, [rsp]
000079bd661deee7  add rsp, 0x30
000079bd661deeeb  vmovaps xmm0, [rsp]
000079bd661deef0  vmovaps xmm1, [rsp+0x10]
000079bd661deef6  vmovaps xmm2, [rsp+0x20]
000079bd661deefc  vmovaps xmm3, [rsp+0x30]
000079bd661def02  vmovaps xmm5, [rsp+0x40]
000079bd661def08  vmovaps xmm6, [rsp+0x50]
000079bd661def0e  vmovaps xmm7, [rsp+0x60]
000079bd661def14  vmovaps xmm8, [rsp+0x70]
000079bd661def1a  vmovaps xmm9, [rsp+0x80]
000079bd661def23  vmovaps xmm10, [rsp+0x90]
000079bd661def2c  vmovaps xmm11, [rsp+0xA0]
000079bd661def35  vmovaps xmm12, [rsp+0xB0]
000079bd661def3e  vmovaps xmm13, [rsp+0xC0]
000079bd661def47  vmovaps xmm14, [rsp+0xD0]
000079bd661def50  vmovaps xmm15, [rsp+0xE0]
000079bd661def59  add rsp, 0xF0
000079bd661def60  pop r11
000079bd661def62  pop r10
000079bd661def64  pop r9
000079bd661def66  pop r8
000079bd661def68  pop rsi
000079bd661def69  pop rdi
000079bd661def6a  pop rdx
000079bd661def6b  pop rcx
000079bd661def6c  pop rax
000079bd661def6d  add rsp, 0x08
000079bd661def71  jmp 0x000079BD661DC31E
000079bd661def76  sub rsp, 0x08
000079bd661def7a  push rax
000079bd661def7b  push rcx
000079bd661def7c  push rdx
000079bd661def7d  push rdi
000079bd661def7e  push rsi
000079bd661def7f  push r8
000079bd661def81  push r9
000079bd661def83  push r10
000079bd661def85  push r11
000079bd661def87  sub rsp, 0xF0
000079bd661def8e  vmovaps [rsp], xmm0
000079bd661def93  vmovaps [rsp+0x10], xmm1
000079bd661def99  vmovaps [rsp+0x20], xmm2
000079bd661def9f  vmovaps [rsp+0x30], xmm3
000079bd661defa5  vmovaps [rsp+0x40], xmm4
000079bd661defab  vmovaps [rsp+0x50], xmm5
000079bd661defb1  vmovaps [rsp+0x60], xmm6
000079bd661defb7  vmovaps [rsp+0x70], xmm7
000079bd661defbd  vmovaps [rsp+0x80], xmm8
000079bd661defc6  vmovaps [rsp+0x90], xmm10
000079bd661defcf  vmovaps [rsp+0xA0], xmm11
000079bd661defd8  vmovaps [rsp+0xB0], xmm12
000079bd661defe1  vmovaps [rsp+0xC0], xmm13
000079bd661defea  vmovaps [rsp+0xD0], xmm14
000079bd661deff3  vmovaps [rsp+0xE0], xmm15
000079bd661deffc  sub rsp, 0x30
000079bd661df000  movaps [rsp], xmm9
000079bd661df005  movaps [rsp+0x10], xmm2
000079bd661df00a  movaps [rsp+0x20], xmm1
000079bd661df00f  lea rdi, [rsp]
000079bd661df013  mov esi, 0x00
000079bd661df018  mov rax, 0x56EBD57B0530
000079bd661df022  call rax
000079bd661df024  movaps xmm9, [rsp]
000079bd661df029  add rsp, 0x30
000079bd661df02d  vmovaps xmm0, [rsp]
000079bd661df032  vmovaps xmm1, [rsp+0x10]
000079bd661df038  vmovaps xmm2, [rsp+0x20]
000079bd661df03e  vmovaps xmm3, [rsp+0x30]
000079bd661df044  vmovaps xmm4, [rsp+0x40]
000079bd661df04a  vmovaps xmm5, [rsp+0x50]
000079bd661df050  vmovaps xmm6, [rsp+0x60]
000079bd661df056  vmovaps xmm7, [rsp+0x70]
000079bd661df05c  vmovaps xmm8, [rsp+0x80]
000079bd661df065  vmovaps xmm10, [rsp+0x90]
000079bd661df06e  vmovaps xmm11, [rsp+0xA0]
000079bd661df077  vmovaps xmm12, [rsp+0xB0]
000079bd661df080  vmovaps xmm13, [rsp+0xC0]
000079bd661df089  vmovaps xmm14, [rsp+0xD0]
000079bd661df092  vmovaps xmm15, [rsp+0xE0]
000079bd661df09b  add rsp, 0xF0
000079bd661df0a2  pop r11
000079bd661df0a4  pop r10
000079bd661df0a6  pop r9
000079bd661df0a8  pop r8
000079bd661df0aa  pop rsi
000079bd661df0ab  pop rdi
000079bd661df0ac  pop rdx
000079bd661df0ad  pop rcx
000079bd661df0ae  pop rax
000079bd661df0af  add rsp, 0x08
000079bd661df0b3  jmp 0x000079BD661DC354
000079bd661df0b8  sub rsp, 0x08
000079bd661df0bc  push rax
000079bd661df0bd  push rcx
000079bd661df0be  push rdx
000079bd661df0bf  push rdi
000079bd661df0c0  push rsi
000079bd661df0c1  push r8
000079bd661df0c3  push r9
000079bd661df0c5  push r10
000079bd661df0c7  push r11
000079bd661df0c9  sub rsp, 0xF0
000079bd661df0d0  vmovaps [rsp], xmm0
000079bd661df0d5  vmovaps [rsp+0x10], xmm2
000079bd661df0db  vmovaps [rsp+0x20], xmm3
000079bd661df0e1  vmovaps [rsp+0x30], xmm4
000079bd661df0e7  vmovaps [rsp+0x40], xmm5
000079bd661df0ed  vmovaps [rsp+0x50], xmm6
000079bd661df0f3  vmovaps [rsp+0x60], xmm7
000079bd661df0f9  vmovaps [rsp+0x70], xmm8
000079bd661df0ff  vmovaps [rsp+0x80], xmm9
000079bd661df108  vmovaps [rsp+0x90], xmm10
000079bd661df111  vmovaps [rsp+0xA0], xmm11
000079bd661df11a  vmovaps [rsp+0xB0], xmm12
000079bd661df123  vmovaps [rsp+0xC0], xmm13
000079bd661df12c  vmovaps [rsp+0xD0], xmm14
000079bd661df135  vmovaps [rsp+0xE0], xmm15
000079bd661df13e  sub rsp, 0x30
000079bd661df142  movaps [rsp], xmm1
000079bd661df146  movaps [rsp+0x10], xmm15
000079bd661df14c  movaps [rsp+0x20], xmm6
000079bd661df151  lea rdi, [rsp]
000079bd661df155  mov esi, 0x00
000079bd661df15a  mov rax, 0x56EBD57B0530
000079bd661df164  call rax
000079bd661df166  movaps xmm1, [rsp]
000079bd661df16a  add rsp, 0x30
000079bd661df16e  vmovaps xmm0, [rsp]
000079bd661df173  vmovaps xmm2, [rsp+0x10]
000079bd661df179  vmovaps xmm3, [rsp+0x20]
000079bd661df17f  vmovaps xmm4, [rsp+0x30]
000079bd661df185  vmovaps xmm5, [rsp+0x40]
000079bd661df18b  vmovaps xmm6, [rsp+0x50]
000079bd661df191  vmovaps xmm7, [rsp+0x60]
000079bd661df197  vmovaps xmm8, [rsp+0x70]
000079bd661df19d  vmovaps xmm9, [rsp+0x80]
000079bd661df1a6  vmovaps xmm10, [rsp+0x90]
000079bd661df1af  vmovaps xmm11, [rsp+0xA0]
000079bd661df1b8  vmovaps xmm12, [rsp+0xB0]
000079bd661df1c1  vmovaps xmm13, [rsp+0xC0]
000079bd661df1ca  vmovaps xmm14, [rsp+0xD0]
000079bd661df1d3  vmovaps xmm15, [rsp+0xE0]
000079bd661df1dc  add rsp, 0xF0
000079bd661df1e3  pop r11
000079bd661df1e5  pop r10
000079bd661df1e7  pop r9
000079bd661df1e9  pop r8
000079bd661df1eb  pop rsi
000079bd661df1ec  pop rdi
000079bd661df1ed  pop rdx
000079bd661df1ee  pop rcx
000079bd661df1ef  pop rax
000079bd661df1f0  add rsp, 0x08
000079bd661df1f4  jmp 0x000079BD661DC375
000079bd661df1f9  sub rsp, 0x08
000079bd661df1fd  push rax
000079bd661df1fe  push rcx
000079bd661df1ff  push rdx
000079bd661df200  push rdi
000079bd661df201  push rsi
000079bd661df202  push r8
000079bd661df204  push r9
000079bd661df206  push r10
000079bd661df208  push r11
000079bd661df20a  sub rsp, 0xF0
000079bd661df211  vmovaps [rsp], xmm0
000079bd661df216  vmovaps [rsp+0x10], xmm1
000079bd661df21c  vmovaps [rsp+0x20], xmm2
000079bd661df222  vmovaps [rsp+0x30], xmm3
000079bd661df228  vmovaps [rsp+0x40], xmm4
000079bd661df22e  vmovaps [rsp+0x50], xmm5
000079bd661df234  vmovaps [rsp+0x60], xmm6
000079bd661df23a  vmovaps [rsp+0x70], xmm7
000079bd661df240  vmovaps [rsp+0x80], xmm8
000079bd661df249  vmovaps [rsp+0x90], xmm9
000079bd661df252  vmovaps [rsp+0xA0], xmm10
000079bd661df25b  vmovaps [rsp+0xB0], xmm11
000079bd661df264  vmovaps [rsp+0xC0], xmm12
000079bd661df26d  vmovaps [rsp+0xD0], xmm13
000079bd661df276  vmovaps [rsp+0xE0], xmm14
000079bd661df27f  sub rsp, 0x30
000079bd661df283  movaps [rsp], xmm15
000079bd661df288  movaps [rsp+0x10], xmm5
000079bd661df28d  movaps [rsp+0x20], xmm3
000079bd661df292  lea rdi, [rsp]
000079bd661df296  mov esi, 0x00
000079bd661df29b  mov rax, 0x56EBD57B0530
000079bd661df2a5  call rax
000079bd661df2a7  movaps xmm15, [rsp]
000079bd661df2ac  add rsp, 0x30
000079bd661df2b0  vmovaps xmm0, [rsp]
000079bd661df2b5  vmovaps xmm1, [rsp+0x10]
000079bd661df2bb  vmovaps xmm2, [rsp+0x20]
000079bd661df2c1  vmovaps xmm3, [rsp+0x30]
000079bd661df2c7  vmovaps xmm4, [rsp+0x40]
000079bd661df2cd  vmovaps xmm5, [rsp+0x50]
000079bd661df2d3  vmovaps xmm6, [rsp+0x60]
000079bd661df2d9  vmovaps xmm7, [rsp+0x70]
000079bd661df2df  vmovaps xmm8, [rsp+0x80]
000079bd661df2e8  vmovaps xmm9, [rsp+0x90]
000079bd661df2f1  vmovaps xmm10, [rsp+0xA0]
000079bd661df2fa  vmovaps xmm11, [rsp+0xB0]
000079bd661df303  vmovaps xmm12, [rsp+0xC0]
000079bd661df30c  vmovaps xmm13, [rsp+0xD0]
000079bd661df315  vmovaps xmm14, [rsp+0xE0]
000079bd661df31e  add rsp, 0xF0
000079bd661df325  pop r11
000079bd661df327  pop r10
000079bd661df329  pop r9
000079bd661df32b  pop r8
000079bd661df32d  pop rsi
000079bd661df32e  pop rdi
000079bd661df32f  pop rdx
000079bd661df330  pop rcx
000079bd661df331  pop rax
000079bd661df332  add rsp, 0x08
000079bd661df336  jmp 0x000079BD661DC38F
000079bd661df33b  sub rsp, 0x08
000079bd661df33f  push rax
000079bd661df340  push rcx
000079bd661df341  push rdx
000079bd661df342  push rdi
000079bd661df343  push rsi
000079bd661df344  push r8
000079bd661df346  push r9
000079bd661df348  push r10
000079bd661df34a  push r11
000079bd661df34c  sub rsp, 0xF0
000079bd661df353  vmovaps [rsp], xmm0
000079bd661df358  vmovaps [rsp+0x10], xmm1
000079bd661df35e  vmovaps [rsp+0x20], xmm2
000079bd661df364  vmovaps [rsp+0x30], xmm3
000079bd661df36a  vmovaps [rsp+0x40], xmm4
000079bd661df370  vmovaps [rsp+0x50], xmm6
000079bd661df376  vmovaps [rsp+0x60], xmm7
000079bd661df37c  vmovaps [rsp+0x70], xmm8
000079bd661df382  vmovaps [rsp+0x80], xmm9
000079bd661df38b  vmovaps [rsp+0x90], xmm10
000079bd661df394  vmovaps [rsp+0xA0], xmm11
000079bd661df39d  vmovaps [rsp+0xB0], xmm12
000079bd661df3a6  vmovaps [rsp+0xC0], xmm13
000079bd661df3af  vmovaps [rsp+0xD0], xmm14
000079bd661df3b8  vmovaps [rsp+0xE0], xmm15
000079bd661df3c1  sub rsp, 0x30
000079bd661df3c5  movaps [rsp], xmm5
000079bd661df3c9  movaps [rsp+0x10], xmm8
000079bd661df3cf  movaps [rsp+0x20], xmm6
000079bd661df3d4  lea rdi, [rsp]
000079bd661df3d8  mov esi, 0x00
000079bd661df3dd  mov rax, 0x56EBD57B0530
000079bd661df3e7  call rax
000079bd661df3e9  movaps xmm5, [rsp]
000079bd661df3ed  add rsp, 0x30
000079bd661df3f1  vmovaps xmm0, [rsp]
000079bd661df3f6  vmovaps xmm1, [rsp+0x10]
000079bd661df3fc  vmovaps xmm2, [rsp+0x20]
000079bd661df402  vmovaps xmm3, [rsp+0x30]
000079bd661df408  vmovaps xmm4, [rsp+0x40]
000079bd661df40e  vmovaps xmm6, [rsp+0x50]
000079bd661df414  vmovaps xmm7, [rsp+0x60]
000079bd661df41a  vmovaps xmm8, [rsp+0x70]
000079bd661df420  vmovaps xmm9, [rsp+0x80]
000079bd661df429  vmovaps xmm10, [rsp+0x90]
000079bd661df432  vmovaps xmm11, [rsp+0xA0]
000079bd661df43b  vmovaps xmm12, [rsp+0xB0]
000079bd661df444  vmovaps xmm13, [rsp+0xC0]
000079bd661df44d  vmovaps xmm14, [rsp+0xD0]
000079bd661df456  vmovaps xmm15, [rsp+0xE0]
000079bd661df45f  add rsp, 0xF0
000079bd661df466  pop r11
000079bd661df468  pop r10
000079bd661df46a  pop r9
000079bd661df46c  pop r8
000079bd661df46e  pop rsi
000079bd661df46f  pop rdi
000079bd661df470  pop rdx
000079bd661df471  pop rcx
000079bd661df472  pop rax
000079bd661df473  add rsp, 0x08
000079bd661df477  jmp 0x000079BD661DC3B3
000079bd661df47c  sub rsp, 0x08
000079bd661df480  push rax
000079bd661df481  push rcx
000079bd661df482  push rdx
000079bd661df483  push rdi
000079bd661df484  push rsi
000079bd661df485  push r8
000079bd661df487  push r9
000079bd661df489  push r10
000079bd661df48b  push r11
000079bd661df48d  sub rsp, 0xF0
000079bd661df494  vmovaps [rsp], xmm0
000079bd661df499  vmovaps [rsp+0x10], xmm1
000079bd661df49f  vmovaps [rsp+0x20], xmm2
000079bd661df4a5  vmovaps [rsp+0x30], xmm3
000079bd661df4ab  vmovaps [rsp+0x40], xmm4
000079bd661df4b1  vmovaps [rsp+0x50], xmm5
000079bd661df4b7  vmovaps [rsp+0x60], xmm7
000079bd661df4bd  vmovaps [rsp+0x70], xmm8
000079bd661df4c3  vmovaps [rsp+0x80], xmm9
000079bd661df4cc  vmovaps [rsp+0x90], xmm10
000079bd661df4d5  vmovaps [rsp+0xA0], xmm11
000079bd661df4de  vmovaps [rsp+0xB0], xmm12
000079bd661df4e7  vmovaps [rsp+0xC0], xmm13
000079bd661df4f0  vmovaps [rsp+0xD0], xmm14
000079bd661df4f9  vmovaps [rsp+0xE0], xmm15
000079bd661df502  sub rsp, 0x30
000079bd661df506  movaps [rsp], xmm6
000079bd661df50a  movaps [rsp+0x10], xmm10
000079bd661df510  movaps [rsp+0x20], xmm8
000079bd661df516  lea rdi, [rsp]
000079bd661df51a  mov esi, 0x00
000079bd661df51f  mov rax, 0x56EBD57B0530
000079bd661df529  call rax
000079bd661df52b  movaps xmm6, [rsp]
000079bd661df52f  add rsp, 0x30
000079bd661df533  vmovaps xmm0, [rsp]
000079bd661df538  vmovaps xmm1, [rsp+0x10]
000079bd661df53e  vmovaps xmm2, [rsp+0x20]
000079bd661df544  vmovaps xmm3, [rsp+0x30]
000079bd661df54a  vmovaps xmm4, [rsp+0x40]
000079bd661df550  vmovaps xmm5, [rsp+0x50]
000079bd661df556  vmovaps xmm7, [rsp+0x60]
000079bd661df55c  vmovaps xmm8, [rsp+0x70]
000079bd661df562  vmovaps xmm9, [rsp+0x80]
000079bd661df56b  vmovaps xmm10, [rsp+0x90]
000079bd661df574  vmovaps xmm11, [rsp+0xA0]
000079bd661df57d  vmovaps xmm12, [rsp+0xB0]
000079bd661df586  vmovaps xmm13, [rsp+0xC0]
000079bd661df58f  vmovaps xmm14, [rsp+0xD0]
000079bd661df598  vmovaps xmm15, [rsp+0xE0]
000079bd661df5a1  add rsp, 0xF0
000079bd661df5a8  pop r11
000079bd661df5aa  pop r10
000079bd661df5ac  pop r9
000079bd661df5ae  pop r8
000079bd661df5b0  pop rsi
000079bd661df5b1  pop rdi
000079bd661df5b2  pop rdx
000079bd661df5b3  pop rcx
000079bd661df5b4  pop rax
000079bd661df5b5  add rsp, 0x08
000079bd661df5b9  jmp 0x000079BD661DC3D8
000079bd661df5be  sub rsp, 0x08
000079bd661df5c2  push rax
000079bd661df5c3  push rcx
000079bd661df5c4  push rdx
000079bd661df5c5  push rdi
000079bd661df5c6  push rsi
000079bd661df5c7  push r8
000079bd661df5c9  push r9
000079bd661df5cb  push r10
000079bd661df5cd  push r11
000079bd661df5cf  sub rsp, 0xF0
000079bd661df5d6  vmovaps [rsp], xmm0
000079bd661df5db  vmovaps [rsp+0x10], xmm1
000079bd661df5e1  vmovaps [rsp+0x20], xmm2
000079bd661df5e7  vmovaps [rsp+0x30], xmm3
000079bd661df5ed  vmovaps [rsp+0x40], xmm4
000079bd661df5f3  vmovaps [rsp+0x50], xmm5
000079bd661df5f9  vmovaps [rsp+0x60], xmm6
000079bd661df5ff  vmovaps [rsp+0x70], xmm7
000079bd661df605  vmovaps [rsp+0x80], xmm8
000079bd661df60e  vmovaps [rsp+0x90], xmm9
000079bd661df617  vmovaps [rsp+0xA0], xmm11
000079bd661df620  vmovaps [rsp+0xB0], xmm12
000079bd661df629  vmovaps [rsp+0xC0], xmm13
000079bd661df632  vmovaps [rsp+0xD0], xmm14
000079bd661df63b  vmovaps [rsp+0xE0], xmm15
000079bd661df644  sub rsp, 0x30
000079bd661df648  movaps [rsp], xmm10
000079bd661df64d  movaps [rsp+0x10], xmm8
000079bd661df653  movaps [rsp+0x20], xmm14
000079bd661df659  lea rdi, [rsp]
000079bd661df65d  mov esi, 0x00
000079bd661df662  mov rax, 0x56EBD57B0530
000079bd661df66c  call rax
000079bd661df66e  movaps xmm10, [rsp]
000079bd661df673  add rsp, 0x30
000079bd661df677  vmovaps xmm0, [rsp]
000079bd661df67c  vmovaps xmm1, [rsp+0x10]
000079bd661df682  vmovaps xmm2, [rsp+0x20]
000079bd661df688  vmovaps xmm3, [rsp+0x30]
000079bd661df68e  vmovaps xmm4, [rsp+0x40]
000079bd661df694  vmovaps xmm5, [rsp+0x50]
000079bd661df69a  vmovaps xmm6, [rsp+0x60]
000079bd661df6a0  vmovaps xmm7, [rsp+0x70]
000079bd661df6a6  vmovaps xmm8, [rsp+0x80]
000079bd661df6af  vmovaps xmm9, [rsp+0x90]
000079bd661df6b8  vmovaps xmm11, [rsp+0xA0]
000079bd661df6c1  vmovaps xmm12, [rsp+0xB0]
000079bd661df6ca  vmovaps xmm13, [rsp+0xC0]
000079bd661df6d3  vmovaps xmm14, [rsp+0xD0]
000079bd661df6dc  vmovaps xmm15, [rsp+0xE0]
000079bd661df6e5  add rsp, 0xF0
000079bd661df6ec  pop r11
000079bd661df6ee  pop r10
000079bd661df6f0  pop r9
000079bd661df6f2  pop r8
000079bd661df6f4  pop rsi
000079bd661df6f5  pop rdi
000079bd661df6f6  pop rdx
000079bd661df6f7  pop rcx
000079bd661df6f8  pop rax
000079bd661df6f9  add rsp, 0x08
000079bd661df6fd  jmp 0x000079BD661DC3F8
000079bd661df702  sub rsp, 0x08
000079bd661df706  push rax
000079bd661df707  push rcx
000079bd661df708  push rdx
000079bd661df709  push rdi
000079bd661df70a  push rsi
000079bd661df70b  push r8
000079bd661df70d  push r9
000079bd661df70f  push r10
000079bd661df711  push r11
000079bd661df713  sub rsp, 0xF0
000079bd661df71a  vmovaps [rsp], xmm0
000079bd661df71f  vmovaps [rsp+0x10], xmm1
000079bd661df725  vmovaps [rsp+0x20], xmm2
000079bd661df72b  vmovaps [rsp+0x30], xmm3
000079bd661df731  vmovaps [rsp+0x40], xmm4
000079bd661df737  vmovaps [rsp+0x50], xmm5
000079bd661df73d  vmovaps [rsp+0x60], xmm6
000079bd661df743  vmovaps [rsp+0x70], xmm7
000079bd661df749  vmovaps [rsp+0x80], xmm8
000079bd661df752  vmovaps [rsp+0x90], xmm9
000079bd661df75b  vmovaps [rsp+0xA0], xmm10
000079bd661df764  vmovaps [rsp+0xB0], xmm11
000079bd661df76d  vmovaps [rsp+0xC0], xmm12
000079bd661df776  vmovaps [rsp+0xD0], xmm13
000079bd661df77f  vmovaps [rsp+0xE0], xmm15
000079bd661df788  sub rsp, 0x30
000079bd661df78c  movaps [rsp], xmm14
000079bd661df791  movaps [rsp+0x10], xmm8
000079bd661df797  movaps [rsp+0x20], xmm4
000079bd661df79c  lea rdi, [rsp]
000079bd661df7a0  mov esi, 0x00
000079bd661df7a5  mov rax, 0x56EBD57B0530
000079bd661df7af  call rax
000079bd661df7b1  movaps xmm14, [rsp]
000079bd661df7b6  add rsp, 0x30
000079bd661df7ba  vmovaps xmm0, [rsp]
000079bd661df7bf  vmovaps xmm1, [rsp+0x10]
000079bd661df7c5  vmovaps xmm2, [rsp+0x20]
000079bd661df7cb  vmovaps xmm3, [rsp+0x30]
000079bd661df7d1  vmovaps xmm4, [rsp+0x40]
000079bd661df7d7  vmovaps xmm5, [rsp+0x50]
000079bd661df7dd  vmovaps xmm6, [rsp+0x60]
000079bd661df7e3  vmovaps xmm7, [rsp+0x70]
000079bd661df7e9  vmovaps xmm8, [rsp+0x80]
000079bd661df7f2  vmovaps xmm9, [rsp+0x90]
000079bd661df7fb  vmovaps xmm10, [rsp+0xA0]
000079bd661df804  vmovaps xmm11, [rsp+0xB0]
000079bd661df80d  vmovaps xmm12, [rsp+0xC0]
000079bd661df816  vmovaps xmm13, [rsp+0xD0]
000079bd661df81f  vmovaps xmm15, [rsp+0xE0]
000079bd661df828  add rsp, 0xF0
000079bd661df82f  pop r11
000079bd661df831  pop r10
000079bd661df833  pop r9
000079bd661df835  pop r8
000079bd661df837  pop rsi
000079bd661df838  pop rdi
000079bd661df839  pop rdx
000079bd661df83a  pop rcx
000079bd661df83b  pop rax
000079bd661df83c  add rsp, 0x08
000079bd661df840  jmp 0x000079BD661DC418
000079bd661df845  sub rsp, 0x08
000079bd661df849  push rax
000079bd661df84a  push rcx
000079bd661df84b  push rdx
000079bd661df84c  push rdi
000079bd661df84d  push rsi
000079bd661df84e  push r8
000079bd661df850  push r9
000079bd661df852  push r10
000079bd661df854  push r11
000079bd661df856  sub rsp, 0xF0
000079bd661df85d  vmovaps [rsp], xmm0
000079bd661df862  vmovaps [rsp+0x10], xmm1
000079bd661df868  vmovaps [rsp+0x20], xmm2
000079bd661df86e  vmovaps [rsp+0x30], xmm3
000079bd661df874  vmovaps [rsp+0x40], xmm5
000079bd661df87a  vmovaps [rsp+0x50], xmm6
000079bd661df880  vmovaps [rsp+0x60], xmm7
000079bd661df886  vmovaps [rsp+0x70], xmm8
000079bd661df88c  vmovaps [rsp+0x80], xmm9
000079bd661df895  vmovaps [rsp+0x90], xmm10
000079bd661df89e  vmovaps [rsp+0xA0], xmm11
000079bd661df8a7  vmovaps [rsp+0xB0], xmm12
000079bd661df8b0  vmovaps [rsp+0xC0], xmm13
000079bd661df8b9  vmovaps [rsp+0xD0], xmm14
000079bd661df8c2  vmovaps [rsp+0xE0], xmm15
000079bd661df8cb  sub rsp, 0x30
000079bd661df8cf  movaps [rsp], xmm4
000079bd661df8d3  movaps [rsp+0x10], xmm13
000079bd661df8d9  movaps [rsp+0x20], xmm8
000079bd661df8df  lea rdi, [rsp]
000079bd661df8e3  mov esi, 0x00
000079bd661df8e8  mov rax, 0x56EBD57B0530
000079bd661df8f2  call rax
000079bd661df8f4  movaps xmm4, [rsp]
000079bd661df8f8  add rsp, 0x30
000079bd661df8fc  vmovaps xmm0, [rsp]
000079bd661df901  vmovaps xmm1, [rsp+0x10]
000079bd661df907  vmovaps xmm2, [rsp+0x20]
000079bd661df90d  vmovaps xmm3, [rsp+0x30]
000079bd661df913  vmovaps xmm5, [rsp+0x40]
000079bd661df919  vmovaps xmm6, [rsp+0x50]
000079bd661df91f  vmovaps xmm7, [rsp+0x60]
000079bd661df925  vmovaps xmm8, [rsp+0x70]
000079bd661df92b  vmovaps xmm9, [rsp+0x80]
000079bd661df934  vmovaps xmm10, [rsp+0x90]
000079bd661df93d  vmovaps xmm11, [rsp+0xA0]
000079bd661df946  vmovaps xmm12, [rsp+0xB0]
000079bd661df94f  vmovaps xmm13, [rsp+0xC0]
000079bd661df958  vmovaps xmm14, [rsp+0xD0]
000079bd661df961  vmovaps xmm15, [rsp+0xE0]
000079bd661df96a  add rsp, 0xF0
000079bd661df971  pop r11
000079bd661df973  pop r10
000079bd661df975  pop r9
000079bd661df977  pop r8
000079bd661df979  pop rsi
000079bd661df97a  pop rdi
000079bd661df97b  pop rdx
000079bd661df97c  pop rcx
000079bd661df97d  pop rax
000079bd661df97e  add rsp, 0x08
000079bd661df982  jmp 0x000079BD661DC43D
000079bd661df987  sub rsp, 0x08
000079bd661df98b  push rax
000079bd661df98c  push rcx
000079bd661df98d  push rdx
000079bd661df98e  push rdi
000079bd661df98f  push rsi
000079bd661df990  push r8
000079bd661df992  push r9
000079bd661df994  push r10
000079bd661df996  push r11
000079bd661df998  sub rsp, 0xF0
000079bd661df99f  vmovaps [rsp], xmm0
000079bd661df9a4  vmovaps [rsp+0x10], xmm1
000079bd661df9aa  vmovaps [rsp+0x20], xmm2
000079bd661df9b0  vmovaps [rsp+0x30], xmm3
000079bd661df9b6  vmovaps [rsp+0x40], xmm4
000079bd661df9bc  vmovaps [rsp+0x50], xmm5
000079bd661df9c2  vmovaps [rsp+0x60], xmm6
000079bd661df9c8  vmovaps [rsp+0x70], xmm7
000079bd661df9ce  vmovaps [rsp+0x80], xmm8
000079bd661df9d7  vmovaps [rsp+0x90], xmm9
000079bd661df9e0  vmovaps [rsp+0xA0], xmm10
000079bd661df9e9  vmovaps [rsp+0xB0], xmm11
000079bd661df9f2  vmovaps [rsp+0xC0], xmm12
000079bd661df9fb  vmovaps [rsp+0xD0], xmm14
000079bd661dfa04  vmovaps [rsp+0xE0], xmm15
000079bd661dfa0d  sub rsp, 0x30
000079bd661dfa11  movaps [rsp], xmm13
000079bd661dfa16  movaps [rsp+0x10], xmm15
000079bd661dfa1c  movaps [rsp+0x20], xmm9
000079bd661dfa22  lea rdi, [rsp]
000079bd661dfa26  mov esi, 0x00
000079bd661dfa2b  mov rax, 0x56EBD57B0530
000079bd661dfa35  call rax
000079bd661dfa37  movaps xmm13, [rsp]
000079bd661dfa3c  add rsp, 0x30
000079bd661dfa40  vmovaps xmm0, [rsp]
000079bd661dfa45  vmovaps xmm1, [rsp+0x10]
000079bd661dfa4b  vmovaps xmm2, [rsp+0x20]
000079bd661dfa51  vmovaps xmm3, [rsp+0x30]
000079bd661dfa57  vmovaps xmm4, [rsp+0x40]
000079bd661dfa5d  vmovaps xmm5, [rsp+0x50]
000079bd661dfa63  vmovaps xmm6, [rsp+0x60]
000079bd661dfa69  vmovaps xmm7, [rsp+0x70]
000079bd661dfa6f  vmovaps xmm8, [rsp+0x80]
000079bd661dfa78  vmovaps xmm9, [rsp+0x90]
000079bd661dfa81  vmovaps xmm10, [rsp+0xA0]
000079bd661dfa8a  vmovaps xmm11, [rsp+0xB0]
000079bd661dfa93  vmovaps xmm12, [rsp+0xC0]
000079bd661dfa9c  vmovaps xmm14, [rsp+0xD0]
000079bd661dfaa5  vmovaps xmm15, [rsp+0xE0]
000079bd661dfaae  add rsp, 0xF0
000079bd661dfab5  pop r11
000079bd661dfab7  pop r10
000079bd661dfab9  pop r9
000079bd661dfabb  pop r8
000079bd661dfabd  pop rsi
000079bd661dfabe  pop rdi
000079bd661dfabf  pop rdx
000079bd661dfac0  pop rcx
000079bd661dfac1  pop rax
000079bd661dfac2  add rsp, 0x08
000079bd661dfac6  jmp 0x000079BD661DC458
000079bd661dfacb  sub rsp, 0x08
000079bd661dfacf  push rax
000079bd661dfad0  push rcx
000079bd661dfad1  push rdx
000079bd661dfad2  push rdi
000079bd661dfad3  push rsi
000079bd661dfad4  push r8
000079bd661dfad6  push r9
000079bd661dfad8  push r10
000079bd661dfada  push r11
000079bd661dfadc  sub rsp, 0xF0
000079bd661dfae3  vmovaps [rsp], xmm0
000079bd661dfae8  vmovaps [rsp+0x10], xmm1
000079bd661dfaee  vmovaps [rsp+0x20], xmm2
000079bd661dfaf4  vmovaps [rsp+0x30], xmm3
000079bd661dfafa  vmovaps [rsp+0x40], xmm4
000079bd661dfb00  vmovaps [rsp+0x50], xmm5
000079bd661dfb06  vmovaps [rsp+0x60], xmm6
000079bd661dfb0c  vmovaps [rsp+0x70], xmm7
000079bd661dfb12  vmovaps [rsp+0x80], xmm8
000079bd661dfb1b  vmovaps [rsp+0x90], xmm9
000079bd661dfb24  vmovaps [rsp+0xA0], xmm10
000079bd661dfb2d  vmovaps [rsp+0xB0], xmm11
000079bd661dfb36  vmovaps [rsp+0xC0], xmm12
000079bd661dfb3f  vmovaps [rsp+0xD0], xmm13
000079bd661dfb48  vmovaps [rsp+0xE0], xmm14
000079bd661dfb51  sub rsp, 0x30
000079bd661dfb55  movaps [rsp], xmm15
000079bd661dfb5a  movaps [rsp+0x10], xmm1
000079bd661dfb5f  movaps [rsp+0x20], xmm5
000079bd661dfb64  lea rdi, [rsp]
000079bd661dfb68  mov esi, 0x00
000079bd661dfb6d  mov rax, 0x56EBD57B0530
000079bd661dfb77  call rax
000079bd661dfb79  movaps xmm15, [rsp]
000079bd661dfb7e  add rsp, 0x30
000079bd661dfb82  vmovaps xmm0, [rsp]
000079bd661dfb87  vmovaps xmm1, [rsp+0x10]
000079bd661dfb8d  vmovaps xmm2, [rsp+0x20]
000079bd661dfb93  vmovaps xmm3, [rsp+0x30]
000079bd661dfb99  vmovaps xmm4, [rsp+0x40]
000079bd661dfb9f  vmovaps xmm5, [rsp+0x50]
000079bd661dfba5  vmovaps xmm6, [rsp+0x60]
000079bd661dfbab  vmovaps xmm7, [rsp+0x70]
000079bd661dfbb1  vmovaps xmm8, [rsp+0x80]
000079bd661dfbba  vmovaps xmm9, [rsp+0x90]
000079bd661dfbc3  vmovaps xmm10, [rsp+0xA0]
000079bd661dfbcc  vmovaps xmm11, [rsp+0xB0]
000079bd661dfbd5  vmovaps xmm12, [rsp+0xC0]
000079bd661dfbde  vmovaps xmm13, [rsp+0xD0]
000079bd661dfbe7  vmovaps xmm14, [rsp+0xE0]
000079bd661dfbf0  add rsp, 0xF0
000079bd661dfbf7  pop r11
000079bd661dfbf9  pop r10
000079bd661dfbfb  pop r9
000079bd661dfbfd  pop r8
000079bd661dfbff  pop rsi
000079bd661dfc00  pop rdi
000079bd661dfc01  pop rdx
000079bd661dfc02  pop rcx
000079bd661dfc03  pop rax
000079bd661dfc04  add rsp, 0x08
000079bd661dfc08  jmp 0x000079BD661DC473
000079bd661dfc0d  call 0x000079BD660B52F0
000079bd661dfc12  jmp 0x000079BD661DC4CE
000079bd661dfc17  sub rsp, 0x08
000079bd661dfc1b  push rax
000079bd661dfc1c  push rcx
000079bd661dfc1d  push rdx
000079bd661dfc1e  push rdi
000079bd661dfc1f  push rsi
000079bd661dfc20  push r8
000079bd661dfc22  push r9
000079bd661dfc24  push r10
000079bd661dfc26  push r11
000079bd661dfc28  sub rsp, 0xF0
000079bd661dfc2f  vmovaps [rsp], xmm0
000079bd661dfc34  vmovaps [rsp+0x10], xmm1
000079bd661dfc3a  vmovaps [rsp+0x20], xmm2
000079bd661dfc40  vmovaps [rsp+0x30], xmm3
000079bd661dfc46  vmovaps [rsp+0x40], xmm4
000079bd661dfc4c  vmovaps [rsp+0x50], xmm5
000079bd661dfc52  vmovaps [rsp+0x60], xmm6
000079bd661dfc58  vmovaps [rsp+0x70], xmm7
000079bd661dfc5e  vmovaps [rsp+0x80], xmm8
000079bd661dfc67  vmovaps [rsp+0x90], xmm10
000079bd661dfc70  vmovaps [rsp+0xA0], xmm11
000079bd661dfc79  vmovaps [rsp+0xB0], xmm12
000079bd661dfc82  vmovaps [rsp+0xC0], xmm13
000079bd661dfc8b  vmovaps [rsp+0xD0], xmm14
000079bd661dfc94  vmovaps [rsp+0xE0], xmm15
000079bd661dfc9d  sub rsp, 0x30
000079bd661dfca1  movaps [rsp], xmm9
000079bd661dfca6  movaps [rsp+0x10], xmm8
000079bd661dfcac  movaps [rsp+0x20], xmm11
000079bd661dfcb2  lea rdi, [rsp]
000079bd661dfcb6  mov esi, 0x00
000079bd661dfcbb  mov rax, 0x56EBD57B0530
000079bd661dfcc5  call rax
000079bd661dfcc7  movaps xmm9, [rsp]
000079bd661dfccc  add rsp, 0x30
000079bd661dfcd0  vmovaps xmm0, [rsp]
000079bd661dfcd5  vmovaps xmm1, [rsp+0x10]
000079bd661dfcdb  vmovaps xmm2, [rsp+0x20]
000079bd661dfce1  vmovaps xmm3, [rsp+0x30]
000079bd661dfce7  vmovaps xmm4, [rsp+0x40]
000079bd661dfced  vmovaps xmm5, [rsp+0x50]
000079bd661dfcf3  vmovaps xmm6, [rsp+0x60]
000079bd661dfcf9  vmovaps xmm7, [rsp+0x70]
000079bd661dfcff  vmovaps xmm8, [rsp+0x80]
000079bd661dfd08  vmovaps xmm10, [rsp+0x90]
000079bd661dfd11  vmovaps xmm11, [rsp+0xA0]
000079bd661dfd1a  vmovaps xmm12, [rsp+0xB0]
000079bd661dfd23  vmovaps xmm13, [rsp+0xC0]
000079bd661dfd2c  vmovaps xmm14, [rsp+0xD0]
000079bd661dfd35  vmovaps xmm15, [rsp+0xE0]
000079bd661dfd3e  add rsp, 0xF0
000079bd661dfd45  pop r11
000079bd661dfd47  pop r10
000079bd661dfd49  pop r9
000079bd661dfd4b  pop r8
000079bd661dfd4d  pop rsi
000079bd661dfd4e  pop rdi
000079bd661dfd4f  pop rdx
000079bd661dfd50  pop rcx
000079bd661dfd51  pop rax
000079bd661dfd52  add rsp, 0x08
000079bd661dfd56  jmp 0x000079BD661DC505
000079bd661dfd5b  sub rsp, 0x08
000079bd661dfd5f  push rax
000079bd661dfd60  push rcx
000079bd661dfd61  push rdx
000079bd661dfd62  push rdi
000079bd661dfd63  push rsi
000079bd661dfd64  push r8
000079bd661dfd66  push r9
000079bd661dfd68  push r10
000079bd661dfd6a  push r11
000079bd661dfd6c  sub rsp, 0xF0
000079bd661dfd73  vmovaps [rsp], xmm0
000079bd661dfd78  vmovaps [rsp+0x10], xmm1
000079bd661dfd7e  vmovaps [rsp+0x20], xmm2
000079bd661dfd84  vmovaps [rsp+0x30], xmm3
000079bd661dfd8a  vmovaps [rsp+0x40], xmm4
000079bd661dfd90  vmovaps [rsp+0x50], xmm5
000079bd661dfd96  vmovaps [rsp+0x60], xmm6
000079bd661dfd9c  vmovaps [rsp+0x70], xmm7
000079bd661dfda2  vmovaps [rsp+0x80], xmm8
000079bd661dfdab  vmovaps [rsp+0x90], xmm9
000079bd661dfdb4  vmovaps [rsp+0xA0], xmm10
000079bd661dfdbd  vmovaps [rsp+0xB0], xmm12
000079bd661dfdc6  vmovaps [rsp+0xC0], xmm13
000079bd661dfdcf  vmovaps [rsp+0xD0], xmm14
000079bd661dfdd8  vmovaps [rsp+0xE0], xmm15
000079bd661dfde1  sub rsp, 0x30
000079bd661dfde5  movaps [rsp], xmm11
000079bd661dfdea  movaps [rsp+0x10], xmm10
000079bd661dfdf0  movaps [rsp+0x20], xmm6
000079bd661dfdf5  lea rdi, [rsp]
000079bd661dfdf9  mov esi, 0x00
000079bd661dfdfe  mov rax, 0x56EBD57B0530
000079bd661dfe08  call rax
000079bd661dfe0a  movaps xmm11, [rsp]
000079bd661dfe0f  add rsp, 0x30
000079bd661dfe13  vmovaps xmm0, [rsp]
000079bd661dfe18  vmovaps xmm1, [rsp+0x10]
000079bd661dfe1e  vmovaps xmm2, [rsp+0x20]
000079bd661dfe24  vmovaps xmm3, [rsp+0x30]
000079bd661dfe2a  vmovaps xmm4, [rsp+0x40]
000079bd661dfe30  vmovaps xmm5, [rsp+0x50]
000079bd661dfe36  vmovaps xmm6, [rsp+0x60]
000079bd661dfe3c  vmovaps xmm7, [rsp+0x70]
000079bd661dfe42  vmovaps xmm8, [rsp+0x80]
000079bd661dfe4b  vmovaps xmm9, [rsp+0x90]
000079bd661dfe54  vmovaps xmm10, [rsp+0xA0]
000079bd661dfe5d  vmovaps xmm12, [rsp+0xB0]
000079bd661dfe66  vmovaps xmm13, [rsp+0xC0]
000079bd661dfe6f  vmovaps xmm14, [rsp+0xD0]
000079bd661dfe78  vmovaps xmm15, [rsp+0xE0]
000079bd661dfe81  add rsp, 0xF0
000079bd661dfe88  pop r11
000079bd661dfe8a  pop r10
000079bd661dfe8c  pop r9
000079bd661dfe8e  pop r8
000079bd661dfe90  pop rsi
000079bd661dfe91  pop rdi
000079bd661dfe92  pop rdx
000079bd661dfe93  pop rcx
000079bd661dfe94  pop rax
000079bd661dfe95  add rsp, 0x08
000079bd661dfe99  jmp 0x000079BD661DC520
000079bd661dfe9e  sub rsp, 0x08
000079bd661dfea2  push rax
000079bd661dfea3  push rcx
000079bd661dfea4  push rdx
000079bd661dfea5  push rdi
000079bd661dfea6  push rsi
000079bd661dfea7  push r8
000079bd661dfea9  push r9
000079bd661dfeab  push r10
000079bd661dfead  push r11
000079bd661dfeaf  sub rsp, 0xF0
000079bd661dfeb6  vmovaps [rsp], xmm0
000079bd661dfebb  vmovaps [rsp+0x10], xmm1
000079bd661dfec1  vmovaps [rsp+0x20], xmm2
000079bd661dfec7  vmovaps [rsp+0x30], xmm3
000079bd661dfecd  vmovaps [rsp+0x40], xmm4
000079bd661dfed3  vmovaps [rsp+0x50], xmm5
000079bd661dfed9  vmovaps [rsp+0x60], xmm6
000079bd661dfedf  vmovaps [rsp+0x70], xmm7
000079bd661dfee5  vmovaps [rsp+0x80], xmm8
000079bd661dfeee  vmovaps [rsp+0x90], xmm9
000079bd661dfef7  vmovaps [rsp+0xA0], xmm11
000079bd661dff00  vmovaps [rsp+0xB0], xmm12
000079bd661dff09  vmovaps [rsp+0xC0], xmm13
000079bd661dff12  vmovaps [rsp+0xD0], xmm14
000079bd661dff1b  vmovaps [rsp+0xE0], xmm15
000079bd661dff24  sub rsp, 0x30
000079bd661dff28  movaps [rsp], xmm10
000079bd661dff2d  movaps [rsp+0x10], xmm14
000079bd661dff33  movaps [rsp+0x20], xmm4
000079bd661dff38  lea rdi, [rsp]
000079bd661dff3c  mov esi, 0x00
000079bd661dff41  mov rax, 0x56EBD57B0530
000079bd661dff4b  call rax
000079bd661dff4d  movaps xmm10, [rsp]
000079bd661dff52  add rsp, 0x30
000079bd661dff56  vmovaps xmm0, [rsp]
000079bd661dff5b  vmovaps xmm1, [rsp+0x10]
000079bd661dff61  vmovaps xmm2, [rsp+0x20]
000079bd661dff67  vmovaps xmm3, [rsp+0x30]
000079bd661dff6d  vmovaps xmm4, [rsp+0x40]
000079bd661dff73  vmovaps xmm5, [rsp+0x50]
000079bd661dff79  vmovaps xmm6, [rsp+0x60]
000079bd661dff7f  vmovaps xmm7, [rsp+0x70]
000079bd661dff85  vmovaps xmm8, [rsp+0x80]
000079bd661dff8e  vmovaps xmm9, [rsp+0x90]
000079bd661dff97  vmovaps xmm11, [rsp+0xA0]
000079bd661dffa0  vmovaps xmm12, [rsp+0xB0]
000079bd661dffa9  vmovaps xmm13, [rsp+0xC0]
000079bd661dffb2  vmovaps xmm14, [rsp+0xD0]
000079bd661dffbb  vmovaps xmm15, [rsp+0xE0]
000079bd661dffc4  add rsp, 0xF0
000079bd661dffcb  pop r11
000079bd661dffcd  pop r10
000079bd661dffcf  pop r9
000079bd661dffd1  pop r8
000079bd661dffd3  pop rsi
000079bd661dffd4  pop rdi
000079bd661dffd5  pop rdx
000079bd661dffd6  pop rcx
000079bd661dffd7  pop rax
000079bd661dffd8  add rsp, 0x08
000079bd661dffdc  jmp 0x000079BD661DC53B
000079bd661dffe1  sub rsp, 0x08
000079bd661dffe5  push rax
000079bd661dffe6  push rcx
000079bd661dffe7  push rdx
000079bd661dffe8  push rdi
000079bd661dffe9  push rsi
000079bd661dffea  push r8
000079bd661dffec  push r9
000079bd661dffee  push r10
000079bd661dfff0  push r11
000079bd661dfff2  sub rsp, 0xF0
000079bd661dfff9  vmovaps [rsp], xmm0
000079bd661dfffe  vmovaps [rsp+0x10], xmm1
000079bd661e0004  vmovaps [rsp+0x20], xmm2
000079bd661e000a  vmovaps [rsp+0x30], xmm3
000079bd661e0010  vmovaps [rsp+0x40], xmm4
000079bd661e0016  vmovaps [rsp+0x50], xmm5
000079bd661e001c  vmovaps [rsp+0x60], xmm6
000079bd661e0022  vmovaps [rsp+0x70], xmm7
000079bd661e0028  vmovaps [rsp+0x80], xmm9
000079bd661e0031  vmovaps [rsp+0x90], xmm10
000079bd661e003a  vmovaps [rsp+0xA0], xmm11
000079bd661e0043  vmovaps [rsp+0xB0], xmm12
000079bd661e004c  vmovaps [rsp+0xC0], xmm13
000079bd661e0055  vmovaps [rsp+0xD0], xmm14
000079bd661e005e  vmovaps [rsp+0xE0], xmm15
000079bd661e0067  sub rsp, 0x30
000079bd661e006b  movaps [rsp], xmm8
000079bd661e0070  movaps [rsp+0x10], xmm1
000079bd661e0075  movaps [rsp+0x20], xmm14
000079bd661e007b  lea rdi, [rsp]
000079bd661e007f  mov esi, 0x00
000079bd661e0084  mov rax, 0x56EBD57B0530
000079bd661e008e  call rax
000079bd661e0090  movaps xmm8, [rsp]
000079bd661e0095  add rsp, 0x30
000079bd661e0099  vmovaps xmm0, [rsp]
000079bd661e009e  vmovaps xmm1, [rsp+0x10]
000079bd661e00a4  vmovaps xmm2, [rsp+0x20]
000079bd661e00aa  vmovaps xmm3, [rsp+0x30]
000079bd661e00b0  vmovaps xmm4, [rsp+0x40]
000079bd661e00b6  vmovaps xmm5, [rsp+0x50]
000079bd661e00bc  vmovaps xmm6, [rsp+0x60]
000079bd661e00c2  vmovaps xmm7, [rsp+0x70]
000079bd661e00c8  vmovaps xmm9, [rsp+0x80]
000079bd661e00d1  vmovaps xmm10, [rsp+0x90]
000079bd661e00da  vmovaps xmm11, [rsp+0xA0]
000079bd661e00e3  vmovaps xmm12, [rsp+0xB0]
000079bd661e00ec  vmovaps xmm13, [rsp+0xC0]
000079bd661e00f5  vmovaps xmm14, [rsp+0xD0]
000079bd661e00fe  vmovaps xmm15, [rsp+0xE0]
000079bd661e0107  add rsp, 0xF0
000079bd661e010e  pop r11
000079bd661e0110  pop r10
000079bd661e0112  pop r9
000079bd661e0114  pop r8
000079bd661e0116  pop rsi
000079bd661e0117  pop rdi
000079bd661e0118  pop rdx
000079bd661e0119  pop rcx
000079bd661e011a  pop rax
000079bd661e011b  add rsp, 0x08
000079bd661e011f  jmp 0x000079BD661DC561
000079bd661e0124  sub rsp, 0x08
000079bd661e0128  push rax
000079bd661e0129  push rcx
000079bd661e012a  push rdx
000079bd661e012b  push rdi
000079bd661e012c  push rsi
000079bd661e012d  push r8
000079bd661e012f  push r9
000079bd661e0131  push r10
000079bd661e0133  push r11
000079bd661e0135  sub rsp, 0xF0
000079bd661e013c  vmovaps [rsp], xmm0
000079bd661e0141  vmovaps [rsp+0x10], xmm1
000079bd661e0147  vmovaps [rsp+0x20], xmm2
000079bd661e014d  vmovaps [rsp+0x30], xmm3
000079bd661e0153  vmovaps [rsp+0x40], xmm4
000079bd661e0159  vmovaps [rsp+0x50], xmm5
000079bd661e015f  vmovaps [rsp+0x60], xmm7
000079bd661e0165  vmovaps [rsp+0x70], xmm8
000079bd661e016b  vmovaps [rsp+0x80], xmm9
000079bd661e0174  vmovaps [rsp+0x90], xmm10
000079bd661e017d  vmovaps [rsp+0xA0], xmm11
000079bd661e0186  vmovaps [rsp+0xB0], xmm12
000079bd661e018f  vmovaps [rsp+0xC0], xmm13
000079bd661e0198  vmovaps [rsp+0xD0], xmm14
000079bd661e01a1  vmovaps [rsp+0xE0], xmm15
000079bd661e01aa  sub rsp, 0x30
000079bd661e01ae  movaps [rsp], xmm6
000079bd661e01b2  movaps [rsp+0x10], xmm1
000079bd661e01b7  movaps [rsp+0x20], xmm14
000079bd661e01bd  lea rdi, [rsp]
000079bd661e01c1  mov esi, 0x00
000079bd661e01c6  mov rax, 0x56EBD57B0530
000079bd661e01d0  call rax
000079bd661e01d2  movaps xmm6, [rsp]
000079bd661e01d6  add rsp, 0x30
000079bd661e01da  vmovaps xmm0, [rsp]
000079bd661e01df  vmovaps xmm1, [rsp+0x10]
000079bd661e01e5  vmovaps xmm2, [rsp+0x20]
000079bd661e01eb  vmovaps xmm3, [rsp+0x30]
000079bd661e01f1  vmovaps xmm4, [rsp+0x40]
000079bd661e01f7  vmovaps xmm5, [rsp+0x50]
000079bd661e01fd  vmovaps xmm7, [rsp+0x60]
000079bd661e0203  vmovaps xmm8, [rsp+0x70]
000079bd661e0209  vmovaps xmm9, [rsp+0x80]
000079bd661e0212  vmovaps xmm10, [rsp+0x90]
000079bd661e021b  vmovaps xmm11, [rsp+0xA0]
000079bd661e0224  vmovaps xmm12, [rsp+0xB0]
000079bd661e022d  vmovaps xmm13, [rsp+0xC0]
000079bd661e0236  vmovaps xmm14, [rsp+0xD0]
000079bd661e023f  vmovaps xmm15, [rsp+0xE0]
000079bd661e0248  add rsp, 0xF0
000079bd661e024f  pop r11
000079bd661e0251  pop r10
000079bd661e0253  pop r9
000079bd661e0255  pop r8
000079bd661e0257  pop rsi
000079bd661e0258  pop rdi
000079bd661e0259  pop rdx
000079bd661e025a  pop rcx
000079bd661e025b  pop rax
000079bd661e025c  add rsp, 0x08
000079bd661e0260  jmp 0x000079BD661DC58D
000079bd661e0265  sub rsp, 0x08
000079bd661e0269  push rax
000079bd661e026a  push rcx
000079bd661e026b  push rdx
000079bd661e026c  push rdi
000079bd661e026d  push rsi
000079bd661e026e  push r8
000079bd661e0270  push r9
000079bd661e0272  push r10
000079bd661e0274  push r11
000079bd661e0276  sub rsp, 0xF0
000079bd661e027d  vmovaps [rsp], xmm0
000079bd661e0282  vmovaps [rsp+0x10], xmm1
000079bd661e0288  vmovaps [rsp+0x20], xmm2
000079bd661e028e  vmovaps [rsp+0x30], xmm3
000079bd661e0294  vmovaps [rsp+0x40], xmm4
000079bd661e029a  vmovaps [rsp+0x50], xmm5
000079bd661e02a0  vmovaps [rsp+0x60], xmm6
000079bd661e02a6  vmovaps [rsp+0x70], xmm7
000079bd661e02ac  vmovaps [rsp+0x80], xmm8
000079bd661e02b5  vmovaps [rsp+0x90], xmm9
000079bd661e02be  vmovaps [rsp+0xA0], xmm10
000079bd661e02c7  vmovaps [rsp+0xB0], xmm11
000079bd661e02d0  vmovaps [rsp+0xC0], xmm12
000079bd661e02d9  vmovaps [rsp+0xD0], xmm13
000079bd661e02e2  vmovaps [rsp+0xE0], xmm15
000079bd661e02eb  sub rsp, 0x30
000079bd661e02ef  movaps [rsp], xmm14
000079bd661e02f4  movaps [rsp+0x10], xmm12
000079bd661e02fa  movaps [rsp+0x20], xmm1
000079bd661e02ff  lea rdi, [rsp]
000079bd661e0303  mov esi, 0x00
000079bd661e0308  mov rax, 0x56EBD57B0530
000079bd661e0312  call rax
000079bd661e0314  movaps xmm14, [rsp]
000079bd661e0319  add rsp, 0x30
000079bd661e031d  vmovaps xmm0, [rsp]
000079bd661e0322  vmovaps xmm1, [rsp+0x10]
000079bd661e0328  vmovaps xmm2, [rsp+0x20]
000079bd661e032e  vmovaps xmm3, [rsp+0x30]
000079bd661e0334  vmovaps xmm4, [rsp+0x40]
000079bd661e033a  vmovaps xmm5, [rsp+0x50]
000079bd661e0340  vmovaps xmm6, [rsp+0x60]
000079bd661e0346  vmovaps xmm7, [rsp+0x70]
000079bd661e034c  vmovaps xmm8, [rsp+0x80]
000079bd661e0355  vmovaps xmm9, [rsp+0x90]
000079bd661e035e  vmovaps xmm10, [rsp+0xA0]
000079bd661e0367  vmovaps xmm11, [rsp+0xB0]
000079bd661e0370  vmovaps xmm12, [rsp+0xC0]
000079bd661e0379  vmovaps xmm13, [rsp+0xD0]
000079bd661e0382  vmovaps xmm15, [rsp+0xE0]
000079bd661e038b  add rsp, 0xF0
000079bd661e0392  pop r11
000079bd661e0394  pop r10
000079bd661e0396  pop r9
000079bd661e0398  pop r8
000079bd661e039a  pop rsi
000079bd661e039b  pop rdi
000079bd661e039c  pop rdx
000079bd661e039d  pop rcx
000079bd661e039e  pop rax
000079bd661e039f  add rsp, 0x08
000079bd661e03a3  jmp 0x000079BD661DC5B3
000079bd661e03a8  sub rsp, 0x08
000079bd661e03ac  push rax
000079bd661e03ad  push rcx
000079bd661e03ae  push rdx
000079bd661e03af  push rdi
000079bd661e03b0  push rsi
000079bd661e03b1  push r8
000079bd661e03b3  push r9
000079bd661e03b5  push r10
000079bd661e03b7  push r11
000079bd661e03b9  sub rsp, 0xF0
000079bd661e03c0  vmovaps [rsp], xmm0
000079bd661e03c5  vmovaps [rsp+0x10], xmm2
000079bd661e03cb  vmovaps [rsp+0x20], xmm3
000079bd661e03d1  vmovaps [rsp+0x30], xmm4
000079bd661e03d7  vmovaps [rsp+0x40], xmm5
000079bd661e03dd  vmovaps [rsp+0x50], xmm6
000079bd661e03e3  vmovaps [rsp+0x60], xmm7
000079bd661e03e9  vmovaps [rsp+0x70], xmm8
000079bd661e03ef  vmovaps [rsp+0x80], xmm9
000079bd661e03f8  vmovaps [rsp+0x90], xmm10
000079bd661e0401  vmovaps [rsp+0xA0], xmm11
000079bd661e040a  vmovaps [rsp+0xB0], xmm12
000079bd661e0413  vmovaps [rsp+0xC0], xmm13
000079bd661e041c  vmovaps [rsp+0xD0], xmm14
000079bd661e0425  vmovaps [rsp+0xE0], xmm15
000079bd661e042e  sub rsp, 0x30
000079bd661e0432  movaps [rsp], xmm1
000079bd661e0436  movaps [rsp+0x10], xmm13
000079bd661e043c  movaps [rsp+0x20], xmm9
000079bd661e0442  lea rdi, [rsp]
000079bd661e0446  mov esi, 0x00
000079bd661e044b  mov rax, 0x56EBD57B0530
000079bd661e0455  call rax
000079bd661e0457  movaps xmm1, [rsp]
000079bd661e045b  add rsp, 0x30
000079bd661e045f  vmovaps xmm0, [rsp]
000079bd661e0464  vmovaps xmm2, [rsp+0x10]
000079bd661e046a  vmovaps xmm3, [rsp+0x20]
000079bd661e0470  vmovaps xmm4, [rsp+0x30]
000079bd661e0476  vmovaps xmm5, [rsp+0x40]
000079bd661e047c  vmovaps xmm6, [rsp+0x50]
000079bd661e0482  vmovaps xmm7, [rsp+0x60]
000079bd661e0488  vmovaps xmm8, [rsp+0x70]
000079bd661e048e  vmovaps xmm9, [rsp+0x80]
000079bd661e0497  vmovaps xmm10, [rsp+0x90]
000079bd661e04a0  vmovaps xmm11, [rsp+0xA0]
000079bd661e04a9  vmovaps xmm12, [rsp+0xB0]
000079bd661e04b2  vmovaps xmm13, [rsp+0xC0]
000079bd661e04bb  vmovaps xmm14, [rsp+0xD0]
000079bd661e04c4  vmovaps xmm15, [rsp+0xE0]
000079bd661e04cd  add rsp, 0xF0
000079bd661e04d4  pop r11
000079bd661e04d6  pop r10
000079bd661e04d8  pop r9
000079bd661e04da  pop r8
000079bd661e04dc  pop rsi
000079bd661e04dd  pop rdi
000079bd661e04de  pop rdx
000079bd661e04df  pop rcx
000079bd661e04e0  pop rax
000079bd661e04e1  add rsp, 0x08
000079bd661e04e5  jmp 0x000079BD661DC5CD
000079bd661e04ea  sub rsp, 0x08
000079bd661e04ee  push rax
000079bd661e04ef  push rcx
000079bd661e04f0  push rdx
000079bd661e04f1  push rdi
000079bd661e04f2  push rsi
000079bd661e04f3  push r8
000079bd661e04f5  push r9
000079bd661e04f7  push r10
000079bd661e04f9  push r11
000079bd661e04fb  sub rsp, 0xF0
000079bd661e0502  vmovaps [rsp], xmm0
000079bd661e0507  vmovaps [rsp+0x10], xmm1
000079bd661e050d  vmovaps [rsp+0x20], xmm2
000079bd661e0513  vmovaps [rsp+0x30], xmm3
000079bd661e0519  vmovaps [rsp+0x40], xmm4
000079bd661e051f  vmovaps [rsp+0x50], xmm5
000079bd661e0525  vmovaps [rsp+0x60], xmm6
000079bd661e052b  vmovaps [rsp+0x70], xmm7
000079bd661e0531  vmovaps [rsp+0x80], xmm8
000079bd661e053a  vmovaps [rsp+0x90], xmm9
000079bd661e0543  vmovaps [rsp+0xA0], xmm10
000079bd661e054c  vmovaps [rsp+0xB0], xmm11
000079bd661e0555  vmovaps [rsp+0xC0], xmm13
000079bd661e055e  vmovaps [rsp+0xD0], xmm14
000079bd661e0567  vmovaps [rsp+0xE0], xmm15
000079bd661e0570  sub rsp, 0x30
000079bd661e0574  movaps [rsp], xmm12
000079bd661e0579  movaps [rsp+0x10], xmm7
000079bd661e057e  movaps [rsp+0x20], xmm13
000079bd661e0584  lea rdi, [rsp]
000079bd661e0588  mov esi, 0x00
000079bd661e058d  mov rax, 0x56EBD57B0530
000079bd661e0597  call rax
000079bd661e0599  movaps xmm12, [rsp]
000079bd661e059e  add rsp, 0x30
000079bd661e05a2  vmovaps xmm0, [rsp]
000079bd661e05a7  vmovaps xmm1, [rsp+0x10]
000079bd661e05ad  vmovaps xmm2, [rsp+0x20]
000079bd661e05b3  vmovaps xmm3, [rsp+0x30]
000079bd661e05b9  vmovaps xmm4, [rsp+0x40]
000079bd661e05bf  vmovaps xmm5, [rsp+0x50]
000079bd661e05c5  vmovaps xmm6, [rsp+0x60]
000079bd661e05cb  vmovaps xmm7, [rsp+0x70]
000079bd661e05d1  vmovaps xmm8, [rsp+0x80]
000079bd661e05da  vmovaps xmm9, [rsp+0x90]
000079bd661e05e3  vmovaps xmm10, [rsp+0xA0]
000079bd661e05ec  vmovaps xmm11, [rsp+0xB0]
000079bd661e05f5  vmovaps xmm13, [rsp+0xC0]
000079bd661e05fe  vmovaps xmm14, [rsp+0xD0]
000079bd661e0607  vmovaps xmm15, [rsp+0xE0]
000079bd661e0610  add rsp, 0xF0
000079bd661e0617  pop r11
000079bd661e0619  pop r10
000079bd661e061b  pop r9
000079bd661e061d  pop r8
000079bd661e061f  pop rsi
000079bd661e0620  pop rdi
000079bd661e0621  pop rdx
000079bd661e0622  pop rcx
000079bd661e0623  pop rax
000079bd661e0624  add rsp, 0x08
000079bd661e0628  jmp 0x000079BD661DC5F4
000079bd661e062d  sub rsp, 0x08
000079bd661e0631  push rax
000079bd661e0632  push rcx
000079bd661e0633  push rdx
000079bd661e0634  push rdi
000079bd661e0635  push rsi
000079bd661e0636  push r8
000079bd661e0638  push r9
000079bd661e063a  push r10
000079bd661e063c  push r11
000079bd661e063e  sub rsp, 0xF0
000079bd661e0645  vmovaps [rsp], xmm0
000079bd661e064a  vmovaps [rsp+0x10], xmm1
000079bd661e0650  vmovaps [rsp+0x20], xmm2
000079bd661e0656  vmovaps [rsp+0x30], xmm3
000079bd661e065c  vmovaps [rsp+0x40], xmm4
000079bd661e0662  vmovaps [rsp+0x50], xmm5
000079bd661e0668  vmovaps [rsp+0x60], xmm6
000079bd661e066e  vmovaps [rsp+0x70], xmm7
000079bd661e0674  vmovaps [rsp+0x80], xmm8
000079bd661e067d  vmovaps [rsp+0x90], xmm9
000079bd661e0686  vmovaps [rsp+0xA0], xmm10
000079bd661e068f  vmovaps [rsp+0xB0], xmm11
000079bd661e0698  vmovaps [rsp+0xC0], xmm12
000079bd661e06a1  vmovaps [rsp+0xD0], xmm14
000079bd661e06aa  vmovaps [rsp+0xE0], xmm15
000079bd661e06b3  sub rsp, 0x30
000079bd661e06b7  movaps [rsp], xmm13
000079bd661e06bc  movaps [rsp+0x10], xmm15
000079bd661e06c2  movaps [rsp+0x20], xmm8
000079bd661e06c8  lea rdi, [rsp]
000079bd661e06cc  mov esi, 0x00
000079bd661e06d1  mov rax, 0x56EBD57B0530
000079bd661e06db  call rax
000079bd661e06dd  movaps xmm13, [rsp]
000079bd661e06e2  add rsp, 0x30
000079bd661e06e6  vmovaps xmm0, [rsp]
000079bd661e06eb  vmovaps xmm1, [rsp+0x10]
000079bd661e06f1  vmovaps xmm2, [rsp+0x20]
000079bd661e06f7  vmovaps xmm3, [rsp+0x30]
000079bd661e06fd  vmovaps xmm4, [rsp+0x40]
000079bd661e0703  vmovaps xmm5, [rsp+0x50]
000079bd661e0709  vmovaps xmm6, [rsp+0x60]
000079bd661e070f  vmovaps xmm7, [rsp+0x70]
000079bd661e0715  vmovaps xmm8, [rsp+0x80]
000079bd661e071e  vmovaps xmm9, [rsp+0x90]
000079bd661e0727  vmovaps xmm10, [rsp+0xA0]
000079bd661e0730  vmovaps xmm11, [rsp+0xB0]
000079bd661e0739  vmovaps xmm12, [rsp+0xC0]
000079bd661e0742  vmovaps xmm14, [rsp+0xD0]
000079bd661e074b  vmovaps xmm15, [rsp+0xE0]
000079bd661e0754  add rsp, 0xF0
000079bd661e075b  pop r11
000079bd661e075d  pop r10
000079bd661e075f  pop r9
000079bd661e0761  pop r8
000079bd661e0763  pop rsi
000079bd661e0764  pop rdi
000079bd661e0765  pop rdx
000079bd661e0766  pop rcx
000079bd661e0767  pop rax
000079bd661e0768  add rsp, 0x08
000079bd661e076c  jmp 0x000079BD661DC60F
000079bd661e0771  sub rsp, 0x08
000079bd661e0775  push rax
000079bd661e0776  push rcx
000079bd661e0777  push rdx
000079bd661e0778  push rdi
000079bd661e0779  push rsi
000079bd661e077a  push r8
000079bd661e077c  push r9
000079bd661e077e  push r10
000079bd661e0780  push r11
000079bd661e0782  sub rsp, 0xF0
000079bd661e0789  vmovaps [rsp], xmm0
000079bd661e078e  vmovaps [rsp+0x10], xmm1
000079bd661e0794  vmovaps [rsp+0x20], xmm2
000079bd661e079a  vmovaps [rsp+0x30], xmm3
000079bd661e07a0  vmovaps [rsp+0x40], xmm4
000079bd661e07a6  vmovaps [rsp+0x50], xmm5
000079bd661e07ac  vmovaps [rsp+0x60], xmm6
000079bd661e07b2  vmovaps [rsp+0x70], xmm7
000079bd661e07b8  vmovaps [rsp+0x80], xmm9
000079bd661e07c1  vmovaps [rsp+0x90], xmm10
000079bd661e07ca  vmovaps [rsp+0xA0], xmm11
000079bd661e07d3  vmovaps [rsp+0xB0], xmm12
000079bd661e07dc  vmovaps [rsp+0xC0], xmm13
000079bd661e07e5  vmovaps [rsp+0xD0], xmm14
000079bd661e07ee  vmovaps [rsp+0xE0], xmm15
000079bd661e07f7  sub rsp, 0x30
000079bd661e07fb  movaps [rsp], xmm8
000079bd661e0800  movaps [rsp+0x10], xmm15
000079bd661e0806  movaps [rsp+0x20], xmm9
000079bd661e080c  lea rdi, [rsp]
000079bd661e0810  mov esi, 0x00
000079bd661e0815  mov rax, 0x56EBD57B0530
000079bd661e081f  call rax
000079bd661e0821  movaps xmm8, [rsp]
000079bd661e0826  add rsp, 0x30
000079bd661e082a  vmovaps xmm0, [rsp]
000079bd661e082f  vmovaps xmm1, [rsp+0x10]
000079bd661e0835  vmovaps xmm2, [rsp+0x20]
000079bd661e083b  vmovaps xmm3, [rsp+0x30]
000079bd661e0841  vmovaps xmm4, [rsp+0x40]
000079bd661e0847  vmovaps xmm5, [rsp+0x50]
000079bd661e084d  vmovaps xmm6, [rsp+0x60]
000079bd661e0853  vmovaps xmm7, [rsp+0x70]
000079bd661e0859  vmovaps xmm9, [rsp+0x80]
000079bd661e0862  vmovaps xmm10, [rsp+0x90]
000079bd661e086b  vmovaps xmm11, [rsp+0xA0]
000079bd661e0874  vmovaps xmm12, [rsp+0xB0]
000079bd661e087d  vmovaps xmm13, [rsp+0xC0]
000079bd661e0886  vmovaps xmm14, [rsp+0xD0]
000079bd661e088f  vmovaps xmm15, [rsp+0xE0]
000079bd661e0898  add rsp, 0xF0
000079bd661e089f  pop r11
000079bd661e08a1  pop r10
000079bd661e08a3  pop r9
000079bd661e08a5  pop r8
000079bd661e08a7  pop rsi
000079bd661e08a8  pop rdi
000079bd661e08a9  pop rdx
000079bd661e08aa  pop rcx
000079bd661e08ab  pop rax
000079bd661e08ac  add rsp, 0x08
000079bd661e08b0  jmp 0x000079BD661DC63D
000079bd661e08b5  sub rsp, 0x08
000079bd661e08b9  push rax
000079bd661e08ba  push rcx
000079bd661e08bb  push rdx
000079bd661e08bc  push rdi
000079bd661e08bd  push rsi
000079bd661e08be  push r8
000079bd661e08c0  push r9
000079bd661e08c2  push r10
000079bd661e08c4  push r11
000079bd661e08c6  sub rsp, 0xF0
000079bd661e08cd  vmovaps [rsp], xmm0
000079bd661e08d2  vmovaps [rsp+0x10], xmm1
000079bd661e08d8  vmovaps [rsp+0x20], xmm2
000079bd661e08de  vmovaps [rsp+0x30], xmm3
000079bd661e08e4  vmovaps [rsp+0x40], xmm4
000079bd661e08ea  vmovaps [rsp+0x50], xmm5
000079bd661e08f0  vmovaps [rsp+0x60], xmm6
000079bd661e08f6  vmovaps [rsp+0x70], xmm7
000079bd661e08fc  vmovaps [rsp+0x80], xmm8
000079bd661e0905  vmovaps [rsp+0x90], xmm9
000079bd661e090e  vmovaps [rsp+0xA0], xmm10
000079bd661e0917  vmovaps [rsp+0xB0], xmm11
000079bd661e0920  vmovaps [rsp+0xC0], xmm12
000079bd661e0929  vmovaps [rsp+0xD0], xmm13
000079bd661e0932  vmovaps [rsp+0xE0], xmm14
000079bd661e093b  sub rsp, 0x30
000079bd661e093f  movaps [rsp], xmm15
000079bd661e0944  movaps [rsp+0x10], xmm11
000079bd661e094a  movaps [rsp+0x20], xmm6
000079bd661e094f  lea rdi, [rsp]
000079bd661e0953  mov esi, 0x00
000079bd661e0958  mov rax, 0x56EBD57B0530
000079bd661e0962  call rax
000079bd661e0964  movaps xmm15, [rsp]
000079bd661e0969  add rsp, 0x30
000079bd661e096d  vmovaps xmm0, [rsp]
000079bd661e0972  vmovaps xmm1, [rsp+0x10]
000079bd661e0978  vmovaps xmm2, [rsp+0x20]
000079bd661e097e  vmovaps xmm3, [rsp+0x30]
000079bd661e0984  vmovaps xmm4, [rsp+0x40]
000079bd661e098a  vmovaps xmm5, [rsp+0x50]
000079bd661e0990  vmovaps xmm6, [rsp+0x60]
000079bd661e0996  vmovaps xmm7, [rsp+0x70]
000079bd661e099c  vmovaps xmm8, [rsp+0x80]
000079bd661e09a5  vmovaps xmm9, [rsp+0x90]
000079bd661e09ae  vmovaps xmm10, [rsp+0xA0]
000079bd661e09b7  vmovaps xmm11, [rsp+0xB0]
000079bd661e09c0  vmovaps xmm12, [rsp+0xC0]
000079bd661e09c9  vmovaps xmm13, [rsp+0xD0]
000079bd661e09d2  vmovaps xmm14, [rsp+0xE0]
000079bd661e09db  add rsp, 0xF0
000079bd661e09e2  pop r11
000079bd661e09e4  pop r10
000079bd661e09e6  pop r9
000079bd661e09e8  pop r8
000079bd661e09ea  pop rsi
000079bd661e09eb  pop rdi
000079bd661e09ec  pop rdx
000079bd661e09ed  pop rcx
000079bd661e09ee  pop rax
000079bd661e09ef  add rsp, 0x08
000079bd661e09f3  jmp 0x000079BD661DC658
000079bd661e09f8  sub rsp, 0x08
000079bd661e09fc  push rax
000079bd661e09fd  push rcx
000079bd661e09fe  push rdx
000079bd661e09ff  push rdi
000079bd661e0a00  push rsi
000079bd661e0a01  push r8
000079bd661e0a03  push r9
000079bd661e0a05  push r10
000079bd661e0a07  push r11
000079bd661e0a09  sub rsp, 0xF0
000079bd661e0a10  vmovaps [rsp], xmm0
000079bd661e0a15  vmovaps [rsp+0x10], xmm1
000079bd661e0a1b  vmovaps [rsp+0x20], xmm2
000079bd661e0a21  vmovaps [rsp+0x30], xmm3
000079bd661e0a27  vmovaps [rsp+0x40], xmm4
000079bd661e0a2d  vmovaps [rsp+0x50], xmm5
000079bd661e0a33  vmovaps [rsp+0x60], xmm6
000079bd661e0a39  vmovaps [rsp+0x70], xmm8
000079bd661e0a3f  vmovaps [rsp+0x80], xmm9
000079bd661e0a48  vmovaps [rsp+0x90], xmm10
000079bd661e0a51  vmovaps [rsp+0xA0], xmm11
000079bd661e0a5a  vmovaps [rsp+0xB0], xmm12
000079bd661e0a63  vmovaps [rsp+0xC0], xmm13
000079bd661e0a6c  vmovaps [rsp+0xD0], xmm14
000079bd661e0a75  vmovaps [rsp+0xE0], xmm15
000079bd661e0a7e  sub rsp, 0x30
000079bd661e0a82  movaps [rsp], xmm7
000079bd661e0a86  movaps [rsp+0x10], xmm11
000079bd661e0a8c  movaps [rsp+0x20], xmm9
000079bd661e0a92  lea rdi, [rsp]
000079bd661e0a96  mov esi, 0x00
000079bd661e0a9b  mov rax, 0x56EBD57B0530
000079bd661e0aa5  call rax
000079bd661e0aa7  movaps xmm7, [rsp]
000079bd661e0aab  add rsp, 0x30
000079bd661e0aaf  vmovaps xmm0, [rsp]
000079bd661e0ab4  vmovaps xmm1, [rsp+0x10]
000079bd661e0aba  vmovaps xmm2, [rsp+0x20]
000079bd661e0ac0  vmovaps xmm3, [rsp+0x30]
000079bd661e0ac6  vmovaps xmm4, [rsp+0x40]
000079bd661e0acc  vmovaps xmm5, [rsp+0x50]
000079bd661e0ad2  vmovaps xmm6, [rsp+0x60]
000079bd661e0ad8  vmovaps xmm8, [rsp+0x70]
000079bd661e0ade  vmovaps xmm9, [rsp+0x80]
000079bd661e0ae7  vmovaps xmm10, [rsp+0x90]
000079bd661e0af0  vmovaps xmm11, [rsp+0xA0]
000079bd661e0af9  vmovaps xmm12, [rsp+0xB0]
000079bd661e0b02  vmovaps xmm13, [rsp+0xC0]
000079bd661e0b0b  vmovaps xmm14, [rsp+0xD0]
000079bd661e0b14  vmovaps xmm15, [rsp+0xE0]
000079bd661e0b1d  add rsp, 0xF0
000079bd661e0b24  pop r11
000079bd661e0b26  pop r10
000079bd661e0b28  pop r9
000079bd661e0b2a  pop r8
000079bd661e0b2c  pop rsi
000079bd661e0b2d  pop rdi
000079bd661e0b2e  pop rdx
000079bd661e0b2f  pop rcx
000079bd661e0b30  pop rax
000079bd661e0b31  add rsp, 0x08
000079bd661e0b35  jmp 0x000079BD661DC685
000079bd661e0b3a  sub rsp, 0x08
000079bd661e0b3e  push rax
000079bd661e0b3f  push rcx
000079bd661e0b40  push rdx
000079bd661e0b41  push rdi
000079bd661e0b42  push rsi
000079bd661e0b43  push r8
000079bd661e0b45  push r9
000079bd661e0b47  push r10
000079bd661e0b49  push r11
000079bd661e0b4b  sub rsp, 0xF0
000079bd661e0b52  vmovaps [rsp], xmm0
000079bd661e0b57  vmovaps [rsp+0x10], xmm1
000079bd661e0b5d  vmovaps [rsp+0x20], xmm2
000079bd661e0b63  vmovaps [rsp+0x30], xmm3
000079bd661e0b69  vmovaps [rsp+0x40], xmm4
000079bd661e0b6f  vmovaps [rsp+0x50], xmm5
000079bd661e0b75  vmovaps [rsp+0x60], xmm6
000079bd661e0b7b  vmovaps [rsp+0x70], xmm7
000079bd661e0b81  vmovaps [rsp+0x80], xmm8
000079bd661e0b8a  vmovaps [rsp+0x90], xmm9
000079bd661e0b93  vmovaps [rsp+0xA0], xmm10
000079bd661e0b9c  vmovaps [rsp+0xB0], xmm12
000079bd661e0ba5  vmovaps [rsp+0xC0], xmm13
000079bd661e0bae  vmovaps [rsp+0xD0], xmm14
000079bd661e0bb7  vmovaps [rsp+0xE0], xmm15
000079bd661e0bc0  sub rsp, 0x30
000079bd661e0bc4  movaps [rsp], xmm11
000079bd661e0bc9  movaps [rsp+0x10], xmm10
000079bd661e0bcf  movaps [rsp+0x20], xmm14
000079bd661e0bd5  lea rdi, [rsp]
000079bd661e0bd9  mov esi, 0x00
000079bd661e0bde  mov rax, 0x56EBD57B0530
000079bd661e0be8  call rax
000079bd661e0bea  movaps xmm11, [rsp]
000079bd661e0bef  add rsp, 0x30
000079bd661e0bf3  vmovaps xmm0, [rsp]
000079bd661e0bf8  vmovaps xmm1, [rsp+0x10]
000079bd661e0bfe  vmovaps xmm2, [rsp+0x20]
000079bd661e0c04  vmovaps xmm3, [rsp+0x30]
000079bd661e0c0a  vmovaps xmm4, [rsp+0x40]
000079bd661e0c10  vmovaps xmm5, [rsp+0x50]
000079bd661e0c16  vmovaps xmm6, [rsp+0x60]
000079bd661e0c1c  vmovaps xmm7, [rsp+0x70]
000079bd661e0c22  vmovaps xmm8, [rsp+0x80]
000079bd661e0c2b  vmovaps xmm9, [rsp+0x90]
000079bd661e0c34  vmovaps xmm10, [rsp+0xA0]
000079bd661e0c3d  vmovaps xmm12, [rsp+0xB0]
000079bd661e0c46  vmovaps xmm13, [rsp+0xC0]
000079bd661e0c4f  vmovaps xmm14, [rsp+0xD0]
000079bd661e0c58  vmovaps xmm15, [rsp+0xE0]
000079bd661e0c61  add rsp, 0xF0
000079bd661e0c68  pop r11
000079bd661e0c6a  pop r10
000079bd661e0c6c  pop r9
000079bd661e0c6e  pop r8
000079bd661e0c70  pop rsi
000079bd661e0c71  pop rdi
000079bd661e0c72  pop rdx
000079bd661e0c73  pop rcx
000079bd661e0c74  pop rax
000079bd661e0c75  add rsp, 0x08
000079bd661e0c79  jmp 0x000079BD661DC6A0
000079bd661e0c7e  call 0x000079BD660C33A0
000079bd661e0c83  jmp 0x000079BD661DC6AA
000079bd661e0c88  sub rsp, 0x08
000079bd661e0c8c  push rax
000079bd661e0c8d  push rcx
000079bd661e0c8e  push rdx
000079bd661e0c8f  push rdi
000079bd661e0c90  push rsi
000079bd661e0c91  push r8
000079bd661e0c93  push r9
000079bd661e0c95  push r10
000079bd661e0c97  push r11
000079bd661e0c99  sub rsp, 0xF0
000079bd661e0ca0  vmovaps [rsp], xmm0
000079bd661e0ca5  vmovaps [rsp+0x10], xmm1
000079bd661e0cab  vmovaps [rsp+0x20], xmm2
000079bd661e0cb1  vmovaps [rsp+0x30], xmm3
000079bd661e0cb7  vmovaps [rsp+0x40], xmm4
000079bd661e0cbd  vmovaps [rsp+0x50], xmm5
000079bd661e0cc3  vmovaps [rsp+0x60], xmm6
000079bd661e0cc9  vmovaps [rsp+0x70], xmm7
000079bd661e0ccf  vmovaps [rsp+0x80], xmm8
000079bd661e0cd8  vmovaps [rsp+0x90], xmm9
000079bd661e0ce1  vmovaps [rsp+0xA0], xmm11
000079bd661e0cea  vmovaps [rsp+0xB0], xmm12
000079bd661e0cf3  vmovaps [rsp+0xC0], xmm13
000079bd661e0cfc  vmovaps [rsp+0xD0], xmm14
000079bd661e0d05  vmovaps [rsp+0xE0], xmm15
000079bd661e0d0e  sub rsp, 0x30
000079bd661e0d12  movaps [rsp], xmm10
000079bd661e0d17  movaps [rsp+0x10], xmm1
000079bd661e0d1c  movaps [rsp+0x20], xmm12
000079bd661e0d22  lea rdi, [rsp]
000079bd661e0d26  mov esi, 0x00
000079bd661e0d2b  mov rax, 0x56EBD57B0530
000079bd661e0d35  call rax
000079bd661e0d37  movaps xmm10, [rsp]
000079bd661e0d3c  add rsp, 0x30
000079bd661e0d40  vmovaps xmm0, [rsp]
000079bd661e0d45  vmovaps xmm1, [rsp+0x10]
000079bd661e0d4b  vmovaps xmm2, [rsp+0x20]
000079bd661e0d51  vmovaps xmm3, [rsp+0x30]
000079bd661e0d57  vmovaps xmm4, [rsp+0x40]
000079bd661e0d5d  vmovaps xmm5, [rsp+0x50]
000079bd661e0d63  vmovaps xmm6, [rsp+0x60]
000079bd661e0d69  vmovaps xmm7, [rsp+0x70]
000079bd661e0d6f  vmovaps xmm8, [rsp+0x80]
000079bd661e0d78  vmovaps xmm9, [rsp+0x90]
000079bd661e0d81  vmovaps xmm11, [rsp+0xA0]
000079bd661e0d8a  vmovaps xmm12, [rsp+0xB0]
000079bd661e0d93  vmovaps xmm13, [rsp+0xC0]
000079bd661e0d9c  vmovaps xmm14, [rsp+0xD0]
000079bd661e0da5  vmovaps xmm15, [rsp+0xE0]
000079bd661e0dae  add rsp, 0xF0
000079bd661e0db5  pop r11
000079bd661e0db7  pop r10
000079bd661e0db9  pop r9
000079bd661e0dbb  pop r8
000079bd661e0dbd  pop rsi
000079bd661e0dbe  pop rdi
000079bd661e0dbf  pop rdx
000079bd661e0dc0  pop rcx
000079bd661e0dc1  pop rax
000079bd661e0dc2  add rsp, 0x08
000079bd661e0dc6  jmp 0x000079BD661DC6CD
000079bd661e0dcb  sub rsp, 0x08
000079bd661e0dcf  push rax
000079bd661e0dd0  push rcx
000079bd661e0dd1  push rdx
000079bd661e0dd2  push rdi
000079bd661e0dd3  push rsi
000079bd661e0dd4  push r8
000079bd661e0dd6  push r9
000079bd661e0dd8  push r10
000079bd661e0dda  push r11
000079bd661e0ddc  sub rsp, 0xF0
000079bd661e0de3  vmovaps [rsp], xmm0
000079bd661e0de8  vmovaps [rsp+0x10], xmm1
000079bd661e0dee  vmovaps [rsp+0x20], xmm2
000079bd661e0df4  vmovaps [rsp+0x30], xmm3
000079bd661e0dfa  vmovaps [rsp+0x40], xmm4
000079bd661e0e00  vmovaps [rsp+0x50], xmm5
000079bd661e0e06  vmovaps [rsp+0x60], xmm6
000079bd661e0e0c  vmovaps [rsp+0x70], xmm7
000079bd661e0e12  vmovaps [rsp+0x80], xmm8
000079bd661e0e1b  vmovaps [rsp+0x90], xmm9
000079bd661e0e24  vmovaps [rsp+0xA0], xmm10
000079bd661e0e2d  vmovaps [rsp+0xB0], xmm11
000079bd661e0e36  vmovaps [rsp+0xC0], xmm13
000079bd661e0e3f  vmovaps [rsp+0xD0], xmm14
000079bd661e0e48  vmovaps [rsp+0xE0], xmm15
000079bd661e0e51  sub rsp, 0x30
000079bd661e0e55  movaps [rsp], xmm12
000079bd661e0e5a  movaps [rsp+0x10], xmm14
000079bd661e0e60  movaps [rsp+0x20], xmm1
000079bd661e0e65  lea rdi, [rsp]
000079bd661e0e69  mov esi, 0x00
000079bd661e0e6e  mov rax, 0x56EBD57B0530
000079bd661e0e78  call rax
000079bd661e0e7a  movaps xmm12, [rsp]
000079bd661e0e7f  add rsp, 0x30
000079bd661e0e83  vmovaps xmm0, [rsp]
000079bd661e0e88  vmovaps xmm1, [rsp+0x10]
000079bd661e0e8e  vmovaps xmm2, [rsp+0x20]
000079bd661e0e94  vmovaps xmm3, [rsp+0x30]
000079bd661e0e9a  vmovaps xmm4, [rsp+0x40]
000079bd661e0ea0  vmovaps xmm5, [rsp+0x50]
000079bd661e0ea6  vmovaps xmm6, [rsp+0x60]
000079bd661e0eac  vmovaps xmm7, [rsp+0x70]
000079bd661e0eb2  vmovaps xmm8, [rsp+0x80]
000079bd661e0ebb  vmovaps xmm9, [rsp+0x90]
000079bd661e0ec4  vmovaps xmm10, [rsp+0xA0]
000079bd661e0ecd  vmovaps xmm11, [rsp+0xB0]
000079bd661e0ed6  vmovaps xmm13, [rsp+0xC0]
000079bd661e0edf  vmovaps xmm14, [rsp+0xD0]
000079bd661e0ee8  vmovaps xmm15, [rsp+0xE0]
000079bd661e0ef1  add rsp, 0xF0
000079bd661e0ef8  pop r11
000079bd661e0efa  pop r10
000079bd661e0efc  pop r9
000079bd661e0efe  pop r8
000079bd661e0f00  pop rsi
000079bd661e0f01  pop rdi
000079bd661e0f02  pop rdx
000079bd661e0f03  pop rcx
000079bd661e0f04  pop rax
000079bd661e0f05  add rsp, 0x08
000079bd661e0f09  jmp 0x000079BD661DC6FC
000079bd661e0f0e  sub rsp, 0x08
000079bd661e0f12  push rax
000079bd661e0f13  push rcx
000079bd661e0f14  push rdx
000079bd661e0f15  push rdi
000079bd661e0f16  push rsi
000079bd661e0f17  push r8
000079bd661e0f19  push r9
000079bd661e0f1b  push r10
000079bd661e0f1d  push r11
000079bd661e0f1f  sub rsp, 0xF0
000079bd661e0f26  vmovaps [rsp], xmm0
000079bd661e0f2b  vmovaps [rsp+0x10], xmm1
000079bd661e0f31  vmovaps [rsp+0x20], xmm2
000079bd661e0f37  vmovaps [rsp+0x30], xmm3
000079bd661e0f3d  vmovaps [rsp+0x40], xmm4
000079bd661e0f43  vmovaps [rsp+0x50], xmm5
000079bd661e0f49  vmovaps [rsp+0x60], xmm6
000079bd661e0f4f  vmovaps [rsp+0x70], xmm7
000079bd661e0f55  vmovaps [rsp+0x80], xmm8
000079bd661e0f5e  vmovaps [rsp+0x90], xmm9
000079bd661e0f67  vmovaps [rsp+0xA0], xmm10
000079bd661e0f70  vmovaps [rsp+0xB0], xmm11
000079bd661e0f79  vmovaps [rsp+0xC0], xmm12
000079bd661e0f82  vmovaps [rsp+0xD0], xmm13
000079bd661e0f8b  vmovaps [rsp+0xE0], xmm15
000079bd661e0f94  sub rsp, 0x30
000079bd661e0f98  movaps [rsp], xmm14
000079bd661e0f9d  movaps [rsp+0x10], xmm9
000079bd661e0fa3  movaps [rsp+0x20], xmm1
000079bd661e0fa8  lea rdi, [rsp]
000079bd661e0fac  mov esi, 0x00
000079bd661e0fb1  mov rax, 0x56EBD57B0530
000079bd661e0fbb  call rax
000079bd661e0fbd  movaps xmm14, [rsp]
000079bd661e0fc2  add rsp, 0x30
000079bd661e0fc6  vmovaps xmm0, [rsp]
000079bd661e0fcb  vmovaps xmm1, [rsp+0x10]
000079bd661e0fd1  vmovaps xmm2, [rsp+0x20]
000079bd661e0fd7  vmovaps xmm3, [rsp+0x30]
000079bd661e0fdd  vmovaps xmm4, [rsp+0x40]
000079bd661e0fe3  vmovaps xmm5, [rsp+0x50]
000079bd661e0fe9  vmovaps xmm6, [rsp+0x60]
000079bd661e0fef  vmovaps xmm7, [rsp+0x70]
000079bd661e0ff5  vmovaps xmm8, [rsp+0x80]
000079bd661e0ffe  vmovaps xmm9, [rsp+0x90]
000079bd661e1007  vmovaps xmm10, [rsp+0xA0]
000079bd661e1010  vmovaps xmm11, [rsp+0xB0]
000079bd661e1019  vmovaps xmm12, [rsp+0xC0]
000079bd661e1022  vmovaps xmm13, [rsp+0xD0]
000079bd661e102b  vmovaps xmm15, [rsp+0xE0]
000079bd661e1034  add rsp, 0xF0
000079bd661e103b  pop r11
000079bd661e103d  pop r10
000079bd661e103f  pop r9
000079bd661e1041  pop r8
000079bd661e1043  pop rsi
000079bd661e1044  pop rdi
000079bd661e1045  pop rdx
000079bd661e1046  pop rcx
000079bd661e1047  pop rax
000079bd661e1048  add rsp, 0x08
000079bd661e104c  jmp 0x000079BD661DC72B
000079bd661e1051  sub rsp, 0x08
000079bd661e1055  push rax
000079bd661e1056  push rcx
000079bd661e1057  push rdx
000079bd661e1058  push rdi
000079bd661e1059  push rsi
000079bd661e105a  push r8
000079bd661e105c  push r9
000079bd661e105e  push r10
000079bd661e1060  push r11
000079bd661e1062  sub rsp, 0xF0
000079bd661e1069  vmovaps [rsp], xmm0
000079bd661e106e  vmovaps [rsp+0x10], xmm2
000079bd661e1074  vmovaps [rsp+0x20], xmm3
000079bd661e107a  vmovaps [rsp+0x30], xmm4
000079bd661e1080  vmovaps [rsp+0x40], xmm5
000079bd661e1086  vmovaps [rsp+0x50], xmm6
000079bd661e108c  vmovaps [rsp+0x60], xmm7
000079bd661e1092  vmovaps [rsp+0x70], xmm8
000079bd661e1098  vmovaps [rsp+0x80], xmm9
000079bd661e10a1  vmovaps [rsp+0x90], xmm10
000079bd661e10aa  vmovaps [rsp+0xA0], xmm11
000079bd661e10b3  vmovaps [rsp+0xB0], xmm12
000079bd661e10bc  vmovaps [rsp+0xC0], xmm13
000079bd661e10c5  vmovaps [rsp+0xD0], xmm14
000079bd661e10ce  vmovaps [rsp+0xE0], xmm15
000079bd661e10d7  sub rsp, 0x30
000079bd661e10db  movaps [rsp], xmm1
000079bd661e10df  movaps [rsp+0x10], xmm13
000079bd661e10e5  movaps [rsp+0x20], xmm8
000079bd661e10eb  lea rdi, [rsp]
000079bd661e10ef  mov esi, 0x00
000079bd661e10f4  mov rax, 0x56EBD57B0530
000079bd661e10fe  call rax
000079bd661e1100  movaps xmm1, [rsp]
000079bd661e1104  add rsp, 0x30
000079bd661e1108  vmovaps xmm0, [rsp]
000079bd661e110d  vmovaps xmm2, [rsp+0x10]
000079bd661e1113  vmovaps xmm3, [rsp+0x20]
000079bd661e1119  vmovaps xmm4, [rsp+0x30]
000079bd661e111f  vmovaps xmm5, [rsp+0x40]
000079bd661e1125  vmovaps xmm6, [rsp+0x50]
000079bd661e112b  vmovaps xmm7, [rsp+0x60]
000079bd661e1131  vmovaps xmm8, [rsp+0x70]
000079bd661e1137  vmovaps xmm9, [rsp+0x80]
000079bd661e1140  vmovaps xmm10, [rsp+0x90]
000079bd661e1149  vmovaps xmm11, [rsp+0xA0]
000079bd661e1152  vmovaps xmm12, [rsp+0xB0]
000079bd661e115b  vmovaps xmm13, [rsp+0xC0]
000079bd661e1164  vmovaps xmm14, [rsp+0xD0]
000079bd661e116d  vmovaps xmm15, [rsp+0xE0]
000079bd661e1176  add rsp, 0xF0
000079bd661e117d  pop r11
000079bd661e117f  pop r10
000079bd661e1181  pop r9
000079bd661e1183  pop r8
000079bd661e1185  pop rsi
000079bd661e1186  pop rdi
000079bd661e1187  pop rdx
000079bd661e1188  pop rcx
000079bd661e1189  pop rax
000079bd661e118a  add rsp, 0x08
000079bd661e118e  jmp 0x000079BD661DC74D
000079bd661e1193  call 0x000079BD6600C260
000079bd661e1198  jmp 0x000079BD661DC75B
000079bd661e119d  call 0x000079BD660BD750
000079bd661e11a2  jmp 0x000079BD661DC765
000079bd661e11a7  sub rsp, 0x08
000079bd661e11ab  push rax
000079bd661e11ac  push rcx
000079bd661e11ad  push rdx
000079bd661e11ae  push rdi
000079bd661e11af  push rsi
000079bd661e11b0  push r8
000079bd661e11b2  push r9
000079bd661e11b4  push r10
000079bd661e11b6  push r11
000079bd661e11b8  sub rsp, 0xF0
000079bd661e11bf  vmovaps [rsp], xmm0
000079bd661e11c4  vmovaps [rsp+0x10], xmm1
000079bd661e11ca  vmovaps [rsp+0x20], xmm2
000079bd661e11d0  vmovaps [rsp+0x30], xmm3
000079bd661e11d6  vmovaps [rsp+0x40], xmm4
000079bd661e11dc  vmovaps [rsp+0x50], xmm5
000079bd661e11e2  vmovaps [rsp+0x60], xmm6
000079bd661e11e8  vmovaps [rsp+0x70], xmm7
000079bd661e11ee  vmovaps [rsp+0x80], xmm9
000079bd661e11f7  vmovaps [rsp+0x90], xmm10
000079bd661e1200  vmovaps [rsp+0xA0], xmm11
000079bd661e1209  vmovaps [rsp+0xB0], xmm12
000079bd661e1212  vmovaps [rsp+0xC0], xmm13
000079bd661e121b  vmovaps [rsp+0xD0], xmm14
000079bd661e1224  vmovaps [rsp+0xE0], xmm15
000079bd661e122d  sub rsp, 0x30
000079bd661e1231  movaps [rsp], xmm8
000079bd661e1236  movaps [rsp+0x10], xmm15
000079bd661e123c  movaps [rsp+0x20], xmm7
000079bd661e1241  lea rdi, [rsp]
000079bd661e1245  mov esi, 0x00
000079bd661e124a  mov rax, 0x56EBD57B0530
000079bd661e1254  call rax
000079bd661e1256  movaps xmm8, [rsp]
000079bd661e125b  add rsp, 0x30
000079bd661e125f  vmovaps xmm0, [rsp]
000079bd661e1264  vmovaps xmm1, [rsp+0x10]
000079bd661e126a  vmovaps xmm2, [rsp+0x20]
000079bd661e1270  vmovaps xmm3, [rsp+0x30]
000079bd661e1276  vmovaps xmm4, [rsp+0x40]
000079bd661e127c  vmovaps xmm5, [rsp+0x50]
000079bd661e1282  vmovaps xmm6, [rsp+0x60]
000079bd661e1288  vmovaps xmm7, [rsp+0x70]
000079bd661e128e  vmovaps xmm9, [rsp+0x80]
000079bd661e1297  vmovaps xmm10, [rsp+0x90]
000079bd661e12a0  vmovaps xmm11, [rsp+0xA0]
000079bd661e12a9  vmovaps xmm12, [rsp+0xB0]
000079bd661e12b2  vmovaps xmm13, [rsp+0xC0]
000079bd661e12bb  vmovaps xmm14, [rsp+0xD0]
000079bd661e12c4  vmovaps xmm15, [rsp+0xE0]
000079bd661e12cd  add rsp, 0xF0
000079bd661e12d4  pop r11
000079bd661e12d6  pop r10
000079bd661e12d8  pop r9
000079bd661e12da  pop r8
000079bd661e12dc  pop rsi
000079bd661e12dd  pop rdi
000079bd661e12de  pop rdx
000079bd661e12df  pop rcx
000079bd661e12e0  pop rax
000079bd661e12e1  add rsp, 0x08
000079bd661e12e5  jmp 0x000079BD661DC787
000079bd661e12ea  sub rsp, 0x08
000079bd661e12ee  push rax
000079bd661e12ef  push rcx
000079bd661e12f0  push rdx
000079bd661e12f1  push rdi
000079bd661e12f2  push rsi
000079bd661e12f3  push r8
000079bd661e12f5  push r9
000079bd661e12f7  push r10
000079bd661e12f9  push r11
000079bd661e12fb  sub rsp, 0xF0
000079bd661e1302  vmovaps [rsp], xmm0
000079bd661e1307  vmovaps [rsp+0x10], xmm1
000079bd661e130d  vmovaps [rsp+0x20], xmm2
000079bd661e1313  vmovaps [rsp+0x30], xmm3
000079bd661e1319  vmovaps [rsp+0x40], xmm4
000079bd661e131f  vmovaps [rsp+0x50], xmm5
000079bd661e1325  vmovaps [rsp+0x60], xmm6
000079bd661e132b  vmovaps [rsp+0x70], xmm8
000079bd661e1331  vmovaps [rsp+0x80], xmm9
000079bd661e133a  vmovaps [rsp+0x90], xmm10
000079bd661e1343  vmovaps [rsp+0xA0], xmm11
000079bd661e134c  vmovaps [rsp+0xB0], xmm12
000079bd661e1355  vmovaps [rsp+0xC0], xmm13
000079bd661e135e  vmovaps [rsp+0xD0], xmm14
000079bd661e1367  vmovaps [rsp+0xE0], xmm15
000079bd661e1370  sub rsp, 0x30
000079bd661e1374  movaps [rsp], xmm7
000079bd661e1378  movaps [rsp+0x10], xmm9
000079bd661e137e  movaps [rsp+0x20], xmm15
000079bd661e1384  lea rdi, [rsp]
000079bd661e1388  mov esi, 0x00
000079bd661e138d  mov rax, 0x56EBD57B0530
000079bd661e1397  call rax
000079bd661e1399  movaps xmm7, [rsp]
000079bd661e139d  add rsp, 0x30
000079bd661e13a1  vmovaps xmm0, [rsp]
000079bd661e13a6  vmovaps xmm1, [rsp+0x10]
000079bd661e13ac  vmovaps xmm2, [rsp+0x20]
000079bd661e13b2  vmovaps xmm3, [rsp+0x30]
000079bd661e13b8  vmovaps xmm4, [rsp+0x40]
000079bd661e13be  vmovaps xmm5, [rsp+0x50]
000079bd661e13c4  vmovaps xmm6, [rsp+0x60]
000079bd661e13ca  vmovaps xmm8, [rsp+0x70]
000079bd661e13d0  vmovaps xmm9, [rsp+0x80]
000079bd661e13d9  vmovaps xmm10, [rsp+0x90]
000079bd661e13e2  vmovaps xmm11, [rsp+0xA0]
000079bd661e13eb  vmovaps xmm12, [rsp+0xB0]
000079bd661e13f4  vmovaps xmm13, [rsp+0xC0]
000079bd661e13fd  vmovaps xmm14, [rsp+0xD0]
000079bd661e1406  vmovaps xmm15, [rsp+0xE0]
000079bd661e140f  add rsp, 0xF0
000079bd661e1416  pop r11
000079bd661e1418  pop r10
000079bd661e141a  pop r9
000079bd661e141c  pop r8
000079bd661e141e  pop rsi
000079bd661e141f  pop rdi
000079bd661e1420  pop rdx
000079bd661e1421  pop rcx
000079bd661e1422  pop rax
000079bd661e1423  add rsp, 0x08
000079bd661e1427  jmp 0x000079BD661DC7B4
000079bd661e142c  sub rsp, 0x08
000079bd661e1430  push rax
000079bd661e1431  push rcx
000079bd661e1432  push rdx
000079bd661e1433  push rdi
000079bd661e1434  push rsi
000079bd661e1435  push r8
000079bd661e1437  push r9
000079bd661e1439  push r10
000079bd661e143b  push r11
000079bd661e143d  sub rsp, 0xF0
000079bd661e1444  vmovaps [rsp], xmm0
000079bd661e1449  vmovaps [rsp+0x10], xmm1
000079bd661e144f  vmovaps [rsp+0x20], xmm2
000079bd661e1455  vmovaps [rsp+0x30], xmm3
000079bd661e145b  vmovaps [rsp+0x40], xmm4
000079bd661e1461  vmovaps [rsp+0x50], xmm5
000079bd661e1467  vmovaps [rsp+0x60], xmm6
000079bd661e146d  vmovaps [rsp+0x70], xmm7
000079bd661e1473  vmovaps [rsp+0x80], xmm8
000079bd661e147c  vmovaps [rsp+0x90], xmm10
000079bd661e1485  vmovaps [rsp+0xA0], xmm11
000079bd661e148e  vmovaps [rsp+0xB0], xmm12
000079bd661e1497  vmovaps [rsp+0xC0], xmm13
000079bd661e14a0  vmovaps [rsp+0xD0], xmm14
000079bd661e14a9  vmovaps [rsp+0xE0], xmm15
000079bd661e14b2  sub rsp, 0x30
000079bd661e14b6  movaps [rsp], xmm9
000079bd661e14bb  movaps [rsp+0x10], xmm13
000079bd661e14c1  movaps [rsp+0x20], xmm15
000079bd661e14c7  lea rdi, [rsp]
000079bd661e14cb  mov esi, 0x00
000079bd661e14d0  mov rax, 0x56EBD57B0530
000079bd661e14da  call rax
000079bd661e14dc  movaps xmm9, [rsp]
000079bd661e14e1  add rsp, 0x30
000079bd661e14e5  vmovaps xmm0, [rsp]
000079bd661e14ea  vmovaps xmm1, [rsp+0x10]
000079bd661e14f0  vmovaps xmm2, [rsp+0x20]
000079bd661e14f6  vmovaps xmm3, [rsp+0x30]
000079bd661e14fc  vmovaps xmm4, [rsp+0x40]
000079bd661e1502  vmovaps xmm5, [rsp+0x50]
000079bd661e1508  vmovaps xmm6, [rsp+0x60]
000079bd661e150e  vmovaps xmm7, [rsp+0x70]
000079bd661e1514  vmovaps xmm8, [rsp+0x80]
000079bd661e151d  vmovaps xmm10, [rsp+0x90]
000079bd661e1526  vmovaps xmm11, [rsp+0xA0]
000079bd661e152f  vmovaps xmm12, [rsp+0xB0]
000079bd661e1538  vmovaps xmm13, [rsp+0xC0]
000079bd661e1541  vmovaps xmm14, [rsp+0xD0]
000079bd661e154a  vmovaps xmm15, [rsp+0xE0]
000079bd661e1553  add rsp, 0xF0
000079bd661e155a  pop r11
000079bd661e155c  pop r10
000079bd661e155e  pop r9
000079bd661e1560  pop r8
000079bd661e1562  pop rsi
000079bd661e1563  pop rdi
000079bd661e1564  pop rdx
000079bd661e1565  pop rcx
000079bd661e1566  pop rax
000079bd661e1567  add rsp, 0x08
000079bd661e156b  jmp 0x000079BD661DC7E2
000079bd661e1570  sub rsp, 0x08
000079bd661e1574  push rax
000079bd661e1575  push rcx
000079bd661e1576  push rdx
000079bd661e1577  push rdi
000079bd661e1578  push rsi
000079bd661e1579  push r8
000079bd661e157b  push r9
000079bd661e157d  push r10
000079bd661e157f  push r11
000079bd661e1581  sub rsp, 0xF0
000079bd661e1588  vmovaps [rsp], xmm0
000079bd661e158d  vmovaps [rsp+0x10], xmm1
000079bd661e1593  vmovaps [rsp+0x20], xmm2
000079bd661e1599  vmovaps [rsp+0x30], xmm3
000079bd661e159f  vmovaps [rsp+0x40], xmm4
000079bd661e15a5  vmovaps [rsp+0x50], xmm5
000079bd661e15ab  vmovaps [rsp+0x60], xmm6
000079bd661e15b1  vmovaps [rsp+0x70], xmm7
000079bd661e15b7  vmovaps [rsp+0x80], xmm8
000079bd661e15c0  vmovaps [rsp+0x90], xmm9
000079bd661e15c9  vmovaps [rsp+0xA0], xmm10
000079bd661e15d2  vmovaps [rsp+0xB0], xmm11
000079bd661e15db  vmovaps [rsp+0xC0], xmm12
000079bd661e15e4  vmovaps [rsp+0xD0], xmm13
000079bd661e15ed  vmovaps [rsp+0xE0], xmm14
000079bd661e15f6  sub rsp, 0x30
000079bd661e15fa  movaps [rsp], xmm15
000079bd661e15ff  movaps [rsp+0x10], xmm11
000079bd661e1605  movaps [rsp+0x20], xmm12
000079bd661e160b  lea rdi, [rsp]
000079bd661e160f  mov esi, 0x00
000079bd661e1614  mov rax, 0x56EBD57B0530
000079bd661e161e  call rax
000079bd661e1620  movaps xmm15, [rsp]
000079bd661e1625  add rsp, 0x30
000079bd661e1629  vmovaps xmm0, [rsp]
000079bd661e162e  vmovaps xmm1, [rsp+0x10]
000079bd661e1634  vmovaps xmm2, [rsp+0x20]
000079bd661e163a  vmovaps xmm3, [rsp+0x30]
000079bd661e1640  vmovaps xmm4, [rsp+0x40]
000079bd661e1646  vmovaps xmm5, [rsp+0x50]
000079bd661e164c  vmovaps xmm6, [rsp+0x60]
000079bd661e1652  vmovaps xmm7, [rsp+0x70]
000079bd661e1658  vmovaps xmm8, [rsp+0x80]
000079bd661e1661  vmovaps xmm9, [rsp+0x90]
000079bd661e166a  vmovaps xmm10, [rsp+0xA0]
000079bd661e1673  vmovaps xmm11, [rsp+0xB0]
000079bd661e167c  vmovaps xmm12, [rsp+0xC0]
000079bd661e1685  vmovaps xmm13, [rsp+0xD0]
000079bd661e168e  vmovaps xmm14, [rsp+0xE0]
000079bd661e1697  add rsp, 0xF0
000079bd661e169e  pop r11
000079bd661e16a0  pop r10
000079bd661e16a2  pop r9
000079bd661e16a4  pop r8
000079bd661e16a6  pop rsi
000079bd661e16a7  pop rdi
000079bd661e16a8  pop rdx
000079bd661e16a9  pop rcx
000079bd661e16aa  pop rax
000079bd661e16ab  add rsp, 0x08
000079bd661e16af  jmp 0x000079BD661DC7FD
000079bd661e16b4  sub rsp, 0x08
000079bd661e16b8  push rax
000079bd661e16b9  push rcx
000079bd661e16ba  push rdx
000079bd661e16bb  push rdi
000079bd661e16bc  push rsi
000079bd661e16bd  push r8
000079bd661e16bf  push r9
000079bd661e16c1  push r10
000079bd661e16c3  push r11
000079bd661e16c5  sub rsp, 0xF0
000079bd661e16cc  vmovaps [rsp], xmm0
000079bd661e16d1  vmovaps [rsp+0x10], xmm1
000079bd661e16d7  vmovaps [rsp+0x20], xmm2
000079bd661e16dd  vmovaps [rsp+0x30], xmm3
000079bd661e16e3  vmovaps [rsp+0x40], xmm4
000079bd661e16e9  vmovaps [rsp+0x50], xmm5
000079bd661e16ef  vmovaps [rsp+0x60], xmm6
000079bd661e16f5  vmovaps [rsp+0x70], xmm7
000079bd661e16fb  vmovaps [rsp+0x80], xmm8
000079bd661e1704  vmovaps [rsp+0x90], xmm9
000079bd661e170d  vmovaps [rsp+0xA0], xmm10
000079bd661e1716  vmovaps [rsp+0xB0], xmm11
000079bd661e171f  vmovaps [rsp+0xC0], xmm12
000079bd661e1728  vmovaps [rsp+0xD0], xmm14
000079bd661e1731  vmovaps [rsp+0xE0], xmm15
000079bd661e173a  sub rsp, 0x30
000079bd661e173e  movaps [rsp], xmm13
000079bd661e1743  movaps [rsp+0x10], xmm10
000079bd661e1749  movaps [rsp+0x20], xmm14
000079bd661e174f  lea rdi, [rsp]
000079bd661e1753  mov esi, 0x00
000079bd661e1758  mov rax, 0x56EBD57B0530
000079bd661e1762  call rax
000079bd661e1764  movaps xmm13, [rsp]
000079bd661e1769  add rsp, 0x30
000079bd661e176d  vmovaps xmm0, [rsp]
000079bd661e1772  vmovaps xmm1, [rsp+0x10]
000079bd661e1778  vmovaps xmm2, [rsp+0x20]
000079bd661e177e  vmovaps xmm3, [rsp+0x30]
000079bd661e1784  vmovaps xmm4, [rsp+0x40]
000079bd661e178a  vmovaps xmm5, [rsp+0x50]
000079bd661e1790  vmovaps xmm6, [rsp+0x60]
000079bd661e1796  vmovaps xmm7, [rsp+0x70]
000079bd661e179c  vmovaps xmm8, [rsp+0x80]
000079bd661e17a5  vmovaps xmm9, [rsp+0x90]
000079bd661e17ae  vmovaps xmm10, [rsp+0xA0]
000079bd661e17b7  vmovaps xmm11, [rsp+0xB0]
000079bd661e17c0  vmovaps xmm12, [rsp+0xC0]
000079bd661e17c9  vmovaps xmm14, [rsp+0xD0]
000079bd661e17d2  vmovaps xmm15, [rsp+0xE0]
000079bd661e17db  add rsp, 0xF0
000079bd661e17e2  pop r11
000079bd661e17e4  pop r10
000079bd661e17e6  pop r9
000079bd661e17e8  pop r8
000079bd661e17ea  pop rsi
000079bd661e17eb  pop rdi
000079bd661e17ec  pop rdx
000079bd661e17ed  pop rcx
000079bd661e17ee  pop rax
000079bd661e17ef  add rsp, 0x08
000079bd661e17f3  jmp 0x000079BD661DC820
000079bd661e17f8  sub rsp, 0x08
000079bd661e17fc  push rax
000079bd661e17fd  push rcx
000079bd661e17fe  push rdx
000079bd661e17ff  push rdi
000079bd661e1800  push rsi
000079bd661e1801  push r8
000079bd661e1803  push r9
000079bd661e1805  push r10
000079bd661e1807  push r11
000079bd661e1809  sub rsp, 0xF0
000079bd661e1810  vmovaps [rsp], xmm0
000079bd661e1815  vmovaps [rsp+0x10], xmm1
000079bd661e181b  vmovaps [rsp+0x20], xmm2
000079bd661e1821  vmovaps [rsp+0x30], xmm3
000079bd661e1827  vmovaps [rsp+0x40], xmm4
000079bd661e182d  vmovaps [rsp+0x50], xmm5
000079bd661e1833  vmovaps [rsp+0x60], xmm6
000079bd661e1839  vmovaps [rsp+0x70], xmm7
000079bd661e183f  vmovaps [rsp+0x80], xmm8
000079bd661e1848  vmovaps [rsp+0x90], xmm9
000079bd661e1851  vmovaps [rsp+0xA0], xmm10
000079bd661e185a  vmovaps [rsp+0xB0], xmm11
000079bd661e1863  vmovaps [rsp+0xC0], xmm12
000079bd661e186c  vmovaps [rsp+0xD0], xmm13
000079bd661e1875  vmovaps [rsp+0xE0], xmm15
000079bd661e187e  sub rsp, 0x30
000079bd661e1882  movaps [rsp], xmm14
000079bd661e1887  movaps [rsp+0x10], xmm1
000079bd661e188c  movaps [rsp+0x20], xmm7
000079bd661e1891  lea rdi, [rsp]
000079bd661e1895  mov esi, 0x00
000079bd661e189a  mov rax, 0x56EBD57B0530
000079bd661e18a4  call rax
000079bd661e18a6  movaps xmm14, [rsp]
000079bd661e18ab  add rsp, 0x30
000079bd661e18af  vmovaps xmm0, [rsp]
000079bd661e18b4  vmovaps xmm1, [rsp+0x10]
000079bd661e18ba  vmovaps xmm2, [rsp+0x20]
000079bd661e18c0  vmovaps xmm3, [rsp+0x30]
000079bd661e18c6  vmovaps xmm4, [rsp+0x40]
000079bd661e18cc  vmovaps xmm5, [rsp+0x50]
000079bd661e18d2  vmovaps xmm6, [rsp+0x60]
000079bd661e18d8  vmovaps xmm7, [rsp+0x70]
000079bd661e18de  vmovaps xmm8, [rsp+0x80]
000079bd661e18e7  vmovaps xmm9, [rsp+0x90]
000079bd661e18f0  vmovaps xmm10, [rsp+0xA0]
000079bd661e18f9  vmovaps xmm11, [rsp+0xB0]
000079bd661e1902  vmovaps xmm12, [rsp+0xC0]
000079bd661e190b  vmovaps xmm13, [rsp+0xD0]
000079bd661e1914  vmovaps xmm15, [rsp+0xE0]
000079bd661e191d  add rsp, 0xF0
000079bd661e1924  pop r11
000079bd661e1926  pop r10
000079bd661e1928  pop r9
000079bd661e192a  pop r8
000079bd661e192c  pop rsi
000079bd661e192d  pop rdi
000079bd661e192e  pop rdx
000079bd661e192f  pop rcx
000079bd661e1930  pop rax
000079bd661e1931  add rsp, 0x08
000079bd661e1935  jmp 0x000079BD661DC843
000079bd661e193a  sub rsp, 0x08
000079bd661e193e  push rax
000079bd661e193f  push rcx
000079bd661e1940  push rdx
000079bd661e1941  push rdi
000079bd661e1942  push rsi
000079bd661e1943  push r8
000079bd661e1945  push r9
000079bd661e1947  push r10
000079bd661e1949  push r11
000079bd661e194b  sub rsp, 0xF0
000079bd661e1952  vmovaps [rsp], xmm0
000079bd661e1957  vmovaps [rsp+0x10], xmm2
000079bd661e195d  vmovaps [rsp+0x20], xmm3
000079bd661e1963  vmovaps [rsp+0x30], xmm4
000079bd661e1969  vmovaps [rsp+0x40], xmm5
000079bd661e196f  vmovaps [rsp+0x50], xmm6
000079bd661e1975  vmovaps [rsp+0x60], xmm7
000079bd661e197b  vmovaps [rsp+0x70], xmm8
000079bd661e1981  vmovaps [rsp+0x80], xmm9
000079bd661e198a  vmovaps [rsp+0x90], xmm10
000079bd661e1993  vmovaps [rsp+0xA0], xmm11
000079bd661e199c  vmovaps [rsp+0xB0], xmm12
000079bd661e19a5  vmovaps [rsp+0xC0], xmm13
000079bd661e19ae  vmovaps [rsp+0xD0], xmm14
000079bd661e19b7  vmovaps [rsp+0xE0], xmm15
000079bd661e19c0  sub rsp, 0x30
000079bd661e19c4  movaps [rsp], xmm1
000079bd661e19c8  movaps [rsp+0x10], xmm8
000079bd661e19ce  movaps [rsp+0x20], xmm9
000079bd661e19d4  lea rdi, [rsp]
000079bd661e19d8  mov esi, 0x00
000079bd661e19dd  mov rax, 0x56EBD57B0530
000079bd661e19e7  call rax
000079bd661e19e9  movaps xmm1, [rsp]
000079bd661e19ed  add rsp, 0x30
000079bd661e19f1  vmovaps xmm0, [rsp]
000079bd661e19f6  vmovaps xmm2, [rsp+0x10]
000079bd661e19fc  vmovaps xmm3, [rsp+0x20]
000079bd661e1a02  vmovaps xmm4, [rsp+0x30]
000079bd661e1a08  vmovaps xmm5, [rsp+0x40]
000079bd661e1a0e  vmovaps xmm6, [rsp+0x50]
000079bd661e1a14  vmovaps xmm7, [rsp+0x60]
000079bd661e1a1a  vmovaps xmm8, [rsp+0x70]
000079bd661e1a20  vmovaps xmm9, [rsp+0x80]
000079bd661e1a29  vmovaps xmm10, [rsp+0x90]
000079bd661e1a32  vmovaps xmm11, [rsp+0xA0]
000079bd661e1a3b  vmovaps xmm12, [rsp+0xB0]
000079bd661e1a44  vmovaps xmm13, [rsp+0xC0]
000079bd661e1a4d  vmovaps xmm14, [rsp+0xD0]
000079bd661e1a56  vmovaps xmm15, [rsp+0xE0]
000079bd661e1a5f  add rsp, 0xF0
000079bd661e1a66  pop r11
000079bd661e1a68  pop r10
000079bd661e1a6a  pop r9
000079bd661e1a6c  pop r8
000079bd661e1a6e  pop rsi
000079bd661e1a6f  pop rdi
000079bd661e1a70  pop rdx
000079bd661e1a71  pop rcx
000079bd661e1a72  pop rax
000079bd661e1a73  add rsp, 0x08
000079bd661e1a77  jmp 0x000079BD661DC865
000079bd661e1a7c  call 0x000079BD660E5940
000079bd661e1a81  jmp 0x000079BD661DC873
000079bd661e1a86  call 0x000079BD6600C380
000079bd661e1a8b  jmp 0x000079BD661DC87D
000079bd661e1a90  call 0x000079BD6600D600
000079bd661e1a95  jmp 0x000079BD661DC887
000079bd661e1a9a  call 0x000079BD65FFF540
000079bd661e1a9f  jmp 0x000079BD661DC891
000079bd661e1aa4  int3
000079bd661e1aa5  nop [rax+rax*1], ax
000079bd661e1aae  nop
000079bd661e1ab0  mov rax, [r15+0xF8]
000079bd661e1ab7  lea r14, [rax+0x140]
000079bd661e1abe  mov r12, [r13+r14*1]
000079bd661e1ac3  mov [r15+0xE8], r12
000079bd661e1aca  lea r14, [rax+0x130]
000079bd661e1ad1  mov r12, [r13+r14*1]
000079bd661e1ad6  lea r14, [rax+0x138]
000079bd661e1add  mov r11, [r13+r14*1]
000079bd661e1ae2  movq xmm1, r12
000079bd661e1ae7  movq xmm15, r11
000079bd661e1aec  movq xmm1, xmm1
000079bd661e1af0  movq xmm1, xmm1
000079bd661e1af4  movaps [r15+0x1A0], xmm1
000079bd661e1afc  movq xmm15, xmm15
000079bd661e1b01  movq xmm15, xmm15
000079bd661e1b06  movaps [r15+0x190], xmm15
000079bd661e1b0e  lea r14, [rax+0x120]
000079bd661e1b15  mov r12, [r13+r14*1]
000079bd661e1b1a  lea r14, [rax+0x128]
000079bd661e1b21  mov r11, [r13+r14*1]
000079bd661e1b26  movq xmm1, r12
000079bd661e1b2b  movq xmm15, r11
000079bd661e1b30  movq xmm1, xmm1
000079bd661e1b34  movq xmm1, xmm1
000079bd661e1b38  movaps [r15+0x1C0], xmm1
000079bd661e1b40  movq xmm15, xmm15
000079bd661e1b45  movq xmm15, xmm15
000079bd661e1b4a  movaps [r15+0x1B0], xmm15
000079bd661e1b52  lea r14, [rax+0x110]
000079bd661e1b59  mov r12, [r13+r14*1]
000079bd661e1b5e  lea r14, [rax+0x118]
000079bd661e1b65  mov r11, [r13+r14*1]
000079bd661e1b6a  movq xmm1, r12
000079bd661e1b6f  movq xmm15, r11
000079bd661e1b74  movq xmm1, xmm1
000079bd661e1b78  movq xmm1, xmm1
000079bd661e1b7c  movaps [r15+0x1E0], xmm1
000079bd661e1b84  movq xmm15, xmm15
000079bd661e1b89  movq xmm15, xmm15
000079bd661e1b8e  movaps [r15+0x1D0], xmm15
000079bd661e1b96  lea r14, [rax+0x100]
000079bd661e1b9d  mov r12, [r13+r14*1]
000079bd661e1ba2  lea r14, [rax+0x108]
000079bd661e1ba9  mov r11, [r13+r14*1]
000079bd661e1bae  movq xmm1, r12
000079bd661e1bb3  movq xmm15, r11
000079bd661e1bb8  movq xmm1, xmm1
000079bd661e1bbc  movq xmm1, xmm1
000079bd661e1bc0  movaps [r15+0x200], xmm1
000079bd661e1bc8  movq xmm15, xmm15
000079bd661e1bcd  movq xmm15, xmm15
000079bd661e1bd2  movaps [r15+0x1F0], xmm15
000079bd661e1bda  mov qword ptr [r15+0x40], 0x430000
000079bd661e1be2  mov r14d, 0x430510
000079bd661e1be8  mov r12, [r13+r14*1]
000079bd661e1bed  movq xmm1, r12
000079bd661e1bf2  lea r14, [rax+0x150]
000079bd661e1bf9  mov [r15+0xF8], r14
000079bd661e1c00  mov rax, [r15+0x50]
000079bd661e1c04  movups xmm15, [r13+rax*1]
000079bd661e1c0a  movaps [r15+0x120], xmm15
000079bd661e1c12  mov qword ptr [r15+0x48], 0x10
000079bd661e1c1a  xor eax, eax
000079bd661e1c1c  mov r14d, 0x10
000079bd661e1c22  mov r12d, 0x200
000079bd661e1c28  cmp r14, r12
000079bd661e1c2b  cmc
000079bd661e1c2c  lahf
000079bd661e1c2d  seto al
000079bd661e1c30  mov [r15+0x108], eax
000079bd661e1c37  pextrq rax, xmm15, 0x01
000079bd661e1c3e  movq xmm14, rax
000079bd661e1c43  movaps [r15+0x130], xmm14
000079bd661e1c4b  movq rax, xmm1
000079bd661e1c50  movq r14, xmm15
000079bd661e1c55  vmovq xmm1, rax
000079bd661e1c5a  vmovq xmm15, r14
000079bd661e1c5f  movaps xmm13, xmm1
000079bd661e1c63  addsd xmm13, xmm15
000079bd661e1c68  ucomisd xmm13, xmm13
000079bd661e1c6d  jp 0x000079BD661E1D86
000079bd661e1c73  movq xmm13, xmm13
000079bd661e1c78  movq rax, xmm13
000079bd661e1c7d  movq r14, xmm14
000079bd661e1c82  vmovq xmm1, rax
000079bd661e1c87  vmovq xmm15, r14
000079bd661e1c8c  movaps xmm14, xmm1
000079bd661e1c90  addsd xmm14, xmm15
000079bd661e1c95  ucomisd xmm14, xmm14
000079bd661e1c9a  jp 0x000079BD661E1DCE
000079bd661e1ca0  movq xmm14, xmm14
000079bd661e1ca5  movaps [r15+0x110], xmm14
000079bd661e1cad  mov eax, [r15+0x108]
000079bd661e1cb4  sahf
000079bd661e1cb5  jnz 0x000079BD661E1CE7
000079bd661e1cb7  cmp dword ptr [r15+0x318], 0x00
000079bd661e1cbf  jz 0x000079BD661E1FE0
000079bd661e1cc5  nop [rax+rax*1], ax
000079bd661e1cce  nop [rax+rax*1], eax
000079bd661e1cd6  mov eax, 0x410490
000079bd661e1cdb  mov [r15+0x100], rax
000079bd661e1ce2  jmp 0x000079BD65FFE110
000079bd661e1ce7  cmp dword ptr [r15+0x318], 0x00
000079bd661e1cef  jz 0x000079BD661E1E20
000079bd661e1cf5  nop [rax+rax*1], ax
000079bd661e1cfe  nop [rax+rax*1], eax
000079bd661e1d06  mov eax, 0x410474
000079bd661e1d0b  mov [r15+0x100], rax
000079bd661e1d12  jmp 0x000079BD65FFE110
000079bd661e1d17  int3
000079bd661e1d18  call 0x000079BD660E27E0
000079bd661e1d1d  jmp 0x000079BD661E1AC3
000079bd661e1d22  call 0x000079BD660E27E0
000079bd661e1d27  jmp 0x000079BD661E1AD6
000079bd661e1d2c  call 0x000079BD660E1570
000079bd661e1d31  jmp 0x000079BD661E1AE2
000079bd661e1d36  call 0x000079BD660E27E0
000079bd661e1d3b  jmp 0x000079BD661E1B1A
000079bd661e1d40  call 0x000079BD660E1570
000079bd661e1d45  jmp 0x000079BD661E1B26
000079bd661e1d4a  call 0x000079BD660E27E0
000079bd661e1d4f  jmp 0x000079BD661E1B5E
000079bd661e1d54  call 0x000079BD660E1570
000079bd661e1d59  jmp 0x000079BD661E1B6A
000079bd661e1d5e  call 0x000079BD660E27E0
000079bd661e1d63  jmp 0x000079BD661E1BA2
000079bd661e1d68  call 0x000079BD660E1570
000079bd661e1d6d  jmp 0x000079BD661E1BAE
000079bd661e1d72  call 0x000079BD660E27E0
000079bd661e1d77  jmp 0x000079BD661E1BED
000079bd661e1d7c  call 0x000079BD6600E760
000079bd661e1d81  jmp 0x000079BD661E1C0A
000079bd661e1d86  ucomisd xmm1, xmm15
000079bd661e1d8b  jp 0x000079BD661E1D9A
000079bd661e1d8d  movaps xmm13, [0x000079BD65DFE060]
000079bd661e1d95  jmp 0x000079BD661E1C73
000079bd661e1d9a  vxorps xmm0, xmm1, xmm15
000079bd661e1d9f  pextrw eax, xmm0, 0x03
000079bd661e1da4  and eax, 0x7FF8
000079bd661e1da9  cmp eax, 0x08
000079bd661e1dac  jnz 0x000079BD661E1C73
000079bd661e1db2  movq rax, xmm15
000079bd661e1db7  shl rax, 0x0D
000079bd661e1dbb  jbe 0x000079BD661E1C73
000079bd661e1dc1  vorps xmm13, xmm15, [0x000079BD65DFE070]
000079bd661e1dc9  jmp 0x000079BD661E1C73
000079bd661e1dce  ucomisd xmm1, xmm15
000079bd661e1dd3  jp 0x000079BD661E1DE2
000079bd661e1dd5  movaps xmm14, [0x000079BD65DFE060]
000079bd661e1ddd  jmp 0x000079BD661E1CA0
000079bd661e1de2  vxorps xmm0, xmm1, xmm15
000079bd661e1de7  pextrw eax, xmm0, 0x03
000079bd661e1dec  and eax, 0x7FF8
000079bd661e1df1  cmp eax, 0x08
000079bd661e1df4  jnz 0x000079BD661E1CA0
000079bd661e1dfa  movq rax, xmm15
000079bd661e1dff  shl rax, 0x0D
000079bd661e1e03  jbe 0x000079BD661E1CA0
000079bd661e1e09  vorps xmm14, xmm15, [0x000079BD65DFE070]
000079bd661e1e11  jmp 0x000079BD661E1CA0
000079bd661e1e16  int3
000079bd661e1e17  nop [rax+rax*1], ax
000079bd661e1e20  mov rax, [r15+0x48]
000079bd661e1e24  mov r14, [r15+0x50]
000079bd661e1e28  lea r12, [r14+rax*1]
000079bd661e1e2c  movups xmm1, [r13+r12*1]
000079bd661e1e32  movaps [r15+0x120], xmm1
000079bd661e1e3a  lea r14, [rax+0x10]
000079bd661e1e3e  mov [r15+0x48], r14
000079bd661e1e42  xor eax, eax
000079bd661e1e44  mov r12d, 0x200
000079bd661e1e4a  cmp r14, r12
000079bd661e1e4d  cmc
000079bd661e1e4e  lahf
000079bd661e1e4f  seto al
000079bd661e1e52  mov [r15+0x108], eax
000079bd661e1e59  pextrq rax, xmm1, 0x01
000079bd661e1e60  movq xmm15, rax
000079bd661e1e65  movaps [r15+0x130], xmm15
000079bd661e1e6d  movaps xmm14, [r15+0x110]
000079bd661e1e75  movq rax, xmm14
000079bd661e1e7a  movq r14, xmm1
000079bd661e1e7f  vmovq xmm1, rax
000079bd661e1e84  vmovq xmm14, r14
000079bd661e1e89  movaps xmm13, xmm1
000079bd661e1e8d  addsd xmm13, xmm14
000079bd661e1e92  ucomisd xmm13, xmm13
000079bd661e1e97  jp 0x000079BD661E1F4C
000079bd661e1e9d  movq xmm13, xmm13
000079bd661e1ea2  movq rax, xmm13
000079bd661e1ea7  movq r14, xmm15
000079bd661e1eac  vmovq xmm1, rax
000079bd661e1eb1  vmovq xmm15, r14
000079bd661e1eb6  movaps xmm14, xmm1
000079bd661e1eba  addsd xmm14, xmm15
000079bd661e1ebf  ucomisd xmm14, xmm14
000079bd661e1ec4  jp 0x000079BD661E1F94
000079bd661e1eca  movq xmm14, xmm14
000079bd661e1ecf  movaps [r15+0x110], xmm14
000079bd661e1ed7  mov eax, [r15+0x108]
000079bd661e1ede  sahf
000079bd661e1edf  jnz 0x000079BD661E1F11
000079bd661e1ee1  cmp dword ptr [r15+0x318], 0x00
000079bd661e1ee9  jz 0x000079BD661E1FE0
000079bd661e1eef  nop [rax+rax*1], ax
000079bd661e1ef8  nop [rax+rax*1], eax
000079bd661e1f00  mov eax, 0x410490
000079bd661e1f05  mov [r15+0x100], rax
000079bd661e1f0c  jmp 0x000079BD65FFE110
000079bd661e1f11  cmp dword ptr [r15+0x318], 0x00
000079bd661e1f19  jz 0x000079BD661E1E20
000079bd661e1f1f  nop [rax+rax*1], ax
000079bd661e1f28  nop [rax+rax*1], eax
000079bd661e1f30  mov eax, 0x410474
000079bd661e1f35  mov [r15+0x100], rax
000079bd661e1f3c  jmp 0x000079BD65FFE110
000079bd661e1f41  int3
000079bd661e1f42  call 0x000079BD660B52F0
000079bd661e1f47  jmp 0x000079BD661E1E32
000079bd661e1f4c  ucomisd xmm1, xmm14
000079bd661e1f51  jp 0x000079BD661E1F60
000079bd661e1f53  movaps xmm13, [0x000079BD65DFE060]
000079bd661e1f5b  jmp 0x000079BD661E1E9D
000079bd661e1f60  vxorps xmm0, xmm1, xmm14
000079bd661e1f65  pextrw eax, xmm0, 0x03
000079bd661e1f6a  and eax, 0x7FF8
000079bd661e1f6f  cmp eax, 0x08
000079bd661e1f72  jnz 0x000079BD661E1E9D
000079bd661e1f78  movq rax, xmm14
000079bd661e1f7d  shl rax, 0x0D
000079bd661e1f81  jbe 0x000079BD661E1E9D
000079bd661e1f87  vorps xmm13, xmm14, [0x000079BD65DFE070]
000079bd661e1f8f  jmp 0x000079BD661E1E9D
000079bd661e1f94  ucomisd xmm1, xmm15
000079bd661e1f99  jp 0x000079BD661E1FA8
000079bd661e1f9b  movaps xmm14, [0x000079BD65DFE060]
000079bd661e1fa3  jmp 0x000079BD661E1ECA
000079bd661e1fa8  vxorps xmm0, xmm1, xmm15
000079bd661e1fad  pextrw eax, xmm0, 0x03
000079bd661e1fb2  and eax, 0x7FF8
000079bd661e1fb7  cmp eax, 0x08
000079bd661e1fba  jnz 0x000079BD661E1ECA
000079bd661e1fc0  movq rax, xmm15
000079bd661e1fc5  shl rax, 0x0D
000079bd661e1fc9  jbe 0x000079BD661E1ECA
000079bd661e1fcf  vorps xmm14, xmm15, [0x000079BD65DFE070]
000079bd661e1fd7  jmp 0x000079BD661E1ECA
000079bd661e1fdc  int3
000079bd661e1fdd  nop [rax], eax
000079bd661e1fe0  mov rax, [r15+0x40]
000079bd661e1fe4  lea r14, [rax+0x510]
000079bd661e1feb  movaps xmm1, [r15+0x110]
000079bd661e1ff3  movq rax, xmm1
000079bd661e1ff8  mov [r13+r14*1], rax
000079bd661e1ffd  mov rax, [r15+0xF0]
000079bd661e2004  mov [r15+0x100], rax
000079bd661e200b  jmp 0x000079BD661CE5C0
000079bd661e2010  int3
000079bd661e2011  call 0x000079BD660D5EB0
000079bd661e2016  jmp 0x000079BD661E1FFD
000079bd661e201b  int3
000079bd661e201c  nop [rax], eax
000079bd661e2020  mov qword ptr [r15+0x100], 0x04
000079bd661e202b  mov esi, 0x00
000079bd661e2030  mov edx, 0x09
000079bd661e2035  mov rdi, 0x7FFCBFCE65D0
000079bd661e203f  mov rax, 0x56EBD5643970
000079bd661e2049  call rax
000079bd661e204b  cmp dword ptr [r15+0x318], 0x00
000079bd661e2053  jnz 0x000079BD65FFE110
000079bd661e2059  jmp 0x000079BD65FFE0A0
000079bd661e205e  int3
000079bd661e205f  int3
