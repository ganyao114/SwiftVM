000074c379dce69b  nop [rax+rax*1], eax
000074c379dce6a0  vmovaps xmm1, [0x000074C3799FE010]
000074c379dce6a8  movq xmm1, xmm1
000074c379dce6ac  movaps [r15+0x110], xmm1
000074c379dce6b4  vmovaps xmm1, [0x000074C3799FE020]
000074c379dce6bc  movq xmm1, xmm1
000074c379dce6c0  movaps [r15+0x120], xmm1
000074c379dce6c8  mov eax, 0x4204C0
000074c379dce6cd  mov r14, [r13+rax*1]
000074c379dce6d2  movq xmm1, r14
000074c379dce6d7  movaps [r15+0x130], xmm1
000074c379dce6df  vmovaps xmm1, [0x000074C3799FE030]
000074c379dce6e7  vpbroadcastq xmm1, xmm1
000074c379dce6ec  movaps [r15+0x140], xmm1
000074c379dce6f4  mov qword ptr [r15+0x40], 0x02
000074c379dce6fc  vmovaps xmm15, [0x000074C3799FE040]
000074c379dce704  movq xmm15, xmm15
000074c379dce709  movaps [r15+0x150], xmm15
000074c379dce711  mov qword ptr [r15+0x58], 0x420000
000074c379dce719  vmovaps xmm15, [0x000074C3799FE050]
000074c379dce721  vpbroadcastq xmm15, xmm15
000074c379dce726  movaps [r15+0x160], xmm15
000074c379dce72e  mov rax, [r15+0x40]
000074c379dce732  vmovq xmm14, rax
000074c379dce737  vpbroadcastq xmm14, xmm14
000074c379dce73c  movaps [r15+0x170], xmm14
000074c379dce744  mov eax, 0x4204D0
000074c379dce749  movups xmm13, [r13+rax*1]
000074c379dce74f  mov qword ptr [r15+0x40], 0x430518
000074c379dce757  mov qword ptr [r15+0x50], 0x430720
000074c379dce75f  vpmovqd xmm12, xmm13
000074c379dce765  pxor xmm11, xmm11
000074c379dce76a  punpcklqdq xmm12, xmm11
000074c379dce76f  movaps [r15+0x210], xmm12
000074c379dce777  movq xmm12, qword ptr [r15+0x120]
000074c379dce780  movq xmm11, qword ptr [r15+0x130]
000074c379dce789  psubd xmm12, xmm11
000074c379dce78e  movq xmm12, xmm12
000074c379dce793  paddq xmm13, xmm14
000074c379dce798  movaps [r15+0x180], xmm13
000074c379dce7a0  movq xmm14, qword ptr [r15+0x150]
000074c379dce7a9  paddd xmm11, xmm14
000074c379dce7ae  movq xmm11, xmm11
000074c379dce7b3  movq xmm11, xmm11
000074c379dce7b8  movaps [r15+0x130], xmm11
000074c379dce7c0  pmovzxdq xmm12, xmm12
000074c379dce7c6  psllq xmm12, 0x00
000074c379dce7cc  movq xmm14, qword ptr [r15+0x210]
000074c379dce7d5  movq xmm13, qword ptr [r15+0x110]
000074c379dce7de  paddd xmm14, xmm13
000074c379dce7e3  movq xmm14, xmm14
000074c379dce7e8  vcvtuqq2pd xmm12, xmm12
000074c379dce7ee  pmovzxdq xmm14, xmm14
000074c379dce7f4  psllq xmm14, 0x00
000074c379dce7fa  vcvtuqq2pd xmm14, xmm14
000074c379dce800  movaps xmm13, xmm12
000074c379dce804  mulpd xmm13, xmm1
000074c379dce809  vcmppd xmm11, xmm13, xmm13, 0x03
000074c379dce80f  ptest xmm11, xmm11
000074c379dce815  jnz 0x000074C379DCE8FF
000074c379dce81b  movaps [r15+0x220], xmm13
000074c379dce823  mov eax, 0x430720
000074c379dce828  movups [r13+rax*1], xmm13
000074c379dce82e  movaps xmm1, xmm14
000074c379dce832  mulpd xmm1, xmm15
000074c379dce837  vcmppd xmm13, xmm1, xmm1, 0x03
000074c379dce83c  ptest xmm13, xmm13
000074c379dce842  jnz 0x000074C379DCEA4C
000074c379dce848  movaps [r15+0x210], xmm1
000074c379dce850  mov eax, 0x430518
000074c379dce855  movups [r13+rax*1], xmm1
000074c379dce85b  mov qword ptr [r15+0x48], 0x10
000074c379dce863  xor eax, eax
000074c379dce865  mov r14d, 0x10
000074c379dce86b  mov r12d, 0x200
000074c379dce871  cmp r14, r12
000074c379dce874  cmc
000074c379dce875  lahf
000074c379dce876  seto al
000074c379dce879  mov [r15+0x108], eax
000074c379dce880  mov eax, [r15+0x108]
000074c379dce887  sahf
000074c379dce888  jnz 0x000074C379DCE8BA
000074c379dce88a  cmp dword ptr [r15+0x318], 0x00
000074c379dce892  jz 0x000074C379DCEFF0
000074c379dce898  nop [rax+rax*1], ax
000074c379dce8a1  nop [rax+rax*1], eax
000074c379dce8a9  mov eax, 0x4101EC
000074c379dce8ae  mov [r15+0x100], rax
000074c379dce8b5  jmp 0x000074C379BFE110
000074c379dce8ba  cmp dword ptr [r15+0x318], 0x00
000074c379dce8c2  jz 0x000074C379DCEBA0
000074c379dce8c8  nop [rax+rax*1], ax
000074c379dce8d1  nop [rax+rax*1], eax
000074c379dce8d9  mov eax, 0x4101AC
000074c379dce8de  mov [r15+0x100], rax
000074c379dce8e5  jmp 0x000074C379BFE110
000074c379dce8ea  int3
000074c379dce8eb  call 0x000074C379C0DC20
000074c379dce8f0  jmp 0x000074C379DCE6D2
000074c379dce8f5  call 0x000074C379C0C260
000074c379dce8fa  jmp 0x000074C379DCE74F
000074c379dce8ff  sub rsp, 0x08
000074c379dce903  push rax
000074c379dce904  push rcx
000074c379dce905  push rdx
000074c379dce906  push rdi
000074c379dce907  push rsi
000074c379dce908  push r8
000074c379dce90a  push r9
000074c379dce90c  push r10
000074c379dce90e  push r11
000074c379dce910  sub rsp, 0xF0
000074c379dce917  vmovaps [rsp], xmm0
000074c379dce91c  vmovaps [rsp+0x10], xmm1
000074c379dce922  vmovaps [rsp+0x20], xmm2
000074c379dce928  vmovaps [rsp+0x30], xmm3
000074c379dce92e  vmovaps [rsp+0x40], xmm4
000074c379dce934  vmovaps [rsp+0x50], xmm5
000074c379dce93a  vmovaps [rsp+0x60], xmm6
000074c379dce940  vmovaps [rsp+0x70], xmm7
000074c379dce946  vmovaps [rsp+0x80], xmm8
000074c379dce94f  vmovaps [rsp+0x90], xmm9
000074c379dce958  vmovaps [rsp+0xA0], xmm10
000074c379dce961  vmovaps [rsp+0xB0], xmm11
000074c379dce96a  vmovaps [rsp+0xC0], xmm12
000074c379dce973  vmovaps [rsp+0xD0], xmm14
000074c379dce97c  vmovaps [rsp+0xE0], xmm15
000074c379dce985  sub rsp, 0x30
000074c379dce989  movaps [rsp], xmm13
000074c379dce98e  movaps [rsp+0x10], xmm12
000074c379dce994  movaps [rsp+0x20], xmm1
000074c379dce999  lea rdi, [rsp]
000074c379dce99d  mov esi, 0x00
000074c379dce9a2  mov rax, 0x56321ABA4530
000074c379dce9ac  call rax
000074c379dce9ae  movaps xmm13, [rsp]
000074c379dce9b3  add rsp, 0x30
000074c379dce9b7  vmovaps xmm0, [rsp]
000074c379dce9bc  vmovaps xmm1, [rsp+0x10]
000074c379dce9c2  vmovaps xmm2, [rsp+0x20]
000074c379dce9c8  vmovaps xmm3, [rsp+0x30]
000074c379dce9ce  vmovaps xmm4, [rsp+0x40]
000074c379dce9d4  vmovaps xmm5, [rsp+0x50]
000074c379dce9da  vmovaps xmm6, [rsp+0x60]
000074c379dce9e0  vmovaps xmm7, [rsp+0x70]
000074c379dce9e6  vmovaps xmm8, [rsp+0x80]
000074c379dce9ef  vmovaps xmm9, [rsp+0x90]
000074c379dce9f8  vmovaps xmm10, [rsp+0xA0]
000074c379dcea01  vmovaps xmm11, [rsp+0xB0]
000074c379dcea0a  vmovaps xmm12, [rsp+0xC0]
000074c379dcea13  vmovaps xmm14, [rsp+0xD0]
000074c379dcea1c  vmovaps xmm15, [rsp+0xE0]
000074c379dcea25  add rsp, 0xF0
000074c379dcea2c  pop r11
000074c379dcea2e  pop r10
000074c379dcea30  pop r9
000074c379dcea32  pop r8
000074c379dcea34  pop rsi
000074c379dcea35  pop rdi
000074c379dcea36  pop rdx
000074c379dcea37  pop rcx
000074c379dcea38  pop rax
000074c379dcea39  add rsp, 0x08
000074c379dcea3d  jmp 0x000074C379DCE81B
000074c379dcea42  call 0x000074C379C0C380
000074c379dcea47  jmp 0x000074C379DCE82E
000074c379dcea4c  sub rsp, 0x08
000074c379dcea50  push rax
000074c379dcea51  push rcx
000074c379dcea52  push rdx
000074c379dcea53  push rdi
000074c379dcea54  push rsi
000074c379dcea55  push r8
000074c379dcea57  push r9
000074c379dcea59  push r10
000074c379dcea5b  push r11
000074c379dcea5d  sub rsp, 0xF0
000074c379dcea64  vmovaps [rsp], xmm0
000074c379dcea69  vmovaps [rsp+0x10], xmm2
000074c379dcea6f  vmovaps [rsp+0x20], xmm3
000074c379dcea75  vmovaps [rsp+0x30], xmm4
000074c379dcea7b  vmovaps [rsp+0x40], xmm5
000074c379dcea81  vmovaps [rsp+0x50], xmm6
000074c379dcea87  vmovaps [rsp+0x60], xmm7
000074c379dcea8d  vmovaps [rsp+0x70], xmm8
000074c379dcea93  vmovaps [rsp+0x80], xmm9
000074c379dcea9c  vmovaps [rsp+0x90], xmm10
000074c379dceaa5  vmovaps [rsp+0xA0], xmm11
000074c379dceaae  vmovaps [rsp+0xB0], xmm12
000074c379dceab7  vmovaps [rsp+0xC0], xmm13
000074c379dceac0  vmovaps [rsp+0xD0], xmm14
000074c379dceac9  vmovaps [rsp+0xE0], xmm15
000074c379dcead2  sub rsp, 0x30
000074c379dcead6  movaps [rsp], xmm1
000074c379dceada  movaps [rsp+0x10], xmm14
000074c379dceae0  movaps [rsp+0x20], xmm15
000074c379dceae6  lea rdi, [rsp]
000074c379dceaea  mov esi, 0x00
000074c379dceaef  mov rax, 0x56321ABA4530
000074c379dceaf9  call rax
000074c379dceafb  movaps xmm1, [rsp]
000074c379dceaff  add rsp, 0x30
000074c379dceb03  vmovaps xmm0, [rsp]
000074c379dceb08  vmovaps xmm2, [rsp+0x10]
000074c379dceb0e  vmovaps xmm3, [rsp+0x20]
000074c379dceb14  vmovaps xmm4, [rsp+0x30]
000074c379dceb1a  vmovaps xmm5, [rsp+0x40]
000074c379dceb20  vmovaps xmm6, [rsp+0x50]
000074c379dceb26  vmovaps xmm7, [rsp+0x60]
000074c379dceb2c  vmovaps xmm8, [rsp+0x70]
000074c379dceb32  vmovaps xmm9, [rsp+0x80]
000074c379dceb3b  vmovaps xmm10, [rsp+0x90]
000074c379dceb44  vmovaps xmm11, [rsp+0xA0]
000074c379dceb4d  vmovaps xmm12, [rsp+0xB0]
000074c379dceb56  vmovaps xmm13, [rsp+0xC0]
000074c379dceb5f  vmovaps xmm14, [rsp+0xD0]
000074c379dceb68  vmovaps xmm15, [rsp+0xE0]
000074c379dceb71  add rsp, 0xF0
000074c379dceb78  pop r11
000074c379dceb7a  pop r10
000074c379dceb7c  pop r9
000074c379dceb7e  pop r8
000074c379dceb80  pop rsi
000074c379dceb81  pop rdi
000074c379dceb82  pop rdx
000074c379dceb83  pop rcx
000074c379dceb84  pop rax
000074c379dceb85  add rsp, 0x08
000074c379dceb89  jmp 0x000074C379DCE848
000074c379dceb8e  call 0x000074C379BFF540
000074c379dceb93  jmp 0x000074C379DCE85B
000074c379dceb98  int3
000074c379dceb99  nop [rax], eax
000074c379dceba0  movaps xmm1, [r15+0x180]
000074c379dceba8  vpmovqd xmm15, xmm1
000074c379dcebae  pxor xmm14, xmm14
000074c379dcebb3  punpcklqdq xmm15, xmm14
000074c379dcebb8  movaps [r15+0x210], xmm15
000074c379dcebc0  movq xmm15, qword ptr [r15+0x120]
000074c379dcebc9  movq xmm14, qword ptr [r15+0x130]
000074c379dcebd2  psubd xmm15, xmm14
000074c379dcebd7  movq xmm15, xmm15
000074c379dcebdc  movaps xmm13, [r15+0x170]
000074c379dcebe4  paddq xmm1, xmm13
000074c379dcebe9  movaps [r15+0x180], xmm1
000074c379dcebf1  movq xmm1, qword ptr [r15+0x150]
000074c379dcebfa  paddd xmm14, xmm1
000074c379dcebff  movq xmm14, xmm14
000074c379dcec04  movq xmm14, xmm14
000074c379dcec09  movaps [r15+0x130], xmm14
000074c379dcec11  pmovzxdq xmm15, xmm15
000074c379dcec17  psllq xmm15, 0x00
000074c379dcec1d  movq xmm1, qword ptr [r15+0x210]
000074c379dcec26  movq xmm14, qword ptr [r15+0x110]
000074c379dcec2f  paddd xmm1, xmm14
000074c379dcec34  movq xmm1, xmm1
000074c379dcec38  vcvtuqq2pd xmm15, xmm15
000074c379dcec3e  pmovzxdq xmm1, xmm1
000074c379dcec43  psllq xmm1, 0x00
000074c379dcec48  vcvtuqq2pd xmm1, xmm1
000074c379dcec4e  movaps xmm14, [r15+0x140]
000074c379dcec56  movaps xmm13, xmm15
000074c379dcec5a  mulpd xmm13, xmm14
000074c379dcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000074c379dcec65  ptest xmm12, xmm12
000074c379dcec6b  jnz 0x000074C379DCED4E
000074c379dcec71  movaps [r15+0x220], xmm13
000074c379dcec79  mov rax, [r15+0x48]
000074c379dcec7d  mov r14, [r15+0x50]
000074c379dcec81  lea r12, [r14+rax*1]
000074c379dcec85  movups [r13+r12*1], xmm13
000074c379dcec8b  movaps xmm15, [r15+0x160]
000074c379dcec93  movaps xmm14, xmm1
000074c379dcec97  mulpd xmm14, xmm15
000074c379dcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000074c379dceca2  ptest xmm13, xmm13
000074c379dceca8  jnz 0x000074C379DCEE9C
000074c379dcecae  movaps [r15+0x210], xmm14
000074c379dcecb6  mov r14, [r15+0x40]
000074c379dcecba  lea r12, [r14+rax*1]
000074c379dcecbe  movups [r13+r12*1], xmm14
000074c379dcecc4  lea r14, [rax+0x10]
000074c379dcecc8  mov [r15+0x48], r14
000074c379dceccc  xor eax, eax
000074c379dcecce  mov r12d, 0x200
000074c379dcecd4  cmp r14, r12
000074c379dcecd7  cmc
000074c379dcecd8  lahf
000074c379dcecd9  seto al
000074c379dcecdc  mov [r15+0x108], eax
000074c379dcece3  mov eax, [r15+0x108]
000074c379dcecea  sahf
000074c379dceceb  jnz 0x000074C379DCED1D
000074c379dceced  cmp dword ptr [r15+0x318], 0x00
000074c379dcecf5  jz 0x000074C379DCEFF0
000074c379dcecfb  nop [rax+rax*1], ax
000074c379dced04  nop [rax+rax*1], eax
000074c379dced0c  mov eax, 0x4101EC
000074c379dced11  mov [r15+0x100], rax
000074c379dced18  jmp 0x000074C379BFE110
000074c379dced1d  cmp dword ptr [r15+0x318], 0x00
000074c379dced25  jz 0x000074C379DCEBA0
000074c379dced2b  nop [rax+rax*1], ax
000074c379dced34  nop [rax+rax*1], eax
000074c379dced3c  mov eax, 0x4101AC
000074c379dced41  mov [r15+0x100], rax
000074c379dced48  jmp 0x000074C379BFE110
000074c379dced4d  int3
000074c379dced4e  sub rsp, 0x08
000074c379dced52  push rax
000074c379dced53  push rcx
000074c379dced54  push rdx
000074c379dced55  push rdi
000074c379dced56  push rsi
000074c379dced57  push r8
000074c379dced59  push r9
000074c379dced5b  push r10
000074c379dced5d  push r11
000074c379dced5f  sub rsp, 0xF0
000074c379dced66  vmovaps [rsp], xmm0
000074c379dced6b  vmovaps [rsp+0x10], xmm1
000074c379dced71  vmovaps [rsp+0x20], xmm2
000074c379dced77  vmovaps [rsp+0x30], xmm3
000074c379dced7d  vmovaps [rsp+0x40], xmm4
000074c379dced83  vmovaps [rsp+0x50], xmm5
000074c379dced89  vmovaps [rsp+0x60], xmm6
000074c379dced8f  vmovaps [rsp+0x70], xmm7
000074c379dced95  vmovaps [rsp+0x80], xmm8
000074c379dced9e  vmovaps [rsp+0x90], xmm9
000074c379dceda7  vmovaps [rsp+0xA0], xmm10
000074c379dcedb0  vmovaps [rsp+0xB0], xmm11
000074c379dcedb9  vmovaps [rsp+0xC0], xmm12
000074c379dcedc2  vmovaps [rsp+0xD0], xmm14
000074c379dcedcb  vmovaps [rsp+0xE0], xmm15
000074c379dcedd4  sub rsp, 0x30
000074c379dcedd8  movaps [rsp], xmm13
000074c379dceddd  movaps [rsp+0x10], xmm15
000074c379dcede3  movaps [rsp+0x20], xmm14
000074c379dcede9  lea rdi, [rsp]
000074c379dceded  mov esi, 0x00
000074c379dcedf2  mov rax, 0x56321ABA4530
000074c379dcedfc  call rax
000074c379dcedfe  movaps xmm13, [rsp]
000074c379dcee03  add rsp, 0x30
000074c379dcee07  vmovaps xmm0, [rsp]
000074c379dcee0c  vmovaps xmm1, [rsp+0x10]
000074c379dcee12  vmovaps xmm2, [rsp+0x20]
000074c379dcee18  vmovaps xmm3, [rsp+0x30]
000074c379dcee1e  vmovaps xmm4, [rsp+0x40]
000074c379dcee24  vmovaps xmm5, [rsp+0x50]
000074c379dcee2a  vmovaps xmm6, [rsp+0x60]
000074c379dcee30  vmovaps xmm7, [rsp+0x70]
000074c379dcee36  vmovaps xmm8, [rsp+0x80]
000074c379dcee3f  vmovaps xmm9, [rsp+0x90]
000074c379dcee48  vmovaps xmm10, [rsp+0xA0]
000074c379dcee51  vmovaps xmm11, [rsp+0xB0]
000074c379dcee5a  vmovaps xmm12, [rsp+0xC0]
000074c379dcee63  vmovaps xmm14, [rsp+0xD0]
000074c379dcee6c  vmovaps xmm15, [rsp+0xE0]
000074c379dcee75  add rsp, 0xF0
000074c379dcee7c  pop r11
000074c379dcee7e  pop r10
000074c379dcee80  pop r9
000074c379dcee82  pop r8
000074c379dcee84  pop rsi
000074c379dcee85  pop rdi
000074c379dcee86  pop rdx
000074c379dcee87  pop rcx
000074c379dcee88  pop rax
000074c379dcee89  add rsp, 0x08
000074c379dcee8d  jmp 0x000074C379DCEC71
000074c379dcee92  call 0x000074C379CC2240
000074c379dcee97  jmp 0x000074C379DCEC8B
000074c379dcee9c  sub rsp, 0x08
000074c379dceea0  push rax
000074c379dceea1  push rcx
000074c379dceea2  push rdx
000074c379dceea3  push rdi
000074c379dceea4  push rsi
000074c379dceea5  push r8
000074c379dceea7  push r9
000074c379dceea9  push r10
000074c379dceeab  push r11
000074c379dceead  sub rsp, 0xF0
000074c379dceeb4  vmovaps [rsp], xmm0
000074c379dceeb9  vmovaps [rsp+0x10], xmm1
000074c379dceebf  vmovaps [rsp+0x20], xmm2
000074c379dceec5  vmovaps [rsp+0x30], xmm3
000074c379dceecb  vmovaps [rsp+0x40], xmm4
000074c379dceed1  vmovaps [rsp+0x50], xmm5
000074c379dceed7  vmovaps [rsp+0x60], xmm6
000074c379dceedd  vmovaps [rsp+0x70], xmm7
000074c379dceee3  vmovaps [rsp+0x80], xmm8
000074c379dceeec  vmovaps [rsp+0x90], xmm9
000074c379dceef5  vmovaps [rsp+0xA0], xmm10
000074c379dceefe  vmovaps [rsp+0xB0], xmm11
000074c379dcef07  vmovaps [rsp+0xC0], xmm12
000074c379dcef10  vmovaps [rsp+0xD0], xmm13
000074c379dcef19  vmovaps [rsp+0xE0], xmm15
000074c379dcef22  sub rsp, 0x30
000074c379dcef26  movaps [rsp], xmm14
000074c379dcef2b  movaps [rsp+0x10], xmm1
000074c379dcef30  movaps [rsp+0x20], xmm15
000074c379dcef36  lea rdi, [rsp]
000074c379dcef3a  mov esi, 0x00
000074c379dcef3f  mov rax, 0x56321ABA4530
000074c379dcef49  call rax
000074c379dcef4b  movaps xmm14, [rsp]
000074c379dcef50  add rsp, 0x30
000074c379dcef54  vmovaps xmm0, [rsp]
000074c379dcef59  vmovaps xmm1, [rsp+0x10]
000074c379dcef5f  vmovaps xmm2, [rsp+0x20]
000074c379dcef65  vmovaps xmm3, [rsp+0x30]
000074c379dcef6b  vmovaps xmm4, [rsp+0x40]
000074c379dcef71  vmovaps xmm5, [rsp+0x50]
000074c379dcef77  vmovaps xmm6, [rsp+0x60]
000074c379dcef7d  vmovaps xmm7, [rsp+0x70]
000074c379dcef83  vmovaps xmm8, [rsp+0x80]
000074c379dcef8c  vmovaps xmm9, [rsp+0x90]
000074c379dcef95  vmovaps xmm10, [rsp+0xA0]
000074c379dcef9e  vmovaps xmm11, [rsp+0xB0]
000074c379dcefa7  vmovaps xmm12, [rsp+0xC0]
000074c379dcefb0  vmovaps xmm13, [rsp+0xD0]
000074c379dcefb9  vmovaps xmm15, [rsp+0xE0]
000074c379dcefc2  add rsp, 0xF0
000074c379dcefc9  pop r11
000074c379dcefcb  pop r10
000074c379dcefcd  pop r9
000074c379dcefcf  pop r8
000074c379dcefd1  pop rsi
000074c379dcefd2  pop rdi
000074c379dcefd3  pop rdx
000074c379dcefd4  pop rcx
000074c379dcefd5  pop rax
000074c379dcefd6  add rsp, 0x08
000074c379dcefda  jmp 0x000074C379DCECAE
000074c379dcefdf  call 0x000074C379CC34C0
000074c379dcefe4  jmp 0x000074C379DCECC4
000074c379dcefe9  int3
000074c379dcefea  nop [rax+rax*1], ax
000074c379dceff0  mov rax, [r15+0xF8]
000074c379dceff7  lea r14, [rax-0x150]
000074c379dceffe  mov [r15+0xF8], r14
000074c379dcf005  mov rax, [r15+0x50]
000074c379dcf009  lea r12, [rax+0x80]
000074c379dcf010  movups xmm1, [r13+r12*1]
000074c379dcf016  lea r12, [rax+0x90]
000074c379dcf01d  movups xmm15, [r13+r12*1]
000074c379dcf023  mov qword ptr [r15+0x48], 0x00
000074c379dcf02b  lea r12, [rax+0x40]
000074c379dcf02f  movups xmm14, [r13+r12*1]
000074c379dcf035  lea r12, [rax+0x50]
000074c379dcf039  movups xmm13, [r13+r12*1]
000074c379dcf03f  lea r12, [r14+0x120]
000074c379dcf046  movq xmm12, qword ptr [r15+0x1C0]
000074c379dcf04f  movq xmm11, qword ptr [r15+0x1B0]
000074c379dcf058  movq r11, xmm12
000074c379dcf05d  movq r10, xmm11
000074c379dcf062  mov [r13+r12*1], r11
000074c379dcf067  lea r12, [r14+0x128]
000074c379dcf06e  mov [r13+r12*1], r10
000074c379dcf073  vxorps xmm12, xmm12, xmm12
000074c379dcf078  vpbroadcastq xmm12, xmm12
000074c379dcf07d  lea r12, [r14+0x100]
000074c379dcf084  movq xmm11, qword ptr [r15+0x200]
000074c379dcf08d  movq xmm10, qword ptr [r15+0x1F0]
000074c379dcf096  movq r11, xmm11
000074c379dcf09b  movq r10, xmm10
000074c379dcf0a0  mov [r13+r12*1], r11
000074c379dcf0a5  lea r12, [r14+0x108]
000074c379dcf0ac  mov [r13+r12*1], r10
000074c379dcf0b1  lea r12, [r14+0xE0]
000074c379dcf0b8  movups [r13+r12*1], xmm15
000074c379dcf0be  lea r12, [r14+0xF0]
000074c379dcf0c5  movups [r13+r12*1], xmm1
000074c379dcf0cb  lea r12, [rax+0xC0]
000074c379dcf0d2  movups xmm1, [r13+r12*1]
000074c379dcf0d8  lea r12, [rax+0xD0]
000074c379dcf0df  movups xmm15, [r13+r12*1]
000074c379dcf0e5  lea r12, [r14+0x110]
000074c379dcf0ec  movq xmm11, qword ptr [r15+0x1E0]
000074c379dcf0f5  movq xmm10, qword ptr [r15+0x1D0]
000074c379dcf0fe  movq r11, xmm11
000074c379dcf103  movq r10, xmm10
000074c379dcf108  mov [r13+r12*1], r11
000074c379dcf10d  lea r12, [r14+0x118]
000074c379dcf114  mov [r13+r12*1], r10
000074c379dcf119  movups xmm11, [r13+rax*1]
000074c379dcf11f  lea r12, [rax+0x10]
000074c379dcf123  movups xmm10, [r13+r12*1]
000074c379dcf129  lea r12, [r14+0x130]
000074c379dcf130  movq xmm9, qword ptr [r15+0x1A0]
000074c379dcf139  movq xmm8, qword ptr [r15+0x190]
000074c379dcf142  movq r11, xmm9
000074c379dcf147  movq r10, xmm8
000074c379dcf14c  mov [r13+r12*1], r11
000074c379dcf151  lea r12, [r14+0x138]
000074c379dcf158  mov [r13+r12*1], r10
000074c379dcf15d  lea r12, [rax+0x140]
000074c379dcf164  movups xmm9, [r13+r12*1]
000074c379dcf16a  lea r12, [rax+0x150]
000074c379dcf171  movups xmm8, [r13+r12*1]
000074c379dcf177  lea r12, [r14+0xC0]
000074c379dcf17e  movups [r13+r12*1], xmm15
000074c379dcf184  lea r12, [r14+0xD0]
000074c379dcf18b  movups [r13+r12*1], xmm1
000074c379dcf191  lea r12, [rax+0x100]
000074c379dcf198  movups xmm1, [r13+r12*1]
000074c379dcf19e  lea r12, [rax+0x110]
000074c379dcf1a5  movups xmm15, [r13+r12*1]
000074c379dcf1ab  lea r12, [r14+0x140]
000074c379dcf1b2  mov r11, [r15+0xE8]
000074c379dcf1b9  mov [r13+r12*1], r11
000074c379dcf1be  lea r12, [rax+0x180]
000074c379dcf1c5  movups xmm7, [r13+r12*1]
000074c379dcf1cb  lea r12, [rax+0x190]
000074c379dcf1d2  movups xmm6, [r13+r12*1]
000074c379dcf1d8  lea r12, [rax+0x1C0]
000074c379dcf1df  movups xmm5, [r13+r12*1]
000074c379dcf1e5  lea r12, [rax+0x1D0]
000074c379dcf1ec  movups xmm4, [r13+r12*1]
000074c379dcf1f2  lea r12, [r14+0x20]
000074c379dcf1f6  movups [r13+r12*1], xmm1
000074c379dcf1fc  lea r12, [r14+0x30]
000074c379dcf200  movups [r13+r12*1], xmm13
000074c379dcf206  lea r12, [rax+0x60]
000074c379dcf20a  movups xmm1, [r13+r12*1]
000074c379dcf210  lea r12, [rax+0x70]
000074c379dcf214  movups xmm13, [r13+r12*1]
000074c379dcf21a  lea r12, [rax+0x20]
000074c379dcf21e  movups xmm3, [r13+r12*1]
000074c379dcf224  lea r12, [rax+0x30]
000074c379dcf228  movups xmm2, [r13+r12*1]
000074c379dcf22e  movaps [r15+0x1F0], xmm2
000074c379dcf236  lea r12, [r14+0x60]
000074c379dcf23a  movups [r13+r12*1], xmm11
000074c379dcf240  lea r12, [r14+0x70]
000074c379dcf244  movups [r13+r12*1], xmm5
000074c379dcf24a  lea r12, [rax+0xE0]
000074c379dcf251  movups xmm11, [r13+r12*1]
000074c379dcf257  lea r12, [rax+0xF0]
000074c379dcf25e  movups xmm5, [r13+r12*1]
000074c379dcf264  lea r12, [r14+0xA0]
000074c379dcf26b  movups [r13+r12*1], xmm13
000074c379dcf271  lea r12, [r14+0xB0]
000074c379dcf278  movups [r13+r12*1], xmm1
000074c379dcf27e  lea r12, [rax+0xA0]
000074c379dcf285  movups xmm1, [r13+r12*1]
000074c379dcf28b  lea r12, [rax+0xB0]
000074c379dcf292  movups xmm13, [r13+r12*1]
000074c379dcf298  lea r12, [rax+0x120]
000074c379dcf29f  vmovaps [rsp+0x10], xmm1
000074c379dcf2a5  movups xmm1, [r13+r12*1]
000074c379dcf2ab  lea r12, [rax+0x130]
000074c379dcf2b2  vmovaps [rsp+0x20], xmm1
000074c379dcf2b8  movups xmm1, [r13+r12*1]
000074c379dcf2be  lea r12, [rax+0x160]
000074c379dcf2c5  vmovaps [rsp+0x30], xmm1
000074c379dcf2cb  movups xmm1, [r13+r12*1]
000074c379dcf2d1  lea r12, [rax+0x170]
000074c379dcf2d8  vmovaps [rsp+0x40], xmm1
000074c379dcf2de  movups xmm1, [r13+r12*1]
000074c379dcf2e4  movaps [r15+0x2B0], xmm1
000074c379dcf2ec  lea r12, [r14+0x80]
000074c379dcf2f3  movups [r13+r12*1], xmm13
000074c379dcf2f9  lea r12, [r14+0x90]
000074c379dcf300  vmovaps xmm13, [rsp+0x10]
000074c379dcf306  movups [r13+r12*1], xmm13
000074c379dcf30c  lea r12, [rax+0x1A0]
000074c379dcf313  movups xmm13, [r13+r12*1]
000074c379dcf319  lea r12, [rax+0x1B0]
000074c379dcf320  vmovaps [rsp+0x10], xmm1
000074c379dcf326  movups xmm1, [r13+r12*1]
000074c379dcf32c  movaps [r15+0x290], xmm13
000074c379dcf334  movaps [r15+0x1E0], xmm1
000074c379dcf33c  lea r12, [rax+0x1E0]
000074c379dcf343  vmovaps [rsp+0x50], xmm1
000074c379dcf349  movups xmm1, [r13+r12*1]
000074c379dcf34f  lea r12, [rax+0x1F0]
000074c379dcf356  vmovaps [rsp+0x60], xmm1
000074c379dcf35c  movups xmm1, [r13+r12*1]
000074c379dcf362  mov qword ptr [r15+0x50], 0x430920
000074c379dcf36a  lea rax, [r14+0x40]
000074c379dcf36e  vmovaps [rsp+0x70], xmm1
000074c379dcf374  vmovaps xmm1, [rsp+0x40]
000074c379dcf37a  movups [r13+rax*1], xmm1
000074c379dcf380  lea rax, [r14+0x50]
000074c379dcf384  movups [r13+rax*1], xmm10
000074c379dcf38a  vmovaps xmm1, [rsp+0x70]
000074c379dcf390  movups [r13+r14*1], xmm1
000074c379dcf396  lea rax, [r14+0x10]
000074c379dcf39a  vmovaps xmm1, [rsp+0x60]
000074c379dcf3a0  movups [r13+rax*1], xmm1
000074c379dcf3a6  mov rax, [r15+0x40]
000074c379dcf3aa  vmovaps [rsp+0x40], xmm3
000074c379dcf3b0  vmovaps xmm1, [rsp+0x40]
000074c379dcf3b6  por xmm3, xmm1
000074c379dcf3ba  vmovaps [rsp+0x40], xmm6
000074c379dcf3c0  vmovaps xmm10, [rsp+0x40]
000074c379dcf3c6  por xmm6, xmm10
000074c379dcf3cb  lea r12, [rax+0x30]
000074c379dcf3cf  mov r11, [r13+r12*1]
000074c379dcf3d4  lea r12, [rax+0x38]
000074c379dcf3d8  mov r10, [r13+r12*1]
000074c379dcf3dd  movq xmm10, r11
000074c379dcf3e2  vmovaps [rsp+0x40], xmm1
000074c379dcf3e8  movq xmm1, r10
000074c379dcf3ed  movq xmm10, xmm10
000074c379dcf3f2  vmovaps [rsp+0x60], xmm10
000074c379dcf3f8  movq xmm10, xmm10
000074c379dcf3fd  movaps [r15+0x130], xmm10
000074c379dcf405  movq xmm1, xmm1
000074c379dcf409  vmovaps [rsp+0x70], xmm1
000074c379dcf40f  movq xmm1, xmm1
000074c379dcf413  movaps [r15+0x280], xmm1
000074c379dcf41b  vmovaps [rsp+0x80], xmm9
000074c379dcf424  vmovaps xmm1, [rsp+0x80]
000074c379dcf42d  por xmm9, xmm1
000074c379dcf432  lea r12, [rax+0x20]
000074c379dcf436  mov r11, [r13+r12*1]
000074c379dcf43b  lea r12, [rax+0x28]
000074c379dcf43f  mov r10, [r13+r12*1]
000074c379dcf444  movq xmm1, r11
000074c379dcf449  movq xmm10, r10
000074c379dcf44e  movq xmm1, xmm1
000074c379dcf452  vmovaps [rsp+0x80], xmm1
000074c379dcf45b  movq xmm1, xmm1
000074c379dcf45f  movaps [r15+0x150], xmm1
000074c379dcf467  movq xmm10, xmm10
000074c379dcf46c  vmovaps [rsp+0x90], xmm10
000074c379dcf475  movq xmm10, xmm10
000074c379dcf47a  movaps [r15+0x140], xmm10
000074c379dcf482  lea r12, [rax+0x10]
000074c379dcf486  mov r11, [r13+r12*1]
000074c379dcf48b  lea r12, [rax+0x18]
000074c379dcf48f  mov r10, [r13+r12*1]
000074c379dcf494  movq xmm1, r11
000074c379dcf499  movq xmm10, r10
000074c379dcf49e  movq xmm1, xmm1
000074c379dcf4a2  vmovaps [rsp+0xA0], xmm1
000074c379dcf4ab  movq xmm1, xmm1
000074c379dcf4af  movaps [r15+0x170], xmm1
000074c379dcf4b7  movq xmm10, xmm10
000074c379dcf4bc  vmovaps [rsp+0xB0], xmm10
000074c379dcf4c5  movq xmm10, xmm10
000074c379dcf4ca  movaps [r15+0x160], xmm10
000074c379dcf4d2  mov r12, [r13+rax*1]
000074c379dcf4d7  vmovq xmm1, r12
000074c379dcf4dc  vpbroadcastq xmm1, xmm1
000074c379dcf4e1  lea r12, [rax+0x08]
000074c379dcf4e5  mov rax, [r13+r12*1]
000074c379dcf4ea  movq xmm10, rax
000074c379dcf4ef  movaps [r15+0x230], xmm10
000074c379dcf4f7  lea rax, [r14+0x50]
000074c379dcf4fb  movups xmm10, [r13+rax*1]
000074c379dcf501  lea rax, [r14+0x60]
000074c379dcf505  vmovaps [rsp+0xC0], xmm1
000074c379dcf50e  movups xmm1, [r13+rax*1]
000074c379dcf514  lea rax, [r14+0x30]
000074c379dcf518  vmovaps [rsp+0xD0], xmm1
000074c379dcf521  movups xmm1, [r13+rax*1]
000074c379dcf527  mov qword ptr [r15+0x60], 0x430920
000074c379dcf52f  mov qword ptr [r15+0x58], 0x40
000074c379dcf537  vmovaps [rsp+0xE0], xmm1
000074c379dcf540  vmovaps [rsp+0xF0], xmm15
000074c379dcf549  vmovaps xmm15, [rsp+0xC0]
000074c379dcf552  vmovaps [rsp+0xC0], xmm14
000074c379dcf55b  vmovaps xmm14, [rsp+0x40]
000074c379dcf561  vmovaps [rsp+0x40], xmm13
000074c379dcf567  movaps xmm1, xmm15
000074c379dcf56b  mulpd xmm1, xmm14
000074c379dcf570  vcmppd xmm13, xmm1, xmm1, 0x03
000074c379dcf575  ptest xmm13, xmm13
000074c379dcf57b  jnz 0x000074C379DD0682
000074c379dcf581  movq xmm14, qword ptr [r15+0x230]
000074c379dcf58a  vmovaps [rsp+0x100], xmm14
000074c379dcf593  vpermilpd xmm14, xmm14, 0x00
000074c379dcf599  vmovaps [rsp+0x110], xmm1
000074c379dcf5a2  vmovaps xmm1, [rsp+0xE0]
000074c379dcf5ab  vmovaps [rsp+0xE0], xmm15
000074c379dcf5b4  movaps xmm13, xmm1
000074c379dcf5b8  mulpd xmm13, xmm14
000074c379dcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000074c379dcf5c3  ptest xmm15, xmm15
000074c379dcf5c9  jnz 0x000074C379DD07C4
000074c379dcf5cf  vxorps xmm1, xmm1, xmm1
000074c379dcf5d3  vpbroadcastq xmm1, xmm1
000074c379dcf5d8  vmovaps xmm14, [rsp+0xE0]
000074c379dcf5e1  vmovaps [rsp+0xE0], xmm1
000074c379dcf5ea  vmovaps xmm1, [rsp+0xD0]
000074c379dcf5f3  vmovaps [rsp+0xD0], xmm13
000074c379dcf5fc  movaps xmm15, xmm14
000074c379dcf600  mulpd xmm15, xmm1
000074c379dcf605  vcmppd xmm13, xmm15, xmm15, 0x03
000074c379dcf60b  ptest xmm13, xmm13
000074c379dcf611  jnz 0x000074C379DD0907
000074c379dcf617  movaps xmm1, xmm14
000074c379dcf61b  mulpd xmm1, xmm10
000074c379dcf620  vcmppd xmm13, xmm1, xmm1, 0x03
000074c379dcf625  ptest xmm13, xmm13
000074c379dcf62b  jnz 0x000074C379DD0A4A
000074c379dcf631  movaps xmm13, xmm14
000074c379dcf635  mulpd xmm13, xmm2
000074c379dcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000074c379dcf640  ptest xmm10, xmm10
000074c379dcf646  jnz 0x000074C379DD0B8C
000074c379dcf64c  vmovaps [rsp+0x120], xmm7
000074c379dcf655  vmovaps xmm14, [rsp+0x120]
000074c379dcf65e  por xmm7, xmm14
000074c379dcf663  vmovaps xmm14, [rsp+0xC0]
000074c379dcf66c  vmovaps xmm10, [rsp+0xC0]
000074c379dcf675  por xmm14, xmm10
000074c379dcf67a  vmovaps xmm2, [rsp+0x100]
000074c379dcf683  vpermilpd xmm2, xmm2, 0x00
000074c379dcf689  vmovaps [rsp+0xC0], xmm1
000074c379dcf692  vmovaps [rsp+0x120], xmm15
000074c379dcf69b  movaps xmm1, xmm10
000074c379dcf69f  mulpd xmm1, xmm2
000074c379dcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000074c379dcf6a8  ptest xmm15, xmm15
000074c379dcf6ae  jnz 0x000074C379DD0CCF
000074c379dcf6b4  xor eax, eax
000074c379dcf6b6  mov r12d, 0x40
000074c379dcf6bc  mov r11d, 0x200
000074c379dcf6c2  cmp r12, r11
000074c379dcf6c5  cmc
000074c379dcf6c6  lahf
000074c379dcf6c7  seto al
000074c379dcf6ca  mov [r15+0x108], eax
000074c379dcf6d1  vmovaps xmm10, [rsp+0x110]
000074c379dcf6da  vmovaps xmm2, [rsp+0xE0]
000074c379dcf6e3  vmovaps [rsp+0xE0], xmm1
000074c379dcf6ec  movaps xmm15, xmm10
000074c379dcf6f0  addpd xmm15, xmm2
000074c379dcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000074c379dcf6fb  ptest xmm1, xmm1
000074c379dcf700  jnz 0x000074C379DD0E10
000074c379dcf706  vmovaps xmm10, [rsp+0x120]
000074c379dcf70f  vmovaps [rsp+0x110], xmm15
000074c379dcf718  movaps xmm1, xmm10
000074c379dcf71c  addpd xmm1, xmm12
000074c379dcf721  vcmppd xmm15, xmm1, xmm1, 0x03
000074c379dcf726  ptest xmm15, xmm15
000074c379dcf72c  jnz 0x000074C379DD0F53
000074c379dcf732  vmovaps xmm10, [rsp+0xC0]
000074c379dcf73b  vmovaps [rsp+0xC0], xmm1
000074c379dcf744  movaps xmm15, xmm10
000074c379dcf748  addpd xmm15, xmm12
000074c379dcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000074c379dcf753  ptest xmm1, xmm1
000074c379dcf758  jnz 0x000074C379DD1095
000074c379dcf75e  vmovaps xmm1, [rsp+0x30]
000074c379dcf764  vmovaps xmm12, [rsp+0x30]
000074c379dcf76a  por xmm1, xmm12
000074c379dcf76f  vmovaps xmm12, [rsp+0x20]
000074c379dcf775  vmovaps xmm10, [rsp+0x20]
000074c379dcf77b  por xmm12, xmm10
000074c379dcf780  vmovaps [rsp+0x20], xmm5
000074c379dcf786  vmovaps xmm10, [rsp+0x20]
000074c379dcf78c  por xmm5, xmm10
000074c379dcf791  vmovaps [rsp+0x20], xmm11
000074c379dcf797  vmovaps xmm10, [rsp+0x20]
000074c379dcf79d  por xmm11, xmm10
000074c379dcf7a2  vmovaps [rsp+0x20], xmm4
000074c379dcf7a8  vmovaps xmm10, [rsp+0x20]
000074c379dcf7ae  por xmm4, xmm10
000074c379dcf7b3  vmovaps [rsp+0x20], xmm8
000074c379dcf7b9  vmovaps xmm10, [rsp+0x20]
000074c379dcf7bf  por xmm8, xmm10
000074c379dcf7c4  vmovaps xmm10, [rsp+0xF0]
000074c379dcf7cd  vmovaps [rsp+0x20], xmm1
000074c379dcf7d3  vmovaps xmm1, [rsp+0xF0]
000074c379dcf7dc  por xmm10, xmm1
000074c379dcf7e1  lea rax, [r14+0xA0]
000074c379dcf7e8  movups xmm1, [r13+rax*1]
000074c379dcf7ee  lea rax, [r14+0xB0]
000074c379dcf7f5  vmovaps [rsp+0x30], xmm1
000074c379dcf7fb  movups xmm1, [r13+rax*1]
000074c379dcf801  vmovaps [rsp+0xF0], xmm1
000074c379dcf80a  vmovaps [rsp+0x120], xmm15
000074c379dcf813  movaps xmm1, xmm13
000074c379dcf817  addpd xmm1, xmm2
000074c379dcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000074c379dcf820  ptest xmm15, xmm15
000074c379dcf826  jnz 0x000074C379DD11ED
000074c379dcf82c  lea rax, [r14+0xF0]
000074c379dcf833  movups xmm15, [r13+rax*1]
000074c379dcf839  vmovaps xmm2, [rsp+0xC0]
000074c379dcf842  vmovaps [rsp+0xC0], xmm1
000074c379dcf84b  vmovaps xmm1, [rsp+0xE0]
000074c379dcf854  vmovaps [rsp+0xE0], xmm15
000074c379dcf85d  movaps xmm13, xmm2
000074c379dcf861  addpd xmm13, xmm1
000074c379dcf866  vcmppd xmm15, xmm13, xmm13, 0x03
000074c379dcf86c  ptest xmm15, xmm15
000074c379dcf872  jnz 0x000074C379DD1338
000074c379dcf878  vmovaps xmm15, [rsp+0x120]
000074c379dcf881  vmovaps xmm2, [rsp+0xD0]
000074c379dcf88a  vmovaps [rsp+0xD0], xmm14
000074c379dcf893  movaps xmm1, xmm15
000074c379dcf897  addpd xmm1, xmm2
000074c379dcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000074c379dcf8a0  ptest xmm14, xmm14
000074c379dcf8a6  jnz 0x000074C379DD147A
000074c379dcf8ac  vmovaps xmm15, [rsp+0x100]
000074c379dcf8b5  vpermilpd xmm15, xmm15, 0x00
000074c379dcf8bb  vmovaps xmm2, [rsp+0xF0]
000074c379dcf8c4  vmovaps [rsp+0xF0], xmm1
000074c379dcf8cd  movaps xmm14, xmm2
000074c379dcf8d1  mulpd xmm14, xmm15
000074c379dcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000074c379dcf8dc  ptest xmm1, xmm1
000074c379dcf8e1  jnz 0x000074C379DD15BB
000074c379dcf8e7  vmovaps xmm1, [rsp+0xA0]
000074c379dcf8f0  vpermilpd xmm1, xmm1, 0x00
000074c379dcf8f6  vmovaps xmm2, [rsp+0xE0]
000074c379dcf8ff  vmovaps [rsp+0xE0], xmm14
000074c379dcf908  movaps xmm15, xmm2
000074c379dcf90c  mulpd xmm15, xmm1
000074c379dcf911  vcmppd xmm14, xmm15, xmm15, 0x03
000074c379dcf917  ptest xmm14, xmm14
000074c379dcf91d  jnz 0x000074C379DD16FE
000074c379dcf923  lea rax, [r14+0xE0]
000074c379dcf92a  movups xmm1, [r13+rax*1]
000074c379dcf930  vmovaps xmm14, [rsp+0x100]
000074c379dcf939  vpermilpd xmm14, xmm14, 0x00
000074c379dcf93f  vmovaps [rsp+0x100], xmm1
000074c379dcf948  vmovaps xmm1, [rsp+0x30]
000074c379dcf94e  vmovaps [rsp+0x30], xmm15
000074c379dcf954  movaps xmm2, xmm1
000074c379dcf957  mulpd xmm2, xmm14
000074c379dcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000074c379dcf961  ptest xmm15, xmm15
000074c379dcf967  jnz 0x000074C379DD184A
000074c379dcf96d  vmovaps [rsp+0x120], xmm10
000074c379dcf976  vmovaps xmm1, [rsp+0x120]
000074c379dcf97f  por xmm10, xmm1
000074c379dcf984  movaps [r15+0x300], xmm10
000074c379dcf98c  vmovaps [rsp+0x120], xmm8
000074c379dcf995  vmovaps xmm1, [rsp+0x120]
000074c379dcf99e  por xmm8, xmm1
000074c379dcf9a3  movaps [r15+0x190], xmm8
000074c379dcf9ab  vmovaps xmm1, [rsp+0xA0]
000074c379dcf9b4  vpermilpd xmm1, xmm1, 0x00
000074c379dcf9ba  vmovaps xmm14, [rsp+0x100]
000074c379dcf9c3  vmovaps [rsp+0x100], xmm13
000074c379dcf9cc  movaps xmm15, xmm14
000074c379dcf9d0  mulpd xmm15, xmm1
000074c379dcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000074c379dcf9db  ptest xmm13, xmm13
000074c379dcf9e1  jnz 0x000074C379DD198B
000074c379dcf9e7  lea rax, [r14+0x90]
000074c379dcf9ee  movups xmm1, [r13+rax*1]
000074c379dcf9f4  vmovaps [rsp+0x120], xmm4
000074c379dcf9fd  vmovaps xmm14, [rsp+0x120]
000074c379dcfa06  por xmm4, xmm14
000074c379dcfa0b  movaps [r15+0x1C0], xmm4
000074c379dcfa13  vmovaps [rsp+0x120], xmm11
000074c379dcfa1c  vmovaps xmm14, [rsp+0x120]
000074c379dcfa25  por xmm11, xmm14
000074c379dcfa2a  movaps [r15+0x200], xmm11
000074c379dcfa32  vmovaps [rsp+0x120], xmm5
000074c379dcfa3b  vmovaps xmm14, [rsp+0x120]
000074c379dcfa44  por xmm5, xmm14
000074c379dcfa49  movaps [r15+0x2D0], xmm5
000074c379dcfa51  vmovaps [rsp+0x120], xmm12
000074c379dcfa5a  vmovaps xmm14, [rsp+0x120]
000074c379dcfa63  por xmm12, xmm14
000074c379dcfa68  movaps [r15+0x2E0], xmm12
000074c379dcfa70  vmovaps xmm13, [rsp+0x110]
000074c379dcfa79  vmovaps [rsp+0x110], xmm1
000074c379dcfa82  vmovaps xmm1, [rsp+0xE0]
000074c379dcfa8b  vmovaps [rsp+0xE0], xmm15
000074c379dcfa94  movaps xmm14, xmm13
000074c379dcfa98  addpd xmm14, xmm1
000074c379dcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000074c379dcfaa3  ptest xmm15, xmm15
000074c379dcfaa9  jnz 0x000074C379DD1AD8
000074c379dcfaaf  vmovaps xmm1, [rsp+0xA0]
000074c379dcfab8  vpermilpd xmm1, xmm1, 0x00
000074c379dcfabe  vmovaps xmm13, [rsp+0x110]
000074c379dcfac7  vmovaps [rsp+0x110], xmm14
000074c379dcfad0  movaps xmm15, xmm13
000074c379dcfad4  mulpd xmm15, xmm1
000074c379dcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000074c379dcfadf  ptest xmm14, xmm14
000074c379dcfae5  jnz 0x000074C379DD1C1B
000074c379dcfaeb  lea rax, [r14+0x80]
000074c379dcfaf2  movups xmm1, [r13+rax*1]
000074c379dcfaf8  vmovaps xmm13, [rsp+0xC0]
000074c379dcfb01  vmovaps [rsp+0xC0], xmm1
000074c379dcfb0a  movaps xmm14, xmm13
000074c379dcfb0e  addpd xmm14, xmm2
000074c379dcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000074c379dcfb19  ptest xmm1, xmm1
000074c379dcfb1e  jnz 0x000074C379DD1D68
000074c379dcfb24  vmovaps xmm13, [rsp+0x100]
000074c379dcfb2d  vmovaps xmm2, [rsp+0x30]
000074c379dcfb33  vmovaps [rsp+0x30], xmm15
000074c379dcfb39  movaps xmm1, xmm13
000074c379dcfb3d  addpd xmm1, xmm2
000074c379dcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000074c379dcfb46  ptest xmm15, xmm15
000074c379dcfb4c  jnz 0x000074C379DD1EAB
000074c379dcfb52  vmovaps xmm15, [rsp+0x20]
000074c379dcfb58  vmovaps xmm13, [rsp+0x20]
000074c379dcfb5e  por xmm15, xmm13
000074c379dcfb63  movaps [r15+0x2F0], xmm15
000074c379dcfb6b  vmovaps xmm13, [rsp+0xA0]
000074c379dcfb74  vpermilpd xmm13, xmm13, 0x00
000074c379dcfb7a  vmovaps [rsp+0x20], xmm1
000074c379dcfb80  vmovaps xmm1, [rsp+0xC0]
000074c379dcfb89  vmovaps [rsp+0xA0], xmm15
000074c379dcfb92  movaps xmm2, xmm1
000074c379dcfb95  mulpd xmm2, xmm13
000074c379dcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000074c379dcfb9f  ptest xmm15, xmm15
000074c379dcfba5  jnz 0x000074C379DD1FEC
000074c379dcfbab  lea rax, [r14+0xD0]
000074c379dcfbb2  movups xmm1, [r13+rax*1]
000074c379dcfbb8  vmovaps xmm13, [rsp+0xF0]
000074c379dcfbc1  vmovaps [rsp+0xC0], xmm1
000074c379dcfbca  vmovaps xmm1, [rsp+0xE0]
000074c379dcfbd3  vmovaps [rsp+0xE0], xmm14
000074c379dcfbdc  movaps xmm15, xmm13
000074c379dcfbe0  addpd xmm15, xmm1
000074c379dcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000074c379dcfbeb  ptest xmm14, xmm14
000074c379dcfbf1  jnz 0x000074C379DD2137
000074c379dcfbf7  vmovaps xmm1, [rsp+0xB0]
000074c379dcfc00  vpermilpd xmm1, xmm1, 0x00
000074c379dcfc06  movaps xmm14, xmm11
000074c379dcfc0a  mulpd xmm14, xmm1
000074c379dcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000074c379dcfc15  ptest xmm13, xmm13
000074c379dcfc1b  jnz 0x000074C379DD227A
000074c379dcfc21  movaps [r15+0x260], xmm14
000074c379dcfc29  vxorps xmm1, xmm1, xmm1
000074c379dcfc2d  vpbroadcastq xmm1, xmm1
000074c379dcfc32  movaps [r15+0x1B0], xmm1
000074c379dcfc3a  vmovaps xmm1, [rsp+0xB0]
000074c379dcfc43  vpermilpd xmm1, xmm1, 0x00
000074c379dcfc49  vmovaps xmm11, [rsp+0xC0]
000074c379dcfc52  vmovaps [rsp+0xC0], xmm15
000074c379dcfc5b  movaps xmm13, xmm11
000074c379dcfc5f  mulpd xmm13, xmm1
000074c379dcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000074c379dcfc6a  ptest xmm15, xmm15
000074c379dcfc70  jnz 0x000074C379DD23BD
000074c379dcfc76  lea rax, [r14+0xC0]
000074c379dcfc7d  movups xmm1, [r13+rax*1]
000074c379dcfc83  vmovaps xmm11, [rsp+0x110]
000074c379dcfc8c  vmovaps [rsp+0xF0], xmm1
000074c379dcfc95  vmovaps xmm1, [rsp+0x30]
000074c379dcfc9b  vmovaps [rsp+0x30], xmm14
000074c379dcfca1  movaps xmm15, xmm11
000074c379dcfca5  addpd xmm15, xmm1
000074c379dcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000074c379dcfcb0  ptest xmm14, xmm14
000074c379dcfcb6  jnz 0x000074C379DD250A
000074c379dcfcbc  vmovaps [rsp+0x100], xmm9
000074c379dcfcc5  vmovaps xmm1, [rsp+0x100]
000074c379dcfcce  por xmm9, xmm1
000074c379dcfcd3  movaps [r15+0x270], xmm9
000074c379dcfcdb  vmovaps [rsp+0x100], xmm6
000074c379dcfce4  vmovaps xmm1, [rsp+0x100]
000074c379dcfced  por xmm6, xmm1
000074c379dcfcf1  movaps [r15+0x1A0], xmm6
000074c379dcfcf9  vmovaps xmm14, [rsp+0xB0]
000074c379dcfd02  vpermilpd xmm14, xmm14, 0x00
000074c379dcfd08  vmovaps xmm6, [rsp+0xF0]
000074c379dcfd11  vmovaps [rsp+0xF0], xmm1
000074c379dcfd1a  movaps xmm11, xmm6
000074c379dcfd1e  mulpd xmm11, xmm14
000074c379dcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000074c379dcfd29  ptest xmm1, xmm1
000074c379dcfd2e  jnz 0x000074C379DD264D
000074c379dcfd34  lea rax, [r14+0x20]
000074c379dcfd38  movups xmm1, [r13+rax*1]
000074c379dcfd3e  movaps [r15+0x110], xmm1
000074c379dcfd46  vmovaps xmm6, [rsp+0xE0]
000074c379dcfd4f  vmovaps [rsp+0xE0], xmm1
000074c379dcfd58  movaps xmm14, xmm6
000074c379dcfd5c  addpd xmm14, xmm2
000074c379dcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000074c379dcfd67  ptest xmm1, xmm1
000074c379dcfd6c  jnz 0x000074C379DD279A
000074c379dcfd72  vmovaps xmm1, [rsp+0xB0]
000074c379dcfd7b  vpermilpd xmm1, xmm1, 0x00
000074c379dcfd81  movaps xmm6, xmm5
000074c379dcfd84  mulpd xmm6, xmm1
000074c379dcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000074c379dcfd8d  ptest xmm2, xmm2
000074c379dcfd92  jnz 0x000074C379DD28DC
000074c379dcfd98  vmovaps xmm5, [rsp+0x20]
000074c379dcfd9e  movaps xmm1, xmm5
000074c379dcfda1  addpd xmm1, xmm13
000074c379dcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000074c379dcfdab  ptest xmm2, xmm2
000074c379dcfdb0  jnz 0x000074C379DD2A1C
000074c379dcfdb6  vmovaps xmm13, [rsp+0x80]
000074c379dcfdbf  vpermilpd xmm13, xmm13, 0x00
000074c379dcfdc5  vmovaps xmm2, [rsp+0xE0]
000074c379dcfdce  vmovaps [rsp+0x20], xmm1
000074c379dcfdd4  movaps xmm5, xmm2
000074c379dcfdd7  mulpd xmm5, xmm13
000074c379dcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000074c379dcfde1  ptest xmm1, xmm1
000074c379dcfde6  jnz 0x000074C379DD2B5D
000074c379dcfdec  vmovaps xmm1, [rsp+0x80]
000074c379dcfdf5  vpermilpd xmm1, xmm1, 0x00
000074c379dcfdfb  movaps xmm13, xmm10
000074c379dcfdff  mulpd xmm13, xmm1
000074c379dcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000074c379dcfe0a  ptest xmm2, xmm2
000074c379dcfe0f  jnz 0x000074C379DD2C9E
000074c379dcfe15  vmovaps xmm10, [rsp+0x30]
000074c379dcfe1b  movaps xmm1, xmm15
000074c379dcfe1f  addpd xmm1, xmm10
000074c379dcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000074c379dcfe29  ptest xmm2, xmm2
000074c379dcfe2e  jnz 0x000074C379DD2DE1
000074c379dcfe34  vmovaps xmm10, [rsp+0xC0]
000074c379dcfe3d  movaps xmm15, xmm10
000074c379dcfe41  addpd xmm15, xmm11
000074c379dcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000074c379dcfe4c  ptest xmm2, xmm2
000074c379dcfe51  jnz 0x000074C379DD2F23
000074c379dcfe57  vmovaps xmm11, [rsp+0x80]
000074c379dcfe60  vpermilpd xmm11, xmm11, 0x00
000074c379dcfe66  movaps xmm10, xmm12
000074c379dcfe6a  mulpd xmm10, xmm11
000074c379dcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000074c379dcfe75  ptest xmm2, xmm2
000074c379dcfe7a  jnz 0x000074C379DD3067
000074c379dcfe80  vmovaps xmm12, [rsp+0x80]
000074c379dcfe89  vpermilpd xmm12, xmm12, 0x00
000074c379dcfe8f  vmovaps xmm2, [rsp+0xA0]
000074c379dcfe98  vmovaps [rsp+0x30], xmm1
000074c379dcfe9e  movaps xmm11, xmm2
000074c379dcfea2  mulpd xmm11, xmm12
000074c379dcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000074c379dcfead  ptest xmm1, xmm1
000074c379dcfeb2  jnz 0x000074C379DD31AB
000074c379dcfeb8  movaps xmm1, xmm14
000074c379dcfebc  addpd xmm1, xmm6
000074c379dcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000074c379dcfec5  ptest xmm12, xmm12
000074c379dcfecb  jnz 0x000074C379DD32EE
000074c379dcfed1  vmovaps xmm12, [rsp+0x20]
000074c379dcfed7  movaps xmm14, xmm12
000074c379dcfedb  addpd xmm14, xmm5
000074c379dcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000074c379dcfee6  ptest xmm6, xmm6
000074c379dcfeeb  jnz 0x000074C379DD342F
000074c379dcfef1  vmovaps xmm12, [rsp+0x90]
000074c379dcfefa  vpermilpd xmm12, xmm12, 0x00
000074c379dcff00  movaps xmm6, xmm9
000074c379dcff04  mulpd xmm6, xmm12
000074c379dcff09  vcmppd xmm5, xmm6, xmm6, 0x03
000074c379dcff0e  ptest xmm5, xmm5
000074c379dcff13  jnz 0x000074C379DD3572
000074c379dcff19  movaps xmm12, xmm15
000074c379dcff1d  addpd xmm12, xmm13
000074c379dcff22  vcmppd xmm9, xmm12, xmm12, 0x03
000074c379dcff28  ptest xmm9, xmm9
000074c379dcff2e  jnz 0x000074C379DD36B4
000074c379dcff34  vmovaps xmm13, [rsp+0x30]
000074c379dcff3a  movaps xmm15, xmm13
000074c379dcff3e  addpd xmm15, xmm10
000074c379dcff43  vcmppd xmm9, xmm15, xmm15, 0x03
000074c379dcff49  ptest xmm9, xmm9
000074c379dcff4f  jnz 0x000074C379DD37F8
000074c379dcff55  vmovaps xmm13, [rsp+0xD0]
000074c379dcff5e  vmovaps xmm10, [rsp+0xD0]
000074c379dcff67  por xmm13, xmm10
000074c379dcff6c  movaps [r15+0x250], xmm13
000074c379dcff74  vmovaps [rsp+0x20], xmm7
000074c379dcff7a  vmovaps xmm13, [rsp+0x20]
000074c379dcff80  por xmm7, xmm13
000074c379dcff85  movaps [r15+0x2A0], xmm7
000074c379dcff8d  vmovaps [rsp+0x20], xmm3
000074c379dcff93  vmovaps xmm13, [rsp+0x20]
000074c379dcff99  por xmm3, xmm13
000074c379dcff9e  movaps [r15+0x1D0], xmm3
000074c379dcffa6  lea rax, [r14+0x40]
000074c379dcffaa  movups xmm13, [r13+rax*1]
000074c379dcffb0  movaps [r15+0x2C0], xmm13
000074c379dcffb8  vmovaps xmm10, [rsp+0x90]
000074c379dcffc1  vpermilpd xmm10, xmm10, 0x00
000074c379dcffc7  movaps xmm9, xmm8
000074c379dcffcb  mulpd xmm9, xmm10
000074c379dcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000074c379dcffd6  ptest xmm5, xmm5
000074c379dcffdb  jnz 0x000074C379DD3946
000074c379dcffe1  movaps xmm10, xmm1
000074c379dcffe5  addpd xmm10, xmm11
000074c379dcffea  vcmppd xmm8, xmm10, xmm10, 0x03
000074c379dcfff0  ptest xmm8, xmm8
000074c379dcfff6  jnz 0x000074C379DD3A8A
000074c379dcfffc  movaps xmm1, xmm14
000074c379dd0000  addpd xmm1, xmm6
000074c379dd0004  vcmppd xmm11, xmm1, xmm1, 0x03
000074c379dd0009  ptest xmm11, xmm11
000074c379dd000f  jnz 0x000074C379DD3BCD
000074c379dd0015  vmovaps xmm14, [rsp+0x90]
000074c379dd001e  vpermilpd xmm14, xmm14, 0x00
000074c379dd0024  movaps xmm11, xmm13
000074c379dd0028  mulpd xmm11, xmm14
000074c379dd002d  vcmppd xmm8, xmm11, xmm11, 0x03
000074c379dd0033  ptest xmm8, xmm8
000074c379dd0039  jnz 0x000074C379DD3D0E
000074c379dd003f  vmovaps xmm14, [rsp+0x90]
000074c379dd0048  vpermilpd xmm14, xmm14, 0x00
000074c379dd004e  vmovaps xmm8, [rsp+0x10]
000074c379dd0054  movaps xmm13, xmm8
000074c379dd0058  mulpd xmm13, xmm14
000074c379dd005d  vcmppd xmm6, xmm13, xmm13, 0x03
000074c379dd0063  ptest xmm6, xmm6
000074c379dd0068  jnz 0x000074C379DD3E52
000074c379dd006e  vmovaps xmm14, [rsp+0x60]
000074c379dd0074  vpermilpd xmm14, xmm14, 0x00
000074c379dd007a  movaps xmm8, xmm7
000074c379dd007e  mulpd xmm8, xmm14
000074c379dd0083  vcmppd xmm6, xmm8, xmm8, 0x03
000074c379dd0089  ptest xmm6, xmm6
000074c379dd008e  jnz 0x000074C379DD3F96
000074c379dd0094  movaps xmm14, xmm12
000074c379dd0098  addpd xmm14, xmm9
000074c379dd009d  vcmppd xmm7, xmm14, xmm14, 0x03
000074c379dd00a3  ptest xmm7, xmm7
000074c379dd00a8  jnz 0x000074C379DD40D9
000074c379dd00ae  vmovaps xmm12, [rsp+0x60]
000074c379dd00b4  vpermilpd xmm12, xmm12, 0x00
000074c379dd00ba  vmovaps xmm7, [rsp+0xF0]
000074c379dd00c3  movaps xmm9, xmm7
000074c379dd00c7  mulpd xmm9, xmm12
000074c379dd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000074c379dd00d2  ptest xmm6, xmm6
000074c379dd00d7  jnz 0x000074C379DD421D
000074c379dd00dd  movaps xmm12, xmm15
000074c379dd00e1  addpd xmm12, xmm11
000074c379dd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000074c379dd00ec  ptest xmm7, xmm7
000074c379dd00f1  jnz 0x000074C379DD4360
000074c379dd00f7  vmovaps xmm15, [rsp+0x60]
000074c379dd00fd  vpermilpd xmm15, xmm15, 0x00
000074c379dd0103  vmovaps xmm7, [rsp+0x40]
000074c379dd0109  movaps xmm11, xmm7
000074c379dd010d  mulpd xmm11, xmm15
000074c379dd0112  vcmppd xmm6, xmm11, xmm11, 0x03
000074c379dd0118  ptest xmm6, xmm6
000074c379dd011d  jnz 0x000074C379DD44A4
000074c379dd0123  movaps xmm15, xmm10
000074c379dd0127  addpd xmm15, xmm13
000074c379dd012c  vcmppd xmm7, xmm15, xmm15, 0x03
000074c379dd0132  ptest xmm7, xmm7
000074c379dd0137  jnz 0x000074C379DD45E7
000074c379dd013d  vmovaps xmm13, [rsp+0x60]
000074c379dd0143  vpermilpd xmm13, xmm13, 0x00
000074c379dd0149  vmovaps xmm7, [rsp+0x50]
000074c379dd014f  movaps xmm10, xmm7
000074c379dd0153  mulpd xmm10, xmm13
000074c379dd0158  vcmppd xmm6, xmm10, xmm10, 0x03
000074c379dd015e  ptest xmm6, xmm6
000074c379dd0163  jnz 0x000074C379DD472B
000074c379dd0169  movaps xmm13, xmm1
000074c379dd016d  addpd xmm13, xmm8
000074c379dd0172  vcmppd xmm7, xmm13, xmm13, 0x03
000074c379dd0178  ptest xmm7, xmm7
000074c379dd017d  jnz 0x000074C379DD486E
000074c379dd0183  lea rax, [r14+0x70]
000074c379dd0187  movups xmm1, [r13+rax*1]
000074c379dd018d  movaps [r15+0x240], xmm1
000074c379dd0195  movaps xmm8, xmm14
000074c379dd0199  addpd xmm8, xmm9
000074c379dd019e  vcmppd xmm7, xmm8, xmm8, 0x03
000074c379dd01a4  ptest xmm7, xmm7
000074c379dd01a9  jnz 0x000074C379DD49BB
000074c379dd01af  movaps [r15+0x170], xmm8
000074c379dd01b7  vmovaps xmm14, [rsp+0x70]
000074c379dd01bd  vpermilpd xmm14, xmm14, 0x00
000074c379dd01c3  movaps xmm9, xmm1
000074c379dd01c7  mulpd xmm9, xmm14
000074c379dd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000074c379dd01d2  ptest xmm7, xmm7
000074c379dd01d7  jnz 0x000074C379DD4AFF
000074c379dd01dd  vmovaps xmm1, [rsp+0x70]
000074c379dd01e3  vpermilpd xmm1, xmm1, 0x00
000074c379dd01e9  movaps xmm14, xmm4
000074c379dd01ed  mulpd xmm14, xmm1
000074c379dd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000074c379dd01f8  ptest xmm7, xmm7
000074c379dd01fd  jnz 0x000074C379DD4C42
000074c379dd0203  movaps [r15+0x180], xmm14
000074c379dd020b  movaps xmm1, xmm12
000074c379dd020f  addpd xmm1, xmm11
000074c379dd0214  vcmppd xmm7, xmm1, xmm1, 0x03
000074c379dd0219  ptest xmm7, xmm7
000074c379dd021e  jnz 0x000074C379DD4D84
000074c379dd0224  movaps [r15+0x210], xmm1
000074c379dd022c  movups xmm12, [r13+r14*1]
000074c379dd0232  lea rax, [r14+0x10]
000074c379dd0236  movups xmm11, [r13+rax*1]
000074c379dd023c  movaps [r15+0x230], xmm11
000074c379dd0244  movaps xmm7, xmm15
000074c379dd0248  addpd xmm7, xmm10
000074c379dd024d  vcmppd xmm6, xmm7, xmm7, 0x03
000074c379dd0252  ptest xmm6, xmm6
000074c379dd0257  jnz 0x000074C379DD4EDA
000074c379dd025d  movaps [r15+0x130], xmm7
000074c379dd0265  vmovaps xmm15, [rsp+0x70]
000074c379dd026b  vpermilpd xmm15, xmm15, 0x00
000074c379dd0271  movaps xmm10, xmm11
000074c379dd0275  mulpd xmm10, xmm15
000074c379dd027a  vcmppd xmm6, xmm10, xmm10, 0x03
000074c379dd0280  ptest xmm6, xmm6
000074c379dd0285  jnz 0x000074C379DD501C
000074c379dd028b  movaps [r15+0x220], xmm10
000074c379dd0293  vmovaps xmm15, [rsp+0x70]
000074c379dd0299  vpermilpd xmm15, xmm15, 0x00
000074c379dd029f  movaps xmm11, xmm12
000074c379dd02a3  mulpd xmm11, xmm15
000074c379dd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000074c379dd02ae  ptest xmm6, xmm6
000074c379dd02b3  jnz 0x000074C379DD5160
000074c379dd02b9  movaps xmm15, xmm13
000074c379dd02bd  addpd xmm15, xmm9
000074c379dd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000074c379dd02c8  ptest xmm12, xmm12
000074c379dd02ce  jnz 0x000074C379DD52A4
000074c379dd02d4  movaps [r15+0x140], xmm15
000074c379dd02dc  movaps xmm13, xmm8
000074c379dd02e0  addpd xmm13, xmm14
000074c379dd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000074c379dd02eb  ptest xmm12, xmm12
000074c379dd02f1  jnz 0x000074C379DD53E8
000074c379dd02f7  movaps [r15+0x150], xmm13
000074c379dd02ff  movaps xmm14, xmm1
000074c379dd0303  addpd xmm14, xmm10
000074c379dd0308  vcmppd xmm12, xmm14, xmm14, 0x03
000074c379dd030e  ptest xmm12, xmm12
000074c379dd0314  jnz 0x000074C379DD552C
000074c379dd031a  movaps [r15+0x160], xmm14
000074c379dd0322  movaps xmm1, xmm7
000074c379dd0325  addpd xmm1, xmm11
000074c379dd032a  vcmppd xmm12, xmm1, xmm1, 0x03
000074c379dd032f  ptest xmm12, xmm12
000074c379dd0335  jnz 0x000074C379DD566F
000074c379dd033b  movaps [r15+0x120], xmm1
000074c379dd0343  mov eax, 0x430920
000074c379dd0348  movups [r13+rax*1], xmm15
000074c379dd034e  mov eax, 0x430930
000074c379dd0353  movups [r13+rax*1], xmm13
000074c379dd0359  mov eax, 0x430940
000074c379dd035e  movups [r13+rax*1], xmm14
000074c379dd0364  mov eax, 0x430950
000074c379dd0369  movups [r13+rax*1], xmm1
000074c379dd036f  mov eax, [r15+0x108]
000074c379dd0376  sahf
000074c379dd0377  jnz 0x000074C379DD03A9
000074c379dd0379  cmp dword ptr [r15+0x318], 0x00
000074c379dd0381  jz 0x000074C379DDB900
000074c379dd0387  nop [rax+rax*1], ax
000074c379dd0390  nop [rax+rax*1], eax
000074c379dd0398  mov eax, 0x410444
000074c379dd039d  mov [r15+0x100], rax
000074c379dd03a4  jmp 0x000074C379BFE110
000074c379dd03a9  cmp dword ptr [r15+0x318], 0x00
000074c379dd03b1  jz 0x000074C379DD57E0
000074c379dd03b7  nop [rax+rax*1], ax
000074c379dd03c0  nop [rax+rax*1], eax
000074c379dd03c8  mov eax, 0x410278
000074c379dd03cd  mov [r15+0x100], rax
000074c379dd03d4  jmp 0x000074C379BFE110
000074c379dd03d9  int3
000074c379dd03da  call 0x000074C379CB52F0
000074c379dd03df  jmp 0x000074C379DCF016
000074c379dd03e4  call 0x000074C379CC4620
000074c379dd03e9  jmp 0x000074C379DCF023
000074c379dd03ee  call 0x000074C379CC33A0
000074c379dd03f3  jmp 0x000074C379DCF035
000074c379dd03f8  call 0x000074C379CC2120
000074c379dd03fd  jmp 0x000074C379DCF03F
000074c379dd0402  call 0x000074C379CC0860
000074c379dd0407  jmp 0x000074C379DCF067
000074c379dd040c  call 0x000074C379CBF5F0
000074c379dd0411  jmp 0x000074C379DCF073
000074c379dd0416  call 0x000074C379CC0860
000074c379dd041b  jmp 0x000074C379DCF0A5
000074c379dd0420  call 0x000074C379CBF5F0
000074c379dd0425  jmp 0x000074C379DCF0B1
000074c379dd042a  call 0x000074C379CC4740
000074c379dd042f  jmp 0x000074C379DCF0BE
000074c379dd0434  call 0x000074C379CB5400
000074c379dd0439  jmp 0x000074C379DCF0CB
000074c379dd043e  call 0x000074C379CB52F0
000074c379dd0443  jmp 0x000074C379DCF0D8
000074c379dd0448  call 0x000074C379CC4620
000074c379dd044d  jmp 0x000074C379DCF0E5
000074c379dd0452  call 0x000074C379CC0860
000074c379dd0457  jmp 0x000074C379DCF10D
000074c379dd045c  call 0x000074C379CBF5F0
000074c379dd0461  jmp 0x000074C379DCF119
000074c379dd0466  call 0x000074C379C09D70
000074c379dd046b  jmp 0x000074C379DCF11F
000074c379dd0470  call 0x000074C379CBE9C0
000074c379dd0475  jmp 0x000074C379DCF129
000074c379dd047a  call 0x000074C379CC0860
000074c379dd047f  jmp 0x000074C379DCF151
000074c379dd0484  call 0x000074C379CBF5F0
000074c379dd0489  jmp 0x000074C379DCF15D
000074c379dd048e  call 0x000074C379CBD750
000074c379dd0493  jmp 0x000074C379DCF16A
000074c379dd0498  call 0x000074C379CBC4E0
000074c379dd049d  jmp 0x000074C379DCF177
000074c379dd04a2  call 0x000074C379CC4740
000074c379dd04a7  jmp 0x000074C379DCF184
000074c379dd04ac  call 0x000074C379CB5400
000074c379dd04b1  jmp 0x000074C379DCF191
000074c379dd04b6  call 0x000074C379CB52F0
000074c379dd04bb  jmp 0x000074C379DCF19E
000074c379dd04c0  call 0x000074C379CC4620
000074c379dd04c5  jmp 0x000074C379DCF1AB
000074c379dd04ca  call 0x000074C379CC0860
000074c379dd04cf  jmp 0x000074C379DCF1BE
000074c379dd04d4  call 0x000074C379CBB270
000074c379dd04d9  jmp 0x000074C379DCF1CB
000074c379dd04de  call 0x000074C379CBA000
000074c379dd04e3  jmp 0x000074C379DCF1D8
000074c379dd04e8  call 0x000074C379CB8D90
000074c379dd04ed  jmp 0x000074C379DCF1E5
000074c379dd04f2  call 0x000074C379CB8A20
000074c379dd04f7  jmp 0x000074C379DCF1F2
000074c379dd04fc  call 0x000074C379CB5400
000074c379dd0501  jmp 0x000074C379DCF1FC
000074c379dd0506  call 0x000074C379CC2240
000074c379dd050b  jmp 0x000074C379DCF206
000074c379dd0510  call 0x000074C379CB52F0
000074c379dd0515  jmp 0x000074C379DCF210
000074c379dd051a  call 0x000074C379CC2120
000074c379dd051f  jmp 0x000074C379DCF21A
000074c379dd0524  call 0x000074C379CB77B0
000074c379dd0529  jmp 0x000074C379DCF224
000074c379dd052e  call 0x000074C379CB6550
000074c379dd0533  jmp 0x000074C379DCF22E
000074c379dd0538  call 0x000074C379CBFD50
000074c379dd053d  jmp 0x000074C379DCF240
000074c379dd0542  call 0x000074C379CB8EA0
000074c379dd0547  jmp 0x000074C379DCF24A
000074c379dd054c  call 0x000074C379CBFC30
000074c379dd0551  jmp 0x000074C379DCF257
000074c379dd0556  call 0x000074C379CB8D90
000074c379dd055b  jmp 0x000074C379DCF264
000074c379dd0560  call 0x000074C379CC2240
000074c379dd0565  jmp 0x000074C379DCF271
000074c379dd056a  call 0x000074C379CB5400
000074c379dd056f  jmp 0x000074C379DCF27E
000074c379dd0574  call 0x000074C379CB52F0
000074c379dd0579  jmp 0x000074C379DCF28B
000074c379dd057e  call 0x000074C379CC2120
000074c379dd0583  jmp 0x000074C379DCF298
000074c379dd0588  call 0x000074C379CB52F0
000074c379dd058d  jmp 0x000074C379DCF2AB
000074c379dd0592  call 0x000074C379CB52F0
000074c379dd0597  jmp 0x000074C379DCF2BE
000074c379dd059c  call 0x000074C379CB52F0
000074c379dd05a1  jmp 0x000074C379DCF2D1
000074c379dd05a6  call 0x000074C379CB52F0
000074c379dd05ab  jmp 0x000074C379DCF2E4
000074c379dd05b0  call 0x000074C379CC2240
000074c379dd05b5  jmp 0x000074C379DCF2F9
000074c379dd05ba  call 0x000074C379CC2240
000074c379dd05bf  jmp 0x000074C379DCF30C
000074c379dd05c4  call 0x000074C379CC2120
000074c379dd05c9  jmp 0x000074C379DCF319
000074c379dd05ce  call 0x000074C379CB52F0
000074c379dd05d3  jmp 0x000074C379DCF32C
000074c379dd05d8  call 0x000074C379CB52F0
000074c379dd05dd  jmp 0x000074C379DCF34F
000074c379dd05e2  call 0x000074C379CB52F0
000074c379dd05e7  jmp 0x000074C379DCF362
000074c379dd05ec  call 0x000074C379BFF540
000074c379dd05f1  jmp 0x000074C379DCF380
000074c379dd05f6  call 0x000074C379C08C20
000074c379dd05fb  jmp 0x000074C379DCF38A
000074c379dd0600  call 0x000074C379CD6600
000074c379dd0605  jmp 0x000074C379DCF396
000074c379dd060a  call 0x000074C379BFF540
000074c379dd060f  jmp 0x000074C379DCF3A6
000074c379dd0614  call 0x000074C379CC0370
000074c379dd0619  jmp 0x000074C379DCF3D4
000074c379dd061e  call 0x000074C379CBF100
000074c379dd0623  jmp 0x000074C379DCF3DD
000074c379dd0628  call 0x000074C379CC0370
000074c379dd062d  jmp 0x000074C379DCF43B
000074c379dd0632  call 0x000074C379CBF100
000074c379dd0637  jmp 0x000074C379DCF444
000074c379dd063c  call 0x000074C379CC0370
000074c379dd0641  jmp 0x000074C379DCF48B
000074c379dd0646  call 0x000074C379CBF100
000074c379dd064b  jmp 0x000074C379DCF494
000074c379dd0650  call 0x000074C379C0B720
000074c379dd0655  jmp 0x000074C379DCF4D7
000074c379dd065a  call 0x000074C379CB47C0
000074c379dd065f  jmp 0x000074C379DCF4EA
000074c379dd0664  call 0x000074C379C08B00
000074c379dd0669  jmp 0x000074C379DCF501
000074c379dd066e  call 0x000074C379BFF430
000074c379dd0673  jmp 0x000074C379DCF514
000074c379dd0678  call 0x000074C379BFF430
000074c379dd067d  jmp 0x000074C379DCF527
000074c379dd0682  sub rsp, 0x08
000074c379dd0686  push rax
000074c379dd0687  push rcx
000074c379dd0688  push rdx
000074c379dd0689  push rdi
000074c379dd068a  push rsi
000074c379dd068b  push r8
000074c379dd068d  push r9
000074c379dd068f  push r10
000074c379dd0691  push r11
000074c379dd0693  sub rsp, 0xF0
000074c379dd069a  vmovaps [rsp], xmm0
000074c379dd069f  vmovaps [rsp+0x10], xmm2
000074c379dd06a5  vmovaps [rsp+0x20], xmm3
000074c379dd06ab  vmovaps [rsp+0x30], xmm4
000074c379dd06b1  vmovaps [rsp+0x40], xmm5
000074c379dd06b7  vmovaps [rsp+0x50], xmm6
000074c379dd06bd  vmovaps [rsp+0x60], xmm7
000074c379dd06c3  vmovaps [rsp+0x70], xmm8
000074c379dd06c9  vmovaps [rsp+0x80], xmm9
000074c379dd06d2  vmovaps [rsp+0x90], xmm10
000074c379dd06db  vmovaps [rsp+0xA0], xmm11
000074c379dd06e4  vmovaps [rsp+0xB0], xmm12
000074c379dd06ed  vmovaps [rsp+0xC0], xmm13
000074c379dd06f6  vmovaps [rsp+0xD0], xmm14
000074c379dd06ff  vmovaps [rsp+0xE0], xmm15
000074c379dd0708  sub rsp, 0x30
000074c379dd070c  movaps [rsp], xmm1
000074c379dd0710  movaps [rsp+0x10], xmm15
000074c379dd0716  movaps [rsp+0x20], xmm14
000074c379dd071c  lea rdi, [rsp]
000074c379dd0720  mov esi, 0x00
000074c379dd0725  mov rax, 0x56321ABA4530
000074c379dd072f  call rax
000074c379dd0731  movaps xmm1, [rsp]
000074c379dd0735  add rsp, 0x30
000074c379dd0739  vmovaps xmm0, [rsp]
000074c379dd073e  vmovaps xmm2, [rsp+0x10]
000074c379dd0744  vmovaps xmm3, [rsp+0x20]
000074c379dd074a  vmovaps xmm4, [rsp+0x30]
000074c379dd0750  vmovaps xmm5, [rsp+0x40]
000074c379dd0756  vmovaps xmm6, [rsp+0x50]
000074c379dd075c  vmovaps xmm7, [rsp+0x60]
000074c379dd0762  vmovaps xmm8, [rsp+0x70]
000074c379dd0768  vmovaps xmm9, [rsp+0x80]
000074c379dd0771  vmovaps xmm10, [rsp+0x90]
000074c379dd077a  vmovaps xmm11, [rsp+0xA0]
000074c379dd0783  vmovaps xmm12, [rsp+0xB0]
000074c379dd078c  vmovaps xmm13, [rsp+0xC0]
000074c379dd0795  vmovaps xmm14, [rsp+0xD0]
000074c379dd079e  vmovaps xmm15, [rsp+0xE0]
000074c379dd07a7  add rsp, 0xF0
000074c379dd07ae  pop r11
000074c379dd07b0  pop r10
000074c379dd07b2  pop r9
000074c379dd07b4  pop r8
000074c379dd07b6  pop rsi
000074c379dd07b7  pop rdi
000074c379dd07b8  pop rdx
000074c379dd07b9  pop rcx
000074c379dd07ba  pop rax
000074c379dd07bb  add rsp, 0x08
000074c379dd07bf  jmp 0x000074C379DCF581
000074c379dd07c4  sub rsp, 0x08
000074c379dd07c8  push rax
000074c379dd07c9  push rcx
000074c379dd07ca  push rdx
000074c379dd07cb  push rdi
000074c379dd07cc  push rsi
000074c379dd07cd  push r8
000074c379dd07cf  push r9
000074c379dd07d1  push r10
000074c379dd07d3  push r11
000074c379dd07d5  sub rsp, 0xF0
000074c379dd07dc  vmovaps [rsp], xmm0
000074c379dd07e1  vmovaps [rsp+0x10], xmm1
000074c379dd07e7  vmovaps [rsp+0x20], xmm2
000074c379dd07ed  vmovaps [rsp+0x30], xmm3
000074c379dd07f3  vmovaps [rsp+0x40], xmm4
000074c379dd07f9  vmovaps [rsp+0x50], xmm5
000074c379dd07ff  vmovaps [rsp+0x60], xmm6
000074c379dd0805  vmovaps [rsp+0x70], xmm7
000074c379dd080b  vmovaps [rsp+0x80], xmm8
000074c379dd0814  vmovaps [rsp+0x90], xmm9
000074c379dd081d  vmovaps [rsp+0xA0], xmm10
000074c379dd0826  vmovaps [rsp+0xB0], xmm11
000074c379dd082f  vmovaps [rsp+0xC0], xmm12
000074c379dd0838  vmovaps [rsp+0xD0], xmm14
000074c379dd0841  vmovaps [rsp+0xE0], xmm15
000074c379dd084a  sub rsp, 0x30
000074c379dd084e  movaps [rsp], xmm13
000074c379dd0853  movaps [rsp+0x10], xmm1
000074c379dd0858  movaps [rsp+0x20], xmm14
000074c379dd085e  lea rdi, [rsp]
000074c379dd0862  mov esi, 0x00
000074c379dd0867  mov rax, 0x56321ABA4530
000074c379dd0871  call rax
000074c379dd0873  movaps xmm13, [rsp]
000074c379dd0878  add rsp, 0x30
000074c379dd087c  vmovaps xmm0, [rsp]
000074c379dd0881  vmovaps xmm1, [rsp+0x10]
000074c379dd0887  vmovaps xmm2, [rsp+0x20]
000074c379dd088d  vmovaps xmm3, [rsp+0x30]
000074c379dd0893  vmovaps xmm4, [rsp+0x40]
000074c379dd0899  vmovaps xmm5, [rsp+0x50]
000074c379dd089f  vmovaps xmm6, [rsp+0x60]
000074c379dd08a5  vmovaps xmm7, [rsp+0x70]
000074c379dd08ab  vmovaps xmm8, [rsp+0x80]
000074c379dd08b4  vmovaps xmm9, [rsp+0x90]
000074c379dd08bd  vmovaps xmm10, [rsp+0xA0]
000074c379dd08c6  vmovaps xmm11, [rsp+0xB0]
000074c379dd08cf  vmovaps xmm12, [rsp+0xC0]
000074c379dd08d8  vmovaps xmm14, [rsp+0xD0]
000074c379dd08e1  vmovaps xmm15, [rsp+0xE0]
000074c379dd08ea  add rsp, 0xF0
000074c379dd08f1  pop r11
000074c379dd08f3  pop r10
000074c379dd08f5  pop r9
000074c379dd08f7  pop r8
000074c379dd08f9  pop rsi
000074c379dd08fa  pop rdi
000074c379dd08fb  pop rdx
000074c379dd08fc  pop rcx
000074c379dd08fd  pop rax
000074c379dd08fe  add rsp, 0x08
000074c379dd0902  jmp 0x000074C379DCF5CF
000074c379dd0907  sub rsp, 0x08
000074c379dd090b  push rax
000074c379dd090c  push rcx
000074c379dd090d  push rdx
000074c379dd090e  push rdi
000074c379dd090f  push rsi
000074c379dd0910  push r8
000074c379dd0912  push r9
000074c379dd0914  push r10
000074c379dd0916  push r11
000074c379dd0918  sub rsp, 0xF0
000074c379dd091f  vmovaps [rsp], xmm0
000074c379dd0924  vmovaps [rsp+0x10], xmm1
000074c379dd092a  vmovaps [rsp+0x20], xmm2
000074c379dd0930  vmovaps [rsp+0x30], xmm3
000074c379dd0936  vmovaps [rsp+0x40], xmm4
000074c379dd093c  vmovaps [rsp+0x50], xmm5
000074c379dd0942  vmovaps [rsp+0x60], xmm6
000074c379dd0948  vmovaps [rsp+0x70], xmm7
000074c379dd094e  vmovaps [rsp+0x80], xmm8
000074c379dd0957  vmovaps [rsp+0x90], xmm9
000074c379dd0960  vmovaps [rsp+0xA0], xmm10
000074c379dd0969  vmovaps [rsp+0xB0], xmm11
000074c379dd0972  vmovaps [rsp+0xC0], xmm12
000074c379dd097b  vmovaps [rsp+0xD0], xmm13
000074c379dd0984  vmovaps [rsp+0xE0], xmm14
000074c379dd098d  sub rsp, 0x30
000074c379dd0991  movaps [rsp], xmm15
000074c379dd0996  movaps [rsp+0x10], xmm14
000074c379dd099c  movaps [rsp+0x20], xmm1
000074c379dd09a1  lea rdi, [rsp]
000074c379dd09a5  mov esi, 0x00
000074c379dd09aa  mov rax, 0x56321ABA4530
000074c379dd09b4  call rax
000074c379dd09b6  movaps xmm15, [rsp]
000074c379dd09bb  add rsp, 0x30
000074c379dd09bf  vmovaps xmm0, [rsp]
000074c379dd09c4  vmovaps xmm1, [rsp+0x10]
000074c379dd09ca  vmovaps xmm2, [rsp+0x20]
000074c379dd09d0  vmovaps xmm3, [rsp+0x30]
000074c379dd09d6  vmovaps xmm4, [rsp+0x40]
000074c379dd09dc  vmovaps xmm5, [rsp+0x50]
000074c379dd09e2  vmovaps xmm6, [rsp+0x60]
000074c379dd09e8  vmovaps xmm7, [rsp+0x70]
000074c379dd09ee  vmovaps xmm8, [rsp+0x80]
000074c379dd09f7  vmovaps xmm9, [rsp+0x90]
000074c379dd0a00  vmovaps xmm10, [rsp+0xA0]
000074c379dd0a09  vmovaps xmm11, [rsp+0xB0]
000074c379dd0a12  vmovaps xmm12, [rsp+0xC0]
000074c379dd0a1b  vmovaps xmm13, [rsp+0xD0]
000074c379dd0a24  vmovaps xmm14, [rsp+0xE0]
000074c379dd0a2d  add rsp, 0xF0
000074c379dd0a34  pop r11
000074c379dd0a36  pop r10
000074c379dd0a38  pop r9
000074c379dd0a3a  pop r8
000074c379dd0a3c  pop rsi
000074c379dd0a3d  pop rdi
000074c379dd0a3e  pop rdx
000074c379dd0a3f  pop rcx
000074c379dd0a40  pop rax
000074c379dd0a41  add rsp, 0x08
000074c379dd0a45  jmp 0x000074C379DCF617
000074c379dd0a4a  sub rsp, 0x08
000074c379dd0a4e  push rax
000074c379dd0a4f  push rcx
000074c379dd0a50  push rdx
000074c379dd0a51  push rdi
000074c379dd0a52  push rsi
000074c379dd0a53  push r8
000074c379dd0a55  push r9
000074c379dd0a57  push r10
000074c379dd0a59  push r11
000074c379dd0a5b  sub rsp, 0xF0
000074c379dd0a62  vmovaps [rsp], xmm0
000074c379dd0a67  vmovaps [rsp+0x10], xmm2
000074c379dd0a6d  vmovaps [rsp+0x20], xmm3
000074c379dd0a73  vmovaps [rsp+0x30], xmm4
000074c379dd0a79  vmovaps [rsp+0x40], xmm5
000074c379dd0a7f  vmovaps [rsp+0x50], xmm6
000074c379dd0a85  vmovaps [rsp+0x60], xmm7
000074c379dd0a8b  vmovaps [rsp+0x70], xmm8
000074c379dd0a91  vmovaps [rsp+0x80], xmm9
000074c379dd0a9a  vmovaps [rsp+0x90], xmm10
000074c379dd0aa3  vmovaps [rsp+0xA0], xmm11
000074c379dd0aac  vmovaps [rsp+0xB0], xmm12
000074c379dd0ab5  vmovaps [rsp+0xC0], xmm13
000074c379dd0abe  vmovaps [rsp+0xD0], xmm14
000074c379dd0ac7  vmovaps [rsp+0xE0], xmm15
000074c379dd0ad0  sub rsp, 0x30
000074c379dd0ad4  movaps [rsp], xmm1
000074c379dd0ad8  movaps [rsp+0x10], xmm14
000074c379dd0ade  movaps [rsp+0x20], xmm10
000074c379dd0ae4  lea rdi, [rsp]
000074c379dd0ae8  mov esi, 0x00
000074c379dd0aed  mov rax, 0x56321ABA4530
000074c379dd0af7  call rax
000074c379dd0af9  movaps xmm1, [rsp]
000074c379dd0afd  add rsp, 0x30
000074c379dd0b01  vmovaps xmm0, [rsp]
000074c379dd0b06  vmovaps xmm2, [rsp+0x10]
000074c379dd0b0c  vmovaps xmm3, [rsp+0x20]
000074c379dd0b12  vmovaps xmm4, [rsp+0x30]
000074c379dd0b18  vmovaps xmm5, [rsp+0x40]
000074c379dd0b1e  vmovaps xmm6, [rsp+0x50]
000074c379dd0b24  vmovaps xmm7, [rsp+0x60]
000074c379dd0b2a  vmovaps xmm8, [rsp+0x70]
000074c379dd0b30  vmovaps xmm9, [rsp+0x80]
000074c379dd0b39  vmovaps xmm10, [rsp+0x90]
000074c379dd0b42  vmovaps xmm11, [rsp+0xA0]
000074c379dd0b4b  vmovaps xmm12, [rsp+0xB0]
000074c379dd0b54  vmovaps xmm13, [rsp+0xC0]
000074c379dd0b5d  vmovaps xmm14, [rsp+0xD0]
000074c379dd0b66  vmovaps xmm15, [rsp+0xE0]
000074c379dd0b6f  add rsp, 0xF0
000074c379dd0b76  pop r11
000074c379dd0b78  pop r10
000074c379dd0b7a  pop r9
000074c379dd0b7c  pop r8
000074c379dd0b7e  pop rsi
000074c379dd0b7f  pop rdi
000074c379dd0b80  pop rdx
000074c379dd0b81  pop rcx
000074c379dd0b82  pop rax
000074c379dd0b83  add rsp, 0x08
000074c379dd0b87  jmp 0x000074C379DCF631
000074c379dd0b8c  sub rsp, 0x08
000074c379dd0b90  push rax
000074c379dd0b91  push rcx
000074c379dd0b92  push rdx
000074c379dd0b93  push rdi
000074c379dd0b94  push rsi
000074c379dd0b95  push r8
000074c379dd0b97  push r9
000074c379dd0b99  push r10
000074c379dd0b9b  push r11
000074c379dd0b9d  sub rsp, 0xF0
000074c379dd0ba4  vmovaps [rsp], xmm0
000074c379dd0ba9  vmovaps [rsp+0x10], xmm1
000074c379dd0baf  vmovaps [rsp+0x20], xmm2
000074c379dd0bb5  vmovaps [rsp+0x30], xmm3
000074c379dd0bbb  vmovaps [rsp+0x40], xmm4
000074c379dd0bc1  vmovaps [rsp+0x50], xmm5
000074c379dd0bc7  vmovaps [rsp+0x60], xmm6
000074c379dd0bcd  vmovaps [rsp+0x70], xmm7
000074c379dd0bd3  vmovaps [rsp+0x80], xmm8
000074c379dd0bdc  vmovaps [rsp+0x90], xmm9
000074c379dd0be5  vmovaps [rsp+0xA0], xmm10
000074c379dd0bee  vmovaps [rsp+0xB0], xmm11
000074c379dd0bf7  vmovaps [rsp+0xC0], xmm12
000074c379dd0c00  vmovaps [rsp+0xD0], xmm14
000074c379dd0c09  vmovaps [rsp+0xE0], xmm15
000074c379dd0c12  sub rsp, 0x30
000074c379dd0c16  movaps [rsp], xmm13
000074c379dd0c1b  movaps [rsp+0x10], xmm14
000074c379dd0c21  movaps [rsp+0x20], xmm2
000074c379dd0c26  lea rdi, [rsp]
000074c379dd0c2a  mov esi, 0x00
000074c379dd0c2f  mov rax, 0x56321ABA4530
000074c379dd0c39  call rax
000074c379dd0c3b  movaps xmm13, [rsp]
000074c379dd0c40  add rsp, 0x30
000074c379dd0c44  vmovaps xmm0, [rsp]
000074c379dd0c49  vmovaps xmm1, [rsp+0x10]
000074c379dd0c4f  vmovaps xmm2, [rsp+0x20]
000074c379dd0c55  vmovaps xmm3, [rsp+0x30]
000074c379dd0c5b  vmovaps xmm4, [rsp+0x40]
000074c379dd0c61  vmovaps xmm5, [rsp+0x50]
000074c379dd0c67  vmovaps xmm6, [rsp+0x60]
000074c379dd0c6d  vmovaps xmm7, [rsp+0x70]
000074c379dd0c73  vmovaps xmm8, [rsp+0x80]
000074c379dd0c7c  vmovaps xmm9, [rsp+0x90]
000074c379dd0c85  vmovaps xmm10, [rsp+0xA0]
000074c379dd0c8e  vmovaps xmm11, [rsp+0xB0]
000074c379dd0c97  vmovaps xmm12, [rsp+0xC0]
000074c379dd0ca0  vmovaps xmm14, [rsp+0xD0]
000074c379dd0ca9  vmovaps xmm15, [rsp+0xE0]
000074c379dd0cb2  add rsp, 0xF0
000074c379dd0cb9  pop r11
000074c379dd0cbb  pop r10
000074c379dd0cbd  pop r9
000074c379dd0cbf  pop r8
000074c379dd0cc1  pop rsi
000074c379dd0cc2  pop rdi
000074c379dd0cc3  pop rdx
000074c379dd0cc4  pop rcx
000074c379dd0cc5  pop rax
000074c379dd0cc6  add rsp, 0x08
000074c379dd0cca  jmp 0x000074C379DCF64C
000074c379dd0ccf  sub rsp, 0x08
000074c379dd0cd3  push rax
000074c379dd0cd4  push rcx
000074c379dd0cd5  push rdx
000074c379dd0cd6  push rdi
000074c379dd0cd7  push rsi
000074c379dd0cd8  push r8
000074c379dd0cda  push r9
000074c379dd0cdc  push r10
000074c379dd0cde  push r11
000074c379dd0ce0  sub rsp, 0xF0
000074c379dd0ce7  vmovaps [rsp], xmm0
000074c379dd0cec  vmovaps [rsp+0x10], xmm2
000074c379dd0cf2  vmovaps [rsp+0x20], xmm3
000074c379dd0cf8  vmovaps [rsp+0x30], xmm4
000074c379dd0cfe  vmovaps [rsp+0x40], xmm5
000074c379dd0d04  vmovaps [rsp+0x50], xmm6
000074c379dd0d0a  vmovaps [rsp+0x60], xmm7
000074c379dd0d10  vmovaps [rsp+0x70], xmm8
000074c379dd0d16  vmovaps [rsp+0x80], xmm9
000074c379dd0d1f  vmovaps [rsp+0x90], xmm10
000074c379dd0d28  vmovaps [rsp+0xA0], xmm11
000074c379dd0d31  vmovaps [rsp+0xB0], xmm12
000074c379dd0d3a  vmovaps [rsp+0xC0], xmm13
000074c379dd0d43  vmovaps [rsp+0xD0], xmm14
000074c379dd0d4c  vmovaps [rsp+0xE0], xmm15
000074c379dd0d55  sub rsp, 0x30
000074c379dd0d59  movaps [rsp], xmm1
000074c379dd0d5d  movaps [rsp+0x10], xmm10
000074c379dd0d63  movaps [rsp+0x20], xmm2
000074c379dd0d68  lea rdi, [rsp]
000074c379dd0d6c  mov esi, 0x00
000074c379dd0d71  mov rax, 0x56321ABA4530
000074c379dd0d7b  call rax
000074c379dd0d7d  movaps xmm1, [rsp]
000074c379dd0d81  add rsp, 0x30
000074c379dd0d85  vmovaps xmm0, [rsp]
000074c379dd0d8a  vmovaps xmm2, [rsp+0x10]
000074c379dd0d90  vmovaps xmm3, [rsp+0x20]
000074c379dd0d96  vmovaps xmm4, [rsp+0x30]
000074c379dd0d9c  vmovaps xmm5, [rsp+0x40]
000074c379dd0da2  vmovaps xmm6, [rsp+0x50]
000074c379dd0da8  vmovaps xmm7, [rsp+0x60]
000074c379dd0dae  vmovaps xmm8, [rsp+0x70]
000074c379dd0db4  vmovaps xmm9, [rsp+0x80]
000074c379dd0dbd  vmovaps xmm10, [rsp+0x90]
000074c379dd0dc6  vmovaps xmm11, [rsp+0xA0]
000074c379dd0dcf  vmovaps xmm12, [rsp+0xB0]
000074c379dd0dd8  vmovaps xmm13, [rsp+0xC0]
000074c379dd0de1  vmovaps xmm14, [rsp+0xD0]
000074c379dd0dea  vmovaps xmm15, [rsp+0xE0]
000074c379dd0df3  add rsp, 0xF0
000074c379dd0dfa  pop r11
000074c379dd0dfc  pop r10
000074c379dd0dfe  pop r9
000074c379dd0e00  pop r8
000074c379dd0e02  pop rsi
000074c379dd0e03  pop rdi
000074c379dd0e04  pop rdx
000074c379dd0e05  pop rcx
000074c379dd0e06  pop rax
000074c379dd0e07  add rsp, 0x08
000074c379dd0e0b  jmp 0x000074C379DCF6B4
000074c379dd0e10  sub rsp, 0x08
000074c379dd0e14  push rax
000074c379dd0e15  push rcx
000074c379dd0e16  push rdx
000074c379dd0e17  push rdi
000074c379dd0e18  push rsi
000074c379dd0e19  push r8
000074c379dd0e1b  push r9
000074c379dd0e1d  push r10
000074c379dd0e1f  push r11
000074c379dd0e21  sub rsp, 0xF0
000074c379dd0e28  vmovaps [rsp], xmm0
000074c379dd0e2d  vmovaps [rsp+0x10], xmm1
000074c379dd0e33  vmovaps [rsp+0x20], xmm2
000074c379dd0e39  vmovaps [rsp+0x30], xmm3
000074c379dd0e3f  vmovaps [rsp+0x40], xmm4
000074c379dd0e45  vmovaps [rsp+0x50], xmm5
000074c379dd0e4b  vmovaps [rsp+0x60], xmm6
000074c379dd0e51  vmovaps [rsp+0x70], xmm7
000074c379dd0e57  vmovaps [rsp+0x80], xmm8
000074c379dd0e60  vmovaps [rsp+0x90], xmm9
000074c379dd0e69  vmovaps [rsp+0xA0], xmm10
000074c379dd0e72  vmovaps [rsp+0xB0], xmm11
000074c379dd0e7b  vmovaps [rsp+0xC0], xmm12
000074c379dd0e84  vmovaps [rsp+0xD0], xmm13
000074c379dd0e8d  vmovaps [rsp+0xE0], xmm14
000074c379dd0e96  sub rsp, 0x30
000074c379dd0e9a  movaps [rsp], xmm15
000074c379dd0e9f  movaps [rsp+0x10], xmm10
000074c379dd0ea5  movaps [rsp+0x20], xmm2
000074c379dd0eaa  lea rdi, [rsp]
000074c379dd0eae  mov esi, 0x00
000074c379dd0eb3  mov rax, 0x56321ABA4530
000074c379dd0ebd  call rax
000074c379dd0ebf  movaps xmm15, [rsp]
000074c379dd0ec4  add rsp, 0x30
000074c379dd0ec8  vmovaps xmm0, [rsp]
000074c379dd0ecd  vmovaps xmm1, [rsp+0x10]
000074c379dd0ed3  vmovaps xmm2, [rsp+0x20]
000074c379dd0ed9  vmovaps xmm3, [rsp+0x30]
000074c379dd0edf  vmovaps xmm4, [rsp+0x40]
000074c379dd0ee5  vmovaps xmm5, [rsp+0x50]
000074c379dd0eeb  vmovaps xmm6, [rsp+0x60]
000074c379dd0ef1  vmovaps xmm7, [rsp+0x70]
000074c379dd0ef7  vmovaps xmm8, [rsp+0x80]
000074c379dd0f00  vmovaps xmm9, [rsp+0x90]
000074c379dd0f09  vmovaps xmm10, [rsp+0xA0]
000074c379dd0f12  vmovaps xmm11, [rsp+0xB0]
000074c379dd0f1b  vmovaps xmm12, [rsp+0xC0]
000074c379dd0f24  vmovaps xmm13, [rsp+0xD0]
000074c379dd0f2d  vmovaps xmm14, [rsp+0xE0]
000074c379dd0f36  add rsp, 0xF0
000074c379dd0f3d  pop r11
000074c379dd0f3f  pop r10
000074c379dd0f41  pop r9
000074c379dd0f43  pop r8
000074c379dd0f45  pop rsi
000074c379dd0f46  pop rdi
000074c379dd0f47  pop rdx
000074c379dd0f48  pop rcx
000074c379dd0f49  pop rax
000074c379dd0f4a  add rsp, 0x08
000074c379dd0f4e  jmp 0x000074C379DCF706
000074c379dd0f53  sub rsp, 0x08
000074c379dd0f57  push rax
000074c379dd0f58  push rcx
000074c379dd0f59  push rdx
000074c379dd0f5a  push rdi
000074c379dd0f5b  push rsi
000074c379dd0f5c  push r8
000074c379dd0f5e  push r9
000074c379dd0f60  push r10
000074c379dd0f62  push r11
000074c379dd0f64  sub rsp, 0xF0
000074c379dd0f6b  vmovaps [rsp], xmm0
000074c379dd0f70  vmovaps [rsp+0x10], xmm2
000074c379dd0f76  vmovaps [rsp+0x20], xmm3
000074c379dd0f7c  vmovaps [rsp+0x30], xmm4
000074c379dd0f82  vmovaps [rsp+0x40], xmm5
000074c379dd0f88  vmovaps [rsp+0x50], xmm6
000074c379dd0f8e  vmovaps [rsp+0x60], xmm7
000074c379dd0f94  vmovaps [rsp+0x70], xmm8
000074c379dd0f9a  vmovaps [rsp+0x80], xmm9
000074c379dd0fa3  vmovaps [rsp+0x90], xmm10
000074c379dd0fac  vmovaps [rsp+0xA0], xmm11
000074c379dd0fb5  vmovaps [rsp+0xB0], xmm12
000074c379dd0fbe  vmovaps [rsp+0xC0], xmm13
000074c379dd0fc7  vmovaps [rsp+0xD0], xmm14
000074c379dd0fd0  vmovaps [rsp+0xE0], xmm15
000074c379dd0fd9  sub rsp, 0x30
000074c379dd0fdd  movaps [rsp], xmm1
000074c379dd0fe1  movaps [rsp+0x10], xmm10
000074c379dd0fe7  movaps [rsp+0x20], xmm12
000074c379dd0fed  lea rdi, [rsp]
000074c379dd0ff1  mov esi, 0x00
000074c379dd0ff6  mov rax, 0x56321ABA4530
000074c379dd1000  call rax
000074c379dd1002  movaps xmm1, [rsp]
000074c379dd1006  add rsp, 0x30
000074c379dd100a  vmovaps xmm0, [rsp]
000074c379dd100f  vmovaps xmm2, [rsp+0x10]
000074c379dd1015  vmovaps xmm3, [rsp+0x20]
000074c379dd101b  vmovaps xmm4, [rsp+0x30]
000074c379dd1021  vmovaps xmm5, [rsp+0x40]
000074c379dd1027  vmovaps xmm6, [rsp+0x50]
000074c379dd102d  vmovaps xmm7, [rsp+0x60]
000074c379dd1033  vmovaps xmm8, [rsp+0x70]
000074c379dd1039  vmovaps xmm9, [rsp+0x80]
000074c379dd1042  vmovaps xmm10, [rsp+0x90]
000074c379dd104b  vmovaps xmm11, [rsp+0xA0]
000074c379dd1054  vmovaps xmm12, [rsp+0xB0]
000074c379dd105d  vmovaps xmm13, [rsp+0xC0]
000074c379dd1066  vmovaps xmm14, [rsp+0xD0]
000074c379dd106f  vmovaps xmm15, [rsp+0xE0]
000074c379dd1078  add rsp, 0xF0
000074c379dd107f  pop r11
000074c379dd1081  pop r10
000074c379dd1083  pop r9
000074c379dd1085  pop r8
000074c379dd1087  pop rsi
000074c379dd1088  pop rdi
000074c379dd1089  pop rdx
000074c379dd108a  pop rcx
000074c379dd108b  pop rax
000074c379dd108c  add rsp, 0x08
000074c379dd1090  jmp 0x000074C379DCF732
000074c379dd1095  sub rsp, 0x08
000074c379dd1099  push rax
000074c379dd109a  push rcx
000074c379dd109b  push rdx
000074c379dd109c  push rdi
000074c379dd109d  push rsi
000074c379dd109e  push r8
000074c379dd10a0  push r9
000074c379dd10a2  push r10
000074c379dd10a4  push r11
000074c379dd10a6  sub rsp, 0xF0
000074c379dd10ad  vmovaps [rsp], xmm0
000074c379dd10b2  vmovaps [rsp+0x10], xmm1
000074c379dd10b8  vmovaps [rsp+0x20], xmm2
000074c379dd10be  vmovaps [rsp+0x30], xmm3
000074c379dd10c4  vmovaps [rsp+0x40], xmm4
000074c379dd10ca  vmovaps [rsp+0x50], xmm5
000074c379dd10d0  vmovaps [rsp+0x60], xmm6
000074c379dd10d6  vmovaps [rsp+0x70], xmm7
000074c379dd10dc  vmovaps [rsp+0x80], xmm8
000074c379dd10e5  vmovaps [rsp+0x90], xmm9
000074c379dd10ee  vmovaps [rsp+0xA0], xmm10
000074c379dd10f7  vmovaps [rsp+0xB0], xmm11
000074c379dd1100  vmovaps [rsp+0xC0], xmm12
000074c379dd1109  vmovaps [rsp+0xD0], xmm13
000074c379dd1112  vmovaps [rsp+0xE0], xmm14
000074c379dd111b  sub rsp, 0x30
000074c379dd111f  movaps [rsp], xmm15
000074c379dd1124  movaps [rsp+0x10], xmm10
000074c379dd112a  movaps [rsp+0x20], xmm12
000074c379dd1130  lea rdi, [rsp]
000074c379dd1134  mov esi, 0x00
000074c379dd1139  mov rax, 0x56321ABA4530
000074c379dd1143  call rax
000074c379dd1145  movaps xmm15, [rsp]
000074c379dd114a  add rsp, 0x30
000074c379dd114e  vmovaps xmm0, [rsp]
000074c379dd1153  vmovaps xmm1, [rsp+0x10]
000074c379dd1159  vmovaps xmm2, [rsp+0x20]
000074c379dd115f  vmovaps xmm3, [rsp+0x30]
000074c379dd1165  vmovaps xmm4, [rsp+0x40]
000074c379dd116b  vmovaps xmm5, [rsp+0x50]
000074c379dd1171  vmovaps xmm6, [rsp+0x60]
000074c379dd1177  vmovaps xmm7, [rsp+0x70]
000074c379dd117d  vmovaps xmm8, [rsp+0x80]
000074c379dd1186  vmovaps xmm9, [rsp+0x90]
000074c379dd118f  vmovaps xmm10, [rsp+0xA0]
000074c379dd1198  vmovaps xmm11, [rsp+0xB0]
000074c379dd11a1  vmovaps xmm12, [rsp+0xC0]
000074c379dd11aa  vmovaps xmm13, [rsp+0xD0]
000074c379dd11b3  vmovaps xmm14, [rsp+0xE0]
000074c379dd11bc  add rsp, 0xF0
000074c379dd11c3  pop r11
000074c379dd11c5  pop r10
000074c379dd11c7  pop r9
000074c379dd11c9  pop r8
000074c379dd11cb  pop rsi
000074c379dd11cc  pop rdi
000074c379dd11cd  pop rdx
000074c379dd11ce  pop rcx
000074c379dd11cf  pop rax
000074c379dd11d0  add rsp, 0x08
000074c379dd11d4  jmp 0x000074C379DCF75E
000074c379dd11d9  call 0x000074C379BFF430
000074c379dd11de  jmp 0x000074C379DCF7EE
000074c379dd11e3  call 0x000074C379BFF430
000074c379dd11e8  jmp 0x000074C379DCF801
000074c379dd11ed  sub rsp, 0x08
000074c379dd11f1  push rax
000074c379dd11f2  push rcx
000074c379dd11f3  push rdx
000074c379dd11f4  push rdi
000074c379dd11f5  push rsi
000074c379dd11f6  push r8
000074c379dd11f8  push r9
000074c379dd11fa  push r10
000074c379dd11fc  push r11
000074c379dd11fe  sub rsp, 0xF0
000074c379dd1205  vmovaps [rsp], xmm0
000074c379dd120a  vmovaps [rsp+0x10], xmm2
000074c379dd1210  vmovaps [rsp+0x20], xmm3
000074c379dd1216  vmovaps [rsp+0x30], xmm4
000074c379dd121c  vmovaps [rsp+0x40], xmm5
000074c379dd1222  vmovaps [rsp+0x50], xmm6
000074c379dd1228  vmovaps [rsp+0x60], xmm7
000074c379dd122e  vmovaps [rsp+0x70], xmm8
000074c379dd1234  vmovaps [rsp+0x80], xmm9
000074c379dd123d  vmovaps [rsp+0x90], xmm10
000074c379dd1246  vmovaps [rsp+0xA0], xmm11
000074c379dd124f  vmovaps [rsp+0xB0], xmm12
000074c379dd1258  vmovaps [rsp+0xC0], xmm13
000074c379dd1261  vmovaps [rsp+0xD0], xmm14
000074c379dd126a  vmovaps [rsp+0xE0], xmm15
000074c379dd1273  sub rsp, 0x30
000074c379dd1277  movaps [rsp], xmm1
000074c379dd127b  movaps [rsp+0x10], xmm13
000074c379dd1281  movaps [rsp+0x20], xmm2
000074c379dd1286  lea rdi, [rsp]
000074c379dd128a  mov esi, 0x00
000074c379dd128f  mov rax, 0x56321ABA4530
000074c379dd1299  call rax
000074c379dd129b  movaps xmm1, [rsp]
000074c379dd129f  add rsp, 0x30
000074c379dd12a3  vmovaps xmm0, [rsp]
000074c379dd12a8  vmovaps xmm2, [rsp+0x10]
000074c379dd12ae  vmovaps xmm3, [rsp+0x20]
000074c379dd12b4  vmovaps xmm4, [rsp+0x30]
000074c379dd12ba  vmovaps xmm5, [rsp+0x40]
000074c379dd12c0  vmovaps xmm6, [rsp+0x50]
000074c379dd12c6  vmovaps xmm7, [rsp+0x60]
000074c379dd12cc  vmovaps xmm8, [rsp+0x70]
000074c379dd12d2  vmovaps xmm9, [rsp+0x80]
000074c379dd12db  vmovaps xmm10, [rsp+0x90]
000074c379dd12e4  vmovaps xmm11, [rsp+0xA0]
000074c379dd12ed  vmovaps xmm12, [rsp+0xB0]
000074c379dd12f6  vmovaps xmm13, [rsp+0xC0]
000074c379dd12ff  vmovaps xmm14, [rsp+0xD0]
000074c379dd1308  vmovaps xmm15, [rsp+0xE0]
000074c379dd1311  add rsp, 0xF0
000074c379dd1318  pop r11
000074c379dd131a  pop r10
000074c379dd131c  pop r9
000074c379dd131e  pop r8
000074c379dd1320  pop rsi
000074c379dd1321  pop rdi
000074c379dd1322  pop rdx
000074c379dd1323  pop rcx
000074c379dd1324  pop rax
000074c379dd1325  add rsp, 0x08
000074c379dd1329  jmp 0x000074C379DCF82C
000074c379dd132e  call 0x000074C379C0E760
000074c379dd1333  jmp 0x000074C379DCF839
000074c379dd1338  sub rsp, 0x08
000074c379dd133c  push rax
000074c379dd133d  push rcx
000074c379dd133e  push rdx
000074c379dd133f  push rdi
000074c379dd1340  push rsi
000074c379dd1341  push r8
000074c379dd1343  push r9
000074c379dd1345  push r10
000074c379dd1347  push r11
000074c379dd1349  sub rsp, 0xF0
000074c379dd1350  vmovaps [rsp], xmm0
000074c379dd1355  vmovaps [rsp+0x10], xmm1
000074c379dd135b  vmovaps [rsp+0x20], xmm2
000074c379dd1361  vmovaps [rsp+0x30], xmm3
000074c379dd1367  vmovaps [rsp+0x40], xmm4
000074c379dd136d  vmovaps [rsp+0x50], xmm5
000074c379dd1373  vmovaps [rsp+0x60], xmm6
000074c379dd1379  vmovaps [rsp+0x70], xmm7
000074c379dd137f  vmovaps [rsp+0x80], xmm8
000074c379dd1388  vmovaps [rsp+0x90], xmm9
000074c379dd1391  vmovaps [rsp+0xA0], xmm10
000074c379dd139a  vmovaps [rsp+0xB0], xmm11
000074c379dd13a3  vmovaps [rsp+0xC0], xmm12
000074c379dd13ac  vmovaps [rsp+0xD0], xmm14
000074c379dd13b5  vmovaps [rsp+0xE0], xmm15
000074c379dd13be  sub rsp, 0x30
000074c379dd13c2  movaps [rsp], xmm13
000074c379dd13c7  movaps [rsp+0x10], xmm2
000074c379dd13cc  movaps [rsp+0x20], xmm1
000074c379dd13d1  lea rdi, [rsp]
000074c379dd13d5  mov esi, 0x00
000074c379dd13da  mov rax, 0x56321ABA4530
000074c379dd13e4  call rax
000074c379dd13e6  movaps xmm13, [rsp]
000074c379dd13eb  add rsp, 0x30
000074c379dd13ef  vmovaps xmm0, [rsp]
000074c379dd13f4  vmovaps xmm1, [rsp+0x10]
000074c379dd13fa  vmovaps xmm2, [rsp+0x20]
000074c379dd1400  vmovaps xmm3, [rsp+0x30]
000074c379dd1406  vmovaps xmm4, [rsp+0x40]
000074c379dd140c  vmovaps xmm5, [rsp+0x50]
000074c379dd1412  vmovaps xmm6, [rsp+0x60]
000074c379dd1418  vmovaps xmm7, [rsp+0x70]
000074c379dd141e  vmovaps xmm8, [rsp+0x80]
000074c379dd1427  vmovaps xmm9, [rsp+0x90]
000074c379dd1430  vmovaps xmm10, [rsp+0xA0]
000074c379dd1439  vmovaps xmm11, [rsp+0xB0]
000074c379dd1442  vmovaps xmm12, [rsp+0xC0]
000074c379dd144b  vmovaps xmm14, [rsp+0xD0]
000074c379dd1454  vmovaps xmm15, [rsp+0xE0]
000074c379dd145d  add rsp, 0xF0
000074c379dd1464  pop r11
000074c379dd1466  pop r10
000074c379dd1468  pop r9
000074c379dd146a  pop r8
000074c379dd146c  pop rsi
000074c379dd146d  pop rdi
000074c379dd146e  pop rdx
000074c379dd146f  pop rcx
000074c379dd1470  pop rax
000074c379dd1471  add rsp, 0x08
000074c379dd1475  jmp 0x000074C379DCF878
000074c379dd147a  sub rsp, 0x08
000074c379dd147e  push rax
000074c379dd147f  push rcx
000074c379dd1480  push rdx
000074c379dd1481  push rdi
000074c379dd1482  push rsi
000074c379dd1483  push r8
000074c379dd1485  push r9
000074c379dd1487  push r10
000074c379dd1489  push r11
000074c379dd148b  sub rsp, 0xF0
000074c379dd1492  vmovaps [rsp], xmm0
000074c379dd1497  vmovaps [rsp+0x10], xmm2
000074c379dd149d  vmovaps [rsp+0x20], xmm3
000074c379dd14a3  vmovaps [rsp+0x30], xmm4
000074c379dd14a9  vmovaps [rsp+0x40], xmm5
000074c379dd14af  vmovaps [rsp+0x50], xmm6
000074c379dd14b5  vmovaps [rsp+0x60], xmm7
000074c379dd14bb  vmovaps [rsp+0x70], xmm8
000074c379dd14c1  vmovaps [rsp+0x80], xmm9
000074c379dd14ca  vmovaps [rsp+0x90], xmm10
000074c379dd14d3  vmovaps [rsp+0xA0], xmm11
000074c379dd14dc  vmovaps [rsp+0xB0], xmm12
000074c379dd14e5  vmovaps [rsp+0xC0], xmm13
000074c379dd14ee  vmovaps [rsp+0xD0], xmm14
000074c379dd14f7  vmovaps [rsp+0xE0], xmm15
000074c379dd1500  sub rsp, 0x30
000074c379dd1504  movaps [rsp], xmm1
000074c379dd1508  movaps [rsp+0x10], xmm15
000074c379dd150e  movaps [rsp+0x20], xmm2
000074c379dd1513  lea rdi, [rsp]
000074c379dd1517  mov esi, 0x00
000074c379dd151c  mov rax, 0x56321ABA4530
000074c379dd1526  call rax
000074c379dd1528  movaps xmm1, [rsp]
000074c379dd152c  add rsp, 0x30
000074c379dd1530  vmovaps xmm0, [rsp]
000074c379dd1535  vmovaps xmm2, [rsp+0x10]
000074c379dd153b  vmovaps xmm3, [rsp+0x20]
000074c379dd1541  vmovaps xmm4, [rsp+0x30]
000074c379dd1547  vmovaps xmm5, [rsp+0x40]
000074c379dd154d  vmovaps xmm6, [rsp+0x50]
000074c379dd1553  vmovaps xmm7, [rsp+0x60]
000074c379dd1559  vmovaps xmm8, [rsp+0x70]
000074c379dd155f  vmovaps xmm9, [rsp+0x80]
000074c379dd1568  vmovaps xmm10, [rsp+0x90]
000074c379dd1571  vmovaps xmm11, [rsp+0xA0]
000074c379dd157a  vmovaps xmm12, [rsp+0xB0]
000074c379dd1583  vmovaps xmm13, [rsp+0xC0]
000074c379dd158c  vmovaps xmm14, [rsp+0xD0]
000074c379dd1595  vmovaps xmm15, [rsp+0xE0]
000074c379dd159e  add rsp, 0xF0
000074c379dd15a5  pop r11
000074c379dd15a7  pop r10
000074c379dd15a9  pop r9
000074c379dd15ab  pop r8
000074c379dd15ad  pop rsi
000074c379dd15ae  pop rdi
000074c379dd15af  pop rdx
000074c379dd15b0  pop rcx
000074c379dd15b1  pop rax
000074c379dd15b2  add rsp, 0x08
000074c379dd15b6  jmp 0x000074C379DCF8AC
000074c379dd15bb  sub rsp, 0x08
000074c379dd15bf  push rax
000074c379dd15c0  push rcx
000074c379dd15c1  push rdx
000074c379dd15c2  push rdi
000074c379dd15c3  push rsi
000074c379dd15c4  push r8
000074c379dd15c6  push r9
000074c379dd15c8  push r10
000074c379dd15ca  push r11
000074c379dd15cc  sub rsp, 0xF0
000074c379dd15d3  vmovaps [rsp], xmm0
000074c379dd15d8  vmovaps [rsp+0x10], xmm1
000074c379dd15de  vmovaps [rsp+0x20], xmm2
000074c379dd15e4  vmovaps [rsp+0x30], xmm3
000074c379dd15ea  vmovaps [rsp+0x40], xmm4
000074c379dd15f0  vmovaps [rsp+0x50], xmm5
000074c379dd15f6  vmovaps [rsp+0x60], xmm6
000074c379dd15fc  vmovaps [rsp+0x70], xmm7
000074c379dd1602  vmovaps [rsp+0x80], xmm8
000074c379dd160b  vmovaps [rsp+0x90], xmm9
000074c379dd1614  vmovaps [rsp+0xA0], xmm10
000074c379dd161d  vmovaps [rsp+0xB0], xmm11
000074c379dd1626  vmovaps [rsp+0xC0], xmm12
000074c379dd162f  vmovaps [rsp+0xD0], xmm13
000074c379dd1638  vmovaps [rsp+0xE0], xmm15
000074c379dd1641  sub rsp, 0x30
000074c379dd1645  movaps [rsp], xmm14
000074c379dd164a  movaps [rsp+0x10], xmm2
000074c379dd164f  movaps [rsp+0x20], xmm15
000074c379dd1655  lea rdi, [rsp]
000074c379dd1659  mov esi, 0x00
000074c379dd165e  mov rax, 0x56321ABA4530
000074c379dd1668  call rax
000074c379dd166a  movaps xmm14, [rsp]
000074c379dd166f  add rsp, 0x30
000074c379dd1673  vmovaps xmm0, [rsp]
000074c379dd1678  vmovaps xmm1, [rsp+0x10]
000074c379dd167e  vmovaps xmm2, [rsp+0x20]
000074c379dd1684  vmovaps xmm3, [rsp+0x30]
000074c379dd168a  vmovaps xmm4, [rsp+0x40]
000074c379dd1690  vmovaps xmm5, [rsp+0x50]
000074c379dd1696  vmovaps xmm6, [rsp+0x60]
000074c379dd169c  vmovaps xmm7, [rsp+0x70]
000074c379dd16a2  vmovaps xmm8, [rsp+0x80]
000074c379dd16ab  vmovaps xmm9, [rsp+0x90]
000074c379dd16b4  vmovaps xmm10, [rsp+0xA0]
000074c379dd16bd  vmovaps xmm11, [rsp+0xB0]
000074c379dd16c6  vmovaps xmm12, [rsp+0xC0]
000074c379dd16cf  vmovaps xmm13, [rsp+0xD0]
000074c379dd16d8  vmovaps xmm15, [rsp+0xE0]
000074c379dd16e1  add rsp, 0xF0
000074c379dd16e8  pop r11
000074c379dd16ea  pop r10
000074c379dd16ec  pop r9
000074c379dd16ee  pop r8
000074c379dd16f0  pop rsi
000074c379dd16f1  pop rdi
000074c379dd16f2  pop rdx
000074c379dd16f3  pop rcx
000074c379dd16f4  pop rax
000074c379dd16f5  add rsp, 0x08
000074c379dd16f9  jmp 0x000074C379DCF8E7
000074c379dd16fe  sub rsp, 0x08
000074c379dd1702  push rax
000074c379dd1703  push rcx
000074c379dd1704  push rdx
000074c379dd1705  push rdi
000074c379dd1706  push rsi
000074c379dd1707  push r8
000074c379dd1709  push r9
000074c379dd170b  push r10
000074c379dd170d  push r11
000074c379dd170f  sub rsp, 0xF0
000074c379dd1716  vmovaps [rsp], xmm0
000074c379dd171b  vmovaps [rsp+0x10], xmm1
000074c379dd1721  vmovaps [rsp+0x20], xmm2
000074c379dd1727  vmovaps [rsp+0x30], xmm3
000074c379dd172d  vmovaps [rsp+0x40], xmm4
000074c379dd1733  vmovaps [rsp+0x50], xmm5
000074c379dd1739  vmovaps [rsp+0x60], xmm6
000074c379dd173f  vmovaps [rsp+0x70], xmm7
000074c379dd1745  vmovaps [rsp+0x80], xmm8
000074c379dd174e  vmovaps [rsp+0x90], xmm9
000074c379dd1757  vmovaps [rsp+0xA0], xmm10
000074c379dd1760  vmovaps [rsp+0xB0], xmm11
000074c379dd1769  vmovaps [rsp+0xC0], xmm12
000074c379dd1772  vmovaps [rsp+0xD0], xmm13
000074c379dd177b  vmovaps [rsp+0xE0], xmm14
000074c379dd1784  sub rsp, 0x30
000074c379dd1788  movaps [rsp], xmm15
000074c379dd178d  movaps [rsp+0x10], xmm2
000074c379dd1792  movaps [rsp+0x20], xmm1
000074c379dd1797  lea rdi, [rsp]
000074c379dd179b  mov esi, 0x00
000074c379dd17a0  mov rax, 0x56321ABA4530
000074c379dd17aa  call rax
000074c379dd17ac  movaps xmm15, [rsp]
000074c379dd17b1  add rsp, 0x30
000074c379dd17b5  vmovaps xmm0, [rsp]
000074c379dd17ba  vmovaps xmm1, [rsp+0x10]
000074c379dd17c0  vmovaps xmm2, [rsp+0x20]
000074c379dd17c6  vmovaps xmm3, [rsp+0x30]
000074c379dd17cc  vmovaps xmm4, [rsp+0x40]
000074c379dd17d2  vmovaps xmm5, [rsp+0x50]
000074c379dd17d8  vmovaps xmm6, [rsp+0x60]
000074c379dd17de  vmovaps xmm7, [rsp+0x70]
000074c379dd17e4  vmovaps xmm8, [rsp+0x80]
000074c379dd17ed  vmovaps xmm9, [rsp+0x90]
000074c379dd17f6  vmovaps xmm10, [rsp+0xA0]
000074c379dd17ff  vmovaps xmm11, [rsp+0xB0]
000074c379dd1808  vmovaps xmm12, [rsp+0xC0]
000074c379dd1811  vmovaps xmm13, [rsp+0xD0]
000074c379dd181a  vmovaps xmm14, [rsp+0xE0]
000074c379dd1823  add rsp, 0xF0
000074c379dd182a  pop r11
000074c379dd182c  pop r10
000074c379dd182e  pop r9
000074c379dd1830  pop r8
000074c379dd1832  pop rsi
000074c379dd1833  pop rdi
000074c379dd1834  pop rdx
000074c379dd1835  pop rcx
000074c379dd1836  pop rax
000074c379dd1837  add rsp, 0x08
000074c379dd183b  jmp 0x000074C379DCF923
000074c379dd1840  call 0x000074C379BFF430
000074c379dd1845  jmp 0x000074C379DCF930
000074c379dd184a  sub rsp, 0x08
000074c379dd184e  push rax
000074c379dd184f  push rcx
000074c379dd1850  push rdx
000074c379dd1851  push rdi
000074c379dd1852  push rsi
000074c379dd1853  push r8
000074c379dd1855  push r9
000074c379dd1857  push r10
000074c379dd1859  push r11
000074c379dd185b  sub rsp, 0xF0
000074c379dd1862  vmovaps [rsp], xmm0
000074c379dd1867  vmovaps [rsp+0x10], xmm1
000074c379dd186d  vmovaps [rsp+0x20], xmm3
000074c379dd1873  vmovaps [rsp+0x30], xmm4
000074c379dd1879  vmovaps [rsp+0x40], xmm5
000074c379dd187f  vmovaps [rsp+0x50], xmm6
000074c379dd1885  vmovaps [rsp+0x60], xmm7
000074c379dd188b  vmovaps [rsp+0x70], xmm8
000074c379dd1891  vmovaps [rsp+0x80], xmm9
000074c379dd189a  vmovaps [rsp+0x90], xmm10
000074c379dd18a3  vmovaps [rsp+0xA0], xmm11
000074c379dd18ac  vmovaps [rsp+0xB0], xmm12
000074c379dd18b5  vmovaps [rsp+0xC0], xmm13
000074c379dd18be  vmovaps [rsp+0xD0], xmm14
000074c379dd18c7  vmovaps [rsp+0xE0], xmm15
000074c379dd18d0  sub rsp, 0x30
000074c379dd18d4  movaps [rsp], xmm2
000074c379dd18d8  movaps [rsp+0x10], xmm1
000074c379dd18dd  movaps [rsp+0x20], xmm14
000074c379dd18e3  lea rdi, [rsp]
000074c379dd18e7  mov esi, 0x00
000074c379dd18ec  mov rax, 0x56321ABA4530
000074c379dd18f6  call rax
000074c379dd18f8  movaps xmm2, [rsp]
000074c379dd18fc  add rsp, 0x30
000074c379dd1900  vmovaps xmm0, [rsp]
000074c379dd1905  vmovaps xmm1, [rsp+0x10]
000074c379dd190b  vmovaps xmm3, [rsp+0x20]
000074c379dd1911  vmovaps xmm4, [rsp+0x30]
000074c379dd1917  vmovaps xmm5, [rsp+0x40]
000074c379dd191d  vmovaps xmm6, [rsp+0x50]
000074c379dd1923  vmovaps xmm7, [rsp+0x60]
000074c379dd1929  vmovaps xmm8, [rsp+0x70]
000074c379dd192f  vmovaps xmm9, [rsp+0x80]
000074c379dd1938  vmovaps xmm10, [rsp+0x90]
000074c379dd1941  vmovaps xmm11, [rsp+0xA0]
000074c379dd194a  vmovaps xmm12, [rsp+0xB0]
000074c379dd1953  vmovaps xmm13, [rsp+0xC0]
000074c379dd195c  vmovaps xmm14, [rsp+0xD0]
000074c379dd1965  vmovaps xmm15, [rsp+0xE0]
000074c379dd196e  add rsp, 0xF0
000074c379dd1975  pop r11
000074c379dd1977  pop r10
000074c379dd1979  pop r9
000074c379dd197b  pop r8
000074c379dd197d  pop rsi
000074c379dd197e  pop rdi
000074c379dd197f  pop rdx
000074c379dd1980  pop rcx
000074c379dd1981  pop rax
000074c379dd1982  add rsp, 0x08
000074c379dd1986  jmp 0x000074C379DCF96D
000074c379dd198b  sub rsp, 0x08
000074c379dd198f  push rax
000074c379dd1990  push rcx
000074c379dd1991  push rdx
000074c379dd1992  push rdi
000074c379dd1993  push rsi
000074c379dd1994  push r8
000074c379dd1996  push r9
000074c379dd1998  push r10
000074c379dd199a  push r11
000074c379dd199c  sub rsp, 0xF0
000074c379dd19a3  vmovaps [rsp], xmm0
000074c379dd19a8  vmovaps [rsp+0x10], xmm1
000074c379dd19ae  vmovaps [rsp+0x20], xmm2
000074c379dd19b4  vmovaps [rsp+0x30], xmm3
000074c379dd19ba  vmovaps [rsp+0x40], xmm4
000074c379dd19c0  vmovaps [rsp+0x50], xmm5
000074c379dd19c6  vmovaps [rsp+0x60], xmm6
000074c379dd19cc  vmovaps [rsp+0x70], xmm7
000074c379dd19d2  vmovaps [rsp+0x80], xmm8
000074c379dd19db  vmovaps [rsp+0x90], xmm9
000074c379dd19e4  vmovaps [rsp+0xA0], xmm10
000074c379dd19ed  vmovaps [rsp+0xB0], xmm11
000074c379dd19f6  vmovaps [rsp+0xC0], xmm12
000074c379dd19ff  vmovaps [rsp+0xD0], xmm13
000074c379dd1a08  vmovaps [rsp+0xE0], xmm14
000074c379dd1a11  sub rsp, 0x30
000074c379dd1a15  movaps [rsp], xmm15
000074c379dd1a1a  movaps [rsp+0x10], xmm14
000074c379dd1a20  movaps [rsp+0x20], xmm1
000074c379dd1a25  lea rdi, [rsp]
000074c379dd1a29  mov esi, 0x00
000074c379dd1a2e  mov rax, 0x56321ABA4530
000074c379dd1a38  call rax
000074c379dd1a3a  movaps xmm15, [rsp]
000074c379dd1a3f  add rsp, 0x30
000074c379dd1a43  vmovaps xmm0, [rsp]
000074c379dd1a48  vmovaps xmm1, [rsp+0x10]
000074c379dd1a4e  vmovaps xmm2, [rsp+0x20]
000074c379dd1a54  vmovaps xmm3, [rsp+0x30]
000074c379dd1a5a  vmovaps xmm4, [rsp+0x40]
000074c379dd1a60  vmovaps xmm5, [rsp+0x50]
000074c379dd1a66  vmovaps xmm6, [rsp+0x60]
000074c379dd1a6c  vmovaps xmm7, [rsp+0x70]
000074c379dd1a72  vmovaps xmm8, [rsp+0x80]
000074c379dd1a7b  vmovaps xmm9, [rsp+0x90]
000074c379dd1a84  vmovaps xmm10, [rsp+0xA0]
000074c379dd1a8d  vmovaps xmm11, [rsp+0xB0]
000074c379dd1a96  vmovaps xmm12, [rsp+0xC0]
000074c379dd1a9f  vmovaps xmm13, [rsp+0xD0]
000074c379dd1aa8  vmovaps xmm14, [rsp+0xE0]
000074c379dd1ab1  add rsp, 0xF0
000074c379dd1ab8  pop r11
000074c379dd1aba  pop r10
000074c379dd1abc  pop r9
000074c379dd1abe  pop r8
000074c379dd1ac0  pop rsi
000074c379dd1ac1  pop rdi
000074c379dd1ac2  pop rdx
000074c379dd1ac3  pop rcx
000074c379dd1ac4  pop rax
000074c379dd1ac5  add rsp, 0x08
000074c379dd1ac9  jmp 0x000074C379DCF9E7
000074c379dd1ace  call 0x000074C379BFF430
000074c379dd1ad3  jmp 0x000074C379DCF9F4
000074c379dd1ad8  sub rsp, 0x08
000074c379dd1adc  push rax
000074c379dd1add  push rcx
000074c379dd1ade  push rdx
000074c379dd1adf  push rdi
000074c379dd1ae0  push rsi
000074c379dd1ae1  push r8
000074c379dd1ae3  push r9
000074c379dd1ae5  push r10
000074c379dd1ae7  push r11
000074c379dd1ae9  sub rsp, 0xF0
000074c379dd1af0  vmovaps [rsp], xmm0
000074c379dd1af5  vmovaps [rsp+0x10], xmm1
000074c379dd1afb  vmovaps [rsp+0x20], xmm2
000074c379dd1b01  vmovaps [rsp+0x30], xmm3
000074c379dd1b07  vmovaps [rsp+0x40], xmm4
000074c379dd1b0d  vmovaps [rsp+0x50], xmm5
000074c379dd1b13  vmovaps [rsp+0x60], xmm6
000074c379dd1b19  vmovaps [rsp+0x70], xmm7
000074c379dd1b1f  vmovaps [rsp+0x80], xmm8
000074c379dd1b28  vmovaps [rsp+0x90], xmm9
000074c379dd1b31  vmovaps [rsp+0xA0], xmm10
000074c379dd1b3a  vmovaps [rsp+0xB0], xmm11
000074c379dd1b43  vmovaps [rsp+0xC0], xmm12
000074c379dd1b4c  vmovaps [rsp+0xD0], xmm13
000074c379dd1b55  vmovaps [rsp+0xE0], xmm15
000074c379dd1b5e  sub rsp, 0x30
000074c379dd1b62  movaps [rsp], xmm14
000074c379dd1b67  movaps [rsp+0x10], xmm13
000074c379dd1b6d  movaps [rsp+0x20], xmm1
000074c379dd1b72  lea rdi, [rsp]
000074c379dd1b76  mov esi, 0x00
000074c379dd1b7b  mov rax, 0x56321ABA4530
000074c379dd1b85  call rax
000074c379dd1b87  movaps xmm14, [rsp]
000074c379dd1b8c  add rsp, 0x30
000074c379dd1b90  vmovaps xmm0, [rsp]
000074c379dd1b95  vmovaps xmm1, [rsp+0x10]
000074c379dd1b9b  vmovaps xmm2, [rsp+0x20]
000074c379dd1ba1  vmovaps xmm3, [rsp+0x30]
000074c379dd1ba7  vmovaps xmm4, [rsp+0x40]
000074c379dd1bad  vmovaps xmm5, [rsp+0x50]
000074c379dd1bb3  vmovaps xmm6, [rsp+0x60]
000074c379dd1bb9  vmovaps xmm7, [rsp+0x70]
000074c379dd1bbf  vmovaps xmm8, [rsp+0x80]
000074c379dd1bc8  vmovaps xmm9, [rsp+0x90]
000074c379dd1bd1  vmovaps xmm10, [rsp+0xA0]
000074c379dd1bda  vmovaps xmm11, [rsp+0xB0]
000074c379dd1be3  vmovaps xmm12, [rsp+0xC0]
000074c379dd1bec  vmovaps xmm13, [rsp+0xD0]
000074c379dd1bf5  vmovaps xmm15, [rsp+0xE0]
000074c379dd1bfe  add rsp, 0xF0
000074c379dd1c05  pop r11
000074c379dd1c07  pop r10
000074c379dd1c09  pop r9
000074c379dd1c0b  pop r8
000074c379dd1c0d  pop rsi
000074c379dd1c0e  pop rdi
000074c379dd1c0f  pop rdx
000074c379dd1c10  pop rcx
000074c379dd1c11  pop rax
000074c379dd1c12  add rsp, 0x08
000074c379dd1c16  jmp 0x000074C379DCFAAF
000074c379dd1c1b  sub rsp, 0x08
000074c379dd1c1f  push rax
000074c379dd1c20  push rcx
000074c379dd1c21  push rdx
000074c379dd1c22  push rdi
000074c379dd1c23  push rsi
000074c379dd1c24  push r8
000074c379dd1c26  push r9
000074c379dd1c28  push r10
000074c379dd1c2a  push r11
000074c379dd1c2c  sub rsp, 0xF0
000074c379dd1c33  vmovaps [rsp], xmm0
000074c379dd1c38  vmovaps [rsp+0x10], xmm1
000074c379dd1c3e  vmovaps [rsp+0x20], xmm2
000074c379dd1c44  vmovaps [rsp+0x30], xmm3
000074c379dd1c4a  vmovaps [rsp+0x40], xmm4
000074c379dd1c50  vmovaps [rsp+0x50], xmm5
000074c379dd1c56  vmovaps [rsp+0x60], xmm6
000074c379dd1c5c  vmovaps [rsp+0x70], xmm7
000074c379dd1c62  vmovaps [rsp+0x80], xmm8
000074c379dd1c6b  vmovaps [rsp+0x90], xmm9
000074c379dd1c74  vmovaps [rsp+0xA0], xmm10
000074c379dd1c7d  vmovaps [rsp+0xB0], xmm11
000074c379dd1c86  vmovaps [rsp+0xC0], xmm12
000074c379dd1c8f  vmovaps [rsp+0xD0], xmm13
000074c379dd1c98  vmovaps [rsp+0xE0], xmm14
000074c379dd1ca1  sub rsp, 0x30
000074c379dd1ca5  movaps [rsp], xmm15
000074c379dd1caa  movaps [rsp+0x10], xmm13
000074c379dd1cb0  movaps [rsp+0x20], xmm1
000074c379dd1cb5  lea rdi, [rsp]
000074c379dd1cb9  mov esi, 0x00
000074c379dd1cbe  mov rax, 0x56321ABA4530
000074c379dd1cc8  call rax
000074c379dd1cca  movaps xmm15, [rsp]
000074c379dd1ccf  add rsp, 0x30
000074c379dd1cd3  vmovaps xmm0, [rsp]
000074c379dd1cd8  vmovaps xmm1, [rsp+0x10]
000074c379dd1cde  vmovaps xmm2, [rsp+0x20]
000074c379dd1ce4  vmovaps xmm3, [rsp+0x30]
000074c379dd1cea  vmovaps xmm4, [rsp+0x40]
000074c379dd1cf0  vmovaps xmm5, [rsp+0x50]
000074c379dd1cf6  vmovaps xmm6, [rsp+0x60]
000074c379dd1cfc  vmovaps xmm7, [rsp+0x70]
000074c379dd1d02  vmovaps xmm8, [rsp+0x80]
000074c379dd1d0b  vmovaps xmm9, [rsp+0x90]
000074c379dd1d14  vmovaps xmm10, [rsp+0xA0]
000074c379dd1d1d  vmovaps xmm11, [rsp+0xB0]
000074c379dd1d26  vmovaps xmm12, [rsp+0xC0]
000074c379dd1d2f  vmovaps xmm13, [rsp+0xD0]
000074c379dd1d38  vmovaps xmm14, [rsp+0xE0]
000074c379dd1d41  add rsp, 0xF0
000074c379dd1d48  pop r11
000074c379dd1d4a  pop r10
000074c379dd1d4c  pop r9
000074c379dd1d4e  pop r8
000074c379dd1d50  pop rsi
000074c379dd1d51  pop rdi
000074c379dd1d52  pop rdx
000074c379dd1d53  pop rcx
000074c379dd1d54  pop rax
000074c379dd1d55  add rsp, 0x08
000074c379dd1d59  jmp 0x000074C379DCFAEB
000074c379dd1d5e  call 0x000074C379BFF430
000074c379dd1d63  jmp 0x000074C379DCFAF8
000074c379dd1d68  sub rsp, 0x08
000074c379dd1d6c  push rax
000074c379dd1d6d  push rcx
000074c379dd1d6e  push rdx
000074c379dd1d6f  push rdi
000074c379dd1d70  push rsi
000074c379dd1d71  push r8
000074c379dd1d73  push r9
000074c379dd1d75  push r10
000074c379dd1d77  push r11
000074c379dd1d79  sub rsp, 0xF0
000074c379dd1d80  vmovaps [rsp], xmm0
000074c379dd1d85  vmovaps [rsp+0x10], xmm1
000074c379dd1d8b  vmovaps [rsp+0x20], xmm2
000074c379dd1d91  vmovaps [rsp+0x30], xmm3
000074c379dd1d97  vmovaps [rsp+0x40], xmm4
000074c379dd1d9d  vmovaps [rsp+0x50], xmm5
000074c379dd1da3  vmovaps [rsp+0x60], xmm6
000074c379dd1da9  vmovaps [rsp+0x70], xmm7
000074c379dd1daf  vmovaps [rsp+0x80], xmm8
000074c379dd1db8  vmovaps [rsp+0x90], xmm9
000074c379dd1dc1  vmovaps [rsp+0xA0], xmm10
000074c379dd1dca  vmovaps [rsp+0xB0], xmm11
000074c379dd1dd3  vmovaps [rsp+0xC0], xmm12
000074c379dd1ddc  vmovaps [rsp+0xD0], xmm13
000074c379dd1de5  vmovaps [rsp+0xE0], xmm15
000074c379dd1dee  sub rsp, 0x30
000074c379dd1df2  movaps [rsp], xmm14
000074c379dd1df7  movaps [rsp+0x10], xmm13
000074c379dd1dfd  movaps [rsp+0x20], xmm2
000074c379dd1e02  lea rdi, [rsp]
000074c379dd1e06  mov esi, 0x00
000074c379dd1e0b  mov rax, 0x56321ABA4530
000074c379dd1e15  call rax
000074c379dd1e17  movaps xmm14, [rsp]
000074c379dd1e1c  add rsp, 0x30
000074c379dd1e20  vmovaps xmm0, [rsp]
000074c379dd1e25  vmovaps xmm1, [rsp+0x10]
000074c379dd1e2b  vmovaps xmm2, [rsp+0x20]
000074c379dd1e31  vmovaps xmm3, [rsp+0x30]
000074c379dd1e37  vmovaps xmm4, [rsp+0x40]
000074c379dd1e3d  vmovaps xmm5, [rsp+0x50]
000074c379dd1e43  vmovaps xmm6, [rsp+0x60]
000074c379dd1e49  vmovaps xmm7, [rsp+0x70]
000074c379dd1e4f  vmovaps xmm8, [rsp+0x80]
000074c379dd1e58  vmovaps xmm9, [rsp+0x90]
000074c379dd1e61  vmovaps xmm10, [rsp+0xA0]
000074c379dd1e6a  vmovaps xmm11, [rsp+0xB0]
000074c379dd1e73  vmovaps xmm12, [rsp+0xC0]
000074c379dd1e7c  vmovaps xmm13, [rsp+0xD0]
000074c379dd1e85  vmovaps xmm15, [rsp+0xE0]
000074c379dd1e8e  add rsp, 0xF0
000074c379dd1e95  pop r11
000074c379dd1e97  pop r10
000074c379dd1e99  pop r9
000074c379dd1e9b  pop r8
000074c379dd1e9d  pop rsi
000074c379dd1e9e  pop rdi
000074c379dd1e9f  pop rdx
000074c379dd1ea0  pop rcx
000074c379dd1ea1  pop rax
000074c379dd1ea2  add rsp, 0x08
000074c379dd1ea6  jmp 0x000074C379DCFB24
000074c379dd1eab  sub rsp, 0x08
000074c379dd1eaf  push rax
000074c379dd1eb0  push rcx
000074c379dd1eb1  push rdx
000074c379dd1eb2  push rdi
000074c379dd1eb3  push rsi
000074c379dd1eb4  push r8
000074c379dd1eb6  push r9
000074c379dd1eb8  push r10
000074c379dd1eba  push r11
000074c379dd1ebc  sub rsp, 0xF0
000074c379dd1ec3  vmovaps [rsp], xmm0
000074c379dd1ec8  vmovaps [rsp+0x10], xmm2
000074c379dd1ece  vmovaps [rsp+0x20], xmm3
000074c379dd1ed4  vmovaps [rsp+0x30], xmm4
000074c379dd1eda  vmovaps [rsp+0x40], xmm5
000074c379dd1ee0  vmovaps [rsp+0x50], xmm6
000074c379dd1ee6  vmovaps [rsp+0x60], xmm7
000074c379dd1eec  vmovaps [rsp+0x70], xmm8
000074c379dd1ef2  vmovaps [rsp+0x80], xmm9
000074c379dd1efb  vmovaps [rsp+0x90], xmm10
000074c379dd1f04  vmovaps [rsp+0xA0], xmm11
000074c379dd1f0d  vmovaps [rsp+0xB0], xmm12
000074c379dd1f16  vmovaps [rsp+0xC0], xmm13
000074c379dd1f1f  vmovaps [rsp+0xD0], xmm14
000074c379dd1f28  vmovaps [rsp+0xE0], xmm15
000074c379dd1f31  sub rsp, 0x30
000074c379dd1f35  movaps [rsp], xmm1
000074c379dd1f39  movaps [rsp+0x10], xmm13
000074c379dd1f3f  movaps [rsp+0x20], xmm2
000074c379dd1f44  lea rdi, [rsp]
000074c379dd1f48  mov esi, 0x00
000074c379dd1f4d  mov rax, 0x56321ABA4530
000074c379dd1f57  call rax
000074c379dd1f59  movaps xmm1, [rsp]
000074c379dd1f5d  add rsp, 0x30
000074c379dd1f61  vmovaps xmm0, [rsp]
000074c379dd1f66  vmovaps xmm2, [rsp+0x10]
000074c379dd1f6c  vmovaps xmm3, [rsp+0x20]
000074c379dd1f72  vmovaps xmm4, [rsp+0x30]
000074c379dd1f78  vmovaps xmm5, [rsp+0x40]
000074c379dd1f7e  vmovaps xmm6, [rsp+0x50]
000074c379dd1f84  vmovaps xmm7, [rsp+0x60]
000074c379dd1f8a  vmovaps xmm8, [rsp+0x70]
000074c379dd1f90  vmovaps xmm9, [rsp+0x80]
000074c379dd1f99  vmovaps xmm10, [rsp+0x90]
000074c379dd1fa2  vmovaps xmm11, [rsp+0xA0]
000074c379dd1fab  vmovaps xmm12, [rsp+0xB0]
000074c379dd1fb4  vmovaps xmm13, [rsp+0xC0]
000074c379dd1fbd  vmovaps xmm14, [rsp+0xD0]
000074c379dd1fc6  vmovaps xmm15, [rsp+0xE0]
000074c379dd1fcf  add rsp, 0xF0
000074c379dd1fd6  pop r11
000074c379dd1fd8  pop r10
000074c379dd1fda  pop r9
000074c379dd1fdc  pop r8
000074c379dd1fde  pop rsi
000074c379dd1fdf  pop rdi
000074c379dd1fe0  pop rdx
000074c379dd1fe1  pop rcx
000074c379dd1fe2  pop rax
000074c379dd1fe3  add rsp, 0x08
000074c379dd1fe7  jmp 0x000074C379DCFB52
000074c379dd1fec  sub rsp, 0x08
000074c379dd1ff0  push rax
000074c379dd1ff1  push rcx
000074c379dd1ff2  push rdx
000074c379dd1ff3  push rdi
000074c379dd1ff4  push rsi
000074c379dd1ff5  push r8
000074c379dd1ff7  push r9
000074c379dd1ff9  push r10
000074c379dd1ffb  push r11
000074c379dd1ffd  sub rsp, 0xF0
000074c379dd2004  vmovaps [rsp], xmm0
000074c379dd2009  vmovaps [rsp+0x10], xmm1
000074c379dd200f  vmovaps [rsp+0x20], xmm3
000074c379dd2015  vmovaps [rsp+0x30], xmm4
000074c379dd201b  vmovaps [rsp+0x40], xmm5
000074c379dd2021  vmovaps [rsp+0x50], xmm6
000074c379dd2027  vmovaps [rsp+0x60], xmm7
000074c379dd202d  vmovaps [rsp+0x70], xmm8
000074c379dd2033  vmovaps [rsp+0x80], xmm9
000074c379dd203c  vmovaps [rsp+0x90], xmm10
000074c379dd2045  vmovaps [rsp+0xA0], xmm11
000074c379dd204e  vmovaps [rsp+0xB0], xmm12
000074c379dd2057  vmovaps [rsp+0xC0], xmm13
000074c379dd2060  vmovaps [rsp+0xD0], xmm14
000074c379dd2069  vmovaps [rsp+0xE0], xmm15
000074c379dd2072  sub rsp, 0x30
000074c379dd2076  movaps [rsp], xmm2
000074c379dd207a  movaps [rsp+0x10], xmm1
000074c379dd207f  movaps [rsp+0x20], xmm13
000074c379dd2085  lea rdi, [rsp]
000074c379dd2089  mov esi, 0x00
000074c379dd208e  mov rax, 0x56321ABA4530
000074c379dd2098  call rax
000074c379dd209a  movaps xmm2, [rsp]
000074c379dd209e  add rsp, 0x30
000074c379dd20a2  vmovaps xmm0, [rsp]
000074c379dd20a7  vmovaps xmm1, [rsp+0x10]
000074c379dd20ad  vmovaps xmm3, [rsp+0x20]
000074c379dd20b3  vmovaps xmm4, [rsp+0x30]
000074c379dd20b9  vmovaps xmm5, [rsp+0x40]
000074c379dd20bf  vmovaps xmm6, [rsp+0x50]
000074c379dd20c5  vmovaps xmm7, [rsp+0x60]
000074c379dd20cb  vmovaps xmm8, [rsp+0x70]
000074c379dd20d1  vmovaps xmm9, [rsp+0x80]
000074c379dd20da  vmovaps xmm10, [rsp+0x90]
000074c379dd20e3  vmovaps xmm11, [rsp+0xA0]
000074c379dd20ec  vmovaps xmm12, [rsp+0xB0]
000074c379dd20f5  vmovaps xmm13, [rsp+0xC0]
000074c379dd20fe  vmovaps xmm14, [rsp+0xD0]
000074c379dd2107  vmovaps xmm15, [rsp+0xE0]
000074c379dd2110  add rsp, 0xF0
000074c379dd2117  pop r11
000074c379dd2119  pop r10
000074c379dd211b  pop r9
000074c379dd211d  pop r8
000074c379dd211f  pop rsi
000074c379dd2120  pop rdi
000074c379dd2121  pop rdx
000074c379dd2122  pop rcx
000074c379dd2123  pop rax
000074c379dd2124  add rsp, 0x08
000074c379dd2128  jmp 0x000074C379DCFBAB
000074c379dd212d  call 0x000074C379BFF430
000074c379dd2132  jmp 0x000074C379DCFBB8
000074c379dd2137  sub rsp, 0x08
000074c379dd213b  push rax
000074c379dd213c  push rcx
000074c379dd213d  push rdx
000074c379dd213e  push rdi
000074c379dd213f  push rsi
000074c379dd2140  push r8
000074c379dd2142  push r9
000074c379dd2144  push r10
000074c379dd2146  push r11
000074c379dd2148  sub rsp, 0xF0
000074c379dd214f  vmovaps [rsp], xmm0
000074c379dd2154  vmovaps [rsp+0x10], xmm1
000074c379dd215a  vmovaps [rsp+0x20], xmm2
000074c379dd2160  vmovaps [rsp+0x30], xmm3
000074c379dd2166  vmovaps [rsp+0x40], xmm4
000074c379dd216c  vmovaps [rsp+0x50], xmm5
000074c379dd2172  vmovaps [rsp+0x60], xmm6
000074c379dd2178  vmovaps [rsp+0x70], xmm7
000074c379dd217e  vmovaps [rsp+0x80], xmm8
000074c379dd2187  vmovaps [rsp+0x90], xmm9
000074c379dd2190  vmovaps [rsp+0xA0], xmm10
000074c379dd2199  vmovaps [rsp+0xB0], xmm11
000074c379dd21a2  vmovaps [rsp+0xC0], xmm12
000074c379dd21ab  vmovaps [rsp+0xD0], xmm13
000074c379dd21b4  vmovaps [rsp+0xE0], xmm14
000074c379dd21bd  sub rsp, 0x30
000074c379dd21c1  movaps [rsp], xmm15
000074c379dd21c6  movaps [rsp+0x10], xmm13
000074c379dd21cc  movaps [rsp+0x20], xmm1
000074c379dd21d1  lea rdi, [rsp]
000074c379dd21d5  mov esi, 0x00
000074c379dd21da  mov rax, 0x56321ABA4530
000074c379dd21e4  call rax
000074c379dd21e6  movaps xmm15, [rsp]
000074c379dd21eb  add rsp, 0x30
000074c379dd21ef  vmovaps xmm0, [rsp]
000074c379dd21f4  vmovaps xmm1, [rsp+0x10]
000074c379dd21fa  vmovaps xmm2, [rsp+0x20]
000074c379dd2200  vmovaps xmm3, [rsp+0x30]
000074c379dd2206  vmovaps xmm4, [rsp+0x40]
000074c379dd220c  vmovaps xmm5, [rsp+0x50]
000074c379dd2212  vmovaps xmm6, [rsp+0x60]
000074c379dd2218  vmovaps xmm7, [rsp+0x70]
000074c379dd221e  vmovaps xmm8, [rsp+0x80]
000074c379dd2227  vmovaps xmm9, [rsp+0x90]
000074c379dd2230  vmovaps xmm10, [rsp+0xA0]
000074c379dd2239  vmovaps xmm11, [rsp+0xB0]
000074c379dd2242  vmovaps xmm12, [rsp+0xC0]
000074c379dd224b  vmovaps xmm13, [rsp+0xD0]
000074c379dd2254  vmovaps xmm14, [rsp+0xE0]
000074c379dd225d  add rsp, 0xF0
000074c379dd2264  pop r11
000074c379dd2266  pop r10
000074c379dd2268  pop r9
000074c379dd226a  pop r8
000074c379dd226c  pop rsi
000074c379dd226d  pop rdi
000074c379dd226e  pop rdx
000074c379dd226f  pop rcx
000074c379dd2270  pop rax
000074c379dd2271  add rsp, 0x08
000074c379dd2275  jmp 0x000074C379DCFBF7
000074c379dd227a  sub rsp, 0x08
000074c379dd227e  push rax
000074c379dd227f  push rcx
000074c379dd2280  push rdx
000074c379dd2281  push rdi
000074c379dd2282  push rsi
000074c379dd2283  push r8
000074c379dd2285  push r9
000074c379dd2287  push r10
000074c379dd2289  push r11
000074c379dd228b  sub rsp, 0xF0
000074c379dd2292  vmovaps [rsp], xmm0
000074c379dd2297  vmovaps [rsp+0x10], xmm1
000074c379dd229d  vmovaps [rsp+0x20], xmm2
000074c379dd22a3  vmovaps [rsp+0x30], xmm3
000074c379dd22a9  vmovaps [rsp+0x40], xmm4
000074c379dd22af  vmovaps [rsp+0x50], xmm5
000074c379dd22b5  vmovaps [rsp+0x60], xmm6
000074c379dd22bb  vmovaps [rsp+0x70], xmm7
000074c379dd22c1  vmovaps [rsp+0x80], xmm8
000074c379dd22ca  vmovaps [rsp+0x90], xmm9
000074c379dd22d3  vmovaps [rsp+0xA0], xmm10
000074c379dd22dc  vmovaps [rsp+0xB0], xmm11
000074c379dd22e5  vmovaps [rsp+0xC0], xmm12
000074c379dd22ee  vmovaps [rsp+0xD0], xmm13
000074c379dd22f7  vmovaps [rsp+0xE0], xmm15
000074c379dd2300  sub rsp, 0x30
000074c379dd2304  movaps [rsp], xmm14
000074c379dd2309  movaps [rsp+0x10], xmm11
000074c379dd230f  movaps [rsp+0x20], xmm1
000074c379dd2314  lea rdi, [rsp]
000074c379dd2318  mov esi, 0x00
000074c379dd231d  mov rax, 0x56321ABA4530
000074c379dd2327  call rax
000074c379dd2329  movaps xmm14, [rsp]
000074c379dd232e  add rsp, 0x30
000074c379dd2332  vmovaps xmm0, [rsp]
000074c379dd2337  vmovaps xmm1, [rsp+0x10]
000074c379dd233d  vmovaps xmm2, [rsp+0x20]
000074c379dd2343  vmovaps xmm3, [rsp+0x30]
000074c379dd2349  vmovaps xmm4, [rsp+0x40]
000074c379dd234f  vmovaps xmm5, [rsp+0x50]
000074c379dd2355  vmovaps xmm6, [rsp+0x60]
000074c379dd235b  vmovaps xmm7, [rsp+0x70]
000074c379dd2361  vmovaps xmm8, [rsp+0x80]
000074c379dd236a  vmovaps xmm9, [rsp+0x90]
000074c379dd2373  vmovaps xmm10, [rsp+0xA0]
000074c379dd237c  vmovaps xmm11, [rsp+0xB0]
000074c379dd2385  vmovaps xmm12, [rsp+0xC0]
000074c379dd238e  vmovaps xmm13, [rsp+0xD0]
000074c379dd2397  vmovaps xmm15, [rsp+0xE0]
000074c379dd23a0  add rsp, 0xF0
000074c379dd23a7  pop r11
000074c379dd23a9  pop r10
000074c379dd23ab  pop r9
000074c379dd23ad  pop r8
000074c379dd23af  pop rsi
000074c379dd23b0  pop rdi
000074c379dd23b1  pop rdx
000074c379dd23b2  pop rcx
000074c379dd23b3  pop rax
000074c379dd23b4  add rsp, 0x08
000074c379dd23b8  jmp 0x000074C379DCFC21
000074c379dd23bd  sub rsp, 0x08
000074c379dd23c1  push rax
000074c379dd23c2  push rcx
000074c379dd23c3  push rdx
000074c379dd23c4  push rdi
000074c379dd23c5  push rsi
000074c379dd23c6  push r8
000074c379dd23c8  push r9
000074c379dd23ca  push r10
000074c379dd23cc  push r11
000074c379dd23ce  sub rsp, 0xF0
000074c379dd23d5  vmovaps [rsp], xmm0
000074c379dd23da  vmovaps [rsp+0x10], xmm1
000074c379dd23e0  vmovaps [rsp+0x20], xmm2
000074c379dd23e6  vmovaps [rsp+0x30], xmm3
000074c379dd23ec  vmovaps [rsp+0x40], xmm4
000074c379dd23f2  vmovaps [rsp+0x50], xmm5
000074c379dd23f8  vmovaps [rsp+0x60], xmm6
000074c379dd23fe  vmovaps [rsp+0x70], xmm7
000074c379dd2404  vmovaps [rsp+0x80], xmm8
000074c379dd240d  vmovaps [rsp+0x90], xmm9
000074c379dd2416  vmovaps [rsp+0xA0], xmm10
000074c379dd241f  vmovaps [rsp+0xB0], xmm11
000074c379dd2428  vmovaps [rsp+0xC0], xmm12
000074c379dd2431  vmovaps [rsp+0xD0], xmm14
000074c379dd243a  vmovaps [rsp+0xE0], xmm15
000074c379dd2443  sub rsp, 0x30
000074c379dd2447  movaps [rsp], xmm13
000074c379dd244c  movaps [rsp+0x10], xmm11
000074c379dd2452  movaps [rsp+0x20], xmm1
000074c379dd2457  lea rdi, [rsp]
000074c379dd245b  mov esi, 0x00
000074c379dd2460  mov rax, 0x56321ABA4530
000074c379dd246a  call rax
000074c379dd246c  movaps xmm13, [rsp]
000074c379dd2471  add rsp, 0x30
000074c379dd2475  vmovaps xmm0, [rsp]
000074c379dd247a  vmovaps xmm1, [rsp+0x10]
000074c379dd2480  vmovaps xmm2, [rsp+0x20]
000074c379dd2486  vmovaps xmm3, [rsp+0x30]
000074c379dd248c  vmovaps xmm4, [rsp+0x40]
000074c379dd2492  vmovaps xmm5, [rsp+0x50]
000074c379dd2498  vmovaps xmm6, [rsp+0x60]
000074c379dd249e  vmovaps xmm7, [rsp+0x70]
000074c379dd24a4  vmovaps xmm8, [rsp+0x80]
000074c379dd24ad  vmovaps xmm9, [rsp+0x90]
000074c379dd24b6  vmovaps xmm10, [rsp+0xA0]
000074c379dd24bf  vmovaps xmm11, [rsp+0xB0]
000074c379dd24c8  vmovaps xmm12, [rsp+0xC0]
000074c379dd24d1  vmovaps xmm14, [rsp+0xD0]
000074c379dd24da  vmovaps xmm15, [rsp+0xE0]
000074c379dd24e3  add rsp, 0xF0
000074c379dd24ea  pop r11
000074c379dd24ec  pop r10
000074c379dd24ee  pop r9
000074c379dd24f0  pop r8
000074c379dd24f2  pop rsi
000074c379dd24f3  pop rdi
000074c379dd24f4  pop rdx
000074c379dd24f5  pop rcx
000074c379dd24f6  pop rax
000074c379dd24f7  add rsp, 0x08
000074c379dd24fb  jmp 0x000074C379DCFC76
000074c379dd2500  call 0x000074C379BFF430
000074c379dd2505  jmp 0x000074C379DCFC83
000074c379dd250a  sub rsp, 0x08
000074c379dd250e  push rax
000074c379dd250f  push rcx
000074c379dd2510  push rdx
000074c379dd2511  push rdi
000074c379dd2512  push rsi
000074c379dd2513  push r8
000074c379dd2515  push r9
000074c379dd2517  push r10
000074c379dd2519  push r11
000074c379dd251b  sub rsp, 0xF0
000074c379dd2522  vmovaps [rsp], xmm0
000074c379dd2527  vmovaps [rsp+0x10], xmm1
000074c379dd252d  vmovaps [rsp+0x20], xmm2
000074c379dd2533  vmovaps [rsp+0x30], xmm3
000074c379dd2539  vmovaps [rsp+0x40], xmm4
000074c379dd253f  vmovaps [rsp+0x50], xmm5
000074c379dd2545  vmovaps [rsp+0x60], xmm6
000074c379dd254b  vmovaps [rsp+0x70], xmm7
000074c379dd2551  vmovaps [rsp+0x80], xmm8
000074c379dd255a  vmovaps [rsp+0x90], xmm9
000074c379dd2563  vmovaps [rsp+0xA0], xmm10
000074c379dd256c  vmovaps [rsp+0xB0], xmm11
000074c379dd2575  vmovaps [rsp+0xC0], xmm12
000074c379dd257e  vmovaps [rsp+0xD0], xmm13
000074c379dd2587  vmovaps [rsp+0xE0], xmm14
000074c379dd2590  sub rsp, 0x30
000074c379dd2594  movaps [rsp], xmm15
000074c379dd2599  movaps [rsp+0x10], xmm11
000074c379dd259f  movaps [rsp+0x20], xmm1
000074c379dd25a4  lea rdi, [rsp]
000074c379dd25a8  mov esi, 0x00
000074c379dd25ad  mov rax, 0x56321ABA4530
000074c379dd25b7  call rax
000074c379dd25b9  movaps xmm15, [rsp]
000074c379dd25be  add rsp, 0x30
000074c379dd25c2  vmovaps xmm0, [rsp]
000074c379dd25c7  vmovaps xmm1, [rsp+0x10]
000074c379dd25cd  vmovaps xmm2, [rsp+0x20]
000074c379dd25d3  vmovaps xmm3, [rsp+0x30]
000074c379dd25d9  vmovaps xmm4, [rsp+0x40]
000074c379dd25df  vmovaps xmm5, [rsp+0x50]
000074c379dd25e5  vmovaps xmm6, [rsp+0x60]
000074c379dd25eb  vmovaps xmm7, [rsp+0x70]
000074c379dd25f1  vmovaps xmm8, [rsp+0x80]
000074c379dd25fa  vmovaps xmm9, [rsp+0x90]
000074c379dd2603  vmovaps xmm10, [rsp+0xA0]
000074c379dd260c  vmovaps xmm11, [rsp+0xB0]
000074c379dd2615  vmovaps xmm12, [rsp+0xC0]
000074c379dd261e  vmovaps xmm13, [rsp+0xD0]
000074c379dd2627  vmovaps xmm14, [rsp+0xE0]
000074c379dd2630  add rsp, 0xF0
000074c379dd2637  pop r11
000074c379dd2639  pop r10
000074c379dd263b  pop r9
000074c379dd263d  pop r8
000074c379dd263f  pop rsi
000074c379dd2640  pop rdi
000074c379dd2641  pop rdx
000074c379dd2642  pop rcx
000074c379dd2643  pop rax
000074c379dd2644  add rsp, 0x08
000074c379dd2648  jmp 0x000074C379DCFCBC
000074c379dd264d  sub rsp, 0x08
000074c379dd2651  push rax
000074c379dd2652  push rcx
000074c379dd2653  push rdx
000074c379dd2654  push rdi
000074c379dd2655  push rsi
000074c379dd2656  push r8
000074c379dd2658  push r9
000074c379dd265a  push r10
000074c379dd265c  push r11
000074c379dd265e  sub rsp, 0xF0
000074c379dd2665  vmovaps [rsp], xmm0
000074c379dd266a  vmovaps [rsp+0x10], xmm1
000074c379dd2670  vmovaps [rsp+0x20], xmm2
000074c379dd2676  vmovaps [rsp+0x30], xmm3
000074c379dd267c  vmovaps [rsp+0x40], xmm4
000074c379dd2682  vmovaps [rsp+0x50], xmm5
000074c379dd2688  vmovaps [rsp+0x60], xmm6
000074c379dd268e  vmovaps [rsp+0x70], xmm7
000074c379dd2694  vmovaps [rsp+0x80], xmm8
000074c379dd269d  vmovaps [rsp+0x90], xmm9
000074c379dd26a6  vmovaps [rsp+0xA0], xmm10
000074c379dd26af  vmovaps [rsp+0xB0], xmm12
000074c379dd26b8  vmovaps [rsp+0xC0], xmm13
000074c379dd26c1  vmovaps [rsp+0xD0], xmm14
000074c379dd26ca  vmovaps [rsp+0xE0], xmm15
000074c379dd26d3  sub rsp, 0x30
000074c379dd26d7  movaps [rsp], xmm11
000074c379dd26dc  movaps [rsp+0x10], xmm6
000074c379dd26e1  movaps [rsp+0x20], xmm14
000074c379dd26e7  lea rdi, [rsp]
000074c379dd26eb  mov esi, 0x00
000074c379dd26f0  mov rax, 0x56321ABA4530
000074c379dd26fa  call rax
000074c379dd26fc  movaps xmm11, [rsp]
000074c379dd2701  add rsp, 0x30
000074c379dd2705  vmovaps xmm0, [rsp]
000074c379dd270a  vmovaps xmm1, [rsp+0x10]
000074c379dd2710  vmovaps xmm2, [rsp+0x20]
000074c379dd2716  vmovaps xmm3, [rsp+0x30]
000074c379dd271c  vmovaps xmm4, [rsp+0x40]
000074c379dd2722  vmovaps xmm5, [rsp+0x50]
000074c379dd2728  vmovaps xmm6, [rsp+0x60]
000074c379dd272e  vmovaps xmm7, [rsp+0x70]
000074c379dd2734  vmovaps xmm8, [rsp+0x80]
000074c379dd273d  vmovaps xmm9, [rsp+0x90]
000074c379dd2746  vmovaps xmm10, [rsp+0xA0]
000074c379dd274f  vmovaps xmm12, [rsp+0xB0]
000074c379dd2758  vmovaps xmm13, [rsp+0xC0]
000074c379dd2761  vmovaps xmm14, [rsp+0xD0]
000074c379dd276a  vmovaps xmm15, [rsp+0xE0]
000074c379dd2773  add rsp, 0xF0
000074c379dd277a  pop r11
000074c379dd277c  pop r10
000074c379dd277e  pop r9
000074c379dd2780  pop r8
000074c379dd2782  pop rsi
000074c379dd2783  pop rdi
000074c379dd2784  pop rdx
000074c379dd2785  pop rcx
000074c379dd2786  pop rax
000074c379dd2787  add rsp, 0x08
000074c379dd278b  jmp 0x000074C379DCFD34
000074c379dd2790  call 0x000074C379BFF430
000074c379dd2795  jmp 0x000074C379DCFD3E
000074c379dd279a  sub rsp, 0x08
000074c379dd279e  push rax
000074c379dd279f  push rcx
000074c379dd27a0  push rdx
000074c379dd27a1  push rdi
000074c379dd27a2  push rsi
000074c379dd27a3  push r8
000074c379dd27a5  push r9
000074c379dd27a7  push r10
000074c379dd27a9  push r11
000074c379dd27ab  sub rsp, 0xF0
000074c379dd27b2  vmovaps [rsp], xmm0
000074c379dd27b7  vmovaps [rsp+0x10], xmm1
000074c379dd27bd  vmovaps [rsp+0x20], xmm2
000074c379dd27c3  vmovaps [rsp+0x30], xmm3
000074c379dd27c9  vmovaps [rsp+0x40], xmm4
000074c379dd27cf  vmovaps [rsp+0x50], xmm5
000074c379dd27d5  vmovaps [rsp+0x60], xmm6
000074c379dd27db  vmovaps [rsp+0x70], xmm7
000074c379dd27e1  vmovaps [rsp+0x80], xmm8
000074c379dd27ea  vmovaps [rsp+0x90], xmm9
000074c379dd27f3  vmovaps [rsp+0xA0], xmm10
000074c379dd27fc  vmovaps [rsp+0xB0], xmm11
000074c379dd2805  vmovaps [rsp+0xC0], xmm12
000074c379dd280e  vmovaps [rsp+0xD0], xmm13
000074c379dd2817  vmovaps [rsp+0xE0], xmm15
000074c379dd2820  sub rsp, 0x30
000074c379dd2824  movaps [rsp], xmm14
000074c379dd2829  movaps [rsp+0x10], xmm6
000074c379dd282e  movaps [rsp+0x20], xmm2
000074c379dd2833  lea rdi, [rsp]
000074c379dd2837  mov esi, 0x00
000074c379dd283c  mov rax, 0x56321ABA4530
000074c379dd2846  call rax
000074c379dd2848  movaps xmm14, [rsp]
000074c379dd284d  add rsp, 0x30
000074c379dd2851  vmovaps xmm0, [rsp]
000074c379dd2856  vmovaps xmm1, [rsp+0x10]
000074c379dd285c  vmovaps xmm2, [rsp+0x20]
000074c379dd2862  vmovaps xmm3, [rsp+0x30]
000074c379dd2868  vmovaps xmm4, [rsp+0x40]
000074c379dd286e  vmovaps xmm5, [rsp+0x50]
000074c379dd2874  vmovaps xmm6, [rsp+0x60]
000074c379dd287a  vmovaps xmm7, [rsp+0x70]
000074c379dd2880  vmovaps xmm8, [rsp+0x80]
000074c379dd2889  vmovaps xmm9, [rsp+0x90]
000074c379dd2892  vmovaps xmm10, [rsp+0xA0]
000074c379dd289b  vmovaps xmm11, [rsp+0xB0]
000074c379dd28a4  vmovaps xmm12, [rsp+0xC0]
000074c379dd28ad  vmovaps xmm13, [rsp+0xD0]
000074c379dd28b6  vmovaps xmm15, [rsp+0xE0]
000074c379dd28bf  add rsp, 0xF0
000074c379dd28c6  pop r11
000074c379dd28c8  pop r10
000074c379dd28ca  pop r9
000074c379dd28cc  pop r8
000074c379dd28ce  pop rsi
000074c379dd28cf  pop rdi
000074c379dd28d0  pop rdx
000074c379dd28d1  pop rcx
000074c379dd28d2  pop rax
000074c379dd28d3  add rsp, 0x08
000074c379dd28d7  jmp 0x000074C379DCFD72
000074c379dd28dc  sub rsp, 0x08
000074c379dd28e0  push rax
000074c379dd28e1  push rcx
000074c379dd28e2  push rdx
000074c379dd28e3  push rdi
000074c379dd28e4  push rsi
000074c379dd28e5  push r8
000074c379dd28e7  push r9
000074c379dd28e9  push r10
000074c379dd28eb  push r11
000074c379dd28ed  sub rsp, 0xF0
000074c379dd28f4  vmovaps [rsp], xmm0
000074c379dd28f9  vmovaps [rsp+0x10], xmm1
000074c379dd28ff  vmovaps [rsp+0x20], xmm2
000074c379dd2905  vmovaps [rsp+0x30], xmm3
000074c379dd290b  vmovaps [rsp+0x40], xmm4
000074c379dd2911  vmovaps [rsp+0x50], xmm5
000074c379dd2917  vmovaps [rsp+0x60], xmm7
000074c379dd291d  vmovaps [rsp+0x70], xmm8
000074c379dd2923  vmovaps [rsp+0x80], xmm9
000074c379dd292c  vmovaps [rsp+0x90], xmm10
000074c379dd2935  vmovaps [rsp+0xA0], xmm11
000074c379dd293e  vmovaps [rsp+0xB0], xmm12
000074c379dd2947  vmovaps [rsp+0xC0], xmm13
000074c379dd2950  vmovaps [rsp+0xD0], xmm14
000074c379dd2959  vmovaps [rsp+0xE0], xmm15
000074c379dd2962  sub rsp, 0x30
000074c379dd2966  movaps [rsp], xmm6
000074c379dd296a  movaps [rsp+0x10], xmm5
000074c379dd296f  movaps [rsp+0x20], xmm1
000074c379dd2974  lea rdi, [rsp]
000074c379dd2978  mov esi, 0x00
000074c379dd297d  mov rax, 0x56321ABA4530
000074c379dd2987  call rax
000074c379dd2989  movaps xmm6, [rsp]
000074c379dd298d  add rsp, 0x30
000074c379dd2991  vmovaps xmm0, [rsp]
000074c379dd2996  vmovaps xmm1, [rsp+0x10]
000074c379dd299c  vmovaps xmm2, [rsp+0x20]
000074c379dd29a2  vmovaps xmm3, [rsp+0x30]
000074c379dd29a8  vmovaps xmm4, [rsp+0x40]
000074c379dd29ae  vmovaps xmm5, [rsp+0x50]
000074c379dd29b4  vmovaps xmm7, [rsp+0x60]
000074c379dd29ba  vmovaps xmm8, [rsp+0x70]
000074c379dd29c0  vmovaps xmm9, [rsp+0x80]
000074c379dd29c9  vmovaps xmm10, [rsp+0x90]
000074c379dd29d2  vmovaps xmm11, [rsp+0xA0]
000074c379dd29db  vmovaps xmm12, [rsp+0xB0]
000074c379dd29e4  vmovaps xmm13, [rsp+0xC0]
000074c379dd29ed  vmovaps xmm14, [rsp+0xD0]
000074c379dd29f6  vmovaps xmm15, [rsp+0xE0]
000074c379dd29ff  add rsp, 0xF0
000074c379dd2a06  pop r11
000074c379dd2a08  pop r10
000074c379dd2a0a  pop r9
000074c379dd2a0c  pop r8
000074c379dd2a0e  pop rsi
000074c379dd2a0f  pop rdi
000074c379dd2a10  pop rdx
000074c379dd2a11  pop rcx
000074c379dd2a12  pop rax
000074c379dd2a13  add rsp, 0x08
000074c379dd2a17  jmp 0x000074C379DCFD98
000074c379dd2a1c  sub rsp, 0x08
000074c379dd2a20  push rax
000074c379dd2a21  push rcx
000074c379dd2a22  push rdx
000074c379dd2a23  push rdi
000074c379dd2a24  push rsi
000074c379dd2a25  push r8
000074c379dd2a27  push r9
000074c379dd2a29  push r10
000074c379dd2a2b  push r11
000074c379dd2a2d  sub rsp, 0xF0
000074c379dd2a34  vmovaps [rsp], xmm0
000074c379dd2a39  vmovaps [rsp+0x10], xmm2
000074c379dd2a3f  vmovaps [rsp+0x20], xmm3
000074c379dd2a45  vmovaps [rsp+0x30], xmm4
000074c379dd2a4b  vmovaps [rsp+0x40], xmm5
000074c379dd2a51  vmovaps [rsp+0x50], xmm6
000074c379dd2a57  vmovaps [rsp+0x60], xmm7
000074c379dd2a5d  vmovaps [rsp+0x70], xmm8
000074c379dd2a63  vmovaps [rsp+0x80], xmm9
000074c379dd2a6c  vmovaps [rsp+0x90], xmm10
000074c379dd2a75  vmovaps [rsp+0xA0], xmm11
000074c379dd2a7e  vmovaps [rsp+0xB0], xmm12
000074c379dd2a87  vmovaps [rsp+0xC0], xmm13
000074c379dd2a90  vmovaps [rsp+0xD0], xmm14
000074c379dd2a99  vmovaps [rsp+0xE0], xmm15
000074c379dd2aa2  sub rsp, 0x30
000074c379dd2aa6  movaps [rsp], xmm1
000074c379dd2aaa  movaps [rsp+0x10], xmm5
000074c379dd2aaf  movaps [rsp+0x20], xmm13
000074c379dd2ab5  lea rdi, [rsp]
000074c379dd2ab9  mov esi, 0x00
000074c379dd2abe  mov rax, 0x56321ABA4530
000074c379dd2ac8  call rax
000074c379dd2aca  movaps xmm1, [rsp]
000074c379dd2ace  add rsp, 0x30
000074c379dd2ad2  vmovaps xmm0, [rsp]
000074c379dd2ad7  vmovaps xmm2, [rsp+0x10]
000074c379dd2add  vmovaps xmm3, [rsp+0x20]
000074c379dd2ae3  vmovaps xmm4, [rsp+0x30]
000074c379dd2ae9  vmovaps xmm5, [rsp+0x40]
000074c379dd2aef  vmovaps xmm6, [rsp+0x50]
000074c379dd2af5  vmovaps xmm7, [rsp+0x60]
000074c379dd2afb  vmovaps xmm8, [rsp+0x70]
000074c379dd2b01  vmovaps xmm9, [rsp+0x80]
000074c379dd2b0a  vmovaps xmm10, [rsp+0x90]
000074c379dd2b13  vmovaps xmm11, [rsp+0xA0]
000074c379dd2b1c  vmovaps xmm12, [rsp+0xB0]
000074c379dd2b25  vmovaps xmm13, [rsp+0xC0]
000074c379dd2b2e  vmovaps xmm14, [rsp+0xD0]
000074c379dd2b37  vmovaps xmm15, [rsp+0xE0]
000074c379dd2b40  add rsp, 0xF0
000074c379dd2b47  pop r11
000074c379dd2b49  pop r10
000074c379dd2b4b  pop r9
000074c379dd2b4d  pop r8
000074c379dd2b4f  pop rsi
000074c379dd2b50  pop rdi
000074c379dd2b51  pop rdx
000074c379dd2b52  pop rcx
000074c379dd2b53  pop rax
000074c379dd2b54  add rsp, 0x08
000074c379dd2b58  jmp 0x000074C379DCFDB6
000074c379dd2b5d  sub rsp, 0x08
000074c379dd2b61  push rax
000074c379dd2b62  push rcx
000074c379dd2b63  push rdx
000074c379dd2b64  push rdi
000074c379dd2b65  push rsi
000074c379dd2b66  push r8
000074c379dd2b68  push r9
000074c379dd2b6a  push r10
000074c379dd2b6c  push r11
000074c379dd2b6e  sub rsp, 0xF0
000074c379dd2b75  vmovaps [rsp], xmm0
000074c379dd2b7a  vmovaps [rsp+0x10], xmm1
000074c379dd2b80  vmovaps [rsp+0x20], xmm2
000074c379dd2b86  vmovaps [rsp+0x30], xmm3
000074c379dd2b8c  vmovaps [rsp+0x40], xmm4
000074c379dd2b92  vmovaps [rsp+0x50], xmm6
000074c379dd2b98  vmovaps [rsp+0x60], xmm7
000074c379dd2b9e  vmovaps [rsp+0x70], xmm8
000074c379dd2ba4  vmovaps [rsp+0x80], xmm9
000074c379dd2bad  vmovaps [rsp+0x90], xmm10
000074c379dd2bb6  vmovaps [rsp+0xA0], xmm11
000074c379dd2bbf  vmovaps [rsp+0xB0], xmm12
000074c379dd2bc8  vmovaps [rsp+0xC0], xmm13
000074c379dd2bd1  vmovaps [rsp+0xD0], xmm14
000074c379dd2bda  vmovaps [rsp+0xE0], xmm15
000074c379dd2be3  sub rsp, 0x30
000074c379dd2be7  movaps [rsp], xmm5
000074c379dd2beb  movaps [rsp+0x10], xmm2
000074c379dd2bf0  movaps [rsp+0x20], xmm13
000074c379dd2bf6  lea rdi, [rsp]
000074c379dd2bfa  mov esi, 0x00
000074c379dd2bff  mov rax, 0x56321ABA4530
000074c379dd2c09  call rax
000074c379dd2c0b  movaps xmm5, [rsp]
000074c379dd2c0f  add rsp, 0x30
000074c379dd2c13  vmovaps xmm0, [rsp]
000074c379dd2c18  vmovaps xmm1, [rsp+0x10]
000074c379dd2c1e  vmovaps xmm2, [rsp+0x20]
000074c379dd2c24  vmovaps xmm3, [rsp+0x30]
000074c379dd2c2a  vmovaps xmm4, [rsp+0x40]
000074c379dd2c30  vmovaps xmm6, [rsp+0x50]
000074c379dd2c36  vmovaps xmm7, [rsp+0x60]
000074c379dd2c3c  vmovaps xmm8, [rsp+0x70]
000074c379dd2c42  vmovaps xmm9, [rsp+0x80]
000074c379dd2c4b  vmovaps xmm10, [rsp+0x90]
000074c379dd2c54  vmovaps xmm11, [rsp+0xA0]
000074c379dd2c5d  vmovaps xmm12, [rsp+0xB0]
000074c379dd2c66  vmovaps xmm13, [rsp+0xC0]
000074c379dd2c6f  vmovaps xmm14, [rsp+0xD0]
000074c379dd2c78  vmovaps xmm15, [rsp+0xE0]
000074c379dd2c81  add rsp, 0xF0
000074c379dd2c88  pop r11
000074c379dd2c8a  pop r10
000074c379dd2c8c  pop r9
000074c379dd2c8e  pop r8
000074c379dd2c90  pop rsi
000074c379dd2c91  pop rdi
000074c379dd2c92  pop rdx
000074c379dd2c93  pop rcx
000074c379dd2c94  pop rax
000074c379dd2c95  add rsp, 0x08
000074c379dd2c99  jmp 0x000074C379DCFDEC
000074c379dd2c9e  sub rsp, 0x08
000074c379dd2ca2  push rax
000074c379dd2ca3  push rcx
000074c379dd2ca4  push rdx
000074c379dd2ca5  push rdi
000074c379dd2ca6  push rsi
000074c379dd2ca7  push r8
000074c379dd2ca9  push r9
000074c379dd2cab  push r10
000074c379dd2cad  push r11
000074c379dd2caf  sub rsp, 0xF0
000074c379dd2cb6  vmovaps [rsp], xmm0
000074c379dd2cbb  vmovaps [rsp+0x10], xmm1
000074c379dd2cc1  vmovaps [rsp+0x20], xmm2
000074c379dd2cc7  vmovaps [rsp+0x30], xmm3
000074c379dd2ccd  vmovaps [rsp+0x40], xmm4
000074c379dd2cd3  vmovaps [rsp+0x50], xmm5
000074c379dd2cd9  vmovaps [rsp+0x60], xmm6
000074c379dd2cdf  vmovaps [rsp+0x70], xmm7
000074c379dd2ce5  vmovaps [rsp+0x80], xmm8
000074c379dd2cee  vmovaps [rsp+0x90], xmm9
000074c379dd2cf7  vmovaps [rsp+0xA0], xmm10
000074c379dd2d00  vmovaps [rsp+0xB0], xmm11
000074c379dd2d09  vmovaps [rsp+0xC0], xmm12
000074c379dd2d12  vmovaps [rsp+0xD0], xmm14
000074c379dd2d1b  vmovaps [rsp+0xE0], xmm15
000074c379dd2d24  sub rsp, 0x30
000074c379dd2d28  movaps [rsp], xmm13
000074c379dd2d2d  movaps [rsp+0x10], xmm10
000074c379dd2d33  movaps [rsp+0x20], xmm1
000074c379dd2d38  lea rdi, [rsp]
000074c379dd2d3c  mov esi, 0x00
000074c379dd2d41  mov rax, 0x56321ABA4530
000074c379dd2d4b  call rax
000074c379dd2d4d  movaps xmm13, [rsp]
000074c379dd2d52  add rsp, 0x30
000074c379dd2d56  vmovaps xmm0, [rsp]
000074c379dd2d5b  vmovaps xmm1, [rsp+0x10]
000074c379dd2d61  vmovaps xmm2, [rsp+0x20]
000074c379dd2d67  vmovaps xmm3, [rsp+0x30]
000074c379dd2d6d  vmovaps xmm4, [rsp+0x40]
000074c379dd2d73  vmovaps xmm5, [rsp+0x50]
000074c379dd2d79  vmovaps xmm6, [rsp+0x60]
000074c379dd2d7f  vmovaps xmm7, [rsp+0x70]
000074c379dd2d85  vmovaps xmm8, [rsp+0x80]
000074c379dd2d8e  vmovaps xmm9, [rsp+0x90]
000074c379dd2d97  vmovaps xmm10, [rsp+0xA0]
000074c379dd2da0  vmovaps xmm11, [rsp+0xB0]
000074c379dd2da9  vmovaps xmm12, [rsp+0xC0]
000074c379dd2db2  vmovaps xmm14, [rsp+0xD0]
000074c379dd2dbb  vmovaps xmm15, [rsp+0xE0]
000074c379dd2dc4  add rsp, 0xF0
000074c379dd2dcb  pop r11
000074c379dd2dcd  pop r10
000074c379dd2dcf  pop r9
000074c379dd2dd1  pop r8
000074c379dd2dd3  pop rsi
000074c379dd2dd4  pop rdi
000074c379dd2dd5  pop rdx
000074c379dd2dd6  pop rcx
000074c379dd2dd7  pop rax
000074c379dd2dd8  add rsp, 0x08
000074c379dd2ddc  jmp 0x000074C379DCFE15
000074c379dd2de1  sub rsp, 0x08
000074c379dd2de5  push rax
000074c379dd2de6  push rcx
000074c379dd2de7  push rdx
000074c379dd2de8  push rdi
000074c379dd2de9  push rsi
000074c379dd2dea  push r8
000074c379dd2dec  push r9
000074c379dd2dee  push r10
000074c379dd2df0  push r11
000074c379dd2df2  sub rsp, 0xF0
000074c379dd2df9  vmovaps [rsp], xmm0
000074c379dd2dfe  vmovaps [rsp+0x10], xmm2
000074c379dd2e04  vmovaps [rsp+0x20], xmm3
000074c379dd2e0a  vmovaps [rsp+0x30], xmm4
000074c379dd2e10  vmovaps [rsp+0x40], xmm5
000074c379dd2e16  vmovaps [rsp+0x50], xmm6
000074c379dd2e1c  vmovaps [rsp+0x60], xmm7
000074c379dd2e22  vmovaps [rsp+0x70], xmm8
000074c379dd2e28  vmovaps [rsp+0x80], xmm9
000074c379dd2e31  vmovaps [rsp+0x90], xmm10
000074c379dd2e3a  vmovaps [rsp+0xA0], xmm11
000074c379dd2e43  vmovaps [rsp+0xB0], xmm12
000074c379dd2e4c  vmovaps [rsp+0xC0], xmm13
000074c379dd2e55  vmovaps [rsp+0xD0], xmm14
000074c379dd2e5e  vmovaps [rsp+0xE0], xmm15
000074c379dd2e67  sub rsp, 0x30
000074c379dd2e6b  movaps [rsp], xmm1
000074c379dd2e6f  movaps [rsp+0x10], xmm15
000074c379dd2e75  movaps [rsp+0x20], xmm10
000074c379dd2e7b  lea rdi, [rsp]
000074c379dd2e7f  mov esi, 0x00
000074c379dd2e84  mov rax, 0x56321ABA4530
000074c379dd2e8e  call rax
000074c379dd2e90  movaps xmm1, [rsp]
000074c379dd2e94  add rsp, 0x30
000074c379dd2e98  vmovaps xmm0, [rsp]
000074c379dd2e9d  vmovaps xmm2, [rsp+0x10]
000074c379dd2ea3  vmovaps xmm3, [rsp+0x20]
000074c379dd2ea9  vmovaps xmm4, [rsp+0x30]
000074c379dd2eaf  vmovaps xmm5, [rsp+0x40]
000074c379dd2eb5  vmovaps xmm6, [rsp+0x50]
000074c379dd2ebb  vmovaps xmm7, [rsp+0x60]
000074c379dd2ec1  vmovaps xmm8, [rsp+0x70]
000074c379dd2ec7  vmovaps xmm9, [rsp+0x80]
000074c379dd2ed0  vmovaps xmm10, [rsp+0x90]
000074c379dd2ed9  vmovaps xmm11, [rsp+0xA0]
000074c379dd2ee2  vmovaps xmm12, [rsp+0xB0]
000074c379dd2eeb  vmovaps xmm13, [rsp+0xC0]
000074c379dd2ef4  vmovaps xmm14, [rsp+0xD0]
000074c379dd2efd  vmovaps xmm15, [rsp+0xE0]
000074c379dd2f06  add rsp, 0xF0
000074c379dd2f0d  pop r11
000074c379dd2f0f  pop r10
000074c379dd2f11  pop r9
000074c379dd2f13  pop r8
000074c379dd2f15  pop rsi
000074c379dd2f16  pop rdi
000074c379dd2f17  pop rdx
000074c379dd2f18  pop rcx
000074c379dd2f19  pop rax
000074c379dd2f1a  add rsp, 0x08
000074c379dd2f1e  jmp 0x000074C379DCFE34
000074c379dd2f23  sub rsp, 0x08
000074c379dd2f27  push rax
000074c379dd2f28  push rcx
000074c379dd2f29  push rdx
000074c379dd2f2a  push rdi
000074c379dd2f2b  push rsi
000074c379dd2f2c  push r8
000074c379dd2f2e  push r9
000074c379dd2f30  push r10
000074c379dd2f32  push r11
000074c379dd2f34  sub rsp, 0xF0
000074c379dd2f3b  vmovaps [rsp], xmm0
000074c379dd2f40  vmovaps [rsp+0x10], xmm1
000074c379dd2f46  vmovaps [rsp+0x20], xmm2
000074c379dd2f4c  vmovaps [rsp+0x30], xmm3
000074c379dd2f52  vmovaps [rsp+0x40], xmm4
000074c379dd2f58  vmovaps [rsp+0x50], xmm5
000074c379dd2f5e  vmovaps [rsp+0x60], xmm6
000074c379dd2f64  vmovaps [rsp+0x70], xmm7
000074c379dd2f6a  vmovaps [rsp+0x80], xmm8
000074c379dd2f73  vmovaps [rsp+0x90], xmm9
000074c379dd2f7c  vmovaps [rsp+0xA0], xmm10
000074c379dd2f85  vmovaps [rsp+0xB0], xmm11
000074c379dd2f8e  vmovaps [rsp+0xC0], xmm12
000074c379dd2f97  vmovaps [rsp+0xD0], xmm13
000074c379dd2fa0  vmovaps [rsp+0xE0], xmm14
000074c379dd2fa9  sub rsp, 0x30
000074c379dd2fad  movaps [rsp], xmm15
000074c379dd2fb2  movaps [rsp+0x10], xmm10
000074c379dd2fb8  movaps [rsp+0x20], xmm11
000074c379dd2fbe  lea rdi, [rsp]
000074c379dd2fc2  mov esi, 0x00
000074c379dd2fc7  mov rax, 0x56321ABA4530
000074c379dd2fd1  call rax
000074c379dd2fd3  movaps xmm15, [rsp]
000074c379dd2fd8  add rsp, 0x30
000074c379dd2fdc  vmovaps xmm0, [rsp]
000074c379dd2fe1  vmovaps xmm1, [rsp+0x10]
000074c379dd2fe7  vmovaps xmm2, [rsp+0x20]
000074c379dd2fed  vmovaps xmm3, [rsp+0x30]
000074c379dd2ff3  vmovaps xmm4, [rsp+0x40]
000074c379dd2ff9  vmovaps xmm5, [rsp+0x50]
000074c379dd2fff  vmovaps xmm6, [rsp+0x60]
000074c379dd3005  vmovaps xmm7, [rsp+0x70]
000074c379dd300b  vmovaps xmm8, [rsp+0x80]
000074c379dd3014  vmovaps xmm9, [rsp+0x90]
000074c379dd301d  vmovaps xmm10, [rsp+0xA0]
000074c379dd3026  vmovaps xmm11, [rsp+0xB0]
000074c379dd302f  vmovaps xmm12, [rsp+0xC0]
000074c379dd3038  vmovaps xmm13, [rsp+0xD0]
000074c379dd3041  vmovaps xmm14, [rsp+0xE0]
000074c379dd304a  add rsp, 0xF0
000074c379dd3051  pop r11
000074c379dd3053  pop r10
000074c379dd3055  pop r9
000074c379dd3057  pop r8
000074c379dd3059  pop rsi
000074c379dd305a  pop rdi
000074c379dd305b  pop rdx
000074c379dd305c  pop rcx
000074c379dd305d  pop rax
000074c379dd305e  add rsp, 0x08
000074c379dd3062  jmp 0x000074C379DCFE57
000074c379dd3067  sub rsp, 0x08
000074c379dd306b  push rax
000074c379dd306c  push rcx
000074c379dd306d  push rdx
000074c379dd306e  push rdi
000074c379dd306f  push rsi
000074c379dd3070  push r8
000074c379dd3072  push r9
000074c379dd3074  push r10
000074c379dd3076  push r11
000074c379dd3078  sub rsp, 0xF0
000074c379dd307f  vmovaps [rsp], xmm0
000074c379dd3084  vmovaps [rsp+0x10], xmm1
000074c379dd308a  vmovaps [rsp+0x20], xmm2
000074c379dd3090  vmovaps [rsp+0x30], xmm3
000074c379dd3096  vmovaps [rsp+0x40], xmm4
000074c379dd309c  vmovaps [rsp+0x50], xmm5
000074c379dd30a2  vmovaps [rsp+0x60], xmm6
000074c379dd30a8  vmovaps [rsp+0x70], xmm7
000074c379dd30ae  vmovaps [rsp+0x80], xmm8
000074c379dd30b7  vmovaps [rsp+0x90], xmm9
000074c379dd30c0  vmovaps [rsp+0xA0], xmm11
000074c379dd30c9  vmovaps [rsp+0xB0], xmm12
000074c379dd30d2  vmovaps [rsp+0xC0], xmm13
000074c379dd30db  vmovaps [rsp+0xD0], xmm14
000074c379dd30e4  vmovaps [rsp+0xE0], xmm15
000074c379dd30ed  sub rsp, 0x30
000074c379dd30f1  movaps [rsp], xmm10
000074c379dd30f6  movaps [rsp+0x10], xmm12
000074c379dd30fc  movaps [rsp+0x20], xmm11
000074c379dd3102  lea rdi, [rsp]
000074c379dd3106  mov esi, 0x00
000074c379dd310b  mov rax, 0x56321ABA4530
000074c379dd3115  call rax
000074c379dd3117  movaps xmm10, [rsp]
000074c379dd311c  add rsp, 0x30
000074c379dd3120  vmovaps xmm0, [rsp]
000074c379dd3125  vmovaps xmm1, [rsp+0x10]
000074c379dd312b  vmovaps xmm2, [rsp+0x20]
000074c379dd3131  vmovaps xmm3, [rsp+0x30]
000074c379dd3137  vmovaps xmm4, [rsp+0x40]
000074c379dd313d  vmovaps xmm5, [rsp+0x50]
000074c379dd3143  vmovaps xmm6, [rsp+0x60]
000074c379dd3149  vmovaps xmm7, [rsp+0x70]
000074c379dd314f  vmovaps xmm8, [rsp+0x80]
000074c379dd3158  vmovaps xmm9, [rsp+0x90]
000074c379dd3161  vmovaps xmm11, [rsp+0xA0]
000074c379dd316a  vmovaps xmm12, [rsp+0xB0]
000074c379dd3173  vmovaps xmm13, [rsp+0xC0]
000074c379dd317c  vmovaps xmm14, [rsp+0xD0]
000074c379dd3185  vmovaps xmm15, [rsp+0xE0]
000074c379dd318e  add rsp, 0xF0
000074c379dd3195  pop r11
000074c379dd3197  pop r10
000074c379dd3199  pop r9
000074c379dd319b  pop r8
000074c379dd319d  pop rsi
000074c379dd319e  pop rdi
000074c379dd319f  pop rdx
000074c379dd31a0  pop rcx
000074c379dd31a1  pop rax
000074c379dd31a2  add rsp, 0x08
000074c379dd31a6  jmp 0x000074C379DCFE80
000074c379dd31ab  sub rsp, 0x08
000074c379dd31af  push rax
000074c379dd31b0  push rcx
000074c379dd31b1  push rdx
000074c379dd31b2  push rdi
000074c379dd31b3  push rsi
000074c379dd31b4  push r8
000074c379dd31b6  push r9
000074c379dd31b8  push r10
000074c379dd31ba  push r11
000074c379dd31bc  sub rsp, 0xF0
000074c379dd31c3  vmovaps [rsp], xmm0
000074c379dd31c8  vmovaps [rsp+0x10], xmm1
000074c379dd31ce  vmovaps [rsp+0x20], xmm2
000074c379dd31d4  vmovaps [rsp+0x30], xmm3
000074c379dd31da  vmovaps [rsp+0x40], xmm4
000074c379dd31e0  vmovaps [rsp+0x50], xmm5
000074c379dd31e6  vmovaps [rsp+0x60], xmm6
000074c379dd31ec  vmovaps [rsp+0x70], xmm7
000074c379dd31f2  vmovaps [rsp+0x80], xmm8
000074c379dd31fb  vmovaps [rsp+0x90], xmm9
000074c379dd3204  vmovaps [rsp+0xA0], xmm10
000074c379dd320d  vmovaps [rsp+0xB0], xmm12
000074c379dd3216  vmovaps [rsp+0xC0], xmm13
000074c379dd321f  vmovaps [rsp+0xD0], xmm14
000074c379dd3228  vmovaps [rsp+0xE0], xmm15
000074c379dd3231  sub rsp, 0x30
000074c379dd3235  movaps [rsp], xmm11
000074c379dd323a  movaps [rsp+0x10], xmm2
000074c379dd323f  movaps [rsp+0x20], xmm12
000074c379dd3245  lea rdi, [rsp]
000074c379dd3249  mov esi, 0x00
000074c379dd324e  mov rax, 0x56321ABA4530
000074c379dd3258  call rax
000074c379dd325a  movaps xmm11, [rsp]
000074c379dd325f  add rsp, 0x30
000074c379dd3263  vmovaps xmm0, [rsp]
000074c379dd3268  vmovaps xmm1, [rsp+0x10]
000074c379dd326e  vmovaps xmm2, [rsp+0x20]
000074c379dd3274  vmovaps xmm3, [rsp+0x30]
000074c379dd327a  vmovaps xmm4, [rsp+0x40]
000074c379dd3280  vmovaps xmm5, [rsp+0x50]
000074c379dd3286  vmovaps xmm6, [rsp+0x60]
000074c379dd328c  vmovaps xmm7, [rsp+0x70]
000074c379dd3292  vmovaps xmm8, [rsp+0x80]
000074c379dd329b  vmovaps xmm9, [rsp+0x90]
000074c379dd32a4  vmovaps xmm10, [rsp+0xA0]
000074c379dd32ad  vmovaps xmm12, [rsp+0xB0]
000074c379dd32b6  vmovaps xmm13, [rsp+0xC0]
000074c379dd32bf  vmovaps xmm14, [rsp+0xD0]
000074c379dd32c8  vmovaps xmm15, [rsp+0xE0]
000074c379dd32d1  add rsp, 0xF0
000074c379dd32d8  pop r11
000074c379dd32da  pop r10
000074c379dd32dc  pop r9
000074c379dd32de  pop r8
000074c379dd32e0  pop rsi
000074c379dd32e1  pop rdi
000074c379dd32e2  pop rdx
000074c379dd32e3  pop rcx
000074c379dd32e4  pop rax
000074c379dd32e5  add rsp, 0x08
000074c379dd32e9  jmp 0x000074C379DCFEB8
000074c379dd32ee  sub rsp, 0x08
000074c379dd32f2  push rax
000074c379dd32f3  push rcx
000074c379dd32f4  push rdx
000074c379dd32f5  push rdi
000074c379dd32f6  push rsi
000074c379dd32f7  push r8
000074c379dd32f9  push r9
000074c379dd32fb  push r10
000074c379dd32fd  push r11
000074c379dd32ff  sub rsp, 0xF0
000074c379dd3306  vmovaps [rsp], xmm0
000074c379dd330b  vmovaps [rsp+0x10], xmm2
000074c379dd3311  vmovaps [rsp+0x20], xmm3
000074c379dd3317  vmovaps [rsp+0x30], xmm4
000074c379dd331d  vmovaps [rsp+0x40], xmm5
000074c379dd3323  vmovaps [rsp+0x50], xmm6
000074c379dd3329  vmovaps [rsp+0x60], xmm7
000074c379dd332f  vmovaps [rsp+0x70], xmm8
000074c379dd3335  vmovaps [rsp+0x80], xmm9
000074c379dd333e  vmovaps [rsp+0x90], xmm10
000074c379dd3347  vmovaps [rsp+0xA0], xmm11
000074c379dd3350  vmovaps [rsp+0xB0], xmm12
000074c379dd3359  vmovaps [rsp+0xC0], xmm13
000074c379dd3362  vmovaps [rsp+0xD0], xmm14
000074c379dd336b  vmovaps [rsp+0xE0], xmm15
000074c379dd3374  sub rsp, 0x30
000074c379dd3378  movaps [rsp], xmm1
000074c379dd337c  movaps [rsp+0x10], xmm14
000074c379dd3382  movaps [rsp+0x20], xmm6
000074c379dd3387  lea rdi, [rsp]
000074c379dd338b  mov esi, 0x00
000074c379dd3390  mov rax, 0x56321ABA4530
000074c379dd339a  call rax
000074c379dd339c  movaps xmm1, [rsp]
000074c379dd33a0  add rsp, 0x30
000074c379dd33a4  vmovaps xmm0, [rsp]
000074c379dd33a9  vmovaps xmm2, [rsp+0x10]
000074c379dd33af  vmovaps xmm3, [rsp+0x20]
000074c379dd33b5  vmovaps xmm4, [rsp+0x30]
000074c379dd33bb  vmovaps xmm5, [rsp+0x40]
000074c379dd33c1  vmovaps xmm6, [rsp+0x50]
000074c379dd33c7  vmovaps xmm7, [rsp+0x60]
000074c379dd33cd  vmovaps xmm8, [rsp+0x70]
000074c379dd33d3  vmovaps xmm9, [rsp+0x80]
000074c379dd33dc  vmovaps xmm10, [rsp+0x90]
000074c379dd33e5  vmovaps xmm11, [rsp+0xA0]
000074c379dd33ee  vmovaps xmm12, [rsp+0xB0]
000074c379dd33f7  vmovaps xmm13, [rsp+0xC0]
000074c379dd3400  vmovaps xmm14, [rsp+0xD0]
000074c379dd3409  vmovaps xmm15, [rsp+0xE0]
000074c379dd3412  add rsp, 0xF0
000074c379dd3419  pop r11
000074c379dd341b  pop r10
000074c379dd341d  pop r9
000074c379dd341f  pop r8
000074c379dd3421  pop rsi
000074c379dd3422  pop rdi
000074c379dd3423  pop rdx
000074c379dd3424  pop rcx
000074c379dd3425  pop rax
000074c379dd3426  add rsp, 0x08
000074c379dd342a  jmp 0x000074C379DCFED1
000074c379dd342f  sub rsp, 0x08
000074c379dd3433  push rax
000074c379dd3434  push rcx
000074c379dd3435  push rdx
000074c379dd3436  push rdi
000074c379dd3437  push rsi
000074c379dd3438  push r8
000074c379dd343a  push r9
000074c379dd343c  push r10
000074c379dd343e  push r11
000074c379dd3440  sub rsp, 0xF0
000074c379dd3447  vmovaps [rsp], xmm0
000074c379dd344c  vmovaps [rsp+0x10], xmm1
000074c379dd3452  vmovaps [rsp+0x20], xmm2
000074c379dd3458  vmovaps [rsp+0x30], xmm3
000074c379dd345e  vmovaps [rsp+0x40], xmm4
000074c379dd3464  vmovaps [rsp+0x50], xmm5
000074c379dd346a  vmovaps [rsp+0x60], xmm6
000074c379dd3470  vmovaps [rsp+0x70], xmm7
000074c379dd3476  vmovaps [rsp+0x80], xmm8
000074c379dd347f  vmovaps [rsp+0x90], xmm9
000074c379dd3488  vmovaps [rsp+0xA0], xmm10
000074c379dd3491  vmovaps [rsp+0xB0], xmm11
000074c379dd349a  vmovaps [rsp+0xC0], xmm12
000074c379dd34a3  vmovaps [rsp+0xD0], xmm13
000074c379dd34ac  vmovaps [rsp+0xE0], xmm15
000074c379dd34b5  sub rsp, 0x30
000074c379dd34b9  movaps [rsp], xmm14
000074c379dd34be  movaps [rsp+0x10], xmm12
000074c379dd34c4  movaps [rsp+0x20], xmm5
000074c379dd34c9  lea rdi, [rsp]
000074c379dd34cd  mov esi, 0x00
000074c379dd34d2  mov rax, 0x56321ABA4530
000074c379dd34dc  call rax
000074c379dd34de  movaps xmm14, [rsp]
000074c379dd34e3  add rsp, 0x30
000074c379dd34e7  vmovaps xmm0, [rsp]
000074c379dd34ec  vmovaps xmm1, [rsp+0x10]
000074c379dd34f2  vmovaps xmm2, [rsp+0x20]
000074c379dd34f8  vmovaps xmm3, [rsp+0x30]
000074c379dd34fe  vmovaps xmm4, [rsp+0x40]
000074c379dd3504  vmovaps xmm5, [rsp+0x50]
000074c379dd350a  vmovaps xmm6, [rsp+0x60]
000074c379dd3510  vmovaps xmm7, [rsp+0x70]
000074c379dd3516  vmovaps xmm8, [rsp+0x80]
000074c379dd351f  vmovaps xmm9, [rsp+0x90]
000074c379dd3528  vmovaps xmm10, [rsp+0xA0]
000074c379dd3531  vmovaps xmm11, [rsp+0xB0]
000074c379dd353a  vmovaps xmm12, [rsp+0xC0]
000074c379dd3543  vmovaps xmm13, [rsp+0xD0]
000074c379dd354c  vmovaps xmm15, [rsp+0xE0]
000074c379dd3555  add rsp, 0xF0
000074c379dd355c  pop r11
000074c379dd355e  pop r10
000074c379dd3560  pop r9
000074c379dd3562  pop r8
000074c379dd3564  pop rsi
000074c379dd3565  pop rdi
000074c379dd3566  pop rdx
000074c379dd3567  pop rcx
000074c379dd3568  pop rax
000074c379dd3569  add rsp, 0x08
000074c379dd356d  jmp 0x000074C379DCFEF1
000074c379dd3572  sub rsp, 0x08
000074c379dd3576  push rax
000074c379dd3577  push rcx
000074c379dd3578  push rdx
000074c379dd3579  push rdi
000074c379dd357a  push rsi
000074c379dd357b  push r8
000074c379dd357d  push r9
000074c379dd357f  push r10
000074c379dd3581  push r11
000074c379dd3583  sub rsp, 0xF0
000074c379dd358a  vmovaps [rsp], xmm0
000074c379dd358f  vmovaps [rsp+0x10], xmm1
000074c379dd3595  vmovaps [rsp+0x20], xmm2
000074c379dd359b  vmovaps [rsp+0x30], xmm3
000074c379dd35a1  vmovaps [rsp+0x40], xmm4
000074c379dd35a7  vmovaps [rsp+0x50], xmm5
000074c379dd35ad  vmovaps [rsp+0x60], xmm7
000074c379dd35b3  vmovaps [rsp+0x70], xmm8
000074c379dd35b9  vmovaps [rsp+0x80], xmm9
000074c379dd35c2  vmovaps [rsp+0x90], xmm10
000074c379dd35cb  vmovaps [rsp+0xA0], xmm11
000074c379dd35d4  vmovaps [rsp+0xB0], xmm12
000074c379dd35dd  vmovaps [rsp+0xC0], xmm13
000074c379dd35e6  vmovaps [rsp+0xD0], xmm14
000074c379dd35ef  vmovaps [rsp+0xE0], xmm15
000074c379dd35f8  sub rsp, 0x30
000074c379dd35fc  movaps [rsp], xmm6
000074c379dd3600  movaps [rsp+0x10], xmm9
000074c379dd3606  movaps [rsp+0x20], xmm12
000074c379dd360c  lea rdi, [rsp]
000074c379dd3610  mov esi, 0x00
000074c379dd3615  mov rax, 0x56321ABA4530
000074c379dd361f  call rax
000074c379dd3621  movaps xmm6, [rsp]
000074c379dd3625  add rsp, 0x30
000074c379dd3629  vmovaps xmm0, [rsp]
000074c379dd362e  vmovaps xmm1, [rsp+0x10]
000074c379dd3634  vmovaps xmm2, [rsp+0x20]
000074c379dd363a  vmovaps xmm3, [rsp+0x30]
000074c379dd3640  vmovaps xmm4, [rsp+0x40]
000074c379dd3646  vmovaps xmm5, [rsp+0x50]
000074c379dd364c  vmovaps xmm7, [rsp+0x60]
000074c379dd3652  vmovaps xmm8, [rsp+0x70]
000074c379dd3658  vmovaps xmm9, [rsp+0x80]
000074c379dd3661  vmovaps xmm10, [rsp+0x90]
000074c379dd366a  vmovaps xmm11, [rsp+0xA0]
000074c379dd3673  vmovaps xmm12, [rsp+0xB0]
000074c379dd367c  vmovaps xmm13, [rsp+0xC0]
000074c379dd3685  vmovaps xmm14, [rsp+0xD0]
000074c379dd368e  vmovaps xmm15, [rsp+0xE0]
000074c379dd3697  add rsp, 0xF0
000074c379dd369e  pop r11
000074c379dd36a0  pop r10
000074c379dd36a2  pop r9
000074c379dd36a4  pop r8
000074c379dd36a6  pop rsi
000074c379dd36a7  pop rdi
000074c379dd36a8  pop rdx
000074c379dd36a9  pop rcx
000074c379dd36aa  pop rax
000074c379dd36ab  add rsp, 0x08
000074c379dd36af  jmp 0x000074C379DCFF19
000074c379dd36b4  sub rsp, 0x08
000074c379dd36b8  push rax
000074c379dd36b9  push rcx
000074c379dd36ba  push rdx
000074c379dd36bb  push rdi
000074c379dd36bc  push rsi
000074c379dd36bd  push r8
000074c379dd36bf  push r9
000074c379dd36c1  push r10
000074c379dd36c3  push r11
000074c379dd36c5  sub rsp, 0xF0
000074c379dd36cc  vmovaps [rsp], xmm0
000074c379dd36d1  vmovaps [rsp+0x10], xmm1
000074c379dd36d7  vmovaps [rsp+0x20], xmm2
000074c379dd36dd  vmovaps [rsp+0x30], xmm3
000074c379dd36e3  vmovaps [rsp+0x40], xmm4
000074c379dd36e9  vmovaps [rsp+0x50], xmm5
000074c379dd36ef  vmovaps [rsp+0x60], xmm6
000074c379dd36f5  vmovaps [rsp+0x70], xmm7
000074c379dd36fb  vmovaps [rsp+0x80], xmm8
000074c379dd3704  vmovaps [rsp+0x90], xmm9
000074c379dd370d  vmovaps [rsp+0xA0], xmm10
000074c379dd3716  vmovaps [rsp+0xB0], xmm11
000074c379dd371f  vmovaps [rsp+0xC0], xmm13
000074c379dd3728  vmovaps [rsp+0xD0], xmm14
000074c379dd3731  vmovaps [rsp+0xE0], xmm15
000074c379dd373a  sub rsp, 0x30
000074c379dd373e  movaps [rsp], xmm12
000074c379dd3743  movaps [rsp+0x10], xmm15
000074c379dd3749  movaps [rsp+0x20], xmm13
000074c379dd374f  lea rdi, [rsp]
000074c379dd3753  mov esi, 0x00
000074c379dd3758  mov rax, 0x56321ABA4530
000074c379dd3762  call rax
000074c379dd3764  movaps xmm12, [rsp]
000074c379dd3769  add rsp, 0x30
000074c379dd376d  vmovaps xmm0, [rsp]
000074c379dd3772  vmovaps xmm1, [rsp+0x10]
000074c379dd3778  vmovaps xmm2, [rsp+0x20]
000074c379dd377e  vmovaps xmm3, [rsp+0x30]
000074c379dd3784  vmovaps xmm4, [rsp+0x40]
000074c379dd378a  vmovaps xmm5, [rsp+0x50]
000074c379dd3790  vmovaps xmm6, [rsp+0x60]
000074c379dd3796  vmovaps xmm7, [rsp+0x70]
000074c379dd379c  vmovaps xmm8, [rsp+0x80]
000074c379dd37a5  vmovaps xmm9, [rsp+0x90]
000074c379dd37ae  vmovaps xmm10, [rsp+0xA0]
000074c379dd37b7  vmovaps xmm11, [rsp+0xB0]
000074c379dd37c0  vmovaps xmm13, [rsp+0xC0]
000074c379dd37c9  vmovaps xmm14, [rsp+0xD0]
000074c379dd37d2  vmovaps xmm15, [rsp+0xE0]
000074c379dd37db  add rsp, 0xF0
000074c379dd37e2  pop r11
000074c379dd37e4  pop r10
000074c379dd37e6  pop r9
000074c379dd37e8  pop r8
000074c379dd37ea  pop rsi
000074c379dd37eb  pop rdi
000074c379dd37ec  pop rdx
000074c379dd37ed  pop rcx
000074c379dd37ee  pop rax
000074c379dd37ef  add rsp, 0x08
000074c379dd37f3  jmp 0x000074C379DCFF34
000074c379dd37f8  sub rsp, 0x08
000074c379dd37fc  push rax
000074c379dd37fd  push rcx
000074c379dd37fe  push rdx
000074c379dd37ff  push rdi
000074c379dd3800  push rsi
000074c379dd3801  push r8
000074c379dd3803  push r9
000074c379dd3805  push r10
000074c379dd3807  push r11
000074c379dd3809  sub rsp, 0xF0
000074c379dd3810  vmovaps [rsp], xmm0
000074c379dd3815  vmovaps [rsp+0x10], xmm1
000074c379dd381b  vmovaps [rsp+0x20], xmm2
000074c379dd3821  vmovaps [rsp+0x30], xmm3
000074c379dd3827  vmovaps [rsp+0x40], xmm4
000074c379dd382d  vmovaps [rsp+0x50], xmm5
000074c379dd3833  vmovaps [rsp+0x60], xmm6
000074c379dd3839  vmovaps [rsp+0x70], xmm7
000074c379dd383f  vmovaps [rsp+0x80], xmm8
000074c379dd3848  vmovaps [rsp+0x90], xmm9
000074c379dd3851  vmovaps [rsp+0xA0], xmm10
000074c379dd385a  vmovaps [rsp+0xB0], xmm11
000074c379dd3863  vmovaps [rsp+0xC0], xmm12
000074c379dd386c  vmovaps [rsp+0xD0], xmm13
000074c379dd3875  vmovaps [rsp+0xE0], xmm14
000074c379dd387e  sub rsp, 0x30
000074c379dd3882  movaps [rsp], xmm15
000074c379dd3887  movaps [rsp+0x10], xmm13
000074c379dd388d  movaps [rsp+0x20], xmm10
000074c379dd3893  lea rdi, [rsp]
000074c379dd3897  mov esi, 0x00
000074c379dd389c  mov rax, 0x56321ABA4530
000074c379dd38a6  call rax
000074c379dd38a8  movaps xmm15, [rsp]
000074c379dd38ad  add rsp, 0x30
000074c379dd38b1  vmovaps xmm0, [rsp]
000074c379dd38b6  vmovaps xmm1, [rsp+0x10]
000074c379dd38bc  vmovaps xmm2, [rsp+0x20]
000074c379dd38c2  vmovaps xmm3, [rsp+0x30]
000074c379dd38c8  vmovaps xmm4, [rsp+0x40]
000074c379dd38ce  vmovaps xmm5, [rsp+0x50]
000074c379dd38d4  vmovaps xmm6, [rsp+0x60]
000074c379dd38da  vmovaps xmm7, [rsp+0x70]
000074c379dd38e0  vmovaps xmm8, [rsp+0x80]
000074c379dd38e9  vmovaps xmm9, [rsp+0x90]
000074c379dd38f2  vmovaps xmm10, [rsp+0xA0]
000074c379dd38fb  vmovaps xmm11, [rsp+0xB0]
000074c379dd3904  vmovaps xmm12, [rsp+0xC0]
000074c379dd390d  vmovaps xmm13, [rsp+0xD0]
000074c379dd3916  vmovaps xmm14, [rsp+0xE0]
000074c379dd391f  add rsp, 0xF0
000074c379dd3926  pop r11
000074c379dd3928  pop r10
000074c379dd392a  pop r9
000074c379dd392c  pop r8
000074c379dd392e  pop rsi
000074c379dd392f  pop rdi
000074c379dd3930  pop rdx
000074c379dd3931  pop rcx
000074c379dd3932  pop rax
000074c379dd3933  add rsp, 0x08
000074c379dd3937  jmp 0x000074C379DCFF55
000074c379dd393c  call 0x000074C379C0C260
000074c379dd3941  jmp 0x000074C379DCFFB0
000074c379dd3946  sub rsp, 0x08
000074c379dd394a  push rax
000074c379dd394b  push rcx
000074c379dd394c  push rdx
000074c379dd394d  push rdi
000074c379dd394e  push rsi
000074c379dd394f  push r8
000074c379dd3951  push r9
000074c379dd3953  push r10
000074c379dd3955  push r11
000074c379dd3957  sub rsp, 0xF0
000074c379dd395e  vmovaps [rsp], xmm0
000074c379dd3963  vmovaps [rsp+0x10], xmm1
000074c379dd3969  vmovaps [rsp+0x20], xmm2
000074c379dd396f  vmovaps [rsp+0x30], xmm3
000074c379dd3975  vmovaps [rsp+0x40], xmm4
000074c379dd397b  vmovaps [rsp+0x50], xmm5
000074c379dd3981  vmovaps [rsp+0x60], xmm6
000074c379dd3987  vmovaps [rsp+0x70], xmm7
000074c379dd398d  vmovaps [rsp+0x80], xmm8
000074c379dd3996  vmovaps [rsp+0x90], xmm10
000074c379dd399f  vmovaps [rsp+0xA0], xmm11
000074c379dd39a8  vmovaps [rsp+0xB0], xmm12
000074c379dd39b1  vmovaps [rsp+0xC0], xmm13
000074c379dd39ba  vmovaps [rsp+0xD0], xmm14
000074c379dd39c3  vmovaps [rsp+0xE0], xmm15
000074c379dd39cc  sub rsp, 0x30
000074c379dd39d0  movaps [rsp], xmm9
000074c379dd39d5  movaps [rsp+0x10], xmm8
000074c379dd39db  movaps [rsp+0x20], xmm10
000074c379dd39e1  lea rdi, [rsp]
000074c379dd39e5  mov esi, 0x00
000074c379dd39ea  mov rax, 0x56321ABA4530
000074c379dd39f4  call rax
000074c379dd39f6  movaps xmm9, [rsp]
000074c379dd39fb  add rsp, 0x30
000074c379dd39ff  vmovaps xmm0, [rsp]
000074c379dd3a04  vmovaps xmm1, [rsp+0x10]
000074c379dd3a0a  vmovaps xmm2, [rsp+0x20]
000074c379dd3a10  vmovaps xmm3, [rsp+0x30]
000074c379dd3a16  vmovaps xmm4, [rsp+0x40]
000074c379dd3a1c  vmovaps xmm5, [rsp+0x50]
000074c379dd3a22  vmovaps xmm6, [rsp+0x60]
000074c379dd3a28  vmovaps xmm7, [rsp+0x70]
000074c379dd3a2e  vmovaps xmm8, [rsp+0x80]
000074c379dd3a37  vmovaps xmm10, [rsp+0x90]
000074c379dd3a40  vmovaps xmm11, [rsp+0xA0]
000074c379dd3a49  vmovaps xmm12, [rsp+0xB0]
000074c379dd3a52  vmovaps xmm13, [rsp+0xC0]
000074c379dd3a5b  vmovaps xmm14, [rsp+0xD0]
000074c379dd3a64  vmovaps xmm15, [rsp+0xE0]
000074c379dd3a6d  add rsp, 0xF0
000074c379dd3a74  pop r11
000074c379dd3a76  pop r10
000074c379dd3a78  pop r9
000074c379dd3a7a  pop r8
000074c379dd3a7c  pop rsi
000074c379dd3a7d  pop rdi
000074c379dd3a7e  pop rdx
000074c379dd3a7f  pop rcx
000074c379dd3a80  pop rax
000074c379dd3a81  add rsp, 0x08
000074c379dd3a85  jmp 0x000074C379DCFFE1
000074c379dd3a8a  sub rsp, 0x08
000074c379dd3a8e  push rax
000074c379dd3a8f  push rcx
000074c379dd3a90  push rdx
000074c379dd3a91  push rdi
000074c379dd3a92  push rsi
000074c379dd3a93  push r8
000074c379dd3a95  push r9
000074c379dd3a97  push r10
000074c379dd3a99  push r11
000074c379dd3a9b  sub rsp, 0xF0
000074c379dd3aa2  vmovaps [rsp], xmm0
000074c379dd3aa7  vmovaps [rsp+0x10], xmm1
000074c379dd3aad  vmovaps [rsp+0x20], xmm2
000074c379dd3ab3  vmovaps [rsp+0x30], xmm3
000074c379dd3ab9  vmovaps [rsp+0x40], xmm4
000074c379dd3abf  vmovaps [rsp+0x50], xmm5
000074c379dd3ac5  vmovaps [rsp+0x60], xmm6
000074c379dd3acb  vmovaps [rsp+0x70], xmm7
000074c379dd3ad1  vmovaps [rsp+0x80], xmm8
000074c379dd3ada  vmovaps [rsp+0x90], xmm9
000074c379dd3ae3  vmovaps [rsp+0xA0], xmm11
000074c379dd3aec  vmovaps [rsp+0xB0], xmm12
000074c379dd3af5  vmovaps [rsp+0xC0], xmm13
000074c379dd3afe  vmovaps [rsp+0xD0], xmm14
000074c379dd3b07  vmovaps [rsp+0xE0], xmm15
000074c379dd3b10  sub rsp, 0x30
000074c379dd3b14  movaps [rsp], xmm10
000074c379dd3b19  movaps [rsp+0x10], xmm1
000074c379dd3b1e  movaps [rsp+0x20], xmm11
000074c379dd3b24  lea rdi, [rsp]
000074c379dd3b28  mov esi, 0x00
000074c379dd3b2d  mov rax, 0x56321ABA4530
000074c379dd3b37  call rax
000074c379dd3b39  movaps xmm10, [rsp]
000074c379dd3b3e  add rsp, 0x30
000074c379dd3b42  vmovaps xmm0, [rsp]
000074c379dd3b47  vmovaps xmm1, [rsp+0x10]
000074c379dd3b4d  vmovaps xmm2, [rsp+0x20]
000074c379dd3b53  vmovaps xmm3, [rsp+0x30]
000074c379dd3b59  vmovaps xmm4, [rsp+0x40]
000074c379dd3b5f  vmovaps xmm5, [rsp+0x50]
000074c379dd3b65  vmovaps xmm6, [rsp+0x60]
000074c379dd3b6b  vmovaps xmm7, [rsp+0x70]
000074c379dd3b71  vmovaps xmm8, [rsp+0x80]
000074c379dd3b7a  vmovaps xmm9, [rsp+0x90]
000074c379dd3b83  vmovaps xmm11, [rsp+0xA0]
000074c379dd3b8c  vmovaps xmm12, [rsp+0xB0]
000074c379dd3b95  vmovaps xmm13, [rsp+0xC0]
000074c379dd3b9e  vmovaps xmm14, [rsp+0xD0]
000074c379dd3ba7  vmovaps xmm15, [rsp+0xE0]
000074c379dd3bb0  add rsp, 0xF0
000074c379dd3bb7  pop r11
000074c379dd3bb9  pop r10
000074c379dd3bbb  pop r9
000074c379dd3bbd  pop r8
000074c379dd3bbf  pop rsi
000074c379dd3bc0  pop rdi
000074c379dd3bc1  pop rdx
000074c379dd3bc2  pop rcx
000074c379dd3bc3  pop rax
000074c379dd3bc4  add rsp, 0x08
000074c379dd3bc8  jmp 0x000074C379DCFFFC
000074c379dd3bcd  sub rsp, 0x08
000074c379dd3bd1  push rax
000074c379dd3bd2  push rcx
000074c379dd3bd3  push rdx
000074c379dd3bd4  push rdi
000074c379dd3bd5  push rsi
000074c379dd3bd6  push r8
000074c379dd3bd8  push r9
000074c379dd3bda  push r10
000074c379dd3bdc  push r11
000074c379dd3bde  sub rsp, 0xF0
000074c379dd3be5  vmovaps [rsp], xmm0
000074c379dd3bea  vmovaps [rsp+0x10], xmm2
000074c379dd3bf0  vmovaps [rsp+0x20], xmm3
000074c379dd3bf6  vmovaps [rsp+0x30], xmm4
000074c379dd3bfc  vmovaps [rsp+0x40], xmm5
000074c379dd3c02  vmovaps [rsp+0x50], xmm6
000074c379dd3c08  vmovaps [rsp+0x60], xmm7
000074c379dd3c0e  vmovaps [rsp+0x70], xmm8
000074c379dd3c14  vmovaps [rsp+0x80], xmm9
000074c379dd3c1d  vmovaps [rsp+0x90], xmm10
000074c379dd3c26  vmovaps [rsp+0xA0], xmm11
000074c379dd3c2f  vmovaps [rsp+0xB0], xmm12
000074c379dd3c38  vmovaps [rsp+0xC0], xmm13
000074c379dd3c41  vmovaps [rsp+0xD0], xmm14
000074c379dd3c4a  vmovaps [rsp+0xE0], xmm15
000074c379dd3c53  sub rsp, 0x30
000074c379dd3c57  movaps [rsp], xmm1
000074c379dd3c5b  movaps [rsp+0x10], xmm14
000074c379dd3c61  movaps [rsp+0x20], xmm6
000074c379dd3c66  lea rdi, [rsp]
000074c379dd3c6a  mov esi, 0x00
000074c379dd3c6f  mov rax, 0x56321ABA4530
000074c379dd3c79  call rax
000074c379dd3c7b  movaps xmm1, [rsp]
000074c379dd3c7f  add rsp, 0x30
000074c379dd3c83  vmovaps xmm0, [rsp]
000074c379dd3c88  vmovaps xmm2, [rsp+0x10]
000074c379dd3c8e  vmovaps xmm3, [rsp+0x20]
000074c379dd3c94  vmovaps xmm4, [rsp+0x30]
000074c379dd3c9a  vmovaps xmm5, [rsp+0x40]
000074c379dd3ca0  vmovaps xmm6, [rsp+0x50]
000074c379dd3ca6  vmovaps xmm7, [rsp+0x60]
000074c379dd3cac  vmovaps xmm8, [rsp+0x70]
000074c379dd3cb2  vmovaps xmm9, [rsp+0x80]
000074c379dd3cbb  vmovaps xmm10, [rsp+0x90]
000074c379dd3cc4  vmovaps xmm11, [rsp+0xA0]
000074c379dd3ccd  vmovaps xmm12, [rsp+0xB0]
000074c379dd3cd6  vmovaps xmm13, [rsp+0xC0]
000074c379dd3cdf  vmovaps xmm14, [rsp+0xD0]
000074c379dd3ce8  vmovaps xmm15, [rsp+0xE0]
000074c379dd3cf1  add rsp, 0xF0
000074c379dd3cf8  pop r11
000074c379dd3cfa  pop r10
000074c379dd3cfc  pop r9
000074c379dd3cfe  pop r8
000074c379dd3d00  pop rsi
000074c379dd3d01  pop rdi
000074c379dd3d02  pop rdx
000074c379dd3d03  pop rcx
000074c379dd3d04  pop rax
000074c379dd3d05  add rsp, 0x08
000074c379dd3d09  jmp 0x000074C379DD0015
000074c379dd3d0e  sub rsp, 0x08
000074c379dd3d12  push rax
000074c379dd3d13  push rcx
000074c379dd3d14  push rdx
000074c379dd3d15  push rdi
000074c379dd3d16  push rsi
000074c379dd3d17  push r8
000074c379dd3d19  push r9
000074c379dd3d1b  push r10
000074c379dd3d1d  push r11
000074c379dd3d1f  sub rsp, 0xF0
000074c379dd3d26  vmovaps [rsp], xmm0
000074c379dd3d2b  vmovaps [rsp+0x10], xmm1
000074c379dd3d31  vmovaps [rsp+0x20], xmm2
000074c379dd3d37  vmovaps [rsp+0x30], xmm3
000074c379dd3d3d  vmovaps [rsp+0x40], xmm4
000074c379dd3d43  vmovaps [rsp+0x50], xmm5
000074c379dd3d49  vmovaps [rsp+0x60], xmm6
000074c379dd3d4f  vmovaps [rsp+0x70], xmm7
000074c379dd3d55  vmovaps [rsp+0x80], xmm8
000074c379dd3d5e  vmovaps [rsp+0x90], xmm9
000074c379dd3d67  vmovaps [rsp+0xA0], xmm10
000074c379dd3d70  vmovaps [rsp+0xB0], xmm12
000074c379dd3d79  vmovaps [rsp+0xC0], xmm13
000074c379dd3d82  vmovaps [rsp+0xD0], xmm14
000074c379dd3d8b  vmovaps [rsp+0xE0], xmm15
000074c379dd3d94  sub rsp, 0x30
000074c379dd3d98  movaps [rsp], xmm11
000074c379dd3d9d  movaps [rsp+0x10], xmm13
000074c379dd3da3  movaps [rsp+0x20], xmm14
000074c379dd3da9  lea rdi, [rsp]
000074c379dd3dad  mov esi, 0x00
000074c379dd3db2  mov rax, 0x56321ABA4530
000074c379dd3dbc  call rax
000074c379dd3dbe  movaps xmm11, [rsp]
000074c379dd3dc3  add rsp, 0x30
000074c379dd3dc7  vmovaps xmm0, [rsp]
000074c379dd3dcc  vmovaps xmm1, [rsp+0x10]
000074c379dd3dd2  vmovaps xmm2, [rsp+0x20]
000074c379dd3dd8  vmovaps xmm3, [rsp+0x30]
000074c379dd3dde  vmovaps xmm4, [rsp+0x40]
000074c379dd3de4  vmovaps xmm5, [rsp+0x50]
000074c379dd3dea  vmovaps xmm6, [rsp+0x60]
000074c379dd3df0  vmovaps xmm7, [rsp+0x70]
000074c379dd3df6  vmovaps xmm8, [rsp+0x80]
000074c379dd3dff  vmovaps xmm9, [rsp+0x90]
000074c379dd3e08  vmovaps xmm10, [rsp+0xA0]
000074c379dd3e11  vmovaps xmm12, [rsp+0xB0]
000074c379dd3e1a  vmovaps xmm13, [rsp+0xC0]
000074c379dd3e23  vmovaps xmm14, [rsp+0xD0]
000074c379dd3e2c  vmovaps xmm15, [rsp+0xE0]
000074c379dd3e35  add rsp, 0xF0
000074c379dd3e3c  pop r11
000074c379dd3e3e  pop r10
000074c379dd3e40  pop r9
000074c379dd3e42  pop r8
000074c379dd3e44  pop rsi
000074c379dd3e45  pop rdi
000074c379dd3e46  pop rdx
000074c379dd3e47  pop rcx
000074c379dd3e48  pop rax
000074c379dd3e49  add rsp, 0x08
000074c379dd3e4d  jmp 0x000074C379DD003F
000074c379dd3e52  sub rsp, 0x08
000074c379dd3e56  push rax
000074c379dd3e57  push rcx
000074c379dd3e58  push rdx
000074c379dd3e59  push rdi
000074c379dd3e5a  push rsi
000074c379dd3e5b  push r8
000074c379dd3e5d  push r9
000074c379dd3e5f  push r10
000074c379dd3e61  push r11
000074c379dd3e63  sub rsp, 0xF0
000074c379dd3e6a  vmovaps [rsp], xmm0
000074c379dd3e6f  vmovaps [rsp+0x10], xmm1
000074c379dd3e75  vmovaps [rsp+0x20], xmm2
000074c379dd3e7b  vmovaps [rsp+0x30], xmm3
000074c379dd3e81  vmovaps [rsp+0x40], xmm4
000074c379dd3e87  vmovaps [rsp+0x50], xmm5
000074c379dd3e8d  vmovaps [rsp+0x60], xmm6
000074c379dd3e93  vmovaps [rsp+0x70], xmm7
000074c379dd3e99  vmovaps [rsp+0x80], xmm8
000074c379dd3ea2  vmovaps [rsp+0x90], xmm9
000074c379dd3eab  vmovaps [rsp+0xA0], xmm10
000074c379dd3eb4  vmovaps [rsp+0xB0], xmm11
000074c379dd3ebd  vmovaps [rsp+0xC0], xmm12
000074c379dd3ec6  vmovaps [rsp+0xD0], xmm14
000074c379dd3ecf  vmovaps [rsp+0xE0], xmm15
000074c379dd3ed8  sub rsp, 0x30
000074c379dd3edc  movaps [rsp], xmm13
000074c379dd3ee1  movaps [rsp+0x10], xmm8
000074c379dd3ee7  movaps [rsp+0x20], xmm14
000074c379dd3eed  lea rdi, [rsp]
000074c379dd3ef1  mov esi, 0x00
000074c379dd3ef6  mov rax, 0x56321ABA4530
000074c379dd3f00  call rax
000074c379dd3f02  movaps xmm13, [rsp]
000074c379dd3f07  add rsp, 0x30
000074c379dd3f0b  vmovaps xmm0, [rsp]
000074c379dd3f10  vmovaps xmm1, [rsp+0x10]
000074c379dd3f16  vmovaps xmm2, [rsp+0x20]
000074c379dd3f1c  vmovaps xmm3, [rsp+0x30]
000074c379dd3f22  vmovaps xmm4, [rsp+0x40]
000074c379dd3f28  vmovaps xmm5, [rsp+0x50]
000074c379dd3f2e  vmovaps xmm6, [rsp+0x60]
000074c379dd3f34  vmovaps xmm7, [rsp+0x70]
000074c379dd3f3a  vmovaps xmm8, [rsp+0x80]
000074c379dd3f43  vmovaps xmm9, [rsp+0x90]
000074c379dd3f4c  vmovaps xmm10, [rsp+0xA0]
000074c379dd3f55  vmovaps xmm11, [rsp+0xB0]
000074c379dd3f5e  vmovaps xmm12, [rsp+0xC0]
000074c379dd3f67  vmovaps xmm14, [rsp+0xD0]
000074c379dd3f70  vmovaps xmm15, [rsp+0xE0]
000074c379dd3f79  add rsp, 0xF0
000074c379dd3f80  pop r11
000074c379dd3f82  pop r10
000074c379dd3f84  pop r9
000074c379dd3f86  pop r8
000074c379dd3f88  pop rsi
000074c379dd3f89  pop rdi
000074c379dd3f8a  pop rdx
000074c379dd3f8b  pop rcx
000074c379dd3f8c  pop rax
000074c379dd3f8d  add rsp, 0x08
000074c379dd3f91  jmp 0x000074C379DD006E
000074c379dd3f96  sub rsp, 0x08
000074c379dd3f9a  push rax
000074c379dd3f9b  push rcx
000074c379dd3f9c  push rdx
000074c379dd3f9d  push rdi
000074c379dd3f9e  push rsi
000074c379dd3f9f  push r8
000074c379dd3fa1  push r9
000074c379dd3fa3  push r10
000074c379dd3fa5  push r11
000074c379dd3fa7  sub rsp, 0xF0
000074c379dd3fae  vmovaps [rsp], xmm0
000074c379dd3fb3  vmovaps [rsp+0x10], xmm1
000074c379dd3fb9  vmovaps [rsp+0x20], xmm2
000074c379dd3fbf  vmovaps [rsp+0x30], xmm3
000074c379dd3fc5  vmovaps [rsp+0x40], xmm4
000074c379dd3fcb  vmovaps [rsp+0x50], xmm5
000074c379dd3fd1  vmovaps [rsp+0x60], xmm6
000074c379dd3fd7  vmovaps [rsp+0x70], xmm7
000074c379dd3fdd  vmovaps [rsp+0x80], xmm9
000074c379dd3fe6  vmovaps [rsp+0x90], xmm10
000074c379dd3fef  vmovaps [rsp+0xA0], xmm11
000074c379dd3ff8  vmovaps [rsp+0xB0], xmm12
000074c379dd4001  vmovaps [rsp+0xC0], xmm13
000074c379dd400a  vmovaps [rsp+0xD0], xmm14
000074c379dd4013  vmovaps [rsp+0xE0], xmm15
000074c379dd401c  sub rsp, 0x30
000074c379dd4020  movaps [rsp], xmm8
000074c379dd4025  movaps [rsp+0x10], xmm7
000074c379dd402a  movaps [rsp+0x20], xmm14
000074c379dd4030  lea rdi, [rsp]
000074c379dd4034  mov esi, 0x00
000074c379dd4039  mov rax, 0x56321ABA4530
000074c379dd4043  call rax
000074c379dd4045  movaps xmm8, [rsp]
000074c379dd404a  add rsp, 0x30
000074c379dd404e  vmovaps xmm0, [rsp]
000074c379dd4053  vmovaps xmm1, [rsp+0x10]
000074c379dd4059  vmovaps xmm2, [rsp+0x20]
000074c379dd405f  vmovaps xmm3, [rsp+0x30]
000074c379dd4065  vmovaps xmm4, [rsp+0x40]
000074c379dd406b  vmovaps xmm5, [rsp+0x50]
000074c379dd4071  vmovaps xmm6, [rsp+0x60]
000074c379dd4077  vmovaps xmm7, [rsp+0x70]
000074c379dd407d  vmovaps xmm9, [rsp+0x80]
000074c379dd4086  vmovaps xmm10, [rsp+0x90]
000074c379dd408f  vmovaps xmm11, [rsp+0xA0]
000074c379dd4098  vmovaps xmm12, [rsp+0xB0]
000074c379dd40a1  vmovaps xmm13, [rsp+0xC0]
000074c379dd40aa  vmovaps xmm14, [rsp+0xD0]
000074c379dd40b3  vmovaps xmm15, [rsp+0xE0]
000074c379dd40bc  add rsp, 0xF0
000074c379dd40c3  pop r11
000074c379dd40c5  pop r10
000074c379dd40c7  pop r9
000074c379dd40c9  pop r8
000074c379dd40cb  pop rsi
000074c379dd40cc  pop rdi
000074c379dd40cd  pop rdx
000074c379dd40ce  pop rcx
000074c379dd40cf  pop rax
000074c379dd40d0  add rsp, 0x08
000074c379dd40d4  jmp 0x000074C379DD0094
000074c379dd40d9  sub rsp, 0x08
000074c379dd40dd  push rax
000074c379dd40de  push rcx
000074c379dd40df  push rdx
000074c379dd40e0  push rdi
000074c379dd40e1  push rsi
000074c379dd40e2  push r8
000074c379dd40e4  push r9
000074c379dd40e6  push r10
000074c379dd40e8  push r11
000074c379dd40ea  sub rsp, 0xF0
000074c379dd40f1  vmovaps [rsp], xmm0
000074c379dd40f6  vmovaps [rsp+0x10], xmm1
000074c379dd40fc  vmovaps [rsp+0x20], xmm2
000074c379dd4102  vmovaps [rsp+0x30], xmm3
000074c379dd4108  vmovaps [rsp+0x40], xmm4
000074c379dd410e  vmovaps [rsp+0x50], xmm5
000074c379dd4114  vmovaps [rsp+0x60], xmm6
000074c379dd411a  vmovaps [rsp+0x70], xmm7
000074c379dd4120  vmovaps [rsp+0x80], xmm8
000074c379dd4129  vmovaps [rsp+0x90], xmm9
000074c379dd4132  vmovaps [rsp+0xA0], xmm10
000074c379dd413b  vmovaps [rsp+0xB0], xmm11
000074c379dd4144  vmovaps [rsp+0xC0], xmm12
000074c379dd414d  vmovaps [rsp+0xD0], xmm13
000074c379dd4156  vmovaps [rsp+0xE0], xmm15
000074c379dd415f  sub rsp, 0x30
000074c379dd4163  movaps [rsp], xmm14
000074c379dd4168  movaps [rsp+0x10], xmm12
000074c379dd416e  movaps [rsp+0x20], xmm9
000074c379dd4174  lea rdi, [rsp]
000074c379dd4178  mov esi, 0x00
000074c379dd417d  mov rax, 0x56321ABA4530
000074c379dd4187  call rax
000074c379dd4189  movaps xmm14, [rsp]
000074c379dd418e  add rsp, 0x30
000074c379dd4192  vmovaps xmm0, [rsp]
000074c379dd4197  vmovaps xmm1, [rsp+0x10]
000074c379dd419d  vmovaps xmm2, [rsp+0x20]
000074c379dd41a3  vmovaps xmm3, [rsp+0x30]
000074c379dd41a9  vmovaps xmm4, [rsp+0x40]
000074c379dd41af  vmovaps xmm5, [rsp+0x50]
000074c379dd41b5  vmovaps xmm6, [rsp+0x60]
000074c379dd41bb  vmovaps xmm7, [rsp+0x70]
000074c379dd41c1  vmovaps xmm8, [rsp+0x80]
000074c379dd41ca  vmovaps xmm9, [rsp+0x90]
000074c379dd41d3  vmovaps xmm10, [rsp+0xA0]
000074c379dd41dc  vmovaps xmm11, [rsp+0xB0]
000074c379dd41e5  vmovaps xmm12, [rsp+0xC0]
000074c379dd41ee  vmovaps xmm13, [rsp+0xD0]
000074c379dd41f7  vmovaps xmm15, [rsp+0xE0]
000074c379dd4200  add rsp, 0xF0
000074c379dd4207  pop r11
000074c379dd4209  pop r10
000074c379dd420b  pop r9
000074c379dd420d  pop r8
000074c379dd420f  pop rsi
000074c379dd4210  pop rdi
000074c379dd4211  pop rdx
000074c379dd4212  pop rcx
000074c379dd4213  pop rax
000074c379dd4214  add rsp, 0x08
000074c379dd4218  jmp 0x000074C379DD00AE
000074c379dd421d  sub rsp, 0x08
000074c379dd4221  push rax
000074c379dd4222  push rcx
000074c379dd4223  push rdx
000074c379dd4224  push rdi
000074c379dd4225  push rsi
000074c379dd4226  push r8
000074c379dd4228  push r9
000074c379dd422a  push r10
000074c379dd422c  push r11
000074c379dd422e  sub rsp, 0xF0
000074c379dd4235  vmovaps [rsp], xmm0
000074c379dd423a  vmovaps [rsp+0x10], xmm1
000074c379dd4240  vmovaps [rsp+0x20], xmm2
000074c379dd4246  vmovaps [rsp+0x30], xmm3
000074c379dd424c  vmovaps [rsp+0x40], xmm4
000074c379dd4252  vmovaps [rsp+0x50], xmm5
000074c379dd4258  vmovaps [rsp+0x60], xmm6
000074c379dd425e  vmovaps [rsp+0x70], xmm7
000074c379dd4264  vmovaps [rsp+0x80], xmm8
000074c379dd426d  vmovaps [rsp+0x90], xmm10
000074c379dd4276  vmovaps [rsp+0xA0], xmm11
000074c379dd427f  vmovaps [rsp+0xB0], xmm12
000074c379dd4288  vmovaps [rsp+0xC0], xmm13
000074c379dd4291  vmovaps [rsp+0xD0], xmm14
000074c379dd429a  vmovaps [rsp+0xE0], xmm15
000074c379dd42a3  sub rsp, 0x30
000074c379dd42a7  movaps [rsp], xmm9
000074c379dd42ac  movaps [rsp+0x10], xmm7
000074c379dd42b1  movaps [rsp+0x20], xmm12
000074c379dd42b7  lea rdi, [rsp]
000074c379dd42bb  mov esi, 0x00
000074c379dd42c0  mov rax, 0x56321ABA4530
000074c379dd42ca  call rax
000074c379dd42cc  movaps xmm9, [rsp]
000074c379dd42d1  add rsp, 0x30
000074c379dd42d5  vmovaps xmm0, [rsp]
000074c379dd42da  vmovaps xmm1, [rsp+0x10]
000074c379dd42e0  vmovaps xmm2, [rsp+0x20]
000074c379dd42e6  vmovaps xmm3, [rsp+0x30]
000074c379dd42ec  vmovaps xmm4, [rsp+0x40]
000074c379dd42f2  vmovaps xmm5, [rsp+0x50]
000074c379dd42f8  vmovaps xmm6, [rsp+0x60]
000074c379dd42fe  vmovaps xmm7, [rsp+0x70]
000074c379dd4304  vmovaps xmm8, [rsp+0x80]
000074c379dd430d  vmovaps xmm10, [rsp+0x90]
000074c379dd4316  vmovaps xmm11, [rsp+0xA0]
000074c379dd431f  vmovaps xmm12, [rsp+0xB0]
000074c379dd4328  vmovaps xmm13, [rsp+0xC0]
000074c379dd4331  vmovaps xmm14, [rsp+0xD0]
000074c379dd433a  vmovaps xmm15, [rsp+0xE0]
000074c379dd4343  add rsp, 0xF0
000074c379dd434a  pop r11
000074c379dd434c  pop r10
000074c379dd434e  pop r9
000074c379dd4350  pop r8
000074c379dd4352  pop rsi
000074c379dd4353  pop rdi
000074c379dd4354  pop rdx
000074c379dd4355  pop rcx
000074c379dd4356  pop rax
000074c379dd4357  add rsp, 0x08
000074c379dd435b  jmp 0x000074C379DD00DD
000074c379dd4360  sub rsp, 0x08
000074c379dd4364  push rax
000074c379dd4365  push rcx
000074c379dd4366  push rdx
000074c379dd4367  push rdi
000074c379dd4368  push rsi
000074c379dd4369  push r8
000074c379dd436b  push r9
000074c379dd436d  push r10
000074c379dd436f  push r11
000074c379dd4371  sub rsp, 0xF0
000074c379dd4378  vmovaps [rsp], xmm0
000074c379dd437d  vmovaps [rsp+0x10], xmm1
000074c379dd4383  vmovaps [rsp+0x20], xmm2
000074c379dd4389  vmovaps [rsp+0x30], xmm3
000074c379dd438f  vmovaps [rsp+0x40], xmm4
000074c379dd4395  vmovaps [rsp+0x50], xmm5
000074c379dd439b  vmovaps [rsp+0x60], xmm6
000074c379dd43a1  vmovaps [rsp+0x70], xmm7
000074c379dd43a7  vmovaps [rsp+0x80], xmm8
000074c379dd43b0  vmovaps [rsp+0x90], xmm9
000074c379dd43b9  vmovaps [rsp+0xA0], xmm10
000074c379dd43c2  vmovaps [rsp+0xB0], xmm11
000074c379dd43cb  vmovaps [rsp+0xC0], xmm13
000074c379dd43d4  vmovaps [rsp+0xD0], xmm14
000074c379dd43dd  vmovaps [rsp+0xE0], xmm15
000074c379dd43e6  sub rsp, 0x30
000074c379dd43ea  movaps [rsp], xmm12
000074c379dd43ef  movaps [rsp+0x10], xmm15
000074c379dd43f5  movaps [rsp+0x20], xmm11
000074c379dd43fb  lea rdi, [rsp]
000074c379dd43ff  mov esi, 0x00
000074c379dd4404  mov rax, 0x56321ABA4530
000074c379dd440e  call rax
000074c379dd4410  movaps xmm12, [rsp]
000074c379dd4415  add rsp, 0x30
000074c379dd4419  vmovaps xmm0, [rsp]
000074c379dd441e  vmovaps xmm1, [rsp+0x10]
000074c379dd4424  vmovaps xmm2, [rsp+0x20]
000074c379dd442a  vmovaps xmm3, [rsp+0x30]
000074c379dd4430  vmovaps xmm4, [rsp+0x40]
000074c379dd4436  vmovaps xmm5, [rsp+0x50]
000074c379dd443c  vmovaps xmm6, [rsp+0x60]
000074c379dd4442  vmovaps xmm7, [rsp+0x70]
000074c379dd4448  vmovaps xmm8, [rsp+0x80]
000074c379dd4451  vmovaps xmm9, [rsp+0x90]
000074c379dd445a  vmovaps xmm10, [rsp+0xA0]
000074c379dd4463  vmovaps xmm11, [rsp+0xB0]
000074c379dd446c  vmovaps xmm13, [rsp+0xC0]
000074c379dd4475  vmovaps xmm14, [rsp+0xD0]
000074c379dd447e  vmovaps xmm15, [rsp+0xE0]
000074c379dd4487  add rsp, 0xF0
000074c379dd448e  pop r11
000074c379dd4490  pop r10
000074c379dd4492  pop r9
000074c379dd4494  pop r8
000074c379dd4496  pop rsi
000074c379dd4497  pop rdi
000074c379dd4498  pop rdx
000074c379dd4499  pop rcx
000074c379dd449a  pop rax
000074c379dd449b  add rsp, 0x08
000074c379dd449f  jmp 0x000074C379DD00F7
000074c379dd44a4  sub rsp, 0x08
000074c379dd44a8  push rax
000074c379dd44a9  push rcx
000074c379dd44aa  push rdx
000074c379dd44ab  push rdi
000074c379dd44ac  push rsi
000074c379dd44ad  push r8
000074c379dd44af  push r9
000074c379dd44b1  push r10
000074c379dd44b3  push r11
000074c379dd44b5  sub rsp, 0xF0
000074c379dd44bc  vmovaps [rsp], xmm0
000074c379dd44c1  vmovaps [rsp+0x10], xmm1
000074c379dd44c7  vmovaps [rsp+0x20], xmm2
000074c379dd44cd  vmovaps [rsp+0x30], xmm3
000074c379dd44d3  vmovaps [rsp+0x40], xmm4
000074c379dd44d9  vmovaps [rsp+0x50], xmm5
000074c379dd44df  vmovaps [rsp+0x60], xmm6
000074c379dd44e5  vmovaps [rsp+0x70], xmm7
000074c379dd44eb  vmovaps [rsp+0x80], xmm8
000074c379dd44f4  vmovaps [rsp+0x90], xmm9
000074c379dd44fd  vmovaps [rsp+0xA0], xmm10
000074c379dd4506  vmovaps [rsp+0xB0], xmm12
000074c379dd450f  vmovaps [rsp+0xC0], xmm13
000074c379dd4518  vmovaps [rsp+0xD0], xmm14
000074c379dd4521  vmovaps [rsp+0xE0], xmm15
000074c379dd452a  sub rsp, 0x30
000074c379dd452e  movaps [rsp], xmm11
000074c379dd4533  movaps [rsp+0x10], xmm7
000074c379dd4538  movaps [rsp+0x20], xmm15
000074c379dd453e  lea rdi, [rsp]
000074c379dd4542  mov esi, 0x00
000074c379dd4547  mov rax, 0x56321ABA4530
000074c379dd4551  call rax
000074c379dd4553  movaps xmm11, [rsp]
000074c379dd4558  add rsp, 0x30
000074c379dd455c  vmovaps xmm0, [rsp]
000074c379dd4561  vmovaps xmm1, [rsp+0x10]
000074c379dd4567  vmovaps xmm2, [rsp+0x20]
000074c379dd456d  vmovaps xmm3, [rsp+0x30]
000074c379dd4573  vmovaps xmm4, [rsp+0x40]
000074c379dd4579  vmovaps xmm5, [rsp+0x50]
000074c379dd457f  vmovaps xmm6, [rsp+0x60]
000074c379dd4585  vmovaps xmm7, [rsp+0x70]
000074c379dd458b  vmovaps xmm8, [rsp+0x80]
000074c379dd4594  vmovaps xmm9, [rsp+0x90]
000074c379dd459d  vmovaps xmm10, [rsp+0xA0]
000074c379dd45a6  vmovaps xmm12, [rsp+0xB0]
000074c379dd45af  vmovaps xmm13, [rsp+0xC0]
000074c379dd45b8  vmovaps xmm14, [rsp+0xD0]
000074c379dd45c1  vmovaps xmm15, [rsp+0xE0]
000074c379dd45ca  add rsp, 0xF0
000074c379dd45d1  pop r11
000074c379dd45d3  pop r10
000074c379dd45d5  pop r9
000074c379dd45d7  pop r8
000074c379dd45d9  pop rsi
000074c379dd45da  pop rdi
000074c379dd45db  pop rdx
000074c379dd45dc  pop rcx
000074c379dd45dd  pop rax
000074c379dd45de  add rsp, 0x08
000074c379dd45e2  jmp 0x000074C379DD0123
000074c379dd45e7  sub rsp, 0x08
000074c379dd45eb  push rax
000074c379dd45ec  push rcx
000074c379dd45ed  push rdx
000074c379dd45ee  push rdi
000074c379dd45ef  push rsi
000074c379dd45f0  push r8
000074c379dd45f2  push r9
000074c379dd45f4  push r10
000074c379dd45f6  push r11
000074c379dd45f8  sub rsp, 0xF0
000074c379dd45ff  vmovaps [rsp], xmm0
000074c379dd4604  vmovaps [rsp+0x10], xmm1
000074c379dd460a  vmovaps [rsp+0x20], xmm2
000074c379dd4610  vmovaps [rsp+0x30], xmm3
000074c379dd4616  vmovaps [rsp+0x40], xmm4
000074c379dd461c  vmovaps [rsp+0x50], xmm5
000074c379dd4622  vmovaps [rsp+0x60], xmm6
000074c379dd4628  vmovaps [rsp+0x70], xmm7
000074c379dd462e  vmovaps [rsp+0x80], xmm8
000074c379dd4637  vmovaps [rsp+0x90], xmm9
000074c379dd4640  vmovaps [rsp+0xA0], xmm10
000074c379dd4649  vmovaps [rsp+0xB0], xmm11
000074c379dd4652  vmovaps [rsp+0xC0], xmm12
000074c379dd465b  vmovaps [rsp+0xD0], xmm13
000074c379dd4664  vmovaps [rsp+0xE0], xmm14
000074c379dd466d  sub rsp, 0x30
000074c379dd4671  movaps [rsp], xmm15
000074c379dd4676  movaps [rsp+0x10], xmm10
000074c379dd467c  movaps [rsp+0x20], xmm13
000074c379dd4682  lea rdi, [rsp]
000074c379dd4686  mov esi, 0x00
000074c379dd468b  mov rax, 0x56321ABA4530
000074c379dd4695  call rax
000074c379dd4697  movaps xmm15, [rsp]
000074c379dd469c  add rsp, 0x30
000074c379dd46a0  vmovaps xmm0, [rsp]
000074c379dd46a5  vmovaps xmm1, [rsp+0x10]
000074c379dd46ab  vmovaps xmm2, [rsp+0x20]
000074c379dd46b1  vmovaps xmm3, [rsp+0x30]
000074c379dd46b7  vmovaps xmm4, [rsp+0x40]
000074c379dd46bd  vmovaps xmm5, [rsp+0x50]
000074c379dd46c3  vmovaps xmm6, [rsp+0x60]
000074c379dd46c9  vmovaps xmm7, [rsp+0x70]
000074c379dd46cf  vmovaps xmm8, [rsp+0x80]
000074c379dd46d8  vmovaps xmm9, [rsp+0x90]
000074c379dd46e1  vmovaps xmm10, [rsp+0xA0]
000074c379dd46ea  vmovaps xmm11, [rsp+0xB0]
000074c379dd46f3  vmovaps xmm12, [rsp+0xC0]
000074c379dd46fc  vmovaps xmm13, [rsp+0xD0]
000074c379dd4705  vmovaps xmm14, [rsp+0xE0]
000074c379dd470e  add rsp, 0xF0
000074c379dd4715  pop r11
000074c379dd4717  pop r10
000074c379dd4719  pop r9
000074c379dd471b  pop r8
000074c379dd471d  pop rsi
000074c379dd471e  pop rdi
000074c379dd471f  pop rdx
000074c379dd4720  pop rcx
000074c379dd4721  pop rax
000074c379dd4722  add rsp, 0x08
000074c379dd4726  jmp 0x000074C379DD013D
000074c379dd472b  sub rsp, 0x08
000074c379dd472f  push rax
000074c379dd4730  push rcx
000074c379dd4731  push rdx
000074c379dd4732  push rdi
000074c379dd4733  push rsi
000074c379dd4734  push r8
000074c379dd4736  push r9
000074c379dd4738  push r10
000074c379dd473a  push r11
000074c379dd473c  sub rsp, 0xF0
000074c379dd4743  vmovaps [rsp], xmm0
000074c379dd4748  vmovaps [rsp+0x10], xmm1
000074c379dd474e  vmovaps [rsp+0x20], xmm2
000074c379dd4754  vmovaps [rsp+0x30], xmm3
000074c379dd475a  vmovaps [rsp+0x40], xmm4
000074c379dd4760  vmovaps [rsp+0x50], xmm5
000074c379dd4766  vmovaps [rsp+0x60], xmm6
000074c379dd476c  vmovaps [rsp+0x70], xmm7
000074c379dd4772  vmovaps [rsp+0x80], xmm8
000074c379dd477b  vmovaps [rsp+0x90], xmm9
000074c379dd4784  vmovaps [rsp+0xA0], xmm11
000074c379dd478d  vmovaps [rsp+0xB0], xmm12
000074c379dd4796  vmovaps [rsp+0xC0], xmm13
000074c379dd479f  vmovaps [rsp+0xD0], xmm14
000074c379dd47a8  vmovaps [rsp+0xE0], xmm15
000074c379dd47b1  sub rsp, 0x30
000074c379dd47b5  movaps [rsp], xmm10
000074c379dd47ba  movaps [rsp+0x10], xmm7
000074c379dd47bf  movaps [rsp+0x20], xmm13
000074c379dd47c5  lea rdi, [rsp]
000074c379dd47c9  mov esi, 0x00
000074c379dd47ce  mov rax, 0x56321ABA4530
000074c379dd47d8  call rax
000074c379dd47da  movaps xmm10, [rsp]
000074c379dd47df  add rsp, 0x30
000074c379dd47e3  vmovaps xmm0, [rsp]
000074c379dd47e8  vmovaps xmm1, [rsp+0x10]
000074c379dd47ee  vmovaps xmm2, [rsp+0x20]
000074c379dd47f4  vmovaps xmm3, [rsp+0x30]
000074c379dd47fa  vmovaps xmm4, [rsp+0x40]
000074c379dd4800  vmovaps xmm5, [rsp+0x50]
000074c379dd4806  vmovaps xmm6, [rsp+0x60]
000074c379dd480c  vmovaps xmm7, [rsp+0x70]
000074c379dd4812  vmovaps xmm8, [rsp+0x80]
000074c379dd481b  vmovaps xmm9, [rsp+0x90]
000074c379dd4824  vmovaps xmm11, [rsp+0xA0]
000074c379dd482d  vmovaps xmm12, [rsp+0xB0]
000074c379dd4836  vmovaps xmm13, [rsp+0xC0]
000074c379dd483f  vmovaps xmm14, [rsp+0xD0]
000074c379dd4848  vmovaps xmm15, [rsp+0xE0]
000074c379dd4851  add rsp, 0xF0
000074c379dd4858  pop r11
000074c379dd485a  pop r10
000074c379dd485c  pop r9
000074c379dd485e  pop r8
000074c379dd4860  pop rsi
000074c379dd4861  pop rdi
000074c379dd4862  pop rdx
000074c379dd4863  pop rcx
000074c379dd4864  pop rax
000074c379dd4865  add rsp, 0x08
000074c379dd4869  jmp 0x000074C379DD0169
000074c379dd486e  sub rsp, 0x08
000074c379dd4872  push rax
000074c379dd4873  push rcx
000074c379dd4874  push rdx
000074c379dd4875  push rdi
000074c379dd4876  push rsi
000074c379dd4877  push r8
000074c379dd4879  push r9
000074c379dd487b  push r10
000074c379dd487d  push r11
000074c379dd487f  sub rsp, 0xF0
000074c379dd4886  vmovaps [rsp], xmm0
000074c379dd488b  vmovaps [rsp+0x10], xmm1
000074c379dd4891  vmovaps [rsp+0x20], xmm2
000074c379dd4897  vmovaps [rsp+0x30], xmm3
000074c379dd489d  vmovaps [rsp+0x40], xmm4
000074c379dd48a3  vmovaps [rsp+0x50], xmm5
000074c379dd48a9  vmovaps [rsp+0x60], xmm6
000074c379dd48af  vmovaps [rsp+0x70], xmm7
000074c379dd48b5  vmovaps [rsp+0x80], xmm8
000074c379dd48be  vmovaps [rsp+0x90], xmm9
000074c379dd48c7  vmovaps [rsp+0xA0], xmm10
000074c379dd48d0  vmovaps [rsp+0xB0], xmm11
000074c379dd48d9  vmovaps [rsp+0xC0], xmm12
000074c379dd48e2  vmovaps [rsp+0xD0], xmm14
000074c379dd48eb  vmovaps [rsp+0xE0], xmm15
000074c379dd48f4  sub rsp, 0x30
000074c379dd48f8  movaps [rsp], xmm13
000074c379dd48fd  movaps [rsp+0x10], xmm1
000074c379dd4902  movaps [rsp+0x20], xmm8
000074c379dd4908  lea rdi, [rsp]
000074c379dd490c  mov esi, 0x00
000074c379dd4911  mov rax, 0x56321ABA4530
000074c379dd491b  call rax
000074c379dd491d  movaps xmm13, [rsp]
000074c379dd4922  add rsp, 0x30
000074c379dd4926  vmovaps xmm0, [rsp]
000074c379dd492b  vmovaps xmm1, [rsp+0x10]
000074c379dd4931  vmovaps xmm2, [rsp+0x20]
000074c379dd4937  vmovaps xmm3, [rsp+0x30]
000074c379dd493d  vmovaps xmm4, [rsp+0x40]
000074c379dd4943  vmovaps xmm5, [rsp+0x50]
000074c379dd4949  vmovaps xmm6, [rsp+0x60]
000074c379dd494f  vmovaps xmm7, [rsp+0x70]
000074c379dd4955  vmovaps xmm8, [rsp+0x80]
000074c379dd495e  vmovaps xmm9, [rsp+0x90]
000074c379dd4967  vmovaps xmm10, [rsp+0xA0]
000074c379dd4970  vmovaps xmm11, [rsp+0xB0]
000074c379dd4979  vmovaps xmm12, [rsp+0xC0]
000074c379dd4982  vmovaps xmm14, [rsp+0xD0]
000074c379dd498b  vmovaps xmm15, [rsp+0xE0]
000074c379dd4994  add rsp, 0xF0
000074c379dd499b  pop r11
000074c379dd499d  pop r10
000074c379dd499f  pop r9
000074c379dd49a1  pop r8
000074c379dd49a3  pop rsi
000074c379dd49a4  pop rdi
000074c379dd49a5  pop rdx
000074c379dd49a6  pop rcx
000074c379dd49a7  pop rax
000074c379dd49a8  add rsp, 0x08
000074c379dd49ac  jmp 0x000074C379DD0183
000074c379dd49b1  call 0x000074C379BFF430
000074c379dd49b6  jmp 0x000074C379DD018D
000074c379dd49bb  sub rsp, 0x08
000074c379dd49bf  push rax
000074c379dd49c0  push rcx
000074c379dd49c1  push rdx
000074c379dd49c2  push rdi
000074c379dd49c3  push rsi
000074c379dd49c4  push r8
000074c379dd49c6  push r9
000074c379dd49c8  push r10
000074c379dd49ca  push r11
000074c379dd49cc  sub rsp, 0xF0
000074c379dd49d3  vmovaps [rsp], xmm0
000074c379dd49d8  vmovaps [rsp+0x10], xmm1
000074c379dd49de  vmovaps [rsp+0x20], xmm2
000074c379dd49e4  vmovaps [rsp+0x30], xmm3
000074c379dd49ea  vmovaps [rsp+0x40], xmm4
000074c379dd49f0  vmovaps [rsp+0x50], xmm5
000074c379dd49f6  vmovaps [rsp+0x60], xmm6
000074c379dd49fc  vmovaps [rsp+0x70], xmm7
000074c379dd4a02  vmovaps [rsp+0x80], xmm9
000074c379dd4a0b  vmovaps [rsp+0x90], xmm10
000074c379dd4a14  vmovaps [rsp+0xA0], xmm11
000074c379dd4a1d  vmovaps [rsp+0xB0], xmm12
000074c379dd4a26  vmovaps [rsp+0xC0], xmm13
000074c379dd4a2f  vmovaps [rsp+0xD0], xmm14
000074c379dd4a38  vmovaps [rsp+0xE0], xmm15
000074c379dd4a41  sub rsp, 0x30
000074c379dd4a45  movaps [rsp], xmm8
000074c379dd4a4a  movaps [rsp+0x10], xmm14
000074c379dd4a50  movaps [rsp+0x20], xmm9
000074c379dd4a56  lea rdi, [rsp]
000074c379dd4a5a  mov esi, 0x00
000074c379dd4a5f  mov rax, 0x56321ABA4530
000074c379dd4a69  call rax
000074c379dd4a6b  movaps xmm8, [rsp]
000074c379dd4a70  add rsp, 0x30
000074c379dd4a74  vmovaps xmm0, [rsp]
000074c379dd4a79  vmovaps xmm1, [rsp+0x10]
000074c379dd4a7f  vmovaps xmm2, [rsp+0x20]
000074c379dd4a85  vmovaps xmm3, [rsp+0x30]
000074c379dd4a8b  vmovaps xmm4, [rsp+0x40]
000074c379dd4a91  vmovaps xmm5, [rsp+0x50]
000074c379dd4a97  vmovaps xmm6, [rsp+0x60]
000074c379dd4a9d  vmovaps xmm7, [rsp+0x70]
000074c379dd4aa3  vmovaps xmm9, [rsp+0x80]
000074c379dd4aac  vmovaps xmm10, [rsp+0x90]
000074c379dd4ab5  vmovaps xmm11, [rsp+0xA0]
000074c379dd4abe  vmovaps xmm12, [rsp+0xB0]
000074c379dd4ac7  vmovaps xmm13, [rsp+0xC0]
000074c379dd4ad0  vmovaps xmm14, [rsp+0xD0]
000074c379dd4ad9  vmovaps xmm15, [rsp+0xE0]
000074c379dd4ae2  add rsp, 0xF0
000074c379dd4ae9  pop r11
000074c379dd4aeb  pop r10
000074c379dd4aed  pop r9
000074c379dd4aef  pop r8
000074c379dd4af1  pop rsi
000074c379dd4af2  pop rdi
000074c379dd4af3  pop rdx
000074c379dd4af4  pop rcx
000074c379dd4af5  pop rax
000074c379dd4af6  add rsp, 0x08
000074c379dd4afa  jmp 0x000074C379DD01AF
000074c379dd4aff  sub rsp, 0x08
000074c379dd4b03  push rax
000074c379dd4b04  push rcx
000074c379dd4b05  push rdx
000074c379dd4b06  push rdi
000074c379dd4b07  push rsi
000074c379dd4b08  push r8
000074c379dd4b0a  push r9
000074c379dd4b0c  push r10
000074c379dd4b0e  push r11
000074c379dd4b10  sub rsp, 0xF0
000074c379dd4b17  vmovaps [rsp], xmm0
000074c379dd4b1c  vmovaps [rsp+0x10], xmm1
000074c379dd4b22  vmovaps [rsp+0x20], xmm2
000074c379dd4b28  vmovaps [rsp+0x30], xmm3
000074c379dd4b2e  vmovaps [rsp+0x40], xmm4
000074c379dd4b34  vmovaps [rsp+0x50], xmm5
000074c379dd4b3a  vmovaps [rsp+0x60], xmm6
000074c379dd4b40  vmovaps [rsp+0x70], xmm7
000074c379dd4b46  vmovaps [rsp+0x80], xmm8
000074c379dd4b4f  vmovaps [rsp+0x90], xmm10
000074c379dd4b58  vmovaps [rsp+0xA0], xmm11
000074c379dd4b61  vmovaps [rsp+0xB0], xmm12
000074c379dd4b6a  vmovaps [rsp+0xC0], xmm13
000074c379dd4b73  vmovaps [rsp+0xD0], xmm14
000074c379dd4b7c  vmovaps [rsp+0xE0], xmm15
000074c379dd4b85  sub rsp, 0x30
000074c379dd4b89  movaps [rsp], xmm9
000074c379dd4b8e  movaps [rsp+0x10], xmm1
000074c379dd4b93  movaps [rsp+0x20], xmm14
000074c379dd4b99  lea rdi, [rsp]
000074c379dd4b9d  mov esi, 0x00
000074c379dd4ba2  mov rax, 0x56321ABA4530
000074c379dd4bac  call rax
000074c379dd4bae  movaps xmm9, [rsp]
000074c379dd4bb3  add rsp, 0x30
000074c379dd4bb7  vmovaps xmm0, [rsp]
000074c379dd4bbc  vmovaps xmm1, [rsp+0x10]
000074c379dd4bc2  vmovaps xmm2, [rsp+0x20]
000074c379dd4bc8  vmovaps xmm3, [rsp+0x30]
000074c379dd4bce  vmovaps xmm4, [rsp+0x40]
000074c379dd4bd4  vmovaps xmm5, [rsp+0x50]
000074c379dd4bda  vmovaps xmm6, [rsp+0x60]
000074c379dd4be0  vmovaps xmm7, [rsp+0x70]
000074c379dd4be6  vmovaps xmm8, [rsp+0x80]
000074c379dd4bef  vmovaps xmm10, [rsp+0x90]
000074c379dd4bf8  vmovaps xmm11, [rsp+0xA0]
000074c379dd4c01  vmovaps xmm12, [rsp+0xB0]
000074c379dd4c0a  vmovaps xmm13, [rsp+0xC0]
000074c379dd4c13  vmovaps xmm14, [rsp+0xD0]
000074c379dd4c1c  vmovaps xmm15, [rsp+0xE0]
000074c379dd4c25  add rsp, 0xF0
000074c379dd4c2c  pop r11
000074c379dd4c2e  pop r10
000074c379dd4c30  pop r9
000074c379dd4c32  pop r8
000074c379dd4c34  pop rsi
000074c379dd4c35  pop rdi
000074c379dd4c36  pop rdx
000074c379dd4c37  pop rcx
000074c379dd4c38  pop rax
000074c379dd4c39  add rsp, 0x08
000074c379dd4c3d  jmp 0x000074C379DD01DD
000074c379dd4c42  sub rsp, 0x08
000074c379dd4c46  push rax
000074c379dd4c47  push rcx
000074c379dd4c48  push rdx
000074c379dd4c49  push rdi
000074c379dd4c4a  push rsi
000074c379dd4c4b  push r8
000074c379dd4c4d  push r9
000074c379dd4c4f  push r10
000074c379dd4c51  push r11
000074c379dd4c53  sub rsp, 0xF0
000074c379dd4c5a  vmovaps [rsp], xmm0
000074c379dd4c5f  vmovaps [rsp+0x10], xmm1
000074c379dd4c65  vmovaps [rsp+0x20], xmm2
000074c379dd4c6b  vmovaps [rsp+0x30], xmm3
000074c379dd4c71  vmovaps [rsp+0x40], xmm4
000074c379dd4c77  vmovaps [rsp+0x50], xmm5
000074c379dd4c7d  vmovaps [rsp+0x60], xmm6
000074c379dd4c83  vmovaps [rsp+0x70], xmm7
000074c379dd4c89  vmovaps [rsp+0x80], xmm8
000074c379dd4c92  vmovaps [rsp+0x90], xmm9
000074c379dd4c9b  vmovaps [rsp+0xA0], xmm10
000074c379dd4ca4  vmovaps [rsp+0xB0], xmm11
000074c379dd4cad  vmovaps [rsp+0xC0], xmm12
000074c379dd4cb6  vmovaps [rsp+0xD0], xmm13
000074c379dd4cbf  vmovaps [rsp+0xE0], xmm15
000074c379dd4cc8  sub rsp, 0x30
000074c379dd4ccc  movaps [rsp], xmm14
000074c379dd4cd1  movaps [rsp+0x10], xmm4
000074c379dd4cd6  movaps [rsp+0x20], xmm1
000074c379dd4cdb  lea rdi, [rsp]
000074c379dd4cdf  mov esi, 0x00
000074c379dd4ce4  mov rax, 0x56321ABA4530
000074c379dd4cee  call rax
000074c379dd4cf0  movaps xmm14, [rsp]
000074c379dd4cf5  add rsp, 0x30
000074c379dd4cf9  vmovaps xmm0, [rsp]
000074c379dd4cfe  vmovaps xmm1, [rsp+0x10]
000074c379dd4d04  vmovaps xmm2, [rsp+0x20]
000074c379dd4d0a  vmovaps xmm3, [rsp+0x30]
000074c379dd4d10  vmovaps xmm4, [rsp+0x40]
000074c379dd4d16  vmovaps xmm5, [rsp+0x50]
000074c379dd4d1c  vmovaps xmm6, [rsp+0x60]
000074c379dd4d22  vmovaps xmm7, [rsp+0x70]
000074c379dd4d28  vmovaps xmm8, [rsp+0x80]
000074c379dd4d31  vmovaps xmm9, [rsp+0x90]
000074c379dd4d3a  vmovaps xmm10, [rsp+0xA0]
000074c379dd4d43  vmovaps xmm11, [rsp+0xB0]
000074c379dd4d4c  vmovaps xmm12, [rsp+0xC0]
000074c379dd4d55  vmovaps xmm13, [rsp+0xD0]
000074c379dd4d5e  vmovaps xmm15, [rsp+0xE0]
000074c379dd4d67  add rsp, 0xF0
000074c379dd4d6e  pop r11
000074c379dd4d70  pop r10
000074c379dd4d72  pop r9
000074c379dd4d74  pop r8
000074c379dd4d76  pop rsi
000074c379dd4d77  pop rdi
000074c379dd4d78  pop rdx
000074c379dd4d79  pop rcx
000074c379dd4d7a  pop rax
000074c379dd4d7b  add rsp, 0x08
000074c379dd4d7f  jmp 0x000074C379DD0203
000074c379dd4d84  sub rsp, 0x08
000074c379dd4d88  push rax
000074c379dd4d89  push rcx
000074c379dd4d8a  push rdx
000074c379dd4d8b  push rdi
000074c379dd4d8c  push rsi
000074c379dd4d8d  push r8
000074c379dd4d8f  push r9
000074c379dd4d91  push r10
000074c379dd4d93  push r11
000074c379dd4d95  sub rsp, 0xF0
000074c379dd4d9c  vmovaps [rsp], xmm0
000074c379dd4da1  vmovaps [rsp+0x10], xmm2
000074c379dd4da7  vmovaps [rsp+0x20], xmm3
000074c379dd4dad  vmovaps [rsp+0x30], xmm4
000074c379dd4db3  vmovaps [rsp+0x40], xmm5
000074c379dd4db9  vmovaps [rsp+0x50], xmm6
000074c379dd4dbf  vmovaps [rsp+0x60], xmm7
000074c379dd4dc5  vmovaps [rsp+0x70], xmm8
000074c379dd4dcb  vmovaps [rsp+0x80], xmm9
000074c379dd4dd4  vmovaps [rsp+0x90], xmm10
000074c379dd4ddd  vmovaps [rsp+0xA0], xmm11
000074c379dd4de6  vmovaps [rsp+0xB0], xmm12
000074c379dd4def  vmovaps [rsp+0xC0], xmm13
000074c379dd4df8  vmovaps [rsp+0xD0], xmm14
000074c379dd4e01  vmovaps [rsp+0xE0], xmm15
000074c379dd4e0a  sub rsp, 0x30
000074c379dd4e0e  movaps [rsp], xmm1
000074c379dd4e12  movaps [rsp+0x10], xmm12
000074c379dd4e18  movaps [rsp+0x20], xmm11
000074c379dd4e1e  lea rdi, [rsp]
000074c379dd4e22  mov esi, 0x00
000074c379dd4e27  mov rax, 0x56321ABA4530
000074c379dd4e31  call rax
000074c379dd4e33  movaps xmm1, [rsp]
000074c379dd4e37  add rsp, 0x30
000074c379dd4e3b  vmovaps xmm0, [rsp]
000074c379dd4e40  vmovaps xmm2, [rsp+0x10]
000074c379dd4e46  vmovaps xmm3, [rsp+0x20]
000074c379dd4e4c  vmovaps xmm4, [rsp+0x30]
000074c379dd4e52  vmovaps xmm5, [rsp+0x40]
000074c379dd4e58  vmovaps xmm6, [rsp+0x50]
000074c379dd4e5e  vmovaps xmm7, [rsp+0x60]
000074c379dd4e64  vmovaps xmm8, [rsp+0x70]
000074c379dd4e6a  vmovaps xmm9, [rsp+0x80]
000074c379dd4e73  vmovaps xmm10, [rsp+0x90]
000074c379dd4e7c  vmovaps xmm11, [rsp+0xA0]
000074c379dd4e85  vmovaps xmm12, [rsp+0xB0]
000074c379dd4e8e  vmovaps xmm13, [rsp+0xC0]
000074c379dd4e97  vmovaps xmm14, [rsp+0xD0]
000074c379dd4ea0  vmovaps xmm15, [rsp+0xE0]
000074c379dd4ea9  add rsp, 0xF0
000074c379dd4eb0  pop r11
000074c379dd4eb2  pop r10
000074c379dd4eb4  pop r9
000074c379dd4eb6  pop r8
000074c379dd4eb8  pop rsi
000074c379dd4eb9  pop rdi
000074c379dd4eba  pop rdx
000074c379dd4ebb  pop rcx
000074c379dd4ebc  pop rax
000074c379dd4ebd  add rsp, 0x08
000074c379dd4ec1  jmp 0x000074C379DD0224
000074c379dd4ec6  call 0x000074C379CE20A0
000074c379dd4ecb  jmp 0x000074C379DD0232
000074c379dd4ed0  call 0x000074C379C09D70
000074c379dd4ed5  jmp 0x000074C379DD023C
000074c379dd4eda  sub rsp, 0x08
000074c379dd4ede  push rax
000074c379dd4edf  push rcx
000074c379dd4ee0  push rdx
000074c379dd4ee1  push rdi
000074c379dd4ee2  push rsi
000074c379dd4ee3  push r8
000074c379dd4ee5  push r9
000074c379dd4ee7  push r10
000074c379dd4ee9  push r11
000074c379dd4eeb  sub rsp, 0xF0
000074c379dd4ef2  vmovaps [rsp], xmm0
000074c379dd4ef7  vmovaps [rsp+0x10], xmm1
000074c379dd4efd  vmovaps [rsp+0x20], xmm2
000074c379dd4f03  vmovaps [rsp+0x30], xmm3
000074c379dd4f09  vmovaps [rsp+0x40], xmm4
000074c379dd4f0f  vmovaps [rsp+0x50], xmm5
000074c379dd4f15  vmovaps [rsp+0x60], xmm6
000074c379dd4f1b  vmovaps [rsp+0x70], xmm8
000074c379dd4f21  vmovaps [rsp+0x80], xmm9
000074c379dd4f2a  vmovaps [rsp+0x90], xmm10
000074c379dd4f33  vmovaps [rsp+0xA0], xmm11
000074c379dd4f3c  vmovaps [rsp+0xB0], xmm12
000074c379dd4f45  vmovaps [rsp+0xC0], xmm13
000074c379dd4f4e  vmovaps [rsp+0xD0], xmm14
000074c379dd4f57  vmovaps [rsp+0xE0], xmm15
000074c379dd4f60  sub rsp, 0x30
000074c379dd4f64  movaps [rsp], xmm7
000074c379dd4f68  movaps [rsp+0x10], xmm15
000074c379dd4f6e  movaps [rsp+0x20], xmm10
000074c379dd4f74  lea rdi, [rsp]
000074c379dd4f78  mov esi, 0x00
000074c379dd4f7d  mov rax, 0x56321ABA4530
000074c379dd4f87  call rax
000074c379dd4f89  movaps xmm7, [rsp]
000074c379dd4f8d  add rsp, 0x30
000074c379dd4f91  vmovaps xmm0, [rsp]
000074c379dd4f96  vmovaps xmm1, [rsp+0x10]
000074c379dd4f9c  vmovaps xmm2, [rsp+0x20]
000074c379dd4fa2  vmovaps xmm3, [rsp+0x30]
000074c379dd4fa8  vmovaps xmm4, [rsp+0x40]
000074c379dd4fae  vmovaps xmm5, [rsp+0x50]
000074c379dd4fb4  vmovaps xmm6, [rsp+0x60]
000074c379dd4fba  vmovaps xmm8, [rsp+0x70]
000074c379dd4fc0  vmovaps xmm9, [rsp+0x80]
000074c379dd4fc9  vmovaps xmm10, [rsp+0x90]
000074c379dd4fd2  vmovaps xmm11, [rsp+0xA0]
000074c379dd4fdb  vmovaps xmm12, [rsp+0xB0]
000074c379dd4fe4  vmovaps xmm13, [rsp+0xC0]
000074c379dd4fed  vmovaps xmm14, [rsp+0xD0]
000074c379dd4ff6  vmovaps xmm15, [rsp+0xE0]
000074c379dd4fff  add rsp, 0xF0
000074c379dd5006  pop r11
000074c379dd5008  pop r10
000074c379dd500a  pop r9
000074c379dd500c  pop r8
000074c379dd500e  pop rsi
000074c379dd500f  pop rdi
000074c379dd5010  pop rdx
000074c379dd5011  pop rcx
000074c379dd5012  pop rax
000074c379dd5013  add rsp, 0x08
000074c379dd5017  jmp 0x000074C379DD025D
000074c379dd501c  sub rsp, 0x08
000074c379dd5020  push rax
000074c379dd5021  push rcx
000074c379dd5022  push rdx
000074c379dd5023  push rdi
000074c379dd5024  push rsi
000074c379dd5025  push r8
000074c379dd5027  push r9
000074c379dd5029  push r10
000074c379dd502b  push r11
000074c379dd502d  sub rsp, 0xF0
000074c379dd5034  vmovaps [rsp], xmm0
000074c379dd5039  vmovaps [rsp+0x10], xmm1
000074c379dd503f  vmovaps [rsp+0x20], xmm2
000074c379dd5045  vmovaps [rsp+0x30], xmm3
000074c379dd504b  vmovaps [rsp+0x40], xmm4
000074c379dd5051  vmovaps [rsp+0x50], xmm5
000074c379dd5057  vmovaps [rsp+0x60], xmm6
000074c379dd505d  vmovaps [rsp+0x70], xmm7
000074c379dd5063  vmovaps [rsp+0x80], xmm8
000074c379dd506c  vmovaps [rsp+0x90], xmm9
000074c379dd5075  vmovaps [rsp+0xA0], xmm11
000074c379dd507e  vmovaps [rsp+0xB0], xmm12
000074c379dd5087  vmovaps [rsp+0xC0], xmm13
000074c379dd5090  vmovaps [rsp+0xD0], xmm14
000074c379dd5099  vmovaps [rsp+0xE0], xmm15
000074c379dd50a2  sub rsp, 0x30
000074c379dd50a6  movaps [rsp], xmm10
000074c379dd50ab  movaps [rsp+0x10], xmm11
000074c379dd50b1  movaps [rsp+0x20], xmm15
000074c379dd50b7  lea rdi, [rsp]
000074c379dd50bb  mov esi, 0x00
000074c379dd50c0  mov rax, 0x56321ABA4530
000074c379dd50ca  call rax
000074c379dd50cc  movaps xmm10, [rsp]
000074c379dd50d1  add rsp, 0x30
000074c379dd50d5  vmovaps xmm0, [rsp]
000074c379dd50da  vmovaps xmm1, [rsp+0x10]
000074c379dd50e0  vmovaps xmm2, [rsp+0x20]
000074c379dd50e6  vmovaps xmm3, [rsp+0x30]
000074c379dd50ec  vmovaps xmm4, [rsp+0x40]
000074c379dd50f2  vmovaps xmm5, [rsp+0x50]
000074c379dd50f8  vmovaps xmm6, [rsp+0x60]
000074c379dd50fe  vmovaps xmm7, [rsp+0x70]
000074c379dd5104  vmovaps xmm8, [rsp+0x80]
000074c379dd510d  vmovaps xmm9, [rsp+0x90]
000074c379dd5116  vmovaps xmm11, [rsp+0xA0]
000074c379dd511f  vmovaps xmm12, [rsp+0xB0]
000074c379dd5128  vmovaps xmm13, [rsp+0xC0]
000074c379dd5131  vmovaps xmm14, [rsp+0xD0]
000074c379dd513a  vmovaps xmm15, [rsp+0xE0]
000074c379dd5143  add rsp, 0xF0
000074c379dd514a  pop r11
000074c379dd514c  pop r10
000074c379dd514e  pop r9
000074c379dd5150  pop r8
000074c379dd5152  pop rsi
000074c379dd5153  pop rdi
000074c379dd5154  pop rdx
000074c379dd5155  pop rcx
000074c379dd5156  pop rax
000074c379dd5157  add rsp, 0x08
000074c379dd515b  jmp 0x000074C379DD028B
000074c379dd5160  sub rsp, 0x08
000074c379dd5164  push rax
000074c379dd5165  push rcx
000074c379dd5166  push rdx
000074c379dd5167  push rdi
000074c379dd5168  push rsi
000074c379dd5169  push r8
000074c379dd516b  push r9
000074c379dd516d  push r10
000074c379dd516f  push r11
000074c379dd5171  sub rsp, 0xF0
000074c379dd5178  vmovaps [rsp], xmm0
000074c379dd517d  vmovaps [rsp+0x10], xmm1
000074c379dd5183  vmovaps [rsp+0x20], xmm2
000074c379dd5189  vmovaps [rsp+0x30], xmm3
000074c379dd518f  vmovaps [rsp+0x40], xmm4
000074c379dd5195  vmovaps [rsp+0x50], xmm5
000074c379dd519b  vmovaps [rsp+0x60], xmm6
000074c379dd51a1  vmovaps [rsp+0x70], xmm7
000074c379dd51a7  vmovaps [rsp+0x80], xmm8
000074c379dd51b0  vmovaps [rsp+0x90], xmm9
000074c379dd51b9  vmovaps [rsp+0xA0], xmm10
000074c379dd51c2  vmovaps [rsp+0xB0], xmm12
000074c379dd51cb  vmovaps [rsp+0xC0], xmm13
000074c379dd51d4  vmovaps [rsp+0xD0], xmm14
000074c379dd51dd  vmovaps [rsp+0xE0], xmm15
000074c379dd51e6  sub rsp, 0x30
000074c379dd51ea  movaps [rsp], xmm11
000074c379dd51ef  movaps [rsp+0x10], xmm12
000074c379dd51f5  movaps [rsp+0x20], xmm15
000074c379dd51fb  lea rdi, [rsp]
000074c379dd51ff  mov esi, 0x00
000074c379dd5204  mov rax, 0x56321ABA4530
000074c379dd520e  call rax
000074c379dd5210  movaps xmm11, [rsp]
000074c379dd5215  add rsp, 0x30
000074c379dd5219  vmovaps xmm0, [rsp]
000074c379dd521e  vmovaps xmm1, [rsp+0x10]
000074c379dd5224  vmovaps xmm2, [rsp+0x20]
000074c379dd522a  vmovaps xmm3, [rsp+0x30]
000074c379dd5230  vmovaps xmm4, [rsp+0x40]
000074c379dd5236  vmovaps xmm5, [rsp+0x50]
000074c379dd523c  vmovaps xmm6, [rsp+0x60]
000074c379dd5242  vmovaps xmm7, [rsp+0x70]
000074c379dd5248  vmovaps xmm8, [rsp+0x80]
000074c379dd5251  vmovaps xmm9, [rsp+0x90]
000074c379dd525a  vmovaps xmm10, [rsp+0xA0]
000074c379dd5263  vmovaps xmm12, [rsp+0xB0]
000074c379dd526c  vmovaps xmm13, [rsp+0xC0]
000074c379dd5275  vmovaps xmm14, [rsp+0xD0]
000074c379dd527e  vmovaps xmm15, [rsp+0xE0]
000074c379dd5287  add rsp, 0xF0
000074c379dd528e  pop r11
000074c379dd5290  pop r10
000074c379dd5292  pop r9
000074c379dd5294  pop r8
000074c379dd5296  pop rsi
000074c379dd5297  pop rdi
000074c379dd5298  pop rdx
000074c379dd5299  pop rcx
000074c379dd529a  pop rax
000074c379dd529b  add rsp, 0x08
000074c379dd529f  jmp 0x000074C379DD02B9
000074c379dd52a4  sub rsp, 0x08
000074c379dd52a8  push rax
000074c379dd52a9  push rcx
000074c379dd52aa  push rdx
000074c379dd52ab  push rdi
000074c379dd52ac  push rsi
000074c379dd52ad  push r8
000074c379dd52af  push r9
000074c379dd52b1  push r10
000074c379dd52b3  push r11
000074c379dd52b5  sub rsp, 0xF0
000074c379dd52bc  vmovaps [rsp], xmm0
000074c379dd52c1  vmovaps [rsp+0x10], xmm1
000074c379dd52c7  vmovaps [rsp+0x20], xmm2
000074c379dd52cd  vmovaps [rsp+0x30], xmm3
000074c379dd52d3  vmovaps [rsp+0x40], xmm4
000074c379dd52d9  vmovaps [rsp+0x50], xmm5
000074c379dd52df  vmovaps [rsp+0x60], xmm6
000074c379dd52e5  vmovaps [rsp+0x70], xmm7
000074c379dd52eb  vmovaps [rsp+0x80], xmm8
000074c379dd52f4  vmovaps [rsp+0x90], xmm9
000074c379dd52fd  vmovaps [rsp+0xA0], xmm10
000074c379dd5306  vmovaps [rsp+0xB0], xmm11
000074c379dd530f  vmovaps [rsp+0xC0], xmm12
000074c379dd5318  vmovaps [rsp+0xD0], xmm13
000074c379dd5321  vmovaps [rsp+0xE0], xmm14
000074c379dd532a  sub rsp, 0x30
000074c379dd532e  movaps [rsp], xmm15
000074c379dd5333  movaps [rsp+0x10], xmm13
000074c379dd5339  movaps [rsp+0x20], xmm9
000074c379dd533f  lea rdi, [rsp]
000074c379dd5343  mov esi, 0x00
000074c379dd5348  mov rax, 0x56321ABA4530
000074c379dd5352  call rax
000074c379dd5354  movaps xmm15, [rsp]
000074c379dd5359  add rsp, 0x30
000074c379dd535d  vmovaps xmm0, [rsp]
000074c379dd5362  vmovaps xmm1, [rsp+0x10]
000074c379dd5368  vmovaps xmm2, [rsp+0x20]
000074c379dd536e  vmovaps xmm3, [rsp+0x30]
000074c379dd5374  vmovaps xmm4, [rsp+0x40]
000074c379dd537a  vmovaps xmm5, [rsp+0x50]
000074c379dd5380  vmovaps xmm6, [rsp+0x60]
000074c379dd5386  vmovaps xmm7, [rsp+0x70]
000074c379dd538c  vmovaps xmm8, [rsp+0x80]
000074c379dd5395  vmovaps xmm9, [rsp+0x90]
000074c379dd539e  vmovaps xmm10, [rsp+0xA0]
000074c379dd53a7  vmovaps xmm11, [rsp+0xB0]
000074c379dd53b0  vmovaps xmm12, [rsp+0xC0]
000074c379dd53b9  vmovaps xmm13, [rsp+0xD0]
000074c379dd53c2  vmovaps xmm14, [rsp+0xE0]
000074c379dd53cb  add rsp, 0xF0
000074c379dd53d2  pop r11
000074c379dd53d4  pop r10
000074c379dd53d6  pop r9
000074c379dd53d8  pop r8
000074c379dd53da  pop rsi
000074c379dd53db  pop rdi
000074c379dd53dc  pop rdx
000074c379dd53dd  pop rcx
000074c379dd53de  pop rax
000074c379dd53df  add rsp, 0x08
000074c379dd53e3  jmp 0x000074C379DD02D4
000074c379dd53e8  sub rsp, 0x08
000074c379dd53ec  push rax
000074c379dd53ed  push rcx
000074c379dd53ee  push rdx
000074c379dd53ef  push rdi
000074c379dd53f0  push rsi
000074c379dd53f1  push r8
000074c379dd53f3  push r9
000074c379dd53f5  push r10
000074c379dd53f7  push r11
000074c379dd53f9  sub rsp, 0xF0
000074c379dd5400  vmovaps [rsp], xmm0
000074c379dd5405  vmovaps [rsp+0x10], xmm1
000074c379dd540b  vmovaps [rsp+0x20], xmm2
000074c379dd5411  vmovaps [rsp+0x30], xmm3
000074c379dd5417  vmovaps [rsp+0x40], xmm4
000074c379dd541d  vmovaps [rsp+0x50], xmm5
000074c379dd5423  vmovaps [rsp+0x60], xmm6
000074c379dd5429  vmovaps [rsp+0x70], xmm7
000074c379dd542f  vmovaps [rsp+0x80], xmm8
000074c379dd5438  vmovaps [rsp+0x90], xmm9
000074c379dd5441  vmovaps [rsp+0xA0], xmm10
000074c379dd544a  vmovaps [rsp+0xB0], xmm11
000074c379dd5453  vmovaps [rsp+0xC0], xmm12
000074c379dd545c  vmovaps [rsp+0xD0], xmm14
000074c379dd5465  vmovaps [rsp+0xE0], xmm15
000074c379dd546e  sub rsp, 0x30
000074c379dd5472  movaps [rsp], xmm13
000074c379dd5477  movaps [rsp+0x10], xmm8
000074c379dd547d  movaps [rsp+0x20], xmm14
000074c379dd5483  lea rdi, [rsp]
000074c379dd5487  mov esi, 0x00
000074c379dd548c  mov rax, 0x56321ABA4530
000074c379dd5496  call rax
000074c379dd5498  movaps xmm13, [rsp]
000074c379dd549d  add rsp, 0x30
000074c379dd54a1  vmovaps xmm0, [rsp]
000074c379dd54a6  vmovaps xmm1, [rsp+0x10]
000074c379dd54ac  vmovaps xmm2, [rsp+0x20]
000074c379dd54b2  vmovaps xmm3, [rsp+0x30]
000074c379dd54b8  vmovaps xmm4, [rsp+0x40]
000074c379dd54be  vmovaps xmm5, [rsp+0x50]
000074c379dd54c4  vmovaps xmm6, [rsp+0x60]
000074c379dd54ca  vmovaps xmm7, [rsp+0x70]
000074c379dd54d0  vmovaps xmm8, [rsp+0x80]
000074c379dd54d9  vmovaps xmm9, [rsp+0x90]
000074c379dd54e2  vmovaps xmm10, [rsp+0xA0]
000074c379dd54eb  vmovaps xmm11, [rsp+0xB0]
000074c379dd54f4  vmovaps xmm12, [rsp+0xC0]
000074c379dd54fd  vmovaps xmm14, [rsp+0xD0]
000074c379dd5506  vmovaps xmm15, [rsp+0xE0]
000074c379dd550f  add rsp, 0xF0
000074c379dd5516  pop r11
000074c379dd5518  pop r10
000074c379dd551a  pop r9
000074c379dd551c  pop r8
000074c379dd551e  pop rsi
000074c379dd551f  pop rdi
000074c379dd5520  pop rdx
000074c379dd5521  pop rcx
000074c379dd5522  pop rax
000074c379dd5523  add rsp, 0x08
000074c379dd5527  jmp 0x000074C379DD02F7
000074c379dd552c  sub rsp, 0x08
000074c379dd5530  push rax
000074c379dd5531  push rcx
000074c379dd5532  push rdx
000074c379dd5533  push rdi
000074c379dd5534  push rsi
000074c379dd5535  push r8
000074c379dd5537  push r9
000074c379dd5539  push r10
000074c379dd553b  push r11
000074c379dd553d  sub rsp, 0xF0
000074c379dd5544  vmovaps [rsp], xmm0
000074c379dd5549  vmovaps [rsp+0x10], xmm1
000074c379dd554f  vmovaps [rsp+0x20], xmm2
000074c379dd5555  vmovaps [rsp+0x30], xmm3
000074c379dd555b  vmovaps [rsp+0x40], xmm4
000074c379dd5561  vmovaps [rsp+0x50], xmm5
000074c379dd5567  vmovaps [rsp+0x60], xmm6
000074c379dd556d  vmovaps [rsp+0x70], xmm7
000074c379dd5573  vmovaps [rsp+0x80], xmm8
000074c379dd557c  vmovaps [rsp+0x90], xmm9
000074c379dd5585  vmovaps [rsp+0xA0], xmm10
000074c379dd558e  vmovaps [rsp+0xB0], xmm11
000074c379dd5597  vmovaps [rsp+0xC0], xmm12
000074c379dd55a0  vmovaps [rsp+0xD0], xmm13
000074c379dd55a9  vmovaps [rsp+0xE0], xmm15
000074c379dd55b2  sub rsp, 0x30
000074c379dd55b6  movaps [rsp], xmm14
000074c379dd55bb  movaps [rsp+0x10], xmm1
000074c379dd55c0  movaps [rsp+0x20], xmm10
000074c379dd55c6  lea rdi, [rsp]
000074c379dd55ca  mov esi, 0x00
000074c379dd55cf  mov rax, 0x56321ABA4530
000074c379dd55d9  call rax
000074c379dd55db  movaps xmm14, [rsp]
000074c379dd55e0  add rsp, 0x30
000074c379dd55e4  vmovaps xmm0, [rsp]
000074c379dd55e9  vmovaps xmm1, [rsp+0x10]
000074c379dd55ef  vmovaps xmm2, [rsp+0x20]
000074c379dd55f5  vmovaps xmm3, [rsp+0x30]
000074c379dd55fb  vmovaps xmm4, [rsp+0x40]
000074c379dd5601  vmovaps xmm5, [rsp+0x50]
000074c379dd5607  vmovaps xmm6, [rsp+0x60]
000074c379dd560d  vmovaps xmm7, [rsp+0x70]
000074c379dd5613  vmovaps xmm8, [rsp+0x80]
000074c379dd561c  vmovaps xmm9, [rsp+0x90]
000074c379dd5625  vmovaps xmm10, [rsp+0xA0]
000074c379dd562e  vmovaps xmm11, [rsp+0xB0]
000074c379dd5637  vmovaps xmm12, [rsp+0xC0]
000074c379dd5640  vmovaps xmm13, [rsp+0xD0]
000074c379dd5649  vmovaps xmm15, [rsp+0xE0]
000074c379dd5652  add rsp, 0xF0
000074c379dd5659  pop r11
000074c379dd565b  pop r10
000074c379dd565d  pop r9
000074c379dd565f  pop r8
000074c379dd5661  pop rsi
000074c379dd5662  pop rdi
000074c379dd5663  pop rdx
000074c379dd5664  pop rcx
000074c379dd5665  pop rax
000074c379dd5666  add rsp, 0x08
000074c379dd566a  jmp 0x000074C379DD031A
000074c379dd566f  sub rsp, 0x08
000074c379dd5673  push rax
000074c379dd5674  push rcx
000074c379dd5675  push rdx
000074c379dd5676  push rdi
000074c379dd5677  push rsi
000074c379dd5678  push r8
000074c379dd567a  push r9
000074c379dd567c  push r10
000074c379dd567e  push r11
000074c379dd5680  sub rsp, 0xF0
000074c379dd5687  vmovaps [rsp], xmm0
000074c379dd568c  vmovaps [rsp+0x10], xmm2
000074c379dd5692  vmovaps [rsp+0x20], xmm3
000074c379dd5698  vmovaps [rsp+0x30], xmm4
000074c379dd569e  vmovaps [rsp+0x40], xmm5
000074c379dd56a4  vmovaps [rsp+0x50], xmm6
000074c379dd56aa  vmovaps [rsp+0x60], xmm7
000074c379dd56b0  vmovaps [rsp+0x70], xmm8
000074c379dd56b6  vmovaps [rsp+0x80], xmm9
000074c379dd56bf  vmovaps [rsp+0x90], xmm10
000074c379dd56c8  vmovaps [rsp+0xA0], xmm11
000074c379dd56d1  vmovaps [rsp+0xB0], xmm12
000074c379dd56da  vmovaps [rsp+0xC0], xmm13
000074c379dd56e3  vmovaps [rsp+0xD0], xmm14
000074c379dd56ec  vmovaps [rsp+0xE0], xmm15
000074c379dd56f5  sub rsp, 0x30
000074c379dd56f9  movaps [rsp], xmm1
000074c379dd56fd  movaps [rsp+0x10], xmm7
000074c379dd5702  movaps [rsp+0x20], xmm11
000074c379dd5708  lea rdi, [rsp]
000074c379dd570c  mov esi, 0x00
000074c379dd5711  mov rax, 0x56321ABA4530
000074c379dd571b  call rax
000074c379dd571d  movaps xmm1, [rsp]
000074c379dd5721  add rsp, 0x30
000074c379dd5725  vmovaps xmm0, [rsp]
000074c379dd572a  vmovaps xmm2, [rsp+0x10]
000074c379dd5730  vmovaps xmm3, [rsp+0x20]
000074c379dd5736  vmovaps xmm4, [rsp+0x30]
000074c379dd573c  vmovaps xmm5, [rsp+0x40]
000074c379dd5742  vmovaps xmm6, [rsp+0x50]
000074c379dd5748  vmovaps xmm7, [rsp+0x60]
000074c379dd574e  vmovaps xmm8, [rsp+0x70]
000074c379dd5754  vmovaps xmm9, [rsp+0x80]
000074c379dd575d  vmovaps xmm10, [rsp+0x90]
000074c379dd5766  vmovaps xmm11, [rsp+0xA0]
000074c379dd576f  vmovaps xmm12, [rsp+0xB0]
000074c379dd5778  vmovaps xmm13, [rsp+0xC0]
000074c379dd5781  vmovaps xmm14, [rsp+0xD0]
000074c379dd578a  vmovaps xmm15, [rsp+0xE0]
000074c379dd5793  add rsp, 0xF0
000074c379dd579a  pop r11
000074c379dd579c  pop r10
000074c379dd579e  pop r9
000074c379dd57a0  pop r8
000074c379dd57a2  pop rsi
000074c379dd57a3  pop rdi
000074c379dd57a4  pop rdx
000074c379dd57a5  pop rcx
000074c379dd57a6  pop rax
000074c379dd57a7  add rsp, 0x08
000074c379dd57ab  jmp 0x000074C379DD033B
000074c379dd57b0  call 0x000074C379C0E880
000074c379dd57b5  jmp 0x000074C379DD034E
000074c379dd57ba  call 0x000074C379C0C380
000074c379dd57bf  jmp 0x000074C379DD0359
000074c379dd57c4  call 0x000074C379C0D600
000074c379dd57c9  jmp 0x000074C379DD0364
000074c379dd57ce  call 0x000074C379BFF540
000074c379dd57d3  jmp 0x000074C379DD036F
000074c379dd57d8  int3
000074c379dd57d9  nop [rax], eax
000074c379dd57e0  mov rax, [r15+0x40]
000074c379dd57e4  mov r14, [r15+0x58]
000074c379dd57e8  lea r12, [rax+r14*1]
000074c379dd57ec  movaps xmm1, [r15+0x1D0]
000074c379dd57f4  vmovaps [rsp+0x10], xmm1
000074c379dd57fa  vmovaps xmm15, [rsp+0x10]
000074c379dd5800  por xmm1, xmm15
000074c379dd5805  movaps xmm14, [r15+0x1A0]
000074c379dd580d  vmovaps [rsp+0x10], xmm14
000074c379dd5813  vmovaps xmm13, [rsp+0x10]
000074c379dd5819  por xmm14, xmm13
000074c379dd581e  lea rax, [r12+0x30]
000074c379dd5823  mov r11, [r13+rax*1]
000074c379dd5828  lea rax, [r12+0x38]
000074c379dd582d  mov r10, [r13+rax*1]
000074c379dd5832  movq xmm13, r11
000074c379dd5837  movq xmm12, r10
000074c379dd583c  movq xmm13, xmm13
000074c379dd5841  vmovaps [rsp+0x10], xmm13
000074c379dd5847  movq xmm13, xmm13
000074c379dd584c  movaps [r15+0x130], xmm13
000074c379dd5854  movq xmm12, xmm12
000074c379dd5859  vmovaps [rsp+0x20], xmm12
000074c379dd585f  movq xmm12, xmm12
000074c379dd5864  movaps [r15+0x280], xmm12
000074c379dd586c  movaps xmm13, [r15+0x270]
000074c379dd5874  vmovaps [rsp+0x30], xmm13
000074c379dd587a  vmovaps xmm12, [rsp+0x30]
000074c379dd5880  por xmm13, xmm12
000074c379dd5885  lea rax, [r12+0x20]
000074c379dd588a  mov r11, [r13+rax*1]
000074c379dd588f  lea rax, [r12+0x28]
000074c379dd5894  mov r10, [r13+rax*1]
000074c379dd5899  movq xmm12, r11
000074c379dd589e  movq xmm11, r10
000074c379dd58a3  movq xmm12, xmm12
000074c379dd58a8  vmovaps [rsp+0x30], xmm12
000074c379dd58ae  movq xmm12, xmm12
000074c379dd58b3  movaps [r15+0x150], xmm12
000074c379dd58bb  movq xmm11, xmm11
000074c379dd58c0  vmovaps [rsp+0x40], xmm11
000074c379dd58c6  movq xmm11, xmm11
000074c379dd58cb  movaps [r15+0x140], xmm11
000074c379dd58d3  lea rax, [r12+0x10]
000074c379dd58d8  mov r11, [r13+rax*1]
000074c379dd58dd  lea rax, [r12+0x18]
000074c379dd58e2  mov r10, [r13+rax*1]
000074c379dd58e7  movq xmm12, r11
000074c379dd58ec  movq xmm11, r10
000074c379dd58f1  movq xmm12, xmm12
000074c379dd58f6  vmovaps [rsp+0x50], xmm12
000074c379dd58fc  movq xmm12, xmm12
000074c379dd5901  movaps [r15+0x170], xmm12
000074c379dd5909  movq xmm11, xmm11
000074c379dd590e  vmovaps [rsp+0x60], xmm11
000074c379dd5914  movq xmm11, xmm11
000074c379dd5919  movaps [r15+0x160], xmm11
000074c379dd5921  mov rax, [r13+r12*1]
000074c379dd5926  vmovq xmm12, rax
000074c379dd592b  vpbroadcastq xmm12, xmm12
000074c379dd5930  lea rax, [r12+0x08]
000074c379dd5935  mov r12, [r13+rax*1]
000074c379dd593a  movq xmm11, r12
000074c379dd593f  movaps [r15+0x230], xmm11
000074c379dd5947  mov rax, [r15+0xF8]
000074c379dd594e  lea r12, [rax+0x50]
000074c379dd5952  movups xmm11, [r13+r12*1]
000074c379dd5958  lea r12, [rax+0x60]
000074c379dd595c  movups xmm10, [r13+r12*1]
000074c379dd5962  lea r12, [rax+0x30]
000074c379dd5966  movups xmm9, [r13+r12*1]
000074c379dd596c  mov r12, [r15+0x50]
000074c379dd5970  lea r11, [r12+r14*1]
000074c379dd5974  mov [r15+0x60], r11
000074c379dd5978  lea r12, [r14+0x40]
000074c379dd597c  mov [r15+0x58], r12
000074c379dd5980  movaps xmm8, xmm12
000074c379dd5984  mulpd xmm8, xmm15
000074c379dd5989  vcmppd xmm7, xmm8, xmm8, 0x03
000074c379dd598f  ptest xmm7, xmm7
000074c379dd5994  jnz 0x000074C379DD67B7
000074c379dd599a  movq xmm15, qword ptr [r15+0x230]
000074c379dd59a3  vmovaps [rsp+0x70], xmm15
000074c379dd59a9  vpermilpd xmm15, xmm15, 0x00
000074c379dd59af  movaps xmm7, xmm9
000074c379dd59b3  mulpd xmm7, xmm15
000074c379dd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000074c379dd59bd  ptest xmm6, xmm6
000074c379dd59c2  jnz 0x000074C379DD68FB
000074c379dd59c8  vxorps xmm15, xmm15, xmm15
000074c379dd59cd  vpbroadcastq xmm15, xmm15
000074c379dd59d2  movaps xmm9, xmm12
000074c379dd59d6  mulpd xmm9, xmm10
000074c379dd59db  vcmppd xmm6, xmm9, xmm9, 0x03
000074c379dd59e1  ptest xmm6, xmm6
000074c379dd59e6  jnz 0x000074C379DD6A3D
000074c379dd59ec  movaps xmm10, xmm12
000074c379dd59f0  mulpd xmm10, xmm11
000074c379dd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000074c379dd59fb  ptest xmm6, xmm6
000074c379dd5a00  jnz 0x000074C379DD6B81
000074c379dd5a06  movaps xmm11, [r15+0x1F0]
000074c379dd5a0e  movaps xmm6, xmm12
000074c379dd5a12  mulpd xmm6, xmm11
000074c379dd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000074c379dd5a1c  ptest xmm5, xmm5
000074c379dd5a21  jnz 0x000074C379DD6CC5
000074c379dd5a27  movaps xmm12, [r15+0x2A0]
000074c379dd5a2f  vmovaps [rsp+0x80], xmm12
000074c379dd5a38  vmovaps xmm11, [rsp+0x80]
000074c379dd5a41  por xmm12, xmm11
000074c379dd5a46  movaps xmm11, [r15+0x250]
000074c379dd5a4e  vmovaps [rsp+0x80], xmm11
000074c379dd5a57  vmovaps xmm5, [rsp+0x80]
000074c379dd5a60  por xmm11, xmm5
000074c379dd5a65  vmovaps xmm4, [rsp+0x70]
000074c379dd5a6b  vpermilpd xmm4, xmm4, 0x00
000074c379dd5a71  movaps xmm3, xmm5
000074c379dd5a74  mulpd xmm3, xmm4
000074c379dd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000074c379dd5a7d  ptest xmm2, xmm2
000074c379dd5a82  jnz 0x000074C379DD6E07
000074c379dd5a88  mov [rsp+0x80], rax
000074c379dd5a90  xor eax, eax
000074c379dd5a92  mov r14d, 0x200
000074c379dd5a98  cmp r12, r14
000074c379dd5a9b  cmc
000074c379dd5a9c  lahf
000074c379dd5a9d  seto al
000074c379dd5aa0  mov [r15+0x108], eax
000074c379dd5aa7  movaps xmm5, xmm8
000074c379dd5aab  addpd xmm5, xmm15
000074c379dd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000074c379dd5ab5  ptest xmm4, xmm4
000074c379dd5aba  jnz 0x000074C379DD6F47
000074c379dd5ac0  movaps xmm8, [r15+0x1B0]
000074c379dd5ac8  movaps xmm4, xmm9
000074c379dd5acc  addpd xmm4, xmm8
000074c379dd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000074c379dd5ad6  ptest xmm2, xmm2
000074c379dd5adb  jnz 0x000074C379DD7089
000074c379dd5ae1  movaps xmm9, xmm10
000074c379dd5ae5  addpd xmm9, xmm8
000074c379dd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000074c379dd5af0  ptest xmm2, xmm2
000074c379dd5af5  jnz 0x000074C379DD71CB
000074c379dd5afb  movaps xmm10, [r15+0x2F0]
000074c379dd5b03  vmovaps [rsp+0x90], xmm10
000074c379dd5b0c  vmovaps xmm8, [rsp+0x90]
000074c379dd5b15  por xmm10, xmm8
000074c379dd5b1a  movaps xmm8, [r15+0x2E0]
000074c379dd5b22  vmovaps [rsp+0x90], xmm8
000074c379dd5b2b  vmovaps xmm2, [rsp+0x90]
000074c379dd5b34  por xmm8, xmm2
000074c379dd5b39  movaps xmm2, [r15+0x2D0]
000074c379dd5b41  vmovaps [rsp+0x90], xmm2
000074c379dd5b4a  vmovaps [rsp+0xA0], xmm1
000074c379dd5b53  vmovaps xmm1, [rsp+0x90]
000074c379dd5b5c  por xmm2, xmm1
000074c379dd5b60  movaps xmm1, [r15+0x200]
000074c379dd5b68  vmovaps [rsp+0x90], xmm1
000074c379dd5b71  vmovaps [rsp+0xB0], xmm15
000074c379dd5b7a  vmovaps xmm15, [rsp+0x90]
000074c379dd5b83  por xmm1, xmm15
000074c379dd5b88  movaps xmm15, [r15+0x1C0]
000074c379dd5b90  vmovaps [rsp+0x90], xmm15
000074c379dd5b99  vmovaps [rsp+0xC0], xmm1
000074c379dd5ba2  vmovaps xmm1, [rsp+0x90]
000074c379dd5bab  por xmm15, xmm1
000074c379dd5bb0  movaps xmm1, [r15+0x190]
000074c379dd5bb8  vmovaps [rsp+0x90], xmm1
000074c379dd5bc1  vmovaps [rsp+0xD0], xmm15
000074c379dd5bca  vmovaps xmm15, [rsp+0x90]
000074c379dd5bd3  por xmm1, xmm15
000074c379dd5bd8  movaps xmm15, [r15+0x300]
000074c379dd5be0  vmovaps [rsp+0x90], xmm15
000074c379dd5be9  vmovaps [rsp+0xE0], xmm1
000074c379dd5bf2  vmovaps xmm1, [rsp+0x90]
000074c379dd5bfb  por xmm15, xmm1
000074c379dd5c00  mov rax, [rsp+0x80]
000074c379dd5c08  lea r14, [rax+0xA0]
000074c379dd5c0f  movups xmm1, [r13+r14*1]
000074c379dd5c15  lea r14, [rax+0xB0]
000074c379dd5c1c  vmovaps [rsp+0x80], xmm1
000074c379dd5c25  movups xmm1, [r13+r14*1]
000074c379dd5c2b  vmovaps [rsp+0x90], xmm1
000074c379dd5c34  vmovaps [rsp+0xF0], xmm15
000074c379dd5c3d  vmovaps xmm15, [rsp+0xB0]
000074c379dd5c46  vmovaps [rsp+0xB0], xmm14
000074c379dd5c4f  movaps xmm1, xmm6
000074c379dd5c52  addpd xmm1, xmm15
000074c379dd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000074c379dd5c5c  ptest xmm14, xmm14
000074c379dd5c62  jnz 0x000074C379DD7323
000074c379dd5c68  lea r14, [rax+0xF0]
000074c379dd5c6f  movups xmm15, [r13+r14*1]
000074c379dd5c75  movaps xmm14, xmm4
000074c379dd5c79  addpd xmm14, xmm3
000074c379dd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000074c379dd5c84  ptest xmm6, xmm6
000074c379dd5c89  jnz 0x000074C379DD746E
000074c379dd5c8f  movaps xmm6, xmm9
000074c379dd5c93  addpd xmm6, xmm7
000074c379dd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000074c379dd5c9c  ptest xmm4, xmm4
000074c379dd5ca1  jnz 0x000074C379DD75B0
000074c379dd5ca7  vmovaps xmm9, [rsp+0x70]
000074c379dd5cad  vpermilpd xmm9, xmm9, 0x00
000074c379dd5cb3  vmovaps xmm4, [rsp+0x90]
000074c379dd5cbc  movaps xmm7, xmm4
000074c379dd5cbf  mulpd xmm7, xmm9
000074c379dd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000074c379dd5cc9  ptest xmm3, xmm3
000074c379dd5cce  jnz 0x000074C379DD76F1
000074c379dd5cd4  vmovaps xmm9, [rsp+0x50]
000074c379dd5cda  vpermilpd xmm9, xmm9, 0x00
000074c379dd5ce0  movaps xmm4, xmm15
000074c379dd5ce4  mulpd xmm4, xmm9
000074c379dd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000074c379dd5cee  ptest xmm3, xmm3
000074c379dd5cf3  jnz 0x000074C379DD7832
000074c379dd5cf9  lea r14, [rax+0xE0]
000074c379dd5d00  movups xmm15, [r13+r14*1]
000074c379dd5d06  vmovaps xmm9, [rsp+0x70]
000074c379dd5d0c  vpermilpd xmm9, xmm9, 0x00
000074c379dd5d12  vmovaps [rsp+0x70], xmm1
000074c379dd5d18  vmovaps xmm1, [rsp+0x80]
000074c379dd5d21  vmovaps [rsp+0x80], xmm15
000074c379dd5d2a  movaps xmm3, xmm1
000074c379dd5d2d  mulpd xmm3, xmm9
000074c379dd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000074c379dd5d37  ptest xmm15, xmm15
000074c379dd5d3d  jnz 0x000074C379DD797E
000074c379dd5d43  vmovaps xmm1, [rsp+0xF0]
000074c379dd5d4c  vmovaps xmm15, [rsp+0xF0]
000074c379dd5d55  por xmm1, xmm15
000074c379dd5d5a  movaps [r15+0x300], xmm1
000074c379dd5d62  vmovaps xmm15, [rsp+0xE0]
000074c379dd5d6b  vmovaps xmm9, [rsp+0xE0]
000074c379dd5d74  por xmm15, xmm9
000074c379dd5d79  movaps [r15+0x190], xmm15
000074c379dd5d81  vmovaps xmm9, [rsp+0x50]
000074c379dd5d87  vpermilpd xmm9, xmm9, 0x00
000074c379dd5d8d  vmovaps [rsp+0x90], xmm1
000074c379dd5d96  vmovaps [rsp+0xE0], xmm15
000074c379dd5d9f  vmovaps xmm15, [rsp+0x80]
000074c379dd5da8  vmovaps [rsp+0x80], xmm14
000074c379dd5db1  movaps xmm1, xmm15
000074c379dd5db5  mulpd xmm1, xmm9
000074c379dd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000074c379dd5dbf  ptest xmm14, xmm14
000074c379dd5dc5  jnz 0x000074C379DD7ABF
000074c379dd5dcb  lea r14, [rax+0x90]
000074c379dd5dd2  movups xmm15, [r13+r14*1]
000074c379dd5dd8  vmovaps xmm14, [rsp+0xD0]
000074c379dd5de1  vmovaps xmm9, [rsp+0xD0]
000074c379dd5dea  por xmm14, xmm9
000074c379dd5def  movaps [r15+0x1C0], xmm14
000074c379dd5df7  vmovaps xmm9, [rsp+0xC0]
000074c379dd5e00  vmovaps [rsp+0xD0], xmm1
000074c379dd5e09  vmovaps xmm1, [rsp+0xC0]
000074c379dd5e12  por xmm9, xmm1
000074c379dd5e17  movaps [r15+0x200], xmm9
000074c379dd5e1f  vmovaps [rsp+0xC0], xmm2
000074c379dd5e28  vmovaps xmm1, [rsp+0xC0]
000074c379dd5e31  por xmm2, xmm1
000074c379dd5e35  movaps [r15+0x2D0], xmm2
000074c379dd5e3d  vmovaps [rsp+0xC0], xmm8
000074c379dd5e46  vmovaps xmm1, [rsp+0xC0]
000074c379dd5e4f  por xmm8, xmm1
000074c379dd5e54  movaps [r15+0x2E0], xmm8
000074c379dd5e5c  vmovaps [rsp+0xC0], xmm15
000074c379dd5e65  movaps xmm1, xmm5
000074c379dd5e68  addpd xmm1, xmm7
000074c379dd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000074c379dd5e71  ptest xmm15, xmm15
000074c379dd5e77  jnz 0x000074C379DD7C0B
000074c379dd5e7d  vmovaps xmm15, [rsp+0x50]
000074c379dd5e83  vpermilpd xmm15, xmm15, 0x00
000074c379dd5e89  vmovaps xmm5, [rsp+0xC0]
000074c379dd5e92  vmovaps [rsp+0xC0], xmm1
000074c379dd5e9b  movaps xmm7, xmm5
000074c379dd5e9e  mulpd xmm7, xmm15
000074c379dd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000074c379dd5ea8  ptest xmm1, xmm1
000074c379dd5ead  jnz 0x000074C379DD7D4B
000074c379dd5eb3  lea r14, [rax+0x80]
000074c379dd5eba  movups xmm1, [r13+r14*1]
000074c379dd5ec0  vmovaps xmm5, [rsp+0x70]
000074c379dd5ec6  vmovaps [rsp+0x70], xmm1
000074c379dd5ecc  movaps xmm15, xmm5
000074c379dd5ed0  addpd xmm15, xmm3
000074c379dd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000074c379dd5edb  ptest xmm1, xmm1
000074c379dd5ee0  jnz 0x000074C379DD7E96
000074c379dd5ee6  vmovaps xmm5, [rsp+0x80]
000074c379dd5eef  movaps xmm1, xmm5
000074c379dd5ef2  addpd xmm1, xmm4
000074c379dd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000074c379dd5efb  ptest xmm3, xmm3
000074c379dd5f00  jnz 0x000074C379DD7FD8
000074c379dd5f06  vmovaps [rsp+0x80], xmm10
000074c379dd5f0f  vmovaps xmm5, [rsp+0x80]
000074c379dd5f18  por xmm10, xmm5
000074c379dd5f1d  movaps [r15+0x2F0], xmm10
000074c379dd5f25  vmovaps xmm5, [rsp+0x50]
000074c379dd5f2b  vpermilpd xmm5, xmm5, 0x00
000074c379dd5f31  vmovaps xmm3, [rsp+0x70]
000074c379dd5f37  vmovaps [rsp+0x50], xmm1
000074c379dd5f3d  movaps xmm4, xmm3
000074c379dd5f40  mulpd xmm4, xmm5
000074c379dd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000074c379dd5f49  ptest xmm1, xmm1
000074c379dd5f4e  jnz 0x000074C379DD8118
000074c379dd5f54  lea r14, [rax+0xD0]
000074c379dd5f5b  movups xmm1, [r13+r14*1]
000074c379dd5f61  vmovaps xmm3, [rsp+0xD0]
000074c379dd5f6a  vmovaps [rsp+0x70], xmm1
000074c379dd5f70  movaps xmm5, xmm6
000074c379dd5f73  addpd xmm5, xmm3
000074c379dd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000074c379dd5f7c  ptest xmm1, xmm1
000074c379dd5f81  jnz 0x000074C379DD8262
000074c379dd5f87  vmovaps xmm1, [rsp+0x60]
000074c379dd5f8d  vpermilpd xmm1, xmm1, 0x00
000074c379dd5f93  movaps xmm6, xmm9
000074c379dd5f97  mulpd xmm6, xmm1
000074c379dd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000074c379dd5fa0  ptest xmm3, xmm3
000074c379dd5fa5  jnz 0x000074C379DD83A2
000074c379dd5fab  movaps [r15+0x260], xmm6
000074c379dd5fb3  vxorps xmm1, xmm1, xmm1
000074c379dd5fb7  vpbroadcastq xmm1, xmm1
000074c379dd5fbc  movaps [r15+0x1B0], xmm1
000074c379dd5fc4  vmovaps xmm1, [rsp+0x60]
000074c379dd5fca  vpermilpd xmm1, xmm1, 0x00
000074c379dd5fd0  vmovaps xmm3, [rsp+0x70]
000074c379dd5fd6  vmovaps [rsp+0x70], xmm15
000074c379dd5fdc  movaps xmm9, xmm3
000074c379dd5fe0  mulpd xmm9, xmm1
000074c379dd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000074c379dd5feb  ptest xmm15, xmm15
000074c379dd5ff1  jnz 0x000074C379DD84E3
000074c379dd5ff7  lea r14, [rax+0xC0]
000074c379dd5ffe  movups xmm1, [r13+r14*1]
000074c379dd6004  vmovaps xmm3, [rsp+0xC0]
000074c379dd600d  vmovaps [rsp+0x80], xmm1
000074c379dd6016  movaps xmm15, xmm3
000074c379dd601a  addpd xmm15, xmm7
000074c379dd601f  vcmppd xmm1, xmm15, xmm15, 0x03
000074c379dd6025  ptest xmm1, xmm1
000074c379dd602a  jnz 0x000074C379DD862F
000074c379dd6030  vmovaps [rsp+0xC0], xmm13
000074c379dd6039  vmovaps xmm1, [rsp+0xC0]
000074c379dd6042  por xmm13, xmm1
000074c379dd6047  movaps [r15+0x270], xmm13
000074c379dd604f  vmovaps xmm1, [rsp+0xB0]
000074c379dd6058  vmovaps xmm7, [rsp+0xB0]
000074c379dd6061  por xmm1, xmm7
000074c379dd6065  movaps [r15+0x1A0], xmm1
000074c379dd606d  vmovaps xmm1, [rsp+0x60]
000074c379dd6073  vpermilpd xmm1, xmm1, 0x00
000074c379dd6079  vmovaps [rsp+0xB0], xmm1
000074c379dd6082  vmovaps xmm1, [rsp+0x80]
000074c379dd608b  vmovaps [rsp+0x80], xmm15
000074c379dd6094  vmovaps xmm15, [rsp+0xB0]
000074c379dd609d  vmovaps [rsp+0xB0], xmm14
000074c379dd60a6  movaps xmm3, xmm1
000074c379dd60a9  mulpd xmm3, xmm15
000074c379dd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000074c379dd60b3  ptest xmm14, xmm14
000074c379dd60b9  jnz 0x000074C379DD8771
000074c379dd60bf  lea r14, [rax+0x20]
000074c379dd60c3  movups xmm1, [r13+r14*1]
000074c379dd60c9  movaps [r15+0x110], xmm1
000074c379dd60d1  vmovaps xmm14, [rsp+0x70]
000074c379dd60d7  vmovaps [rsp+0x70], xmm1
000074c379dd60dd  movaps xmm15, xmm14
000074c379dd60e1  addpd xmm15, xmm4
000074c379dd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000074c379dd60ec  ptest xmm1, xmm1
000074c379dd60f1  jnz 0x000074C379DD88BC
000074c379dd60f7  vmovaps xmm1, [rsp+0x60]
000074c379dd60fd  vpermilpd xmm1, xmm1, 0x00
000074c379dd6103  movaps xmm14, xmm2
000074c379dd6107  mulpd xmm14, xmm1
000074c379dd610c  vcmppd xmm4, xmm14, xmm14, 0x03
000074c379dd6112  ptest xmm4, xmm4
000074c379dd6117  jnz 0x000074C379DD89FF
000074c379dd611d  vmovaps xmm4, [rsp+0x50]
000074c379dd6123  movaps xmm1, xmm4
000074c379dd6126  addpd xmm1, xmm9
000074c379dd612b  vcmppd xmm2, xmm1, xmm1, 0x03
000074c379dd6130  ptest xmm2, xmm2
000074c379dd6135  jnz 0x000074C379DD8B41
000074c379dd613b  vmovaps xmm9, [rsp+0x30]
000074c379dd6141  vpermilpd xmm9, xmm9, 0x00
000074c379dd6147  vmovaps xmm2, [rsp+0x70]
000074c379dd614d  vmovaps [rsp+0x50], xmm1
000074c379dd6153  movaps xmm4, xmm2
000074c379dd6156  mulpd xmm4, xmm9
000074c379dd615b  vcmppd xmm1, xmm4, xmm4, 0x03
000074c379dd6160  ptest xmm1, xmm1
000074c379dd6165  jnz 0x000074C379DD8C82
000074c379dd616b  vmovaps xmm1, [rsp+0x30]
000074c379dd6171  vpermilpd xmm1, xmm1, 0x00
000074c379dd6177  vmovaps xmm2, [rsp+0x90]
000074c379dd6180  vmovaps [rsp+0x60], xmm15
000074c379dd6186  movaps xmm9, xmm2
000074c379dd618a  mulpd xmm9, xmm1
000074c379dd618f  vcmppd xmm15, xmm9, xmm9, 0x03
000074c379dd6195  ptest xmm15, xmm15
000074c379dd619b  jnz 0x000074C379DD8DC3
000074c379dd61a1  vmovaps xmm15, [rsp+0x80]
000074c379dd61aa  movaps xmm1, xmm15
000074c379dd61ae  addpd xmm1, xmm6
000074c379dd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000074c379dd61b7  ptest xmm2, xmm2
000074c379dd61bc  jnz 0x000074C379DD8F05
000074c379dd61c2  movaps xmm15, xmm5
000074c379dd61c6  addpd xmm15, xmm3
000074c379dd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000074c379dd61d1  ptest xmm6, xmm6
000074c379dd61d6  jnz 0x000074C379DD9046
000074c379dd61dc  vmovaps xmm6, [rsp+0x30]
000074c379dd61e2  vpermilpd xmm6, xmm6, 0x00
000074c379dd61e8  movaps xmm5, xmm8
000074c379dd61ec  mulpd xmm5, xmm6
000074c379dd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000074c379dd61f5  ptest xmm3, xmm3
000074c379dd61fa  jnz 0x000074C379DD9188
000074c379dd6200  vmovaps xmm8, [rsp+0x30]
000074c379dd6206  vpermilpd xmm8, xmm8, 0x00
000074c379dd620c  movaps xmm6, xmm10
000074c379dd6210  mulpd xmm6, xmm8
000074c379dd6215  vcmppd xmm3, xmm6, xmm6, 0x03
000074c379dd621a  ptest xmm3, xmm3
000074c379dd621f  jnz 0x000074C379DD92C9
000074c379dd6225  vmovaps xmm8, [rsp+0x60]
000074c379dd622b  movaps xmm10, xmm8
000074c379dd622f  addpd xmm10, xmm14
000074c379dd6234  vcmppd xmm3, xmm10, xmm10, 0x03
000074c379dd623a  ptest xmm3, xmm3
000074c379dd623f  jnz 0x000074C379DD940B
000074c379dd6245  vmovaps xmm8, [rsp+0x50]
000074c379dd624b  movaps xmm14, xmm8
000074c379dd624f  addpd xmm14, xmm4
000074c379dd6254  vcmppd xmm3, xmm14, xmm14, 0x03
000074c379dd625a  ptest xmm3, xmm3
000074c379dd625f  jnz 0x000074C379DD954F
000074c379dd6265  vmovaps xmm8, [rsp+0x40]
000074c379dd626b  vpermilpd xmm8, xmm8, 0x00
000074c379dd6271  movaps xmm4, xmm13
000074c379dd6275  mulpd xmm4, xmm8
000074c379dd627a  vcmppd xmm3, xmm4, xmm4, 0x03
000074c379dd627f  ptest xmm3, xmm3
000074c379dd6284  jnz 0x000074C379DD9692
000074c379dd628a  movaps xmm13, xmm15
000074c379dd628e  addpd xmm13, xmm9
000074c379dd6293  vcmppd xmm8, xmm13, xmm13, 0x03
000074c379dd6299  ptest xmm8, xmm8
000074c379dd629f  jnz 0x000074C379DD97D4
000074c379dd62a5  movaps xmm15, xmm1
000074c379dd62a9  addpd xmm15, xmm5
000074c379dd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000074c379dd62b4  ptest xmm9, xmm9
000074c379dd62ba  jnz 0x000074C379DD9918
000074c379dd62c0  vmovaps [rsp+0x30], xmm11
000074c379dd62c6  vmovaps xmm1, [rsp+0x30]
000074c379dd62cc  por xmm11, xmm1
000074c379dd62d1  movaps [r15+0x250], xmm11
000074c379dd62d9  vmovaps [rsp+0x30], xmm12
000074c379dd62df  vmovaps xmm1, [rsp+0x30]
000074c379dd62e5  por xmm12, xmm1
000074c379dd62ea  movaps [r15+0x2A0], xmm12
000074c379dd62f2  vmovaps xmm1, [rsp+0xA0]
000074c379dd62fb  vmovaps xmm11, [rsp+0xA0]
000074c379dd6304  por xmm1, xmm11
000074c379dd6309  movaps [r15+0x1D0], xmm1
000074c379dd6311  lea r14, [rax+0x40]
000074c379dd6315  movups xmm1, [r13+r14*1]
000074c379dd631b  movaps [r15+0x2C0], xmm1
000074c379dd6323  vmovaps xmm11, [rsp+0x40]
000074c379dd6329  vpermilpd xmm11, xmm11, 0x00
000074c379dd632f  vmovaps xmm8, [rsp+0xE0]
000074c379dd6338  movaps xmm9, xmm8
000074c379dd633c  mulpd xmm9, xmm11
000074c379dd6341  vcmppd xmm5, xmm9, xmm9, 0x03
000074c379dd6347  ptest xmm5, xmm5
000074c379dd634c  jnz 0x000074C379DD9A64
000074c379dd6352  movaps xmm11, xmm10
000074c379dd6356  addpd xmm11, xmm6
000074c379dd635b  vcmppd xmm8, xmm11, xmm11, 0x03
000074c379dd6361  ptest xmm8, xmm8
000074c379dd6367  jnz 0x000074C379DD9BA8
000074c379dd636d  movaps xmm10, xmm14
000074c379dd6371  addpd xmm10, xmm4
000074c379dd6376  vcmppd xmm8, xmm10, xmm10, 0x03
000074c379dd637c  ptest xmm8, xmm8
000074c379dd6382  jnz 0x000074C379DD9CEB
000074c379dd6388  vmovaps xmm14, [rsp+0x40]
000074c379dd638e  vpermilpd xmm14, xmm14, 0x00
000074c379dd6394  movaps xmm8, xmm1
000074c379dd6398  mulpd xmm8, xmm14
000074c379dd639d  vcmppd xmm6, xmm8, xmm8, 0x03
000074c379dd63a3  ptest xmm6, xmm6
000074c379dd63a8  jnz 0x000074C379DD9E2E
000074c379dd63ae  movaps xmm1, [r15+0x2B0]
000074c379dd63b6  vmovaps xmm14, [rsp+0x40]
000074c379dd63bc  vpermilpd xmm14, xmm14, 0x00
000074c379dd63c2  movaps xmm6, xmm1
000074c379dd63c5  mulpd xmm6, xmm14
000074c379dd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000074c379dd63cf  ptest xmm5, xmm5
000074c379dd63d4  jnz 0x000074C379DD9F71
000074c379dd63da  vmovaps xmm1, [rsp+0x10]
000074c379dd63e0  vpermilpd xmm1, xmm1, 0x00
000074c379dd63e6  movaps xmm14, xmm12
000074c379dd63ea  mulpd xmm14, xmm1
000074c379dd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000074c379dd63f5  ptest xmm5, xmm5
000074c379dd63fa  jnz 0x000074C379DDA0B2
000074c379dd6400  movaps xmm1, xmm13
000074c379dd6404  addpd xmm1, xmm9
000074c379dd6409  vcmppd xmm12, xmm1, xmm1, 0x03
000074c379dd640e  ptest xmm12, xmm12
000074c379dd6414  jnz 0x000074C379DDA1F5
000074c379dd641a  vmovaps xmm13, [rsp+0x10]
000074c379dd6420  vpermilpd xmm13, xmm13, 0x00
000074c379dd6426  movaps xmm12, xmm7
000074c379dd642a  mulpd xmm12, xmm13
000074c379dd642f  vcmppd xmm9, xmm12, xmm12, 0x03
000074c379dd6435  ptest xmm9, xmm9
000074c379dd643b  jnz 0x000074C379DDA337
000074c379dd6441  movaps xmm13, xmm15
000074c379dd6445  addpd xmm13, xmm8
000074c379dd644a  vcmppd xmm9, xmm13, xmm13, 0x03
000074c379dd6450  ptest xmm9, xmm9
000074c379dd6456  jnz 0x000074C379DDA47A
000074c379dd645c  movaps xmm15, [r15+0x290]
000074c379dd6464  vmovaps xmm9, [rsp+0x10]
000074c379dd646a  vpermilpd xmm9, xmm9, 0x00
000074c379dd6470  movaps xmm8, xmm15
000074c379dd6474  mulpd xmm8, xmm9
000074c379dd6479  vcmppd xmm7, xmm8, xmm8, 0x03
000074c379dd647f  ptest xmm7, xmm7
000074c379dd6484  jnz 0x000074C379DDA5BE
000074c379dd648a  movaps xmm15, xmm11
000074c379dd648e  addpd xmm15, xmm6
000074c379dd6493  vcmppd xmm9, xmm15, xmm15, 0x03
000074c379dd6499  ptest xmm9, xmm9
000074c379dd649f  jnz 0x000074C379DDA702
000074c379dd64a5  movaps xmm11, [r15+0x1E0]
000074c379dd64ad  vmovaps xmm9, [rsp+0x10]
000074c379dd64b3  vpermilpd xmm9, xmm9, 0x00
000074c379dd64b9  movaps xmm7, xmm11
000074c379dd64bd  mulpd xmm7, xmm9
000074c379dd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000074c379dd64c7  ptest xmm6, xmm6
000074c379dd64cc  jnz 0x000074C379DDA845
000074c379dd64d2  movaps xmm11, xmm10
000074c379dd64d6  addpd xmm11, xmm14
000074c379dd64db  vcmppd xmm9, xmm11, xmm11, 0x03
000074c379dd64e1  ptest xmm9, xmm9
000074c379dd64e7  jnz 0x000074C379DDA987
000074c379dd64ed  lea r14, [rax+0x70]
000074c379dd64f1  movups xmm14, [r13+r14*1]
000074c379dd64f7  movaps [r15+0x240], xmm14
000074c379dd64ff  movaps xmm10, xmm1
000074c379dd6503  addpd xmm10, xmm12
000074c379dd6508  vcmppd xmm9, xmm10, xmm10, 0x03
000074c379dd650e  ptest xmm9, xmm9
000074c379dd6514  jnz 0x000074C379DDAAD5
000074c379dd651a  movaps [r15+0x170], xmm10
000074c379dd6522  vmovaps xmm1, [rsp+0x20]
000074c379dd6528  vpermilpd xmm1, xmm1, 0x00
000074c379dd652e  movaps xmm12, xmm14
000074c379dd6532  mulpd xmm12, xmm1
000074c379dd6537  vcmppd xmm9, xmm12, xmm12, 0x03
000074c379dd653d  ptest xmm9, xmm9
000074c379dd6543  jnz 0x000074C379DDAC18
000074c379dd6549  vmovaps xmm1, [rsp+0x20]
000074c379dd654f  vpermilpd xmm1, xmm1, 0x00
000074c379dd6555  vmovaps xmm9, [rsp+0xB0]
000074c379dd655e  movaps xmm14, xmm9
000074c379dd6562  mulpd xmm14, xmm1
000074c379dd6567  vcmppd xmm6, xmm14, xmm14, 0x03
000074c379dd656d  ptest xmm6, xmm6
000074c379dd6572  jnz 0x000074C379DDAD5B
000074c379dd6578  movaps [r15+0x180], xmm14
000074c379dd6580  movaps xmm1, xmm13
000074c379dd6584  addpd xmm1, xmm8
000074c379dd6589  vcmppd xmm9, xmm1, xmm1, 0x03
000074c379dd658e  ptest xmm9, xmm9
000074c379dd6594  jnz 0x000074C379DDAE9E
000074c379dd659a  movaps [r15+0x210], xmm1
000074c379dd65a2  movups xmm13, [r13+rax*1]
000074c379dd65a8  lea r14, [rax+0x10]
000074c379dd65ac  movups xmm9, [r13+r14*1]
000074c379dd65b2  movaps [r15+0x230], xmm9
000074c379dd65ba  movaps xmm8, xmm15
000074c379dd65be  addpd xmm8, xmm7
000074c379dd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000074c379dd65c9  ptest xmm6, xmm6
000074c379dd65ce  jnz 0x000074C379DDAFF4
000074c379dd65d4  movaps [r15+0x130], xmm8
000074c379dd65dc  vmovaps xmm15, [rsp+0x20]
000074c379dd65e2  vpermilpd xmm15, xmm15, 0x00
000074c379dd65e8  movaps xmm7, xmm9
000074c379dd65ec  mulpd xmm7, xmm15
000074c379dd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000074c379dd65f6  ptest xmm6, xmm6
000074c379dd65fb  jnz 0x000074C379DDB137
000074c379dd6601  movaps [r15+0x220], xmm7
000074c379dd6609  vmovaps xmm15, [rsp+0x20]
000074c379dd660f  vpermilpd xmm15, xmm15, 0x00
000074c379dd6615  movaps xmm9, xmm13
000074c379dd6619  mulpd xmm9, xmm15
000074c379dd661e  vcmppd xmm6, xmm9, xmm9, 0x03
000074c379dd6624  ptest xmm6, xmm6
000074c379dd6629  jnz 0x000074C379DDB279
000074c379dd662f  movaps xmm15, xmm11
000074c379dd6633  addpd xmm15, xmm12
000074c379dd6638  vcmppd xmm13, xmm15, xmm15, 0x03
000074c379dd663e  ptest xmm13, xmm13
000074c379dd6644  jnz 0x000074C379DDB3BD
000074c379dd664a  movaps [r15+0x140], xmm15
000074c379dd6652  movaps xmm13, xmm10
000074c379dd6656  addpd xmm13, xmm14
000074c379dd665b  vcmppd xmm12, xmm13, xmm13, 0x03
000074c379dd6661  ptest xmm12, xmm12
000074c379dd6667  jnz 0x000074C379DDB501
000074c379dd666d  movaps [r15+0x150], xmm13
000074c379dd6675  movaps xmm14, xmm1
000074c379dd6679  addpd xmm14, xmm7
000074c379dd667e  vcmppd xmm12, xmm14, xmm14, 0x03
000074c379dd6684  ptest xmm12, xmm12
000074c379dd668a  jnz 0x000074C379DDB645
000074c379dd6690  movaps [r15+0x160], xmm14
000074c379dd6698  movaps xmm1, xmm8
000074c379dd669c  addpd xmm1, xmm9
000074c379dd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000074c379dd66a6  ptest xmm12, xmm12
000074c379dd66ac  jnz 0x000074C379DDB787
000074c379dd66b2  movaps [r15+0x120], xmm1
000074c379dd66ba  movups [r13+r11*1], xmm15
000074c379dd66c0  lea rax, [r11+0x10]
000074c379dd66c4  movups [r13+rax*1], xmm13
000074c379dd66ca  lea rax, [r11+0x20]
000074c379dd66ce  movups [r13+rax*1], xmm14
000074c379dd66d4  lea rax, [r11+0x30]
000074c379dd66d8  movups [r13+rax*1], xmm1
000074c379dd66de  mov eax, [r15+0x108]
000074c379dd66e5  sahf
000074c379dd66e6  jnz 0x000074C379DD6718
000074c379dd66e8  cmp dword ptr [r15+0x318], 0x00
000074c379dd66f0  jz 0x000074C379DDB900
000074c379dd66f6  nop [rax+rax*1], ax
000074c379dd66ff  nop [rax+rax*1], eax
000074c379dd6707  mov eax, 0x410444
000074c379dd670c  mov [r15+0x100], rax
000074c379dd6713  jmp 0x000074C379BFE110
000074c379dd6718  cmp dword ptr [r15+0x318], 0x00
000074c379dd6720  jz 0x000074C379DD57E0
000074c379dd6726  nop [rax+rax*1], ax
000074c379dd672f  nop [rax+rax*1], eax
000074c379dd6737  mov eax, 0x410278
000074c379dd673c  mov [r15+0x100], rax
000074c379dd6743  jmp 0x000074C379BFE110
000074c379dd6748  int3
000074c379dd6749  call 0x000074C379C0A4B0
000074c379dd674e  jmp 0x000074C379DD5828
000074c379dd6753  call 0x000074C379C09240
000074c379dd6758  jmp 0x000074C379DD5832
000074c379dd675d  call 0x000074C379C0A4B0
000074c379dd6762  jmp 0x000074C379DD588F
000074c379dd6767  call 0x000074C379C09240
000074c379dd676c  jmp 0x000074C379DD5899
000074c379dd6771  call 0x000074C379C0A4B0
000074c379dd6776  jmp 0x000074C379DD58DD
000074c379dd677b  call 0x000074C379C09240
000074c379dd6780  jmp 0x000074C379DD58E7
000074c379dd6785  call 0x000074C379CB47C0
000074c379dd678a  jmp 0x000074C379DD5926
000074c379dd678f  call 0x000074C379C0B720
000074c379dd6794  jmp 0x000074C379DD593A
000074c379dd6799  call 0x000074C379CBFC30
000074c379dd679e  jmp 0x000074C379DD5958
000074c379dd67a3  call 0x000074C379CBE9C0
000074c379dd67a8  jmp 0x000074C379DD5962
000074c379dd67ad  call 0x000074C379CBD750
000074c379dd67b2  jmp 0x000074C379DD596C
000074c379dd67b7  sub rsp, 0x08
000074c379dd67bb  push rax
000074c379dd67bc  push rcx
000074c379dd67bd  push rdx
000074c379dd67be  push rdi
000074c379dd67bf  push rsi
000074c379dd67c0  push r8
000074c379dd67c2  push r9
000074c379dd67c4  push r10
000074c379dd67c6  push r11
000074c379dd67c8  sub rsp, 0xF0
000074c379dd67cf  vmovaps [rsp], xmm0
000074c379dd67d4  vmovaps [rsp+0x10], xmm1
000074c379dd67da  vmovaps [rsp+0x20], xmm2
000074c379dd67e0  vmovaps [rsp+0x30], xmm3
000074c379dd67e6  vmovaps [rsp+0x40], xmm4
000074c379dd67ec  vmovaps [rsp+0x50], xmm5
000074c379dd67f2  vmovaps [rsp+0x60], xmm6
000074c379dd67f8  vmovaps [rsp+0x70], xmm7
000074c379dd67fe  vmovaps [rsp+0x80], xmm9
000074c379dd6807  vmovaps [rsp+0x90], xmm10
000074c379dd6810  vmovaps [rsp+0xA0], xmm11
000074c379dd6819  vmovaps [rsp+0xB0], xmm12
000074c379dd6822  vmovaps [rsp+0xC0], xmm13
000074c379dd682b  vmovaps [rsp+0xD0], xmm14
000074c379dd6834  vmovaps [rsp+0xE0], xmm15
000074c379dd683d  sub rsp, 0x30
000074c379dd6841  movaps [rsp], xmm8
000074c379dd6846  movaps [rsp+0x10], xmm12
000074c379dd684c  movaps [rsp+0x20], xmm15
000074c379dd6852  lea rdi, [rsp]
000074c379dd6856  mov esi, 0x00
000074c379dd685b  mov rax, 0x56321ABA4530
000074c379dd6865  call rax
000074c379dd6867  movaps xmm8, [rsp]
000074c379dd686c  add rsp, 0x30
000074c379dd6870  vmovaps xmm0, [rsp]
000074c379dd6875  vmovaps xmm1, [rsp+0x10]
000074c379dd687b  vmovaps xmm2, [rsp+0x20]
000074c379dd6881  vmovaps xmm3, [rsp+0x30]
000074c379dd6887  vmovaps xmm4, [rsp+0x40]
000074c379dd688d  vmovaps xmm5, [rsp+0x50]
000074c379dd6893  vmovaps xmm6, [rsp+0x60]
000074c379dd6899  vmovaps xmm7, [rsp+0x70]
000074c379dd689f  vmovaps xmm9, [rsp+0x80]
000074c379dd68a8  vmovaps xmm10, [rsp+0x90]
000074c379dd68b1  vmovaps xmm11, [rsp+0xA0]
000074c379dd68ba  vmovaps xmm12, [rsp+0xB0]
000074c379dd68c3  vmovaps xmm13, [rsp+0xC0]
000074c379dd68cc  vmovaps xmm14, [rsp+0xD0]
000074c379dd68d5  vmovaps xmm15, [rsp+0xE0]
000074c379dd68de  add rsp, 0xF0
000074c379dd68e5  pop r11
000074c379dd68e7  pop r10
000074c379dd68e9  pop r9
000074c379dd68eb  pop r8
000074c379dd68ed  pop rsi
000074c379dd68ee  pop rdi
000074c379dd68ef  pop rdx
000074c379dd68f0  pop rcx
000074c379dd68f1  pop rax
000074c379dd68f2  add rsp, 0x08
000074c379dd68f6  jmp 0x000074C379DD599A
000074c379dd68fb  sub rsp, 0x08
000074c379dd68ff  push rax
000074c379dd6900  push rcx
000074c379dd6901  push rdx
000074c379dd6902  push rdi
000074c379dd6903  push rsi
000074c379dd6904  push r8
000074c379dd6906  push r9
000074c379dd6908  push r10
000074c379dd690a  push r11
000074c379dd690c  sub rsp, 0xF0
000074c379dd6913  vmovaps [rsp], xmm0
000074c379dd6918  vmovaps [rsp+0x10], xmm1
000074c379dd691e  vmovaps [rsp+0x20], xmm2
000074c379dd6924  vmovaps [rsp+0x30], xmm3
000074c379dd692a  vmovaps [rsp+0x40], xmm4
000074c379dd6930  vmovaps [rsp+0x50], xmm5
000074c379dd6936  vmovaps [rsp+0x60], xmm6
000074c379dd693c  vmovaps [rsp+0x70], xmm8
000074c379dd6942  vmovaps [rsp+0x80], xmm9
000074c379dd694b  vmovaps [rsp+0x90], xmm10
000074c379dd6954  vmovaps [rsp+0xA0], xmm11
000074c379dd695d  vmovaps [rsp+0xB0], xmm12
000074c379dd6966  vmovaps [rsp+0xC0], xmm13
000074c379dd696f  vmovaps [rsp+0xD0], xmm14
000074c379dd6978  vmovaps [rsp+0xE0], xmm15
000074c379dd6981  sub rsp, 0x30
000074c379dd6985  movaps [rsp], xmm7
000074c379dd6989  movaps [rsp+0x10], xmm9
000074c379dd698f  movaps [rsp+0x20], xmm15
000074c379dd6995  lea rdi, [rsp]
000074c379dd6999  mov esi, 0x00
000074c379dd699e  mov rax, 0x56321ABA4530
000074c379dd69a8  call rax
000074c379dd69aa  movaps xmm7, [rsp]
000074c379dd69ae  add rsp, 0x30
000074c379dd69b2  vmovaps xmm0, [rsp]
000074c379dd69b7  vmovaps xmm1, [rsp+0x10]
000074c379dd69bd  vmovaps xmm2, [rsp+0x20]
000074c379dd69c3  vmovaps xmm3, [rsp+0x30]
000074c379dd69c9  vmovaps xmm4, [rsp+0x40]
000074c379dd69cf  vmovaps xmm5, [rsp+0x50]
000074c379dd69d5  vmovaps xmm6, [rsp+0x60]
000074c379dd69db  vmovaps xmm8, [rsp+0x70]
000074c379dd69e1  vmovaps xmm9, [rsp+0x80]
000074c379dd69ea  vmovaps xmm10, [rsp+0x90]
000074c379dd69f3  vmovaps xmm11, [rsp+0xA0]
000074c379dd69fc  vmovaps xmm12, [rsp+0xB0]
000074c379dd6a05  vmovaps xmm13, [rsp+0xC0]
000074c379dd6a0e  vmovaps xmm14, [rsp+0xD0]
000074c379dd6a17  vmovaps xmm15, [rsp+0xE0]
000074c379dd6a20  add rsp, 0xF0
000074c379dd6a27  pop r11
000074c379dd6a29  pop r10
000074c379dd6a2b  pop r9
000074c379dd6a2d  pop r8
000074c379dd6a2f  pop rsi
000074c379dd6a30  pop rdi
000074c379dd6a31  pop rdx
000074c379dd6a32  pop rcx
000074c379dd6a33  pop rax
000074c379dd6a34  add rsp, 0x08
000074c379dd6a38  jmp 0x000074C379DD59C8
000074c379dd6a3d  sub rsp, 0x08
000074c379dd6a41  push rax
000074c379dd6a42  push rcx
000074c379dd6a43  push rdx
000074c379dd6a44  push rdi
000074c379dd6a45  push rsi
000074c379dd6a46  push r8
000074c379dd6a48  push r9
000074c379dd6a4a  push r10
000074c379dd6a4c  push r11
000074c379dd6a4e  sub rsp, 0xF0
000074c379dd6a55  vmovaps [rsp], xmm0
000074c379dd6a5a  vmovaps [rsp+0x10], xmm1
000074c379dd6a60  vmovaps [rsp+0x20], xmm2
000074c379dd6a66  vmovaps [rsp+0x30], xmm3
000074c379dd6a6c  vmovaps [rsp+0x40], xmm4
000074c379dd6a72  vmovaps [rsp+0x50], xmm5
000074c379dd6a78  vmovaps [rsp+0x60], xmm6
000074c379dd6a7e  vmovaps [rsp+0x70], xmm7
000074c379dd6a84  vmovaps [rsp+0x80], xmm8
000074c379dd6a8d  vmovaps [rsp+0x90], xmm10
000074c379dd6a96  vmovaps [rsp+0xA0], xmm11
000074c379dd6a9f  vmovaps [rsp+0xB0], xmm12
000074c379dd6aa8  vmovaps [rsp+0xC0], xmm13
000074c379dd6ab1  vmovaps [rsp+0xD0], xmm14
000074c379dd6aba  vmovaps [rsp+0xE0], xmm15
000074c379dd6ac3  sub rsp, 0x30
000074c379dd6ac7  movaps [rsp], xmm9
000074c379dd6acc  movaps [rsp+0x10], xmm12
000074c379dd6ad2  movaps [rsp+0x20], xmm10
000074c379dd6ad8  lea rdi, [rsp]
000074c379dd6adc  mov esi, 0x00
000074c379dd6ae1  mov rax, 0x56321ABA4530
000074c379dd6aeb  call rax
000074c379dd6aed  movaps xmm9, [rsp]
000074c379dd6af2  add rsp, 0x30
000074c379dd6af6  vmovaps xmm0, [rsp]
000074c379dd6afb  vmovaps xmm1, [rsp+0x10]
000074c379dd6b01  vmovaps xmm2, [rsp+0x20]
000074c379dd6b07  vmovaps xmm3, [rsp+0x30]
000074c379dd6b0d  vmovaps xmm4, [rsp+0x40]
000074c379dd6b13  vmovaps xmm5, [rsp+0x50]
000074c379dd6b19  vmovaps xmm6, [rsp+0x60]
000074c379dd6b1f  vmovaps xmm7, [rsp+0x70]
000074c379dd6b25  vmovaps xmm8, [rsp+0x80]
000074c379dd6b2e  vmovaps xmm10, [rsp+0x90]
000074c379dd6b37  vmovaps xmm11, [rsp+0xA0]
000074c379dd6b40  vmovaps xmm12, [rsp+0xB0]
000074c379dd6b49  vmovaps xmm13, [rsp+0xC0]
000074c379dd6b52  vmovaps xmm14, [rsp+0xD0]
000074c379dd6b5b  vmovaps xmm15, [rsp+0xE0]
000074c379dd6b64  add rsp, 0xF0
000074c379dd6b6b  pop r11
000074c379dd6b6d  pop r10
000074c379dd6b6f  pop r9
000074c379dd6b71  pop r8
000074c379dd6b73  pop rsi
000074c379dd6b74  pop rdi
000074c379dd6b75  pop rdx
000074c379dd6b76  pop rcx
000074c379dd6b77  pop rax
000074c379dd6b78  add rsp, 0x08
000074c379dd6b7c  jmp 0x000074C379DD59EC
000074c379dd6b81  sub rsp, 0x08
000074c379dd6b85  push rax
000074c379dd6b86  push rcx
000074c379dd6b87  push rdx
000074c379dd6b88  push rdi
000074c379dd6b89  push rsi
000074c379dd6b8a  push r8
000074c379dd6b8c  push r9
000074c379dd6b8e  push r10
000074c379dd6b90  push r11
000074c379dd6b92  sub rsp, 0xF0
000074c379dd6b99  vmovaps [rsp], xmm0
000074c379dd6b9e  vmovaps [rsp+0x10], xmm1
000074c379dd6ba4  vmovaps [rsp+0x20], xmm2
000074c379dd6baa  vmovaps [rsp+0x30], xmm3
000074c379dd6bb0  vmovaps [rsp+0x40], xmm4
000074c379dd6bb6  vmovaps [rsp+0x50], xmm5
000074c379dd6bbc  vmovaps [rsp+0x60], xmm6
000074c379dd6bc2  vmovaps [rsp+0x70], xmm7
000074c379dd6bc8  vmovaps [rsp+0x80], xmm8
000074c379dd6bd1  vmovaps [rsp+0x90], xmm9
000074c379dd6bda  vmovaps [rsp+0xA0], xmm11
000074c379dd6be3  vmovaps [rsp+0xB0], xmm12
000074c379dd6bec  vmovaps [rsp+0xC0], xmm13
000074c379dd6bf5  vmovaps [rsp+0xD0], xmm14
000074c379dd6bfe  vmovaps [rsp+0xE0], xmm15
000074c379dd6c07  sub rsp, 0x30
000074c379dd6c0b  movaps [rsp], xmm10
000074c379dd6c10  movaps [rsp+0x10], xmm12
000074c379dd6c16  movaps [rsp+0x20], xmm11
000074c379dd6c1c  lea rdi, [rsp]
000074c379dd6c20  mov esi, 0x00
000074c379dd6c25  mov rax, 0x56321ABA4530
000074c379dd6c2f  call rax
000074c379dd6c31  movaps xmm10, [rsp]
000074c379dd6c36  add rsp, 0x30
000074c379dd6c3a  vmovaps xmm0, [rsp]
000074c379dd6c3f  vmovaps xmm1, [rsp+0x10]
000074c379dd6c45  vmovaps xmm2, [rsp+0x20]
000074c379dd6c4b  vmovaps xmm3, [rsp+0x30]
000074c379dd6c51  vmovaps xmm4, [rsp+0x40]
000074c379dd6c57  vmovaps xmm5, [rsp+0x50]
000074c379dd6c5d  vmovaps xmm6, [rsp+0x60]
000074c379dd6c63  vmovaps xmm7, [rsp+0x70]
000074c379dd6c69  vmovaps xmm8, [rsp+0x80]
000074c379dd6c72  vmovaps xmm9, [rsp+0x90]
000074c379dd6c7b  vmovaps xmm11, [rsp+0xA0]
000074c379dd6c84  vmovaps xmm12, [rsp+0xB0]
000074c379dd6c8d  vmovaps xmm13, [rsp+0xC0]
000074c379dd6c96  vmovaps xmm14, [rsp+0xD0]
000074c379dd6c9f  vmovaps xmm15, [rsp+0xE0]
000074c379dd6ca8  add rsp, 0xF0
000074c379dd6caf  pop r11
000074c379dd6cb1  pop r10
000074c379dd6cb3  pop r9
000074c379dd6cb5  pop r8
000074c379dd6cb7  pop rsi
000074c379dd6cb8  pop rdi
000074c379dd6cb9  pop rdx
000074c379dd6cba  pop rcx
000074c379dd6cbb  pop rax
000074c379dd6cbc  add rsp, 0x08
000074c379dd6cc0  jmp 0x000074C379DD5A06
000074c379dd6cc5  sub rsp, 0x08
000074c379dd6cc9  push rax
000074c379dd6cca  push rcx
000074c379dd6ccb  push rdx
000074c379dd6ccc  push rdi
000074c379dd6ccd  push rsi
000074c379dd6cce  push r8
000074c379dd6cd0  push r9
000074c379dd6cd2  push r10
000074c379dd6cd4  push r11
000074c379dd6cd6  sub rsp, 0xF0
000074c379dd6cdd  vmovaps [rsp], xmm0
000074c379dd6ce2  vmovaps [rsp+0x10], xmm1
000074c379dd6ce8  vmovaps [rsp+0x20], xmm2
000074c379dd6cee  vmovaps [rsp+0x30], xmm3
000074c379dd6cf4  vmovaps [rsp+0x40], xmm4
000074c379dd6cfa  vmovaps [rsp+0x50], xmm5
000074c379dd6d00  vmovaps [rsp+0x60], xmm7
000074c379dd6d06  vmovaps [rsp+0x70], xmm8
000074c379dd6d0c  vmovaps [rsp+0x80], xmm9
000074c379dd6d15  vmovaps [rsp+0x90], xmm10
000074c379dd6d1e  vmovaps [rsp+0xA0], xmm11
000074c379dd6d27  vmovaps [rsp+0xB0], xmm12
000074c379dd6d30  vmovaps [rsp+0xC0], xmm13
000074c379dd6d39  vmovaps [rsp+0xD0], xmm14
000074c379dd6d42  vmovaps [rsp+0xE0], xmm15
000074c379dd6d4b  sub rsp, 0x30
000074c379dd6d4f  movaps [rsp], xmm6
000074c379dd6d53  movaps [rsp+0x10], xmm12
000074c379dd6d59  movaps [rsp+0x20], xmm11
000074c379dd6d5f  lea rdi, [rsp]
000074c379dd6d63  mov esi, 0x00
000074c379dd6d68  mov rax, 0x56321ABA4530
000074c379dd6d72  call rax
000074c379dd6d74  movaps xmm6, [rsp]
000074c379dd6d78  add rsp, 0x30
000074c379dd6d7c  vmovaps xmm0, [rsp]
000074c379dd6d81  vmovaps xmm1, [rsp+0x10]
000074c379dd6d87  vmovaps xmm2, [rsp+0x20]
000074c379dd6d8d  vmovaps xmm3, [rsp+0x30]
000074c379dd6d93  vmovaps xmm4, [rsp+0x40]
000074c379dd6d99  vmovaps xmm5, [rsp+0x50]
000074c379dd6d9f  vmovaps xmm7, [rsp+0x60]
000074c379dd6da5  vmovaps xmm8, [rsp+0x70]
000074c379dd6dab  vmovaps xmm9, [rsp+0x80]
000074c379dd6db4  vmovaps xmm10, [rsp+0x90]
000074c379dd6dbd  vmovaps xmm11, [rsp+0xA0]
000074c379dd6dc6  vmovaps xmm12, [rsp+0xB0]
000074c379dd6dcf  vmovaps xmm13, [rsp+0xC0]
000074c379dd6dd8  vmovaps xmm14, [rsp+0xD0]
000074c379dd6de1  vmovaps xmm15, [rsp+0xE0]
000074c379dd6dea  add rsp, 0xF0
000074c379dd6df1  pop r11
000074c379dd6df3  pop r10
000074c379dd6df5  pop r9
000074c379dd6df7  pop r8
000074c379dd6df9  pop rsi
000074c379dd6dfa  pop rdi
000074c379dd6dfb  pop rdx
000074c379dd6dfc  pop rcx
000074c379dd6dfd  pop rax
000074c379dd6dfe  add rsp, 0x08
000074c379dd6e02  jmp 0x000074C379DD5A27
000074c379dd6e07  sub rsp, 0x08
000074c379dd6e0b  push rax
000074c379dd6e0c  push rcx
000074c379dd6e0d  push rdx
000074c379dd6e0e  push rdi
000074c379dd6e0f  push rsi
000074c379dd6e10  push r8
000074c379dd6e12  push r9
000074c379dd6e14  push r10
000074c379dd6e16  push r11
000074c379dd6e18  sub rsp, 0xF0
000074c379dd6e1f  vmovaps [rsp], xmm0
000074c379dd6e24  vmovaps [rsp+0x10], xmm1
000074c379dd6e2a  vmovaps [rsp+0x20], xmm2
000074c379dd6e30  vmovaps [rsp+0x30], xmm4
000074c379dd6e36  vmovaps [rsp+0x40], xmm5
000074c379dd6e3c  vmovaps [rsp+0x50], xmm6
000074c379dd6e42  vmovaps [rsp+0x60], xmm7
000074c379dd6e48  vmovaps [rsp+0x70], xmm8
000074c379dd6e4e  vmovaps [rsp+0x80], xmm9
000074c379dd6e57  vmovaps [rsp+0x90], xmm10
000074c379dd6e60  vmovaps [rsp+0xA0], xmm11
000074c379dd6e69  vmovaps [rsp+0xB0], xmm12
000074c379dd6e72  vmovaps [rsp+0xC0], xmm13
000074c379dd6e7b  vmovaps [rsp+0xD0], xmm14
000074c379dd6e84  vmovaps [rsp+0xE0], xmm15
000074c379dd6e8d  sub rsp, 0x30
000074c379dd6e91  movaps [rsp], xmm3
000074c379dd6e95  movaps [rsp+0x10], xmm5
000074c379dd6e9a  movaps [rsp+0x20], xmm4
000074c379dd6e9f  lea rdi, [rsp]
000074c379dd6ea3  mov esi, 0x00
000074c379dd6ea8  mov rax, 0x56321ABA4530
000074c379dd6eb2  call rax
000074c379dd6eb4  movaps xmm3, [rsp]
000074c379dd6eb8  add rsp, 0x30
000074c379dd6ebc  vmovaps xmm0, [rsp]
000074c379dd6ec1  vmovaps xmm1, [rsp+0x10]
000074c379dd6ec7  vmovaps xmm2, [rsp+0x20]
000074c379dd6ecd  vmovaps xmm4, [rsp+0x30]
000074c379dd6ed3  vmovaps xmm5, [rsp+0x40]
000074c379dd6ed9  vmovaps xmm6, [rsp+0x50]
000074c379dd6edf  vmovaps xmm7, [rsp+0x60]
000074c379dd6ee5  vmovaps xmm8, [rsp+0x70]
000074c379dd6eeb  vmovaps xmm9, [rsp+0x80]
000074c379dd6ef4  vmovaps xmm10, [rsp+0x90]
000074c379dd6efd  vmovaps xmm11, [rsp+0xA0]
000074c379dd6f06  vmovaps xmm12, [rsp+0xB0]
000074c379dd6f0f  vmovaps xmm13, [rsp+0xC0]
000074c379dd6f18  vmovaps xmm14, [rsp+0xD0]
000074c379dd6f21  vmovaps xmm15, [rsp+0xE0]
000074c379dd6f2a  add rsp, 0xF0
000074c379dd6f31  pop r11
000074c379dd6f33  pop r10
000074c379dd6f35  pop r9
000074c379dd6f37  pop r8
000074c379dd6f39  pop rsi
000074c379dd6f3a  pop rdi
000074c379dd6f3b  pop rdx
000074c379dd6f3c  pop rcx
000074c379dd6f3d  pop rax
000074c379dd6f3e  add rsp, 0x08
000074c379dd6f42  jmp 0x000074C379DD5A88
000074c379dd6f47  sub rsp, 0x08
000074c379dd6f4b  push rax
000074c379dd6f4c  push rcx
000074c379dd6f4d  push rdx
000074c379dd6f4e  push rdi
000074c379dd6f4f  push rsi
000074c379dd6f50  push r8
000074c379dd6f52  push r9
000074c379dd6f54  push r10
000074c379dd6f56  push r11
000074c379dd6f58  sub rsp, 0xF0
000074c379dd6f5f  vmovaps [rsp], xmm0
000074c379dd6f64  vmovaps [rsp+0x10], xmm1
000074c379dd6f6a  vmovaps [rsp+0x20], xmm2
000074c379dd6f70  vmovaps [rsp+0x30], xmm3
000074c379dd6f76  vmovaps [rsp+0x40], xmm4
000074c379dd6f7c  vmovaps [rsp+0x50], xmm6
000074c379dd6f82  vmovaps [rsp+0x60], xmm7
000074c379dd6f88  vmovaps [rsp+0x70], xmm8
000074c379dd6f8e  vmovaps [rsp+0x80], xmm9
000074c379dd6f97  vmovaps [rsp+0x90], xmm10
000074c379dd6fa0  vmovaps [rsp+0xA0], xmm11
000074c379dd6fa9  vmovaps [rsp+0xB0], xmm12
000074c379dd6fb2  vmovaps [rsp+0xC0], xmm13
000074c379dd6fbb  vmovaps [rsp+0xD0], xmm14
000074c379dd6fc4  vmovaps [rsp+0xE0], xmm15
000074c379dd6fcd  sub rsp, 0x30
000074c379dd6fd1  movaps [rsp], xmm5
000074c379dd6fd5  movaps [rsp+0x10], xmm8
000074c379dd6fdb  movaps [rsp+0x20], xmm15
000074c379dd6fe1  lea rdi, [rsp]
000074c379dd6fe5  mov esi, 0x00
000074c379dd6fea  mov rax, 0x56321ABA4530
000074c379dd6ff4  call rax
000074c379dd6ff6  movaps xmm5, [rsp]
000074c379dd6ffa  add rsp, 0x30
000074c379dd6ffe  vmovaps xmm0, [rsp]
000074c379dd7003  vmovaps xmm1, [rsp+0x10]
000074c379dd7009  vmovaps xmm2, [rsp+0x20]
000074c379dd700f  vmovaps xmm3, [rsp+0x30]
000074c379dd7015  vmovaps xmm4, [rsp+0x40]
000074c379dd701b  vmovaps xmm6, [rsp+0x50]
000074c379dd7021  vmovaps xmm7, [rsp+0x60]
000074c379dd7027  vmovaps xmm8, [rsp+0x70]
000074c379dd702d  vmovaps xmm9, [rsp+0x80]
000074c379dd7036  vmovaps xmm10, [rsp+0x90]
000074c379dd703f  vmovaps xmm11, [rsp+0xA0]
000074c379dd7048  vmovaps xmm12, [rsp+0xB0]
000074c379dd7051  vmovaps xmm13, [rsp+0xC0]
000074c379dd705a  vmovaps xmm14, [rsp+0xD0]
000074c379dd7063  vmovaps xmm15, [rsp+0xE0]
000074c379dd706c  add rsp, 0xF0
000074c379dd7073  pop r11
000074c379dd7075  pop r10
000074c379dd7077  pop r9
000074c379dd7079  pop r8
000074c379dd707b  pop rsi
000074c379dd707c  pop rdi
000074c379dd707d  pop rdx
000074c379dd707e  pop rcx
000074c379dd707f  pop rax
000074c379dd7080  add rsp, 0x08
000074c379dd7084  jmp 0x000074C379DD5AC0
000074c379dd7089  sub rsp, 0x08
000074c379dd708d  push rax
000074c379dd708e  push rcx
000074c379dd708f  push rdx
000074c379dd7090  push rdi
000074c379dd7091  push rsi
000074c379dd7092  push r8
000074c379dd7094  push r9
000074c379dd7096  push r10
000074c379dd7098  push r11
000074c379dd709a  sub rsp, 0xF0
000074c379dd70a1  vmovaps [rsp], xmm0
000074c379dd70a6  vmovaps [rsp+0x10], xmm1
000074c379dd70ac  vmovaps [rsp+0x20], xmm2
000074c379dd70b2  vmovaps [rsp+0x30], xmm3
000074c379dd70b8  vmovaps [rsp+0x40], xmm5
000074c379dd70be  vmovaps [rsp+0x50], xmm6
000074c379dd70c4  vmovaps [rsp+0x60], xmm7
000074c379dd70ca  vmovaps [rsp+0x70], xmm8
000074c379dd70d0  vmovaps [rsp+0x80], xmm9
000074c379dd70d9  vmovaps [rsp+0x90], xmm10
000074c379dd70e2  vmovaps [rsp+0xA0], xmm11
000074c379dd70eb  vmovaps [rsp+0xB0], xmm12
000074c379dd70f4  vmovaps [rsp+0xC0], xmm13
000074c379dd70fd  vmovaps [rsp+0xD0], xmm14
000074c379dd7106  vmovaps [rsp+0xE0], xmm15
000074c379dd710f  sub rsp, 0x30
000074c379dd7113  movaps [rsp], xmm4
000074c379dd7117  movaps [rsp+0x10], xmm9
000074c379dd711d  movaps [rsp+0x20], xmm8
000074c379dd7123  lea rdi, [rsp]
000074c379dd7127  mov esi, 0x00
000074c379dd712c  mov rax, 0x56321ABA4530
000074c379dd7136  call rax
000074c379dd7138  movaps xmm4, [rsp]
000074c379dd713c  add rsp, 0x30
000074c379dd7140  vmovaps xmm0, [rsp]
000074c379dd7145  vmovaps xmm1, [rsp+0x10]
000074c379dd714b  vmovaps xmm2, [rsp+0x20]
000074c379dd7151  vmovaps xmm3, [rsp+0x30]
000074c379dd7157  vmovaps xmm5, [rsp+0x40]
000074c379dd715d  vmovaps xmm6, [rsp+0x50]
000074c379dd7163  vmovaps xmm7, [rsp+0x60]
000074c379dd7169  vmovaps xmm8, [rsp+0x70]
000074c379dd716f  vmovaps xmm9, [rsp+0x80]
000074c379dd7178  vmovaps xmm10, [rsp+0x90]
000074c379dd7181  vmovaps xmm11, [rsp+0xA0]
000074c379dd718a  vmovaps xmm12, [rsp+0xB0]
000074c379dd7193  vmovaps xmm13, [rsp+0xC0]
000074c379dd719c  vmovaps xmm14, [rsp+0xD0]
000074c379dd71a5  vmovaps xmm15, [rsp+0xE0]
000074c379dd71ae  add rsp, 0xF0
000074c379dd71b5  pop r11
000074c379dd71b7  pop r10
000074c379dd71b9  pop r9
000074c379dd71bb  pop r8
000074c379dd71bd  pop rsi
000074c379dd71be  pop rdi
000074c379dd71bf  pop rdx
000074c379dd71c0  pop rcx
000074c379dd71c1  pop rax
000074c379dd71c2  add rsp, 0x08
000074c379dd71c6  jmp 0x000074C379DD5AE1
000074c379dd71cb  sub rsp, 0x08
000074c379dd71cf  push rax
000074c379dd71d0  push rcx
000074c379dd71d1  push rdx
000074c379dd71d2  push rdi
000074c379dd71d3  push rsi
000074c379dd71d4  push r8
000074c379dd71d6  push r9
000074c379dd71d8  push r10
000074c379dd71da  push r11
000074c379dd71dc  sub rsp, 0xF0
000074c379dd71e3  vmovaps [rsp], xmm0
000074c379dd71e8  vmovaps [rsp+0x10], xmm1
000074c379dd71ee  vmovaps [rsp+0x20], xmm2
000074c379dd71f4  vmovaps [rsp+0x30], xmm3
000074c379dd71fa  vmovaps [rsp+0x40], xmm4
000074c379dd7200  vmovaps [rsp+0x50], xmm5
000074c379dd7206  vmovaps [rsp+0x60], xmm6
000074c379dd720c  vmovaps [rsp+0x70], xmm7
000074c379dd7212  vmovaps [rsp+0x80], xmm8
000074c379dd721b  vmovaps [rsp+0x90], xmm10
000074c379dd7224  vmovaps [rsp+0xA0], xmm11
000074c379dd722d  vmovaps [rsp+0xB0], xmm12
000074c379dd7236  vmovaps [rsp+0xC0], xmm13
000074c379dd723f  vmovaps [rsp+0xD0], xmm14
000074c379dd7248  vmovaps [rsp+0xE0], xmm15
000074c379dd7251  sub rsp, 0x30
000074c379dd7255  movaps [rsp], xmm9
000074c379dd725a  movaps [rsp+0x10], xmm10
000074c379dd7260  movaps [rsp+0x20], xmm8
000074c379dd7266  lea rdi, [rsp]
000074c379dd726a  mov esi, 0x00
000074c379dd726f  mov rax, 0x56321ABA4530
000074c379dd7279  call rax
000074c379dd727b  movaps xmm9, [rsp]
000074c379dd7280  add rsp, 0x30
000074c379dd7284  vmovaps xmm0, [rsp]
000074c379dd7289  vmovaps xmm1, [rsp+0x10]
000074c379dd728f  vmovaps xmm2, [rsp+0x20]
000074c379dd7295  vmovaps xmm3, [rsp+0x30]
000074c379dd729b  vmovaps xmm4, [rsp+0x40]
000074c379dd72a1  vmovaps xmm5, [rsp+0x50]
000074c379dd72a7  vmovaps xmm6, [rsp+0x60]
000074c379dd72ad  vmovaps xmm7, [rsp+0x70]
000074c379dd72b3  vmovaps xmm8, [rsp+0x80]
000074c379dd72bc  vmovaps xmm10, [rsp+0x90]
000074c379dd72c5  vmovaps xmm11, [rsp+0xA0]
000074c379dd72ce  vmovaps xmm12, [rsp+0xB0]
000074c379dd72d7  vmovaps xmm13, [rsp+0xC0]
000074c379dd72e0  vmovaps xmm14, [rsp+0xD0]
000074c379dd72e9  vmovaps xmm15, [rsp+0xE0]
000074c379dd72f2  add rsp, 0xF0
000074c379dd72f9  pop r11
000074c379dd72fb  pop r10
000074c379dd72fd  pop r9
000074c379dd72ff  pop r8
000074c379dd7301  pop rsi
000074c379dd7302  pop rdi
000074c379dd7303  pop rdx
000074c379dd7304  pop rcx
000074c379dd7305  pop rax
000074c379dd7306  add rsp, 0x08
000074c379dd730a  jmp 0x000074C379DD5AFB
000074c379dd730f  call 0x000074C379CD64F0
000074c379dd7314  jmp 0x000074C379DD5C15
000074c379dd7319  call 0x000074C379CD64F0
000074c379dd731e  jmp 0x000074C379DD5C2B
000074c379dd7323  sub rsp, 0x08
000074c379dd7327  push rax
000074c379dd7328  push rcx
000074c379dd7329  push rdx
000074c379dd732a  push rdi
000074c379dd732b  push rsi
000074c379dd732c  push r8
000074c379dd732e  push r9
000074c379dd7330  push r10
000074c379dd7332  push r11
000074c379dd7334  sub rsp, 0xF0
000074c379dd733b  vmovaps [rsp], xmm0
000074c379dd7340  vmovaps [rsp+0x10], xmm2
000074c379dd7346  vmovaps [rsp+0x20], xmm3
000074c379dd734c  vmovaps [rsp+0x30], xmm4
000074c379dd7352  vmovaps [rsp+0x40], xmm5
000074c379dd7358  vmovaps [rsp+0x50], xmm6
000074c379dd735e  vmovaps [rsp+0x60], xmm7
000074c379dd7364  vmovaps [rsp+0x70], xmm8
000074c379dd736a  vmovaps [rsp+0x80], xmm9
000074c379dd7373  vmovaps [rsp+0x90], xmm10
000074c379dd737c  vmovaps [rsp+0xA0], xmm11
000074c379dd7385  vmovaps [rsp+0xB0], xmm12
000074c379dd738e  vmovaps [rsp+0xC0], xmm13
000074c379dd7397  vmovaps [rsp+0xD0], xmm14
000074c379dd73a0  vmovaps [rsp+0xE0], xmm15
000074c379dd73a9  sub rsp, 0x30
000074c379dd73ad  movaps [rsp], xmm1
000074c379dd73b1  movaps [rsp+0x10], xmm6
000074c379dd73b6  movaps [rsp+0x20], xmm15
000074c379dd73bc  lea rdi, [rsp]
000074c379dd73c0  mov esi, 0x00
000074c379dd73c5  mov rax, 0x56321ABA4530
000074c379dd73cf  call rax
000074c379dd73d1  movaps xmm1, [rsp]
000074c379dd73d5  add rsp, 0x30
000074c379dd73d9  vmovaps xmm0, [rsp]
000074c379dd73de  vmovaps xmm2, [rsp+0x10]
000074c379dd73e4  vmovaps xmm3, [rsp+0x20]
000074c379dd73ea  vmovaps xmm4, [rsp+0x30]
000074c379dd73f0  vmovaps xmm5, [rsp+0x40]
000074c379dd73f6  vmovaps xmm6, [rsp+0x50]
000074c379dd73fc  vmovaps xmm7, [rsp+0x60]
000074c379dd7402  vmovaps xmm8, [rsp+0x70]
000074c379dd7408  vmovaps xmm9, [rsp+0x80]
000074c379dd7411  vmovaps xmm10, [rsp+0x90]
000074c379dd741a  vmovaps xmm11, [rsp+0xA0]
000074c379dd7423  vmovaps xmm12, [rsp+0xB0]
000074c379dd742c  vmovaps xmm13, [rsp+0xC0]
000074c379dd7435  vmovaps xmm14, [rsp+0xD0]
000074c379dd743e  vmovaps xmm15, [rsp+0xE0]
000074c379dd7447  add rsp, 0xF0
000074c379dd744e  pop r11
000074c379dd7450  pop r10
000074c379dd7452  pop r9
000074c379dd7454  pop r8
000074c379dd7456  pop rsi
000074c379dd7457  pop rdi
000074c379dd7458  pop rdx
000074c379dd7459  pop rcx
000074c379dd745a  pop rax
000074c379dd745b  add rsp, 0x08
000074c379dd745f  jmp 0x000074C379DD5C68
000074c379dd7464  call 0x000074C379CE5820
000074c379dd7469  jmp 0x000074C379DD5C75
000074c379dd746e  sub rsp, 0x08
000074c379dd7472  push rax
000074c379dd7473  push rcx
000074c379dd7474  push rdx
000074c379dd7475  push rdi
000074c379dd7476  push rsi
000074c379dd7477  push r8
000074c379dd7479  push r9
000074c379dd747b  push r10
000074c379dd747d  push r11
000074c379dd747f  sub rsp, 0xF0
000074c379dd7486  vmovaps [rsp], xmm0
000074c379dd748b  vmovaps [rsp+0x10], xmm1
000074c379dd7491  vmovaps [rsp+0x20], xmm2
000074c379dd7497  vmovaps [rsp+0x30], xmm3
000074c379dd749d  vmovaps [rsp+0x40], xmm4
000074c379dd74a3  vmovaps [rsp+0x50], xmm5
000074c379dd74a9  vmovaps [rsp+0x60], xmm6
000074c379dd74af  vmovaps [rsp+0x70], xmm7
000074c379dd74b5  vmovaps [rsp+0x80], xmm8
000074c379dd74be  vmovaps [rsp+0x90], xmm9
000074c379dd74c7  vmovaps [rsp+0xA0], xmm10
000074c379dd74d0  vmovaps [rsp+0xB0], xmm11
000074c379dd74d9  vmovaps [rsp+0xC0], xmm12
000074c379dd74e2  vmovaps [rsp+0xD0], xmm13
000074c379dd74eb  vmovaps [rsp+0xE0], xmm15
000074c379dd74f4  sub rsp, 0x30
000074c379dd74f8  movaps [rsp], xmm14
000074c379dd74fd  movaps [rsp+0x10], xmm4
000074c379dd7502  movaps [rsp+0x20], xmm3
000074c379dd7507  lea rdi, [rsp]
000074c379dd750b  mov esi, 0x00
000074c379dd7510  mov rax, 0x56321ABA4530
000074c379dd751a  call rax
000074c379dd751c  movaps xmm14, [rsp]
000074c379dd7521  add rsp, 0x30
000074c379dd7525  vmovaps xmm0, [rsp]
000074c379dd752a  vmovaps xmm1, [rsp+0x10]
000074c379dd7530  vmovaps xmm2, [rsp+0x20]
000074c379dd7536  vmovaps xmm3, [rsp+0x30]
000074c379dd753c  vmovaps xmm4, [rsp+0x40]
000074c379dd7542  vmovaps xmm5, [rsp+0x50]
000074c379dd7548  vmovaps xmm6, [rsp+0x60]
000074c379dd754e  vmovaps xmm7, [rsp+0x70]
000074c379dd7554  vmovaps xmm8, [rsp+0x80]
000074c379dd755d  vmovaps xmm9, [rsp+0x90]
000074c379dd7566  vmovaps xmm10, [rsp+0xA0]
000074c379dd756f  vmovaps xmm11, [rsp+0xB0]
000074c379dd7578  vmovaps xmm12, [rsp+0xC0]
000074c379dd7581  vmovaps xmm13, [rsp+0xD0]
000074c379dd758a  vmovaps xmm15, [rsp+0xE0]
000074c379dd7593  add rsp, 0xF0
000074c379dd759a  pop r11
000074c379dd759c  pop r10
000074c379dd759e  pop r9
000074c379dd75a0  pop r8
000074c379dd75a2  pop rsi
000074c379dd75a3  pop rdi
000074c379dd75a4  pop rdx
000074c379dd75a5  pop rcx
000074c379dd75a6  pop rax
000074c379dd75a7  add rsp, 0x08
000074c379dd75ab  jmp 0x000074C379DD5C8F
000074c379dd75b0  sub rsp, 0x08
000074c379dd75b4  push rax
000074c379dd75b5  push rcx
000074c379dd75b6  push rdx
000074c379dd75b7  push rdi
000074c379dd75b8  push rsi
000074c379dd75b9  push r8
000074c379dd75bb  push r9
000074c379dd75bd  push r10
000074c379dd75bf  push r11
000074c379dd75c1  sub rsp, 0xF0
000074c379dd75c8  vmovaps [rsp], xmm0
000074c379dd75cd  vmovaps [rsp+0x10], xmm1
000074c379dd75d3  vmovaps [rsp+0x20], xmm2
000074c379dd75d9  vmovaps [rsp+0x30], xmm3
000074c379dd75df  vmovaps [rsp+0x40], xmm4
000074c379dd75e5  vmovaps [rsp+0x50], xmm5
000074c379dd75eb  vmovaps [rsp+0x60], xmm7
000074c379dd75f1  vmovaps [rsp+0x70], xmm8
000074c379dd75f7  vmovaps [rsp+0x80], xmm9
000074c379dd7600  vmovaps [rsp+0x90], xmm10
000074c379dd7609  vmovaps [rsp+0xA0], xmm11
000074c379dd7612  vmovaps [rsp+0xB0], xmm12
000074c379dd761b  vmovaps [rsp+0xC0], xmm13
000074c379dd7624  vmovaps [rsp+0xD0], xmm14
000074c379dd762d  vmovaps [rsp+0xE0], xmm15
000074c379dd7636  sub rsp, 0x30
000074c379dd763a  movaps [rsp], xmm6
000074c379dd763e  movaps [rsp+0x10], xmm9
000074c379dd7644  movaps [rsp+0x20], xmm7
000074c379dd7649  lea rdi, [rsp]
000074c379dd764d  mov esi, 0x00
000074c379dd7652  mov rax, 0x56321ABA4530
000074c379dd765c  call rax
000074c379dd765e  movaps xmm6, [rsp]
000074c379dd7662  add rsp, 0x30
000074c379dd7666  vmovaps xmm0, [rsp]
000074c379dd766b  vmovaps xmm1, [rsp+0x10]
000074c379dd7671  vmovaps xmm2, [rsp+0x20]
000074c379dd7677  vmovaps xmm3, [rsp+0x30]
000074c379dd767d  vmovaps xmm4, [rsp+0x40]
000074c379dd7683  vmovaps xmm5, [rsp+0x50]
000074c379dd7689  vmovaps xmm7, [rsp+0x60]
000074c379dd768f  vmovaps xmm8, [rsp+0x70]
000074c379dd7695  vmovaps xmm9, [rsp+0x80]
000074c379dd769e  vmovaps xmm10, [rsp+0x90]
000074c379dd76a7  vmovaps xmm11, [rsp+0xA0]
000074c379dd76b0  vmovaps xmm12, [rsp+0xB0]
000074c379dd76b9  vmovaps xmm13, [rsp+0xC0]
000074c379dd76c2  vmovaps xmm14, [rsp+0xD0]
000074c379dd76cb  vmovaps xmm15, [rsp+0xE0]
000074c379dd76d4  add rsp, 0xF0
000074c379dd76db  pop r11
000074c379dd76dd  pop r10
000074c379dd76df  pop r9
000074c379dd76e1  pop r8
000074c379dd76e3  pop rsi
000074c379dd76e4  pop rdi
000074c379dd76e5  pop rdx
000074c379dd76e6  pop rcx
000074c379dd76e7  pop rax
000074c379dd76e8  add rsp, 0x08
000074c379dd76ec  jmp 0x000074C379DD5CA7
000074c379dd76f1  sub rsp, 0x08
000074c379dd76f5  push rax
000074c379dd76f6  push rcx
000074c379dd76f7  push rdx
000074c379dd76f8  push rdi
000074c379dd76f9  push rsi
000074c379dd76fa  push r8
000074c379dd76fc  push r9
000074c379dd76fe  push r10
000074c379dd7700  push r11
000074c379dd7702  sub rsp, 0xF0
000074c379dd7709  vmovaps [rsp], xmm0
000074c379dd770e  vmovaps [rsp+0x10], xmm1
000074c379dd7714  vmovaps [rsp+0x20], xmm2
000074c379dd771a  vmovaps [rsp+0x30], xmm3
000074c379dd7720  vmovaps [rsp+0x40], xmm4
000074c379dd7726  vmovaps [rsp+0x50], xmm5
000074c379dd772c  vmovaps [rsp+0x60], xmm6
000074c379dd7732  vmovaps [rsp+0x70], xmm8
000074c379dd7738  vmovaps [rsp+0x80], xmm9
000074c379dd7741  vmovaps [rsp+0x90], xmm10
000074c379dd774a  vmovaps [rsp+0xA0], xmm11
000074c379dd7753  vmovaps [rsp+0xB0], xmm12
000074c379dd775c  vmovaps [rsp+0xC0], xmm13
000074c379dd7765  vmovaps [rsp+0xD0], xmm14
000074c379dd776e  vmovaps [rsp+0xE0], xmm15
000074c379dd7777  sub rsp, 0x30
000074c379dd777b  movaps [rsp], xmm7
000074c379dd777f  movaps [rsp+0x10], xmm4
000074c379dd7784  movaps [rsp+0x20], xmm9
000074c379dd778a  lea rdi, [rsp]
000074c379dd778e  mov esi, 0x00
000074c379dd7793  mov rax, 0x56321ABA4530
000074c379dd779d  call rax
000074c379dd779f  movaps xmm7, [rsp]
000074c379dd77a3  add rsp, 0x30
000074c379dd77a7  vmovaps xmm0, [rsp]
000074c379dd77ac  vmovaps xmm1, [rsp+0x10]
000074c379dd77b2  vmovaps xmm2, [rsp+0x20]
000074c379dd77b8  vmovaps xmm3, [rsp+0x30]
000074c379dd77be  vmovaps xmm4, [rsp+0x40]
000074c379dd77c4  vmovaps xmm5, [rsp+0x50]
000074c379dd77ca  vmovaps xmm6, [rsp+0x60]
000074c379dd77d0  vmovaps xmm8, [rsp+0x70]
000074c379dd77d6  vmovaps xmm9, [rsp+0x80]
000074c379dd77df  vmovaps xmm10, [rsp+0x90]
000074c379dd77e8  vmovaps xmm11, [rsp+0xA0]
000074c379dd77f1  vmovaps xmm12, [rsp+0xB0]
000074c379dd77fa  vmovaps xmm13, [rsp+0xC0]
000074c379dd7803  vmovaps xmm14, [rsp+0xD0]
000074c379dd780c  vmovaps xmm15, [rsp+0xE0]
000074c379dd7815  add rsp, 0xF0
000074c379dd781c  pop r11
000074c379dd781e  pop r10
000074c379dd7820  pop r9
000074c379dd7822  pop r8
000074c379dd7824  pop rsi
000074c379dd7825  pop rdi
000074c379dd7826  pop rdx
000074c379dd7827  pop rcx
000074c379dd7828  pop rax
000074c379dd7829  add rsp, 0x08
000074c379dd782d  jmp 0x000074C379DD5CD4
000074c379dd7832  sub rsp, 0x08
000074c379dd7836  push rax
000074c379dd7837  push rcx
000074c379dd7838  push rdx
000074c379dd7839  push rdi
000074c379dd783a  push rsi
000074c379dd783b  push r8
000074c379dd783d  push r9
000074c379dd783f  push r10
000074c379dd7841  push r11
000074c379dd7843  sub rsp, 0xF0
000074c379dd784a  vmovaps [rsp], xmm0
000074c379dd784f  vmovaps [rsp+0x10], xmm1
000074c379dd7855  vmovaps [rsp+0x20], xmm2
000074c379dd785b  vmovaps [rsp+0x30], xmm3
000074c379dd7861  vmovaps [rsp+0x40], xmm5
000074c379dd7867  vmovaps [rsp+0x50], xmm6
000074c379dd786d  vmovaps [rsp+0x60], xmm7
000074c379dd7873  vmovaps [rsp+0x70], xmm8
000074c379dd7879  vmovaps [rsp+0x80], xmm9
000074c379dd7882  vmovaps [rsp+0x90], xmm10
000074c379dd788b  vmovaps [rsp+0xA0], xmm11
000074c379dd7894  vmovaps [rsp+0xB0], xmm12
000074c379dd789d  vmovaps [rsp+0xC0], xmm13
000074c379dd78a6  vmovaps [rsp+0xD0], xmm14
000074c379dd78af  vmovaps [rsp+0xE0], xmm15
000074c379dd78b8  sub rsp, 0x30
000074c379dd78bc  movaps [rsp], xmm4
000074c379dd78c0  movaps [rsp+0x10], xmm15
000074c379dd78c6  movaps [rsp+0x20], xmm9
000074c379dd78cc  lea rdi, [rsp]
000074c379dd78d0  mov esi, 0x00
000074c379dd78d5  mov rax, 0x56321ABA4530
000074c379dd78df  call rax
000074c379dd78e1  movaps xmm4, [rsp]
000074c379dd78e5  add rsp, 0x30
000074c379dd78e9  vmovaps xmm0, [rsp]
000074c379dd78ee  vmovaps xmm1, [rsp+0x10]
000074c379dd78f4  vmovaps xmm2, [rsp+0x20]
000074c379dd78fa  vmovaps xmm3, [rsp+0x30]
000074c379dd7900  vmovaps xmm5, [rsp+0x40]
000074c379dd7906  vmovaps xmm6, [rsp+0x50]
000074c379dd790c  vmovaps xmm7, [rsp+0x60]
000074c379dd7912  vmovaps xmm8, [rsp+0x70]
000074c379dd7918  vmovaps xmm9, [rsp+0x80]
000074c379dd7921  vmovaps xmm10, [rsp+0x90]
000074c379dd792a  vmovaps xmm11, [rsp+0xA0]
000074c379dd7933  vmovaps xmm12, [rsp+0xB0]
000074c379dd793c  vmovaps xmm13, [rsp+0xC0]
000074c379dd7945  vmovaps xmm14, [rsp+0xD0]
000074c379dd794e  vmovaps xmm15, [rsp+0xE0]
000074c379dd7957  add rsp, 0xF0
000074c379dd795e  pop r11
000074c379dd7960  pop r10
000074c379dd7962  pop r9
000074c379dd7964  pop r8
000074c379dd7966  pop rsi
000074c379dd7967  pop rdi
000074c379dd7968  pop rdx
000074c379dd7969  pop rcx
000074c379dd796a  pop rax
000074c379dd796b  add rsp, 0x08
000074c379dd796f  jmp 0x000074C379DD5CF9
000074c379dd7974  call 0x000074C379CE5820
000074c379dd7979  jmp 0x000074C379DD5D06
000074c379dd797e  sub rsp, 0x08
000074c379dd7982  push rax
000074c379dd7983  push rcx
000074c379dd7984  push rdx
000074c379dd7985  push rdi
000074c379dd7986  push rsi
000074c379dd7987  push r8
000074c379dd7989  push r9
000074c379dd798b  push r10
000074c379dd798d  push r11
000074c379dd798f  sub rsp, 0xF0
000074c379dd7996  vmovaps [rsp], xmm0
000074c379dd799b  vmovaps [rsp+0x10], xmm1
000074c379dd79a1  vmovaps [rsp+0x20], xmm2
000074c379dd79a7  vmovaps [rsp+0x30], xmm4
000074c379dd79ad  vmovaps [rsp+0x40], xmm5
000074c379dd79b3  vmovaps [rsp+0x50], xmm6
000074c379dd79b9  vmovaps [rsp+0x60], xmm7
000074c379dd79bf  vmovaps [rsp+0x70], xmm8
000074c379dd79c5  vmovaps [rsp+0x80], xmm9
000074c379dd79ce  vmovaps [rsp+0x90], xmm10
000074c379dd79d7  vmovaps [rsp+0xA0], xmm11
000074c379dd79e0  vmovaps [rsp+0xB0], xmm12
000074c379dd79e9  vmovaps [rsp+0xC0], xmm13
000074c379dd79f2  vmovaps [rsp+0xD0], xmm14
000074c379dd79fb  vmovaps [rsp+0xE0], xmm15
000074c379dd7a04  sub rsp, 0x30
000074c379dd7a08  movaps [rsp], xmm3
000074c379dd7a0c  movaps [rsp+0x10], xmm1
000074c379dd7a11  movaps [rsp+0x20], xmm9
000074c379dd7a17  lea rdi, [rsp]
000074c379dd7a1b  mov esi, 0x00
000074c379dd7a20  mov rax, 0x56321ABA4530
000074c379dd7a2a  call rax
000074c379dd7a2c  movaps xmm3, [rsp]
000074c379dd7a30  add rsp, 0x30
000074c379dd7a34  vmovaps xmm0, [rsp]
000074c379dd7a39  vmovaps xmm1, [rsp+0x10]
000074c379dd7a3f  vmovaps xmm2, [rsp+0x20]
000074c379dd7a45  vmovaps xmm4, [rsp+0x30]
000074c379dd7a4b  vmovaps xmm5, [rsp+0x40]
000074c379dd7a51  vmovaps xmm6, [rsp+0x50]
000074c379dd7a57  vmovaps xmm7, [rsp+0x60]
000074c379dd7a5d  vmovaps xmm8, [rsp+0x70]
000074c379dd7a63  vmovaps xmm9, [rsp+0x80]
000074c379dd7a6c  vmovaps xmm10, [rsp+0x90]
000074c379dd7a75  vmovaps xmm11, [rsp+0xA0]
000074c379dd7a7e  vmovaps xmm12, [rsp+0xB0]
000074c379dd7a87  vmovaps xmm13, [rsp+0xC0]
000074c379dd7a90  vmovaps xmm14, [rsp+0xD0]
000074c379dd7a99  vmovaps xmm15, [rsp+0xE0]
000074c379dd7aa2  add rsp, 0xF0
000074c379dd7aa9  pop r11
000074c379dd7aab  pop r10
000074c379dd7aad  pop r9
000074c379dd7aaf  pop r8
000074c379dd7ab1  pop rsi
000074c379dd7ab2  pop rdi
000074c379dd7ab3  pop rdx
000074c379dd7ab4  pop rcx
000074c379dd7ab5  pop rax
000074c379dd7ab6  add rsp, 0x08
000074c379dd7aba  jmp 0x000074C379DD5D43
000074c379dd7abf  sub rsp, 0x08
000074c379dd7ac3  push rax
000074c379dd7ac4  push rcx
000074c379dd7ac5  push rdx
000074c379dd7ac6  push rdi
000074c379dd7ac7  push rsi
000074c379dd7ac8  push r8
000074c379dd7aca  push r9
000074c379dd7acc  push r10
000074c379dd7ace  push r11
000074c379dd7ad0  sub rsp, 0xF0
000074c379dd7ad7  vmovaps [rsp], xmm0
000074c379dd7adc  vmovaps [rsp+0x10], xmm2
000074c379dd7ae2  vmovaps [rsp+0x20], xmm3
000074c379dd7ae8  vmovaps [rsp+0x30], xmm4
000074c379dd7aee  vmovaps [rsp+0x40], xmm5
000074c379dd7af4  vmovaps [rsp+0x50], xmm6
000074c379dd7afa  vmovaps [rsp+0x60], xmm7
000074c379dd7b00  vmovaps [rsp+0x70], xmm8
000074c379dd7b06  vmovaps [rsp+0x80], xmm9
000074c379dd7b0f  vmovaps [rsp+0x90], xmm10
000074c379dd7b18  vmovaps [rsp+0xA0], xmm11
000074c379dd7b21  vmovaps [rsp+0xB0], xmm12
000074c379dd7b2a  vmovaps [rsp+0xC0], xmm13
000074c379dd7b33  vmovaps [rsp+0xD0], xmm14
000074c379dd7b3c  vmovaps [rsp+0xE0], xmm15
000074c379dd7b45  sub rsp, 0x30
000074c379dd7b49  movaps [rsp], xmm1
000074c379dd7b4d  movaps [rsp+0x10], xmm15
000074c379dd7b53  movaps [rsp+0x20], xmm9
000074c379dd7b59  lea rdi, [rsp]
000074c379dd7b5d  mov esi, 0x00
000074c379dd7b62  mov rax, 0x56321ABA4530
000074c379dd7b6c  call rax
000074c379dd7b6e  movaps xmm1, [rsp]
000074c379dd7b72  add rsp, 0x30
000074c379dd7b76  vmovaps xmm0, [rsp]
000074c379dd7b7b  vmovaps xmm2, [rsp+0x10]
000074c379dd7b81  vmovaps xmm3, [rsp+0x20]
000074c379dd7b87  vmovaps xmm4, [rsp+0x30]
000074c379dd7b8d  vmovaps xmm5, [rsp+0x40]
000074c379dd7b93  vmovaps xmm6, [rsp+0x50]
000074c379dd7b99  vmovaps xmm7, [rsp+0x60]
000074c379dd7b9f  vmovaps xmm8, [rsp+0x70]
000074c379dd7ba5  vmovaps xmm9, [rsp+0x80]
000074c379dd7bae  vmovaps xmm10, [rsp+0x90]
000074c379dd7bb7  vmovaps xmm11, [rsp+0xA0]
000074c379dd7bc0  vmovaps xmm12, [rsp+0xB0]
000074c379dd7bc9  vmovaps xmm13, [rsp+0xC0]
000074c379dd7bd2  vmovaps xmm14, [rsp+0xD0]
000074c379dd7bdb  vmovaps xmm15, [rsp+0xE0]
000074c379dd7be4  add rsp, 0xF0
000074c379dd7beb  pop r11
000074c379dd7bed  pop r10
000074c379dd7bef  pop r9
000074c379dd7bf1  pop r8
000074c379dd7bf3  pop rsi
000074c379dd7bf4  pop rdi
000074c379dd7bf5  pop rdx
000074c379dd7bf6  pop rcx
000074c379dd7bf7  pop rax
000074c379dd7bf8  add rsp, 0x08
000074c379dd7bfc  jmp 0x000074C379DD5DCB
000074c379dd7c01  call 0x000074C379CE5820
000074c379dd7c06  jmp 0x000074C379DD5DD8
000074c379dd7c0b  sub rsp, 0x08
000074c379dd7c0f  push rax
000074c379dd7c10  push rcx
000074c379dd7c11  push rdx
000074c379dd7c12  push rdi
000074c379dd7c13  push rsi
000074c379dd7c14  push r8
000074c379dd7c16  push r9
000074c379dd7c18  push r10
000074c379dd7c1a  push r11
000074c379dd7c1c  sub rsp, 0xF0
000074c379dd7c23  vmovaps [rsp], xmm0
000074c379dd7c28  vmovaps [rsp+0x10], xmm2
000074c379dd7c2e  vmovaps [rsp+0x20], xmm3
000074c379dd7c34  vmovaps [rsp+0x30], xmm4
000074c379dd7c3a  vmovaps [rsp+0x40], xmm5
000074c379dd7c40  vmovaps [rsp+0x50], xmm6
000074c379dd7c46  vmovaps [rsp+0x60], xmm7
000074c379dd7c4c  vmovaps [rsp+0x70], xmm8
000074c379dd7c52  vmovaps [rsp+0x80], xmm9
000074c379dd7c5b  vmovaps [rsp+0x90], xmm10
000074c379dd7c64  vmovaps [rsp+0xA0], xmm11
000074c379dd7c6d  vmovaps [rsp+0xB0], xmm12
000074c379dd7c76  vmovaps [rsp+0xC0], xmm13
000074c379dd7c7f  vmovaps [rsp+0xD0], xmm14
000074c379dd7c88  vmovaps [rsp+0xE0], xmm15
000074c379dd7c91  sub rsp, 0x30
000074c379dd7c95  movaps [rsp], xmm1
000074c379dd7c99  movaps [rsp+0x10], xmm5
000074c379dd7c9e  movaps [rsp+0x20], xmm7
000074c379dd7ca3  lea rdi, [rsp]
000074c379dd7ca7  mov esi, 0x00
000074c379dd7cac  mov rax, 0x56321ABA4530
000074c379dd7cb6  call rax
000074c379dd7cb8  movaps xmm1, [rsp]
000074c379dd7cbc  add rsp, 0x30
000074c379dd7cc0  vmovaps xmm0, [rsp]
000074c379dd7cc5  vmovaps xmm2, [rsp+0x10]
000074c379dd7ccb  vmovaps xmm3, [rsp+0x20]
000074c379dd7cd1  vmovaps xmm4, [rsp+0x30]
000074c379dd7cd7  vmovaps xmm5, [rsp+0x40]
000074c379dd7cdd  vmovaps xmm6, [rsp+0x50]
000074c379dd7ce3  vmovaps xmm7, [rsp+0x60]
000074c379dd7ce9  vmovaps xmm8, [rsp+0x70]
000074c379dd7cef  vmovaps xmm9, [rsp+0x80]
000074c379dd7cf8  vmovaps xmm10, [rsp+0x90]
000074c379dd7d01  vmovaps xmm11, [rsp+0xA0]
000074c379dd7d0a  vmovaps xmm12, [rsp+0xB0]
000074c379dd7d13  vmovaps xmm13, [rsp+0xC0]
000074c379dd7d1c  vmovaps xmm14, [rsp+0xD0]
000074c379dd7d25  vmovaps xmm15, [rsp+0xE0]
000074c379dd7d2e  add rsp, 0xF0
000074c379dd7d35  pop r11
000074c379dd7d37  pop r10
000074c379dd7d39  pop r9
000074c379dd7d3b  pop r8
000074c379dd7d3d  pop rsi
000074c379dd7d3e  pop rdi
000074c379dd7d3f  pop rdx
000074c379dd7d40  pop rcx
000074c379dd7d41  pop rax
000074c379dd7d42  add rsp, 0x08
000074c379dd7d46  jmp 0x000074C379DD5E7D
000074c379dd7d4b  sub rsp, 0x08
000074c379dd7d4f  push rax
000074c379dd7d50  push rcx
000074c379dd7d51  push rdx
000074c379dd7d52  push rdi
000074c379dd7d53  push rsi
000074c379dd7d54  push r8
000074c379dd7d56  push r9
000074c379dd7d58  push r10
000074c379dd7d5a  push r11
000074c379dd7d5c  sub rsp, 0xF0
000074c379dd7d63  vmovaps [rsp], xmm0
000074c379dd7d68  vmovaps [rsp+0x10], xmm1
000074c379dd7d6e  vmovaps [rsp+0x20], xmm2
000074c379dd7d74  vmovaps [rsp+0x30], xmm3
000074c379dd7d7a  vmovaps [rsp+0x40], xmm4
000074c379dd7d80  vmovaps [rsp+0x50], xmm5
000074c379dd7d86  vmovaps [rsp+0x60], xmm6
000074c379dd7d8c  vmovaps [rsp+0x70], xmm8
000074c379dd7d92  vmovaps [rsp+0x80], xmm9
000074c379dd7d9b  vmovaps [rsp+0x90], xmm10
000074c379dd7da4  vmovaps [rsp+0xA0], xmm11
000074c379dd7dad  vmovaps [rsp+0xB0], xmm12
000074c379dd7db6  vmovaps [rsp+0xC0], xmm13
000074c379dd7dbf  vmovaps [rsp+0xD0], xmm14
000074c379dd7dc8  vmovaps [rsp+0xE0], xmm15
000074c379dd7dd1  sub rsp, 0x30
000074c379dd7dd5  movaps [rsp], xmm7
000074c379dd7dd9  movaps [rsp+0x10], xmm5
000074c379dd7dde  movaps [rsp+0x20], xmm15
000074c379dd7de4  lea rdi, [rsp]
000074c379dd7de8  mov esi, 0x00
000074c379dd7ded  mov rax, 0x56321ABA4530
000074c379dd7df7  call rax
000074c379dd7df9  movaps xmm7, [rsp]
000074c379dd7dfd  add rsp, 0x30
000074c379dd7e01  vmovaps xmm0, [rsp]
000074c379dd7e06  vmovaps xmm1, [rsp+0x10]
000074c379dd7e0c  vmovaps xmm2, [rsp+0x20]
000074c379dd7e12  vmovaps xmm3, [rsp+0x30]
000074c379dd7e18  vmovaps xmm4, [rsp+0x40]
000074c379dd7e1e  vmovaps xmm5, [rsp+0x50]
000074c379dd7e24  vmovaps xmm6, [rsp+0x60]
000074c379dd7e2a  vmovaps xmm8, [rsp+0x70]
000074c379dd7e30  vmovaps xmm9, [rsp+0x80]
000074c379dd7e39  vmovaps xmm10, [rsp+0x90]
000074c379dd7e42  vmovaps xmm11, [rsp+0xA0]
000074c379dd7e4b  vmovaps xmm12, [rsp+0xB0]
000074c379dd7e54  vmovaps xmm13, [rsp+0xC0]
000074c379dd7e5d  vmovaps xmm14, [rsp+0xD0]
000074c379dd7e66  vmovaps xmm15, [rsp+0xE0]
000074c379dd7e6f  add rsp, 0xF0
000074c379dd7e76  pop r11
000074c379dd7e78  pop r10
000074c379dd7e7a  pop r9
000074c379dd7e7c  pop r8
000074c379dd7e7e  pop rsi
000074c379dd7e7f  pop rdi
000074c379dd7e80  pop rdx
000074c379dd7e81  pop rcx
000074c379dd7e82  pop rax
000074c379dd7e83  add rsp, 0x08
000074c379dd7e87  jmp 0x000074C379DD5EB3
000074c379dd7e8c  call 0x000074C379CD64F0
000074c379dd7e91  jmp 0x000074C379DD5EC0
000074c379dd7e96  sub rsp, 0x08
000074c379dd7e9a  push rax
000074c379dd7e9b  push rcx
000074c379dd7e9c  push rdx
000074c379dd7e9d  push rdi
000074c379dd7e9e  push rsi
000074c379dd7e9f  push r8
000074c379dd7ea1  push r9
000074c379dd7ea3  push r10
000074c379dd7ea5  push r11
000074c379dd7ea7  sub rsp, 0xF0
000074c379dd7eae  vmovaps [rsp], xmm0
000074c379dd7eb3  vmovaps [rsp+0x10], xmm1
000074c379dd7eb9  vmovaps [rsp+0x20], xmm2
000074c379dd7ebf  vmovaps [rsp+0x30], xmm3
000074c379dd7ec5  vmovaps [rsp+0x40], xmm4
000074c379dd7ecb  vmovaps [rsp+0x50], xmm5
000074c379dd7ed1  vmovaps [rsp+0x60], xmm6
000074c379dd7ed7  vmovaps [rsp+0x70], xmm7
000074c379dd7edd  vmovaps [rsp+0x80], xmm8
000074c379dd7ee6  vmovaps [rsp+0x90], xmm9
000074c379dd7eef  vmovaps [rsp+0xA0], xmm10
000074c379dd7ef8  vmovaps [rsp+0xB0], xmm11
000074c379dd7f01  vmovaps [rsp+0xC0], xmm12
000074c379dd7f0a  vmovaps [rsp+0xD0], xmm13
000074c379dd7f13  vmovaps [rsp+0xE0], xmm14
000074c379dd7f1c  sub rsp, 0x30
000074c379dd7f20  movaps [rsp], xmm15
000074c379dd7f25  movaps [rsp+0x10], xmm5
000074c379dd7f2a  movaps [rsp+0x20], xmm3
000074c379dd7f2f  lea rdi, [rsp]
000074c379dd7f33  mov esi, 0x00
000074c379dd7f38  mov rax, 0x56321ABA4530
000074c379dd7f42  call rax
000074c379dd7f44  movaps xmm15, [rsp]
000074c379dd7f49  add rsp, 0x30
000074c379dd7f4d  vmovaps xmm0, [rsp]
000074c379dd7f52  vmovaps xmm1, [rsp+0x10]
000074c379dd7f58  vmovaps xmm2, [rsp+0x20]
000074c379dd7f5e  vmovaps xmm3, [rsp+0x30]
000074c379dd7f64  vmovaps xmm4, [rsp+0x40]
000074c379dd7f6a  vmovaps xmm5, [rsp+0x50]
000074c379dd7f70  vmovaps xmm6, [rsp+0x60]
000074c379dd7f76  vmovaps xmm7, [rsp+0x70]
000074c379dd7f7c  vmovaps xmm8, [rsp+0x80]
000074c379dd7f85  vmovaps xmm9, [rsp+0x90]
000074c379dd7f8e  vmovaps xmm10, [rsp+0xA0]
000074c379dd7f97  vmovaps xmm11, [rsp+0xB0]
000074c379dd7fa0  vmovaps xmm12, [rsp+0xC0]
000074c379dd7fa9  vmovaps xmm13, [rsp+0xD0]
000074c379dd7fb2  vmovaps xmm14, [rsp+0xE0]
000074c379dd7fbb  add rsp, 0xF0
000074c379dd7fc2  pop r11
000074c379dd7fc4  pop r10
000074c379dd7fc6  pop r9
000074c379dd7fc8  pop r8
000074c379dd7fca  pop rsi
000074c379dd7fcb  pop rdi
000074c379dd7fcc  pop rdx
000074c379dd7fcd  pop rcx
000074c379dd7fce  pop rax
000074c379dd7fcf  add rsp, 0x08
000074c379dd7fd3  jmp 0x000074C379DD5EE6
000074c379dd7fd8  sub rsp, 0x08
000074c379dd7fdc  push rax
000074c379dd7fdd  push rcx
000074c379dd7fde  push rdx
000074c379dd7fdf  push rdi
000074c379dd7fe0  push rsi
000074c379dd7fe1  push r8
000074c379dd7fe3  push r9
000074c379dd7fe5  push r10
000074c379dd7fe7  push r11
000074c379dd7fe9  sub rsp, 0xF0
000074c379dd7ff0  vmovaps [rsp], xmm0
000074c379dd7ff5  vmovaps [rsp+0x10], xmm2
000074c379dd7ffb  vmovaps [rsp+0x20], xmm3
000074c379dd8001  vmovaps [rsp+0x30], xmm4
000074c379dd8007  vmovaps [rsp+0x40], xmm5
000074c379dd800d  vmovaps [rsp+0x50], xmm6
000074c379dd8013  vmovaps [rsp+0x60], xmm7
000074c379dd8019  vmovaps [rsp+0x70], xmm8
000074c379dd801f  vmovaps [rsp+0x80], xmm9
000074c379dd8028  vmovaps [rsp+0x90], xmm10
000074c379dd8031  vmovaps [rsp+0xA0], xmm11
000074c379dd803a  vmovaps [rsp+0xB0], xmm12
000074c379dd8043  vmovaps [rsp+0xC0], xmm13
000074c379dd804c  vmovaps [rsp+0xD0], xmm14
000074c379dd8055  vmovaps [rsp+0xE0], xmm15
000074c379dd805e  sub rsp, 0x30
000074c379dd8062  movaps [rsp], xmm1
000074c379dd8066  movaps [rsp+0x10], xmm5
000074c379dd806b  movaps [rsp+0x20], xmm4
000074c379dd8070  lea rdi, [rsp]
000074c379dd8074  mov esi, 0x00
000074c379dd8079  mov rax, 0x56321ABA4530
000074c379dd8083  call rax
000074c379dd8085  movaps xmm1, [rsp]
000074c379dd8089  add rsp, 0x30
000074c379dd808d  vmovaps xmm0, [rsp]
000074c379dd8092  vmovaps xmm2, [rsp+0x10]
000074c379dd8098  vmovaps xmm3, [rsp+0x20]
000074c379dd809e  vmovaps xmm4, [rsp+0x30]
000074c379dd80a4  vmovaps xmm5, [rsp+0x40]
000074c379dd80aa  vmovaps xmm6, [rsp+0x50]
000074c379dd80b0  vmovaps xmm7, [rsp+0x60]
000074c379dd80b6  vmovaps xmm8, [rsp+0x70]
000074c379dd80bc  vmovaps xmm9, [rsp+0x80]
000074c379dd80c5  vmovaps xmm10, [rsp+0x90]
000074c379dd80ce  vmovaps xmm11, [rsp+0xA0]
000074c379dd80d7  vmovaps xmm12, [rsp+0xB0]
000074c379dd80e0  vmovaps xmm13, [rsp+0xC0]
000074c379dd80e9  vmovaps xmm14, [rsp+0xD0]
000074c379dd80f2  vmovaps xmm15, [rsp+0xE0]
000074c379dd80fb  add rsp, 0xF0
000074c379dd8102  pop r11
000074c379dd8104  pop r10
000074c379dd8106  pop r9
000074c379dd8108  pop r8
000074c379dd810a  pop rsi
000074c379dd810b  pop rdi
000074c379dd810c  pop rdx
000074c379dd810d  pop rcx
000074c379dd810e  pop rax
000074c379dd810f  add rsp, 0x08
000074c379dd8113  jmp 0x000074C379DD5F06
000074c379dd8118  sub rsp, 0x08
000074c379dd811c  push rax
000074c379dd811d  push rcx
000074c379dd811e  push rdx
000074c379dd811f  push rdi
000074c379dd8120  push rsi
000074c379dd8121  push r8
000074c379dd8123  push r9
000074c379dd8125  push r10
000074c379dd8127  push r11
000074c379dd8129  sub rsp, 0xF0
000074c379dd8130  vmovaps [rsp], xmm0
000074c379dd8135  vmovaps [rsp+0x10], xmm1
000074c379dd813b  vmovaps [rsp+0x20], xmm2
000074c379dd8141  vmovaps [rsp+0x30], xmm3
000074c379dd8147  vmovaps [rsp+0x40], xmm5
000074c379dd814d  vmovaps [rsp+0x50], xmm6
000074c379dd8153  vmovaps [rsp+0x60], xmm7
000074c379dd8159  vmovaps [rsp+0x70], xmm8
000074c379dd815f  vmovaps [rsp+0x80], xmm9
000074c379dd8168  vmovaps [rsp+0x90], xmm10
000074c379dd8171  vmovaps [rsp+0xA0], xmm11
000074c379dd817a  vmovaps [rsp+0xB0], xmm12
000074c379dd8183  vmovaps [rsp+0xC0], xmm13
000074c379dd818c  vmovaps [rsp+0xD0], xmm14
000074c379dd8195  vmovaps [rsp+0xE0], xmm15
000074c379dd819e  sub rsp, 0x30
000074c379dd81a2  movaps [rsp], xmm4
000074c379dd81a6  movaps [rsp+0x10], xmm3
000074c379dd81ab  movaps [rsp+0x20], xmm5
000074c379dd81b0  lea rdi, [rsp]
000074c379dd81b4  mov esi, 0x00
000074c379dd81b9  mov rax, 0x56321ABA4530
000074c379dd81c3  call rax
000074c379dd81c5  movaps xmm4, [rsp]
000074c379dd81c9  add rsp, 0x30
000074c379dd81cd  vmovaps xmm0, [rsp]
000074c379dd81d2  vmovaps xmm1, [rsp+0x10]
000074c379dd81d8  vmovaps xmm2, [rsp+0x20]
000074c379dd81de  vmovaps xmm3, [rsp+0x30]
000074c379dd81e4  vmovaps xmm5, [rsp+0x40]
000074c379dd81ea  vmovaps xmm6, [rsp+0x50]
000074c379dd81f0  vmovaps xmm7, [rsp+0x60]
000074c379dd81f6  vmovaps xmm8, [rsp+0x70]
000074c379dd81fc  vmovaps xmm9, [rsp+0x80]
000074c379dd8205  vmovaps xmm10, [rsp+0x90]
000074c379dd820e  vmovaps xmm11, [rsp+0xA0]
000074c379dd8217  vmovaps xmm12, [rsp+0xB0]
000074c379dd8220  vmovaps xmm13, [rsp+0xC0]
000074c379dd8229  vmovaps xmm14, [rsp+0xD0]
000074c379dd8232  vmovaps xmm15, [rsp+0xE0]
000074c379dd823b  add rsp, 0xF0
000074c379dd8242  pop r11
000074c379dd8244  pop r10
000074c379dd8246  pop r9
000074c379dd8248  pop r8
000074c379dd824a  pop rsi
000074c379dd824b  pop rdi
000074c379dd824c  pop rdx
000074c379dd824d  pop rcx
000074c379dd824e  pop rax
000074c379dd824f  add rsp, 0x08
000074c379dd8253  jmp 0x000074C379DD5F54
000074c379dd8258  call 0x000074C379CD64F0
000074c379dd825d  jmp 0x000074C379DD5F61
000074c379dd8262  sub rsp, 0x08
000074c379dd8266  push rax
000074c379dd8267  push rcx
000074c379dd8268  push rdx
000074c379dd8269  push rdi
000074c379dd826a  push rsi
000074c379dd826b  push r8
000074c379dd826d  push r9
000074c379dd826f  push r10
000074c379dd8271  push r11
000074c379dd8273  sub rsp, 0xF0
000074c379dd827a  vmovaps [rsp], xmm0
000074c379dd827f  vmovaps [rsp+0x10], xmm1
000074c379dd8285  vmovaps [rsp+0x20], xmm2
000074c379dd828b  vmovaps [rsp+0x30], xmm3
000074c379dd8291  vmovaps [rsp+0x40], xmm4
000074c379dd8297  vmovaps [rsp+0x50], xmm6
000074c379dd829d  vmovaps [rsp+0x60], xmm7
000074c379dd82a3  vmovaps [rsp+0x70], xmm8
000074c379dd82a9  vmovaps [rsp+0x80], xmm9
000074c379dd82b2  vmovaps [rsp+0x90], xmm10
000074c379dd82bb  vmovaps [rsp+0xA0], xmm11
000074c379dd82c4  vmovaps [rsp+0xB0], xmm12
000074c379dd82cd  vmovaps [rsp+0xC0], xmm13
000074c379dd82d6  vmovaps [rsp+0xD0], xmm14
000074c379dd82df  vmovaps [rsp+0xE0], xmm15
000074c379dd82e8  sub rsp, 0x30
000074c379dd82ec  movaps [rsp], xmm5
000074c379dd82f0  movaps [rsp+0x10], xmm6
000074c379dd82f5  movaps [rsp+0x20], xmm3
000074c379dd82fa  lea rdi, [rsp]
000074c379dd82fe  mov esi, 0x00
000074c379dd8303  mov rax, 0x56321ABA4530
000074c379dd830d  call rax
000074c379dd830f  movaps xmm5, [rsp]
000074c379dd8313  add rsp, 0x30
000074c379dd8317  vmovaps xmm0, [rsp]
000074c379dd831c  vmovaps xmm1, [rsp+0x10]
000074c379dd8322  vmovaps xmm2, [rsp+0x20]
000074c379dd8328  vmovaps xmm3, [rsp+0x30]
000074c379dd832e  vmovaps xmm4, [rsp+0x40]
000074c379dd8334  vmovaps xmm6, [rsp+0x50]
000074c379dd833a  vmovaps xmm7, [rsp+0x60]
000074c379dd8340  vmovaps xmm8, [rsp+0x70]
000074c379dd8346  vmovaps xmm9, [rsp+0x80]
000074c379dd834f  vmovaps xmm10, [rsp+0x90]
000074c379dd8358  vmovaps xmm11, [rsp+0xA0]
000074c379dd8361  vmovaps xmm12, [rsp+0xB0]
000074c379dd836a  vmovaps xmm13, [rsp+0xC0]
000074c379dd8373  vmovaps xmm14, [rsp+0xD0]
000074c379dd837c  vmovaps xmm15, [rsp+0xE0]
000074c379dd8385  add rsp, 0xF0
000074c379dd838c  pop r11
000074c379dd838e  pop r10
000074c379dd8390  pop r9
000074c379dd8392  pop r8
000074c379dd8394  pop rsi
000074c379dd8395  pop rdi
000074c379dd8396  pop rdx
000074c379dd8397  pop rcx
000074c379dd8398  pop rax
000074c379dd8399  add rsp, 0x08
000074c379dd839d  jmp 0x000074C379DD5F87
000074c379dd83a2  sub rsp, 0x08
000074c379dd83a6  push rax
000074c379dd83a7  push rcx
000074c379dd83a8  push rdx
000074c379dd83a9  push rdi
000074c379dd83aa  push rsi
000074c379dd83ab  push r8
000074c379dd83ad  push r9
000074c379dd83af  push r10
000074c379dd83b1  push r11
000074c379dd83b3  sub rsp, 0xF0
000074c379dd83ba  vmovaps [rsp], xmm0
000074c379dd83bf  vmovaps [rsp+0x10], xmm1
000074c379dd83c5  vmovaps [rsp+0x20], xmm2
000074c379dd83cb  vmovaps [rsp+0x30], xmm3
000074c379dd83d1  vmovaps [rsp+0x40], xmm4
000074c379dd83d7  vmovaps [rsp+0x50], xmm5
000074c379dd83dd  vmovaps [rsp+0x60], xmm7
000074c379dd83e3  vmovaps [rsp+0x70], xmm8
000074c379dd83e9  vmovaps [rsp+0x80], xmm9
000074c379dd83f2  vmovaps [rsp+0x90], xmm10
000074c379dd83fb  vmovaps [rsp+0xA0], xmm11
000074c379dd8404  vmovaps [rsp+0xB0], xmm12
000074c379dd840d  vmovaps [rsp+0xC0], xmm13
000074c379dd8416  vmovaps [rsp+0xD0], xmm14
000074c379dd841f  vmovaps [rsp+0xE0], xmm15
000074c379dd8428  sub rsp, 0x30
000074c379dd842c  movaps [rsp], xmm6
000074c379dd8430  movaps [rsp+0x10], xmm9
000074c379dd8436  movaps [rsp+0x20], xmm1
000074c379dd843b  lea rdi, [rsp]
000074c379dd843f  mov esi, 0x00
000074c379dd8444  mov rax, 0x56321ABA4530
000074c379dd844e  call rax
000074c379dd8450  movaps xmm6, [rsp]
000074c379dd8454  add rsp, 0x30
000074c379dd8458  vmovaps xmm0, [rsp]
000074c379dd845d  vmovaps xmm1, [rsp+0x10]
000074c379dd8463  vmovaps xmm2, [rsp+0x20]
000074c379dd8469  vmovaps xmm3, [rsp+0x30]
000074c379dd846f  vmovaps xmm4, [rsp+0x40]
000074c379dd8475  vmovaps xmm5, [rsp+0x50]
000074c379dd847b  vmovaps xmm7, [rsp+0x60]
000074c379dd8481  vmovaps xmm8, [rsp+0x70]
000074c379dd8487  vmovaps xmm9, [rsp+0x80]
000074c379dd8490  vmovaps xmm10, [rsp+0x90]
000074c379dd8499  vmovaps xmm11, [rsp+0xA0]
000074c379dd84a2  vmovaps xmm12, [rsp+0xB0]
000074c379dd84ab  vmovaps xmm13, [rsp+0xC0]
000074c379dd84b4  vmovaps xmm14, [rsp+0xD0]
000074c379dd84bd  vmovaps xmm15, [rsp+0xE0]
000074c379dd84c6  add rsp, 0xF0
000074c379dd84cd  pop r11
000074c379dd84cf  pop r10
000074c379dd84d1  pop r9
000074c379dd84d3  pop r8
000074c379dd84d5  pop rsi
000074c379dd84d6  pop rdi
000074c379dd84d7  pop rdx
000074c379dd84d8  pop rcx
000074c379dd84d9  pop rax
000074c379dd84da  add rsp, 0x08
000074c379dd84de  jmp 0x000074C379DD5FAB
000074c379dd84e3  sub rsp, 0x08
000074c379dd84e7  push rax
000074c379dd84e8  push rcx
000074c379dd84e9  push rdx
000074c379dd84ea  push rdi
000074c379dd84eb  push rsi
000074c379dd84ec  push r8
000074c379dd84ee  push r9
000074c379dd84f0  push r10
000074c379dd84f2  push r11
000074c379dd84f4  sub rsp, 0xF0
000074c379dd84fb  vmovaps [rsp], xmm0
000074c379dd8500  vmovaps [rsp+0x10], xmm1
000074c379dd8506  vmovaps [rsp+0x20], xmm2
000074c379dd850c  vmovaps [rsp+0x30], xmm3
000074c379dd8512  vmovaps [rsp+0x40], xmm4
000074c379dd8518  vmovaps [rsp+0x50], xmm5
000074c379dd851e  vmovaps [rsp+0x60], xmm6
000074c379dd8524  vmovaps [rsp+0x70], xmm7
000074c379dd852a  vmovaps [rsp+0x80], xmm8
000074c379dd8533  vmovaps [rsp+0x90], xmm10
000074c379dd853c  vmovaps [rsp+0xA0], xmm11
000074c379dd8545  vmovaps [rsp+0xB0], xmm12
000074c379dd854e  vmovaps [rsp+0xC0], xmm13
000074c379dd8557  vmovaps [rsp+0xD0], xmm14
000074c379dd8560  vmovaps [rsp+0xE0], xmm15
000074c379dd8569  sub rsp, 0x30
000074c379dd856d  movaps [rsp], xmm9
000074c379dd8572  movaps [rsp+0x10], xmm3
000074c379dd8577  movaps [rsp+0x20], xmm1
000074c379dd857c  lea rdi, [rsp]
000074c379dd8580  mov esi, 0x00
000074c379dd8585  mov rax, 0x56321ABA4530
000074c379dd858f  call rax
000074c379dd8591  movaps xmm9, [rsp]
000074c379dd8596  add rsp, 0x30
000074c379dd859a  vmovaps xmm0, [rsp]
000074c379dd859f  vmovaps xmm1, [rsp+0x10]
000074c379dd85a5  vmovaps xmm2, [rsp+0x20]
000074c379dd85ab  vmovaps xmm3, [rsp+0x30]
000074c379dd85b1  vmovaps xmm4, [rsp+0x40]
000074c379dd85b7  vmovaps xmm5, [rsp+0x50]
000074c379dd85bd  vmovaps xmm6, [rsp+0x60]
000074c379dd85c3  vmovaps xmm7, [rsp+0x70]
000074c379dd85c9  vmovaps xmm8, [rsp+0x80]
000074c379dd85d2  vmovaps xmm10, [rsp+0x90]
000074c379dd85db  vmovaps xmm11, [rsp+0xA0]
000074c379dd85e4  vmovaps xmm12, [rsp+0xB0]
000074c379dd85ed  vmovaps xmm13, [rsp+0xC0]
000074c379dd85f6  vmovaps xmm14, [rsp+0xD0]
000074c379dd85ff  vmovaps xmm15, [rsp+0xE0]
000074c379dd8608  add rsp, 0xF0
000074c379dd860f  pop r11
000074c379dd8611  pop r10
000074c379dd8613  pop r9
000074c379dd8615  pop r8
000074c379dd8617  pop rsi
000074c379dd8618  pop rdi
000074c379dd8619  pop rdx
000074c379dd861a  pop rcx
000074c379dd861b  pop rax
000074c379dd861c  add rsp, 0x08
000074c379dd8620  jmp 0x000074C379DD5FF7
000074c379dd8625  call 0x000074C379CD64F0
000074c379dd862a  jmp 0x000074C379DD6004
000074c379dd862f  sub rsp, 0x08
000074c379dd8633  push rax
000074c379dd8634  push rcx
000074c379dd8635  push rdx
000074c379dd8636  push rdi
000074c379dd8637  push rsi
000074c379dd8638  push r8
000074c379dd863a  push r9
000074c379dd863c  push r10
000074c379dd863e  push r11
000074c379dd8640  sub rsp, 0xF0
000074c379dd8647  vmovaps [rsp], xmm0
000074c379dd864c  vmovaps [rsp+0x10], xmm1
000074c379dd8652  vmovaps [rsp+0x20], xmm2
000074c379dd8658  vmovaps [rsp+0x30], xmm3
000074c379dd865e  vmovaps [rsp+0x40], xmm4
000074c379dd8664  vmovaps [rsp+0x50], xmm5
000074c379dd866a  vmovaps [rsp+0x60], xmm6
000074c379dd8670  vmovaps [rsp+0x70], xmm7
000074c379dd8676  vmovaps [rsp+0x80], xmm8
000074c379dd867f  vmovaps [rsp+0x90], xmm9
000074c379dd8688  vmovaps [rsp+0xA0], xmm10
000074c379dd8691  vmovaps [rsp+0xB0], xmm11
000074c379dd869a  vmovaps [rsp+0xC0], xmm12
000074c379dd86a3  vmovaps [rsp+0xD0], xmm13
000074c379dd86ac  vmovaps [rsp+0xE0], xmm14
000074c379dd86b5  sub rsp, 0x30
000074c379dd86b9  movaps [rsp], xmm15
000074c379dd86be  movaps [rsp+0x10], xmm3
000074c379dd86c3  movaps [rsp+0x20], xmm7
000074c379dd86c8  lea rdi, [rsp]
000074c379dd86cc  mov esi, 0x00
000074c379dd86d1  mov rax, 0x56321ABA4530
000074c379dd86db  call rax
000074c379dd86dd  movaps xmm15, [rsp]
000074c379dd86e2  add rsp, 0x30
000074c379dd86e6  vmovaps xmm0, [rsp]
000074c379dd86eb  vmovaps xmm1, [rsp+0x10]
000074c379dd86f1  vmovaps xmm2, [rsp+0x20]
000074c379dd86f7  vmovaps xmm3, [rsp+0x30]
000074c379dd86fd  vmovaps xmm4, [rsp+0x40]
000074c379dd8703  vmovaps xmm5, [rsp+0x50]
000074c379dd8709  vmovaps xmm6, [rsp+0x60]
000074c379dd870f  vmovaps xmm7, [rsp+0x70]
000074c379dd8715  vmovaps xmm8, [rsp+0x80]
000074c379dd871e  vmovaps xmm9, [rsp+0x90]
000074c379dd8727  vmovaps xmm10, [rsp+0xA0]
000074c379dd8730  vmovaps xmm11, [rsp+0xB0]
000074c379dd8739  vmovaps xmm12, [rsp+0xC0]
000074c379dd8742  vmovaps xmm13, [rsp+0xD0]
000074c379dd874b  vmovaps xmm14, [rsp+0xE0]
000074c379dd8754  add rsp, 0xF0
000074c379dd875b  pop r11
000074c379dd875d  pop r10
000074c379dd875f  pop r9
000074c379dd8761  pop r8
000074c379dd8763  pop rsi
000074c379dd8764  pop rdi
000074c379dd8765  pop rdx
000074c379dd8766  pop rcx
000074c379dd8767  pop rax
000074c379dd8768  add rsp, 0x08
000074c379dd876c  jmp 0x000074C379DD6030
000074c379dd8771  sub rsp, 0x08
000074c379dd8775  push rax
000074c379dd8776  push rcx
000074c379dd8777  push rdx
000074c379dd8778  push rdi
000074c379dd8779  push rsi
000074c379dd877a  push r8
000074c379dd877c  push r9
000074c379dd877e  push r10
000074c379dd8780  push r11
000074c379dd8782  sub rsp, 0xF0
000074c379dd8789  vmovaps [rsp], xmm0
000074c379dd878e  vmovaps [rsp+0x10], xmm1
000074c379dd8794  vmovaps [rsp+0x20], xmm2
000074c379dd879a  vmovaps [rsp+0x30], xmm4
000074c379dd87a0  vmovaps [rsp+0x40], xmm5
000074c379dd87a6  vmovaps [rsp+0x50], xmm6
000074c379dd87ac  vmovaps [rsp+0x60], xmm7
000074c379dd87b2  vmovaps [rsp+0x70], xmm8
000074c379dd87b8  vmovaps [rsp+0x80], xmm9
000074c379dd87c1  vmovaps [rsp+0x90], xmm10
000074c379dd87ca  vmovaps [rsp+0xA0], xmm11
000074c379dd87d3  vmovaps [rsp+0xB0], xmm12
000074c379dd87dc  vmovaps [rsp+0xC0], xmm13
000074c379dd87e5  vmovaps [rsp+0xD0], xmm14
000074c379dd87ee  vmovaps [rsp+0xE0], xmm15
000074c379dd87f7  sub rsp, 0x30
000074c379dd87fb  movaps [rsp], xmm3
000074c379dd87ff  movaps [rsp+0x10], xmm1
000074c379dd8804  movaps [rsp+0x20], xmm15
000074c379dd880a  lea rdi, [rsp]
000074c379dd880e  mov esi, 0x00
000074c379dd8813  mov rax, 0x56321ABA4530
000074c379dd881d  call rax
000074c379dd881f  movaps xmm3, [rsp]
000074c379dd8823  add rsp, 0x30
000074c379dd8827  vmovaps xmm0, [rsp]
000074c379dd882c  vmovaps xmm1, [rsp+0x10]
000074c379dd8832  vmovaps xmm2, [rsp+0x20]
000074c379dd8838  vmovaps xmm4, [rsp+0x30]
000074c379dd883e  vmovaps xmm5, [rsp+0x40]
000074c379dd8844  vmovaps xmm6, [rsp+0x50]
000074c379dd884a  vmovaps xmm7, [rsp+0x60]
000074c379dd8850  vmovaps xmm8, [rsp+0x70]
000074c379dd8856  vmovaps xmm9, [rsp+0x80]
000074c379dd885f  vmovaps xmm10, [rsp+0x90]
000074c379dd8868  vmovaps xmm11, [rsp+0xA0]
000074c379dd8871  vmovaps xmm12, [rsp+0xB0]
000074c379dd887a  vmovaps xmm13, [rsp+0xC0]
000074c379dd8883  vmovaps xmm14, [rsp+0xD0]
000074c379dd888c  vmovaps xmm15, [rsp+0xE0]
000074c379dd8895  add rsp, 0xF0
000074c379dd889c  pop r11
000074c379dd889e  pop r10
000074c379dd88a0  pop r9
000074c379dd88a2  pop r8
000074c379dd88a4  pop rsi
000074c379dd88a5  pop rdi
000074c379dd88a6  pop rdx
000074c379dd88a7  pop rcx
000074c379dd88a8  pop rax
000074c379dd88a9  add rsp, 0x08
000074c379dd88ad  jmp 0x000074C379DD60BF
000074c379dd88b2  call 0x000074C379CD64F0
000074c379dd88b7  jmp 0x000074C379DD60C9
000074c379dd88bc  sub rsp, 0x08
000074c379dd88c0  push rax
000074c379dd88c1  push rcx
000074c379dd88c2  push rdx
000074c379dd88c3  push rdi
000074c379dd88c4  push rsi
000074c379dd88c5  push r8
000074c379dd88c7  push r9
000074c379dd88c9  push r10
000074c379dd88cb  push r11
000074c379dd88cd  sub rsp, 0xF0
000074c379dd88d4  vmovaps [rsp], xmm0
000074c379dd88d9  vmovaps [rsp+0x10], xmm1
000074c379dd88df  vmovaps [rsp+0x20], xmm2
000074c379dd88e5  vmovaps [rsp+0x30], xmm3
000074c379dd88eb  vmovaps [rsp+0x40], xmm4
000074c379dd88f1  vmovaps [rsp+0x50], xmm5
000074c379dd88f7  vmovaps [rsp+0x60], xmm6
000074c379dd88fd  vmovaps [rsp+0x70], xmm7
000074c379dd8903  vmovaps [rsp+0x80], xmm8
000074c379dd890c  vmovaps [rsp+0x90], xmm9
000074c379dd8915  vmovaps [rsp+0xA0], xmm10
000074c379dd891e  vmovaps [rsp+0xB0], xmm11
000074c379dd8927  vmovaps [rsp+0xC0], xmm12
000074c379dd8930  vmovaps [rsp+0xD0], xmm13
000074c379dd8939  vmovaps [rsp+0xE0], xmm14
000074c379dd8942  sub rsp, 0x30
000074c379dd8946  movaps [rsp], xmm15
000074c379dd894b  movaps [rsp+0x10], xmm14
000074c379dd8951  movaps [rsp+0x20], xmm4
000074c379dd8956  lea rdi, [rsp]
000074c379dd895a  mov esi, 0x00
000074c379dd895f  mov rax, 0x56321ABA4530
000074c379dd8969  call rax
000074c379dd896b  movaps xmm15, [rsp]
000074c379dd8970  add rsp, 0x30
000074c379dd8974  vmovaps xmm0, [rsp]
000074c379dd8979  vmovaps xmm1, [rsp+0x10]
000074c379dd897f  vmovaps xmm2, [rsp+0x20]
000074c379dd8985  vmovaps xmm3, [rsp+0x30]
000074c379dd898b  vmovaps xmm4, [rsp+0x40]
000074c379dd8991  vmovaps xmm5, [rsp+0x50]
000074c379dd8997  vmovaps xmm6, [rsp+0x60]
000074c379dd899d  vmovaps xmm7, [rsp+0x70]
000074c379dd89a3  vmovaps xmm8, [rsp+0x80]
000074c379dd89ac  vmovaps xmm9, [rsp+0x90]
000074c379dd89b5  vmovaps xmm10, [rsp+0xA0]
000074c379dd89be  vmovaps xmm11, [rsp+0xB0]
000074c379dd89c7  vmovaps xmm12, [rsp+0xC0]
000074c379dd89d0  vmovaps xmm13, [rsp+0xD0]
000074c379dd89d9  vmovaps xmm14, [rsp+0xE0]
000074c379dd89e2  add rsp, 0xF0
000074c379dd89e9  pop r11
000074c379dd89eb  pop r10
000074c379dd89ed  pop r9
000074c379dd89ef  pop r8
000074c379dd89f1  pop rsi
000074c379dd89f2  pop rdi
000074c379dd89f3  pop rdx
000074c379dd89f4  pop rcx
000074c379dd89f5  pop rax
000074c379dd89f6  add rsp, 0x08
000074c379dd89fa  jmp 0x000074C379DD60F7
000074c379dd89ff  sub rsp, 0x08
000074c379dd8a03  push rax
000074c379dd8a04  push rcx
000074c379dd8a05  push rdx
000074c379dd8a06  push rdi
000074c379dd8a07  push rsi
000074c379dd8a08  push r8
000074c379dd8a0a  push r9
000074c379dd8a0c  push r10
000074c379dd8a0e  push r11
000074c379dd8a10  sub rsp, 0xF0
000074c379dd8a17  vmovaps [rsp], xmm0
000074c379dd8a1c  vmovaps [rsp+0x10], xmm1
000074c379dd8a22  vmovaps [rsp+0x20], xmm2
000074c379dd8a28  vmovaps [rsp+0x30], xmm3
000074c379dd8a2e  vmovaps [rsp+0x40], xmm4
000074c379dd8a34  vmovaps [rsp+0x50], xmm5
000074c379dd8a3a  vmovaps [rsp+0x60], xmm6
000074c379dd8a40  vmovaps [rsp+0x70], xmm7
000074c379dd8a46  vmovaps [rsp+0x80], xmm8
000074c379dd8a4f  vmovaps [rsp+0x90], xmm9
000074c379dd8a58  vmovaps [rsp+0xA0], xmm10
000074c379dd8a61  vmovaps [rsp+0xB0], xmm11
000074c379dd8a6a  vmovaps [rsp+0xC0], xmm12
000074c379dd8a73  vmovaps [rsp+0xD0], xmm13
000074c379dd8a7c  vmovaps [rsp+0xE0], xmm15
000074c379dd8a85  sub rsp, 0x30
000074c379dd8a89  movaps [rsp], xmm14
000074c379dd8a8e  movaps [rsp+0x10], xmm2
000074c379dd8a93  movaps [rsp+0x20], xmm1
000074c379dd8a98  lea rdi, [rsp]
000074c379dd8a9c  mov esi, 0x00
000074c379dd8aa1  mov rax, 0x56321ABA4530
000074c379dd8aab  call rax
000074c379dd8aad  movaps xmm14, [rsp]
000074c379dd8ab2  add rsp, 0x30
000074c379dd8ab6  vmovaps xmm0, [rsp]
000074c379dd8abb  vmovaps xmm1, [rsp+0x10]
000074c379dd8ac1  vmovaps xmm2, [rsp+0x20]
000074c379dd8ac7  vmovaps xmm3, [rsp+0x30]
000074c379dd8acd  vmovaps xmm4, [rsp+0x40]
000074c379dd8ad3  vmovaps xmm5, [rsp+0x50]
000074c379dd8ad9  vmovaps xmm6, [rsp+0x60]
000074c379dd8adf  vmovaps xmm7, [rsp+0x70]
000074c379dd8ae5  vmovaps xmm8, [rsp+0x80]
000074c379dd8aee  vmovaps xmm9, [rsp+0x90]
000074c379dd8af7  vmovaps xmm10, [rsp+0xA0]
000074c379dd8b00  vmovaps xmm11, [rsp+0xB0]
000074c379dd8b09  vmovaps xmm12, [rsp+0xC0]
000074c379dd8b12  vmovaps xmm13, [rsp+0xD0]
000074c379dd8b1b  vmovaps xmm15, [rsp+0xE0]
000074c379dd8b24  add rsp, 0xF0
000074c379dd8b2b  pop r11
000074c379dd8b2d  pop r10
000074c379dd8b2f  pop r9
000074c379dd8b31  pop r8
000074c379dd8b33  pop rsi
000074c379dd8b34  pop rdi
000074c379dd8b35  pop rdx
000074c379dd8b36  pop rcx
000074c379dd8b37  pop rax
000074c379dd8b38  add rsp, 0x08
000074c379dd8b3c  jmp 0x000074C379DD611D
000074c379dd8b41  sub rsp, 0x08
000074c379dd8b45  push rax
000074c379dd8b46  push rcx
000074c379dd8b47  push rdx
000074c379dd8b48  push rdi
000074c379dd8b49  push rsi
000074c379dd8b4a  push r8
000074c379dd8b4c  push r9
000074c379dd8b4e  push r10
000074c379dd8b50  push r11
000074c379dd8b52  sub rsp, 0xF0
000074c379dd8b59  vmovaps [rsp], xmm0
000074c379dd8b5e  vmovaps [rsp+0x10], xmm2
000074c379dd8b64  vmovaps [rsp+0x20], xmm3
000074c379dd8b6a  vmovaps [rsp+0x30], xmm4
000074c379dd8b70  vmovaps [rsp+0x40], xmm5
000074c379dd8b76  vmovaps [rsp+0x50], xmm6
000074c379dd8b7c  vmovaps [rsp+0x60], xmm7
000074c379dd8b82  vmovaps [rsp+0x70], xmm8
000074c379dd8b88  vmovaps [rsp+0x80], xmm9
000074c379dd8b91  vmovaps [rsp+0x90], xmm10
000074c379dd8b9a  vmovaps [rsp+0xA0], xmm11
000074c379dd8ba3  vmovaps [rsp+0xB0], xmm12
000074c379dd8bac  vmovaps [rsp+0xC0], xmm13
000074c379dd8bb5  vmovaps [rsp+0xD0], xmm14
000074c379dd8bbe  vmovaps [rsp+0xE0], xmm15
000074c379dd8bc7  sub rsp, 0x30
000074c379dd8bcb  movaps [rsp], xmm1
000074c379dd8bcf  movaps [rsp+0x10], xmm4
000074c379dd8bd4  movaps [rsp+0x20], xmm9
000074c379dd8bda  lea rdi, [rsp]
000074c379dd8bde  mov esi, 0x00
000074c379dd8be3  mov rax, 0x56321ABA4530
000074c379dd8bed  call rax
000074c379dd8bef  movaps xmm1, [rsp]
000074c379dd8bf3  add rsp, 0x30
000074c379dd8bf7  vmovaps xmm0, [rsp]
000074c379dd8bfc  vmovaps xmm2, [rsp+0x10]
000074c379dd8c02  vmovaps xmm3, [rsp+0x20]
000074c379dd8c08  vmovaps xmm4, [rsp+0x30]
000074c379dd8c0e  vmovaps xmm5, [rsp+0x40]
000074c379dd8c14  vmovaps xmm6, [rsp+0x50]
000074c379dd8c1a  vmovaps xmm7, [rsp+0x60]
000074c379dd8c20  vmovaps xmm8, [rsp+0x70]
000074c379dd8c26  vmovaps xmm9, [rsp+0x80]
000074c379dd8c2f  vmovaps xmm10, [rsp+0x90]
000074c379dd8c38  vmovaps xmm11, [rsp+0xA0]
000074c379dd8c41  vmovaps xmm12, [rsp+0xB0]
000074c379dd8c4a  vmovaps xmm13, [rsp+0xC0]
000074c379dd8c53  vmovaps xmm14, [rsp+0xD0]
000074c379dd8c5c  vmovaps xmm15, [rsp+0xE0]
000074c379dd8c65  add rsp, 0xF0
000074c379dd8c6c  pop r11
000074c379dd8c6e  pop r10
000074c379dd8c70  pop r9
000074c379dd8c72  pop r8
000074c379dd8c74  pop rsi
000074c379dd8c75  pop rdi
000074c379dd8c76  pop rdx
000074c379dd8c77  pop rcx
000074c379dd8c78  pop rax
000074c379dd8c79  add rsp, 0x08
000074c379dd8c7d  jmp 0x000074C379DD613B
000074c379dd8c82  sub rsp, 0x08
000074c379dd8c86  push rax
000074c379dd8c87  push rcx
000074c379dd8c88  push rdx
000074c379dd8c89  push rdi
000074c379dd8c8a  push rsi
000074c379dd8c8b  push r8
000074c379dd8c8d  push r9
000074c379dd8c8f  push r10
000074c379dd8c91  push r11
000074c379dd8c93  sub rsp, 0xF0
000074c379dd8c9a  vmovaps [rsp], xmm0
000074c379dd8c9f  vmovaps [rsp+0x10], xmm1
000074c379dd8ca5  vmovaps [rsp+0x20], xmm2
000074c379dd8cab  vmovaps [rsp+0x30], xmm3
000074c379dd8cb1  vmovaps [rsp+0x40], xmm5
000074c379dd8cb7  vmovaps [rsp+0x50], xmm6
000074c379dd8cbd  vmovaps [rsp+0x60], xmm7
000074c379dd8cc3  vmovaps [rsp+0x70], xmm8
000074c379dd8cc9  vmovaps [rsp+0x80], xmm9
000074c379dd8cd2  vmovaps [rsp+0x90], xmm10
000074c379dd8cdb  vmovaps [rsp+0xA0], xmm11
000074c379dd8ce4  vmovaps [rsp+0xB0], xmm12
000074c379dd8ced  vmovaps [rsp+0xC0], xmm13
000074c379dd8cf6  vmovaps [rsp+0xD0], xmm14
000074c379dd8cff  vmovaps [rsp+0xE0], xmm15
000074c379dd8d08  sub rsp, 0x30
000074c379dd8d0c  movaps [rsp], xmm4
000074c379dd8d10  movaps [rsp+0x10], xmm2
000074c379dd8d15  movaps [rsp+0x20], xmm9
000074c379dd8d1b  lea rdi, [rsp]
000074c379dd8d1f  mov esi, 0x00
000074c379dd8d24  mov rax, 0x56321ABA4530
000074c379dd8d2e  call rax
000074c379dd8d30  movaps xmm4, [rsp]
000074c379dd8d34  add rsp, 0x30
000074c379dd8d38  vmovaps xmm0, [rsp]
000074c379dd8d3d  vmovaps xmm1, [rsp+0x10]
000074c379dd8d43  vmovaps xmm2, [rsp+0x20]
000074c379dd8d49  vmovaps xmm3, [rsp+0x30]
000074c379dd8d4f  vmovaps xmm5, [rsp+0x40]
000074c379dd8d55  vmovaps xmm6, [rsp+0x50]
000074c379dd8d5b  vmovaps xmm7, [rsp+0x60]
000074c379dd8d61  vmovaps xmm8, [rsp+0x70]
000074c379dd8d67  vmovaps xmm9, [rsp+0x80]
000074c379dd8d70  vmovaps xmm10, [rsp+0x90]
000074c379dd8d79  vmovaps xmm11, [rsp+0xA0]
000074c379dd8d82  vmovaps xmm12, [rsp+0xB0]
000074c379dd8d8b  vmovaps xmm13, [rsp+0xC0]
000074c379dd8d94  vmovaps xmm14, [rsp+0xD0]
000074c379dd8d9d  vmovaps xmm15, [rsp+0xE0]
000074c379dd8da6  add rsp, 0xF0
000074c379dd8dad  pop r11
000074c379dd8daf  pop r10
000074c379dd8db1  pop r9
000074c379dd8db3  pop r8
000074c379dd8db5  pop rsi
000074c379dd8db6  pop rdi
000074c379dd8db7  pop rdx
000074c379dd8db8  pop rcx
000074c379dd8db9  pop rax
000074c379dd8dba  add rsp, 0x08
000074c379dd8dbe  jmp 0x000074C379DD616B
000074c379dd8dc3  sub rsp, 0x08
000074c379dd8dc7  push rax
000074c379dd8dc8  push rcx
000074c379dd8dc9  push rdx
000074c379dd8dca  push rdi
000074c379dd8dcb  push rsi
000074c379dd8dcc  push r8
000074c379dd8dce  push r9
000074c379dd8dd0  push r10
000074c379dd8dd2  push r11
000074c379dd8dd4  sub rsp, 0xF0
000074c379dd8ddb  vmovaps [rsp], xmm0
000074c379dd8de0  vmovaps [rsp+0x10], xmm1
000074c379dd8de6  vmovaps [rsp+0x20], xmm2
000074c379dd8dec  vmovaps [rsp+0x30], xmm3
000074c379dd8df2  vmovaps [rsp+0x40], xmm4
000074c379dd8df8  vmovaps [rsp+0x50], xmm5
000074c379dd8dfe  vmovaps [rsp+0x60], xmm6
000074c379dd8e04  vmovaps [rsp+0x70], xmm7
000074c379dd8e0a  vmovaps [rsp+0x80], xmm8
000074c379dd8e13  vmovaps [rsp+0x90], xmm10
000074c379dd8e1c  vmovaps [rsp+0xA0], xmm11
000074c379dd8e25  vmovaps [rsp+0xB0], xmm12
000074c379dd8e2e  vmovaps [rsp+0xC0], xmm13
000074c379dd8e37  vmovaps [rsp+0xD0], xmm14
000074c379dd8e40  vmovaps [rsp+0xE0], xmm15
000074c379dd8e49  sub rsp, 0x30
000074c379dd8e4d  movaps [rsp], xmm9
000074c379dd8e52  movaps [rsp+0x10], xmm2
000074c379dd8e57  movaps [rsp+0x20], xmm1
000074c379dd8e5c  lea rdi, [rsp]
000074c379dd8e60  mov esi, 0x00
000074c379dd8e65  mov rax, 0x56321ABA4530
000074c379dd8e6f  call rax
000074c379dd8e71  movaps xmm9, [rsp]
000074c379dd8e76  add rsp, 0x30
000074c379dd8e7a  vmovaps xmm0, [rsp]
000074c379dd8e7f  vmovaps xmm1, [rsp+0x10]
000074c379dd8e85  vmovaps xmm2, [rsp+0x20]
000074c379dd8e8b  vmovaps xmm3, [rsp+0x30]
000074c379dd8e91  vmovaps xmm4, [rsp+0x40]
000074c379dd8e97  vmovaps xmm5, [rsp+0x50]
000074c379dd8e9d  vmovaps xmm6, [rsp+0x60]
000074c379dd8ea3  vmovaps xmm7, [rsp+0x70]
000074c379dd8ea9  vmovaps xmm8, [rsp+0x80]
000074c379dd8eb2  vmovaps xmm10, [rsp+0x90]
000074c379dd8ebb  vmovaps xmm11, [rsp+0xA0]
000074c379dd8ec4  vmovaps xmm12, [rsp+0xB0]
000074c379dd8ecd  vmovaps xmm13, [rsp+0xC0]
000074c379dd8ed6  vmovaps xmm14, [rsp+0xD0]
000074c379dd8edf  vmovaps xmm15, [rsp+0xE0]
000074c379dd8ee8  add rsp, 0xF0
000074c379dd8eef  pop r11
000074c379dd8ef1  pop r10
000074c379dd8ef3  pop r9
000074c379dd8ef5  pop r8
000074c379dd8ef7  pop rsi
000074c379dd8ef8  pop rdi
000074c379dd8ef9  pop rdx
000074c379dd8efa  pop rcx
000074c379dd8efb  pop rax
000074c379dd8efc  add rsp, 0x08
000074c379dd8f00  jmp 0x000074C379DD61A1
000074c379dd8f05  sub rsp, 0x08
000074c379dd8f09  push rax
000074c379dd8f0a  push rcx
000074c379dd8f0b  push rdx
000074c379dd8f0c  push rdi
000074c379dd8f0d  push rsi
000074c379dd8f0e  push r8
000074c379dd8f10  push r9
000074c379dd8f12  push r10
000074c379dd8f14  push r11
000074c379dd8f16  sub rsp, 0xF0
000074c379dd8f1d  vmovaps [rsp], xmm0
000074c379dd8f22  vmovaps [rsp+0x10], xmm2
000074c379dd8f28  vmovaps [rsp+0x20], xmm3
000074c379dd8f2e  vmovaps [rsp+0x30], xmm4
000074c379dd8f34  vmovaps [rsp+0x40], xmm5
000074c379dd8f3a  vmovaps [rsp+0x50], xmm6
000074c379dd8f40  vmovaps [rsp+0x60], xmm7
000074c379dd8f46  vmovaps [rsp+0x70], xmm8
000074c379dd8f4c  vmovaps [rsp+0x80], xmm9
000074c379dd8f55  vmovaps [rsp+0x90], xmm10
000074c379dd8f5e  vmovaps [rsp+0xA0], xmm11
000074c379dd8f67  vmovaps [rsp+0xB0], xmm12
000074c379dd8f70  vmovaps [rsp+0xC0], xmm13
000074c379dd8f79  vmovaps [rsp+0xD0], xmm14
000074c379dd8f82  vmovaps [rsp+0xE0], xmm15
000074c379dd8f8b  sub rsp, 0x30
000074c379dd8f8f  movaps [rsp], xmm1
000074c379dd8f93  movaps [rsp+0x10], xmm15
000074c379dd8f99  movaps [rsp+0x20], xmm6
000074c379dd8f9e  lea rdi, [rsp]
000074c379dd8fa2  mov esi, 0x00
000074c379dd8fa7  mov rax, 0x56321ABA4530
000074c379dd8fb1  call rax
000074c379dd8fb3  movaps xmm1, [rsp]
000074c379dd8fb7  add rsp, 0x30
000074c379dd8fbb  vmovaps xmm0, [rsp]
000074c379dd8fc0  vmovaps xmm2, [rsp+0x10]
000074c379dd8fc6  vmovaps xmm3, [rsp+0x20]
000074c379dd8fcc  vmovaps xmm4, [rsp+0x30]
000074c379dd8fd2  vmovaps xmm5, [rsp+0x40]
000074c379dd8fd8  vmovaps xmm6, [rsp+0x50]
000074c379dd8fde  vmovaps xmm7, [rsp+0x60]
000074c379dd8fe4  vmovaps xmm8, [rsp+0x70]
000074c379dd8fea  vmovaps xmm9, [rsp+0x80]
000074c379dd8ff3  vmovaps xmm10, [rsp+0x90]
000074c379dd8ffc  vmovaps xmm11, [rsp+0xA0]
000074c379dd9005  vmovaps xmm12, [rsp+0xB0]
000074c379dd900e  vmovaps xmm13, [rsp+0xC0]
000074c379dd9017  vmovaps xmm14, [rsp+0xD0]
000074c379dd9020  vmovaps xmm15, [rsp+0xE0]
000074c379dd9029  add rsp, 0xF0
000074c379dd9030  pop r11
000074c379dd9032  pop r10
000074c379dd9034  pop r9
000074c379dd9036  pop r8
000074c379dd9038  pop rsi
000074c379dd9039  pop rdi
000074c379dd903a  pop rdx
000074c379dd903b  pop rcx
000074c379dd903c  pop rax
000074c379dd903d  add rsp, 0x08
000074c379dd9041  jmp 0x000074C379DD61C2
000074c379dd9046  sub rsp, 0x08
000074c379dd904a  push rax
000074c379dd904b  push rcx
000074c379dd904c  push rdx
000074c379dd904d  push rdi
000074c379dd904e  push rsi
000074c379dd904f  push r8
000074c379dd9051  push r9
000074c379dd9053  push r10
000074c379dd9055  push r11
000074c379dd9057  sub rsp, 0xF0
000074c379dd905e  vmovaps [rsp], xmm0
000074c379dd9063  vmovaps [rsp+0x10], xmm1
000074c379dd9069  vmovaps [rsp+0x20], xmm2
000074c379dd906f  vmovaps [rsp+0x30], xmm3
000074c379dd9075  vmovaps [rsp+0x40], xmm4
000074c379dd907b  vmovaps [rsp+0x50], xmm5
000074c379dd9081  vmovaps [rsp+0x60], xmm6
000074c379dd9087  vmovaps [rsp+0x70], xmm7
000074c379dd908d  vmovaps [rsp+0x80], xmm8
000074c379dd9096  vmovaps [rsp+0x90], xmm9
000074c379dd909f  vmovaps [rsp+0xA0], xmm10
000074c379dd90a8  vmovaps [rsp+0xB0], xmm11
000074c379dd90b1  vmovaps [rsp+0xC0], xmm12
000074c379dd90ba  vmovaps [rsp+0xD0], xmm13
000074c379dd90c3  vmovaps [rsp+0xE0], xmm14
000074c379dd90cc  sub rsp, 0x30
000074c379dd90d0  movaps [rsp], xmm15
000074c379dd90d5  movaps [rsp+0x10], xmm5
000074c379dd90da  movaps [rsp+0x20], xmm3
000074c379dd90df  lea rdi, [rsp]
000074c379dd90e3  mov esi, 0x00
000074c379dd90e8  mov rax, 0x56321ABA4530
000074c379dd90f2  call rax
000074c379dd90f4  movaps xmm15, [rsp]
000074c379dd90f9  add rsp, 0x30
000074c379dd90fd  vmovaps xmm0, [rsp]
000074c379dd9102  vmovaps xmm1, [rsp+0x10]
000074c379dd9108  vmovaps xmm2, [rsp+0x20]
000074c379dd910e  vmovaps xmm3, [rsp+0x30]
000074c379dd9114  vmovaps xmm4, [rsp+0x40]
000074c379dd911a  vmovaps xmm5, [rsp+0x50]
000074c379dd9120  vmovaps xmm6, [rsp+0x60]
000074c379dd9126  vmovaps xmm7, [rsp+0x70]
000074c379dd912c  vmovaps xmm8, [rsp+0x80]
000074c379dd9135  vmovaps xmm9, [rsp+0x90]
000074c379dd913e  vmovaps xmm10, [rsp+0xA0]
000074c379dd9147  vmovaps xmm11, [rsp+0xB0]
000074c379dd9150  vmovaps xmm12, [rsp+0xC0]
000074c379dd9159  vmovaps xmm13, [rsp+0xD0]
000074c379dd9162  vmovaps xmm14, [rsp+0xE0]
000074c379dd916b  add rsp, 0xF0
000074c379dd9172  pop r11
000074c379dd9174  pop r10
000074c379dd9176  pop r9
000074c379dd9178  pop r8
000074c379dd917a  pop rsi
000074c379dd917b  pop rdi
000074c379dd917c  pop rdx
000074c379dd917d  pop rcx
000074c379dd917e  pop rax
000074c379dd917f  add rsp, 0x08
000074c379dd9183  jmp 0x000074C379DD61DC
000074c379dd9188  sub rsp, 0x08
000074c379dd918c  push rax
000074c379dd918d  push rcx
000074c379dd918e  push rdx
000074c379dd918f  push rdi
000074c379dd9190  push rsi
000074c379dd9191  push r8
000074c379dd9193  push r9
000074c379dd9195  push r10
000074c379dd9197  push r11
000074c379dd9199  sub rsp, 0xF0
000074c379dd91a0  vmovaps [rsp], xmm0
000074c379dd91a5  vmovaps [rsp+0x10], xmm1
000074c379dd91ab  vmovaps [rsp+0x20], xmm2
000074c379dd91b1  vmovaps [rsp+0x30], xmm3
000074c379dd91b7  vmovaps [rsp+0x40], xmm4
000074c379dd91bd  vmovaps [rsp+0x50], xmm6
000074c379dd91c3  vmovaps [rsp+0x60], xmm7
000074c379dd91c9  vmovaps [rsp+0x70], xmm8
000074c379dd91cf  vmovaps [rsp+0x80], xmm9
000074c379dd91d8  vmovaps [rsp+0x90], xmm10
000074c379dd91e1  vmovaps [rsp+0xA0], xmm11
000074c379dd91ea  vmovaps [rsp+0xB0], xmm12
000074c379dd91f3  vmovaps [rsp+0xC0], xmm13
000074c379dd91fc  vmovaps [rsp+0xD0], xmm14
000074c379dd9205  vmovaps [rsp+0xE0], xmm15
000074c379dd920e  sub rsp, 0x30
000074c379dd9212  movaps [rsp], xmm5
000074c379dd9216  movaps [rsp+0x10], xmm8
000074c379dd921c  movaps [rsp+0x20], xmm6
000074c379dd9221  lea rdi, [rsp]
000074c379dd9225  mov esi, 0x00
000074c379dd922a  mov rax, 0x56321ABA4530
000074c379dd9234  call rax
000074c379dd9236  movaps xmm5, [rsp]
000074c379dd923a  add rsp, 0x30
000074c379dd923e  vmovaps xmm0, [rsp]
000074c379dd9243  vmovaps xmm1, [rsp+0x10]
000074c379dd9249  vmovaps xmm2, [rsp+0x20]
000074c379dd924f  vmovaps xmm3, [rsp+0x30]
000074c379dd9255  vmovaps xmm4, [rsp+0x40]
000074c379dd925b  vmovaps xmm6, [rsp+0x50]
000074c379dd9261  vmovaps xmm7, [rsp+0x60]
000074c379dd9267  vmovaps xmm8, [rsp+0x70]
000074c379dd926d  vmovaps xmm9, [rsp+0x80]
000074c379dd9276  vmovaps xmm10, [rsp+0x90]
000074c379dd927f  vmovaps xmm11, [rsp+0xA0]
000074c379dd9288  vmovaps xmm12, [rsp+0xB0]
000074c379dd9291  vmovaps xmm13, [rsp+0xC0]
000074c379dd929a  vmovaps xmm14, [rsp+0xD0]
000074c379dd92a3  vmovaps xmm15, [rsp+0xE0]
000074c379dd92ac  add rsp, 0xF0
000074c379dd92b3  pop r11
000074c379dd92b5  pop r10
000074c379dd92b7  pop r9
000074c379dd92b9  pop r8
000074c379dd92bb  pop rsi
000074c379dd92bc  pop rdi
000074c379dd92bd  pop rdx
000074c379dd92be  pop rcx
000074c379dd92bf  pop rax
000074c379dd92c0  add rsp, 0x08
000074c379dd92c4  jmp 0x000074C379DD6200
000074c379dd92c9  sub rsp, 0x08
000074c379dd92cd  push rax
000074c379dd92ce  push rcx
000074c379dd92cf  push rdx
000074c379dd92d0  push rdi
000074c379dd92d1  push rsi
000074c379dd92d2  push r8
000074c379dd92d4  push r9
000074c379dd92d6  push r10
000074c379dd92d8  push r11
000074c379dd92da  sub rsp, 0xF0
000074c379dd92e1  vmovaps [rsp], xmm0
000074c379dd92e6  vmovaps [rsp+0x10], xmm1
000074c379dd92ec  vmovaps [rsp+0x20], xmm2
000074c379dd92f2  vmovaps [rsp+0x30], xmm3
000074c379dd92f8  vmovaps [rsp+0x40], xmm4
000074c379dd92fe  vmovaps [rsp+0x50], xmm5
000074c379dd9304  vmovaps [rsp+0x60], xmm7
000074c379dd930a  vmovaps [rsp+0x70], xmm8
000074c379dd9310  vmovaps [rsp+0x80], xmm9
000074c379dd9319  vmovaps [rsp+0x90], xmm10
000074c379dd9322  vmovaps [rsp+0xA0], xmm11
000074c379dd932b  vmovaps [rsp+0xB0], xmm12
000074c379dd9334  vmovaps [rsp+0xC0], xmm13
000074c379dd933d  vmovaps [rsp+0xD0], xmm14
000074c379dd9346  vmovaps [rsp+0xE0], xmm15
000074c379dd934f  sub rsp, 0x30
000074c379dd9353  movaps [rsp], xmm6
000074c379dd9357  movaps [rsp+0x10], xmm10
000074c379dd935d  movaps [rsp+0x20], xmm8
000074c379dd9363  lea rdi, [rsp]
000074c379dd9367  mov esi, 0x00
000074c379dd936c  mov rax, 0x56321ABA4530
000074c379dd9376  call rax
000074c379dd9378  movaps xmm6, [rsp]
000074c379dd937c  add rsp, 0x30
000074c379dd9380  vmovaps xmm0, [rsp]
000074c379dd9385  vmovaps xmm1, [rsp+0x10]
000074c379dd938b  vmovaps xmm2, [rsp+0x20]
000074c379dd9391  vmovaps xmm3, [rsp+0x30]
000074c379dd9397  vmovaps xmm4, [rsp+0x40]
000074c379dd939d  vmovaps xmm5, [rsp+0x50]
000074c379dd93a3  vmovaps xmm7, [rsp+0x60]
000074c379dd93a9  vmovaps xmm8, [rsp+0x70]
000074c379dd93af  vmovaps xmm9, [rsp+0x80]
000074c379dd93b8  vmovaps xmm10, [rsp+0x90]
000074c379dd93c1  vmovaps xmm11, [rsp+0xA0]
000074c379dd93ca  vmovaps xmm12, [rsp+0xB0]
000074c379dd93d3  vmovaps xmm13, [rsp+0xC0]
000074c379dd93dc  vmovaps xmm14, [rsp+0xD0]
000074c379dd93e5  vmovaps xmm15, [rsp+0xE0]
000074c379dd93ee  add rsp, 0xF0
000074c379dd93f5  pop r11
000074c379dd93f7  pop r10
000074c379dd93f9  pop r9
000074c379dd93fb  pop r8
000074c379dd93fd  pop rsi
000074c379dd93fe  pop rdi
000074c379dd93ff  pop rdx
000074c379dd9400  pop rcx
000074c379dd9401  pop rax
000074c379dd9402  add rsp, 0x08
000074c379dd9406  jmp 0x000074C379DD6225
000074c379dd940b  sub rsp, 0x08
000074c379dd940f  push rax
000074c379dd9410  push rcx
000074c379dd9411  push rdx
000074c379dd9412  push rdi
000074c379dd9413  push rsi
000074c379dd9414  push r8
000074c379dd9416  push r9
000074c379dd9418  push r10
000074c379dd941a  push r11
000074c379dd941c  sub rsp, 0xF0
000074c379dd9423  vmovaps [rsp], xmm0
000074c379dd9428  vmovaps [rsp+0x10], xmm1
000074c379dd942e  vmovaps [rsp+0x20], xmm2
000074c379dd9434  vmovaps [rsp+0x30], xmm3
000074c379dd943a  vmovaps [rsp+0x40], xmm4
000074c379dd9440  vmovaps [rsp+0x50], xmm5
000074c379dd9446  vmovaps [rsp+0x60], xmm6
000074c379dd944c  vmovaps [rsp+0x70], xmm7
000074c379dd9452  vmovaps [rsp+0x80], xmm8
000074c379dd945b  vmovaps [rsp+0x90], xmm9
000074c379dd9464  vmovaps [rsp+0xA0], xmm11
000074c379dd946d  vmovaps [rsp+0xB0], xmm12
000074c379dd9476  vmovaps [rsp+0xC0], xmm13
000074c379dd947f  vmovaps [rsp+0xD0], xmm14
000074c379dd9488  vmovaps [rsp+0xE0], xmm15
000074c379dd9491  sub rsp, 0x30
000074c379dd9495  movaps [rsp], xmm10
000074c379dd949a  movaps [rsp+0x10], xmm8
000074c379dd94a0  movaps [rsp+0x20], xmm14
000074c379dd94a6  lea rdi, [rsp]
000074c379dd94aa  mov esi, 0x00
000074c379dd94af  mov rax, 0x56321ABA4530
000074c379dd94b9  call rax
000074c379dd94bb  movaps xmm10, [rsp]
000074c379dd94c0  add rsp, 0x30
000074c379dd94c4  vmovaps xmm0, [rsp]
000074c379dd94c9  vmovaps xmm1, [rsp+0x10]
000074c379dd94cf  vmovaps xmm2, [rsp+0x20]
000074c379dd94d5  vmovaps xmm3, [rsp+0x30]
000074c379dd94db  vmovaps xmm4, [rsp+0x40]
000074c379dd94e1  vmovaps xmm5, [rsp+0x50]
000074c379dd94e7  vmovaps xmm6, [rsp+0x60]
000074c379dd94ed  vmovaps xmm7, [rsp+0x70]
000074c379dd94f3  vmovaps xmm8, [rsp+0x80]
000074c379dd94fc  vmovaps xmm9, [rsp+0x90]
000074c379dd9505  vmovaps xmm11, [rsp+0xA0]
000074c379dd950e  vmovaps xmm12, [rsp+0xB0]
000074c379dd9517  vmovaps xmm13, [rsp+0xC0]
000074c379dd9520  vmovaps xmm14, [rsp+0xD0]
000074c379dd9529  vmovaps xmm15, [rsp+0xE0]
000074c379dd9532  add rsp, 0xF0
000074c379dd9539  pop r11
000074c379dd953b  pop r10
000074c379dd953d  pop r9
000074c379dd953f  pop r8
000074c379dd9541  pop rsi
000074c379dd9542  pop rdi
000074c379dd9543  pop rdx
000074c379dd9544  pop rcx
000074c379dd9545  pop rax
000074c379dd9546  add rsp, 0x08
000074c379dd954a  jmp 0x000074C379DD6245
000074c379dd954f  sub rsp, 0x08
000074c379dd9553  push rax
000074c379dd9554  push rcx
000074c379dd9555  push rdx
000074c379dd9556  push rdi
000074c379dd9557  push rsi
000074c379dd9558  push r8
000074c379dd955a  push r9
000074c379dd955c  push r10
000074c379dd955e  push r11
000074c379dd9560  sub rsp, 0xF0
000074c379dd9567  vmovaps [rsp], xmm0
000074c379dd956c  vmovaps [rsp+0x10], xmm1
000074c379dd9572  vmovaps [rsp+0x20], xmm2
000074c379dd9578  vmovaps [rsp+0x30], xmm3
000074c379dd957e  vmovaps [rsp+0x40], xmm4
000074c379dd9584  vmovaps [rsp+0x50], xmm5
000074c379dd958a  vmovaps [rsp+0x60], xmm6
000074c379dd9590  vmovaps [rsp+0x70], xmm7
000074c379dd9596  vmovaps [rsp+0x80], xmm8
000074c379dd959f  vmovaps [rsp+0x90], xmm9
000074c379dd95a8  vmovaps [rsp+0xA0], xmm10
000074c379dd95b1  vmovaps [rsp+0xB0], xmm11
000074c379dd95ba  vmovaps [rsp+0xC0], xmm12
000074c379dd95c3  vmovaps [rsp+0xD0], xmm13
000074c379dd95cc  vmovaps [rsp+0xE0], xmm15
000074c379dd95d5  sub rsp, 0x30
000074c379dd95d9  movaps [rsp], xmm14
000074c379dd95de  movaps [rsp+0x10], xmm8
000074c379dd95e4  movaps [rsp+0x20], xmm4
000074c379dd95e9  lea rdi, [rsp]
000074c379dd95ed  mov esi, 0x00
000074c379dd95f2  mov rax, 0x56321ABA4530
000074c379dd95fc  call rax
000074c379dd95fe  movaps xmm14, [rsp]
000074c379dd9603  add rsp, 0x30
000074c379dd9607  vmovaps xmm0, [rsp]
000074c379dd960c  vmovaps xmm1, [rsp+0x10]
000074c379dd9612  vmovaps xmm2, [rsp+0x20]
000074c379dd9618  vmovaps xmm3, [rsp+0x30]
000074c379dd961e  vmovaps xmm4, [rsp+0x40]
000074c379dd9624  vmovaps xmm5, [rsp+0x50]
000074c379dd962a  vmovaps xmm6, [rsp+0x60]
000074c379dd9630  vmovaps xmm7, [rsp+0x70]
000074c379dd9636  vmovaps xmm8, [rsp+0x80]
000074c379dd963f  vmovaps xmm9, [rsp+0x90]
000074c379dd9648  vmovaps xmm10, [rsp+0xA0]
000074c379dd9651  vmovaps xmm11, [rsp+0xB0]
000074c379dd965a  vmovaps xmm12, [rsp+0xC0]
000074c379dd9663  vmovaps xmm13, [rsp+0xD0]
000074c379dd966c  vmovaps xmm15, [rsp+0xE0]
000074c379dd9675  add rsp, 0xF0
000074c379dd967c  pop r11
000074c379dd967e  pop r10
000074c379dd9680  pop r9
000074c379dd9682  pop r8
000074c379dd9684  pop rsi
000074c379dd9685  pop rdi
000074c379dd9686  pop rdx
000074c379dd9687  pop rcx
000074c379dd9688  pop rax
000074c379dd9689  add rsp, 0x08
000074c379dd968d  jmp 0x000074C379DD6265
000074c379dd9692  sub rsp, 0x08
000074c379dd9696  push rax
000074c379dd9697  push rcx
000074c379dd9698  push rdx
000074c379dd9699  push rdi
000074c379dd969a  push rsi
000074c379dd969b  push r8
000074c379dd969d  push r9
000074c379dd969f  push r10
000074c379dd96a1  push r11
000074c379dd96a3  sub rsp, 0xF0
000074c379dd96aa  vmovaps [rsp], xmm0
000074c379dd96af  vmovaps [rsp+0x10], xmm1
000074c379dd96b5  vmovaps [rsp+0x20], xmm2
000074c379dd96bb  vmovaps [rsp+0x30], xmm3
000074c379dd96c1  vmovaps [rsp+0x40], xmm5
000074c379dd96c7  vmovaps [rsp+0x50], xmm6
000074c379dd96cd  vmovaps [rsp+0x60], xmm7
000074c379dd96d3  vmovaps [rsp+0x70], xmm8
000074c379dd96d9  vmovaps [rsp+0x80], xmm9
000074c379dd96e2  vmovaps [rsp+0x90], xmm10
000074c379dd96eb  vmovaps [rsp+0xA0], xmm11
000074c379dd96f4  vmovaps [rsp+0xB0], xmm12
000074c379dd96fd  vmovaps [rsp+0xC0], xmm13
000074c379dd9706  vmovaps [rsp+0xD0], xmm14
000074c379dd970f  vmovaps [rsp+0xE0], xmm15
000074c379dd9718  sub rsp, 0x30
000074c379dd971c  movaps [rsp], xmm4
000074c379dd9720  movaps [rsp+0x10], xmm13
000074c379dd9726  movaps [rsp+0x20], xmm8
000074c379dd972c  lea rdi, [rsp]
000074c379dd9730  mov esi, 0x00
000074c379dd9735  mov rax, 0x56321ABA4530
000074c379dd973f  call rax
000074c379dd9741  movaps xmm4, [rsp]
000074c379dd9745  add rsp, 0x30
000074c379dd9749  vmovaps xmm0, [rsp]
000074c379dd974e  vmovaps xmm1, [rsp+0x10]
000074c379dd9754  vmovaps xmm2, [rsp+0x20]
000074c379dd975a  vmovaps xmm3, [rsp+0x30]
000074c379dd9760  vmovaps xmm5, [rsp+0x40]
000074c379dd9766  vmovaps xmm6, [rsp+0x50]
000074c379dd976c  vmovaps xmm7, [rsp+0x60]
000074c379dd9772  vmovaps xmm8, [rsp+0x70]
000074c379dd9778  vmovaps xmm9, [rsp+0x80]
000074c379dd9781  vmovaps xmm10, [rsp+0x90]
000074c379dd978a  vmovaps xmm11, [rsp+0xA0]
000074c379dd9793  vmovaps xmm12, [rsp+0xB0]
000074c379dd979c  vmovaps xmm13, [rsp+0xC0]
000074c379dd97a5  vmovaps xmm14, [rsp+0xD0]
000074c379dd97ae  vmovaps xmm15, [rsp+0xE0]
000074c379dd97b7  add rsp, 0xF0
000074c379dd97be  pop r11
000074c379dd97c0  pop r10
000074c379dd97c2  pop r9
000074c379dd97c4  pop r8
000074c379dd97c6  pop rsi
000074c379dd97c7  pop rdi
000074c379dd97c8  pop rdx
000074c379dd97c9  pop rcx
000074c379dd97ca  pop rax
000074c379dd97cb  add rsp, 0x08
000074c379dd97cf  jmp 0x000074C379DD628A
000074c379dd97d4  sub rsp, 0x08
000074c379dd97d8  push rax
000074c379dd97d9  push rcx
000074c379dd97da  push rdx
000074c379dd97db  push rdi
000074c379dd97dc  push rsi
000074c379dd97dd  push r8
000074c379dd97df  push r9
000074c379dd97e1  push r10
000074c379dd97e3  push r11
000074c379dd97e5  sub rsp, 0xF0
000074c379dd97ec  vmovaps [rsp], xmm0
000074c379dd97f1  vmovaps [rsp+0x10], xmm1
000074c379dd97f7  vmovaps [rsp+0x20], xmm2
000074c379dd97fd  vmovaps [rsp+0x30], xmm3
000074c379dd9803  vmovaps [rsp+0x40], xmm4
000074c379dd9809  vmovaps [rsp+0x50], xmm5
000074c379dd980f  vmovaps [rsp+0x60], xmm6
000074c379dd9815  vmovaps [rsp+0x70], xmm7
000074c379dd981b  vmovaps [rsp+0x80], xmm8
000074c379dd9824  vmovaps [rsp+0x90], xmm9
000074c379dd982d  vmovaps [rsp+0xA0], xmm10
000074c379dd9836  vmovaps [rsp+0xB0], xmm11
000074c379dd983f  vmovaps [rsp+0xC0], xmm12
000074c379dd9848  vmovaps [rsp+0xD0], xmm14
000074c379dd9851  vmovaps [rsp+0xE0], xmm15
000074c379dd985a  sub rsp, 0x30
000074c379dd985e  movaps [rsp], xmm13
000074c379dd9863  movaps [rsp+0x10], xmm15
000074c379dd9869  movaps [rsp+0x20], xmm9
000074c379dd986f  lea rdi, [rsp]
000074c379dd9873  mov esi, 0x00
000074c379dd9878  mov rax, 0x56321ABA4530
000074c379dd9882  call rax
000074c379dd9884  movaps xmm13, [rsp]
000074c379dd9889  add rsp, 0x30
000074c379dd988d  vmovaps xmm0, [rsp]
000074c379dd9892  vmovaps xmm1, [rsp+0x10]
000074c379dd9898  vmovaps xmm2, [rsp+0x20]
000074c379dd989e  vmovaps xmm3, [rsp+0x30]
000074c379dd98a4  vmovaps xmm4, [rsp+0x40]
000074c379dd98aa  vmovaps xmm5, [rsp+0x50]
000074c379dd98b0  vmovaps xmm6, [rsp+0x60]
000074c379dd98b6  vmovaps xmm7, [rsp+0x70]
000074c379dd98bc  vmovaps xmm8, [rsp+0x80]
000074c379dd98c5  vmovaps xmm9, [rsp+0x90]
000074c379dd98ce  vmovaps xmm10, [rsp+0xA0]
000074c379dd98d7  vmovaps xmm11, [rsp+0xB0]
000074c379dd98e0  vmovaps xmm12, [rsp+0xC0]
000074c379dd98e9  vmovaps xmm14, [rsp+0xD0]
000074c379dd98f2  vmovaps xmm15, [rsp+0xE0]
000074c379dd98fb  add rsp, 0xF0
000074c379dd9902  pop r11
000074c379dd9904  pop r10
000074c379dd9906  pop r9
000074c379dd9908  pop r8
000074c379dd990a  pop rsi
000074c379dd990b  pop rdi
000074c379dd990c  pop rdx
000074c379dd990d  pop rcx
000074c379dd990e  pop rax
000074c379dd990f  add rsp, 0x08
000074c379dd9913  jmp 0x000074C379DD62A5
000074c379dd9918  sub rsp, 0x08
000074c379dd991c  push rax
000074c379dd991d  push rcx
000074c379dd991e  push rdx
000074c379dd991f  push rdi
000074c379dd9920  push rsi
000074c379dd9921  push r8
000074c379dd9923  push r9
000074c379dd9925  push r10
000074c379dd9927  push r11
000074c379dd9929  sub rsp, 0xF0
000074c379dd9930  vmovaps [rsp], xmm0
000074c379dd9935  vmovaps [rsp+0x10], xmm1
000074c379dd993b  vmovaps [rsp+0x20], xmm2
000074c379dd9941  vmovaps [rsp+0x30], xmm3
000074c379dd9947  vmovaps [rsp+0x40], xmm4
000074c379dd994d  vmovaps [rsp+0x50], xmm5
000074c379dd9953  vmovaps [rsp+0x60], xmm6
000074c379dd9959  vmovaps [rsp+0x70], xmm7
000074c379dd995f  vmovaps [rsp+0x80], xmm8
000074c379dd9968  vmovaps [rsp+0x90], xmm9
000074c379dd9971  vmovaps [rsp+0xA0], xmm10
000074c379dd997a  vmovaps [rsp+0xB0], xmm11
000074c379dd9983  vmovaps [rsp+0xC0], xmm12
000074c379dd998c  vmovaps [rsp+0xD0], xmm13
000074c379dd9995  vmovaps [rsp+0xE0], xmm14
000074c379dd999e  sub rsp, 0x30
000074c379dd99a2  movaps [rsp], xmm15
000074c379dd99a7  movaps [rsp+0x10], xmm1
000074c379dd99ac  movaps [rsp+0x20], xmm5
000074c379dd99b1  lea rdi, [rsp]
000074c379dd99b5  mov esi, 0x00
000074c379dd99ba  mov rax, 0x56321ABA4530
000074c379dd99c4  call rax
000074c379dd99c6  movaps xmm15, [rsp]
000074c379dd99cb  add rsp, 0x30
000074c379dd99cf  vmovaps xmm0, [rsp]
000074c379dd99d4  vmovaps xmm1, [rsp+0x10]
000074c379dd99da  vmovaps xmm2, [rsp+0x20]
000074c379dd99e0  vmovaps xmm3, [rsp+0x30]
000074c379dd99e6  vmovaps xmm4, [rsp+0x40]
000074c379dd99ec  vmovaps xmm5, [rsp+0x50]
000074c379dd99f2  vmovaps xmm6, [rsp+0x60]
000074c379dd99f8  vmovaps xmm7, [rsp+0x70]
000074c379dd99fe  vmovaps xmm8, [rsp+0x80]
000074c379dd9a07  vmovaps xmm9, [rsp+0x90]
000074c379dd9a10  vmovaps xmm10, [rsp+0xA0]
000074c379dd9a19  vmovaps xmm11, [rsp+0xB0]
000074c379dd9a22  vmovaps xmm12, [rsp+0xC0]
000074c379dd9a2b  vmovaps xmm13, [rsp+0xD0]
000074c379dd9a34  vmovaps xmm14, [rsp+0xE0]
000074c379dd9a3d  add rsp, 0xF0
000074c379dd9a44  pop r11
000074c379dd9a46  pop r10
000074c379dd9a48  pop r9
000074c379dd9a4a  pop r8
000074c379dd9a4c  pop rsi
000074c379dd9a4d  pop rdi
000074c379dd9a4e  pop rdx
000074c379dd9a4f  pop rcx
000074c379dd9a50  pop rax
000074c379dd9a51  add rsp, 0x08
000074c379dd9a55  jmp 0x000074C379DD62C0
000074c379dd9a5a  call 0x000074C379CD64F0
000074c379dd9a5f  jmp 0x000074C379DD631B
000074c379dd9a64  sub rsp, 0x08
000074c379dd9a68  push rax
000074c379dd9a69  push rcx
000074c379dd9a6a  push rdx
000074c379dd9a6b  push rdi
000074c379dd9a6c  push rsi
000074c379dd9a6d  push r8
000074c379dd9a6f  push r9
000074c379dd9a71  push r10
000074c379dd9a73  push r11
000074c379dd9a75  sub rsp, 0xF0
000074c379dd9a7c  vmovaps [rsp], xmm0
000074c379dd9a81  vmovaps [rsp+0x10], xmm1
000074c379dd9a87  vmovaps [rsp+0x20], xmm2
000074c379dd9a8d  vmovaps [rsp+0x30], xmm3
000074c379dd9a93  vmovaps [rsp+0x40], xmm4
000074c379dd9a99  vmovaps [rsp+0x50], xmm5
000074c379dd9a9f  vmovaps [rsp+0x60], xmm6
000074c379dd9aa5  vmovaps [rsp+0x70], xmm7
000074c379dd9aab  vmovaps [rsp+0x80], xmm8
000074c379dd9ab4  vmovaps [rsp+0x90], xmm10
000074c379dd9abd  vmovaps [rsp+0xA0], xmm11
000074c379dd9ac6  vmovaps [rsp+0xB0], xmm12
000074c379dd9acf  vmovaps [rsp+0xC0], xmm13
000074c379dd9ad8  vmovaps [rsp+0xD0], xmm14
000074c379dd9ae1  vmovaps [rsp+0xE0], xmm15
000074c379dd9aea  sub rsp, 0x30
000074c379dd9aee  movaps [rsp], xmm9
000074c379dd9af3  movaps [rsp+0x10], xmm8
000074c379dd9af9  movaps [rsp+0x20], xmm11
000074c379dd9aff  lea rdi, [rsp]
000074c379dd9b03  mov esi, 0x00
000074c379dd9b08  mov rax, 0x56321ABA4530
000074c379dd9b12  call rax
000074c379dd9b14  movaps xmm9, [rsp]
000074c379dd9b19  add rsp, 0x30
000074c379dd9b1d  vmovaps xmm0, [rsp]
000074c379dd9b22  vmovaps xmm1, [rsp+0x10]
000074c379dd9b28  vmovaps xmm2, [rsp+0x20]
000074c379dd9b2e  vmovaps xmm3, [rsp+0x30]
000074c379dd9b34  vmovaps xmm4, [rsp+0x40]
000074c379dd9b3a  vmovaps xmm5, [rsp+0x50]
000074c379dd9b40  vmovaps xmm6, [rsp+0x60]
000074c379dd9b46  vmovaps xmm7, [rsp+0x70]
000074c379dd9b4c  vmovaps xmm8, [rsp+0x80]
000074c379dd9b55  vmovaps xmm10, [rsp+0x90]
000074c379dd9b5e  vmovaps xmm11, [rsp+0xA0]
000074c379dd9b67  vmovaps xmm12, [rsp+0xB0]
000074c379dd9b70  vmovaps xmm13, [rsp+0xC0]
000074c379dd9b79  vmovaps xmm14, [rsp+0xD0]
000074c379dd9b82  vmovaps xmm15, [rsp+0xE0]
000074c379dd9b8b  add rsp, 0xF0
000074c379dd9b92  pop r11
000074c379dd9b94  pop r10
000074c379dd9b96  pop r9
000074c379dd9b98  pop r8
000074c379dd9b9a  pop rsi
000074c379dd9b9b  pop rdi
000074c379dd9b9c  pop rdx
000074c379dd9b9d  pop rcx
000074c379dd9b9e  pop rax
000074c379dd9b9f  add rsp, 0x08
000074c379dd9ba3  jmp 0x000074C379DD6352
000074c379dd9ba8  sub rsp, 0x08
000074c379dd9bac  push rax
000074c379dd9bad  push rcx
000074c379dd9bae  push rdx
000074c379dd9baf  push rdi
000074c379dd9bb0  push rsi
000074c379dd9bb1  push r8
000074c379dd9bb3  push r9
000074c379dd9bb5  push r10
000074c379dd9bb7  push r11
000074c379dd9bb9  sub rsp, 0xF0
000074c379dd9bc0  vmovaps [rsp], xmm0
000074c379dd9bc5  vmovaps [rsp+0x10], xmm1
000074c379dd9bcb  vmovaps [rsp+0x20], xmm2
000074c379dd9bd1  vmovaps [rsp+0x30], xmm3
000074c379dd9bd7  vmovaps [rsp+0x40], xmm4
000074c379dd9bdd  vmovaps [rsp+0x50], xmm5
000074c379dd9be3  vmovaps [rsp+0x60], xmm6
000074c379dd9be9  vmovaps [rsp+0x70], xmm7
000074c379dd9bef  vmovaps [rsp+0x80], xmm8
000074c379dd9bf8  vmovaps [rsp+0x90], xmm9
000074c379dd9c01  vmovaps [rsp+0xA0], xmm10
000074c379dd9c0a  vmovaps [rsp+0xB0], xmm12
000074c379dd9c13  vmovaps [rsp+0xC0], xmm13
000074c379dd9c1c  vmovaps [rsp+0xD0], xmm14
000074c379dd9c25  vmovaps [rsp+0xE0], xmm15
000074c379dd9c2e  sub rsp, 0x30
000074c379dd9c32  movaps [rsp], xmm11
000074c379dd9c37  movaps [rsp+0x10], xmm10
000074c379dd9c3d  movaps [rsp+0x20], xmm6
000074c379dd9c42  lea rdi, [rsp]
000074c379dd9c46  mov esi, 0x00
000074c379dd9c4b  mov rax, 0x56321ABA4530
000074c379dd9c55  call rax
000074c379dd9c57  movaps xmm11, [rsp]
000074c379dd9c5c  add rsp, 0x30
000074c379dd9c60  vmovaps xmm0, [rsp]
000074c379dd9c65  vmovaps xmm1, [rsp+0x10]
000074c379dd9c6b  vmovaps xmm2, [rsp+0x20]
000074c379dd9c71  vmovaps xmm3, [rsp+0x30]
000074c379dd9c77  vmovaps xmm4, [rsp+0x40]
000074c379dd9c7d  vmovaps xmm5, [rsp+0x50]
000074c379dd9c83  vmovaps xmm6, [rsp+0x60]
000074c379dd9c89  vmovaps xmm7, [rsp+0x70]
000074c379dd9c8f  vmovaps xmm8, [rsp+0x80]
000074c379dd9c98  vmovaps xmm9, [rsp+0x90]
000074c379dd9ca1  vmovaps xmm10, [rsp+0xA0]
000074c379dd9caa  vmovaps xmm12, [rsp+0xB0]
000074c379dd9cb3  vmovaps xmm13, [rsp+0xC0]
000074c379dd9cbc  vmovaps xmm14, [rsp+0xD0]
000074c379dd9cc5  vmovaps xmm15, [rsp+0xE0]
000074c379dd9cce  add rsp, 0xF0
000074c379dd9cd5  pop r11
000074c379dd9cd7  pop r10
000074c379dd9cd9  pop r9
000074c379dd9cdb  pop r8
000074c379dd9cdd  pop rsi
000074c379dd9cde  pop rdi
000074c379dd9cdf  pop rdx
000074c379dd9ce0  pop rcx
000074c379dd9ce1  pop rax
000074c379dd9ce2  add rsp, 0x08
000074c379dd9ce6  jmp 0x000074C379DD636D
000074c379dd9ceb  sub rsp, 0x08
000074c379dd9cef  push rax
000074c379dd9cf0  push rcx
000074c379dd9cf1  push rdx
000074c379dd9cf2  push rdi
000074c379dd9cf3  push rsi
000074c379dd9cf4  push r8
000074c379dd9cf6  push r9
000074c379dd9cf8  push r10
000074c379dd9cfa  push r11
000074c379dd9cfc  sub rsp, 0xF0
000074c379dd9d03  vmovaps [rsp], xmm0
000074c379dd9d08  vmovaps [rsp+0x10], xmm1
000074c379dd9d0e  vmovaps [rsp+0x20], xmm2
000074c379dd9d14  vmovaps [rsp+0x30], xmm3
000074c379dd9d1a  vmovaps [rsp+0x40], xmm4
000074c379dd9d20  vmovaps [rsp+0x50], xmm5
000074c379dd9d26  vmovaps [rsp+0x60], xmm6
000074c379dd9d2c  vmovaps [rsp+0x70], xmm7
000074c379dd9d32  vmovaps [rsp+0x80], xmm8
000074c379dd9d3b  vmovaps [rsp+0x90], xmm9
000074c379dd9d44  vmovaps [rsp+0xA0], xmm11
000074c379dd9d4d  vmovaps [rsp+0xB0], xmm12
000074c379dd9d56  vmovaps [rsp+0xC0], xmm13
000074c379dd9d5f  vmovaps [rsp+0xD0], xmm14
000074c379dd9d68  vmovaps [rsp+0xE0], xmm15
000074c379dd9d71  sub rsp, 0x30
000074c379dd9d75  movaps [rsp], xmm10
000074c379dd9d7a  movaps [rsp+0x10], xmm14
000074c379dd9d80  movaps [rsp+0x20], xmm4
000074c379dd9d85  lea rdi, [rsp]
000074c379dd9d89  mov esi, 0x00
000074c379dd9d8e  mov rax, 0x56321ABA4530
000074c379dd9d98  call rax
000074c379dd9d9a  movaps xmm10, [rsp]
000074c379dd9d9f  add rsp, 0x30
000074c379dd9da3  vmovaps xmm0, [rsp]
000074c379dd9da8  vmovaps xmm1, [rsp+0x10]
000074c379dd9dae  vmovaps xmm2, [rsp+0x20]
000074c379dd9db4  vmovaps xmm3, [rsp+0x30]
000074c379dd9dba  vmovaps xmm4, [rsp+0x40]
000074c379dd9dc0  vmovaps xmm5, [rsp+0x50]
000074c379dd9dc6  vmovaps xmm6, [rsp+0x60]
000074c379dd9dcc  vmovaps xmm7, [rsp+0x70]
000074c379dd9dd2  vmovaps xmm8, [rsp+0x80]
000074c379dd9ddb  vmovaps xmm9, [rsp+0x90]
000074c379dd9de4  vmovaps xmm11, [rsp+0xA0]
000074c379dd9ded  vmovaps xmm12, [rsp+0xB0]
000074c379dd9df6  vmovaps xmm13, [rsp+0xC0]
000074c379dd9dff  vmovaps xmm14, [rsp+0xD0]
000074c379dd9e08  vmovaps xmm15, [rsp+0xE0]
000074c379dd9e11  add rsp, 0xF0
000074c379dd9e18  pop r11
000074c379dd9e1a  pop r10
000074c379dd9e1c  pop r9
000074c379dd9e1e  pop r8
000074c379dd9e20  pop rsi
000074c379dd9e21  pop rdi
000074c379dd9e22  pop rdx
000074c379dd9e23  pop rcx
000074c379dd9e24  pop rax
000074c379dd9e25  add rsp, 0x08
000074c379dd9e29  jmp 0x000074C379DD6388
000074c379dd9e2e  sub rsp, 0x08
000074c379dd9e32  push rax
000074c379dd9e33  push rcx
000074c379dd9e34  push rdx
000074c379dd9e35  push rdi
000074c379dd9e36  push rsi
000074c379dd9e37  push r8
000074c379dd9e39  push r9
000074c379dd9e3b  push r10
000074c379dd9e3d  push r11
000074c379dd9e3f  sub rsp, 0xF0
000074c379dd9e46  vmovaps [rsp], xmm0
000074c379dd9e4b  vmovaps [rsp+0x10], xmm1
000074c379dd9e51  vmovaps [rsp+0x20], xmm2
000074c379dd9e57  vmovaps [rsp+0x30], xmm3
000074c379dd9e5d  vmovaps [rsp+0x40], xmm4
000074c379dd9e63  vmovaps [rsp+0x50], xmm5
000074c379dd9e69  vmovaps [rsp+0x60], xmm6
000074c379dd9e6f  vmovaps [rsp+0x70], xmm7
000074c379dd9e75  vmovaps [rsp+0x80], xmm9
000074c379dd9e7e  vmovaps [rsp+0x90], xmm10
000074c379dd9e87  vmovaps [rsp+0xA0], xmm11
000074c379dd9e90  vmovaps [rsp+0xB0], xmm12
000074c379dd9e99  vmovaps [rsp+0xC0], xmm13
000074c379dd9ea2  vmovaps [rsp+0xD0], xmm14
000074c379dd9eab  vmovaps [rsp+0xE0], xmm15
000074c379dd9eb4  sub rsp, 0x30
000074c379dd9eb8  movaps [rsp], xmm8
000074c379dd9ebd  movaps [rsp+0x10], xmm1
000074c379dd9ec2  movaps [rsp+0x20], xmm14
000074c379dd9ec8  lea rdi, [rsp]
000074c379dd9ecc  mov esi, 0x00
000074c379dd9ed1  mov rax, 0x56321ABA4530
000074c379dd9edb  call rax
000074c379dd9edd  movaps xmm8, [rsp]
000074c379dd9ee2  add rsp, 0x30
000074c379dd9ee6  vmovaps xmm0, [rsp]
000074c379dd9eeb  vmovaps xmm1, [rsp+0x10]
000074c379dd9ef1  vmovaps xmm2, [rsp+0x20]
000074c379dd9ef7  vmovaps xmm3, [rsp+0x30]
000074c379dd9efd  vmovaps xmm4, [rsp+0x40]
000074c379dd9f03  vmovaps xmm5, [rsp+0x50]
000074c379dd9f09  vmovaps xmm6, [rsp+0x60]
000074c379dd9f0f  vmovaps xmm7, [rsp+0x70]
000074c379dd9f15  vmovaps xmm9, [rsp+0x80]
000074c379dd9f1e  vmovaps xmm10, [rsp+0x90]
000074c379dd9f27  vmovaps xmm11, [rsp+0xA0]
000074c379dd9f30  vmovaps xmm12, [rsp+0xB0]
000074c379dd9f39  vmovaps xmm13, [rsp+0xC0]
000074c379dd9f42  vmovaps xmm14, [rsp+0xD0]
000074c379dd9f4b  vmovaps xmm15, [rsp+0xE0]
000074c379dd9f54  add rsp, 0xF0
000074c379dd9f5b  pop r11
000074c379dd9f5d  pop r10
000074c379dd9f5f  pop r9
000074c379dd9f61  pop r8
000074c379dd9f63  pop rsi
000074c379dd9f64  pop rdi
000074c379dd9f65  pop rdx
000074c379dd9f66  pop rcx
000074c379dd9f67  pop rax
000074c379dd9f68  add rsp, 0x08
000074c379dd9f6c  jmp 0x000074C379DD63AE
000074c379dd9f71  sub rsp, 0x08
000074c379dd9f75  push rax
000074c379dd9f76  push rcx
000074c379dd9f77  push rdx
000074c379dd9f78  push rdi
000074c379dd9f79  push rsi
000074c379dd9f7a  push r8
000074c379dd9f7c  push r9
000074c379dd9f7e  push r10
000074c379dd9f80  push r11
000074c379dd9f82  sub rsp, 0xF0
000074c379dd9f89  vmovaps [rsp], xmm0
000074c379dd9f8e  vmovaps [rsp+0x10], xmm1
000074c379dd9f94  vmovaps [rsp+0x20], xmm2
000074c379dd9f9a  vmovaps [rsp+0x30], xmm3
000074c379dd9fa0  vmovaps [rsp+0x40], xmm4
000074c379dd9fa6  vmovaps [rsp+0x50], xmm5
000074c379dd9fac  vmovaps [rsp+0x60], xmm7
000074c379dd9fb2  vmovaps [rsp+0x70], xmm8
000074c379dd9fb8  vmovaps [rsp+0x80], xmm9
000074c379dd9fc1  vmovaps [rsp+0x90], xmm10
000074c379dd9fca  vmovaps [rsp+0xA0], xmm11
000074c379dd9fd3  vmovaps [rsp+0xB0], xmm12
000074c379dd9fdc  vmovaps [rsp+0xC0], xmm13
000074c379dd9fe5  vmovaps [rsp+0xD0], xmm14
000074c379dd9fee  vmovaps [rsp+0xE0], xmm15
000074c379dd9ff7  sub rsp, 0x30
000074c379dd9ffb  movaps [rsp], xmm6
000074c379dd9fff  movaps [rsp+0x10], xmm1
000074c379dda004  movaps [rsp+0x20], xmm14
000074c379dda00a  lea rdi, [rsp]
000074c379dda00e  mov esi, 0x00
000074c379dda013  mov rax, 0x56321ABA4530
000074c379dda01d  call rax
000074c379dda01f  movaps xmm6, [rsp]
000074c379dda023  add rsp, 0x30
000074c379dda027  vmovaps xmm0, [rsp]
000074c379dda02c  vmovaps xmm1, [rsp+0x10]
000074c379dda032  vmovaps xmm2, [rsp+0x20]
000074c379dda038  vmovaps xmm3, [rsp+0x30]
000074c379dda03e  vmovaps xmm4, [rsp+0x40]
000074c379dda044  vmovaps xmm5, [rsp+0x50]
000074c379dda04a  vmovaps xmm7, [rsp+0x60]
000074c379dda050  vmovaps xmm8, [rsp+0x70]
000074c379dda056  vmovaps xmm9, [rsp+0x80]
000074c379dda05f  vmovaps xmm10, [rsp+0x90]
000074c379dda068  vmovaps xmm11, [rsp+0xA0]
000074c379dda071  vmovaps xmm12, [rsp+0xB0]
000074c379dda07a  vmovaps xmm13, [rsp+0xC0]
000074c379dda083  vmovaps xmm14, [rsp+0xD0]
000074c379dda08c  vmovaps xmm15, [rsp+0xE0]
000074c379dda095  add rsp, 0xF0
000074c379dda09c  pop r11
000074c379dda09e  pop r10
000074c379dda0a0  pop r9
000074c379dda0a2  pop r8
000074c379dda0a4  pop rsi
000074c379dda0a5  pop rdi
000074c379dda0a6  pop rdx
000074c379dda0a7  pop rcx
000074c379dda0a8  pop rax
000074c379dda0a9  add rsp, 0x08
000074c379dda0ad  jmp 0x000074C379DD63DA
000074c379dda0b2  sub rsp, 0x08
000074c379dda0b6  push rax
000074c379dda0b7  push rcx
000074c379dda0b8  push rdx
000074c379dda0b9  push rdi
000074c379dda0ba  push rsi
000074c379dda0bb  push r8
000074c379dda0bd  push r9
000074c379dda0bf  push r10
000074c379dda0c1  push r11
000074c379dda0c3  sub rsp, 0xF0
000074c379dda0ca  vmovaps [rsp], xmm0
000074c379dda0cf  vmovaps [rsp+0x10], xmm1
000074c379dda0d5  vmovaps [rsp+0x20], xmm2
000074c379dda0db  vmovaps [rsp+0x30], xmm3
000074c379dda0e1  vmovaps [rsp+0x40], xmm4
000074c379dda0e7  vmovaps [rsp+0x50], xmm5
000074c379dda0ed  vmovaps [rsp+0x60], xmm6
000074c379dda0f3  vmovaps [rsp+0x70], xmm7
000074c379dda0f9  vmovaps [rsp+0x80], xmm8
000074c379dda102  vmovaps [rsp+0x90], xmm9
000074c379dda10b  vmovaps [rsp+0xA0], xmm10
000074c379dda114  vmovaps [rsp+0xB0], xmm11
000074c379dda11d  vmovaps [rsp+0xC0], xmm12
000074c379dda126  vmovaps [rsp+0xD0], xmm13
000074c379dda12f  vmovaps [rsp+0xE0], xmm15
000074c379dda138  sub rsp, 0x30
000074c379dda13c  movaps [rsp], xmm14
000074c379dda141  movaps [rsp+0x10], xmm12
000074c379dda147  movaps [rsp+0x20], xmm1
000074c379dda14c  lea rdi, [rsp]
000074c379dda150  mov esi, 0x00
000074c379dda155  mov rax, 0x56321ABA4530
000074c379dda15f  call rax
000074c379dda161  movaps xmm14, [rsp]
000074c379dda166  add rsp, 0x30
000074c379dda16a  vmovaps xmm0, [rsp]
000074c379dda16f  vmovaps xmm1, [rsp+0x10]
000074c379dda175  vmovaps xmm2, [rsp+0x20]
000074c379dda17b  vmovaps xmm3, [rsp+0x30]
000074c379dda181  vmovaps xmm4, [rsp+0x40]
000074c379dda187  vmovaps xmm5, [rsp+0x50]
000074c379dda18d  vmovaps xmm6, [rsp+0x60]
000074c379dda193  vmovaps xmm7, [rsp+0x70]
000074c379dda199  vmovaps xmm8, [rsp+0x80]
000074c379dda1a2  vmovaps xmm9, [rsp+0x90]
000074c379dda1ab  vmovaps xmm10, [rsp+0xA0]
000074c379dda1b4  vmovaps xmm11, [rsp+0xB0]
000074c379dda1bd  vmovaps xmm12, [rsp+0xC0]
000074c379dda1c6  vmovaps xmm13, [rsp+0xD0]
000074c379dda1cf  vmovaps xmm15, [rsp+0xE0]
000074c379dda1d8  add rsp, 0xF0
000074c379dda1df  pop r11
000074c379dda1e1  pop r10
000074c379dda1e3  pop r9
000074c379dda1e5  pop r8
000074c379dda1e7  pop rsi
000074c379dda1e8  pop rdi
000074c379dda1e9  pop rdx
000074c379dda1ea  pop rcx
000074c379dda1eb  pop rax
000074c379dda1ec  add rsp, 0x08
000074c379dda1f0  jmp 0x000074C379DD6400
000074c379dda1f5  sub rsp, 0x08
000074c379dda1f9  push rax
000074c379dda1fa  push rcx
000074c379dda1fb  push rdx
000074c379dda1fc  push rdi
000074c379dda1fd  push rsi
000074c379dda1fe  push r8
000074c379dda200  push r9
000074c379dda202  push r10
000074c379dda204  push r11
000074c379dda206  sub rsp, 0xF0
000074c379dda20d  vmovaps [rsp], xmm0
000074c379dda212  vmovaps [rsp+0x10], xmm2
000074c379dda218  vmovaps [rsp+0x20], xmm3
000074c379dda21e  vmovaps [rsp+0x30], xmm4
000074c379dda224  vmovaps [rsp+0x40], xmm5
000074c379dda22a  vmovaps [rsp+0x50], xmm6
000074c379dda230  vmovaps [rsp+0x60], xmm7
000074c379dda236  vmovaps [rsp+0x70], xmm8
000074c379dda23c  vmovaps [rsp+0x80], xmm9
000074c379dda245  vmovaps [rsp+0x90], xmm10
000074c379dda24e  vmovaps [rsp+0xA0], xmm11
000074c379dda257  vmovaps [rsp+0xB0], xmm12
000074c379dda260  vmovaps [rsp+0xC0], xmm13
000074c379dda269  vmovaps [rsp+0xD0], xmm14
000074c379dda272  vmovaps [rsp+0xE0], xmm15
000074c379dda27b  sub rsp, 0x30
000074c379dda27f  movaps [rsp], xmm1
000074c379dda283  movaps [rsp+0x10], xmm13
000074c379dda289  movaps [rsp+0x20], xmm9
000074c379dda28f  lea rdi, [rsp]
000074c379dda293  mov esi, 0x00
000074c379dda298  mov rax, 0x56321ABA4530
000074c379dda2a2  call rax
000074c379dda2a4  movaps xmm1, [rsp]
000074c379dda2a8  add rsp, 0x30
000074c379dda2ac  vmovaps xmm0, [rsp]
000074c379dda2b1  vmovaps xmm2, [rsp+0x10]
000074c379dda2b7  vmovaps xmm3, [rsp+0x20]
000074c379dda2bd  vmovaps xmm4, [rsp+0x30]
000074c379dda2c3  vmovaps xmm5, [rsp+0x40]
000074c379dda2c9  vmovaps xmm6, [rsp+0x50]
000074c379dda2cf  vmovaps xmm7, [rsp+0x60]
000074c379dda2d5  vmovaps xmm8, [rsp+0x70]
000074c379dda2db  vmovaps xmm9, [rsp+0x80]
000074c379dda2e4  vmovaps xmm10, [rsp+0x90]
000074c379dda2ed  vmovaps xmm11, [rsp+0xA0]
000074c379dda2f6  vmovaps xmm12, [rsp+0xB0]
000074c379dda2ff  vmovaps xmm13, [rsp+0xC0]
000074c379dda308  vmovaps xmm14, [rsp+0xD0]
000074c379dda311  vmovaps xmm15, [rsp+0xE0]
000074c379dda31a  add rsp, 0xF0
000074c379dda321  pop r11
000074c379dda323  pop r10
000074c379dda325  pop r9
000074c379dda327  pop r8
000074c379dda329  pop rsi
000074c379dda32a  pop rdi
000074c379dda32b  pop rdx
000074c379dda32c  pop rcx
000074c379dda32d  pop rax
000074c379dda32e  add rsp, 0x08
000074c379dda332  jmp 0x000074C379DD641A
000074c379dda337  sub rsp, 0x08
000074c379dda33b  push rax
000074c379dda33c  push rcx
000074c379dda33d  push rdx
000074c379dda33e  push rdi
000074c379dda33f  push rsi
000074c379dda340  push r8
000074c379dda342  push r9
000074c379dda344  push r10
000074c379dda346  push r11
000074c379dda348  sub rsp, 0xF0
000074c379dda34f  vmovaps [rsp], xmm0
000074c379dda354  vmovaps [rsp+0x10], xmm1
000074c379dda35a  vmovaps [rsp+0x20], xmm2
000074c379dda360  vmovaps [rsp+0x30], xmm3
000074c379dda366  vmovaps [rsp+0x40], xmm4
000074c379dda36c  vmovaps [rsp+0x50], xmm5
000074c379dda372  vmovaps [rsp+0x60], xmm6
000074c379dda378  vmovaps [rsp+0x70], xmm7
000074c379dda37e  vmovaps [rsp+0x80], xmm8
000074c379dda387  vmovaps [rsp+0x90], xmm9
000074c379dda390  vmovaps [rsp+0xA0], xmm10
000074c379dda399  vmovaps [rsp+0xB0], xmm11
000074c379dda3a2  vmovaps [rsp+0xC0], xmm13
000074c379dda3ab  vmovaps [rsp+0xD0], xmm14
000074c379dda3b4  vmovaps [rsp+0xE0], xmm15
000074c379dda3bd  sub rsp, 0x30
000074c379dda3c1  movaps [rsp], xmm12
000074c379dda3c6  movaps [rsp+0x10], xmm7
000074c379dda3cb  movaps [rsp+0x20], xmm13
000074c379dda3d1  lea rdi, [rsp]
000074c379dda3d5  mov esi, 0x00
000074c379dda3da  mov rax, 0x56321ABA4530
000074c379dda3e4  call rax
000074c379dda3e6  movaps xmm12, [rsp]
000074c379dda3eb  add rsp, 0x30
000074c379dda3ef  vmovaps xmm0, [rsp]
000074c379dda3f4  vmovaps xmm1, [rsp+0x10]
000074c379dda3fa  vmovaps xmm2, [rsp+0x20]
000074c379dda400  vmovaps xmm3, [rsp+0x30]
000074c379dda406  vmovaps xmm4, [rsp+0x40]
000074c379dda40c  vmovaps xmm5, [rsp+0x50]
000074c379dda412  vmovaps xmm6, [rsp+0x60]
000074c379dda418  vmovaps xmm7, [rsp+0x70]
000074c379dda41e  vmovaps xmm8, [rsp+0x80]
000074c379dda427  vmovaps xmm9, [rsp+0x90]
000074c379dda430  vmovaps xmm10, [rsp+0xA0]
000074c379dda439  vmovaps xmm11, [rsp+0xB0]
000074c379dda442  vmovaps xmm13, [rsp+0xC0]
000074c379dda44b  vmovaps xmm14, [rsp+0xD0]
000074c379dda454  vmovaps xmm15, [rsp+0xE0]
000074c379dda45d  add rsp, 0xF0
000074c379dda464  pop r11
000074c379dda466  pop r10
000074c379dda468  pop r9
000074c379dda46a  pop r8
000074c379dda46c  pop rsi
000074c379dda46d  pop rdi
000074c379dda46e  pop rdx
000074c379dda46f  pop rcx
000074c379dda470  pop rax
000074c379dda471  add rsp, 0x08
000074c379dda475  jmp 0x000074C379DD6441
000074c379dda47a  sub rsp, 0x08
000074c379dda47e  push rax
000074c379dda47f  push rcx
000074c379dda480  push rdx
000074c379dda481  push rdi
000074c379dda482  push rsi
000074c379dda483  push r8
000074c379dda485  push r9
000074c379dda487  push r10
000074c379dda489  push r11
000074c379dda48b  sub rsp, 0xF0
000074c379dda492  vmovaps [rsp], xmm0
000074c379dda497  vmovaps [rsp+0x10], xmm1
000074c379dda49d  vmovaps [rsp+0x20], xmm2
000074c379dda4a3  vmovaps [rsp+0x30], xmm3
000074c379dda4a9  vmovaps [rsp+0x40], xmm4
000074c379dda4af  vmovaps [rsp+0x50], xmm5
000074c379dda4b5  vmovaps [rsp+0x60], xmm6
000074c379dda4bb  vmovaps [rsp+0x70], xmm7
000074c379dda4c1  vmovaps [rsp+0x80], xmm8
000074c379dda4ca  vmovaps [rsp+0x90], xmm9
000074c379dda4d3  vmovaps [rsp+0xA0], xmm10
000074c379dda4dc  vmovaps [rsp+0xB0], xmm11
000074c379dda4e5  vmovaps [rsp+0xC0], xmm12
000074c379dda4ee  vmovaps [rsp+0xD0], xmm14
000074c379dda4f7  vmovaps [rsp+0xE0], xmm15
000074c379dda500  sub rsp, 0x30
000074c379dda504  movaps [rsp], xmm13
000074c379dda509  movaps [rsp+0x10], xmm15
000074c379dda50f  movaps [rsp+0x20], xmm8
000074c379dda515  lea rdi, [rsp]
000074c379dda519  mov esi, 0x00
000074c379dda51e  mov rax, 0x56321ABA4530
000074c379dda528  call rax
000074c379dda52a  movaps xmm13, [rsp]
000074c379dda52f  add rsp, 0x30
000074c379dda533  vmovaps xmm0, [rsp]
000074c379dda538  vmovaps xmm1, [rsp+0x10]
000074c379dda53e  vmovaps xmm2, [rsp+0x20]
000074c379dda544  vmovaps xmm3, [rsp+0x30]
000074c379dda54a  vmovaps xmm4, [rsp+0x40]
000074c379dda550  vmovaps xmm5, [rsp+0x50]
000074c379dda556  vmovaps xmm6, [rsp+0x60]
000074c379dda55c  vmovaps xmm7, [rsp+0x70]
000074c379dda562  vmovaps xmm8, [rsp+0x80]
000074c379dda56b  vmovaps xmm9, [rsp+0x90]
000074c379dda574  vmovaps xmm10, [rsp+0xA0]
000074c379dda57d  vmovaps xmm11, [rsp+0xB0]
000074c379dda586  vmovaps xmm12, [rsp+0xC0]
000074c379dda58f  vmovaps xmm14, [rsp+0xD0]
000074c379dda598  vmovaps xmm15, [rsp+0xE0]
000074c379dda5a1  add rsp, 0xF0
000074c379dda5a8  pop r11
000074c379dda5aa  pop r10
000074c379dda5ac  pop r9
000074c379dda5ae  pop r8
000074c379dda5b0  pop rsi
000074c379dda5b1  pop rdi
000074c379dda5b2  pop rdx
000074c379dda5b3  pop rcx
000074c379dda5b4  pop rax
000074c379dda5b5  add rsp, 0x08
000074c379dda5b9  jmp 0x000074C379DD645C
000074c379dda5be  sub rsp, 0x08
000074c379dda5c2  push rax
000074c379dda5c3  push rcx
000074c379dda5c4  push rdx
000074c379dda5c5  push rdi
000074c379dda5c6  push rsi
000074c379dda5c7  push r8
000074c379dda5c9  push r9
000074c379dda5cb  push r10
000074c379dda5cd  push r11
000074c379dda5cf  sub rsp, 0xF0
000074c379dda5d6  vmovaps [rsp], xmm0
000074c379dda5db  vmovaps [rsp+0x10], xmm1
000074c379dda5e1  vmovaps [rsp+0x20], xmm2
000074c379dda5e7  vmovaps [rsp+0x30], xmm3
000074c379dda5ed  vmovaps [rsp+0x40], xmm4
000074c379dda5f3  vmovaps [rsp+0x50], xmm5
000074c379dda5f9  vmovaps [rsp+0x60], xmm6
000074c379dda5ff  vmovaps [rsp+0x70], xmm7
000074c379dda605  vmovaps [rsp+0x80], xmm9
000074c379dda60e  vmovaps [rsp+0x90], xmm10
000074c379dda617  vmovaps [rsp+0xA0], xmm11
000074c379dda620  vmovaps [rsp+0xB0], xmm12
000074c379dda629  vmovaps [rsp+0xC0], xmm13
000074c379dda632  vmovaps [rsp+0xD0], xmm14
000074c379dda63b  vmovaps [rsp+0xE0], xmm15
000074c379dda644  sub rsp, 0x30
000074c379dda648  movaps [rsp], xmm8
000074c379dda64d  movaps [rsp+0x10], xmm15
000074c379dda653  movaps [rsp+0x20], xmm9
000074c379dda659  lea rdi, [rsp]
000074c379dda65d  mov esi, 0x00
000074c379dda662  mov rax, 0x56321ABA4530
000074c379dda66c  call rax
000074c379dda66e  movaps xmm8, [rsp]
000074c379dda673  add rsp, 0x30
000074c379dda677  vmovaps xmm0, [rsp]
000074c379dda67c  vmovaps xmm1, [rsp+0x10]
000074c379dda682  vmovaps xmm2, [rsp+0x20]
000074c379dda688  vmovaps xmm3, [rsp+0x30]
000074c379dda68e  vmovaps xmm4, [rsp+0x40]
000074c379dda694  vmovaps xmm5, [rsp+0x50]
000074c379dda69a  vmovaps xmm6, [rsp+0x60]
000074c379dda6a0  vmovaps xmm7, [rsp+0x70]
000074c379dda6a6  vmovaps xmm9, [rsp+0x80]
000074c379dda6af  vmovaps xmm10, [rsp+0x90]
000074c379dda6b8  vmovaps xmm11, [rsp+0xA0]
000074c379dda6c1  vmovaps xmm12, [rsp+0xB0]
000074c379dda6ca  vmovaps xmm13, [rsp+0xC0]
000074c379dda6d3  vmovaps xmm14, [rsp+0xD0]
000074c379dda6dc  vmovaps xmm15, [rsp+0xE0]
000074c379dda6e5  add rsp, 0xF0
000074c379dda6ec  pop r11
000074c379dda6ee  pop r10
000074c379dda6f0  pop r9
000074c379dda6f2  pop r8
000074c379dda6f4  pop rsi
000074c379dda6f5  pop rdi
000074c379dda6f6  pop rdx
000074c379dda6f7  pop rcx
000074c379dda6f8  pop rax
000074c379dda6f9  add rsp, 0x08
000074c379dda6fd  jmp 0x000074C379DD648A
000074c379dda702  sub rsp, 0x08
000074c379dda706  push rax
000074c379dda707  push rcx
000074c379dda708  push rdx
000074c379dda709  push rdi
000074c379dda70a  push rsi
000074c379dda70b  push r8
000074c379dda70d  push r9
000074c379dda70f  push r10
000074c379dda711  push r11
000074c379dda713  sub rsp, 0xF0
000074c379dda71a  vmovaps [rsp], xmm0
000074c379dda71f  vmovaps [rsp+0x10], xmm1
000074c379dda725  vmovaps [rsp+0x20], xmm2
000074c379dda72b  vmovaps [rsp+0x30], xmm3
000074c379dda731  vmovaps [rsp+0x40], xmm4
000074c379dda737  vmovaps [rsp+0x50], xmm5
000074c379dda73d  vmovaps [rsp+0x60], xmm6
000074c379dda743  vmovaps [rsp+0x70], xmm7
000074c379dda749  vmovaps [rsp+0x80], xmm8
000074c379dda752  vmovaps [rsp+0x90], xmm9
000074c379dda75b  vmovaps [rsp+0xA0], xmm10
000074c379dda764  vmovaps [rsp+0xB0], xmm11
000074c379dda76d  vmovaps [rsp+0xC0], xmm12
000074c379dda776  vmovaps [rsp+0xD0], xmm13
000074c379dda77f  vmovaps [rsp+0xE0], xmm14
000074c379dda788  sub rsp, 0x30
000074c379dda78c  movaps [rsp], xmm15
000074c379dda791  movaps [rsp+0x10], xmm11
000074c379dda797  movaps [rsp+0x20], xmm6
000074c379dda79c  lea rdi, [rsp]
000074c379dda7a0  mov esi, 0x00
000074c379dda7a5  mov rax, 0x56321ABA4530
000074c379dda7af  call rax
000074c379dda7b1  movaps xmm15, [rsp]
000074c379dda7b6  add rsp, 0x30
000074c379dda7ba  vmovaps xmm0, [rsp]
000074c379dda7bf  vmovaps xmm1, [rsp+0x10]
000074c379dda7c5  vmovaps xmm2, [rsp+0x20]
000074c379dda7cb  vmovaps xmm3, [rsp+0x30]
000074c379dda7d1  vmovaps xmm4, [rsp+0x40]
000074c379dda7d7  vmovaps xmm5, [rsp+0x50]
000074c379dda7dd  vmovaps xmm6, [rsp+0x60]
000074c379dda7e3  vmovaps xmm7, [rsp+0x70]
000074c379dda7e9  vmovaps xmm8, [rsp+0x80]
000074c379dda7f2  vmovaps xmm9, [rsp+0x90]
000074c379dda7fb  vmovaps xmm10, [rsp+0xA0]
000074c379dda804  vmovaps xmm11, [rsp+0xB0]
000074c379dda80d  vmovaps xmm12, [rsp+0xC0]
000074c379dda816  vmovaps xmm13, [rsp+0xD0]
000074c379dda81f  vmovaps xmm14, [rsp+0xE0]
000074c379dda828  add rsp, 0xF0
000074c379dda82f  pop r11
000074c379dda831  pop r10
000074c379dda833  pop r9
000074c379dda835  pop r8
000074c379dda837  pop rsi
000074c379dda838  pop rdi
000074c379dda839  pop rdx
000074c379dda83a  pop rcx
000074c379dda83b  pop rax
000074c379dda83c  add rsp, 0x08
000074c379dda840  jmp 0x000074C379DD64A5
000074c379dda845  sub rsp, 0x08
000074c379dda849  push rax
000074c379dda84a  push rcx
000074c379dda84b  push rdx
000074c379dda84c  push rdi
000074c379dda84d  push rsi
000074c379dda84e  push r8
000074c379dda850  push r9
000074c379dda852  push r10
000074c379dda854  push r11
000074c379dda856  sub rsp, 0xF0
000074c379dda85d  vmovaps [rsp], xmm0
000074c379dda862  vmovaps [rsp+0x10], xmm1
000074c379dda868  vmovaps [rsp+0x20], xmm2
000074c379dda86e  vmovaps [rsp+0x30], xmm3
000074c379dda874  vmovaps [rsp+0x40], xmm4
000074c379dda87a  vmovaps [rsp+0x50], xmm5
000074c379dda880  vmovaps [rsp+0x60], xmm6
000074c379dda886  vmovaps [rsp+0x70], xmm8
000074c379dda88c  vmovaps [rsp+0x80], xmm9
000074c379dda895  vmovaps [rsp+0x90], xmm10
000074c379dda89e  vmovaps [rsp+0xA0], xmm11
000074c379dda8a7  vmovaps [rsp+0xB0], xmm12
000074c379dda8b0  vmovaps [rsp+0xC0], xmm13
000074c379dda8b9  vmovaps [rsp+0xD0], xmm14
000074c379dda8c2  vmovaps [rsp+0xE0], xmm15
000074c379dda8cb  sub rsp, 0x30
000074c379dda8cf  movaps [rsp], xmm7
000074c379dda8d3  movaps [rsp+0x10], xmm11
000074c379dda8d9  movaps [rsp+0x20], xmm9
000074c379dda8df  lea rdi, [rsp]
000074c379dda8e3  mov esi, 0x00
000074c379dda8e8  mov rax, 0x56321ABA4530
000074c379dda8f2  call rax
000074c379dda8f4  movaps xmm7, [rsp]
000074c379dda8f8  add rsp, 0x30
000074c379dda8fc  vmovaps xmm0, [rsp]
000074c379dda901  vmovaps xmm1, [rsp+0x10]
000074c379dda907  vmovaps xmm2, [rsp+0x20]
000074c379dda90d  vmovaps xmm3, [rsp+0x30]
000074c379dda913  vmovaps xmm4, [rsp+0x40]
000074c379dda919  vmovaps xmm5, [rsp+0x50]
000074c379dda91f  vmovaps xmm6, [rsp+0x60]
000074c379dda925  vmovaps xmm8, [rsp+0x70]
000074c379dda92b  vmovaps xmm9, [rsp+0x80]
000074c379dda934  vmovaps xmm10, [rsp+0x90]
000074c379dda93d  vmovaps xmm11, [rsp+0xA0]
000074c379dda946  vmovaps xmm12, [rsp+0xB0]
000074c379dda94f  vmovaps xmm13, [rsp+0xC0]
000074c379dda958  vmovaps xmm14, [rsp+0xD0]
000074c379dda961  vmovaps xmm15, [rsp+0xE0]
000074c379dda96a  add rsp, 0xF0
000074c379dda971  pop r11
000074c379dda973  pop r10
000074c379dda975  pop r9
000074c379dda977  pop r8
000074c379dda979  pop rsi
000074c379dda97a  pop rdi
000074c379dda97b  pop rdx
000074c379dda97c  pop rcx
000074c379dda97d  pop rax
000074c379dda97e  add rsp, 0x08
000074c379dda982  jmp 0x000074C379DD64D2
000074c379dda987  sub rsp, 0x08
000074c379dda98b  push rax
000074c379dda98c  push rcx
000074c379dda98d  push rdx
000074c379dda98e  push rdi
000074c379dda98f  push rsi
000074c379dda990  push r8
000074c379dda992  push r9
000074c379dda994  push r10
000074c379dda996  push r11
000074c379dda998  sub rsp, 0xF0
000074c379dda99f  vmovaps [rsp], xmm0
000074c379dda9a4  vmovaps [rsp+0x10], xmm1
000074c379dda9aa  vmovaps [rsp+0x20], xmm2
000074c379dda9b0  vmovaps [rsp+0x30], xmm3
000074c379dda9b6  vmovaps [rsp+0x40], xmm4
000074c379dda9bc  vmovaps [rsp+0x50], xmm5
000074c379dda9c2  vmovaps [rsp+0x60], xmm6
000074c379dda9c8  vmovaps [rsp+0x70], xmm7
000074c379dda9ce  vmovaps [rsp+0x80], xmm8
000074c379dda9d7  vmovaps [rsp+0x90], xmm9
000074c379dda9e0  vmovaps [rsp+0xA0], xmm10
000074c379dda9e9  vmovaps [rsp+0xB0], xmm12
000074c379dda9f2  vmovaps [rsp+0xC0], xmm13
000074c379dda9fb  vmovaps [rsp+0xD0], xmm14
000074c379ddaa04  vmovaps [rsp+0xE0], xmm15
000074c379ddaa0d  sub rsp, 0x30
000074c379ddaa11  movaps [rsp], xmm11
000074c379ddaa16  movaps [rsp+0x10], xmm10
000074c379ddaa1c  movaps [rsp+0x20], xmm14
000074c379ddaa22  lea rdi, [rsp]
000074c379ddaa26  mov esi, 0x00
000074c379ddaa2b  mov rax, 0x56321ABA4530
000074c379ddaa35  call rax
000074c379ddaa37  movaps xmm11, [rsp]
000074c379ddaa3c  add rsp, 0x30
000074c379ddaa40  vmovaps xmm0, [rsp]
000074c379ddaa45  vmovaps xmm1, [rsp+0x10]
000074c379ddaa4b  vmovaps xmm2, [rsp+0x20]
000074c379ddaa51  vmovaps xmm3, [rsp+0x30]
000074c379ddaa57  vmovaps xmm4, [rsp+0x40]
000074c379ddaa5d  vmovaps xmm5, [rsp+0x50]
000074c379ddaa63  vmovaps xmm6, [rsp+0x60]
000074c379ddaa69  vmovaps xmm7, [rsp+0x70]
000074c379ddaa6f  vmovaps xmm8, [rsp+0x80]
000074c379ddaa78  vmovaps xmm9, [rsp+0x90]
000074c379ddaa81  vmovaps xmm10, [rsp+0xA0]
000074c379ddaa8a  vmovaps xmm12, [rsp+0xB0]
000074c379ddaa93  vmovaps xmm13, [rsp+0xC0]
000074c379ddaa9c  vmovaps xmm14, [rsp+0xD0]
000074c379ddaaa5  vmovaps xmm15, [rsp+0xE0]
000074c379ddaaae  add rsp, 0xF0
000074c379ddaab5  pop r11
000074c379ddaab7  pop r10
000074c379ddaab9  pop r9
000074c379ddaabb  pop r8
000074c379ddaabd  pop rsi
000074c379ddaabe  pop rdi
000074c379ddaabf  pop rdx
000074c379ddaac0  pop rcx
000074c379ddaac1  pop rax
000074c379ddaac2  add rsp, 0x08
000074c379ddaac6  jmp 0x000074C379DD64ED
000074c379ddaacb  call 0x000074C379CE45A0
000074c379ddaad0  jmp 0x000074C379DD64F7
000074c379ddaad5  sub rsp, 0x08
000074c379ddaad9  push rax
000074c379ddaada  push rcx
000074c379ddaadb  push rdx
000074c379ddaadc  push rdi
000074c379ddaadd  push rsi
000074c379ddaade  push r8
000074c379ddaae0  push r9
000074c379ddaae2  push r10
000074c379ddaae4  push r11
000074c379ddaae6  sub rsp, 0xF0
000074c379ddaaed  vmovaps [rsp], xmm0
000074c379ddaaf2  vmovaps [rsp+0x10], xmm1
000074c379ddaaf8  vmovaps [rsp+0x20], xmm2
000074c379ddaafe  vmovaps [rsp+0x30], xmm3
000074c379ddab04  vmovaps [rsp+0x40], xmm4
000074c379ddab0a  vmovaps [rsp+0x50], xmm5
000074c379ddab10  vmovaps [rsp+0x60], xmm6
000074c379ddab16  vmovaps [rsp+0x70], xmm7
000074c379ddab1c  vmovaps [rsp+0x80], xmm8
000074c379ddab25  vmovaps [rsp+0x90], xmm9
000074c379ddab2e  vmovaps [rsp+0xA0], xmm11
000074c379ddab37  vmovaps [rsp+0xB0], xmm12
000074c379ddab40  vmovaps [rsp+0xC0], xmm13
000074c379ddab49  vmovaps [rsp+0xD0], xmm14
000074c379ddab52  vmovaps [rsp+0xE0], xmm15
000074c379ddab5b  sub rsp, 0x30
000074c379ddab5f  movaps [rsp], xmm10
000074c379ddab64  movaps [rsp+0x10], xmm1
000074c379ddab69  movaps [rsp+0x20], xmm12
000074c379ddab6f  lea rdi, [rsp]
000074c379ddab73  mov esi, 0x00
000074c379ddab78  mov rax, 0x56321ABA4530
000074c379ddab82  call rax
000074c379ddab84  movaps xmm10, [rsp]
000074c379ddab89  add rsp, 0x30
000074c379ddab8d  vmovaps xmm0, [rsp]
000074c379ddab92  vmovaps xmm1, [rsp+0x10]
000074c379ddab98  vmovaps xmm2, [rsp+0x20]
000074c379ddab9e  vmovaps xmm3, [rsp+0x30]
000074c379ddaba4  vmovaps xmm4, [rsp+0x40]
000074c379ddabaa  vmovaps xmm5, [rsp+0x50]
000074c379ddabb0  vmovaps xmm6, [rsp+0x60]
000074c379ddabb6  vmovaps xmm7, [rsp+0x70]
000074c379ddabbc  vmovaps xmm8, [rsp+0x80]
000074c379ddabc5  vmovaps xmm9, [rsp+0x90]
000074c379ddabce  vmovaps xmm11, [rsp+0xA0]
000074c379ddabd7  vmovaps xmm12, [rsp+0xB0]
000074c379ddabe0  vmovaps xmm13, [rsp+0xC0]
000074c379ddabe9  vmovaps xmm14, [rsp+0xD0]
000074c379ddabf2  vmovaps xmm15, [rsp+0xE0]
000074c379ddabfb  add rsp, 0xF0
000074c379ddac02  pop r11
000074c379ddac04  pop r10
000074c379ddac06  pop r9
000074c379ddac08  pop r8
000074c379ddac0a  pop rsi
000074c379ddac0b  pop rdi
000074c379ddac0c  pop rdx
000074c379ddac0d  pop rcx
000074c379ddac0e  pop rax
000074c379ddac0f  add rsp, 0x08
000074c379ddac13  jmp 0x000074C379DD651A
000074c379ddac18  sub rsp, 0x08
000074c379ddac1c  push rax
000074c379ddac1d  push rcx
000074c379ddac1e  push rdx
000074c379ddac1f  push rdi
000074c379ddac20  push rsi
000074c379ddac21  push r8
000074c379ddac23  push r9
000074c379ddac25  push r10
000074c379ddac27  push r11
000074c379ddac29  sub rsp, 0xF0
000074c379ddac30  vmovaps [rsp], xmm0
000074c379ddac35  vmovaps [rsp+0x10], xmm1
000074c379ddac3b  vmovaps [rsp+0x20], xmm2
000074c379ddac41  vmovaps [rsp+0x30], xmm3
000074c379ddac47  vmovaps [rsp+0x40], xmm4
000074c379ddac4d  vmovaps [rsp+0x50], xmm5
000074c379ddac53  vmovaps [rsp+0x60], xmm6
000074c379ddac59  vmovaps [rsp+0x70], xmm7
000074c379ddac5f  vmovaps [rsp+0x80], xmm8
000074c379ddac68  vmovaps [rsp+0x90], xmm9
000074c379ddac71  vmovaps [rsp+0xA0], xmm10
000074c379ddac7a  vmovaps [rsp+0xB0], xmm11
000074c379ddac83  vmovaps [rsp+0xC0], xmm13
000074c379ddac8c  vmovaps [rsp+0xD0], xmm14
000074c379ddac95  vmovaps [rsp+0xE0], xmm15
000074c379ddac9e  sub rsp, 0x30
000074c379ddaca2  movaps [rsp], xmm12
000074c379ddaca7  movaps [rsp+0x10], xmm14
000074c379ddacad  movaps [rsp+0x20], xmm1
000074c379ddacb2  lea rdi, [rsp]
000074c379ddacb6  mov esi, 0x00
000074c379ddacbb  mov rax, 0x56321ABA4530
000074c379ddacc5  call rax
000074c379ddacc7  movaps xmm12, [rsp]
000074c379ddaccc  add rsp, 0x30
000074c379ddacd0  vmovaps xmm0, [rsp]
000074c379ddacd5  vmovaps xmm1, [rsp+0x10]
000074c379ddacdb  vmovaps xmm2, [rsp+0x20]
000074c379ddace1  vmovaps xmm3, [rsp+0x30]
000074c379ddace7  vmovaps xmm4, [rsp+0x40]
000074c379ddaced  vmovaps xmm5, [rsp+0x50]
000074c379ddacf3  vmovaps xmm6, [rsp+0x60]
000074c379ddacf9  vmovaps xmm7, [rsp+0x70]
000074c379ddacff  vmovaps xmm8, [rsp+0x80]
000074c379ddad08  vmovaps xmm9, [rsp+0x90]
000074c379ddad11  vmovaps xmm10, [rsp+0xA0]
000074c379ddad1a  vmovaps xmm11, [rsp+0xB0]
000074c379ddad23  vmovaps xmm13, [rsp+0xC0]
000074c379ddad2c  vmovaps xmm14, [rsp+0xD0]
000074c379ddad35  vmovaps xmm15, [rsp+0xE0]
000074c379ddad3e  add rsp, 0xF0
000074c379ddad45  pop r11
000074c379ddad47  pop r10
000074c379ddad49  pop r9
000074c379ddad4b  pop r8
000074c379ddad4d  pop rsi
000074c379ddad4e  pop rdi
000074c379ddad4f  pop rdx
000074c379ddad50  pop rcx
000074c379ddad51  pop rax
000074c379ddad52  add rsp, 0x08
000074c379ddad56  jmp 0x000074C379DD6549
000074c379ddad5b  sub rsp, 0x08
000074c379ddad5f  push rax
000074c379ddad60  push rcx
000074c379ddad61  push rdx
000074c379ddad62  push rdi
000074c379ddad63  push rsi
000074c379ddad64  push r8
000074c379ddad66  push r9
000074c379ddad68  push r10
000074c379ddad6a  push r11
000074c379ddad6c  sub rsp, 0xF0
000074c379ddad73  vmovaps [rsp], xmm0
000074c379ddad78  vmovaps [rsp+0x10], xmm1
000074c379ddad7e  vmovaps [rsp+0x20], xmm2
000074c379ddad84  vmovaps [rsp+0x30], xmm3
000074c379ddad8a  vmovaps [rsp+0x40], xmm4
000074c379ddad90  vmovaps [rsp+0x50], xmm5
000074c379ddad96  vmovaps [rsp+0x60], xmm6
000074c379ddad9c  vmovaps [rsp+0x70], xmm7
000074c379ddada2  vmovaps [rsp+0x80], xmm8
000074c379ddadab  vmovaps [rsp+0x90], xmm9
000074c379ddadb4  vmovaps [rsp+0xA0], xmm10
000074c379ddadbd  vmovaps [rsp+0xB0], xmm11
000074c379ddadc6  vmovaps [rsp+0xC0], xmm12
000074c379ddadcf  vmovaps [rsp+0xD0], xmm13
000074c379ddadd8  vmovaps [rsp+0xE0], xmm15
000074c379ddade1  sub rsp, 0x30
000074c379ddade5  movaps [rsp], xmm14
000074c379ddadea  movaps [rsp+0x10], xmm9
000074c379ddadf0  movaps [rsp+0x20], xmm1
000074c379ddadf5  lea rdi, [rsp]
000074c379ddadf9  mov esi, 0x00
000074c379ddadfe  mov rax, 0x56321ABA4530
000074c379ddae08  call rax
000074c379ddae0a  movaps xmm14, [rsp]
000074c379ddae0f  add rsp, 0x30
000074c379ddae13  vmovaps xmm0, [rsp]
000074c379ddae18  vmovaps xmm1, [rsp+0x10]
000074c379ddae1e  vmovaps xmm2, [rsp+0x20]
000074c379ddae24  vmovaps xmm3, [rsp+0x30]
000074c379ddae2a  vmovaps xmm4, [rsp+0x40]
000074c379ddae30  vmovaps xmm5, [rsp+0x50]
000074c379ddae36  vmovaps xmm6, [rsp+0x60]
000074c379ddae3c  vmovaps xmm7, [rsp+0x70]
000074c379ddae42  vmovaps xmm8, [rsp+0x80]
000074c379ddae4b  vmovaps xmm9, [rsp+0x90]
000074c379ddae54  vmovaps xmm10, [rsp+0xA0]
000074c379ddae5d  vmovaps xmm11, [rsp+0xB0]
000074c379ddae66  vmovaps xmm12, [rsp+0xC0]
000074c379ddae6f  vmovaps xmm13, [rsp+0xD0]
000074c379ddae78  vmovaps xmm15, [rsp+0xE0]
000074c379ddae81  add rsp, 0xF0
000074c379ddae88  pop r11
000074c379ddae8a  pop r10
000074c379ddae8c  pop r9
000074c379ddae8e  pop r8
000074c379ddae90  pop rsi
000074c379ddae91  pop rdi
000074c379ddae92  pop rdx
000074c379ddae93  pop rcx
000074c379ddae94  pop rax
000074c379ddae95  add rsp, 0x08
000074c379ddae99  jmp 0x000074C379DD6578
000074c379ddae9e  sub rsp, 0x08
000074c379ddaea2  push rax
000074c379ddaea3  push rcx
000074c379ddaea4  push rdx
000074c379ddaea5  push rdi
000074c379ddaea6  push rsi
000074c379ddaea7  push r8
000074c379ddaea9  push r9
000074c379ddaeab  push r10
000074c379ddaead  push r11
000074c379ddaeaf  sub rsp, 0xF0
000074c379ddaeb6  vmovaps [rsp], xmm0
000074c379ddaebb  vmovaps [rsp+0x10], xmm2
000074c379ddaec1  vmovaps [rsp+0x20], xmm3
000074c379ddaec7  vmovaps [rsp+0x30], xmm4
000074c379ddaecd  vmovaps [rsp+0x40], xmm5
000074c379ddaed3  vmovaps [rsp+0x50], xmm6
000074c379ddaed9  vmovaps [rsp+0x60], xmm7
000074c379ddaedf  vmovaps [rsp+0x70], xmm8
000074c379ddaee5  vmovaps [rsp+0x80], xmm9
000074c379ddaeee  vmovaps [rsp+0x90], xmm10
000074c379ddaef7  vmovaps [rsp+0xA0], xmm11
000074c379ddaf00  vmovaps [rsp+0xB0], xmm12
000074c379ddaf09  vmovaps [rsp+0xC0], xmm13
000074c379ddaf12  vmovaps [rsp+0xD0], xmm14
000074c379ddaf1b  vmovaps [rsp+0xE0], xmm15
000074c379ddaf24  sub rsp, 0x30
000074c379ddaf28  movaps [rsp], xmm1
000074c379ddaf2c  movaps [rsp+0x10], xmm13
000074c379ddaf32  movaps [rsp+0x20], xmm8
000074c379ddaf38  lea rdi, [rsp]
000074c379ddaf3c  mov esi, 0x00
000074c379ddaf41  mov rax, 0x56321ABA4530
000074c379ddaf4b  call rax
000074c379ddaf4d  movaps xmm1, [rsp]
000074c379ddaf51  add rsp, 0x30
000074c379ddaf55  vmovaps xmm0, [rsp]
000074c379ddaf5a  vmovaps xmm2, [rsp+0x10]
000074c379ddaf60  vmovaps xmm3, [rsp+0x20]
000074c379ddaf66  vmovaps xmm4, [rsp+0x30]
000074c379ddaf6c  vmovaps xmm5, [rsp+0x40]
000074c379ddaf72  vmovaps xmm6, [rsp+0x50]
000074c379ddaf78  vmovaps xmm7, [rsp+0x60]
000074c379ddaf7e  vmovaps xmm8, [rsp+0x70]
000074c379ddaf84  vmovaps xmm9, [rsp+0x80]
000074c379ddaf8d  vmovaps xmm10, [rsp+0x90]
000074c379ddaf96  vmovaps xmm11, [rsp+0xA0]
000074c379ddaf9f  vmovaps xmm12, [rsp+0xB0]
000074c379ddafa8  vmovaps xmm13, [rsp+0xC0]
000074c379ddafb1  vmovaps xmm14, [rsp+0xD0]
000074c379ddafba  vmovaps xmm15, [rsp+0xE0]
000074c379ddafc3  add rsp, 0xF0
000074c379ddafca  pop r11
000074c379ddafcc  pop r10
000074c379ddafce  pop r9
000074c379ddafd0  pop r8
000074c379ddafd2  pop rsi
000074c379ddafd3  pop rdi
000074c379ddafd4  pop rdx
000074c379ddafd5  pop rcx
000074c379ddafd6  pop rax
000074c379ddafd7  add rsp, 0x08
000074c379ddafdb  jmp 0x000074C379DD659A
000074c379ddafe0  call 0x000074C379C0C260
000074c379ddafe5  jmp 0x000074C379DD65A8
000074c379ddafea  call 0x000074C379CDE950
000074c379ddafef  jmp 0x000074C379DD65B2
000074c379ddaff4  sub rsp, 0x08
000074c379ddaff8  push rax
000074c379ddaff9  push rcx
000074c379ddaffa  push rdx
000074c379ddaffb  push rdi
000074c379ddaffc  push rsi
000074c379ddaffd  push r8
000074c379ddafff  push r9
000074c379ddb001  push r10
000074c379ddb003  push r11
000074c379ddb005  sub rsp, 0xF0
000074c379ddb00c  vmovaps [rsp], xmm0
000074c379ddb011  vmovaps [rsp+0x10], xmm1
000074c379ddb017  vmovaps [rsp+0x20], xmm2
000074c379ddb01d  vmovaps [rsp+0x30], xmm3
000074c379ddb023  vmovaps [rsp+0x40], xmm4
000074c379ddb029  vmovaps [rsp+0x50], xmm5
000074c379ddb02f  vmovaps [rsp+0x60], xmm6
000074c379ddb035  vmovaps [rsp+0x70], xmm7
000074c379ddb03b  vmovaps [rsp+0x80], xmm9
000074c379ddb044  vmovaps [rsp+0x90], xmm10
000074c379ddb04d  vmovaps [rsp+0xA0], xmm11
000074c379ddb056  vmovaps [rsp+0xB0], xmm12
000074c379ddb05f  vmovaps [rsp+0xC0], xmm13
000074c379ddb068  vmovaps [rsp+0xD0], xmm14
000074c379ddb071  vmovaps [rsp+0xE0], xmm15
000074c379ddb07a  sub rsp, 0x30
000074c379ddb07e  movaps [rsp], xmm8
000074c379ddb083  movaps [rsp+0x10], xmm15
000074c379ddb089  movaps [rsp+0x20], xmm7
000074c379ddb08e  lea rdi, [rsp]
000074c379ddb092  mov esi, 0x00
000074c379ddb097  mov rax, 0x56321ABA4530
000074c379ddb0a1  call rax
000074c379ddb0a3  movaps xmm8, [rsp]
000074c379ddb0a8  add rsp, 0x30
000074c379ddb0ac  vmovaps xmm0, [rsp]
000074c379ddb0b1  vmovaps xmm1, [rsp+0x10]
000074c379ddb0b7  vmovaps xmm2, [rsp+0x20]
000074c379ddb0bd  vmovaps xmm3, [rsp+0x30]
000074c379ddb0c3  vmovaps xmm4, [rsp+0x40]
000074c379ddb0c9  vmovaps xmm5, [rsp+0x50]
000074c379ddb0cf  vmovaps xmm6, [rsp+0x60]
000074c379ddb0d5  vmovaps xmm7, [rsp+0x70]
000074c379ddb0db  vmovaps xmm9, [rsp+0x80]
000074c379ddb0e4  vmovaps xmm10, [rsp+0x90]
000074c379ddb0ed  vmovaps xmm11, [rsp+0xA0]
000074c379ddb0f6  vmovaps xmm12, [rsp+0xB0]
000074c379ddb0ff  vmovaps xmm13, [rsp+0xC0]
000074c379ddb108  vmovaps xmm14, [rsp+0xD0]
000074c379ddb111  vmovaps xmm15, [rsp+0xE0]
000074c379ddb11a  add rsp, 0xF0
000074c379ddb121  pop r11
000074c379ddb123  pop r10
000074c379ddb125  pop r9
000074c379ddb127  pop r8
000074c379ddb129  pop rsi
000074c379ddb12a  pop rdi
000074c379ddb12b  pop rdx
000074c379ddb12c  pop rcx
000074c379ddb12d  pop rax
000074c379ddb12e  add rsp, 0x08
000074c379ddb132  jmp 0x000074C379DD65D4
000074c379ddb137  sub rsp, 0x08
000074c379ddb13b  push rax
000074c379ddb13c  push rcx
000074c379ddb13d  push rdx
000074c379ddb13e  push rdi
000074c379ddb13f  push rsi
000074c379ddb140  push r8
000074c379ddb142  push r9
000074c379ddb144  push r10
000074c379ddb146  push r11
000074c379ddb148  sub rsp, 0xF0
000074c379ddb14f  vmovaps [rsp], xmm0
000074c379ddb154  vmovaps [rsp+0x10], xmm1
000074c379ddb15a  vmovaps [rsp+0x20], xmm2
000074c379ddb160  vmovaps [rsp+0x30], xmm3
000074c379ddb166  vmovaps [rsp+0x40], xmm4
000074c379ddb16c  vmovaps [rsp+0x50], xmm5
000074c379ddb172  vmovaps [rsp+0x60], xmm6
000074c379ddb178  vmovaps [rsp+0x70], xmm8
000074c379ddb17e  vmovaps [rsp+0x80], xmm9
000074c379ddb187  vmovaps [rsp+0x90], xmm10
000074c379ddb190  vmovaps [rsp+0xA0], xmm11
000074c379ddb199  vmovaps [rsp+0xB0], xmm12
000074c379ddb1a2  vmovaps [rsp+0xC0], xmm13
000074c379ddb1ab  vmovaps [rsp+0xD0], xmm14
000074c379ddb1b4  vmovaps [rsp+0xE0], xmm15
000074c379ddb1bd  sub rsp, 0x30
000074c379ddb1c1  movaps [rsp], xmm7
000074c379ddb1c5  movaps [rsp+0x10], xmm9
000074c379ddb1cb  movaps [rsp+0x20], xmm15
000074c379ddb1d1  lea rdi, [rsp]
000074c379ddb1d5  mov esi, 0x00
000074c379ddb1da  mov rax, 0x56321ABA4530
000074c379ddb1e4  call rax
000074c379ddb1e6  movaps xmm7, [rsp]
000074c379ddb1ea  add rsp, 0x30
000074c379ddb1ee  vmovaps xmm0, [rsp]
000074c379ddb1f3  vmovaps xmm1, [rsp+0x10]
000074c379ddb1f9  vmovaps xmm2, [rsp+0x20]
000074c379ddb1ff  vmovaps xmm3, [rsp+0x30]
000074c379ddb205  vmovaps xmm4, [rsp+0x40]
000074c379ddb20b  vmovaps xmm5, [rsp+0x50]
000074c379ddb211  vmovaps xmm6, [rsp+0x60]
000074c379ddb217  vmovaps xmm8, [rsp+0x70]
000074c379ddb21d  vmovaps xmm9, [rsp+0x80]
000074c379ddb226  vmovaps xmm10, [rsp+0x90]
000074c379ddb22f  vmovaps xmm11, [rsp+0xA0]
000074c379ddb238  vmovaps xmm12, [rsp+0xB0]
000074c379ddb241  vmovaps xmm13, [rsp+0xC0]
000074c379ddb24a  vmovaps xmm14, [rsp+0xD0]
000074c379ddb253  vmovaps xmm15, [rsp+0xE0]
000074c379ddb25c  add rsp, 0xF0
000074c379ddb263  pop r11
000074c379ddb265  pop r10
000074c379ddb267  pop r9
000074c379ddb269  pop r8
000074c379ddb26b  pop rsi
000074c379ddb26c  pop rdi
000074c379ddb26d  pop rdx
000074c379ddb26e  pop rcx
000074c379ddb26f  pop rax
000074c379ddb270  add rsp, 0x08
000074c379ddb274  jmp 0x000074C379DD6601
000074c379ddb279  sub rsp, 0x08
000074c379ddb27d  push rax
000074c379ddb27e  push rcx
000074c379ddb27f  push rdx
000074c379ddb280  push rdi
000074c379ddb281  push rsi
000074c379ddb282  push r8
000074c379ddb284  push r9
000074c379ddb286  push r10
000074c379ddb288  push r11
000074c379ddb28a  sub rsp, 0xF0
000074c379ddb291  vmovaps [rsp], xmm0
000074c379ddb296  vmovaps [rsp+0x10], xmm1
000074c379ddb29c  vmovaps [rsp+0x20], xmm2
000074c379ddb2a2  vmovaps [rsp+0x30], xmm3
000074c379ddb2a8  vmovaps [rsp+0x40], xmm4
000074c379ddb2ae  vmovaps [rsp+0x50], xmm5
000074c379ddb2b4  vmovaps [rsp+0x60], xmm6
000074c379ddb2ba  vmovaps [rsp+0x70], xmm7
000074c379ddb2c0  vmovaps [rsp+0x80], xmm8
000074c379ddb2c9  vmovaps [rsp+0x90], xmm10
000074c379ddb2d2  vmovaps [rsp+0xA0], xmm11
000074c379ddb2db  vmovaps [rsp+0xB0], xmm12
000074c379ddb2e4  vmovaps [rsp+0xC0], xmm13
000074c379ddb2ed  vmovaps [rsp+0xD0], xmm14
000074c379ddb2f6  vmovaps [rsp+0xE0], xmm15
000074c379ddb2ff  sub rsp, 0x30
000074c379ddb303  movaps [rsp], xmm9
000074c379ddb308  movaps [rsp+0x10], xmm13
000074c379ddb30e  movaps [rsp+0x20], xmm15
000074c379ddb314  lea rdi, [rsp]
000074c379ddb318  mov esi, 0x00
000074c379ddb31d  mov rax, 0x56321ABA4530
000074c379ddb327  call rax
000074c379ddb329  movaps xmm9, [rsp]
000074c379ddb32e  add rsp, 0x30
000074c379ddb332  vmovaps xmm0, [rsp]
000074c379ddb337  vmovaps xmm1, [rsp+0x10]
000074c379ddb33d  vmovaps xmm2, [rsp+0x20]
000074c379ddb343  vmovaps xmm3, [rsp+0x30]
000074c379ddb349  vmovaps xmm4, [rsp+0x40]
000074c379ddb34f  vmovaps xmm5, [rsp+0x50]
000074c379ddb355  vmovaps xmm6, [rsp+0x60]
000074c379ddb35b  vmovaps xmm7, [rsp+0x70]
000074c379ddb361  vmovaps xmm8, [rsp+0x80]
000074c379ddb36a  vmovaps xmm10, [rsp+0x90]
000074c379ddb373  vmovaps xmm11, [rsp+0xA0]
000074c379ddb37c  vmovaps xmm12, [rsp+0xB0]
000074c379ddb385  vmovaps xmm13, [rsp+0xC0]
000074c379ddb38e  vmovaps xmm14, [rsp+0xD0]
000074c379ddb397  vmovaps xmm15, [rsp+0xE0]
000074c379ddb3a0  add rsp, 0xF0
000074c379ddb3a7  pop r11
000074c379ddb3a9  pop r10
000074c379ddb3ab  pop r9
000074c379ddb3ad  pop r8
000074c379ddb3af  pop rsi
000074c379ddb3b0  pop rdi
000074c379ddb3b1  pop rdx
000074c379ddb3b2  pop rcx
000074c379ddb3b3  pop rax
000074c379ddb3b4  add rsp, 0x08
000074c379ddb3b8  jmp 0x000074C379DD662F
000074c379ddb3bd  sub rsp, 0x08
000074c379ddb3c1  push rax
000074c379ddb3c2  push rcx
000074c379ddb3c3  push rdx
000074c379ddb3c4  push rdi
000074c379ddb3c5  push rsi
000074c379ddb3c6  push r8
000074c379ddb3c8  push r9
000074c379ddb3ca  push r10
000074c379ddb3cc  push r11
000074c379ddb3ce  sub rsp, 0xF0
000074c379ddb3d5  vmovaps [rsp], xmm0
000074c379ddb3da  vmovaps [rsp+0x10], xmm1
000074c379ddb3e0  vmovaps [rsp+0x20], xmm2
000074c379ddb3e6  vmovaps [rsp+0x30], xmm3
000074c379ddb3ec  vmovaps [rsp+0x40], xmm4
000074c379ddb3f2  vmovaps [rsp+0x50], xmm5
000074c379ddb3f8  vmovaps [rsp+0x60], xmm6
000074c379ddb3fe  vmovaps [rsp+0x70], xmm7
000074c379ddb404  vmovaps [rsp+0x80], xmm8
000074c379ddb40d  vmovaps [rsp+0x90], xmm9
000074c379ddb416  vmovaps [rsp+0xA0], xmm10
000074c379ddb41f  vmovaps [rsp+0xB0], xmm11
000074c379ddb428  vmovaps [rsp+0xC0], xmm12
000074c379ddb431  vmovaps [rsp+0xD0], xmm13
000074c379ddb43a  vmovaps [rsp+0xE0], xmm14
000074c379ddb443  sub rsp, 0x30
000074c379ddb447  movaps [rsp], xmm15
000074c379ddb44c  movaps [rsp+0x10], xmm11
000074c379ddb452  movaps [rsp+0x20], xmm12
000074c379ddb458  lea rdi, [rsp]
000074c379ddb45c  mov esi, 0x00
000074c379ddb461  mov rax, 0x56321ABA4530
000074c379ddb46b  call rax
000074c379ddb46d  movaps xmm15, [rsp]
000074c379ddb472  add rsp, 0x30
000074c379ddb476  vmovaps xmm0, [rsp]
000074c379ddb47b  vmovaps xmm1, [rsp+0x10]
000074c379ddb481  vmovaps xmm2, [rsp+0x20]
000074c379ddb487  vmovaps xmm3, [rsp+0x30]
000074c379ddb48d  vmovaps xmm4, [rsp+0x40]
000074c379ddb493  vmovaps xmm5, [rsp+0x50]
000074c379ddb499  vmovaps xmm6, [rsp+0x60]
000074c379ddb49f  vmovaps xmm7, [rsp+0x70]
000074c379ddb4a5  vmovaps xmm8, [rsp+0x80]
000074c379ddb4ae  vmovaps xmm9, [rsp+0x90]
000074c379ddb4b7  vmovaps xmm10, [rsp+0xA0]
000074c379ddb4c0  vmovaps xmm11, [rsp+0xB0]
000074c379ddb4c9  vmovaps xmm12, [rsp+0xC0]
000074c379ddb4d2  vmovaps xmm13, [rsp+0xD0]
000074c379ddb4db  vmovaps xmm14, [rsp+0xE0]
000074c379ddb4e4  add rsp, 0xF0
000074c379ddb4eb  pop r11
000074c379ddb4ed  pop r10
000074c379ddb4ef  pop r9
000074c379ddb4f1  pop r8
000074c379ddb4f3  pop rsi
000074c379ddb4f4  pop rdi
000074c379ddb4f5  pop rdx
000074c379ddb4f6  pop rcx
000074c379ddb4f7  pop rax
000074c379ddb4f8  add rsp, 0x08
000074c379ddb4fc  jmp 0x000074C379DD664A
000074c379ddb501  sub rsp, 0x08
000074c379ddb505  push rax
000074c379ddb506  push rcx
000074c379ddb507  push rdx
000074c379ddb508  push rdi
000074c379ddb509  push rsi
000074c379ddb50a  push r8
000074c379ddb50c  push r9
000074c379ddb50e  push r10
000074c379ddb510  push r11
000074c379ddb512  sub rsp, 0xF0
000074c379ddb519  vmovaps [rsp], xmm0
000074c379ddb51e  vmovaps [rsp+0x10], xmm1
000074c379ddb524  vmovaps [rsp+0x20], xmm2
000074c379ddb52a  vmovaps [rsp+0x30], xmm3
000074c379ddb530  vmovaps [rsp+0x40], xmm4
000074c379ddb536  vmovaps [rsp+0x50], xmm5
000074c379ddb53c  vmovaps [rsp+0x60], xmm6
000074c379ddb542  vmovaps [rsp+0x70], xmm7
000074c379ddb548  vmovaps [rsp+0x80], xmm8
000074c379ddb551  vmovaps [rsp+0x90], xmm9
000074c379ddb55a  vmovaps [rsp+0xA0], xmm10
000074c379ddb563  vmovaps [rsp+0xB0], xmm11
000074c379ddb56c  vmovaps [rsp+0xC0], xmm12
000074c379ddb575  vmovaps [rsp+0xD0], xmm14
000074c379ddb57e  vmovaps [rsp+0xE0], xmm15
000074c379ddb587  sub rsp, 0x30
000074c379ddb58b  movaps [rsp], xmm13
000074c379ddb590  movaps [rsp+0x10], xmm10
000074c379ddb596  movaps [rsp+0x20], xmm14
000074c379ddb59c  lea rdi, [rsp]
000074c379ddb5a0  mov esi, 0x00
000074c379ddb5a5  mov rax, 0x56321ABA4530
000074c379ddb5af  call rax
000074c379ddb5b1  movaps xmm13, [rsp]
000074c379ddb5b6  add rsp, 0x30
000074c379ddb5ba  vmovaps xmm0, [rsp]
000074c379ddb5bf  vmovaps xmm1, [rsp+0x10]
000074c379ddb5c5  vmovaps xmm2, [rsp+0x20]
000074c379ddb5cb  vmovaps xmm3, [rsp+0x30]
000074c379ddb5d1  vmovaps xmm4, [rsp+0x40]
000074c379ddb5d7  vmovaps xmm5, [rsp+0x50]
000074c379ddb5dd  vmovaps xmm6, [rsp+0x60]
000074c379ddb5e3  vmovaps xmm7, [rsp+0x70]
000074c379ddb5e9  vmovaps xmm8, [rsp+0x80]
000074c379ddb5f2  vmovaps xmm9, [rsp+0x90]
000074c379ddb5fb  vmovaps xmm10, [rsp+0xA0]
000074c379ddb604  vmovaps xmm11, [rsp+0xB0]
000074c379ddb60d  vmovaps xmm12, [rsp+0xC0]
000074c379ddb616  vmovaps xmm14, [rsp+0xD0]
000074c379ddb61f  vmovaps xmm15, [rsp+0xE0]
000074c379ddb628  add rsp, 0xF0
000074c379ddb62f  pop r11
000074c379ddb631  pop r10
000074c379ddb633  pop r9
000074c379ddb635  pop r8
000074c379ddb637  pop rsi
000074c379ddb638  pop rdi
000074c379ddb639  pop rdx
000074c379ddb63a  pop rcx
000074c379ddb63b  pop rax
000074c379ddb63c  add rsp, 0x08
000074c379ddb640  jmp 0x000074C379DD666D
000074c379ddb645  sub rsp, 0x08
000074c379ddb649  push rax
000074c379ddb64a  push rcx
000074c379ddb64b  push rdx
000074c379ddb64c  push rdi
000074c379ddb64d  push rsi
000074c379ddb64e  push r8
000074c379ddb650  push r9
000074c379ddb652  push r10
000074c379ddb654  push r11
000074c379ddb656  sub rsp, 0xF0
000074c379ddb65d  vmovaps [rsp], xmm0
000074c379ddb662  vmovaps [rsp+0x10], xmm1
000074c379ddb668  vmovaps [rsp+0x20], xmm2
000074c379ddb66e  vmovaps [rsp+0x30], xmm3
000074c379ddb674  vmovaps [rsp+0x40], xmm4
000074c379ddb67a  vmovaps [rsp+0x50], xmm5
000074c379ddb680  vmovaps [rsp+0x60], xmm6
000074c379ddb686  vmovaps [rsp+0x70], xmm7
000074c379ddb68c  vmovaps [rsp+0x80], xmm8
000074c379ddb695  vmovaps [rsp+0x90], xmm9
000074c379ddb69e  vmovaps [rsp+0xA0], xmm10
000074c379ddb6a7  vmovaps [rsp+0xB0], xmm11
000074c379ddb6b0  vmovaps [rsp+0xC0], xmm12
000074c379ddb6b9  vmovaps [rsp+0xD0], xmm13
000074c379ddb6c2  vmovaps [rsp+0xE0], xmm15
000074c379ddb6cb  sub rsp, 0x30
000074c379ddb6cf  movaps [rsp], xmm14
000074c379ddb6d4  movaps [rsp+0x10], xmm1
000074c379ddb6d9  movaps [rsp+0x20], xmm7
000074c379ddb6de  lea rdi, [rsp]
000074c379ddb6e2  mov esi, 0x00
000074c379ddb6e7  mov rax, 0x56321ABA4530
000074c379ddb6f1  call rax
000074c379ddb6f3  movaps xmm14, [rsp]
000074c379ddb6f8  add rsp, 0x30
000074c379ddb6fc  vmovaps xmm0, [rsp]
000074c379ddb701  vmovaps xmm1, [rsp+0x10]
000074c379ddb707  vmovaps xmm2, [rsp+0x20]
000074c379ddb70d  vmovaps xmm3, [rsp+0x30]
000074c379ddb713  vmovaps xmm4, [rsp+0x40]
000074c379ddb719  vmovaps xmm5, [rsp+0x50]
000074c379ddb71f  vmovaps xmm6, [rsp+0x60]
000074c379ddb725  vmovaps xmm7, [rsp+0x70]
000074c379ddb72b  vmovaps xmm8, [rsp+0x80]
000074c379ddb734  vmovaps xmm9, [rsp+0x90]
000074c379ddb73d  vmovaps xmm10, [rsp+0xA0]
000074c379ddb746  vmovaps xmm11, [rsp+0xB0]
000074c379ddb74f  vmovaps xmm12, [rsp+0xC0]
000074c379ddb758  vmovaps xmm13, [rsp+0xD0]
000074c379ddb761  vmovaps xmm15, [rsp+0xE0]
000074c379ddb76a  add rsp, 0xF0
000074c379ddb771  pop r11
000074c379ddb773  pop r10
000074c379ddb775  pop r9
000074c379ddb777  pop r8
000074c379ddb779  pop rsi
000074c379ddb77a  pop rdi
000074c379ddb77b  pop rdx
000074c379ddb77c  pop rcx
000074c379ddb77d  pop rax
000074c379ddb77e  add rsp, 0x08
000074c379ddb782  jmp 0x000074C379DD6690
000074c379ddb787  sub rsp, 0x08
000074c379ddb78b  push rax
000074c379ddb78c  push rcx
000074c379ddb78d  push rdx
000074c379ddb78e  push rdi
000074c379ddb78f  push rsi
000074c379ddb790  push r8
000074c379ddb792  push r9
000074c379ddb794  push r10
000074c379ddb796  push r11
000074c379ddb798  sub rsp, 0xF0
000074c379ddb79f  vmovaps [rsp], xmm0
000074c379ddb7a4  vmovaps [rsp+0x10], xmm2
000074c379ddb7aa  vmovaps [rsp+0x20], xmm3
000074c379ddb7b0  vmovaps [rsp+0x30], xmm4
000074c379ddb7b6  vmovaps [rsp+0x40], xmm5
000074c379ddb7bc  vmovaps [rsp+0x50], xmm6
000074c379ddb7c2  vmovaps [rsp+0x60], xmm7
000074c379ddb7c8  vmovaps [rsp+0x70], xmm8
000074c379ddb7ce  vmovaps [rsp+0x80], xmm9
000074c379ddb7d7  vmovaps [rsp+0x90], xmm10
000074c379ddb7e0  vmovaps [rsp+0xA0], xmm11
000074c379ddb7e9  vmovaps [rsp+0xB0], xmm12
000074c379ddb7f2  vmovaps [rsp+0xC0], xmm13
000074c379ddb7fb  vmovaps [rsp+0xD0], xmm14
000074c379ddb804  vmovaps [rsp+0xE0], xmm15
000074c379ddb80d  sub rsp, 0x30
000074c379ddb811  movaps [rsp], xmm1
000074c379ddb815  movaps [rsp+0x10], xmm8
000074c379ddb81b  movaps [rsp+0x20], xmm9
000074c379ddb821  lea rdi, [rsp]
000074c379ddb825  mov esi, 0x00
000074c379ddb82a  mov rax, 0x56321ABA4530
000074c379ddb834  call rax
000074c379ddb836  movaps xmm1, [rsp]
000074c379ddb83a  add rsp, 0x30
000074c379ddb83e  vmovaps xmm0, [rsp]
000074c379ddb843  vmovaps xmm2, [rsp+0x10]
000074c379ddb849  vmovaps xmm3, [rsp+0x20]
000074c379ddb84f  vmovaps xmm4, [rsp+0x30]
000074c379ddb855  vmovaps xmm5, [rsp+0x40]
000074c379ddb85b  vmovaps xmm6, [rsp+0x50]
000074c379ddb861  vmovaps xmm7, [rsp+0x60]
000074c379ddb867  vmovaps xmm8, [rsp+0x70]
000074c379ddb86d  vmovaps xmm9, [rsp+0x80]
000074c379ddb876  vmovaps xmm10, [rsp+0x90]
000074c379ddb87f  vmovaps xmm11, [rsp+0xA0]
000074c379ddb888  vmovaps xmm12, [rsp+0xB0]
000074c379ddb891  vmovaps xmm13, [rsp+0xC0]
000074c379ddb89a  vmovaps xmm14, [rsp+0xD0]
000074c379ddb8a3  vmovaps xmm15, [rsp+0xE0]
000074c379ddb8ac  add rsp, 0xF0
000074c379ddb8b3  pop r11
000074c379ddb8b5  pop r10
000074c379ddb8b7  pop r9
000074c379ddb8b9  pop r8
000074c379ddb8bb  pop rsi
000074c379ddb8bc  pop rdi
000074c379ddb8bd  pop rdx
000074c379ddb8be  pop rcx
000074c379ddb8bf  pop rax
000074c379ddb8c0  add rsp, 0x08
000074c379ddb8c4  jmp 0x000074C379DD66B2
000074c379ddb8c9  call 0x000074C379CB3E40
000074c379ddb8ce  jmp 0x000074C379DD66C0
000074c379ddb8d3  call 0x000074C379C0C380
000074c379ddb8d8  jmp 0x000074C379DD66CA
000074c379ddb8dd  call 0x000074C379C0D600
000074c379ddb8e2  jmp 0x000074C379DD66D4
000074c379ddb8e7  call 0x000074C379BFF540
000074c379ddb8ec  jmp 0x000074C379DD66DE
000074c379ddb8f1  int3
000074c379ddb8f2  nop [rax+rax*1], ax
000074c379ddb8fb  nop [rax+rax*1], eax
000074c379ddb900  mov eax, [r15+0x48]
000074c379ddb904  lea r14d, [eax+0x01]
000074c379ddb909  mov [rsp+0x10], r14d
000074c379ddb90e  mov r14d, r14d
000074c379ddb911  mov [r15+0x48], r14
000074c379ddb915  xor eax, eax
000074c379ddb917  mov r14d, [rsp+0x10]
000074c379ddb91c  cmp r14d, 0x1F4
000074c379ddb923  cmc
000074c379ddb924  lahf
000074c379ddb925  seto al
000074c379ddb928  mov [r15+0x108], eax
000074c379ddb92f  mov eax, [r15+0x108]
000074c379ddb936  sahf
000074c379ddb937  jnz 0x000074C379DDB969
000074c379ddb939  cmp dword ptr [r15+0x318], 0x00
000074c379ddb941  jz 0x000074C379DE1AB0
000074c379ddb947  nop [rax+rax*1], ax
000074c379ddb950  nop [rax+rax*1], eax
000074c379ddb958  mov eax, 0x410450
000074c379ddb95d  mov [r15+0x100], rax
000074c379ddb964  jmp 0x000074C379BFE110
000074c379ddb969  cmp dword ptr [r15+0x318], 0x00
000074c379ddb971  jz 0x000074C379DDB9A0
000074c379ddb977  nop [rax+rax*1], ax
000074c379ddb980  nop [rax+rax*1], eax
000074c379ddb988  mov eax, 0x410274
000074c379ddb98d  mov [r15+0x100], rax
000074c379ddb994  jmp 0x000074C379BFE110
000074c379ddb999  int3
000074c379ddb99a  int3
000074c379ddb99b  nop [rax+rax*1], eax
000074c379ddb9a0  mov rax, [r15+0x40]
000074c379ddb9a4  movaps xmm1, [r15+0x1D0]
000074c379ddb9ac  vmovaps [rsp+0x10], xmm1
000074c379ddb9b2  vmovaps xmm15, [rsp+0x10]
000074c379ddb9b8  por xmm1, xmm15
000074c379ddb9bd  movaps xmm14, [r15+0x1A0]
000074c379ddb9c5  vmovaps [rsp+0x10], xmm14
000074c379ddb9cb  vmovaps xmm13, [rsp+0x10]
000074c379ddb9d1  por xmm14, xmm13
000074c379ddb9d6  lea r14, [rax+0x30]
000074c379ddb9da  mov r12, [r13+r14*1]
000074c379ddb9df  lea r14, [rax+0x38]
000074c379ddb9e3  mov r11, [r13+r14*1]
000074c379ddb9e8  movq xmm13, r12
000074c379ddb9ed  movq xmm12, r11
000074c379ddb9f2  movq xmm13, xmm13
000074c379ddb9f7  vmovaps [rsp+0x10], xmm13
000074c379ddb9fd  movq xmm13, xmm13
000074c379ddba02  movaps [r15+0x130], xmm13
000074c379ddba0a  movq xmm12, xmm12
000074c379ddba0f  vmovaps [rsp+0x20], xmm12
000074c379ddba15  movq xmm12, xmm12
000074c379ddba1a  movaps [r15+0x280], xmm12
000074c379ddba22  movaps xmm13, [r15+0x270]
000074c379ddba2a  vmovaps [rsp+0x30], xmm13
000074c379ddba30  vmovaps xmm12, [rsp+0x30]
000074c379ddba36  por xmm13, xmm12
000074c379ddba3b  lea r14, [rax+0x20]
000074c379ddba3f  mov r12, [r13+r14*1]
000074c379ddba44  lea r14, [rax+0x28]
000074c379ddba48  mov r11, [r13+r14*1]
000074c379ddba4d  movq xmm12, r12
000074c379ddba52  movq xmm11, r11
000074c379ddba57  movq xmm12, xmm12
000074c379ddba5c  vmovaps [rsp+0x30], xmm12
000074c379ddba62  movq xmm12, xmm12
000074c379ddba67  movaps [r15+0x150], xmm12
000074c379ddba6f  movq xmm11, xmm11
000074c379ddba74  vmovaps [rsp+0x40], xmm11
000074c379ddba7a  movq xmm11, xmm11
000074c379ddba7f  movaps [r15+0x140], xmm11
000074c379ddba87  lea r14, [rax+0x10]
000074c379ddba8b  mov r12, [r13+r14*1]
000074c379ddba90  lea r14, [rax+0x18]
000074c379ddba94  mov r11, [r13+r14*1]
000074c379ddba99  movq xmm12, r12
000074c379ddba9e  movq xmm11, r11
000074c379ddbaa3  movq xmm12, xmm12
000074c379ddbaa8  vmovaps [rsp+0x50], xmm12
000074c379ddbaae  movq xmm12, xmm12
000074c379ddbab3  movaps [r15+0x170], xmm12
000074c379ddbabb  movq xmm11, xmm11
000074c379ddbac0  vmovaps [rsp+0x60], xmm11
000074c379ddbac6  movq xmm11, xmm11
000074c379ddbacb  movaps [r15+0x160], xmm11
000074c379ddbad3  mov r14, [r13+rax*1]
000074c379ddbad8  vmovq xmm12, r14
000074c379ddbadd  vpbroadcastq xmm12, xmm12
000074c379ddbae2  lea r14, [rax+0x08]
000074c379ddbae6  mov rax, [r13+r14*1]
000074c379ddbaeb  movq xmm11, rax
000074c379ddbaf0  movaps [r15+0x230], xmm11
000074c379ddbaf8  mov rax, [r15+0xF8]
000074c379ddbaff  lea r14, [rax+0x50]
000074c379ddbb03  movups xmm11, [r13+r14*1]
000074c379ddbb09  lea r14, [rax+0x60]
000074c379ddbb0d  movups xmm10, [r13+r14*1]
000074c379ddbb13  lea r14, [rax+0x30]
000074c379ddbb17  movups xmm9, [r13+r14*1]
000074c379ddbb1d  mov r14, [r15+0x50]
000074c379ddbb21  mov [r15+0x60], r14
000074c379ddbb25  mov qword ptr [r15+0x58], 0x40
000074c379ddbb2d  movaps xmm8, xmm12
000074c379ddbb31  mulpd xmm8, xmm15
000074c379ddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000074c379ddbb3c  ptest xmm7, xmm7
000074c379ddbb41  jnz 0x000074C379DDC96A
000074c379ddbb47  movq xmm15, qword ptr [r15+0x230]
000074c379ddbb50  vmovaps [rsp+0x70], xmm15
000074c379ddbb56  vpermilpd xmm15, xmm15, 0x00
000074c379ddbb5c  movaps xmm7, xmm9
000074c379ddbb60  mulpd xmm7, xmm15
000074c379ddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000074c379ddbb6a  ptest xmm6, xmm6
000074c379ddbb6f  jnz 0x000074C379DDCAAE
000074c379ddbb75  vxorps xmm15, xmm15, xmm15
000074c379ddbb7a  vpbroadcastq xmm15, xmm15
000074c379ddbb7f  movaps xmm9, xmm12
000074c379ddbb83  mulpd xmm9, xmm10
000074c379ddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000074c379ddbb8e  ptest xmm6, xmm6
000074c379ddbb93  jnz 0x000074C379DDCBF0
000074c379ddbb99  movaps xmm10, xmm12
000074c379ddbb9d  mulpd xmm10, xmm11
000074c379ddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000074c379ddbba8  ptest xmm6, xmm6
000074c379ddbbad  jnz 0x000074C379DDCD34
000074c379ddbbb3  movaps xmm11, [r15+0x1F0]
000074c379ddbbbb  movaps xmm6, xmm12
000074c379ddbbbf  mulpd xmm6, xmm11
000074c379ddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000074c379ddbbc9  ptest xmm5, xmm5
000074c379ddbbce  jnz 0x000074C379DDCE78
000074c379ddbbd4  movaps xmm12, [r15+0x2A0]
000074c379ddbbdc  vmovaps [rsp+0x80], xmm12
000074c379ddbbe5  vmovaps xmm11, [rsp+0x80]
000074c379ddbbee  por xmm12, xmm11
000074c379ddbbf3  movaps xmm11, [r15+0x250]
000074c379ddbbfb  vmovaps [rsp+0x80], xmm11
000074c379ddbc04  vmovaps xmm5, [rsp+0x80]
000074c379ddbc0d  por xmm11, xmm5
000074c379ddbc12  vmovaps xmm4, [rsp+0x70]
000074c379ddbc18  vpermilpd xmm4, xmm4, 0x00
000074c379ddbc1e  movaps xmm3, xmm5
000074c379ddbc21  mulpd xmm3, xmm4
000074c379ddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000074c379ddbc2a  ptest xmm2, xmm2
000074c379ddbc2f  jnz 0x000074C379DDCFBA
000074c379ddbc35  mov [rsp+0x80], rax
000074c379ddbc3d  xor eax, eax
000074c379ddbc3f  mov r12d, 0x40
000074c379ddbc45  mov r11d, 0x200
000074c379ddbc4b  cmp r12, r11
000074c379ddbc4e  cmc
000074c379ddbc4f  lahf
000074c379ddbc50  seto al
000074c379ddbc53  mov [r15+0x108], eax
000074c379ddbc5a  movaps xmm5, xmm8
000074c379ddbc5e  addpd xmm5, xmm15
000074c379ddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000074c379ddbc68  ptest xmm4, xmm4
000074c379ddbc6d  jnz 0x000074C379DDD0FA
000074c379ddbc73  movaps xmm8, [r15+0x1B0]
000074c379ddbc7b  movaps xmm4, xmm9
000074c379ddbc7f  addpd xmm4, xmm8
000074c379ddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000074c379ddbc89  ptest xmm2, xmm2
000074c379ddbc8e  jnz 0x000074C379DDD23C
000074c379ddbc94  movaps xmm9, xmm10
000074c379ddbc98  addpd xmm9, xmm8
000074c379ddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000074c379ddbca3  ptest xmm2, xmm2
000074c379ddbca8  jnz 0x000074C379DDD37E
000074c379ddbcae  movaps xmm10, [r15+0x2F0]
000074c379ddbcb6  vmovaps [rsp+0x90], xmm10
000074c379ddbcbf  vmovaps xmm8, [rsp+0x90]
000074c379ddbcc8  por xmm10, xmm8
000074c379ddbccd  movaps xmm8, [r15+0x2E0]
000074c379ddbcd5  vmovaps [rsp+0x90], xmm8
000074c379ddbcde  vmovaps xmm2, [rsp+0x90]
000074c379ddbce7  por xmm8, xmm2
000074c379ddbcec  movaps xmm2, [r15+0x2D0]
000074c379ddbcf4  vmovaps [rsp+0x90], xmm2
000074c379ddbcfd  vmovaps [rsp+0xA0], xmm1
000074c379ddbd06  vmovaps xmm1, [rsp+0x90]
000074c379ddbd0f  por xmm2, xmm1
000074c379ddbd13  movaps xmm1, [r15+0x200]
000074c379ddbd1b  vmovaps [rsp+0x90], xmm1
000074c379ddbd24  vmovaps [rsp+0xB0], xmm15
000074c379ddbd2d  vmovaps xmm15, [rsp+0x90]
000074c379ddbd36  por xmm1, xmm15
000074c379ddbd3b  movaps xmm15, [r15+0x1C0]
000074c379ddbd43  vmovaps [rsp+0x90], xmm15
000074c379ddbd4c  vmovaps [rsp+0xC0], xmm1
000074c379ddbd55  vmovaps xmm1, [rsp+0x90]
000074c379ddbd5e  por xmm15, xmm1
000074c379ddbd63  movaps xmm1, [r15+0x190]
000074c379ddbd6b  vmovaps [rsp+0x90], xmm1
000074c379ddbd74  vmovaps [rsp+0xD0], xmm15
000074c379ddbd7d  vmovaps xmm15, [rsp+0x90]
000074c379ddbd86  por xmm1, xmm15
000074c379ddbd8b  movaps xmm15, [r15+0x300]
000074c379ddbd93  vmovaps [rsp+0x90], xmm15
000074c379ddbd9c  vmovaps [rsp+0xE0], xmm1
000074c379ddbda5  vmovaps xmm1, [rsp+0x90]
000074c379ddbdae  por xmm15, xmm1
000074c379ddbdb3  mov rax, [rsp+0x80]
000074c379ddbdbb  lea r12, [rax+0xA0]
000074c379ddbdc2  movups xmm1, [r13+r12*1]
000074c379ddbdc8  lea r12, [rax+0xB0]
000074c379ddbdcf  vmovaps [rsp+0x80], xmm1
000074c379ddbdd8  movups xmm1, [r13+r12*1]
000074c379ddbdde  vmovaps [rsp+0x90], xmm1
000074c379ddbde7  vmovaps [rsp+0xF0], xmm15
000074c379ddbdf0  vmovaps xmm15, [rsp+0xB0]
000074c379ddbdf9  vmovaps [rsp+0xB0], xmm14
000074c379ddbe02  movaps xmm1, xmm6
000074c379ddbe05  addpd xmm1, xmm15
000074c379ddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000074c379ddbe0f  ptest xmm14, xmm14
000074c379ddbe15  jnz 0x000074C379DDD4D6
000074c379ddbe1b  lea r12, [rax+0xF0]
000074c379ddbe22  movups xmm15, [r13+r12*1]
000074c379ddbe28  movaps xmm14, xmm4
000074c379ddbe2c  addpd xmm14, xmm3
000074c379ddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000074c379ddbe37  ptest xmm6, xmm6
000074c379ddbe3c  jnz 0x000074C379DDD621
000074c379ddbe42  movaps xmm6, xmm9
000074c379ddbe46  addpd xmm6, xmm7
000074c379ddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000074c379ddbe4f  ptest xmm4, xmm4
000074c379ddbe54  jnz 0x000074C379DDD763
000074c379ddbe5a  vmovaps xmm9, [rsp+0x70]
000074c379ddbe60  vpermilpd xmm9, xmm9, 0x00
000074c379ddbe66  vmovaps xmm4, [rsp+0x90]
000074c379ddbe6f  movaps xmm7, xmm4
000074c379ddbe72  mulpd xmm7, xmm9
000074c379ddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000074c379ddbe7c  ptest xmm3, xmm3
000074c379ddbe81  jnz 0x000074C379DDD8A4
000074c379ddbe87  vmovaps xmm9, [rsp+0x50]
000074c379ddbe8d  vpermilpd xmm9, xmm9, 0x00
000074c379ddbe93  movaps xmm4, xmm15
000074c379ddbe97  mulpd xmm4, xmm9
000074c379ddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000074c379ddbea1  ptest xmm3, xmm3
000074c379ddbea6  jnz 0x000074C379DDD9E5
000074c379ddbeac  lea r12, [rax+0xE0]
000074c379ddbeb3  movups xmm15, [r13+r12*1]
000074c379ddbeb9  vmovaps xmm9, [rsp+0x70]
000074c379ddbebf  vpermilpd xmm9, xmm9, 0x00
000074c379ddbec5  vmovaps [rsp+0x70], xmm1
000074c379ddbecb  vmovaps xmm1, [rsp+0x80]
000074c379ddbed4  vmovaps [rsp+0x80], xmm15
000074c379ddbedd  movaps xmm3, xmm1
000074c379ddbee0  mulpd xmm3, xmm9
000074c379ddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000074c379ddbeea  ptest xmm15, xmm15
000074c379ddbef0  jnz 0x000074C379DDDB31
000074c379ddbef6  vmovaps xmm1, [rsp+0xF0]
000074c379ddbeff  vmovaps xmm15, [rsp+0xF0]
000074c379ddbf08  por xmm1, xmm15
000074c379ddbf0d  movaps [r15+0x300], xmm1
000074c379ddbf15  vmovaps xmm15, [rsp+0xE0]
000074c379ddbf1e  vmovaps xmm9, [rsp+0xE0]
000074c379ddbf27  por xmm15, xmm9
000074c379ddbf2c  movaps [r15+0x190], xmm15
000074c379ddbf34  vmovaps xmm9, [rsp+0x50]
000074c379ddbf3a  vpermilpd xmm9, xmm9, 0x00
000074c379ddbf40  vmovaps [rsp+0x90], xmm1
000074c379ddbf49  vmovaps [rsp+0xE0], xmm15
000074c379ddbf52  vmovaps xmm15, [rsp+0x80]
000074c379ddbf5b  vmovaps [rsp+0x80], xmm14
000074c379ddbf64  movaps xmm1, xmm15
000074c379ddbf68  mulpd xmm1, xmm9
000074c379ddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000074c379ddbf72  ptest xmm14, xmm14
000074c379ddbf78  jnz 0x000074C379DDDC72
000074c379ddbf7e  lea r12, [rax+0x90]
000074c379ddbf85  movups xmm15, [r13+r12*1]
000074c379ddbf8b  vmovaps xmm14, [rsp+0xD0]
000074c379ddbf94  vmovaps xmm9, [rsp+0xD0]
000074c379ddbf9d  por xmm14, xmm9
000074c379ddbfa2  movaps [r15+0x1C0], xmm14
000074c379ddbfaa  vmovaps xmm9, [rsp+0xC0]
000074c379ddbfb3  vmovaps [rsp+0xD0], xmm1
000074c379ddbfbc  vmovaps xmm1, [rsp+0xC0]
000074c379ddbfc5  por xmm9, xmm1
000074c379ddbfca  movaps [r15+0x200], xmm9
000074c379ddbfd2  vmovaps [rsp+0xC0], xmm2
000074c379ddbfdb  vmovaps xmm1, [rsp+0xC0]
000074c379ddbfe4  por xmm2, xmm1
000074c379ddbfe8  movaps [r15+0x2D0], xmm2
000074c379ddbff0  vmovaps [rsp+0xC0], xmm8
000074c379ddbff9  vmovaps xmm1, [rsp+0xC0]
000074c379ddc002  por xmm8, xmm1
000074c379ddc007  movaps [r15+0x2E0], xmm8
000074c379ddc00f  vmovaps [rsp+0xC0], xmm15
000074c379ddc018  movaps xmm1, xmm5
000074c379ddc01b  addpd xmm1, xmm7
000074c379ddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000074c379ddc024  ptest xmm15, xmm15
000074c379ddc02a  jnz 0x000074C379DDDDBE
000074c379ddc030  vmovaps xmm15, [rsp+0x50]
000074c379ddc036  vpermilpd xmm15, xmm15, 0x00
000074c379ddc03c  vmovaps xmm5, [rsp+0xC0]
000074c379ddc045  vmovaps [rsp+0xC0], xmm1
000074c379ddc04e  movaps xmm7, xmm5
000074c379ddc051  mulpd xmm7, xmm15
000074c379ddc056  vcmppd xmm1, xmm7, xmm7, 0x03
000074c379ddc05b  ptest xmm1, xmm1
000074c379ddc060  jnz 0x000074C379DDDEFE
000074c379ddc066  lea r12, [rax+0x80]
000074c379ddc06d  movups xmm1, [r13+r12*1]
000074c379ddc073  vmovaps xmm5, [rsp+0x70]
000074c379ddc079  vmovaps [rsp+0x70], xmm1
000074c379ddc07f  movaps xmm15, xmm5
000074c379ddc083  addpd xmm15, xmm3
000074c379ddc088  vcmppd xmm1, xmm15, xmm15, 0x03
000074c379ddc08e  ptest xmm1, xmm1
000074c379ddc093  jnz 0x000074C379DDE049
000074c379ddc099  vmovaps xmm5, [rsp+0x80]
000074c379ddc0a2  movaps xmm1, xmm5
000074c379ddc0a5  addpd xmm1, xmm4
000074c379ddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000074c379ddc0ae  ptest xmm3, xmm3
000074c379ddc0b3  jnz 0x000074C379DDE18B
000074c379ddc0b9  vmovaps [rsp+0x80], xmm10
000074c379ddc0c2  vmovaps xmm5, [rsp+0x80]
000074c379ddc0cb  por xmm10, xmm5
000074c379ddc0d0  movaps [r15+0x2F0], xmm10
000074c379ddc0d8  vmovaps xmm5, [rsp+0x50]
000074c379ddc0de  vpermilpd xmm5, xmm5, 0x00
000074c379ddc0e4  vmovaps xmm3, [rsp+0x70]
000074c379ddc0ea  vmovaps [rsp+0x50], xmm1
000074c379ddc0f0  movaps xmm4, xmm3
000074c379ddc0f3  mulpd xmm4, xmm5
000074c379ddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000074c379ddc0fc  ptest xmm1, xmm1
000074c379ddc101  jnz 0x000074C379DDE2CB
000074c379ddc107  lea r12, [rax+0xD0]
000074c379ddc10e  movups xmm1, [r13+r12*1]
000074c379ddc114  vmovaps xmm3, [rsp+0xD0]
000074c379ddc11d  vmovaps [rsp+0x70], xmm1
000074c379ddc123  movaps xmm5, xmm6
000074c379ddc126  addpd xmm5, xmm3
000074c379ddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000074c379ddc12f  ptest xmm1, xmm1
000074c379ddc134  jnz 0x000074C379DDE415
000074c379ddc13a  vmovaps xmm1, [rsp+0x60]
000074c379ddc140  vpermilpd xmm1, xmm1, 0x00
000074c379ddc146  movaps xmm6, xmm9
000074c379ddc14a  mulpd xmm6, xmm1
000074c379ddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000074c379ddc153  ptest xmm3, xmm3
000074c379ddc158  jnz 0x000074C379DDE555
000074c379ddc15e  movaps [r15+0x260], xmm6
000074c379ddc166  vxorps xmm1, xmm1, xmm1
000074c379ddc16a  vpbroadcastq xmm1, xmm1
000074c379ddc16f  movaps [r15+0x1B0], xmm1
000074c379ddc177  vmovaps xmm1, [rsp+0x60]
000074c379ddc17d  vpermilpd xmm1, xmm1, 0x00
000074c379ddc183  vmovaps xmm3, [rsp+0x70]
000074c379ddc189  vmovaps [rsp+0x70], xmm15
000074c379ddc18f  movaps xmm9, xmm3
000074c379ddc193  mulpd xmm9, xmm1
000074c379ddc198  vcmppd xmm15, xmm9, xmm9, 0x03
000074c379ddc19e  ptest xmm15, xmm15
000074c379ddc1a4  jnz 0x000074C379DDE696
000074c379ddc1aa  lea r12, [rax+0xC0]
000074c379ddc1b1  movups xmm1, [r13+r12*1]
000074c379ddc1b7  vmovaps xmm3, [rsp+0xC0]
000074c379ddc1c0  vmovaps [rsp+0x80], xmm1
000074c379ddc1c9  movaps xmm15, xmm3
000074c379ddc1cd  addpd xmm15, xmm7
000074c379ddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000074c379ddc1d8  ptest xmm1, xmm1
000074c379ddc1dd  jnz 0x000074C379DDE7E2
000074c379ddc1e3  vmovaps [rsp+0xC0], xmm13
000074c379ddc1ec  vmovaps xmm1, [rsp+0xC0]
000074c379ddc1f5  por xmm13, xmm1
000074c379ddc1fa  movaps [r15+0x270], xmm13
000074c379ddc202  vmovaps xmm1, [rsp+0xB0]
000074c379ddc20b  vmovaps xmm7, [rsp+0xB0]
000074c379ddc214  por xmm1, xmm7
000074c379ddc218  movaps [r15+0x1A0], xmm1
000074c379ddc220  vmovaps xmm1, [rsp+0x60]
000074c379ddc226  vpermilpd xmm1, xmm1, 0x00
000074c379ddc22c  vmovaps [rsp+0xB0], xmm1
000074c379ddc235  vmovaps xmm1, [rsp+0x80]
000074c379ddc23e  vmovaps [rsp+0x80], xmm15
000074c379ddc247  vmovaps xmm15, [rsp+0xB0]
000074c379ddc250  vmovaps [rsp+0xB0], xmm14
000074c379ddc259  movaps xmm3, xmm1
000074c379ddc25c  mulpd xmm3, xmm15
000074c379ddc261  vcmppd xmm14, xmm3, xmm3, 0x03
000074c379ddc266  ptest xmm14, xmm14
000074c379ddc26c  jnz 0x000074C379DDE924
000074c379ddc272  lea r12, [rax+0x20]
000074c379ddc276  movups xmm1, [r13+r12*1]
000074c379ddc27c  movaps [r15+0x110], xmm1
000074c379ddc284  vmovaps xmm14, [rsp+0x70]
000074c379ddc28a  vmovaps [rsp+0x70], xmm1
000074c379ddc290  movaps xmm15, xmm14
000074c379ddc294  addpd xmm15, xmm4
000074c379ddc299  vcmppd xmm1, xmm15, xmm15, 0x03
000074c379ddc29f  ptest xmm1, xmm1
000074c379ddc2a4  jnz 0x000074C379DDEA6F
000074c379ddc2aa  vmovaps xmm1, [rsp+0x60]
000074c379ddc2b0  vpermilpd xmm1, xmm1, 0x00
000074c379ddc2b6  movaps xmm14, xmm2
000074c379ddc2ba  mulpd xmm14, xmm1
000074c379ddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000074c379ddc2c5  ptest xmm4, xmm4
000074c379ddc2ca  jnz 0x000074C379DDEBB2
000074c379ddc2d0  vmovaps xmm4, [rsp+0x50]
000074c379ddc2d6  movaps xmm1, xmm4
000074c379ddc2d9  addpd xmm1, xmm9
000074c379ddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000074c379ddc2e3  ptest xmm2, xmm2
000074c379ddc2e8  jnz 0x000074C379DDECF4
000074c379ddc2ee  vmovaps xmm9, [rsp+0x30]
000074c379ddc2f4  vpermilpd xmm9, xmm9, 0x00
000074c379ddc2fa  vmovaps xmm2, [rsp+0x70]
000074c379ddc300  vmovaps [rsp+0x50], xmm1
000074c379ddc306  movaps xmm4, xmm2
000074c379ddc309  mulpd xmm4, xmm9
000074c379ddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000074c379ddc313  ptest xmm1, xmm1
000074c379ddc318  jnz 0x000074C379DDEE35
000074c379ddc31e  vmovaps xmm1, [rsp+0x30]
000074c379ddc324  vpermilpd xmm1, xmm1, 0x00
000074c379ddc32a  vmovaps xmm2, [rsp+0x90]
000074c379ddc333  vmovaps [rsp+0x60], xmm15
000074c379ddc339  movaps xmm9, xmm2
000074c379ddc33d  mulpd xmm9, xmm1
000074c379ddc342  vcmppd xmm15, xmm9, xmm9, 0x03
000074c379ddc348  ptest xmm15, xmm15
000074c379ddc34e  jnz 0x000074C379DDEF76
000074c379ddc354  vmovaps xmm15, [rsp+0x80]
000074c379ddc35d  movaps xmm1, xmm15
000074c379ddc361  addpd xmm1, xmm6
000074c379ddc365  vcmppd xmm2, xmm1, xmm1, 0x03
000074c379ddc36a  ptest xmm2, xmm2
000074c379ddc36f  jnz 0x000074C379DDF0B8
000074c379ddc375  movaps xmm15, xmm5
000074c379ddc379  addpd xmm15, xmm3
000074c379ddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000074c379ddc384  ptest xmm6, xmm6
000074c379ddc389  jnz 0x000074C379DDF1F9
000074c379ddc38f  vmovaps xmm6, [rsp+0x30]
000074c379ddc395  vpermilpd xmm6, xmm6, 0x00
000074c379ddc39b  movaps xmm5, xmm8
000074c379ddc39f  mulpd xmm5, xmm6
000074c379ddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000074c379ddc3a8  ptest xmm3, xmm3
000074c379ddc3ad  jnz 0x000074C379DDF33B
000074c379ddc3b3  vmovaps xmm8, [rsp+0x30]
000074c379ddc3b9  vpermilpd xmm8, xmm8, 0x00
000074c379ddc3bf  movaps xmm6, xmm10
000074c379ddc3c3  mulpd xmm6, xmm8
000074c379ddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000074c379ddc3cd  ptest xmm3, xmm3
000074c379ddc3d2  jnz 0x000074C379DDF47C
000074c379ddc3d8  vmovaps xmm8, [rsp+0x60]
000074c379ddc3de  movaps xmm10, xmm8
000074c379ddc3e2  addpd xmm10, xmm14
000074c379ddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000074c379ddc3ed  ptest xmm3, xmm3
000074c379ddc3f2  jnz 0x000074C379DDF5BE
000074c379ddc3f8  vmovaps xmm8, [rsp+0x50]
000074c379ddc3fe  movaps xmm14, xmm8
000074c379ddc402  addpd xmm14, xmm4
000074c379ddc407  vcmppd xmm3, xmm14, xmm14, 0x03
000074c379ddc40d  ptest xmm3, xmm3
000074c379ddc412  jnz 0x000074C379DDF702
000074c379ddc418  vmovaps xmm8, [rsp+0x40]
000074c379ddc41e  vpermilpd xmm8, xmm8, 0x00
000074c379ddc424  movaps xmm4, xmm13
000074c379ddc428  mulpd xmm4, xmm8
000074c379ddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000074c379ddc432  ptest xmm3, xmm3
000074c379ddc437  jnz 0x000074C379DDF845
000074c379ddc43d  movaps xmm13, xmm15
000074c379ddc441  addpd xmm13, xmm9
000074c379ddc446  vcmppd xmm8, xmm13, xmm13, 0x03
000074c379ddc44c  ptest xmm8, xmm8
000074c379ddc452  jnz 0x000074C379DDF987
000074c379ddc458  movaps xmm15, xmm1
000074c379ddc45c  addpd xmm15, xmm5
000074c379ddc461  vcmppd xmm9, xmm15, xmm15, 0x03
000074c379ddc467  ptest xmm9, xmm9
000074c379ddc46d  jnz 0x000074C379DDFACB
000074c379ddc473  vmovaps [rsp+0x30], xmm11
000074c379ddc479  vmovaps xmm1, [rsp+0x30]
000074c379ddc47f  por xmm11, xmm1
000074c379ddc484  movaps [r15+0x250], xmm11
000074c379ddc48c  vmovaps [rsp+0x30], xmm12
000074c379ddc492  vmovaps xmm1, [rsp+0x30]
000074c379ddc498  por xmm12, xmm1
000074c379ddc49d  movaps [r15+0x2A0], xmm12
000074c379ddc4a5  vmovaps xmm1, [rsp+0xA0]
000074c379ddc4ae  vmovaps xmm11, [rsp+0xA0]
000074c379ddc4b7  por xmm1, xmm11
000074c379ddc4bc  movaps [r15+0x1D0], xmm1
000074c379ddc4c4  lea r12, [rax+0x40]
000074c379ddc4c8  movups xmm1, [r13+r12*1]
000074c379ddc4ce  movaps [r15+0x2C0], xmm1
000074c379ddc4d6  vmovaps xmm11, [rsp+0x40]
000074c379ddc4dc  vpermilpd xmm11, xmm11, 0x00
000074c379ddc4e2  vmovaps xmm8, [rsp+0xE0]
000074c379ddc4eb  movaps xmm9, xmm8
000074c379ddc4ef  mulpd xmm9, xmm11
000074c379ddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000074c379ddc4fa  ptest xmm5, xmm5
000074c379ddc4ff  jnz 0x000074C379DDFC17
000074c379ddc505  movaps xmm11, xmm10
000074c379ddc509  addpd xmm11, xmm6
000074c379ddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000074c379ddc514  ptest xmm8, xmm8
000074c379ddc51a  jnz 0x000074C379DDFD5B
000074c379ddc520  movaps xmm10, xmm14
000074c379ddc524  addpd xmm10, xmm4
000074c379ddc529  vcmppd xmm8, xmm10, xmm10, 0x03
000074c379ddc52f  ptest xmm8, xmm8
000074c379ddc535  jnz 0x000074C379DDFE9E
000074c379ddc53b  vmovaps xmm14, [rsp+0x40]
000074c379ddc541  vpermilpd xmm14, xmm14, 0x00
000074c379ddc547  movaps xmm8, xmm1
000074c379ddc54b  mulpd xmm8, xmm14
000074c379ddc550  vcmppd xmm6, xmm8, xmm8, 0x03
000074c379ddc556  ptest xmm6, xmm6
000074c379ddc55b  jnz 0x000074C379DDFFE1
000074c379ddc561  movaps xmm1, [r15+0x2B0]
000074c379ddc569  vmovaps xmm14, [rsp+0x40]
000074c379ddc56f  vpermilpd xmm14, xmm14, 0x00
000074c379ddc575  movaps xmm6, xmm1
000074c379ddc578  mulpd xmm6, xmm14
000074c379ddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000074c379ddc582  ptest xmm5, xmm5
000074c379ddc587  jnz 0x000074C379DE0124
000074c379ddc58d  vmovaps xmm1, [rsp+0x10]
000074c379ddc593  vpermilpd xmm1, xmm1, 0x00
000074c379ddc599  movaps xmm14, xmm12
000074c379ddc59d  mulpd xmm14, xmm1
000074c379ddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000074c379ddc5a8  ptest xmm5, xmm5
000074c379ddc5ad  jnz 0x000074C379DE0265
000074c379ddc5b3  movaps xmm1, xmm13
000074c379ddc5b7  addpd xmm1, xmm9
000074c379ddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000074c379ddc5c1  ptest xmm12, xmm12
000074c379ddc5c7  jnz 0x000074C379DE03A8
000074c379ddc5cd  vmovaps xmm13, [rsp+0x10]
000074c379ddc5d3  vpermilpd xmm13, xmm13, 0x00
000074c379ddc5d9  movaps xmm12, xmm7
000074c379ddc5dd  mulpd xmm12, xmm13
000074c379ddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000074c379ddc5e8  ptest xmm9, xmm9
000074c379ddc5ee  jnz 0x000074C379DE04EA
000074c379ddc5f4  movaps xmm13, xmm15
000074c379ddc5f8  addpd xmm13, xmm8
000074c379ddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000074c379ddc603  ptest xmm9, xmm9
000074c379ddc609  jnz 0x000074C379DE062D
000074c379ddc60f  movaps xmm15, [r15+0x290]
000074c379ddc617  vmovaps xmm9, [rsp+0x10]
000074c379ddc61d  vpermilpd xmm9, xmm9, 0x00
000074c379ddc623  movaps xmm8, xmm15
000074c379ddc627  mulpd xmm8, xmm9
000074c379ddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000074c379ddc632  ptest xmm7, xmm7
000074c379ddc637  jnz 0x000074C379DE0771
000074c379ddc63d  movaps xmm15, xmm11
000074c379ddc641  addpd xmm15, xmm6
000074c379ddc646  vcmppd xmm9, xmm15, xmm15, 0x03
000074c379ddc64c  ptest xmm9, xmm9
000074c379ddc652  jnz 0x000074C379DE08B5
000074c379ddc658  movaps xmm11, [r15+0x1E0]
000074c379ddc660  vmovaps xmm9, [rsp+0x10]
000074c379ddc666  vpermilpd xmm9, xmm9, 0x00
000074c379ddc66c  movaps xmm7, xmm11
000074c379ddc670  mulpd xmm7, xmm9
000074c379ddc675  vcmppd xmm6, xmm7, xmm7, 0x03
000074c379ddc67a  ptest xmm6, xmm6
000074c379ddc67f  jnz 0x000074C379DE09F8
000074c379ddc685  movaps xmm11, xmm10
000074c379ddc689  addpd xmm11, xmm14
000074c379ddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000074c379ddc694  ptest xmm9, xmm9
000074c379ddc69a  jnz 0x000074C379DE0B3A
000074c379ddc6a0  lea r12, [rax+0x70]
000074c379ddc6a4  movups xmm14, [r13+r12*1]
000074c379ddc6aa  movaps [r15+0x240], xmm14
000074c379ddc6b2  movaps xmm10, xmm1
000074c379ddc6b6  addpd xmm10, xmm12
000074c379ddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000074c379ddc6c1  ptest xmm9, xmm9
000074c379ddc6c7  jnz 0x000074C379DE0C88
000074c379ddc6cd  movaps [r15+0x170], xmm10
000074c379ddc6d5  vmovaps xmm1, [rsp+0x20]
000074c379ddc6db  vpermilpd xmm1, xmm1, 0x00
000074c379ddc6e1  movaps xmm12, xmm14
000074c379ddc6e5  mulpd xmm12, xmm1
000074c379ddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000074c379ddc6f0  ptest xmm9, xmm9
000074c379ddc6f6  jnz 0x000074C379DE0DCB
000074c379ddc6fc  vmovaps xmm1, [rsp+0x20]
000074c379ddc702  vpermilpd xmm1, xmm1, 0x00
000074c379ddc708  vmovaps xmm9, [rsp+0xB0]
000074c379ddc711  movaps xmm14, xmm9
000074c379ddc715  mulpd xmm14, xmm1
000074c379ddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000074c379ddc720  ptest xmm6, xmm6
000074c379ddc725  jnz 0x000074C379DE0F0E
000074c379ddc72b  movaps [r15+0x180], xmm14
000074c379ddc733  movaps xmm1, xmm13
000074c379ddc737  addpd xmm1, xmm8
000074c379ddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000074c379ddc741  ptest xmm9, xmm9
000074c379ddc747  jnz 0x000074C379DE1051
000074c379ddc74d  movaps [r15+0x210], xmm1
000074c379ddc755  movups xmm13, [r13+rax*1]
000074c379ddc75b  lea r12, [rax+0x10]
000074c379ddc75f  movups xmm9, [r13+r12*1]
000074c379ddc765  movaps [r15+0x230], xmm9
000074c379ddc76d  movaps xmm8, xmm15
000074c379ddc771  addpd xmm8, xmm7
000074c379ddc776  vcmppd xmm6, xmm8, xmm8, 0x03
000074c379ddc77c  ptest xmm6, xmm6
000074c379ddc781  jnz 0x000074C379DE11A7
000074c379ddc787  movaps [r15+0x130], xmm8
000074c379ddc78f  vmovaps xmm15, [rsp+0x20]
000074c379ddc795  vpermilpd xmm15, xmm15, 0x00
000074c379ddc79b  movaps xmm7, xmm9
000074c379ddc79f  mulpd xmm7, xmm15
000074c379ddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000074c379ddc7a9  ptest xmm6, xmm6
000074c379ddc7ae  jnz 0x000074C379DE12EA
000074c379ddc7b4  movaps [r15+0x220], xmm7
000074c379ddc7bc  vmovaps xmm15, [rsp+0x20]
000074c379ddc7c2  vpermilpd xmm15, xmm15, 0x00
000074c379ddc7c8  movaps xmm9, xmm13
000074c379ddc7cc  mulpd xmm9, xmm15
000074c379ddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000074c379ddc7d7  ptest xmm6, xmm6
000074c379ddc7dc  jnz 0x000074C379DE142C
000074c379ddc7e2  movaps xmm15, xmm11
000074c379ddc7e6  addpd xmm15, xmm12
000074c379ddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000074c379ddc7f1  ptest xmm13, xmm13
000074c379ddc7f7  jnz 0x000074C379DE1570
000074c379ddc7fd  movaps [r15+0x140], xmm15
000074c379ddc805  movaps xmm13, xmm10
000074c379ddc809  addpd xmm13, xmm14
000074c379ddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000074c379ddc814  ptest xmm12, xmm12
000074c379ddc81a  jnz 0x000074C379DE16B4
000074c379ddc820  movaps [r15+0x150], xmm13
000074c379ddc828  movaps xmm14, xmm1
000074c379ddc82c  addpd xmm14, xmm7
000074c379ddc831  vcmppd xmm12, xmm14, xmm14, 0x03
000074c379ddc837  ptest xmm12, xmm12
000074c379ddc83d  jnz 0x000074C379DE17F8
000074c379ddc843  movaps [r15+0x160], xmm14
000074c379ddc84b  movaps xmm1, xmm8
000074c379ddc84f  addpd xmm1, xmm9
000074c379ddc854  vcmppd xmm12, xmm1, xmm1, 0x03
000074c379ddc859  ptest xmm12, xmm12
000074c379ddc85f  jnz 0x000074C379DE193A
000074c379ddc865  movaps [r15+0x120], xmm1
000074c379ddc86d  movups [r13+r14*1], xmm15
000074c379ddc873  lea rax, [r14+0x10]
000074c379ddc877  movups [r13+rax*1], xmm13
000074c379ddc87d  lea rax, [r14+0x20]
000074c379ddc881  movups [r13+rax*1], xmm14
000074c379ddc887  lea rax, [r14+0x30]
000074c379ddc88b  movups [r13+rax*1], xmm1
000074c379ddc891  mov eax, [r15+0x108]
000074c379ddc898  sahf
000074c379ddc899  jnz 0x000074C379DDC8CB
000074c379ddc89b  cmp dword ptr [r15+0x318], 0x00
000074c379ddc8a3  jz 0x000074C379DDB900
000074c379ddc8a9  nop [rax+rax*1], ax
000074c379ddc8b2  nop [rax+rax*1], eax
000074c379ddc8ba  mov eax, 0x410444
000074c379ddc8bf  mov [r15+0x100], rax
000074c379ddc8c6  jmp 0x000074C379BFE110
000074c379ddc8cb  cmp dword ptr [r15+0x318], 0x00
000074c379ddc8d3  jz 0x000074C379DD57E0
000074c379ddc8d9  nop [rax+rax*1], ax
000074c379ddc8e2  nop [rax+rax*1], eax
000074c379ddc8ea  mov eax, 0x410278
000074c379ddc8ef  mov [r15+0x100], rax
000074c379ddc8f6  jmp 0x000074C379BFE110
000074c379ddc8fb  int3
000074c379ddc8fc  call 0x000074C379CE27E0
000074c379ddc901  jmp 0x000074C379DDB9DF
000074c379ddc906  call 0x000074C379CE1570
000074c379ddc90b  jmp 0x000074C379DDB9E8
000074c379ddc910  call 0x000074C379CE27E0
000074c379ddc915  jmp 0x000074C379DDBA44
000074c379ddc91a  call 0x000074C379CE1570
000074c379ddc91f  jmp 0x000074C379DDBA4D
000074c379ddc924  call 0x000074C379CE27E0
000074c379ddc929  jmp 0x000074C379DDBA90
000074c379ddc92e  call 0x000074C379CE1570
000074c379ddc933  jmp 0x000074C379DDBA99
000074c379ddc938  call 0x000074C379C0DC20
000074c379ddc93d  jmp 0x000074C379DDBAD8
000074c379ddc942  call 0x000074C379CD59C0
000074c379ddc947  jmp 0x000074C379DDBAEB
000074c379ddc94c  call 0x000074C379CE0E30
000074c379ddc951  jmp 0x000074C379DDBB09
000074c379ddc956  call 0x000074C379CDFBC0
000074c379ddc95b  jmp 0x000074C379DDBB13
000074c379ddc960  call 0x000074C379CDE950
000074c379ddc965  jmp 0x000074C379DDBB1D
000074c379ddc96a  sub rsp, 0x08
000074c379ddc96e  push rax
000074c379ddc96f  push rcx
000074c379ddc970  push rdx
000074c379ddc971  push rdi
000074c379ddc972  push rsi
000074c379ddc973  push r8
000074c379ddc975  push r9
000074c379ddc977  push r10
000074c379ddc979  push r11
000074c379ddc97b  sub rsp, 0xF0
000074c379ddc982  vmovaps [rsp], xmm0
000074c379ddc987  vmovaps [rsp+0x10], xmm1
000074c379ddc98d  vmovaps [rsp+0x20], xmm2
000074c379ddc993  vmovaps [rsp+0x30], xmm3
000074c379ddc999  vmovaps [rsp+0x40], xmm4
000074c379ddc99f  vmovaps [rsp+0x50], xmm5
000074c379ddc9a5  vmovaps [rsp+0x60], xmm6
000074c379ddc9ab  vmovaps [rsp+0x70], xmm7
000074c379ddc9b1  vmovaps [rsp+0x80], xmm9
000074c379ddc9ba  vmovaps [rsp+0x90], xmm10
000074c379ddc9c3  vmovaps [rsp+0xA0], xmm11
000074c379ddc9cc  vmovaps [rsp+0xB0], xmm12
000074c379ddc9d5  vmovaps [rsp+0xC0], xmm13
000074c379ddc9de  vmovaps [rsp+0xD0], xmm14
000074c379ddc9e7  vmovaps [rsp+0xE0], xmm15
000074c379ddc9f0  sub rsp, 0x30
000074c379ddc9f4  movaps [rsp], xmm8
000074c379ddc9f9  movaps [rsp+0x10], xmm12
000074c379ddc9ff  movaps [rsp+0x20], xmm15
000074c379ddca05  lea rdi, [rsp]
000074c379ddca09  mov esi, 0x00
000074c379ddca0e  mov rax, 0x56321ABA4530
000074c379ddca18  call rax
000074c379ddca1a  movaps xmm8, [rsp]
000074c379ddca1f  add rsp, 0x30
000074c379ddca23  vmovaps xmm0, [rsp]
000074c379ddca28  vmovaps xmm1, [rsp+0x10]
000074c379ddca2e  vmovaps xmm2, [rsp+0x20]
000074c379ddca34  vmovaps xmm3, [rsp+0x30]
000074c379ddca3a  vmovaps xmm4, [rsp+0x40]
000074c379ddca40  vmovaps xmm5, [rsp+0x50]
000074c379ddca46  vmovaps xmm6, [rsp+0x60]
000074c379ddca4c  vmovaps xmm7, [rsp+0x70]
000074c379ddca52  vmovaps xmm9, [rsp+0x80]
000074c379ddca5b  vmovaps xmm10, [rsp+0x90]
000074c379ddca64  vmovaps xmm11, [rsp+0xA0]
000074c379ddca6d  vmovaps xmm12, [rsp+0xB0]
000074c379ddca76  vmovaps xmm13, [rsp+0xC0]
000074c379ddca7f  vmovaps xmm14, [rsp+0xD0]
000074c379ddca88  vmovaps xmm15, [rsp+0xE0]
000074c379ddca91  add rsp, 0xF0
000074c379ddca98  pop r11
000074c379ddca9a  pop r10
000074c379ddca9c  pop r9
000074c379ddca9e  pop r8
000074c379ddcaa0  pop rsi
000074c379ddcaa1  pop rdi
000074c379ddcaa2  pop rdx
000074c379ddcaa3  pop rcx
000074c379ddcaa4  pop rax
000074c379ddcaa5  add rsp, 0x08
000074c379ddcaa9  jmp 0x000074C379DDBB47
000074c379ddcaae  sub rsp, 0x08
000074c379ddcab2  push rax
000074c379ddcab3  push rcx
000074c379ddcab4  push rdx
000074c379ddcab5  push rdi
000074c379ddcab6  push rsi
000074c379ddcab7  push r8
000074c379ddcab9  push r9
000074c379ddcabb  push r10
000074c379ddcabd  push r11
000074c379ddcabf  sub rsp, 0xF0
000074c379ddcac6  vmovaps [rsp], xmm0
000074c379ddcacb  vmovaps [rsp+0x10], xmm1
000074c379ddcad1  vmovaps [rsp+0x20], xmm2
000074c379ddcad7  vmovaps [rsp+0x30], xmm3
000074c379ddcadd  vmovaps [rsp+0x40], xmm4
000074c379ddcae3  vmovaps [rsp+0x50], xmm5
000074c379ddcae9  vmovaps [rsp+0x60], xmm6
000074c379ddcaef  vmovaps [rsp+0x70], xmm8
000074c379ddcaf5  vmovaps [rsp+0x80], xmm9
000074c379ddcafe  vmovaps [rsp+0x90], xmm10
000074c379ddcb07  vmovaps [rsp+0xA0], xmm11
000074c379ddcb10  vmovaps [rsp+0xB0], xmm12
000074c379ddcb19  vmovaps [rsp+0xC0], xmm13
000074c379ddcb22  vmovaps [rsp+0xD0], xmm14
000074c379ddcb2b  vmovaps [rsp+0xE0], xmm15
000074c379ddcb34  sub rsp, 0x30
000074c379ddcb38  movaps [rsp], xmm7
000074c379ddcb3c  movaps [rsp+0x10], xmm9
000074c379ddcb42  movaps [rsp+0x20], xmm15
000074c379ddcb48  lea rdi, [rsp]
000074c379ddcb4c  mov esi, 0x00
000074c379ddcb51  mov rax, 0x56321ABA4530
000074c379ddcb5b  call rax
000074c379ddcb5d  movaps xmm7, [rsp]
000074c379ddcb61  add rsp, 0x30
000074c379ddcb65  vmovaps xmm0, [rsp]
000074c379ddcb6a  vmovaps xmm1, [rsp+0x10]
000074c379ddcb70  vmovaps xmm2, [rsp+0x20]
000074c379ddcb76  vmovaps xmm3, [rsp+0x30]
000074c379ddcb7c  vmovaps xmm4, [rsp+0x40]
000074c379ddcb82  vmovaps xmm5, [rsp+0x50]
000074c379ddcb88  vmovaps xmm6, [rsp+0x60]
000074c379ddcb8e  vmovaps xmm8, [rsp+0x70]
000074c379ddcb94  vmovaps xmm9, [rsp+0x80]
000074c379ddcb9d  vmovaps xmm10, [rsp+0x90]
000074c379ddcba6  vmovaps xmm11, [rsp+0xA0]
000074c379ddcbaf  vmovaps xmm12, [rsp+0xB0]
000074c379ddcbb8  vmovaps xmm13, [rsp+0xC0]
000074c379ddcbc1  vmovaps xmm14, [rsp+0xD0]
000074c379ddcbca  vmovaps xmm15, [rsp+0xE0]
000074c379ddcbd3  add rsp, 0xF0
000074c379ddcbda  pop r11
000074c379ddcbdc  pop r10
000074c379ddcbde  pop r9
000074c379ddcbe0  pop r8
000074c379ddcbe2  pop rsi
000074c379ddcbe3  pop rdi
000074c379ddcbe4  pop rdx
000074c379ddcbe5  pop rcx
000074c379ddcbe6  pop rax
000074c379ddcbe7  add rsp, 0x08
000074c379ddcbeb  jmp 0x000074C379DDBB75
000074c379ddcbf0  sub rsp, 0x08
000074c379ddcbf4  push rax
000074c379ddcbf5  push rcx
000074c379ddcbf6  push rdx
000074c379ddcbf7  push rdi
000074c379ddcbf8  push rsi
000074c379ddcbf9  push r8
000074c379ddcbfb  push r9
000074c379ddcbfd  push r10
000074c379ddcbff  push r11
000074c379ddcc01  sub rsp, 0xF0
000074c379ddcc08  vmovaps [rsp], xmm0
000074c379ddcc0d  vmovaps [rsp+0x10], xmm1
000074c379ddcc13  vmovaps [rsp+0x20], xmm2
000074c379ddcc19  vmovaps [rsp+0x30], xmm3
000074c379ddcc1f  vmovaps [rsp+0x40], xmm4
000074c379ddcc25  vmovaps [rsp+0x50], xmm5
000074c379ddcc2b  vmovaps [rsp+0x60], xmm6
000074c379ddcc31  vmovaps [rsp+0x70], xmm7
000074c379ddcc37  vmovaps [rsp+0x80], xmm8
000074c379ddcc40  vmovaps [rsp+0x90], xmm10
000074c379ddcc49  vmovaps [rsp+0xA0], xmm11
000074c379ddcc52  vmovaps [rsp+0xB0], xmm12
000074c379ddcc5b  vmovaps [rsp+0xC0], xmm13
000074c379ddcc64  vmovaps [rsp+0xD0], xmm14
000074c379ddcc6d  vmovaps [rsp+0xE0], xmm15
000074c379ddcc76  sub rsp, 0x30
000074c379ddcc7a  movaps [rsp], xmm9
000074c379ddcc7f  movaps [rsp+0x10], xmm12
000074c379ddcc85  movaps [rsp+0x20], xmm10
000074c379ddcc8b  lea rdi, [rsp]
000074c379ddcc8f  mov esi, 0x00
000074c379ddcc94  mov rax, 0x56321ABA4530
000074c379ddcc9e  call rax
000074c379ddcca0  movaps xmm9, [rsp]
000074c379ddcca5  add rsp, 0x30
000074c379ddcca9  vmovaps xmm0, [rsp]
000074c379ddccae  vmovaps xmm1, [rsp+0x10]
000074c379ddccb4  vmovaps xmm2, [rsp+0x20]
000074c379ddccba  vmovaps xmm3, [rsp+0x30]
000074c379ddccc0  vmovaps xmm4, [rsp+0x40]
000074c379ddccc6  vmovaps xmm5, [rsp+0x50]
000074c379ddcccc  vmovaps xmm6, [rsp+0x60]
000074c379ddccd2  vmovaps xmm7, [rsp+0x70]
000074c379ddccd8  vmovaps xmm8, [rsp+0x80]
000074c379ddcce1  vmovaps xmm10, [rsp+0x90]
000074c379ddccea  vmovaps xmm11, [rsp+0xA0]
000074c379ddccf3  vmovaps xmm12, [rsp+0xB0]
000074c379ddccfc  vmovaps xmm13, [rsp+0xC0]
000074c379ddcd05  vmovaps xmm14, [rsp+0xD0]
000074c379ddcd0e  vmovaps xmm15, [rsp+0xE0]
000074c379ddcd17  add rsp, 0xF0
000074c379ddcd1e  pop r11
000074c379ddcd20  pop r10
000074c379ddcd22  pop r9
000074c379ddcd24  pop r8
000074c379ddcd26  pop rsi
000074c379ddcd27  pop rdi
000074c379ddcd28  pop rdx
000074c379ddcd29  pop rcx
000074c379ddcd2a  pop rax
000074c379ddcd2b  add rsp, 0x08
000074c379ddcd2f  jmp 0x000074C379DDBB99
000074c379ddcd34  sub rsp, 0x08
000074c379ddcd38  push rax
000074c379ddcd39  push rcx
000074c379ddcd3a  push rdx
000074c379ddcd3b  push rdi
000074c379ddcd3c  push rsi
000074c379ddcd3d  push r8
000074c379ddcd3f  push r9
000074c379ddcd41  push r10
000074c379ddcd43  push r11
000074c379ddcd45  sub rsp, 0xF0
000074c379ddcd4c  vmovaps [rsp], xmm0
000074c379ddcd51  vmovaps [rsp+0x10], xmm1
000074c379ddcd57  vmovaps [rsp+0x20], xmm2
000074c379ddcd5d  vmovaps [rsp+0x30], xmm3
000074c379ddcd63  vmovaps [rsp+0x40], xmm4
000074c379ddcd69  vmovaps [rsp+0x50], xmm5
000074c379ddcd6f  vmovaps [rsp+0x60], xmm6
000074c379ddcd75  vmovaps [rsp+0x70], xmm7
000074c379ddcd7b  vmovaps [rsp+0x80], xmm8
000074c379ddcd84  vmovaps [rsp+0x90], xmm9
000074c379ddcd8d  vmovaps [rsp+0xA0], xmm11
000074c379ddcd96  vmovaps [rsp+0xB0], xmm12
000074c379ddcd9f  vmovaps [rsp+0xC0], xmm13
000074c379ddcda8  vmovaps [rsp+0xD0], xmm14
000074c379ddcdb1  vmovaps [rsp+0xE0], xmm15
000074c379ddcdba  sub rsp, 0x30
000074c379ddcdbe  movaps [rsp], xmm10
000074c379ddcdc3  movaps [rsp+0x10], xmm12
000074c379ddcdc9  movaps [rsp+0x20], xmm11
000074c379ddcdcf  lea rdi, [rsp]
000074c379ddcdd3  mov esi, 0x00
000074c379ddcdd8  mov rax, 0x56321ABA4530
000074c379ddcde2  call rax
000074c379ddcde4  movaps xmm10, [rsp]
000074c379ddcde9  add rsp, 0x30
000074c379ddcded  vmovaps xmm0, [rsp]
000074c379ddcdf2  vmovaps xmm1, [rsp+0x10]
000074c379ddcdf8  vmovaps xmm2, [rsp+0x20]
000074c379ddcdfe  vmovaps xmm3, [rsp+0x30]
000074c379ddce04  vmovaps xmm4, [rsp+0x40]
000074c379ddce0a  vmovaps xmm5, [rsp+0x50]
000074c379ddce10  vmovaps xmm6, [rsp+0x60]
000074c379ddce16  vmovaps xmm7, [rsp+0x70]
000074c379ddce1c  vmovaps xmm8, [rsp+0x80]
000074c379ddce25  vmovaps xmm9, [rsp+0x90]
000074c379ddce2e  vmovaps xmm11, [rsp+0xA0]
000074c379ddce37  vmovaps xmm12, [rsp+0xB0]
000074c379ddce40  vmovaps xmm13, [rsp+0xC0]
000074c379ddce49  vmovaps xmm14, [rsp+0xD0]
000074c379ddce52  vmovaps xmm15, [rsp+0xE0]
000074c379ddce5b  add rsp, 0xF0
000074c379ddce62  pop r11
000074c379ddce64  pop r10
000074c379ddce66  pop r9
000074c379ddce68  pop r8
000074c379ddce6a  pop rsi
000074c379ddce6b  pop rdi
000074c379ddce6c  pop rdx
000074c379ddce6d  pop rcx
000074c379ddce6e  pop rax
000074c379ddce6f  add rsp, 0x08
000074c379ddce73  jmp 0x000074C379DDBBB3
000074c379ddce78  sub rsp, 0x08
000074c379ddce7c  push rax
000074c379ddce7d  push rcx
000074c379ddce7e  push rdx
000074c379ddce7f  push rdi
000074c379ddce80  push rsi
000074c379ddce81  push r8
000074c379ddce83  push r9
000074c379ddce85  push r10
000074c379ddce87  push r11
000074c379ddce89  sub rsp, 0xF0
000074c379ddce90  vmovaps [rsp], xmm0
000074c379ddce95  vmovaps [rsp+0x10], xmm1
000074c379ddce9b  vmovaps [rsp+0x20], xmm2
000074c379ddcea1  vmovaps [rsp+0x30], xmm3
000074c379ddcea7  vmovaps [rsp+0x40], xmm4
000074c379ddcead  vmovaps [rsp+0x50], xmm5
000074c379ddceb3  vmovaps [rsp+0x60], xmm7
000074c379ddceb9  vmovaps [rsp+0x70], xmm8
000074c379ddcebf  vmovaps [rsp+0x80], xmm9
000074c379ddcec8  vmovaps [rsp+0x90], xmm10
000074c379ddced1  vmovaps [rsp+0xA0], xmm11
000074c379ddceda  vmovaps [rsp+0xB0], xmm12
000074c379ddcee3  vmovaps [rsp+0xC0], xmm13
000074c379ddceec  vmovaps [rsp+0xD0], xmm14
000074c379ddcef5  vmovaps [rsp+0xE0], xmm15
000074c379ddcefe  sub rsp, 0x30
000074c379ddcf02  movaps [rsp], xmm6
000074c379ddcf06  movaps [rsp+0x10], xmm12
000074c379ddcf0c  movaps [rsp+0x20], xmm11
000074c379ddcf12  lea rdi, [rsp]
000074c379ddcf16  mov esi, 0x00
000074c379ddcf1b  mov rax, 0x56321ABA4530
000074c379ddcf25  call rax
000074c379ddcf27  movaps xmm6, [rsp]
000074c379ddcf2b  add rsp, 0x30
000074c379ddcf2f  vmovaps xmm0, [rsp]
000074c379ddcf34  vmovaps xmm1, [rsp+0x10]
000074c379ddcf3a  vmovaps xmm2, [rsp+0x20]
000074c379ddcf40  vmovaps xmm3, [rsp+0x30]
000074c379ddcf46  vmovaps xmm4, [rsp+0x40]
000074c379ddcf4c  vmovaps xmm5, [rsp+0x50]
000074c379ddcf52  vmovaps xmm7, [rsp+0x60]
000074c379ddcf58  vmovaps xmm8, [rsp+0x70]
000074c379ddcf5e  vmovaps xmm9, [rsp+0x80]
000074c379ddcf67  vmovaps xmm10, [rsp+0x90]
000074c379ddcf70  vmovaps xmm11, [rsp+0xA0]
000074c379ddcf79  vmovaps xmm12, [rsp+0xB0]
000074c379ddcf82  vmovaps xmm13, [rsp+0xC0]
000074c379ddcf8b  vmovaps xmm14, [rsp+0xD0]
000074c379ddcf94  vmovaps xmm15, [rsp+0xE0]
000074c379ddcf9d  add rsp, 0xF0
000074c379ddcfa4  pop r11
000074c379ddcfa6  pop r10
000074c379ddcfa8  pop r9
000074c379ddcfaa  pop r8
000074c379ddcfac  pop rsi
000074c379ddcfad  pop rdi
000074c379ddcfae  pop rdx
000074c379ddcfaf  pop rcx
000074c379ddcfb0  pop rax
000074c379ddcfb1  add rsp, 0x08
000074c379ddcfb5  jmp 0x000074C379DDBBD4
000074c379ddcfba  sub rsp, 0x08
000074c379ddcfbe  push rax
000074c379ddcfbf  push rcx
000074c379ddcfc0  push rdx
000074c379ddcfc1  push rdi
000074c379ddcfc2  push rsi
000074c379ddcfc3  push r8
000074c379ddcfc5  push r9
000074c379ddcfc7  push r10
000074c379ddcfc9  push r11
000074c379ddcfcb  sub rsp, 0xF0
000074c379ddcfd2  vmovaps [rsp], xmm0
000074c379ddcfd7  vmovaps [rsp+0x10], xmm1
000074c379ddcfdd  vmovaps [rsp+0x20], xmm2
000074c379ddcfe3  vmovaps [rsp+0x30], xmm4
000074c379ddcfe9  vmovaps [rsp+0x40], xmm5
000074c379ddcfef  vmovaps [rsp+0x50], xmm6
000074c379ddcff5  vmovaps [rsp+0x60], xmm7
000074c379ddcffb  vmovaps [rsp+0x70], xmm8
000074c379ddd001  vmovaps [rsp+0x80], xmm9
000074c379ddd00a  vmovaps [rsp+0x90], xmm10
000074c379ddd013  vmovaps [rsp+0xA0], xmm11
000074c379ddd01c  vmovaps [rsp+0xB0], xmm12
000074c379ddd025  vmovaps [rsp+0xC0], xmm13
000074c379ddd02e  vmovaps [rsp+0xD0], xmm14
000074c379ddd037  vmovaps [rsp+0xE0], xmm15
000074c379ddd040  sub rsp, 0x30
000074c379ddd044  movaps [rsp], xmm3
000074c379ddd048  movaps [rsp+0x10], xmm5
000074c379ddd04d  movaps [rsp+0x20], xmm4
000074c379ddd052  lea rdi, [rsp]
000074c379ddd056  mov esi, 0x00
000074c379ddd05b  mov rax, 0x56321ABA4530
000074c379ddd065  call rax
000074c379ddd067  movaps xmm3, [rsp]
000074c379ddd06b  add rsp, 0x30
000074c379ddd06f  vmovaps xmm0, [rsp]
000074c379ddd074  vmovaps xmm1, [rsp+0x10]
000074c379ddd07a  vmovaps xmm2, [rsp+0x20]
000074c379ddd080  vmovaps xmm4, [rsp+0x30]
000074c379ddd086  vmovaps xmm5, [rsp+0x40]
000074c379ddd08c  vmovaps xmm6, [rsp+0x50]
000074c379ddd092  vmovaps xmm7, [rsp+0x60]
000074c379ddd098  vmovaps xmm8, [rsp+0x70]
000074c379ddd09e  vmovaps xmm9, [rsp+0x80]
000074c379ddd0a7  vmovaps xmm10, [rsp+0x90]
000074c379ddd0b0  vmovaps xmm11, [rsp+0xA0]
000074c379ddd0b9  vmovaps xmm12, [rsp+0xB0]
000074c379ddd0c2  vmovaps xmm13, [rsp+0xC0]
000074c379ddd0cb  vmovaps xmm14, [rsp+0xD0]
000074c379ddd0d4  vmovaps xmm15, [rsp+0xE0]
000074c379ddd0dd  add rsp, 0xF0
000074c379ddd0e4  pop r11
000074c379ddd0e6  pop r10
000074c379ddd0e8  pop r9
000074c379ddd0ea  pop r8
000074c379ddd0ec  pop rsi
000074c379ddd0ed  pop rdi
000074c379ddd0ee  pop rdx
000074c379ddd0ef  pop rcx
000074c379ddd0f0  pop rax
000074c379ddd0f1  add rsp, 0x08
000074c379ddd0f5  jmp 0x000074C379DDBC35
000074c379ddd0fa  sub rsp, 0x08
000074c379ddd0fe  push rax
000074c379ddd0ff  push rcx
000074c379ddd100  push rdx
000074c379ddd101  push rdi
000074c379ddd102  push rsi
000074c379ddd103  push r8
000074c379ddd105  push r9
000074c379ddd107  push r10
000074c379ddd109  push r11
000074c379ddd10b  sub rsp, 0xF0
000074c379ddd112  vmovaps [rsp], xmm0
000074c379ddd117  vmovaps [rsp+0x10], xmm1
000074c379ddd11d  vmovaps [rsp+0x20], xmm2
000074c379ddd123  vmovaps [rsp+0x30], xmm3
000074c379ddd129  vmovaps [rsp+0x40], xmm4
000074c379ddd12f  vmovaps [rsp+0x50], xmm6
000074c379ddd135  vmovaps [rsp+0x60], xmm7
000074c379ddd13b  vmovaps [rsp+0x70], xmm8
000074c379ddd141  vmovaps [rsp+0x80], xmm9
000074c379ddd14a  vmovaps [rsp+0x90], xmm10
000074c379ddd153  vmovaps [rsp+0xA0], xmm11
000074c379ddd15c  vmovaps [rsp+0xB0], xmm12
000074c379ddd165  vmovaps [rsp+0xC0], xmm13
000074c379ddd16e  vmovaps [rsp+0xD0], xmm14
000074c379ddd177  vmovaps [rsp+0xE0], xmm15
000074c379ddd180  sub rsp, 0x30
000074c379ddd184  movaps [rsp], xmm5
000074c379ddd188  movaps [rsp+0x10], xmm8
000074c379ddd18e  movaps [rsp+0x20], xmm15
000074c379ddd194  lea rdi, [rsp]
000074c379ddd198  mov esi, 0x00
000074c379ddd19d  mov rax, 0x56321ABA4530
000074c379ddd1a7  call rax
000074c379ddd1a9  movaps xmm5, [rsp]
000074c379ddd1ad  add rsp, 0x30
000074c379ddd1b1  vmovaps xmm0, [rsp]
000074c379ddd1b6  vmovaps xmm1, [rsp+0x10]
000074c379ddd1bc  vmovaps xmm2, [rsp+0x20]
000074c379ddd1c2  vmovaps xmm3, [rsp+0x30]
000074c379ddd1c8  vmovaps xmm4, [rsp+0x40]
000074c379ddd1ce  vmovaps xmm6, [rsp+0x50]
000074c379ddd1d4  vmovaps xmm7, [rsp+0x60]
000074c379ddd1da  vmovaps xmm8, [rsp+0x70]
000074c379ddd1e0  vmovaps xmm9, [rsp+0x80]
000074c379ddd1e9  vmovaps xmm10, [rsp+0x90]
000074c379ddd1f2  vmovaps xmm11, [rsp+0xA0]
000074c379ddd1fb  vmovaps xmm12, [rsp+0xB0]
000074c379ddd204  vmovaps xmm13, [rsp+0xC0]
000074c379ddd20d  vmovaps xmm14, [rsp+0xD0]
000074c379ddd216  vmovaps xmm15, [rsp+0xE0]
000074c379ddd21f  add rsp, 0xF0
000074c379ddd226  pop r11
000074c379ddd228  pop r10
000074c379ddd22a  pop r9
000074c379ddd22c  pop r8
000074c379ddd22e  pop rsi
000074c379ddd22f  pop rdi
000074c379ddd230  pop rdx
000074c379ddd231  pop rcx
000074c379ddd232  pop rax
000074c379ddd233  add rsp, 0x08
000074c379ddd237  jmp 0x000074C379DDBC73
000074c379ddd23c  sub rsp, 0x08
000074c379ddd240  push rax
000074c379ddd241  push rcx
000074c379ddd242  push rdx
000074c379ddd243  push rdi
000074c379ddd244  push rsi
000074c379ddd245  push r8
000074c379ddd247  push r9
000074c379ddd249  push r10
000074c379ddd24b  push r11
000074c379ddd24d  sub rsp, 0xF0
000074c379ddd254  vmovaps [rsp], xmm0
000074c379ddd259  vmovaps [rsp+0x10], xmm1
000074c379ddd25f  vmovaps [rsp+0x20], xmm2
000074c379ddd265  vmovaps [rsp+0x30], xmm3
000074c379ddd26b  vmovaps [rsp+0x40], xmm5
000074c379ddd271  vmovaps [rsp+0x50], xmm6
000074c379ddd277  vmovaps [rsp+0x60], xmm7
000074c379ddd27d  vmovaps [rsp+0x70], xmm8
000074c379ddd283  vmovaps [rsp+0x80], xmm9
000074c379ddd28c  vmovaps [rsp+0x90], xmm10
000074c379ddd295  vmovaps [rsp+0xA0], xmm11
000074c379ddd29e  vmovaps [rsp+0xB0], xmm12
000074c379ddd2a7  vmovaps [rsp+0xC0], xmm13
000074c379ddd2b0  vmovaps [rsp+0xD0], xmm14
000074c379ddd2b9  vmovaps [rsp+0xE0], xmm15
000074c379ddd2c2  sub rsp, 0x30
000074c379ddd2c6  movaps [rsp], xmm4
000074c379ddd2ca  movaps [rsp+0x10], xmm9
000074c379ddd2d0  movaps [rsp+0x20], xmm8
000074c379ddd2d6  lea rdi, [rsp]
000074c379ddd2da  mov esi, 0x00
000074c379ddd2df  mov rax, 0x56321ABA4530
000074c379ddd2e9  call rax
000074c379ddd2eb  movaps xmm4, [rsp]
000074c379ddd2ef  add rsp, 0x30
000074c379ddd2f3  vmovaps xmm0, [rsp]
000074c379ddd2f8  vmovaps xmm1, [rsp+0x10]
000074c379ddd2fe  vmovaps xmm2, [rsp+0x20]
000074c379ddd304  vmovaps xmm3, [rsp+0x30]
000074c379ddd30a  vmovaps xmm5, [rsp+0x40]
000074c379ddd310  vmovaps xmm6, [rsp+0x50]
000074c379ddd316  vmovaps xmm7, [rsp+0x60]
000074c379ddd31c  vmovaps xmm8, [rsp+0x70]
000074c379ddd322  vmovaps xmm9, [rsp+0x80]
000074c379ddd32b  vmovaps xmm10, [rsp+0x90]
000074c379ddd334  vmovaps xmm11, [rsp+0xA0]
000074c379ddd33d  vmovaps xmm12, [rsp+0xB0]
000074c379ddd346  vmovaps xmm13, [rsp+0xC0]
000074c379ddd34f  vmovaps xmm14, [rsp+0xD0]
000074c379ddd358  vmovaps xmm15, [rsp+0xE0]
000074c379ddd361  add rsp, 0xF0
000074c379ddd368  pop r11
000074c379ddd36a  pop r10
000074c379ddd36c  pop r9
000074c379ddd36e  pop r8
000074c379ddd370  pop rsi
000074c379ddd371  pop rdi
000074c379ddd372  pop rdx
000074c379ddd373  pop rcx
000074c379ddd374  pop rax
000074c379ddd375  add rsp, 0x08
000074c379ddd379  jmp 0x000074C379DDBC94
000074c379ddd37e  sub rsp, 0x08
000074c379ddd382  push rax
000074c379ddd383  push rcx
000074c379ddd384  push rdx
000074c379ddd385  push rdi
000074c379ddd386  push rsi
000074c379ddd387  push r8
000074c379ddd389  push r9
000074c379ddd38b  push r10
000074c379ddd38d  push r11
000074c379ddd38f  sub rsp, 0xF0
000074c379ddd396  vmovaps [rsp], xmm0
000074c379ddd39b  vmovaps [rsp+0x10], xmm1
000074c379ddd3a1  vmovaps [rsp+0x20], xmm2
000074c379ddd3a7  vmovaps [rsp+0x30], xmm3
000074c379ddd3ad  vmovaps [rsp+0x40], xmm4
000074c379ddd3b3  vmovaps [rsp+0x50], xmm5
000074c379ddd3b9  vmovaps [rsp+0x60], xmm6
000074c379ddd3bf  vmovaps [rsp+0x70], xmm7
000074c379ddd3c5  vmovaps [rsp+0x80], xmm8
000074c379ddd3ce  vmovaps [rsp+0x90], xmm10
000074c379ddd3d7  vmovaps [rsp+0xA0], xmm11
000074c379ddd3e0  vmovaps [rsp+0xB0], xmm12
000074c379ddd3e9  vmovaps [rsp+0xC0], xmm13
000074c379ddd3f2  vmovaps [rsp+0xD0], xmm14
000074c379ddd3fb  vmovaps [rsp+0xE0], xmm15
000074c379ddd404  sub rsp, 0x30
000074c379ddd408  movaps [rsp], xmm9
000074c379ddd40d  movaps [rsp+0x10], xmm10
000074c379ddd413  movaps [rsp+0x20], xmm8
000074c379ddd419  lea rdi, [rsp]
000074c379ddd41d  mov esi, 0x00
000074c379ddd422  mov rax, 0x56321ABA4530
000074c379ddd42c  call rax
000074c379ddd42e  movaps xmm9, [rsp]
000074c379ddd433  add rsp, 0x30
000074c379ddd437  vmovaps xmm0, [rsp]
000074c379ddd43c  vmovaps xmm1, [rsp+0x10]
000074c379ddd442  vmovaps xmm2, [rsp+0x20]
000074c379ddd448  vmovaps xmm3, [rsp+0x30]
000074c379ddd44e  vmovaps xmm4, [rsp+0x40]
000074c379ddd454  vmovaps xmm5, [rsp+0x50]
000074c379ddd45a  vmovaps xmm6, [rsp+0x60]
000074c379ddd460  vmovaps xmm7, [rsp+0x70]
000074c379ddd466  vmovaps xmm8, [rsp+0x80]
000074c379ddd46f  vmovaps xmm10, [rsp+0x90]
000074c379ddd478  vmovaps xmm11, [rsp+0xA0]
000074c379ddd481  vmovaps xmm12, [rsp+0xB0]
000074c379ddd48a  vmovaps xmm13, [rsp+0xC0]
000074c379ddd493  vmovaps xmm14, [rsp+0xD0]
000074c379ddd49c  vmovaps xmm15, [rsp+0xE0]
000074c379ddd4a5  add rsp, 0xF0
000074c379ddd4ac  pop r11
000074c379ddd4ae  pop r10
000074c379ddd4b0  pop r9
000074c379ddd4b2  pop r8
000074c379ddd4b4  pop rsi
000074c379ddd4b5  pop rdi
000074c379ddd4b6  pop rdx
000074c379ddd4b7  pop rcx
000074c379ddd4b8  pop rax
000074c379ddd4b9  add rsp, 0x08
000074c379ddd4bd  jmp 0x000074C379DDBCAE
000074c379ddd4c2  call 0x000074C379CB52F0
000074c379ddd4c7  jmp 0x000074C379DDBDC8
000074c379ddd4cc  call 0x000074C379CB52F0
000074c379ddd4d1  jmp 0x000074C379DDBDDE
000074c379ddd4d6  sub rsp, 0x08
000074c379ddd4da  push rax
000074c379ddd4db  push rcx
000074c379ddd4dc  push rdx
000074c379ddd4dd  push rdi
000074c379ddd4de  push rsi
000074c379ddd4df  push r8
000074c379ddd4e1  push r9
000074c379ddd4e3  push r10
000074c379ddd4e5  push r11
000074c379ddd4e7  sub rsp, 0xF0
000074c379ddd4ee  vmovaps [rsp], xmm0
000074c379ddd4f3  vmovaps [rsp+0x10], xmm2
000074c379ddd4f9  vmovaps [rsp+0x20], xmm3
000074c379ddd4ff  vmovaps [rsp+0x30], xmm4
000074c379ddd505  vmovaps [rsp+0x40], xmm5
000074c379ddd50b  vmovaps [rsp+0x50], xmm6
000074c379ddd511  vmovaps [rsp+0x60], xmm7
000074c379ddd517  vmovaps [rsp+0x70], xmm8
000074c379ddd51d  vmovaps [rsp+0x80], xmm9
000074c379ddd526  vmovaps [rsp+0x90], xmm10
000074c379ddd52f  vmovaps [rsp+0xA0], xmm11
000074c379ddd538  vmovaps [rsp+0xB0], xmm12
000074c379ddd541  vmovaps [rsp+0xC0], xmm13
000074c379ddd54a  vmovaps [rsp+0xD0], xmm14
000074c379ddd553  vmovaps [rsp+0xE0], xmm15
000074c379ddd55c  sub rsp, 0x30
000074c379ddd560  movaps [rsp], xmm1
000074c379ddd564  movaps [rsp+0x10], xmm6
000074c379ddd569  movaps [rsp+0x20], xmm15
000074c379ddd56f  lea rdi, [rsp]
000074c379ddd573  mov esi, 0x00
000074c379ddd578  mov rax, 0x56321ABA4530
000074c379ddd582  call rax
000074c379ddd584  movaps xmm1, [rsp]
000074c379ddd588  add rsp, 0x30
000074c379ddd58c  vmovaps xmm0, [rsp]
000074c379ddd591  vmovaps xmm2, [rsp+0x10]
000074c379ddd597  vmovaps xmm3, [rsp+0x20]
000074c379ddd59d  vmovaps xmm4, [rsp+0x30]
000074c379ddd5a3  vmovaps xmm5, [rsp+0x40]
000074c379ddd5a9  vmovaps xmm6, [rsp+0x50]
000074c379ddd5af  vmovaps xmm7, [rsp+0x60]
000074c379ddd5b5  vmovaps xmm8, [rsp+0x70]
000074c379ddd5bb  vmovaps xmm9, [rsp+0x80]
000074c379ddd5c4  vmovaps xmm10, [rsp+0x90]
000074c379ddd5cd  vmovaps xmm11, [rsp+0xA0]
000074c379ddd5d6  vmovaps xmm12, [rsp+0xB0]
000074c379ddd5df  vmovaps xmm13, [rsp+0xC0]
000074c379ddd5e8  vmovaps xmm14, [rsp+0xD0]
000074c379ddd5f1  vmovaps xmm15, [rsp+0xE0]
000074c379ddd5fa  add rsp, 0xF0
000074c379ddd601  pop r11
000074c379ddd603  pop r10
000074c379ddd605  pop r9
000074c379ddd607  pop r8
000074c379ddd609  pop rsi
000074c379ddd60a  pop rdi
000074c379ddd60b  pop rdx
000074c379ddd60c  pop rcx
000074c379ddd60d  pop rax
000074c379ddd60e  add rsp, 0x08
000074c379ddd612  jmp 0x000074C379DDBE1B
000074c379ddd617  call 0x000074C379CC4620
000074c379ddd61c  jmp 0x000074C379DDBE28
000074c379ddd621  sub rsp, 0x08
000074c379ddd625  push rax
000074c379ddd626  push rcx
000074c379ddd627  push rdx
000074c379ddd628  push rdi
000074c379ddd629  push rsi
000074c379ddd62a  push r8
000074c379ddd62c  push r9
000074c379ddd62e  push r10
000074c379ddd630  push r11
000074c379ddd632  sub rsp, 0xF0
000074c379ddd639  vmovaps [rsp], xmm0
000074c379ddd63e  vmovaps [rsp+0x10], xmm1
000074c379ddd644  vmovaps [rsp+0x20], xmm2
000074c379ddd64a  vmovaps [rsp+0x30], xmm3
000074c379ddd650  vmovaps [rsp+0x40], xmm4
000074c379ddd656  vmovaps [rsp+0x50], xmm5
000074c379ddd65c  vmovaps [rsp+0x60], xmm6
000074c379ddd662  vmovaps [rsp+0x70], xmm7
000074c379ddd668  vmovaps [rsp+0x80], xmm8
000074c379ddd671  vmovaps [rsp+0x90], xmm9
000074c379ddd67a  vmovaps [rsp+0xA0], xmm10
000074c379ddd683  vmovaps [rsp+0xB0], xmm11
000074c379ddd68c  vmovaps [rsp+0xC0], xmm12
000074c379ddd695  vmovaps [rsp+0xD0], xmm13
000074c379ddd69e  vmovaps [rsp+0xE0], xmm15
000074c379ddd6a7  sub rsp, 0x30
000074c379ddd6ab  movaps [rsp], xmm14
000074c379ddd6b0  movaps [rsp+0x10], xmm4
000074c379ddd6b5  movaps [rsp+0x20], xmm3
000074c379ddd6ba  lea rdi, [rsp]
000074c379ddd6be  mov esi, 0x00
000074c379ddd6c3  mov rax, 0x56321ABA4530
000074c379ddd6cd  call rax
000074c379ddd6cf  movaps xmm14, [rsp]
000074c379ddd6d4  add rsp, 0x30
000074c379ddd6d8  vmovaps xmm0, [rsp]
000074c379ddd6dd  vmovaps xmm1, [rsp+0x10]
000074c379ddd6e3  vmovaps xmm2, [rsp+0x20]
000074c379ddd6e9  vmovaps xmm3, [rsp+0x30]
000074c379ddd6ef  vmovaps xmm4, [rsp+0x40]
000074c379ddd6f5  vmovaps xmm5, [rsp+0x50]
000074c379ddd6fb  vmovaps xmm6, [rsp+0x60]
000074c379ddd701  vmovaps xmm7, [rsp+0x70]
000074c379ddd707  vmovaps xmm8, [rsp+0x80]
000074c379ddd710  vmovaps xmm9, [rsp+0x90]
000074c379ddd719  vmovaps xmm10, [rsp+0xA0]
000074c379ddd722  vmovaps xmm11, [rsp+0xB0]
000074c379ddd72b  vmovaps xmm12, [rsp+0xC0]
000074c379ddd734  vmovaps xmm13, [rsp+0xD0]
000074c379ddd73d  vmovaps xmm15, [rsp+0xE0]
000074c379ddd746  add rsp, 0xF0
000074c379ddd74d  pop r11
000074c379ddd74f  pop r10
000074c379ddd751  pop r9
000074c379ddd753  pop r8
000074c379ddd755  pop rsi
000074c379ddd756  pop rdi
000074c379ddd757  pop rdx
000074c379ddd758  pop rcx
000074c379ddd759  pop rax
000074c379ddd75a  add rsp, 0x08
000074c379ddd75e  jmp 0x000074C379DDBE42
000074c379ddd763  sub rsp, 0x08
000074c379ddd767  push rax
000074c379ddd768  push rcx
000074c379ddd769  push rdx
000074c379ddd76a  push rdi
000074c379ddd76b  push rsi
000074c379ddd76c  push r8
000074c379ddd76e  push r9
000074c379ddd770  push r10
000074c379ddd772  push r11
000074c379ddd774  sub rsp, 0xF0
000074c379ddd77b  vmovaps [rsp], xmm0
000074c379ddd780  vmovaps [rsp+0x10], xmm1
000074c379ddd786  vmovaps [rsp+0x20], xmm2
000074c379ddd78c  vmovaps [rsp+0x30], xmm3
000074c379ddd792  vmovaps [rsp+0x40], xmm4
000074c379ddd798  vmovaps [rsp+0x50], xmm5
000074c379ddd79e  vmovaps [rsp+0x60], xmm7
000074c379ddd7a4  vmovaps [rsp+0x70], xmm8
000074c379ddd7aa  vmovaps [rsp+0x80], xmm9
000074c379ddd7b3  vmovaps [rsp+0x90], xmm10
000074c379ddd7bc  vmovaps [rsp+0xA0], xmm11
000074c379ddd7c5  vmovaps [rsp+0xB0], xmm12
000074c379ddd7ce  vmovaps [rsp+0xC0], xmm13
000074c379ddd7d7  vmovaps [rsp+0xD0], xmm14
000074c379ddd7e0  vmovaps [rsp+0xE0], xmm15
000074c379ddd7e9  sub rsp, 0x30
000074c379ddd7ed  movaps [rsp], xmm6
000074c379ddd7f1  movaps [rsp+0x10], xmm9
000074c379ddd7f7  movaps [rsp+0x20], xmm7
000074c379ddd7fc  lea rdi, [rsp]
000074c379ddd800  mov esi, 0x00
000074c379ddd805  mov rax, 0x56321ABA4530
000074c379ddd80f  call rax
000074c379ddd811  movaps xmm6, [rsp]
000074c379ddd815  add rsp, 0x30
000074c379ddd819  vmovaps xmm0, [rsp]
000074c379ddd81e  vmovaps xmm1, [rsp+0x10]
000074c379ddd824  vmovaps xmm2, [rsp+0x20]
000074c379ddd82a  vmovaps xmm3, [rsp+0x30]
000074c379ddd830  vmovaps xmm4, [rsp+0x40]
000074c379ddd836  vmovaps xmm5, [rsp+0x50]
000074c379ddd83c  vmovaps xmm7, [rsp+0x60]
000074c379ddd842  vmovaps xmm8, [rsp+0x70]
000074c379ddd848  vmovaps xmm9, [rsp+0x80]
000074c379ddd851  vmovaps xmm10, [rsp+0x90]
000074c379ddd85a  vmovaps xmm11, [rsp+0xA0]
000074c379ddd863  vmovaps xmm12, [rsp+0xB0]
000074c379ddd86c  vmovaps xmm13, [rsp+0xC0]
000074c379ddd875  vmovaps xmm14, [rsp+0xD0]
000074c379ddd87e  vmovaps xmm15, [rsp+0xE0]
000074c379ddd887  add rsp, 0xF0
000074c379ddd88e  pop r11
000074c379ddd890  pop r10
000074c379ddd892  pop r9
000074c379ddd894  pop r8
000074c379ddd896  pop rsi
000074c379ddd897  pop rdi
000074c379ddd898  pop rdx
000074c379ddd899  pop rcx
000074c379ddd89a  pop rax
000074c379ddd89b  add rsp, 0x08
000074c379ddd89f  jmp 0x000074C379DDBE5A
000074c379ddd8a4  sub rsp, 0x08
000074c379ddd8a8  push rax
000074c379ddd8a9  push rcx
000074c379ddd8aa  push rdx
000074c379ddd8ab  push rdi
000074c379ddd8ac  push rsi
000074c379ddd8ad  push r8
000074c379ddd8af  push r9
000074c379ddd8b1  push r10
000074c379ddd8b3  push r11
000074c379ddd8b5  sub rsp, 0xF0
000074c379ddd8bc  vmovaps [rsp], xmm0
000074c379ddd8c1  vmovaps [rsp+0x10], xmm1
000074c379ddd8c7  vmovaps [rsp+0x20], xmm2
000074c379ddd8cd  vmovaps [rsp+0x30], xmm3
000074c379ddd8d3  vmovaps [rsp+0x40], xmm4
000074c379ddd8d9  vmovaps [rsp+0x50], xmm5
000074c379ddd8df  vmovaps [rsp+0x60], xmm6
000074c379ddd8e5  vmovaps [rsp+0x70], xmm8
000074c379ddd8eb  vmovaps [rsp+0x80], xmm9
000074c379ddd8f4  vmovaps [rsp+0x90], xmm10
000074c379ddd8fd  vmovaps [rsp+0xA0], xmm11
000074c379ddd906  vmovaps [rsp+0xB0], xmm12
000074c379ddd90f  vmovaps [rsp+0xC0], xmm13
000074c379ddd918  vmovaps [rsp+0xD0], xmm14
000074c379ddd921  vmovaps [rsp+0xE0], xmm15
000074c379ddd92a  sub rsp, 0x30
000074c379ddd92e  movaps [rsp], xmm7
000074c379ddd932  movaps [rsp+0x10], xmm4
000074c379ddd937  movaps [rsp+0x20], xmm9
000074c379ddd93d  lea rdi, [rsp]
000074c379ddd941  mov esi, 0x00
000074c379ddd946  mov rax, 0x56321ABA4530
000074c379ddd950  call rax
000074c379ddd952  movaps xmm7, [rsp]
000074c379ddd956  add rsp, 0x30
000074c379ddd95a  vmovaps xmm0, [rsp]
000074c379ddd95f  vmovaps xmm1, [rsp+0x10]
000074c379ddd965  vmovaps xmm2, [rsp+0x20]
000074c379ddd96b  vmovaps xmm3, [rsp+0x30]
000074c379ddd971  vmovaps xmm4, [rsp+0x40]
000074c379ddd977  vmovaps xmm5, [rsp+0x50]
000074c379ddd97d  vmovaps xmm6, [rsp+0x60]
000074c379ddd983  vmovaps xmm8, [rsp+0x70]
000074c379ddd989  vmovaps xmm9, [rsp+0x80]
000074c379ddd992  vmovaps xmm10, [rsp+0x90]
000074c379ddd99b  vmovaps xmm11, [rsp+0xA0]
000074c379ddd9a4  vmovaps xmm12, [rsp+0xB0]
000074c379ddd9ad  vmovaps xmm13, [rsp+0xC0]
000074c379ddd9b6  vmovaps xmm14, [rsp+0xD0]
000074c379ddd9bf  vmovaps xmm15, [rsp+0xE0]
000074c379ddd9c8  add rsp, 0xF0
000074c379ddd9cf  pop r11
000074c379ddd9d1  pop r10
000074c379ddd9d3  pop r9
000074c379ddd9d5  pop r8
000074c379ddd9d7  pop rsi
000074c379ddd9d8  pop rdi
000074c379ddd9d9  pop rdx
000074c379ddd9da  pop rcx
000074c379ddd9db  pop rax
000074c379ddd9dc  add rsp, 0x08
000074c379ddd9e0  jmp 0x000074C379DDBE87
000074c379ddd9e5  sub rsp, 0x08
000074c379ddd9e9  push rax
000074c379ddd9ea  push rcx
000074c379ddd9eb  push rdx
000074c379ddd9ec  push rdi
000074c379ddd9ed  push rsi
000074c379ddd9ee  push r8
000074c379ddd9f0  push r9
000074c379ddd9f2  push r10
000074c379ddd9f4  push r11
000074c379ddd9f6  sub rsp, 0xF0
000074c379ddd9fd  vmovaps [rsp], xmm0
000074c379ddda02  vmovaps [rsp+0x10], xmm1
000074c379ddda08  vmovaps [rsp+0x20], xmm2
000074c379ddda0e  vmovaps [rsp+0x30], xmm3
000074c379ddda14  vmovaps [rsp+0x40], xmm5
000074c379ddda1a  vmovaps [rsp+0x50], xmm6
000074c379ddda20  vmovaps [rsp+0x60], xmm7
000074c379ddda26  vmovaps [rsp+0x70], xmm8
000074c379ddda2c  vmovaps [rsp+0x80], xmm9
000074c379ddda35  vmovaps [rsp+0x90], xmm10
000074c379ddda3e  vmovaps [rsp+0xA0], xmm11
000074c379ddda47  vmovaps [rsp+0xB0], xmm12
000074c379ddda50  vmovaps [rsp+0xC0], xmm13
000074c379ddda59  vmovaps [rsp+0xD0], xmm14
000074c379ddda62  vmovaps [rsp+0xE0], xmm15
000074c379ddda6b  sub rsp, 0x30
000074c379ddda6f  movaps [rsp], xmm4
000074c379ddda73  movaps [rsp+0x10], xmm15
000074c379ddda79  movaps [rsp+0x20], xmm9
000074c379ddda7f  lea rdi, [rsp]
000074c379ddda83  mov esi, 0x00
000074c379ddda88  mov rax, 0x56321ABA4530
000074c379ddda92  call rax
000074c379ddda94  movaps xmm4, [rsp]
000074c379ddda98  add rsp, 0x30
000074c379ddda9c  vmovaps xmm0, [rsp]
000074c379dddaa1  vmovaps xmm1, [rsp+0x10]
000074c379dddaa7  vmovaps xmm2, [rsp+0x20]
000074c379dddaad  vmovaps xmm3, [rsp+0x30]
000074c379dddab3  vmovaps xmm5, [rsp+0x40]
000074c379dddab9  vmovaps xmm6, [rsp+0x50]
000074c379dddabf  vmovaps xmm7, [rsp+0x60]
000074c379dddac5  vmovaps xmm8, [rsp+0x70]
000074c379dddacb  vmovaps xmm9, [rsp+0x80]
000074c379dddad4  vmovaps xmm10, [rsp+0x90]
000074c379dddadd  vmovaps xmm11, [rsp+0xA0]
000074c379dddae6  vmovaps xmm12, [rsp+0xB0]
000074c379dddaef  vmovaps xmm13, [rsp+0xC0]
000074c379dddaf8  vmovaps xmm14, [rsp+0xD0]
000074c379dddb01  vmovaps xmm15, [rsp+0xE0]
000074c379dddb0a  add rsp, 0xF0
000074c379dddb11  pop r11
000074c379dddb13  pop r10
000074c379dddb15  pop r9
000074c379dddb17  pop r8
000074c379dddb19  pop rsi
000074c379dddb1a  pop rdi
000074c379dddb1b  pop rdx
000074c379dddb1c  pop rcx
000074c379dddb1d  pop rax
000074c379dddb1e  add rsp, 0x08
000074c379dddb22  jmp 0x000074C379DDBEAC
000074c379dddb27  call 0x000074C379CC4620
000074c379dddb2c  jmp 0x000074C379DDBEB9
000074c379dddb31  sub rsp, 0x08
000074c379dddb35  push rax
000074c379dddb36  push rcx
000074c379dddb37  push rdx
000074c379dddb38  push rdi
000074c379dddb39  push rsi
000074c379dddb3a  push r8
000074c379dddb3c  push r9
000074c379dddb3e  push r10
000074c379dddb40  push r11
000074c379dddb42  sub rsp, 0xF0
000074c379dddb49  vmovaps [rsp], xmm0
000074c379dddb4e  vmovaps [rsp+0x10], xmm1
000074c379dddb54  vmovaps [rsp+0x20], xmm2
000074c379dddb5a  vmovaps [rsp+0x30], xmm4
000074c379dddb60  vmovaps [rsp+0x40], xmm5
000074c379dddb66  vmovaps [rsp+0x50], xmm6
000074c379dddb6c  vmovaps [rsp+0x60], xmm7
000074c379dddb72  vmovaps [rsp+0x70], xmm8
000074c379dddb78  vmovaps [rsp+0x80], xmm9
000074c379dddb81  vmovaps [rsp+0x90], xmm10
000074c379dddb8a  vmovaps [rsp+0xA0], xmm11
000074c379dddb93  vmovaps [rsp+0xB0], xmm12
000074c379dddb9c  vmovaps [rsp+0xC0], xmm13
000074c379dddba5  vmovaps [rsp+0xD0], xmm14
000074c379dddbae  vmovaps [rsp+0xE0], xmm15
000074c379dddbb7  sub rsp, 0x30
000074c379dddbbb  movaps [rsp], xmm3
000074c379dddbbf  movaps [rsp+0x10], xmm1
000074c379dddbc4  movaps [rsp+0x20], xmm9
000074c379dddbca  lea rdi, [rsp]
000074c379dddbce  mov esi, 0x00
000074c379dddbd3  mov rax, 0x56321ABA4530
000074c379dddbdd  call rax
000074c379dddbdf  movaps xmm3, [rsp]
000074c379dddbe3  add rsp, 0x30
000074c379dddbe7  vmovaps xmm0, [rsp]
000074c379dddbec  vmovaps xmm1, [rsp+0x10]
000074c379dddbf2  vmovaps xmm2, [rsp+0x20]
000074c379dddbf8  vmovaps xmm4, [rsp+0x30]
000074c379dddbfe  vmovaps xmm5, [rsp+0x40]
000074c379dddc04  vmovaps xmm6, [rsp+0x50]
000074c379dddc0a  vmovaps xmm7, [rsp+0x60]
000074c379dddc10  vmovaps xmm8, [rsp+0x70]
000074c379dddc16  vmovaps xmm9, [rsp+0x80]
000074c379dddc1f  vmovaps xmm10, [rsp+0x90]
000074c379dddc28  vmovaps xmm11, [rsp+0xA0]
000074c379dddc31  vmovaps xmm12, [rsp+0xB0]
000074c379dddc3a  vmovaps xmm13, [rsp+0xC0]
000074c379dddc43  vmovaps xmm14, [rsp+0xD0]
000074c379dddc4c  vmovaps xmm15, [rsp+0xE0]
000074c379dddc55  add rsp, 0xF0
000074c379dddc5c  pop r11
000074c379dddc5e  pop r10
000074c379dddc60  pop r9
000074c379dddc62  pop r8
000074c379dddc64  pop rsi
000074c379dddc65  pop rdi
000074c379dddc66  pop rdx
000074c379dddc67  pop rcx
000074c379dddc68  pop rax
000074c379dddc69  add rsp, 0x08
000074c379dddc6d  jmp 0x000074C379DDBEF6
000074c379dddc72  sub rsp, 0x08
000074c379dddc76  push rax
000074c379dddc77  push rcx
000074c379dddc78  push rdx
000074c379dddc79  push rdi
000074c379dddc7a  push rsi
000074c379dddc7b  push r8
000074c379dddc7d  push r9
000074c379dddc7f  push r10
000074c379dddc81  push r11
000074c379dddc83  sub rsp, 0xF0
000074c379dddc8a  vmovaps [rsp], xmm0
000074c379dddc8f  vmovaps [rsp+0x10], xmm2
000074c379dddc95  vmovaps [rsp+0x20], xmm3
000074c379dddc9b  vmovaps [rsp+0x30], xmm4
000074c379dddca1  vmovaps [rsp+0x40], xmm5
000074c379dddca7  vmovaps [rsp+0x50], xmm6
000074c379dddcad  vmovaps [rsp+0x60], xmm7
000074c379dddcb3  vmovaps [rsp+0x70], xmm8
000074c379dddcb9  vmovaps [rsp+0x80], xmm9
000074c379dddcc2  vmovaps [rsp+0x90], xmm10
000074c379dddccb  vmovaps [rsp+0xA0], xmm11
000074c379dddcd4  vmovaps [rsp+0xB0], xmm12
000074c379dddcdd  vmovaps [rsp+0xC0], xmm13
000074c379dddce6  vmovaps [rsp+0xD0], xmm14
000074c379dddcef  vmovaps [rsp+0xE0], xmm15
000074c379dddcf8  sub rsp, 0x30
000074c379dddcfc  movaps [rsp], xmm1
000074c379dddd00  movaps [rsp+0x10], xmm15
000074c379dddd06  movaps [rsp+0x20], xmm9
000074c379dddd0c  lea rdi, [rsp]
000074c379dddd10  mov esi, 0x00
000074c379dddd15  mov rax, 0x56321ABA4530
000074c379dddd1f  call rax
000074c379dddd21  movaps xmm1, [rsp]
000074c379dddd25  add rsp, 0x30
000074c379dddd29  vmovaps xmm0, [rsp]
000074c379dddd2e  vmovaps xmm2, [rsp+0x10]
000074c379dddd34  vmovaps xmm3, [rsp+0x20]
000074c379dddd3a  vmovaps xmm4, [rsp+0x30]
000074c379dddd40  vmovaps xmm5, [rsp+0x40]
000074c379dddd46  vmovaps xmm6, [rsp+0x50]
000074c379dddd4c  vmovaps xmm7, [rsp+0x60]
000074c379dddd52  vmovaps xmm8, [rsp+0x70]
000074c379dddd58  vmovaps xmm9, [rsp+0x80]
000074c379dddd61  vmovaps xmm10, [rsp+0x90]
000074c379dddd6a  vmovaps xmm11, [rsp+0xA0]
000074c379dddd73  vmovaps xmm12, [rsp+0xB0]
000074c379dddd7c  vmovaps xmm13, [rsp+0xC0]
000074c379dddd85  vmovaps xmm14, [rsp+0xD0]
000074c379dddd8e  vmovaps xmm15, [rsp+0xE0]
000074c379dddd97  add rsp, 0xF0
000074c379dddd9e  pop r11
000074c379dddda0  pop r10
000074c379dddda2  pop r9
000074c379dddda4  pop r8
000074c379dddda6  pop rsi
000074c379dddda7  pop rdi
000074c379dddda8  pop rdx
000074c379dddda9  pop rcx
000074c379ddddaa  pop rax
000074c379ddddab  add rsp, 0x08
000074c379ddddaf  jmp 0x000074C379DDBF7E
000074c379ddddb4  call 0x000074C379CC4620
000074c379ddddb9  jmp 0x000074C379DDBF8B
000074c379ddddbe  sub rsp, 0x08
000074c379ddddc2  push rax
000074c379ddddc3  push rcx
000074c379ddddc4  push rdx
000074c379ddddc5  push rdi
000074c379ddddc6  push rsi
000074c379ddddc7  push r8
000074c379ddddc9  push r9
000074c379ddddcb  push r10
000074c379ddddcd  push r11
000074c379ddddcf  sub rsp, 0xF0
000074c379ddddd6  vmovaps [rsp], xmm0
000074c379dddddb  vmovaps [rsp+0x10], xmm2
000074c379dddde1  vmovaps [rsp+0x20], xmm3
000074c379dddde7  vmovaps [rsp+0x30], xmm4
000074c379dddded  vmovaps [rsp+0x40], xmm5
000074c379ddddf3  vmovaps [rsp+0x50], xmm6
000074c379ddddf9  vmovaps [rsp+0x60], xmm7
000074c379ddddff  vmovaps [rsp+0x70], xmm8
000074c379ddde05  vmovaps [rsp+0x80], xmm9
000074c379ddde0e  vmovaps [rsp+0x90], xmm10
000074c379ddde17  vmovaps [rsp+0xA0], xmm11
000074c379ddde20  vmovaps [rsp+0xB0], xmm12
000074c379ddde29  vmovaps [rsp+0xC0], xmm13
000074c379ddde32  vmovaps [rsp+0xD0], xmm14
000074c379ddde3b  vmovaps [rsp+0xE0], xmm15
000074c379ddde44  sub rsp, 0x30
000074c379ddde48  movaps [rsp], xmm1
000074c379ddde4c  movaps [rsp+0x10], xmm5
000074c379ddde51  movaps [rsp+0x20], xmm7
000074c379ddde56  lea rdi, [rsp]
000074c379ddde5a  mov esi, 0x00
000074c379ddde5f  mov rax, 0x56321ABA4530
000074c379ddde69  call rax
000074c379ddde6b  movaps xmm1, [rsp]
000074c379ddde6f  add rsp, 0x30
000074c379ddde73  vmovaps xmm0, [rsp]
000074c379ddde78  vmovaps xmm2, [rsp+0x10]
000074c379ddde7e  vmovaps xmm3, [rsp+0x20]
000074c379ddde84  vmovaps xmm4, [rsp+0x30]
000074c379ddde8a  vmovaps xmm5, [rsp+0x40]
000074c379ddde90  vmovaps xmm6, [rsp+0x50]
000074c379ddde96  vmovaps xmm7, [rsp+0x60]
000074c379ddde9c  vmovaps xmm8, [rsp+0x70]
000074c379dddea2  vmovaps xmm9, [rsp+0x80]
000074c379dddeab  vmovaps xmm10, [rsp+0x90]
000074c379dddeb4  vmovaps xmm11, [rsp+0xA0]
000074c379dddebd  vmovaps xmm12, [rsp+0xB0]
000074c379dddec6  vmovaps xmm13, [rsp+0xC0]
000074c379dddecf  vmovaps xmm14, [rsp+0xD0]
000074c379ddded8  vmovaps xmm15, [rsp+0xE0]
000074c379dddee1  add rsp, 0xF0
000074c379dddee8  pop r11
000074c379dddeea  pop r10
000074c379dddeec  pop r9
000074c379dddeee  pop r8
000074c379dddef0  pop rsi
000074c379dddef1  pop rdi
000074c379dddef2  pop rdx
000074c379dddef3  pop rcx
000074c379dddef4  pop rax
000074c379dddef5  add rsp, 0x08
000074c379dddef9  jmp 0x000074C379DDC030
000074c379dddefe  sub rsp, 0x08
000074c379dddf02  push rax
000074c379dddf03  push rcx
000074c379dddf04  push rdx
000074c379dddf05  push rdi
000074c379dddf06  push rsi
000074c379dddf07  push r8
000074c379dddf09  push r9
000074c379dddf0b  push r10
000074c379dddf0d  push r11
000074c379dddf0f  sub rsp, 0xF0
000074c379dddf16  vmovaps [rsp], xmm0
000074c379dddf1b  vmovaps [rsp+0x10], xmm1
000074c379dddf21  vmovaps [rsp+0x20], xmm2
000074c379dddf27  vmovaps [rsp+0x30], xmm3
000074c379dddf2d  vmovaps [rsp+0x40], xmm4
000074c379dddf33  vmovaps [rsp+0x50], xmm5
000074c379dddf39  vmovaps [rsp+0x60], xmm6
000074c379dddf3f  vmovaps [rsp+0x70], xmm8
000074c379dddf45  vmovaps [rsp+0x80], xmm9
000074c379dddf4e  vmovaps [rsp+0x90], xmm10
000074c379dddf57  vmovaps [rsp+0xA0], xmm11
000074c379dddf60  vmovaps [rsp+0xB0], xmm12
000074c379dddf69  vmovaps [rsp+0xC0], xmm13
000074c379dddf72  vmovaps [rsp+0xD0], xmm14
000074c379dddf7b  vmovaps [rsp+0xE0], xmm15
000074c379dddf84  sub rsp, 0x30
000074c379dddf88  movaps [rsp], xmm7
000074c379dddf8c  movaps [rsp+0x10], xmm5
000074c379dddf91  movaps [rsp+0x20], xmm15
000074c379dddf97  lea rdi, [rsp]
000074c379dddf9b  mov esi, 0x00
000074c379dddfa0  mov rax, 0x56321ABA4530
000074c379dddfaa  call rax
000074c379dddfac  movaps xmm7, [rsp]
000074c379dddfb0  add rsp, 0x30
000074c379dddfb4  vmovaps xmm0, [rsp]
000074c379dddfb9  vmovaps xmm1, [rsp+0x10]
000074c379dddfbf  vmovaps xmm2, [rsp+0x20]
000074c379dddfc5  vmovaps xmm3, [rsp+0x30]
000074c379dddfcb  vmovaps xmm4, [rsp+0x40]
000074c379dddfd1  vmovaps xmm5, [rsp+0x50]
000074c379dddfd7  vmovaps xmm6, [rsp+0x60]
000074c379dddfdd  vmovaps xmm8, [rsp+0x70]
000074c379dddfe3  vmovaps xmm9, [rsp+0x80]
000074c379dddfec  vmovaps xmm10, [rsp+0x90]
000074c379dddff5  vmovaps xmm11, [rsp+0xA0]
000074c379dddffe  vmovaps xmm12, [rsp+0xB0]
000074c379dde007  vmovaps xmm13, [rsp+0xC0]
000074c379dde010  vmovaps xmm14, [rsp+0xD0]
000074c379dde019  vmovaps xmm15, [rsp+0xE0]
000074c379dde022  add rsp, 0xF0
000074c379dde029  pop r11
000074c379dde02b  pop r10
000074c379dde02d  pop r9
000074c379dde02f  pop r8
000074c379dde031  pop rsi
000074c379dde032  pop rdi
000074c379dde033  pop rdx
000074c379dde034  pop rcx
000074c379dde035  pop rax
000074c379dde036  add rsp, 0x08
000074c379dde03a  jmp 0x000074C379DDC066
000074c379dde03f  call 0x000074C379CB52F0
000074c379dde044  jmp 0x000074C379DDC073
000074c379dde049  sub rsp, 0x08
000074c379dde04d  push rax
000074c379dde04e  push rcx
000074c379dde04f  push rdx
000074c379dde050  push rdi
000074c379dde051  push rsi
000074c379dde052  push r8
000074c379dde054  push r9
000074c379dde056  push r10
000074c379dde058  push r11
000074c379dde05a  sub rsp, 0xF0
000074c379dde061  vmovaps [rsp], xmm0
000074c379dde066  vmovaps [rsp+0x10], xmm1
000074c379dde06c  vmovaps [rsp+0x20], xmm2
000074c379dde072  vmovaps [rsp+0x30], xmm3
000074c379dde078  vmovaps [rsp+0x40], xmm4
000074c379dde07e  vmovaps [rsp+0x50], xmm5
000074c379dde084  vmovaps [rsp+0x60], xmm6
000074c379dde08a  vmovaps [rsp+0x70], xmm7
000074c379dde090  vmovaps [rsp+0x80], xmm8
000074c379dde099  vmovaps [rsp+0x90], xmm9
000074c379dde0a2  vmovaps [rsp+0xA0], xmm10
000074c379dde0ab  vmovaps [rsp+0xB0], xmm11
000074c379dde0b4  vmovaps [rsp+0xC0], xmm12
000074c379dde0bd  vmovaps [rsp+0xD0], xmm13
000074c379dde0c6  vmovaps [rsp+0xE0], xmm14
000074c379dde0cf  sub rsp, 0x30
000074c379dde0d3  movaps [rsp], xmm15
000074c379dde0d8  movaps [rsp+0x10], xmm5
000074c379dde0dd  movaps [rsp+0x20], xmm3
000074c379dde0e2  lea rdi, [rsp]
000074c379dde0e6  mov esi, 0x00
000074c379dde0eb  mov rax, 0x56321ABA4530
000074c379dde0f5  call rax
000074c379dde0f7  movaps xmm15, [rsp]
000074c379dde0fc  add rsp, 0x30
000074c379dde100  vmovaps xmm0, [rsp]
000074c379dde105  vmovaps xmm1, [rsp+0x10]
000074c379dde10b  vmovaps xmm2, [rsp+0x20]
000074c379dde111  vmovaps xmm3, [rsp+0x30]
000074c379dde117  vmovaps xmm4, [rsp+0x40]
000074c379dde11d  vmovaps xmm5, [rsp+0x50]
000074c379dde123  vmovaps xmm6, [rsp+0x60]
000074c379dde129  vmovaps xmm7, [rsp+0x70]
000074c379dde12f  vmovaps xmm8, [rsp+0x80]
000074c379dde138  vmovaps xmm9, [rsp+0x90]
000074c379dde141  vmovaps xmm10, [rsp+0xA0]
000074c379dde14a  vmovaps xmm11, [rsp+0xB0]
000074c379dde153  vmovaps xmm12, [rsp+0xC0]
000074c379dde15c  vmovaps xmm13, [rsp+0xD0]
000074c379dde165  vmovaps xmm14, [rsp+0xE0]
000074c379dde16e  add rsp, 0xF0
000074c379dde175  pop r11
000074c379dde177  pop r10
000074c379dde179  pop r9
000074c379dde17b  pop r8
000074c379dde17d  pop rsi
000074c379dde17e  pop rdi
000074c379dde17f  pop rdx
000074c379dde180  pop rcx
000074c379dde181  pop rax
000074c379dde182  add rsp, 0x08
000074c379dde186  jmp 0x000074C379DDC099
000074c379dde18b  sub rsp, 0x08
000074c379dde18f  push rax
000074c379dde190  push rcx
000074c379dde191  push rdx
000074c379dde192  push rdi
000074c379dde193  push rsi
000074c379dde194  push r8
000074c379dde196  push r9
000074c379dde198  push r10
000074c379dde19a  push r11
000074c379dde19c  sub rsp, 0xF0
000074c379dde1a3  vmovaps [rsp], xmm0
000074c379dde1a8  vmovaps [rsp+0x10], xmm2
000074c379dde1ae  vmovaps [rsp+0x20], xmm3
000074c379dde1b4  vmovaps [rsp+0x30], xmm4
000074c379dde1ba  vmovaps [rsp+0x40], xmm5
000074c379dde1c0  vmovaps [rsp+0x50], xmm6
000074c379dde1c6  vmovaps [rsp+0x60], xmm7
000074c379dde1cc  vmovaps [rsp+0x70], xmm8
000074c379dde1d2  vmovaps [rsp+0x80], xmm9
000074c379dde1db  vmovaps [rsp+0x90], xmm10
000074c379dde1e4  vmovaps [rsp+0xA0], xmm11
000074c379dde1ed  vmovaps [rsp+0xB0], xmm12
000074c379dde1f6  vmovaps [rsp+0xC0], xmm13
000074c379dde1ff  vmovaps [rsp+0xD0], xmm14
000074c379dde208  vmovaps [rsp+0xE0], xmm15
000074c379dde211  sub rsp, 0x30
000074c379dde215  movaps [rsp], xmm1
000074c379dde219  movaps [rsp+0x10], xmm5
000074c379dde21e  movaps [rsp+0x20], xmm4
000074c379dde223  lea rdi, [rsp]
000074c379dde227  mov esi, 0x00
000074c379dde22c  mov rax, 0x56321ABA4530
000074c379dde236  call rax
000074c379dde238  movaps xmm1, [rsp]
000074c379dde23c  add rsp, 0x30
000074c379dde240  vmovaps xmm0, [rsp]
000074c379dde245  vmovaps xmm2, [rsp+0x10]
000074c379dde24b  vmovaps xmm3, [rsp+0x20]
000074c379dde251  vmovaps xmm4, [rsp+0x30]
000074c379dde257  vmovaps xmm5, [rsp+0x40]
000074c379dde25d  vmovaps xmm6, [rsp+0x50]
000074c379dde263  vmovaps xmm7, [rsp+0x60]
000074c379dde269  vmovaps xmm8, [rsp+0x70]
000074c379dde26f  vmovaps xmm9, [rsp+0x80]
000074c379dde278  vmovaps xmm10, [rsp+0x90]
000074c379dde281  vmovaps xmm11, [rsp+0xA0]
000074c379dde28a  vmovaps xmm12, [rsp+0xB0]
000074c379dde293  vmovaps xmm13, [rsp+0xC0]
000074c379dde29c  vmovaps xmm14, [rsp+0xD0]
000074c379dde2a5  vmovaps xmm15, [rsp+0xE0]
000074c379dde2ae  add rsp, 0xF0
000074c379dde2b5  pop r11
000074c379dde2b7  pop r10
000074c379dde2b9  pop r9
000074c379dde2bb  pop r8
000074c379dde2bd  pop rsi
000074c379dde2be  pop rdi
000074c379dde2bf  pop rdx
000074c379dde2c0  pop rcx
000074c379dde2c1  pop rax
000074c379dde2c2  add rsp, 0x08
000074c379dde2c6  jmp 0x000074C379DDC0B9
000074c379dde2cb  sub rsp, 0x08
000074c379dde2cf  push rax
000074c379dde2d0  push rcx
000074c379dde2d1  push rdx
000074c379dde2d2  push rdi
000074c379dde2d3  push rsi
000074c379dde2d4  push r8
000074c379dde2d6  push r9
000074c379dde2d8  push r10
000074c379dde2da  push r11
000074c379dde2dc  sub rsp, 0xF0
000074c379dde2e3  vmovaps [rsp], xmm0
000074c379dde2e8  vmovaps [rsp+0x10], xmm1
000074c379dde2ee  vmovaps [rsp+0x20], xmm2
000074c379dde2f4  vmovaps [rsp+0x30], xmm3
000074c379dde2fa  vmovaps [rsp+0x40], xmm5
000074c379dde300  vmovaps [rsp+0x50], xmm6
000074c379dde306  vmovaps [rsp+0x60], xmm7
000074c379dde30c  vmovaps [rsp+0x70], xmm8
000074c379dde312  vmovaps [rsp+0x80], xmm9
000074c379dde31b  vmovaps [rsp+0x90], xmm10
000074c379dde324  vmovaps [rsp+0xA0], xmm11
000074c379dde32d  vmovaps [rsp+0xB0], xmm12
000074c379dde336  vmovaps [rsp+0xC0], xmm13
000074c379dde33f  vmovaps [rsp+0xD0], xmm14
000074c379dde348  vmovaps [rsp+0xE0], xmm15
000074c379dde351  sub rsp, 0x30
000074c379dde355  movaps [rsp], xmm4
000074c379dde359  movaps [rsp+0x10], xmm3
000074c379dde35e  movaps [rsp+0x20], xmm5
000074c379dde363  lea rdi, [rsp]
000074c379dde367  mov esi, 0x00
000074c379dde36c  mov rax, 0x56321ABA4530
000074c379dde376  call rax
000074c379dde378  movaps xmm4, [rsp]
000074c379dde37c  add rsp, 0x30
000074c379dde380  vmovaps xmm0, [rsp]
000074c379dde385  vmovaps xmm1, [rsp+0x10]
000074c379dde38b  vmovaps xmm2, [rsp+0x20]
000074c379dde391  vmovaps xmm3, [rsp+0x30]
000074c379dde397  vmovaps xmm5, [rsp+0x40]
000074c379dde39d  vmovaps xmm6, [rsp+0x50]
000074c379dde3a3  vmovaps xmm7, [rsp+0x60]
000074c379dde3a9  vmovaps xmm8, [rsp+0x70]
000074c379dde3af  vmovaps xmm9, [rsp+0x80]
000074c379dde3b8  vmovaps xmm10, [rsp+0x90]
000074c379dde3c1  vmovaps xmm11, [rsp+0xA0]
000074c379dde3ca  vmovaps xmm12, [rsp+0xB0]
000074c379dde3d3  vmovaps xmm13, [rsp+0xC0]
000074c379dde3dc  vmovaps xmm14, [rsp+0xD0]
000074c379dde3e5  vmovaps xmm15, [rsp+0xE0]
000074c379dde3ee  add rsp, 0xF0
000074c379dde3f5  pop r11
000074c379dde3f7  pop r10
000074c379dde3f9  pop r9
000074c379dde3fb  pop r8
000074c379dde3fd  pop rsi
000074c379dde3fe  pop rdi
000074c379dde3ff  pop rdx
000074c379dde400  pop rcx
000074c379dde401  pop rax
000074c379dde402  add rsp, 0x08
000074c379dde406  jmp 0x000074C379DDC107
000074c379dde40b  call 0x000074C379CB52F0
000074c379dde410  jmp 0x000074C379DDC114
000074c379dde415  sub rsp, 0x08
000074c379dde419  push rax
000074c379dde41a  push rcx
000074c379dde41b  push rdx
000074c379dde41c  push rdi
000074c379dde41d  push rsi
000074c379dde41e  push r8
000074c379dde420  push r9
000074c379dde422  push r10
000074c379dde424  push r11
000074c379dde426  sub rsp, 0xF0
000074c379dde42d  vmovaps [rsp], xmm0
000074c379dde432  vmovaps [rsp+0x10], xmm1
000074c379dde438  vmovaps [rsp+0x20], xmm2
000074c379dde43e  vmovaps [rsp+0x30], xmm3
000074c379dde444  vmovaps [rsp+0x40], xmm4
000074c379dde44a  vmovaps [rsp+0x50], xmm6
000074c379dde450  vmovaps [rsp+0x60], xmm7
000074c379dde456  vmovaps [rsp+0x70], xmm8
000074c379dde45c  vmovaps [rsp+0x80], xmm9
000074c379dde465  vmovaps [rsp+0x90], xmm10
000074c379dde46e  vmovaps [rsp+0xA0], xmm11
000074c379dde477  vmovaps [rsp+0xB0], xmm12
000074c379dde480  vmovaps [rsp+0xC0], xmm13
000074c379dde489  vmovaps [rsp+0xD0], xmm14
000074c379dde492  vmovaps [rsp+0xE0], xmm15
000074c379dde49b  sub rsp, 0x30
000074c379dde49f  movaps [rsp], xmm5
000074c379dde4a3  movaps [rsp+0x10], xmm6
000074c379dde4a8  movaps [rsp+0x20], xmm3
000074c379dde4ad  lea rdi, [rsp]
000074c379dde4b1  mov esi, 0x00
000074c379dde4b6  mov rax, 0x56321ABA4530
000074c379dde4c0  call rax
000074c379dde4c2  movaps xmm5, [rsp]
000074c379dde4c6  add rsp, 0x30
000074c379dde4ca  vmovaps xmm0, [rsp]
000074c379dde4cf  vmovaps xmm1, [rsp+0x10]
000074c379dde4d5  vmovaps xmm2, [rsp+0x20]
000074c379dde4db  vmovaps xmm3, [rsp+0x30]
000074c379dde4e1  vmovaps xmm4, [rsp+0x40]
000074c379dde4e7  vmovaps xmm6, [rsp+0x50]
000074c379dde4ed  vmovaps xmm7, [rsp+0x60]
000074c379dde4f3  vmovaps xmm8, [rsp+0x70]
000074c379dde4f9  vmovaps xmm9, [rsp+0x80]
000074c379dde502  vmovaps xmm10, [rsp+0x90]
000074c379dde50b  vmovaps xmm11, [rsp+0xA0]
000074c379dde514  vmovaps xmm12, [rsp+0xB0]
000074c379dde51d  vmovaps xmm13, [rsp+0xC0]
000074c379dde526  vmovaps xmm14, [rsp+0xD0]
000074c379dde52f  vmovaps xmm15, [rsp+0xE0]
000074c379dde538  add rsp, 0xF0
000074c379dde53f  pop r11
000074c379dde541  pop r10
000074c379dde543  pop r9
000074c379dde545  pop r8
000074c379dde547  pop rsi
000074c379dde548  pop rdi
000074c379dde549  pop rdx
000074c379dde54a  pop rcx
000074c379dde54b  pop rax
000074c379dde54c  add rsp, 0x08
000074c379dde550  jmp 0x000074C379DDC13A
000074c379dde555  sub rsp, 0x08
000074c379dde559  push rax
000074c379dde55a  push rcx
000074c379dde55b  push rdx
000074c379dde55c  push rdi
000074c379dde55d  push rsi
000074c379dde55e  push r8
000074c379dde560  push r9
000074c379dde562  push r10
000074c379dde564  push r11
000074c379dde566  sub rsp, 0xF0
000074c379dde56d  vmovaps [rsp], xmm0
000074c379dde572  vmovaps [rsp+0x10], xmm1
000074c379dde578  vmovaps [rsp+0x20], xmm2
000074c379dde57e  vmovaps [rsp+0x30], xmm3
000074c379dde584  vmovaps [rsp+0x40], xmm4
000074c379dde58a  vmovaps [rsp+0x50], xmm5
000074c379dde590  vmovaps [rsp+0x60], xmm7
000074c379dde596  vmovaps [rsp+0x70], xmm8
000074c379dde59c  vmovaps [rsp+0x80], xmm9
000074c379dde5a5  vmovaps [rsp+0x90], xmm10
000074c379dde5ae  vmovaps [rsp+0xA0], xmm11
000074c379dde5b7  vmovaps [rsp+0xB0], xmm12
000074c379dde5c0  vmovaps [rsp+0xC0], xmm13
000074c379dde5c9  vmovaps [rsp+0xD0], xmm14
000074c379dde5d2  vmovaps [rsp+0xE0], xmm15
000074c379dde5db  sub rsp, 0x30
000074c379dde5df  movaps [rsp], xmm6
000074c379dde5e3  movaps [rsp+0x10], xmm9
000074c379dde5e9  movaps [rsp+0x20], xmm1
000074c379dde5ee  lea rdi, [rsp]
000074c379dde5f2  mov esi, 0x00
000074c379dde5f7  mov rax, 0x56321ABA4530
000074c379dde601  call rax
000074c379dde603  movaps xmm6, [rsp]
000074c379dde607  add rsp, 0x30
000074c379dde60b  vmovaps xmm0, [rsp]
000074c379dde610  vmovaps xmm1, [rsp+0x10]
000074c379dde616  vmovaps xmm2, [rsp+0x20]
000074c379dde61c  vmovaps xmm3, [rsp+0x30]
000074c379dde622  vmovaps xmm4, [rsp+0x40]
000074c379dde628  vmovaps xmm5, [rsp+0x50]
000074c379dde62e  vmovaps xmm7, [rsp+0x60]
000074c379dde634  vmovaps xmm8, [rsp+0x70]
000074c379dde63a  vmovaps xmm9, [rsp+0x80]
000074c379dde643  vmovaps xmm10, [rsp+0x90]
000074c379dde64c  vmovaps xmm11, [rsp+0xA0]
000074c379dde655  vmovaps xmm12, [rsp+0xB0]
000074c379dde65e  vmovaps xmm13, [rsp+0xC0]
000074c379dde667  vmovaps xmm14, [rsp+0xD0]
000074c379dde670  vmovaps xmm15, [rsp+0xE0]
000074c379dde679  add rsp, 0xF0
000074c379dde680  pop r11
000074c379dde682  pop r10
000074c379dde684  pop r9
000074c379dde686  pop r8
000074c379dde688  pop rsi
000074c379dde689  pop rdi
000074c379dde68a  pop rdx
000074c379dde68b  pop rcx
000074c379dde68c  pop rax
000074c379dde68d  add rsp, 0x08
000074c379dde691  jmp 0x000074C379DDC15E
000074c379dde696  sub rsp, 0x08
000074c379dde69a  push rax
000074c379dde69b  push rcx
000074c379dde69c  push rdx
000074c379dde69d  push rdi
000074c379dde69e  push rsi
000074c379dde69f  push r8
000074c379dde6a1  push r9
000074c379dde6a3  push r10
000074c379dde6a5  push r11
000074c379dde6a7  sub rsp, 0xF0
000074c379dde6ae  vmovaps [rsp], xmm0
000074c379dde6b3  vmovaps [rsp+0x10], xmm1
000074c379dde6b9  vmovaps [rsp+0x20], xmm2
000074c379dde6bf  vmovaps [rsp+0x30], xmm3
000074c379dde6c5  vmovaps [rsp+0x40], xmm4
000074c379dde6cb  vmovaps [rsp+0x50], xmm5
000074c379dde6d1  vmovaps [rsp+0x60], xmm6
000074c379dde6d7  vmovaps [rsp+0x70], xmm7
000074c379dde6dd  vmovaps [rsp+0x80], xmm8
000074c379dde6e6  vmovaps [rsp+0x90], xmm10
000074c379dde6ef  vmovaps [rsp+0xA0], xmm11
000074c379dde6f8  vmovaps [rsp+0xB0], xmm12
000074c379dde701  vmovaps [rsp+0xC0], xmm13
000074c379dde70a  vmovaps [rsp+0xD0], xmm14
000074c379dde713  vmovaps [rsp+0xE0], xmm15
000074c379dde71c  sub rsp, 0x30
000074c379dde720  movaps [rsp], xmm9
000074c379dde725  movaps [rsp+0x10], xmm3
000074c379dde72a  movaps [rsp+0x20], xmm1
000074c379dde72f  lea rdi, [rsp]
000074c379dde733  mov esi, 0x00
000074c379dde738  mov rax, 0x56321ABA4530
000074c379dde742  call rax
000074c379dde744  movaps xmm9, [rsp]
000074c379dde749  add rsp, 0x30
000074c379dde74d  vmovaps xmm0, [rsp]
000074c379dde752  vmovaps xmm1, [rsp+0x10]
000074c379dde758  vmovaps xmm2, [rsp+0x20]
000074c379dde75e  vmovaps xmm3, [rsp+0x30]
000074c379dde764  vmovaps xmm4, [rsp+0x40]
000074c379dde76a  vmovaps xmm5, [rsp+0x50]
000074c379dde770  vmovaps xmm6, [rsp+0x60]
000074c379dde776  vmovaps xmm7, [rsp+0x70]
000074c379dde77c  vmovaps xmm8, [rsp+0x80]
000074c379dde785  vmovaps xmm10, [rsp+0x90]
000074c379dde78e  vmovaps xmm11, [rsp+0xA0]
000074c379dde797  vmovaps xmm12, [rsp+0xB0]
000074c379dde7a0  vmovaps xmm13, [rsp+0xC0]
000074c379dde7a9  vmovaps xmm14, [rsp+0xD0]
000074c379dde7b2  vmovaps xmm15, [rsp+0xE0]
000074c379dde7bb  add rsp, 0xF0
000074c379dde7c2  pop r11
000074c379dde7c4  pop r10
000074c379dde7c6  pop r9
000074c379dde7c8  pop r8
000074c379dde7ca  pop rsi
000074c379dde7cb  pop rdi
000074c379dde7cc  pop rdx
000074c379dde7cd  pop rcx
000074c379dde7ce  pop rax
000074c379dde7cf  add rsp, 0x08
000074c379dde7d3  jmp 0x000074C379DDC1AA
000074c379dde7d8  call 0x000074C379CB52F0
000074c379dde7dd  jmp 0x000074C379DDC1B7
000074c379dde7e2  sub rsp, 0x08
000074c379dde7e6  push rax
000074c379dde7e7  push rcx
000074c379dde7e8  push rdx
000074c379dde7e9  push rdi
000074c379dde7ea  push rsi
000074c379dde7eb  push r8
000074c379dde7ed  push r9
000074c379dde7ef  push r10
000074c379dde7f1  push r11
000074c379dde7f3  sub rsp, 0xF0
000074c379dde7fa  vmovaps [rsp], xmm0
000074c379dde7ff  vmovaps [rsp+0x10], xmm1
000074c379dde805  vmovaps [rsp+0x20], xmm2
000074c379dde80b  vmovaps [rsp+0x30], xmm3
000074c379dde811  vmovaps [rsp+0x40], xmm4
000074c379dde817  vmovaps [rsp+0x50], xmm5
000074c379dde81d  vmovaps [rsp+0x60], xmm6
000074c379dde823  vmovaps [rsp+0x70], xmm7
000074c379dde829  vmovaps [rsp+0x80], xmm8
000074c379dde832  vmovaps [rsp+0x90], xmm9
000074c379dde83b  vmovaps [rsp+0xA0], xmm10
000074c379dde844  vmovaps [rsp+0xB0], xmm11
000074c379dde84d  vmovaps [rsp+0xC0], xmm12
000074c379dde856  vmovaps [rsp+0xD0], xmm13
000074c379dde85f  vmovaps [rsp+0xE0], xmm14
000074c379dde868  sub rsp, 0x30
000074c379dde86c  movaps [rsp], xmm15
000074c379dde871  movaps [rsp+0x10], xmm3
000074c379dde876  movaps [rsp+0x20], xmm7
000074c379dde87b  lea rdi, [rsp]
000074c379dde87f  mov esi, 0x00
000074c379dde884  mov rax, 0x56321ABA4530
000074c379dde88e  call rax
000074c379dde890  movaps xmm15, [rsp]
000074c379dde895  add rsp, 0x30
000074c379dde899  vmovaps xmm0, [rsp]
000074c379dde89e  vmovaps xmm1, [rsp+0x10]
000074c379dde8a4  vmovaps xmm2, [rsp+0x20]
000074c379dde8aa  vmovaps xmm3, [rsp+0x30]
000074c379dde8b0  vmovaps xmm4, [rsp+0x40]
000074c379dde8b6  vmovaps xmm5, [rsp+0x50]
000074c379dde8bc  vmovaps xmm6, [rsp+0x60]
000074c379dde8c2  vmovaps xmm7, [rsp+0x70]
000074c379dde8c8  vmovaps xmm8, [rsp+0x80]
000074c379dde8d1  vmovaps xmm9, [rsp+0x90]
000074c379dde8da  vmovaps xmm10, [rsp+0xA0]
000074c379dde8e3  vmovaps xmm11, [rsp+0xB0]
000074c379dde8ec  vmovaps xmm12, [rsp+0xC0]
000074c379dde8f5  vmovaps xmm13, [rsp+0xD0]
000074c379dde8fe  vmovaps xmm14, [rsp+0xE0]
000074c379dde907  add rsp, 0xF0
000074c379dde90e  pop r11
000074c379dde910  pop r10
000074c379dde912  pop r9
000074c379dde914  pop r8
000074c379dde916  pop rsi
000074c379dde917  pop rdi
000074c379dde918  pop rdx
000074c379dde919  pop rcx
000074c379dde91a  pop rax
000074c379dde91b  add rsp, 0x08
000074c379dde91f  jmp 0x000074C379DDC1E3
000074c379dde924  sub rsp, 0x08
000074c379dde928  push rax
000074c379dde929  push rcx
000074c379dde92a  push rdx
000074c379dde92b  push rdi
000074c379dde92c  push rsi
000074c379dde92d  push r8
000074c379dde92f  push r9
000074c379dde931  push r10
000074c379dde933  push r11
000074c379dde935  sub rsp, 0xF0
000074c379dde93c  vmovaps [rsp], xmm0
000074c379dde941  vmovaps [rsp+0x10], xmm1
000074c379dde947  vmovaps [rsp+0x20], xmm2
000074c379dde94d  vmovaps [rsp+0x30], xmm4
000074c379dde953  vmovaps [rsp+0x40], xmm5
000074c379dde959  vmovaps [rsp+0x50], xmm6
000074c379dde95f  vmovaps [rsp+0x60], xmm7
000074c379dde965  vmovaps [rsp+0x70], xmm8
000074c379dde96b  vmovaps [rsp+0x80], xmm9
000074c379dde974  vmovaps [rsp+0x90], xmm10
000074c379dde97d  vmovaps [rsp+0xA0], xmm11
000074c379dde986  vmovaps [rsp+0xB0], xmm12
000074c379dde98f  vmovaps [rsp+0xC0], xmm13
000074c379dde998  vmovaps [rsp+0xD0], xmm14
000074c379dde9a1  vmovaps [rsp+0xE0], xmm15
000074c379dde9aa  sub rsp, 0x30
000074c379dde9ae  movaps [rsp], xmm3
000074c379dde9b2  movaps [rsp+0x10], xmm1
000074c379dde9b7  movaps [rsp+0x20], xmm15
000074c379dde9bd  lea rdi, [rsp]
000074c379dde9c1  mov esi, 0x00
000074c379dde9c6  mov rax, 0x56321ABA4530
000074c379dde9d0  call rax
000074c379dde9d2  movaps xmm3, [rsp]
000074c379dde9d6  add rsp, 0x30
000074c379dde9da  vmovaps xmm0, [rsp]
000074c379dde9df  vmovaps xmm1, [rsp+0x10]
000074c379dde9e5  vmovaps xmm2, [rsp+0x20]
000074c379dde9eb  vmovaps xmm4, [rsp+0x30]
000074c379dde9f1  vmovaps xmm5, [rsp+0x40]
000074c379dde9f7  vmovaps xmm6, [rsp+0x50]
000074c379dde9fd  vmovaps xmm7, [rsp+0x60]
000074c379ddea03  vmovaps xmm8, [rsp+0x70]
000074c379ddea09  vmovaps xmm9, [rsp+0x80]
000074c379ddea12  vmovaps xmm10, [rsp+0x90]
000074c379ddea1b  vmovaps xmm11, [rsp+0xA0]
000074c379ddea24  vmovaps xmm12, [rsp+0xB0]
000074c379ddea2d  vmovaps xmm13, [rsp+0xC0]
000074c379ddea36  vmovaps xmm14, [rsp+0xD0]
000074c379ddea3f  vmovaps xmm15, [rsp+0xE0]
000074c379ddea48  add rsp, 0xF0
000074c379ddea4f  pop r11
000074c379ddea51  pop r10
000074c379ddea53  pop r9
000074c379ddea55  pop r8
000074c379ddea57  pop rsi
000074c379ddea58  pop rdi
000074c379ddea59  pop rdx
000074c379ddea5a  pop rcx
000074c379ddea5b  pop rax
000074c379ddea5c  add rsp, 0x08
000074c379ddea60  jmp 0x000074C379DDC272
000074c379ddea65  call 0x000074C379CB52F0
000074c379ddea6a  jmp 0x000074C379DDC27C
000074c379ddea6f  sub rsp, 0x08
000074c379ddea73  push rax
000074c379ddea74  push rcx
000074c379ddea75  push rdx
000074c379ddea76  push rdi
000074c379ddea77  push rsi
000074c379ddea78  push r8
000074c379ddea7a  push r9
000074c379ddea7c  push r10
000074c379ddea7e  push r11
000074c379ddea80  sub rsp, 0xF0
000074c379ddea87  vmovaps [rsp], xmm0
000074c379ddea8c  vmovaps [rsp+0x10], xmm1
000074c379ddea92  vmovaps [rsp+0x20], xmm2
000074c379ddea98  vmovaps [rsp+0x30], xmm3
000074c379ddea9e  vmovaps [rsp+0x40], xmm4
000074c379ddeaa4  vmovaps [rsp+0x50], xmm5
000074c379ddeaaa  vmovaps [rsp+0x60], xmm6
000074c379ddeab0  vmovaps [rsp+0x70], xmm7
000074c379ddeab6  vmovaps [rsp+0x80], xmm8
000074c379ddeabf  vmovaps [rsp+0x90], xmm9
000074c379ddeac8  vmovaps [rsp+0xA0], xmm10
000074c379ddead1  vmovaps [rsp+0xB0], xmm11
000074c379ddeada  vmovaps [rsp+0xC0], xmm12
000074c379ddeae3  vmovaps [rsp+0xD0], xmm13
000074c379ddeaec  vmovaps [rsp+0xE0], xmm14
000074c379ddeaf5  sub rsp, 0x30
000074c379ddeaf9  movaps [rsp], xmm15
000074c379ddeafe  movaps [rsp+0x10], xmm14
000074c379ddeb04  movaps [rsp+0x20], xmm4
000074c379ddeb09  lea rdi, [rsp]
000074c379ddeb0d  mov esi, 0x00
000074c379ddeb12  mov rax, 0x56321ABA4530
000074c379ddeb1c  call rax
000074c379ddeb1e  movaps xmm15, [rsp]
000074c379ddeb23  add rsp, 0x30
000074c379ddeb27  vmovaps xmm0, [rsp]
000074c379ddeb2c  vmovaps xmm1, [rsp+0x10]
000074c379ddeb32  vmovaps xmm2, [rsp+0x20]
000074c379ddeb38  vmovaps xmm3, [rsp+0x30]
000074c379ddeb3e  vmovaps xmm4, [rsp+0x40]
000074c379ddeb44  vmovaps xmm5, [rsp+0x50]
000074c379ddeb4a  vmovaps xmm6, [rsp+0x60]
000074c379ddeb50  vmovaps xmm7, [rsp+0x70]
000074c379ddeb56  vmovaps xmm8, [rsp+0x80]
000074c379ddeb5f  vmovaps xmm9, [rsp+0x90]
000074c379ddeb68  vmovaps xmm10, [rsp+0xA0]
000074c379ddeb71  vmovaps xmm11, [rsp+0xB0]
000074c379ddeb7a  vmovaps xmm12, [rsp+0xC0]
000074c379ddeb83  vmovaps xmm13, [rsp+0xD0]
000074c379ddeb8c  vmovaps xmm14, [rsp+0xE0]
000074c379ddeb95  add rsp, 0xF0
000074c379ddeb9c  pop r11
000074c379ddeb9e  pop r10
000074c379ddeba0  pop r9
000074c379ddeba2  pop r8
000074c379ddeba4  pop rsi
000074c379ddeba5  pop rdi
000074c379ddeba6  pop rdx
000074c379ddeba7  pop rcx
000074c379ddeba8  pop rax
000074c379ddeba9  add rsp, 0x08
000074c379ddebad  jmp 0x000074C379DDC2AA
000074c379ddebb2  sub rsp, 0x08
000074c379ddebb6  push rax
000074c379ddebb7  push rcx
000074c379ddebb8  push rdx
000074c379ddebb9  push rdi
000074c379ddebba  push rsi
000074c379ddebbb  push r8
000074c379ddebbd  push r9
000074c379ddebbf  push r10
000074c379ddebc1  push r11
000074c379ddebc3  sub rsp, 0xF0
000074c379ddebca  vmovaps [rsp], xmm0
000074c379ddebcf  vmovaps [rsp+0x10], xmm1
000074c379ddebd5  vmovaps [rsp+0x20], xmm2
000074c379ddebdb  vmovaps [rsp+0x30], xmm3
000074c379ddebe1  vmovaps [rsp+0x40], xmm4
000074c379ddebe7  vmovaps [rsp+0x50], xmm5
000074c379ddebed  vmovaps [rsp+0x60], xmm6
000074c379ddebf3  vmovaps [rsp+0x70], xmm7
000074c379ddebf9  vmovaps [rsp+0x80], xmm8
000074c379ddec02  vmovaps [rsp+0x90], xmm9
000074c379ddec0b  vmovaps [rsp+0xA0], xmm10
000074c379ddec14  vmovaps [rsp+0xB0], xmm11
000074c379ddec1d  vmovaps [rsp+0xC0], xmm12
000074c379ddec26  vmovaps [rsp+0xD0], xmm13
000074c379ddec2f  vmovaps [rsp+0xE0], xmm15
000074c379ddec38  sub rsp, 0x30
000074c379ddec3c  movaps [rsp], xmm14
000074c379ddec41  movaps [rsp+0x10], xmm2
000074c379ddec46  movaps [rsp+0x20], xmm1
000074c379ddec4b  lea rdi, [rsp]
000074c379ddec4f  mov esi, 0x00
000074c379ddec54  mov rax, 0x56321ABA4530
000074c379ddec5e  call rax
000074c379ddec60  movaps xmm14, [rsp]
000074c379ddec65  add rsp, 0x30
000074c379ddec69  vmovaps xmm0, [rsp]
000074c379ddec6e  vmovaps xmm1, [rsp+0x10]
000074c379ddec74  vmovaps xmm2, [rsp+0x20]
000074c379ddec7a  vmovaps xmm3, [rsp+0x30]
000074c379ddec80  vmovaps xmm4, [rsp+0x40]
000074c379ddec86  vmovaps xmm5, [rsp+0x50]
000074c379ddec8c  vmovaps xmm6, [rsp+0x60]
000074c379ddec92  vmovaps xmm7, [rsp+0x70]
000074c379ddec98  vmovaps xmm8, [rsp+0x80]
000074c379ddeca1  vmovaps xmm9, [rsp+0x90]
000074c379ddecaa  vmovaps xmm10, [rsp+0xA0]
000074c379ddecb3  vmovaps xmm11, [rsp+0xB0]
000074c379ddecbc  vmovaps xmm12, [rsp+0xC0]
000074c379ddecc5  vmovaps xmm13, [rsp+0xD0]
000074c379ddecce  vmovaps xmm15, [rsp+0xE0]
000074c379ddecd7  add rsp, 0xF0
000074c379ddecde  pop r11
000074c379ddece0  pop r10
000074c379ddece2  pop r9
000074c379ddece4  pop r8
000074c379ddece6  pop rsi
000074c379ddece7  pop rdi
000074c379ddece8  pop rdx
000074c379ddece9  pop rcx
000074c379ddecea  pop rax
000074c379ddeceb  add rsp, 0x08
000074c379ddecef  jmp 0x000074C379DDC2D0
000074c379ddecf4  sub rsp, 0x08
000074c379ddecf8  push rax
000074c379ddecf9  push rcx
000074c379ddecfa  push rdx
000074c379ddecfb  push rdi
000074c379ddecfc  push rsi
000074c379ddecfd  push r8
000074c379ddecff  push r9
000074c379dded01  push r10
000074c379dded03  push r11
000074c379dded05  sub rsp, 0xF0
000074c379dded0c  vmovaps [rsp], xmm0
000074c379dded11  vmovaps [rsp+0x10], xmm2
000074c379dded17  vmovaps [rsp+0x20], xmm3
000074c379dded1d  vmovaps [rsp+0x30], xmm4
000074c379dded23  vmovaps [rsp+0x40], xmm5
000074c379dded29  vmovaps [rsp+0x50], xmm6
000074c379dded2f  vmovaps [rsp+0x60], xmm7
000074c379dded35  vmovaps [rsp+0x70], xmm8
000074c379dded3b  vmovaps [rsp+0x80], xmm9
000074c379dded44  vmovaps [rsp+0x90], xmm10
000074c379dded4d  vmovaps [rsp+0xA0], xmm11
000074c379dded56  vmovaps [rsp+0xB0], xmm12
000074c379dded5f  vmovaps [rsp+0xC0], xmm13
000074c379dded68  vmovaps [rsp+0xD0], xmm14
000074c379dded71  vmovaps [rsp+0xE0], xmm15
000074c379dded7a  sub rsp, 0x30
000074c379dded7e  movaps [rsp], xmm1
000074c379dded82  movaps [rsp+0x10], xmm4
000074c379dded87  movaps [rsp+0x20], xmm9
000074c379dded8d  lea rdi, [rsp]
000074c379dded91  mov esi, 0x00
000074c379dded96  mov rax, 0x56321ABA4530
000074c379ddeda0  call rax
000074c379ddeda2  movaps xmm1, [rsp]
000074c379ddeda6  add rsp, 0x30
000074c379ddedaa  vmovaps xmm0, [rsp]
000074c379ddedaf  vmovaps xmm2, [rsp+0x10]
000074c379ddedb5  vmovaps xmm3, [rsp+0x20]
000074c379ddedbb  vmovaps xmm4, [rsp+0x30]
000074c379ddedc1  vmovaps xmm5, [rsp+0x40]
000074c379ddedc7  vmovaps xmm6, [rsp+0x50]
000074c379ddedcd  vmovaps xmm7, [rsp+0x60]
000074c379ddedd3  vmovaps xmm8, [rsp+0x70]
000074c379ddedd9  vmovaps xmm9, [rsp+0x80]
000074c379ddede2  vmovaps xmm10, [rsp+0x90]
000074c379ddedeb  vmovaps xmm11, [rsp+0xA0]
000074c379ddedf4  vmovaps xmm12, [rsp+0xB0]
000074c379ddedfd  vmovaps xmm13, [rsp+0xC0]
000074c379ddee06  vmovaps xmm14, [rsp+0xD0]
000074c379ddee0f  vmovaps xmm15, [rsp+0xE0]
000074c379ddee18  add rsp, 0xF0
000074c379ddee1f  pop r11
000074c379ddee21  pop r10
000074c379ddee23  pop r9
000074c379ddee25  pop r8
000074c379ddee27  pop rsi
000074c379ddee28  pop rdi
000074c379ddee29  pop rdx
000074c379ddee2a  pop rcx
000074c379ddee2b  pop rax
000074c379ddee2c  add rsp, 0x08
000074c379ddee30  jmp 0x000074C379DDC2EE
000074c379ddee35  sub rsp, 0x08
000074c379ddee39  push rax
000074c379ddee3a  push rcx
000074c379ddee3b  push rdx
000074c379ddee3c  push rdi
000074c379ddee3d  push rsi
000074c379ddee3e  push r8
000074c379ddee40  push r9
000074c379ddee42  push r10
000074c379ddee44  push r11
000074c379ddee46  sub rsp, 0xF0
000074c379ddee4d  vmovaps [rsp], xmm0
000074c379ddee52  vmovaps [rsp+0x10], xmm1
000074c379ddee58  vmovaps [rsp+0x20], xmm2
000074c379ddee5e  vmovaps [rsp+0x30], xmm3
000074c379ddee64  vmovaps [rsp+0x40], xmm5
000074c379ddee6a  vmovaps [rsp+0x50], xmm6
000074c379ddee70  vmovaps [rsp+0x60], xmm7
000074c379ddee76  vmovaps [rsp+0x70], xmm8
000074c379ddee7c  vmovaps [rsp+0x80], xmm9
000074c379ddee85  vmovaps [rsp+0x90], xmm10
000074c379ddee8e  vmovaps [rsp+0xA0], xmm11
000074c379ddee97  vmovaps [rsp+0xB0], xmm12
000074c379ddeea0  vmovaps [rsp+0xC0], xmm13
000074c379ddeea9  vmovaps [rsp+0xD0], xmm14
000074c379ddeeb2  vmovaps [rsp+0xE0], xmm15
000074c379ddeebb  sub rsp, 0x30
000074c379ddeebf  movaps [rsp], xmm4
000074c379ddeec3  movaps [rsp+0x10], xmm2
000074c379ddeec8  movaps [rsp+0x20], xmm9
000074c379ddeece  lea rdi, [rsp]
000074c379ddeed2  mov esi, 0x00
000074c379ddeed7  mov rax, 0x56321ABA4530
000074c379ddeee1  call rax
000074c379ddeee3  movaps xmm4, [rsp]
000074c379ddeee7  add rsp, 0x30
000074c379ddeeeb  vmovaps xmm0, [rsp]
000074c379ddeef0  vmovaps xmm1, [rsp+0x10]
000074c379ddeef6  vmovaps xmm2, [rsp+0x20]
000074c379ddeefc  vmovaps xmm3, [rsp+0x30]
000074c379ddef02  vmovaps xmm5, [rsp+0x40]
000074c379ddef08  vmovaps xmm6, [rsp+0x50]
000074c379ddef0e  vmovaps xmm7, [rsp+0x60]
000074c379ddef14  vmovaps xmm8, [rsp+0x70]
000074c379ddef1a  vmovaps xmm9, [rsp+0x80]
000074c379ddef23  vmovaps xmm10, [rsp+0x90]
000074c379ddef2c  vmovaps xmm11, [rsp+0xA0]
000074c379ddef35  vmovaps xmm12, [rsp+0xB0]
000074c379ddef3e  vmovaps xmm13, [rsp+0xC0]
000074c379ddef47  vmovaps xmm14, [rsp+0xD0]
000074c379ddef50  vmovaps xmm15, [rsp+0xE0]
000074c379ddef59  add rsp, 0xF0
000074c379ddef60  pop r11
000074c379ddef62  pop r10
000074c379ddef64  pop r9
000074c379ddef66  pop r8
000074c379ddef68  pop rsi
000074c379ddef69  pop rdi
000074c379ddef6a  pop rdx
000074c379ddef6b  pop rcx
000074c379ddef6c  pop rax
000074c379ddef6d  add rsp, 0x08
000074c379ddef71  jmp 0x000074C379DDC31E
000074c379ddef76  sub rsp, 0x08
000074c379ddef7a  push rax
000074c379ddef7b  push rcx
000074c379ddef7c  push rdx
000074c379ddef7d  push rdi
000074c379ddef7e  push rsi
000074c379ddef7f  push r8
000074c379ddef81  push r9
000074c379ddef83  push r10
000074c379ddef85  push r11
000074c379ddef87  sub rsp, 0xF0
000074c379ddef8e  vmovaps [rsp], xmm0
000074c379ddef93  vmovaps [rsp+0x10], xmm1
000074c379ddef99  vmovaps [rsp+0x20], xmm2
000074c379ddef9f  vmovaps [rsp+0x30], xmm3
000074c379ddefa5  vmovaps [rsp+0x40], xmm4
000074c379ddefab  vmovaps [rsp+0x50], xmm5
000074c379ddefb1  vmovaps [rsp+0x60], xmm6
000074c379ddefb7  vmovaps [rsp+0x70], xmm7
000074c379ddefbd  vmovaps [rsp+0x80], xmm8
000074c379ddefc6  vmovaps [rsp+0x90], xmm10
000074c379ddefcf  vmovaps [rsp+0xA0], xmm11
000074c379ddefd8  vmovaps [rsp+0xB0], xmm12
000074c379ddefe1  vmovaps [rsp+0xC0], xmm13
000074c379ddefea  vmovaps [rsp+0xD0], xmm14
000074c379ddeff3  vmovaps [rsp+0xE0], xmm15
000074c379ddeffc  sub rsp, 0x30
000074c379ddf000  movaps [rsp], xmm9
000074c379ddf005  movaps [rsp+0x10], xmm2
000074c379ddf00a  movaps [rsp+0x20], xmm1
000074c379ddf00f  lea rdi, [rsp]
000074c379ddf013  mov esi, 0x00
000074c379ddf018  mov rax, 0x56321ABA4530
000074c379ddf022  call rax
000074c379ddf024  movaps xmm9, [rsp]
000074c379ddf029  add rsp, 0x30
000074c379ddf02d  vmovaps xmm0, [rsp]
000074c379ddf032  vmovaps xmm1, [rsp+0x10]
000074c379ddf038  vmovaps xmm2, [rsp+0x20]
000074c379ddf03e  vmovaps xmm3, [rsp+0x30]
000074c379ddf044  vmovaps xmm4, [rsp+0x40]
000074c379ddf04a  vmovaps xmm5, [rsp+0x50]
000074c379ddf050  vmovaps xmm6, [rsp+0x60]
000074c379ddf056  vmovaps xmm7, [rsp+0x70]
000074c379ddf05c  vmovaps xmm8, [rsp+0x80]
000074c379ddf065  vmovaps xmm10, [rsp+0x90]
000074c379ddf06e  vmovaps xmm11, [rsp+0xA0]
000074c379ddf077  vmovaps xmm12, [rsp+0xB0]
000074c379ddf080  vmovaps xmm13, [rsp+0xC0]
000074c379ddf089  vmovaps xmm14, [rsp+0xD0]
000074c379ddf092  vmovaps xmm15, [rsp+0xE0]
000074c379ddf09b  add rsp, 0xF0
000074c379ddf0a2  pop r11
000074c379ddf0a4  pop r10
000074c379ddf0a6  pop r9
000074c379ddf0a8  pop r8
000074c379ddf0aa  pop rsi
000074c379ddf0ab  pop rdi
000074c379ddf0ac  pop rdx
000074c379ddf0ad  pop rcx
000074c379ddf0ae  pop rax
000074c379ddf0af  add rsp, 0x08
000074c379ddf0b3  jmp 0x000074C379DDC354
000074c379ddf0b8  sub rsp, 0x08
000074c379ddf0bc  push rax
000074c379ddf0bd  push rcx
000074c379ddf0be  push rdx
000074c379ddf0bf  push rdi
000074c379ddf0c0  push rsi
000074c379ddf0c1  push r8
000074c379ddf0c3  push r9
000074c379ddf0c5  push r10
000074c379ddf0c7  push r11
000074c379ddf0c9  sub rsp, 0xF0
000074c379ddf0d0  vmovaps [rsp], xmm0
000074c379ddf0d5  vmovaps [rsp+0x10], xmm2
000074c379ddf0db  vmovaps [rsp+0x20], xmm3
000074c379ddf0e1  vmovaps [rsp+0x30], xmm4
000074c379ddf0e7  vmovaps [rsp+0x40], xmm5
000074c379ddf0ed  vmovaps [rsp+0x50], xmm6
000074c379ddf0f3  vmovaps [rsp+0x60], xmm7
000074c379ddf0f9  vmovaps [rsp+0x70], xmm8
000074c379ddf0ff  vmovaps [rsp+0x80], xmm9
000074c379ddf108  vmovaps [rsp+0x90], xmm10
000074c379ddf111  vmovaps [rsp+0xA0], xmm11
000074c379ddf11a  vmovaps [rsp+0xB0], xmm12
000074c379ddf123  vmovaps [rsp+0xC0], xmm13
000074c379ddf12c  vmovaps [rsp+0xD0], xmm14
000074c379ddf135  vmovaps [rsp+0xE0], xmm15
000074c379ddf13e  sub rsp, 0x30
000074c379ddf142  movaps [rsp], xmm1
000074c379ddf146  movaps [rsp+0x10], xmm15
000074c379ddf14c  movaps [rsp+0x20], xmm6
000074c379ddf151  lea rdi, [rsp]
000074c379ddf155  mov esi, 0x00
000074c379ddf15a  mov rax, 0x56321ABA4530
000074c379ddf164  call rax
000074c379ddf166  movaps xmm1, [rsp]
000074c379ddf16a  add rsp, 0x30
000074c379ddf16e  vmovaps xmm0, [rsp]
000074c379ddf173  vmovaps xmm2, [rsp+0x10]
000074c379ddf179  vmovaps xmm3, [rsp+0x20]
000074c379ddf17f  vmovaps xmm4, [rsp+0x30]
000074c379ddf185  vmovaps xmm5, [rsp+0x40]
000074c379ddf18b  vmovaps xmm6, [rsp+0x50]
000074c379ddf191  vmovaps xmm7, [rsp+0x60]
000074c379ddf197  vmovaps xmm8, [rsp+0x70]
000074c379ddf19d  vmovaps xmm9, [rsp+0x80]
000074c379ddf1a6  vmovaps xmm10, [rsp+0x90]
000074c379ddf1af  vmovaps xmm11, [rsp+0xA0]
000074c379ddf1b8  vmovaps xmm12, [rsp+0xB0]
000074c379ddf1c1  vmovaps xmm13, [rsp+0xC0]
000074c379ddf1ca  vmovaps xmm14, [rsp+0xD0]
000074c379ddf1d3  vmovaps xmm15, [rsp+0xE0]
000074c379ddf1dc  add rsp, 0xF0
000074c379ddf1e3  pop r11
000074c379ddf1e5  pop r10
000074c379ddf1e7  pop r9
000074c379ddf1e9  pop r8
000074c379ddf1eb  pop rsi
000074c379ddf1ec  pop rdi
000074c379ddf1ed  pop rdx
000074c379ddf1ee  pop rcx
000074c379ddf1ef  pop rax
000074c379ddf1f0  add rsp, 0x08
000074c379ddf1f4  jmp 0x000074C379DDC375
000074c379ddf1f9  sub rsp, 0x08
000074c379ddf1fd  push rax
000074c379ddf1fe  push rcx
000074c379ddf1ff  push rdx
000074c379ddf200  push rdi
000074c379ddf201  push rsi
000074c379ddf202  push r8
000074c379ddf204  push r9
000074c379ddf206  push r10
000074c379ddf208  push r11
000074c379ddf20a  sub rsp, 0xF0
000074c379ddf211  vmovaps [rsp], xmm0
000074c379ddf216  vmovaps [rsp+0x10], xmm1
000074c379ddf21c  vmovaps [rsp+0x20], xmm2
000074c379ddf222  vmovaps [rsp+0x30], xmm3
000074c379ddf228  vmovaps [rsp+0x40], xmm4
000074c379ddf22e  vmovaps [rsp+0x50], xmm5
000074c379ddf234  vmovaps [rsp+0x60], xmm6
000074c379ddf23a  vmovaps [rsp+0x70], xmm7
000074c379ddf240  vmovaps [rsp+0x80], xmm8
000074c379ddf249  vmovaps [rsp+0x90], xmm9
000074c379ddf252  vmovaps [rsp+0xA0], xmm10
000074c379ddf25b  vmovaps [rsp+0xB0], xmm11
000074c379ddf264  vmovaps [rsp+0xC0], xmm12
000074c379ddf26d  vmovaps [rsp+0xD0], xmm13
000074c379ddf276  vmovaps [rsp+0xE0], xmm14
000074c379ddf27f  sub rsp, 0x30
000074c379ddf283  movaps [rsp], xmm15
000074c379ddf288  movaps [rsp+0x10], xmm5
000074c379ddf28d  movaps [rsp+0x20], xmm3
000074c379ddf292  lea rdi, [rsp]
000074c379ddf296  mov esi, 0x00
000074c379ddf29b  mov rax, 0x56321ABA4530
000074c379ddf2a5  call rax
000074c379ddf2a7  movaps xmm15, [rsp]
000074c379ddf2ac  add rsp, 0x30
000074c379ddf2b0  vmovaps xmm0, [rsp]
000074c379ddf2b5  vmovaps xmm1, [rsp+0x10]
000074c379ddf2bb  vmovaps xmm2, [rsp+0x20]
000074c379ddf2c1  vmovaps xmm3, [rsp+0x30]
000074c379ddf2c7  vmovaps xmm4, [rsp+0x40]
000074c379ddf2cd  vmovaps xmm5, [rsp+0x50]
000074c379ddf2d3  vmovaps xmm6, [rsp+0x60]
000074c379ddf2d9  vmovaps xmm7, [rsp+0x70]
000074c379ddf2df  vmovaps xmm8, [rsp+0x80]
000074c379ddf2e8  vmovaps xmm9, [rsp+0x90]
000074c379ddf2f1  vmovaps xmm10, [rsp+0xA0]
000074c379ddf2fa  vmovaps xmm11, [rsp+0xB0]
000074c379ddf303  vmovaps xmm12, [rsp+0xC0]
000074c379ddf30c  vmovaps xmm13, [rsp+0xD0]
000074c379ddf315  vmovaps xmm14, [rsp+0xE0]
000074c379ddf31e  add rsp, 0xF0
000074c379ddf325  pop r11
000074c379ddf327  pop r10
000074c379ddf329  pop r9
000074c379ddf32b  pop r8
000074c379ddf32d  pop rsi
000074c379ddf32e  pop rdi
000074c379ddf32f  pop rdx
000074c379ddf330  pop rcx
000074c379ddf331  pop rax
000074c379ddf332  add rsp, 0x08
000074c379ddf336  jmp 0x000074C379DDC38F
000074c379ddf33b  sub rsp, 0x08
000074c379ddf33f  push rax
000074c379ddf340  push rcx
000074c379ddf341  push rdx
000074c379ddf342  push rdi
000074c379ddf343  push rsi
000074c379ddf344  push r8
000074c379ddf346  push r9
000074c379ddf348  push r10
000074c379ddf34a  push r11
000074c379ddf34c  sub rsp, 0xF0
000074c379ddf353  vmovaps [rsp], xmm0
000074c379ddf358  vmovaps [rsp+0x10], xmm1
000074c379ddf35e  vmovaps [rsp+0x20], xmm2
000074c379ddf364  vmovaps [rsp+0x30], xmm3
000074c379ddf36a  vmovaps [rsp+0x40], xmm4
000074c379ddf370  vmovaps [rsp+0x50], xmm6
000074c379ddf376  vmovaps [rsp+0x60], xmm7
000074c379ddf37c  vmovaps [rsp+0x70], xmm8
000074c379ddf382  vmovaps [rsp+0x80], xmm9
000074c379ddf38b  vmovaps [rsp+0x90], xmm10
000074c379ddf394  vmovaps [rsp+0xA0], xmm11
000074c379ddf39d  vmovaps [rsp+0xB0], xmm12
000074c379ddf3a6  vmovaps [rsp+0xC0], xmm13
000074c379ddf3af  vmovaps [rsp+0xD0], xmm14
000074c379ddf3b8  vmovaps [rsp+0xE0], xmm15
000074c379ddf3c1  sub rsp, 0x30
000074c379ddf3c5  movaps [rsp], xmm5
000074c379ddf3c9  movaps [rsp+0x10], xmm8
000074c379ddf3cf  movaps [rsp+0x20], xmm6
000074c379ddf3d4  lea rdi, [rsp]
000074c379ddf3d8  mov esi, 0x00
000074c379ddf3dd  mov rax, 0x56321ABA4530
000074c379ddf3e7  call rax
000074c379ddf3e9  movaps xmm5, [rsp]
000074c379ddf3ed  add rsp, 0x30
000074c379ddf3f1  vmovaps xmm0, [rsp]
000074c379ddf3f6  vmovaps xmm1, [rsp+0x10]
000074c379ddf3fc  vmovaps xmm2, [rsp+0x20]
000074c379ddf402  vmovaps xmm3, [rsp+0x30]
000074c379ddf408  vmovaps xmm4, [rsp+0x40]
000074c379ddf40e  vmovaps xmm6, [rsp+0x50]
000074c379ddf414  vmovaps xmm7, [rsp+0x60]
000074c379ddf41a  vmovaps xmm8, [rsp+0x70]
000074c379ddf420  vmovaps xmm9, [rsp+0x80]
000074c379ddf429  vmovaps xmm10, [rsp+0x90]
000074c379ddf432  vmovaps xmm11, [rsp+0xA0]
000074c379ddf43b  vmovaps xmm12, [rsp+0xB0]
000074c379ddf444  vmovaps xmm13, [rsp+0xC0]
000074c379ddf44d  vmovaps xmm14, [rsp+0xD0]
000074c379ddf456  vmovaps xmm15, [rsp+0xE0]
000074c379ddf45f  add rsp, 0xF0
000074c379ddf466  pop r11
000074c379ddf468  pop r10
000074c379ddf46a  pop r9
000074c379ddf46c  pop r8
000074c379ddf46e  pop rsi
000074c379ddf46f  pop rdi
000074c379ddf470  pop rdx
000074c379ddf471  pop rcx
000074c379ddf472  pop rax
000074c379ddf473  add rsp, 0x08
000074c379ddf477  jmp 0x000074C379DDC3B3
000074c379ddf47c  sub rsp, 0x08
000074c379ddf480  push rax
000074c379ddf481  push rcx
000074c379ddf482  push rdx
000074c379ddf483  push rdi
000074c379ddf484  push rsi
000074c379ddf485  push r8
000074c379ddf487  push r9
000074c379ddf489  push r10
000074c379ddf48b  push r11
000074c379ddf48d  sub rsp, 0xF0
000074c379ddf494  vmovaps [rsp], xmm0
000074c379ddf499  vmovaps [rsp+0x10], xmm1
000074c379ddf49f  vmovaps [rsp+0x20], xmm2
000074c379ddf4a5  vmovaps [rsp+0x30], xmm3
000074c379ddf4ab  vmovaps [rsp+0x40], xmm4
000074c379ddf4b1  vmovaps [rsp+0x50], xmm5
000074c379ddf4b7  vmovaps [rsp+0x60], xmm7
000074c379ddf4bd  vmovaps [rsp+0x70], xmm8
000074c379ddf4c3  vmovaps [rsp+0x80], xmm9
000074c379ddf4cc  vmovaps [rsp+0x90], xmm10
000074c379ddf4d5  vmovaps [rsp+0xA0], xmm11
000074c379ddf4de  vmovaps [rsp+0xB0], xmm12
000074c379ddf4e7  vmovaps [rsp+0xC0], xmm13
000074c379ddf4f0  vmovaps [rsp+0xD0], xmm14
000074c379ddf4f9  vmovaps [rsp+0xE0], xmm15
000074c379ddf502  sub rsp, 0x30
000074c379ddf506  movaps [rsp], xmm6
000074c379ddf50a  movaps [rsp+0x10], xmm10
000074c379ddf510  movaps [rsp+0x20], xmm8
000074c379ddf516  lea rdi, [rsp]
000074c379ddf51a  mov esi, 0x00
000074c379ddf51f  mov rax, 0x56321ABA4530
000074c379ddf529  call rax
000074c379ddf52b  movaps xmm6, [rsp]
000074c379ddf52f  add rsp, 0x30
000074c379ddf533  vmovaps xmm0, [rsp]
000074c379ddf538  vmovaps xmm1, [rsp+0x10]
000074c379ddf53e  vmovaps xmm2, [rsp+0x20]
000074c379ddf544  vmovaps xmm3, [rsp+0x30]
000074c379ddf54a  vmovaps xmm4, [rsp+0x40]
000074c379ddf550  vmovaps xmm5, [rsp+0x50]
000074c379ddf556  vmovaps xmm7, [rsp+0x60]
000074c379ddf55c  vmovaps xmm8, [rsp+0x70]
000074c379ddf562  vmovaps xmm9, [rsp+0x80]
000074c379ddf56b  vmovaps xmm10, [rsp+0x90]
000074c379ddf574  vmovaps xmm11, [rsp+0xA0]
000074c379ddf57d  vmovaps xmm12, [rsp+0xB0]
000074c379ddf586  vmovaps xmm13, [rsp+0xC0]
000074c379ddf58f  vmovaps xmm14, [rsp+0xD0]
000074c379ddf598  vmovaps xmm15, [rsp+0xE0]
000074c379ddf5a1  add rsp, 0xF0
000074c379ddf5a8  pop r11
000074c379ddf5aa  pop r10
000074c379ddf5ac  pop r9
000074c379ddf5ae  pop r8
000074c379ddf5b0  pop rsi
000074c379ddf5b1  pop rdi
000074c379ddf5b2  pop rdx
000074c379ddf5b3  pop rcx
000074c379ddf5b4  pop rax
000074c379ddf5b5  add rsp, 0x08
000074c379ddf5b9  jmp 0x000074C379DDC3D8
000074c379ddf5be  sub rsp, 0x08
000074c379ddf5c2  push rax
000074c379ddf5c3  push rcx
000074c379ddf5c4  push rdx
000074c379ddf5c5  push rdi
000074c379ddf5c6  push rsi
000074c379ddf5c7  push r8
000074c379ddf5c9  push r9
000074c379ddf5cb  push r10
000074c379ddf5cd  push r11
000074c379ddf5cf  sub rsp, 0xF0
000074c379ddf5d6  vmovaps [rsp], xmm0
000074c379ddf5db  vmovaps [rsp+0x10], xmm1
000074c379ddf5e1  vmovaps [rsp+0x20], xmm2
000074c379ddf5e7  vmovaps [rsp+0x30], xmm3
000074c379ddf5ed  vmovaps [rsp+0x40], xmm4
000074c379ddf5f3  vmovaps [rsp+0x50], xmm5
000074c379ddf5f9  vmovaps [rsp+0x60], xmm6
000074c379ddf5ff  vmovaps [rsp+0x70], xmm7
000074c379ddf605  vmovaps [rsp+0x80], xmm8
000074c379ddf60e  vmovaps [rsp+0x90], xmm9
000074c379ddf617  vmovaps [rsp+0xA0], xmm11
000074c379ddf620  vmovaps [rsp+0xB0], xmm12
000074c379ddf629  vmovaps [rsp+0xC0], xmm13
000074c379ddf632  vmovaps [rsp+0xD0], xmm14
000074c379ddf63b  vmovaps [rsp+0xE0], xmm15
000074c379ddf644  sub rsp, 0x30
000074c379ddf648  movaps [rsp], xmm10
000074c379ddf64d  movaps [rsp+0x10], xmm8
000074c379ddf653  movaps [rsp+0x20], xmm14
000074c379ddf659  lea rdi, [rsp]
000074c379ddf65d  mov esi, 0x00
000074c379ddf662  mov rax, 0x56321ABA4530
000074c379ddf66c  call rax
000074c379ddf66e  movaps xmm10, [rsp]
000074c379ddf673  add rsp, 0x30
000074c379ddf677  vmovaps xmm0, [rsp]
000074c379ddf67c  vmovaps xmm1, [rsp+0x10]
000074c379ddf682  vmovaps xmm2, [rsp+0x20]
000074c379ddf688  vmovaps xmm3, [rsp+0x30]
000074c379ddf68e  vmovaps xmm4, [rsp+0x40]
000074c379ddf694  vmovaps xmm5, [rsp+0x50]
000074c379ddf69a  vmovaps xmm6, [rsp+0x60]
000074c379ddf6a0  vmovaps xmm7, [rsp+0x70]
000074c379ddf6a6  vmovaps xmm8, [rsp+0x80]
000074c379ddf6af  vmovaps xmm9, [rsp+0x90]
000074c379ddf6b8  vmovaps xmm11, [rsp+0xA0]
000074c379ddf6c1  vmovaps xmm12, [rsp+0xB0]
000074c379ddf6ca  vmovaps xmm13, [rsp+0xC0]
000074c379ddf6d3  vmovaps xmm14, [rsp+0xD0]
000074c379ddf6dc  vmovaps xmm15, [rsp+0xE0]
000074c379ddf6e5  add rsp, 0xF0
000074c379ddf6ec  pop r11
000074c379ddf6ee  pop r10
000074c379ddf6f0  pop r9
000074c379ddf6f2  pop r8
000074c379ddf6f4  pop rsi
000074c379ddf6f5  pop rdi
000074c379ddf6f6  pop rdx
000074c379ddf6f7  pop rcx
000074c379ddf6f8  pop rax
000074c379ddf6f9  add rsp, 0x08
000074c379ddf6fd  jmp 0x000074C379DDC3F8
000074c379ddf702  sub rsp, 0x08
000074c379ddf706  push rax
000074c379ddf707  push rcx
000074c379ddf708  push rdx
000074c379ddf709  push rdi
000074c379ddf70a  push rsi
000074c379ddf70b  push r8
000074c379ddf70d  push r9
000074c379ddf70f  push r10
000074c379ddf711  push r11
000074c379ddf713  sub rsp, 0xF0
000074c379ddf71a  vmovaps [rsp], xmm0
000074c379ddf71f  vmovaps [rsp+0x10], xmm1
000074c379ddf725  vmovaps [rsp+0x20], xmm2
000074c379ddf72b  vmovaps [rsp+0x30], xmm3
000074c379ddf731  vmovaps [rsp+0x40], xmm4
000074c379ddf737  vmovaps [rsp+0x50], xmm5
000074c379ddf73d  vmovaps [rsp+0x60], xmm6
000074c379ddf743  vmovaps [rsp+0x70], xmm7
000074c379ddf749  vmovaps [rsp+0x80], xmm8
000074c379ddf752  vmovaps [rsp+0x90], xmm9
000074c379ddf75b  vmovaps [rsp+0xA0], xmm10
000074c379ddf764  vmovaps [rsp+0xB0], xmm11
000074c379ddf76d  vmovaps [rsp+0xC0], xmm12
000074c379ddf776  vmovaps [rsp+0xD0], xmm13
000074c379ddf77f  vmovaps [rsp+0xE0], xmm15
000074c379ddf788  sub rsp, 0x30
000074c379ddf78c  movaps [rsp], xmm14
000074c379ddf791  movaps [rsp+0x10], xmm8
000074c379ddf797  movaps [rsp+0x20], xmm4
000074c379ddf79c  lea rdi, [rsp]
000074c379ddf7a0  mov esi, 0x00
000074c379ddf7a5  mov rax, 0x56321ABA4530
000074c379ddf7af  call rax
000074c379ddf7b1  movaps xmm14, [rsp]
000074c379ddf7b6  add rsp, 0x30
000074c379ddf7ba  vmovaps xmm0, [rsp]
000074c379ddf7bf  vmovaps xmm1, [rsp+0x10]
000074c379ddf7c5  vmovaps xmm2, [rsp+0x20]
000074c379ddf7cb  vmovaps xmm3, [rsp+0x30]
000074c379ddf7d1  vmovaps xmm4, [rsp+0x40]
000074c379ddf7d7  vmovaps xmm5, [rsp+0x50]
000074c379ddf7dd  vmovaps xmm6, [rsp+0x60]
000074c379ddf7e3  vmovaps xmm7, [rsp+0x70]
000074c379ddf7e9  vmovaps xmm8, [rsp+0x80]
000074c379ddf7f2  vmovaps xmm9, [rsp+0x90]
000074c379ddf7fb  vmovaps xmm10, [rsp+0xA0]
000074c379ddf804  vmovaps xmm11, [rsp+0xB0]
000074c379ddf80d  vmovaps xmm12, [rsp+0xC0]
000074c379ddf816  vmovaps xmm13, [rsp+0xD0]
000074c379ddf81f  vmovaps xmm15, [rsp+0xE0]
000074c379ddf828  add rsp, 0xF0
000074c379ddf82f  pop r11
000074c379ddf831  pop r10
000074c379ddf833  pop r9
000074c379ddf835  pop r8
000074c379ddf837  pop rsi
000074c379ddf838  pop rdi
000074c379ddf839  pop rdx
000074c379ddf83a  pop rcx
000074c379ddf83b  pop rax
000074c379ddf83c  add rsp, 0x08
000074c379ddf840  jmp 0x000074C379DDC418
000074c379ddf845  sub rsp, 0x08
000074c379ddf849  push rax
000074c379ddf84a  push rcx
000074c379ddf84b  push rdx
000074c379ddf84c  push rdi
000074c379ddf84d  push rsi
000074c379ddf84e  push r8
000074c379ddf850  push r9
000074c379ddf852  push r10
000074c379ddf854  push r11
000074c379ddf856  sub rsp, 0xF0
000074c379ddf85d  vmovaps [rsp], xmm0
000074c379ddf862  vmovaps [rsp+0x10], xmm1
000074c379ddf868  vmovaps [rsp+0x20], xmm2
000074c379ddf86e  vmovaps [rsp+0x30], xmm3
000074c379ddf874  vmovaps [rsp+0x40], xmm5
000074c379ddf87a  vmovaps [rsp+0x50], xmm6
000074c379ddf880  vmovaps [rsp+0x60], xmm7
000074c379ddf886  vmovaps [rsp+0x70], xmm8
000074c379ddf88c  vmovaps [rsp+0x80], xmm9
000074c379ddf895  vmovaps [rsp+0x90], xmm10
000074c379ddf89e  vmovaps [rsp+0xA0], xmm11
000074c379ddf8a7  vmovaps [rsp+0xB0], xmm12
000074c379ddf8b0  vmovaps [rsp+0xC0], xmm13
000074c379ddf8b9  vmovaps [rsp+0xD0], xmm14
000074c379ddf8c2  vmovaps [rsp+0xE0], xmm15
000074c379ddf8cb  sub rsp, 0x30
000074c379ddf8cf  movaps [rsp], xmm4
000074c379ddf8d3  movaps [rsp+0x10], xmm13
000074c379ddf8d9  movaps [rsp+0x20], xmm8
000074c379ddf8df  lea rdi, [rsp]
000074c379ddf8e3  mov esi, 0x00
000074c379ddf8e8  mov rax, 0x56321ABA4530
000074c379ddf8f2  call rax
000074c379ddf8f4  movaps xmm4, [rsp]
000074c379ddf8f8  add rsp, 0x30
000074c379ddf8fc  vmovaps xmm0, [rsp]
000074c379ddf901  vmovaps xmm1, [rsp+0x10]
000074c379ddf907  vmovaps xmm2, [rsp+0x20]
000074c379ddf90d  vmovaps xmm3, [rsp+0x30]
000074c379ddf913  vmovaps xmm5, [rsp+0x40]
000074c379ddf919  vmovaps xmm6, [rsp+0x50]
000074c379ddf91f  vmovaps xmm7, [rsp+0x60]
000074c379ddf925  vmovaps xmm8, [rsp+0x70]
000074c379ddf92b  vmovaps xmm9, [rsp+0x80]
000074c379ddf934  vmovaps xmm10, [rsp+0x90]
000074c379ddf93d  vmovaps xmm11, [rsp+0xA0]
000074c379ddf946  vmovaps xmm12, [rsp+0xB0]
000074c379ddf94f  vmovaps xmm13, [rsp+0xC0]
000074c379ddf958  vmovaps xmm14, [rsp+0xD0]
000074c379ddf961  vmovaps xmm15, [rsp+0xE0]
000074c379ddf96a  add rsp, 0xF0
000074c379ddf971  pop r11
000074c379ddf973  pop r10
000074c379ddf975  pop r9
000074c379ddf977  pop r8
000074c379ddf979  pop rsi
000074c379ddf97a  pop rdi
000074c379ddf97b  pop rdx
000074c379ddf97c  pop rcx
000074c379ddf97d  pop rax
000074c379ddf97e  add rsp, 0x08
000074c379ddf982  jmp 0x000074C379DDC43D
000074c379ddf987  sub rsp, 0x08
000074c379ddf98b  push rax
000074c379ddf98c  push rcx
000074c379ddf98d  push rdx
000074c379ddf98e  push rdi
000074c379ddf98f  push rsi
000074c379ddf990  push r8
000074c379ddf992  push r9
000074c379ddf994  push r10
000074c379ddf996  push r11
000074c379ddf998  sub rsp, 0xF0
000074c379ddf99f  vmovaps [rsp], xmm0
000074c379ddf9a4  vmovaps [rsp+0x10], xmm1
000074c379ddf9aa  vmovaps [rsp+0x20], xmm2
000074c379ddf9b0  vmovaps [rsp+0x30], xmm3
000074c379ddf9b6  vmovaps [rsp+0x40], xmm4
000074c379ddf9bc  vmovaps [rsp+0x50], xmm5
000074c379ddf9c2  vmovaps [rsp+0x60], xmm6
000074c379ddf9c8  vmovaps [rsp+0x70], xmm7
000074c379ddf9ce  vmovaps [rsp+0x80], xmm8
000074c379ddf9d7  vmovaps [rsp+0x90], xmm9
000074c379ddf9e0  vmovaps [rsp+0xA0], xmm10
000074c379ddf9e9  vmovaps [rsp+0xB0], xmm11
000074c379ddf9f2  vmovaps [rsp+0xC0], xmm12
000074c379ddf9fb  vmovaps [rsp+0xD0], xmm14
000074c379ddfa04  vmovaps [rsp+0xE0], xmm15
000074c379ddfa0d  sub rsp, 0x30
000074c379ddfa11  movaps [rsp], xmm13
000074c379ddfa16  movaps [rsp+0x10], xmm15
000074c379ddfa1c  movaps [rsp+0x20], xmm9
000074c379ddfa22  lea rdi, [rsp]
000074c379ddfa26  mov esi, 0x00
000074c379ddfa2b  mov rax, 0x56321ABA4530
000074c379ddfa35  call rax
000074c379ddfa37  movaps xmm13, [rsp]
000074c379ddfa3c  add rsp, 0x30
000074c379ddfa40  vmovaps xmm0, [rsp]
000074c379ddfa45  vmovaps xmm1, [rsp+0x10]
000074c379ddfa4b  vmovaps xmm2, [rsp+0x20]
000074c379ddfa51  vmovaps xmm3, [rsp+0x30]
000074c379ddfa57  vmovaps xmm4, [rsp+0x40]
000074c379ddfa5d  vmovaps xmm5, [rsp+0x50]
000074c379ddfa63  vmovaps xmm6, [rsp+0x60]
000074c379ddfa69  vmovaps xmm7, [rsp+0x70]
000074c379ddfa6f  vmovaps xmm8, [rsp+0x80]
000074c379ddfa78  vmovaps xmm9, [rsp+0x90]
000074c379ddfa81  vmovaps xmm10, [rsp+0xA0]
000074c379ddfa8a  vmovaps xmm11, [rsp+0xB0]
000074c379ddfa93  vmovaps xmm12, [rsp+0xC0]
000074c379ddfa9c  vmovaps xmm14, [rsp+0xD0]
000074c379ddfaa5  vmovaps xmm15, [rsp+0xE0]
000074c379ddfaae  add rsp, 0xF0
000074c379ddfab5  pop r11
000074c379ddfab7  pop r10
000074c379ddfab9  pop r9
000074c379ddfabb  pop r8
000074c379ddfabd  pop rsi
000074c379ddfabe  pop rdi
000074c379ddfabf  pop rdx
000074c379ddfac0  pop rcx
000074c379ddfac1  pop rax
000074c379ddfac2  add rsp, 0x08
000074c379ddfac6  jmp 0x000074C379DDC458
000074c379ddfacb  sub rsp, 0x08
000074c379ddfacf  push rax
000074c379ddfad0  push rcx
000074c379ddfad1  push rdx
000074c379ddfad2  push rdi
000074c379ddfad3  push rsi
000074c379ddfad4  push r8
000074c379ddfad6  push r9
000074c379ddfad8  push r10
000074c379ddfada  push r11
000074c379ddfadc  sub rsp, 0xF0
000074c379ddfae3  vmovaps [rsp], xmm0
000074c379ddfae8  vmovaps [rsp+0x10], xmm1
000074c379ddfaee  vmovaps [rsp+0x20], xmm2
000074c379ddfaf4  vmovaps [rsp+0x30], xmm3
000074c379ddfafa  vmovaps [rsp+0x40], xmm4
000074c379ddfb00  vmovaps [rsp+0x50], xmm5
000074c379ddfb06  vmovaps [rsp+0x60], xmm6
000074c379ddfb0c  vmovaps [rsp+0x70], xmm7
000074c379ddfb12  vmovaps [rsp+0x80], xmm8
000074c379ddfb1b  vmovaps [rsp+0x90], xmm9
000074c379ddfb24  vmovaps [rsp+0xA0], xmm10
000074c379ddfb2d  vmovaps [rsp+0xB0], xmm11
000074c379ddfb36  vmovaps [rsp+0xC0], xmm12
000074c379ddfb3f  vmovaps [rsp+0xD0], xmm13
000074c379ddfb48  vmovaps [rsp+0xE0], xmm14
000074c379ddfb51  sub rsp, 0x30
000074c379ddfb55  movaps [rsp], xmm15
000074c379ddfb5a  movaps [rsp+0x10], xmm1
000074c379ddfb5f  movaps [rsp+0x20], xmm5
000074c379ddfb64  lea rdi, [rsp]
000074c379ddfb68  mov esi, 0x00
000074c379ddfb6d  mov rax, 0x56321ABA4530
000074c379ddfb77  call rax
000074c379ddfb79  movaps xmm15, [rsp]
000074c379ddfb7e  add rsp, 0x30
000074c379ddfb82  vmovaps xmm0, [rsp]
000074c379ddfb87  vmovaps xmm1, [rsp+0x10]
000074c379ddfb8d  vmovaps xmm2, [rsp+0x20]
000074c379ddfb93  vmovaps xmm3, [rsp+0x30]
000074c379ddfb99  vmovaps xmm4, [rsp+0x40]
000074c379ddfb9f  vmovaps xmm5, [rsp+0x50]
000074c379ddfba5  vmovaps xmm6, [rsp+0x60]
000074c379ddfbab  vmovaps xmm7, [rsp+0x70]
000074c379ddfbb1  vmovaps xmm8, [rsp+0x80]
000074c379ddfbba  vmovaps xmm9, [rsp+0x90]
000074c379ddfbc3  vmovaps xmm10, [rsp+0xA0]
000074c379ddfbcc  vmovaps xmm11, [rsp+0xB0]
000074c379ddfbd5  vmovaps xmm12, [rsp+0xC0]
000074c379ddfbde  vmovaps xmm13, [rsp+0xD0]
000074c379ddfbe7  vmovaps xmm14, [rsp+0xE0]
000074c379ddfbf0  add rsp, 0xF0
000074c379ddfbf7  pop r11
000074c379ddfbf9  pop r10
000074c379ddfbfb  pop r9
000074c379ddfbfd  pop r8
000074c379ddfbff  pop rsi
000074c379ddfc00  pop rdi
000074c379ddfc01  pop rdx
000074c379ddfc02  pop rcx
000074c379ddfc03  pop rax
000074c379ddfc04  add rsp, 0x08
000074c379ddfc08  jmp 0x000074C379DDC473
000074c379ddfc0d  call 0x000074C379CB52F0
000074c379ddfc12  jmp 0x000074C379DDC4CE
000074c379ddfc17  sub rsp, 0x08
000074c379ddfc1b  push rax
000074c379ddfc1c  push rcx
000074c379ddfc1d  push rdx
000074c379ddfc1e  push rdi
000074c379ddfc1f  push rsi
000074c379ddfc20  push r8
000074c379ddfc22  push r9
000074c379ddfc24  push r10
000074c379ddfc26  push r11
000074c379ddfc28  sub rsp, 0xF0
000074c379ddfc2f  vmovaps [rsp], xmm0
000074c379ddfc34  vmovaps [rsp+0x10], xmm1
000074c379ddfc3a  vmovaps [rsp+0x20], xmm2
000074c379ddfc40  vmovaps [rsp+0x30], xmm3
000074c379ddfc46  vmovaps [rsp+0x40], xmm4
000074c379ddfc4c  vmovaps [rsp+0x50], xmm5
000074c379ddfc52  vmovaps [rsp+0x60], xmm6
000074c379ddfc58  vmovaps [rsp+0x70], xmm7
000074c379ddfc5e  vmovaps [rsp+0x80], xmm8
000074c379ddfc67  vmovaps [rsp+0x90], xmm10
000074c379ddfc70  vmovaps [rsp+0xA0], xmm11
000074c379ddfc79  vmovaps [rsp+0xB0], xmm12
000074c379ddfc82  vmovaps [rsp+0xC0], xmm13
000074c379ddfc8b  vmovaps [rsp+0xD0], xmm14
000074c379ddfc94  vmovaps [rsp+0xE0], xmm15
000074c379ddfc9d  sub rsp, 0x30
000074c379ddfca1  movaps [rsp], xmm9
000074c379ddfca6  movaps [rsp+0x10], xmm8
000074c379ddfcac  movaps [rsp+0x20], xmm11
000074c379ddfcb2  lea rdi, [rsp]
000074c379ddfcb6  mov esi, 0x00
000074c379ddfcbb  mov rax, 0x56321ABA4530
000074c379ddfcc5  call rax
000074c379ddfcc7  movaps xmm9, [rsp]
000074c379ddfccc  add rsp, 0x30
000074c379ddfcd0  vmovaps xmm0, [rsp]
000074c379ddfcd5  vmovaps xmm1, [rsp+0x10]
000074c379ddfcdb  vmovaps xmm2, [rsp+0x20]
000074c379ddfce1  vmovaps xmm3, [rsp+0x30]
000074c379ddfce7  vmovaps xmm4, [rsp+0x40]
000074c379ddfced  vmovaps xmm5, [rsp+0x50]
000074c379ddfcf3  vmovaps xmm6, [rsp+0x60]
000074c379ddfcf9  vmovaps xmm7, [rsp+0x70]
000074c379ddfcff  vmovaps xmm8, [rsp+0x80]
000074c379ddfd08  vmovaps xmm10, [rsp+0x90]
000074c379ddfd11  vmovaps xmm11, [rsp+0xA0]
000074c379ddfd1a  vmovaps xmm12, [rsp+0xB0]
000074c379ddfd23  vmovaps xmm13, [rsp+0xC0]
000074c379ddfd2c  vmovaps xmm14, [rsp+0xD0]
000074c379ddfd35  vmovaps xmm15, [rsp+0xE0]
000074c379ddfd3e  add rsp, 0xF0
000074c379ddfd45  pop r11
000074c379ddfd47  pop r10
000074c379ddfd49  pop r9
000074c379ddfd4b  pop r8
000074c379ddfd4d  pop rsi
000074c379ddfd4e  pop rdi
000074c379ddfd4f  pop rdx
000074c379ddfd50  pop rcx
000074c379ddfd51  pop rax
000074c379ddfd52  add rsp, 0x08
000074c379ddfd56  jmp 0x000074C379DDC505
000074c379ddfd5b  sub rsp, 0x08
000074c379ddfd5f  push rax
000074c379ddfd60  push rcx
000074c379ddfd61  push rdx
000074c379ddfd62  push rdi
000074c379ddfd63  push rsi
000074c379ddfd64  push r8
000074c379ddfd66  push r9
000074c379ddfd68  push r10
000074c379ddfd6a  push r11
000074c379ddfd6c  sub rsp, 0xF0
000074c379ddfd73  vmovaps [rsp], xmm0
000074c379ddfd78  vmovaps [rsp+0x10], xmm1
000074c379ddfd7e  vmovaps [rsp+0x20], xmm2
000074c379ddfd84  vmovaps [rsp+0x30], xmm3
000074c379ddfd8a  vmovaps [rsp+0x40], xmm4
000074c379ddfd90  vmovaps [rsp+0x50], xmm5
000074c379ddfd96  vmovaps [rsp+0x60], xmm6
000074c379ddfd9c  vmovaps [rsp+0x70], xmm7
000074c379ddfda2  vmovaps [rsp+0x80], xmm8
000074c379ddfdab  vmovaps [rsp+0x90], xmm9
000074c379ddfdb4  vmovaps [rsp+0xA0], xmm10
000074c379ddfdbd  vmovaps [rsp+0xB0], xmm12
000074c379ddfdc6  vmovaps [rsp+0xC0], xmm13
000074c379ddfdcf  vmovaps [rsp+0xD0], xmm14
000074c379ddfdd8  vmovaps [rsp+0xE0], xmm15
000074c379ddfde1  sub rsp, 0x30
000074c379ddfde5  movaps [rsp], xmm11
000074c379ddfdea  movaps [rsp+0x10], xmm10
000074c379ddfdf0  movaps [rsp+0x20], xmm6
000074c379ddfdf5  lea rdi, [rsp]
000074c379ddfdf9  mov esi, 0x00
000074c379ddfdfe  mov rax, 0x56321ABA4530
000074c379ddfe08  call rax
000074c379ddfe0a  movaps xmm11, [rsp]
000074c379ddfe0f  add rsp, 0x30
000074c379ddfe13  vmovaps xmm0, [rsp]
000074c379ddfe18  vmovaps xmm1, [rsp+0x10]
000074c379ddfe1e  vmovaps xmm2, [rsp+0x20]
000074c379ddfe24  vmovaps xmm3, [rsp+0x30]
000074c379ddfe2a  vmovaps xmm4, [rsp+0x40]
000074c379ddfe30  vmovaps xmm5, [rsp+0x50]
000074c379ddfe36  vmovaps xmm6, [rsp+0x60]
000074c379ddfe3c  vmovaps xmm7, [rsp+0x70]
000074c379ddfe42  vmovaps xmm8, [rsp+0x80]
000074c379ddfe4b  vmovaps xmm9, [rsp+0x90]
000074c379ddfe54  vmovaps xmm10, [rsp+0xA0]
000074c379ddfe5d  vmovaps xmm12, [rsp+0xB0]
000074c379ddfe66  vmovaps xmm13, [rsp+0xC0]
000074c379ddfe6f  vmovaps xmm14, [rsp+0xD0]
000074c379ddfe78  vmovaps xmm15, [rsp+0xE0]
000074c379ddfe81  add rsp, 0xF0
000074c379ddfe88  pop r11
000074c379ddfe8a  pop r10
000074c379ddfe8c  pop r9
000074c379ddfe8e  pop r8
000074c379ddfe90  pop rsi
000074c379ddfe91  pop rdi
000074c379ddfe92  pop rdx
000074c379ddfe93  pop rcx
000074c379ddfe94  pop rax
000074c379ddfe95  add rsp, 0x08
000074c379ddfe99  jmp 0x000074C379DDC520
000074c379ddfe9e  sub rsp, 0x08
000074c379ddfea2  push rax
000074c379ddfea3  push rcx
000074c379ddfea4  push rdx
000074c379ddfea5  push rdi
000074c379ddfea6  push rsi
000074c379ddfea7  push r8
000074c379ddfea9  push r9
000074c379ddfeab  push r10
000074c379ddfead  push r11
000074c379ddfeaf  sub rsp, 0xF0
000074c379ddfeb6  vmovaps [rsp], xmm0
000074c379ddfebb  vmovaps [rsp+0x10], xmm1
000074c379ddfec1  vmovaps [rsp+0x20], xmm2
000074c379ddfec7  vmovaps [rsp+0x30], xmm3
000074c379ddfecd  vmovaps [rsp+0x40], xmm4
000074c379ddfed3  vmovaps [rsp+0x50], xmm5
000074c379ddfed9  vmovaps [rsp+0x60], xmm6
000074c379ddfedf  vmovaps [rsp+0x70], xmm7
000074c379ddfee5  vmovaps [rsp+0x80], xmm8
000074c379ddfeee  vmovaps [rsp+0x90], xmm9
000074c379ddfef7  vmovaps [rsp+0xA0], xmm11
000074c379ddff00  vmovaps [rsp+0xB0], xmm12
000074c379ddff09  vmovaps [rsp+0xC0], xmm13
000074c379ddff12  vmovaps [rsp+0xD0], xmm14
000074c379ddff1b  vmovaps [rsp+0xE0], xmm15
000074c379ddff24  sub rsp, 0x30
000074c379ddff28  movaps [rsp], xmm10
000074c379ddff2d  movaps [rsp+0x10], xmm14
000074c379ddff33  movaps [rsp+0x20], xmm4
000074c379ddff38  lea rdi, [rsp]
000074c379ddff3c  mov esi, 0x00
000074c379ddff41  mov rax, 0x56321ABA4530
000074c379ddff4b  call rax
000074c379ddff4d  movaps xmm10, [rsp]
000074c379ddff52  add rsp, 0x30
000074c379ddff56  vmovaps xmm0, [rsp]
000074c379ddff5b  vmovaps xmm1, [rsp+0x10]
000074c379ddff61  vmovaps xmm2, [rsp+0x20]
000074c379ddff67  vmovaps xmm3, [rsp+0x30]
000074c379ddff6d  vmovaps xmm4, [rsp+0x40]
000074c379ddff73  vmovaps xmm5, [rsp+0x50]
000074c379ddff79  vmovaps xmm6, [rsp+0x60]
000074c379ddff7f  vmovaps xmm7, [rsp+0x70]
000074c379ddff85  vmovaps xmm8, [rsp+0x80]
000074c379ddff8e  vmovaps xmm9, [rsp+0x90]
000074c379ddff97  vmovaps xmm11, [rsp+0xA0]
000074c379ddffa0  vmovaps xmm12, [rsp+0xB0]
000074c379ddffa9  vmovaps xmm13, [rsp+0xC0]
000074c379ddffb2  vmovaps xmm14, [rsp+0xD0]
000074c379ddffbb  vmovaps xmm15, [rsp+0xE0]
000074c379ddffc4  add rsp, 0xF0
000074c379ddffcb  pop r11
000074c379ddffcd  pop r10
000074c379ddffcf  pop r9
000074c379ddffd1  pop r8
000074c379ddffd3  pop rsi
000074c379ddffd4  pop rdi
000074c379ddffd5  pop rdx
000074c379ddffd6  pop rcx
000074c379ddffd7  pop rax
000074c379ddffd8  add rsp, 0x08
000074c379ddffdc  jmp 0x000074C379DDC53B
000074c379ddffe1  sub rsp, 0x08
000074c379ddffe5  push rax
000074c379ddffe6  push rcx
000074c379ddffe7  push rdx
000074c379ddffe8  push rdi
000074c379ddffe9  push rsi
000074c379ddffea  push r8
000074c379ddffec  push r9
000074c379ddffee  push r10
000074c379ddfff0  push r11
000074c379ddfff2  sub rsp, 0xF0
000074c379ddfff9  vmovaps [rsp], xmm0
000074c379ddfffe  vmovaps [rsp+0x10], xmm1
000074c379de0004  vmovaps [rsp+0x20], xmm2
000074c379de000a  vmovaps [rsp+0x30], xmm3
000074c379de0010  vmovaps [rsp+0x40], xmm4
000074c379de0016  vmovaps [rsp+0x50], xmm5
000074c379de001c  vmovaps [rsp+0x60], xmm6
000074c379de0022  vmovaps [rsp+0x70], xmm7
000074c379de0028  vmovaps [rsp+0x80], xmm9
000074c379de0031  vmovaps [rsp+0x90], xmm10
000074c379de003a  vmovaps [rsp+0xA0], xmm11
000074c379de0043  vmovaps [rsp+0xB0], xmm12
000074c379de004c  vmovaps [rsp+0xC0], xmm13
000074c379de0055  vmovaps [rsp+0xD0], xmm14
000074c379de005e  vmovaps [rsp+0xE0], xmm15
000074c379de0067  sub rsp, 0x30
000074c379de006b  movaps [rsp], xmm8
000074c379de0070  movaps [rsp+0x10], xmm1
000074c379de0075  movaps [rsp+0x20], xmm14
000074c379de007b  lea rdi, [rsp]
000074c379de007f  mov esi, 0x00
000074c379de0084  mov rax, 0x56321ABA4530
000074c379de008e  call rax
000074c379de0090  movaps xmm8, [rsp]
000074c379de0095  add rsp, 0x30
000074c379de0099  vmovaps xmm0, [rsp]
000074c379de009e  vmovaps xmm1, [rsp+0x10]
000074c379de00a4  vmovaps xmm2, [rsp+0x20]
000074c379de00aa  vmovaps xmm3, [rsp+0x30]
000074c379de00b0  vmovaps xmm4, [rsp+0x40]
000074c379de00b6  vmovaps xmm5, [rsp+0x50]
000074c379de00bc  vmovaps xmm6, [rsp+0x60]
000074c379de00c2  vmovaps xmm7, [rsp+0x70]
000074c379de00c8  vmovaps xmm9, [rsp+0x80]
000074c379de00d1  vmovaps xmm10, [rsp+0x90]
000074c379de00da  vmovaps xmm11, [rsp+0xA0]
000074c379de00e3  vmovaps xmm12, [rsp+0xB0]
000074c379de00ec  vmovaps xmm13, [rsp+0xC0]
000074c379de00f5  vmovaps xmm14, [rsp+0xD0]
000074c379de00fe  vmovaps xmm15, [rsp+0xE0]
000074c379de0107  add rsp, 0xF0
000074c379de010e  pop r11
000074c379de0110  pop r10
000074c379de0112  pop r9
000074c379de0114  pop r8
000074c379de0116  pop rsi
000074c379de0117  pop rdi
000074c379de0118  pop rdx
000074c379de0119  pop rcx
000074c379de011a  pop rax
000074c379de011b  add rsp, 0x08
000074c379de011f  jmp 0x000074C379DDC561
000074c379de0124  sub rsp, 0x08
000074c379de0128  push rax
000074c379de0129  push rcx
000074c379de012a  push rdx
000074c379de012b  push rdi
000074c379de012c  push rsi
000074c379de012d  push r8
000074c379de012f  push r9
000074c379de0131  push r10
000074c379de0133  push r11
000074c379de0135  sub rsp, 0xF0
000074c379de013c  vmovaps [rsp], xmm0
000074c379de0141  vmovaps [rsp+0x10], xmm1
000074c379de0147  vmovaps [rsp+0x20], xmm2
000074c379de014d  vmovaps [rsp+0x30], xmm3
000074c379de0153  vmovaps [rsp+0x40], xmm4
000074c379de0159  vmovaps [rsp+0x50], xmm5
000074c379de015f  vmovaps [rsp+0x60], xmm7
000074c379de0165  vmovaps [rsp+0x70], xmm8
000074c379de016b  vmovaps [rsp+0x80], xmm9
000074c379de0174  vmovaps [rsp+0x90], xmm10
000074c379de017d  vmovaps [rsp+0xA0], xmm11
000074c379de0186  vmovaps [rsp+0xB0], xmm12
000074c379de018f  vmovaps [rsp+0xC0], xmm13
000074c379de0198  vmovaps [rsp+0xD0], xmm14
000074c379de01a1  vmovaps [rsp+0xE0], xmm15
000074c379de01aa  sub rsp, 0x30
000074c379de01ae  movaps [rsp], xmm6
000074c379de01b2  movaps [rsp+0x10], xmm1
000074c379de01b7  movaps [rsp+0x20], xmm14
000074c379de01bd  lea rdi, [rsp]
000074c379de01c1  mov esi, 0x00
000074c379de01c6  mov rax, 0x56321ABA4530
000074c379de01d0  call rax
000074c379de01d2  movaps xmm6, [rsp]
000074c379de01d6  add rsp, 0x30
000074c379de01da  vmovaps xmm0, [rsp]
000074c379de01df  vmovaps xmm1, [rsp+0x10]
000074c379de01e5  vmovaps xmm2, [rsp+0x20]
000074c379de01eb  vmovaps xmm3, [rsp+0x30]
000074c379de01f1  vmovaps xmm4, [rsp+0x40]
000074c379de01f7  vmovaps xmm5, [rsp+0x50]
000074c379de01fd  vmovaps xmm7, [rsp+0x60]
000074c379de0203  vmovaps xmm8, [rsp+0x70]
000074c379de0209  vmovaps xmm9, [rsp+0x80]
000074c379de0212  vmovaps xmm10, [rsp+0x90]
000074c379de021b  vmovaps xmm11, [rsp+0xA0]
000074c379de0224  vmovaps xmm12, [rsp+0xB0]
000074c379de022d  vmovaps xmm13, [rsp+0xC0]
000074c379de0236  vmovaps xmm14, [rsp+0xD0]
000074c379de023f  vmovaps xmm15, [rsp+0xE0]
000074c379de0248  add rsp, 0xF0
000074c379de024f  pop r11
000074c379de0251  pop r10
000074c379de0253  pop r9
000074c379de0255  pop r8
000074c379de0257  pop rsi
000074c379de0258  pop rdi
000074c379de0259  pop rdx
000074c379de025a  pop rcx
000074c379de025b  pop rax
000074c379de025c  add rsp, 0x08
000074c379de0260  jmp 0x000074C379DDC58D
000074c379de0265  sub rsp, 0x08
000074c379de0269  push rax
000074c379de026a  push rcx
000074c379de026b  push rdx
000074c379de026c  push rdi
000074c379de026d  push rsi
000074c379de026e  push r8
000074c379de0270  push r9
000074c379de0272  push r10
000074c379de0274  push r11
000074c379de0276  sub rsp, 0xF0
000074c379de027d  vmovaps [rsp], xmm0
000074c379de0282  vmovaps [rsp+0x10], xmm1
000074c379de0288  vmovaps [rsp+0x20], xmm2
000074c379de028e  vmovaps [rsp+0x30], xmm3
000074c379de0294  vmovaps [rsp+0x40], xmm4
000074c379de029a  vmovaps [rsp+0x50], xmm5
000074c379de02a0  vmovaps [rsp+0x60], xmm6
000074c379de02a6  vmovaps [rsp+0x70], xmm7
000074c379de02ac  vmovaps [rsp+0x80], xmm8
000074c379de02b5  vmovaps [rsp+0x90], xmm9
000074c379de02be  vmovaps [rsp+0xA0], xmm10
000074c379de02c7  vmovaps [rsp+0xB0], xmm11
000074c379de02d0  vmovaps [rsp+0xC0], xmm12
000074c379de02d9  vmovaps [rsp+0xD0], xmm13
000074c379de02e2  vmovaps [rsp+0xE0], xmm15
000074c379de02eb  sub rsp, 0x30
000074c379de02ef  movaps [rsp], xmm14
000074c379de02f4  movaps [rsp+0x10], xmm12
000074c379de02fa  movaps [rsp+0x20], xmm1
000074c379de02ff  lea rdi, [rsp]
000074c379de0303  mov esi, 0x00
000074c379de0308  mov rax, 0x56321ABA4530
000074c379de0312  call rax
000074c379de0314  movaps xmm14, [rsp]
000074c379de0319  add rsp, 0x30
000074c379de031d  vmovaps xmm0, [rsp]
000074c379de0322  vmovaps xmm1, [rsp+0x10]
000074c379de0328  vmovaps xmm2, [rsp+0x20]
000074c379de032e  vmovaps xmm3, [rsp+0x30]
000074c379de0334  vmovaps xmm4, [rsp+0x40]
000074c379de033a  vmovaps xmm5, [rsp+0x50]
000074c379de0340  vmovaps xmm6, [rsp+0x60]
000074c379de0346  vmovaps xmm7, [rsp+0x70]
000074c379de034c  vmovaps xmm8, [rsp+0x80]
000074c379de0355  vmovaps xmm9, [rsp+0x90]
000074c379de035e  vmovaps xmm10, [rsp+0xA0]
000074c379de0367  vmovaps xmm11, [rsp+0xB0]
000074c379de0370  vmovaps xmm12, [rsp+0xC0]
000074c379de0379  vmovaps xmm13, [rsp+0xD0]
000074c379de0382  vmovaps xmm15, [rsp+0xE0]
000074c379de038b  add rsp, 0xF0
000074c379de0392  pop r11
000074c379de0394  pop r10
000074c379de0396  pop r9
000074c379de0398  pop r8
000074c379de039a  pop rsi
000074c379de039b  pop rdi
000074c379de039c  pop rdx
000074c379de039d  pop rcx
000074c379de039e  pop rax
000074c379de039f  add rsp, 0x08
000074c379de03a3  jmp 0x000074C379DDC5B3
000074c379de03a8  sub rsp, 0x08
000074c379de03ac  push rax
000074c379de03ad  push rcx
000074c379de03ae  push rdx
000074c379de03af  push rdi
000074c379de03b0  push rsi
000074c379de03b1  push r8
000074c379de03b3  push r9
000074c379de03b5  push r10
000074c379de03b7  push r11
000074c379de03b9  sub rsp, 0xF0
000074c379de03c0  vmovaps [rsp], xmm0
000074c379de03c5  vmovaps [rsp+0x10], xmm2
000074c379de03cb  vmovaps [rsp+0x20], xmm3
000074c379de03d1  vmovaps [rsp+0x30], xmm4
000074c379de03d7  vmovaps [rsp+0x40], xmm5
000074c379de03dd  vmovaps [rsp+0x50], xmm6
000074c379de03e3  vmovaps [rsp+0x60], xmm7
000074c379de03e9  vmovaps [rsp+0x70], xmm8
000074c379de03ef  vmovaps [rsp+0x80], xmm9
000074c379de03f8  vmovaps [rsp+0x90], xmm10
000074c379de0401  vmovaps [rsp+0xA0], xmm11
000074c379de040a  vmovaps [rsp+0xB0], xmm12
000074c379de0413  vmovaps [rsp+0xC0], xmm13
000074c379de041c  vmovaps [rsp+0xD0], xmm14
000074c379de0425  vmovaps [rsp+0xE0], xmm15
000074c379de042e  sub rsp, 0x30
000074c379de0432  movaps [rsp], xmm1
000074c379de0436  movaps [rsp+0x10], xmm13
000074c379de043c  movaps [rsp+0x20], xmm9
000074c379de0442  lea rdi, [rsp]
000074c379de0446  mov esi, 0x00
000074c379de044b  mov rax, 0x56321ABA4530
000074c379de0455  call rax
000074c379de0457  movaps xmm1, [rsp]
000074c379de045b  add rsp, 0x30
000074c379de045f  vmovaps xmm0, [rsp]
000074c379de0464  vmovaps xmm2, [rsp+0x10]
000074c379de046a  vmovaps xmm3, [rsp+0x20]
000074c379de0470  vmovaps xmm4, [rsp+0x30]
000074c379de0476  vmovaps xmm5, [rsp+0x40]
000074c379de047c  vmovaps xmm6, [rsp+0x50]
000074c379de0482  vmovaps xmm7, [rsp+0x60]
000074c379de0488  vmovaps xmm8, [rsp+0x70]
000074c379de048e  vmovaps xmm9, [rsp+0x80]
000074c379de0497  vmovaps xmm10, [rsp+0x90]
000074c379de04a0  vmovaps xmm11, [rsp+0xA0]
000074c379de04a9  vmovaps xmm12, [rsp+0xB0]
000074c379de04b2  vmovaps xmm13, [rsp+0xC0]
000074c379de04bb  vmovaps xmm14, [rsp+0xD0]
000074c379de04c4  vmovaps xmm15, [rsp+0xE0]
000074c379de04cd  add rsp, 0xF0
000074c379de04d4  pop r11
000074c379de04d6  pop r10
000074c379de04d8  pop r9
000074c379de04da  pop r8
000074c379de04dc  pop rsi
000074c379de04dd  pop rdi
000074c379de04de  pop rdx
000074c379de04df  pop rcx
000074c379de04e0  pop rax
000074c379de04e1  add rsp, 0x08
000074c379de04e5  jmp 0x000074C379DDC5CD
000074c379de04ea  sub rsp, 0x08
000074c379de04ee  push rax
000074c379de04ef  push rcx
000074c379de04f0  push rdx
000074c379de04f1  push rdi
000074c379de04f2  push rsi
000074c379de04f3  push r8
000074c379de04f5  push r9
000074c379de04f7  push r10
000074c379de04f9  push r11
000074c379de04fb  sub rsp, 0xF0
000074c379de0502  vmovaps [rsp], xmm0
000074c379de0507  vmovaps [rsp+0x10], xmm1
000074c379de050d  vmovaps [rsp+0x20], xmm2
000074c379de0513  vmovaps [rsp+0x30], xmm3
000074c379de0519  vmovaps [rsp+0x40], xmm4
000074c379de051f  vmovaps [rsp+0x50], xmm5
000074c379de0525  vmovaps [rsp+0x60], xmm6
000074c379de052b  vmovaps [rsp+0x70], xmm7
000074c379de0531  vmovaps [rsp+0x80], xmm8
000074c379de053a  vmovaps [rsp+0x90], xmm9
000074c379de0543  vmovaps [rsp+0xA0], xmm10
000074c379de054c  vmovaps [rsp+0xB0], xmm11
000074c379de0555  vmovaps [rsp+0xC0], xmm13
000074c379de055e  vmovaps [rsp+0xD0], xmm14
000074c379de0567  vmovaps [rsp+0xE0], xmm15
000074c379de0570  sub rsp, 0x30
000074c379de0574  movaps [rsp], xmm12
000074c379de0579  movaps [rsp+0x10], xmm7
000074c379de057e  movaps [rsp+0x20], xmm13
000074c379de0584  lea rdi, [rsp]
000074c379de0588  mov esi, 0x00
000074c379de058d  mov rax, 0x56321ABA4530
000074c379de0597  call rax
000074c379de0599  movaps xmm12, [rsp]
000074c379de059e  add rsp, 0x30
000074c379de05a2  vmovaps xmm0, [rsp]
000074c379de05a7  vmovaps xmm1, [rsp+0x10]
000074c379de05ad  vmovaps xmm2, [rsp+0x20]
000074c379de05b3  vmovaps xmm3, [rsp+0x30]
000074c379de05b9  vmovaps xmm4, [rsp+0x40]
000074c379de05bf  vmovaps xmm5, [rsp+0x50]
000074c379de05c5  vmovaps xmm6, [rsp+0x60]
000074c379de05cb  vmovaps xmm7, [rsp+0x70]
000074c379de05d1  vmovaps xmm8, [rsp+0x80]
000074c379de05da  vmovaps xmm9, [rsp+0x90]
000074c379de05e3  vmovaps xmm10, [rsp+0xA0]
000074c379de05ec  vmovaps xmm11, [rsp+0xB0]
000074c379de05f5  vmovaps xmm13, [rsp+0xC0]
000074c379de05fe  vmovaps xmm14, [rsp+0xD0]
000074c379de0607  vmovaps xmm15, [rsp+0xE0]
000074c379de0610  add rsp, 0xF0
000074c379de0617  pop r11
000074c379de0619  pop r10
000074c379de061b  pop r9
000074c379de061d  pop r8
000074c379de061f  pop rsi
000074c379de0620  pop rdi
000074c379de0621  pop rdx
000074c379de0622  pop rcx
000074c379de0623  pop rax
000074c379de0624  add rsp, 0x08
000074c379de0628  jmp 0x000074C379DDC5F4
000074c379de062d  sub rsp, 0x08
000074c379de0631  push rax
000074c379de0632  push rcx
000074c379de0633  push rdx
000074c379de0634  push rdi
000074c379de0635  push rsi
000074c379de0636  push r8
000074c379de0638  push r9
000074c379de063a  push r10
000074c379de063c  push r11
000074c379de063e  sub rsp, 0xF0
000074c379de0645  vmovaps [rsp], xmm0
000074c379de064a  vmovaps [rsp+0x10], xmm1
000074c379de0650  vmovaps [rsp+0x20], xmm2
000074c379de0656  vmovaps [rsp+0x30], xmm3
000074c379de065c  vmovaps [rsp+0x40], xmm4
000074c379de0662  vmovaps [rsp+0x50], xmm5
000074c379de0668  vmovaps [rsp+0x60], xmm6
000074c379de066e  vmovaps [rsp+0x70], xmm7
000074c379de0674  vmovaps [rsp+0x80], xmm8
000074c379de067d  vmovaps [rsp+0x90], xmm9
000074c379de0686  vmovaps [rsp+0xA0], xmm10
000074c379de068f  vmovaps [rsp+0xB0], xmm11
000074c379de0698  vmovaps [rsp+0xC0], xmm12
000074c379de06a1  vmovaps [rsp+0xD0], xmm14
000074c379de06aa  vmovaps [rsp+0xE0], xmm15
000074c379de06b3  sub rsp, 0x30
000074c379de06b7  movaps [rsp], xmm13
000074c379de06bc  movaps [rsp+0x10], xmm15
000074c379de06c2  movaps [rsp+0x20], xmm8
000074c379de06c8  lea rdi, [rsp]
000074c379de06cc  mov esi, 0x00
000074c379de06d1  mov rax, 0x56321ABA4530
000074c379de06db  call rax
000074c379de06dd  movaps xmm13, [rsp]
000074c379de06e2  add rsp, 0x30
000074c379de06e6  vmovaps xmm0, [rsp]
000074c379de06eb  vmovaps xmm1, [rsp+0x10]
000074c379de06f1  vmovaps xmm2, [rsp+0x20]
000074c379de06f7  vmovaps xmm3, [rsp+0x30]
000074c379de06fd  vmovaps xmm4, [rsp+0x40]
000074c379de0703  vmovaps xmm5, [rsp+0x50]
000074c379de0709  vmovaps xmm6, [rsp+0x60]
000074c379de070f  vmovaps xmm7, [rsp+0x70]
000074c379de0715  vmovaps xmm8, [rsp+0x80]
000074c379de071e  vmovaps xmm9, [rsp+0x90]
000074c379de0727  vmovaps xmm10, [rsp+0xA0]
000074c379de0730  vmovaps xmm11, [rsp+0xB0]
000074c379de0739  vmovaps xmm12, [rsp+0xC0]
000074c379de0742  vmovaps xmm14, [rsp+0xD0]
000074c379de074b  vmovaps xmm15, [rsp+0xE0]
000074c379de0754  add rsp, 0xF0
000074c379de075b  pop r11
000074c379de075d  pop r10
000074c379de075f  pop r9
000074c379de0761  pop r8
000074c379de0763  pop rsi
000074c379de0764  pop rdi
000074c379de0765  pop rdx
000074c379de0766  pop rcx
000074c379de0767  pop rax
000074c379de0768  add rsp, 0x08
000074c379de076c  jmp 0x000074C379DDC60F
000074c379de0771  sub rsp, 0x08
000074c379de0775  push rax
000074c379de0776  push rcx
000074c379de0777  push rdx
000074c379de0778  push rdi
000074c379de0779  push rsi
000074c379de077a  push r8
000074c379de077c  push r9
000074c379de077e  push r10
000074c379de0780  push r11
000074c379de0782  sub rsp, 0xF0
000074c379de0789  vmovaps [rsp], xmm0
000074c379de078e  vmovaps [rsp+0x10], xmm1
000074c379de0794  vmovaps [rsp+0x20], xmm2
000074c379de079a  vmovaps [rsp+0x30], xmm3
000074c379de07a0  vmovaps [rsp+0x40], xmm4
000074c379de07a6  vmovaps [rsp+0x50], xmm5
000074c379de07ac  vmovaps [rsp+0x60], xmm6
000074c379de07b2  vmovaps [rsp+0x70], xmm7
000074c379de07b8  vmovaps [rsp+0x80], xmm9
000074c379de07c1  vmovaps [rsp+0x90], xmm10
000074c379de07ca  vmovaps [rsp+0xA0], xmm11
000074c379de07d3  vmovaps [rsp+0xB0], xmm12
000074c379de07dc  vmovaps [rsp+0xC0], xmm13
000074c379de07e5  vmovaps [rsp+0xD0], xmm14
000074c379de07ee  vmovaps [rsp+0xE0], xmm15
000074c379de07f7  sub rsp, 0x30
000074c379de07fb  movaps [rsp], xmm8
000074c379de0800  movaps [rsp+0x10], xmm15
000074c379de0806  movaps [rsp+0x20], xmm9
000074c379de080c  lea rdi, [rsp]
000074c379de0810  mov esi, 0x00
000074c379de0815  mov rax, 0x56321ABA4530
000074c379de081f  call rax
000074c379de0821  movaps xmm8, [rsp]
000074c379de0826  add rsp, 0x30
000074c379de082a  vmovaps xmm0, [rsp]
000074c379de082f  vmovaps xmm1, [rsp+0x10]
000074c379de0835  vmovaps xmm2, [rsp+0x20]
000074c379de083b  vmovaps xmm3, [rsp+0x30]
000074c379de0841  vmovaps xmm4, [rsp+0x40]
000074c379de0847  vmovaps xmm5, [rsp+0x50]
000074c379de084d  vmovaps xmm6, [rsp+0x60]
000074c379de0853  vmovaps xmm7, [rsp+0x70]
000074c379de0859  vmovaps xmm9, [rsp+0x80]
000074c379de0862  vmovaps xmm10, [rsp+0x90]
000074c379de086b  vmovaps xmm11, [rsp+0xA0]
000074c379de0874  vmovaps xmm12, [rsp+0xB0]
000074c379de087d  vmovaps xmm13, [rsp+0xC0]
000074c379de0886  vmovaps xmm14, [rsp+0xD0]
000074c379de088f  vmovaps xmm15, [rsp+0xE0]
000074c379de0898  add rsp, 0xF0
000074c379de089f  pop r11
000074c379de08a1  pop r10
000074c379de08a3  pop r9
000074c379de08a5  pop r8
000074c379de08a7  pop rsi
000074c379de08a8  pop rdi
000074c379de08a9  pop rdx
000074c379de08aa  pop rcx
000074c379de08ab  pop rax
000074c379de08ac  add rsp, 0x08
000074c379de08b0  jmp 0x000074C379DDC63D
000074c379de08b5  sub rsp, 0x08
000074c379de08b9  push rax
000074c379de08ba  push rcx
000074c379de08bb  push rdx
000074c379de08bc  push rdi
000074c379de08bd  push rsi
000074c379de08be  push r8
000074c379de08c0  push r9
000074c379de08c2  push r10
000074c379de08c4  push r11
000074c379de08c6  sub rsp, 0xF0
000074c379de08cd  vmovaps [rsp], xmm0
000074c379de08d2  vmovaps [rsp+0x10], xmm1
000074c379de08d8  vmovaps [rsp+0x20], xmm2
000074c379de08de  vmovaps [rsp+0x30], xmm3
000074c379de08e4  vmovaps [rsp+0x40], xmm4
000074c379de08ea  vmovaps [rsp+0x50], xmm5
000074c379de08f0  vmovaps [rsp+0x60], xmm6
000074c379de08f6  vmovaps [rsp+0x70], xmm7
000074c379de08fc  vmovaps [rsp+0x80], xmm8
000074c379de0905  vmovaps [rsp+0x90], xmm9
000074c379de090e  vmovaps [rsp+0xA0], xmm10
000074c379de0917  vmovaps [rsp+0xB0], xmm11
000074c379de0920  vmovaps [rsp+0xC0], xmm12
000074c379de0929  vmovaps [rsp+0xD0], xmm13
000074c379de0932  vmovaps [rsp+0xE0], xmm14
000074c379de093b  sub rsp, 0x30
000074c379de093f  movaps [rsp], xmm15
000074c379de0944  movaps [rsp+0x10], xmm11
000074c379de094a  movaps [rsp+0x20], xmm6
000074c379de094f  lea rdi, [rsp]
000074c379de0953  mov esi, 0x00
000074c379de0958  mov rax, 0x56321ABA4530
000074c379de0962  call rax
000074c379de0964  movaps xmm15, [rsp]
000074c379de0969  add rsp, 0x30
000074c379de096d  vmovaps xmm0, [rsp]
000074c379de0972  vmovaps xmm1, [rsp+0x10]
000074c379de0978  vmovaps xmm2, [rsp+0x20]
000074c379de097e  vmovaps xmm3, [rsp+0x30]
000074c379de0984  vmovaps xmm4, [rsp+0x40]
000074c379de098a  vmovaps xmm5, [rsp+0x50]
000074c379de0990  vmovaps xmm6, [rsp+0x60]
000074c379de0996  vmovaps xmm7, [rsp+0x70]
000074c379de099c  vmovaps xmm8, [rsp+0x80]
000074c379de09a5  vmovaps xmm9, [rsp+0x90]
000074c379de09ae  vmovaps xmm10, [rsp+0xA0]
000074c379de09b7  vmovaps xmm11, [rsp+0xB0]
000074c379de09c0  vmovaps xmm12, [rsp+0xC0]
000074c379de09c9  vmovaps xmm13, [rsp+0xD0]
000074c379de09d2  vmovaps xmm14, [rsp+0xE0]
000074c379de09db  add rsp, 0xF0
000074c379de09e2  pop r11
000074c379de09e4  pop r10
000074c379de09e6  pop r9
000074c379de09e8  pop r8
000074c379de09ea  pop rsi
000074c379de09eb  pop rdi
000074c379de09ec  pop rdx
000074c379de09ed  pop rcx
000074c379de09ee  pop rax
000074c379de09ef  add rsp, 0x08
000074c379de09f3  jmp 0x000074C379DDC658
000074c379de09f8  sub rsp, 0x08
000074c379de09fc  push rax
000074c379de09fd  push rcx
000074c379de09fe  push rdx
000074c379de09ff  push rdi
000074c379de0a00  push rsi
000074c379de0a01  push r8
000074c379de0a03  push r9
000074c379de0a05  push r10
000074c379de0a07  push r11
000074c379de0a09  sub rsp, 0xF0
000074c379de0a10  vmovaps [rsp], xmm0
000074c379de0a15  vmovaps [rsp+0x10], xmm1
000074c379de0a1b  vmovaps [rsp+0x20], xmm2
000074c379de0a21  vmovaps [rsp+0x30], xmm3
000074c379de0a27  vmovaps [rsp+0x40], xmm4
000074c379de0a2d  vmovaps [rsp+0x50], xmm5
000074c379de0a33  vmovaps [rsp+0x60], xmm6
000074c379de0a39  vmovaps [rsp+0x70], xmm8
000074c379de0a3f  vmovaps [rsp+0x80], xmm9
000074c379de0a48  vmovaps [rsp+0x90], xmm10
000074c379de0a51  vmovaps [rsp+0xA0], xmm11
000074c379de0a5a  vmovaps [rsp+0xB0], xmm12
000074c379de0a63  vmovaps [rsp+0xC0], xmm13
000074c379de0a6c  vmovaps [rsp+0xD0], xmm14
000074c379de0a75  vmovaps [rsp+0xE0], xmm15
000074c379de0a7e  sub rsp, 0x30
000074c379de0a82  movaps [rsp], xmm7
000074c379de0a86  movaps [rsp+0x10], xmm11
000074c379de0a8c  movaps [rsp+0x20], xmm9
000074c379de0a92  lea rdi, [rsp]
000074c379de0a96  mov esi, 0x00
000074c379de0a9b  mov rax, 0x56321ABA4530
000074c379de0aa5  call rax
000074c379de0aa7  movaps xmm7, [rsp]
000074c379de0aab  add rsp, 0x30
000074c379de0aaf  vmovaps xmm0, [rsp]
000074c379de0ab4  vmovaps xmm1, [rsp+0x10]
000074c379de0aba  vmovaps xmm2, [rsp+0x20]
000074c379de0ac0  vmovaps xmm3, [rsp+0x30]
000074c379de0ac6  vmovaps xmm4, [rsp+0x40]
000074c379de0acc  vmovaps xmm5, [rsp+0x50]
000074c379de0ad2  vmovaps xmm6, [rsp+0x60]
000074c379de0ad8  vmovaps xmm8, [rsp+0x70]
000074c379de0ade  vmovaps xmm9, [rsp+0x80]
000074c379de0ae7  vmovaps xmm10, [rsp+0x90]
000074c379de0af0  vmovaps xmm11, [rsp+0xA0]
000074c379de0af9  vmovaps xmm12, [rsp+0xB0]
000074c379de0b02  vmovaps xmm13, [rsp+0xC0]
000074c379de0b0b  vmovaps xmm14, [rsp+0xD0]
000074c379de0b14  vmovaps xmm15, [rsp+0xE0]
000074c379de0b1d  add rsp, 0xF0
000074c379de0b24  pop r11
000074c379de0b26  pop r10
000074c379de0b28  pop r9
000074c379de0b2a  pop r8
000074c379de0b2c  pop rsi
000074c379de0b2d  pop rdi
000074c379de0b2e  pop rdx
000074c379de0b2f  pop rcx
000074c379de0b30  pop rax
000074c379de0b31  add rsp, 0x08
000074c379de0b35  jmp 0x000074C379DDC685
000074c379de0b3a  sub rsp, 0x08
000074c379de0b3e  push rax
000074c379de0b3f  push rcx
000074c379de0b40  push rdx
000074c379de0b41  push rdi
000074c379de0b42  push rsi
000074c379de0b43  push r8
000074c379de0b45  push r9
000074c379de0b47  push r10
000074c379de0b49  push r11
000074c379de0b4b  sub rsp, 0xF0
000074c379de0b52  vmovaps [rsp], xmm0
000074c379de0b57  vmovaps [rsp+0x10], xmm1
000074c379de0b5d  vmovaps [rsp+0x20], xmm2
000074c379de0b63  vmovaps [rsp+0x30], xmm3
000074c379de0b69  vmovaps [rsp+0x40], xmm4
000074c379de0b6f  vmovaps [rsp+0x50], xmm5
000074c379de0b75  vmovaps [rsp+0x60], xmm6
000074c379de0b7b  vmovaps [rsp+0x70], xmm7
000074c379de0b81  vmovaps [rsp+0x80], xmm8
000074c379de0b8a  vmovaps [rsp+0x90], xmm9
000074c379de0b93  vmovaps [rsp+0xA0], xmm10
000074c379de0b9c  vmovaps [rsp+0xB0], xmm12
000074c379de0ba5  vmovaps [rsp+0xC0], xmm13
000074c379de0bae  vmovaps [rsp+0xD0], xmm14
000074c379de0bb7  vmovaps [rsp+0xE0], xmm15
000074c379de0bc0  sub rsp, 0x30
000074c379de0bc4  movaps [rsp], xmm11
000074c379de0bc9  movaps [rsp+0x10], xmm10
000074c379de0bcf  movaps [rsp+0x20], xmm14
000074c379de0bd5  lea rdi, [rsp]
000074c379de0bd9  mov esi, 0x00
000074c379de0bde  mov rax, 0x56321ABA4530
000074c379de0be8  call rax
000074c379de0bea  movaps xmm11, [rsp]
000074c379de0bef  add rsp, 0x30
000074c379de0bf3  vmovaps xmm0, [rsp]
000074c379de0bf8  vmovaps xmm1, [rsp+0x10]
000074c379de0bfe  vmovaps xmm2, [rsp+0x20]
000074c379de0c04  vmovaps xmm3, [rsp+0x30]
000074c379de0c0a  vmovaps xmm4, [rsp+0x40]
000074c379de0c10  vmovaps xmm5, [rsp+0x50]
000074c379de0c16  vmovaps xmm6, [rsp+0x60]
000074c379de0c1c  vmovaps xmm7, [rsp+0x70]
000074c379de0c22  vmovaps xmm8, [rsp+0x80]
000074c379de0c2b  vmovaps xmm9, [rsp+0x90]
000074c379de0c34  vmovaps xmm10, [rsp+0xA0]
000074c379de0c3d  vmovaps xmm12, [rsp+0xB0]
000074c379de0c46  vmovaps xmm13, [rsp+0xC0]
000074c379de0c4f  vmovaps xmm14, [rsp+0xD0]
000074c379de0c58  vmovaps xmm15, [rsp+0xE0]
000074c379de0c61  add rsp, 0xF0
000074c379de0c68  pop r11
000074c379de0c6a  pop r10
000074c379de0c6c  pop r9
000074c379de0c6e  pop r8
000074c379de0c70  pop rsi
000074c379de0c71  pop rdi
000074c379de0c72  pop rdx
000074c379de0c73  pop rcx
000074c379de0c74  pop rax
000074c379de0c75  add rsp, 0x08
000074c379de0c79  jmp 0x000074C379DDC6A0
000074c379de0c7e  call 0x000074C379CC33A0
000074c379de0c83  jmp 0x000074C379DDC6AA
000074c379de0c88  sub rsp, 0x08
000074c379de0c8c  push rax
000074c379de0c8d  push rcx
000074c379de0c8e  push rdx
000074c379de0c8f  push rdi
000074c379de0c90  push rsi
000074c379de0c91  push r8
000074c379de0c93  push r9
000074c379de0c95  push r10
000074c379de0c97  push r11
000074c379de0c99  sub rsp, 0xF0
000074c379de0ca0  vmovaps [rsp], xmm0
000074c379de0ca5  vmovaps [rsp+0x10], xmm1
000074c379de0cab  vmovaps [rsp+0x20], xmm2
000074c379de0cb1  vmovaps [rsp+0x30], xmm3
000074c379de0cb7  vmovaps [rsp+0x40], xmm4
000074c379de0cbd  vmovaps [rsp+0x50], xmm5
000074c379de0cc3  vmovaps [rsp+0x60], xmm6
000074c379de0cc9  vmovaps [rsp+0x70], xmm7
000074c379de0ccf  vmovaps [rsp+0x80], xmm8
000074c379de0cd8  vmovaps [rsp+0x90], xmm9
000074c379de0ce1  vmovaps [rsp+0xA0], xmm11
000074c379de0cea  vmovaps [rsp+0xB0], xmm12
000074c379de0cf3  vmovaps [rsp+0xC0], xmm13
000074c379de0cfc  vmovaps [rsp+0xD0], xmm14
000074c379de0d05  vmovaps [rsp+0xE0], xmm15
000074c379de0d0e  sub rsp, 0x30
000074c379de0d12  movaps [rsp], xmm10
000074c379de0d17  movaps [rsp+0x10], xmm1
000074c379de0d1c  movaps [rsp+0x20], xmm12
000074c379de0d22  lea rdi, [rsp]
000074c379de0d26  mov esi, 0x00
000074c379de0d2b  mov rax, 0x56321ABA4530
000074c379de0d35  call rax
000074c379de0d37  movaps xmm10, [rsp]
000074c379de0d3c  add rsp, 0x30
000074c379de0d40  vmovaps xmm0, [rsp]
000074c379de0d45  vmovaps xmm1, [rsp+0x10]
000074c379de0d4b  vmovaps xmm2, [rsp+0x20]
000074c379de0d51  vmovaps xmm3, [rsp+0x30]
000074c379de0d57  vmovaps xmm4, [rsp+0x40]
000074c379de0d5d  vmovaps xmm5, [rsp+0x50]
000074c379de0d63  vmovaps xmm6, [rsp+0x60]
000074c379de0d69  vmovaps xmm7, [rsp+0x70]
000074c379de0d6f  vmovaps xmm8, [rsp+0x80]
000074c379de0d78  vmovaps xmm9, [rsp+0x90]
000074c379de0d81  vmovaps xmm11, [rsp+0xA0]
000074c379de0d8a  vmovaps xmm12, [rsp+0xB0]
000074c379de0d93  vmovaps xmm13, [rsp+0xC0]
000074c379de0d9c  vmovaps xmm14, [rsp+0xD0]
000074c379de0da5  vmovaps xmm15, [rsp+0xE0]
000074c379de0dae  add rsp, 0xF0
000074c379de0db5  pop r11
000074c379de0db7  pop r10
000074c379de0db9  pop r9
000074c379de0dbb  pop r8
000074c379de0dbd  pop rsi
000074c379de0dbe  pop rdi
000074c379de0dbf  pop rdx
000074c379de0dc0  pop rcx
000074c379de0dc1  pop rax
000074c379de0dc2  add rsp, 0x08
000074c379de0dc6  jmp 0x000074C379DDC6CD
000074c379de0dcb  sub rsp, 0x08
000074c379de0dcf  push rax
000074c379de0dd0  push rcx
000074c379de0dd1  push rdx
000074c379de0dd2  push rdi
000074c379de0dd3  push rsi
000074c379de0dd4  push r8
000074c379de0dd6  push r9
000074c379de0dd8  push r10
000074c379de0dda  push r11
000074c379de0ddc  sub rsp, 0xF0
000074c379de0de3  vmovaps [rsp], xmm0
000074c379de0de8  vmovaps [rsp+0x10], xmm1
000074c379de0dee  vmovaps [rsp+0x20], xmm2
000074c379de0df4  vmovaps [rsp+0x30], xmm3
000074c379de0dfa  vmovaps [rsp+0x40], xmm4
000074c379de0e00  vmovaps [rsp+0x50], xmm5
000074c379de0e06  vmovaps [rsp+0x60], xmm6
000074c379de0e0c  vmovaps [rsp+0x70], xmm7
000074c379de0e12  vmovaps [rsp+0x80], xmm8
000074c379de0e1b  vmovaps [rsp+0x90], xmm9
000074c379de0e24  vmovaps [rsp+0xA0], xmm10
000074c379de0e2d  vmovaps [rsp+0xB0], xmm11
000074c379de0e36  vmovaps [rsp+0xC0], xmm13
000074c379de0e3f  vmovaps [rsp+0xD0], xmm14
000074c379de0e48  vmovaps [rsp+0xE0], xmm15
000074c379de0e51  sub rsp, 0x30
000074c379de0e55  movaps [rsp], xmm12
000074c379de0e5a  movaps [rsp+0x10], xmm14
000074c379de0e60  movaps [rsp+0x20], xmm1
000074c379de0e65  lea rdi, [rsp]
000074c379de0e69  mov esi, 0x00
000074c379de0e6e  mov rax, 0x56321ABA4530
000074c379de0e78  call rax
000074c379de0e7a  movaps xmm12, [rsp]
000074c379de0e7f  add rsp, 0x30
000074c379de0e83  vmovaps xmm0, [rsp]
000074c379de0e88  vmovaps xmm1, [rsp+0x10]
000074c379de0e8e  vmovaps xmm2, [rsp+0x20]
000074c379de0e94  vmovaps xmm3, [rsp+0x30]
000074c379de0e9a  vmovaps xmm4, [rsp+0x40]
000074c379de0ea0  vmovaps xmm5, [rsp+0x50]
000074c379de0ea6  vmovaps xmm6, [rsp+0x60]
000074c379de0eac  vmovaps xmm7, [rsp+0x70]
000074c379de0eb2  vmovaps xmm8, [rsp+0x80]
000074c379de0ebb  vmovaps xmm9, [rsp+0x90]
000074c379de0ec4  vmovaps xmm10, [rsp+0xA0]
000074c379de0ecd  vmovaps xmm11, [rsp+0xB0]
000074c379de0ed6  vmovaps xmm13, [rsp+0xC0]
000074c379de0edf  vmovaps xmm14, [rsp+0xD0]
000074c379de0ee8  vmovaps xmm15, [rsp+0xE0]
000074c379de0ef1  add rsp, 0xF0
000074c379de0ef8  pop r11
000074c379de0efa  pop r10
000074c379de0efc  pop r9
000074c379de0efe  pop r8
000074c379de0f00  pop rsi
000074c379de0f01  pop rdi
000074c379de0f02  pop rdx
000074c379de0f03  pop rcx
000074c379de0f04  pop rax
000074c379de0f05  add rsp, 0x08
000074c379de0f09  jmp 0x000074C379DDC6FC
000074c379de0f0e  sub rsp, 0x08
000074c379de0f12  push rax
000074c379de0f13  push rcx
000074c379de0f14  push rdx
000074c379de0f15  push rdi
000074c379de0f16  push rsi
000074c379de0f17  push r8
000074c379de0f19  push r9
000074c379de0f1b  push r10
000074c379de0f1d  push r11
000074c379de0f1f  sub rsp, 0xF0
000074c379de0f26  vmovaps [rsp], xmm0
000074c379de0f2b  vmovaps [rsp+0x10], xmm1
000074c379de0f31  vmovaps [rsp+0x20], xmm2
000074c379de0f37  vmovaps [rsp+0x30], xmm3
000074c379de0f3d  vmovaps [rsp+0x40], xmm4
000074c379de0f43  vmovaps [rsp+0x50], xmm5
000074c379de0f49  vmovaps [rsp+0x60], xmm6
000074c379de0f4f  vmovaps [rsp+0x70], xmm7
000074c379de0f55  vmovaps [rsp+0x80], xmm8
000074c379de0f5e  vmovaps [rsp+0x90], xmm9
000074c379de0f67  vmovaps [rsp+0xA0], xmm10
000074c379de0f70  vmovaps [rsp+0xB0], xmm11
000074c379de0f79  vmovaps [rsp+0xC0], xmm12
000074c379de0f82  vmovaps [rsp+0xD0], xmm13
000074c379de0f8b  vmovaps [rsp+0xE0], xmm15
000074c379de0f94  sub rsp, 0x30
000074c379de0f98  movaps [rsp], xmm14
000074c379de0f9d  movaps [rsp+0x10], xmm9
000074c379de0fa3  movaps [rsp+0x20], xmm1
000074c379de0fa8  lea rdi, [rsp]
000074c379de0fac  mov esi, 0x00
000074c379de0fb1  mov rax, 0x56321ABA4530
000074c379de0fbb  call rax
000074c379de0fbd  movaps xmm14, [rsp]
000074c379de0fc2  add rsp, 0x30
000074c379de0fc6  vmovaps xmm0, [rsp]
000074c379de0fcb  vmovaps xmm1, [rsp+0x10]
000074c379de0fd1  vmovaps xmm2, [rsp+0x20]
000074c379de0fd7  vmovaps xmm3, [rsp+0x30]
000074c379de0fdd  vmovaps xmm4, [rsp+0x40]
000074c379de0fe3  vmovaps xmm5, [rsp+0x50]
000074c379de0fe9  vmovaps xmm6, [rsp+0x60]
000074c379de0fef  vmovaps xmm7, [rsp+0x70]
000074c379de0ff5  vmovaps xmm8, [rsp+0x80]
000074c379de0ffe  vmovaps xmm9, [rsp+0x90]
000074c379de1007  vmovaps xmm10, [rsp+0xA0]
000074c379de1010  vmovaps xmm11, [rsp+0xB0]
000074c379de1019  vmovaps xmm12, [rsp+0xC0]
000074c379de1022  vmovaps xmm13, [rsp+0xD0]
000074c379de102b  vmovaps xmm15, [rsp+0xE0]
000074c379de1034  add rsp, 0xF0
000074c379de103b  pop r11
000074c379de103d  pop r10
000074c379de103f  pop r9
000074c379de1041  pop r8
000074c379de1043  pop rsi
000074c379de1044  pop rdi
000074c379de1045  pop rdx
000074c379de1046  pop rcx
000074c379de1047  pop rax
000074c379de1048  add rsp, 0x08
000074c379de104c  jmp 0x000074C379DDC72B
000074c379de1051  sub rsp, 0x08
000074c379de1055  push rax
000074c379de1056  push rcx
000074c379de1057  push rdx
000074c379de1058  push rdi
000074c379de1059  push rsi
000074c379de105a  push r8
000074c379de105c  push r9
000074c379de105e  push r10
000074c379de1060  push r11
000074c379de1062  sub rsp, 0xF0
000074c379de1069  vmovaps [rsp], xmm0
000074c379de106e  vmovaps [rsp+0x10], xmm2
000074c379de1074  vmovaps [rsp+0x20], xmm3
000074c379de107a  vmovaps [rsp+0x30], xmm4
000074c379de1080  vmovaps [rsp+0x40], xmm5
000074c379de1086  vmovaps [rsp+0x50], xmm6
000074c379de108c  vmovaps [rsp+0x60], xmm7
000074c379de1092  vmovaps [rsp+0x70], xmm8
000074c379de1098  vmovaps [rsp+0x80], xmm9
000074c379de10a1  vmovaps [rsp+0x90], xmm10
000074c379de10aa  vmovaps [rsp+0xA0], xmm11
000074c379de10b3  vmovaps [rsp+0xB0], xmm12
000074c379de10bc  vmovaps [rsp+0xC0], xmm13
000074c379de10c5  vmovaps [rsp+0xD0], xmm14
000074c379de10ce  vmovaps [rsp+0xE0], xmm15
000074c379de10d7  sub rsp, 0x30
000074c379de10db  movaps [rsp], xmm1
000074c379de10df  movaps [rsp+0x10], xmm13
000074c379de10e5  movaps [rsp+0x20], xmm8
000074c379de10eb  lea rdi, [rsp]
000074c379de10ef  mov esi, 0x00
000074c379de10f4  mov rax, 0x56321ABA4530
000074c379de10fe  call rax
000074c379de1100  movaps xmm1, [rsp]
000074c379de1104  add rsp, 0x30
000074c379de1108  vmovaps xmm0, [rsp]
000074c379de110d  vmovaps xmm2, [rsp+0x10]
000074c379de1113  vmovaps xmm3, [rsp+0x20]
000074c379de1119  vmovaps xmm4, [rsp+0x30]
000074c379de111f  vmovaps xmm5, [rsp+0x40]
000074c379de1125  vmovaps xmm6, [rsp+0x50]
000074c379de112b  vmovaps xmm7, [rsp+0x60]
000074c379de1131  vmovaps xmm8, [rsp+0x70]
000074c379de1137  vmovaps xmm9, [rsp+0x80]
000074c379de1140  vmovaps xmm10, [rsp+0x90]
000074c379de1149  vmovaps xmm11, [rsp+0xA0]
000074c379de1152  vmovaps xmm12, [rsp+0xB0]
000074c379de115b  vmovaps xmm13, [rsp+0xC0]
000074c379de1164  vmovaps xmm14, [rsp+0xD0]
000074c379de116d  vmovaps xmm15, [rsp+0xE0]
000074c379de1176  add rsp, 0xF0
000074c379de117d  pop r11
000074c379de117f  pop r10
000074c379de1181  pop r9
000074c379de1183  pop r8
000074c379de1185  pop rsi
000074c379de1186  pop rdi
000074c379de1187  pop rdx
000074c379de1188  pop rcx
000074c379de1189  pop rax
000074c379de118a  add rsp, 0x08
000074c379de118e  jmp 0x000074C379DDC74D
000074c379de1193  call 0x000074C379C0C260
000074c379de1198  jmp 0x000074C379DDC75B
000074c379de119d  call 0x000074C379CBD750
000074c379de11a2  jmp 0x000074C379DDC765
000074c379de11a7  sub rsp, 0x08
000074c379de11ab  push rax
000074c379de11ac  push rcx
000074c379de11ad  push rdx
000074c379de11ae  push rdi
000074c379de11af  push rsi
000074c379de11b0  push r8
000074c379de11b2  push r9
000074c379de11b4  push r10
000074c379de11b6  push r11
000074c379de11b8  sub rsp, 0xF0
000074c379de11bf  vmovaps [rsp], xmm0
000074c379de11c4  vmovaps [rsp+0x10], xmm1
000074c379de11ca  vmovaps [rsp+0x20], xmm2
000074c379de11d0  vmovaps [rsp+0x30], xmm3
000074c379de11d6  vmovaps [rsp+0x40], xmm4
000074c379de11dc  vmovaps [rsp+0x50], xmm5
000074c379de11e2  vmovaps [rsp+0x60], xmm6
000074c379de11e8  vmovaps [rsp+0x70], xmm7
000074c379de11ee  vmovaps [rsp+0x80], xmm9
000074c379de11f7  vmovaps [rsp+0x90], xmm10
000074c379de1200  vmovaps [rsp+0xA0], xmm11
000074c379de1209  vmovaps [rsp+0xB0], xmm12
000074c379de1212  vmovaps [rsp+0xC0], xmm13
000074c379de121b  vmovaps [rsp+0xD0], xmm14
000074c379de1224  vmovaps [rsp+0xE0], xmm15
000074c379de122d  sub rsp, 0x30
000074c379de1231  movaps [rsp], xmm8
000074c379de1236  movaps [rsp+0x10], xmm15
000074c379de123c  movaps [rsp+0x20], xmm7
000074c379de1241  lea rdi, [rsp]
000074c379de1245  mov esi, 0x00
000074c379de124a  mov rax, 0x56321ABA4530
000074c379de1254  call rax
000074c379de1256  movaps xmm8, [rsp]
000074c379de125b  add rsp, 0x30
000074c379de125f  vmovaps xmm0, [rsp]
000074c379de1264  vmovaps xmm1, [rsp+0x10]
000074c379de126a  vmovaps xmm2, [rsp+0x20]
000074c379de1270  vmovaps xmm3, [rsp+0x30]
000074c379de1276  vmovaps xmm4, [rsp+0x40]
000074c379de127c  vmovaps xmm5, [rsp+0x50]
000074c379de1282  vmovaps xmm6, [rsp+0x60]
000074c379de1288  vmovaps xmm7, [rsp+0x70]
000074c379de128e  vmovaps xmm9, [rsp+0x80]
000074c379de1297  vmovaps xmm10, [rsp+0x90]
000074c379de12a0  vmovaps xmm11, [rsp+0xA0]
000074c379de12a9  vmovaps xmm12, [rsp+0xB0]
000074c379de12b2  vmovaps xmm13, [rsp+0xC0]
000074c379de12bb  vmovaps xmm14, [rsp+0xD0]
000074c379de12c4  vmovaps xmm15, [rsp+0xE0]
000074c379de12cd  add rsp, 0xF0
000074c379de12d4  pop r11
000074c379de12d6  pop r10
000074c379de12d8  pop r9
000074c379de12da  pop r8
000074c379de12dc  pop rsi
000074c379de12dd  pop rdi
000074c379de12de  pop rdx
000074c379de12df  pop rcx
000074c379de12e0  pop rax
000074c379de12e1  add rsp, 0x08
000074c379de12e5  jmp 0x000074C379DDC787
000074c379de12ea  sub rsp, 0x08
000074c379de12ee  push rax
000074c379de12ef  push rcx
000074c379de12f0  push rdx
000074c379de12f1  push rdi
000074c379de12f2  push rsi
000074c379de12f3  push r8
000074c379de12f5  push r9
000074c379de12f7  push r10
000074c379de12f9  push r11
000074c379de12fb  sub rsp, 0xF0
000074c379de1302  vmovaps [rsp], xmm0
000074c379de1307  vmovaps [rsp+0x10], xmm1
000074c379de130d  vmovaps [rsp+0x20], xmm2
000074c379de1313  vmovaps [rsp+0x30], xmm3
000074c379de1319  vmovaps [rsp+0x40], xmm4
000074c379de131f  vmovaps [rsp+0x50], xmm5
000074c379de1325  vmovaps [rsp+0x60], xmm6
000074c379de132b  vmovaps [rsp+0x70], xmm8
000074c379de1331  vmovaps [rsp+0x80], xmm9
000074c379de133a  vmovaps [rsp+0x90], xmm10
000074c379de1343  vmovaps [rsp+0xA0], xmm11
000074c379de134c  vmovaps [rsp+0xB0], xmm12
000074c379de1355  vmovaps [rsp+0xC0], xmm13
000074c379de135e  vmovaps [rsp+0xD0], xmm14
000074c379de1367  vmovaps [rsp+0xE0], xmm15
000074c379de1370  sub rsp, 0x30
000074c379de1374  movaps [rsp], xmm7
000074c379de1378  movaps [rsp+0x10], xmm9
000074c379de137e  movaps [rsp+0x20], xmm15
000074c379de1384  lea rdi, [rsp]
000074c379de1388  mov esi, 0x00
000074c379de138d  mov rax, 0x56321ABA4530
000074c379de1397  call rax
000074c379de1399  movaps xmm7, [rsp]
000074c379de139d  add rsp, 0x30
000074c379de13a1  vmovaps xmm0, [rsp]
000074c379de13a6  vmovaps xmm1, [rsp+0x10]
000074c379de13ac  vmovaps xmm2, [rsp+0x20]
000074c379de13b2  vmovaps xmm3, [rsp+0x30]
000074c379de13b8  vmovaps xmm4, [rsp+0x40]
000074c379de13be  vmovaps xmm5, [rsp+0x50]
000074c379de13c4  vmovaps xmm6, [rsp+0x60]
000074c379de13ca  vmovaps xmm8, [rsp+0x70]
000074c379de13d0  vmovaps xmm9, [rsp+0x80]
000074c379de13d9  vmovaps xmm10, [rsp+0x90]
000074c379de13e2  vmovaps xmm11, [rsp+0xA0]
000074c379de13eb  vmovaps xmm12, [rsp+0xB0]
000074c379de13f4  vmovaps xmm13, [rsp+0xC0]
000074c379de13fd  vmovaps xmm14, [rsp+0xD0]
000074c379de1406  vmovaps xmm15, [rsp+0xE0]
000074c379de140f  add rsp, 0xF0
000074c379de1416  pop r11
000074c379de1418  pop r10
000074c379de141a  pop r9
000074c379de141c  pop r8
000074c379de141e  pop rsi
000074c379de141f  pop rdi
000074c379de1420  pop rdx
000074c379de1421  pop rcx
000074c379de1422  pop rax
000074c379de1423  add rsp, 0x08
000074c379de1427  jmp 0x000074C379DDC7B4
000074c379de142c  sub rsp, 0x08
000074c379de1430  push rax
000074c379de1431  push rcx
000074c379de1432  push rdx
000074c379de1433  push rdi
000074c379de1434  push rsi
000074c379de1435  push r8
000074c379de1437  push r9
000074c379de1439  push r10
000074c379de143b  push r11
000074c379de143d  sub rsp, 0xF0
000074c379de1444  vmovaps [rsp], xmm0
000074c379de1449  vmovaps [rsp+0x10], xmm1
000074c379de144f  vmovaps [rsp+0x20], xmm2
000074c379de1455  vmovaps [rsp+0x30], xmm3
000074c379de145b  vmovaps [rsp+0x40], xmm4
000074c379de1461  vmovaps [rsp+0x50], xmm5
000074c379de1467  vmovaps [rsp+0x60], xmm6
000074c379de146d  vmovaps [rsp+0x70], xmm7
000074c379de1473  vmovaps [rsp+0x80], xmm8
000074c379de147c  vmovaps [rsp+0x90], xmm10
000074c379de1485  vmovaps [rsp+0xA0], xmm11
000074c379de148e  vmovaps [rsp+0xB0], xmm12
000074c379de1497  vmovaps [rsp+0xC0], xmm13
000074c379de14a0  vmovaps [rsp+0xD0], xmm14
000074c379de14a9  vmovaps [rsp+0xE0], xmm15
000074c379de14b2  sub rsp, 0x30
000074c379de14b6  movaps [rsp], xmm9
000074c379de14bb  movaps [rsp+0x10], xmm13
000074c379de14c1  movaps [rsp+0x20], xmm15
000074c379de14c7  lea rdi, [rsp]
000074c379de14cb  mov esi, 0x00
000074c379de14d0  mov rax, 0x56321ABA4530
000074c379de14da  call rax
000074c379de14dc  movaps xmm9, [rsp]
000074c379de14e1  add rsp, 0x30
000074c379de14e5  vmovaps xmm0, [rsp]
000074c379de14ea  vmovaps xmm1, [rsp+0x10]
000074c379de14f0  vmovaps xmm2, [rsp+0x20]
000074c379de14f6  vmovaps xmm3, [rsp+0x30]
000074c379de14fc  vmovaps xmm4, [rsp+0x40]
000074c379de1502  vmovaps xmm5, [rsp+0x50]
000074c379de1508  vmovaps xmm6, [rsp+0x60]
000074c379de150e  vmovaps xmm7, [rsp+0x70]
000074c379de1514  vmovaps xmm8, [rsp+0x80]
000074c379de151d  vmovaps xmm10, [rsp+0x90]
000074c379de1526  vmovaps xmm11, [rsp+0xA0]
000074c379de152f  vmovaps xmm12, [rsp+0xB0]
000074c379de1538  vmovaps xmm13, [rsp+0xC0]
000074c379de1541  vmovaps xmm14, [rsp+0xD0]
000074c379de154a  vmovaps xmm15, [rsp+0xE0]
000074c379de1553  add rsp, 0xF0
000074c379de155a  pop r11
000074c379de155c  pop r10
000074c379de155e  pop r9
000074c379de1560  pop r8
000074c379de1562  pop rsi
000074c379de1563  pop rdi
000074c379de1564  pop rdx
000074c379de1565  pop rcx
000074c379de1566  pop rax
000074c379de1567  add rsp, 0x08
000074c379de156b  jmp 0x000074C379DDC7E2
000074c379de1570  sub rsp, 0x08
000074c379de1574  push rax
000074c379de1575  push rcx
000074c379de1576  push rdx
000074c379de1577  push rdi
000074c379de1578  push rsi
000074c379de1579  push r8
000074c379de157b  push r9
000074c379de157d  push r10
000074c379de157f  push r11
000074c379de1581  sub rsp, 0xF0
000074c379de1588  vmovaps [rsp], xmm0
000074c379de158d  vmovaps [rsp+0x10], xmm1
000074c379de1593  vmovaps [rsp+0x20], xmm2
000074c379de1599  vmovaps [rsp+0x30], xmm3
000074c379de159f  vmovaps [rsp+0x40], xmm4
000074c379de15a5  vmovaps [rsp+0x50], xmm5
000074c379de15ab  vmovaps [rsp+0x60], xmm6
000074c379de15b1  vmovaps [rsp+0x70], xmm7
000074c379de15b7  vmovaps [rsp+0x80], xmm8
000074c379de15c0  vmovaps [rsp+0x90], xmm9
000074c379de15c9  vmovaps [rsp+0xA0], xmm10
000074c379de15d2  vmovaps [rsp+0xB0], xmm11
000074c379de15db  vmovaps [rsp+0xC0], xmm12
000074c379de15e4  vmovaps [rsp+0xD0], xmm13
000074c379de15ed  vmovaps [rsp+0xE0], xmm14
000074c379de15f6  sub rsp, 0x30
000074c379de15fa  movaps [rsp], xmm15
000074c379de15ff  movaps [rsp+0x10], xmm11
000074c379de1605  movaps [rsp+0x20], xmm12
000074c379de160b  lea rdi, [rsp]
000074c379de160f  mov esi, 0x00
000074c379de1614  mov rax, 0x56321ABA4530
000074c379de161e  call rax
000074c379de1620  movaps xmm15, [rsp]
000074c379de1625  add rsp, 0x30
000074c379de1629  vmovaps xmm0, [rsp]
000074c379de162e  vmovaps xmm1, [rsp+0x10]
000074c379de1634  vmovaps xmm2, [rsp+0x20]
000074c379de163a  vmovaps xmm3, [rsp+0x30]
000074c379de1640  vmovaps xmm4, [rsp+0x40]
000074c379de1646  vmovaps xmm5, [rsp+0x50]
000074c379de164c  vmovaps xmm6, [rsp+0x60]
000074c379de1652  vmovaps xmm7, [rsp+0x70]
000074c379de1658  vmovaps xmm8, [rsp+0x80]
000074c379de1661  vmovaps xmm9, [rsp+0x90]
000074c379de166a  vmovaps xmm10, [rsp+0xA0]
000074c379de1673  vmovaps xmm11, [rsp+0xB0]
000074c379de167c  vmovaps xmm12, [rsp+0xC0]
000074c379de1685  vmovaps xmm13, [rsp+0xD0]
000074c379de168e  vmovaps xmm14, [rsp+0xE0]
000074c379de1697  add rsp, 0xF0
000074c379de169e  pop r11
000074c379de16a0  pop r10
000074c379de16a2  pop r9
000074c379de16a4  pop r8
000074c379de16a6  pop rsi
000074c379de16a7  pop rdi
000074c379de16a8  pop rdx
000074c379de16a9  pop rcx
000074c379de16aa  pop rax
000074c379de16ab  add rsp, 0x08
000074c379de16af  jmp 0x000074C379DDC7FD
000074c379de16b4  sub rsp, 0x08
000074c379de16b8  push rax
000074c379de16b9  push rcx
000074c379de16ba  push rdx
000074c379de16bb  push rdi
000074c379de16bc  push rsi
000074c379de16bd  push r8
000074c379de16bf  push r9
000074c379de16c1  push r10
000074c379de16c3  push r11
000074c379de16c5  sub rsp, 0xF0
000074c379de16cc  vmovaps [rsp], xmm0
000074c379de16d1  vmovaps [rsp+0x10], xmm1
000074c379de16d7  vmovaps [rsp+0x20], xmm2
000074c379de16dd  vmovaps [rsp+0x30], xmm3
000074c379de16e3  vmovaps [rsp+0x40], xmm4
000074c379de16e9  vmovaps [rsp+0x50], xmm5
000074c379de16ef  vmovaps [rsp+0x60], xmm6
000074c379de16f5  vmovaps [rsp+0x70], xmm7
000074c379de16fb  vmovaps [rsp+0x80], xmm8
000074c379de1704  vmovaps [rsp+0x90], xmm9
000074c379de170d  vmovaps [rsp+0xA0], xmm10
000074c379de1716  vmovaps [rsp+0xB0], xmm11
000074c379de171f  vmovaps [rsp+0xC0], xmm12
000074c379de1728  vmovaps [rsp+0xD0], xmm14
000074c379de1731  vmovaps [rsp+0xE0], xmm15
000074c379de173a  sub rsp, 0x30
000074c379de173e  movaps [rsp], xmm13
000074c379de1743  movaps [rsp+0x10], xmm10
000074c379de1749  movaps [rsp+0x20], xmm14
000074c379de174f  lea rdi, [rsp]
000074c379de1753  mov esi, 0x00
000074c379de1758  mov rax, 0x56321ABA4530
000074c379de1762  call rax
000074c379de1764  movaps xmm13, [rsp]
000074c379de1769  add rsp, 0x30
000074c379de176d  vmovaps xmm0, [rsp]
000074c379de1772  vmovaps xmm1, [rsp+0x10]
000074c379de1778  vmovaps xmm2, [rsp+0x20]
000074c379de177e  vmovaps xmm3, [rsp+0x30]
000074c379de1784  vmovaps xmm4, [rsp+0x40]
000074c379de178a  vmovaps xmm5, [rsp+0x50]
000074c379de1790  vmovaps xmm6, [rsp+0x60]
000074c379de1796  vmovaps xmm7, [rsp+0x70]
000074c379de179c  vmovaps xmm8, [rsp+0x80]
000074c379de17a5  vmovaps xmm9, [rsp+0x90]
000074c379de17ae  vmovaps xmm10, [rsp+0xA0]
000074c379de17b7  vmovaps xmm11, [rsp+0xB0]
000074c379de17c0  vmovaps xmm12, [rsp+0xC0]
000074c379de17c9  vmovaps xmm14, [rsp+0xD0]
000074c379de17d2  vmovaps xmm15, [rsp+0xE0]
000074c379de17db  add rsp, 0xF0
000074c379de17e2  pop r11
000074c379de17e4  pop r10
000074c379de17e6  pop r9
000074c379de17e8  pop r8
000074c379de17ea  pop rsi
000074c379de17eb  pop rdi
000074c379de17ec  pop rdx
000074c379de17ed  pop rcx
000074c379de17ee  pop rax
000074c379de17ef  add rsp, 0x08
000074c379de17f3  jmp 0x000074C379DDC820
000074c379de17f8  sub rsp, 0x08
000074c379de17fc  push rax
000074c379de17fd  push rcx
000074c379de17fe  push rdx
000074c379de17ff  push rdi
000074c379de1800  push rsi
000074c379de1801  push r8
000074c379de1803  push r9
000074c379de1805  push r10
000074c379de1807  push r11
000074c379de1809  sub rsp, 0xF0
000074c379de1810  vmovaps [rsp], xmm0
000074c379de1815  vmovaps [rsp+0x10], xmm1
000074c379de181b  vmovaps [rsp+0x20], xmm2
000074c379de1821  vmovaps [rsp+0x30], xmm3
000074c379de1827  vmovaps [rsp+0x40], xmm4
000074c379de182d  vmovaps [rsp+0x50], xmm5
000074c379de1833  vmovaps [rsp+0x60], xmm6
000074c379de1839  vmovaps [rsp+0x70], xmm7
000074c379de183f  vmovaps [rsp+0x80], xmm8
000074c379de1848  vmovaps [rsp+0x90], xmm9
000074c379de1851  vmovaps [rsp+0xA0], xmm10
000074c379de185a  vmovaps [rsp+0xB0], xmm11
000074c379de1863  vmovaps [rsp+0xC0], xmm12
000074c379de186c  vmovaps [rsp+0xD0], xmm13
000074c379de1875  vmovaps [rsp+0xE0], xmm15
000074c379de187e  sub rsp, 0x30
000074c379de1882  movaps [rsp], xmm14
000074c379de1887  movaps [rsp+0x10], xmm1
000074c379de188c  movaps [rsp+0x20], xmm7
000074c379de1891  lea rdi, [rsp]
000074c379de1895  mov esi, 0x00
000074c379de189a  mov rax, 0x56321ABA4530
000074c379de18a4  call rax
000074c379de18a6  movaps xmm14, [rsp]
000074c379de18ab  add rsp, 0x30
000074c379de18af  vmovaps xmm0, [rsp]
000074c379de18b4  vmovaps xmm1, [rsp+0x10]
000074c379de18ba  vmovaps xmm2, [rsp+0x20]
000074c379de18c0  vmovaps xmm3, [rsp+0x30]
000074c379de18c6  vmovaps xmm4, [rsp+0x40]
000074c379de18cc  vmovaps xmm5, [rsp+0x50]
000074c379de18d2  vmovaps xmm6, [rsp+0x60]
000074c379de18d8  vmovaps xmm7, [rsp+0x70]
000074c379de18de  vmovaps xmm8, [rsp+0x80]
000074c379de18e7  vmovaps xmm9, [rsp+0x90]
000074c379de18f0  vmovaps xmm10, [rsp+0xA0]
000074c379de18f9  vmovaps xmm11, [rsp+0xB0]
000074c379de1902  vmovaps xmm12, [rsp+0xC0]
000074c379de190b  vmovaps xmm13, [rsp+0xD0]
000074c379de1914  vmovaps xmm15, [rsp+0xE0]
000074c379de191d  add rsp, 0xF0
000074c379de1924  pop r11
000074c379de1926  pop r10
000074c379de1928  pop r9
000074c379de192a  pop r8
000074c379de192c  pop rsi
000074c379de192d  pop rdi
000074c379de192e  pop rdx
000074c379de192f  pop rcx
000074c379de1930  pop rax
000074c379de1931  add rsp, 0x08
000074c379de1935  jmp 0x000074C379DDC843
000074c379de193a  sub rsp, 0x08
000074c379de193e  push rax
000074c379de193f  push rcx
000074c379de1940  push rdx
000074c379de1941  push rdi
000074c379de1942  push rsi
000074c379de1943  push r8
000074c379de1945  push r9
000074c379de1947  push r10
000074c379de1949  push r11
000074c379de194b  sub rsp, 0xF0
000074c379de1952  vmovaps [rsp], xmm0
000074c379de1957  vmovaps [rsp+0x10], xmm2
000074c379de195d  vmovaps [rsp+0x20], xmm3
000074c379de1963  vmovaps [rsp+0x30], xmm4
000074c379de1969  vmovaps [rsp+0x40], xmm5
000074c379de196f  vmovaps [rsp+0x50], xmm6
000074c379de1975  vmovaps [rsp+0x60], xmm7
000074c379de197b  vmovaps [rsp+0x70], xmm8
000074c379de1981  vmovaps [rsp+0x80], xmm9
000074c379de198a  vmovaps [rsp+0x90], xmm10
000074c379de1993  vmovaps [rsp+0xA0], xmm11
000074c379de199c  vmovaps [rsp+0xB0], xmm12
000074c379de19a5  vmovaps [rsp+0xC0], xmm13
000074c379de19ae  vmovaps [rsp+0xD0], xmm14
000074c379de19b7  vmovaps [rsp+0xE0], xmm15
000074c379de19c0  sub rsp, 0x30
000074c379de19c4  movaps [rsp], xmm1
000074c379de19c8  movaps [rsp+0x10], xmm8
000074c379de19ce  movaps [rsp+0x20], xmm9
000074c379de19d4  lea rdi, [rsp]
000074c379de19d8  mov esi, 0x00
000074c379de19dd  mov rax, 0x56321ABA4530
000074c379de19e7  call rax
000074c379de19e9  movaps xmm1, [rsp]
000074c379de19ed  add rsp, 0x30
000074c379de19f1  vmovaps xmm0, [rsp]
000074c379de19f6  vmovaps xmm2, [rsp+0x10]
000074c379de19fc  vmovaps xmm3, [rsp+0x20]
000074c379de1a02  vmovaps xmm4, [rsp+0x30]
000074c379de1a08  vmovaps xmm5, [rsp+0x40]
000074c379de1a0e  vmovaps xmm6, [rsp+0x50]
000074c379de1a14  vmovaps xmm7, [rsp+0x60]
000074c379de1a1a  vmovaps xmm8, [rsp+0x70]
000074c379de1a20  vmovaps xmm9, [rsp+0x80]
000074c379de1a29  vmovaps xmm10, [rsp+0x90]
000074c379de1a32  vmovaps xmm11, [rsp+0xA0]
000074c379de1a3b  vmovaps xmm12, [rsp+0xB0]
000074c379de1a44  vmovaps xmm13, [rsp+0xC0]
000074c379de1a4d  vmovaps xmm14, [rsp+0xD0]
000074c379de1a56  vmovaps xmm15, [rsp+0xE0]
000074c379de1a5f  add rsp, 0xF0
000074c379de1a66  pop r11
000074c379de1a68  pop r10
000074c379de1a6a  pop r9
000074c379de1a6c  pop r8
000074c379de1a6e  pop rsi
000074c379de1a6f  pop rdi
000074c379de1a70  pop rdx
000074c379de1a71  pop rcx
000074c379de1a72  pop rax
000074c379de1a73  add rsp, 0x08
000074c379de1a77  jmp 0x000074C379DDC865
000074c379de1a7c  call 0x000074C379CE5940
000074c379de1a81  jmp 0x000074C379DDC873
000074c379de1a86  call 0x000074C379C0C380
000074c379de1a8b  jmp 0x000074C379DDC87D
000074c379de1a90  call 0x000074C379C0D600
000074c379de1a95  jmp 0x000074C379DDC887
000074c379de1a9a  call 0x000074C379BFF540
000074c379de1a9f  jmp 0x000074C379DDC891
000074c379de1aa4  int3
000074c379de1aa5  nop [rax+rax*1], ax
000074c379de1aae  nop
000074c379de1ab0  mov rax, [r15+0xF8]
000074c379de1ab7  lea r14, [rax+0x140]
000074c379de1abe  mov r12, [r13+r14*1]
000074c379de1ac3  mov [r15+0xE8], r12
000074c379de1aca  lea r14, [rax+0x130]
000074c379de1ad1  mov r12, [r13+r14*1]
000074c379de1ad6  lea r14, [rax+0x138]
000074c379de1add  mov r11, [r13+r14*1]
000074c379de1ae2  movq xmm1, r12
000074c379de1ae7  movq xmm15, r11
000074c379de1aec  movq xmm1, xmm1
000074c379de1af0  movq xmm1, xmm1
000074c379de1af4  movaps [r15+0x1A0], xmm1
000074c379de1afc  movq xmm15, xmm15
000074c379de1b01  movq xmm15, xmm15
000074c379de1b06  movaps [r15+0x190], xmm15
000074c379de1b0e  lea r14, [rax+0x120]
000074c379de1b15  mov r12, [r13+r14*1]
000074c379de1b1a  lea r14, [rax+0x128]
000074c379de1b21  mov r11, [r13+r14*1]
000074c379de1b26  movq xmm1, r12
000074c379de1b2b  movq xmm15, r11
000074c379de1b30  movq xmm1, xmm1
000074c379de1b34  movq xmm1, xmm1
000074c379de1b38  movaps [r15+0x1C0], xmm1
000074c379de1b40  movq xmm15, xmm15
000074c379de1b45  movq xmm15, xmm15
000074c379de1b4a  movaps [r15+0x1B0], xmm15
000074c379de1b52  lea r14, [rax+0x110]
000074c379de1b59  mov r12, [r13+r14*1]
000074c379de1b5e  lea r14, [rax+0x118]
000074c379de1b65  mov r11, [r13+r14*1]
000074c379de1b6a  movq xmm1, r12
000074c379de1b6f  movq xmm15, r11
000074c379de1b74  movq xmm1, xmm1
000074c379de1b78  movq xmm1, xmm1
000074c379de1b7c  movaps [r15+0x1E0], xmm1
000074c379de1b84  movq xmm15, xmm15
000074c379de1b89  movq xmm15, xmm15
000074c379de1b8e  movaps [r15+0x1D0], xmm15
000074c379de1b96  lea r14, [rax+0x100]
000074c379de1b9d  mov r12, [r13+r14*1]
000074c379de1ba2  lea r14, [rax+0x108]
000074c379de1ba9  mov r11, [r13+r14*1]
000074c379de1bae  movq xmm1, r12
000074c379de1bb3  movq xmm15, r11
000074c379de1bb8  movq xmm1, xmm1
000074c379de1bbc  movq xmm1, xmm1
000074c379de1bc0  movaps [r15+0x200], xmm1
000074c379de1bc8  movq xmm15, xmm15
000074c379de1bcd  movq xmm15, xmm15
000074c379de1bd2  movaps [r15+0x1F0], xmm15
000074c379de1bda  mov qword ptr [r15+0x40], 0x430000
000074c379de1be2  mov r14d, 0x430510
000074c379de1be8  mov r12, [r13+r14*1]
000074c379de1bed  movq xmm1, r12
000074c379de1bf2  lea r14, [rax+0x150]
000074c379de1bf9  mov [r15+0xF8], r14
000074c379de1c00  mov rax, [r15+0x50]
000074c379de1c04  movups xmm15, [r13+rax*1]
000074c379de1c0a  movaps [r15+0x120], xmm15
000074c379de1c12  mov qword ptr [r15+0x48], 0x10
000074c379de1c1a  xor eax, eax
000074c379de1c1c  mov r14d, 0x10
000074c379de1c22  mov r12d, 0x200
000074c379de1c28  cmp r14, r12
000074c379de1c2b  cmc
000074c379de1c2c  lahf
000074c379de1c2d  seto al
000074c379de1c30  mov [r15+0x108], eax
000074c379de1c37  pextrq rax, xmm15, 0x01
000074c379de1c3e  movq xmm14, rax
000074c379de1c43  movaps [r15+0x130], xmm14
000074c379de1c4b  movq rax, xmm1
000074c379de1c50  movq r14, xmm15
000074c379de1c55  vmovq xmm1, rax
000074c379de1c5a  vmovq xmm15, r14
000074c379de1c5f  movaps xmm13, xmm1
000074c379de1c63  addsd xmm13, xmm15
000074c379de1c68  ucomisd xmm13, xmm13
000074c379de1c6d  jp 0x000074C379DE1D86
000074c379de1c73  movq xmm13, xmm13
000074c379de1c78  movq rax, xmm13
000074c379de1c7d  movq r14, xmm14
000074c379de1c82  vmovq xmm1, rax
000074c379de1c87  vmovq xmm15, r14
000074c379de1c8c  movaps xmm14, xmm1
000074c379de1c90  addsd xmm14, xmm15
000074c379de1c95  ucomisd xmm14, xmm14
000074c379de1c9a  jp 0x000074C379DE1DCE
000074c379de1ca0  movq xmm14, xmm14
000074c379de1ca5  movaps [r15+0x110], xmm14
000074c379de1cad  mov eax, [r15+0x108]
000074c379de1cb4  sahf
000074c379de1cb5  jnz 0x000074C379DE1CE7
000074c379de1cb7  cmp dword ptr [r15+0x318], 0x00
000074c379de1cbf  jz 0x000074C379DE1FE0
000074c379de1cc5  nop [rax+rax*1], ax
000074c379de1cce  nop [rax+rax*1], eax
000074c379de1cd6  mov eax, 0x410490
000074c379de1cdb  mov [r15+0x100], rax
000074c379de1ce2  jmp 0x000074C379BFE110
000074c379de1ce7  cmp dword ptr [r15+0x318], 0x00
000074c379de1cef  jz 0x000074C379DE1E20
000074c379de1cf5  nop [rax+rax*1], ax
000074c379de1cfe  nop [rax+rax*1], eax
000074c379de1d06  mov eax, 0x410474
000074c379de1d0b  mov [r15+0x100], rax
000074c379de1d12  jmp 0x000074C379BFE110
000074c379de1d17  int3
000074c379de1d18  call 0x000074C379CE27E0
000074c379de1d1d  jmp 0x000074C379DE1AC3
000074c379de1d22  call 0x000074C379CE27E0
000074c379de1d27  jmp 0x000074C379DE1AD6
000074c379de1d2c  call 0x000074C379CE1570
000074c379de1d31  jmp 0x000074C379DE1AE2
000074c379de1d36  call 0x000074C379CE27E0
000074c379de1d3b  jmp 0x000074C379DE1B1A
000074c379de1d40  call 0x000074C379CE1570
000074c379de1d45  jmp 0x000074C379DE1B26
000074c379de1d4a  call 0x000074C379CE27E0
000074c379de1d4f  jmp 0x000074C379DE1B5E
000074c379de1d54  call 0x000074C379CE1570
000074c379de1d59  jmp 0x000074C379DE1B6A
000074c379de1d5e  call 0x000074C379CE27E0
000074c379de1d63  jmp 0x000074C379DE1BA2
000074c379de1d68  call 0x000074C379CE1570
000074c379de1d6d  jmp 0x000074C379DE1BAE
000074c379de1d72  call 0x000074C379CE27E0
000074c379de1d77  jmp 0x000074C379DE1BED
000074c379de1d7c  call 0x000074C379C0E760
000074c379de1d81  jmp 0x000074C379DE1C0A
000074c379de1d86  ucomisd xmm1, xmm15
000074c379de1d8b  jp 0x000074C379DE1D9A
000074c379de1d8d  movaps xmm13, [0x000074C3799FE060]
000074c379de1d95  jmp 0x000074C379DE1C73
000074c379de1d9a  vxorps xmm0, xmm1, xmm15
000074c379de1d9f  pextrw eax, xmm0, 0x03
000074c379de1da4  and eax, 0x7FF8
000074c379de1da9  cmp eax, 0x08
000074c379de1dac  jnz 0x000074C379DE1C73
000074c379de1db2  movq rax, xmm15
000074c379de1db7  shl rax, 0x0D
000074c379de1dbb  jbe 0x000074C379DE1C73
000074c379de1dc1  vorps xmm13, xmm15, [0x000074C3799FE070]
000074c379de1dc9  jmp 0x000074C379DE1C73
000074c379de1dce  ucomisd xmm1, xmm15
000074c379de1dd3  jp 0x000074C379DE1DE2
000074c379de1dd5  movaps xmm14, [0x000074C3799FE060]
000074c379de1ddd  jmp 0x000074C379DE1CA0
000074c379de1de2  vxorps xmm0, xmm1, xmm15
000074c379de1de7  pextrw eax, xmm0, 0x03
000074c379de1dec  and eax, 0x7FF8
000074c379de1df1  cmp eax, 0x08
000074c379de1df4  jnz 0x000074C379DE1CA0
000074c379de1dfa  movq rax, xmm15
000074c379de1dff  shl rax, 0x0D
000074c379de1e03  jbe 0x000074C379DE1CA0
000074c379de1e09  vorps xmm14, xmm15, [0x000074C3799FE070]
000074c379de1e11  jmp 0x000074C379DE1CA0
000074c379de1e16  int3
000074c379de1e17  nop [rax+rax*1], ax
000074c379de1e20  mov rax, [r15+0x48]
000074c379de1e24  mov r14, [r15+0x50]
000074c379de1e28  lea r12, [r14+rax*1]
000074c379de1e2c  movups xmm1, [r13+r12*1]
000074c379de1e32  movaps [r15+0x120], xmm1
000074c379de1e3a  lea r14, [rax+0x10]
000074c379de1e3e  mov [r15+0x48], r14
000074c379de1e42  xor eax, eax
000074c379de1e44  mov r12d, 0x200
000074c379de1e4a  cmp r14, r12
000074c379de1e4d  cmc
000074c379de1e4e  lahf
000074c379de1e4f  seto al
000074c379de1e52  mov [r15+0x108], eax
000074c379de1e59  pextrq rax, xmm1, 0x01
000074c379de1e60  movq xmm15, rax
000074c379de1e65  movaps [r15+0x130], xmm15
000074c379de1e6d  movaps xmm14, [r15+0x110]
000074c379de1e75  movq rax, xmm14
000074c379de1e7a  movq r14, xmm1
000074c379de1e7f  vmovq xmm1, rax
000074c379de1e84  vmovq xmm14, r14
000074c379de1e89  movaps xmm13, xmm1
000074c379de1e8d  addsd xmm13, xmm14
000074c379de1e92  ucomisd xmm13, xmm13
000074c379de1e97  jp 0x000074C379DE1F4C
000074c379de1e9d  movq xmm13, xmm13
000074c379de1ea2  movq rax, xmm13
000074c379de1ea7  movq r14, xmm15
000074c379de1eac  vmovq xmm1, rax
000074c379de1eb1  vmovq xmm15, r14
000074c379de1eb6  movaps xmm14, xmm1
000074c379de1eba  addsd xmm14, xmm15
000074c379de1ebf  ucomisd xmm14, xmm14
000074c379de1ec4  jp 0x000074C379DE1F94
000074c379de1eca  movq xmm14, xmm14
000074c379de1ecf  movaps [r15+0x110], xmm14
000074c379de1ed7  mov eax, [r15+0x108]
000074c379de1ede  sahf
000074c379de1edf  jnz 0x000074C379DE1F11
000074c379de1ee1  cmp dword ptr [r15+0x318], 0x00
000074c379de1ee9  jz 0x000074C379DE1FE0
000074c379de1eef  nop [rax+rax*1], ax
000074c379de1ef8  nop [rax+rax*1], eax
000074c379de1f00  mov eax, 0x410490
000074c379de1f05  mov [r15+0x100], rax
000074c379de1f0c  jmp 0x000074C379BFE110
000074c379de1f11  cmp dword ptr [r15+0x318], 0x00
000074c379de1f19  jz 0x000074C379DE1E20
000074c379de1f1f  nop [rax+rax*1], ax
000074c379de1f28  nop [rax+rax*1], eax
000074c379de1f30  mov eax, 0x410474
000074c379de1f35  mov [r15+0x100], rax
000074c379de1f3c  jmp 0x000074C379BFE110
000074c379de1f41  int3
000074c379de1f42  call 0x000074C379CB52F0
000074c379de1f47  jmp 0x000074C379DE1E32
000074c379de1f4c  ucomisd xmm1, xmm14
000074c379de1f51  jp 0x000074C379DE1F60
000074c379de1f53  movaps xmm13, [0x000074C3799FE060]
000074c379de1f5b  jmp 0x000074C379DE1E9D
000074c379de1f60  vxorps xmm0, xmm1, xmm14
000074c379de1f65  pextrw eax, xmm0, 0x03
000074c379de1f6a  and eax, 0x7FF8
000074c379de1f6f  cmp eax, 0x08
000074c379de1f72  jnz 0x000074C379DE1E9D
000074c379de1f78  movq rax, xmm14
000074c379de1f7d  shl rax, 0x0D
000074c379de1f81  jbe 0x000074C379DE1E9D
000074c379de1f87  vorps xmm13, xmm14, [0x000074C3799FE070]
000074c379de1f8f  jmp 0x000074C379DE1E9D
000074c379de1f94  ucomisd xmm1, xmm15
000074c379de1f99  jp 0x000074C379DE1FA8
000074c379de1f9b  movaps xmm14, [0x000074C3799FE060]
000074c379de1fa3  jmp 0x000074C379DE1ECA
000074c379de1fa8  vxorps xmm0, xmm1, xmm15
000074c379de1fad  pextrw eax, xmm0, 0x03
000074c379de1fb2  and eax, 0x7FF8
000074c379de1fb7  cmp eax, 0x08
000074c379de1fba  jnz 0x000074C379DE1ECA
000074c379de1fc0  movq rax, xmm15
000074c379de1fc5  shl rax, 0x0D
000074c379de1fc9  jbe 0x000074C379DE1ECA
000074c379de1fcf  vorps xmm14, xmm15, [0x000074C3799FE070]
000074c379de1fd7  jmp 0x000074C379DE1ECA
000074c379de1fdc  int3
000074c379de1fdd  nop [rax], eax
000074c379de1fe0  mov rax, [r15+0x40]
000074c379de1fe4  lea r14, [rax+0x510]
000074c379de1feb  movaps xmm1, [r15+0x110]
000074c379de1ff3  movq rax, xmm1
000074c379de1ff8  mov [r13+r14*1], rax
000074c379de1ffd  mov rax, [r15+0xF0]
000074c379de2004  mov [r15+0x100], rax
000074c379de200b  jmp 0x000074C379DCE5C0
000074c379de2010  int3
000074c379de2011  call 0x000074C379CD5EB0
000074c379de2016  jmp 0x000074C379DE1FFD
000074c379de201b  int3
000074c379de201c  nop [rax], eax
000074c379de2020  mov qword ptr [r15+0x100], 0x04
000074c379de202b  mov esi, 0x00
000074c379de2030  mov edx, 0x09
000074c379de2035  mov rdi, 0x7FFD13586230
000074c379de203f  mov rax, 0x56321AA37970
000074c379de2049  call rax
000074c379de204b  cmp dword ptr [r15+0x318], 0x00
000074c379de2053  jnz 0x000074C379BFE110
000074c379de2059  jmp 0x000074C379BFE0A0
000074c379de205e  int3
000074c379de205f  int3
