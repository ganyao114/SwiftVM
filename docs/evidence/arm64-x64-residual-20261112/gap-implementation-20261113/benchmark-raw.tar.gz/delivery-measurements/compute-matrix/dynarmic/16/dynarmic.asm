00007e97133ce69b  nop [rax+rax*1], eax
00007e97133ce6a0  vmovaps xmm1, [0x00007E9712FFE010]
00007e97133ce6a8  movq xmm1, xmm1
00007e97133ce6ac  movaps [r15+0x110], xmm1
00007e97133ce6b4  vmovaps xmm1, [0x00007E9712FFE020]
00007e97133ce6bc  movq xmm1, xmm1
00007e97133ce6c0  movaps [r15+0x120], xmm1
00007e97133ce6c8  mov eax, 0x4204C0
00007e97133ce6cd  mov r14, [r13+rax*1]
00007e97133ce6d2  movq xmm1, r14
00007e97133ce6d7  movaps [r15+0x130], xmm1
00007e97133ce6df  vmovaps xmm1, [0x00007E9712FFE030]
00007e97133ce6e7  vpbroadcastq xmm1, xmm1
00007e97133ce6ec  movaps [r15+0x140], xmm1
00007e97133ce6f4  mov qword ptr [r15+0x40], 0x02
00007e97133ce6fc  vmovaps xmm15, [0x00007E9712FFE040]
00007e97133ce704  movq xmm15, xmm15
00007e97133ce709  movaps [r15+0x150], xmm15
00007e97133ce711  mov qword ptr [r15+0x58], 0x420000
00007e97133ce719  vmovaps xmm15, [0x00007E9712FFE050]
00007e97133ce721  vpbroadcastq xmm15, xmm15
00007e97133ce726  movaps [r15+0x160], xmm15
00007e97133ce72e  mov rax, [r15+0x40]
00007e97133ce732  vmovq xmm14, rax
00007e97133ce737  vpbroadcastq xmm14, xmm14
00007e97133ce73c  movaps [r15+0x170], xmm14
00007e97133ce744  mov eax, 0x4204D0
00007e97133ce749  movups xmm13, [r13+rax*1]
00007e97133ce74f  mov qword ptr [r15+0x40], 0x430518
00007e97133ce757  mov qword ptr [r15+0x50], 0x430720
00007e97133ce75f  vpmovqd xmm12, xmm13
00007e97133ce765  pxor xmm11, xmm11
00007e97133ce76a  punpcklqdq xmm12, xmm11
00007e97133ce76f  movaps [r15+0x210], xmm12
00007e97133ce777  movq xmm12, qword ptr [r15+0x120]
00007e97133ce780  movq xmm11, qword ptr [r15+0x130]
00007e97133ce789  psubd xmm12, xmm11
00007e97133ce78e  movq xmm12, xmm12
00007e97133ce793  paddq xmm13, xmm14
00007e97133ce798  movaps [r15+0x180], xmm13
00007e97133ce7a0  movq xmm14, qword ptr [r15+0x150]
00007e97133ce7a9  paddd xmm11, xmm14
00007e97133ce7ae  movq xmm11, xmm11
00007e97133ce7b3  movq xmm11, xmm11
00007e97133ce7b8  movaps [r15+0x130], xmm11
00007e97133ce7c0  pmovzxdq xmm12, xmm12
00007e97133ce7c6  psllq xmm12, 0x00
00007e97133ce7cc  movq xmm14, qword ptr [r15+0x210]
00007e97133ce7d5  movq xmm13, qword ptr [r15+0x110]
00007e97133ce7de  paddd xmm14, xmm13
00007e97133ce7e3  movq xmm14, xmm14
00007e97133ce7e8  vcvtuqq2pd xmm12, xmm12
00007e97133ce7ee  pmovzxdq xmm14, xmm14
00007e97133ce7f4  psllq xmm14, 0x00
00007e97133ce7fa  vcvtuqq2pd xmm14, xmm14
00007e97133ce800  movaps xmm13, xmm12
00007e97133ce804  mulpd xmm13, xmm1
00007e97133ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007e97133ce80f  ptest xmm11, xmm11
00007e97133ce815  jnz 0x00007E97133CE8FF
00007e97133ce81b  movaps [r15+0x220], xmm13
00007e97133ce823  mov eax, 0x430720
00007e97133ce828  movups [r13+rax*1], xmm13
00007e97133ce82e  movaps xmm1, xmm14
00007e97133ce832  mulpd xmm1, xmm15
00007e97133ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007e97133ce83c  ptest xmm13, xmm13
00007e97133ce842  jnz 0x00007E97133CEA4C
00007e97133ce848  movaps [r15+0x210], xmm1
00007e97133ce850  mov eax, 0x430518
00007e97133ce855  movups [r13+rax*1], xmm1
00007e97133ce85b  mov qword ptr [r15+0x48], 0x10
00007e97133ce863  xor eax, eax
00007e97133ce865  mov r14d, 0x10
00007e97133ce86b  mov r12d, 0x200
00007e97133ce871  cmp r14, r12
00007e97133ce874  cmc
00007e97133ce875  lahf
00007e97133ce876  seto al
00007e97133ce879  mov [r15+0x108], eax
00007e97133ce880  mov eax, [r15+0x108]
00007e97133ce887  sahf
00007e97133ce888  jnz 0x00007E97133CE8BA
00007e97133ce88a  cmp dword ptr [r15+0x318], 0x00
00007e97133ce892  jz 0x00007E97133CEFF0
00007e97133ce898  nop [rax+rax*1], ax
00007e97133ce8a1  nop [rax+rax*1], eax
00007e97133ce8a9  mov eax, 0x4101EC
00007e97133ce8ae  mov [r15+0x100], rax
00007e97133ce8b5  jmp 0x00007E97131FE110
00007e97133ce8ba  cmp dword ptr [r15+0x318], 0x00
00007e97133ce8c2  jz 0x00007E97133CEBA0
00007e97133ce8c8  nop [rax+rax*1], ax
00007e97133ce8d1  nop [rax+rax*1], eax
00007e97133ce8d9  mov eax, 0x4101AC
00007e97133ce8de  mov [r15+0x100], rax
00007e97133ce8e5  jmp 0x00007E97131FE110
00007e97133ce8ea  int3
00007e97133ce8eb  call 0x00007E971320DC20
00007e97133ce8f0  jmp 0x00007E97133CE6D2
00007e97133ce8f5  call 0x00007E971320C260
00007e97133ce8fa  jmp 0x00007E97133CE74F
00007e97133ce8ff  sub rsp, 0x08
00007e97133ce903  push rax
00007e97133ce904  push rcx
00007e97133ce905  push rdx
00007e97133ce906  push rdi
00007e97133ce907  push rsi
00007e97133ce908  push r8
00007e97133ce90a  push r9
00007e97133ce90c  push r10
00007e97133ce90e  push r11
00007e97133ce910  sub rsp, 0xF0
00007e97133ce917  vmovaps [rsp], xmm0
00007e97133ce91c  vmovaps [rsp+0x10], xmm1
00007e97133ce922  vmovaps [rsp+0x20], xmm2
00007e97133ce928  vmovaps [rsp+0x30], xmm3
00007e97133ce92e  vmovaps [rsp+0x40], xmm4
00007e97133ce934  vmovaps [rsp+0x50], xmm5
00007e97133ce93a  vmovaps [rsp+0x60], xmm6
00007e97133ce940  vmovaps [rsp+0x70], xmm7
00007e97133ce946  vmovaps [rsp+0x80], xmm8
00007e97133ce94f  vmovaps [rsp+0x90], xmm9
00007e97133ce958  vmovaps [rsp+0xA0], xmm10
00007e97133ce961  vmovaps [rsp+0xB0], xmm11
00007e97133ce96a  vmovaps [rsp+0xC0], xmm12
00007e97133ce973  vmovaps [rsp+0xD0], xmm14
00007e97133ce97c  vmovaps [rsp+0xE0], xmm15
00007e97133ce985  sub rsp, 0x30
00007e97133ce989  movaps [rsp], xmm13
00007e97133ce98e  movaps [rsp+0x10], xmm12
00007e97133ce994  movaps [rsp+0x20], xmm1
00007e97133ce999  lea rdi, [rsp]
00007e97133ce99d  mov esi, 0x00
00007e97133ce9a2  mov rax, 0x58D8AED5F530
00007e97133ce9ac  call rax
00007e97133ce9ae  movaps xmm13, [rsp]
00007e97133ce9b3  add rsp, 0x30
00007e97133ce9b7  vmovaps xmm0, [rsp]
00007e97133ce9bc  vmovaps xmm1, [rsp+0x10]
00007e97133ce9c2  vmovaps xmm2, [rsp+0x20]
00007e97133ce9c8  vmovaps xmm3, [rsp+0x30]
00007e97133ce9ce  vmovaps xmm4, [rsp+0x40]
00007e97133ce9d4  vmovaps xmm5, [rsp+0x50]
00007e97133ce9da  vmovaps xmm6, [rsp+0x60]
00007e97133ce9e0  vmovaps xmm7, [rsp+0x70]
00007e97133ce9e6  vmovaps xmm8, [rsp+0x80]
00007e97133ce9ef  vmovaps xmm9, [rsp+0x90]
00007e97133ce9f8  vmovaps xmm10, [rsp+0xA0]
00007e97133cea01  vmovaps xmm11, [rsp+0xB0]
00007e97133cea0a  vmovaps xmm12, [rsp+0xC0]
00007e97133cea13  vmovaps xmm14, [rsp+0xD0]
00007e97133cea1c  vmovaps xmm15, [rsp+0xE0]
00007e97133cea25  add rsp, 0xF0
00007e97133cea2c  pop r11
00007e97133cea2e  pop r10
00007e97133cea30  pop r9
00007e97133cea32  pop r8
00007e97133cea34  pop rsi
00007e97133cea35  pop rdi
00007e97133cea36  pop rdx
00007e97133cea37  pop rcx
00007e97133cea38  pop rax
00007e97133cea39  add rsp, 0x08
00007e97133cea3d  jmp 0x00007E97133CE81B
00007e97133cea42  call 0x00007E971320C380
00007e97133cea47  jmp 0x00007E97133CE82E
00007e97133cea4c  sub rsp, 0x08
00007e97133cea50  push rax
00007e97133cea51  push rcx
00007e97133cea52  push rdx
00007e97133cea53  push rdi
00007e97133cea54  push rsi
00007e97133cea55  push r8
00007e97133cea57  push r9
00007e97133cea59  push r10
00007e97133cea5b  push r11
00007e97133cea5d  sub rsp, 0xF0
00007e97133cea64  vmovaps [rsp], xmm0
00007e97133cea69  vmovaps [rsp+0x10], xmm2
00007e97133cea6f  vmovaps [rsp+0x20], xmm3
00007e97133cea75  vmovaps [rsp+0x30], xmm4
00007e97133cea7b  vmovaps [rsp+0x40], xmm5
00007e97133cea81  vmovaps [rsp+0x50], xmm6
00007e97133cea87  vmovaps [rsp+0x60], xmm7
00007e97133cea8d  vmovaps [rsp+0x70], xmm8
00007e97133cea93  vmovaps [rsp+0x80], xmm9
00007e97133cea9c  vmovaps [rsp+0x90], xmm10
00007e97133ceaa5  vmovaps [rsp+0xA0], xmm11
00007e97133ceaae  vmovaps [rsp+0xB0], xmm12
00007e97133ceab7  vmovaps [rsp+0xC0], xmm13
00007e97133ceac0  vmovaps [rsp+0xD0], xmm14
00007e97133ceac9  vmovaps [rsp+0xE0], xmm15
00007e97133cead2  sub rsp, 0x30
00007e97133cead6  movaps [rsp], xmm1
00007e97133ceada  movaps [rsp+0x10], xmm14
00007e97133ceae0  movaps [rsp+0x20], xmm15
00007e97133ceae6  lea rdi, [rsp]
00007e97133ceaea  mov esi, 0x00
00007e97133ceaef  mov rax, 0x58D8AED5F530
00007e97133ceaf9  call rax
00007e97133ceafb  movaps xmm1, [rsp]
00007e97133ceaff  add rsp, 0x30
00007e97133ceb03  vmovaps xmm0, [rsp]
00007e97133ceb08  vmovaps xmm2, [rsp+0x10]
00007e97133ceb0e  vmovaps xmm3, [rsp+0x20]
00007e97133ceb14  vmovaps xmm4, [rsp+0x30]
00007e97133ceb1a  vmovaps xmm5, [rsp+0x40]
00007e97133ceb20  vmovaps xmm6, [rsp+0x50]
00007e97133ceb26  vmovaps xmm7, [rsp+0x60]
00007e97133ceb2c  vmovaps xmm8, [rsp+0x70]
00007e97133ceb32  vmovaps xmm9, [rsp+0x80]
00007e97133ceb3b  vmovaps xmm10, [rsp+0x90]
00007e97133ceb44  vmovaps xmm11, [rsp+0xA0]
00007e97133ceb4d  vmovaps xmm12, [rsp+0xB0]
00007e97133ceb56  vmovaps xmm13, [rsp+0xC0]
00007e97133ceb5f  vmovaps xmm14, [rsp+0xD0]
00007e97133ceb68  vmovaps xmm15, [rsp+0xE0]
00007e97133ceb71  add rsp, 0xF0
00007e97133ceb78  pop r11
00007e97133ceb7a  pop r10
00007e97133ceb7c  pop r9
00007e97133ceb7e  pop r8
00007e97133ceb80  pop rsi
00007e97133ceb81  pop rdi
00007e97133ceb82  pop rdx
00007e97133ceb83  pop rcx
00007e97133ceb84  pop rax
00007e97133ceb85  add rsp, 0x08
00007e97133ceb89  jmp 0x00007E97133CE848
00007e97133ceb8e  call 0x00007E97131FF540
00007e97133ceb93  jmp 0x00007E97133CE85B
00007e97133ceb98  int3
00007e97133ceb99  nop [rax], eax
00007e97133ceba0  movaps xmm1, [r15+0x180]
00007e97133ceba8  vpmovqd xmm15, xmm1
00007e97133cebae  pxor xmm14, xmm14
00007e97133cebb3  punpcklqdq xmm15, xmm14
00007e97133cebb8  movaps [r15+0x210], xmm15
00007e97133cebc0  movq xmm15, qword ptr [r15+0x120]
00007e97133cebc9  movq xmm14, qword ptr [r15+0x130]
00007e97133cebd2  psubd xmm15, xmm14
00007e97133cebd7  movq xmm15, xmm15
00007e97133cebdc  movaps xmm13, [r15+0x170]
00007e97133cebe4  paddq xmm1, xmm13
00007e97133cebe9  movaps [r15+0x180], xmm1
00007e97133cebf1  movq xmm1, qword ptr [r15+0x150]
00007e97133cebfa  paddd xmm14, xmm1
00007e97133cebff  movq xmm14, xmm14
00007e97133cec04  movq xmm14, xmm14
00007e97133cec09  movaps [r15+0x130], xmm14
00007e97133cec11  pmovzxdq xmm15, xmm15
00007e97133cec17  psllq xmm15, 0x00
00007e97133cec1d  movq xmm1, qword ptr [r15+0x210]
00007e97133cec26  movq xmm14, qword ptr [r15+0x110]
00007e97133cec2f  paddd xmm1, xmm14
00007e97133cec34  movq xmm1, xmm1
00007e97133cec38  vcvtuqq2pd xmm15, xmm15
00007e97133cec3e  pmovzxdq xmm1, xmm1
00007e97133cec43  psllq xmm1, 0x00
00007e97133cec48  vcvtuqq2pd xmm1, xmm1
00007e97133cec4e  movaps xmm14, [r15+0x140]
00007e97133cec56  movaps xmm13, xmm15
00007e97133cec5a  mulpd xmm13, xmm14
00007e97133cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007e97133cec65  ptest xmm12, xmm12
00007e97133cec6b  jnz 0x00007E97133CED4E
00007e97133cec71  movaps [r15+0x220], xmm13
00007e97133cec79  mov rax, [r15+0x48]
00007e97133cec7d  mov r14, [r15+0x50]
00007e97133cec81  lea r12, [r14+rax*1]
00007e97133cec85  movups [r13+r12*1], xmm13
00007e97133cec8b  movaps xmm15, [r15+0x160]
00007e97133cec93  movaps xmm14, xmm1
00007e97133cec97  mulpd xmm14, xmm15
00007e97133cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007e97133ceca2  ptest xmm13, xmm13
00007e97133ceca8  jnz 0x00007E97133CEE9C
00007e97133cecae  movaps [r15+0x210], xmm14
00007e97133cecb6  mov r14, [r15+0x40]
00007e97133cecba  lea r12, [r14+rax*1]
00007e97133cecbe  movups [r13+r12*1], xmm14
00007e97133cecc4  lea r14, [rax+0x10]
00007e97133cecc8  mov [r15+0x48], r14
00007e97133ceccc  xor eax, eax
00007e97133cecce  mov r12d, 0x200
00007e97133cecd4  cmp r14, r12
00007e97133cecd7  cmc
00007e97133cecd8  lahf
00007e97133cecd9  seto al
00007e97133cecdc  mov [r15+0x108], eax
00007e97133cece3  mov eax, [r15+0x108]
00007e97133cecea  sahf
00007e97133ceceb  jnz 0x00007E97133CED1D
00007e97133ceced  cmp dword ptr [r15+0x318], 0x00
00007e97133cecf5  jz 0x00007E97133CEFF0
00007e97133cecfb  nop [rax+rax*1], ax
00007e97133ced04  nop [rax+rax*1], eax
00007e97133ced0c  mov eax, 0x4101EC
00007e97133ced11  mov [r15+0x100], rax
00007e97133ced18  jmp 0x00007E97131FE110
00007e97133ced1d  cmp dword ptr [r15+0x318], 0x00
00007e97133ced25  jz 0x00007E97133CEBA0
00007e97133ced2b  nop [rax+rax*1], ax
00007e97133ced34  nop [rax+rax*1], eax
00007e97133ced3c  mov eax, 0x4101AC
00007e97133ced41  mov [r15+0x100], rax
00007e97133ced48  jmp 0x00007E97131FE110
00007e97133ced4d  int3
00007e97133ced4e  sub rsp, 0x08
00007e97133ced52  push rax
00007e97133ced53  push rcx
00007e97133ced54  push rdx
00007e97133ced55  push rdi
00007e97133ced56  push rsi
00007e97133ced57  push r8
00007e97133ced59  push r9
00007e97133ced5b  push r10
00007e97133ced5d  push r11
00007e97133ced5f  sub rsp, 0xF0
00007e97133ced66  vmovaps [rsp], xmm0
00007e97133ced6b  vmovaps [rsp+0x10], xmm1
00007e97133ced71  vmovaps [rsp+0x20], xmm2
00007e97133ced77  vmovaps [rsp+0x30], xmm3
00007e97133ced7d  vmovaps [rsp+0x40], xmm4
00007e97133ced83  vmovaps [rsp+0x50], xmm5
00007e97133ced89  vmovaps [rsp+0x60], xmm6
00007e97133ced8f  vmovaps [rsp+0x70], xmm7
00007e97133ced95  vmovaps [rsp+0x80], xmm8
00007e97133ced9e  vmovaps [rsp+0x90], xmm9
00007e97133ceda7  vmovaps [rsp+0xA0], xmm10
00007e97133cedb0  vmovaps [rsp+0xB0], xmm11
00007e97133cedb9  vmovaps [rsp+0xC0], xmm12
00007e97133cedc2  vmovaps [rsp+0xD0], xmm14
00007e97133cedcb  vmovaps [rsp+0xE0], xmm15
00007e97133cedd4  sub rsp, 0x30
00007e97133cedd8  movaps [rsp], xmm13
00007e97133ceddd  movaps [rsp+0x10], xmm15
00007e97133cede3  movaps [rsp+0x20], xmm14
00007e97133cede9  lea rdi, [rsp]
00007e97133ceded  mov esi, 0x00
00007e97133cedf2  mov rax, 0x58D8AED5F530
00007e97133cedfc  call rax
00007e97133cedfe  movaps xmm13, [rsp]
00007e97133cee03  add rsp, 0x30
00007e97133cee07  vmovaps xmm0, [rsp]
00007e97133cee0c  vmovaps xmm1, [rsp+0x10]
00007e97133cee12  vmovaps xmm2, [rsp+0x20]
00007e97133cee18  vmovaps xmm3, [rsp+0x30]
00007e97133cee1e  vmovaps xmm4, [rsp+0x40]
00007e97133cee24  vmovaps xmm5, [rsp+0x50]
00007e97133cee2a  vmovaps xmm6, [rsp+0x60]
00007e97133cee30  vmovaps xmm7, [rsp+0x70]
00007e97133cee36  vmovaps xmm8, [rsp+0x80]
00007e97133cee3f  vmovaps xmm9, [rsp+0x90]
00007e97133cee48  vmovaps xmm10, [rsp+0xA0]
00007e97133cee51  vmovaps xmm11, [rsp+0xB0]
00007e97133cee5a  vmovaps xmm12, [rsp+0xC0]
00007e97133cee63  vmovaps xmm14, [rsp+0xD0]
00007e97133cee6c  vmovaps xmm15, [rsp+0xE0]
00007e97133cee75  add rsp, 0xF0
00007e97133cee7c  pop r11
00007e97133cee7e  pop r10
00007e97133cee80  pop r9
00007e97133cee82  pop r8
00007e97133cee84  pop rsi
00007e97133cee85  pop rdi
00007e97133cee86  pop rdx
00007e97133cee87  pop rcx
00007e97133cee88  pop rax
00007e97133cee89  add rsp, 0x08
00007e97133cee8d  jmp 0x00007E97133CEC71
00007e97133cee92  call 0x00007E97132C2240
00007e97133cee97  jmp 0x00007E97133CEC8B
00007e97133cee9c  sub rsp, 0x08
00007e97133ceea0  push rax
00007e97133ceea1  push rcx
00007e97133ceea2  push rdx
00007e97133ceea3  push rdi
00007e97133ceea4  push rsi
00007e97133ceea5  push r8
00007e97133ceea7  push r9
00007e97133ceea9  push r10
00007e97133ceeab  push r11
00007e97133ceead  sub rsp, 0xF0
00007e97133ceeb4  vmovaps [rsp], xmm0
00007e97133ceeb9  vmovaps [rsp+0x10], xmm1
00007e97133ceebf  vmovaps [rsp+0x20], xmm2
00007e97133ceec5  vmovaps [rsp+0x30], xmm3
00007e97133ceecb  vmovaps [rsp+0x40], xmm4
00007e97133ceed1  vmovaps [rsp+0x50], xmm5
00007e97133ceed7  vmovaps [rsp+0x60], xmm6
00007e97133ceedd  vmovaps [rsp+0x70], xmm7
00007e97133ceee3  vmovaps [rsp+0x80], xmm8
00007e97133ceeec  vmovaps [rsp+0x90], xmm9
00007e97133ceef5  vmovaps [rsp+0xA0], xmm10
00007e97133ceefe  vmovaps [rsp+0xB0], xmm11
00007e97133cef07  vmovaps [rsp+0xC0], xmm12
00007e97133cef10  vmovaps [rsp+0xD0], xmm13
00007e97133cef19  vmovaps [rsp+0xE0], xmm15
00007e97133cef22  sub rsp, 0x30
00007e97133cef26  movaps [rsp], xmm14
00007e97133cef2b  movaps [rsp+0x10], xmm1
00007e97133cef30  movaps [rsp+0x20], xmm15
00007e97133cef36  lea rdi, [rsp]
00007e97133cef3a  mov esi, 0x00
00007e97133cef3f  mov rax, 0x58D8AED5F530
00007e97133cef49  call rax
00007e97133cef4b  movaps xmm14, [rsp]
00007e97133cef50  add rsp, 0x30
00007e97133cef54  vmovaps xmm0, [rsp]
00007e97133cef59  vmovaps xmm1, [rsp+0x10]
00007e97133cef5f  vmovaps xmm2, [rsp+0x20]
00007e97133cef65  vmovaps xmm3, [rsp+0x30]
00007e97133cef6b  vmovaps xmm4, [rsp+0x40]
00007e97133cef71  vmovaps xmm5, [rsp+0x50]
00007e97133cef77  vmovaps xmm6, [rsp+0x60]
00007e97133cef7d  vmovaps xmm7, [rsp+0x70]
00007e97133cef83  vmovaps xmm8, [rsp+0x80]
00007e97133cef8c  vmovaps xmm9, [rsp+0x90]
00007e97133cef95  vmovaps xmm10, [rsp+0xA0]
00007e97133cef9e  vmovaps xmm11, [rsp+0xB0]
00007e97133cefa7  vmovaps xmm12, [rsp+0xC0]
00007e97133cefb0  vmovaps xmm13, [rsp+0xD0]
00007e97133cefb9  vmovaps xmm15, [rsp+0xE0]
00007e97133cefc2  add rsp, 0xF0
00007e97133cefc9  pop r11
00007e97133cefcb  pop r10
00007e97133cefcd  pop r9
00007e97133cefcf  pop r8
00007e97133cefd1  pop rsi
00007e97133cefd2  pop rdi
00007e97133cefd3  pop rdx
00007e97133cefd4  pop rcx
00007e97133cefd5  pop rax
00007e97133cefd6  add rsp, 0x08
00007e97133cefda  jmp 0x00007E97133CECAE
00007e97133cefdf  call 0x00007E97132C34C0
00007e97133cefe4  jmp 0x00007E97133CECC4
00007e97133cefe9  int3
00007e97133cefea  nop [rax+rax*1], ax
00007e97133ceff0  mov rax, [r15+0xF8]
00007e97133ceff7  lea r14, [rax-0x150]
00007e97133ceffe  mov [r15+0xF8], r14
00007e97133cf005  mov rax, [r15+0x50]
00007e97133cf009  lea r12, [rax+0x80]
00007e97133cf010  movups xmm1, [r13+r12*1]
00007e97133cf016  lea r12, [rax+0x90]
00007e97133cf01d  movups xmm15, [r13+r12*1]
00007e97133cf023  mov qword ptr [r15+0x48], 0x00
00007e97133cf02b  lea r12, [rax+0x40]
00007e97133cf02f  movups xmm14, [r13+r12*1]
00007e97133cf035  lea r12, [rax+0x50]
00007e97133cf039  movups xmm13, [r13+r12*1]
00007e97133cf03f  lea r12, [r14+0x120]
00007e97133cf046  movq xmm12, qword ptr [r15+0x1C0]
00007e97133cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007e97133cf058  movq r11, xmm12
00007e97133cf05d  movq r10, xmm11
00007e97133cf062  mov [r13+r12*1], r11
00007e97133cf067  lea r12, [r14+0x128]
00007e97133cf06e  mov [r13+r12*1], r10
00007e97133cf073  vxorps xmm12, xmm12, xmm12
00007e97133cf078  vpbroadcastq xmm12, xmm12
00007e97133cf07d  lea r12, [r14+0x100]
00007e97133cf084  movq xmm11, qword ptr [r15+0x200]
00007e97133cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007e97133cf096  movq r11, xmm11
00007e97133cf09b  movq r10, xmm10
00007e97133cf0a0  mov [r13+r12*1], r11
00007e97133cf0a5  lea r12, [r14+0x108]
00007e97133cf0ac  mov [r13+r12*1], r10
00007e97133cf0b1  lea r12, [r14+0xE0]
00007e97133cf0b8  movups [r13+r12*1], xmm15
00007e97133cf0be  lea r12, [r14+0xF0]
00007e97133cf0c5  movups [r13+r12*1], xmm1
00007e97133cf0cb  lea r12, [rax+0xC0]
00007e97133cf0d2  movups xmm1, [r13+r12*1]
00007e97133cf0d8  lea r12, [rax+0xD0]
00007e97133cf0df  movups xmm15, [r13+r12*1]
00007e97133cf0e5  lea r12, [r14+0x110]
00007e97133cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007e97133cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007e97133cf0fe  movq r11, xmm11
00007e97133cf103  movq r10, xmm10
00007e97133cf108  mov [r13+r12*1], r11
00007e97133cf10d  lea r12, [r14+0x118]
00007e97133cf114  mov [r13+r12*1], r10
00007e97133cf119  movups xmm11, [r13+rax*1]
00007e97133cf11f  lea r12, [rax+0x10]
00007e97133cf123  movups xmm10, [r13+r12*1]
00007e97133cf129  lea r12, [r14+0x130]
00007e97133cf130  movq xmm9, qword ptr [r15+0x1A0]
00007e97133cf139  movq xmm8, qword ptr [r15+0x190]
00007e97133cf142  movq r11, xmm9
00007e97133cf147  movq r10, xmm8
00007e97133cf14c  mov [r13+r12*1], r11
00007e97133cf151  lea r12, [r14+0x138]
00007e97133cf158  mov [r13+r12*1], r10
00007e97133cf15d  lea r12, [rax+0x140]
00007e97133cf164  movups xmm9, [r13+r12*1]
00007e97133cf16a  lea r12, [rax+0x150]
00007e97133cf171  movups xmm8, [r13+r12*1]
00007e97133cf177  lea r12, [r14+0xC0]
00007e97133cf17e  movups [r13+r12*1], xmm15
00007e97133cf184  lea r12, [r14+0xD0]
00007e97133cf18b  movups [r13+r12*1], xmm1
00007e97133cf191  lea r12, [rax+0x100]
00007e97133cf198  movups xmm1, [r13+r12*1]
00007e97133cf19e  lea r12, [rax+0x110]
00007e97133cf1a5  movups xmm15, [r13+r12*1]
00007e97133cf1ab  lea r12, [r14+0x140]
00007e97133cf1b2  mov r11, [r15+0xE8]
00007e97133cf1b9  mov [r13+r12*1], r11
00007e97133cf1be  lea r12, [rax+0x180]
00007e97133cf1c5  movups xmm7, [r13+r12*1]
00007e97133cf1cb  lea r12, [rax+0x190]
00007e97133cf1d2  movups xmm6, [r13+r12*1]
00007e97133cf1d8  lea r12, [rax+0x1C0]
00007e97133cf1df  movups xmm5, [r13+r12*1]
00007e97133cf1e5  lea r12, [rax+0x1D0]
00007e97133cf1ec  movups xmm4, [r13+r12*1]
00007e97133cf1f2  lea r12, [r14+0x20]
00007e97133cf1f6  movups [r13+r12*1], xmm1
00007e97133cf1fc  lea r12, [r14+0x30]
00007e97133cf200  movups [r13+r12*1], xmm13
00007e97133cf206  lea r12, [rax+0x60]
00007e97133cf20a  movups xmm1, [r13+r12*1]
00007e97133cf210  lea r12, [rax+0x70]
00007e97133cf214  movups xmm13, [r13+r12*1]
00007e97133cf21a  lea r12, [rax+0x20]
00007e97133cf21e  movups xmm3, [r13+r12*1]
00007e97133cf224  lea r12, [rax+0x30]
00007e97133cf228  movups xmm2, [r13+r12*1]
00007e97133cf22e  movaps [r15+0x1F0], xmm2
00007e97133cf236  lea r12, [r14+0x60]
00007e97133cf23a  movups [r13+r12*1], xmm11
00007e97133cf240  lea r12, [r14+0x70]
00007e97133cf244  movups [r13+r12*1], xmm5
00007e97133cf24a  lea r12, [rax+0xE0]
00007e97133cf251  movups xmm11, [r13+r12*1]
00007e97133cf257  lea r12, [rax+0xF0]
00007e97133cf25e  movups xmm5, [r13+r12*1]
00007e97133cf264  lea r12, [r14+0xA0]
00007e97133cf26b  movups [r13+r12*1], xmm13
00007e97133cf271  lea r12, [r14+0xB0]
00007e97133cf278  movups [r13+r12*1], xmm1
00007e97133cf27e  lea r12, [rax+0xA0]
00007e97133cf285  movups xmm1, [r13+r12*1]
00007e97133cf28b  lea r12, [rax+0xB0]
00007e97133cf292  movups xmm13, [r13+r12*1]
00007e97133cf298  lea r12, [rax+0x120]
00007e97133cf29f  vmovaps [rsp+0x10], xmm1
00007e97133cf2a5  movups xmm1, [r13+r12*1]
00007e97133cf2ab  lea r12, [rax+0x130]
00007e97133cf2b2  vmovaps [rsp+0x20], xmm1
00007e97133cf2b8  movups xmm1, [r13+r12*1]
00007e97133cf2be  lea r12, [rax+0x160]
00007e97133cf2c5  vmovaps [rsp+0x30], xmm1
00007e97133cf2cb  movups xmm1, [r13+r12*1]
00007e97133cf2d1  lea r12, [rax+0x170]
00007e97133cf2d8  vmovaps [rsp+0x40], xmm1
00007e97133cf2de  movups xmm1, [r13+r12*1]
00007e97133cf2e4  movaps [r15+0x2B0], xmm1
00007e97133cf2ec  lea r12, [r14+0x80]
00007e97133cf2f3  movups [r13+r12*1], xmm13
00007e97133cf2f9  lea r12, [r14+0x90]
00007e97133cf300  vmovaps xmm13, [rsp+0x10]
00007e97133cf306  movups [r13+r12*1], xmm13
00007e97133cf30c  lea r12, [rax+0x1A0]
00007e97133cf313  movups xmm13, [r13+r12*1]
00007e97133cf319  lea r12, [rax+0x1B0]
00007e97133cf320  vmovaps [rsp+0x10], xmm1
00007e97133cf326  movups xmm1, [r13+r12*1]
00007e97133cf32c  movaps [r15+0x290], xmm13
00007e97133cf334  movaps [r15+0x1E0], xmm1
00007e97133cf33c  lea r12, [rax+0x1E0]
00007e97133cf343  vmovaps [rsp+0x50], xmm1
00007e97133cf349  movups xmm1, [r13+r12*1]
00007e97133cf34f  lea r12, [rax+0x1F0]
00007e97133cf356  vmovaps [rsp+0x60], xmm1
00007e97133cf35c  movups xmm1, [r13+r12*1]
00007e97133cf362  mov qword ptr [r15+0x50], 0x430920
00007e97133cf36a  lea rax, [r14+0x40]
00007e97133cf36e  vmovaps [rsp+0x70], xmm1
00007e97133cf374  vmovaps xmm1, [rsp+0x40]
00007e97133cf37a  movups [r13+rax*1], xmm1
00007e97133cf380  lea rax, [r14+0x50]
00007e97133cf384  movups [r13+rax*1], xmm10
00007e97133cf38a  vmovaps xmm1, [rsp+0x70]
00007e97133cf390  movups [r13+r14*1], xmm1
00007e97133cf396  lea rax, [r14+0x10]
00007e97133cf39a  vmovaps xmm1, [rsp+0x60]
00007e97133cf3a0  movups [r13+rax*1], xmm1
00007e97133cf3a6  mov rax, [r15+0x40]
00007e97133cf3aa  vmovaps [rsp+0x40], xmm3
00007e97133cf3b0  vmovaps xmm1, [rsp+0x40]
00007e97133cf3b6  por xmm3, xmm1
00007e97133cf3ba  vmovaps [rsp+0x40], xmm6
00007e97133cf3c0  vmovaps xmm10, [rsp+0x40]
00007e97133cf3c6  por xmm6, xmm10
00007e97133cf3cb  lea r12, [rax+0x30]
00007e97133cf3cf  mov r11, [r13+r12*1]
00007e97133cf3d4  lea r12, [rax+0x38]
00007e97133cf3d8  mov r10, [r13+r12*1]
00007e97133cf3dd  movq xmm10, r11
00007e97133cf3e2  vmovaps [rsp+0x40], xmm1
00007e97133cf3e8  movq xmm1, r10
00007e97133cf3ed  movq xmm10, xmm10
00007e97133cf3f2  vmovaps [rsp+0x60], xmm10
00007e97133cf3f8  movq xmm10, xmm10
00007e97133cf3fd  movaps [r15+0x130], xmm10
00007e97133cf405  movq xmm1, xmm1
00007e97133cf409  vmovaps [rsp+0x70], xmm1
00007e97133cf40f  movq xmm1, xmm1
00007e97133cf413  movaps [r15+0x280], xmm1
00007e97133cf41b  vmovaps [rsp+0x80], xmm9
00007e97133cf424  vmovaps xmm1, [rsp+0x80]
00007e97133cf42d  por xmm9, xmm1
00007e97133cf432  lea r12, [rax+0x20]
00007e97133cf436  mov r11, [r13+r12*1]
00007e97133cf43b  lea r12, [rax+0x28]
00007e97133cf43f  mov r10, [r13+r12*1]
00007e97133cf444  movq xmm1, r11
00007e97133cf449  movq xmm10, r10
00007e97133cf44e  movq xmm1, xmm1
00007e97133cf452  vmovaps [rsp+0x80], xmm1
00007e97133cf45b  movq xmm1, xmm1
00007e97133cf45f  movaps [r15+0x150], xmm1
00007e97133cf467  movq xmm10, xmm10
00007e97133cf46c  vmovaps [rsp+0x90], xmm10
00007e97133cf475  movq xmm10, xmm10
00007e97133cf47a  movaps [r15+0x140], xmm10
00007e97133cf482  lea r12, [rax+0x10]
00007e97133cf486  mov r11, [r13+r12*1]
00007e97133cf48b  lea r12, [rax+0x18]
00007e97133cf48f  mov r10, [r13+r12*1]
00007e97133cf494  movq xmm1, r11
00007e97133cf499  movq xmm10, r10
00007e97133cf49e  movq xmm1, xmm1
00007e97133cf4a2  vmovaps [rsp+0xA0], xmm1
00007e97133cf4ab  movq xmm1, xmm1
00007e97133cf4af  movaps [r15+0x170], xmm1
00007e97133cf4b7  movq xmm10, xmm10
00007e97133cf4bc  vmovaps [rsp+0xB0], xmm10
00007e97133cf4c5  movq xmm10, xmm10
00007e97133cf4ca  movaps [r15+0x160], xmm10
00007e97133cf4d2  mov r12, [r13+rax*1]
00007e97133cf4d7  vmovq xmm1, r12
00007e97133cf4dc  vpbroadcastq xmm1, xmm1
00007e97133cf4e1  lea r12, [rax+0x08]
00007e97133cf4e5  mov rax, [r13+r12*1]
00007e97133cf4ea  movq xmm10, rax
00007e97133cf4ef  movaps [r15+0x230], xmm10
00007e97133cf4f7  lea rax, [r14+0x50]
00007e97133cf4fb  movups xmm10, [r13+rax*1]
00007e97133cf501  lea rax, [r14+0x60]
00007e97133cf505  vmovaps [rsp+0xC0], xmm1
00007e97133cf50e  movups xmm1, [r13+rax*1]
00007e97133cf514  lea rax, [r14+0x30]
00007e97133cf518  vmovaps [rsp+0xD0], xmm1
00007e97133cf521  movups xmm1, [r13+rax*1]
00007e97133cf527  mov qword ptr [r15+0x60], 0x430920
00007e97133cf52f  mov qword ptr [r15+0x58], 0x40
00007e97133cf537  vmovaps [rsp+0xE0], xmm1
00007e97133cf540  vmovaps [rsp+0xF0], xmm15
00007e97133cf549  vmovaps xmm15, [rsp+0xC0]
00007e97133cf552  vmovaps [rsp+0xC0], xmm14
00007e97133cf55b  vmovaps xmm14, [rsp+0x40]
00007e97133cf561  vmovaps [rsp+0x40], xmm13
00007e97133cf567  movaps xmm1, xmm15
00007e97133cf56b  mulpd xmm1, xmm14
00007e97133cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007e97133cf575  ptest xmm13, xmm13
00007e97133cf57b  jnz 0x00007E97133D0682
00007e97133cf581  movq xmm14, qword ptr [r15+0x230]
00007e97133cf58a  vmovaps [rsp+0x100], xmm14
00007e97133cf593  vpermilpd xmm14, xmm14, 0x00
00007e97133cf599  vmovaps [rsp+0x110], xmm1
00007e97133cf5a2  vmovaps xmm1, [rsp+0xE0]
00007e97133cf5ab  vmovaps [rsp+0xE0], xmm15
00007e97133cf5b4  movaps xmm13, xmm1
00007e97133cf5b8  mulpd xmm13, xmm14
00007e97133cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007e97133cf5c3  ptest xmm15, xmm15
00007e97133cf5c9  jnz 0x00007E97133D07C4
00007e97133cf5cf  vxorps xmm1, xmm1, xmm1
00007e97133cf5d3  vpbroadcastq xmm1, xmm1
00007e97133cf5d8  vmovaps xmm14, [rsp+0xE0]
00007e97133cf5e1  vmovaps [rsp+0xE0], xmm1
00007e97133cf5ea  vmovaps xmm1, [rsp+0xD0]
00007e97133cf5f3  vmovaps [rsp+0xD0], xmm13
00007e97133cf5fc  movaps xmm15, xmm14
00007e97133cf600  mulpd xmm15, xmm1
00007e97133cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007e97133cf60b  ptest xmm13, xmm13
00007e97133cf611  jnz 0x00007E97133D0907
00007e97133cf617  movaps xmm1, xmm14
00007e97133cf61b  mulpd xmm1, xmm10
00007e97133cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007e97133cf625  ptest xmm13, xmm13
00007e97133cf62b  jnz 0x00007E97133D0A4A
00007e97133cf631  movaps xmm13, xmm14
00007e97133cf635  mulpd xmm13, xmm2
00007e97133cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007e97133cf640  ptest xmm10, xmm10
00007e97133cf646  jnz 0x00007E97133D0B8C
00007e97133cf64c  vmovaps [rsp+0x120], xmm7
00007e97133cf655  vmovaps xmm14, [rsp+0x120]
00007e97133cf65e  por xmm7, xmm14
00007e97133cf663  vmovaps xmm14, [rsp+0xC0]
00007e97133cf66c  vmovaps xmm10, [rsp+0xC0]
00007e97133cf675  por xmm14, xmm10
00007e97133cf67a  vmovaps xmm2, [rsp+0x100]
00007e97133cf683  vpermilpd xmm2, xmm2, 0x00
00007e97133cf689  vmovaps [rsp+0xC0], xmm1
00007e97133cf692  vmovaps [rsp+0x120], xmm15
00007e97133cf69b  movaps xmm1, xmm10
00007e97133cf69f  mulpd xmm1, xmm2
00007e97133cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007e97133cf6a8  ptest xmm15, xmm15
00007e97133cf6ae  jnz 0x00007E97133D0CCF
00007e97133cf6b4  xor eax, eax
00007e97133cf6b6  mov r12d, 0x40
00007e97133cf6bc  mov r11d, 0x200
00007e97133cf6c2  cmp r12, r11
00007e97133cf6c5  cmc
00007e97133cf6c6  lahf
00007e97133cf6c7  seto al
00007e97133cf6ca  mov [r15+0x108], eax
00007e97133cf6d1  vmovaps xmm10, [rsp+0x110]
00007e97133cf6da  vmovaps xmm2, [rsp+0xE0]
00007e97133cf6e3  vmovaps [rsp+0xE0], xmm1
00007e97133cf6ec  movaps xmm15, xmm10
00007e97133cf6f0  addpd xmm15, xmm2
00007e97133cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007e97133cf6fb  ptest xmm1, xmm1
00007e97133cf700  jnz 0x00007E97133D0E10
00007e97133cf706  vmovaps xmm10, [rsp+0x120]
00007e97133cf70f  vmovaps [rsp+0x110], xmm15
00007e97133cf718  movaps xmm1, xmm10
00007e97133cf71c  addpd xmm1, xmm12
00007e97133cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007e97133cf726  ptest xmm15, xmm15
00007e97133cf72c  jnz 0x00007E97133D0F53
00007e97133cf732  vmovaps xmm10, [rsp+0xC0]
00007e97133cf73b  vmovaps [rsp+0xC0], xmm1
00007e97133cf744  movaps xmm15, xmm10
00007e97133cf748  addpd xmm15, xmm12
00007e97133cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007e97133cf753  ptest xmm1, xmm1
00007e97133cf758  jnz 0x00007E97133D1095
00007e97133cf75e  vmovaps xmm1, [rsp+0x30]
00007e97133cf764  vmovaps xmm12, [rsp+0x30]
00007e97133cf76a  por xmm1, xmm12
00007e97133cf76f  vmovaps xmm12, [rsp+0x20]
00007e97133cf775  vmovaps xmm10, [rsp+0x20]
00007e97133cf77b  por xmm12, xmm10
00007e97133cf780  vmovaps [rsp+0x20], xmm5
00007e97133cf786  vmovaps xmm10, [rsp+0x20]
00007e97133cf78c  por xmm5, xmm10
00007e97133cf791  vmovaps [rsp+0x20], xmm11
00007e97133cf797  vmovaps xmm10, [rsp+0x20]
00007e97133cf79d  por xmm11, xmm10
00007e97133cf7a2  vmovaps [rsp+0x20], xmm4
00007e97133cf7a8  vmovaps xmm10, [rsp+0x20]
00007e97133cf7ae  por xmm4, xmm10
00007e97133cf7b3  vmovaps [rsp+0x20], xmm8
00007e97133cf7b9  vmovaps xmm10, [rsp+0x20]
00007e97133cf7bf  por xmm8, xmm10
00007e97133cf7c4  vmovaps xmm10, [rsp+0xF0]
00007e97133cf7cd  vmovaps [rsp+0x20], xmm1
00007e97133cf7d3  vmovaps xmm1, [rsp+0xF0]
00007e97133cf7dc  por xmm10, xmm1
00007e97133cf7e1  lea rax, [r14+0xA0]
00007e97133cf7e8  movups xmm1, [r13+rax*1]
00007e97133cf7ee  lea rax, [r14+0xB0]
00007e97133cf7f5  vmovaps [rsp+0x30], xmm1
00007e97133cf7fb  movups xmm1, [r13+rax*1]
00007e97133cf801  vmovaps [rsp+0xF0], xmm1
00007e97133cf80a  vmovaps [rsp+0x120], xmm15
00007e97133cf813  movaps xmm1, xmm13
00007e97133cf817  addpd xmm1, xmm2
00007e97133cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007e97133cf820  ptest xmm15, xmm15
00007e97133cf826  jnz 0x00007E97133D11ED
00007e97133cf82c  lea rax, [r14+0xF0]
00007e97133cf833  movups xmm15, [r13+rax*1]
00007e97133cf839  vmovaps xmm2, [rsp+0xC0]
00007e97133cf842  vmovaps [rsp+0xC0], xmm1
00007e97133cf84b  vmovaps xmm1, [rsp+0xE0]
00007e97133cf854  vmovaps [rsp+0xE0], xmm15
00007e97133cf85d  movaps xmm13, xmm2
00007e97133cf861  addpd xmm13, xmm1
00007e97133cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007e97133cf86c  ptest xmm15, xmm15
00007e97133cf872  jnz 0x00007E97133D1338
00007e97133cf878  vmovaps xmm15, [rsp+0x120]
00007e97133cf881  vmovaps xmm2, [rsp+0xD0]
00007e97133cf88a  vmovaps [rsp+0xD0], xmm14
00007e97133cf893  movaps xmm1, xmm15
00007e97133cf897  addpd xmm1, xmm2
00007e97133cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007e97133cf8a0  ptest xmm14, xmm14
00007e97133cf8a6  jnz 0x00007E97133D147A
00007e97133cf8ac  vmovaps xmm15, [rsp+0x100]
00007e97133cf8b5  vpermilpd xmm15, xmm15, 0x00
00007e97133cf8bb  vmovaps xmm2, [rsp+0xF0]
00007e97133cf8c4  vmovaps [rsp+0xF0], xmm1
00007e97133cf8cd  movaps xmm14, xmm2
00007e97133cf8d1  mulpd xmm14, xmm15
00007e97133cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007e97133cf8dc  ptest xmm1, xmm1
00007e97133cf8e1  jnz 0x00007E97133D15BB
00007e97133cf8e7  vmovaps xmm1, [rsp+0xA0]
00007e97133cf8f0  vpermilpd xmm1, xmm1, 0x00
00007e97133cf8f6  vmovaps xmm2, [rsp+0xE0]
00007e97133cf8ff  vmovaps [rsp+0xE0], xmm14
00007e97133cf908  movaps xmm15, xmm2
00007e97133cf90c  mulpd xmm15, xmm1
00007e97133cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007e97133cf917  ptest xmm14, xmm14
00007e97133cf91d  jnz 0x00007E97133D16FE
00007e97133cf923  lea rax, [r14+0xE0]
00007e97133cf92a  movups xmm1, [r13+rax*1]
00007e97133cf930  vmovaps xmm14, [rsp+0x100]
00007e97133cf939  vpermilpd xmm14, xmm14, 0x00
00007e97133cf93f  vmovaps [rsp+0x100], xmm1
00007e97133cf948  vmovaps xmm1, [rsp+0x30]
00007e97133cf94e  vmovaps [rsp+0x30], xmm15
00007e97133cf954  movaps xmm2, xmm1
00007e97133cf957  mulpd xmm2, xmm14
00007e97133cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007e97133cf961  ptest xmm15, xmm15
00007e97133cf967  jnz 0x00007E97133D184A
00007e97133cf96d  vmovaps [rsp+0x120], xmm10
00007e97133cf976  vmovaps xmm1, [rsp+0x120]
00007e97133cf97f  por xmm10, xmm1
00007e97133cf984  movaps [r15+0x300], xmm10
00007e97133cf98c  vmovaps [rsp+0x120], xmm8
00007e97133cf995  vmovaps xmm1, [rsp+0x120]
00007e97133cf99e  por xmm8, xmm1
00007e97133cf9a3  movaps [r15+0x190], xmm8
00007e97133cf9ab  vmovaps xmm1, [rsp+0xA0]
00007e97133cf9b4  vpermilpd xmm1, xmm1, 0x00
00007e97133cf9ba  vmovaps xmm14, [rsp+0x100]
00007e97133cf9c3  vmovaps [rsp+0x100], xmm13
00007e97133cf9cc  movaps xmm15, xmm14
00007e97133cf9d0  mulpd xmm15, xmm1
00007e97133cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007e97133cf9db  ptest xmm13, xmm13
00007e97133cf9e1  jnz 0x00007E97133D198B
00007e97133cf9e7  lea rax, [r14+0x90]
00007e97133cf9ee  movups xmm1, [r13+rax*1]
00007e97133cf9f4  vmovaps [rsp+0x120], xmm4
00007e97133cf9fd  vmovaps xmm14, [rsp+0x120]
00007e97133cfa06  por xmm4, xmm14
00007e97133cfa0b  movaps [r15+0x1C0], xmm4
00007e97133cfa13  vmovaps [rsp+0x120], xmm11
00007e97133cfa1c  vmovaps xmm14, [rsp+0x120]
00007e97133cfa25  por xmm11, xmm14
00007e97133cfa2a  movaps [r15+0x200], xmm11
00007e97133cfa32  vmovaps [rsp+0x120], xmm5
00007e97133cfa3b  vmovaps xmm14, [rsp+0x120]
00007e97133cfa44  por xmm5, xmm14
00007e97133cfa49  movaps [r15+0x2D0], xmm5
00007e97133cfa51  vmovaps [rsp+0x120], xmm12
00007e97133cfa5a  vmovaps xmm14, [rsp+0x120]
00007e97133cfa63  por xmm12, xmm14
00007e97133cfa68  movaps [r15+0x2E0], xmm12
00007e97133cfa70  vmovaps xmm13, [rsp+0x110]
00007e97133cfa79  vmovaps [rsp+0x110], xmm1
00007e97133cfa82  vmovaps xmm1, [rsp+0xE0]
00007e97133cfa8b  vmovaps [rsp+0xE0], xmm15
00007e97133cfa94  movaps xmm14, xmm13
00007e97133cfa98  addpd xmm14, xmm1
00007e97133cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007e97133cfaa3  ptest xmm15, xmm15
00007e97133cfaa9  jnz 0x00007E97133D1AD8
00007e97133cfaaf  vmovaps xmm1, [rsp+0xA0]
00007e97133cfab8  vpermilpd xmm1, xmm1, 0x00
00007e97133cfabe  vmovaps xmm13, [rsp+0x110]
00007e97133cfac7  vmovaps [rsp+0x110], xmm14
00007e97133cfad0  movaps xmm15, xmm13
00007e97133cfad4  mulpd xmm15, xmm1
00007e97133cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007e97133cfadf  ptest xmm14, xmm14
00007e97133cfae5  jnz 0x00007E97133D1C1B
00007e97133cfaeb  lea rax, [r14+0x80]
00007e97133cfaf2  movups xmm1, [r13+rax*1]
00007e97133cfaf8  vmovaps xmm13, [rsp+0xC0]
00007e97133cfb01  vmovaps [rsp+0xC0], xmm1
00007e97133cfb0a  movaps xmm14, xmm13
00007e97133cfb0e  addpd xmm14, xmm2
00007e97133cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007e97133cfb19  ptest xmm1, xmm1
00007e97133cfb1e  jnz 0x00007E97133D1D68
00007e97133cfb24  vmovaps xmm13, [rsp+0x100]
00007e97133cfb2d  vmovaps xmm2, [rsp+0x30]
00007e97133cfb33  vmovaps [rsp+0x30], xmm15
00007e97133cfb39  movaps xmm1, xmm13
00007e97133cfb3d  addpd xmm1, xmm2
00007e97133cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007e97133cfb46  ptest xmm15, xmm15
00007e97133cfb4c  jnz 0x00007E97133D1EAB
00007e97133cfb52  vmovaps xmm15, [rsp+0x20]
00007e97133cfb58  vmovaps xmm13, [rsp+0x20]
00007e97133cfb5e  por xmm15, xmm13
00007e97133cfb63  movaps [r15+0x2F0], xmm15
00007e97133cfb6b  vmovaps xmm13, [rsp+0xA0]
00007e97133cfb74  vpermilpd xmm13, xmm13, 0x00
00007e97133cfb7a  vmovaps [rsp+0x20], xmm1
00007e97133cfb80  vmovaps xmm1, [rsp+0xC0]
00007e97133cfb89  vmovaps [rsp+0xA0], xmm15
00007e97133cfb92  movaps xmm2, xmm1
00007e97133cfb95  mulpd xmm2, xmm13
00007e97133cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007e97133cfb9f  ptest xmm15, xmm15
00007e97133cfba5  jnz 0x00007E97133D1FEC
00007e97133cfbab  lea rax, [r14+0xD0]
00007e97133cfbb2  movups xmm1, [r13+rax*1]
00007e97133cfbb8  vmovaps xmm13, [rsp+0xF0]
00007e97133cfbc1  vmovaps [rsp+0xC0], xmm1
00007e97133cfbca  vmovaps xmm1, [rsp+0xE0]
00007e97133cfbd3  vmovaps [rsp+0xE0], xmm14
00007e97133cfbdc  movaps xmm15, xmm13
00007e97133cfbe0  addpd xmm15, xmm1
00007e97133cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007e97133cfbeb  ptest xmm14, xmm14
00007e97133cfbf1  jnz 0x00007E97133D2137
00007e97133cfbf7  vmovaps xmm1, [rsp+0xB0]
00007e97133cfc00  vpermilpd xmm1, xmm1, 0x00
00007e97133cfc06  movaps xmm14, xmm11
00007e97133cfc0a  mulpd xmm14, xmm1
00007e97133cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007e97133cfc15  ptest xmm13, xmm13
00007e97133cfc1b  jnz 0x00007E97133D227A
00007e97133cfc21  movaps [r15+0x260], xmm14
00007e97133cfc29  vxorps xmm1, xmm1, xmm1
00007e97133cfc2d  vpbroadcastq xmm1, xmm1
00007e97133cfc32  movaps [r15+0x1B0], xmm1
00007e97133cfc3a  vmovaps xmm1, [rsp+0xB0]
00007e97133cfc43  vpermilpd xmm1, xmm1, 0x00
00007e97133cfc49  vmovaps xmm11, [rsp+0xC0]
00007e97133cfc52  vmovaps [rsp+0xC0], xmm15
00007e97133cfc5b  movaps xmm13, xmm11
00007e97133cfc5f  mulpd xmm13, xmm1
00007e97133cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007e97133cfc6a  ptest xmm15, xmm15
00007e97133cfc70  jnz 0x00007E97133D23BD
00007e97133cfc76  lea rax, [r14+0xC0]
00007e97133cfc7d  movups xmm1, [r13+rax*1]
00007e97133cfc83  vmovaps xmm11, [rsp+0x110]
00007e97133cfc8c  vmovaps [rsp+0xF0], xmm1
00007e97133cfc95  vmovaps xmm1, [rsp+0x30]
00007e97133cfc9b  vmovaps [rsp+0x30], xmm14
00007e97133cfca1  movaps xmm15, xmm11
00007e97133cfca5  addpd xmm15, xmm1
00007e97133cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007e97133cfcb0  ptest xmm14, xmm14
00007e97133cfcb6  jnz 0x00007E97133D250A
00007e97133cfcbc  vmovaps [rsp+0x100], xmm9
00007e97133cfcc5  vmovaps xmm1, [rsp+0x100]
00007e97133cfcce  por xmm9, xmm1
00007e97133cfcd3  movaps [r15+0x270], xmm9
00007e97133cfcdb  vmovaps [rsp+0x100], xmm6
00007e97133cfce4  vmovaps xmm1, [rsp+0x100]
00007e97133cfced  por xmm6, xmm1
00007e97133cfcf1  movaps [r15+0x1A0], xmm6
00007e97133cfcf9  vmovaps xmm14, [rsp+0xB0]
00007e97133cfd02  vpermilpd xmm14, xmm14, 0x00
00007e97133cfd08  vmovaps xmm6, [rsp+0xF0]
00007e97133cfd11  vmovaps [rsp+0xF0], xmm1
00007e97133cfd1a  movaps xmm11, xmm6
00007e97133cfd1e  mulpd xmm11, xmm14
00007e97133cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007e97133cfd29  ptest xmm1, xmm1
00007e97133cfd2e  jnz 0x00007E97133D264D
00007e97133cfd34  lea rax, [r14+0x20]
00007e97133cfd38  movups xmm1, [r13+rax*1]
00007e97133cfd3e  movaps [r15+0x110], xmm1
00007e97133cfd46  vmovaps xmm6, [rsp+0xE0]
00007e97133cfd4f  vmovaps [rsp+0xE0], xmm1
00007e97133cfd58  movaps xmm14, xmm6
00007e97133cfd5c  addpd xmm14, xmm2
00007e97133cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007e97133cfd67  ptest xmm1, xmm1
00007e97133cfd6c  jnz 0x00007E97133D279A
00007e97133cfd72  vmovaps xmm1, [rsp+0xB0]
00007e97133cfd7b  vpermilpd xmm1, xmm1, 0x00
00007e97133cfd81  movaps xmm6, xmm5
00007e97133cfd84  mulpd xmm6, xmm1
00007e97133cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007e97133cfd8d  ptest xmm2, xmm2
00007e97133cfd92  jnz 0x00007E97133D28DC
00007e97133cfd98  vmovaps xmm5, [rsp+0x20]
00007e97133cfd9e  movaps xmm1, xmm5
00007e97133cfda1  addpd xmm1, xmm13
00007e97133cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007e97133cfdab  ptest xmm2, xmm2
00007e97133cfdb0  jnz 0x00007E97133D2A1C
00007e97133cfdb6  vmovaps xmm13, [rsp+0x80]
00007e97133cfdbf  vpermilpd xmm13, xmm13, 0x00
00007e97133cfdc5  vmovaps xmm2, [rsp+0xE0]
00007e97133cfdce  vmovaps [rsp+0x20], xmm1
00007e97133cfdd4  movaps xmm5, xmm2
00007e97133cfdd7  mulpd xmm5, xmm13
00007e97133cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007e97133cfde1  ptest xmm1, xmm1
00007e97133cfde6  jnz 0x00007E97133D2B5D
00007e97133cfdec  vmovaps xmm1, [rsp+0x80]
00007e97133cfdf5  vpermilpd xmm1, xmm1, 0x00
00007e97133cfdfb  movaps xmm13, xmm10
00007e97133cfdff  mulpd xmm13, xmm1
00007e97133cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007e97133cfe0a  ptest xmm2, xmm2
00007e97133cfe0f  jnz 0x00007E97133D2C9E
00007e97133cfe15  vmovaps xmm10, [rsp+0x30]
00007e97133cfe1b  movaps xmm1, xmm15
00007e97133cfe1f  addpd xmm1, xmm10
00007e97133cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007e97133cfe29  ptest xmm2, xmm2
00007e97133cfe2e  jnz 0x00007E97133D2DE1
00007e97133cfe34  vmovaps xmm10, [rsp+0xC0]
00007e97133cfe3d  movaps xmm15, xmm10
00007e97133cfe41  addpd xmm15, xmm11
00007e97133cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007e97133cfe4c  ptest xmm2, xmm2
00007e97133cfe51  jnz 0x00007E97133D2F23
00007e97133cfe57  vmovaps xmm11, [rsp+0x80]
00007e97133cfe60  vpermilpd xmm11, xmm11, 0x00
00007e97133cfe66  movaps xmm10, xmm12
00007e97133cfe6a  mulpd xmm10, xmm11
00007e97133cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007e97133cfe75  ptest xmm2, xmm2
00007e97133cfe7a  jnz 0x00007E97133D3067
00007e97133cfe80  vmovaps xmm12, [rsp+0x80]
00007e97133cfe89  vpermilpd xmm12, xmm12, 0x00
00007e97133cfe8f  vmovaps xmm2, [rsp+0xA0]
00007e97133cfe98  vmovaps [rsp+0x30], xmm1
00007e97133cfe9e  movaps xmm11, xmm2
00007e97133cfea2  mulpd xmm11, xmm12
00007e97133cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007e97133cfead  ptest xmm1, xmm1
00007e97133cfeb2  jnz 0x00007E97133D31AB
00007e97133cfeb8  movaps xmm1, xmm14
00007e97133cfebc  addpd xmm1, xmm6
00007e97133cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007e97133cfec5  ptest xmm12, xmm12
00007e97133cfecb  jnz 0x00007E97133D32EE
00007e97133cfed1  vmovaps xmm12, [rsp+0x20]
00007e97133cfed7  movaps xmm14, xmm12
00007e97133cfedb  addpd xmm14, xmm5
00007e97133cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007e97133cfee6  ptest xmm6, xmm6
00007e97133cfeeb  jnz 0x00007E97133D342F
00007e97133cfef1  vmovaps xmm12, [rsp+0x90]
00007e97133cfefa  vpermilpd xmm12, xmm12, 0x00
00007e97133cff00  movaps xmm6, xmm9
00007e97133cff04  mulpd xmm6, xmm12
00007e97133cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007e97133cff0e  ptest xmm5, xmm5
00007e97133cff13  jnz 0x00007E97133D3572
00007e97133cff19  movaps xmm12, xmm15
00007e97133cff1d  addpd xmm12, xmm13
00007e97133cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007e97133cff28  ptest xmm9, xmm9
00007e97133cff2e  jnz 0x00007E97133D36B4
00007e97133cff34  vmovaps xmm13, [rsp+0x30]
00007e97133cff3a  movaps xmm15, xmm13
00007e97133cff3e  addpd xmm15, xmm10
00007e97133cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007e97133cff49  ptest xmm9, xmm9
00007e97133cff4f  jnz 0x00007E97133D37F8
00007e97133cff55  vmovaps xmm13, [rsp+0xD0]
00007e97133cff5e  vmovaps xmm10, [rsp+0xD0]
00007e97133cff67  por xmm13, xmm10
00007e97133cff6c  movaps [r15+0x250], xmm13
00007e97133cff74  vmovaps [rsp+0x20], xmm7
00007e97133cff7a  vmovaps xmm13, [rsp+0x20]
00007e97133cff80  por xmm7, xmm13
00007e97133cff85  movaps [r15+0x2A0], xmm7
00007e97133cff8d  vmovaps [rsp+0x20], xmm3
00007e97133cff93  vmovaps xmm13, [rsp+0x20]
00007e97133cff99  por xmm3, xmm13
00007e97133cff9e  movaps [r15+0x1D0], xmm3
00007e97133cffa6  lea rax, [r14+0x40]
00007e97133cffaa  movups xmm13, [r13+rax*1]
00007e97133cffb0  movaps [r15+0x2C0], xmm13
00007e97133cffb8  vmovaps xmm10, [rsp+0x90]
00007e97133cffc1  vpermilpd xmm10, xmm10, 0x00
00007e97133cffc7  movaps xmm9, xmm8
00007e97133cffcb  mulpd xmm9, xmm10
00007e97133cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007e97133cffd6  ptest xmm5, xmm5
00007e97133cffdb  jnz 0x00007E97133D3946
00007e97133cffe1  movaps xmm10, xmm1
00007e97133cffe5  addpd xmm10, xmm11
00007e97133cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007e97133cfff0  ptest xmm8, xmm8
00007e97133cfff6  jnz 0x00007E97133D3A8A
00007e97133cfffc  movaps xmm1, xmm14
00007e97133d0000  addpd xmm1, xmm6
00007e97133d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007e97133d0009  ptest xmm11, xmm11
00007e97133d000f  jnz 0x00007E97133D3BCD
00007e97133d0015  vmovaps xmm14, [rsp+0x90]
00007e97133d001e  vpermilpd xmm14, xmm14, 0x00
00007e97133d0024  movaps xmm11, xmm13
00007e97133d0028  mulpd xmm11, xmm14
00007e97133d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007e97133d0033  ptest xmm8, xmm8
00007e97133d0039  jnz 0x00007E97133D3D0E
00007e97133d003f  vmovaps xmm14, [rsp+0x90]
00007e97133d0048  vpermilpd xmm14, xmm14, 0x00
00007e97133d004e  vmovaps xmm8, [rsp+0x10]
00007e97133d0054  movaps xmm13, xmm8
00007e97133d0058  mulpd xmm13, xmm14
00007e97133d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007e97133d0063  ptest xmm6, xmm6
00007e97133d0068  jnz 0x00007E97133D3E52
00007e97133d006e  vmovaps xmm14, [rsp+0x60]
00007e97133d0074  vpermilpd xmm14, xmm14, 0x00
00007e97133d007a  movaps xmm8, xmm7
00007e97133d007e  mulpd xmm8, xmm14
00007e97133d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007e97133d0089  ptest xmm6, xmm6
00007e97133d008e  jnz 0x00007E97133D3F96
00007e97133d0094  movaps xmm14, xmm12
00007e97133d0098  addpd xmm14, xmm9
00007e97133d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007e97133d00a3  ptest xmm7, xmm7
00007e97133d00a8  jnz 0x00007E97133D40D9
00007e97133d00ae  vmovaps xmm12, [rsp+0x60]
00007e97133d00b4  vpermilpd xmm12, xmm12, 0x00
00007e97133d00ba  vmovaps xmm7, [rsp+0xF0]
00007e97133d00c3  movaps xmm9, xmm7
00007e97133d00c7  mulpd xmm9, xmm12
00007e97133d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007e97133d00d2  ptest xmm6, xmm6
00007e97133d00d7  jnz 0x00007E97133D421D
00007e97133d00dd  movaps xmm12, xmm15
00007e97133d00e1  addpd xmm12, xmm11
00007e97133d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007e97133d00ec  ptest xmm7, xmm7
00007e97133d00f1  jnz 0x00007E97133D4360
00007e97133d00f7  vmovaps xmm15, [rsp+0x60]
00007e97133d00fd  vpermilpd xmm15, xmm15, 0x00
00007e97133d0103  vmovaps xmm7, [rsp+0x40]
00007e97133d0109  movaps xmm11, xmm7
00007e97133d010d  mulpd xmm11, xmm15
00007e97133d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007e97133d0118  ptest xmm6, xmm6
00007e97133d011d  jnz 0x00007E97133D44A4
00007e97133d0123  movaps xmm15, xmm10
00007e97133d0127  addpd xmm15, xmm13
00007e97133d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007e97133d0132  ptest xmm7, xmm7
00007e97133d0137  jnz 0x00007E97133D45E7
00007e97133d013d  vmovaps xmm13, [rsp+0x60]
00007e97133d0143  vpermilpd xmm13, xmm13, 0x00
00007e97133d0149  vmovaps xmm7, [rsp+0x50]
00007e97133d014f  movaps xmm10, xmm7
00007e97133d0153  mulpd xmm10, xmm13
00007e97133d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007e97133d015e  ptest xmm6, xmm6
00007e97133d0163  jnz 0x00007E97133D472B
00007e97133d0169  movaps xmm13, xmm1
00007e97133d016d  addpd xmm13, xmm8
00007e97133d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007e97133d0178  ptest xmm7, xmm7
00007e97133d017d  jnz 0x00007E97133D486E
00007e97133d0183  lea rax, [r14+0x70]
00007e97133d0187  movups xmm1, [r13+rax*1]
00007e97133d018d  movaps [r15+0x240], xmm1
00007e97133d0195  movaps xmm8, xmm14
00007e97133d0199  addpd xmm8, xmm9
00007e97133d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007e97133d01a4  ptest xmm7, xmm7
00007e97133d01a9  jnz 0x00007E97133D49BB
00007e97133d01af  movaps [r15+0x170], xmm8
00007e97133d01b7  vmovaps xmm14, [rsp+0x70]
00007e97133d01bd  vpermilpd xmm14, xmm14, 0x00
00007e97133d01c3  movaps xmm9, xmm1
00007e97133d01c7  mulpd xmm9, xmm14
00007e97133d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007e97133d01d2  ptest xmm7, xmm7
00007e97133d01d7  jnz 0x00007E97133D4AFF
00007e97133d01dd  vmovaps xmm1, [rsp+0x70]
00007e97133d01e3  vpermilpd xmm1, xmm1, 0x00
00007e97133d01e9  movaps xmm14, xmm4
00007e97133d01ed  mulpd xmm14, xmm1
00007e97133d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007e97133d01f8  ptest xmm7, xmm7
00007e97133d01fd  jnz 0x00007E97133D4C42
00007e97133d0203  movaps [r15+0x180], xmm14
00007e97133d020b  movaps xmm1, xmm12
00007e97133d020f  addpd xmm1, xmm11
00007e97133d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007e97133d0219  ptest xmm7, xmm7
00007e97133d021e  jnz 0x00007E97133D4D84
00007e97133d0224  movaps [r15+0x210], xmm1
00007e97133d022c  movups xmm12, [r13+r14*1]
00007e97133d0232  lea rax, [r14+0x10]
00007e97133d0236  movups xmm11, [r13+rax*1]
00007e97133d023c  movaps [r15+0x230], xmm11
00007e97133d0244  movaps xmm7, xmm15
00007e97133d0248  addpd xmm7, xmm10
00007e97133d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007e97133d0252  ptest xmm6, xmm6
00007e97133d0257  jnz 0x00007E97133D4EDA
00007e97133d025d  movaps [r15+0x130], xmm7
00007e97133d0265  vmovaps xmm15, [rsp+0x70]
00007e97133d026b  vpermilpd xmm15, xmm15, 0x00
00007e97133d0271  movaps xmm10, xmm11
00007e97133d0275  mulpd xmm10, xmm15
00007e97133d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007e97133d0280  ptest xmm6, xmm6
00007e97133d0285  jnz 0x00007E97133D501C
00007e97133d028b  movaps [r15+0x220], xmm10
00007e97133d0293  vmovaps xmm15, [rsp+0x70]
00007e97133d0299  vpermilpd xmm15, xmm15, 0x00
00007e97133d029f  movaps xmm11, xmm12
00007e97133d02a3  mulpd xmm11, xmm15
00007e97133d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007e97133d02ae  ptest xmm6, xmm6
00007e97133d02b3  jnz 0x00007E97133D5160
00007e97133d02b9  movaps xmm15, xmm13
00007e97133d02bd  addpd xmm15, xmm9
00007e97133d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007e97133d02c8  ptest xmm12, xmm12
00007e97133d02ce  jnz 0x00007E97133D52A4
00007e97133d02d4  movaps [r15+0x140], xmm15
00007e97133d02dc  movaps xmm13, xmm8
00007e97133d02e0  addpd xmm13, xmm14
00007e97133d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007e97133d02eb  ptest xmm12, xmm12
00007e97133d02f1  jnz 0x00007E97133D53E8
00007e97133d02f7  movaps [r15+0x150], xmm13
00007e97133d02ff  movaps xmm14, xmm1
00007e97133d0303  addpd xmm14, xmm10
00007e97133d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007e97133d030e  ptest xmm12, xmm12
00007e97133d0314  jnz 0x00007E97133D552C
00007e97133d031a  movaps [r15+0x160], xmm14
00007e97133d0322  movaps xmm1, xmm7
00007e97133d0325  addpd xmm1, xmm11
00007e97133d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007e97133d032f  ptest xmm12, xmm12
00007e97133d0335  jnz 0x00007E97133D566F
00007e97133d033b  movaps [r15+0x120], xmm1
00007e97133d0343  mov eax, 0x430920
00007e97133d0348  movups [r13+rax*1], xmm15
00007e97133d034e  mov eax, 0x430930
00007e97133d0353  movups [r13+rax*1], xmm13
00007e97133d0359  mov eax, 0x430940
00007e97133d035e  movups [r13+rax*1], xmm14
00007e97133d0364  mov eax, 0x430950
00007e97133d0369  movups [r13+rax*1], xmm1
00007e97133d036f  mov eax, [r15+0x108]
00007e97133d0376  sahf
00007e97133d0377  jnz 0x00007E97133D03A9
00007e97133d0379  cmp dword ptr [r15+0x318], 0x00
00007e97133d0381  jz 0x00007E97133DB900
00007e97133d0387  nop [rax+rax*1], ax
00007e97133d0390  nop [rax+rax*1], eax
00007e97133d0398  mov eax, 0x410444
00007e97133d039d  mov [r15+0x100], rax
00007e97133d03a4  jmp 0x00007E97131FE110
00007e97133d03a9  cmp dword ptr [r15+0x318], 0x00
00007e97133d03b1  jz 0x00007E97133D57E0
00007e97133d03b7  nop [rax+rax*1], ax
00007e97133d03c0  nop [rax+rax*1], eax
00007e97133d03c8  mov eax, 0x410278
00007e97133d03cd  mov [r15+0x100], rax
00007e97133d03d4  jmp 0x00007E97131FE110
00007e97133d03d9  int3
00007e97133d03da  call 0x00007E97132B52F0
00007e97133d03df  jmp 0x00007E97133CF016
00007e97133d03e4  call 0x00007E97132C4620
00007e97133d03e9  jmp 0x00007E97133CF023
00007e97133d03ee  call 0x00007E97132C33A0
00007e97133d03f3  jmp 0x00007E97133CF035
00007e97133d03f8  call 0x00007E97132C2120
00007e97133d03fd  jmp 0x00007E97133CF03F
00007e97133d0402  call 0x00007E97132C0860
00007e97133d0407  jmp 0x00007E97133CF067
00007e97133d040c  call 0x00007E97132BF5F0
00007e97133d0411  jmp 0x00007E97133CF073
00007e97133d0416  call 0x00007E97132C0860
00007e97133d041b  jmp 0x00007E97133CF0A5
00007e97133d0420  call 0x00007E97132BF5F0
00007e97133d0425  jmp 0x00007E97133CF0B1
00007e97133d042a  call 0x00007E97132C4740
00007e97133d042f  jmp 0x00007E97133CF0BE
00007e97133d0434  call 0x00007E97132B5400
00007e97133d0439  jmp 0x00007E97133CF0CB
00007e97133d043e  call 0x00007E97132B52F0
00007e97133d0443  jmp 0x00007E97133CF0D8
00007e97133d0448  call 0x00007E97132C4620
00007e97133d044d  jmp 0x00007E97133CF0E5
00007e97133d0452  call 0x00007E97132C0860
00007e97133d0457  jmp 0x00007E97133CF10D
00007e97133d045c  call 0x00007E97132BF5F0
00007e97133d0461  jmp 0x00007E97133CF119
00007e97133d0466  call 0x00007E9713209D70
00007e97133d046b  jmp 0x00007E97133CF11F
00007e97133d0470  call 0x00007E97132BE9C0
00007e97133d0475  jmp 0x00007E97133CF129
00007e97133d047a  call 0x00007E97132C0860
00007e97133d047f  jmp 0x00007E97133CF151
00007e97133d0484  call 0x00007E97132BF5F0
00007e97133d0489  jmp 0x00007E97133CF15D
00007e97133d048e  call 0x00007E97132BD750
00007e97133d0493  jmp 0x00007E97133CF16A
00007e97133d0498  call 0x00007E97132BC4E0
00007e97133d049d  jmp 0x00007E97133CF177
00007e97133d04a2  call 0x00007E97132C4740
00007e97133d04a7  jmp 0x00007E97133CF184
00007e97133d04ac  call 0x00007E97132B5400
00007e97133d04b1  jmp 0x00007E97133CF191
00007e97133d04b6  call 0x00007E97132B52F0
00007e97133d04bb  jmp 0x00007E97133CF19E
00007e97133d04c0  call 0x00007E97132C4620
00007e97133d04c5  jmp 0x00007E97133CF1AB
00007e97133d04ca  call 0x00007E97132C0860
00007e97133d04cf  jmp 0x00007E97133CF1BE
00007e97133d04d4  call 0x00007E97132BB270
00007e97133d04d9  jmp 0x00007E97133CF1CB
00007e97133d04de  call 0x00007E97132BA000
00007e97133d04e3  jmp 0x00007E97133CF1D8
00007e97133d04e8  call 0x00007E97132B8D90
00007e97133d04ed  jmp 0x00007E97133CF1E5
00007e97133d04f2  call 0x00007E97132B8A20
00007e97133d04f7  jmp 0x00007E97133CF1F2
00007e97133d04fc  call 0x00007E97132B5400
00007e97133d0501  jmp 0x00007E97133CF1FC
00007e97133d0506  call 0x00007E97132C2240
00007e97133d050b  jmp 0x00007E97133CF206
00007e97133d0510  call 0x00007E97132B52F0
00007e97133d0515  jmp 0x00007E97133CF210
00007e97133d051a  call 0x00007E97132C2120
00007e97133d051f  jmp 0x00007E97133CF21A
00007e97133d0524  call 0x00007E97132B77B0
00007e97133d0529  jmp 0x00007E97133CF224
00007e97133d052e  call 0x00007E97132B6550
00007e97133d0533  jmp 0x00007E97133CF22E
00007e97133d0538  call 0x00007E97132BFD50
00007e97133d053d  jmp 0x00007E97133CF240
00007e97133d0542  call 0x00007E97132B8EA0
00007e97133d0547  jmp 0x00007E97133CF24A
00007e97133d054c  call 0x00007E97132BFC30
00007e97133d0551  jmp 0x00007E97133CF257
00007e97133d0556  call 0x00007E97132B8D90
00007e97133d055b  jmp 0x00007E97133CF264
00007e97133d0560  call 0x00007E97132C2240
00007e97133d0565  jmp 0x00007E97133CF271
00007e97133d056a  call 0x00007E97132B5400
00007e97133d056f  jmp 0x00007E97133CF27E
00007e97133d0574  call 0x00007E97132B52F0
00007e97133d0579  jmp 0x00007E97133CF28B
00007e97133d057e  call 0x00007E97132C2120
00007e97133d0583  jmp 0x00007E97133CF298
00007e97133d0588  call 0x00007E97132B52F0
00007e97133d058d  jmp 0x00007E97133CF2AB
00007e97133d0592  call 0x00007E97132B52F0
00007e97133d0597  jmp 0x00007E97133CF2BE
00007e97133d059c  call 0x00007E97132B52F0
00007e97133d05a1  jmp 0x00007E97133CF2D1
00007e97133d05a6  call 0x00007E97132B52F0
00007e97133d05ab  jmp 0x00007E97133CF2E4
00007e97133d05b0  call 0x00007E97132C2240
00007e97133d05b5  jmp 0x00007E97133CF2F9
00007e97133d05ba  call 0x00007E97132C2240
00007e97133d05bf  jmp 0x00007E97133CF30C
00007e97133d05c4  call 0x00007E97132C2120
00007e97133d05c9  jmp 0x00007E97133CF319
00007e97133d05ce  call 0x00007E97132B52F0
00007e97133d05d3  jmp 0x00007E97133CF32C
00007e97133d05d8  call 0x00007E97132B52F0
00007e97133d05dd  jmp 0x00007E97133CF34F
00007e97133d05e2  call 0x00007E97132B52F0
00007e97133d05e7  jmp 0x00007E97133CF362
00007e97133d05ec  call 0x00007E97131FF540
00007e97133d05f1  jmp 0x00007E97133CF380
00007e97133d05f6  call 0x00007E9713208C20
00007e97133d05fb  jmp 0x00007E97133CF38A
00007e97133d0600  call 0x00007E97132D6600
00007e97133d0605  jmp 0x00007E97133CF396
00007e97133d060a  call 0x00007E97131FF540
00007e97133d060f  jmp 0x00007E97133CF3A6
00007e97133d0614  call 0x00007E97132C0370
00007e97133d0619  jmp 0x00007E97133CF3D4
00007e97133d061e  call 0x00007E97132BF100
00007e97133d0623  jmp 0x00007E97133CF3DD
00007e97133d0628  call 0x00007E97132C0370
00007e97133d062d  jmp 0x00007E97133CF43B
00007e97133d0632  call 0x00007E97132BF100
00007e97133d0637  jmp 0x00007E97133CF444
00007e97133d063c  call 0x00007E97132C0370
00007e97133d0641  jmp 0x00007E97133CF48B
00007e97133d0646  call 0x00007E97132BF100
00007e97133d064b  jmp 0x00007E97133CF494
00007e97133d0650  call 0x00007E971320B720
00007e97133d0655  jmp 0x00007E97133CF4D7
00007e97133d065a  call 0x00007E97132B47C0
00007e97133d065f  jmp 0x00007E97133CF4EA
00007e97133d0664  call 0x00007E9713208B00
00007e97133d0669  jmp 0x00007E97133CF501
00007e97133d066e  call 0x00007E97131FF430
00007e97133d0673  jmp 0x00007E97133CF514
00007e97133d0678  call 0x00007E97131FF430
00007e97133d067d  jmp 0x00007E97133CF527
00007e97133d0682  sub rsp, 0x08
00007e97133d0686  push rax
00007e97133d0687  push rcx
00007e97133d0688  push rdx
00007e97133d0689  push rdi
00007e97133d068a  push rsi
00007e97133d068b  push r8
00007e97133d068d  push r9
00007e97133d068f  push r10
00007e97133d0691  push r11
00007e97133d0693  sub rsp, 0xF0
00007e97133d069a  vmovaps [rsp], xmm0
00007e97133d069f  vmovaps [rsp+0x10], xmm2
00007e97133d06a5  vmovaps [rsp+0x20], xmm3
00007e97133d06ab  vmovaps [rsp+0x30], xmm4
00007e97133d06b1  vmovaps [rsp+0x40], xmm5
00007e97133d06b7  vmovaps [rsp+0x50], xmm6
00007e97133d06bd  vmovaps [rsp+0x60], xmm7
00007e97133d06c3  vmovaps [rsp+0x70], xmm8
00007e97133d06c9  vmovaps [rsp+0x80], xmm9
00007e97133d06d2  vmovaps [rsp+0x90], xmm10
00007e97133d06db  vmovaps [rsp+0xA0], xmm11
00007e97133d06e4  vmovaps [rsp+0xB0], xmm12
00007e97133d06ed  vmovaps [rsp+0xC0], xmm13
00007e97133d06f6  vmovaps [rsp+0xD0], xmm14
00007e97133d06ff  vmovaps [rsp+0xE0], xmm15
00007e97133d0708  sub rsp, 0x30
00007e97133d070c  movaps [rsp], xmm1
00007e97133d0710  movaps [rsp+0x10], xmm15
00007e97133d0716  movaps [rsp+0x20], xmm14
00007e97133d071c  lea rdi, [rsp]
00007e97133d0720  mov esi, 0x00
00007e97133d0725  mov rax, 0x58D8AED5F530
00007e97133d072f  call rax
00007e97133d0731  movaps xmm1, [rsp]
00007e97133d0735  add rsp, 0x30
00007e97133d0739  vmovaps xmm0, [rsp]
00007e97133d073e  vmovaps xmm2, [rsp+0x10]
00007e97133d0744  vmovaps xmm3, [rsp+0x20]
00007e97133d074a  vmovaps xmm4, [rsp+0x30]
00007e97133d0750  vmovaps xmm5, [rsp+0x40]
00007e97133d0756  vmovaps xmm6, [rsp+0x50]
00007e97133d075c  vmovaps xmm7, [rsp+0x60]
00007e97133d0762  vmovaps xmm8, [rsp+0x70]
00007e97133d0768  vmovaps xmm9, [rsp+0x80]
00007e97133d0771  vmovaps xmm10, [rsp+0x90]
00007e97133d077a  vmovaps xmm11, [rsp+0xA0]
00007e97133d0783  vmovaps xmm12, [rsp+0xB0]
00007e97133d078c  vmovaps xmm13, [rsp+0xC0]
00007e97133d0795  vmovaps xmm14, [rsp+0xD0]
00007e97133d079e  vmovaps xmm15, [rsp+0xE0]
00007e97133d07a7  add rsp, 0xF0
00007e97133d07ae  pop r11
00007e97133d07b0  pop r10
00007e97133d07b2  pop r9
00007e97133d07b4  pop r8
00007e97133d07b6  pop rsi
00007e97133d07b7  pop rdi
00007e97133d07b8  pop rdx
00007e97133d07b9  pop rcx
00007e97133d07ba  pop rax
00007e97133d07bb  add rsp, 0x08
00007e97133d07bf  jmp 0x00007E97133CF581
00007e97133d07c4  sub rsp, 0x08
00007e97133d07c8  push rax
00007e97133d07c9  push rcx
00007e97133d07ca  push rdx
00007e97133d07cb  push rdi
00007e97133d07cc  push rsi
00007e97133d07cd  push r8
00007e97133d07cf  push r9
00007e97133d07d1  push r10
00007e97133d07d3  push r11
00007e97133d07d5  sub rsp, 0xF0
00007e97133d07dc  vmovaps [rsp], xmm0
00007e97133d07e1  vmovaps [rsp+0x10], xmm1
00007e97133d07e7  vmovaps [rsp+0x20], xmm2
00007e97133d07ed  vmovaps [rsp+0x30], xmm3
00007e97133d07f3  vmovaps [rsp+0x40], xmm4
00007e97133d07f9  vmovaps [rsp+0x50], xmm5
00007e97133d07ff  vmovaps [rsp+0x60], xmm6
00007e97133d0805  vmovaps [rsp+0x70], xmm7
00007e97133d080b  vmovaps [rsp+0x80], xmm8
00007e97133d0814  vmovaps [rsp+0x90], xmm9
00007e97133d081d  vmovaps [rsp+0xA0], xmm10
00007e97133d0826  vmovaps [rsp+0xB0], xmm11
00007e97133d082f  vmovaps [rsp+0xC0], xmm12
00007e97133d0838  vmovaps [rsp+0xD0], xmm14
00007e97133d0841  vmovaps [rsp+0xE0], xmm15
00007e97133d084a  sub rsp, 0x30
00007e97133d084e  movaps [rsp], xmm13
00007e97133d0853  movaps [rsp+0x10], xmm1
00007e97133d0858  movaps [rsp+0x20], xmm14
00007e97133d085e  lea rdi, [rsp]
00007e97133d0862  mov esi, 0x00
00007e97133d0867  mov rax, 0x58D8AED5F530
00007e97133d0871  call rax
00007e97133d0873  movaps xmm13, [rsp]
00007e97133d0878  add rsp, 0x30
00007e97133d087c  vmovaps xmm0, [rsp]
00007e97133d0881  vmovaps xmm1, [rsp+0x10]
00007e97133d0887  vmovaps xmm2, [rsp+0x20]
00007e97133d088d  vmovaps xmm3, [rsp+0x30]
00007e97133d0893  vmovaps xmm4, [rsp+0x40]
00007e97133d0899  vmovaps xmm5, [rsp+0x50]
00007e97133d089f  vmovaps xmm6, [rsp+0x60]
00007e97133d08a5  vmovaps xmm7, [rsp+0x70]
00007e97133d08ab  vmovaps xmm8, [rsp+0x80]
00007e97133d08b4  vmovaps xmm9, [rsp+0x90]
00007e97133d08bd  vmovaps xmm10, [rsp+0xA0]
00007e97133d08c6  vmovaps xmm11, [rsp+0xB0]
00007e97133d08cf  vmovaps xmm12, [rsp+0xC0]
00007e97133d08d8  vmovaps xmm14, [rsp+0xD0]
00007e97133d08e1  vmovaps xmm15, [rsp+0xE0]
00007e97133d08ea  add rsp, 0xF0
00007e97133d08f1  pop r11
00007e97133d08f3  pop r10
00007e97133d08f5  pop r9
00007e97133d08f7  pop r8
00007e97133d08f9  pop rsi
00007e97133d08fa  pop rdi
00007e97133d08fb  pop rdx
00007e97133d08fc  pop rcx
00007e97133d08fd  pop rax
00007e97133d08fe  add rsp, 0x08
00007e97133d0902  jmp 0x00007E97133CF5CF
00007e97133d0907  sub rsp, 0x08
00007e97133d090b  push rax
00007e97133d090c  push rcx
00007e97133d090d  push rdx
00007e97133d090e  push rdi
00007e97133d090f  push rsi
00007e97133d0910  push r8
00007e97133d0912  push r9
00007e97133d0914  push r10
00007e97133d0916  push r11
00007e97133d0918  sub rsp, 0xF0
00007e97133d091f  vmovaps [rsp], xmm0
00007e97133d0924  vmovaps [rsp+0x10], xmm1
00007e97133d092a  vmovaps [rsp+0x20], xmm2
00007e97133d0930  vmovaps [rsp+0x30], xmm3
00007e97133d0936  vmovaps [rsp+0x40], xmm4
00007e97133d093c  vmovaps [rsp+0x50], xmm5
00007e97133d0942  vmovaps [rsp+0x60], xmm6
00007e97133d0948  vmovaps [rsp+0x70], xmm7
00007e97133d094e  vmovaps [rsp+0x80], xmm8
00007e97133d0957  vmovaps [rsp+0x90], xmm9
00007e97133d0960  vmovaps [rsp+0xA0], xmm10
00007e97133d0969  vmovaps [rsp+0xB0], xmm11
00007e97133d0972  vmovaps [rsp+0xC0], xmm12
00007e97133d097b  vmovaps [rsp+0xD0], xmm13
00007e97133d0984  vmovaps [rsp+0xE0], xmm14
00007e97133d098d  sub rsp, 0x30
00007e97133d0991  movaps [rsp], xmm15
00007e97133d0996  movaps [rsp+0x10], xmm14
00007e97133d099c  movaps [rsp+0x20], xmm1
00007e97133d09a1  lea rdi, [rsp]
00007e97133d09a5  mov esi, 0x00
00007e97133d09aa  mov rax, 0x58D8AED5F530
00007e97133d09b4  call rax
00007e97133d09b6  movaps xmm15, [rsp]
00007e97133d09bb  add rsp, 0x30
00007e97133d09bf  vmovaps xmm0, [rsp]
00007e97133d09c4  vmovaps xmm1, [rsp+0x10]
00007e97133d09ca  vmovaps xmm2, [rsp+0x20]
00007e97133d09d0  vmovaps xmm3, [rsp+0x30]
00007e97133d09d6  vmovaps xmm4, [rsp+0x40]
00007e97133d09dc  vmovaps xmm5, [rsp+0x50]
00007e97133d09e2  vmovaps xmm6, [rsp+0x60]
00007e97133d09e8  vmovaps xmm7, [rsp+0x70]
00007e97133d09ee  vmovaps xmm8, [rsp+0x80]
00007e97133d09f7  vmovaps xmm9, [rsp+0x90]
00007e97133d0a00  vmovaps xmm10, [rsp+0xA0]
00007e97133d0a09  vmovaps xmm11, [rsp+0xB0]
00007e97133d0a12  vmovaps xmm12, [rsp+0xC0]
00007e97133d0a1b  vmovaps xmm13, [rsp+0xD0]
00007e97133d0a24  vmovaps xmm14, [rsp+0xE0]
00007e97133d0a2d  add rsp, 0xF0
00007e97133d0a34  pop r11
00007e97133d0a36  pop r10
00007e97133d0a38  pop r9
00007e97133d0a3a  pop r8
00007e97133d0a3c  pop rsi
00007e97133d0a3d  pop rdi
00007e97133d0a3e  pop rdx
00007e97133d0a3f  pop rcx
00007e97133d0a40  pop rax
00007e97133d0a41  add rsp, 0x08
00007e97133d0a45  jmp 0x00007E97133CF617
00007e97133d0a4a  sub rsp, 0x08
00007e97133d0a4e  push rax
00007e97133d0a4f  push rcx
00007e97133d0a50  push rdx
00007e97133d0a51  push rdi
00007e97133d0a52  push rsi
00007e97133d0a53  push r8
00007e97133d0a55  push r9
00007e97133d0a57  push r10
00007e97133d0a59  push r11
00007e97133d0a5b  sub rsp, 0xF0
00007e97133d0a62  vmovaps [rsp], xmm0
00007e97133d0a67  vmovaps [rsp+0x10], xmm2
00007e97133d0a6d  vmovaps [rsp+0x20], xmm3
00007e97133d0a73  vmovaps [rsp+0x30], xmm4
00007e97133d0a79  vmovaps [rsp+0x40], xmm5
00007e97133d0a7f  vmovaps [rsp+0x50], xmm6
00007e97133d0a85  vmovaps [rsp+0x60], xmm7
00007e97133d0a8b  vmovaps [rsp+0x70], xmm8
00007e97133d0a91  vmovaps [rsp+0x80], xmm9
00007e97133d0a9a  vmovaps [rsp+0x90], xmm10
00007e97133d0aa3  vmovaps [rsp+0xA0], xmm11
00007e97133d0aac  vmovaps [rsp+0xB0], xmm12
00007e97133d0ab5  vmovaps [rsp+0xC0], xmm13
00007e97133d0abe  vmovaps [rsp+0xD0], xmm14
00007e97133d0ac7  vmovaps [rsp+0xE0], xmm15
00007e97133d0ad0  sub rsp, 0x30
00007e97133d0ad4  movaps [rsp], xmm1
00007e97133d0ad8  movaps [rsp+0x10], xmm14
00007e97133d0ade  movaps [rsp+0x20], xmm10
00007e97133d0ae4  lea rdi, [rsp]
00007e97133d0ae8  mov esi, 0x00
00007e97133d0aed  mov rax, 0x58D8AED5F530
00007e97133d0af7  call rax
00007e97133d0af9  movaps xmm1, [rsp]
00007e97133d0afd  add rsp, 0x30
00007e97133d0b01  vmovaps xmm0, [rsp]
00007e97133d0b06  vmovaps xmm2, [rsp+0x10]
00007e97133d0b0c  vmovaps xmm3, [rsp+0x20]
00007e97133d0b12  vmovaps xmm4, [rsp+0x30]
00007e97133d0b18  vmovaps xmm5, [rsp+0x40]
00007e97133d0b1e  vmovaps xmm6, [rsp+0x50]
00007e97133d0b24  vmovaps xmm7, [rsp+0x60]
00007e97133d0b2a  vmovaps xmm8, [rsp+0x70]
00007e97133d0b30  vmovaps xmm9, [rsp+0x80]
00007e97133d0b39  vmovaps xmm10, [rsp+0x90]
00007e97133d0b42  vmovaps xmm11, [rsp+0xA0]
00007e97133d0b4b  vmovaps xmm12, [rsp+0xB0]
00007e97133d0b54  vmovaps xmm13, [rsp+0xC0]
00007e97133d0b5d  vmovaps xmm14, [rsp+0xD0]
00007e97133d0b66  vmovaps xmm15, [rsp+0xE0]
00007e97133d0b6f  add rsp, 0xF0
00007e97133d0b76  pop r11
00007e97133d0b78  pop r10
00007e97133d0b7a  pop r9
00007e97133d0b7c  pop r8
00007e97133d0b7e  pop rsi
00007e97133d0b7f  pop rdi
00007e97133d0b80  pop rdx
00007e97133d0b81  pop rcx
00007e97133d0b82  pop rax
00007e97133d0b83  add rsp, 0x08
00007e97133d0b87  jmp 0x00007E97133CF631
00007e97133d0b8c  sub rsp, 0x08
00007e97133d0b90  push rax
00007e97133d0b91  push rcx
00007e97133d0b92  push rdx
00007e97133d0b93  push rdi
00007e97133d0b94  push rsi
00007e97133d0b95  push r8
00007e97133d0b97  push r9
00007e97133d0b99  push r10
00007e97133d0b9b  push r11
00007e97133d0b9d  sub rsp, 0xF0
00007e97133d0ba4  vmovaps [rsp], xmm0
00007e97133d0ba9  vmovaps [rsp+0x10], xmm1
00007e97133d0baf  vmovaps [rsp+0x20], xmm2
00007e97133d0bb5  vmovaps [rsp+0x30], xmm3
00007e97133d0bbb  vmovaps [rsp+0x40], xmm4
00007e97133d0bc1  vmovaps [rsp+0x50], xmm5
00007e97133d0bc7  vmovaps [rsp+0x60], xmm6
00007e97133d0bcd  vmovaps [rsp+0x70], xmm7
00007e97133d0bd3  vmovaps [rsp+0x80], xmm8
00007e97133d0bdc  vmovaps [rsp+0x90], xmm9
00007e97133d0be5  vmovaps [rsp+0xA0], xmm10
00007e97133d0bee  vmovaps [rsp+0xB0], xmm11
00007e97133d0bf7  vmovaps [rsp+0xC0], xmm12
00007e97133d0c00  vmovaps [rsp+0xD0], xmm14
00007e97133d0c09  vmovaps [rsp+0xE0], xmm15
00007e97133d0c12  sub rsp, 0x30
00007e97133d0c16  movaps [rsp], xmm13
00007e97133d0c1b  movaps [rsp+0x10], xmm14
00007e97133d0c21  movaps [rsp+0x20], xmm2
00007e97133d0c26  lea rdi, [rsp]
00007e97133d0c2a  mov esi, 0x00
00007e97133d0c2f  mov rax, 0x58D8AED5F530
00007e97133d0c39  call rax
00007e97133d0c3b  movaps xmm13, [rsp]
00007e97133d0c40  add rsp, 0x30
00007e97133d0c44  vmovaps xmm0, [rsp]
00007e97133d0c49  vmovaps xmm1, [rsp+0x10]
00007e97133d0c4f  vmovaps xmm2, [rsp+0x20]
00007e97133d0c55  vmovaps xmm3, [rsp+0x30]
00007e97133d0c5b  vmovaps xmm4, [rsp+0x40]
00007e97133d0c61  vmovaps xmm5, [rsp+0x50]
00007e97133d0c67  vmovaps xmm6, [rsp+0x60]
00007e97133d0c6d  vmovaps xmm7, [rsp+0x70]
00007e97133d0c73  vmovaps xmm8, [rsp+0x80]
00007e97133d0c7c  vmovaps xmm9, [rsp+0x90]
00007e97133d0c85  vmovaps xmm10, [rsp+0xA0]
00007e97133d0c8e  vmovaps xmm11, [rsp+0xB0]
00007e97133d0c97  vmovaps xmm12, [rsp+0xC0]
00007e97133d0ca0  vmovaps xmm14, [rsp+0xD0]
00007e97133d0ca9  vmovaps xmm15, [rsp+0xE0]
00007e97133d0cb2  add rsp, 0xF0
00007e97133d0cb9  pop r11
00007e97133d0cbb  pop r10
00007e97133d0cbd  pop r9
00007e97133d0cbf  pop r8
00007e97133d0cc1  pop rsi
00007e97133d0cc2  pop rdi
00007e97133d0cc3  pop rdx
00007e97133d0cc4  pop rcx
00007e97133d0cc5  pop rax
00007e97133d0cc6  add rsp, 0x08
00007e97133d0cca  jmp 0x00007E97133CF64C
00007e97133d0ccf  sub rsp, 0x08
00007e97133d0cd3  push rax
00007e97133d0cd4  push rcx
00007e97133d0cd5  push rdx
00007e97133d0cd6  push rdi
00007e97133d0cd7  push rsi
00007e97133d0cd8  push r8
00007e97133d0cda  push r9
00007e97133d0cdc  push r10
00007e97133d0cde  push r11
00007e97133d0ce0  sub rsp, 0xF0
00007e97133d0ce7  vmovaps [rsp], xmm0
00007e97133d0cec  vmovaps [rsp+0x10], xmm2
00007e97133d0cf2  vmovaps [rsp+0x20], xmm3
00007e97133d0cf8  vmovaps [rsp+0x30], xmm4
00007e97133d0cfe  vmovaps [rsp+0x40], xmm5
00007e97133d0d04  vmovaps [rsp+0x50], xmm6
00007e97133d0d0a  vmovaps [rsp+0x60], xmm7
00007e97133d0d10  vmovaps [rsp+0x70], xmm8
00007e97133d0d16  vmovaps [rsp+0x80], xmm9
00007e97133d0d1f  vmovaps [rsp+0x90], xmm10
00007e97133d0d28  vmovaps [rsp+0xA0], xmm11
00007e97133d0d31  vmovaps [rsp+0xB0], xmm12
00007e97133d0d3a  vmovaps [rsp+0xC0], xmm13
00007e97133d0d43  vmovaps [rsp+0xD0], xmm14
00007e97133d0d4c  vmovaps [rsp+0xE0], xmm15
00007e97133d0d55  sub rsp, 0x30
00007e97133d0d59  movaps [rsp], xmm1
00007e97133d0d5d  movaps [rsp+0x10], xmm10
00007e97133d0d63  movaps [rsp+0x20], xmm2
00007e97133d0d68  lea rdi, [rsp]
00007e97133d0d6c  mov esi, 0x00
00007e97133d0d71  mov rax, 0x58D8AED5F530
00007e97133d0d7b  call rax
00007e97133d0d7d  movaps xmm1, [rsp]
00007e97133d0d81  add rsp, 0x30
00007e97133d0d85  vmovaps xmm0, [rsp]
00007e97133d0d8a  vmovaps xmm2, [rsp+0x10]
00007e97133d0d90  vmovaps xmm3, [rsp+0x20]
00007e97133d0d96  vmovaps xmm4, [rsp+0x30]
00007e97133d0d9c  vmovaps xmm5, [rsp+0x40]
00007e97133d0da2  vmovaps xmm6, [rsp+0x50]
00007e97133d0da8  vmovaps xmm7, [rsp+0x60]
00007e97133d0dae  vmovaps xmm8, [rsp+0x70]
00007e97133d0db4  vmovaps xmm9, [rsp+0x80]
00007e97133d0dbd  vmovaps xmm10, [rsp+0x90]
00007e97133d0dc6  vmovaps xmm11, [rsp+0xA0]
00007e97133d0dcf  vmovaps xmm12, [rsp+0xB0]
00007e97133d0dd8  vmovaps xmm13, [rsp+0xC0]
00007e97133d0de1  vmovaps xmm14, [rsp+0xD0]
00007e97133d0dea  vmovaps xmm15, [rsp+0xE0]
00007e97133d0df3  add rsp, 0xF0
00007e97133d0dfa  pop r11
00007e97133d0dfc  pop r10
00007e97133d0dfe  pop r9
00007e97133d0e00  pop r8
00007e97133d0e02  pop rsi
00007e97133d0e03  pop rdi
00007e97133d0e04  pop rdx
00007e97133d0e05  pop rcx
00007e97133d0e06  pop rax
00007e97133d0e07  add rsp, 0x08
00007e97133d0e0b  jmp 0x00007E97133CF6B4
00007e97133d0e10  sub rsp, 0x08
00007e97133d0e14  push rax
00007e97133d0e15  push rcx
00007e97133d0e16  push rdx
00007e97133d0e17  push rdi
00007e97133d0e18  push rsi
00007e97133d0e19  push r8
00007e97133d0e1b  push r9
00007e97133d0e1d  push r10
00007e97133d0e1f  push r11
00007e97133d0e21  sub rsp, 0xF0
00007e97133d0e28  vmovaps [rsp], xmm0
00007e97133d0e2d  vmovaps [rsp+0x10], xmm1
00007e97133d0e33  vmovaps [rsp+0x20], xmm2
00007e97133d0e39  vmovaps [rsp+0x30], xmm3
00007e97133d0e3f  vmovaps [rsp+0x40], xmm4
00007e97133d0e45  vmovaps [rsp+0x50], xmm5
00007e97133d0e4b  vmovaps [rsp+0x60], xmm6
00007e97133d0e51  vmovaps [rsp+0x70], xmm7
00007e97133d0e57  vmovaps [rsp+0x80], xmm8
00007e97133d0e60  vmovaps [rsp+0x90], xmm9
00007e97133d0e69  vmovaps [rsp+0xA0], xmm10
00007e97133d0e72  vmovaps [rsp+0xB0], xmm11
00007e97133d0e7b  vmovaps [rsp+0xC0], xmm12
00007e97133d0e84  vmovaps [rsp+0xD0], xmm13
00007e97133d0e8d  vmovaps [rsp+0xE0], xmm14
00007e97133d0e96  sub rsp, 0x30
00007e97133d0e9a  movaps [rsp], xmm15
00007e97133d0e9f  movaps [rsp+0x10], xmm10
00007e97133d0ea5  movaps [rsp+0x20], xmm2
00007e97133d0eaa  lea rdi, [rsp]
00007e97133d0eae  mov esi, 0x00
00007e97133d0eb3  mov rax, 0x58D8AED5F530
00007e97133d0ebd  call rax
00007e97133d0ebf  movaps xmm15, [rsp]
00007e97133d0ec4  add rsp, 0x30
00007e97133d0ec8  vmovaps xmm0, [rsp]
00007e97133d0ecd  vmovaps xmm1, [rsp+0x10]
00007e97133d0ed3  vmovaps xmm2, [rsp+0x20]
00007e97133d0ed9  vmovaps xmm3, [rsp+0x30]
00007e97133d0edf  vmovaps xmm4, [rsp+0x40]
00007e97133d0ee5  vmovaps xmm5, [rsp+0x50]
00007e97133d0eeb  vmovaps xmm6, [rsp+0x60]
00007e97133d0ef1  vmovaps xmm7, [rsp+0x70]
00007e97133d0ef7  vmovaps xmm8, [rsp+0x80]
00007e97133d0f00  vmovaps xmm9, [rsp+0x90]
00007e97133d0f09  vmovaps xmm10, [rsp+0xA0]
00007e97133d0f12  vmovaps xmm11, [rsp+0xB0]
00007e97133d0f1b  vmovaps xmm12, [rsp+0xC0]
00007e97133d0f24  vmovaps xmm13, [rsp+0xD0]
00007e97133d0f2d  vmovaps xmm14, [rsp+0xE0]
00007e97133d0f36  add rsp, 0xF0
00007e97133d0f3d  pop r11
00007e97133d0f3f  pop r10
00007e97133d0f41  pop r9
00007e97133d0f43  pop r8
00007e97133d0f45  pop rsi
00007e97133d0f46  pop rdi
00007e97133d0f47  pop rdx
00007e97133d0f48  pop rcx
00007e97133d0f49  pop rax
00007e97133d0f4a  add rsp, 0x08
00007e97133d0f4e  jmp 0x00007E97133CF706
00007e97133d0f53  sub rsp, 0x08
00007e97133d0f57  push rax
00007e97133d0f58  push rcx
00007e97133d0f59  push rdx
00007e97133d0f5a  push rdi
00007e97133d0f5b  push rsi
00007e97133d0f5c  push r8
00007e97133d0f5e  push r9
00007e97133d0f60  push r10
00007e97133d0f62  push r11
00007e97133d0f64  sub rsp, 0xF0
00007e97133d0f6b  vmovaps [rsp], xmm0
00007e97133d0f70  vmovaps [rsp+0x10], xmm2
00007e97133d0f76  vmovaps [rsp+0x20], xmm3
00007e97133d0f7c  vmovaps [rsp+0x30], xmm4
00007e97133d0f82  vmovaps [rsp+0x40], xmm5
00007e97133d0f88  vmovaps [rsp+0x50], xmm6
00007e97133d0f8e  vmovaps [rsp+0x60], xmm7
00007e97133d0f94  vmovaps [rsp+0x70], xmm8
00007e97133d0f9a  vmovaps [rsp+0x80], xmm9
00007e97133d0fa3  vmovaps [rsp+0x90], xmm10
00007e97133d0fac  vmovaps [rsp+0xA0], xmm11
00007e97133d0fb5  vmovaps [rsp+0xB0], xmm12
00007e97133d0fbe  vmovaps [rsp+0xC0], xmm13
00007e97133d0fc7  vmovaps [rsp+0xD0], xmm14
00007e97133d0fd0  vmovaps [rsp+0xE0], xmm15
00007e97133d0fd9  sub rsp, 0x30
00007e97133d0fdd  movaps [rsp], xmm1
00007e97133d0fe1  movaps [rsp+0x10], xmm10
00007e97133d0fe7  movaps [rsp+0x20], xmm12
00007e97133d0fed  lea rdi, [rsp]
00007e97133d0ff1  mov esi, 0x00
00007e97133d0ff6  mov rax, 0x58D8AED5F530
00007e97133d1000  call rax
00007e97133d1002  movaps xmm1, [rsp]
00007e97133d1006  add rsp, 0x30
00007e97133d100a  vmovaps xmm0, [rsp]
00007e97133d100f  vmovaps xmm2, [rsp+0x10]
00007e97133d1015  vmovaps xmm3, [rsp+0x20]
00007e97133d101b  vmovaps xmm4, [rsp+0x30]
00007e97133d1021  vmovaps xmm5, [rsp+0x40]
00007e97133d1027  vmovaps xmm6, [rsp+0x50]
00007e97133d102d  vmovaps xmm7, [rsp+0x60]
00007e97133d1033  vmovaps xmm8, [rsp+0x70]
00007e97133d1039  vmovaps xmm9, [rsp+0x80]
00007e97133d1042  vmovaps xmm10, [rsp+0x90]
00007e97133d104b  vmovaps xmm11, [rsp+0xA0]
00007e97133d1054  vmovaps xmm12, [rsp+0xB0]
00007e97133d105d  vmovaps xmm13, [rsp+0xC0]
00007e97133d1066  vmovaps xmm14, [rsp+0xD0]
00007e97133d106f  vmovaps xmm15, [rsp+0xE0]
00007e97133d1078  add rsp, 0xF0
00007e97133d107f  pop r11
00007e97133d1081  pop r10
00007e97133d1083  pop r9
00007e97133d1085  pop r8
00007e97133d1087  pop rsi
00007e97133d1088  pop rdi
00007e97133d1089  pop rdx
00007e97133d108a  pop rcx
00007e97133d108b  pop rax
00007e97133d108c  add rsp, 0x08
00007e97133d1090  jmp 0x00007E97133CF732
00007e97133d1095  sub rsp, 0x08
00007e97133d1099  push rax
00007e97133d109a  push rcx
00007e97133d109b  push rdx
00007e97133d109c  push rdi
00007e97133d109d  push rsi
00007e97133d109e  push r8
00007e97133d10a0  push r9
00007e97133d10a2  push r10
00007e97133d10a4  push r11
00007e97133d10a6  sub rsp, 0xF0
00007e97133d10ad  vmovaps [rsp], xmm0
00007e97133d10b2  vmovaps [rsp+0x10], xmm1
00007e97133d10b8  vmovaps [rsp+0x20], xmm2
00007e97133d10be  vmovaps [rsp+0x30], xmm3
00007e97133d10c4  vmovaps [rsp+0x40], xmm4
00007e97133d10ca  vmovaps [rsp+0x50], xmm5
00007e97133d10d0  vmovaps [rsp+0x60], xmm6
00007e97133d10d6  vmovaps [rsp+0x70], xmm7
00007e97133d10dc  vmovaps [rsp+0x80], xmm8
00007e97133d10e5  vmovaps [rsp+0x90], xmm9
00007e97133d10ee  vmovaps [rsp+0xA0], xmm10
00007e97133d10f7  vmovaps [rsp+0xB0], xmm11
00007e97133d1100  vmovaps [rsp+0xC0], xmm12
00007e97133d1109  vmovaps [rsp+0xD0], xmm13
00007e97133d1112  vmovaps [rsp+0xE0], xmm14
00007e97133d111b  sub rsp, 0x30
00007e97133d111f  movaps [rsp], xmm15
00007e97133d1124  movaps [rsp+0x10], xmm10
00007e97133d112a  movaps [rsp+0x20], xmm12
00007e97133d1130  lea rdi, [rsp]
00007e97133d1134  mov esi, 0x00
00007e97133d1139  mov rax, 0x58D8AED5F530
00007e97133d1143  call rax
00007e97133d1145  movaps xmm15, [rsp]
00007e97133d114a  add rsp, 0x30
00007e97133d114e  vmovaps xmm0, [rsp]
00007e97133d1153  vmovaps xmm1, [rsp+0x10]
00007e97133d1159  vmovaps xmm2, [rsp+0x20]
00007e97133d115f  vmovaps xmm3, [rsp+0x30]
00007e97133d1165  vmovaps xmm4, [rsp+0x40]
00007e97133d116b  vmovaps xmm5, [rsp+0x50]
00007e97133d1171  vmovaps xmm6, [rsp+0x60]
00007e97133d1177  vmovaps xmm7, [rsp+0x70]
00007e97133d117d  vmovaps xmm8, [rsp+0x80]
00007e97133d1186  vmovaps xmm9, [rsp+0x90]
00007e97133d118f  vmovaps xmm10, [rsp+0xA0]
00007e97133d1198  vmovaps xmm11, [rsp+0xB0]
00007e97133d11a1  vmovaps xmm12, [rsp+0xC0]
00007e97133d11aa  vmovaps xmm13, [rsp+0xD0]
00007e97133d11b3  vmovaps xmm14, [rsp+0xE0]
00007e97133d11bc  add rsp, 0xF0
00007e97133d11c3  pop r11
00007e97133d11c5  pop r10
00007e97133d11c7  pop r9
00007e97133d11c9  pop r8
00007e97133d11cb  pop rsi
00007e97133d11cc  pop rdi
00007e97133d11cd  pop rdx
00007e97133d11ce  pop rcx
00007e97133d11cf  pop rax
00007e97133d11d0  add rsp, 0x08
00007e97133d11d4  jmp 0x00007E97133CF75E
00007e97133d11d9  call 0x00007E97131FF430
00007e97133d11de  jmp 0x00007E97133CF7EE
00007e97133d11e3  call 0x00007E97131FF430
00007e97133d11e8  jmp 0x00007E97133CF801
00007e97133d11ed  sub rsp, 0x08
00007e97133d11f1  push rax
00007e97133d11f2  push rcx
00007e97133d11f3  push rdx
00007e97133d11f4  push rdi
00007e97133d11f5  push rsi
00007e97133d11f6  push r8
00007e97133d11f8  push r9
00007e97133d11fa  push r10
00007e97133d11fc  push r11
00007e97133d11fe  sub rsp, 0xF0
00007e97133d1205  vmovaps [rsp], xmm0
00007e97133d120a  vmovaps [rsp+0x10], xmm2
00007e97133d1210  vmovaps [rsp+0x20], xmm3
00007e97133d1216  vmovaps [rsp+0x30], xmm4
00007e97133d121c  vmovaps [rsp+0x40], xmm5
00007e97133d1222  vmovaps [rsp+0x50], xmm6
00007e97133d1228  vmovaps [rsp+0x60], xmm7
00007e97133d122e  vmovaps [rsp+0x70], xmm8
00007e97133d1234  vmovaps [rsp+0x80], xmm9
00007e97133d123d  vmovaps [rsp+0x90], xmm10
00007e97133d1246  vmovaps [rsp+0xA0], xmm11
00007e97133d124f  vmovaps [rsp+0xB0], xmm12
00007e97133d1258  vmovaps [rsp+0xC0], xmm13
00007e97133d1261  vmovaps [rsp+0xD0], xmm14
00007e97133d126a  vmovaps [rsp+0xE0], xmm15
00007e97133d1273  sub rsp, 0x30
00007e97133d1277  movaps [rsp], xmm1
00007e97133d127b  movaps [rsp+0x10], xmm13
00007e97133d1281  movaps [rsp+0x20], xmm2
00007e97133d1286  lea rdi, [rsp]
00007e97133d128a  mov esi, 0x00
00007e97133d128f  mov rax, 0x58D8AED5F530
00007e97133d1299  call rax
00007e97133d129b  movaps xmm1, [rsp]
00007e97133d129f  add rsp, 0x30
00007e97133d12a3  vmovaps xmm0, [rsp]
00007e97133d12a8  vmovaps xmm2, [rsp+0x10]
00007e97133d12ae  vmovaps xmm3, [rsp+0x20]
00007e97133d12b4  vmovaps xmm4, [rsp+0x30]
00007e97133d12ba  vmovaps xmm5, [rsp+0x40]
00007e97133d12c0  vmovaps xmm6, [rsp+0x50]
00007e97133d12c6  vmovaps xmm7, [rsp+0x60]
00007e97133d12cc  vmovaps xmm8, [rsp+0x70]
00007e97133d12d2  vmovaps xmm9, [rsp+0x80]
00007e97133d12db  vmovaps xmm10, [rsp+0x90]
00007e97133d12e4  vmovaps xmm11, [rsp+0xA0]
00007e97133d12ed  vmovaps xmm12, [rsp+0xB0]
00007e97133d12f6  vmovaps xmm13, [rsp+0xC0]
00007e97133d12ff  vmovaps xmm14, [rsp+0xD0]
00007e97133d1308  vmovaps xmm15, [rsp+0xE0]
00007e97133d1311  add rsp, 0xF0
00007e97133d1318  pop r11
00007e97133d131a  pop r10
00007e97133d131c  pop r9
00007e97133d131e  pop r8
00007e97133d1320  pop rsi
00007e97133d1321  pop rdi
00007e97133d1322  pop rdx
00007e97133d1323  pop rcx
00007e97133d1324  pop rax
00007e97133d1325  add rsp, 0x08
00007e97133d1329  jmp 0x00007E97133CF82C
00007e97133d132e  call 0x00007E971320E760
00007e97133d1333  jmp 0x00007E97133CF839
00007e97133d1338  sub rsp, 0x08
00007e97133d133c  push rax
00007e97133d133d  push rcx
00007e97133d133e  push rdx
00007e97133d133f  push rdi
00007e97133d1340  push rsi
00007e97133d1341  push r8
00007e97133d1343  push r9
00007e97133d1345  push r10
00007e97133d1347  push r11
00007e97133d1349  sub rsp, 0xF0
00007e97133d1350  vmovaps [rsp], xmm0
00007e97133d1355  vmovaps [rsp+0x10], xmm1
00007e97133d135b  vmovaps [rsp+0x20], xmm2
00007e97133d1361  vmovaps [rsp+0x30], xmm3
00007e97133d1367  vmovaps [rsp+0x40], xmm4
00007e97133d136d  vmovaps [rsp+0x50], xmm5
00007e97133d1373  vmovaps [rsp+0x60], xmm6
00007e97133d1379  vmovaps [rsp+0x70], xmm7
00007e97133d137f  vmovaps [rsp+0x80], xmm8
00007e97133d1388  vmovaps [rsp+0x90], xmm9
00007e97133d1391  vmovaps [rsp+0xA0], xmm10
00007e97133d139a  vmovaps [rsp+0xB0], xmm11
00007e97133d13a3  vmovaps [rsp+0xC0], xmm12
00007e97133d13ac  vmovaps [rsp+0xD0], xmm14
00007e97133d13b5  vmovaps [rsp+0xE0], xmm15
00007e97133d13be  sub rsp, 0x30
00007e97133d13c2  movaps [rsp], xmm13
00007e97133d13c7  movaps [rsp+0x10], xmm2
00007e97133d13cc  movaps [rsp+0x20], xmm1
00007e97133d13d1  lea rdi, [rsp]
00007e97133d13d5  mov esi, 0x00
00007e97133d13da  mov rax, 0x58D8AED5F530
00007e97133d13e4  call rax
00007e97133d13e6  movaps xmm13, [rsp]
00007e97133d13eb  add rsp, 0x30
00007e97133d13ef  vmovaps xmm0, [rsp]
00007e97133d13f4  vmovaps xmm1, [rsp+0x10]
00007e97133d13fa  vmovaps xmm2, [rsp+0x20]
00007e97133d1400  vmovaps xmm3, [rsp+0x30]
00007e97133d1406  vmovaps xmm4, [rsp+0x40]
00007e97133d140c  vmovaps xmm5, [rsp+0x50]
00007e97133d1412  vmovaps xmm6, [rsp+0x60]
00007e97133d1418  vmovaps xmm7, [rsp+0x70]
00007e97133d141e  vmovaps xmm8, [rsp+0x80]
00007e97133d1427  vmovaps xmm9, [rsp+0x90]
00007e97133d1430  vmovaps xmm10, [rsp+0xA0]
00007e97133d1439  vmovaps xmm11, [rsp+0xB0]
00007e97133d1442  vmovaps xmm12, [rsp+0xC0]
00007e97133d144b  vmovaps xmm14, [rsp+0xD0]
00007e97133d1454  vmovaps xmm15, [rsp+0xE0]
00007e97133d145d  add rsp, 0xF0
00007e97133d1464  pop r11
00007e97133d1466  pop r10
00007e97133d1468  pop r9
00007e97133d146a  pop r8
00007e97133d146c  pop rsi
00007e97133d146d  pop rdi
00007e97133d146e  pop rdx
00007e97133d146f  pop rcx
00007e97133d1470  pop rax
00007e97133d1471  add rsp, 0x08
00007e97133d1475  jmp 0x00007E97133CF878
00007e97133d147a  sub rsp, 0x08
00007e97133d147e  push rax
00007e97133d147f  push rcx
00007e97133d1480  push rdx
00007e97133d1481  push rdi
00007e97133d1482  push rsi
00007e97133d1483  push r8
00007e97133d1485  push r9
00007e97133d1487  push r10
00007e97133d1489  push r11
00007e97133d148b  sub rsp, 0xF0
00007e97133d1492  vmovaps [rsp], xmm0
00007e97133d1497  vmovaps [rsp+0x10], xmm2
00007e97133d149d  vmovaps [rsp+0x20], xmm3
00007e97133d14a3  vmovaps [rsp+0x30], xmm4
00007e97133d14a9  vmovaps [rsp+0x40], xmm5
00007e97133d14af  vmovaps [rsp+0x50], xmm6
00007e97133d14b5  vmovaps [rsp+0x60], xmm7
00007e97133d14bb  vmovaps [rsp+0x70], xmm8
00007e97133d14c1  vmovaps [rsp+0x80], xmm9
00007e97133d14ca  vmovaps [rsp+0x90], xmm10
00007e97133d14d3  vmovaps [rsp+0xA0], xmm11
00007e97133d14dc  vmovaps [rsp+0xB0], xmm12
00007e97133d14e5  vmovaps [rsp+0xC0], xmm13
00007e97133d14ee  vmovaps [rsp+0xD0], xmm14
00007e97133d14f7  vmovaps [rsp+0xE0], xmm15
00007e97133d1500  sub rsp, 0x30
00007e97133d1504  movaps [rsp], xmm1
00007e97133d1508  movaps [rsp+0x10], xmm15
00007e97133d150e  movaps [rsp+0x20], xmm2
00007e97133d1513  lea rdi, [rsp]
00007e97133d1517  mov esi, 0x00
00007e97133d151c  mov rax, 0x58D8AED5F530
00007e97133d1526  call rax
00007e97133d1528  movaps xmm1, [rsp]
00007e97133d152c  add rsp, 0x30
00007e97133d1530  vmovaps xmm0, [rsp]
00007e97133d1535  vmovaps xmm2, [rsp+0x10]
00007e97133d153b  vmovaps xmm3, [rsp+0x20]
00007e97133d1541  vmovaps xmm4, [rsp+0x30]
00007e97133d1547  vmovaps xmm5, [rsp+0x40]
00007e97133d154d  vmovaps xmm6, [rsp+0x50]
00007e97133d1553  vmovaps xmm7, [rsp+0x60]
00007e97133d1559  vmovaps xmm8, [rsp+0x70]
00007e97133d155f  vmovaps xmm9, [rsp+0x80]
00007e97133d1568  vmovaps xmm10, [rsp+0x90]
00007e97133d1571  vmovaps xmm11, [rsp+0xA0]
00007e97133d157a  vmovaps xmm12, [rsp+0xB0]
00007e97133d1583  vmovaps xmm13, [rsp+0xC0]
00007e97133d158c  vmovaps xmm14, [rsp+0xD0]
00007e97133d1595  vmovaps xmm15, [rsp+0xE0]
00007e97133d159e  add rsp, 0xF0
00007e97133d15a5  pop r11
00007e97133d15a7  pop r10
00007e97133d15a9  pop r9
00007e97133d15ab  pop r8
00007e97133d15ad  pop rsi
00007e97133d15ae  pop rdi
00007e97133d15af  pop rdx
00007e97133d15b0  pop rcx
00007e97133d15b1  pop rax
00007e97133d15b2  add rsp, 0x08
00007e97133d15b6  jmp 0x00007E97133CF8AC
00007e97133d15bb  sub rsp, 0x08
00007e97133d15bf  push rax
00007e97133d15c0  push rcx
00007e97133d15c1  push rdx
00007e97133d15c2  push rdi
00007e97133d15c3  push rsi
00007e97133d15c4  push r8
00007e97133d15c6  push r9
00007e97133d15c8  push r10
00007e97133d15ca  push r11
00007e97133d15cc  sub rsp, 0xF0
00007e97133d15d3  vmovaps [rsp], xmm0
00007e97133d15d8  vmovaps [rsp+0x10], xmm1
00007e97133d15de  vmovaps [rsp+0x20], xmm2
00007e97133d15e4  vmovaps [rsp+0x30], xmm3
00007e97133d15ea  vmovaps [rsp+0x40], xmm4
00007e97133d15f0  vmovaps [rsp+0x50], xmm5
00007e97133d15f6  vmovaps [rsp+0x60], xmm6
00007e97133d15fc  vmovaps [rsp+0x70], xmm7
00007e97133d1602  vmovaps [rsp+0x80], xmm8
00007e97133d160b  vmovaps [rsp+0x90], xmm9
00007e97133d1614  vmovaps [rsp+0xA0], xmm10
00007e97133d161d  vmovaps [rsp+0xB0], xmm11
00007e97133d1626  vmovaps [rsp+0xC0], xmm12
00007e97133d162f  vmovaps [rsp+0xD0], xmm13
00007e97133d1638  vmovaps [rsp+0xE0], xmm15
00007e97133d1641  sub rsp, 0x30
00007e97133d1645  movaps [rsp], xmm14
00007e97133d164a  movaps [rsp+0x10], xmm2
00007e97133d164f  movaps [rsp+0x20], xmm15
00007e97133d1655  lea rdi, [rsp]
00007e97133d1659  mov esi, 0x00
00007e97133d165e  mov rax, 0x58D8AED5F530
00007e97133d1668  call rax
00007e97133d166a  movaps xmm14, [rsp]
00007e97133d166f  add rsp, 0x30
00007e97133d1673  vmovaps xmm0, [rsp]
00007e97133d1678  vmovaps xmm1, [rsp+0x10]
00007e97133d167e  vmovaps xmm2, [rsp+0x20]
00007e97133d1684  vmovaps xmm3, [rsp+0x30]
00007e97133d168a  vmovaps xmm4, [rsp+0x40]
00007e97133d1690  vmovaps xmm5, [rsp+0x50]
00007e97133d1696  vmovaps xmm6, [rsp+0x60]
00007e97133d169c  vmovaps xmm7, [rsp+0x70]
00007e97133d16a2  vmovaps xmm8, [rsp+0x80]
00007e97133d16ab  vmovaps xmm9, [rsp+0x90]
00007e97133d16b4  vmovaps xmm10, [rsp+0xA0]
00007e97133d16bd  vmovaps xmm11, [rsp+0xB0]
00007e97133d16c6  vmovaps xmm12, [rsp+0xC0]
00007e97133d16cf  vmovaps xmm13, [rsp+0xD0]
00007e97133d16d8  vmovaps xmm15, [rsp+0xE0]
00007e97133d16e1  add rsp, 0xF0
00007e97133d16e8  pop r11
00007e97133d16ea  pop r10
00007e97133d16ec  pop r9
00007e97133d16ee  pop r8
00007e97133d16f0  pop rsi
00007e97133d16f1  pop rdi
00007e97133d16f2  pop rdx
00007e97133d16f3  pop rcx
00007e97133d16f4  pop rax
00007e97133d16f5  add rsp, 0x08
00007e97133d16f9  jmp 0x00007E97133CF8E7
00007e97133d16fe  sub rsp, 0x08
00007e97133d1702  push rax
00007e97133d1703  push rcx
00007e97133d1704  push rdx
00007e97133d1705  push rdi
00007e97133d1706  push rsi
00007e97133d1707  push r8
00007e97133d1709  push r9
00007e97133d170b  push r10
00007e97133d170d  push r11
00007e97133d170f  sub rsp, 0xF0
00007e97133d1716  vmovaps [rsp], xmm0
00007e97133d171b  vmovaps [rsp+0x10], xmm1
00007e97133d1721  vmovaps [rsp+0x20], xmm2
00007e97133d1727  vmovaps [rsp+0x30], xmm3
00007e97133d172d  vmovaps [rsp+0x40], xmm4
00007e97133d1733  vmovaps [rsp+0x50], xmm5
00007e97133d1739  vmovaps [rsp+0x60], xmm6
00007e97133d173f  vmovaps [rsp+0x70], xmm7
00007e97133d1745  vmovaps [rsp+0x80], xmm8
00007e97133d174e  vmovaps [rsp+0x90], xmm9
00007e97133d1757  vmovaps [rsp+0xA0], xmm10
00007e97133d1760  vmovaps [rsp+0xB0], xmm11
00007e97133d1769  vmovaps [rsp+0xC0], xmm12
00007e97133d1772  vmovaps [rsp+0xD0], xmm13
00007e97133d177b  vmovaps [rsp+0xE0], xmm14
00007e97133d1784  sub rsp, 0x30
00007e97133d1788  movaps [rsp], xmm15
00007e97133d178d  movaps [rsp+0x10], xmm2
00007e97133d1792  movaps [rsp+0x20], xmm1
00007e97133d1797  lea rdi, [rsp]
00007e97133d179b  mov esi, 0x00
00007e97133d17a0  mov rax, 0x58D8AED5F530
00007e97133d17aa  call rax
00007e97133d17ac  movaps xmm15, [rsp]
00007e97133d17b1  add rsp, 0x30
00007e97133d17b5  vmovaps xmm0, [rsp]
00007e97133d17ba  vmovaps xmm1, [rsp+0x10]
00007e97133d17c0  vmovaps xmm2, [rsp+0x20]
00007e97133d17c6  vmovaps xmm3, [rsp+0x30]
00007e97133d17cc  vmovaps xmm4, [rsp+0x40]
00007e97133d17d2  vmovaps xmm5, [rsp+0x50]
00007e97133d17d8  vmovaps xmm6, [rsp+0x60]
00007e97133d17de  vmovaps xmm7, [rsp+0x70]
00007e97133d17e4  vmovaps xmm8, [rsp+0x80]
00007e97133d17ed  vmovaps xmm9, [rsp+0x90]
00007e97133d17f6  vmovaps xmm10, [rsp+0xA0]
00007e97133d17ff  vmovaps xmm11, [rsp+0xB0]
00007e97133d1808  vmovaps xmm12, [rsp+0xC0]
00007e97133d1811  vmovaps xmm13, [rsp+0xD0]
00007e97133d181a  vmovaps xmm14, [rsp+0xE0]
00007e97133d1823  add rsp, 0xF0
00007e97133d182a  pop r11
00007e97133d182c  pop r10
00007e97133d182e  pop r9
00007e97133d1830  pop r8
00007e97133d1832  pop rsi
00007e97133d1833  pop rdi
00007e97133d1834  pop rdx
00007e97133d1835  pop rcx
00007e97133d1836  pop rax
00007e97133d1837  add rsp, 0x08
00007e97133d183b  jmp 0x00007E97133CF923
00007e97133d1840  call 0x00007E97131FF430
00007e97133d1845  jmp 0x00007E97133CF930
00007e97133d184a  sub rsp, 0x08
00007e97133d184e  push rax
00007e97133d184f  push rcx
00007e97133d1850  push rdx
00007e97133d1851  push rdi
00007e97133d1852  push rsi
00007e97133d1853  push r8
00007e97133d1855  push r9
00007e97133d1857  push r10
00007e97133d1859  push r11
00007e97133d185b  sub rsp, 0xF0
00007e97133d1862  vmovaps [rsp], xmm0
00007e97133d1867  vmovaps [rsp+0x10], xmm1
00007e97133d186d  vmovaps [rsp+0x20], xmm3
00007e97133d1873  vmovaps [rsp+0x30], xmm4
00007e97133d1879  vmovaps [rsp+0x40], xmm5
00007e97133d187f  vmovaps [rsp+0x50], xmm6
00007e97133d1885  vmovaps [rsp+0x60], xmm7
00007e97133d188b  vmovaps [rsp+0x70], xmm8
00007e97133d1891  vmovaps [rsp+0x80], xmm9
00007e97133d189a  vmovaps [rsp+0x90], xmm10
00007e97133d18a3  vmovaps [rsp+0xA0], xmm11
00007e97133d18ac  vmovaps [rsp+0xB0], xmm12
00007e97133d18b5  vmovaps [rsp+0xC0], xmm13
00007e97133d18be  vmovaps [rsp+0xD0], xmm14
00007e97133d18c7  vmovaps [rsp+0xE0], xmm15
00007e97133d18d0  sub rsp, 0x30
00007e97133d18d4  movaps [rsp], xmm2
00007e97133d18d8  movaps [rsp+0x10], xmm1
00007e97133d18dd  movaps [rsp+0x20], xmm14
00007e97133d18e3  lea rdi, [rsp]
00007e97133d18e7  mov esi, 0x00
00007e97133d18ec  mov rax, 0x58D8AED5F530
00007e97133d18f6  call rax
00007e97133d18f8  movaps xmm2, [rsp]
00007e97133d18fc  add rsp, 0x30
00007e97133d1900  vmovaps xmm0, [rsp]
00007e97133d1905  vmovaps xmm1, [rsp+0x10]
00007e97133d190b  vmovaps xmm3, [rsp+0x20]
00007e97133d1911  vmovaps xmm4, [rsp+0x30]
00007e97133d1917  vmovaps xmm5, [rsp+0x40]
00007e97133d191d  vmovaps xmm6, [rsp+0x50]
00007e97133d1923  vmovaps xmm7, [rsp+0x60]
00007e97133d1929  vmovaps xmm8, [rsp+0x70]
00007e97133d192f  vmovaps xmm9, [rsp+0x80]
00007e97133d1938  vmovaps xmm10, [rsp+0x90]
00007e97133d1941  vmovaps xmm11, [rsp+0xA0]
00007e97133d194a  vmovaps xmm12, [rsp+0xB0]
00007e97133d1953  vmovaps xmm13, [rsp+0xC0]
00007e97133d195c  vmovaps xmm14, [rsp+0xD0]
00007e97133d1965  vmovaps xmm15, [rsp+0xE0]
00007e97133d196e  add rsp, 0xF0
00007e97133d1975  pop r11
00007e97133d1977  pop r10
00007e97133d1979  pop r9
00007e97133d197b  pop r8
00007e97133d197d  pop rsi
00007e97133d197e  pop rdi
00007e97133d197f  pop rdx
00007e97133d1980  pop rcx
00007e97133d1981  pop rax
00007e97133d1982  add rsp, 0x08
00007e97133d1986  jmp 0x00007E97133CF96D
00007e97133d198b  sub rsp, 0x08
00007e97133d198f  push rax
00007e97133d1990  push rcx
00007e97133d1991  push rdx
00007e97133d1992  push rdi
00007e97133d1993  push rsi
00007e97133d1994  push r8
00007e97133d1996  push r9
00007e97133d1998  push r10
00007e97133d199a  push r11
00007e97133d199c  sub rsp, 0xF0
00007e97133d19a3  vmovaps [rsp], xmm0
00007e97133d19a8  vmovaps [rsp+0x10], xmm1
00007e97133d19ae  vmovaps [rsp+0x20], xmm2
00007e97133d19b4  vmovaps [rsp+0x30], xmm3
00007e97133d19ba  vmovaps [rsp+0x40], xmm4
00007e97133d19c0  vmovaps [rsp+0x50], xmm5
00007e97133d19c6  vmovaps [rsp+0x60], xmm6
00007e97133d19cc  vmovaps [rsp+0x70], xmm7
00007e97133d19d2  vmovaps [rsp+0x80], xmm8
00007e97133d19db  vmovaps [rsp+0x90], xmm9
00007e97133d19e4  vmovaps [rsp+0xA0], xmm10
00007e97133d19ed  vmovaps [rsp+0xB0], xmm11
00007e97133d19f6  vmovaps [rsp+0xC0], xmm12
00007e97133d19ff  vmovaps [rsp+0xD0], xmm13
00007e97133d1a08  vmovaps [rsp+0xE0], xmm14
00007e97133d1a11  sub rsp, 0x30
00007e97133d1a15  movaps [rsp], xmm15
00007e97133d1a1a  movaps [rsp+0x10], xmm14
00007e97133d1a20  movaps [rsp+0x20], xmm1
00007e97133d1a25  lea rdi, [rsp]
00007e97133d1a29  mov esi, 0x00
00007e97133d1a2e  mov rax, 0x58D8AED5F530
00007e97133d1a38  call rax
00007e97133d1a3a  movaps xmm15, [rsp]
00007e97133d1a3f  add rsp, 0x30
00007e97133d1a43  vmovaps xmm0, [rsp]
00007e97133d1a48  vmovaps xmm1, [rsp+0x10]
00007e97133d1a4e  vmovaps xmm2, [rsp+0x20]
00007e97133d1a54  vmovaps xmm3, [rsp+0x30]
00007e97133d1a5a  vmovaps xmm4, [rsp+0x40]
00007e97133d1a60  vmovaps xmm5, [rsp+0x50]
00007e97133d1a66  vmovaps xmm6, [rsp+0x60]
00007e97133d1a6c  vmovaps xmm7, [rsp+0x70]
00007e97133d1a72  vmovaps xmm8, [rsp+0x80]
00007e97133d1a7b  vmovaps xmm9, [rsp+0x90]
00007e97133d1a84  vmovaps xmm10, [rsp+0xA0]
00007e97133d1a8d  vmovaps xmm11, [rsp+0xB0]
00007e97133d1a96  vmovaps xmm12, [rsp+0xC0]
00007e97133d1a9f  vmovaps xmm13, [rsp+0xD0]
00007e97133d1aa8  vmovaps xmm14, [rsp+0xE0]
00007e97133d1ab1  add rsp, 0xF0
00007e97133d1ab8  pop r11
00007e97133d1aba  pop r10
00007e97133d1abc  pop r9
00007e97133d1abe  pop r8
00007e97133d1ac0  pop rsi
00007e97133d1ac1  pop rdi
00007e97133d1ac2  pop rdx
00007e97133d1ac3  pop rcx
00007e97133d1ac4  pop rax
00007e97133d1ac5  add rsp, 0x08
00007e97133d1ac9  jmp 0x00007E97133CF9E7
00007e97133d1ace  call 0x00007E97131FF430
00007e97133d1ad3  jmp 0x00007E97133CF9F4
00007e97133d1ad8  sub rsp, 0x08
00007e97133d1adc  push rax
00007e97133d1add  push rcx
00007e97133d1ade  push rdx
00007e97133d1adf  push rdi
00007e97133d1ae0  push rsi
00007e97133d1ae1  push r8
00007e97133d1ae3  push r9
00007e97133d1ae5  push r10
00007e97133d1ae7  push r11
00007e97133d1ae9  sub rsp, 0xF0
00007e97133d1af0  vmovaps [rsp], xmm0
00007e97133d1af5  vmovaps [rsp+0x10], xmm1
00007e97133d1afb  vmovaps [rsp+0x20], xmm2
00007e97133d1b01  vmovaps [rsp+0x30], xmm3
00007e97133d1b07  vmovaps [rsp+0x40], xmm4
00007e97133d1b0d  vmovaps [rsp+0x50], xmm5
00007e97133d1b13  vmovaps [rsp+0x60], xmm6
00007e97133d1b19  vmovaps [rsp+0x70], xmm7
00007e97133d1b1f  vmovaps [rsp+0x80], xmm8
00007e97133d1b28  vmovaps [rsp+0x90], xmm9
00007e97133d1b31  vmovaps [rsp+0xA0], xmm10
00007e97133d1b3a  vmovaps [rsp+0xB0], xmm11
00007e97133d1b43  vmovaps [rsp+0xC0], xmm12
00007e97133d1b4c  vmovaps [rsp+0xD0], xmm13
00007e97133d1b55  vmovaps [rsp+0xE0], xmm15
00007e97133d1b5e  sub rsp, 0x30
00007e97133d1b62  movaps [rsp], xmm14
00007e97133d1b67  movaps [rsp+0x10], xmm13
00007e97133d1b6d  movaps [rsp+0x20], xmm1
00007e97133d1b72  lea rdi, [rsp]
00007e97133d1b76  mov esi, 0x00
00007e97133d1b7b  mov rax, 0x58D8AED5F530
00007e97133d1b85  call rax
00007e97133d1b87  movaps xmm14, [rsp]
00007e97133d1b8c  add rsp, 0x30
00007e97133d1b90  vmovaps xmm0, [rsp]
00007e97133d1b95  vmovaps xmm1, [rsp+0x10]
00007e97133d1b9b  vmovaps xmm2, [rsp+0x20]
00007e97133d1ba1  vmovaps xmm3, [rsp+0x30]
00007e97133d1ba7  vmovaps xmm4, [rsp+0x40]
00007e97133d1bad  vmovaps xmm5, [rsp+0x50]
00007e97133d1bb3  vmovaps xmm6, [rsp+0x60]
00007e97133d1bb9  vmovaps xmm7, [rsp+0x70]
00007e97133d1bbf  vmovaps xmm8, [rsp+0x80]
00007e97133d1bc8  vmovaps xmm9, [rsp+0x90]
00007e97133d1bd1  vmovaps xmm10, [rsp+0xA0]
00007e97133d1bda  vmovaps xmm11, [rsp+0xB0]
00007e97133d1be3  vmovaps xmm12, [rsp+0xC0]
00007e97133d1bec  vmovaps xmm13, [rsp+0xD0]
00007e97133d1bf5  vmovaps xmm15, [rsp+0xE0]
00007e97133d1bfe  add rsp, 0xF0
00007e97133d1c05  pop r11
00007e97133d1c07  pop r10
00007e97133d1c09  pop r9
00007e97133d1c0b  pop r8
00007e97133d1c0d  pop rsi
00007e97133d1c0e  pop rdi
00007e97133d1c0f  pop rdx
00007e97133d1c10  pop rcx
00007e97133d1c11  pop rax
00007e97133d1c12  add rsp, 0x08
00007e97133d1c16  jmp 0x00007E97133CFAAF
00007e97133d1c1b  sub rsp, 0x08
00007e97133d1c1f  push rax
00007e97133d1c20  push rcx
00007e97133d1c21  push rdx
00007e97133d1c22  push rdi
00007e97133d1c23  push rsi
00007e97133d1c24  push r8
00007e97133d1c26  push r9
00007e97133d1c28  push r10
00007e97133d1c2a  push r11
00007e97133d1c2c  sub rsp, 0xF0
00007e97133d1c33  vmovaps [rsp], xmm0
00007e97133d1c38  vmovaps [rsp+0x10], xmm1
00007e97133d1c3e  vmovaps [rsp+0x20], xmm2
00007e97133d1c44  vmovaps [rsp+0x30], xmm3
00007e97133d1c4a  vmovaps [rsp+0x40], xmm4
00007e97133d1c50  vmovaps [rsp+0x50], xmm5
00007e97133d1c56  vmovaps [rsp+0x60], xmm6
00007e97133d1c5c  vmovaps [rsp+0x70], xmm7
00007e97133d1c62  vmovaps [rsp+0x80], xmm8
00007e97133d1c6b  vmovaps [rsp+0x90], xmm9
00007e97133d1c74  vmovaps [rsp+0xA0], xmm10
00007e97133d1c7d  vmovaps [rsp+0xB0], xmm11
00007e97133d1c86  vmovaps [rsp+0xC0], xmm12
00007e97133d1c8f  vmovaps [rsp+0xD0], xmm13
00007e97133d1c98  vmovaps [rsp+0xE0], xmm14
00007e97133d1ca1  sub rsp, 0x30
00007e97133d1ca5  movaps [rsp], xmm15
00007e97133d1caa  movaps [rsp+0x10], xmm13
00007e97133d1cb0  movaps [rsp+0x20], xmm1
00007e97133d1cb5  lea rdi, [rsp]
00007e97133d1cb9  mov esi, 0x00
00007e97133d1cbe  mov rax, 0x58D8AED5F530
00007e97133d1cc8  call rax
00007e97133d1cca  movaps xmm15, [rsp]
00007e97133d1ccf  add rsp, 0x30
00007e97133d1cd3  vmovaps xmm0, [rsp]
00007e97133d1cd8  vmovaps xmm1, [rsp+0x10]
00007e97133d1cde  vmovaps xmm2, [rsp+0x20]
00007e97133d1ce4  vmovaps xmm3, [rsp+0x30]
00007e97133d1cea  vmovaps xmm4, [rsp+0x40]
00007e97133d1cf0  vmovaps xmm5, [rsp+0x50]
00007e97133d1cf6  vmovaps xmm6, [rsp+0x60]
00007e97133d1cfc  vmovaps xmm7, [rsp+0x70]
00007e97133d1d02  vmovaps xmm8, [rsp+0x80]
00007e97133d1d0b  vmovaps xmm9, [rsp+0x90]
00007e97133d1d14  vmovaps xmm10, [rsp+0xA0]
00007e97133d1d1d  vmovaps xmm11, [rsp+0xB0]
00007e97133d1d26  vmovaps xmm12, [rsp+0xC0]
00007e97133d1d2f  vmovaps xmm13, [rsp+0xD0]
00007e97133d1d38  vmovaps xmm14, [rsp+0xE0]
00007e97133d1d41  add rsp, 0xF0
00007e97133d1d48  pop r11
00007e97133d1d4a  pop r10
00007e97133d1d4c  pop r9
00007e97133d1d4e  pop r8
00007e97133d1d50  pop rsi
00007e97133d1d51  pop rdi
00007e97133d1d52  pop rdx
00007e97133d1d53  pop rcx
00007e97133d1d54  pop rax
00007e97133d1d55  add rsp, 0x08
00007e97133d1d59  jmp 0x00007E97133CFAEB
00007e97133d1d5e  call 0x00007E97131FF430
00007e97133d1d63  jmp 0x00007E97133CFAF8
00007e97133d1d68  sub rsp, 0x08
00007e97133d1d6c  push rax
00007e97133d1d6d  push rcx
00007e97133d1d6e  push rdx
00007e97133d1d6f  push rdi
00007e97133d1d70  push rsi
00007e97133d1d71  push r8
00007e97133d1d73  push r9
00007e97133d1d75  push r10
00007e97133d1d77  push r11
00007e97133d1d79  sub rsp, 0xF0
00007e97133d1d80  vmovaps [rsp], xmm0
00007e97133d1d85  vmovaps [rsp+0x10], xmm1
00007e97133d1d8b  vmovaps [rsp+0x20], xmm2
00007e97133d1d91  vmovaps [rsp+0x30], xmm3
00007e97133d1d97  vmovaps [rsp+0x40], xmm4
00007e97133d1d9d  vmovaps [rsp+0x50], xmm5
00007e97133d1da3  vmovaps [rsp+0x60], xmm6
00007e97133d1da9  vmovaps [rsp+0x70], xmm7
00007e97133d1daf  vmovaps [rsp+0x80], xmm8
00007e97133d1db8  vmovaps [rsp+0x90], xmm9
00007e97133d1dc1  vmovaps [rsp+0xA0], xmm10
00007e97133d1dca  vmovaps [rsp+0xB0], xmm11
00007e97133d1dd3  vmovaps [rsp+0xC0], xmm12
00007e97133d1ddc  vmovaps [rsp+0xD0], xmm13
00007e97133d1de5  vmovaps [rsp+0xE0], xmm15
00007e97133d1dee  sub rsp, 0x30
00007e97133d1df2  movaps [rsp], xmm14
00007e97133d1df7  movaps [rsp+0x10], xmm13
00007e97133d1dfd  movaps [rsp+0x20], xmm2
00007e97133d1e02  lea rdi, [rsp]
00007e97133d1e06  mov esi, 0x00
00007e97133d1e0b  mov rax, 0x58D8AED5F530
00007e97133d1e15  call rax
00007e97133d1e17  movaps xmm14, [rsp]
00007e97133d1e1c  add rsp, 0x30
00007e97133d1e20  vmovaps xmm0, [rsp]
00007e97133d1e25  vmovaps xmm1, [rsp+0x10]
00007e97133d1e2b  vmovaps xmm2, [rsp+0x20]
00007e97133d1e31  vmovaps xmm3, [rsp+0x30]
00007e97133d1e37  vmovaps xmm4, [rsp+0x40]
00007e97133d1e3d  vmovaps xmm5, [rsp+0x50]
00007e97133d1e43  vmovaps xmm6, [rsp+0x60]
00007e97133d1e49  vmovaps xmm7, [rsp+0x70]
00007e97133d1e4f  vmovaps xmm8, [rsp+0x80]
00007e97133d1e58  vmovaps xmm9, [rsp+0x90]
00007e97133d1e61  vmovaps xmm10, [rsp+0xA0]
00007e97133d1e6a  vmovaps xmm11, [rsp+0xB0]
00007e97133d1e73  vmovaps xmm12, [rsp+0xC0]
00007e97133d1e7c  vmovaps xmm13, [rsp+0xD0]
00007e97133d1e85  vmovaps xmm15, [rsp+0xE0]
00007e97133d1e8e  add rsp, 0xF0
00007e97133d1e95  pop r11
00007e97133d1e97  pop r10
00007e97133d1e99  pop r9
00007e97133d1e9b  pop r8
00007e97133d1e9d  pop rsi
00007e97133d1e9e  pop rdi
00007e97133d1e9f  pop rdx
00007e97133d1ea0  pop rcx
00007e97133d1ea1  pop rax
00007e97133d1ea2  add rsp, 0x08
00007e97133d1ea6  jmp 0x00007E97133CFB24
00007e97133d1eab  sub rsp, 0x08
00007e97133d1eaf  push rax
00007e97133d1eb0  push rcx
00007e97133d1eb1  push rdx
00007e97133d1eb2  push rdi
00007e97133d1eb3  push rsi
00007e97133d1eb4  push r8
00007e97133d1eb6  push r9
00007e97133d1eb8  push r10
00007e97133d1eba  push r11
00007e97133d1ebc  sub rsp, 0xF0
00007e97133d1ec3  vmovaps [rsp], xmm0
00007e97133d1ec8  vmovaps [rsp+0x10], xmm2
00007e97133d1ece  vmovaps [rsp+0x20], xmm3
00007e97133d1ed4  vmovaps [rsp+0x30], xmm4
00007e97133d1eda  vmovaps [rsp+0x40], xmm5
00007e97133d1ee0  vmovaps [rsp+0x50], xmm6
00007e97133d1ee6  vmovaps [rsp+0x60], xmm7
00007e97133d1eec  vmovaps [rsp+0x70], xmm8
00007e97133d1ef2  vmovaps [rsp+0x80], xmm9
00007e97133d1efb  vmovaps [rsp+0x90], xmm10
00007e97133d1f04  vmovaps [rsp+0xA0], xmm11
00007e97133d1f0d  vmovaps [rsp+0xB0], xmm12
00007e97133d1f16  vmovaps [rsp+0xC0], xmm13
00007e97133d1f1f  vmovaps [rsp+0xD0], xmm14
00007e97133d1f28  vmovaps [rsp+0xE0], xmm15
00007e97133d1f31  sub rsp, 0x30
00007e97133d1f35  movaps [rsp], xmm1
00007e97133d1f39  movaps [rsp+0x10], xmm13
00007e97133d1f3f  movaps [rsp+0x20], xmm2
00007e97133d1f44  lea rdi, [rsp]
00007e97133d1f48  mov esi, 0x00
00007e97133d1f4d  mov rax, 0x58D8AED5F530
00007e97133d1f57  call rax
00007e97133d1f59  movaps xmm1, [rsp]
00007e97133d1f5d  add rsp, 0x30
00007e97133d1f61  vmovaps xmm0, [rsp]
00007e97133d1f66  vmovaps xmm2, [rsp+0x10]
00007e97133d1f6c  vmovaps xmm3, [rsp+0x20]
00007e97133d1f72  vmovaps xmm4, [rsp+0x30]
00007e97133d1f78  vmovaps xmm5, [rsp+0x40]
00007e97133d1f7e  vmovaps xmm6, [rsp+0x50]
00007e97133d1f84  vmovaps xmm7, [rsp+0x60]
00007e97133d1f8a  vmovaps xmm8, [rsp+0x70]
00007e97133d1f90  vmovaps xmm9, [rsp+0x80]
00007e97133d1f99  vmovaps xmm10, [rsp+0x90]
00007e97133d1fa2  vmovaps xmm11, [rsp+0xA0]
00007e97133d1fab  vmovaps xmm12, [rsp+0xB0]
00007e97133d1fb4  vmovaps xmm13, [rsp+0xC0]
00007e97133d1fbd  vmovaps xmm14, [rsp+0xD0]
00007e97133d1fc6  vmovaps xmm15, [rsp+0xE0]
00007e97133d1fcf  add rsp, 0xF0
00007e97133d1fd6  pop r11
00007e97133d1fd8  pop r10
00007e97133d1fda  pop r9
00007e97133d1fdc  pop r8
00007e97133d1fde  pop rsi
00007e97133d1fdf  pop rdi
00007e97133d1fe0  pop rdx
00007e97133d1fe1  pop rcx
00007e97133d1fe2  pop rax
00007e97133d1fe3  add rsp, 0x08
00007e97133d1fe7  jmp 0x00007E97133CFB52
00007e97133d1fec  sub rsp, 0x08
00007e97133d1ff0  push rax
00007e97133d1ff1  push rcx
00007e97133d1ff2  push rdx
00007e97133d1ff3  push rdi
00007e97133d1ff4  push rsi
00007e97133d1ff5  push r8
00007e97133d1ff7  push r9
00007e97133d1ff9  push r10
00007e97133d1ffb  push r11
00007e97133d1ffd  sub rsp, 0xF0
00007e97133d2004  vmovaps [rsp], xmm0
00007e97133d2009  vmovaps [rsp+0x10], xmm1
00007e97133d200f  vmovaps [rsp+0x20], xmm3
00007e97133d2015  vmovaps [rsp+0x30], xmm4
00007e97133d201b  vmovaps [rsp+0x40], xmm5
00007e97133d2021  vmovaps [rsp+0x50], xmm6
00007e97133d2027  vmovaps [rsp+0x60], xmm7
00007e97133d202d  vmovaps [rsp+0x70], xmm8
00007e97133d2033  vmovaps [rsp+0x80], xmm9
00007e97133d203c  vmovaps [rsp+0x90], xmm10
00007e97133d2045  vmovaps [rsp+0xA0], xmm11
00007e97133d204e  vmovaps [rsp+0xB0], xmm12
00007e97133d2057  vmovaps [rsp+0xC0], xmm13
00007e97133d2060  vmovaps [rsp+0xD0], xmm14
00007e97133d2069  vmovaps [rsp+0xE0], xmm15
00007e97133d2072  sub rsp, 0x30
00007e97133d2076  movaps [rsp], xmm2
00007e97133d207a  movaps [rsp+0x10], xmm1
00007e97133d207f  movaps [rsp+0x20], xmm13
00007e97133d2085  lea rdi, [rsp]
00007e97133d2089  mov esi, 0x00
00007e97133d208e  mov rax, 0x58D8AED5F530
00007e97133d2098  call rax
00007e97133d209a  movaps xmm2, [rsp]
00007e97133d209e  add rsp, 0x30
00007e97133d20a2  vmovaps xmm0, [rsp]
00007e97133d20a7  vmovaps xmm1, [rsp+0x10]
00007e97133d20ad  vmovaps xmm3, [rsp+0x20]
00007e97133d20b3  vmovaps xmm4, [rsp+0x30]
00007e97133d20b9  vmovaps xmm5, [rsp+0x40]
00007e97133d20bf  vmovaps xmm6, [rsp+0x50]
00007e97133d20c5  vmovaps xmm7, [rsp+0x60]
00007e97133d20cb  vmovaps xmm8, [rsp+0x70]
00007e97133d20d1  vmovaps xmm9, [rsp+0x80]
00007e97133d20da  vmovaps xmm10, [rsp+0x90]
00007e97133d20e3  vmovaps xmm11, [rsp+0xA0]
00007e97133d20ec  vmovaps xmm12, [rsp+0xB0]
00007e97133d20f5  vmovaps xmm13, [rsp+0xC0]
00007e97133d20fe  vmovaps xmm14, [rsp+0xD0]
00007e97133d2107  vmovaps xmm15, [rsp+0xE0]
00007e97133d2110  add rsp, 0xF0
00007e97133d2117  pop r11
00007e97133d2119  pop r10
00007e97133d211b  pop r9
00007e97133d211d  pop r8
00007e97133d211f  pop rsi
00007e97133d2120  pop rdi
00007e97133d2121  pop rdx
00007e97133d2122  pop rcx
00007e97133d2123  pop rax
00007e97133d2124  add rsp, 0x08
00007e97133d2128  jmp 0x00007E97133CFBAB
00007e97133d212d  call 0x00007E97131FF430
00007e97133d2132  jmp 0x00007E97133CFBB8
00007e97133d2137  sub rsp, 0x08
00007e97133d213b  push rax
00007e97133d213c  push rcx
00007e97133d213d  push rdx
00007e97133d213e  push rdi
00007e97133d213f  push rsi
00007e97133d2140  push r8
00007e97133d2142  push r9
00007e97133d2144  push r10
00007e97133d2146  push r11
00007e97133d2148  sub rsp, 0xF0
00007e97133d214f  vmovaps [rsp], xmm0
00007e97133d2154  vmovaps [rsp+0x10], xmm1
00007e97133d215a  vmovaps [rsp+0x20], xmm2
00007e97133d2160  vmovaps [rsp+0x30], xmm3
00007e97133d2166  vmovaps [rsp+0x40], xmm4
00007e97133d216c  vmovaps [rsp+0x50], xmm5
00007e97133d2172  vmovaps [rsp+0x60], xmm6
00007e97133d2178  vmovaps [rsp+0x70], xmm7
00007e97133d217e  vmovaps [rsp+0x80], xmm8
00007e97133d2187  vmovaps [rsp+0x90], xmm9
00007e97133d2190  vmovaps [rsp+0xA0], xmm10
00007e97133d2199  vmovaps [rsp+0xB0], xmm11
00007e97133d21a2  vmovaps [rsp+0xC0], xmm12
00007e97133d21ab  vmovaps [rsp+0xD0], xmm13
00007e97133d21b4  vmovaps [rsp+0xE0], xmm14
00007e97133d21bd  sub rsp, 0x30
00007e97133d21c1  movaps [rsp], xmm15
00007e97133d21c6  movaps [rsp+0x10], xmm13
00007e97133d21cc  movaps [rsp+0x20], xmm1
00007e97133d21d1  lea rdi, [rsp]
00007e97133d21d5  mov esi, 0x00
00007e97133d21da  mov rax, 0x58D8AED5F530
00007e97133d21e4  call rax
00007e97133d21e6  movaps xmm15, [rsp]
00007e97133d21eb  add rsp, 0x30
00007e97133d21ef  vmovaps xmm0, [rsp]
00007e97133d21f4  vmovaps xmm1, [rsp+0x10]
00007e97133d21fa  vmovaps xmm2, [rsp+0x20]
00007e97133d2200  vmovaps xmm3, [rsp+0x30]
00007e97133d2206  vmovaps xmm4, [rsp+0x40]
00007e97133d220c  vmovaps xmm5, [rsp+0x50]
00007e97133d2212  vmovaps xmm6, [rsp+0x60]
00007e97133d2218  vmovaps xmm7, [rsp+0x70]
00007e97133d221e  vmovaps xmm8, [rsp+0x80]
00007e97133d2227  vmovaps xmm9, [rsp+0x90]
00007e97133d2230  vmovaps xmm10, [rsp+0xA0]
00007e97133d2239  vmovaps xmm11, [rsp+0xB0]
00007e97133d2242  vmovaps xmm12, [rsp+0xC0]
00007e97133d224b  vmovaps xmm13, [rsp+0xD0]
00007e97133d2254  vmovaps xmm14, [rsp+0xE0]
00007e97133d225d  add rsp, 0xF0
00007e97133d2264  pop r11
00007e97133d2266  pop r10
00007e97133d2268  pop r9
00007e97133d226a  pop r8
00007e97133d226c  pop rsi
00007e97133d226d  pop rdi
00007e97133d226e  pop rdx
00007e97133d226f  pop rcx
00007e97133d2270  pop rax
00007e97133d2271  add rsp, 0x08
00007e97133d2275  jmp 0x00007E97133CFBF7
00007e97133d227a  sub rsp, 0x08
00007e97133d227e  push rax
00007e97133d227f  push rcx
00007e97133d2280  push rdx
00007e97133d2281  push rdi
00007e97133d2282  push rsi
00007e97133d2283  push r8
00007e97133d2285  push r9
00007e97133d2287  push r10
00007e97133d2289  push r11
00007e97133d228b  sub rsp, 0xF0
00007e97133d2292  vmovaps [rsp], xmm0
00007e97133d2297  vmovaps [rsp+0x10], xmm1
00007e97133d229d  vmovaps [rsp+0x20], xmm2
00007e97133d22a3  vmovaps [rsp+0x30], xmm3
00007e97133d22a9  vmovaps [rsp+0x40], xmm4
00007e97133d22af  vmovaps [rsp+0x50], xmm5
00007e97133d22b5  vmovaps [rsp+0x60], xmm6
00007e97133d22bb  vmovaps [rsp+0x70], xmm7
00007e97133d22c1  vmovaps [rsp+0x80], xmm8
00007e97133d22ca  vmovaps [rsp+0x90], xmm9
00007e97133d22d3  vmovaps [rsp+0xA0], xmm10
00007e97133d22dc  vmovaps [rsp+0xB0], xmm11
00007e97133d22e5  vmovaps [rsp+0xC0], xmm12
00007e97133d22ee  vmovaps [rsp+0xD0], xmm13
00007e97133d22f7  vmovaps [rsp+0xE0], xmm15
00007e97133d2300  sub rsp, 0x30
00007e97133d2304  movaps [rsp], xmm14
00007e97133d2309  movaps [rsp+0x10], xmm11
00007e97133d230f  movaps [rsp+0x20], xmm1
00007e97133d2314  lea rdi, [rsp]
00007e97133d2318  mov esi, 0x00
00007e97133d231d  mov rax, 0x58D8AED5F530
00007e97133d2327  call rax
00007e97133d2329  movaps xmm14, [rsp]
00007e97133d232e  add rsp, 0x30
00007e97133d2332  vmovaps xmm0, [rsp]
00007e97133d2337  vmovaps xmm1, [rsp+0x10]
00007e97133d233d  vmovaps xmm2, [rsp+0x20]
00007e97133d2343  vmovaps xmm3, [rsp+0x30]
00007e97133d2349  vmovaps xmm4, [rsp+0x40]
00007e97133d234f  vmovaps xmm5, [rsp+0x50]
00007e97133d2355  vmovaps xmm6, [rsp+0x60]
00007e97133d235b  vmovaps xmm7, [rsp+0x70]
00007e97133d2361  vmovaps xmm8, [rsp+0x80]
00007e97133d236a  vmovaps xmm9, [rsp+0x90]
00007e97133d2373  vmovaps xmm10, [rsp+0xA0]
00007e97133d237c  vmovaps xmm11, [rsp+0xB0]
00007e97133d2385  vmovaps xmm12, [rsp+0xC0]
00007e97133d238e  vmovaps xmm13, [rsp+0xD0]
00007e97133d2397  vmovaps xmm15, [rsp+0xE0]
00007e97133d23a0  add rsp, 0xF0
00007e97133d23a7  pop r11
00007e97133d23a9  pop r10
00007e97133d23ab  pop r9
00007e97133d23ad  pop r8
00007e97133d23af  pop rsi
00007e97133d23b0  pop rdi
00007e97133d23b1  pop rdx
00007e97133d23b2  pop rcx
00007e97133d23b3  pop rax
00007e97133d23b4  add rsp, 0x08
00007e97133d23b8  jmp 0x00007E97133CFC21
00007e97133d23bd  sub rsp, 0x08
00007e97133d23c1  push rax
00007e97133d23c2  push rcx
00007e97133d23c3  push rdx
00007e97133d23c4  push rdi
00007e97133d23c5  push rsi
00007e97133d23c6  push r8
00007e97133d23c8  push r9
00007e97133d23ca  push r10
00007e97133d23cc  push r11
00007e97133d23ce  sub rsp, 0xF0
00007e97133d23d5  vmovaps [rsp], xmm0
00007e97133d23da  vmovaps [rsp+0x10], xmm1
00007e97133d23e0  vmovaps [rsp+0x20], xmm2
00007e97133d23e6  vmovaps [rsp+0x30], xmm3
00007e97133d23ec  vmovaps [rsp+0x40], xmm4
00007e97133d23f2  vmovaps [rsp+0x50], xmm5
00007e97133d23f8  vmovaps [rsp+0x60], xmm6
00007e97133d23fe  vmovaps [rsp+0x70], xmm7
00007e97133d2404  vmovaps [rsp+0x80], xmm8
00007e97133d240d  vmovaps [rsp+0x90], xmm9
00007e97133d2416  vmovaps [rsp+0xA0], xmm10
00007e97133d241f  vmovaps [rsp+0xB0], xmm11
00007e97133d2428  vmovaps [rsp+0xC0], xmm12
00007e97133d2431  vmovaps [rsp+0xD0], xmm14
00007e97133d243a  vmovaps [rsp+0xE0], xmm15
00007e97133d2443  sub rsp, 0x30
00007e97133d2447  movaps [rsp], xmm13
00007e97133d244c  movaps [rsp+0x10], xmm11
00007e97133d2452  movaps [rsp+0x20], xmm1
00007e97133d2457  lea rdi, [rsp]
00007e97133d245b  mov esi, 0x00
00007e97133d2460  mov rax, 0x58D8AED5F530
00007e97133d246a  call rax
00007e97133d246c  movaps xmm13, [rsp]
00007e97133d2471  add rsp, 0x30
00007e97133d2475  vmovaps xmm0, [rsp]
00007e97133d247a  vmovaps xmm1, [rsp+0x10]
00007e97133d2480  vmovaps xmm2, [rsp+0x20]
00007e97133d2486  vmovaps xmm3, [rsp+0x30]
00007e97133d248c  vmovaps xmm4, [rsp+0x40]
00007e97133d2492  vmovaps xmm5, [rsp+0x50]
00007e97133d2498  vmovaps xmm6, [rsp+0x60]
00007e97133d249e  vmovaps xmm7, [rsp+0x70]
00007e97133d24a4  vmovaps xmm8, [rsp+0x80]
00007e97133d24ad  vmovaps xmm9, [rsp+0x90]
00007e97133d24b6  vmovaps xmm10, [rsp+0xA0]
00007e97133d24bf  vmovaps xmm11, [rsp+0xB0]
00007e97133d24c8  vmovaps xmm12, [rsp+0xC0]
00007e97133d24d1  vmovaps xmm14, [rsp+0xD0]
00007e97133d24da  vmovaps xmm15, [rsp+0xE0]
00007e97133d24e3  add rsp, 0xF0
00007e97133d24ea  pop r11
00007e97133d24ec  pop r10
00007e97133d24ee  pop r9
00007e97133d24f0  pop r8
00007e97133d24f2  pop rsi
00007e97133d24f3  pop rdi
00007e97133d24f4  pop rdx
00007e97133d24f5  pop rcx
00007e97133d24f6  pop rax
00007e97133d24f7  add rsp, 0x08
00007e97133d24fb  jmp 0x00007E97133CFC76
00007e97133d2500  call 0x00007E97131FF430
00007e97133d2505  jmp 0x00007E97133CFC83
00007e97133d250a  sub rsp, 0x08
00007e97133d250e  push rax
00007e97133d250f  push rcx
00007e97133d2510  push rdx
00007e97133d2511  push rdi
00007e97133d2512  push rsi
00007e97133d2513  push r8
00007e97133d2515  push r9
00007e97133d2517  push r10
00007e97133d2519  push r11
00007e97133d251b  sub rsp, 0xF0
00007e97133d2522  vmovaps [rsp], xmm0
00007e97133d2527  vmovaps [rsp+0x10], xmm1
00007e97133d252d  vmovaps [rsp+0x20], xmm2
00007e97133d2533  vmovaps [rsp+0x30], xmm3
00007e97133d2539  vmovaps [rsp+0x40], xmm4
00007e97133d253f  vmovaps [rsp+0x50], xmm5
00007e97133d2545  vmovaps [rsp+0x60], xmm6
00007e97133d254b  vmovaps [rsp+0x70], xmm7
00007e97133d2551  vmovaps [rsp+0x80], xmm8
00007e97133d255a  vmovaps [rsp+0x90], xmm9
00007e97133d2563  vmovaps [rsp+0xA0], xmm10
00007e97133d256c  vmovaps [rsp+0xB0], xmm11
00007e97133d2575  vmovaps [rsp+0xC0], xmm12
00007e97133d257e  vmovaps [rsp+0xD0], xmm13
00007e97133d2587  vmovaps [rsp+0xE0], xmm14
00007e97133d2590  sub rsp, 0x30
00007e97133d2594  movaps [rsp], xmm15
00007e97133d2599  movaps [rsp+0x10], xmm11
00007e97133d259f  movaps [rsp+0x20], xmm1
00007e97133d25a4  lea rdi, [rsp]
00007e97133d25a8  mov esi, 0x00
00007e97133d25ad  mov rax, 0x58D8AED5F530
00007e97133d25b7  call rax
00007e97133d25b9  movaps xmm15, [rsp]
00007e97133d25be  add rsp, 0x30
00007e97133d25c2  vmovaps xmm0, [rsp]
00007e97133d25c7  vmovaps xmm1, [rsp+0x10]
00007e97133d25cd  vmovaps xmm2, [rsp+0x20]
00007e97133d25d3  vmovaps xmm3, [rsp+0x30]
00007e97133d25d9  vmovaps xmm4, [rsp+0x40]
00007e97133d25df  vmovaps xmm5, [rsp+0x50]
00007e97133d25e5  vmovaps xmm6, [rsp+0x60]
00007e97133d25eb  vmovaps xmm7, [rsp+0x70]
00007e97133d25f1  vmovaps xmm8, [rsp+0x80]
00007e97133d25fa  vmovaps xmm9, [rsp+0x90]
00007e97133d2603  vmovaps xmm10, [rsp+0xA0]
00007e97133d260c  vmovaps xmm11, [rsp+0xB0]
00007e97133d2615  vmovaps xmm12, [rsp+0xC0]
00007e97133d261e  vmovaps xmm13, [rsp+0xD0]
00007e97133d2627  vmovaps xmm14, [rsp+0xE0]
00007e97133d2630  add rsp, 0xF0
00007e97133d2637  pop r11
00007e97133d2639  pop r10
00007e97133d263b  pop r9
00007e97133d263d  pop r8
00007e97133d263f  pop rsi
00007e97133d2640  pop rdi
00007e97133d2641  pop rdx
00007e97133d2642  pop rcx
00007e97133d2643  pop rax
00007e97133d2644  add rsp, 0x08
00007e97133d2648  jmp 0x00007E97133CFCBC
00007e97133d264d  sub rsp, 0x08
00007e97133d2651  push rax
00007e97133d2652  push rcx
00007e97133d2653  push rdx
00007e97133d2654  push rdi
00007e97133d2655  push rsi
00007e97133d2656  push r8
00007e97133d2658  push r9
00007e97133d265a  push r10
00007e97133d265c  push r11
00007e97133d265e  sub rsp, 0xF0
00007e97133d2665  vmovaps [rsp], xmm0
00007e97133d266a  vmovaps [rsp+0x10], xmm1
00007e97133d2670  vmovaps [rsp+0x20], xmm2
00007e97133d2676  vmovaps [rsp+0x30], xmm3
00007e97133d267c  vmovaps [rsp+0x40], xmm4
00007e97133d2682  vmovaps [rsp+0x50], xmm5
00007e97133d2688  vmovaps [rsp+0x60], xmm6
00007e97133d268e  vmovaps [rsp+0x70], xmm7
00007e97133d2694  vmovaps [rsp+0x80], xmm8
00007e97133d269d  vmovaps [rsp+0x90], xmm9
00007e97133d26a6  vmovaps [rsp+0xA0], xmm10
00007e97133d26af  vmovaps [rsp+0xB0], xmm12
00007e97133d26b8  vmovaps [rsp+0xC0], xmm13
00007e97133d26c1  vmovaps [rsp+0xD0], xmm14
00007e97133d26ca  vmovaps [rsp+0xE0], xmm15
00007e97133d26d3  sub rsp, 0x30
00007e97133d26d7  movaps [rsp], xmm11
00007e97133d26dc  movaps [rsp+0x10], xmm6
00007e97133d26e1  movaps [rsp+0x20], xmm14
00007e97133d26e7  lea rdi, [rsp]
00007e97133d26eb  mov esi, 0x00
00007e97133d26f0  mov rax, 0x58D8AED5F530
00007e97133d26fa  call rax
00007e97133d26fc  movaps xmm11, [rsp]
00007e97133d2701  add rsp, 0x30
00007e97133d2705  vmovaps xmm0, [rsp]
00007e97133d270a  vmovaps xmm1, [rsp+0x10]
00007e97133d2710  vmovaps xmm2, [rsp+0x20]
00007e97133d2716  vmovaps xmm3, [rsp+0x30]
00007e97133d271c  vmovaps xmm4, [rsp+0x40]
00007e97133d2722  vmovaps xmm5, [rsp+0x50]
00007e97133d2728  vmovaps xmm6, [rsp+0x60]
00007e97133d272e  vmovaps xmm7, [rsp+0x70]
00007e97133d2734  vmovaps xmm8, [rsp+0x80]
00007e97133d273d  vmovaps xmm9, [rsp+0x90]
00007e97133d2746  vmovaps xmm10, [rsp+0xA0]
00007e97133d274f  vmovaps xmm12, [rsp+0xB0]
00007e97133d2758  vmovaps xmm13, [rsp+0xC0]
00007e97133d2761  vmovaps xmm14, [rsp+0xD0]
00007e97133d276a  vmovaps xmm15, [rsp+0xE0]
00007e97133d2773  add rsp, 0xF0
00007e97133d277a  pop r11
00007e97133d277c  pop r10
00007e97133d277e  pop r9
00007e97133d2780  pop r8
00007e97133d2782  pop rsi
00007e97133d2783  pop rdi
00007e97133d2784  pop rdx
00007e97133d2785  pop rcx
00007e97133d2786  pop rax
00007e97133d2787  add rsp, 0x08
00007e97133d278b  jmp 0x00007E97133CFD34
00007e97133d2790  call 0x00007E97131FF430
00007e97133d2795  jmp 0x00007E97133CFD3E
00007e97133d279a  sub rsp, 0x08
00007e97133d279e  push rax
00007e97133d279f  push rcx
00007e97133d27a0  push rdx
00007e97133d27a1  push rdi
00007e97133d27a2  push rsi
00007e97133d27a3  push r8
00007e97133d27a5  push r9
00007e97133d27a7  push r10
00007e97133d27a9  push r11
00007e97133d27ab  sub rsp, 0xF0
00007e97133d27b2  vmovaps [rsp], xmm0
00007e97133d27b7  vmovaps [rsp+0x10], xmm1
00007e97133d27bd  vmovaps [rsp+0x20], xmm2
00007e97133d27c3  vmovaps [rsp+0x30], xmm3
00007e97133d27c9  vmovaps [rsp+0x40], xmm4
00007e97133d27cf  vmovaps [rsp+0x50], xmm5
00007e97133d27d5  vmovaps [rsp+0x60], xmm6
00007e97133d27db  vmovaps [rsp+0x70], xmm7
00007e97133d27e1  vmovaps [rsp+0x80], xmm8
00007e97133d27ea  vmovaps [rsp+0x90], xmm9
00007e97133d27f3  vmovaps [rsp+0xA0], xmm10
00007e97133d27fc  vmovaps [rsp+0xB0], xmm11
00007e97133d2805  vmovaps [rsp+0xC0], xmm12
00007e97133d280e  vmovaps [rsp+0xD0], xmm13
00007e97133d2817  vmovaps [rsp+0xE0], xmm15
00007e97133d2820  sub rsp, 0x30
00007e97133d2824  movaps [rsp], xmm14
00007e97133d2829  movaps [rsp+0x10], xmm6
00007e97133d282e  movaps [rsp+0x20], xmm2
00007e97133d2833  lea rdi, [rsp]
00007e97133d2837  mov esi, 0x00
00007e97133d283c  mov rax, 0x58D8AED5F530
00007e97133d2846  call rax
00007e97133d2848  movaps xmm14, [rsp]
00007e97133d284d  add rsp, 0x30
00007e97133d2851  vmovaps xmm0, [rsp]
00007e97133d2856  vmovaps xmm1, [rsp+0x10]
00007e97133d285c  vmovaps xmm2, [rsp+0x20]
00007e97133d2862  vmovaps xmm3, [rsp+0x30]
00007e97133d2868  vmovaps xmm4, [rsp+0x40]
00007e97133d286e  vmovaps xmm5, [rsp+0x50]
00007e97133d2874  vmovaps xmm6, [rsp+0x60]
00007e97133d287a  vmovaps xmm7, [rsp+0x70]
00007e97133d2880  vmovaps xmm8, [rsp+0x80]
00007e97133d2889  vmovaps xmm9, [rsp+0x90]
00007e97133d2892  vmovaps xmm10, [rsp+0xA0]
00007e97133d289b  vmovaps xmm11, [rsp+0xB0]
00007e97133d28a4  vmovaps xmm12, [rsp+0xC0]
00007e97133d28ad  vmovaps xmm13, [rsp+0xD0]
00007e97133d28b6  vmovaps xmm15, [rsp+0xE0]
00007e97133d28bf  add rsp, 0xF0
00007e97133d28c6  pop r11
00007e97133d28c8  pop r10
00007e97133d28ca  pop r9
00007e97133d28cc  pop r8
00007e97133d28ce  pop rsi
00007e97133d28cf  pop rdi
00007e97133d28d0  pop rdx
00007e97133d28d1  pop rcx
00007e97133d28d2  pop rax
00007e97133d28d3  add rsp, 0x08
00007e97133d28d7  jmp 0x00007E97133CFD72
00007e97133d28dc  sub rsp, 0x08
00007e97133d28e0  push rax
00007e97133d28e1  push rcx
00007e97133d28e2  push rdx
00007e97133d28e3  push rdi
00007e97133d28e4  push rsi
00007e97133d28e5  push r8
00007e97133d28e7  push r9
00007e97133d28e9  push r10
00007e97133d28eb  push r11
00007e97133d28ed  sub rsp, 0xF0
00007e97133d28f4  vmovaps [rsp], xmm0
00007e97133d28f9  vmovaps [rsp+0x10], xmm1
00007e97133d28ff  vmovaps [rsp+0x20], xmm2
00007e97133d2905  vmovaps [rsp+0x30], xmm3
00007e97133d290b  vmovaps [rsp+0x40], xmm4
00007e97133d2911  vmovaps [rsp+0x50], xmm5
00007e97133d2917  vmovaps [rsp+0x60], xmm7
00007e97133d291d  vmovaps [rsp+0x70], xmm8
00007e97133d2923  vmovaps [rsp+0x80], xmm9
00007e97133d292c  vmovaps [rsp+0x90], xmm10
00007e97133d2935  vmovaps [rsp+0xA0], xmm11
00007e97133d293e  vmovaps [rsp+0xB0], xmm12
00007e97133d2947  vmovaps [rsp+0xC0], xmm13
00007e97133d2950  vmovaps [rsp+0xD0], xmm14
00007e97133d2959  vmovaps [rsp+0xE0], xmm15
00007e97133d2962  sub rsp, 0x30
00007e97133d2966  movaps [rsp], xmm6
00007e97133d296a  movaps [rsp+0x10], xmm5
00007e97133d296f  movaps [rsp+0x20], xmm1
00007e97133d2974  lea rdi, [rsp]
00007e97133d2978  mov esi, 0x00
00007e97133d297d  mov rax, 0x58D8AED5F530
00007e97133d2987  call rax
00007e97133d2989  movaps xmm6, [rsp]
00007e97133d298d  add rsp, 0x30
00007e97133d2991  vmovaps xmm0, [rsp]
00007e97133d2996  vmovaps xmm1, [rsp+0x10]
00007e97133d299c  vmovaps xmm2, [rsp+0x20]
00007e97133d29a2  vmovaps xmm3, [rsp+0x30]
00007e97133d29a8  vmovaps xmm4, [rsp+0x40]
00007e97133d29ae  vmovaps xmm5, [rsp+0x50]
00007e97133d29b4  vmovaps xmm7, [rsp+0x60]
00007e97133d29ba  vmovaps xmm8, [rsp+0x70]
00007e97133d29c0  vmovaps xmm9, [rsp+0x80]
00007e97133d29c9  vmovaps xmm10, [rsp+0x90]
00007e97133d29d2  vmovaps xmm11, [rsp+0xA0]
00007e97133d29db  vmovaps xmm12, [rsp+0xB0]
00007e97133d29e4  vmovaps xmm13, [rsp+0xC0]
00007e97133d29ed  vmovaps xmm14, [rsp+0xD0]
00007e97133d29f6  vmovaps xmm15, [rsp+0xE0]
00007e97133d29ff  add rsp, 0xF0
00007e97133d2a06  pop r11
00007e97133d2a08  pop r10
00007e97133d2a0a  pop r9
00007e97133d2a0c  pop r8
00007e97133d2a0e  pop rsi
00007e97133d2a0f  pop rdi
00007e97133d2a10  pop rdx
00007e97133d2a11  pop rcx
00007e97133d2a12  pop rax
00007e97133d2a13  add rsp, 0x08
00007e97133d2a17  jmp 0x00007E97133CFD98
00007e97133d2a1c  sub rsp, 0x08
00007e97133d2a20  push rax
00007e97133d2a21  push rcx
00007e97133d2a22  push rdx
00007e97133d2a23  push rdi
00007e97133d2a24  push rsi
00007e97133d2a25  push r8
00007e97133d2a27  push r9
00007e97133d2a29  push r10
00007e97133d2a2b  push r11
00007e97133d2a2d  sub rsp, 0xF0
00007e97133d2a34  vmovaps [rsp], xmm0
00007e97133d2a39  vmovaps [rsp+0x10], xmm2
00007e97133d2a3f  vmovaps [rsp+0x20], xmm3
00007e97133d2a45  vmovaps [rsp+0x30], xmm4
00007e97133d2a4b  vmovaps [rsp+0x40], xmm5
00007e97133d2a51  vmovaps [rsp+0x50], xmm6
00007e97133d2a57  vmovaps [rsp+0x60], xmm7
00007e97133d2a5d  vmovaps [rsp+0x70], xmm8
00007e97133d2a63  vmovaps [rsp+0x80], xmm9
00007e97133d2a6c  vmovaps [rsp+0x90], xmm10
00007e97133d2a75  vmovaps [rsp+0xA0], xmm11
00007e97133d2a7e  vmovaps [rsp+0xB0], xmm12
00007e97133d2a87  vmovaps [rsp+0xC0], xmm13
00007e97133d2a90  vmovaps [rsp+0xD0], xmm14
00007e97133d2a99  vmovaps [rsp+0xE0], xmm15
00007e97133d2aa2  sub rsp, 0x30
00007e97133d2aa6  movaps [rsp], xmm1
00007e97133d2aaa  movaps [rsp+0x10], xmm5
00007e97133d2aaf  movaps [rsp+0x20], xmm13
00007e97133d2ab5  lea rdi, [rsp]
00007e97133d2ab9  mov esi, 0x00
00007e97133d2abe  mov rax, 0x58D8AED5F530
00007e97133d2ac8  call rax
00007e97133d2aca  movaps xmm1, [rsp]
00007e97133d2ace  add rsp, 0x30
00007e97133d2ad2  vmovaps xmm0, [rsp]
00007e97133d2ad7  vmovaps xmm2, [rsp+0x10]
00007e97133d2add  vmovaps xmm3, [rsp+0x20]
00007e97133d2ae3  vmovaps xmm4, [rsp+0x30]
00007e97133d2ae9  vmovaps xmm5, [rsp+0x40]
00007e97133d2aef  vmovaps xmm6, [rsp+0x50]
00007e97133d2af5  vmovaps xmm7, [rsp+0x60]
00007e97133d2afb  vmovaps xmm8, [rsp+0x70]
00007e97133d2b01  vmovaps xmm9, [rsp+0x80]
00007e97133d2b0a  vmovaps xmm10, [rsp+0x90]
00007e97133d2b13  vmovaps xmm11, [rsp+0xA0]
00007e97133d2b1c  vmovaps xmm12, [rsp+0xB0]
00007e97133d2b25  vmovaps xmm13, [rsp+0xC0]
00007e97133d2b2e  vmovaps xmm14, [rsp+0xD0]
00007e97133d2b37  vmovaps xmm15, [rsp+0xE0]
00007e97133d2b40  add rsp, 0xF0
00007e97133d2b47  pop r11
00007e97133d2b49  pop r10
00007e97133d2b4b  pop r9
00007e97133d2b4d  pop r8
00007e97133d2b4f  pop rsi
00007e97133d2b50  pop rdi
00007e97133d2b51  pop rdx
00007e97133d2b52  pop rcx
00007e97133d2b53  pop rax
00007e97133d2b54  add rsp, 0x08
00007e97133d2b58  jmp 0x00007E97133CFDB6
00007e97133d2b5d  sub rsp, 0x08
00007e97133d2b61  push rax
00007e97133d2b62  push rcx
00007e97133d2b63  push rdx
00007e97133d2b64  push rdi
00007e97133d2b65  push rsi
00007e97133d2b66  push r8
00007e97133d2b68  push r9
00007e97133d2b6a  push r10
00007e97133d2b6c  push r11
00007e97133d2b6e  sub rsp, 0xF0
00007e97133d2b75  vmovaps [rsp], xmm0
00007e97133d2b7a  vmovaps [rsp+0x10], xmm1
00007e97133d2b80  vmovaps [rsp+0x20], xmm2
00007e97133d2b86  vmovaps [rsp+0x30], xmm3
00007e97133d2b8c  vmovaps [rsp+0x40], xmm4
00007e97133d2b92  vmovaps [rsp+0x50], xmm6
00007e97133d2b98  vmovaps [rsp+0x60], xmm7
00007e97133d2b9e  vmovaps [rsp+0x70], xmm8
00007e97133d2ba4  vmovaps [rsp+0x80], xmm9
00007e97133d2bad  vmovaps [rsp+0x90], xmm10
00007e97133d2bb6  vmovaps [rsp+0xA0], xmm11
00007e97133d2bbf  vmovaps [rsp+0xB0], xmm12
00007e97133d2bc8  vmovaps [rsp+0xC0], xmm13
00007e97133d2bd1  vmovaps [rsp+0xD0], xmm14
00007e97133d2bda  vmovaps [rsp+0xE0], xmm15
00007e97133d2be3  sub rsp, 0x30
00007e97133d2be7  movaps [rsp], xmm5
00007e97133d2beb  movaps [rsp+0x10], xmm2
00007e97133d2bf0  movaps [rsp+0x20], xmm13
00007e97133d2bf6  lea rdi, [rsp]
00007e97133d2bfa  mov esi, 0x00
00007e97133d2bff  mov rax, 0x58D8AED5F530
00007e97133d2c09  call rax
00007e97133d2c0b  movaps xmm5, [rsp]
00007e97133d2c0f  add rsp, 0x30
00007e97133d2c13  vmovaps xmm0, [rsp]
00007e97133d2c18  vmovaps xmm1, [rsp+0x10]
00007e97133d2c1e  vmovaps xmm2, [rsp+0x20]
00007e97133d2c24  vmovaps xmm3, [rsp+0x30]
00007e97133d2c2a  vmovaps xmm4, [rsp+0x40]
00007e97133d2c30  vmovaps xmm6, [rsp+0x50]
00007e97133d2c36  vmovaps xmm7, [rsp+0x60]
00007e97133d2c3c  vmovaps xmm8, [rsp+0x70]
00007e97133d2c42  vmovaps xmm9, [rsp+0x80]
00007e97133d2c4b  vmovaps xmm10, [rsp+0x90]
00007e97133d2c54  vmovaps xmm11, [rsp+0xA0]
00007e97133d2c5d  vmovaps xmm12, [rsp+0xB0]
00007e97133d2c66  vmovaps xmm13, [rsp+0xC0]
00007e97133d2c6f  vmovaps xmm14, [rsp+0xD0]
00007e97133d2c78  vmovaps xmm15, [rsp+0xE0]
00007e97133d2c81  add rsp, 0xF0
00007e97133d2c88  pop r11
00007e97133d2c8a  pop r10
00007e97133d2c8c  pop r9
00007e97133d2c8e  pop r8
00007e97133d2c90  pop rsi
00007e97133d2c91  pop rdi
00007e97133d2c92  pop rdx
00007e97133d2c93  pop rcx
00007e97133d2c94  pop rax
00007e97133d2c95  add rsp, 0x08
00007e97133d2c99  jmp 0x00007E97133CFDEC
00007e97133d2c9e  sub rsp, 0x08
00007e97133d2ca2  push rax
00007e97133d2ca3  push rcx
00007e97133d2ca4  push rdx
00007e97133d2ca5  push rdi
00007e97133d2ca6  push rsi
00007e97133d2ca7  push r8
00007e97133d2ca9  push r9
00007e97133d2cab  push r10
00007e97133d2cad  push r11
00007e97133d2caf  sub rsp, 0xF0
00007e97133d2cb6  vmovaps [rsp], xmm0
00007e97133d2cbb  vmovaps [rsp+0x10], xmm1
00007e97133d2cc1  vmovaps [rsp+0x20], xmm2
00007e97133d2cc7  vmovaps [rsp+0x30], xmm3
00007e97133d2ccd  vmovaps [rsp+0x40], xmm4
00007e97133d2cd3  vmovaps [rsp+0x50], xmm5
00007e97133d2cd9  vmovaps [rsp+0x60], xmm6
00007e97133d2cdf  vmovaps [rsp+0x70], xmm7
00007e97133d2ce5  vmovaps [rsp+0x80], xmm8
00007e97133d2cee  vmovaps [rsp+0x90], xmm9
00007e97133d2cf7  vmovaps [rsp+0xA0], xmm10
00007e97133d2d00  vmovaps [rsp+0xB0], xmm11
00007e97133d2d09  vmovaps [rsp+0xC0], xmm12
00007e97133d2d12  vmovaps [rsp+0xD0], xmm14
00007e97133d2d1b  vmovaps [rsp+0xE0], xmm15
00007e97133d2d24  sub rsp, 0x30
00007e97133d2d28  movaps [rsp], xmm13
00007e97133d2d2d  movaps [rsp+0x10], xmm10
00007e97133d2d33  movaps [rsp+0x20], xmm1
00007e97133d2d38  lea rdi, [rsp]
00007e97133d2d3c  mov esi, 0x00
00007e97133d2d41  mov rax, 0x58D8AED5F530
00007e97133d2d4b  call rax
00007e97133d2d4d  movaps xmm13, [rsp]
00007e97133d2d52  add rsp, 0x30
00007e97133d2d56  vmovaps xmm0, [rsp]
00007e97133d2d5b  vmovaps xmm1, [rsp+0x10]
00007e97133d2d61  vmovaps xmm2, [rsp+0x20]
00007e97133d2d67  vmovaps xmm3, [rsp+0x30]
00007e97133d2d6d  vmovaps xmm4, [rsp+0x40]
00007e97133d2d73  vmovaps xmm5, [rsp+0x50]
00007e97133d2d79  vmovaps xmm6, [rsp+0x60]
00007e97133d2d7f  vmovaps xmm7, [rsp+0x70]
00007e97133d2d85  vmovaps xmm8, [rsp+0x80]
00007e97133d2d8e  vmovaps xmm9, [rsp+0x90]
00007e97133d2d97  vmovaps xmm10, [rsp+0xA0]
00007e97133d2da0  vmovaps xmm11, [rsp+0xB0]
00007e97133d2da9  vmovaps xmm12, [rsp+0xC0]
00007e97133d2db2  vmovaps xmm14, [rsp+0xD0]
00007e97133d2dbb  vmovaps xmm15, [rsp+0xE0]
00007e97133d2dc4  add rsp, 0xF0
00007e97133d2dcb  pop r11
00007e97133d2dcd  pop r10
00007e97133d2dcf  pop r9
00007e97133d2dd1  pop r8
00007e97133d2dd3  pop rsi
00007e97133d2dd4  pop rdi
00007e97133d2dd5  pop rdx
00007e97133d2dd6  pop rcx
00007e97133d2dd7  pop rax
00007e97133d2dd8  add rsp, 0x08
00007e97133d2ddc  jmp 0x00007E97133CFE15
00007e97133d2de1  sub rsp, 0x08
00007e97133d2de5  push rax
00007e97133d2de6  push rcx
00007e97133d2de7  push rdx
00007e97133d2de8  push rdi
00007e97133d2de9  push rsi
00007e97133d2dea  push r8
00007e97133d2dec  push r9
00007e97133d2dee  push r10
00007e97133d2df0  push r11
00007e97133d2df2  sub rsp, 0xF0
00007e97133d2df9  vmovaps [rsp], xmm0
00007e97133d2dfe  vmovaps [rsp+0x10], xmm2
00007e97133d2e04  vmovaps [rsp+0x20], xmm3
00007e97133d2e0a  vmovaps [rsp+0x30], xmm4
00007e97133d2e10  vmovaps [rsp+0x40], xmm5
00007e97133d2e16  vmovaps [rsp+0x50], xmm6
00007e97133d2e1c  vmovaps [rsp+0x60], xmm7
00007e97133d2e22  vmovaps [rsp+0x70], xmm8
00007e97133d2e28  vmovaps [rsp+0x80], xmm9
00007e97133d2e31  vmovaps [rsp+0x90], xmm10
00007e97133d2e3a  vmovaps [rsp+0xA0], xmm11
00007e97133d2e43  vmovaps [rsp+0xB0], xmm12
00007e97133d2e4c  vmovaps [rsp+0xC0], xmm13
00007e97133d2e55  vmovaps [rsp+0xD0], xmm14
00007e97133d2e5e  vmovaps [rsp+0xE0], xmm15
00007e97133d2e67  sub rsp, 0x30
00007e97133d2e6b  movaps [rsp], xmm1
00007e97133d2e6f  movaps [rsp+0x10], xmm15
00007e97133d2e75  movaps [rsp+0x20], xmm10
00007e97133d2e7b  lea rdi, [rsp]
00007e97133d2e7f  mov esi, 0x00
00007e97133d2e84  mov rax, 0x58D8AED5F530
00007e97133d2e8e  call rax
00007e97133d2e90  movaps xmm1, [rsp]
00007e97133d2e94  add rsp, 0x30
00007e97133d2e98  vmovaps xmm0, [rsp]
00007e97133d2e9d  vmovaps xmm2, [rsp+0x10]
00007e97133d2ea3  vmovaps xmm3, [rsp+0x20]
00007e97133d2ea9  vmovaps xmm4, [rsp+0x30]
00007e97133d2eaf  vmovaps xmm5, [rsp+0x40]
00007e97133d2eb5  vmovaps xmm6, [rsp+0x50]
00007e97133d2ebb  vmovaps xmm7, [rsp+0x60]
00007e97133d2ec1  vmovaps xmm8, [rsp+0x70]
00007e97133d2ec7  vmovaps xmm9, [rsp+0x80]
00007e97133d2ed0  vmovaps xmm10, [rsp+0x90]
00007e97133d2ed9  vmovaps xmm11, [rsp+0xA0]
00007e97133d2ee2  vmovaps xmm12, [rsp+0xB0]
00007e97133d2eeb  vmovaps xmm13, [rsp+0xC0]
00007e97133d2ef4  vmovaps xmm14, [rsp+0xD0]
00007e97133d2efd  vmovaps xmm15, [rsp+0xE0]
00007e97133d2f06  add rsp, 0xF0
00007e97133d2f0d  pop r11
00007e97133d2f0f  pop r10
00007e97133d2f11  pop r9
00007e97133d2f13  pop r8
00007e97133d2f15  pop rsi
00007e97133d2f16  pop rdi
00007e97133d2f17  pop rdx
00007e97133d2f18  pop rcx
00007e97133d2f19  pop rax
00007e97133d2f1a  add rsp, 0x08
00007e97133d2f1e  jmp 0x00007E97133CFE34
00007e97133d2f23  sub rsp, 0x08
00007e97133d2f27  push rax
00007e97133d2f28  push rcx
00007e97133d2f29  push rdx
00007e97133d2f2a  push rdi
00007e97133d2f2b  push rsi
00007e97133d2f2c  push r8
00007e97133d2f2e  push r9
00007e97133d2f30  push r10
00007e97133d2f32  push r11
00007e97133d2f34  sub rsp, 0xF0
00007e97133d2f3b  vmovaps [rsp], xmm0
00007e97133d2f40  vmovaps [rsp+0x10], xmm1
00007e97133d2f46  vmovaps [rsp+0x20], xmm2
00007e97133d2f4c  vmovaps [rsp+0x30], xmm3
00007e97133d2f52  vmovaps [rsp+0x40], xmm4
00007e97133d2f58  vmovaps [rsp+0x50], xmm5
00007e97133d2f5e  vmovaps [rsp+0x60], xmm6
00007e97133d2f64  vmovaps [rsp+0x70], xmm7
00007e97133d2f6a  vmovaps [rsp+0x80], xmm8
00007e97133d2f73  vmovaps [rsp+0x90], xmm9
00007e97133d2f7c  vmovaps [rsp+0xA0], xmm10
00007e97133d2f85  vmovaps [rsp+0xB0], xmm11
00007e97133d2f8e  vmovaps [rsp+0xC0], xmm12
00007e97133d2f97  vmovaps [rsp+0xD0], xmm13
00007e97133d2fa0  vmovaps [rsp+0xE0], xmm14
00007e97133d2fa9  sub rsp, 0x30
00007e97133d2fad  movaps [rsp], xmm15
00007e97133d2fb2  movaps [rsp+0x10], xmm10
00007e97133d2fb8  movaps [rsp+0x20], xmm11
00007e97133d2fbe  lea rdi, [rsp]
00007e97133d2fc2  mov esi, 0x00
00007e97133d2fc7  mov rax, 0x58D8AED5F530
00007e97133d2fd1  call rax
00007e97133d2fd3  movaps xmm15, [rsp]
00007e97133d2fd8  add rsp, 0x30
00007e97133d2fdc  vmovaps xmm0, [rsp]
00007e97133d2fe1  vmovaps xmm1, [rsp+0x10]
00007e97133d2fe7  vmovaps xmm2, [rsp+0x20]
00007e97133d2fed  vmovaps xmm3, [rsp+0x30]
00007e97133d2ff3  vmovaps xmm4, [rsp+0x40]
00007e97133d2ff9  vmovaps xmm5, [rsp+0x50]
00007e97133d2fff  vmovaps xmm6, [rsp+0x60]
00007e97133d3005  vmovaps xmm7, [rsp+0x70]
00007e97133d300b  vmovaps xmm8, [rsp+0x80]
00007e97133d3014  vmovaps xmm9, [rsp+0x90]
00007e97133d301d  vmovaps xmm10, [rsp+0xA0]
00007e97133d3026  vmovaps xmm11, [rsp+0xB0]
00007e97133d302f  vmovaps xmm12, [rsp+0xC0]
00007e97133d3038  vmovaps xmm13, [rsp+0xD0]
00007e97133d3041  vmovaps xmm14, [rsp+0xE0]
00007e97133d304a  add rsp, 0xF0
00007e97133d3051  pop r11
00007e97133d3053  pop r10
00007e97133d3055  pop r9
00007e97133d3057  pop r8
00007e97133d3059  pop rsi
00007e97133d305a  pop rdi
00007e97133d305b  pop rdx
00007e97133d305c  pop rcx
00007e97133d305d  pop rax
00007e97133d305e  add rsp, 0x08
00007e97133d3062  jmp 0x00007E97133CFE57
00007e97133d3067  sub rsp, 0x08
00007e97133d306b  push rax
00007e97133d306c  push rcx
00007e97133d306d  push rdx
00007e97133d306e  push rdi
00007e97133d306f  push rsi
00007e97133d3070  push r8
00007e97133d3072  push r9
00007e97133d3074  push r10
00007e97133d3076  push r11
00007e97133d3078  sub rsp, 0xF0
00007e97133d307f  vmovaps [rsp], xmm0
00007e97133d3084  vmovaps [rsp+0x10], xmm1
00007e97133d308a  vmovaps [rsp+0x20], xmm2
00007e97133d3090  vmovaps [rsp+0x30], xmm3
00007e97133d3096  vmovaps [rsp+0x40], xmm4
00007e97133d309c  vmovaps [rsp+0x50], xmm5
00007e97133d30a2  vmovaps [rsp+0x60], xmm6
00007e97133d30a8  vmovaps [rsp+0x70], xmm7
00007e97133d30ae  vmovaps [rsp+0x80], xmm8
00007e97133d30b7  vmovaps [rsp+0x90], xmm9
00007e97133d30c0  vmovaps [rsp+0xA0], xmm11
00007e97133d30c9  vmovaps [rsp+0xB0], xmm12
00007e97133d30d2  vmovaps [rsp+0xC0], xmm13
00007e97133d30db  vmovaps [rsp+0xD0], xmm14
00007e97133d30e4  vmovaps [rsp+0xE0], xmm15
00007e97133d30ed  sub rsp, 0x30
00007e97133d30f1  movaps [rsp], xmm10
00007e97133d30f6  movaps [rsp+0x10], xmm12
00007e97133d30fc  movaps [rsp+0x20], xmm11
00007e97133d3102  lea rdi, [rsp]
00007e97133d3106  mov esi, 0x00
00007e97133d310b  mov rax, 0x58D8AED5F530
00007e97133d3115  call rax
00007e97133d3117  movaps xmm10, [rsp]
00007e97133d311c  add rsp, 0x30
00007e97133d3120  vmovaps xmm0, [rsp]
00007e97133d3125  vmovaps xmm1, [rsp+0x10]
00007e97133d312b  vmovaps xmm2, [rsp+0x20]
00007e97133d3131  vmovaps xmm3, [rsp+0x30]
00007e97133d3137  vmovaps xmm4, [rsp+0x40]
00007e97133d313d  vmovaps xmm5, [rsp+0x50]
00007e97133d3143  vmovaps xmm6, [rsp+0x60]
00007e97133d3149  vmovaps xmm7, [rsp+0x70]
00007e97133d314f  vmovaps xmm8, [rsp+0x80]
00007e97133d3158  vmovaps xmm9, [rsp+0x90]
00007e97133d3161  vmovaps xmm11, [rsp+0xA0]
00007e97133d316a  vmovaps xmm12, [rsp+0xB0]
00007e97133d3173  vmovaps xmm13, [rsp+0xC0]
00007e97133d317c  vmovaps xmm14, [rsp+0xD0]
00007e97133d3185  vmovaps xmm15, [rsp+0xE0]
00007e97133d318e  add rsp, 0xF0
00007e97133d3195  pop r11
00007e97133d3197  pop r10
00007e97133d3199  pop r9
00007e97133d319b  pop r8
00007e97133d319d  pop rsi
00007e97133d319e  pop rdi
00007e97133d319f  pop rdx
00007e97133d31a0  pop rcx
00007e97133d31a1  pop rax
00007e97133d31a2  add rsp, 0x08
00007e97133d31a6  jmp 0x00007E97133CFE80
00007e97133d31ab  sub rsp, 0x08
00007e97133d31af  push rax
00007e97133d31b0  push rcx
00007e97133d31b1  push rdx
00007e97133d31b2  push rdi
00007e97133d31b3  push rsi
00007e97133d31b4  push r8
00007e97133d31b6  push r9
00007e97133d31b8  push r10
00007e97133d31ba  push r11
00007e97133d31bc  sub rsp, 0xF0
00007e97133d31c3  vmovaps [rsp], xmm0
00007e97133d31c8  vmovaps [rsp+0x10], xmm1
00007e97133d31ce  vmovaps [rsp+0x20], xmm2
00007e97133d31d4  vmovaps [rsp+0x30], xmm3
00007e97133d31da  vmovaps [rsp+0x40], xmm4
00007e97133d31e0  vmovaps [rsp+0x50], xmm5
00007e97133d31e6  vmovaps [rsp+0x60], xmm6
00007e97133d31ec  vmovaps [rsp+0x70], xmm7
00007e97133d31f2  vmovaps [rsp+0x80], xmm8
00007e97133d31fb  vmovaps [rsp+0x90], xmm9
00007e97133d3204  vmovaps [rsp+0xA0], xmm10
00007e97133d320d  vmovaps [rsp+0xB0], xmm12
00007e97133d3216  vmovaps [rsp+0xC0], xmm13
00007e97133d321f  vmovaps [rsp+0xD0], xmm14
00007e97133d3228  vmovaps [rsp+0xE0], xmm15
00007e97133d3231  sub rsp, 0x30
00007e97133d3235  movaps [rsp], xmm11
00007e97133d323a  movaps [rsp+0x10], xmm2
00007e97133d323f  movaps [rsp+0x20], xmm12
00007e97133d3245  lea rdi, [rsp]
00007e97133d3249  mov esi, 0x00
00007e97133d324e  mov rax, 0x58D8AED5F530
00007e97133d3258  call rax
00007e97133d325a  movaps xmm11, [rsp]
00007e97133d325f  add rsp, 0x30
00007e97133d3263  vmovaps xmm0, [rsp]
00007e97133d3268  vmovaps xmm1, [rsp+0x10]
00007e97133d326e  vmovaps xmm2, [rsp+0x20]
00007e97133d3274  vmovaps xmm3, [rsp+0x30]
00007e97133d327a  vmovaps xmm4, [rsp+0x40]
00007e97133d3280  vmovaps xmm5, [rsp+0x50]
00007e97133d3286  vmovaps xmm6, [rsp+0x60]
00007e97133d328c  vmovaps xmm7, [rsp+0x70]
00007e97133d3292  vmovaps xmm8, [rsp+0x80]
00007e97133d329b  vmovaps xmm9, [rsp+0x90]
00007e97133d32a4  vmovaps xmm10, [rsp+0xA0]
00007e97133d32ad  vmovaps xmm12, [rsp+0xB0]
00007e97133d32b6  vmovaps xmm13, [rsp+0xC0]
00007e97133d32bf  vmovaps xmm14, [rsp+0xD0]
00007e97133d32c8  vmovaps xmm15, [rsp+0xE0]
00007e97133d32d1  add rsp, 0xF0
00007e97133d32d8  pop r11
00007e97133d32da  pop r10
00007e97133d32dc  pop r9
00007e97133d32de  pop r8
00007e97133d32e0  pop rsi
00007e97133d32e1  pop rdi
00007e97133d32e2  pop rdx
00007e97133d32e3  pop rcx
00007e97133d32e4  pop rax
00007e97133d32e5  add rsp, 0x08
00007e97133d32e9  jmp 0x00007E97133CFEB8
00007e97133d32ee  sub rsp, 0x08
00007e97133d32f2  push rax
00007e97133d32f3  push rcx
00007e97133d32f4  push rdx
00007e97133d32f5  push rdi
00007e97133d32f6  push rsi
00007e97133d32f7  push r8
00007e97133d32f9  push r9
00007e97133d32fb  push r10
00007e97133d32fd  push r11
00007e97133d32ff  sub rsp, 0xF0
00007e97133d3306  vmovaps [rsp], xmm0
00007e97133d330b  vmovaps [rsp+0x10], xmm2
00007e97133d3311  vmovaps [rsp+0x20], xmm3
00007e97133d3317  vmovaps [rsp+0x30], xmm4
00007e97133d331d  vmovaps [rsp+0x40], xmm5
00007e97133d3323  vmovaps [rsp+0x50], xmm6
00007e97133d3329  vmovaps [rsp+0x60], xmm7
00007e97133d332f  vmovaps [rsp+0x70], xmm8
00007e97133d3335  vmovaps [rsp+0x80], xmm9
00007e97133d333e  vmovaps [rsp+0x90], xmm10
00007e97133d3347  vmovaps [rsp+0xA0], xmm11
00007e97133d3350  vmovaps [rsp+0xB0], xmm12
00007e97133d3359  vmovaps [rsp+0xC0], xmm13
00007e97133d3362  vmovaps [rsp+0xD0], xmm14
00007e97133d336b  vmovaps [rsp+0xE0], xmm15
00007e97133d3374  sub rsp, 0x30
00007e97133d3378  movaps [rsp], xmm1
00007e97133d337c  movaps [rsp+0x10], xmm14
00007e97133d3382  movaps [rsp+0x20], xmm6
00007e97133d3387  lea rdi, [rsp]
00007e97133d338b  mov esi, 0x00
00007e97133d3390  mov rax, 0x58D8AED5F530
00007e97133d339a  call rax
00007e97133d339c  movaps xmm1, [rsp]
00007e97133d33a0  add rsp, 0x30
00007e97133d33a4  vmovaps xmm0, [rsp]
00007e97133d33a9  vmovaps xmm2, [rsp+0x10]
00007e97133d33af  vmovaps xmm3, [rsp+0x20]
00007e97133d33b5  vmovaps xmm4, [rsp+0x30]
00007e97133d33bb  vmovaps xmm5, [rsp+0x40]
00007e97133d33c1  vmovaps xmm6, [rsp+0x50]
00007e97133d33c7  vmovaps xmm7, [rsp+0x60]
00007e97133d33cd  vmovaps xmm8, [rsp+0x70]
00007e97133d33d3  vmovaps xmm9, [rsp+0x80]
00007e97133d33dc  vmovaps xmm10, [rsp+0x90]
00007e97133d33e5  vmovaps xmm11, [rsp+0xA0]
00007e97133d33ee  vmovaps xmm12, [rsp+0xB0]
00007e97133d33f7  vmovaps xmm13, [rsp+0xC0]
00007e97133d3400  vmovaps xmm14, [rsp+0xD0]
00007e97133d3409  vmovaps xmm15, [rsp+0xE0]
00007e97133d3412  add rsp, 0xF0
00007e97133d3419  pop r11
00007e97133d341b  pop r10
00007e97133d341d  pop r9
00007e97133d341f  pop r8
00007e97133d3421  pop rsi
00007e97133d3422  pop rdi
00007e97133d3423  pop rdx
00007e97133d3424  pop rcx
00007e97133d3425  pop rax
00007e97133d3426  add rsp, 0x08
00007e97133d342a  jmp 0x00007E97133CFED1
00007e97133d342f  sub rsp, 0x08
00007e97133d3433  push rax
00007e97133d3434  push rcx
00007e97133d3435  push rdx
00007e97133d3436  push rdi
00007e97133d3437  push rsi
00007e97133d3438  push r8
00007e97133d343a  push r9
00007e97133d343c  push r10
00007e97133d343e  push r11
00007e97133d3440  sub rsp, 0xF0
00007e97133d3447  vmovaps [rsp], xmm0
00007e97133d344c  vmovaps [rsp+0x10], xmm1
00007e97133d3452  vmovaps [rsp+0x20], xmm2
00007e97133d3458  vmovaps [rsp+0x30], xmm3
00007e97133d345e  vmovaps [rsp+0x40], xmm4
00007e97133d3464  vmovaps [rsp+0x50], xmm5
00007e97133d346a  vmovaps [rsp+0x60], xmm6
00007e97133d3470  vmovaps [rsp+0x70], xmm7
00007e97133d3476  vmovaps [rsp+0x80], xmm8
00007e97133d347f  vmovaps [rsp+0x90], xmm9
00007e97133d3488  vmovaps [rsp+0xA0], xmm10
00007e97133d3491  vmovaps [rsp+0xB0], xmm11
00007e97133d349a  vmovaps [rsp+0xC0], xmm12
00007e97133d34a3  vmovaps [rsp+0xD0], xmm13
00007e97133d34ac  vmovaps [rsp+0xE0], xmm15
00007e97133d34b5  sub rsp, 0x30
00007e97133d34b9  movaps [rsp], xmm14
00007e97133d34be  movaps [rsp+0x10], xmm12
00007e97133d34c4  movaps [rsp+0x20], xmm5
00007e97133d34c9  lea rdi, [rsp]
00007e97133d34cd  mov esi, 0x00
00007e97133d34d2  mov rax, 0x58D8AED5F530
00007e97133d34dc  call rax
00007e97133d34de  movaps xmm14, [rsp]
00007e97133d34e3  add rsp, 0x30
00007e97133d34e7  vmovaps xmm0, [rsp]
00007e97133d34ec  vmovaps xmm1, [rsp+0x10]
00007e97133d34f2  vmovaps xmm2, [rsp+0x20]
00007e97133d34f8  vmovaps xmm3, [rsp+0x30]
00007e97133d34fe  vmovaps xmm4, [rsp+0x40]
00007e97133d3504  vmovaps xmm5, [rsp+0x50]
00007e97133d350a  vmovaps xmm6, [rsp+0x60]
00007e97133d3510  vmovaps xmm7, [rsp+0x70]
00007e97133d3516  vmovaps xmm8, [rsp+0x80]
00007e97133d351f  vmovaps xmm9, [rsp+0x90]
00007e97133d3528  vmovaps xmm10, [rsp+0xA0]
00007e97133d3531  vmovaps xmm11, [rsp+0xB0]
00007e97133d353a  vmovaps xmm12, [rsp+0xC0]
00007e97133d3543  vmovaps xmm13, [rsp+0xD0]
00007e97133d354c  vmovaps xmm15, [rsp+0xE0]
00007e97133d3555  add rsp, 0xF0
00007e97133d355c  pop r11
00007e97133d355e  pop r10
00007e97133d3560  pop r9
00007e97133d3562  pop r8
00007e97133d3564  pop rsi
00007e97133d3565  pop rdi
00007e97133d3566  pop rdx
00007e97133d3567  pop rcx
00007e97133d3568  pop rax
00007e97133d3569  add rsp, 0x08
00007e97133d356d  jmp 0x00007E97133CFEF1
00007e97133d3572  sub rsp, 0x08
00007e97133d3576  push rax
00007e97133d3577  push rcx
00007e97133d3578  push rdx
00007e97133d3579  push rdi
00007e97133d357a  push rsi
00007e97133d357b  push r8
00007e97133d357d  push r9
00007e97133d357f  push r10
00007e97133d3581  push r11
00007e97133d3583  sub rsp, 0xF0
00007e97133d358a  vmovaps [rsp], xmm0
00007e97133d358f  vmovaps [rsp+0x10], xmm1
00007e97133d3595  vmovaps [rsp+0x20], xmm2
00007e97133d359b  vmovaps [rsp+0x30], xmm3
00007e97133d35a1  vmovaps [rsp+0x40], xmm4
00007e97133d35a7  vmovaps [rsp+0x50], xmm5
00007e97133d35ad  vmovaps [rsp+0x60], xmm7
00007e97133d35b3  vmovaps [rsp+0x70], xmm8
00007e97133d35b9  vmovaps [rsp+0x80], xmm9
00007e97133d35c2  vmovaps [rsp+0x90], xmm10
00007e97133d35cb  vmovaps [rsp+0xA0], xmm11
00007e97133d35d4  vmovaps [rsp+0xB0], xmm12
00007e97133d35dd  vmovaps [rsp+0xC0], xmm13
00007e97133d35e6  vmovaps [rsp+0xD0], xmm14
00007e97133d35ef  vmovaps [rsp+0xE0], xmm15
00007e97133d35f8  sub rsp, 0x30
00007e97133d35fc  movaps [rsp], xmm6
00007e97133d3600  movaps [rsp+0x10], xmm9
00007e97133d3606  movaps [rsp+0x20], xmm12
00007e97133d360c  lea rdi, [rsp]
00007e97133d3610  mov esi, 0x00
00007e97133d3615  mov rax, 0x58D8AED5F530
00007e97133d361f  call rax
00007e97133d3621  movaps xmm6, [rsp]
00007e97133d3625  add rsp, 0x30
00007e97133d3629  vmovaps xmm0, [rsp]
00007e97133d362e  vmovaps xmm1, [rsp+0x10]
00007e97133d3634  vmovaps xmm2, [rsp+0x20]
00007e97133d363a  vmovaps xmm3, [rsp+0x30]
00007e97133d3640  vmovaps xmm4, [rsp+0x40]
00007e97133d3646  vmovaps xmm5, [rsp+0x50]
00007e97133d364c  vmovaps xmm7, [rsp+0x60]
00007e97133d3652  vmovaps xmm8, [rsp+0x70]
00007e97133d3658  vmovaps xmm9, [rsp+0x80]
00007e97133d3661  vmovaps xmm10, [rsp+0x90]
00007e97133d366a  vmovaps xmm11, [rsp+0xA0]
00007e97133d3673  vmovaps xmm12, [rsp+0xB0]
00007e97133d367c  vmovaps xmm13, [rsp+0xC0]
00007e97133d3685  vmovaps xmm14, [rsp+0xD0]
00007e97133d368e  vmovaps xmm15, [rsp+0xE0]
00007e97133d3697  add rsp, 0xF0
00007e97133d369e  pop r11
00007e97133d36a0  pop r10
00007e97133d36a2  pop r9
00007e97133d36a4  pop r8
00007e97133d36a6  pop rsi
00007e97133d36a7  pop rdi
00007e97133d36a8  pop rdx
00007e97133d36a9  pop rcx
00007e97133d36aa  pop rax
00007e97133d36ab  add rsp, 0x08
00007e97133d36af  jmp 0x00007E97133CFF19
00007e97133d36b4  sub rsp, 0x08
00007e97133d36b8  push rax
00007e97133d36b9  push rcx
00007e97133d36ba  push rdx
00007e97133d36bb  push rdi
00007e97133d36bc  push rsi
00007e97133d36bd  push r8
00007e97133d36bf  push r9
00007e97133d36c1  push r10
00007e97133d36c3  push r11
00007e97133d36c5  sub rsp, 0xF0
00007e97133d36cc  vmovaps [rsp], xmm0
00007e97133d36d1  vmovaps [rsp+0x10], xmm1
00007e97133d36d7  vmovaps [rsp+0x20], xmm2
00007e97133d36dd  vmovaps [rsp+0x30], xmm3
00007e97133d36e3  vmovaps [rsp+0x40], xmm4
00007e97133d36e9  vmovaps [rsp+0x50], xmm5
00007e97133d36ef  vmovaps [rsp+0x60], xmm6
00007e97133d36f5  vmovaps [rsp+0x70], xmm7
00007e97133d36fb  vmovaps [rsp+0x80], xmm8
00007e97133d3704  vmovaps [rsp+0x90], xmm9
00007e97133d370d  vmovaps [rsp+0xA0], xmm10
00007e97133d3716  vmovaps [rsp+0xB0], xmm11
00007e97133d371f  vmovaps [rsp+0xC0], xmm13
00007e97133d3728  vmovaps [rsp+0xD0], xmm14
00007e97133d3731  vmovaps [rsp+0xE0], xmm15
00007e97133d373a  sub rsp, 0x30
00007e97133d373e  movaps [rsp], xmm12
00007e97133d3743  movaps [rsp+0x10], xmm15
00007e97133d3749  movaps [rsp+0x20], xmm13
00007e97133d374f  lea rdi, [rsp]
00007e97133d3753  mov esi, 0x00
00007e97133d3758  mov rax, 0x58D8AED5F530
00007e97133d3762  call rax
00007e97133d3764  movaps xmm12, [rsp]
00007e97133d3769  add rsp, 0x30
00007e97133d376d  vmovaps xmm0, [rsp]
00007e97133d3772  vmovaps xmm1, [rsp+0x10]
00007e97133d3778  vmovaps xmm2, [rsp+0x20]
00007e97133d377e  vmovaps xmm3, [rsp+0x30]
00007e97133d3784  vmovaps xmm4, [rsp+0x40]
00007e97133d378a  vmovaps xmm5, [rsp+0x50]
00007e97133d3790  vmovaps xmm6, [rsp+0x60]
00007e97133d3796  vmovaps xmm7, [rsp+0x70]
00007e97133d379c  vmovaps xmm8, [rsp+0x80]
00007e97133d37a5  vmovaps xmm9, [rsp+0x90]
00007e97133d37ae  vmovaps xmm10, [rsp+0xA0]
00007e97133d37b7  vmovaps xmm11, [rsp+0xB0]
00007e97133d37c0  vmovaps xmm13, [rsp+0xC0]
00007e97133d37c9  vmovaps xmm14, [rsp+0xD0]
00007e97133d37d2  vmovaps xmm15, [rsp+0xE0]
00007e97133d37db  add rsp, 0xF0
00007e97133d37e2  pop r11
00007e97133d37e4  pop r10
00007e97133d37e6  pop r9
00007e97133d37e8  pop r8
00007e97133d37ea  pop rsi
00007e97133d37eb  pop rdi
00007e97133d37ec  pop rdx
00007e97133d37ed  pop rcx
00007e97133d37ee  pop rax
00007e97133d37ef  add rsp, 0x08
00007e97133d37f3  jmp 0x00007E97133CFF34
00007e97133d37f8  sub rsp, 0x08
00007e97133d37fc  push rax
00007e97133d37fd  push rcx
00007e97133d37fe  push rdx
00007e97133d37ff  push rdi
00007e97133d3800  push rsi
00007e97133d3801  push r8
00007e97133d3803  push r9
00007e97133d3805  push r10
00007e97133d3807  push r11
00007e97133d3809  sub rsp, 0xF0
00007e97133d3810  vmovaps [rsp], xmm0
00007e97133d3815  vmovaps [rsp+0x10], xmm1
00007e97133d381b  vmovaps [rsp+0x20], xmm2
00007e97133d3821  vmovaps [rsp+0x30], xmm3
00007e97133d3827  vmovaps [rsp+0x40], xmm4
00007e97133d382d  vmovaps [rsp+0x50], xmm5
00007e97133d3833  vmovaps [rsp+0x60], xmm6
00007e97133d3839  vmovaps [rsp+0x70], xmm7
00007e97133d383f  vmovaps [rsp+0x80], xmm8
00007e97133d3848  vmovaps [rsp+0x90], xmm9
00007e97133d3851  vmovaps [rsp+0xA0], xmm10
00007e97133d385a  vmovaps [rsp+0xB0], xmm11
00007e97133d3863  vmovaps [rsp+0xC0], xmm12
00007e97133d386c  vmovaps [rsp+0xD0], xmm13
00007e97133d3875  vmovaps [rsp+0xE0], xmm14
00007e97133d387e  sub rsp, 0x30
00007e97133d3882  movaps [rsp], xmm15
00007e97133d3887  movaps [rsp+0x10], xmm13
00007e97133d388d  movaps [rsp+0x20], xmm10
00007e97133d3893  lea rdi, [rsp]
00007e97133d3897  mov esi, 0x00
00007e97133d389c  mov rax, 0x58D8AED5F530
00007e97133d38a6  call rax
00007e97133d38a8  movaps xmm15, [rsp]
00007e97133d38ad  add rsp, 0x30
00007e97133d38b1  vmovaps xmm0, [rsp]
00007e97133d38b6  vmovaps xmm1, [rsp+0x10]
00007e97133d38bc  vmovaps xmm2, [rsp+0x20]
00007e97133d38c2  vmovaps xmm3, [rsp+0x30]
00007e97133d38c8  vmovaps xmm4, [rsp+0x40]
00007e97133d38ce  vmovaps xmm5, [rsp+0x50]
00007e97133d38d4  vmovaps xmm6, [rsp+0x60]
00007e97133d38da  vmovaps xmm7, [rsp+0x70]
00007e97133d38e0  vmovaps xmm8, [rsp+0x80]
00007e97133d38e9  vmovaps xmm9, [rsp+0x90]
00007e97133d38f2  vmovaps xmm10, [rsp+0xA0]
00007e97133d38fb  vmovaps xmm11, [rsp+0xB0]
00007e97133d3904  vmovaps xmm12, [rsp+0xC0]
00007e97133d390d  vmovaps xmm13, [rsp+0xD0]
00007e97133d3916  vmovaps xmm14, [rsp+0xE0]
00007e97133d391f  add rsp, 0xF0
00007e97133d3926  pop r11
00007e97133d3928  pop r10
00007e97133d392a  pop r9
00007e97133d392c  pop r8
00007e97133d392e  pop rsi
00007e97133d392f  pop rdi
00007e97133d3930  pop rdx
00007e97133d3931  pop rcx
00007e97133d3932  pop rax
00007e97133d3933  add rsp, 0x08
00007e97133d3937  jmp 0x00007E97133CFF55
00007e97133d393c  call 0x00007E971320C260
00007e97133d3941  jmp 0x00007E97133CFFB0
00007e97133d3946  sub rsp, 0x08
00007e97133d394a  push rax
00007e97133d394b  push rcx
00007e97133d394c  push rdx
00007e97133d394d  push rdi
00007e97133d394e  push rsi
00007e97133d394f  push r8
00007e97133d3951  push r9
00007e97133d3953  push r10
00007e97133d3955  push r11
00007e97133d3957  sub rsp, 0xF0
00007e97133d395e  vmovaps [rsp], xmm0
00007e97133d3963  vmovaps [rsp+0x10], xmm1
00007e97133d3969  vmovaps [rsp+0x20], xmm2
00007e97133d396f  vmovaps [rsp+0x30], xmm3
00007e97133d3975  vmovaps [rsp+0x40], xmm4
00007e97133d397b  vmovaps [rsp+0x50], xmm5
00007e97133d3981  vmovaps [rsp+0x60], xmm6
00007e97133d3987  vmovaps [rsp+0x70], xmm7
00007e97133d398d  vmovaps [rsp+0x80], xmm8
00007e97133d3996  vmovaps [rsp+0x90], xmm10
00007e97133d399f  vmovaps [rsp+0xA0], xmm11
00007e97133d39a8  vmovaps [rsp+0xB0], xmm12
00007e97133d39b1  vmovaps [rsp+0xC0], xmm13
00007e97133d39ba  vmovaps [rsp+0xD0], xmm14
00007e97133d39c3  vmovaps [rsp+0xE0], xmm15
00007e97133d39cc  sub rsp, 0x30
00007e97133d39d0  movaps [rsp], xmm9
00007e97133d39d5  movaps [rsp+0x10], xmm8
00007e97133d39db  movaps [rsp+0x20], xmm10
00007e97133d39e1  lea rdi, [rsp]
00007e97133d39e5  mov esi, 0x00
00007e97133d39ea  mov rax, 0x58D8AED5F530
00007e97133d39f4  call rax
00007e97133d39f6  movaps xmm9, [rsp]
00007e97133d39fb  add rsp, 0x30
00007e97133d39ff  vmovaps xmm0, [rsp]
00007e97133d3a04  vmovaps xmm1, [rsp+0x10]
00007e97133d3a0a  vmovaps xmm2, [rsp+0x20]
00007e97133d3a10  vmovaps xmm3, [rsp+0x30]
00007e97133d3a16  vmovaps xmm4, [rsp+0x40]
00007e97133d3a1c  vmovaps xmm5, [rsp+0x50]
00007e97133d3a22  vmovaps xmm6, [rsp+0x60]
00007e97133d3a28  vmovaps xmm7, [rsp+0x70]
00007e97133d3a2e  vmovaps xmm8, [rsp+0x80]
00007e97133d3a37  vmovaps xmm10, [rsp+0x90]
00007e97133d3a40  vmovaps xmm11, [rsp+0xA0]
00007e97133d3a49  vmovaps xmm12, [rsp+0xB0]
00007e97133d3a52  vmovaps xmm13, [rsp+0xC0]
00007e97133d3a5b  vmovaps xmm14, [rsp+0xD0]
00007e97133d3a64  vmovaps xmm15, [rsp+0xE0]
00007e97133d3a6d  add rsp, 0xF0
00007e97133d3a74  pop r11
00007e97133d3a76  pop r10
00007e97133d3a78  pop r9
00007e97133d3a7a  pop r8
00007e97133d3a7c  pop rsi
00007e97133d3a7d  pop rdi
00007e97133d3a7e  pop rdx
00007e97133d3a7f  pop rcx
00007e97133d3a80  pop rax
00007e97133d3a81  add rsp, 0x08
00007e97133d3a85  jmp 0x00007E97133CFFE1
00007e97133d3a8a  sub rsp, 0x08
00007e97133d3a8e  push rax
00007e97133d3a8f  push rcx
00007e97133d3a90  push rdx
00007e97133d3a91  push rdi
00007e97133d3a92  push rsi
00007e97133d3a93  push r8
00007e97133d3a95  push r9
00007e97133d3a97  push r10
00007e97133d3a99  push r11
00007e97133d3a9b  sub rsp, 0xF0
00007e97133d3aa2  vmovaps [rsp], xmm0
00007e97133d3aa7  vmovaps [rsp+0x10], xmm1
00007e97133d3aad  vmovaps [rsp+0x20], xmm2
00007e97133d3ab3  vmovaps [rsp+0x30], xmm3
00007e97133d3ab9  vmovaps [rsp+0x40], xmm4
00007e97133d3abf  vmovaps [rsp+0x50], xmm5
00007e97133d3ac5  vmovaps [rsp+0x60], xmm6
00007e97133d3acb  vmovaps [rsp+0x70], xmm7
00007e97133d3ad1  vmovaps [rsp+0x80], xmm8
00007e97133d3ada  vmovaps [rsp+0x90], xmm9
00007e97133d3ae3  vmovaps [rsp+0xA0], xmm11
00007e97133d3aec  vmovaps [rsp+0xB0], xmm12
00007e97133d3af5  vmovaps [rsp+0xC0], xmm13
00007e97133d3afe  vmovaps [rsp+0xD0], xmm14
00007e97133d3b07  vmovaps [rsp+0xE0], xmm15
00007e97133d3b10  sub rsp, 0x30
00007e97133d3b14  movaps [rsp], xmm10
00007e97133d3b19  movaps [rsp+0x10], xmm1
00007e97133d3b1e  movaps [rsp+0x20], xmm11
00007e97133d3b24  lea rdi, [rsp]
00007e97133d3b28  mov esi, 0x00
00007e97133d3b2d  mov rax, 0x58D8AED5F530
00007e97133d3b37  call rax
00007e97133d3b39  movaps xmm10, [rsp]
00007e97133d3b3e  add rsp, 0x30
00007e97133d3b42  vmovaps xmm0, [rsp]
00007e97133d3b47  vmovaps xmm1, [rsp+0x10]
00007e97133d3b4d  vmovaps xmm2, [rsp+0x20]
00007e97133d3b53  vmovaps xmm3, [rsp+0x30]
00007e97133d3b59  vmovaps xmm4, [rsp+0x40]
00007e97133d3b5f  vmovaps xmm5, [rsp+0x50]
00007e97133d3b65  vmovaps xmm6, [rsp+0x60]
00007e97133d3b6b  vmovaps xmm7, [rsp+0x70]
00007e97133d3b71  vmovaps xmm8, [rsp+0x80]
00007e97133d3b7a  vmovaps xmm9, [rsp+0x90]
00007e97133d3b83  vmovaps xmm11, [rsp+0xA0]
00007e97133d3b8c  vmovaps xmm12, [rsp+0xB0]
00007e97133d3b95  vmovaps xmm13, [rsp+0xC0]
00007e97133d3b9e  vmovaps xmm14, [rsp+0xD0]
00007e97133d3ba7  vmovaps xmm15, [rsp+0xE0]
00007e97133d3bb0  add rsp, 0xF0
00007e97133d3bb7  pop r11
00007e97133d3bb9  pop r10
00007e97133d3bbb  pop r9
00007e97133d3bbd  pop r8
00007e97133d3bbf  pop rsi
00007e97133d3bc0  pop rdi
00007e97133d3bc1  pop rdx
00007e97133d3bc2  pop rcx
00007e97133d3bc3  pop rax
00007e97133d3bc4  add rsp, 0x08
00007e97133d3bc8  jmp 0x00007E97133CFFFC
00007e97133d3bcd  sub rsp, 0x08
00007e97133d3bd1  push rax
00007e97133d3bd2  push rcx
00007e97133d3bd3  push rdx
00007e97133d3bd4  push rdi
00007e97133d3bd5  push rsi
00007e97133d3bd6  push r8
00007e97133d3bd8  push r9
00007e97133d3bda  push r10
00007e97133d3bdc  push r11
00007e97133d3bde  sub rsp, 0xF0
00007e97133d3be5  vmovaps [rsp], xmm0
00007e97133d3bea  vmovaps [rsp+0x10], xmm2
00007e97133d3bf0  vmovaps [rsp+0x20], xmm3
00007e97133d3bf6  vmovaps [rsp+0x30], xmm4
00007e97133d3bfc  vmovaps [rsp+0x40], xmm5
00007e97133d3c02  vmovaps [rsp+0x50], xmm6
00007e97133d3c08  vmovaps [rsp+0x60], xmm7
00007e97133d3c0e  vmovaps [rsp+0x70], xmm8
00007e97133d3c14  vmovaps [rsp+0x80], xmm9
00007e97133d3c1d  vmovaps [rsp+0x90], xmm10
00007e97133d3c26  vmovaps [rsp+0xA0], xmm11
00007e97133d3c2f  vmovaps [rsp+0xB0], xmm12
00007e97133d3c38  vmovaps [rsp+0xC0], xmm13
00007e97133d3c41  vmovaps [rsp+0xD0], xmm14
00007e97133d3c4a  vmovaps [rsp+0xE0], xmm15
00007e97133d3c53  sub rsp, 0x30
00007e97133d3c57  movaps [rsp], xmm1
00007e97133d3c5b  movaps [rsp+0x10], xmm14
00007e97133d3c61  movaps [rsp+0x20], xmm6
00007e97133d3c66  lea rdi, [rsp]
00007e97133d3c6a  mov esi, 0x00
00007e97133d3c6f  mov rax, 0x58D8AED5F530
00007e97133d3c79  call rax
00007e97133d3c7b  movaps xmm1, [rsp]
00007e97133d3c7f  add rsp, 0x30
00007e97133d3c83  vmovaps xmm0, [rsp]
00007e97133d3c88  vmovaps xmm2, [rsp+0x10]
00007e97133d3c8e  vmovaps xmm3, [rsp+0x20]
00007e97133d3c94  vmovaps xmm4, [rsp+0x30]
00007e97133d3c9a  vmovaps xmm5, [rsp+0x40]
00007e97133d3ca0  vmovaps xmm6, [rsp+0x50]
00007e97133d3ca6  vmovaps xmm7, [rsp+0x60]
00007e97133d3cac  vmovaps xmm8, [rsp+0x70]
00007e97133d3cb2  vmovaps xmm9, [rsp+0x80]
00007e97133d3cbb  vmovaps xmm10, [rsp+0x90]
00007e97133d3cc4  vmovaps xmm11, [rsp+0xA0]
00007e97133d3ccd  vmovaps xmm12, [rsp+0xB0]
00007e97133d3cd6  vmovaps xmm13, [rsp+0xC0]
00007e97133d3cdf  vmovaps xmm14, [rsp+0xD0]
00007e97133d3ce8  vmovaps xmm15, [rsp+0xE0]
00007e97133d3cf1  add rsp, 0xF0
00007e97133d3cf8  pop r11
00007e97133d3cfa  pop r10
00007e97133d3cfc  pop r9
00007e97133d3cfe  pop r8
00007e97133d3d00  pop rsi
00007e97133d3d01  pop rdi
00007e97133d3d02  pop rdx
00007e97133d3d03  pop rcx
00007e97133d3d04  pop rax
00007e97133d3d05  add rsp, 0x08
00007e97133d3d09  jmp 0x00007E97133D0015
00007e97133d3d0e  sub rsp, 0x08
00007e97133d3d12  push rax
00007e97133d3d13  push rcx
00007e97133d3d14  push rdx
00007e97133d3d15  push rdi
00007e97133d3d16  push rsi
00007e97133d3d17  push r8
00007e97133d3d19  push r9
00007e97133d3d1b  push r10
00007e97133d3d1d  push r11
00007e97133d3d1f  sub rsp, 0xF0
00007e97133d3d26  vmovaps [rsp], xmm0
00007e97133d3d2b  vmovaps [rsp+0x10], xmm1
00007e97133d3d31  vmovaps [rsp+0x20], xmm2
00007e97133d3d37  vmovaps [rsp+0x30], xmm3
00007e97133d3d3d  vmovaps [rsp+0x40], xmm4
00007e97133d3d43  vmovaps [rsp+0x50], xmm5
00007e97133d3d49  vmovaps [rsp+0x60], xmm6
00007e97133d3d4f  vmovaps [rsp+0x70], xmm7
00007e97133d3d55  vmovaps [rsp+0x80], xmm8
00007e97133d3d5e  vmovaps [rsp+0x90], xmm9
00007e97133d3d67  vmovaps [rsp+0xA0], xmm10
00007e97133d3d70  vmovaps [rsp+0xB0], xmm12
00007e97133d3d79  vmovaps [rsp+0xC0], xmm13
00007e97133d3d82  vmovaps [rsp+0xD0], xmm14
00007e97133d3d8b  vmovaps [rsp+0xE0], xmm15
00007e97133d3d94  sub rsp, 0x30
00007e97133d3d98  movaps [rsp], xmm11
00007e97133d3d9d  movaps [rsp+0x10], xmm13
00007e97133d3da3  movaps [rsp+0x20], xmm14
00007e97133d3da9  lea rdi, [rsp]
00007e97133d3dad  mov esi, 0x00
00007e97133d3db2  mov rax, 0x58D8AED5F530
00007e97133d3dbc  call rax
00007e97133d3dbe  movaps xmm11, [rsp]
00007e97133d3dc3  add rsp, 0x30
00007e97133d3dc7  vmovaps xmm0, [rsp]
00007e97133d3dcc  vmovaps xmm1, [rsp+0x10]
00007e97133d3dd2  vmovaps xmm2, [rsp+0x20]
00007e97133d3dd8  vmovaps xmm3, [rsp+0x30]
00007e97133d3dde  vmovaps xmm4, [rsp+0x40]
00007e97133d3de4  vmovaps xmm5, [rsp+0x50]
00007e97133d3dea  vmovaps xmm6, [rsp+0x60]
00007e97133d3df0  vmovaps xmm7, [rsp+0x70]
00007e97133d3df6  vmovaps xmm8, [rsp+0x80]
00007e97133d3dff  vmovaps xmm9, [rsp+0x90]
00007e97133d3e08  vmovaps xmm10, [rsp+0xA0]
00007e97133d3e11  vmovaps xmm12, [rsp+0xB0]
00007e97133d3e1a  vmovaps xmm13, [rsp+0xC0]
00007e97133d3e23  vmovaps xmm14, [rsp+0xD0]
00007e97133d3e2c  vmovaps xmm15, [rsp+0xE0]
00007e97133d3e35  add rsp, 0xF0
00007e97133d3e3c  pop r11
00007e97133d3e3e  pop r10
00007e97133d3e40  pop r9
00007e97133d3e42  pop r8
00007e97133d3e44  pop rsi
00007e97133d3e45  pop rdi
00007e97133d3e46  pop rdx
00007e97133d3e47  pop rcx
00007e97133d3e48  pop rax
00007e97133d3e49  add rsp, 0x08
00007e97133d3e4d  jmp 0x00007E97133D003F
00007e97133d3e52  sub rsp, 0x08
00007e97133d3e56  push rax
00007e97133d3e57  push rcx
00007e97133d3e58  push rdx
00007e97133d3e59  push rdi
00007e97133d3e5a  push rsi
00007e97133d3e5b  push r8
00007e97133d3e5d  push r9
00007e97133d3e5f  push r10
00007e97133d3e61  push r11
00007e97133d3e63  sub rsp, 0xF0
00007e97133d3e6a  vmovaps [rsp], xmm0
00007e97133d3e6f  vmovaps [rsp+0x10], xmm1
00007e97133d3e75  vmovaps [rsp+0x20], xmm2
00007e97133d3e7b  vmovaps [rsp+0x30], xmm3
00007e97133d3e81  vmovaps [rsp+0x40], xmm4
00007e97133d3e87  vmovaps [rsp+0x50], xmm5
00007e97133d3e8d  vmovaps [rsp+0x60], xmm6
00007e97133d3e93  vmovaps [rsp+0x70], xmm7
00007e97133d3e99  vmovaps [rsp+0x80], xmm8
00007e97133d3ea2  vmovaps [rsp+0x90], xmm9
00007e97133d3eab  vmovaps [rsp+0xA0], xmm10
00007e97133d3eb4  vmovaps [rsp+0xB0], xmm11
00007e97133d3ebd  vmovaps [rsp+0xC0], xmm12
00007e97133d3ec6  vmovaps [rsp+0xD0], xmm14
00007e97133d3ecf  vmovaps [rsp+0xE0], xmm15
00007e97133d3ed8  sub rsp, 0x30
00007e97133d3edc  movaps [rsp], xmm13
00007e97133d3ee1  movaps [rsp+0x10], xmm8
00007e97133d3ee7  movaps [rsp+0x20], xmm14
00007e97133d3eed  lea rdi, [rsp]
00007e97133d3ef1  mov esi, 0x00
00007e97133d3ef6  mov rax, 0x58D8AED5F530
00007e97133d3f00  call rax
00007e97133d3f02  movaps xmm13, [rsp]
00007e97133d3f07  add rsp, 0x30
00007e97133d3f0b  vmovaps xmm0, [rsp]
00007e97133d3f10  vmovaps xmm1, [rsp+0x10]
00007e97133d3f16  vmovaps xmm2, [rsp+0x20]
00007e97133d3f1c  vmovaps xmm3, [rsp+0x30]
00007e97133d3f22  vmovaps xmm4, [rsp+0x40]
00007e97133d3f28  vmovaps xmm5, [rsp+0x50]
00007e97133d3f2e  vmovaps xmm6, [rsp+0x60]
00007e97133d3f34  vmovaps xmm7, [rsp+0x70]
00007e97133d3f3a  vmovaps xmm8, [rsp+0x80]
00007e97133d3f43  vmovaps xmm9, [rsp+0x90]
00007e97133d3f4c  vmovaps xmm10, [rsp+0xA0]
00007e97133d3f55  vmovaps xmm11, [rsp+0xB0]
00007e97133d3f5e  vmovaps xmm12, [rsp+0xC0]
00007e97133d3f67  vmovaps xmm14, [rsp+0xD0]
00007e97133d3f70  vmovaps xmm15, [rsp+0xE0]
00007e97133d3f79  add rsp, 0xF0
00007e97133d3f80  pop r11
00007e97133d3f82  pop r10
00007e97133d3f84  pop r9
00007e97133d3f86  pop r8
00007e97133d3f88  pop rsi
00007e97133d3f89  pop rdi
00007e97133d3f8a  pop rdx
00007e97133d3f8b  pop rcx
00007e97133d3f8c  pop rax
00007e97133d3f8d  add rsp, 0x08
00007e97133d3f91  jmp 0x00007E97133D006E
00007e97133d3f96  sub rsp, 0x08
00007e97133d3f9a  push rax
00007e97133d3f9b  push rcx
00007e97133d3f9c  push rdx
00007e97133d3f9d  push rdi
00007e97133d3f9e  push rsi
00007e97133d3f9f  push r8
00007e97133d3fa1  push r9
00007e97133d3fa3  push r10
00007e97133d3fa5  push r11
00007e97133d3fa7  sub rsp, 0xF0
00007e97133d3fae  vmovaps [rsp], xmm0
00007e97133d3fb3  vmovaps [rsp+0x10], xmm1
00007e97133d3fb9  vmovaps [rsp+0x20], xmm2
00007e97133d3fbf  vmovaps [rsp+0x30], xmm3
00007e97133d3fc5  vmovaps [rsp+0x40], xmm4
00007e97133d3fcb  vmovaps [rsp+0x50], xmm5
00007e97133d3fd1  vmovaps [rsp+0x60], xmm6
00007e97133d3fd7  vmovaps [rsp+0x70], xmm7
00007e97133d3fdd  vmovaps [rsp+0x80], xmm9
00007e97133d3fe6  vmovaps [rsp+0x90], xmm10
00007e97133d3fef  vmovaps [rsp+0xA0], xmm11
00007e97133d3ff8  vmovaps [rsp+0xB0], xmm12
00007e97133d4001  vmovaps [rsp+0xC0], xmm13
00007e97133d400a  vmovaps [rsp+0xD0], xmm14
00007e97133d4013  vmovaps [rsp+0xE0], xmm15
00007e97133d401c  sub rsp, 0x30
00007e97133d4020  movaps [rsp], xmm8
00007e97133d4025  movaps [rsp+0x10], xmm7
00007e97133d402a  movaps [rsp+0x20], xmm14
00007e97133d4030  lea rdi, [rsp]
00007e97133d4034  mov esi, 0x00
00007e97133d4039  mov rax, 0x58D8AED5F530
00007e97133d4043  call rax
00007e97133d4045  movaps xmm8, [rsp]
00007e97133d404a  add rsp, 0x30
00007e97133d404e  vmovaps xmm0, [rsp]
00007e97133d4053  vmovaps xmm1, [rsp+0x10]
00007e97133d4059  vmovaps xmm2, [rsp+0x20]
00007e97133d405f  vmovaps xmm3, [rsp+0x30]
00007e97133d4065  vmovaps xmm4, [rsp+0x40]
00007e97133d406b  vmovaps xmm5, [rsp+0x50]
00007e97133d4071  vmovaps xmm6, [rsp+0x60]
00007e97133d4077  vmovaps xmm7, [rsp+0x70]
00007e97133d407d  vmovaps xmm9, [rsp+0x80]
00007e97133d4086  vmovaps xmm10, [rsp+0x90]
00007e97133d408f  vmovaps xmm11, [rsp+0xA0]
00007e97133d4098  vmovaps xmm12, [rsp+0xB0]
00007e97133d40a1  vmovaps xmm13, [rsp+0xC0]
00007e97133d40aa  vmovaps xmm14, [rsp+0xD0]
00007e97133d40b3  vmovaps xmm15, [rsp+0xE0]
00007e97133d40bc  add rsp, 0xF0
00007e97133d40c3  pop r11
00007e97133d40c5  pop r10
00007e97133d40c7  pop r9
00007e97133d40c9  pop r8
00007e97133d40cb  pop rsi
00007e97133d40cc  pop rdi
00007e97133d40cd  pop rdx
00007e97133d40ce  pop rcx
00007e97133d40cf  pop rax
00007e97133d40d0  add rsp, 0x08
00007e97133d40d4  jmp 0x00007E97133D0094
00007e97133d40d9  sub rsp, 0x08
00007e97133d40dd  push rax
00007e97133d40de  push rcx
00007e97133d40df  push rdx
00007e97133d40e0  push rdi
00007e97133d40e1  push rsi
00007e97133d40e2  push r8
00007e97133d40e4  push r9
00007e97133d40e6  push r10
00007e97133d40e8  push r11
00007e97133d40ea  sub rsp, 0xF0
00007e97133d40f1  vmovaps [rsp], xmm0
00007e97133d40f6  vmovaps [rsp+0x10], xmm1
00007e97133d40fc  vmovaps [rsp+0x20], xmm2
00007e97133d4102  vmovaps [rsp+0x30], xmm3
00007e97133d4108  vmovaps [rsp+0x40], xmm4
00007e97133d410e  vmovaps [rsp+0x50], xmm5
00007e97133d4114  vmovaps [rsp+0x60], xmm6
00007e97133d411a  vmovaps [rsp+0x70], xmm7
00007e97133d4120  vmovaps [rsp+0x80], xmm8
00007e97133d4129  vmovaps [rsp+0x90], xmm9
00007e97133d4132  vmovaps [rsp+0xA0], xmm10
00007e97133d413b  vmovaps [rsp+0xB0], xmm11
00007e97133d4144  vmovaps [rsp+0xC0], xmm12
00007e97133d414d  vmovaps [rsp+0xD0], xmm13
00007e97133d4156  vmovaps [rsp+0xE0], xmm15
00007e97133d415f  sub rsp, 0x30
00007e97133d4163  movaps [rsp], xmm14
00007e97133d4168  movaps [rsp+0x10], xmm12
00007e97133d416e  movaps [rsp+0x20], xmm9
00007e97133d4174  lea rdi, [rsp]
00007e97133d4178  mov esi, 0x00
00007e97133d417d  mov rax, 0x58D8AED5F530
00007e97133d4187  call rax
00007e97133d4189  movaps xmm14, [rsp]
00007e97133d418e  add rsp, 0x30
00007e97133d4192  vmovaps xmm0, [rsp]
00007e97133d4197  vmovaps xmm1, [rsp+0x10]
00007e97133d419d  vmovaps xmm2, [rsp+0x20]
00007e97133d41a3  vmovaps xmm3, [rsp+0x30]
00007e97133d41a9  vmovaps xmm4, [rsp+0x40]
00007e97133d41af  vmovaps xmm5, [rsp+0x50]
00007e97133d41b5  vmovaps xmm6, [rsp+0x60]
00007e97133d41bb  vmovaps xmm7, [rsp+0x70]
00007e97133d41c1  vmovaps xmm8, [rsp+0x80]
00007e97133d41ca  vmovaps xmm9, [rsp+0x90]
00007e97133d41d3  vmovaps xmm10, [rsp+0xA0]
00007e97133d41dc  vmovaps xmm11, [rsp+0xB0]
00007e97133d41e5  vmovaps xmm12, [rsp+0xC0]
00007e97133d41ee  vmovaps xmm13, [rsp+0xD0]
00007e97133d41f7  vmovaps xmm15, [rsp+0xE0]
00007e97133d4200  add rsp, 0xF0
00007e97133d4207  pop r11
00007e97133d4209  pop r10
00007e97133d420b  pop r9
00007e97133d420d  pop r8
00007e97133d420f  pop rsi
00007e97133d4210  pop rdi
00007e97133d4211  pop rdx
00007e97133d4212  pop rcx
00007e97133d4213  pop rax
00007e97133d4214  add rsp, 0x08
00007e97133d4218  jmp 0x00007E97133D00AE
00007e97133d421d  sub rsp, 0x08
00007e97133d4221  push rax
00007e97133d4222  push rcx
00007e97133d4223  push rdx
00007e97133d4224  push rdi
00007e97133d4225  push rsi
00007e97133d4226  push r8
00007e97133d4228  push r9
00007e97133d422a  push r10
00007e97133d422c  push r11
00007e97133d422e  sub rsp, 0xF0
00007e97133d4235  vmovaps [rsp], xmm0
00007e97133d423a  vmovaps [rsp+0x10], xmm1
00007e97133d4240  vmovaps [rsp+0x20], xmm2
00007e97133d4246  vmovaps [rsp+0x30], xmm3
00007e97133d424c  vmovaps [rsp+0x40], xmm4
00007e97133d4252  vmovaps [rsp+0x50], xmm5
00007e97133d4258  vmovaps [rsp+0x60], xmm6
00007e97133d425e  vmovaps [rsp+0x70], xmm7
00007e97133d4264  vmovaps [rsp+0x80], xmm8
00007e97133d426d  vmovaps [rsp+0x90], xmm10
00007e97133d4276  vmovaps [rsp+0xA0], xmm11
00007e97133d427f  vmovaps [rsp+0xB0], xmm12
00007e97133d4288  vmovaps [rsp+0xC0], xmm13
00007e97133d4291  vmovaps [rsp+0xD0], xmm14
00007e97133d429a  vmovaps [rsp+0xE0], xmm15
00007e97133d42a3  sub rsp, 0x30
00007e97133d42a7  movaps [rsp], xmm9
00007e97133d42ac  movaps [rsp+0x10], xmm7
00007e97133d42b1  movaps [rsp+0x20], xmm12
00007e97133d42b7  lea rdi, [rsp]
00007e97133d42bb  mov esi, 0x00
00007e97133d42c0  mov rax, 0x58D8AED5F530
00007e97133d42ca  call rax
00007e97133d42cc  movaps xmm9, [rsp]
00007e97133d42d1  add rsp, 0x30
00007e97133d42d5  vmovaps xmm0, [rsp]
00007e97133d42da  vmovaps xmm1, [rsp+0x10]
00007e97133d42e0  vmovaps xmm2, [rsp+0x20]
00007e97133d42e6  vmovaps xmm3, [rsp+0x30]
00007e97133d42ec  vmovaps xmm4, [rsp+0x40]
00007e97133d42f2  vmovaps xmm5, [rsp+0x50]
00007e97133d42f8  vmovaps xmm6, [rsp+0x60]
00007e97133d42fe  vmovaps xmm7, [rsp+0x70]
00007e97133d4304  vmovaps xmm8, [rsp+0x80]
00007e97133d430d  vmovaps xmm10, [rsp+0x90]
00007e97133d4316  vmovaps xmm11, [rsp+0xA0]
00007e97133d431f  vmovaps xmm12, [rsp+0xB0]
00007e97133d4328  vmovaps xmm13, [rsp+0xC0]
00007e97133d4331  vmovaps xmm14, [rsp+0xD0]
00007e97133d433a  vmovaps xmm15, [rsp+0xE0]
00007e97133d4343  add rsp, 0xF0
00007e97133d434a  pop r11
00007e97133d434c  pop r10
00007e97133d434e  pop r9
00007e97133d4350  pop r8
00007e97133d4352  pop rsi
00007e97133d4353  pop rdi
00007e97133d4354  pop rdx
00007e97133d4355  pop rcx
00007e97133d4356  pop rax
00007e97133d4357  add rsp, 0x08
00007e97133d435b  jmp 0x00007E97133D00DD
00007e97133d4360  sub rsp, 0x08
00007e97133d4364  push rax
00007e97133d4365  push rcx
00007e97133d4366  push rdx
00007e97133d4367  push rdi
00007e97133d4368  push rsi
00007e97133d4369  push r8
00007e97133d436b  push r9
00007e97133d436d  push r10
00007e97133d436f  push r11
00007e97133d4371  sub rsp, 0xF0
00007e97133d4378  vmovaps [rsp], xmm0
00007e97133d437d  vmovaps [rsp+0x10], xmm1
00007e97133d4383  vmovaps [rsp+0x20], xmm2
00007e97133d4389  vmovaps [rsp+0x30], xmm3
00007e97133d438f  vmovaps [rsp+0x40], xmm4
00007e97133d4395  vmovaps [rsp+0x50], xmm5
00007e97133d439b  vmovaps [rsp+0x60], xmm6
00007e97133d43a1  vmovaps [rsp+0x70], xmm7
00007e97133d43a7  vmovaps [rsp+0x80], xmm8
00007e97133d43b0  vmovaps [rsp+0x90], xmm9
00007e97133d43b9  vmovaps [rsp+0xA0], xmm10
00007e97133d43c2  vmovaps [rsp+0xB0], xmm11
00007e97133d43cb  vmovaps [rsp+0xC0], xmm13
00007e97133d43d4  vmovaps [rsp+0xD0], xmm14
00007e97133d43dd  vmovaps [rsp+0xE0], xmm15
00007e97133d43e6  sub rsp, 0x30
00007e97133d43ea  movaps [rsp], xmm12
00007e97133d43ef  movaps [rsp+0x10], xmm15
00007e97133d43f5  movaps [rsp+0x20], xmm11
00007e97133d43fb  lea rdi, [rsp]
00007e97133d43ff  mov esi, 0x00
00007e97133d4404  mov rax, 0x58D8AED5F530
00007e97133d440e  call rax
00007e97133d4410  movaps xmm12, [rsp]
00007e97133d4415  add rsp, 0x30
00007e97133d4419  vmovaps xmm0, [rsp]
00007e97133d441e  vmovaps xmm1, [rsp+0x10]
00007e97133d4424  vmovaps xmm2, [rsp+0x20]
00007e97133d442a  vmovaps xmm3, [rsp+0x30]
00007e97133d4430  vmovaps xmm4, [rsp+0x40]
00007e97133d4436  vmovaps xmm5, [rsp+0x50]
00007e97133d443c  vmovaps xmm6, [rsp+0x60]
00007e97133d4442  vmovaps xmm7, [rsp+0x70]
00007e97133d4448  vmovaps xmm8, [rsp+0x80]
00007e97133d4451  vmovaps xmm9, [rsp+0x90]
00007e97133d445a  vmovaps xmm10, [rsp+0xA0]
00007e97133d4463  vmovaps xmm11, [rsp+0xB0]
00007e97133d446c  vmovaps xmm13, [rsp+0xC0]
00007e97133d4475  vmovaps xmm14, [rsp+0xD0]
00007e97133d447e  vmovaps xmm15, [rsp+0xE0]
00007e97133d4487  add rsp, 0xF0
00007e97133d448e  pop r11
00007e97133d4490  pop r10
00007e97133d4492  pop r9
00007e97133d4494  pop r8
00007e97133d4496  pop rsi
00007e97133d4497  pop rdi
00007e97133d4498  pop rdx
00007e97133d4499  pop rcx
00007e97133d449a  pop rax
00007e97133d449b  add rsp, 0x08
00007e97133d449f  jmp 0x00007E97133D00F7
00007e97133d44a4  sub rsp, 0x08
00007e97133d44a8  push rax
00007e97133d44a9  push rcx
00007e97133d44aa  push rdx
00007e97133d44ab  push rdi
00007e97133d44ac  push rsi
00007e97133d44ad  push r8
00007e97133d44af  push r9
00007e97133d44b1  push r10
00007e97133d44b3  push r11
00007e97133d44b5  sub rsp, 0xF0
00007e97133d44bc  vmovaps [rsp], xmm0
00007e97133d44c1  vmovaps [rsp+0x10], xmm1
00007e97133d44c7  vmovaps [rsp+0x20], xmm2
00007e97133d44cd  vmovaps [rsp+0x30], xmm3
00007e97133d44d3  vmovaps [rsp+0x40], xmm4
00007e97133d44d9  vmovaps [rsp+0x50], xmm5
00007e97133d44df  vmovaps [rsp+0x60], xmm6
00007e97133d44e5  vmovaps [rsp+0x70], xmm7
00007e97133d44eb  vmovaps [rsp+0x80], xmm8
00007e97133d44f4  vmovaps [rsp+0x90], xmm9
00007e97133d44fd  vmovaps [rsp+0xA0], xmm10
00007e97133d4506  vmovaps [rsp+0xB0], xmm12
00007e97133d450f  vmovaps [rsp+0xC0], xmm13
00007e97133d4518  vmovaps [rsp+0xD0], xmm14
00007e97133d4521  vmovaps [rsp+0xE0], xmm15
00007e97133d452a  sub rsp, 0x30
00007e97133d452e  movaps [rsp], xmm11
00007e97133d4533  movaps [rsp+0x10], xmm7
00007e97133d4538  movaps [rsp+0x20], xmm15
00007e97133d453e  lea rdi, [rsp]
00007e97133d4542  mov esi, 0x00
00007e97133d4547  mov rax, 0x58D8AED5F530
00007e97133d4551  call rax
00007e97133d4553  movaps xmm11, [rsp]
00007e97133d4558  add rsp, 0x30
00007e97133d455c  vmovaps xmm0, [rsp]
00007e97133d4561  vmovaps xmm1, [rsp+0x10]
00007e97133d4567  vmovaps xmm2, [rsp+0x20]
00007e97133d456d  vmovaps xmm3, [rsp+0x30]
00007e97133d4573  vmovaps xmm4, [rsp+0x40]
00007e97133d4579  vmovaps xmm5, [rsp+0x50]
00007e97133d457f  vmovaps xmm6, [rsp+0x60]
00007e97133d4585  vmovaps xmm7, [rsp+0x70]
00007e97133d458b  vmovaps xmm8, [rsp+0x80]
00007e97133d4594  vmovaps xmm9, [rsp+0x90]
00007e97133d459d  vmovaps xmm10, [rsp+0xA0]
00007e97133d45a6  vmovaps xmm12, [rsp+0xB0]
00007e97133d45af  vmovaps xmm13, [rsp+0xC0]
00007e97133d45b8  vmovaps xmm14, [rsp+0xD0]
00007e97133d45c1  vmovaps xmm15, [rsp+0xE0]
00007e97133d45ca  add rsp, 0xF0
00007e97133d45d1  pop r11
00007e97133d45d3  pop r10
00007e97133d45d5  pop r9
00007e97133d45d7  pop r8
00007e97133d45d9  pop rsi
00007e97133d45da  pop rdi
00007e97133d45db  pop rdx
00007e97133d45dc  pop rcx
00007e97133d45dd  pop rax
00007e97133d45de  add rsp, 0x08
00007e97133d45e2  jmp 0x00007E97133D0123
00007e97133d45e7  sub rsp, 0x08
00007e97133d45eb  push rax
00007e97133d45ec  push rcx
00007e97133d45ed  push rdx
00007e97133d45ee  push rdi
00007e97133d45ef  push rsi
00007e97133d45f0  push r8
00007e97133d45f2  push r9
00007e97133d45f4  push r10
00007e97133d45f6  push r11
00007e97133d45f8  sub rsp, 0xF0
00007e97133d45ff  vmovaps [rsp], xmm0
00007e97133d4604  vmovaps [rsp+0x10], xmm1
00007e97133d460a  vmovaps [rsp+0x20], xmm2
00007e97133d4610  vmovaps [rsp+0x30], xmm3
00007e97133d4616  vmovaps [rsp+0x40], xmm4
00007e97133d461c  vmovaps [rsp+0x50], xmm5
00007e97133d4622  vmovaps [rsp+0x60], xmm6
00007e97133d4628  vmovaps [rsp+0x70], xmm7
00007e97133d462e  vmovaps [rsp+0x80], xmm8
00007e97133d4637  vmovaps [rsp+0x90], xmm9
00007e97133d4640  vmovaps [rsp+0xA0], xmm10
00007e97133d4649  vmovaps [rsp+0xB0], xmm11
00007e97133d4652  vmovaps [rsp+0xC0], xmm12
00007e97133d465b  vmovaps [rsp+0xD0], xmm13
00007e97133d4664  vmovaps [rsp+0xE0], xmm14
00007e97133d466d  sub rsp, 0x30
00007e97133d4671  movaps [rsp], xmm15
00007e97133d4676  movaps [rsp+0x10], xmm10
00007e97133d467c  movaps [rsp+0x20], xmm13
00007e97133d4682  lea rdi, [rsp]
00007e97133d4686  mov esi, 0x00
00007e97133d468b  mov rax, 0x58D8AED5F530
00007e97133d4695  call rax
00007e97133d4697  movaps xmm15, [rsp]
00007e97133d469c  add rsp, 0x30
00007e97133d46a0  vmovaps xmm0, [rsp]
00007e97133d46a5  vmovaps xmm1, [rsp+0x10]
00007e97133d46ab  vmovaps xmm2, [rsp+0x20]
00007e97133d46b1  vmovaps xmm3, [rsp+0x30]
00007e97133d46b7  vmovaps xmm4, [rsp+0x40]
00007e97133d46bd  vmovaps xmm5, [rsp+0x50]
00007e97133d46c3  vmovaps xmm6, [rsp+0x60]
00007e97133d46c9  vmovaps xmm7, [rsp+0x70]
00007e97133d46cf  vmovaps xmm8, [rsp+0x80]
00007e97133d46d8  vmovaps xmm9, [rsp+0x90]
00007e97133d46e1  vmovaps xmm10, [rsp+0xA0]
00007e97133d46ea  vmovaps xmm11, [rsp+0xB0]
00007e97133d46f3  vmovaps xmm12, [rsp+0xC0]
00007e97133d46fc  vmovaps xmm13, [rsp+0xD0]
00007e97133d4705  vmovaps xmm14, [rsp+0xE0]
00007e97133d470e  add rsp, 0xF0
00007e97133d4715  pop r11
00007e97133d4717  pop r10
00007e97133d4719  pop r9
00007e97133d471b  pop r8
00007e97133d471d  pop rsi
00007e97133d471e  pop rdi
00007e97133d471f  pop rdx
00007e97133d4720  pop rcx
00007e97133d4721  pop rax
00007e97133d4722  add rsp, 0x08
00007e97133d4726  jmp 0x00007E97133D013D
00007e97133d472b  sub rsp, 0x08
00007e97133d472f  push rax
00007e97133d4730  push rcx
00007e97133d4731  push rdx
00007e97133d4732  push rdi
00007e97133d4733  push rsi
00007e97133d4734  push r8
00007e97133d4736  push r9
00007e97133d4738  push r10
00007e97133d473a  push r11
00007e97133d473c  sub rsp, 0xF0
00007e97133d4743  vmovaps [rsp], xmm0
00007e97133d4748  vmovaps [rsp+0x10], xmm1
00007e97133d474e  vmovaps [rsp+0x20], xmm2
00007e97133d4754  vmovaps [rsp+0x30], xmm3
00007e97133d475a  vmovaps [rsp+0x40], xmm4
00007e97133d4760  vmovaps [rsp+0x50], xmm5
00007e97133d4766  vmovaps [rsp+0x60], xmm6
00007e97133d476c  vmovaps [rsp+0x70], xmm7
00007e97133d4772  vmovaps [rsp+0x80], xmm8
00007e97133d477b  vmovaps [rsp+0x90], xmm9
00007e97133d4784  vmovaps [rsp+0xA0], xmm11
00007e97133d478d  vmovaps [rsp+0xB0], xmm12
00007e97133d4796  vmovaps [rsp+0xC0], xmm13
00007e97133d479f  vmovaps [rsp+0xD0], xmm14
00007e97133d47a8  vmovaps [rsp+0xE0], xmm15
00007e97133d47b1  sub rsp, 0x30
00007e97133d47b5  movaps [rsp], xmm10
00007e97133d47ba  movaps [rsp+0x10], xmm7
00007e97133d47bf  movaps [rsp+0x20], xmm13
00007e97133d47c5  lea rdi, [rsp]
00007e97133d47c9  mov esi, 0x00
00007e97133d47ce  mov rax, 0x58D8AED5F530
00007e97133d47d8  call rax
00007e97133d47da  movaps xmm10, [rsp]
00007e97133d47df  add rsp, 0x30
00007e97133d47e3  vmovaps xmm0, [rsp]
00007e97133d47e8  vmovaps xmm1, [rsp+0x10]
00007e97133d47ee  vmovaps xmm2, [rsp+0x20]
00007e97133d47f4  vmovaps xmm3, [rsp+0x30]
00007e97133d47fa  vmovaps xmm4, [rsp+0x40]
00007e97133d4800  vmovaps xmm5, [rsp+0x50]
00007e97133d4806  vmovaps xmm6, [rsp+0x60]
00007e97133d480c  vmovaps xmm7, [rsp+0x70]
00007e97133d4812  vmovaps xmm8, [rsp+0x80]
00007e97133d481b  vmovaps xmm9, [rsp+0x90]
00007e97133d4824  vmovaps xmm11, [rsp+0xA0]
00007e97133d482d  vmovaps xmm12, [rsp+0xB0]
00007e97133d4836  vmovaps xmm13, [rsp+0xC0]
00007e97133d483f  vmovaps xmm14, [rsp+0xD0]
00007e97133d4848  vmovaps xmm15, [rsp+0xE0]
00007e97133d4851  add rsp, 0xF0
00007e97133d4858  pop r11
00007e97133d485a  pop r10
00007e97133d485c  pop r9
00007e97133d485e  pop r8
00007e97133d4860  pop rsi
00007e97133d4861  pop rdi
00007e97133d4862  pop rdx
00007e97133d4863  pop rcx
00007e97133d4864  pop rax
00007e97133d4865  add rsp, 0x08
00007e97133d4869  jmp 0x00007E97133D0169
00007e97133d486e  sub rsp, 0x08
00007e97133d4872  push rax
00007e97133d4873  push rcx
00007e97133d4874  push rdx
00007e97133d4875  push rdi
00007e97133d4876  push rsi
00007e97133d4877  push r8
00007e97133d4879  push r9
00007e97133d487b  push r10
00007e97133d487d  push r11
00007e97133d487f  sub rsp, 0xF0
00007e97133d4886  vmovaps [rsp], xmm0
00007e97133d488b  vmovaps [rsp+0x10], xmm1
00007e97133d4891  vmovaps [rsp+0x20], xmm2
00007e97133d4897  vmovaps [rsp+0x30], xmm3
00007e97133d489d  vmovaps [rsp+0x40], xmm4
00007e97133d48a3  vmovaps [rsp+0x50], xmm5
00007e97133d48a9  vmovaps [rsp+0x60], xmm6
00007e97133d48af  vmovaps [rsp+0x70], xmm7
00007e97133d48b5  vmovaps [rsp+0x80], xmm8
00007e97133d48be  vmovaps [rsp+0x90], xmm9
00007e97133d48c7  vmovaps [rsp+0xA0], xmm10
00007e97133d48d0  vmovaps [rsp+0xB0], xmm11
00007e97133d48d9  vmovaps [rsp+0xC0], xmm12
00007e97133d48e2  vmovaps [rsp+0xD0], xmm14
00007e97133d48eb  vmovaps [rsp+0xE0], xmm15
00007e97133d48f4  sub rsp, 0x30
00007e97133d48f8  movaps [rsp], xmm13
00007e97133d48fd  movaps [rsp+0x10], xmm1
00007e97133d4902  movaps [rsp+0x20], xmm8
00007e97133d4908  lea rdi, [rsp]
00007e97133d490c  mov esi, 0x00
00007e97133d4911  mov rax, 0x58D8AED5F530
00007e97133d491b  call rax
00007e97133d491d  movaps xmm13, [rsp]
00007e97133d4922  add rsp, 0x30
00007e97133d4926  vmovaps xmm0, [rsp]
00007e97133d492b  vmovaps xmm1, [rsp+0x10]
00007e97133d4931  vmovaps xmm2, [rsp+0x20]
00007e97133d4937  vmovaps xmm3, [rsp+0x30]
00007e97133d493d  vmovaps xmm4, [rsp+0x40]
00007e97133d4943  vmovaps xmm5, [rsp+0x50]
00007e97133d4949  vmovaps xmm6, [rsp+0x60]
00007e97133d494f  vmovaps xmm7, [rsp+0x70]
00007e97133d4955  vmovaps xmm8, [rsp+0x80]
00007e97133d495e  vmovaps xmm9, [rsp+0x90]
00007e97133d4967  vmovaps xmm10, [rsp+0xA0]
00007e97133d4970  vmovaps xmm11, [rsp+0xB0]
00007e97133d4979  vmovaps xmm12, [rsp+0xC0]
00007e97133d4982  vmovaps xmm14, [rsp+0xD0]
00007e97133d498b  vmovaps xmm15, [rsp+0xE0]
00007e97133d4994  add rsp, 0xF0
00007e97133d499b  pop r11
00007e97133d499d  pop r10
00007e97133d499f  pop r9
00007e97133d49a1  pop r8
00007e97133d49a3  pop rsi
00007e97133d49a4  pop rdi
00007e97133d49a5  pop rdx
00007e97133d49a6  pop rcx
00007e97133d49a7  pop rax
00007e97133d49a8  add rsp, 0x08
00007e97133d49ac  jmp 0x00007E97133D0183
00007e97133d49b1  call 0x00007E97131FF430
00007e97133d49b6  jmp 0x00007E97133D018D
00007e97133d49bb  sub rsp, 0x08
00007e97133d49bf  push rax
00007e97133d49c0  push rcx
00007e97133d49c1  push rdx
00007e97133d49c2  push rdi
00007e97133d49c3  push rsi
00007e97133d49c4  push r8
00007e97133d49c6  push r9
00007e97133d49c8  push r10
00007e97133d49ca  push r11
00007e97133d49cc  sub rsp, 0xF0
00007e97133d49d3  vmovaps [rsp], xmm0
00007e97133d49d8  vmovaps [rsp+0x10], xmm1
00007e97133d49de  vmovaps [rsp+0x20], xmm2
00007e97133d49e4  vmovaps [rsp+0x30], xmm3
00007e97133d49ea  vmovaps [rsp+0x40], xmm4
00007e97133d49f0  vmovaps [rsp+0x50], xmm5
00007e97133d49f6  vmovaps [rsp+0x60], xmm6
00007e97133d49fc  vmovaps [rsp+0x70], xmm7
00007e97133d4a02  vmovaps [rsp+0x80], xmm9
00007e97133d4a0b  vmovaps [rsp+0x90], xmm10
00007e97133d4a14  vmovaps [rsp+0xA0], xmm11
00007e97133d4a1d  vmovaps [rsp+0xB0], xmm12
00007e97133d4a26  vmovaps [rsp+0xC0], xmm13
00007e97133d4a2f  vmovaps [rsp+0xD0], xmm14
00007e97133d4a38  vmovaps [rsp+0xE0], xmm15
00007e97133d4a41  sub rsp, 0x30
00007e97133d4a45  movaps [rsp], xmm8
00007e97133d4a4a  movaps [rsp+0x10], xmm14
00007e97133d4a50  movaps [rsp+0x20], xmm9
00007e97133d4a56  lea rdi, [rsp]
00007e97133d4a5a  mov esi, 0x00
00007e97133d4a5f  mov rax, 0x58D8AED5F530
00007e97133d4a69  call rax
00007e97133d4a6b  movaps xmm8, [rsp]
00007e97133d4a70  add rsp, 0x30
00007e97133d4a74  vmovaps xmm0, [rsp]
00007e97133d4a79  vmovaps xmm1, [rsp+0x10]
00007e97133d4a7f  vmovaps xmm2, [rsp+0x20]
00007e97133d4a85  vmovaps xmm3, [rsp+0x30]
00007e97133d4a8b  vmovaps xmm4, [rsp+0x40]
00007e97133d4a91  vmovaps xmm5, [rsp+0x50]
00007e97133d4a97  vmovaps xmm6, [rsp+0x60]
00007e97133d4a9d  vmovaps xmm7, [rsp+0x70]
00007e97133d4aa3  vmovaps xmm9, [rsp+0x80]
00007e97133d4aac  vmovaps xmm10, [rsp+0x90]
00007e97133d4ab5  vmovaps xmm11, [rsp+0xA0]
00007e97133d4abe  vmovaps xmm12, [rsp+0xB0]
00007e97133d4ac7  vmovaps xmm13, [rsp+0xC0]
00007e97133d4ad0  vmovaps xmm14, [rsp+0xD0]
00007e97133d4ad9  vmovaps xmm15, [rsp+0xE0]
00007e97133d4ae2  add rsp, 0xF0
00007e97133d4ae9  pop r11
00007e97133d4aeb  pop r10
00007e97133d4aed  pop r9
00007e97133d4aef  pop r8
00007e97133d4af1  pop rsi
00007e97133d4af2  pop rdi
00007e97133d4af3  pop rdx
00007e97133d4af4  pop rcx
00007e97133d4af5  pop rax
00007e97133d4af6  add rsp, 0x08
00007e97133d4afa  jmp 0x00007E97133D01AF
00007e97133d4aff  sub rsp, 0x08
00007e97133d4b03  push rax
00007e97133d4b04  push rcx
00007e97133d4b05  push rdx
00007e97133d4b06  push rdi
00007e97133d4b07  push rsi
00007e97133d4b08  push r8
00007e97133d4b0a  push r9
00007e97133d4b0c  push r10
00007e97133d4b0e  push r11
00007e97133d4b10  sub rsp, 0xF0
00007e97133d4b17  vmovaps [rsp], xmm0
00007e97133d4b1c  vmovaps [rsp+0x10], xmm1
00007e97133d4b22  vmovaps [rsp+0x20], xmm2
00007e97133d4b28  vmovaps [rsp+0x30], xmm3
00007e97133d4b2e  vmovaps [rsp+0x40], xmm4
00007e97133d4b34  vmovaps [rsp+0x50], xmm5
00007e97133d4b3a  vmovaps [rsp+0x60], xmm6
00007e97133d4b40  vmovaps [rsp+0x70], xmm7
00007e97133d4b46  vmovaps [rsp+0x80], xmm8
00007e97133d4b4f  vmovaps [rsp+0x90], xmm10
00007e97133d4b58  vmovaps [rsp+0xA0], xmm11
00007e97133d4b61  vmovaps [rsp+0xB0], xmm12
00007e97133d4b6a  vmovaps [rsp+0xC0], xmm13
00007e97133d4b73  vmovaps [rsp+0xD0], xmm14
00007e97133d4b7c  vmovaps [rsp+0xE0], xmm15
00007e97133d4b85  sub rsp, 0x30
00007e97133d4b89  movaps [rsp], xmm9
00007e97133d4b8e  movaps [rsp+0x10], xmm1
00007e97133d4b93  movaps [rsp+0x20], xmm14
00007e97133d4b99  lea rdi, [rsp]
00007e97133d4b9d  mov esi, 0x00
00007e97133d4ba2  mov rax, 0x58D8AED5F530
00007e97133d4bac  call rax
00007e97133d4bae  movaps xmm9, [rsp]
00007e97133d4bb3  add rsp, 0x30
00007e97133d4bb7  vmovaps xmm0, [rsp]
00007e97133d4bbc  vmovaps xmm1, [rsp+0x10]
00007e97133d4bc2  vmovaps xmm2, [rsp+0x20]
00007e97133d4bc8  vmovaps xmm3, [rsp+0x30]
00007e97133d4bce  vmovaps xmm4, [rsp+0x40]
00007e97133d4bd4  vmovaps xmm5, [rsp+0x50]
00007e97133d4bda  vmovaps xmm6, [rsp+0x60]
00007e97133d4be0  vmovaps xmm7, [rsp+0x70]
00007e97133d4be6  vmovaps xmm8, [rsp+0x80]
00007e97133d4bef  vmovaps xmm10, [rsp+0x90]
00007e97133d4bf8  vmovaps xmm11, [rsp+0xA0]
00007e97133d4c01  vmovaps xmm12, [rsp+0xB0]
00007e97133d4c0a  vmovaps xmm13, [rsp+0xC0]
00007e97133d4c13  vmovaps xmm14, [rsp+0xD0]
00007e97133d4c1c  vmovaps xmm15, [rsp+0xE0]
00007e97133d4c25  add rsp, 0xF0
00007e97133d4c2c  pop r11
00007e97133d4c2e  pop r10
00007e97133d4c30  pop r9
00007e97133d4c32  pop r8
00007e97133d4c34  pop rsi
00007e97133d4c35  pop rdi
00007e97133d4c36  pop rdx
00007e97133d4c37  pop rcx
00007e97133d4c38  pop rax
00007e97133d4c39  add rsp, 0x08
00007e97133d4c3d  jmp 0x00007E97133D01DD
00007e97133d4c42  sub rsp, 0x08
00007e97133d4c46  push rax
00007e97133d4c47  push rcx
00007e97133d4c48  push rdx
00007e97133d4c49  push rdi
00007e97133d4c4a  push rsi
00007e97133d4c4b  push r8
00007e97133d4c4d  push r9
00007e97133d4c4f  push r10
00007e97133d4c51  push r11
00007e97133d4c53  sub rsp, 0xF0
00007e97133d4c5a  vmovaps [rsp], xmm0
00007e97133d4c5f  vmovaps [rsp+0x10], xmm1
00007e97133d4c65  vmovaps [rsp+0x20], xmm2
00007e97133d4c6b  vmovaps [rsp+0x30], xmm3
00007e97133d4c71  vmovaps [rsp+0x40], xmm4
00007e97133d4c77  vmovaps [rsp+0x50], xmm5
00007e97133d4c7d  vmovaps [rsp+0x60], xmm6
00007e97133d4c83  vmovaps [rsp+0x70], xmm7
00007e97133d4c89  vmovaps [rsp+0x80], xmm8
00007e97133d4c92  vmovaps [rsp+0x90], xmm9
00007e97133d4c9b  vmovaps [rsp+0xA0], xmm10
00007e97133d4ca4  vmovaps [rsp+0xB0], xmm11
00007e97133d4cad  vmovaps [rsp+0xC0], xmm12
00007e97133d4cb6  vmovaps [rsp+0xD0], xmm13
00007e97133d4cbf  vmovaps [rsp+0xE0], xmm15
00007e97133d4cc8  sub rsp, 0x30
00007e97133d4ccc  movaps [rsp], xmm14
00007e97133d4cd1  movaps [rsp+0x10], xmm4
00007e97133d4cd6  movaps [rsp+0x20], xmm1
00007e97133d4cdb  lea rdi, [rsp]
00007e97133d4cdf  mov esi, 0x00
00007e97133d4ce4  mov rax, 0x58D8AED5F530
00007e97133d4cee  call rax
00007e97133d4cf0  movaps xmm14, [rsp]
00007e97133d4cf5  add rsp, 0x30
00007e97133d4cf9  vmovaps xmm0, [rsp]
00007e97133d4cfe  vmovaps xmm1, [rsp+0x10]
00007e97133d4d04  vmovaps xmm2, [rsp+0x20]
00007e97133d4d0a  vmovaps xmm3, [rsp+0x30]
00007e97133d4d10  vmovaps xmm4, [rsp+0x40]
00007e97133d4d16  vmovaps xmm5, [rsp+0x50]
00007e97133d4d1c  vmovaps xmm6, [rsp+0x60]
00007e97133d4d22  vmovaps xmm7, [rsp+0x70]
00007e97133d4d28  vmovaps xmm8, [rsp+0x80]
00007e97133d4d31  vmovaps xmm9, [rsp+0x90]
00007e97133d4d3a  vmovaps xmm10, [rsp+0xA0]
00007e97133d4d43  vmovaps xmm11, [rsp+0xB0]
00007e97133d4d4c  vmovaps xmm12, [rsp+0xC0]
00007e97133d4d55  vmovaps xmm13, [rsp+0xD0]
00007e97133d4d5e  vmovaps xmm15, [rsp+0xE0]
00007e97133d4d67  add rsp, 0xF0
00007e97133d4d6e  pop r11
00007e97133d4d70  pop r10
00007e97133d4d72  pop r9
00007e97133d4d74  pop r8
00007e97133d4d76  pop rsi
00007e97133d4d77  pop rdi
00007e97133d4d78  pop rdx
00007e97133d4d79  pop rcx
00007e97133d4d7a  pop rax
00007e97133d4d7b  add rsp, 0x08
00007e97133d4d7f  jmp 0x00007E97133D0203
00007e97133d4d84  sub rsp, 0x08
00007e97133d4d88  push rax
00007e97133d4d89  push rcx
00007e97133d4d8a  push rdx
00007e97133d4d8b  push rdi
00007e97133d4d8c  push rsi
00007e97133d4d8d  push r8
00007e97133d4d8f  push r9
00007e97133d4d91  push r10
00007e97133d4d93  push r11
00007e97133d4d95  sub rsp, 0xF0
00007e97133d4d9c  vmovaps [rsp], xmm0
00007e97133d4da1  vmovaps [rsp+0x10], xmm2
00007e97133d4da7  vmovaps [rsp+0x20], xmm3
00007e97133d4dad  vmovaps [rsp+0x30], xmm4
00007e97133d4db3  vmovaps [rsp+0x40], xmm5
00007e97133d4db9  vmovaps [rsp+0x50], xmm6
00007e97133d4dbf  vmovaps [rsp+0x60], xmm7
00007e97133d4dc5  vmovaps [rsp+0x70], xmm8
00007e97133d4dcb  vmovaps [rsp+0x80], xmm9
00007e97133d4dd4  vmovaps [rsp+0x90], xmm10
00007e97133d4ddd  vmovaps [rsp+0xA0], xmm11
00007e97133d4de6  vmovaps [rsp+0xB0], xmm12
00007e97133d4def  vmovaps [rsp+0xC0], xmm13
00007e97133d4df8  vmovaps [rsp+0xD0], xmm14
00007e97133d4e01  vmovaps [rsp+0xE0], xmm15
00007e97133d4e0a  sub rsp, 0x30
00007e97133d4e0e  movaps [rsp], xmm1
00007e97133d4e12  movaps [rsp+0x10], xmm12
00007e97133d4e18  movaps [rsp+0x20], xmm11
00007e97133d4e1e  lea rdi, [rsp]
00007e97133d4e22  mov esi, 0x00
00007e97133d4e27  mov rax, 0x58D8AED5F530
00007e97133d4e31  call rax
00007e97133d4e33  movaps xmm1, [rsp]
00007e97133d4e37  add rsp, 0x30
00007e97133d4e3b  vmovaps xmm0, [rsp]
00007e97133d4e40  vmovaps xmm2, [rsp+0x10]
00007e97133d4e46  vmovaps xmm3, [rsp+0x20]
00007e97133d4e4c  vmovaps xmm4, [rsp+0x30]
00007e97133d4e52  vmovaps xmm5, [rsp+0x40]
00007e97133d4e58  vmovaps xmm6, [rsp+0x50]
00007e97133d4e5e  vmovaps xmm7, [rsp+0x60]
00007e97133d4e64  vmovaps xmm8, [rsp+0x70]
00007e97133d4e6a  vmovaps xmm9, [rsp+0x80]
00007e97133d4e73  vmovaps xmm10, [rsp+0x90]
00007e97133d4e7c  vmovaps xmm11, [rsp+0xA0]
00007e97133d4e85  vmovaps xmm12, [rsp+0xB0]
00007e97133d4e8e  vmovaps xmm13, [rsp+0xC0]
00007e97133d4e97  vmovaps xmm14, [rsp+0xD0]
00007e97133d4ea0  vmovaps xmm15, [rsp+0xE0]
00007e97133d4ea9  add rsp, 0xF0
00007e97133d4eb0  pop r11
00007e97133d4eb2  pop r10
00007e97133d4eb4  pop r9
00007e97133d4eb6  pop r8
00007e97133d4eb8  pop rsi
00007e97133d4eb9  pop rdi
00007e97133d4eba  pop rdx
00007e97133d4ebb  pop rcx
00007e97133d4ebc  pop rax
00007e97133d4ebd  add rsp, 0x08
00007e97133d4ec1  jmp 0x00007E97133D0224
00007e97133d4ec6  call 0x00007E97132E20A0
00007e97133d4ecb  jmp 0x00007E97133D0232
00007e97133d4ed0  call 0x00007E9713209D70
00007e97133d4ed5  jmp 0x00007E97133D023C
00007e97133d4eda  sub rsp, 0x08
00007e97133d4ede  push rax
00007e97133d4edf  push rcx
00007e97133d4ee0  push rdx
00007e97133d4ee1  push rdi
00007e97133d4ee2  push rsi
00007e97133d4ee3  push r8
00007e97133d4ee5  push r9
00007e97133d4ee7  push r10
00007e97133d4ee9  push r11
00007e97133d4eeb  sub rsp, 0xF0
00007e97133d4ef2  vmovaps [rsp], xmm0
00007e97133d4ef7  vmovaps [rsp+0x10], xmm1
00007e97133d4efd  vmovaps [rsp+0x20], xmm2
00007e97133d4f03  vmovaps [rsp+0x30], xmm3
00007e97133d4f09  vmovaps [rsp+0x40], xmm4
00007e97133d4f0f  vmovaps [rsp+0x50], xmm5
00007e97133d4f15  vmovaps [rsp+0x60], xmm6
00007e97133d4f1b  vmovaps [rsp+0x70], xmm8
00007e97133d4f21  vmovaps [rsp+0x80], xmm9
00007e97133d4f2a  vmovaps [rsp+0x90], xmm10
00007e97133d4f33  vmovaps [rsp+0xA0], xmm11
00007e97133d4f3c  vmovaps [rsp+0xB0], xmm12
00007e97133d4f45  vmovaps [rsp+0xC0], xmm13
00007e97133d4f4e  vmovaps [rsp+0xD0], xmm14
00007e97133d4f57  vmovaps [rsp+0xE0], xmm15
00007e97133d4f60  sub rsp, 0x30
00007e97133d4f64  movaps [rsp], xmm7
00007e97133d4f68  movaps [rsp+0x10], xmm15
00007e97133d4f6e  movaps [rsp+0x20], xmm10
00007e97133d4f74  lea rdi, [rsp]
00007e97133d4f78  mov esi, 0x00
00007e97133d4f7d  mov rax, 0x58D8AED5F530
00007e97133d4f87  call rax
00007e97133d4f89  movaps xmm7, [rsp]
00007e97133d4f8d  add rsp, 0x30
00007e97133d4f91  vmovaps xmm0, [rsp]
00007e97133d4f96  vmovaps xmm1, [rsp+0x10]
00007e97133d4f9c  vmovaps xmm2, [rsp+0x20]
00007e97133d4fa2  vmovaps xmm3, [rsp+0x30]
00007e97133d4fa8  vmovaps xmm4, [rsp+0x40]
00007e97133d4fae  vmovaps xmm5, [rsp+0x50]
00007e97133d4fb4  vmovaps xmm6, [rsp+0x60]
00007e97133d4fba  vmovaps xmm8, [rsp+0x70]
00007e97133d4fc0  vmovaps xmm9, [rsp+0x80]
00007e97133d4fc9  vmovaps xmm10, [rsp+0x90]
00007e97133d4fd2  vmovaps xmm11, [rsp+0xA0]
00007e97133d4fdb  vmovaps xmm12, [rsp+0xB0]
00007e97133d4fe4  vmovaps xmm13, [rsp+0xC0]
00007e97133d4fed  vmovaps xmm14, [rsp+0xD0]
00007e97133d4ff6  vmovaps xmm15, [rsp+0xE0]
00007e97133d4fff  add rsp, 0xF0
00007e97133d5006  pop r11
00007e97133d5008  pop r10
00007e97133d500a  pop r9
00007e97133d500c  pop r8
00007e97133d500e  pop rsi
00007e97133d500f  pop rdi
00007e97133d5010  pop rdx
00007e97133d5011  pop rcx
00007e97133d5012  pop rax
00007e97133d5013  add rsp, 0x08
00007e97133d5017  jmp 0x00007E97133D025D
00007e97133d501c  sub rsp, 0x08
00007e97133d5020  push rax
00007e97133d5021  push rcx
00007e97133d5022  push rdx
00007e97133d5023  push rdi
00007e97133d5024  push rsi
00007e97133d5025  push r8
00007e97133d5027  push r9
00007e97133d5029  push r10
00007e97133d502b  push r11
00007e97133d502d  sub rsp, 0xF0
00007e97133d5034  vmovaps [rsp], xmm0
00007e97133d5039  vmovaps [rsp+0x10], xmm1
00007e97133d503f  vmovaps [rsp+0x20], xmm2
00007e97133d5045  vmovaps [rsp+0x30], xmm3
00007e97133d504b  vmovaps [rsp+0x40], xmm4
00007e97133d5051  vmovaps [rsp+0x50], xmm5
00007e97133d5057  vmovaps [rsp+0x60], xmm6
00007e97133d505d  vmovaps [rsp+0x70], xmm7
00007e97133d5063  vmovaps [rsp+0x80], xmm8
00007e97133d506c  vmovaps [rsp+0x90], xmm9
00007e97133d5075  vmovaps [rsp+0xA0], xmm11
00007e97133d507e  vmovaps [rsp+0xB0], xmm12
00007e97133d5087  vmovaps [rsp+0xC0], xmm13
00007e97133d5090  vmovaps [rsp+0xD0], xmm14
00007e97133d5099  vmovaps [rsp+0xE0], xmm15
00007e97133d50a2  sub rsp, 0x30
00007e97133d50a6  movaps [rsp], xmm10
00007e97133d50ab  movaps [rsp+0x10], xmm11
00007e97133d50b1  movaps [rsp+0x20], xmm15
00007e97133d50b7  lea rdi, [rsp]
00007e97133d50bb  mov esi, 0x00
00007e97133d50c0  mov rax, 0x58D8AED5F530
00007e97133d50ca  call rax
00007e97133d50cc  movaps xmm10, [rsp]
00007e97133d50d1  add rsp, 0x30
00007e97133d50d5  vmovaps xmm0, [rsp]
00007e97133d50da  vmovaps xmm1, [rsp+0x10]
00007e97133d50e0  vmovaps xmm2, [rsp+0x20]
00007e97133d50e6  vmovaps xmm3, [rsp+0x30]
00007e97133d50ec  vmovaps xmm4, [rsp+0x40]
00007e97133d50f2  vmovaps xmm5, [rsp+0x50]
00007e97133d50f8  vmovaps xmm6, [rsp+0x60]
00007e97133d50fe  vmovaps xmm7, [rsp+0x70]
00007e97133d5104  vmovaps xmm8, [rsp+0x80]
00007e97133d510d  vmovaps xmm9, [rsp+0x90]
00007e97133d5116  vmovaps xmm11, [rsp+0xA0]
00007e97133d511f  vmovaps xmm12, [rsp+0xB0]
00007e97133d5128  vmovaps xmm13, [rsp+0xC0]
00007e97133d5131  vmovaps xmm14, [rsp+0xD0]
00007e97133d513a  vmovaps xmm15, [rsp+0xE0]
00007e97133d5143  add rsp, 0xF0
00007e97133d514a  pop r11
00007e97133d514c  pop r10
00007e97133d514e  pop r9
00007e97133d5150  pop r8
00007e97133d5152  pop rsi
00007e97133d5153  pop rdi
00007e97133d5154  pop rdx
00007e97133d5155  pop rcx
00007e97133d5156  pop rax
00007e97133d5157  add rsp, 0x08
00007e97133d515b  jmp 0x00007E97133D028B
00007e97133d5160  sub rsp, 0x08
00007e97133d5164  push rax
00007e97133d5165  push rcx
00007e97133d5166  push rdx
00007e97133d5167  push rdi
00007e97133d5168  push rsi
00007e97133d5169  push r8
00007e97133d516b  push r9
00007e97133d516d  push r10
00007e97133d516f  push r11
00007e97133d5171  sub rsp, 0xF0
00007e97133d5178  vmovaps [rsp], xmm0
00007e97133d517d  vmovaps [rsp+0x10], xmm1
00007e97133d5183  vmovaps [rsp+0x20], xmm2
00007e97133d5189  vmovaps [rsp+0x30], xmm3
00007e97133d518f  vmovaps [rsp+0x40], xmm4
00007e97133d5195  vmovaps [rsp+0x50], xmm5
00007e97133d519b  vmovaps [rsp+0x60], xmm6
00007e97133d51a1  vmovaps [rsp+0x70], xmm7
00007e97133d51a7  vmovaps [rsp+0x80], xmm8
00007e97133d51b0  vmovaps [rsp+0x90], xmm9
00007e97133d51b9  vmovaps [rsp+0xA0], xmm10
00007e97133d51c2  vmovaps [rsp+0xB0], xmm12
00007e97133d51cb  vmovaps [rsp+0xC0], xmm13
00007e97133d51d4  vmovaps [rsp+0xD0], xmm14
00007e97133d51dd  vmovaps [rsp+0xE0], xmm15
00007e97133d51e6  sub rsp, 0x30
00007e97133d51ea  movaps [rsp], xmm11
00007e97133d51ef  movaps [rsp+0x10], xmm12
00007e97133d51f5  movaps [rsp+0x20], xmm15
00007e97133d51fb  lea rdi, [rsp]
00007e97133d51ff  mov esi, 0x00
00007e97133d5204  mov rax, 0x58D8AED5F530
00007e97133d520e  call rax
00007e97133d5210  movaps xmm11, [rsp]
00007e97133d5215  add rsp, 0x30
00007e97133d5219  vmovaps xmm0, [rsp]
00007e97133d521e  vmovaps xmm1, [rsp+0x10]
00007e97133d5224  vmovaps xmm2, [rsp+0x20]
00007e97133d522a  vmovaps xmm3, [rsp+0x30]
00007e97133d5230  vmovaps xmm4, [rsp+0x40]
00007e97133d5236  vmovaps xmm5, [rsp+0x50]
00007e97133d523c  vmovaps xmm6, [rsp+0x60]
00007e97133d5242  vmovaps xmm7, [rsp+0x70]
00007e97133d5248  vmovaps xmm8, [rsp+0x80]
00007e97133d5251  vmovaps xmm9, [rsp+0x90]
00007e97133d525a  vmovaps xmm10, [rsp+0xA0]
00007e97133d5263  vmovaps xmm12, [rsp+0xB0]
00007e97133d526c  vmovaps xmm13, [rsp+0xC0]
00007e97133d5275  vmovaps xmm14, [rsp+0xD0]
00007e97133d527e  vmovaps xmm15, [rsp+0xE0]
00007e97133d5287  add rsp, 0xF0
00007e97133d528e  pop r11
00007e97133d5290  pop r10
00007e97133d5292  pop r9
00007e97133d5294  pop r8
00007e97133d5296  pop rsi
00007e97133d5297  pop rdi
00007e97133d5298  pop rdx
00007e97133d5299  pop rcx
00007e97133d529a  pop rax
00007e97133d529b  add rsp, 0x08
00007e97133d529f  jmp 0x00007E97133D02B9
00007e97133d52a4  sub rsp, 0x08
00007e97133d52a8  push rax
00007e97133d52a9  push rcx
00007e97133d52aa  push rdx
00007e97133d52ab  push rdi
00007e97133d52ac  push rsi
00007e97133d52ad  push r8
00007e97133d52af  push r9
00007e97133d52b1  push r10
00007e97133d52b3  push r11
00007e97133d52b5  sub rsp, 0xF0
00007e97133d52bc  vmovaps [rsp], xmm0
00007e97133d52c1  vmovaps [rsp+0x10], xmm1
00007e97133d52c7  vmovaps [rsp+0x20], xmm2
00007e97133d52cd  vmovaps [rsp+0x30], xmm3
00007e97133d52d3  vmovaps [rsp+0x40], xmm4
00007e97133d52d9  vmovaps [rsp+0x50], xmm5
00007e97133d52df  vmovaps [rsp+0x60], xmm6
00007e97133d52e5  vmovaps [rsp+0x70], xmm7
00007e97133d52eb  vmovaps [rsp+0x80], xmm8
00007e97133d52f4  vmovaps [rsp+0x90], xmm9
00007e97133d52fd  vmovaps [rsp+0xA0], xmm10
00007e97133d5306  vmovaps [rsp+0xB0], xmm11
00007e97133d530f  vmovaps [rsp+0xC0], xmm12
00007e97133d5318  vmovaps [rsp+0xD0], xmm13
00007e97133d5321  vmovaps [rsp+0xE0], xmm14
00007e97133d532a  sub rsp, 0x30
00007e97133d532e  movaps [rsp], xmm15
00007e97133d5333  movaps [rsp+0x10], xmm13
00007e97133d5339  movaps [rsp+0x20], xmm9
00007e97133d533f  lea rdi, [rsp]
00007e97133d5343  mov esi, 0x00
00007e97133d5348  mov rax, 0x58D8AED5F530
00007e97133d5352  call rax
00007e97133d5354  movaps xmm15, [rsp]
00007e97133d5359  add rsp, 0x30
00007e97133d535d  vmovaps xmm0, [rsp]
00007e97133d5362  vmovaps xmm1, [rsp+0x10]
00007e97133d5368  vmovaps xmm2, [rsp+0x20]
00007e97133d536e  vmovaps xmm3, [rsp+0x30]
00007e97133d5374  vmovaps xmm4, [rsp+0x40]
00007e97133d537a  vmovaps xmm5, [rsp+0x50]
00007e97133d5380  vmovaps xmm6, [rsp+0x60]
00007e97133d5386  vmovaps xmm7, [rsp+0x70]
00007e97133d538c  vmovaps xmm8, [rsp+0x80]
00007e97133d5395  vmovaps xmm9, [rsp+0x90]
00007e97133d539e  vmovaps xmm10, [rsp+0xA0]
00007e97133d53a7  vmovaps xmm11, [rsp+0xB0]
00007e97133d53b0  vmovaps xmm12, [rsp+0xC0]
00007e97133d53b9  vmovaps xmm13, [rsp+0xD0]
00007e97133d53c2  vmovaps xmm14, [rsp+0xE0]
00007e97133d53cb  add rsp, 0xF0
00007e97133d53d2  pop r11
00007e97133d53d4  pop r10
00007e97133d53d6  pop r9
00007e97133d53d8  pop r8
00007e97133d53da  pop rsi
00007e97133d53db  pop rdi
00007e97133d53dc  pop rdx
00007e97133d53dd  pop rcx
00007e97133d53de  pop rax
00007e97133d53df  add rsp, 0x08
00007e97133d53e3  jmp 0x00007E97133D02D4
00007e97133d53e8  sub rsp, 0x08
00007e97133d53ec  push rax
00007e97133d53ed  push rcx
00007e97133d53ee  push rdx
00007e97133d53ef  push rdi
00007e97133d53f0  push rsi
00007e97133d53f1  push r8
00007e97133d53f3  push r9
00007e97133d53f5  push r10
00007e97133d53f7  push r11
00007e97133d53f9  sub rsp, 0xF0
00007e97133d5400  vmovaps [rsp], xmm0
00007e97133d5405  vmovaps [rsp+0x10], xmm1
00007e97133d540b  vmovaps [rsp+0x20], xmm2
00007e97133d5411  vmovaps [rsp+0x30], xmm3
00007e97133d5417  vmovaps [rsp+0x40], xmm4
00007e97133d541d  vmovaps [rsp+0x50], xmm5
00007e97133d5423  vmovaps [rsp+0x60], xmm6
00007e97133d5429  vmovaps [rsp+0x70], xmm7
00007e97133d542f  vmovaps [rsp+0x80], xmm8
00007e97133d5438  vmovaps [rsp+0x90], xmm9
00007e97133d5441  vmovaps [rsp+0xA0], xmm10
00007e97133d544a  vmovaps [rsp+0xB0], xmm11
00007e97133d5453  vmovaps [rsp+0xC0], xmm12
00007e97133d545c  vmovaps [rsp+0xD0], xmm14
00007e97133d5465  vmovaps [rsp+0xE0], xmm15
00007e97133d546e  sub rsp, 0x30
00007e97133d5472  movaps [rsp], xmm13
00007e97133d5477  movaps [rsp+0x10], xmm8
00007e97133d547d  movaps [rsp+0x20], xmm14
00007e97133d5483  lea rdi, [rsp]
00007e97133d5487  mov esi, 0x00
00007e97133d548c  mov rax, 0x58D8AED5F530
00007e97133d5496  call rax
00007e97133d5498  movaps xmm13, [rsp]
00007e97133d549d  add rsp, 0x30
00007e97133d54a1  vmovaps xmm0, [rsp]
00007e97133d54a6  vmovaps xmm1, [rsp+0x10]
00007e97133d54ac  vmovaps xmm2, [rsp+0x20]
00007e97133d54b2  vmovaps xmm3, [rsp+0x30]
00007e97133d54b8  vmovaps xmm4, [rsp+0x40]
00007e97133d54be  vmovaps xmm5, [rsp+0x50]
00007e97133d54c4  vmovaps xmm6, [rsp+0x60]
00007e97133d54ca  vmovaps xmm7, [rsp+0x70]
00007e97133d54d0  vmovaps xmm8, [rsp+0x80]
00007e97133d54d9  vmovaps xmm9, [rsp+0x90]
00007e97133d54e2  vmovaps xmm10, [rsp+0xA0]
00007e97133d54eb  vmovaps xmm11, [rsp+0xB0]
00007e97133d54f4  vmovaps xmm12, [rsp+0xC0]
00007e97133d54fd  vmovaps xmm14, [rsp+0xD0]
00007e97133d5506  vmovaps xmm15, [rsp+0xE0]
00007e97133d550f  add rsp, 0xF0
00007e97133d5516  pop r11
00007e97133d5518  pop r10
00007e97133d551a  pop r9
00007e97133d551c  pop r8
00007e97133d551e  pop rsi
00007e97133d551f  pop rdi
00007e97133d5520  pop rdx
00007e97133d5521  pop rcx
00007e97133d5522  pop rax
00007e97133d5523  add rsp, 0x08
00007e97133d5527  jmp 0x00007E97133D02F7
00007e97133d552c  sub rsp, 0x08
00007e97133d5530  push rax
00007e97133d5531  push rcx
00007e97133d5532  push rdx
00007e97133d5533  push rdi
00007e97133d5534  push rsi
00007e97133d5535  push r8
00007e97133d5537  push r9
00007e97133d5539  push r10
00007e97133d553b  push r11
00007e97133d553d  sub rsp, 0xF0
00007e97133d5544  vmovaps [rsp], xmm0
00007e97133d5549  vmovaps [rsp+0x10], xmm1
00007e97133d554f  vmovaps [rsp+0x20], xmm2
00007e97133d5555  vmovaps [rsp+0x30], xmm3
00007e97133d555b  vmovaps [rsp+0x40], xmm4
00007e97133d5561  vmovaps [rsp+0x50], xmm5
00007e97133d5567  vmovaps [rsp+0x60], xmm6
00007e97133d556d  vmovaps [rsp+0x70], xmm7
00007e97133d5573  vmovaps [rsp+0x80], xmm8
00007e97133d557c  vmovaps [rsp+0x90], xmm9
00007e97133d5585  vmovaps [rsp+0xA0], xmm10
00007e97133d558e  vmovaps [rsp+0xB0], xmm11
00007e97133d5597  vmovaps [rsp+0xC0], xmm12
00007e97133d55a0  vmovaps [rsp+0xD0], xmm13
00007e97133d55a9  vmovaps [rsp+0xE0], xmm15
00007e97133d55b2  sub rsp, 0x30
00007e97133d55b6  movaps [rsp], xmm14
00007e97133d55bb  movaps [rsp+0x10], xmm1
00007e97133d55c0  movaps [rsp+0x20], xmm10
00007e97133d55c6  lea rdi, [rsp]
00007e97133d55ca  mov esi, 0x00
00007e97133d55cf  mov rax, 0x58D8AED5F530
00007e97133d55d9  call rax
00007e97133d55db  movaps xmm14, [rsp]
00007e97133d55e0  add rsp, 0x30
00007e97133d55e4  vmovaps xmm0, [rsp]
00007e97133d55e9  vmovaps xmm1, [rsp+0x10]
00007e97133d55ef  vmovaps xmm2, [rsp+0x20]
00007e97133d55f5  vmovaps xmm3, [rsp+0x30]
00007e97133d55fb  vmovaps xmm4, [rsp+0x40]
00007e97133d5601  vmovaps xmm5, [rsp+0x50]
00007e97133d5607  vmovaps xmm6, [rsp+0x60]
00007e97133d560d  vmovaps xmm7, [rsp+0x70]
00007e97133d5613  vmovaps xmm8, [rsp+0x80]
00007e97133d561c  vmovaps xmm9, [rsp+0x90]
00007e97133d5625  vmovaps xmm10, [rsp+0xA0]
00007e97133d562e  vmovaps xmm11, [rsp+0xB0]
00007e97133d5637  vmovaps xmm12, [rsp+0xC0]
00007e97133d5640  vmovaps xmm13, [rsp+0xD0]
00007e97133d5649  vmovaps xmm15, [rsp+0xE0]
00007e97133d5652  add rsp, 0xF0
00007e97133d5659  pop r11
00007e97133d565b  pop r10
00007e97133d565d  pop r9
00007e97133d565f  pop r8
00007e97133d5661  pop rsi
00007e97133d5662  pop rdi
00007e97133d5663  pop rdx
00007e97133d5664  pop rcx
00007e97133d5665  pop rax
00007e97133d5666  add rsp, 0x08
00007e97133d566a  jmp 0x00007E97133D031A
00007e97133d566f  sub rsp, 0x08
00007e97133d5673  push rax
00007e97133d5674  push rcx
00007e97133d5675  push rdx
00007e97133d5676  push rdi
00007e97133d5677  push rsi
00007e97133d5678  push r8
00007e97133d567a  push r9
00007e97133d567c  push r10
00007e97133d567e  push r11
00007e97133d5680  sub rsp, 0xF0
00007e97133d5687  vmovaps [rsp], xmm0
00007e97133d568c  vmovaps [rsp+0x10], xmm2
00007e97133d5692  vmovaps [rsp+0x20], xmm3
00007e97133d5698  vmovaps [rsp+0x30], xmm4
00007e97133d569e  vmovaps [rsp+0x40], xmm5
00007e97133d56a4  vmovaps [rsp+0x50], xmm6
00007e97133d56aa  vmovaps [rsp+0x60], xmm7
00007e97133d56b0  vmovaps [rsp+0x70], xmm8
00007e97133d56b6  vmovaps [rsp+0x80], xmm9
00007e97133d56bf  vmovaps [rsp+0x90], xmm10
00007e97133d56c8  vmovaps [rsp+0xA0], xmm11
00007e97133d56d1  vmovaps [rsp+0xB0], xmm12
00007e97133d56da  vmovaps [rsp+0xC0], xmm13
00007e97133d56e3  vmovaps [rsp+0xD0], xmm14
00007e97133d56ec  vmovaps [rsp+0xE0], xmm15
00007e97133d56f5  sub rsp, 0x30
00007e97133d56f9  movaps [rsp], xmm1
00007e97133d56fd  movaps [rsp+0x10], xmm7
00007e97133d5702  movaps [rsp+0x20], xmm11
00007e97133d5708  lea rdi, [rsp]
00007e97133d570c  mov esi, 0x00
00007e97133d5711  mov rax, 0x58D8AED5F530
00007e97133d571b  call rax
00007e97133d571d  movaps xmm1, [rsp]
00007e97133d5721  add rsp, 0x30
00007e97133d5725  vmovaps xmm0, [rsp]
00007e97133d572a  vmovaps xmm2, [rsp+0x10]
00007e97133d5730  vmovaps xmm3, [rsp+0x20]
00007e97133d5736  vmovaps xmm4, [rsp+0x30]
00007e97133d573c  vmovaps xmm5, [rsp+0x40]
00007e97133d5742  vmovaps xmm6, [rsp+0x50]
00007e97133d5748  vmovaps xmm7, [rsp+0x60]
00007e97133d574e  vmovaps xmm8, [rsp+0x70]
00007e97133d5754  vmovaps xmm9, [rsp+0x80]
00007e97133d575d  vmovaps xmm10, [rsp+0x90]
00007e97133d5766  vmovaps xmm11, [rsp+0xA0]
00007e97133d576f  vmovaps xmm12, [rsp+0xB0]
00007e97133d5778  vmovaps xmm13, [rsp+0xC0]
00007e97133d5781  vmovaps xmm14, [rsp+0xD0]
00007e97133d578a  vmovaps xmm15, [rsp+0xE0]
00007e97133d5793  add rsp, 0xF0
00007e97133d579a  pop r11
00007e97133d579c  pop r10
00007e97133d579e  pop r9
00007e97133d57a0  pop r8
00007e97133d57a2  pop rsi
00007e97133d57a3  pop rdi
00007e97133d57a4  pop rdx
00007e97133d57a5  pop rcx
00007e97133d57a6  pop rax
00007e97133d57a7  add rsp, 0x08
00007e97133d57ab  jmp 0x00007E97133D033B
00007e97133d57b0  call 0x00007E971320E880
00007e97133d57b5  jmp 0x00007E97133D034E
00007e97133d57ba  call 0x00007E971320C380
00007e97133d57bf  jmp 0x00007E97133D0359
00007e97133d57c4  call 0x00007E971320D600
00007e97133d57c9  jmp 0x00007E97133D0364
00007e97133d57ce  call 0x00007E97131FF540
00007e97133d57d3  jmp 0x00007E97133D036F
00007e97133d57d8  int3
00007e97133d57d9  nop [rax], eax
00007e97133d57e0  mov rax, [r15+0x40]
00007e97133d57e4  mov r14, [r15+0x58]
00007e97133d57e8  lea r12, [rax+r14*1]
00007e97133d57ec  movaps xmm1, [r15+0x1D0]
00007e97133d57f4  vmovaps [rsp+0x10], xmm1
00007e97133d57fa  vmovaps xmm15, [rsp+0x10]
00007e97133d5800  por xmm1, xmm15
00007e97133d5805  movaps xmm14, [r15+0x1A0]
00007e97133d580d  vmovaps [rsp+0x10], xmm14
00007e97133d5813  vmovaps xmm13, [rsp+0x10]
00007e97133d5819  por xmm14, xmm13
00007e97133d581e  lea rax, [r12+0x30]
00007e97133d5823  mov r11, [r13+rax*1]
00007e97133d5828  lea rax, [r12+0x38]
00007e97133d582d  mov r10, [r13+rax*1]
00007e97133d5832  movq xmm13, r11
00007e97133d5837  movq xmm12, r10
00007e97133d583c  movq xmm13, xmm13
00007e97133d5841  vmovaps [rsp+0x10], xmm13
00007e97133d5847  movq xmm13, xmm13
00007e97133d584c  movaps [r15+0x130], xmm13
00007e97133d5854  movq xmm12, xmm12
00007e97133d5859  vmovaps [rsp+0x20], xmm12
00007e97133d585f  movq xmm12, xmm12
00007e97133d5864  movaps [r15+0x280], xmm12
00007e97133d586c  movaps xmm13, [r15+0x270]
00007e97133d5874  vmovaps [rsp+0x30], xmm13
00007e97133d587a  vmovaps xmm12, [rsp+0x30]
00007e97133d5880  por xmm13, xmm12
00007e97133d5885  lea rax, [r12+0x20]
00007e97133d588a  mov r11, [r13+rax*1]
00007e97133d588f  lea rax, [r12+0x28]
00007e97133d5894  mov r10, [r13+rax*1]
00007e97133d5899  movq xmm12, r11
00007e97133d589e  movq xmm11, r10
00007e97133d58a3  movq xmm12, xmm12
00007e97133d58a8  vmovaps [rsp+0x30], xmm12
00007e97133d58ae  movq xmm12, xmm12
00007e97133d58b3  movaps [r15+0x150], xmm12
00007e97133d58bb  movq xmm11, xmm11
00007e97133d58c0  vmovaps [rsp+0x40], xmm11
00007e97133d58c6  movq xmm11, xmm11
00007e97133d58cb  movaps [r15+0x140], xmm11
00007e97133d58d3  lea rax, [r12+0x10]
00007e97133d58d8  mov r11, [r13+rax*1]
00007e97133d58dd  lea rax, [r12+0x18]
00007e97133d58e2  mov r10, [r13+rax*1]
00007e97133d58e7  movq xmm12, r11
00007e97133d58ec  movq xmm11, r10
00007e97133d58f1  movq xmm12, xmm12
00007e97133d58f6  vmovaps [rsp+0x50], xmm12
00007e97133d58fc  movq xmm12, xmm12
00007e97133d5901  movaps [r15+0x170], xmm12
00007e97133d5909  movq xmm11, xmm11
00007e97133d590e  vmovaps [rsp+0x60], xmm11
00007e97133d5914  movq xmm11, xmm11
00007e97133d5919  movaps [r15+0x160], xmm11
00007e97133d5921  mov rax, [r13+r12*1]
00007e97133d5926  vmovq xmm12, rax
00007e97133d592b  vpbroadcastq xmm12, xmm12
00007e97133d5930  lea rax, [r12+0x08]
00007e97133d5935  mov r12, [r13+rax*1]
00007e97133d593a  movq xmm11, r12
00007e97133d593f  movaps [r15+0x230], xmm11
00007e97133d5947  mov rax, [r15+0xF8]
00007e97133d594e  lea r12, [rax+0x50]
00007e97133d5952  movups xmm11, [r13+r12*1]
00007e97133d5958  lea r12, [rax+0x60]
00007e97133d595c  movups xmm10, [r13+r12*1]
00007e97133d5962  lea r12, [rax+0x30]
00007e97133d5966  movups xmm9, [r13+r12*1]
00007e97133d596c  mov r12, [r15+0x50]
00007e97133d5970  lea r11, [r12+r14*1]
00007e97133d5974  mov [r15+0x60], r11
00007e97133d5978  lea r12, [r14+0x40]
00007e97133d597c  mov [r15+0x58], r12
00007e97133d5980  movaps xmm8, xmm12
00007e97133d5984  mulpd xmm8, xmm15
00007e97133d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007e97133d598f  ptest xmm7, xmm7
00007e97133d5994  jnz 0x00007E97133D67B7
00007e97133d599a  movq xmm15, qword ptr [r15+0x230]
00007e97133d59a3  vmovaps [rsp+0x70], xmm15
00007e97133d59a9  vpermilpd xmm15, xmm15, 0x00
00007e97133d59af  movaps xmm7, xmm9
00007e97133d59b3  mulpd xmm7, xmm15
00007e97133d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007e97133d59bd  ptest xmm6, xmm6
00007e97133d59c2  jnz 0x00007E97133D68FB
00007e97133d59c8  vxorps xmm15, xmm15, xmm15
00007e97133d59cd  vpbroadcastq xmm15, xmm15
00007e97133d59d2  movaps xmm9, xmm12
00007e97133d59d6  mulpd xmm9, xmm10
00007e97133d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007e97133d59e1  ptest xmm6, xmm6
00007e97133d59e6  jnz 0x00007E97133D6A3D
00007e97133d59ec  movaps xmm10, xmm12
00007e97133d59f0  mulpd xmm10, xmm11
00007e97133d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007e97133d59fb  ptest xmm6, xmm6
00007e97133d5a00  jnz 0x00007E97133D6B81
00007e97133d5a06  movaps xmm11, [r15+0x1F0]
00007e97133d5a0e  movaps xmm6, xmm12
00007e97133d5a12  mulpd xmm6, xmm11
00007e97133d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007e97133d5a1c  ptest xmm5, xmm5
00007e97133d5a21  jnz 0x00007E97133D6CC5
00007e97133d5a27  movaps xmm12, [r15+0x2A0]
00007e97133d5a2f  vmovaps [rsp+0x80], xmm12
00007e97133d5a38  vmovaps xmm11, [rsp+0x80]
00007e97133d5a41  por xmm12, xmm11
00007e97133d5a46  movaps xmm11, [r15+0x250]
00007e97133d5a4e  vmovaps [rsp+0x80], xmm11
00007e97133d5a57  vmovaps xmm5, [rsp+0x80]
00007e97133d5a60  por xmm11, xmm5
00007e97133d5a65  vmovaps xmm4, [rsp+0x70]
00007e97133d5a6b  vpermilpd xmm4, xmm4, 0x00
00007e97133d5a71  movaps xmm3, xmm5
00007e97133d5a74  mulpd xmm3, xmm4
00007e97133d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007e97133d5a7d  ptest xmm2, xmm2
00007e97133d5a82  jnz 0x00007E97133D6E07
00007e97133d5a88  mov [rsp+0x80], rax
00007e97133d5a90  xor eax, eax
00007e97133d5a92  mov r14d, 0x200
00007e97133d5a98  cmp r12, r14
00007e97133d5a9b  cmc
00007e97133d5a9c  lahf
00007e97133d5a9d  seto al
00007e97133d5aa0  mov [r15+0x108], eax
00007e97133d5aa7  movaps xmm5, xmm8
00007e97133d5aab  addpd xmm5, xmm15
00007e97133d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007e97133d5ab5  ptest xmm4, xmm4
00007e97133d5aba  jnz 0x00007E97133D6F47
00007e97133d5ac0  movaps xmm8, [r15+0x1B0]
00007e97133d5ac8  movaps xmm4, xmm9
00007e97133d5acc  addpd xmm4, xmm8
00007e97133d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007e97133d5ad6  ptest xmm2, xmm2
00007e97133d5adb  jnz 0x00007E97133D7089
00007e97133d5ae1  movaps xmm9, xmm10
00007e97133d5ae5  addpd xmm9, xmm8
00007e97133d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007e97133d5af0  ptest xmm2, xmm2
00007e97133d5af5  jnz 0x00007E97133D71CB
00007e97133d5afb  movaps xmm10, [r15+0x2F0]
00007e97133d5b03  vmovaps [rsp+0x90], xmm10
00007e97133d5b0c  vmovaps xmm8, [rsp+0x90]
00007e97133d5b15  por xmm10, xmm8
00007e97133d5b1a  movaps xmm8, [r15+0x2E0]
00007e97133d5b22  vmovaps [rsp+0x90], xmm8
00007e97133d5b2b  vmovaps xmm2, [rsp+0x90]
00007e97133d5b34  por xmm8, xmm2
00007e97133d5b39  movaps xmm2, [r15+0x2D0]
00007e97133d5b41  vmovaps [rsp+0x90], xmm2
00007e97133d5b4a  vmovaps [rsp+0xA0], xmm1
00007e97133d5b53  vmovaps xmm1, [rsp+0x90]
00007e97133d5b5c  por xmm2, xmm1
00007e97133d5b60  movaps xmm1, [r15+0x200]
00007e97133d5b68  vmovaps [rsp+0x90], xmm1
00007e97133d5b71  vmovaps [rsp+0xB0], xmm15
00007e97133d5b7a  vmovaps xmm15, [rsp+0x90]
00007e97133d5b83  por xmm1, xmm15
00007e97133d5b88  movaps xmm15, [r15+0x1C0]
00007e97133d5b90  vmovaps [rsp+0x90], xmm15
00007e97133d5b99  vmovaps [rsp+0xC0], xmm1
00007e97133d5ba2  vmovaps xmm1, [rsp+0x90]
00007e97133d5bab  por xmm15, xmm1
00007e97133d5bb0  movaps xmm1, [r15+0x190]
00007e97133d5bb8  vmovaps [rsp+0x90], xmm1
00007e97133d5bc1  vmovaps [rsp+0xD0], xmm15
00007e97133d5bca  vmovaps xmm15, [rsp+0x90]
00007e97133d5bd3  por xmm1, xmm15
00007e97133d5bd8  movaps xmm15, [r15+0x300]
00007e97133d5be0  vmovaps [rsp+0x90], xmm15
00007e97133d5be9  vmovaps [rsp+0xE0], xmm1
00007e97133d5bf2  vmovaps xmm1, [rsp+0x90]
00007e97133d5bfb  por xmm15, xmm1
00007e97133d5c00  mov rax, [rsp+0x80]
00007e97133d5c08  lea r14, [rax+0xA0]
00007e97133d5c0f  movups xmm1, [r13+r14*1]
00007e97133d5c15  lea r14, [rax+0xB0]
00007e97133d5c1c  vmovaps [rsp+0x80], xmm1
00007e97133d5c25  movups xmm1, [r13+r14*1]
00007e97133d5c2b  vmovaps [rsp+0x90], xmm1
00007e97133d5c34  vmovaps [rsp+0xF0], xmm15
00007e97133d5c3d  vmovaps xmm15, [rsp+0xB0]
00007e97133d5c46  vmovaps [rsp+0xB0], xmm14
00007e97133d5c4f  movaps xmm1, xmm6
00007e97133d5c52  addpd xmm1, xmm15
00007e97133d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007e97133d5c5c  ptest xmm14, xmm14
00007e97133d5c62  jnz 0x00007E97133D7323
00007e97133d5c68  lea r14, [rax+0xF0]
00007e97133d5c6f  movups xmm15, [r13+r14*1]
00007e97133d5c75  movaps xmm14, xmm4
00007e97133d5c79  addpd xmm14, xmm3
00007e97133d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007e97133d5c84  ptest xmm6, xmm6
00007e97133d5c89  jnz 0x00007E97133D746E
00007e97133d5c8f  movaps xmm6, xmm9
00007e97133d5c93  addpd xmm6, xmm7
00007e97133d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007e97133d5c9c  ptest xmm4, xmm4
00007e97133d5ca1  jnz 0x00007E97133D75B0
00007e97133d5ca7  vmovaps xmm9, [rsp+0x70]
00007e97133d5cad  vpermilpd xmm9, xmm9, 0x00
00007e97133d5cb3  vmovaps xmm4, [rsp+0x90]
00007e97133d5cbc  movaps xmm7, xmm4
00007e97133d5cbf  mulpd xmm7, xmm9
00007e97133d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007e97133d5cc9  ptest xmm3, xmm3
00007e97133d5cce  jnz 0x00007E97133D76F1
00007e97133d5cd4  vmovaps xmm9, [rsp+0x50]
00007e97133d5cda  vpermilpd xmm9, xmm9, 0x00
00007e97133d5ce0  movaps xmm4, xmm15
00007e97133d5ce4  mulpd xmm4, xmm9
00007e97133d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007e97133d5cee  ptest xmm3, xmm3
00007e97133d5cf3  jnz 0x00007E97133D7832
00007e97133d5cf9  lea r14, [rax+0xE0]
00007e97133d5d00  movups xmm15, [r13+r14*1]
00007e97133d5d06  vmovaps xmm9, [rsp+0x70]
00007e97133d5d0c  vpermilpd xmm9, xmm9, 0x00
00007e97133d5d12  vmovaps [rsp+0x70], xmm1
00007e97133d5d18  vmovaps xmm1, [rsp+0x80]
00007e97133d5d21  vmovaps [rsp+0x80], xmm15
00007e97133d5d2a  movaps xmm3, xmm1
00007e97133d5d2d  mulpd xmm3, xmm9
00007e97133d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007e97133d5d37  ptest xmm15, xmm15
00007e97133d5d3d  jnz 0x00007E97133D797E
00007e97133d5d43  vmovaps xmm1, [rsp+0xF0]
00007e97133d5d4c  vmovaps xmm15, [rsp+0xF0]
00007e97133d5d55  por xmm1, xmm15
00007e97133d5d5a  movaps [r15+0x300], xmm1
00007e97133d5d62  vmovaps xmm15, [rsp+0xE0]
00007e97133d5d6b  vmovaps xmm9, [rsp+0xE0]
00007e97133d5d74  por xmm15, xmm9
00007e97133d5d79  movaps [r15+0x190], xmm15
00007e97133d5d81  vmovaps xmm9, [rsp+0x50]
00007e97133d5d87  vpermilpd xmm9, xmm9, 0x00
00007e97133d5d8d  vmovaps [rsp+0x90], xmm1
00007e97133d5d96  vmovaps [rsp+0xE0], xmm15
00007e97133d5d9f  vmovaps xmm15, [rsp+0x80]
00007e97133d5da8  vmovaps [rsp+0x80], xmm14
00007e97133d5db1  movaps xmm1, xmm15
00007e97133d5db5  mulpd xmm1, xmm9
00007e97133d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007e97133d5dbf  ptest xmm14, xmm14
00007e97133d5dc5  jnz 0x00007E97133D7ABF
00007e97133d5dcb  lea r14, [rax+0x90]
00007e97133d5dd2  movups xmm15, [r13+r14*1]
00007e97133d5dd8  vmovaps xmm14, [rsp+0xD0]
00007e97133d5de1  vmovaps xmm9, [rsp+0xD0]
00007e97133d5dea  por xmm14, xmm9
00007e97133d5def  movaps [r15+0x1C0], xmm14
00007e97133d5df7  vmovaps xmm9, [rsp+0xC0]
00007e97133d5e00  vmovaps [rsp+0xD0], xmm1
00007e97133d5e09  vmovaps xmm1, [rsp+0xC0]
00007e97133d5e12  por xmm9, xmm1
00007e97133d5e17  movaps [r15+0x200], xmm9
00007e97133d5e1f  vmovaps [rsp+0xC0], xmm2
00007e97133d5e28  vmovaps xmm1, [rsp+0xC0]
00007e97133d5e31  por xmm2, xmm1
00007e97133d5e35  movaps [r15+0x2D0], xmm2
00007e97133d5e3d  vmovaps [rsp+0xC0], xmm8
00007e97133d5e46  vmovaps xmm1, [rsp+0xC0]
00007e97133d5e4f  por xmm8, xmm1
00007e97133d5e54  movaps [r15+0x2E0], xmm8
00007e97133d5e5c  vmovaps [rsp+0xC0], xmm15
00007e97133d5e65  movaps xmm1, xmm5
00007e97133d5e68  addpd xmm1, xmm7
00007e97133d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007e97133d5e71  ptest xmm15, xmm15
00007e97133d5e77  jnz 0x00007E97133D7C0B
00007e97133d5e7d  vmovaps xmm15, [rsp+0x50]
00007e97133d5e83  vpermilpd xmm15, xmm15, 0x00
00007e97133d5e89  vmovaps xmm5, [rsp+0xC0]
00007e97133d5e92  vmovaps [rsp+0xC0], xmm1
00007e97133d5e9b  movaps xmm7, xmm5
00007e97133d5e9e  mulpd xmm7, xmm15
00007e97133d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007e97133d5ea8  ptest xmm1, xmm1
00007e97133d5ead  jnz 0x00007E97133D7D4B
00007e97133d5eb3  lea r14, [rax+0x80]
00007e97133d5eba  movups xmm1, [r13+r14*1]
00007e97133d5ec0  vmovaps xmm5, [rsp+0x70]
00007e97133d5ec6  vmovaps [rsp+0x70], xmm1
00007e97133d5ecc  movaps xmm15, xmm5
00007e97133d5ed0  addpd xmm15, xmm3
00007e97133d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007e97133d5edb  ptest xmm1, xmm1
00007e97133d5ee0  jnz 0x00007E97133D7E96
00007e97133d5ee6  vmovaps xmm5, [rsp+0x80]
00007e97133d5eef  movaps xmm1, xmm5
00007e97133d5ef2  addpd xmm1, xmm4
00007e97133d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007e97133d5efb  ptest xmm3, xmm3
00007e97133d5f00  jnz 0x00007E97133D7FD8
00007e97133d5f06  vmovaps [rsp+0x80], xmm10
00007e97133d5f0f  vmovaps xmm5, [rsp+0x80]
00007e97133d5f18  por xmm10, xmm5
00007e97133d5f1d  movaps [r15+0x2F0], xmm10
00007e97133d5f25  vmovaps xmm5, [rsp+0x50]
00007e97133d5f2b  vpermilpd xmm5, xmm5, 0x00
00007e97133d5f31  vmovaps xmm3, [rsp+0x70]
00007e97133d5f37  vmovaps [rsp+0x50], xmm1
00007e97133d5f3d  movaps xmm4, xmm3
00007e97133d5f40  mulpd xmm4, xmm5
00007e97133d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007e97133d5f49  ptest xmm1, xmm1
00007e97133d5f4e  jnz 0x00007E97133D8118
00007e97133d5f54  lea r14, [rax+0xD0]
00007e97133d5f5b  movups xmm1, [r13+r14*1]
00007e97133d5f61  vmovaps xmm3, [rsp+0xD0]
00007e97133d5f6a  vmovaps [rsp+0x70], xmm1
00007e97133d5f70  movaps xmm5, xmm6
00007e97133d5f73  addpd xmm5, xmm3
00007e97133d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007e97133d5f7c  ptest xmm1, xmm1
00007e97133d5f81  jnz 0x00007E97133D8262
00007e97133d5f87  vmovaps xmm1, [rsp+0x60]
00007e97133d5f8d  vpermilpd xmm1, xmm1, 0x00
00007e97133d5f93  movaps xmm6, xmm9
00007e97133d5f97  mulpd xmm6, xmm1
00007e97133d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007e97133d5fa0  ptest xmm3, xmm3
00007e97133d5fa5  jnz 0x00007E97133D83A2
00007e97133d5fab  movaps [r15+0x260], xmm6
00007e97133d5fb3  vxorps xmm1, xmm1, xmm1
00007e97133d5fb7  vpbroadcastq xmm1, xmm1
00007e97133d5fbc  movaps [r15+0x1B0], xmm1
00007e97133d5fc4  vmovaps xmm1, [rsp+0x60]
00007e97133d5fca  vpermilpd xmm1, xmm1, 0x00
00007e97133d5fd0  vmovaps xmm3, [rsp+0x70]
00007e97133d5fd6  vmovaps [rsp+0x70], xmm15
00007e97133d5fdc  movaps xmm9, xmm3
00007e97133d5fe0  mulpd xmm9, xmm1
00007e97133d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007e97133d5feb  ptest xmm15, xmm15
00007e97133d5ff1  jnz 0x00007E97133D84E3
00007e97133d5ff7  lea r14, [rax+0xC0]
00007e97133d5ffe  movups xmm1, [r13+r14*1]
00007e97133d6004  vmovaps xmm3, [rsp+0xC0]
00007e97133d600d  vmovaps [rsp+0x80], xmm1
00007e97133d6016  movaps xmm15, xmm3
00007e97133d601a  addpd xmm15, xmm7
00007e97133d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007e97133d6025  ptest xmm1, xmm1
00007e97133d602a  jnz 0x00007E97133D862F
00007e97133d6030  vmovaps [rsp+0xC0], xmm13
00007e97133d6039  vmovaps xmm1, [rsp+0xC0]
00007e97133d6042  por xmm13, xmm1
00007e97133d6047  movaps [r15+0x270], xmm13
00007e97133d604f  vmovaps xmm1, [rsp+0xB0]
00007e97133d6058  vmovaps xmm7, [rsp+0xB0]
00007e97133d6061  por xmm1, xmm7
00007e97133d6065  movaps [r15+0x1A0], xmm1
00007e97133d606d  vmovaps xmm1, [rsp+0x60]
00007e97133d6073  vpermilpd xmm1, xmm1, 0x00
00007e97133d6079  vmovaps [rsp+0xB0], xmm1
00007e97133d6082  vmovaps xmm1, [rsp+0x80]
00007e97133d608b  vmovaps [rsp+0x80], xmm15
00007e97133d6094  vmovaps xmm15, [rsp+0xB0]
00007e97133d609d  vmovaps [rsp+0xB0], xmm14
00007e97133d60a6  movaps xmm3, xmm1
00007e97133d60a9  mulpd xmm3, xmm15
00007e97133d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007e97133d60b3  ptest xmm14, xmm14
00007e97133d60b9  jnz 0x00007E97133D8771
00007e97133d60bf  lea r14, [rax+0x20]
00007e97133d60c3  movups xmm1, [r13+r14*1]
00007e97133d60c9  movaps [r15+0x110], xmm1
00007e97133d60d1  vmovaps xmm14, [rsp+0x70]
00007e97133d60d7  vmovaps [rsp+0x70], xmm1
00007e97133d60dd  movaps xmm15, xmm14
00007e97133d60e1  addpd xmm15, xmm4
00007e97133d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007e97133d60ec  ptest xmm1, xmm1
00007e97133d60f1  jnz 0x00007E97133D88BC
00007e97133d60f7  vmovaps xmm1, [rsp+0x60]
00007e97133d60fd  vpermilpd xmm1, xmm1, 0x00
00007e97133d6103  movaps xmm14, xmm2
00007e97133d6107  mulpd xmm14, xmm1
00007e97133d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007e97133d6112  ptest xmm4, xmm4
00007e97133d6117  jnz 0x00007E97133D89FF
00007e97133d611d  vmovaps xmm4, [rsp+0x50]
00007e97133d6123  movaps xmm1, xmm4
00007e97133d6126  addpd xmm1, xmm9
00007e97133d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007e97133d6130  ptest xmm2, xmm2
00007e97133d6135  jnz 0x00007E97133D8B41
00007e97133d613b  vmovaps xmm9, [rsp+0x30]
00007e97133d6141  vpermilpd xmm9, xmm9, 0x00
00007e97133d6147  vmovaps xmm2, [rsp+0x70]
00007e97133d614d  vmovaps [rsp+0x50], xmm1
00007e97133d6153  movaps xmm4, xmm2
00007e97133d6156  mulpd xmm4, xmm9
00007e97133d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007e97133d6160  ptest xmm1, xmm1
00007e97133d6165  jnz 0x00007E97133D8C82
00007e97133d616b  vmovaps xmm1, [rsp+0x30]
00007e97133d6171  vpermilpd xmm1, xmm1, 0x00
00007e97133d6177  vmovaps xmm2, [rsp+0x90]
00007e97133d6180  vmovaps [rsp+0x60], xmm15
00007e97133d6186  movaps xmm9, xmm2
00007e97133d618a  mulpd xmm9, xmm1
00007e97133d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007e97133d6195  ptest xmm15, xmm15
00007e97133d619b  jnz 0x00007E97133D8DC3
00007e97133d61a1  vmovaps xmm15, [rsp+0x80]
00007e97133d61aa  movaps xmm1, xmm15
00007e97133d61ae  addpd xmm1, xmm6
00007e97133d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007e97133d61b7  ptest xmm2, xmm2
00007e97133d61bc  jnz 0x00007E97133D8F05
00007e97133d61c2  movaps xmm15, xmm5
00007e97133d61c6  addpd xmm15, xmm3
00007e97133d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007e97133d61d1  ptest xmm6, xmm6
00007e97133d61d6  jnz 0x00007E97133D9046
00007e97133d61dc  vmovaps xmm6, [rsp+0x30]
00007e97133d61e2  vpermilpd xmm6, xmm6, 0x00
00007e97133d61e8  movaps xmm5, xmm8
00007e97133d61ec  mulpd xmm5, xmm6
00007e97133d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007e97133d61f5  ptest xmm3, xmm3
00007e97133d61fa  jnz 0x00007E97133D9188
00007e97133d6200  vmovaps xmm8, [rsp+0x30]
00007e97133d6206  vpermilpd xmm8, xmm8, 0x00
00007e97133d620c  movaps xmm6, xmm10
00007e97133d6210  mulpd xmm6, xmm8
00007e97133d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007e97133d621a  ptest xmm3, xmm3
00007e97133d621f  jnz 0x00007E97133D92C9
00007e97133d6225  vmovaps xmm8, [rsp+0x60]
00007e97133d622b  movaps xmm10, xmm8
00007e97133d622f  addpd xmm10, xmm14
00007e97133d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007e97133d623a  ptest xmm3, xmm3
00007e97133d623f  jnz 0x00007E97133D940B
00007e97133d6245  vmovaps xmm8, [rsp+0x50]
00007e97133d624b  movaps xmm14, xmm8
00007e97133d624f  addpd xmm14, xmm4
00007e97133d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007e97133d625a  ptest xmm3, xmm3
00007e97133d625f  jnz 0x00007E97133D954F
00007e97133d6265  vmovaps xmm8, [rsp+0x40]
00007e97133d626b  vpermilpd xmm8, xmm8, 0x00
00007e97133d6271  movaps xmm4, xmm13
00007e97133d6275  mulpd xmm4, xmm8
00007e97133d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007e97133d627f  ptest xmm3, xmm3
00007e97133d6284  jnz 0x00007E97133D9692
00007e97133d628a  movaps xmm13, xmm15
00007e97133d628e  addpd xmm13, xmm9
00007e97133d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007e97133d6299  ptest xmm8, xmm8
00007e97133d629f  jnz 0x00007E97133D97D4
00007e97133d62a5  movaps xmm15, xmm1
00007e97133d62a9  addpd xmm15, xmm5
00007e97133d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007e97133d62b4  ptest xmm9, xmm9
00007e97133d62ba  jnz 0x00007E97133D9918
00007e97133d62c0  vmovaps [rsp+0x30], xmm11
00007e97133d62c6  vmovaps xmm1, [rsp+0x30]
00007e97133d62cc  por xmm11, xmm1
00007e97133d62d1  movaps [r15+0x250], xmm11
00007e97133d62d9  vmovaps [rsp+0x30], xmm12
00007e97133d62df  vmovaps xmm1, [rsp+0x30]
00007e97133d62e5  por xmm12, xmm1
00007e97133d62ea  movaps [r15+0x2A0], xmm12
00007e97133d62f2  vmovaps xmm1, [rsp+0xA0]
00007e97133d62fb  vmovaps xmm11, [rsp+0xA0]
00007e97133d6304  por xmm1, xmm11
00007e97133d6309  movaps [r15+0x1D0], xmm1
00007e97133d6311  lea r14, [rax+0x40]
00007e97133d6315  movups xmm1, [r13+r14*1]
00007e97133d631b  movaps [r15+0x2C0], xmm1
00007e97133d6323  vmovaps xmm11, [rsp+0x40]
00007e97133d6329  vpermilpd xmm11, xmm11, 0x00
00007e97133d632f  vmovaps xmm8, [rsp+0xE0]
00007e97133d6338  movaps xmm9, xmm8
00007e97133d633c  mulpd xmm9, xmm11
00007e97133d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007e97133d6347  ptest xmm5, xmm5
00007e97133d634c  jnz 0x00007E97133D9A64
00007e97133d6352  movaps xmm11, xmm10
00007e97133d6356  addpd xmm11, xmm6
00007e97133d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007e97133d6361  ptest xmm8, xmm8
00007e97133d6367  jnz 0x00007E97133D9BA8
00007e97133d636d  movaps xmm10, xmm14
00007e97133d6371  addpd xmm10, xmm4
00007e97133d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007e97133d637c  ptest xmm8, xmm8
00007e97133d6382  jnz 0x00007E97133D9CEB
00007e97133d6388  vmovaps xmm14, [rsp+0x40]
00007e97133d638e  vpermilpd xmm14, xmm14, 0x00
00007e97133d6394  movaps xmm8, xmm1
00007e97133d6398  mulpd xmm8, xmm14
00007e97133d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007e97133d63a3  ptest xmm6, xmm6
00007e97133d63a8  jnz 0x00007E97133D9E2E
00007e97133d63ae  movaps xmm1, [r15+0x2B0]
00007e97133d63b6  vmovaps xmm14, [rsp+0x40]
00007e97133d63bc  vpermilpd xmm14, xmm14, 0x00
00007e97133d63c2  movaps xmm6, xmm1
00007e97133d63c5  mulpd xmm6, xmm14
00007e97133d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007e97133d63cf  ptest xmm5, xmm5
00007e97133d63d4  jnz 0x00007E97133D9F71
00007e97133d63da  vmovaps xmm1, [rsp+0x10]
00007e97133d63e0  vpermilpd xmm1, xmm1, 0x00
00007e97133d63e6  movaps xmm14, xmm12
00007e97133d63ea  mulpd xmm14, xmm1
00007e97133d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007e97133d63f5  ptest xmm5, xmm5
00007e97133d63fa  jnz 0x00007E97133DA0B2
00007e97133d6400  movaps xmm1, xmm13
00007e97133d6404  addpd xmm1, xmm9
00007e97133d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007e97133d640e  ptest xmm12, xmm12
00007e97133d6414  jnz 0x00007E97133DA1F5
00007e97133d641a  vmovaps xmm13, [rsp+0x10]
00007e97133d6420  vpermilpd xmm13, xmm13, 0x00
00007e97133d6426  movaps xmm12, xmm7
00007e97133d642a  mulpd xmm12, xmm13
00007e97133d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007e97133d6435  ptest xmm9, xmm9
00007e97133d643b  jnz 0x00007E97133DA337
00007e97133d6441  movaps xmm13, xmm15
00007e97133d6445  addpd xmm13, xmm8
00007e97133d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007e97133d6450  ptest xmm9, xmm9
00007e97133d6456  jnz 0x00007E97133DA47A
00007e97133d645c  movaps xmm15, [r15+0x290]
00007e97133d6464  vmovaps xmm9, [rsp+0x10]
00007e97133d646a  vpermilpd xmm9, xmm9, 0x00
00007e97133d6470  movaps xmm8, xmm15
00007e97133d6474  mulpd xmm8, xmm9
00007e97133d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007e97133d647f  ptest xmm7, xmm7
00007e97133d6484  jnz 0x00007E97133DA5BE
00007e97133d648a  movaps xmm15, xmm11
00007e97133d648e  addpd xmm15, xmm6
00007e97133d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007e97133d6499  ptest xmm9, xmm9
00007e97133d649f  jnz 0x00007E97133DA702
00007e97133d64a5  movaps xmm11, [r15+0x1E0]
00007e97133d64ad  vmovaps xmm9, [rsp+0x10]
00007e97133d64b3  vpermilpd xmm9, xmm9, 0x00
00007e97133d64b9  movaps xmm7, xmm11
00007e97133d64bd  mulpd xmm7, xmm9
00007e97133d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007e97133d64c7  ptest xmm6, xmm6
00007e97133d64cc  jnz 0x00007E97133DA845
00007e97133d64d2  movaps xmm11, xmm10
00007e97133d64d6  addpd xmm11, xmm14
00007e97133d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007e97133d64e1  ptest xmm9, xmm9
00007e97133d64e7  jnz 0x00007E97133DA987
00007e97133d64ed  lea r14, [rax+0x70]
00007e97133d64f1  movups xmm14, [r13+r14*1]
00007e97133d64f7  movaps [r15+0x240], xmm14
00007e97133d64ff  movaps xmm10, xmm1
00007e97133d6503  addpd xmm10, xmm12
00007e97133d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007e97133d650e  ptest xmm9, xmm9
00007e97133d6514  jnz 0x00007E97133DAAD5
00007e97133d651a  movaps [r15+0x170], xmm10
00007e97133d6522  vmovaps xmm1, [rsp+0x20]
00007e97133d6528  vpermilpd xmm1, xmm1, 0x00
00007e97133d652e  movaps xmm12, xmm14
00007e97133d6532  mulpd xmm12, xmm1
00007e97133d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007e97133d653d  ptest xmm9, xmm9
00007e97133d6543  jnz 0x00007E97133DAC18
00007e97133d6549  vmovaps xmm1, [rsp+0x20]
00007e97133d654f  vpermilpd xmm1, xmm1, 0x00
00007e97133d6555  vmovaps xmm9, [rsp+0xB0]
00007e97133d655e  movaps xmm14, xmm9
00007e97133d6562  mulpd xmm14, xmm1
00007e97133d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007e97133d656d  ptest xmm6, xmm6
00007e97133d6572  jnz 0x00007E97133DAD5B
00007e97133d6578  movaps [r15+0x180], xmm14
00007e97133d6580  movaps xmm1, xmm13
00007e97133d6584  addpd xmm1, xmm8
00007e97133d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007e97133d658e  ptest xmm9, xmm9
00007e97133d6594  jnz 0x00007E97133DAE9E
00007e97133d659a  movaps [r15+0x210], xmm1
00007e97133d65a2  movups xmm13, [r13+rax*1]
00007e97133d65a8  lea r14, [rax+0x10]
00007e97133d65ac  movups xmm9, [r13+r14*1]
00007e97133d65b2  movaps [r15+0x230], xmm9
00007e97133d65ba  movaps xmm8, xmm15
00007e97133d65be  addpd xmm8, xmm7
00007e97133d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007e97133d65c9  ptest xmm6, xmm6
00007e97133d65ce  jnz 0x00007E97133DAFF4
00007e97133d65d4  movaps [r15+0x130], xmm8
00007e97133d65dc  vmovaps xmm15, [rsp+0x20]
00007e97133d65e2  vpermilpd xmm15, xmm15, 0x00
00007e97133d65e8  movaps xmm7, xmm9
00007e97133d65ec  mulpd xmm7, xmm15
00007e97133d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007e97133d65f6  ptest xmm6, xmm6
00007e97133d65fb  jnz 0x00007E97133DB137
00007e97133d6601  movaps [r15+0x220], xmm7
00007e97133d6609  vmovaps xmm15, [rsp+0x20]
00007e97133d660f  vpermilpd xmm15, xmm15, 0x00
00007e97133d6615  movaps xmm9, xmm13
00007e97133d6619  mulpd xmm9, xmm15
00007e97133d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007e97133d6624  ptest xmm6, xmm6
00007e97133d6629  jnz 0x00007E97133DB279
00007e97133d662f  movaps xmm15, xmm11
00007e97133d6633  addpd xmm15, xmm12
00007e97133d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007e97133d663e  ptest xmm13, xmm13
00007e97133d6644  jnz 0x00007E97133DB3BD
00007e97133d664a  movaps [r15+0x140], xmm15
00007e97133d6652  movaps xmm13, xmm10
00007e97133d6656  addpd xmm13, xmm14
00007e97133d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007e97133d6661  ptest xmm12, xmm12
00007e97133d6667  jnz 0x00007E97133DB501
00007e97133d666d  movaps [r15+0x150], xmm13
00007e97133d6675  movaps xmm14, xmm1
00007e97133d6679  addpd xmm14, xmm7
00007e97133d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007e97133d6684  ptest xmm12, xmm12
00007e97133d668a  jnz 0x00007E97133DB645
00007e97133d6690  movaps [r15+0x160], xmm14
00007e97133d6698  movaps xmm1, xmm8
00007e97133d669c  addpd xmm1, xmm9
00007e97133d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007e97133d66a6  ptest xmm12, xmm12
00007e97133d66ac  jnz 0x00007E97133DB787
00007e97133d66b2  movaps [r15+0x120], xmm1
00007e97133d66ba  movups [r13+r11*1], xmm15
00007e97133d66c0  lea rax, [r11+0x10]
00007e97133d66c4  movups [r13+rax*1], xmm13
00007e97133d66ca  lea rax, [r11+0x20]
00007e97133d66ce  movups [r13+rax*1], xmm14
00007e97133d66d4  lea rax, [r11+0x30]
00007e97133d66d8  movups [r13+rax*1], xmm1
00007e97133d66de  mov eax, [r15+0x108]
00007e97133d66e5  sahf
00007e97133d66e6  jnz 0x00007E97133D6718
00007e97133d66e8  cmp dword ptr [r15+0x318], 0x00
00007e97133d66f0  jz 0x00007E97133DB900
00007e97133d66f6  nop [rax+rax*1], ax
00007e97133d66ff  nop [rax+rax*1], eax
00007e97133d6707  mov eax, 0x410444
00007e97133d670c  mov [r15+0x100], rax
00007e97133d6713  jmp 0x00007E97131FE110
00007e97133d6718  cmp dword ptr [r15+0x318], 0x00
00007e97133d6720  jz 0x00007E97133D57E0
00007e97133d6726  nop [rax+rax*1], ax
00007e97133d672f  nop [rax+rax*1], eax
00007e97133d6737  mov eax, 0x410278
00007e97133d673c  mov [r15+0x100], rax
00007e97133d6743  jmp 0x00007E97131FE110
00007e97133d6748  int3
00007e97133d6749  call 0x00007E971320A4B0
00007e97133d674e  jmp 0x00007E97133D5828
00007e97133d6753  call 0x00007E9713209240
00007e97133d6758  jmp 0x00007E97133D5832
00007e97133d675d  call 0x00007E971320A4B0
00007e97133d6762  jmp 0x00007E97133D588F
00007e97133d6767  call 0x00007E9713209240
00007e97133d676c  jmp 0x00007E97133D5899
00007e97133d6771  call 0x00007E971320A4B0
00007e97133d6776  jmp 0x00007E97133D58DD
00007e97133d677b  call 0x00007E9713209240
00007e97133d6780  jmp 0x00007E97133D58E7
00007e97133d6785  call 0x00007E97132B47C0
00007e97133d678a  jmp 0x00007E97133D5926
00007e97133d678f  call 0x00007E971320B720
00007e97133d6794  jmp 0x00007E97133D593A
00007e97133d6799  call 0x00007E97132BFC30
00007e97133d679e  jmp 0x00007E97133D5958
00007e97133d67a3  call 0x00007E97132BE9C0
00007e97133d67a8  jmp 0x00007E97133D5962
00007e97133d67ad  call 0x00007E97132BD750
00007e97133d67b2  jmp 0x00007E97133D596C
00007e97133d67b7  sub rsp, 0x08
00007e97133d67bb  push rax
00007e97133d67bc  push rcx
00007e97133d67bd  push rdx
00007e97133d67be  push rdi
00007e97133d67bf  push rsi
00007e97133d67c0  push r8
00007e97133d67c2  push r9
00007e97133d67c4  push r10
00007e97133d67c6  push r11
00007e97133d67c8  sub rsp, 0xF0
00007e97133d67cf  vmovaps [rsp], xmm0
00007e97133d67d4  vmovaps [rsp+0x10], xmm1
00007e97133d67da  vmovaps [rsp+0x20], xmm2
00007e97133d67e0  vmovaps [rsp+0x30], xmm3
00007e97133d67e6  vmovaps [rsp+0x40], xmm4
00007e97133d67ec  vmovaps [rsp+0x50], xmm5
00007e97133d67f2  vmovaps [rsp+0x60], xmm6
00007e97133d67f8  vmovaps [rsp+0x70], xmm7
00007e97133d67fe  vmovaps [rsp+0x80], xmm9
00007e97133d6807  vmovaps [rsp+0x90], xmm10
00007e97133d6810  vmovaps [rsp+0xA0], xmm11
00007e97133d6819  vmovaps [rsp+0xB0], xmm12
00007e97133d6822  vmovaps [rsp+0xC0], xmm13
00007e97133d682b  vmovaps [rsp+0xD0], xmm14
00007e97133d6834  vmovaps [rsp+0xE0], xmm15
00007e97133d683d  sub rsp, 0x30
00007e97133d6841  movaps [rsp], xmm8
00007e97133d6846  movaps [rsp+0x10], xmm12
00007e97133d684c  movaps [rsp+0x20], xmm15
00007e97133d6852  lea rdi, [rsp]
00007e97133d6856  mov esi, 0x00
00007e97133d685b  mov rax, 0x58D8AED5F530
00007e97133d6865  call rax
00007e97133d6867  movaps xmm8, [rsp]
00007e97133d686c  add rsp, 0x30
00007e97133d6870  vmovaps xmm0, [rsp]
00007e97133d6875  vmovaps xmm1, [rsp+0x10]
00007e97133d687b  vmovaps xmm2, [rsp+0x20]
00007e97133d6881  vmovaps xmm3, [rsp+0x30]
00007e97133d6887  vmovaps xmm4, [rsp+0x40]
00007e97133d688d  vmovaps xmm5, [rsp+0x50]
00007e97133d6893  vmovaps xmm6, [rsp+0x60]
00007e97133d6899  vmovaps xmm7, [rsp+0x70]
00007e97133d689f  vmovaps xmm9, [rsp+0x80]
00007e97133d68a8  vmovaps xmm10, [rsp+0x90]
00007e97133d68b1  vmovaps xmm11, [rsp+0xA0]
00007e97133d68ba  vmovaps xmm12, [rsp+0xB0]
00007e97133d68c3  vmovaps xmm13, [rsp+0xC0]
00007e97133d68cc  vmovaps xmm14, [rsp+0xD0]
00007e97133d68d5  vmovaps xmm15, [rsp+0xE0]
00007e97133d68de  add rsp, 0xF0
00007e97133d68e5  pop r11
00007e97133d68e7  pop r10
00007e97133d68e9  pop r9
00007e97133d68eb  pop r8
00007e97133d68ed  pop rsi
00007e97133d68ee  pop rdi
00007e97133d68ef  pop rdx
00007e97133d68f0  pop rcx
00007e97133d68f1  pop rax
00007e97133d68f2  add rsp, 0x08
00007e97133d68f6  jmp 0x00007E97133D599A
00007e97133d68fb  sub rsp, 0x08
00007e97133d68ff  push rax
00007e97133d6900  push rcx
00007e97133d6901  push rdx
00007e97133d6902  push rdi
00007e97133d6903  push rsi
00007e97133d6904  push r8
00007e97133d6906  push r9
00007e97133d6908  push r10
00007e97133d690a  push r11
00007e97133d690c  sub rsp, 0xF0
00007e97133d6913  vmovaps [rsp], xmm0
00007e97133d6918  vmovaps [rsp+0x10], xmm1
00007e97133d691e  vmovaps [rsp+0x20], xmm2
00007e97133d6924  vmovaps [rsp+0x30], xmm3
00007e97133d692a  vmovaps [rsp+0x40], xmm4
00007e97133d6930  vmovaps [rsp+0x50], xmm5
00007e97133d6936  vmovaps [rsp+0x60], xmm6
00007e97133d693c  vmovaps [rsp+0x70], xmm8
00007e97133d6942  vmovaps [rsp+0x80], xmm9
00007e97133d694b  vmovaps [rsp+0x90], xmm10
00007e97133d6954  vmovaps [rsp+0xA0], xmm11
00007e97133d695d  vmovaps [rsp+0xB0], xmm12
00007e97133d6966  vmovaps [rsp+0xC0], xmm13
00007e97133d696f  vmovaps [rsp+0xD0], xmm14
00007e97133d6978  vmovaps [rsp+0xE0], xmm15
00007e97133d6981  sub rsp, 0x30
00007e97133d6985  movaps [rsp], xmm7
00007e97133d6989  movaps [rsp+0x10], xmm9
00007e97133d698f  movaps [rsp+0x20], xmm15
00007e97133d6995  lea rdi, [rsp]
00007e97133d6999  mov esi, 0x00
00007e97133d699e  mov rax, 0x58D8AED5F530
00007e97133d69a8  call rax
00007e97133d69aa  movaps xmm7, [rsp]
00007e97133d69ae  add rsp, 0x30
00007e97133d69b2  vmovaps xmm0, [rsp]
00007e97133d69b7  vmovaps xmm1, [rsp+0x10]
00007e97133d69bd  vmovaps xmm2, [rsp+0x20]
00007e97133d69c3  vmovaps xmm3, [rsp+0x30]
00007e97133d69c9  vmovaps xmm4, [rsp+0x40]
00007e97133d69cf  vmovaps xmm5, [rsp+0x50]
00007e97133d69d5  vmovaps xmm6, [rsp+0x60]
00007e97133d69db  vmovaps xmm8, [rsp+0x70]
00007e97133d69e1  vmovaps xmm9, [rsp+0x80]
00007e97133d69ea  vmovaps xmm10, [rsp+0x90]
00007e97133d69f3  vmovaps xmm11, [rsp+0xA0]
00007e97133d69fc  vmovaps xmm12, [rsp+0xB0]
00007e97133d6a05  vmovaps xmm13, [rsp+0xC0]
00007e97133d6a0e  vmovaps xmm14, [rsp+0xD0]
00007e97133d6a17  vmovaps xmm15, [rsp+0xE0]
00007e97133d6a20  add rsp, 0xF0
00007e97133d6a27  pop r11
00007e97133d6a29  pop r10
00007e97133d6a2b  pop r9
00007e97133d6a2d  pop r8
00007e97133d6a2f  pop rsi
00007e97133d6a30  pop rdi
00007e97133d6a31  pop rdx
00007e97133d6a32  pop rcx
00007e97133d6a33  pop rax
00007e97133d6a34  add rsp, 0x08
00007e97133d6a38  jmp 0x00007E97133D59C8
00007e97133d6a3d  sub rsp, 0x08
00007e97133d6a41  push rax
00007e97133d6a42  push rcx
00007e97133d6a43  push rdx
00007e97133d6a44  push rdi
00007e97133d6a45  push rsi
00007e97133d6a46  push r8
00007e97133d6a48  push r9
00007e97133d6a4a  push r10
00007e97133d6a4c  push r11
00007e97133d6a4e  sub rsp, 0xF0
00007e97133d6a55  vmovaps [rsp], xmm0
00007e97133d6a5a  vmovaps [rsp+0x10], xmm1
00007e97133d6a60  vmovaps [rsp+0x20], xmm2
00007e97133d6a66  vmovaps [rsp+0x30], xmm3
00007e97133d6a6c  vmovaps [rsp+0x40], xmm4
00007e97133d6a72  vmovaps [rsp+0x50], xmm5
00007e97133d6a78  vmovaps [rsp+0x60], xmm6
00007e97133d6a7e  vmovaps [rsp+0x70], xmm7
00007e97133d6a84  vmovaps [rsp+0x80], xmm8
00007e97133d6a8d  vmovaps [rsp+0x90], xmm10
00007e97133d6a96  vmovaps [rsp+0xA0], xmm11
00007e97133d6a9f  vmovaps [rsp+0xB0], xmm12
00007e97133d6aa8  vmovaps [rsp+0xC0], xmm13
00007e97133d6ab1  vmovaps [rsp+0xD0], xmm14
00007e97133d6aba  vmovaps [rsp+0xE0], xmm15
00007e97133d6ac3  sub rsp, 0x30
00007e97133d6ac7  movaps [rsp], xmm9
00007e97133d6acc  movaps [rsp+0x10], xmm12
00007e97133d6ad2  movaps [rsp+0x20], xmm10
00007e97133d6ad8  lea rdi, [rsp]
00007e97133d6adc  mov esi, 0x00
00007e97133d6ae1  mov rax, 0x58D8AED5F530
00007e97133d6aeb  call rax
00007e97133d6aed  movaps xmm9, [rsp]
00007e97133d6af2  add rsp, 0x30
00007e97133d6af6  vmovaps xmm0, [rsp]
00007e97133d6afb  vmovaps xmm1, [rsp+0x10]
00007e97133d6b01  vmovaps xmm2, [rsp+0x20]
00007e97133d6b07  vmovaps xmm3, [rsp+0x30]
00007e97133d6b0d  vmovaps xmm4, [rsp+0x40]
00007e97133d6b13  vmovaps xmm5, [rsp+0x50]
00007e97133d6b19  vmovaps xmm6, [rsp+0x60]
00007e97133d6b1f  vmovaps xmm7, [rsp+0x70]
00007e97133d6b25  vmovaps xmm8, [rsp+0x80]
00007e97133d6b2e  vmovaps xmm10, [rsp+0x90]
00007e97133d6b37  vmovaps xmm11, [rsp+0xA0]
00007e97133d6b40  vmovaps xmm12, [rsp+0xB0]
00007e97133d6b49  vmovaps xmm13, [rsp+0xC0]
00007e97133d6b52  vmovaps xmm14, [rsp+0xD0]
00007e97133d6b5b  vmovaps xmm15, [rsp+0xE0]
00007e97133d6b64  add rsp, 0xF0
00007e97133d6b6b  pop r11
00007e97133d6b6d  pop r10
00007e97133d6b6f  pop r9
00007e97133d6b71  pop r8
00007e97133d6b73  pop rsi
00007e97133d6b74  pop rdi
00007e97133d6b75  pop rdx
00007e97133d6b76  pop rcx
00007e97133d6b77  pop rax
00007e97133d6b78  add rsp, 0x08
00007e97133d6b7c  jmp 0x00007E97133D59EC
00007e97133d6b81  sub rsp, 0x08
00007e97133d6b85  push rax
00007e97133d6b86  push rcx
00007e97133d6b87  push rdx
00007e97133d6b88  push rdi
00007e97133d6b89  push rsi
00007e97133d6b8a  push r8
00007e97133d6b8c  push r9
00007e97133d6b8e  push r10
00007e97133d6b90  push r11
00007e97133d6b92  sub rsp, 0xF0
00007e97133d6b99  vmovaps [rsp], xmm0
00007e97133d6b9e  vmovaps [rsp+0x10], xmm1
00007e97133d6ba4  vmovaps [rsp+0x20], xmm2
00007e97133d6baa  vmovaps [rsp+0x30], xmm3
00007e97133d6bb0  vmovaps [rsp+0x40], xmm4
00007e97133d6bb6  vmovaps [rsp+0x50], xmm5
00007e97133d6bbc  vmovaps [rsp+0x60], xmm6
00007e97133d6bc2  vmovaps [rsp+0x70], xmm7
00007e97133d6bc8  vmovaps [rsp+0x80], xmm8
00007e97133d6bd1  vmovaps [rsp+0x90], xmm9
00007e97133d6bda  vmovaps [rsp+0xA0], xmm11
00007e97133d6be3  vmovaps [rsp+0xB0], xmm12
00007e97133d6bec  vmovaps [rsp+0xC0], xmm13
00007e97133d6bf5  vmovaps [rsp+0xD0], xmm14
00007e97133d6bfe  vmovaps [rsp+0xE0], xmm15
00007e97133d6c07  sub rsp, 0x30
00007e97133d6c0b  movaps [rsp], xmm10
00007e97133d6c10  movaps [rsp+0x10], xmm12
00007e97133d6c16  movaps [rsp+0x20], xmm11
00007e97133d6c1c  lea rdi, [rsp]
00007e97133d6c20  mov esi, 0x00
00007e97133d6c25  mov rax, 0x58D8AED5F530
00007e97133d6c2f  call rax
00007e97133d6c31  movaps xmm10, [rsp]
00007e97133d6c36  add rsp, 0x30
00007e97133d6c3a  vmovaps xmm0, [rsp]
00007e97133d6c3f  vmovaps xmm1, [rsp+0x10]
00007e97133d6c45  vmovaps xmm2, [rsp+0x20]
00007e97133d6c4b  vmovaps xmm3, [rsp+0x30]
00007e97133d6c51  vmovaps xmm4, [rsp+0x40]
00007e97133d6c57  vmovaps xmm5, [rsp+0x50]
00007e97133d6c5d  vmovaps xmm6, [rsp+0x60]
00007e97133d6c63  vmovaps xmm7, [rsp+0x70]
00007e97133d6c69  vmovaps xmm8, [rsp+0x80]
00007e97133d6c72  vmovaps xmm9, [rsp+0x90]
00007e97133d6c7b  vmovaps xmm11, [rsp+0xA0]
00007e97133d6c84  vmovaps xmm12, [rsp+0xB0]
00007e97133d6c8d  vmovaps xmm13, [rsp+0xC0]
00007e97133d6c96  vmovaps xmm14, [rsp+0xD0]
00007e97133d6c9f  vmovaps xmm15, [rsp+0xE0]
00007e97133d6ca8  add rsp, 0xF0
00007e97133d6caf  pop r11
00007e97133d6cb1  pop r10
00007e97133d6cb3  pop r9
00007e97133d6cb5  pop r8
00007e97133d6cb7  pop rsi
00007e97133d6cb8  pop rdi
00007e97133d6cb9  pop rdx
00007e97133d6cba  pop rcx
00007e97133d6cbb  pop rax
00007e97133d6cbc  add rsp, 0x08
00007e97133d6cc0  jmp 0x00007E97133D5A06
00007e97133d6cc5  sub rsp, 0x08
00007e97133d6cc9  push rax
00007e97133d6cca  push rcx
00007e97133d6ccb  push rdx
00007e97133d6ccc  push rdi
00007e97133d6ccd  push rsi
00007e97133d6cce  push r8
00007e97133d6cd0  push r9
00007e97133d6cd2  push r10
00007e97133d6cd4  push r11
00007e97133d6cd6  sub rsp, 0xF0
00007e97133d6cdd  vmovaps [rsp], xmm0
00007e97133d6ce2  vmovaps [rsp+0x10], xmm1
00007e97133d6ce8  vmovaps [rsp+0x20], xmm2
00007e97133d6cee  vmovaps [rsp+0x30], xmm3
00007e97133d6cf4  vmovaps [rsp+0x40], xmm4
00007e97133d6cfa  vmovaps [rsp+0x50], xmm5
00007e97133d6d00  vmovaps [rsp+0x60], xmm7
00007e97133d6d06  vmovaps [rsp+0x70], xmm8
00007e97133d6d0c  vmovaps [rsp+0x80], xmm9
00007e97133d6d15  vmovaps [rsp+0x90], xmm10
00007e97133d6d1e  vmovaps [rsp+0xA0], xmm11
00007e97133d6d27  vmovaps [rsp+0xB0], xmm12
00007e97133d6d30  vmovaps [rsp+0xC0], xmm13
00007e97133d6d39  vmovaps [rsp+0xD0], xmm14
00007e97133d6d42  vmovaps [rsp+0xE0], xmm15
00007e97133d6d4b  sub rsp, 0x30
00007e97133d6d4f  movaps [rsp], xmm6
00007e97133d6d53  movaps [rsp+0x10], xmm12
00007e97133d6d59  movaps [rsp+0x20], xmm11
00007e97133d6d5f  lea rdi, [rsp]
00007e97133d6d63  mov esi, 0x00
00007e97133d6d68  mov rax, 0x58D8AED5F530
00007e97133d6d72  call rax
00007e97133d6d74  movaps xmm6, [rsp]
00007e97133d6d78  add rsp, 0x30
00007e97133d6d7c  vmovaps xmm0, [rsp]
00007e97133d6d81  vmovaps xmm1, [rsp+0x10]
00007e97133d6d87  vmovaps xmm2, [rsp+0x20]
00007e97133d6d8d  vmovaps xmm3, [rsp+0x30]
00007e97133d6d93  vmovaps xmm4, [rsp+0x40]
00007e97133d6d99  vmovaps xmm5, [rsp+0x50]
00007e97133d6d9f  vmovaps xmm7, [rsp+0x60]
00007e97133d6da5  vmovaps xmm8, [rsp+0x70]
00007e97133d6dab  vmovaps xmm9, [rsp+0x80]
00007e97133d6db4  vmovaps xmm10, [rsp+0x90]
00007e97133d6dbd  vmovaps xmm11, [rsp+0xA0]
00007e97133d6dc6  vmovaps xmm12, [rsp+0xB0]
00007e97133d6dcf  vmovaps xmm13, [rsp+0xC0]
00007e97133d6dd8  vmovaps xmm14, [rsp+0xD0]
00007e97133d6de1  vmovaps xmm15, [rsp+0xE0]
00007e97133d6dea  add rsp, 0xF0
00007e97133d6df1  pop r11
00007e97133d6df3  pop r10
00007e97133d6df5  pop r9
00007e97133d6df7  pop r8
00007e97133d6df9  pop rsi
00007e97133d6dfa  pop rdi
00007e97133d6dfb  pop rdx
00007e97133d6dfc  pop rcx
00007e97133d6dfd  pop rax
00007e97133d6dfe  add rsp, 0x08
00007e97133d6e02  jmp 0x00007E97133D5A27
00007e97133d6e07  sub rsp, 0x08
00007e97133d6e0b  push rax
00007e97133d6e0c  push rcx
00007e97133d6e0d  push rdx
00007e97133d6e0e  push rdi
00007e97133d6e0f  push rsi
00007e97133d6e10  push r8
00007e97133d6e12  push r9
00007e97133d6e14  push r10
00007e97133d6e16  push r11
00007e97133d6e18  sub rsp, 0xF0
00007e97133d6e1f  vmovaps [rsp], xmm0
00007e97133d6e24  vmovaps [rsp+0x10], xmm1
00007e97133d6e2a  vmovaps [rsp+0x20], xmm2
00007e97133d6e30  vmovaps [rsp+0x30], xmm4
00007e97133d6e36  vmovaps [rsp+0x40], xmm5
00007e97133d6e3c  vmovaps [rsp+0x50], xmm6
00007e97133d6e42  vmovaps [rsp+0x60], xmm7
00007e97133d6e48  vmovaps [rsp+0x70], xmm8
00007e97133d6e4e  vmovaps [rsp+0x80], xmm9
00007e97133d6e57  vmovaps [rsp+0x90], xmm10
00007e97133d6e60  vmovaps [rsp+0xA0], xmm11
00007e97133d6e69  vmovaps [rsp+0xB0], xmm12
00007e97133d6e72  vmovaps [rsp+0xC0], xmm13
00007e97133d6e7b  vmovaps [rsp+0xD0], xmm14
00007e97133d6e84  vmovaps [rsp+0xE0], xmm15
00007e97133d6e8d  sub rsp, 0x30
00007e97133d6e91  movaps [rsp], xmm3
00007e97133d6e95  movaps [rsp+0x10], xmm5
00007e97133d6e9a  movaps [rsp+0x20], xmm4
00007e97133d6e9f  lea rdi, [rsp]
00007e97133d6ea3  mov esi, 0x00
00007e97133d6ea8  mov rax, 0x58D8AED5F530
00007e97133d6eb2  call rax
00007e97133d6eb4  movaps xmm3, [rsp]
00007e97133d6eb8  add rsp, 0x30
00007e97133d6ebc  vmovaps xmm0, [rsp]
00007e97133d6ec1  vmovaps xmm1, [rsp+0x10]
00007e97133d6ec7  vmovaps xmm2, [rsp+0x20]
00007e97133d6ecd  vmovaps xmm4, [rsp+0x30]
00007e97133d6ed3  vmovaps xmm5, [rsp+0x40]
00007e97133d6ed9  vmovaps xmm6, [rsp+0x50]
00007e97133d6edf  vmovaps xmm7, [rsp+0x60]
00007e97133d6ee5  vmovaps xmm8, [rsp+0x70]
00007e97133d6eeb  vmovaps xmm9, [rsp+0x80]
00007e97133d6ef4  vmovaps xmm10, [rsp+0x90]
00007e97133d6efd  vmovaps xmm11, [rsp+0xA0]
00007e97133d6f06  vmovaps xmm12, [rsp+0xB0]
00007e97133d6f0f  vmovaps xmm13, [rsp+0xC0]
00007e97133d6f18  vmovaps xmm14, [rsp+0xD0]
00007e97133d6f21  vmovaps xmm15, [rsp+0xE0]
00007e97133d6f2a  add rsp, 0xF0
00007e97133d6f31  pop r11
00007e97133d6f33  pop r10
00007e97133d6f35  pop r9
00007e97133d6f37  pop r8
00007e97133d6f39  pop rsi
00007e97133d6f3a  pop rdi
00007e97133d6f3b  pop rdx
00007e97133d6f3c  pop rcx
00007e97133d6f3d  pop rax
00007e97133d6f3e  add rsp, 0x08
00007e97133d6f42  jmp 0x00007E97133D5A88
00007e97133d6f47  sub rsp, 0x08
00007e97133d6f4b  push rax
00007e97133d6f4c  push rcx
00007e97133d6f4d  push rdx
00007e97133d6f4e  push rdi
00007e97133d6f4f  push rsi
00007e97133d6f50  push r8
00007e97133d6f52  push r9
00007e97133d6f54  push r10
00007e97133d6f56  push r11
00007e97133d6f58  sub rsp, 0xF0
00007e97133d6f5f  vmovaps [rsp], xmm0
00007e97133d6f64  vmovaps [rsp+0x10], xmm1
00007e97133d6f6a  vmovaps [rsp+0x20], xmm2
00007e97133d6f70  vmovaps [rsp+0x30], xmm3
00007e97133d6f76  vmovaps [rsp+0x40], xmm4
00007e97133d6f7c  vmovaps [rsp+0x50], xmm6
00007e97133d6f82  vmovaps [rsp+0x60], xmm7
00007e97133d6f88  vmovaps [rsp+0x70], xmm8
00007e97133d6f8e  vmovaps [rsp+0x80], xmm9
00007e97133d6f97  vmovaps [rsp+0x90], xmm10
00007e97133d6fa0  vmovaps [rsp+0xA0], xmm11
00007e97133d6fa9  vmovaps [rsp+0xB0], xmm12
00007e97133d6fb2  vmovaps [rsp+0xC0], xmm13
00007e97133d6fbb  vmovaps [rsp+0xD0], xmm14
00007e97133d6fc4  vmovaps [rsp+0xE0], xmm15
00007e97133d6fcd  sub rsp, 0x30
00007e97133d6fd1  movaps [rsp], xmm5
00007e97133d6fd5  movaps [rsp+0x10], xmm8
00007e97133d6fdb  movaps [rsp+0x20], xmm15
00007e97133d6fe1  lea rdi, [rsp]
00007e97133d6fe5  mov esi, 0x00
00007e97133d6fea  mov rax, 0x58D8AED5F530
00007e97133d6ff4  call rax
00007e97133d6ff6  movaps xmm5, [rsp]
00007e97133d6ffa  add rsp, 0x30
00007e97133d6ffe  vmovaps xmm0, [rsp]
00007e97133d7003  vmovaps xmm1, [rsp+0x10]
00007e97133d7009  vmovaps xmm2, [rsp+0x20]
00007e97133d700f  vmovaps xmm3, [rsp+0x30]
00007e97133d7015  vmovaps xmm4, [rsp+0x40]
00007e97133d701b  vmovaps xmm6, [rsp+0x50]
00007e97133d7021  vmovaps xmm7, [rsp+0x60]
00007e97133d7027  vmovaps xmm8, [rsp+0x70]
00007e97133d702d  vmovaps xmm9, [rsp+0x80]
00007e97133d7036  vmovaps xmm10, [rsp+0x90]
00007e97133d703f  vmovaps xmm11, [rsp+0xA0]
00007e97133d7048  vmovaps xmm12, [rsp+0xB0]
00007e97133d7051  vmovaps xmm13, [rsp+0xC0]
00007e97133d705a  vmovaps xmm14, [rsp+0xD0]
00007e97133d7063  vmovaps xmm15, [rsp+0xE0]
00007e97133d706c  add rsp, 0xF0
00007e97133d7073  pop r11
00007e97133d7075  pop r10
00007e97133d7077  pop r9
00007e97133d7079  pop r8
00007e97133d707b  pop rsi
00007e97133d707c  pop rdi
00007e97133d707d  pop rdx
00007e97133d707e  pop rcx
00007e97133d707f  pop rax
00007e97133d7080  add rsp, 0x08
00007e97133d7084  jmp 0x00007E97133D5AC0
00007e97133d7089  sub rsp, 0x08
00007e97133d708d  push rax
00007e97133d708e  push rcx
00007e97133d708f  push rdx
00007e97133d7090  push rdi
00007e97133d7091  push rsi
00007e97133d7092  push r8
00007e97133d7094  push r9
00007e97133d7096  push r10
00007e97133d7098  push r11
00007e97133d709a  sub rsp, 0xF0
00007e97133d70a1  vmovaps [rsp], xmm0
00007e97133d70a6  vmovaps [rsp+0x10], xmm1
00007e97133d70ac  vmovaps [rsp+0x20], xmm2
00007e97133d70b2  vmovaps [rsp+0x30], xmm3
00007e97133d70b8  vmovaps [rsp+0x40], xmm5
00007e97133d70be  vmovaps [rsp+0x50], xmm6
00007e97133d70c4  vmovaps [rsp+0x60], xmm7
00007e97133d70ca  vmovaps [rsp+0x70], xmm8
00007e97133d70d0  vmovaps [rsp+0x80], xmm9
00007e97133d70d9  vmovaps [rsp+0x90], xmm10
00007e97133d70e2  vmovaps [rsp+0xA0], xmm11
00007e97133d70eb  vmovaps [rsp+0xB0], xmm12
00007e97133d70f4  vmovaps [rsp+0xC0], xmm13
00007e97133d70fd  vmovaps [rsp+0xD0], xmm14
00007e97133d7106  vmovaps [rsp+0xE0], xmm15
00007e97133d710f  sub rsp, 0x30
00007e97133d7113  movaps [rsp], xmm4
00007e97133d7117  movaps [rsp+0x10], xmm9
00007e97133d711d  movaps [rsp+0x20], xmm8
00007e97133d7123  lea rdi, [rsp]
00007e97133d7127  mov esi, 0x00
00007e97133d712c  mov rax, 0x58D8AED5F530
00007e97133d7136  call rax
00007e97133d7138  movaps xmm4, [rsp]
00007e97133d713c  add rsp, 0x30
00007e97133d7140  vmovaps xmm0, [rsp]
00007e97133d7145  vmovaps xmm1, [rsp+0x10]
00007e97133d714b  vmovaps xmm2, [rsp+0x20]
00007e97133d7151  vmovaps xmm3, [rsp+0x30]
00007e97133d7157  vmovaps xmm5, [rsp+0x40]
00007e97133d715d  vmovaps xmm6, [rsp+0x50]
00007e97133d7163  vmovaps xmm7, [rsp+0x60]
00007e97133d7169  vmovaps xmm8, [rsp+0x70]
00007e97133d716f  vmovaps xmm9, [rsp+0x80]
00007e97133d7178  vmovaps xmm10, [rsp+0x90]
00007e97133d7181  vmovaps xmm11, [rsp+0xA0]
00007e97133d718a  vmovaps xmm12, [rsp+0xB0]
00007e97133d7193  vmovaps xmm13, [rsp+0xC0]
00007e97133d719c  vmovaps xmm14, [rsp+0xD0]
00007e97133d71a5  vmovaps xmm15, [rsp+0xE0]
00007e97133d71ae  add rsp, 0xF0
00007e97133d71b5  pop r11
00007e97133d71b7  pop r10
00007e97133d71b9  pop r9
00007e97133d71bb  pop r8
00007e97133d71bd  pop rsi
00007e97133d71be  pop rdi
00007e97133d71bf  pop rdx
00007e97133d71c0  pop rcx
00007e97133d71c1  pop rax
00007e97133d71c2  add rsp, 0x08
00007e97133d71c6  jmp 0x00007E97133D5AE1
00007e97133d71cb  sub rsp, 0x08
00007e97133d71cf  push rax
00007e97133d71d0  push rcx
00007e97133d71d1  push rdx
00007e97133d71d2  push rdi
00007e97133d71d3  push rsi
00007e97133d71d4  push r8
00007e97133d71d6  push r9
00007e97133d71d8  push r10
00007e97133d71da  push r11
00007e97133d71dc  sub rsp, 0xF0
00007e97133d71e3  vmovaps [rsp], xmm0
00007e97133d71e8  vmovaps [rsp+0x10], xmm1
00007e97133d71ee  vmovaps [rsp+0x20], xmm2
00007e97133d71f4  vmovaps [rsp+0x30], xmm3
00007e97133d71fa  vmovaps [rsp+0x40], xmm4
00007e97133d7200  vmovaps [rsp+0x50], xmm5
00007e97133d7206  vmovaps [rsp+0x60], xmm6
00007e97133d720c  vmovaps [rsp+0x70], xmm7
00007e97133d7212  vmovaps [rsp+0x80], xmm8
00007e97133d721b  vmovaps [rsp+0x90], xmm10
00007e97133d7224  vmovaps [rsp+0xA0], xmm11
00007e97133d722d  vmovaps [rsp+0xB0], xmm12
00007e97133d7236  vmovaps [rsp+0xC0], xmm13
00007e97133d723f  vmovaps [rsp+0xD0], xmm14
00007e97133d7248  vmovaps [rsp+0xE0], xmm15
00007e97133d7251  sub rsp, 0x30
00007e97133d7255  movaps [rsp], xmm9
00007e97133d725a  movaps [rsp+0x10], xmm10
00007e97133d7260  movaps [rsp+0x20], xmm8
00007e97133d7266  lea rdi, [rsp]
00007e97133d726a  mov esi, 0x00
00007e97133d726f  mov rax, 0x58D8AED5F530
00007e97133d7279  call rax
00007e97133d727b  movaps xmm9, [rsp]
00007e97133d7280  add rsp, 0x30
00007e97133d7284  vmovaps xmm0, [rsp]
00007e97133d7289  vmovaps xmm1, [rsp+0x10]
00007e97133d728f  vmovaps xmm2, [rsp+0x20]
00007e97133d7295  vmovaps xmm3, [rsp+0x30]
00007e97133d729b  vmovaps xmm4, [rsp+0x40]
00007e97133d72a1  vmovaps xmm5, [rsp+0x50]
00007e97133d72a7  vmovaps xmm6, [rsp+0x60]
00007e97133d72ad  vmovaps xmm7, [rsp+0x70]
00007e97133d72b3  vmovaps xmm8, [rsp+0x80]
00007e97133d72bc  vmovaps xmm10, [rsp+0x90]
00007e97133d72c5  vmovaps xmm11, [rsp+0xA0]
00007e97133d72ce  vmovaps xmm12, [rsp+0xB0]
00007e97133d72d7  vmovaps xmm13, [rsp+0xC0]
00007e97133d72e0  vmovaps xmm14, [rsp+0xD0]
00007e97133d72e9  vmovaps xmm15, [rsp+0xE0]
00007e97133d72f2  add rsp, 0xF0
00007e97133d72f9  pop r11
00007e97133d72fb  pop r10
00007e97133d72fd  pop r9
00007e97133d72ff  pop r8
00007e97133d7301  pop rsi
00007e97133d7302  pop rdi
00007e97133d7303  pop rdx
00007e97133d7304  pop rcx
00007e97133d7305  pop rax
00007e97133d7306  add rsp, 0x08
00007e97133d730a  jmp 0x00007E97133D5AFB
00007e97133d730f  call 0x00007E97132D64F0
00007e97133d7314  jmp 0x00007E97133D5C15
00007e97133d7319  call 0x00007E97132D64F0
00007e97133d731e  jmp 0x00007E97133D5C2B
00007e97133d7323  sub rsp, 0x08
00007e97133d7327  push rax
00007e97133d7328  push rcx
00007e97133d7329  push rdx
00007e97133d732a  push rdi
00007e97133d732b  push rsi
00007e97133d732c  push r8
00007e97133d732e  push r9
00007e97133d7330  push r10
00007e97133d7332  push r11
00007e97133d7334  sub rsp, 0xF0
00007e97133d733b  vmovaps [rsp], xmm0
00007e97133d7340  vmovaps [rsp+0x10], xmm2
00007e97133d7346  vmovaps [rsp+0x20], xmm3
00007e97133d734c  vmovaps [rsp+0x30], xmm4
00007e97133d7352  vmovaps [rsp+0x40], xmm5
00007e97133d7358  vmovaps [rsp+0x50], xmm6
00007e97133d735e  vmovaps [rsp+0x60], xmm7
00007e97133d7364  vmovaps [rsp+0x70], xmm8
00007e97133d736a  vmovaps [rsp+0x80], xmm9
00007e97133d7373  vmovaps [rsp+0x90], xmm10
00007e97133d737c  vmovaps [rsp+0xA0], xmm11
00007e97133d7385  vmovaps [rsp+0xB0], xmm12
00007e97133d738e  vmovaps [rsp+0xC0], xmm13
00007e97133d7397  vmovaps [rsp+0xD0], xmm14
00007e97133d73a0  vmovaps [rsp+0xE0], xmm15
00007e97133d73a9  sub rsp, 0x30
00007e97133d73ad  movaps [rsp], xmm1
00007e97133d73b1  movaps [rsp+0x10], xmm6
00007e97133d73b6  movaps [rsp+0x20], xmm15
00007e97133d73bc  lea rdi, [rsp]
00007e97133d73c0  mov esi, 0x00
00007e97133d73c5  mov rax, 0x58D8AED5F530
00007e97133d73cf  call rax
00007e97133d73d1  movaps xmm1, [rsp]
00007e97133d73d5  add rsp, 0x30
00007e97133d73d9  vmovaps xmm0, [rsp]
00007e97133d73de  vmovaps xmm2, [rsp+0x10]
00007e97133d73e4  vmovaps xmm3, [rsp+0x20]
00007e97133d73ea  vmovaps xmm4, [rsp+0x30]
00007e97133d73f0  vmovaps xmm5, [rsp+0x40]
00007e97133d73f6  vmovaps xmm6, [rsp+0x50]
00007e97133d73fc  vmovaps xmm7, [rsp+0x60]
00007e97133d7402  vmovaps xmm8, [rsp+0x70]
00007e97133d7408  vmovaps xmm9, [rsp+0x80]
00007e97133d7411  vmovaps xmm10, [rsp+0x90]
00007e97133d741a  vmovaps xmm11, [rsp+0xA0]
00007e97133d7423  vmovaps xmm12, [rsp+0xB0]
00007e97133d742c  vmovaps xmm13, [rsp+0xC0]
00007e97133d7435  vmovaps xmm14, [rsp+0xD0]
00007e97133d743e  vmovaps xmm15, [rsp+0xE0]
00007e97133d7447  add rsp, 0xF0
00007e97133d744e  pop r11
00007e97133d7450  pop r10
00007e97133d7452  pop r9
00007e97133d7454  pop r8
00007e97133d7456  pop rsi
00007e97133d7457  pop rdi
00007e97133d7458  pop rdx
00007e97133d7459  pop rcx
00007e97133d745a  pop rax
00007e97133d745b  add rsp, 0x08
00007e97133d745f  jmp 0x00007E97133D5C68
00007e97133d7464  call 0x00007E97132E5820
00007e97133d7469  jmp 0x00007E97133D5C75
00007e97133d746e  sub rsp, 0x08
00007e97133d7472  push rax
00007e97133d7473  push rcx
00007e97133d7474  push rdx
00007e97133d7475  push rdi
00007e97133d7476  push rsi
00007e97133d7477  push r8
00007e97133d7479  push r9
00007e97133d747b  push r10
00007e97133d747d  push r11
00007e97133d747f  sub rsp, 0xF0
00007e97133d7486  vmovaps [rsp], xmm0
00007e97133d748b  vmovaps [rsp+0x10], xmm1
00007e97133d7491  vmovaps [rsp+0x20], xmm2
00007e97133d7497  vmovaps [rsp+0x30], xmm3
00007e97133d749d  vmovaps [rsp+0x40], xmm4
00007e97133d74a3  vmovaps [rsp+0x50], xmm5
00007e97133d74a9  vmovaps [rsp+0x60], xmm6
00007e97133d74af  vmovaps [rsp+0x70], xmm7
00007e97133d74b5  vmovaps [rsp+0x80], xmm8
00007e97133d74be  vmovaps [rsp+0x90], xmm9
00007e97133d74c7  vmovaps [rsp+0xA0], xmm10
00007e97133d74d0  vmovaps [rsp+0xB0], xmm11
00007e97133d74d9  vmovaps [rsp+0xC0], xmm12
00007e97133d74e2  vmovaps [rsp+0xD0], xmm13
00007e97133d74eb  vmovaps [rsp+0xE0], xmm15
00007e97133d74f4  sub rsp, 0x30
00007e97133d74f8  movaps [rsp], xmm14
00007e97133d74fd  movaps [rsp+0x10], xmm4
00007e97133d7502  movaps [rsp+0x20], xmm3
00007e97133d7507  lea rdi, [rsp]
00007e97133d750b  mov esi, 0x00
00007e97133d7510  mov rax, 0x58D8AED5F530
00007e97133d751a  call rax
00007e97133d751c  movaps xmm14, [rsp]
00007e97133d7521  add rsp, 0x30
00007e97133d7525  vmovaps xmm0, [rsp]
00007e97133d752a  vmovaps xmm1, [rsp+0x10]
00007e97133d7530  vmovaps xmm2, [rsp+0x20]
00007e97133d7536  vmovaps xmm3, [rsp+0x30]
00007e97133d753c  vmovaps xmm4, [rsp+0x40]
00007e97133d7542  vmovaps xmm5, [rsp+0x50]
00007e97133d7548  vmovaps xmm6, [rsp+0x60]
00007e97133d754e  vmovaps xmm7, [rsp+0x70]
00007e97133d7554  vmovaps xmm8, [rsp+0x80]
00007e97133d755d  vmovaps xmm9, [rsp+0x90]
00007e97133d7566  vmovaps xmm10, [rsp+0xA0]
00007e97133d756f  vmovaps xmm11, [rsp+0xB0]
00007e97133d7578  vmovaps xmm12, [rsp+0xC0]
00007e97133d7581  vmovaps xmm13, [rsp+0xD0]
00007e97133d758a  vmovaps xmm15, [rsp+0xE0]
00007e97133d7593  add rsp, 0xF0
00007e97133d759a  pop r11
00007e97133d759c  pop r10
00007e97133d759e  pop r9
00007e97133d75a0  pop r8
00007e97133d75a2  pop rsi
00007e97133d75a3  pop rdi
00007e97133d75a4  pop rdx
00007e97133d75a5  pop rcx
00007e97133d75a6  pop rax
00007e97133d75a7  add rsp, 0x08
00007e97133d75ab  jmp 0x00007E97133D5C8F
00007e97133d75b0  sub rsp, 0x08
00007e97133d75b4  push rax
00007e97133d75b5  push rcx
00007e97133d75b6  push rdx
00007e97133d75b7  push rdi
00007e97133d75b8  push rsi
00007e97133d75b9  push r8
00007e97133d75bb  push r9
00007e97133d75bd  push r10
00007e97133d75bf  push r11
00007e97133d75c1  sub rsp, 0xF0
00007e97133d75c8  vmovaps [rsp], xmm0
00007e97133d75cd  vmovaps [rsp+0x10], xmm1
00007e97133d75d3  vmovaps [rsp+0x20], xmm2
00007e97133d75d9  vmovaps [rsp+0x30], xmm3
00007e97133d75df  vmovaps [rsp+0x40], xmm4
00007e97133d75e5  vmovaps [rsp+0x50], xmm5
00007e97133d75eb  vmovaps [rsp+0x60], xmm7
00007e97133d75f1  vmovaps [rsp+0x70], xmm8
00007e97133d75f7  vmovaps [rsp+0x80], xmm9
00007e97133d7600  vmovaps [rsp+0x90], xmm10
00007e97133d7609  vmovaps [rsp+0xA0], xmm11
00007e97133d7612  vmovaps [rsp+0xB0], xmm12
00007e97133d761b  vmovaps [rsp+0xC0], xmm13
00007e97133d7624  vmovaps [rsp+0xD0], xmm14
00007e97133d762d  vmovaps [rsp+0xE0], xmm15
00007e97133d7636  sub rsp, 0x30
00007e97133d763a  movaps [rsp], xmm6
00007e97133d763e  movaps [rsp+0x10], xmm9
00007e97133d7644  movaps [rsp+0x20], xmm7
00007e97133d7649  lea rdi, [rsp]
00007e97133d764d  mov esi, 0x00
00007e97133d7652  mov rax, 0x58D8AED5F530
00007e97133d765c  call rax
00007e97133d765e  movaps xmm6, [rsp]
00007e97133d7662  add rsp, 0x30
00007e97133d7666  vmovaps xmm0, [rsp]
00007e97133d766b  vmovaps xmm1, [rsp+0x10]
00007e97133d7671  vmovaps xmm2, [rsp+0x20]
00007e97133d7677  vmovaps xmm3, [rsp+0x30]
00007e97133d767d  vmovaps xmm4, [rsp+0x40]
00007e97133d7683  vmovaps xmm5, [rsp+0x50]
00007e97133d7689  vmovaps xmm7, [rsp+0x60]
00007e97133d768f  vmovaps xmm8, [rsp+0x70]
00007e97133d7695  vmovaps xmm9, [rsp+0x80]
00007e97133d769e  vmovaps xmm10, [rsp+0x90]
00007e97133d76a7  vmovaps xmm11, [rsp+0xA0]
00007e97133d76b0  vmovaps xmm12, [rsp+0xB0]
00007e97133d76b9  vmovaps xmm13, [rsp+0xC0]
00007e97133d76c2  vmovaps xmm14, [rsp+0xD0]
00007e97133d76cb  vmovaps xmm15, [rsp+0xE0]
00007e97133d76d4  add rsp, 0xF0
00007e97133d76db  pop r11
00007e97133d76dd  pop r10
00007e97133d76df  pop r9
00007e97133d76e1  pop r8
00007e97133d76e3  pop rsi
00007e97133d76e4  pop rdi
00007e97133d76e5  pop rdx
00007e97133d76e6  pop rcx
00007e97133d76e7  pop rax
00007e97133d76e8  add rsp, 0x08
00007e97133d76ec  jmp 0x00007E97133D5CA7
00007e97133d76f1  sub rsp, 0x08
00007e97133d76f5  push rax
00007e97133d76f6  push rcx
00007e97133d76f7  push rdx
00007e97133d76f8  push rdi
00007e97133d76f9  push rsi
00007e97133d76fa  push r8
00007e97133d76fc  push r9
00007e97133d76fe  push r10
00007e97133d7700  push r11
00007e97133d7702  sub rsp, 0xF0
00007e97133d7709  vmovaps [rsp], xmm0
00007e97133d770e  vmovaps [rsp+0x10], xmm1
00007e97133d7714  vmovaps [rsp+0x20], xmm2
00007e97133d771a  vmovaps [rsp+0x30], xmm3
00007e97133d7720  vmovaps [rsp+0x40], xmm4
00007e97133d7726  vmovaps [rsp+0x50], xmm5
00007e97133d772c  vmovaps [rsp+0x60], xmm6
00007e97133d7732  vmovaps [rsp+0x70], xmm8
00007e97133d7738  vmovaps [rsp+0x80], xmm9
00007e97133d7741  vmovaps [rsp+0x90], xmm10
00007e97133d774a  vmovaps [rsp+0xA0], xmm11
00007e97133d7753  vmovaps [rsp+0xB0], xmm12
00007e97133d775c  vmovaps [rsp+0xC0], xmm13
00007e97133d7765  vmovaps [rsp+0xD0], xmm14
00007e97133d776e  vmovaps [rsp+0xE0], xmm15
00007e97133d7777  sub rsp, 0x30
00007e97133d777b  movaps [rsp], xmm7
00007e97133d777f  movaps [rsp+0x10], xmm4
00007e97133d7784  movaps [rsp+0x20], xmm9
00007e97133d778a  lea rdi, [rsp]
00007e97133d778e  mov esi, 0x00
00007e97133d7793  mov rax, 0x58D8AED5F530
00007e97133d779d  call rax
00007e97133d779f  movaps xmm7, [rsp]
00007e97133d77a3  add rsp, 0x30
00007e97133d77a7  vmovaps xmm0, [rsp]
00007e97133d77ac  vmovaps xmm1, [rsp+0x10]
00007e97133d77b2  vmovaps xmm2, [rsp+0x20]
00007e97133d77b8  vmovaps xmm3, [rsp+0x30]
00007e97133d77be  vmovaps xmm4, [rsp+0x40]
00007e97133d77c4  vmovaps xmm5, [rsp+0x50]
00007e97133d77ca  vmovaps xmm6, [rsp+0x60]
00007e97133d77d0  vmovaps xmm8, [rsp+0x70]
00007e97133d77d6  vmovaps xmm9, [rsp+0x80]
00007e97133d77df  vmovaps xmm10, [rsp+0x90]
00007e97133d77e8  vmovaps xmm11, [rsp+0xA0]
00007e97133d77f1  vmovaps xmm12, [rsp+0xB0]
00007e97133d77fa  vmovaps xmm13, [rsp+0xC0]
00007e97133d7803  vmovaps xmm14, [rsp+0xD0]
00007e97133d780c  vmovaps xmm15, [rsp+0xE0]
00007e97133d7815  add rsp, 0xF0
00007e97133d781c  pop r11
00007e97133d781e  pop r10
00007e97133d7820  pop r9
00007e97133d7822  pop r8
00007e97133d7824  pop rsi
00007e97133d7825  pop rdi
00007e97133d7826  pop rdx
00007e97133d7827  pop rcx
00007e97133d7828  pop rax
00007e97133d7829  add rsp, 0x08
00007e97133d782d  jmp 0x00007E97133D5CD4
00007e97133d7832  sub rsp, 0x08
00007e97133d7836  push rax
00007e97133d7837  push rcx
00007e97133d7838  push rdx
00007e97133d7839  push rdi
00007e97133d783a  push rsi
00007e97133d783b  push r8
00007e97133d783d  push r9
00007e97133d783f  push r10
00007e97133d7841  push r11
00007e97133d7843  sub rsp, 0xF0
00007e97133d784a  vmovaps [rsp], xmm0
00007e97133d784f  vmovaps [rsp+0x10], xmm1
00007e97133d7855  vmovaps [rsp+0x20], xmm2
00007e97133d785b  vmovaps [rsp+0x30], xmm3
00007e97133d7861  vmovaps [rsp+0x40], xmm5
00007e97133d7867  vmovaps [rsp+0x50], xmm6
00007e97133d786d  vmovaps [rsp+0x60], xmm7
00007e97133d7873  vmovaps [rsp+0x70], xmm8
00007e97133d7879  vmovaps [rsp+0x80], xmm9
00007e97133d7882  vmovaps [rsp+0x90], xmm10
00007e97133d788b  vmovaps [rsp+0xA0], xmm11
00007e97133d7894  vmovaps [rsp+0xB0], xmm12
00007e97133d789d  vmovaps [rsp+0xC0], xmm13
00007e97133d78a6  vmovaps [rsp+0xD0], xmm14
00007e97133d78af  vmovaps [rsp+0xE0], xmm15
00007e97133d78b8  sub rsp, 0x30
00007e97133d78bc  movaps [rsp], xmm4
00007e97133d78c0  movaps [rsp+0x10], xmm15
00007e97133d78c6  movaps [rsp+0x20], xmm9
00007e97133d78cc  lea rdi, [rsp]
00007e97133d78d0  mov esi, 0x00
00007e97133d78d5  mov rax, 0x58D8AED5F530
00007e97133d78df  call rax
00007e97133d78e1  movaps xmm4, [rsp]
00007e97133d78e5  add rsp, 0x30
00007e97133d78e9  vmovaps xmm0, [rsp]
00007e97133d78ee  vmovaps xmm1, [rsp+0x10]
00007e97133d78f4  vmovaps xmm2, [rsp+0x20]
00007e97133d78fa  vmovaps xmm3, [rsp+0x30]
00007e97133d7900  vmovaps xmm5, [rsp+0x40]
00007e97133d7906  vmovaps xmm6, [rsp+0x50]
00007e97133d790c  vmovaps xmm7, [rsp+0x60]
00007e97133d7912  vmovaps xmm8, [rsp+0x70]
00007e97133d7918  vmovaps xmm9, [rsp+0x80]
00007e97133d7921  vmovaps xmm10, [rsp+0x90]
00007e97133d792a  vmovaps xmm11, [rsp+0xA0]
00007e97133d7933  vmovaps xmm12, [rsp+0xB0]
00007e97133d793c  vmovaps xmm13, [rsp+0xC0]
00007e97133d7945  vmovaps xmm14, [rsp+0xD0]
00007e97133d794e  vmovaps xmm15, [rsp+0xE0]
00007e97133d7957  add rsp, 0xF0
00007e97133d795e  pop r11
00007e97133d7960  pop r10
00007e97133d7962  pop r9
00007e97133d7964  pop r8
00007e97133d7966  pop rsi
00007e97133d7967  pop rdi
00007e97133d7968  pop rdx
00007e97133d7969  pop rcx
00007e97133d796a  pop rax
00007e97133d796b  add rsp, 0x08
00007e97133d796f  jmp 0x00007E97133D5CF9
00007e97133d7974  call 0x00007E97132E5820
00007e97133d7979  jmp 0x00007E97133D5D06
00007e97133d797e  sub rsp, 0x08
00007e97133d7982  push rax
00007e97133d7983  push rcx
00007e97133d7984  push rdx
00007e97133d7985  push rdi
00007e97133d7986  push rsi
00007e97133d7987  push r8
00007e97133d7989  push r9
00007e97133d798b  push r10
00007e97133d798d  push r11
00007e97133d798f  sub rsp, 0xF0
00007e97133d7996  vmovaps [rsp], xmm0
00007e97133d799b  vmovaps [rsp+0x10], xmm1
00007e97133d79a1  vmovaps [rsp+0x20], xmm2
00007e97133d79a7  vmovaps [rsp+0x30], xmm4
00007e97133d79ad  vmovaps [rsp+0x40], xmm5
00007e97133d79b3  vmovaps [rsp+0x50], xmm6
00007e97133d79b9  vmovaps [rsp+0x60], xmm7
00007e97133d79bf  vmovaps [rsp+0x70], xmm8
00007e97133d79c5  vmovaps [rsp+0x80], xmm9
00007e97133d79ce  vmovaps [rsp+0x90], xmm10
00007e97133d79d7  vmovaps [rsp+0xA0], xmm11
00007e97133d79e0  vmovaps [rsp+0xB0], xmm12
00007e97133d79e9  vmovaps [rsp+0xC0], xmm13
00007e97133d79f2  vmovaps [rsp+0xD0], xmm14
00007e97133d79fb  vmovaps [rsp+0xE0], xmm15
00007e97133d7a04  sub rsp, 0x30
00007e97133d7a08  movaps [rsp], xmm3
00007e97133d7a0c  movaps [rsp+0x10], xmm1
00007e97133d7a11  movaps [rsp+0x20], xmm9
00007e97133d7a17  lea rdi, [rsp]
00007e97133d7a1b  mov esi, 0x00
00007e97133d7a20  mov rax, 0x58D8AED5F530
00007e97133d7a2a  call rax
00007e97133d7a2c  movaps xmm3, [rsp]
00007e97133d7a30  add rsp, 0x30
00007e97133d7a34  vmovaps xmm0, [rsp]
00007e97133d7a39  vmovaps xmm1, [rsp+0x10]
00007e97133d7a3f  vmovaps xmm2, [rsp+0x20]
00007e97133d7a45  vmovaps xmm4, [rsp+0x30]
00007e97133d7a4b  vmovaps xmm5, [rsp+0x40]
00007e97133d7a51  vmovaps xmm6, [rsp+0x50]
00007e97133d7a57  vmovaps xmm7, [rsp+0x60]
00007e97133d7a5d  vmovaps xmm8, [rsp+0x70]
00007e97133d7a63  vmovaps xmm9, [rsp+0x80]
00007e97133d7a6c  vmovaps xmm10, [rsp+0x90]
00007e97133d7a75  vmovaps xmm11, [rsp+0xA0]
00007e97133d7a7e  vmovaps xmm12, [rsp+0xB0]
00007e97133d7a87  vmovaps xmm13, [rsp+0xC0]
00007e97133d7a90  vmovaps xmm14, [rsp+0xD0]
00007e97133d7a99  vmovaps xmm15, [rsp+0xE0]
00007e97133d7aa2  add rsp, 0xF0
00007e97133d7aa9  pop r11
00007e97133d7aab  pop r10
00007e97133d7aad  pop r9
00007e97133d7aaf  pop r8
00007e97133d7ab1  pop rsi
00007e97133d7ab2  pop rdi
00007e97133d7ab3  pop rdx
00007e97133d7ab4  pop rcx
00007e97133d7ab5  pop rax
00007e97133d7ab6  add rsp, 0x08
00007e97133d7aba  jmp 0x00007E97133D5D43
00007e97133d7abf  sub rsp, 0x08
00007e97133d7ac3  push rax
00007e97133d7ac4  push rcx
00007e97133d7ac5  push rdx
00007e97133d7ac6  push rdi
00007e97133d7ac7  push rsi
00007e97133d7ac8  push r8
00007e97133d7aca  push r9
00007e97133d7acc  push r10
00007e97133d7ace  push r11
00007e97133d7ad0  sub rsp, 0xF0
00007e97133d7ad7  vmovaps [rsp], xmm0
00007e97133d7adc  vmovaps [rsp+0x10], xmm2
00007e97133d7ae2  vmovaps [rsp+0x20], xmm3
00007e97133d7ae8  vmovaps [rsp+0x30], xmm4
00007e97133d7aee  vmovaps [rsp+0x40], xmm5
00007e97133d7af4  vmovaps [rsp+0x50], xmm6
00007e97133d7afa  vmovaps [rsp+0x60], xmm7
00007e97133d7b00  vmovaps [rsp+0x70], xmm8
00007e97133d7b06  vmovaps [rsp+0x80], xmm9
00007e97133d7b0f  vmovaps [rsp+0x90], xmm10
00007e97133d7b18  vmovaps [rsp+0xA0], xmm11
00007e97133d7b21  vmovaps [rsp+0xB0], xmm12
00007e97133d7b2a  vmovaps [rsp+0xC0], xmm13
00007e97133d7b33  vmovaps [rsp+0xD0], xmm14
00007e97133d7b3c  vmovaps [rsp+0xE0], xmm15
00007e97133d7b45  sub rsp, 0x30
00007e97133d7b49  movaps [rsp], xmm1
00007e97133d7b4d  movaps [rsp+0x10], xmm15
00007e97133d7b53  movaps [rsp+0x20], xmm9
00007e97133d7b59  lea rdi, [rsp]
00007e97133d7b5d  mov esi, 0x00
00007e97133d7b62  mov rax, 0x58D8AED5F530
00007e97133d7b6c  call rax
00007e97133d7b6e  movaps xmm1, [rsp]
00007e97133d7b72  add rsp, 0x30
00007e97133d7b76  vmovaps xmm0, [rsp]
00007e97133d7b7b  vmovaps xmm2, [rsp+0x10]
00007e97133d7b81  vmovaps xmm3, [rsp+0x20]
00007e97133d7b87  vmovaps xmm4, [rsp+0x30]
00007e97133d7b8d  vmovaps xmm5, [rsp+0x40]
00007e97133d7b93  vmovaps xmm6, [rsp+0x50]
00007e97133d7b99  vmovaps xmm7, [rsp+0x60]
00007e97133d7b9f  vmovaps xmm8, [rsp+0x70]
00007e97133d7ba5  vmovaps xmm9, [rsp+0x80]
00007e97133d7bae  vmovaps xmm10, [rsp+0x90]
00007e97133d7bb7  vmovaps xmm11, [rsp+0xA0]
00007e97133d7bc0  vmovaps xmm12, [rsp+0xB0]
00007e97133d7bc9  vmovaps xmm13, [rsp+0xC0]
00007e97133d7bd2  vmovaps xmm14, [rsp+0xD0]
00007e97133d7bdb  vmovaps xmm15, [rsp+0xE0]
00007e97133d7be4  add rsp, 0xF0
00007e97133d7beb  pop r11
00007e97133d7bed  pop r10
00007e97133d7bef  pop r9
00007e97133d7bf1  pop r8
00007e97133d7bf3  pop rsi
00007e97133d7bf4  pop rdi
00007e97133d7bf5  pop rdx
00007e97133d7bf6  pop rcx
00007e97133d7bf7  pop rax
00007e97133d7bf8  add rsp, 0x08
00007e97133d7bfc  jmp 0x00007E97133D5DCB
00007e97133d7c01  call 0x00007E97132E5820
00007e97133d7c06  jmp 0x00007E97133D5DD8
00007e97133d7c0b  sub rsp, 0x08
00007e97133d7c0f  push rax
00007e97133d7c10  push rcx
00007e97133d7c11  push rdx
00007e97133d7c12  push rdi
00007e97133d7c13  push rsi
00007e97133d7c14  push r8
00007e97133d7c16  push r9
00007e97133d7c18  push r10
00007e97133d7c1a  push r11
00007e97133d7c1c  sub rsp, 0xF0
00007e97133d7c23  vmovaps [rsp], xmm0
00007e97133d7c28  vmovaps [rsp+0x10], xmm2
00007e97133d7c2e  vmovaps [rsp+0x20], xmm3
00007e97133d7c34  vmovaps [rsp+0x30], xmm4
00007e97133d7c3a  vmovaps [rsp+0x40], xmm5
00007e97133d7c40  vmovaps [rsp+0x50], xmm6
00007e97133d7c46  vmovaps [rsp+0x60], xmm7
00007e97133d7c4c  vmovaps [rsp+0x70], xmm8
00007e97133d7c52  vmovaps [rsp+0x80], xmm9
00007e97133d7c5b  vmovaps [rsp+0x90], xmm10
00007e97133d7c64  vmovaps [rsp+0xA0], xmm11
00007e97133d7c6d  vmovaps [rsp+0xB0], xmm12
00007e97133d7c76  vmovaps [rsp+0xC0], xmm13
00007e97133d7c7f  vmovaps [rsp+0xD0], xmm14
00007e97133d7c88  vmovaps [rsp+0xE0], xmm15
00007e97133d7c91  sub rsp, 0x30
00007e97133d7c95  movaps [rsp], xmm1
00007e97133d7c99  movaps [rsp+0x10], xmm5
00007e97133d7c9e  movaps [rsp+0x20], xmm7
00007e97133d7ca3  lea rdi, [rsp]
00007e97133d7ca7  mov esi, 0x00
00007e97133d7cac  mov rax, 0x58D8AED5F530
00007e97133d7cb6  call rax
00007e97133d7cb8  movaps xmm1, [rsp]
00007e97133d7cbc  add rsp, 0x30
00007e97133d7cc0  vmovaps xmm0, [rsp]
00007e97133d7cc5  vmovaps xmm2, [rsp+0x10]
00007e97133d7ccb  vmovaps xmm3, [rsp+0x20]
00007e97133d7cd1  vmovaps xmm4, [rsp+0x30]
00007e97133d7cd7  vmovaps xmm5, [rsp+0x40]
00007e97133d7cdd  vmovaps xmm6, [rsp+0x50]
00007e97133d7ce3  vmovaps xmm7, [rsp+0x60]
00007e97133d7ce9  vmovaps xmm8, [rsp+0x70]
00007e97133d7cef  vmovaps xmm9, [rsp+0x80]
00007e97133d7cf8  vmovaps xmm10, [rsp+0x90]
00007e97133d7d01  vmovaps xmm11, [rsp+0xA0]
00007e97133d7d0a  vmovaps xmm12, [rsp+0xB0]
00007e97133d7d13  vmovaps xmm13, [rsp+0xC0]
00007e97133d7d1c  vmovaps xmm14, [rsp+0xD0]
00007e97133d7d25  vmovaps xmm15, [rsp+0xE0]
00007e97133d7d2e  add rsp, 0xF0
00007e97133d7d35  pop r11
00007e97133d7d37  pop r10
00007e97133d7d39  pop r9
00007e97133d7d3b  pop r8
00007e97133d7d3d  pop rsi
00007e97133d7d3e  pop rdi
00007e97133d7d3f  pop rdx
00007e97133d7d40  pop rcx
00007e97133d7d41  pop rax
00007e97133d7d42  add rsp, 0x08
00007e97133d7d46  jmp 0x00007E97133D5E7D
00007e97133d7d4b  sub rsp, 0x08
00007e97133d7d4f  push rax
00007e97133d7d50  push rcx
00007e97133d7d51  push rdx
00007e97133d7d52  push rdi
00007e97133d7d53  push rsi
00007e97133d7d54  push r8
00007e97133d7d56  push r9
00007e97133d7d58  push r10
00007e97133d7d5a  push r11
00007e97133d7d5c  sub rsp, 0xF0
00007e97133d7d63  vmovaps [rsp], xmm0
00007e97133d7d68  vmovaps [rsp+0x10], xmm1
00007e97133d7d6e  vmovaps [rsp+0x20], xmm2
00007e97133d7d74  vmovaps [rsp+0x30], xmm3
00007e97133d7d7a  vmovaps [rsp+0x40], xmm4
00007e97133d7d80  vmovaps [rsp+0x50], xmm5
00007e97133d7d86  vmovaps [rsp+0x60], xmm6
00007e97133d7d8c  vmovaps [rsp+0x70], xmm8
00007e97133d7d92  vmovaps [rsp+0x80], xmm9
00007e97133d7d9b  vmovaps [rsp+0x90], xmm10
00007e97133d7da4  vmovaps [rsp+0xA0], xmm11
00007e97133d7dad  vmovaps [rsp+0xB0], xmm12
00007e97133d7db6  vmovaps [rsp+0xC0], xmm13
00007e97133d7dbf  vmovaps [rsp+0xD0], xmm14
00007e97133d7dc8  vmovaps [rsp+0xE0], xmm15
00007e97133d7dd1  sub rsp, 0x30
00007e97133d7dd5  movaps [rsp], xmm7
00007e97133d7dd9  movaps [rsp+0x10], xmm5
00007e97133d7dde  movaps [rsp+0x20], xmm15
00007e97133d7de4  lea rdi, [rsp]
00007e97133d7de8  mov esi, 0x00
00007e97133d7ded  mov rax, 0x58D8AED5F530
00007e97133d7df7  call rax
00007e97133d7df9  movaps xmm7, [rsp]
00007e97133d7dfd  add rsp, 0x30
00007e97133d7e01  vmovaps xmm0, [rsp]
00007e97133d7e06  vmovaps xmm1, [rsp+0x10]
00007e97133d7e0c  vmovaps xmm2, [rsp+0x20]
00007e97133d7e12  vmovaps xmm3, [rsp+0x30]
00007e97133d7e18  vmovaps xmm4, [rsp+0x40]
00007e97133d7e1e  vmovaps xmm5, [rsp+0x50]
00007e97133d7e24  vmovaps xmm6, [rsp+0x60]
00007e97133d7e2a  vmovaps xmm8, [rsp+0x70]
00007e97133d7e30  vmovaps xmm9, [rsp+0x80]
00007e97133d7e39  vmovaps xmm10, [rsp+0x90]
00007e97133d7e42  vmovaps xmm11, [rsp+0xA0]
00007e97133d7e4b  vmovaps xmm12, [rsp+0xB0]
00007e97133d7e54  vmovaps xmm13, [rsp+0xC0]
00007e97133d7e5d  vmovaps xmm14, [rsp+0xD0]
00007e97133d7e66  vmovaps xmm15, [rsp+0xE0]
00007e97133d7e6f  add rsp, 0xF0
00007e97133d7e76  pop r11
00007e97133d7e78  pop r10
00007e97133d7e7a  pop r9
00007e97133d7e7c  pop r8
00007e97133d7e7e  pop rsi
00007e97133d7e7f  pop rdi
00007e97133d7e80  pop rdx
00007e97133d7e81  pop rcx
00007e97133d7e82  pop rax
00007e97133d7e83  add rsp, 0x08
00007e97133d7e87  jmp 0x00007E97133D5EB3
00007e97133d7e8c  call 0x00007E97132D64F0
00007e97133d7e91  jmp 0x00007E97133D5EC0
00007e97133d7e96  sub rsp, 0x08
00007e97133d7e9a  push rax
00007e97133d7e9b  push rcx
00007e97133d7e9c  push rdx
00007e97133d7e9d  push rdi
00007e97133d7e9e  push rsi
00007e97133d7e9f  push r8
00007e97133d7ea1  push r9
00007e97133d7ea3  push r10
00007e97133d7ea5  push r11
00007e97133d7ea7  sub rsp, 0xF0
00007e97133d7eae  vmovaps [rsp], xmm0
00007e97133d7eb3  vmovaps [rsp+0x10], xmm1
00007e97133d7eb9  vmovaps [rsp+0x20], xmm2
00007e97133d7ebf  vmovaps [rsp+0x30], xmm3
00007e97133d7ec5  vmovaps [rsp+0x40], xmm4
00007e97133d7ecb  vmovaps [rsp+0x50], xmm5
00007e97133d7ed1  vmovaps [rsp+0x60], xmm6
00007e97133d7ed7  vmovaps [rsp+0x70], xmm7
00007e97133d7edd  vmovaps [rsp+0x80], xmm8
00007e97133d7ee6  vmovaps [rsp+0x90], xmm9
00007e97133d7eef  vmovaps [rsp+0xA0], xmm10
00007e97133d7ef8  vmovaps [rsp+0xB0], xmm11
00007e97133d7f01  vmovaps [rsp+0xC0], xmm12
00007e97133d7f0a  vmovaps [rsp+0xD0], xmm13
00007e97133d7f13  vmovaps [rsp+0xE0], xmm14
00007e97133d7f1c  sub rsp, 0x30
00007e97133d7f20  movaps [rsp], xmm15
00007e97133d7f25  movaps [rsp+0x10], xmm5
00007e97133d7f2a  movaps [rsp+0x20], xmm3
00007e97133d7f2f  lea rdi, [rsp]
00007e97133d7f33  mov esi, 0x00
00007e97133d7f38  mov rax, 0x58D8AED5F530
00007e97133d7f42  call rax
00007e97133d7f44  movaps xmm15, [rsp]
00007e97133d7f49  add rsp, 0x30
00007e97133d7f4d  vmovaps xmm0, [rsp]
00007e97133d7f52  vmovaps xmm1, [rsp+0x10]
00007e97133d7f58  vmovaps xmm2, [rsp+0x20]
00007e97133d7f5e  vmovaps xmm3, [rsp+0x30]
00007e97133d7f64  vmovaps xmm4, [rsp+0x40]
00007e97133d7f6a  vmovaps xmm5, [rsp+0x50]
00007e97133d7f70  vmovaps xmm6, [rsp+0x60]
00007e97133d7f76  vmovaps xmm7, [rsp+0x70]
00007e97133d7f7c  vmovaps xmm8, [rsp+0x80]
00007e97133d7f85  vmovaps xmm9, [rsp+0x90]
00007e97133d7f8e  vmovaps xmm10, [rsp+0xA0]
00007e97133d7f97  vmovaps xmm11, [rsp+0xB0]
00007e97133d7fa0  vmovaps xmm12, [rsp+0xC0]
00007e97133d7fa9  vmovaps xmm13, [rsp+0xD0]
00007e97133d7fb2  vmovaps xmm14, [rsp+0xE0]
00007e97133d7fbb  add rsp, 0xF0
00007e97133d7fc2  pop r11
00007e97133d7fc4  pop r10
00007e97133d7fc6  pop r9
00007e97133d7fc8  pop r8
00007e97133d7fca  pop rsi
00007e97133d7fcb  pop rdi
00007e97133d7fcc  pop rdx
00007e97133d7fcd  pop rcx
00007e97133d7fce  pop rax
00007e97133d7fcf  add rsp, 0x08
00007e97133d7fd3  jmp 0x00007E97133D5EE6
00007e97133d7fd8  sub rsp, 0x08
00007e97133d7fdc  push rax
00007e97133d7fdd  push rcx
00007e97133d7fde  push rdx
00007e97133d7fdf  push rdi
00007e97133d7fe0  push rsi
00007e97133d7fe1  push r8
00007e97133d7fe3  push r9
00007e97133d7fe5  push r10
00007e97133d7fe7  push r11
00007e97133d7fe9  sub rsp, 0xF0
00007e97133d7ff0  vmovaps [rsp], xmm0
00007e97133d7ff5  vmovaps [rsp+0x10], xmm2
00007e97133d7ffb  vmovaps [rsp+0x20], xmm3
00007e97133d8001  vmovaps [rsp+0x30], xmm4
00007e97133d8007  vmovaps [rsp+0x40], xmm5
00007e97133d800d  vmovaps [rsp+0x50], xmm6
00007e97133d8013  vmovaps [rsp+0x60], xmm7
00007e97133d8019  vmovaps [rsp+0x70], xmm8
00007e97133d801f  vmovaps [rsp+0x80], xmm9
00007e97133d8028  vmovaps [rsp+0x90], xmm10
00007e97133d8031  vmovaps [rsp+0xA0], xmm11
00007e97133d803a  vmovaps [rsp+0xB0], xmm12
00007e97133d8043  vmovaps [rsp+0xC0], xmm13
00007e97133d804c  vmovaps [rsp+0xD0], xmm14
00007e97133d8055  vmovaps [rsp+0xE0], xmm15
00007e97133d805e  sub rsp, 0x30
00007e97133d8062  movaps [rsp], xmm1
00007e97133d8066  movaps [rsp+0x10], xmm5
00007e97133d806b  movaps [rsp+0x20], xmm4
00007e97133d8070  lea rdi, [rsp]
00007e97133d8074  mov esi, 0x00
00007e97133d8079  mov rax, 0x58D8AED5F530
00007e97133d8083  call rax
00007e97133d8085  movaps xmm1, [rsp]
00007e97133d8089  add rsp, 0x30
00007e97133d808d  vmovaps xmm0, [rsp]
00007e97133d8092  vmovaps xmm2, [rsp+0x10]
00007e97133d8098  vmovaps xmm3, [rsp+0x20]
00007e97133d809e  vmovaps xmm4, [rsp+0x30]
00007e97133d80a4  vmovaps xmm5, [rsp+0x40]
00007e97133d80aa  vmovaps xmm6, [rsp+0x50]
00007e97133d80b0  vmovaps xmm7, [rsp+0x60]
00007e97133d80b6  vmovaps xmm8, [rsp+0x70]
00007e97133d80bc  vmovaps xmm9, [rsp+0x80]
00007e97133d80c5  vmovaps xmm10, [rsp+0x90]
00007e97133d80ce  vmovaps xmm11, [rsp+0xA0]
00007e97133d80d7  vmovaps xmm12, [rsp+0xB0]
00007e97133d80e0  vmovaps xmm13, [rsp+0xC0]
00007e97133d80e9  vmovaps xmm14, [rsp+0xD0]
00007e97133d80f2  vmovaps xmm15, [rsp+0xE0]
00007e97133d80fb  add rsp, 0xF0
00007e97133d8102  pop r11
00007e97133d8104  pop r10
00007e97133d8106  pop r9
00007e97133d8108  pop r8
00007e97133d810a  pop rsi
00007e97133d810b  pop rdi
00007e97133d810c  pop rdx
00007e97133d810d  pop rcx
00007e97133d810e  pop rax
00007e97133d810f  add rsp, 0x08
00007e97133d8113  jmp 0x00007E97133D5F06
00007e97133d8118  sub rsp, 0x08
00007e97133d811c  push rax
00007e97133d811d  push rcx
00007e97133d811e  push rdx
00007e97133d811f  push rdi
00007e97133d8120  push rsi
00007e97133d8121  push r8
00007e97133d8123  push r9
00007e97133d8125  push r10
00007e97133d8127  push r11
00007e97133d8129  sub rsp, 0xF0
00007e97133d8130  vmovaps [rsp], xmm0
00007e97133d8135  vmovaps [rsp+0x10], xmm1
00007e97133d813b  vmovaps [rsp+0x20], xmm2
00007e97133d8141  vmovaps [rsp+0x30], xmm3
00007e97133d8147  vmovaps [rsp+0x40], xmm5
00007e97133d814d  vmovaps [rsp+0x50], xmm6
00007e97133d8153  vmovaps [rsp+0x60], xmm7
00007e97133d8159  vmovaps [rsp+0x70], xmm8
00007e97133d815f  vmovaps [rsp+0x80], xmm9
00007e97133d8168  vmovaps [rsp+0x90], xmm10
00007e97133d8171  vmovaps [rsp+0xA0], xmm11
00007e97133d817a  vmovaps [rsp+0xB0], xmm12
00007e97133d8183  vmovaps [rsp+0xC0], xmm13
00007e97133d818c  vmovaps [rsp+0xD0], xmm14
00007e97133d8195  vmovaps [rsp+0xE0], xmm15
00007e97133d819e  sub rsp, 0x30
00007e97133d81a2  movaps [rsp], xmm4
00007e97133d81a6  movaps [rsp+0x10], xmm3
00007e97133d81ab  movaps [rsp+0x20], xmm5
00007e97133d81b0  lea rdi, [rsp]
00007e97133d81b4  mov esi, 0x00
00007e97133d81b9  mov rax, 0x58D8AED5F530
00007e97133d81c3  call rax
00007e97133d81c5  movaps xmm4, [rsp]
00007e97133d81c9  add rsp, 0x30
00007e97133d81cd  vmovaps xmm0, [rsp]
00007e97133d81d2  vmovaps xmm1, [rsp+0x10]
00007e97133d81d8  vmovaps xmm2, [rsp+0x20]
00007e97133d81de  vmovaps xmm3, [rsp+0x30]
00007e97133d81e4  vmovaps xmm5, [rsp+0x40]
00007e97133d81ea  vmovaps xmm6, [rsp+0x50]
00007e97133d81f0  vmovaps xmm7, [rsp+0x60]
00007e97133d81f6  vmovaps xmm8, [rsp+0x70]
00007e97133d81fc  vmovaps xmm9, [rsp+0x80]
00007e97133d8205  vmovaps xmm10, [rsp+0x90]
00007e97133d820e  vmovaps xmm11, [rsp+0xA0]
00007e97133d8217  vmovaps xmm12, [rsp+0xB0]
00007e97133d8220  vmovaps xmm13, [rsp+0xC0]
00007e97133d8229  vmovaps xmm14, [rsp+0xD0]
00007e97133d8232  vmovaps xmm15, [rsp+0xE0]
00007e97133d823b  add rsp, 0xF0
00007e97133d8242  pop r11
00007e97133d8244  pop r10
00007e97133d8246  pop r9
00007e97133d8248  pop r8
00007e97133d824a  pop rsi
00007e97133d824b  pop rdi
00007e97133d824c  pop rdx
00007e97133d824d  pop rcx
00007e97133d824e  pop rax
00007e97133d824f  add rsp, 0x08
00007e97133d8253  jmp 0x00007E97133D5F54
00007e97133d8258  call 0x00007E97132D64F0
00007e97133d825d  jmp 0x00007E97133D5F61
00007e97133d8262  sub rsp, 0x08
00007e97133d8266  push rax
00007e97133d8267  push rcx
00007e97133d8268  push rdx
00007e97133d8269  push rdi
00007e97133d826a  push rsi
00007e97133d826b  push r8
00007e97133d826d  push r9
00007e97133d826f  push r10
00007e97133d8271  push r11
00007e97133d8273  sub rsp, 0xF0
00007e97133d827a  vmovaps [rsp], xmm0
00007e97133d827f  vmovaps [rsp+0x10], xmm1
00007e97133d8285  vmovaps [rsp+0x20], xmm2
00007e97133d828b  vmovaps [rsp+0x30], xmm3
00007e97133d8291  vmovaps [rsp+0x40], xmm4
00007e97133d8297  vmovaps [rsp+0x50], xmm6
00007e97133d829d  vmovaps [rsp+0x60], xmm7
00007e97133d82a3  vmovaps [rsp+0x70], xmm8
00007e97133d82a9  vmovaps [rsp+0x80], xmm9
00007e97133d82b2  vmovaps [rsp+0x90], xmm10
00007e97133d82bb  vmovaps [rsp+0xA0], xmm11
00007e97133d82c4  vmovaps [rsp+0xB0], xmm12
00007e97133d82cd  vmovaps [rsp+0xC0], xmm13
00007e97133d82d6  vmovaps [rsp+0xD0], xmm14
00007e97133d82df  vmovaps [rsp+0xE0], xmm15
00007e97133d82e8  sub rsp, 0x30
00007e97133d82ec  movaps [rsp], xmm5
00007e97133d82f0  movaps [rsp+0x10], xmm6
00007e97133d82f5  movaps [rsp+0x20], xmm3
00007e97133d82fa  lea rdi, [rsp]
00007e97133d82fe  mov esi, 0x00
00007e97133d8303  mov rax, 0x58D8AED5F530
00007e97133d830d  call rax
00007e97133d830f  movaps xmm5, [rsp]
00007e97133d8313  add rsp, 0x30
00007e97133d8317  vmovaps xmm0, [rsp]
00007e97133d831c  vmovaps xmm1, [rsp+0x10]
00007e97133d8322  vmovaps xmm2, [rsp+0x20]
00007e97133d8328  vmovaps xmm3, [rsp+0x30]
00007e97133d832e  vmovaps xmm4, [rsp+0x40]
00007e97133d8334  vmovaps xmm6, [rsp+0x50]
00007e97133d833a  vmovaps xmm7, [rsp+0x60]
00007e97133d8340  vmovaps xmm8, [rsp+0x70]
00007e97133d8346  vmovaps xmm9, [rsp+0x80]
00007e97133d834f  vmovaps xmm10, [rsp+0x90]
00007e97133d8358  vmovaps xmm11, [rsp+0xA0]
00007e97133d8361  vmovaps xmm12, [rsp+0xB0]
00007e97133d836a  vmovaps xmm13, [rsp+0xC0]
00007e97133d8373  vmovaps xmm14, [rsp+0xD0]
00007e97133d837c  vmovaps xmm15, [rsp+0xE0]
00007e97133d8385  add rsp, 0xF0
00007e97133d838c  pop r11
00007e97133d838e  pop r10
00007e97133d8390  pop r9
00007e97133d8392  pop r8
00007e97133d8394  pop rsi
00007e97133d8395  pop rdi
00007e97133d8396  pop rdx
00007e97133d8397  pop rcx
00007e97133d8398  pop rax
00007e97133d8399  add rsp, 0x08
00007e97133d839d  jmp 0x00007E97133D5F87
00007e97133d83a2  sub rsp, 0x08
00007e97133d83a6  push rax
00007e97133d83a7  push rcx
00007e97133d83a8  push rdx
00007e97133d83a9  push rdi
00007e97133d83aa  push rsi
00007e97133d83ab  push r8
00007e97133d83ad  push r9
00007e97133d83af  push r10
00007e97133d83b1  push r11
00007e97133d83b3  sub rsp, 0xF0
00007e97133d83ba  vmovaps [rsp], xmm0
00007e97133d83bf  vmovaps [rsp+0x10], xmm1
00007e97133d83c5  vmovaps [rsp+0x20], xmm2
00007e97133d83cb  vmovaps [rsp+0x30], xmm3
00007e97133d83d1  vmovaps [rsp+0x40], xmm4
00007e97133d83d7  vmovaps [rsp+0x50], xmm5
00007e97133d83dd  vmovaps [rsp+0x60], xmm7
00007e97133d83e3  vmovaps [rsp+0x70], xmm8
00007e97133d83e9  vmovaps [rsp+0x80], xmm9
00007e97133d83f2  vmovaps [rsp+0x90], xmm10
00007e97133d83fb  vmovaps [rsp+0xA0], xmm11
00007e97133d8404  vmovaps [rsp+0xB0], xmm12
00007e97133d840d  vmovaps [rsp+0xC0], xmm13
00007e97133d8416  vmovaps [rsp+0xD0], xmm14
00007e97133d841f  vmovaps [rsp+0xE0], xmm15
00007e97133d8428  sub rsp, 0x30
00007e97133d842c  movaps [rsp], xmm6
00007e97133d8430  movaps [rsp+0x10], xmm9
00007e97133d8436  movaps [rsp+0x20], xmm1
00007e97133d843b  lea rdi, [rsp]
00007e97133d843f  mov esi, 0x00
00007e97133d8444  mov rax, 0x58D8AED5F530
00007e97133d844e  call rax
00007e97133d8450  movaps xmm6, [rsp]
00007e97133d8454  add rsp, 0x30
00007e97133d8458  vmovaps xmm0, [rsp]
00007e97133d845d  vmovaps xmm1, [rsp+0x10]
00007e97133d8463  vmovaps xmm2, [rsp+0x20]
00007e97133d8469  vmovaps xmm3, [rsp+0x30]
00007e97133d846f  vmovaps xmm4, [rsp+0x40]
00007e97133d8475  vmovaps xmm5, [rsp+0x50]
00007e97133d847b  vmovaps xmm7, [rsp+0x60]
00007e97133d8481  vmovaps xmm8, [rsp+0x70]
00007e97133d8487  vmovaps xmm9, [rsp+0x80]
00007e97133d8490  vmovaps xmm10, [rsp+0x90]
00007e97133d8499  vmovaps xmm11, [rsp+0xA0]
00007e97133d84a2  vmovaps xmm12, [rsp+0xB0]
00007e97133d84ab  vmovaps xmm13, [rsp+0xC0]
00007e97133d84b4  vmovaps xmm14, [rsp+0xD0]
00007e97133d84bd  vmovaps xmm15, [rsp+0xE0]
00007e97133d84c6  add rsp, 0xF0
00007e97133d84cd  pop r11
00007e97133d84cf  pop r10
00007e97133d84d1  pop r9
00007e97133d84d3  pop r8
00007e97133d84d5  pop rsi
00007e97133d84d6  pop rdi
00007e97133d84d7  pop rdx
00007e97133d84d8  pop rcx
00007e97133d84d9  pop rax
00007e97133d84da  add rsp, 0x08
00007e97133d84de  jmp 0x00007E97133D5FAB
00007e97133d84e3  sub rsp, 0x08
00007e97133d84e7  push rax
00007e97133d84e8  push rcx
00007e97133d84e9  push rdx
00007e97133d84ea  push rdi
00007e97133d84eb  push rsi
00007e97133d84ec  push r8
00007e97133d84ee  push r9
00007e97133d84f0  push r10
00007e97133d84f2  push r11
00007e97133d84f4  sub rsp, 0xF0
00007e97133d84fb  vmovaps [rsp], xmm0
00007e97133d8500  vmovaps [rsp+0x10], xmm1
00007e97133d8506  vmovaps [rsp+0x20], xmm2
00007e97133d850c  vmovaps [rsp+0x30], xmm3
00007e97133d8512  vmovaps [rsp+0x40], xmm4
00007e97133d8518  vmovaps [rsp+0x50], xmm5
00007e97133d851e  vmovaps [rsp+0x60], xmm6
00007e97133d8524  vmovaps [rsp+0x70], xmm7
00007e97133d852a  vmovaps [rsp+0x80], xmm8
00007e97133d8533  vmovaps [rsp+0x90], xmm10
00007e97133d853c  vmovaps [rsp+0xA0], xmm11
00007e97133d8545  vmovaps [rsp+0xB0], xmm12
00007e97133d854e  vmovaps [rsp+0xC0], xmm13
00007e97133d8557  vmovaps [rsp+0xD0], xmm14
00007e97133d8560  vmovaps [rsp+0xE0], xmm15
00007e97133d8569  sub rsp, 0x30
00007e97133d856d  movaps [rsp], xmm9
00007e97133d8572  movaps [rsp+0x10], xmm3
00007e97133d8577  movaps [rsp+0x20], xmm1
00007e97133d857c  lea rdi, [rsp]
00007e97133d8580  mov esi, 0x00
00007e97133d8585  mov rax, 0x58D8AED5F530
00007e97133d858f  call rax
00007e97133d8591  movaps xmm9, [rsp]
00007e97133d8596  add rsp, 0x30
00007e97133d859a  vmovaps xmm0, [rsp]
00007e97133d859f  vmovaps xmm1, [rsp+0x10]
00007e97133d85a5  vmovaps xmm2, [rsp+0x20]
00007e97133d85ab  vmovaps xmm3, [rsp+0x30]
00007e97133d85b1  vmovaps xmm4, [rsp+0x40]
00007e97133d85b7  vmovaps xmm5, [rsp+0x50]
00007e97133d85bd  vmovaps xmm6, [rsp+0x60]
00007e97133d85c3  vmovaps xmm7, [rsp+0x70]
00007e97133d85c9  vmovaps xmm8, [rsp+0x80]
00007e97133d85d2  vmovaps xmm10, [rsp+0x90]
00007e97133d85db  vmovaps xmm11, [rsp+0xA0]
00007e97133d85e4  vmovaps xmm12, [rsp+0xB0]
00007e97133d85ed  vmovaps xmm13, [rsp+0xC0]
00007e97133d85f6  vmovaps xmm14, [rsp+0xD0]
00007e97133d85ff  vmovaps xmm15, [rsp+0xE0]
00007e97133d8608  add rsp, 0xF0
00007e97133d860f  pop r11
00007e97133d8611  pop r10
00007e97133d8613  pop r9
00007e97133d8615  pop r8
00007e97133d8617  pop rsi
00007e97133d8618  pop rdi
00007e97133d8619  pop rdx
00007e97133d861a  pop rcx
00007e97133d861b  pop rax
00007e97133d861c  add rsp, 0x08
00007e97133d8620  jmp 0x00007E97133D5FF7
00007e97133d8625  call 0x00007E97132D64F0
00007e97133d862a  jmp 0x00007E97133D6004
00007e97133d862f  sub rsp, 0x08
00007e97133d8633  push rax
00007e97133d8634  push rcx
00007e97133d8635  push rdx
00007e97133d8636  push rdi
00007e97133d8637  push rsi
00007e97133d8638  push r8
00007e97133d863a  push r9
00007e97133d863c  push r10
00007e97133d863e  push r11
00007e97133d8640  sub rsp, 0xF0
00007e97133d8647  vmovaps [rsp], xmm0
00007e97133d864c  vmovaps [rsp+0x10], xmm1
00007e97133d8652  vmovaps [rsp+0x20], xmm2
00007e97133d8658  vmovaps [rsp+0x30], xmm3
00007e97133d865e  vmovaps [rsp+0x40], xmm4
00007e97133d8664  vmovaps [rsp+0x50], xmm5
00007e97133d866a  vmovaps [rsp+0x60], xmm6
00007e97133d8670  vmovaps [rsp+0x70], xmm7
00007e97133d8676  vmovaps [rsp+0x80], xmm8
00007e97133d867f  vmovaps [rsp+0x90], xmm9
00007e97133d8688  vmovaps [rsp+0xA0], xmm10
00007e97133d8691  vmovaps [rsp+0xB0], xmm11
00007e97133d869a  vmovaps [rsp+0xC0], xmm12
00007e97133d86a3  vmovaps [rsp+0xD0], xmm13
00007e97133d86ac  vmovaps [rsp+0xE0], xmm14
00007e97133d86b5  sub rsp, 0x30
00007e97133d86b9  movaps [rsp], xmm15
00007e97133d86be  movaps [rsp+0x10], xmm3
00007e97133d86c3  movaps [rsp+0x20], xmm7
00007e97133d86c8  lea rdi, [rsp]
00007e97133d86cc  mov esi, 0x00
00007e97133d86d1  mov rax, 0x58D8AED5F530
00007e97133d86db  call rax
00007e97133d86dd  movaps xmm15, [rsp]
00007e97133d86e2  add rsp, 0x30
00007e97133d86e6  vmovaps xmm0, [rsp]
00007e97133d86eb  vmovaps xmm1, [rsp+0x10]
00007e97133d86f1  vmovaps xmm2, [rsp+0x20]
00007e97133d86f7  vmovaps xmm3, [rsp+0x30]
00007e97133d86fd  vmovaps xmm4, [rsp+0x40]
00007e97133d8703  vmovaps xmm5, [rsp+0x50]
00007e97133d8709  vmovaps xmm6, [rsp+0x60]
00007e97133d870f  vmovaps xmm7, [rsp+0x70]
00007e97133d8715  vmovaps xmm8, [rsp+0x80]
00007e97133d871e  vmovaps xmm9, [rsp+0x90]
00007e97133d8727  vmovaps xmm10, [rsp+0xA0]
00007e97133d8730  vmovaps xmm11, [rsp+0xB0]
00007e97133d8739  vmovaps xmm12, [rsp+0xC0]
00007e97133d8742  vmovaps xmm13, [rsp+0xD0]
00007e97133d874b  vmovaps xmm14, [rsp+0xE0]
00007e97133d8754  add rsp, 0xF0
00007e97133d875b  pop r11
00007e97133d875d  pop r10
00007e97133d875f  pop r9
00007e97133d8761  pop r8
00007e97133d8763  pop rsi
00007e97133d8764  pop rdi
00007e97133d8765  pop rdx
00007e97133d8766  pop rcx
00007e97133d8767  pop rax
00007e97133d8768  add rsp, 0x08
00007e97133d876c  jmp 0x00007E97133D6030
00007e97133d8771  sub rsp, 0x08
00007e97133d8775  push rax
00007e97133d8776  push rcx
00007e97133d8777  push rdx
00007e97133d8778  push rdi
00007e97133d8779  push rsi
00007e97133d877a  push r8
00007e97133d877c  push r9
00007e97133d877e  push r10
00007e97133d8780  push r11
00007e97133d8782  sub rsp, 0xF0
00007e97133d8789  vmovaps [rsp], xmm0
00007e97133d878e  vmovaps [rsp+0x10], xmm1
00007e97133d8794  vmovaps [rsp+0x20], xmm2
00007e97133d879a  vmovaps [rsp+0x30], xmm4
00007e97133d87a0  vmovaps [rsp+0x40], xmm5
00007e97133d87a6  vmovaps [rsp+0x50], xmm6
00007e97133d87ac  vmovaps [rsp+0x60], xmm7
00007e97133d87b2  vmovaps [rsp+0x70], xmm8
00007e97133d87b8  vmovaps [rsp+0x80], xmm9
00007e97133d87c1  vmovaps [rsp+0x90], xmm10
00007e97133d87ca  vmovaps [rsp+0xA0], xmm11
00007e97133d87d3  vmovaps [rsp+0xB0], xmm12
00007e97133d87dc  vmovaps [rsp+0xC0], xmm13
00007e97133d87e5  vmovaps [rsp+0xD0], xmm14
00007e97133d87ee  vmovaps [rsp+0xE0], xmm15
00007e97133d87f7  sub rsp, 0x30
00007e97133d87fb  movaps [rsp], xmm3
00007e97133d87ff  movaps [rsp+0x10], xmm1
00007e97133d8804  movaps [rsp+0x20], xmm15
00007e97133d880a  lea rdi, [rsp]
00007e97133d880e  mov esi, 0x00
00007e97133d8813  mov rax, 0x58D8AED5F530
00007e97133d881d  call rax
00007e97133d881f  movaps xmm3, [rsp]
00007e97133d8823  add rsp, 0x30
00007e97133d8827  vmovaps xmm0, [rsp]
00007e97133d882c  vmovaps xmm1, [rsp+0x10]
00007e97133d8832  vmovaps xmm2, [rsp+0x20]
00007e97133d8838  vmovaps xmm4, [rsp+0x30]
00007e97133d883e  vmovaps xmm5, [rsp+0x40]
00007e97133d8844  vmovaps xmm6, [rsp+0x50]
00007e97133d884a  vmovaps xmm7, [rsp+0x60]
00007e97133d8850  vmovaps xmm8, [rsp+0x70]
00007e97133d8856  vmovaps xmm9, [rsp+0x80]
00007e97133d885f  vmovaps xmm10, [rsp+0x90]
00007e97133d8868  vmovaps xmm11, [rsp+0xA0]
00007e97133d8871  vmovaps xmm12, [rsp+0xB0]
00007e97133d887a  vmovaps xmm13, [rsp+0xC0]
00007e97133d8883  vmovaps xmm14, [rsp+0xD0]
00007e97133d888c  vmovaps xmm15, [rsp+0xE0]
00007e97133d8895  add rsp, 0xF0
00007e97133d889c  pop r11
00007e97133d889e  pop r10
00007e97133d88a0  pop r9
00007e97133d88a2  pop r8
00007e97133d88a4  pop rsi
00007e97133d88a5  pop rdi
00007e97133d88a6  pop rdx
00007e97133d88a7  pop rcx
00007e97133d88a8  pop rax
00007e97133d88a9  add rsp, 0x08
00007e97133d88ad  jmp 0x00007E97133D60BF
00007e97133d88b2  call 0x00007E97132D64F0
00007e97133d88b7  jmp 0x00007E97133D60C9
00007e97133d88bc  sub rsp, 0x08
00007e97133d88c0  push rax
00007e97133d88c1  push rcx
00007e97133d88c2  push rdx
00007e97133d88c3  push rdi
00007e97133d88c4  push rsi
00007e97133d88c5  push r8
00007e97133d88c7  push r9
00007e97133d88c9  push r10
00007e97133d88cb  push r11
00007e97133d88cd  sub rsp, 0xF0
00007e97133d88d4  vmovaps [rsp], xmm0
00007e97133d88d9  vmovaps [rsp+0x10], xmm1
00007e97133d88df  vmovaps [rsp+0x20], xmm2
00007e97133d88e5  vmovaps [rsp+0x30], xmm3
00007e97133d88eb  vmovaps [rsp+0x40], xmm4
00007e97133d88f1  vmovaps [rsp+0x50], xmm5
00007e97133d88f7  vmovaps [rsp+0x60], xmm6
00007e97133d88fd  vmovaps [rsp+0x70], xmm7
00007e97133d8903  vmovaps [rsp+0x80], xmm8
00007e97133d890c  vmovaps [rsp+0x90], xmm9
00007e97133d8915  vmovaps [rsp+0xA0], xmm10
00007e97133d891e  vmovaps [rsp+0xB0], xmm11
00007e97133d8927  vmovaps [rsp+0xC0], xmm12
00007e97133d8930  vmovaps [rsp+0xD0], xmm13
00007e97133d8939  vmovaps [rsp+0xE0], xmm14
00007e97133d8942  sub rsp, 0x30
00007e97133d8946  movaps [rsp], xmm15
00007e97133d894b  movaps [rsp+0x10], xmm14
00007e97133d8951  movaps [rsp+0x20], xmm4
00007e97133d8956  lea rdi, [rsp]
00007e97133d895a  mov esi, 0x00
00007e97133d895f  mov rax, 0x58D8AED5F530
00007e97133d8969  call rax
00007e97133d896b  movaps xmm15, [rsp]
00007e97133d8970  add rsp, 0x30
00007e97133d8974  vmovaps xmm0, [rsp]
00007e97133d8979  vmovaps xmm1, [rsp+0x10]
00007e97133d897f  vmovaps xmm2, [rsp+0x20]
00007e97133d8985  vmovaps xmm3, [rsp+0x30]
00007e97133d898b  vmovaps xmm4, [rsp+0x40]
00007e97133d8991  vmovaps xmm5, [rsp+0x50]
00007e97133d8997  vmovaps xmm6, [rsp+0x60]
00007e97133d899d  vmovaps xmm7, [rsp+0x70]
00007e97133d89a3  vmovaps xmm8, [rsp+0x80]
00007e97133d89ac  vmovaps xmm9, [rsp+0x90]
00007e97133d89b5  vmovaps xmm10, [rsp+0xA0]
00007e97133d89be  vmovaps xmm11, [rsp+0xB0]
00007e97133d89c7  vmovaps xmm12, [rsp+0xC0]
00007e97133d89d0  vmovaps xmm13, [rsp+0xD0]
00007e97133d89d9  vmovaps xmm14, [rsp+0xE0]
00007e97133d89e2  add rsp, 0xF0
00007e97133d89e9  pop r11
00007e97133d89eb  pop r10
00007e97133d89ed  pop r9
00007e97133d89ef  pop r8
00007e97133d89f1  pop rsi
00007e97133d89f2  pop rdi
00007e97133d89f3  pop rdx
00007e97133d89f4  pop rcx
00007e97133d89f5  pop rax
00007e97133d89f6  add rsp, 0x08
00007e97133d89fa  jmp 0x00007E97133D60F7
00007e97133d89ff  sub rsp, 0x08
00007e97133d8a03  push rax
00007e97133d8a04  push rcx
00007e97133d8a05  push rdx
00007e97133d8a06  push rdi
00007e97133d8a07  push rsi
00007e97133d8a08  push r8
00007e97133d8a0a  push r9
00007e97133d8a0c  push r10
00007e97133d8a0e  push r11
00007e97133d8a10  sub rsp, 0xF0
00007e97133d8a17  vmovaps [rsp], xmm0
00007e97133d8a1c  vmovaps [rsp+0x10], xmm1
00007e97133d8a22  vmovaps [rsp+0x20], xmm2
00007e97133d8a28  vmovaps [rsp+0x30], xmm3
00007e97133d8a2e  vmovaps [rsp+0x40], xmm4
00007e97133d8a34  vmovaps [rsp+0x50], xmm5
00007e97133d8a3a  vmovaps [rsp+0x60], xmm6
00007e97133d8a40  vmovaps [rsp+0x70], xmm7
00007e97133d8a46  vmovaps [rsp+0x80], xmm8
00007e97133d8a4f  vmovaps [rsp+0x90], xmm9
00007e97133d8a58  vmovaps [rsp+0xA0], xmm10
00007e97133d8a61  vmovaps [rsp+0xB0], xmm11
00007e97133d8a6a  vmovaps [rsp+0xC0], xmm12
00007e97133d8a73  vmovaps [rsp+0xD0], xmm13
00007e97133d8a7c  vmovaps [rsp+0xE0], xmm15
00007e97133d8a85  sub rsp, 0x30
00007e97133d8a89  movaps [rsp], xmm14
00007e97133d8a8e  movaps [rsp+0x10], xmm2
00007e97133d8a93  movaps [rsp+0x20], xmm1
00007e97133d8a98  lea rdi, [rsp]
00007e97133d8a9c  mov esi, 0x00
00007e97133d8aa1  mov rax, 0x58D8AED5F530
00007e97133d8aab  call rax
00007e97133d8aad  movaps xmm14, [rsp]
00007e97133d8ab2  add rsp, 0x30
00007e97133d8ab6  vmovaps xmm0, [rsp]
00007e97133d8abb  vmovaps xmm1, [rsp+0x10]
00007e97133d8ac1  vmovaps xmm2, [rsp+0x20]
00007e97133d8ac7  vmovaps xmm3, [rsp+0x30]
00007e97133d8acd  vmovaps xmm4, [rsp+0x40]
00007e97133d8ad3  vmovaps xmm5, [rsp+0x50]
00007e97133d8ad9  vmovaps xmm6, [rsp+0x60]
00007e97133d8adf  vmovaps xmm7, [rsp+0x70]
00007e97133d8ae5  vmovaps xmm8, [rsp+0x80]
00007e97133d8aee  vmovaps xmm9, [rsp+0x90]
00007e97133d8af7  vmovaps xmm10, [rsp+0xA0]
00007e97133d8b00  vmovaps xmm11, [rsp+0xB0]
00007e97133d8b09  vmovaps xmm12, [rsp+0xC0]
00007e97133d8b12  vmovaps xmm13, [rsp+0xD0]
00007e97133d8b1b  vmovaps xmm15, [rsp+0xE0]
00007e97133d8b24  add rsp, 0xF0
00007e97133d8b2b  pop r11
00007e97133d8b2d  pop r10
00007e97133d8b2f  pop r9
00007e97133d8b31  pop r8
00007e97133d8b33  pop rsi
00007e97133d8b34  pop rdi
00007e97133d8b35  pop rdx
00007e97133d8b36  pop rcx
00007e97133d8b37  pop rax
00007e97133d8b38  add rsp, 0x08
00007e97133d8b3c  jmp 0x00007E97133D611D
00007e97133d8b41  sub rsp, 0x08
00007e97133d8b45  push rax
00007e97133d8b46  push rcx
00007e97133d8b47  push rdx
00007e97133d8b48  push rdi
00007e97133d8b49  push rsi
00007e97133d8b4a  push r8
00007e97133d8b4c  push r9
00007e97133d8b4e  push r10
00007e97133d8b50  push r11
00007e97133d8b52  sub rsp, 0xF0
00007e97133d8b59  vmovaps [rsp], xmm0
00007e97133d8b5e  vmovaps [rsp+0x10], xmm2
00007e97133d8b64  vmovaps [rsp+0x20], xmm3
00007e97133d8b6a  vmovaps [rsp+0x30], xmm4
00007e97133d8b70  vmovaps [rsp+0x40], xmm5
00007e97133d8b76  vmovaps [rsp+0x50], xmm6
00007e97133d8b7c  vmovaps [rsp+0x60], xmm7
00007e97133d8b82  vmovaps [rsp+0x70], xmm8
00007e97133d8b88  vmovaps [rsp+0x80], xmm9
00007e97133d8b91  vmovaps [rsp+0x90], xmm10
00007e97133d8b9a  vmovaps [rsp+0xA0], xmm11
00007e97133d8ba3  vmovaps [rsp+0xB0], xmm12
00007e97133d8bac  vmovaps [rsp+0xC0], xmm13
00007e97133d8bb5  vmovaps [rsp+0xD0], xmm14
00007e97133d8bbe  vmovaps [rsp+0xE0], xmm15
00007e97133d8bc7  sub rsp, 0x30
00007e97133d8bcb  movaps [rsp], xmm1
00007e97133d8bcf  movaps [rsp+0x10], xmm4
00007e97133d8bd4  movaps [rsp+0x20], xmm9
00007e97133d8bda  lea rdi, [rsp]
00007e97133d8bde  mov esi, 0x00
00007e97133d8be3  mov rax, 0x58D8AED5F530
00007e97133d8bed  call rax
00007e97133d8bef  movaps xmm1, [rsp]
00007e97133d8bf3  add rsp, 0x30
00007e97133d8bf7  vmovaps xmm0, [rsp]
00007e97133d8bfc  vmovaps xmm2, [rsp+0x10]
00007e97133d8c02  vmovaps xmm3, [rsp+0x20]
00007e97133d8c08  vmovaps xmm4, [rsp+0x30]
00007e97133d8c0e  vmovaps xmm5, [rsp+0x40]
00007e97133d8c14  vmovaps xmm6, [rsp+0x50]
00007e97133d8c1a  vmovaps xmm7, [rsp+0x60]
00007e97133d8c20  vmovaps xmm8, [rsp+0x70]
00007e97133d8c26  vmovaps xmm9, [rsp+0x80]
00007e97133d8c2f  vmovaps xmm10, [rsp+0x90]
00007e97133d8c38  vmovaps xmm11, [rsp+0xA0]
00007e97133d8c41  vmovaps xmm12, [rsp+0xB0]
00007e97133d8c4a  vmovaps xmm13, [rsp+0xC0]
00007e97133d8c53  vmovaps xmm14, [rsp+0xD0]
00007e97133d8c5c  vmovaps xmm15, [rsp+0xE0]
00007e97133d8c65  add rsp, 0xF0
00007e97133d8c6c  pop r11
00007e97133d8c6e  pop r10
00007e97133d8c70  pop r9
00007e97133d8c72  pop r8
00007e97133d8c74  pop rsi
00007e97133d8c75  pop rdi
00007e97133d8c76  pop rdx
00007e97133d8c77  pop rcx
00007e97133d8c78  pop rax
00007e97133d8c79  add rsp, 0x08
00007e97133d8c7d  jmp 0x00007E97133D613B
00007e97133d8c82  sub rsp, 0x08
00007e97133d8c86  push rax
00007e97133d8c87  push rcx
00007e97133d8c88  push rdx
00007e97133d8c89  push rdi
00007e97133d8c8a  push rsi
00007e97133d8c8b  push r8
00007e97133d8c8d  push r9
00007e97133d8c8f  push r10
00007e97133d8c91  push r11
00007e97133d8c93  sub rsp, 0xF0
00007e97133d8c9a  vmovaps [rsp], xmm0
00007e97133d8c9f  vmovaps [rsp+0x10], xmm1
00007e97133d8ca5  vmovaps [rsp+0x20], xmm2
00007e97133d8cab  vmovaps [rsp+0x30], xmm3
00007e97133d8cb1  vmovaps [rsp+0x40], xmm5
00007e97133d8cb7  vmovaps [rsp+0x50], xmm6
00007e97133d8cbd  vmovaps [rsp+0x60], xmm7
00007e97133d8cc3  vmovaps [rsp+0x70], xmm8
00007e97133d8cc9  vmovaps [rsp+0x80], xmm9
00007e97133d8cd2  vmovaps [rsp+0x90], xmm10
00007e97133d8cdb  vmovaps [rsp+0xA0], xmm11
00007e97133d8ce4  vmovaps [rsp+0xB0], xmm12
00007e97133d8ced  vmovaps [rsp+0xC0], xmm13
00007e97133d8cf6  vmovaps [rsp+0xD0], xmm14
00007e97133d8cff  vmovaps [rsp+0xE0], xmm15
00007e97133d8d08  sub rsp, 0x30
00007e97133d8d0c  movaps [rsp], xmm4
00007e97133d8d10  movaps [rsp+0x10], xmm2
00007e97133d8d15  movaps [rsp+0x20], xmm9
00007e97133d8d1b  lea rdi, [rsp]
00007e97133d8d1f  mov esi, 0x00
00007e97133d8d24  mov rax, 0x58D8AED5F530
00007e97133d8d2e  call rax
00007e97133d8d30  movaps xmm4, [rsp]
00007e97133d8d34  add rsp, 0x30
00007e97133d8d38  vmovaps xmm0, [rsp]
00007e97133d8d3d  vmovaps xmm1, [rsp+0x10]
00007e97133d8d43  vmovaps xmm2, [rsp+0x20]
00007e97133d8d49  vmovaps xmm3, [rsp+0x30]
00007e97133d8d4f  vmovaps xmm5, [rsp+0x40]
00007e97133d8d55  vmovaps xmm6, [rsp+0x50]
00007e97133d8d5b  vmovaps xmm7, [rsp+0x60]
00007e97133d8d61  vmovaps xmm8, [rsp+0x70]
00007e97133d8d67  vmovaps xmm9, [rsp+0x80]
00007e97133d8d70  vmovaps xmm10, [rsp+0x90]
00007e97133d8d79  vmovaps xmm11, [rsp+0xA0]
00007e97133d8d82  vmovaps xmm12, [rsp+0xB0]
00007e97133d8d8b  vmovaps xmm13, [rsp+0xC0]
00007e97133d8d94  vmovaps xmm14, [rsp+0xD0]
00007e97133d8d9d  vmovaps xmm15, [rsp+0xE0]
00007e97133d8da6  add rsp, 0xF0
00007e97133d8dad  pop r11
00007e97133d8daf  pop r10
00007e97133d8db1  pop r9
00007e97133d8db3  pop r8
00007e97133d8db5  pop rsi
00007e97133d8db6  pop rdi
00007e97133d8db7  pop rdx
00007e97133d8db8  pop rcx
00007e97133d8db9  pop rax
00007e97133d8dba  add rsp, 0x08
00007e97133d8dbe  jmp 0x00007E97133D616B
00007e97133d8dc3  sub rsp, 0x08
00007e97133d8dc7  push rax
00007e97133d8dc8  push rcx
00007e97133d8dc9  push rdx
00007e97133d8dca  push rdi
00007e97133d8dcb  push rsi
00007e97133d8dcc  push r8
00007e97133d8dce  push r9
00007e97133d8dd0  push r10
00007e97133d8dd2  push r11
00007e97133d8dd4  sub rsp, 0xF0
00007e97133d8ddb  vmovaps [rsp], xmm0
00007e97133d8de0  vmovaps [rsp+0x10], xmm1
00007e97133d8de6  vmovaps [rsp+0x20], xmm2
00007e97133d8dec  vmovaps [rsp+0x30], xmm3
00007e97133d8df2  vmovaps [rsp+0x40], xmm4
00007e97133d8df8  vmovaps [rsp+0x50], xmm5
00007e97133d8dfe  vmovaps [rsp+0x60], xmm6
00007e97133d8e04  vmovaps [rsp+0x70], xmm7
00007e97133d8e0a  vmovaps [rsp+0x80], xmm8
00007e97133d8e13  vmovaps [rsp+0x90], xmm10
00007e97133d8e1c  vmovaps [rsp+0xA0], xmm11
00007e97133d8e25  vmovaps [rsp+0xB0], xmm12
00007e97133d8e2e  vmovaps [rsp+0xC0], xmm13
00007e97133d8e37  vmovaps [rsp+0xD0], xmm14
00007e97133d8e40  vmovaps [rsp+0xE0], xmm15
00007e97133d8e49  sub rsp, 0x30
00007e97133d8e4d  movaps [rsp], xmm9
00007e97133d8e52  movaps [rsp+0x10], xmm2
00007e97133d8e57  movaps [rsp+0x20], xmm1
00007e97133d8e5c  lea rdi, [rsp]
00007e97133d8e60  mov esi, 0x00
00007e97133d8e65  mov rax, 0x58D8AED5F530
00007e97133d8e6f  call rax
00007e97133d8e71  movaps xmm9, [rsp]
00007e97133d8e76  add rsp, 0x30
00007e97133d8e7a  vmovaps xmm0, [rsp]
00007e97133d8e7f  vmovaps xmm1, [rsp+0x10]
00007e97133d8e85  vmovaps xmm2, [rsp+0x20]
00007e97133d8e8b  vmovaps xmm3, [rsp+0x30]
00007e97133d8e91  vmovaps xmm4, [rsp+0x40]
00007e97133d8e97  vmovaps xmm5, [rsp+0x50]
00007e97133d8e9d  vmovaps xmm6, [rsp+0x60]
00007e97133d8ea3  vmovaps xmm7, [rsp+0x70]
00007e97133d8ea9  vmovaps xmm8, [rsp+0x80]
00007e97133d8eb2  vmovaps xmm10, [rsp+0x90]
00007e97133d8ebb  vmovaps xmm11, [rsp+0xA0]
00007e97133d8ec4  vmovaps xmm12, [rsp+0xB0]
00007e97133d8ecd  vmovaps xmm13, [rsp+0xC0]
00007e97133d8ed6  vmovaps xmm14, [rsp+0xD0]
00007e97133d8edf  vmovaps xmm15, [rsp+0xE0]
00007e97133d8ee8  add rsp, 0xF0
00007e97133d8eef  pop r11
00007e97133d8ef1  pop r10
00007e97133d8ef3  pop r9
00007e97133d8ef5  pop r8
00007e97133d8ef7  pop rsi
00007e97133d8ef8  pop rdi
00007e97133d8ef9  pop rdx
00007e97133d8efa  pop rcx
00007e97133d8efb  pop rax
00007e97133d8efc  add rsp, 0x08
00007e97133d8f00  jmp 0x00007E97133D61A1
00007e97133d8f05  sub rsp, 0x08
00007e97133d8f09  push rax
00007e97133d8f0a  push rcx
00007e97133d8f0b  push rdx
00007e97133d8f0c  push rdi
00007e97133d8f0d  push rsi
00007e97133d8f0e  push r8
00007e97133d8f10  push r9
00007e97133d8f12  push r10
00007e97133d8f14  push r11
00007e97133d8f16  sub rsp, 0xF0
00007e97133d8f1d  vmovaps [rsp], xmm0
00007e97133d8f22  vmovaps [rsp+0x10], xmm2
00007e97133d8f28  vmovaps [rsp+0x20], xmm3
00007e97133d8f2e  vmovaps [rsp+0x30], xmm4
00007e97133d8f34  vmovaps [rsp+0x40], xmm5
00007e97133d8f3a  vmovaps [rsp+0x50], xmm6
00007e97133d8f40  vmovaps [rsp+0x60], xmm7
00007e97133d8f46  vmovaps [rsp+0x70], xmm8
00007e97133d8f4c  vmovaps [rsp+0x80], xmm9
00007e97133d8f55  vmovaps [rsp+0x90], xmm10
00007e97133d8f5e  vmovaps [rsp+0xA0], xmm11
00007e97133d8f67  vmovaps [rsp+0xB0], xmm12
00007e97133d8f70  vmovaps [rsp+0xC0], xmm13
00007e97133d8f79  vmovaps [rsp+0xD0], xmm14
00007e97133d8f82  vmovaps [rsp+0xE0], xmm15
00007e97133d8f8b  sub rsp, 0x30
00007e97133d8f8f  movaps [rsp], xmm1
00007e97133d8f93  movaps [rsp+0x10], xmm15
00007e97133d8f99  movaps [rsp+0x20], xmm6
00007e97133d8f9e  lea rdi, [rsp]
00007e97133d8fa2  mov esi, 0x00
00007e97133d8fa7  mov rax, 0x58D8AED5F530
00007e97133d8fb1  call rax
00007e97133d8fb3  movaps xmm1, [rsp]
00007e97133d8fb7  add rsp, 0x30
00007e97133d8fbb  vmovaps xmm0, [rsp]
00007e97133d8fc0  vmovaps xmm2, [rsp+0x10]
00007e97133d8fc6  vmovaps xmm3, [rsp+0x20]
00007e97133d8fcc  vmovaps xmm4, [rsp+0x30]
00007e97133d8fd2  vmovaps xmm5, [rsp+0x40]
00007e97133d8fd8  vmovaps xmm6, [rsp+0x50]
00007e97133d8fde  vmovaps xmm7, [rsp+0x60]
00007e97133d8fe4  vmovaps xmm8, [rsp+0x70]
00007e97133d8fea  vmovaps xmm9, [rsp+0x80]
00007e97133d8ff3  vmovaps xmm10, [rsp+0x90]
00007e97133d8ffc  vmovaps xmm11, [rsp+0xA0]
00007e97133d9005  vmovaps xmm12, [rsp+0xB0]
00007e97133d900e  vmovaps xmm13, [rsp+0xC0]
00007e97133d9017  vmovaps xmm14, [rsp+0xD0]
00007e97133d9020  vmovaps xmm15, [rsp+0xE0]
00007e97133d9029  add rsp, 0xF0
00007e97133d9030  pop r11
00007e97133d9032  pop r10
00007e97133d9034  pop r9
00007e97133d9036  pop r8
00007e97133d9038  pop rsi
00007e97133d9039  pop rdi
00007e97133d903a  pop rdx
00007e97133d903b  pop rcx
00007e97133d903c  pop rax
00007e97133d903d  add rsp, 0x08
00007e97133d9041  jmp 0x00007E97133D61C2
00007e97133d9046  sub rsp, 0x08
00007e97133d904a  push rax
00007e97133d904b  push rcx
00007e97133d904c  push rdx
00007e97133d904d  push rdi
00007e97133d904e  push rsi
00007e97133d904f  push r8
00007e97133d9051  push r9
00007e97133d9053  push r10
00007e97133d9055  push r11
00007e97133d9057  sub rsp, 0xF0
00007e97133d905e  vmovaps [rsp], xmm0
00007e97133d9063  vmovaps [rsp+0x10], xmm1
00007e97133d9069  vmovaps [rsp+0x20], xmm2
00007e97133d906f  vmovaps [rsp+0x30], xmm3
00007e97133d9075  vmovaps [rsp+0x40], xmm4
00007e97133d907b  vmovaps [rsp+0x50], xmm5
00007e97133d9081  vmovaps [rsp+0x60], xmm6
00007e97133d9087  vmovaps [rsp+0x70], xmm7
00007e97133d908d  vmovaps [rsp+0x80], xmm8
00007e97133d9096  vmovaps [rsp+0x90], xmm9
00007e97133d909f  vmovaps [rsp+0xA0], xmm10
00007e97133d90a8  vmovaps [rsp+0xB0], xmm11
00007e97133d90b1  vmovaps [rsp+0xC0], xmm12
00007e97133d90ba  vmovaps [rsp+0xD0], xmm13
00007e97133d90c3  vmovaps [rsp+0xE0], xmm14
00007e97133d90cc  sub rsp, 0x30
00007e97133d90d0  movaps [rsp], xmm15
00007e97133d90d5  movaps [rsp+0x10], xmm5
00007e97133d90da  movaps [rsp+0x20], xmm3
00007e97133d90df  lea rdi, [rsp]
00007e97133d90e3  mov esi, 0x00
00007e97133d90e8  mov rax, 0x58D8AED5F530
00007e97133d90f2  call rax
00007e97133d90f4  movaps xmm15, [rsp]
00007e97133d90f9  add rsp, 0x30
00007e97133d90fd  vmovaps xmm0, [rsp]
00007e97133d9102  vmovaps xmm1, [rsp+0x10]
00007e97133d9108  vmovaps xmm2, [rsp+0x20]
00007e97133d910e  vmovaps xmm3, [rsp+0x30]
00007e97133d9114  vmovaps xmm4, [rsp+0x40]
00007e97133d911a  vmovaps xmm5, [rsp+0x50]
00007e97133d9120  vmovaps xmm6, [rsp+0x60]
00007e97133d9126  vmovaps xmm7, [rsp+0x70]
00007e97133d912c  vmovaps xmm8, [rsp+0x80]
00007e97133d9135  vmovaps xmm9, [rsp+0x90]
00007e97133d913e  vmovaps xmm10, [rsp+0xA0]
00007e97133d9147  vmovaps xmm11, [rsp+0xB0]
00007e97133d9150  vmovaps xmm12, [rsp+0xC0]
00007e97133d9159  vmovaps xmm13, [rsp+0xD0]
00007e97133d9162  vmovaps xmm14, [rsp+0xE0]
00007e97133d916b  add rsp, 0xF0
00007e97133d9172  pop r11
00007e97133d9174  pop r10
00007e97133d9176  pop r9
00007e97133d9178  pop r8
00007e97133d917a  pop rsi
00007e97133d917b  pop rdi
00007e97133d917c  pop rdx
00007e97133d917d  pop rcx
00007e97133d917e  pop rax
00007e97133d917f  add rsp, 0x08
00007e97133d9183  jmp 0x00007E97133D61DC
00007e97133d9188  sub rsp, 0x08
00007e97133d918c  push rax
00007e97133d918d  push rcx
00007e97133d918e  push rdx
00007e97133d918f  push rdi
00007e97133d9190  push rsi
00007e97133d9191  push r8
00007e97133d9193  push r9
00007e97133d9195  push r10
00007e97133d9197  push r11
00007e97133d9199  sub rsp, 0xF0
00007e97133d91a0  vmovaps [rsp], xmm0
00007e97133d91a5  vmovaps [rsp+0x10], xmm1
00007e97133d91ab  vmovaps [rsp+0x20], xmm2
00007e97133d91b1  vmovaps [rsp+0x30], xmm3
00007e97133d91b7  vmovaps [rsp+0x40], xmm4
00007e97133d91bd  vmovaps [rsp+0x50], xmm6
00007e97133d91c3  vmovaps [rsp+0x60], xmm7
00007e97133d91c9  vmovaps [rsp+0x70], xmm8
00007e97133d91cf  vmovaps [rsp+0x80], xmm9
00007e97133d91d8  vmovaps [rsp+0x90], xmm10
00007e97133d91e1  vmovaps [rsp+0xA0], xmm11
00007e97133d91ea  vmovaps [rsp+0xB0], xmm12
00007e97133d91f3  vmovaps [rsp+0xC0], xmm13
00007e97133d91fc  vmovaps [rsp+0xD0], xmm14
00007e97133d9205  vmovaps [rsp+0xE0], xmm15
00007e97133d920e  sub rsp, 0x30
00007e97133d9212  movaps [rsp], xmm5
00007e97133d9216  movaps [rsp+0x10], xmm8
00007e97133d921c  movaps [rsp+0x20], xmm6
00007e97133d9221  lea rdi, [rsp]
00007e97133d9225  mov esi, 0x00
00007e97133d922a  mov rax, 0x58D8AED5F530
00007e97133d9234  call rax
00007e97133d9236  movaps xmm5, [rsp]
00007e97133d923a  add rsp, 0x30
00007e97133d923e  vmovaps xmm0, [rsp]
00007e97133d9243  vmovaps xmm1, [rsp+0x10]
00007e97133d9249  vmovaps xmm2, [rsp+0x20]
00007e97133d924f  vmovaps xmm3, [rsp+0x30]
00007e97133d9255  vmovaps xmm4, [rsp+0x40]
00007e97133d925b  vmovaps xmm6, [rsp+0x50]
00007e97133d9261  vmovaps xmm7, [rsp+0x60]
00007e97133d9267  vmovaps xmm8, [rsp+0x70]
00007e97133d926d  vmovaps xmm9, [rsp+0x80]
00007e97133d9276  vmovaps xmm10, [rsp+0x90]
00007e97133d927f  vmovaps xmm11, [rsp+0xA0]
00007e97133d9288  vmovaps xmm12, [rsp+0xB0]
00007e97133d9291  vmovaps xmm13, [rsp+0xC0]
00007e97133d929a  vmovaps xmm14, [rsp+0xD0]
00007e97133d92a3  vmovaps xmm15, [rsp+0xE0]
00007e97133d92ac  add rsp, 0xF0
00007e97133d92b3  pop r11
00007e97133d92b5  pop r10
00007e97133d92b7  pop r9
00007e97133d92b9  pop r8
00007e97133d92bb  pop rsi
00007e97133d92bc  pop rdi
00007e97133d92bd  pop rdx
00007e97133d92be  pop rcx
00007e97133d92bf  pop rax
00007e97133d92c0  add rsp, 0x08
00007e97133d92c4  jmp 0x00007E97133D6200
00007e97133d92c9  sub rsp, 0x08
00007e97133d92cd  push rax
00007e97133d92ce  push rcx
00007e97133d92cf  push rdx
00007e97133d92d0  push rdi
00007e97133d92d1  push rsi
00007e97133d92d2  push r8
00007e97133d92d4  push r9
00007e97133d92d6  push r10
00007e97133d92d8  push r11
00007e97133d92da  sub rsp, 0xF0
00007e97133d92e1  vmovaps [rsp], xmm0
00007e97133d92e6  vmovaps [rsp+0x10], xmm1
00007e97133d92ec  vmovaps [rsp+0x20], xmm2
00007e97133d92f2  vmovaps [rsp+0x30], xmm3
00007e97133d92f8  vmovaps [rsp+0x40], xmm4
00007e97133d92fe  vmovaps [rsp+0x50], xmm5
00007e97133d9304  vmovaps [rsp+0x60], xmm7
00007e97133d930a  vmovaps [rsp+0x70], xmm8
00007e97133d9310  vmovaps [rsp+0x80], xmm9
00007e97133d9319  vmovaps [rsp+0x90], xmm10
00007e97133d9322  vmovaps [rsp+0xA0], xmm11
00007e97133d932b  vmovaps [rsp+0xB0], xmm12
00007e97133d9334  vmovaps [rsp+0xC0], xmm13
00007e97133d933d  vmovaps [rsp+0xD0], xmm14
00007e97133d9346  vmovaps [rsp+0xE0], xmm15
00007e97133d934f  sub rsp, 0x30
00007e97133d9353  movaps [rsp], xmm6
00007e97133d9357  movaps [rsp+0x10], xmm10
00007e97133d935d  movaps [rsp+0x20], xmm8
00007e97133d9363  lea rdi, [rsp]
00007e97133d9367  mov esi, 0x00
00007e97133d936c  mov rax, 0x58D8AED5F530
00007e97133d9376  call rax
00007e97133d9378  movaps xmm6, [rsp]
00007e97133d937c  add rsp, 0x30
00007e97133d9380  vmovaps xmm0, [rsp]
00007e97133d9385  vmovaps xmm1, [rsp+0x10]
00007e97133d938b  vmovaps xmm2, [rsp+0x20]
00007e97133d9391  vmovaps xmm3, [rsp+0x30]
00007e97133d9397  vmovaps xmm4, [rsp+0x40]
00007e97133d939d  vmovaps xmm5, [rsp+0x50]
00007e97133d93a3  vmovaps xmm7, [rsp+0x60]
00007e97133d93a9  vmovaps xmm8, [rsp+0x70]
00007e97133d93af  vmovaps xmm9, [rsp+0x80]
00007e97133d93b8  vmovaps xmm10, [rsp+0x90]
00007e97133d93c1  vmovaps xmm11, [rsp+0xA0]
00007e97133d93ca  vmovaps xmm12, [rsp+0xB0]
00007e97133d93d3  vmovaps xmm13, [rsp+0xC0]
00007e97133d93dc  vmovaps xmm14, [rsp+0xD0]
00007e97133d93e5  vmovaps xmm15, [rsp+0xE0]
00007e97133d93ee  add rsp, 0xF0
00007e97133d93f5  pop r11
00007e97133d93f7  pop r10
00007e97133d93f9  pop r9
00007e97133d93fb  pop r8
00007e97133d93fd  pop rsi
00007e97133d93fe  pop rdi
00007e97133d93ff  pop rdx
00007e97133d9400  pop rcx
00007e97133d9401  pop rax
00007e97133d9402  add rsp, 0x08
00007e97133d9406  jmp 0x00007E97133D6225
00007e97133d940b  sub rsp, 0x08
00007e97133d940f  push rax
00007e97133d9410  push rcx
00007e97133d9411  push rdx
00007e97133d9412  push rdi
00007e97133d9413  push rsi
00007e97133d9414  push r8
00007e97133d9416  push r9
00007e97133d9418  push r10
00007e97133d941a  push r11
00007e97133d941c  sub rsp, 0xF0
00007e97133d9423  vmovaps [rsp], xmm0
00007e97133d9428  vmovaps [rsp+0x10], xmm1
00007e97133d942e  vmovaps [rsp+0x20], xmm2
00007e97133d9434  vmovaps [rsp+0x30], xmm3
00007e97133d943a  vmovaps [rsp+0x40], xmm4
00007e97133d9440  vmovaps [rsp+0x50], xmm5
00007e97133d9446  vmovaps [rsp+0x60], xmm6
00007e97133d944c  vmovaps [rsp+0x70], xmm7
00007e97133d9452  vmovaps [rsp+0x80], xmm8
00007e97133d945b  vmovaps [rsp+0x90], xmm9
00007e97133d9464  vmovaps [rsp+0xA0], xmm11
00007e97133d946d  vmovaps [rsp+0xB0], xmm12
00007e97133d9476  vmovaps [rsp+0xC0], xmm13
00007e97133d947f  vmovaps [rsp+0xD0], xmm14
00007e97133d9488  vmovaps [rsp+0xE0], xmm15
00007e97133d9491  sub rsp, 0x30
00007e97133d9495  movaps [rsp], xmm10
00007e97133d949a  movaps [rsp+0x10], xmm8
00007e97133d94a0  movaps [rsp+0x20], xmm14
00007e97133d94a6  lea rdi, [rsp]
00007e97133d94aa  mov esi, 0x00
00007e97133d94af  mov rax, 0x58D8AED5F530
00007e97133d94b9  call rax
00007e97133d94bb  movaps xmm10, [rsp]
00007e97133d94c0  add rsp, 0x30
00007e97133d94c4  vmovaps xmm0, [rsp]
00007e97133d94c9  vmovaps xmm1, [rsp+0x10]
00007e97133d94cf  vmovaps xmm2, [rsp+0x20]
00007e97133d94d5  vmovaps xmm3, [rsp+0x30]
00007e97133d94db  vmovaps xmm4, [rsp+0x40]
00007e97133d94e1  vmovaps xmm5, [rsp+0x50]
00007e97133d94e7  vmovaps xmm6, [rsp+0x60]
00007e97133d94ed  vmovaps xmm7, [rsp+0x70]
00007e97133d94f3  vmovaps xmm8, [rsp+0x80]
00007e97133d94fc  vmovaps xmm9, [rsp+0x90]
00007e97133d9505  vmovaps xmm11, [rsp+0xA0]
00007e97133d950e  vmovaps xmm12, [rsp+0xB0]
00007e97133d9517  vmovaps xmm13, [rsp+0xC0]
00007e97133d9520  vmovaps xmm14, [rsp+0xD0]
00007e97133d9529  vmovaps xmm15, [rsp+0xE0]
00007e97133d9532  add rsp, 0xF0
00007e97133d9539  pop r11
00007e97133d953b  pop r10
00007e97133d953d  pop r9
00007e97133d953f  pop r8
00007e97133d9541  pop rsi
00007e97133d9542  pop rdi
00007e97133d9543  pop rdx
00007e97133d9544  pop rcx
00007e97133d9545  pop rax
00007e97133d9546  add rsp, 0x08
00007e97133d954a  jmp 0x00007E97133D6245
00007e97133d954f  sub rsp, 0x08
00007e97133d9553  push rax
00007e97133d9554  push rcx
00007e97133d9555  push rdx
00007e97133d9556  push rdi
00007e97133d9557  push rsi
00007e97133d9558  push r8
00007e97133d955a  push r9
00007e97133d955c  push r10
00007e97133d955e  push r11
00007e97133d9560  sub rsp, 0xF0
00007e97133d9567  vmovaps [rsp], xmm0
00007e97133d956c  vmovaps [rsp+0x10], xmm1
00007e97133d9572  vmovaps [rsp+0x20], xmm2
00007e97133d9578  vmovaps [rsp+0x30], xmm3
00007e97133d957e  vmovaps [rsp+0x40], xmm4
00007e97133d9584  vmovaps [rsp+0x50], xmm5
00007e97133d958a  vmovaps [rsp+0x60], xmm6
00007e97133d9590  vmovaps [rsp+0x70], xmm7
00007e97133d9596  vmovaps [rsp+0x80], xmm8
00007e97133d959f  vmovaps [rsp+0x90], xmm9
00007e97133d95a8  vmovaps [rsp+0xA0], xmm10
00007e97133d95b1  vmovaps [rsp+0xB0], xmm11
00007e97133d95ba  vmovaps [rsp+0xC0], xmm12
00007e97133d95c3  vmovaps [rsp+0xD0], xmm13
00007e97133d95cc  vmovaps [rsp+0xE0], xmm15
00007e97133d95d5  sub rsp, 0x30
00007e97133d95d9  movaps [rsp], xmm14
00007e97133d95de  movaps [rsp+0x10], xmm8
00007e97133d95e4  movaps [rsp+0x20], xmm4
00007e97133d95e9  lea rdi, [rsp]
00007e97133d95ed  mov esi, 0x00
00007e97133d95f2  mov rax, 0x58D8AED5F530
00007e97133d95fc  call rax
00007e97133d95fe  movaps xmm14, [rsp]
00007e97133d9603  add rsp, 0x30
00007e97133d9607  vmovaps xmm0, [rsp]
00007e97133d960c  vmovaps xmm1, [rsp+0x10]
00007e97133d9612  vmovaps xmm2, [rsp+0x20]
00007e97133d9618  vmovaps xmm3, [rsp+0x30]
00007e97133d961e  vmovaps xmm4, [rsp+0x40]
00007e97133d9624  vmovaps xmm5, [rsp+0x50]
00007e97133d962a  vmovaps xmm6, [rsp+0x60]
00007e97133d9630  vmovaps xmm7, [rsp+0x70]
00007e97133d9636  vmovaps xmm8, [rsp+0x80]
00007e97133d963f  vmovaps xmm9, [rsp+0x90]
00007e97133d9648  vmovaps xmm10, [rsp+0xA0]
00007e97133d9651  vmovaps xmm11, [rsp+0xB0]
00007e97133d965a  vmovaps xmm12, [rsp+0xC0]
00007e97133d9663  vmovaps xmm13, [rsp+0xD0]
00007e97133d966c  vmovaps xmm15, [rsp+0xE0]
00007e97133d9675  add rsp, 0xF0
00007e97133d967c  pop r11
00007e97133d967e  pop r10
00007e97133d9680  pop r9
00007e97133d9682  pop r8
00007e97133d9684  pop rsi
00007e97133d9685  pop rdi
00007e97133d9686  pop rdx
00007e97133d9687  pop rcx
00007e97133d9688  pop rax
00007e97133d9689  add rsp, 0x08
00007e97133d968d  jmp 0x00007E97133D6265
00007e97133d9692  sub rsp, 0x08
00007e97133d9696  push rax
00007e97133d9697  push rcx
00007e97133d9698  push rdx
00007e97133d9699  push rdi
00007e97133d969a  push rsi
00007e97133d969b  push r8
00007e97133d969d  push r9
00007e97133d969f  push r10
00007e97133d96a1  push r11
00007e97133d96a3  sub rsp, 0xF0
00007e97133d96aa  vmovaps [rsp], xmm0
00007e97133d96af  vmovaps [rsp+0x10], xmm1
00007e97133d96b5  vmovaps [rsp+0x20], xmm2
00007e97133d96bb  vmovaps [rsp+0x30], xmm3
00007e97133d96c1  vmovaps [rsp+0x40], xmm5
00007e97133d96c7  vmovaps [rsp+0x50], xmm6
00007e97133d96cd  vmovaps [rsp+0x60], xmm7
00007e97133d96d3  vmovaps [rsp+0x70], xmm8
00007e97133d96d9  vmovaps [rsp+0x80], xmm9
00007e97133d96e2  vmovaps [rsp+0x90], xmm10
00007e97133d96eb  vmovaps [rsp+0xA0], xmm11
00007e97133d96f4  vmovaps [rsp+0xB0], xmm12
00007e97133d96fd  vmovaps [rsp+0xC0], xmm13
00007e97133d9706  vmovaps [rsp+0xD0], xmm14
00007e97133d970f  vmovaps [rsp+0xE0], xmm15
00007e97133d9718  sub rsp, 0x30
00007e97133d971c  movaps [rsp], xmm4
00007e97133d9720  movaps [rsp+0x10], xmm13
00007e97133d9726  movaps [rsp+0x20], xmm8
00007e97133d972c  lea rdi, [rsp]
00007e97133d9730  mov esi, 0x00
00007e97133d9735  mov rax, 0x58D8AED5F530
00007e97133d973f  call rax
00007e97133d9741  movaps xmm4, [rsp]
00007e97133d9745  add rsp, 0x30
00007e97133d9749  vmovaps xmm0, [rsp]
00007e97133d974e  vmovaps xmm1, [rsp+0x10]
00007e97133d9754  vmovaps xmm2, [rsp+0x20]
00007e97133d975a  vmovaps xmm3, [rsp+0x30]
00007e97133d9760  vmovaps xmm5, [rsp+0x40]
00007e97133d9766  vmovaps xmm6, [rsp+0x50]
00007e97133d976c  vmovaps xmm7, [rsp+0x60]
00007e97133d9772  vmovaps xmm8, [rsp+0x70]
00007e97133d9778  vmovaps xmm9, [rsp+0x80]
00007e97133d9781  vmovaps xmm10, [rsp+0x90]
00007e97133d978a  vmovaps xmm11, [rsp+0xA0]
00007e97133d9793  vmovaps xmm12, [rsp+0xB0]
00007e97133d979c  vmovaps xmm13, [rsp+0xC0]
00007e97133d97a5  vmovaps xmm14, [rsp+0xD0]
00007e97133d97ae  vmovaps xmm15, [rsp+0xE0]
00007e97133d97b7  add rsp, 0xF0
00007e97133d97be  pop r11
00007e97133d97c0  pop r10
00007e97133d97c2  pop r9
00007e97133d97c4  pop r8
00007e97133d97c6  pop rsi
00007e97133d97c7  pop rdi
00007e97133d97c8  pop rdx
00007e97133d97c9  pop rcx
00007e97133d97ca  pop rax
00007e97133d97cb  add rsp, 0x08
00007e97133d97cf  jmp 0x00007E97133D628A
00007e97133d97d4  sub rsp, 0x08
00007e97133d97d8  push rax
00007e97133d97d9  push rcx
00007e97133d97da  push rdx
00007e97133d97db  push rdi
00007e97133d97dc  push rsi
00007e97133d97dd  push r8
00007e97133d97df  push r9
00007e97133d97e1  push r10
00007e97133d97e3  push r11
00007e97133d97e5  sub rsp, 0xF0
00007e97133d97ec  vmovaps [rsp], xmm0
00007e97133d97f1  vmovaps [rsp+0x10], xmm1
00007e97133d97f7  vmovaps [rsp+0x20], xmm2
00007e97133d97fd  vmovaps [rsp+0x30], xmm3
00007e97133d9803  vmovaps [rsp+0x40], xmm4
00007e97133d9809  vmovaps [rsp+0x50], xmm5
00007e97133d980f  vmovaps [rsp+0x60], xmm6
00007e97133d9815  vmovaps [rsp+0x70], xmm7
00007e97133d981b  vmovaps [rsp+0x80], xmm8
00007e97133d9824  vmovaps [rsp+0x90], xmm9
00007e97133d982d  vmovaps [rsp+0xA0], xmm10
00007e97133d9836  vmovaps [rsp+0xB0], xmm11
00007e97133d983f  vmovaps [rsp+0xC0], xmm12
00007e97133d9848  vmovaps [rsp+0xD0], xmm14
00007e97133d9851  vmovaps [rsp+0xE0], xmm15
00007e97133d985a  sub rsp, 0x30
00007e97133d985e  movaps [rsp], xmm13
00007e97133d9863  movaps [rsp+0x10], xmm15
00007e97133d9869  movaps [rsp+0x20], xmm9
00007e97133d986f  lea rdi, [rsp]
00007e97133d9873  mov esi, 0x00
00007e97133d9878  mov rax, 0x58D8AED5F530
00007e97133d9882  call rax
00007e97133d9884  movaps xmm13, [rsp]
00007e97133d9889  add rsp, 0x30
00007e97133d988d  vmovaps xmm0, [rsp]
00007e97133d9892  vmovaps xmm1, [rsp+0x10]
00007e97133d9898  vmovaps xmm2, [rsp+0x20]
00007e97133d989e  vmovaps xmm3, [rsp+0x30]
00007e97133d98a4  vmovaps xmm4, [rsp+0x40]
00007e97133d98aa  vmovaps xmm5, [rsp+0x50]
00007e97133d98b0  vmovaps xmm6, [rsp+0x60]
00007e97133d98b6  vmovaps xmm7, [rsp+0x70]
00007e97133d98bc  vmovaps xmm8, [rsp+0x80]
00007e97133d98c5  vmovaps xmm9, [rsp+0x90]
00007e97133d98ce  vmovaps xmm10, [rsp+0xA0]
00007e97133d98d7  vmovaps xmm11, [rsp+0xB0]
00007e97133d98e0  vmovaps xmm12, [rsp+0xC0]
00007e97133d98e9  vmovaps xmm14, [rsp+0xD0]
00007e97133d98f2  vmovaps xmm15, [rsp+0xE0]
00007e97133d98fb  add rsp, 0xF0
00007e97133d9902  pop r11
00007e97133d9904  pop r10
00007e97133d9906  pop r9
00007e97133d9908  pop r8
00007e97133d990a  pop rsi
00007e97133d990b  pop rdi
00007e97133d990c  pop rdx
00007e97133d990d  pop rcx
00007e97133d990e  pop rax
00007e97133d990f  add rsp, 0x08
00007e97133d9913  jmp 0x00007E97133D62A5
00007e97133d9918  sub rsp, 0x08
00007e97133d991c  push rax
00007e97133d991d  push rcx
00007e97133d991e  push rdx
00007e97133d991f  push rdi
00007e97133d9920  push rsi
00007e97133d9921  push r8
00007e97133d9923  push r9
00007e97133d9925  push r10
00007e97133d9927  push r11
00007e97133d9929  sub rsp, 0xF0
00007e97133d9930  vmovaps [rsp], xmm0
00007e97133d9935  vmovaps [rsp+0x10], xmm1
00007e97133d993b  vmovaps [rsp+0x20], xmm2
00007e97133d9941  vmovaps [rsp+0x30], xmm3
00007e97133d9947  vmovaps [rsp+0x40], xmm4
00007e97133d994d  vmovaps [rsp+0x50], xmm5
00007e97133d9953  vmovaps [rsp+0x60], xmm6
00007e97133d9959  vmovaps [rsp+0x70], xmm7
00007e97133d995f  vmovaps [rsp+0x80], xmm8
00007e97133d9968  vmovaps [rsp+0x90], xmm9
00007e97133d9971  vmovaps [rsp+0xA0], xmm10
00007e97133d997a  vmovaps [rsp+0xB0], xmm11
00007e97133d9983  vmovaps [rsp+0xC0], xmm12
00007e97133d998c  vmovaps [rsp+0xD0], xmm13
00007e97133d9995  vmovaps [rsp+0xE0], xmm14
00007e97133d999e  sub rsp, 0x30
00007e97133d99a2  movaps [rsp], xmm15
00007e97133d99a7  movaps [rsp+0x10], xmm1
00007e97133d99ac  movaps [rsp+0x20], xmm5
00007e97133d99b1  lea rdi, [rsp]
00007e97133d99b5  mov esi, 0x00
00007e97133d99ba  mov rax, 0x58D8AED5F530
00007e97133d99c4  call rax
00007e97133d99c6  movaps xmm15, [rsp]
00007e97133d99cb  add rsp, 0x30
00007e97133d99cf  vmovaps xmm0, [rsp]
00007e97133d99d4  vmovaps xmm1, [rsp+0x10]
00007e97133d99da  vmovaps xmm2, [rsp+0x20]
00007e97133d99e0  vmovaps xmm3, [rsp+0x30]
00007e97133d99e6  vmovaps xmm4, [rsp+0x40]
00007e97133d99ec  vmovaps xmm5, [rsp+0x50]
00007e97133d99f2  vmovaps xmm6, [rsp+0x60]
00007e97133d99f8  vmovaps xmm7, [rsp+0x70]
00007e97133d99fe  vmovaps xmm8, [rsp+0x80]
00007e97133d9a07  vmovaps xmm9, [rsp+0x90]
00007e97133d9a10  vmovaps xmm10, [rsp+0xA0]
00007e97133d9a19  vmovaps xmm11, [rsp+0xB0]
00007e97133d9a22  vmovaps xmm12, [rsp+0xC0]
00007e97133d9a2b  vmovaps xmm13, [rsp+0xD0]
00007e97133d9a34  vmovaps xmm14, [rsp+0xE0]
00007e97133d9a3d  add rsp, 0xF0
00007e97133d9a44  pop r11
00007e97133d9a46  pop r10
00007e97133d9a48  pop r9
00007e97133d9a4a  pop r8
00007e97133d9a4c  pop rsi
00007e97133d9a4d  pop rdi
00007e97133d9a4e  pop rdx
00007e97133d9a4f  pop rcx
00007e97133d9a50  pop rax
00007e97133d9a51  add rsp, 0x08
00007e97133d9a55  jmp 0x00007E97133D62C0
00007e97133d9a5a  call 0x00007E97132D64F0
00007e97133d9a5f  jmp 0x00007E97133D631B
00007e97133d9a64  sub rsp, 0x08
00007e97133d9a68  push rax
00007e97133d9a69  push rcx
00007e97133d9a6a  push rdx
00007e97133d9a6b  push rdi
00007e97133d9a6c  push rsi
00007e97133d9a6d  push r8
00007e97133d9a6f  push r9
00007e97133d9a71  push r10
00007e97133d9a73  push r11
00007e97133d9a75  sub rsp, 0xF0
00007e97133d9a7c  vmovaps [rsp], xmm0
00007e97133d9a81  vmovaps [rsp+0x10], xmm1
00007e97133d9a87  vmovaps [rsp+0x20], xmm2
00007e97133d9a8d  vmovaps [rsp+0x30], xmm3
00007e97133d9a93  vmovaps [rsp+0x40], xmm4
00007e97133d9a99  vmovaps [rsp+0x50], xmm5
00007e97133d9a9f  vmovaps [rsp+0x60], xmm6
00007e97133d9aa5  vmovaps [rsp+0x70], xmm7
00007e97133d9aab  vmovaps [rsp+0x80], xmm8
00007e97133d9ab4  vmovaps [rsp+0x90], xmm10
00007e97133d9abd  vmovaps [rsp+0xA0], xmm11
00007e97133d9ac6  vmovaps [rsp+0xB0], xmm12
00007e97133d9acf  vmovaps [rsp+0xC0], xmm13
00007e97133d9ad8  vmovaps [rsp+0xD0], xmm14
00007e97133d9ae1  vmovaps [rsp+0xE0], xmm15
00007e97133d9aea  sub rsp, 0x30
00007e97133d9aee  movaps [rsp], xmm9
00007e97133d9af3  movaps [rsp+0x10], xmm8
00007e97133d9af9  movaps [rsp+0x20], xmm11
00007e97133d9aff  lea rdi, [rsp]
00007e97133d9b03  mov esi, 0x00
00007e97133d9b08  mov rax, 0x58D8AED5F530
00007e97133d9b12  call rax
00007e97133d9b14  movaps xmm9, [rsp]
00007e97133d9b19  add rsp, 0x30
00007e97133d9b1d  vmovaps xmm0, [rsp]
00007e97133d9b22  vmovaps xmm1, [rsp+0x10]
00007e97133d9b28  vmovaps xmm2, [rsp+0x20]
00007e97133d9b2e  vmovaps xmm3, [rsp+0x30]
00007e97133d9b34  vmovaps xmm4, [rsp+0x40]
00007e97133d9b3a  vmovaps xmm5, [rsp+0x50]
00007e97133d9b40  vmovaps xmm6, [rsp+0x60]
00007e97133d9b46  vmovaps xmm7, [rsp+0x70]
00007e97133d9b4c  vmovaps xmm8, [rsp+0x80]
00007e97133d9b55  vmovaps xmm10, [rsp+0x90]
00007e97133d9b5e  vmovaps xmm11, [rsp+0xA0]
00007e97133d9b67  vmovaps xmm12, [rsp+0xB0]
00007e97133d9b70  vmovaps xmm13, [rsp+0xC0]
00007e97133d9b79  vmovaps xmm14, [rsp+0xD0]
00007e97133d9b82  vmovaps xmm15, [rsp+0xE0]
00007e97133d9b8b  add rsp, 0xF0
00007e97133d9b92  pop r11
00007e97133d9b94  pop r10
00007e97133d9b96  pop r9
00007e97133d9b98  pop r8
00007e97133d9b9a  pop rsi
00007e97133d9b9b  pop rdi
00007e97133d9b9c  pop rdx
00007e97133d9b9d  pop rcx
00007e97133d9b9e  pop rax
00007e97133d9b9f  add rsp, 0x08
00007e97133d9ba3  jmp 0x00007E97133D6352
00007e97133d9ba8  sub rsp, 0x08
00007e97133d9bac  push rax
00007e97133d9bad  push rcx
00007e97133d9bae  push rdx
00007e97133d9baf  push rdi
00007e97133d9bb0  push rsi
00007e97133d9bb1  push r8
00007e97133d9bb3  push r9
00007e97133d9bb5  push r10
00007e97133d9bb7  push r11
00007e97133d9bb9  sub rsp, 0xF0
00007e97133d9bc0  vmovaps [rsp], xmm0
00007e97133d9bc5  vmovaps [rsp+0x10], xmm1
00007e97133d9bcb  vmovaps [rsp+0x20], xmm2
00007e97133d9bd1  vmovaps [rsp+0x30], xmm3
00007e97133d9bd7  vmovaps [rsp+0x40], xmm4
00007e97133d9bdd  vmovaps [rsp+0x50], xmm5
00007e97133d9be3  vmovaps [rsp+0x60], xmm6
00007e97133d9be9  vmovaps [rsp+0x70], xmm7
00007e97133d9bef  vmovaps [rsp+0x80], xmm8
00007e97133d9bf8  vmovaps [rsp+0x90], xmm9
00007e97133d9c01  vmovaps [rsp+0xA0], xmm10
00007e97133d9c0a  vmovaps [rsp+0xB0], xmm12
00007e97133d9c13  vmovaps [rsp+0xC0], xmm13
00007e97133d9c1c  vmovaps [rsp+0xD0], xmm14
00007e97133d9c25  vmovaps [rsp+0xE0], xmm15
00007e97133d9c2e  sub rsp, 0x30
00007e97133d9c32  movaps [rsp], xmm11
00007e97133d9c37  movaps [rsp+0x10], xmm10
00007e97133d9c3d  movaps [rsp+0x20], xmm6
00007e97133d9c42  lea rdi, [rsp]
00007e97133d9c46  mov esi, 0x00
00007e97133d9c4b  mov rax, 0x58D8AED5F530
00007e97133d9c55  call rax
00007e97133d9c57  movaps xmm11, [rsp]
00007e97133d9c5c  add rsp, 0x30
00007e97133d9c60  vmovaps xmm0, [rsp]
00007e97133d9c65  vmovaps xmm1, [rsp+0x10]
00007e97133d9c6b  vmovaps xmm2, [rsp+0x20]
00007e97133d9c71  vmovaps xmm3, [rsp+0x30]
00007e97133d9c77  vmovaps xmm4, [rsp+0x40]
00007e97133d9c7d  vmovaps xmm5, [rsp+0x50]
00007e97133d9c83  vmovaps xmm6, [rsp+0x60]
00007e97133d9c89  vmovaps xmm7, [rsp+0x70]
00007e97133d9c8f  vmovaps xmm8, [rsp+0x80]
00007e97133d9c98  vmovaps xmm9, [rsp+0x90]
00007e97133d9ca1  vmovaps xmm10, [rsp+0xA0]
00007e97133d9caa  vmovaps xmm12, [rsp+0xB0]
00007e97133d9cb3  vmovaps xmm13, [rsp+0xC0]
00007e97133d9cbc  vmovaps xmm14, [rsp+0xD0]
00007e97133d9cc5  vmovaps xmm15, [rsp+0xE0]
00007e97133d9cce  add rsp, 0xF0
00007e97133d9cd5  pop r11
00007e97133d9cd7  pop r10
00007e97133d9cd9  pop r9
00007e97133d9cdb  pop r8
00007e97133d9cdd  pop rsi
00007e97133d9cde  pop rdi
00007e97133d9cdf  pop rdx
00007e97133d9ce0  pop rcx
00007e97133d9ce1  pop rax
00007e97133d9ce2  add rsp, 0x08
00007e97133d9ce6  jmp 0x00007E97133D636D
00007e97133d9ceb  sub rsp, 0x08
00007e97133d9cef  push rax
00007e97133d9cf0  push rcx
00007e97133d9cf1  push rdx
00007e97133d9cf2  push rdi
00007e97133d9cf3  push rsi
00007e97133d9cf4  push r8
00007e97133d9cf6  push r9
00007e97133d9cf8  push r10
00007e97133d9cfa  push r11
00007e97133d9cfc  sub rsp, 0xF0
00007e97133d9d03  vmovaps [rsp], xmm0
00007e97133d9d08  vmovaps [rsp+0x10], xmm1
00007e97133d9d0e  vmovaps [rsp+0x20], xmm2
00007e97133d9d14  vmovaps [rsp+0x30], xmm3
00007e97133d9d1a  vmovaps [rsp+0x40], xmm4
00007e97133d9d20  vmovaps [rsp+0x50], xmm5
00007e97133d9d26  vmovaps [rsp+0x60], xmm6
00007e97133d9d2c  vmovaps [rsp+0x70], xmm7
00007e97133d9d32  vmovaps [rsp+0x80], xmm8
00007e97133d9d3b  vmovaps [rsp+0x90], xmm9
00007e97133d9d44  vmovaps [rsp+0xA0], xmm11
00007e97133d9d4d  vmovaps [rsp+0xB0], xmm12
00007e97133d9d56  vmovaps [rsp+0xC0], xmm13
00007e97133d9d5f  vmovaps [rsp+0xD0], xmm14
00007e97133d9d68  vmovaps [rsp+0xE0], xmm15
00007e97133d9d71  sub rsp, 0x30
00007e97133d9d75  movaps [rsp], xmm10
00007e97133d9d7a  movaps [rsp+0x10], xmm14
00007e97133d9d80  movaps [rsp+0x20], xmm4
00007e97133d9d85  lea rdi, [rsp]
00007e97133d9d89  mov esi, 0x00
00007e97133d9d8e  mov rax, 0x58D8AED5F530
00007e97133d9d98  call rax
00007e97133d9d9a  movaps xmm10, [rsp]
00007e97133d9d9f  add rsp, 0x30
00007e97133d9da3  vmovaps xmm0, [rsp]
00007e97133d9da8  vmovaps xmm1, [rsp+0x10]
00007e97133d9dae  vmovaps xmm2, [rsp+0x20]
00007e97133d9db4  vmovaps xmm3, [rsp+0x30]
00007e97133d9dba  vmovaps xmm4, [rsp+0x40]
00007e97133d9dc0  vmovaps xmm5, [rsp+0x50]
00007e97133d9dc6  vmovaps xmm6, [rsp+0x60]
00007e97133d9dcc  vmovaps xmm7, [rsp+0x70]
00007e97133d9dd2  vmovaps xmm8, [rsp+0x80]
00007e97133d9ddb  vmovaps xmm9, [rsp+0x90]
00007e97133d9de4  vmovaps xmm11, [rsp+0xA0]
00007e97133d9ded  vmovaps xmm12, [rsp+0xB0]
00007e97133d9df6  vmovaps xmm13, [rsp+0xC0]
00007e97133d9dff  vmovaps xmm14, [rsp+0xD0]
00007e97133d9e08  vmovaps xmm15, [rsp+0xE0]
00007e97133d9e11  add rsp, 0xF0
00007e97133d9e18  pop r11
00007e97133d9e1a  pop r10
00007e97133d9e1c  pop r9
00007e97133d9e1e  pop r8
00007e97133d9e20  pop rsi
00007e97133d9e21  pop rdi
00007e97133d9e22  pop rdx
00007e97133d9e23  pop rcx
00007e97133d9e24  pop rax
00007e97133d9e25  add rsp, 0x08
00007e97133d9e29  jmp 0x00007E97133D6388
00007e97133d9e2e  sub rsp, 0x08
00007e97133d9e32  push rax
00007e97133d9e33  push rcx
00007e97133d9e34  push rdx
00007e97133d9e35  push rdi
00007e97133d9e36  push rsi
00007e97133d9e37  push r8
00007e97133d9e39  push r9
00007e97133d9e3b  push r10
00007e97133d9e3d  push r11
00007e97133d9e3f  sub rsp, 0xF0
00007e97133d9e46  vmovaps [rsp], xmm0
00007e97133d9e4b  vmovaps [rsp+0x10], xmm1
00007e97133d9e51  vmovaps [rsp+0x20], xmm2
00007e97133d9e57  vmovaps [rsp+0x30], xmm3
00007e97133d9e5d  vmovaps [rsp+0x40], xmm4
00007e97133d9e63  vmovaps [rsp+0x50], xmm5
00007e97133d9e69  vmovaps [rsp+0x60], xmm6
00007e97133d9e6f  vmovaps [rsp+0x70], xmm7
00007e97133d9e75  vmovaps [rsp+0x80], xmm9
00007e97133d9e7e  vmovaps [rsp+0x90], xmm10
00007e97133d9e87  vmovaps [rsp+0xA0], xmm11
00007e97133d9e90  vmovaps [rsp+0xB0], xmm12
00007e97133d9e99  vmovaps [rsp+0xC0], xmm13
00007e97133d9ea2  vmovaps [rsp+0xD0], xmm14
00007e97133d9eab  vmovaps [rsp+0xE0], xmm15
00007e97133d9eb4  sub rsp, 0x30
00007e97133d9eb8  movaps [rsp], xmm8
00007e97133d9ebd  movaps [rsp+0x10], xmm1
00007e97133d9ec2  movaps [rsp+0x20], xmm14
00007e97133d9ec8  lea rdi, [rsp]
00007e97133d9ecc  mov esi, 0x00
00007e97133d9ed1  mov rax, 0x58D8AED5F530
00007e97133d9edb  call rax
00007e97133d9edd  movaps xmm8, [rsp]
00007e97133d9ee2  add rsp, 0x30
00007e97133d9ee6  vmovaps xmm0, [rsp]
00007e97133d9eeb  vmovaps xmm1, [rsp+0x10]
00007e97133d9ef1  vmovaps xmm2, [rsp+0x20]
00007e97133d9ef7  vmovaps xmm3, [rsp+0x30]
00007e97133d9efd  vmovaps xmm4, [rsp+0x40]
00007e97133d9f03  vmovaps xmm5, [rsp+0x50]
00007e97133d9f09  vmovaps xmm6, [rsp+0x60]
00007e97133d9f0f  vmovaps xmm7, [rsp+0x70]
00007e97133d9f15  vmovaps xmm9, [rsp+0x80]
00007e97133d9f1e  vmovaps xmm10, [rsp+0x90]
00007e97133d9f27  vmovaps xmm11, [rsp+0xA0]
00007e97133d9f30  vmovaps xmm12, [rsp+0xB0]
00007e97133d9f39  vmovaps xmm13, [rsp+0xC0]
00007e97133d9f42  vmovaps xmm14, [rsp+0xD0]
00007e97133d9f4b  vmovaps xmm15, [rsp+0xE0]
00007e97133d9f54  add rsp, 0xF0
00007e97133d9f5b  pop r11
00007e97133d9f5d  pop r10
00007e97133d9f5f  pop r9
00007e97133d9f61  pop r8
00007e97133d9f63  pop rsi
00007e97133d9f64  pop rdi
00007e97133d9f65  pop rdx
00007e97133d9f66  pop rcx
00007e97133d9f67  pop rax
00007e97133d9f68  add rsp, 0x08
00007e97133d9f6c  jmp 0x00007E97133D63AE
00007e97133d9f71  sub rsp, 0x08
00007e97133d9f75  push rax
00007e97133d9f76  push rcx
00007e97133d9f77  push rdx
00007e97133d9f78  push rdi
00007e97133d9f79  push rsi
00007e97133d9f7a  push r8
00007e97133d9f7c  push r9
00007e97133d9f7e  push r10
00007e97133d9f80  push r11
00007e97133d9f82  sub rsp, 0xF0
00007e97133d9f89  vmovaps [rsp], xmm0
00007e97133d9f8e  vmovaps [rsp+0x10], xmm1
00007e97133d9f94  vmovaps [rsp+0x20], xmm2
00007e97133d9f9a  vmovaps [rsp+0x30], xmm3
00007e97133d9fa0  vmovaps [rsp+0x40], xmm4
00007e97133d9fa6  vmovaps [rsp+0x50], xmm5
00007e97133d9fac  vmovaps [rsp+0x60], xmm7
00007e97133d9fb2  vmovaps [rsp+0x70], xmm8
00007e97133d9fb8  vmovaps [rsp+0x80], xmm9
00007e97133d9fc1  vmovaps [rsp+0x90], xmm10
00007e97133d9fca  vmovaps [rsp+0xA0], xmm11
00007e97133d9fd3  vmovaps [rsp+0xB0], xmm12
00007e97133d9fdc  vmovaps [rsp+0xC0], xmm13
00007e97133d9fe5  vmovaps [rsp+0xD0], xmm14
00007e97133d9fee  vmovaps [rsp+0xE0], xmm15
00007e97133d9ff7  sub rsp, 0x30
00007e97133d9ffb  movaps [rsp], xmm6
00007e97133d9fff  movaps [rsp+0x10], xmm1
00007e97133da004  movaps [rsp+0x20], xmm14
00007e97133da00a  lea rdi, [rsp]
00007e97133da00e  mov esi, 0x00
00007e97133da013  mov rax, 0x58D8AED5F530
00007e97133da01d  call rax
00007e97133da01f  movaps xmm6, [rsp]
00007e97133da023  add rsp, 0x30
00007e97133da027  vmovaps xmm0, [rsp]
00007e97133da02c  vmovaps xmm1, [rsp+0x10]
00007e97133da032  vmovaps xmm2, [rsp+0x20]
00007e97133da038  vmovaps xmm3, [rsp+0x30]
00007e97133da03e  vmovaps xmm4, [rsp+0x40]
00007e97133da044  vmovaps xmm5, [rsp+0x50]
00007e97133da04a  vmovaps xmm7, [rsp+0x60]
00007e97133da050  vmovaps xmm8, [rsp+0x70]
00007e97133da056  vmovaps xmm9, [rsp+0x80]
00007e97133da05f  vmovaps xmm10, [rsp+0x90]
00007e97133da068  vmovaps xmm11, [rsp+0xA0]
00007e97133da071  vmovaps xmm12, [rsp+0xB0]
00007e97133da07a  vmovaps xmm13, [rsp+0xC0]
00007e97133da083  vmovaps xmm14, [rsp+0xD0]
00007e97133da08c  vmovaps xmm15, [rsp+0xE0]
00007e97133da095  add rsp, 0xF0
00007e97133da09c  pop r11
00007e97133da09e  pop r10
00007e97133da0a0  pop r9
00007e97133da0a2  pop r8
00007e97133da0a4  pop rsi
00007e97133da0a5  pop rdi
00007e97133da0a6  pop rdx
00007e97133da0a7  pop rcx
00007e97133da0a8  pop rax
00007e97133da0a9  add rsp, 0x08
00007e97133da0ad  jmp 0x00007E97133D63DA
00007e97133da0b2  sub rsp, 0x08
00007e97133da0b6  push rax
00007e97133da0b7  push rcx
00007e97133da0b8  push rdx
00007e97133da0b9  push rdi
00007e97133da0ba  push rsi
00007e97133da0bb  push r8
00007e97133da0bd  push r9
00007e97133da0bf  push r10
00007e97133da0c1  push r11
00007e97133da0c3  sub rsp, 0xF0
00007e97133da0ca  vmovaps [rsp], xmm0
00007e97133da0cf  vmovaps [rsp+0x10], xmm1
00007e97133da0d5  vmovaps [rsp+0x20], xmm2
00007e97133da0db  vmovaps [rsp+0x30], xmm3
00007e97133da0e1  vmovaps [rsp+0x40], xmm4
00007e97133da0e7  vmovaps [rsp+0x50], xmm5
00007e97133da0ed  vmovaps [rsp+0x60], xmm6
00007e97133da0f3  vmovaps [rsp+0x70], xmm7
00007e97133da0f9  vmovaps [rsp+0x80], xmm8
00007e97133da102  vmovaps [rsp+0x90], xmm9
00007e97133da10b  vmovaps [rsp+0xA0], xmm10
00007e97133da114  vmovaps [rsp+0xB0], xmm11
00007e97133da11d  vmovaps [rsp+0xC0], xmm12
00007e97133da126  vmovaps [rsp+0xD0], xmm13
00007e97133da12f  vmovaps [rsp+0xE0], xmm15
00007e97133da138  sub rsp, 0x30
00007e97133da13c  movaps [rsp], xmm14
00007e97133da141  movaps [rsp+0x10], xmm12
00007e97133da147  movaps [rsp+0x20], xmm1
00007e97133da14c  lea rdi, [rsp]
00007e97133da150  mov esi, 0x00
00007e97133da155  mov rax, 0x58D8AED5F530
00007e97133da15f  call rax
00007e97133da161  movaps xmm14, [rsp]
00007e97133da166  add rsp, 0x30
00007e97133da16a  vmovaps xmm0, [rsp]
00007e97133da16f  vmovaps xmm1, [rsp+0x10]
00007e97133da175  vmovaps xmm2, [rsp+0x20]
00007e97133da17b  vmovaps xmm3, [rsp+0x30]
00007e97133da181  vmovaps xmm4, [rsp+0x40]
00007e97133da187  vmovaps xmm5, [rsp+0x50]
00007e97133da18d  vmovaps xmm6, [rsp+0x60]
00007e97133da193  vmovaps xmm7, [rsp+0x70]
00007e97133da199  vmovaps xmm8, [rsp+0x80]
00007e97133da1a2  vmovaps xmm9, [rsp+0x90]
00007e97133da1ab  vmovaps xmm10, [rsp+0xA0]
00007e97133da1b4  vmovaps xmm11, [rsp+0xB0]
00007e97133da1bd  vmovaps xmm12, [rsp+0xC0]
00007e97133da1c6  vmovaps xmm13, [rsp+0xD0]
00007e97133da1cf  vmovaps xmm15, [rsp+0xE0]
00007e97133da1d8  add rsp, 0xF0
00007e97133da1df  pop r11
00007e97133da1e1  pop r10
00007e97133da1e3  pop r9
00007e97133da1e5  pop r8
00007e97133da1e7  pop rsi
00007e97133da1e8  pop rdi
00007e97133da1e9  pop rdx
00007e97133da1ea  pop rcx
00007e97133da1eb  pop rax
00007e97133da1ec  add rsp, 0x08
00007e97133da1f0  jmp 0x00007E97133D6400
00007e97133da1f5  sub rsp, 0x08
00007e97133da1f9  push rax
00007e97133da1fa  push rcx
00007e97133da1fb  push rdx
00007e97133da1fc  push rdi
00007e97133da1fd  push rsi
00007e97133da1fe  push r8
00007e97133da200  push r9
00007e97133da202  push r10
00007e97133da204  push r11
00007e97133da206  sub rsp, 0xF0
00007e97133da20d  vmovaps [rsp], xmm0
00007e97133da212  vmovaps [rsp+0x10], xmm2
00007e97133da218  vmovaps [rsp+0x20], xmm3
00007e97133da21e  vmovaps [rsp+0x30], xmm4
00007e97133da224  vmovaps [rsp+0x40], xmm5
00007e97133da22a  vmovaps [rsp+0x50], xmm6
00007e97133da230  vmovaps [rsp+0x60], xmm7
00007e97133da236  vmovaps [rsp+0x70], xmm8
00007e97133da23c  vmovaps [rsp+0x80], xmm9
00007e97133da245  vmovaps [rsp+0x90], xmm10
00007e97133da24e  vmovaps [rsp+0xA0], xmm11
00007e97133da257  vmovaps [rsp+0xB0], xmm12
00007e97133da260  vmovaps [rsp+0xC0], xmm13
00007e97133da269  vmovaps [rsp+0xD0], xmm14
00007e97133da272  vmovaps [rsp+0xE0], xmm15
00007e97133da27b  sub rsp, 0x30
00007e97133da27f  movaps [rsp], xmm1
00007e97133da283  movaps [rsp+0x10], xmm13
00007e97133da289  movaps [rsp+0x20], xmm9
00007e97133da28f  lea rdi, [rsp]
00007e97133da293  mov esi, 0x00
00007e97133da298  mov rax, 0x58D8AED5F530
00007e97133da2a2  call rax
00007e97133da2a4  movaps xmm1, [rsp]
00007e97133da2a8  add rsp, 0x30
00007e97133da2ac  vmovaps xmm0, [rsp]
00007e97133da2b1  vmovaps xmm2, [rsp+0x10]
00007e97133da2b7  vmovaps xmm3, [rsp+0x20]
00007e97133da2bd  vmovaps xmm4, [rsp+0x30]
00007e97133da2c3  vmovaps xmm5, [rsp+0x40]
00007e97133da2c9  vmovaps xmm6, [rsp+0x50]
00007e97133da2cf  vmovaps xmm7, [rsp+0x60]
00007e97133da2d5  vmovaps xmm8, [rsp+0x70]
00007e97133da2db  vmovaps xmm9, [rsp+0x80]
00007e97133da2e4  vmovaps xmm10, [rsp+0x90]
00007e97133da2ed  vmovaps xmm11, [rsp+0xA0]
00007e97133da2f6  vmovaps xmm12, [rsp+0xB0]
00007e97133da2ff  vmovaps xmm13, [rsp+0xC0]
00007e97133da308  vmovaps xmm14, [rsp+0xD0]
00007e97133da311  vmovaps xmm15, [rsp+0xE0]
00007e97133da31a  add rsp, 0xF0
00007e97133da321  pop r11
00007e97133da323  pop r10
00007e97133da325  pop r9
00007e97133da327  pop r8
00007e97133da329  pop rsi
00007e97133da32a  pop rdi
00007e97133da32b  pop rdx
00007e97133da32c  pop rcx
00007e97133da32d  pop rax
00007e97133da32e  add rsp, 0x08
00007e97133da332  jmp 0x00007E97133D641A
00007e97133da337  sub rsp, 0x08
00007e97133da33b  push rax
00007e97133da33c  push rcx
00007e97133da33d  push rdx
00007e97133da33e  push rdi
00007e97133da33f  push rsi
00007e97133da340  push r8
00007e97133da342  push r9
00007e97133da344  push r10
00007e97133da346  push r11
00007e97133da348  sub rsp, 0xF0
00007e97133da34f  vmovaps [rsp], xmm0
00007e97133da354  vmovaps [rsp+0x10], xmm1
00007e97133da35a  vmovaps [rsp+0x20], xmm2
00007e97133da360  vmovaps [rsp+0x30], xmm3
00007e97133da366  vmovaps [rsp+0x40], xmm4
00007e97133da36c  vmovaps [rsp+0x50], xmm5
00007e97133da372  vmovaps [rsp+0x60], xmm6
00007e97133da378  vmovaps [rsp+0x70], xmm7
00007e97133da37e  vmovaps [rsp+0x80], xmm8
00007e97133da387  vmovaps [rsp+0x90], xmm9
00007e97133da390  vmovaps [rsp+0xA0], xmm10
00007e97133da399  vmovaps [rsp+0xB0], xmm11
00007e97133da3a2  vmovaps [rsp+0xC0], xmm13
00007e97133da3ab  vmovaps [rsp+0xD0], xmm14
00007e97133da3b4  vmovaps [rsp+0xE0], xmm15
00007e97133da3bd  sub rsp, 0x30
00007e97133da3c1  movaps [rsp], xmm12
00007e97133da3c6  movaps [rsp+0x10], xmm7
00007e97133da3cb  movaps [rsp+0x20], xmm13
00007e97133da3d1  lea rdi, [rsp]
00007e97133da3d5  mov esi, 0x00
00007e97133da3da  mov rax, 0x58D8AED5F530
00007e97133da3e4  call rax
00007e97133da3e6  movaps xmm12, [rsp]
00007e97133da3eb  add rsp, 0x30
00007e97133da3ef  vmovaps xmm0, [rsp]
00007e97133da3f4  vmovaps xmm1, [rsp+0x10]
00007e97133da3fa  vmovaps xmm2, [rsp+0x20]
00007e97133da400  vmovaps xmm3, [rsp+0x30]
00007e97133da406  vmovaps xmm4, [rsp+0x40]
00007e97133da40c  vmovaps xmm5, [rsp+0x50]
00007e97133da412  vmovaps xmm6, [rsp+0x60]
00007e97133da418  vmovaps xmm7, [rsp+0x70]
00007e97133da41e  vmovaps xmm8, [rsp+0x80]
00007e97133da427  vmovaps xmm9, [rsp+0x90]
00007e97133da430  vmovaps xmm10, [rsp+0xA0]
00007e97133da439  vmovaps xmm11, [rsp+0xB0]
00007e97133da442  vmovaps xmm13, [rsp+0xC0]
00007e97133da44b  vmovaps xmm14, [rsp+0xD0]
00007e97133da454  vmovaps xmm15, [rsp+0xE0]
00007e97133da45d  add rsp, 0xF0
00007e97133da464  pop r11
00007e97133da466  pop r10
00007e97133da468  pop r9
00007e97133da46a  pop r8
00007e97133da46c  pop rsi
00007e97133da46d  pop rdi
00007e97133da46e  pop rdx
00007e97133da46f  pop rcx
00007e97133da470  pop rax
00007e97133da471  add rsp, 0x08
00007e97133da475  jmp 0x00007E97133D6441
00007e97133da47a  sub rsp, 0x08
00007e97133da47e  push rax
00007e97133da47f  push rcx
00007e97133da480  push rdx
00007e97133da481  push rdi
00007e97133da482  push rsi
00007e97133da483  push r8
00007e97133da485  push r9
00007e97133da487  push r10
00007e97133da489  push r11
00007e97133da48b  sub rsp, 0xF0
00007e97133da492  vmovaps [rsp], xmm0
00007e97133da497  vmovaps [rsp+0x10], xmm1
00007e97133da49d  vmovaps [rsp+0x20], xmm2
00007e97133da4a3  vmovaps [rsp+0x30], xmm3
00007e97133da4a9  vmovaps [rsp+0x40], xmm4
00007e97133da4af  vmovaps [rsp+0x50], xmm5
00007e97133da4b5  vmovaps [rsp+0x60], xmm6
00007e97133da4bb  vmovaps [rsp+0x70], xmm7
00007e97133da4c1  vmovaps [rsp+0x80], xmm8
00007e97133da4ca  vmovaps [rsp+0x90], xmm9
00007e97133da4d3  vmovaps [rsp+0xA0], xmm10
00007e97133da4dc  vmovaps [rsp+0xB0], xmm11
00007e97133da4e5  vmovaps [rsp+0xC0], xmm12
00007e97133da4ee  vmovaps [rsp+0xD0], xmm14
00007e97133da4f7  vmovaps [rsp+0xE0], xmm15
00007e97133da500  sub rsp, 0x30
00007e97133da504  movaps [rsp], xmm13
00007e97133da509  movaps [rsp+0x10], xmm15
00007e97133da50f  movaps [rsp+0x20], xmm8
00007e97133da515  lea rdi, [rsp]
00007e97133da519  mov esi, 0x00
00007e97133da51e  mov rax, 0x58D8AED5F530
00007e97133da528  call rax
00007e97133da52a  movaps xmm13, [rsp]
00007e97133da52f  add rsp, 0x30
00007e97133da533  vmovaps xmm0, [rsp]
00007e97133da538  vmovaps xmm1, [rsp+0x10]
00007e97133da53e  vmovaps xmm2, [rsp+0x20]
00007e97133da544  vmovaps xmm3, [rsp+0x30]
00007e97133da54a  vmovaps xmm4, [rsp+0x40]
00007e97133da550  vmovaps xmm5, [rsp+0x50]
00007e97133da556  vmovaps xmm6, [rsp+0x60]
00007e97133da55c  vmovaps xmm7, [rsp+0x70]
00007e97133da562  vmovaps xmm8, [rsp+0x80]
00007e97133da56b  vmovaps xmm9, [rsp+0x90]
00007e97133da574  vmovaps xmm10, [rsp+0xA0]
00007e97133da57d  vmovaps xmm11, [rsp+0xB0]
00007e97133da586  vmovaps xmm12, [rsp+0xC0]
00007e97133da58f  vmovaps xmm14, [rsp+0xD0]
00007e97133da598  vmovaps xmm15, [rsp+0xE0]
00007e97133da5a1  add rsp, 0xF0
00007e97133da5a8  pop r11
00007e97133da5aa  pop r10
00007e97133da5ac  pop r9
00007e97133da5ae  pop r8
00007e97133da5b0  pop rsi
00007e97133da5b1  pop rdi
00007e97133da5b2  pop rdx
00007e97133da5b3  pop rcx
00007e97133da5b4  pop rax
00007e97133da5b5  add rsp, 0x08
00007e97133da5b9  jmp 0x00007E97133D645C
00007e97133da5be  sub rsp, 0x08
00007e97133da5c2  push rax
00007e97133da5c3  push rcx
00007e97133da5c4  push rdx
00007e97133da5c5  push rdi
00007e97133da5c6  push rsi
00007e97133da5c7  push r8
00007e97133da5c9  push r9
00007e97133da5cb  push r10
00007e97133da5cd  push r11
00007e97133da5cf  sub rsp, 0xF0
00007e97133da5d6  vmovaps [rsp], xmm0
00007e97133da5db  vmovaps [rsp+0x10], xmm1
00007e97133da5e1  vmovaps [rsp+0x20], xmm2
00007e97133da5e7  vmovaps [rsp+0x30], xmm3
00007e97133da5ed  vmovaps [rsp+0x40], xmm4
00007e97133da5f3  vmovaps [rsp+0x50], xmm5
00007e97133da5f9  vmovaps [rsp+0x60], xmm6
00007e97133da5ff  vmovaps [rsp+0x70], xmm7
00007e97133da605  vmovaps [rsp+0x80], xmm9
00007e97133da60e  vmovaps [rsp+0x90], xmm10
00007e97133da617  vmovaps [rsp+0xA0], xmm11
00007e97133da620  vmovaps [rsp+0xB0], xmm12
00007e97133da629  vmovaps [rsp+0xC0], xmm13
00007e97133da632  vmovaps [rsp+0xD0], xmm14
00007e97133da63b  vmovaps [rsp+0xE0], xmm15
00007e97133da644  sub rsp, 0x30
00007e97133da648  movaps [rsp], xmm8
00007e97133da64d  movaps [rsp+0x10], xmm15
00007e97133da653  movaps [rsp+0x20], xmm9
00007e97133da659  lea rdi, [rsp]
00007e97133da65d  mov esi, 0x00
00007e97133da662  mov rax, 0x58D8AED5F530
00007e97133da66c  call rax
00007e97133da66e  movaps xmm8, [rsp]
00007e97133da673  add rsp, 0x30
00007e97133da677  vmovaps xmm0, [rsp]
00007e97133da67c  vmovaps xmm1, [rsp+0x10]
00007e97133da682  vmovaps xmm2, [rsp+0x20]
00007e97133da688  vmovaps xmm3, [rsp+0x30]
00007e97133da68e  vmovaps xmm4, [rsp+0x40]
00007e97133da694  vmovaps xmm5, [rsp+0x50]
00007e97133da69a  vmovaps xmm6, [rsp+0x60]
00007e97133da6a0  vmovaps xmm7, [rsp+0x70]
00007e97133da6a6  vmovaps xmm9, [rsp+0x80]
00007e97133da6af  vmovaps xmm10, [rsp+0x90]
00007e97133da6b8  vmovaps xmm11, [rsp+0xA0]
00007e97133da6c1  vmovaps xmm12, [rsp+0xB0]
00007e97133da6ca  vmovaps xmm13, [rsp+0xC0]
00007e97133da6d3  vmovaps xmm14, [rsp+0xD0]
00007e97133da6dc  vmovaps xmm15, [rsp+0xE0]
00007e97133da6e5  add rsp, 0xF0
00007e97133da6ec  pop r11
00007e97133da6ee  pop r10
00007e97133da6f0  pop r9
00007e97133da6f2  pop r8
00007e97133da6f4  pop rsi
00007e97133da6f5  pop rdi
00007e97133da6f6  pop rdx
00007e97133da6f7  pop rcx
00007e97133da6f8  pop rax
00007e97133da6f9  add rsp, 0x08
00007e97133da6fd  jmp 0x00007E97133D648A
00007e97133da702  sub rsp, 0x08
00007e97133da706  push rax
00007e97133da707  push rcx
00007e97133da708  push rdx
00007e97133da709  push rdi
00007e97133da70a  push rsi
00007e97133da70b  push r8
00007e97133da70d  push r9
00007e97133da70f  push r10
00007e97133da711  push r11
00007e97133da713  sub rsp, 0xF0
00007e97133da71a  vmovaps [rsp], xmm0
00007e97133da71f  vmovaps [rsp+0x10], xmm1
00007e97133da725  vmovaps [rsp+0x20], xmm2
00007e97133da72b  vmovaps [rsp+0x30], xmm3
00007e97133da731  vmovaps [rsp+0x40], xmm4
00007e97133da737  vmovaps [rsp+0x50], xmm5
00007e97133da73d  vmovaps [rsp+0x60], xmm6
00007e97133da743  vmovaps [rsp+0x70], xmm7
00007e97133da749  vmovaps [rsp+0x80], xmm8
00007e97133da752  vmovaps [rsp+0x90], xmm9
00007e97133da75b  vmovaps [rsp+0xA0], xmm10
00007e97133da764  vmovaps [rsp+0xB0], xmm11
00007e97133da76d  vmovaps [rsp+0xC0], xmm12
00007e97133da776  vmovaps [rsp+0xD0], xmm13
00007e97133da77f  vmovaps [rsp+0xE0], xmm14
00007e97133da788  sub rsp, 0x30
00007e97133da78c  movaps [rsp], xmm15
00007e97133da791  movaps [rsp+0x10], xmm11
00007e97133da797  movaps [rsp+0x20], xmm6
00007e97133da79c  lea rdi, [rsp]
00007e97133da7a0  mov esi, 0x00
00007e97133da7a5  mov rax, 0x58D8AED5F530
00007e97133da7af  call rax
00007e97133da7b1  movaps xmm15, [rsp]
00007e97133da7b6  add rsp, 0x30
00007e97133da7ba  vmovaps xmm0, [rsp]
00007e97133da7bf  vmovaps xmm1, [rsp+0x10]
00007e97133da7c5  vmovaps xmm2, [rsp+0x20]
00007e97133da7cb  vmovaps xmm3, [rsp+0x30]
00007e97133da7d1  vmovaps xmm4, [rsp+0x40]
00007e97133da7d7  vmovaps xmm5, [rsp+0x50]
00007e97133da7dd  vmovaps xmm6, [rsp+0x60]
00007e97133da7e3  vmovaps xmm7, [rsp+0x70]
00007e97133da7e9  vmovaps xmm8, [rsp+0x80]
00007e97133da7f2  vmovaps xmm9, [rsp+0x90]
00007e97133da7fb  vmovaps xmm10, [rsp+0xA0]
00007e97133da804  vmovaps xmm11, [rsp+0xB0]
00007e97133da80d  vmovaps xmm12, [rsp+0xC0]
00007e97133da816  vmovaps xmm13, [rsp+0xD0]
00007e97133da81f  vmovaps xmm14, [rsp+0xE0]
00007e97133da828  add rsp, 0xF0
00007e97133da82f  pop r11
00007e97133da831  pop r10
00007e97133da833  pop r9
00007e97133da835  pop r8
00007e97133da837  pop rsi
00007e97133da838  pop rdi
00007e97133da839  pop rdx
00007e97133da83a  pop rcx
00007e97133da83b  pop rax
00007e97133da83c  add rsp, 0x08
00007e97133da840  jmp 0x00007E97133D64A5
00007e97133da845  sub rsp, 0x08
00007e97133da849  push rax
00007e97133da84a  push rcx
00007e97133da84b  push rdx
00007e97133da84c  push rdi
00007e97133da84d  push rsi
00007e97133da84e  push r8
00007e97133da850  push r9
00007e97133da852  push r10
00007e97133da854  push r11
00007e97133da856  sub rsp, 0xF0
00007e97133da85d  vmovaps [rsp], xmm0
00007e97133da862  vmovaps [rsp+0x10], xmm1
00007e97133da868  vmovaps [rsp+0x20], xmm2
00007e97133da86e  vmovaps [rsp+0x30], xmm3
00007e97133da874  vmovaps [rsp+0x40], xmm4
00007e97133da87a  vmovaps [rsp+0x50], xmm5
00007e97133da880  vmovaps [rsp+0x60], xmm6
00007e97133da886  vmovaps [rsp+0x70], xmm8
00007e97133da88c  vmovaps [rsp+0x80], xmm9
00007e97133da895  vmovaps [rsp+0x90], xmm10
00007e97133da89e  vmovaps [rsp+0xA0], xmm11
00007e97133da8a7  vmovaps [rsp+0xB0], xmm12
00007e97133da8b0  vmovaps [rsp+0xC0], xmm13
00007e97133da8b9  vmovaps [rsp+0xD0], xmm14
00007e97133da8c2  vmovaps [rsp+0xE0], xmm15
00007e97133da8cb  sub rsp, 0x30
00007e97133da8cf  movaps [rsp], xmm7
00007e97133da8d3  movaps [rsp+0x10], xmm11
00007e97133da8d9  movaps [rsp+0x20], xmm9
00007e97133da8df  lea rdi, [rsp]
00007e97133da8e3  mov esi, 0x00
00007e97133da8e8  mov rax, 0x58D8AED5F530
00007e97133da8f2  call rax
00007e97133da8f4  movaps xmm7, [rsp]
00007e97133da8f8  add rsp, 0x30
00007e97133da8fc  vmovaps xmm0, [rsp]
00007e97133da901  vmovaps xmm1, [rsp+0x10]
00007e97133da907  vmovaps xmm2, [rsp+0x20]
00007e97133da90d  vmovaps xmm3, [rsp+0x30]
00007e97133da913  vmovaps xmm4, [rsp+0x40]
00007e97133da919  vmovaps xmm5, [rsp+0x50]
00007e97133da91f  vmovaps xmm6, [rsp+0x60]
00007e97133da925  vmovaps xmm8, [rsp+0x70]
00007e97133da92b  vmovaps xmm9, [rsp+0x80]
00007e97133da934  vmovaps xmm10, [rsp+0x90]
00007e97133da93d  vmovaps xmm11, [rsp+0xA0]
00007e97133da946  vmovaps xmm12, [rsp+0xB0]
00007e97133da94f  vmovaps xmm13, [rsp+0xC0]
00007e97133da958  vmovaps xmm14, [rsp+0xD0]
00007e97133da961  vmovaps xmm15, [rsp+0xE0]
00007e97133da96a  add rsp, 0xF0
00007e97133da971  pop r11
00007e97133da973  pop r10
00007e97133da975  pop r9
00007e97133da977  pop r8
00007e97133da979  pop rsi
00007e97133da97a  pop rdi
00007e97133da97b  pop rdx
00007e97133da97c  pop rcx
00007e97133da97d  pop rax
00007e97133da97e  add rsp, 0x08
00007e97133da982  jmp 0x00007E97133D64D2
00007e97133da987  sub rsp, 0x08
00007e97133da98b  push rax
00007e97133da98c  push rcx
00007e97133da98d  push rdx
00007e97133da98e  push rdi
00007e97133da98f  push rsi
00007e97133da990  push r8
00007e97133da992  push r9
00007e97133da994  push r10
00007e97133da996  push r11
00007e97133da998  sub rsp, 0xF0
00007e97133da99f  vmovaps [rsp], xmm0
00007e97133da9a4  vmovaps [rsp+0x10], xmm1
00007e97133da9aa  vmovaps [rsp+0x20], xmm2
00007e97133da9b0  vmovaps [rsp+0x30], xmm3
00007e97133da9b6  vmovaps [rsp+0x40], xmm4
00007e97133da9bc  vmovaps [rsp+0x50], xmm5
00007e97133da9c2  vmovaps [rsp+0x60], xmm6
00007e97133da9c8  vmovaps [rsp+0x70], xmm7
00007e97133da9ce  vmovaps [rsp+0x80], xmm8
00007e97133da9d7  vmovaps [rsp+0x90], xmm9
00007e97133da9e0  vmovaps [rsp+0xA0], xmm10
00007e97133da9e9  vmovaps [rsp+0xB0], xmm12
00007e97133da9f2  vmovaps [rsp+0xC0], xmm13
00007e97133da9fb  vmovaps [rsp+0xD0], xmm14
00007e97133daa04  vmovaps [rsp+0xE0], xmm15
00007e97133daa0d  sub rsp, 0x30
00007e97133daa11  movaps [rsp], xmm11
00007e97133daa16  movaps [rsp+0x10], xmm10
00007e97133daa1c  movaps [rsp+0x20], xmm14
00007e97133daa22  lea rdi, [rsp]
00007e97133daa26  mov esi, 0x00
00007e97133daa2b  mov rax, 0x58D8AED5F530
00007e97133daa35  call rax
00007e97133daa37  movaps xmm11, [rsp]
00007e97133daa3c  add rsp, 0x30
00007e97133daa40  vmovaps xmm0, [rsp]
00007e97133daa45  vmovaps xmm1, [rsp+0x10]
00007e97133daa4b  vmovaps xmm2, [rsp+0x20]
00007e97133daa51  vmovaps xmm3, [rsp+0x30]
00007e97133daa57  vmovaps xmm4, [rsp+0x40]
00007e97133daa5d  vmovaps xmm5, [rsp+0x50]
00007e97133daa63  vmovaps xmm6, [rsp+0x60]
00007e97133daa69  vmovaps xmm7, [rsp+0x70]
00007e97133daa6f  vmovaps xmm8, [rsp+0x80]
00007e97133daa78  vmovaps xmm9, [rsp+0x90]
00007e97133daa81  vmovaps xmm10, [rsp+0xA0]
00007e97133daa8a  vmovaps xmm12, [rsp+0xB0]
00007e97133daa93  vmovaps xmm13, [rsp+0xC0]
00007e97133daa9c  vmovaps xmm14, [rsp+0xD0]
00007e97133daaa5  vmovaps xmm15, [rsp+0xE0]
00007e97133daaae  add rsp, 0xF0
00007e97133daab5  pop r11
00007e97133daab7  pop r10
00007e97133daab9  pop r9
00007e97133daabb  pop r8
00007e97133daabd  pop rsi
00007e97133daabe  pop rdi
00007e97133daabf  pop rdx
00007e97133daac0  pop rcx
00007e97133daac1  pop rax
00007e97133daac2  add rsp, 0x08
00007e97133daac6  jmp 0x00007E97133D64ED
00007e97133daacb  call 0x00007E97132E45A0
00007e97133daad0  jmp 0x00007E97133D64F7
00007e97133daad5  sub rsp, 0x08
00007e97133daad9  push rax
00007e97133daada  push rcx
00007e97133daadb  push rdx
00007e97133daadc  push rdi
00007e97133daadd  push rsi
00007e97133daade  push r8
00007e97133daae0  push r9
00007e97133daae2  push r10
00007e97133daae4  push r11
00007e97133daae6  sub rsp, 0xF0
00007e97133daaed  vmovaps [rsp], xmm0
00007e97133daaf2  vmovaps [rsp+0x10], xmm1
00007e97133daaf8  vmovaps [rsp+0x20], xmm2
00007e97133daafe  vmovaps [rsp+0x30], xmm3
00007e97133dab04  vmovaps [rsp+0x40], xmm4
00007e97133dab0a  vmovaps [rsp+0x50], xmm5
00007e97133dab10  vmovaps [rsp+0x60], xmm6
00007e97133dab16  vmovaps [rsp+0x70], xmm7
00007e97133dab1c  vmovaps [rsp+0x80], xmm8
00007e97133dab25  vmovaps [rsp+0x90], xmm9
00007e97133dab2e  vmovaps [rsp+0xA0], xmm11
00007e97133dab37  vmovaps [rsp+0xB0], xmm12
00007e97133dab40  vmovaps [rsp+0xC0], xmm13
00007e97133dab49  vmovaps [rsp+0xD0], xmm14
00007e97133dab52  vmovaps [rsp+0xE0], xmm15
00007e97133dab5b  sub rsp, 0x30
00007e97133dab5f  movaps [rsp], xmm10
00007e97133dab64  movaps [rsp+0x10], xmm1
00007e97133dab69  movaps [rsp+0x20], xmm12
00007e97133dab6f  lea rdi, [rsp]
00007e97133dab73  mov esi, 0x00
00007e97133dab78  mov rax, 0x58D8AED5F530
00007e97133dab82  call rax
00007e97133dab84  movaps xmm10, [rsp]
00007e97133dab89  add rsp, 0x30
00007e97133dab8d  vmovaps xmm0, [rsp]
00007e97133dab92  vmovaps xmm1, [rsp+0x10]
00007e97133dab98  vmovaps xmm2, [rsp+0x20]
00007e97133dab9e  vmovaps xmm3, [rsp+0x30]
00007e97133daba4  vmovaps xmm4, [rsp+0x40]
00007e97133dabaa  vmovaps xmm5, [rsp+0x50]
00007e97133dabb0  vmovaps xmm6, [rsp+0x60]
00007e97133dabb6  vmovaps xmm7, [rsp+0x70]
00007e97133dabbc  vmovaps xmm8, [rsp+0x80]
00007e97133dabc5  vmovaps xmm9, [rsp+0x90]
00007e97133dabce  vmovaps xmm11, [rsp+0xA0]
00007e97133dabd7  vmovaps xmm12, [rsp+0xB0]
00007e97133dabe0  vmovaps xmm13, [rsp+0xC0]
00007e97133dabe9  vmovaps xmm14, [rsp+0xD0]
00007e97133dabf2  vmovaps xmm15, [rsp+0xE0]
00007e97133dabfb  add rsp, 0xF0
00007e97133dac02  pop r11
00007e97133dac04  pop r10
00007e97133dac06  pop r9
00007e97133dac08  pop r8
00007e97133dac0a  pop rsi
00007e97133dac0b  pop rdi
00007e97133dac0c  pop rdx
00007e97133dac0d  pop rcx
00007e97133dac0e  pop rax
00007e97133dac0f  add rsp, 0x08
00007e97133dac13  jmp 0x00007E97133D651A
00007e97133dac18  sub rsp, 0x08
00007e97133dac1c  push rax
00007e97133dac1d  push rcx
00007e97133dac1e  push rdx
00007e97133dac1f  push rdi
00007e97133dac20  push rsi
00007e97133dac21  push r8
00007e97133dac23  push r9
00007e97133dac25  push r10
00007e97133dac27  push r11
00007e97133dac29  sub rsp, 0xF0
00007e97133dac30  vmovaps [rsp], xmm0
00007e97133dac35  vmovaps [rsp+0x10], xmm1
00007e97133dac3b  vmovaps [rsp+0x20], xmm2
00007e97133dac41  vmovaps [rsp+0x30], xmm3
00007e97133dac47  vmovaps [rsp+0x40], xmm4
00007e97133dac4d  vmovaps [rsp+0x50], xmm5
00007e97133dac53  vmovaps [rsp+0x60], xmm6
00007e97133dac59  vmovaps [rsp+0x70], xmm7
00007e97133dac5f  vmovaps [rsp+0x80], xmm8
00007e97133dac68  vmovaps [rsp+0x90], xmm9
00007e97133dac71  vmovaps [rsp+0xA0], xmm10
00007e97133dac7a  vmovaps [rsp+0xB0], xmm11
00007e97133dac83  vmovaps [rsp+0xC0], xmm13
00007e97133dac8c  vmovaps [rsp+0xD0], xmm14
00007e97133dac95  vmovaps [rsp+0xE0], xmm15
00007e97133dac9e  sub rsp, 0x30
00007e97133daca2  movaps [rsp], xmm12
00007e97133daca7  movaps [rsp+0x10], xmm14
00007e97133dacad  movaps [rsp+0x20], xmm1
00007e97133dacb2  lea rdi, [rsp]
00007e97133dacb6  mov esi, 0x00
00007e97133dacbb  mov rax, 0x58D8AED5F530
00007e97133dacc5  call rax
00007e97133dacc7  movaps xmm12, [rsp]
00007e97133daccc  add rsp, 0x30
00007e97133dacd0  vmovaps xmm0, [rsp]
00007e97133dacd5  vmovaps xmm1, [rsp+0x10]
00007e97133dacdb  vmovaps xmm2, [rsp+0x20]
00007e97133dace1  vmovaps xmm3, [rsp+0x30]
00007e97133dace7  vmovaps xmm4, [rsp+0x40]
00007e97133daced  vmovaps xmm5, [rsp+0x50]
00007e97133dacf3  vmovaps xmm6, [rsp+0x60]
00007e97133dacf9  vmovaps xmm7, [rsp+0x70]
00007e97133dacff  vmovaps xmm8, [rsp+0x80]
00007e97133dad08  vmovaps xmm9, [rsp+0x90]
00007e97133dad11  vmovaps xmm10, [rsp+0xA0]
00007e97133dad1a  vmovaps xmm11, [rsp+0xB0]
00007e97133dad23  vmovaps xmm13, [rsp+0xC0]
00007e97133dad2c  vmovaps xmm14, [rsp+0xD0]
00007e97133dad35  vmovaps xmm15, [rsp+0xE0]
00007e97133dad3e  add rsp, 0xF0
00007e97133dad45  pop r11
00007e97133dad47  pop r10
00007e97133dad49  pop r9
00007e97133dad4b  pop r8
00007e97133dad4d  pop rsi
00007e97133dad4e  pop rdi
00007e97133dad4f  pop rdx
00007e97133dad50  pop rcx
00007e97133dad51  pop rax
00007e97133dad52  add rsp, 0x08
00007e97133dad56  jmp 0x00007E97133D6549
00007e97133dad5b  sub rsp, 0x08
00007e97133dad5f  push rax
00007e97133dad60  push rcx
00007e97133dad61  push rdx
00007e97133dad62  push rdi
00007e97133dad63  push rsi
00007e97133dad64  push r8
00007e97133dad66  push r9
00007e97133dad68  push r10
00007e97133dad6a  push r11
00007e97133dad6c  sub rsp, 0xF0
00007e97133dad73  vmovaps [rsp], xmm0
00007e97133dad78  vmovaps [rsp+0x10], xmm1
00007e97133dad7e  vmovaps [rsp+0x20], xmm2
00007e97133dad84  vmovaps [rsp+0x30], xmm3
00007e97133dad8a  vmovaps [rsp+0x40], xmm4
00007e97133dad90  vmovaps [rsp+0x50], xmm5
00007e97133dad96  vmovaps [rsp+0x60], xmm6
00007e97133dad9c  vmovaps [rsp+0x70], xmm7
00007e97133dada2  vmovaps [rsp+0x80], xmm8
00007e97133dadab  vmovaps [rsp+0x90], xmm9
00007e97133dadb4  vmovaps [rsp+0xA0], xmm10
00007e97133dadbd  vmovaps [rsp+0xB0], xmm11
00007e97133dadc6  vmovaps [rsp+0xC0], xmm12
00007e97133dadcf  vmovaps [rsp+0xD0], xmm13
00007e97133dadd8  vmovaps [rsp+0xE0], xmm15
00007e97133dade1  sub rsp, 0x30
00007e97133dade5  movaps [rsp], xmm14
00007e97133dadea  movaps [rsp+0x10], xmm9
00007e97133dadf0  movaps [rsp+0x20], xmm1
00007e97133dadf5  lea rdi, [rsp]
00007e97133dadf9  mov esi, 0x00
00007e97133dadfe  mov rax, 0x58D8AED5F530
00007e97133dae08  call rax
00007e97133dae0a  movaps xmm14, [rsp]
00007e97133dae0f  add rsp, 0x30
00007e97133dae13  vmovaps xmm0, [rsp]
00007e97133dae18  vmovaps xmm1, [rsp+0x10]
00007e97133dae1e  vmovaps xmm2, [rsp+0x20]
00007e97133dae24  vmovaps xmm3, [rsp+0x30]
00007e97133dae2a  vmovaps xmm4, [rsp+0x40]
00007e97133dae30  vmovaps xmm5, [rsp+0x50]
00007e97133dae36  vmovaps xmm6, [rsp+0x60]
00007e97133dae3c  vmovaps xmm7, [rsp+0x70]
00007e97133dae42  vmovaps xmm8, [rsp+0x80]
00007e97133dae4b  vmovaps xmm9, [rsp+0x90]
00007e97133dae54  vmovaps xmm10, [rsp+0xA0]
00007e97133dae5d  vmovaps xmm11, [rsp+0xB0]
00007e97133dae66  vmovaps xmm12, [rsp+0xC0]
00007e97133dae6f  vmovaps xmm13, [rsp+0xD0]
00007e97133dae78  vmovaps xmm15, [rsp+0xE0]
00007e97133dae81  add rsp, 0xF0
00007e97133dae88  pop r11
00007e97133dae8a  pop r10
00007e97133dae8c  pop r9
00007e97133dae8e  pop r8
00007e97133dae90  pop rsi
00007e97133dae91  pop rdi
00007e97133dae92  pop rdx
00007e97133dae93  pop rcx
00007e97133dae94  pop rax
00007e97133dae95  add rsp, 0x08
00007e97133dae99  jmp 0x00007E97133D6578
00007e97133dae9e  sub rsp, 0x08
00007e97133daea2  push rax
00007e97133daea3  push rcx
00007e97133daea4  push rdx
00007e97133daea5  push rdi
00007e97133daea6  push rsi
00007e97133daea7  push r8
00007e97133daea9  push r9
00007e97133daeab  push r10
00007e97133daead  push r11
00007e97133daeaf  sub rsp, 0xF0
00007e97133daeb6  vmovaps [rsp], xmm0
00007e97133daebb  vmovaps [rsp+0x10], xmm2
00007e97133daec1  vmovaps [rsp+0x20], xmm3
00007e97133daec7  vmovaps [rsp+0x30], xmm4
00007e97133daecd  vmovaps [rsp+0x40], xmm5
00007e97133daed3  vmovaps [rsp+0x50], xmm6
00007e97133daed9  vmovaps [rsp+0x60], xmm7
00007e97133daedf  vmovaps [rsp+0x70], xmm8
00007e97133daee5  vmovaps [rsp+0x80], xmm9
00007e97133daeee  vmovaps [rsp+0x90], xmm10
00007e97133daef7  vmovaps [rsp+0xA0], xmm11
00007e97133daf00  vmovaps [rsp+0xB0], xmm12
00007e97133daf09  vmovaps [rsp+0xC0], xmm13
00007e97133daf12  vmovaps [rsp+0xD0], xmm14
00007e97133daf1b  vmovaps [rsp+0xE0], xmm15
00007e97133daf24  sub rsp, 0x30
00007e97133daf28  movaps [rsp], xmm1
00007e97133daf2c  movaps [rsp+0x10], xmm13
00007e97133daf32  movaps [rsp+0x20], xmm8
00007e97133daf38  lea rdi, [rsp]
00007e97133daf3c  mov esi, 0x00
00007e97133daf41  mov rax, 0x58D8AED5F530
00007e97133daf4b  call rax
00007e97133daf4d  movaps xmm1, [rsp]
00007e97133daf51  add rsp, 0x30
00007e97133daf55  vmovaps xmm0, [rsp]
00007e97133daf5a  vmovaps xmm2, [rsp+0x10]
00007e97133daf60  vmovaps xmm3, [rsp+0x20]
00007e97133daf66  vmovaps xmm4, [rsp+0x30]
00007e97133daf6c  vmovaps xmm5, [rsp+0x40]
00007e97133daf72  vmovaps xmm6, [rsp+0x50]
00007e97133daf78  vmovaps xmm7, [rsp+0x60]
00007e97133daf7e  vmovaps xmm8, [rsp+0x70]
00007e97133daf84  vmovaps xmm9, [rsp+0x80]
00007e97133daf8d  vmovaps xmm10, [rsp+0x90]
00007e97133daf96  vmovaps xmm11, [rsp+0xA0]
00007e97133daf9f  vmovaps xmm12, [rsp+0xB0]
00007e97133dafa8  vmovaps xmm13, [rsp+0xC0]
00007e97133dafb1  vmovaps xmm14, [rsp+0xD0]
00007e97133dafba  vmovaps xmm15, [rsp+0xE0]
00007e97133dafc3  add rsp, 0xF0
00007e97133dafca  pop r11
00007e97133dafcc  pop r10
00007e97133dafce  pop r9
00007e97133dafd0  pop r8
00007e97133dafd2  pop rsi
00007e97133dafd3  pop rdi
00007e97133dafd4  pop rdx
00007e97133dafd5  pop rcx
00007e97133dafd6  pop rax
00007e97133dafd7  add rsp, 0x08
00007e97133dafdb  jmp 0x00007E97133D659A
00007e97133dafe0  call 0x00007E971320C260
00007e97133dafe5  jmp 0x00007E97133D65A8
00007e97133dafea  call 0x00007E97132DE950
00007e97133dafef  jmp 0x00007E97133D65B2
00007e97133daff4  sub rsp, 0x08
00007e97133daff8  push rax
00007e97133daff9  push rcx
00007e97133daffa  push rdx
00007e97133daffb  push rdi
00007e97133daffc  push rsi
00007e97133daffd  push r8
00007e97133dafff  push r9
00007e97133db001  push r10
00007e97133db003  push r11
00007e97133db005  sub rsp, 0xF0
00007e97133db00c  vmovaps [rsp], xmm0
00007e97133db011  vmovaps [rsp+0x10], xmm1
00007e97133db017  vmovaps [rsp+0x20], xmm2
00007e97133db01d  vmovaps [rsp+0x30], xmm3
00007e97133db023  vmovaps [rsp+0x40], xmm4
00007e97133db029  vmovaps [rsp+0x50], xmm5
00007e97133db02f  vmovaps [rsp+0x60], xmm6
00007e97133db035  vmovaps [rsp+0x70], xmm7
00007e97133db03b  vmovaps [rsp+0x80], xmm9
00007e97133db044  vmovaps [rsp+0x90], xmm10
00007e97133db04d  vmovaps [rsp+0xA0], xmm11
00007e97133db056  vmovaps [rsp+0xB0], xmm12
00007e97133db05f  vmovaps [rsp+0xC0], xmm13
00007e97133db068  vmovaps [rsp+0xD0], xmm14
00007e97133db071  vmovaps [rsp+0xE0], xmm15
00007e97133db07a  sub rsp, 0x30
00007e97133db07e  movaps [rsp], xmm8
00007e97133db083  movaps [rsp+0x10], xmm15
00007e97133db089  movaps [rsp+0x20], xmm7
00007e97133db08e  lea rdi, [rsp]
00007e97133db092  mov esi, 0x00
00007e97133db097  mov rax, 0x58D8AED5F530
00007e97133db0a1  call rax
00007e97133db0a3  movaps xmm8, [rsp]
00007e97133db0a8  add rsp, 0x30
00007e97133db0ac  vmovaps xmm0, [rsp]
00007e97133db0b1  vmovaps xmm1, [rsp+0x10]
00007e97133db0b7  vmovaps xmm2, [rsp+0x20]
00007e97133db0bd  vmovaps xmm3, [rsp+0x30]
00007e97133db0c3  vmovaps xmm4, [rsp+0x40]
00007e97133db0c9  vmovaps xmm5, [rsp+0x50]
00007e97133db0cf  vmovaps xmm6, [rsp+0x60]
00007e97133db0d5  vmovaps xmm7, [rsp+0x70]
00007e97133db0db  vmovaps xmm9, [rsp+0x80]
00007e97133db0e4  vmovaps xmm10, [rsp+0x90]
00007e97133db0ed  vmovaps xmm11, [rsp+0xA0]
00007e97133db0f6  vmovaps xmm12, [rsp+0xB0]
00007e97133db0ff  vmovaps xmm13, [rsp+0xC0]
00007e97133db108  vmovaps xmm14, [rsp+0xD0]
00007e97133db111  vmovaps xmm15, [rsp+0xE0]
00007e97133db11a  add rsp, 0xF0
00007e97133db121  pop r11
00007e97133db123  pop r10
00007e97133db125  pop r9
00007e97133db127  pop r8
00007e97133db129  pop rsi
00007e97133db12a  pop rdi
00007e97133db12b  pop rdx
00007e97133db12c  pop rcx
00007e97133db12d  pop rax
00007e97133db12e  add rsp, 0x08
00007e97133db132  jmp 0x00007E97133D65D4
00007e97133db137  sub rsp, 0x08
00007e97133db13b  push rax
00007e97133db13c  push rcx
00007e97133db13d  push rdx
00007e97133db13e  push rdi
00007e97133db13f  push rsi
00007e97133db140  push r8
00007e97133db142  push r9
00007e97133db144  push r10
00007e97133db146  push r11
00007e97133db148  sub rsp, 0xF0
00007e97133db14f  vmovaps [rsp], xmm0
00007e97133db154  vmovaps [rsp+0x10], xmm1
00007e97133db15a  vmovaps [rsp+0x20], xmm2
00007e97133db160  vmovaps [rsp+0x30], xmm3
00007e97133db166  vmovaps [rsp+0x40], xmm4
00007e97133db16c  vmovaps [rsp+0x50], xmm5
00007e97133db172  vmovaps [rsp+0x60], xmm6
00007e97133db178  vmovaps [rsp+0x70], xmm8
00007e97133db17e  vmovaps [rsp+0x80], xmm9
00007e97133db187  vmovaps [rsp+0x90], xmm10
00007e97133db190  vmovaps [rsp+0xA0], xmm11
00007e97133db199  vmovaps [rsp+0xB0], xmm12
00007e97133db1a2  vmovaps [rsp+0xC0], xmm13
00007e97133db1ab  vmovaps [rsp+0xD0], xmm14
00007e97133db1b4  vmovaps [rsp+0xE0], xmm15
00007e97133db1bd  sub rsp, 0x30
00007e97133db1c1  movaps [rsp], xmm7
00007e97133db1c5  movaps [rsp+0x10], xmm9
00007e97133db1cb  movaps [rsp+0x20], xmm15
00007e97133db1d1  lea rdi, [rsp]
00007e97133db1d5  mov esi, 0x00
00007e97133db1da  mov rax, 0x58D8AED5F530
00007e97133db1e4  call rax
00007e97133db1e6  movaps xmm7, [rsp]
00007e97133db1ea  add rsp, 0x30
00007e97133db1ee  vmovaps xmm0, [rsp]
00007e97133db1f3  vmovaps xmm1, [rsp+0x10]
00007e97133db1f9  vmovaps xmm2, [rsp+0x20]
00007e97133db1ff  vmovaps xmm3, [rsp+0x30]
00007e97133db205  vmovaps xmm4, [rsp+0x40]
00007e97133db20b  vmovaps xmm5, [rsp+0x50]
00007e97133db211  vmovaps xmm6, [rsp+0x60]
00007e97133db217  vmovaps xmm8, [rsp+0x70]
00007e97133db21d  vmovaps xmm9, [rsp+0x80]
00007e97133db226  vmovaps xmm10, [rsp+0x90]
00007e97133db22f  vmovaps xmm11, [rsp+0xA0]
00007e97133db238  vmovaps xmm12, [rsp+0xB0]
00007e97133db241  vmovaps xmm13, [rsp+0xC0]
00007e97133db24a  vmovaps xmm14, [rsp+0xD0]
00007e97133db253  vmovaps xmm15, [rsp+0xE0]
00007e97133db25c  add rsp, 0xF0
00007e97133db263  pop r11
00007e97133db265  pop r10
00007e97133db267  pop r9
00007e97133db269  pop r8
00007e97133db26b  pop rsi
00007e97133db26c  pop rdi
00007e97133db26d  pop rdx
00007e97133db26e  pop rcx
00007e97133db26f  pop rax
00007e97133db270  add rsp, 0x08
00007e97133db274  jmp 0x00007E97133D6601
00007e97133db279  sub rsp, 0x08
00007e97133db27d  push rax
00007e97133db27e  push rcx
00007e97133db27f  push rdx
00007e97133db280  push rdi
00007e97133db281  push rsi
00007e97133db282  push r8
00007e97133db284  push r9
00007e97133db286  push r10
00007e97133db288  push r11
00007e97133db28a  sub rsp, 0xF0
00007e97133db291  vmovaps [rsp], xmm0
00007e97133db296  vmovaps [rsp+0x10], xmm1
00007e97133db29c  vmovaps [rsp+0x20], xmm2
00007e97133db2a2  vmovaps [rsp+0x30], xmm3
00007e97133db2a8  vmovaps [rsp+0x40], xmm4
00007e97133db2ae  vmovaps [rsp+0x50], xmm5
00007e97133db2b4  vmovaps [rsp+0x60], xmm6
00007e97133db2ba  vmovaps [rsp+0x70], xmm7
00007e97133db2c0  vmovaps [rsp+0x80], xmm8
00007e97133db2c9  vmovaps [rsp+0x90], xmm10
00007e97133db2d2  vmovaps [rsp+0xA0], xmm11
00007e97133db2db  vmovaps [rsp+0xB0], xmm12
00007e97133db2e4  vmovaps [rsp+0xC0], xmm13
00007e97133db2ed  vmovaps [rsp+0xD0], xmm14
00007e97133db2f6  vmovaps [rsp+0xE0], xmm15
00007e97133db2ff  sub rsp, 0x30
00007e97133db303  movaps [rsp], xmm9
00007e97133db308  movaps [rsp+0x10], xmm13
00007e97133db30e  movaps [rsp+0x20], xmm15
00007e97133db314  lea rdi, [rsp]
00007e97133db318  mov esi, 0x00
00007e97133db31d  mov rax, 0x58D8AED5F530
00007e97133db327  call rax
00007e97133db329  movaps xmm9, [rsp]
00007e97133db32e  add rsp, 0x30
00007e97133db332  vmovaps xmm0, [rsp]
00007e97133db337  vmovaps xmm1, [rsp+0x10]
00007e97133db33d  vmovaps xmm2, [rsp+0x20]
00007e97133db343  vmovaps xmm3, [rsp+0x30]
00007e97133db349  vmovaps xmm4, [rsp+0x40]
00007e97133db34f  vmovaps xmm5, [rsp+0x50]
00007e97133db355  vmovaps xmm6, [rsp+0x60]
00007e97133db35b  vmovaps xmm7, [rsp+0x70]
00007e97133db361  vmovaps xmm8, [rsp+0x80]
00007e97133db36a  vmovaps xmm10, [rsp+0x90]
00007e97133db373  vmovaps xmm11, [rsp+0xA0]
00007e97133db37c  vmovaps xmm12, [rsp+0xB0]
00007e97133db385  vmovaps xmm13, [rsp+0xC0]
00007e97133db38e  vmovaps xmm14, [rsp+0xD0]
00007e97133db397  vmovaps xmm15, [rsp+0xE0]
00007e97133db3a0  add rsp, 0xF0
00007e97133db3a7  pop r11
00007e97133db3a9  pop r10
00007e97133db3ab  pop r9
00007e97133db3ad  pop r8
00007e97133db3af  pop rsi
00007e97133db3b0  pop rdi
00007e97133db3b1  pop rdx
00007e97133db3b2  pop rcx
00007e97133db3b3  pop rax
00007e97133db3b4  add rsp, 0x08
00007e97133db3b8  jmp 0x00007E97133D662F
00007e97133db3bd  sub rsp, 0x08
00007e97133db3c1  push rax
00007e97133db3c2  push rcx
00007e97133db3c3  push rdx
00007e97133db3c4  push rdi
00007e97133db3c5  push rsi
00007e97133db3c6  push r8
00007e97133db3c8  push r9
00007e97133db3ca  push r10
00007e97133db3cc  push r11
00007e97133db3ce  sub rsp, 0xF0
00007e97133db3d5  vmovaps [rsp], xmm0
00007e97133db3da  vmovaps [rsp+0x10], xmm1
00007e97133db3e0  vmovaps [rsp+0x20], xmm2
00007e97133db3e6  vmovaps [rsp+0x30], xmm3
00007e97133db3ec  vmovaps [rsp+0x40], xmm4
00007e97133db3f2  vmovaps [rsp+0x50], xmm5
00007e97133db3f8  vmovaps [rsp+0x60], xmm6
00007e97133db3fe  vmovaps [rsp+0x70], xmm7
00007e97133db404  vmovaps [rsp+0x80], xmm8
00007e97133db40d  vmovaps [rsp+0x90], xmm9
00007e97133db416  vmovaps [rsp+0xA0], xmm10
00007e97133db41f  vmovaps [rsp+0xB0], xmm11
00007e97133db428  vmovaps [rsp+0xC0], xmm12
00007e97133db431  vmovaps [rsp+0xD0], xmm13
00007e97133db43a  vmovaps [rsp+0xE0], xmm14
00007e97133db443  sub rsp, 0x30
00007e97133db447  movaps [rsp], xmm15
00007e97133db44c  movaps [rsp+0x10], xmm11
00007e97133db452  movaps [rsp+0x20], xmm12
00007e97133db458  lea rdi, [rsp]
00007e97133db45c  mov esi, 0x00
00007e97133db461  mov rax, 0x58D8AED5F530
00007e97133db46b  call rax
00007e97133db46d  movaps xmm15, [rsp]
00007e97133db472  add rsp, 0x30
00007e97133db476  vmovaps xmm0, [rsp]
00007e97133db47b  vmovaps xmm1, [rsp+0x10]
00007e97133db481  vmovaps xmm2, [rsp+0x20]
00007e97133db487  vmovaps xmm3, [rsp+0x30]
00007e97133db48d  vmovaps xmm4, [rsp+0x40]
00007e97133db493  vmovaps xmm5, [rsp+0x50]
00007e97133db499  vmovaps xmm6, [rsp+0x60]
00007e97133db49f  vmovaps xmm7, [rsp+0x70]
00007e97133db4a5  vmovaps xmm8, [rsp+0x80]
00007e97133db4ae  vmovaps xmm9, [rsp+0x90]
00007e97133db4b7  vmovaps xmm10, [rsp+0xA0]
00007e97133db4c0  vmovaps xmm11, [rsp+0xB0]
00007e97133db4c9  vmovaps xmm12, [rsp+0xC0]
00007e97133db4d2  vmovaps xmm13, [rsp+0xD0]
00007e97133db4db  vmovaps xmm14, [rsp+0xE0]
00007e97133db4e4  add rsp, 0xF0
00007e97133db4eb  pop r11
00007e97133db4ed  pop r10
00007e97133db4ef  pop r9
00007e97133db4f1  pop r8
00007e97133db4f3  pop rsi
00007e97133db4f4  pop rdi
00007e97133db4f5  pop rdx
00007e97133db4f6  pop rcx
00007e97133db4f7  pop rax
00007e97133db4f8  add rsp, 0x08
00007e97133db4fc  jmp 0x00007E97133D664A
00007e97133db501  sub rsp, 0x08
00007e97133db505  push rax
00007e97133db506  push rcx
00007e97133db507  push rdx
00007e97133db508  push rdi
00007e97133db509  push rsi
00007e97133db50a  push r8
00007e97133db50c  push r9
00007e97133db50e  push r10
00007e97133db510  push r11
00007e97133db512  sub rsp, 0xF0
00007e97133db519  vmovaps [rsp], xmm0
00007e97133db51e  vmovaps [rsp+0x10], xmm1
00007e97133db524  vmovaps [rsp+0x20], xmm2
00007e97133db52a  vmovaps [rsp+0x30], xmm3
00007e97133db530  vmovaps [rsp+0x40], xmm4
00007e97133db536  vmovaps [rsp+0x50], xmm5
00007e97133db53c  vmovaps [rsp+0x60], xmm6
00007e97133db542  vmovaps [rsp+0x70], xmm7
00007e97133db548  vmovaps [rsp+0x80], xmm8
00007e97133db551  vmovaps [rsp+0x90], xmm9
00007e97133db55a  vmovaps [rsp+0xA0], xmm10
00007e97133db563  vmovaps [rsp+0xB0], xmm11
00007e97133db56c  vmovaps [rsp+0xC0], xmm12
00007e97133db575  vmovaps [rsp+0xD0], xmm14
00007e97133db57e  vmovaps [rsp+0xE0], xmm15
00007e97133db587  sub rsp, 0x30
00007e97133db58b  movaps [rsp], xmm13
00007e97133db590  movaps [rsp+0x10], xmm10
00007e97133db596  movaps [rsp+0x20], xmm14
00007e97133db59c  lea rdi, [rsp]
00007e97133db5a0  mov esi, 0x00
00007e97133db5a5  mov rax, 0x58D8AED5F530
00007e97133db5af  call rax
00007e97133db5b1  movaps xmm13, [rsp]
00007e97133db5b6  add rsp, 0x30
00007e97133db5ba  vmovaps xmm0, [rsp]
00007e97133db5bf  vmovaps xmm1, [rsp+0x10]
00007e97133db5c5  vmovaps xmm2, [rsp+0x20]
00007e97133db5cb  vmovaps xmm3, [rsp+0x30]
00007e97133db5d1  vmovaps xmm4, [rsp+0x40]
00007e97133db5d7  vmovaps xmm5, [rsp+0x50]
00007e97133db5dd  vmovaps xmm6, [rsp+0x60]
00007e97133db5e3  vmovaps xmm7, [rsp+0x70]
00007e97133db5e9  vmovaps xmm8, [rsp+0x80]
00007e97133db5f2  vmovaps xmm9, [rsp+0x90]
00007e97133db5fb  vmovaps xmm10, [rsp+0xA0]
00007e97133db604  vmovaps xmm11, [rsp+0xB0]
00007e97133db60d  vmovaps xmm12, [rsp+0xC0]
00007e97133db616  vmovaps xmm14, [rsp+0xD0]
00007e97133db61f  vmovaps xmm15, [rsp+0xE0]
00007e97133db628  add rsp, 0xF0
00007e97133db62f  pop r11
00007e97133db631  pop r10
00007e97133db633  pop r9
00007e97133db635  pop r8
00007e97133db637  pop rsi
00007e97133db638  pop rdi
00007e97133db639  pop rdx
00007e97133db63a  pop rcx
00007e97133db63b  pop rax
00007e97133db63c  add rsp, 0x08
00007e97133db640  jmp 0x00007E97133D666D
00007e97133db645  sub rsp, 0x08
00007e97133db649  push rax
00007e97133db64a  push rcx
00007e97133db64b  push rdx
00007e97133db64c  push rdi
00007e97133db64d  push rsi
00007e97133db64e  push r8
00007e97133db650  push r9
00007e97133db652  push r10
00007e97133db654  push r11
00007e97133db656  sub rsp, 0xF0
00007e97133db65d  vmovaps [rsp], xmm0
00007e97133db662  vmovaps [rsp+0x10], xmm1
00007e97133db668  vmovaps [rsp+0x20], xmm2
00007e97133db66e  vmovaps [rsp+0x30], xmm3
00007e97133db674  vmovaps [rsp+0x40], xmm4
00007e97133db67a  vmovaps [rsp+0x50], xmm5
00007e97133db680  vmovaps [rsp+0x60], xmm6
00007e97133db686  vmovaps [rsp+0x70], xmm7
00007e97133db68c  vmovaps [rsp+0x80], xmm8
00007e97133db695  vmovaps [rsp+0x90], xmm9
00007e97133db69e  vmovaps [rsp+0xA0], xmm10
00007e97133db6a7  vmovaps [rsp+0xB0], xmm11
00007e97133db6b0  vmovaps [rsp+0xC0], xmm12
00007e97133db6b9  vmovaps [rsp+0xD0], xmm13
00007e97133db6c2  vmovaps [rsp+0xE0], xmm15
00007e97133db6cb  sub rsp, 0x30
00007e97133db6cf  movaps [rsp], xmm14
00007e97133db6d4  movaps [rsp+0x10], xmm1
00007e97133db6d9  movaps [rsp+0x20], xmm7
00007e97133db6de  lea rdi, [rsp]
00007e97133db6e2  mov esi, 0x00
00007e97133db6e7  mov rax, 0x58D8AED5F530
00007e97133db6f1  call rax
00007e97133db6f3  movaps xmm14, [rsp]
00007e97133db6f8  add rsp, 0x30
00007e97133db6fc  vmovaps xmm0, [rsp]
00007e97133db701  vmovaps xmm1, [rsp+0x10]
00007e97133db707  vmovaps xmm2, [rsp+0x20]
00007e97133db70d  vmovaps xmm3, [rsp+0x30]
00007e97133db713  vmovaps xmm4, [rsp+0x40]
00007e97133db719  vmovaps xmm5, [rsp+0x50]
00007e97133db71f  vmovaps xmm6, [rsp+0x60]
00007e97133db725  vmovaps xmm7, [rsp+0x70]
00007e97133db72b  vmovaps xmm8, [rsp+0x80]
00007e97133db734  vmovaps xmm9, [rsp+0x90]
00007e97133db73d  vmovaps xmm10, [rsp+0xA0]
00007e97133db746  vmovaps xmm11, [rsp+0xB0]
00007e97133db74f  vmovaps xmm12, [rsp+0xC0]
00007e97133db758  vmovaps xmm13, [rsp+0xD0]
00007e97133db761  vmovaps xmm15, [rsp+0xE0]
00007e97133db76a  add rsp, 0xF0
00007e97133db771  pop r11
00007e97133db773  pop r10
00007e97133db775  pop r9
00007e97133db777  pop r8
00007e97133db779  pop rsi
00007e97133db77a  pop rdi
00007e97133db77b  pop rdx
00007e97133db77c  pop rcx
00007e97133db77d  pop rax
00007e97133db77e  add rsp, 0x08
00007e97133db782  jmp 0x00007E97133D6690
00007e97133db787  sub rsp, 0x08
00007e97133db78b  push rax
00007e97133db78c  push rcx
00007e97133db78d  push rdx
00007e97133db78e  push rdi
00007e97133db78f  push rsi
00007e97133db790  push r8
00007e97133db792  push r9
00007e97133db794  push r10
00007e97133db796  push r11
00007e97133db798  sub rsp, 0xF0
00007e97133db79f  vmovaps [rsp], xmm0
00007e97133db7a4  vmovaps [rsp+0x10], xmm2
00007e97133db7aa  vmovaps [rsp+0x20], xmm3
00007e97133db7b0  vmovaps [rsp+0x30], xmm4
00007e97133db7b6  vmovaps [rsp+0x40], xmm5
00007e97133db7bc  vmovaps [rsp+0x50], xmm6
00007e97133db7c2  vmovaps [rsp+0x60], xmm7
00007e97133db7c8  vmovaps [rsp+0x70], xmm8
00007e97133db7ce  vmovaps [rsp+0x80], xmm9
00007e97133db7d7  vmovaps [rsp+0x90], xmm10
00007e97133db7e0  vmovaps [rsp+0xA0], xmm11
00007e97133db7e9  vmovaps [rsp+0xB0], xmm12
00007e97133db7f2  vmovaps [rsp+0xC0], xmm13
00007e97133db7fb  vmovaps [rsp+0xD0], xmm14
00007e97133db804  vmovaps [rsp+0xE0], xmm15
00007e97133db80d  sub rsp, 0x30
00007e97133db811  movaps [rsp], xmm1
00007e97133db815  movaps [rsp+0x10], xmm8
00007e97133db81b  movaps [rsp+0x20], xmm9
00007e97133db821  lea rdi, [rsp]
00007e97133db825  mov esi, 0x00
00007e97133db82a  mov rax, 0x58D8AED5F530
00007e97133db834  call rax
00007e97133db836  movaps xmm1, [rsp]
00007e97133db83a  add rsp, 0x30
00007e97133db83e  vmovaps xmm0, [rsp]
00007e97133db843  vmovaps xmm2, [rsp+0x10]
00007e97133db849  vmovaps xmm3, [rsp+0x20]
00007e97133db84f  vmovaps xmm4, [rsp+0x30]
00007e97133db855  vmovaps xmm5, [rsp+0x40]
00007e97133db85b  vmovaps xmm6, [rsp+0x50]
00007e97133db861  vmovaps xmm7, [rsp+0x60]
00007e97133db867  vmovaps xmm8, [rsp+0x70]
00007e97133db86d  vmovaps xmm9, [rsp+0x80]
00007e97133db876  vmovaps xmm10, [rsp+0x90]
00007e97133db87f  vmovaps xmm11, [rsp+0xA0]
00007e97133db888  vmovaps xmm12, [rsp+0xB0]
00007e97133db891  vmovaps xmm13, [rsp+0xC0]
00007e97133db89a  vmovaps xmm14, [rsp+0xD0]
00007e97133db8a3  vmovaps xmm15, [rsp+0xE0]
00007e97133db8ac  add rsp, 0xF0
00007e97133db8b3  pop r11
00007e97133db8b5  pop r10
00007e97133db8b7  pop r9
00007e97133db8b9  pop r8
00007e97133db8bb  pop rsi
00007e97133db8bc  pop rdi
00007e97133db8bd  pop rdx
00007e97133db8be  pop rcx
00007e97133db8bf  pop rax
00007e97133db8c0  add rsp, 0x08
00007e97133db8c4  jmp 0x00007E97133D66B2
00007e97133db8c9  call 0x00007E97132B3E40
00007e97133db8ce  jmp 0x00007E97133D66C0
00007e97133db8d3  call 0x00007E971320C380
00007e97133db8d8  jmp 0x00007E97133D66CA
00007e97133db8dd  call 0x00007E971320D600
00007e97133db8e2  jmp 0x00007E97133D66D4
00007e97133db8e7  call 0x00007E97131FF540
00007e97133db8ec  jmp 0x00007E97133D66DE
00007e97133db8f1  int3
00007e97133db8f2  nop [rax+rax*1], ax
00007e97133db8fb  nop [rax+rax*1], eax
00007e97133db900  mov eax, [r15+0x48]
00007e97133db904  lea r14d, [eax+0x01]
00007e97133db909  mov [rsp+0x10], r14d
00007e97133db90e  mov r14d, r14d
00007e97133db911  mov [r15+0x48], r14
00007e97133db915  xor eax, eax
00007e97133db917  mov r14d, [rsp+0x10]
00007e97133db91c  cmp r14d, 0x1F4
00007e97133db923  cmc
00007e97133db924  lahf
00007e97133db925  seto al
00007e97133db928  mov [r15+0x108], eax
00007e97133db92f  mov eax, [r15+0x108]
00007e97133db936  sahf
00007e97133db937  jnz 0x00007E97133DB969
00007e97133db939  cmp dword ptr [r15+0x318], 0x00
00007e97133db941  jz 0x00007E97133E1AB0
00007e97133db947  nop [rax+rax*1], ax
00007e97133db950  nop [rax+rax*1], eax
00007e97133db958  mov eax, 0x410450
00007e97133db95d  mov [r15+0x100], rax
00007e97133db964  jmp 0x00007E97131FE110
00007e97133db969  cmp dword ptr [r15+0x318], 0x00
00007e97133db971  jz 0x00007E97133DB9A0
00007e97133db977  nop [rax+rax*1], ax
00007e97133db980  nop [rax+rax*1], eax
00007e97133db988  mov eax, 0x410274
00007e97133db98d  mov [r15+0x100], rax
00007e97133db994  jmp 0x00007E97131FE110
00007e97133db999  int3
00007e97133db99a  int3
00007e97133db99b  nop [rax+rax*1], eax
00007e97133db9a0  mov rax, [r15+0x40]
00007e97133db9a4  movaps xmm1, [r15+0x1D0]
00007e97133db9ac  vmovaps [rsp+0x10], xmm1
00007e97133db9b2  vmovaps xmm15, [rsp+0x10]
00007e97133db9b8  por xmm1, xmm15
00007e97133db9bd  movaps xmm14, [r15+0x1A0]
00007e97133db9c5  vmovaps [rsp+0x10], xmm14
00007e97133db9cb  vmovaps xmm13, [rsp+0x10]
00007e97133db9d1  por xmm14, xmm13
00007e97133db9d6  lea r14, [rax+0x30]
00007e97133db9da  mov r12, [r13+r14*1]
00007e97133db9df  lea r14, [rax+0x38]
00007e97133db9e3  mov r11, [r13+r14*1]
00007e97133db9e8  movq xmm13, r12
00007e97133db9ed  movq xmm12, r11
00007e97133db9f2  movq xmm13, xmm13
00007e97133db9f7  vmovaps [rsp+0x10], xmm13
00007e97133db9fd  movq xmm13, xmm13
00007e97133dba02  movaps [r15+0x130], xmm13
00007e97133dba0a  movq xmm12, xmm12
00007e97133dba0f  vmovaps [rsp+0x20], xmm12
00007e97133dba15  movq xmm12, xmm12
00007e97133dba1a  movaps [r15+0x280], xmm12
00007e97133dba22  movaps xmm13, [r15+0x270]
00007e97133dba2a  vmovaps [rsp+0x30], xmm13
00007e97133dba30  vmovaps xmm12, [rsp+0x30]
00007e97133dba36  por xmm13, xmm12
00007e97133dba3b  lea r14, [rax+0x20]
00007e97133dba3f  mov r12, [r13+r14*1]
00007e97133dba44  lea r14, [rax+0x28]
00007e97133dba48  mov r11, [r13+r14*1]
00007e97133dba4d  movq xmm12, r12
00007e97133dba52  movq xmm11, r11
00007e97133dba57  movq xmm12, xmm12
00007e97133dba5c  vmovaps [rsp+0x30], xmm12
00007e97133dba62  movq xmm12, xmm12
00007e97133dba67  movaps [r15+0x150], xmm12
00007e97133dba6f  movq xmm11, xmm11
00007e97133dba74  vmovaps [rsp+0x40], xmm11
00007e97133dba7a  movq xmm11, xmm11
00007e97133dba7f  movaps [r15+0x140], xmm11
00007e97133dba87  lea r14, [rax+0x10]
00007e97133dba8b  mov r12, [r13+r14*1]
00007e97133dba90  lea r14, [rax+0x18]
00007e97133dba94  mov r11, [r13+r14*1]
00007e97133dba99  movq xmm12, r12
00007e97133dba9e  movq xmm11, r11
00007e97133dbaa3  movq xmm12, xmm12
00007e97133dbaa8  vmovaps [rsp+0x50], xmm12
00007e97133dbaae  movq xmm12, xmm12
00007e97133dbab3  movaps [r15+0x170], xmm12
00007e97133dbabb  movq xmm11, xmm11
00007e97133dbac0  vmovaps [rsp+0x60], xmm11
00007e97133dbac6  movq xmm11, xmm11
00007e97133dbacb  movaps [r15+0x160], xmm11
00007e97133dbad3  mov r14, [r13+rax*1]
00007e97133dbad8  vmovq xmm12, r14
00007e97133dbadd  vpbroadcastq xmm12, xmm12
00007e97133dbae2  lea r14, [rax+0x08]
00007e97133dbae6  mov rax, [r13+r14*1]
00007e97133dbaeb  movq xmm11, rax
00007e97133dbaf0  movaps [r15+0x230], xmm11
00007e97133dbaf8  mov rax, [r15+0xF8]
00007e97133dbaff  lea r14, [rax+0x50]
00007e97133dbb03  movups xmm11, [r13+r14*1]
00007e97133dbb09  lea r14, [rax+0x60]
00007e97133dbb0d  movups xmm10, [r13+r14*1]
00007e97133dbb13  lea r14, [rax+0x30]
00007e97133dbb17  movups xmm9, [r13+r14*1]
00007e97133dbb1d  mov r14, [r15+0x50]
00007e97133dbb21  mov [r15+0x60], r14
00007e97133dbb25  mov qword ptr [r15+0x58], 0x40
00007e97133dbb2d  movaps xmm8, xmm12
00007e97133dbb31  mulpd xmm8, xmm15
00007e97133dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007e97133dbb3c  ptest xmm7, xmm7
00007e97133dbb41  jnz 0x00007E97133DC96A
00007e97133dbb47  movq xmm15, qword ptr [r15+0x230]
00007e97133dbb50  vmovaps [rsp+0x70], xmm15
00007e97133dbb56  vpermilpd xmm15, xmm15, 0x00
00007e97133dbb5c  movaps xmm7, xmm9
00007e97133dbb60  mulpd xmm7, xmm15
00007e97133dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007e97133dbb6a  ptest xmm6, xmm6
00007e97133dbb6f  jnz 0x00007E97133DCAAE
00007e97133dbb75  vxorps xmm15, xmm15, xmm15
00007e97133dbb7a  vpbroadcastq xmm15, xmm15
00007e97133dbb7f  movaps xmm9, xmm12
00007e97133dbb83  mulpd xmm9, xmm10
00007e97133dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007e97133dbb8e  ptest xmm6, xmm6
00007e97133dbb93  jnz 0x00007E97133DCBF0
00007e97133dbb99  movaps xmm10, xmm12
00007e97133dbb9d  mulpd xmm10, xmm11
00007e97133dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007e97133dbba8  ptest xmm6, xmm6
00007e97133dbbad  jnz 0x00007E97133DCD34
00007e97133dbbb3  movaps xmm11, [r15+0x1F0]
00007e97133dbbbb  movaps xmm6, xmm12
00007e97133dbbbf  mulpd xmm6, xmm11
00007e97133dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007e97133dbbc9  ptest xmm5, xmm5
00007e97133dbbce  jnz 0x00007E97133DCE78
00007e97133dbbd4  movaps xmm12, [r15+0x2A0]
00007e97133dbbdc  vmovaps [rsp+0x80], xmm12
00007e97133dbbe5  vmovaps xmm11, [rsp+0x80]
00007e97133dbbee  por xmm12, xmm11
00007e97133dbbf3  movaps xmm11, [r15+0x250]
00007e97133dbbfb  vmovaps [rsp+0x80], xmm11
00007e97133dbc04  vmovaps xmm5, [rsp+0x80]
00007e97133dbc0d  por xmm11, xmm5
00007e97133dbc12  vmovaps xmm4, [rsp+0x70]
00007e97133dbc18  vpermilpd xmm4, xmm4, 0x00
00007e97133dbc1e  movaps xmm3, xmm5
00007e97133dbc21  mulpd xmm3, xmm4
00007e97133dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007e97133dbc2a  ptest xmm2, xmm2
00007e97133dbc2f  jnz 0x00007E97133DCFBA
00007e97133dbc35  mov [rsp+0x80], rax
00007e97133dbc3d  xor eax, eax
00007e97133dbc3f  mov r12d, 0x40
00007e97133dbc45  mov r11d, 0x200
00007e97133dbc4b  cmp r12, r11
00007e97133dbc4e  cmc
00007e97133dbc4f  lahf
00007e97133dbc50  seto al
00007e97133dbc53  mov [r15+0x108], eax
00007e97133dbc5a  movaps xmm5, xmm8
00007e97133dbc5e  addpd xmm5, xmm15
00007e97133dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007e97133dbc68  ptest xmm4, xmm4
00007e97133dbc6d  jnz 0x00007E97133DD0FA
00007e97133dbc73  movaps xmm8, [r15+0x1B0]
00007e97133dbc7b  movaps xmm4, xmm9
00007e97133dbc7f  addpd xmm4, xmm8
00007e97133dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007e97133dbc89  ptest xmm2, xmm2
00007e97133dbc8e  jnz 0x00007E97133DD23C
00007e97133dbc94  movaps xmm9, xmm10
00007e97133dbc98  addpd xmm9, xmm8
00007e97133dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007e97133dbca3  ptest xmm2, xmm2
00007e97133dbca8  jnz 0x00007E97133DD37E
00007e97133dbcae  movaps xmm10, [r15+0x2F0]
00007e97133dbcb6  vmovaps [rsp+0x90], xmm10
00007e97133dbcbf  vmovaps xmm8, [rsp+0x90]
00007e97133dbcc8  por xmm10, xmm8
00007e97133dbccd  movaps xmm8, [r15+0x2E0]
00007e97133dbcd5  vmovaps [rsp+0x90], xmm8
00007e97133dbcde  vmovaps xmm2, [rsp+0x90]
00007e97133dbce7  por xmm8, xmm2
00007e97133dbcec  movaps xmm2, [r15+0x2D0]
00007e97133dbcf4  vmovaps [rsp+0x90], xmm2
00007e97133dbcfd  vmovaps [rsp+0xA0], xmm1
00007e97133dbd06  vmovaps xmm1, [rsp+0x90]
00007e97133dbd0f  por xmm2, xmm1
00007e97133dbd13  movaps xmm1, [r15+0x200]
00007e97133dbd1b  vmovaps [rsp+0x90], xmm1
00007e97133dbd24  vmovaps [rsp+0xB0], xmm15
00007e97133dbd2d  vmovaps xmm15, [rsp+0x90]
00007e97133dbd36  por xmm1, xmm15
00007e97133dbd3b  movaps xmm15, [r15+0x1C0]
00007e97133dbd43  vmovaps [rsp+0x90], xmm15
00007e97133dbd4c  vmovaps [rsp+0xC0], xmm1
00007e97133dbd55  vmovaps xmm1, [rsp+0x90]
00007e97133dbd5e  por xmm15, xmm1
00007e97133dbd63  movaps xmm1, [r15+0x190]
00007e97133dbd6b  vmovaps [rsp+0x90], xmm1
00007e97133dbd74  vmovaps [rsp+0xD0], xmm15
00007e97133dbd7d  vmovaps xmm15, [rsp+0x90]
00007e97133dbd86  por xmm1, xmm15
00007e97133dbd8b  movaps xmm15, [r15+0x300]
00007e97133dbd93  vmovaps [rsp+0x90], xmm15
00007e97133dbd9c  vmovaps [rsp+0xE0], xmm1
00007e97133dbda5  vmovaps xmm1, [rsp+0x90]
00007e97133dbdae  por xmm15, xmm1
00007e97133dbdb3  mov rax, [rsp+0x80]
00007e97133dbdbb  lea r12, [rax+0xA0]
00007e97133dbdc2  movups xmm1, [r13+r12*1]
00007e97133dbdc8  lea r12, [rax+0xB0]
00007e97133dbdcf  vmovaps [rsp+0x80], xmm1
00007e97133dbdd8  movups xmm1, [r13+r12*1]
00007e97133dbdde  vmovaps [rsp+0x90], xmm1
00007e97133dbde7  vmovaps [rsp+0xF0], xmm15
00007e97133dbdf0  vmovaps xmm15, [rsp+0xB0]
00007e97133dbdf9  vmovaps [rsp+0xB0], xmm14
00007e97133dbe02  movaps xmm1, xmm6
00007e97133dbe05  addpd xmm1, xmm15
00007e97133dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007e97133dbe0f  ptest xmm14, xmm14
00007e97133dbe15  jnz 0x00007E97133DD4D6
00007e97133dbe1b  lea r12, [rax+0xF0]
00007e97133dbe22  movups xmm15, [r13+r12*1]
00007e97133dbe28  movaps xmm14, xmm4
00007e97133dbe2c  addpd xmm14, xmm3
00007e97133dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007e97133dbe37  ptest xmm6, xmm6
00007e97133dbe3c  jnz 0x00007E97133DD621
00007e97133dbe42  movaps xmm6, xmm9
00007e97133dbe46  addpd xmm6, xmm7
00007e97133dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007e97133dbe4f  ptest xmm4, xmm4
00007e97133dbe54  jnz 0x00007E97133DD763
00007e97133dbe5a  vmovaps xmm9, [rsp+0x70]
00007e97133dbe60  vpermilpd xmm9, xmm9, 0x00
00007e97133dbe66  vmovaps xmm4, [rsp+0x90]
00007e97133dbe6f  movaps xmm7, xmm4
00007e97133dbe72  mulpd xmm7, xmm9
00007e97133dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007e97133dbe7c  ptest xmm3, xmm3
00007e97133dbe81  jnz 0x00007E97133DD8A4
00007e97133dbe87  vmovaps xmm9, [rsp+0x50]
00007e97133dbe8d  vpermilpd xmm9, xmm9, 0x00
00007e97133dbe93  movaps xmm4, xmm15
00007e97133dbe97  mulpd xmm4, xmm9
00007e97133dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007e97133dbea1  ptest xmm3, xmm3
00007e97133dbea6  jnz 0x00007E97133DD9E5
00007e97133dbeac  lea r12, [rax+0xE0]
00007e97133dbeb3  movups xmm15, [r13+r12*1]
00007e97133dbeb9  vmovaps xmm9, [rsp+0x70]
00007e97133dbebf  vpermilpd xmm9, xmm9, 0x00
00007e97133dbec5  vmovaps [rsp+0x70], xmm1
00007e97133dbecb  vmovaps xmm1, [rsp+0x80]
00007e97133dbed4  vmovaps [rsp+0x80], xmm15
00007e97133dbedd  movaps xmm3, xmm1
00007e97133dbee0  mulpd xmm3, xmm9
00007e97133dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007e97133dbeea  ptest xmm15, xmm15
00007e97133dbef0  jnz 0x00007E97133DDB31
00007e97133dbef6  vmovaps xmm1, [rsp+0xF0]
00007e97133dbeff  vmovaps xmm15, [rsp+0xF0]
00007e97133dbf08  por xmm1, xmm15
00007e97133dbf0d  movaps [r15+0x300], xmm1
00007e97133dbf15  vmovaps xmm15, [rsp+0xE0]
00007e97133dbf1e  vmovaps xmm9, [rsp+0xE0]
00007e97133dbf27  por xmm15, xmm9
00007e97133dbf2c  movaps [r15+0x190], xmm15
00007e97133dbf34  vmovaps xmm9, [rsp+0x50]
00007e97133dbf3a  vpermilpd xmm9, xmm9, 0x00
00007e97133dbf40  vmovaps [rsp+0x90], xmm1
00007e97133dbf49  vmovaps [rsp+0xE0], xmm15
00007e97133dbf52  vmovaps xmm15, [rsp+0x80]
00007e97133dbf5b  vmovaps [rsp+0x80], xmm14
00007e97133dbf64  movaps xmm1, xmm15
00007e97133dbf68  mulpd xmm1, xmm9
00007e97133dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007e97133dbf72  ptest xmm14, xmm14
00007e97133dbf78  jnz 0x00007E97133DDC72
00007e97133dbf7e  lea r12, [rax+0x90]
00007e97133dbf85  movups xmm15, [r13+r12*1]
00007e97133dbf8b  vmovaps xmm14, [rsp+0xD0]
00007e97133dbf94  vmovaps xmm9, [rsp+0xD0]
00007e97133dbf9d  por xmm14, xmm9
00007e97133dbfa2  movaps [r15+0x1C0], xmm14
00007e97133dbfaa  vmovaps xmm9, [rsp+0xC0]
00007e97133dbfb3  vmovaps [rsp+0xD0], xmm1
00007e97133dbfbc  vmovaps xmm1, [rsp+0xC0]
00007e97133dbfc5  por xmm9, xmm1
00007e97133dbfca  movaps [r15+0x200], xmm9
00007e97133dbfd2  vmovaps [rsp+0xC0], xmm2
00007e97133dbfdb  vmovaps xmm1, [rsp+0xC0]
00007e97133dbfe4  por xmm2, xmm1
00007e97133dbfe8  movaps [r15+0x2D0], xmm2
00007e97133dbff0  vmovaps [rsp+0xC0], xmm8
00007e97133dbff9  vmovaps xmm1, [rsp+0xC0]
00007e97133dc002  por xmm8, xmm1
00007e97133dc007  movaps [r15+0x2E0], xmm8
00007e97133dc00f  vmovaps [rsp+0xC0], xmm15
00007e97133dc018  movaps xmm1, xmm5
00007e97133dc01b  addpd xmm1, xmm7
00007e97133dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007e97133dc024  ptest xmm15, xmm15
00007e97133dc02a  jnz 0x00007E97133DDDBE
00007e97133dc030  vmovaps xmm15, [rsp+0x50]
00007e97133dc036  vpermilpd xmm15, xmm15, 0x00
00007e97133dc03c  vmovaps xmm5, [rsp+0xC0]
00007e97133dc045  vmovaps [rsp+0xC0], xmm1
00007e97133dc04e  movaps xmm7, xmm5
00007e97133dc051  mulpd xmm7, xmm15
00007e97133dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007e97133dc05b  ptest xmm1, xmm1
00007e97133dc060  jnz 0x00007E97133DDEFE
00007e97133dc066  lea r12, [rax+0x80]
00007e97133dc06d  movups xmm1, [r13+r12*1]
00007e97133dc073  vmovaps xmm5, [rsp+0x70]
00007e97133dc079  vmovaps [rsp+0x70], xmm1
00007e97133dc07f  movaps xmm15, xmm5
00007e97133dc083  addpd xmm15, xmm3
00007e97133dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007e97133dc08e  ptest xmm1, xmm1
00007e97133dc093  jnz 0x00007E97133DE049
00007e97133dc099  vmovaps xmm5, [rsp+0x80]
00007e97133dc0a2  movaps xmm1, xmm5
00007e97133dc0a5  addpd xmm1, xmm4
00007e97133dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007e97133dc0ae  ptest xmm3, xmm3
00007e97133dc0b3  jnz 0x00007E97133DE18B
00007e97133dc0b9  vmovaps [rsp+0x80], xmm10
00007e97133dc0c2  vmovaps xmm5, [rsp+0x80]
00007e97133dc0cb  por xmm10, xmm5
00007e97133dc0d0  movaps [r15+0x2F0], xmm10
00007e97133dc0d8  vmovaps xmm5, [rsp+0x50]
00007e97133dc0de  vpermilpd xmm5, xmm5, 0x00
00007e97133dc0e4  vmovaps xmm3, [rsp+0x70]
00007e97133dc0ea  vmovaps [rsp+0x50], xmm1
00007e97133dc0f0  movaps xmm4, xmm3
00007e97133dc0f3  mulpd xmm4, xmm5
00007e97133dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007e97133dc0fc  ptest xmm1, xmm1
00007e97133dc101  jnz 0x00007E97133DE2CB
00007e97133dc107  lea r12, [rax+0xD0]
00007e97133dc10e  movups xmm1, [r13+r12*1]
00007e97133dc114  vmovaps xmm3, [rsp+0xD0]
00007e97133dc11d  vmovaps [rsp+0x70], xmm1
00007e97133dc123  movaps xmm5, xmm6
00007e97133dc126  addpd xmm5, xmm3
00007e97133dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007e97133dc12f  ptest xmm1, xmm1
00007e97133dc134  jnz 0x00007E97133DE415
00007e97133dc13a  vmovaps xmm1, [rsp+0x60]
00007e97133dc140  vpermilpd xmm1, xmm1, 0x00
00007e97133dc146  movaps xmm6, xmm9
00007e97133dc14a  mulpd xmm6, xmm1
00007e97133dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007e97133dc153  ptest xmm3, xmm3
00007e97133dc158  jnz 0x00007E97133DE555
00007e97133dc15e  movaps [r15+0x260], xmm6
00007e97133dc166  vxorps xmm1, xmm1, xmm1
00007e97133dc16a  vpbroadcastq xmm1, xmm1
00007e97133dc16f  movaps [r15+0x1B0], xmm1
00007e97133dc177  vmovaps xmm1, [rsp+0x60]
00007e97133dc17d  vpermilpd xmm1, xmm1, 0x00
00007e97133dc183  vmovaps xmm3, [rsp+0x70]
00007e97133dc189  vmovaps [rsp+0x70], xmm15
00007e97133dc18f  movaps xmm9, xmm3
00007e97133dc193  mulpd xmm9, xmm1
00007e97133dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007e97133dc19e  ptest xmm15, xmm15
00007e97133dc1a4  jnz 0x00007E97133DE696
00007e97133dc1aa  lea r12, [rax+0xC0]
00007e97133dc1b1  movups xmm1, [r13+r12*1]
00007e97133dc1b7  vmovaps xmm3, [rsp+0xC0]
00007e97133dc1c0  vmovaps [rsp+0x80], xmm1
00007e97133dc1c9  movaps xmm15, xmm3
00007e97133dc1cd  addpd xmm15, xmm7
00007e97133dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007e97133dc1d8  ptest xmm1, xmm1
00007e97133dc1dd  jnz 0x00007E97133DE7E2
00007e97133dc1e3  vmovaps [rsp+0xC0], xmm13
00007e97133dc1ec  vmovaps xmm1, [rsp+0xC0]
00007e97133dc1f5  por xmm13, xmm1
00007e97133dc1fa  movaps [r15+0x270], xmm13
00007e97133dc202  vmovaps xmm1, [rsp+0xB0]
00007e97133dc20b  vmovaps xmm7, [rsp+0xB0]
00007e97133dc214  por xmm1, xmm7
00007e97133dc218  movaps [r15+0x1A0], xmm1
00007e97133dc220  vmovaps xmm1, [rsp+0x60]
00007e97133dc226  vpermilpd xmm1, xmm1, 0x00
00007e97133dc22c  vmovaps [rsp+0xB0], xmm1
00007e97133dc235  vmovaps xmm1, [rsp+0x80]
00007e97133dc23e  vmovaps [rsp+0x80], xmm15
00007e97133dc247  vmovaps xmm15, [rsp+0xB0]
00007e97133dc250  vmovaps [rsp+0xB0], xmm14
00007e97133dc259  movaps xmm3, xmm1
00007e97133dc25c  mulpd xmm3, xmm15
00007e97133dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007e97133dc266  ptest xmm14, xmm14
00007e97133dc26c  jnz 0x00007E97133DE924
00007e97133dc272  lea r12, [rax+0x20]
00007e97133dc276  movups xmm1, [r13+r12*1]
00007e97133dc27c  movaps [r15+0x110], xmm1
00007e97133dc284  vmovaps xmm14, [rsp+0x70]
00007e97133dc28a  vmovaps [rsp+0x70], xmm1
00007e97133dc290  movaps xmm15, xmm14
00007e97133dc294  addpd xmm15, xmm4
00007e97133dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007e97133dc29f  ptest xmm1, xmm1
00007e97133dc2a4  jnz 0x00007E97133DEA6F
00007e97133dc2aa  vmovaps xmm1, [rsp+0x60]
00007e97133dc2b0  vpermilpd xmm1, xmm1, 0x00
00007e97133dc2b6  movaps xmm14, xmm2
00007e97133dc2ba  mulpd xmm14, xmm1
00007e97133dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007e97133dc2c5  ptest xmm4, xmm4
00007e97133dc2ca  jnz 0x00007E97133DEBB2
00007e97133dc2d0  vmovaps xmm4, [rsp+0x50]
00007e97133dc2d6  movaps xmm1, xmm4
00007e97133dc2d9  addpd xmm1, xmm9
00007e97133dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007e97133dc2e3  ptest xmm2, xmm2
00007e97133dc2e8  jnz 0x00007E97133DECF4
00007e97133dc2ee  vmovaps xmm9, [rsp+0x30]
00007e97133dc2f4  vpermilpd xmm9, xmm9, 0x00
00007e97133dc2fa  vmovaps xmm2, [rsp+0x70]
00007e97133dc300  vmovaps [rsp+0x50], xmm1
00007e97133dc306  movaps xmm4, xmm2
00007e97133dc309  mulpd xmm4, xmm9
00007e97133dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007e97133dc313  ptest xmm1, xmm1
00007e97133dc318  jnz 0x00007E97133DEE35
00007e97133dc31e  vmovaps xmm1, [rsp+0x30]
00007e97133dc324  vpermilpd xmm1, xmm1, 0x00
00007e97133dc32a  vmovaps xmm2, [rsp+0x90]
00007e97133dc333  vmovaps [rsp+0x60], xmm15
00007e97133dc339  movaps xmm9, xmm2
00007e97133dc33d  mulpd xmm9, xmm1
00007e97133dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007e97133dc348  ptest xmm15, xmm15
00007e97133dc34e  jnz 0x00007E97133DEF76
00007e97133dc354  vmovaps xmm15, [rsp+0x80]
00007e97133dc35d  movaps xmm1, xmm15
00007e97133dc361  addpd xmm1, xmm6
00007e97133dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007e97133dc36a  ptest xmm2, xmm2
00007e97133dc36f  jnz 0x00007E97133DF0B8
00007e97133dc375  movaps xmm15, xmm5
00007e97133dc379  addpd xmm15, xmm3
00007e97133dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007e97133dc384  ptest xmm6, xmm6
00007e97133dc389  jnz 0x00007E97133DF1F9
00007e97133dc38f  vmovaps xmm6, [rsp+0x30]
00007e97133dc395  vpermilpd xmm6, xmm6, 0x00
00007e97133dc39b  movaps xmm5, xmm8
00007e97133dc39f  mulpd xmm5, xmm6
00007e97133dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007e97133dc3a8  ptest xmm3, xmm3
00007e97133dc3ad  jnz 0x00007E97133DF33B
00007e97133dc3b3  vmovaps xmm8, [rsp+0x30]
00007e97133dc3b9  vpermilpd xmm8, xmm8, 0x00
00007e97133dc3bf  movaps xmm6, xmm10
00007e97133dc3c3  mulpd xmm6, xmm8
00007e97133dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007e97133dc3cd  ptest xmm3, xmm3
00007e97133dc3d2  jnz 0x00007E97133DF47C
00007e97133dc3d8  vmovaps xmm8, [rsp+0x60]
00007e97133dc3de  movaps xmm10, xmm8
00007e97133dc3e2  addpd xmm10, xmm14
00007e97133dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007e97133dc3ed  ptest xmm3, xmm3
00007e97133dc3f2  jnz 0x00007E97133DF5BE
00007e97133dc3f8  vmovaps xmm8, [rsp+0x50]
00007e97133dc3fe  movaps xmm14, xmm8
00007e97133dc402  addpd xmm14, xmm4
00007e97133dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007e97133dc40d  ptest xmm3, xmm3
00007e97133dc412  jnz 0x00007E97133DF702
00007e97133dc418  vmovaps xmm8, [rsp+0x40]
00007e97133dc41e  vpermilpd xmm8, xmm8, 0x00
00007e97133dc424  movaps xmm4, xmm13
00007e97133dc428  mulpd xmm4, xmm8
00007e97133dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007e97133dc432  ptest xmm3, xmm3
00007e97133dc437  jnz 0x00007E97133DF845
00007e97133dc43d  movaps xmm13, xmm15
00007e97133dc441  addpd xmm13, xmm9
00007e97133dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007e97133dc44c  ptest xmm8, xmm8
00007e97133dc452  jnz 0x00007E97133DF987
00007e97133dc458  movaps xmm15, xmm1
00007e97133dc45c  addpd xmm15, xmm5
00007e97133dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007e97133dc467  ptest xmm9, xmm9
00007e97133dc46d  jnz 0x00007E97133DFACB
00007e97133dc473  vmovaps [rsp+0x30], xmm11
00007e97133dc479  vmovaps xmm1, [rsp+0x30]
00007e97133dc47f  por xmm11, xmm1
00007e97133dc484  movaps [r15+0x250], xmm11
00007e97133dc48c  vmovaps [rsp+0x30], xmm12
00007e97133dc492  vmovaps xmm1, [rsp+0x30]
00007e97133dc498  por xmm12, xmm1
00007e97133dc49d  movaps [r15+0x2A0], xmm12
00007e97133dc4a5  vmovaps xmm1, [rsp+0xA0]
00007e97133dc4ae  vmovaps xmm11, [rsp+0xA0]
00007e97133dc4b7  por xmm1, xmm11
00007e97133dc4bc  movaps [r15+0x1D0], xmm1
00007e97133dc4c4  lea r12, [rax+0x40]
00007e97133dc4c8  movups xmm1, [r13+r12*1]
00007e97133dc4ce  movaps [r15+0x2C0], xmm1
00007e97133dc4d6  vmovaps xmm11, [rsp+0x40]
00007e97133dc4dc  vpermilpd xmm11, xmm11, 0x00
00007e97133dc4e2  vmovaps xmm8, [rsp+0xE0]
00007e97133dc4eb  movaps xmm9, xmm8
00007e97133dc4ef  mulpd xmm9, xmm11
00007e97133dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007e97133dc4fa  ptest xmm5, xmm5
00007e97133dc4ff  jnz 0x00007E97133DFC17
00007e97133dc505  movaps xmm11, xmm10
00007e97133dc509  addpd xmm11, xmm6
00007e97133dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007e97133dc514  ptest xmm8, xmm8
00007e97133dc51a  jnz 0x00007E97133DFD5B
00007e97133dc520  movaps xmm10, xmm14
00007e97133dc524  addpd xmm10, xmm4
00007e97133dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007e97133dc52f  ptest xmm8, xmm8
00007e97133dc535  jnz 0x00007E97133DFE9E
00007e97133dc53b  vmovaps xmm14, [rsp+0x40]
00007e97133dc541  vpermilpd xmm14, xmm14, 0x00
00007e97133dc547  movaps xmm8, xmm1
00007e97133dc54b  mulpd xmm8, xmm14
00007e97133dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007e97133dc556  ptest xmm6, xmm6
00007e97133dc55b  jnz 0x00007E97133DFFE1
00007e97133dc561  movaps xmm1, [r15+0x2B0]
00007e97133dc569  vmovaps xmm14, [rsp+0x40]
00007e97133dc56f  vpermilpd xmm14, xmm14, 0x00
00007e97133dc575  movaps xmm6, xmm1
00007e97133dc578  mulpd xmm6, xmm14
00007e97133dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007e97133dc582  ptest xmm5, xmm5
00007e97133dc587  jnz 0x00007E97133E0124
00007e97133dc58d  vmovaps xmm1, [rsp+0x10]
00007e97133dc593  vpermilpd xmm1, xmm1, 0x00
00007e97133dc599  movaps xmm14, xmm12
00007e97133dc59d  mulpd xmm14, xmm1
00007e97133dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007e97133dc5a8  ptest xmm5, xmm5
00007e97133dc5ad  jnz 0x00007E97133E0265
00007e97133dc5b3  movaps xmm1, xmm13
00007e97133dc5b7  addpd xmm1, xmm9
00007e97133dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007e97133dc5c1  ptest xmm12, xmm12
00007e97133dc5c7  jnz 0x00007E97133E03A8
00007e97133dc5cd  vmovaps xmm13, [rsp+0x10]
00007e97133dc5d3  vpermilpd xmm13, xmm13, 0x00
00007e97133dc5d9  movaps xmm12, xmm7
00007e97133dc5dd  mulpd xmm12, xmm13
00007e97133dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007e97133dc5e8  ptest xmm9, xmm9
00007e97133dc5ee  jnz 0x00007E97133E04EA
00007e97133dc5f4  movaps xmm13, xmm15
00007e97133dc5f8  addpd xmm13, xmm8
00007e97133dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007e97133dc603  ptest xmm9, xmm9
00007e97133dc609  jnz 0x00007E97133E062D
00007e97133dc60f  movaps xmm15, [r15+0x290]
00007e97133dc617  vmovaps xmm9, [rsp+0x10]
00007e97133dc61d  vpermilpd xmm9, xmm9, 0x00
00007e97133dc623  movaps xmm8, xmm15
00007e97133dc627  mulpd xmm8, xmm9
00007e97133dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007e97133dc632  ptest xmm7, xmm7
00007e97133dc637  jnz 0x00007E97133E0771
00007e97133dc63d  movaps xmm15, xmm11
00007e97133dc641  addpd xmm15, xmm6
00007e97133dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007e97133dc64c  ptest xmm9, xmm9
00007e97133dc652  jnz 0x00007E97133E08B5
00007e97133dc658  movaps xmm11, [r15+0x1E0]
00007e97133dc660  vmovaps xmm9, [rsp+0x10]
00007e97133dc666  vpermilpd xmm9, xmm9, 0x00
00007e97133dc66c  movaps xmm7, xmm11
00007e97133dc670  mulpd xmm7, xmm9
00007e97133dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007e97133dc67a  ptest xmm6, xmm6
00007e97133dc67f  jnz 0x00007E97133E09F8
00007e97133dc685  movaps xmm11, xmm10
00007e97133dc689  addpd xmm11, xmm14
00007e97133dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007e97133dc694  ptest xmm9, xmm9
00007e97133dc69a  jnz 0x00007E97133E0B3A
00007e97133dc6a0  lea r12, [rax+0x70]
00007e97133dc6a4  movups xmm14, [r13+r12*1]
00007e97133dc6aa  movaps [r15+0x240], xmm14
00007e97133dc6b2  movaps xmm10, xmm1
00007e97133dc6b6  addpd xmm10, xmm12
00007e97133dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007e97133dc6c1  ptest xmm9, xmm9
00007e97133dc6c7  jnz 0x00007E97133E0C88
00007e97133dc6cd  movaps [r15+0x170], xmm10
00007e97133dc6d5  vmovaps xmm1, [rsp+0x20]
00007e97133dc6db  vpermilpd xmm1, xmm1, 0x00
00007e97133dc6e1  movaps xmm12, xmm14
00007e97133dc6e5  mulpd xmm12, xmm1
00007e97133dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007e97133dc6f0  ptest xmm9, xmm9
00007e97133dc6f6  jnz 0x00007E97133E0DCB
00007e97133dc6fc  vmovaps xmm1, [rsp+0x20]
00007e97133dc702  vpermilpd xmm1, xmm1, 0x00
00007e97133dc708  vmovaps xmm9, [rsp+0xB0]
00007e97133dc711  movaps xmm14, xmm9
00007e97133dc715  mulpd xmm14, xmm1
00007e97133dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007e97133dc720  ptest xmm6, xmm6
00007e97133dc725  jnz 0x00007E97133E0F0E
00007e97133dc72b  movaps [r15+0x180], xmm14
00007e97133dc733  movaps xmm1, xmm13
00007e97133dc737  addpd xmm1, xmm8
00007e97133dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007e97133dc741  ptest xmm9, xmm9
00007e97133dc747  jnz 0x00007E97133E1051
00007e97133dc74d  movaps [r15+0x210], xmm1
00007e97133dc755  movups xmm13, [r13+rax*1]
00007e97133dc75b  lea r12, [rax+0x10]
00007e97133dc75f  movups xmm9, [r13+r12*1]
00007e97133dc765  movaps [r15+0x230], xmm9
00007e97133dc76d  movaps xmm8, xmm15
00007e97133dc771  addpd xmm8, xmm7
00007e97133dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007e97133dc77c  ptest xmm6, xmm6
00007e97133dc781  jnz 0x00007E97133E11A7
00007e97133dc787  movaps [r15+0x130], xmm8
00007e97133dc78f  vmovaps xmm15, [rsp+0x20]
00007e97133dc795  vpermilpd xmm15, xmm15, 0x00
00007e97133dc79b  movaps xmm7, xmm9
00007e97133dc79f  mulpd xmm7, xmm15
00007e97133dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007e97133dc7a9  ptest xmm6, xmm6
00007e97133dc7ae  jnz 0x00007E97133E12EA
00007e97133dc7b4  movaps [r15+0x220], xmm7
00007e97133dc7bc  vmovaps xmm15, [rsp+0x20]
00007e97133dc7c2  vpermilpd xmm15, xmm15, 0x00
00007e97133dc7c8  movaps xmm9, xmm13
00007e97133dc7cc  mulpd xmm9, xmm15
00007e97133dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007e97133dc7d7  ptest xmm6, xmm6
00007e97133dc7dc  jnz 0x00007E97133E142C
00007e97133dc7e2  movaps xmm15, xmm11
00007e97133dc7e6  addpd xmm15, xmm12
00007e97133dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007e97133dc7f1  ptest xmm13, xmm13
00007e97133dc7f7  jnz 0x00007E97133E1570
00007e97133dc7fd  movaps [r15+0x140], xmm15
00007e97133dc805  movaps xmm13, xmm10
00007e97133dc809  addpd xmm13, xmm14
00007e97133dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007e97133dc814  ptest xmm12, xmm12
00007e97133dc81a  jnz 0x00007E97133E16B4
00007e97133dc820  movaps [r15+0x150], xmm13
00007e97133dc828  movaps xmm14, xmm1
00007e97133dc82c  addpd xmm14, xmm7
00007e97133dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007e97133dc837  ptest xmm12, xmm12
00007e97133dc83d  jnz 0x00007E97133E17F8
00007e97133dc843  movaps [r15+0x160], xmm14
00007e97133dc84b  movaps xmm1, xmm8
00007e97133dc84f  addpd xmm1, xmm9
00007e97133dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007e97133dc859  ptest xmm12, xmm12
00007e97133dc85f  jnz 0x00007E97133E193A
00007e97133dc865  movaps [r15+0x120], xmm1
00007e97133dc86d  movups [r13+r14*1], xmm15
00007e97133dc873  lea rax, [r14+0x10]
00007e97133dc877  movups [r13+rax*1], xmm13
00007e97133dc87d  lea rax, [r14+0x20]
00007e97133dc881  movups [r13+rax*1], xmm14
00007e97133dc887  lea rax, [r14+0x30]
00007e97133dc88b  movups [r13+rax*1], xmm1
00007e97133dc891  mov eax, [r15+0x108]
00007e97133dc898  sahf
00007e97133dc899  jnz 0x00007E97133DC8CB
00007e97133dc89b  cmp dword ptr [r15+0x318], 0x00
00007e97133dc8a3  jz 0x00007E97133DB900
00007e97133dc8a9  nop [rax+rax*1], ax
00007e97133dc8b2  nop [rax+rax*1], eax
00007e97133dc8ba  mov eax, 0x410444
00007e97133dc8bf  mov [r15+0x100], rax
00007e97133dc8c6  jmp 0x00007E97131FE110
00007e97133dc8cb  cmp dword ptr [r15+0x318], 0x00
00007e97133dc8d3  jz 0x00007E97133D57E0
00007e97133dc8d9  nop [rax+rax*1], ax
00007e97133dc8e2  nop [rax+rax*1], eax
00007e97133dc8ea  mov eax, 0x410278
00007e97133dc8ef  mov [r15+0x100], rax
00007e97133dc8f6  jmp 0x00007E97131FE110
00007e97133dc8fb  int3
00007e97133dc8fc  call 0x00007E97132E27E0
00007e97133dc901  jmp 0x00007E97133DB9DF
00007e97133dc906  call 0x00007E97132E1570
00007e97133dc90b  jmp 0x00007E97133DB9E8
00007e97133dc910  call 0x00007E97132E27E0
00007e97133dc915  jmp 0x00007E97133DBA44
00007e97133dc91a  call 0x00007E97132E1570
00007e97133dc91f  jmp 0x00007E97133DBA4D
00007e97133dc924  call 0x00007E97132E27E0
00007e97133dc929  jmp 0x00007E97133DBA90
00007e97133dc92e  call 0x00007E97132E1570
00007e97133dc933  jmp 0x00007E97133DBA99
00007e97133dc938  call 0x00007E971320DC20
00007e97133dc93d  jmp 0x00007E97133DBAD8
00007e97133dc942  call 0x00007E97132D59C0
00007e97133dc947  jmp 0x00007E97133DBAEB
00007e97133dc94c  call 0x00007E97132E0E30
00007e97133dc951  jmp 0x00007E97133DBB09
00007e97133dc956  call 0x00007E97132DFBC0
00007e97133dc95b  jmp 0x00007E97133DBB13
00007e97133dc960  call 0x00007E97132DE950
00007e97133dc965  jmp 0x00007E97133DBB1D
00007e97133dc96a  sub rsp, 0x08
00007e97133dc96e  push rax
00007e97133dc96f  push rcx
00007e97133dc970  push rdx
00007e97133dc971  push rdi
00007e97133dc972  push rsi
00007e97133dc973  push r8
00007e97133dc975  push r9
00007e97133dc977  push r10
00007e97133dc979  push r11
00007e97133dc97b  sub rsp, 0xF0
00007e97133dc982  vmovaps [rsp], xmm0
00007e97133dc987  vmovaps [rsp+0x10], xmm1
00007e97133dc98d  vmovaps [rsp+0x20], xmm2
00007e97133dc993  vmovaps [rsp+0x30], xmm3
00007e97133dc999  vmovaps [rsp+0x40], xmm4
00007e97133dc99f  vmovaps [rsp+0x50], xmm5
00007e97133dc9a5  vmovaps [rsp+0x60], xmm6
00007e97133dc9ab  vmovaps [rsp+0x70], xmm7
00007e97133dc9b1  vmovaps [rsp+0x80], xmm9
00007e97133dc9ba  vmovaps [rsp+0x90], xmm10
00007e97133dc9c3  vmovaps [rsp+0xA0], xmm11
00007e97133dc9cc  vmovaps [rsp+0xB0], xmm12
00007e97133dc9d5  vmovaps [rsp+0xC0], xmm13
00007e97133dc9de  vmovaps [rsp+0xD0], xmm14
00007e97133dc9e7  vmovaps [rsp+0xE0], xmm15
00007e97133dc9f0  sub rsp, 0x30
00007e97133dc9f4  movaps [rsp], xmm8
00007e97133dc9f9  movaps [rsp+0x10], xmm12
00007e97133dc9ff  movaps [rsp+0x20], xmm15
00007e97133dca05  lea rdi, [rsp]
00007e97133dca09  mov esi, 0x00
00007e97133dca0e  mov rax, 0x58D8AED5F530
00007e97133dca18  call rax
00007e97133dca1a  movaps xmm8, [rsp]
00007e97133dca1f  add rsp, 0x30
00007e97133dca23  vmovaps xmm0, [rsp]
00007e97133dca28  vmovaps xmm1, [rsp+0x10]
00007e97133dca2e  vmovaps xmm2, [rsp+0x20]
00007e97133dca34  vmovaps xmm3, [rsp+0x30]
00007e97133dca3a  vmovaps xmm4, [rsp+0x40]
00007e97133dca40  vmovaps xmm5, [rsp+0x50]
00007e97133dca46  vmovaps xmm6, [rsp+0x60]
00007e97133dca4c  vmovaps xmm7, [rsp+0x70]
00007e97133dca52  vmovaps xmm9, [rsp+0x80]
00007e97133dca5b  vmovaps xmm10, [rsp+0x90]
00007e97133dca64  vmovaps xmm11, [rsp+0xA0]
00007e97133dca6d  vmovaps xmm12, [rsp+0xB0]
00007e97133dca76  vmovaps xmm13, [rsp+0xC0]
00007e97133dca7f  vmovaps xmm14, [rsp+0xD0]
00007e97133dca88  vmovaps xmm15, [rsp+0xE0]
00007e97133dca91  add rsp, 0xF0
00007e97133dca98  pop r11
00007e97133dca9a  pop r10
00007e97133dca9c  pop r9
00007e97133dca9e  pop r8
00007e97133dcaa0  pop rsi
00007e97133dcaa1  pop rdi
00007e97133dcaa2  pop rdx
00007e97133dcaa3  pop rcx
00007e97133dcaa4  pop rax
00007e97133dcaa5  add rsp, 0x08
00007e97133dcaa9  jmp 0x00007E97133DBB47
00007e97133dcaae  sub rsp, 0x08
00007e97133dcab2  push rax
00007e97133dcab3  push rcx
00007e97133dcab4  push rdx
00007e97133dcab5  push rdi
00007e97133dcab6  push rsi
00007e97133dcab7  push r8
00007e97133dcab9  push r9
00007e97133dcabb  push r10
00007e97133dcabd  push r11
00007e97133dcabf  sub rsp, 0xF0
00007e97133dcac6  vmovaps [rsp], xmm0
00007e97133dcacb  vmovaps [rsp+0x10], xmm1
00007e97133dcad1  vmovaps [rsp+0x20], xmm2
00007e97133dcad7  vmovaps [rsp+0x30], xmm3
00007e97133dcadd  vmovaps [rsp+0x40], xmm4
00007e97133dcae3  vmovaps [rsp+0x50], xmm5
00007e97133dcae9  vmovaps [rsp+0x60], xmm6
00007e97133dcaef  vmovaps [rsp+0x70], xmm8
00007e97133dcaf5  vmovaps [rsp+0x80], xmm9
00007e97133dcafe  vmovaps [rsp+0x90], xmm10
00007e97133dcb07  vmovaps [rsp+0xA0], xmm11
00007e97133dcb10  vmovaps [rsp+0xB0], xmm12
00007e97133dcb19  vmovaps [rsp+0xC0], xmm13
00007e97133dcb22  vmovaps [rsp+0xD0], xmm14
00007e97133dcb2b  vmovaps [rsp+0xE0], xmm15
00007e97133dcb34  sub rsp, 0x30
00007e97133dcb38  movaps [rsp], xmm7
00007e97133dcb3c  movaps [rsp+0x10], xmm9
00007e97133dcb42  movaps [rsp+0x20], xmm15
00007e97133dcb48  lea rdi, [rsp]
00007e97133dcb4c  mov esi, 0x00
00007e97133dcb51  mov rax, 0x58D8AED5F530
00007e97133dcb5b  call rax
00007e97133dcb5d  movaps xmm7, [rsp]
00007e97133dcb61  add rsp, 0x30
00007e97133dcb65  vmovaps xmm0, [rsp]
00007e97133dcb6a  vmovaps xmm1, [rsp+0x10]
00007e97133dcb70  vmovaps xmm2, [rsp+0x20]
00007e97133dcb76  vmovaps xmm3, [rsp+0x30]
00007e97133dcb7c  vmovaps xmm4, [rsp+0x40]
00007e97133dcb82  vmovaps xmm5, [rsp+0x50]
00007e97133dcb88  vmovaps xmm6, [rsp+0x60]
00007e97133dcb8e  vmovaps xmm8, [rsp+0x70]
00007e97133dcb94  vmovaps xmm9, [rsp+0x80]
00007e97133dcb9d  vmovaps xmm10, [rsp+0x90]
00007e97133dcba6  vmovaps xmm11, [rsp+0xA0]
00007e97133dcbaf  vmovaps xmm12, [rsp+0xB0]
00007e97133dcbb8  vmovaps xmm13, [rsp+0xC0]
00007e97133dcbc1  vmovaps xmm14, [rsp+0xD0]
00007e97133dcbca  vmovaps xmm15, [rsp+0xE0]
00007e97133dcbd3  add rsp, 0xF0
00007e97133dcbda  pop r11
00007e97133dcbdc  pop r10
00007e97133dcbde  pop r9
00007e97133dcbe0  pop r8
00007e97133dcbe2  pop rsi
00007e97133dcbe3  pop rdi
00007e97133dcbe4  pop rdx
00007e97133dcbe5  pop rcx
00007e97133dcbe6  pop rax
00007e97133dcbe7  add rsp, 0x08
00007e97133dcbeb  jmp 0x00007E97133DBB75
00007e97133dcbf0  sub rsp, 0x08
00007e97133dcbf4  push rax
00007e97133dcbf5  push rcx
00007e97133dcbf6  push rdx
00007e97133dcbf7  push rdi
00007e97133dcbf8  push rsi
00007e97133dcbf9  push r8
00007e97133dcbfb  push r9
00007e97133dcbfd  push r10
00007e97133dcbff  push r11
00007e97133dcc01  sub rsp, 0xF0
00007e97133dcc08  vmovaps [rsp], xmm0
00007e97133dcc0d  vmovaps [rsp+0x10], xmm1
00007e97133dcc13  vmovaps [rsp+0x20], xmm2
00007e97133dcc19  vmovaps [rsp+0x30], xmm3
00007e97133dcc1f  vmovaps [rsp+0x40], xmm4
00007e97133dcc25  vmovaps [rsp+0x50], xmm5
00007e97133dcc2b  vmovaps [rsp+0x60], xmm6
00007e97133dcc31  vmovaps [rsp+0x70], xmm7
00007e97133dcc37  vmovaps [rsp+0x80], xmm8
00007e97133dcc40  vmovaps [rsp+0x90], xmm10
00007e97133dcc49  vmovaps [rsp+0xA0], xmm11
00007e97133dcc52  vmovaps [rsp+0xB0], xmm12
00007e97133dcc5b  vmovaps [rsp+0xC0], xmm13
00007e97133dcc64  vmovaps [rsp+0xD0], xmm14
00007e97133dcc6d  vmovaps [rsp+0xE0], xmm15
00007e97133dcc76  sub rsp, 0x30
00007e97133dcc7a  movaps [rsp], xmm9
00007e97133dcc7f  movaps [rsp+0x10], xmm12
00007e97133dcc85  movaps [rsp+0x20], xmm10
00007e97133dcc8b  lea rdi, [rsp]
00007e97133dcc8f  mov esi, 0x00
00007e97133dcc94  mov rax, 0x58D8AED5F530
00007e97133dcc9e  call rax
00007e97133dcca0  movaps xmm9, [rsp]
00007e97133dcca5  add rsp, 0x30
00007e97133dcca9  vmovaps xmm0, [rsp]
00007e97133dccae  vmovaps xmm1, [rsp+0x10]
00007e97133dccb4  vmovaps xmm2, [rsp+0x20]
00007e97133dccba  vmovaps xmm3, [rsp+0x30]
00007e97133dccc0  vmovaps xmm4, [rsp+0x40]
00007e97133dccc6  vmovaps xmm5, [rsp+0x50]
00007e97133dcccc  vmovaps xmm6, [rsp+0x60]
00007e97133dccd2  vmovaps xmm7, [rsp+0x70]
00007e97133dccd8  vmovaps xmm8, [rsp+0x80]
00007e97133dcce1  vmovaps xmm10, [rsp+0x90]
00007e97133dccea  vmovaps xmm11, [rsp+0xA0]
00007e97133dccf3  vmovaps xmm12, [rsp+0xB0]
00007e97133dccfc  vmovaps xmm13, [rsp+0xC0]
00007e97133dcd05  vmovaps xmm14, [rsp+0xD0]
00007e97133dcd0e  vmovaps xmm15, [rsp+0xE0]
00007e97133dcd17  add rsp, 0xF0
00007e97133dcd1e  pop r11
00007e97133dcd20  pop r10
00007e97133dcd22  pop r9
00007e97133dcd24  pop r8
00007e97133dcd26  pop rsi
00007e97133dcd27  pop rdi
00007e97133dcd28  pop rdx
00007e97133dcd29  pop rcx
00007e97133dcd2a  pop rax
00007e97133dcd2b  add rsp, 0x08
00007e97133dcd2f  jmp 0x00007E97133DBB99
00007e97133dcd34  sub rsp, 0x08
00007e97133dcd38  push rax
00007e97133dcd39  push rcx
00007e97133dcd3a  push rdx
00007e97133dcd3b  push rdi
00007e97133dcd3c  push rsi
00007e97133dcd3d  push r8
00007e97133dcd3f  push r9
00007e97133dcd41  push r10
00007e97133dcd43  push r11
00007e97133dcd45  sub rsp, 0xF0
00007e97133dcd4c  vmovaps [rsp], xmm0
00007e97133dcd51  vmovaps [rsp+0x10], xmm1
00007e97133dcd57  vmovaps [rsp+0x20], xmm2
00007e97133dcd5d  vmovaps [rsp+0x30], xmm3
00007e97133dcd63  vmovaps [rsp+0x40], xmm4
00007e97133dcd69  vmovaps [rsp+0x50], xmm5
00007e97133dcd6f  vmovaps [rsp+0x60], xmm6
00007e97133dcd75  vmovaps [rsp+0x70], xmm7
00007e97133dcd7b  vmovaps [rsp+0x80], xmm8
00007e97133dcd84  vmovaps [rsp+0x90], xmm9
00007e97133dcd8d  vmovaps [rsp+0xA0], xmm11
00007e97133dcd96  vmovaps [rsp+0xB0], xmm12
00007e97133dcd9f  vmovaps [rsp+0xC0], xmm13
00007e97133dcda8  vmovaps [rsp+0xD0], xmm14
00007e97133dcdb1  vmovaps [rsp+0xE0], xmm15
00007e97133dcdba  sub rsp, 0x30
00007e97133dcdbe  movaps [rsp], xmm10
00007e97133dcdc3  movaps [rsp+0x10], xmm12
00007e97133dcdc9  movaps [rsp+0x20], xmm11
00007e97133dcdcf  lea rdi, [rsp]
00007e97133dcdd3  mov esi, 0x00
00007e97133dcdd8  mov rax, 0x58D8AED5F530
00007e97133dcde2  call rax
00007e97133dcde4  movaps xmm10, [rsp]
00007e97133dcde9  add rsp, 0x30
00007e97133dcded  vmovaps xmm0, [rsp]
00007e97133dcdf2  vmovaps xmm1, [rsp+0x10]
00007e97133dcdf8  vmovaps xmm2, [rsp+0x20]
00007e97133dcdfe  vmovaps xmm3, [rsp+0x30]
00007e97133dce04  vmovaps xmm4, [rsp+0x40]
00007e97133dce0a  vmovaps xmm5, [rsp+0x50]
00007e97133dce10  vmovaps xmm6, [rsp+0x60]
00007e97133dce16  vmovaps xmm7, [rsp+0x70]
00007e97133dce1c  vmovaps xmm8, [rsp+0x80]
00007e97133dce25  vmovaps xmm9, [rsp+0x90]
00007e97133dce2e  vmovaps xmm11, [rsp+0xA0]
00007e97133dce37  vmovaps xmm12, [rsp+0xB0]
00007e97133dce40  vmovaps xmm13, [rsp+0xC0]
00007e97133dce49  vmovaps xmm14, [rsp+0xD0]
00007e97133dce52  vmovaps xmm15, [rsp+0xE0]
00007e97133dce5b  add rsp, 0xF0
00007e97133dce62  pop r11
00007e97133dce64  pop r10
00007e97133dce66  pop r9
00007e97133dce68  pop r8
00007e97133dce6a  pop rsi
00007e97133dce6b  pop rdi
00007e97133dce6c  pop rdx
00007e97133dce6d  pop rcx
00007e97133dce6e  pop rax
00007e97133dce6f  add rsp, 0x08
00007e97133dce73  jmp 0x00007E97133DBBB3
00007e97133dce78  sub rsp, 0x08
00007e97133dce7c  push rax
00007e97133dce7d  push rcx
00007e97133dce7e  push rdx
00007e97133dce7f  push rdi
00007e97133dce80  push rsi
00007e97133dce81  push r8
00007e97133dce83  push r9
00007e97133dce85  push r10
00007e97133dce87  push r11
00007e97133dce89  sub rsp, 0xF0
00007e97133dce90  vmovaps [rsp], xmm0
00007e97133dce95  vmovaps [rsp+0x10], xmm1
00007e97133dce9b  vmovaps [rsp+0x20], xmm2
00007e97133dcea1  vmovaps [rsp+0x30], xmm3
00007e97133dcea7  vmovaps [rsp+0x40], xmm4
00007e97133dcead  vmovaps [rsp+0x50], xmm5
00007e97133dceb3  vmovaps [rsp+0x60], xmm7
00007e97133dceb9  vmovaps [rsp+0x70], xmm8
00007e97133dcebf  vmovaps [rsp+0x80], xmm9
00007e97133dcec8  vmovaps [rsp+0x90], xmm10
00007e97133dced1  vmovaps [rsp+0xA0], xmm11
00007e97133dceda  vmovaps [rsp+0xB0], xmm12
00007e97133dcee3  vmovaps [rsp+0xC0], xmm13
00007e97133dceec  vmovaps [rsp+0xD0], xmm14
00007e97133dcef5  vmovaps [rsp+0xE0], xmm15
00007e97133dcefe  sub rsp, 0x30
00007e97133dcf02  movaps [rsp], xmm6
00007e97133dcf06  movaps [rsp+0x10], xmm12
00007e97133dcf0c  movaps [rsp+0x20], xmm11
00007e97133dcf12  lea rdi, [rsp]
00007e97133dcf16  mov esi, 0x00
00007e97133dcf1b  mov rax, 0x58D8AED5F530
00007e97133dcf25  call rax
00007e97133dcf27  movaps xmm6, [rsp]
00007e97133dcf2b  add rsp, 0x30
00007e97133dcf2f  vmovaps xmm0, [rsp]
00007e97133dcf34  vmovaps xmm1, [rsp+0x10]
00007e97133dcf3a  vmovaps xmm2, [rsp+0x20]
00007e97133dcf40  vmovaps xmm3, [rsp+0x30]
00007e97133dcf46  vmovaps xmm4, [rsp+0x40]
00007e97133dcf4c  vmovaps xmm5, [rsp+0x50]
00007e97133dcf52  vmovaps xmm7, [rsp+0x60]
00007e97133dcf58  vmovaps xmm8, [rsp+0x70]
00007e97133dcf5e  vmovaps xmm9, [rsp+0x80]
00007e97133dcf67  vmovaps xmm10, [rsp+0x90]
00007e97133dcf70  vmovaps xmm11, [rsp+0xA0]
00007e97133dcf79  vmovaps xmm12, [rsp+0xB0]
00007e97133dcf82  vmovaps xmm13, [rsp+0xC0]
00007e97133dcf8b  vmovaps xmm14, [rsp+0xD0]
00007e97133dcf94  vmovaps xmm15, [rsp+0xE0]
00007e97133dcf9d  add rsp, 0xF0
00007e97133dcfa4  pop r11
00007e97133dcfa6  pop r10
00007e97133dcfa8  pop r9
00007e97133dcfaa  pop r8
00007e97133dcfac  pop rsi
00007e97133dcfad  pop rdi
00007e97133dcfae  pop rdx
00007e97133dcfaf  pop rcx
00007e97133dcfb0  pop rax
00007e97133dcfb1  add rsp, 0x08
00007e97133dcfb5  jmp 0x00007E97133DBBD4
00007e97133dcfba  sub rsp, 0x08
00007e97133dcfbe  push rax
00007e97133dcfbf  push rcx
00007e97133dcfc0  push rdx
00007e97133dcfc1  push rdi
00007e97133dcfc2  push rsi
00007e97133dcfc3  push r8
00007e97133dcfc5  push r9
00007e97133dcfc7  push r10
00007e97133dcfc9  push r11
00007e97133dcfcb  sub rsp, 0xF0
00007e97133dcfd2  vmovaps [rsp], xmm0
00007e97133dcfd7  vmovaps [rsp+0x10], xmm1
00007e97133dcfdd  vmovaps [rsp+0x20], xmm2
00007e97133dcfe3  vmovaps [rsp+0x30], xmm4
00007e97133dcfe9  vmovaps [rsp+0x40], xmm5
00007e97133dcfef  vmovaps [rsp+0x50], xmm6
00007e97133dcff5  vmovaps [rsp+0x60], xmm7
00007e97133dcffb  vmovaps [rsp+0x70], xmm8
00007e97133dd001  vmovaps [rsp+0x80], xmm9
00007e97133dd00a  vmovaps [rsp+0x90], xmm10
00007e97133dd013  vmovaps [rsp+0xA0], xmm11
00007e97133dd01c  vmovaps [rsp+0xB0], xmm12
00007e97133dd025  vmovaps [rsp+0xC0], xmm13
00007e97133dd02e  vmovaps [rsp+0xD0], xmm14
00007e97133dd037  vmovaps [rsp+0xE0], xmm15
00007e97133dd040  sub rsp, 0x30
00007e97133dd044  movaps [rsp], xmm3
00007e97133dd048  movaps [rsp+0x10], xmm5
00007e97133dd04d  movaps [rsp+0x20], xmm4
00007e97133dd052  lea rdi, [rsp]
00007e97133dd056  mov esi, 0x00
00007e97133dd05b  mov rax, 0x58D8AED5F530
00007e97133dd065  call rax
00007e97133dd067  movaps xmm3, [rsp]
00007e97133dd06b  add rsp, 0x30
00007e97133dd06f  vmovaps xmm0, [rsp]
00007e97133dd074  vmovaps xmm1, [rsp+0x10]
00007e97133dd07a  vmovaps xmm2, [rsp+0x20]
00007e97133dd080  vmovaps xmm4, [rsp+0x30]
00007e97133dd086  vmovaps xmm5, [rsp+0x40]
00007e97133dd08c  vmovaps xmm6, [rsp+0x50]
00007e97133dd092  vmovaps xmm7, [rsp+0x60]
00007e97133dd098  vmovaps xmm8, [rsp+0x70]
00007e97133dd09e  vmovaps xmm9, [rsp+0x80]
00007e97133dd0a7  vmovaps xmm10, [rsp+0x90]
00007e97133dd0b0  vmovaps xmm11, [rsp+0xA0]
00007e97133dd0b9  vmovaps xmm12, [rsp+0xB0]
00007e97133dd0c2  vmovaps xmm13, [rsp+0xC0]
00007e97133dd0cb  vmovaps xmm14, [rsp+0xD0]
00007e97133dd0d4  vmovaps xmm15, [rsp+0xE0]
00007e97133dd0dd  add rsp, 0xF0
00007e97133dd0e4  pop r11
00007e97133dd0e6  pop r10
00007e97133dd0e8  pop r9
00007e97133dd0ea  pop r8
00007e97133dd0ec  pop rsi
00007e97133dd0ed  pop rdi
00007e97133dd0ee  pop rdx
00007e97133dd0ef  pop rcx
00007e97133dd0f0  pop rax
00007e97133dd0f1  add rsp, 0x08
00007e97133dd0f5  jmp 0x00007E97133DBC35
00007e97133dd0fa  sub rsp, 0x08
00007e97133dd0fe  push rax
00007e97133dd0ff  push rcx
00007e97133dd100  push rdx
00007e97133dd101  push rdi
00007e97133dd102  push rsi
00007e97133dd103  push r8
00007e97133dd105  push r9
00007e97133dd107  push r10
00007e97133dd109  push r11
00007e97133dd10b  sub rsp, 0xF0
00007e97133dd112  vmovaps [rsp], xmm0
00007e97133dd117  vmovaps [rsp+0x10], xmm1
00007e97133dd11d  vmovaps [rsp+0x20], xmm2
00007e97133dd123  vmovaps [rsp+0x30], xmm3
00007e97133dd129  vmovaps [rsp+0x40], xmm4
00007e97133dd12f  vmovaps [rsp+0x50], xmm6
00007e97133dd135  vmovaps [rsp+0x60], xmm7
00007e97133dd13b  vmovaps [rsp+0x70], xmm8
00007e97133dd141  vmovaps [rsp+0x80], xmm9
00007e97133dd14a  vmovaps [rsp+0x90], xmm10
00007e97133dd153  vmovaps [rsp+0xA0], xmm11
00007e97133dd15c  vmovaps [rsp+0xB0], xmm12
00007e97133dd165  vmovaps [rsp+0xC0], xmm13
00007e97133dd16e  vmovaps [rsp+0xD0], xmm14
00007e97133dd177  vmovaps [rsp+0xE0], xmm15
00007e97133dd180  sub rsp, 0x30
00007e97133dd184  movaps [rsp], xmm5
00007e97133dd188  movaps [rsp+0x10], xmm8
00007e97133dd18e  movaps [rsp+0x20], xmm15
00007e97133dd194  lea rdi, [rsp]
00007e97133dd198  mov esi, 0x00
00007e97133dd19d  mov rax, 0x58D8AED5F530
00007e97133dd1a7  call rax
00007e97133dd1a9  movaps xmm5, [rsp]
00007e97133dd1ad  add rsp, 0x30
00007e97133dd1b1  vmovaps xmm0, [rsp]
00007e97133dd1b6  vmovaps xmm1, [rsp+0x10]
00007e97133dd1bc  vmovaps xmm2, [rsp+0x20]
00007e97133dd1c2  vmovaps xmm3, [rsp+0x30]
00007e97133dd1c8  vmovaps xmm4, [rsp+0x40]
00007e97133dd1ce  vmovaps xmm6, [rsp+0x50]
00007e97133dd1d4  vmovaps xmm7, [rsp+0x60]
00007e97133dd1da  vmovaps xmm8, [rsp+0x70]
00007e97133dd1e0  vmovaps xmm9, [rsp+0x80]
00007e97133dd1e9  vmovaps xmm10, [rsp+0x90]
00007e97133dd1f2  vmovaps xmm11, [rsp+0xA0]
00007e97133dd1fb  vmovaps xmm12, [rsp+0xB0]
00007e97133dd204  vmovaps xmm13, [rsp+0xC0]
00007e97133dd20d  vmovaps xmm14, [rsp+0xD0]
00007e97133dd216  vmovaps xmm15, [rsp+0xE0]
00007e97133dd21f  add rsp, 0xF0
00007e97133dd226  pop r11
00007e97133dd228  pop r10
00007e97133dd22a  pop r9
00007e97133dd22c  pop r8
00007e97133dd22e  pop rsi
00007e97133dd22f  pop rdi
00007e97133dd230  pop rdx
00007e97133dd231  pop rcx
00007e97133dd232  pop rax
00007e97133dd233  add rsp, 0x08
00007e97133dd237  jmp 0x00007E97133DBC73
00007e97133dd23c  sub rsp, 0x08
00007e97133dd240  push rax
00007e97133dd241  push rcx
00007e97133dd242  push rdx
00007e97133dd243  push rdi
00007e97133dd244  push rsi
00007e97133dd245  push r8
00007e97133dd247  push r9
00007e97133dd249  push r10
00007e97133dd24b  push r11
00007e97133dd24d  sub rsp, 0xF0
00007e97133dd254  vmovaps [rsp], xmm0
00007e97133dd259  vmovaps [rsp+0x10], xmm1
00007e97133dd25f  vmovaps [rsp+0x20], xmm2
00007e97133dd265  vmovaps [rsp+0x30], xmm3
00007e97133dd26b  vmovaps [rsp+0x40], xmm5
00007e97133dd271  vmovaps [rsp+0x50], xmm6
00007e97133dd277  vmovaps [rsp+0x60], xmm7
00007e97133dd27d  vmovaps [rsp+0x70], xmm8
00007e97133dd283  vmovaps [rsp+0x80], xmm9
00007e97133dd28c  vmovaps [rsp+0x90], xmm10
00007e97133dd295  vmovaps [rsp+0xA0], xmm11
00007e97133dd29e  vmovaps [rsp+0xB0], xmm12
00007e97133dd2a7  vmovaps [rsp+0xC0], xmm13
00007e97133dd2b0  vmovaps [rsp+0xD0], xmm14
00007e97133dd2b9  vmovaps [rsp+0xE0], xmm15
00007e97133dd2c2  sub rsp, 0x30
00007e97133dd2c6  movaps [rsp], xmm4
00007e97133dd2ca  movaps [rsp+0x10], xmm9
00007e97133dd2d0  movaps [rsp+0x20], xmm8
00007e97133dd2d6  lea rdi, [rsp]
00007e97133dd2da  mov esi, 0x00
00007e97133dd2df  mov rax, 0x58D8AED5F530
00007e97133dd2e9  call rax
00007e97133dd2eb  movaps xmm4, [rsp]
00007e97133dd2ef  add rsp, 0x30
00007e97133dd2f3  vmovaps xmm0, [rsp]
00007e97133dd2f8  vmovaps xmm1, [rsp+0x10]
00007e97133dd2fe  vmovaps xmm2, [rsp+0x20]
00007e97133dd304  vmovaps xmm3, [rsp+0x30]
00007e97133dd30a  vmovaps xmm5, [rsp+0x40]
00007e97133dd310  vmovaps xmm6, [rsp+0x50]
00007e97133dd316  vmovaps xmm7, [rsp+0x60]
00007e97133dd31c  vmovaps xmm8, [rsp+0x70]
00007e97133dd322  vmovaps xmm9, [rsp+0x80]
00007e97133dd32b  vmovaps xmm10, [rsp+0x90]
00007e97133dd334  vmovaps xmm11, [rsp+0xA0]
00007e97133dd33d  vmovaps xmm12, [rsp+0xB0]
00007e97133dd346  vmovaps xmm13, [rsp+0xC0]
00007e97133dd34f  vmovaps xmm14, [rsp+0xD0]
00007e97133dd358  vmovaps xmm15, [rsp+0xE0]
00007e97133dd361  add rsp, 0xF0
00007e97133dd368  pop r11
00007e97133dd36a  pop r10
00007e97133dd36c  pop r9
00007e97133dd36e  pop r8
00007e97133dd370  pop rsi
00007e97133dd371  pop rdi
00007e97133dd372  pop rdx
00007e97133dd373  pop rcx
00007e97133dd374  pop rax
00007e97133dd375  add rsp, 0x08
00007e97133dd379  jmp 0x00007E97133DBC94
00007e97133dd37e  sub rsp, 0x08
00007e97133dd382  push rax
00007e97133dd383  push rcx
00007e97133dd384  push rdx
00007e97133dd385  push rdi
00007e97133dd386  push rsi
00007e97133dd387  push r8
00007e97133dd389  push r9
00007e97133dd38b  push r10
00007e97133dd38d  push r11
00007e97133dd38f  sub rsp, 0xF0
00007e97133dd396  vmovaps [rsp], xmm0
00007e97133dd39b  vmovaps [rsp+0x10], xmm1
00007e97133dd3a1  vmovaps [rsp+0x20], xmm2
00007e97133dd3a7  vmovaps [rsp+0x30], xmm3
00007e97133dd3ad  vmovaps [rsp+0x40], xmm4
00007e97133dd3b3  vmovaps [rsp+0x50], xmm5
00007e97133dd3b9  vmovaps [rsp+0x60], xmm6
00007e97133dd3bf  vmovaps [rsp+0x70], xmm7
00007e97133dd3c5  vmovaps [rsp+0x80], xmm8
00007e97133dd3ce  vmovaps [rsp+0x90], xmm10
00007e97133dd3d7  vmovaps [rsp+0xA0], xmm11
00007e97133dd3e0  vmovaps [rsp+0xB0], xmm12
00007e97133dd3e9  vmovaps [rsp+0xC0], xmm13
00007e97133dd3f2  vmovaps [rsp+0xD0], xmm14
00007e97133dd3fb  vmovaps [rsp+0xE0], xmm15
00007e97133dd404  sub rsp, 0x30
00007e97133dd408  movaps [rsp], xmm9
00007e97133dd40d  movaps [rsp+0x10], xmm10
00007e97133dd413  movaps [rsp+0x20], xmm8
00007e97133dd419  lea rdi, [rsp]
00007e97133dd41d  mov esi, 0x00
00007e97133dd422  mov rax, 0x58D8AED5F530
00007e97133dd42c  call rax
00007e97133dd42e  movaps xmm9, [rsp]
00007e97133dd433  add rsp, 0x30
00007e97133dd437  vmovaps xmm0, [rsp]
00007e97133dd43c  vmovaps xmm1, [rsp+0x10]
00007e97133dd442  vmovaps xmm2, [rsp+0x20]
00007e97133dd448  vmovaps xmm3, [rsp+0x30]
00007e97133dd44e  vmovaps xmm4, [rsp+0x40]
00007e97133dd454  vmovaps xmm5, [rsp+0x50]
00007e97133dd45a  vmovaps xmm6, [rsp+0x60]
00007e97133dd460  vmovaps xmm7, [rsp+0x70]
00007e97133dd466  vmovaps xmm8, [rsp+0x80]
00007e97133dd46f  vmovaps xmm10, [rsp+0x90]
00007e97133dd478  vmovaps xmm11, [rsp+0xA0]
00007e97133dd481  vmovaps xmm12, [rsp+0xB0]
00007e97133dd48a  vmovaps xmm13, [rsp+0xC0]
00007e97133dd493  vmovaps xmm14, [rsp+0xD0]
00007e97133dd49c  vmovaps xmm15, [rsp+0xE0]
00007e97133dd4a5  add rsp, 0xF0
00007e97133dd4ac  pop r11
00007e97133dd4ae  pop r10
00007e97133dd4b0  pop r9
00007e97133dd4b2  pop r8
00007e97133dd4b4  pop rsi
00007e97133dd4b5  pop rdi
00007e97133dd4b6  pop rdx
00007e97133dd4b7  pop rcx
00007e97133dd4b8  pop rax
00007e97133dd4b9  add rsp, 0x08
00007e97133dd4bd  jmp 0x00007E97133DBCAE
00007e97133dd4c2  call 0x00007E97132B52F0
00007e97133dd4c7  jmp 0x00007E97133DBDC8
00007e97133dd4cc  call 0x00007E97132B52F0
00007e97133dd4d1  jmp 0x00007E97133DBDDE
00007e97133dd4d6  sub rsp, 0x08
00007e97133dd4da  push rax
00007e97133dd4db  push rcx
00007e97133dd4dc  push rdx
00007e97133dd4dd  push rdi
00007e97133dd4de  push rsi
00007e97133dd4df  push r8
00007e97133dd4e1  push r9
00007e97133dd4e3  push r10
00007e97133dd4e5  push r11
00007e97133dd4e7  sub rsp, 0xF0
00007e97133dd4ee  vmovaps [rsp], xmm0
00007e97133dd4f3  vmovaps [rsp+0x10], xmm2
00007e97133dd4f9  vmovaps [rsp+0x20], xmm3
00007e97133dd4ff  vmovaps [rsp+0x30], xmm4
00007e97133dd505  vmovaps [rsp+0x40], xmm5
00007e97133dd50b  vmovaps [rsp+0x50], xmm6
00007e97133dd511  vmovaps [rsp+0x60], xmm7
00007e97133dd517  vmovaps [rsp+0x70], xmm8
00007e97133dd51d  vmovaps [rsp+0x80], xmm9
00007e97133dd526  vmovaps [rsp+0x90], xmm10
00007e97133dd52f  vmovaps [rsp+0xA0], xmm11
00007e97133dd538  vmovaps [rsp+0xB0], xmm12
00007e97133dd541  vmovaps [rsp+0xC0], xmm13
00007e97133dd54a  vmovaps [rsp+0xD0], xmm14
00007e97133dd553  vmovaps [rsp+0xE0], xmm15
00007e97133dd55c  sub rsp, 0x30
00007e97133dd560  movaps [rsp], xmm1
00007e97133dd564  movaps [rsp+0x10], xmm6
00007e97133dd569  movaps [rsp+0x20], xmm15
00007e97133dd56f  lea rdi, [rsp]
00007e97133dd573  mov esi, 0x00
00007e97133dd578  mov rax, 0x58D8AED5F530
00007e97133dd582  call rax
00007e97133dd584  movaps xmm1, [rsp]
00007e97133dd588  add rsp, 0x30
00007e97133dd58c  vmovaps xmm0, [rsp]
00007e97133dd591  vmovaps xmm2, [rsp+0x10]
00007e97133dd597  vmovaps xmm3, [rsp+0x20]
00007e97133dd59d  vmovaps xmm4, [rsp+0x30]
00007e97133dd5a3  vmovaps xmm5, [rsp+0x40]
00007e97133dd5a9  vmovaps xmm6, [rsp+0x50]
00007e97133dd5af  vmovaps xmm7, [rsp+0x60]
00007e97133dd5b5  vmovaps xmm8, [rsp+0x70]
00007e97133dd5bb  vmovaps xmm9, [rsp+0x80]
00007e97133dd5c4  vmovaps xmm10, [rsp+0x90]
00007e97133dd5cd  vmovaps xmm11, [rsp+0xA0]
00007e97133dd5d6  vmovaps xmm12, [rsp+0xB0]
00007e97133dd5df  vmovaps xmm13, [rsp+0xC0]
00007e97133dd5e8  vmovaps xmm14, [rsp+0xD0]
00007e97133dd5f1  vmovaps xmm15, [rsp+0xE0]
00007e97133dd5fa  add rsp, 0xF0
00007e97133dd601  pop r11
00007e97133dd603  pop r10
00007e97133dd605  pop r9
00007e97133dd607  pop r8
00007e97133dd609  pop rsi
00007e97133dd60a  pop rdi
00007e97133dd60b  pop rdx
00007e97133dd60c  pop rcx
00007e97133dd60d  pop rax
00007e97133dd60e  add rsp, 0x08
00007e97133dd612  jmp 0x00007E97133DBE1B
00007e97133dd617  call 0x00007E97132C4620
00007e97133dd61c  jmp 0x00007E97133DBE28
00007e97133dd621  sub rsp, 0x08
00007e97133dd625  push rax
00007e97133dd626  push rcx
00007e97133dd627  push rdx
00007e97133dd628  push rdi
00007e97133dd629  push rsi
00007e97133dd62a  push r8
00007e97133dd62c  push r9
00007e97133dd62e  push r10
00007e97133dd630  push r11
00007e97133dd632  sub rsp, 0xF0
00007e97133dd639  vmovaps [rsp], xmm0
00007e97133dd63e  vmovaps [rsp+0x10], xmm1
00007e97133dd644  vmovaps [rsp+0x20], xmm2
00007e97133dd64a  vmovaps [rsp+0x30], xmm3
00007e97133dd650  vmovaps [rsp+0x40], xmm4
00007e97133dd656  vmovaps [rsp+0x50], xmm5
00007e97133dd65c  vmovaps [rsp+0x60], xmm6
00007e97133dd662  vmovaps [rsp+0x70], xmm7
00007e97133dd668  vmovaps [rsp+0x80], xmm8
00007e97133dd671  vmovaps [rsp+0x90], xmm9
00007e97133dd67a  vmovaps [rsp+0xA0], xmm10
00007e97133dd683  vmovaps [rsp+0xB0], xmm11
00007e97133dd68c  vmovaps [rsp+0xC0], xmm12
00007e97133dd695  vmovaps [rsp+0xD0], xmm13
00007e97133dd69e  vmovaps [rsp+0xE0], xmm15
00007e97133dd6a7  sub rsp, 0x30
00007e97133dd6ab  movaps [rsp], xmm14
00007e97133dd6b0  movaps [rsp+0x10], xmm4
00007e97133dd6b5  movaps [rsp+0x20], xmm3
00007e97133dd6ba  lea rdi, [rsp]
00007e97133dd6be  mov esi, 0x00
00007e97133dd6c3  mov rax, 0x58D8AED5F530
00007e97133dd6cd  call rax
00007e97133dd6cf  movaps xmm14, [rsp]
00007e97133dd6d4  add rsp, 0x30
00007e97133dd6d8  vmovaps xmm0, [rsp]
00007e97133dd6dd  vmovaps xmm1, [rsp+0x10]
00007e97133dd6e3  vmovaps xmm2, [rsp+0x20]
00007e97133dd6e9  vmovaps xmm3, [rsp+0x30]
00007e97133dd6ef  vmovaps xmm4, [rsp+0x40]
00007e97133dd6f5  vmovaps xmm5, [rsp+0x50]
00007e97133dd6fb  vmovaps xmm6, [rsp+0x60]
00007e97133dd701  vmovaps xmm7, [rsp+0x70]
00007e97133dd707  vmovaps xmm8, [rsp+0x80]
00007e97133dd710  vmovaps xmm9, [rsp+0x90]
00007e97133dd719  vmovaps xmm10, [rsp+0xA0]
00007e97133dd722  vmovaps xmm11, [rsp+0xB0]
00007e97133dd72b  vmovaps xmm12, [rsp+0xC0]
00007e97133dd734  vmovaps xmm13, [rsp+0xD0]
00007e97133dd73d  vmovaps xmm15, [rsp+0xE0]
00007e97133dd746  add rsp, 0xF0
00007e97133dd74d  pop r11
00007e97133dd74f  pop r10
00007e97133dd751  pop r9
00007e97133dd753  pop r8
00007e97133dd755  pop rsi
00007e97133dd756  pop rdi
00007e97133dd757  pop rdx
00007e97133dd758  pop rcx
00007e97133dd759  pop rax
00007e97133dd75a  add rsp, 0x08
00007e97133dd75e  jmp 0x00007E97133DBE42
00007e97133dd763  sub rsp, 0x08
00007e97133dd767  push rax
00007e97133dd768  push rcx
00007e97133dd769  push rdx
00007e97133dd76a  push rdi
00007e97133dd76b  push rsi
00007e97133dd76c  push r8
00007e97133dd76e  push r9
00007e97133dd770  push r10
00007e97133dd772  push r11
00007e97133dd774  sub rsp, 0xF0
00007e97133dd77b  vmovaps [rsp], xmm0
00007e97133dd780  vmovaps [rsp+0x10], xmm1
00007e97133dd786  vmovaps [rsp+0x20], xmm2
00007e97133dd78c  vmovaps [rsp+0x30], xmm3
00007e97133dd792  vmovaps [rsp+0x40], xmm4
00007e97133dd798  vmovaps [rsp+0x50], xmm5
00007e97133dd79e  vmovaps [rsp+0x60], xmm7
00007e97133dd7a4  vmovaps [rsp+0x70], xmm8
00007e97133dd7aa  vmovaps [rsp+0x80], xmm9
00007e97133dd7b3  vmovaps [rsp+0x90], xmm10
00007e97133dd7bc  vmovaps [rsp+0xA0], xmm11
00007e97133dd7c5  vmovaps [rsp+0xB0], xmm12
00007e97133dd7ce  vmovaps [rsp+0xC0], xmm13
00007e97133dd7d7  vmovaps [rsp+0xD0], xmm14
00007e97133dd7e0  vmovaps [rsp+0xE0], xmm15
00007e97133dd7e9  sub rsp, 0x30
00007e97133dd7ed  movaps [rsp], xmm6
00007e97133dd7f1  movaps [rsp+0x10], xmm9
00007e97133dd7f7  movaps [rsp+0x20], xmm7
00007e97133dd7fc  lea rdi, [rsp]
00007e97133dd800  mov esi, 0x00
00007e97133dd805  mov rax, 0x58D8AED5F530
00007e97133dd80f  call rax
00007e97133dd811  movaps xmm6, [rsp]
00007e97133dd815  add rsp, 0x30
00007e97133dd819  vmovaps xmm0, [rsp]
00007e97133dd81e  vmovaps xmm1, [rsp+0x10]
00007e97133dd824  vmovaps xmm2, [rsp+0x20]
00007e97133dd82a  vmovaps xmm3, [rsp+0x30]
00007e97133dd830  vmovaps xmm4, [rsp+0x40]
00007e97133dd836  vmovaps xmm5, [rsp+0x50]
00007e97133dd83c  vmovaps xmm7, [rsp+0x60]
00007e97133dd842  vmovaps xmm8, [rsp+0x70]
00007e97133dd848  vmovaps xmm9, [rsp+0x80]
00007e97133dd851  vmovaps xmm10, [rsp+0x90]
00007e97133dd85a  vmovaps xmm11, [rsp+0xA0]
00007e97133dd863  vmovaps xmm12, [rsp+0xB0]
00007e97133dd86c  vmovaps xmm13, [rsp+0xC0]
00007e97133dd875  vmovaps xmm14, [rsp+0xD0]
00007e97133dd87e  vmovaps xmm15, [rsp+0xE0]
00007e97133dd887  add rsp, 0xF0
00007e97133dd88e  pop r11
00007e97133dd890  pop r10
00007e97133dd892  pop r9
00007e97133dd894  pop r8
00007e97133dd896  pop rsi
00007e97133dd897  pop rdi
00007e97133dd898  pop rdx
00007e97133dd899  pop rcx
00007e97133dd89a  pop rax
00007e97133dd89b  add rsp, 0x08
00007e97133dd89f  jmp 0x00007E97133DBE5A
00007e97133dd8a4  sub rsp, 0x08
00007e97133dd8a8  push rax
00007e97133dd8a9  push rcx
00007e97133dd8aa  push rdx
00007e97133dd8ab  push rdi
00007e97133dd8ac  push rsi
00007e97133dd8ad  push r8
00007e97133dd8af  push r9
00007e97133dd8b1  push r10
00007e97133dd8b3  push r11
00007e97133dd8b5  sub rsp, 0xF0
00007e97133dd8bc  vmovaps [rsp], xmm0
00007e97133dd8c1  vmovaps [rsp+0x10], xmm1
00007e97133dd8c7  vmovaps [rsp+0x20], xmm2
00007e97133dd8cd  vmovaps [rsp+0x30], xmm3
00007e97133dd8d3  vmovaps [rsp+0x40], xmm4
00007e97133dd8d9  vmovaps [rsp+0x50], xmm5
00007e97133dd8df  vmovaps [rsp+0x60], xmm6
00007e97133dd8e5  vmovaps [rsp+0x70], xmm8
00007e97133dd8eb  vmovaps [rsp+0x80], xmm9
00007e97133dd8f4  vmovaps [rsp+0x90], xmm10
00007e97133dd8fd  vmovaps [rsp+0xA0], xmm11
00007e97133dd906  vmovaps [rsp+0xB0], xmm12
00007e97133dd90f  vmovaps [rsp+0xC0], xmm13
00007e97133dd918  vmovaps [rsp+0xD0], xmm14
00007e97133dd921  vmovaps [rsp+0xE0], xmm15
00007e97133dd92a  sub rsp, 0x30
00007e97133dd92e  movaps [rsp], xmm7
00007e97133dd932  movaps [rsp+0x10], xmm4
00007e97133dd937  movaps [rsp+0x20], xmm9
00007e97133dd93d  lea rdi, [rsp]
00007e97133dd941  mov esi, 0x00
00007e97133dd946  mov rax, 0x58D8AED5F530
00007e97133dd950  call rax
00007e97133dd952  movaps xmm7, [rsp]
00007e97133dd956  add rsp, 0x30
00007e97133dd95a  vmovaps xmm0, [rsp]
00007e97133dd95f  vmovaps xmm1, [rsp+0x10]
00007e97133dd965  vmovaps xmm2, [rsp+0x20]
00007e97133dd96b  vmovaps xmm3, [rsp+0x30]
00007e97133dd971  vmovaps xmm4, [rsp+0x40]
00007e97133dd977  vmovaps xmm5, [rsp+0x50]
00007e97133dd97d  vmovaps xmm6, [rsp+0x60]
00007e97133dd983  vmovaps xmm8, [rsp+0x70]
00007e97133dd989  vmovaps xmm9, [rsp+0x80]
00007e97133dd992  vmovaps xmm10, [rsp+0x90]
00007e97133dd99b  vmovaps xmm11, [rsp+0xA0]
00007e97133dd9a4  vmovaps xmm12, [rsp+0xB0]
00007e97133dd9ad  vmovaps xmm13, [rsp+0xC0]
00007e97133dd9b6  vmovaps xmm14, [rsp+0xD0]
00007e97133dd9bf  vmovaps xmm15, [rsp+0xE0]
00007e97133dd9c8  add rsp, 0xF0
00007e97133dd9cf  pop r11
00007e97133dd9d1  pop r10
00007e97133dd9d3  pop r9
00007e97133dd9d5  pop r8
00007e97133dd9d7  pop rsi
00007e97133dd9d8  pop rdi
00007e97133dd9d9  pop rdx
00007e97133dd9da  pop rcx
00007e97133dd9db  pop rax
00007e97133dd9dc  add rsp, 0x08
00007e97133dd9e0  jmp 0x00007E97133DBE87
00007e97133dd9e5  sub rsp, 0x08
00007e97133dd9e9  push rax
00007e97133dd9ea  push rcx
00007e97133dd9eb  push rdx
00007e97133dd9ec  push rdi
00007e97133dd9ed  push rsi
00007e97133dd9ee  push r8
00007e97133dd9f0  push r9
00007e97133dd9f2  push r10
00007e97133dd9f4  push r11
00007e97133dd9f6  sub rsp, 0xF0
00007e97133dd9fd  vmovaps [rsp], xmm0
00007e97133dda02  vmovaps [rsp+0x10], xmm1
00007e97133dda08  vmovaps [rsp+0x20], xmm2
00007e97133dda0e  vmovaps [rsp+0x30], xmm3
00007e97133dda14  vmovaps [rsp+0x40], xmm5
00007e97133dda1a  vmovaps [rsp+0x50], xmm6
00007e97133dda20  vmovaps [rsp+0x60], xmm7
00007e97133dda26  vmovaps [rsp+0x70], xmm8
00007e97133dda2c  vmovaps [rsp+0x80], xmm9
00007e97133dda35  vmovaps [rsp+0x90], xmm10
00007e97133dda3e  vmovaps [rsp+0xA0], xmm11
00007e97133dda47  vmovaps [rsp+0xB0], xmm12
00007e97133dda50  vmovaps [rsp+0xC0], xmm13
00007e97133dda59  vmovaps [rsp+0xD0], xmm14
00007e97133dda62  vmovaps [rsp+0xE0], xmm15
00007e97133dda6b  sub rsp, 0x30
00007e97133dda6f  movaps [rsp], xmm4
00007e97133dda73  movaps [rsp+0x10], xmm15
00007e97133dda79  movaps [rsp+0x20], xmm9
00007e97133dda7f  lea rdi, [rsp]
00007e97133dda83  mov esi, 0x00
00007e97133dda88  mov rax, 0x58D8AED5F530
00007e97133dda92  call rax
00007e97133dda94  movaps xmm4, [rsp]
00007e97133dda98  add rsp, 0x30
00007e97133dda9c  vmovaps xmm0, [rsp]
00007e97133ddaa1  vmovaps xmm1, [rsp+0x10]
00007e97133ddaa7  vmovaps xmm2, [rsp+0x20]
00007e97133ddaad  vmovaps xmm3, [rsp+0x30]
00007e97133ddab3  vmovaps xmm5, [rsp+0x40]
00007e97133ddab9  vmovaps xmm6, [rsp+0x50]
00007e97133ddabf  vmovaps xmm7, [rsp+0x60]
00007e97133ddac5  vmovaps xmm8, [rsp+0x70]
00007e97133ddacb  vmovaps xmm9, [rsp+0x80]
00007e97133ddad4  vmovaps xmm10, [rsp+0x90]
00007e97133ddadd  vmovaps xmm11, [rsp+0xA0]
00007e97133ddae6  vmovaps xmm12, [rsp+0xB0]
00007e97133ddaef  vmovaps xmm13, [rsp+0xC0]
00007e97133ddaf8  vmovaps xmm14, [rsp+0xD0]
00007e97133ddb01  vmovaps xmm15, [rsp+0xE0]
00007e97133ddb0a  add rsp, 0xF0
00007e97133ddb11  pop r11
00007e97133ddb13  pop r10
00007e97133ddb15  pop r9
00007e97133ddb17  pop r8
00007e97133ddb19  pop rsi
00007e97133ddb1a  pop rdi
00007e97133ddb1b  pop rdx
00007e97133ddb1c  pop rcx
00007e97133ddb1d  pop rax
00007e97133ddb1e  add rsp, 0x08
00007e97133ddb22  jmp 0x00007E97133DBEAC
00007e97133ddb27  call 0x00007E97132C4620
00007e97133ddb2c  jmp 0x00007E97133DBEB9
00007e97133ddb31  sub rsp, 0x08
00007e97133ddb35  push rax
00007e97133ddb36  push rcx
00007e97133ddb37  push rdx
00007e97133ddb38  push rdi
00007e97133ddb39  push rsi
00007e97133ddb3a  push r8
00007e97133ddb3c  push r9
00007e97133ddb3e  push r10
00007e97133ddb40  push r11
00007e97133ddb42  sub rsp, 0xF0
00007e97133ddb49  vmovaps [rsp], xmm0
00007e97133ddb4e  vmovaps [rsp+0x10], xmm1
00007e97133ddb54  vmovaps [rsp+0x20], xmm2
00007e97133ddb5a  vmovaps [rsp+0x30], xmm4
00007e97133ddb60  vmovaps [rsp+0x40], xmm5
00007e97133ddb66  vmovaps [rsp+0x50], xmm6
00007e97133ddb6c  vmovaps [rsp+0x60], xmm7
00007e97133ddb72  vmovaps [rsp+0x70], xmm8
00007e97133ddb78  vmovaps [rsp+0x80], xmm9
00007e97133ddb81  vmovaps [rsp+0x90], xmm10
00007e97133ddb8a  vmovaps [rsp+0xA0], xmm11
00007e97133ddb93  vmovaps [rsp+0xB0], xmm12
00007e97133ddb9c  vmovaps [rsp+0xC0], xmm13
00007e97133ddba5  vmovaps [rsp+0xD0], xmm14
00007e97133ddbae  vmovaps [rsp+0xE0], xmm15
00007e97133ddbb7  sub rsp, 0x30
00007e97133ddbbb  movaps [rsp], xmm3
00007e97133ddbbf  movaps [rsp+0x10], xmm1
00007e97133ddbc4  movaps [rsp+0x20], xmm9
00007e97133ddbca  lea rdi, [rsp]
00007e97133ddbce  mov esi, 0x00
00007e97133ddbd3  mov rax, 0x58D8AED5F530
00007e97133ddbdd  call rax
00007e97133ddbdf  movaps xmm3, [rsp]
00007e97133ddbe3  add rsp, 0x30
00007e97133ddbe7  vmovaps xmm0, [rsp]
00007e97133ddbec  vmovaps xmm1, [rsp+0x10]
00007e97133ddbf2  vmovaps xmm2, [rsp+0x20]
00007e97133ddbf8  vmovaps xmm4, [rsp+0x30]
00007e97133ddbfe  vmovaps xmm5, [rsp+0x40]
00007e97133ddc04  vmovaps xmm6, [rsp+0x50]
00007e97133ddc0a  vmovaps xmm7, [rsp+0x60]
00007e97133ddc10  vmovaps xmm8, [rsp+0x70]
00007e97133ddc16  vmovaps xmm9, [rsp+0x80]
00007e97133ddc1f  vmovaps xmm10, [rsp+0x90]
00007e97133ddc28  vmovaps xmm11, [rsp+0xA0]
00007e97133ddc31  vmovaps xmm12, [rsp+0xB0]
00007e97133ddc3a  vmovaps xmm13, [rsp+0xC0]
00007e97133ddc43  vmovaps xmm14, [rsp+0xD0]
00007e97133ddc4c  vmovaps xmm15, [rsp+0xE0]
00007e97133ddc55  add rsp, 0xF0
00007e97133ddc5c  pop r11
00007e97133ddc5e  pop r10
00007e97133ddc60  pop r9
00007e97133ddc62  pop r8
00007e97133ddc64  pop rsi
00007e97133ddc65  pop rdi
00007e97133ddc66  pop rdx
00007e97133ddc67  pop rcx
00007e97133ddc68  pop rax
00007e97133ddc69  add rsp, 0x08
00007e97133ddc6d  jmp 0x00007E97133DBEF6
00007e97133ddc72  sub rsp, 0x08
00007e97133ddc76  push rax
00007e97133ddc77  push rcx
00007e97133ddc78  push rdx
00007e97133ddc79  push rdi
00007e97133ddc7a  push rsi
00007e97133ddc7b  push r8
00007e97133ddc7d  push r9
00007e97133ddc7f  push r10
00007e97133ddc81  push r11
00007e97133ddc83  sub rsp, 0xF0
00007e97133ddc8a  vmovaps [rsp], xmm0
00007e97133ddc8f  vmovaps [rsp+0x10], xmm2
00007e97133ddc95  vmovaps [rsp+0x20], xmm3
00007e97133ddc9b  vmovaps [rsp+0x30], xmm4
00007e97133ddca1  vmovaps [rsp+0x40], xmm5
00007e97133ddca7  vmovaps [rsp+0x50], xmm6
00007e97133ddcad  vmovaps [rsp+0x60], xmm7
00007e97133ddcb3  vmovaps [rsp+0x70], xmm8
00007e97133ddcb9  vmovaps [rsp+0x80], xmm9
00007e97133ddcc2  vmovaps [rsp+0x90], xmm10
00007e97133ddccb  vmovaps [rsp+0xA0], xmm11
00007e97133ddcd4  vmovaps [rsp+0xB0], xmm12
00007e97133ddcdd  vmovaps [rsp+0xC0], xmm13
00007e97133ddce6  vmovaps [rsp+0xD0], xmm14
00007e97133ddcef  vmovaps [rsp+0xE0], xmm15
00007e97133ddcf8  sub rsp, 0x30
00007e97133ddcfc  movaps [rsp], xmm1
00007e97133ddd00  movaps [rsp+0x10], xmm15
00007e97133ddd06  movaps [rsp+0x20], xmm9
00007e97133ddd0c  lea rdi, [rsp]
00007e97133ddd10  mov esi, 0x00
00007e97133ddd15  mov rax, 0x58D8AED5F530
00007e97133ddd1f  call rax
00007e97133ddd21  movaps xmm1, [rsp]
00007e97133ddd25  add rsp, 0x30
00007e97133ddd29  vmovaps xmm0, [rsp]
00007e97133ddd2e  vmovaps xmm2, [rsp+0x10]
00007e97133ddd34  vmovaps xmm3, [rsp+0x20]
00007e97133ddd3a  vmovaps xmm4, [rsp+0x30]
00007e97133ddd40  vmovaps xmm5, [rsp+0x40]
00007e97133ddd46  vmovaps xmm6, [rsp+0x50]
00007e97133ddd4c  vmovaps xmm7, [rsp+0x60]
00007e97133ddd52  vmovaps xmm8, [rsp+0x70]
00007e97133ddd58  vmovaps xmm9, [rsp+0x80]
00007e97133ddd61  vmovaps xmm10, [rsp+0x90]
00007e97133ddd6a  vmovaps xmm11, [rsp+0xA0]
00007e97133ddd73  vmovaps xmm12, [rsp+0xB0]
00007e97133ddd7c  vmovaps xmm13, [rsp+0xC0]
00007e97133ddd85  vmovaps xmm14, [rsp+0xD0]
00007e97133ddd8e  vmovaps xmm15, [rsp+0xE0]
00007e97133ddd97  add rsp, 0xF0
00007e97133ddd9e  pop r11
00007e97133ddda0  pop r10
00007e97133ddda2  pop r9
00007e97133ddda4  pop r8
00007e97133ddda6  pop rsi
00007e97133ddda7  pop rdi
00007e97133ddda8  pop rdx
00007e97133ddda9  pop rcx
00007e97133dddaa  pop rax
00007e97133dddab  add rsp, 0x08
00007e97133dddaf  jmp 0x00007E97133DBF7E
00007e97133dddb4  call 0x00007E97132C4620
00007e97133dddb9  jmp 0x00007E97133DBF8B
00007e97133dddbe  sub rsp, 0x08
00007e97133dddc2  push rax
00007e97133dddc3  push rcx
00007e97133dddc4  push rdx
00007e97133dddc5  push rdi
00007e97133dddc6  push rsi
00007e97133dddc7  push r8
00007e97133dddc9  push r9
00007e97133dddcb  push r10
00007e97133dddcd  push r11
00007e97133dddcf  sub rsp, 0xF0
00007e97133dddd6  vmovaps [rsp], xmm0
00007e97133ddddb  vmovaps [rsp+0x10], xmm2
00007e97133ddde1  vmovaps [rsp+0x20], xmm3
00007e97133ddde7  vmovaps [rsp+0x30], xmm4
00007e97133ddded  vmovaps [rsp+0x40], xmm5
00007e97133dddf3  vmovaps [rsp+0x50], xmm6
00007e97133dddf9  vmovaps [rsp+0x60], xmm7
00007e97133dddff  vmovaps [rsp+0x70], xmm8
00007e97133dde05  vmovaps [rsp+0x80], xmm9
00007e97133dde0e  vmovaps [rsp+0x90], xmm10
00007e97133dde17  vmovaps [rsp+0xA0], xmm11
00007e97133dde20  vmovaps [rsp+0xB0], xmm12
00007e97133dde29  vmovaps [rsp+0xC0], xmm13
00007e97133dde32  vmovaps [rsp+0xD0], xmm14
00007e97133dde3b  vmovaps [rsp+0xE0], xmm15
00007e97133dde44  sub rsp, 0x30
00007e97133dde48  movaps [rsp], xmm1
00007e97133dde4c  movaps [rsp+0x10], xmm5
00007e97133dde51  movaps [rsp+0x20], xmm7
00007e97133dde56  lea rdi, [rsp]
00007e97133dde5a  mov esi, 0x00
00007e97133dde5f  mov rax, 0x58D8AED5F530
00007e97133dde69  call rax
00007e97133dde6b  movaps xmm1, [rsp]
00007e97133dde6f  add rsp, 0x30
00007e97133dde73  vmovaps xmm0, [rsp]
00007e97133dde78  vmovaps xmm2, [rsp+0x10]
00007e97133dde7e  vmovaps xmm3, [rsp+0x20]
00007e97133dde84  vmovaps xmm4, [rsp+0x30]
00007e97133dde8a  vmovaps xmm5, [rsp+0x40]
00007e97133dde90  vmovaps xmm6, [rsp+0x50]
00007e97133dde96  vmovaps xmm7, [rsp+0x60]
00007e97133dde9c  vmovaps xmm8, [rsp+0x70]
00007e97133ddea2  vmovaps xmm9, [rsp+0x80]
00007e97133ddeab  vmovaps xmm10, [rsp+0x90]
00007e97133ddeb4  vmovaps xmm11, [rsp+0xA0]
00007e97133ddebd  vmovaps xmm12, [rsp+0xB0]
00007e97133ddec6  vmovaps xmm13, [rsp+0xC0]
00007e97133ddecf  vmovaps xmm14, [rsp+0xD0]
00007e97133dded8  vmovaps xmm15, [rsp+0xE0]
00007e97133ddee1  add rsp, 0xF0
00007e97133ddee8  pop r11
00007e97133ddeea  pop r10
00007e97133ddeec  pop r9
00007e97133ddeee  pop r8
00007e97133ddef0  pop rsi
00007e97133ddef1  pop rdi
00007e97133ddef2  pop rdx
00007e97133ddef3  pop rcx
00007e97133ddef4  pop rax
00007e97133ddef5  add rsp, 0x08
00007e97133ddef9  jmp 0x00007E97133DC030
00007e97133ddefe  sub rsp, 0x08
00007e97133ddf02  push rax
00007e97133ddf03  push rcx
00007e97133ddf04  push rdx
00007e97133ddf05  push rdi
00007e97133ddf06  push rsi
00007e97133ddf07  push r8
00007e97133ddf09  push r9
00007e97133ddf0b  push r10
00007e97133ddf0d  push r11
00007e97133ddf0f  sub rsp, 0xF0
00007e97133ddf16  vmovaps [rsp], xmm0
00007e97133ddf1b  vmovaps [rsp+0x10], xmm1
00007e97133ddf21  vmovaps [rsp+0x20], xmm2
00007e97133ddf27  vmovaps [rsp+0x30], xmm3
00007e97133ddf2d  vmovaps [rsp+0x40], xmm4
00007e97133ddf33  vmovaps [rsp+0x50], xmm5
00007e97133ddf39  vmovaps [rsp+0x60], xmm6
00007e97133ddf3f  vmovaps [rsp+0x70], xmm8
00007e97133ddf45  vmovaps [rsp+0x80], xmm9
00007e97133ddf4e  vmovaps [rsp+0x90], xmm10
00007e97133ddf57  vmovaps [rsp+0xA0], xmm11
00007e97133ddf60  vmovaps [rsp+0xB0], xmm12
00007e97133ddf69  vmovaps [rsp+0xC0], xmm13
00007e97133ddf72  vmovaps [rsp+0xD0], xmm14
00007e97133ddf7b  vmovaps [rsp+0xE0], xmm15
00007e97133ddf84  sub rsp, 0x30
00007e97133ddf88  movaps [rsp], xmm7
00007e97133ddf8c  movaps [rsp+0x10], xmm5
00007e97133ddf91  movaps [rsp+0x20], xmm15
00007e97133ddf97  lea rdi, [rsp]
00007e97133ddf9b  mov esi, 0x00
00007e97133ddfa0  mov rax, 0x58D8AED5F530
00007e97133ddfaa  call rax
00007e97133ddfac  movaps xmm7, [rsp]
00007e97133ddfb0  add rsp, 0x30
00007e97133ddfb4  vmovaps xmm0, [rsp]
00007e97133ddfb9  vmovaps xmm1, [rsp+0x10]
00007e97133ddfbf  vmovaps xmm2, [rsp+0x20]
00007e97133ddfc5  vmovaps xmm3, [rsp+0x30]
00007e97133ddfcb  vmovaps xmm4, [rsp+0x40]
00007e97133ddfd1  vmovaps xmm5, [rsp+0x50]
00007e97133ddfd7  vmovaps xmm6, [rsp+0x60]
00007e97133ddfdd  vmovaps xmm8, [rsp+0x70]
00007e97133ddfe3  vmovaps xmm9, [rsp+0x80]
00007e97133ddfec  vmovaps xmm10, [rsp+0x90]
00007e97133ddff5  vmovaps xmm11, [rsp+0xA0]
00007e97133ddffe  vmovaps xmm12, [rsp+0xB0]
00007e97133de007  vmovaps xmm13, [rsp+0xC0]
00007e97133de010  vmovaps xmm14, [rsp+0xD0]
00007e97133de019  vmovaps xmm15, [rsp+0xE0]
00007e97133de022  add rsp, 0xF0
00007e97133de029  pop r11
00007e97133de02b  pop r10
00007e97133de02d  pop r9
00007e97133de02f  pop r8
00007e97133de031  pop rsi
00007e97133de032  pop rdi
00007e97133de033  pop rdx
00007e97133de034  pop rcx
00007e97133de035  pop rax
00007e97133de036  add rsp, 0x08
00007e97133de03a  jmp 0x00007E97133DC066
00007e97133de03f  call 0x00007E97132B52F0
00007e97133de044  jmp 0x00007E97133DC073
00007e97133de049  sub rsp, 0x08
00007e97133de04d  push rax
00007e97133de04e  push rcx
00007e97133de04f  push rdx
00007e97133de050  push rdi
00007e97133de051  push rsi
00007e97133de052  push r8
00007e97133de054  push r9
00007e97133de056  push r10
00007e97133de058  push r11
00007e97133de05a  sub rsp, 0xF0
00007e97133de061  vmovaps [rsp], xmm0
00007e97133de066  vmovaps [rsp+0x10], xmm1
00007e97133de06c  vmovaps [rsp+0x20], xmm2
00007e97133de072  vmovaps [rsp+0x30], xmm3
00007e97133de078  vmovaps [rsp+0x40], xmm4
00007e97133de07e  vmovaps [rsp+0x50], xmm5
00007e97133de084  vmovaps [rsp+0x60], xmm6
00007e97133de08a  vmovaps [rsp+0x70], xmm7
00007e97133de090  vmovaps [rsp+0x80], xmm8
00007e97133de099  vmovaps [rsp+0x90], xmm9
00007e97133de0a2  vmovaps [rsp+0xA0], xmm10
00007e97133de0ab  vmovaps [rsp+0xB0], xmm11
00007e97133de0b4  vmovaps [rsp+0xC0], xmm12
00007e97133de0bd  vmovaps [rsp+0xD0], xmm13
00007e97133de0c6  vmovaps [rsp+0xE0], xmm14
00007e97133de0cf  sub rsp, 0x30
00007e97133de0d3  movaps [rsp], xmm15
00007e97133de0d8  movaps [rsp+0x10], xmm5
00007e97133de0dd  movaps [rsp+0x20], xmm3
00007e97133de0e2  lea rdi, [rsp]
00007e97133de0e6  mov esi, 0x00
00007e97133de0eb  mov rax, 0x58D8AED5F530
00007e97133de0f5  call rax
00007e97133de0f7  movaps xmm15, [rsp]
00007e97133de0fc  add rsp, 0x30
00007e97133de100  vmovaps xmm0, [rsp]
00007e97133de105  vmovaps xmm1, [rsp+0x10]
00007e97133de10b  vmovaps xmm2, [rsp+0x20]
00007e97133de111  vmovaps xmm3, [rsp+0x30]
00007e97133de117  vmovaps xmm4, [rsp+0x40]
00007e97133de11d  vmovaps xmm5, [rsp+0x50]
00007e97133de123  vmovaps xmm6, [rsp+0x60]
00007e97133de129  vmovaps xmm7, [rsp+0x70]
00007e97133de12f  vmovaps xmm8, [rsp+0x80]
00007e97133de138  vmovaps xmm9, [rsp+0x90]
00007e97133de141  vmovaps xmm10, [rsp+0xA0]
00007e97133de14a  vmovaps xmm11, [rsp+0xB0]
00007e97133de153  vmovaps xmm12, [rsp+0xC0]
00007e97133de15c  vmovaps xmm13, [rsp+0xD0]
00007e97133de165  vmovaps xmm14, [rsp+0xE0]
00007e97133de16e  add rsp, 0xF0
00007e97133de175  pop r11
00007e97133de177  pop r10
00007e97133de179  pop r9
00007e97133de17b  pop r8
00007e97133de17d  pop rsi
00007e97133de17e  pop rdi
00007e97133de17f  pop rdx
00007e97133de180  pop rcx
00007e97133de181  pop rax
00007e97133de182  add rsp, 0x08
00007e97133de186  jmp 0x00007E97133DC099
00007e97133de18b  sub rsp, 0x08
00007e97133de18f  push rax
00007e97133de190  push rcx
00007e97133de191  push rdx
00007e97133de192  push rdi
00007e97133de193  push rsi
00007e97133de194  push r8
00007e97133de196  push r9
00007e97133de198  push r10
00007e97133de19a  push r11
00007e97133de19c  sub rsp, 0xF0
00007e97133de1a3  vmovaps [rsp], xmm0
00007e97133de1a8  vmovaps [rsp+0x10], xmm2
00007e97133de1ae  vmovaps [rsp+0x20], xmm3
00007e97133de1b4  vmovaps [rsp+0x30], xmm4
00007e97133de1ba  vmovaps [rsp+0x40], xmm5
00007e97133de1c0  vmovaps [rsp+0x50], xmm6
00007e97133de1c6  vmovaps [rsp+0x60], xmm7
00007e97133de1cc  vmovaps [rsp+0x70], xmm8
00007e97133de1d2  vmovaps [rsp+0x80], xmm9
00007e97133de1db  vmovaps [rsp+0x90], xmm10
00007e97133de1e4  vmovaps [rsp+0xA0], xmm11
00007e97133de1ed  vmovaps [rsp+0xB0], xmm12
00007e97133de1f6  vmovaps [rsp+0xC0], xmm13
00007e97133de1ff  vmovaps [rsp+0xD0], xmm14
00007e97133de208  vmovaps [rsp+0xE0], xmm15
00007e97133de211  sub rsp, 0x30
00007e97133de215  movaps [rsp], xmm1
00007e97133de219  movaps [rsp+0x10], xmm5
00007e97133de21e  movaps [rsp+0x20], xmm4
00007e97133de223  lea rdi, [rsp]
00007e97133de227  mov esi, 0x00
00007e97133de22c  mov rax, 0x58D8AED5F530
00007e97133de236  call rax
00007e97133de238  movaps xmm1, [rsp]
00007e97133de23c  add rsp, 0x30
00007e97133de240  vmovaps xmm0, [rsp]
00007e97133de245  vmovaps xmm2, [rsp+0x10]
00007e97133de24b  vmovaps xmm3, [rsp+0x20]
00007e97133de251  vmovaps xmm4, [rsp+0x30]
00007e97133de257  vmovaps xmm5, [rsp+0x40]
00007e97133de25d  vmovaps xmm6, [rsp+0x50]
00007e97133de263  vmovaps xmm7, [rsp+0x60]
00007e97133de269  vmovaps xmm8, [rsp+0x70]
00007e97133de26f  vmovaps xmm9, [rsp+0x80]
00007e97133de278  vmovaps xmm10, [rsp+0x90]
00007e97133de281  vmovaps xmm11, [rsp+0xA0]
00007e97133de28a  vmovaps xmm12, [rsp+0xB0]
00007e97133de293  vmovaps xmm13, [rsp+0xC0]
00007e97133de29c  vmovaps xmm14, [rsp+0xD0]
00007e97133de2a5  vmovaps xmm15, [rsp+0xE0]
00007e97133de2ae  add rsp, 0xF0
00007e97133de2b5  pop r11
00007e97133de2b7  pop r10
00007e97133de2b9  pop r9
00007e97133de2bb  pop r8
00007e97133de2bd  pop rsi
00007e97133de2be  pop rdi
00007e97133de2bf  pop rdx
00007e97133de2c0  pop rcx
00007e97133de2c1  pop rax
00007e97133de2c2  add rsp, 0x08
00007e97133de2c6  jmp 0x00007E97133DC0B9
00007e97133de2cb  sub rsp, 0x08
00007e97133de2cf  push rax
00007e97133de2d0  push rcx
00007e97133de2d1  push rdx
00007e97133de2d2  push rdi
00007e97133de2d3  push rsi
00007e97133de2d4  push r8
00007e97133de2d6  push r9
00007e97133de2d8  push r10
00007e97133de2da  push r11
00007e97133de2dc  sub rsp, 0xF0
00007e97133de2e3  vmovaps [rsp], xmm0
00007e97133de2e8  vmovaps [rsp+0x10], xmm1
00007e97133de2ee  vmovaps [rsp+0x20], xmm2
00007e97133de2f4  vmovaps [rsp+0x30], xmm3
00007e97133de2fa  vmovaps [rsp+0x40], xmm5
00007e97133de300  vmovaps [rsp+0x50], xmm6
00007e97133de306  vmovaps [rsp+0x60], xmm7
00007e97133de30c  vmovaps [rsp+0x70], xmm8
00007e97133de312  vmovaps [rsp+0x80], xmm9
00007e97133de31b  vmovaps [rsp+0x90], xmm10
00007e97133de324  vmovaps [rsp+0xA0], xmm11
00007e97133de32d  vmovaps [rsp+0xB0], xmm12
00007e97133de336  vmovaps [rsp+0xC0], xmm13
00007e97133de33f  vmovaps [rsp+0xD0], xmm14
00007e97133de348  vmovaps [rsp+0xE0], xmm15
00007e97133de351  sub rsp, 0x30
00007e97133de355  movaps [rsp], xmm4
00007e97133de359  movaps [rsp+0x10], xmm3
00007e97133de35e  movaps [rsp+0x20], xmm5
00007e97133de363  lea rdi, [rsp]
00007e97133de367  mov esi, 0x00
00007e97133de36c  mov rax, 0x58D8AED5F530
00007e97133de376  call rax
00007e97133de378  movaps xmm4, [rsp]
00007e97133de37c  add rsp, 0x30
00007e97133de380  vmovaps xmm0, [rsp]
00007e97133de385  vmovaps xmm1, [rsp+0x10]
00007e97133de38b  vmovaps xmm2, [rsp+0x20]
00007e97133de391  vmovaps xmm3, [rsp+0x30]
00007e97133de397  vmovaps xmm5, [rsp+0x40]
00007e97133de39d  vmovaps xmm6, [rsp+0x50]
00007e97133de3a3  vmovaps xmm7, [rsp+0x60]
00007e97133de3a9  vmovaps xmm8, [rsp+0x70]
00007e97133de3af  vmovaps xmm9, [rsp+0x80]
00007e97133de3b8  vmovaps xmm10, [rsp+0x90]
00007e97133de3c1  vmovaps xmm11, [rsp+0xA0]
00007e97133de3ca  vmovaps xmm12, [rsp+0xB0]
00007e97133de3d3  vmovaps xmm13, [rsp+0xC0]
00007e97133de3dc  vmovaps xmm14, [rsp+0xD0]
00007e97133de3e5  vmovaps xmm15, [rsp+0xE0]
00007e97133de3ee  add rsp, 0xF0
00007e97133de3f5  pop r11
00007e97133de3f7  pop r10
00007e97133de3f9  pop r9
00007e97133de3fb  pop r8
00007e97133de3fd  pop rsi
00007e97133de3fe  pop rdi
00007e97133de3ff  pop rdx
00007e97133de400  pop rcx
00007e97133de401  pop rax
00007e97133de402  add rsp, 0x08
00007e97133de406  jmp 0x00007E97133DC107
00007e97133de40b  call 0x00007E97132B52F0
00007e97133de410  jmp 0x00007E97133DC114
00007e97133de415  sub rsp, 0x08
00007e97133de419  push rax
00007e97133de41a  push rcx
00007e97133de41b  push rdx
00007e97133de41c  push rdi
00007e97133de41d  push rsi
00007e97133de41e  push r8
00007e97133de420  push r9
00007e97133de422  push r10
00007e97133de424  push r11
00007e97133de426  sub rsp, 0xF0
00007e97133de42d  vmovaps [rsp], xmm0
00007e97133de432  vmovaps [rsp+0x10], xmm1
00007e97133de438  vmovaps [rsp+0x20], xmm2
00007e97133de43e  vmovaps [rsp+0x30], xmm3
00007e97133de444  vmovaps [rsp+0x40], xmm4
00007e97133de44a  vmovaps [rsp+0x50], xmm6
00007e97133de450  vmovaps [rsp+0x60], xmm7
00007e97133de456  vmovaps [rsp+0x70], xmm8
00007e97133de45c  vmovaps [rsp+0x80], xmm9
00007e97133de465  vmovaps [rsp+0x90], xmm10
00007e97133de46e  vmovaps [rsp+0xA0], xmm11
00007e97133de477  vmovaps [rsp+0xB0], xmm12
00007e97133de480  vmovaps [rsp+0xC0], xmm13
00007e97133de489  vmovaps [rsp+0xD0], xmm14
00007e97133de492  vmovaps [rsp+0xE0], xmm15
00007e97133de49b  sub rsp, 0x30
00007e97133de49f  movaps [rsp], xmm5
00007e97133de4a3  movaps [rsp+0x10], xmm6
00007e97133de4a8  movaps [rsp+0x20], xmm3
00007e97133de4ad  lea rdi, [rsp]
00007e97133de4b1  mov esi, 0x00
00007e97133de4b6  mov rax, 0x58D8AED5F530
00007e97133de4c0  call rax
00007e97133de4c2  movaps xmm5, [rsp]
00007e97133de4c6  add rsp, 0x30
00007e97133de4ca  vmovaps xmm0, [rsp]
00007e97133de4cf  vmovaps xmm1, [rsp+0x10]
00007e97133de4d5  vmovaps xmm2, [rsp+0x20]
00007e97133de4db  vmovaps xmm3, [rsp+0x30]
00007e97133de4e1  vmovaps xmm4, [rsp+0x40]
00007e97133de4e7  vmovaps xmm6, [rsp+0x50]
00007e97133de4ed  vmovaps xmm7, [rsp+0x60]
00007e97133de4f3  vmovaps xmm8, [rsp+0x70]
00007e97133de4f9  vmovaps xmm9, [rsp+0x80]
00007e97133de502  vmovaps xmm10, [rsp+0x90]
00007e97133de50b  vmovaps xmm11, [rsp+0xA0]
00007e97133de514  vmovaps xmm12, [rsp+0xB0]
00007e97133de51d  vmovaps xmm13, [rsp+0xC0]
00007e97133de526  vmovaps xmm14, [rsp+0xD0]
00007e97133de52f  vmovaps xmm15, [rsp+0xE0]
00007e97133de538  add rsp, 0xF0
00007e97133de53f  pop r11
00007e97133de541  pop r10
00007e97133de543  pop r9
00007e97133de545  pop r8
00007e97133de547  pop rsi
00007e97133de548  pop rdi
00007e97133de549  pop rdx
00007e97133de54a  pop rcx
00007e97133de54b  pop rax
00007e97133de54c  add rsp, 0x08
00007e97133de550  jmp 0x00007E97133DC13A
00007e97133de555  sub rsp, 0x08
00007e97133de559  push rax
00007e97133de55a  push rcx
00007e97133de55b  push rdx
00007e97133de55c  push rdi
00007e97133de55d  push rsi
00007e97133de55e  push r8
00007e97133de560  push r9
00007e97133de562  push r10
00007e97133de564  push r11
00007e97133de566  sub rsp, 0xF0
00007e97133de56d  vmovaps [rsp], xmm0
00007e97133de572  vmovaps [rsp+0x10], xmm1
00007e97133de578  vmovaps [rsp+0x20], xmm2
00007e97133de57e  vmovaps [rsp+0x30], xmm3
00007e97133de584  vmovaps [rsp+0x40], xmm4
00007e97133de58a  vmovaps [rsp+0x50], xmm5
00007e97133de590  vmovaps [rsp+0x60], xmm7
00007e97133de596  vmovaps [rsp+0x70], xmm8
00007e97133de59c  vmovaps [rsp+0x80], xmm9
00007e97133de5a5  vmovaps [rsp+0x90], xmm10
00007e97133de5ae  vmovaps [rsp+0xA0], xmm11
00007e97133de5b7  vmovaps [rsp+0xB0], xmm12
00007e97133de5c0  vmovaps [rsp+0xC0], xmm13
00007e97133de5c9  vmovaps [rsp+0xD0], xmm14
00007e97133de5d2  vmovaps [rsp+0xE0], xmm15
00007e97133de5db  sub rsp, 0x30
00007e97133de5df  movaps [rsp], xmm6
00007e97133de5e3  movaps [rsp+0x10], xmm9
00007e97133de5e9  movaps [rsp+0x20], xmm1
00007e97133de5ee  lea rdi, [rsp]
00007e97133de5f2  mov esi, 0x00
00007e97133de5f7  mov rax, 0x58D8AED5F530
00007e97133de601  call rax
00007e97133de603  movaps xmm6, [rsp]
00007e97133de607  add rsp, 0x30
00007e97133de60b  vmovaps xmm0, [rsp]
00007e97133de610  vmovaps xmm1, [rsp+0x10]
00007e97133de616  vmovaps xmm2, [rsp+0x20]
00007e97133de61c  vmovaps xmm3, [rsp+0x30]
00007e97133de622  vmovaps xmm4, [rsp+0x40]
00007e97133de628  vmovaps xmm5, [rsp+0x50]
00007e97133de62e  vmovaps xmm7, [rsp+0x60]
00007e97133de634  vmovaps xmm8, [rsp+0x70]
00007e97133de63a  vmovaps xmm9, [rsp+0x80]
00007e97133de643  vmovaps xmm10, [rsp+0x90]
00007e97133de64c  vmovaps xmm11, [rsp+0xA0]
00007e97133de655  vmovaps xmm12, [rsp+0xB0]
00007e97133de65e  vmovaps xmm13, [rsp+0xC0]
00007e97133de667  vmovaps xmm14, [rsp+0xD0]
00007e97133de670  vmovaps xmm15, [rsp+0xE0]
00007e97133de679  add rsp, 0xF0
00007e97133de680  pop r11
00007e97133de682  pop r10
00007e97133de684  pop r9
00007e97133de686  pop r8
00007e97133de688  pop rsi
00007e97133de689  pop rdi
00007e97133de68a  pop rdx
00007e97133de68b  pop rcx
00007e97133de68c  pop rax
00007e97133de68d  add rsp, 0x08
00007e97133de691  jmp 0x00007E97133DC15E
00007e97133de696  sub rsp, 0x08
00007e97133de69a  push rax
00007e97133de69b  push rcx
00007e97133de69c  push rdx
00007e97133de69d  push rdi
00007e97133de69e  push rsi
00007e97133de69f  push r8
00007e97133de6a1  push r9
00007e97133de6a3  push r10
00007e97133de6a5  push r11
00007e97133de6a7  sub rsp, 0xF0
00007e97133de6ae  vmovaps [rsp], xmm0
00007e97133de6b3  vmovaps [rsp+0x10], xmm1
00007e97133de6b9  vmovaps [rsp+0x20], xmm2
00007e97133de6bf  vmovaps [rsp+0x30], xmm3
00007e97133de6c5  vmovaps [rsp+0x40], xmm4
00007e97133de6cb  vmovaps [rsp+0x50], xmm5
00007e97133de6d1  vmovaps [rsp+0x60], xmm6
00007e97133de6d7  vmovaps [rsp+0x70], xmm7
00007e97133de6dd  vmovaps [rsp+0x80], xmm8
00007e97133de6e6  vmovaps [rsp+0x90], xmm10
00007e97133de6ef  vmovaps [rsp+0xA0], xmm11
00007e97133de6f8  vmovaps [rsp+0xB0], xmm12
00007e97133de701  vmovaps [rsp+0xC0], xmm13
00007e97133de70a  vmovaps [rsp+0xD0], xmm14
00007e97133de713  vmovaps [rsp+0xE0], xmm15
00007e97133de71c  sub rsp, 0x30
00007e97133de720  movaps [rsp], xmm9
00007e97133de725  movaps [rsp+0x10], xmm3
00007e97133de72a  movaps [rsp+0x20], xmm1
00007e97133de72f  lea rdi, [rsp]
00007e97133de733  mov esi, 0x00
00007e97133de738  mov rax, 0x58D8AED5F530
00007e97133de742  call rax
00007e97133de744  movaps xmm9, [rsp]
00007e97133de749  add rsp, 0x30
00007e97133de74d  vmovaps xmm0, [rsp]
00007e97133de752  vmovaps xmm1, [rsp+0x10]
00007e97133de758  vmovaps xmm2, [rsp+0x20]
00007e97133de75e  vmovaps xmm3, [rsp+0x30]
00007e97133de764  vmovaps xmm4, [rsp+0x40]
00007e97133de76a  vmovaps xmm5, [rsp+0x50]
00007e97133de770  vmovaps xmm6, [rsp+0x60]
00007e97133de776  vmovaps xmm7, [rsp+0x70]
00007e97133de77c  vmovaps xmm8, [rsp+0x80]
00007e97133de785  vmovaps xmm10, [rsp+0x90]
00007e97133de78e  vmovaps xmm11, [rsp+0xA0]
00007e97133de797  vmovaps xmm12, [rsp+0xB0]
00007e97133de7a0  vmovaps xmm13, [rsp+0xC0]
00007e97133de7a9  vmovaps xmm14, [rsp+0xD0]
00007e97133de7b2  vmovaps xmm15, [rsp+0xE0]
00007e97133de7bb  add rsp, 0xF0
00007e97133de7c2  pop r11
00007e97133de7c4  pop r10
00007e97133de7c6  pop r9
00007e97133de7c8  pop r8
00007e97133de7ca  pop rsi
00007e97133de7cb  pop rdi
00007e97133de7cc  pop rdx
00007e97133de7cd  pop rcx
00007e97133de7ce  pop rax
00007e97133de7cf  add rsp, 0x08
00007e97133de7d3  jmp 0x00007E97133DC1AA
00007e97133de7d8  call 0x00007E97132B52F0
00007e97133de7dd  jmp 0x00007E97133DC1B7
00007e97133de7e2  sub rsp, 0x08
00007e97133de7e6  push rax
00007e97133de7e7  push rcx
00007e97133de7e8  push rdx
00007e97133de7e9  push rdi
00007e97133de7ea  push rsi
00007e97133de7eb  push r8
00007e97133de7ed  push r9
00007e97133de7ef  push r10
00007e97133de7f1  push r11
00007e97133de7f3  sub rsp, 0xF0
00007e97133de7fa  vmovaps [rsp], xmm0
00007e97133de7ff  vmovaps [rsp+0x10], xmm1
00007e97133de805  vmovaps [rsp+0x20], xmm2
00007e97133de80b  vmovaps [rsp+0x30], xmm3
00007e97133de811  vmovaps [rsp+0x40], xmm4
00007e97133de817  vmovaps [rsp+0x50], xmm5
00007e97133de81d  vmovaps [rsp+0x60], xmm6
00007e97133de823  vmovaps [rsp+0x70], xmm7
00007e97133de829  vmovaps [rsp+0x80], xmm8
00007e97133de832  vmovaps [rsp+0x90], xmm9
00007e97133de83b  vmovaps [rsp+0xA0], xmm10
00007e97133de844  vmovaps [rsp+0xB0], xmm11
00007e97133de84d  vmovaps [rsp+0xC0], xmm12
00007e97133de856  vmovaps [rsp+0xD0], xmm13
00007e97133de85f  vmovaps [rsp+0xE0], xmm14
00007e97133de868  sub rsp, 0x30
00007e97133de86c  movaps [rsp], xmm15
00007e97133de871  movaps [rsp+0x10], xmm3
00007e97133de876  movaps [rsp+0x20], xmm7
00007e97133de87b  lea rdi, [rsp]
00007e97133de87f  mov esi, 0x00
00007e97133de884  mov rax, 0x58D8AED5F530
00007e97133de88e  call rax
00007e97133de890  movaps xmm15, [rsp]
00007e97133de895  add rsp, 0x30
00007e97133de899  vmovaps xmm0, [rsp]
00007e97133de89e  vmovaps xmm1, [rsp+0x10]
00007e97133de8a4  vmovaps xmm2, [rsp+0x20]
00007e97133de8aa  vmovaps xmm3, [rsp+0x30]
00007e97133de8b0  vmovaps xmm4, [rsp+0x40]
00007e97133de8b6  vmovaps xmm5, [rsp+0x50]
00007e97133de8bc  vmovaps xmm6, [rsp+0x60]
00007e97133de8c2  vmovaps xmm7, [rsp+0x70]
00007e97133de8c8  vmovaps xmm8, [rsp+0x80]
00007e97133de8d1  vmovaps xmm9, [rsp+0x90]
00007e97133de8da  vmovaps xmm10, [rsp+0xA0]
00007e97133de8e3  vmovaps xmm11, [rsp+0xB0]
00007e97133de8ec  vmovaps xmm12, [rsp+0xC0]
00007e97133de8f5  vmovaps xmm13, [rsp+0xD0]
00007e97133de8fe  vmovaps xmm14, [rsp+0xE0]
00007e97133de907  add rsp, 0xF0
00007e97133de90e  pop r11
00007e97133de910  pop r10
00007e97133de912  pop r9
00007e97133de914  pop r8
00007e97133de916  pop rsi
00007e97133de917  pop rdi
00007e97133de918  pop rdx
00007e97133de919  pop rcx
00007e97133de91a  pop rax
00007e97133de91b  add rsp, 0x08
00007e97133de91f  jmp 0x00007E97133DC1E3
00007e97133de924  sub rsp, 0x08
00007e97133de928  push rax
00007e97133de929  push rcx
00007e97133de92a  push rdx
00007e97133de92b  push rdi
00007e97133de92c  push rsi
00007e97133de92d  push r8
00007e97133de92f  push r9
00007e97133de931  push r10
00007e97133de933  push r11
00007e97133de935  sub rsp, 0xF0
00007e97133de93c  vmovaps [rsp], xmm0
00007e97133de941  vmovaps [rsp+0x10], xmm1
00007e97133de947  vmovaps [rsp+0x20], xmm2
00007e97133de94d  vmovaps [rsp+0x30], xmm4
00007e97133de953  vmovaps [rsp+0x40], xmm5
00007e97133de959  vmovaps [rsp+0x50], xmm6
00007e97133de95f  vmovaps [rsp+0x60], xmm7
00007e97133de965  vmovaps [rsp+0x70], xmm8
00007e97133de96b  vmovaps [rsp+0x80], xmm9
00007e97133de974  vmovaps [rsp+0x90], xmm10
00007e97133de97d  vmovaps [rsp+0xA0], xmm11
00007e97133de986  vmovaps [rsp+0xB0], xmm12
00007e97133de98f  vmovaps [rsp+0xC0], xmm13
00007e97133de998  vmovaps [rsp+0xD0], xmm14
00007e97133de9a1  vmovaps [rsp+0xE0], xmm15
00007e97133de9aa  sub rsp, 0x30
00007e97133de9ae  movaps [rsp], xmm3
00007e97133de9b2  movaps [rsp+0x10], xmm1
00007e97133de9b7  movaps [rsp+0x20], xmm15
00007e97133de9bd  lea rdi, [rsp]
00007e97133de9c1  mov esi, 0x00
00007e97133de9c6  mov rax, 0x58D8AED5F530
00007e97133de9d0  call rax
00007e97133de9d2  movaps xmm3, [rsp]
00007e97133de9d6  add rsp, 0x30
00007e97133de9da  vmovaps xmm0, [rsp]
00007e97133de9df  vmovaps xmm1, [rsp+0x10]
00007e97133de9e5  vmovaps xmm2, [rsp+0x20]
00007e97133de9eb  vmovaps xmm4, [rsp+0x30]
00007e97133de9f1  vmovaps xmm5, [rsp+0x40]
00007e97133de9f7  vmovaps xmm6, [rsp+0x50]
00007e97133de9fd  vmovaps xmm7, [rsp+0x60]
00007e97133dea03  vmovaps xmm8, [rsp+0x70]
00007e97133dea09  vmovaps xmm9, [rsp+0x80]
00007e97133dea12  vmovaps xmm10, [rsp+0x90]
00007e97133dea1b  vmovaps xmm11, [rsp+0xA0]
00007e97133dea24  vmovaps xmm12, [rsp+0xB0]
00007e97133dea2d  vmovaps xmm13, [rsp+0xC0]
00007e97133dea36  vmovaps xmm14, [rsp+0xD0]
00007e97133dea3f  vmovaps xmm15, [rsp+0xE0]
00007e97133dea48  add rsp, 0xF0
00007e97133dea4f  pop r11
00007e97133dea51  pop r10
00007e97133dea53  pop r9
00007e97133dea55  pop r8
00007e97133dea57  pop rsi
00007e97133dea58  pop rdi
00007e97133dea59  pop rdx
00007e97133dea5a  pop rcx
00007e97133dea5b  pop rax
00007e97133dea5c  add rsp, 0x08
00007e97133dea60  jmp 0x00007E97133DC272
00007e97133dea65  call 0x00007E97132B52F0
00007e97133dea6a  jmp 0x00007E97133DC27C
00007e97133dea6f  sub rsp, 0x08
00007e97133dea73  push rax
00007e97133dea74  push rcx
00007e97133dea75  push rdx
00007e97133dea76  push rdi
00007e97133dea77  push rsi
00007e97133dea78  push r8
00007e97133dea7a  push r9
00007e97133dea7c  push r10
00007e97133dea7e  push r11
00007e97133dea80  sub rsp, 0xF0
00007e97133dea87  vmovaps [rsp], xmm0
00007e97133dea8c  vmovaps [rsp+0x10], xmm1
00007e97133dea92  vmovaps [rsp+0x20], xmm2
00007e97133dea98  vmovaps [rsp+0x30], xmm3
00007e97133dea9e  vmovaps [rsp+0x40], xmm4
00007e97133deaa4  vmovaps [rsp+0x50], xmm5
00007e97133deaaa  vmovaps [rsp+0x60], xmm6
00007e97133deab0  vmovaps [rsp+0x70], xmm7
00007e97133deab6  vmovaps [rsp+0x80], xmm8
00007e97133deabf  vmovaps [rsp+0x90], xmm9
00007e97133deac8  vmovaps [rsp+0xA0], xmm10
00007e97133dead1  vmovaps [rsp+0xB0], xmm11
00007e97133deada  vmovaps [rsp+0xC0], xmm12
00007e97133deae3  vmovaps [rsp+0xD0], xmm13
00007e97133deaec  vmovaps [rsp+0xE0], xmm14
00007e97133deaf5  sub rsp, 0x30
00007e97133deaf9  movaps [rsp], xmm15
00007e97133deafe  movaps [rsp+0x10], xmm14
00007e97133deb04  movaps [rsp+0x20], xmm4
00007e97133deb09  lea rdi, [rsp]
00007e97133deb0d  mov esi, 0x00
00007e97133deb12  mov rax, 0x58D8AED5F530
00007e97133deb1c  call rax
00007e97133deb1e  movaps xmm15, [rsp]
00007e97133deb23  add rsp, 0x30
00007e97133deb27  vmovaps xmm0, [rsp]
00007e97133deb2c  vmovaps xmm1, [rsp+0x10]
00007e97133deb32  vmovaps xmm2, [rsp+0x20]
00007e97133deb38  vmovaps xmm3, [rsp+0x30]
00007e97133deb3e  vmovaps xmm4, [rsp+0x40]
00007e97133deb44  vmovaps xmm5, [rsp+0x50]
00007e97133deb4a  vmovaps xmm6, [rsp+0x60]
00007e97133deb50  vmovaps xmm7, [rsp+0x70]
00007e97133deb56  vmovaps xmm8, [rsp+0x80]
00007e97133deb5f  vmovaps xmm9, [rsp+0x90]
00007e97133deb68  vmovaps xmm10, [rsp+0xA0]
00007e97133deb71  vmovaps xmm11, [rsp+0xB0]
00007e97133deb7a  vmovaps xmm12, [rsp+0xC0]
00007e97133deb83  vmovaps xmm13, [rsp+0xD0]
00007e97133deb8c  vmovaps xmm14, [rsp+0xE0]
00007e97133deb95  add rsp, 0xF0
00007e97133deb9c  pop r11
00007e97133deb9e  pop r10
00007e97133deba0  pop r9
00007e97133deba2  pop r8
00007e97133deba4  pop rsi
00007e97133deba5  pop rdi
00007e97133deba6  pop rdx
00007e97133deba7  pop rcx
00007e97133deba8  pop rax
00007e97133deba9  add rsp, 0x08
00007e97133debad  jmp 0x00007E97133DC2AA
00007e97133debb2  sub rsp, 0x08
00007e97133debb6  push rax
00007e97133debb7  push rcx
00007e97133debb8  push rdx
00007e97133debb9  push rdi
00007e97133debba  push rsi
00007e97133debbb  push r8
00007e97133debbd  push r9
00007e97133debbf  push r10
00007e97133debc1  push r11
00007e97133debc3  sub rsp, 0xF0
00007e97133debca  vmovaps [rsp], xmm0
00007e97133debcf  vmovaps [rsp+0x10], xmm1
00007e97133debd5  vmovaps [rsp+0x20], xmm2
00007e97133debdb  vmovaps [rsp+0x30], xmm3
00007e97133debe1  vmovaps [rsp+0x40], xmm4
00007e97133debe7  vmovaps [rsp+0x50], xmm5
00007e97133debed  vmovaps [rsp+0x60], xmm6
00007e97133debf3  vmovaps [rsp+0x70], xmm7
00007e97133debf9  vmovaps [rsp+0x80], xmm8
00007e97133dec02  vmovaps [rsp+0x90], xmm9
00007e97133dec0b  vmovaps [rsp+0xA0], xmm10
00007e97133dec14  vmovaps [rsp+0xB0], xmm11
00007e97133dec1d  vmovaps [rsp+0xC0], xmm12
00007e97133dec26  vmovaps [rsp+0xD0], xmm13
00007e97133dec2f  vmovaps [rsp+0xE0], xmm15
00007e97133dec38  sub rsp, 0x30
00007e97133dec3c  movaps [rsp], xmm14
00007e97133dec41  movaps [rsp+0x10], xmm2
00007e97133dec46  movaps [rsp+0x20], xmm1
00007e97133dec4b  lea rdi, [rsp]
00007e97133dec4f  mov esi, 0x00
00007e97133dec54  mov rax, 0x58D8AED5F530
00007e97133dec5e  call rax
00007e97133dec60  movaps xmm14, [rsp]
00007e97133dec65  add rsp, 0x30
00007e97133dec69  vmovaps xmm0, [rsp]
00007e97133dec6e  vmovaps xmm1, [rsp+0x10]
00007e97133dec74  vmovaps xmm2, [rsp+0x20]
00007e97133dec7a  vmovaps xmm3, [rsp+0x30]
00007e97133dec80  vmovaps xmm4, [rsp+0x40]
00007e97133dec86  vmovaps xmm5, [rsp+0x50]
00007e97133dec8c  vmovaps xmm6, [rsp+0x60]
00007e97133dec92  vmovaps xmm7, [rsp+0x70]
00007e97133dec98  vmovaps xmm8, [rsp+0x80]
00007e97133deca1  vmovaps xmm9, [rsp+0x90]
00007e97133decaa  vmovaps xmm10, [rsp+0xA0]
00007e97133decb3  vmovaps xmm11, [rsp+0xB0]
00007e97133decbc  vmovaps xmm12, [rsp+0xC0]
00007e97133decc5  vmovaps xmm13, [rsp+0xD0]
00007e97133decce  vmovaps xmm15, [rsp+0xE0]
00007e97133decd7  add rsp, 0xF0
00007e97133decde  pop r11
00007e97133dece0  pop r10
00007e97133dece2  pop r9
00007e97133dece4  pop r8
00007e97133dece6  pop rsi
00007e97133dece7  pop rdi
00007e97133dece8  pop rdx
00007e97133dece9  pop rcx
00007e97133decea  pop rax
00007e97133deceb  add rsp, 0x08
00007e97133decef  jmp 0x00007E97133DC2D0
00007e97133decf4  sub rsp, 0x08
00007e97133decf8  push rax
00007e97133decf9  push rcx
00007e97133decfa  push rdx
00007e97133decfb  push rdi
00007e97133decfc  push rsi
00007e97133decfd  push r8
00007e97133decff  push r9
00007e97133ded01  push r10
00007e97133ded03  push r11
00007e97133ded05  sub rsp, 0xF0
00007e97133ded0c  vmovaps [rsp], xmm0
00007e97133ded11  vmovaps [rsp+0x10], xmm2
00007e97133ded17  vmovaps [rsp+0x20], xmm3
00007e97133ded1d  vmovaps [rsp+0x30], xmm4
00007e97133ded23  vmovaps [rsp+0x40], xmm5
00007e97133ded29  vmovaps [rsp+0x50], xmm6
00007e97133ded2f  vmovaps [rsp+0x60], xmm7
00007e97133ded35  vmovaps [rsp+0x70], xmm8
00007e97133ded3b  vmovaps [rsp+0x80], xmm9
00007e97133ded44  vmovaps [rsp+0x90], xmm10
00007e97133ded4d  vmovaps [rsp+0xA0], xmm11
00007e97133ded56  vmovaps [rsp+0xB0], xmm12
00007e97133ded5f  vmovaps [rsp+0xC0], xmm13
00007e97133ded68  vmovaps [rsp+0xD0], xmm14
00007e97133ded71  vmovaps [rsp+0xE0], xmm15
00007e97133ded7a  sub rsp, 0x30
00007e97133ded7e  movaps [rsp], xmm1
00007e97133ded82  movaps [rsp+0x10], xmm4
00007e97133ded87  movaps [rsp+0x20], xmm9
00007e97133ded8d  lea rdi, [rsp]
00007e97133ded91  mov esi, 0x00
00007e97133ded96  mov rax, 0x58D8AED5F530
00007e97133deda0  call rax
00007e97133deda2  movaps xmm1, [rsp]
00007e97133deda6  add rsp, 0x30
00007e97133dedaa  vmovaps xmm0, [rsp]
00007e97133dedaf  vmovaps xmm2, [rsp+0x10]
00007e97133dedb5  vmovaps xmm3, [rsp+0x20]
00007e97133dedbb  vmovaps xmm4, [rsp+0x30]
00007e97133dedc1  vmovaps xmm5, [rsp+0x40]
00007e97133dedc7  vmovaps xmm6, [rsp+0x50]
00007e97133dedcd  vmovaps xmm7, [rsp+0x60]
00007e97133dedd3  vmovaps xmm8, [rsp+0x70]
00007e97133dedd9  vmovaps xmm9, [rsp+0x80]
00007e97133dede2  vmovaps xmm10, [rsp+0x90]
00007e97133dedeb  vmovaps xmm11, [rsp+0xA0]
00007e97133dedf4  vmovaps xmm12, [rsp+0xB0]
00007e97133dedfd  vmovaps xmm13, [rsp+0xC0]
00007e97133dee06  vmovaps xmm14, [rsp+0xD0]
00007e97133dee0f  vmovaps xmm15, [rsp+0xE0]
00007e97133dee18  add rsp, 0xF0
00007e97133dee1f  pop r11
00007e97133dee21  pop r10
00007e97133dee23  pop r9
00007e97133dee25  pop r8
00007e97133dee27  pop rsi
00007e97133dee28  pop rdi
00007e97133dee29  pop rdx
00007e97133dee2a  pop rcx
00007e97133dee2b  pop rax
00007e97133dee2c  add rsp, 0x08
00007e97133dee30  jmp 0x00007E97133DC2EE
00007e97133dee35  sub rsp, 0x08
00007e97133dee39  push rax
00007e97133dee3a  push rcx
00007e97133dee3b  push rdx
00007e97133dee3c  push rdi
00007e97133dee3d  push rsi
00007e97133dee3e  push r8
00007e97133dee40  push r9
00007e97133dee42  push r10
00007e97133dee44  push r11
00007e97133dee46  sub rsp, 0xF0
00007e97133dee4d  vmovaps [rsp], xmm0
00007e97133dee52  vmovaps [rsp+0x10], xmm1
00007e97133dee58  vmovaps [rsp+0x20], xmm2
00007e97133dee5e  vmovaps [rsp+0x30], xmm3
00007e97133dee64  vmovaps [rsp+0x40], xmm5
00007e97133dee6a  vmovaps [rsp+0x50], xmm6
00007e97133dee70  vmovaps [rsp+0x60], xmm7
00007e97133dee76  vmovaps [rsp+0x70], xmm8
00007e97133dee7c  vmovaps [rsp+0x80], xmm9
00007e97133dee85  vmovaps [rsp+0x90], xmm10
00007e97133dee8e  vmovaps [rsp+0xA0], xmm11
00007e97133dee97  vmovaps [rsp+0xB0], xmm12
00007e97133deea0  vmovaps [rsp+0xC0], xmm13
00007e97133deea9  vmovaps [rsp+0xD0], xmm14
00007e97133deeb2  vmovaps [rsp+0xE0], xmm15
00007e97133deebb  sub rsp, 0x30
00007e97133deebf  movaps [rsp], xmm4
00007e97133deec3  movaps [rsp+0x10], xmm2
00007e97133deec8  movaps [rsp+0x20], xmm9
00007e97133deece  lea rdi, [rsp]
00007e97133deed2  mov esi, 0x00
00007e97133deed7  mov rax, 0x58D8AED5F530
00007e97133deee1  call rax
00007e97133deee3  movaps xmm4, [rsp]
00007e97133deee7  add rsp, 0x30
00007e97133deeeb  vmovaps xmm0, [rsp]
00007e97133deef0  vmovaps xmm1, [rsp+0x10]
00007e97133deef6  vmovaps xmm2, [rsp+0x20]
00007e97133deefc  vmovaps xmm3, [rsp+0x30]
00007e97133def02  vmovaps xmm5, [rsp+0x40]
00007e97133def08  vmovaps xmm6, [rsp+0x50]
00007e97133def0e  vmovaps xmm7, [rsp+0x60]
00007e97133def14  vmovaps xmm8, [rsp+0x70]
00007e97133def1a  vmovaps xmm9, [rsp+0x80]
00007e97133def23  vmovaps xmm10, [rsp+0x90]
00007e97133def2c  vmovaps xmm11, [rsp+0xA0]
00007e97133def35  vmovaps xmm12, [rsp+0xB0]
00007e97133def3e  vmovaps xmm13, [rsp+0xC0]
00007e97133def47  vmovaps xmm14, [rsp+0xD0]
00007e97133def50  vmovaps xmm15, [rsp+0xE0]
00007e97133def59  add rsp, 0xF0
00007e97133def60  pop r11
00007e97133def62  pop r10
00007e97133def64  pop r9
00007e97133def66  pop r8
00007e97133def68  pop rsi
00007e97133def69  pop rdi
00007e97133def6a  pop rdx
00007e97133def6b  pop rcx
00007e97133def6c  pop rax
00007e97133def6d  add rsp, 0x08
00007e97133def71  jmp 0x00007E97133DC31E
00007e97133def76  sub rsp, 0x08
00007e97133def7a  push rax
00007e97133def7b  push rcx
00007e97133def7c  push rdx
00007e97133def7d  push rdi
00007e97133def7e  push rsi
00007e97133def7f  push r8
00007e97133def81  push r9
00007e97133def83  push r10
00007e97133def85  push r11
00007e97133def87  sub rsp, 0xF0
00007e97133def8e  vmovaps [rsp], xmm0
00007e97133def93  vmovaps [rsp+0x10], xmm1
00007e97133def99  vmovaps [rsp+0x20], xmm2
00007e97133def9f  vmovaps [rsp+0x30], xmm3
00007e97133defa5  vmovaps [rsp+0x40], xmm4
00007e97133defab  vmovaps [rsp+0x50], xmm5
00007e97133defb1  vmovaps [rsp+0x60], xmm6
00007e97133defb7  vmovaps [rsp+0x70], xmm7
00007e97133defbd  vmovaps [rsp+0x80], xmm8
00007e97133defc6  vmovaps [rsp+0x90], xmm10
00007e97133defcf  vmovaps [rsp+0xA0], xmm11
00007e97133defd8  vmovaps [rsp+0xB0], xmm12
00007e97133defe1  vmovaps [rsp+0xC0], xmm13
00007e97133defea  vmovaps [rsp+0xD0], xmm14
00007e97133deff3  vmovaps [rsp+0xE0], xmm15
00007e97133deffc  sub rsp, 0x30
00007e97133df000  movaps [rsp], xmm9
00007e97133df005  movaps [rsp+0x10], xmm2
00007e97133df00a  movaps [rsp+0x20], xmm1
00007e97133df00f  lea rdi, [rsp]
00007e97133df013  mov esi, 0x00
00007e97133df018  mov rax, 0x58D8AED5F530
00007e97133df022  call rax
00007e97133df024  movaps xmm9, [rsp]
00007e97133df029  add rsp, 0x30
00007e97133df02d  vmovaps xmm0, [rsp]
00007e97133df032  vmovaps xmm1, [rsp+0x10]
00007e97133df038  vmovaps xmm2, [rsp+0x20]
00007e97133df03e  vmovaps xmm3, [rsp+0x30]
00007e97133df044  vmovaps xmm4, [rsp+0x40]
00007e97133df04a  vmovaps xmm5, [rsp+0x50]
00007e97133df050  vmovaps xmm6, [rsp+0x60]
00007e97133df056  vmovaps xmm7, [rsp+0x70]
00007e97133df05c  vmovaps xmm8, [rsp+0x80]
00007e97133df065  vmovaps xmm10, [rsp+0x90]
00007e97133df06e  vmovaps xmm11, [rsp+0xA0]
00007e97133df077  vmovaps xmm12, [rsp+0xB0]
00007e97133df080  vmovaps xmm13, [rsp+0xC0]
00007e97133df089  vmovaps xmm14, [rsp+0xD0]
00007e97133df092  vmovaps xmm15, [rsp+0xE0]
00007e97133df09b  add rsp, 0xF0
00007e97133df0a2  pop r11
00007e97133df0a4  pop r10
00007e97133df0a6  pop r9
00007e97133df0a8  pop r8
00007e97133df0aa  pop rsi
00007e97133df0ab  pop rdi
00007e97133df0ac  pop rdx
00007e97133df0ad  pop rcx
00007e97133df0ae  pop rax
00007e97133df0af  add rsp, 0x08
00007e97133df0b3  jmp 0x00007E97133DC354
00007e97133df0b8  sub rsp, 0x08
00007e97133df0bc  push rax
00007e97133df0bd  push rcx
00007e97133df0be  push rdx
00007e97133df0bf  push rdi
00007e97133df0c0  push rsi
00007e97133df0c1  push r8
00007e97133df0c3  push r9
00007e97133df0c5  push r10
00007e97133df0c7  push r11
00007e97133df0c9  sub rsp, 0xF0
00007e97133df0d0  vmovaps [rsp], xmm0
00007e97133df0d5  vmovaps [rsp+0x10], xmm2
00007e97133df0db  vmovaps [rsp+0x20], xmm3
00007e97133df0e1  vmovaps [rsp+0x30], xmm4
00007e97133df0e7  vmovaps [rsp+0x40], xmm5
00007e97133df0ed  vmovaps [rsp+0x50], xmm6
00007e97133df0f3  vmovaps [rsp+0x60], xmm7
00007e97133df0f9  vmovaps [rsp+0x70], xmm8
00007e97133df0ff  vmovaps [rsp+0x80], xmm9
00007e97133df108  vmovaps [rsp+0x90], xmm10
00007e97133df111  vmovaps [rsp+0xA0], xmm11
00007e97133df11a  vmovaps [rsp+0xB0], xmm12
00007e97133df123  vmovaps [rsp+0xC0], xmm13
00007e97133df12c  vmovaps [rsp+0xD0], xmm14
00007e97133df135  vmovaps [rsp+0xE0], xmm15
00007e97133df13e  sub rsp, 0x30
00007e97133df142  movaps [rsp], xmm1
00007e97133df146  movaps [rsp+0x10], xmm15
00007e97133df14c  movaps [rsp+0x20], xmm6
00007e97133df151  lea rdi, [rsp]
00007e97133df155  mov esi, 0x00
00007e97133df15a  mov rax, 0x58D8AED5F530
00007e97133df164  call rax
00007e97133df166  movaps xmm1, [rsp]
00007e97133df16a  add rsp, 0x30
00007e97133df16e  vmovaps xmm0, [rsp]
00007e97133df173  vmovaps xmm2, [rsp+0x10]
00007e97133df179  vmovaps xmm3, [rsp+0x20]
00007e97133df17f  vmovaps xmm4, [rsp+0x30]
00007e97133df185  vmovaps xmm5, [rsp+0x40]
00007e97133df18b  vmovaps xmm6, [rsp+0x50]
00007e97133df191  vmovaps xmm7, [rsp+0x60]
00007e97133df197  vmovaps xmm8, [rsp+0x70]
00007e97133df19d  vmovaps xmm9, [rsp+0x80]
00007e97133df1a6  vmovaps xmm10, [rsp+0x90]
00007e97133df1af  vmovaps xmm11, [rsp+0xA0]
00007e97133df1b8  vmovaps xmm12, [rsp+0xB0]
00007e97133df1c1  vmovaps xmm13, [rsp+0xC0]
00007e97133df1ca  vmovaps xmm14, [rsp+0xD0]
00007e97133df1d3  vmovaps xmm15, [rsp+0xE0]
00007e97133df1dc  add rsp, 0xF0
00007e97133df1e3  pop r11
00007e97133df1e5  pop r10
00007e97133df1e7  pop r9
00007e97133df1e9  pop r8
00007e97133df1eb  pop rsi
00007e97133df1ec  pop rdi
00007e97133df1ed  pop rdx
00007e97133df1ee  pop rcx
00007e97133df1ef  pop rax
00007e97133df1f0  add rsp, 0x08
00007e97133df1f4  jmp 0x00007E97133DC375
00007e97133df1f9  sub rsp, 0x08
00007e97133df1fd  push rax
00007e97133df1fe  push rcx
00007e97133df1ff  push rdx
00007e97133df200  push rdi
00007e97133df201  push rsi
00007e97133df202  push r8
00007e97133df204  push r9
00007e97133df206  push r10
00007e97133df208  push r11
00007e97133df20a  sub rsp, 0xF0
00007e97133df211  vmovaps [rsp], xmm0
00007e97133df216  vmovaps [rsp+0x10], xmm1
00007e97133df21c  vmovaps [rsp+0x20], xmm2
00007e97133df222  vmovaps [rsp+0x30], xmm3
00007e97133df228  vmovaps [rsp+0x40], xmm4
00007e97133df22e  vmovaps [rsp+0x50], xmm5
00007e97133df234  vmovaps [rsp+0x60], xmm6
00007e97133df23a  vmovaps [rsp+0x70], xmm7
00007e97133df240  vmovaps [rsp+0x80], xmm8
00007e97133df249  vmovaps [rsp+0x90], xmm9
00007e97133df252  vmovaps [rsp+0xA0], xmm10
00007e97133df25b  vmovaps [rsp+0xB0], xmm11
00007e97133df264  vmovaps [rsp+0xC0], xmm12
00007e97133df26d  vmovaps [rsp+0xD0], xmm13
00007e97133df276  vmovaps [rsp+0xE0], xmm14
00007e97133df27f  sub rsp, 0x30
00007e97133df283  movaps [rsp], xmm15
00007e97133df288  movaps [rsp+0x10], xmm5
00007e97133df28d  movaps [rsp+0x20], xmm3
00007e97133df292  lea rdi, [rsp]
00007e97133df296  mov esi, 0x00
00007e97133df29b  mov rax, 0x58D8AED5F530
00007e97133df2a5  call rax
00007e97133df2a7  movaps xmm15, [rsp]
00007e97133df2ac  add rsp, 0x30
00007e97133df2b0  vmovaps xmm0, [rsp]
00007e97133df2b5  vmovaps xmm1, [rsp+0x10]
00007e97133df2bb  vmovaps xmm2, [rsp+0x20]
00007e97133df2c1  vmovaps xmm3, [rsp+0x30]
00007e97133df2c7  vmovaps xmm4, [rsp+0x40]
00007e97133df2cd  vmovaps xmm5, [rsp+0x50]
00007e97133df2d3  vmovaps xmm6, [rsp+0x60]
00007e97133df2d9  vmovaps xmm7, [rsp+0x70]
00007e97133df2df  vmovaps xmm8, [rsp+0x80]
00007e97133df2e8  vmovaps xmm9, [rsp+0x90]
00007e97133df2f1  vmovaps xmm10, [rsp+0xA0]
00007e97133df2fa  vmovaps xmm11, [rsp+0xB0]
00007e97133df303  vmovaps xmm12, [rsp+0xC0]
00007e97133df30c  vmovaps xmm13, [rsp+0xD0]
00007e97133df315  vmovaps xmm14, [rsp+0xE0]
00007e97133df31e  add rsp, 0xF0
00007e97133df325  pop r11
00007e97133df327  pop r10
00007e97133df329  pop r9
00007e97133df32b  pop r8
00007e97133df32d  pop rsi
00007e97133df32e  pop rdi
00007e97133df32f  pop rdx
00007e97133df330  pop rcx
00007e97133df331  pop rax
00007e97133df332  add rsp, 0x08
00007e97133df336  jmp 0x00007E97133DC38F
00007e97133df33b  sub rsp, 0x08
00007e97133df33f  push rax
00007e97133df340  push rcx
00007e97133df341  push rdx
00007e97133df342  push rdi
00007e97133df343  push rsi
00007e97133df344  push r8
00007e97133df346  push r9
00007e97133df348  push r10
00007e97133df34a  push r11
00007e97133df34c  sub rsp, 0xF0
00007e97133df353  vmovaps [rsp], xmm0
00007e97133df358  vmovaps [rsp+0x10], xmm1
00007e97133df35e  vmovaps [rsp+0x20], xmm2
00007e97133df364  vmovaps [rsp+0x30], xmm3
00007e97133df36a  vmovaps [rsp+0x40], xmm4
00007e97133df370  vmovaps [rsp+0x50], xmm6
00007e97133df376  vmovaps [rsp+0x60], xmm7
00007e97133df37c  vmovaps [rsp+0x70], xmm8
00007e97133df382  vmovaps [rsp+0x80], xmm9
00007e97133df38b  vmovaps [rsp+0x90], xmm10
00007e97133df394  vmovaps [rsp+0xA0], xmm11
00007e97133df39d  vmovaps [rsp+0xB0], xmm12
00007e97133df3a6  vmovaps [rsp+0xC0], xmm13
00007e97133df3af  vmovaps [rsp+0xD0], xmm14
00007e97133df3b8  vmovaps [rsp+0xE0], xmm15
00007e97133df3c1  sub rsp, 0x30
00007e97133df3c5  movaps [rsp], xmm5
00007e97133df3c9  movaps [rsp+0x10], xmm8
00007e97133df3cf  movaps [rsp+0x20], xmm6
00007e97133df3d4  lea rdi, [rsp]
00007e97133df3d8  mov esi, 0x00
00007e97133df3dd  mov rax, 0x58D8AED5F530
00007e97133df3e7  call rax
00007e97133df3e9  movaps xmm5, [rsp]
00007e97133df3ed  add rsp, 0x30
00007e97133df3f1  vmovaps xmm0, [rsp]
00007e97133df3f6  vmovaps xmm1, [rsp+0x10]
00007e97133df3fc  vmovaps xmm2, [rsp+0x20]
00007e97133df402  vmovaps xmm3, [rsp+0x30]
00007e97133df408  vmovaps xmm4, [rsp+0x40]
00007e97133df40e  vmovaps xmm6, [rsp+0x50]
00007e97133df414  vmovaps xmm7, [rsp+0x60]
00007e97133df41a  vmovaps xmm8, [rsp+0x70]
00007e97133df420  vmovaps xmm9, [rsp+0x80]
00007e97133df429  vmovaps xmm10, [rsp+0x90]
00007e97133df432  vmovaps xmm11, [rsp+0xA0]
00007e97133df43b  vmovaps xmm12, [rsp+0xB0]
00007e97133df444  vmovaps xmm13, [rsp+0xC0]
00007e97133df44d  vmovaps xmm14, [rsp+0xD0]
00007e97133df456  vmovaps xmm15, [rsp+0xE0]
00007e97133df45f  add rsp, 0xF0
00007e97133df466  pop r11
00007e97133df468  pop r10
00007e97133df46a  pop r9
00007e97133df46c  pop r8
00007e97133df46e  pop rsi
00007e97133df46f  pop rdi
00007e97133df470  pop rdx
00007e97133df471  pop rcx
00007e97133df472  pop rax
00007e97133df473  add rsp, 0x08
00007e97133df477  jmp 0x00007E97133DC3B3
00007e97133df47c  sub rsp, 0x08
00007e97133df480  push rax
00007e97133df481  push rcx
00007e97133df482  push rdx
00007e97133df483  push rdi
00007e97133df484  push rsi
00007e97133df485  push r8
00007e97133df487  push r9
00007e97133df489  push r10
00007e97133df48b  push r11
00007e97133df48d  sub rsp, 0xF0
00007e97133df494  vmovaps [rsp], xmm0
00007e97133df499  vmovaps [rsp+0x10], xmm1
00007e97133df49f  vmovaps [rsp+0x20], xmm2
00007e97133df4a5  vmovaps [rsp+0x30], xmm3
00007e97133df4ab  vmovaps [rsp+0x40], xmm4
00007e97133df4b1  vmovaps [rsp+0x50], xmm5
00007e97133df4b7  vmovaps [rsp+0x60], xmm7
00007e97133df4bd  vmovaps [rsp+0x70], xmm8
00007e97133df4c3  vmovaps [rsp+0x80], xmm9
00007e97133df4cc  vmovaps [rsp+0x90], xmm10
00007e97133df4d5  vmovaps [rsp+0xA0], xmm11
00007e97133df4de  vmovaps [rsp+0xB0], xmm12
00007e97133df4e7  vmovaps [rsp+0xC0], xmm13
00007e97133df4f0  vmovaps [rsp+0xD0], xmm14
00007e97133df4f9  vmovaps [rsp+0xE0], xmm15
00007e97133df502  sub rsp, 0x30
00007e97133df506  movaps [rsp], xmm6
00007e97133df50a  movaps [rsp+0x10], xmm10
00007e97133df510  movaps [rsp+0x20], xmm8
00007e97133df516  lea rdi, [rsp]
00007e97133df51a  mov esi, 0x00
00007e97133df51f  mov rax, 0x58D8AED5F530
00007e97133df529  call rax
00007e97133df52b  movaps xmm6, [rsp]
00007e97133df52f  add rsp, 0x30
00007e97133df533  vmovaps xmm0, [rsp]
00007e97133df538  vmovaps xmm1, [rsp+0x10]
00007e97133df53e  vmovaps xmm2, [rsp+0x20]
00007e97133df544  vmovaps xmm3, [rsp+0x30]
00007e97133df54a  vmovaps xmm4, [rsp+0x40]
00007e97133df550  vmovaps xmm5, [rsp+0x50]
00007e97133df556  vmovaps xmm7, [rsp+0x60]
00007e97133df55c  vmovaps xmm8, [rsp+0x70]
00007e97133df562  vmovaps xmm9, [rsp+0x80]
00007e97133df56b  vmovaps xmm10, [rsp+0x90]
00007e97133df574  vmovaps xmm11, [rsp+0xA0]
00007e97133df57d  vmovaps xmm12, [rsp+0xB0]
00007e97133df586  vmovaps xmm13, [rsp+0xC0]
00007e97133df58f  vmovaps xmm14, [rsp+0xD0]
00007e97133df598  vmovaps xmm15, [rsp+0xE0]
00007e97133df5a1  add rsp, 0xF0
00007e97133df5a8  pop r11
00007e97133df5aa  pop r10
00007e97133df5ac  pop r9
00007e97133df5ae  pop r8
00007e97133df5b0  pop rsi
00007e97133df5b1  pop rdi
00007e97133df5b2  pop rdx
00007e97133df5b3  pop rcx
00007e97133df5b4  pop rax
00007e97133df5b5  add rsp, 0x08
00007e97133df5b9  jmp 0x00007E97133DC3D8
00007e97133df5be  sub rsp, 0x08
00007e97133df5c2  push rax
00007e97133df5c3  push rcx
00007e97133df5c4  push rdx
00007e97133df5c5  push rdi
00007e97133df5c6  push rsi
00007e97133df5c7  push r8
00007e97133df5c9  push r9
00007e97133df5cb  push r10
00007e97133df5cd  push r11
00007e97133df5cf  sub rsp, 0xF0
00007e97133df5d6  vmovaps [rsp], xmm0
00007e97133df5db  vmovaps [rsp+0x10], xmm1
00007e97133df5e1  vmovaps [rsp+0x20], xmm2
00007e97133df5e7  vmovaps [rsp+0x30], xmm3
00007e97133df5ed  vmovaps [rsp+0x40], xmm4
00007e97133df5f3  vmovaps [rsp+0x50], xmm5
00007e97133df5f9  vmovaps [rsp+0x60], xmm6
00007e97133df5ff  vmovaps [rsp+0x70], xmm7
00007e97133df605  vmovaps [rsp+0x80], xmm8
00007e97133df60e  vmovaps [rsp+0x90], xmm9
00007e97133df617  vmovaps [rsp+0xA0], xmm11
00007e97133df620  vmovaps [rsp+0xB0], xmm12
00007e97133df629  vmovaps [rsp+0xC0], xmm13
00007e97133df632  vmovaps [rsp+0xD0], xmm14
00007e97133df63b  vmovaps [rsp+0xE0], xmm15
00007e97133df644  sub rsp, 0x30
00007e97133df648  movaps [rsp], xmm10
00007e97133df64d  movaps [rsp+0x10], xmm8
00007e97133df653  movaps [rsp+0x20], xmm14
00007e97133df659  lea rdi, [rsp]
00007e97133df65d  mov esi, 0x00
00007e97133df662  mov rax, 0x58D8AED5F530
00007e97133df66c  call rax
00007e97133df66e  movaps xmm10, [rsp]
00007e97133df673  add rsp, 0x30
00007e97133df677  vmovaps xmm0, [rsp]
00007e97133df67c  vmovaps xmm1, [rsp+0x10]
00007e97133df682  vmovaps xmm2, [rsp+0x20]
00007e97133df688  vmovaps xmm3, [rsp+0x30]
00007e97133df68e  vmovaps xmm4, [rsp+0x40]
00007e97133df694  vmovaps xmm5, [rsp+0x50]
00007e97133df69a  vmovaps xmm6, [rsp+0x60]
00007e97133df6a0  vmovaps xmm7, [rsp+0x70]
00007e97133df6a6  vmovaps xmm8, [rsp+0x80]
00007e97133df6af  vmovaps xmm9, [rsp+0x90]
00007e97133df6b8  vmovaps xmm11, [rsp+0xA0]
00007e97133df6c1  vmovaps xmm12, [rsp+0xB0]
00007e97133df6ca  vmovaps xmm13, [rsp+0xC0]
00007e97133df6d3  vmovaps xmm14, [rsp+0xD0]
00007e97133df6dc  vmovaps xmm15, [rsp+0xE0]
00007e97133df6e5  add rsp, 0xF0
00007e97133df6ec  pop r11
00007e97133df6ee  pop r10
00007e97133df6f0  pop r9
00007e97133df6f2  pop r8
00007e97133df6f4  pop rsi
00007e97133df6f5  pop rdi
00007e97133df6f6  pop rdx
00007e97133df6f7  pop rcx
00007e97133df6f8  pop rax
00007e97133df6f9  add rsp, 0x08
00007e97133df6fd  jmp 0x00007E97133DC3F8
00007e97133df702  sub rsp, 0x08
00007e97133df706  push rax
00007e97133df707  push rcx
00007e97133df708  push rdx
00007e97133df709  push rdi
00007e97133df70a  push rsi
00007e97133df70b  push r8
00007e97133df70d  push r9
00007e97133df70f  push r10
00007e97133df711  push r11
00007e97133df713  sub rsp, 0xF0
00007e97133df71a  vmovaps [rsp], xmm0
00007e97133df71f  vmovaps [rsp+0x10], xmm1
00007e97133df725  vmovaps [rsp+0x20], xmm2
00007e97133df72b  vmovaps [rsp+0x30], xmm3
00007e97133df731  vmovaps [rsp+0x40], xmm4
00007e97133df737  vmovaps [rsp+0x50], xmm5
00007e97133df73d  vmovaps [rsp+0x60], xmm6
00007e97133df743  vmovaps [rsp+0x70], xmm7
00007e97133df749  vmovaps [rsp+0x80], xmm8
00007e97133df752  vmovaps [rsp+0x90], xmm9
00007e97133df75b  vmovaps [rsp+0xA0], xmm10
00007e97133df764  vmovaps [rsp+0xB0], xmm11
00007e97133df76d  vmovaps [rsp+0xC0], xmm12
00007e97133df776  vmovaps [rsp+0xD0], xmm13
00007e97133df77f  vmovaps [rsp+0xE0], xmm15
00007e97133df788  sub rsp, 0x30
00007e97133df78c  movaps [rsp], xmm14
00007e97133df791  movaps [rsp+0x10], xmm8
00007e97133df797  movaps [rsp+0x20], xmm4
00007e97133df79c  lea rdi, [rsp]
00007e97133df7a0  mov esi, 0x00
00007e97133df7a5  mov rax, 0x58D8AED5F530
00007e97133df7af  call rax
00007e97133df7b1  movaps xmm14, [rsp]
00007e97133df7b6  add rsp, 0x30
00007e97133df7ba  vmovaps xmm0, [rsp]
00007e97133df7bf  vmovaps xmm1, [rsp+0x10]
00007e97133df7c5  vmovaps xmm2, [rsp+0x20]
00007e97133df7cb  vmovaps xmm3, [rsp+0x30]
00007e97133df7d1  vmovaps xmm4, [rsp+0x40]
00007e97133df7d7  vmovaps xmm5, [rsp+0x50]
00007e97133df7dd  vmovaps xmm6, [rsp+0x60]
00007e97133df7e3  vmovaps xmm7, [rsp+0x70]
00007e97133df7e9  vmovaps xmm8, [rsp+0x80]
00007e97133df7f2  vmovaps xmm9, [rsp+0x90]
00007e97133df7fb  vmovaps xmm10, [rsp+0xA0]
00007e97133df804  vmovaps xmm11, [rsp+0xB0]
00007e97133df80d  vmovaps xmm12, [rsp+0xC0]
00007e97133df816  vmovaps xmm13, [rsp+0xD0]
00007e97133df81f  vmovaps xmm15, [rsp+0xE0]
00007e97133df828  add rsp, 0xF0
00007e97133df82f  pop r11
00007e97133df831  pop r10
00007e97133df833  pop r9
00007e97133df835  pop r8
00007e97133df837  pop rsi
00007e97133df838  pop rdi
00007e97133df839  pop rdx
00007e97133df83a  pop rcx
00007e97133df83b  pop rax
00007e97133df83c  add rsp, 0x08
00007e97133df840  jmp 0x00007E97133DC418
00007e97133df845  sub rsp, 0x08
00007e97133df849  push rax
00007e97133df84a  push rcx
00007e97133df84b  push rdx
00007e97133df84c  push rdi
00007e97133df84d  push rsi
00007e97133df84e  push r8
00007e97133df850  push r9
00007e97133df852  push r10
00007e97133df854  push r11
00007e97133df856  sub rsp, 0xF0
00007e97133df85d  vmovaps [rsp], xmm0
00007e97133df862  vmovaps [rsp+0x10], xmm1
00007e97133df868  vmovaps [rsp+0x20], xmm2
00007e97133df86e  vmovaps [rsp+0x30], xmm3
00007e97133df874  vmovaps [rsp+0x40], xmm5
00007e97133df87a  vmovaps [rsp+0x50], xmm6
00007e97133df880  vmovaps [rsp+0x60], xmm7
00007e97133df886  vmovaps [rsp+0x70], xmm8
00007e97133df88c  vmovaps [rsp+0x80], xmm9
00007e97133df895  vmovaps [rsp+0x90], xmm10
00007e97133df89e  vmovaps [rsp+0xA0], xmm11
00007e97133df8a7  vmovaps [rsp+0xB0], xmm12
00007e97133df8b0  vmovaps [rsp+0xC0], xmm13
00007e97133df8b9  vmovaps [rsp+0xD0], xmm14
00007e97133df8c2  vmovaps [rsp+0xE0], xmm15
00007e97133df8cb  sub rsp, 0x30
00007e97133df8cf  movaps [rsp], xmm4
00007e97133df8d3  movaps [rsp+0x10], xmm13
00007e97133df8d9  movaps [rsp+0x20], xmm8
00007e97133df8df  lea rdi, [rsp]
00007e97133df8e3  mov esi, 0x00
00007e97133df8e8  mov rax, 0x58D8AED5F530
00007e97133df8f2  call rax
00007e97133df8f4  movaps xmm4, [rsp]
00007e97133df8f8  add rsp, 0x30
00007e97133df8fc  vmovaps xmm0, [rsp]
00007e97133df901  vmovaps xmm1, [rsp+0x10]
00007e97133df907  vmovaps xmm2, [rsp+0x20]
00007e97133df90d  vmovaps xmm3, [rsp+0x30]
00007e97133df913  vmovaps xmm5, [rsp+0x40]
00007e97133df919  vmovaps xmm6, [rsp+0x50]
00007e97133df91f  vmovaps xmm7, [rsp+0x60]
00007e97133df925  vmovaps xmm8, [rsp+0x70]
00007e97133df92b  vmovaps xmm9, [rsp+0x80]
00007e97133df934  vmovaps xmm10, [rsp+0x90]
00007e97133df93d  vmovaps xmm11, [rsp+0xA0]
00007e97133df946  vmovaps xmm12, [rsp+0xB0]
00007e97133df94f  vmovaps xmm13, [rsp+0xC0]
00007e97133df958  vmovaps xmm14, [rsp+0xD0]
00007e97133df961  vmovaps xmm15, [rsp+0xE0]
00007e97133df96a  add rsp, 0xF0
00007e97133df971  pop r11
00007e97133df973  pop r10
00007e97133df975  pop r9
00007e97133df977  pop r8
00007e97133df979  pop rsi
00007e97133df97a  pop rdi
00007e97133df97b  pop rdx
00007e97133df97c  pop rcx
00007e97133df97d  pop rax
00007e97133df97e  add rsp, 0x08
00007e97133df982  jmp 0x00007E97133DC43D
00007e97133df987  sub rsp, 0x08
00007e97133df98b  push rax
00007e97133df98c  push rcx
00007e97133df98d  push rdx
00007e97133df98e  push rdi
00007e97133df98f  push rsi
00007e97133df990  push r8
00007e97133df992  push r9
00007e97133df994  push r10
00007e97133df996  push r11
00007e97133df998  sub rsp, 0xF0
00007e97133df99f  vmovaps [rsp], xmm0
00007e97133df9a4  vmovaps [rsp+0x10], xmm1
00007e97133df9aa  vmovaps [rsp+0x20], xmm2
00007e97133df9b0  vmovaps [rsp+0x30], xmm3
00007e97133df9b6  vmovaps [rsp+0x40], xmm4
00007e97133df9bc  vmovaps [rsp+0x50], xmm5
00007e97133df9c2  vmovaps [rsp+0x60], xmm6
00007e97133df9c8  vmovaps [rsp+0x70], xmm7
00007e97133df9ce  vmovaps [rsp+0x80], xmm8
00007e97133df9d7  vmovaps [rsp+0x90], xmm9
00007e97133df9e0  vmovaps [rsp+0xA0], xmm10
00007e97133df9e9  vmovaps [rsp+0xB0], xmm11
00007e97133df9f2  vmovaps [rsp+0xC0], xmm12
00007e97133df9fb  vmovaps [rsp+0xD0], xmm14
00007e97133dfa04  vmovaps [rsp+0xE0], xmm15
00007e97133dfa0d  sub rsp, 0x30
00007e97133dfa11  movaps [rsp], xmm13
00007e97133dfa16  movaps [rsp+0x10], xmm15
00007e97133dfa1c  movaps [rsp+0x20], xmm9
00007e97133dfa22  lea rdi, [rsp]
00007e97133dfa26  mov esi, 0x00
00007e97133dfa2b  mov rax, 0x58D8AED5F530
00007e97133dfa35  call rax
00007e97133dfa37  movaps xmm13, [rsp]
00007e97133dfa3c  add rsp, 0x30
00007e97133dfa40  vmovaps xmm0, [rsp]
00007e97133dfa45  vmovaps xmm1, [rsp+0x10]
00007e97133dfa4b  vmovaps xmm2, [rsp+0x20]
00007e97133dfa51  vmovaps xmm3, [rsp+0x30]
00007e97133dfa57  vmovaps xmm4, [rsp+0x40]
00007e97133dfa5d  vmovaps xmm5, [rsp+0x50]
00007e97133dfa63  vmovaps xmm6, [rsp+0x60]
00007e97133dfa69  vmovaps xmm7, [rsp+0x70]
00007e97133dfa6f  vmovaps xmm8, [rsp+0x80]
00007e97133dfa78  vmovaps xmm9, [rsp+0x90]
00007e97133dfa81  vmovaps xmm10, [rsp+0xA0]
00007e97133dfa8a  vmovaps xmm11, [rsp+0xB0]
00007e97133dfa93  vmovaps xmm12, [rsp+0xC0]
00007e97133dfa9c  vmovaps xmm14, [rsp+0xD0]
00007e97133dfaa5  vmovaps xmm15, [rsp+0xE0]
00007e97133dfaae  add rsp, 0xF0
00007e97133dfab5  pop r11
00007e97133dfab7  pop r10
00007e97133dfab9  pop r9
00007e97133dfabb  pop r8
00007e97133dfabd  pop rsi
00007e97133dfabe  pop rdi
00007e97133dfabf  pop rdx
00007e97133dfac0  pop rcx
00007e97133dfac1  pop rax
00007e97133dfac2  add rsp, 0x08
00007e97133dfac6  jmp 0x00007E97133DC458
00007e97133dfacb  sub rsp, 0x08
00007e97133dfacf  push rax
00007e97133dfad0  push rcx
00007e97133dfad1  push rdx
00007e97133dfad2  push rdi
00007e97133dfad3  push rsi
00007e97133dfad4  push r8
00007e97133dfad6  push r9
00007e97133dfad8  push r10
00007e97133dfada  push r11
00007e97133dfadc  sub rsp, 0xF0
00007e97133dfae3  vmovaps [rsp], xmm0
00007e97133dfae8  vmovaps [rsp+0x10], xmm1
00007e97133dfaee  vmovaps [rsp+0x20], xmm2
00007e97133dfaf4  vmovaps [rsp+0x30], xmm3
00007e97133dfafa  vmovaps [rsp+0x40], xmm4
00007e97133dfb00  vmovaps [rsp+0x50], xmm5
00007e97133dfb06  vmovaps [rsp+0x60], xmm6
00007e97133dfb0c  vmovaps [rsp+0x70], xmm7
00007e97133dfb12  vmovaps [rsp+0x80], xmm8
00007e97133dfb1b  vmovaps [rsp+0x90], xmm9
00007e97133dfb24  vmovaps [rsp+0xA0], xmm10
00007e97133dfb2d  vmovaps [rsp+0xB0], xmm11
00007e97133dfb36  vmovaps [rsp+0xC0], xmm12
00007e97133dfb3f  vmovaps [rsp+0xD0], xmm13
00007e97133dfb48  vmovaps [rsp+0xE0], xmm14
00007e97133dfb51  sub rsp, 0x30
00007e97133dfb55  movaps [rsp], xmm15
00007e97133dfb5a  movaps [rsp+0x10], xmm1
00007e97133dfb5f  movaps [rsp+0x20], xmm5
00007e97133dfb64  lea rdi, [rsp]
00007e97133dfb68  mov esi, 0x00
00007e97133dfb6d  mov rax, 0x58D8AED5F530
00007e97133dfb77  call rax
00007e97133dfb79  movaps xmm15, [rsp]
00007e97133dfb7e  add rsp, 0x30
00007e97133dfb82  vmovaps xmm0, [rsp]
00007e97133dfb87  vmovaps xmm1, [rsp+0x10]
00007e97133dfb8d  vmovaps xmm2, [rsp+0x20]
00007e97133dfb93  vmovaps xmm3, [rsp+0x30]
00007e97133dfb99  vmovaps xmm4, [rsp+0x40]
00007e97133dfb9f  vmovaps xmm5, [rsp+0x50]
00007e97133dfba5  vmovaps xmm6, [rsp+0x60]
00007e97133dfbab  vmovaps xmm7, [rsp+0x70]
00007e97133dfbb1  vmovaps xmm8, [rsp+0x80]
00007e97133dfbba  vmovaps xmm9, [rsp+0x90]
00007e97133dfbc3  vmovaps xmm10, [rsp+0xA0]
00007e97133dfbcc  vmovaps xmm11, [rsp+0xB0]
00007e97133dfbd5  vmovaps xmm12, [rsp+0xC0]
00007e97133dfbde  vmovaps xmm13, [rsp+0xD0]
00007e97133dfbe7  vmovaps xmm14, [rsp+0xE0]
00007e97133dfbf0  add rsp, 0xF0
00007e97133dfbf7  pop r11
00007e97133dfbf9  pop r10
00007e97133dfbfb  pop r9
00007e97133dfbfd  pop r8
00007e97133dfbff  pop rsi
00007e97133dfc00  pop rdi
00007e97133dfc01  pop rdx
00007e97133dfc02  pop rcx
00007e97133dfc03  pop rax
00007e97133dfc04  add rsp, 0x08
00007e97133dfc08  jmp 0x00007E97133DC473
00007e97133dfc0d  call 0x00007E97132B52F0
00007e97133dfc12  jmp 0x00007E97133DC4CE
00007e97133dfc17  sub rsp, 0x08
00007e97133dfc1b  push rax
00007e97133dfc1c  push rcx
00007e97133dfc1d  push rdx
00007e97133dfc1e  push rdi
00007e97133dfc1f  push rsi
00007e97133dfc20  push r8
00007e97133dfc22  push r9
00007e97133dfc24  push r10
00007e97133dfc26  push r11
00007e97133dfc28  sub rsp, 0xF0
00007e97133dfc2f  vmovaps [rsp], xmm0
00007e97133dfc34  vmovaps [rsp+0x10], xmm1
00007e97133dfc3a  vmovaps [rsp+0x20], xmm2
00007e97133dfc40  vmovaps [rsp+0x30], xmm3
00007e97133dfc46  vmovaps [rsp+0x40], xmm4
00007e97133dfc4c  vmovaps [rsp+0x50], xmm5
00007e97133dfc52  vmovaps [rsp+0x60], xmm6
00007e97133dfc58  vmovaps [rsp+0x70], xmm7
00007e97133dfc5e  vmovaps [rsp+0x80], xmm8
00007e97133dfc67  vmovaps [rsp+0x90], xmm10
00007e97133dfc70  vmovaps [rsp+0xA0], xmm11
00007e97133dfc79  vmovaps [rsp+0xB0], xmm12
00007e97133dfc82  vmovaps [rsp+0xC0], xmm13
00007e97133dfc8b  vmovaps [rsp+0xD0], xmm14
00007e97133dfc94  vmovaps [rsp+0xE0], xmm15
00007e97133dfc9d  sub rsp, 0x30
00007e97133dfca1  movaps [rsp], xmm9
00007e97133dfca6  movaps [rsp+0x10], xmm8
00007e97133dfcac  movaps [rsp+0x20], xmm11
00007e97133dfcb2  lea rdi, [rsp]
00007e97133dfcb6  mov esi, 0x00
00007e97133dfcbb  mov rax, 0x58D8AED5F530
00007e97133dfcc5  call rax
00007e97133dfcc7  movaps xmm9, [rsp]
00007e97133dfccc  add rsp, 0x30
00007e97133dfcd0  vmovaps xmm0, [rsp]
00007e97133dfcd5  vmovaps xmm1, [rsp+0x10]
00007e97133dfcdb  vmovaps xmm2, [rsp+0x20]
00007e97133dfce1  vmovaps xmm3, [rsp+0x30]
00007e97133dfce7  vmovaps xmm4, [rsp+0x40]
00007e97133dfced  vmovaps xmm5, [rsp+0x50]
00007e97133dfcf3  vmovaps xmm6, [rsp+0x60]
00007e97133dfcf9  vmovaps xmm7, [rsp+0x70]
00007e97133dfcff  vmovaps xmm8, [rsp+0x80]
00007e97133dfd08  vmovaps xmm10, [rsp+0x90]
00007e97133dfd11  vmovaps xmm11, [rsp+0xA0]
00007e97133dfd1a  vmovaps xmm12, [rsp+0xB0]
00007e97133dfd23  vmovaps xmm13, [rsp+0xC0]
00007e97133dfd2c  vmovaps xmm14, [rsp+0xD0]
00007e97133dfd35  vmovaps xmm15, [rsp+0xE0]
00007e97133dfd3e  add rsp, 0xF0
00007e97133dfd45  pop r11
00007e97133dfd47  pop r10
00007e97133dfd49  pop r9
00007e97133dfd4b  pop r8
00007e97133dfd4d  pop rsi
00007e97133dfd4e  pop rdi
00007e97133dfd4f  pop rdx
00007e97133dfd50  pop rcx
00007e97133dfd51  pop rax
00007e97133dfd52  add rsp, 0x08
00007e97133dfd56  jmp 0x00007E97133DC505
00007e97133dfd5b  sub rsp, 0x08
00007e97133dfd5f  push rax
00007e97133dfd60  push rcx
00007e97133dfd61  push rdx
00007e97133dfd62  push rdi
00007e97133dfd63  push rsi
00007e97133dfd64  push r8
00007e97133dfd66  push r9
00007e97133dfd68  push r10
00007e97133dfd6a  push r11
00007e97133dfd6c  sub rsp, 0xF0
00007e97133dfd73  vmovaps [rsp], xmm0
00007e97133dfd78  vmovaps [rsp+0x10], xmm1
00007e97133dfd7e  vmovaps [rsp+0x20], xmm2
00007e97133dfd84  vmovaps [rsp+0x30], xmm3
00007e97133dfd8a  vmovaps [rsp+0x40], xmm4
00007e97133dfd90  vmovaps [rsp+0x50], xmm5
00007e97133dfd96  vmovaps [rsp+0x60], xmm6
00007e97133dfd9c  vmovaps [rsp+0x70], xmm7
00007e97133dfda2  vmovaps [rsp+0x80], xmm8
00007e97133dfdab  vmovaps [rsp+0x90], xmm9
00007e97133dfdb4  vmovaps [rsp+0xA0], xmm10
00007e97133dfdbd  vmovaps [rsp+0xB0], xmm12
00007e97133dfdc6  vmovaps [rsp+0xC0], xmm13
00007e97133dfdcf  vmovaps [rsp+0xD0], xmm14
00007e97133dfdd8  vmovaps [rsp+0xE0], xmm15
00007e97133dfde1  sub rsp, 0x30
00007e97133dfde5  movaps [rsp], xmm11
00007e97133dfdea  movaps [rsp+0x10], xmm10
00007e97133dfdf0  movaps [rsp+0x20], xmm6
00007e97133dfdf5  lea rdi, [rsp]
00007e97133dfdf9  mov esi, 0x00
00007e97133dfdfe  mov rax, 0x58D8AED5F530
00007e97133dfe08  call rax
00007e97133dfe0a  movaps xmm11, [rsp]
00007e97133dfe0f  add rsp, 0x30
00007e97133dfe13  vmovaps xmm0, [rsp]
00007e97133dfe18  vmovaps xmm1, [rsp+0x10]
00007e97133dfe1e  vmovaps xmm2, [rsp+0x20]
00007e97133dfe24  vmovaps xmm3, [rsp+0x30]
00007e97133dfe2a  vmovaps xmm4, [rsp+0x40]
00007e97133dfe30  vmovaps xmm5, [rsp+0x50]
00007e97133dfe36  vmovaps xmm6, [rsp+0x60]
00007e97133dfe3c  vmovaps xmm7, [rsp+0x70]
00007e97133dfe42  vmovaps xmm8, [rsp+0x80]
00007e97133dfe4b  vmovaps xmm9, [rsp+0x90]
00007e97133dfe54  vmovaps xmm10, [rsp+0xA0]
00007e97133dfe5d  vmovaps xmm12, [rsp+0xB0]
00007e97133dfe66  vmovaps xmm13, [rsp+0xC0]
00007e97133dfe6f  vmovaps xmm14, [rsp+0xD0]
00007e97133dfe78  vmovaps xmm15, [rsp+0xE0]
00007e97133dfe81  add rsp, 0xF0
00007e97133dfe88  pop r11
00007e97133dfe8a  pop r10
00007e97133dfe8c  pop r9
00007e97133dfe8e  pop r8
00007e97133dfe90  pop rsi
00007e97133dfe91  pop rdi
00007e97133dfe92  pop rdx
00007e97133dfe93  pop rcx
00007e97133dfe94  pop rax
00007e97133dfe95  add rsp, 0x08
00007e97133dfe99  jmp 0x00007E97133DC520
00007e97133dfe9e  sub rsp, 0x08
00007e97133dfea2  push rax
00007e97133dfea3  push rcx
00007e97133dfea4  push rdx
00007e97133dfea5  push rdi
00007e97133dfea6  push rsi
00007e97133dfea7  push r8
00007e97133dfea9  push r9
00007e97133dfeab  push r10
00007e97133dfead  push r11
00007e97133dfeaf  sub rsp, 0xF0
00007e97133dfeb6  vmovaps [rsp], xmm0
00007e97133dfebb  vmovaps [rsp+0x10], xmm1
00007e97133dfec1  vmovaps [rsp+0x20], xmm2
00007e97133dfec7  vmovaps [rsp+0x30], xmm3
00007e97133dfecd  vmovaps [rsp+0x40], xmm4
00007e97133dfed3  vmovaps [rsp+0x50], xmm5
00007e97133dfed9  vmovaps [rsp+0x60], xmm6
00007e97133dfedf  vmovaps [rsp+0x70], xmm7
00007e97133dfee5  vmovaps [rsp+0x80], xmm8
00007e97133dfeee  vmovaps [rsp+0x90], xmm9
00007e97133dfef7  vmovaps [rsp+0xA0], xmm11
00007e97133dff00  vmovaps [rsp+0xB0], xmm12
00007e97133dff09  vmovaps [rsp+0xC0], xmm13
00007e97133dff12  vmovaps [rsp+0xD0], xmm14
00007e97133dff1b  vmovaps [rsp+0xE0], xmm15
00007e97133dff24  sub rsp, 0x30
00007e97133dff28  movaps [rsp], xmm10
00007e97133dff2d  movaps [rsp+0x10], xmm14
00007e97133dff33  movaps [rsp+0x20], xmm4
00007e97133dff38  lea rdi, [rsp]
00007e97133dff3c  mov esi, 0x00
00007e97133dff41  mov rax, 0x58D8AED5F530
00007e97133dff4b  call rax
00007e97133dff4d  movaps xmm10, [rsp]
00007e97133dff52  add rsp, 0x30
00007e97133dff56  vmovaps xmm0, [rsp]
00007e97133dff5b  vmovaps xmm1, [rsp+0x10]
00007e97133dff61  vmovaps xmm2, [rsp+0x20]
00007e97133dff67  vmovaps xmm3, [rsp+0x30]
00007e97133dff6d  vmovaps xmm4, [rsp+0x40]
00007e97133dff73  vmovaps xmm5, [rsp+0x50]
00007e97133dff79  vmovaps xmm6, [rsp+0x60]
00007e97133dff7f  vmovaps xmm7, [rsp+0x70]
00007e97133dff85  vmovaps xmm8, [rsp+0x80]
00007e97133dff8e  vmovaps xmm9, [rsp+0x90]
00007e97133dff97  vmovaps xmm11, [rsp+0xA0]
00007e97133dffa0  vmovaps xmm12, [rsp+0xB0]
00007e97133dffa9  vmovaps xmm13, [rsp+0xC0]
00007e97133dffb2  vmovaps xmm14, [rsp+0xD0]
00007e97133dffbb  vmovaps xmm15, [rsp+0xE0]
00007e97133dffc4  add rsp, 0xF0
00007e97133dffcb  pop r11
00007e97133dffcd  pop r10
00007e97133dffcf  pop r9
00007e97133dffd1  pop r8
00007e97133dffd3  pop rsi
00007e97133dffd4  pop rdi
00007e97133dffd5  pop rdx
00007e97133dffd6  pop rcx
00007e97133dffd7  pop rax
00007e97133dffd8  add rsp, 0x08
00007e97133dffdc  jmp 0x00007E97133DC53B
00007e97133dffe1  sub rsp, 0x08
00007e97133dffe5  push rax
00007e97133dffe6  push rcx
00007e97133dffe7  push rdx
00007e97133dffe8  push rdi
00007e97133dffe9  push rsi
00007e97133dffea  push r8
00007e97133dffec  push r9
00007e97133dffee  push r10
00007e97133dfff0  push r11
00007e97133dfff2  sub rsp, 0xF0
00007e97133dfff9  vmovaps [rsp], xmm0
00007e97133dfffe  vmovaps [rsp+0x10], xmm1
00007e97133e0004  vmovaps [rsp+0x20], xmm2
00007e97133e000a  vmovaps [rsp+0x30], xmm3
00007e97133e0010  vmovaps [rsp+0x40], xmm4
00007e97133e0016  vmovaps [rsp+0x50], xmm5
00007e97133e001c  vmovaps [rsp+0x60], xmm6
00007e97133e0022  vmovaps [rsp+0x70], xmm7
00007e97133e0028  vmovaps [rsp+0x80], xmm9
00007e97133e0031  vmovaps [rsp+0x90], xmm10
00007e97133e003a  vmovaps [rsp+0xA0], xmm11
00007e97133e0043  vmovaps [rsp+0xB0], xmm12
00007e97133e004c  vmovaps [rsp+0xC0], xmm13
00007e97133e0055  vmovaps [rsp+0xD0], xmm14
00007e97133e005e  vmovaps [rsp+0xE0], xmm15
00007e97133e0067  sub rsp, 0x30
00007e97133e006b  movaps [rsp], xmm8
00007e97133e0070  movaps [rsp+0x10], xmm1
00007e97133e0075  movaps [rsp+0x20], xmm14
00007e97133e007b  lea rdi, [rsp]
00007e97133e007f  mov esi, 0x00
00007e97133e0084  mov rax, 0x58D8AED5F530
00007e97133e008e  call rax
00007e97133e0090  movaps xmm8, [rsp]
00007e97133e0095  add rsp, 0x30
00007e97133e0099  vmovaps xmm0, [rsp]
00007e97133e009e  vmovaps xmm1, [rsp+0x10]
00007e97133e00a4  vmovaps xmm2, [rsp+0x20]
00007e97133e00aa  vmovaps xmm3, [rsp+0x30]
00007e97133e00b0  vmovaps xmm4, [rsp+0x40]
00007e97133e00b6  vmovaps xmm5, [rsp+0x50]
00007e97133e00bc  vmovaps xmm6, [rsp+0x60]
00007e97133e00c2  vmovaps xmm7, [rsp+0x70]
00007e97133e00c8  vmovaps xmm9, [rsp+0x80]
00007e97133e00d1  vmovaps xmm10, [rsp+0x90]
00007e97133e00da  vmovaps xmm11, [rsp+0xA0]
00007e97133e00e3  vmovaps xmm12, [rsp+0xB0]
00007e97133e00ec  vmovaps xmm13, [rsp+0xC0]
00007e97133e00f5  vmovaps xmm14, [rsp+0xD0]
00007e97133e00fe  vmovaps xmm15, [rsp+0xE0]
00007e97133e0107  add rsp, 0xF0
00007e97133e010e  pop r11
00007e97133e0110  pop r10
00007e97133e0112  pop r9
00007e97133e0114  pop r8
00007e97133e0116  pop rsi
00007e97133e0117  pop rdi
00007e97133e0118  pop rdx
00007e97133e0119  pop rcx
00007e97133e011a  pop rax
00007e97133e011b  add rsp, 0x08
00007e97133e011f  jmp 0x00007E97133DC561
00007e97133e0124  sub rsp, 0x08
00007e97133e0128  push rax
00007e97133e0129  push rcx
00007e97133e012a  push rdx
00007e97133e012b  push rdi
00007e97133e012c  push rsi
00007e97133e012d  push r8
00007e97133e012f  push r9
00007e97133e0131  push r10
00007e97133e0133  push r11
00007e97133e0135  sub rsp, 0xF0
00007e97133e013c  vmovaps [rsp], xmm0
00007e97133e0141  vmovaps [rsp+0x10], xmm1
00007e97133e0147  vmovaps [rsp+0x20], xmm2
00007e97133e014d  vmovaps [rsp+0x30], xmm3
00007e97133e0153  vmovaps [rsp+0x40], xmm4
00007e97133e0159  vmovaps [rsp+0x50], xmm5
00007e97133e015f  vmovaps [rsp+0x60], xmm7
00007e97133e0165  vmovaps [rsp+0x70], xmm8
00007e97133e016b  vmovaps [rsp+0x80], xmm9
00007e97133e0174  vmovaps [rsp+0x90], xmm10
00007e97133e017d  vmovaps [rsp+0xA0], xmm11
00007e97133e0186  vmovaps [rsp+0xB0], xmm12
00007e97133e018f  vmovaps [rsp+0xC0], xmm13
00007e97133e0198  vmovaps [rsp+0xD0], xmm14
00007e97133e01a1  vmovaps [rsp+0xE0], xmm15
00007e97133e01aa  sub rsp, 0x30
00007e97133e01ae  movaps [rsp], xmm6
00007e97133e01b2  movaps [rsp+0x10], xmm1
00007e97133e01b7  movaps [rsp+0x20], xmm14
00007e97133e01bd  lea rdi, [rsp]
00007e97133e01c1  mov esi, 0x00
00007e97133e01c6  mov rax, 0x58D8AED5F530
00007e97133e01d0  call rax
00007e97133e01d2  movaps xmm6, [rsp]
00007e97133e01d6  add rsp, 0x30
00007e97133e01da  vmovaps xmm0, [rsp]
00007e97133e01df  vmovaps xmm1, [rsp+0x10]
00007e97133e01e5  vmovaps xmm2, [rsp+0x20]
00007e97133e01eb  vmovaps xmm3, [rsp+0x30]
00007e97133e01f1  vmovaps xmm4, [rsp+0x40]
00007e97133e01f7  vmovaps xmm5, [rsp+0x50]
00007e97133e01fd  vmovaps xmm7, [rsp+0x60]
00007e97133e0203  vmovaps xmm8, [rsp+0x70]
00007e97133e0209  vmovaps xmm9, [rsp+0x80]
00007e97133e0212  vmovaps xmm10, [rsp+0x90]
00007e97133e021b  vmovaps xmm11, [rsp+0xA0]
00007e97133e0224  vmovaps xmm12, [rsp+0xB0]
00007e97133e022d  vmovaps xmm13, [rsp+0xC0]
00007e97133e0236  vmovaps xmm14, [rsp+0xD0]
00007e97133e023f  vmovaps xmm15, [rsp+0xE0]
00007e97133e0248  add rsp, 0xF0
00007e97133e024f  pop r11
00007e97133e0251  pop r10
00007e97133e0253  pop r9
00007e97133e0255  pop r8
00007e97133e0257  pop rsi
00007e97133e0258  pop rdi
00007e97133e0259  pop rdx
00007e97133e025a  pop rcx
00007e97133e025b  pop rax
00007e97133e025c  add rsp, 0x08
00007e97133e0260  jmp 0x00007E97133DC58D
00007e97133e0265  sub rsp, 0x08
00007e97133e0269  push rax
00007e97133e026a  push rcx
00007e97133e026b  push rdx
00007e97133e026c  push rdi
00007e97133e026d  push rsi
00007e97133e026e  push r8
00007e97133e0270  push r9
00007e97133e0272  push r10
00007e97133e0274  push r11
00007e97133e0276  sub rsp, 0xF0
00007e97133e027d  vmovaps [rsp], xmm0
00007e97133e0282  vmovaps [rsp+0x10], xmm1
00007e97133e0288  vmovaps [rsp+0x20], xmm2
00007e97133e028e  vmovaps [rsp+0x30], xmm3
00007e97133e0294  vmovaps [rsp+0x40], xmm4
00007e97133e029a  vmovaps [rsp+0x50], xmm5
00007e97133e02a0  vmovaps [rsp+0x60], xmm6
00007e97133e02a6  vmovaps [rsp+0x70], xmm7
00007e97133e02ac  vmovaps [rsp+0x80], xmm8
00007e97133e02b5  vmovaps [rsp+0x90], xmm9
00007e97133e02be  vmovaps [rsp+0xA0], xmm10
00007e97133e02c7  vmovaps [rsp+0xB0], xmm11
00007e97133e02d0  vmovaps [rsp+0xC0], xmm12
00007e97133e02d9  vmovaps [rsp+0xD0], xmm13
00007e97133e02e2  vmovaps [rsp+0xE0], xmm15
00007e97133e02eb  sub rsp, 0x30
00007e97133e02ef  movaps [rsp], xmm14
00007e97133e02f4  movaps [rsp+0x10], xmm12
00007e97133e02fa  movaps [rsp+0x20], xmm1
00007e97133e02ff  lea rdi, [rsp]
00007e97133e0303  mov esi, 0x00
00007e97133e0308  mov rax, 0x58D8AED5F530
00007e97133e0312  call rax
00007e97133e0314  movaps xmm14, [rsp]
00007e97133e0319  add rsp, 0x30
00007e97133e031d  vmovaps xmm0, [rsp]
00007e97133e0322  vmovaps xmm1, [rsp+0x10]
00007e97133e0328  vmovaps xmm2, [rsp+0x20]
00007e97133e032e  vmovaps xmm3, [rsp+0x30]
00007e97133e0334  vmovaps xmm4, [rsp+0x40]
00007e97133e033a  vmovaps xmm5, [rsp+0x50]
00007e97133e0340  vmovaps xmm6, [rsp+0x60]
00007e97133e0346  vmovaps xmm7, [rsp+0x70]
00007e97133e034c  vmovaps xmm8, [rsp+0x80]
00007e97133e0355  vmovaps xmm9, [rsp+0x90]
00007e97133e035e  vmovaps xmm10, [rsp+0xA0]
00007e97133e0367  vmovaps xmm11, [rsp+0xB0]
00007e97133e0370  vmovaps xmm12, [rsp+0xC0]
00007e97133e0379  vmovaps xmm13, [rsp+0xD0]
00007e97133e0382  vmovaps xmm15, [rsp+0xE0]
00007e97133e038b  add rsp, 0xF0
00007e97133e0392  pop r11
00007e97133e0394  pop r10
00007e97133e0396  pop r9
00007e97133e0398  pop r8
00007e97133e039a  pop rsi
00007e97133e039b  pop rdi
00007e97133e039c  pop rdx
00007e97133e039d  pop rcx
00007e97133e039e  pop rax
00007e97133e039f  add rsp, 0x08
00007e97133e03a3  jmp 0x00007E97133DC5B3
00007e97133e03a8  sub rsp, 0x08
00007e97133e03ac  push rax
00007e97133e03ad  push rcx
00007e97133e03ae  push rdx
00007e97133e03af  push rdi
00007e97133e03b0  push rsi
00007e97133e03b1  push r8
00007e97133e03b3  push r9
00007e97133e03b5  push r10
00007e97133e03b7  push r11
00007e97133e03b9  sub rsp, 0xF0
00007e97133e03c0  vmovaps [rsp], xmm0
00007e97133e03c5  vmovaps [rsp+0x10], xmm2
00007e97133e03cb  vmovaps [rsp+0x20], xmm3
00007e97133e03d1  vmovaps [rsp+0x30], xmm4
00007e97133e03d7  vmovaps [rsp+0x40], xmm5
00007e97133e03dd  vmovaps [rsp+0x50], xmm6
00007e97133e03e3  vmovaps [rsp+0x60], xmm7
00007e97133e03e9  vmovaps [rsp+0x70], xmm8
00007e97133e03ef  vmovaps [rsp+0x80], xmm9
00007e97133e03f8  vmovaps [rsp+0x90], xmm10
00007e97133e0401  vmovaps [rsp+0xA0], xmm11
00007e97133e040a  vmovaps [rsp+0xB0], xmm12
00007e97133e0413  vmovaps [rsp+0xC0], xmm13
00007e97133e041c  vmovaps [rsp+0xD0], xmm14
00007e97133e0425  vmovaps [rsp+0xE0], xmm15
00007e97133e042e  sub rsp, 0x30
00007e97133e0432  movaps [rsp], xmm1
00007e97133e0436  movaps [rsp+0x10], xmm13
00007e97133e043c  movaps [rsp+0x20], xmm9
00007e97133e0442  lea rdi, [rsp]
00007e97133e0446  mov esi, 0x00
00007e97133e044b  mov rax, 0x58D8AED5F530
00007e97133e0455  call rax
00007e97133e0457  movaps xmm1, [rsp]
00007e97133e045b  add rsp, 0x30
00007e97133e045f  vmovaps xmm0, [rsp]
00007e97133e0464  vmovaps xmm2, [rsp+0x10]
00007e97133e046a  vmovaps xmm3, [rsp+0x20]
00007e97133e0470  vmovaps xmm4, [rsp+0x30]
00007e97133e0476  vmovaps xmm5, [rsp+0x40]
00007e97133e047c  vmovaps xmm6, [rsp+0x50]
00007e97133e0482  vmovaps xmm7, [rsp+0x60]
00007e97133e0488  vmovaps xmm8, [rsp+0x70]
00007e97133e048e  vmovaps xmm9, [rsp+0x80]
00007e97133e0497  vmovaps xmm10, [rsp+0x90]
00007e97133e04a0  vmovaps xmm11, [rsp+0xA0]
00007e97133e04a9  vmovaps xmm12, [rsp+0xB0]
00007e97133e04b2  vmovaps xmm13, [rsp+0xC0]
00007e97133e04bb  vmovaps xmm14, [rsp+0xD0]
00007e97133e04c4  vmovaps xmm15, [rsp+0xE0]
00007e97133e04cd  add rsp, 0xF0
00007e97133e04d4  pop r11
00007e97133e04d6  pop r10
00007e97133e04d8  pop r9
00007e97133e04da  pop r8
00007e97133e04dc  pop rsi
00007e97133e04dd  pop rdi
00007e97133e04de  pop rdx
00007e97133e04df  pop rcx
00007e97133e04e0  pop rax
00007e97133e04e1  add rsp, 0x08
00007e97133e04e5  jmp 0x00007E97133DC5CD
00007e97133e04ea  sub rsp, 0x08
00007e97133e04ee  push rax
00007e97133e04ef  push rcx
00007e97133e04f0  push rdx
00007e97133e04f1  push rdi
00007e97133e04f2  push rsi
00007e97133e04f3  push r8
00007e97133e04f5  push r9
00007e97133e04f7  push r10
00007e97133e04f9  push r11
00007e97133e04fb  sub rsp, 0xF0
00007e97133e0502  vmovaps [rsp], xmm0
00007e97133e0507  vmovaps [rsp+0x10], xmm1
00007e97133e050d  vmovaps [rsp+0x20], xmm2
00007e97133e0513  vmovaps [rsp+0x30], xmm3
00007e97133e0519  vmovaps [rsp+0x40], xmm4
00007e97133e051f  vmovaps [rsp+0x50], xmm5
00007e97133e0525  vmovaps [rsp+0x60], xmm6
00007e97133e052b  vmovaps [rsp+0x70], xmm7
00007e97133e0531  vmovaps [rsp+0x80], xmm8
00007e97133e053a  vmovaps [rsp+0x90], xmm9
00007e97133e0543  vmovaps [rsp+0xA0], xmm10
00007e97133e054c  vmovaps [rsp+0xB0], xmm11
00007e97133e0555  vmovaps [rsp+0xC0], xmm13
00007e97133e055e  vmovaps [rsp+0xD0], xmm14
00007e97133e0567  vmovaps [rsp+0xE0], xmm15
00007e97133e0570  sub rsp, 0x30
00007e97133e0574  movaps [rsp], xmm12
00007e97133e0579  movaps [rsp+0x10], xmm7
00007e97133e057e  movaps [rsp+0x20], xmm13
00007e97133e0584  lea rdi, [rsp]
00007e97133e0588  mov esi, 0x00
00007e97133e058d  mov rax, 0x58D8AED5F530
00007e97133e0597  call rax
00007e97133e0599  movaps xmm12, [rsp]
00007e97133e059e  add rsp, 0x30
00007e97133e05a2  vmovaps xmm0, [rsp]
00007e97133e05a7  vmovaps xmm1, [rsp+0x10]
00007e97133e05ad  vmovaps xmm2, [rsp+0x20]
00007e97133e05b3  vmovaps xmm3, [rsp+0x30]
00007e97133e05b9  vmovaps xmm4, [rsp+0x40]
00007e97133e05bf  vmovaps xmm5, [rsp+0x50]
00007e97133e05c5  vmovaps xmm6, [rsp+0x60]
00007e97133e05cb  vmovaps xmm7, [rsp+0x70]
00007e97133e05d1  vmovaps xmm8, [rsp+0x80]
00007e97133e05da  vmovaps xmm9, [rsp+0x90]
00007e97133e05e3  vmovaps xmm10, [rsp+0xA0]
00007e97133e05ec  vmovaps xmm11, [rsp+0xB0]
00007e97133e05f5  vmovaps xmm13, [rsp+0xC0]
00007e97133e05fe  vmovaps xmm14, [rsp+0xD0]
00007e97133e0607  vmovaps xmm15, [rsp+0xE0]
00007e97133e0610  add rsp, 0xF0
00007e97133e0617  pop r11
00007e97133e0619  pop r10
00007e97133e061b  pop r9
00007e97133e061d  pop r8
00007e97133e061f  pop rsi
00007e97133e0620  pop rdi
00007e97133e0621  pop rdx
00007e97133e0622  pop rcx
00007e97133e0623  pop rax
00007e97133e0624  add rsp, 0x08
00007e97133e0628  jmp 0x00007E97133DC5F4
00007e97133e062d  sub rsp, 0x08
00007e97133e0631  push rax
00007e97133e0632  push rcx
00007e97133e0633  push rdx
00007e97133e0634  push rdi
00007e97133e0635  push rsi
00007e97133e0636  push r8
00007e97133e0638  push r9
00007e97133e063a  push r10
00007e97133e063c  push r11
00007e97133e063e  sub rsp, 0xF0
00007e97133e0645  vmovaps [rsp], xmm0
00007e97133e064a  vmovaps [rsp+0x10], xmm1
00007e97133e0650  vmovaps [rsp+0x20], xmm2
00007e97133e0656  vmovaps [rsp+0x30], xmm3
00007e97133e065c  vmovaps [rsp+0x40], xmm4
00007e97133e0662  vmovaps [rsp+0x50], xmm5
00007e97133e0668  vmovaps [rsp+0x60], xmm6
00007e97133e066e  vmovaps [rsp+0x70], xmm7
00007e97133e0674  vmovaps [rsp+0x80], xmm8
00007e97133e067d  vmovaps [rsp+0x90], xmm9
00007e97133e0686  vmovaps [rsp+0xA0], xmm10
00007e97133e068f  vmovaps [rsp+0xB0], xmm11
00007e97133e0698  vmovaps [rsp+0xC0], xmm12
00007e97133e06a1  vmovaps [rsp+0xD0], xmm14
00007e97133e06aa  vmovaps [rsp+0xE0], xmm15
00007e97133e06b3  sub rsp, 0x30
00007e97133e06b7  movaps [rsp], xmm13
00007e97133e06bc  movaps [rsp+0x10], xmm15
00007e97133e06c2  movaps [rsp+0x20], xmm8
00007e97133e06c8  lea rdi, [rsp]
00007e97133e06cc  mov esi, 0x00
00007e97133e06d1  mov rax, 0x58D8AED5F530
00007e97133e06db  call rax
00007e97133e06dd  movaps xmm13, [rsp]
00007e97133e06e2  add rsp, 0x30
00007e97133e06e6  vmovaps xmm0, [rsp]
00007e97133e06eb  vmovaps xmm1, [rsp+0x10]
00007e97133e06f1  vmovaps xmm2, [rsp+0x20]
00007e97133e06f7  vmovaps xmm3, [rsp+0x30]
00007e97133e06fd  vmovaps xmm4, [rsp+0x40]
00007e97133e0703  vmovaps xmm5, [rsp+0x50]
00007e97133e0709  vmovaps xmm6, [rsp+0x60]
00007e97133e070f  vmovaps xmm7, [rsp+0x70]
00007e97133e0715  vmovaps xmm8, [rsp+0x80]
00007e97133e071e  vmovaps xmm9, [rsp+0x90]
00007e97133e0727  vmovaps xmm10, [rsp+0xA0]
00007e97133e0730  vmovaps xmm11, [rsp+0xB0]
00007e97133e0739  vmovaps xmm12, [rsp+0xC0]
00007e97133e0742  vmovaps xmm14, [rsp+0xD0]
00007e97133e074b  vmovaps xmm15, [rsp+0xE0]
00007e97133e0754  add rsp, 0xF0
00007e97133e075b  pop r11
00007e97133e075d  pop r10
00007e97133e075f  pop r9
00007e97133e0761  pop r8
00007e97133e0763  pop rsi
00007e97133e0764  pop rdi
00007e97133e0765  pop rdx
00007e97133e0766  pop rcx
00007e97133e0767  pop rax
00007e97133e0768  add rsp, 0x08
00007e97133e076c  jmp 0x00007E97133DC60F
00007e97133e0771  sub rsp, 0x08
00007e97133e0775  push rax
00007e97133e0776  push rcx
00007e97133e0777  push rdx
00007e97133e0778  push rdi
00007e97133e0779  push rsi
00007e97133e077a  push r8
00007e97133e077c  push r9
00007e97133e077e  push r10
00007e97133e0780  push r11
00007e97133e0782  sub rsp, 0xF0
00007e97133e0789  vmovaps [rsp], xmm0
00007e97133e078e  vmovaps [rsp+0x10], xmm1
00007e97133e0794  vmovaps [rsp+0x20], xmm2
00007e97133e079a  vmovaps [rsp+0x30], xmm3
00007e97133e07a0  vmovaps [rsp+0x40], xmm4
00007e97133e07a6  vmovaps [rsp+0x50], xmm5
00007e97133e07ac  vmovaps [rsp+0x60], xmm6
00007e97133e07b2  vmovaps [rsp+0x70], xmm7
00007e97133e07b8  vmovaps [rsp+0x80], xmm9
00007e97133e07c1  vmovaps [rsp+0x90], xmm10
00007e97133e07ca  vmovaps [rsp+0xA0], xmm11
00007e97133e07d3  vmovaps [rsp+0xB0], xmm12
00007e97133e07dc  vmovaps [rsp+0xC0], xmm13
00007e97133e07e5  vmovaps [rsp+0xD0], xmm14
00007e97133e07ee  vmovaps [rsp+0xE0], xmm15
00007e97133e07f7  sub rsp, 0x30
00007e97133e07fb  movaps [rsp], xmm8
00007e97133e0800  movaps [rsp+0x10], xmm15
00007e97133e0806  movaps [rsp+0x20], xmm9
00007e97133e080c  lea rdi, [rsp]
00007e97133e0810  mov esi, 0x00
00007e97133e0815  mov rax, 0x58D8AED5F530
00007e97133e081f  call rax
00007e97133e0821  movaps xmm8, [rsp]
00007e97133e0826  add rsp, 0x30
00007e97133e082a  vmovaps xmm0, [rsp]
00007e97133e082f  vmovaps xmm1, [rsp+0x10]
00007e97133e0835  vmovaps xmm2, [rsp+0x20]
00007e97133e083b  vmovaps xmm3, [rsp+0x30]
00007e97133e0841  vmovaps xmm4, [rsp+0x40]
00007e97133e0847  vmovaps xmm5, [rsp+0x50]
00007e97133e084d  vmovaps xmm6, [rsp+0x60]
00007e97133e0853  vmovaps xmm7, [rsp+0x70]
00007e97133e0859  vmovaps xmm9, [rsp+0x80]
00007e97133e0862  vmovaps xmm10, [rsp+0x90]
00007e97133e086b  vmovaps xmm11, [rsp+0xA0]
00007e97133e0874  vmovaps xmm12, [rsp+0xB0]
00007e97133e087d  vmovaps xmm13, [rsp+0xC0]
00007e97133e0886  vmovaps xmm14, [rsp+0xD0]
00007e97133e088f  vmovaps xmm15, [rsp+0xE0]
00007e97133e0898  add rsp, 0xF0
00007e97133e089f  pop r11
00007e97133e08a1  pop r10
00007e97133e08a3  pop r9
00007e97133e08a5  pop r8
00007e97133e08a7  pop rsi
00007e97133e08a8  pop rdi
00007e97133e08a9  pop rdx
00007e97133e08aa  pop rcx
00007e97133e08ab  pop rax
00007e97133e08ac  add rsp, 0x08
00007e97133e08b0  jmp 0x00007E97133DC63D
00007e97133e08b5  sub rsp, 0x08
00007e97133e08b9  push rax
00007e97133e08ba  push rcx
00007e97133e08bb  push rdx
00007e97133e08bc  push rdi
00007e97133e08bd  push rsi
00007e97133e08be  push r8
00007e97133e08c0  push r9
00007e97133e08c2  push r10
00007e97133e08c4  push r11
00007e97133e08c6  sub rsp, 0xF0
00007e97133e08cd  vmovaps [rsp], xmm0
00007e97133e08d2  vmovaps [rsp+0x10], xmm1
00007e97133e08d8  vmovaps [rsp+0x20], xmm2
00007e97133e08de  vmovaps [rsp+0x30], xmm3
00007e97133e08e4  vmovaps [rsp+0x40], xmm4
00007e97133e08ea  vmovaps [rsp+0x50], xmm5
00007e97133e08f0  vmovaps [rsp+0x60], xmm6
00007e97133e08f6  vmovaps [rsp+0x70], xmm7
00007e97133e08fc  vmovaps [rsp+0x80], xmm8
00007e97133e0905  vmovaps [rsp+0x90], xmm9
00007e97133e090e  vmovaps [rsp+0xA0], xmm10
00007e97133e0917  vmovaps [rsp+0xB0], xmm11
00007e97133e0920  vmovaps [rsp+0xC0], xmm12
00007e97133e0929  vmovaps [rsp+0xD0], xmm13
00007e97133e0932  vmovaps [rsp+0xE0], xmm14
00007e97133e093b  sub rsp, 0x30
00007e97133e093f  movaps [rsp], xmm15
00007e97133e0944  movaps [rsp+0x10], xmm11
00007e97133e094a  movaps [rsp+0x20], xmm6
00007e97133e094f  lea rdi, [rsp]
00007e97133e0953  mov esi, 0x00
00007e97133e0958  mov rax, 0x58D8AED5F530
00007e97133e0962  call rax
00007e97133e0964  movaps xmm15, [rsp]
00007e97133e0969  add rsp, 0x30
00007e97133e096d  vmovaps xmm0, [rsp]
00007e97133e0972  vmovaps xmm1, [rsp+0x10]
00007e97133e0978  vmovaps xmm2, [rsp+0x20]
00007e97133e097e  vmovaps xmm3, [rsp+0x30]
00007e97133e0984  vmovaps xmm4, [rsp+0x40]
00007e97133e098a  vmovaps xmm5, [rsp+0x50]
00007e97133e0990  vmovaps xmm6, [rsp+0x60]
00007e97133e0996  vmovaps xmm7, [rsp+0x70]
00007e97133e099c  vmovaps xmm8, [rsp+0x80]
00007e97133e09a5  vmovaps xmm9, [rsp+0x90]
00007e97133e09ae  vmovaps xmm10, [rsp+0xA0]
00007e97133e09b7  vmovaps xmm11, [rsp+0xB0]
00007e97133e09c0  vmovaps xmm12, [rsp+0xC0]
00007e97133e09c9  vmovaps xmm13, [rsp+0xD0]
00007e97133e09d2  vmovaps xmm14, [rsp+0xE0]
00007e97133e09db  add rsp, 0xF0
00007e97133e09e2  pop r11
00007e97133e09e4  pop r10
00007e97133e09e6  pop r9
00007e97133e09e8  pop r8
00007e97133e09ea  pop rsi
00007e97133e09eb  pop rdi
00007e97133e09ec  pop rdx
00007e97133e09ed  pop rcx
00007e97133e09ee  pop rax
00007e97133e09ef  add rsp, 0x08
00007e97133e09f3  jmp 0x00007E97133DC658
00007e97133e09f8  sub rsp, 0x08
00007e97133e09fc  push rax
00007e97133e09fd  push rcx
00007e97133e09fe  push rdx
00007e97133e09ff  push rdi
00007e97133e0a00  push rsi
00007e97133e0a01  push r8
00007e97133e0a03  push r9
00007e97133e0a05  push r10
00007e97133e0a07  push r11
00007e97133e0a09  sub rsp, 0xF0
00007e97133e0a10  vmovaps [rsp], xmm0
00007e97133e0a15  vmovaps [rsp+0x10], xmm1
00007e97133e0a1b  vmovaps [rsp+0x20], xmm2
00007e97133e0a21  vmovaps [rsp+0x30], xmm3
00007e97133e0a27  vmovaps [rsp+0x40], xmm4
00007e97133e0a2d  vmovaps [rsp+0x50], xmm5
00007e97133e0a33  vmovaps [rsp+0x60], xmm6
00007e97133e0a39  vmovaps [rsp+0x70], xmm8
00007e97133e0a3f  vmovaps [rsp+0x80], xmm9
00007e97133e0a48  vmovaps [rsp+0x90], xmm10
00007e97133e0a51  vmovaps [rsp+0xA0], xmm11
00007e97133e0a5a  vmovaps [rsp+0xB0], xmm12
00007e97133e0a63  vmovaps [rsp+0xC0], xmm13
00007e97133e0a6c  vmovaps [rsp+0xD0], xmm14
00007e97133e0a75  vmovaps [rsp+0xE0], xmm15
00007e97133e0a7e  sub rsp, 0x30
00007e97133e0a82  movaps [rsp], xmm7
00007e97133e0a86  movaps [rsp+0x10], xmm11
00007e97133e0a8c  movaps [rsp+0x20], xmm9
00007e97133e0a92  lea rdi, [rsp]
00007e97133e0a96  mov esi, 0x00
00007e97133e0a9b  mov rax, 0x58D8AED5F530
00007e97133e0aa5  call rax
00007e97133e0aa7  movaps xmm7, [rsp]
00007e97133e0aab  add rsp, 0x30
00007e97133e0aaf  vmovaps xmm0, [rsp]
00007e97133e0ab4  vmovaps xmm1, [rsp+0x10]
00007e97133e0aba  vmovaps xmm2, [rsp+0x20]
00007e97133e0ac0  vmovaps xmm3, [rsp+0x30]
00007e97133e0ac6  vmovaps xmm4, [rsp+0x40]
00007e97133e0acc  vmovaps xmm5, [rsp+0x50]
00007e97133e0ad2  vmovaps xmm6, [rsp+0x60]
00007e97133e0ad8  vmovaps xmm8, [rsp+0x70]
00007e97133e0ade  vmovaps xmm9, [rsp+0x80]
00007e97133e0ae7  vmovaps xmm10, [rsp+0x90]
00007e97133e0af0  vmovaps xmm11, [rsp+0xA0]
00007e97133e0af9  vmovaps xmm12, [rsp+0xB0]
00007e97133e0b02  vmovaps xmm13, [rsp+0xC0]
00007e97133e0b0b  vmovaps xmm14, [rsp+0xD0]
00007e97133e0b14  vmovaps xmm15, [rsp+0xE0]
00007e97133e0b1d  add rsp, 0xF0
00007e97133e0b24  pop r11
00007e97133e0b26  pop r10
00007e97133e0b28  pop r9
00007e97133e0b2a  pop r8
00007e97133e0b2c  pop rsi
00007e97133e0b2d  pop rdi
00007e97133e0b2e  pop rdx
00007e97133e0b2f  pop rcx
00007e97133e0b30  pop rax
00007e97133e0b31  add rsp, 0x08
00007e97133e0b35  jmp 0x00007E97133DC685
00007e97133e0b3a  sub rsp, 0x08
00007e97133e0b3e  push rax
00007e97133e0b3f  push rcx
00007e97133e0b40  push rdx
00007e97133e0b41  push rdi
00007e97133e0b42  push rsi
00007e97133e0b43  push r8
00007e97133e0b45  push r9
00007e97133e0b47  push r10
00007e97133e0b49  push r11
00007e97133e0b4b  sub rsp, 0xF0
00007e97133e0b52  vmovaps [rsp], xmm0
00007e97133e0b57  vmovaps [rsp+0x10], xmm1
00007e97133e0b5d  vmovaps [rsp+0x20], xmm2
00007e97133e0b63  vmovaps [rsp+0x30], xmm3
00007e97133e0b69  vmovaps [rsp+0x40], xmm4
00007e97133e0b6f  vmovaps [rsp+0x50], xmm5
00007e97133e0b75  vmovaps [rsp+0x60], xmm6
00007e97133e0b7b  vmovaps [rsp+0x70], xmm7
00007e97133e0b81  vmovaps [rsp+0x80], xmm8
00007e97133e0b8a  vmovaps [rsp+0x90], xmm9
00007e97133e0b93  vmovaps [rsp+0xA0], xmm10
00007e97133e0b9c  vmovaps [rsp+0xB0], xmm12
00007e97133e0ba5  vmovaps [rsp+0xC0], xmm13
00007e97133e0bae  vmovaps [rsp+0xD0], xmm14
00007e97133e0bb7  vmovaps [rsp+0xE0], xmm15
00007e97133e0bc0  sub rsp, 0x30
00007e97133e0bc4  movaps [rsp], xmm11
00007e97133e0bc9  movaps [rsp+0x10], xmm10
00007e97133e0bcf  movaps [rsp+0x20], xmm14
00007e97133e0bd5  lea rdi, [rsp]
00007e97133e0bd9  mov esi, 0x00
00007e97133e0bde  mov rax, 0x58D8AED5F530
00007e97133e0be8  call rax
00007e97133e0bea  movaps xmm11, [rsp]
00007e97133e0bef  add rsp, 0x30
00007e97133e0bf3  vmovaps xmm0, [rsp]
00007e97133e0bf8  vmovaps xmm1, [rsp+0x10]
00007e97133e0bfe  vmovaps xmm2, [rsp+0x20]
00007e97133e0c04  vmovaps xmm3, [rsp+0x30]
00007e97133e0c0a  vmovaps xmm4, [rsp+0x40]
00007e97133e0c10  vmovaps xmm5, [rsp+0x50]
00007e97133e0c16  vmovaps xmm6, [rsp+0x60]
00007e97133e0c1c  vmovaps xmm7, [rsp+0x70]
00007e97133e0c22  vmovaps xmm8, [rsp+0x80]
00007e97133e0c2b  vmovaps xmm9, [rsp+0x90]
00007e97133e0c34  vmovaps xmm10, [rsp+0xA0]
00007e97133e0c3d  vmovaps xmm12, [rsp+0xB0]
00007e97133e0c46  vmovaps xmm13, [rsp+0xC0]
00007e97133e0c4f  vmovaps xmm14, [rsp+0xD0]
00007e97133e0c58  vmovaps xmm15, [rsp+0xE0]
00007e97133e0c61  add rsp, 0xF0
00007e97133e0c68  pop r11
00007e97133e0c6a  pop r10
00007e97133e0c6c  pop r9
00007e97133e0c6e  pop r8
00007e97133e0c70  pop rsi
00007e97133e0c71  pop rdi
00007e97133e0c72  pop rdx
00007e97133e0c73  pop rcx
00007e97133e0c74  pop rax
00007e97133e0c75  add rsp, 0x08
00007e97133e0c79  jmp 0x00007E97133DC6A0
00007e97133e0c7e  call 0x00007E97132C33A0
00007e97133e0c83  jmp 0x00007E97133DC6AA
00007e97133e0c88  sub rsp, 0x08
00007e97133e0c8c  push rax
00007e97133e0c8d  push rcx
00007e97133e0c8e  push rdx
00007e97133e0c8f  push rdi
00007e97133e0c90  push rsi
00007e97133e0c91  push r8
00007e97133e0c93  push r9
00007e97133e0c95  push r10
00007e97133e0c97  push r11
00007e97133e0c99  sub rsp, 0xF0
00007e97133e0ca0  vmovaps [rsp], xmm0
00007e97133e0ca5  vmovaps [rsp+0x10], xmm1
00007e97133e0cab  vmovaps [rsp+0x20], xmm2
00007e97133e0cb1  vmovaps [rsp+0x30], xmm3
00007e97133e0cb7  vmovaps [rsp+0x40], xmm4
00007e97133e0cbd  vmovaps [rsp+0x50], xmm5
00007e97133e0cc3  vmovaps [rsp+0x60], xmm6
00007e97133e0cc9  vmovaps [rsp+0x70], xmm7
00007e97133e0ccf  vmovaps [rsp+0x80], xmm8
00007e97133e0cd8  vmovaps [rsp+0x90], xmm9
00007e97133e0ce1  vmovaps [rsp+0xA0], xmm11
00007e97133e0cea  vmovaps [rsp+0xB0], xmm12
00007e97133e0cf3  vmovaps [rsp+0xC0], xmm13
00007e97133e0cfc  vmovaps [rsp+0xD0], xmm14
00007e97133e0d05  vmovaps [rsp+0xE0], xmm15
00007e97133e0d0e  sub rsp, 0x30
00007e97133e0d12  movaps [rsp], xmm10
00007e97133e0d17  movaps [rsp+0x10], xmm1
00007e97133e0d1c  movaps [rsp+0x20], xmm12
00007e97133e0d22  lea rdi, [rsp]
00007e97133e0d26  mov esi, 0x00
00007e97133e0d2b  mov rax, 0x58D8AED5F530
00007e97133e0d35  call rax
00007e97133e0d37  movaps xmm10, [rsp]
00007e97133e0d3c  add rsp, 0x30
00007e97133e0d40  vmovaps xmm0, [rsp]
00007e97133e0d45  vmovaps xmm1, [rsp+0x10]
00007e97133e0d4b  vmovaps xmm2, [rsp+0x20]
00007e97133e0d51  vmovaps xmm3, [rsp+0x30]
00007e97133e0d57  vmovaps xmm4, [rsp+0x40]
00007e97133e0d5d  vmovaps xmm5, [rsp+0x50]
00007e97133e0d63  vmovaps xmm6, [rsp+0x60]
00007e97133e0d69  vmovaps xmm7, [rsp+0x70]
00007e97133e0d6f  vmovaps xmm8, [rsp+0x80]
00007e97133e0d78  vmovaps xmm9, [rsp+0x90]
00007e97133e0d81  vmovaps xmm11, [rsp+0xA0]
00007e97133e0d8a  vmovaps xmm12, [rsp+0xB0]
00007e97133e0d93  vmovaps xmm13, [rsp+0xC0]
00007e97133e0d9c  vmovaps xmm14, [rsp+0xD0]
00007e97133e0da5  vmovaps xmm15, [rsp+0xE0]
00007e97133e0dae  add rsp, 0xF0
00007e97133e0db5  pop r11
00007e97133e0db7  pop r10
00007e97133e0db9  pop r9
00007e97133e0dbb  pop r8
00007e97133e0dbd  pop rsi
00007e97133e0dbe  pop rdi
00007e97133e0dbf  pop rdx
00007e97133e0dc0  pop rcx
00007e97133e0dc1  pop rax
00007e97133e0dc2  add rsp, 0x08
00007e97133e0dc6  jmp 0x00007E97133DC6CD
00007e97133e0dcb  sub rsp, 0x08
00007e97133e0dcf  push rax
00007e97133e0dd0  push rcx
00007e97133e0dd1  push rdx
00007e97133e0dd2  push rdi
00007e97133e0dd3  push rsi
00007e97133e0dd4  push r8
00007e97133e0dd6  push r9
00007e97133e0dd8  push r10
00007e97133e0dda  push r11
00007e97133e0ddc  sub rsp, 0xF0
00007e97133e0de3  vmovaps [rsp], xmm0
00007e97133e0de8  vmovaps [rsp+0x10], xmm1
00007e97133e0dee  vmovaps [rsp+0x20], xmm2
00007e97133e0df4  vmovaps [rsp+0x30], xmm3
00007e97133e0dfa  vmovaps [rsp+0x40], xmm4
00007e97133e0e00  vmovaps [rsp+0x50], xmm5
00007e97133e0e06  vmovaps [rsp+0x60], xmm6
00007e97133e0e0c  vmovaps [rsp+0x70], xmm7
00007e97133e0e12  vmovaps [rsp+0x80], xmm8
00007e97133e0e1b  vmovaps [rsp+0x90], xmm9
00007e97133e0e24  vmovaps [rsp+0xA0], xmm10
00007e97133e0e2d  vmovaps [rsp+0xB0], xmm11
00007e97133e0e36  vmovaps [rsp+0xC0], xmm13
00007e97133e0e3f  vmovaps [rsp+0xD0], xmm14
00007e97133e0e48  vmovaps [rsp+0xE0], xmm15
00007e97133e0e51  sub rsp, 0x30
00007e97133e0e55  movaps [rsp], xmm12
00007e97133e0e5a  movaps [rsp+0x10], xmm14
00007e97133e0e60  movaps [rsp+0x20], xmm1
00007e97133e0e65  lea rdi, [rsp]
00007e97133e0e69  mov esi, 0x00
00007e97133e0e6e  mov rax, 0x58D8AED5F530
00007e97133e0e78  call rax
00007e97133e0e7a  movaps xmm12, [rsp]
00007e97133e0e7f  add rsp, 0x30
00007e97133e0e83  vmovaps xmm0, [rsp]
00007e97133e0e88  vmovaps xmm1, [rsp+0x10]
00007e97133e0e8e  vmovaps xmm2, [rsp+0x20]
00007e97133e0e94  vmovaps xmm3, [rsp+0x30]
00007e97133e0e9a  vmovaps xmm4, [rsp+0x40]
00007e97133e0ea0  vmovaps xmm5, [rsp+0x50]
00007e97133e0ea6  vmovaps xmm6, [rsp+0x60]
00007e97133e0eac  vmovaps xmm7, [rsp+0x70]
00007e97133e0eb2  vmovaps xmm8, [rsp+0x80]
00007e97133e0ebb  vmovaps xmm9, [rsp+0x90]
00007e97133e0ec4  vmovaps xmm10, [rsp+0xA0]
00007e97133e0ecd  vmovaps xmm11, [rsp+0xB0]
00007e97133e0ed6  vmovaps xmm13, [rsp+0xC0]
00007e97133e0edf  vmovaps xmm14, [rsp+0xD0]
00007e97133e0ee8  vmovaps xmm15, [rsp+0xE0]
00007e97133e0ef1  add rsp, 0xF0
00007e97133e0ef8  pop r11
00007e97133e0efa  pop r10
00007e97133e0efc  pop r9
00007e97133e0efe  pop r8
00007e97133e0f00  pop rsi
00007e97133e0f01  pop rdi
00007e97133e0f02  pop rdx
00007e97133e0f03  pop rcx
00007e97133e0f04  pop rax
00007e97133e0f05  add rsp, 0x08
00007e97133e0f09  jmp 0x00007E97133DC6FC
00007e97133e0f0e  sub rsp, 0x08
00007e97133e0f12  push rax
00007e97133e0f13  push rcx
00007e97133e0f14  push rdx
00007e97133e0f15  push rdi
00007e97133e0f16  push rsi
00007e97133e0f17  push r8
00007e97133e0f19  push r9
00007e97133e0f1b  push r10
00007e97133e0f1d  push r11
00007e97133e0f1f  sub rsp, 0xF0
00007e97133e0f26  vmovaps [rsp], xmm0
00007e97133e0f2b  vmovaps [rsp+0x10], xmm1
00007e97133e0f31  vmovaps [rsp+0x20], xmm2
00007e97133e0f37  vmovaps [rsp+0x30], xmm3
00007e97133e0f3d  vmovaps [rsp+0x40], xmm4
00007e97133e0f43  vmovaps [rsp+0x50], xmm5
00007e97133e0f49  vmovaps [rsp+0x60], xmm6
00007e97133e0f4f  vmovaps [rsp+0x70], xmm7
00007e97133e0f55  vmovaps [rsp+0x80], xmm8
00007e97133e0f5e  vmovaps [rsp+0x90], xmm9
00007e97133e0f67  vmovaps [rsp+0xA0], xmm10
00007e97133e0f70  vmovaps [rsp+0xB0], xmm11
00007e97133e0f79  vmovaps [rsp+0xC0], xmm12
00007e97133e0f82  vmovaps [rsp+0xD0], xmm13
00007e97133e0f8b  vmovaps [rsp+0xE0], xmm15
00007e97133e0f94  sub rsp, 0x30
00007e97133e0f98  movaps [rsp], xmm14
00007e97133e0f9d  movaps [rsp+0x10], xmm9
00007e97133e0fa3  movaps [rsp+0x20], xmm1
00007e97133e0fa8  lea rdi, [rsp]
00007e97133e0fac  mov esi, 0x00
00007e97133e0fb1  mov rax, 0x58D8AED5F530
00007e97133e0fbb  call rax
00007e97133e0fbd  movaps xmm14, [rsp]
00007e97133e0fc2  add rsp, 0x30
00007e97133e0fc6  vmovaps xmm0, [rsp]
00007e97133e0fcb  vmovaps xmm1, [rsp+0x10]
00007e97133e0fd1  vmovaps xmm2, [rsp+0x20]
00007e97133e0fd7  vmovaps xmm3, [rsp+0x30]
00007e97133e0fdd  vmovaps xmm4, [rsp+0x40]
00007e97133e0fe3  vmovaps xmm5, [rsp+0x50]
00007e97133e0fe9  vmovaps xmm6, [rsp+0x60]
00007e97133e0fef  vmovaps xmm7, [rsp+0x70]
00007e97133e0ff5  vmovaps xmm8, [rsp+0x80]
00007e97133e0ffe  vmovaps xmm9, [rsp+0x90]
00007e97133e1007  vmovaps xmm10, [rsp+0xA0]
00007e97133e1010  vmovaps xmm11, [rsp+0xB0]
00007e97133e1019  vmovaps xmm12, [rsp+0xC0]
00007e97133e1022  vmovaps xmm13, [rsp+0xD0]
00007e97133e102b  vmovaps xmm15, [rsp+0xE0]
00007e97133e1034  add rsp, 0xF0
00007e97133e103b  pop r11
00007e97133e103d  pop r10
00007e97133e103f  pop r9
00007e97133e1041  pop r8
00007e97133e1043  pop rsi
00007e97133e1044  pop rdi
00007e97133e1045  pop rdx
00007e97133e1046  pop rcx
00007e97133e1047  pop rax
00007e97133e1048  add rsp, 0x08
00007e97133e104c  jmp 0x00007E97133DC72B
00007e97133e1051  sub rsp, 0x08
00007e97133e1055  push rax
00007e97133e1056  push rcx
00007e97133e1057  push rdx
00007e97133e1058  push rdi
00007e97133e1059  push rsi
00007e97133e105a  push r8
00007e97133e105c  push r9
00007e97133e105e  push r10
00007e97133e1060  push r11
00007e97133e1062  sub rsp, 0xF0
00007e97133e1069  vmovaps [rsp], xmm0
00007e97133e106e  vmovaps [rsp+0x10], xmm2
00007e97133e1074  vmovaps [rsp+0x20], xmm3
00007e97133e107a  vmovaps [rsp+0x30], xmm4
00007e97133e1080  vmovaps [rsp+0x40], xmm5
00007e97133e1086  vmovaps [rsp+0x50], xmm6
00007e97133e108c  vmovaps [rsp+0x60], xmm7
00007e97133e1092  vmovaps [rsp+0x70], xmm8
00007e97133e1098  vmovaps [rsp+0x80], xmm9
00007e97133e10a1  vmovaps [rsp+0x90], xmm10
00007e97133e10aa  vmovaps [rsp+0xA0], xmm11
00007e97133e10b3  vmovaps [rsp+0xB0], xmm12
00007e97133e10bc  vmovaps [rsp+0xC0], xmm13
00007e97133e10c5  vmovaps [rsp+0xD0], xmm14
00007e97133e10ce  vmovaps [rsp+0xE0], xmm15
00007e97133e10d7  sub rsp, 0x30
00007e97133e10db  movaps [rsp], xmm1
00007e97133e10df  movaps [rsp+0x10], xmm13
00007e97133e10e5  movaps [rsp+0x20], xmm8
00007e97133e10eb  lea rdi, [rsp]
00007e97133e10ef  mov esi, 0x00
00007e97133e10f4  mov rax, 0x58D8AED5F530
00007e97133e10fe  call rax
00007e97133e1100  movaps xmm1, [rsp]
00007e97133e1104  add rsp, 0x30
00007e97133e1108  vmovaps xmm0, [rsp]
00007e97133e110d  vmovaps xmm2, [rsp+0x10]
00007e97133e1113  vmovaps xmm3, [rsp+0x20]
00007e97133e1119  vmovaps xmm4, [rsp+0x30]
00007e97133e111f  vmovaps xmm5, [rsp+0x40]
00007e97133e1125  vmovaps xmm6, [rsp+0x50]
00007e97133e112b  vmovaps xmm7, [rsp+0x60]
00007e97133e1131  vmovaps xmm8, [rsp+0x70]
00007e97133e1137  vmovaps xmm9, [rsp+0x80]
00007e97133e1140  vmovaps xmm10, [rsp+0x90]
00007e97133e1149  vmovaps xmm11, [rsp+0xA0]
00007e97133e1152  vmovaps xmm12, [rsp+0xB0]
00007e97133e115b  vmovaps xmm13, [rsp+0xC0]
00007e97133e1164  vmovaps xmm14, [rsp+0xD0]
00007e97133e116d  vmovaps xmm15, [rsp+0xE0]
00007e97133e1176  add rsp, 0xF0
00007e97133e117d  pop r11
00007e97133e117f  pop r10
00007e97133e1181  pop r9
00007e97133e1183  pop r8
00007e97133e1185  pop rsi
00007e97133e1186  pop rdi
00007e97133e1187  pop rdx
00007e97133e1188  pop rcx
00007e97133e1189  pop rax
00007e97133e118a  add rsp, 0x08
00007e97133e118e  jmp 0x00007E97133DC74D
00007e97133e1193  call 0x00007E971320C260
00007e97133e1198  jmp 0x00007E97133DC75B
00007e97133e119d  call 0x00007E97132BD750
00007e97133e11a2  jmp 0x00007E97133DC765
00007e97133e11a7  sub rsp, 0x08
00007e97133e11ab  push rax
00007e97133e11ac  push rcx
00007e97133e11ad  push rdx
00007e97133e11ae  push rdi
00007e97133e11af  push rsi
00007e97133e11b0  push r8
00007e97133e11b2  push r9
00007e97133e11b4  push r10
00007e97133e11b6  push r11
00007e97133e11b8  sub rsp, 0xF0
00007e97133e11bf  vmovaps [rsp], xmm0
00007e97133e11c4  vmovaps [rsp+0x10], xmm1
00007e97133e11ca  vmovaps [rsp+0x20], xmm2
00007e97133e11d0  vmovaps [rsp+0x30], xmm3
00007e97133e11d6  vmovaps [rsp+0x40], xmm4
00007e97133e11dc  vmovaps [rsp+0x50], xmm5
00007e97133e11e2  vmovaps [rsp+0x60], xmm6
00007e97133e11e8  vmovaps [rsp+0x70], xmm7
00007e97133e11ee  vmovaps [rsp+0x80], xmm9
00007e97133e11f7  vmovaps [rsp+0x90], xmm10
00007e97133e1200  vmovaps [rsp+0xA0], xmm11
00007e97133e1209  vmovaps [rsp+0xB0], xmm12
00007e97133e1212  vmovaps [rsp+0xC0], xmm13
00007e97133e121b  vmovaps [rsp+0xD0], xmm14
00007e97133e1224  vmovaps [rsp+0xE0], xmm15
00007e97133e122d  sub rsp, 0x30
00007e97133e1231  movaps [rsp], xmm8
00007e97133e1236  movaps [rsp+0x10], xmm15
00007e97133e123c  movaps [rsp+0x20], xmm7
00007e97133e1241  lea rdi, [rsp]
00007e97133e1245  mov esi, 0x00
00007e97133e124a  mov rax, 0x58D8AED5F530
00007e97133e1254  call rax
00007e97133e1256  movaps xmm8, [rsp]
00007e97133e125b  add rsp, 0x30
00007e97133e125f  vmovaps xmm0, [rsp]
00007e97133e1264  vmovaps xmm1, [rsp+0x10]
00007e97133e126a  vmovaps xmm2, [rsp+0x20]
00007e97133e1270  vmovaps xmm3, [rsp+0x30]
00007e97133e1276  vmovaps xmm4, [rsp+0x40]
00007e97133e127c  vmovaps xmm5, [rsp+0x50]
00007e97133e1282  vmovaps xmm6, [rsp+0x60]
00007e97133e1288  vmovaps xmm7, [rsp+0x70]
00007e97133e128e  vmovaps xmm9, [rsp+0x80]
00007e97133e1297  vmovaps xmm10, [rsp+0x90]
00007e97133e12a0  vmovaps xmm11, [rsp+0xA0]
00007e97133e12a9  vmovaps xmm12, [rsp+0xB0]
00007e97133e12b2  vmovaps xmm13, [rsp+0xC0]
00007e97133e12bb  vmovaps xmm14, [rsp+0xD0]
00007e97133e12c4  vmovaps xmm15, [rsp+0xE0]
00007e97133e12cd  add rsp, 0xF0
00007e97133e12d4  pop r11
00007e97133e12d6  pop r10
00007e97133e12d8  pop r9
00007e97133e12da  pop r8
00007e97133e12dc  pop rsi
00007e97133e12dd  pop rdi
00007e97133e12de  pop rdx
00007e97133e12df  pop rcx
00007e97133e12e0  pop rax
00007e97133e12e1  add rsp, 0x08
00007e97133e12e5  jmp 0x00007E97133DC787
00007e97133e12ea  sub rsp, 0x08
00007e97133e12ee  push rax
00007e97133e12ef  push rcx
00007e97133e12f0  push rdx
00007e97133e12f1  push rdi
00007e97133e12f2  push rsi
00007e97133e12f3  push r8
00007e97133e12f5  push r9
00007e97133e12f7  push r10
00007e97133e12f9  push r11
00007e97133e12fb  sub rsp, 0xF0
00007e97133e1302  vmovaps [rsp], xmm0
00007e97133e1307  vmovaps [rsp+0x10], xmm1
00007e97133e130d  vmovaps [rsp+0x20], xmm2
00007e97133e1313  vmovaps [rsp+0x30], xmm3
00007e97133e1319  vmovaps [rsp+0x40], xmm4
00007e97133e131f  vmovaps [rsp+0x50], xmm5
00007e97133e1325  vmovaps [rsp+0x60], xmm6
00007e97133e132b  vmovaps [rsp+0x70], xmm8
00007e97133e1331  vmovaps [rsp+0x80], xmm9
00007e97133e133a  vmovaps [rsp+0x90], xmm10
00007e97133e1343  vmovaps [rsp+0xA0], xmm11
00007e97133e134c  vmovaps [rsp+0xB0], xmm12
00007e97133e1355  vmovaps [rsp+0xC0], xmm13
00007e97133e135e  vmovaps [rsp+0xD0], xmm14
00007e97133e1367  vmovaps [rsp+0xE0], xmm15
00007e97133e1370  sub rsp, 0x30
00007e97133e1374  movaps [rsp], xmm7
00007e97133e1378  movaps [rsp+0x10], xmm9
00007e97133e137e  movaps [rsp+0x20], xmm15
00007e97133e1384  lea rdi, [rsp]
00007e97133e1388  mov esi, 0x00
00007e97133e138d  mov rax, 0x58D8AED5F530
00007e97133e1397  call rax
00007e97133e1399  movaps xmm7, [rsp]
00007e97133e139d  add rsp, 0x30
00007e97133e13a1  vmovaps xmm0, [rsp]
00007e97133e13a6  vmovaps xmm1, [rsp+0x10]
00007e97133e13ac  vmovaps xmm2, [rsp+0x20]
00007e97133e13b2  vmovaps xmm3, [rsp+0x30]
00007e97133e13b8  vmovaps xmm4, [rsp+0x40]
00007e97133e13be  vmovaps xmm5, [rsp+0x50]
00007e97133e13c4  vmovaps xmm6, [rsp+0x60]
00007e97133e13ca  vmovaps xmm8, [rsp+0x70]
00007e97133e13d0  vmovaps xmm9, [rsp+0x80]
00007e97133e13d9  vmovaps xmm10, [rsp+0x90]
00007e97133e13e2  vmovaps xmm11, [rsp+0xA0]
00007e97133e13eb  vmovaps xmm12, [rsp+0xB0]
00007e97133e13f4  vmovaps xmm13, [rsp+0xC0]
00007e97133e13fd  vmovaps xmm14, [rsp+0xD0]
00007e97133e1406  vmovaps xmm15, [rsp+0xE0]
00007e97133e140f  add rsp, 0xF0
00007e97133e1416  pop r11
00007e97133e1418  pop r10
00007e97133e141a  pop r9
00007e97133e141c  pop r8
00007e97133e141e  pop rsi
00007e97133e141f  pop rdi
00007e97133e1420  pop rdx
00007e97133e1421  pop rcx
00007e97133e1422  pop rax
00007e97133e1423  add rsp, 0x08
00007e97133e1427  jmp 0x00007E97133DC7B4
00007e97133e142c  sub rsp, 0x08
00007e97133e1430  push rax
00007e97133e1431  push rcx
00007e97133e1432  push rdx
00007e97133e1433  push rdi
00007e97133e1434  push rsi
00007e97133e1435  push r8
00007e97133e1437  push r9
00007e97133e1439  push r10
00007e97133e143b  push r11
00007e97133e143d  sub rsp, 0xF0
00007e97133e1444  vmovaps [rsp], xmm0
00007e97133e1449  vmovaps [rsp+0x10], xmm1
00007e97133e144f  vmovaps [rsp+0x20], xmm2
00007e97133e1455  vmovaps [rsp+0x30], xmm3
00007e97133e145b  vmovaps [rsp+0x40], xmm4
00007e97133e1461  vmovaps [rsp+0x50], xmm5
00007e97133e1467  vmovaps [rsp+0x60], xmm6
00007e97133e146d  vmovaps [rsp+0x70], xmm7
00007e97133e1473  vmovaps [rsp+0x80], xmm8
00007e97133e147c  vmovaps [rsp+0x90], xmm10
00007e97133e1485  vmovaps [rsp+0xA0], xmm11
00007e97133e148e  vmovaps [rsp+0xB0], xmm12
00007e97133e1497  vmovaps [rsp+0xC0], xmm13
00007e97133e14a0  vmovaps [rsp+0xD0], xmm14
00007e97133e14a9  vmovaps [rsp+0xE0], xmm15
00007e97133e14b2  sub rsp, 0x30
00007e97133e14b6  movaps [rsp], xmm9
00007e97133e14bb  movaps [rsp+0x10], xmm13
00007e97133e14c1  movaps [rsp+0x20], xmm15
00007e97133e14c7  lea rdi, [rsp]
00007e97133e14cb  mov esi, 0x00
00007e97133e14d0  mov rax, 0x58D8AED5F530
00007e97133e14da  call rax
00007e97133e14dc  movaps xmm9, [rsp]
00007e97133e14e1  add rsp, 0x30
00007e97133e14e5  vmovaps xmm0, [rsp]
00007e97133e14ea  vmovaps xmm1, [rsp+0x10]
00007e97133e14f0  vmovaps xmm2, [rsp+0x20]
00007e97133e14f6  vmovaps xmm3, [rsp+0x30]
00007e97133e14fc  vmovaps xmm4, [rsp+0x40]
00007e97133e1502  vmovaps xmm5, [rsp+0x50]
00007e97133e1508  vmovaps xmm6, [rsp+0x60]
00007e97133e150e  vmovaps xmm7, [rsp+0x70]
00007e97133e1514  vmovaps xmm8, [rsp+0x80]
00007e97133e151d  vmovaps xmm10, [rsp+0x90]
00007e97133e1526  vmovaps xmm11, [rsp+0xA0]
00007e97133e152f  vmovaps xmm12, [rsp+0xB0]
00007e97133e1538  vmovaps xmm13, [rsp+0xC0]
00007e97133e1541  vmovaps xmm14, [rsp+0xD0]
00007e97133e154a  vmovaps xmm15, [rsp+0xE0]
00007e97133e1553  add rsp, 0xF0
00007e97133e155a  pop r11
00007e97133e155c  pop r10
00007e97133e155e  pop r9
00007e97133e1560  pop r8
00007e97133e1562  pop rsi
00007e97133e1563  pop rdi
00007e97133e1564  pop rdx
00007e97133e1565  pop rcx
00007e97133e1566  pop rax
00007e97133e1567  add rsp, 0x08
00007e97133e156b  jmp 0x00007E97133DC7E2
00007e97133e1570  sub rsp, 0x08
00007e97133e1574  push rax
00007e97133e1575  push rcx
00007e97133e1576  push rdx
00007e97133e1577  push rdi
00007e97133e1578  push rsi
00007e97133e1579  push r8
00007e97133e157b  push r9
00007e97133e157d  push r10
00007e97133e157f  push r11
00007e97133e1581  sub rsp, 0xF0
00007e97133e1588  vmovaps [rsp], xmm0
00007e97133e158d  vmovaps [rsp+0x10], xmm1
00007e97133e1593  vmovaps [rsp+0x20], xmm2
00007e97133e1599  vmovaps [rsp+0x30], xmm3
00007e97133e159f  vmovaps [rsp+0x40], xmm4
00007e97133e15a5  vmovaps [rsp+0x50], xmm5
00007e97133e15ab  vmovaps [rsp+0x60], xmm6
00007e97133e15b1  vmovaps [rsp+0x70], xmm7
00007e97133e15b7  vmovaps [rsp+0x80], xmm8
00007e97133e15c0  vmovaps [rsp+0x90], xmm9
00007e97133e15c9  vmovaps [rsp+0xA0], xmm10
00007e97133e15d2  vmovaps [rsp+0xB0], xmm11
00007e97133e15db  vmovaps [rsp+0xC0], xmm12
00007e97133e15e4  vmovaps [rsp+0xD0], xmm13
00007e97133e15ed  vmovaps [rsp+0xE0], xmm14
00007e97133e15f6  sub rsp, 0x30
00007e97133e15fa  movaps [rsp], xmm15
00007e97133e15ff  movaps [rsp+0x10], xmm11
00007e97133e1605  movaps [rsp+0x20], xmm12
00007e97133e160b  lea rdi, [rsp]
00007e97133e160f  mov esi, 0x00
00007e97133e1614  mov rax, 0x58D8AED5F530
00007e97133e161e  call rax
00007e97133e1620  movaps xmm15, [rsp]
00007e97133e1625  add rsp, 0x30
00007e97133e1629  vmovaps xmm0, [rsp]
00007e97133e162e  vmovaps xmm1, [rsp+0x10]
00007e97133e1634  vmovaps xmm2, [rsp+0x20]
00007e97133e163a  vmovaps xmm3, [rsp+0x30]
00007e97133e1640  vmovaps xmm4, [rsp+0x40]
00007e97133e1646  vmovaps xmm5, [rsp+0x50]
00007e97133e164c  vmovaps xmm6, [rsp+0x60]
00007e97133e1652  vmovaps xmm7, [rsp+0x70]
00007e97133e1658  vmovaps xmm8, [rsp+0x80]
00007e97133e1661  vmovaps xmm9, [rsp+0x90]
00007e97133e166a  vmovaps xmm10, [rsp+0xA0]
00007e97133e1673  vmovaps xmm11, [rsp+0xB0]
00007e97133e167c  vmovaps xmm12, [rsp+0xC0]
00007e97133e1685  vmovaps xmm13, [rsp+0xD0]
00007e97133e168e  vmovaps xmm14, [rsp+0xE0]
00007e97133e1697  add rsp, 0xF0
00007e97133e169e  pop r11
00007e97133e16a0  pop r10
00007e97133e16a2  pop r9
00007e97133e16a4  pop r8
00007e97133e16a6  pop rsi
00007e97133e16a7  pop rdi
00007e97133e16a8  pop rdx
00007e97133e16a9  pop rcx
00007e97133e16aa  pop rax
00007e97133e16ab  add rsp, 0x08
00007e97133e16af  jmp 0x00007E97133DC7FD
00007e97133e16b4  sub rsp, 0x08
00007e97133e16b8  push rax
00007e97133e16b9  push rcx
00007e97133e16ba  push rdx
00007e97133e16bb  push rdi
00007e97133e16bc  push rsi
00007e97133e16bd  push r8
00007e97133e16bf  push r9
00007e97133e16c1  push r10
00007e97133e16c3  push r11
00007e97133e16c5  sub rsp, 0xF0
00007e97133e16cc  vmovaps [rsp], xmm0
00007e97133e16d1  vmovaps [rsp+0x10], xmm1
00007e97133e16d7  vmovaps [rsp+0x20], xmm2
00007e97133e16dd  vmovaps [rsp+0x30], xmm3
00007e97133e16e3  vmovaps [rsp+0x40], xmm4
00007e97133e16e9  vmovaps [rsp+0x50], xmm5
00007e97133e16ef  vmovaps [rsp+0x60], xmm6
00007e97133e16f5  vmovaps [rsp+0x70], xmm7
00007e97133e16fb  vmovaps [rsp+0x80], xmm8
00007e97133e1704  vmovaps [rsp+0x90], xmm9
00007e97133e170d  vmovaps [rsp+0xA0], xmm10
00007e97133e1716  vmovaps [rsp+0xB0], xmm11
00007e97133e171f  vmovaps [rsp+0xC0], xmm12
00007e97133e1728  vmovaps [rsp+0xD0], xmm14
00007e97133e1731  vmovaps [rsp+0xE0], xmm15
00007e97133e173a  sub rsp, 0x30
00007e97133e173e  movaps [rsp], xmm13
00007e97133e1743  movaps [rsp+0x10], xmm10
00007e97133e1749  movaps [rsp+0x20], xmm14
00007e97133e174f  lea rdi, [rsp]
00007e97133e1753  mov esi, 0x00
00007e97133e1758  mov rax, 0x58D8AED5F530
00007e97133e1762  call rax
00007e97133e1764  movaps xmm13, [rsp]
00007e97133e1769  add rsp, 0x30
00007e97133e176d  vmovaps xmm0, [rsp]
00007e97133e1772  vmovaps xmm1, [rsp+0x10]
00007e97133e1778  vmovaps xmm2, [rsp+0x20]
00007e97133e177e  vmovaps xmm3, [rsp+0x30]
00007e97133e1784  vmovaps xmm4, [rsp+0x40]
00007e97133e178a  vmovaps xmm5, [rsp+0x50]
00007e97133e1790  vmovaps xmm6, [rsp+0x60]
00007e97133e1796  vmovaps xmm7, [rsp+0x70]
00007e97133e179c  vmovaps xmm8, [rsp+0x80]
00007e97133e17a5  vmovaps xmm9, [rsp+0x90]
00007e97133e17ae  vmovaps xmm10, [rsp+0xA0]
00007e97133e17b7  vmovaps xmm11, [rsp+0xB0]
00007e97133e17c0  vmovaps xmm12, [rsp+0xC0]
00007e97133e17c9  vmovaps xmm14, [rsp+0xD0]
00007e97133e17d2  vmovaps xmm15, [rsp+0xE0]
00007e97133e17db  add rsp, 0xF0
00007e97133e17e2  pop r11
00007e97133e17e4  pop r10
00007e97133e17e6  pop r9
00007e97133e17e8  pop r8
00007e97133e17ea  pop rsi
00007e97133e17eb  pop rdi
00007e97133e17ec  pop rdx
00007e97133e17ed  pop rcx
00007e97133e17ee  pop rax
00007e97133e17ef  add rsp, 0x08
00007e97133e17f3  jmp 0x00007E97133DC820
00007e97133e17f8  sub rsp, 0x08
00007e97133e17fc  push rax
00007e97133e17fd  push rcx
00007e97133e17fe  push rdx
00007e97133e17ff  push rdi
00007e97133e1800  push rsi
00007e97133e1801  push r8
00007e97133e1803  push r9
00007e97133e1805  push r10
00007e97133e1807  push r11
00007e97133e1809  sub rsp, 0xF0
00007e97133e1810  vmovaps [rsp], xmm0
00007e97133e1815  vmovaps [rsp+0x10], xmm1
00007e97133e181b  vmovaps [rsp+0x20], xmm2
00007e97133e1821  vmovaps [rsp+0x30], xmm3
00007e97133e1827  vmovaps [rsp+0x40], xmm4
00007e97133e182d  vmovaps [rsp+0x50], xmm5
00007e97133e1833  vmovaps [rsp+0x60], xmm6
00007e97133e1839  vmovaps [rsp+0x70], xmm7
00007e97133e183f  vmovaps [rsp+0x80], xmm8
00007e97133e1848  vmovaps [rsp+0x90], xmm9
00007e97133e1851  vmovaps [rsp+0xA0], xmm10
00007e97133e185a  vmovaps [rsp+0xB0], xmm11
00007e97133e1863  vmovaps [rsp+0xC0], xmm12
00007e97133e186c  vmovaps [rsp+0xD0], xmm13
00007e97133e1875  vmovaps [rsp+0xE0], xmm15
00007e97133e187e  sub rsp, 0x30
00007e97133e1882  movaps [rsp], xmm14
00007e97133e1887  movaps [rsp+0x10], xmm1
00007e97133e188c  movaps [rsp+0x20], xmm7
00007e97133e1891  lea rdi, [rsp]
00007e97133e1895  mov esi, 0x00
00007e97133e189a  mov rax, 0x58D8AED5F530
00007e97133e18a4  call rax
00007e97133e18a6  movaps xmm14, [rsp]
00007e97133e18ab  add rsp, 0x30
00007e97133e18af  vmovaps xmm0, [rsp]
00007e97133e18b4  vmovaps xmm1, [rsp+0x10]
00007e97133e18ba  vmovaps xmm2, [rsp+0x20]
00007e97133e18c0  vmovaps xmm3, [rsp+0x30]
00007e97133e18c6  vmovaps xmm4, [rsp+0x40]
00007e97133e18cc  vmovaps xmm5, [rsp+0x50]
00007e97133e18d2  vmovaps xmm6, [rsp+0x60]
00007e97133e18d8  vmovaps xmm7, [rsp+0x70]
00007e97133e18de  vmovaps xmm8, [rsp+0x80]
00007e97133e18e7  vmovaps xmm9, [rsp+0x90]
00007e97133e18f0  vmovaps xmm10, [rsp+0xA0]
00007e97133e18f9  vmovaps xmm11, [rsp+0xB0]
00007e97133e1902  vmovaps xmm12, [rsp+0xC0]
00007e97133e190b  vmovaps xmm13, [rsp+0xD0]
00007e97133e1914  vmovaps xmm15, [rsp+0xE0]
00007e97133e191d  add rsp, 0xF0
00007e97133e1924  pop r11
00007e97133e1926  pop r10
00007e97133e1928  pop r9
00007e97133e192a  pop r8
00007e97133e192c  pop rsi
00007e97133e192d  pop rdi
00007e97133e192e  pop rdx
00007e97133e192f  pop rcx
00007e97133e1930  pop rax
00007e97133e1931  add rsp, 0x08
00007e97133e1935  jmp 0x00007E97133DC843
00007e97133e193a  sub rsp, 0x08
00007e97133e193e  push rax
00007e97133e193f  push rcx
00007e97133e1940  push rdx
00007e97133e1941  push rdi
00007e97133e1942  push rsi
00007e97133e1943  push r8
00007e97133e1945  push r9
00007e97133e1947  push r10
00007e97133e1949  push r11
00007e97133e194b  sub rsp, 0xF0
00007e97133e1952  vmovaps [rsp], xmm0
00007e97133e1957  vmovaps [rsp+0x10], xmm2
00007e97133e195d  vmovaps [rsp+0x20], xmm3
00007e97133e1963  vmovaps [rsp+0x30], xmm4
00007e97133e1969  vmovaps [rsp+0x40], xmm5
00007e97133e196f  vmovaps [rsp+0x50], xmm6
00007e97133e1975  vmovaps [rsp+0x60], xmm7
00007e97133e197b  vmovaps [rsp+0x70], xmm8
00007e97133e1981  vmovaps [rsp+0x80], xmm9
00007e97133e198a  vmovaps [rsp+0x90], xmm10
00007e97133e1993  vmovaps [rsp+0xA0], xmm11
00007e97133e199c  vmovaps [rsp+0xB0], xmm12
00007e97133e19a5  vmovaps [rsp+0xC0], xmm13
00007e97133e19ae  vmovaps [rsp+0xD0], xmm14
00007e97133e19b7  vmovaps [rsp+0xE0], xmm15
00007e97133e19c0  sub rsp, 0x30
00007e97133e19c4  movaps [rsp], xmm1
00007e97133e19c8  movaps [rsp+0x10], xmm8
00007e97133e19ce  movaps [rsp+0x20], xmm9
00007e97133e19d4  lea rdi, [rsp]
00007e97133e19d8  mov esi, 0x00
00007e97133e19dd  mov rax, 0x58D8AED5F530
00007e97133e19e7  call rax
00007e97133e19e9  movaps xmm1, [rsp]
00007e97133e19ed  add rsp, 0x30
00007e97133e19f1  vmovaps xmm0, [rsp]
00007e97133e19f6  vmovaps xmm2, [rsp+0x10]
00007e97133e19fc  vmovaps xmm3, [rsp+0x20]
00007e97133e1a02  vmovaps xmm4, [rsp+0x30]
00007e97133e1a08  vmovaps xmm5, [rsp+0x40]
00007e97133e1a0e  vmovaps xmm6, [rsp+0x50]
00007e97133e1a14  vmovaps xmm7, [rsp+0x60]
00007e97133e1a1a  vmovaps xmm8, [rsp+0x70]
00007e97133e1a20  vmovaps xmm9, [rsp+0x80]
00007e97133e1a29  vmovaps xmm10, [rsp+0x90]
00007e97133e1a32  vmovaps xmm11, [rsp+0xA0]
00007e97133e1a3b  vmovaps xmm12, [rsp+0xB0]
00007e97133e1a44  vmovaps xmm13, [rsp+0xC0]
00007e97133e1a4d  vmovaps xmm14, [rsp+0xD0]
00007e97133e1a56  vmovaps xmm15, [rsp+0xE0]
00007e97133e1a5f  add rsp, 0xF0
00007e97133e1a66  pop r11
00007e97133e1a68  pop r10
00007e97133e1a6a  pop r9
00007e97133e1a6c  pop r8
00007e97133e1a6e  pop rsi
00007e97133e1a6f  pop rdi
00007e97133e1a70  pop rdx
00007e97133e1a71  pop rcx
00007e97133e1a72  pop rax
00007e97133e1a73  add rsp, 0x08
00007e97133e1a77  jmp 0x00007E97133DC865
00007e97133e1a7c  call 0x00007E97132E5940
00007e97133e1a81  jmp 0x00007E97133DC873
00007e97133e1a86  call 0x00007E971320C380
00007e97133e1a8b  jmp 0x00007E97133DC87D
00007e97133e1a90  call 0x00007E971320D600
00007e97133e1a95  jmp 0x00007E97133DC887
00007e97133e1a9a  call 0x00007E97131FF540
00007e97133e1a9f  jmp 0x00007E97133DC891
00007e97133e1aa4  int3
00007e97133e1aa5  nop [rax+rax*1], ax
00007e97133e1aae  nop
00007e97133e1ab0  mov rax, [r15+0xF8]
00007e97133e1ab7  lea r14, [rax+0x140]
00007e97133e1abe  mov r12, [r13+r14*1]
00007e97133e1ac3  mov [r15+0xE8], r12
00007e97133e1aca  lea r14, [rax+0x130]
00007e97133e1ad1  mov r12, [r13+r14*1]
00007e97133e1ad6  lea r14, [rax+0x138]
00007e97133e1add  mov r11, [r13+r14*1]
00007e97133e1ae2  movq xmm1, r12
00007e97133e1ae7  movq xmm15, r11
00007e97133e1aec  movq xmm1, xmm1
00007e97133e1af0  movq xmm1, xmm1
00007e97133e1af4  movaps [r15+0x1A0], xmm1
00007e97133e1afc  movq xmm15, xmm15
00007e97133e1b01  movq xmm15, xmm15
00007e97133e1b06  movaps [r15+0x190], xmm15
00007e97133e1b0e  lea r14, [rax+0x120]
00007e97133e1b15  mov r12, [r13+r14*1]
00007e97133e1b1a  lea r14, [rax+0x128]
00007e97133e1b21  mov r11, [r13+r14*1]
00007e97133e1b26  movq xmm1, r12
00007e97133e1b2b  movq xmm15, r11
00007e97133e1b30  movq xmm1, xmm1
00007e97133e1b34  movq xmm1, xmm1
00007e97133e1b38  movaps [r15+0x1C0], xmm1
00007e97133e1b40  movq xmm15, xmm15
00007e97133e1b45  movq xmm15, xmm15
00007e97133e1b4a  movaps [r15+0x1B0], xmm15
00007e97133e1b52  lea r14, [rax+0x110]
00007e97133e1b59  mov r12, [r13+r14*1]
00007e97133e1b5e  lea r14, [rax+0x118]
00007e97133e1b65  mov r11, [r13+r14*1]
00007e97133e1b6a  movq xmm1, r12
00007e97133e1b6f  movq xmm15, r11
00007e97133e1b74  movq xmm1, xmm1
00007e97133e1b78  movq xmm1, xmm1
00007e97133e1b7c  movaps [r15+0x1E0], xmm1
00007e97133e1b84  movq xmm15, xmm15
00007e97133e1b89  movq xmm15, xmm15
00007e97133e1b8e  movaps [r15+0x1D0], xmm15
00007e97133e1b96  lea r14, [rax+0x100]
00007e97133e1b9d  mov r12, [r13+r14*1]
00007e97133e1ba2  lea r14, [rax+0x108]
00007e97133e1ba9  mov r11, [r13+r14*1]
00007e97133e1bae  movq xmm1, r12
00007e97133e1bb3  movq xmm15, r11
00007e97133e1bb8  movq xmm1, xmm1
00007e97133e1bbc  movq xmm1, xmm1
00007e97133e1bc0  movaps [r15+0x200], xmm1
00007e97133e1bc8  movq xmm15, xmm15
00007e97133e1bcd  movq xmm15, xmm15
00007e97133e1bd2  movaps [r15+0x1F0], xmm15
00007e97133e1bda  mov qword ptr [r15+0x40], 0x430000
00007e97133e1be2  mov r14d, 0x430510
00007e97133e1be8  mov r12, [r13+r14*1]
00007e97133e1bed  movq xmm1, r12
00007e97133e1bf2  lea r14, [rax+0x150]
00007e97133e1bf9  mov [r15+0xF8], r14
00007e97133e1c00  mov rax, [r15+0x50]
00007e97133e1c04  movups xmm15, [r13+rax*1]
00007e97133e1c0a  movaps [r15+0x120], xmm15
00007e97133e1c12  mov qword ptr [r15+0x48], 0x10
00007e97133e1c1a  xor eax, eax
00007e97133e1c1c  mov r14d, 0x10
00007e97133e1c22  mov r12d, 0x200
00007e97133e1c28  cmp r14, r12
00007e97133e1c2b  cmc
00007e97133e1c2c  lahf
00007e97133e1c2d  seto al
00007e97133e1c30  mov [r15+0x108], eax
00007e97133e1c37  pextrq rax, xmm15, 0x01
00007e97133e1c3e  movq xmm14, rax
00007e97133e1c43  movaps [r15+0x130], xmm14
00007e97133e1c4b  movq rax, xmm1
00007e97133e1c50  movq r14, xmm15
00007e97133e1c55  vmovq xmm1, rax
00007e97133e1c5a  vmovq xmm15, r14
00007e97133e1c5f  movaps xmm13, xmm1
00007e97133e1c63  addsd xmm13, xmm15
00007e97133e1c68  ucomisd xmm13, xmm13
00007e97133e1c6d  jp 0x00007E97133E1D86
00007e97133e1c73  movq xmm13, xmm13
00007e97133e1c78  movq rax, xmm13
00007e97133e1c7d  movq r14, xmm14
00007e97133e1c82  vmovq xmm1, rax
00007e97133e1c87  vmovq xmm15, r14
00007e97133e1c8c  movaps xmm14, xmm1
00007e97133e1c90  addsd xmm14, xmm15
00007e97133e1c95  ucomisd xmm14, xmm14
00007e97133e1c9a  jp 0x00007E97133E1DCE
00007e97133e1ca0  movq xmm14, xmm14
00007e97133e1ca5  movaps [r15+0x110], xmm14
00007e97133e1cad  mov eax, [r15+0x108]
00007e97133e1cb4  sahf
00007e97133e1cb5  jnz 0x00007E97133E1CE7
00007e97133e1cb7  cmp dword ptr [r15+0x318], 0x00
00007e97133e1cbf  jz 0x00007E97133E1FE0
00007e97133e1cc5  nop [rax+rax*1], ax
00007e97133e1cce  nop [rax+rax*1], eax
00007e97133e1cd6  mov eax, 0x410490
00007e97133e1cdb  mov [r15+0x100], rax
00007e97133e1ce2  jmp 0x00007E97131FE110
00007e97133e1ce7  cmp dword ptr [r15+0x318], 0x00
00007e97133e1cef  jz 0x00007E97133E1E20
00007e97133e1cf5  nop [rax+rax*1], ax
00007e97133e1cfe  nop [rax+rax*1], eax
00007e97133e1d06  mov eax, 0x410474
00007e97133e1d0b  mov [r15+0x100], rax
00007e97133e1d12  jmp 0x00007E97131FE110
00007e97133e1d17  int3
00007e97133e1d18  call 0x00007E97132E27E0
00007e97133e1d1d  jmp 0x00007E97133E1AC3
00007e97133e1d22  call 0x00007E97132E27E0
00007e97133e1d27  jmp 0x00007E97133E1AD6
00007e97133e1d2c  call 0x00007E97132E1570
00007e97133e1d31  jmp 0x00007E97133E1AE2
00007e97133e1d36  call 0x00007E97132E27E0
00007e97133e1d3b  jmp 0x00007E97133E1B1A
00007e97133e1d40  call 0x00007E97132E1570
00007e97133e1d45  jmp 0x00007E97133E1B26
00007e97133e1d4a  call 0x00007E97132E27E0
00007e97133e1d4f  jmp 0x00007E97133E1B5E
00007e97133e1d54  call 0x00007E97132E1570
00007e97133e1d59  jmp 0x00007E97133E1B6A
00007e97133e1d5e  call 0x00007E97132E27E0
00007e97133e1d63  jmp 0x00007E97133E1BA2
00007e97133e1d68  call 0x00007E97132E1570
00007e97133e1d6d  jmp 0x00007E97133E1BAE
00007e97133e1d72  call 0x00007E97132E27E0
00007e97133e1d77  jmp 0x00007E97133E1BED
00007e97133e1d7c  call 0x00007E971320E760
00007e97133e1d81  jmp 0x00007E97133E1C0A
00007e97133e1d86  ucomisd xmm1, xmm15
00007e97133e1d8b  jp 0x00007E97133E1D9A
00007e97133e1d8d  movaps xmm13, [0x00007E9712FFE060]
00007e97133e1d95  jmp 0x00007E97133E1C73
00007e97133e1d9a  vxorps xmm0, xmm1, xmm15
00007e97133e1d9f  pextrw eax, xmm0, 0x03
00007e97133e1da4  and eax, 0x7FF8
00007e97133e1da9  cmp eax, 0x08
00007e97133e1dac  jnz 0x00007E97133E1C73
00007e97133e1db2  movq rax, xmm15
00007e97133e1db7  shl rax, 0x0D
00007e97133e1dbb  jbe 0x00007E97133E1C73
00007e97133e1dc1  vorps xmm13, xmm15, [0x00007E9712FFE070]
00007e97133e1dc9  jmp 0x00007E97133E1C73
00007e97133e1dce  ucomisd xmm1, xmm15
00007e97133e1dd3  jp 0x00007E97133E1DE2
00007e97133e1dd5  movaps xmm14, [0x00007E9712FFE060]
00007e97133e1ddd  jmp 0x00007E97133E1CA0
00007e97133e1de2  vxorps xmm0, xmm1, xmm15
00007e97133e1de7  pextrw eax, xmm0, 0x03
00007e97133e1dec  and eax, 0x7FF8
00007e97133e1df1  cmp eax, 0x08
00007e97133e1df4  jnz 0x00007E97133E1CA0
00007e97133e1dfa  movq rax, xmm15
00007e97133e1dff  shl rax, 0x0D
00007e97133e1e03  jbe 0x00007E97133E1CA0
00007e97133e1e09  vorps xmm14, xmm15, [0x00007E9712FFE070]
00007e97133e1e11  jmp 0x00007E97133E1CA0
00007e97133e1e16  int3
00007e97133e1e17  nop [rax+rax*1], ax
00007e97133e1e20  mov rax, [r15+0x48]
00007e97133e1e24  mov r14, [r15+0x50]
00007e97133e1e28  lea r12, [r14+rax*1]
00007e97133e1e2c  movups xmm1, [r13+r12*1]
00007e97133e1e32  movaps [r15+0x120], xmm1
00007e97133e1e3a  lea r14, [rax+0x10]
00007e97133e1e3e  mov [r15+0x48], r14
00007e97133e1e42  xor eax, eax
00007e97133e1e44  mov r12d, 0x200
00007e97133e1e4a  cmp r14, r12
00007e97133e1e4d  cmc
00007e97133e1e4e  lahf
00007e97133e1e4f  seto al
00007e97133e1e52  mov [r15+0x108], eax
00007e97133e1e59  pextrq rax, xmm1, 0x01
00007e97133e1e60  movq xmm15, rax
00007e97133e1e65  movaps [r15+0x130], xmm15
00007e97133e1e6d  movaps xmm14, [r15+0x110]
00007e97133e1e75  movq rax, xmm14
00007e97133e1e7a  movq r14, xmm1
00007e97133e1e7f  vmovq xmm1, rax
00007e97133e1e84  vmovq xmm14, r14
00007e97133e1e89  movaps xmm13, xmm1
00007e97133e1e8d  addsd xmm13, xmm14
00007e97133e1e92  ucomisd xmm13, xmm13
00007e97133e1e97  jp 0x00007E97133E1F4C
00007e97133e1e9d  movq xmm13, xmm13
00007e97133e1ea2  movq rax, xmm13
00007e97133e1ea7  movq r14, xmm15
00007e97133e1eac  vmovq xmm1, rax
00007e97133e1eb1  vmovq xmm15, r14
00007e97133e1eb6  movaps xmm14, xmm1
00007e97133e1eba  addsd xmm14, xmm15
00007e97133e1ebf  ucomisd xmm14, xmm14
00007e97133e1ec4  jp 0x00007E97133E1F94
00007e97133e1eca  movq xmm14, xmm14
00007e97133e1ecf  movaps [r15+0x110], xmm14
00007e97133e1ed7  mov eax, [r15+0x108]
00007e97133e1ede  sahf
00007e97133e1edf  jnz 0x00007E97133E1F11
00007e97133e1ee1  cmp dword ptr [r15+0x318], 0x00
00007e97133e1ee9  jz 0x00007E97133E1FE0
00007e97133e1eef  nop [rax+rax*1], ax
00007e97133e1ef8  nop [rax+rax*1], eax
00007e97133e1f00  mov eax, 0x410490
00007e97133e1f05  mov [r15+0x100], rax
00007e97133e1f0c  jmp 0x00007E97131FE110
00007e97133e1f11  cmp dword ptr [r15+0x318], 0x00
00007e97133e1f19  jz 0x00007E97133E1E20
00007e97133e1f1f  nop [rax+rax*1], ax
00007e97133e1f28  nop [rax+rax*1], eax
00007e97133e1f30  mov eax, 0x410474
00007e97133e1f35  mov [r15+0x100], rax
00007e97133e1f3c  jmp 0x00007E97131FE110
00007e97133e1f41  int3
00007e97133e1f42  call 0x00007E97132B52F0
00007e97133e1f47  jmp 0x00007E97133E1E32
00007e97133e1f4c  ucomisd xmm1, xmm14
00007e97133e1f51  jp 0x00007E97133E1F60
00007e97133e1f53  movaps xmm13, [0x00007E9712FFE060]
00007e97133e1f5b  jmp 0x00007E97133E1E9D
00007e97133e1f60  vxorps xmm0, xmm1, xmm14
00007e97133e1f65  pextrw eax, xmm0, 0x03
00007e97133e1f6a  and eax, 0x7FF8
00007e97133e1f6f  cmp eax, 0x08
00007e97133e1f72  jnz 0x00007E97133E1E9D
00007e97133e1f78  movq rax, xmm14
00007e97133e1f7d  shl rax, 0x0D
00007e97133e1f81  jbe 0x00007E97133E1E9D
00007e97133e1f87  vorps xmm13, xmm14, [0x00007E9712FFE070]
00007e97133e1f8f  jmp 0x00007E97133E1E9D
00007e97133e1f94  ucomisd xmm1, xmm15
00007e97133e1f99  jp 0x00007E97133E1FA8
00007e97133e1f9b  movaps xmm14, [0x00007E9712FFE060]
00007e97133e1fa3  jmp 0x00007E97133E1ECA
00007e97133e1fa8  vxorps xmm0, xmm1, xmm15
00007e97133e1fad  pextrw eax, xmm0, 0x03
00007e97133e1fb2  and eax, 0x7FF8
00007e97133e1fb7  cmp eax, 0x08
00007e97133e1fba  jnz 0x00007E97133E1ECA
00007e97133e1fc0  movq rax, xmm15
00007e97133e1fc5  shl rax, 0x0D
00007e97133e1fc9  jbe 0x00007E97133E1ECA
00007e97133e1fcf  vorps xmm14, xmm15, [0x00007E9712FFE070]
00007e97133e1fd7  jmp 0x00007E97133E1ECA
00007e97133e1fdc  int3
00007e97133e1fdd  nop [rax], eax
00007e97133e1fe0  mov rax, [r15+0x40]
00007e97133e1fe4  lea r14, [rax+0x510]
00007e97133e1feb  movaps xmm1, [r15+0x110]
00007e97133e1ff3  movq rax, xmm1
00007e97133e1ff8  mov [r13+r14*1], rax
00007e97133e1ffd  mov rax, [r15+0xF0]
00007e97133e2004  mov [r15+0x100], rax
00007e97133e200b  jmp 0x00007E97133CE5C0
00007e97133e2010  int3
00007e97133e2011  call 0x00007E97132D5EB0
00007e97133e2016  jmp 0x00007E97133E1FFD
00007e97133e201b  int3
00007e97133e201c  nop [rax], eax
00007e97133e2020  mov qword ptr [r15+0x100], 0x04
00007e97133e202b  mov esi, 0x00
00007e97133e2030  mov edx, 0x09
00007e97133e2035  mov rdi, 0x7FFFB0296C80
00007e97133e203f  mov rax, 0x58D8AEBF2970
00007e97133e2049  call rax
00007e97133e204b  cmp dword ptr [r15+0x318], 0x00
00007e97133e2053  jnz 0x00007E97131FE110
00007e97133e2059  jmp 0x00007E97131FE0A0
00007e97133e205e  int3
00007e97133e205f  int3
