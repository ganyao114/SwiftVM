000073ef1c5ce69b  nop [rax+rax*1], eax
000073ef1c5ce6a0  vmovaps xmm1, [0x000073EF1C1FE010]
000073ef1c5ce6a8  movq xmm1, xmm1
000073ef1c5ce6ac  movaps [r15+0x110], xmm1
000073ef1c5ce6b4  vmovaps xmm1, [0x000073EF1C1FE020]
000073ef1c5ce6bc  movq xmm1, xmm1
000073ef1c5ce6c0  movaps [r15+0x120], xmm1
000073ef1c5ce6c8  mov eax, 0x4204C0
000073ef1c5ce6cd  mov r14, [r13+rax*1]
000073ef1c5ce6d2  movq xmm1, r14
000073ef1c5ce6d7  movaps [r15+0x130], xmm1
000073ef1c5ce6df  vmovaps xmm1, [0x000073EF1C1FE030]
000073ef1c5ce6e7  vpbroadcastq xmm1, xmm1
000073ef1c5ce6ec  movaps [r15+0x140], xmm1
000073ef1c5ce6f4  mov qword ptr [r15+0x40], 0x02
000073ef1c5ce6fc  vmovaps xmm15, [0x000073EF1C1FE040]
000073ef1c5ce704  movq xmm15, xmm15
000073ef1c5ce709  movaps [r15+0x150], xmm15
000073ef1c5ce711  mov qword ptr [r15+0x58], 0x420000
000073ef1c5ce719  vmovaps xmm15, [0x000073EF1C1FE050]
000073ef1c5ce721  vpbroadcastq xmm15, xmm15
000073ef1c5ce726  movaps [r15+0x160], xmm15
000073ef1c5ce72e  mov rax, [r15+0x40]
000073ef1c5ce732  vmovq xmm14, rax
000073ef1c5ce737  vpbroadcastq xmm14, xmm14
000073ef1c5ce73c  movaps [r15+0x170], xmm14
000073ef1c5ce744  mov eax, 0x4204D0
000073ef1c5ce749  movups xmm13, [r13+rax*1]
000073ef1c5ce74f  mov qword ptr [r15+0x40], 0x430518
000073ef1c5ce757  mov qword ptr [r15+0x50], 0x430720
000073ef1c5ce75f  vpmovqd xmm12, xmm13
000073ef1c5ce765  pxor xmm11, xmm11
000073ef1c5ce76a  punpcklqdq xmm12, xmm11
000073ef1c5ce76f  movaps [r15+0x210], xmm12
000073ef1c5ce777  movq xmm12, qword ptr [r15+0x120]
000073ef1c5ce780  movq xmm11, qword ptr [r15+0x130]
000073ef1c5ce789  psubd xmm12, xmm11
000073ef1c5ce78e  movq xmm12, xmm12
000073ef1c5ce793  paddq xmm13, xmm14
000073ef1c5ce798  movaps [r15+0x180], xmm13
000073ef1c5ce7a0  movq xmm14, qword ptr [r15+0x150]
000073ef1c5ce7a9  paddd xmm11, xmm14
000073ef1c5ce7ae  movq xmm11, xmm11
000073ef1c5ce7b3  movq xmm11, xmm11
000073ef1c5ce7b8  movaps [r15+0x130], xmm11
000073ef1c5ce7c0  pmovzxdq xmm12, xmm12
000073ef1c5ce7c6  psllq xmm12, 0x00
000073ef1c5ce7cc  movq xmm14, qword ptr [r15+0x210]
000073ef1c5ce7d5  movq xmm13, qword ptr [r15+0x110]
000073ef1c5ce7de  paddd xmm14, xmm13
000073ef1c5ce7e3  movq xmm14, xmm14
000073ef1c5ce7e8  vcvtuqq2pd xmm12, xmm12
000073ef1c5ce7ee  pmovzxdq xmm14, xmm14
000073ef1c5ce7f4  psllq xmm14, 0x00
000073ef1c5ce7fa  vcvtuqq2pd xmm14, xmm14
000073ef1c5ce800  movaps xmm13, xmm12
000073ef1c5ce804  mulpd xmm13, xmm1
000073ef1c5ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000073ef1c5ce80f  ptest xmm11, xmm11
000073ef1c5ce815  jnz 0x000073EF1C5CE8FF
000073ef1c5ce81b  movaps [r15+0x220], xmm13
000073ef1c5ce823  mov eax, 0x430720
000073ef1c5ce828  movups [r13+rax*1], xmm13
000073ef1c5ce82e  movaps xmm1, xmm14
000073ef1c5ce832  mulpd xmm1, xmm15
000073ef1c5ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000073ef1c5ce83c  ptest xmm13, xmm13
000073ef1c5ce842  jnz 0x000073EF1C5CEA4C
000073ef1c5ce848  movaps [r15+0x210], xmm1
000073ef1c5ce850  mov eax, 0x430518
000073ef1c5ce855  movups [r13+rax*1], xmm1
000073ef1c5ce85b  mov qword ptr [r15+0x48], 0x10
000073ef1c5ce863  xor eax, eax
000073ef1c5ce865  mov r14d, 0x10
000073ef1c5ce86b  mov r12d, 0x200
000073ef1c5ce871  cmp r14, r12
000073ef1c5ce874  cmc
000073ef1c5ce875  lahf
000073ef1c5ce876  seto al
000073ef1c5ce879  mov [r15+0x108], eax
000073ef1c5ce880  mov eax, [r15+0x108]
000073ef1c5ce887  sahf
000073ef1c5ce888  jnz 0x000073EF1C5CE8BA
000073ef1c5ce88a  cmp dword ptr [r15+0x318], 0x00
000073ef1c5ce892  jz 0x000073EF1C5CEFF0
000073ef1c5ce898  nop [rax+rax*1], ax
000073ef1c5ce8a1  nop [rax+rax*1], eax
000073ef1c5ce8a9  mov eax, 0x4101EC
000073ef1c5ce8ae  mov [r15+0x100], rax
000073ef1c5ce8b5  jmp 0x000073EF1C3FE110
000073ef1c5ce8ba  cmp dword ptr [r15+0x318], 0x00
000073ef1c5ce8c2  jz 0x000073EF1C5CEBA0
000073ef1c5ce8c8  nop [rax+rax*1], ax
000073ef1c5ce8d1  nop [rax+rax*1], eax
000073ef1c5ce8d9  mov eax, 0x4101AC
000073ef1c5ce8de  mov [r15+0x100], rax
000073ef1c5ce8e5  jmp 0x000073EF1C3FE110
000073ef1c5ce8ea  int3
000073ef1c5ce8eb  call 0x000073EF1C40DC20
000073ef1c5ce8f0  jmp 0x000073EF1C5CE6D2
000073ef1c5ce8f5  call 0x000073EF1C40C260
000073ef1c5ce8fa  jmp 0x000073EF1C5CE74F
000073ef1c5ce8ff  sub rsp, 0x08
000073ef1c5ce903  push rax
000073ef1c5ce904  push rcx
000073ef1c5ce905  push rdx
000073ef1c5ce906  push rdi
000073ef1c5ce907  push rsi
000073ef1c5ce908  push r8
000073ef1c5ce90a  push r9
000073ef1c5ce90c  push r10
000073ef1c5ce90e  push r11
000073ef1c5ce910  sub rsp, 0xF0
000073ef1c5ce917  vmovaps [rsp], xmm0
000073ef1c5ce91c  vmovaps [rsp+0x10], xmm1
000073ef1c5ce922  vmovaps [rsp+0x20], xmm2
000073ef1c5ce928  vmovaps [rsp+0x30], xmm3
000073ef1c5ce92e  vmovaps [rsp+0x40], xmm4
000073ef1c5ce934  vmovaps [rsp+0x50], xmm5
000073ef1c5ce93a  vmovaps [rsp+0x60], xmm6
000073ef1c5ce940  vmovaps [rsp+0x70], xmm7
000073ef1c5ce946  vmovaps [rsp+0x80], xmm8
000073ef1c5ce94f  vmovaps [rsp+0x90], xmm9
000073ef1c5ce958  vmovaps [rsp+0xA0], xmm10
000073ef1c5ce961  vmovaps [rsp+0xB0], xmm11
000073ef1c5ce96a  vmovaps [rsp+0xC0], xmm12
000073ef1c5ce973  vmovaps [rsp+0xD0], xmm14
000073ef1c5ce97c  vmovaps [rsp+0xE0], xmm15
000073ef1c5ce985  sub rsp, 0x30
000073ef1c5ce989  movaps [rsp], xmm13
000073ef1c5ce98e  movaps [rsp+0x10], xmm12
000073ef1c5ce994  movaps [rsp+0x20], xmm1
000073ef1c5ce999  lea rdi, [rsp]
000073ef1c5ce99d  mov esi, 0x00
000073ef1c5ce9a2  mov rax, 0x56F25E118530
000073ef1c5ce9ac  call rax
000073ef1c5ce9ae  movaps xmm13, [rsp]
000073ef1c5ce9b3  add rsp, 0x30
000073ef1c5ce9b7  vmovaps xmm0, [rsp]
000073ef1c5ce9bc  vmovaps xmm1, [rsp+0x10]
000073ef1c5ce9c2  vmovaps xmm2, [rsp+0x20]
000073ef1c5ce9c8  vmovaps xmm3, [rsp+0x30]
000073ef1c5ce9ce  vmovaps xmm4, [rsp+0x40]
000073ef1c5ce9d4  vmovaps xmm5, [rsp+0x50]
000073ef1c5ce9da  vmovaps xmm6, [rsp+0x60]
000073ef1c5ce9e0  vmovaps xmm7, [rsp+0x70]
000073ef1c5ce9e6  vmovaps xmm8, [rsp+0x80]
000073ef1c5ce9ef  vmovaps xmm9, [rsp+0x90]
000073ef1c5ce9f8  vmovaps xmm10, [rsp+0xA0]
000073ef1c5cea01  vmovaps xmm11, [rsp+0xB0]
000073ef1c5cea0a  vmovaps xmm12, [rsp+0xC0]
000073ef1c5cea13  vmovaps xmm14, [rsp+0xD0]
000073ef1c5cea1c  vmovaps xmm15, [rsp+0xE0]
000073ef1c5cea25  add rsp, 0xF0
000073ef1c5cea2c  pop r11
000073ef1c5cea2e  pop r10
000073ef1c5cea30  pop r9
000073ef1c5cea32  pop r8
000073ef1c5cea34  pop rsi
000073ef1c5cea35  pop rdi
000073ef1c5cea36  pop rdx
000073ef1c5cea37  pop rcx
000073ef1c5cea38  pop rax
000073ef1c5cea39  add rsp, 0x08
000073ef1c5cea3d  jmp 0x000073EF1C5CE81B
000073ef1c5cea42  call 0x000073EF1C40C380
000073ef1c5cea47  jmp 0x000073EF1C5CE82E
000073ef1c5cea4c  sub rsp, 0x08
000073ef1c5cea50  push rax
000073ef1c5cea51  push rcx
000073ef1c5cea52  push rdx
000073ef1c5cea53  push rdi
000073ef1c5cea54  push rsi
000073ef1c5cea55  push r8
000073ef1c5cea57  push r9
000073ef1c5cea59  push r10
000073ef1c5cea5b  push r11
000073ef1c5cea5d  sub rsp, 0xF0
000073ef1c5cea64  vmovaps [rsp], xmm0
000073ef1c5cea69  vmovaps [rsp+0x10], xmm2
000073ef1c5cea6f  vmovaps [rsp+0x20], xmm3
000073ef1c5cea75  vmovaps [rsp+0x30], xmm4
000073ef1c5cea7b  vmovaps [rsp+0x40], xmm5
000073ef1c5cea81  vmovaps [rsp+0x50], xmm6
000073ef1c5cea87  vmovaps [rsp+0x60], xmm7
000073ef1c5cea8d  vmovaps [rsp+0x70], xmm8
000073ef1c5cea93  vmovaps [rsp+0x80], xmm9
000073ef1c5cea9c  vmovaps [rsp+0x90], xmm10
000073ef1c5ceaa5  vmovaps [rsp+0xA0], xmm11
000073ef1c5ceaae  vmovaps [rsp+0xB0], xmm12
000073ef1c5ceab7  vmovaps [rsp+0xC0], xmm13
000073ef1c5ceac0  vmovaps [rsp+0xD0], xmm14
000073ef1c5ceac9  vmovaps [rsp+0xE0], xmm15
000073ef1c5cead2  sub rsp, 0x30
000073ef1c5cead6  movaps [rsp], xmm1
000073ef1c5ceada  movaps [rsp+0x10], xmm14
000073ef1c5ceae0  movaps [rsp+0x20], xmm15
000073ef1c5ceae6  lea rdi, [rsp]
000073ef1c5ceaea  mov esi, 0x00
000073ef1c5ceaef  mov rax, 0x56F25E118530
000073ef1c5ceaf9  call rax
000073ef1c5ceafb  movaps xmm1, [rsp]
000073ef1c5ceaff  add rsp, 0x30
000073ef1c5ceb03  vmovaps xmm0, [rsp]
000073ef1c5ceb08  vmovaps xmm2, [rsp+0x10]
000073ef1c5ceb0e  vmovaps xmm3, [rsp+0x20]
000073ef1c5ceb14  vmovaps xmm4, [rsp+0x30]
000073ef1c5ceb1a  vmovaps xmm5, [rsp+0x40]
000073ef1c5ceb20  vmovaps xmm6, [rsp+0x50]
000073ef1c5ceb26  vmovaps xmm7, [rsp+0x60]
000073ef1c5ceb2c  vmovaps xmm8, [rsp+0x70]
000073ef1c5ceb32  vmovaps xmm9, [rsp+0x80]
000073ef1c5ceb3b  vmovaps xmm10, [rsp+0x90]
000073ef1c5ceb44  vmovaps xmm11, [rsp+0xA0]
000073ef1c5ceb4d  vmovaps xmm12, [rsp+0xB0]
000073ef1c5ceb56  vmovaps xmm13, [rsp+0xC0]
000073ef1c5ceb5f  vmovaps xmm14, [rsp+0xD0]
000073ef1c5ceb68  vmovaps xmm15, [rsp+0xE0]
000073ef1c5ceb71  add rsp, 0xF0
000073ef1c5ceb78  pop r11
000073ef1c5ceb7a  pop r10
000073ef1c5ceb7c  pop r9
000073ef1c5ceb7e  pop r8
000073ef1c5ceb80  pop rsi
000073ef1c5ceb81  pop rdi
000073ef1c5ceb82  pop rdx
000073ef1c5ceb83  pop rcx
000073ef1c5ceb84  pop rax
000073ef1c5ceb85  add rsp, 0x08
000073ef1c5ceb89  jmp 0x000073EF1C5CE848
000073ef1c5ceb8e  call 0x000073EF1C3FF540
000073ef1c5ceb93  jmp 0x000073EF1C5CE85B
000073ef1c5ceb98  int3
000073ef1c5ceb99  nop [rax], eax
000073ef1c5ceba0  movaps xmm1, [r15+0x180]
000073ef1c5ceba8  vpmovqd xmm15, xmm1
000073ef1c5cebae  pxor xmm14, xmm14
000073ef1c5cebb3  punpcklqdq xmm15, xmm14
000073ef1c5cebb8  movaps [r15+0x210], xmm15
000073ef1c5cebc0  movq xmm15, qword ptr [r15+0x120]
000073ef1c5cebc9  movq xmm14, qword ptr [r15+0x130]
000073ef1c5cebd2  psubd xmm15, xmm14
000073ef1c5cebd7  movq xmm15, xmm15
000073ef1c5cebdc  movaps xmm13, [r15+0x170]
000073ef1c5cebe4  paddq xmm1, xmm13
000073ef1c5cebe9  movaps [r15+0x180], xmm1
000073ef1c5cebf1  movq xmm1, qword ptr [r15+0x150]
000073ef1c5cebfa  paddd xmm14, xmm1
000073ef1c5cebff  movq xmm14, xmm14
000073ef1c5cec04  movq xmm14, xmm14
000073ef1c5cec09  movaps [r15+0x130], xmm14
000073ef1c5cec11  pmovzxdq xmm15, xmm15
000073ef1c5cec17  psllq xmm15, 0x00
000073ef1c5cec1d  movq xmm1, qword ptr [r15+0x210]
000073ef1c5cec26  movq xmm14, qword ptr [r15+0x110]
000073ef1c5cec2f  paddd xmm1, xmm14
000073ef1c5cec34  movq xmm1, xmm1
000073ef1c5cec38  vcvtuqq2pd xmm15, xmm15
000073ef1c5cec3e  pmovzxdq xmm1, xmm1
000073ef1c5cec43  psllq xmm1, 0x00
000073ef1c5cec48  vcvtuqq2pd xmm1, xmm1
000073ef1c5cec4e  movaps xmm14, [r15+0x140]
000073ef1c5cec56  movaps xmm13, xmm15
000073ef1c5cec5a  mulpd xmm13, xmm14
000073ef1c5cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000073ef1c5cec65  ptest xmm12, xmm12
000073ef1c5cec6b  jnz 0x000073EF1C5CED4E
000073ef1c5cec71  movaps [r15+0x220], xmm13
000073ef1c5cec79  mov rax, [r15+0x48]
000073ef1c5cec7d  mov r14, [r15+0x50]
000073ef1c5cec81  lea r12, [r14+rax*1]
000073ef1c5cec85  movups [r13+r12*1], xmm13
000073ef1c5cec8b  movaps xmm15, [r15+0x160]
000073ef1c5cec93  movaps xmm14, xmm1
000073ef1c5cec97  mulpd xmm14, xmm15
000073ef1c5cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000073ef1c5ceca2  ptest xmm13, xmm13
000073ef1c5ceca8  jnz 0x000073EF1C5CEE9C
000073ef1c5cecae  movaps [r15+0x210], xmm14
000073ef1c5cecb6  mov r14, [r15+0x40]
000073ef1c5cecba  lea r12, [r14+rax*1]
000073ef1c5cecbe  movups [r13+r12*1], xmm14
000073ef1c5cecc4  lea r14, [rax+0x10]
000073ef1c5cecc8  mov [r15+0x48], r14
000073ef1c5ceccc  xor eax, eax
000073ef1c5cecce  mov r12d, 0x200
000073ef1c5cecd4  cmp r14, r12
000073ef1c5cecd7  cmc
000073ef1c5cecd8  lahf
000073ef1c5cecd9  seto al
000073ef1c5cecdc  mov [r15+0x108], eax
000073ef1c5cece3  mov eax, [r15+0x108]
000073ef1c5cecea  sahf
000073ef1c5ceceb  jnz 0x000073EF1C5CED1D
000073ef1c5ceced  cmp dword ptr [r15+0x318], 0x00
000073ef1c5cecf5  jz 0x000073EF1C5CEFF0
000073ef1c5cecfb  nop [rax+rax*1], ax
000073ef1c5ced04  nop [rax+rax*1], eax
000073ef1c5ced0c  mov eax, 0x4101EC
000073ef1c5ced11  mov [r15+0x100], rax
000073ef1c5ced18  jmp 0x000073EF1C3FE110
000073ef1c5ced1d  cmp dword ptr [r15+0x318], 0x00
000073ef1c5ced25  jz 0x000073EF1C5CEBA0
000073ef1c5ced2b  nop [rax+rax*1], ax
000073ef1c5ced34  nop [rax+rax*1], eax
000073ef1c5ced3c  mov eax, 0x4101AC
000073ef1c5ced41  mov [r15+0x100], rax
000073ef1c5ced48  jmp 0x000073EF1C3FE110
000073ef1c5ced4d  int3
000073ef1c5ced4e  sub rsp, 0x08
000073ef1c5ced52  push rax
000073ef1c5ced53  push rcx
000073ef1c5ced54  push rdx
000073ef1c5ced55  push rdi
000073ef1c5ced56  push rsi
000073ef1c5ced57  push r8
000073ef1c5ced59  push r9
000073ef1c5ced5b  push r10
000073ef1c5ced5d  push r11
000073ef1c5ced5f  sub rsp, 0xF0
000073ef1c5ced66  vmovaps [rsp], xmm0
000073ef1c5ced6b  vmovaps [rsp+0x10], xmm1
000073ef1c5ced71  vmovaps [rsp+0x20], xmm2
000073ef1c5ced77  vmovaps [rsp+0x30], xmm3
000073ef1c5ced7d  vmovaps [rsp+0x40], xmm4
000073ef1c5ced83  vmovaps [rsp+0x50], xmm5
000073ef1c5ced89  vmovaps [rsp+0x60], xmm6
000073ef1c5ced8f  vmovaps [rsp+0x70], xmm7
000073ef1c5ced95  vmovaps [rsp+0x80], xmm8
000073ef1c5ced9e  vmovaps [rsp+0x90], xmm9
000073ef1c5ceda7  vmovaps [rsp+0xA0], xmm10
000073ef1c5cedb0  vmovaps [rsp+0xB0], xmm11
000073ef1c5cedb9  vmovaps [rsp+0xC0], xmm12
000073ef1c5cedc2  vmovaps [rsp+0xD0], xmm14
000073ef1c5cedcb  vmovaps [rsp+0xE0], xmm15
000073ef1c5cedd4  sub rsp, 0x30
000073ef1c5cedd8  movaps [rsp], xmm13
000073ef1c5ceddd  movaps [rsp+0x10], xmm15
000073ef1c5cede3  movaps [rsp+0x20], xmm14
000073ef1c5cede9  lea rdi, [rsp]
000073ef1c5ceded  mov esi, 0x00
000073ef1c5cedf2  mov rax, 0x56F25E118530
000073ef1c5cedfc  call rax
000073ef1c5cedfe  movaps xmm13, [rsp]
000073ef1c5cee03  add rsp, 0x30
000073ef1c5cee07  vmovaps xmm0, [rsp]
000073ef1c5cee0c  vmovaps xmm1, [rsp+0x10]
000073ef1c5cee12  vmovaps xmm2, [rsp+0x20]
000073ef1c5cee18  vmovaps xmm3, [rsp+0x30]
000073ef1c5cee1e  vmovaps xmm4, [rsp+0x40]
000073ef1c5cee24  vmovaps xmm5, [rsp+0x50]
000073ef1c5cee2a  vmovaps xmm6, [rsp+0x60]
000073ef1c5cee30  vmovaps xmm7, [rsp+0x70]
000073ef1c5cee36  vmovaps xmm8, [rsp+0x80]
000073ef1c5cee3f  vmovaps xmm9, [rsp+0x90]
000073ef1c5cee48  vmovaps xmm10, [rsp+0xA0]
000073ef1c5cee51  vmovaps xmm11, [rsp+0xB0]
000073ef1c5cee5a  vmovaps xmm12, [rsp+0xC0]
000073ef1c5cee63  vmovaps xmm14, [rsp+0xD0]
000073ef1c5cee6c  vmovaps xmm15, [rsp+0xE0]
000073ef1c5cee75  add rsp, 0xF0
000073ef1c5cee7c  pop r11
000073ef1c5cee7e  pop r10
000073ef1c5cee80  pop r9
000073ef1c5cee82  pop r8
000073ef1c5cee84  pop rsi
000073ef1c5cee85  pop rdi
000073ef1c5cee86  pop rdx
000073ef1c5cee87  pop rcx
000073ef1c5cee88  pop rax
000073ef1c5cee89  add rsp, 0x08
000073ef1c5cee8d  jmp 0x000073EF1C5CEC71
000073ef1c5cee92  call 0x000073EF1C4C2240
000073ef1c5cee97  jmp 0x000073EF1C5CEC8B
000073ef1c5cee9c  sub rsp, 0x08
000073ef1c5ceea0  push rax
000073ef1c5ceea1  push rcx
000073ef1c5ceea2  push rdx
000073ef1c5ceea3  push rdi
000073ef1c5ceea4  push rsi
000073ef1c5ceea5  push r8
000073ef1c5ceea7  push r9
000073ef1c5ceea9  push r10
000073ef1c5ceeab  push r11
000073ef1c5ceead  sub rsp, 0xF0
000073ef1c5ceeb4  vmovaps [rsp], xmm0
000073ef1c5ceeb9  vmovaps [rsp+0x10], xmm1
000073ef1c5ceebf  vmovaps [rsp+0x20], xmm2
000073ef1c5ceec5  vmovaps [rsp+0x30], xmm3
000073ef1c5ceecb  vmovaps [rsp+0x40], xmm4
000073ef1c5ceed1  vmovaps [rsp+0x50], xmm5
000073ef1c5ceed7  vmovaps [rsp+0x60], xmm6
000073ef1c5ceedd  vmovaps [rsp+0x70], xmm7
000073ef1c5ceee3  vmovaps [rsp+0x80], xmm8
000073ef1c5ceeec  vmovaps [rsp+0x90], xmm9
000073ef1c5ceef5  vmovaps [rsp+0xA0], xmm10
000073ef1c5ceefe  vmovaps [rsp+0xB0], xmm11
000073ef1c5cef07  vmovaps [rsp+0xC0], xmm12
000073ef1c5cef10  vmovaps [rsp+0xD0], xmm13
000073ef1c5cef19  vmovaps [rsp+0xE0], xmm15
000073ef1c5cef22  sub rsp, 0x30
000073ef1c5cef26  movaps [rsp], xmm14
000073ef1c5cef2b  movaps [rsp+0x10], xmm1
000073ef1c5cef30  movaps [rsp+0x20], xmm15
000073ef1c5cef36  lea rdi, [rsp]
000073ef1c5cef3a  mov esi, 0x00
000073ef1c5cef3f  mov rax, 0x56F25E118530
000073ef1c5cef49  call rax
000073ef1c5cef4b  movaps xmm14, [rsp]
000073ef1c5cef50  add rsp, 0x30
000073ef1c5cef54  vmovaps xmm0, [rsp]
000073ef1c5cef59  vmovaps xmm1, [rsp+0x10]
000073ef1c5cef5f  vmovaps xmm2, [rsp+0x20]
000073ef1c5cef65  vmovaps xmm3, [rsp+0x30]
000073ef1c5cef6b  vmovaps xmm4, [rsp+0x40]
000073ef1c5cef71  vmovaps xmm5, [rsp+0x50]
000073ef1c5cef77  vmovaps xmm6, [rsp+0x60]
000073ef1c5cef7d  vmovaps xmm7, [rsp+0x70]
000073ef1c5cef83  vmovaps xmm8, [rsp+0x80]
000073ef1c5cef8c  vmovaps xmm9, [rsp+0x90]
000073ef1c5cef95  vmovaps xmm10, [rsp+0xA0]
000073ef1c5cef9e  vmovaps xmm11, [rsp+0xB0]
000073ef1c5cefa7  vmovaps xmm12, [rsp+0xC0]
000073ef1c5cefb0  vmovaps xmm13, [rsp+0xD0]
000073ef1c5cefb9  vmovaps xmm15, [rsp+0xE0]
000073ef1c5cefc2  add rsp, 0xF0
000073ef1c5cefc9  pop r11
000073ef1c5cefcb  pop r10
000073ef1c5cefcd  pop r9
000073ef1c5cefcf  pop r8
000073ef1c5cefd1  pop rsi
000073ef1c5cefd2  pop rdi
000073ef1c5cefd3  pop rdx
000073ef1c5cefd4  pop rcx
000073ef1c5cefd5  pop rax
000073ef1c5cefd6  add rsp, 0x08
000073ef1c5cefda  jmp 0x000073EF1C5CECAE
000073ef1c5cefdf  call 0x000073EF1C4C34C0
000073ef1c5cefe4  jmp 0x000073EF1C5CECC4
000073ef1c5cefe9  int3
000073ef1c5cefea  nop [rax+rax*1], ax
000073ef1c5ceff0  mov rax, [r15+0xF8]
000073ef1c5ceff7  lea r14, [rax-0x150]
000073ef1c5ceffe  mov [r15+0xF8], r14
000073ef1c5cf005  mov rax, [r15+0x50]
000073ef1c5cf009  lea r12, [rax+0x80]
000073ef1c5cf010  movups xmm1, [r13+r12*1]
000073ef1c5cf016  lea r12, [rax+0x90]
000073ef1c5cf01d  movups xmm15, [r13+r12*1]
000073ef1c5cf023  mov qword ptr [r15+0x48], 0x00
000073ef1c5cf02b  lea r12, [rax+0x40]
000073ef1c5cf02f  movups xmm14, [r13+r12*1]
000073ef1c5cf035  lea r12, [rax+0x50]
000073ef1c5cf039  movups xmm13, [r13+r12*1]
000073ef1c5cf03f  lea r12, [r14+0x120]
000073ef1c5cf046  movq xmm12, qword ptr [r15+0x1C0]
000073ef1c5cf04f  movq xmm11, qword ptr [r15+0x1B0]
000073ef1c5cf058  movq r11, xmm12
000073ef1c5cf05d  movq r10, xmm11
000073ef1c5cf062  mov [r13+r12*1], r11
000073ef1c5cf067  lea r12, [r14+0x128]
000073ef1c5cf06e  mov [r13+r12*1], r10
000073ef1c5cf073  vxorps xmm12, xmm12, xmm12
000073ef1c5cf078  vpbroadcastq xmm12, xmm12
000073ef1c5cf07d  lea r12, [r14+0x100]
000073ef1c5cf084  movq xmm11, qword ptr [r15+0x200]
000073ef1c5cf08d  movq xmm10, qword ptr [r15+0x1F0]
000073ef1c5cf096  movq r11, xmm11
000073ef1c5cf09b  movq r10, xmm10
000073ef1c5cf0a0  mov [r13+r12*1], r11
000073ef1c5cf0a5  lea r12, [r14+0x108]
000073ef1c5cf0ac  mov [r13+r12*1], r10
000073ef1c5cf0b1  lea r12, [r14+0xE0]
000073ef1c5cf0b8  movups [r13+r12*1], xmm15
000073ef1c5cf0be  lea r12, [r14+0xF0]
000073ef1c5cf0c5  movups [r13+r12*1], xmm1
000073ef1c5cf0cb  lea r12, [rax+0xC0]
000073ef1c5cf0d2  movups xmm1, [r13+r12*1]
000073ef1c5cf0d8  lea r12, [rax+0xD0]
000073ef1c5cf0df  movups xmm15, [r13+r12*1]
000073ef1c5cf0e5  lea r12, [r14+0x110]
000073ef1c5cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000073ef1c5cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000073ef1c5cf0fe  movq r11, xmm11
000073ef1c5cf103  movq r10, xmm10
000073ef1c5cf108  mov [r13+r12*1], r11
000073ef1c5cf10d  lea r12, [r14+0x118]
000073ef1c5cf114  mov [r13+r12*1], r10
000073ef1c5cf119  movups xmm11, [r13+rax*1]
000073ef1c5cf11f  lea r12, [rax+0x10]
000073ef1c5cf123  movups xmm10, [r13+r12*1]
000073ef1c5cf129  lea r12, [r14+0x130]
000073ef1c5cf130  movq xmm9, qword ptr [r15+0x1A0]
000073ef1c5cf139  movq xmm8, qword ptr [r15+0x190]
000073ef1c5cf142  movq r11, xmm9
000073ef1c5cf147  movq r10, xmm8
000073ef1c5cf14c  mov [r13+r12*1], r11
000073ef1c5cf151  lea r12, [r14+0x138]
000073ef1c5cf158  mov [r13+r12*1], r10
000073ef1c5cf15d  lea r12, [rax+0x140]
000073ef1c5cf164  movups xmm9, [r13+r12*1]
000073ef1c5cf16a  lea r12, [rax+0x150]
000073ef1c5cf171  movups xmm8, [r13+r12*1]
000073ef1c5cf177  lea r12, [r14+0xC0]
000073ef1c5cf17e  movups [r13+r12*1], xmm15
000073ef1c5cf184  lea r12, [r14+0xD0]
000073ef1c5cf18b  movups [r13+r12*1], xmm1
000073ef1c5cf191  lea r12, [rax+0x100]
000073ef1c5cf198  movups xmm1, [r13+r12*1]
000073ef1c5cf19e  lea r12, [rax+0x110]
000073ef1c5cf1a5  movups xmm15, [r13+r12*1]
000073ef1c5cf1ab  lea r12, [r14+0x140]
000073ef1c5cf1b2  mov r11, [r15+0xE8]
000073ef1c5cf1b9  mov [r13+r12*1], r11
000073ef1c5cf1be  lea r12, [rax+0x180]
000073ef1c5cf1c5  movups xmm7, [r13+r12*1]
000073ef1c5cf1cb  lea r12, [rax+0x190]
000073ef1c5cf1d2  movups xmm6, [r13+r12*1]
000073ef1c5cf1d8  lea r12, [rax+0x1C0]
000073ef1c5cf1df  movups xmm5, [r13+r12*1]
000073ef1c5cf1e5  lea r12, [rax+0x1D0]
000073ef1c5cf1ec  movups xmm4, [r13+r12*1]
000073ef1c5cf1f2  lea r12, [r14+0x20]
000073ef1c5cf1f6  movups [r13+r12*1], xmm1
000073ef1c5cf1fc  lea r12, [r14+0x30]
000073ef1c5cf200  movups [r13+r12*1], xmm13
000073ef1c5cf206  lea r12, [rax+0x60]
000073ef1c5cf20a  movups xmm1, [r13+r12*1]
000073ef1c5cf210  lea r12, [rax+0x70]
000073ef1c5cf214  movups xmm13, [r13+r12*1]
000073ef1c5cf21a  lea r12, [rax+0x20]
000073ef1c5cf21e  movups xmm3, [r13+r12*1]
000073ef1c5cf224  lea r12, [rax+0x30]
000073ef1c5cf228  movups xmm2, [r13+r12*1]
000073ef1c5cf22e  movaps [r15+0x1F0], xmm2
000073ef1c5cf236  lea r12, [r14+0x60]
000073ef1c5cf23a  movups [r13+r12*1], xmm11
000073ef1c5cf240  lea r12, [r14+0x70]
000073ef1c5cf244  movups [r13+r12*1], xmm5
000073ef1c5cf24a  lea r12, [rax+0xE0]
000073ef1c5cf251  movups xmm11, [r13+r12*1]
000073ef1c5cf257  lea r12, [rax+0xF0]
000073ef1c5cf25e  movups xmm5, [r13+r12*1]
000073ef1c5cf264  lea r12, [r14+0xA0]
000073ef1c5cf26b  movups [r13+r12*1], xmm13
000073ef1c5cf271  lea r12, [r14+0xB0]
000073ef1c5cf278  movups [r13+r12*1], xmm1
000073ef1c5cf27e  lea r12, [rax+0xA0]
000073ef1c5cf285  movups xmm1, [r13+r12*1]
000073ef1c5cf28b  lea r12, [rax+0xB0]
000073ef1c5cf292  movups xmm13, [r13+r12*1]
000073ef1c5cf298  lea r12, [rax+0x120]
000073ef1c5cf29f  vmovaps [rsp+0x10], xmm1
000073ef1c5cf2a5  movups xmm1, [r13+r12*1]
000073ef1c5cf2ab  lea r12, [rax+0x130]
000073ef1c5cf2b2  vmovaps [rsp+0x20], xmm1
000073ef1c5cf2b8  movups xmm1, [r13+r12*1]
000073ef1c5cf2be  lea r12, [rax+0x160]
000073ef1c5cf2c5  vmovaps [rsp+0x30], xmm1
000073ef1c5cf2cb  movups xmm1, [r13+r12*1]
000073ef1c5cf2d1  lea r12, [rax+0x170]
000073ef1c5cf2d8  vmovaps [rsp+0x40], xmm1
000073ef1c5cf2de  movups xmm1, [r13+r12*1]
000073ef1c5cf2e4  movaps [r15+0x2B0], xmm1
000073ef1c5cf2ec  lea r12, [r14+0x80]
000073ef1c5cf2f3  movups [r13+r12*1], xmm13
000073ef1c5cf2f9  lea r12, [r14+0x90]
000073ef1c5cf300  vmovaps xmm13, [rsp+0x10]
000073ef1c5cf306  movups [r13+r12*1], xmm13
000073ef1c5cf30c  lea r12, [rax+0x1A0]
000073ef1c5cf313  movups xmm13, [r13+r12*1]
000073ef1c5cf319  lea r12, [rax+0x1B0]
000073ef1c5cf320  vmovaps [rsp+0x10], xmm1
000073ef1c5cf326  movups xmm1, [r13+r12*1]
000073ef1c5cf32c  movaps [r15+0x290], xmm13
000073ef1c5cf334  movaps [r15+0x1E0], xmm1
000073ef1c5cf33c  lea r12, [rax+0x1E0]
000073ef1c5cf343  vmovaps [rsp+0x50], xmm1
000073ef1c5cf349  movups xmm1, [r13+r12*1]
000073ef1c5cf34f  lea r12, [rax+0x1F0]
000073ef1c5cf356  vmovaps [rsp+0x60], xmm1
000073ef1c5cf35c  movups xmm1, [r13+r12*1]
000073ef1c5cf362  mov qword ptr [r15+0x50], 0x430920
000073ef1c5cf36a  lea rax, [r14+0x40]
000073ef1c5cf36e  vmovaps [rsp+0x70], xmm1
000073ef1c5cf374  vmovaps xmm1, [rsp+0x40]
000073ef1c5cf37a  movups [r13+rax*1], xmm1
000073ef1c5cf380  lea rax, [r14+0x50]
000073ef1c5cf384  movups [r13+rax*1], xmm10
000073ef1c5cf38a  vmovaps xmm1, [rsp+0x70]
000073ef1c5cf390  movups [r13+r14*1], xmm1
000073ef1c5cf396  lea rax, [r14+0x10]
000073ef1c5cf39a  vmovaps xmm1, [rsp+0x60]
000073ef1c5cf3a0  movups [r13+rax*1], xmm1
000073ef1c5cf3a6  mov rax, [r15+0x40]
000073ef1c5cf3aa  vmovaps [rsp+0x40], xmm3
000073ef1c5cf3b0  vmovaps xmm1, [rsp+0x40]
000073ef1c5cf3b6  por xmm3, xmm1
000073ef1c5cf3ba  vmovaps [rsp+0x40], xmm6
000073ef1c5cf3c0  vmovaps xmm10, [rsp+0x40]
000073ef1c5cf3c6  por xmm6, xmm10
000073ef1c5cf3cb  lea r12, [rax+0x30]
000073ef1c5cf3cf  mov r11, [r13+r12*1]
000073ef1c5cf3d4  lea r12, [rax+0x38]
000073ef1c5cf3d8  mov r10, [r13+r12*1]
000073ef1c5cf3dd  movq xmm10, r11
000073ef1c5cf3e2  vmovaps [rsp+0x40], xmm1
000073ef1c5cf3e8  movq xmm1, r10
000073ef1c5cf3ed  movq xmm10, xmm10
000073ef1c5cf3f2  vmovaps [rsp+0x60], xmm10
000073ef1c5cf3f8  movq xmm10, xmm10
000073ef1c5cf3fd  movaps [r15+0x130], xmm10
000073ef1c5cf405  movq xmm1, xmm1
000073ef1c5cf409  vmovaps [rsp+0x70], xmm1
000073ef1c5cf40f  movq xmm1, xmm1
000073ef1c5cf413  movaps [r15+0x280], xmm1
000073ef1c5cf41b  vmovaps [rsp+0x80], xmm9
000073ef1c5cf424  vmovaps xmm1, [rsp+0x80]
000073ef1c5cf42d  por xmm9, xmm1
000073ef1c5cf432  lea r12, [rax+0x20]
000073ef1c5cf436  mov r11, [r13+r12*1]
000073ef1c5cf43b  lea r12, [rax+0x28]
000073ef1c5cf43f  mov r10, [r13+r12*1]
000073ef1c5cf444  movq xmm1, r11
000073ef1c5cf449  movq xmm10, r10
000073ef1c5cf44e  movq xmm1, xmm1
000073ef1c5cf452  vmovaps [rsp+0x80], xmm1
000073ef1c5cf45b  movq xmm1, xmm1
000073ef1c5cf45f  movaps [r15+0x150], xmm1
000073ef1c5cf467  movq xmm10, xmm10
000073ef1c5cf46c  vmovaps [rsp+0x90], xmm10
000073ef1c5cf475  movq xmm10, xmm10
000073ef1c5cf47a  movaps [r15+0x140], xmm10
000073ef1c5cf482  lea r12, [rax+0x10]
000073ef1c5cf486  mov r11, [r13+r12*1]
000073ef1c5cf48b  lea r12, [rax+0x18]
000073ef1c5cf48f  mov r10, [r13+r12*1]
000073ef1c5cf494  movq xmm1, r11
000073ef1c5cf499  movq xmm10, r10
000073ef1c5cf49e  movq xmm1, xmm1
000073ef1c5cf4a2  vmovaps [rsp+0xA0], xmm1
000073ef1c5cf4ab  movq xmm1, xmm1
000073ef1c5cf4af  movaps [r15+0x170], xmm1
000073ef1c5cf4b7  movq xmm10, xmm10
000073ef1c5cf4bc  vmovaps [rsp+0xB0], xmm10
000073ef1c5cf4c5  movq xmm10, xmm10
000073ef1c5cf4ca  movaps [r15+0x160], xmm10
000073ef1c5cf4d2  mov r12, [r13+rax*1]
000073ef1c5cf4d7  vmovq xmm1, r12
000073ef1c5cf4dc  vpbroadcastq xmm1, xmm1
000073ef1c5cf4e1  lea r12, [rax+0x08]
000073ef1c5cf4e5  mov rax, [r13+r12*1]
000073ef1c5cf4ea  movq xmm10, rax
000073ef1c5cf4ef  movaps [r15+0x230], xmm10
000073ef1c5cf4f7  lea rax, [r14+0x50]
000073ef1c5cf4fb  movups xmm10, [r13+rax*1]
000073ef1c5cf501  lea rax, [r14+0x60]
000073ef1c5cf505  vmovaps [rsp+0xC0], xmm1
000073ef1c5cf50e  movups xmm1, [r13+rax*1]
000073ef1c5cf514  lea rax, [r14+0x30]
000073ef1c5cf518  vmovaps [rsp+0xD0], xmm1
000073ef1c5cf521  movups xmm1, [r13+rax*1]
000073ef1c5cf527  mov qword ptr [r15+0x60], 0x430920
000073ef1c5cf52f  mov qword ptr [r15+0x58], 0x40
000073ef1c5cf537  vmovaps [rsp+0xE0], xmm1
000073ef1c5cf540  vmovaps [rsp+0xF0], xmm15
000073ef1c5cf549  vmovaps xmm15, [rsp+0xC0]
000073ef1c5cf552  vmovaps [rsp+0xC0], xmm14
000073ef1c5cf55b  vmovaps xmm14, [rsp+0x40]
000073ef1c5cf561  vmovaps [rsp+0x40], xmm13
000073ef1c5cf567  movaps xmm1, xmm15
000073ef1c5cf56b  mulpd xmm1, xmm14
000073ef1c5cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000073ef1c5cf575  ptest xmm13, xmm13
000073ef1c5cf57b  jnz 0x000073EF1C5D0682
000073ef1c5cf581  movq xmm14, qword ptr [r15+0x230]
000073ef1c5cf58a  vmovaps [rsp+0x100], xmm14
000073ef1c5cf593  vpermilpd xmm14, xmm14, 0x00
000073ef1c5cf599  vmovaps [rsp+0x110], xmm1
000073ef1c5cf5a2  vmovaps xmm1, [rsp+0xE0]
000073ef1c5cf5ab  vmovaps [rsp+0xE0], xmm15
000073ef1c5cf5b4  movaps xmm13, xmm1
000073ef1c5cf5b8  mulpd xmm13, xmm14
000073ef1c5cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000073ef1c5cf5c3  ptest xmm15, xmm15
000073ef1c5cf5c9  jnz 0x000073EF1C5D07C4
000073ef1c5cf5cf  vxorps xmm1, xmm1, xmm1
000073ef1c5cf5d3  vpbroadcastq xmm1, xmm1
000073ef1c5cf5d8  vmovaps xmm14, [rsp+0xE0]
000073ef1c5cf5e1  vmovaps [rsp+0xE0], xmm1
000073ef1c5cf5ea  vmovaps xmm1, [rsp+0xD0]
000073ef1c5cf5f3  vmovaps [rsp+0xD0], xmm13
000073ef1c5cf5fc  movaps xmm15, xmm14
000073ef1c5cf600  mulpd xmm15, xmm1
000073ef1c5cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000073ef1c5cf60b  ptest xmm13, xmm13
000073ef1c5cf611  jnz 0x000073EF1C5D0907
000073ef1c5cf617  movaps xmm1, xmm14
000073ef1c5cf61b  mulpd xmm1, xmm10
000073ef1c5cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000073ef1c5cf625  ptest xmm13, xmm13
000073ef1c5cf62b  jnz 0x000073EF1C5D0A4A
000073ef1c5cf631  movaps xmm13, xmm14
000073ef1c5cf635  mulpd xmm13, xmm2
000073ef1c5cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000073ef1c5cf640  ptest xmm10, xmm10
000073ef1c5cf646  jnz 0x000073EF1C5D0B8C
000073ef1c5cf64c  vmovaps [rsp+0x120], xmm7
000073ef1c5cf655  vmovaps xmm14, [rsp+0x120]
000073ef1c5cf65e  por xmm7, xmm14
000073ef1c5cf663  vmovaps xmm14, [rsp+0xC0]
000073ef1c5cf66c  vmovaps xmm10, [rsp+0xC0]
000073ef1c5cf675  por xmm14, xmm10
000073ef1c5cf67a  vmovaps xmm2, [rsp+0x100]
000073ef1c5cf683  vpermilpd xmm2, xmm2, 0x00
000073ef1c5cf689  vmovaps [rsp+0xC0], xmm1
000073ef1c5cf692  vmovaps [rsp+0x120], xmm15
000073ef1c5cf69b  movaps xmm1, xmm10
000073ef1c5cf69f  mulpd xmm1, xmm2
000073ef1c5cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000073ef1c5cf6a8  ptest xmm15, xmm15
000073ef1c5cf6ae  jnz 0x000073EF1C5D0CCF
000073ef1c5cf6b4  xor eax, eax
000073ef1c5cf6b6  mov r12d, 0x40
000073ef1c5cf6bc  mov r11d, 0x200
000073ef1c5cf6c2  cmp r12, r11
000073ef1c5cf6c5  cmc
000073ef1c5cf6c6  lahf
000073ef1c5cf6c7  seto al
000073ef1c5cf6ca  mov [r15+0x108], eax
000073ef1c5cf6d1  vmovaps xmm10, [rsp+0x110]
000073ef1c5cf6da  vmovaps xmm2, [rsp+0xE0]
000073ef1c5cf6e3  vmovaps [rsp+0xE0], xmm1
000073ef1c5cf6ec  movaps xmm15, xmm10
000073ef1c5cf6f0  addpd xmm15, xmm2
000073ef1c5cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000073ef1c5cf6fb  ptest xmm1, xmm1
000073ef1c5cf700  jnz 0x000073EF1C5D0E10
000073ef1c5cf706  vmovaps xmm10, [rsp+0x120]
000073ef1c5cf70f  vmovaps [rsp+0x110], xmm15
000073ef1c5cf718  movaps xmm1, xmm10
000073ef1c5cf71c  addpd xmm1, xmm12
000073ef1c5cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000073ef1c5cf726  ptest xmm15, xmm15
000073ef1c5cf72c  jnz 0x000073EF1C5D0F53
000073ef1c5cf732  vmovaps xmm10, [rsp+0xC0]
000073ef1c5cf73b  vmovaps [rsp+0xC0], xmm1
000073ef1c5cf744  movaps xmm15, xmm10
000073ef1c5cf748  addpd xmm15, xmm12
000073ef1c5cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000073ef1c5cf753  ptest xmm1, xmm1
000073ef1c5cf758  jnz 0x000073EF1C5D1095
000073ef1c5cf75e  vmovaps xmm1, [rsp+0x30]
000073ef1c5cf764  vmovaps xmm12, [rsp+0x30]
000073ef1c5cf76a  por xmm1, xmm12
000073ef1c5cf76f  vmovaps xmm12, [rsp+0x20]
000073ef1c5cf775  vmovaps xmm10, [rsp+0x20]
000073ef1c5cf77b  por xmm12, xmm10
000073ef1c5cf780  vmovaps [rsp+0x20], xmm5
000073ef1c5cf786  vmovaps xmm10, [rsp+0x20]
000073ef1c5cf78c  por xmm5, xmm10
000073ef1c5cf791  vmovaps [rsp+0x20], xmm11
000073ef1c5cf797  vmovaps xmm10, [rsp+0x20]
000073ef1c5cf79d  por xmm11, xmm10
000073ef1c5cf7a2  vmovaps [rsp+0x20], xmm4
000073ef1c5cf7a8  vmovaps xmm10, [rsp+0x20]
000073ef1c5cf7ae  por xmm4, xmm10
000073ef1c5cf7b3  vmovaps [rsp+0x20], xmm8
000073ef1c5cf7b9  vmovaps xmm10, [rsp+0x20]
000073ef1c5cf7bf  por xmm8, xmm10
000073ef1c5cf7c4  vmovaps xmm10, [rsp+0xF0]
000073ef1c5cf7cd  vmovaps [rsp+0x20], xmm1
000073ef1c5cf7d3  vmovaps xmm1, [rsp+0xF0]
000073ef1c5cf7dc  por xmm10, xmm1
000073ef1c5cf7e1  lea rax, [r14+0xA0]
000073ef1c5cf7e8  movups xmm1, [r13+rax*1]
000073ef1c5cf7ee  lea rax, [r14+0xB0]
000073ef1c5cf7f5  vmovaps [rsp+0x30], xmm1
000073ef1c5cf7fb  movups xmm1, [r13+rax*1]
000073ef1c5cf801  vmovaps [rsp+0xF0], xmm1
000073ef1c5cf80a  vmovaps [rsp+0x120], xmm15
000073ef1c5cf813  movaps xmm1, xmm13
000073ef1c5cf817  addpd xmm1, xmm2
000073ef1c5cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000073ef1c5cf820  ptest xmm15, xmm15
000073ef1c5cf826  jnz 0x000073EF1C5D11ED
000073ef1c5cf82c  lea rax, [r14+0xF0]
000073ef1c5cf833  movups xmm15, [r13+rax*1]
000073ef1c5cf839  vmovaps xmm2, [rsp+0xC0]
000073ef1c5cf842  vmovaps [rsp+0xC0], xmm1
000073ef1c5cf84b  vmovaps xmm1, [rsp+0xE0]
000073ef1c5cf854  vmovaps [rsp+0xE0], xmm15
000073ef1c5cf85d  movaps xmm13, xmm2
000073ef1c5cf861  addpd xmm13, xmm1
000073ef1c5cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000073ef1c5cf86c  ptest xmm15, xmm15
000073ef1c5cf872  jnz 0x000073EF1C5D1338
000073ef1c5cf878  vmovaps xmm15, [rsp+0x120]
000073ef1c5cf881  vmovaps xmm2, [rsp+0xD0]
000073ef1c5cf88a  vmovaps [rsp+0xD0], xmm14
000073ef1c5cf893  movaps xmm1, xmm15
000073ef1c5cf897  addpd xmm1, xmm2
000073ef1c5cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000073ef1c5cf8a0  ptest xmm14, xmm14
000073ef1c5cf8a6  jnz 0x000073EF1C5D147A
000073ef1c5cf8ac  vmovaps xmm15, [rsp+0x100]
000073ef1c5cf8b5  vpermilpd xmm15, xmm15, 0x00
000073ef1c5cf8bb  vmovaps xmm2, [rsp+0xF0]
000073ef1c5cf8c4  vmovaps [rsp+0xF0], xmm1
000073ef1c5cf8cd  movaps xmm14, xmm2
000073ef1c5cf8d1  mulpd xmm14, xmm15
000073ef1c5cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000073ef1c5cf8dc  ptest xmm1, xmm1
000073ef1c5cf8e1  jnz 0x000073EF1C5D15BB
000073ef1c5cf8e7  vmovaps xmm1, [rsp+0xA0]
000073ef1c5cf8f0  vpermilpd xmm1, xmm1, 0x00
000073ef1c5cf8f6  vmovaps xmm2, [rsp+0xE0]
000073ef1c5cf8ff  vmovaps [rsp+0xE0], xmm14
000073ef1c5cf908  movaps xmm15, xmm2
000073ef1c5cf90c  mulpd xmm15, xmm1
000073ef1c5cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000073ef1c5cf917  ptest xmm14, xmm14
000073ef1c5cf91d  jnz 0x000073EF1C5D16FE
000073ef1c5cf923  lea rax, [r14+0xE0]
000073ef1c5cf92a  movups xmm1, [r13+rax*1]
000073ef1c5cf930  vmovaps xmm14, [rsp+0x100]
000073ef1c5cf939  vpermilpd xmm14, xmm14, 0x00
000073ef1c5cf93f  vmovaps [rsp+0x100], xmm1
000073ef1c5cf948  vmovaps xmm1, [rsp+0x30]
000073ef1c5cf94e  vmovaps [rsp+0x30], xmm15
000073ef1c5cf954  movaps xmm2, xmm1
000073ef1c5cf957  mulpd xmm2, xmm14
000073ef1c5cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000073ef1c5cf961  ptest xmm15, xmm15
000073ef1c5cf967  jnz 0x000073EF1C5D184A
000073ef1c5cf96d  vmovaps [rsp+0x120], xmm10
000073ef1c5cf976  vmovaps xmm1, [rsp+0x120]
000073ef1c5cf97f  por xmm10, xmm1
000073ef1c5cf984  movaps [r15+0x300], xmm10
000073ef1c5cf98c  vmovaps [rsp+0x120], xmm8
000073ef1c5cf995  vmovaps xmm1, [rsp+0x120]
000073ef1c5cf99e  por xmm8, xmm1
000073ef1c5cf9a3  movaps [r15+0x190], xmm8
000073ef1c5cf9ab  vmovaps xmm1, [rsp+0xA0]
000073ef1c5cf9b4  vpermilpd xmm1, xmm1, 0x00
000073ef1c5cf9ba  vmovaps xmm14, [rsp+0x100]
000073ef1c5cf9c3  vmovaps [rsp+0x100], xmm13
000073ef1c5cf9cc  movaps xmm15, xmm14
000073ef1c5cf9d0  mulpd xmm15, xmm1
000073ef1c5cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000073ef1c5cf9db  ptest xmm13, xmm13
000073ef1c5cf9e1  jnz 0x000073EF1C5D198B
000073ef1c5cf9e7  lea rax, [r14+0x90]
000073ef1c5cf9ee  movups xmm1, [r13+rax*1]
000073ef1c5cf9f4  vmovaps [rsp+0x120], xmm4
000073ef1c5cf9fd  vmovaps xmm14, [rsp+0x120]
000073ef1c5cfa06  por xmm4, xmm14
000073ef1c5cfa0b  movaps [r15+0x1C0], xmm4
000073ef1c5cfa13  vmovaps [rsp+0x120], xmm11
000073ef1c5cfa1c  vmovaps xmm14, [rsp+0x120]
000073ef1c5cfa25  por xmm11, xmm14
000073ef1c5cfa2a  movaps [r15+0x200], xmm11
000073ef1c5cfa32  vmovaps [rsp+0x120], xmm5
000073ef1c5cfa3b  vmovaps xmm14, [rsp+0x120]
000073ef1c5cfa44  por xmm5, xmm14
000073ef1c5cfa49  movaps [r15+0x2D0], xmm5
000073ef1c5cfa51  vmovaps [rsp+0x120], xmm12
000073ef1c5cfa5a  vmovaps xmm14, [rsp+0x120]
000073ef1c5cfa63  por xmm12, xmm14
000073ef1c5cfa68  movaps [r15+0x2E0], xmm12
000073ef1c5cfa70  vmovaps xmm13, [rsp+0x110]
000073ef1c5cfa79  vmovaps [rsp+0x110], xmm1
000073ef1c5cfa82  vmovaps xmm1, [rsp+0xE0]
000073ef1c5cfa8b  vmovaps [rsp+0xE0], xmm15
000073ef1c5cfa94  movaps xmm14, xmm13
000073ef1c5cfa98  addpd xmm14, xmm1
000073ef1c5cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000073ef1c5cfaa3  ptest xmm15, xmm15
000073ef1c5cfaa9  jnz 0x000073EF1C5D1AD8
000073ef1c5cfaaf  vmovaps xmm1, [rsp+0xA0]
000073ef1c5cfab8  vpermilpd xmm1, xmm1, 0x00
000073ef1c5cfabe  vmovaps xmm13, [rsp+0x110]
000073ef1c5cfac7  vmovaps [rsp+0x110], xmm14
000073ef1c5cfad0  movaps xmm15, xmm13
000073ef1c5cfad4  mulpd xmm15, xmm1
000073ef1c5cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000073ef1c5cfadf  ptest xmm14, xmm14
000073ef1c5cfae5  jnz 0x000073EF1C5D1C1B
000073ef1c5cfaeb  lea rax, [r14+0x80]
000073ef1c5cfaf2  movups xmm1, [r13+rax*1]
000073ef1c5cfaf8  vmovaps xmm13, [rsp+0xC0]
000073ef1c5cfb01  vmovaps [rsp+0xC0], xmm1
000073ef1c5cfb0a  movaps xmm14, xmm13
000073ef1c5cfb0e  addpd xmm14, xmm2
000073ef1c5cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000073ef1c5cfb19  ptest xmm1, xmm1
000073ef1c5cfb1e  jnz 0x000073EF1C5D1D68
000073ef1c5cfb24  vmovaps xmm13, [rsp+0x100]
000073ef1c5cfb2d  vmovaps xmm2, [rsp+0x30]
000073ef1c5cfb33  vmovaps [rsp+0x30], xmm15
000073ef1c5cfb39  movaps xmm1, xmm13
000073ef1c5cfb3d  addpd xmm1, xmm2
000073ef1c5cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000073ef1c5cfb46  ptest xmm15, xmm15
000073ef1c5cfb4c  jnz 0x000073EF1C5D1EAB
000073ef1c5cfb52  vmovaps xmm15, [rsp+0x20]
000073ef1c5cfb58  vmovaps xmm13, [rsp+0x20]
000073ef1c5cfb5e  por xmm15, xmm13
000073ef1c5cfb63  movaps [r15+0x2F0], xmm15
000073ef1c5cfb6b  vmovaps xmm13, [rsp+0xA0]
000073ef1c5cfb74  vpermilpd xmm13, xmm13, 0x00
000073ef1c5cfb7a  vmovaps [rsp+0x20], xmm1
000073ef1c5cfb80  vmovaps xmm1, [rsp+0xC0]
000073ef1c5cfb89  vmovaps [rsp+0xA0], xmm15
000073ef1c5cfb92  movaps xmm2, xmm1
000073ef1c5cfb95  mulpd xmm2, xmm13
000073ef1c5cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000073ef1c5cfb9f  ptest xmm15, xmm15
000073ef1c5cfba5  jnz 0x000073EF1C5D1FEC
000073ef1c5cfbab  lea rax, [r14+0xD0]
000073ef1c5cfbb2  movups xmm1, [r13+rax*1]
000073ef1c5cfbb8  vmovaps xmm13, [rsp+0xF0]
000073ef1c5cfbc1  vmovaps [rsp+0xC0], xmm1
000073ef1c5cfbca  vmovaps xmm1, [rsp+0xE0]
000073ef1c5cfbd3  vmovaps [rsp+0xE0], xmm14
000073ef1c5cfbdc  movaps xmm15, xmm13
000073ef1c5cfbe0  addpd xmm15, xmm1
000073ef1c5cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000073ef1c5cfbeb  ptest xmm14, xmm14
000073ef1c5cfbf1  jnz 0x000073EF1C5D2137
000073ef1c5cfbf7  vmovaps xmm1, [rsp+0xB0]
000073ef1c5cfc00  vpermilpd xmm1, xmm1, 0x00
000073ef1c5cfc06  movaps xmm14, xmm11
000073ef1c5cfc0a  mulpd xmm14, xmm1
000073ef1c5cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000073ef1c5cfc15  ptest xmm13, xmm13
000073ef1c5cfc1b  jnz 0x000073EF1C5D227A
000073ef1c5cfc21  movaps [r15+0x260], xmm14
000073ef1c5cfc29  vxorps xmm1, xmm1, xmm1
000073ef1c5cfc2d  vpbroadcastq xmm1, xmm1
000073ef1c5cfc32  movaps [r15+0x1B0], xmm1
000073ef1c5cfc3a  vmovaps xmm1, [rsp+0xB0]
000073ef1c5cfc43  vpermilpd xmm1, xmm1, 0x00
000073ef1c5cfc49  vmovaps xmm11, [rsp+0xC0]
000073ef1c5cfc52  vmovaps [rsp+0xC0], xmm15
000073ef1c5cfc5b  movaps xmm13, xmm11
000073ef1c5cfc5f  mulpd xmm13, xmm1
000073ef1c5cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000073ef1c5cfc6a  ptest xmm15, xmm15
000073ef1c5cfc70  jnz 0x000073EF1C5D23BD
000073ef1c5cfc76  lea rax, [r14+0xC0]
000073ef1c5cfc7d  movups xmm1, [r13+rax*1]
000073ef1c5cfc83  vmovaps xmm11, [rsp+0x110]
000073ef1c5cfc8c  vmovaps [rsp+0xF0], xmm1
000073ef1c5cfc95  vmovaps xmm1, [rsp+0x30]
000073ef1c5cfc9b  vmovaps [rsp+0x30], xmm14
000073ef1c5cfca1  movaps xmm15, xmm11
000073ef1c5cfca5  addpd xmm15, xmm1
000073ef1c5cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000073ef1c5cfcb0  ptest xmm14, xmm14
000073ef1c5cfcb6  jnz 0x000073EF1C5D250A
000073ef1c5cfcbc  vmovaps [rsp+0x100], xmm9
000073ef1c5cfcc5  vmovaps xmm1, [rsp+0x100]
000073ef1c5cfcce  por xmm9, xmm1
000073ef1c5cfcd3  movaps [r15+0x270], xmm9
000073ef1c5cfcdb  vmovaps [rsp+0x100], xmm6
000073ef1c5cfce4  vmovaps xmm1, [rsp+0x100]
000073ef1c5cfced  por xmm6, xmm1
000073ef1c5cfcf1  movaps [r15+0x1A0], xmm6
000073ef1c5cfcf9  vmovaps xmm14, [rsp+0xB0]
000073ef1c5cfd02  vpermilpd xmm14, xmm14, 0x00
000073ef1c5cfd08  vmovaps xmm6, [rsp+0xF0]
000073ef1c5cfd11  vmovaps [rsp+0xF0], xmm1
000073ef1c5cfd1a  movaps xmm11, xmm6
000073ef1c5cfd1e  mulpd xmm11, xmm14
000073ef1c5cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000073ef1c5cfd29  ptest xmm1, xmm1
000073ef1c5cfd2e  jnz 0x000073EF1C5D264D
000073ef1c5cfd34  lea rax, [r14+0x20]
000073ef1c5cfd38  movups xmm1, [r13+rax*1]
000073ef1c5cfd3e  movaps [r15+0x110], xmm1
000073ef1c5cfd46  vmovaps xmm6, [rsp+0xE0]
000073ef1c5cfd4f  vmovaps [rsp+0xE0], xmm1
000073ef1c5cfd58  movaps xmm14, xmm6
000073ef1c5cfd5c  addpd xmm14, xmm2
000073ef1c5cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000073ef1c5cfd67  ptest xmm1, xmm1
000073ef1c5cfd6c  jnz 0x000073EF1C5D279A
000073ef1c5cfd72  vmovaps xmm1, [rsp+0xB0]
000073ef1c5cfd7b  vpermilpd xmm1, xmm1, 0x00
000073ef1c5cfd81  movaps xmm6, xmm5
000073ef1c5cfd84  mulpd xmm6, xmm1
000073ef1c5cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000073ef1c5cfd8d  ptest xmm2, xmm2
000073ef1c5cfd92  jnz 0x000073EF1C5D28DC
000073ef1c5cfd98  vmovaps xmm5, [rsp+0x20]
000073ef1c5cfd9e  movaps xmm1, xmm5
000073ef1c5cfda1  addpd xmm1, xmm13
000073ef1c5cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000073ef1c5cfdab  ptest xmm2, xmm2
000073ef1c5cfdb0  jnz 0x000073EF1C5D2A1C
000073ef1c5cfdb6  vmovaps xmm13, [rsp+0x80]
000073ef1c5cfdbf  vpermilpd xmm13, xmm13, 0x00
000073ef1c5cfdc5  vmovaps xmm2, [rsp+0xE0]
000073ef1c5cfdce  vmovaps [rsp+0x20], xmm1
000073ef1c5cfdd4  movaps xmm5, xmm2
000073ef1c5cfdd7  mulpd xmm5, xmm13
000073ef1c5cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000073ef1c5cfde1  ptest xmm1, xmm1
000073ef1c5cfde6  jnz 0x000073EF1C5D2B5D
000073ef1c5cfdec  vmovaps xmm1, [rsp+0x80]
000073ef1c5cfdf5  vpermilpd xmm1, xmm1, 0x00
000073ef1c5cfdfb  movaps xmm13, xmm10
000073ef1c5cfdff  mulpd xmm13, xmm1
000073ef1c5cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000073ef1c5cfe0a  ptest xmm2, xmm2
000073ef1c5cfe0f  jnz 0x000073EF1C5D2C9E
000073ef1c5cfe15  vmovaps xmm10, [rsp+0x30]
000073ef1c5cfe1b  movaps xmm1, xmm15
000073ef1c5cfe1f  addpd xmm1, xmm10
000073ef1c5cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000073ef1c5cfe29  ptest xmm2, xmm2
000073ef1c5cfe2e  jnz 0x000073EF1C5D2DE1
000073ef1c5cfe34  vmovaps xmm10, [rsp+0xC0]
000073ef1c5cfe3d  movaps xmm15, xmm10
000073ef1c5cfe41  addpd xmm15, xmm11
000073ef1c5cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000073ef1c5cfe4c  ptest xmm2, xmm2
000073ef1c5cfe51  jnz 0x000073EF1C5D2F23
000073ef1c5cfe57  vmovaps xmm11, [rsp+0x80]
000073ef1c5cfe60  vpermilpd xmm11, xmm11, 0x00
000073ef1c5cfe66  movaps xmm10, xmm12
000073ef1c5cfe6a  mulpd xmm10, xmm11
000073ef1c5cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000073ef1c5cfe75  ptest xmm2, xmm2
000073ef1c5cfe7a  jnz 0x000073EF1C5D3067
000073ef1c5cfe80  vmovaps xmm12, [rsp+0x80]
000073ef1c5cfe89  vpermilpd xmm12, xmm12, 0x00
000073ef1c5cfe8f  vmovaps xmm2, [rsp+0xA0]
000073ef1c5cfe98  vmovaps [rsp+0x30], xmm1
000073ef1c5cfe9e  movaps xmm11, xmm2
000073ef1c5cfea2  mulpd xmm11, xmm12
000073ef1c5cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000073ef1c5cfead  ptest xmm1, xmm1
000073ef1c5cfeb2  jnz 0x000073EF1C5D31AB
000073ef1c5cfeb8  movaps xmm1, xmm14
000073ef1c5cfebc  addpd xmm1, xmm6
000073ef1c5cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000073ef1c5cfec5  ptest xmm12, xmm12
000073ef1c5cfecb  jnz 0x000073EF1C5D32EE
000073ef1c5cfed1  vmovaps xmm12, [rsp+0x20]
000073ef1c5cfed7  movaps xmm14, xmm12
000073ef1c5cfedb  addpd xmm14, xmm5
000073ef1c5cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000073ef1c5cfee6  ptest xmm6, xmm6
000073ef1c5cfeeb  jnz 0x000073EF1C5D342F
000073ef1c5cfef1  vmovaps xmm12, [rsp+0x90]
000073ef1c5cfefa  vpermilpd xmm12, xmm12, 0x00
000073ef1c5cff00  movaps xmm6, xmm9
000073ef1c5cff04  mulpd xmm6, xmm12
000073ef1c5cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000073ef1c5cff0e  ptest xmm5, xmm5
000073ef1c5cff13  jnz 0x000073EF1C5D3572
000073ef1c5cff19  movaps xmm12, xmm15
000073ef1c5cff1d  addpd xmm12, xmm13
000073ef1c5cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000073ef1c5cff28  ptest xmm9, xmm9
000073ef1c5cff2e  jnz 0x000073EF1C5D36B4
000073ef1c5cff34  vmovaps xmm13, [rsp+0x30]
000073ef1c5cff3a  movaps xmm15, xmm13
000073ef1c5cff3e  addpd xmm15, xmm10
000073ef1c5cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000073ef1c5cff49  ptest xmm9, xmm9
000073ef1c5cff4f  jnz 0x000073EF1C5D37F8
000073ef1c5cff55  vmovaps xmm13, [rsp+0xD0]
000073ef1c5cff5e  vmovaps xmm10, [rsp+0xD0]
000073ef1c5cff67  por xmm13, xmm10
000073ef1c5cff6c  movaps [r15+0x250], xmm13
000073ef1c5cff74  vmovaps [rsp+0x20], xmm7
000073ef1c5cff7a  vmovaps xmm13, [rsp+0x20]
000073ef1c5cff80  por xmm7, xmm13
000073ef1c5cff85  movaps [r15+0x2A0], xmm7
000073ef1c5cff8d  vmovaps [rsp+0x20], xmm3
000073ef1c5cff93  vmovaps xmm13, [rsp+0x20]
000073ef1c5cff99  por xmm3, xmm13
000073ef1c5cff9e  movaps [r15+0x1D0], xmm3
000073ef1c5cffa6  lea rax, [r14+0x40]
000073ef1c5cffaa  movups xmm13, [r13+rax*1]
000073ef1c5cffb0  movaps [r15+0x2C0], xmm13
000073ef1c5cffb8  vmovaps xmm10, [rsp+0x90]
000073ef1c5cffc1  vpermilpd xmm10, xmm10, 0x00
000073ef1c5cffc7  movaps xmm9, xmm8
000073ef1c5cffcb  mulpd xmm9, xmm10
000073ef1c5cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000073ef1c5cffd6  ptest xmm5, xmm5
000073ef1c5cffdb  jnz 0x000073EF1C5D3946
000073ef1c5cffe1  movaps xmm10, xmm1
000073ef1c5cffe5  addpd xmm10, xmm11
000073ef1c5cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000073ef1c5cfff0  ptest xmm8, xmm8
000073ef1c5cfff6  jnz 0x000073EF1C5D3A8A
000073ef1c5cfffc  movaps xmm1, xmm14
000073ef1c5d0000  addpd xmm1, xmm6
000073ef1c5d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000073ef1c5d0009  ptest xmm11, xmm11
000073ef1c5d000f  jnz 0x000073EF1C5D3BCD
000073ef1c5d0015  vmovaps xmm14, [rsp+0x90]
000073ef1c5d001e  vpermilpd xmm14, xmm14, 0x00
000073ef1c5d0024  movaps xmm11, xmm13
000073ef1c5d0028  mulpd xmm11, xmm14
000073ef1c5d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000073ef1c5d0033  ptest xmm8, xmm8
000073ef1c5d0039  jnz 0x000073EF1C5D3D0E
000073ef1c5d003f  vmovaps xmm14, [rsp+0x90]
000073ef1c5d0048  vpermilpd xmm14, xmm14, 0x00
000073ef1c5d004e  vmovaps xmm8, [rsp+0x10]
000073ef1c5d0054  movaps xmm13, xmm8
000073ef1c5d0058  mulpd xmm13, xmm14
000073ef1c5d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000073ef1c5d0063  ptest xmm6, xmm6
000073ef1c5d0068  jnz 0x000073EF1C5D3E52
000073ef1c5d006e  vmovaps xmm14, [rsp+0x60]
000073ef1c5d0074  vpermilpd xmm14, xmm14, 0x00
000073ef1c5d007a  movaps xmm8, xmm7
000073ef1c5d007e  mulpd xmm8, xmm14
000073ef1c5d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000073ef1c5d0089  ptest xmm6, xmm6
000073ef1c5d008e  jnz 0x000073EF1C5D3F96
000073ef1c5d0094  movaps xmm14, xmm12
000073ef1c5d0098  addpd xmm14, xmm9
000073ef1c5d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000073ef1c5d00a3  ptest xmm7, xmm7
000073ef1c5d00a8  jnz 0x000073EF1C5D40D9
000073ef1c5d00ae  vmovaps xmm12, [rsp+0x60]
000073ef1c5d00b4  vpermilpd xmm12, xmm12, 0x00
000073ef1c5d00ba  vmovaps xmm7, [rsp+0xF0]
000073ef1c5d00c3  movaps xmm9, xmm7
000073ef1c5d00c7  mulpd xmm9, xmm12
000073ef1c5d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000073ef1c5d00d2  ptest xmm6, xmm6
000073ef1c5d00d7  jnz 0x000073EF1C5D421D
000073ef1c5d00dd  movaps xmm12, xmm15
000073ef1c5d00e1  addpd xmm12, xmm11
000073ef1c5d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000073ef1c5d00ec  ptest xmm7, xmm7
000073ef1c5d00f1  jnz 0x000073EF1C5D4360
000073ef1c5d00f7  vmovaps xmm15, [rsp+0x60]
000073ef1c5d00fd  vpermilpd xmm15, xmm15, 0x00
000073ef1c5d0103  vmovaps xmm7, [rsp+0x40]
000073ef1c5d0109  movaps xmm11, xmm7
000073ef1c5d010d  mulpd xmm11, xmm15
000073ef1c5d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000073ef1c5d0118  ptest xmm6, xmm6
000073ef1c5d011d  jnz 0x000073EF1C5D44A4
000073ef1c5d0123  movaps xmm15, xmm10
000073ef1c5d0127  addpd xmm15, xmm13
000073ef1c5d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000073ef1c5d0132  ptest xmm7, xmm7
000073ef1c5d0137  jnz 0x000073EF1C5D45E7
000073ef1c5d013d  vmovaps xmm13, [rsp+0x60]
000073ef1c5d0143  vpermilpd xmm13, xmm13, 0x00
000073ef1c5d0149  vmovaps xmm7, [rsp+0x50]
000073ef1c5d014f  movaps xmm10, xmm7
000073ef1c5d0153  mulpd xmm10, xmm13
000073ef1c5d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000073ef1c5d015e  ptest xmm6, xmm6
000073ef1c5d0163  jnz 0x000073EF1C5D472B
000073ef1c5d0169  movaps xmm13, xmm1
000073ef1c5d016d  addpd xmm13, xmm8
000073ef1c5d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000073ef1c5d0178  ptest xmm7, xmm7
000073ef1c5d017d  jnz 0x000073EF1C5D486E
000073ef1c5d0183  lea rax, [r14+0x70]
000073ef1c5d0187  movups xmm1, [r13+rax*1]
000073ef1c5d018d  movaps [r15+0x240], xmm1
000073ef1c5d0195  movaps xmm8, xmm14
000073ef1c5d0199  addpd xmm8, xmm9
000073ef1c5d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000073ef1c5d01a4  ptest xmm7, xmm7
000073ef1c5d01a9  jnz 0x000073EF1C5D49BB
000073ef1c5d01af  movaps [r15+0x170], xmm8
000073ef1c5d01b7  vmovaps xmm14, [rsp+0x70]
000073ef1c5d01bd  vpermilpd xmm14, xmm14, 0x00
000073ef1c5d01c3  movaps xmm9, xmm1
000073ef1c5d01c7  mulpd xmm9, xmm14
000073ef1c5d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000073ef1c5d01d2  ptest xmm7, xmm7
000073ef1c5d01d7  jnz 0x000073EF1C5D4AFF
000073ef1c5d01dd  vmovaps xmm1, [rsp+0x70]
000073ef1c5d01e3  vpermilpd xmm1, xmm1, 0x00
000073ef1c5d01e9  movaps xmm14, xmm4
000073ef1c5d01ed  mulpd xmm14, xmm1
000073ef1c5d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000073ef1c5d01f8  ptest xmm7, xmm7
000073ef1c5d01fd  jnz 0x000073EF1C5D4C42
000073ef1c5d0203  movaps [r15+0x180], xmm14
000073ef1c5d020b  movaps xmm1, xmm12
000073ef1c5d020f  addpd xmm1, xmm11
000073ef1c5d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000073ef1c5d0219  ptest xmm7, xmm7
000073ef1c5d021e  jnz 0x000073EF1C5D4D84
000073ef1c5d0224  movaps [r15+0x210], xmm1
000073ef1c5d022c  movups xmm12, [r13+r14*1]
000073ef1c5d0232  lea rax, [r14+0x10]
000073ef1c5d0236  movups xmm11, [r13+rax*1]
000073ef1c5d023c  movaps [r15+0x230], xmm11
000073ef1c5d0244  movaps xmm7, xmm15
000073ef1c5d0248  addpd xmm7, xmm10
000073ef1c5d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000073ef1c5d0252  ptest xmm6, xmm6
000073ef1c5d0257  jnz 0x000073EF1C5D4EDA
000073ef1c5d025d  movaps [r15+0x130], xmm7
000073ef1c5d0265  vmovaps xmm15, [rsp+0x70]
000073ef1c5d026b  vpermilpd xmm15, xmm15, 0x00
000073ef1c5d0271  movaps xmm10, xmm11
000073ef1c5d0275  mulpd xmm10, xmm15
000073ef1c5d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000073ef1c5d0280  ptest xmm6, xmm6
000073ef1c5d0285  jnz 0x000073EF1C5D501C
000073ef1c5d028b  movaps [r15+0x220], xmm10
000073ef1c5d0293  vmovaps xmm15, [rsp+0x70]
000073ef1c5d0299  vpermilpd xmm15, xmm15, 0x00
000073ef1c5d029f  movaps xmm11, xmm12
000073ef1c5d02a3  mulpd xmm11, xmm15
000073ef1c5d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000073ef1c5d02ae  ptest xmm6, xmm6
000073ef1c5d02b3  jnz 0x000073EF1C5D5160
000073ef1c5d02b9  movaps xmm15, xmm13
000073ef1c5d02bd  addpd xmm15, xmm9
000073ef1c5d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000073ef1c5d02c8  ptest xmm12, xmm12
000073ef1c5d02ce  jnz 0x000073EF1C5D52A4
000073ef1c5d02d4  movaps [r15+0x140], xmm15
000073ef1c5d02dc  movaps xmm13, xmm8
000073ef1c5d02e0  addpd xmm13, xmm14
000073ef1c5d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000073ef1c5d02eb  ptest xmm12, xmm12
000073ef1c5d02f1  jnz 0x000073EF1C5D53E8
000073ef1c5d02f7  movaps [r15+0x150], xmm13
000073ef1c5d02ff  movaps xmm14, xmm1
000073ef1c5d0303  addpd xmm14, xmm10
000073ef1c5d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000073ef1c5d030e  ptest xmm12, xmm12
000073ef1c5d0314  jnz 0x000073EF1C5D552C
000073ef1c5d031a  movaps [r15+0x160], xmm14
000073ef1c5d0322  movaps xmm1, xmm7
000073ef1c5d0325  addpd xmm1, xmm11
000073ef1c5d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000073ef1c5d032f  ptest xmm12, xmm12
000073ef1c5d0335  jnz 0x000073EF1C5D566F
000073ef1c5d033b  movaps [r15+0x120], xmm1
000073ef1c5d0343  mov eax, 0x430920
000073ef1c5d0348  movups [r13+rax*1], xmm15
000073ef1c5d034e  mov eax, 0x430930
000073ef1c5d0353  movups [r13+rax*1], xmm13
000073ef1c5d0359  mov eax, 0x430940
000073ef1c5d035e  movups [r13+rax*1], xmm14
000073ef1c5d0364  mov eax, 0x430950
000073ef1c5d0369  movups [r13+rax*1], xmm1
000073ef1c5d036f  mov eax, [r15+0x108]
000073ef1c5d0376  sahf
000073ef1c5d0377  jnz 0x000073EF1C5D03A9
000073ef1c5d0379  cmp dword ptr [r15+0x318], 0x00
000073ef1c5d0381  jz 0x000073EF1C5DB900
000073ef1c5d0387  nop [rax+rax*1], ax
000073ef1c5d0390  nop [rax+rax*1], eax
000073ef1c5d0398  mov eax, 0x410444
000073ef1c5d039d  mov [r15+0x100], rax
000073ef1c5d03a4  jmp 0x000073EF1C3FE110
000073ef1c5d03a9  cmp dword ptr [r15+0x318], 0x00
000073ef1c5d03b1  jz 0x000073EF1C5D57E0
000073ef1c5d03b7  nop [rax+rax*1], ax
000073ef1c5d03c0  nop [rax+rax*1], eax
000073ef1c5d03c8  mov eax, 0x410278
000073ef1c5d03cd  mov [r15+0x100], rax
000073ef1c5d03d4  jmp 0x000073EF1C3FE110
000073ef1c5d03d9  int3
000073ef1c5d03da  call 0x000073EF1C4B52F0
000073ef1c5d03df  jmp 0x000073EF1C5CF016
000073ef1c5d03e4  call 0x000073EF1C4C4620
000073ef1c5d03e9  jmp 0x000073EF1C5CF023
000073ef1c5d03ee  call 0x000073EF1C4C33A0
000073ef1c5d03f3  jmp 0x000073EF1C5CF035
000073ef1c5d03f8  call 0x000073EF1C4C2120
000073ef1c5d03fd  jmp 0x000073EF1C5CF03F
000073ef1c5d0402  call 0x000073EF1C4C0860
000073ef1c5d0407  jmp 0x000073EF1C5CF067
000073ef1c5d040c  call 0x000073EF1C4BF5F0
000073ef1c5d0411  jmp 0x000073EF1C5CF073
000073ef1c5d0416  call 0x000073EF1C4C0860
000073ef1c5d041b  jmp 0x000073EF1C5CF0A5
000073ef1c5d0420  call 0x000073EF1C4BF5F0
000073ef1c5d0425  jmp 0x000073EF1C5CF0B1
000073ef1c5d042a  call 0x000073EF1C4C4740
000073ef1c5d042f  jmp 0x000073EF1C5CF0BE
000073ef1c5d0434  call 0x000073EF1C4B5400
000073ef1c5d0439  jmp 0x000073EF1C5CF0CB
000073ef1c5d043e  call 0x000073EF1C4B52F0
000073ef1c5d0443  jmp 0x000073EF1C5CF0D8
000073ef1c5d0448  call 0x000073EF1C4C4620
000073ef1c5d044d  jmp 0x000073EF1C5CF0E5
000073ef1c5d0452  call 0x000073EF1C4C0860
000073ef1c5d0457  jmp 0x000073EF1C5CF10D
000073ef1c5d045c  call 0x000073EF1C4BF5F0
000073ef1c5d0461  jmp 0x000073EF1C5CF119
000073ef1c5d0466  call 0x000073EF1C409D70
000073ef1c5d046b  jmp 0x000073EF1C5CF11F
000073ef1c5d0470  call 0x000073EF1C4BE9C0
000073ef1c5d0475  jmp 0x000073EF1C5CF129
000073ef1c5d047a  call 0x000073EF1C4C0860
000073ef1c5d047f  jmp 0x000073EF1C5CF151
000073ef1c5d0484  call 0x000073EF1C4BF5F0
000073ef1c5d0489  jmp 0x000073EF1C5CF15D
000073ef1c5d048e  call 0x000073EF1C4BD750
000073ef1c5d0493  jmp 0x000073EF1C5CF16A
000073ef1c5d0498  call 0x000073EF1C4BC4E0
000073ef1c5d049d  jmp 0x000073EF1C5CF177
000073ef1c5d04a2  call 0x000073EF1C4C4740
000073ef1c5d04a7  jmp 0x000073EF1C5CF184
000073ef1c5d04ac  call 0x000073EF1C4B5400
000073ef1c5d04b1  jmp 0x000073EF1C5CF191
000073ef1c5d04b6  call 0x000073EF1C4B52F0
000073ef1c5d04bb  jmp 0x000073EF1C5CF19E
000073ef1c5d04c0  call 0x000073EF1C4C4620
000073ef1c5d04c5  jmp 0x000073EF1C5CF1AB
000073ef1c5d04ca  call 0x000073EF1C4C0860
000073ef1c5d04cf  jmp 0x000073EF1C5CF1BE
000073ef1c5d04d4  call 0x000073EF1C4BB270
000073ef1c5d04d9  jmp 0x000073EF1C5CF1CB
000073ef1c5d04de  call 0x000073EF1C4BA000
000073ef1c5d04e3  jmp 0x000073EF1C5CF1D8
000073ef1c5d04e8  call 0x000073EF1C4B8D90
000073ef1c5d04ed  jmp 0x000073EF1C5CF1E5
000073ef1c5d04f2  call 0x000073EF1C4B8A20
000073ef1c5d04f7  jmp 0x000073EF1C5CF1F2
000073ef1c5d04fc  call 0x000073EF1C4B5400
000073ef1c5d0501  jmp 0x000073EF1C5CF1FC
000073ef1c5d0506  call 0x000073EF1C4C2240
000073ef1c5d050b  jmp 0x000073EF1C5CF206
000073ef1c5d0510  call 0x000073EF1C4B52F0
000073ef1c5d0515  jmp 0x000073EF1C5CF210
000073ef1c5d051a  call 0x000073EF1C4C2120
000073ef1c5d051f  jmp 0x000073EF1C5CF21A
000073ef1c5d0524  call 0x000073EF1C4B77B0
000073ef1c5d0529  jmp 0x000073EF1C5CF224
000073ef1c5d052e  call 0x000073EF1C4B6550
000073ef1c5d0533  jmp 0x000073EF1C5CF22E
000073ef1c5d0538  call 0x000073EF1C4BFD50
000073ef1c5d053d  jmp 0x000073EF1C5CF240
000073ef1c5d0542  call 0x000073EF1C4B8EA0
000073ef1c5d0547  jmp 0x000073EF1C5CF24A
000073ef1c5d054c  call 0x000073EF1C4BFC30
000073ef1c5d0551  jmp 0x000073EF1C5CF257
000073ef1c5d0556  call 0x000073EF1C4B8D90
000073ef1c5d055b  jmp 0x000073EF1C5CF264
000073ef1c5d0560  call 0x000073EF1C4C2240
000073ef1c5d0565  jmp 0x000073EF1C5CF271
000073ef1c5d056a  call 0x000073EF1C4B5400
000073ef1c5d056f  jmp 0x000073EF1C5CF27E
000073ef1c5d0574  call 0x000073EF1C4B52F0
000073ef1c5d0579  jmp 0x000073EF1C5CF28B
000073ef1c5d057e  call 0x000073EF1C4C2120
000073ef1c5d0583  jmp 0x000073EF1C5CF298
000073ef1c5d0588  call 0x000073EF1C4B52F0
000073ef1c5d058d  jmp 0x000073EF1C5CF2AB
000073ef1c5d0592  call 0x000073EF1C4B52F0
000073ef1c5d0597  jmp 0x000073EF1C5CF2BE
000073ef1c5d059c  call 0x000073EF1C4B52F0
000073ef1c5d05a1  jmp 0x000073EF1C5CF2D1
000073ef1c5d05a6  call 0x000073EF1C4B52F0
000073ef1c5d05ab  jmp 0x000073EF1C5CF2E4
000073ef1c5d05b0  call 0x000073EF1C4C2240
000073ef1c5d05b5  jmp 0x000073EF1C5CF2F9
000073ef1c5d05ba  call 0x000073EF1C4C2240
000073ef1c5d05bf  jmp 0x000073EF1C5CF30C
000073ef1c5d05c4  call 0x000073EF1C4C2120
000073ef1c5d05c9  jmp 0x000073EF1C5CF319
000073ef1c5d05ce  call 0x000073EF1C4B52F0
000073ef1c5d05d3  jmp 0x000073EF1C5CF32C
000073ef1c5d05d8  call 0x000073EF1C4B52F0
000073ef1c5d05dd  jmp 0x000073EF1C5CF34F
000073ef1c5d05e2  call 0x000073EF1C4B52F0
000073ef1c5d05e7  jmp 0x000073EF1C5CF362
000073ef1c5d05ec  call 0x000073EF1C3FF540
000073ef1c5d05f1  jmp 0x000073EF1C5CF380
000073ef1c5d05f6  call 0x000073EF1C408C20
000073ef1c5d05fb  jmp 0x000073EF1C5CF38A
000073ef1c5d0600  call 0x000073EF1C4D6600
000073ef1c5d0605  jmp 0x000073EF1C5CF396
000073ef1c5d060a  call 0x000073EF1C3FF540
000073ef1c5d060f  jmp 0x000073EF1C5CF3A6
000073ef1c5d0614  call 0x000073EF1C4C0370
000073ef1c5d0619  jmp 0x000073EF1C5CF3D4
000073ef1c5d061e  call 0x000073EF1C4BF100
000073ef1c5d0623  jmp 0x000073EF1C5CF3DD
000073ef1c5d0628  call 0x000073EF1C4C0370
000073ef1c5d062d  jmp 0x000073EF1C5CF43B
000073ef1c5d0632  call 0x000073EF1C4BF100
000073ef1c5d0637  jmp 0x000073EF1C5CF444
000073ef1c5d063c  call 0x000073EF1C4C0370
000073ef1c5d0641  jmp 0x000073EF1C5CF48B
000073ef1c5d0646  call 0x000073EF1C4BF100
000073ef1c5d064b  jmp 0x000073EF1C5CF494
000073ef1c5d0650  call 0x000073EF1C40B720
000073ef1c5d0655  jmp 0x000073EF1C5CF4D7
000073ef1c5d065a  call 0x000073EF1C4B47C0
000073ef1c5d065f  jmp 0x000073EF1C5CF4EA
000073ef1c5d0664  call 0x000073EF1C408B00
000073ef1c5d0669  jmp 0x000073EF1C5CF501
000073ef1c5d066e  call 0x000073EF1C3FF430
000073ef1c5d0673  jmp 0x000073EF1C5CF514
000073ef1c5d0678  call 0x000073EF1C3FF430
000073ef1c5d067d  jmp 0x000073EF1C5CF527
000073ef1c5d0682  sub rsp, 0x08
000073ef1c5d0686  push rax
000073ef1c5d0687  push rcx
000073ef1c5d0688  push rdx
000073ef1c5d0689  push rdi
000073ef1c5d068a  push rsi
000073ef1c5d068b  push r8
000073ef1c5d068d  push r9
000073ef1c5d068f  push r10
000073ef1c5d0691  push r11
000073ef1c5d0693  sub rsp, 0xF0
000073ef1c5d069a  vmovaps [rsp], xmm0
000073ef1c5d069f  vmovaps [rsp+0x10], xmm2
000073ef1c5d06a5  vmovaps [rsp+0x20], xmm3
000073ef1c5d06ab  vmovaps [rsp+0x30], xmm4
000073ef1c5d06b1  vmovaps [rsp+0x40], xmm5
000073ef1c5d06b7  vmovaps [rsp+0x50], xmm6
000073ef1c5d06bd  vmovaps [rsp+0x60], xmm7
000073ef1c5d06c3  vmovaps [rsp+0x70], xmm8
000073ef1c5d06c9  vmovaps [rsp+0x80], xmm9
000073ef1c5d06d2  vmovaps [rsp+0x90], xmm10
000073ef1c5d06db  vmovaps [rsp+0xA0], xmm11
000073ef1c5d06e4  vmovaps [rsp+0xB0], xmm12
000073ef1c5d06ed  vmovaps [rsp+0xC0], xmm13
000073ef1c5d06f6  vmovaps [rsp+0xD0], xmm14
000073ef1c5d06ff  vmovaps [rsp+0xE0], xmm15
000073ef1c5d0708  sub rsp, 0x30
000073ef1c5d070c  movaps [rsp], xmm1
000073ef1c5d0710  movaps [rsp+0x10], xmm15
000073ef1c5d0716  movaps [rsp+0x20], xmm14
000073ef1c5d071c  lea rdi, [rsp]
000073ef1c5d0720  mov esi, 0x00
000073ef1c5d0725  mov rax, 0x56F25E118530
000073ef1c5d072f  call rax
000073ef1c5d0731  movaps xmm1, [rsp]
000073ef1c5d0735  add rsp, 0x30
000073ef1c5d0739  vmovaps xmm0, [rsp]
000073ef1c5d073e  vmovaps xmm2, [rsp+0x10]
000073ef1c5d0744  vmovaps xmm3, [rsp+0x20]
000073ef1c5d074a  vmovaps xmm4, [rsp+0x30]
000073ef1c5d0750  vmovaps xmm5, [rsp+0x40]
000073ef1c5d0756  vmovaps xmm6, [rsp+0x50]
000073ef1c5d075c  vmovaps xmm7, [rsp+0x60]
000073ef1c5d0762  vmovaps xmm8, [rsp+0x70]
000073ef1c5d0768  vmovaps xmm9, [rsp+0x80]
000073ef1c5d0771  vmovaps xmm10, [rsp+0x90]
000073ef1c5d077a  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d0783  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d078c  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d0795  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d079e  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d07a7  add rsp, 0xF0
000073ef1c5d07ae  pop r11
000073ef1c5d07b0  pop r10
000073ef1c5d07b2  pop r9
000073ef1c5d07b4  pop r8
000073ef1c5d07b6  pop rsi
000073ef1c5d07b7  pop rdi
000073ef1c5d07b8  pop rdx
000073ef1c5d07b9  pop rcx
000073ef1c5d07ba  pop rax
000073ef1c5d07bb  add rsp, 0x08
000073ef1c5d07bf  jmp 0x000073EF1C5CF581
000073ef1c5d07c4  sub rsp, 0x08
000073ef1c5d07c8  push rax
000073ef1c5d07c9  push rcx
000073ef1c5d07ca  push rdx
000073ef1c5d07cb  push rdi
000073ef1c5d07cc  push rsi
000073ef1c5d07cd  push r8
000073ef1c5d07cf  push r9
000073ef1c5d07d1  push r10
000073ef1c5d07d3  push r11
000073ef1c5d07d5  sub rsp, 0xF0
000073ef1c5d07dc  vmovaps [rsp], xmm0
000073ef1c5d07e1  vmovaps [rsp+0x10], xmm1
000073ef1c5d07e7  vmovaps [rsp+0x20], xmm2
000073ef1c5d07ed  vmovaps [rsp+0x30], xmm3
000073ef1c5d07f3  vmovaps [rsp+0x40], xmm4
000073ef1c5d07f9  vmovaps [rsp+0x50], xmm5
000073ef1c5d07ff  vmovaps [rsp+0x60], xmm6
000073ef1c5d0805  vmovaps [rsp+0x70], xmm7
000073ef1c5d080b  vmovaps [rsp+0x80], xmm8
000073ef1c5d0814  vmovaps [rsp+0x90], xmm9
000073ef1c5d081d  vmovaps [rsp+0xA0], xmm10
000073ef1c5d0826  vmovaps [rsp+0xB0], xmm11
000073ef1c5d082f  vmovaps [rsp+0xC0], xmm12
000073ef1c5d0838  vmovaps [rsp+0xD0], xmm14
000073ef1c5d0841  vmovaps [rsp+0xE0], xmm15
000073ef1c5d084a  sub rsp, 0x30
000073ef1c5d084e  movaps [rsp], xmm13
000073ef1c5d0853  movaps [rsp+0x10], xmm1
000073ef1c5d0858  movaps [rsp+0x20], xmm14
000073ef1c5d085e  lea rdi, [rsp]
000073ef1c5d0862  mov esi, 0x00
000073ef1c5d0867  mov rax, 0x56F25E118530
000073ef1c5d0871  call rax
000073ef1c5d0873  movaps xmm13, [rsp]
000073ef1c5d0878  add rsp, 0x30
000073ef1c5d087c  vmovaps xmm0, [rsp]
000073ef1c5d0881  vmovaps xmm1, [rsp+0x10]
000073ef1c5d0887  vmovaps xmm2, [rsp+0x20]
000073ef1c5d088d  vmovaps xmm3, [rsp+0x30]
000073ef1c5d0893  vmovaps xmm4, [rsp+0x40]
000073ef1c5d0899  vmovaps xmm5, [rsp+0x50]
000073ef1c5d089f  vmovaps xmm6, [rsp+0x60]
000073ef1c5d08a5  vmovaps xmm7, [rsp+0x70]
000073ef1c5d08ab  vmovaps xmm8, [rsp+0x80]
000073ef1c5d08b4  vmovaps xmm9, [rsp+0x90]
000073ef1c5d08bd  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d08c6  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d08cf  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d08d8  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d08e1  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d08ea  add rsp, 0xF0
000073ef1c5d08f1  pop r11
000073ef1c5d08f3  pop r10
000073ef1c5d08f5  pop r9
000073ef1c5d08f7  pop r8
000073ef1c5d08f9  pop rsi
000073ef1c5d08fa  pop rdi
000073ef1c5d08fb  pop rdx
000073ef1c5d08fc  pop rcx
000073ef1c5d08fd  pop rax
000073ef1c5d08fe  add rsp, 0x08
000073ef1c5d0902  jmp 0x000073EF1C5CF5CF
000073ef1c5d0907  sub rsp, 0x08
000073ef1c5d090b  push rax
000073ef1c5d090c  push rcx
000073ef1c5d090d  push rdx
000073ef1c5d090e  push rdi
000073ef1c5d090f  push rsi
000073ef1c5d0910  push r8
000073ef1c5d0912  push r9
000073ef1c5d0914  push r10
000073ef1c5d0916  push r11
000073ef1c5d0918  sub rsp, 0xF0
000073ef1c5d091f  vmovaps [rsp], xmm0
000073ef1c5d0924  vmovaps [rsp+0x10], xmm1
000073ef1c5d092a  vmovaps [rsp+0x20], xmm2
000073ef1c5d0930  vmovaps [rsp+0x30], xmm3
000073ef1c5d0936  vmovaps [rsp+0x40], xmm4
000073ef1c5d093c  vmovaps [rsp+0x50], xmm5
000073ef1c5d0942  vmovaps [rsp+0x60], xmm6
000073ef1c5d0948  vmovaps [rsp+0x70], xmm7
000073ef1c5d094e  vmovaps [rsp+0x80], xmm8
000073ef1c5d0957  vmovaps [rsp+0x90], xmm9
000073ef1c5d0960  vmovaps [rsp+0xA0], xmm10
000073ef1c5d0969  vmovaps [rsp+0xB0], xmm11
000073ef1c5d0972  vmovaps [rsp+0xC0], xmm12
000073ef1c5d097b  vmovaps [rsp+0xD0], xmm13
000073ef1c5d0984  vmovaps [rsp+0xE0], xmm14
000073ef1c5d098d  sub rsp, 0x30
000073ef1c5d0991  movaps [rsp], xmm15
000073ef1c5d0996  movaps [rsp+0x10], xmm14
000073ef1c5d099c  movaps [rsp+0x20], xmm1
000073ef1c5d09a1  lea rdi, [rsp]
000073ef1c5d09a5  mov esi, 0x00
000073ef1c5d09aa  mov rax, 0x56F25E118530
000073ef1c5d09b4  call rax
000073ef1c5d09b6  movaps xmm15, [rsp]
000073ef1c5d09bb  add rsp, 0x30
000073ef1c5d09bf  vmovaps xmm0, [rsp]
000073ef1c5d09c4  vmovaps xmm1, [rsp+0x10]
000073ef1c5d09ca  vmovaps xmm2, [rsp+0x20]
000073ef1c5d09d0  vmovaps xmm3, [rsp+0x30]
000073ef1c5d09d6  vmovaps xmm4, [rsp+0x40]
000073ef1c5d09dc  vmovaps xmm5, [rsp+0x50]
000073ef1c5d09e2  vmovaps xmm6, [rsp+0x60]
000073ef1c5d09e8  vmovaps xmm7, [rsp+0x70]
000073ef1c5d09ee  vmovaps xmm8, [rsp+0x80]
000073ef1c5d09f7  vmovaps xmm9, [rsp+0x90]
000073ef1c5d0a00  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d0a09  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d0a12  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d0a1b  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d0a24  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d0a2d  add rsp, 0xF0
000073ef1c5d0a34  pop r11
000073ef1c5d0a36  pop r10
000073ef1c5d0a38  pop r9
000073ef1c5d0a3a  pop r8
000073ef1c5d0a3c  pop rsi
000073ef1c5d0a3d  pop rdi
000073ef1c5d0a3e  pop rdx
000073ef1c5d0a3f  pop rcx
000073ef1c5d0a40  pop rax
000073ef1c5d0a41  add rsp, 0x08
000073ef1c5d0a45  jmp 0x000073EF1C5CF617
000073ef1c5d0a4a  sub rsp, 0x08
000073ef1c5d0a4e  push rax
000073ef1c5d0a4f  push rcx
000073ef1c5d0a50  push rdx
000073ef1c5d0a51  push rdi
000073ef1c5d0a52  push rsi
000073ef1c5d0a53  push r8
000073ef1c5d0a55  push r9
000073ef1c5d0a57  push r10
000073ef1c5d0a59  push r11
000073ef1c5d0a5b  sub rsp, 0xF0
000073ef1c5d0a62  vmovaps [rsp], xmm0
000073ef1c5d0a67  vmovaps [rsp+0x10], xmm2
000073ef1c5d0a6d  vmovaps [rsp+0x20], xmm3
000073ef1c5d0a73  vmovaps [rsp+0x30], xmm4
000073ef1c5d0a79  vmovaps [rsp+0x40], xmm5
000073ef1c5d0a7f  vmovaps [rsp+0x50], xmm6
000073ef1c5d0a85  vmovaps [rsp+0x60], xmm7
000073ef1c5d0a8b  vmovaps [rsp+0x70], xmm8
000073ef1c5d0a91  vmovaps [rsp+0x80], xmm9
000073ef1c5d0a9a  vmovaps [rsp+0x90], xmm10
000073ef1c5d0aa3  vmovaps [rsp+0xA0], xmm11
000073ef1c5d0aac  vmovaps [rsp+0xB0], xmm12
000073ef1c5d0ab5  vmovaps [rsp+0xC0], xmm13
000073ef1c5d0abe  vmovaps [rsp+0xD0], xmm14
000073ef1c5d0ac7  vmovaps [rsp+0xE0], xmm15
000073ef1c5d0ad0  sub rsp, 0x30
000073ef1c5d0ad4  movaps [rsp], xmm1
000073ef1c5d0ad8  movaps [rsp+0x10], xmm14
000073ef1c5d0ade  movaps [rsp+0x20], xmm10
000073ef1c5d0ae4  lea rdi, [rsp]
000073ef1c5d0ae8  mov esi, 0x00
000073ef1c5d0aed  mov rax, 0x56F25E118530
000073ef1c5d0af7  call rax
000073ef1c5d0af9  movaps xmm1, [rsp]
000073ef1c5d0afd  add rsp, 0x30
000073ef1c5d0b01  vmovaps xmm0, [rsp]
000073ef1c5d0b06  vmovaps xmm2, [rsp+0x10]
000073ef1c5d0b0c  vmovaps xmm3, [rsp+0x20]
000073ef1c5d0b12  vmovaps xmm4, [rsp+0x30]
000073ef1c5d0b18  vmovaps xmm5, [rsp+0x40]
000073ef1c5d0b1e  vmovaps xmm6, [rsp+0x50]
000073ef1c5d0b24  vmovaps xmm7, [rsp+0x60]
000073ef1c5d0b2a  vmovaps xmm8, [rsp+0x70]
000073ef1c5d0b30  vmovaps xmm9, [rsp+0x80]
000073ef1c5d0b39  vmovaps xmm10, [rsp+0x90]
000073ef1c5d0b42  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d0b4b  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d0b54  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d0b5d  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d0b66  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d0b6f  add rsp, 0xF0
000073ef1c5d0b76  pop r11
000073ef1c5d0b78  pop r10
000073ef1c5d0b7a  pop r9
000073ef1c5d0b7c  pop r8
000073ef1c5d0b7e  pop rsi
000073ef1c5d0b7f  pop rdi
000073ef1c5d0b80  pop rdx
000073ef1c5d0b81  pop rcx
000073ef1c5d0b82  pop rax
000073ef1c5d0b83  add rsp, 0x08
000073ef1c5d0b87  jmp 0x000073EF1C5CF631
000073ef1c5d0b8c  sub rsp, 0x08
000073ef1c5d0b90  push rax
000073ef1c5d0b91  push rcx
000073ef1c5d0b92  push rdx
000073ef1c5d0b93  push rdi
000073ef1c5d0b94  push rsi
000073ef1c5d0b95  push r8
000073ef1c5d0b97  push r9
000073ef1c5d0b99  push r10
000073ef1c5d0b9b  push r11
000073ef1c5d0b9d  sub rsp, 0xF0
000073ef1c5d0ba4  vmovaps [rsp], xmm0
000073ef1c5d0ba9  vmovaps [rsp+0x10], xmm1
000073ef1c5d0baf  vmovaps [rsp+0x20], xmm2
000073ef1c5d0bb5  vmovaps [rsp+0x30], xmm3
000073ef1c5d0bbb  vmovaps [rsp+0x40], xmm4
000073ef1c5d0bc1  vmovaps [rsp+0x50], xmm5
000073ef1c5d0bc7  vmovaps [rsp+0x60], xmm6
000073ef1c5d0bcd  vmovaps [rsp+0x70], xmm7
000073ef1c5d0bd3  vmovaps [rsp+0x80], xmm8
000073ef1c5d0bdc  vmovaps [rsp+0x90], xmm9
000073ef1c5d0be5  vmovaps [rsp+0xA0], xmm10
000073ef1c5d0bee  vmovaps [rsp+0xB0], xmm11
000073ef1c5d0bf7  vmovaps [rsp+0xC0], xmm12
000073ef1c5d0c00  vmovaps [rsp+0xD0], xmm14
000073ef1c5d0c09  vmovaps [rsp+0xE0], xmm15
000073ef1c5d0c12  sub rsp, 0x30
000073ef1c5d0c16  movaps [rsp], xmm13
000073ef1c5d0c1b  movaps [rsp+0x10], xmm14
000073ef1c5d0c21  movaps [rsp+0x20], xmm2
000073ef1c5d0c26  lea rdi, [rsp]
000073ef1c5d0c2a  mov esi, 0x00
000073ef1c5d0c2f  mov rax, 0x56F25E118530
000073ef1c5d0c39  call rax
000073ef1c5d0c3b  movaps xmm13, [rsp]
000073ef1c5d0c40  add rsp, 0x30
000073ef1c5d0c44  vmovaps xmm0, [rsp]
000073ef1c5d0c49  vmovaps xmm1, [rsp+0x10]
000073ef1c5d0c4f  vmovaps xmm2, [rsp+0x20]
000073ef1c5d0c55  vmovaps xmm3, [rsp+0x30]
000073ef1c5d0c5b  vmovaps xmm4, [rsp+0x40]
000073ef1c5d0c61  vmovaps xmm5, [rsp+0x50]
000073ef1c5d0c67  vmovaps xmm6, [rsp+0x60]
000073ef1c5d0c6d  vmovaps xmm7, [rsp+0x70]
000073ef1c5d0c73  vmovaps xmm8, [rsp+0x80]
000073ef1c5d0c7c  vmovaps xmm9, [rsp+0x90]
000073ef1c5d0c85  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d0c8e  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d0c97  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d0ca0  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d0ca9  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d0cb2  add rsp, 0xF0
000073ef1c5d0cb9  pop r11
000073ef1c5d0cbb  pop r10
000073ef1c5d0cbd  pop r9
000073ef1c5d0cbf  pop r8
000073ef1c5d0cc1  pop rsi
000073ef1c5d0cc2  pop rdi
000073ef1c5d0cc3  pop rdx
000073ef1c5d0cc4  pop rcx
000073ef1c5d0cc5  pop rax
000073ef1c5d0cc6  add rsp, 0x08
000073ef1c5d0cca  jmp 0x000073EF1C5CF64C
000073ef1c5d0ccf  sub rsp, 0x08
000073ef1c5d0cd3  push rax
000073ef1c5d0cd4  push rcx
000073ef1c5d0cd5  push rdx
000073ef1c5d0cd6  push rdi
000073ef1c5d0cd7  push rsi
000073ef1c5d0cd8  push r8
000073ef1c5d0cda  push r9
000073ef1c5d0cdc  push r10
000073ef1c5d0cde  push r11
000073ef1c5d0ce0  sub rsp, 0xF0
000073ef1c5d0ce7  vmovaps [rsp], xmm0
000073ef1c5d0cec  vmovaps [rsp+0x10], xmm2
000073ef1c5d0cf2  vmovaps [rsp+0x20], xmm3
000073ef1c5d0cf8  vmovaps [rsp+0x30], xmm4
000073ef1c5d0cfe  vmovaps [rsp+0x40], xmm5
000073ef1c5d0d04  vmovaps [rsp+0x50], xmm6
000073ef1c5d0d0a  vmovaps [rsp+0x60], xmm7
000073ef1c5d0d10  vmovaps [rsp+0x70], xmm8
000073ef1c5d0d16  vmovaps [rsp+0x80], xmm9
000073ef1c5d0d1f  vmovaps [rsp+0x90], xmm10
000073ef1c5d0d28  vmovaps [rsp+0xA0], xmm11
000073ef1c5d0d31  vmovaps [rsp+0xB0], xmm12
000073ef1c5d0d3a  vmovaps [rsp+0xC0], xmm13
000073ef1c5d0d43  vmovaps [rsp+0xD0], xmm14
000073ef1c5d0d4c  vmovaps [rsp+0xE0], xmm15
000073ef1c5d0d55  sub rsp, 0x30
000073ef1c5d0d59  movaps [rsp], xmm1
000073ef1c5d0d5d  movaps [rsp+0x10], xmm10
000073ef1c5d0d63  movaps [rsp+0x20], xmm2
000073ef1c5d0d68  lea rdi, [rsp]
000073ef1c5d0d6c  mov esi, 0x00
000073ef1c5d0d71  mov rax, 0x56F25E118530
000073ef1c5d0d7b  call rax
000073ef1c5d0d7d  movaps xmm1, [rsp]
000073ef1c5d0d81  add rsp, 0x30
000073ef1c5d0d85  vmovaps xmm0, [rsp]
000073ef1c5d0d8a  vmovaps xmm2, [rsp+0x10]
000073ef1c5d0d90  vmovaps xmm3, [rsp+0x20]
000073ef1c5d0d96  vmovaps xmm4, [rsp+0x30]
000073ef1c5d0d9c  vmovaps xmm5, [rsp+0x40]
000073ef1c5d0da2  vmovaps xmm6, [rsp+0x50]
000073ef1c5d0da8  vmovaps xmm7, [rsp+0x60]
000073ef1c5d0dae  vmovaps xmm8, [rsp+0x70]
000073ef1c5d0db4  vmovaps xmm9, [rsp+0x80]
000073ef1c5d0dbd  vmovaps xmm10, [rsp+0x90]
000073ef1c5d0dc6  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d0dcf  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d0dd8  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d0de1  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d0dea  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d0df3  add rsp, 0xF0
000073ef1c5d0dfa  pop r11
000073ef1c5d0dfc  pop r10
000073ef1c5d0dfe  pop r9
000073ef1c5d0e00  pop r8
000073ef1c5d0e02  pop rsi
000073ef1c5d0e03  pop rdi
000073ef1c5d0e04  pop rdx
000073ef1c5d0e05  pop rcx
000073ef1c5d0e06  pop rax
000073ef1c5d0e07  add rsp, 0x08
000073ef1c5d0e0b  jmp 0x000073EF1C5CF6B4
000073ef1c5d0e10  sub rsp, 0x08
000073ef1c5d0e14  push rax
000073ef1c5d0e15  push rcx
000073ef1c5d0e16  push rdx
000073ef1c5d0e17  push rdi
000073ef1c5d0e18  push rsi
000073ef1c5d0e19  push r8
000073ef1c5d0e1b  push r9
000073ef1c5d0e1d  push r10
000073ef1c5d0e1f  push r11
000073ef1c5d0e21  sub rsp, 0xF0
000073ef1c5d0e28  vmovaps [rsp], xmm0
000073ef1c5d0e2d  vmovaps [rsp+0x10], xmm1
000073ef1c5d0e33  vmovaps [rsp+0x20], xmm2
000073ef1c5d0e39  vmovaps [rsp+0x30], xmm3
000073ef1c5d0e3f  vmovaps [rsp+0x40], xmm4
000073ef1c5d0e45  vmovaps [rsp+0x50], xmm5
000073ef1c5d0e4b  vmovaps [rsp+0x60], xmm6
000073ef1c5d0e51  vmovaps [rsp+0x70], xmm7
000073ef1c5d0e57  vmovaps [rsp+0x80], xmm8
000073ef1c5d0e60  vmovaps [rsp+0x90], xmm9
000073ef1c5d0e69  vmovaps [rsp+0xA0], xmm10
000073ef1c5d0e72  vmovaps [rsp+0xB0], xmm11
000073ef1c5d0e7b  vmovaps [rsp+0xC0], xmm12
000073ef1c5d0e84  vmovaps [rsp+0xD0], xmm13
000073ef1c5d0e8d  vmovaps [rsp+0xE0], xmm14
000073ef1c5d0e96  sub rsp, 0x30
000073ef1c5d0e9a  movaps [rsp], xmm15
000073ef1c5d0e9f  movaps [rsp+0x10], xmm10
000073ef1c5d0ea5  movaps [rsp+0x20], xmm2
000073ef1c5d0eaa  lea rdi, [rsp]
000073ef1c5d0eae  mov esi, 0x00
000073ef1c5d0eb3  mov rax, 0x56F25E118530
000073ef1c5d0ebd  call rax
000073ef1c5d0ebf  movaps xmm15, [rsp]
000073ef1c5d0ec4  add rsp, 0x30
000073ef1c5d0ec8  vmovaps xmm0, [rsp]
000073ef1c5d0ecd  vmovaps xmm1, [rsp+0x10]
000073ef1c5d0ed3  vmovaps xmm2, [rsp+0x20]
000073ef1c5d0ed9  vmovaps xmm3, [rsp+0x30]
000073ef1c5d0edf  vmovaps xmm4, [rsp+0x40]
000073ef1c5d0ee5  vmovaps xmm5, [rsp+0x50]
000073ef1c5d0eeb  vmovaps xmm6, [rsp+0x60]
000073ef1c5d0ef1  vmovaps xmm7, [rsp+0x70]
000073ef1c5d0ef7  vmovaps xmm8, [rsp+0x80]
000073ef1c5d0f00  vmovaps xmm9, [rsp+0x90]
000073ef1c5d0f09  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d0f12  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d0f1b  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d0f24  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d0f2d  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d0f36  add rsp, 0xF0
000073ef1c5d0f3d  pop r11
000073ef1c5d0f3f  pop r10
000073ef1c5d0f41  pop r9
000073ef1c5d0f43  pop r8
000073ef1c5d0f45  pop rsi
000073ef1c5d0f46  pop rdi
000073ef1c5d0f47  pop rdx
000073ef1c5d0f48  pop rcx
000073ef1c5d0f49  pop rax
000073ef1c5d0f4a  add rsp, 0x08
000073ef1c5d0f4e  jmp 0x000073EF1C5CF706
000073ef1c5d0f53  sub rsp, 0x08
000073ef1c5d0f57  push rax
000073ef1c5d0f58  push rcx
000073ef1c5d0f59  push rdx
000073ef1c5d0f5a  push rdi
000073ef1c5d0f5b  push rsi
000073ef1c5d0f5c  push r8
000073ef1c5d0f5e  push r9
000073ef1c5d0f60  push r10
000073ef1c5d0f62  push r11
000073ef1c5d0f64  sub rsp, 0xF0
000073ef1c5d0f6b  vmovaps [rsp], xmm0
000073ef1c5d0f70  vmovaps [rsp+0x10], xmm2
000073ef1c5d0f76  vmovaps [rsp+0x20], xmm3
000073ef1c5d0f7c  vmovaps [rsp+0x30], xmm4
000073ef1c5d0f82  vmovaps [rsp+0x40], xmm5
000073ef1c5d0f88  vmovaps [rsp+0x50], xmm6
000073ef1c5d0f8e  vmovaps [rsp+0x60], xmm7
000073ef1c5d0f94  vmovaps [rsp+0x70], xmm8
000073ef1c5d0f9a  vmovaps [rsp+0x80], xmm9
000073ef1c5d0fa3  vmovaps [rsp+0x90], xmm10
000073ef1c5d0fac  vmovaps [rsp+0xA0], xmm11
000073ef1c5d0fb5  vmovaps [rsp+0xB0], xmm12
000073ef1c5d0fbe  vmovaps [rsp+0xC0], xmm13
000073ef1c5d0fc7  vmovaps [rsp+0xD0], xmm14
000073ef1c5d0fd0  vmovaps [rsp+0xE0], xmm15
000073ef1c5d0fd9  sub rsp, 0x30
000073ef1c5d0fdd  movaps [rsp], xmm1
000073ef1c5d0fe1  movaps [rsp+0x10], xmm10
000073ef1c5d0fe7  movaps [rsp+0x20], xmm12
000073ef1c5d0fed  lea rdi, [rsp]
000073ef1c5d0ff1  mov esi, 0x00
000073ef1c5d0ff6  mov rax, 0x56F25E118530
000073ef1c5d1000  call rax
000073ef1c5d1002  movaps xmm1, [rsp]
000073ef1c5d1006  add rsp, 0x30
000073ef1c5d100a  vmovaps xmm0, [rsp]
000073ef1c5d100f  vmovaps xmm2, [rsp+0x10]
000073ef1c5d1015  vmovaps xmm3, [rsp+0x20]
000073ef1c5d101b  vmovaps xmm4, [rsp+0x30]
000073ef1c5d1021  vmovaps xmm5, [rsp+0x40]
000073ef1c5d1027  vmovaps xmm6, [rsp+0x50]
000073ef1c5d102d  vmovaps xmm7, [rsp+0x60]
000073ef1c5d1033  vmovaps xmm8, [rsp+0x70]
000073ef1c5d1039  vmovaps xmm9, [rsp+0x80]
000073ef1c5d1042  vmovaps xmm10, [rsp+0x90]
000073ef1c5d104b  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d1054  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d105d  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d1066  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d106f  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d1078  add rsp, 0xF0
000073ef1c5d107f  pop r11
000073ef1c5d1081  pop r10
000073ef1c5d1083  pop r9
000073ef1c5d1085  pop r8
000073ef1c5d1087  pop rsi
000073ef1c5d1088  pop rdi
000073ef1c5d1089  pop rdx
000073ef1c5d108a  pop rcx
000073ef1c5d108b  pop rax
000073ef1c5d108c  add rsp, 0x08
000073ef1c5d1090  jmp 0x000073EF1C5CF732
000073ef1c5d1095  sub rsp, 0x08
000073ef1c5d1099  push rax
000073ef1c5d109a  push rcx
000073ef1c5d109b  push rdx
000073ef1c5d109c  push rdi
000073ef1c5d109d  push rsi
000073ef1c5d109e  push r8
000073ef1c5d10a0  push r9
000073ef1c5d10a2  push r10
000073ef1c5d10a4  push r11
000073ef1c5d10a6  sub rsp, 0xF0
000073ef1c5d10ad  vmovaps [rsp], xmm0
000073ef1c5d10b2  vmovaps [rsp+0x10], xmm1
000073ef1c5d10b8  vmovaps [rsp+0x20], xmm2
000073ef1c5d10be  vmovaps [rsp+0x30], xmm3
000073ef1c5d10c4  vmovaps [rsp+0x40], xmm4
000073ef1c5d10ca  vmovaps [rsp+0x50], xmm5
000073ef1c5d10d0  vmovaps [rsp+0x60], xmm6
000073ef1c5d10d6  vmovaps [rsp+0x70], xmm7
000073ef1c5d10dc  vmovaps [rsp+0x80], xmm8
000073ef1c5d10e5  vmovaps [rsp+0x90], xmm9
000073ef1c5d10ee  vmovaps [rsp+0xA0], xmm10
000073ef1c5d10f7  vmovaps [rsp+0xB0], xmm11
000073ef1c5d1100  vmovaps [rsp+0xC0], xmm12
000073ef1c5d1109  vmovaps [rsp+0xD0], xmm13
000073ef1c5d1112  vmovaps [rsp+0xE0], xmm14
000073ef1c5d111b  sub rsp, 0x30
000073ef1c5d111f  movaps [rsp], xmm15
000073ef1c5d1124  movaps [rsp+0x10], xmm10
000073ef1c5d112a  movaps [rsp+0x20], xmm12
000073ef1c5d1130  lea rdi, [rsp]
000073ef1c5d1134  mov esi, 0x00
000073ef1c5d1139  mov rax, 0x56F25E118530
000073ef1c5d1143  call rax
000073ef1c5d1145  movaps xmm15, [rsp]
000073ef1c5d114a  add rsp, 0x30
000073ef1c5d114e  vmovaps xmm0, [rsp]
000073ef1c5d1153  vmovaps xmm1, [rsp+0x10]
000073ef1c5d1159  vmovaps xmm2, [rsp+0x20]
000073ef1c5d115f  vmovaps xmm3, [rsp+0x30]
000073ef1c5d1165  vmovaps xmm4, [rsp+0x40]
000073ef1c5d116b  vmovaps xmm5, [rsp+0x50]
000073ef1c5d1171  vmovaps xmm6, [rsp+0x60]
000073ef1c5d1177  vmovaps xmm7, [rsp+0x70]
000073ef1c5d117d  vmovaps xmm8, [rsp+0x80]
000073ef1c5d1186  vmovaps xmm9, [rsp+0x90]
000073ef1c5d118f  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d1198  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d11a1  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d11aa  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d11b3  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d11bc  add rsp, 0xF0
000073ef1c5d11c3  pop r11
000073ef1c5d11c5  pop r10
000073ef1c5d11c7  pop r9
000073ef1c5d11c9  pop r8
000073ef1c5d11cb  pop rsi
000073ef1c5d11cc  pop rdi
000073ef1c5d11cd  pop rdx
000073ef1c5d11ce  pop rcx
000073ef1c5d11cf  pop rax
000073ef1c5d11d0  add rsp, 0x08
000073ef1c5d11d4  jmp 0x000073EF1C5CF75E
000073ef1c5d11d9  call 0x000073EF1C3FF430
000073ef1c5d11de  jmp 0x000073EF1C5CF7EE
000073ef1c5d11e3  call 0x000073EF1C3FF430
000073ef1c5d11e8  jmp 0x000073EF1C5CF801
000073ef1c5d11ed  sub rsp, 0x08
000073ef1c5d11f1  push rax
000073ef1c5d11f2  push rcx
000073ef1c5d11f3  push rdx
000073ef1c5d11f4  push rdi
000073ef1c5d11f5  push rsi
000073ef1c5d11f6  push r8
000073ef1c5d11f8  push r9
000073ef1c5d11fa  push r10
000073ef1c5d11fc  push r11
000073ef1c5d11fe  sub rsp, 0xF0
000073ef1c5d1205  vmovaps [rsp], xmm0
000073ef1c5d120a  vmovaps [rsp+0x10], xmm2
000073ef1c5d1210  vmovaps [rsp+0x20], xmm3
000073ef1c5d1216  vmovaps [rsp+0x30], xmm4
000073ef1c5d121c  vmovaps [rsp+0x40], xmm5
000073ef1c5d1222  vmovaps [rsp+0x50], xmm6
000073ef1c5d1228  vmovaps [rsp+0x60], xmm7
000073ef1c5d122e  vmovaps [rsp+0x70], xmm8
000073ef1c5d1234  vmovaps [rsp+0x80], xmm9
000073ef1c5d123d  vmovaps [rsp+0x90], xmm10
000073ef1c5d1246  vmovaps [rsp+0xA0], xmm11
000073ef1c5d124f  vmovaps [rsp+0xB0], xmm12
000073ef1c5d1258  vmovaps [rsp+0xC0], xmm13
000073ef1c5d1261  vmovaps [rsp+0xD0], xmm14
000073ef1c5d126a  vmovaps [rsp+0xE0], xmm15
000073ef1c5d1273  sub rsp, 0x30
000073ef1c5d1277  movaps [rsp], xmm1
000073ef1c5d127b  movaps [rsp+0x10], xmm13
000073ef1c5d1281  movaps [rsp+0x20], xmm2
000073ef1c5d1286  lea rdi, [rsp]
000073ef1c5d128a  mov esi, 0x00
000073ef1c5d128f  mov rax, 0x56F25E118530
000073ef1c5d1299  call rax
000073ef1c5d129b  movaps xmm1, [rsp]
000073ef1c5d129f  add rsp, 0x30
000073ef1c5d12a3  vmovaps xmm0, [rsp]
000073ef1c5d12a8  vmovaps xmm2, [rsp+0x10]
000073ef1c5d12ae  vmovaps xmm3, [rsp+0x20]
000073ef1c5d12b4  vmovaps xmm4, [rsp+0x30]
000073ef1c5d12ba  vmovaps xmm5, [rsp+0x40]
000073ef1c5d12c0  vmovaps xmm6, [rsp+0x50]
000073ef1c5d12c6  vmovaps xmm7, [rsp+0x60]
000073ef1c5d12cc  vmovaps xmm8, [rsp+0x70]
000073ef1c5d12d2  vmovaps xmm9, [rsp+0x80]
000073ef1c5d12db  vmovaps xmm10, [rsp+0x90]
000073ef1c5d12e4  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d12ed  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d12f6  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d12ff  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d1308  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d1311  add rsp, 0xF0
000073ef1c5d1318  pop r11
000073ef1c5d131a  pop r10
000073ef1c5d131c  pop r9
000073ef1c5d131e  pop r8
000073ef1c5d1320  pop rsi
000073ef1c5d1321  pop rdi
000073ef1c5d1322  pop rdx
000073ef1c5d1323  pop rcx
000073ef1c5d1324  pop rax
000073ef1c5d1325  add rsp, 0x08
000073ef1c5d1329  jmp 0x000073EF1C5CF82C
000073ef1c5d132e  call 0x000073EF1C40E760
000073ef1c5d1333  jmp 0x000073EF1C5CF839
000073ef1c5d1338  sub rsp, 0x08
000073ef1c5d133c  push rax
000073ef1c5d133d  push rcx
000073ef1c5d133e  push rdx
000073ef1c5d133f  push rdi
000073ef1c5d1340  push rsi
000073ef1c5d1341  push r8
000073ef1c5d1343  push r9
000073ef1c5d1345  push r10
000073ef1c5d1347  push r11
000073ef1c5d1349  sub rsp, 0xF0
000073ef1c5d1350  vmovaps [rsp], xmm0
000073ef1c5d1355  vmovaps [rsp+0x10], xmm1
000073ef1c5d135b  vmovaps [rsp+0x20], xmm2
000073ef1c5d1361  vmovaps [rsp+0x30], xmm3
000073ef1c5d1367  vmovaps [rsp+0x40], xmm4
000073ef1c5d136d  vmovaps [rsp+0x50], xmm5
000073ef1c5d1373  vmovaps [rsp+0x60], xmm6
000073ef1c5d1379  vmovaps [rsp+0x70], xmm7
000073ef1c5d137f  vmovaps [rsp+0x80], xmm8
000073ef1c5d1388  vmovaps [rsp+0x90], xmm9
000073ef1c5d1391  vmovaps [rsp+0xA0], xmm10
000073ef1c5d139a  vmovaps [rsp+0xB0], xmm11
000073ef1c5d13a3  vmovaps [rsp+0xC0], xmm12
000073ef1c5d13ac  vmovaps [rsp+0xD0], xmm14
000073ef1c5d13b5  vmovaps [rsp+0xE0], xmm15
000073ef1c5d13be  sub rsp, 0x30
000073ef1c5d13c2  movaps [rsp], xmm13
000073ef1c5d13c7  movaps [rsp+0x10], xmm2
000073ef1c5d13cc  movaps [rsp+0x20], xmm1
000073ef1c5d13d1  lea rdi, [rsp]
000073ef1c5d13d5  mov esi, 0x00
000073ef1c5d13da  mov rax, 0x56F25E118530
000073ef1c5d13e4  call rax
000073ef1c5d13e6  movaps xmm13, [rsp]
000073ef1c5d13eb  add rsp, 0x30
000073ef1c5d13ef  vmovaps xmm0, [rsp]
000073ef1c5d13f4  vmovaps xmm1, [rsp+0x10]
000073ef1c5d13fa  vmovaps xmm2, [rsp+0x20]
000073ef1c5d1400  vmovaps xmm3, [rsp+0x30]
000073ef1c5d1406  vmovaps xmm4, [rsp+0x40]
000073ef1c5d140c  vmovaps xmm5, [rsp+0x50]
000073ef1c5d1412  vmovaps xmm6, [rsp+0x60]
000073ef1c5d1418  vmovaps xmm7, [rsp+0x70]
000073ef1c5d141e  vmovaps xmm8, [rsp+0x80]
000073ef1c5d1427  vmovaps xmm9, [rsp+0x90]
000073ef1c5d1430  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d1439  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d1442  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d144b  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d1454  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d145d  add rsp, 0xF0
000073ef1c5d1464  pop r11
000073ef1c5d1466  pop r10
000073ef1c5d1468  pop r9
000073ef1c5d146a  pop r8
000073ef1c5d146c  pop rsi
000073ef1c5d146d  pop rdi
000073ef1c5d146e  pop rdx
000073ef1c5d146f  pop rcx
000073ef1c5d1470  pop rax
000073ef1c5d1471  add rsp, 0x08
000073ef1c5d1475  jmp 0x000073EF1C5CF878
000073ef1c5d147a  sub rsp, 0x08
000073ef1c5d147e  push rax
000073ef1c5d147f  push rcx
000073ef1c5d1480  push rdx
000073ef1c5d1481  push rdi
000073ef1c5d1482  push rsi
000073ef1c5d1483  push r8
000073ef1c5d1485  push r9
000073ef1c5d1487  push r10
000073ef1c5d1489  push r11
000073ef1c5d148b  sub rsp, 0xF0
000073ef1c5d1492  vmovaps [rsp], xmm0
000073ef1c5d1497  vmovaps [rsp+0x10], xmm2
000073ef1c5d149d  vmovaps [rsp+0x20], xmm3
000073ef1c5d14a3  vmovaps [rsp+0x30], xmm4
000073ef1c5d14a9  vmovaps [rsp+0x40], xmm5
000073ef1c5d14af  vmovaps [rsp+0x50], xmm6
000073ef1c5d14b5  vmovaps [rsp+0x60], xmm7
000073ef1c5d14bb  vmovaps [rsp+0x70], xmm8
000073ef1c5d14c1  vmovaps [rsp+0x80], xmm9
000073ef1c5d14ca  vmovaps [rsp+0x90], xmm10
000073ef1c5d14d3  vmovaps [rsp+0xA0], xmm11
000073ef1c5d14dc  vmovaps [rsp+0xB0], xmm12
000073ef1c5d14e5  vmovaps [rsp+0xC0], xmm13
000073ef1c5d14ee  vmovaps [rsp+0xD0], xmm14
000073ef1c5d14f7  vmovaps [rsp+0xE0], xmm15
000073ef1c5d1500  sub rsp, 0x30
000073ef1c5d1504  movaps [rsp], xmm1
000073ef1c5d1508  movaps [rsp+0x10], xmm15
000073ef1c5d150e  movaps [rsp+0x20], xmm2
000073ef1c5d1513  lea rdi, [rsp]
000073ef1c5d1517  mov esi, 0x00
000073ef1c5d151c  mov rax, 0x56F25E118530
000073ef1c5d1526  call rax
000073ef1c5d1528  movaps xmm1, [rsp]
000073ef1c5d152c  add rsp, 0x30
000073ef1c5d1530  vmovaps xmm0, [rsp]
000073ef1c5d1535  vmovaps xmm2, [rsp+0x10]
000073ef1c5d153b  vmovaps xmm3, [rsp+0x20]
000073ef1c5d1541  vmovaps xmm4, [rsp+0x30]
000073ef1c5d1547  vmovaps xmm5, [rsp+0x40]
000073ef1c5d154d  vmovaps xmm6, [rsp+0x50]
000073ef1c5d1553  vmovaps xmm7, [rsp+0x60]
000073ef1c5d1559  vmovaps xmm8, [rsp+0x70]
000073ef1c5d155f  vmovaps xmm9, [rsp+0x80]
000073ef1c5d1568  vmovaps xmm10, [rsp+0x90]
000073ef1c5d1571  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d157a  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d1583  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d158c  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d1595  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d159e  add rsp, 0xF0
000073ef1c5d15a5  pop r11
000073ef1c5d15a7  pop r10
000073ef1c5d15a9  pop r9
000073ef1c5d15ab  pop r8
000073ef1c5d15ad  pop rsi
000073ef1c5d15ae  pop rdi
000073ef1c5d15af  pop rdx
000073ef1c5d15b0  pop rcx
000073ef1c5d15b1  pop rax
000073ef1c5d15b2  add rsp, 0x08
000073ef1c5d15b6  jmp 0x000073EF1C5CF8AC
000073ef1c5d15bb  sub rsp, 0x08
000073ef1c5d15bf  push rax
000073ef1c5d15c0  push rcx
000073ef1c5d15c1  push rdx
000073ef1c5d15c2  push rdi
000073ef1c5d15c3  push rsi
000073ef1c5d15c4  push r8
000073ef1c5d15c6  push r9
000073ef1c5d15c8  push r10
000073ef1c5d15ca  push r11
000073ef1c5d15cc  sub rsp, 0xF0
000073ef1c5d15d3  vmovaps [rsp], xmm0
000073ef1c5d15d8  vmovaps [rsp+0x10], xmm1
000073ef1c5d15de  vmovaps [rsp+0x20], xmm2
000073ef1c5d15e4  vmovaps [rsp+0x30], xmm3
000073ef1c5d15ea  vmovaps [rsp+0x40], xmm4
000073ef1c5d15f0  vmovaps [rsp+0x50], xmm5
000073ef1c5d15f6  vmovaps [rsp+0x60], xmm6
000073ef1c5d15fc  vmovaps [rsp+0x70], xmm7
000073ef1c5d1602  vmovaps [rsp+0x80], xmm8
000073ef1c5d160b  vmovaps [rsp+0x90], xmm9
000073ef1c5d1614  vmovaps [rsp+0xA0], xmm10
000073ef1c5d161d  vmovaps [rsp+0xB0], xmm11
000073ef1c5d1626  vmovaps [rsp+0xC0], xmm12
000073ef1c5d162f  vmovaps [rsp+0xD0], xmm13
000073ef1c5d1638  vmovaps [rsp+0xE0], xmm15
000073ef1c5d1641  sub rsp, 0x30
000073ef1c5d1645  movaps [rsp], xmm14
000073ef1c5d164a  movaps [rsp+0x10], xmm2
000073ef1c5d164f  movaps [rsp+0x20], xmm15
000073ef1c5d1655  lea rdi, [rsp]
000073ef1c5d1659  mov esi, 0x00
000073ef1c5d165e  mov rax, 0x56F25E118530
000073ef1c5d1668  call rax
000073ef1c5d166a  movaps xmm14, [rsp]
000073ef1c5d166f  add rsp, 0x30
000073ef1c5d1673  vmovaps xmm0, [rsp]
000073ef1c5d1678  vmovaps xmm1, [rsp+0x10]
000073ef1c5d167e  vmovaps xmm2, [rsp+0x20]
000073ef1c5d1684  vmovaps xmm3, [rsp+0x30]
000073ef1c5d168a  vmovaps xmm4, [rsp+0x40]
000073ef1c5d1690  vmovaps xmm5, [rsp+0x50]
000073ef1c5d1696  vmovaps xmm6, [rsp+0x60]
000073ef1c5d169c  vmovaps xmm7, [rsp+0x70]
000073ef1c5d16a2  vmovaps xmm8, [rsp+0x80]
000073ef1c5d16ab  vmovaps xmm9, [rsp+0x90]
000073ef1c5d16b4  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d16bd  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d16c6  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d16cf  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d16d8  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d16e1  add rsp, 0xF0
000073ef1c5d16e8  pop r11
000073ef1c5d16ea  pop r10
000073ef1c5d16ec  pop r9
000073ef1c5d16ee  pop r8
000073ef1c5d16f0  pop rsi
000073ef1c5d16f1  pop rdi
000073ef1c5d16f2  pop rdx
000073ef1c5d16f3  pop rcx
000073ef1c5d16f4  pop rax
000073ef1c5d16f5  add rsp, 0x08
000073ef1c5d16f9  jmp 0x000073EF1C5CF8E7
000073ef1c5d16fe  sub rsp, 0x08
000073ef1c5d1702  push rax
000073ef1c5d1703  push rcx
000073ef1c5d1704  push rdx
000073ef1c5d1705  push rdi
000073ef1c5d1706  push rsi
000073ef1c5d1707  push r8
000073ef1c5d1709  push r9
000073ef1c5d170b  push r10
000073ef1c5d170d  push r11
000073ef1c5d170f  sub rsp, 0xF0
000073ef1c5d1716  vmovaps [rsp], xmm0
000073ef1c5d171b  vmovaps [rsp+0x10], xmm1
000073ef1c5d1721  vmovaps [rsp+0x20], xmm2
000073ef1c5d1727  vmovaps [rsp+0x30], xmm3
000073ef1c5d172d  vmovaps [rsp+0x40], xmm4
000073ef1c5d1733  vmovaps [rsp+0x50], xmm5
000073ef1c5d1739  vmovaps [rsp+0x60], xmm6
000073ef1c5d173f  vmovaps [rsp+0x70], xmm7
000073ef1c5d1745  vmovaps [rsp+0x80], xmm8
000073ef1c5d174e  vmovaps [rsp+0x90], xmm9
000073ef1c5d1757  vmovaps [rsp+0xA0], xmm10
000073ef1c5d1760  vmovaps [rsp+0xB0], xmm11
000073ef1c5d1769  vmovaps [rsp+0xC0], xmm12
000073ef1c5d1772  vmovaps [rsp+0xD0], xmm13
000073ef1c5d177b  vmovaps [rsp+0xE0], xmm14
000073ef1c5d1784  sub rsp, 0x30
000073ef1c5d1788  movaps [rsp], xmm15
000073ef1c5d178d  movaps [rsp+0x10], xmm2
000073ef1c5d1792  movaps [rsp+0x20], xmm1
000073ef1c5d1797  lea rdi, [rsp]
000073ef1c5d179b  mov esi, 0x00
000073ef1c5d17a0  mov rax, 0x56F25E118530
000073ef1c5d17aa  call rax
000073ef1c5d17ac  movaps xmm15, [rsp]
000073ef1c5d17b1  add rsp, 0x30
000073ef1c5d17b5  vmovaps xmm0, [rsp]
000073ef1c5d17ba  vmovaps xmm1, [rsp+0x10]
000073ef1c5d17c0  vmovaps xmm2, [rsp+0x20]
000073ef1c5d17c6  vmovaps xmm3, [rsp+0x30]
000073ef1c5d17cc  vmovaps xmm4, [rsp+0x40]
000073ef1c5d17d2  vmovaps xmm5, [rsp+0x50]
000073ef1c5d17d8  vmovaps xmm6, [rsp+0x60]
000073ef1c5d17de  vmovaps xmm7, [rsp+0x70]
000073ef1c5d17e4  vmovaps xmm8, [rsp+0x80]
000073ef1c5d17ed  vmovaps xmm9, [rsp+0x90]
000073ef1c5d17f6  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d17ff  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d1808  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d1811  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d181a  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d1823  add rsp, 0xF0
000073ef1c5d182a  pop r11
000073ef1c5d182c  pop r10
000073ef1c5d182e  pop r9
000073ef1c5d1830  pop r8
000073ef1c5d1832  pop rsi
000073ef1c5d1833  pop rdi
000073ef1c5d1834  pop rdx
000073ef1c5d1835  pop rcx
000073ef1c5d1836  pop rax
000073ef1c5d1837  add rsp, 0x08
000073ef1c5d183b  jmp 0x000073EF1C5CF923
000073ef1c5d1840  call 0x000073EF1C3FF430
000073ef1c5d1845  jmp 0x000073EF1C5CF930
000073ef1c5d184a  sub rsp, 0x08
000073ef1c5d184e  push rax
000073ef1c5d184f  push rcx
000073ef1c5d1850  push rdx
000073ef1c5d1851  push rdi
000073ef1c5d1852  push rsi
000073ef1c5d1853  push r8
000073ef1c5d1855  push r9
000073ef1c5d1857  push r10
000073ef1c5d1859  push r11
000073ef1c5d185b  sub rsp, 0xF0
000073ef1c5d1862  vmovaps [rsp], xmm0
000073ef1c5d1867  vmovaps [rsp+0x10], xmm1
000073ef1c5d186d  vmovaps [rsp+0x20], xmm3
000073ef1c5d1873  vmovaps [rsp+0x30], xmm4
000073ef1c5d1879  vmovaps [rsp+0x40], xmm5
000073ef1c5d187f  vmovaps [rsp+0x50], xmm6
000073ef1c5d1885  vmovaps [rsp+0x60], xmm7
000073ef1c5d188b  vmovaps [rsp+0x70], xmm8
000073ef1c5d1891  vmovaps [rsp+0x80], xmm9
000073ef1c5d189a  vmovaps [rsp+0x90], xmm10
000073ef1c5d18a3  vmovaps [rsp+0xA0], xmm11
000073ef1c5d18ac  vmovaps [rsp+0xB0], xmm12
000073ef1c5d18b5  vmovaps [rsp+0xC0], xmm13
000073ef1c5d18be  vmovaps [rsp+0xD0], xmm14
000073ef1c5d18c7  vmovaps [rsp+0xE0], xmm15
000073ef1c5d18d0  sub rsp, 0x30
000073ef1c5d18d4  movaps [rsp], xmm2
000073ef1c5d18d8  movaps [rsp+0x10], xmm1
000073ef1c5d18dd  movaps [rsp+0x20], xmm14
000073ef1c5d18e3  lea rdi, [rsp]
000073ef1c5d18e7  mov esi, 0x00
000073ef1c5d18ec  mov rax, 0x56F25E118530
000073ef1c5d18f6  call rax
000073ef1c5d18f8  movaps xmm2, [rsp]
000073ef1c5d18fc  add rsp, 0x30
000073ef1c5d1900  vmovaps xmm0, [rsp]
000073ef1c5d1905  vmovaps xmm1, [rsp+0x10]
000073ef1c5d190b  vmovaps xmm3, [rsp+0x20]
000073ef1c5d1911  vmovaps xmm4, [rsp+0x30]
000073ef1c5d1917  vmovaps xmm5, [rsp+0x40]
000073ef1c5d191d  vmovaps xmm6, [rsp+0x50]
000073ef1c5d1923  vmovaps xmm7, [rsp+0x60]
000073ef1c5d1929  vmovaps xmm8, [rsp+0x70]
000073ef1c5d192f  vmovaps xmm9, [rsp+0x80]
000073ef1c5d1938  vmovaps xmm10, [rsp+0x90]
000073ef1c5d1941  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d194a  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d1953  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d195c  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d1965  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d196e  add rsp, 0xF0
000073ef1c5d1975  pop r11
000073ef1c5d1977  pop r10
000073ef1c5d1979  pop r9
000073ef1c5d197b  pop r8
000073ef1c5d197d  pop rsi
000073ef1c5d197e  pop rdi
000073ef1c5d197f  pop rdx
000073ef1c5d1980  pop rcx
000073ef1c5d1981  pop rax
000073ef1c5d1982  add rsp, 0x08
000073ef1c5d1986  jmp 0x000073EF1C5CF96D
000073ef1c5d198b  sub rsp, 0x08
000073ef1c5d198f  push rax
000073ef1c5d1990  push rcx
000073ef1c5d1991  push rdx
000073ef1c5d1992  push rdi
000073ef1c5d1993  push rsi
000073ef1c5d1994  push r8
000073ef1c5d1996  push r9
000073ef1c5d1998  push r10
000073ef1c5d199a  push r11
000073ef1c5d199c  sub rsp, 0xF0
000073ef1c5d19a3  vmovaps [rsp], xmm0
000073ef1c5d19a8  vmovaps [rsp+0x10], xmm1
000073ef1c5d19ae  vmovaps [rsp+0x20], xmm2
000073ef1c5d19b4  vmovaps [rsp+0x30], xmm3
000073ef1c5d19ba  vmovaps [rsp+0x40], xmm4
000073ef1c5d19c0  vmovaps [rsp+0x50], xmm5
000073ef1c5d19c6  vmovaps [rsp+0x60], xmm6
000073ef1c5d19cc  vmovaps [rsp+0x70], xmm7
000073ef1c5d19d2  vmovaps [rsp+0x80], xmm8
000073ef1c5d19db  vmovaps [rsp+0x90], xmm9
000073ef1c5d19e4  vmovaps [rsp+0xA0], xmm10
000073ef1c5d19ed  vmovaps [rsp+0xB0], xmm11
000073ef1c5d19f6  vmovaps [rsp+0xC0], xmm12
000073ef1c5d19ff  vmovaps [rsp+0xD0], xmm13
000073ef1c5d1a08  vmovaps [rsp+0xE0], xmm14
000073ef1c5d1a11  sub rsp, 0x30
000073ef1c5d1a15  movaps [rsp], xmm15
000073ef1c5d1a1a  movaps [rsp+0x10], xmm14
000073ef1c5d1a20  movaps [rsp+0x20], xmm1
000073ef1c5d1a25  lea rdi, [rsp]
000073ef1c5d1a29  mov esi, 0x00
000073ef1c5d1a2e  mov rax, 0x56F25E118530
000073ef1c5d1a38  call rax
000073ef1c5d1a3a  movaps xmm15, [rsp]
000073ef1c5d1a3f  add rsp, 0x30
000073ef1c5d1a43  vmovaps xmm0, [rsp]
000073ef1c5d1a48  vmovaps xmm1, [rsp+0x10]
000073ef1c5d1a4e  vmovaps xmm2, [rsp+0x20]
000073ef1c5d1a54  vmovaps xmm3, [rsp+0x30]
000073ef1c5d1a5a  vmovaps xmm4, [rsp+0x40]
000073ef1c5d1a60  vmovaps xmm5, [rsp+0x50]
000073ef1c5d1a66  vmovaps xmm6, [rsp+0x60]
000073ef1c5d1a6c  vmovaps xmm7, [rsp+0x70]
000073ef1c5d1a72  vmovaps xmm8, [rsp+0x80]
000073ef1c5d1a7b  vmovaps xmm9, [rsp+0x90]
000073ef1c5d1a84  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d1a8d  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d1a96  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d1a9f  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d1aa8  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d1ab1  add rsp, 0xF0
000073ef1c5d1ab8  pop r11
000073ef1c5d1aba  pop r10
000073ef1c5d1abc  pop r9
000073ef1c5d1abe  pop r8
000073ef1c5d1ac0  pop rsi
000073ef1c5d1ac1  pop rdi
000073ef1c5d1ac2  pop rdx
000073ef1c5d1ac3  pop rcx
000073ef1c5d1ac4  pop rax
000073ef1c5d1ac5  add rsp, 0x08
000073ef1c5d1ac9  jmp 0x000073EF1C5CF9E7
000073ef1c5d1ace  call 0x000073EF1C3FF430
000073ef1c5d1ad3  jmp 0x000073EF1C5CF9F4
000073ef1c5d1ad8  sub rsp, 0x08
000073ef1c5d1adc  push rax
000073ef1c5d1add  push rcx
000073ef1c5d1ade  push rdx
000073ef1c5d1adf  push rdi
000073ef1c5d1ae0  push rsi
000073ef1c5d1ae1  push r8
000073ef1c5d1ae3  push r9
000073ef1c5d1ae5  push r10
000073ef1c5d1ae7  push r11
000073ef1c5d1ae9  sub rsp, 0xF0
000073ef1c5d1af0  vmovaps [rsp], xmm0
000073ef1c5d1af5  vmovaps [rsp+0x10], xmm1
000073ef1c5d1afb  vmovaps [rsp+0x20], xmm2
000073ef1c5d1b01  vmovaps [rsp+0x30], xmm3
000073ef1c5d1b07  vmovaps [rsp+0x40], xmm4
000073ef1c5d1b0d  vmovaps [rsp+0x50], xmm5
000073ef1c5d1b13  vmovaps [rsp+0x60], xmm6
000073ef1c5d1b19  vmovaps [rsp+0x70], xmm7
000073ef1c5d1b1f  vmovaps [rsp+0x80], xmm8
000073ef1c5d1b28  vmovaps [rsp+0x90], xmm9
000073ef1c5d1b31  vmovaps [rsp+0xA0], xmm10
000073ef1c5d1b3a  vmovaps [rsp+0xB0], xmm11
000073ef1c5d1b43  vmovaps [rsp+0xC0], xmm12
000073ef1c5d1b4c  vmovaps [rsp+0xD0], xmm13
000073ef1c5d1b55  vmovaps [rsp+0xE0], xmm15
000073ef1c5d1b5e  sub rsp, 0x30
000073ef1c5d1b62  movaps [rsp], xmm14
000073ef1c5d1b67  movaps [rsp+0x10], xmm13
000073ef1c5d1b6d  movaps [rsp+0x20], xmm1
000073ef1c5d1b72  lea rdi, [rsp]
000073ef1c5d1b76  mov esi, 0x00
000073ef1c5d1b7b  mov rax, 0x56F25E118530
000073ef1c5d1b85  call rax
000073ef1c5d1b87  movaps xmm14, [rsp]
000073ef1c5d1b8c  add rsp, 0x30
000073ef1c5d1b90  vmovaps xmm0, [rsp]
000073ef1c5d1b95  vmovaps xmm1, [rsp+0x10]
000073ef1c5d1b9b  vmovaps xmm2, [rsp+0x20]
000073ef1c5d1ba1  vmovaps xmm3, [rsp+0x30]
000073ef1c5d1ba7  vmovaps xmm4, [rsp+0x40]
000073ef1c5d1bad  vmovaps xmm5, [rsp+0x50]
000073ef1c5d1bb3  vmovaps xmm6, [rsp+0x60]
000073ef1c5d1bb9  vmovaps xmm7, [rsp+0x70]
000073ef1c5d1bbf  vmovaps xmm8, [rsp+0x80]
000073ef1c5d1bc8  vmovaps xmm9, [rsp+0x90]
000073ef1c5d1bd1  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d1bda  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d1be3  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d1bec  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d1bf5  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d1bfe  add rsp, 0xF0
000073ef1c5d1c05  pop r11
000073ef1c5d1c07  pop r10
000073ef1c5d1c09  pop r9
000073ef1c5d1c0b  pop r8
000073ef1c5d1c0d  pop rsi
000073ef1c5d1c0e  pop rdi
000073ef1c5d1c0f  pop rdx
000073ef1c5d1c10  pop rcx
000073ef1c5d1c11  pop rax
000073ef1c5d1c12  add rsp, 0x08
000073ef1c5d1c16  jmp 0x000073EF1C5CFAAF
000073ef1c5d1c1b  sub rsp, 0x08
000073ef1c5d1c1f  push rax
000073ef1c5d1c20  push rcx
000073ef1c5d1c21  push rdx
000073ef1c5d1c22  push rdi
000073ef1c5d1c23  push rsi
000073ef1c5d1c24  push r8
000073ef1c5d1c26  push r9
000073ef1c5d1c28  push r10
000073ef1c5d1c2a  push r11
000073ef1c5d1c2c  sub rsp, 0xF0
000073ef1c5d1c33  vmovaps [rsp], xmm0
000073ef1c5d1c38  vmovaps [rsp+0x10], xmm1
000073ef1c5d1c3e  vmovaps [rsp+0x20], xmm2
000073ef1c5d1c44  vmovaps [rsp+0x30], xmm3
000073ef1c5d1c4a  vmovaps [rsp+0x40], xmm4
000073ef1c5d1c50  vmovaps [rsp+0x50], xmm5
000073ef1c5d1c56  vmovaps [rsp+0x60], xmm6
000073ef1c5d1c5c  vmovaps [rsp+0x70], xmm7
000073ef1c5d1c62  vmovaps [rsp+0x80], xmm8
000073ef1c5d1c6b  vmovaps [rsp+0x90], xmm9
000073ef1c5d1c74  vmovaps [rsp+0xA0], xmm10
000073ef1c5d1c7d  vmovaps [rsp+0xB0], xmm11
000073ef1c5d1c86  vmovaps [rsp+0xC0], xmm12
000073ef1c5d1c8f  vmovaps [rsp+0xD0], xmm13
000073ef1c5d1c98  vmovaps [rsp+0xE0], xmm14
000073ef1c5d1ca1  sub rsp, 0x30
000073ef1c5d1ca5  movaps [rsp], xmm15
000073ef1c5d1caa  movaps [rsp+0x10], xmm13
000073ef1c5d1cb0  movaps [rsp+0x20], xmm1
000073ef1c5d1cb5  lea rdi, [rsp]
000073ef1c5d1cb9  mov esi, 0x00
000073ef1c5d1cbe  mov rax, 0x56F25E118530
000073ef1c5d1cc8  call rax
000073ef1c5d1cca  movaps xmm15, [rsp]
000073ef1c5d1ccf  add rsp, 0x30
000073ef1c5d1cd3  vmovaps xmm0, [rsp]
000073ef1c5d1cd8  vmovaps xmm1, [rsp+0x10]
000073ef1c5d1cde  vmovaps xmm2, [rsp+0x20]
000073ef1c5d1ce4  vmovaps xmm3, [rsp+0x30]
000073ef1c5d1cea  vmovaps xmm4, [rsp+0x40]
000073ef1c5d1cf0  vmovaps xmm5, [rsp+0x50]
000073ef1c5d1cf6  vmovaps xmm6, [rsp+0x60]
000073ef1c5d1cfc  vmovaps xmm7, [rsp+0x70]
000073ef1c5d1d02  vmovaps xmm8, [rsp+0x80]
000073ef1c5d1d0b  vmovaps xmm9, [rsp+0x90]
000073ef1c5d1d14  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d1d1d  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d1d26  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d1d2f  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d1d38  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d1d41  add rsp, 0xF0
000073ef1c5d1d48  pop r11
000073ef1c5d1d4a  pop r10
000073ef1c5d1d4c  pop r9
000073ef1c5d1d4e  pop r8
000073ef1c5d1d50  pop rsi
000073ef1c5d1d51  pop rdi
000073ef1c5d1d52  pop rdx
000073ef1c5d1d53  pop rcx
000073ef1c5d1d54  pop rax
000073ef1c5d1d55  add rsp, 0x08
000073ef1c5d1d59  jmp 0x000073EF1C5CFAEB
000073ef1c5d1d5e  call 0x000073EF1C3FF430
000073ef1c5d1d63  jmp 0x000073EF1C5CFAF8
000073ef1c5d1d68  sub rsp, 0x08
000073ef1c5d1d6c  push rax
000073ef1c5d1d6d  push rcx
000073ef1c5d1d6e  push rdx
000073ef1c5d1d6f  push rdi
000073ef1c5d1d70  push rsi
000073ef1c5d1d71  push r8
000073ef1c5d1d73  push r9
000073ef1c5d1d75  push r10
000073ef1c5d1d77  push r11
000073ef1c5d1d79  sub rsp, 0xF0
000073ef1c5d1d80  vmovaps [rsp], xmm0
000073ef1c5d1d85  vmovaps [rsp+0x10], xmm1
000073ef1c5d1d8b  vmovaps [rsp+0x20], xmm2
000073ef1c5d1d91  vmovaps [rsp+0x30], xmm3
000073ef1c5d1d97  vmovaps [rsp+0x40], xmm4
000073ef1c5d1d9d  vmovaps [rsp+0x50], xmm5
000073ef1c5d1da3  vmovaps [rsp+0x60], xmm6
000073ef1c5d1da9  vmovaps [rsp+0x70], xmm7
000073ef1c5d1daf  vmovaps [rsp+0x80], xmm8
000073ef1c5d1db8  vmovaps [rsp+0x90], xmm9
000073ef1c5d1dc1  vmovaps [rsp+0xA0], xmm10
000073ef1c5d1dca  vmovaps [rsp+0xB0], xmm11
000073ef1c5d1dd3  vmovaps [rsp+0xC0], xmm12
000073ef1c5d1ddc  vmovaps [rsp+0xD0], xmm13
000073ef1c5d1de5  vmovaps [rsp+0xE0], xmm15
000073ef1c5d1dee  sub rsp, 0x30
000073ef1c5d1df2  movaps [rsp], xmm14
000073ef1c5d1df7  movaps [rsp+0x10], xmm13
000073ef1c5d1dfd  movaps [rsp+0x20], xmm2
000073ef1c5d1e02  lea rdi, [rsp]
000073ef1c5d1e06  mov esi, 0x00
000073ef1c5d1e0b  mov rax, 0x56F25E118530
000073ef1c5d1e15  call rax
000073ef1c5d1e17  movaps xmm14, [rsp]
000073ef1c5d1e1c  add rsp, 0x30
000073ef1c5d1e20  vmovaps xmm0, [rsp]
000073ef1c5d1e25  vmovaps xmm1, [rsp+0x10]
000073ef1c5d1e2b  vmovaps xmm2, [rsp+0x20]
000073ef1c5d1e31  vmovaps xmm3, [rsp+0x30]
000073ef1c5d1e37  vmovaps xmm4, [rsp+0x40]
000073ef1c5d1e3d  vmovaps xmm5, [rsp+0x50]
000073ef1c5d1e43  vmovaps xmm6, [rsp+0x60]
000073ef1c5d1e49  vmovaps xmm7, [rsp+0x70]
000073ef1c5d1e4f  vmovaps xmm8, [rsp+0x80]
000073ef1c5d1e58  vmovaps xmm9, [rsp+0x90]
000073ef1c5d1e61  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d1e6a  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d1e73  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d1e7c  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d1e85  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d1e8e  add rsp, 0xF0
000073ef1c5d1e95  pop r11
000073ef1c5d1e97  pop r10
000073ef1c5d1e99  pop r9
000073ef1c5d1e9b  pop r8
000073ef1c5d1e9d  pop rsi
000073ef1c5d1e9e  pop rdi
000073ef1c5d1e9f  pop rdx
000073ef1c5d1ea0  pop rcx
000073ef1c5d1ea1  pop rax
000073ef1c5d1ea2  add rsp, 0x08
000073ef1c5d1ea6  jmp 0x000073EF1C5CFB24
000073ef1c5d1eab  sub rsp, 0x08
000073ef1c5d1eaf  push rax
000073ef1c5d1eb0  push rcx
000073ef1c5d1eb1  push rdx
000073ef1c5d1eb2  push rdi
000073ef1c5d1eb3  push rsi
000073ef1c5d1eb4  push r8
000073ef1c5d1eb6  push r9
000073ef1c5d1eb8  push r10
000073ef1c5d1eba  push r11
000073ef1c5d1ebc  sub rsp, 0xF0
000073ef1c5d1ec3  vmovaps [rsp], xmm0
000073ef1c5d1ec8  vmovaps [rsp+0x10], xmm2
000073ef1c5d1ece  vmovaps [rsp+0x20], xmm3
000073ef1c5d1ed4  vmovaps [rsp+0x30], xmm4
000073ef1c5d1eda  vmovaps [rsp+0x40], xmm5
000073ef1c5d1ee0  vmovaps [rsp+0x50], xmm6
000073ef1c5d1ee6  vmovaps [rsp+0x60], xmm7
000073ef1c5d1eec  vmovaps [rsp+0x70], xmm8
000073ef1c5d1ef2  vmovaps [rsp+0x80], xmm9
000073ef1c5d1efb  vmovaps [rsp+0x90], xmm10
000073ef1c5d1f04  vmovaps [rsp+0xA0], xmm11
000073ef1c5d1f0d  vmovaps [rsp+0xB0], xmm12
000073ef1c5d1f16  vmovaps [rsp+0xC0], xmm13
000073ef1c5d1f1f  vmovaps [rsp+0xD0], xmm14
000073ef1c5d1f28  vmovaps [rsp+0xE0], xmm15
000073ef1c5d1f31  sub rsp, 0x30
000073ef1c5d1f35  movaps [rsp], xmm1
000073ef1c5d1f39  movaps [rsp+0x10], xmm13
000073ef1c5d1f3f  movaps [rsp+0x20], xmm2
000073ef1c5d1f44  lea rdi, [rsp]
000073ef1c5d1f48  mov esi, 0x00
000073ef1c5d1f4d  mov rax, 0x56F25E118530
000073ef1c5d1f57  call rax
000073ef1c5d1f59  movaps xmm1, [rsp]
000073ef1c5d1f5d  add rsp, 0x30
000073ef1c5d1f61  vmovaps xmm0, [rsp]
000073ef1c5d1f66  vmovaps xmm2, [rsp+0x10]
000073ef1c5d1f6c  vmovaps xmm3, [rsp+0x20]
000073ef1c5d1f72  vmovaps xmm4, [rsp+0x30]
000073ef1c5d1f78  vmovaps xmm5, [rsp+0x40]
000073ef1c5d1f7e  vmovaps xmm6, [rsp+0x50]
000073ef1c5d1f84  vmovaps xmm7, [rsp+0x60]
000073ef1c5d1f8a  vmovaps xmm8, [rsp+0x70]
000073ef1c5d1f90  vmovaps xmm9, [rsp+0x80]
000073ef1c5d1f99  vmovaps xmm10, [rsp+0x90]
000073ef1c5d1fa2  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d1fab  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d1fb4  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d1fbd  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d1fc6  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d1fcf  add rsp, 0xF0
000073ef1c5d1fd6  pop r11
000073ef1c5d1fd8  pop r10
000073ef1c5d1fda  pop r9
000073ef1c5d1fdc  pop r8
000073ef1c5d1fde  pop rsi
000073ef1c5d1fdf  pop rdi
000073ef1c5d1fe0  pop rdx
000073ef1c5d1fe1  pop rcx
000073ef1c5d1fe2  pop rax
000073ef1c5d1fe3  add rsp, 0x08
000073ef1c5d1fe7  jmp 0x000073EF1C5CFB52
000073ef1c5d1fec  sub rsp, 0x08
000073ef1c5d1ff0  push rax
000073ef1c5d1ff1  push rcx
000073ef1c5d1ff2  push rdx
000073ef1c5d1ff3  push rdi
000073ef1c5d1ff4  push rsi
000073ef1c5d1ff5  push r8
000073ef1c5d1ff7  push r9
000073ef1c5d1ff9  push r10
000073ef1c5d1ffb  push r11
000073ef1c5d1ffd  sub rsp, 0xF0
000073ef1c5d2004  vmovaps [rsp], xmm0
000073ef1c5d2009  vmovaps [rsp+0x10], xmm1
000073ef1c5d200f  vmovaps [rsp+0x20], xmm3
000073ef1c5d2015  vmovaps [rsp+0x30], xmm4
000073ef1c5d201b  vmovaps [rsp+0x40], xmm5
000073ef1c5d2021  vmovaps [rsp+0x50], xmm6
000073ef1c5d2027  vmovaps [rsp+0x60], xmm7
000073ef1c5d202d  vmovaps [rsp+0x70], xmm8
000073ef1c5d2033  vmovaps [rsp+0x80], xmm9
000073ef1c5d203c  vmovaps [rsp+0x90], xmm10
000073ef1c5d2045  vmovaps [rsp+0xA0], xmm11
000073ef1c5d204e  vmovaps [rsp+0xB0], xmm12
000073ef1c5d2057  vmovaps [rsp+0xC0], xmm13
000073ef1c5d2060  vmovaps [rsp+0xD0], xmm14
000073ef1c5d2069  vmovaps [rsp+0xE0], xmm15
000073ef1c5d2072  sub rsp, 0x30
000073ef1c5d2076  movaps [rsp], xmm2
000073ef1c5d207a  movaps [rsp+0x10], xmm1
000073ef1c5d207f  movaps [rsp+0x20], xmm13
000073ef1c5d2085  lea rdi, [rsp]
000073ef1c5d2089  mov esi, 0x00
000073ef1c5d208e  mov rax, 0x56F25E118530
000073ef1c5d2098  call rax
000073ef1c5d209a  movaps xmm2, [rsp]
000073ef1c5d209e  add rsp, 0x30
000073ef1c5d20a2  vmovaps xmm0, [rsp]
000073ef1c5d20a7  vmovaps xmm1, [rsp+0x10]
000073ef1c5d20ad  vmovaps xmm3, [rsp+0x20]
000073ef1c5d20b3  vmovaps xmm4, [rsp+0x30]
000073ef1c5d20b9  vmovaps xmm5, [rsp+0x40]
000073ef1c5d20bf  vmovaps xmm6, [rsp+0x50]
000073ef1c5d20c5  vmovaps xmm7, [rsp+0x60]
000073ef1c5d20cb  vmovaps xmm8, [rsp+0x70]
000073ef1c5d20d1  vmovaps xmm9, [rsp+0x80]
000073ef1c5d20da  vmovaps xmm10, [rsp+0x90]
000073ef1c5d20e3  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d20ec  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d20f5  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d20fe  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d2107  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d2110  add rsp, 0xF0
000073ef1c5d2117  pop r11
000073ef1c5d2119  pop r10
000073ef1c5d211b  pop r9
000073ef1c5d211d  pop r8
000073ef1c5d211f  pop rsi
000073ef1c5d2120  pop rdi
000073ef1c5d2121  pop rdx
000073ef1c5d2122  pop rcx
000073ef1c5d2123  pop rax
000073ef1c5d2124  add rsp, 0x08
000073ef1c5d2128  jmp 0x000073EF1C5CFBAB
000073ef1c5d212d  call 0x000073EF1C3FF430
000073ef1c5d2132  jmp 0x000073EF1C5CFBB8
000073ef1c5d2137  sub rsp, 0x08
000073ef1c5d213b  push rax
000073ef1c5d213c  push rcx
000073ef1c5d213d  push rdx
000073ef1c5d213e  push rdi
000073ef1c5d213f  push rsi
000073ef1c5d2140  push r8
000073ef1c5d2142  push r9
000073ef1c5d2144  push r10
000073ef1c5d2146  push r11
000073ef1c5d2148  sub rsp, 0xF0
000073ef1c5d214f  vmovaps [rsp], xmm0
000073ef1c5d2154  vmovaps [rsp+0x10], xmm1
000073ef1c5d215a  vmovaps [rsp+0x20], xmm2
000073ef1c5d2160  vmovaps [rsp+0x30], xmm3
000073ef1c5d2166  vmovaps [rsp+0x40], xmm4
000073ef1c5d216c  vmovaps [rsp+0x50], xmm5
000073ef1c5d2172  vmovaps [rsp+0x60], xmm6
000073ef1c5d2178  vmovaps [rsp+0x70], xmm7
000073ef1c5d217e  vmovaps [rsp+0x80], xmm8
000073ef1c5d2187  vmovaps [rsp+0x90], xmm9
000073ef1c5d2190  vmovaps [rsp+0xA0], xmm10
000073ef1c5d2199  vmovaps [rsp+0xB0], xmm11
000073ef1c5d21a2  vmovaps [rsp+0xC0], xmm12
000073ef1c5d21ab  vmovaps [rsp+0xD0], xmm13
000073ef1c5d21b4  vmovaps [rsp+0xE0], xmm14
000073ef1c5d21bd  sub rsp, 0x30
000073ef1c5d21c1  movaps [rsp], xmm15
000073ef1c5d21c6  movaps [rsp+0x10], xmm13
000073ef1c5d21cc  movaps [rsp+0x20], xmm1
000073ef1c5d21d1  lea rdi, [rsp]
000073ef1c5d21d5  mov esi, 0x00
000073ef1c5d21da  mov rax, 0x56F25E118530
000073ef1c5d21e4  call rax
000073ef1c5d21e6  movaps xmm15, [rsp]
000073ef1c5d21eb  add rsp, 0x30
000073ef1c5d21ef  vmovaps xmm0, [rsp]
000073ef1c5d21f4  vmovaps xmm1, [rsp+0x10]
000073ef1c5d21fa  vmovaps xmm2, [rsp+0x20]
000073ef1c5d2200  vmovaps xmm3, [rsp+0x30]
000073ef1c5d2206  vmovaps xmm4, [rsp+0x40]
000073ef1c5d220c  vmovaps xmm5, [rsp+0x50]
000073ef1c5d2212  vmovaps xmm6, [rsp+0x60]
000073ef1c5d2218  vmovaps xmm7, [rsp+0x70]
000073ef1c5d221e  vmovaps xmm8, [rsp+0x80]
000073ef1c5d2227  vmovaps xmm9, [rsp+0x90]
000073ef1c5d2230  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d2239  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d2242  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d224b  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d2254  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d225d  add rsp, 0xF0
000073ef1c5d2264  pop r11
000073ef1c5d2266  pop r10
000073ef1c5d2268  pop r9
000073ef1c5d226a  pop r8
000073ef1c5d226c  pop rsi
000073ef1c5d226d  pop rdi
000073ef1c5d226e  pop rdx
000073ef1c5d226f  pop rcx
000073ef1c5d2270  pop rax
000073ef1c5d2271  add rsp, 0x08
000073ef1c5d2275  jmp 0x000073EF1C5CFBF7
000073ef1c5d227a  sub rsp, 0x08
000073ef1c5d227e  push rax
000073ef1c5d227f  push rcx
000073ef1c5d2280  push rdx
000073ef1c5d2281  push rdi
000073ef1c5d2282  push rsi
000073ef1c5d2283  push r8
000073ef1c5d2285  push r9
000073ef1c5d2287  push r10
000073ef1c5d2289  push r11
000073ef1c5d228b  sub rsp, 0xF0
000073ef1c5d2292  vmovaps [rsp], xmm0
000073ef1c5d2297  vmovaps [rsp+0x10], xmm1
000073ef1c5d229d  vmovaps [rsp+0x20], xmm2
000073ef1c5d22a3  vmovaps [rsp+0x30], xmm3
000073ef1c5d22a9  vmovaps [rsp+0x40], xmm4
000073ef1c5d22af  vmovaps [rsp+0x50], xmm5
000073ef1c5d22b5  vmovaps [rsp+0x60], xmm6
000073ef1c5d22bb  vmovaps [rsp+0x70], xmm7
000073ef1c5d22c1  vmovaps [rsp+0x80], xmm8
000073ef1c5d22ca  vmovaps [rsp+0x90], xmm9
000073ef1c5d22d3  vmovaps [rsp+0xA0], xmm10
000073ef1c5d22dc  vmovaps [rsp+0xB0], xmm11
000073ef1c5d22e5  vmovaps [rsp+0xC0], xmm12
000073ef1c5d22ee  vmovaps [rsp+0xD0], xmm13
000073ef1c5d22f7  vmovaps [rsp+0xE0], xmm15
000073ef1c5d2300  sub rsp, 0x30
000073ef1c5d2304  movaps [rsp], xmm14
000073ef1c5d2309  movaps [rsp+0x10], xmm11
000073ef1c5d230f  movaps [rsp+0x20], xmm1
000073ef1c5d2314  lea rdi, [rsp]
000073ef1c5d2318  mov esi, 0x00
000073ef1c5d231d  mov rax, 0x56F25E118530
000073ef1c5d2327  call rax
000073ef1c5d2329  movaps xmm14, [rsp]
000073ef1c5d232e  add rsp, 0x30
000073ef1c5d2332  vmovaps xmm0, [rsp]
000073ef1c5d2337  vmovaps xmm1, [rsp+0x10]
000073ef1c5d233d  vmovaps xmm2, [rsp+0x20]
000073ef1c5d2343  vmovaps xmm3, [rsp+0x30]
000073ef1c5d2349  vmovaps xmm4, [rsp+0x40]
000073ef1c5d234f  vmovaps xmm5, [rsp+0x50]
000073ef1c5d2355  vmovaps xmm6, [rsp+0x60]
000073ef1c5d235b  vmovaps xmm7, [rsp+0x70]
000073ef1c5d2361  vmovaps xmm8, [rsp+0x80]
000073ef1c5d236a  vmovaps xmm9, [rsp+0x90]
000073ef1c5d2373  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d237c  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d2385  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d238e  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d2397  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d23a0  add rsp, 0xF0
000073ef1c5d23a7  pop r11
000073ef1c5d23a9  pop r10
000073ef1c5d23ab  pop r9
000073ef1c5d23ad  pop r8
000073ef1c5d23af  pop rsi
000073ef1c5d23b0  pop rdi
000073ef1c5d23b1  pop rdx
000073ef1c5d23b2  pop rcx
000073ef1c5d23b3  pop rax
000073ef1c5d23b4  add rsp, 0x08
000073ef1c5d23b8  jmp 0x000073EF1C5CFC21
000073ef1c5d23bd  sub rsp, 0x08
000073ef1c5d23c1  push rax
000073ef1c5d23c2  push rcx
000073ef1c5d23c3  push rdx
000073ef1c5d23c4  push rdi
000073ef1c5d23c5  push rsi
000073ef1c5d23c6  push r8
000073ef1c5d23c8  push r9
000073ef1c5d23ca  push r10
000073ef1c5d23cc  push r11
000073ef1c5d23ce  sub rsp, 0xF0
000073ef1c5d23d5  vmovaps [rsp], xmm0
000073ef1c5d23da  vmovaps [rsp+0x10], xmm1
000073ef1c5d23e0  vmovaps [rsp+0x20], xmm2
000073ef1c5d23e6  vmovaps [rsp+0x30], xmm3
000073ef1c5d23ec  vmovaps [rsp+0x40], xmm4
000073ef1c5d23f2  vmovaps [rsp+0x50], xmm5
000073ef1c5d23f8  vmovaps [rsp+0x60], xmm6
000073ef1c5d23fe  vmovaps [rsp+0x70], xmm7
000073ef1c5d2404  vmovaps [rsp+0x80], xmm8
000073ef1c5d240d  vmovaps [rsp+0x90], xmm9
000073ef1c5d2416  vmovaps [rsp+0xA0], xmm10
000073ef1c5d241f  vmovaps [rsp+0xB0], xmm11
000073ef1c5d2428  vmovaps [rsp+0xC0], xmm12
000073ef1c5d2431  vmovaps [rsp+0xD0], xmm14
000073ef1c5d243a  vmovaps [rsp+0xE0], xmm15
000073ef1c5d2443  sub rsp, 0x30
000073ef1c5d2447  movaps [rsp], xmm13
000073ef1c5d244c  movaps [rsp+0x10], xmm11
000073ef1c5d2452  movaps [rsp+0x20], xmm1
000073ef1c5d2457  lea rdi, [rsp]
000073ef1c5d245b  mov esi, 0x00
000073ef1c5d2460  mov rax, 0x56F25E118530
000073ef1c5d246a  call rax
000073ef1c5d246c  movaps xmm13, [rsp]
000073ef1c5d2471  add rsp, 0x30
000073ef1c5d2475  vmovaps xmm0, [rsp]
000073ef1c5d247a  vmovaps xmm1, [rsp+0x10]
000073ef1c5d2480  vmovaps xmm2, [rsp+0x20]
000073ef1c5d2486  vmovaps xmm3, [rsp+0x30]
000073ef1c5d248c  vmovaps xmm4, [rsp+0x40]
000073ef1c5d2492  vmovaps xmm5, [rsp+0x50]
000073ef1c5d2498  vmovaps xmm6, [rsp+0x60]
000073ef1c5d249e  vmovaps xmm7, [rsp+0x70]
000073ef1c5d24a4  vmovaps xmm8, [rsp+0x80]
000073ef1c5d24ad  vmovaps xmm9, [rsp+0x90]
000073ef1c5d24b6  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d24bf  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d24c8  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d24d1  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d24da  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d24e3  add rsp, 0xF0
000073ef1c5d24ea  pop r11
000073ef1c5d24ec  pop r10
000073ef1c5d24ee  pop r9
000073ef1c5d24f0  pop r8
000073ef1c5d24f2  pop rsi
000073ef1c5d24f3  pop rdi
000073ef1c5d24f4  pop rdx
000073ef1c5d24f5  pop rcx
000073ef1c5d24f6  pop rax
000073ef1c5d24f7  add rsp, 0x08
000073ef1c5d24fb  jmp 0x000073EF1C5CFC76
000073ef1c5d2500  call 0x000073EF1C3FF430
000073ef1c5d2505  jmp 0x000073EF1C5CFC83
000073ef1c5d250a  sub rsp, 0x08
000073ef1c5d250e  push rax
000073ef1c5d250f  push rcx
000073ef1c5d2510  push rdx
000073ef1c5d2511  push rdi
000073ef1c5d2512  push rsi
000073ef1c5d2513  push r8
000073ef1c5d2515  push r9
000073ef1c5d2517  push r10
000073ef1c5d2519  push r11
000073ef1c5d251b  sub rsp, 0xF0
000073ef1c5d2522  vmovaps [rsp], xmm0
000073ef1c5d2527  vmovaps [rsp+0x10], xmm1
000073ef1c5d252d  vmovaps [rsp+0x20], xmm2
000073ef1c5d2533  vmovaps [rsp+0x30], xmm3
000073ef1c5d2539  vmovaps [rsp+0x40], xmm4
000073ef1c5d253f  vmovaps [rsp+0x50], xmm5
000073ef1c5d2545  vmovaps [rsp+0x60], xmm6
000073ef1c5d254b  vmovaps [rsp+0x70], xmm7
000073ef1c5d2551  vmovaps [rsp+0x80], xmm8
000073ef1c5d255a  vmovaps [rsp+0x90], xmm9
000073ef1c5d2563  vmovaps [rsp+0xA0], xmm10
000073ef1c5d256c  vmovaps [rsp+0xB0], xmm11
000073ef1c5d2575  vmovaps [rsp+0xC0], xmm12
000073ef1c5d257e  vmovaps [rsp+0xD0], xmm13
000073ef1c5d2587  vmovaps [rsp+0xE0], xmm14
000073ef1c5d2590  sub rsp, 0x30
000073ef1c5d2594  movaps [rsp], xmm15
000073ef1c5d2599  movaps [rsp+0x10], xmm11
000073ef1c5d259f  movaps [rsp+0x20], xmm1
000073ef1c5d25a4  lea rdi, [rsp]
000073ef1c5d25a8  mov esi, 0x00
000073ef1c5d25ad  mov rax, 0x56F25E118530
000073ef1c5d25b7  call rax
000073ef1c5d25b9  movaps xmm15, [rsp]
000073ef1c5d25be  add rsp, 0x30
000073ef1c5d25c2  vmovaps xmm0, [rsp]
000073ef1c5d25c7  vmovaps xmm1, [rsp+0x10]
000073ef1c5d25cd  vmovaps xmm2, [rsp+0x20]
000073ef1c5d25d3  vmovaps xmm3, [rsp+0x30]
000073ef1c5d25d9  vmovaps xmm4, [rsp+0x40]
000073ef1c5d25df  vmovaps xmm5, [rsp+0x50]
000073ef1c5d25e5  vmovaps xmm6, [rsp+0x60]
000073ef1c5d25eb  vmovaps xmm7, [rsp+0x70]
000073ef1c5d25f1  vmovaps xmm8, [rsp+0x80]
000073ef1c5d25fa  vmovaps xmm9, [rsp+0x90]
000073ef1c5d2603  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d260c  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d2615  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d261e  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d2627  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d2630  add rsp, 0xF0
000073ef1c5d2637  pop r11
000073ef1c5d2639  pop r10
000073ef1c5d263b  pop r9
000073ef1c5d263d  pop r8
000073ef1c5d263f  pop rsi
000073ef1c5d2640  pop rdi
000073ef1c5d2641  pop rdx
000073ef1c5d2642  pop rcx
000073ef1c5d2643  pop rax
000073ef1c5d2644  add rsp, 0x08
000073ef1c5d2648  jmp 0x000073EF1C5CFCBC
000073ef1c5d264d  sub rsp, 0x08
000073ef1c5d2651  push rax
000073ef1c5d2652  push rcx
000073ef1c5d2653  push rdx
000073ef1c5d2654  push rdi
000073ef1c5d2655  push rsi
000073ef1c5d2656  push r8
000073ef1c5d2658  push r9
000073ef1c5d265a  push r10
000073ef1c5d265c  push r11
000073ef1c5d265e  sub rsp, 0xF0
000073ef1c5d2665  vmovaps [rsp], xmm0
000073ef1c5d266a  vmovaps [rsp+0x10], xmm1
000073ef1c5d2670  vmovaps [rsp+0x20], xmm2
000073ef1c5d2676  vmovaps [rsp+0x30], xmm3
000073ef1c5d267c  vmovaps [rsp+0x40], xmm4
000073ef1c5d2682  vmovaps [rsp+0x50], xmm5
000073ef1c5d2688  vmovaps [rsp+0x60], xmm6
000073ef1c5d268e  vmovaps [rsp+0x70], xmm7
000073ef1c5d2694  vmovaps [rsp+0x80], xmm8
000073ef1c5d269d  vmovaps [rsp+0x90], xmm9
000073ef1c5d26a6  vmovaps [rsp+0xA0], xmm10
000073ef1c5d26af  vmovaps [rsp+0xB0], xmm12
000073ef1c5d26b8  vmovaps [rsp+0xC0], xmm13
000073ef1c5d26c1  vmovaps [rsp+0xD0], xmm14
000073ef1c5d26ca  vmovaps [rsp+0xE0], xmm15
000073ef1c5d26d3  sub rsp, 0x30
000073ef1c5d26d7  movaps [rsp], xmm11
000073ef1c5d26dc  movaps [rsp+0x10], xmm6
000073ef1c5d26e1  movaps [rsp+0x20], xmm14
000073ef1c5d26e7  lea rdi, [rsp]
000073ef1c5d26eb  mov esi, 0x00
000073ef1c5d26f0  mov rax, 0x56F25E118530
000073ef1c5d26fa  call rax
000073ef1c5d26fc  movaps xmm11, [rsp]
000073ef1c5d2701  add rsp, 0x30
000073ef1c5d2705  vmovaps xmm0, [rsp]
000073ef1c5d270a  vmovaps xmm1, [rsp+0x10]
000073ef1c5d2710  vmovaps xmm2, [rsp+0x20]
000073ef1c5d2716  vmovaps xmm3, [rsp+0x30]
000073ef1c5d271c  vmovaps xmm4, [rsp+0x40]
000073ef1c5d2722  vmovaps xmm5, [rsp+0x50]
000073ef1c5d2728  vmovaps xmm6, [rsp+0x60]
000073ef1c5d272e  vmovaps xmm7, [rsp+0x70]
000073ef1c5d2734  vmovaps xmm8, [rsp+0x80]
000073ef1c5d273d  vmovaps xmm9, [rsp+0x90]
000073ef1c5d2746  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d274f  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d2758  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d2761  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d276a  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d2773  add rsp, 0xF0
000073ef1c5d277a  pop r11
000073ef1c5d277c  pop r10
000073ef1c5d277e  pop r9
000073ef1c5d2780  pop r8
000073ef1c5d2782  pop rsi
000073ef1c5d2783  pop rdi
000073ef1c5d2784  pop rdx
000073ef1c5d2785  pop rcx
000073ef1c5d2786  pop rax
000073ef1c5d2787  add rsp, 0x08
000073ef1c5d278b  jmp 0x000073EF1C5CFD34
000073ef1c5d2790  call 0x000073EF1C3FF430
000073ef1c5d2795  jmp 0x000073EF1C5CFD3E
000073ef1c5d279a  sub rsp, 0x08
000073ef1c5d279e  push rax
000073ef1c5d279f  push rcx
000073ef1c5d27a0  push rdx
000073ef1c5d27a1  push rdi
000073ef1c5d27a2  push rsi
000073ef1c5d27a3  push r8
000073ef1c5d27a5  push r9
000073ef1c5d27a7  push r10
000073ef1c5d27a9  push r11
000073ef1c5d27ab  sub rsp, 0xF0
000073ef1c5d27b2  vmovaps [rsp], xmm0
000073ef1c5d27b7  vmovaps [rsp+0x10], xmm1
000073ef1c5d27bd  vmovaps [rsp+0x20], xmm2
000073ef1c5d27c3  vmovaps [rsp+0x30], xmm3
000073ef1c5d27c9  vmovaps [rsp+0x40], xmm4
000073ef1c5d27cf  vmovaps [rsp+0x50], xmm5
000073ef1c5d27d5  vmovaps [rsp+0x60], xmm6
000073ef1c5d27db  vmovaps [rsp+0x70], xmm7
000073ef1c5d27e1  vmovaps [rsp+0x80], xmm8
000073ef1c5d27ea  vmovaps [rsp+0x90], xmm9
000073ef1c5d27f3  vmovaps [rsp+0xA0], xmm10
000073ef1c5d27fc  vmovaps [rsp+0xB0], xmm11
000073ef1c5d2805  vmovaps [rsp+0xC0], xmm12
000073ef1c5d280e  vmovaps [rsp+0xD0], xmm13
000073ef1c5d2817  vmovaps [rsp+0xE0], xmm15
000073ef1c5d2820  sub rsp, 0x30
000073ef1c5d2824  movaps [rsp], xmm14
000073ef1c5d2829  movaps [rsp+0x10], xmm6
000073ef1c5d282e  movaps [rsp+0x20], xmm2
000073ef1c5d2833  lea rdi, [rsp]
000073ef1c5d2837  mov esi, 0x00
000073ef1c5d283c  mov rax, 0x56F25E118530
000073ef1c5d2846  call rax
000073ef1c5d2848  movaps xmm14, [rsp]
000073ef1c5d284d  add rsp, 0x30
000073ef1c5d2851  vmovaps xmm0, [rsp]
000073ef1c5d2856  vmovaps xmm1, [rsp+0x10]
000073ef1c5d285c  vmovaps xmm2, [rsp+0x20]
000073ef1c5d2862  vmovaps xmm3, [rsp+0x30]
000073ef1c5d2868  vmovaps xmm4, [rsp+0x40]
000073ef1c5d286e  vmovaps xmm5, [rsp+0x50]
000073ef1c5d2874  vmovaps xmm6, [rsp+0x60]
000073ef1c5d287a  vmovaps xmm7, [rsp+0x70]
000073ef1c5d2880  vmovaps xmm8, [rsp+0x80]
000073ef1c5d2889  vmovaps xmm9, [rsp+0x90]
000073ef1c5d2892  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d289b  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d28a4  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d28ad  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d28b6  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d28bf  add rsp, 0xF0
000073ef1c5d28c6  pop r11
000073ef1c5d28c8  pop r10
000073ef1c5d28ca  pop r9
000073ef1c5d28cc  pop r8
000073ef1c5d28ce  pop rsi
000073ef1c5d28cf  pop rdi
000073ef1c5d28d0  pop rdx
000073ef1c5d28d1  pop rcx
000073ef1c5d28d2  pop rax
000073ef1c5d28d3  add rsp, 0x08
000073ef1c5d28d7  jmp 0x000073EF1C5CFD72
000073ef1c5d28dc  sub rsp, 0x08
000073ef1c5d28e0  push rax
000073ef1c5d28e1  push rcx
000073ef1c5d28e2  push rdx
000073ef1c5d28e3  push rdi
000073ef1c5d28e4  push rsi
000073ef1c5d28e5  push r8
000073ef1c5d28e7  push r9
000073ef1c5d28e9  push r10
000073ef1c5d28eb  push r11
000073ef1c5d28ed  sub rsp, 0xF0
000073ef1c5d28f4  vmovaps [rsp], xmm0
000073ef1c5d28f9  vmovaps [rsp+0x10], xmm1
000073ef1c5d28ff  vmovaps [rsp+0x20], xmm2
000073ef1c5d2905  vmovaps [rsp+0x30], xmm3
000073ef1c5d290b  vmovaps [rsp+0x40], xmm4
000073ef1c5d2911  vmovaps [rsp+0x50], xmm5
000073ef1c5d2917  vmovaps [rsp+0x60], xmm7
000073ef1c5d291d  vmovaps [rsp+0x70], xmm8
000073ef1c5d2923  vmovaps [rsp+0x80], xmm9
000073ef1c5d292c  vmovaps [rsp+0x90], xmm10
000073ef1c5d2935  vmovaps [rsp+0xA0], xmm11
000073ef1c5d293e  vmovaps [rsp+0xB0], xmm12
000073ef1c5d2947  vmovaps [rsp+0xC0], xmm13
000073ef1c5d2950  vmovaps [rsp+0xD0], xmm14
000073ef1c5d2959  vmovaps [rsp+0xE0], xmm15
000073ef1c5d2962  sub rsp, 0x30
000073ef1c5d2966  movaps [rsp], xmm6
000073ef1c5d296a  movaps [rsp+0x10], xmm5
000073ef1c5d296f  movaps [rsp+0x20], xmm1
000073ef1c5d2974  lea rdi, [rsp]
000073ef1c5d2978  mov esi, 0x00
000073ef1c5d297d  mov rax, 0x56F25E118530
000073ef1c5d2987  call rax
000073ef1c5d2989  movaps xmm6, [rsp]
000073ef1c5d298d  add rsp, 0x30
000073ef1c5d2991  vmovaps xmm0, [rsp]
000073ef1c5d2996  vmovaps xmm1, [rsp+0x10]
000073ef1c5d299c  vmovaps xmm2, [rsp+0x20]
000073ef1c5d29a2  vmovaps xmm3, [rsp+0x30]
000073ef1c5d29a8  vmovaps xmm4, [rsp+0x40]
000073ef1c5d29ae  vmovaps xmm5, [rsp+0x50]
000073ef1c5d29b4  vmovaps xmm7, [rsp+0x60]
000073ef1c5d29ba  vmovaps xmm8, [rsp+0x70]
000073ef1c5d29c0  vmovaps xmm9, [rsp+0x80]
000073ef1c5d29c9  vmovaps xmm10, [rsp+0x90]
000073ef1c5d29d2  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d29db  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d29e4  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d29ed  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d29f6  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d29ff  add rsp, 0xF0
000073ef1c5d2a06  pop r11
000073ef1c5d2a08  pop r10
000073ef1c5d2a0a  pop r9
000073ef1c5d2a0c  pop r8
000073ef1c5d2a0e  pop rsi
000073ef1c5d2a0f  pop rdi
000073ef1c5d2a10  pop rdx
000073ef1c5d2a11  pop rcx
000073ef1c5d2a12  pop rax
000073ef1c5d2a13  add rsp, 0x08
000073ef1c5d2a17  jmp 0x000073EF1C5CFD98
000073ef1c5d2a1c  sub rsp, 0x08
000073ef1c5d2a20  push rax
000073ef1c5d2a21  push rcx
000073ef1c5d2a22  push rdx
000073ef1c5d2a23  push rdi
000073ef1c5d2a24  push rsi
000073ef1c5d2a25  push r8
000073ef1c5d2a27  push r9
000073ef1c5d2a29  push r10
000073ef1c5d2a2b  push r11
000073ef1c5d2a2d  sub rsp, 0xF0
000073ef1c5d2a34  vmovaps [rsp], xmm0
000073ef1c5d2a39  vmovaps [rsp+0x10], xmm2
000073ef1c5d2a3f  vmovaps [rsp+0x20], xmm3
000073ef1c5d2a45  vmovaps [rsp+0x30], xmm4
000073ef1c5d2a4b  vmovaps [rsp+0x40], xmm5
000073ef1c5d2a51  vmovaps [rsp+0x50], xmm6
000073ef1c5d2a57  vmovaps [rsp+0x60], xmm7
000073ef1c5d2a5d  vmovaps [rsp+0x70], xmm8
000073ef1c5d2a63  vmovaps [rsp+0x80], xmm9
000073ef1c5d2a6c  vmovaps [rsp+0x90], xmm10
000073ef1c5d2a75  vmovaps [rsp+0xA0], xmm11
000073ef1c5d2a7e  vmovaps [rsp+0xB0], xmm12
000073ef1c5d2a87  vmovaps [rsp+0xC0], xmm13
000073ef1c5d2a90  vmovaps [rsp+0xD0], xmm14
000073ef1c5d2a99  vmovaps [rsp+0xE0], xmm15
000073ef1c5d2aa2  sub rsp, 0x30
000073ef1c5d2aa6  movaps [rsp], xmm1
000073ef1c5d2aaa  movaps [rsp+0x10], xmm5
000073ef1c5d2aaf  movaps [rsp+0x20], xmm13
000073ef1c5d2ab5  lea rdi, [rsp]
000073ef1c5d2ab9  mov esi, 0x00
000073ef1c5d2abe  mov rax, 0x56F25E118530
000073ef1c5d2ac8  call rax
000073ef1c5d2aca  movaps xmm1, [rsp]
000073ef1c5d2ace  add rsp, 0x30
000073ef1c5d2ad2  vmovaps xmm0, [rsp]
000073ef1c5d2ad7  vmovaps xmm2, [rsp+0x10]
000073ef1c5d2add  vmovaps xmm3, [rsp+0x20]
000073ef1c5d2ae3  vmovaps xmm4, [rsp+0x30]
000073ef1c5d2ae9  vmovaps xmm5, [rsp+0x40]
000073ef1c5d2aef  vmovaps xmm6, [rsp+0x50]
000073ef1c5d2af5  vmovaps xmm7, [rsp+0x60]
000073ef1c5d2afb  vmovaps xmm8, [rsp+0x70]
000073ef1c5d2b01  vmovaps xmm9, [rsp+0x80]
000073ef1c5d2b0a  vmovaps xmm10, [rsp+0x90]
000073ef1c5d2b13  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d2b1c  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d2b25  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d2b2e  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d2b37  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d2b40  add rsp, 0xF0
000073ef1c5d2b47  pop r11
000073ef1c5d2b49  pop r10
000073ef1c5d2b4b  pop r9
000073ef1c5d2b4d  pop r8
000073ef1c5d2b4f  pop rsi
000073ef1c5d2b50  pop rdi
000073ef1c5d2b51  pop rdx
000073ef1c5d2b52  pop rcx
000073ef1c5d2b53  pop rax
000073ef1c5d2b54  add rsp, 0x08
000073ef1c5d2b58  jmp 0x000073EF1C5CFDB6
000073ef1c5d2b5d  sub rsp, 0x08
000073ef1c5d2b61  push rax
000073ef1c5d2b62  push rcx
000073ef1c5d2b63  push rdx
000073ef1c5d2b64  push rdi
000073ef1c5d2b65  push rsi
000073ef1c5d2b66  push r8
000073ef1c5d2b68  push r9
000073ef1c5d2b6a  push r10
000073ef1c5d2b6c  push r11
000073ef1c5d2b6e  sub rsp, 0xF0
000073ef1c5d2b75  vmovaps [rsp], xmm0
000073ef1c5d2b7a  vmovaps [rsp+0x10], xmm1
000073ef1c5d2b80  vmovaps [rsp+0x20], xmm2
000073ef1c5d2b86  vmovaps [rsp+0x30], xmm3
000073ef1c5d2b8c  vmovaps [rsp+0x40], xmm4
000073ef1c5d2b92  vmovaps [rsp+0x50], xmm6
000073ef1c5d2b98  vmovaps [rsp+0x60], xmm7
000073ef1c5d2b9e  vmovaps [rsp+0x70], xmm8
000073ef1c5d2ba4  vmovaps [rsp+0x80], xmm9
000073ef1c5d2bad  vmovaps [rsp+0x90], xmm10
000073ef1c5d2bb6  vmovaps [rsp+0xA0], xmm11
000073ef1c5d2bbf  vmovaps [rsp+0xB0], xmm12
000073ef1c5d2bc8  vmovaps [rsp+0xC0], xmm13
000073ef1c5d2bd1  vmovaps [rsp+0xD0], xmm14
000073ef1c5d2bda  vmovaps [rsp+0xE0], xmm15
000073ef1c5d2be3  sub rsp, 0x30
000073ef1c5d2be7  movaps [rsp], xmm5
000073ef1c5d2beb  movaps [rsp+0x10], xmm2
000073ef1c5d2bf0  movaps [rsp+0x20], xmm13
000073ef1c5d2bf6  lea rdi, [rsp]
000073ef1c5d2bfa  mov esi, 0x00
000073ef1c5d2bff  mov rax, 0x56F25E118530
000073ef1c5d2c09  call rax
000073ef1c5d2c0b  movaps xmm5, [rsp]
000073ef1c5d2c0f  add rsp, 0x30
000073ef1c5d2c13  vmovaps xmm0, [rsp]
000073ef1c5d2c18  vmovaps xmm1, [rsp+0x10]
000073ef1c5d2c1e  vmovaps xmm2, [rsp+0x20]
000073ef1c5d2c24  vmovaps xmm3, [rsp+0x30]
000073ef1c5d2c2a  vmovaps xmm4, [rsp+0x40]
000073ef1c5d2c30  vmovaps xmm6, [rsp+0x50]
000073ef1c5d2c36  vmovaps xmm7, [rsp+0x60]
000073ef1c5d2c3c  vmovaps xmm8, [rsp+0x70]
000073ef1c5d2c42  vmovaps xmm9, [rsp+0x80]
000073ef1c5d2c4b  vmovaps xmm10, [rsp+0x90]
000073ef1c5d2c54  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d2c5d  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d2c66  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d2c6f  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d2c78  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d2c81  add rsp, 0xF0
000073ef1c5d2c88  pop r11
000073ef1c5d2c8a  pop r10
000073ef1c5d2c8c  pop r9
000073ef1c5d2c8e  pop r8
000073ef1c5d2c90  pop rsi
000073ef1c5d2c91  pop rdi
000073ef1c5d2c92  pop rdx
000073ef1c5d2c93  pop rcx
000073ef1c5d2c94  pop rax
000073ef1c5d2c95  add rsp, 0x08
000073ef1c5d2c99  jmp 0x000073EF1C5CFDEC
000073ef1c5d2c9e  sub rsp, 0x08
000073ef1c5d2ca2  push rax
000073ef1c5d2ca3  push rcx
000073ef1c5d2ca4  push rdx
000073ef1c5d2ca5  push rdi
000073ef1c5d2ca6  push rsi
000073ef1c5d2ca7  push r8
000073ef1c5d2ca9  push r9
000073ef1c5d2cab  push r10
000073ef1c5d2cad  push r11
000073ef1c5d2caf  sub rsp, 0xF0
000073ef1c5d2cb6  vmovaps [rsp], xmm0
000073ef1c5d2cbb  vmovaps [rsp+0x10], xmm1
000073ef1c5d2cc1  vmovaps [rsp+0x20], xmm2
000073ef1c5d2cc7  vmovaps [rsp+0x30], xmm3
000073ef1c5d2ccd  vmovaps [rsp+0x40], xmm4
000073ef1c5d2cd3  vmovaps [rsp+0x50], xmm5
000073ef1c5d2cd9  vmovaps [rsp+0x60], xmm6
000073ef1c5d2cdf  vmovaps [rsp+0x70], xmm7
000073ef1c5d2ce5  vmovaps [rsp+0x80], xmm8
000073ef1c5d2cee  vmovaps [rsp+0x90], xmm9
000073ef1c5d2cf7  vmovaps [rsp+0xA0], xmm10
000073ef1c5d2d00  vmovaps [rsp+0xB0], xmm11
000073ef1c5d2d09  vmovaps [rsp+0xC0], xmm12
000073ef1c5d2d12  vmovaps [rsp+0xD0], xmm14
000073ef1c5d2d1b  vmovaps [rsp+0xE0], xmm15
000073ef1c5d2d24  sub rsp, 0x30
000073ef1c5d2d28  movaps [rsp], xmm13
000073ef1c5d2d2d  movaps [rsp+0x10], xmm10
000073ef1c5d2d33  movaps [rsp+0x20], xmm1
000073ef1c5d2d38  lea rdi, [rsp]
000073ef1c5d2d3c  mov esi, 0x00
000073ef1c5d2d41  mov rax, 0x56F25E118530
000073ef1c5d2d4b  call rax
000073ef1c5d2d4d  movaps xmm13, [rsp]
000073ef1c5d2d52  add rsp, 0x30
000073ef1c5d2d56  vmovaps xmm0, [rsp]
000073ef1c5d2d5b  vmovaps xmm1, [rsp+0x10]
000073ef1c5d2d61  vmovaps xmm2, [rsp+0x20]
000073ef1c5d2d67  vmovaps xmm3, [rsp+0x30]
000073ef1c5d2d6d  vmovaps xmm4, [rsp+0x40]
000073ef1c5d2d73  vmovaps xmm5, [rsp+0x50]
000073ef1c5d2d79  vmovaps xmm6, [rsp+0x60]
000073ef1c5d2d7f  vmovaps xmm7, [rsp+0x70]
000073ef1c5d2d85  vmovaps xmm8, [rsp+0x80]
000073ef1c5d2d8e  vmovaps xmm9, [rsp+0x90]
000073ef1c5d2d97  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d2da0  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d2da9  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d2db2  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d2dbb  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d2dc4  add rsp, 0xF0
000073ef1c5d2dcb  pop r11
000073ef1c5d2dcd  pop r10
000073ef1c5d2dcf  pop r9
000073ef1c5d2dd1  pop r8
000073ef1c5d2dd3  pop rsi
000073ef1c5d2dd4  pop rdi
000073ef1c5d2dd5  pop rdx
000073ef1c5d2dd6  pop rcx
000073ef1c5d2dd7  pop rax
000073ef1c5d2dd8  add rsp, 0x08
000073ef1c5d2ddc  jmp 0x000073EF1C5CFE15
000073ef1c5d2de1  sub rsp, 0x08
000073ef1c5d2de5  push rax
000073ef1c5d2de6  push rcx
000073ef1c5d2de7  push rdx
000073ef1c5d2de8  push rdi
000073ef1c5d2de9  push rsi
000073ef1c5d2dea  push r8
000073ef1c5d2dec  push r9
000073ef1c5d2dee  push r10
000073ef1c5d2df0  push r11
000073ef1c5d2df2  sub rsp, 0xF0
000073ef1c5d2df9  vmovaps [rsp], xmm0
000073ef1c5d2dfe  vmovaps [rsp+0x10], xmm2
000073ef1c5d2e04  vmovaps [rsp+0x20], xmm3
000073ef1c5d2e0a  vmovaps [rsp+0x30], xmm4
000073ef1c5d2e10  vmovaps [rsp+0x40], xmm5
000073ef1c5d2e16  vmovaps [rsp+0x50], xmm6
000073ef1c5d2e1c  vmovaps [rsp+0x60], xmm7
000073ef1c5d2e22  vmovaps [rsp+0x70], xmm8
000073ef1c5d2e28  vmovaps [rsp+0x80], xmm9
000073ef1c5d2e31  vmovaps [rsp+0x90], xmm10
000073ef1c5d2e3a  vmovaps [rsp+0xA0], xmm11
000073ef1c5d2e43  vmovaps [rsp+0xB0], xmm12
000073ef1c5d2e4c  vmovaps [rsp+0xC0], xmm13
000073ef1c5d2e55  vmovaps [rsp+0xD0], xmm14
000073ef1c5d2e5e  vmovaps [rsp+0xE0], xmm15
000073ef1c5d2e67  sub rsp, 0x30
000073ef1c5d2e6b  movaps [rsp], xmm1
000073ef1c5d2e6f  movaps [rsp+0x10], xmm15
000073ef1c5d2e75  movaps [rsp+0x20], xmm10
000073ef1c5d2e7b  lea rdi, [rsp]
000073ef1c5d2e7f  mov esi, 0x00
000073ef1c5d2e84  mov rax, 0x56F25E118530
000073ef1c5d2e8e  call rax
000073ef1c5d2e90  movaps xmm1, [rsp]
000073ef1c5d2e94  add rsp, 0x30
000073ef1c5d2e98  vmovaps xmm0, [rsp]
000073ef1c5d2e9d  vmovaps xmm2, [rsp+0x10]
000073ef1c5d2ea3  vmovaps xmm3, [rsp+0x20]
000073ef1c5d2ea9  vmovaps xmm4, [rsp+0x30]
000073ef1c5d2eaf  vmovaps xmm5, [rsp+0x40]
000073ef1c5d2eb5  vmovaps xmm6, [rsp+0x50]
000073ef1c5d2ebb  vmovaps xmm7, [rsp+0x60]
000073ef1c5d2ec1  vmovaps xmm8, [rsp+0x70]
000073ef1c5d2ec7  vmovaps xmm9, [rsp+0x80]
000073ef1c5d2ed0  vmovaps xmm10, [rsp+0x90]
000073ef1c5d2ed9  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d2ee2  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d2eeb  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d2ef4  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d2efd  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d2f06  add rsp, 0xF0
000073ef1c5d2f0d  pop r11
000073ef1c5d2f0f  pop r10
000073ef1c5d2f11  pop r9
000073ef1c5d2f13  pop r8
000073ef1c5d2f15  pop rsi
000073ef1c5d2f16  pop rdi
000073ef1c5d2f17  pop rdx
000073ef1c5d2f18  pop rcx
000073ef1c5d2f19  pop rax
000073ef1c5d2f1a  add rsp, 0x08
000073ef1c5d2f1e  jmp 0x000073EF1C5CFE34
000073ef1c5d2f23  sub rsp, 0x08
000073ef1c5d2f27  push rax
000073ef1c5d2f28  push rcx
000073ef1c5d2f29  push rdx
000073ef1c5d2f2a  push rdi
000073ef1c5d2f2b  push rsi
000073ef1c5d2f2c  push r8
000073ef1c5d2f2e  push r9
000073ef1c5d2f30  push r10
000073ef1c5d2f32  push r11
000073ef1c5d2f34  sub rsp, 0xF0
000073ef1c5d2f3b  vmovaps [rsp], xmm0
000073ef1c5d2f40  vmovaps [rsp+0x10], xmm1
000073ef1c5d2f46  vmovaps [rsp+0x20], xmm2
000073ef1c5d2f4c  vmovaps [rsp+0x30], xmm3
000073ef1c5d2f52  vmovaps [rsp+0x40], xmm4
000073ef1c5d2f58  vmovaps [rsp+0x50], xmm5
000073ef1c5d2f5e  vmovaps [rsp+0x60], xmm6
000073ef1c5d2f64  vmovaps [rsp+0x70], xmm7
000073ef1c5d2f6a  vmovaps [rsp+0x80], xmm8
000073ef1c5d2f73  vmovaps [rsp+0x90], xmm9
000073ef1c5d2f7c  vmovaps [rsp+0xA0], xmm10
000073ef1c5d2f85  vmovaps [rsp+0xB0], xmm11
000073ef1c5d2f8e  vmovaps [rsp+0xC0], xmm12
000073ef1c5d2f97  vmovaps [rsp+0xD0], xmm13
000073ef1c5d2fa0  vmovaps [rsp+0xE0], xmm14
000073ef1c5d2fa9  sub rsp, 0x30
000073ef1c5d2fad  movaps [rsp], xmm15
000073ef1c5d2fb2  movaps [rsp+0x10], xmm10
000073ef1c5d2fb8  movaps [rsp+0x20], xmm11
000073ef1c5d2fbe  lea rdi, [rsp]
000073ef1c5d2fc2  mov esi, 0x00
000073ef1c5d2fc7  mov rax, 0x56F25E118530
000073ef1c5d2fd1  call rax
000073ef1c5d2fd3  movaps xmm15, [rsp]
000073ef1c5d2fd8  add rsp, 0x30
000073ef1c5d2fdc  vmovaps xmm0, [rsp]
000073ef1c5d2fe1  vmovaps xmm1, [rsp+0x10]
000073ef1c5d2fe7  vmovaps xmm2, [rsp+0x20]
000073ef1c5d2fed  vmovaps xmm3, [rsp+0x30]
000073ef1c5d2ff3  vmovaps xmm4, [rsp+0x40]
000073ef1c5d2ff9  vmovaps xmm5, [rsp+0x50]
000073ef1c5d2fff  vmovaps xmm6, [rsp+0x60]
000073ef1c5d3005  vmovaps xmm7, [rsp+0x70]
000073ef1c5d300b  vmovaps xmm8, [rsp+0x80]
000073ef1c5d3014  vmovaps xmm9, [rsp+0x90]
000073ef1c5d301d  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d3026  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d302f  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d3038  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d3041  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d304a  add rsp, 0xF0
000073ef1c5d3051  pop r11
000073ef1c5d3053  pop r10
000073ef1c5d3055  pop r9
000073ef1c5d3057  pop r8
000073ef1c5d3059  pop rsi
000073ef1c5d305a  pop rdi
000073ef1c5d305b  pop rdx
000073ef1c5d305c  pop rcx
000073ef1c5d305d  pop rax
000073ef1c5d305e  add rsp, 0x08
000073ef1c5d3062  jmp 0x000073EF1C5CFE57
000073ef1c5d3067  sub rsp, 0x08
000073ef1c5d306b  push rax
000073ef1c5d306c  push rcx
000073ef1c5d306d  push rdx
000073ef1c5d306e  push rdi
000073ef1c5d306f  push rsi
000073ef1c5d3070  push r8
000073ef1c5d3072  push r9
000073ef1c5d3074  push r10
000073ef1c5d3076  push r11
000073ef1c5d3078  sub rsp, 0xF0
000073ef1c5d307f  vmovaps [rsp], xmm0
000073ef1c5d3084  vmovaps [rsp+0x10], xmm1
000073ef1c5d308a  vmovaps [rsp+0x20], xmm2
000073ef1c5d3090  vmovaps [rsp+0x30], xmm3
000073ef1c5d3096  vmovaps [rsp+0x40], xmm4
000073ef1c5d309c  vmovaps [rsp+0x50], xmm5
000073ef1c5d30a2  vmovaps [rsp+0x60], xmm6
000073ef1c5d30a8  vmovaps [rsp+0x70], xmm7
000073ef1c5d30ae  vmovaps [rsp+0x80], xmm8
000073ef1c5d30b7  vmovaps [rsp+0x90], xmm9
000073ef1c5d30c0  vmovaps [rsp+0xA0], xmm11
000073ef1c5d30c9  vmovaps [rsp+0xB0], xmm12
000073ef1c5d30d2  vmovaps [rsp+0xC0], xmm13
000073ef1c5d30db  vmovaps [rsp+0xD0], xmm14
000073ef1c5d30e4  vmovaps [rsp+0xE0], xmm15
000073ef1c5d30ed  sub rsp, 0x30
000073ef1c5d30f1  movaps [rsp], xmm10
000073ef1c5d30f6  movaps [rsp+0x10], xmm12
000073ef1c5d30fc  movaps [rsp+0x20], xmm11
000073ef1c5d3102  lea rdi, [rsp]
000073ef1c5d3106  mov esi, 0x00
000073ef1c5d310b  mov rax, 0x56F25E118530
000073ef1c5d3115  call rax
000073ef1c5d3117  movaps xmm10, [rsp]
000073ef1c5d311c  add rsp, 0x30
000073ef1c5d3120  vmovaps xmm0, [rsp]
000073ef1c5d3125  vmovaps xmm1, [rsp+0x10]
000073ef1c5d312b  vmovaps xmm2, [rsp+0x20]
000073ef1c5d3131  vmovaps xmm3, [rsp+0x30]
000073ef1c5d3137  vmovaps xmm4, [rsp+0x40]
000073ef1c5d313d  vmovaps xmm5, [rsp+0x50]
000073ef1c5d3143  vmovaps xmm6, [rsp+0x60]
000073ef1c5d3149  vmovaps xmm7, [rsp+0x70]
000073ef1c5d314f  vmovaps xmm8, [rsp+0x80]
000073ef1c5d3158  vmovaps xmm9, [rsp+0x90]
000073ef1c5d3161  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d316a  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d3173  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d317c  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d3185  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d318e  add rsp, 0xF0
000073ef1c5d3195  pop r11
000073ef1c5d3197  pop r10
000073ef1c5d3199  pop r9
000073ef1c5d319b  pop r8
000073ef1c5d319d  pop rsi
000073ef1c5d319e  pop rdi
000073ef1c5d319f  pop rdx
000073ef1c5d31a0  pop rcx
000073ef1c5d31a1  pop rax
000073ef1c5d31a2  add rsp, 0x08
000073ef1c5d31a6  jmp 0x000073EF1C5CFE80
000073ef1c5d31ab  sub rsp, 0x08
000073ef1c5d31af  push rax
000073ef1c5d31b0  push rcx
000073ef1c5d31b1  push rdx
000073ef1c5d31b2  push rdi
000073ef1c5d31b3  push rsi
000073ef1c5d31b4  push r8
000073ef1c5d31b6  push r9
000073ef1c5d31b8  push r10
000073ef1c5d31ba  push r11
000073ef1c5d31bc  sub rsp, 0xF0
000073ef1c5d31c3  vmovaps [rsp], xmm0
000073ef1c5d31c8  vmovaps [rsp+0x10], xmm1
000073ef1c5d31ce  vmovaps [rsp+0x20], xmm2
000073ef1c5d31d4  vmovaps [rsp+0x30], xmm3
000073ef1c5d31da  vmovaps [rsp+0x40], xmm4
000073ef1c5d31e0  vmovaps [rsp+0x50], xmm5
000073ef1c5d31e6  vmovaps [rsp+0x60], xmm6
000073ef1c5d31ec  vmovaps [rsp+0x70], xmm7
000073ef1c5d31f2  vmovaps [rsp+0x80], xmm8
000073ef1c5d31fb  vmovaps [rsp+0x90], xmm9
000073ef1c5d3204  vmovaps [rsp+0xA0], xmm10
000073ef1c5d320d  vmovaps [rsp+0xB0], xmm12
000073ef1c5d3216  vmovaps [rsp+0xC0], xmm13
000073ef1c5d321f  vmovaps [rsp+0xD0], xmm14
000073ef1c5d3228  vmovaps [rsp+0xE0], xmm15
000073ef1c5d3231  sub rsp, 0x30
000073ef1c5d3235  movaps [rsp], xmm11
000073ef1c5d323a  movaps [rsp+0x10], xmm2
000073ef1c5d323f  movaps [rsp+0x20], xmm12
000073ef1c5d3245  lea rdi, [rsp]
000073ef1c5d3249  mov esi, 0x00
000073ef1c5d324e  mov rax, 0x56F25E118530
000073ef1c5d3258  call rax
000073ef1c5d325a  movaps xmm11, [rsp]
000073ef1c5d325f  add rsp, 0x30
000073ef1c5d3263  vmovaps xmm0, [rsp]
000073ef1c5d3268  vmovaps xmm1, [rsp+0x10]
000073ef1c5d326e  vmovaps xmm2, [rsp+0x20]
000073ef1c5d3274  vmovaps xmm3, [rsp+0x30]
000073ef1c5d327a  vmovaps xmm4, [rsp+0x40]
000073ef1c5d3280  vmovaps xmm5, [rsp+0x50]
000073ef1c5d3286  vmovaps xmm6, [rsp+0x60]
000073ef1c5d328c  vmovaps xmm7, [rsp+0x70]
000073ef1c5d3292  vmovaps xmm8, [rsp+0x80]
000073ef1c5d329b  vmovaps xmm9, [rsp+0x90]
000073ef1c5d32a4  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d32ad  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d32b6  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d32bf  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d32c8  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d32d1  add rsp, 0xF0
000073ef1c5d32d8  pop r11
000073ef1c5d32da  pop r10
000073ef1c5d32dc  pop r9
000073ef1c5d32de  pop r8
000073ef1c5d32e0  pop rsi
000073ef1c5d32e1  pop rdi
000073ef1c5d32e2  pop rdx
000073ef1c5d32e3  pop rcx
000073ef1c5d32e4  pop rax
000073ef1c5d32e5  add rsp, 0x08
000073ef1c5d32e9  jmp 0x000073EF1C5CFEB8
000073ef1c5d32ee  sub rsp, 0x08
000073ef1c5d32f2  push rax
000073ef1c5d32f3  push rcx
000073ef1c5d32f4  push rdx
000073ef1c5d32f5  push rdi
000073ef1c5d32f6  push rsi
000073ef1c5d32f7  push r8
000073ef1c5d32f9  push r9
000073ef1c5d32fb  push r10
000073ef1c5d32fd  push r11
000073ef1c5d32ff  sub rsp, 0xF0
000073ef1c5d3306  vmovaps [rsp], xmm0
000073ef1c5d330b  vmovaps [rsp+0x10], xmm2
000073ef1c5d3311  vmovaps [rsp+0x20], xmm3
000073ef1c5d3317  vmovaps [rsp+0x30], xmm4
000073ef1c5d331d  vmovaps [rsp+0x40], xmm5
000073ef1c5d3323  vmovaps [rsp+0x50], xmm6
000073ef1c5d3329  vmovaps [rsp+0x60], xmm7
000073ef1c5d332f  vmovaps [rsp+0x70], xmm8
000073ef1c5d3335  vmovaps [rsp+0x80], xmm9
000073ef1c5d333e  vmovaps [rsp+0x90], xmm10
000073ef1c5d3347  vmovaps [rsp+0xA0], xmm11
000073ef1c5d3350  vmovaps [rsp+0xB0], xmm12
000073ef1c5d3359  vmovaps [rsp+0xC0], xmm13
000073ef1c5d3362  vmovaps [rsp+0xD0], xmm14
000073ef1c5d336b  vmovaps [rsp+0xE0], xmm15
000073ef1c5d3374  sub rsp, 0x30
000073ef1c5d3378  movaps [rsp], xmm1
000073ef1c5d337c  movaps [rsp+0x10], xmm14
000073ef1c5d3382  movaps [rsp+0x20], xmm6
000073ef1c5d3387  lea rdi, [rsp]
000073ef1c5d338b  mov esi, 0x00
000073ef1c5d3390  mov rax, 0x56F25E118530
000073ef1c5d339a  call rax
000073ef1c5d339c  movaps xmm1, [rsp]
000073ef1c5d33a0  add rsp, 0x30
000073ef1c5d33a4  vmovaps xmm0, [rsp]
000073ef1c5d33a9  vmovaps xmm2, [rsp+0x10]
000073ef1c5d33af  vmovaps xmm3, [rsp+0x20]
000073ef1c5d33b5  vmovaps xmm4, [rsp+0x30]
000073ef1c5d33bb  vmovaps xmm5, [rsp+0x40]
000073ef1c5d33c1  vmovaps xmm6, [rsp+0x50]
000073ef1c5d33c7  vmovaps xmm7, [rsp+0x60]
000073ef1c5d33cd  vmovaps xmm8, [rsp+0x70]
000073ef1c5d33d3  vmovaps xmm9, [rsp+0x80]
000073ef1c5d33dc  vmovaps xmm10, [rsp+0x90]
000073ef1c5d33e5  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d33ee  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d33f7  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d3400  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d3409  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d3412  add rsp, 0xF0
000073ef1c5d3419  pop r11
000073ef1c5d341b  pop r10
000073ef1c5d341d  pop r9
000073ef1c5d341f  pop r8
000073ef1c5d3421  pop rsi
000073ef1c5d3422  pop rdi
000073ef1c5d3423  pop rdx
000073ef1c5d3424  pop rcx
000073ef1c5d3425  pop rax
000073ef1c5d3426  add rsp, 0x08
000073ef1c5d342a  jmp 0x000073EF1C5CFED1
000073ef1c5d342f  sub rsp, 0x08
000073ef1c5d3433  push rax
000073ef1c5d3434  push rcx
000073ef1c5d3435  push rdx
000073ef1c5d3436  push rdi
000073ef1c5d3437  push rsi
000073ef1c5d3438  push r8
000073ef1c5d343a  push r9
000073ef1c5d343c  push r10
000073ef1c5d343e  push r11
000073ef1c5d3440  sub rsp, 0xF0
000073ef1c5d3447  vmovaps [rsp], xmm0
000073ef1c5d344c  vmovaps [rsp+0x10], xmm1
000073ef1c5d3452  vmovaps [rsp+0x20], xmm2
000073ef1c5d3458  vmovaps [rsp+0x30], xmm3
000073ef1c5d345e  vmovaps [rsp+0x40], xmm4
000073ef1c5d3464  vmovaps [rsp+0x50], xmm5
000073ef1c5d346a  vmovaps [rsp+0x60], xmm6
000073ef1c5d3470  vmovaps [rsp+0x70], xmm7
000073ef1c5d3476  vmovaps [rsp+0x80], xmm8
000073ef1c5d347f  vmovaps [rsp+0x90], xmm9
000073ef1c5d3488  vmovaps [rsp+0xA0], xmm10
000073ef1c5d3491  vmovaps [rsp+0xB0], xmm11
000073ef1c5d349a  vmovaps [rsp+0xC0], xmm12
000073ef1c5d34a3  vmovaps [rsp+0xD0], xmm13
000073ef1c5d34ac  vmovaps [rsp+0xE0], xmm15
000073ef1c5d34b5  sub rsp, 0x30
000073ef1c5d34b9  movaps [rsp], xmm14
000073ef1c5d34be  movaps [rsp+0x10], xmm12
000073ef1c5d34c4  movaps [rsp+0x20], xmm5
000073ef1c5d34c9  lea rdi, [rsp]
000073ef1c5d34cd  mov esi, 0x00
000073ef1c5d34d2  mov rax, 0x56F25E118530
000073ef1c5d34dc  call rax
000073ef1c5d34de  movaps xmm14, [rsp]
000073ef1c5d34e3  add rsp, 0x30
000073ef1c5d34e7  vmovaps xmm0, [rsp]
000073ef1c5d34ec  vmovaps xmm1, [rsp+0x10]
000073ef1c5d34f2  vmovaps xmm2, [rsp+0x20]
000073ef1c5d34f8  vmovaps xmm3, [rsp+0x30]
000073ef1c5d34fe  vmovaps xmm4, [rsp+0x40]
000073ef1c5d3504  vmovaps xmm5, [rsp+0x50]
000073ef1c5d350a  vmovaps xmm6, [rsp+0x60]
000073ef1c5d3510  vmovaps xmm7, [rsp+0x70]
000073ef1c5d3516  vmovaps xmm8, [rsp+0x80]
000073ef1c5d351f  vmovaps xmm9, [rsp+0x90]
000073ef1c5d3528  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d3531  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d353a  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d3543  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d354c  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d3555  add rsp, 0xF0
000073ef1c5d355c  pop r11
000073ef1c5d355e  pop r10
000073ef1c5d3560  pop r9
000073ef1c5d3562  pop r8
000073ef1c5d3564  pop rsi
000073ef1c5d3565  pop rdi
000073ef1c5d3566  pop rdx
000073ef1c5d3567  pop rcx
000073ef1c5d3568  pop rax
000073ef1c5d3569  add rsp, 0x08
000073ef1c5d356d  jmp 0x000073EF1C5CFEF1
000073ef1c5d3572  sub rsp, 0x08
000073ef1c5d3576  push rax
000073ef1c5d3577  push rcx
000073ef1c5d3578  push rdx
000073ef1c5d3579  push rdi
000073ef1c5d357a  push rsi
000073ef1c5d357b  push r8
000073ef1c5d357d  push r9
000073ef1c5d357f  push r10
000073ef1c5d3581  push r11
000073ef1c5d3583  sub rsp, 0xF0
000073ef1c5d358a  vmovaps [rsp], xmm0
000073ef1c5d358f  vmovaps [rsp+0x10], xmm1
000073ef1c5d3595  vmovaps [rsp+0x20], xmm2
000073ef1c5d359b  vmovaps [rsp+0x30], xmm3
000073ef1c5d35a1  vmovaps [rsp+0x40], xmm4
000073ef1c5d35a7  vmovaps [rsp+0x50], xmm5
000073ef1c5d35ad  vmovaps [rsp+0x60], xmm7
000073ef1c5d35b3  vmovaps [rsp+0x70], xmm8
000073ef1c5d35b9  vmovaps [rsp+0x80], xmm9
000073ef1c5d35c2  vmovaps [rsp+0x90], xmm10
000073ef1c5d35cb  vmovaps [rsp+0xA0], xmm11
000073ef1c5d35d4  vmovaps [rsp+0xB0], xmm12
000073ef1c5d35dd  vmovaps [rsp+0xC0], xmm13
000073ef1c5d35e6  vmovaps [rsp+0xD0], xmm14
000073ef1c5d35ef  vmovaps [rsp+0xE0], xmm15
000073ef1c5d35f8  sub rsp, 0x30
000073ef1c5d35fc  movaps [rsp], xmm6
000073ef1c5d3600  movaps [rsp+0x10], xmm9
000073ef1c5d3606  movaps [rsp+0x20], xmm12
000073ef1c5d360c  lea rdi, [rsp]
000073ef1c5d3610  mov esi, 0x00
000073ef1c5d3615  mov rax, 0x56F25E118530
000073ef1c5d361f  call rax
000073ef1c5d3621  movaps xmm6, [rsp]
000073ef1c5d3625  add rsp, 0x30
000073ef1c5d3629  vmovaps xmm0, [rsp]
000073ef1c5d362e  vmovaps xmm1, [rsp+0x10]
000073ef1c5d3634  vmovaps xmm2, [rsp+0x20]
000073ef1c5d363a  vmovaps xmm3, [rsp+0x30]
000073ef1c5d3640  vmovaps xmm4, [rsp+0x40]
000073ef1c5d3646  vmovaps xmm5, [rsp+0x50]
000073ef1c5d364c  vmovaps xmm7, [rsp+0x60]
000073ef1c5d3652  vmovaps xmm8, [rsp+0x70]
000073ef1c5d3658  vmovaps xmm9, [rsp+0x80]
000073ef1c5d3661  vmovaps xmm10, [rsp+0x90]
000073ef1c5d366a  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d3673  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d367c  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d3685  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d368e  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d3697  add rsp, 0xF0
000073ef1c5d369e  pop r11
000073ef1c5d36a0  pop r10
000073ef1c5d36a2  pop r9
000073ef1c5d36a4  pop r8
000073ef1c5d36a6  pop rsi
000073ef1c5d36a7  pop rdi
000073ef1c5d36a8  pop rdx
000073ef1c5d36a9  pop rcx
000073ef1c5d36aa  pop rax
000073ef1c5d36ab  add rsp, 0x08
000073ef1c5d36af  jmp 0x000073EF1C5CFF19
000073ef1c5d36b4  sub rsp, 0x08
000073ef1c5d36b8  push rax
000073ef1c5d36b9  push rcx
000073ef1c5d36ba  push rdx
000073ef1c5d36bb  push rdi
000073ef1c5d36bc  push rsi
000073ef1c5d36bd  push r8
000073ef1c5d36bf  push r9
000073ef1c5d36c1  push r10
000073ef1c5d36c3  push r11
000073ef1c5d36c5  sub rsp, 0xF0
000073ef1c5d36cc  vmovaps [rsp], xmm0
000073ef1c5d36d1  vmovaps [rsp+0x10], xmm1
000073ef1c5d36d7  vmovaps [rsp+0x20], xmm2
000073ef1c5d36dd  vmovaps [rsp+0x30], xmm3
000073ef1c5d36e3  vmovaps [rsp+0x40], xmm4
000073ef1c5d36e9  vmovaps [rsp+0x50], xmm5
000073ef1c5d36ef  vmovaps [rsp+0x60], xmm6
000073ef1c5d36f5  vmovaps [rsp+0x70], xmm7
000073ef1c5d36fb  vmovaps [rsp+0x80], xmm8
000073ef1c5d3704  vmovaps [rsp+0x90], xmm9
000073ef1c5d370d  vmovaps [rsp+0xA0], xmm10
000073ef1c5d3716  vmovaps [rsp+0xB0], xmm11
000073ef1c5d371f  vmovaps [rsp+0xC0], xmm13
000073ef1c5d3728  vmovaps [rsp+0xD0], xmm14
000073ef1c5d3731  vmovaps [rsp+0xE0], xmm15
000073ef1c5d373a  sub rsp, 0x30
000073ef1c5d373e  movaps [rsp], xmm12
000073ef1c5d3743  movaps [rsp+0x10], xmm15
000073ef1c5d3749  movaps [rsp+0x20], xmm13
000073ef1c5d374f  lea rdi, [rsp]
000073ef1c5d3753  mov esi, 0x00
000073ef1c5d3758  mov rax, 0x56F25E118530
000073ef1c5d3762  call rax
000073ef1c5d3764  movaps xmm12, [rsp]
000073ef1c5d3769  add rsp, 0x30
000073ef1c5d376d  vmovaps xmm0, [rsp]
000073ef1c5d3772  vmovaps xmm1, [rsp+0x10]
000073ef1c5d3778  vmovaps xmm2, [rsp+0x20]
000073ef1c5d377e  vmovaps xmm3, [rsp+0x30]
000073ef1c5d3784  vmovaps xmm4, [rsp+0x40]
000073ef1c5d378a  vmovaps xmm5, [rsp+0x50]
000073ef1c5d3790  vmovaps xmm6, [rsp+0x60]
000073ef1c5d3796  vmovaps xmm7, [rsp+0x70]
000073ef1c5d379c  vmovaps xmm8, [rsp+0x80]
000073ef1c5d37a5  vmovaps xmm9, [rsp+0x90]
000073ef1c5d37ae  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d37b7  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d37c0  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d37c9  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d37d2  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d37db  add rsp, 0xF0
000073ef1c5d37e2  pop r11
000073ef1c5d37e4  pop r10
000073ef1c5d37e6  pop r9
000073ef1c5d37e8  pop r8
000073ef1c5d37ea  pop rsi
000073ef1c5d37eb  pop rdi
000073ef1c5d37ec  pop rdx
000073ef1c5d37ed  pop rcx
000073ef1c5d37ee  pop rax
000073ef1c5d37ef  add rsp, 0x08
000073ef1c5d37f3  jmp 0x000073EF1C5CFF34
000073ef1c5d37f8  sub rsp, 0x08
000073ef1c5d37fc  push rax
000073ef1c5d37fd  push rcx
000073ef1c5d37fe  push rdx
000073ef1c5d37ff  push rdi
000073ef1c5d3800  push rsi
000073ef1c5d3801  push r8
000073ef1c5d3803  push r9
000073ef1c5d3805  push r10
000073ef1c5d3807  push r11
000073ef1c5d3809  sub rsp, 0xF0
000073ef1c5d3810  vmovaps [rsp], xmm0
000073ef1c5d3815  vmovaps [rsp+0x10], xmm1
000073ef1c5d381b  vmovaps [rsp+0x20], xmm2
000073ef1c5d3821  vmovaps [rsp+0x30], xmm3
000073ef1c5d3827  vmovaps [rsp+0x40], xmm4
000073ef1c5d382d  vmovaps [rsp+0x50], xmm5
000073ef1c5d3833  vmovaps [rsp+0x60], xmm6
000073ef1c5d3839  vmovaps [rsp+0x70], xmm7
000073ef1c5d383f  vmovaps [rsp+0x80], xmm8
000073ef1c5d3848  vmovaps [rsp+0x90], xmm9
000073ef1c5d3851  vmovaps [rsp+0xA0], xmm10
000073ef1c5d385a  vmovaps [rsp+0xB0], xmm11
000073ef1c5d3863  vmovaps [rsp+0xC0], xmm12
000073ef1c5d386c  vmovaps [rsp+0xD0], xmm13
000073ef1c5d3875  vmovaps [rsp+0xE0], xmm14
000073ef1c5d387e  sub rsp, 0x30
000073ef1c5d3882  movaps [rsp], xmm15
000073ef1c5d3887  movaps [rsp+0x10], xmm13
000073ef1c5d388d  movaps [rsp+0x20], xmm10
000073ef1c5d3893  lea rdi, [rsp]
000073ef1c5d3897  mov esi, 0x00
000073ef1c5d389c  mov rax, 0x56F25E118530
000073ef1c5d38a6  call rax
000073ef1c5d38a8  movaps xmm15, [rsp]
000073ef1c5d38ad  add rsp, 0x30
000073ef1c5d38b1  vmovaps xmm0, [rsp]
000073ef1c5d38b6  vmovaps xmm1, [rsp+0x10]
000073ef1c5d38bc  vmovaps xmm2, [rsp+0x20]
000073ef1c5d38c2  vmovaps xmm3, [rsp+0x30]
000073ef1c5d38c8  vmovaps xmm4, [rsp+0x40]
000073ef1c5d38ce  vmovaps xmm5, [rsp+0x50]
000073ef1c5d38d4  vmovaps xmm6, [rsp+0x60]
000073ef1c5d38da  vmovaps xmm7, [rsp+0x70]
000073ef1c5d38e0  vmovaps xmm8, [rsp+0x80]
000073ef1c5d38e9  vmovaps xmm9, [rsp+0x90]
000073ef1c5d38f2  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d38fb  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d3904  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d390d  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d3916  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d391f  add rsp, 0xF0
000073ef1c5d3926  pop r11
000073ef1c5d3928  pop r10
000073ef1c5d392a  pop r9
000073ef1c5d392c  pop r8
000073ef1c5d392e  pop rsi
000073ef1c5d392f  pop rdi
000073ef1c5d3930  pop rdx
000073ef1c5d3931  pop rcx
000073ef1c5d3932  pop rax
000073ef1c5d3933  add rsp, 0x08
000073ef1c5d3937  jmp 0x000073EF1C5CFF55
000073ef1c5d393c  call 0x000073EF1C40C260
000073ef1c5d3941  jmp 0x000073EF1C5CFFB0
000073ef1c5d3946  sub rsp, 0x08
000073ef1c5d394a  push rax
000073ef1c5d394b  push rcx
000073ef1c5d394c  push rdx
000073ef1c5d394d  push rdi
000073ef1c5d394e  push rsi
000073ef1c5d394f  push r8
000073ef1c5d3951  push r9
000073ef1c5d3953  push r10
000073ef1c5d3955  push r11
000073ef1c5d3957  sub rsp, 0xF0
000073ef1c5d395e  vmovaps [rsp], xmm0
000073ef1c5d3963  vmovaps [rsp+0x10], xmm1
000073ef1c5d3969  vmovaps [rsp+0x20], xmm2
000073ef1c5d396f  vmovaps [rsp+0x30], xmm3
000073ef1c5d3975  vmovaps [rsp+0x40], xmm4
000073ef1c5d397b  vmovaps [rsp+0x50], xmm5
000073ef1c5d3981  vmovaps [rsp+0x60], xmm6
000073ef1c5d3987  vmovaps [rsp+0x70], xmm7
000073ef1c5d398d  vmovaps [rsp+0x80], xmm8
000073ef1c5d3996  vmovaps [rsp+0x90], xmm10
000073ef1c5d399f  vmovaps [rsp+0xA0], xmm11
000073ef1c5d39a8  vmovaps [rsp+0xB0], xmm12
000073ef1c5d39b1  vmovaps [rsp+0xC0], xmm13
000073ef1c5d39ba  vmovaps [rsp+0xD0], xmm14
000073ef1c5d39c3  vmovaps [rsp+0xE0], xmm15
000073ef1c5d39cc  sub rsp, 0x30
000073ef1c5d39d0  movaps [rsp], xmm9
000073ef1c5d39d5  movaps [rsp+0x10], xmm8
000073ef1c5d39db  movaps [rsp+0x20], xmm10
000073ef1c5d39e1  lea rdi, [rsp]
000073ef1c5d39e5  mov esi, 0x00
000073ef1c5d39ea  mov rax, 0x56F25E118530
000073ef1c5d39f4  call rax
000073ef1c5d39f6  movaps xmm9, [rsp]
000073ef1c5d39fb  add rsp, 0x30
000073ef1c5d39ff  vmovaps xmm0, [rsp]
000073ef1c5d3a04  vmovaps xmm1, [rsp+0x10]
000073ef1c5d3a0a  vmovaps xmm2, [rsp+0x20]
000073ef1c5d3a10  vmovaps xmm3, [rsp+0x30]
000073ef1c5d3a16  vmovaps xmm4, [rsp+0x40]
000073ef1c5d3a1c  vmovaps xmm5, [rsp+0x50]
000073ef1c5d3a22  vmovaps xmm6, [rsp+0x60]
000073ef1c5d3a28  vmovaps xmm7, [rsp+0x70]
000073ef1c5d3a2e  vmovaps xmm8, [rsp+0x80]
000073ef1c5d3a37  vmovaps xmm10, [rsp+0x90]
000073ef1c5d3a40  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d3a49  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d3a52  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d3a5b  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d3a64  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d3a6d  add rsp, 0xF0
000073ef1c5d3a74  pop r11
000073ef1c5d3a76  pop r10
000073ef1c5d3a78  pop r9
000073ef1c5d3a7a  pop r8
000073ef1c5d3a7c  pop rsi
000073ef1c5d3a7d  pop rdi
000073ef1c5d3a7e  pop rdx
000073ef1c5d3a7f  pop rcx
000073ef1c5d3a80  pop rax
000073ef1c5d3a81  add rsp, 0x08
000073ef1c5d3a85  jmp 0x000073EF1C5CFFE1
000073ef1c5d3a8a  sub rsp, 0x08
000073ef1c5d3a8e  push rax
000073ef1c5d3a8f  push rcx
000073ef1c5d3a90  push rdx
000073ef1c5d3a91  push rdi
000073ef1c5d3a92  push rsi
000073ef1c5d3a93  push r8
000073ef1c5d3a95  push r9
000073ef1c5d3a97  push r10
000073ef1c5d3a99  push r11
000073ef1c5d3a9b  sub rsp, 0xF0
000073ef1c5d3aa2  vmovaps [rsp], xmm0
000073ef1c5d3aa7  vmovaps [rsp+0x10], xmm1
000073ef1c5d3aad  vmovaps [rsp+0x20], xmm2
000073ef1c5d3ab3  vmovaps [rsp+0x30], xmm3
000073ef1c5d3ab9  vmovaps [rsp+0x40], xmm4
000073ef1c5d3abf  vmovaps [rsp+0x50], xmm5
000073ef1c5d3ac5  vmovaps [rsp+0x60], xmm6
000073ef1c5d3acb  vmovaps [rsp+0x70], xmm7
000073ef1c5d3ad1  vmovaps [rsp+0x80], xmm8
000073ef1c5d3ada  vmovaps [rsp+0x90], xmm9
000073ef1c5d3ae3  vmovaps [rsp+0xA0], xmm11
000073ef1c5d3aec  vmovaps [rsp+0xB0], xmm12
000073ef1c5d3af5  vmovaps [rsp+0xC0], xmm13
000073ef1c5d3afe  vmovaps [rsp+0xD0], xmm14
000073ef1c5d3b07  vmovaps [rsp+0xE0], xmm15
000073ef1c5d3b10  sub rsp, 0x30
000073ef1c5d3b14  movaps [rsp], xmm10
000073ef1c5d3b19  movaps [rsp+0x10], xmm1
000073ef1c5d3b1e  movaps [rsp+0x20], xmm11
000073ef1c5d3b24  lea rdi, [rsp]
000073ef1c5d3b28  mov esi, 0x00
000073ef1c5d3b2d  mov rax, 0x56F25E118530
000073ef1c5d3b37  call rax
000073ef1c5d3b39  movaps xmm10, [rsp]
000073ef1c5d3b3e  add rsp, 0x30
000073ef1c5d3b42  vmovaps xmm0, [rsp]
000073ef1c5d3b47  vmovaps xmm1, [rsp+0x10]
000073ef1c5d3b4d  vmovaps xmm2, [rsp+0x20]
000073ef1c5d3b53  vmovaps xmm3, [rsp+0x30]
000073ef1c5d3b59  vmovaps xmm4, [rsp+0x40]
000073ef1c5d3b5f  vmovaps xmm5, [rsp+0x50]
000073ef1c5d3b65  vmovaps xmm6, [rsp+0x60]
000073ef1c5d3b6b  vmovaps xmm7, [rsp+0x70]
000073ef1c5d3b71  vmovaps xmm8, [rsp+0x80]
000073ef1c5d3b7a  vmovaps xmm9, [rsp+0x90]
000073ef1c5d3b83  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d3b8c  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d3b95  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d3b9e  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d3ba7  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d3bb0  add rsp, 0xF0
000073ef1c5d3bb7  pop r11
000073ef1c5d3bb9  pop r10
000073ef1c5d3bbb  pop r9
000073ef1c5d3bbd  pop r8
000073ef1c5d3bbf  pop rsi
000073ef1c5d3bc0  pop rdi
000073ef1c5d3bc1  pop rdx
000073ef1c5d3bc2  pop rcx
000073ef1c5d3bc3  pop rax
000073ef1c5d3bc4  add rsp, 0x08
000073ef1c5d3bc8  jmp 0x000073EF1C5CFFFC
000073ef1c5d3bcd  sub rsp, 0x08
000073ef1c5d3bd1  push rax
000073ef1c5d3bd2  push rcx
000073ef1c5d3bd3  push rdx
000073ef1c5d3bd4  push rdi
000073ef1c5d3bd5  push rsi
000073ef1c5d3bd6  push r8
000073ef1c5d3bd8  push r9
000073ef1c5d3bda  push r10
000073ef1c5d3bdc  push r11
000073ef1c5d3bde  sub rsp, 0xF0
000073ef1c5d3be5  vmovaps [rsp], xmm0
000073ef1c5d3bea  vmovaps [rsp+0x10], xmm2
000073ef1c5d3bf0  vmovaps [rsp+0x20], xmm3
000073ef1c5d3bf6  vmovaps [rsp+0x30], xmm4
000073ef1c5d3bfc  vmovaps [rsp+0x40], xmm5
000073ef1c5d3c02  vmovaps [rsp+0x50], xmm6
000073ef1c5d3c08  vmovaps [rsp+0x60], xmm7
000073ef1c5d3c0e  vmovaps [rsp+0x70], xmm8
000073ef1c5d3c14  vmovaps [rsp+0x80], xmm9
000073ef1c5d3c1d  vmovaps [rsp+0x90], xmm10
000073ef1c5d3c26  vmovaps [rsp+0xA0], xmm11
000073ef1c5d3c2f  vmovaps [rsp+0xB0], xmm12
000073ef1c5d3c38  vmovaps [rsp+0xC0], xmm13
000073ef1c5d3c41  vmovaps [rsp+0xD0], xmm14
000073ef1c5d3c4a  vmovaps [rsp+0xE0], xmm15
000073ef1c5d3c53  sub rsp, 0x30
000073ef1c5d3c57  movaps [rsp], xmm1
000073ef1c5d3c5b  movaps [rsp+0x10], xmm14
000073ef1c5d3c61  movaps [rsp+0x20], xmm6
000073ef1c5d3c66  lea rdi, [rsp]
000073ef1c5d3c6a  mov esi, 0x00
000073ef1c5d3c6f  mov rax, 0x56F25E118530
000073ef1c5d3c79  call rax
000073ef1c5d3c7b  movaps xmm1, [rsp]
000073ef1c5d3c7f  add rsp, 0x30
000073ef1c5d3c83  vmovaps xmm0, [rsp]
000073ef1c5d3c88  vmovaps xmm2, [rsp+0x10]
000073ef1c5d3c8e  vmovaps xmm3, [rsp+0x20]
000073ef1c5d3c94  vmovaps xmm4, [rsp+0x30]
000073ef1c5d3c9a  vmovaps xmm5, [rsp+0x40]
000073ef1c5d3ca0  vmovaps xmm6, [rsp+0x50]
000073ef1c5d3ca6  vmovaps xmm7, [rsp+0x60]
000073ef1c5d3cac  vmovaps xmm8, [rsp+0x70]
000073ef1c5d3cb2  vmovaps xmm9, [rsp+0x80]
000073ef1c5d3cbb  vmovaps xmm10, [rsp+0x90]
000073ef1c5d3cc4  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d3ccd  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d3cd6  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d3cdf  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d3ce8  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d3cf1  add rsp, 0xF0
000073ef1c5d3cf8  pop r11
000073ef1c5d3cfa  pop r10
000073ef1c5d3cfc  pop r9
000073ef1c5d3cfe  pop r8
000073ef1c5d3d00  pop rsi
000073ef1c5d3d01  pop rdi
000073ef1c5d3d02  pop rdx
000073ef1c5d3d03  pop rcx
000073ef1c5d3d04  pop rax
000073ef1c5d3d05  add rsp, 0x08
000073ef1c5d3d09  jmp 0x000073EF1C5D0015
000073ef1c5d3d0e  sub rsp, 0x08
000073ef1c5d3d12  push rax
000073ef1c5d3d13  push rcx
000073ef1c5d3d14  push rdx
000073ef1c5d3d15  push rdi
000073ef1c5d3d16  push rsi
000073ef1c5d3d17  push r8
000073ef1c5d3d19  push r9
000073ef1c5d3d1b  push r10
000073ef1c5d3d1d  push r11
000073ef1c5d3d1f  sub rsp, 0xF0
000073ef1c5d3d26  vmovaps [rsp], xmm0
000073ef1c5d3d2b  vmovaps [rsp+0x10], xmm1
000073ef1c5d3d31  vmovaps [rsp+0x20], xmm2
000073ef1c5d3d37  vmovaps [rsp+0x30], xmm3
000073ef1c5d3d3d  vmovaps [rsp+0x40], xmm4
000073ef1c5d3d43  vmovaps [rsp+0x50], xmm5
000073ef1c5d3d49  vmovaps [rsp+0x60], xmm6
000073ef1c5d3d4f  vmovaps [rsp+0x70], xmm7
000073ef1c5d3d55  vmovaps [rsp+0x80], xmm8
000073ef1c5d3d5e  vmovaps [rsp+0x90], xmm9
000073ef1c5d3d67  vmovaps [rsp+0xA0], xmm10
000073ef1c5d3d70  vmovaps [rsp+0xB0], xmm12
000073ef1c5d3d79  vmovaps [rsp+0xC0], xmm13
000073ef1c5d3d82  vmovaps [rsp+0xD0], xmm14
000073ef1c5d3d8b  vmovaps [rsp+0xE0], xmm15
000073ef1c5d3d94  sub rsp, 0x30
000073ef1c5d3d98  movaps [rsp], xmm11
000073ef1c5d3d9d  movaps [rsp+0x10], xmm13
000073ef1c5d3da3  movaps [rsp+0x20], xmm14
000073ef1c5d3da9  lea rdi, [rsp]
000073ef1c5d3dad  mov esi, 0x00
000073ef1c5d3db2  mov rax, 0x56F25E118530
000073ef1c5d3dbc  call rax
000073ef1c5d3dbe  movaps xmm11, [rsp]
000073ef1c5d3dc3  add rsp, 0x30
000073ef1c5d3dc7  vmovaps xmm0, [rsp]
000073ef1c5d3dcc  vmovaps xmm1, [rsp+0x10]
000073ef1c5d3dd2  vmovaps xmm2, [rsp+0x20]
000073ef1c5d3dd8  vmovaps xmm3, [rsp+0x30]
000073ef1c5d3dde  vmovaps xmm4, [rsp+0x40]
000073ef1c5d3de4  vmovaps xmm5, [rsp+0x50]
000073ef1c5d3dea  vmovaps xmm6, [rsp+0x60]
000073ef1c5d3df0  vmovaps xmm7, [rsp+0x70]
000073ef1c5d3df6  vmovaps xmm8, [rsp+0x80]
000073ef1c5d3dff  vmovaps xmm9, [rsp+0x90]
000073ef1c5d3e08  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d3e11  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d3e1a  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d3e23  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d3e2c  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d3e35  add rsp, 0xF0
000073ef1c5d3e3c  pop r11
000073ef1c5d3e3e  pop r10
000073ef1c5d3e40  pop r9
000073ef1c5d3e42  pop r8
000073ef1c5d3e44  pop rsi
000073ef1c5d3e45  pop rdi
000073ef1c5d3e46  pop rdx
000073ef1c5d3e47  pop rcx
000073ef1c5d3e48  pop rax
000073ef1c5d3e49  add rsp, 0x08
000073ef1c5d3e4d  jmp 0x000073EF1C5D003F
000073ef1c5d3e52  sub rsp, 0x08
000073ef1c5d3e56  push rax
000073ef1c5d3e57  push rcx
000073ef1c5d3e58  push rdx
000073ef1c5d3e59  push rdi
000073ef1c5d3e5a  push rsi
000073ef1c5d3e5b  push r8
000073ef1c5d3e5d  push r9
000073ef1c5d3e5f  push r10
000073ef1c5d3e61  push r11
000073ef1c5d3e63  sub rsp, 0xF0
000073ef1c5d3e6a  vmovaps [rsp], xmm0
000073ef1c5d3e6f  vmovaps [rsp+0x10], xmm1
000073ef1c5d3e75  vmovaps [rsp+0x20], xmm2
000073ef1c5d3e7b  vmovaps [rsp+0x30], xmm3
000073ef1c5d3e81  vmovaps [rsp+0x40], xmm4
000073ef1c5d3e87  vmovaps [rsp+0x50], xmm5
000073ef1c5d3e8d  vmovaps [rsp+0x60], xmm6
000073ef1c5d3e93  vmovaps [rsp+0x70], xmm7
000073ef1c5d3e99  vmovaps [rsp+0x80], xmm8
000073ef1c5d3ea2  vmovaps [rsp+0x90], xmm9
000073ef1c5d3eab  vmovaps [rsp+0xA0], xmm10
000073ef1c5d3eb4  vmovaps [rsp+0xB0], xmm11
000073ef1c5d3ebd  vmovaps [rsp+0xC0], xmm12
000073ef1c5d3ec6  vmovaps [rsp+0xD0], xmm14
000073ef1c5d3ecf  vmovaps [rsp+0xE0], xmm15
000073ef1c5d3ed8  sub rsp, 0x30
000073ef1c5d3edc  movaps [rsp], xmm13
000073ef1c5d3ee1  movaps [rsp+0x10], xmm8
000073ef1c5d3ee7  movaps [rsp+0x20], xmm14
000073ef1c5d3eed  lea rdi, [rsp]
000073ef1c5d3ef1  mov esi, 0x00
000073ef1c5d3ef6  mov rax, 0x56F25E118530
000073ef1c5d3f00  call rax
000073ef1c5d3f02  movaps xmm13, [rsp]
000073ef1c5d3f07  add rsp, 0x30
000073ef1c5d3f0b  vmovaps xmm0, [rsp]
000073ef1c5d3f10  vmovaps xmm1, [rsp+0x10]
000073ef1c5d3f16  vmovaps xmm2, [rsp+0x20]
000073ef1c5d3f1c  vmovaps xmm3, [rsp+0x30]
000073ef1c5d3f22  vmovaps xmm4, [rsp+0x40]
000073ef1c5d3f28  vmovaps xmm5, [rsp+0x50]
000073ef1c5d3f2e  vmovaps xmm6, [rsp+0x60]
000073ef1c5d3f34  vmovaps xmm7, [rsp+0x70]
000073ef1c5d3f3a  vmovaps xmm8, [rsp+0x80]
000073ef1c5d3f43  vmovaps xmm9, [rsp+0x90]
000073ef1c5d3f4c  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d3f55  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d3f5e  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d3f67  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d3f70  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d3f79  add rsp, 0xF0
000073ef1c5d3f80  pop r11
000073ef1c5d3f82  pop r10
000073ef1c5d3f84  pop r9
000073ef1c5d3f86  pop r8
000073ef1c5d3f88  pop rsi
000073ef1c5d3f89  pop rdi
000073ef1c5d3f8a  pop rdx
000073ef1c5d3f8b  pop rcx
000073ef1c5d3f8c  pop rax
000073ef1c5d3f8d  add rsp, 0x08
000073ef1c5d3f91  jmp 0x000073EF1C5D006E
000073ef1c5d3f96  sub rsp, 0x08
000073ef1c5d3f9a  push rax
000073ef1c5d3f9b  push rcx
000073ef1c5d3f9c  push rdx
000073ef1c5d3f9d  push rdi
000073ef1c5d3f9e  push rsi
000073ef1c5d3f9f  push r8
000073ef1c5d3fa1  push r9
000073ef1c5d3fa3  push r10
000073ef1c5d3fa5  push r11
000073ef1c5d3fa7  sub rsp, 0xF0
000073ef1c5d3fae  vmovaps [rsp], xmm0
000073ef1c5d3fb3  vmovaps [rsp+0x10], xmm1
000073ef1c5d3fb9  vmovaps [rsp+0x20], xmm2
000073ef1c5d3fbf  vmovaps [rsp+0x30], xmm3
000073ef1c5d3fc5  vmovaps [rsp+0x40], xmm4
000073ef1c5d3fcb  vmovaps [rsp+0x50], xmm5
000073ef1c5d3fd1  vmovaps [rsp+0x60], xmm6
000073ef1c5d3fd7  vmovaps [rsp+0x70], xmm7
000073ef1c5d3fdd  vmovaps [rsp+0x80], xmm9
000073ef1c5d3fe6  vmovaps [rsp+0x90], xmm10
000073ef1c5d3fef  vmovaps [rsp+0xA0], xmm11
000073ef1c5d3ff8  vmovaps [rsp+0xB0], xmm12
000073ef1c5d4001  vmovaps [rsp+0xC0], xmm13
000073ef1c5d400a  vmovaps [rsp+0xD0], xmm14
000073ef1c5d4013  vmovaps [rsp+0xE0], xmm15
000073ef1c5d401c  sub rsp, 0x30
000073ef1c5d4020  movaps [rsp], xmm8
000073ef1c5d4025  movaps [rsp+0x10], xmm7
000073ef1c5d402a  movaps [rsp+0x20], xmm14
000073ef1c5d4030  lea rdi, [rsp]
000073ef1c5d4034  mov esi, 0x00
000073ef1c5d4039  mov rax, 0x56F25E118530
000073ef1c5d4043  call rax
000073ef1c5d4045  movaps xmm8, [rsp]
000073ef1c5d404a  add rsp, 0x30
000073ef1c5d404e  vmovaps xmm0, [rsp]
000073ef1c5d4053  vmovaps xmm1, [rsp+0x10]
000073ef1c5d4059  vmovaps xmm2, [rsp+0x20]
000073ef1c5d405f  vmovaps xmm3, [rsp+0x30]
000073ef1c5d4065  vmovaps xmm4, [rsp+0x40]
000073ef1c5d406b  vmovaps xmm5, [rsp+0x50]
000073ef1c5d4071  vmovaps xmm6, [rsp+0x60]
000073ef1c5d4077  vmovaps xmm7, [rsp+0x70]
000073ef1c5d407d  vmovaps xmm9, [rsp+0x80]
000073ef1c5d4086  vmovaps xmm10, [rsp+0x90]
000073ef1c5d408f  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d4098  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d40a1  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d40aa  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d40b3  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d40bc  add rsp, 0xF0
000073ef1c5d40c3  pop r11
000073ef1c5d40c5  pop r10
000073ef1c5d40c7  pop r9
000073ef1c5d40c9  pop r8
000073ef1c5d40cb  pop rsi
000073ef1c5d40cc  pop rdi
000073ef1c5d40cd  pop rdx
000073ef1c5d40ce  pop rcx
000073ef1c5d40cf  pop rax
000073ef1c5d40d0  add rsp, 0x08
000073ef1c5d40d4  jmp 0x000073EF1C5D0094
000073ef1c5d40d9  sub rsp, 0x08
000073ef1c5d40dd  push rax
000073ef1c5d40de  push rcx
000073ef1c5d40df  push rdx
000073ef1c5d40e0  push rdi
000073ef1c5d40e1  push rsi
000073ef1c5d40e2  push r8
000073ef1c5d40e4  push r9
000073ef1c5d40e6  push r10
000073ef1c5d40e8  push r11
000073ef1c5d40ea  sub rsp, 0xF0
000073ef1c5d40f1  vmovaps [rsp], xmm0
000073ef1c5d40f6  vmovaps [rsp+0x10], xmm1
000073ef1c5d40fc  vmovaps [rsp+0x20], xmm2
000073ef1c5d4102  vmovaps [rsp+0x30], xmm3
000073ef1c5d4108  vmovaps [rsp+0x40], xmm4
000073ef1c5d410e  vmovaps [rsp+0x50], xmm5
000073ef1c5d4114  vmovaps [rsp+0x60], xmm6
000073ef1c5d411a  vmovaps [rsp+0x70], xmm7
000073ef1c5d4120  vmovaps [rsp+0x80], xmm8
000073ef1c5d4129  vmovaps [rsp+0x90], xmm9
000073ef1c5d4132  vmovaps [rsp+0xA0], xmm10
000073ef1c5d413b  vmovaps [rsp+0xB0], xmm11
000073ef1c5d4144  vmovaps [rsp+0xC0], xmm12
000073ef1c5d414d  vmovaps [rsp+0xD0], xmm13
000073ef1c5d4156  vmovaps [rsp+0xE0], xmm15
000073ef1c5d415f  sub rsp, 0x30
000073ef1c5d4163  movaps [rsp], xmm14
000073ef1c5d4168  movaps [rsp+0x10], xmm12
000073ef1c5d416e  movaps [rsp+0x20], xmm9
000073ef1c5d4174  lea rdi, [rsp]
000073ef1c5d4178  mov esi, 0x00
000073ef1c5d417d  mov rax, 0x56F25E118530
000073ef1c5d4187  call rax
000073ef1c5d4189  movaps xmm14, [rsp]
000073ef1c5d418e  add rsp, 0x30
000073ef1c5d4192  vmovaps xmm0, [rsp]
000073ef1c5d4197  vmovaps xmm1, [rsp+0x10]
000073ef1c5d419d  vmovaps xmm2, [rsp+0x20]
000073ef1c5d41a3  vmovaps xmm3, [rsp+0x30]
000073ef1c5d41a9  vmovaps xmm4, [rsp+0x40]
000073ef1c5d41af  vmovaps xmm5, [rsp+0x50]
000073ef1c5d41b5  vmovaps xmm6, [rsp+0x60]
000073ef1c5d41bb  vmovaps xmm7, [rsp+0x70]
000073ef1c5d41c1  vmovaps xmm8, [rsp+0x80]
000073ef1c5d41ca  vmovaps xmm9, [rsp+0x90]
000073ef1c5d41d3  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d41dc  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d41e5  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d41ee  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d41f7  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d4200  add rsp, 0xF0
000073ef1c5d4207  pop r11
000073ef1c5d4209  pop r10
000073ef1c5d420b  pop r9
000073ef1c5d420d  pop r8
000073ef1c5d420f  pop rsi
000073ef1c5d4210  pop rdi
000073ef1c5d4211  pop rdx
000073ef1c5d4212  pop rcx
000073ef1c5d4213  pop rax
000073ef1c5d4214  add rsp, 0x08
000073ef1c5d4218  jmp 0x000073EF1C5D00AE
000073ef1c5d421d  sub rsp, 0x08
000073ef1c5d4221  push rax
000073ef1c5d4222  push rcx
000073ef1c5d4223  push rdx
000073ef1c5d4224  push rdi
000073ef1c5d4225  push rsi
000073ef1c5d4226  push r8
000073ef1c5d4228  push r9
000073ef1c5d422a  push r10
000073ef1c5d422c  push r11
000073ef1c5d422e  sub rsp, 0xF0
000073ef1c5d4235  vmovaps [rsp], xmm0
000073ef1c5d423a  vmovaps [rsp+0x10], xmm1
000073ef1c5d4240  vmovaps [rsp+0x20], xmm2
000073ef1c5d4246  vmovaps [rsp+0x30], xmm3
000073ef1c5d424c  vmovaps [rsp+0x40], xmm4
000073ef1c5d4252  vmovaps [rsp+0x50], xmm5
000073ef1c5d4258  vmovaps [rsp+0x60], xmm6
000073ef1c5d425e  vmovaps [rsp+0x70], xmm7
000073ef1c5d4264  vmovaps [rsp+0x80], xmm8
000073ef1c5d426d  vmovaps [rsp+0x90], xmm10
000073ef1c5d4276  vmovaps [rsp+0xA0], xmm11
000073ef1c5d427f  vmovaps [rsp+0xB0], xmm12
000073ef1c5d4288  vmovaps [rsp+0xC0], xmm13
000073ef1c5d4291  vmovaps [rsp+0xD0], xmm14
000073ef1c5d429a  vmovaps [rsp+0xE0], xmm15
000073ef1c5d42a3  sub rsp, 0x30
000073ef1c5d42a7  movaps [rsp], xmm9
000073ef1c5d42ac  movaps [rsp+0x10], xmm7
000073ef1c5d42b1  movaps [rsp+0x20], xmm12
000073ef1c5d42b7  lea rdi, [rsp]
000073ef1c5d42bb  mov esi, 0x00
000073ef1c5d42c0  mov rax, 0x56F25E118530
000073ef1c5d42ca  call rax
000073ef1c5d42cc  movaps xmm9, [rsp]
000073ef1c5d42d1  add rsp, 0x30
000073ef1c5d42d5  vmovaps xmm0, [rsp]
000073ef1c5d42da  vmovaps xmm1, [rsp+0x10]
000073ef1c5d42e0  vmovaps xmm2, [rsp+0x20]
000073ef1c5d42e6  vmovaps xmm3, [rsp+0x30]
000073ef1c5d42ec  vmovaps xmm4, [rsp+0x40]
000073ef1c5d42f2  vmovaps xmm5, [rsp+0x50]
000073ef1c5d42f8  vmovaps xmm6, [rsp+0x60]
000073ef1c5d42fe  vmovaps xmm7, [rsp+0x70]
000073ef1c5d4304  vmovaps xmm8, [rsp+0x80]
000073ef1c5d430d  vmovaps xmm10, [rsp+0x90]
000073ef1c5d4316  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d431f  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d4328  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d4331  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d433a  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d4343  add rsp, 0xF0
000073ef1c5d434a  pop r11
000073ef1c5d434c  pop r10
000073ef1c5d434e  pop r9
000073ef1c5d4350  pop r8
000073ef1c5d4352  pop rsi
000073ef1c5d4353  pop rdi
000073ef1c5d4354  pop rdx
000073ef1c5d4355  pop rcx
000073ef1c5d4356  pop rax
000073ef1c5d4357  add rsp, 0x08
000073ef1c5d435b  jmp 0x000073EF1C5D00DD
000073ef1c5d4360  sub rsp, 0x08
000073ef1c5d4364  push rax
000073ef1c5d4365  push rcx
000073ef1c5d4366  push rdx
000073ef1c5d4367  push rdi
000073ef1c5d4368  push rsi
000073ef1c5d4369  push r8
000073ef1c5d436b  push r9
000073ef1c5d436d  push r10
000073ef1c5d436f  push r11
000073ef1c5d4371  sub rsp, 0xF0
000073ef1c5d4378  vmovaps [rsp], xmm0
000073ef1c5d437d  vmovaps [rsp+0x10], xmm1
000073ef1c5d4383  vmovaps [rsp+0x20], xmm2
000073ef1c5d4389  vmovaps [rsp+0x30], xmm3
000073ef1c5d438f  vmovaps [rsp+0x40], xmm4
000073ef1c5d4395  vmovaps [rsp+0x50], xmm5
000073ef1c5d439b  vmovaps [rsp+0x60], xmm6
000073ef1c5d43a1  vmovaps [rsp+0x70], xmm7
000073ef1c5d43a7  vmovaps [rsp+0x80], xmm8
000073ef1c5d43b0  vmovaps [rsp+0x90], xmm9
000073ef1c5d43b9  vmovaps [rsp+0xA0], xmm10
000073ef1c5d43c2  vmovaps [rsp+0xB0], xmm11
000073ef1c5d43cb  vmovaps [rsp+0xC0], xmm13
000073ef1c5d43d4  vmovaps [rsp+0xD0], xmm14
000073ef1c5d43dd  vmovaps [rsp+0xE0], xmm15
000073ef1c5d43e6  sub rsp, 0x30
000073ef1c5d43ea  movaps [rsp], xmm12
000073ef1c5d43ef  movaps [rsp+0x10], xmm15
000073ef1c5d43f5  movaps [rsp+0x20], xmm11
000073ef1c5d43fb  lea rdi, [rsp]
000073ef1c5d43ff  mov esi, 0x00
000073ef1c5d4404  mov rax, 0x56F25E118530
000073ef1c5d440e  call rax
000073ef1c5d4410  movaps xmm12, [rsp]
000073ef1c5d4415  add rsp, 0x30
000073ef1c5d4419  vmovaps xmm0, [rsp]
000073ef1c5d441e  vmovaps xmm1, [rsp+0x10]
000073ef1c5d4424  vmovaps xmm2, [rsp+0x20]
000073ef1c5d442a  vmovaps xmm3, [rsp+0x30]
000073ef1c5d4430  vmovaps xmm4, [rsp+0x40]
000073ef1c5d4436  vmovaps xmm5, [rsp+0x50]
000073ef1c5d443c  vmovaps xmm6, [rsp+0x60]
000073ef1c5d4442  vmovaps xmm7, [rsp+0x70]
000073ef1c5d4448  vmovaps xmm8, [rsp+0x80]
000073ef1c5d4451  vmovaps xmm9, [rsp+0x90]
000073ef1c5d445a  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d4463  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d446c  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d4475  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d447e  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d4487  add rsp, 0xF0
000073ef1c5d448e  pop r11
000073ef1c5d4490  pop r10
000073ef1c5d4492  pop r9
000073ef1c5d4494  pop r8
000073ef1c5d4496  pop rsi
000073ef1c5d4497  pop rdi
000073ef1c5d4498  pop rdx
000073ef1c5d4499  pop rcx
000073ef1c5d449a  pop rax
000073ef1c5d449b  add rsp, 0x08
000073ef1c5d449f  jmp 0x000073EF1C5D00F7
000073ef1c5d44a4  sub rsp, 0x08
000073ef1c5d44a8  push rax
000073ef1c5d44a9  push rcx
000073ef1c5d44aa  push rdx
000073ef1c5d44ab  push rdi
000073ef1c5d44ac  push rsi
000073ef1c5d44ad  push r8
000073ef1c5d44af  push r9
000073ef1c5d44b1  push r10
000073ef1c5d44b3  push r11
000073ef1c5d44b5  sub rsp, 0xF0
000073ef1c5d44bc  vmovaps [rsp], xmm0
000073ef1c5d44c1  vmovaps [rsp+0x10], xmm1
000073ef1c5d44c7  vmovaps [rsp+0x20], xmm2
000073ef1c5d44cd  vmovaps [rsp+0x30], xmm3
000073ef1c5d44d3  vmovaps [rsp+0x40], xmm4
000073ef1c5d44d9  vmovaps [rsp+0x50], xmm5
000073ef1c5d44df  vmovaps [rsp+0x60], xmm6
000073ef1c5d44e5  vmovaps [rsp+0x70], xmm7
000073ef1c5d44eb  vmovaps [rsp+0x80], xmm8
000073ef1c5d44f4  vmovaps [rsp+0x90], xmm9
000073ef1c5d44fd  vmovaps [rsp+0xA0], xmm10
000073ef1c5d4506  vmovaps [rsp+0xB0], xmm12
000073ef1c5d450f  vmovaps [rsp+0xC0], xmm13
000073ef1c5d4518  vmovaps [rsp+0xD0], xmm14
000073ef1c5d4521  vmovaps [rsp+0xE0], xmm15
000073ef1c5d452a  sub rsp, 0x30
000073ef1c5d452e  movaps [rsp], xmm11
000073ef1c5d4533  movaps [rsp+0x10], xmm7
000073ef1c5d4538  movaps [rsp+0x20], xmm15
000073ef1c5d453e  lea rdi, [rsp]
000073ef1c5d4542  mov esi, 0x00
000073ef1c5d4547  mov rax, 0x56F25E118530
000073ef1c5d4551  call rax
000073ef1c5d4553  movaps xmm11, [rsp]
000073ef1c5d4558  add rsp, 0x30
000073ef1c5d455c  vmovaps xmm0, [rsp]
000073ef1c5d4561  vmovaps xmm1, [rsp+0x10]
000073ef1c5d4567  vmovaps xmm2, [rsp+0x20]
000073ef1c5d456d  vmovaps xmm3, [rsp+0x30]
000073ef1c5d4573  vmovaps xmm4, [rsp+0x40]
000073ef1c5d4579  vmovaps xmm5, [rsp+0x50]
000073ef1c5d457f  vmovaps xmm6, [rsp+0x60]
000073ef1c5d4585  vmovaps xmm7, [rsp+0x70]
000073ef1c5d458b  vmovaps xmm8, [rsp+0x80]
000073ef1c5d4594  vmovaps xmm9, [rsp+0x90]
000073ef1c5d459d  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d45a6  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d45af  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d45b8  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d45c1  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d45ca  add rsp, 0xF0
000073ef1c5d45d1  pop r11
000073ef1c5d45d3  pop r10
000073ef1c5d45d5  pop r9
000073ef1c5d45d7  pop r8
000073ef1c5d45d9  pop rsi
000073ef1c5d45da  pop rdi
000073ef1c5d45db  pop rdx
000073ef1c5d45dc  pop rcx
000073ef1c5d45dd  pop rax
000073ef1c5d45de  add rsp, 0x08
000073ef1c5d45e2  jmp 0x000073EF1C5D0123
000073ef1c5d45e7  sub rsp, 0x08
000073ef1c5d45eb  push rax
000073ef1c5d45ec  push rcx
000073ef1c5d45ed  push rdx
000073ef1c5d45ee  push rdi
000073ef1c5d45ef  push rsi
000073ef1c5d45f0  push r8
000073ef1c5d45f2  push r9
000073ef1c5d45f4  push r10
000073ef1c5d45f6  push r11
000073ef1c5d45f8  sub rsp, 0xF0
000073ef1c5d45ff  vmovaps [rsp], xmm0
000073ef1c5d4604  vmovaps [rsp+0x10], xmm1
000073ef1c5d460a  vmovaps [rsp+0x20], xmm2
000073ef1c5d4610  vmovaps [rsp+0x30], xmm3
000073ef1c5d4616  vmovaps [rsp+0x40], xmm4
000073ef1c5d461c  vmovaps [rsp+0x50], xmm5
000073ef1c5d4622  vmovaps [rsp+0x60], xmm6
000073ef1c5d4628  vmovaps [rsp+0x70], xmm7
000073ef1c5d462e  vmovaps [rsp+0x80], xmm8
000073ef1c5d4637  vmovaps [rsp+0x90], xmm9
000073ef1c5d4640  vmovaps [rsp+0xA0], xmm10
000073ef1c5d4649  vmovaps [rsp+0xB0], xmm11
000073ef1c5d4652  vmovaps [rsp+0xC0], xmm12
000073ef1c5d465b  vmovaps [rsp+0xD0], xmm13
000073ef1c5d4664  vmovaps [rsp+0xE0], xmm14
000073ef1c5d466d  sub rsp, 0x30
000073ef1c5d4671  movaps [rsp], xmm15
000073ef1c5d4676  movaps [rsp+0x10], xmm10
000073ef1c5d467c  movaps [rsp+0x20], xmm13
000073ef1c5d4682  lea rdi, [rsp]
000073ef1c5d4686  mov esi, 0x00
000073ef1c5d468b  mov rax, 0x56F25E118530
000073ef1c5d4695  call rax
000073ef1c5d4697  movaps xmm15, [rsp]
000073ef1c5d469c  add rsp, 0x30
000073ef1c5d46a0  vmovaps xmm0, [rsp]
000073ef1c5d46a5  vmovaps xmm1, [rsp+0x10]
000073ef1c5d46ab  vmovaps xmm2, [rsp+0x20]
000073ef1c5d46b1  vmovaps xmm3, [rsp+0x30]
000073ef1c5d46b7  vmovaps xmm4, [rsp+0x40]
000073ef1c5d46bd  vmovaps xmm5, [rsp+0x50]
000073ef1c5d46c3  vmovaps xmm6, [rsp+0x60]
000073ef1c5d46c9  vmovaps xmm7, [rsp+0x70]
000073ef1c5d46cf  vmovaps xmm8, [rsp+0x80]
000073ef1c5d46d8  vmovaps xmm9, [rsp+0x90]
000073ef1c5d46e1  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d46ea  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d46f3  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d46fc  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d4705  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d470e  add rsp, 0xF0
000073ef1c5d4715  pop r11
000073ef1c5d4717  pop r10
000073ef1c5d4719  pop r9
000073ef1c5d471b  pop r8
000073ef1c5d471d  pop rsi
000073ef1c5d471e  pop rdi
000073ef1c5d471f  pop rdx
000073ef1c5d4720  pop rcx
000073ef1c5d4721  pop rax
000073ef1c5d4722  add rsp, 0x08
000073ef1c5d4726  jmp 0x000073EF1C5D013D
000073ef1c5d472b  sub rsp, 0x08
000073ef1c5d472f  push rax
000073ef1c5d4730  push rcx
000073ef1c5d4731  push rdx
000073ef1c5d4732  push rdi
000073ef1c5d4733  push rsi
000073ef1c5d4734  push r8
000073ef1c5d4736  push r9
000073ef1c5d4738  push r10
000073ef1c5d473a  push r11
000073ef1c5d473c  sub rsp, 0xF0
000073ef1c5d4743  vmovaps [rsp], xmm0
000073ef1c5d4748  vmovaps [rsp+0x10], xmm1
000073ef1c5d474e  vmovaps [rsp+0x20], xmm2
000073ef1c5d4754  vmovaps [rsp+0x30], xmm3
000073ef1c5d475a  vmovaps [rsp+0x40], xmm4
000073ef1c5d4760  vmovaps [rsp+0x50], xmm5
000073ef1c5d4766  vmovaps [rsp+0x60], xmm6
000073ef1c5d476c  vmovaps [rsp+0x70], xmm7
000073ef1c5d4772  vmovaps [rsp+0x80], xmm8
000073ef1c5d477b  vmovaps [rsp+0x90], xmm9
000073ef1c5d4784  vmovaps [rsp+0xA0], xmm11
000073ef1c5d478d  vmovaps [rsp+0xB0], xmm12
000073ef1c5d4796  vmovaps [rsp+0xC0], xmm13
000073ef1c5d479f  vmovaps [rsp+0xD0], xmm14
000073ef1c5d47a8  vmovaps [rsp+0xE0], xmm15
000073ef1c5d47b1  sub rsp, 0x30
000073ef1c5d47b5  movaps [rsp], xmm10
000073ef1c5d47ba  movaps [rsp+0x10], xmm7
000073ef1c5d47bf  movaps [rsp+0x20], xmm13
000073ef1c5d47c5  lea rdi, [rsp]
000073ef1c5d47c9  mov esi, 0x00
000073ef1c5d47ce  mov rax, 0x56F25E118530
000073ef1c5d47d8  call rax
000073ef1c5d47da  movaps xmm10, [rsp]
000073ef1c5d47df  add rsp, 0x30
000073ef1c5d47e3  vmovaps xmm0, [rsp]
000073ef1c5d47e8  vmovaps xmm1, [rsp+0x10]
000073ef1c5d47ee  vmovaps xmm2, [rsp+0x20]
000073ef1c5d47f4  vmovaps xmm3, [rsp+0x30]
000073ef1c5d47fa  vmovaps xmm4, [rsp+0x40]
000073ef1c5d4800  vmovaps xmm5, [rsp+0x50]
000073ef1c5d4806  vmovaps xmm6, [rsp+0x60]
000073ef1c5d480c  vmovaps xmm7, [rsp+0x70]
000073ef1c5d4812  vmovaps xmm8, [rsp+0x80]
000073ef1c5d481b  vmovaps xmm9, [rsp+0x90]
000073ef1c5d4824  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d482d  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d4836  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d483f  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d4848  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d4851  add rsp, 0xF0
000073ef1c5d4858  pop r11
000073ef1c5d485a  pop r10
000073ef1c5d485c  pop r9
000073ef1c5d485e  pop r8
000073ef1c5d4860  pop rsi
000073ef1c5d4861  pop rdi
000073ef1c5d4862  pop rdx
000073ef1c5d4863  pop rcx
000073ef1c5d4864  pop rax
000073ef1c5d4865  add rsp, 0x08
000073ef1c5d4869  jmp 0x000073EF1C5D0169
000073ef1c5d486e  sub rsp, 0x08
000073ef1c5d4872  push rax
000073ef1c5d4873  push rcx
000073ef1c5d4874  push rdx
000073ef1c5d4875  push rdi
000073ef1c5d4876  push rsi
000073ef1c5d4877  push r8
000073ef1c5d4879  push r9
000073ef1c5d487b  push r10
000073ef1c5d487d  push r11
000073ef1c5d487f  sub rsp, 0xF0
000073ef1c5d4886  vmovaps [rsp], xmm0
000073ef1c5d488b  vmovaps [rsp+0x10], xmm1
000073ef1c5d4891  vmovaps [rsp+0x20], xmm2
000073ef1c5d4897  vmovaps [rsp+0x30], xmm3
000073ef1c5d489d  vmovaps [rsp+0x40], xmm4
000073ef1c5d48a3  vmovaps [rsp+0x50], xmm5
000073ef1c5d48a9  vmovaps [rsp+0x60], xmm6
000073ef1c5d48af  vmovaps [rsp+0x70], xmm7
000073ef1c5d48b5  vmovaps [rsp+0x80], xmm8
000073ef1c5d48be  vmovaps [rsp+0x90], xmm9
000073ef1c5d48c7  vmovaps [rsp+0xA0], xmm10
000073ef1c5d48d0  vmovaps [rsp+0xB0], xmm11
000073ef1c5d48d9  vmovaps [rsp+0xC0], xmm12
000073ef1c5d48e2  vmovaps [rsp+0xD0], xmm14
000073ef1c5d48eb  vmovaps [rsp+0xE0], xmm15
000073ef1c5d48f4  sub rsp, 0x30
000073ef1c5d48f8  movaps [rsp], xmm13
000073ef1c5d48fd  movaps [rsp+0x10], xmm1
000073ef1c5d4902  movaps [rsp+0x20], xmm8
000073ef1c5d4908  lea rdi, [rsp]
000073ef1c5d490c  mov esi, 0x00
000073ef1c5d4911  mov rax, 0x56F25E118530
000073ef1c5d491b  call rax
000073ef1c5d491d  movaps xmm13, [rsp]
000073ef1c5d4922  add rsp, 0x30
000073ef1c5d4926  vmovaps xmm0, [rsp]
000073ef1c5d492b  vmovaps xmm1, [rsp+0x10]
000073ef1c5d4931  vmovaps xmm2, [rsp+0x20]
000073ef1c5d4937  vmovaps xmm3, [rsp+0x30]
000073ef1c5d493d  vmovaps xmm4, [rsp+0x40]
000073ef1c5d4943  vmovaps xmm5, [rsp+0x50]
000073ef1c5d4949  vmovaps xmm6, [rsp+0x60]
000073ef1c5d494f  vmovaps xmm7, [rsp+0x70]
000073ef1c5d4955  vmovaps xmm8, [rsp+0x80]
000073ef1c5d495e  vmovaps xmm9, [rsp+0x90]
000073ef1c5d4967  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d4970  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d4979  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d4982  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d498b  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d4994  add rsp, 0xF0
000073ef1c5d499b  pop r11
000073ef1c5d499d  pop r10
000073ef1c5d499f  pop r9
000073ef1c5d49a1  pop r8
000073ef1c5d49a3  pop rsi
000073ef1c5d49a4  pop rdi
000073ef1c5d49a5  pop rdx
000073ef1c5d49a6  pop rcx
000073ef1c5d49a7  pop rax
000073ef1c5d49a8  add rsp, 0x08
000073ef1c5d49ac  jmp 0x000073EF1C5D0183
000073ef1c5d49b1  call 0x000073EF1C3FF430
000073ef1c5d49b6  jmp 0x000073EF1C5D018D
000073ef1c5d49bb  sub rsp, 0x08
000073ef1c5d49bf  push rax
000073ef1c5d49c0  push rcx
000073ef1c5d49c1  push rdx
000073ef1c5d49c2  push rdi
000073ef1c5d49c3  push rsi
000073ef1c5d49c4  push r8
000073ef1c5d49c6  push r9
000073ef1c5d49c8  push r10
000073ef1c5d49ca  push r11
000073ef1c5d49cc  sub rsp, 0xF0
000073ef1c5d49d3  vmovaps [rsp], xmm0
000073ef1c5d49d8  vmovaps [rsp+0x10], xmm1
000073ef1c5d49de  vmovaps [rsp+0x20], xmm2
000073ef1c5d49e4  vmovaps [rsp+0x30], xmm3
000073ef1c5d49ea  vmovaps [rsp+0x40], xmm4
000073ef1c5d49f0  vmovaps [rsp+0x50], xmm5
000073ef1c5d49f6  vmovaps [rsp+0x60], xmm6
000073ef1c5d49fc  vmovaps [rsp+0x70], xmm7
000073ef1c5d4a02  vmovaps [rsp+0x80], xmm9
000073ef1c5d4a0b  vmovaps [rsp+0x90], xmm10
000073ef1c5d4a14  vmovaps [rsp+0xA0], xmm11
000073ef1c5d4a1d  vmovaps [rsp+0xB0], xmm12
000073ef1c5d4a26  vmovaps [rsp+0xC0], xmm13
000073ef1c5d4a2f  vmovaps [rsp+0xD0], xmm14
000073ef1c5d4a38  vmovaps [rsp+0xE0], xmm15
000073ef1c5d4a41  sub rsp, 0x30
000073ef1c5d4a45  movaps [rsp], xmm8
000073ef1c5d4a4a  movaps [rsp+0x10], xmm14
000073ef1c5d4a50  movaps [rsp+0x20], xmm9
000073ef1c5d4a56  lea rdi, [rsp]
000073ef1c5d4a5a  mov esi, 0x00
000073ef1c5d4a5f  mov rax, 0x56F25E118530
000073ef1c5d4a69  call rax
000073ef1c5d4a6b  movaps xmm8, [rsp]
000073ef1c5d4a70  add rsp, 0x30
000073ef1c5d4a74  vmovaps xmm0, [rsp]
000073ef1c5d4a79  vmovaps xmm1, [rsp+0x10]
000073ef1c5d4a7f  vmovaps xmm2, [rsp+0x20]
000073ef1c5d4a85  vmovaps xmm3, [rsp+0x30]
000073ef1c5d4a8b  vmovaps xmm4, [rsp+0x40]
000073ef1c5d4a91  vmovaps xmm5, [rsp+0x50]
000073ef1c5d4a97  vmovaps xmm6, [rsp+0x60]
000073ef1c5d4a9d  vmovaps xmm7, [rsp+0x70]
000073ef1c5d4aa3  vmovaps xmm9, [rsp+0x80]
000073ef1c5d4aac  vmovaps xmm10, [rsp+0x90]
000073ef1c5d4ab5  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d4abe  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d4ac7  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d4ad0  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d4ad9  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d4ae2  add rsp, 0xF0
000073ef1c5d4ae9  pop r11
000073ef1c5d4aeb  pop r10
000073ef1c5d4aed  pop r9
000073ef1c5d4aef  pop r8
000073ef1c5d4af1  pop rsi
000073ef1c5d4af2  pop rdi
000073ef1c5d4af3  pop rdx
000073ef1c5d4af4  pop rcx
000073ef1c5d4af5  pop rax
000073ef1c5d4af6  add rsp, 0x08
000073ef1c5d4afa  jmp 0x000073EF1C5D01AF
000073ef1c5d4aff  sub rsp, 0x08
000073ef1c5d4b03  push rax
000073ef1c5d4b04  push rcx
000073ef1c5d4b05  push rdx
000073ef1c5d4b06  push rdi
000073ef1c5d4b07  push rsi
000073ef1c5d4b08  push r8
000073ef1c5d4b0a  push r9
000073ef1c5d4b0c  push r10
000073ef1c5d4b0e  push r11
000073ef1c5d4b10  sub rsp, 0xF0
000073ef1c5d4b17  vmovaps [rsp], xmm0
000073ef1c5d4b1c  vmovaps [rsp+0x10], xmm1
000073ef1c5d4b22  vmovaps [rsp+0x20], xmm2
000073ef1c5d4b28  vmovaps [rsp+0x30], xmm3
000073ef1c5d4b2e  vmovaps [rsp+0x40], xmm4
000073ef1c5d4b34  vmovaps [rsp+0x50], xmm5
000073ef1c5d4b3a  vmovaps [rsp+0x60], xmm6
000073ef1c5d4b40  vmovaps [rsp+0x70], xmm7
000073ef1c5d4b46  vmovaps [rsp+0x80], xmm8
000073ef1c5d4b4f  vmovaps [rsp+0x90], xmm10
000073ef1c5d4b58  vmovaps [rsp+0xA0], xmm11
000073ef1c5d4b61  vmovaps [rsp+0xB0], xmm12
000073ef1c5d4b6a  vmovaps [rsp+0xC0], xmm13
000073ef1c5d4b73  vmovaps [rsp+0xD0], xmm14
000073ef1c5d4b7c  vmovaps [rsp+0xE0], xmm15
000073ef1c5d4b85  sub rsp, 0x30
000073ef1c5d4b89  movaps [rsp], xmm9
000073ef1c5d4b8e  movaps [rsp+0x10], xmm1
000073ef1c5d4b93  movaps [rsp+0x20], xmm14
000073ef1c5d4b99  lea rdi, [rsp]
000073ef1c5d4b9d  mov esi, 0x00
000073ef1c5d4ba2  mov rax, 0x56F25E118530
000073ef1c5d4bac  call rax
000073ef1c5d4bae  movaps xmm9, [rsp]
000073ef1c5d4bb3  add rsp, 0x30
000073ef1c5d4bb7  vmovaps xmm0, [rsp]
000073ef1c5d4bbc  vmovaps xmm1, [rsp+0x10]
000073ef1c5d4bc2  vmovaps xmm2, [rsp+0x20]
000073ef1c5d4bc8  vmovaps xmm3, [rsp+0x30]
000073ef1c5d4bce  vmovaps xmm4, [rsp+0x40]
000073ef1c5d4bd4  vmovaps xmm5, [rsp+0x50]
000073ef1c5d4bda  vmovaps xmm6, [rsp+0x60]
000073ef1c5d4be0  vmovaps xmm7, [rsp+0x70]
000073ef1c5d4be6  vmovaps xmm8, [rsp+0x80]
000073ef1c5d4bef  vmovaps xmm10, [rsp+0x90]
000073ef1c5d4bf8  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d4c01  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d4c0a  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d4c13  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d4c1c  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d4c25  add rsp, 0xF0
000073ef1c5d4c2c  pop r11
000073ef1c5d4c2e  pop r10
000073ef1c5d4c30  pop r9
000073ef1c5d4c32  pop r8
000073ef1c5d4c34  pop rsi
000073ef1c5d4c35  pop rdi
000073ef1c5d4c36  pop rdx
000073ef1c5d4c37  pop rcx
000073ef1c5d4c38  pop rax
000073ef1c5d4c39  add rsp, 0x08
000073ef1c5d4c3d  jmp 0x000073EF1C5D01DD
000073ef1c5d4c42  sub rsp, 0x08
000073ef1c5d4c46  push rax
000073ef1c5d4c47  push rcx
000073ef1c5d4c48  push rdx
000073ef1c5d4c49  push rdi
000073ef1c5d4c4a  push rsi
000073ef1c5d4c4b  push r8
000073ef1c5d4c4d  push r9
000073ef1c5d4c4f  push r10
000073ef1c5d4c51  push r11
000073ef1c5d4c53  sub rsp, 0xF0
000073ef1c5d4c5a  vmovaps [rsp], xmm0
000073ef1c5d4c5f  vmovaps [rsp+0x10], xmm1
000073ef1c5d4c65  vmovaps [rsp+0x20], xmm2
000073ef1c5d4c6b  vmovaps [rsp+0x30], xmm3
000073ef1c5d4c71  vmovaps [rsp+0x40], xmm4
000073ef1c5d4c77  vmovaps [rsp+0x50], xmm5
000073ef1c5d4c7d  vmovaps [rsp+0x60], xmm6
000073ef1c5d4c83  vmovaps [rsp+0x70], xmm7
000073ef1c5d4c89  vmovaps [rsp+0x80], xmm8
000073ef1c5d4c92  vmovaps [rsp+0x90], xmm9
000073ef1c5d4c9b  vmovaps [rsp+0xA0], xmm10
000073ef1c5d4ca4  vmovaps [rsp+0xB0], xmm11
000073ef1c5d4cad  vmovaps [rsp+0xC0], xmm12
000073ef1c5d4cb6  vmovaps [rsp+0xD0], xmm13
000073ef1c5d4cbf  vmovaps [rsp+0xE0], xmm15
000073ef1c5d4cc8  sub rsp, 0x30
000073ef1c5d4ccc  movaps [rsp], xmm14
000073ef1c5d4cd1  movaps [rsp+0x10], xmm4
000073ef1c5d4cd6  movaps [rsp+0x20], xmm1
000073ef1c5d4cdb  lea rdi, [rsp]
000073ef1c5d4cdf  mov esi, 0x00
000073ef1c5d4ce4  mov rax, 0x56F25E118530
000073ef1c5d4cee  call rax
000073ef1c5d4cf0  movaps xmm14, [rsp]
000073ef1c5d4cf5  add rsp, 0x30
000073ef1c5d4cf9  vmovaps xmm0, [rsp]
000073ef1c5d4cfe  vmovaps xmm1, [rsp+0x10]
000073ef1c5d4d04  vmovaps xmm2, [rsp+0x20]
000073ef1c5d4d0a  vmovaps xmm3, [rsp+0x30]
000073ef1c5d4d10  vmovaps xmm4, [rsp+0x40]
000073ef1c5d4d16  vmovaps xmm5, [rsp+0x50]
000073ef1c5d4d1c  vmovaps xmm6, [rsp+0x60]
000073ef1c5d4d22  vmovaps xmm7, [rsp+0x70]
000073ef1c5d4d28  vmovaps xmm8, [rsp+0x80]
000073ef1c5d4d31  vmovaps xmm9, [rsp+0x90]
000073ef1c5d4d3a  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d4d43  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d4d4c  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d4d55  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d4d5e  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d4d67  add rsp, 0xF0
000073ef1c5d4d6e  pop r11
000073ef1c5d4d70  pop r10
000073ef1c5d4d72  pop r9
000073ef1c5d4d74  pop r8
000073ef1c5d4d76  pop rsi
000073ef1c5d4d77  pop rdi
000073ef1c5d4d78  pop rdx
000073ef1c5d4d79  pop rcx
000073ef1c5d4d7a  pop rax
000073ef1c5d4d7b  add rsp, 0x08
000073ef1c5d4d7f  jmp 0x000073EF1C5D0203
000073ef1c5d4d84  sub rsp, 0x08
000073ef1c5d4d88  push rax
000073ef1c5d4d89  push rcx
000073ef1c5d4d8a  push rdx
000073ef1c5d4d8b  push rdi
000073ef1c5d4d8c  push rsi
000073ef1c5d4d8d  push r8
000073ef1c5d4d8f  push r9
000073ef1c5d4d91  push r10
000073ef1c5d4d93  push r11
000073ef1c5d4d95  sub rsp, 0xF0
000073ef1c5d4d9c  vmovaps [rsp], xmm0
000073ef1c5d4da1  vmovaps [rsp+0x10], xmm2
000073ef1c5d4da7  vmovaps [rsp+0x20], xmm3
000073ef1c5d4dad  vmovaps [rsp+0x30], xmm4
000073ef1c5d4db3  vmovaps [rsp+0x40], xmm5
000073ef1c5d4db9  vmovaps [rsp+0x50], xmm6
000073ef1c5d4dbf  vmovaps [rsp+0x60], xmm7
000073ef1c5d4dc5  vmovaps [rsp+0x70], xmm8
000073ef1c5d4dcb  vmovaps [rsp+0x80], xmm9
000073ef1c5d4dd4  vmovaps [rsp+0x90], xmm10
000073ef1c5d4ddd  vmovaps [rsp+0xA0], xmm11
000073ef1c5d4de6  vmovaps [rsp+0xB0], xmm12
000073ef1c5d4def  vmovaps [rsp+0xC0], xmm13
000073ef1c5d4df8  vmovaps [rsp+0xD0], xmm14
000073ef1c5d4e01  vmovaps [rsp+0xE0], xmm15
000073ef1c5d4e0a  sub rsp, 0x30
000073ef1c5d4e0e  movaps [rsp], xmm1
000073ef1c5d4e12  movaps [rsp+0x10], xmm12
000073ef1c5d4e18  movaps [rsp+0x20], xmm11
000073ef1c5d4e1e  lea rdi, [rsp]
000073ef1c5d4e22  mov esi, 0x00
000073ef1c5d4e27  mov rax, 0x56F25E118530
000073ef1c5d4e31  call rax
000073ef1c5d4e33  movaps xmm1, [rsp]
000073ef1c5d4e37  add rsp, 0x30
000073ef1c5d4e3b  vmovaps xmm0, [rsp]
000073ef1c5d4e40  vmovaps xmm2, [rsp+0x10]
000073ef1c5d4e46  vmovaps xmm3, [rsp+0x20]
000073ef1c5d4e4c  vmovaps xmm4, [rsp+0x30]
000073ef1c5d4e52  vmovaps xmm5, [rsp+0x40]
000073ef1c5d4e58  vmovaps xmm6, [rsp+0x50]
000073ef1c5d4e5e  vmovaps xmm7, [rsp+0x60]
000073ef1c5d4e64  vmovaps xmm8, [rsp+0x70]
000073ef1c5d4e6a  vmovaps xmm9, [rsp+0x80]
000073ef1c5d4e73  vmovaps xmm10, [rsp+0x90]
000073ef1c5d4e7c  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d4e85  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d4e8e  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d4e97  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d4ea0  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d4ea9  add rsp, 0xF0
000073ef1c5d4eb0  pop r11
000073ef1c5d4eb2  pop r10
000073ef1c5d4eb4  pop r9
000073ef1c5d4eb6  pop r8
000073ef1c5d4eb8  pop rsi
000073ef1c5d4eb9  pop rdi
000073ef1c5d4eba  pop rdx
000073ef1c5d4ebb  pop rcx
000073ef1c5d4ebc  pop rax
000073ef1c5d4ebd  add rsp, 0x08
000073ef1c5d4ec1  jmp 0x000073EF1C5D0224
000073ef1c5d4ec6  call 0x000073EF1C4E20A0
000073ef1c5d4ecb  jmp 0x000073EF1C5D0232
000073ef1c5d4ed0  call 0x000073EF1C409D70
000073ef1c5d4ed5  jmp 0x000073EF1C5D023C
000073ef1c5d4eda  sub rsp, 0x08
000073ef1c5d4ede  push rax
000073ef1c5d4edf  push rcx
000073ef1c5d4ee0  push rdx
000073ef1c5d4ee1  push rdi
000073ef1c5d4ee2  push rsi
000073ef1c5d4ee3  push r8
000073ef1c5d4ee5  push r9
000073ef1c5d4ee7  push r10
000073ef1c5d4ee9  push r11
000073ef1c5d4eeb  sub rsp, 0xF0
000073ef1c5d4ef2  vmovaps [rsp], xmm0
000073ef1c5d4ef7  vmovaps [rsp+0x10], xmm1
000073ef1c5d4efd  vmovaps [rsp+0x20], xmm2
000073ef1c5d4f03  vmovaps [rsp+0x30], xmm3
000073ef1c5d4f09  vmovaps [rsp+0x40], xmm4
000073ef1c5d4f0f  vmovaps [rsp+0x50], xmm5
000073ef1c5d4f15  vmovaps [rsp+0x60], xmm6
000073ef1c5d4f1b  vmovaps [rsp+0x70], xmm8
000073ef1c5d4f21  vmovaps [rsp+0x80], xmm9
000073ef1c5d4f2a  vmovaps [rsp+0x90], xmm10
000073ef1c5d4f33  vmovaps [rsp+0xA0], xmm11
000073ef1c5d4f3c  vmovaps [rsp+0xB0], xmm12
000073ef1c5d4f45  vmovaps [rsp+0xC0], xmm13
000073ef1c5d4f4e  vmovaps [rsp+0xD0], xmm14
000073ef1c5d4f57  vmovaps [rsp+0xE0], xmm15
000073ef1c5d4f60  sub rsp, 0x30
000073ef1c5d4f64  movaps [rsp], xmm7
000073ef1c5d4f68  movaps [rsp+0x10], xmm15
000073ef1c5d4f6e  movaps [rsp+0x20], xmm10
000073ef1c5d4f74  lea rdi, [rsp]
000073ef1c5d4f78  mov esi, 0x00
000073ef1c5d4f7d  mov rax, 0x56F25E118530
000073ef1c5d4f87  call rax
000073ef1c5d4f89  movaps xmm7, [rsp]
000073ef1c5d4f8d  add rsp, 0x30
000073ef1c5d4f91  vmovaps xmm0, [rsp]
000073ef1c5d4f96  vmovaps xmm1, [rsp+0x10]
000073ef1c5d4f9c  vmovaps xmm2, [rsp+0x20]
000073ef1c5d4fa2  vmovaps xmm3, [rsp+0x30]
000073ef1c5d4fa8  vmovaps xmm4, [rsp+0x40]
000073ef1c5d4fae  vmovaps xmm5, [rsp+0x50]
000073ef1c5d4fb4  vmovaps xmm6, [rsp+0x60]
000073ef1c5d4fba  vmovaps xmm8, [rsp+0x70]
000073ef1c5d4fc0  vmovaps xmm9, [rsp+0x80]
000073ef1c5d4fc9  vmovaps xmm10, [rsp+0x90]
000073ef1c5d4fd2  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d4fdb  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d4fe4  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d4fed  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d4ff6  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d4fff  add rsp, 0xF0
000073ef1c5d5006  pop r11
000073ef1c5d5008  pop r10
000073ef1c5d500a  pop r9
000073ef1c5d500c  pop r8
000073ef1c5d500e  pop rsi
000073ef1c5d500f  pop rdi
000073ef1c5d5010  pop rdx
000073ef1c5d5011  pop rcx
000073ef1c5d5012  pop rax
000073ef1c5d5013  add rsp, 0x08
000073ef1c5d5017  jmp 0x000073EF1C5D025D
000073ef1c5d501c  sub rsp, 0x08
000073ef1c5d5020  push rax
000073ef1c5d5021  push rcx
000073ef1c5d5022  push rdx
000073ef1c5d5023  push rdi
000073ef1c5d5024  push rsi
000073ef1c5d5025  push r8
000073ef1c5d5027  push r9
000073ef1c5d5029  push r10
000073ef1c5d502b  push r11
000073ef1c5d502d  sub rsp, 0xF0
000073ef1c5d5034  vmovaps [rsp], xmm0
000073ef1c5d5039  vmovaps [rsp+0x10], xmm1
000073ef1c5d503f  vmovaps [rsp+0x20], xmm2
000073ef1c5d5045  vmovaps [rsp+0x30], xmm3
000073ef1c5d504b  vmovaps [rsp+0x40], xmm4
000073ef1c5d5051  vmovaps [rsp+0x50], xmm5
000073ef1c5d5057  vmovaps [rsp+0x60], xmm6
000073ef1c5d505d  vmovaps [rsp+0x70], xmm7
000073ef1c5d5063  vmovaps [rsp+0x80], xmm8
000073ef1c5d506c  vmovaps [rsp+0x90], xmm9
000073ef1c5d5075  vmovaps [rsp+0xA0], xmm11
000073ef1c5d507e  vmovaps [rsp+0xB0], xmm12
000073ef1c5d5087  vmovaps [rsp+0xC0], xmm13
000073ef1c5d5090  vmovaps [rsp+0xD0], xmm14
000073ef1c5d5099  vmovaps [rsp+0xE0], xmm15
000073ef1c5d50a2  sub rsp, 0x30
000073ef1c5d50a6  movaps [rsp], xmm10
000073ef1c5d50ab  movaps [rsp+0x10], xmm11
000073ef1c5d50b1  movaps [rsp+0x20], xmm15
000073ef1c5d50b7  lea rdi, [rsp]
000073ef1c5d50bb  mov esi, 0x00
000073ef1c5d50c0  mov rax, 0x56F25E118530
000073ef1c5d50ca  call rax
000073ef1c5d50cc  movaps xmm10, [rsp]
000073ef1c5d50d1  add rsp, 0x30
000073ef1c5d50d5  vmovaps xmm0, [rsp]
000073ef1c5d50da  vmovaps xmm1, [rsp+0x10]
000073ef1c5d50e0  vmovaps xmm2, [rsp+0x20]
000073ef1c5d50e6  vmovaps xmm3, [rsp+0x30]
000073ef1c5d50ec  vmovaps xmm4, [rsp+0x40]
000073ef1c5d50f2  vmovaps xmm5, [rsp+0x50]
000073ef1c5d50f8  vmovaps xmm6, [rsp+0x60]
000073ef1c5d50fe  vmovaps xmm7, [rsp+0x70]
000073ef1c5d5104  vmovaps xmm8, [rsp+0x80]
000073ef1c5d510d  vmovaps xmm9, [rsp+0x90]
000073ef1c5d5116  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d511f  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d5128  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d5131  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d513a  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d5143  add rsp, 0xF0
000073ef1c5d514a  pop r11
000073ef1c5d514c  pop r10
000073ef1c5d514e  pop r9
000073ef1c5d5150  pop r8
000073ef1c5d5152  pop rsi
000073ef1c5d5153  pop rdi
000073ef1c5d5154  pop rdx
000073ef1c5d5155  pop rcx
000073ef1c5d5156  pop rax
000073ef1c5d5157  add rsp, 0x08
000073ef1c5d515b  jmp 0x000073EF1C5D028B
000073ef1c5d5160  sub rsp, 0x08
000073ef1c5d5164  push rax
000073ef1c5d5165  push rcx
000073ef1c5d5166  push rdx
000073ef1c5d5167  push rdi
000073ef1c5d5168  push rsi
000073ef1c5d5169  push r8
000073ef1c5d516b  push r9
000073ef1c5d516d  push r10
000073ef1c5d516f  push r11
000073ef1c5d5171  sub rsp, 0xF0
000073ef1c5d5178  vmovaps [rsp], xmm0
000073ef1c5d517d  vmovaps [rsp+0x10], xmm1
000073ef1c5d5183  vmovaps [rsp+0x20], xmm2
000073ef1c5d5189  vmovaps [rsp+0x30], xmm3
000073ef1c5d518f  vmovaps [rsp+0x40], xmm4
000073ef1c5d5195  vmovaps [rsp+0x50], xmm5
000073ef1c5d519b  vmovaps [rsp+0x60], xmm6
000073ef1c5d51a1  vmovaps [rsp+0x70], xmm7
000073ef1c5d51a7  vmovaps [rsp+0x80], xmm8
000073ef1c5d51b0  vmovaps [rsp+0x90], xmm9
000073ef1c5d51b9  vmovaps [rsp+0xA0], xmm10
000073ef1c5d51c2  vmovaps [rsp+0xB0], xmm12
000073ef1c5d51cb  vmovaps [rsp+0xC0], xmm13
000073ef1c5d51d4  vmovaps [rsp+0xD0], xmm14
000073ef1c5d51dd  vmovaps [rsp+0xE0], xmm15
000073ef1c5d51e6  sub rsp, 0x30
000073ef1c5d51ea  movaps [rsp], xmm11
000073ef1c5d51ef  movaps [rsp+0x10], xmm12
000073ef1c5d51f5  movaps [rsp+0x20], xmm15
000073ef1c5d51fb  lea rdi, [rsp]
000073ef1c5d51ff  mov esi, 0x00
000073ef1c5d5204  mov rax, 0x56F25E118530
000073ef1c5d520e  call rax
000073ef1c5d5210  movaps xmm11, [rsp]
000073ef1c5d5215  add rsp, 0x30
000073ef1c5d5219  vmovaps xmm0, [rsp]
000073ef1c5d521e  vmovaps xmm1, [rsp+0x10]
000073ef1c5d5224  vmovaps xmm2, [rsp+0x20]
000073ef1c5d522a  vmovaps xmm3, [rsp+0x30]
000073ef1c5d5230  vmovaps xmm4, [rsp+0x40]
000073ef1c5d5236  vmovaps xmm5, [rsp+0x50]
000073ef1c5d523c  vmovaps xmm6, [rsp+0x60]
000073ef1c5d5242  vmovaps xmm7, [rsp+0x70]
000073ef1c5d5248  vmovaps xmm8, [rsp+0x80]
000073ef1c5d5251  vmovaps xmm9, [rsp+0x90]
000073ef1c5d525a  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d5263  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d526c  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d5275  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d527e  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d5287  add rsp, 0xF0
000073ef1c5d528e  pop r11
000073ef1c5d5290  pop r10
000073ef1c5d5292  pop r9
000073ef1c5d5294  pop r8
000073ef1c5d5296  pop rsi
000073ef1c5d5297  pop rdi
000073ef1c5d5298  pop rdx
000073ef1c5d5299  pop rcx
000073ef1c5d529a  pop rax
000073ef1c5d529b  add rsp, 0x08
000073ef1c5d529f  jmp 0x000073EF1C5D02B9
000073ef1c5d52a4  sub rsp, 0x08
000073ef1c5d52a8  push rax
000073ef1c5d52a9  push rcx
000073ef1c5d52aa  push rdx
000073ef1c5d52ab  push rdi
000073ef1c5d52ac  push rsi
000073ef1c5d52ad  push r8
000073ef1c5d52af  push r9
000073ef1c5d52b1  push r10
000073ef1c5d52b3  push r11
000073ef1c5d52b5  sub rsp, 0xF0
000073ef1c5d52bc  vmovaps [rsp], xmm0
000073ef1c5d52c1  vmovaps [rsp+0x10], xmm1
000073ef1c5d52c7  vmovaps [rsp+0x20], xmm2
000073ef1c5d52cd  vmovaps [rsp+0x30], xmm3
000073ef1c5d52d3  vmovaps [rsp+0x40], xmm4
000073ef1c5d52d9  vmovaps [rsp+0x50], xmm5
000073ef1c5d52df  vmovaps [rsp+0x60], xmm6
000073ef1c5d52e5  vmovaps [rsp+0x70], xmm7
000073ef1c5d52eb  vmovaps [rsp+0x80], xmm8
000073ef1c5d52f4  vmovaps [rsp+0x90], xmm9
000073ef1c5d52fd  vmovaps [rsp+0xA0], xmm10
000073ef1c5d5306  vmovaps [rsp+0xB0], xmm11
000073ef1c5d530f  vmovaps [rsp+0xC0], xmm12
000073ef1c5d5318  vmovaps [rsp+0xD0], xmm13
000073ef1c5d5321  vmovaps [rsp+0xE0], xmm14
000073ef1c5d532a  sub rsp, 0x30
000073ef1c5d532e  movaps [rsp], xmm15
000073ef1c5d5333  movaps [rsp+0x10], xmm13
000073ef1c5d5339  movaps [rsp+0x20], xmm9
000073ef1c5d533f  lea rdi, [rsp]
000073ef1c5d5343  mov esi, 0x00
000073ef1c5d5348  mov rax, 0x56F25E118530
000073ef1c5d5352  call rax
000073ef1c5d5354  movaps xmm15, [rsp]
000073ef1c5d5359  add rsp, 0x30
000073ef1c5d535d  vmovaps xmm0, [rsp]
000073ef1c5d5362  vmovaps xmm1, [rsp+0x10]
000073ef1c5d5368  vmovaps xmm2, [rsp+0x20]
000073ef1c5d536e  vmovaps xmm3, [rsp+0x30]
000073ef1c5d5374  vmovaps xmm4, [rsp+0x40]
000073ef1c5d537a  vmovaps xmm5, [rsp+0x50]
000073ef1c5d5380  vmovaps xmm6, [rsp+0x60]
000073ef1c5d5386  vmovaps xmm7, [rsp+0x70]
000073ef1c5d538c  vmovaps xmm8, [rsp+0x80]
000073ef1c5d5395  vmovaps xmm9, [rsp+0x90]
000073ef1c5d539e  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d53a7  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d53b0  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d53b9  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d53c2  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d53cb  add rsp, 0xF0
000073ef1c5d53d2  pop r11
000073ef1c5d53d4  pop r10
000073ef1c5d53d6  pop r9
000073ef1c5d53d8  pop r8
000073ef1c5d53da  pop rsi
000073ef1c5d53db  pop rdi
000073ef1c5d53dc  pop rdx
000073ef1c5d53dd  pop rcx
000073ef1c5d53de  pop rax
000073ef1c5d53df  add rsp, 0x08
000073ef1c5d53e3  jmp 0x000073EF1C5D02D4
000073ef1c5d53e8  sub rsp, 0x08
000073ef1c5d53ec  push rax
000073ef1c5d53ed  push rcx
000073ef1c5d53ee  push rdx
000073ef1c5d53ef  push rdi
000073ef1c5d53f0  push rsi
000073ef1c5d53f1  push r8
000073ef1c5d53f3  push r9
000073ef1c5d53f5  push r10
000073ef1c5d53f7  push r11
000073ef1c5d53f9  sub rsp, 0xF0
000073ef1c5d5400  vmovaps [rsp], xmm0
000073ef1c5d5405  vmovaps [rsp+0x10], xmm1
000073ef1c5d540b  vmovaps [rsp+0x20], xmm2
000073ef1c5d5411  vmovaps [rsp+0x30], xmm3
000073ef1c5d5417  vmovaps [rsp+0x40], xmm4
000073ef1c5d541d  vmovaps [rsp+0x50], xmm5
000073ef1c5d5423  vmovaps [rsp+0x60], xmm6
000073ef1c5d5429  vmovaps [rsp+0x70], xmm7
000073ef1c5d542f  vmovaps [rsp+0x80], xmm8
000073ef1c5d5438  vmovaps [rsp+0x90], xmm9
000073ef1c5d5441  vmovaps [rsp+0xA0], xmm10
000073ef1c5d544a  vmovaps [rsp+0xB0], xmm11
000073ef1c5d5453  vmovaps [rsp+0xC0], xmm12
000073ef1c5d545c  vmovaps [rsp+0xD0], xmm14
000073ef1c5d5465  vmovaps [rsp+0xE0], xmm15
000073ef1c5d546e  sub rsp, 0x30
000073ef1c5d5472  movaps [rsp], xmm13
000073ef1c5d5477  movaps [rsp+0x10], xmm8
000073ef1c5d547d  movaps [rsp+0x20], xmm14
000073ef1c5d5483  lea rdi, [rsp]
000073ef1c5d5487  mov esi, 0x00
000073ef1c5d548c  mov rax, 0x56F25E118530
000073ef1c5d5496  call rax
000073ef1c5d5498  movaps xmm13, [rsp]
000073ef1c5d549d  add rsp, 0x30
000073ef1c5d54a1  vmovaps xmm0, [rsp]
000073ef1c5d54a6  vmovaps xmm1, [rsp+0x10]
000073ef1c5d54ac  vmovaps xmm2, [rsp+0x20]
000073ef1c5d54b2  vmovaps xmm3, [rsp+0x30]
000073ef1c5d54b8  vmovaps xmm4, [rsp+0x40]
000073ef1c5d54be  vmovaps xmm5, [rsp+0x50]
000073ef1c5d54c4  vmovaps xmm6, [rsp+0x60]
000073ef1c5d54ca  vmovaps xmm7, [rsp+0x70]
000073ef1c5d54d0  vmovaps xmm8, [rsp+0x80]
000073ef1c5d54d9  vmovaps xmm9, [rsp+0x90]
000073ef1c5d54e2  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d54eb  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d54f4  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d54fd  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d5506  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d550f  add rsp, 0xF0
000073ef1c5d5516  pop r11
000073ef1c5d5518  pop r10
000073ef1c5d551a  pop r9
000073ef1c5d551c  pop r8
000073ef1c5d551e  pop rsi
000073ef1c5d551f  pop rdi
000073ef1c5d5520  pop rdx
000073ef1c5d5521  pop rcx
000073ef1c5d5522  pop rax
000073ef1c5d5523  add rsp, 0x08
000073ef1c5d5527  jmp 0x000073EF1C5D02F7
000073ef1c5d552c  sub rsp, 0x08
000073ef1c5d5530  push rax
000073ef1c5d5531  push rcx
000073ef1c5d5532  push rdx
000073ef1c5d5533  push rdi
000073ef1c5d5534  push rsi
000073ef1c5d5535  push r8
000073ef1c5d5537  push r9
000073ef1c5d5539  push r10
000073ef1c5d553b  push r11
000073ef1c5d553d  sub rsp, 0xF0
000073ef1c5d5544  vmovaps [rsp], xmm0
000073ef1c5d5549  vmovaps [rsp+0x10], xmm1
000073ef1c5d554f  vmovaps [rsp+0x20], xmm2
000073ef1c5d5555  vmovaps [rsp+0x30], xmm3
000073ef1c5d555b  vmovaps [rsp+0x40], xmm4
000073ef1c5d5561  vmovaps [rsp+0x50], xmm5
000073ef1c5d5567  vmovaps [rsp+0x60], xmm6
000073ef1c5d556d  vmovaps [rsp+0x70], xmm7
000073ef1c5d5573  vmovaps [rsp+0x80], xmm8
000073ef1c5d557c  vmovaps [rsp+0x90], xmm9
000073ef1c5d5585  vmovaps [rsp+0xA0], xmm10
000073ef1c5d558e  vmovaps [rsp+0xB0], xmm11
000073ef1c5d5597  vmovaps [rsp+0xC0], xmm12
000073ef1c5d55a0  vmovaps [rsp+0xD0], xmm13
000073ef1c5d55a9  vmovaps [rsp+0xE0], xmm15
000073ef1c5d55b2  sub rsp, 0x30
000073ef1c5d55b6  movaps [rsp], xmm14
000073ef1c5d55bb  movaps [rsp+0x10], xmm1
000073ef1c5d55c0  movaps [rsp+0x20], xmm10
000073ef1c5d55c6  lea rdi, [rsp]
000073ef1c5d55ca  mov esi, 0x00
000073ef1c5d55cf  mov rax, 0x56F25E118530
000073ef1c5d55d9  call rax
000073ef1c5d55db  movaps xmm14, [rsp]
000073ef1c5d55e0  add rsp, 0x30
000073ef1c5d55e4  vmovaps xmm0, [rsp]
000073ef1c5d55e9  vmovaps xmm1, [rsp+0x10]
000073ef1c5d55ef  vmovaps xmm2, [rsp+0x20]
000073ef1c5d55f5  vmovaps xmm3, [rsp+0x30]
000073ef1c5d55fb  vmovaps xmm4, [rsp+0x40]
000073ef1c5d5601  vmovaps xmm5, [rsp+0x50]
000073ef1c5d5607  vmovaps xmm6, [rsp+0x60]
000073ef1c5d560d  vmovaps xmm7, [rsp+0x70]
000073ef1c5d5613  vmovaps xmm8, [rsp+0x80]
000073ef1c5d561c  vmovaps xmm9, [rsp+0x90]
000073ef1c5d5625  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d562e  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d5637  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d5640  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d5649  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d5652  add rsp, 0xF0
000073ef1c5d5659  pop r11
000073ef1c5d565b  pop r10
000073ef1c5d565d  pop r9
000073ef1c5d565f  pop r8
000073ef1c5d5661  pop rsi
000073ef1c5d5662  pop rdi
000073ef1c5d5663  pop rdx
000073ef1c5d5664  pop rcx
000073ef1c5d5665  pop rax
000073ef1c5d5666  add rsp, 0x08
000073ef1c5d566a  jmp 0x000073EF1C5D031A
000073ef1c5d566f  sub rsp, 0x08
000073ef1c5d5673  push rax
000073ef1c5d5674  push rcx
000073ef1c5d5675  push rdx
000073ef1c5d5676  push rdi
000073ef1c5d5677  push rsi
000073ef1c5d5678  push r8
000073ef1c5d567a  push r9
000073ef1c5d567c  push r10
000073ef1c5d567e  push r11
000073ef1c5d5680  sub rsp, 0xF0
000073ef1c5d5687  vmovaps [rsp], xmm0
000073ef1c5d568c  vmovaps [rsp+0x10], xmm2
000073ef1c5d5692  vmovaps [rsp+0x20], xmm3
000073ef1c5d5698  vmovaps [rsp+0x30], xmm4
000073ef1c5d569e  vmovaps [rsp+0x40], xmm5
000073ef1c5d56a4  vmovaps [rsp+0x50], xmm6
000073ef1c5d56aa  vmovaps [rsp+0x60], xmm7
000073ef1c5d56b0  vmovaps [rsp+0x70], xmm8
000073ef1c5d56b6  vmovaps [rsp+0x80], xmm9
000073ef1c5d56bf  vmovaps [rsp+0x90], xmm10
000073ef1c5d56c8  vmovaps [rsp+0xA0], xmm11
000073ef1c5d56d1  vmovaps [rsp+0xB0], xmm12
000073ef1c5d56da  vmovaps [rsp+0xC0], xmm13
000073ef1c5d56e3  vmovaps [rsp+0xD0], xmm14
000073ef1c5d56ec  vmovaps [rsp+0xE0], xmm15
000073ef1c5d56f5  sub rsp, 0x30
000073ef1c5d56f9  movaps [rsp], xmm1
000073ef1c5d56fd  movaps [rsp+0x10], xmm7
000073ef1c5d5702  movaps [rsp+0x20], xmm11
000073ef1c5d5708  lea rdi, [rsp]
000073ef1c5d570c  mov esi, 0x00
000073ef1c5d5711  mov rax, 0x56F25E118530
000073ef1c5d571b  call rax
000073ef1c5d571d  movaps xmm1, [rsp]
000073ef1c5d5721  add rsp, 0x30
000073ef1c5d5725  vmovaps xmm0, [rsp]
000073ef1c5d572a  vmovaps xmm2, [rsp+0x10]
000073ef1c5d5730  vmovaps xmm3, [rsp+0x20]
000073ef1c5d5736  vmovaps xmm4, [rsp+0x30]
000073ef1c5d573c  vmovaps xmm5, [rsp+0x40]
000073ef1c5d5742  vmovaps xmm6, [rsp+0x50]
000073ef1c5d5748  vmovaps xmm7, [rsp+0x60]
000073ef1c5d574e  vmovaps xmm8, [rsp+0x70]
000073ef1c5d5754  vmovaps xmm9, [rsp+0x80]
000073ef1c5d575d  vmovaps xmm10, [rsp+0x90]
000073ef1c5d5766  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d576f  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d5778  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d5781  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d578a  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d5793  add rsp, 0xF0
000073ef1c5d579a  pop r11
000073ef1c5d579c  pop r10
000073ef1c5d579e  pop r9
000073ef1c5d57a0  pop r8
000073ef1c5d57a2  pop rsi
000073ef1c5d57a3  pop rdi
000073ef1c5d57a4  pop rdx
000073ef1c5d57a5  pop rcx
000073ef1c5d57a6  pop rax
000073ef1c5d57a7  add rsp, 0x08
000073ef1c5d57ab  jmp 0x000073EF1C5D033B
000073ef1c5d57b0  call 0x000073EF1C40E880
000073ef1c5d57b5  jmp 0x000073EF1C5D034E
000073ef1c5d57ba  call 0x000073EF1C40C380
000073ef1c5d57bf  jmp 0x000073EF1C5D0359
000073ef1c5d57c4  call 0x000073EF1C40D600
000073ef1c5d57c9  jmp 0x000073EF1C5D0364
000073ef1c5d57ce  call 0x000073EF1C3FF540
000073ef1c5d57d3  jmp 0x000073EF1C5D036F
000073ef1c5d57d8  int3
000073ef1c5d57d9  nop [rax], eax
000073ef1c5d57e0  mov rax, [r15+0x40]
000073ef1c5d57e4  mov r14, [r15+0x58]
000073ef1c5d57e8  lea r12, [rax+r14*1]
000073ef1c5d57ec  movaps xmm1, [r15+0x1D0]
000073ef1c5d57f4  vmovaps [rsp+0x10], xmm1
000073ef1c5d57fa  vmovaps xmm15, [rsp+0x10]
000073ef1c5d5800  por xmm1, xmm15
000073ef1c5d5805  movaps xmm14, [r15+0x1A0]
000073ef1c5d580d  vmovaps [rsp+0x10], xmm14
000073ef1c5d5813  vmovaps xmm13, [rsp+0x10]
000073ef1c5d5819  por xmm14, xmm13
000073ef1c5d581e  lea rax, [r12+0x30]
000073ef1c5d5823  mov r11, [r13+rax*1]
000073ef1c5d5828  lea rax, [r12+0x38]
000073ef1c5d582d  mov r10, [r13+rax*1]
000073ef1c5d5832  movq xmm13, r11
000073ef1c5d5837  movq xmm12, r10
000073ef1c5d583c  movq xmm13, xmm13
000073ef1c5d5841  vmovaps [rsp+0x10], xmm13
000073ef1c5d5847  movq xmm13, xmm13
000073ef1c5d584c  movaps [r15+0x130], xmm13
000073ef1c5d5854  movq xmm12, xmm12
000073ef1c5d5859  vmovaps [rsp+0x20], xmm12
000073ef1c5d585f  movq xmm12, xmm12
000073ef1c5d5864  movaps [r15+0x280], xmm12
000073ef1c5d586c  movaps xmm13, [r15+0x270]
000073ef1c5d5874  vmovaps [rsp+0x30], xmm13
000073ef1c5d587a  vmovaps xmm12, [rsp+0x30]
000073ef1c5d5880  por xmm13, xmm12
000073ef1c5d5885  lea rax, [r12+0x20]
000073ef1c5d588a  mov r11, [r13+rax*1]
000073ef1c5d588f  lea rax, [r12+0x28]
000073ef1c5d5894  mov r10, [r13+rax*1]
000073ef1c5d5899  movq xmm12, r11
000073ef1c5d589e  movq xmm11, r10
000073ef1c5d58a3  movq xmm12, xmm12
000073ef1c5d58a8  vmovaps [rsp+0x30], xmm12
000073ef1c5d58ae  movq xmm12, xmm12
000073ef1c5d58b3  movaps [r15+0x150], xmm12
000073ef1c5d58bb  movq xmm11, xmm11
000073ef1c5d58c0  vmovaps [rsp+0x40], xmm11
000073ef1c5d58c6  movq xmm11, xmm11
000073ef1c5d58cb  movaps [r15+0x140], xmm11
000073ef1c5d58d3  lea rax, [r12+0x10]
000073ef1c5d58d8  mov r11, [r13+rax*1]
000073ef1c5d58dd  lea rax, [r12+0x18]
000073ef1c5d58e2  mov r10, [r13+rax*1]
000073ef1c5d58e7  movq xmm12, r11
000073ef1c5d58ec  movq xmm11, r10
000073ef1c5d58f1  movq xmm12, xmm12
000073ef1c5d58f6  vmovaps [rsp+0x50], xmm12
000073ef1c5d58fc  movq xmm12, xmm12
000073ef1c5d5901  movaps [r15+0x170], xmm12
000073ef1c5d5909  movq xmm11, xmm11
000073ef1c5d590e  vmovaps [rsp+0x60], xmm11
000073ef1c5d5914  movq xmm11, xmm11
000073ef1c5d5919  movaps [r15+0x160], xmm11
000073ef1c5d5921  mov rax, [r13+r12*1]
000073ef1c5d5926  vmovq xmm12, rax
000073ef1c5d592b  vpbroadcastq xmm12, xmm12
000073ef1c5d5930  lea rax, [r12+0x08]
000073ef1c5d5935  mov r12, [r13+rax*1]
000073ef1c5d593a  movq xmm11, r12
000073ef1c5d593f  movaps [r15+0x230], xmm11
000073ef1c5d5947  mov rax, [r15+0xF8]
000073ef1c5d594e  lea r12, [rax+0x50]
000073ef1c5d5952  movups xmm11, [r13+r12*1]
000073ef1c5d5958  lea r12, [rax+0x60]
000073ef1c5d595c  movups xmm10, [r13+r12*1]
000073ef1c5d5962  lea r12, [rax+0x30]
000073ef1c5d5966  movups xmm9, [r13+r12*1]
000073ef1c5d596c  mov r12, [r15+0x50]
000073ef1c5d5970  lea r11, [r12+r14*1]
000073ef1c5d5974  mov [r15+0x60], r11
000073ef1c5d5978  lea r12, [r14+0x40]
000073ef1c5d597c  mov [r15+0x58], r12
000073ef1c5d5980  movaps xmm8, xmm12
000073ef1c5d5984  mulpd xmm8, xmm15
000073ef1c5d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000073ef1c5d598f  ptest xmm7, xmm7
000073ef1c5d5994  jnz 0x000073EF1C5D67B7
000073ef1c5d599a  movq xmm15, qword ptr [r15+0x230]
000073ef1c5d59a3  vmovaps [rsp+0x70], xmm15
000073ef1c5d59a9  vpermilpd xmm15, xmm15, 0x00
000073ef1c5d59af  movaps xmm7, xmm9
000073ef1c5d59b3  mulpd xmm7, xmm15
000073ef1c5d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000073ef1c5d59bd  ptest xmm6, xmm6
000073ef1c5d59c2  jnz 0x000073EF1C5D68FB
000073ef1c5d59c8  vxorps xmm15, xmm15, xmm15
000073ef1c5d59cd  vpbroadcastq xmm15, xmm15
000073ef1c5d59d2  movaps xmm9, xmm12
000073ef1c5d59d6  mulpd xmm9, xmm10
000073ef1c5d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000073ef1c5d59e1  ptest xmm6, xmm6
000073ef1c5d59e6  jnz 0x000073EF1C5D6A3D
000073ef1c5d59ec  movaps xmm10, xmm12
000073ef1c5d59f0  mulpd xmm10, xmm11
000073ef1c5d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000073ef1c5d59fb  ptest xmm6, xmm6
000073ef1c5d5a00  jnz 0x000073EF1C5D6B81
000073ef1c5d5a06  movaps xmm11, [r15+0x1F0]
000073ef1c5d5a0e  movaps xmm6, xmm12
000073ef1c5d5a12  mulpd xmm6, xmm11
000073ef1c5d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000073ef1c5d5a1c  ptest xmm5, xmm5
000073ef1c5d5a21  jnz 0x000073EF1C5D6CC5
000073ef1c5d5a27  movaps xmm12, [r15+0x2A0]
000073ef1c5d5a2f  vmovaps [rsp+0x80], xmm12
000073ef1c5d5a38  vmovaps xmm11, [rsp+0x80]
000073ef1c5d5a41  por xmm12, xmm11
000073ef1c5d5a46  movaps xmm11, [r15+0x250]
000073ef1c5d5a4e  vmovaps [rsp+0x80], xmm11
000073ef1c5d5a57  vmovaps xmm5, [rsp+0x80]
000073ef1c5d5a60  por xmm11, xmm5
000073ef1c5d5a65  vmovaps xmm4, [rsp+0x70]
000073ef1c5d5a6b  vpermilpd xmm4, xmm4, 0x00
000073ef1c5d5a71  movaps xmm3, xmm5
000073ef1c5d5a74  mulpd xmm3, xmm4
000073ef1c5d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000073ef1c5d5a7d  ptest xmm2, xmm2
000073ef1c5d5a82  jnz 0x000073EF1C5D6E07
000073ef1c5d5a88  mov [rsp+0x80], rax
000073ef1c5d5a90  xor eax, eax
000073ef1c5d5a92  mov r14d, 0x200
000073ef1c5d5a98  cmp r12, r14
000073ef1c5d5a9b  cmc
000073ef1c5d5a9c  lahf
000073ef1c5d5a9d  seto al
000073ef1c5d5aa0  mov [r15+0x108], eax
000073ef1c5d5aa7  movaps xmm5, xmm8
000073ef1c5d5aab  addpd xmm5, xmm15
000073ef1c5d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000073ef1c5d5ab5  ptest xmm4, xmm4
000073ef1c5d5aba  jnz 0x000073EF1C5D6F47
000073ef1c5d5ac0  movaps xmm8, [r15+0x1B0]
000073ef1c5d5ac8  movaps xmm4, xmm9
000073ef1c5d5acc  addpd xmm4, xmm8
000073ef1c5d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000073ef1c5d5ad6  ptest xmm2, xmm2
000073ef1c5d5adb  jnz 0x000073EF1C5D7089
000073ef1c5d5ae1  movaps xmm9, xmm10
000073ef1c5d5ae5  addpd xmm9, xmm8
000073ef1c5d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000073ef1c5d5af0  ptest xmm2, xmm2
000073ef1c5d5af5  jnz 0x000073EF1C5D71CB
000073ef1c5d5afb  movaps xmm10, [r15+0x2F0]
000073ef1c5d5b03  vmovaps [rsp+0x90], xmm10
000073ef1c5d5b0c  vmovaps xmm8, [rsp+0x90]
000073ef1c5d5b15  por xmm10, xmm8
000073ef1c5d5b1a  movaps xmm8, [r15+0x2E0]
000073ef1c5d5b22  vmovaps [rsp+0x90], xmm8
000073ef1c5d5b2b  vmovaps xmm2, [rsp+0x90]
000073ef1c5d5b34  por xmm8, xmm2
000073ef1c5d5b39  movaps xmm2, [r15+0x2D0]
000073ef1c5d5b41  vmovaps [rsp+0x90], xmm2
000073ef1c5d5b4a  vmovaps [rsp+0xA0], xmm1
000073ef1c5d5b53  vmovaps xmm1, [rsp+0x90]
000073ef1c5d5b5c  por xmm2, xmm1
000073ef1c5d5b60  movaps xmm1, [r15+0x200]
000073ef1c5d5b68  vmovaps [rsp+0x90], xmm1
000073ef1c5d5b71  vmovaps [rsp+0xB0], xmm15
000073ef1c5d5b7a  vmovaps xmm15, [rsp+0x90]
000073ef1c5d5b83  por xmm1, xmm15
000073ef1c5d5b88  movaps xmm15, [r15+0x1C0]
000073ef1c5d5b90  vmovaps [rsp+0x90], xmm15
000073ef1c5d5b99  vmovaps [rsp+0xC0], xmm1
000073ef1c5d5ba2  vmovaps xmm1, [rsp+0x90]
000073ef1c5d5bab  por xmm15, xmm1
000073ef1c5d5bb0  movaps xmm1, [r15+0x190]
000073ef1c5d5bb8  vmovaps [rsp+0x90], xmm1
000073ef1c5d5bc1  vmovaps [rsp+0xD0], xmm15
000073ef1c5d5bca  vmovaps xmm15, [rsp+0x90]
000073ef1c5d5bd3  por xmm1, xmm15
000073ef1c5d5bd8  movaps xmm15, [r15+0x300]
000073ef1c5d5be0  vmovaps [rsp+0x90], xmm15
000073ef1c5d5be9  vmovaps [rsp+0xE0], xmm1
000073ef1c5d5bf2  vmovaps xmm1, [rsp+0x90]
000073ef1c5d5bfb  por xmm15, xmm1
000073ef1c5d5c00  mov rax, [rsp+0x80]
000073ef1c5d5c08  lea r14, [rax+0xA0]
000073ef1c5d5c0f  movups xmm1, [r13+r14*1]
000073ef1c5d5c15  lea r14, [rax+0xB0]
000073ef1c5d5c1c  vmovaps [rsp+0x80], xmm1
000073ef1c5d5c25  movups xmm1, [r13+r14*1]
000073ef1c5d5c2b  vmovaps [rsp+0x90], xmm1
000073ef1c5d5c34  vmovaps [rsp+0xF0], xmm15
000073ef1c5d5c3d  vmovaps xmm15, [rsp+0xB0]
000073ef1c5d5c46  vmovaps [rsp+0xB0], xmm14
000073ef1c5d5c4f  movaps xmm1, xmm6
000073ef1c5d5c52  addpd xmm1, xmm15
000073ef1c5d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000073ef1c5d5c5c  ptest xmm14, xmm14
000073ef1c5d5c62  jnz 0x000073EF1C5D7323
000073ef1c5d5c68  lea r14, [rax+0xF0]
000073ef1c5d5c6f  movups xmm15, [r13+r14*1]
000073ef1c5d5c75  movaps xmm14, xmm4
000073ef1c5d5c79  addpd xmm14, xmm3
000073ef1c5d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000073ef1c5d5c84  ptest xmm6, xmm6
000073ef1c5d5c89  jnz 0x000073EF1C5D746E
000073ef1c5d5c8f  movaps xmm6, xmm9
000073ef1c5d5c93  addpd xmm6, xmm7
000073ef1c5d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000073ef1c5d5c9c  ptest xmm4, xmm4
000073ef1c5d5ca1  jnz 0x000073EF1C5D75B0
000073ef1c5d5ca7  vmovaps xmm9, [rsp+0x70]
000073ef1c5d5cad  vpermilpd xmm9, xmm9, 0x00
000073ef1c5d5cb3  vmovaps xmm4, [rsp+0x90]
000073ef1c5d5cbc  movaps xmm7, xmm4
000073ef1c5d5cbf  mulpd xmm7, xmm9
000073ef1c5d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000073ef1c5d5cc9  ptest xmm3, xmm3
000073ef1c5d5cce  jnz 0x000073EF1C5D76F1
000073ef1c5d5cd4  vmovaps xmm9, [rsp+0x50]
000073ef1c5d5cda  vpermilpd xmm9, xmm9, 0x00
000073ef1c5d5ce0  movaps xmm4, xmm15
000073ef1c5d5ce4  mulpd xmm4, xmm9
000073ef1c5d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000073ef1c5d5cee  ptest xmm3, xmm3
000073ef1c5d5cf3  jnz 0x000073EF1C5D7832
000073ef1c5d5cf9  lea r14, [rax+0xE0]
000073ef1c5d5d00  movups xmm15, [r13+r14*1]
000073ef1c5d5d06  vmovaps xmm9, [rsp+0x70]
000073ef1c5d5d0c  vpermilpd xmm9, xmm9, 0x00
000073ef1c5d5d12  vmovaps [rsp+0x70], xmm1
000073ef1c5d5d18  vmovaps xmm1, [rsp+0x80]
000073ef1c5d5d21  vmovaps [rsp+0x80], xmm15
000073ef1c5d5d2a  movaps xmm3, xmm1
000073ef1c5d5d2d  mulpd xmm3, xmm9
000073ef1c5d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000073ef1c5d5d37  ptest xmm15, xmm15
000073ef1c5d5d3d  jnz 0x000073EF1C5D797E
000073ef1c5d5d43  vmovaps xmm1, [rsp+0xF0]
000073ef1c5d5d4c  vmovaps xmm15, [rsp+0xF0]
000073ef1c5d5d55  por xmm1, xmm15
000073ef1c5d5d5a  movaps [r15+0x300], xmm1
000073ef1c5d5d62  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d5d6b  vmovaps xmm9, [rsp+0xE0]
000073ef1c5d5d74  por xmm15, xmm9
000073ef1c5d5d79  movaps [r15+0x190], xmm15
000073ef1c5d5d81  vmovaps xmm9, [rsp+0x50]
000073ef1c5d5d87  vpermilpd xmm9, xmm9, 0x00
000073ef1c5d5d8d  vmovaps [rsp+0x90], xmm1
000073ef1c5d5d96  vmovaps [rsp+0xE0], xmm15
000073ef1c5d5d9f  vmovaps xmm15, [rsp+0x80]
000073ef1c5d5da8  vmovaps [rsp+0x80], xmm14
000073ef1c5d5db1  movaps xmm1, xmm15
000073ef1c5d5db5  mulpd xmm1, xmm9
000073ef1c5d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000073ef1c5d5dbf  ptest xmm14, xmm14
000073ef1c5d5dc5  jnz 0x000073EF1C5D7ABF
000073ef1c5d5dcb  lea r14, [rax+0x90]
000073ef1c5d5dd2  movups xmm15, [r13+r14*1]
000073ef1c5d5dd8  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d5de1  vmovaps xmm9, [rsp+0xD0]
000073ef1c5d5dea  por xmm14, xmm9
000073ef1c5d5def  movaps [r15+0x1C0], xmm14
000073ef1c5d5df7  vmovaps xmm9, [rsp+0xC0]
000073ef1c5d5e00  vmovaps [rsp+0xD0], xmm1
000073ef1c5d5e09  vmovaps xmm1, [rsp+0xC0]
000073ef1c5d5e12  por xmm9, xmm1
000073ef1c5d5e17  movaps [r15+0x200], xmm9
000073ef1c5d5e1f  vmovaps [rsp+0xC0], xmm2
000073ef1c5d5e28  vmovaps xmm1, [rsp+0xC0]
000073ef1c5d5e31  por xmm2, xmm1
000073ef1c5d5e35  movaps [r15+0x2D0], xmm2
000073ef1c5d5e3d  vmovaps [rsp+0xC0], xmm8
000073ef1c5d5e46  vmovaps xmm1, [rsp+0xC0]
000073ef1c5d5e4f  por xmm8, xmm1
000073ef1c5d5e54  movaps [r15+0x2E0], xmm8
000073ef1c5d5e5c  vmovaps [rsp+0xC0], xmm15
000073ef1c5d5e65  movaps xmm1, xmm5
000073ef1c5d5e68  addpd xmm1, xmm7
000073ef1c5d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000073ef1c5d5e71  ptest xmm15, xmm15
000073ef1c5d5e77  jnz 0x000073EF1C5D7C0B
000073ef1c5d5e7d  vmovaps xmm15, [rsp+0x50]
000073ef1c5d5e83  vpermilpd xmm15, xmm15, 0x00
000073ef1c5d5e89  vmovaps xmm5, [rsp+0xC0]
000073ef1c5d5e92  vmovaps [rsp+0xC0], xmm1
000073ef1c5d5e9b  movaps xmm7, xmm5
000073ef1c5d5e9e  mulpd xmm7, xmm15
000073ef1c5d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000073ef1c5d5ea8  ptest xmm1, xmm1
000073ef1c5d5ead  jnz 0x000073EF1C5D7D4B
000073ef1c5d5eb3  lea r14, [rax+0x80]
000073ef1c5d5eba  movups xmm1, [r13+r14*1]
000073ef1c5d5ec0  vmovaps xmm5, [rsp+0x70]
000073ef1c5d5ec6  vmovaps [rsp+0x70], xmm1
000073ef1c5d5ecc  movaps xmm15, xmm5
000073ef1c5d5ed0  addpd xmm15, xmm3
000073ef1c5d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000073ef1c5d5edb  ptest xmm1, xmm1
000073ef1c5d5ee0  jnz 0x000073EF1C5D7E96
000073ef1c5d5ee6  vmovaps xmm5, [rsp+0x80]
000073ef1c5d5eef  movaps xmm1, xmm5
000073ef1c5d5ef2  addpd xmm1, xmm4
000073ef1c5d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000073ef1c5d5efb  ptest xmm3, xmm3
000073ef1c5d5f00  jnz 0x000073EF1C5D7FD8
000073ef1c5d5f06  vmovaps [rsp+0x80], xmm10
000073ef1c5d5f0f  vmovaps xmm5, [rsp+0x80]
000073ef1c5d5f18  por xmm10, xmm5
000073ef1c5d5f1d  movaps [r15+0x2F0], xmm10
000073ef1c5d5f25  vmovaps xmm5, [rsp+0x50]
000073ef1c5d5f2b  vpermilpd xmm5, xmm5, 0x00
000073ef1c5d5f31  vmovaps xmm3, [rsp+0x70]
000073ef1c5d5f37  vmovaps [rsp+0x50], xmm1
000073ef1c5d5f3d  movaps xmm4, xmm3
000073ef1c5d5f40  mulpd xmm4, xmm5
000073ef1c5d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000073ef1c5d5f49  ptest xmm1, xmm1
000073ef1c5d5f4e  jnz 0x000073EF1C5D8118
000073ef1c5d5f54  lea r14, [rax+0xD0]
000073ef1c5d5f5b  movups xmm1, [r13+r14*1]
000073ef1c5d5f61  vmovaps xmm3, [rsp+0xD0]
000073ef1c5d5f6a  vmovaps [rsp+0x70], xmm1
000073ef1c5d5f70  movaps xmm5, xmm6
000073ef1c5d5f73  addpd xmm5, xmm3
000073ef1c5d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000073ef1c5d5f7c  ptest xmm1, xmm1
000073ef1c5d5f81  jnz 0x000073EF1C5D8262
000073ef1c5d5f87  vmovaps xmm1, [rsp+0x60]
000073ef1c5d5f8d  vpermilpd xmm1, xmm1, 0x00
000073ef1c5d5f93  movaps xmm6, xmm9
000073ef1c5d5f97  mulpd xmm6, xmm1
000073ef1c5d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000073ef1c5d5fa0  ptest xmm3, xmm3
000073ef1c5d5fa5  jnz 0x000073EF1C5D83A2
000073ef1c5d5fab  movaps [r15+0x260], xmm6
000073ef1c5d5fb3  vxorps xmm1, xmm1, xmm1
000073ef1c5d5fb7  vpbroadcastq xmm1, xmm1
000073ef1c5d5fbc  movaps [r15+0x1B0], xmm1
000073ef1c5d5fc4  vmovaps xmm1, [rsp+0x60]
000073ef1c5d5fca  vpermilpd xmm1, xmm1, 0x00
000073ef1c5d5fd0  vmovaps xmm3, [rsp+0x70]
000073ef1c5d5fd6  vmovaps [rsp+0x70], xmm15
000073ef1c5d5fdc  movaps xmm9, xmm3
000073ef1c5d5fe0  mulpd xmm9, xmm1
000073ef1c5d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000073ef1c5d5feb  ptest xmm15, xmm15
000073ef1c5d5ff1  jnz 0x000073EF1C5D84E3
000073ef1c5d5ff7  lea r14, [rax+0xC0]
000073ef1c5d5ffe  movups xmm1, [r13+r14*1]
000073ef1c5d6004  vmovaps xmm3, [rsp+0xC0]
000073ef1c5d600d  vmovaps [rsp+0x80], xmm1
000073ef1c5d6016  movaps xmm15, xmm3
000073ef1c5d601a  addpd xmm15, xmm7
000073ef1c5d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000073ef1c5d6025  ptest xmm1, xmm1
000073ef1c5d602a  jnz 0x000073EF1C5D862F
000073ef1c5d6030  vmovaps [rsp+0xC0], xmm13
000073ef1c5d6039  vmovaps xmm1, [rsp+0xC0]
000073ef1c5d6042  por xmm13, xmm1
000073ef1c5d6047  movaps [r15+0x270], xmm13
000073ef1c5d604f  vmovaps xmm1, [rsp+0xB0]
000073ef1c5d6058  vmovaps xmm7, [rsp+0xB0]
000073ef1c5d6061  por xmm1, xmm7
000073ef1c5d6065  movaps [r15+0x1A0], xmm1
000073ef1c5d606d  vmovaps xmm1, [rsp+0x60]
000073ef1c5d6073  vpermilpd xmm1, xmm1, 0x00
000073ef1c5d6079  vmovaps [rsp+0xB0], xmm1
000073ef1c5d6082  vmovaps xmm1, [rsp+0x80]
000073ef1c5d608b  vmovaps [rsp+0x80], xmm15
000073ef1c5d6094  vmovaps xmm15, [rsp+0xB0]
000073ef1c5d609d  vmovaps [rsp+0xB0], xmm14
000073ef1c5d60a6  movaps xmm3, xmm1
000073ef1c5d60a9  mulpd xmm3, xmm15
000073ef1c5d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000073ef1c5d60b3  ptest xmm14, xmm14
000073ef1c5d60b9  jnz 0x000073EF1C5D8771
000073ef1c5d60bf  lea r14, [rax+0x20]
000073ef1c5d60c3  movups xmm1, [r13+r14*1]
000073ef1c5d60c9  movaps [r15+0x110], xmm1
000073ef1c5d60d1  vmovaps xmm14, [rsp+0x70]
000073ef1c5d60d7  vmovaps [rsp+0x70], xmm1
000073ef1c5d60dd  movaps xmm15, xmm14
000073ef1c5d60e1  addpd xmm15, xmm4
000073ef1c5d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000073ef1c5d60ec  ptest xmm1, xmm1
000073ef1c5d60f1  jnz 0x000073EF1C5D88BC
000073ef1c5d60f7  vmovaps xmm1, [rsp+0x60]
000073ef1c5d60fd  vpermilpd xmm1, xmm1, 0x00
000073ef1c5d6103  movaps xmm14, xmm2
000073ef1c5d6107  mulpd xmm14, xmm1
000073ef1c5d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000073ef1c5d6112  ptest xmm4, xmm4
000073ef1c5d6117  jnz 0x000073EF1C5D89FF
000073ef1c5d611d  vmovaps xmm4, [rsp+0x50]
000073ef1c5d6123  movaps xmm1, xmm4
000073ef1c5d6126  addpd xmm1, xmm9
000073ef1c5d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000073ef1c5d6130  ptest xmm2, xmm2
000073ef1c5d6135  jnz 0x000073EF1C5D8B41
000073ef1c5d613b  vmovaps xmm9, [rsp+0x30]
000073ef1c5d6141  vpermilpd xmm9, xmm9, 0x00
000073ef1c5d6147  vmovaps xmm2, [rsp+0x70]
000073ef1c5d614d  vmovaps [rsp+0x50], xmm1
000073ef1c5d6153  movaps xmm4, xmm2
000073ef1c5d6156  mulpd xmm4, xmm9
000073ef1c5d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000073ef1c5d6160  ptest xmm1, xmm1
000073ef1c5d6165  jnz 0x000073EF1C5D8C82
000073ef1c5d616b  vmovaps xmm1, [rsp+0x30]
000073ef1c5d6171  vpermilpd xmm1, xmm1, 0x00
000073ef1c5d6177  vmovaps xmm2, [rsp+0x90]
000073ef1c5d6180  vmovaps [rsp+0x60], xmm15
000073ef1c5d6186  movaps xmm9, xmm2
000073ef1c5d618a  mulpd xmm9, xmm1
000073ef1c5d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000073ef1c5d6195  ptest xmm15, xmm15
000073ef1c5d619b  jnz 0x000073EF1C5D8DC3
000073ef1c5d61a1  vmovaps xmm15, [rsp+0x80]
000073ef1c5d61aa  movaps xmm1, xmm15
000073ef1c5d61ae  addpd xmm1, xmm6
000073ef1c5d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000073ef1c5d61b7  ptest xmm2, xmm2
000073ef1c5d61bc  jnz 0x000073EF1C5D8F05
000073ef1c5d61c2  movaps xmm15, xmm5
000073ef1c5d61c6  addpd xmm15, xmm3
000073ef1c5d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000073ef1c5d61d1  ptest xmm6, xmm6
000073ef1c5d61d6  jnz 0x000073EF1C5D9046
000073ef1c5d61dc  vmovaps xmm6, [rsp+0x30]
000073ef1c5d61e2  vpermilpd xmm6, xmm6, 0x00
000073ef1c5d61e8  movaps xmm5, xmm8
000073ef1c5d61ec  mulpd xmm5, xmm6
000073ef1c5d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000073ef1c5d61f5  ptest xmm3, xmm3
000073ef1c5d61fa  jnz 0x000073EF1C5D9188
000073ef1c5d6200  vmovaps xmm8, [rsp+0x30]
000073ef1c5d6206  vpermilpd xmm8, xmm8, 0x00
000073ef1c5d620c  movaps xmm6, xmm10
000073ef1c5d6210  mulpd xmm6, xmm8
000073ef1c5d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000073ef1c5d621a  ptest xmm3, xmm3
000073ef1c5d621f  jnz 0x000073EF1C5D92C9
000073ef1c5d6225  vmovaps xmm8, [rsp+0x60]
000073ef1c5d622b  movaps xmm10, xmm8
000073ef1c5d622f  addpd xmm10, xmm14
000073ef1c5d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000073ef1c5d623a  ptest xmm3, xmm3
000073ef1c5d623f  jnz 0x000073EF1C5D940B
000073ef1c5d6245  vmovaps xmm8, [rsp+0x50]
000073ef1c5d624b  movaps xmm14, xmm8
000073ef1c5d624f  addpd xmm14, xmm4
000073ef1c5d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000073ef1c5d625a  ptest xmm3, xmm3
000073ef1c5d625f  jnz 0x000073EF1C5D954F
000073ef1c5d6265  vmovaps xmm8, [rsp+0x40]
000073ef1c5d626b  vpermilpd xmm8, xmm8, 0x00
000073ef1c5d6271  movaps xmm4, xmm13
000073ef1c5d6275  mulpd xmm4, xmm8
000073ef1c5d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000073ef1c5d627f  ptest xmm3, xmm3
000073ef1c5d6284  jnz 0x000073EF1C5D9692
000073ef1c5d628a  movaps xmm13, xmm15
000073ef1c5d628e  addpd xmm13, xmm9
000073ef1c5d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000073ef1c5d6299  ptest xmm8, xmm8
000073ef1c5d629f  jnz 0x000073EF1C5D97D4
000073ef1c5d62a5  movaps xmm15, xmm1
000073ef1c5d62a9  addpd xmm15, xmm5
000073ef1c5d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000073ef1c5d62b4  ptest xmm9, xmm9
000073ef1c5d62ba  jnz 0x000073EF1C5D9918
000073ef1c5d62c0  vmovaps [rsp+0x30], xmm11
000073ef1c5d62c6  vmovaps xmm1, [rsp+0x30]
000073ef1c5d62cc  por xmm11, xmm1
000073ef1c5d62d1  movaps [r15+0x250], xmm11
000073ef1c5d62d9  vmovaps [rsp+0x30], xmm12
000073ef1c5d62df  vmovaps xmm1, [rsp+0x30]
000073ef1c5d62e5  por xmm12, xmm1
000073ef1c5d62ea  movaps [r15+0x2A0], xmm12
000073ef1c5d62f2  vmovaps xmm1, [rsp+0xA0]
000073ef1c5d62fb  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d6304  por xmm1, xmm11
000073ef1c5d6309  movaps [r15+0x1D0], xmm1
000073ef1c5d6311  lea r14, [rax+0x40]
000073ef1c5d6315  movups xmm1, [r13+r14*1]
000073ef1c5d631b  movaps [r15+0x2C0], xmm1
000073ef1c5d6323  vmovaps xmm11, [rsp+0x40]
000073ef1c5d6329  vpermilpd xmm11, xmm11, 0x00
000073ef1c5d632f  vmovaps xmm8, [rsp+0xE0]
000073ef1c5d6338  movaps xmm9, xmm8
000073ef1c5d633c  mulpd xmm9, xmm11
000073ef1c5d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000073ef1c5d6347  ptest xmm5, xmm5
000073ef1c5d634c  jnz 0x000073EF1C5D9A64
000073ef1c5d6352  movaps xmm11, xmm10
000073ef1c5d6356  addpd xmm11, xmm6
000073ef1c5d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000073ef1c5d6361  ptest xmm8, xmm8
000073ef1c5d6367  jnz 0x000073EF1C5D9BA8
000073ef1c5d636d  movaps xmm10, xmm14
000073ef1c5d6371  addpd xmm10, xmm4
000073ef1c5d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000073ef1c5d637c  ptest xmm8, xmm8
000073ef1c5d6382  jnz 0x000073EF1C5D9CEB
000073ef1c5d6388  vmovaps xmm14, [rsp+0x40]
000073ef1c5d638e  vpermilpd xmm14, xmm14, 0x00
000073ef1c5d6394  movaps xmm8, xmm1
000073ef1c5d6398  mulpd xmm8, xmm14
000073ef1c5d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000073ef1c5d63a3  ptest xmm6, xmm6
000073ef1c5d63a8  jnz 0x000073EF1C5D9E2E
000073ef1c5d63ae  movaps xmm1, [r15+0x2B0]
000073ef1c5d63b6  vmovaps xmm14, [rsp+0x40]
000073ef1c5d63bc  vpermilpd xmm14, xmm14, 0x00
000073ef1c5d63c2  movaps xmm6, xmm1
000073ef1c5d63c5  mulpd xmm6, xmm14
000073ef1c5d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000073ef1c5d63cf  ptest xmm5, xmm5
000073ef1c5d63d4  jnz 0x000073EF1C5D9F71
000073ef1c5d63da  vmovaps xmm1, [rsp+0x10]
000073ef1c5d63e0  vpermilpd xmm1, xmm1, 0x00
000073ef1c5d63e6  movaps xmm14, xmm12
000073ef1c5d63ea  mulpd xmm14, xmm1
000073ef1c5d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000073ef1c5d63f5  ptest xmm5, xmm5
000073ef1c5d63fa  jnz 0x000073EF1C5DA0B2
000073ef1c5d6400  movaps xmm1, xmm13
000073ef1c5d6404  addpd xmm1, xmm9
000073ef1c5d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000073ef1c5d640e  ptest xmm12, xmm12
000073ef1c5d6414  jnz 0x000073EF1C5DA1F5
000073ef1c5d641a  vmovaps xmm13, [rsp+0x10]
000073ef1c5d6420  vpermilpd xmm13, xmm13, 0x00
000073ef1c5d6426  movaps xmm12, xmm7
000073ef1c5d642a  mulpd xmm12, xmm13
000073ef1c5d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000073ef1c5d6435  ptest xmm9, xmm9
000073ef1c5d643b  jnz 0x000073EF1C5DA337
000073ef1c5d6441  movaps xmm13, xmm15
000073ef1c5d6445  addpd xmm13, xmm8
000073ef1c5d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000073ef1c5d6450  ptest xmm9, xmm9
000073ef1c5d6456  jnz 0x000073EF1C5DA47A
000073ef1c5d645c  movaps xmm15, [r15+0x290]
000073ef1c5d6464  vmovaps xmm9, [rsp+0x10]
000073ef1c5d646a  vpermilpd xmm9, xmm9, 0x00
000073ef1c5d6470  movaps xmm8, xmm15
000073ef1c5d6474  mulpd xmm8, xmm9
000073ef1c5d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000073ef1c5d647f  ptest xmm7, xmm7
000073ef1c5d6484  jnz 0x000073EF1C5DA5BE
000073ef1c5d648a  movaps xmm15, xmm11
000073ef1c5d648e  addpd xmm15, xmm6
000073ef1c5d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000073ef1c5d6499  ptest xmm9, xmm9
000073ef1c5d649f  jnz 0x000073EF1C5DA702
000073ef1c5d64a5  movaps xmm11, [r15+0x1E0]
000073ef1c5d64ad  vmovaps xmm9, [rsp+0x10]
000073ef1c5d64b3  vpermilpd xmm9, xmm9, 0x00
000073ef1c5d64b9  movaps xmm7, xmm11
000073ef1c5d64bd  mulpd xmm7, xmm9
000073ef1c5d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000073ef1c5d64c7  ptest xmm6, xmm6
000073ef1c5d64cc  jnz 0x000073EF1C5DA845
000073ef1c5d64d2  movaps xmm11, xmm10
000073ef1c5d64d6  addpd xmm11, xmm14
000073ef1c5d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000073ef1c5d64e1  ptest xmm9, xmm9
000073ef1c5d64e7  jnz 0x000073EF1C5DA987
000073ef1c5d64ed  lea r14, [rax+0x70]
000073ef1c5d64f1  movups xmm14, [r13+r14*1]
000073ef1c5d64f7  movaps [r15+0x240], xmm14
000073ef1c5d64ff  movaps xmm10, xmm1
000073ef1c5d6503  addpd xmm10, xmm12
000073ef1c5d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000073ef1c5d650e  ptest xmm9, xmm9
000073ef1c5d6514  jnz 0x000073EF1C5DAAD5
000073ef1c5d651a  movaps [r15+0x170], xmm10
000073ef1c5d6522  vmovaps xmm1, [rsp+0x20]
000073ef1c5d6528  vpermilpd xmm1, xmm1, 0x00
000073ef1c5d652e  movaps xmm12, xmm14
000073ef1c5d6532  mulpd xmm12, xmm1
000073ef1c5d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000073ef1c5d653d  ptest xmm9, xmm9
000073ef1c5d6543  jnz 0x000073EF1C5DAC18
000073ef1c5d6549  vmovaps xmm1, [rsp+0x20]
000073ef1c5d654f  vpermilpd xmm1, xmm1, 0x00
000073ef1c5d6555  vmovaps xmm9, [rsp+0xB0]
000073ef1c5d655e  movaps xmm14, xmm9
000073ef1c5d6562  mulpd xmm14, xmm1
000073ef1c5d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000073ef1c5d656d  ptest xmm6, xmm6
000073ef1c5d6572  jnz 0x000073EF1C5DAD5B
000073ef1c5d6578  movaps [r15+0x180], xmm14
000073ef1c5d6580  movaps xmm1, xmm13
000073ef1c5d6584  addpd xmm1, xmm8
000073ef1c5d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000073ef1c5d658e  ptest xmm9, xmm9
000073ef1c5d6594  jnz 0x000073EF1C5DAE9E
000073ef1c5d659a  movaps [r15+0x210], xmm1
000073ef1c5d65a2  movups xmm13, [r13+rax*1]
000073ef1c5d65a8  lea r14, [rax+0x10]
000073ef1c5d65ac  movups xmm9, [r13+r14*1]
000073ef1c5d65b2  movaps [r15+0x230], xmm9
000073ef1c5d65ba  movaps xmm8, xmm15
000073ef1c5d65be  addpd xmm8, xmm7
000073ef1c5d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000073ef1c5d65c9  ptest xmm6, xmm6
000073ef1c5d65ce  jnz 0x000073EF1C5DAFF4
000073ef1c5d65d4  movaps [r15+0x130], xmm8
000073ef1c5d65dc  vmovaps xmm15, [rsp+0x20]
000073ef1c5d65e2  vpermilpd xmm15, xmm15, 0x00
000073ef1c5d65e8  movaps xmm7, xmm9
000073ef1c5d65ec  mulpd xmm7, xmm15
000073ef1c5d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000073ef1c5d65f6  ptest xmm6, xmm6
000073ef1c5d65fb  jnz 0x000073EF1C5DB137
000073ef1c5d6601  movaps [r15+0x220], xmm7
000073ef1c5d6609  vmovaps xmm15, [rsp+0x20]
000073ef1c5d660f  vpermilpd xmm15, xmm15, 0x00
000073ef1c5d6615  movaps xmm9, xmm13
000073ef1c5d6619  mulpd xmm9, xmm15
000073ef1c5d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000073ef1c5d6624  ptest xmm6, xmm6
000073ef1c5d6629  jnz 0x000073EF1C5DB279
000073ef1c5d662f  movaps xmm15, xmm11
000073ef1c5d6633  addpd xmm15, xmm12
000073ef1c5d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000073ef1c5d663e  ptest xmm13, xmm13
000073ef1c5d6644  jnz 0x000073EF1C5DB3BD
000073ef1c5d664a  movaps [r15+0x140], xmm15
000073ef1c5d6652  movaps xmm13, xmm10
000073ef1c5d6656  addpd xmm13, xmm14
000073ef1c5d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000073ef1c5d6661  ptest xmm12, xmm12
000073ef1c5d6667  jnz 0x000073EF1C5DB501
000073ef1c5d666d  movaps [r15+0x150], xmm13
000073ef1c5d6675  movaps xmm14, xmm1
000073ef1c5d6679  addpd xmm14, xmm7
000073ef1c5d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000073ef1c5d6684  ptest xmm12, xmm12
000073ef1c5d668a  jnz 0x000073EF1C5DB645
000073ef1c5d6690  movaps [r15+0x160], xmm14
000073ef1c5d6698  movaps xmm1, xmm8
000073ef1c5d669c  addpd xmm1, xmm9
000073ef1c5d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000073ef1c5d66a6  ptest xmm12, xmm12
000073ef1c5d66ac  jnz 0x000073EF1C5DB787
000073ef1c5d66b2  movaps [r15+0x120], xmm1
000073ef1c5d66ba  movups [r13+r11*1], xmm15
000073ef1c5d66c0  lea rax, [r11+0x10]
000073ef1c5d66c4  movups [r13+rax*1], xmm13
000073ef1c5d66ca  lea rax, [r11+0x20]
000073ef1c5d66ce  movups [r13+rax*1], xmm14
000073ef1c5d66d4  lea rax, [r11+0x30]
000073ef1c5d66d8  movups [r13+rax*1], xmm1
000073ef1c5d66de  mov eax, [r15+0x108]
000073ef1c5d66e5  sahf
000073ef1c5d66e6  jnz 0x000073EF1C5D6718
000073ef1c5d66e8  cmp dword ptr [r15+0x318], 0x00
000073ef1c5d66f0  jz 0x000073EF1C5DB900
000073ef1c5d66f6  nop [rax+rax*1], ax
000073ef1c5d66ff  nop [rax+rax*1], eax
000073ef1c5d6707  mov eax, 0x410444
000073ef1c5d670c  mov [r15+0x100], rax
000073ef1c5d6713  jmp 0x000073EF1C3FE110
000073ef1c5d6718  cmp dword ptr [r15+0x318], 0x00
000073ef1c5d6720  jz 0x000073EF1C5D57E0
000073ef1c5d6726  nop [rax+rax*1], ax
000073ef1c5d672f  nop [rax+rax*1], eax
000073ef1c5d6737  mov eax, 0x410278
000073ef1c5d673c  mov [r15+0x100], rax
000073ef1c5d6743  jmp 0x000073EF1C3FE110
000073ef1c5d6748  int3
000073ef1c5d6749  call 0x000073EF1C40A4B0
000073ef1c5d674e  jmp 0x000073EF1C5D5828
000073ef1c5d6753  call 0x000073EF1C409240
000073ef1c5d6758  jmp 0x000073EF1C5D5832
000073ef1c5d675d  call 0x000073EF1C40A4B0
000073ef1c5d6762  jmp 0x000073EF1C5D588F
000073ef1c5d6767  call 0x000073EF1C409240
000073ef1c5d676c  jmp 0x000073EF1C5D5899
000073ef1c5d6771  call 0x000073EF1C40A4B0
000073ef1c5d6776  jmp 0x000073EF1C5D58DD
000073ef1c5d677b  call 0x000073EF1C409240
000073ef1c5d6780  jmp 0x000073EF1C5D58E7
000073ef1c5d6785  call 0x000073EF1C4B47C0
000073ef1c5d678a  jmp 0x000073EF1C5D5926
000073ef1c5d678f  call 0x000073EF1C40B720
000073ef1c5d6794  jmp 0x000073EF1C5D593A
000073ef1c5d6799  call 0x000073EF1C4BFC30
000073ef1c5d679e  jmp 0x000073EF1C5D5958
000073ef1c5d67a3  call 0x000073EF1C4BE9C0
000073ef1c5d67a8  jmp 0x000073EF1C5D5962
000073ef1c5d67ad  call 0x000073EF1C4BD750
000073ef1c5d67b2  jmp 0x000073EF1C5D596C
000073ef1c5d67b7  sub rsp, 0x08
000073ef1c5d67bb  push rax
000073ef1c5d67bc  push rcx
000073ef1c5d67bd  push rdx
000073ef1c5d67be  push rdi
000073ef1c5d67bf  push rsi
000073ef1c5d67c0  push r8
000073ef1c5d67c2  push r9
000073ef1c5d67c4  push r10
000073ef1c5d67c6  push r11
000073ef1c5d67c8  sub rsp, 0xF0
000073ef1c5d67cf  vmovaps [rsp], xmm0
000073ef1c5d67d4  vmovaps [rsp+0x10], xmm1
000073ef1c5d67da  vmovaps [rsp+0x20], xmm2
000073ef1c5d67e0  vmovaps [rsp+0x30], xmm3
000073ef1c5d67e6  vmovaps [rsp+0x40], xmm4
000073ef1c5d67ec  vmovaps [rsp+0x50], xmm5
000073ef1c5d67f2  vmovaps [rsp+0x60], xmm6
000073ef1c5d67f8  vmovaps [rsp+0x70], xmm7
000073ef1c5d67fe  vmovaps [rsp+0x80], xmm9
000073ef1c5d6807  vmovaps [rsp+0x90], xmm10
000073ef1c5d6810  vmovaps [rsp+0xA0], xmm11
000073ef1c5d6819  vmovaps [rsp+0xB0], xmm12
000073ef1c5d6822  vmovaps [rsp+0xC0], xmm13
000073ef1c5d682b  vmovaps [rsp+0xD0], xmm14
000073ef1c5d6834  vmovaps [rsp+0xE0], xmm15
000073ef1c5d683d  sub rsp, 0x30
000073ef1c5d6841  movaps [rsp], xmm8
000073ef1c5d6846  movaps [rsp+0x10], xmm12
000073ef1c5d684c  movaps [rsp+0x20], xmm15
000073ef1c5d6852  lea rdi, [rsp]
000073ef1c5d6856  mov esi, 0x00
000073ef1c5d685b  mov rax, 0x56F25E118530
000073ef1c5d6865  call rax
000073ef1c5d6867  movaps xmm8, [rsp]
000073ef1c5d686c  add rsp, 0x30
000073ef1c5d6870  vmovaps xmm0, [rsp]
000073ef1c5d6875  vmovaps xmm1, [rsp+0x10]
000073ef1c5d687b  vmovaps xmm2, [rsp+0x20]
000073ef1c5d6881  vmovaps xmm3, [rsp+0x30]
000073ef1c5d6887  vmovaps xmm4, [rsp+0x40]
000073ef1c5d688d  vmovaps xmm5, [rsp+0x50]
000073ef1c5d6893  vmovaps xmm6, [rsp+0x60]
000073ef1c5d6899  vmovaps xmm7, [rsp+0x70]
000073ef1c5d689f  vmovaps xmm9, [rsp+0x80]
000073ef1c5d68a8  vmovaps xmm10, [rsp+0x90]
000073ef1c5d68b1  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d68ba  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d68c3  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d68cc  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d68d5  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d68de  add rsp, 0xF0
000073ef1c5d68e5  pop r11
000073ef1c5d68e7  pop r10
000073ef1c5d68e9  pop r9
000073ef1c5d68eb  pop r8
000073ef1c5d68ed  pop rsi
000073ef1c5d68ee  pop rdi
000073ef1c5d68ef  pop rdx
000073ef1c5d68f0  pop rcx
000073ef1c5d68f1  pop rax
000073ef1c5d68f2  add rsp, 0x08
000073ef1c5d68f6  jmp 0x000073EF1C5D599A
000073ef1c5d68fb  sub rsp, 0x08
000073ef1c5d68ff  push rax
000073ef1c5d6900  push rcx
000073ef1c5d6901  push rdx
000073ef1c5d6902  push rdi
000073ef1c5d6903  push rsi
000073ef1c5d6904  push r8
000073ef1c5d6906  push r9
000073ef1c5d6908  push r10
000073ef1c5d690a  push r11
000073ef1c5d690c  sub rsp, 0xF0
000073ef1c5d6913  vmovaps [rsp], xmm0
000073ef1c5d6918  vmovaps [rsp+0x10], xmm1
000073ef1c5d691e  vmovaps [rsp+0x20], xmm2
000073ef1c5d6924  vmovaps [rsp+0x30], xmm3
000073ef1c5d692a  vmovaps [rsp+0x40], xmm4
000073ef1c5d6930  vmovaps [rsp+0x50], xmm5
000073ef1c5d6936  vmovaps [rsp+0x60], xmm6
000073ef1c5d693c  vmovaps [rsp+0x70], xmm8
000073ef1c5d6942  vmovaps [rsp+0x80], xmm9
000073ef1c5d694b  vmovaps [rsp+0x90], xmm10
000073ef1c5d6954  vmovaps [rsp+0xA0], xmm11
000073ef1c5d695d  vmovaps [rsp+0xB0], xmm12
000073ef1c5d6966  vmovaps [rsp+0xC0], xmm13
000073ef1c5d696f  vmovaps [rsp+0xD0], xmm14
000073ef1c5d6978  vmovaps [rsp+0xE0], xmm15
000073ef1c5d6981  sub rsp, 0x30
000073ef1c5d6985  movaps [rsp], xmm7
000073ef1c5d6989  movaps [rsp+0x10], xmm9
000073ef1c5d698f  movaps [rsp+0x20], xmm15
000073ef1c5d6995  lea rdi, [rsp]
000073ef1c5d6999  mov esi, 0x00
000073ef1c5d699e  mov rax, 0x56F25E118530
000073ef1c5d69a8  call rax
000073ef1c5d69aa  movaps xmm7, [rsp]
000073ef1c5d69ae  add rsp, 0x30
000073ef1c5d69b2  vmovaps xmm0, [rsp]
000073ef1c5d69b7  vmovaps xmm1, [rsp+0x10]
000073ef1c5d69bd  vmovaps xmm2, [rsp+0x20]
000073ef1c5d69c3  vmovaps xmm3, [rsp+0x30]
000073ef1c5d69c9  vmovaps xmm4, [rsp+0x40]
000073ef1c5d69cf  vmovaps xmm5, [rsp+0x50]
000073ef1c5d69d5  vmovaps xmm6, [rsp+0x60]
000073ef1c5d69db  vmovaps xmm8, [rsp+0x70]
000073ef1c5d69e1  vmovaps xmm9, [rsp+0x80]
000073ef1c5d69ea  vmovaps xmm10, [rsp+0x90]
000073ef1c5d69f3  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d69fc  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d6a05  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d6a0e  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d6a17  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d6a20  add rsp, 0xF0
000073ef1c5d6a27  pop r11
000073ef1c5d6a29  pop r10
000073ef1c5d6a2b  pop r9
000073ef1c5d6a2d  pop r8
000073ef1c5d6a2f  pop rsi
000073ef1c5d6a30  pop rdi
000073ef1c5d6a31  pop rdx
000073ef1c5d6a32  pop rcx
000073ef1c5d6a33  pop rax
000073ef1c5d6a34  add rsp, 0x08
000073ef1c5d6a38  jmp 0x000073EF1C5D59C8
000073ef1c5d6a3d  sub rsp, 0x08
000073ef1c5d6a41  push rax
000073ef1c5d6a42  push rcx
000073ef1c5d6a43  push rdx
000073ef1c5d6a44  push rdi
000073ef1c5d6a45  push rsi
000073ef1c5d6a46  push r8
000073ef1c5d6a48  push r9
000073ef1c5d6a4a  push r10
000073ef1c5d6a4c  push r11
000073ef1c5d6a4e  sub rsp, 0xF0
000073ef1c5d6a55  vmovaps [rsp], xmm0
000073ef1c5d6a5a  vmovaps [rsp+0x10], xmm1
000073ef1c5d6a60  vmovaps [rsp+0x20], xmm2
000073ef1c5d6a66  vmovaps [rsp+0x30], xmm3
000073ef1c5d6a6c  vmovaps [rsp+0x40], xmm4
000073ef1c5d6a72  vmovaps [rsp+0x50], xmm5
000073ef1c5d6a78  vmovaps [rsp+0x60], xmm6
000073ef1c5d6a7e  vmovaps [rsp+0x70], xmm7
000073ef1c5d6a84  vmovaps [rsp+0x80], xmm8
000073ef1c5d6a8d  vmovaps [rsp+0x90], xmm10
000073ef1c5d6a96  vmovaps [rsp+0xA0], xmm11
000073ef1c5d6a9f  vmovaps [rsp+0xB0], xmm12
000073ef1c5d6aa8  vmovaps [rsp+0xC0], xmm13
000073ef1c5d6ab1  vmovaps [rsp+0xD0], xmm14
000073ef1c5d6aba  vmovaps [rsp+0xE0], xmm15
000073ef1c5d6ac3  sub rsp, 0x30
000073ef1c5d6ac7  movaps [rsp], xmm9
000073ef1c5d6acc  movaps [rsp+0x10], xmm12
000073ef1c5d6ad2  movaps [rsp+0x20], xmm10
000073ef1c5d6ad8  lea rdi, [rsp]
000073ef1c5d6adc  mov esi, 0x00
000073ef1c5d6ae1  mov rax, 0x56F25E118530
000073ef1c5d6aeb  call rax
000073ef1c5d6aed  movaps xmm9, [rsp]
000073ef1c5d6af2  add rsp, 0x30
000073ef1c5d6af6  vmovaps xmm0, [rsp]
000073ef1c5d6afb  vmovaps xmm1, [rsp+0x10]
000073ef1c5d6b01  vmovaps xmm2, [rsp+0x20]
000073ef1c5d6b07  vmovaps xmm3, [rsp+0x30]
000073ef1c5d6b0d  vmovaps xmm4, [rsp+0x40]
000073ef1c5d6b13  vmovaps xmm5, [rsp+0x50]
000073ef1c5d6b19  vmovaps xmm6, [rsp+0x60]
000073ef1c5d6b1f  vmovaps xmm7, [rsp+0x70]
000073ef1c5d6b25  vmovaps xmm8, [rsp+0x80]
000073ef1c5d6b2e  vmovaps xmm10, [rsp+0x90]
000073ef1c5d6b37  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d6b40  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d6b49  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d6b52  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d6b5b  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d6b64  add rsp, 0xF0
000073ef1c5d6b6b  pop r11
000073ef1c5d6b6d  pop r10
000073ef1c5d6b6f  pop r9
000073ef1c5d6b71  pop r8
000073ef1c5d6b73  pop rsi
000073ef1c5d6b74  pop rdi
000073ef1c5d6b75  pop rdx
000073ef1c5d6b76  pop rcx
000073ef1c5d6b77  pop rax
000073ef1c5d6b78  add rsp, 0x08
000073ef1c5d6b7c  jmp 0x000073EF1C5D59EC
000073ef1c5d6b81  sub rsp, 0x08
000073ef1c5d6b85  push rax
000073ef1c5d6b86  push rcx
000073ef1c5d6b87  push rdx
000073ef1c5d6b88  push rdi
000073ef1c5d6b89  push rsi
000073ef1c5d6b8a  push r8
000073ef1c5d6b8c  push r9
000073ef1c5d6b8e  push r10
000073ef1c5d6b90  push r11
000073ef1c5d6b92  sub rsp, 0xF0
000073ef1c5d6b99  vmovaps [rsp], xmm0
000073ef1c5d6b9e  vmovaps [rsp+0x10], xmm1
000073ef1c5d6ba4  vmovaps [rsp+0x20], xmm2
000073ef1c5d6baa  vmovaps [rsp+0x30], xmm3
000073ef1c5d6bb0  vmovaps [rsp+0x40], xmm4
000073ef1c5d6bb6  vmovaps [rsp+0x50], xmm5
000073ef1c5d6bbc  vmovaps [rsp+0x60], xmm6
000073ef1c5d6bc2  vmovaps [rsp+0x70], xmm7
000073ef1c5d6bc8  vmovaps [rsp+0x80], xmm8
000073ef1c5d6bd1  vmovaps [rsp+0x90], xmm9
000073ef1c5d6bda  vmovaps [rsp+0xA0], xmm11
000073ef1c5d6be3  vmovaps [rsp+0xB0], xmm12
000073ef1c5d6bec  vmovaps [rsp+0xC0], xmm13
000073ef1c5d6bf5  vmovaps [rsp+0xD0], xmm14
000073ef1c5d6bfe  vmovaps [rsp+0xE0], xmm15
000073ef1c5d6c07  sub rsp, 0x30
000073ef1c5d6c0b  movaps [rsp], xmm10
000073ef1c5d6c10  movaps [rsp+0x10], xmm12
000073ef1c5d6c16  movaps [rsp+0x20], xmm11
000073ef1c5d6c1c  lea rdi, [rsp]
000073ef1c5d6c20  mov esi, 0x00
000073ef1c5d6c25  mov rax, 0x56F25E118530
000073ef1c5d6c2f  call rax
000073ef1c5d6c31  movaps xmm10, [rsp]
000073ef1c5d6c36  add rsp, 0x30
000073ef1c5d6c3a  vmovaps xmm0, [rsp]
000073ef1c5d6c3f  vmovaps xmm1, [rsp+0x10]
000073ef1c5d6c45  vmovaps xmm2, [rsp+0x20]
000073ef1c5d6c4b  vmovaps xmm3, [rsp+0x30]
000073ef1c5d6c51  vmovaps xmm4, [rsp+0x40]
000073ef1c5d6c57  vmovaps xmm5, [rsp+0x50]
000073ef1c5d6c5d  vmovaps xmm6, [rsp+0x60]
000073ef1c5d6c63  vmovaps xmm7, [rsp+0x70]
000073ef1c5d6c69  vmovaps xmm8, [rsp+0x80]
000073ef1c5d6c72  vmovaps xmm9, [rsp+0x90]
000073ef1c5d6c7b  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d6c84  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d6c8d  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d6c96  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d6c9f  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d6ca8  add rsp, 0xF0
000073ef1c5d6caf  pop r11
000073ef1c5d6cb1  pop r10
000073ef1c5d6cb3  pop r9
000073ef1c5d6cb5  pop r8
000073ef1c5d6cb7  pop rsi
000073ef1c5d6cb8  pop rdi
000073ef1c5d6cb9  pop rdx
000073ef1c5d6cba  pop rcx
000073ef1c5d6cbb  pop rax
000073ef1c5d6cbc  add rsp, 0x08
000073ef1c5d6cc0  jmp 0x000073EF1C5D5A06
000073ef1c5d6cc5  sub rsp, 0x08
000073ef1c5d6cc9  push rax
000073ef1c5d6cca  push rcx
000073ef1c5d6ccb  push rdx
000073ef1c5d6ccc  push rdi
000073ef1c5d6ccd  push rsi
000073ef1c5d6cce  push r8
000073ef1c5d6cd0  push r9
000073ef1c5d6cd2  push r10
000073ef1c5d6cd4  push r11
000073ef1c5d6cd6  sub rsp, 0xF0
000073ef1c5d6cdd  vmovaps [rsp], xmm0
000073ef1c5d6ce2  vmovaps [rsp+0x10], xmm1
000073ef1c5d6ce8  vmovaps [rsp+0x20], xmm2
000073ef1c5d6cee  vmovaps [rsp+0x30], xmm3
000073ef1c5d6cf4  vmovaps [rsp+0x40], xmm4
000073ef1c5d6cfa  vmovaps [rsp+0x50], xmm5
000073ef1c5d6d00  vmovaps [rsp+0x60], xmm7
000073ef1c5d6d06  vmovaps [rsp+0x70], xmm8
000073ef1c5d6d0c  vmovaps [rsp+0x80], xmm9
000073ef1c5d6d15  vmovaps [rsp+0x90], xmm10
000073ef1c5d6d1e  vmovaps [rsp+0xA0], xmm11
000073ef1c5d6d27  vmovaps [rsp+0xB0], xmm12
000073ef1c5d6d30  vmovaps [rsp+0xC0], xmm13
000073ef1c5d6d39  vmovaps [rsp+0xD0], xmm14
000073ef1c5d6d42  vmovaps [rsp+0xE0], xmm15
000073ef1c5d6d4b  sub rsp, 0x30
000073ef1c5d6d4f  movaps [rsp], xmm6
000073ef1c5d6d53  movaps [rsp+0x10], xmm12
000073ef1c5d6d59  movaps [rsp+0x20], xmm11
000073ef1c5d6d5f  lea rdi, [rsp]
000073ef1c5d6d63  mov esi, 0x00
000073ef1c5d6d68  mov rax, 0x56F25E118530
000073ef1c5d6d72  call rax
000073ef1c5d6d74  movaps xmm6, [rsp]
000073ef1c5d6d78  add rsp, 0x30
000073ef1c5d6d7c  vmovaps xmm0, [rsp]
000073ef1c5d6d81  vmovaps xmm1, [rsp+0x10]
000073ef1c5d6d87  vmovaps xmm2, [rsp+0x20]
000073ef1c5d6d8d  vmovaps xmm3, [rsp+0x30]
000073ef1c5d6d93  vmovaps xmm4, [rsp+0x40]
000073ef1c5d6d99  vmovaps xmm5, [rsp+0x50]
000073ef1c5d6d9f  vmovaps xmm7, [rsp+0x60]
000073ef1c5d6da5  vmovaps xmm8, [rsp+0x70]
000073ef1c5d6dab  vmovaps xmm9, [rsp+0x80]
000073ef1c5d6db4  vmovaps xmm10, [rsp+0x90]
000073ef1c5d6dbd  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d6dc6  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d6dcf  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d6dd8  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d6de1  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d6dea  add rsp, 0xF0
000073ef1c5d6df1  pop r11
000073ef1c5d6df3  pop r10
000073ef1c5d6df5  pop r9
000073ef1c5d6df7  pop r8
000073ef1c5d6df9  pop rsi
000073ef1c5d6dfa  pop rdi
000073ef1c5d6dfb  pop rdx
000073ef1c5d6dfc  pop rcx
000073ef1c5d6dfd  pop rax
000073ef1c5d6dfe  add rsp, 0x08
000073ef1c5d6e02  jmp 0x000073EF1C5D5A27
000073ef1c5d6e07  sub rsp, 0x08
000073ef1c5d6e0b  push rax
000073ef1c5d6e0c  push rcx
000073ef1c5d6e0d  push rdx
000073ef1c5d6e0e  push rdi
000073ef1c5d6e0f  push rsi
000073ef1c5d6e10  push r8
000073ef1c5d6e12  push r9
000073ef1c5d6e14  push r10
000073ef1c5d6e16  push r11
000073ef1c5d6e18  sub rsp, 0xF0
000073ef1c5d6e1f  vmovaps [rsp], xmm0
000073ef1c5d6e24  vmovaps [rsp+0x10], xmm1
000073ef1c5d6e2a  vmovaps [rsp+0x20], xmm2
000073ef1c5d6e30  vmovaps [rsp+0x30], xmm4
000073ef1c5d6e36  vmovaps [rsp+0x40], xmm5
000073ef1c5d6e3c  vmovaps [rsp+0x50], xmm6
000073ef1c5d6e42  vmovaps [rsp+0x60], xmm7
000073ef1c5d6e48  vmovaps [rsp+0x70], xmm8
000073ef1c5d6e4e  vmovaps [rsp+0x80], xmm9
000073ef1c5d6e57  vmovaps [rsp+0x90], xmm10
000073ef1c5d6e60  vmovaps [rsp+0xA0], xmm11
000073ef1c5d6e69  vmovaps [rsp+0xB0], xmm12
000073ef1c5d6e72  vmovaps [rsp+0xC0], xmm13
000073ef1c5d6e7b  vmovaps [rsp+0xD0], xmm14
000073ef1c5d6e84  vmovaps [rsp+0xE0], xmm15
000073ef1c5d6e8d  sub rsp, 0x30
000073ef1c5d6e91  movaps [rsp], xmm3
000073ef1c5d6e95  movaps [rsp+0x10], xmm5
000073ef1c5d6e9a  movaps [rsp+0x20], xmm4
000073ef1c5d6e9f  lea rdi, [rsp]
000073ef1c5d6ea3  mov esi, 0x00
000073ef1c5d6ea8  mov rax, 0x56F25E118530
000073ef1c5d6eb2  call rax
000073ef1c5d6eb4  movaps xmm3, [rsp]
000073ef1c5d6eb8  add rsp, 0x30
000073ef1c5d6ebc  vmovaps xmm0, [rsp]
000073ef1c5d6ec1  vmovaps xmm1, [rsp+0x10]
000073ef1c5d6ec7  vmovaps xmm2, [rsp+0x20]
000073ef1c5d6ecd  vmovaps xmm4, [rsp+0x30]
000073ef1c5d6ed3  vmovaps xmm5, [rsp+0x40]
000073ef1c5d6ed9  vmovaps xmm6, [rsp+0x50]
000073ef1c5d6edf  vmovaps xmm7, [rsp+0x60]
000073ef1c5d6ee5  vmovaps xmm8, [rsp+0x70]
000073ef1c5d6eeb  vmovaps xmm9, [rsp+0x80]
000073ef1c5d6ef4  vmovaps xmm10, [rsp+0x90]
000073ef1c5d6efd  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d6f06  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d6f0f  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d6f18  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d6f21  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d6f2a  add rsp, 0xF0
000073ef1c5d6f31  pop r11
000073ef1c5d6f33  pop r10
000073ef1c5d6f35  pop r9
000073ef1c5d6f37  pop r8
000073ef1c5d6f39  pop rsi
000073ef1c5d6f3a  pop rdi
000073ef1c5d6f3b  pop rdx
000073ef1c5d6f3c  pop rcx
000073ef1c5d6f3d  pop rax
000073ef1c5d6f3e  add rsp, 0x08
000073ef1c5d6f42  jmp 0x000073EF1C5D5A88
000073ef1c5d6f47  sub rsp, 0x08
000073ef1c5d6f4b  push rax
000073ef1c5d6f4c  push rcx
000073ef1c5d6f4d  push rdx
000073ef1c5d6f4e  push rdi
000073ef1c5d6f4f  push rsi
000073ef1c5d6f50  push r8
000073ef1c5d6f52  push r9
000073ef1c5d6f54  push r10
000073ef1c5d6f56  push r11
000073ef1c5d6f58  sub rsp, 0xF0
000073ef1c5d6f5f  vmovaps [rsp], xmm0
000073ef1c5d6f64  vmovaps [rsp+0x10], xmm1
000073ef1c5d6f6a  vmovaps [rsp+0x20], xmm2
000073ef1c5d6f70  vmovaps [rsp+0x30], xmm3
000073ef1c5d6f76  vmovaps [rsp+0x40], xmm4
000073ef1c5d6f7c  vmovaps [rsp+0x50], xmm6
000073ef1c5d6f82  vmovaps [rsp+0x60], xmm7
000073ef1c5d6f88  vmovaps [rsp+0x70], xmm8
000073ef1c5d6f8e  vmovaps [rsp+0x80], xmm9
000073ef1c5d6f97  vmovaps [rsp+0x90], xmm10
000073ef1c5d6fa0  vmovaps [rsp+0xA0], xmm11
000073ef1c5d6fa9  vmovaps [rsp+0xB0], xmm12
000073ef1c5d6fb2  vmovaps [rsp+0xC0], xmm13
000073ef1c5d6fbb  vmovaps [rsp+0xD0], xmm14
000073ef1c5d6fc4  vmovaps [rsp+0xE0], xmm15
000073ef1c5d6fcd  sub rsp, 0x30
000073ef1c5d6fd1  movaps [rsp], xmm5
000073ef1c5d6fd5  movaps [rsp+0x10], xmm8
000073ef1c5d6fdb  movaps [rsp+0x20], xmm15
000073ef1c5d6fe1  lea rdi, [rsp]
000073ef1c5d6fe5  mov esi, 0x00
000073ef1c5d6fea  mov rax, 0x56F25E118530
000073ef1c5d6ff4  call rax
000073ef1c5d6ff6  movaps xmm5, [rsp]
000073ef1c5d6ffa  add rsp, 0x30
000073ef1c5d6ffe  vmovaps xmm0, [rsp]
000073ef1c5d7003  vmovaps xmm1, [rsp+0x10]
000073ef1c5d7009  vmovaps xmm2, [rsp+0x20]
000073ef1c5d700f  vmovaps xmm3, [rsp+0x30]
000073ef1c5d7015  vmovaps xmm4, [rsp+0x40]
000073ef1c5d701b  vmovaps xmm6, [rsp+0x50]
000073ef1c5d7021  vmovaps xmm7, [rsp+0x60]
000073ef1c5d7027  vmovaps xmm8, [rsp+0x70]
000073ef1c5d702d  vmovaps xmm9, [rsp+0x80]
000073ef1c5d7036  vmovaps xmm10, [rsp+0x90]
000073ef1c5d703f  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d7048  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d7051  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d705a  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d7063  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d706c  add rsp, 0xF0
000073ef1c5d7073  pop r11
000073ef1c5d7075  pop r10
000073ef1c5d7077  pop r9
000073ef1c5d7079  pop r8
000073ef1c5d707b  pop rsi
000073ef1c5d707c  pop rdi
000073ef1c5d707d  pop rdx
000073ef1c5d707e  pop rcx
000073ef1c5d707f  pop rax
000073ef1c5d7080  add rsp, 0x08
000073ef1c5d7084  jmp 0x000073EF1C5D5AC0
000073ef1c5d7089  sub rsp, 0x08
000073ef1c5d708d  push rax
000073ef1c5d708e  push rcx
000073ef1c5d708f  push rdx
000073ef1c5d7090  push rdi
000073ef1c5d7091  push rsi
000073ef1c5d7092  push r8
000073ef1c5d7094  push r9
000073ef1c5d7096  push r10
000073ef1c5d7098  push r11
000073ef1c5d709a  sub rsp, 0xF0
000073ef1c5d70a1  vmovaps [rsp], xmm0
000073ef1c5d70a6  vmovaps [rsp+0x10], xmm1
000073ef1c5d70ac  vmovaps [rsp+0x20], xmm2
000073ef1c5d70b2  vmovaps [rsp+0x30], xmm3
000073ef1c5d70b8  vmovaps [rsp+0x40], xmm5
000073ef1c5d70be  vmovaps [rsp+0x50], xmm6
000073ef1c5d70c4  vmovaps [rsp+0x60], xmm7
000073ef1c5d70ca  vmovaps [rsp+0x70], xmm8
000073ef1c5d70d0  vmovaps [rsp+0x80], xmm9
000073ef1c5d70d9  vmovaps [rsp+0x90], xmm10
000073ef1c5d70e2  vmovaps [rsp+0xA0], xmm11
000073ef1c5d70eb  vmovaps [rsp+0xB0], xmm12
000073ef1c5d70f4  vmovaps [rsp+0xC0], xmm13
000073ef1c5d70fd  vmovaps [rsp+0xD0], xmm14
000073ef1c5d7106  vmovaps [rsp+0xE0], xmm15
000073ef1c5d710f  sub rsp, 0x30
000073ef1c5d7113  movaps [rsp], xmm4
000073ef1c5d7117  movaps [rsp+0x10], xmm9
000073ef1c5d711d  movaps [rsp+0x20], xmm8
000073ef1c5d7123  lea rdi, [rsp]
000073ef1c5d7127  mov esi, 0x00
000073ef1c5d712c  mov rax, 0x56F25E118530
000073ef1c5d7136  call rax
000073ef1c5d7138  movaps xmm4, [rsp]
000073ef1c5d713c  add rsp, 0x30
000073ef1c5d7140  vmovaps xmm0, [rsp]
000073ef1c5d7145  vmovaps xmm1, [rsp+0x10]
000073ef1c5d714b  vmovaps xmm2, [rsp+0x20]
000073ef1c5d7151  vmovaps xmm3, [rsp+0x30]
000073ef1c5d7157  vmovaps xmm5, [rsp+0x40]
000073ef1c5d715d  vmovaps xmm6, [rsp+0x50]
000073ef1c5d7163  vmovaps xmm7, [rsp+0x60]
000073ef1c5d7169  vmovaps xmm8, [rsp+0x70]
000073ef1c5d716f  vmovaps xmm9, [rsp+0x80]
000073ef1c5d7178  vmovaps xmm10, [rsp+0x90]
000073ef1c5d7181  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d718a  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d7193  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d719c  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d71a5  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d71ae  add rsp, 0xF0
000073ef1c5d71b5  pop r11
000073ef1c5d71b7  pop r10
000073ef1c5d71b9  pop r9
000073ef1c5d71bb  pop r8
000073ef1c5d71bd  pop rsi
000073ef1c5d71be  pop rdi
000073ef1c5d71bf  pop rdx
000073ef1c5d71c0  pop rcx
000073ef1c5d71c1  pop rax
000073ef1c5d71c2  add rsp, 0x08
000073ef1c5d71c6  jmp 0x000073EF1C5D5AE1
000073ef1c5d71cb  sub rsp, 0x08
000073ef1c5d71cf  push rax
000073ef1c5d71d0  push rcx
000073ef1c5d71d1  push rdx
000073ef1c5d71d2  push rdi
000073ef1c5d71d3  push rsi
000073ef1c5d71d4  push r8
000073ef1c5d71d6  push r9
000073ef1c5d71d8  push r10
000073ef1c5d71da  push r11
000073ef1c5d71dc  sub rsp, 0xF0
000073ef1c5d71e3  vmovaps [rsp], xmm0
000073ef1c5d71e8  vmovaps [rsp+0x10], xmm1
000073ef1c5d71ee  vmovaps [rsp+0x20], xmm2
000073ef1c5d71f4  vmovaps [rsp+0x30], xmm3
000073ef1c5d71fa  vmovaps [rsp+0x40], xmm4
000073ef1c5d7200  vmovaps [rsp+0x50], xmm5
000073ef1c5d7206  vmovaps [rsp+0x60], xmm6
000073ef1c5d720c  vmovaps [rsp+0x70], xmm7
000073ef1c5d7212  vmovaps [rsp+0x80], xmm8
000073ef1c5d721b  vmovaps [rsp+0x90], xmm10
000073ef1c5d7224  vmovaps [rsp+0xA0], xmm11
000073ef1c5d722d  vmovaps [rsp+0xB0], xmm12
000073ef1c5d7236  vmovaps [rsp+0xC0], xmm13
000073ef1c5d723f  vmovaps [rsp+0xD0], xmm14
000073ef1c5d7248  vmovaps [rsp+0xE0], xmm15
000073ef1c5d7251  sub rsp, 0x30
000073ef1c5d7255  movaps [rsp], xmm9
000073ef1c5d725a  movaps [rsp+0x10], xmm10
000073ef1c5d7260  movaps [rsp+0x20], xmm8
000073ef1c5d7266  lea rdi, [rsp]
000073ef1c5d726a  mov esi, 0x00
000073ef1c5d726f  mov rax, 0x56F25E118530
000073ef1c5d7279  call rax
000073ef1c5d727b  movaps xmm9, [rsp]
000073ef1c5d7280  add rsp, 0x30
000073ef1c5d7284  vmovaps xmm0, [rsp]
000073ef1c5d7289  vmovaps xmm1, [rsp+0x10]
000073ef1c5d728f  vmovaps xmm2, [rsp+0x20]
000073ef1c5d7295  vmovaps xmm3, [rsp+0x30]
000073ef1c5d729b  vmovaps xmm4, [rsp+0x40]
000073ef1c5d72a1  vmovaps xmm5, [rsp+0x50]
000073ef1c5d72a7  vmovaps xmm6, [rsp+0x60]
000073ef1c5d72ad  vmovaps xmm7, [rsp+0x70]
000073ef1c5d72b3  vmovaps xmm8, [rsp+0x80]
000073ef1c5d72bc  vmovaps xmm10, [rsp+0x90]
000073ef1c5d72c5  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d72ce  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d72d7  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d72e0  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d72e9  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d72f2  add rsp, 0xF0
000073ef1c5d72f9  pop r11
000073ef1c5d72fb  pop r10
000073ef1c5d72fd  pop r9
000073ef1c5d72ff  pop r8
000073ef1c5d7301  pop rsi
000073ef1c5d7302  pop rdi
000073ef1c5d7303  pop rdx
000073ef1c5d7304  pop rcx
000073ef1c5d7305  pop rax
000073ef1c5d7306  add rsp, 0x08
000073ef1c5d730a  jmp 0x000073EF1C5D5AFB
000073ef1c5d730f  call 0x000073EF1C4D64F0
000073ef1c5d7314  jmp 0x000073EF1C5D5C15
000073ef1c5d7319  call 0x000073EF1C4D64F0
000073ef1c5d731e  jmp 0x000073EF1C5D5C2B
000073ef1c5d7323  sub rsp, 0x08
000073ef1c5d7327  push rax
000073ef1c5d7328  push rcx
000073ef1c5d7329  push rdx
000073ef1c5d732a  push rdi
000073ef1c5d732b  push rsi
000073ef1c5d732c  push r8
000073ef1c5d732e  push r9
000073ef1c5d7330  push r10
000073ef1c5d7332  push r11
000073ef1c5d7334  sub rsp, 0xF0
000073ef1c5d733b  vmovaps [rsp], xmm0
000073ef1c5d7340  vmovaps [rsp+0x10], xmm2
000073ef1c5d7346  vmovaps [rsp+0x20], xmm3
000073ef1c5d734c  vmovaps [rsp+0x30], xmm4
000073ef1c5d7352  vmovaps [rsp+0x40], xmm5
000073ef1c5d7358  vmovaps [rsp+0x50], xmm6
000073ef1c5d735e  vmovaps [rsp+0x60], xmm7
000073ef1c5d7364  vmovaps [rsp+0x70], xmm8
000073ef1c5d736a  vmovaps [rsp+0x80], xmm9
000073ef1c5d7373  vmovaps [rsp+0x90], xmm10
000073ef1c5d737c  vmovaps [rsp+0xA0], xmm11
000073ef1c5d7385  vmovaps [rsp+0xB0], xmm12
000073ef1c5d738e  vmovaps [rsp+0xC0], xmm13
000073ef1c5d7397  vmovaps [rsp+0xD0], xmm14
000073ef1c5d73a0  vmovaps [rsp+0xE0], xmm15
000073ef1c5d73a9  sub rsp, 0x30
000073ef1c5d73ad  movaps [rsp], xmm1
000073ef1c5d73b1  movaps [rsp+0x10], xmm6
000073ef1c5d73b6  movaps [rsp+0x20], xmm15
000073ef1c5d73bc  lea rdi, [rsp]
000073ef1c5d73c0  mov esi, 0x00
000073ef1c5d73c5  mov rax, 0x56F25E118530
000073ef1c5d73cf  call rax
000073ef1c5d73d1  movaps xmm1, [rsp]
000073ef1c5d73d5  add rsp, 0x30
000073ef1c5d73d9  vmovaps xmm0, [rsp]
000073ef1c5d73de  vmovaps xmm2, [rsp+0x10]
000073ef1c5d73e4  vmovaps xmm3, [rsp+0x20]
000073ef1c5d73ea  vmovaps xmm4, [rsp+0x30]
000073ef1c5d73f0  vmovaps xmm5, [rsp+0x40]
000073ef1c5d73f6  vmovaps xmm6, [rsp+0x50]
000073ef1c5d73fc  vmovaps xmm7, [rsp+0x60]
000073ef1c5d7402  vmovaps xmm8, [rsp+0x70]
000073ef1c5d7408  vmovaps xmm9, [rsp+0x80]
000073ef1c5d7411  vmovaps xmm10, [rsp+0x90]
000073ef1c5d741a  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d7423  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d742c  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d7435  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d743e  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d7447  add rsp, 0xF0
000073ef1c5d744e  pop r11
000073ef1c5d7450  pop r10
000073ef1c5d7452  pop r9
000073ef1c5d7454  pop r8
000073ef1c5d7456  pop rsi
000073ef1c5d7457  pop rdi
000073ef1c5d7458  pop rdx
000073ef1c5d7459  pop rcx
000073ef1c5d745a  pop rax
000073ef1c5d745b  add rsp, 0x08
000073ef1c5d745f  jmp 0x000073EF1C5D5C68
000073ef1c5d7464  call 0x000073EF1C4E5820
000073ef1c5d7469  jmp 0x000073EF1C5D5C75
000073ef1c5d746e  sub rsp, 0x08
000073ef1c5d7472  push rax
000073ef1c5d7473  push rcx
000073ef1c5d7474  push rdx
000073ef1c5d7475  push rdi
000073ef1c5d7476  push rsi
000073ef1c5d7477  push r8
000073ef1c5d7479  push r9
000073ef1c5d747b  push r10
000073ef1c5d747d  push r11
000073ef1c5d747f  sub rsp, 0xF0
000073ef1c5d7486  vmovaps [rsp], xmm0
000073ef1c5d748b  vmovaps [rsp+0x10], xmm1
000073ef1c5d7491  vmovaps [rsp+0x20], xmm2
000073ef1c5d7497  vmovaps [rsp+0x30], xmm3
000073ef1c5d749d  vmovaps [rsp+0x40], xmm4
000073ef1c5d74a3  vmovaps [rsp+0x50], xmm5
000073ef1c5d74a9  vmovaps [rsp+0x60], xmm6
000073ef1c5d74af  vmovaps [rsp+0x70], xmm7
000073ef1c5d74b5  vmovaps [rsp+0x80], xmm8
000073ef1c5d74be  vmovaps [rsp+0x90], xmm9
000073ef1c5d74c7  vmovaps [rsp+0xA0], xmm10
000073ef1c5d74d0  vmovaps [rsp+0xB0], xmm11
000073ef1c5d74d9  vmovaps [rsp+0xC0], xmm12
000073ef1c5d74e2  vmovaps [rsp+0xD0], xmm13
000073ef1c5d74eb  vmovaps [rsp+0xE0], xmm15
000073ef1c5d74f4  sub rsp, 0x30
000073ef1c5d74f8  movaps [rsp], xmm14
000073ef1c5d74fd  movaps [rsp+0x10], xmm4
000073ef1c5d7502  movaps [rsp+0x20], xmm3
000073ef1c5d7507  lea rdi, [rsp]
000073ef1c5d750b  mov esi, 0x00
000073ef1c5d7510  mov rax, 0x56F25E118530
000073ef1c5d751a  call rax
000073ef1c5d751c  movaps xmm14, [rsp]
000073ef1c5d7521  add rsp, 0x30
000073ef1c5d7525  vmovaps xmm0, [rsp]
000073ef1c5d752a  vmovaps xmm1, [rsp+0x10]
000073ef1c5d7530  vmovaps xmm2, [rsp+0x20]
000073ef1c5d7536  vmovaps xmm3, [rsp+0x30]
000073ef1c5d753c  vmovaps xmm4, [rsp+0x40]
000073ef1c5d7542  vmovaps xmm5, [rsp+0x50]
000073ef1c5d7548  vmovaps xmm6, [rsp+0x60]
000073ef1c5d754e  vmovaps xmm7, [rsp+0x70]
000073ef1c5d7554  vmovaps xmm8, [rsp+0x80]
000073ef1c5d755d  vmovaps xmm9, [rsp+0x90]
000073ef1c5d7566  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d756f  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d7578  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d7581  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d758a  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d7593  add rsp, 0xF0
000073ef1c5d759a  pop r11
000073ef1c5d759c  pop r10
000073ef1c5d759e  pop r9
000073ef1c5d75a0  pop r8
000073ef1c5d75a2  pop rsi
000073ef1c5d75a3  pop rdi
000073ef1c5d75a4  pop rdx
000073ef1c5d75a5  pop rcx
000073ef1c5d75a6  pop rax
000073ef1c5d75a7  add rsp, 0x08
000073ef1c5d75ab  jmp 0x000073EF1C5D5C8F
000073ef1c5d75b0  sub rsp, 0x08
000073ef1c5d75b4  push rax
000073ef1c5d75b5  push rcx
000073ef1c5d75b6  push rdx
000073ef1c5d75b7  push rdi
000073ef1c5d75b8  push rsi
000073ef1c5d75b9  push r8
000073ef1c5d75bb  push r9
000073ef1c5d75bd  push r10
000073ef1c5d75bf  push r11
000073ef1c5d75c1  sub rsp, 0xF0
000073ef1c5d75c8  vmovaps [rsp], xmm0
000073ef1c5d75cd  vmovaps [rsp+0x10], xmm1
000073ef1c5d75d3  vmovaps [rsp+0x20], xmm2
000073ef1c5d75d9  vmovaps [rsp+0x30], xmm3
000073ef1c5d75df  vmovaps [rsp+0x40], xmm4
000073ef1c5d75e5  vmovaps [rsp+0x50], xmm5
000073ef1c5d75eb  vmovaps [rsp+0x60], xmm7
000073ef1c5d75f1  vmovaps [rsp+0x70], xmm8
000073ef1c5d75f7  vmovaps [rsp+0x80], xmm9
000073ef1c5d7600  vmovaps [rsp+0x90], xmm10
000073ef1c5d7609  vmovaps [rsp+0xA0], xmm11
000073ef1c5d7612  vmovaps [rsp+0xB0], xmm12
000073ef1c5d761b  vmovaps [rsp+0xC0], xmm13
000073ef1c5d7624  vmovaps [rsp+0xD0], xmm14
000073ef1c5d762d  vmovaps [rsp+0xE0], xmm15
000073ef1c5d7636  sub rsp, 0x30
000073ef1c5d763a  movaps [rsp], xmm6
000073ef1c5d763e  movaps [rsp+0x10], xmm9
000073ef1c5d7644  movaps [rsp+0x20], xmm7
000073ef1c5d7649  lea rdi, [rsp]
000073ef1c5d764d  mov esi, 0x00
000073ef1c5d7652  mov rax, 0x56F25E118530
000073ef1c5d765c  call rax
000073ef1c5d765e  movaps xmm6, [rsp]
000073ef1c5d7662  add rsp, 0x30
000073ef1c5d7666  vmovaps xmm0, [rsp]
000073ef1c5d766b  vmovaps xmm1, [rsp+0x10]
000073ef1c5d7671  vmovaps xmm2, [rsp+0x20]
000073ef1c5d7677  vmovaps xmm3, [rsp+0x30]
000073ef1c5d767d  vmovaps xmm4, [rsp+0x40]
000073ef1c5d7683  vmovaps xmm5, [rsp+0x50]
000073ef1c5d7689  vmovaps xmm7, [rsp+0x60]
000073ef1c5d768f  vmovaps xmm8, [rsp+0x70]
000073ef1c5d7695  vmovaps xmm9, [rsp+0x80]
000073ef1c5d769e  vmovaps xmm10, [rsp+0x90]
000073ef1c5d76a7  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d76b0  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d76b9  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d76c2  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d76cb  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d76d4  add rsp, 0xF0
000073ef1c5d76db  pop r11
000073ef1c5d76dd  pop r10
000073ef1c5d76df  pop r9
000073ef1c5d76e1  pop r8
000073ef1c5d76e3  pop rsi
000073ef1c5d76e4  pop rdi
000073ef1c5d76e5  pop rdx
000073ef1c5d76e6  pop rcx
000073ef1c5d76e7  pop rax
000073ef1c5d76e8  add rsp, 0x08
000073ef1c5d76ec  jmp 0x000073EF1C5D5CA7
000073ef1c5d76f1  sub rsp, 0x08
000073ef1c5d76f5  push rax
000073ef1c5d76f6  push rcx
000073ef1c5d76f7  push rdx
000073ef1c5d76f8  push rdi
000073ef1c5d76f9  push rsi
000073ef1c5d76fa  push r8
000073ef1c5d76fc  push r9
000073ef1c5d76fe  push r10
000073ef1c5d7700  push r11
000073ef1c5d7702  sub rsp, 0xF0
000073ef1c5d7709  vmovaps [rsp], xmm0
000073ef1c5d770e  vmovaps [rsp+0x10], xmm1
000073ef1c5d7714  vmovaps [rsp+0x20], xmm2
000073ef1c5d771a  vmovaps [rsp+0x30], xmm3
000073ef1c5d7720  vmovaps [rsp+0x40], xmm4
000073ef1c5d7726  vmovaps [rsp+0x50], xmm5
000073ef1c5d772c  vmovaps [rsp+0x60], xmm6
000073ef1c5d7732  vmovaps [rsp+0x70], xmm8
000073ef1c5d7738  vmovaps [rsp+0x80], xmm9
000073ef1c5d7741  vmovaps [rsp+0x90], xmm10
000073ef1c5d774a  vmovaps [rsp+0xA0], xmm11
000073ef1c5d7753  vmovaps [rsp+0xB0], xmm12
000073ef1c5d775c  vmovaps [rsp+0xC0], xmm13
000073ef1c5d7765  vmovaps [rsp+0xD0], xmm14
000073ef1c5d776e  vmovaps [rsp+0xE0], xmm15
000073ef1c5d7777  sub rsp, 0x30
000073ef1c5d777b  movaps [rsp], xmm7
000073ef1c5d777f  movaps [rsp+0x10], xmm4
000073ef1c5d7784  movaps [rsp+0x20], xmm9
000073ef1c5d778a  lea rdi, [rsp]
000073ef1c5d778e  mov esi, 0x00
000073ef1c5d7793  mov rax, 0x56F25E118530
000073ef1c5d779d  call rax
000073ef1c5d779f  movaps xmm7, [rsp]
000073ef1c5d77a3  add rsp, 0x30
000073ef1c5d77a7  vmovaps xmm0, [rsp]
000073ef1c5d77ac  vmovaps xmm1, [rsp+0x10]
000073ef1c5d77b2  vmovaps xmm2, [rsp+0x20]
000073ef1c5d77b8  vmovaps xmm3, [rsp+0x30]
000073ef1c5d77be  vmovaps xmm4, [rsp+0x40]
000073ef1c5d77c4  vmovaps xmm5, [rsp+0x50]
000073ef1c5d77ca  vmovaps xmm6, [rsp+0x60]
000073ef1c5d77d0  vmovaps xmm8, [rsp+0x70]
000073ef1c5d77d6  vmovaps xmm9, [rsp+0x80]
000073ef1c5d77df  vmovaps xmm10, [rsp+0x90]
000073ef1c5d77e8  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d77f1  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d77fa  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d7803  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d780c  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d7815  add rsp, 0xF0
000073ef1c5d781c  pop r11
000073ef1c5d781e  pop r10
000073ef1c5d7820  pop r9
000073ef1c5d7822  pop r8
000073ef1c5d7824  pop rsi
000073ef1c5d7825  pop rdi
000073ef1c5d7826  pop rdx
000073ef1c5d7827  pop rcx
000073ef1c5d7828  pop rax
000073ef1c5d7829  add rsp, 0x08
000073ef1c5d782d  jmp 0x000073EF1C5D5CD4
000073ef1c5d7832  sub rsp, 0x08
000073ef1c5d7836  push rax
000073ef1c5d7837  push rcx
000073ef1c5d7838  push rdx
000073ef1c5d7839  push rdi
000073ef1c5d783a  push rsi
000073ef1c5d783b  push r8
000073ef1c5d783d  push r9
000073ef1c5d783f  push r10
000073ef1c5d7841  push r11
000073ef1c5d7843  sub rsp, 0xF0
000073ef1c5d784a  vmovaps [rsp], xmm0
000073ef1c5d784f  vmovaps [rsp+0x10], xmm1
000073ef1c5d7855  vmovaps [rsp+0x20], xmm2
000073ef1c5d785b  vmovaps [rsp+0x30], xmm3
000073ef1c5d7861  vmovaps [rsp+0x40], xmm5
000073ef1c5d7867  vmovaps [rsp+0x50], xmm6
000073ef1c5d786d  vmovaps [rsp+0x60], xmm7
000073ef1c5d7873  vmovaps [rsp+0x70], xmm8
000073ef1c5d7879  vmovaps [rsp+0x80], xmm9
000073ef1c5d7882  vmovaps [rsp+0x90], xmm10
000073ef1c5d788b  vmovaps [rsp+0xA0], xmm11
000073ef1c5d7894  vmovaps [rsp+0xB0], xmm12
000073ef1c5d789d  vmovaps [rsp+0xC0], xmm13
000073ef1c5d78a6  vmovaps [rsp+0xD0], xmm14
000073ef1c5d78af  vmovaps [rsp+0xE0], xmm15
000073ef1c5d78b8  sub rsp, 0x30
000073ef1c5d78bc  movaps [rsp], xmm4
000073ef1c5d78c0  movaps [rsp+0x10], xmm15
000073ef1c5d78c6  movaps [rsp+0x20], xmm9
000073ef1c5d78cc  lea rdi, [rsp]
000073ef1c5d78d0  mov esi, 0x00
000073ef1c5d78d5  mov rax, 0x56F25E118530
000073ef1c5d78df  call rax
000073ef1c5d78e1  movaps xmm4, [rsp]
000073ef1c5d78e5  add rsp, 0x30
000073ef1c5d78e9  vmovaps xmm0, [rsp]
000073ef1c5d78ee  vmovaps xmm1, [rsp+0x10]
000073ef1c5d78f4  vmovaps xmm2, [rsp+0x20]
000073ef1c5d78fa  vmovaps xmm3, [rsp+0x30]
000073ef1c5d7900  vmovaps xmm5, [rsp+0x40]
000073ef1c5d7906  vmovaps xmm6, [rsp+0x50]
000073ef1c5d790c  vmovaps xmm7, [rsp+0x60]
000073ef1c5d7912  vmovaps xmm8, [rsp+0x70]
000073ef1c5d7918  vmovaps xmm9, [rsp+0x80]
000073ef1c5d7921  vmovaps xmm10, [rsp+0x90]
000073ef1c5d792a  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d7933  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d793c  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d7945  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d794e  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d7957  add rsp, 0xF0
000073ef1c5d795e  pop r11
000073ef1c5d7960  pop r10
000073ef1c5d7962  pop r9
000073ef1c5d7964  pop r8
000073ef1c5d7966  pop rsi
000073ef1c5d7967  pop rdi
000073ef1c5d7968  pop rdx
000073ef1c5d7969  pop rcx
000073ef1c5d796a  pop rax
000073ef1c5d796b  add rsp, 0x08
000073ef1c5d796f  jmp 0x000073EF1C5D5CF9
000073ef1c5d7974  call 0x000073EF1C4E5820
000073ef1c5d7979  jmp 0x000073EF1C5D5D06
000073ef1c5d797e  sub rsp, 0x08
000073ef1c5d7982  push rax
000073ef1c5d7983  push rcx
000073ef1c5d7984  push rdx
000073ef1c5d7985  push rdi
000073ef1c5d7986  push rsi
000073ef1c5d7987  push r8
000073ef1c5d7989  push r9
000073ef1c5d798b  push r10
000073ef1c5d798d  push r11
000073ef1c5d798f  sub rsp, 0xF0
000073ef1c5d7996  vmovaps [rsp], xmm0
000073ef1c5d799b  vmovaps [rsp+0x10], xmm1
000073ef1c5d79a1  vmovaps [rsp+0x20], xmm2
000073ef1c5d79a7  vmovaps [rsp+0x30], xmm4
000073ef1c5d79ad  vmovaps [rsp+0x40], xmm5
000073ef1c5d79b3  vmovaps [rsp+0x50], xmm6
000073ef1c5d79b9  vmovaps [rsp+0x60], xmm7
000073ef1c5d79bf  vmovaps [rsp+0x70], xmm8
000073ef1c5d79c5  vmovaps [rsp+0x80], xmm9
000073ef1c5d79ce  vmovaps [rsp+0x90], xmm10
000073ef1c5d79d7  vmovaps [rsp+0xA0], xmm11
000073ef1c5d79e0  vmovaps [rsp+0xB0], xmm12
000073ef1c5d79e9  vmovaps [rsp+0xC0], xmm13
000073ef1c5d79f2  vmovaps [rsp+0xD0], xmm14
000073ef1c5d79fb  vmovaps [rsp+0xE0], xmm15
000073ef1c5d7a04  sub rsp, 0x30
000073ef1c5d7a08  movaps [rsp], xmm3
000073ef1c5d7a0c  movaps [rsp+0x10], xmm1
000073ef1c5d7a11  movaps [rsp+0x20], xmm9
000073ef1c5d7a17  lea rdi, [rsp]
000073ef1c5d7a1b  mov esi, 0x00
000073ef1c5d7a20  mov rax, 0x56F25E118530
000073ef1c5d7a2a  call rax
000073ef1c5d7a2c  movaps xmm3, [rsp]
000073ef1c5d7a30  add rsp, 0x30
000073ef1c5d7a34  vmovaps xmm0, [rsp]
000073ef1c5d7a39  vmovaps xmm1, [rsp+0x10]
000073ef1c5d7a3f  vmovaps xmm2, [rsp+0x20]
000073ef1c5d7a45  vmovaps xmm4, [rsp+0x30]
000073ef1c5d7a4b  vmovaps xmm5, [rsp+0x40]
000073ef1c5d7a51  vmovaps xmm6, [rsp+0x50]
000073ef1c5d7a57  vmovaps xmm7, [rsp+0x60]
000073ef1c5d7a5d  vmovaps xmm8, [rsp+0x70]
000073ef1c5d7a63  vmovaps xmm9, [rsp+0x80]
000073ef1c5d7a6c  vmovaps xmm10, [rsp+0x90]
000073ef1c5d7a75  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d7a7e  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d7a87  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d7a90  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d7a99  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d7aa2  add rsp, 0xF0
000073ef1c5d7aa9  pop r11
000073ef1c5d7aab  pop r10
000073ef1c5d7aad  pop r9
000073ef1c5d7aaf  pop r8
000073ef1c5d7ab1  pop rsi
000073ef1c5d7ab2  pop rdi
000073ef1c5d7ab3  pop rdx
000073ef1c5d7ab4  pop rcx
000073ef1c5d7ab5  pop rax
000073ef1c5d7ab6  add rsp, 0x08
000073ef1c5d7aba  jmp 0x000073EF1C5D5D43
000073ef1c5d7abf  sub rsp, 0x08
000073ef1c5d7ac3  push rax
000073ef1c5d7ac4  push rcx
000073ef1c5d7ac5  push rdx
000073ef1c5d7ac6  push rdi
000073ef1c5d7ac7  push rsi
000073ef1c5d7ac8  push r8
000073ef1c5d7aca  push r9
000073ef1c5d7acc  push r10
000073ef1c5d7ace  push r11
000073ef1c5d7ad0  sub rsp, 0xF0
000073ef1c5d7ad7  vmovaps [rsp], xmm0
000073ef1c5d7adc  vmovaps [rsp+0x10], xmm2
000073ef1c5d7ae2  vmovaps [rsp+0x20], xmm3
000073ef1c5d7ae8  vmovaps [rsp+0x30], xmm4
000073ef1c5d7aee  vmovaps [rsp+0x40], xmm5
000073ef1c5d7af4  vmovaps [rsp+0x50], xmm6
000073ef1c5d7afa  vmovaps [rsp+0x60], xmm7
000073ef1c5d7b00  vmovaps [rsp+0x70], xmm8
000073ef1c5d7b06  vmovaps [rsp+0x80], xmm9
000073ef1c5d7b0f  vmovaps [rsp+0x90], xmm10
000073ef1c5d7b18  vmovaps [rsp+0xA0], xmm11
000073ef1c5d7b21  vmovaps [rsp+0xB0], xmm12
000073ef1c5d7b2a  vmovaps [rsp+0xC0], xmm13
000073ef1c5d7b33  vmovaps [rsp+0xD0], xmm14
000073ef1c5d7b3c  vmovaps [rsp+0xE0], xmm15
000073ef1c5d7b45  sub rsp, 0x30
000073ef1c5d7b49  movaps [rsp], xmm1
000073ef1c5d7b4d  movaps [rsp+0x10], xmm15
000073ef1c5d7b53  movaps [rsp+0x20], xmm9
000073ef1c5d7b59  lea rdi, [rsp]
000073ef1c5d7b5d  mov esi, 0x00
000073ef1c5d7b62  mov rax, 0x56F25E118530
000073ef1c5d7b6c  call rax
000073ef1c5d7b6e  movaps xmm1, [rsp]
000073ef1c5d7b72  add rsp, 0x30
000073ef1c5d7b76  vmovaps xmm0, [rsp]
000073ef1c5d7b7b  vmovaps xmm2, [rsp+0x10]
000073ef1c5d7b81  vmovaps xmm3, [rsp+0x20]
000073ef1c5d7b87  vmovaps xmm4, [rsp+0x30]
000073ef1c5d7b8d  vmovaps xmm5, [rsp+0x40]
000073ef1c5d7b93  vmovaps xmm6, [rsp+0x50]
000073ef1c5d7b99  vmovaps xmm7, [rsp+0x60]
000073ef1c5d7b9f  vmovaps xmm8, [rsp+0x70]
000073ef1c5d7ba5  vmovaps xmm9, [rsp+0x80]
000073ef1c5d7bae  vmovaps xmm10, [rsp+0x90]
000073ef1c5d7bb7  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d7bc0  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d7bc9  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d7bd2  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d7bdb  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d7be4  add rsp, 0xF0
000073ef1c5d7beb  pop r11
000073ef1c5d7bed  pop r10
000073ef1c5d7bef  pop r9
000073ef1c5d7bf1  pop r8
000073ef1c5d7bf3  pop rsi
000073ef1c5d7bf4  pop rdi
000073ef1c5d7bf5  pop rdx
000073ef1c5d7bf6  pop rcx
000073ef1c5d7bf7  pop rax
000073ef1c5d7bf8  add rsp, 0x08
000073ef1c5d7bfc  jmp 0x000073EF1C5D5DCB
000073ef1c5d7c01  call 0x000073EF1C4E5820
000073ef1c5d7c06  jmp 0x000073EF1C5D5DD8
000073ef1c5d7c0b  sub rsp, 0x08
000073ef1c5d7c0f  push rax
000073ef1c5d7c10  push rcx
000073ef1c5d7c11  push rdx
000073ef1c5d7c12  push rdi
000073ef1c5d7c13  push rsi
000073ef1c5d7c14  push r8
000073ef1c5d7c16  push r9
000073ef1c5d7c18  push r10
000073ef1c5d7c1a  push r11
000073ef1c5d7c1c  sub rsp, 0xF0
000073ef1c5d7c23  vmovaps [rsp], xmm0
000073ef1c5d7c28  vmovaps [rsp+0x10], xmm2
000073ef1c5d7c2e  vmovaps [rsp+0x20], xmm3
000073ef1c5d7c34  vmovaps [rsp+0x30], xmm4
000073ef1c5d7c3a  vmovaps [rsp+0x40], xmm5
000073ef1c5d7c40  vmovaps [rsp+0x50], xmm6
000073ef1c5d7c46  vmovaps [rsp+0x60], xmm7
000073ef1c5d7c4c  vmovaps [rsp+0x70], xmm8
000073ef1c5d7c52  vmovaps [rsp+0x80], xmm9
000073ef1c5d7c5b  vmovaps [rsp+0x90], xmm10
000073ef1c5d7c64  vmovaps [rsp+0xA0], xmm11
000073ef1c5d7c6d  vmovaps [rsp+0xB0], xmm12
000073ef1c5d7c76  vmovaps [rsp+0xC0], xmm13
000073ef1c5d7c7f  vmovaps [rsp+0xD0], xmm14
000073ef1c5d7c88  vmovaps [rsp+0xE0], xmm15
000073ef1c5d7c91  sub rsp, 0x30
000073ef1c5d7c95  movaps [rsp], xmm1
000073ef1c5d7c99  movaps [rsp+0x10], xmm5
000073ef1c5d7c9e  movaps [rsp+0x20], xmm7
000073ef1c5d7ca3  lea rdi, [rsp]
000073ef1c5d7ca7  mov esi, 0x00
000073ef1c5d7cac  mov rax, 0x56F25E118530
000073ef1c5d7cb6  call rax
000073ef1c5d7cb8  movaps xmm1, [rsp]
000073ef1c5d7cbc  add rsp, 0x30
000073ef1c5d7cc0  vmovaps xmm0, [rsp]
000073ef1c5d7cc5  vmovaps xmm2, [rsp+0x10]
000073ef1c5d7ccb  vmovaps xmm3, [rsp+0x20]
000073ef1c5d7cd1  vmovaps xmm4, [rsp+0x30]
000073ef1c5d7cd7  vmovaps xmm5, [rsp+0x40]
000073ef1c5d7cdd  vmovaps xmm6, [rsp+0x50]
000073ef1c5d7ce3  vmovaps xmm7, [rsp+0x60]
000073ef1c5d7ce9  vmovaps xmm8, [rsp+0x70]
000073ef1c5d7cef  vmovaps xmm9, [rsp+0x80]
000073ef1c5d7cf8  vmovaps xmm10, [rsp+0x90]
000073ef1c5d7d01  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d7d0a  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d7d13  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d7d1c  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d7d25  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d7d2e  add rsp, 0xF0
000073ef1c5d7d35  pop r11
000073ef1c5d7d37  pop r10
000073ef1c5d7d39  pop r9
000073ef1c5d7d3b  pop r8
000073ef1c5d7d3d  pop rsi
000073ef1c5d7d3e  pop rdi
000073ef1c5d7d3f  pop rdx
000073ef1c5d7d40  pop rcx
000073ef1c5d7d41  pop rax
000073ef1c5d7d42  add rsp, 0x08
000073ef1c5d7d46  jmp 0x000073EF1C5D5E7D
000073ef1c5d7d4b  sub rsp, 0x08
000073ef1c5d7d4f  push rax
000073ef1c5d7d50  push rcx
000073ef1c5d7d51  push rdx
000073ef1c5d7d52  push rdi
000073ef1c5d7d53  push rsi
000073ef1c5d7d54  push r8
000073ef1c5d7d56  push r9
000073ef1c5d7d58  push r10
000073ef1c5d7d5a  push r11
000073ef1c5d7d5c  sub rsp, 0xF0
000073ef1c5d7d63  vmovaps [rsp], xmm0
000073ef1c5d7d68  vmovaps [rsp+0x10], xmm1
000073ef1c5d7d6e  vmovaps [rsp+0x20], xmm2
000073ef1c5d7d74  vmovaps [rsp+0x30], xmm3
000073ef1c5d7d7a  vmovaps [rsp+0x40], xmm4
000073ef1c5d7d80  vmovaps [rsp+0x50], xmm5
000073ef1c5d7d86  vmovaps [rsp+0x60], xmm6
000073ef1c5d7d8c  vmovaps [rsp+0x70], xmm8
000073ef1c5d7d92  vmovaps [rsp+0x80], xmm9
000073ef1c5d7d9b  vmovaps [rsp+0x90], xmm10
000073ef1c5d7da4  vmovaps [rsp+0xA0], xmm11
000073ef1c5d7dad  vmovaps [rsp+0xB0], xmm12
000073ef1c5d7db6  vmovaps [rsp+0xC0], xmm13
000073ef1c5d7dbf  vmovaps [rsp+0xD0], xmm14
000073ef1c5d7dc8  vmovaps [rsp+0xE0], xmm15
000073ef1c5d7dd1  sub rsp, 0x30
000073ef1c5d7dd5  movaps [rsp], xmm7
000073ef1c5d7dd9  movaps [rsp+0x10], xmm5
000073ef1c5d7dde  movaps [rsp+0x20], xmm15
000073ef1c5d7de4  lea rdi, [rsp]
000073ef1c5d7de8  mov esi, 0x00
000073ef1c5d7ded  mov rax, 0x56F25E118530
000073ef1c5d7df7  call rax
000073ef1c5d7df9  movaps xmm7, [rsp]
000073ef1c5d7dfd  add rsp, 0x30
000073ef1c5d7e01  vmovaps xmm0, [rsp]
000073ef1c5d7e06  vmovaps xmm1, [rsp+0x10]
000073ef1c5d7e0c  vmovaps xmm2, [rsp+0x20]
000073ef1c5d7e12  vmovaps xmm3, [rsp+0x30]
000073ef1c5d7e18  vmovaps xmm4, [rsp+0x40]
000073ef1c5d7e1e  vmovaps xmm5, [rsp+0x50]
000073ef1c5d7e24  vmovaps xmm6, [rsp+0x60]
000073ef1c5d7e2a  vmovaps xmm8, [rsp+0x70]
000073ef1c5d7e30  vmovaps xmm9, [rsp+0x80]
000073ef1c5d7e39  vmovaps xmm10, [rsp+0x90]
000073ef1c5d7e42  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d7e4b  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d7e54  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d7e5d  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d7e66  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d7e6f  add rsp, 0xF0
000073ef1c5d7e76  pop r11
000073ef1c5d7e78  pop r10
000073ef1c5d7e7a  pop r9
000073ef1c5d7e7c  pop r8
000073ef1c5d7e7e  pop rsi
000073ef1c5d7e7f  pop rdi
000073ef1c5d7e80  pop rdx
000073ef1c5d7e81  pop rcx
000073ef1c5d7e82  pop rax
000073ef1c5d7e83  add rsp, 0x08
000073ef1c5d7e87  jmp 0x000073EF1C5D5EB3
000073ef1c5d7e8c  call 0x000073EF1C4D64F0
000073ef1c5d7e91  jmp 0x000073EF1C5D5EC0
000073ef1c5d7e96  sub rsp, 0x08
000073ef1c5d7e9a  push rax
000073ef1c5d7e9b  push rcx
000073ef1c5d7e9c  push rdx
000073ef1c5d7e9d  push rdi
000073ef1c5d7e9e  push rsi
000073ef1c5d7e9f  push r8
000073ef1c5d7ea1  push r9
000073ef1c5d7ea3  push r10
000073ef1c5d7ea5  push r11
000073ef1c5d7ea7  sub rsp, 0xF0
000073ef1c5d7eae  vmovaps [rsp], xmm0
000073ef1c5d7eb3  vmovaps [rsp+0x10], xmm1
000073ef1c5d7eb9  vmovaps [rsp+0x20], xmm2
000073ef1c5d7ebf  vmovaps [rsp+0x30], xmm3
000073ef1c5d7ec5  vmovaps [rsp+0x40], xmm4
000073ef1c5d7ecb  vmovaps [rsp+0x50], xmm5
000073ef1c5d7ed1  vmovaps [rsp+0x60], xmm6
000073ef1c5d7ed7  vmovaps [rsp+0x70], xmm7
000073ef1c5d7edd  vmovaps [rsp+0x80], xmm8
000073ef1c5d7ee6  vmovaps [rsp+0x90], xmm9
000073ef1c5d7eef  vmovaps [rsp+0xA0], xmm10
000073ef1c5d7ef8  vmovaps [rsp+0xB0], xmm11
000073ef1c5d7f01  vmovaps [rsp+0xC0], xmm12
000073ef1c5d7f0a  vmovaps [rsp+0xD0], xmm13
000073ef1c5d7f13  vmovaps [rsp+0xE0], xmm14
000073ef1c5d7f1c  sub rsp, 0x30
000073ef1c5d7f20  movaps [rsp], xmm15
000073ef1c5d7f25  movaps [rsp+0x10], xmm5
000073ef1c5d7f2a  movaps [rsp+0x20], xmm3
000073ef1c5d7f2f  lea rdi, [rsp]
000073ef1c5d7f33  mov esi, 0x00
000073ef1c5d7f38  mov rax, 0x56F25E118530
000073ef1c5d7f42  call rax
000073ef1c5d7f44  movaps xmm15, [rsp]
000073ef1c5d7f49  add rsp, 0x30
000073ef1c5d7f4d  vmovaps xmm0, [rsp]
000073ef1c5d7f52  vmovaps xmm1, [rsp+0x10]
000073ef1c5d7f58  vmovaps xmm2, [rsp+0x20]
000073ef1c5d7f5e  vmovaps xmm3, [rsp+0x30]
000073ef1c5d7f64  vmovaps xmm4, [rsp+0x40]
000073ef1c5d7f6a  vmovaps xmm5, [rsp+0x50]
000073ef1c5d7f70  vmovaps xmm6, [rsp+0x60]
000073ef1c5d7f76  vmovaps xmm7, [rsp+0x70]
000073ef1c5d7f7c  vmovaps xmm8, [rsp+0x80]
000073ef1c5d7f85  vmovaps xmm9, [rsp+0x90]
000073ef1c5d7f8e  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d7f97  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d7fa0  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d7fa9  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d7fb2  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d7fbb  add rsp, 0xF0
000073ef1c5d7fc2  pop r11
000073ef1c5d7fc4  pop r10
000073ef1c5d7fc6  pop r9
000073ef1c5d7fc8  pop r8
000073ef1c5d7fca  pop rsi
000073ef1c5d7fcb  pop rdi
000073ef1c5d7fcc  pop rdx
000073ef1c5d7fcd  pop rcx
000073ef1c5d7fce  pop rax
000073ef1c5d7fcf  add rsp, 0x08
000073ef1c5d7fd3  jmp 0x000073EF1C5D5EE6
000073ef1c5d7fd8  sub rsp, 0x08
000073ef1c5d7fdc  push rax
000073ef1c5d7fdd  push rcx
000073ef1c5d7fde  push rdx
000073ef1c5d7fdf  push rdi
000073ef1c5d7fe0  push rsi
000073ef1c5d7fe1  push r8
000073ef1c5d7fe3  push r9
000073ef1c5d7fe5  push r10
000073ef1c5d7fe7  push r11
000073ef1c5d7fe9  sub rsp, 0xF0
000073ef1c5d7ff0  vmovaps [rsp], xmm0
000073ef1c5d7ff5  vmovaps [rsp+0x10], xmm2
000073ef1c5d7ffb  vmovaps [rsp+0x20], xmm3
000073ef1c5d8001  vmovaps [rsp+0x30], xmm4
000073ef1c5d8007  vmovaps [rsp+0x40], xmm5
000073ef1c5d800d  vmovaps [rsp+0x50], xmm6
000073ef1c5d8013  vmovaps [rsp+0x60], xmm7
000073ef1c5d8019  vmovaps [rsp+0x70], xmm8
000073ef1c5d801f  vmovaps [rsp+0x80], xmm9
000073ef1c5d8028  vmovaps [rsp+0x90], xmm10
000073ef1c5d8031  vmovaps [rsp+0xA0], xmm11
000073ef1c5d803a  vmovaps [rsp+0xB0], xmm12
000073ef1c5d8043  vmovaps [rsp+0xC0], xmm13
000073ef1c5d804c  vmovaps [rsp+0xD0], xmm14
000073ef1c5d8055  vmovaps [rsp+0xE0], xmm15
000073ef1c5d805e  sub rsp, 0x30
000073ef1c5d8062  movaps [rsp], xmm1
000073ef1c5d8066  movaps [rsp+0x10], xmm5
000073ef1c5d806b  movaps [rsp+0x20], xmm4
000073ef1c5d8070  lea rdi, [rsp]
000073ef1c5d8074  mov esi, 0x00
000073ef1c5d8079  mov rax, 0x56F25E118530
000073ef1c5d8083  call rax
000073ef1c5d8085  movaps xmm1, [rsp]
000073ef1c5d8089  add rsp, 0x30
000073ef1c5d808d  vmovaps xmm0, [rsp]
000073ef1c5d8092  vmovaps xmm2, [rsp+0x10]
000073ef1c5d8098  vmovaps xmm3, [rsp+0x20]
000073ef1c5d809e  vmovaps xmm4, [rsp+0x30]
000073ef1c5d80a4  vmovaps xmm5, [rsp+0x40]
000073ef1c5d80aa  vmovaps xmm6, [rsp+0x50]
000073ef1c5d80b0  vmovaps xmm7, [rsp+0x60]
000073ef1c5d80b6  vmovaps xmm8, [rsp+0x70]
000073ef1c5d80bc  vmovaps xmm9, [rsp+0x80]
000073ef1c5d80c5  vmovaps xmm10, [rsp+0x90]
000073ef1c5d80ce  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d80d7  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d80e0  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d80e9  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d80f2  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d80fb  add rsp, 0xF0
000073ef1c5d8102  pop r11
000073ef1c5d8104  pop r10
000073ef1c5d8106  pop r9
000073ef1c5d8108  pop r8
000073ef1c5d810a  pop rsi
000073ef1c5d810b  pop rdi
000073ef1c5d810c  pop rdx
000073ef1c5d810d  pop rcx
000073ef1c5d810e  pop rax
000073ef1c5d810f  add rsp, 0x08
000073ef1c5d8113  jmp 0x000073EF1C5D5F06
000073ef1c5d8118  sub rsp, 0x08
000073ef1c5d811c  push rax
000073ef1c5d811d  push rcx
000073ef1c5d811e  push rdx
000073ef1c5d811f  push rdi
000073ef1c5d8120  push rsi
000073ef1c5d8121  push r8
000073ef1c5d8123  push r9
000073ef1c5d8125  push r10
000073ef1c5d8127  push r11
000073ef1c5d8129  sub rsp, 0xF0
000073ef1c5d8130  vmovaps [rsp], xmm0
000073ef1c5d8135  vmovaps [rsp+0x10], xmm1
000073ef1c5d813b  vmovaps [rsp+0x20], xmm2
000073ef1c5d8141  vmovaps [rsp+0x30], xmm3
000073ef1c5d8147  vmovaps [rsp+0x40], xmm5
000073ef1c5d814d  vmovaps [rsp+0x50], xmm6
000073ef1c5d8153  vmovaps [rsp+0x60], xmm7
000073ef1c5d8159  vmovaps [rsp+0x70], xmm8
000073ef1c5d815f  vmovaps [rsp+0x80], xmm9
000073ef1c5d8168  vmovaps [rsp+0x90], xmm10
000073ef1c5d8171  vmovaps [rsp+0xA0], xmm11
000073ef1c5d817a  vmovaps [rsp+0xB0], xmm12
000073ef1c5d8183  vmovaps [rsp+0xC0], xmm13
000073ef1c5d818c  vmovaps [rsp+0xD0], xmm14
000073ef1c5d8195  vmovaps [rsp+0xE0], xmm15
000073ef1c5d819e  sub rsp, 0x30
000073ef1c5d81a2  movaps [rsp], xmm4
000073ef1c5d81a6  movaps [rsp+0x10], xmm3
000073ef1c5d81ab  movaps [rsp+0x20], xmm5
000073ef1c5d81b0  lea rdi, [rsp]
000073ef1c5d81b4  mov esi, 0x00
000073ef1c5d81b9  mov rax, 0x56F25E118530
000073ef1c5d81c3  call rax
000073ef1c5d81c5  movaps xmm4, [rsp]
000073ef1c5d81c9  add rsp, 0x30
000073ef1c5d81cd  vmovaps xmm0, [rsp]
000073ef1c5d81d2  vmovaps xmm1, [rsp+0x10]
000073ef1c5d81d8  vmovaps xmm2, [rsp+0x20]
000073ef1c5d81de  vmovaps xmm3, [rsp+0x30]
000073ef1c5d81e4  vmovaps xmm5, [rsp+0x40]
000073ef1c5d81ea  vmovaps xmm6, [rsp+0x50]
000073ef1c5d81f0  vmovaps xmm7, [rsp+0x60]
000073ef1c5d81f6  vmovaps xmm8, [rsp+0x70]
000073ef1c5d81fc  vmovaps xmm9, [rsp+0x80]
000073ef1c5d8205  vmovaps xmm10, [rsp+0x90]
000073ef1c5d820e  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d8217  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d8220  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d8229  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d8232  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d823b  add rsp, 0xF0
000073ef1c5d8242  pop r11
000073ef1c5d8244  pop r10
000073ef1c5d8246  pop r9
000073ef1c5d8248  pop r8
000073ef1c5d824a  pop rsi
000073ef1c5d824b  pop rdi
000073ef1c5d824c  pop rdx
000073ef1c5d824d  pop rcx
000073ef1c5d824e  pop rax
000073ef1c5d824f  add rsp, 0x08
000073ef1c5d8253  jmp 0x000073EF1C5D5F54
000073ef1c5d8258  call 0x000073EF1C4D64F0
000073ef1c5d825d  jmp 0x000073EF1C5D5F61
000073ef1c5d8262  sub rsp, 0x08
000073ef1c5d8266  push rax
000073ef1c5d8267  push rcx
000073ef1c5d8268  push rdx
000073ef1c5d8269  push rdi
000073ef1c5d826a  push rsi
000073ef1c5d826b  push r8
000073ef1c5d826d  push r9
000073ef1c5d826f  push r10
000073ef1c5d8271  push r11
000073ef1c5d8273  sub rsp, 0xF0
000073ef1c5d827a  vmovaps [rsp], xmm0
000073ef1c5d827f  vmovaps [rsp+0x10], xmm1
000073ef1c5d8285  vmovaps [rsp+0x20], xmm2
000073ef1c5d828b  vmovaps [rsp+0x30], xmm3
000073ef1c5d8291  vmovaps [rsp+0x40], xmm4
000073ef1c5d8297  vmovaps [rsp+0x50], xmm6
000073ef1c5d829d  vmovaps [rsp+0x60], xmm7
000073ef1c5d82a3  vmovaps [rsp+0x70], xmm8
000073ef1c5d82a9  vmovaps [rsp+0x80], xmm9
000073ef1c5d82b2  vmovaps [rsp+0x90], xmm10
000073ef1c5d82bb  vmovaps [rsp+0xA0], xmm11
000073ef1c5d82c4  vmovaps [rsp+0xB0], xmm12
000073ef1c5d82cd  vmovaps [rsp+0xC0], xmm13
000073ef1c5d82d6  vmovaps [rsp+0xD0], xmm14
000073ef1c5d82df  vmovaps [rsp+0xE0], xmm15
000073ef1c5d82e8  sub rsp, 0x30
000073ef1c5d82ec  movaps [rsp], xmm5
000073ef1c5d82f0  movaps [rsp+0x10], xmm6
000073ef1c5d82f5  movaps [rsp+0x20], xmm3
000073ef1c5d82fa  lea rdi, [rsp]
000073ef1c5d82fe  mov esi, 0x00
000073ef1c5d8303  mov rax, 0x56F25E118530
000073ef1c5d830d  call rax
000073ef1c5d830f  movaps xmm5, [rsp]
000073ef1c5d8313  add rsp, 0x30
000073ef1c5d8317  vmovaps xmm0, [rsp]
000073ef1c5d831c  vmovaps xmm1, [rsp+0x10]
000073ef1c5d8322  vmovaps xmm2, [rsp+0x20]
000073ef1c5d8328  vmovaps xmm3, [rsp+0x30]
000073ef1c5d832e  vmovaps xmm4, [rsp+0x40]
000073ef1c5d8334  vmovaps xmm6, [rsp+0x50]
000073ef1c5d833a  vmovaps xmm7, [rsp+0x60]
000073ef1c5d8340  vmovaps xmm8, [rsp+0x70]
000073ef1c5d8346  vmovaps xmm9, [rsp+0x80]
000073ef1c5d834f  vmovaps xmm10, [rsp+0x90]
000073ef1c5d8358  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d8361  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d836a  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d8373  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d837c  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d8385  add rsp, 0xF0
000073ef1c5d838c  pop r11
000073ef1c5d838e  pop r10
000073ef1c5d8390  pop r9
000073ef1c5d8392  pop r8
000073ef1c5d8394  pop rsi
000073ef1c5d8395  pop rdi
000073ef1c5d8396  pop rdx
000073ef1c5d8397  pop rcx
000073ef1c5d8398  pop rax
000073ef1c5d8399  add rsp, 0x08
000073ef1c5d839d  jmp 0x000073EF1C5D5F87
000073ef1c5d83a2  sub rsp, 0x08
000073ef1c5d83a6  push rax
000073ef1c5d83a7  push rcx
000073ef1c5d83a8  push rdx
000073ef1c5d83a9  push rdi
000073ef1c5d83aa  push rsi
000073ef1c5d83ab  push r8
000073ef1c5d83ad  push r9
000073ef1c5d83af  push r10
000073ef1c5d83b1  push r11
000073ef1c5d83b3  sub rsp, 0xF0
000073ef1c5d83ba  vmovaps [rsp], xmm0
000073ef1c5d83bf  vmovaps [rsp+0x10], xmm1
000073ef1c5d83c5  vmovaps [rsp+0x20], xmm2
000073ef1c5d83cb  vmovaps [rsp+0x30], xmm3
000073ef1c5d83d1  vmovaps [rsp+0x40], xmm4
000073ef1c5d83d7  vmovaps [rsp+0x50], xmm5
000073ef1c5d83dd  vmovaps [rsp+0x60], xmm7
000073ef1c5d83e3  vmovaps [rsp+0x70], xmm8
000073ef1c5d83e9  vmovaps [rsp+0x80], xmm9
000073ef1c5d83f2  vmovaps [rsp+0x90], xmm10
000073ef1c5d83fb  vmovaps [rsp+0xA0], xmm11
000073ef1c5d8404  vmovaps [rsp+0xB0], xmm12
000073ef1c5d840d  vmovaps [rsp+0xC0], xmm13
000073ef1c5d8416  vmovaps [rsp+0xD0], xmm14
000073ef1c5d841f  vmovaps [rsp+0xE0], xmm15
000073ef1c5d8428  sub rsp, 0x30
000073ef1c5d842c  movaps [rsp], xmm6
000073ef1c5d8430  movaps [rsp+0x10], xmm9
000073ef1c5d8436  movaps [rsp+0x20], xmm1
000073ef1c5d843b  lea rdi, [rsp]
000073ef1c5d843f  mov esi, 0x00
000073ef1c5d8444  mov rax, 0x56F25E118530
000073ef1c5d844e  call rax
000073ef1c5d8450  movaps xmm6, [rsp]
000073ef1c5d8454  add rsp, 0x30
000073ef1c5d8458  vmovaps xmm0, [rsp]
000073ef1c5d845d  vmovaps xmm1, [rsp+0x10]
000073ef1c5d8463  vmovaps xmm2, [rsp+0x20]
000073ef1c5d8469  vmovaps xmm3, [rsp+0x30]
000073ef1c5d846f  vmovaps xmm4, [rsp+0x40]
000073ef1c5d8475  vmovaps xmm5, [rsp+0x50]
000073ef1c5d847b  vmovaps xmm7, [rsp+0x60]
000073ef1c5d8481  vmovaps xmm8, [rsp+0x70]
000073ef1c5d8487  vmovaps xmm9, [rsp+0x80]
000073ef1c5d8490  vmovaps xmm10, [rsp+0x90]
000073ef1c5d8499  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d84a2  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d84ab  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d84b4  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d84bd  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d84c6  add rsp, 0xF0
000073ef1c5d84cd  pop r11
000073ef1c5d84cf  pop r10
000073ef1c5d84d1  pop r9
000073ef1c5d84d3  pop r8
000073ef1c5d84d5  pop rsi
000073ef1c5d84d6  pop rdi
000073ef1c5d84d7  pop rdx
000073ef1c5d84d8  pop rcx
000073ef1c5d84d9  pop rax
000073ef1c5d84da  add rsp, 0x08
000073ef1c5d84de  jmp 0x000073EF1C5D5FAB
000073ef1c5d84e3  sub rsp, 0x08
000073ef1c5d84e7  push rax
000073ef1c5d84e8  push rcx
000073ef1c5d84e9  push rdx
000073ef1c5d84ea  push rdi
000073ef1c5d84eb  push rsi
000073ef1c5d84ec  push r8
000073ef1c5d84ee  push r9
000073ef1c5d84f0  push r10
000073ef1c5d84f2  push r11
000073ef1c5d84f4  sub rsp, 0xF0
000073ef1c5d84fb  vmovaps [rsp], xmm0
000073ef1c5d8500  vmovaps [rsp+0x10], xmm1
000073ef1c5d8506  vmovaps [rsp+0x20], xmm2
000073ef1c5d850c  vmovaps [rsp+0x30], xmm3
000073ef1c5d8512  vmovaps [rsp+0x40], xmm4
000073ef1c5d8518  vmovaps [rsp+0x50], xmm5
000073ef1c5d851e  vmovaps [rsp+0x60], xmm6
000073ef1c5d8524  vmovaps [rsp+0x70], xmm7
000073ef1c5d852a  vmovaps [rsp+0x80], xmm8
000073ef1c5d8533  vmovaps [rsp+0x90], xmm10
000073ef1c5d853c  vmovaps [rsp+0xA0], xmm11
000073ef1c5d8545  vmovaps [rsp+0xB0], xmm12
000073ef1c5d854e  vmovaps [rsp+0xC0], xmm13
000073ef1c5d8557  vmovaps [rsp+0xD0], xmm14
000073ef1c5d8560  vmovaps [rsp+0xE0], xmm15
000073ef1c5d8569  sub rsp, 0x30
000073ef1c5d856d  movaps [rsp], xmm9
000073ef1c5d8572  movaps [rsp+0x10], xmm3
000073ef1c5d8577  movaps [rsp+0x20], xmm1
000073ef1c5d857c  lea rdi, [rsp]
000073ef1c5d8580  mov esi, 0x00
000073ef1c5d8585  mov rax, 0x56F25E118530
000073ef1c5d858f  call rax
000073ef1c5d8591  movaps xmm9, [rsp]
000073ef1c5d8596  add rsp, 0x30
000073ef1c5d859a  vmovaps xmm0, [rsp]
000073ef1c5d859f  vmovaps xmm1, [rsp+0x10]
000073ef1c5d85a5  vmovaps xmm2, [rsp+0x20]
000073ef1c5d85ab  vmovaps xmm3, [rsp+0x30]
000073ef1c5d85b1  vmovaps xmm4, [rsp+0x40]
000073ef1c5d85b7  vmovaps xmm5, [rsp+0x50]
000073ef1c5d85bd  vmovaps xmm6, [rsp+0x60]
000073ef1c5d85c3  vmovaps xmm7, [rsp+0x70]
000073ef1c5d85c9  vmovaps xmm8, [rsp+0x80]
000073ef1c5d85d2  vmovaps xmm10, [rsp+0x90]
000073ef1c5d85db  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d85e4  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d85ed  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d85f6  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d85ff  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d8608  add rsp, 0xF0
000073ef1c5d860f  pop r11
000073ef1c5d8611  pop r10
000073ef1c5d8613  pop r9
000073ef1c5d8615  pop r8
000073ef1c5d8617  pop rsi
000073ef1c5d8618  pop rdi
000073ef1c5d8619  pop rdx
000073ef1c5d861a  pop rcx
000073ef1c5d861b  pop rax
000073ef1c5d861c  add rsp, 0x08
000073ef1c5d8620  jmp 0x000073EF1C5D5FF7
000073ef1c5d8625  call 0x000073EF1C4D64F0
000073ef1c5d862a  jmp 0x000073EF1C5D6004
000073ef1c5d862f  sub rsp, 0x08
000073ef1c5d8633  push rax
000073ef1c5d8634  push rcx
000073ef1c5d8635  push rdx
000073ef1c5d8636  push rdi
000073ef1c5d8637  push rsi
000073ef1c5d8638  push r8
000073ef1c5d863a  push r9
000073ef1c5d863c  push r10
000073ef1c5d863e  push r11
000073ef1c5d8640  sub rsp, 0xF0
000073ef1c5d8647  vmovaps [rsp], xmm0
000073ef1c5d864c  vmovaps [rsp+0x10], xmm1
000073ef1c5d8652  vmovaps [rsp+0x20], xmm2
000073ef1c5d8658  vmovaps [rsp+0x30], xmm3
000073ef1c5d865e  vmovaps [rsp+0x40], xmm4
000073ef1c5d8664  vmovaps [rsp+0x50], xmm5
000073ef1c5d866a  vmovaps [rsp+0x60], xmm6
000073ef1c5d8670  vmovaps [rsp+0x70], xmm7
000073ef1c5d8676  vmovaps [rsp+0x80], xmm8
000073ef1c5d867f  vmovaps [rsp+0x90], xmm9
000073ef1c5d8688  vmovaps [rsp+0xA0], xmm10
000073ef1c5d8691  vmovaps [rsp+0xB0], xmm11
000073ef1c5d869a  vmovaps [rsp+0xC0], xmm12
000073ef1c5d86a3  vmovaps [rsp+0xD0], xmm13
000073ef1c5d86ac  vmovaps [rsp+0xE0], xmm14
000073ef1c5d86b5  sub rsp, 0x30
000073ef1c5d86b9  movaps [rsp], xmm15
000073ef1c5d86be  movaps [rsp+0x10], xmm3
000073ef1c5d86c3  movaps [rsp+0x20], xmm7
000073ef1c5d86c8  lea rdi, [rsp]
000073ef1c5d86cc  mov esi, 0x00
000073ef1c5d86d1  mov rax, 0x56F25E118530
000073ef1c5d86db  call rax
000073ef1c5d86dd  movaps xmm15, [rsp]
000073ef1c5d86e2  add rsp, 0x30
000073ef1c5d86e6  vmovaps xmm0, [rsp]
000073ef1c5d86eb  vmovaps xmm1, [rsp+0x10]
000073ef1c5d86f1  vmovaps xmm2, [rsp+0x20]
000073ef1c5d86f7  vmovaps xmm3, [rsp+0x30]
000073ef1c5d86fd  vmovaps xmm4, [rsp+0x40]
000073ef1c5d8703  vmovaps xmm5, [rsp+0x50]
000073ef1c5d8709  vmovaps xmm6, [rsp+0x60]
000073ef1c5d870f  vmovaps xmm7, [rsp+0x70]
000073ef1c5d8715  vmovaps xmm8, [rsp+0x80]
000073ef1c5d871e  vmovaps xmm9, [rsp+0x90]
000073ef1c5d8727  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d8730  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d8739  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d8742  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d874b  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d8754  add rsp, 0xF0
000073ef1c5d875b  pop r11
000073ef1c5d875d  pop r10
000073ef1c5d875f  pop r9
000073ef1c5d8761  pop r8
000073ef1c5d8763  pop rsi
000073ef1c5d8764  pop rdi
000073ef1c5d8765  pop rdx
000073ef1c5d8766  pop rcx
000073ef1c5d8767  pop rax
000073ef1c5d8768  add rsp, 0x08
000073ef1c5d876c  jmp 0x000073EF1C5D6030
000073ef1c5d8771  sub rsp, 0x08
000073ef1c5d8775  push rax
000073ef1c5d8776  push rcx
000073ef1c5d8777  push rdx
000073ef1c5d8778  push rdi
000073ef1c5d8779  push rsi
000073ef1c5d877a  push r8
000073ef1c5d877c  push r9
000073ef1c5d877e  push r10
000073ef1c5d8780  push r11
000073ef1c5d8782  sub rsp, 0xF0
000073ef1c5d8789  vmovaps [rsp], xmm0
000073ef1c5d878e  vmovaps [rsp+0x10], xmm1
000073ef1c5d8794  vmovaps [rsp+0x20], xmm2
000073ef1c5d879a  vmovaps [rsp+0x30], xmm4
000073ef1c5d87a0  vmovaps [rsp+0x40], xmm5
000073ef1c5d87a6  vmovaps [rsp+0x50], xmm6
000073ef1c5d87ac  vmovaps [rsp+0x60], xmm7
000073ef1c5d87b2  vmovaps [rsp+0x70], xmm8
000073ef1c5d87b8  vmovaps [rsp+0x80], xmm9
000073ef1c5d87c1  vmovaps [rsp+0x90], xmm10
000073ef1c5d87ca  vmovaps [rsp+0xA0], xmm11
000073ef1c5d87d3  vmovaps [rsp+0xB0], xmm12
000073ef1c5d87dc  vmovaps [rsp+0xC0], xmm13
000073ef1c5d87e5  vmovaps [rsp+0xD0], xmm14
000073ef1c5d87ee  vmovaps [rsp+0xE0], xmm15
000073ef1c5d87f7  sub rsp, 0x30
000073ef1c5d87fb  movaps [rsp], xmm3
000073ef1c5d87ff  movaps [rsp+0x10], xmm1
000073ef1c5d8804  movaps [rsp+0x20], xmm15
000073ef1c5d880a  lea rdi, [rsp]
000073ef1c5d880e  mov esi, 0x00
000073ef1c5d8813  mov rax, 0x56F25E118530
000073ef1c5d881d  call rax
000073ef1c5d881f  movaps xmm3, [rsp]
000073ef1c5d8823  add rsp, 0x30
000073ef1c5d8827  vmovaps xmm0, [rsp]
000073ef1c5d882c  vmovaps xmm1, [rsp+0x10]
000073ef1c5d8832  vmovaps xmm2, [rsp+0x20]
000073ef1c5d8838  vmovaps xmm4, [rsp+0x30]
000073ef1c5d883e  vmovaps xmm5, [rsp+0x40]
000073ef1c5d8844  vmovaps xmm6, [rsp+0x50]
000073ef1c5d884a  vmovaps xmm7, [rsp+0x60]
000073ef1c5d8850  vmovaps xmm8, [rsp+0x70]
000073ef1c5d8856  vmovaps xmm9, [rsp+0x80]
000073ef1c5d885f  vmovaps xmm10, [rsp+0x90]
000073ef1c5d8868  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d8871  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d887a  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d8883  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d888c  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d8895  add rsp, 0xF0
000073ef1c5d889c  pop r11
000073ef1c5d889e  pop r10
000073ef1c5d88a0  pop r9
000073ef1c5d88a2  pop r8
000073ef1c5d88a4  pop rsi
000073ef1c5d88a5  pop rdi
000073ef1c5d88a6  pop rdx
000073ef1c5d88a7  pop rcx
000073ef1c5d88a8  pop rax
000073ef1c5d88a9  add rsp, 0x08
000073ef1c5d88ad  jmp 0x000073EF1C5D60BF
000073ef1c5d88b2  call 0x000073EF1C4D64F0
000073ef1c5d88b7  jmp 0x000073EF1C5D60C9
000073ef1c5d88bc  sub rsp, 0x08
000073ef1c5d88c0  push rax
000073ef1c5d88c1  push rcx
000073ef1c5d88c2  push rdx
000073ef1c5d88c3  push rdi
000073ef1c5d88c4  push rsi
000073ef1c5d88c5  push r8
000073ef1c5d88c7  push r9
000073ef1c5d88c9  push r10
000073ef1c5d88cb  push r11
000073ef1c5d88cd  sub rsp, 0xF0
000073ef1c5d88d4  vmovaps [rsp], xmm0
000073ef1c5d88d9  vmovaps [rsp+0x10], xmm1
000073ef1c5d88df  vmovaps [rsp+0x20], xmm2
000073ef1c5d88e5  vmovaps [rsp+0x30], xmm3
000073ef1c5d88eb  vmovaps [rsp+0x40], xmm4
000073ef1c5d88f1  vmovaps [rsp+0x50], xmm5
000073ef1c5d88f7  vmovaps [rsp+0x60], xmm6
000073ef1c5d88fd  vmovaps [rsp+0x70], xmm7
000073ef1c5d8903  vmovaps [rsp+0x80], xmm8
000073ef1c5d890c  vmovaps [rsp+0x90], xmm9
000073ef1c5d8915  vmovaps [rsp+0xA0], xmm10
000073ef1c5d891e  vmovaps [rsp+0xB0], xmm11
000073ef1c5d8927  vmovaps [rsp+0xC0], xmm12
000073ef1c5d8930  vmovaps [rsp+0xD0], xmm13
000073ef1c5d8939  vmovaps [rsp+0xE0], xmm14
000073ef1c5d8942  sub rsp, 0x30
000073ef1c5d8946  movaps [rsp], xmm15
000073ef1c5d894b  movaps [rsp+0x10], xmm14
000073ef1c5d8951  movaps [rsp+0x20], xmm4
000073ef1c5d8956  lea rdi, [rsp]
000073ef1c5d895a  mov esi, 0x00
000073ef1c5d895f  mov rax, 0x56F25E118530
000073ef1c5d8969  call rax
000073ef1c5d896b  movaps xmm15, [rsp]
000073ef1c5d8970  add rsp, 0x30
000073ef1c5d8974  vmovaps xmm0, [rsp]
000073ef1c5d8979  vmovaps xmm1, [rsp+0x10]
000073ef1c5d897f  vmovaps xmm2, [rsp+0x20]
000073ef1c5d8985  vmovaps xmm3, [rsp+0x30]
000073ef1c5d898b  vmovaps xmm4, [rsp+0x40]
000073ef1c5d8991  vmovaps xmm5, [rsp+0x50]
000073ef1c5d8997  vmovaps xmm6, [rsp+0x60]
000073ef1c5d899d  vmovaps xmm7, [rsp+0x70]
000073ef1c5d89a3  vmovaps xmm8, [rsp+0x80]
000073ef1c5d89ac  vmovaps xmm9, [rsp+0x90]
000073ef1c5d89b5  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d89be  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d89c7  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d89d0  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d89d9  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d89e2  add rsp, 0xF0
000073ef1c5d89e9  pop r11
000073ef1c5d89eb  pop r10
000073ef1c5d89ed  pop r9
000073ef1c5d89ef  pop r8
000073ef1c5d89f1  pop rsi
000073ef1c5d89f2  pop rdi
000073ef1c5d89f3  pop rdx
000073ef1c5d89f4  pop rcx
000073ef1c5d89f5  pop rax
000073ef1c5d89f6  add rsp, 0x08
000073ef1c5d89fa  jmp 0x000073EF1C5D60F7
000073ef1c5d89ff  sub rsp, 0x08
000073ef1c5d8a03  push rax
000073ef1c5d8a04  push rcx
000073ef1c5d8a05  push rdx
000073ef1c5d8a06  push rdi
000073ef1c5d8a07  push rsi
000073ef1c5d8a08  push r8
000073ef1c5d8a0a  push r9
000073ef1c5d8a0c  push r10
000073ef1c5d8a0e  push r11
000073ef1c5d8a10  sub rsp, 0xF0
000073ef1c5d8a17  vmovaps [rsp], xmm0
000073ef1c5d8a1c  vmovaps [rsp+0x10], xmm1
000073ef1c5d8a22  vmovaps [rsp+0x20], xmm2
000073ef1c5d8a28  vmovaps [rsp+0x30], xmm3
000073ef1c5d8a2e  vmovaps [rsp+0x40], xmm4
000073ef1c5d8a34  vmovaps [rsp+0x50], xmm5
000073ef1c5d8a3a  vmovaps [rsp+0x60], xmm6
000073ef1c5d8a40  vmovaps [rsp+0x70], xmm7
000073ef1c5d8a46  vmovaps [rsp+0x80], xmm8
000073ef1c5d8a4f  vmovaps [rsp+0x90], xmm9
000073ef1c5d8a58  vmovaps [rsp+0xA0], xmm10
000073ef1c5d8a61  vmovaps [rsp+0xB0], xmm11
000073ef1c5d8a6a  vmovaps [rsp+0xC0], xmm12
000073ef1c5d8a73  vmovaps [rsp+0xD0], xmm13
000073ef1c5d8a7c  vmovaps [rsp+0xE0], xmm15
000073ef1c5d8a85  sub rsp, 0x30
000073ef1c5d8a89  movaps [rsp], xmm14
000073ef1c5d8a8e  movaps [rsp+0x10], xmm2
000073ef1c5d8a93  movaps [rsp+0x20], xmm1
000073ef1c5d8a98  lea rdi, [rsp]
000073ef1c5d8a9c  mov esi, 0x00
000073ef1c5d8aa1  mov rax, 0x56F25E118530
000073ef1c5d8aab  call rax
000073ef1c5d8aad  movaps xmm14, [rsp]
000073ef1c5d8ab2  add rsp, 0x30
000073ef1c5d8ab6  vmovaps xmm0, [rsp]
000073ef1c5d8abb  vmovaps xmm1, [rsp+0x10]
000073ef1c5d8ac1  vmovaps xmm2, [rsp+0x20]
000073ef1c5d8ac7  vmovaps xmm3, [rsp+0x30]
000073ef1c5d8acd  vmovaps xmm4, [rsp+0x40]
000073ef1c5d8ad3  vmovaps xmm5, [rsp+0x50]
000073ef1c5d8ad9  vmovaps xmm6, [rsp+0x60]
000073ef1c5d8adf  vmovaps xmm7, [rsp+0x70]
000073ef1c5d8ae5  vmovaps xmm8, [rsp+0x80]
000073ef1c5d8aee  vmovaps xmm9, [rsp+0x90]
000073ef1c5d8af7  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d8b00  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d8b09  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d8b12  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d8b1b  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d8b24  add rsp, 0xF0
000073ef1c5d8b2b  pop r11
000073ef1c5d8b2d  pop r10
000073ef1c5d8b2f  pop r9
000073ef1c5d8b31  pop r8
000073ef1c5d8b33  pop rsi
000073ef1c5d8b34  pop rdi
000073ef1c5d8b35  pop rdx
000073ef1c5d8b36  pop rcx
000073ef1c5d8b37  pop rax
000073ef1c5d8b38  add rsp, 0x08
000073ef1c5d8b3c  jmp 0x000073EF1C5D611D
000073ef1c5d8b41  sub rsp, 0x08
000073ef1c5d8b45  push rax
000073ef1c5d8b46  push rcx
000073ef1c5d8b47  push rdx
000073ef1c5d8b48  push rdi
000073ef1c5d8b49  push rsi
000073ef1c5d8b4a  push r8
000073ef1c5d8b4c  push r9
000073ef1c5d8b4e  push r10
000073ef1c5d8b50  push r11
000073ef1c5d8b52  sub rsp, 0xF0
000073ef1c5d8b59  vmovaps [rsp], xmm0
000073ef1c5d8b5e  vmovaps [rsp+0x10], xmm2
000073ef1c5d8b64  vmovaps [rsp+0x20], xmm3
000073ef1c5d8b6a  vmovaps [rsp+0x30], xmm4
000073ef1c5d8b70  vmovaps [rsp+0x40], xmm5
000073ef1c5d8b76  vmovaps [rsp+0x50], xmm6
000073ef1c5d8b7c  vmovaps [rsp+0x60], xmm7
000073ef1c5d8b82  vmovaps [rsp+0x70], xmm8
000073ef1c5d8b88  vmovaps [rsp+0x80], xmm9
000073ef1c5d8b91  vmovaps [rsp+0x90], xmm10
000073ef1c5d8b9a  vmovaps [rsp+0xA0], xmm11
000073ef1c5d8ba3  vmovaps [rsp+0xB0], xmm12
000073ef1c5d8bac  vmovaps [rsp+0xC0], xmm13
000073ef1c5d8bb5  vmovaps [rsp+0xD0], xmm14
000073ef1c5d8bbe  vmovaps [rsp+0xE0], xmm15
000073ef1c5d8bc7  sub rsp, 0x30
000073ef1c5d8bcb  movaps [rsp], xmm1
000073ef1c5d8bcf  movaps [rsp+0x10], xmm4
000073ef1c5d8bd4  movaps [rsp+0x20], xmm9
000073ef1c5d8bda  lea rdi, [rsp]
000073ef1c5d8bde  mov esi, 0x00
000073ef1c5d8be3  mov rax, 0x56F25E118530
000073ef1c5d8bed  call rax
000073ef1c5d8bef  movaps xmm1, [rsp]
000073ef1c5d8bf3  add rsp, 0x30
000073ef1c5d8bf7  vmovaps xmm0, [rsp]
000073ef1c5d8bfc  vmovaps xmm2, [rsp+0x10]
000073ef1c5d8c02  vmovaps xmm3, [rsp+0x20]
000073ef1c5d8c08  vmovaps xmm4, [rsp+0x30]
000073ef1c5d8c0e  vmovaps xmm5, [rsp+0x40]
000073ef1c5d8c14  vmovaps xmm6, [rsp+0x50]
000073ef1c5d8c1a  vmovaps xmm7, [rsp+0x60]
000073ef1c5d8c20  vmovaps xmm8, [rsp+0x70]
000073ef1c5d8c26  vmovaps xmm9, [rsp+0x80]
000073ef1c5d8c2f  vmovaps xmm10, [rsp+0x90]
000073ef1c5d8c38  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d8c41  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d8c4a  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d8c53  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d8c5c  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d8c65  add rsp, 0xF0
000073ef1c5d8c6c  pop r11
000073ef1c5d8c6e  pop r10
000073ef1c5d8c70  pop r9
000073ef1c5d8c72  pop r8
000073ef1c5d8c74  pop rsi
000073ef1c5d8c75  pop rdi
000073ef1c5d8c76  pop rdx
000073ef1c5d8c77  pop rcx
000073ef1c5d8c78  pop rax
000073ef1c5d8c79  add rsp, 0x08
000073ef1c5d8c7d  jmp 0x000073EF1C5D613B
000073ef1c5d8c82  sub rsp, 0x08
000073ef1c5d8c86  push rax
000073ef1c5d8c87  push rcx
000073ef1c5d8c88  push rdx
000073ef1c5d8c89  push rdi
000073ef1c5d8c8a  push rsi
000073ef1c5d8c8b  push r8
000073ef1c5d8c8d  push r9
000073ef1c5d8c8f  push r10
000073ef1c5d8c91  push r11
000073ef1c5d8c93  sub rsp, 0xF0
000073ef1c5d8c9a  vmovaps [rsp], xmm0
000073ef1c5d8c9f  vmovaps [rsp+0x10], xmm1
000073ef1c5d8ca5  vmovaps [rsp+0x20], xmm2
000073ef1c5d8cab  vmovaps [rsp+0x30], xmm3
000073ef1c5d8cb1  vmovaps [rsp+0x40], xmm5
000073ef1c5d8cb7  vmovaps [rsp+0x50], xmm6
000073ef1c5d8cbd  vmovaps [rsp+0x60], xmm7
000073ef1c5d8cc3  vmovaps [rsp+0x70], xmm8
000073ef1c5d8cc9  vmovaps [rsp+0x80], xmm9
000073ef1c5d8cd2  vmovaps [rsp+0x90], xmm10
000073ef1c5d8cdb  vmovaps [rsp+0xA0], xmm11
000073ef1c5d8ce4  vmovaps [rsp+0xB0], xmm12
000073ef1c5d8ced  vmovaps [rsp+0xC0], xmm13
000073ef1c5d8cf6  vmovaps [rsp+0xD0], xmm14
000073ef1c5d8cff  vmovaps [rsp+0xE0], xmm15
000073ef1c5d8d08  sub rsp, 0x30
000073ef1c5d8d0c  movaps [rsp], xmm4
000073ef1c5d8d10  movaps [rsp+0x10], xmm2
000073ef1c5d8d15  movaps [rsp+0x20], xmm9
000073ef1c5d8d1b  lea rdi, [rsp]
000073ef1c5d8d1f  mov esi, 0x00
000073ef1c5d8d24  mov rax, 0x56F25E118530
000073ef1c5d8d2e  call rax
000073ef1c5d8d30  movaps xmm4, [rsp]
000073ef1c5d8d34  add rsp, 0x30
000073ef1c5d8d38  vmovaps xmm0, [rsp]
000073ef1c5d8d3d  vmovaps xmm1, [rsp+0x10]
000073ef1c5d8d43  vmovaps xmm2, [rsp+0x20]
000073ef1c5d8d49  vmovaps xmm3, [rsp+0x30]
000073ef1c5d8d4f  vmovaps xmm5, [rsp+0x40]
000073ef1c5d8d55  vmovaps xmm6, [rsp+0x50]
000073ef1c5d8d5b  vmovaps xmm7, [rsp+0x60]
000073ef1c5d8d61  vmovaps xmm8, [rsp+0x70]
000073ef1c5d8d67  vmovaps xmm9, [rsp+0x80]
000073ef1c5d8d70  vmovaps xmm10, [rsp+0x90]
000073ef1c5d8d79  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d8d82  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d8d8b  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d8d94  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d8d9d  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d8da6  add rsp, 0xF0
000073ef1c5d8dad  pop r11
000073ef1c5d8daf  pop r10
000073ef1c5d8db1  pop r9
000073ef1c5d8db3  pop r8
000073ef1c5d8db5  pop rsi
000073ef1c5d8db6  pop rdi
000073ef1c5d8db7  pop rdx
000073ef1c5d8db8  pop rcx
000073ef1c5d8db9  pop rax
000073ef1c5d8dba  add rsp, 0x08
000073ef1c5d8dbe  jmp 0x000073EF1C5D616B
000073ef1c5d8dc3  sub rsp, 0x08
000073ef1c5d8dc7  push rax
000073ef1c5d8dc8  push rcx
000073ef1c5d8dc9  push rdx
000073ef1c5d8dca  push rdi
000073ef1c5d8dcb  push rsi
000073ef1c5d8dcc  push r8
000073ef1c5d8dce  push r9
000073ef1c5d8dd0  push r10
000073ef1c5d8dd2  push r11
000073ef1c5d8dd4  sub rsp, 0xF0
000073ef1c5d8ddb  vmovaps [rsp], xmm0
000073ef1c5d8de0  vmovaps [rsp+0x10], xmm1
000073ef1c5d8de6  vmovaps [rsp+0x20], xmm2
000073ef1c5d8dec  vmovaps [rsp+0x30], xmm3
000073ef1c5d8df2  vmovaps [rsp+0x40], xmm4
000073ef1c5d8df8  vmovaps [rsp+0x50], xmm5
000073ef1c5d8dfe  vmovaps [rsp+0x60], xmm6
000073ef1c5d8e04  vmovaps [rsp+0x70], xmm7
000073ef1c5d8e0a  vmovaps [rsp+0x80], xmm8
000073ef1c5d8e13  vmovaps [rsp+0x90], xmm10
000073ef1c5d8e1c  vmovaps [rsp+0xA0], xmm11
000073ef1c5d8e25  vmovaps [rsp+0xB0], xmm12
000073ef1c5d8e2e  vmovaps [rsp+0xC0], xmm13
000073ef1c5d8e37  vmovaps [rsp+0xD0], xmm14
000073ef1c5d8e40  vmovaps [rsp+0xE0], xmm15
000073ef1c5d8e49  sub rsp, 0x30
000073ef1c5d8e4d  movaps [rsp], xmm9
000073ef1c5d8e52  movaps [rsp+0x10], xmm2
000073ef1c5d8e57  movaps [rsp+0x20], xmm1
000073ef1c5d8e5c  lea rdi, [rsp]
000073ef1c5d8e60  mov esi, 0x00
000073ef1c5d8e65  mov rax, 0x56F25E118530
000073ef1c5d8e6f  call rax
000073ef1c5d8e71  movaps xmm9, [rsp]
000073ef1c5d8e76  add rsp, 0x30
000073ef1c5d8e7a  vmovaps xmm0, [rsp]
000073ef1c5d8e7f  vmovaps xmm1, [rsp+0x10]
000073ef1c5d8e85  vmovaps xmm2, [rsp+0x20]
000073ef1c5d8e8b  vmovaps xmm3, [rsp+0x30]
000073ef1c5d8e91  vmovaps xmm4, [rsp+0x40]
000073ef1c5d8e97  vmovaps xmm5, [rsp+0x50]
000073ef1c5d8e9d  vmovaps xmm6, [rsp+0x60]
000073ef1c5d8ea3  vmovaps xmm7, [rsp+0x70]
000073ef1c5d8ea9  vmovaps xmm8, [rsp+0x80]
000073ef1c5d8eb2  vmovaps xmm10, [rsp+0x90]
000073ef1c5d8ebb  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d8ec4  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d8ecd  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d8ed6  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d8edf  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d8ee8  add rsp, 0xF0
000073ef1c5d8eef  pop r11
000073ef1c5d8ef1  pop r10
000073ef1c5d8ef3  pop r9
000073ef1c5d8ef5  pop r8
000073ef1c5d8ef7  pop rsi
000073ef1c5d8ef8  pop rdi
000073ef1c5d8ef9  pop rdx
000073ef1c5d8efa  pop rcx
000073ef1c5d8efb  pop rax
000073ef1c5d8efc  add rsp, 0x08
000073ef1c5d8f00  jmp 0x000073EF1C5D61A1
000073ef1c5d8f05  sub rsp, 0x08
000073ef1c5d8f09  push rax
000073ef1c5d8f0a  push rcx
000073ef1c5d8f0b  push rdx
000073ef1c5d8f0c  push rdi
000073ef1c5d8f0d  push rsi
000073ef1c5d8f0e  push r8
000073ef1c5d8f10  push r9
000073ef1c5d8f12  push r10
000073ef1c5d8f14  push r11
000073ef1c5d8f16  sub rsp, 0xF0
000073ef1c5d8f1d  vmovaps [rsp], xmm0
000073ef1c5d8f22  vmovaps [rsp+0x10], xmm2
000073ef1c5d8f28  vmovaps [rsp+0x20], xmm3
000073ef1c5d8f2e  vmovaps [rsp+0x30], xmm4
000073ef1c5d8f34  vmovaps [rsp+0x40], xmm5
000073ef1c5d8f3a  vmovaps [rsp+0x50], xmm6
000073ef1c5d8f40  vmovaps [rsp+0x60], xmm7
000073ef1c5d8f46  vmovaps [rsp+0x70], xmm8
000073ef1c5d8f4c  vmovaps [rsp+0x80], xmm9
000073ef1c5d8f55  vmovaps [rsp+0x90], xmm10
000073ef1c5d8f5e  vmovaps [rsp+0xA0], xmm11
000073ef1c5d8f67  vmovaps [rsp+0xB0], xmm12
000073ef1c5d8f70  vmovaps [rsp+0xC0], xmm13
000073ef1c5d8f79  vmovaps [rsp+0xD0], xmm14
000073ef1c5d8f82  vmovaps [rsp+0xE0], xmm15
000073ef1c5d8f8b  sub rsp, 0x30
000073ef1c5d8f8f  movaps [rsp], xmm1
000073ef1c5d8f93  movaps [rsp+0x10], xmm15
000073ef1c5d8f99  movaps [rsp+0x20], xmm6
000073ef1c5d8f9e  lea rdi, [rsp]
000073ef1c5d8fa2  mov esi, 0x00
000073ef1c5d8fa7  mov rax, 0x56F25E118530
000073ef1c5d8fb1  call rax
000073ef1c5d8fb3  movaps xmm1, [rsp]
000073ef1c5d8fb7  add rsp, 0x30
000073ef1c5d8fbb  vmovaps xmm0, [rsp]
000073ef1c5d8fc0  vmovaps xmm2, [rsp+0x10]
000073ef1c5d8fc6  vmovaps xmm3, [rsp+0x20]
000073ef1c5d8fcc  vmovaps xmm4, [rsp+0x30]
000073ef1c5d8fd2  vmovaps xmm5, [rsp+0x40]
000073ef1c5d8fd8  vmovaps xmm6, [rsp+0x50]
000073ef1c5d8fde  vmovaps xmm7, [rsp+0x60]
000073ef1c5d8fe4  vmovaps xmm8, [rsp+0x70]
000073ef1c5d8fea  vmovaps xmm9, [rsp+0x80]
000073ef1c5d8ff3  vmovaps xmm10, [rsp+0x90]
000073ef1c5d8ffc  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d9005  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d900e  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d9017  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d9020  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d9029  add rsp, 0xF0
000073ef1c5d9030  pop r11
000073ef1c5d9032  pop r10
000073ef1c5d9034  pop r9
000073ef1c5d9036  pop r8
000073ef1c5d9038  pop rsi
000073ef1c5d9039  pop rdi
000073ef1c5d903a  pop rdx
000073ef1c5d903b  pop rcx
000073ef1c5d903c  pop rax
000073ef1c5d903d  add rsp, 0x08
000073ef1c5d9041  jmp 0x000073EF1C5D61C2
000073ef1c5d9046  sub rsp, 0x08
000073ef1c5d904a  push rax
000073ef1c5d904b  push rcx
000073ef1c5d904c  push rdx
000073ef1c5d904d  push rdi
000073ef1c5d904e  push rsi
000073ef1c5d904f  push r8
000073ef1c5d9051  push r9
000073ef1c5d9053  push r10
000073ef1c5d9055  push r11
000073ef1c5d9057  sub rsp, 0xF0
000073ef1c5d905e  vmovaps [rsp], xmm0
000073ef1c5d9063  vmovaps [rsp+0x10], xmm1
000073ef1c5d9069  vmovaps [rsp+0x20], xmm2
000073ef1c5d906f  vmovaps [rsp+0x30], xmm3
000073ef1c5d9075  vmovaps [rsp+0x40], xmm4
000073ef1c5d907b  vmovaps [rsp+0x50], xmm5
000073ef1c5d9081  vmovaps [rsp+0x60], xmm6
000073ef1c5d9087  vmovaps [rsp+0x70], xmm7
000073ef1c5d908d  vmovaps [rsp+0x80], xmm8
000073ef1c5d9096  vmovaps [rsp+0x90], xmm9
000073ef1c5d909f  vmovaps [rsp+0xA0], xmm10
000073ef1c5d90a8  vmovaps [rsp+0xB0], xmm11
000073ef1c5d90b1  vmovaps [rsp+0xC0], xmm12
000073ef1c5d90ba  vmovaps [rsp+0xD0], xmm13
000073ef1c5d90c3  vmovaps [rsp+0xE0], xmm14
000073ef1c5d90cc  sub rsp, 0x30
000073ef1c5d90d0  movaps [rsp], xmm15
000073ef1c5d90d5  movaps [rsp+0x10], xmm5
000073ef1c5d90da  movaps [rsp+0x20], xmm3
000073ef1c5d90df  lea rdi, [rsp]
000073ef1c5d90e3  mov esi, 0x00
000073ef1c5d90e8  mov rax, 0x56F25E118530
000073ef1c5d90f2  call rax
000073ef1c5d90f4  movaps xmm15, [rsp]
000073ef1c5d90f9  add rsp, 0x30
000073ef1c5d90fd  vmovaps xmm0, [rsp]
000073ef1c5d9102  vmovaps xmm1, [rsp+0x10]
000073ef1c5d9108  vmovaps xmm2, [rsp+0x20]
000073ef1c5d910e  vmovaps xmm3, [rsp+0x30]
000073ef1c5d9114  vmovaps xmm4, [rsp+0x40]
000073ef1c5d911a  vmovaps xmm5, [rsp+0x50]
000073ef1c5d9120  vmovaps xmm6, [rsp+0x60]
000073ef1c5d9126  vmovaps xmm7, [rsp+0x70]
000073ef1c5d912c  vmovaps xmm8, [rsp+0x80]
000073ef1c5d9135  vmovaps xmm9, [rsp+0x90]
000073ef1c5d913e  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d9147  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d9150  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d9159  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d9162  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d916b  add rsp, 0xF0
000073ef1c5d9172  pop r11
000073ef1c5d9174  pop r10
000073ef1c5d9176  pop r9
000073ef1c5d9178  pop r8
000073ef1c5d917a  pop rsi
000073ef1c5d917b  pop rdi
000073ef1c5d917c  pop rdx
000073ef1c5d917d  pop rcx
000073ef1c5d917e  pop rax
000073ef1c5d917f  add rsp, 0x08
000073ef1c5d9183  jmp 0x000073EF1C5D61DC
000073ef1c5d9188  sub rsp, 0x08
000073ef1c5d918c  push rax
000073ef1c5d918d  push rcx
000073ef1c5d918e  push rdx
000073ef1c5d918f  push rdi
000073ef1c5d9190  push rsi
000073ef1c5d9191  push r8
000073ef1c5d9193  push r9
000073ef1c5d9195  push r10
000073ef1c5d9197  push r11
000073ef1c5d9199  sub rsp, 0xF0
000073ef1c5d91a0  vmovaps [rsp], xmm0
000073ef1c5d91a5  vmovaps [rsp+0x10], xmm1
000073ef1c5d91ab  vmovaps [rsp+0x20], xmm2
000073ef1c5d91b1  vmovaps [rsp+0x30], xmm3
000073ef1c5d91b7  vmovaps [rsp+0x40], xmm4
000073ef1c5d91bd  vmovaps [rsp+0x50], xmm6
000073ef1c5d91c3  vmovaps [rsp+0x60], xmm7
000073ef1c5d91c9  vmovaps [rsp+0x70], xmm8
000073ef1c5d91cf  vmovaps [rsp+0x80], xmm9
000073ef1c5d91d8  vmovaps [rsp+0x90], xmm10
000073ef1c5d91e1  vmovaps [rsp+0xA0], xmm11
000073ef1c5d91ea  vmovaps [rsp+0xB0], xmm12
000073ef1c5d91f3  vmovaps [rsp+0xC0], xmm13
000073ef1c5d91fc  vmovaps [rsp+0xD0], xmm14
000073ef1c5d9205  vmovaps [rsp+0xE0], xmm15
000073ef1c5d920e  sub rsp, 0x30
000073ef1c5d9212  movaps [rsp], xmm5
000073ef1c5d9216  movaps [rsp+0x10], xmm8
000073ef1c5d921c  movaps [rsp+0x20], xmm6
000073ef1c5d9221  lea rdi, [rsp]
000073ef1c5d9225  mov esi, 0x00
000073ef1c5d922a  mov rax, 0x56F25E118530
000073ef1c5d9234  call rax
000073ef1c5d9236  movaps xmm5, [rsp]
000073ef1c5d923a  add rsp, 0x30
000073ef1c5d923e  vmovaps xmm0, [rsp]
000073ef1c5d9243  vmovaps xmm1, [rsp+0x10]
000073ef1c5d9249  vmovaps xmm2, [rsp+0x20]
000073ef1c5d924f  vmovaps xmm3, [rsp+0x30]
000073ef1c5d9255  vmovaps xmm4, [rsp+0x40]
000073ef1c5d925b  vmovaps xmm6, [rsp+0x50]
000073ef1c5d9261  vmovaps xmm7, [rsp+0x60]
000073ef1c5d9267  vmovaps xmm8, [rsp+0x70]
000073ef1c5d926d  vmovaps xmm9, [rsp+0x80]
000073ef1c5d9276  vmovaps xmm10, [rsp+0x90]
000073ef1c5d927f  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d9288  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d9291  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d929a  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d92a3  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d92ac  add rsp, 0xF0
000073ef1c5d92b3  pop r11
000073ef1c5d92b5  pop r10
000073ef1c5d92b7  pop r9
000073ef1c5d92b9  pop r8
000073ef1c5d92bb  pop rsi
000073ef1c5d92bc  pop rdi
000073ef1c5d92bd  pop rdx
000073ef1c5d92be  pop rcx
000073ef1c5d92bf  pop rax
000073ef1c5d92c0  add rsp, 0x08
000073ef1c5d92c4  jmp 0x000073EF1C5D6200
000073ef1c5d92c9  sub rsp, 0x08
000073ef1c5d92cd  push rax
000073ef1c5d92ce  push rcx
000073ef1c5d92cf  push rdx
000073ef1c5d92d0  push rdi
000073ef1c5d92d1  push rsi
000073ef1c5d92d2  push r8
000073ef1c5d92d4  push r9
000073ef1c5d92d6  push r10
000073ef1c5d92d8  push r11
000073ef1c5d92da  sub rsp, 0xF0
000073ef1c5d92e1  vmovaps [rsp], xmm0
000073ef1c5d92e6  vmovaps [rsp+0x10], xmm1
000073ef1c5d92ec  vmovaps [rsp+0x20], xmm2
000073ef1c5d92f2  vmovaps [rsp+0x30], xmm3
000073ef1c5d92f8  vmovaps [rsp+0x40], xmm4
000073ef1c5d92fe  vmovaps [rsp+0x50], xmm5
000073ef1c5d9304  vmovaps [rsp+0x60], xmm7
000073ef1c5d930a  vmovaps [rsp+0x70], xmm8
000073ef1c5d9310  vmovaps [rsp+0x80], xmm9
000073ef1c5d9319  vmovaps [rsp+0x90], xmm10
000073ef1c5d9322  vmovaps [rsp+0xA0], xmm11
000073ef1c5d932b  vmovaps [rsp+0xB0], xmm12
000073ef1c5d9334  vmovaps [rsp+0xC0], xmm13
000073ef1c5d933d  vmovaps [rsp+0xD0], xmm14
000073ef1c5d9346  vmovaps [rsp+0xE0], xmm15
000073ef1c5d934f  sub rsp, 0x30
000073ef1c5d9353  movaps [rsp], xmm6
000073ef1c5d9357  movaps [rsp+0x10], xmm10
000073ef1c5d935d  movaps [rsp+0x20], xmm8
000073ef1c5d9363  lea rdi, [rsp]
000073ef1c5d9367  mov esi, 0x00
000073ef1c5d936c  mov rax, 0x56F25E118530
000073ef1c5d9376  call rax
000073ef1c5d9378  movaps xmm6, [rsp]
000073ef1c5d937c  add rsp, 0x30
000073ef1c5d9380  vmovaps xmm0, [rsp]
000073ef1c5d9385  vmovaps xmm1, [rsp+0x10]
000073ef1c5d938b  vmovaps xmm2, [rsp+0x20]
000073ef1c5d9391  vmovaps xmm3, [rsp+0x30]
000073ef1c5d9397  vmovaps xmm4, [rsp+0x40]
000073ef1c5d939d  vmovaps xmm5, [rsp+0x50]
000073ef1c5d93a3  vmovaps xmm7, [rsp+0x60]
000073ef1c5d93a9  vmovaps xmm8, [rsp+0x70]
000073ef1c5d93af  vmovaps xmm9, [rsp+0x80]
000073ef1c5d93b8  vmovaps xmm10, [rsp+0x90]
000073ef1c5d93c1  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d93ca  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d93d3  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d93dc  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d93e5  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d93ee  add rsp, 0xF0
000073ef1c5d93f5  pop r11
000073ef1c5d93f7  pop r10
000073ef1c5d93f9  pop r9
000073ef1c5d93fb  pop r8
000073ef1c5d93fd  pop rsi
000073ef1c5d93fe  pop rdi
000073ef1c5d93ff  pop rdx
000073ef1c5d9400  pop rcx
000073ef1c5d9401  pop rax
000073ef1c5d9402  add rsp, 0x08
000073ef1c5d9406  jmp 0x000073EF1C5D6225
000073ef1c5d940b  sub rsp, 0x08
000073ef1c5d940f  push rax
000073ef1c5d9410  push rcx
000073ef1c5d9411  push rdx
000073ef1c5d9412  push rdi
000073ef1c5d9413  push rsi
000073ef1c5d9414  push r8
000073ef1c5d9416  push r9
000073ef1c5d9418  push r10
000073ef1c5d941a  push r11
000073ef1c5d941c  sub rsp, 0xF0
000073ef1c5d9423  vmovaps [rsp], xmm0
000073ef1c5d9428  vmovaps [rsp+0x10], xmm1
000073ef1c5d942e  vmovaps [rsp+0x20], xmm2
000073ef1c5d9434  vmovaps [rsp+0x30], xmm3
000073ef1c5d943a  vmovaps [rsp+0x40], xmm4
000073ef1c5d9440  vmovaps [rsp+0x50], xmm5
000073ef1c5d9446  vmovaps [rsp+0x60], xmm6
000073ef1c5d944c  vmovaps [rsp+0x70], xmm7
000073ef1c5d9452  vmovaps [rsp+0x80], xmm8
000073ef1c5d945b  vmovaps [rsp+0x90], xmm9
000073ef1c5d9464  vmovaps [rsp+0xA0], xmm11
000073ef1c5d946d  vmovaps [rsp+0xB0], xmm12
000073ef1c5d9476  vmovaps [rsp+0xC0], xmm13
000073ef1c5d947f  vmovaps [rsp+0xD0], xmm14
000073ef1c5d9488  vmovaps [rsp+0xE0], xmm15
000073ef1c5d9491  sub rsp, 0x30
000073ef1c5d9495  movaps [rsp], xmm10
000073ef1c5d949a  movaps [rsp+0x10], xmm8
000073ef1c5d94a0  movaps [rsp+0x20], xmm14
000073ef1c5d94a6  lea rdi, [rsp]
000073ef1c5d94aa  mov esi, 0x00
000073ef1c5d94af  mov rax, 0x56F25E118530
000073ef1c5d94b9  call rax
000073ef1c5d94bb  movaps xmm10, [rsp]
000073ef1c5d94c0  add rsp, 0x30
000073ef1c5d94c4  vmovaps xmm0, [rsp]
000073ef1c5d94c9  vmovaps xmm1, [rsp+0x10]
000073ef1c5d94cf  vmovaps xmm2, [rsp+0x20]
000073ef1c5d94d5  vmovaps xmm3, [rsp+0x30]
000073ef1c5d94db  vmovaps xmm4, [rsp+0x40]
000073ef1c5d94e1  vmovaps xmm5, [rsp+0x50]
000073ef1c5d94e7  vmovaps xmm6, [rsp+0x60]
000073ef1c5d94ed  vmovaps xmm7, [rsp+0x70]
000073ef1c5d94f3  vmovaps xmm8, [rsp+0x80]
000073ef1c5d94fc  vmovaps xmm9, [rsp+0x90]
000073ef1c5d9505  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d950e  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d9517  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d9520  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d9529  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d9532  add rsp, 0xF0
000073ef1c5d9539  pop r11
000073ef1c5d953b  pop r10
000073ef1c5d953d  pop r9
000073ef1c5d953f  pop r8
000073ef1c5d9541  pop rsi
000073ef1c5d9542  pop rdi
000073ef1c5d9543  pop rdx
000073ef1c5d9544  pop rcx
000073ef1c5d9545  pop rax
000073ef1c5d9546  add rsp, 0x08
000073ef1c5d954a  jmp 0x000073EF1C5D6245
000073ef1c5d954f  sub rsp, 0x08
000073ef1c5d9553  push rax
000073ef1c5d9554  push rcx
000073ef1c5d9555  push rdx
000073ef1c5d9556  push rdi
000073ef1c5d9557  push rsi
000073ef1c5d9558  push r8
000073ef1c5d955a  push r9
000073ef1c5d955c  push r10
000073ef1c5d955e  push r11
000073ef1c5d9560  sub rsp, 0xF0
000073ef1c5d9567  vmovaps [rsp], xmm0
000073ef1c5d956c  vmovaps [rsp+0x10], xmm1
000073ef1c5d9572  vmovaps [rsp+0x20], xmm2
000073ef1c5d9578  vmovaps [rsp+0x30], xmm3
000073ef1c5d957e  vmovaps [rsp+0x40], xmm4
000073ef1c5d9584  vmovaps [rsp+0x50], xmm5
000073ef1c5d958a  vmovaps [rsp+0x60], xmm6
000073ef1c5d9590  vmovaps [rsp+0x70], xmm7
000073ef1c5d9596  vmovaps [rsp+0x80], xmm8
000073ef1c5d959f  vmovaps [rsp+0x90], xmm9
000073ef1c5d95a8  vmovaps [rsp+0xA0], xmm10
000073ef1c5d95b1  vmovaps [rsp+0xB0], xmm11
000073ef1c5d95ba  vmovaps [rsp+0xC0], xmm12
000073ef1c5d95c3  vmovaps [rsp+0xD0], xmm13
000073ef1c5d95cc  vmovaps [rsp+0xE0], xmm15
000073ef1c5d95d5  sub rsp, 0x30
000073ef1c5d95d9  movaps [rsp], xmm14
000073ef1c5d95de  movaps [rsp+0x10], xmm8
000073ef1c5d95e4  movaps [rsp+0x20], xmm4
000073ef1c5d95e9  lea rdi, [rsp]
000073ef1c5d95ed  mov esi, 0x00
000073ef1c5d95f2  mov rax, 0x56F25E118530
000073ef1c5d95fc  call rax
000073ef1c5d95fe  movaps xmm14, [rsp]
000073ef1c5d9603  add rsp, 0x30
000073ef1c5d9607  vmovaps xmm0, [rsp]
000073ef1c5d960c  vmovaps xmm1, [rsp+0x10]
000073ef1c5d9612  vmovaps xmm2, [rsp+0x20]
000073ef1c5d9618  vmovaps xmm3, [rsp+0x30]
000073ef1c5d961e  vmovaps xmm4, [rsp+0x40]
000073ef1c5d9624  vmovaps xmm5, [rsp+0x50]
000073ef1c5d962a  vmovaps xmm6, [rsp+0x60]
000073ef1c5d9630  vmovaps xmm7, [rsp+0x70]
000073ef1c5d9636  vmovaps xmm8, [rsp+0x80]
000073ef1c5d963f  vmovaps xmm9, [rsp+0x90]
000073ef1c5d9648  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d9651  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d965a  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d9663  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d966c  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d9675  add rsp, 0xF0
000073ef1c5d967c  pop r11
000073ef1c5d967e  pop r10
000073ef1c5d9680  pop r9
000073ef1c5d9682  pop r8
000073ef1c5d9684  pop rsi
000073ef1c5d9685  pop rdi
000073ef1c5d9686  pop rdx
000073ef1c5d9687  pop rcx
000073ef1c5d9688  pop rax
000073ef1c5d9689  add rsp, 0x08
000073ef1c5d968d  jmp 0x000073EF1C5D6265
000073ef1c5d9692  sub rsp, 0x08
000073ef1c5d9696  push rax
000073ef1c5d9697  push rcx
000073ef1c5d9698  push rdx
000073ef1c5d9699  push rdi
000073ef1c5d969a  push rsi
000073ef1c5d969b  push r8
000073ef1c5d969d  push r9
000073ef1c5d969f  push r10
000073ef1c5d96a1  push r11
000073ef1c5d96a3  sub rsp, 0xF0
000073ef1c5d96aa  vmovaps [rsp], xmm0
000073ef1c5d96af  vmovaps [rsp+0x10], xmm1
000073ef1c5d96b5  vmovaps [rsp+0x20], xmm2
000073ef1c5d96bb  vmovaps [rsp+0x30], xmm3
000073ef1c5d96c1  vmovaps [rsp+0x40], xmm5
000073ef1c5d96c7  vmovaps [rsp+0x50], xmm6
000073ef1c5d96cd  vmovaps [rsp+0x60], xmm7
000073ef1c5d96d3  vmovaps [rsp+0x70], xmm8
000073ef1c5d96d9  vmovaps [rsp+0x80], xmm9
000073ef1c5d96e2  vmovaps [rsp+0x90], xmm10
000073ef1c5d96eb  vmovaps [rsp+0xA0], xmm11
000073ef1c5d96f4  vmovaps [rsp+0xB0], xmm12
000073ef1c5d96fd  vmovaps [rsp+0xC0], xmm13
000073ef1c5d9706  vmovaps [rsp+0xD0], xmm14
000073ef1c5d970f  vmovaps [rsp+0xE0], xmm15
000073ef1c5d9718  sub rsp, 0x30
000073ef1c5d971c  movaps [rsp], xmm4
000073ef1c5d9720  movaps [rsp+0x10], xmm13
000073ef1c5d9726  movaps [rsp+0x20], xmm8
000073ef1c5d972c  lea rdi, [rsp]
000073ef1c5d9730  mov esi, 0x00
000073ef1c5d9735  mov rax, 0x56F25E118530
000073ef1c5d973f  call rax
000073ef1c5d9741  movaps xmm4, [rsp]
000073ef1c5d9745  add rsp, 0x30
000073ef1c5d9749  vmovaps xmm0, [rsp]
000073ef1c5d974e  vmovaps xmm1, [rsp+0x10]
000073ef1c5d9754  vmovaps xmm2, [rsp+0x20]
000073ef1c5d975a  vmovaps xmm3, [rsp+0x30]
000073ef1c5d9760  vmovaps xmm5, [rsp+0x40]
000073ef1c5d9766  vmovaps xmm6, [rsp+0x50]
000073ef1c5d976c  vmovaps xmm7, [rsp+0x60]
000073ef1c5d9772  vmovaps xmm8, [rsp+0x70]
000073ef1c5d9778  vmovaps xmm9, [rsp+0x80]
000073ef1c5d9781  vmovaps xmm10, [rsp+0x90]
000073ef1c5d978a  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d9793  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d979c  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d97a5  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d97ae  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d97b7  add rsp, 0xF0
000073ef1c5d97be  pop r11
000073ef1c5d97c0  pop r10
000073ef1c5d97c2  pop r9
000073ef1c5d97c4  pop r8
000073ef1c5d97c6  pop rsi
000073ef1c5d97c7  pop rdi
000073ef1c5d97c8  pop rdx
000073ef1c5d97c9  pop rcx
000073ef1c5d97ca  pop rax
000073ef1c5d97cb  add rsp, 0x08
000073ef1c5d97cf  jmp 0x000073EF1C5D628A
000073ef1c5d97d4  sub rsp, 0x08
000073ef1c5d97d8  push rax
000073ef1c5d97d9  push rcx
000073ef1c5d97da  push rdx
000073ef1c5d97db  push rdi
000073ef1c5d97dc  push rsi
000073ef1c5d97dd  push r8
000073ef1c5d97df  push r9
000073ef1c5d97e1  push r10
000073ef1c5d97e3  push r11
000073ef1c5d97e5  sub rsp, 0xF0
000073ef1c5d97ec  vmovaps [rsp], xmm0
000073ef1c5d97f1  vmovaps [rsp+0x10], xmm1
000073ef1c5d97f7  vmovaps [rsp+0x20], xmm2
000073ef1c5d97fd  vmovaps [rsp+0x30], xmm3
000073ef1c5d9803  vmovaps [rsp+0x40], xmm4
000073ef1c5d9809  vmovaps [rsp+0x50], xmm5
000073ef1c5d980f  vmovaps [rsp+0x60], xmm6
000073ef1c5d9815  vmovaps [rsp+0x70], xmm7
000073ef1c5d981b  vmovaps [rsp+0x80], xmm8
000073ef1c5d9824  vmovaps [rsp+0x90], xmm9
000073ef1c5d982d  vmovaps [rsp+0xA0], xmm10
000073ef1c5d9836  vmovaps [rsp+0xB0], xmm11
000073ef1c5d983f  vmovaps [rsp+0xC0], xmm12
000073ef1c5d9848  vmovaps [rsp+0xD0], xmm14
000073ef1c5d9851  vmovaps [rsp+0xE0], xmm15
000073ef1c5d985a  sub rsp, 0x30
000073ef1c5d985e  movaps [rsp], xmm13
000073ef1c5d9863  movaps [rsp+0x10], xmm15
000073ef1c5d9869  movaps [rsp+0x20], xmm9
000073ef1c5d986f  lea rdi, [rsp]
000073ef1c5d9873  mov esi, 0x00
000073ef1c5d9878  mov rax, 0x56F25E118530
000073ef1c5d9882  call rax
000073ef1c5d9884  movaps xmm13, [rsp]
000073ef1c5d9889  add rsp, 0x30
000073ef1c5d988d  vmovaps xmm0, [rsp]
000073ef1c5d9892  vmovaps xmm1, [rsp+0x10]
000073ef1c5d9898  vmovaps xmm2, [rsp+0x20]
000073ef1c5d989e  vmovaps xmm3, [rsp+0x30]
000073ef1c5d98a4  vmovaps xmm4, [rsp+0x40]
000073ef1c5d98aa  vmovaps xmm5, [rsp+0x50]
000073ef1c5d98b0  vmovaps xmm6, [rsp+0x60]
000073ef1c5d98b6  vmovaps xmm7, [rsp+0x70]
000073ef1c5d98bc  vmovaps xmm8, [rsp+0x80]
000073ef1c5d98c5  vmovaps xmm9, [rsp+0x90]
000073ef1c5d98ce  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d98d7  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d98e0  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d98e9  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d98f2  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d98fb  add rsp, 0xF0
000073ef1c5d9902  pop r11
000073ef1c5d9904  pop r10
000073ef1c5d9906  pop r9
000073ef1c5d9908  pop r8
000073ef1c5d990a  pop rsi
000073ef1c5d990b  pop rdi
000073ef1c5d990c  pop rdx
000073ef1c5d990d  pop rcx
000073ef1c5d990e  pop rax
000073ef1c5d990f  add rsp, 0x08
000073ef1c5d9913  jmp 0x000073EF1C5D62A5
000073ef1c5d9918  sub rsp, 0x08
000073ef1c5d991c  push rax
000073ef1c5d991d  push rcx
000073ef1c5d991e  push rdx
000073ef1c5d991f  push rdi
000073ef1c5d9920  push rsi
000073ef1c5d9921  push r8
000073ef1c5d9923  push r9
000073ef1c5d9925  push r10
000073ef1c5d9927  push r11
000073ef1c5d9929  sub rsp, 0xF0
000073ef1c5d9930  vmovaps [rsp], xmm0
000073ef1c5d9935  vmovaps [rsp+0x10], xmm1
000073ef1c5d993b  vmovaps [rsp+0x20], xmm2
000073ef1c5d9941  vmovaps [rsp+0x30], xmm3
000073ef1c5d9947  vmovaps [rsp+0x40], xmm4
000073ef1c5d994d  vmovaps [rsp+0x50], xmm5
000073ef1c5d9953  vmovaps [rsp+0x60], xmm6
000073ef1c5d9959  vmovaps [rsp+0x70], xmm7
000073ef1c5d995f  vmovaps [rsp+0x80], xmm8
000073ef1c5d9968  vmovaps [rsp+0x90], xmm9
000073ef1c5d9971  vmovaps [rsp+0xA0], xmm10
000073ef1c5d997a  vmovaps [rsp+0xB0], xmm11
000073ef1c5d9983  vmovaps [rsp+0xC0], xmm12
000073ef1c5d998c  vmovaps [rsp+0xD0], xmm13
000073ef1c5d9995  vmovaps [rsp+0xE0], xmm14
000073ef1c5d999e  sub rsp, 0x30
000073ef1c5d99a2  movaps [rsp], xmm15
000073ef1c5d99a7  movaps [rsp+0x10], xmm1
000073ef1c5d99ac  movaps [rsp+0x20], xmm5
000073ef1c5d99b1  lea rdi, [rsp]
000073ef1c5d99b5  mov esi, 0x00
000073ef1c5d99ba  mov rax, 0x56F25E118530
000073ef1c5d99c4  call rax
000073ef1c5d99c6  movaps xmm15, [rsp]
000073ef1c5d99cb  add rsp, 0x30
000073ef1c5d99cf  vmovaps xmm0, [rsp]
000073ef1c5d99d4  vmovaps xmm1, [rsp+0x10]
000073ef1c5d99da  vmovaps xmm2, [rsp+0x20]
000073ef1c5d99e0  vmovaps xmm3, [rsp+0x30]
000073ef1c5d99e6  vmovaps xmm4, [rsp+0x40]
000073ef1c5d99ec  vmovaps xmm5, [rsp+0x50]
000073ef1c5d99f2  vmovaps xmm6, [rsp+0x60]
000073ef1c5d99f8  vmovaps xmm7, [rsp+0x70]
000073ef1c5d99fe  vmovaps xmm8, [rsp+0x80]
000073ef1c5d9a07  vmovaps xmm9, [rsp+0x90]
000073ef1c5d9a10  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d9a19  vmovaps xmm11, [rsp+0xB0]
000073ef1c5d9a22  vmovaps xmm12, [rsp+0xC0]
000073ef1c5d9a2b  vmovaps xmm13, [rsp+0xD0]
000073ef1c5d9a34  vmovaps xmm14, [rsp+0xE0]
000073ef1c5d9a3d  add rsp, 0xF0
000073ef1c5d9a44  pop r11
000073ef1c5d9a46  pop r10
000073ef1c5d9a48  pop r9
000073ef1c5d9a4a  pop r8
000073ef1c5d9a4c  pop rsi
000073ef1c5d9a4d  pop rdi
000073ef1c5d9a4e  pop rdx
000073ef1c5d9a4f  pop rcx
000073ef1c5d9a50  pop rax
000073ef1c5d9a51  add rsp, 0x08
000073ef1c5d9a55  jmp 0x000073EF1C5D62C0
000073ef1c5d9a5a  call 0x000073EF1C4D64F0
000073ef1c5d9a5f  jmp 0x000073EF1C5D631B
000073ef1c5d9a64  sub rsp, 0x08
000073ef1c5d9a68  push rax
000073ef1c5d9a69  push rcx
000073ef1c5d9a6a  push rdx
000073ef1c5d9a6b  push rdi
000073ef1c5d9a6c  push rsi
000073ef1c5d9a6d  push r8
000073ef1c5d9a6f  push r9
000073ef1c5d9a71  push r10
000073ef1c5d9a73  push r11
000073ef1c5d9a75  sub rsp, 0xF0
000073ef1c5d9a7c  vmovaps [rsp], xmm0
000073ef1c5d9a81  vmovaps [rsp+0x10], xmm1
000073ef1c5d9a87  vmovaps [rsp+0x20], xmm2
000073ef1c5d9a8d  vmovaps [rsp+0x30], xmm3
000073ef1c5d9a93  vmovaps [rsp+0x40], xmm4
000073ef1c5d9a99  vmovaps [rsp+0x50], xmm5
000073ef1c5d9a9f  vmovaps [rsp+0x60], xmm6
000073ef1c5d9aa5  vmovaps [rsp+0x70], xmm7
000073ef1c5d9aab  vmovaps [rsp+0x80], xmm8
000073ef1c5d9ab4  vmovaps [rsp+0x90], xmm10
000073ef1c5d9abd  vmovaps [rsp+0xA0], xmm11
000073ef1c5d9ac6  vmovaps [rsp+0xB0], xmm12
000073ef1c5d9acf  vmovaps [rsp+0xC0], xmm13
000073ef1c5d9ad8  vmovaps [rsp+0xD0], xmm14
000073ef1c5d9ae1  vmovaps [rsp+0xE0], xmm15
000073ef1c5d9aea  sub rsp, 0x30
000073ef1c5d9aee  movaps [rsp], xmm9
000073ef1c5d9af3  movaps [rsp+0x10], xmm8
000073ef1c5d9af9  movaps [rsp+0x20], xmm11
000073ef1c5d9aff  lea rdi, [rsp]
000073ef1c5d9b03  mov esi, 0x00
000073ef1c5d9b08  mov rax, 0x56F25E118530
000073ef1c5d9b12  call rax
000073ef1c5d9b14  movaps xmm9, [rsp]
000073ef1c5d9b19  add rsp, 0x30
000073ef1c5d9b1d  vmovaps xmm0, [rsp]
000073ef1c5d9b22  vmovaps xmm1, [rsp+0x10]
000073ef1c5d9b28  vmovaps xmm2, [rsp+0x20]
000073ef1c5d9b2e  vmovaps xmm3, [rsp+0x30]
000073ef1c5d9b34  vmovaps xmm4, [rsp+0x40]
000073ef1c5d9b3a  vmovaps xmm5, [rsp+0x50]
000073ef1c5d9b40  vmovaps xmm6, [rsp+0x60]
000073ef1c5d9b46  vmovaps xmm7, [rsp+0x70]
000073ef1c5d9b4c  vmovaps xmm8, [rsp+0x80]
000073ef1c5d9b55  vmovaps xmm10, [rsp+0x90]
000073ef1c5d9b5e  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d9b67  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d9b70  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d9b79  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d9b82  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d9b8b  add rsp, 0xF0
000073ef1c5d9b92  pop r11
000073ef1c5d9b94  pop r10
000073ef1c5d9b96  pop r9
000073ef1c5d9b98  pop r8
000073ef1c5d9b9a  pop rsi
000073ef1c5d9b9b  pop rdi
000073ef1c5d9b9c  pop rdx
000073ef1c5d9b9d  pop rcx
000073ef1c5d9b9e  pop rax
000073ef1c5d9b9f  add rsp, 0x08
000073ef1c5d9ba3  jmp 0x000073EF1C5D6352
000073ef1c5d9ba8  sub rsp, 0x08
000073ef1c5d9bac  push rax
000073ef1c5d9bad  push rcx
000073ef1c5d9bae  push rdx
000073ef1c5d9baf  push rdi
000073ef1c5d9bb0  push rsi
000073ef1c5d9bb1  push r8
000073ef1c5d9bb3  push r9
000073ef1c5d9bb5  push r10
000073ef1c5d9bb7  push r11
000073ef1c5d9bb9  sub rsp, 0xF0
000073ef1c5d9bc0  vmovaps [rsp], xmm0
000073ef1c5d9bc5  vmovaps [rsp+0x10], xmm1
000073ef1c5d9bcb  vmovaps [rsp+0x20], xmm2
000073ef1c5d9bd1  vmovaps [rsp+0x30], xmm3
000073ef1c5d9bd7  vmovaps [rsp+0x40], xmm4
000073ef1c5d9bdd  vmovaps [rsp+0x50], xmm5
000073ef1c5d9be3  vmovaps [rsp+0x60], xmm6
000073ef1c5d9be9  vmovaps [rsp+0x70], xmm7
000073ef1c5d9bef  vmovaps [rsp+0x80], xmm8
000073ef1c5d9bf8  vmovaps [rsp+0x90], xmm9
000073ef1c5d9c01  vmovaps [rsp+0xA0], xmm10
000073ef1c5d9c0a  vmovaps [rsp+0xB0], xmm12
000073ef1c5d9c13  vmovaps [rsp+0xC0], xmm13
000073ef1c5d9c1c  vmovaps [rsp+0xD0], xmm14
000073ef1c5d9c25  vmovaps [rsp+0xE0], xmm15
000073ef1c5d9c2e  sub rsp, 0x30
000073ef1c5d9c32  movaps [rsp], xmm11
000073ef1c5d9c37  movaps [rsp+0x10], xmm10
000073ef1c5d9c3d  movaps [rsp+0x20], xmm6
000073ef1c5d9c42  lea rdi, [rsp]
000073ef1c5d9c46  mov esi, 0x00
000073ef1c5d9c4b  mov rax, 0x56F25E118530
000073ef1c5d9c55  call rax
000073ef1c5d9c57  movaps xmm11, [rsp]
000073ef1c5d9c5c  add rsp, 0x30
000073ef1c5d9c60  vmovaps xmm0, [rsp]
000073ef1c5d9c65  vmovaps xmm1, [rsp+0x10]
000073ef1c5d9c6b  vmovaps xmm2, [rsp+0x20]
000073ef1c5d9c71  vmovaps xmm3, [rsp+0x30]
000073ef1c5d9c77  vmovaps xmm4, [rsp+0x40]
000073ef1c5d9c7d  vmovaps xmm5, [rsp+0x50]
000073ef1c5d9c83  vmovaps xmm6, [rsp+0x60]
000073ef1c5d9c89  vmovaps xmm7, [rsp+0x70]
000073ef1c5d9c8f  vmovaps xmm8, [rsp+0x80]
000073ef1c5d9c98  vmovaps xmm9, [rsp+0x90]
000073ef1c5d9ca1  vmovaps xmm10, [rsp+0xA0]
000073ef1c5d9caa  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d9cb3  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d9cbc  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d9cc5  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d9cce  add rsp, 0xF0
000073ef1c5d9cd5  pop r11
000073ef1c5d9cd7  pop r10
000073ef1c5d9cd9  pop r9
000073ef1c5d9cdb  pop r8
000073ef1c5d9cdd  pop rsi
000073ef1c5d9cde  pop rdi
000073ef1c5d9cdf  pop rdx
000073ef1c5d9ce0  pop rcx
000073ef1c5d9ce1  pop rax
000073ef1c5d9ce2  add rsp, 0x08
000073ef1c5d9ce6  jmp 0x000073EF1C5D636D
000073ef1c5d9ceb  sub rsp, 0x08
000073ef1c5d9cef  push rax
000073ef1c5d9cf0  push rcx
000073ef1c5d9cf1  push rdx
000073ef1c5d9cf2  push rdi
000073ef1c5d9cf3  push rsi
000073ef1c5d9cf4  push r8
000073ef1c5d9cf6  push r9
000073ef1c5d9cf8  push r10
000073ef1c5d9cfa  push r11
000073ef1c5d9cfc  sub rsp, 0xF0
000073ef1c5d9d03  vmovaps [rsp], xmm0
000073ef1c5d9d08  vmovaps [rsp+0x10], xmm1
000073ef1c5d9d0e  vmovaps [rsp+0x20], xmm2
000073ef1c5d9d14  vmovaps [rsp+0x30], xmm3
000073ef1c5d9d1a  vmovaps [rsp+0x40], xmm4
000073ef1c5d9d20  vmovaps [rsp+0x50], xmm5
000073ef1c5d9d26  vmovaps [rsp+0x60], xmm6
000073ef1c5d9d2c  vmovaps [rsp+0x70], xmm7
000073ef1c5d9d32  vmovaps [rsp+0x80], xmm8
000073ef1c5d9d3b  vmovaps [rsp+0x90], xmm9
000073ef1c5d9d44  vmovaps [rsp+0xA0], xmm11
000073ef1c5d9d4d  vmovaps [rsp+0xB0], xmm12
000073ef1c5d9d56  vmovaps [rsp+0xC0], xmm13
000073ef1c5d9d5f  vmovaps [rsp+0xD0], xmm14
000073ef1c5d9d68  vmovaps [rsp+0xE0], xmm15
000073ef1c5d9d71  sub rsp, 0x30
000073ef1c5d9d75  movaps [rsp], xmm10
000073ef1c5d9d7a  movaps [rsp+0x10], xmm14
000073ef1c5d9d80  movaps [rsp+0x20], xmm4
000073ef1c5d9d85  lea rdi, [rsp]
000073ef1c5d9d89  mov esi, 0x00
000073ef1c5d9d8e  mov rax, 0x56F25E118530
000073ef1c5d9d98  call rax
000073ef1c5d9d9a  movaps xmm10, [rsp]
000073ef1c5d9d9f  add rsp, 0x30
000073ef1c5d9da3  vmovaps xmm0, [rsp]
000073ef1c5d9da8  vmovaps xmm1, [rsp+0x10]
000073ef1c5d9dae  vmovaps xmm2, [rsp+0x20]
000073ef1c5d9db4  vmovaps xmm3, [rsp+0x30]
000073ef1c5d9dba  vmovaps xmm4, [rsp+0x40]
000073ef1c5d9dc0  vmovaps xmm5, [rsp+0x50]
000073ef1c5d9dc6  vmovaps xmm6, [rsp+0x60]
000073ef1c5d9dcc  vmovaps xmm7, [rsp+0x70]
000073ef1c5d9dd2  vmovaps xmm8, [rsp+0x80]
000073ef1c5d9ddb  vmovaps xmm9, [rsp+0x90]
000073ef1c5d9de4  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d9ded  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d9df6  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d9dff  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d9e08  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d9e11  add rsp, 0xF0
000073ef1c5d9e18  pop r11
000073ef1c5d9e1a  pop r10
000073ef1c5d9e1c  pop r9
000073ef1c5d9e1e  pop r8
000073ef1c5d9e20  pop rsi
000073ef1c5d9e21  pop rdi
000073ef1c5d9e22  pop rdx
000073ef1c5d9e23  pop rcx
000073ef1c5d9e24  pop rax
000073ef1c5d9e25  add rsp, 0x08
000073ef1c5d9e29  jmp 0x000073EF1C5D6388
000073ef1c5d9e2e  sub rsp, 0x08
000073ef1c5d9e32  push rax
000073ef1c5d9e33  push rcx
000073ef1c5d9e34  push rdx
000073ef1c5d9e35  push rdi
000073ef1c5d9e36  push rsi
000073ef1c5d9e37  push r8
000073ef1c5d9e39  push r9
000073ef1c5d9e3b  push r10
000073ef1c5d9e3d  push r11
000073ef1c5d9e3f  sub rsp, 0xF0
000073ef1c5d9e46  vmovaps [rsp], xmm0
000073ef1c5d9e4b  vmovaps [rsp+0x10], xmm1
000073ef1c5d9e51  vmovaps [rsp+0x20], xmm2
000073ef1c5d9e57  vmovaps [rsp+0x30], xmm3
000073ef1c5d9e5d  vmovaps [rsp+0x40], xmm4
000073ef1c5d9e63  vmovaps [rsp+0x50], xmm5
000073ef1c5d9e69  vmovaps [rsp+0x60], xmm6
000073ef1c5d9e6f  vmovaps [rsp+0x70], xmm7
000073ef1c5d9e75  vmovaps [rsp+0x80], xmm9
000073ef1c5d9e7e  vmovaps [rsp+0x90], xmm10
000073ef1c5d9e87  vmovaps [rsp+0xA0], xmm11
000073ef1c5d9e90  vmovaps [rsp+0xB0], xmm12
000073ef1c5d9e99  vmovaps [rsp+0xC0], xmm13
000073ef1c5d9ea2  vmovaps [rsp+0xD0], xmm14
000073ef1c5d9eab  vmovaps [rsp+0xE0], xmm15
000073ef1c5d9eb4  sub rsp, 0x30
000073ef1c5d9eb8  movaps [rsp], xmm8
000073ef1c5d9ebd  movaps [rsp+0x10], xmm1
000073ef1c5d9ec2  movaps [rsp+0x20], xmm14
000073ef1c5d9ec8  lea rdi, [rsp]
000073ef1c5d9ecc  mov esi, 0x00
000073ef1c5d9ed1  mov rax, 0x56F25E118530
000073ef1c5d9edb  call rax
000073ef1c5d9edd  movaps xmm8, [rsp]
000073ef1c5d9ee2  add rsp, 0x30
000073ef1c5d9ee6  vmovaps xmm0, [rsp]
000073ef1c5d9eeb  vmovaps xmm1, [rsp+0x10]
000073ef1c5d9ef1  vmovaps xmm2, [rsp+0x20]
000073ef1c5d9ef7  vmovaps xmm3, [rsp+0x30]
000073ef1c5d9efd  vmovaps xmm4, [rsp+0x40]
000073ef1c5d9f03  vmovaps xmm5, [rsp+0x50]
000073ef1c5d9f09  vmovaps xmm6, [rsp+0x60]
000073ef1c5d9f0f  vmovaps xmm7, [rsp+0x70]
000073ef1c5d9f15  vmovaps xmm9, [rsp+0x80]
000073ef1c5d9f1e  vmovaps xmm10, [rsp+0x90]
000073ef1c5d9f27  vmovaps xmm11, [rsp+0xA0]
000073ef1c5d9f30  vmovaps xmm12, [rsp+0xB0]
000073ef1c5d9f39  vmovaps xmm13, [rsp+0xC0]
000073ef1c5d9f42  vmovaps xmm14, [rsp+0xD0]
000073ef1c5d9f4b  vmovaps xmm15, [rsp+0xE0]
000073ef1c5d9f54  add rsp, 0xF0
000073ef1c5d9f5b  pop r11
000073ef1c5d9f5d  pop r10
000073ef1c5d9f5f  pop r9
000073ef1c5d9f61  pop r8
000073ef1c5d9f63  pop rsi
000073ef1c5d9f64  pop rdi
000073ef1c5d9f65  pop rdx
000073ef1c5d9f66  pop rcx
000073ef1c5d9f67  pop rax
000073ef1c5d9f68  add rsp, 0x08
000073ef1c5d9f6c  jmp 0x000073EF1C5D63AE
000073ef1c5d9f71  sub rsp, 0x08
000073ef1c5d9f75  push rax
000073ef1c5d9f76  push rcx
000073ef1c5d9f77  push rdx
000073ef1c5d9f78  push rdi
000073ef1c5d9f79  push rsi
000073ef1c5d9f7a  push r8
000073ef1c5d9f7c  push r9
000073ef1c5d9f7e  push r10
000073ef1c5d9f80  push r11
000073ef1c5d9f82  sub rsp, 0xF0
000073ef1c5d9f89  vmovaps [rsp], xmm0
000073ef1c5d9f8e  vmovaps [rsp+0x10], xmm1
000073ef1c5d9f94  vmovaps [rsp+0x20], xmm2
000073ef1c5d9f9a  vmovaps [rsp+0x30], xmm3
000073ef1c5d9fa0  vmovaps [rsp+0x40], xmm4
000073ef1c5d9fa6  vmovaps [rsp+0x50], xmm5
000073ef1c5d9fac  vmovaps [rsp+0x60], xmm7
000073ef1c5d9fb2  vmovaps [rsp+0x70], xmm8
000073ef1c5d9fb8  vmovaps [rsp+0x80], xmm9
000073ef1c5d9fc1  vmovaps [rsp+0x90], xmm10
000073ef1c5d9fca  vmovaps [rsp+0xA0], xmm11
000073ef1c5d9fd3  vmovaps [rsp+0xB0], xmm12
000073ef1c5d9fdc  vmovaps [rsp+0xC0], xmm13
000073ef1c5d9fe5  vmovaps [rsp+0xD0], xmm14
000073ef1c5d9fee  vmovaps [rsp+0xE0], xmm15
000073ef1c5d9ff7  sub rsp, 0x30
000073ef1c5d9ffb  movaps [rsp], xmm6
000073ef1c5d9fff  movaps [rsp+0x10], xmm1
000073ef1c5da004  movaps [rsp+0x20], xmm14
000073ef1c5da00a  lea rdi, [rsp]
000073ef1c5da00e  mov esi, 0x00
000073ef1c5da013  mov rax, 0x56F25E118530
000073ef1c5da01d  call rax
000073ef1c5da01f  movaps xmm6, [rsp]
000073ef1c5da023  add rsp, 0x30
000073ef1c5da027  vmovaps xmm0, [rsp]
000073ef1c5da02c  vmovaps xmm1, [rsp+0x10]
000073ef1c5da032  vmovaps xmm2, [rsp+0x20]
000073ef1c5da038  vmovaps xmm3, [rsp+0x30]
000073ef1c5da03e  vmovaps xmm4, [rsp+0x40]
000073ef1c5da044  vmovaps xmm5, [rsp+0x50]
000073ef1c5da04a  vmovaps xmm7, [rsp+0x60]
000073ef1c5da050  vmovaps xmm8, [rsp+0x70]
000073ef1c5da056  vmovaps xmm9, [rsp+0x80]
000073ef1c5da05f  vmovaps xmm10, [rsp+0x90]
000073ef1c5da068  vmovaps xmm11, [rsp+0xA0]
000073ef1c5da071  vmovaps xmm12, [rsp+0xB0]
000073ef1c5da07a  vmovaps xmm13, [rsp+0xC0]
000073ef1c5da083  vmovaps xmm14, [rsp+0xD0]
000073ef1c5da08c  vmovaps xmm15, [rsp+0xE0]
000073ef1c5da095  add rsp, 0xF0
000073ef1c5da09c  pop r11
000073ef1c5da09e  pop r10
000073ef1c5da0a0  pop r9
000073ef1c5da0a2  pop r8
000073ef1c5da0a4  pop rsi
000073ef1c5da0a5  pop rdi
000073ef1c5da0a6  pop rdx
000073ef1c5da0a7  pop rcx
000073ef1c5da0a8  pop rax
000073ef1c5da0a9  add rsp, 0x08
000073ef1c5da0ad  jmp 0x000073EF1C5D63DA
000073ef1c5da0b2  sub rsp, 0x08
000073ef1c5da0b6  push rax
000073ef1c5da0b7  push rcx
000073ef1c5da0b8  push rdx
000073ef1c5da0b9  push rdi
000073ef1c5da0ba  push rsi
000073ef1c5da0bb  push r8
000073ef1c5da0bd  push r9
000073ef1c5da0bf  push r10
000073ef1c5da0c1  push r11
000073ef1c5da0c3  sub rsp, 0xF0
000073ef1c5da0ca  vmovaps [rsp], xmm0
000073ef1c5da0cf  vmovaps [rsp+0x10], xmm1
000073ef1c5da0d5  vmovaps [rsp+0x20], xmm2
000073ef1c5da0db  vmovaps [rsp+0x30], xmm3
000073ef1c5da0e1  vmovaps [rsp+0x40], xmm4
000073ef1c5da0e7  vmovaps [rsp+0x50], xmm5
000073ef1c5da0ed  vmovaps [rsp+0x60], xmm6
000073ef1c5da0f3  vmovaps [rsp+0x70], xmm7
000073ef1c5da0f9  vmovaps [rsp+0x80], xmm8
000073ef1c5da102  vmovaps [rsp+0x90], xmm9
000073ef1c5da10b  vmovaps [rsp+0xA0], xmm10
000073ef1c5da114  vmovaps [rsp+0xB0], xmm11
000073ef1c5da11d  vmovaps [rsp+0xC0], xmm12
000073ef1c5da126  vmovaps [rsp+0xD0], xmm13
000073ef1c5da12f  vmovaps [rsp+0xE0], xmm15
000073ef1c5da138  sub rsp, 0x30
000073ef1c5da13c  movaps [rsp], xmm14
000073ef1c5da141  movaps [rsp+0x10], xmm12
000073ef1c5da147  movaps [rsp+0x20], xmm1
000073ef1c5da14c  lea rdi, [rsp]
000073ef1c5da150  mov esi, 0x00
000073ef1c5da155  mov rax, 0x56F25E118530
000073ef1c5da15f  call rax
000073ef1c5da161  movaps xmm14, [rsp]
000073ef1c5da166  add rsp, 0x30
000073ef1c5da16a  vmovaps xmm0, [rsp]
000073ef1c5da16f  vmovaps xmm1, [rsp+0x10]
000073ef1c5da175  vmovaps xmm2, [rsp+0x20]
000073ef1c5da17b  vmovaps xmm3, [rsp+0x30]
000073ef1c5da181  vmovaps xmm4, [rsp+0x40]
000073ef1c5da187  vmovaps xmm5, [rsp+0x50]
000073ef1c5da18d  vmovaps xmm6, [rsp+0x60]
000073ef1c5da193  vmovaps xmm7, [rsp+0x70]
000073ef1c5da199  vmovaps xmm8, [rsp+0x80]
000073ef1c5da1a2  vmovaps xmm9, [rsp+0x90]
000073ef1c5da1ab  vmovaps xmm10, [rsp+0xA0]
000073ef1c5da1b4  vmovaps xmm11, [rsp+0xB0]
000073ef1c5da1bd  vmovaps xmm12, [rsp+0xC0]
000073ef1c5da1c6  vmovaps xmm13, [rsp+0xD0]
000073ef1c5da1cf  vmovaps xmm15, [rsp+0xE0]
000073ef1c5da1d8  add rsp, 0xF0
000073ef1c5da1df  pop r11
000073ef1c5da1e1  pop r10
000073ef1c5da1e3  pop r9
000073ef1c5da1e5  pop r8
000073ef1c5da1e7  pop rsi
000073ef1c5da1e8  pop rdi
000073ef1c5da1e9  pop rdx
000073ef1c5da1ea  pop rcx
000073ef1c5da1eb  pop rax
000073ef1c5da1ec  add rsp, 0x08
000073ef1c5da1f0  jmp 0x000073EF1C5D6400
000073ef1c5da1f5  sub rsp, 0x08
000073ef1c5da1f9  push rax
000073ef1c5da1fa  push rcx
000073ef1c5da1fb  push rdx
000073ef1c5da1fc  push rdi
000073ef1c5da1fd  push rsi
000073ef1c5da1fe  push r8
000073ef1c5da200  push r9
000073ef1c5da202  push r10
000073ef1c5da204  push r11
000073ef1c5da206  sub rsp, 0xF0
000073ef1c5da20d  vmovaps [rsp], xmm0
000073ef1c5da212  vmovaps [rsp+0x10], xmm2
000073ef1c5da218  vmovaps [rsp+0x20], xmm3
000073ef1c5da21e  vmovaps [rsp+0x30], xmm4
000073ef1c5da224  vmovaps [rsp+0x40], xmm5
000073ef1c5da22a  vmovaps [rsp+0x50], xmm6
000073ef1c5da230  vmovaps [rsp+0x60], xmm7
000073ef1c5da236  vmovaps [rsp+0x70], xmm8
000073ef1c5da23c  vmovaps [rsp+0x80], xmm9
000073ef1c5da245  vmovaps [rsp+0x90], xmm10
000073ef1c5da24e  vmovaps [rsp+0xA0], xmm11
000073ef1c5da257  vmovaps [rsp+0xB0], xmm12
000073ef1c5da260  vmovaps [rsp+0xC0], xmm13
000073ef1c5da269  vmovaps [rsp+0xD0], xmm14
000073ef1c5da272  vmovaps [rsp+0xE0], xmm15
000073ef1c5da27b  sub rsp, 0x30
000073ef1c5da27f  movaps [rsp], xmm1
000073ef1c5da283  movaps [rsp+0x10], xmm13
000073ef1c5da289  movaps [rsp+0x20], xmm9
000073ef1c5da28f  lea rdi, [rsp]
000073ef1c5da293  mov esi, 0x00
000073ef1c5da298  mov rax, 0x56F25E118530
000073ef1c5da2a2  call rax
000073ef1c5da2a4  movaps xmm1, [rsp]
000073ef1c5da2a8  add rsp, 0x30
000073ef1c5da2ac  vmovaps xmm0, [rsp]
000073ef1c5da2b1  vmovaps xmm2, [rsp+0x10]
000073ef1c5da2b7  vmovaps xmm3, [rsp+0x20]
000073ef1c5da2bd  vmovaps xmm4, [rsp+0x30]
000073ef1c5da2c3  vmovaps xmm5, [rsp+0x40]
000073ef1c5da2c9  vmovaps xmm6, [rsp+0x50]
000073ef1c5da2cf  vmovaps xmm7, [rsp+0x60]
000073ef1c5da2d5  vmovaps xmm8, [rsp+0x70]
000073ef1c5da2db  vmovaps xmm9, [rsp+0x80]
000073ef1c5da2e4  vmovaps xmm10, [rsp+0x90]
000073ef1c5da2ed  vmovaps xmm11, [rsp+0xA0]
000073ef1c5da2f6  vmovaps xmm12, [rsp+0xB0]
000073ef1c5da2ff  vmovaps xmm13, [rsp+0xC0]
000073ef1c5da308  vmovaps xmm14, [rsp+0xD0]
000073ef1c5da311  vmovaps xmm15, [rsp+0xE0]
000073ef1c5da31a  add rsp, 0xF0
000073ef1c5da321  pop r11
000073ef1c5da323  pop r10
000073ef1c5da325  pop r9
000073ef1c5da327  pop r8
000073ef1c5da329  pop rsi
000073ef1c5da32a  pop rdi
000073ef1c5da32b  pop rdx
000073ef1c5da32c  pop rcx
000073ef1c5da32d  pop rax
000073ef1c5da32e  add rsp, 0x08
000073ef1c5da332  jmp 0x000073EF1C5D641A
000073ef1c5da337  sub rsp, 0x08
000073ef1c5da33b  push rax
000073ef1c5da33c  push rcx
000073ef1c5da33d  push rdx
000073ef1c5da33e  push rdi
000073ef1c5da33f  push rsi
000073ef1c5da340  push r8
000073ef1c5da342  push r9
000073ef1c5da344  push r10
000073ef1c5da346  push r11
000073ef1c5da348  sub rsp, 0xF0
000073ef1c5da34f  vmovaps [rsp], xmm0
000073ef1c5da354  vmovaps [rsp+0x10], xmm1
000073ef1c5da35a  vmovaps [rsp+0x20], xmm2
000073ef1c5da360  vmovaps [rsp+0x30], xmm3
000073ef1c5da366  vmovaps [rsp+0x40], xmm4
000073ef1c5da36c  vmovaps [rsp+0x50], xmm5
000073ef1c5da372  vmovaps [rsp+0x60], xmm6
000073ef1c5da378  vmovaps [rsp+0x70], xmm7
000073ef1c5da37e  vmovaps [rsp+0x80], xmm8
000073ef1c5da387  vmovaps [rsp+0x90], xmm9
000073ef1c5da390  vmovaps [rsp+0xA0], xmm10
000073ef1c5da399  vmovaps [rsp+0xB0], xmm11
000073ef1c5da3a2  vmovaps [rsp+0xC0], xmm13
000073ef1c5da3ab  vmovaps [rsp+0xD0], xmm14
000073ef1c5da3b4  vmovaps [rsp+0xE0], xmm15
000073ef1c5da3bd  sub rsp, 0x30
000073ef1c5da3c1  movaps [rsp], xmm12
000073ef1c5da3c6  movaps [rsp+0x10], xmm7
000073ef1c5da3cb  movaps [rsp+0x20], xmm13
000073ef1c5da3d1  lea rdi, [rsp]
000073ef1c5da3d5  mov esi, 0x00
000073ef1c5da3da  mov rax, 0x56F25E118530
000073ef1c5da3e4  call rax
000073ef1c5da3e6  movaps xmm12, [rsp]
000073ef1c5da3eb  add rsp, 0x30
000073ef1c5da3ef  vmovaps xmm0, [rsp]
000073ef1c5da3f4  vmovaps xmm1, [rsp+0x10]
000073ef1c5da3fa  vmovaps xmm2, [rsp+0x20]
000073ef1c5da400  vmovaps xmm3, [rsp+0x30]
000073ef1c5da406  vmovaps xmm4, [rsp+0x40]
000073ef1c5da40c  vmovaps xmm5, [rsp+0x50]
000073ef1c5da412  vmovaps xmm6, [rsp+0x60]
000073ef1c5da418  vmovaps xmm7, [rsp+0x70]
000073ef1c5da41e  vmovaps xmm8, [rsp+0x80]
000073ef1c5da427  vmovaps xmm9, [rsp+0x90]
000073ef1c5da430  vmovaps xmm10, [rsp+0xA0]
000073ef1c5da439  vmovaps xmm11, [rsp+0xB0]
000073ef1c5da442  vmovaps xmm13, [rsp+0xC0]
000073ef1c5da44b  vmovaps xmm14, [rsp+0xD0]
000073ef1c5da454  vmovaps xmm15, [rsp+0xE0]
000073ef1c5da45d  add rsp, 0xF0
000073ef1c5da464  pop r11
000073ef1c5da466  pop r10
000073ef1c5da468  pop r9
000073ef1c5da46a  pop r8
000073ef1c5da46c  pop rsi
000073ef1c5da46d  pop rdi
000073ef1c5da46e  pop rdx
000073ef1c5da46f  pop rcx
000073ef1c5da470  pop rax
000073ef1c5da471  add rsp, 0x08
000073ef1c5da475  jmp 0x000073EF1C5D6441
000073ef1c5da47a  sub rsp, 0x08
000073ef1c5da47e  push rax
000073ef1c5da47f  push rcx
000073ef1c5da480  push rdx
000073ef1c5da481  push rdi
000073ef1c5da482  push rsi
000073ef1c5da483  push r8
000073ef1c5da485  push r9
000073ef1c5da487  push r10
000073ef1c5da489  push r11
000073ef1c5da48b  sub rsp, 0xF0
000073ef1c5da492  vmovaps [rsp], xmm0
000073ef1c5da497  vmovaps [rsp+0x10], xmm1
000073ef1c5da49d  vmovaps [rsp+0x20], xmm2
000073ef1c5da4a3  vmovaps [rsp+0x30], xmm3
000073ef1c5da4a9  vmovaps [rsp+0x40], xmm4
000073ef1c5da4af  vmovaps [rsp+0x50], xmm5
000073ef1c5da4b5  vmovaps [rsp+0x60], xmm6
000073ef1c5da4bb  vmovaps [rsp+0x70], xmm7
000073ef1c5da4c1  vmovaps [rsp+0x80], xmm8
000073ef1c5da4ca  vmovaps [rsp+0x90], xmm9
000073ef1c5da4d3  vmovaps [rsp+0xA0], xmm10
000073ef1c5da4dc  vmovaps [rsp+0xB0], xmm11
000073ef1c5da4e5  vmovaps [rsp+0xC0], xmm12
000073ef1c5da4ee  vmovaps [rsp+0xD0], xmm14
000073ef1c5da4f7  vmovaps [rsp+0xE0], xmm15
000073ef1c5da500  sub rsp, 0x30
000073ef1c5da504  movaps [rsp], xmm13
000073ef1c5da509  movaps [rsp+0x10], xmm15
000073ef1c5da50f  movaps [rsp+0x20], xmm8
000073ef1c5da515  lea rdi, [rsp]
000073ef1c5da519  mov esi, 0x00
000073ef1c5da51e  mov rax, 0x56F25E118530
000073ef1c5da528  call rax
000073ef1c5da52a  movaps xmm13, [rsp]
000073ef1c5da52f  add rsp, 0x30
000073ef1c5da533  vmovaps xmm0, [rsp]
000073ef1c5da538  vmovaps xmm1, [rsp+0x10]
000073ef1c5da53e  vmovaps xmm2, [rsp+0x20]
000073ef1c5da544  vmovaps xmm3, [rsp+0x30]
000073ef1c5da54a  vmovaps xmm4, [rsp+0x40]
000073ef1c5da550  vmovaps xmm5, [rsp+0x50]
000073ef1c5da556  vmovaps xmm6, [rsp+0x60]
000073ef1c5da55c  vmovaps xmm7, [rsp+0x70]
000073ef1c5da562  vmovaps xmm8, [rsp+0x80]
000073ef1c5da56b  vmovaps xmm9, [rsp+0x90]
000073ef1c5da574  vmovaps xmm10, [rsp+0xA0]
000073ef1c5da57d  vmovaps xmm11, [rsp+0xB0]
000073ef1c5da586  vmovaps xmm12, [rsp+0xC0]
000073ef1c5da58f  vmovaps xmm14, [rsp+0xD0]
000073ef1c5da598  vmovaps xmm15, [rsp+0xE0]
000073ef1c5da5a1  add rsp, 0xF0
000073ef1c5da5a8  pop r11
000073ef1c5da5aa  pop r10
000073ef1c5da5ac  pop r9
000073ef1c5da5ae  pop r8
000073ef1c5da5b0  pop rsi
000073ef1c5da5b1  pop rdi
000073ef1c5da5b2  pop rdx
000073ef1c5da5b3  pop rcx
000073ef1c5da5b4  pop rax
000073ef1c5da5b5  add rsp, 0x08
000073ef1c5da5b9  jmp 0x000073EF1C5D645C
000073ef1c5da5be  sub rsp, 0x08
000073ef1c5da5c2  push rax
000073ef1c5da5c3  push rcx
000073ef1c5da5c4  push rdx
000073ef1c5da5c5  push rdi
000073ef1c5da5c6  push rsi
000073ef1c5da5c7  push r8
000073ef1c5da5c9  push r9
000073ef1c5da5cb  push r10
000073ef1c5da5cd  push r11
000073ef1c5da5cf  sub rsp, 0xF0
000073ef1c5da5d6  vmovaps [rsp], xmm0
000073ef1c5da5db  vmovaps [rsp+0x10], xmm1
000073ef1c5da5e1  vmovaps [rsp+0x20], xmm2
000073ef1c5da5e7  vmovaps [rsp+0x30], xmm3
000073ef1c5da5ed  vmovaps [rsp+0x40], xmm4
000073ef1c5da5f3  vmovaps [rsp+0x50], xmm5
000073ef1c5da5f9  vmovaps [rsp+0x60], xmm6
000073ef1c5da5ff  vmovaps [rsp+0x70], xmm7
000073ef1c5da605  vmovaps [rsp+0x80], xmm9
000073ef1c5da60e  vmovaps [rsp+0x90], xmm10
000073ef1c5da617  vmovaps [rsp+0xA0], xmm11
000073ef1c5da620  vmovaps [rsp+0xB0], xmm12
000073ef1c5da629  vmovaps [rsp+0xC0], xmm13
000073ef1c5da632  vmovaps [rsp+0xD0], xmm14
000073ef1c5da63b  vmovaps [rsp+0xE0], xmm15
000073ef1c5da644  sub rsp, 0x30
000073ef1c5da648  movaps [rsp], xmm8
000073ef1c5da64d  movaps [rsp+0x10], xmm15
000073ef1c5da653  movaps [rsp+0x20], xmm9
000073ef1c5da659  lea rdi, [rsp]
000073ef1c5da65d  mov esi, 0x00
000073ef1c5da662  mov rax, 0x56F25E118530
000073ef1c5da66c  call rax
000073ef1c5da66e  movaps xmm8, [rsp]
000073ef1c5da673  add rsp, 0x30
000073ef1c5da677  vmovaps xmm0, [rsp]
000073ef1c5da67c  vmovaps xmm1, [rsp+0x10]
000073ef1c5da682  vmovaps xmm2, [rsp+0x20]
000073ef1c5da688  vmovaps xmm3, [rsp+0x30]
000073ef1c5da68e  vmovaps xmm4, [rsp+0x40]
000073ef1c5da694  vmovaps xmm5, [rsp+0x50]
000073ef1c5da69a  vmovaps xmm6, [rsp+0x60]
000073ef1c5da6a0  vmovaps xmm7, [rsp+0x70]
000073ef1c5da6a6  vmovaps xmm9, [rsp+0x80]
000073ef1c5da6af  vmovaps xmm10, [rsp+0x90]
000073ef1c5da6b8  vmovaps xmm11, [rsp+0xA0]
000073ef1c5da6c1  vmovaps xmm12, [rsp+0xB0]
000073ef1c5da6ca  vmovaps xmm13, [rsp+0xC0]
000073ef1c5da6d3  vmovaps xmm14, [rsp+0xD0]
000073ef1c5da6dc  vmovaps xmm15, [rsp+0xE0]
000073ef1c5da6e5  add rsp, 0xF0
000073ef1c5da6ec  pop r11
000073ef1c5da6ee  pop r10
000073ef1c5da6f0  pop r9
000073ef1c5da6f2  pop r8
000073ef1c5da6f4  pop rsi
000073ef1c5da6f5  pop rdi
000073ef1c5da6f6  pop rdx
000073ef1c5da6f7  pop rcx
000073ef1c5da6f8  pop rax
000073ef1c5da6f9  add rsp, 0x08
000073ef1c5da6fd  jmp 0x000073EF1C5D648A
000073ef1c5da702  sub rsp, 0x08
000073ef1c5da706  push rax
000073ef1c5da707  push rcx
000073ef1c5da708  push rdx
000073ef1c5da709  push rdi
000073ef1c5da70a  push rsi
000073ef1c5da70b  push r8
000073ef1c5da70d  push r9
000073ef1c5da70f  push r10
000073ef1c5da711  push r11
000073ef1c5da713  sub rsp, 0xF0
000073ef1c5da71a  vmovaps [rsp], xmm0
000073ef1c5da71f  vmovaps [rsp+0x10], xmm1
000073ef1c5da725  vmovaps [rsp+0x20], xmm2
000073ef1c5da72b  vmovaps [rsp+0x30], xmm3
000073ef1c5da731  vmovaps [rsp+0x40], xmm4
000073ef1c5da737  vmovaps [rsp+0x50], xmm5
000073ef1c5da73d  vmovaps [rsp+0x60], xmm6
000073ef1c5da743  vmovaps [rsp+0x70], xmm7
000073ef1c5da749  vmovaps [rsp+0x80], xmm8
000073ef1c5da752  vmovaps [rsp+0x90], xmm9
000073ef1c5da75b  vmovaps [rsp+0xA0], xmm10
000073ef1c5da764  vmovaps [rsp+0xB0], xmm11
000073ef1c5da76d  vmovaps [rsp+0xC0], xmm12
000073ef1c5da776  vmovaps [rsp+0xD0], xmm13
000073ef1c5da77f  vmovaps [rsp+0xE0], xmm14
000073ef1c5da788  sub rsp, 0x30
000073ef1c5da78c  movaps [rsp], xmm15
000073ef1c5da791  movaps [rsp+0x10], xmm11
000073ef1c5da797  movaps [rsp+0x20], xmm6
000073ef1c5da79c  lea rdi, [rsp]
000073ef1c5da7a0  mov esi, 0x00
000073ef1c5da7a5  mov rax, 0x56F25E118530
000073ef1c5da7af  call rax
000073ef1c5da7b1  movaps xmm15, [rsp]
000073ef1c5da7b6  add rsp, 0x30
000073ef1c5da7ba  vmovaps xmm0, [rsp]
000073ef1c5da7bf  vmovaps xmm1, [rsp+0x10]
000073ef1c5da7c5  vmovaps xmm2, [rsp+0x20]
000073ef1c5da7cb  vmovaps xmm3, [rsp+0x30]
000073ef1c5da7d1  vmovaps xmm4, [rsp+0x40]
000073ef1c5da7d7  vmovaps xmm5, [rsp+0x50]
000073ef1c5da7dd  vmovaps xmm6, [rsp+0x60]
000073ef1c5da7e3  vmovaps xmm7, [rsp+0x70]
000073ef1c5da7e9  vmovaps xmm8, [rsp+0x80]
000073ef1c5da7f2  vmovaps xmm9, [rsp+0x90]
000073ef1c5da7fb  vmovaps xmm10, [rsp+0xA0]
000073ef1c5da804  vmovaps xmm11, [rsp+0xB0]
000073ef1c5da80d  vmovaps xmm12, [rsp+0xC0]
000073ef1c5da816  vmovaps xmm13, [rsp+0xD0]
000073ef1c5da81f  vmovaps xmm14, [rsp+0xE0]
000073ef1c5da828  add rsp, 0xF0
000073ef1c5da82f  pop r11
000073ef1c5da831  pop r10
000073ef1c5da833  pop r9
000073ef1c5da835  pop r8
000073ef1c5da837  pop rsi
000073ef1c5da838  pop rdi
000073ef1c5da839  pop rdx
000073ef1c5da83a  pop rcx
000073ef1c5da83b  pop rax
000073ef1c5da83c  add rsp, 0x08
000073ef1c5da840  jmp 0x000073EF1C5D64A5
000073ef1c5da845  sub rsp, 0x08
000073ef1c5da849  push rax
000073ef1c5da84a  push rcx
000073ef1c5da84b  push rdx
000073ef1c5da84c  push rdi
000073ef1c5da84d  push rsi
000073ef1c5da84e  push r8
000073ef1c5da850  push r9
000073ef1c5da852  push r10
000073ef1c5da854  push r11
000073ef1c5da856  sub rsp, 0xF0
000073ef1c5da85d  vmovaps [rsp], xmm0
000073ef1c5da862  vmovaps [rsp+0x10], xmm1
000073ef1c5da868  vmovaps [rsp+0x20], xmm2
000073ef1c5da86e  vmovaps [rsp+0x30], xmm3
000073ef1c5da874  vmovaps [rsp+0x40], xmm4
000073ef1c5da87a  vmovaps [rsp+0x50], xmm5
000073ef1c5da880  vmovaps [rsp+0x60], xmm6
000073ef1c5da886  vmovaps [rsp+0x70], xmm8
000073ef1c5da88c  vmovaps [rsp+0x80], xmm9
000073ef1c5da895  vmovaps [rsp+0x90], xmm10
000073ef1c5da89e  vmovaps [rsp+0xA0], xmm11
000073ef1c5da8a7  vmovaps [rsp+0xB0], xmm12
000073ef1c5da8b0  vmovaps [rsp+0xC0], xmm13
000073ef1c5da8b9  vmovaps [rsp+0xD0], xmm14
000073ef1c5da8c2  vmovaps [rsp+0xE0], xmm15
000073ef1c5da8cb  sub rsp, 0x30
000073ef1c5da8cf  movaps [rsp], xmm7
000073ef1c5da8d3  movaps [rsp+0x10], xmm11
000073ef1c5da8d9  movaps [rsp+0x20], xmm9
000073ef1c5da8df  lea rdi, [rsp]
000073ef1c5da8e3  mov esi, 0x00
000073ef1c5da8e8  mov rax, 0x56F25E118530
000073ef1c5da8f2  call rax
000073ef1c5da8f4  movaps xmm7, [rsp]
000073ef1c5da8f8  add rsp, 0x30
000073ef1c5da8fc  vmovaps xmm0, [rsp]
000073ef1c5da901  vmovaps xmm1, [rsp+0x10]
000073ef1c5da907  vmovaps xmm2, [rsp+0x20]
000073ef1c5da90d  vmovaps xmm3, [rsp+0x30]
000073ef1c5da913  vmovaps xmm4, [rsp+0x40]
000073ef1c5da919  vmovaps xmm5, [rsp+0x50]
000073ef1c5da91f  vmovaps xmm6, [rsp+0x60]
000073ef1c5da925  vmovaps xmm8, [rsp+0x70]
000073ef1c5da92b  vmovaps xmm9, [rsp+0x80]
000073ef1c5da934  vmovaps xmm10, [rsp+0x90]
000073ef1c5da93d  vmovaps xmm11, [rsp+0xA0]
000073ef1c5da946  vmovaps xmm12, [rsp+0xB0]
000073ef1c5da94f  vmovaps xmm13, [rsp+0xC0]
000073ef1c5da958  vmovaps xmm14, [rsp+0xD0]
000073ef1c5da961  vmovaps xmm15, [rsp+0xE0]
000073ef1c5da96a  add rsp, 0xF0
000073ef1c5da971  pop r11
000073ef1c5da973  pop r10
000073ef1c5da975  pop r9
000073ef1c5da977  pop r8
000073ef1c5da979  pop rsi
000073ef1c5da97a  pop rdi
000073ef1c5da97b  pop rdx
000073ef1c5da97c  pop rcx
000073ef1c5da97d  pop rax
000073ef1c5da97e  add rsp, 0x08
000073ef1c5da982  jmp 0x000073EF1C5D64D2
000073ef1c5da987  sub rsp, 0x08
000073ef1c5da98b  push rax
000073ef1c5da98c  push rcx
000073ef1c5da98d  push rdx
000073ef1c5da98e  push rdi
000073ef1c5da98f  push rsi
000073ef1c5da990  push r8
000073ef1c5da992  push r9
000073ef1c5da994  push r10
000073ef1c5da996  push r11
000073ef1c5da998  sub rsp, 0xF0
000073ef1c5da99f  vmovaps [rsp], xmm0
000073ef1c5da9a4  vmovaps [rsp+0x10], xmm1
000073ef1c5da9aa  vmovaps [rsp+0x20], xmm2
000073ef1c5da9b0  vmovaps [rsp+0x30], xmm3
000073ef1c5da9b6  vmovaps [rsp+0x40], xmm4
000073ef1c5da9bc  vmovaps [rsp+0x50], xmm5
000073ef1c5da9c2  vmovaps [rsp+0x60], xmm6
000073ef1c5da9c8  vmovaps [rsp+0x70], xmm7
000073ef1c5da9ce  vmovaps [rsp+0x80], xmm8
000073ef1c5da9d7  vmovaps [rsp+0x90], xmm9
000073ef1c5da9e0  vmovaps [rsp+0xA0], xmm10
000073ef1c5da9e9  vmovaps [rsp+0xB0], xmm12
000073ef1c5da9f2  vmovaps [rsp+0xC0], xmm13
000073ef1c5da9fb  vmovaps [rsp+0xD0], xmm14
000073ef1c5daa04  vmovaps [rsp+0xE0], xmm15
000073ef1c5daa0d  sub rsp, 0x30
000073ef1c5daa11  movaps [rsp], xmm11
000073ef1c5daa16  movaps [rsp+0x10], xmm10
000073ef1c5daa1c  movaps [rsp+0x20], xmm14
000073ef1c5daa22  lea rdi, [rsp]
000073ef1c5daa26  mov esi, 0x00
000073ef1c5daa2b  mov rax, 0x56F25E118530
000073ef1c5daa35  call rax
000073ef1c5daa37  movaps xmm11, [rsp]
000073ef1c5daa3c  add rsp, 0x30
000073ef1c5daa40  vmovaps xmm0, [rsp]
000073ef1c5daa45  vmovaps xmm1, [rsp+0x10]
000073ef1c5daa4b  vmovaps xmm2, [rsp+0x20]
000073ef1c5daa51  vmovaps xmm3, [rsp+0x30]
000073ef1c5daa57  vmovaps xmm4, [rsp+0x40]
000073ef1c5daa5d  vmovaps xmm5, [rsp+0x50]
000073ef1c5daa63  vmovaps xmm6, [rsp+0x60]
000073ef1c5daa69  vmovaps xmm7, [rsp+0x70]
000073ef1c5daa6f  vmovaps xmm8, [rsp+0x80]
000073ef1c5daa78  vmovaps xmm9, [rsp+0x90]
000073ef1c5daa81  vmovaps xmm10, [rsp+0xA0]
000073ef1c5daa8a  vmovaps xmm12, [rsp+0xB0]
000073ef1c5daa93  vmovaps xmm13, [rsp+0xC0]
000073ef1c5daa9c  vmovaps xmm14, [rsp+0xD0]
000073ef1c5daaa5  vmovaps xmm15, [rsp+0xE0]
000073ef1c5daaae  add rsp, 0xF0
000073ef1c5daab5  pop r11
000073ef1c5daab7  pop r10
000073ef1c5daab9  pop r9
000073ef1c5daabb  pop r8
000073ef1c5daabd  pop rsi
000073ef1c5daabe  pop rdi
000073ef1c5daabf  pop rdx
000073ef1c5daac0  pop rcx
000073ef1c5daac1  pop rax
000073ef1c5daac2  add rsp, 0x08
000073ef1c5daac6  jmp 0x000073EF1C5D64ED
000073ef1c5daacb  call 0x000073EF1C4E45A0
000073ef1c5daad0  jmp 0x000073EF1C5D64F7
000073ef1c5daad5  sub rsp, 0x08
000073ef1c5daad9  push rax
000073ef1c5daada  push rcx
000073ef1c5daadb  push rdx
000073ef1c5daadc  push rdi
000073ef1c5daadd  push rsi
000073ef1c5daade  push r8
000073ef1c5daae0  push r9
000073ef1c5daae2  push r10
000073ef1c5daae4  push r11
000073ef1c5daae6  sub rsp, 0xF0
000073ef1c5daaed  vmovaps [rsp], xmm0
000073ef1c5daaf2  vmovaps [rsp+0x10], xmm1
000073ef1c5daaf8  vmovaps [rsp+0x20], xmm2
000073ef1c5daafe  vmovaps [rsp+0x30], xmm3
000073ef1c5dab04  vmovaps [rsp+0x40], xmm4
000073ef1c5dab0a  vmovaps [rsp+0x50], xmm5
000073ef1c5dab10  vmovaps [rsp+0x60], xmm6
000073ef1c5dab16  vmovaps [rsp+0x70], xmm7
000073ef1c5dab1c  vmovaps [rsp+0x80], xmm8
000073ef1c5dab25  vmovaps [rsp+0x90], xmm9
000073ef1c5dab2e  vmovaps [rsp+0xA0], xmm11
000073ef1c5dab37  vmovaps [rsp+0xB0], xmm12
000073ef1c5dab40  vmovaps [rsp+0xC0], xmm13
000073ef1c5dab49  vmovaps [rsp+0xD0], xmm14
000073ef1c5dab52  vmovaps [rsp+0xE0], xmm15
000073ef1c5dab5b  sub rsp, 0x30
000073ef1c5dab5f  movaps [rsp], xmm10
000073ef1c5dab64  movaps [rsp+0x10], xmm1
000073ef1c5dab69  movaps [rsp+0x20], xmm12
000073ef1c5dab6f  lea rdi, [rsp]
000073ef1c5dab73  mov esi, 0x00
000073ef1c5dab78  mov rax, 0x56F25E118530
000073ef1c5dab82  call rax
000073ef1c5dab84  movaps xmm10, [rsp]
000073ef1c5dab89  add rsp, 0x30
000073ef1c5dab8d  vmovaps xmm0, [rsp]
000073ef1c5dab92  vmovaps xmm1, [rsp+0x10]
000073ef1c5dab98  vmovaps xmm2, [rsp+0x20]
000073ef1c5dab9e  vmovaps xmm3, [rsp+0x30]
000073ef1c5daba4  vmovaps xmm4, [rsp+0x40]
000073ef1c5dabaa  vmovaps xmm5, [rsp+0x50]
000073ef1c5dabb0  vmovaps xmm6, [rsp+0x60]
000073ef1c5dabb6  vmovaps xmm7, [rsp+0x70]
000073ef1c5dabbc  vmovaps xmm8, [rsp+0x80]
000073ef1c5dabc5  vmovaps xmm9, [rsp+0x90]
000073ef1c5dabce  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dabd7  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dabe0  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dabe9  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dabf2  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dabfb  add rsp, 0xF0
000073ef1c5dac02  pop r11
000073ef1c5dac04  pop r10
000073ef1c5dac06  pop r9
000073ef1c5dac08  pop r8
000073ef1c5dac0a  pop rsi
000073ef1c5dac0b  pop rdi
000073ef1c5dac0c  pop rdx
000073ef1c5dac0d  pop rcx
000073ef1c5dac0e  pop rax
000073ef1c5dac0f  add rsp, 0x08
000073ef1c5dac13  jmp 0x000073EF1C5D651A
000073ef1c5dac18  sub rsp, 0x08
000073ef1c5dac1c  push rax
000073ef1c5dac1d  push rcx
000073ef1c5dac1e  push rdx
000073ef1c5dac1f  push rdi
000073ef1c5dac20  push rsi
000073ef1c5dac21  push r8
000073ef1c5dac23  push r9
000073ef1c5dac25  push r10
000073ef1c5dac27  push r11
000073ef1c5dac29  sub rsp, 0xF0
000073ef1c5dac30  vmovaps [rsp], xmm0
000073ef1c5dac35  vmovaps [rsp+0x10], xmm1
000073ef1c5dac3b  vmovaps [rsp+0x20], xmm2
000073ef1c5dac41  vmovaps [rsp+0x30], xmm3
000073ef1c5dac47  vmovaps [rsp+0x40], xmm4
000073ef1c5dac4d  vmovaps [rsp+0x50], xmm5
000073ef1c5dac53  vmovaps [rsp+0x60], xmm6
000073ef1c5dac59  vmovaps [rsp+0x70], xmm7
000073ef1c5dac5f  vmovaps [rsp+0x80], xmm8
000073ef1c5dac68  vmovaps [rsp+0x90], xmm9
000073ef1c5dac71  vmovaps [rsp+0xA0], xmm10
000073ef1c5dac7a  vmovaps [rsp+0xB0], xmm11
000073ef1c5dac83  vmovaps [rsp+0xC0], xmm13
000073ef1c5dac8c  vmovaps [rsp+0xD0], xmm14
000073ef1c5dac95  vmovaps [rsp+0xE0], xmm15
000073ef1c5dac9e  sub rsp, 0x30
000073ef1c5daca2  movaps [rsp], xmm12
000073ef1c5daca7  movaps [rsp+0x10], xmm14
000073ef1c5dacad  movaps [rsp+0x20], xmm1
000073ef1c5dacb2  lea rdi, [rsp]
000073ef1c5dacb6  mov esi, 0x00
000073ef1c5dacbb  mov rax, 0x56F25E118530
000073ef1c5dacc5  call rax
000073ef1c5dacc7  movaps xmm12, [rsp]
000073ef1c5daccc  add rsp, 0x30
000073ef1c5dacd0  vmovaps xmm0, [rsp]
000073ef1c5dacd5  vmovaps xmm1, [rsp+0x10]
000073ef1c5dacdb  vmovaps xmm2, [rsp+0x20]
000073ef1c5dace1  vmovaps xmm3, [rsp+0x30]
000073ef1c5dace7  vmovaps xmm4, [rsp+0x40]
000073ef1c5daced  vmovaps xmm5, [rsp+0x50]
000073ef1c5dacf3  vmovaps xmm6, [rsp+0x60]
000073ef1c5dacf9  vmovaps xmm7, [rsp+0x70]
000073ef1c5dacff  vmovaps xmm8, [rsp+0x80]
000073ef1c5dad08  vmovaps xmm9, [rsp+0x90]
000073ef1c5dad11  vmovaps xmm10, [rsp+0xA0]
000073ef1c5dad1a  vmovaps xmm11, [rsp+0xB0]
000073ef1c5dad23  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dad2c  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dad35  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dad3e  add rsp, 0xF0
000073ef1c5dad45  pop r11
000073ef1c5dad47  pop r10
000073ef1c5dad49  pop r9
000073ef1c5dad4b  pop r8
000073ef1c5dad4d  pop rsi
000073ef1c5dad4e  pop rdi
000073ef1c5dad4f  pop rdx
000073ef1c5dad50  pop rcx
000073ef1c5dad51  pop rax
000073ef1c5dad52  add rsp, 0x08
000073ef1c5dad56  jmp 0x000073EF1C5D6549
000073ef1c5dad5b  sub rsp, 0x08
000073ef1c5dad5f  push rax
000073ef1c5dad60  push rcx
000073ef1c5dad61  push rdx
000073ef1c5dad62  push rdi
000073ef1c5dad63  push rsi
000073ef1c5dad64  push r8
000073ef1c5dad66  push r9
000073ef1c5dad68  push r10
000073ef1c5dad6a  push r11
000073ef1c5dad6c  sub rsp, 0xF0
000073ef1c5dad73  vmovaps [rsp], xmm0
000073ef1c5dad78  vmovaps [rsp+0x10], xmm1
000073ef1c5dad7e  vmovaps [rsp+0x20], xmm2
000073ef1c5dad84  vmovaps [rsp+0x30], xmm3
000073ef1c5dad8a  vmovaps [rsp+0x40], xmm4
000073ef1c5dad90  vmovaps [rsp+0x50], xmm5
000073ef1c5dad96  vmovaps [rsp+0x60], xmm6
000073ef1c5dad9c  vmovaps [rsp+0x70], xmm7
000073ef1c5dada2  vmovaps [rsp+0x80], xmm8
000073ef1c5dadab  vmovaps [rsp+0x90], xmm9
000073ef1c5dadb4  vmovaps [rsp+0xA0], xmm10
000073ef1c5dadbd  vmovaps [rsp+0xB0], xmm11
000073ef1c5dadc6  vmovaps [rsp+0xC0], xmm12
000073ef1c5dadcf  vmovaps [rsp+0xD0], xmm13
000073ef1c5dadd8  vmovaps [rsp+0xE0], xmm15
000073ef1c5dade1  sub rsp, 0x30
000073ef1c5dade5  movaps [rsp], xmm14
000073ef1c5dadea  movaps [rsp+0x10], xmm9
000073ef1c5dadf0  movaps [rsp+0x20], xmm1
000073ef1c5dadf5  lea rdi, [rsp]
000073ef1c5dadf9  mov esi, 0x00
000073ef1c5dadfe  mov rax, 0x56F25E118530
000073ef1c5dae08  call rax
000073ef1c5dae0a  movaps xmm14, [rsp]
000073ef1c5dae0f  add rsp, 0x30
000073ef1c5dae13  vmovaps xmm0, [rsp]
000073ef1c5dae18  vmovaps xmm1, [rsp+0x10]
000073ef1c5dae1e  vmovaps xmm2, [rsp+0x20]
000073ef1c5dae24  vmovaps xmm3, [rsp+0x30]
000073ef1c5dae2a  vmovaps xmm4, [rsp+0x40]
000073ef1c5dae30  vmovaps xmm5, [rsp+0x50]
000073ef1c5dae36  vmovaps xmm6, [rsp+0x60]
000073ef1c5dae3c  vmovaps xmm7, [rsp+0x70]
000073ef1c5dae42  vmovaps xmm8, [rsp+0x80]
000073ef1c5dae4b  vmovaps xmm9, [rsp+0x90]
000073ef1c5dae54  vmovaps xmm10, [rsp+0xA0]
000073ef1c5dae5d  vmovaps xmm11, [rsp+0xB0]
000073ef1c5dae66  vmovaps xmm12, [rsp+0xC0]
000073ef1c5dae6f  vmovaps xmm13, [rsp+0xD0]
000073ef1c5dae78  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dae81  add rsp, 0xF0
000073ef1c5dae88  pop r11
000073ef1c5dae8a  pop r10
000073ef1c5dae8c  pop r9
000073ef1c5dae8e  pop r8
000073ef1c5dae90  pop rsi
000073ef1c5dae91  pop rdi
000073ef1c5dae92  pop rdx
000073ef1c5dae93  pop rcx
000073ef1c5dae94  pop rax
000073ef1c5dae95  add rsp, 0x08
000073ef1c5dae99  jmp 0x000073EF1C5D6578
000073ef1c5dae9e  sub rsp, 0x08
000073ef1c5daea2  push rax
000073ef1c5daea3  push rcx
000073ef1c5daea4  push rdx
000073ef1c5daea5  push rdi
000073ef1c5daea6  push rsi
000073ef1c5daea7  push r8
000073ef1c5daea9  push r9
000073ef1c5daeab  push r10
000073ef1c5daead  push r11
000073ef1c5daeaf  sub rsp, 0xF0
000073ef1c5daeb6  vmovaps [rsp], xmm0
000073ef1c5daebb  vmovaps [rsp+0x10], xmm2
000073ef1c5daec1  vmovaps [rsp+0x20], xmm3
000073ef1c5daec7  vmovaps [rsp+0x30], xmm4
000073ef1c5daecd  vmovaps [rsp+0x40], xmm5
000073ef1c5daed3  vmovaps [rsp+0x50], xmm6
000073ef1c5daed9  vmovaps [rsp+0x60], xmm7
000073ef1c5daedf  vmovaps [rsp+0x70], xmm8
000073ef1c5daee5  vmovaps [rsp+0x80], xmm9
000073ef1c5daeee  vmovaps [rsp+0x90], xmm10
000073ef1c5daef7  vmovaps [rsp+0xA0], xmm11
000073ef1c5daf00  vmovaps [rsp+0xB0], xmm12
000073ef1c5daf09  vmovaps [rsp+0xC0], xmm13
000073ef1c5daf12  vmovaps [rsp+0xD0], xmm14
000073ef1c5daf1b  vmovaps [rsp+0xE0], xmm15
000073ef1c5daf24  sub rsp, 0x30
000073ef1c5daf28  movaps [rsp], xmm1
000073ef1c5daf2c  movaps [rsp+0x10], xmm13
000073ef1c5daf32  movaps [rsp+0x20], xmm8
000073ef1c5daf38  lea rdi, [rsp]
000073ef1c5daf3c  mov esi, 0x00
000073ef1c5daf41  mov rax, 0x56F25E118530
000073ef1c5daf4b  call rax
000073ef1c5daf4d  movaps xmm1, [rsp]
000073ef1c5daf51  add rsp, 0x30
000073ef1c5daf55  vmovaps xmm0, [rsp]
000073ef1c5daf5a  vmovaps xmm2, [rsp+0x10]
000073ef1c5daf60  vmovaps xmm3, [rsp+0x20]
000073ef1c5daf66  vmovaps xmm4, [rsp+0x30]
000073ef1c5daf6c  vmovaps xmm5, [rsp+0x40]
000073ef1c5daf72  vmovaps xmm6, [rsp+0x50]
000073ef1c5daf78  vmovaps xmm7, [rsp+0x60]
000073ef1c5daf7e  vmovaps xmm8, [rsp+0x70]
000073ef1c5daf84  vmovaps xmm9, [rsp+0x80]
000073ef1c5daf8d  vmovaps xmm10, [rsp+0x90]
000073ef1c5daf96  vmovaps xmm11, [rsp+0xA0]
000073ef1c5daf9f  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dafa8  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dafb1  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dafba  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dafc3  add rsp, 0xF0
000073ef1c5dafca  pop r11
000073ef1c5dafcc  pop r10
000073ef1c5dafce  pop r9
000073ef1c5dafd0  pop r8
000073ef1c5dafd2  pop rsi
000073ef1c5dafd3  pop rdi
000073ef1c5dafd4  pop rdx
000073ef1c5dafd5  pop rcx
000073ef1c5dafd6  pop rax
000073ef1c5dafd7  add rsp, 0x08
000073ef1c5dafdb  jmp 0x000073EF1C5D659A
000073ef1c5dafe0  call 0x000073EF1C40C260
000073ef1c5dafe5  jmp 0x000073EF1C5D65A8
000073ef1c5dafea  call 0x000073EF1C4DE950
000073ef1c5dafef  jmp 0x000073EF1C5D65B2
000073ef1c5daff4  sub rsp, 0x08
000073ef1c5daff8  push rax
000073ef1c5daff9  push rcx
000073ef1c5daffa  push rdx
000073ef1c5daffb  push rdi
000073ef1c5daffc  push rsi
000073ef1c5daffd  push r8
000073ef1c5dafff  push r9
000073ef1c5db001  push r10
000073ef1c5db003  push r11
000073ef1c5db005  sub rsp, 0xF0
000073ef1c5db00c  vmovaps [rsp], xmm0
000073ef1c5db011  vmovaps [rsp+0x10], xmm1
000073ef1c5db017  vmovaps [rsp+0x20], xmm2
000073ef1c5db01d  vmovaps [rsp+0x30], xmm3
000073ef1c5db023  vmovaps [rsp+0x40], xmm4
000073ef1c5db029  vmovaps [rsp+0x50], xmm5
000073ef1c5db02f  vmovaps [rsp+0x60], xmm6
000073ef1c5db035  vmovaps [rsp+0x70], xmm7
000073ef1c5db03b  vmovaps [rsp+0x80], xmm9
000073ef1c5db044  vmovaps [rsp+0x90], xmm10
000073ef1c5db04d  vmovaps [rsp+0xA0], xmm11
000073ef1c5db056  vmovaps [rsp+0xB0], xmm12
000073ef1c5db05f  vmovaps [rsp+0xC0], xmm13
000073ef1c5db068  vmovaps [rsp+0xD0], xmm14
000073ef1c5db071  vmovaps [rsp+0xE0], xmm15
000073ef1c5db07a  sub rsp, 0x30
000073ef1c5db07e  movaps [rsp], xmm8
000073ef1c5db083  movaps [rsp+0x10], xmm15
000073ef1c5db089  movaps [rsp+0x20], xmm7
000073ef1c5db08e  lea rdi, [rsp]
000073ef1c5db092  mov esi, 0x00
000073ef1c5db097  mov rax, 0x56F25E118530
000073ef1c5db0a1  call rax
000073ef1c5db0a3  movaps xmm8, [rsp]
000073ef1c5db0a8  add rsp, 0x30
000073ef1c5db0ac  vmovaps xmm0, [rsp]
000073ef1c5db0b1  vmovaps xmm1, [rsp+0x10]
000073ef1c5db0b7  vmovaps xmm2, [rsp+0x20]
000073ef1c5db0bd  vmovaps xmm3, [rsp+0x30]
000073ef1c5db0c3  vmovaps xmm4, [rsp+0x40]
000073ef1c5db0c9  vmovaps xmm5, [rsp+0x50]
000073ef1c5db0cf  vmovaps xmm6, [rsp+0x60]
000073ef1c5db0d5  vmovaps xmm7, [rsp+0x70]
000073ef1c5db0db  vmovaps xmm9, [rsp+0x80]
000073ef1c5db0e4  vmovaps xmm10, [rsp+0x90]
000073ef1c5db0ed  vmovaps xmm11, [rsp+0xA0]
000073ef1c5db0f6  vmovaps xmm12, [rsp+0xB0]
000073ef1c5db0ff  vmovaps xmm13, [rsp+0xC0]
000073ef1c5db108  vmovaps xmm14, [rsp+0xD0]
000073ef1c5db111  vmovaps xmm15, [rsp+0xE0]
000073ef1c5db11a  add rsp, 0xF0
000073ef1c5db121  pop r11
000073ef1c5db123  pop r10
000073ef1c5db125  pop r9
000073ef1c5db127  pop r8
000073ef1c5db129  pop rsi
000073ef1c5db12a  pop rdi
000073ef1c5db12b  pop rdx
000073ef1c5db12c  pop rcx
000073ef1c5db12d  pop rax
000073ef1c5db12e  add rsp, 0x08
000073ef1c5db132  jmp 0x000073EF1C5D65D4
000073ef1c5db137  sub rsp, 0x08
000073ef1c5db13b  push rax
000073ef1c5db13c  push rcx
000073ef1c5db13d  push rdx
000073ef1c5db13e  push rdi
000073ef1c5db13f  push rsi
000073ef1c5db140  push r8
000073ef1c5db142  push r9
000073ef1c5db144  push r10
000073ef1c5db146  push r11
000073ef1c5db148  sub rsp, 0xF0
000073ef1c5db14f  vmovaps [rsp], xmm0
000073ef1c5db154  vmovaps [rsp+0x10], xmm1
000073ef1c5db15a  vmovaps [rsp+0x20], xmm2
000073ef1c5db160  vmovaps [rsp+0x30], xmm3
000073ef1c5db166  vmovaps [rsp+0x40], xmm4
000073ef1c5db16c  vmovaps [rsp+0x50], xmm5
000073ef1c5db172  vmovaps [rsp+0x60], xmm6
000073ef1c5db178  vmovaps [rsp+0x70], xmm8
000073ef1c5db17e  vmovaps [rsp+0x80], xmm9
000073ef1c5db187  vmovaps [rsp+0x90], xmm10
000073ef1c5db190  vmovaps [rsp+0xA0], xmm11
000073ef1c5db199  vmovaps [rsp+0xB0], xmm12
000073ef1c5db1a2  vmovaps [rsp+0xC0], xmm13
000073ef1c5db1ab  vmovaps [rsp+0xD0], xmm14
000073ef1c5db1b4  vmovaps [rsp+0xE0], xmm15
000073ef1c5db1bd  sub rsp, 0x30
000073ef1c5db1c1  movaps [rsp], xmm7
000073ef1c5db1c5  movaps [rsp+0x10], xmm9
000073ef1c5db1cb  movaps [rsp+0x20], xmm15
000073ef1c5db1d1  lea rdi, [rsp]
000073ef1c5db1d5  mov esi, 0x00
000073ef1c5db1da  mov rax, 0x56F25E118530
000073ef1c5db1e4  call rax
000073ef1c5db1e6  movaps xmm7, [rsp]
000073ef1c5db1ea  add rsp, 0x30
000073ef1c5db1ee  vmovaps xmm0, [rsp]
000073ef1c5db1f3  vmovaps xmm1, [rsp+0x10]
000073ef1c5db1f9  vmovaps xmm2, [rsp+0x20]
000073ef1c5db1ff  vmovaps xmm3, [rsp+0x30]
000073ef1c5db205  vmovaps xmm4, [rsp+0x40]
000073ef1c5db20b  vmovaps xmm5, [rsp+0x50]
000073ef1c5db211  vmovaps xmm6, [rsp+0x60]
000073ef1c5db217  vmovaps xmm8, [rsp+0x70]
000073ef1c5db21d  vmovaps xmm9, [rsp+0x80]
000073ef1c5db226  vmovaps xmm10, [rsp+0x90]
000073ef1c5db22f  vmovaps xmm11, [rsp+0xA0]
000073ef1c5db238  vmovaps xmm12, [rsp+0xB0]
000073ef1c5db241  vmovaps xmm13, [rsp+0xC0]
000073ef1c5db24a  vmovaps xmm14, [rsp+0xD0]
000073ef1c5db253  vmovaps xmm15, [rsp+0xE0]
000073ef1c5db25c  add rsp, 0xF0
000073ef1c5db263  pop r11
000073ef1c5db265  pop r10
000073ef1c5db267  pop r9
000073ef1c5db269  pop r8
000073ef1c5db26b  pop rsi
000073ef1c5db26c  pop rdi
000073ef1c5db26d  pop rdx
000073ef1c5db26e  pop rcx
000073ef1c5db26f  pop rax
000073ef1c5db270  add rsp, 0x08
000073ef1c5db274  jmp 0x000073EF1C5D6601
000073ef1c5db279  sub rsp, 0x08
000073ef1c5db27d  push rax
000073ef1c5db27e  push rcx
000073ef1c5db27f  push rdx
000073ef1c5db280  push rdi
000073ef1c5db281  push rsi
000073ef1c5db282  push r8
000073ef1c5db284  push r9
000073ef1c5db286  push r10
000073ef1c5db288  push r11
000073ef1c5db28a  sub rsp, 0xF0
000073ef1c5db291  vmovaps [rsp], xmm0
000073ef1c5db296  vmovaps [rsp+0x10], xmm1
000073ef1c5db29c  vmovaps [rsp+0x20], xmm2
000073ef1c5db2a2  vmovaps [rsp+0x30], xmm3
000073ef1c5db2a8  vmovaps [rsp+0x40], xmm4
000073ef1c5db2ae  vmovaps [rsp+0x50], xmm5
000073ef1c5db2b4  vmovaps [rsp+0x60], xmm6
000073ef1c5db2ba  vmovaps [rsp+0x70], xmm7
000073ef1c5db2c0  vmovaps [rsp+0x80], xmm8
000073ef1c5db2c9  vmovaps [rsp+0x90], xmm10
000073ef1c5db2d2  vmovaps [rsp+0xA0], xmm11
000073ef1c5db2db  vmovaps [rsp+0xB0], xmm12
000073ef1c5db2e4  vmovaps [rsp+0xC0], xmm13
000073ef1c5db2ed  vmovaps [rsp+0xD0], xmm14
000073ef1c5db2f6  vmovaps [rsp+0xE0], xmm15
000073ef1c5db2ff  sub rsp, 0x30
000073ef1c5db303  movaps [rsp], xmm9
000073ef1c5db308  movaps [rsp+0x10], xmm13
000073ef1c5db30e  movaps [rsp+0x20], xmm15
000073ef1c5db314  lea rdi, [rsp]
000073ef1c5db318  mov esi, 0x00
000073ef1c5db31d  mov rax, 0x56F25E118530
000073ef1c5db327  call rax
000073ef1c5db329  movaps xmm9, [rsp]
000073ef1c5db32e  add rsp, 0x30
000073ef1c5db332  vmovaps xmm0, [rsp]
000073ef1c5db337  vmovaps xmm1, [rsp+0x10]
000073ef1c5db33d  vmovaps xmm2, [rsp+0x20]
000073ef1c5db343  vmovaps xmm3, [rsp+0x30]
000073ef1c5db349  vmovaps xmm4, [rsp+0x40]
000073ef1c5db34f  vmovaps xmm5, [rsp+0x50]
000073ef1c5db355  vmovaps xmm6, [rsp+0x60]
000073ef1c5db35b  vmovaps xmm7, [rsp+0x70]
000073ef1c5db361  vmovaps xmm8, [rsp+0x80]
000073ef1c5db36a  vmovaps xmm10, [rsp+0x90]
000073ef1c5db373  vmovaps xmm11, [rsp+0xA0]
000073ef1c5db37c  vmovaps xmm12, [rsp+0xB0]
000073ef1c5db385  vmovaps xmm13, [rsp+0xC0]
000073ef1c5db38e  vmovaps xmm14, [rsp+0xD0]
000073ef1c5db397  vmovaps xmm15, [rsp+0xE0]
000073ef1c5db3a0  add rsp, 0xF0
000073ef1c5db3a7  pop r11
000073ef1c5db3a9  pop r10
000073ef1c5db3ab  pop r9
000073ef1c5db3ad  pop r8
000073ef1c5db3af  pop rsi
000073ef1c5db3b0  pop rdi
000073ef1c5db3b1  pop rdx
000073ef1c5db3b2  pop rcx
000073ef1c5db3b3  pop rax
000073ef1c5db3b4  add rsp, 0x08
000073ef1c5db3b8  jmp 0x000073EF1C5D662F
000073ef1c5db3bd  sub rsp, 0x08
000073ef1c5db3c1  push rax
000073ef1c5db3c2  push rcx
000073ef1c5db3c3  push rdx
000073ef1c5db3c4  push rdi
000073ef1c5db3c5  push rsi
000073ef1c5db3c6  push r8
000073ef1c5db3c8  push r9
000073ef1c5db3ca  push r10
000073ef1c5db3cc  push r11
000073ef1c5db3ce  sub rsp, 0xF0
000073ef1c5db3d5  vmovaps [rsp], xmm0
000073ef1c5db3da  vmovaps [rsp+0x10], xmm1
000073ef1c5db3e0  vmovaps [rsp+0x20], xmm2
000073ef1c5db3e6  vmovaps [rsp+0x30], xmm3
000073ef1c5db3ec  vmovaps [rsp+0x40], xmm4
000073ef1c5db3f2  vmovaps [rsp+0x50], xmm5
000073ef1c5db3f8  vmovaps [rsp+0x60], xmm6
000073ef1c5db3fe  vmovaps [rsp+0x70], xmm7
000073ef1c5db404  vmovaps [rsp+0x80], xmm8
000073ef1c5db40d  vmovaps [rsp+0x90], xmm9
000073ef1c5db416  vmovaps [rsp+0xA0], xmm10
000073ef1c5db41f  vmovaps [rsp+0xB0], xmm11
000073ef1c5db428  vmovaps [rsp+0xC0], xmm12
000073ef1c5db431  vmovaps [rsp+0xD0], xmm13
000073ef1c5db43a  vmovaps [rsp+0xE0], xmm14
000073ef1c5db443  sub rsp, 0x30
000073ef1c5db447  movaps [rsp], xmm15
000073ef1c5db44c  movaps [rsp+0x10], xmm11
000073ef1c5db452  movaps [rsp+0x20], xmm12
000073ef1c5db458  lea rdi, [rsp]
000073ef1c5db45c  mov esi, 0x00
000073ef1c5db461  mov rax, 0x56F25E118530
000073ef1c5db46b  call rax
000073ef1c5db46d  movaps xmm15, [rsp]
000073ef1c5db472  add rsp, 0x30
000073ef1c5db476  vmovaps xmm0, [rsp]
000073ef1c5db47b  vmovaps xmm1, [rsp+0x10]
000073ef1c5db481  vmovaps xmm2, [rsp+0x20]
000073ef1c5db487  vmovaps xmm3, [rsp+0x30]
000073ef1c5db48d  vmovaps xmm4, [rsp+0x40]
000073ef1c5db493  vmovaps xmm5, [rsp+0x50]
000073ef1c5db499  vmovaps xmm6, [rsp+0x60]
000073ef1c5db49f  vmovaps xmm7, [rsp+0x70]
000073ef1c5db4a5  vmovaps xmm8, [rsp+0x80]
000073ef1c5db4ae  vmovaps xmm9, [rsp+0x90]
000073ef1c5db4b7  vmovaps xmm10, [rsp+0xA0]
000073ef1c5db4c0  vmovaps xmm11, [rsp+0xB0]
000073ef1c5db4c9  vmovaps xmm12, [rsp+0xC0]
000073ef1c5db4d2  vmovaps xmm13, [rsp+0xD0]
000073ef1c5db4db  vmovaps xmm14, [rsp+0xE0]
000073ef1c5db4e4  add rsp, 0xF0
000073ef1c5db4eb  pop r11
000073ef1c5db4ed  pop r10
000073ef1c5db4ef  pop r9
000073ef1c5db4f1  pop r8
000073ef1c5db4f3  pop rsi
000073ef1c5db4f4  pop rdi
000073ef1c5db4f5  pop rdx
000073ef1c5db4f6  pop rcx
000073ef1c5db4f7  pop rax
000073ef1c5db4f8  add rsp, 0x08
000073ef1c5db4fc  jmp 0x000073EF1C5D664A
000073ef1c5db501  sub rsp, 0x08
000073ef1c5db505  push rax
000073ef1c5db506  push rcx
000073ef1c5db507  push rdx
000073ef1c5db508  push rdi
000073ef1c5db509  push rsi
000073ef1c5db50a  push r8
000073ef1c5db50c  push r9
000073ef1c5db50e  push r10
000073ef1c5db510  push r11
000073ef1c5db512  sub rsp, 0xF0
000073ef1c5db519  vmovaps [rsp], xmm0
000073ef1c5db51e  vmovaps [rsp+0x10], xmm1
000073ef1c5db524  vmovaps [rsp+0x20], xmm2
000073ef1c5db52a  vmovaps [rsp+0x30], xmm3
000073ef1c5db530  vmovaps [rsp+0x40], xmm4
000073ef1c5db536  vmovaps [rsp+0x50], xmm5
000073ef1c5db53c  vmovaps [rsp+0x60], xmm6
000073ef1c5db542  vmovaps [rsp+0x70], xmm7
000073ef1c5db548  vmovaps [rsp+0x80], xmm8
000073ef1c5db551  vmovaps [rsp+0x90], xmm9
000073ef1c5db55a  vmovaps [rsp+0xA0], xmm10
000073ef1c5db563  vmovaps [rsp+0xB0], xmm11
000073ef1c5db56c  vmovaps [rsp+0xC0], xmm12
000073ef1c5db575  vmovaps [rsp+0xD0], xmm14
000073ef1c5db57e  vmovaps [rsp+0xE0], xmm15
000073ef1c5db587  sub rsp, 0x30
000073ef1c5db58b  movaps [rsp], xmm13
000073ef1c5db590  movaps [rsp+0x10], xmm10
000073ef1c5db596  movaps [rsp+0x20], xmm14
000073ef1c5db59c  lea rdi, [rsp]
000073ef1c5db5a0  mov esi, 0x00
000073ef1c5db5a5  mov rax, 0x56F25E118530
000073ef1c5db5af  call rax
000073ef1c5db5b1  movaps xmm13, [rsp]
000073ef1c5db5b6  add rsp, 0x30
000073ef1c5db5ba  vmovaps xmm0, [rsp]
000073ef1c5db5bf  vmovaps xmm1, [rsp+0x10]
000073ef1c5db5c5  vmovaps xmm2, [rsp+0x20]
000073ef1c5db5cb  vmovaps xmm3, [rsp+0x30]
000073ef1c5db5d1  vmovaps xmm4, [rsp+0x40]
000073ef1c5db5d7  vmovaps xmm5, [rsp+0x50]
000073ef1c5db5dd  vmovaps xmm6, [rsp+0x60]
000073ef1c5db5e3  vmovaps xmm7, [rsp+0x70]
000073ef1c5db5e9  vmovaps xmm8, [rsp+0x80]
000073ef1c5db5f2  vmovaps xmm9, [rsp+0x90]
000073ef1c5db5fb  vmovaps xmm10, [rsp+0xA0]
000073ef1c5db604  vmovaps xmm11, [rsp+0xB0]
000073ef1c5db60d  vmovaps xmm12, [rsp+0xC0]
000073ef1c5db616  vmovaps xmm14, [rsp+0xD0]
000073ef1c5db61f  vmovaps xmm15, [rsp+0xE0]
000073ef1c5db628  add rsp, 0xF0
000073ef1c5db62f  pop r11
000073ef1c5db631  pop r10
000073ef1c5db633  pop r9
000073ef1c5db635  pop r8
000073ef1c5db637  pop rsi
000073ef1c5db638  pop rdi
000073ef1c5db639  pop rdx
000073ef1c5db63a  pop rcx
000073ef1c5db63b  pop rax
000073ef1c5db63c  add rsp, 0x08
000073ef1c5db640  jmp 0x000073EF1C5D666D
000073ef1c5db645  sub rsp, 0x08
000073ef1c5db649  push rax
000073ef1c5db64a  push rcx
000073ef1c5db64b  push rdx
000073ef1c5db64c  push rdi
000073ef1c5db64d  push rsi
000073ef1c5db64e  push r8
000073ef1c5db650  push r9
000073ef1c5db652  push r10
000073ef1c5db654  push r11
000073ef1c5db656  sub rsp, 0xF0
000073ef1c5db65d  vmovaps [rsp], xmm0
000073ef1c5db662  vmovaps [rsp+0x10], xmm1
000073ef1c5db668  vmovaps [rsp+0x20], xmm2
000073ef1c5db66e  vmovaps [rsp+0x30], xmm3
000073ef1c5db674  vmovaps [rsp+0x40], xmm4
000073ef1c5db67a  vmovaps [rsp+0x50], xmm5
000073ef1c5db680  vmovaps [rsp+0x60], xmm6
000073ef1c5db686  vmovaps [rsp+0x70], xmm7
000073ef1c5db68c  vmovaps [rsp+0x80], xmm8
000073ef1c5db695  vmovaps [rsp+0x90], xmm9
000073ef1c5db69e  vmovaps [rsp+0xA0], xmm10
000073ef1c5db6a7  vmovaps [rsp+0xB0], xmm11
000073ef1c5db6b0  vmovaps [rsp+0xC0], xmm12
000073ef1c5db6b9  vmovaps [rsp+0xD0], xmm13
000073ef1c5db6c2  vmovaps [rsp+0xE0], xmm15
000073ef1c5db6cb  sub rsp, 0x30
000073ef1c5db6cf  movaps [rsp], xmm14
000073ef1c5db6d4  movaps [rsp+0x10], xmm1
000073ef1c5db6d9  movaps [rsp+0x20], xmm7
000073ef1c5db6de  lea rdi, [rsp]
000073ef1c5db6e2  mov esi, 0x00
000073ef1c5db6e7  mov rax, 0x56F25E118530
000073ef1c5db6f1  call rax
000073ef1c5db6f3  movaps xmm14, [rsp]
000073ef1c5db6f8  add rsp, 0x30
000073ef1c5db6fc  vmovaps xmm0, [rsp]
000073ef1c5db701  vmovaps xmm1, [rsp+0x10]
000073ef1c5db707  vmovaps xmm2, [rsp+0x20]
000073ef1c5db70d  vmovaps xmm3, [rsp+0x30]
000073ef1c5db713  vmovaps xmm4, [rsp+0x40]
000073ef1c5db719  vmovaps xmm5, [rsp+0x50]
000073ef1c5db71f  vmovaps xmm6, [rsp+0x60]
000073ef1c5db725  vmovaps xmm7, [rsp+0x70]
000073ef1c5db72b  vmovaps xmm8, [rsp+0x80]
000073ef1c5db734  vmovaps xmm9, [rsp+0x90]
000073ef1c5db73d  vmovaps xmm10, [rsp+0xA0]
000073ef1c5db746  vmovaps xmm11, [rsp+0xB0]
000073ef1c5db74f  vmovaps xmm12, [rsp+0xC0]
000073ef1c5db758  vmovaps xmm13, [rsp+0xD0]
000073ef1c5db761  vmovaps xmm15, [rsp+0xE0]
000073ef1c5db76a  add rsp, 0xF0
000073ef1c5db771  pop r11
000073ef1c5db773  pop r10
000073ef1c5db775  pop r9
000073ef1c5db777  pop r8
000073ef1c5db779  pop rsi
000073ef1c5db77a  pop rdi
000073ef1c5db77b  pop rdx
000073ef1c5db77c  pop rcx
000073ef1c5db77d  pop rax
000073ef1c5db77e  add rsp, 0x08
000073ef1c5db782  jmp 0x000073EF1C5D6690
000073ef1c5db787  sub rsp, 0x08
000073ef1c5db78b  push rax
000073ef1c5db78c  push rcx
000073ef1c5db78d  push rdx
000073ef1c5db78e  push rdi
000073ef1c5db78f  push rsi
000073ef1c5db790  push r8
000073ef1c5db792  push r9
000073ef1c5db794  push r10
000073ef1c5db796  push r11
000073ef1c5db798  sub rsp, 0xF0
000073ef1c5db79f  vmovaps [rsp], xmm0
000073ef1c5db7a4  vmovaps [rsp+0x10], xmm2
000073ef1c5db7aa  vmovaps [rsp+0x20], xmm3
000073ef1c5db7b0  vmovaps [rsp+0x30], xmm4
000073ef1c5db7b6  vmovaps [rsp+0x40], xmm5
000073ef1c5db7bc  vmovaps [rsp+0x50], xmm6
000073ef1c5db7c2  vmovaps [rsp+0x60], xmm7
000073ef1c5db7c8  vmovaps [rsp+0x70], xmm8
000073ef1c5db7ce  vmovaps [rsp+0x80], xmm9
000073ef1c5db7d7  vmovaps [rsp+0x90], xmm10
000073ef1c5db7e0  vmovaps [rsp+0xA0], xmm11
000073ef1c5db7e9  vmovaps [rsp+0xB0], xmm12
000073ef1c5db7f2  vmovaps [rsp+0xC0], xmm13
000073ef1c5db7fb  vmovaps [rsp+0xD0], xmm14
000073ef1c5db804  vmovaps [rsp+0xE0], xmm15
000073ef1c5db80d  sub rsp, 0x30
000073ef1c5db811  movaps [rsp], xmm1
000073ef1c5db815  movaps [rsp+0x10], xmm8
000073ef1c5db81b  movaps [rsp+0x20], xmm9
000073ef1c5db821  lea rdi, [rsp]
000073ef1c5db825  mov esi, 0x00
000073ef1c5db82a  mov rax, 0x56F25E118530
000073ef1c5db834  call rax
000073ef1c5db836  movaps xmm1, [rsp]
000073ef1c5db83a  add rsp, 0x30
000073ef1c5db83e  vmovaps xmm0, [rsp]
000073ef1c5db843  vmovaps xmm2, [rsp+0x10]
000073ef1c5db849  vmovaps xmm3, [rsp+0x20]
000073ef1c5db84f  vmovaps xmm4, [rsp+0x30]
000073ef1c5db855  vmovaps xmm5, [rsp+0x40]
000073ef1c5db85b  vmovaps xmm6, [rsp+0x50]
000073ef1c5db861  vmovaps xmm7, [rsp+0x60]
000073ef1c5db867  vmovaps xmm8, [rsp+0x70]
000073ef1c5db86d  vmovaps xmm9, [rsp+0x80]
000073ef1c5db876  vmovaps xmm10, [rsp+0x90]
000073ef1c5db87f  vmovaps xmm11, [rsp+0xA0]
000073ef1c5db888  vmovaps xmm12, [rsp+0xB0]
000073ef1c5db891  vmovaps xmm13, [rsp+0xC0]
000073ef1c5db89a  vmovaps xmm14, [rsp+0xD0]
000073ef1c5db8a3  vmovaps xmm15, [rsp+0xE0]
000073ef1c5db8ac  add rsp, 0xF0
000073ef1c5db8b3  pop r11
000073ef1c5db8b5  pop r10
000073ef1c5db8b7  pop r9
000073ef1c5db8b9  pop r8
000073ef1c5db8bb  pop rsi
000073ef1c5db8bc  pop rdi
000073ef1c5db8bd  pop rdx
000073ef1c5db8be  pop rcx
000073ef1c5db8bf  pop rax
000073ef1c5db8c0  add rsp, 0x08
000073ef1c5db8c4  jmp 0x000073EF1C5D66B2
000073ef1c5db8c9  call 0x000073EF1C4B3E40
000073ef1c5db8ce  jmp 0x000073EF1C5D66C0
000073ef1c5db8d3  call 0x000073EF1C40C380
000073ef1c5db8d8  jmp 0x000073EF1C5D66CA
000073ef1c5db8dd  call 0x000073EF1C40D600
000073ef1c5db8e2  jmp 0x000073EF1C5D66D4
000073ef1c5db8e7  call 0x000073EF1C3FF540
000073ef1c5db8ec  jmp 0x000073EF1C5D66DE
000073ef1c5db8f1  int3
000073ef1c5db8f2  nop [rax+rax*1], ax
000073ef1c5db8fb  nop [rax+rax*1], eax
000073ef1c5db900  mov eax, [r15+0x48]
000073ef1c5db904  lea r14d, [eax+0x01]
000073ef1c5db909  mov [rsp+0x10], r14d
000073ef1c5db90e  mov r14d, r14d
000073ef1c5db911  mov [r15+0x48], r14
000073ef1c5db915  xor eax, eax
000073ef1c5db917  mov r14d, [rsp+0x10]
000073ef1c5db91c  cmp r14d, 0x1F4
000073ef1c5db923  cmc
000073ef1c5db924  lahf
000073ef1c5db925  seto al
000073ef1c5db928  mov [r15+0x108], eax
000073ef1c5db92f  mov eax, [r15+0x108]
000073ef1c5db936  sahf
000073ef1c5db937  jnz 0x000073EF1C5DB969
000073ef1c5db939  cmp dword ptr [r15+0x318], 0x00
000073ef1c5db941  jz 0x000073EF1C5E1AB0
000073ef1c5db947  nop [rax+rax*1], ax
000073ef1c5db950  nop [rax+rax*1], eax
000073ef1c5db958  mov eax, 0x410450
000073ef1c5db95d  mov [r15+0x100], rax
000073ef1c5db964  jmp 0x000073EF1C3FE110
000073ef1c5db969  cmp dword ptr [r15+0x318], 0x00
000073ef1c5db971  jz 0x000073EF1C5DB9A0
000073ef1c5db977  nop [rax+rax*1], ax
000073ef1c5db980  nop [rax+rax*1], eax
000073ef1c5db988  mov eax, 0x410274
000073ef1c5db98d  mov [r15+0x100], rax
000073ef1c5db994  jmp 0x000073EF1C3FE110
000073ef1c5db999  int3
000073ef1c5db99a  int3
000073ef1c5db99b  nop [rax+rax*1], eax
000073ef1c5db9a0  mov rax, [r15+0x40]
000073ef1c5db9a4  movaps xmm1, [r15+0x1D0]
000073ef1c5db9ac  vmovaps [rsp+0x10], xmm1
000073ef1c5db9b2  vmovaps xmm15, [rsp+0x10]
000073ef1c5db9b8  por xmm1, xmm15
000073ef1c5db9bd  movaps xmm14, [r15+0x1A0]
000073ef1c5db9c5  vmovaps [rsp+0x10], xmm14
000073ef1c5db9cb  vmovaps xmm13, [rsp+0x10]
000073ef1c5db9d1  por xmm14, xmm13
000073ef1c5db9d6  lea r14, [rax+0x30]
000073ef1c5db9da  mov r12, [r13+r14*1]
000073ef1c5db9df  lea r14, [rax+0x38]
000073ef1c5db9e3  mov r11, [r13+r14*1]
000073ef1c5db9e8  movq xmm13, r12
000073ef1c5db9ed  movq xmm12, r11
000073ef1c5db9f2  movq xmm13, xmm13
000073ef1c5db9f7  vmovaps [rsp+0x10], xmm13
000073ef1c5db9fd  movq xmm13, xmm13
000073ef1c5dba02  movaps [r15+0x130], xmm13
000073ef1c5dba0a  movq xmm12, xmm12
000073ef1c5dba0f  vmovaps [rsp+0x20], xmm12
000073ef1c5dba15  movq xmm12, xmm12
000073ef1c5dba1a  movaps [r15+0x280], xmm12
000073ef1c5dba22  movaps xmm13, [r15+0x270]
000073ef1c5dba2a  vmovaps [rsp+0x30], xmm13
000073ef1c5dba30  vmovaps xmm12, [rsp+0x30]
000073ef1c5dba36  por xmm13, xmm12
000073ef1c5dba3b  lea r14, [rax+0x20]
000073ef1c5dba3f  mov r12, [r13+r14*1]
000073ef1c5dba44  lea r14, [rax+0x28]
000073ef1c5dba48  mov r11, [r13+r14*1]
000073ef1c5dba4d  movq xmm12, r12
000073ef1c5dba52  movq xmm11, r11
000073ef1c5dba57  movq xmm12, xmm12
000073ef1c5dba5c  vmovaps [rsp+0x30], xmm12
000073ef1c5dba62  movq xmm12, xmm12
000073ef1c5dba67  movaps [r15+0x150], xmm12
000073ef1c5dba6f  movq xmm11, xmm11
000073ef1c5dba74  vmovaps [rsp+0x40], xmm11
000073ef1c5dba7a  movq xmm11, xmm11
000073ef1c5dba7f  movaps [r15+0x140], xmm11
000073ef1c5dba87  lea r14, [rax+0x10]
000073ef1c5dba8b  mov r12, [r13+r14*1]
000073ef1c5dba90  lea r14, [rax+0x18]
000073ef1c5dba94  mov r11, [r13+r14*1]
000073ef1c5dba99  movq xmm12, r12
000073ef1c5dba9e  movq xmm11, r11
000073ef1c5dbaa3  movq xmm12, xmm12
000073ef1c5dbaa8  vmovaps [rsp+0x50], xmm12
000073ef1c5dbaae  movq xmm12, xmm12
000073ef1c5dbab3  movaps [r15+0x170], xmm12
000073ef1c5dbabb  movq xmm11, xmm11
000073ef1c5dbac0  vmovaps [rsp+0x60], xmm11
000073ef1c5dbac6  movq xmm11, xmm11
000073ef1c5dbacb  movaps [r15+0x160], xmm11
000073ef1c5dbad3  mov r14, [r13+rax*1]
000073ef1c5dbad8  vmovq xmm12, r14
000073ef1c5dbadd  vpbroadcastq xmm12, xmm12
000073ef1c5dbae2  lea r14, [rax+0x08]
000073ef1c5dbae6  mov rax, [r13+r14*1]
000073ef1c5dbaeb  movq xmm11, rax
000073ef1c5dbaf0  movaps [r15+0x230], xmm11
000073ef1c5dbaf8  mov rax, [r15+0xF8]
000073ef1c5dbaff  lea r14, [rax+0x50]
000073ef1c5dbb03  movups xmm11, [r13+r14*1]
000073ef1c5dbb09  lea r14, [rax+0x60]
000073ef1c5dbb0d  movups xmm10, [r13+r14*1]
000073ef1c5dbb13  lea r14, [rax+0x30]
000073ef1c5dbb17  movups xmm9, [r13+r14*1]
000073ef1c5dbb1d  mov r14, [r15+0x50]
000073ef1c5dbb21  mov [r15+0x60], r14
000073ef1c5dbb25  mov qword ptr [r15+0x58], 0x40
000073ef1c5dbb2d  movaps xmm8, xmm12
000073ef1c5dbb31  mulpd xmm8, xmm15
000073ef1c5dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000073ef1c5dbb3c  ptest xmm7, xmm7
000073ef1c5dbb41  jnz 0x000073EF1C5DC96A
000073ef1c5dbb47  movq xmm15, qword ptr [r15+0x230]
000073ef1c5dbb50  vmovaps [rsp+0x70], xmm15
000073ef1c5dbb56  vpermilpd xmm15, xmm15, 0x00
000073ef1c5dbb5c  movaps xmm7, xmm9
000073ef1c5dbb60  mulpd xmm7, xmm15
000073ef1c5dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000073ef1c5dbb6a  ptest xmm6, xmm6
000073ef1c5dbb6f  jnz 0x000073EF1C5DCAAE
000073ef1c5dbb75  vxorps xmm15, xmm15, xmm15
000073ef1c5dbb7a  vpbroadcastq xmm15, xmm15
000073ef1c5dbb7f  movaps xmm9, xmm12
000073ef1c5dbb83  mulpd xmm9, xmm10
000073ef1c5dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000073ef1c5dbb8e  ptest xmm6, xmm6
000073ef1c5dbb93  jnz 0x000073EF1C5DCBF0
000073ef1c5dbb99  movaps xmm10, xmm12
000073ef1c5dbb9d  mulpd xmm10, xmm11
000073ef1c5dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000073ef1c5dbba8  ptest xmm6, xmm6
000073ef1c5dbbad  jnz 0x000073EF1C5DCD34
000073ef1c5dbbb3  movaps xmm11, [r15+0x1F0]
000073ef1c5dbbbb  movaps xmm6, xmm12
000073ef1c5dbbbf  mulpd xmm6, xmm11
000073ef1c5dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000073ef1c5dbbc9  ptest xmm5, xmm5
000073ef1c5dbbce  jnz 0x000073EF1C5DCE78
000073ef1c5dbbd4  movaps xmm12, [r15+0x2A0]
000073ef1c5dbbdc  vmovaps [rsp+0x80], xmm12
000073ef1c5dbbe5  vmovaps xmm11, [rsp+0x80]
000073ef1c5dbbee  por xmm12, xmm11
000073ef1c5dbbf3  movaps xmm11, [r15+0x250]
000073ef1c5dbbfb  vmovaps [rsp+0x80], xmm11
000073ef1c5dbc04  vmovaps xmm5, [rsp+0x80]
000073ef1c5dbc0d  por xmm11, xmm5
000073ef1c5dbc12  vmovaps xmm4, [rsp+0x70]
000073ef1c5dbc18  vpermilpd xmm4, xmm4, 0x00
000073ef1c5dbc1e  movaps xmm3, xmm5
000073ef1c5dbc21  mulpd xmm3, xmm4
000073ef1c5dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000073ef1c5dbc2a  ptest xmm2, xmm2
000073ef1c5dbc2f  jnz 0x000073EF1C5DCFBA
000073ef1c5dbc35  mov [rsp+0x80], rax
000073ef1c5dbc3d  xor eax, eax
000073ef1c5dbc3f  mov r12d, 0x40
000073ef1c5dbc45  mov r11d, 0x200
000073ef1c5dbc4b  cmp r12, r11
000073ef1c5dbc4e  cmc
000073ef1c5dbc4f  lahf
000073ef1c5dbc50  seto al
000073ef1c5dbc53  mov [r15+0x108], eax
000073ef1c5dbc5a  movaps xmm5, xmm8
000073ef1c5dbc5e  addpd xmm5, xmm15
000073ef1c5dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000073ef1c5dbc68  ptest xmm4, xmm4
000073ef1c5dbc6d  jnz 0x000073EF1C5DD0FA
000073ef1c5dbc73  movaps xmm8, [r15+0x1B0]
000073ef1c5dbc7b  movaps xmm4, xmm9
000073ef1c5dbc7f  addpd xmm4, xmm8
000073ef1c5dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000073ef1c5dbc89  ptest xmm2, xmm2
000073ef1c5dbc8e  jnz 0x000073EF1C5DD23C
000073ef1c5dbc94  movaps xmm9, xmm10
000073ef1c5dbc98  addpd xmm9, xmm8
000073ef1c5dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000073ef1c5dbca3  ptest xmm2, xmm2
000073ef1c5dbca8  jnz 0x000073EF1C5DD37E
000073ef1c5dbcae  movaps xmm10, [r15+0x2F0]
000073ef1c5dbcb6  vmovaps [rsp+0x90], xmm10
000073ef1c5dbcbf  vmovaps xmm8, [rsp+0x90]
000073ef1c5dbcc8  por xmm10, xmm8
000073ef1c5dbccd  movaps xmm8, [r15+0x2E0]
000073ef1c5dbcd5  vmovaps [rsp+0x90], xmm8
000073ef1c5dbcde  vmovaps xmm2, [rsp+0x90]
000073ef1c5dbce7  por xmm8, xmm2
000073ef1c5dbcec  movaps xmm2, [r15+0x2D0]
000073ef1c5dbcf4  vmovaps [rsp+0x90], xmm2
000073ef1c5dbcfd  vmovaps [rsp+0xA0], xmm1
000073ef1c5dbd06  vmovaps xmm1, [rsp+0x90]
000073ef1c5dbd0f  por xmm2, xmm1
000073ef1c5dbd13  movaps xmm1, [r15+0x200]
000073ef1c5dbd1b  vmovaps [rsp+0x90], xmm1
000073ef1c5dbd24  vmovaps [rsp+0xB0], xmm15
000073ef1c5dbd2d  vmovaps xmm15, [rsp+0x90]
000073ef1c5dbd36  por xmm1, xmm15
000073ef1c5dbd3b  movaps xmm15, [r15+0x1C0]
000073ef1c5dbd43  vmovaps [rsp+0x90], xmm15
000073ef1c5dbd4c  vmovaps [rsp+0xC0], xmm1
000073ef1c5dbd55  vmovaps xmm1, [rsp+0x90]
000073ef1c5dbd5e  por xmm15, xmm1
000073ef1c5dbd63  movaps xmm1, [r15+0x190]
000073ef1c5dbd6b  vmovaps [rsp+0x90], xmm1
000073ef1c5dbd74  vmovaps [rsp+0xD0], xmm15
000073ef1c5dbd7d  vmovaps xmm15, [rsp+0x90]
000073ef1c5dbd86  por xmm1, xmm15
000073ef1c5dbd8b  movaps xmm15, [r15+0x300]
000073ef1c5dbd93  vmovaps [rsp+0x90], xmm15
000073ef1c5dbd9c  vmovaps [rsp+0xE0], xmm1
000073ef1c5dbda5  vmovaps xmm1, [rsp+0x90]
000073ef1c5dbdae  por xmm15, xmm1
000073ef1c5dbdb3  mov rax, [rsp+0x80]
000073ef1c5dbdbb  lea r12, [rax+0xA0]
000073ef1c5dbdc2  movups xmm1, [r13+r12*1]
000073ef1c5dbdc8  lea r12, [rax+0xB0]
000073ef1c5dbdcf  vmovaps [rsp+0x80], xmm1
000073ef1c5dbdd8  movups xmm1, [r13+r12*1]
000073ef1c5dbdde  vmovaps [rsp+0x90], xmm1
000073ef1c5dbde7  vmovaps [rsp+0xF0], xmm15
000073ef1c5dbdf0  vmovaps xmm15, [rsp+0xB0]
000073ef1c5dbdf9  vmovaps [rsp+0xB0], xmm14
000073ef1c5dbe02  movaps xmm1, xmm6
000073ef1c5dbe05  addpd xmm1, xmm15
000073ef1c5dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000073ef1c5dbe0f  ptest xmm14, xmm14
000073ef1c5dbe15  jnz 0x000073EF1C5DD4D6
000073ef1c5dbe1b  lea r12, [rax+0xF0]
000073ef1c5dbe22  movups xmm15, [r13+r12*1]
000073ef1c5dbe28  movaps xmm14, xmm4
000073ef1c5dbe2c  addpd xmm14, xmm3
000073ef1c5dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000073ef1c5dbe37  ptest xmm6, xmm6
000073ef1c5dbe3c  jnz 0x000073EF1C5DD621
000073ef1c5dbe42  movaps xmm6, xmm9
000073ef1c5dbe46  addpd xmm6, xmm7
000073ef1c5dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000073ef1c5dbe4f  ptest xmm4, xmm4
000073ef1c5dbe54  jnz 0x000073EF1C5DD763
000073ef1c5dbe5a  vmovaps xmm9, [rsp+0x70]
000073ef1c5dbe60  vpermilpd xmm9, xmm9, 0x00
000073ef1c5dbe66  vmovaps xmm4, [rsp+0x90]
000073ef1c5dbe6f  movaps xmm7, xmm4
000073ef1c5dbe72  mulpd xmm7, xmm9
000073ef1c5dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000073ef1c5dbe7c  ptest xmm3, xmm3
000073ef1c5dbe81  jnz 0x000073EF1C5DD8A4
000073ef1c5dbe87  vmovaps xmm9, [rsp+0x50]
000073ef1c5dbe8d  vpermilpd xmm9, xmm9, 0x00
000073ef1c5dbe93  movaps xmm4, xmm15
000073ef1c5dbe97  mulpd xmm4, xmm9
000073ef1c5dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000073ef1c5dbea1  ptest xmm3, xmm3
000073ef1c5dbea6  jnz 0x000073EF1C5DD9E5
000073ef1c5dbeac  lea r12, [rax+0xE0]
000073ef1c5dbeb3  movups xmm15, [r13+r12*1]
000073ef1c5dbeb9  vmovaps xmm9, [rsp+0x70]
000073ef1c5dbebf  vpermilpd xmm9, xmm9, 0x00
000073ef1c5dbec5  vmovaps [rsp+0x70], xmm1
000073ef1c5dbecb  vmovaps xmm1, [rsp+0x80]
000073ef1c5dbed4  vmovaps [rsp+0x80], xmm15
000073ef1c5dbedd  movaps xmm3, xmm1
000073ef1c5dbee0  mulpd xmm3, xmm9
000073ef1c5dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000073ef1c5dbeea  ptest xmm15, xmm15
000073ef1c5dbef0  jnz 0x000073EF1C5DDB31
000073ef1c5dbef6  vmovaps xmm1, [rsp+0xF0]
000073ef1c5dbeff  vmovaps xmm15, [rsp+0xF0]
000073ef1c5dbf08  por xmm1, xmm15
000073ef1c5dbf0d  movaps [r15+0x300], xmm1
000073ef1c5dbf15  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dbf1e  vmovaps xmm9, [rsp+0xE0]
000073ef1c5dbf27  por xmm15, xmm9
000073ef1c5dbf2c  movaps [r15+0x190], xmm15
000073ef1c5dbf34  vmovaps xmm9, [rsp+0x50]
000073ef1c5dbf3a  vpermilpd xmm9, xmm9, 0x00
000073ef1c5dbf40  vmovaps [rsp+0x90], xmm1
000073ef1c5dbf49  vmovaps [rsp+0xE0], xmm15
000073ef1c5dbf52  vmovaps xmm15, [rsp+0x80]
000073ef1c5dbf5b  vmovaps [rsp+0x80], xmm14
000073ef1c5dbf64  movaps xmm1, xmm15
000073ef1c5dbf68  mulpd xmm1, xmm9
000073ef1c5dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000073ef1c5dbf72  ptest xmm14, xmm14
000073ef1c5dbf78  jnz 0x000073EF1C5DDC72
000073ef1c5dbf7e  lea r12, [rax+0x90]
000073ef1c5dbf85  movups xmm15, [r13+r12*1]
000073ef1c5dbf8b  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dbf94  vmovaps xmm9, [rsp+0xD0]
000073ef1c5dbf9d  por xmm14, xmm9
000073ef1c5dbfa2  movaps [r15+0x1C0], xmm14
000073ef1c5dbfaa  vmovaps xmm9, [rsp+0xC0]
000073ef1c5dbfb3  vmovaps [rsp+0xD0], xmm1
000073ef1c5dbfbc  vmovaps xmm1, [rsp+0xC0]
000073ef1c5dbfc5  por xmm9, xmm1
000073ef1c5dbfca  movaps [r15+0x200], xmm9
000073ef1c5dbfd2  vmovaps [rsp+0xC0], xmm2
000073ef1c5dbfdb  vmovaps xmm1, [rsp+0xC0]
000073ef1c5dbfe4  por xmm2, xmm1
000073ef1c5dbfe8  movaps [r15+0x2D0], xmm2
000073ef1c5dbff0  vmovaps [rsp+0xC0], xmm8
000073ef1c5dbff9  vmovaps xmm1, [rsp+0xC0]
000073ef1c5dc002  por xmm8, xmm1
000073ef1c5dc007  movaps [r15+0x2E0], xmm8
000073ef1c5dc00f  vmovaps [rsp+0xC0], xmm15
000073ef1c5dc018  movaps xmm1, xmm5
000073ef1c5dc01b  addpd xmm1, xmm7
000073ef1c5dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000073ef1c5dc024  ptest xmm15, xmm15
000073ef1c5dc02a  jnz 0x000073EF1C5DDDBE
000073ef1c5dc030  vmovaps xmm15, [rsp+0x50]
000073ef1c5dc036  vpermilpd xmm15, xmm15, 0x00
000073ef1c5dc03c  vmovaps xmm5, [rsp+0xC0]
000073ef1c5dc045  vmovaps [rsp+0xC0], xmm1
000073ef1c5dc04e  movaps xmm7, xmm5
000073ef1c5dc051  mulpd xmm7, xmm15
000073ef1c5dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000073ef1c5dc05b  ptest xmm1, xmm1
000073ef1c5dc060  jnz 0x000073EF1C5DDEFE
000073ef1c5dc066  lea r12, [rax+0x80]
000073ef1c5dc06d  movups xmm1, [r13+r12*1]
000073ef1c5dc073  vmovaps xmm5, [rsp+0x70]
000073ef1c5dc079  vmovaps [rsp+0x70], xmm1
000073ef1c5dc07f  movaps xmm15, xmm5
000073ef1c5dc083  addpd xmm15, xmm3
000073ef1c5dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000073ef1c5dc08e  ptest xmm1, xmm1
000073ef1c5dc093  jnz 0x000073EF1C5DE049
000073ef1c5dc099  vmovaps xmm5, [rsp+0x80]
000073ef1c5dc0a2  movaps xmm1, xmm5
000073ef1c5dc0a5  addpd xmm1, xmm4
000073ef1c5dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000073ef1c5dc0ae  ptest xmm3, xmm3
000073ef1c5dc0b3  jnz 0x000073EF1C5DE18B
000073ef1c5dc0b9  vmovaps [rsp+0x80], xmm10
000073ef1c5dc0c2  vmovaps xmm5, [rsp+0x80]
000073ef1c5dc0cb  por xmm10, xmm5
000073ef1c5dc0d0  movaps [r15+0x2F0], xmm10
000073ef1c5dc0d8  vmovaps xmm5, [rsp+0x50]
000073ef1c5dc0de  vpermilpd xmm5, xmm5, 0x00
000073ef1c5dc0e4  vmovaps xmm3, [rsp+0x70]
000073ef1c5dc0ea  vmovaps [rsp+0x50], xmm1
000073ef1c5dc0f0  movaps xmm4, xmm3
000073ef1c5dc0f3  mulpd xmm4, xmm5
000073ef1c5dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000073ef1c5dc0fc  ptest xmm1, xmm1
000073ef1c5dc101  jnz 0x000073EF1C5DE2CB
000073ef1c5dc107  lea r12, [rax+0xD0]
000073ef1c5dc10e  movups xmm1, [r13+r12*1]
000073ef1c5dc114  vmovaps xmm3, [rsp+0xD0]
000073ef1c5dc11d  vmovaps [rsp+0x70], xmm1
000073ef1c5dc123  movaps xmm5, xmm6
000073ef1c5dc126  addpd xmm5, xmm3
000073ef1c5dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000073ef1c5dc12f  ptest xmm1, xmm1
000073ef1c5dc134  jnz 0x000073EF1C5DE415
000073ef1c5dc13a  vmovaps xmm1, [rsp+0x60]
000073ef1c5dc140  vpermilpd xmm1, xmm1, 0x00
000073ef1c5dc146  movaps xmm6, xmm9
000073ef1c5dc14a  mulpd xmm6, xmm1
000073ef1c5dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000073ef1c5dc153  ptest xmm3, xmm3
000073ef1c5dc158  jnz 0x000073EF1C5DE555
000073ef1c5dc15e  movaps [r15+0x260], xmm6
000073ef1c5dc166  vxorps xmm1, xmm1, xmm1
000073ef1c5dc16a  vpbroadcastq xmm1, xmm1
000073ef1c5dc16f  movaps [r15+0x1B0], xmm1
000073ef1c5dc177  vmovaps xmm1, [rsp+0x60]
000073ef1c5dc17d  vpermilpd xmm1, xmm1, 0x00
000073ef1c5dc183  vmovaps xmm3, [rsp+0x70]
000073ef1c5dc189  vmovaps [rsp+0x70], xmm15
000073ef1c5dc18f  movaps xmm9, xmm3
000073ef1c5dc193  mulpd xmm9, xmm1
000073ef1c5dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000073ef1c5dc19e  ptest xmm15, xmm15
000073ef1c5dc1a4  jnz 0x000073EF1C5DE696
000073ef1c5dc1aa  lea r12, [rax+0xC0]
000073ef1c5dc1b1  movups xmm1, [r13+r12*1]
000073ef1c5dc1b7  vmovaps xmm3, [rsp+0xC0]
000073ef1c5dc1c0  vmovaps [rsp+0x80], xmm1
000073ef1c5dc1c9  movaps xmm15, xmm3
000073ef1c5dc1cd  addpd xmm15, xmm7
000073ef1c5dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000073ef1c5dc1d8  ptest xmm1, xmm1
000073ef1c5dc1dd  jnz 0x000073EF1C5DE7E2
000073ef1c5dc1e3  vmovaps [rsp+0xC0], xmm13
000073ef1c5dc1ec  vmovaps xmm1, [rsp+0xC0]
000073ef1c5dc1f5  por xmm13, xmm1
000073ef1c5dc1fa  movaps [r15+0x270], xmm13
000073ef1c5dc202  vmovaps xmm1, [rsp+0xB0]
000073ef1c5dc20b  vmovaps xmm7, [rsp+0xB0]
000073ef1c5dc214  por xmm1, xmm7
000073ef1c5dc218  movaps [r15+0x1A0], xmm1
000073ef1c5dc220  vmovaps xmm1, [rsp+0x60]
000073ef1c5dc226  vpermilpd xmm1, xmm1, 0x00
000073ef1c5dc22c  vmovaps [rsp+0xB0], xmm1
000073ef1c5dc235  vmovaps xmm1, [rsp+0x80]
000073ef1c5dc23e  vmovaps [rsp+0x80], xmm15
000073ef1c5dc247  vmovaps xmm15, [rsp+0xB0]
000073ef1c5dc250  vmovaps [rsp+0xB0], xmm14
000073ef1c5dc259  movaps xmm3, xmm1
000073ef1c5dc25c  mulpd xmm3, xmm15
000073ef1c5dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000073ef1c5dc266  ptest xmm14, xmm14
000073ef1c5dc26c  jnz 0x000073EF1C5DE924
000073ef1c5dc272  lea r12, [rax+0x20]
000073ef1c5dc276  movups xmm1, [r13+r12*1]
000073ef1c5dc27c  movaps [r15+0x110], xmm1
000073ef1c5dc284  vmovaps xmm14, [rsp+0x70]
000073ef1c5dc28a  vmovaps [rsp+0x70], xmm1
000073ef1c5dc290  movaps xmm15, xmm14
000073ef1c5dc294  addpd xmm15, xmm4
000073ef1c5dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000073ef1c5dc29f  ptest xmm1, xmm1
000073ef1c5dc2a4  jnz 0x000073EF1C5DEA6F
000073ef1c5dc2aa  vmovaps xmm1, [rsp+0x60]
000073ef1c5dc2b0  vpermilpd xmm1, xmm1, 0x00
000073ef1c5dc2b6  movaps xmm14, xmm2
000073ef1c5dc2ba  mulpd xmm14, xmm1
000073ef1c5dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000073ef1c5dc2c5  ptest xmm4, xmm4
000073ef1c5dc2ca  jnz 0x000073EF1C5DEBB2
000073ef1c5dc2d0  vmovaps xmm4, [rsp+0x50]
000073ef1c5dc2d6  movaps xmm1, xmm4
000073ef1c5dc2d9  addpd xmm1, xmm9
000073ef1c5dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000073ef1c5dc2e3  ptest xmm2, xmm2
000073ef1c5dc2e8  jnz 0x000073EF1C5DECF4
000073ef1c5dc2ee  vmovaps xmm9, [rsp+0x30]
000073ef1c5dc2f4  vpermilpd xmm9, xmm9, 0x00
000073ef1c5dc2fa  vmovaps xmm2, [rsp+0x70]
000073ef1c5dc300  vmovaps [rsp+0x50], xmm1
000073ef1c5dc306  movaps xmm4, xmm2
000073ef1c5dc309  mulpd xmm4, xmm9
000073ef1c5dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000073ef1c5dc313  ptest xmm1, xmm1
000073ef1c5dc318  jnz 0x000073EF1C5DEE35
000073ef1c5dc31e  vmovaps xmm1, [rsp+0x30]
000073ef1c5dc324  vpermilpd xmm1, xmm1, 0x00
000073ef1c5dc32a  vmovaps xmm2, [rsp+0x90]
000073ef1c5dc333  vmovaps [rsp+0x60], xmm15
000073ef1c5dc339  movaps xmm9, xmm2
000073ef1c5dc33d  mulpd xmm9, xmm1
000073ef1c5dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000073ef1c5dc348  ptest xmm15, xmm15
000073ef1c5dc34e  jnz 0x000073EF1C5DEF76
000073ef1c5dc354  vmovaps xmm15, [rsp+0x80]
000073ef1c5dc35d  movaps xmm1, xmm15
000073ef1c5dc361  addpd xmm1, xmm6
000073ef1c5dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000073ef1c5dc36a  ptest xmm2, xmm2
000073ef1c5dc36f  jnz 0x000073EF1C5DF0B8
000073ef1c5dc375  movaps xmm15, xmm5
000073ef1c5dc379  addpd xmm15, xmm3
000073ef1c5dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000073ef1c5dc384  ptest xmm6, xmm6
000073ef1c5dc389  jnz 0x000073EF1C5DF1F9
000073ef1c5dc38f  vmovaps xmm6, [rsp+0x30]
000073ef1c5dc395  vpermilpd xmm6, xmm6, 0x00
000073ef1c5dc39b  movaps xmm5, xmm8
000073ef1c5dc39f  mulpd xmm5, xmm6
000073ef1c5dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000073ef1c5dc3a8  ptest xmm3, xmm3
000073ef1c5dc3ad  jnz 0x000073EF1C5DF33B
000073ef1c5dc3b3  vmovaps xmm8, [rsp+0x30]
000073ef1c5dc3b9  vpermilpd xmm8, xmm8, 0x00
000073ef1c5dc3bf  movaps xmm6, xmm10
000073ef1c5dc3c3  mulpd xmm6, xmm8
000073ef1c5dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000073ef1c5dc3cd  ptest xmm3, xmm3
000073ef1c5dc3d2  jnz 0x000073EF1C5DF47C
000073ef1c5dc3d8  vmovaps xmm8, [rsp+0x60]
000073ef1c5dc3de  movaps xmm10, xmm8
000073ef1c5dc3e2  addpd xmm10, xmm14
000073ef1c5dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000073ef1c5dc3ed  ptest xmm3, xmm3
000073ef1c5dc3f2  jnz 0x000073EF1C5DF5BE
000073ef1c5dc3f8  vmovaps xmm8, [rsp+0x50]
000073ef1c5dc3fe  movaps xmm14, xmm8
000073ef1c5dc402  addpd xmm14, xmm4
000073ef1c5dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000073ef1c5dc40d  ptest xmm3, xmm3
000073ef1c5dc412  jnz 0x000073EF1C5DF702
000073ef1c5dc418  vmovaps xmm8, [rsp+0x40]
000073ef1c5dc41e  vpermilpd xmm8, xmm8, 0x00
000073ef1c5dc424  movaps xmm4, xmm13
000073ef1c5dc428  mulpd xmm4, xmm8
000073ef1c5dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000073ef1c5dc432  ptest xmm3, xmm3
000073ef1c5dc437  jnz 0x000073EF1C5DF845
000073ef1c5dc43d  movaps xmm13, xmm15
000073ef1c5dc441  addpd xmm13, xmm9
000073ef1c5dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000073ef1c5dc44c  ptest xmm8, xmm8
000073ef1c5dc452  jnz 0x000073EF1C5DF987
000073ef1c5dc458  movaps xmm15, xmm1
000073ef1c5dc45c  addpd xmm15, xmm5
000073ef1c5dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000073ef1c5dc467  ptest xmm9, xmm9
000073ef1c5dc46d  jnz 0x000073EF1C5DFACB
000073ef1c5dc473  vmovaps [rsp+0x30], xmm11
000073ef1c5dc479  vmovaps xmm1, [rsp+0x30]
000073ef1c5dc47f  por xmm11, xmm1
000073ef1c5dc484  movaps [r15+0x250], xmm11
000073ef1c5dc48c  vmovaps [rsp+0x30], xmm12
000073ef1c5dc492  vmovaps xmm1, [rsp+0x30]
000073ef1c5dc498  por xmm12, xmm1
000073ef1c5dc49d  movaps [r15+0x2A0], xmm12
000073ef1c5dc4a5  vmovaps xmm1, [rsp+0xA0]
000073ef1c5dc4ae  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dc4b7  por xmm1, xmm11
000073ef1c5dc4bc  movaps [r15+0x1D0], xmm1
000073ef1c5dc4c4  lea r12, [rax+0x40]
000073ef1c5dc4c8  movups xmm1, [r13+r12*1]
000073ef1c5dc4ce  movaps [r15+0x2C0], xmm1
000073ef1c5dc4d6  vmovaps xmm11, [rsp+0x40]
000073ef1c5dc4dc  vpermilpd xmm11, xmm11, 0x00
000073ef1c5dc4e2  vmovaps xmm8, [rsp+0xE0]
000073ef1c5dc4eb  movaps xmm9, xmm8
000073ef1c5dc4ef  mulpd xmm9, xmm11
000073ef1c5dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000073ef1c5dc4fa  ptest xmm5, xmm5
000073ef1c5dc4ff  jnz 0x000073EF1C5DFC17
000073ef1c5dc505  movaps xmm11, xmm10
000073ef1c5dc509  addpd xmm11, xmm6
000073ef1c5dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000073ef1c5dc514  ptest xmm8, xmm8
000073ef1c5dc51a  jnz 0x000073EF1C5DFD5B
000073ef1c5dc520  movaps xmm10, xmm14
000073ef1c5dc524  addpd xmm10, xmm4
000073ef1c5dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000073ef1c5dc52f  ptest xmm8, xmm8
000073ef1c5dc535  jnz 0x000073EF1C5DFE9E
000073ef1c5dc53b  vmovaps xmm14, [rsp+0x40]
000073ef1c5dc541  vpermilpd xmm14, xmm14, 0x00
000073ef1c5dc547  movaps xmm8, xmm1
000073ef1c5dc54b  mulpd xmm8, xmm14
000073ef1c5dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000073ef1c5dc556  ptest xmm6, xmm6
000073ef1c5dc55b  jnz 0x000073EF1C5DFFE1
000073ef1c5dc561  movaps xmm1, [r15+0x2B0]
000073ef1c5dc569  vmovaps xmm14, [rsp+0x40]
000073ef1c5dc56f  vpermilpd xmm14, xmm14, 0x00
000073ef1c5dc575  movaps xmm6, xmm1
000073ef1c5dc578  mulpd xmm6, xmm14
000073ef1c5dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000073ef1c5dc582  ptest xmm5, xmm5
000073ef1c5dc587  jnz 0x000073EF1C5E0124
000073ef1c5dc58d  vmovaps xmm1, [rsp+0x10]
000073ef1c5dc593  vpermilpd xmm1, xmm1, 0x00
000073ef1c5dc599  movaps xmm14, xmm12
000073ef1c5dc59d  mulpd xmm14, xmm1
000073ef1c5dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000073ef1c5dc5a8  ptest xmm5, xmm5
000073ef1c5dc5ad  jnz 0x000073EF1C5E0265
000073ef1c5dc5b3  movaps xmm1, xmm13
000073ef1c5dc5b7  addpd xmm1, xmm9
000073ef1c5dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000073ef1c5dc5c1  ptest xmm12, xmm12
000073ef1c5dc5c7  jnz 0x000073EF1C5E03A8
000073ef1c5dc5cd  vmovaps xmm13, [rsp+0x10]
000073ef1c5dc5d3  vpermilpd xmm13, xmm13, 0x00
000073ef1c5dc5d9  movaps xmm12, xmm7
000073ef1c5dc5dd  mulpd xmm12, xmm13
000073ef1c5dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000073ef1c5dc5e8  ptest xmm9, xmm9
000073ef1c5dc5ee  jnz 0x000073EF1C5E04EA
000073ef1c5dc5f4  movaps xmm13, xmm15
000073ef1c5dc5f8  addpd xmm13, xmm8
000073ef1c5dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000073ef1c5dc603  ptest xmm9, xmm9
000073ef1c5dc609  jnz 0x000073EF1C5E062D
000073ef1c5dc60f  movaps xmm15, [r15+0x290]
000073ef1c5dc617  vmovaps xmm9, [rsp+0x10]
000073ef1c5dc61d  vpermilpd xmm9, xmm9, 0x00
000073ef1c5dc623  movaps xmm8, xmm15
000073ef1c5dc627  mulpd xmm8, xmm9
000073ef1c5dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000073ef1c5dc632  ptest xmm7, xmm7
000073ef1c5dc637  jnz 0x000073EF1C5E0771
000073ef1c5dc63d  movaps xmm15, xmm11
000073ef1c5dc641  addpd xmm15, xmm6
000073ef1c5dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000073ef1c5dc64c  ptest xmm9, xmm9
000073ef1c5dc652  jnz 0x000073EF1C5E08B5
000073ef1c5dc658  movaps xmm11, [r15+0x1E0]
000073ef1c5dc660  vmovaps xmm9, [rsp+0x10]
000073ef1c5dc666  vpermilpd xmm9, xmm9, 0x00
000073ef1c5dc66c  movaps xmm7, xmm11
000073ef1c5dc670  mulpd xmm7, xmm9
000073ef1c5dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000073ef1c5dc67a  ptest xmm6, xmm6
000073ef1c5dc67f  jnz 0x000073EF1C5E09F8
000073ef1c5dc685  movaps xmm11, xmm10
000073ef1c5dc689  addpd xmm11, xmm14
000073ef1c5dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000073ef1c5dc694  ptest xmm9, xmm9
000073ef1c5dc69a  jnz 0x000073EF1C5E0B3A
000073ef1c5dc6a0  lea r12, [rax+0x70]
000073ef1c5dc6a4  movups xmm14, [r13+r12*1]
000073ef1c5dc6aa  movaps [r15+0x240], xmm14
000073ef1c5dc6b2  movaps xmm10, xmm1
000073ef1c5dc6b6  addpd xmm10, xmm12
000073ef1c5dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000073ef1c5dc6c1  ptest xmm9, xmm9
000073ef1c5dc6c7  jnz 0x000073EF1C5E0C88
000073ef1c5dc6cd  movaps [r15+0x170], xmm10
000073ef1c5dc6d5  vmovaps xmm1, [rsp+0x20]
000073ef1c5dc6db  vpermilpd xmm1, xmm1, 0x00
000073ef1c5dc6e1  movaps xmm12, xmm14
000073ef1c5dc6e5  mulpd xmm12, xmm1
000073ef1c5dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000073ef1c5dc6f0  ptest xmm9, xmm9
000073ef1c5dc6f6  jnz 0x000073EF1C5E0DCB
000073ef1c5dc6fc  vmovaps xmm1, [rsp+0x20]
000073ef1c5dc702  vpermilpd xmm1, xmm1, 0x00
000073ef1c5dc708  vmovaps xmm9, [rsp+0xB0]
000073ef1c5dc711  movaps xmm14, xmm9
000073ef1c5dc715  mulpd xmm14, xmm1
000073ef1c5dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000073ef1c5dc720  ptest xmm6, xmm6
000073ef1c5dc725  jnz 0x000073EF1C5E0F0E
000073ef1c5dc72b  movaps [r15+0x180], xmm14
000073ef1c5dc733  movaps xmm1, xmm13
000073ef1c5dc737  addpd xmm1, xmm8
000073ef1c5dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000073ef1c5dc741  ptest xmm9, xmm9
000073ef1c5dc747  jnz 0x000073EF1C5E1051
000073ef1c5dc74d  movaps [r15+0x210], xmm1
000073ef1c5dc755  movups xmm13, [r13+rax*1]
000073ef1c5dc75b  lea r12, [rax+0x10]
000073ef1c5dc75f  movups xmm9, [r13+r12*1]
000073ef1c5dc765  movaps [r15+0x230], xmm9
000073ef1c5dc76d  movaps xmm8, xmm15
000073ef1c5dc771  addpd xmm8, xmm7
000073ef1c5dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000073ef1c5dc77c  ptest xmm6, xmm6
000073ef1c5dc781  jnz 0x000073EF1C5E11A7
000073ef1c5dc787  movaps [r15+0x130], xmm8
000073ef1c5dc78f  vmovaps xmm15, [rsp+0x20]
000073ef1c5dc795  vpermilpd xmm15, xmm15, 0x00
000073ef1c5dc79b  movaps xmm7, xmm9
000073ef1c5dc79f  mulpd xmm7, xmm15
000073ef1c5dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000073ef1c5dc7a9  ptest xmm6, xmm6
000073ef1c5dc7ae  jnz 0x000073EF1C5E12EA
000073ef1c5dc7b4  movaps [r15+0x220], xmm7
000073ef1c5dc7bc  vmovaps xmm15, [rsp+0x20]
000073ef1c5dc7c2  vpermilpd xmm15, xmm15, 0x00
000073ef1c5dc7c8  movaps xmm9, xmm13
000073ef1c5dc7cc  mulpd xmm9, xmm15
000073ef1c5dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000073ef1c5dc7d7  ptest xmm6, xmm6
000073ef1c5dc7dc  jnz 0x000073EF1C5E142C
000073ef1c5dc7e2  movaps xmm15, xmm11
000073ef1c5dc7e6  addpd xmm15, xmm12
000073ef1c5dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000073ef1c5dc7f1  ptest xmm13, xmm13
000073ef1c5dc7f7  jnz 0x000073EF1C5E1570
000073ef1c5dc7fd  movaps [r15+0x140], xmm15
000073ef1c5dc805  movaps xmm13, xmm10
000073ef1c5dc809  addpd xmm13, xmm14
000073ef1c5dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000073ef1c5dc814  ptest xmm12, xmm12
000073ef1c5dc81a  jnz 0x000073EF1C5E16B4
000073ef1c5dc820  movaps [r15+0x150], xmm13
000073ef1c5dc828  movaps xmm14, xmm1
000073ef1c5dc82c  addpd xmm14, xmm7
000073ef1c5dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000073ef1c5dc837  ptest xmm12, xmm12
000073ef1c5dc83d  jnz 0x000073EF1C5E17F8
000073ef1c5dc843  movaps [r15+0x160], xmm14
000073ef1c5dc84b  movaps xmm1, xmm8
000073ef1c5dc84f  addpd xmm1, xmm9
000073ef1c5dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000073ef1c5dc859  ptest xmm12, xmm12
000073ef1c5dc85f  jnz 0x000073EF1C5E193A
000073ef1c5dc865  movaps [r15+0x120], xmm1
000073ef1c5dc86d  movups [r13+r14*1], xmm15
000073ef1c5dc873  lea rax, [r14+0x10]
000073ef1c5dc877  movups [r13+rax*1], xmm13
000073ef1c5dc87d  lea rax, [r14+0x20]
000073ef1c5dc881  movups [r13+rax*1], xmm14
000073ef1c5dc887  lea rax, [r14+0x30]
000073ef1c5dc88b  movups [r13+rax*1], xmm1
000073ef1c5dc891  mov eax, [r15+0x108]
000073ef1c5dc898  sahf
000073ef1c5dc899  jnz 0x000073EF1C5DC8CB
000073ef1c5dc89b  cmp dword ptr [r15+0x318], 0x00
000073ef1c5dc8a3  jz 0x000073EF1C5DB900
000073ef1c5dc8a9  nop [rax+rax*1], ax
000073ef1c5dc8b2  nop [rax+rax*1], eax
000073ef1c5dc8ba  mov eax, 0x410444
000073ef1c5dc8bf  mov [r15+0x100], rax
000073ef1c5dc8c6  jmp 0x000073EF1C3FE110
000073ef1c5dc8cb  cmp dword ptr [r15+0x318], 0x00
000073ef1c5dc8d3  jz 0x000073EF1C5D57E0
000073ef1c5dc8d9  nop [rax+rax*1], ax
000073ef1c5dc8e2  nop [rax+rax*1], eax
000073ef1c5dc8ea  mov eax, 0x410278
000073ef1c5dc8ef  mov [r15+0x100], rax
000073ef1c5dc8f6  jmp 0x000073EF1C3FE110
000073ef1c5dc8fb  int3
000073ef1c5dc8fc  call 0x000073EF1C4E27E0
000073ef1c5dc901  jmp 0x000073EF1C5DB9DF
000073ef1c5dc906  call 0x000073EF1C4E1570
000073ef1c5dc90b  jmp 0x000073EF1C5DB9E8
000073ef1c5dc910  call 0x000073EF1C4E27E0
000073ef1c5dc915  jmp 0x000073EF1C5DBA44
000073ef1c5dc91a  call 0x000073EF1C4E1570
000073ef1c5dc91f  jmp 0x000073EF1C5DBA4D
000073ef1c5dc924  call 0x000073EF1C4E27E0
000073ef1c5dc929  jmp 0x000073EF1C5DBA90
000073ef1c5dc92e  call 0x000073EF1C4E1570
000073ef1c5dc933  jmp 0x000073EF1C5DBA99
000073ef1c5dc938  call 0x000073EF1C40DC20
000073ef1c5dc93d  jmp 0x000073EF1C5DBAD8
000073ef1c5dc942  call 0x000073EF1C4D59C0
000073ef1c5dc947  jmp 0x000073EF1C5DBAEB
000073ef1c5dc94c  call 0x000073EF1C4E0E30
000073ef1c5dc951  jmp 0x000073EF1C5DBB09
000073ef1c5dc956  call 0x000073EF1C4DFBC0
000073ef1c5dc95b  jmp 0x000073EF1C5DBB13
000073ef1c5dc960  call 0x000073EF1C4DE950
000073ef1c5dc965  jmp 0x000073EF1C5DBB1D
000073ef1c5dc96a  sub rsp, 0x08
000073ef1c5dc96e  push rax
000073ef1c5dc96f  push rcx
000073ef1c5dc970  push rdx
000073ef1c5dc971  push rdi
000073ef1c5dc972  push rsi
000073ef1c5dc973  push r8
000073ef1c5dc975  push r9
000073ef1c5dc977  push r10
000073ef1c5dc979  push r11
000073ef1c5dc97b  sub rsp, 0xF0
000073ef1c5dc982  vmovaps [rsp], xmm0
000073ef1c5dc987  vmovaps [rsp+0x10], xmm1
000073ef1c5dc98d  vmovaps [rsp+0x20], xmm2
000073ef1c5dc993  vmovaps [rsp+0x30], xmm3
000073ef1c5dc999  vmovaps [rsp+0x40], xmm4
000073ef1c5dc99f  vmovaps [rsp+0x50], xmm5
000073ef1c5dc9a5  vmovaps [rsp+0x60], xmm6
000073ef1c5dc9ab  vmovaps [rsp+0x70], xmm7
000073ef1c5dc9b1  vmovaps [rsp+0x80], xmm9
000073ef1c5dc9ba  vmovaps [rsp+0x90], xmm10
000073ef1c5dc9c3  vmovaps [rsp+0xA0], xmm11
000073ef1c5dc9cc  vmovaps [rsp+0xB0], xmm12
000073ef1c5dc9d5  vmovaps [rsp+0xC0], xmm13
000073ef1c5dc9de  vmovaps [rsp+0xD0], xmm14
000073ef1c5dc9e7  vmovaps [rsp+0xE0], xmm15
000073ef1c5dc9f0  sub rsp, 0x30
000073ef1c5dc9f4  movaps [rsp], xmm8
000073ef1c5dc9f9  movaps [rsp+0x10], xmm12
000073ef1c5dc9ff  movaps [rsp+0x20], xmm15
000073ef1c5dca05  lea rdi, [rsp]
000073ef1c5dca09  mov esi, 0x00
000073ef1c5dca0e  mov rax, 0x56F25E118530
000073ef1c5dca18  call rax
000073ef1c5dca1a  movaps xmm8, [rsp]
000073ef1c5dca1f  add rsp, 0x30
000073ef1c5dca23  vmovaps xmm0, [rsp]
000073ef1c5dca28  vmovaps xmm1, [rsp+0x10]
000073ef1c5dca2e  vmovaps xmm2, [rsp+0x20]
000073ef1c5dca34  vmovaps xmm3, [rsp+0x30]
000073ef1c5dca3a  vmovaps xmm4, [rsp+0x40]
000073ef1c5dca40  vmovaps xmm5, [rsp+0x50]
000073ef1c5dca46  vmovaps xmm6, [rsp+0x60]
000073ef1c5dca4c  vmovaps xmm7, [rsp+0x70]
000073ef1c5dca52  vmovaps xmm9, [rsp+0x80]
000073ef1c5dca5b  vmovaps xmm10, [rsp+0x90]
000073ef1c5dca64  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dca6d  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dca76  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dca7f  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dca88  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dca91  add rsp, 0xF0
000073ef1c5dca98  pop r11
000073ef1c5dca9a  pop r10
000073ef1c5dca9c  pop r9
000073ef1c5dca9e  pop r8
000073ef1c5dcaa0  pop rsi
000073ef1c5dcaa1  pop rdi
000073ef1c5dcaa2  pop rdx
000073ef1c5dcaa3  pop rcx
000073ef1c5dcaa4  pop rax
000073ef1c5dcaa5  add rsp, 0x08
000073ef1c5dcaa9  jmp 0x000073EF1C5DBB47
000073ef1c5dcaae  sub rsp, 0x08
000073ef1c5dcab2  push rax
000073ef1c5dcab3  push rcx
000073ef1c5dcab4  push rdx
000073ef1c5dcab5  push rdi
000073ef1c5dcab6  push rsi
000073ef1c5dcab7  push r8
000073ef1c5dcab9  push r9
000073ef1c5dcabb  push r10
000073ef1c5dcabd  push r11
000073ef1c5dcabf  sub rsp, 0xF0
000073ef1c5dcac6  vmovaps [rsp], xmm0
000073ef1c5dcacb  vmovaps [rsp+0x10], xmm1
000073ef1c5dcad1  vmovaps [rsp+0x20], xmm2
000073ef1c5dcad7  vmovaps [rsp+0x30], xmm3
000073ef1c5dcadd  vmovaps [rsp+0x40], xmm4
000073ef1c5dcae3  vmovaps [rsp+0x50], xmm5
000073ef1c5dcae9  vmovaps [rsp+0x60], xmm6
000073ef1c5dcaef  vmovaps [rsp+0x70], xmm8
000073ef1c5dcaf5  vmovaps [rsp+0x80], xmm9
000073ef1c5dcafe  vmovaps [rsp+0x90], xmm10
000073ef1c5dcb07  vmovaps [rsp+0xA0], xmm11
000073ef1c5dcb10  vmovaps [rsp+0xB0], xmm12
000073ef1c5dcb19  vmovaps [rsp+0xC0], xmm13
000073ef1c5dcb22  vmovaps [rsp+0xD0], xmm14
000073ef1c5dcb2b  vmovaps [rsp+0xE0], xmm15
000073ef1c5dcb34  sub rsp, 0x30
000073ef1c5dcb38  movaps [rsp], xmm7
000073ef1c5dcb3c  movaps [rsp+0x10], xmm9
000073ef1c5dcb42  movaps [rsp+0x20], xmm15
000073ef1c5dcb48  lea rdi, [rsp]
000073ef1c5dcb4c  mov esi, 0x00
000073ef1c5dcb51  mov rax, 0x56F25E118530
000073ef1c5dcb5b  call rax
000073ef1c5dcb5d  movaps xmm7, [rsp]
000073ef1c5dcb61  add rsp, 0x30
000073ef1c5dcb65  vmovaps xmm0, [rsp]
000073ef1c5dcb6a  vmovaps xmm1, [rsp+0x10]
000073ef1c5dcb70  vmovaps xmm2, [rsp+0x20]
000073ef1c5dcb76  vmovaps xmm3, [rsp+0x30]
000073ef1c5dcb7c  vmovaps xmm4, [rsp+0x40]
000073ef1c5dcb82  vmovaps xmm5, [rsp+0x50]
000073ef1c5dcb88  vmovaps xmm6, [rsp+0x60]
000073ef1c5dcb8e  vmovaps xmm8, [rsp+0x70]
000073ef1c5dcb94  vmovaps xmm9, [rsp+0x80]
000073ef1c5dcb9d  vmovaps xmm10, [rsp+0x90]
000073ef1c5dcba6  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dcbaf  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dcbb8  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dcbc1  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dcbca  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dcbd3  add rsp, 0xF0
000073ef1c5dcbda  pop r11
000073ef1c5dcbdc  pop r10
000073ef1c5dcbde  pop r9
000073ef1c5dcbe0  pop r8
000073ef1c5dcbe2  pop rsi
000073ef1c5dcbe3  pop rdi
000073ef1c5dcbe4  pop rdx
000073ef1c5dcbe5  pop rcx
000073ef1c5dcbe6  pop rax
000073ef1c5dcbe7  add rsp, 0x08
000073ef1c5dcbeb  jmp 0x000073EF1C5DBB75
000073ef1c5dcbf0  sub rsp, 0x08
000073ef1c5dcbf4  push rax
000073ef1c5dcbf5  push rcx
000073ef1c5dcbf6  push rdx
000073ef1c5dcbf7  push rdi
000073ef1c5dcbf8  push rsi
000073ef1c5dcbf9  push r8
000073ef1c5dcbfb  push r9
000073ef1c5dcbfd  push r10
000073ef1c5dcbff  push r11
000073ef1c5dcc01  sub rsp, 0xF0
000073ef1c5dcc08  vmovaps [rsp], xmm0
000073ef1c5dcc0d  vmovaps [rsp+0x10], xmm1
000073ef1c5dcc13  vmovaps [rsp+0x20], xmm2
000073ef1c5dcc19  vmovaps [rsp+0x30], xmm3
000073ef1c5dcc1f  vmovaps [rsp+0x40], xmm4
000073ef1c5dcc25  vmovaps [rsp+0x50], xmm5
000073ef1c5dcc2b  vmovaps [rsp+0x60], xmm6
000073ef1c5dcc31  vmovaps [rsp+0x70], xmm7
000073ef1c5dcc37  vmovaps [rsp+0x80], xmm8
000073ef1c5dcc40  vmovaps [rsp+0x90], xmm10
000073ef1c5dcc49  vmovaps [rsp+0xA0], xmm11
000073ef1c5dcc52  vmovaps [rsp+0xB0], xmm12
000073ef1c5dcc5b  vmovaps [rsp+0xC0], xmm13
000073ef1c5dcc64  vmovaps [rsp+0xD0], xmm14
000073ef1c5dcc6d  vmovaps [rsp+0xE0], xmm15
000073ef1c5dcc76  sub rsp, 0x30
000073ef1c5dcc7a  movaps [rsp], xmm9
000073ef1c5dcc7f  movaps [rsp+0x10], xmm12
000073ef1c5dcc85  movaps [rsp+0x20], xmm10
000073ef1c5dcc8b  lea rdi, [rsp]
000073ef1c5dcc8f  mov esi, 0x00
000073ef1c5dcc94  mov rax, 0x56F25E118530
000073ef1c5dcc9e  call rax
000073ef1c5dcca0  movaps xmm9, [rsp]
000073ef1c5dcca5  add rsp, 0x30
000073ef1c5dcca9  vmovaps xmm0, [rsp]
000073ef1c5dccae  vmovaps xmm1, [rsp+0x10]
000073ef1c5dccb4  vmovaps xmm2, [rsp+0x20]
000073ef1c5dccba  vmovaps xmm3, [rsp+0x30]
000073ef1c5dccc0  vmovaps xmm4, [rsp+0x40]
000073ef1c5dccc6  vmovaps xmm5, [rsp+0x50]
000073ef1c5dcccc  vmovaps xmm6, [rsp+0x60]
000073ef1c5dccd2  vmovaps xmm7, [rsp+0x70]
000073ef1c5dccd8  vmovaps xmm8, [rsp+0x80]
000073ef1c5dcce1  vmovaps xmm10, [rsp+0x90]
000073ef1c5dccea  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dccf3  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dccfc  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dcd05  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dcd0e  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dcd17  add rsp, 0xF0
000073ef1c5dcd1e  pop r11
000073ef1c5dcd20  pop r10
000073ef1c5dcd22  pop r9
000073ef1c5dcd24  pop r8
000073ef1c5dcd26  pop rsi
000073ef1c5dcd27  pop rdi
000073ef1c5dcd28  pop rdx
000073ef1c5dcd29  pop rcx
000073ef1c5dcd2a  pop rax
000073ef1c5dcd2b  add rsp, 0x08
000073ef1c5dcd2f  jmp 0x000073EF1C5DBB99
000073ef1c5dcd34  sub rsp, 0x08
000073ef1c5dcd38  push rax
000073ef1c5dcd39  push rcx
000073ef1c5dcd3a  push rdx
000073ef1c5dcd3b  push rdi
000073ef1c5dcd3c  push rsi
000073ef1c5dcd3d  push r8
000073ef1c5dcd3f  push r9
000073ef1c5dcd41  push r10
000073ef1c5dcd43  push r11
000073ef1c5dcd45  sub rsp, 0xF0
000073ef1c5dcd4c  vmovaps [rsp], xmm0
000073ef1c5dcd51  vmovaps [rsp+0x10], xmm1
000073ef1c5dcd57  vmovaps [rsp+0x20], xmm2
000073ef1c5dcd5d  vmovaps [rsp+0x30], xmm3
000073ef1c5dcd63  vmovaps [rsp+0x40], xmm4
000073ef1c5dcd69  vmovaps [rsp+0x50], xmm5
000073ef1c5dcd6f  vmovaps [rsp+0x60], xmm6
000073ef1c5dcd75  vmovaps [rsp+0x70], xmm7
000073ef1c5dcd7b  vmovaps [rsp+0x80], xmm8
000073ef1c5dcd84  vmovaps [rsp+0x90], xmm9
000073ef1c5dcd8d  vmovaps [rsp+0xA0], xmm11
000073ef1c5dcd96  vmovaps [rsp+0xB0], xmm12
000073ef1c5dcd9f  vmovaps [rsp+0xC0], xmm13
000073ef1c5dcda8  vmovaps [rsp+0xD0], xmm14
000073ef1c5dcdb1  vmovaps [rsp+0xE0], xmm15
000073ef1c5dcdba  sub rsp, 0x30
000073ef1c5dcdbe  movaps [rsp], xmm10
000073ef1c5dcdc3  movaps [rsp+0x10], xmm12
000073ef1c5dcdc9  movaps [rsp+0x20], xmm11
000073ef1c5dcdcf  lea rdi, [rsp]
000073ef1c5dcdd3  mov esi, 0x00
000073ef1c5dcdd8  mov rax, 0x56F25E118530
000073ef1c5dcde2  call rax
000073ef1c5dcde4  movaps xmm10, [rsp]
000073ef1c5dcde9  add rsp, 0x30
000073ef1c5dcded  vmovaps xmm0, [rsp]
000073ef1c5dcdf2  vmovaps xmm1, [rsp+0x10]
000073ef1c5dcdf8  vmovaps xmm2, [rsp+0x20]
000073ef1c5dcdfe  vmovaps xmm3, [rsp+0x30]
000073ef1c5dce04  vmovaps xmm4, [rsp+0x40]
000073ef1c5dce0a  vmovaps xmm5, [rsp+0x50]
000073ef1c5dce10  vmovaps xmm6, [rsp+0x60]
000073ef1c5dce16  vmovaps xmm7, [rsp+0x70]
000073ef1c5dce1c  vmovaps xmm8, [rsp+0x80]
000073ef1c5dce25  vmovaps xmm9, [rsp+0x90]
000073ef1c5dce2e  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dce37  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dce40  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dce49  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dce52  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dce5b  add rsp, 0xF0
000073ef1c5dce62  pop r11
000073ef1c5dce64  pop r10
000073ef1c5dce66  pop r9
000073ef1c5dce68  pop r8
000073ef1c5dce6a  pop rsi
000073ef1c5dce6b  pop rdi
000073ef1c5dce6c  pop rdx
000073ef1c5dce6d  pop rcx
000073ef1c5dce6e  pop rax
000073ef1c5dce6f  add rsp, 0x08
000073ef1c5dce73  jmp 0x000073EF1C5DBBB3
000073ef1c5dce78  sub rsp, 0x08
000073ef1c5dce7c  push rax
000073ef1c5dce7d  push rcx
000073ef1c5dce7e  push rdx
000073ef1c5dce7f  push rdi
000073ef1c5dce80  push rsi
000073ef1c5dce81  push r8
000073ef1c5dce83  push r9
000073ef1c5dce85  push r10
000073ef1c5dce87  push r11
000073ef1c5dce89  sub rsp, 0xF0
000073ef1c5dce90  vmovaps [rsp], xmm0
000073ef1c5dce95  vmovaps [rsp+0x10], xmm1
000073ef1c5dce9b  vmovaps [rsp+0x20], xmm2
000073ef1c5dcea1  vmovaps [rsp+0x30], xmm3
000073ef1c5dcea7  vmovaps [rsp+0x40], xmm4
000073ef1c5dcead  vmovaps [rsp+0x50], xmm5
000073ef1c5dceb3  vmovaps [rsp+0x60], xmm7
000073ef1c5dceb9  vmovaps [rsp+0x70], xmm8
000073ef1c5dcebf  vmovaps [rsp+0x80], xmm9
000073ef1c5dcec8  vmovaps [rsp+0x90], xmm10
000073ef1c5dced1  vmovaps [rsp+0xA0], xmm11
000073ef1c5dceda  vmovaps [rsp+0xB0], xmm12
000073ef1c5dcee3  vmovaps [rsp+0xC0], xmm13
000073ef1c5dceec  vmovaps [rsp+0xD0], xmm14
000073ef1c5dcef5  vmovaps [rsp+0xE0], xmm15
000073ef1c5dcefe  sub rsp, 0x30
000073ef1c5dcf02  movaps [rsp], xmm6
000073ef1c5dcf06  movaps [rsp+0x10], xmm12
000073ef1c5dcf0c  movaps [rsp+0x20], xmm11
000073ef1c5dcf12  lea rdi, [rsp]
000073ef1c5dcf16  mov esi, 0x00
000073ef1c5dcf1b  mov rax, 0x56F25E118530
000073ef1c5dcf25  call rax
000073ef1c5dcf27  movaps xmm6, [rsp]
000073ef1c5dcf2b  add rsp, 0x30
000073ef1c5dcf2f  vmovaps xmm0, [rsp]
000073ef1c5dcf34  vmovaps xmm1, [rsp+0x10]
000073ef1c5dcf3a  vmovaps xmm2, [rsp+0x20]
000073ef1c5dcf40  vmovaps xmm3, [rsp+0x30]
000073ef1c5dcf46  vmovaps xmm4, [rsp+0x40]
000073ef1c5dcf4c  vmovaps xmm5, [rsp+0x50]
000073ef1c5dcf52  vmovaps xmm7, [rsp+0x60]
000073ef1c5dcf58  vmovaps xmm8, [rsp+0x70]
000073ef1c5dcf5e  vmovaps xmm9, [rsp+0x80]
000073ef1c5dcf67  vmovaps xmm10, [rsp+0x90]
000073ef1c5dcf70  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dcf79  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dcf82  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dcf8b  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dcf94  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dcf9d  add rsp, 0xF0
000073ef1c5dcfa4  pop r11
000073ef1c5dcfa6  pop r10
000073ef1c5dcfa8  pop r9
000073ef1c5dcfaa  pop r8
000073ef1c5dcfac  pop rsi
000073ef1c5dcfad  pop rdi
000073ef1c5dcfae  pop rdx
000073ef1c5dcfaf  pop rcx
000073ef1c5dcfb0  pop rax
000073ef1c5dcfb1  add rsp, 0x08
000073ef1c5dcfb5  jmp 0x000073EF1C5DBBD4
000073ef1c5dcfba  sub rsp, 0x08
000073ef1c5dcfbe  push rax
000073ef1c5dcfbf  push rcx
000073ef1c5dcfc0  push rdx
000073ef1c5dcfc1  push rdi
000073ef1c5dcfc2  push rsi
000073ef1c5dcfc3  push r8
000073ef1c5dcfc5  push r9
000073ef1c5dcfc7  push r10
000073ef1c5dcfc9  push r11
000073ef1c5dcfcb  sub rsp, 0xF0
000073ef1c5dcfd2  vmovaps [rsp], xmm0
000073ef1c5dcfd7  vmovaps [rsp+0x10], xmm1
000073ef1c5dcfdd  vmovaps [rsp+0x20], xmm2
000073ef1c5dcfe3  vmovaps [rsp+0x30], xmm4
000073ef1c5dcfe9  vmovaps [rsp+0x40], xmm5
000073ef1c5dcfef  vmovaps [rsp+0x50], xmm6
000073ef1c5dcff5  vmovaps [rsp+0x60], xmm7
000073ef1c5dcffb  vmovaps [rsp+0x70], xmm8
000073ef1c5dd001  vmovaps [rsp+0x80], xmm9
000073ef1c5dd00a  vmovaps [rsp+0x90], xmm10
000073ef1c5dd013  vmovaps [rsp+0xA0], xmm11
000073ef1c5dd01c  vmovaps [rsp+0xB0], xmm12
000073ef1c5dd025  vmovaps [rsp+0xC0], xmm13
000073ef1c5dd02e  vmovaps [rsp+0xD0], xmm14
000073ef1c5dd037  vmovaps [rsp+0xE0], xmm15
000073ef1c5dd040  sub rsp, 0x30
000073ef1c5dd044  movaps [rsp], xmm3
000073ef1c5dd048  movaps [rsp+0x10], xmm5
000073ef1c5dd04d  movaps [rsp+0x20], xmm4
000073ef1c5dd052  lea rdi, [rsp]
000073ef1c5dd056  mov esi, 0x00
000073ef1c5dd05b  mov rax, 0x56F25E118530
000073ef1c5dd065  call rax
000073ef1c5dd067  movaps xmm3, [rsp]
000073ef1c5dd06b  add rsp, 0x30
000073ef1c5dd06f  vmovaps xmm0, [rsp]
000073ef1c5dd074  vmovaps xmm1, [rsp+0x10]
000073ef1c5dd07a  vmovaps xmm2, [rsp+0x20]
000073ef1c5dd080  vmovaps xmm4, [rsp+0x30]
000073ef1c5dd086  vmovaps xmm5, [rsp+0x40]
000073ef1c5dd08c  vmovaps xmm6, [rsp+0x50]
000073ef1c5dd092  vmovaps xmm7, [rsp+0x60]
000073ef1c5dd098  vmovaps xmm8, [rsp+0x70]
000073ef1c5dd09e  vmovaps xmm9, [rsp+0x80]
000073ef1c5dd0a7  vmovaps xmm10, [rsp+0x90]
000073ef1c5dd0b0  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dd0b9  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dd0c2  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dd0cb  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dd0d4  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dd0dd  add rsp, 0xF0
000073ef1c5dd0e4  pop r11
000073ef1c5dd0e6  pop r10
000073ef1c5dd0e8  pop r9
000073ef1c5dd0ea  pop r8
000073ef1c5dd0ec  pop rsi
000073ef1c5dd0ed  pop rdi
000073ef1c5dd0ee  pop rdx
000073ef1c5dd0ef  pop rcx
000073ef1c5dd0f0  pop rax
000073ef1c5dd0f1  add rsp, 0x08
000073ef1c5dd0f5  jmp 0x000073EF1C5DBC35
000073ef1c5dd0fa  sub rsp, 0x08
000073ef1c5dd0fe  push rax
000073ef1c5dd0ff  push rcx
000073ef1c5dd100  push rdx
000073ef1c5dd101  push rdi
000073ef1c5dd102  push rsi
000073ef1c5dd103  push r8
000073ef1c5dd105  push r9
000073ef1c5dd107  push r10
000073ef1c5dd109  push r11
000073ef1c5dd10b  sub rsp, 0xF0
000073ef1c5dd112  vmovaps [rsp], xmm0
000073ef1c5dd117  vmovaps [rsp+0x10], xmm1
000073ef1c5dd11d  vmovaps [rsp+0x20], xmm2
000073ef1c5dd123  vmovaps [rsp+0x30], xmm3
000073ef1c5dd129  vmovaps [rsp+0x40], xmm4
000073ef1c5dd12f  vmovaps [rsp+0x50], xmm6
000073ef1c5dd135  vmovaps [rsp+0x60], xmm7
000073ef1c5dd13b  vmovaps [rsp+0x70], xmm8
000073ef1c5dd141  vmovaps [rsp+0x80], xmm9
000073ef1c5dd14a  vmovaps [rsp+0x90], xmm10
000073ef1c5dd153  vmovaps [rsp+0xA0], xmm11
000073ef1c5dd15c  vmovaps [rsp+0xB0], xmm12
000073ef1c5dd165  vmovaps [rsp+0xC0], xmm13
000073ef1c5dd16e  vmovaps [rsp+0xD0], xmm14
000073ef1c5dd177  vmovaps [rsp+0xE0], xmm15
000073ef1c5dd180  sub rsp, 0x30
000073ef1c5dd184  movaps [rsp], xmm5
000073ef1c5dd188  movaps [rsp+0x10], xmm8
000073ef1c5dd18e  movaps [rsp+0x20], xmm15
000073ef1c5dd194  lea rdi, [rsp]
000073ef1c5dd198  mov esi, 0x00
000073ef1c5dd19d  mov rax, 0x56F25E118530
000073ef1c5dd1a7  call rax
000073ef1c5dd1a9  movaps xmm5, [rsp]
000073ef1c5dd1ad  add rsp, 0x30
000073ef1c5dd1b1  vmovaps xmm0, [rsp]
000073ef1c5dd1b6  vmovaps xmm1, [rsp+0x10]
000073ef1c5dd1bc  vmovaps xmm2, [rsp+0x20]
000073ef1c5dd1c2  vmovaps xmm3, [rsp+0x30]
000073ef1c5dd1c8  vmovaps xmm4, [rsp+0x40]
000073ef1c5dd1ce  vmovaps xmm6, [rsp+0x50]
000073ef1c5dd1d4  vmovaps xmm7, [rsp+0x60]
000073ef1c5dd1da  vmovaps xmm8, [rsp+0x70]
000073ef1c5dd1e0  vmovaps xmm9, [rsp+0x80]
000073ef1c5dd1e9  vmovaps xmm10, [rsp+0x90]
000073ef1c5dd1f2  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dd1fb  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dd204  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dd20d  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dd216  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dd21f  add rsp, 0xF0
000073ef1c5dd226  pop r11
000073ef1c5dd228  pop r10
000073ef1c5dd22a  pop r9
000073ef1c5dd22c  pop r8
000073ef1c5dd22e  pop rsi
000073ef1c5dd22f  pop rdi
000073ef1c5dd230  pop rdx
000073ef1c5dd231  pop rcx
000073ef1c5dd232  pop rax
000073ef1c5dd233  add rsp, 0x08
000073ef1c5dd237  jmp 0x000073EF1C5DBC73
000073ef1c5dd23c  sub rsp, 0x08
000073ef1c5dd240  push rax
000073ef1c5dd241  push rcx
000073ef1c5dd242  push rdx
000073ef1c5dd243  push rdi
000073ef1c5dd244  push rsi
000073ef1c5dd245  push r8
000073ef1c5dd247  push r9
000073ef1c5dd249  push r10
000073ef1c5dd24b  push r11
000073ef1c5dd24d  sub rsp, 0xF0
000073ef1c5dd254  vmovaps [rsp], xmm0
000073ef1c5dd259  vmovaps [rsp+0x10], xmm1
000073ef1c5dd25f  vmovaps [rsp+0x20], xmm2
000073ef1c5dd265  vmovaps [rsp+0x30], xmm3
000073ef1c5dd26b  vmovaps [rsp+0x40], xmm5
000073ef1c5dd271  vmovaps [rsp+0x50], xmm6
000073ef1c5dd277  vmovaps [rsp+0x60], xmm7
000073ef1c5dd27d  vmovaps [rsp+0x70], xmm8
000073ef1c5dd283  vmovaps [rsp+0x80], xmm9
000073ef1c5dd28c  vmovaps [rsp+0x90], xmm10
000073ef1c5dd295  vmovaps [rsp+0xA0], xmm11
000073ef1c5dd29e  vmovaps [rsp+0xB0], xmm12
000073ef1c5dd2a7  vmovaps [rsp+0xC0], xmm13
000073ef1c5dd2b0  vmovaps [rsp+0xD0], xmm14
000073ef1c5dd2b9  vmovaps [rsp+0xE0], xmm15
000073ef1c5dd2c2  sub rsp, 0x30
000073ef1c5dd2c6  movaps [rsp], xmm4
000073ef1c5dd2ca  movaps [rsp+0x10], xmm9
000073ef1c5dd2d0  movaps [rsp+0x20], xmm8
000073ef1c5dd2d6  lea rdi, [rsp]
000073ef1c5dd2da  mov esi, 0x00
000073ef1c5dd2df  mov rax, 0x56F25E118530
000073ef1c5dd2e9  call rax
000073ef1c5dd2eb  movaps xmm4, [rsp]
000073ef1c5dd2ef  add rsp, 0x30
000073ef1c5dd2f3  vmovaps xmm0, [rsp]
000073ef1c5dd2f8  vmovaps xmm1, [rsp+0x10]
000073ef1c5dd2fe  vmovaps xmm2, [rsp+0x20]
000073ef1c5dd304  vmovaps xmm3, [rsp+0x30]
000073ef1c5dd30a  vmovaps xmm5, [rsp+0x40]
000073ef1c5dd310  vmovaps xmm6, [rsp+0x50]
000073ef1c5dd316  vmovaps xmm7, [rsp+0x60]
000073ef1c5dd31c  vmovaps xmm8, [rsp+0x70]
000073ef1c5dd322  vmovaps xmm9, [rsp+0x80]
000073ef1c5dd32b  vmovaps xmm10, [rsp+0x90]
000073ef1c5dd334  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dd33d  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dd346  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dd34f  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dd358  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dd361  add rsp, 0xF0
000073ef1c5dd368  pop r11
000073ef1c5dd36a  pop r10
000073ef1c5dd36c  pop r9
000073ef1c5dd36e  pop r8
000073ef1c5dd370  pop rsi
000073ef1c5dd371  pop rdi
000073ef1c5dd372  pop rdx
000073ef1c5dd373  pop rcx
000073ef1c5dd374  pop rax
000073ef1c5dd375  add rsp, 0x08
000073ef1c5dd379  jmp 0x000073EF1C5DBC94
000073ef1c5dd37e  sub rsp, 0x08
000073ef1c5dd382  push rax
000073ef1c5dd383  push rcx
000073ef1c5dd384  push rdx
000073ef1c5dd385  push rdi
000073ef1c5dd386  push rsi
000073ef1c5dd387  push r8
000073ef1c5dd389  push r9
000073ef1c5dd38b  push r10
000073ef1c5dd38d  push r11
000073ef1c5dd38f  sub rsp, 0xF0
000073ef1c5dd396  vmovaps [rsp], xmm0
000073ef1c5dd39b  vmovaps [rsp+0x10], xmm1
000073ef1c5dd3a1  vmovaps [rsp+0x20], xmm2
000073ef1c5dd3a7  vmovaps [rsp+0x30], xmm3
000073ef1c5dd3ad  vmovaps [rsp+0x40], xmm4
000073ef1c5dd3b3  vmovaps [rsp+0x50], xmm5
000073ef1c5dd3b9  vmovaps [rsp+0x60], xmm6
000073ef1c5dd3bf  vmovaps [rsp+0x70], xmm7
000073ef1c5dd3c5  vmovaps [rsp+0x80], xmm8
000073ef1c5dd3ce  vmovaps [rsp+0x90], xmm10
000073ef1c5dd3d7  vmovaps [rsp+0xA0], xmm11
000073ef1c5dd3e0  vmovaps [rsp+0xB0], xmm12
000073ef1c5dd3e9  vmovaps [rsp+0xC0], xmm13
000073ef1c5dd3f2  vmovaps [rsp+0xD0], xmm14
000073ef1c5dd3fb  vmovaps [rsp+0xE0], xmm15
000073ef1c5dd404  sub rsp, 0x30
000073ef1c5dd408  movaps [rsp], xmm9
000073ef1c5dd40d  movaps [rsp+0x10], xmm10
000073ef1c5dd413  movaps [rsp+0x20], xmm8
000073ef1c5dd419  lea rdi, [rsp]
000073ef1c5dd41d  mov esi, 0x00
000073ef1c5dd422  mov rax, 0x56F25E118530
000073ef1c5dd42c  call rax
000073ef1c5dd42e  movaps xmm9, [rsp]
000073ef1c5dd433  add rsp, 0x30
000073ef1c5dd437  vmovaps xmm0, [rsp]
000073ef1c5dd43c  vmovaps xmm1, [rsp+0x10]
000073ef1c5dd442  vmovaps xmm2, [rsp+0x20]
000073ef1c5dd448  vmovaps xmm3, [rsp+0x30]
000073ef1c5dd44e  vmovaps xmm4, [rsp+0x40]
000073ef1c5dd454  vmovaps xmm5, [rsp+0x50]
000073ef1c5dd45a  vmovaps xmm6, [rsp+0x60]
000073ef1c5dd460  vmovaps xmm7, [rsp+0x70]
000073ef1c5dd466  vmovaps xmm8, [rsp+0x80]
000073ef1c5dd46f  vmovaps xmm10, [rsp+0x90]
000073ef1c5dd478  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dd481  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dd48a  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dd493  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dd49c  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dd4a5  add rsp, 0xF0
000073ef1c5dd4ac  pop r11
000073ef1c5dd4ae  pop r10
000073ef1c5dd4b0  pop r9
000073ef1c5dd4b2  pop r8
000073ef1c5dd4b4  pop rsi
000073ef1c5dd4b5  pop rdi
000073ef1c5dd4b6  pop rdx
000073ef1c5dd4b7  pop rcx
000073ef1c5dd4b8  pop rax
000073ef1c5dd4b9  add rsp, 0x08
000073ef1c5dd4bd  jmp 0x000073EF1C5DBCAE
000073ef1c5dd4c2  call 0x000073EF1C4B52F0
000073ef1c5dd4c7  jmp 0x000073EF1C5DBDC8
000073ef1c5dd4cc  call 0x000073EF1C4B52F0
000073ef1c5dd4d1  jmp 0x000073EF1C5DBDDE
000073ef1c5dd4d6  sub rsp, 0x08
000073ef1c5dd4da  push rax
000073ef1c5dd4db  push rcx
000073ef1c5dd4dc  push rdx
000073ef1c5dd4dd  push rdi
000073ef1c5dd4de  push rsi
000073ef1c5dd4df  push r8
000073ef1c5dd4e1  push r9
000073ef1c5dd4e3  push r10
000073ef1c5dd4e5  push r11
000073ef1c5dd4e7  sub rsp, 0xF0
000073ef1c5dd4ee  vmovaps [rsp], xmm0
000073ef1c5dd4f3  vmovaps [rsp+0x10], xmm2
000073ef1c5dd4f9  vmovaps [rsp+0x20], xmm3
000073ef1c5dd4ff  vmovaps [rsp+0x30], xmm4
000073ef1c5dd505  vmovaps [rsp+0x40], xmm5
000073ef1c5dd50b  vmovaps [rsp+0x50], xmm6
000073ef1c5dd511  vmovaps [rsp+0x60], xmm7
000073ef1c5dd517  vmovaps [rsp+0x70], xmm8
000073ef1c5dd51d  vmovaps [rsp+0x80], xmm9
000073ef1c5dd526  vmovaps [rsp+0x90], xmm10
000073ef1c5dd52f  vmovaps [rsp+0xA0], xmm11
000073ef1c5dd538  vmovaps [rsp+0xB0], xmm12
000073ef1c5dd541  vmovaps [rsp+0xC0], xmm13
000073ef1c5dd54a  vmovaps [rsp+0xD0], xmm14
000073ef1c5dd553  vmovaps [rsp+0xE0], xmm15
000073ef1c5dd55c  sub rsp, 0x30
000073ef1c5dd560  movaps [rsp], xmm1
000073ef1c5dd564  movaps [rsp+0x10], xmm6
000073ef1c5dd569  movaps [rsp+0x20], xmm15
000073ef1c5dd56f  lea rdi, [rsp]
000073ef1c5dd573  mov esi, 0x00
000073ef1c5dd578  mov rax, 0x56F25E118530
000073ef1c5dd582  call rax
000073ef1c5dd584  movaps xmm1, [rsp]
000073ef1c5dd588  add rsp, 0x30
000073ef1c5dd58c  vmovaps xmm0, [rsp]
000073ef1c5dd591  vmovaps xmm2, [rsp+0x10]
000073ef1c5dd597  vmovaps xmm3, [rsp+0x20]
000073ef1c5dd59d  vmovaps xmm4, [rsp+0x30]
000073ef1c5dd5a3  vmovaps xmm5, [rsp+0x40]
000073ef1c5dd5a9  vmovaps xmm6, [rsp+0x50]
000073ef1c5dd5af  vmovaps xmm7, [rsp+0x60]
000073ef1c5dd5b5  vmovaps xmm8, [rsp+0x70]
000073ef1c5dd5bb  vmovaps xmm9, [rsp+0x80]
000073ef1c5dd5c4  vmovaps xmm10, [rsp+0x90]
000073ef1c5dd5cd  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dd5d6  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dd5df  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dd5e8  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dd5f1  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dd5fa  add rsp, 0xF0
000073ef1c5dd601  pop r11
000073ef1c5dd603  pop r10
000073ef1c5dd605  pop r9
000073ef1c5dd607  pop r8
000073ef1c5dd609  pop rsi
000073ef1c5dd60a  pop rdi
000073ef1c5dd60b  pop rdx
000073ef1c5dd60c  pop rcx
000073ef1c5dd60d  pop rax
000073ef1c5dd60e  add rsp, 0x08
000073ef1c5dd612  jmp 0x000073EF1C5DBE1B
000073ef1c5dd617  call 0x000073EF1C4C4620
000073ef1c5dd61c  jmp 0x000073EF1C5DBE28
000073ef1c5dd621  sub rsp, 0x08
000073ef1c5dd625  push rax
000073ef1c5dd626  push rcx
000073ef1c5dd627  push rdx
000073ef1c5dd628  push rdi
000073ef1c5dd629  push rsi
000073ef1c5dd62a  push r8
000073ef1c5dd62c  push r9
000073ef1c5dd62e  push r10
000073ef1c5dd630  push r11
000073ef1c5dd632  sub rsp, 0xF0
000073ef1c5dd639  vmovaps [rsp], xmm0
000073ef1c5dd63e  vmovaps [rsp+0x10], xmm1
000073ef1c5dd644  vmovaps [rsp+0x20], xmm2
000073ef1c5dd64a  vmovaps [rsp+0x30], xmm3
000073ef1c5dd650  vmovaps [rsp+0x40], xmm4
000073ef1c5dd656  vmovaps [rsp+0x50], xmm5
000073ef1c5dd65c  vmovaps [rsp+0x60], xmm6
000073ef1c5dd662  vmovaps [rsp+0x70], xmm7
000073ef1c5dd668  vmovaps [rsp+0x80], xmm8
000073ef1c5dd671  vmovaps [rsp+0x90], xmm9
000073ef1c5dd67a  vmovaps [rsp+0xA0], xmm10
000073ef1c5dd683  vmovaps [rsp+0xB0], xmm11
000073ef1c5dd68c  vmovaps [rsp+0xC0], xmm12
000073ef1c5dd695  vmovaps [rsp+0xD0], xmm13
000073ef1c5dd69e  vmovaps [rsp+0xE0], xmm15
000073ef1c5dd6a7  sub rsp, 0x30
000073ef1c5dd6ab  movaps [rsp], xmm14
000073ef1c5dd6b0  movaps [rsp+0x10], xmm4
000073ef1c5dd6b5  movaps [rsp+0x20], xmm3
000073ef1c5dd6ba  lea rdi, [rsp]
000073ef1c5dd6be  mov esi, 0x00
000073ef1c5dd6c3  mov rax, 0x56F25E118530
000073ef1c5dd6cd  call rax
000073ef1c5dd6cf  movaps xmm14, [rsp]
000073ef1c5dd6d4  add rsp, 0x30
000073ef1c5dd6d8  vmovaps xmm0, [rsp]
000073ef1c5dd6dd  vmovaps xmm1, [rsp+0x10]
000073ef1c5dd6e3  vmovaps xmm2, [rsp+0x20]
000073ef1c5dd6e9  vmovaps xmm3, [rsp+0x30]
000073ef1c5dd6ef  vmovaps xmm4, [rsp+0x40]
000073ef1c5dd6f5  vmovaps xmm5, [rsp+0x50]
000073ef1c5dd6fb  vmovaps xmm6, [rsp+0x60]
000073ef1c5dd701  vmovaps xmm7, [rsp+0x70]
000073ef1c5dd707  vmovaps xmm8, [rsp+0x80]
000073ef1c5dd710  vmovaps xmm9, [rsp+0x90]
000073ef1c5dd719  vmovaps xmm10, [rsp+0xA0]
000073ef1c5dd722  vmovaps xmm11, [rsp+0xB0]
000073ef1c5dd72b  vmovaps xmm12, [rsp+0xC0]
000073ef1c5dd734  vmovaps xmm13, [rsp+0xD0]
000073ef1c5dd73d  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dd746  add rsp, 0xF0
000073ef1c5dd74d  pop r11
000073ef1c5dd74f  pop r10
000073ef1c5dd751  pop r9
000073ef1c5dd753  pop r8
000073ef1c5dd755  pop rsi
000073ef1c5dd756  pop rdi
000073ef1c5dd757  pop rdx
000073ef1c5dd758  pop rcx
000073ef1c5dd759  pop rax
000073ef1c5dd75a  add rsp, 0x08
000073ef1c5dd75e  jmp 0x000073EF1C5DBE42
000073ef1c5dd763  sub rsp, 0x08
000073ef1c5dd767  push rax
000073ef1c5dd768  push rcx
000073ef1c5dd769  push rdx
000073ef1c5dd76a  push rdi
000073ef1c5dd76b  push rsi
000073ef1c5dd76c  push r8
000073ef1c5dd76e  push r9
000073ef1c5dd770  push r10
000073ef1c5dd772  push r11
000073ef1c5dd774  sub rsp, 0xF0
000073ef1c5dd77b  vmovaps [rsp], xmm0
000073ef1c5dd780  vmovaps [rsp+0x10], xmm1
000073ef1c5dd786  vmovaps [rsp+0x20], xmm2
000073ef1c5dd78c  vmovaps [rsp+0x30], xmm3
000073ef1c5dd792  vmovaps [rsp+0x40], xmm4
000073ef1c5dd798  vmovaps [rsp+0x50], xmm5
000073ef1c5dd79e  vmovaps [rsp+0x60], xmm7
000073ef1c5dd7a4  vmovaps [rsp+0x70], xmm8
000073ef1c5dd7aa  vmovaps [rsp+0x80], xmm9
000073ef1c5dd7b3  vmovaps [rsp+0x90], xmm10
000073ef1c5dd7bc  vmovaps [rsp+0xA0], xmm11
000073ef1c5dd7c5  vmovaps [rsp+0xB0], xmm12
000073ef1c5dd7ce  vmovaps [rsp+0xC0], xmm13
000073ef1c5dd7d7  vmovaps [rsp+0xD0], xmm14
000073ef1c5dd7e0  vmovaps [rsp+0xE0], xmm15
000073ef1c5dd7e9  sub rsp, 0x30
000073ef1c5dd7ed  movaps [rsp], xmm6
000073ef1c5dd7f1  movaps [rsp+0x10], xmm9
000073ef1c5dd7f7  movaps [rsp+0x20], xmm7
000073ef1c5dd7fc  lea rdi, [rsp]
000073ef1c5dd800  mov esi, 0x00
000073ef1c5dd805  mov rax, 0x56F25E118530
000073ef1c5dd80f  call rax
000073ef1c5dd811  movaps xmm6, [rsp]
000073ef1c5dd815  add rsp, 0x30
000073ef1c5dd819  vmovaps xmm0, [rsp]
000073ef1c5dd81e  vmovaps xmm1, [rsp+0x10]
000073ef1c5dd824  vmovaps xmm2, [rsp+0x20]
000073ef1c5dd82a  vmovaps xmm3, [rsp+0x30]
000073ef1c5dd830  vmovaps xmm4, [rsp+0x40]
000073ef1c5dd836  vmovaps xmm5, [rsp+0x50]
000073ef1c5dd83c  vmovaps xmm7, [rsp+0x60]
000073ef1c5dd842  vmovaps xmm8, [rsp+0x70]
000073ef1c5dd848  vmovaps xmm9, [rsp+0x80]
000073ef1c5dd851  vmovaps xmm10, [rsp+0x90]
000073ef1c5dd85a  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dd863  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dd86c  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dd875  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dd87e  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dd887  add rsp, 0xF0
000073ef1c5dd88e  pop r11
000073ef1c5dd890  pop r10
000073ef1c5dd892  pop r9
000073ef1c5dd894  pop r8
000073ef1c5dd896  pop rsi
000073ef1c5dd897  pop rdi
000073ef1c5dd898  pop rdx
000073ef1c5dd899  pop rcx
000073ef1c5dd89a  pop rax
000073ef1c5dd89b  add rsp, 0x08
000073ef1c5dd89f  jmp 0x000073EF1C5DBE5A
000073ef1c5dd8a4  sub rsp, 0x08
000073ef1c5dd8a8  push rax
000073ef1c5dd8a9  push rcx
000073ef1c5dd8aa  push rdx
000073ef1c5dd8ab  push rdi
000073ef1c5dd8ac  push rsi
000073ef1c5dd8ad  push r8
000073ef1c5dd8af  push r9
000073ef1c5dd8b1  push r10
000073ef1c5dd8b3  push r11
000073ef1c5dd8b5  sub rsp, 0xF0
000073ef1c5dd8bc  vmovaps [rsp], xmm0
000073ef1c5dd8c1  vmovaps [rsp+0x10], xmm1
000073ef1c5dd8c7  vmovaps [rsp+0x20], xmm2
000073ef1c5dd8cd  vmovaps [rsp+0x30], xmm3
000073ef1c5dd8d3  vmovaps [rsp+0x40], xmm4
000073ef1c5dd8d9  vmovaps [rsp+0x50], xmm5
000073ef1c5dd8df  vmovaps [rsp+0x60], xmm6
000073ef1c5dd8e5  vmovaps [rsp+0x70], xmm8
000073ef1c5dd8eb  vmovaps [rsp+0x80], xmm9
000073ef1c5dd8f4  vmovaps [rsp+0x90], xmm10
000073ef1c5dd8fd  vmovaps [rsp+0xA0], xmm11
000073ef1c5dd906  vmovaps [rsp+0xB0], xmm12
000073ef1c5dd90f  vmovaps [rsp+0xC0], xmm13
000073ef1c5dd918  vmovaps [rsp+0xD0], xmm14
000073ef1c5dd921  vmovaps [rsp+0xE0], xmm15
000073ef1c5dd92a  sub rsp, 0x30
000073ef1c5dd92e  movaps [rsp], xmm7
000073ef1c5dd932  movaps [rsp+0x10], xmm4
000073ef1c5dd937  movaps [rsp+0x20], xmm9
000073ef1c5dd93d  lea rdi, [rsp]
000073ef1c5dd941  mov esi, 0x00
000073ef1c5dd946  mov rax, 0x56F25E118530
000073ef1c5dd950  call rax
000073ef1c5dd952  movaps xmm7, [rsp]
000073ef1c5dd956  add rsp, 0x30
000073ef1c5dd95a  vmovaps xmm0, [rsp]
000073ef1c5dd95f  vmovaps xmm1, [rsp+0x10]
000073ef1c5dd965  vmovaps xmm2, [rsp+0x20]
000073ef1c5dd96b  vmovaps xmm3, [rsp+0x30]
000073ef1c5dd971  vmovaps xmm4, [rsp+0x40]
000073ef1c5dd977  vmovaps xmm5, [rsp+0x50]
000073ef1c5dd97d  vmovaps xmm6, [rsp+0x60]
000073ef1c5dd983  vmovaps xmm8, [rsp+0x70]
000073ef1c5dd989  vmovaps xmm9, [rsp+0x80]
000073ef1c5dd992  vmovaps xmm10, [rsp+0x90]
000073ef1c5dd99b  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dd9a4  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dd9ad  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dd9b6  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dd9bf  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dd9c8  add rsp, 0xF0
000073ef1c5dd9cf  pop r11
000073ef1c5dd9d1  pop r10
000073ef1c5dd9d3  pop r9
000073ef1c5dd9d5  pop r8
000073ef1c5dd9d7  pop rsi
000073ef1c5dd9d8  pop rdi
000073ef1c5dd9d9  pop rdx
000073ef1c5dd9da  pop rcx
000073ef1c5dd9db  pop rax
000073ef1c5dd9dc  add rsp, 0x08
000073ef1c5dd9e0  jmp 0x000073EF1C5DBE87
000073ef1c5dd9e5  sub rsp, 0x08
000073ef1c5dd9e9  push rax
000073ef1c5dd9ea  push rcx
000073ef1c5dd9eb  push rdx
000073ef1c5dd9ec  push rdi
000073ef1c5dd9ed  push rsi
000073ef1c5dd9ee  push r8
000073ef1c5dd9f0  push r9
000073ef1c5dd9f2  push r10
000073ef1c5dd9f4  push r11
000073ef1c5dd9f6  sub rsp, 0xF0
000073ef1c5dd9fd  vmovaps [rsp], xmm0
000073ef1c5dda02  vmovaps [rsp+0x10], xmm1
000073ef1c5dda08  vmovaps [rsp+0x20], xmm2
000073ef1c5dda0e  vmovaps [rsp+0x30], xmm3
000073ef1c5dda14  vmovaps [rsp+0x40], xmm5
000073ef1c5dda1a  vmovaps [rsp+0x50], xmm6
000073ef1c5dda20  vmovaps [rsp+0x60], xmm7
000073ef1c5dda26  vmovaps [rsp+0x70], xmm8
000073ef1c5dda2c  vmovaps [rsp+0x80], xmm9
000073ef1c5dda35  vmovaps [rsp+0x90], xmm10
000073ef1c5dda3e  vmovaps [rsp+0xA0], xmm11
000073ef1c5dda47  vmovaps [rsp+0xB0], xmm12
000073ef1c5dda50  vmovaps [rsp+0xC0], xmm13
000073ef1c5dda59  vmovaps [rsp+0xD0], xmm14
000073ef1c5dda62  vmovaps [rsp+0xE0], xmm15
000073ef1c5dda6b  sub rsp, 0x30
000073ef1c5dda6f  movaps [rsp], xmm4
000073ef1c5dda73  movaps [rsp+0x10], xmm15
000073ef1c5dda79  movaps [rsp+0x20], xmm9
000073ef1c5dda7f  lea rdi, [rsp]
000073ef1c5dda83  mov esi, 0x00
000073ef1c5dda88  mov rax, 0x56F25E118530
000073ef1c5dda92  call rax
000073ef1c5dda94  movaps xmm4, [rsp]
000073ef1c5dda98  add rsp, 0x30
000073ef1c5dda9c  vmovaps xmm0, [rsp]
000073ef1c5ddaa1  vmovaps xmm1, [rsp+0x10]
000073ef1c5ddaa7  vmovaps xmm2, [rsp+0x20]
000073ef1c5ddaad  vmovaps xmm3, [rsp+0x30]
000073ef1c5ddab3  vmovaps xmm5, [rsp+0x40]
000073ef1c5ddab9  vmovaps xmm6, [rsp+0x50]
000073ef1c5ddabf  vmovaps xmm7, [rsp+0x60]
000073ef1c5ddac5  vmovaps xmm8, [rsp+0x70]
000073ef1c5ddacb  vmovaps xmm9, [rsp+0x80]
000073ef1c5ddad4  vmovaps xmm10, [rsp+0x90]
000073ef1c5ddadd  vmovaps xmm11, [rsp+0xA0]
000073ef1c5ddae6  vmovaps xmm12, [rsp+0xB0]
000073ef1c5ddaef  vmovaps xmm13, [rsp+0xC0]
000073ef1c5ddaf8  vmovaps xmm14, [rsp+0xD0]
000073ef1c5ddb01  vmovaps xmm15, [rsp+0xE0]
000073ef1c5ddb0a  add rsp, 0xF0
000073ef1c5ddb11  pop r11
000073ef1c5ddb13  pop r10
000073ef1c5ddb15  pop r9
000073ef1c5ddb17  pop r8
000073ef1c5ddb19  pop rsi
000073ef1c5ddb1a  pop rdi
000073ef1c5ddb1b  pop rdx
000073ef1c5ddb1c  pop rcx
000073ef1c5ddb1d  pop rax
000073ef1c5ddb1e  add rsp, 0x08
000073ef1c5ddb22  jmp 0x000073EF1C5DBEAC
000073ef1c5ddb27  call 0x000073EF1C4C4620
000073ef1c5ddb2c  jmp 0x000073EF1C5DBEB9
000073ef1c5ddb31  sub rsp, 0x08
000073ef1c5ddb35  push rax
000073ef1c5ddb36  push rcx
000073ef1c5ddb37  push rdx
000073ef1c5ddb38  push rdi
000073ef1c5ddb39  push rsi
000073ef1c5ddb3a  push r8
000073ef1c5ddb3c  push r9
000073ef1c5ddb3e  push r10
000073ef1c5ddb40  push r11
000073ef1c5ddb42  sub rsp, 0xF0
000073ef1c5ddb49  vmovaps [rsp], xmm0
000073ef1c5ddb4e  vmovaps [rsp+0x10], xmm1
000073ef1c5ddb54  vmovaps [rsp+0x20], xmm2
000073ef1c5ddb5a  vmovaps [rsp+0x30], xmm4
000073ef1c5ddb60  vmovaps [rsp+0x40], xmm5
000073ef1c5ddb66  vmovaps [rsp+0x50], xmm6
000073ef1c5ddb6c  vmovaps [rsp+0x60], xmm7
000073ef1c5ddb72  vmovaps [rsp+0x70], xmm8
000073ef1c5ddb78  vmovaps [rsp+0x80], xmm9
000073ef1c5ddb81  vmovaps [rsp+0x90], xmm10
000073ef1c5ddb8a  vmovaps [rsp+0xA0], xmm11
000073ef1c5ddb93  vmovaps [rsp+0xB0], xmm12
000073ef1c5ddb9c  vmovaps [rsp+0xC0], xmm13
000073ef1c5ddba5  vmovaps [rsp+0xD0], xmm14
000073ef1c5ddbae  vmovaps [rsp+0xE0], xmm15
000073ef1c5ddbb7  sub rsp, 0x30
000073ef1c5ddbbb  movaps [rsp], xmm3
000073ef1c5ddbbf  movaps [rsp+0x10], xmm1
000073ef1c5ddbc4  movaps [rsp+0x20], xmm9
000073ef1c5ddbca  lea rdi, [rsp]
000073ef1c5ddbce  mov esi, 0x00
000073ef1c5ddbd3  mov rax, 0x56F25E118530
000073ef1c5ddbdd  call rax
000073ef1c5ddbdf  movaps xmm3, [rsp]
000073ef1c5ddbe3  add rsp, 0x30
000073ef1c5ddbe7  vmovaps xmm0, [rsp]
000073ef1c5ddbec  vmovaps xmm1, [rsp+0x10]
000073ef1c5ddbf2  vmovaps xmm2, [rsp+0x20]
000073ef1c5ddbf8  vmovaps xmm4, [rsp+0x30]
000073ef1c5ddbfe  vmovaps xmm5, [rsp+0x40]
000073ef1c5ddc04  vmovaps xmm6, [rsp+0x50]
000073ef1c5ddc0a  vmovaps xmm7, [rsp+0x60]
000073ef1c5ddc10  vmovaps xmm8, [rsp+0x70]
000073ef1c5ddc16  vmovaps xmm9, [rsp+0x80]
000073ef1c5ddc1f  vmovaps xmm10, [rsp+0x90]
000073ef1c5ddc28  vmovaps xmm11, [rsp+0xA0]
000073ef1c5ddc31  vmovaps xmm12, [rsp+0xB0]
000073ef1c5ddc3a  vmovaps xmm13, [rsp+0xC0]
000073ef1c5ddc43  vmovaps xmm14, [rsp+0xD0]
000073ef1c5ddc4c  vmovaps xmm15, [rsp+0xE0]
000073ef1c5ddc55  add rsp, 0xF0
000073ef1c5ddc5c  pop r11
000073ef1c5ddc5e  pop r10
000073ef1c5ddc60  pop r9
000073ef1c5ddc62  pop r8
000073ef1c5ddc64  pop rsi
000073ef1c5ddc65  pop rdi
000073ef1c5ddc66  pop rdx
000073ef1c5ddc67  pop rcx
000073ef1c5ddc68  pop rax
000073ef1c5ddc69  add rsp, 0x08
000073ef1c5ddc6d  jmp 0x000073EF1C5DBEF6
000073ef1c5ddc72  sub rsp, 0x08
000073ef1c5ddc76  push rax
000073ef1c5ddc77  push rcx
000073ef1c5ddc78  push rdx
000073ef1c5ddc79  push rdi
000073ef1c5ddc7a  push rsi
000073ef1c5ddc7b  push r8
000073ef1c5ddc7d  push r9
000073ef1c5ddc7f  push r10
000073ef1c5ddc81  push r11
000073ef1c5ddc83  sub rsp, 0xF0
000073ef1c5ddc8a  vmovaps [rsp], xmm0
000073ef1c5ddc8f  vmovaps [rsp+0x10], xmm2
000073ef1c5ddc95  vmovaps [rsp+0x20], xmm3
000073ef1c5ddc9b  vmovaps [rsp+0x30], xmm4
000073ef1c5ddca1  vmovaps [rsp+0x40], xmm5
000073ef1c5ddca7  vmovaps [rsp+0x50], xmm6
000073ef1c5ddcad  vmovaps [rsp+0x60], xmm7
000073ef1c5ddcb3  vmovaps [rsp+0x70], xmm8
000073ef1c5ddcb9  vmovaps [rsp+0x80], xmm9
000073ef1c5ddcc2  vmovaps [rsp+0x90], xmm10
000073ef1c5ddccb  vmovaps [rsp+0xA0], xmm11
000073ef1c5ddcd4  vmovaps [rsp+0xB0], xmm12
000073ef1c5ddcdd  vmovaps [rsp+0xC0], xmm13
000073ef1c5ddce6  vmovaps [rsp+0xD0], xmm14
000073ef1c5ddcef  vmovaps [rsp+0xE0], xmm15
000073ef1c5ddcf8  sub rsp, 0x30
000073ef1c5ddcfc  movaps [rsp], xmm1
000073ef1c5ddd00  movaps [rsp+0x10], xmm15
000073ef1c5ddd06  movaps [rsp+0x20], xmm9
000073ef1c5ddd0c  lea rdi, [rsp]
000073ef1c5ddd10  mov esi, 0x00
000073ef1c5ddd15  mov rax, 0x56F25E118530
000073ef1c5ddd1f  call rax
000073ef1c5ddd21  movaps xmm1, [rsp]
000073ef1c5ddd25  add rsp, 0x30
000073ef1c5ddd29  vmovaps xmm0, [rsp]
000073ef1c5ddd2e  vmovaps xmm2, [rsp+0x10]
000073ef1c5ddd34  vmovaps xmm3, [rsp+0x20]
000073ef1c5ddd3a  vmovaps xmm4, [rsp+0x30]
000073ef1c5ddd40  vmovaps xmm5, [rsp+0x40]
000073ef1c5ddd46  vmovaps xmm6, [rsp+0x50]
000073ef1c5ddd4c  vmovaps xmm7, [rsp+0x60]
000073ef1c5ddd52  vmovaps xmm8, [rsp+0x70]
000073ef1c5ddd58  vmovaps xmm9, [rsp+0x80]
000073ef1c5ddd61  vmovaps xmm10, [rsp+0x90]
000073ef1c5ddd6a  vmovaps xmm11, [rsp+0xA0]
000073ef1c5ddd73  vmovaps xmm12, [rsp+0xB0]
000073ef1c5ddd7c  vmovaps xmm13, [rsp+0xC0]
000073ef1c5ddd85  vmovaps xmm14, [rsp+0xD0]
000073ef1c5ddd8e  vmovaps xmm15, [rsp+0xE0]
000073ef1c5ddd97  add rsp, 0xF0
000073ef1c5ddd9e  pop r11
000073ef1c5ddda0  pop r10
000073ef1c5ddda2  pop r9
000073ef1c5ddda4  pop r8
000073ef1c5ddda6  pop rsi
000073ef1c5ddda7  pop rdi
000073ef1c5ddda8  pop rdx
000073ef1c5ddda9  pop rcx
000073ef1c5dddaa  pop rax
000073ef1c5dddab  add rsp, 0x08
000073ef1c5dddaf  jmp 0x000073EF1C5DBF7E
000073ef1c5dddb4  call 0x000073EF1C4C4620
000073ef1c5dddb9  jmp 0x000073EF1C5DBF8B
000073ef1c5dddbe  sub rsp, 0x08
000073ef1c5dddc2  push rax
000073ef1c5dddc3  push rcx
000073ef1c5dddc4  push rdx
000073ef1c5dddc5  push rdi
000073ef1c5dddc6  push rsi
000073ef1c5dddc7  push r8
000073ef1c5dddc9  push r9
000073ef1c5dddcb  push r10
000073ef1c5dddcd  push r11
000073ef1c5dddcf  sub rsp, 0xF0
000073ef1c5dddd6  vmovaps [rsp], xmm0
000073ef1c5ddddb  vmovaps [rsp+0x10], xmm2
000073ef1c5ddde1  vmovaps [rsp+0x20], xmm3
000073ef1c5ddde7  vmovaps [rsp+0x30], xmm4
000073ef1c5ddded  vmovaps [rsp+0x40], xmm5
000073ef1c5dddf3  vmovaps [rsp+0x50], xmm6
000073ef1c5dddf9  vmovaps [rsp+0x60], xmm7
000073ef1c5dddff  vmovaps [rsp+0x70], xmm8
000073ef1c5dde05  vmovaps [rsp+0x80], xmm9
000073ef1c5dde0e  vmovaps [rsp+0x90], xmm10
000073ef1c5dde17  vmovaps [rsp+0xA0], xmm11
000073ef1c5dde20  vmovaps [rsp+0xB0], xmm12
000073ef1c5dde29  vmovaps [rsp+0xC0], xmm13
000073ef1c5dde32  vmovaps [rsp+0xD0], xmm14
000073ef1c5dde3b  vmovaps [rsp+0xE0], xmm15
000073ef1c5dde44  sub rsp, 0x30
000073ef1c5dde48  movaps [rsp], xmm1
000073ef1c5dde4c  movaps [rsp+0x10], xmm5
000073ef1c5dde51  movaps [rsp+0x20], xmm7
000073ef1c5dde56  lea rdi, [rsp]
000073ef1c5dde5a  mov esi, 0x00
000073ef1c5dde5f  mov rax, 0x56F25E118530
000073ef1c5dde69  call rax
000073ef1c5dde6b  movaps xmm1, [rsp]
000073ef1c5dde6f  add rsp, 0x30
000073ef1c5dde73  vmovaps xmm0, [rsp]
000073ef1c5dde78  vmovaps xmm2, [rsp+0x10]
000073ef1c5dde7e  vmovaps xmm3, [rsp+0x20]
000073ef1c5dde84  vmovaps xmm4, [rsp+0x30]
000073ef1c5dde8a  vmovaps xmm5, [rsp+0x40]
000073ef1c5dde90  vmovaps xmm6, [rsp+0x50]
000073ef1c5dde96  vmovaps xmm7, [rsp+0x60]
000073ef1c5dde9c  vmovaps xmm8, [rsp+0x70]
000073ef1c5ddea2  vmovaps xmm9, [rsp+0x80]
000073ef1c5ddeab  vmovaps xmm10, [rsp+0x90]
000073ef1c5ddeb4  vmovaps xmm11, [rsp+0xA0]
000073ef1c5ddebd  vmovaps xmm12, [rsp+0xB0]
000073ef1c5ddec6  vmovaps xmm13, [rsp+0xC0]
000073ef1c5ddecf  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dded8  vmovaps xmm15, [rsp+0xE0]
000073ef1c5ddee1  add rsp, 0xF0
000073ef1c5ddee8  pop r11
000073ef1c5ddeea  pop r10
000073ef1c5ddeec  pop r9
000073ef1c5ddeee  pop r8
000073ef1c5ddef0  pop rsi
000073ef1c5ddef1  pop rdi
000073ef1c5ddef2  pop rdx
000073ef1c5ddef3  pop rcx
000073ef1c5ddef4  pop rax
000073ef1c5ddef5  add rsp, 0x08
000073ef1c5ddef9  jmp 0x000073EF1C5DC030
000073ef1c5ddefe  sub rsp, 0x08
000073ef1c5ddf02  push rax
000073ef1c5ddf03  push rcx
000073ef1c5ddf04  push rdx
000073ef1c5ddf05  push rdi
000073ef1c5ddf06  push rsi
000073ef1c5ddf07  push r8
000073ef1c5ddf09  push r9
000073ef1c5ddf0b  push r10
000073ef1c5ddf0d  push r11
000073ef1c5ddf0f  sub rsp, 0xF0
000073ef1c5ddf16  vmovaps [rsp], xmm0
000073ef1c5ddf1b  vmovaps [rsp+0x10], xmm1
000073ef1c5ddf21  vmovaps [rsp+0x20], xmm2
000073ef1c5ddf27  vmovaps [rsp+0x30], xmm3
000073ef1c5ddf2d  vmovaps [rsp+0x40], xmm4
000073ef1c5ddf33  vmovaps [rsp+0x50], xmm5
000073ef1c5ddf39  vmovaps [rsp+0x60], xmm6
000073ef1c5ddf3f  vmovaps [rsp+0x70], xmm8
000073ef1c5ddf45  vmovaps [rsp+0x80], xmm9
000073ef1c5ddf4e  vmovaps [rsp+0x90], xmm10
000073ef1c5ddf57  vmovaps [rsp+0xA0], xmm11
000073ef1c5ddf60  vmovaps [rsp+0xB0], xmm12
000073ef1c5ddf69  vmovaps [rsp+0xC0], xmm13
000073ef1c5ddf72  vmovaps [rsp+0xD0], xmm14
000073ef1c5ddf7b  vmovaps [rsp+0xE0], xmm15
000073ef1c5ddf84  sub rsp, 0x30
000073ef1c5ddf88  movaps [rsp], xmm7
000073ef1c5ddf8c  movaps [rsp+0x10], xmm5
000073ef1c5ddf91  movaps [rsp+0x20], xmm15
000073ef1c5ddf97  lea rdi, [rsp]
000073ef1c5ddf9b  mov esi, 0x00
000073ef1c5ddfa0  mov rax, 0x56F25E118530
000073ef1c5ddfaa  call rax
000073ef1c5ddfac  movaps xmm7, [rsp]
000073ef1c5ddfb0  add rsp, 0x30
000073ef1c5ddfb4  vmovaps xmm0, [rsp]
000073ef1c5ddfb9  vmovaps xmm1, [rsp+0x10]
000073ef1c5ddfbf  vmovaps xmm2, [rsp+0x20]
000073ef1c5ddfc5  vmovaps xmm3, [rsp+0x30]
000073ef1c5ddfcb  vmovaps xmm4, [rsp+0x40]
000073ef1c5ddfd1  vmovaps xmm5, [rsp+0x50]
000073ef1c5ddfd7  vmovaps xmm6, [rsp+0x60]
000073ef1c5ddfdd  vmovaps xmm8, [rsp+0x70]
000073ef1c5ddfe3  vmovaps xmm9, [rsp+0x80]
000073ef1c5ddfec  vmovaps xmm10, [rsp+0x90]
000073ef1c5ddff5  vmovaps xmm11, [rsp+0xA0]
000073ef1c5ddffe  vmovaps xmm12, [rsp+0xB0]
000073ef1c5de007  vmovaps xmm13, [rsp+0xC0]
000073ef1c5de010  vmovaps xmm14, [rsp+0xD0]
000073ef1c5de019  vmovaps xmm15, [rsp+0xE0]
000073ef1c5de022  add rsp, 0xF0
000073ef1c5de029  pop r11
000073ef1c5de02b  pop r10
000073ef1c5de02d  pop r9
000073ef1c5de02f  pop r8
000073ef1c5de031  pop rsi
000073ef1c5de032  pop rdi
000073ef1c5de033  pop rdx
000073ef1c5de034  pop rcx
000073ef1c5de035  pop rax
000073ef1c5de036  add rsp, 0x08
000073ef1c5de03a  jmp 0x000073EF1C5DC066
000073ef1c5de03f  call 0x000073EF1C4B52F0
000073ef1c5de044  jmp 0x000073EF1C5DC073
000073ef1c5de049  sub rsp, 0x08
000073ef1c5de04d  push rax
000073ef1c5de04e  push rcx
000073ef1c5de04f  push rdx
000073ef1c5de050  push rdi
000073ef1c5de051  push rsi
000073ef1c5de052  push r8
000073ef1c5de054  push r9
000073ef1c5de056  push r10
000073ef1c5de058  push r11
000073ef1c5de05a  sub rsp, 0xF0
000073ef1c5de061  vmovaps [rsp], xmm0
000073ef1c5de066  vmovaps [rsp+0x10], xmm1
000073ef1c5de06c  vmovaps [rsp+0x20], xmm2
000073ef1c5de072  vmovaps [rsp+0x30], xmm3
000073ef1c5de078  vmovaps [rsp+0x40], xmm4
000073ef1c5de07e  vmovaps [rsp+0x50], xmm5
000073ef1c5de084  vmovaps [rsp+0x60], xmm6
000073ef1c5de08a  vmovaps [rsp+0x70], xmm7
000073ef1c5de090  vmovaps [rsp+0x80], xmm8
000073ef1c5de099  vmovaps [rsp+0x90], xmm9
000073ef1c5de0a2  vmovaps [rsp+0xA0], xmm10
000073ef1c5de0ab  vmovaps [rsp+0xB0], xmm11
000073ef1c5de0b4  vmovaps [rsp+0xC0], xmm12
000073ef1c5de0bd  vmovaps [rsp+0xD0], xmm13
000073ef1c5de0c6  vmovaps [rsp+0xE0], xmm14
000073ef1c5de0cf  sub rsp, 0x30
000073ef1c5de0d3  movaps [rsp], xmm15
000073ef1c5de0d8  movaps [rsp+0x10], xmm5
000073ef1c5de0dd  movaps [rsp+0x20], xmm3
000073ef1c5de0e2  lea rdi, [rsp]
000073ef1c5de0e6  mov esi, 0x00
000073ef1c5de0eb  mov rax, 0x56F25E118530
000073ef1c5de0f5  call rax
000073ef1c5de0f7  movaps xmm15, [rsp]
000073ef1c5de0fc  add rsp, 0x30
000073ef1c5de100  vmovaps xmm0, [rsp]
000073ef1c5de105  vmovaps xmm1, [rsp+0x10]
000073ef1c5de10b  vmovaps xmm2, [rsp+0x20]
000073ef1c5de111  vmovaps xmm3, [rsp+0x30]
000073ef1c5de117  vmovaps xmm4, [rsp+0x40]
000073ef1c5de11d  vmovaps xmm5, [rsp+0x50]
000073ef1c5de123  vmovaps xmm6, [rsp+0x60]
000073ef1c5de129  vmovaps xmm7, [rsp+0x70]
000073ef1c5de12f  vmovaps xmm8, [rsp+0x80]
000073ef1c5de138  vmovaps xmm9, [rsp+0x90]
000073ef1c5de141  vmovaps xmm10, [rsp+0xA0]
000073ef1c5de14a  vmovaps xmm11, [rsp+0xB0]
000073ef1c5de153  vmovaps xmm12, [rsp+0xC0]
000073ef1c5de15c  vmovaps xmm13, [rsp+0xD0]
000073ef1c5de165  vmovaps xmm14, [rsp+0xE0]
000073ef1c5de16e  add rsp, 0xF0
000073ef1c5de175  pop r11
000073ef1c5de177  pop r10
000073ef1c5de179  pop r9
000073ef1c5de17b  pop r8
000073ef1c5de17d  pop rsi
000073ef1c5de17e  pop rdi
000073ef1c5de17f  pop rdx
000073ef1c5de180  pop rcx
000073ef1c5de181  pop rax
000073ef1c5de182  add rsp, 0x08
000073ef1c5de186  jmp 0x000073EF1C5DC099
000073ef1c5de18b  sub rsp, 0x08
000073ef1c5de18f  push rax
000073ef1c5de190  push rcx
000073ef1c5de191  push rdx
000073ef1c5de192  push rdi
000073ef1c5de193  push rsi
000073ef1c5de194  push r8
000073ef1c5de196  push r9
000073ef1c5de198  push r10
000073ef1c5de19a  push r11
000073ef1c5de19c  sub rsp, 0xF0
000073ef1c5de1a3  vmovaps [rsp], xmm0
000073ef1c5de1a8  vmovaps [rsp+0x10], xmm2
000073ef1c5de1ae  vmovaps [rsp+0x20], xmm3
000073ef1c5de1b4  vmovaps [rsp+0x30], xmm4
000073ef1c5de1ba  vmovaps [rsp+0x40], xmm5
000073ef1c5de1c0  vmovaps [rsp+0x50], xmm6
000073ef1c5de1c6  vmovaps [rsp+0x60], xmm7
000073ef1c5de1cc  vmovaps [rsp+0x70], xmm8
000073ef1c5de1d2  vmovaps [rsp+0x80], xmm9
000073ef1c5de1db  vmovaps [rsp+0x90], xmm10
000073ef1c5de1e4  vmovaps [rsp+0xA0], xmm11
000073ef1c5de1ed  vmovaps [rsp+0xB0], xmm12
000073ef1c5de1f6  vmovaps [rsp+0xC0], xmm13
000073ef1c5de1ff  vmovaps [rsp+0xD0], xmm14
000073ef1c5de208  vmovaps [rsp+0xE0], xmm15
000073ef1c5de211  sub rsp, 0x30
000073ef1c5de215  movaps [rsp], xmm1
000073ef1c5de219  movaps [rsp+0x10], xmm5
000073ef1c5de21e  movaps [rsp+0x20], xmm4
000073ef1c5de223  lea rdi, [rsp]
000073ef1c5de227  mov esi, 0x00
000073ef1c5de22c  mov rax, 0x56F25E118530
000073ef1c5de236  call rax
000073ef1c5de238  movaps xmm1, [rsp]
000073ef1c5de23c  add rsp, 0x30
000073ef1c5de240  vmovaps xmm0, [rsp]
000073ef1c5de245  vmovaps xmm2, [rsp+0x10]
000073ef1c5de24b  vmovaps xmm3, [rsp+0x20]
000073ef1c5de251  vmovaps xmm4, [rsp+0x30]
000073ef1c5de257  vmovaps xmm5, [rsp+0x40]
000073ef1c5de25d  vmovaps xmm6, [rsp+0x50]
000073ef1c5de263  vmovaps xmm7, [rsp+0x60]
000073ef1c5de269  vmovaps xmm8, [rsp+0x70]
000073ef1c5de26f  vmovaps xmm9, [rsp+0x80]
000073ef1c5de278  vmovaps xmm10, [rsp+0x90]
000073ef1c5de281  vmovaps xmm11, [rsp+0xA0]
000073ef1c5de28a  vmovaps xmm12, [rsp+0xB0]
000073ef1c5de293  vmovaps xmm13, [rsp+0xC0]
000073ef1c5de29c  vmovaps xmm14, [rsp+0xD0]
000073ef1c5de2a5  vmovaps xmm15, [rsp+0xE0]
000073ef1c5de2ae  add rsp, 0xF0
000073ef1c5de2b5  pop r11
000073ef1c5de2b7  pop r10
000073ef1c5de2b9  pop r9
000073ef1c5de2bb  pop r8
000073ef1c5de2bd  pop rsi
000073ef1c5de2be  pop rdi
000073ef1c5de2bf  pop rdx
000073ef1c5de2c0  pop rcx
000073ef1c5de2c1  pop rax
000073ef1c5de2c2  add rsp, 0x08
000073ef1c5de2c6  jmp 0x000073EF1C5DC0B9
000073ef1c5de2cb  sub rsp, 0x08
000073ef1c5de2cf  push rax
000073ef1c5de2d0  push rcx
000073ef1c5de2d1  push rdx
000073ef1c5de2d2  push rdi
000073ef1c5de2d3  push rsi
000073ef1c5de2d4  push r8
000073ef1c5de2d6  push r9
000073ef1c5de2d8  push r10
000073ef1c5de2da  push r11
000073ef1c5de2dc  sub rsp, 0xF0
000073ef1c5de2e3  vmovaps [rsp], xmm0
000073ef1c5de2e8  vmovaps [rsp+0x10], xmm1
000073ef1c5de2ee  vmovaps [rsp+0x20], xmm2
000073ef1c5de2f4  vmovaps [rsp+0x30], xmm3
000073ef1c5de2fa  vmovaps [rsp+0x40], xmm5
000073ef1c5de300  vmovaps [rsp+0x50], xmm6
000073ef1c5de306  vmovaps [rsp+0x60], xmm7
000073ef1c5de30c  vmovaps [rsp+0x70], xmm8
000073ef1c5de312  vmovaps [rsp+0x80], xmm9
000073ef1c5de31b  vmovaps [rsp+0x90], xmm10
000073ef1c5de324  vmovaps [rsp+0xA0], xmm11
000073ef1c5de32d  vmovaps [rsp+0xB0], xmm12
000073ef1c5de336  vmovaps [rsp+0xC0], xmm13
000073ef1c5de33f  vmovaps [rsp+0xD0], xmm14
000073ef1c5de348  vmovaps [rsp+0xE0], xmm15
000073ef1c5de351  sub rsp, 0x30
000073ef1c5de355  movaps [rsp], xmm4
000073ef1c5de359  movaps [rsp+0x10], xmm3
000073ef1c5de35e  movaps [rsp+0x20], xmm5
000073ef1c5de363  lea rdi, [rsp]
000073ef1c5de367  mov esi, 0x00
000073ef1c5de36c  mov rax, 0x56F25E118530
000073ef1c5de376  call rax
000073ef1c5de378  movaps xmm4, [rsp]
000073ef1c5de37c  add rsp, 0x30
000073ef1c5de380  vmovaps xmm0, [rsp]
000073ef1c5de385  vmovaps xmm1, [rsp+0x10]
000073ef1c5de38b  vmovaps xmm2, [rsp+0x20]
000073ef1c5de391  vmovaps xmm3, [rsp+0x30]
000073ef1c5de397  vmovaps xmm5, [rsp+0x40]
000073ef1c5de39d  vmovaps xmm6, [rsp+0x50]
000073ef1c5de3a3  vmovaps xmm7, [rsp+0x60]
000073ef1c5de3a9  vmovaps xmm8, [rsp+0x70]
000073ef1c5de3af  vmovaps xmm9, [rsp+0x80]
000073ef1c5de3b8  vmovaps xmm10, [rsp+0x90]
000073ef1c5de3c1  vmovaps xmm11, [rsp+0xA0]
000073ef1c5de3ca  vmovaps xmm12, [rsp+0xB0]
000073ef1c5de3d3  vmovaps xmm13, [rsp+0xC0]
000073ef1c5de3dc  vmovaps xmm14, [rsp+0xD0]
000073ef1c5de3e5  vmovaps xmm15, [rsp+0xE0]
000073ef1c5de3ee  add rsp, 0xF0
000073ef1c5de3f5  pop r11
000073ef1c5de3f7  pop r10
000073ef1c5de3f9  pop r9
000073ef1c5de3fb  pop r8
000073ef1c5de3fd  pop rsi
000073ef1c5de3fe  pop rdi
000073ef1c5de3ff  pop rdx
000073ef1c5de400  pop rcx
000073ef1c5de401  pop rax
000073ef1c5de402  add rsp, 0x08
000073ef1c5de406  jmp 0x000073EF1C5DC107
000073ef1c5de40b  call 0x000073EF1C4B52F0
000073ef1c5de410  jmp 0x000073EF1C5DC114
000073ef1c5de415  sub rsp, 0x08
000073ef1c5de419  push rax
000073ef1c5de41a  push rcx
000073ef1c5de41b  push rdx
000073ef1c5de41c  push rdi
000073ef1c5de41d  push rsi
000073ef1c5de41e  push r8
000073ef1c5de420  push r9
000073ef1c5de422  push r10
000073ef1c5de424  push r11
000073ef1c5de426  sub rsp, 0xF0
000073ef1c5de42d  vmovaps [rsp], xmm0
000073ef1c5de432  vmovaps [rsp+0x10], xmm1
000073ef1c5de438  vmovaps [rsp+0x20], xmm2
000073ef1c5de43e  vmovaps [rsp+0x30], xmm3
000073ef1c5de444  vmovaps [rsp+0x40], xmm4
000073ef1c5de44a  vmovaps [rsp+0x50], xmm6
000073ef1c5de450  vmovaps [rsp+0x60], xmm7
000073ef1c5de456  vmovaps [rsp+0x70], xmm8
000073ef1c5de45c  vmovaps [rsp+0x80], xmm9
000073ef1c5de465  vmovaps [rsp+0x90], xmm10
000073ef1c5de46e  vmovaps [rsp+0xA0], xmm11
000073ef1c5de477  vmovaps [rsp+0xB0], xmm12
000073ef1c5de480  vmovaps [rsp+0xC0], xmm13
000073ef1c5de489  vmovaps [rsp+0xD0], xmm14
000073ef1c5de492  vmovaps [rsp+0xE0], xmm15
000073ef1c5de49b  sub rsp, 0x30
000073ef1c5de49f  movaps [rsp], xmm5
000073ef1c5de4a3  movaps [rsp+0x10], xmm6
000073ef1c5de4a8  movaps [rsp+0x20], xmm3
000073ef1c5de4ad  lea rdi, [rsp]
000073ef1c5de4b1  mov esi, 0x00
000073ef1c5de4b6  mov rax, 0x56F25E118530
000073ef1c5de4c0  call rax
000073ef1c5de4c2  movaps xmm5, [rsp]
000073ef1c5de4c6  add rsp, 0x30
000073ef1c5de4ca  vmovaps xmm0, [rsp]
000073ef1c5de4cf  vmovaps xmm1, [rsp+0x10]
000073ef1c5de4d5  vmovaps xmm2, [rsp+0x20]
000073ef1c5de4db  vmovaps xmm3, [rsp+0x30]
000073ef1c5de4e1  vmovaps xmm4, [rsp+0x40]
000073ef1c5de4e7  vmovaps xmm6, [rsp+0x50]
000073ef1c5de4ed  vmovaps xmm7, [rsp+0x60]
000073ef1c5de4f3  vmovaps xmm8, [rsp+0x70]
000073ef1c5de4f9  vmovaps xmm9, [rsp+0x80]
000073ef1c5de502  vmovaps xmm10, [rsp+0x90]
000073ef1c5de50b  vmovaps xmm11, [rsp+0xA0]
000073ef1c5de514  vmovaps xmm12, [rsp+0xB0]
000073ef1c5de51d  vmovaps xmm13, [rsp+0xC0]
000073ef1c5de526  vmovaps xmm14, [rsp+0xD0]
000073ef1c5de52f  vmovaps xmm15, [rsp+0xE0]
000073ef1c5de538  add rsp, 0xF0
000073ef1c5de53f  pop r11
000073ef1c5de541  pop r10
000073ef1c5de543  pop r9
000073ef1c5de545  pop r8
000073ef1c5de547  pop rsi
000073ef1c5de548  pop rdi
000073ef1c5de549  pop rdx
000073ef1c5de54a  pop rcx
000073ef1c5de54b  pop rax
000073ef1c5de54c  add rsp, 0x08
000073ef1c5de550  jmp 0x000073EF1C5DC13A
000073ef1c5de555  sub rsp, 0x08
000073ef1c5de559  push rax
000073ef1c5de55a  push rcx
000073ef1c5de55b  push rdx
000073ef1c5de55c  push rdi
000073ef1c5de55d  push rsi
000073ef1c5de55e  push r8
000073ef1c5de560  push r9
000073ef1c5de562  push r10
000073ef1c5de564  push r11
000073ef1c5de566  sub rsp, 0xF0
000073ef1c5de56d  vmovaps [rsp], xmm0
000073ef1c5de572  vmovaps [rsp+0x10], xmm1
000073ef1c5de578  vmovaps [rsp+0x20], xmm2
000073ef1c5de57e  vmovaps [rsp+0x30], xmm3
000073ef1c5de584  vmovaps [rsp+0x40], xmm4
000073ef1c5de58a  vmovaps [rsp+0x50], xmm5
000073ef1c5de590  vmovaps [rsp+0x60], xmm7
000073ef1c5de596  vmovaps [rsp+0x70], xmm8
000073ef1c5de59c  vmovaps [rsp+0x80], xmm9
000073ef1c5de5a5  vmovaps [rsp+0x90], xmm10
000073ef1c5de5ae  vmovaps [rsp+0xA0], xmm11
000073ef1c5de5b7  vmovaps [rsp+0xB0], xmm12
000073ef1c5de5c0  vmovaps [rsp+0xC0], xmm13
000073ef1c5de5c9  vmovaps [rsp+0xD0], xmm14
000073ef1c5de5d2  vmovaps [rsp+0xE0], xmm15
000073ef1c5de5db  sub rsp, 0x30
000073ef1c5de5df  movaps [rsp], xmm6
000073ef1c5de5e3  movaps [rsp+0x10], xmm9
000073ef1c5de5e9  movaps [rsp+0x20], xmm1
000073ef1c5de5ee  lea rdi, [rsp]
000073ef1c5de5f2  mov esi, 0x00
000073ef1c5de5f7  mov rax, 0x56F25E118530
000073ef1c5de601  call rax
000073ef1c5de603  movaps xmm6, [rsp]
000073ef1c5de607  add rsp, 0x30
000073ef1c5de60b  vmovaps xmm0, [rsp]
000073ef1c5de610  vmovaps xmm1, [rsp+0x10]
000073ef1c5de616  vmovaps xmm2, [rsp+0x20]
000073ef1c5de61c  vmovaps xmm3, [rsp+0x30]
000073ef1c5de622  vmovaps xmm4, [rsp+0x40]
000073ef1c5de628  vmovaps xmm5, [rsp+0x50]
000073ef1c5de62e  vmovaps xmm7, [rsp+0x60]
000073ef1c5de634  vmovaps xmm8, [rsp+0x70]
000073ef1c5de63a  vmovaps xmm9, [rsp+0x80]
000073ef1c5de643  vmovaps xmm10, [rsp+0x90]
000073ef1c5de64c  vmovaps xmm11, [rsp+0xA0]
000073ef1c5de655  vmovaps xmm12, [rsp+0xB0]
000073ef1c5de65e  vmovaps xmm13, [rsp+0xC0]
000073ef1c5de667  vmovaps xmm14, [rsp+0xD0]
000073ef1c5de670  vmovaps xmm15, [rsp+0xE0]
000073ef1c5de679  add rsp, 0xF0
000073ef1c5de680  pop r11
000073ef1c5de682  pop r10
000073ef1c5de684  pop r9
000073ef1c5de686  pop r8
000073ef1c5de688  pop rsi
000073ef1c5de689  pop rdi
000073ef1c5de68a  pop rdx
000073ef1c5de68b  pop rcx
000073ef1c5de68c  pop rax
000073ef1c5de68d  add rsp, 0x08
000073ef1c5de691  jmp 0x000073EF1C5DC15E
000073ef1c5de696  sub rsp, 0x08
000073ef1c5de69a  push rax
000073ef1c5de69b  push rcx
000073ef1c5de69c  push rdx
000073ef1c5de69d  push rdi
000073ef1c5de69e  push rsi
000073ef1c5de69f  push r8
000073ef1c5de6a1  push r9
000073ef1c5de6a3  push r10
000073ef1c5de6a5  push r11
000073ef1c5de6a7  sub rsp, 0xF0
000073ef1c5de6ae  vmovaps [rsp], xmm0
000073ef1c5de6b3  vmovaps [rsp+0x10], xmm1
000073ef1c5de6b9  vmovaps [rsp+0x20], xmm2
000073ef1c5de6bf  vmovaps [rsp+0x30], xmm3
000073ef1c5de6c5  vmovaps [rsp+0x40], xmm4
000073ef1c5de6cb  vmovaps [rsp+0x50], xmm5
000073ef1c5de6d1  vmovaps [rsp+0x60], xmm6
000073ef1c5de6d7  vmovaps [rsp+0x70], xmm7
000073ef1c5de6dd  vmovaps [rsp+0x80], xmm8
000073ef1c5de6e6  vmovaps [rsp+0x90], xmm10
000073ef1c5de6ef  vmovaps [rsp+0xA0], xmm11
000073ef1c5de6f8  vmovaps [rsp+0xB0], xmm12
000073ef1c5de701  vmovaps [rsp+0xC0], xmm13
000073ef1c5de70a  vmovaps [rsp+0xD0], xmm14
000073ef1c5de713  vmovaps [rsp+0xE0], xmm15
000073ef1c5de71c  sub rsp, 0x30
000073ef1c5de720  movaps [rsp], xmm9
000073ef1c5de725  movaps [rsp+0x10], xmm3
000073ef1c5de72a  movaps [rsp+0x20], xmm1
000073ef1c5de72f  lea rdi, [rsp]
000073ef1c5de733  mov esi, 0x00
000073ef1c5de738  mov rax, 0x56F25E118530
000073ef1c5de742  call rax
000073ef1c5de744  movaps xmm9, [rsp]
000073ef1c5de749  add rsp, 0x30
000073ef1c5de74d  vmovaps xmm0, [rsp]
000073ef1c5de752  vmovaps xmm1, [rsp+0x10]
000073ef1c5de758  vmovaps xmm2, [rsp+0x20]
000073ef1c5de75e  vmovaps xmm3, [rsp+0x30]
000073ef1c5de764  vmovaps xmm4, [rsp+0x40]
000073ef1c5de76a  vmovaps xmm5, [rsp+0x50]
000073ef1c5de770  vmovaps xmm6, [rsp+0x60]
000073ef1c5de776  vmovaps xmm7, [rsp+0x70]
000073ef1c5de77c  vmovaps xmm8, [rsp+0x80]
000073ef1c5de785  vmovaps xmm10, [rsp+0x90]
000073ef1c5de78e  vmovaps xmm11, [rsp+0xA0]
000073ef1c5de797  vmovaps xmm12, [rsp+0xB0]
000073ef1c5de7a0  vmovaps xmm13, [rsp+0xC0]
000073ef1c5de7a9  vmovaps xmm14, [rsp+0xD0]
000073ef1c5de7b2  vmovaps xmm15, [rsp+0xE0]
000073ef1c5de7bb  add rsp, 0xF0
000073ef1c5de7c2  pop r11
000073ef1c5de7c4  pop r10
000073ef1c5de7c6  pop r9
000073ef1c5de7c8  pop r8
000073ef1c5de7ca  pop rsi
000073ef1c5de7cb  pop rdi
000073ef1c5de7cc  pop rdx
000073ef1c5de7cd  pop rcx
000073ef1c5de7ce  pop rax
000073ef1c5de7cf  add rsp, 0x08
000073ef1c5de7d3  jmp 0x000073EF1C5DC1AA
000073ef1c5de7d8  call 0x000073EF1C4B52F0
000073ef1c5de7dd  jmp 0x000073EF1C5DC1B7
000073ef1c5de7e2  sub rsp, 0x08
000073ef1c5de7e6  push rax
000073ef1c5de7e7  push rcx
000073ef1c5de7e8  push rdx
000073ef1c5de7e9  push rdi
000073ef1c5de7ea  push rsi
000073ef1c5de7eb  push r8
000073ef1c5de7ed  push r9
000073ef1c5de7ef  push r10
000073ef1c5de7f1  push r11
000073ef1c5de7f3  sub rsp, 0xF0
000073ef1c5de7fa  vmovaps [rsp], xmm0
000073ef1c5de7ff  vmovaps [rsp+0x10], xmm1
000073ef1c5de805  vmovaps [rsp+0x20], xmm2
000073ef1c5de80b  vmovaps [rsp+0x30], xmm3
000073ef1c5de811  vmovaps [rsp+0x40], xmm4
000073ef1c5de817  vmovaps [rsp+0x50], xmm5
000073ef1c5de81d  vmovaps [rsp+0x60], xmm6
000073ef1c5de823  vmovaps [rsp+0x70], xmm7
000073ef1c5de829  vmovaps [rsp+0x80], xmm8
000073ef1c5de832  vmovaps [rsp+0x90], xmm9
000073ef1c5de83b  vmovaps [rsp+0xA0], xmm10
000073ef1c5de844  vmovaps [rsp+0xB0], xmm11
000073ef1c5de84d  vmovaps [rsp+0xC0], xmm12
000073ef1c5de856  vmovaps [rsp+0xD0], xmm13
000073ef1c5de85f  vmovaps [rsp+0xE0], xmm14
000073ef1c5de868  sub rsp, 0x30
000073ef1c5de86c  movaps [rsp], xmm15
000073ef1c5de871  movaps [rsp+0x10], xmm3
000073ef1c5de876  movaps [rsp+0x20], xmm7
000073ef1c5de87b  lea rdi, [rsp]
000073ef1c5de87f  mov esi, 0x00
000073ef1c5de884  mov rax, 0x56F25E118530
000073ef1c5de88e  call rax
000073ef1c5de890  movaps xmm15, [rsp]
000073ef1c5de895  add rsp, 0x30
000073ef1c5de899  vmovaps xmm0, [rsp]
000073ef1c5de89e  vmovaps xmm1, [rsp+0x10]
000073ef1c5de8a4  vmovaps xmm2, [rsp+0x20]
000073ef1c5de8aa  vmovaps xmm3, [rsp+0x30]
000073ef1c5de8b0  vmovaps xmm4, [rsp+0x40]
000073ef1c5de8b6  vmovaps xmm5, [rsp+0x50]
000073ef1c5de8bc  vmovaps xmm6, [rsp+0x60]
000073ef1c5de8c2  vmovaps xmm7, [rsp+0x70]
000073ef1c5de8c8  vmovaps xmm8, [rsp+0x80]
000073ef1c5de8d1  vmovaps xmm9, [rsp+0x90]
000073ef1c5de8da  vmovaps xmm10, [rsp+0xA0]
000073ef1c5de8e3  vmovaps xmm11, [rsp+0xB0]
000073ef1c5de8ec  vmovaps xmm12, [rsp+0xC0]
000073ef1c5de8f5  vmovaps xmm13, [rsp+0xD0]
000073ef1c5de8fe  vmovaps xmm14, [rsp+0xE0]
000073ef1c5de907  add rsp, 0xF0
000073ef1c5de90e  pop r11
000073ef1c5de910  pop r10
000073ef1c5de912  pop r9
000073ef1c5de914  pop r8
000073ef1c5de916  pop rsi
000073ef1c5de917  pop rdi
000073ef1c5de918  pop rdx
000073ef1c5de919  pop rcx
000073ef1c5de91a  pop rax
000073ef1c5de91b  add rsp, 0x08
000073ef1c5de91f  jmp 0x000073EF1C5DC1E3
000073ef1c5de924  sub rsp, 0x08
000073ef1c5de928  push rax
000073ef1c5de929  push rcx
000073ef1c5de92a  push rdx
000073ef1c5de92b  push rdi
000073ef1c5de92c  push rsi
000073ef1c5de92d  push r8
000073ef1c5de92f  push r9
000073ef1c5de931  push r10
000073ef1c5de933  push r11
000073ef1c5de935  sub rsp, 0xF0
000073ef1c5de93c  vmovaps [rsp], xmm0
000073ef1c5de941  vmovaps [rsp+0x10], xmm1
000073ef1c5de947  vmovaps [rsp+0x20], xmm2
000073ef1c5de94d  vmovaps [rsp+0x30], xmm4
000073ef1c5de953  vmovaps [rsp+0x40], xmm5
000073ef1c5de959  vmovaps [rsp+0x50], xmm6
000073ef1c5de95f  vmovaps [rsp+0x60], xmm7
000073ef1c5de965  vmovaps [rsp+0x70], xmm8
000073ef1c5de96b  vmovaps [rsp+0x80], xmm9
000073ef1c5de974  vmovaps [rsp+0x90], xmm10
000073ef1c5de97d  vmovaps [rsp+0xA0], xmm11
000073ef1c5de986  vmovaps [rsp+0xB0], xmm12
000073ef1c5de98f  vmovaps [rsp+0xC0], xmm13
000073ef1c5de998  vmovaps [rsp+0xD0], xmm14
000073ef1c5de9a1  vmovaps [rsp+0xE0], xmm15
000073ef1c5de9aa  sub rsp, 0x30
000073ef1c5de9ae  movaps [rsp], xmm3
000073ef1c5de9b2  movaps [rsp+0x10], xmm1
000073ef1c5de9b7  movaps [rsp+0x20], xmm15
000073ef1c5de9bd  lea rdi, [rsp]
000073ef1c5de9c1  mov esi, 0x00
000073ef1c5de9c6  mov rax, 0x56F25E118530
000073ef1c5de9d0  call rax
000073ef1c5de9d2  movaps xmm3, [rsp]
000073ef1c5de9d6  add rsp, 0x30
000073ef1c5de9da  vmovaps xmm0, [rsp]
000073ef1c5de9df  vmovaps xmm1, [rsp+0x10]
000073ef1c5de9e5  vmovaps xmm2, [rsp+0x20]
000073ef1c5de9eb  vmovaps xmm4, [rsp+0x30]
000073ef1c5de9f1  vmovaps xmm5, [rsp+0x40]
000073ef1c5de9f7  vmovaps xmm6, [rsp+0x50]
000073ef1c5de9fd  vmovaps xmm7, [rsp+0x60]
000073ef1c5dea03  vmovaps xmm8, [rsp+0x70]
000073ef1c5dea09  vmovaps xmm9, [rsp+0x80]
000073ef1c5dea12  vmovaps xmm10, [rsp+0x90]
000073ef1c5dea1b  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dea24  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dea2d  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dea36  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dea3f  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dea48  add rsp, 0xF0
000073ef1c5dea4f  pop r11
000073ef1c5dea51  pop r10
000073ef1c5dea53  pop r9
000073ef1c5dea55  pop r8
000073ef1c5dea57  pop rsi
000073ef1c5dea58  pop rdi
000073ef1c5dea59  pop rdx
000073ef1c5dea5a  pop rcx
000073ef1c5dea5b  pop rax
000073ef1c5dea5c  add rsp, 0x08
000073ef1c5dea60  jmp 0x000073EF1C5DC272
000073ef1c5dea65  call 0x000073EF1C4B52F0
000073ef1c5dea6a  jmp 0x000073EF1C5DC27C
000073ef1c5dea6f  sub rsp, 0x08
000073ef1c5dea73  push rax
000073ef1c5dea74  push rcx
000073ef1c5dea75  push rdx
000073ef1c5dea76  push rdi
000073ef1c5dea77  push rsi
000073ef1c5dea78  push r8
000073ef1c5dea7a  push r9
000073ef1c5dea7c  push r10
000073ef1c5dea7e  push r11
000073ef1c5dea80  sub rsp, 0xF0
000073ef1c5dea87  vmovaps [rsp], xmm0
000073ef1c5dea8c  vmovaps [rsp+0x10], xmm1
000073ef1c5dea92  vmovaps [rsp+0x20], xmm2
000073ef1c5dea98  vmovaps [rsp+0x30], xmm3
000073ef1c5dea9e  vmovaps [rsp+0x40], xmm4
000073ef1c5deaa4  vmovaps [rsp+0x50], xmm5
000073ef1c5deaaa  vmovaps [rsp+0x60], xmm6
000073ef1c5deab0  vmovaps [rsp+0x70], xmm7
000073ef1c5deab6  vmovaps [rsp+0x80], xmm8
000073ef1c5deabf  vmovaps [rsp+0x90], xmm9
000073ef1c5deac8  vmovaps [rsp+0xA0], xmm10
000073ef1c5dead1  vmovaps [rsp+0xB0], xmm11
000073ef1c5deada  vmovaps [rsp+0xC0], xmm12
000073ef1c5deae3  vmovaps [rsp+0xD0], xmm13
000073ef1c5deaec  vmovaps [rsp+0xE0], xmm14
000073ef1c5deaf5  sub rsp, 0x30
000073ef1c5deaf9  movaps [rsp], xmm15
000073ef1c5deafe  movaps [rsp+0x10], xmm14
000073ef1c5deb04  movaps [rsp+0x20], xmm4
000073ef1c5deb09  lea rdi, [rsp]
000073ef1c5deb0d  mov esi, 0x00
000073ef1c5deb12  mov rax, 0x56F25E118530
000073ef1c5deb1c  call rax
000073ef1c5deb1e  movaps xmm15, [rsp]
000073ef1c5deb23  add rsp, 0x30
000073ef1c5deb27  vmovaps xmm0, [rsp]
000073ef1c5deb2c  vmovaps xmm1, [rsp+0x10]
000073ef1c5deb32  vmovaps xmm2, [rsp+0x20]
000073ef1c5deb38  vmovaps xmm3, [rsp+0x30]
000073ef1c5deb3e  vmovaps xmm4, [rsp+0x40]
000073ef1c5deb44  vmovaps xmm5, [rsp+0x50]
000073ef1c5deb4a  vmovaps xmm6, [rsp+0x60]
000073ef1c5deb50  vmovaps xmm7, [rsp+0x70]
000073ef1c5deb56  vmovaps xmm8, [rsp+0x80]
000073ef1c5deb5f  vmovaps xmm9, [rsp+0x90]
000073ef1c5deb68  vmovaps xmm10, [rsp+0xA0]
000073ef1c5deb71  vmovaps xmm11, [rsp+0xB0]
000073ef1c5deb7a  vmovaps xmm12, [rsp+0xC0]
000073ef1c5deb83  vmovaps xmm13, [rsp+0xD0]
000073ef1c5deb8c  vmovaps xmm14, [rsp+0xE0]
000073ef1c5deb95  add rsp, 0xF0
000073ef1c5deb9c  pop r11
000073ef1c5deb9e  pop r10
000073ef1c5deba0  pop r9
000073ef1c5deba2  pop r8
000073ef1c5deba4  pop rsi
000073ef1c5deba5  pop rdi
000073ef1c5deba6  pop rdx
000073ef1c5deba7  pop rcx
000073ef1c5deba8  pop rax
000073ef1c5deba9  add rsp, 0x08
000073ef1c5debad  jmp 0x000073EF1C5DC2AA
000073ef1c5debb2  sub rsp, 0x08
000073ef1c5debb6  push rax
000073ef1c5debb7  push rcx
000073ef1c5debb8  push rdx
000073ef1c5debb9  push rdi
000073ef1c5debba  push rsi
000073ef1c5debbb  push r8
000073ef1c5debbd  push r9
000073ef1c5debbf  push r10
000073ef1c5debc1  push r11
000073ef1c5debc3  sub rsp, 0xF0
000073ef1c5debca  vmovaps [rsp], xmm0
000073ef1c5debcf  vmovaps [rsp+0x10], xmm1
000073ef1c5debd5  vmovaps [rsp+0x20], xmm2
000073ef1c5debdb  vmovaps [rsp+0x30], xmm3
000073ef1c5debe1  vmovaps [rsp+0x40], xmm4
000073ef1c5debe7  vmovaps [rsp+0x50], xmm5
000073ef1c5debed  vmovaps [rsp+0x60], xmm6
000073ef1c5debf3  vmovaps [rsp+0x70], xmm7
000073ef1c5debf9  vmovaps [rsp+0x80], xmm8
000073ef1c5dec02  vmovaps [rsp+0x90], xmm9
000073ef1c5dec0b  vmovaps [rsp+0xA0], xmm10
000073ef1c5dec14  vmovaps [rsp+0xB0], xmm11
000073ef1c5dec1d  vmovaps [rsp+0xC0], xmm12
000073ef1c5dec26  vmovaps [rsp+0xD0], xmm13
000073ef1c5dec2f  vmovaps [rsp+0xE0], xmm15
000073ef1c5dec38  sub rsp, 0x30
000073ef1c5dec3c  movaps [rsp], xmm14
000073ef1c5dec41  movaps [rsp+0x10], xmm2
000073ef1c5dec46  movaps [rsp+0x20], xmm1
000073ef1c5dec4b  lea rdi, [rsp]
000073ef1c5dec4f  mov esi, 0x00
000073ef1c5dec54  mov rax, 0x56F25E118530
000073ef1c5dec5e  call rax
000073ef1c5dec60  movaps xmm14, [rsp]
000073ef1c5dec65  add rsp, 0x30
000073ef1c5dec69  vmovaps xmm0, [rsp]
000073ef1c5dec6e  vmovaps xmm1, [rsp+0x10]
000073ef1c5dec74  vmovaps xmm2, [rsp+0x20]
000073ef1c5dec7a  vmovaps xmm3, [rsp+0x30]
000073ef1c5dec80  vmovaps xmm4, [rsp+0x40]
000073ef1c5dec86  vmovaps xmm5, [rsp+0x50]
000073ef1c5dec8c  vmovaps xmm6, [rsp+0x60]
000073ef1c5dec92  vmovaps xmm7, [rsp+0x70]
000073ef1c5dec98  vmovaps xmm8, [rsp+0x80]
000073ef1c5deca1  vmovaps xmm9, [rsp+0x90]
000073ef1c5decaa  vmovaps xmm10, [rsp+0xA0]
000073ef1c5decb3  vmovaps xmm11, [rsp+0xB0]
000073ef1c5decbc  vmovaps xmm12, [rsp+0xC0]
000073ef1c5decc5  vmovaps xmm13, [rsp+0xD0]
000073ef1c5decce  vmovaps xmm15, [rsp+0xE0]
000073ef1c5decd7  add rsp, 0xF0
000073ef1c5decde  pop r11
000073ef1c5dece0  pop r10
000073ef1c5dece2  pop r9
000073ef1c5dece4  pop r8
000073ef1c5dece6  pop rsi
000073ef1c5dece7  pop rdi
000073ef1c5dece8  pop rdx
000073ef1c5dece9  pop rcx
000073ef1c5decea  pop rax
000073ef1c5deceb  add rsp, 0x08
000073ef1c5decef  jmp 0x000073EF1C5DC2D0
000073ef1c5decf4  sub rsp, 0x08
000073ef1c5decf8  push rax
000073ef1c5decf9  push rcx
000073ef1c5decfa  push rdx
000073ef1c5decfb  push rdi
000073ef1c5decfc  push rsi
000073ef1c5decfd  push r8
000073ef1c5decff  push r9
000073ef1c5ded01  push r10
000073ef1c5ded03  push r11
000073ef1c5ded05  sub rsp, 0xF0
000073ef1c5ded0c  vmovaps [rsp], xmm0
000073ef1c5ded11  vmovaps [rsp+0x10], xmm2
000073ef1c5ded17  vmovaps [rsp+0x20], xmm3
000073ef1c5ded1d  vmovaps [rsp+0x30], xmm4
000073ef1c5ded23  vmovaps [rsp+0x40], xmm5
000073ef1c5ded29  vmovaps [rsp+0x50], xmm6
000073ef1c5ded2f  vmovaps [rsp+0x60], xmm7
000073ef1c5ded35  vmovaps [rsp+0x70], xmm8
000073ef1c5ded3b  vmovaps [rsp+0x80], xmm9
000073ef1c5ded44  vmovaps [rsp+0x90], xmm10
000073ef1c5ded4d  vmovaps [rsp+0xA0], xmm11
000073ef1c5ded56  vmovaps [rsp+0xB0], xmm12
000073ef1c5ded5f  vmovaps [rsp+0xC0], xmm13
000073ef1c5ded68  vmovaps [rsp+0xD0], xmm14
000073ef1c5ded71  vmovaps [rsp+0xE0], xmm15
000073ef1c5ded7a  sub rsp, 0x30
000073ef1c5ded7e  movaps [rsp], xmm1
000073ef1c5ded82  movaps [rsp+0x10], xmm4
000073ef1c5ded87  movaps [rsp+0x20], xmm9
000073ef1c5ded8d  lea rdi, [rsp]
000073ef1c5ded91  mov esi, 0x00
000073ef1c5ded96  mov rax, 0x56F25E118530
000073ef1c5deda0  call rax
000073ef1c5deda2  movaps xmm1, [rsp]
000073ef1c5deda6  add rsp, 0x30
000073ef1c5dedaa  vmovaps xmm0, [rsp]
000073ef1c5dedaf  vmovaps xmm2, [rsp+0x10]
000073ef1c5dedb5  vmovaps xmm3, [rsp+0x20]
000073ef1c5dedbb  vmovaps xmm4, [rsp+0x30]
000073ef1c5dedc1  vmovaps xmm5, [rsp+0x40]
000073ef1c5dedc7  vmovaps xmm6, [rsp+0x50]
000073ef1c5dedcd  vmovaps xmm7, [rsp+0x60]
000073ef1c5dedd3  vmovaps xmm8, [rsp+0x70]
000073ef1c5dedd9  vmovaps xmm9, [rsp+0x80]
000073ef1c5dede2  vmovaps xmm10, [rsp+0x90]
000073ef1c5dedeb  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dedf4  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dedfd  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dee06  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dee0f  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dee18  add rsp, 0xF0
000073ef1c5dee1f  pop r11
000073ef1c5dee21  pop r10
000073ef1c5dee23  pop r9
000073ef1c5dee25  pop r8
000073ef1c5dee27  pop rsi
000073ef1c5dee28  pop rdi
000073ef1c5dee29  pop rdx
000073ef1c5dee2a  pop rcx
000073ef1c5dee2b  pop rax
000073ef1c5dee2c  add rsp, 0x08
000073ef1c5dee30  jmp 0x000073EF1C5DC2EE
000073ef1c5dee35  sub rsp, 0x08
000073ef1c5dee39  push rax
000073ef1c5dee3a  push rcx
000073ef1c5dee3b  push rdx
000073ef1c5dee3c  push rdi
000073ef1c5dee3d  push rsi
000073ef1c5dee3e  push r8
000073ef1c5dee40  push r9
000073ef1c5dee42  push r10
000073ef1c5dee44  push r11
000073ef1c5dee46  sub rsp, 0xF0
000073ef1c5dee4d  vmovaps [rsp], xmm0
000073ef1c5dee52  vmovaps [rsp+0x10], xmm1
000073ef1c5dee58  vmovaps [rsp+0x20], xmm2
000073ef1c5dee5e  vmovaps [rsp+0x30], xmm3
000073ef1c5dee64  vmovaps [rsp+0x40], xmm5
000073ef1c5dee6a  vmovaps [rsp+0x50], xmm6
000073ef1c5dee70  vmovaps [rsp+0x60], xmm7
000073ef1c5dee76  vmovaps [rsp+0x70], xmm8
000073ef1c5dee7c  vmovaps [rsp+0x80], xmm9
000073ef1c5dee85  vmovaps [rsp+0x90], xmm10
000073ef1c5dee8e  vmovaps [rsp+0xA0], xmm11
000073ef1c5dee97  vmovaps [rsp+0xB0], xmm12
000073ef1c5deea0  vmovaps [rsp+0xC0], xmm13
000073ef1c5deea9  vmovaps [rsp+0xD0], xmm14
000073ef1c5deeb2  vmovaps [rsp+0xE0], xmm15
000073ef1c5deebb  sub rsp, 0x30
000073ef1c5deebf  movaps [rsp], xmm4
000073ef1c5deec3  movaps [rsp+0x10], xmm2
000073ef1c5deec8  movaps [rsp+0x20], xmm9
000073ef1c5deece  lea rdi, [rsp]
000073ef1c5deed2  mov esi, 0x00
000073ef1c5deed7  mov rax, 0x56F25E118530
000073ef1c5deee1  call rax
000073ef1c5deee3  movaps xmm4, [rsp]
000073ef1c5deee7  add rsp, 0x30
000073ef1c5deeeb  vmovaps xmm0, [rsp]
000073ef1c5deef0  vmovaps xmm1, [rsp+0x10]
000073ef1c5deef6  vmovaps xmm2, [rsp+0x20]
000073ef1c5deefc  vmovaps xmm3, [rsp+0x30]
000073ef1c5def02  vmovaps xmm5, [rsp+0x40]
000073ef1c5def08  vmovaps xmm6, [rsp+0x50]
000073ef1c5def0e  vmovaps xmm7, [rsp+0x60]
000073ef1c5def14  vmovaps xmm8, [rsp+0x70]
000073ef1c5def1a  vmovaps xmm9, [rsp+0x80]
000073ef1c5def23  vmovaps xmm10, [rsp+0x90]
000073ef1c5def2c  vmovaps xmm11, [rsp+0xA0]
000073ef1c5def35  vmovaps xmm12, [rsp+0xB0]
000073ef1c5def3e  vmovaps xmm13, [rsp+0xC0]
000073ef1c5def47  vmovaps xmm14, [rsp+0xD0]
000073ef1c5def50  vmovaps xmm15, [rsp+0xE0]
000073ef1c5def59  add rsp, 0xF0
000073ef1c5def60  pop r11
000073ef1c5def62  pop r10
000073ef1c5def64  pop r9
000073ef1c5def66  pop r8
000073ef1c5def68  pop rsi
000073ef1c5def69  pop rdi
000073ef1c5def6a  pop rdx
000073ef1c5def6b  pop rcx
000073ef1c5def6c  pop rax
000073ef1c5def6d  add rsp, 0x08
000073ef1c5def71  jmp 0x000073EF1C5DC31E
000073ef1c5def76  sub rsp, 0x08
000073ef1c5def7a  push rax
000073ef1c5def7b  push rcx
000073ef1c5def7c  push rdx
000073ef1c5def7d  push rdi
000073ef1c5def7e  push rsi
000073ef1c5def7f  push r8
000073ef1c5def81  push r9
000073ef1c5def83  push r10
000073ef1c5def85  push r11
000073ef1c5def87  sub rsp, 0xF0
000073ef1c5def8e  vmovaps [rsp], xmm0
000073ef1c5def93  vmovaps [rsp+0x10], xmm1
000073ef1c5def99  vmovaps [rsp+0x20], xmm2
000073ef1c5def9f  vmovaps [rsp+0x30], xmm3
000073ef1c5defa5  vmovaps [rsp+0x40], xmm4
000073ef1c5defab  vmovaps [rsp+0x50], xmm5
000073ef1c5defb1  vmovaps [rsp+0x60], xmm6
000073ef1c5defb7  vmovaps [rsp+0x70], xmm7
000073ef1c5defbd  vmovaps [rsp+0x80], xmm8
000073ef1c5defc6  vmovaps [rsp+0x90], xmm10
000073ef1c5defcf  vmovaps [rsp+0xA0], xmm11
000073ef1c5defd8  vmovaps [rsp+0xB0], xmm12
000073ef1c5defe1  vmovaps [rsp+0xC0], xmm13
000073ef1c5defea  vmovaps [rsp+0xD0], xmm14
000073ef1c5deff3  vmovaps [rsp+0xE0], xmm15
000073ef1c5deffc  sub rsp, 0x30
000073ef1c5df000  movaps [rsp], xmm9
000073ef1c5df005  movaps [rsp+0x10], xmm2
000073ef1c5df00a  movaps [rsp+0x20], xmm1
000073ef1c5df00f  lea rdi, [rsp]
000073ef1c5df013  mov esi, 0x00
000073ef1c5df018  mov rax, 0x56F25E118530
000073ef1c5df022  call rax
000073ef1c5df024  movaps xmm9, [rsp]
000073ef1c5df029  add rsp, 0x30
000073ef1c5df02d  vmovaps xmm0, [rsp]
000073ef1c5df032  vmovaps xmm1, [rsp+0x10]
000073ef1c5df038  vmovaps xmm2, [rsp+0x20]
000073ef1c5df03e  vmovaps xmm3, [rsp+0x30]
000073ef1c5df044  vmovaps xmm4, [rsp+0x40]
000073ef1c5df04a  vmovaps xmm5, [rsp+0x50]
000073ef1c5df050  vmovaps xmm6, [rsp+0x60]
000073ef1c5df056  vmovaps xmm7, [rsp+0x70]
000073ef1c5df05c  vmovaps xmm8, [rsp+0x80]
000073ef1c5df065  vmovaps xmm10, [rsp+0x90]
000073ef1c5df06e  vmovaps xmm11, [rsp+0xA0]
000073ef1c5df077  vmovaps xmm12, [rsp+0xB0]
000073ef1c5df080  vmovaps xmm13, [rsp+0xC0]
000073ef1c5df089  vmovaps xmm14, [rsp+0xD0]
000073ef1c5df092  vmovaps xmm15, [rsp+0xE0]
000073ef1c5df09b  add rsp, 0xF0
000073ef1c5df0a2  pop r11
000073ef1c5df0a4  pop r10
000073ef1c5df0a6  pop r9
000073ef1c5df0a8  pop r8
000073ef1c5df0aa  pop rsi
000073ef1c5df0ab  pop rdi
000073ef1c5df0ac  pop rdx
000073ef1c5df0ad  pop rcx
000073ef1c5df0ae  pop rax
000073ef1c5df0af  add rsp, 0x08
000073ef1c5df0b3  jmp 0x000073EF1C5DC354
000073ef1c5df0b8  sub rsp, 0x08
000073ef1c5df0bc  push rax
000073ef1c5df0bd  push rcx
000073ef1c5df0be  push rdx
000073ef1c5df0bf  push rdi
000073ef1c5df0c0  push rsi
000073ef1c5df0c1  push r8
000073ef1c5df0c3  push r9
000073ef1c5df0c5  push r10
000073ef1c5df0c7  push r11
000073ef1c5df0c9  sub rsp, 0xF0
000073ef1c5df0d0  vmovaps [rsp], xmm0
000073ef1c5df0d5  vmovaps [rsp+0x10], xmm2
000073ef1c5df0db  vmovaps [rsp+0x20], xmm3
000073ef1c5df0e1  vmovaps [rsp+0x30], xmm4
000073ef1c5df0e7  vmovaps [rsp+0x40], xmm5
000073ef1c5df0ed  vmovaps [rsp+0x50], xmm6
000073ef1c5df0f3  vmovaps [rsp+0x60], xmm7
000073ef1c5df0f9  vmovaps [rsp+0x70], xmm8
000073ef1c5df0ff  vmovaps [rsp+0x80], xmm9
000073ef1c5df108  vmovaps [rsp+0x90], xmm10
000073ef1c5df111  vmovaps [rsp+0xA0], xmm11
000073ef1c5df11a  vmovaps [rsp+0xB0], xmm12
000073ef1c5df123  vmovaps [rsp+0xC0], xmm13
000073ef1c5df12c  vmovaps [rsp+0xD0], xmm14
000073ef1c5df135  vmovaps [rsp+0xE0], xmm15
000073ef1c5df13e  sub rsp, 0x30
000073ef1c5df142  movaps [rsp], xmm1
000073ef1c5df146  movaps [rsp+0x10], xmm15
000073ef1c5df14c  movaps [rsp+0x20], xmm6
000073ef1c5df151  lea rdi, [rsp]
000073ef1c5df155  mov esi, 0x00
000073ef1c5df15a  mov rax, 0x56F25E118530
000073ef1c5df164  call rax
000073ef1c5df166  movaps xmm1, [rsp]
000073ef1c5df16a  add rsp, 0x30
000073ef1c5df16e  vmovaps xmm0, [rsp]
000073ef1c5df173  vmovaps xmm2, [rsp+0x10]
000073ef1c5df179  vmovaps xmm3, [rsp+0x20]
000073ef1c5df17f  vmovaps xmm4, [rsp+0x30]
000073ef1c5df185  vmovaps xmm5, [rsp+0x40]
000073ef1c5df18b  vmovaps xmm6, [rsp+0x50]
000073ef1c5df191  vmovaps xmm7, [rsp+0x60]
000073ef1c5df197  vmovaps xmm8, [rsp+0x70]
000073ef1c5df19d  vmovaps xmm9, [rsp+0x80]
000073ef1c5df1a6  vmovaps xmm10, [rsp+0x90]
000073ef1c5df1af  vmovaps xmm11, [rsp+0xA0]
000073ef1c5df1b8  vmovaps xmm12, [rsp+0xB0]
000073ef1c5df1c1  vmovaps xmm13, [rsp+0xC0]
000073ef1c5df1ca  vmovaps xmm14, [rsp+0xD0]
000073ef1c5df1d3  vmovaps xmm15, [rsp+0xE0]
000073ef1c5df1dc  add rsp, 0xF0
000073ef1c5df1e3  pop r11
000073ef1c5df1e5  pop r10
000073ef1c5df1e7  pop r9
000073ef1c5df1e9  pop r8
000073ef1c5df1eb  pop rsi
000073ef1c5df1ec  pop rdi
000073ef1c5df1ed  pop rdx
000073ef1c5df1ee  pop rcx
000073ef1c5df1ef  pop rax
000073ef1c5df1f0  add rsp, 0x08
000073ef1c5df1f4  jmp 0x000073EF1C5DC375
000073ef1c5df1f9  sub rsp, 0x08
000073ef1c5df1fd  push rax
000073ef1c5df1fe  push rcx
000073ef1c5df1ff  push rdx
000073ef1c5df200  push rdi
000073ef1c5df201  push rsi
000073ef1c5df202  push r8
000073ef1c5df204  push r9
000073ef1c5df206  push r10
000073ef1c5df208  push r11
000073ef1c5df20a  sub rsp, 0xF0
000073ef1c5df211  vmovaps [rsp], xmm0
000073ef1c5df216  vmovaps [rsp+0x10], xmm1
000073ef1c5df21c  vmovaps [rsp+0x20], xmm2
000073ef1c5df222  vmovaps [rsp+0x30], xmm3
000073ef1c5df228  vmovaps [rsp+0x40], xmm4
000073ef1c5df22e  vmovaps [rsp+0x50], xmm5
000073ef1c5df234  vmovaps [rsp+0x60], xmm6
000073ef1c5df23a  vmovaps [rsp+0x70], xmm7
000073ef1c5df240  vmovaps [rsp+0x80], xmm8
000073ef1c5df249  vmovaps [rsp+0x90], xmm9
000073ef1c5df252  vmovaps [rsp+0xA0], xmm10
000073ef1c5df25b  vmovaps [rsp+0xB0], xmm11
000073ef1c5df264  vmovaps [rsp+0xC0], xmm12
000073ef1c5df26d  vmovaps [rsp+0xD0], xmm13
000073ef1c5df276  vmovaps [rsp+0xE0], xmm14
000073ef1c5df27f  sub rsp, 0x30
000073ef1c5df283  movaps [rsp], xmm15
000073ef1c5df288  movaps [rsp+0x10], xmm5
000073ef1c5df28d  movaps [rsp+0x20], xmm3
000073ef1c5df292  lea rdi, [rsp]
000073ef1c5df296  mov esi, 0x00
000073ef1c5df29b  mov rax, 0x56F25E118530
000073ef1c5df2a5  call rax
000073ef1c5df2a7  movaps xmm15, [rsp]
000073ef1c5df2ac  add rsp, 0x30
000073ef1c5df2b0  vmovaps xmm0, [rsp]
000073ef1c5df2b5  vmovaps xmm1, [rsp+0x10]
000073ef1c5df2bb  vmovaps xmm2, [rsp+0x20]
000073ef1c5df2c1  vmovaps xmm3, [rsp+0x30]
000073ef1c5df2c7  vmovaps xmm4, [rsp+0x40]
000073ef1c5df2cd  vmovaps xmm5, [rsp+0x50]
000073ef1c5df2d3  vmovaps xmm6, [rsp+0x60]
000073ef1c5df2d9  vmovaps xmm7, [rsp+0x70]
000073ef1c5df2df  vmovaps xmm8, [rsp+0x80]
000073ef1c5df2e8  vmovaps xmm9, [rsp+0x90]
000073ef1c5df2f1  vmovaps xmm10, [rsp+0xA0]
000073ef1c5df2fa  vmovaps xmm11, [rsp+0xB0]
000073ef1c5df303  vmovaps xmm12, [rsp+0xC0]
000073ef1c5df30c  vmovaps xmm13, [rsp+0xD0]
000073ef1c5df315  vmovaps xmm14, [rsp+0xE0]
000073ef1c5df31e  add rsp, 0xF0
000073ef1c5df325  pop r11
000073ef1c5df327  pop r10
000073ef1c5df329  pop r9
000073ef1c5df32b  pop r8
000073ef1c5df32d  pop rsi
000073ef1c5df32e  pop rdi
000073ef1c5df32f  pop rdx
000073ef1c5df330  pop rcx
000073ef1c5df331  pop rax
000073ef1c5df332  add rsp, 0x08
000073ef1c5df336  jmp 0x000073EF1C5DC38F
000073ef1c5df33b  sub rsp, 0x08
000073ef1c5df33f  push rax
000073ef1c5df340  push rcx
000073ef1c5df341  push rdx
000073ef1c5df342  push rdi
000073ef1c5df343  push rsi
000073ef1c5df344  push r8
000073ef1c5df346  push r9
000073ef1c5df348  push r10
000073ef1c5df34a  push r11
000073ef1c5df34c  sub rsp, 0xF0
000073ef1c5df353  vmovaps [rsp], xmm0
000073ef1c5df358  vmovaps [rsp+0x10], xmm1
000073ef1c5df35e  vmovaps [rsp+0x20], xmm2
000073ef1c5df364  vmovaps [rsp+0x30], xmm3
000073ef1c5df36a  vmovaps [rsp+0x40], xmm4
000073ef1c5df370  vmovaps [rsp+0x50], xmm6
000073ef1c5df376  vmovaps [rsp+0x60], xmm7
000073ef1c5df37c  vmovaps [rsp+0x70], xmm8
000073ef1c5df382  vmovaps [rsp+0x80], xmm9
000073ef1c5df38b  vmovaps [rsp+0x90], xmm10
000073ef1c5df394  vmovaps [rsp+0xA0], xmm11
000073ef1c5df39d  vmovaps [rsp+0xB0], xmm12
000073ef1c5df3a6  vmovaps [rsp+0xC0], xmm13
000073ef1c5df3af  vmovaps [rsp+0xD0], xmm14
000073ef1c5df3b8  vmovaps [rsp+0xE0], xmm15
000073ef1c5df3c1  sub rsp, 0x30
000073ef1c5df3c5  movaps [rsp], xmm5
000073ef1c5df3c9  movaps [rsp+0x10], xmm8
000073ef1c5df3cf  movaps [rsp+0x20], xmm6
000073ef1c5df3d4  lea rdi, [rsp]
000073ef1c5df3d8  mov esi, 0x00
000073ef1c5df3dd  mov rax, 0x56F25E118530
000073ef1c5df3e7  call rax
000073ef1c5df3e9  movaps xmm5, [rsp]
000073ef1c5df3ed  add rsp, 0x30
000073ef1c5df3f1  vmovaps xmm0, [rsp]
000073ef1c5df3f6  vmovaps xmm1, [rsp+0x10]
000073ef1c5df3fc  vmovaps xmm2, [rsp+0x20]
000073ef1c5df402  vmovaps xmm3, [rsp+0x30]
000073ef1c5df408  vmovaps xmm4, [rsp+0x40]
000073ef1c5df40e  vmovaps xmm6, [rsp+0x50]
000073ef1c5df414  vmovaps xmm7, [rsp+0x60]
000073ef1c5df41a  vmovaps xmm8, [rsp+0x70]
000073ef1c5df420  vmovaps xmm9, [rsp+0x80]
000073ef1c5df429  vmovaps xmm10, [rsp+0x90]
000073ef1c5df432  vmovaps xmm11, [rsp+0xA0]
000073ef1c5df43b  vmovaps xmm12, [rsp+0xB0]
000073ef1c5df444  vmovaps xmm13, [rsp+0xC0]
000073ef1c5df44d  vmovaps xmm14, [rsp+0xD0]
000073ef1c5df456  vmovaps xmm15, [rsp+0xE0]
000073ef1c5df45f  add rsp, 0xF0
000073ef1c5df466  pop r11
000073ef1c5df468  pop r10
000073ef1c5df46a  pop r9
000073ef1c5df46c  pop r8
000073ef1c5df46e  pop rsi
000073ef1c5df46f  pop rdi
000073ef1c5df470  pop rdx
000073ef1c5df471  pop rcx
000073ef1c5df472  pop rax
000073ef1c5df473  add rsp, 0x08
000073ef1c5df477  jmp 0x000073EF1C5DC3B3
000073ef1c5df47c  sub rsp, 0x08
000073ef1c5df480  push rax
000073ef1c5df481  push rcx
000073ef1c5df482  push rdx
000073ef1c5df483  push rdi
000073ef1c5df484  push rsi
000073ef1c5df485  push r8
000073ef1c5df487  push r9
000073ef1c5df489  push r10
000073ef1c5df48b  push r11
000073ef1c5df48d  sub rsp, 0xF0
000073ef1c5df494  vmovaps [rsp], xmm0
000073ef1c5df499  vmovaps [rsp+0x10], xmm1
000073ef1c5df49f  vmovaps [rsp+0x20], xmm2
000073ef1c5df4a5  vmovaps [rsp+0x30], xmm3
000073ef1c5df4ab  vmovaps [rsp+0x40], xmm4
000073ef1c5df4b1  vmovaps [rsp+0x50], xmm5
000073ef1c5df4b7  vmovaps [rsp+0x60], xmm7
000073ef1c5df4bd  vmovaps [rsp+0x70], xmm8
000073ef1c5df4c3  vmovaps [rsp+0x80], xmm9
000073ef1c5df4cc  vmovaps [rsp+0x90], xmm10
000073ef1c5df4d5  vmovaps [rsp+0xA0], xmm11
000073ef1c5df4de  vmovaps [rsp+0xB0], xmm12
000073ef1c5df4e7  vmovaps [rsp+0xC0], xmm13
000073ef1c5df4f0  vmovaps [rsp+0xD0], xmm14
000073ef1c5df4f9  vmovaps [rsp+0xE0], xmm15
000073ef1c5df502  sub rsp, 0x30
000073ef1c5df506  movaps [rsp], xmm6
000073ef1c5df50a  movaps [rsp+0x10], xmm10
000073ef1c5df510  movaps [rsp+0x20], xmm8
000073ef1c5df516  lea rdi, [rsp]
000073ef1c5df51a  mov esi, 0x00
000073ef1c5df51f  mov rax, 0x56F25E118530
000073ef1c5df529  call rax
000073ef1c5df52b  movaps xmm6, [rsp]
000073ef1c5df52f  add rsp, 0x30
000073ef1c5df533  vmovaps xmm0, [rsp]
000073ef1c5df538  vmovaps xmm1, [rsp+0x10]
000073ef1c5df53e  vmovaps xmm2, [rsp+0x20]
000073ef1c5df544  vmovaps xmm3, [rsp+0x30]
000073ef1c5df54a  vmovaps xmm4, [rsp+0x40]
000073ef1c5df550  vmovaps xmm5, [rsp+0x50]
000073ef1c5df556  vmovaps xmm7, [rsp+0x60]
000073ef1c5df55c  vmovaps xmm8, [rsp+0x70]
000073ef1c5df562  vmovaps xmm9, [rsp+0x80]
000073ef1c5df56b  vmovaps xmm10, [rsp+0x90]
000073ef1c5df574  vmovaps xmm11, [rsp+0xA0]
000073ef1c5df57d  vmovaps xmm12, [rsp+0xB0]
000073ef1c5df586  vmovaps xmm13, [rsp+0xC0]
000073ef1c5df58f  vmovaps xmm14, [rsp+0xD0]
000073ef1c5df598  vmovaps xmm15, [rsp+0xE0]
000073ef1c5df5a1  add rsp, 0xF0
000073ef1c5df5a8  pop r11
000073ef1c5df5aa  pop r10
000073ef1c5df5ac  pop r9
000073ef1c5df5ae  pop r8
000073ef1c5df5b0  pop rsi
000073ef1c5df5b1  pop rdi
000073ef1c5df5b2  pop rdx
000073ef1c5df5b3  pop rcx
000073ef1c5df5b4  pop rax
000073ef1c5df5b5  add rsp, 0x08
000073ef1c5df5b9  jmp 0x000073EF1C5DC3D8
000073ef1c5df5be  sub rsp, 0x08
000073ef1c5df5c2  push rax
000073ef1c5df5c3  push rcx
000073ef1c5df5c4  push rdx
000073ef1c5df5c5  push rdi
000073ef1c5df5c6  push rsi
000073ef1c5df5c7  push r8
000073ef1c5df5c9  push r9
000073ef1c5df5cb  push r10
000073ef1c5df5cd  push r11
000073ef1c5df5cf  sub rsp, 0xF0
000073ef1c5df5d6  vmovaps [rsp], xmm0
000073ef1c5df5db  vmovaps [rsp+0x10], xmm1
000073ef1c5df5e1  vmovaps [rsp+0x20], xmm2
000073ef1c5df5e7  vmovaps [rsp+0x30], xmm3
000073ef1c5df5ed  vmovaps [rsp+0x40], xmm4
000073ef1c5df5f3  vmovaps [rsp+0x50], xmm5
000073ef1c5df5f9  vmovaps [rsp+0x60], xmm6
000073ef1c5df5ff  vmovaps [rsp+0x70], xmm7
000073ef1c5df605  vmovaps [rsp+0x80], xmm8
000073ef1c5df60e  vmovaps [rsp+0x90], xmm9
000073ef1c5df617  vmovaps [rsp+0xA0], xmm11
000073ef1c5df620  vmovaps [rsp+0xB0], xmm12
000073ef1c5df629  vmovaps [rsp+0xC0], xmm13
000073ef1c5df632  vmovaps [rsp+0xD0], xmm14
000073ef1c5df63b  vmovaps [rsp+0xE0], xmm15
000073ef1c5df644  sub rsp, 0x30
000073ef1c5df648  movaps [rsp], xmm10
000073ef1c5df64d  movaps [rsp+0x10], xmm8
000073ef1c5df653  movaps [rsp+0x20], xmm14
000073ef1c5df659  lea rdi, [rsp]
000073ef1c5df65d  mov esi, 0x00
000073ef1c5df662  mov rax, 0x56F25E118530
000073ef1c5df66c  call rax
000073ef1c5df66e  movaps xmm10, [rsp]
000073ef1c5df673  add rsp, 0x30
000073ef1c5df677  vmovaps xmm0, [rsp]
000073ef1c5df67c  vmovaps xmm1, [rsp+0x10]
000073ef1c5df682  vmovaps xmm2, [rsp+0x20]
000073ef1c5df688  vmovaps xmm3, [rsp+0x30]
000073ef1c5df68e  vmovaps xmm4, [rsp+0x40]
000073ef1c5df694  vmovaps xmm5, [rsp+0x50]
000073ef1c5df69a  vmovaps xmm6, [rsp+0x60]
000073ef1c5df6a0  vmovaps xmm7, [rsp+0x70]
000073ef1c5df6a6  vmovaps xmm8, [rsp+0x80]
000073ef1c5df6af  vmovaps xmm9, [rsp+0x90]
000073ef1c5df6b8  vmovaps xmm11, [rsp+0xA0]
000073ef1c5df6c1  vmovaps xmm12, [rsp+0xB0]
000073ef1c5df6ca  vmovaps xmm13, [rsp+0xC0]
000073ef1c5df6d3  vmovaps xmm14, [rsp+0xD0]
000073ef1c5df6dc  vmovaps xmm15, [rsp+0xE0]
000073ef1c5df6e5  add rsp, 0xF0
000073ef1c5df6ec  pop r11
000073ef1c5df6ee  pop r10
000073ef1c5df6f0  pop r9
000073ef1c5df6f2  pop r8
000073ef1c5df6f4  pop rsi
000073ef1c5df6f5  pop rdi
000073ef1c5df6f6  pop rdx
000073ef1c5df6f7  pop rcx
000073ef1c5df6f8  pop rax
000073ef1c5df6f9  add rsp, 0x08
000073ef1c5df6fd  jmp 0x000073EF1C5DC3F8
000073ef1c5df702  sub rsp, 0x08
000073ef1c5df706  push rax
000073ef1c5df707  push rcx
000073ef1c5df708  push rdx
000073ef1c5df709  push rdi
000073ef1c5df70a  push rsi
000073ef1c5df70b  push r8
000073ef1c5df70d  push r9
000073ef1c5df70f  push r10
000073ef1c5df711  push r11
000073ef1c5df713  sub rsp, 0xF0
000073ef1c5df71a  vmovaps [rsp], xmm0
000073ef1c5df71f  vmovaps [rsp+0x10], xmm1
000073ef1c5df725  vmovaps [rsp+0x20], xmm2
000073ef1c5df72b  vmovaps [rsp+0x30], xmm3
000073ef1c5df731  vmovaps [rsp+0x40], xmm4
000073ef1c5df737  vmovaps [rsp+0x50], xmm5
000073ef1c5df73d  vmovaps [rsp+0x60], xmm6
000073ef1c5df743  vmovaps [rsp+0x70], xmm7
000073ef1c5df749  vmovaps [rsp+0x80], xmm8
000073ef1c5df752  vmovaps [rsp+0x90], xmm9
000073ef1c5df75b  vmovaps [rsp+0xA0], xmm10
000073ef1c5df764  vmovaps [rsp+0xB0], xmm11
000073ef1c5df76d  vmovaps [rsp+0xC0], xmm12
000073ef1c5df776  vmovaps [rsp+0xD0], xmm13
000073ef1c5df77f  vmovaps [rsp+0xE0], xmm15
000073ef1c5df788  sub rsp, 0x30
000073ef1c5df78c  movaps [rsp], xmm14
000073ef1c5df791  movaps [rsp+0x10], xmm8
000073ef1c5df797  movaps [rsp+0x20], xmm4
000073ef1c5df79c  lea rdi, [rsp]
000073ef1c5df7a0  mov esi, 0x00
000073ef1c5df7a5  mov rax, 0x56F25E118530
000073ef1c5df7af  call rax
000073ef1c5df7b1  movaps xmm14, [rsp]
000073ef1c5df7b6  add rsp, 0x30
000073ef1c5df7ba  vmovaps xmm0, [rsp]
000073ef1c5df7bf  vmovaps xmm1, [rsp+0x10]
000073ef1c5df7c5  vmovaps xmm2, [rsp+0x20]
000073ef1c5df7cb  vmovaps xmm3, [rsp+0x30]
000073ef1c5df7d1  vmovaps xmm4, [rsp+0x40]
000073ef1c5df7d7  vmovaps xmm5, [rsp+0x50]
000073ef1c5df7dd  vmovaps xmm6, [rsp+0x60]
000073ef1c5df7e3  vmovaps xmm7, [rsp+0x70]
000073ef1c5df7e9  vmovaps xmm8, [rsp+0x80]
000073ef1c5df7f2  vmovaps xmm9, [rsp+0x90]
000073ef1c5df7fb  vmovaps xmm10, [rsp+0xA0]
000073ef1c5df804  vmovaps xmm11, [rsp+0xB0]
000073ef1c5df80d  vmovaps xmm12, [rsp+0xC0]
000073ef1c5df816  vmovaps xmm13, [rsp+0xD0]
000073ef1c5df81f  vmovaps xmm15, [rsp+0xE0]
000073ef1c5df828  add rsp, 0xF0
000073ef1c5df82f  pop r11
000073ef1c5df831  pop r10
000073ef1c5df833  pop r9
000073ef1c5df835  pop r8
000073ef1c5df837  pop rsi
000073ef1c5df838  pop rdi
000073ef1c5df839  pop rdx
000073ef1c5df83a  pop rcx
000073ef1c5df83b  pop rax
000073ef1c5df83c  add rsp, 0x08
000073ef1c5df840  jmp 0x000073EF1C5DC418
000073ef1c5df845  sub rsp, 0x08
000073ef1c5df849  push rax
000073ef1c5df84a  push rcx
000073ef1c5df84b  push rdx
000073ef1c5df84c  push rdi
000073ef1c5df84d  push rsi
000073ef1c5df84e  push r8
000073ef1c5df850  push r9
000073ef1c5df852  push r10
000073ef1c5df854  push r11
000073ef1c5df856  sub rsp, 0xF0
000073ef1c5df85d  vmovaps [rsp], xmm0
000073ef1c5df862  vmovaps [rsp+0x10], xmm1
000073ef1c5df868  vmovaps [rsp+0x20], xmm2
000073ef1c5df86e  vmovaps [rsp+0x30], xmm3
000073ef1c5df874  vmovaps [rsp+0x40], xmm5
000073ef1c5df87a  vmovaps [rsp+0x50], xmm6
000073ef1c5df880  vmovaps [rsp+0x60], xmm7
000073ef1c5df886  vmovaps [rsp+0x70], xmm8
000073ef1c5df88c  vmovaps [rsp+0x80], xmm9
000073ef1c5df895  vmovaps [rsp+0x90], xmm10
000073ef1c5df89e  vmovaps [rsp+0xA0], xmm11
000073ef1c5df8a7  vmovaps [rsp+0xB0], xmm12
000073ef1c5df8b0  vmovaps [rsp+0xC0], xmm13
000073ef1c5df8b9  vmovaps [rsp+0xD0], xmm14
000073ef1c5df8c2  vmovaps [rsp+0xE0], xmm15
000073ef1c5df8cb  sub rsp, 0x30
000073ef1c5df8cf  movaps [rsp], xmm4
000073ef1c5df8d3  movaps [rsp+0x10], xmm13
000073ef1c5df8d9  movaps [rsp+0x20], xmm8
000073ef1c5df8df  lea rdi, [rsp]
000073ef1c5df8e3  mov esi, 0x00
000073ef1c5df8e8  mov rax, 0x56F25E118530
000073ef1c5df8f2  call rax
000073ef1c5df8f4  movaps xmm4, [rsp]
000073ef1c5df8f8  add rsp, 0x30
000073ef1c5df8fc  vmovaps xmm0, [rsp]
000073ef1c5df901  vmovaps xmm1, [rsp+0x10]
000073ef1c5df907  vmovaps xmm2, [rsp+0x20]
000073ef1c5df90d  vmovaps xmm3, [rsp+0x30]
000073ef1c5df913  vmovaps xmm5, [rsp+0x40]
000073ef1c5df919  vmovaps xmm6, [rsp+0x50]
000073ef1c5df91f  vmovaps xmm7, [rsp+0x60]
000073ef1c5df925  vmovaps xmm8, [rsp+0x70]
000073ef1c5df92b  vmovaps xmm9, [rsp+0x80]
000073ef1c5df934  vmovaps xmm10, [rsp+0x90]
000073ef1c5df93d  vmovaps xmm11, [rsp+0xA0]
000073ef1c5df946  vmovaps xmm12, [rsp+0xB0]
000073ef1c5df94f  vmovaps xmm13, [rsp+0xC0]
000073ef1c5df958  vmovaps xmm14, [rsp+0xD0]
000073ef1c5df961  vmovaps xmm15, [rsp+0xE0]
000073ef1c5df96a  add rsp, 0xF0
000073ef1c5df971  pop r11
000073ef1c5df973  pop r10
000073ef1c5df975  pop r9
000073ef1c5df977  pop r8
000073ef1c5df979  pop rsi
000073ef1c5df97a  pop rdi
000073ef1c5df97b  pop rdx
000073ef1c5df97c  pop rcx
000073ef1c5df97d  pop rax
000073ef1c5df97e  add rsp, 0x08
000073ef1c5df982  jmp 0x000073EF1C5DC43D
000073ef1c5df987  sub rsp, 0x08
000073ef1c5df98b  push rax
000073ef1c5df98c  push rcx
000073ef1c5df98d  push rdx
000073ef1c5df98e  push rdi
000073ef1c5df98f  push rsi
000073ef1c5df990  push r8
000073ef1c5df992  push r9
000073ef1c5df994  push r10
000073ef1c5df996  push r11
000073ef1c5df998  sub rsp, 0xF0
000073ef1c5df99f  vmovaps [rsp], xmm0
000073ef1c5df9a4  vmovaps [rsp+0x10], xmm1
000073ef1c5df9aa  vmovaps [rsp+0x20], xmm2
000073ef1c5df9b0  vmovaps [rsp+0x30], xmm3
000073ef1c5df9b6  vmovaps [rsp+0x40], xmm4
000073ef1c5df9bc  vmovaps [rsp+0x50], xmm5
000073ef1c5df9c2  vmovaps [rsp+0x60], xmm6
000073ef1c5df9c8  vmovaps [rsp+0x70], xmm7
000073ef1c5df9ce  vmovaps [rsp+0x80], xmm8
000073ef1c5df9d7  vmovaps [rsp+0x90], xmm9
000073ef1c5df9e0  vmovaps [rsp+0xA0], xmm10
000073ef1c5df9e9  vmovaps [rsp+0xB0], xmm11
000073ef1c5df9f2  vmovaps [rsp+0xC0], xmm12
000073ef1c5df9fb  vmovaps [rsp+0xD0], xmm14
000073ef1c5dfa04  vmovaps [rsp+0xE0], xmm15
000073ef1c5dfa0d  sub rsp, 0x30
000073ef1c5dfa11  movaps [rsp], xmm13
000073ef1c5dfa16  movaps [rsp+0x10], xmm15
000073ef1c5dfa1c  movaps [rsp+0x20], xmm9
000073ef1c5dfa22  lea rdi, [rsp]
000073ef1c5dfa26  mov esi, 0x00
000073ef1c5dfa2b  mov rax, 0x56F25E118530
000073ef1c5dfa35  call rax
000073ef1c5dfa37  movaps xmm13, [rsp]
000073ef1c5dfa3c  add rsp, 0x30
000073ef1c5dfa40  vmovaps xmm0, [rsp]
000073ef1c5dfa45  vmovaps xmm1, [rsp+0x10]
000073ef1c5dfa4b  vmovaps xmm2, [rsp+0x20]
000073ef1c5dfa51  vmovaps xmm3, [rsp+0x30]
000073ef1c5dfa57  vmovaps xmm4, [rsp+0x40]
000073ef1c5dfa5d  vmovaps xmm5, [rsp+0x50]
000073ef1c5dfa63  vmovaps xmm6, [rsp+0x60]
000073ef1c5dfa69  vmovaps xmm7, [rsp+0x70]
000073ef1c5dfa6f  vmovaps xmm8, [rsp+0x80]
000073ef1c5dfa78  vmovaps xmm9, [rsp+0x90]
000073ef1c5dfa81  vmovaps xmm10, [rsp+0xA0]
000073ef1c5dfa8a  vmovaps xmm11, [rsp+0xB0]
000073ef1c5dfa93  vmovaps xmm12, [rsp+0xC0]
000073ef1c5dfa9c  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dfaa5  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dfaae  add rsp, 0xF0
000073ef1c5dfab5  pop r11
000073ef1c5dfab7  pop r10
000073ef1c5dfab9  pop r9
000073ef1c5dfabb  pop r8
000073ef1c5dfabd  pop rsi
000073ef1c5dfabe  pop rdi
000073ef1c5dfabf  pop rdx
000073ef1c5dfac0  pop rcx
000073ef1c5dfac1  pop rax
000073ef1c5dfac2  add rsp, 0x08
000073ef1c5dfac6  jmp 0x000073EF1C5DC458
000073ef1c5dfacb  sub rsp, 0x08
000073ef1c5dfacf  push rax
000073ef1c5dfad0  push rcx
000073ef1c5dfad1  push rdx
000073ef1c5dfad2  push rdi
000073ef1c5dfad3  push rsi
000073ef1c5dfad4  push r8
000073ef1c5dfad6  push r9
000073ef1c5dfad8  push r10
000073ef1c5dfada  push r11
000073ef1c5dfadc  sub rsp, 0xF0
000073ef1c5dfae3  vmovaps [rsp], xmm0
000073ef1c5dfae8  vmovaps [rsp+0x10], xmm1
000073ef1c5dfaee  vmovaps [rsp+0x20], xmm2
000073ef1c5dfaf4  vmovaps [rsp+0x30], xmm3
000073ef1c5dfafa  vmovaps [rsp+0x40], xmm4
000073ef1c5dfb00  vmovaps [rsp+0x50], xmm5
000073ef1c5dfb06  vmovaps [rsp+0x60], xmm6
000073ef1c5dfb0c  vmovaps [rsp+0x70], xmm7
000073ef1c5dfb12  vmovaps [rsp+0x80], xmm8
000073ef1c5dfb1b  vmovaps [rsp+0x90], xmm9
000073ef1c5dfb24  vmovaps [rsp+0xA0], xmm10
000073ef1c5dfb2d  vmovaps [rsp+0xB0], xmm11
000073ef1c5dfb36  vmovaps [rsp+0xC0], xmm12
000073ef1c5dfb3f  vmovaps [rsp+0xD0], xmm13
000073ef1c5dfb48  vmovaps [rsp+0xE0], xmm14
000073ef1c5dfb51  sub rsp, 0x30
000073ef1c5dfb55  movaps [rsp], xmm15
000073ef1c5dfb5a  movaps [rsp+0x10], xmm1
000073ef1c5dfb5f  movaps [rsp+0x20], xmm5
000073ef1c5dfb64  lea rdi, [rsp]
000073ef1c5dfb68  mov esi, 0x00
000073ef1c5dfb6d  mov rax, 0x56F25E118530
000073ef1c5dfb77  call rax
000073ef1c5dfb79  movaps xmm15, [rsp]
000073ef1c5dfb7e  add rsp, 0x30
000073ef1c5dfb82  vmovaps xmm0, [rsp]
000073ef1c5dfb87  vmovaps xmm1, [rsp+0x10]
000073ef1c5dfb8d  vmovaps xmm2, [rsp+0x20]
000073ef1c5dfb93  vmovaps xmm3, [rsp+0x30]
000073ef1c5dfb99  vmovaps xmm4, [rsp+0x40]
000073ef1c5dfb9f  vmovaps xmm5, [rsp+0x50]
000073ef1c5dfba5  vmovaps xmm6, [rsp+0x60]
000073ef1c5dfbab  vmovaps xmm7, [rsp+0x70]
000073ef1c5dfbb1  vmovaps xmm8, [rsp+0x80]
000073ef1c5dfbba  vmovaps xmm9, [rsp+0x90]
000073ef1c5dfbc3  vmovaps xmm10, [rsp+0xA0]
000073ef1c5dfbcc  vmovaps xmm11, [rsp+0xB0]
000073ef1c5dfbd5  vmovaps xmm12, [rsp+0xC0]
000073ef1c5dfbde  vmovaps xmm13, [rsp+0xD0]
000073ef1c5dfbe7  vmovaps xmm14, [rsp+0xE0]
000073ef1c5dfbf0  add rsp, 0xF0
000073ef1c5dfbf7  pop r11
000073ef1c5dfbf9  pop r10
000073ef1c5dfbfb  pop r9
000073ef1c5dfbfd  pop r8
000073ef1c5dfbff  pop rsi
000073ef1c5dfc00  pop rdi
000073ef1c5dfc01  pop rdx
000073ef1c5dfc02  pop rcx
000073ef1c5dfc03  pop rax
000073ef1c5dfc04  add rsp, 0x08
000073ef1c5dfc08  jmp 0x000073EF1C5DC473
000073ef1c5dfc0d  call 0x000073EF1C4B52F0
000073ef1c5dfc12  jmp 0x000073EF1C5DC4CE
000073ef1c5dfc17  sub rsp, 0x08
000073ef1c5dfc1b  push rax
000073ef1c5dfc1c  push rcx
000073ef1c5dfc1d  push rdx
000073ef1c5dfc1e  push rdi
000073ef1c5dfc1f  push rsi
000073ef1c5dfc20  push r8
000073ef1c5dfc22  push r9
000073ef1c5dfc24  push r10
000073ef1c5dfc26  push r11
000073ef1c5dfc28  sub rsp, 0xF0
000073ef1c5dfc2f  vmovaps [rsp], xmm0
000073ef1c5dfc34  vmovaps [rsp+0x10], xmm1
000073ef1c5dfc3a  vmovaps [rsp+0x20], xmm2
000073ef1c5dfc40  vmovaps [rsp+0x30], xmm3
000073ef1c5dfc46  vmovaps [rsp+0x40], xmm4
000073ef1c5dfc4c  vmovaps [rsp+0x50], xmm5
000073ef1c5dfc52  vmovaps [rsp+0x60], xmm6
000073ef1c5dfc58  vmovaps [rsp+0x70], xmm7
000073ef1c5dfc5e  vmovaps [rsp+0x80], xmm8
000073ef1c5dfc67  vmovaps [rsp+0x90], xmm10
000073ef1c5dfc70  vmovaps [rsp+0xA0], xmm11
000073ef1c5dfc79  vmovaps [rsp+0xB0], xmm12
000073ef1c5dfc82  vmovaps [rsp+0xC0], xmm13
000073ef1c5dfc8b  vmovaps [rsp+0xD0], xmm14
000073ef1c5dfc94  vmovaps [rsp+0xE0], xmm15
000073ef1c5dfc9d  sub rsp, 0x30
000073ef1c5dfca1  movaps [rsp], xmm9
000073ef1c5dfca6  movaps [rsp+0x10], xmm8
000073ef1c5dfcac  movaps [rsp+0x20], xmm11
000073ef1c5dfcb2  lea rdi, [rsp]
000073ef1c5dfcb6  mov esi, 0x00
000073ef1c5dfcbb  mov rax, 0x56F25E118530
000073ef1c5dfcc5  call rax
000073ef1c5dfcc7  movaps xmm9, [rsp]
000073ef1c5dfccc  add rsp, 0x30
000073ef1c5dfcd0  vmovaps xmm0, [rsp]
000073ef1c5dfcd5  vmovaps xmm1, [rsp+0x10]
000073ef1c5dfcdb  vmovaps xmm2, [rsp+0x20]
000073ef1c5dfce1  vmovaps xmm3, [rsp+0x30]
000073ef1c5dfce7  vmovaps xmm4, [rsp+0x40]
000073ef1c5dfced  vmovaps xmm5, [rsp+0x50]
000073ef1c5dfcf3  vmovaps xmm6, [rsp+0x60]
000073ef1c5dfcf9  vmovaps xmm7, [rsp+0x70]
000073ef1c5dfcff  vmovaps xmm8, [rsp+0x80]
000073ef1c5dfd08  vmovaps xmm10, [rsp+0x90]
000073ef1c5dfd11  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dfd1a  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dfd23  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dfd2c  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dfd35  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dfd3e  add rsp, 0xF0
000073ef1c5dfd45  pop r11
000073ef1c5dfd47  pop r10
000073ef1c5dfd49  pop r9
000073ef1c5dfd4b  pop r8
000073ef1c5dfd4d  pop rsi
000073ef1c5dfd4e  pop rdi
000073ef1c5dfd4f  pop rdx
000073ef1c5dfd50  pop rcx
000073ef1c5dfd51  pop rax
000073ef1c5dfd52  add rsp, 0x08
000073ef1c5dfd56  jmp 0x000073EF1C5DC505
000073ef1c5dfd5b  sub rsp, 0x08
000073ef1c5dfd5f  push rax
000073ef1c5dfd60  push rcx
000073ef1c5dfd61  push rdx
000073ef1c5dfd62  push rdi
000073ef1c5dfd63  push rsi
000073ef1c5dfd64  push r8
000073ef1c5dfd66  push r9
000073ef1c5dfd68  push r10
000073ef1c5dfd6a  push r11
000073ef1c5dfd6c  sub rsp, 0xF0
000073ef1c5dfd73  vmovaps [rsp], xmm0
000073ef1c5dfd78  vmovaps [rsp+0x10], xmm1
000073ef1c5dfd7e  vmovaps [rsp+0x20], xmm2
000073ef1c5dfd84  vmovaps [rsp+0x30], xmm3
000073ef1c5dfd8a  vmovaps [rsp+0x40], xmm4
000073ef1c5dfd90  vmovaps [rsp+0x50], xmm5
000073ef1c5dfd96  vmovaps [rsp+0x60], xmm6
000073ef1c5dfd9c  vmovaps [rsp+0x70], xmm7
000073ef1c5dfda2  vmovaps [rsp+0x80], xmm8
000073ef1c5dfdab  vmovaps [rsp+0x90], xmm9
000073ef1c5dfdb4  vmovaps [rsp+0xA0], xmm10
000073ef1c5dfdbd  vmovaps [rsp+0xB0], xmm12
000073ef1c5dfdc6  vmovaps [rsp+0xC0], xmm13
000073ef1c5dfdcf  vmovaps [rsp+0xD0], xmm14
000073ef1c5dfdd8  vmovaps [rsp+0xE0], xmm15
000073ef1c5dfde1  sub rsp, 0x30
000073ef1c5dfde5  movaps [rsp], xmm11
000073ef1c5dfdea  movaps [rsp+0x10], xmm10
000073ef1c5dfdf0  movaps [rsp+0x20], xmm6
000073ef1c5dfdf5  lea rdi, [rsp]
000073ef1c5dfdf9  mov esi, 0x00
000073ef1c5dfdfe  mov rax, 0x56F25E118530
000073ef1c5dfe08  call rax
000073ef1c5dfe0a  movaps xmm11, [rsp]
000073ef1c5dfe0f  add rsp, 0x30
000073ef1c5dfe13  vmovaps xmm0, [rsp]
000073ef1c5dfe18  vmovaps xmm1, [rsp+0x10]
000073ef1c5dfe1e  vmovaps xmm2, [rsp+0x20]
000073ef1c5dfe24  vmovaps xmm3, [rsp+0x30]
000073ef1c5dfe2a  vmovaps xmm4, [rsp+0x40]
000073ef1c5dfe30  vmovaps xmm5, [rsp+0x50]
000073ef1c5dfe36  vmovaps xmm6, [rsp+0x60]
000073ef1c5dfe3c  vmovaps xmm7, [rsp+0x70]
000073ef1c5dfe42  vmovaps xmm8, [rsp+0x80]
000073ef1c5dfe4b  vmovaps xmm9, [rsp+0x90]
000073ef1c5dfe54  vmovaps xmm10, [rsp+0xA0]
000073ef1c5dfe5d  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dfe66  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dfe6f  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dfe78  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dfe81  add rsp, 0xF0
000073ef1c5dfe88  pop r11
000073ef1c5dfe8a  pop r10
000073ef1c5dfe8c  pop r9
000073ef1c5dfe8e  pop r8
000073ef1c5dfe90  pop rsi
000073ef1c5dfe91  pop rdi
000073ef1c5dfe92  pop rdx
000073ef1c5dfe93  pop rcx
000073ef1c5dfe94  pop rax
000073ef1c5dfe95  add rsp, 0x08
000073ef1c5dfe99  jmp 0x000073EF1C5DC520
000073ef1c5dfe9e  sub rsp, 0x08
000073ef1c5dfea2  push rax
000073ef1c5dfea3  push rcx
000073ef1c5dfea4  push rdx
000073ef1c5dfea5  push rdi
000073ef1c5dfea6  push rsi
000073ef1c5dfea7  push r8
000073ef1c5dfea9  push r9
000073ef1c5dfeab  push r10
000073ef1c5dfead  push r11
000073ef1c5dfeaf  sub rsp, 0xF0
000073ef1c5dfeb6  vmovaps [rsp], xmm0
000073ef1c5dfebb  vmovaps [rsp+0x10], xmm1
000073ef1c5dfec1  vmovaps [rsp+0x20], xmm2
000073ef1c5dfec7  vmovaps [rsp+0x30], xmm3
000073ef1c5dfecd  vmovaps [rsp+0x40], xmm4
000073ef1c5dfed3  vmovaps [rsp+0x50], xmm5
000073ef1c5dfed9  vmovaps [rsp+0x60], xmm6
000073ef1c5dfedf  vmovaps [rsp+0x70], xmm7
000073ef1c5dfee5  vmovaps [rsp+0x80], xmm8
000073ef1c5dfeee  vmovaps [rsp+0x90], xmm9
000073ef1c5dfef7  vmovaps [rsp+0xA0], xmm11
000073ef1c5dff00  vmovaps [rsp+0xB0], xmm12
000073ef1c5dff09  vmovaps [rsp+0xC0], xmm13
000073ef1c5dff12  vmovaps [rsp+0xD0], xmm14
000073ef1c5dff1b  vmovaps [rsp+0xE0], xmm15
000073ef1c5dff24  sub rsp, 0x30
000073ef1c5dff28  movaps [rsp], xmm10
000073ef1c5dff2d  movaps [rsp+0x10], xmm14
000073ef1c5dff33  movaps [rsp+0x20], xmm4
000073ef1c5dff38  lea rdi, [rsp]
000073ef1c5dff3c  mov esi, 0x00
000073ef1c5dff41  mov rax, 0x56F25E118530
000073ef1c5dff4b  call rax
000073ef1c5dff4d  movaps xmm10, [rsp]
000073ef1c5dff52  add rsp, 0x30
000073ef1c5dff56  vmovaps xmm0, [rsp]
000073ef1c5dff5b  vmovaps xmm1, [rsp+0x10]
000073ef1c5dff61  vmovaps xmm2, [rsp+0x20]
000073ef1c5dff67  vmovaps xmm3, [rsp+0x30]
000073ef1c5dff6d  vmovaps xmm4, [rsp+0x40]
000073ef1c5dff73  vmovaps xmm5, [rsp+0x50]
000073ef1c5dff79  vmovaps xmm6, [rsp+0x60]
000073ef1c5dff7f  vmovaps xmm7, [rsp+0x70]
000073ef1c5dff85  vmovaps xmm8, [rsp+0x80]
000073ef1c5dff8e  vmovaps xmm9, [rsp+0x90]
000073ef1c5dff97  vmovaps xmm11, [rsp+0xA0]
000073ef1c5dffa0  vmovaps xmm12, [rsp+0xB0]
000073ef1c5dffa9  vmovaps xmm13, [rsp+0xC0]
000073ef1c5dffb2  vmovaps xmm14, [rsp+0xD0]
000073ef1c5dffbb  vmovaps xmm15, [rsp+0xE0]
000073ef1c5dffc4  add rsp, 0xF0
000073ef1c5dffcb  pop r11
000073ef1c5dffcd  pop r10
000073ef1c5dffcf  pop r9
000073ef1c5dffd1  pop r8
000073ef1c5dffd3  pop rsi
000073ef1c5dffd4  pop rdi
000073ef1c5dffd5  pop rdx
000073ef1c5dffd6  pop rcx
000073ef1c5dffd7  pop rax
000073ef1c5dffd8  add rsp, 0x08
000073ef1c5dffdc  jmp 0x000073EF1C5DC53B
000073ef1c5dffe1  sub rsp, 0x08
000073ef1c5dffe5  push rax
000073ef1c5dffe6  push rcx
000073ef1c5dffe7  push rdx
000073ef1c5dffe8  push rdi
000073ef1c5dffe9  push rsi
000073ef1c5dffea  push r8
000073ef1c5dffec  push r9
000073ef1c5dffee  push r10
000073ef1c5dfff0  push r11
000073ef1c5dfff2  sub rsp, 0xF0
000073ef1c5dfff9  vmovaps [rsp], xmm0
000073ef1c5dfffe  vmovaps [rsp+0x10], xmm1
000073ef1c5e0004  vmovaps [rsp+0x20], xmm2
000073ef1c5e000a  vmovaps [rsp+0x30], xmm3
000073ef1c5e0010  vmovaps [rsp+0x40], xmm4
000073ef1c5e0016  vmovaps [rsp+0x50], xmm5
000073ef1c5e001c  vmovaps [rsp+0x60], xmm6
000073ef1c5e0022  vmovaps [rsp+0x70], xmm7
000073ef1c5e0028  vmovaps [rsp+0x80], xmm9
000073ef1c5e0031  vmovaps [rsp+0x90], xmm10
000073ef1c5e003a  vmovaps [rsp+0xA0], xmm11
000073ef1c5e0043  vmovaps [rsp+0xB0], xmm12
000073ef1c5e004c  vmovaps [rsp+0xC0], xmm13
000073ef1c5e0055  vmovaps [rsp+0xD0], xmm14
000073ef1c5e005e  vmovaps [rsp+0xE0], xmm15
000073ef1c5e0067  sub rsp, 0x30
000073ef1c5e006b  movaps [rsp], xmm8
000073ef1c5e0070  movaps [rsp+0x10], xmm1
000073ef1c5e0075  movaps [rsp+0x20], xmm14
000073ef1c5e007b  lea rdi, [rsp]
000073ef1c5e007f  mov esi, 0x00
000073ef1c5e0084  mov rax, 0x56F25E118530
000073ef1c5e008e  call rax
000073ef1c5e0090  movaps xmm8, [rsp]
000073ef1c5e0095  add rsp, 0x30
000073ef1c5e0099  vmovaps xmm0, [rsp]
000073ef1c5e009e  vmovaps xmm1, [rsp+0x10]
000073ef1c5e00a4  vmovaps xmm2, [rsp+0x20]
000073ef1c5e00aa  vmovaps xmm3, [rsp+0x30]
000073ef1c5e00b0  vmovaps xmm4, [rsp+0x40]
000073ef1c5e00b6  vmovaps xmm5, [rsp+0x50]
000073ef1c5e00bc  vmovaps xmm6, [rsp+0x60]
000073ef1c5e00c2  vmovaps xmm7, [rsp+0x70]
000073ef1c5e00c8  vmovaps xmm9, [rsp+0x80]
000073ef1c5e00d1  vmovaps xmm10, [rsp+0x90]
000073ef1c5e00da  vmovaps xmm11, [rsp+0xA0]
000073ef1c5e00e3  vmovaps xmm12, [rsp+0xB0]
000073ef1c5e00ec  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e00f5  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e00fe  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e0107  add rsp, 0xF0
000073ef1c5e010e  pop r11
000073ef1c5e0110  pop r10
000073ef1c5e0112  pop r9
000073ef1c5e0114  pop r8
000073ef1c5e0116  pop rsi
000073ef1c5e0117  pop rdi
000073ef1c5e0118  pop rdx
000073ef1c5e0119  pop rcx
000073ef1c5e011a  pop rax
000073ef1c5e011b  add rsp, 0x08
000073ef1c5e011f  jmp 0x000073EF1C5DC561
000073ef1c5e0124  sub rsp, 0x08
000073ef1c5e0128  push rax
000073ef1c5e0129  push rcx
000073ef1c5e012a  push rdx
000073ef1c5e012b  push rdi
000073ef1c5e012c  push rsi
000073ef1c5e012d  push r8
000073ef1c5e012f  push r9
000073ef1c5e0131  push r10
000073ef1c5e0133  push r11
000073ef1c5e0135  sub rsp, 0xF0
000073ef1c5e013c  vmovaps [rsp], xmm0
000073ef1c5e0141  vmovaps [rsp+0x10], xmm1
000073ef1c5e0147  vmovaps [rsp+0x20], xmm2
000073ef1c5e014d  vmovaps [rsp+0x30], xmm3
000073ef1c5e0153  vmovaps [rsp+0x40], xmm4
000073ef1c5e0159  vmovaps [rsp+0x50], xmm5
000073ef1c5e015f  vmovaps [rsp+0x60], xmm7
000073ef1c5e0165  vmovaps [rsp+0x70], xmm8
000073ef1c5e016b  vmovaps [rsp+0x80], xmm9
000073ef1c5e0174  vmovaps [rsp+0x90], xmm10
000073ef1c5e017d  vmovaps [rsp+0xA0], xmm11
000073ef1c5e0186  vmovaps [rsp+0xB0], xmm12
000073ef1c5e018f  vmovaps [rsp+0xC0], xmm13
000073ef1c5e0198  vmovaps [rsp+0xD0], xmm14
000073ef1c5e01a1  vmovaps [rsp+0xE0], xmm15
000073ef1c5e01aa  sub rsp, 0x30
000073ef1c5e01ae  movaps [rsp], xmm6
000073ef1c5e01b2  movaps [rsp+0x10], xmm1
000073ef1c5e01b7  movaps [rsp+0x20], xmm14
000073ef1c5e01bd  lea rdi, [rsp]
000073ef1c5e01c1  mov esi, 0x00
000073ef1c5e01c6  mov rax, 0x56F25E118530
000073ef1c5e01d0  call rax
000073ef1c5e01d2  movaps xmm6, [rsp]
000073ef1c5e01d6  add rsp, 0x30
000073ef1c5e01da  vmovaps xmm0, [rsp]
000073ef1c5e01df  vmovaps xmm1, [rsp+0x10]
000073ef1c5e01e5  vmovaps xmm2, [rsp+0x20]
000073ef1c5e01eb  vmovaps xmm3, [rsp+0x30]
000073ef1c5e01f1  vmovaps xmm4, [rsp+0x40]
000073ef1c5e01f7  vmovaps xmm5, [rsp+0x50]
000073ef1c5e01fd  vmovaps xmm7, [rsp+0x60]
000073ef1c5e0203  vmovaps xmm8, [rsp+0x70]
000073ef1c5e0209  vmovaps xmm9, [rsp+0x80]
000073ef1c5e0212  vmovaps xmm10, [rsp+0x90]
000073ef1c5e021b  vmovaps xmm11, [rsp+0xA0]
000073ef1c5e0224  vmovaps xmm12, [rsp+0xB0]
000073ef1c5e022d  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e0236  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e023f  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e0248  add rsp, 0xF0
000073ef1c5e024f  pop r11
000073ef1c5e0251  pop r10
000073ef1c5e0253  pop r9
000073ef1c5e0255  pop r8
000073ef1c5e0257  pop rsi
000073ef1c5e0258  pop rdi
000073ef1c5e0259  pop rdx
000073ef1c5e025a  pop rcx
000073ef1c5e025b  pop rax
000073ef1c5e025c  add rsp, 0x08
000073ef1c5e0260  jmp 0x000073EF1C5DC58D
000073ef1c5e0265  sub rsp, 0x08
000073ef1c5e0269  push rax
000073ef1c5e026a  push rcx
000073ef1c5e026b  push rdx
000073ef1c5e026c  push rdi
000073ef1c5e026d  push rsi
000073ef1c5e026e  push r8
000073ef1c5e0270  push r9
000073ef1c5e0272  push r10
000073ef1c5e0274  push r11
000073ef1c5e0276  sub rsp, 0xF0
000073ef1c5e027d  vmovaps [rsp], xmm0
000073ef1c5e0282  vmovaps [rsp+0x10], xmm1
000073ef1c5e0288  vmovaps [rsp+0x20], xmm2
000073ef1c5e028e  vmovaps [rsp+0x30], xmm3
000073ef1c5e0294  vmovaps [rsp+0x40], xmm4
000073ef1c5e029a  vmovaps [rsp+0x50], xmm5
000073ef1c5e02a0  vmovaps [rsp+0x60], xmm6
000073ef1c5e02a6  vmovaps [rsp+0x70], xmm7
000073ef1c5e02ac  vmovaps [rsp+0x80], xmm8
000073ef1c5e02b5  vmovaps [rsp+0x90], xmm9
000073ef1c5e02be  vmovaps [rsp+0xA0], xmm10
000073ef1c5e02c7  vmovaps [rsp+0xB0], xmm11
000073ef1c5e02d0  vmovaps [rsp+0xC0], xmm12
000073ef1c5e02d9  vmovaps [rsp+0xD0], xmm13
000073ef1c5e02e2  vmovaps [rsp+0xE0], xmm15
000073ef1c5e02eb  sub rsp, 0x30
000073ef1c5e02ef  movaps [rsp], xmm14
000073ef1c5e02f4  movaps [rsp+0x10], xmm12
000073ef1c5e02fa  movaps [rsp+0x20], xmm1
000073ef1c5e02ff  lea rdi, [rsp]
000073ef1c5e0303  mov esi, 0x00
000073ef1c5e0308  mov rax, 0x56F25E118530
000073ef1c5e0312  call rax
000073ef1c5e0314  movaps xmm14, [rsp]
000073ef1c5e0319  add rsp, 0x30
000073ef1c5e031d  vmovaps xmm0, [rsp]
000073ef1c5e0322  vmovaps xmm1, [rsp+0x10]
000073ef1c5e0328  vmovaps xmm2, [rsp+0x20]
000073ef1c5e032e  vmovaps xmm3, [rsp+0x30]
000073ef1c5e0334  vmovaps xmm4, [rsp+0x40]
000073ef1c5e033a  vmovaps xmm5, [rsp+0x50]
000073ef1c5e0340  vmovaps xmm6, [rsp+0x60]
000073ef1c5e0346  vmovaps xmm7, [rsp+0x70]
000073ef1c5e034c  vmovaps xmm8, [rsp+0x80]
000073ef1c5e0355  vmovaps xmm9, [rsp+0x90]
000073ef1c5e035e  vmovaps xmm10, [rsp+0xA0]
000073ef1c5e0367  vmovaps xmm11, [rsp+0xB0]
000073ef1c5e0370  vmovaps xmm12, [rsp+0xC0]
000073ef1c5e0379  vmovaps xmm13, [rsp+0xD0]
000073ef1c5e0382  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e038b  add rsp, 0xF0
000073ef1c5e0392  pop r11
000073ef1c5e0394  pop r10
000073ef1c5e0396  pop r9
000073ef1c5e0398  pop r8
000073ef1c5e039a  pop rsi
000073ef1c5e039b  pop rdi
000073ef1c5e039c  pop rdx
000073ef1c5e039d  pop rcx
000073ef1c5e039e  pop rax
000073ef1c5e039f  add rsp, 0x08
000073ef1c5e03a3  jmp 0x000073EF1C5DC5B3
000073ef1c5e03a8  sub rsp, 0x08
000073ef1c5e03ac  push rax
000073ef1c5e03ad  push rcx
000073ef1c5e03ae  push rdx
000073ef1c5e03af  push rdi
000073ef1c5e03b0  push rsi
000073ef1c5e03b1  push r8
000073ef1c5e03b3  push r9
000073ef1c5e03b5  push r10
000073ef1c5e03b7  push r11
000073ef1c5e03b9  sub rsp, 0xF0
000073ef1c5e03c0  vmovaps [rsp], xmm0
000073ef1c5e03c5  vmovaps [rsp+0x10], xmm2
000073ef1c5e03cb  vmovaps [rsp+0x20], xmm3
000073ef1c5e03d1  vmovaps [rsp+0x30], xmm4
000073ef1c5e03d7  vmovaps [rsp+0x40], xmm5
000073ef1c5e03dd  vmovaps [rsp+0x50], xmm6
000073ef1c5e03e3  vmovaps [rsp+0x60], xmm7
000073ef1c5e03e9  vmovaps [rsp+0x70], xmm8
000073ef1c5e03ef  vmovaps [rsp+0x80], xmm9
000073ef1c5e03f8  vmovaps [rsp+0x90], xmm10
000073ef1c5e0401  vmovaps [rsp+0xA0], xmm11
000073ef1c5e040a  vmovaps [rsp+0xB0], xmm12
000073ef1c5e0413  vmovaps [rsp+0xC0], xmm13
000073ef1c5e041c  vmovaps [rsp+0xD0], xmm14
000073ef1c5e0425  vmovaps [rsp+0xE0], xmm15
000073ef1c5e042e  sub rsp, 0x30
000073ef1c5e0432  movaps [rsp], xmm1
000073ef1c5e0436  movaps [rsp+0x10], xmm13
000073ef1c5e043c  movaps [rsp+0x20], xmm9
000073ef1c5e0442  lea rdi, [rsp]
000073ef1c5e0446  mov esi, 0x00
000073ef1c5e044b  mov rax, 0x56F25E118530
000073ef1c5e0455  call rax
000073ef1c5e0457  movaps xmm1, [rsp]
000073ef1c5e045b  add rsp, 0x30
000073ef1c5e045f  vmovaps xmm0, [rsp]
000073ef1c5e0464  vmovaps xmm2, [rsp+0x10]
000073ef1c5e046a  vmovaps xmm3, [rsp+0x20]
000073ef1c5e0470  vmovaps xmm4, [rsp+0x30]
000073ef1c5e0476  vmovaps xmm5, [rsp+0x40]
000073ef1c5e047c  vmovaps xmm6, [rsp+0x50]
000073ef1c5e0482  vmovaps xmm7, [rsp+0x60]
000073ef1c5e0488  vmovaps xmm8, [rsp+0x70]
000073ef1c5e048e  vmovaps xmm9, [rsp+0x80]
000073ef1c5e0497  vmovaps xmm10, [rsp+0x90]
000073ef1c5e04a0  vmovaps xmm11, [rsp+0xA0]
000073ef1c5e04a9  vmovaps xmm12, [rsp+0xB0]
000073ef1c5e04b2  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e04bb  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e04c4  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e04cd  add rsp, 0xF0
000073ef1c5e04d4  pop r11
000073ef1c5e04d6  pop r10
000073ef1c5e04d8  pop r9
000073ef1c5e04da  pop r8
000073ef1c5e04dc  pop rsi
000073ef1c5e04dd  pop rdi
000073ef1c5e04de  pop rdx
000073ef1c5e04df  pop rcx
000073ef1c5e04e0  pop rax
000073ef1c5e04e1  add rsp, 0x08
000073ef1c5e04e5  jmp 0x000073EF1C5DC5CD
000073ef1c5e04ea  sub rsp, 0x08
000073ef1c5e04ee  push rax
000073ef1c5e04ef  push rcx
000073ef1c5e04f0  push rdx
000073ef1c5e04f1  push rdi
000073ef1c5e04f2  push rsi
000073ef1c5e04f3  push r8
000073ef1c5e04f5  push r9
000073ef1c5e04f7  push r10
000073ef1c5e04f9  push r11
000073ef1c5e04fb  sub rsp, 0xF0
000073ef1c5e0502  vmovaps [rsp], xmm0
000073ef1c5e0507  vmovaps [rsp+0x10], xmm1
000073ef1c5e050d  vmovaps [rsp+0x20], xmm2
000073ef1c5e0513  vmovaps [rsp+0x30], xmm3
000073ef1c5e0519  vmovaps [rsp+0x40], xmm4
000073ef1c5e051f  vmovaps [rsp+0x50], xmm5
000073ef1c5e0525  vmovaps [rsp+0x60], xmm6
000073ef1c5e052b  vmovaps [rsp+0x70], xmm7
000073ef1c5e0531  vmovaps [rsp+0x80], xmm8
000073ef1c5e053a  vmovaps [rsp+0x90], xmm9
000073ef1c5e0543  vmovaps [rsp+0xA0], xmm10
000073ef1c5e054c  vmovaps [rsp+0xB0], xmm11
000073ef1c5e0555  vmovaps [rsp+0xC0], xmm13
000073ef1c5e055e  vmovaps [rsp+0xD0], xmm14
000073ef1c5e0567  vmovaps [rsp+0xE0], xmm15
000073ef1c5e0570  sub rsp, 0x30
000073ef1c5e0574  movaps [rsp], xmm12
000073ef1c5e0579  movaps [rsp+0x10], xmm7
000073ef1c5e057e  movaps [rsp+0x20], xmm13
000073ef1c5e0584  lea rdi, [rsp]
000073ef1c5e0588  mov esi, 0x00
000073ef1c5e058d  mov rax, 0x56F25E118530
000073ef1c5e0597  call rax
000073ef1c5e0599  movaps xmm12, [rsp]
000073ef1c5e059e  add rsp, 0x30
000073ef1c5e05a2  vmovaps xmm0, [rsp]
000073ef1c5e05a7  vmovaps xmm1, [rsp+0x10]
000073ef1c5e05ad  vmovaps xmm2, [rsp+0x20]
000073ef1c5e05b3  vmovaps xmm3, [rsp+0x30]
000073ef1c5e05b9  vmovaps xmm4, [rsp+0x40]
000073ef1c5e05bf  vmovaps xmm5, [rsp+0x50]
000073ef1c5e05c5  vmovaps xmm6, [rsp+0x60]
000073ef1c5e05cb  vmovaps xmm7, [rsp+0x70]
000073ef1c5e05d1  vmovaps xmm8, [rsp+0x80]
000073ef1c5e05da  vmovaps xmm9, [rsp+0x90]
000073ef1c5e05e3  vmovaps xmm10, [rsp+0xA0]
000073ef1c5e05ec  vmovaps xmm11, [rsp+0xB0]
000073ef1c5e05f5  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e05fe  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e0607  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e0610  add rsp, 0xF0
000073ef1c5e0617  pop r11
000073ef1c5e0619  pop r10
000073ef1c5e061b  pop r9
000073ef1c5e061d  pop r8
000073ef1c5e061f  pop rsi
000073ef1c5e0620  pop rdi
000073ef1c5e0621  pop rdx
000073ef1c5e0622  pop rcx
000073ef1c5e0623  pop rax
000073ef1c5e0624  add rsp, 0x08
000073ef1c5e0628  jmp 0x000073EF1C5DC5F4
000073ef1c5e062d  sub rsp, 0x08
000073ef1c5e0631  push rax
000073ef1c5e0632  push rcx
000073ef1c5e0633  push rdx
000073ef1c5e0634  push rdi
000073ef1c5e0635  push rsi
000073ef1c5e0636  push r8
000073ef1c5e0638  push r9
000073ef1c5e063a  push r10
000073ef1c5e063c  push r11
000073ef1c5e063e  sub rsp, 0xF0
000073ef1c5e0645  vmovaps [rsp], xmm0
000073ef1c5e064a  vmovaps [rsp+0x10], xmm1
000073ef1c5e0650  vmovaps [rsp+0x20], xmm2
000073ef1c5e0656  vmovaps [rsp+0x30], xmm3
000073ef1c5e065c  vmovaps [rsp+0x40], xmm4
000073ef1c5e0662  vmovaps [rsp+0x50], xmm5
000073ef1c5e0668  vmovaps [rsp+0x60], xmm6
000073ef1c5e066e  vmovaps [rsp+0x70], xmm7
000073ef1c5e0674  vmovaps [rsp+0x80], xmm8
000073ef1c5e067d  vmovaps [rsp+0x90], xmm9
000073ef1c5e0686  vmovaps [rsp+0xA0], xmm10
000073ef1c5e068f  vmovaps [rsp+0xB0], xmm11
000073ef1c5e0698  vmovaps [rsp+0xC0], xmm12
000073ef1c5e06a1  vmovaps [rsp+0xD0], xmm14
000073ef1c5e06aa  vmovaps [rsp+0xE0], xmm15
000073ef1c5e06b3  sub rsp, 0x30
000073ef1c5e06b7  movaps [rsp], xmm13
000073ef1c5e06bc  movaps [rsp+0x10], xmm15
000073ef1c5e06c2  movaps [rsp+0x20], xmm8
000073ef1c5e06c8  lea rdi, [rsp]
000073ef1c5e06cc  mov esi, 0x00
000073ef1c5e06d1  mov rax, 0x56F25E118530
000073ef1c5e06db  call rax
000073ef1c5e06dd  movaps xmm13, [rsp]
000073ef1c5e06e2  add rsp, 0x30
000073ef1c5e06e6  vmovaps xmm0, [rsp]
000073ef1c5e06eb  vmovaps xmm1, [rsp+0x10]
000073ef1c5e06f1  vmovaps xmm2, [rsp+0x20]
000073ef1c5e06f7  vmovaps xmm3, [rsp+0x30]
000073ef1c5e06fd  vmovaps xmm4, [rsp+0x40]
000073ef1c5e0703  vmovaps xmm5, [rsp+0x50]
000073ef1c5e0709  vmovaps xmm6, [rsp+0x60]
000073ef1c5e070f  vmovaps xmm7, [rsp+0x70]
000073ef1c5e0715  vmovaps xmm8, [rsp+0x80]
000073ef1c5e071e  vmovaps xmm9, [rsp+0x90]
000073ef1c5e0727  vmovaps xmm10, [rsp+0xA0]
000073ef1c5e0730  vmovaps xmm11, [rsp+0xB0]
000073ef1c5e0739  vmovaps xmm12, [rsp+0xC0]
000073ef1c5e0742  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e074b  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e0754  add rsp, 0xF0
000073ef1c5e075b  pop r11
000073ef1c5e075d  pop r10
000073ef1c5e075f  pop r9
000073ef1c5e0761  pop r8
000073ef1c5e0763  pop rsi
000073ef1c5e0764  pop rdi
000073ef1c5e0765  pop rdx
000073ef1c5e0766  pop rcx
000073ef1c5e0767  pop rax
000073ef1c5e0768  add rsp, 0x08
000073ef1c5e076c  jmp 0x000073EF1C5DC60F
000073ef1c5e0771  sub rsp, 0x08
000073ef1c5e0775  push rax
000073ef1c5e0776  push rcx
000073ef1c5e0777  push rdx
000073ef1c5e0778  push rdi
000073ef1c5e0779  push rsi
000073ef1c5e077a  push r8
000073ef1c5e077c  push r9
000073ef1c5e077e  push r10
000073ef1c5e0780  push r11
000073ef1c5e0782  sub rsp, 0xF0
000073ef1c5e0789  vmovaps [rsp], xmm0
000073ef1c5e078e  vmovaps [rsp+0x10], xmm1
000073ef1c5e0794  vmovaps [rsp+0x20], xmm2
000073ef1c5e079a  vmovaps [rsp+0x30], xmm3
000073ef1c5e07a0  vmovaps [rsp+0x40], xmm4
000073ef1c5e07a6  vmovaps [rsp+0x50], xmm5
000073ef1c5e07ac  vmovaps [rsp+0x60], xmm6
000073ef1c5e07b2  vmovaps [rsp+0x70], xmm7
000073ef1c5e07b8  vmovaps [rsp+0x80], xmm9
000073ef1c5e07c1  vmovaps [rsp+0x90], xmm10
000073ef1c5e07ca  vmovaps [rsp+0xA0], xmm11
000073ef1c5e07d3  vmovaps [rsp+0xB0], xmm12
000073ef1c5e07dc  vmovaps [rsp+0xC0], xmm13
000073ef1c5e07e5  vmovaps [rsp+0xD0], xmm14
000073ef1c5e07ee  vmovaps [rsp+0xE0], xmm15
000073ef1c5e07f7  sub rsp, 0x30
000073ef1c5e07fb  movaps [rsp], xmm8
000073ef1c5e0800  movaps [rsp+0x10], xmm15
000073ef1c5e0806  movaps [rsp+0x20], xmm9
000073ef1c5e080c  lea rdi, [rsp]
000073ef1c5e0810  mov esi, 0x00
000073ef1c5e0815  mov rax, 0x56F25E118530
000073ef1c5e081f  call rax
000073ef1c5e0821  movaps xmm8, [rsp]
000073ef1c5e0826  add rsp, 0x30
000073ef1c5e082a  vmovaps xmm0, [rsp]
000073ef1c5e082f  vmovaps xmm1, [rsp+0x10]
000073ef1c5e0835  vmovaps xmm2, [rsp+0x20]
000073ef1c5e083b  vmovaps xmm3, [rsp+0x30]
000073ef1c5e0841  vmovaps xmm4, [rsp+0x40]
000073ef1c5e0847  vmovaps xmm5, [rsp+0x50]
000073ef1c5e084d  vmovaps xmm6, [rsp+0x60]
000073ef1c5e0853  vmovaps xmm7, [rsp+0x70]
000073ef1c5e0859  vmovaps xmm9, [rsp+0x80]
000073ef1c5e0862  vmovaps xmm10, [rsp+0x90]
000073ef1c5e086b  vmovaps xmm11, [rsp+0xA0]
000073ef1c5e0874  vmovaps xmm12, [rsp+0xB0]
000073ef1c5e087d  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e0886  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e088f  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e0898  add rsp, 0xF0
000073ef1c5e089f  pop r11
000073ef1c5e08a1  pop r10
000073ef1c5e08a3  pop r9
000073ef1c5e08a5  pop r8
000073ef1c5e08a7  pop rsi
000073ef1c5e08a8  pop rdi
000073ef1c5e08a9  pop rdx
000073ef1c5e08aa  pop rcx
000073ef1c5e08ab  pop rax
000073ef1c5e08ac  add rsp, 0x08
000073ef1c5e08b0  jmp 0x000073EF1C5DC63D
000073ef1c5e08b5  sub rsp, 0x08
000073ef1c5e08b9  push rax
000073ef1c5e08ba  push rcx
000073ef1c5e08bb  push rdx
000073ef1c5e08bc  push rdi
000073ef1c5e08bd  push rsi
000073ef1c5e08be  push r8
000073ef1c5e08c0  push r9
000073ef1c5e08c2  push r10
000073ef1c5e08c4  push r11
000073ef1c5e08c6  sub rsp, 0xF0
000073ef1c5e08cd  vmovaps [rsp], xmm0
000073ef1c5e08d2  vmovaps [rsp+0x10], xmm1
000073ef1c5e08d8  vmovaps [rsp+0x20], xmm2
000073ef1c5e08de  vmovaps [rsp+0x30], xmm3
000073ef1c5e08e4  vmovaps [rsp+0x40], xmm4
000073ef1c5e08ea  vmovaps [rsp+0x50], xmm5
000073ef1c5e08f0  vmovaps [rsp+0x60], xmm6
000073ef1c5e08f6  vmovaps [rsp+0x70], xmm7
000073ef1c5e08fc  vmovaps [rsp+0x80], xmm8
000073ef1c5e0905  vmovaps [rsp+0x90], xmm9
000073ef1c5e090e  vmovaps [rsp+0xA0], xmm10
000073ef1c5e0917  vmovaps [rsp+0xB0], xmm11
000073ef1c5e0920  vmovaps [rsp+0xC0], xmm12
000073ef1c5e0929  vmovaps [rsp+0xD0], xmm13
000073ef1c5e0932  vmovaps [rsp+0xE0], xmm14
000073ef1c5e093b  sub rsp, 0x30
000073ef1c5e093f  movaps [rsp], xmm15
000073ef1c5e0944  movaps [rsp+0x10], xmm11
000073ef1c5e094a  movaps [rsp+0x20], xmm6
000073ef1c5e094f  lea rdi, [rsp]
000073ef1c5e0953  mov esi, 0x00
000073ef1c5e0958  mov rax, 0x56F25E118530
000073ef1c5e0962  call rax
000073ef1c5e0964  movaps xmm15, [rsp]
000073ef1c5e0969  add rsp, 0x30
000073ef1c5e096d  vmovaps xmm0, [rsp]
000073ef1c5e0972  vmovaps xmm1, [rsp+0x10]
000073ef1c5e0978  vmovaps xmm2, [rsp+0x20]
000073ef1c5e097e  vmovaps xmm3, [rsp+0x30]
000073ef1c5e0984  vmovaps xmm4, [rsp+0x40]
000073ef1c5e098a  vmovaps xmm5, [rsp+0x50]
000073ef1c5e0990  vmovaps xmm6, [rsp+0x60]
000073ef1c5e0996  vmovaps xmm7, [rsp+0x70]
000073ef1c5e099c  vmovaps xmm8, [rsp+0x80]
000073ef1c5e09a5  vmovaps xmm9, [rsp+0x90]
000073ef1c5e09ae  vmovaps xmm10, [rsp+0xA0]
000073ef1c5e09b7  vmovaps xmm11, [rsp+0xB0]
000073ef1c5e09c0  vmovaps xmm12, [rsp+0xC0]
000073ef1c5e09c9  vmovaps xmm13, [rsp+0xD0]
000073ef1c5e09d2  vmovaps xmm14, [rsp+0xE0]
000073ef1c5e09db  add rsp, 0xF0
000073ef1c5e09e2  pop r11
000073ef1c5e09e4  pop r10
000073ef1c5e09e6  pop r9
000073ef1c5e09e8  pop r8
000073ef1c5e09ea  pop rsi
000073ef1c5e09eb  pop rdi
000073ef1c5e09ec  pop rdx
000073ef1c5e09ed  pop rcx
000073ef1c5e09ee  pop rax
000073ef1c5e09ef  add rsp, 0x08
000073ef1c5e09f3  jmp 0x000073EF1C5DC658
000073ef1c5e09f8  sub rsp, 0x08
000073ef1c5e09fc  push rax
000073ef1c5e09fd  push rcx
000073ef1c5e09fe  push rdx
000073ef1c5e09ff  push rdi
000073ef1c5e0a00  push rsi
000073ef1c5e0a01  push r8
000073ef1c5e0a03  push r9
000073ef1c5e0a05  push r10
000073ef1c5e0a07  push r11
000073ef1c5e0a09  sub rsp, 0xF0
000073ef1c5e0a10  vmovaps [rsp], xmm0
000073ef1c5e0a15  vmovaps [rsp+0x10], xmm1
000073ef1c5e0a1b  vmovaps [rsp+0x20], xmm2
000073ef1c5e0a21  vmovaps [rsp+0x30], xmm3
000073ef1c5e0a27  vmovaps [rsp+0x40], xmm4
000073ef1c5e0a2d  vmovaps [rsp+0x50], xmm5
000073ef1c5e0a33  vmovaps [rsp+0x60], xmm6
000073ef1c5e0a39  vmovaps [rsp+0x70], xmm8
000073ef1c5e0a3f  vmovaps [rsp+0x80], xmm9
000073ef1c5e0a48  vmovaps [rsp+0x90], xmm10
000073ef1c5e0a51  vmovaps [rsp+0xA0], xmm11
000073ef1c5e0a5a  vmovaps [rsp+0xB0], xmm12
000073ef1c5e0a63  vmovaps [rsp+0xC0], xmm13
000073ef1c5e0a6c  vmovaps [rsp+0xD0], xmm14
000073ef1c5e0a75  vmovaps [rsp+0xE0], xmm15
000073ef1c5e0a7e  sub rsp, 0x30
000073ef1c5e0a82  movaps [rsp], xmm7
000073ef1c5e0a86  movaps [rsp+0x10], xmm11
000073ef1c5e0a8c  movaps [rsp+0x20], xmm9
000073ef1c5e0a92  lea rdi, [rsp]
000073ef1c5e0a96  mov esi, 0x00
000073ef1c5e0a9b  mov rax, 0x56F25E118530
000073ef1c5e0aa5  call rax
000073ef1c5e0aa7  movaps xmm7, [rsp]
000073ef1c5e0aab  add rsp, 0x30
000073ef1c5e0aaf  vmovaps xmm0, [rsp]
000073ef1c5e0ab4  vmovaps xmm1, [rsp+0x10]
000073ef1c5e0aba  vmovaps xmm2, [rsp+0x20]
000073ef1c5e0ac0  vmovaps xmm3, [rsp+0x30]
000073ef1c5e0ac6  vmovaps xmm4, [rsp+0x40]
000073ef1c5e0acc  vmovaps xmm5, [rsp+0x50]
000073ef1c5e0ad2  vmovaps xmm6, [rsp+0x60]
000073ef1c5e0ad8  vmovaps xmm8, [rsp+0x70]
000073ef1c5e0ade  vmovaps xmm9, [rsp+0x80]
000073ef1c5e0ae7  vmovaps xmm10, [rsp+0x90]
000073ef1c5e0af0  vmovaps xmm11, [rsp+0xA0]
000073ef1c5e0af9  vmovaps xmm12, [rsp+0xB0]
000073ef1c5e0b02  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e0b0b  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e0b14  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e0b1d  add rsp, 0xF0
000073ef1c5e0b24  pop r11
000073ef1c5e0b26  pop r10
000073ef1c5e0b28  pop r9
000073ef1c5e0b2a  pop r8
000073ef1c5e0b2c  pop rsi
000073ef1c5e0b2d  pop rdi
000073ef1c5e0b2e  pop rdx
000073ef1c5e0b2f  pop rcx
000073ef1c5e0b30  pop rax
000073ef1c5e0b31  add rsp, 0x08
000073ef1c5e0b35  jmp 0x000073EF1C5DC685
000073ef1c5e0b3a  sub rsp, 0x08
000073ef1c5e0b3e  push rax
000073ef1c5e0b3f  push rcx
000073ef1c5e0b40  push rdx
000073ef1c5e0b41  push rdi
000073ef1c5e0b42  push rsi
000073ef1c5e0b43  push r8
000073ef1c5e0b45  push r9
000073ef1c5e0b47  push r10
000073ef1c5e0b49  push r11
000073ef1c5e0b4b  sub rsp, 0xF0
000073ef1c5e0b52  vmovaps [rsp], xmm0
000073ef1c5e0b57  vmovaps [rsp+0x10], xmm1
000073ef1c5e0b5d  vmovaps [rsp+0x20], xmm2
000073ef1c5e0b63  vmovaps [rsp+0x30], xmm3
000073ef1c5e0b69  vmovaps [rsp+0x40], xmm4
000073ef1c5e0b6f  vmovaps [rsp+0x50], xmm5
000073ef1c5e0b75  vmovaps [rsp+0x60], xmm6
000073ef1c5e0b7b  vmovaps [rsp+0x70], xmm7
000073ef1c5e0b81  vmovaps [rsp+0x80], xmm8
000073ef1c5e0b8a  vmovaps [rsp+0x90], xmm9
000073ef1c5e0b93  vmovaps [rsp+0xA0], xmm10
000073ef1c5e0b9c  vmovaps [rsp+0xB0], xmm12
000073ef1c5e0ba5  vmovaps [rsp+0xC0], xmm13
000073ef1c5e0bae  vmovaps [rsp+0xD0], xmm14
000073ef1c5e0bb7  vmovaps [rsp+0xE0], xmm15
000073ef1c5e0bc0  sub rsp, 0x30
000073ef1c5e0bc4  movaps [rsp], xmm11
000073ef1c5e0bc9  movaps [rsp+0x10], xmm10
000073ef1c5e0bcf  movaps [rsp+0x20], xmm14
000073ef1c5e0bd5  lea rdi, [rsp]
000073ef1c5e0bd9  mov esi, 0x00
000073ef1c5e0bde  mov rax, 0x56F25E118530
000073ef1c5e0be8  call rax
000073ef1c5e0bea  movaps xmm11, [rsp]
000073ef1c5e0bef  add rsp, 0x30
000073ef1c5e0bf3  vmovaps xmm0, [rsp]
000073ef1c5e0bf8  vmovaps xmm1, [rsp+0x10]
000073ef1c5e0bfe  vmovaps xmm2, [rsp+0x20]
000073ef1c5e0c04  vmovaps xmm3, [rsp+0x30]
000073ef1c5e0c0a  vmovaps xmm4, [rsp+0x40]
000073ef1c5e0c10  vmovaps xmm5, [rsp+0x50]
000073ef1c5e0c16  vmovaps xmm6, [rsp+0x60]
000073ef1c5e0c1c  vmovaps xmm7, [rsp+0x70]
000073ef1c5e0c22  vmovaps xmm8, [rsp+0x80]
000073ef1c5e0c2b  vmovaps xmm9, [rsp+0x90]
000073ef1c5e0c34  vmovaps xmm10, [rsp+0xA0]
000073ef1c5e0c3d  vmovaps xmm12, [rsp+0xB0]
000073ef1c5e0c46  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e0c4f  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e0c58  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e0c61  add rsp, 0xF0
000073ef1c5e0c68  pop r11
000073ef1c5e0c6a  pop r10
000073ef1c5e0c6c  pop r9
000073ef1c5e0c6e  pop r8
000073ef1c5e0c70  pop rsi
000073ef1c5e0c71  pop rdi
000073ef1c5e0c72  pop rdx
000073ef1c5e0c73  pop rcx
000073ef1c5e0c74  pop rax
000073ef1c5e0c75  add rsp, 0x08
000073ef1c5e0c79  jmp 0x000073EF1C5DC6A0
000073ef1c5e0c7e  call 0x000073EF1C4C33A0
000073ef1c5e0c83  jmp 0x000073EF1C5DC6AA
000073ef1c5e0c88  sub rsp, 0x08
000073ef1c5e0c8c  push rax
000073ef1c5e0c8d  push rcx
000073ef1c5e0c8e  push rdx
000073ef1c5e0c8f  push rdi
000073ef1c5e0c90  push rsi
000073ef1c5e0c91  push r8
000073ef1c5e0c93  push r9
000073ef1c5e0c95  push r10
000073ef1c5e0c97  push r11
000073ef1c5e0c99  sub rsp, 0xF0
000073ef1c5e0ca0  vmovaps [rsp], xmm0
000073ef1c5e0ca5  vmovaps [rsp+0x10], xmm1
000073ef1c5e0cab  vmovaps [rsp+0x20], xmm2
000073ef1c5e0cb1  vmovaps [rsp+0x30], xmm3
000073ef1c5e0cb7  vmovaps [rsp+0x40], xmm4
000073ef1c5e0cbd  vmovaps [rsp+0x50], xmm5
000073ef1c5e0cc3  vmovaps [rsp+0x60], xmm6
000073ef1c5e0cc9  vmovaps [rsp+0x70], xmm7
000073ef1c5e0ccf  vmovaps [rsp+0x80], xmm8
000073ef1c5e0cd8  vmovaps [rsp+0x90], xmm9
000073ef1c5e0ce1  vmovaps [rsp+0xA0], xmm11
000073ef1c5e0cea  vmovaps [rsp+0xB0], xmm12
000073ef1c5e0cf3  vmovaps [rsp+0xC0], xmm13
000073ef1c5e0cfc  vmovaps [rsp+0xD0], xmm14
000073ef1c5e0d05  vmovaps [rsp+0xE0], xmm15
000073ef1c5e0d0e  sub rsp, 0x30
000073ef1c5e0d12  movaps [rsp], xmm10
000073ef1c5e0d17  movaps [rsp+0x10], xmm1
000073ef1c5e0d1c  movaps [rsp+0x20], xmm12
000073ef1c5e0d22  lea rdi, [rsp]
000073ef1c5e0d26  mov esi, 0x00
000073ef1c5e0d2b  mov rax, 0x56F25E118530
000073ef1c5e0d35  call rax
000073ef1c5e0d37  movaps xmm10, [rsp]
000073ef1c5e0d3c  add rsp, 0x30
000073ef1c5e0d40  vmovaps xmm0, [rsp]
000073ef1c5e0d45  vmovaps xmm1, [rsp+0x10]
000073ef1c5e0d4b  vmovaps xmm2, [rsp+0x20]
000073ef1c5e0d51  vmovaps xmm3, [rsp+0x30]
000073ef1c5e0d57  vmovaps xmm4, [rsp+0x40]
000073ef1c5e0d5d  vmovaps xmm5, [rsp+0x50]
000073ef1c5e0d63  vmovaps xmm6, [rsp+0x60]
000073ef1c5e0d69  vmovaps xmm7, [rsp+0x70]
000073ef1c5e0d6f  vmovaps xmm8, [rsp+0x80]
000073ef1c5e0d78  vmovaps xmm9, [rsp+0x90]
000073ef1c5e0d81  vmovaps xmm11, [rsp+0xA0]
000073ef1c5e0d8a  vmovaps xmm12, [rsp+0xB0]
000073ef1c5e0d93  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e0d9c  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e0da5  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e0dae  add rsp, 0xF0
000073ef1c5e0db5  pop r11
000073ef1c5e0db7  pop r10
000073ef1c5e0db9  pop r9
000073ef1c5e0dbb  pop r8
000073ef1c5e0dbd  pop rsi
000073ef1c5e0dbe  pop rdi
000073ef1c5e0dbf  pop rdx
000073ef1c5e0dc0  pop rcx
000073ef1c5e0dc1  pop rax
000073ef1c5e0dc2  add rsp, 0x08
000073ef1c5e0dc6  jmp 0x000073EF1C5DC6CD
000073ef1c5e0dcb  sub rsp, 0x08
000073ef1c5e0dcf  push rax
000073ef1c5e0dd0  push rcx
000073ef1c5e0dd1  push rdx
000073ef1c5e0dd2  push rdi
000073ef1c5e0dd3  push rsi
000073ef1c5e0dd4  push r8
000073ef1c5e0dd6  push r9
000073ef1c5e0dd8  push r10
000073ef1c5e0dda  push r11
000073ef1c5e0ddc  sub rsp, 0xF0
000073ef1c5e0de3  vmovaps [rsp], xmm0
000073ef1c5e0de8  vmovaps [rsp+0x10], xmm1
000073ef1c5e0dee  vmovaps [rsp+0x20], xmm2
000073ef1c5e0df4  vmovaps [rsp+0x30], xmm3
000073ef1c5e0dfa  vmovaps [rsp+0x40], xmm4
000073ef1c5e0e00  vmovaps [rsp+0x50], xmm5
000073ef1c5e0e06  vmovaps [rsp+0x60], xmm6
000073ef1c5e0e0c  vmovaps [rsp+0x70], xmm7
000073ef1c5e0e12  vmovaps [rsp+0x80], xmm8
000073ef1c5e0e1b  vmovaps [rsp+0x90], xmm9
000073ef1c5e0e24  vmovaps [rsp+0xA0], xmm10
000073ef1c5e0e2d  vmovaps [rsp+0xB0], xmm11
000073ef1c5e0e36  vmovaps [rsp+0xC0], xmm13
000073ef1c5e0e3f  vmovaps [rsp+0xD0], xmm14
000073ef1c5e0e48  vmovaps [rsp+0xE0], xmm15
000073ef1c5e0e51  sub rsp, 0x30
000073ef1c5e0e55  movaps [rsp], xmm12
000073ef1c5e0e5a  movaps [rsp+0x10], xmm14
000073ef1c5e0e60  movaps [rsp+0x20], xmm1
000073ef1c5e0e65  lea rdi, [rsp]
000073ef1c5e0e69  mov esi, 0x00
000073ef1c5e0e6e  mov rax, 0x56F25E118530
000073ef1c5e0e78  call rax
000073ef1c5e0e7a  movaps xmm12, [rsp]
000073ef1c5e0e7f  add rsp, 0x30
000073ef1c5e0e83  vmovaps xmm0, [rsp]
000073ef1c5e0e88  vmovaps xmm1, [rsp+0x10]
000073ef1c5e0e8e  vmovaps xmm2, [rsp+0x20]
000073ef1c5e0e94  vmovaps xmm3, [rsp+0x30]
000073ef1c5e0e9a  vmovaps xmm4, [rsp+0x40]
000073ef1c5e0ea0  vmovaps xmm5, [rsp+0x50]
000073ef1c5e0ea6  vmovaps xmm6, [rsp+0x60]
000073ef1c5e0eac  vmovaps xmm7, [rsp+0x70]
000073ef1c5e0eb2  vmovaps xmm8, [rsp+0x80]
000073ef1c5e0ebb  vmovaps xmm9, [rsp+0x90]
000073ef1c5e0ec4  vmovaps xmm10, [rsp+0xA0]
000073ef1c5e0ecd  vmovaps xmm11, [rsp+0xB0]
000073ef1c5e0ed6  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e0edf  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e0ee8  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e0ef1  add rsp, 0xF0
000073ef1c5e0ef8  pop r11
000073ef1c5e0efa  pop r10
000073ef1c5e0efc  pop r9
000073ef1c5e0efe  pop r8
000073ef1c5e0f00  pop rsi
000073ef1c5e0f01  pop rdi
000073ef1c5e0f02  pop rdx
000073ef1c5e0f03  pop rcx
000073ef1c5e0f04  pop rax
000073ef1c5e0f05  add rsp, 0x08
000073ef1c5e0f09  jmp 0x000073EF1C5DC6FC
000073ef1c5e0f0e  sub rsp, 0x08
000073ef1c5e0f12  push rax
000073ef1c5e0f13  push rcx
000073ef1c5e0f14  push rdx
000073ef1c5e0f15  push rdi
000073ef1c5e0f16  push rsi
000073ef1c5e0f17  push r8
000073ef1c5e0f19  push r9
000073ef1c5e0f1b  push r10
000073ef1c5e0f1d  push r11
000073ef1c5e0f1f  sub rsp, 0xF0
000073ef1c5e0f26  vmovaps [rsp], xmm0
000073ef1c5e0f2b  vmovaps [rsp+0x10], xmm1
000073ef1c5e0f31  vmovaps [rsp+0x20], xmm2
000073ef1c5e0f37  vmovaps [rsp+0x30], xmm3
000073ef1c5e0f3d  vmovaps [rsp+0x40], xmm4
000073ef1c5e0f43  vmovaps [rsp+0x50], xmm5
000073ef1c5e0f49  vmovaps [rsp+0x60], xmm6
000073ef1c5e0f4f  vmovaps [rsp+0x70], xmm7
000073ef1c5e0f55  vmovaps [rsp+0x80], xmm8
000073ef1c5e0f5e  vmovaps [rsp+0x90], xmm9
000073ef1c5e0f67  vmovaps [rsp+0xA0], xmm10
000073ef1c5e0f70  vmovaps [rsp+0xB0], xmm11
000073ef1c5e0f79  vmovaps [rsp+0xC0], xmm12
000073ef1c5e0f82  vmovaps [rsp+0xD0], xmm13
000073ef1c5e0f8b  vmovaps [rsp+0xE0], xmm15
000073ef1c5e0f94  sub rsp, 0x30
000073ef1c5e0f98  movaps [rsp], xmm14
000073ef1c5e0f9d  movaps [rsp+0x10], xmm9
000073ef1c5e0fa3  movaps [rsp+0x20], xmm1
000073ef1c5e0fa8  lea rdi, [rsp]
000073ef1c5e0fac  mov esi, 0x00
000073ef1c5e0fb1  mov rax, 0x56F25E118530
000073ef1c5e0fbb  call rax
000073ef1c5e0fbd  movaps xmm14, [rsp]
000073ef1c5e0fc2  add rsp, 0x30
000073ef1c5e0fc6  vmovaps xmm0, [rsp]
000073ef1c5e0fcb  vmovaps xmm1, [rsp+0x10]
000073ef1c5e0fd1  vmovaps xmm2, [rsp+0x20]
000073ef1c5e0fd7  vmovaps xmm3, [rsp+0x30]
000073ef1c5e0fdd  vmovaps xmm4, [rsp+0x40]
000073ef1c5e0fe3  vmovaps xmm5, [rsp+0x50]
000073ef1c5e0fe9  vmovaps xmm6, [rsp+0x60]
000073ef1c5e0fef  vmovaps xmm7, [rsp+0x70]
000073ef1c5e0ff5  vmovaps xmm8, [rsp+0x80]
000073ef1c5e0ffe  vmovaps xmm9, [rsp+0x90]
000073ef1c5e1007  vmovaps xmm10, [rsp+0xA0]
000073ef1c5e1010  vmovaps xmm11, [rsp+0xB0]
000073ef1c5e1019  vmovaps xmm12, [rsp+0xC0]
000073ef1c5e1022  vmovaps xmm13, [rsp+0xD0]
000073ef1c5e102b  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e1034  add rsp, 0xF0
000073ef1c5e103b  pop r11
000073ef1c5e103d  pop r10
000073ef1c5e103f  pop r9
000073ef1c5e1041  pop r8
000073ef1c5e1043  pop rsi
000073ef1c5e1044  pop rdi
000073ef1c5e1045  pop rdx
000073ef1c5e1046  pop rcx
000073ef1c5e1047  pop rax
000073ef1c5e1048  add rsp, 0x08
000073ef1c5e104c  jmp 0x000073EF1C5DC72B
000073ef1c5e1051  sub rsp, 0x08
000073ef1c5e1055  push rax
000073ef1c5e1056  push rcx
000073ef1c5e1057  push rdx
000073ef1c5e1058  push rdi
000073ef1c5e1059  push rsi
000073ef1c5e105a  push r8
000073ef1c5e105c  push r9
000073ef1c5e105e  push r10
000073ef1c5e1060  push r11
000073ef1c5e1062  sub rsp, 0xF0
000073ef1c5e1069  vmovaps [rsp], xmm0
000073ef1c5e106e  vmovaps [rsp+0x10], xmm2
000073ef1c5e1074  vmovaps [rsp+0x20], xmm3
000073ef1c5e107a  vmovaps [rsp+0x30], xmm4
000073ef1c5e1080  vmovaps [rsp+0x40], xmm5
000073ef1c5e1086  vmovaps [rsp+0x50], xmm6
000073ef1c5e108c  vmovaps [rsp+0x60], xmm7
000073ef1c5e1092  vmovaps [rsp+0x70], xmm8
000073ef1c5e1098  vmovaps [rsp+0x80], xmm9
000073ef1c5e10a1  vmovaps [rsp+0x90], xmm10
000073ef1c5e10aa  vmovaps [rsp+0xA0], xmm11
000073ef1c5e10b3  vmovaps [rsp+0xB0], xmm12
000073ef1c5e10bc  vmovaps [rsp+0xC0], xmm13
000073ef1c5e10c5  vmovaps [rsp+0xD0], xmm14
000073ef1c5e10ce  vmovaps [rsp+0xE0], xmm15
000073ef1c5e10d7  sub rsp, 0x30
000073ef1c5e10db  movaps [rsp], xmm1
000073ef1c5e10df  movaps [rsp+0x10], xmm13
000073ef1c5e10e5  movaps [rsp+0x20], xmm8
000073ef1c5e10eb  lea rdi, [rsp]
000073ef1c5e10ef  mov esi, 0x00
000073ef1c5e10f4  mov rax, 0x56F25E118530
000073ef1c5e10fe  call rax
000073ef1c5e1100  movaps xmm1, [rsp]
000073ef1c5e1104  add rsp, 0x30
000073ef1c5e1108  vmovaps xmm0, [rsp]
000073ef1c5e110d  vmovaps xmm2, [rsp+0x10]
000073ef1c5e1113  vmovaps xmm3, [rsp+0x20]
000073ef1c5e1119  vmovaps xmm4, [rsp+0x30]
000073ef1c5e111f  vmovaps xmm5, [rsp+0x40]
000073ef1c5e1125  vmovaps xmm6, [rsp+0x50]
000073ef1c5e112b  vmovaps xmm7, [rsp+0x60]
000073ef1c5e1131  vmovaps xmm8, [rsp+0x70]
000073ef1c5e1137  vmovaps xmm9, [rsp+0x80]
000073ef1c5e1140  vmovaps xmm10, [rsp+0x90]
000073ef1c5e1149  vmovaps xmm11, [rsp+0xA0]
000073ef1c5e1152  vmovaps xmm12, [rsp+0xB0]
000073ef1c5e115b  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e1164  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e116d  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e1176  add rsp, 0xF0
000073ef1c5e117d  pop r11
000073ef1c5e117f  pop r10
000073ef1c5e1181  pop r9
000073ef1c5e1183  pop r8
000073ef1c5e1185  pop rsi
000073ef1c5e1186  pop rdi
000073ef1c5e1187  pop rdx
000073ef1c5e1188  pop rcx
000073ef1c5e1189  pop rax
000073ef1c5e118a  add rsp, 0x08
000073ef1c5e118e  jmp 0x000073EF1C5DC74D
000073ef1c5e1193  call 0x000073EF1C40C260
000073ef1c5e1198  jmp 0x000073EF1C5DC75B
000073ef1c5e119d  call 0x000073EF1C4BD750
000073ef1c5e11a2  jmp 0x000073EF1C5DC765
000073ef1c5e11a7  sub rsp, 0x08
000073ef1c5e11ab  push rax
000073ef1c5e11ac  push rcx
000073ef1c5e11ad  push rdx
000073ef1c5e11ae  push rdi
000073ef1c5e11af  push rsi
000073ef1c5e11b0  push r8
000073ef1c5e11b2  push r9
000073ef1c5e11b4  push r10
000073ef1c5e11b6  push r11
000073ef1c5e11b8  sub rsp, 0xF0
000073ef1c5e11bf  vmovaps [rsp], xmm0
000073ef1c5e11c4  vmovaps [rsp+0x10], xmm1
000073ef1c5e11ca  vmovaps [rsp+0x20], xmm2
000073ef1c5e11d0  vmovaps [rsp+0x30], xmm3
000073ef1c5e11d6  vmovaps [rsp+0x40], xmm4
000073ef1c5e11dc  vmovaps [rsp+0x50], xmm5
000073ef1c5e11e2  vmovaps [rsp+0x60], xmm6
000073ef1c5e11e8  vmovaps [rsp+0x70], xmm7
000073ef1c5e11ee  vmovaps [rsp+0x80], xmm9
000073ef1c5e11f7  vmovaps [rsp+0x90], xmm10
000073ef1c5e1200  vmovaps [rsp+0xA0], xmm11
000073ef1c5e1209  vmovaps [rsp+0xB0], xmm12
000073ef1c5e1212  vmovaps [rsp+0xC0], xmm13
000073ef1c5e121b  vmovaps [rsp+0xD0], xmm14
000073ef1c5e1224  vmovaps [rsp+0xE0], xmm15
000073ef1c5e122d  sub rsp, 0x30
000073ef1c5e1231  movaps [rsp], xmm8
000073ef1c5e1236  movaps [rsp+0x10], xmm15
000073ef1c5e123c  movaps [rsp+0x20], xmm7
000073ef1c5e1241  lea rdi, [rsp]
000073ef1c5e1245  mov esi, 0x00
000073ef1c5e124a  mov rax, 0x56F25E118530
000073ef1c5e1254  call rax
000073ef1c5e1256  movaps xmm8, [rsp]
000073ef1c5e125b  add rsp, 0x30
000073ef1c5e125f  vmovaps xmm0, [rsp]
000073ef1c5e1264  vmovaps xmm1, [rsp+0x10]
000073ef1c5e126a  vmovaps xmm2, [rsp+0x20]
000073ef1c5e1270  vmovaps xmm3, [rsp+0x30]
000073ef1c5e1276  vmovaps xmm4, [rsp+0x40]
000073ef1c5e127c  vmovaps xmm5, [rsp+0x50]
000073ef1c5e1282  vmovaps xmm6, [rsp+0x60]
000073ef1c5e1288  vmovaps xmm7, [rsp+0x70]
000073ef1c5e128e  vmovaps xmm9, [rsp+0x80]
000073ef1c5e1297  vmovaps xmm10, [rsp+0x90]
000073ef1c5e12a0  vmovaps xmm11, [rsp+0xA0]
000073ef1c5e12a9  vmovaps xmm12, [rsp+0xB0]
000073ef1c5e12b2  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e12bb  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e12c4  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e12cd  add rsp, 0xF0
000073ef1c5e12d4  pop r11
000073ef1c5e12d6  pop r10
000073ef1c5e12d8  pop r9
000073ef1c5e12da  pop r8
000073ef1c5e12dc  pop rsi
000073ef1c5e12dd  pop rdi
000073ef1c5e12de  pop rdx
000073ef1c5e12df  pop rcx
000073ef1c5e12e0  pop rax
000073ef1c5e12e1  add rsp, 0x08
000073ef1c5e12e5  jmp 0x000073EF1C5DC787
000073ef1c5e12ea  sub rsp, 0x08
000073ef1c5e12ee  push rax
000073ef1c5e12ef  push rcx
000073ef1c5e12f0  push rdx
000073ef1c5e12f1  push rdi
000073ef1c5e12f2  push rsi
000073ef1c5e12f3  push r8
000073ef1c5e12f5  push r9
000073ef1c5e12f7  push r10
000073ef1c5e12f9  push r11
000073ef1c5e12fb  sub rsp, 0xF0
000073ef1c5e1302  vmovaps [rsp], xmm0
000073ef1c5e1307  vmovaps [rsp+0x10], xmm1
000073ef1c5e130d  vmovaps [rsp+0x20], xmm2
000073ef1c5e1313  vmovaps [rsp+0x30], xmm3
000073ef1c5e1319  vmovaps [rsp+0x40], xmm4
000073ef1c5e131f  vmovaps [rsp+0x50], xmm5
000073ef1c5e1325  vmovaps [rsp+0x60], xmm6
000073ef1c5e132b  vmovaps [rsp+0x70], xmm8
000073ef1c5e1331  vmovaps [rsp+0x80], xmm9
000073ef1c5e133a  vmovaps [rsp+0x90], xmm10
000073ef1c5e1343  vmovaps [rsp+0xA0], xmm11
000073ef1c5e134c  vmovaps [rsp+0xB0], xmm12
000073ef1c5e1355  vmovaps [rsp+0xC0], xmm13
000073ef1c5e135e  vmovaps [rsp+0xD0], xmm14
000073ef1c5e1367  vmovaps [rsp+0xE0], xmm15
000073ef1c5e1370  sub rsp, 0x30
000073ef1c5e1374  movaps [rsp], xmm7
000073ef1c5e1378  movaps [rsp+0x10], xmm9
000073ef1c5e137e  movaps [rsp+0x20], xmm15
000073ef1c5e1384  lea rdi, [rsp]
000073ef1c5e1388  mov esi, 0x00
000073ef1c5e138d  mov rax, 0x56F25E118530
000073ef1c5e1397  call rax
000073ef1c5e1399  movaps xmm7, [rsp]
000073ef1c5e139d  add rsp, 0x30
000073ef1c5e13a1  vmovaps xmm0, [rsp]
000073ef1c5e13a6  vmovaps xmm1, [rsp+0x10]
000073ef1c5e13ac  vmovaps xmm2, [rsp+0x20]
000073ef1c5e13b2  vmovaps xmm3, [rsp+0x30]
000073ef1c5e13b8  vmovaps xmm4, [rsp+0x40]
000073ef1c5e13be  vmovaps xmm5, [rsp+0x50]
000073ef1c5e13c4  vmovaps xmm6, [rsp+0x60]
000073ef1c5e13ca  vmovaps xmm8, [rsp+0x70]
000073ef1c5e13d0  vmovaps xmm9, [rsp+0x80]
000073ef1c5e13d9  vmovaps xmm10, [rsp+0x90]
000073ef1c5e13e2  vmovaps xmm11, [rsp+0xA0]
000073ef1c5e13eb  vmovaps xmm12, [rsp+0xB0]
000073ef1c5e13f4  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e13fd  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e1406  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e140f  add rsp, 0xF0
000073ef1c5e1416  pop r11
000073ef1c5e1418  pop r10
000073ef1c5e141a  pop r9
000073ef1c5e141c  pop r8
000073ef1c5e141e  pop rsi
000073ef1c5e141f  pop rdi
000073ef1c5e1420  pop rdx
000073ef1c5e1421  pop rcx
000073ef1c5e1422  pop rax
000073ef1c5e1423  add rsp, 0x08
000073ef1c5e1427  jmp 0x000073EF1C5DC7B4
000073ef1c5e142c  sub rsp, 0x08
000073ef1c5e1430  push rax
000073ef1c5e1431  push rcx
000073ef1c5e1432  push rdx
000073ef1c5e1433  push rdi
000073ef1c5e1434  push rsi
000073ef1c5e1435  push r8
000073ef1c5e1437  push r9
000073ef1c5e1439  push r10
000073ef1c5e143b  push r11
000073ef1c5e143d  sub rsp, 0xF0
000073ef1c5e1444  vmovaps [rsp], xmm0
000073ef1c5e1449  vmovaps [rsp+0x10], xmm1
000073ef1c5e144f  vmovaps [rsp+0x20], xmm2
000073ef1c5e1455  vmovaps [rsp+0x30], xmm3
000073ef1c5e145b  vmovaps [rsp+0x40], xmm4
000073ef1c5e1461  vmovaps [rsp+0x50], xmm5
000073ef1c5e1467  vmovaps [rsp+0x60], xmm6
000073ef1c5e146d  vmovaps [rsp+0x70], xmm7
000073ef1c5e1473  vmovaps [rsp+0x80], xmm8
000073ef1c5e147c  vmovaps [rsp+0x90], xmm10
000073ef1c5e1485  vmovaps [rsp+0xA0], xmm11
000073ef1c5e148e  vmovaps [rsp+0xB0], xmm12
000073ef1c5e1497  vmovaps [rsp+0xC0], xmm13
000073ef1c5e14a0  vmovaps [rsp+0xD0], xmm14
000073ef1c5e14a9  vmovaps [rsp+0xE0], xmm15
000073ef1c5e14b2  sub rsp, 0x30
000073ef1c5e14b6  movaps [rsp], xmm9
000073ef1c5e14bb  movaps [rsp+0x10], xmm13
000073ef1c5e14c1  movaps [rsp+0x20], xmm15
000073ef1c5e14c7  lea rdi, [rsp]
000073ef1c5e14cb  mov esi, 0x00
000073ef1c5e14d0  mov rax, 0x56F25E118530
000073ef1c5e14da  call rax
000073ef1c5e14dc  movaps xmm9, [rsp]
000073ef1c5e14e1  add rsp, 0x30
000073ef1c5e14e5  vmovaps xmm0, [rsp]
000073ef1c5e14ea  vmovaps xmm1, [rsp+0x10]
000073ef1c5e14f0  vmovaps xmm2, [rsp+0x20]
000073ef1c5e14f6  vmovaps xmm3, [rsp+0x30]
000073ef1c5e14fc  vmovaps xmm4, [rsp+0x40]
000073ef1c5e1502  vmovaps xmm5, [rsp+0x50]
000073ef1c5e1508  vmovaps xmm6, [rsp+0x60]
000073ef1c5e150e  vmovaps xmm7, [rsp+0x70]
000073ef1c5e1514  vmovaps xmm8, [rsp+0x80]
000073ef1c5e151d  vmovaps xmm10, [rsp+0x90]
000073ef1c5e1526  vmovaps xmm11, [rsp+0xA0]
000073ef1c5e152f  vmovaps xmm12, [rsp+0xB0]
000073ef1c5e1538  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e1541  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e154a  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e1553  add rsp, 0xF0
000073ef1c5e155a  pop r11
000073ef1c5e155c  pop r10
000073ef1c5e155e  pop r9
000073ef1c5e1560  pop r8
000073ef1c5e1562  pop rsi
000073ef1c5e1563  pop rdi
000073ef1c5e1564  pop rdx
000073ef1c5e1565  pop rcx
000073ef1c5e1566  pop rax
000073ef1c5e1567  add rsp, 0x08
000073ef1c5e156b  jmp 0x000073EF1C5DC7E2
000073ef1c5e1570  sub rsp, 0x08
000073ef1c5e1574  push rax
000073ef1c5e1575  push rcx
000073ef1c5e1576  push rdx
000073ef1c5e1577  push rdi
000073ef1c5e1578  push rsi
000073ef1c5e1579  push r8
000073ef1c5e157b  push r9
000073ef1c5e157d  push r10
000073ef1c5e157f  push r11
000073ef1c5e1581  sub rsp, 0xF0
000073ef1c5e1588  vmovaps [rsp], xmm0
000073ef1c5e158d  vmovaps [rsp+0x10], xmm1
000073ef1c5e1593  vmovaps [rsp+0x20], xmm2
000073ef1c5e1599  vmovaps [rsp+0x30], xmm3
000073ef1c5e159f  vmovaps [rsp+0x40], xmm4
000073ef1c5e15a5  vmovaps [rsp+0x50], xmm5
000073ef1c5e15ab  vmovaps [rsp+0x60], xmm6
000073ef1c5e15b1  vmovaps [rsp+0x70], xmm7
000073ef1c5e15b7  vmovaps [rsp+0x80], xmm8
000073ef1c5e15c0  vmovaps [rsp+0x90], xmm9
000073ef1c5e15c9  vmovaps [rsp+0xA0], xmm10
000073ef1c5e15d2  vmovaps [rsp+0xB0], xmm11
000073ef1c5e15db  vmovaps [rsp+0xC0], xmm12
000073ef1c5e15e4  vmovaps [rsp+0xD0], xmm13
000073ef1c5e15ed  vmovaps [rsp+0xE0], xmm14
000073ef1c5e15f6  sub rsp, 0x30
000073ef1c5e15fa  movaps [rsp], xmm15
000073ef1c5e15ff  movaps [rsp+0x10], xmm11
000073ef1c5e1605  movaps [rsp+0x20], xmm12
000073ef1c5e160b  lea rdi, [rsp]
000073ef1c5e160f  mov esi, 0x00
000073ef1c5e1614  mov rax, 0x56F25E118530
000073ef1c5e161e  call rax
000073ef1c5e1620  movaps xmm15, [rsp]
000073ef1c5e1625  add rsp, 0x30
000073ef1c5e1629  vmovaps xmm0, [rsp]
000073ef1c5e162e  vmovaps xmm1, [rsp+0x10]
000073ef1c5e1634  vmovaps xmm2, [rsp+0x20]
000073ef1c5e163a  vmovaps xmm3, [rsp+0x30]
000073ef1c5e1640  vmovaps xmm4, [rsp+0x40]
000073ef1c5e1646  vmovaps xmm5, [rsp+0x50]
000073ef1c5e164c  vmovaps xmm6, [rsp+0x60]
000073ef1c5e1652  vmovaps xmm7, [rsp+0x70]
000073ef1c5e1658  vmovaps xmm8, [rsp+0x80]
000073ef1c5e1661  vmovaps xmm9, [rsp+0x90]
000073ef1c5e166a  vmovaps xmm10, [rsp+0xA0]
000073ef1c5e1673  vmovaps xmm11, [rsp+0xB0]
000073ef1c5e167c  vmovaps xmm12, [rsp+0xC0]
000073ef1c5e1685  vmovaps xmm13, [rsp+0xD0]
000073ef1c5e168e  vmovaps xmm14, [rsp+0xE0]
000073ef1c5e1697  add rsp, 0xF0
000073ef1c5e169e  pop r11
000073ef1c5e16a0  pop r10
000073ef1c5e16a2  pop r9
000073ef1c5e16a4  pop r8
000073ef1c5e16a6  pop rsi
000073ef1c5e16a7  pop rdi
000073ef1c5e16a8  pop rdx
000073ef1c5e16a9  pop rcx
000073ef1c5e16aa  pop rax
000073ef1c5e16ab  add rsp, 0x08
000073ef1c5e16af  jmp 0x000073EF1C5DC7FD
000073ef1c5e16b4  sub rsp, 0x08
000073ef1c5e16b8  push rax
000073ef1c5e16b9  push rcx
000073ef1c5e16ba  push rdx
000073ef1c5e16bb  push rdi
000073ef1c5e16bc  push rsi
000073ef1c5e16bd  push r8
000073ef1c5e16bf  push r9
000073ef1c5e16c1  push r10
000073ef1c5e16c3  push r11
000073ef1c5e16c5  sub rsp, 0xF0
000073ef1c5e16cc  vmovaps [rsp], xmm0
000073ef1c5e16d1  vmovaps [rsp+0x10], xmm1
000073ef1c5e16d7  vmovaps [rsp+0x20], xmm2
000073ef1c5e16dd  vmovaps [rsp+0x30], xmm3
000073ef1c5e16e3  vmovaps [rsp+0x40], xmm4
000073ef1c5e16e9  vmovaps [rsp+0x50], xmm5
000073ef1c5e16ef  vmovaps [rsp+0x60], xmm6
000073ef1c5e16f5  vmovaps [rsp+0x70], xmm7
000073ef1c5e16fb  vmovaps [rsp+0x80], xmm8
000073ef1c5e1704  vmovaps [rsp+0x90], xmm9
000073ef1c5e170d  vmovaps [rsp+0xA0], xmm10
000073ef1c5e1716  vmovaps [rsp+0xB0], xmm11
000073ef1c5e171f  vmovaps [rsp+0xC0], xmm12
000073ef1c5e1728  vmovaps [rsp+0xD0], xmm14
000073ef1c5e1731  vmovaps [rsp+0xE0], xmm15
000073ef1c5e173a  sub rsp, 0x30
000073ef1c5e173e  movaps [rsp], xmm13
000073ef1c5e1743  movaps [rsp+0x10], xmm10
000073ef1c5e1749  movaps [rsp+0x20], xmm14
000073ef1c5e174f  lea rdi, [rsp]
000073ef1c5e1753  mov esi, 0x00
000073ef1c5e1758  mov rax, 0x56F25E118530
000073ef1c5e1762  call rax
000073ef1c5e1764  movaps xmm13, [rsp]
000073ef1c5e1769  add rsp, 0x30
000073ef1c5e176d  vmovaps xmm0, [rsp]
000073ef1c5e1772  vmovaps xmm1, [rsp+0x10]
000073ef1c5e1778  vmovaps xmm2, [rsp+0x20]
000073ef1c5e177e  vmovaps xmm3, [rsp+0x30]
000073ef1c5e1784  vmovaps xmm4, [rsp+0x40]
000073ef1c5e178a  vmovaps xmm5, [rsp+0x50]
000073ef1c5e1790  vmovaps xmm6, [rsp+0x60]
000073ef1c5e1796  vmovaps xmm7, [rsp+0x70]
000073ef1c5e179c  vmovaps xmm8, [rsp+0x80]
000073ef1c5e17a5  vmovaps xmm9, [rsp+0x90]
000073ef1c5e17ae  vmovaps xmm10, [rsp+0xA0]
000073ef1c5e17b7  vmovaps xmm11, [rsp+0xB0]
000073ef1c5e17c0  vmovaps xmm12, [rsp+0xC0]
000073ef1c5e17c9  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e17d2  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e17db  add rsp, 0xF0
000073ef1c5e17e2  pop r11
000073ef1c5e17e4  pop r10
000073ef1c5e17e6  pop r9
000073ef1c5e17e8  pop r8
000073ef1c5e17ea  pop rsi
000073ef1c5e17eb  pop rdi
000073ef1c5e17ec  pop rdx
000073ef1c5e17ed  pop rcx
000073ef1c5e17ee  pop rax
000073ef1c5e17ef  add rsp, 0x08
000073ef1c5e17f3  jmp 0x000073EF1C5DC820
000073ef1c5e17f8  sub rsp, 0x08
000073ef1c5e17fc  push rax
000073ef1c5e17fd  push rcx
000073ef1c5e17fe  push rdx
000073ef1c5e17ff  push rdi
000073ef1c5e1800  push rsi
000073ef1c5e1801  push r8
000073ef1c5e1803  push r9
000073ef1c5e1805  push r10
000073ef1c5e1807  push r11
000073ef1c5e1809  sub rsp, 0xF0
000073ef1c5e1810  vmovaps [rsp], xmm0
000073ef1c5e1815  vmovaps [rsp+0x10], xmm1
000073ef1c5e181b  vmovaps [rsp+0x20], xmm2
000073ef1c5e1821  vmovaps [rsp+0x30], xmm3
000073ef1c5e1827  vmovaps [rsp+0x40], xmm4
000073ef1c5e182d  vmovaps [rsp+0x50], xmm5
000073ef1c5e1833  vmovaps [rsp+0x60], xmm6
000073ef1c5e1839  vmovaps [rsp+0x70], xmm7
000073ef1c5e183f  vmovaps [rsp+0x80], xmm8
000073ef1c5e1848  vmovaps [rsp+0x90], xmm9
000073ef1c5e1851  vmovaps [rsp+0xA0], xmm10
000073ef1c5e185a  vmovaps [rsp+0xB0], xmm11
000073ef1c5e1863  vmovaps [rsp+0xC0], xmm12
000073ef1c5e186c  vmovaps [rsp+0xD0], xmm13
000073ef1c5e1875  vmovaps [rsp+0xE0], xmm15
000073ef1c5e187e  sub rsp, 0x30
000073ef1c5e1882  movaps [rsp], xmm14
000073ef1c5e1887  movaps [rsp+0x10], xmm1
000073ef1c5e188c  movaps [rsp+0x20], xmm7
000073ef1c5e1891  lea rdi, [rsp]
000073ef1c5e1895  mov esi, 0x00
000073ef1c5e189a  mov rax, 0x56F25E118530
000073ef1c5e18a4  call rax
000073ef1c5e18a6  movaps xmm14, [rsp]
000073ef1c5e18ab  add rsp, 0x30
000073ef1c5e18af  vmovaps xmm0, [rsp]
000073ef1c5e18b4  vmovaps xmm1, [rsp+0x10]
000073ef1c5e18ba  vmovaps xmm2, [rsp+0x20]
000073ef1c5e18c0  vmovaps xmm3, [rsp+0x30]
000073ef1c5e18c6  vmovaps xmm4, [rsp+0x40]
000073ef1c5e18cc  vmovaps xmm5, [rsp+0x50]
000073ef1c5e18d2  vmovaps xmm6, [rsp+0x60]
000073ef1c5e18d8  vmovaps xmm7, [rsp+0x70]
000073ef1c5e18de  vmovaps xmm8, [rsp+0x80]
000073ef1c5e18e7  vmovaps xmm9, [rsp+0x90]
000073ef1c5e18f0  vmovaps xmm10, [rsp+0xA0]
000073ef1c5e18f9  vmovaps xmm11, [rsp+0xB0]
000073ef1c5e1902  vmovaps xmm12, [rsp+0xC0]
000073ef1c5e190b  vmovaps xmm13, [rsp+0xD0]
000073ef1c5e1914  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e191d  add rsp, 0xF0
000073ef1c5e1924  pop r11
000073ef1c5e1926  pop r10
000073ef1c5e1928  pop r9
000073ef1c5e192a  pop r8
000073ef1c5e192c  pop rsi
000073ef1c5e192d  pop rdi
000073ef1c5e192e  pop rdx
000073ef1c5e192f  pop rcx
000073ef1c5e1930  pop rax
000073ef1c5e1931  add rsp, 0x08
000073ef1c5e1935  jmp 0x000073EF1C5DC843
000073ef1c5e193a  sub rsp, 0x08
000073ef1c5e193e  push rax
000073ef1c5e193f  push rcx
000073ef1c5e1940  push rdx
000073ef1c5e1941  push rdi
000073ef1c5e1942  push rsi
000073ef1c5e1943  push r8
000073ef1c5e1945  push r9
000073ef1c5e1947  push r10
000073ef1c5e1949  push r11
000073ef1c5e194b  sub rsp, 0xF0
000073ef1c5e1952  vmovaps [rsp], xmm0
000073ef1c5e1957  vmovaps [rsp+0x10], xmm2
000073ef1c5e195d  vmovaps [rsp+0x20], xmm3
000073ef1c5e1963  vmovaps [rsp+0x30], xmm4
000073ef1c5e1969  vmovaps [rsp+0x40], xmm5
000073ef1c5e196f  vmovaps [rsp+0x50], xmm6
000073ef1c5e1975  vmovaps [rsp+0x60], xmm7
000073ef1c5e197b  vmovaps [rsp+0x70], xmm8
000073ef1c5e1981  vmovaps [rsp+0x80], xmm9
000073ef1c5e198a  vmovaps [rsp+0x90], xmm10
000073ef1c5e1993  vmovaps [rsp+0xA0], xmm11
000073ef1c5e199c  vmovaps [rsp+0xB0], xmm12
000073ef1c5e19a5  vmovaps [rsp+0xC0], xmm13
000073ef1c5e19ae  vmovaps [rsp+0xD0], xmm14
000073ef1c5e19b7  vmovaps [rsp+0xE0], xmm15
000073ef1c5e19c0  sub rsp, 0x30
000073ef1c5e19c4  movaps [rsp], xmm1
000073ef1c5e19c8  movaps [rsp+0x10], xmm8
000073ef1c5e19ce  movaps [rsp+0x20], xmm9
000073ef1c5e19d4  lea rdi, [rsp]
000073ef1c5e19d8  mov esi, 0x00
000073ef1c5e19dd  mov rax, 0x56F25E118530
000073ef1c5e19e7  call rax
000073ef1c5e19e9  movaps xmm1, [rsp]
000073ef1c5e19ed  add rsp, 0x30
000073ef1c5e19f1  vmovaps xmm0, [rsp]
000073ef1c5e19f6  vmovaps xmm2, [rsp+0x10]
000073ef1c5e19fc  vmovaps xmm3, [rsp+0x20]
000073ef1c5e1a02  vmovaps xmm4, [rsp+0x30]
000073ef1c5e1a08  vmovaps xmm5, [rsp+0x40]
000073ef1c5e1a0e  vmovaps xmm6, [rsp+0x50]
000073ef1c5e1a14  vmovaps xmm7, [rsp+0x60]
000073ef1c5e1a1a  vmovaps xmm8, [rsp+0x70]
000073ef1c5e1a20  vmovaps xmm9, [rsp+0x80]
000073ef1c5e1a29  vmovaps xmm10, [rsp+0x90]
000073ef1c5e1a32  vmovaps xmm11, [rsp+0xA0]
000073ef1c5e1a3b  vmovaps xmm12, [rsp+0xB0]
000073ef1c5e1a44  vmovaps xmm13, [rsp+0xC0]
000073ef1c5e1a4d  vmovaps xmm14, [rsp+0xD0]
000073ef1c5e1a56  vmovaps xmm15, [rsp+0xE0]
000073ef1c5e1a5f  add rsp, 0xF0
000073ef1c5e1a66  pop r11
000073ef1c5e1a68  pop r10
000073ef1c5e1a6a  pop r9
000073ef1c5e1a6c  pop r8
000073ef1c5e1a6e  pop rsi
000073ef1c5e1a6f  pop rdi
000073ef1c5e1a70  pop rdx
000073ef1c5e1a71  pop rcx
000073ef1c5e1a72  pop rax
000073ef1c5e1a73  add rsp, 0x08
000073ef1c5e1a77  jmp 0x000073EF1C5DC865
000073ef1c5e1a7c  call 0x000073EF1C4E5940
000073ef1c5e1a81  jmp 0x000073EF1C5DC873
000073ef1c5e1a86  call 0x000073EF1C40C380
000073ef1c5e1a8b  jmp 0x000073EF1C5DC87D
000073ef1c5e1a90  call 0x000073EF1C40D600
000073ef1c5e1a95  jmp 0x000073EF1C5DC887
000073ef1c5e1a9a  call 0x000073EF1C3FF540
000073ef1c5e1a9f  jmp 0x000073EF1C5DC891
000073ef1c5e1aa4  int3
000073ef1c5e1aa5  nop [rax+rax*1], ax
000073ef1c5e1aae  nop
000073ef1c5e1ab0  mov rax, [r15+0xF8]
000073ef1c5e1ab7  lea r14, [rax+0x140]
000073ef1c5e1abe  mov r12, [r13+r14*1]
000073ef1c5e1ac3  mov [r15+0xE8], r12
000073ef1c5e1aca  lea r14, [rax+0x130]
000073ef1c5e1ad1  mov r12, [r13+r14*1]
000073ef1c5e1ad6  lea r14, [rax+0x138]
000073ef1c5e1add  mov r11, [r13+r14*1]
000073ef1c5e1ae2  movq xmm1, r12
000073ef1c5e1ae7  movq xmm15, r11
000073ef1c5e1aec  movq xmm1, xmm1
000073ef1c5e1af0  movq xmm1, xmm1
000073ef1c5e1af4  movaps [r15+0x1A0], xmm1
000073ef1c5e1afc  movq xmm15, xmm15
000073ef1c5e1b01  movq xmm15, xmm15
000073ef1c5e1b06  movaps [r15+0x190], xmm15
000073ef1c5e1b0e  lea r14, [rax+0x120]
000073ef1c5e1b15  mov r12, [r13+r14*1]
000073ef1c5e1b1a  lea r14, [rax+0x128]
000073ef1c5e1b21  mov r11, [r13+r14*1]
000073ef1c5e1b26  movq xmm1, r12
000073ef1c5e1b2b  movq xmm15, r11
000073ef1c5e1b30  movq xmm1, xmm1
000073ef1c5e1b34  movq xmm1, xmm1
000073ef1c5e1b38  movaps [r15+0x1C0], xmm1
000073ef1c5e1b40  movq xmm15, xmm15
000073ef1c5e1b45  movq xmm15, xmm15
000073ef1c5e1b4a  movaps [r15+0x1B0], xmm15
000073ef1c5e1b52  lea r14, [rax+0x110]
000073ef1c5e1b59  mov r12, [r13+r14*1]
000073ef1c5e1b5e  lea r14, [rax+0x118]
000073ef1c5e1b65  mov r11, [r13+r14*1]
000073ef1c5e1b6a  movq xmm1, r12
000073ef1c5e1b6f  movq xmm15, r11
000073ef1c5e1b74  movq xmm1, xmm1
000073ef1c5e1b78  movq xmm1, xmm1
000073ef1c5e1b7c  movaps [r15+0x1E0], xmm1
000073ef1c5e1b84  movq xmm15, xmm15
000073ef1c5e1b89  movq xmm15, xmm15
000073ef1c5e1b8e  movaps [r15+0x1D0], xmm15
000073ef1c5e1b96  lea r14, [rax+0x100]
000073ef1c5e1b9d  mov r12, [r13+r14*1]
000073ef1c5e1ba2  lea r14, [rax+0x108]
000073ef1c5e1ba9  mov r11, [r13+r14*1]
000073ef1c5e1bae  movq xmm1, r12
000073ef1c5e1bb3  movq xmm15, r11
000073ef1c5e1bb8  movq xmm1, xmm1
000073ef1c5e1bbc  movq xmm1, xmm1
000073ef1c5e1bc0  movaps [r15+0x200], xmm1
000073ef1c5e1bc8  movq xmm15, xmm15
000073ef1c5e1bcd  movq xmm15, xmm15
000073ef1c5e1bd2  movaps [r15+0x1F0], xmm15
000073ef1c5e1bda  mov qword ptr [r15+0x40], 0x430000
000073ef1c5e1be2  mov r14d, 0x430510
000073ef1c5e1be8  mov r12, [r13+r14*1]
000073ef1c5e1bed  movq xmm1, r12
000073ef1c5e1bf2  lea r14, [rax+0x150]
000073ef1c5e1bf9  mov [r15+0xF8], r14
000073ef1c5e1c00  mov rax, [r15+0x50]
000073ef1c5e1c04  movups xmm15, [r13+rax*1]
000073ef1c5e1c0a  movaps [r15+0x120], xmm15
000073ef1c5e1c12  mov qword ptr [r15+0x48], 0x10
000073ef1c5e1c1a  xor eax, eax
000073ef1c5e1c1c  mov r14d, 0x10
000073ef1c5e1c22  mov r12d, 0x200
000073ef1c5e1c28  cmp r14, r12
000073ef1c5e1c2b  cmc
000073ef1c5e1c2c  lahf
000073ef1c5e1c2d  seto al
000073ef1c5e1c30  mov [r15+0x108], eax
000073ef1c5e1c37  pextrq rax, xmm15, 0x01
000073ef1c5e1c3e  movq xmm14, rax
000073ef1c5e1c43  movaps [r15+0x130], xmm14
000073ef1c5e1c4b  movq rax, xmm1
000073ef1c5e1c50  movq r14, xmm15
000073ef1c5e1c55  vmovq xmm1, rax
000073ef1c5e1c5a  vmovq xmm15, r14
000073ef1c5e1c5f  movaps xmm13, xmm1
000073ef1c5e1c63  addsd xmm13, xmm15
000073ef1c5e1c68  ucomisd xmm13, xmm13
000073ef1c5e1c6d  jp 0x000073EF1C5E1D86
000073ef1c5e1c73  movq xmm13, xmm13
000073ef1c5e1c78  movq rax, xmm13
000073ef1c5e1c7d  movq r14, xmm14
000073ef1c5e1c82  vmovq xmm1, rax
000073ef1c5e1c87  vmovq xmm15, r14
000073ef1c5e1c8c  movaps xmm14, xmm1
000073ef1c5e1c90  addsd xmm14, xmm15
000073ef1c5e1c95  ucomisd xmm14, xmm14
000073ef1c5e1c9a  jp 0x000073EF1C5E1DCE
000073ef1c5e1ca0  movq xmm14, xmm14
000073ef1c5e1ca5  movaps [r15+0x110], xmm14
000073ef1c5e1cad  mov eax, [r15+0x108]
000073ef1c5e1cb4  sahf
000073ef1c5e1cb5  jnz 0x000073EF1C5E1CE7
000073ef1c5e1cb7  cmp dword ptr [r15+0x318], 0x00
000073ef1c5e1cbf  jz 0x000073EF1C5E1FE0
000073ef1c5e1cc5  nop [rax+rax*1], ax
000073ef1c5e1cce  nop [rax+rax*1], eax
000073ef1c5e1cd6  mov eax, 0x410490
000073ef1c5e1cdb  mov [r15+0x100], rax
000073ef1c5e1ce2  jmp 0x000073EF1C3FE110
000073ef1c5e1ce7  cmp dword ptr [r15+0x318], 0x00
000073ef1c5e1cef  jz 0x000073EF1C5E1E20
000073ef1c5e1cf5  nop [rax+rax*1], ax
000073ef1c5e1cfe  nop [rax+rax*1], eax
000073ef1c5e1d06  mov eax, 0x410474
000073ef1c5e1d0b  mov [r15+0x100], rax
000073ef1c5e1d12  jmp 0x000073EF1C3FE110
000073ef1c5e1d17  int3
000073ef1c5e1d18  call 0x000073EF1C4E27E0
000073ef1c5e1d1d  jmp 0x000073EF1C5E1AC3
000073ef1c5e1d22  call 0x000073EF1C4E27E0
000073ef1c5e1d27  jmp 0x000073EF1C5E1AD6
000073ef1c5e1d2c  call 0x000073EF1C4E1570
000073ef1c5e1d31  jmp 0x000073EF1C5E1AE2
000073ef1c5e1d36  call 0x000073EF1C4E27E0
000073ef1c5e1d3b  jmp 0x000073EF1C5E1B1A
000073ef1c5e1d40  call 0x000073EF1C4E1570
000073ef1c5e1d45  jmp 0x000073EF1C5E1B26
000073ef1c5e1d4a  call 0x000073EF1C4E27E0
000073ef1c5e1d4f  jmp 0x000073EF1C5E1B5E
000073ef1c5e1d54  call 0x000073EF1C4E1570
000073ef1c5e1d59  jmp 0x000073EF1C5E1B6A
000073ef1c5e1d5e  call 0x000073EF1C4E27E0
000073ef1c5e1d63  jmp 0x000073EF1C5E1BA2
000073ef1c5e1d68  call 0x000073EF1C4E1570
000073ef1c5e1d6d  jmp 0x000073EF1C5E1BAE
000073ef1c5e1d72  call 0x000073EF1C4E27E0
000073ef1c5e1d77  jmp 0x000073EF1C5E1BED
000073ef1c5e1d7c  call 0x000073EF1C40E760
000073ef1c5e1d81  jmp 0x000073EF1C5E1C0A
000073ef1c5e1d86  ucomisd xmm1, xmm15
000073ef1c5e1d8b  jp 0x000073EF1C5E1D9A
000073ef1c5e1d8d  movaps xmm13, [0x000073EF1C1FE060]
000073ef1c5e1d95  jmp 0x000073EF1C5E1C73
000073ef1c5e1d9a  vxorps xmm0, xmm1, xmm15
000073ef1c5e1d9f  pextrw eax, xmm0, 0x03
000073ef1c5e1da4  and eax, 0x7FF8
000073ef1c5e1da9  cmp eax, 0x08
000073ef1c5e1dac  jnz 0x000073EF1C5E1C73
000073ef1c5e1db2  movq rax, xmm15
000073ef1c5e1db7  shl rax, 0x0D
000073ef1c5e1dbb  jbe 0x000073EF1C5E1C73
000073ef1c5e1dc1  vorps xmm13, xmm15, [0x000073EF1C1FE070]
000073ef1c5e1dc9  jmp 0x000073EF1C5E1C73
000073ef1c5e1dce  ucomisd xmm1, xmm15
000073ef1c5e1dd3  jp 0x000073EF1C5E1DE2
000073ef1c5e1dd5  movaps xmm14, [0x000073EF1C1FE060]
000073ef1c5e1ddd  jmp 0x000073EF1C5E1CA0
000073ef1c5e1de2  vxorps xmm0, xmm1, xmm15
000073ef1c5e1de7  pextrw eax, xmm0, 0x03
000073ef1c5e1dec  and eax, 0x7FF8
000073ef1c5e1df1  cmp eax, 0x08
000073ef1c5e1df4  jnz 0x000073EF1C5E1CA0
000073ef1c5e1dfa  movq rax, xmm15
000073ef1c5e1dff  shl rax, 0x0D
000073ef1c5e1e03  jbe 0x000073EF1C5E1CA0
000073ef1c5e1e09  vorps xmm14, xmm15, [0x000073EF1C1FE070]
000073ef1c5e1e11  jmp 0x000073EF1C5E1CA0
000073ef1c5e1e16  int3
000073ef1c5e1e17  nop [rax+rax*1], ax
000073ef1c5e1e20  mov rax, [r15+0x48]
000073ef1c5e1e24  mov r14, [r15+0x50]
000073ef1c5e1e28  lea r12, [r14+rax*1]
000073ef1c5e1e2c  movups xmm1, [r13+r12*1]
000073ef1c5e1e32  movaps [r15+0x120], xmm1
000073ef1c5e1e3a  lea r14, [rax+0x10]
000073ef1c5e1e3e  mov [r15+0x48], r14
000073ef1c5e1e42  xor eax, eax
000073ef1c5e1e44  mov r12d, 0x200
000073ef1c5e1e4a  cmp r14, r12
000073ef1c5e1e4d  cmc
000073ef1c5e1e4e  lahf
000073ef1c5e1e4f  seto al
000073ef1c5e1e52  mov [r15+0x108], eax
000073ef1c5e1e59  pextrq rax, xmm1, 0x01
000073ef1c5e1e60  movq xmm15, rax
000073ef1c5e1e65  movaps [r15+0x130], xmm15
000073ef1c5e1e6d  movaps xmm14, [r15+0x110]
000073ef1c5e1e75  movq rax, xmm14
000073ef1c5e1e7a  movq r14, xmm1
000073ef1c5e1e7f  vmovq xmm1, rax
000073ef1c5e1e84  vmovq xmm14, r14
000073ef1c5e1e89  movaps xmm13, xmm1
000073ef1c5e1e8d  addsd xmm13, xmm14
000073ef1c5e1e92  ucomisd xmm13, xmm13
000073ef1c5e1e97  jp 0x000073EF1C5E1F4C
000073ef1c5e1e9d  movq xmm13, xmm13
000073ef1c5e1ea2  movq rax, xmm13
000073ef1c5e1ea7  movq r14, xmm15
000073ef1c5e1eac  vmovq xmm1, rax
000073ef1c5e1eb1  vmovq xmm15, r14
000073ef1c5e1eb6  movaps xmm14, xmm1
000073ef1c5e1eba  addsd xmm14, xmm15
000073ef1c5e1ebf  ucomisd xmm14, xmm14
000073ef1c5e1ec4  jp 0x000073EF1C5E1F94
000073ef1c5e1eca  movq xmm14, xmm14
000073ef1c5e1ecf  movaps [r15+0x110], xmm14
000073ef1c5e1ed7  mov eax, [r15+0x108]
000073ef1c5e1ede  sahf
000073ef1c5e1edf  jnz 0x000073EF1C5E1F11
000073ef1c5e1ee1  cmp dword ptr [r15+0x318], 0x00
000073ef1c5e1ee9  jz 0x000073EF1C5E1FE0
000073ef1c5e1eef  nop [rax+rax*1], ax
000073ef1c5e1ef8  nop [rax+rax*1], eax
000073ef1c5e1f00  mov eax, 0x410490
000073ef1c5e1f05  mov [r15+0x100], rax
000073ef1c5e1f0c  jmp 0x000073EF1C3FE110
000073ef1c5e1f11  cmp dword ptr [r15+0x318], 0x00
000073ef1c5e1f19  jz 0x000073EF1C5E1E20
000073ef1c5e1f1f  nop [rax+rax*1], ax
000073ef1c5e1f28  nop [rax+rax*1], eax
000073ef1c5e1f30  mov eax, 0x410474
000073ef1c5e1f35  mov [r15+0x100], rax
000073ef1c5e1f3c  jmp 0x000073EF1C3FE110
000073ef1c5e1f41  int3
000073ef1c5e1f42  call 0x000073EF1C4B52F0
000073ef1c5e1f47  jmp 0x000073EF1C5E1E32
000073ef1c5e1f4c  ucomisd xmm1, xmm14
000073ef1c5e1f51  jp 0x000073EF1C5E1F60
000073ef1c5e1f53  movaps xmm13, [0x000073EF1C1FE060]
000073ef1c5e1f5b  jmp 0x000073EF1C5E1E9D
000073ef1c5e1f60  vxorps xmm0, xmm1, xmm14
000073ef1c5e1f65  pextrw eax, xmm0, 0x03
000073ef1c5e1f6a  and eax, 0x7FF8
000073ef1c5e1f6f  cmp eax, 0x08
000073ef1c5e1f72  jnz 0x000073EF1C5E1E9D
000073ef1c5e1f78  movq rax, xmm14
000073ef1c5e1f7d  shl rax, 0x0D
000073ef1c5e1f81  jbe 0x000073EF1C5E1E9D
000073ef1c5e1f87  vorps xmm13, xmm14, [0x000073EF1C1FE070]
000073ef1c5e1f8f  jmp 0x000073EF1C5E1E9D
000073ef1c5e1f94  ucomisd xmm1, xmm15
000073ef1c5e1f99  jp 0x000073EF1C5E1FA8
000073ef1c5e1f9b  movaps xmm14, [0x000073EF1C1FE060]
000073ef1c5e1fa3  jmp 0x000073EF1C5E1ECA
000073ef1c5e1fa8  vxorps xmm0, xmm1, xmm15
000073ef1c5e1fad  pextrw eax, xmm0, 0x03
000073ef1c5e1fb2  and eax, 0x7FF8
000073ef1c5e1fb7  cmp eax, 0x08
000073ef1c5e1fba  jnz 0x000073EF1C5E1ECA
000073ef1c5e1fc0  movq rax, xmm15
000073ef1c5e1fc5  shl rax, 0x0D
000073ef1c5e1fc9  jbe 0x000073EF1C5E1ECA
000073ef1c5e1fcf  vorps xmm14, xmm15, [0x000073EF1C1FE070]
000073ef1c5e1fd7  jmp 0x000073EF1C5E1ECA
000073ef1c5e1fdc  int3
000073ef1c5e1fdd  nop [rax], eax
000073ef1c5e1fe0  mov rax, [r15+0x40]
000073ef1c5e1fe4  lea r14, [rax+0x510]
000073ef1c5e1feb  movaps xmm1, [r15+0x110]
000073ef1c5e1ff3  movq rax, xmm1
000073ef1c5e1ff8  mov [r13+r14*1], rax
000073ef1c5e1ffd  mov rax, [r15+0xF0]
000073ef1c5e2004  mov [r15+0x100], rax
000073ef1c5e200b  jmp 0x000073EF1C5CE5C0
000073ef1c5e2010  int3
000073ef1c5e2011  call 0x000073EF1C4D5EB0
000073ef1c5e2016  jmp 0x000073EF1C5E1FFD
000073ef1c5e201b  int3
000073ef1c5e201c  nop [rax], eax
000073ef1c5e2020  mov qword ptr [r15+0x100], 0x04
000073ef1c5e202b  mov esi, 0x00
000073ef1c5e2030  mov edx, 0x09
000073ef1c5e2035  mov rdi, 0x7FFE0DC3EA00
000073ef1c5e203f  mov rax, 0x56F25DFAB970
000073ef1c5e2049  call rax
000073ef1c5e204b  cmp dword ptr [r15+0x318], 0x00
000073ef1c5e2053  jnz 0x000073EF1C3FE110
000073ef1c5e2059  jmp 0x000073EF1C3FE0A0
000073ef1c5e205e  int3
000073ef1c5e205f  int3
