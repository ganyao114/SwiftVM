00007d07b35ce69b  nop [rax+rax*1], eax
00007d07b35ce6a0  vmovaps xmm1, [0x00007D07B31FE010]
00007d07b35ce6a8  movq xmm1, xmm1
00007d07b35ce6ac  movaps [r15+0x110], xmm1
00007d07b35ce6b4  vmovaps xmm1, [0x00007D07B31FE020]
00007d07b35ce6bc  movq xmm1, xmm1
00007d07b35ce6c0  movaps [r15+0x120], xmm1
00007d07b35ce6c8  mov eax, 0x4204C0
00007d07b35ce6cd  mov r14, [r13+rax*1]
00007d07b35ce6d2  movq xmm1, r14
00007d07b35ce6d7  movaps [r15+0x130], xmm1
00007d07b35ce6df  vmovaps xmm1, [0x00007D07B31FE030]
00007d07b35ce6e7  vpbroadcastq xmm1, xmm1
00007d07b35ce6ec  movaps [r15+0x140], xmm1
00007d07b35ce6f4  mov qword ptr [r15+0x40], 0x02
00007d07b35ce6fc  vmovaps xmm15, [0x00007D07B31FE040]
00007d07b35ce704  movq xmm15, xmm15
00007d07b35ce709  movaps [r15+0x150], xmm15
00007d07b35ce711  mov qword ptr [r15+0x58], 0x420000
00007d07b35ce719  vmovaps xmm15, [0x00007D07B31FE050]
00007d07b35ce721  vpbroadcastq xmm15, xmm15
00007d07b35ce726  movaps [r15+0x160], xmm15
00007d07b35ce72e  mov rax, [r15+0x40]
00007d07b35ce732  vmovq xmm14, rax
00007d07b35ce737  vpbroadcastq xmm14, xmm14
00007d07b35ce73c  movaps [r15+0x170], xmm14
00007d07b35ce744  mov eax, 0x4204D0
00007d07b35ce749  movups xmm13, [r13+rax*1]
00007d07b35ce74f  mov qword ptr [r15+0x40], 0x430518
00007d07b35ce757  mov qword ptr [r15+0x50], 0x430720
00007d07b35ce75f  vpmovqd xmm12, xmm13
00007d07b35ce765  pxor xmm11, xmm11
00007d07b35ce76a  punpcklqdq xmm12, xmm11
00007d07b35ce76f  movaps [r15+0x210], xmm12
00007d07b35ce777  movq xmm12, qword ptr [r15+0x120]
00007d07b35ce780  movq xmm11, qword ptr [r15+0x130]
00007d07b35ce789  psubd xmm12, xmm11
00007d07b35ce78e  movq xmm12, xmm12
00007d07b35ce793  paddq xmm13, xmm14
00007d07b35ce798  movaps [r15+0x180], xmm13
00007d07b35ce7a0  movq xmm14, qword ptr [r15+0x150]
00007d07b35ce7a9  paddd xmm11, xmm14
00007d07b35ce7ae  movq xmm11, xmm11
00007d07b35ce7b3  movq xmm11, xmm11
00007d07b35ce7b8  movaps [r15+0x130], xmm11
00007d07b35ce7c0  pmovzxdq xmm12, xmm12
00007d07b35ce7c6  psllq xmm12, 0x00
00007d07b35ce7cc  movq xmm14, qword ptr [r15+0x210]
00007d07b35ce7d5  movq xmm13, qword ptr [r15+0x110]
00007d07b35ce7de  paddd xmm14, xmm13
00007d07b35ce7e3  movq xmm14, xmm14
00007d07b35ce7e8  vcvtuqq2pd xmm12, xmm12
00007d07b35ce7ee  pmovzxdq xmm14, xmm14
00007d07b35ce7f4  psllq xmm14, 0x00
00007d07b35ce7fa  vcvtuqq2pd xmm14, xmm14
00007d07b35ce800  movaps xmm13, xmm12
00007d07b35ce804  mulpd xmm13, xmm1
00007d07b35ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007d07b35ce80f  ptest xmm11, xmm11
00007d07b35ce815  jnz 0x00007D07B35CE8FF
00007d07b35ce81b  movaps [r15+0x220], xmm13
00007d07b35ce823  mov eax, 0x430720
00007d07b35ce828  movups [r13+rax*1], xmm13
00007d07b35ce82e  movaps xmm1, xmm14
00007d07b35ce832  mulpd xmm1, xmm15
00007d07b35ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007d07b35ce83c  ptest xmm13, xmm13
00007d07b35ce842  jnz 0x00007D07B35CEA4C
00007d07b35ce848  movaps [r15+0x210], xmm1
00007d07b35ce850  mov eax, 0x430518
00007d07b35ce855  movups [r13+rax*1], xmm1
00007d07b35ce85b  mov qword ptr [r15+0x48], 0x10
00007d07b35ce863  xor eax, eax
00007d07b35ce865  mov r14d, 0x10
00007d07b35ce86b  mov r12d, 0x200
00007d07b35ce871  cmp r14, r12
00007d07b35ce874  cmc
00007d07b35ce875  lahf
00007d07b35ce876  seto al
00007d07b35ce879  mov [r15+0x108], eax
00007d07b35ce880  mov eax, [r15+0x108]
00007d07b35ce887  sahf
00007d07b35ce888  jnz 0x00007D07B35CE8BA
00007d07b35ce88a  cmp dword ptr [r15+0x318], 0x00
00007d07b35ce892  jz 0x00007D07B35CEFF0
00007d07b35ce898  nop [rax+rax*1], ax
00007d07b35ce8a1  nop [rax+rax*1], eax
00007d07b35ce8a9  mov eax, 0x4101EC
00007d07b35ce8ae  mov [r15+0x100], rax
00007d07b35ce8b5  jmp 0x00007D07B33FE110
00007d07b35ce8ba  cmp dword ptr [r15+0x318], 0x00
00007d07b35ce8c2  jz 0x00007D07B35CEBA0
00007d07b35ce8c8  nop [rax+rax*1], ax
00007d07b35ce8d1  nop [rax+rax*1], eax
00007d07b35ce8d9  mov eax, 0x4101AC
00007d07b35ce8de  mov [r15+0x100], rax
00007d07b35ce8e5  jmp 0x00007D07B33FE110
00007d07b35ce8ea  int3
00007d07b35ce8eb  call 0x00007D07B340DC20
00007d07b35ce8f0  jmp 0x00007D07B35CE6D2
00007d07b35ce8f5  call 0x00007D07B340C260
00007d07b35ce8fa  jmp 0x00007D07B35CE74F
00007d07b35ce8ff  sub rsp, 0x08
00007d07b35ce903  push rax
00007d07b35ce904  push rcx
00007d07b35ce905  push rdx
00007d07b35ce906  push rdi
00007d07b35ce907  push rsi
00007d07b35ce908  push r8
00007d07b35ce90a  push r9
00007d07b35ce90c  push r10
00007d07b35ce90e  push r11
00007d07b35ce910  sub rsp, 0xF0
00007d07b35ce917  vmovaps [rsp], xmm0
00007d07b35ce91c  vmovaps [rsp+0x10], xmm1
00007d07b35ce922  vmovaps [rsp+0x20], xmm2
00007d07b35ce928  vmovaps [rsp+0x30], xmm3
00007d07b35ce92e  vmovaps [rsp+0x40], xmm4
00007d07b35ce934  vmovaps [rsp+0x50], xmm5
00007d07b35ce93a  vmovaps [rsp+0x60], xmm6
00007d07b35ce940  vmovaps [rsp+0x70], xmm7
00007d07b35ce946  vmovaps [rsp+0x80], xmm8
00007d07b35ce94f  vmovaps [rsp+0x90], xmm9
00007d07b35ce958  vmovaps [rsp+0xA0], xmm10
00007d07b35ce961  vmovaps [rsp+0xB0], xmm11
00007d07b35ce96a  vmovaps [rsp+0xC0], xmm12
00007d07b35ce973  vmovaps [rsp+0xD0], xmm14
00007d07b35ce97c  vmovaps [rsp+0xE0], xmm15
00007d07b35ce985  sub rsp, 0x30
00007d07b35ce989  movaps [rsp], xmm13
00007d07b35ce98e  movaps [rsp+0x10], xmm12
00007d07b35ce994  movaps [rsp+0x20], xmm1
00007d07b35ce999  lea rdi, [rsp]
00007d07b35ce99d  mov esi, 0x00
00007d07b35ce9a2  mov rax, 0x5D0AA712D530
00007d07b35ce9ac  call rax
00007d07b35ce9ae  movaps xmm13, [rsp]
00007d07b35ce9b3  add rsp, 0x30
00007d07b35ce9b7  vmovaps xmm0, [rsp]
00007d07b35ce9bc  vmovaps xmm1, [rsp+0x10]
00007d07b35ce9c2  vmovaps xmm2, [rsp+0x20]
00007d07b35ce9c8  vmovaps xmm3, [rsp+0x30]
00007d07b35ce9ce  vmovaps xmm4, [rsp+0x40]
00007d07b35ce9d4  vmovaps xmm5, [rsp+0x50]
00007d07b35ce9da  vmovaps xmm6, [rsp+0x60]
00007d07b35ce9e0  vmovaps xmm7, [rsp+0x70]
00007d07b35ce9e6  vmovaps xmm8, [rsp+0x80]
00007d07b35ce9ef  vmovaps xmm9, [rsp+0x90]
00007d07b35ce9f8  vmovaps xmm10, [rsp+0xA0]
00007d07b35cea01  vmovaps xmm11, [rsp+0xB0]
00007d07b35cea0a  vmovaps xmm12, [rsp+0xC0]
00007d07b35cea13  vmovaps xmm14, [rsp+0xD0]
00007d07b35cea1c  vmovaps xmm15, [rsp+0xE0]
00007d07b35cea25  add rsp, 0xF0
00007d07b35cea2c  pop r11
00007d07b35cea2e  pop r10
00007d07b35cea30  pop r9
00007d07b35cea32  pop r8
00007d07b35cea34  pop rsi
00007d07b35cea35  pop rdi
00007d07b35cea36  pop rdx
00007d07b35cea37  pop rcx
00007d07b35cea38  pop rax
00007d07b35cea39  add rsp, 0x08
00007d07b35cea3d  jmp 0x00007D07B35CE81B
00007d07b35cea42  call 0x00007D07B340C380
00007d07b35cea47  jmp 0x00007D07B35CE82E
00007d07b35cea4c  sub rsp, 0x08
00007d07b35cea50  push rax
00007d07b35cea51  push rcx
00007d07b35cea52  push rdx
00007d07b35cea53  push rdi
00007d07b35cea54  push rsi
00007d07b35cea55  push r8
00007d07b35cea57  push r9
00007d07b35cea59  push r10
00007d07b35cea5b  push r11
00007d07b35cea5d  sub rsp, 0xF0
00007d07b35cea64  vmovaps [rsp], xmm0
00007d07b35cea69  vmovaps [rsp+0x10], xmm2
00007d07b35cea6f  vmovaps [rsp+0x20], xmm3
00007d07b35cea75  vmovaps [rsp+0x30], xmm4
00007d07b35cea7b  vmovaps [rsp+0x40], xmm5
00007d07b35cea81  vmovaps [rsp+0x50], xmm6
00007d07b35cea87  vmovaps [rsp+0x60], xmm7
00007d07b35cea8d  vmovaps [rsp+0x70], xmm8
00007d07b35cea93  vmovaps [rsp+0x80], xmm9
00007d07b35cea9c  vmovaps [rsp+0x90], xmm10
00007d07b35ceaa5  vmovaps [rsp+0xA0], xmm11
00007d07b35ceaae  vmovaps [rsp+0xB0], xmm12
00007d07b35ceab7  vmovaps [rsp+0xC0], xmm13
00007d07b35ceac0  vmovaps [rsp+0xD0], xmm14
00007d07b35ceac9  vmovaps [rsp+0xE0], xmm15
00007d07b35cead2  sub rsp, 0x30
00007d07b35cead6  movaps [rsp], xmm1
00007d07b35ceada  movaps [rsp+0x10], xmm14
00007d07b35ceae0  movaps [rsp+0x20], xmm15
00007d07b35ceae6  lea rdi, [rsp]
00007d07b35ceaea  mov esi, 0x00
00007d07b35ceaef  mov rax, 0x5D0AA712D530
00007d07b35ceaf9  call rax
00007d07b35ceafb  movaps xmm1, [rsp]
00007d07b35ceaff  add rsp, 0x30
00007d07b35ceb03  vmovaps xmm0, [rsp]
00007d07b35ceb08  vmovaps xmm2, [rsp+0x10]
00007d07b35ceb0e  vmovaps xmm3, [rsp+0x20]
00007d07b35ceb14  vmovaps xmm4, [rsp+0x30]
00007d07b35ceb1a  vmovaps xmm5, [rsp+0x40]
00007d07b35ceb20  vmovaps xmm6, [rsp+0x50]
00007d07b35ceb26  vmovaps xmm7, [rsp+0x60]
00007d07b35ceb2c  vmovaps xmm8, [rsp+0x70]
00007d07b35ceb32  vmovaps xmm9, [rsp+0x80]
00007d07b35ceb3b  vmovaps xmm10, [rsp+0x90]
00007d07b35ceb44  vmovaps xmm11, [rsp+0xA0]
00007d07b35ceb4d  vmovaps xmm12, [rsp+0xB0]
00007d07b35ceb56  vmovaps xmm13, [rsp+0xC0]
00007d07b35ceb5f  vmovaps xmm14, [rsp+0xD0]
00007d07b35ceb68  vmovaps xmm15, [rsp+0xE0]
00007d07b35ceb71  add rsp, 0xF0
00007d07b35ceb78  pop r11
00007d07b35ceb7a  pop r10
00007d07b35ceb7c  pop r9
00007d07b35ceb7e  pop r8
00007d07b35ceb80  pop rsi
00007d07b35ceb81  pop rdi
00007d07b35ceb82  pop rdx
00007d07b35ceb83  pop rcx
00007d07b35ceb84  pop rax
00007d07b35ceb85  add rsp, 0x08
00007d07b35ceb89  jmp 0x00007D07B35CE848
00007d07b35ceb8e  call 0x00007D07B33FF540
00007d07b35ceb93  jmp 0x00007D07B35CE85B
00007d07b35ceb98  int3
00007d07b35ceb99  nop [rax], eax
00007d07b35ceba0  movaps xmm1, [r15+0x180]
00007d07b35ceba8  vpmovqd xmm15, xmm1
00007d07b35cebae  pxor xmm14, xmm14
00007d07b35cebb3  punpcklqdq xmm15, xmm14
00007d07b35cebb8  movaps [r15+0x210], xmm15
00007d07b35cebc0  movq xmm15, qword ptr [r15+0x120]
00007d07b35cebc9  movq xmm14, qword ptr [r15+0x130]
00007d07b35cebd2  psubd xmm15, xmm14
00007d07b35cebd7  movq xmm15, xmm15
00007d07b35cebdc  movaps xmm13, [r15+0x170]
00007d07b35cebe4  paddq xmm1, xmm13
00007d07b35cebe9  movaps [r15+0x180], xmm1
00007d07b35cebf1  movq xmm1, qword ptr [r15+0x150]
00007d07b35cebfa  paddd xmm14, xmm1
00007d07b35cebff  movq xmm14, xmm14
00007d07b35cec04  movq xmm14, xmm14
00007d07b35cec09  movaps [r15+0x130], xmm14
00007d07b35cec11  pmovzxdq xmm15, xmm15
00007d07b35cec17  psllq xmm15, 0x00
00007d07b35cec1d  movq xmm1, qword ptr [r15+0x210]
00007d07b35cec26  movq xmm14, qword ptr [r15+0x110]
00007d07b35cec2f  paddd xmm1, xmm14
00007d07b35cec34  movq xmm1, xmm1
00007d07b35cec38  vcvtuqq2pd xmm15, xmm15
00007d07b35cec3e  pmovzxdq xmm1, xmm1
00007d07b35cec43  psllq xmm1, 0x00
00007d07b35cec48  vcvtuqq2pd xmm1, xmm1
00007d07b35cec4e  movaps xmm14, [r15+0x140]
00007d07b35cec56  movaps xmm13, xmm15
00007d07b35cec5a  mulpd xmm13, xmm14
00007d07b35cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007d07b35cec65  ptest xmm12, xmm12
00007d07b35cec6b  jnz 0x00007D07B35CED4E
00007d07b35cec71  movaps [r15+0x220], xmm13
00007d07b35cec79  mov rax, [r15+0x48]
00007d07b35cec7d  mov r14, [r15+0x50]
00007d07b35cec81  lea r12, [r14+rax*1]
00007d07b35cec85  movups [r13+r12*1], xmm13
00007d07b35cec8b  movaps xmm15, [r15+0x160]
00007d07b35cec93  movaps xmm14, xmm1
00007d07b35cec97  mulpd xmm14, xmm15
00007d07b35cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007d07b35ceca2  ptest xmm13, xmm13
00007d07b35ceca8  jnz 0x00007D07B35CEE9C
00007d07b35cecae  movaps [r15+0x210], xmm14
00007d07b35cecb6  mov r14, [r15+0x40]
00007d07b35cecba  lea r12, [r14+rax*1]
00007d07b35cecbe  movups [r13+r12*1], xmm14
00007d07b35cecc4  lea r14, [rax+0x10]
00007d07b35cecc8  mov [r15+0x48], r14
00007d07b35ceccc  xor eax, eax
00007d07b35cecce  mov r12d, 0x200
00007d07b35cecd4  cmp r14, r12
00007d07b35cecd7  cmc
00007d07b35cecd8  lahf
00007d07b35cecd9  seto al
00007d07b35cecdc  mov [r15+0x108], eax
00007d07b35cece3  mov eax, [r15+0x108]
00007d07b35cecea  sahf
00007d07b35ceceb  jnz 0x00007D07B35CED1D
00007d07b35ceced  cmp dword ptr [r15+0x318], 0x00
00007d07b35cecf5  jz 0x00007D07B35CEFF0
00007d07b35cecfb  nop [rax+rax*1], ax
00007d07b35ced04  nop [rax+rax*1], eax
00007d07b35ced0c  mov eax, 0x4101EC
00007d07b35ced11  mov [r15+0x100], rax
00007d07b35ced18  jmp 0x00007D07B33FE110
00007d07b35ced1d  cmp dword ptr [r15+0x318], 0x00
00007d07b35ced25  jz 0x00007D07B35CEBA0
00007d07b35ced2b  nop [rax+rax*1], ax
00007d07b35ced34  nop [rax+rax*1], eax
00007d07b35ced3c  mov eax, 0x4101AC
00007d07b35ced41  mov [r15+0x100], rax
00007d07b35ced48  jmp 0x00007D07B33FE110
00007d07b35ced4d  int3
00007d07b35ced4e  sub rsp, 0x08
00007d07b35ced52  push rax
00007d07b35ced53  push rcx
00007d07b35ced54  push rdx
00007d07b35ced55  push rdi
00007d07b35ced56  push rsi
00007d07b35ced57  push r8
00007d07b35ced59  push r9
00007d07b35ced5b  push r10
00007d07b35ced5d  push r11
00007d07b35ced5f  sub rsp, 0xF0
00007d07b35ced66  vmovaps [rsp], xmm0
00007d07b35ced6b  vmovaps [rsp+0x10], xmm1
00007d07b35ced71  vmovaps [rsp+0x20], xmm2
00007d07b35ced77  vmovaps [rsp+0x30], xmm3
00007d07b35ced7d  vmovaps [rsp+0x40], xmm4
00007d07b35ced83  vmovaps [rsp+0x50], xmm5
00007d07b35ced89  vmovaps [rsp+0x60], xmm6
00007d07b35ced8f  vmovaps [rsp+0x70], xmm7
00007d07b35ced95  vmovaps [rsp+0x80], xmm8
00007d07b35ced9e  vmovaps [rsp+0x90], xmm9
00007d07b35ceda7  vmovaps [rsp+0xA0], xmm10
00007d07b35cedb0  vmovaps [rsp+0xB0], xmm11
00007d07b35cedb9  vmovaps [rsp+0xC0], xmm12
00007d07b35cedc2  vmovaps [rsp+0xD0], xmm14
00007d07b35cedcb  vmovaps [rsp+0xE0], xmm15
00007d07b35cedd4  sub rsp, 0x30
00007d07b35cedd8  movaps [rsp], xmm13
00007d07b35ceddd  movaps [rsp+0x10], xmm15
00007d07b35cede3  movaps [rsp+0x20], xmm14
00007d07b35cede9  lea rdi, [rsp]
00007d07b35ceded  mov esi, 0x00
00007d07b35cedf2  mov rax, 0x5D0AA712D530
00007d07b35cedfc  call rax
00007d07b35cedfe  movaps xmm13, [rsp]
00007d07b35cee03  add rsp, 0x30
00007d07b35cee07  vmovaps xmm0, [rsp]
00007d07b35cee0c  vmovaps xmm1, [rsp+0x10]
00007d07b35cee12  vmovaps xmm2, [rsp+0x20]
00007d07b35cee18  vmovaps xmm3, [rsp+0x30]
00007d07b35cee1e  vmovaps xmm4, [rsp+0x40]
00007d07b35cee24  vmovaps xmm5, [rsp+0x50]
00007d07b35cee2a  vmovaps xmm6, [rsp+0x60]
00007d07b35cee30  vmovaps xmm7, [rsp+0x70]
00007d07b35cee36  vmovaps xmm8, [rsp+0x80]
00007d07b35cee3f  vmovaps xmm9, [rsp+0x90]
00007d07b35cee48  vmovaps xmm10, [rsp+0xA0]
00007d07b35cee51  vmovaps xmm11, [rsp+0xB0]
00007d07b35cee5a  vmovaps xmm12, [rsp+0xC0]
00007d07b35cee63  vmovaps xmm14, [rsp+0xD0]
00007d07b35cee6c  vmovaps xmm15, [rsp+0xE0]
00007d07b35cee75  add rsp, 0xF0
00007d07b35cee7c  pop r11
00007d07b35cee7e  pop r10
00007d07b35cee80  pop r9
00007d07b35cee82  pop r8
00007d07b35cee84  pop rsi
00007d07b35cee85  pop rdi
00007d07b35cee86  pop rdx
00007d07b35cee87  pop rcx
00007d07b35cee88  pop rax
00007d07b35cee89  add rsp, 0x08
00007d07b35cee8d  jmp 0x00007D07B35CEC71
00007d07b35cee92  call 0x00007D07B34C2240
00007d07b35cee97  jmp 0x00007D07B35CEC8B
00007d07b35cee9c  sub rsp, 0x08
00007d07b35ceea0  push rax
00007d07b35ceea1  push rcx
00007d07b35ceea2  push rdx
00007d07b35ceea3  push rdi
00007d07b35ceea4  push rsi
00007d07b35ceea5  push r8
00007d07b35ceea7  push r9
00007d07b35ceea9  push r10
00007d07b35ceeab  push r11
00007d07b35ceead  sub rsp, 0xF0
00007d07b35ceeb4  vmovaps [rsp], xmm0
00007d07b35ceeb9  vmovaps [rsp+0x10], xmm1
00007d07b35ceebf  vmovaps [rsp+0x20], xmm2
00007d07b35ceec5  vmovaps [rsp+0x30], xmm3
00007d07b35ceecb  vmovaps [rsp+0x40], xmm4
00007d07b35ceed1  vmovaps [rsp+0x50], xmm5
00007d07b35ceed7  vmovaps [rsp+0x60], xmm6
00007d07b35ceedd  vmovaps [rsp+0x70], xmm7
00007d07b35ceee3  vmovaps [rsp+0x80], xmm8
00007d07b35ceeec  vmovaps [rsp+0x90], xmm9
00007d07b35ceef5  vmovaps [rsp+0xA0], xmm10
00007d07b35ceefe  vmovaps [rsp+0xB0], xmm11
00007d07b35cef07  vmovaps [rsp+0xC0], xmm12
00007d07b35cef10  vmovaps [rsp+0xD0], xmm13
00007d07b35cef19  vmovaps [rsp+0xE0], xmm15
00007d07b35cef22  sub rsp, 0x30
00007d07b35cef26  movaps [rsp], xmm14
00007d07b35cef2b  movaps [rsp+0x10], xmm1
00007d07b35cef30  movaps [rsp+0x20], xmm15
00007d07b35cef36  lea rdi, [rsp]
00007d07b35cef3a  mov esi, 0x00
00007d07b35cef3f  mov rax, 0x5D0AA712D530
00007d07b35cef49  call rax
00007d07b35cef4b  movaps xmm14, [rsp]
00007d07b35cef50  add rsp, 0x30
00007d07b35cef54  vmovaps xmm0, [rsp]
00007d07b35cef59  vmovaps xmm1, [rsp+0x10]
00007d07b35cef5f  vmovaps xmm2, [rsp+0x20]
00007d07b35cef65  vmovaps xmm3, [rsp+0x30]
00007d07b35cef6b  vmovaps xmm4, [rsp+0x40]
00007d07b35cef71  vmovaps xmm5, [rsp+0x50]
00007d07b35cef77  vmovaps xmm6, [rsp+0x60]
00007d07b35cef7d  vmovaps xmm7, [rsp+0x70]
00007d07b35cef83  vmovaps xmm8, [rsp+0x80]
00007d07b35cef8c  vmovaps xmm9, [rsp+0x90]
00007d07b35cef95  vmovaps xmm10, [rsp+0xA0]
00007d07b35cef9e  vmovaps xmm11, [rsp+0xB0]
00007d07b35cefa7  vmovaps xmm12, [rsp+0xC0]
00007d07b35cefb0  vmovaps xmm13, [rsp+0xD0]
00007d07b35cefb9  vmovaps xmm15, [rsp+0xE0]
00007d07b35cefc2  add rsp, 0xF0
00007d07b35cefc9  pop r11
00007d07b35cefcb  pop r10
00007d07b35cefcd  pop r9
00007d07b35cefcf  pop r8
00007d07b35cefd1  pop rsi
00007d07b35cefd2  pop rdi
00007d07b35cefd3  pop rdx
00007d07b35cefd4  pop rcx
00007d07b35cefd5  pop rax
00007d07b35cefd6  add rsp, 0x08
00007d07b35cefda  jmp 0x00007D07B35CECAE
00007d07b35cefdf  call 0x00007D07B34C34C0
00007d07b35cefe4  jmp 0x00007D07B35CECC4
00007d07b35cefe9  int3
00007d07b35cefea  nop [rax+rax*1], ax
00007d07b35ceff0  mov rax, [r15+0xF8]
00007d07b35ceff7  lea r14, [rax-0x150]
00007d07b35ceffe  mov [r15+0xF8], r14
00007d07b35cf005  mov rax, [r15+0x50]
00007d07b35cf009  lea r12, [rax+0x80]
00007d07b35cf010  movups xmm1, [r13+r12*1]
00007d07b35cf016  lea r12, [rax+0x90]
00007d07b35cf01d  movups xmm15, [r13+r12*1]
00007d07b35cf023  mov qword ptr [r15+0x48], 0x00
00007d07b35cf02b  lea r12, [rax+0x40]
00007d07b35cf02f  movups xmm14, [r13+r12*1]
00007d07b35cf035  lea r12, [rax+0x50]
00007d07b35cf039  movups xmm13, [r13+r12*1]
00007d07b35cf03f  lea r12, [r14+0x120]
00007d07b35cf046  movq xmm12, qword ptr [r15+0x1C0]
00007d07b35cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007d07b35cf058  movq r11, xmm12
00007d07b35cf05d  movq r10, xmm11
00007d07b35cf062  mov [r13+r12*1], r11
00007d07b35cf067  lea r12, [r14+0x128]
00007d07b35cf06e  mov [r13+r12*1], r10
00007d07b35cf073  vxorps xmm12, xmm12, xmm12
00007d07b35cf078  vpbroadcastq xmm12, xmm12
00007d07b35cf07d  lea r12, [r14+0x100]
00007d07b35cf084  movq xmm11, qword ptr [r15+0x200]
00007d07b35cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007d07b35cf096  movq r11, xmm11
00007d07b35cf09b  movq r10, xmm10
00007d07b35cf0a0  mov [r13+r12*1], r11
00007d07b35cf0a5  lea r12, [r14+0x108]
00007d07b35cf0ac  mov [r13+r12*1], r10
00007d07b35cf0b1  lea r12, [r14+0xE0]
00007d07b35cf0b8  movups [r13+r12*1], xmm15
00007d07b35cf0be  lea r12, [r14+0xF0]
00007d07b35cf0c5  movups [r13+r12*1], xmm1
00007d07b35cf0cb  lea r12, [rax+0xC0]
00007d07b35cf0d2  movups xmm1, [r13+r12*1]
00007d07b35cf0d8  lea r12, [rax+0xD0]
00007d07b35cf0df  movups xmm15, [r13+r12*1]
00007d07b35cf0e5  lea r12, [r14+0x110]
00007d07b35cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007d07b35cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007d07b35cf0fe  movq r11, xmm11
00007d07b35cf103  movq r10, xmm10
00007d07b35cf108  mov [r13+r12*1], r11
00007d07b35cf10d  lea r12, [r14+0x118]
00007d07b35cf114  mov [r13+r12*1], r10
00007d07b35cf119  movups xmm11, [r13+rax*1]
00007d07b35cf11f  lea r12, [rax+0x10]
00007d07b35cf123  movups xmm10, [r13+r12*1]
00007d07b35cf129  lea r12, [r14+0x130]
00007d07b35cf130  movq xmm9, qword ptr [r15+0x1A0]
00007d07b35cf139  movq xmm8, qword ptr [r15+0x190]
00007d07b35cf142  movq r11, xmm9
00007d07b35cf147  movq r10, xmm8
00007d07b35cf14c  mov [r13+r12*1], r11
00007d07b35cf151  lea r12, [r14+0x138]
00007d07b35cf158  mov [r13+r12*1], r10
00007d07b35cf15d  lea r12, [rax+0x140]
00007d07b35cf164  movups xmm9, [r13+r12*1]
00007d07b35cf16a  lea r12, [rax+0x150]
00007d07b35cf171  movups xmm8, [r13+r12*1]
00007d07b35cf177  lea r12, [r14+0xC0]
00007d07b35cf17e  movups [r13+r12*1], xmm15
00007d07b35cf184  lea r12, [r14+0xD0]
00007d07b35cf18b  movups [r13+r12*1], xmm1
00007d07b35cf191  lea r12, [rax+0x100]
00007d07b35cf198  movups xmm1, [r13+r12*1]
00007d07b35cf19e  lea r12, [rax+0x110]
00007d07b35cf1a5  movups xmm15, [r13+r12*1]
00007d07b35cf1ab  lea r12, [r14+0x140]
00007d07b35cf1b2  mov r11, [r15+0xE8]
00007d07b35cf1b9  mov [r13+r12*1], r11
00007d07b35cf1be  lea r12, [rax+0x180]
00007d07b35cf1c5  movups xmm7, [r13+r12*1]
00007d07b35cf1cb  lea r12, [rax+0x190]
00007d07b35cf1d2  movups xmm6, [r13+r12*1]
00007d07b35cf1d8  lea r12, [rax+0x1C0]
00007d07b35cf1df  movups xmm5, [r13+r12*1]
00007d07b35cf1e5  lea r12, [rax+0x1D0]
00007d07b35cf1ec  movups xmm4, [r13+r12*1]
00007d07b35cf1f2  lea r12, [r14+0x20]
00007d07b35cf1f6  movups [r13+r12*1], xmm1
00007d07b35cf1fc  lea r12, [r14+0x30]
00007d07b35cf200  movups [r13+r12*1], xmm13
00007d07b35cf206  lea r12, [rax+0x60]
00007d07b35cf20a  movups xmm1, [r13+r12*1]
00007d07b35cf210  lea r12, [rax+0x70]
00007d07b35cf214  movups xmm13, [r13+r12*1]
00007d07b35cf21a  lea r12, [rax+0x20]
00007d07b35cf21e  movups xmm3, [r13+r12*1]
00007d07b35cf224  lea r12, [rax+0x30]
00007d07b35cf228  movups xmm2, [r13+r12*1]
00007d07b35cf22e  movaps [r15+0x1F0], xmm2
00007d07b35cf236  lea r12, [r14+0x60]
00007d07b35cf23a  movups [r13+r12*1], xmm11
00007d07b35cf240  lea r12, [r14+0x70]
00007d07b35cf244  movups [r13+r12*1], xmm5
00007d07b35cf24a  lea r12, [rax+0xE0]
00007d07b35cf251  movups xmm11, [r13+r12*1]
00007d07b35cf257  lea r12, [rax+0xF0]
00007d07b35cf25e  movups xmm5, [r13+r12*1]
00007d07b35cf264  lea r12, [r14+0xA0]
00007d07b35cf26b  movups [r13+r12*1], xmm13
00007d07b35cf271  lea r12, [r14+0xB0]
00007d07b35cf278  movups [r13+r12*1], xmm1
00007d07b35cf27e  lea r12, [rax+0xA0]
00007d07b35cf285  movups xmm1, [r13+r12*1]
00007d07b35cf28b  lea r12, [rax+0xB0]
00007d07b35cf292  movups xmm13, [r13+r12*1]
00007d07b35cf298  lea r12, [rax+0x120]
00007d07b35cf29f  vmovaps [rsp+0x10], xmm1
00007d07b35cf2a5  movups xmm1, [r13+r12*1]
00007d07b35cf2ab  lea r12, [rax+0x130]
00007d07b35cf2b2  vmovaps [rsp+0x20], xmm1
00007d07b35cf2b8  movups xmm1, [r13+r12*1]
00007d07b35cf2be  lea r12, [rax+0x160]
00007d07b35cf2c5  vmovaps [rsp+0x30], xmm1
00007d07b35cf2cb  movups xmm1, [r13+r12*1]
00007d07b35cf2d1  lea r12, [rax+0x170]
00007d07b35cf2d8  vmovaps [rsp+0x40], xmm1
00007d07b35cf2de  movups xmm1, [r13+r12*1]
00007d07b35cf2e4  movaps [r15+0x2B0], xmm1
00007d07b35cf2ec  lea r12, [r14+0x80]
00007d07b35cf2f3  movups [r13+r12*1], xmm13
00007d07b35cf2f9  lea r12, [r14+0x90]
00007d07b35cf300  vmovaps xmm13, [rsp+0x10]
00007d07b35cf306  movups [r13+r12*1], xmm13
00007d07b35cf30c  lea r12, [rax+0x1A0]
00007d07b35cf313  movups xmm13, [r13+r12*1]
00007d07b35cf319  lea r12, [rax+0x1B0]
00007d07b35cf320  vmovaps [rsp+0x10], xmm1
00007d07b35cf326  movups xmm1, [r13+r12*1]
00007d07b35cf32c  movaps [r15+0x290], xmm13
00007d07b35cf334  movaps [r15+0x1E0], xmm1
00007d07b35cf33c  lea r12, [rax+0x1E0]
00007d07b35cf343  vmovaps [rsp+0x50], xmm1
00007d07b35cf349  movups xmm1, [r13+r12*1]
00007d07b35cf34f  lea r12, [rax+0x1F0]
00007d07b35cf356  vmovaps [rsp+0x60], xmm1
00007d07b35cf35c  movups xmm1, [r13+r12*1]
00007d07b35cf362  mov qword ptr [r15+0x50], 0x430920
00007d07b35cf36a  lea rax, [r14+0x40]
00007d07b35cf36e  vmovaps [rsp+0x70], xmm1
00007d07b35cf374  vmovaps xmm1, [rsp+0x40]
00007d07b35cf37a  movups [r13+rax*1], xmm1
00007d07b35cf380  lea rax, [r14+0x50]
00007d07b35cf384  movups [r13+rax*1], xmm10
00007d07b35cf38a  vmovaps xmm1, [rsp+0x70]
00007d07b35cf390  movups [r13+r14*1], xmm1
00007d07b35cf396  lea rax, [r14+0x10]
00007d07b35cf39a  vmovaps xmm1, [rsp+0x60]
00007d07b35cf3a0  movups [r13+rax*1], xmm1
00007d07b35cf3a6  mov rax, [r15+0x40]
00007d07b35cf3aa  vmovaps [rsp+0x40], xmm3
00007d07b35cf3b0  vmovaps xmm1, [rsp+0x40]
00007d07b35cf3b6  por xmm3, xmm1
00007d07b35cf3ba  vmovaps [rsp+0x40], xmm6
00007d07b35cf3c0  vmovaps xmm10, [rsp+0x40]
00007d07b35cf3c6  por xmm6, xmm10
00007d07b35cf3cb  lea r12, [rax+0x30]
00007d07b35cf3cf  mov r11, [r13+r12*1]
00007d07b35cf3d4  lea r12, [rax+0x38]
00007d07b35cf3d8  mov r10, [r13+r12*1]
00007d07b35cf3dd  movq xmm10, r11
00007d07b35cf3e2  vmovaps [rsp+0x40], xmm1
00007d07b35cf3e8  movq xmm1, r10
00007d07b35cf3ed  movq xmm10, xmm10
00007d07b35cf3f2  vmovaps [rsp+0x60], xmm10
00007d07b35cf3f8  movq xmm10, xmm10
00007d07b35cf3fd  movaps [r15+0x130], xmm10
00007d07b35cf405  movq xmm1, xmm1
00007d07b35cf409  vmovaps [rsp+0x70], xmm1
00007d07b35cf40f  movq xmm1, xmm1
00007d07b35cf413  movaps [r15+0x280], xmm1
00007d07b35cf41b  vmovaps [rsp+0x80], xmm9
00007d07b35cf424  vmovaps xmm1, [rsp+0x80]
00007d07b35cf42d  por xmm9, xmm1
00007d07b35cf432  lea r12, [rax+0x20]
00007d07b35cf436  mov r11, [r13+r12*1]
00007d07b35cf43b  lea r12, [rax+0x28]
00007d07b35cf43f  mov r10, [r13+r12*1]
00007d07b35cf444  movq xmm1, r11
00007d07b35cf449  movq xmm10, r10
00007d07b35cf44e  movq xmm1, xmm1
00007d07b35cf452  vmovaps [rsp+0x80], xmm1
00007d07b35cf45b  movq xmm1, xmm1
00007d07b35cf45f  movaps [r15+0x150], xmm1
00007d07b35cf467  movq xmm10, xmm10
00007d07b35cf46c  vmovaps [rsp+0x90], xmm10
00007d07b35cf475  movq xmm10, xmm10
00007d07b35cf47a  movaps [r15+0x140], xmm10
00007d07b35cf482  lea r12, [rax+0x10]
00007d07b35cf486  mov r11, [r13+r12*1]
00007d07b35cf48b  lea r12, [rax+0x18]
00007d07b35cf48f  mov r10, [r13+r12*1]
00007d07b35cf494  movq xmm1, r11
00007d07b35cf499  movq xmm10, r10
00007d07b35cf49e  movq xmm1, xmm1
00007d07b35cf4a2  vmovaps [rsp+0xA0], xmm1
00007d07b35cf4ab  movq xmm1, xmm1
00007d07b35cf4af  movaps [r15+0x170], xmm1
00007d07b35cf4b7  movq xmm10, xmm10
00007d07b35cf4bc  vmovaps [rsp+0xB0], xmm10
00007d07b35cf4c5  movq xmm10, xmm10
00007d07b35cf4ca  movaps [r15+0x160], xmm10
00007d07b35cf4d2  mov r12, [r13+rax*1]
00007d07b35cf4d7  vmovq xmm1, r12
00007d07b35cf4dc  vpbroadcastq xmm1, xmm1
00007d07b35cf4e1  lea r12, [rax+0x08]
00007d07b35cf4e5  mov rax, [r13+r12*1]
00007d07b35cf4ea  movq xmm10, rax
00007d07b35cf4ef  movaps [r15+0x230], xmm10
00007d07b35cf4f7  lea rax, [r14+0x50]
00007d07b35cf4fb  movups xmm10, [r13+rax*1]
00007d07b35cf501  lea rax, [r14+0x60]
00007d07b35cf505  vmovaps [rsp+0xC0], xmm1
00007d07b35cf50e  movups xmm1, [r13+rax*1]
00007d07b35cf514  lea rax, [r14+0x30]
00007d07b35cf518  vmovaps [rsp+0xD0], xmm1
00007d07b35cf521  movups xmm1, [r13+rax*1]
00007d07b35cf527  mov qword ptr [r15+0x60], 0x430920
00007d07b35cf52f  mov qword ptr [r15+0x58], 0x40
00007d07b35cf537  vmovaps [rsp+0xE0], xmm1
00007d07b35cf540  vmovaps [rsp+0xF0], xmm15
00007d07b35cf549  vmovaps xmm15, [rsp+0xC0]
00007d07b35cf552  vmovaps [rsp+0xC0], xmm14
00007d07b35cf55b  vmovaps xmm14, [rsp+0x40]
00007d07b35cf561  vmovaps [rsp+0x40], xmm13
00007d07b35cf567  movaps xmm1, xmm15
00007d07b35cf56b  mulpd xmm1, xmm14
00007d07b35cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007d07b35cf575  ptest xmm13, xmm13
00007d07b35cf57b  jnz 0x00007D07B35D0682
00007d07b35cf581  movq xmm14, qword ptr [r15+0x230]
00007d07b35cf58a  vmovaps [rsp+0x100], xmm14
00007d07b35cf593  vpermilpd xmm14, xmm14, 0x00
00007d07b35cf599  vmovaps [rsp+0x110], xmm1
00007d07b35cf5a2  vmovaps xmm1, [rsp+0xE0]
00007d07b35cf5ab  vmovaps [rsp+0xE0], xmm15
00007d07b35cf5b4  movaps xmm13, xmm1
00007d07b35cf5b8  mulpd xmm13, xmm14
00007d07b35cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007d07b35cf5c3  ptest xmm15, xmm15
00007d07b35cf5c9  jnz 0x00007D07B35D07C4
00007d07b35cf5cf  vxorps xmm1, xmm1, xmm1
00007d07b35cf5d3  vpbroadcastq xmm1, xmm1
00007d07b35cf5d8  vmovaps xmm14, [rsp+0xE0]
00007d07b35cf5e1  vmovaps [rsp+0xE0], xmm1
00007d07b35cf5ea  vmovaps xmm1, [rsp+0xD0]
00007d07b35cf5f3  vmovaps [rsp+0xD0], xmm13
00007d07b35cf5fc  movaps xmm15, xmm14
00007d07b35cf600  mulpd xmm15, xmm1
00007d07b35cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007d07b35cf60b  ptest xmm13, xmm13
00007d07b35cf611  jnz 0x00007D07B35D0907
00007d07b35cf617  movaps xmm1, xmm14
00007d07b35cf61b  mulpd xmm1, xmm10
00007d07b35cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007d07b35cf625  ptest xmm13, xmm13
00007d07b35cf62b  jnz 0x00007D07B35D0A4A
00007d07b35cf631  movaps xmm13, xmm14
00007d07b35cf635  mulpd xmm13, xmm2
00007d07b35cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007d07b35cf640  ptest xmm10, xmm10
00007d07b35cf646  jnz 0x00007D07B35D0B8C
00007d07b35cf64c  vmovaps [rsp+0x120], xmm7
00007d07b35cf655  vmovaps xmm14, [rsp+0x120]
00007d07b35cf65e  por xmm7, xmm14
00007d07b35cf663  vmovaps xmm14, [rsp+0xC0]
00007d07b35cf66c  vmovaps xmm10, [rsp+0xC0]
00007d07b35cf675  por xmm14, xmm10
00007d07b35cf67a  vmovaps xmm2, [rsp+0x100]
00007d07b35cf683  vpermilpd xmm2, xmm2, 0x00
00007d07b35cf689  vmovaps [rsp+0xC0], xmm1
00007d07b35cf692  vmovaps [rsp+0x120], xmm15
00007d07b35cf69b  movaps xmm1, xmm10
00007d07b35cf69f  mulpd xmm1, xmm2
00007d07b35cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007d07b35cf6a8  ptest xmm15, xmm15
00007d07b35cf6ae  jnz 0x00007D07B35D0CCF
00007d07b35cf6b4  xor eax, eax
00007d07b35cf6b6  mov r12d, 0x40
00007d07b35cf6bc  mov r11d, 0x200
00007d07b35cf6c2  cmp r12, r11
00007d07b35cf6c5  cmc
00007d07b35cf6c6  lahf
00007d07b35cf6c7  seto al
00007d07b35cf6ca  mov [r15+0x108], eax
00007d07b35cf6d1  vmovaps xmm10, [rsp+0x110]
00007d07b35cf6da  vmovaps xmm2, [rsp+0xE0]
00007d07b35cf6e3  vmovaps [rsp+0xE0], xmm1
00007d07b35cf6ec  movaps xmm15, xmm10
00007d07b35cf6f0  addpd xmm15, xmm2
00007d07b35cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d07b35cf6fb  ptest xmm1, xmm1
00007d07b35cf700  jnz 0x00007D07B35D0E10
00007d07b35cf706  vmovaps xmm10, [rsp+0x120]
00007d07b35cf70f  vmovaps [rsp+0x110], xmm15
00007d07b35cf718  movaps xmm1, xmm10
00007d07b35cf71c  addpd xmm1, xmm12
00007d07b35cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007d07b35cf726  ptest xmm15, xmm15
00007d07b35cf72c  jnz 0x00007D07B35D0F53
00007d07b35cf732  vmovaps xmm10, [rsp+0xC0]
00007d07b35cf73b  vmovaps [rsp+0xC0], xmm1
00007d07b35cf744  movaps xmm15, xmm10
00007d07b35cf748  addpd xmm15, xmm12
00007d07b35cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007d07b35cf753  ptest xmm1, xmm1
00007d07b35cf758  jnz 0x00007D07B35D1095
00007d07b35cf75e  vmovaps xmm1, [rsp+0x30]
00007d07b35cf764  vmovaps xmm12, [rsp+0x30]
00007d07b35cf76a  por xmm1, xmm12
00007d07b35cf76f  vmovaps xmm12, [rsp+0x20]
00007d07b35cf775  vmovaps xmm10, [rsp+0x20]
00007d07b35cf77b  por xmm12, xmm10
00007d07b35cf780  vmovaps [rsp+0x20], xmm5
00007d07b35cf786  vmovaps xmm10, [rsp+0x20]
00007d07b35cf78c  por xmm5, xmm10
00007d07b35cf791  vmovaps [rsp+0x20], xmm11
00007d07b35cf797  vmovaps xmm10, [rsp+0x20]
00007d07b35cf79d  por xmm11, xmm10
00007d07b35cf7a2  vmovaps [rsp+0x20], xmm4
00007d07b35cf7a8  vmovaps xmm10, [rsp+0x20]
00007d07b35cf7ae  por xmm4, xmm10
00007d07b35cf7b3  vmovaps [rsp+0x20], xmm8
00007d07b35cf7b9  vmovaps xmm10, [rsp+0x20]
00007d07b35cf7bf  por xmm8, xmm10
00007d07b35cf7c4  vmovaps xmm10, [rsp+0xF0]
00007d07b35cf7cd  vmovaps [rsp+0x20], xmm1
00007d07b35cf7d3  vmovaps xmm1, [rsp+0xF0]
00007d07b35cf7dc  por xmm10, xmm1
00007d07b35cf7e1  lea rax, [r14+0xA0]
00007d07b35cf7e8  movups xmm1, [r13+rax*1]
00007d07b35cf7ee  lea rax, [r14+0xB0]
00007d07b35cf7f5  vmovaps [rsp+0x30], xmm1
00007d07b35cf7fb  movups xmm1, [r13+rax*1]
00007d07b35cf801  vmovaps [rsp+0xF0], xmm1
00007d07b35cf80a  vmovaps [rsp+0x120], xmm15
00007d07b35cf813  movaps xmm1, xmm13
00007d07b35cf817  addpd xmm1, xmm2
00007d07b35cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007d07b35cf820  ptest xmm15, xmm15
00007d07b35cf826  jnz 0x00007D07B35D11ED
00007d07b35cf82c  lea rax, [r14+0xF0]
00007d07b35cf833  movups xmm15, [r13+rax*1]
00007d07b35cf839  vmovaps xmm2, [rsp+0xC0]
00007d07b35cf842  vmovaps [rsp+0xC0], xmm1
00007d07b35cf84b  vmovaps xmm1, [rsp+0xE0]
00007d07b35cf854  vmovaps [rsp+0xE0], xmm15
00007d07b35cf85d  movaps xmm13, xmm2
00007d07b35cf861  addpd xmm13, xmm1
00007d07b35cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007d07b35cf86c  ptest xmm15, xmm15
00007d07b35cf872  jnz 0x00007D07B35D1338
00007d07b35cf878  vmovaps xmm15, [rsp+0x120]
00007d07b35cf881  vmovaps xmm2, [rsp+0xD0]
00007d07b35cf88a  vmovaps [rsp+0xD0], xmm14
00007d07b35cf893  movaps xmm1, xmm15
00007d07b35cf897  addpd xmm1, xmm2
00007d07b35cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007d07b35cf8a0  ptest xmm14, xmm14
00007d07b35cf8a6  jnz 0x00007D07B35D147A
00007d07b35cf8ac  vmovaps xmm15, [rsp+0x100]
00007d07b35cf8b5  vpermilpd xmm15, xmm15, 0x00
00007d07b35cf8bb  vmovaps xmm2, [rsp+0xF0]
00007d07b35cf8c4  vmovaps [rsp+0xF0], xmm1
00007d07b35cf8cd  movaps xmm14, xmm2
00007d07b35cf8d1  mulpd xmm14, xmm15
00007d07b35cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007d07b35cf8dc  ptest xmm1, xmm1
00007d07b35cf8e1  jnz 0x00007D07B35D15BB
00007d07b35cf8e7  vmovaps xmm1, [rsp+0xA0]
00007d07b35cf8f0  vpermilpd xmm1, xmm1, 0x00
00007d07b35cf8f6  vmovaps xmm2, [rsp+0xE0]
00007d07b35cf8ff  vmovaps [rsp+0xE0], xmm14
00007d07b35cf908  movaps xmm15, xmm2
00007d07b35cf90c  mulpd xmm15, xmm1
00007d07b35cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007d07b35cf917  ptest xmm14, xmm14
00007d07b35cf91d  jnz 0x00007D07B35D16FE
00007d07b35cf923  lea rax, [r14+0xE0]
00007d07b35cf92a  movups xmm1, [r13+rax*1]
00007d07b35cf930  vmovaps xmm14, [rsp+0x100]
00007d07b35cf939  vpermilpd xmm14, xmm14, 0x00
00007d07b35cf93f  vmovaps [rsp+0x100], xmm1
00007d07b35cf948  vmovaps xmm1, [rsp+0x30]
00007d07b35cf94e  vmovaps [rsp+0x30], xmm15
00007d07b35cf954  movaps xmm2, xmm1
00007d07b35cf957  mulpd xmm2, xmm14
00007d07b35cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007d07b35cf961  ptest xmm15, xmm15
00007d07b35cf967  jnz 0x00007D07B35D184A
00007d07b35cf96d  vmovaps [rsp+0x120], xmm10
00007d07b35cf976  vmovaps xmm1, [rsp+0x120]
00007d07b35cf97f  por xmm10, xmm1
00007d07b35cf984  movaps [r15+0x300], xmm10
00007d07b35cf98c  vmovaps [rsp+0x120], xmm8
00007d07b35cf995  vmovaps xmm1, [rsp+0x120]
00007d07b35cf99e  por xmm8, xmm1
00007d07b35cf9a3  movaps [r15+0x190], xmm8
00007d07b35cf9ab  vmovaps xmm1, [rsp+0xA0]
00007d07b35cf9b4  vpermilpd xmm1, xmm1, 0x00
00007d07b35cf9ba  vmovaps xmm14, [rsp+0x100]
00007d07b35cf9c3  vmovaps [rsp+0x100], xmm13
00007d07b35cf9cc  movaps xmm15, xmm14
00007d07b35cf9d0  mulpd xmm15, xmm1
00007d07b35cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007d07b35cf9db  ptest xmm13, xmm13
00007d07b35cf9e1  jnz 0x00007D07B35D198B
00007d07b35cf9e7  lea rax, [r14+0x90]
00007d07b35cf9ee  movups xmm1, [r13+rax*1]
00007d07b35cf9f4  vmovaps [rsp+0x120], xmm4
00007d07b35cf9fd  vmovaps xmm14, [rsp+0x120]
00007d07b35cfa06  por xmm4, xmm14
00007d07b35cfa0b  movaps [r15+0x1C0], xmm4
00007d07b35cfa13  vmovaps [rsp+0x120], xmm11
00007d07b35cfa1c  vmovaps xmm14, [rsp+0x120]
00007d07b35cfa25  por xmm11, xmm14
00007d07b35cfa2a  movaps [r15+0x200], xmm11
00007d07b35cfa32  vmovaps [rsp+0x120], xmm5
00007d07b35cfa3b  vmovaps xmm14, [rsp+0x120]
00007d07b35cfa44  por xmm5, xmm14
00007d07b35cfa49  movaps [r15+0x2D0], xmm5
00007d07b35cfa51  vmovaps [rsp+0x120], xmm12
00007d07b35cfa5a  vmovaps xmm14, [rsp+0x120]
00007d07b35cfa63  por xmm12, xmm14
00007d07b35cfa68  movaps [r15+0x2E0], xmm12
00007d07b35cfa70  vmovaps xmm13, [rsp+0x110]
00007d07b35cfa79  vmovaps [rsp+0x110], xmm1
00007d07b35cfa82  vmovaps xmm1, [rsp+0xE0]
00007d07b35cfa8b  vmovaps [rsp+0xE0], xmm15
00007d07b35cfa94  movaps xmm14, xmm13
00007d07b35cfa98  addpd xmm14, xmm1
00007d07b35cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007d07b35cfaa3  ptest xmm15, xmm15
00007d07b35cfaa9  jnz 0x00007D07B35D1AD8
00007d07b35cfaaf  vmovaps xmm1, [rsp+0xA0]
00007d07b35cfab8  vpermilpd xmm1, xmm1, 0x00
00007d07b35cfabe  vmovaps xmm13, [rsp+0x110]
00007d07b35cfac7  vmovaps [rsp+0x110], xmm14
00007d07b35cfad0  movaps xmm15, xmm13
00007d07b35cfad4  mulpd xmm15, xmm1
00007d07b35cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007d07b35cfadf  ptest xmm14, xmm14
00007d07b35cfae5  jnz 0x00007D07B35D1C1B
00007d07b35cfaeb  lea rax, [r14+0x80]
00007d07b35cfaf2  movups xmm1, [r13+rax*1]
00007d07b35cfaf8  vmovaps xmm13, [rsp+0xC0]
00007d07b35cfb01  vmovaps [rsp+0xC0], xmm1
00007d07b35cfb0a  movaps xmm14, xmm13
00007d07b35cfb0e  addpd xmm14, xmm2
00007d07b35cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007d07b35cfb19  ptest xmm1, xmm1
00007d07b35cfb1e  jnz 0x00007D07B35D1D68
00007d07b35cfb24  vmovaps xmm13, [rsp+0x100]
00007d07b35cfb2d  vmovaps xmm2, [rsp+0x30]
00007d07b35cfb33  vmovaps [rsp+0x30], xmm15
00007d07b35cfb39  movaps xmm1, xmm13
00007d07b35cfb3d  addpd xmm1, xmm2
00007d07b35cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007d07b35cfb46  ptest xmm15, xmm15
00007d07b35cfb4c  jnz 0x00007D07B35D1EAB
00007d07b35cfb52  vmovaps xmm15, [rsp+0x20]
00007d07b35cfb58  vmovaps xmm13, [rsp+0x20]
00007d07b35cfb5e  por xmm15, xmm13
00007d07b35cfb63  movaps [r15+0x2F0], xmm15
00007d07b35cfb6b  vmovaps xmm13, [rsp+0xA0]
00007d07b35cfb74  vpermilpd xmm13, xmm13, 0x00
00007d07b35cfb7a  vmovaps [rsp+0x20], xmm1
00007d07b35cfb80  vmovaps xmm1, [rsp+0xC0]
00007d07b35cfb89  vmovaps [rsp+0xA0], xmm15
00007d07b35cfb92  movaps xmm2, xmm1
00007d07b35cfb95  mulpd xmm2, xmm13
00007d07b35cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007d07b35cfb9f  ptest xmm15, xmm15
00007d07b35cfba5  jnz 0x00007D07B35D1FEC
00007d07b35cfbab  lea rax, [r14+0xD0]
00007d07b35cfbb2  movups xmm1, [r13+rax*1]
00007d07b35cfbb8  vmovaps xmm13, [rsp+0xF0]
00007d07b35cfbc1  vmovaps [rsp+0xC0], xmm1
00007d07b35cfbca  vmovaps xmm1, [rsp+0xE0]
00007d07b35cfbd3  vmovaps [rsp+0xE0], xmm14
00007d07b35cfbdc  movaps xmm15, xmm13
00007d07b35cfbe0  addpd xmm15, xmm1
00007d07b35cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007d07b35cfbeb  ptest xmm14, xmm14
00007d07b35cfbf1  jnz 0x00007D07B35D2137
00007d07b35cfbf7  vmovaps xmm1, [rsp+0xB0]
00007d07b35cfc00  vpermilpd xmm1, xmm1, 0x00
00007d07b35cfc06  movaps xmm14, xmm11
00007d07b35cfc0a  mulpd xmm14, xmm1
00007d07b35cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007d07b35cfc15  ptest xmm13, xmm13
00007d07b35cfc1b  jnz 0x00007D07B35D227A
00007d07b35cfc21  movaps [r15+0x260], xmm14
00007d07b35cfc29  vxorps xmm1, xmm1, xmm1
00007d07b35cfc2d  vpbroadcastq xmm1, xmm1
00007d07b35cfc32  movaps [r15+0x1B0], xmm1
00007d07b35cfc3a  vmovaps xmm1, [rsp+0xB0]
00007d07b35cfc43  vpermilpd xmm1, xmm1, 0x00
00007d07b35cfc49  vmovaps xmm11, [rsp+0xC0]
00007d07b35cfc52  vmovaps [rsp+0xC0], xmm15
00007d07b35cfc5b  movaps xmm13, xmm11
00007d07b35cfc5f  mulpd xmm13, xmm1
00007d07b35cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007d07b35cfc6a  ptest xmm15, xmm15
00007d07b35cfc70  jnz 0x00007D07B35D23BD
00007d07b35cfc76  lea rax, [r14+0xC0]
00007d07b35cfc7d  movups xmm1, [r13+rax*1]
00007d07b35cfc83  vmovaps xmm11, [rsp+0x110]
00007d07b35cfc8c  vmovaps [rsp+0xF0], xmm1
00007d07b35cfc95  vmovaps xmm1, [rsp+0x30]
00007d07b35cfc9b  vmovaps [rsp+0x30], xmm14
00007d07b35cfca1  movaps xmm15, xmm11
00007d07b35cfca5  addpd xmm15, xmm1
00007d07b35cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007d07b35cfcb0  ptest xmm14, xmm14
00007d07b35cfcb6  jnz 0x00007D07B35D250A
00007d07b35cfcbc  vmovaps [rsp+0x100], xmm9
00007d07b35cfcc5  vmovaps xmm1, [rsp+0x100]
00007d07b35cfcce  por xmm9, xmm1
00007d07b35cfcd3  movaps [r15+0x270], xmm9
00007d07b35cfcdb  vmovaps [rsp+0x100], xmm6
00007d07b35cfce4  vmovaps xmm1, [rsp+0x100]
00007d07b35cfced  por xmm6, xmm1
00007d07b35cfcf1  movaps [r15+0x1A0], xmm6
00007d07b35cfcf9  vmovaps xmm14, [rsp+0xB0]
00007d07b35cfd02  vpermilpd xmm14, xmm14, 0x00
00007d07b35cfd08  vmovaps xmm6, [rsp+0xF0]
00007d07b35cfd11  vmovaps [rsp+0xF0], xmm1
00007d07b35cfd1a  movaps xmm11, xmm6
00007d07b35cfd1e  mulpd xmm11, xmm14
00007d07b35cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007d07b35cfd29  ptest xmm1, xmm1
00007d07b35cfd2e  jnz 0x00007D07B35D264D
00007d07b35cfd34  lea rax, [r14+0x20]
00007d07b35cfd38  movups xmm1, [r13+rax*1]
00007d07b35cfd3e  movaps [r15+0x110], xmm1
00007d07b35cfd46  vmovaps xmm6, [rsp+0xE0]
00007d07b35cfd4f  vmovaps [rsp+0xE0], xmm1
00007d07b35cfd58  movaps xmm14, xmm6
00007d07b35cfd5c  addpd xmm14, xmm2
00007d07b35cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007d07b35cfd67  ptest xmm1, xmm1
00007d07b35cfd6c  jnz 0x00007D07B35D279A
00007d07b35cfd72  vmovaps xmm1, [rsp+0xB0]
00007d07b35cfd7b  vpermilpd xmm1, xmm1, 0x00
00007d07b35cfd81  movaps xmm6, xmm5
00007d07b35cfd84  mulpd xmm6, xmm1
00007d07b35cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007d07b35cfd8d  ptest xmm2, xmm2
00007d07b35cfd92  jnz 0x00007D07B35D28DC
00007d07b35cfd98  vmovaps xmm5, [rsp+0x20]
00007d07b35cfd9e  movaps xmm1, xmm5
00007d07b35cfda1  addpd xmm1, xmm13
00007d07b35cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007d07b35cfdab  ptest xmm2, xmm2
00007d07b35cfdb0  jnz 0x00007D07B35D2A1C
00007d07b35cfdb6  vmovaps xmm13, [rsp+0x80]
00007d07b35cfdbf  vpermilpd xmm13, xmm13, 0x00
00007d07b35cfdc5  vmovaps xmm2, [rsp+0xE0]
00007d07b35cfdce  vmovaps [rsp+0x20], xmm1
00007d07b35cfdd4  movaps xmm5, xmm2
00007d07b35cfdd7  mulpd xmm5, xmm13
00007d07b35cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007d07b35cfde1  ptest xmm1, xmm1
00007d07b35cfde6  jnz 0x00007D07B35D2B5D
00007d07b35cfdec  vmovaps xmm1, [rsp+0x80]
00007d07b35cfdf5  vpermilpd xmm1, xmm1, 0x00
00007d07b35cfdfb  movaps xmm13, xmm10
00007d07b35cfdff  mulpd xmm13, xmm1
00007d07b35cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007d07b35cfe0a  ptest xmm2, xmm2
00007d07b35cfe0f  jnz 0x00007D07B35D2C9E
00007d07b35cfe15  vmovaps xmm10, [rsp+0x30]
00007d07b35cfe1b  movaps xmm1, xmm15
00007d07b35cfe1f  addpd xmm1, xmm10
00007d07b35cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007d07b35cfe29  ptest xmm2, xmm2
00007d07b35cfe2e  jnz 0x00007D07B35D2DE1
00007d07b35cfe34  vmovaps xmm10, [rsp+0xC0]
00007d07b35cfe3d  movaps xmm15, xmm10
00007d07b35cfe41  addpd xmm15, xmm11
00007d07b35cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007d07b35cfe4c  ptest xmm2, xmm2
00007d07b35cfe51  jnz 0x00007D07B35D2F23
00007d07b35cfe57  vmovaps xmm11, [rsp+0x80]
00007d07b35cfe60  vpermilpd xmm11, xmm11, 0x00
00007d07b35cfe66  movaps xmm10, xmm12
00007d07b35cfe6a  mulpd xmm10, xmm11
00007d07b35cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007d07b35cfe75  ptest xmm2, xmm2
00007d07b35cfe7a  jnz 0x00007D07B35D3067
00007d07b35cfe80  vmovaps xmm12, [rsp+0x80]
00007d07b35cfe89  vpermilpd xmm12, xmm12, 0x00
00007d07b35cfe8f  vmovaps xmm2, [rsp+0xA0]
00007d07b35cfe98  vmovaps [rsp+0x30], xmm1
00007d07b35cfe9e  movaps xmm11, xmm2
00007d07b35cfea2  mulpd xmm11, xmm12
00007d07b35cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007d07b35cfead  ptest xmm1, xmm1
00007d07b35cfeb2  jnz 0x00007D07B35D31AB
00007d07b35cfeb8  movaps xmm1, xmm14
00007d07b35cfebc  addpd xmm1, xmm6
00007d07b35cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007d07b35cfec5  ptest xmm12, xmm12
00007d07b35cfecb  jnz 0x00007D07B35D32EE
00007d07b35cfed1  vmovaps xmm12, [rsp+0x20]
00007d07b35cfed7  movaps xmm14, xmm12
00007d07b35cfedb  addpd xmm14, xmm5
00007d07b35cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007d07b35cfee6  ptest xmm6, xmm6
00007d07b35cfeeb  jnz 0x00007D07B35D342F
00007d07b35cfef1  vmovaps xmm12, [rsp+0x90]
00007d07b35cfefa  vpermilpd xmm12, xmm12, 0x00
00007d07b35cff00  movaps xmm6, xmm9
00007d07b35cff04  mulpd xmm6, xmm12
00007d07b35cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007d07b35cff0e  ptest xmm5, xmm5
00007d07b35cff13  jnz 0x00007D07B35D3572
00007d07b35cff19  movaps xmm12, xmm15
00007d07b35cff1d  addpd xmm12, xmm13
00007d07b35cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007d07b35cff28  ptest xmm9, xmm9
00007d07b35cff2e  jnz 0x00007D07B35D36B4
00007d07b35cff34  vmovaps xmm13, [rsp+0x30]
00007d07b35cff3a  movaps xmm15, xmm13
00007d07b35cff3e  addpd xmm15, xmm10
00007d07b35cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007d07b35cff49  ptest xmm9, xmm9
00007d07b35cff4f  jnz 0x00007D07B35D37F8
00007d07b35cff55  vmovaps xmm13, [rsp+0xD0]
00007d07b35cff5e  vmovaps xmm10, [rsp+0xD0]
00007d07b35cff67  por xmm13, xmm10
00007d07b35cff6c  movaps [r15+0x250], xmm13
00007d07b35cff74  vmovaps [rsp+0x20], xmm7
00007d07b35cff7a  vmovaps xmm13, [rsp+0x20]
00007d07b35cff80  por xmm7, xmm13
00007d07b35cff85  movaps [r15+0x2A0], xmm7
00007d07b35cff8d  vmovaps [rsp+0x20], xmm3
00007d07b35cff93  vmovaps xmm13, [rsp+0x20]
00007d07b35cff99  por xmm3, xmm13
00007d07b35cff9e  movaps [r15+0x1D0], xmm3
00007d07b35cffa6  lea rax, [r14+0x40]
00007d07b35cffaa  movups xmm13, [r13+rax*1]
00007d07b35cffb0  movaps [r15+0x2C0], xmm13
00007d07b35cffb8  vmovaps xmm10, [rsp+0x90]
00007d07b35cffc1  vpermilpd xmm10, xmm10, 0x00
00007d07b35cffc7  movaps xmm9, xmm8
00007d07b35cffcb  mulpd xmm9, xmm10
00007d07b35cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007d07b35cffd6  ptest xmm5, xmm5
00007d07b35cffdb  jnz 0x00007D07B35D3946
00007d07b35cffe1  movaps xmm10, xmm1
00007d07b35cffe5  addpd xmm10, xmm11
00007d07b35cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007d07b35cfff0  ptest xmm8, xmm8
00007d07b35cfff6  jnz 0x00007D07B35D3A8A
00007d07b35cfffc  movaps xmm1, xmm14
00007d07b35d0000  addpd xmm1, xmm6
00007d07b35d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007d07b35d0009  ptest xmm11, xmm11
00007d07b35d000f  jnz 0x00007D07B35D3BCD
00007d07b35d0015  vmovaps xmm14, [rsp+0x90]
00007d07b35d001e  vpermilpd xmm14, xmm14, 0x00
00007d07b35d0024  movaps xmm11, xmm13
00007d07b35d0028  mulpd xmm11, xmm14
00007d07b35d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007d07b35d0033  ptest xmm8, xmm8
00007d07b35d0039  jnz 0x00007D07B35D3D0E
00007d07b35d003f  vmovaps xmm14, [rsp+0x90]
00007d07b35d0048  vpermilpd xmm14, xmm14, 0x00
00007d07b35d004e  vmovaps xmm8, [rsp+0x10]
00007d07b35d0054  movaps xmm13, xmm8
00007d07b35d0058  mulpd xmm13, xmm14
00007d07b35d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007d07b35d0063  ptest xmm6, xmm6
00007d07b35d0068  jnz 0x00007D07B35D3E52
00007d07b35d006e  vmovaps xmm14, [rsp+0x60]
00007d07b35d0074  vpermilpd xmm14, xmm14, 0x00
00007d07b35d007a  movaps xmm8, xmm7
00007d07b35d007e  mulpd xmm8, xmm14
00007d07b35d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007d07b35d0089  ptest xmm6, xmm6
00007d07b35d008e  jnz 0x00007D07B35D3F96
00007d07b35d0094  movaps xmm14, xmm12
00007d07b35d0098  addpd xmm14, xmm9
00007d07b35d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007d07b35d00a3  ptest xmm7, xmm7
00007d07b35d00a8  jnz 0x00007D07B35D40D9
00007d07b35d00ae  vmovaps xmm12, [rsp+0x60]
00007d07b35d00b4  vpermilpd xmm12, xmm12, 0x00
00007d07b35d00ba  vmovaps xmm7, [rsp+0xF0]
00007d07b35d00c3  movaps xmm9, xmm7
00007d07b35d00c7  mulpd xmm9, xmm12
00007d07b35d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007d07b35d00d2  ptest xmm6, xmm6
00007d07b35d00d7  jnz 0x00007D07B35D421D
00007d07b35d00dd  movaps xmm12, xmm15
00007d07b35d00e1  addpd xmm12, xmm11
00007d07b35d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007d07b35d00ec  ptest xmm7, xmm7
00007d07b35d00f1  jnz 0x00007D07B35D4360
00007d07b35d00f7  vmovaps xmm15, [rsp+0x60]
00007d07b35d00fd  vpermilpd xmm15, xmm15, 0x00
00007d07b35d0103  vmovaps xmm7, [rsp+0x40]
00007d07b35d0109  movaps xmm11, xmm7
00007d07b35d010d  mulpd xmm11, xmm15
00007d07b35d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007d07b35d0118  ptest xmm6, xmm6
00007d07b35d011d  jnz 0x00007D07B35D44A4
00007d07b35d0123  movaps xmm15, xmm10
00007d07b35d0127  addpd xmm15, xmm13
00007d07b35d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007d07b35d0132  ptest xmm7, xmm7
00007d07b35d0137  jnz 0x00007D07B35D45E7
00007d07b35d013d  vmovaps xmm13, [rsp+0x60]
00007d07b35d0143  vpermilpd xmm13, xmm13, 0x00
00007d07b35d0149  vmovaps xmm7, [rsp+0x50]
00007d07b35d014f  movaps xmm10, xmm7
00007d07b35d0153  mulpd xmm10, xmm13
00007d07b35d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007d07b35d015e  ptest xmm6, xmm6
00007d07b35d0163  jnz 0x00007D07B35D472B
00007d07b35d0169  movaps xmm13, xmm1
00007d07b35d016d  addpd xmm13, xmm8
00007d07b35d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007d07b35d0178  ptest xmm7, xmm7
00007d07b35d017d  jnz 0x00007D07B35D486E
00007d07b35d0183  lea rax, [r14+0x70]
00007d07b35d0187  movups xmm1, [r13+rax*1]
00007d07b35d018d  movaps [r15+0x240], xmm1
00007d07b35d0195  movaps xmm8, xmm14
00007d07b35d0199  addpd xmm8, xmm9
00007d07b35d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007d07b35d01a4  ptest xmm7, xmm7
00007d07b35d01a9  jnz 0x00007D07B35D49BB
00007d07b35d01af  movaps [r15+0x170], xmm8
00007d07b35d01b7  vmovaps xmm14, [rsp+0x70]
00007d07b35d01bd  vpermilpd xmm14, xmm14, 0x00
00007d07b35d01c3  movaps xmm9, xmm1
00007d07b35d01c7  mulpd xmm9, xmm14
00007d07b35d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007d07b35d01d2  ptest xmm7, xmm7
00007d07b35d01d7  jnz 0x00007D07B35D4AFF
00007d07b35d01dd  vmovaps xmm1, [rsp+0x70]
00007d07b35d01e3  vpermilpd xmm1, xmm1, 0x00
00007d07b35d01e9  movaps xmm14, xmm4
00007d07b35d01ed  mulpd xmm14, xmm1
00007d07b35d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007d07b35d01f8  ptest xmm7, xmm7
00007d07b35d01fd  jnz 0x00007D07B35D4C42
00007d07b35d0203  movaps [r15+0x180], xmm14
00007d07b35d020b  movaps xmm1, xmm12
00007d07b35d020f  addpd xmm1, xmm11
00007d07b35d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007d07b35d0219  ptest xmm7, xmm7
00007d07b35d021e  jnz 0x00007D07B35D4D84
00007d07b35d0224  movaps [r15+0x210], xmm1
00007d07b35d022c  movups xmm12, [r13+r14*1]
00007d07b35d0232  lea rax, [r14+0x10]
00007d07b35d0236  movups xmm11, [r13+rax*1]
00007d07b35d023c  movaps [r15+0x230], xmm11
00007d07b35d0244  movaps xmm7, xmm15
00007d07b35d0248  addpd xmm7, xmm10
00007d07b35d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007d07b35d0252  ptest xmm6, xmm6
00007d07b35d0257  jnz 0x00007D07B35D4EDA
00007d07b35d025d  movaps [r15+0x130], xmm7
00007d07b35d0265  vmovaps xmm15, [rsp+0x70]
00007d07b35d026b  vpermilpd xmm15, xmm15, 0x00
00007d07b35d0271  movaps xmm10, xmm11
00007d07b35d0275  mulpd xmm10, xmm15
00007d07b35d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007d07b35d0280  ptest xmm6, xmm6
00007d07b35d0285  jnz 0x00007D07B35D501C
00007d07b35d028b  movaps [r15+0x220], xmm10
00007d07b35d0293  vmovaps xmm15, [rsp+0x70]
00007d07b35d0299  vpermilpd xmm15, xmm15, 0x00
00007d07b35d029f  movaps xmm11, xmm12
00007d07b35d02a3  mulpd xmm11, xmm15
00007d07b35d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007d07b35d02ae  ptest xmm6, xmm6
00007d07b35d02b3  jnz 0x00007D07B35D5160
00007d07b35d02b9  movaps xmm15, xmm13
00007d07b35d02bd  addpd xmm15, xmm9
00007d07b35d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007d07b35d02c8  ptest xmm12, xmm12
00007d07b35d02ce  jnz 0x00007D07B35D52A4
00007d07b35d02d4  movaps [r15+0x140], xmm15
00007d07b35d02dc  movaps xmm13, xmm8
00007d07b35d02e0  addpd xmm13, xmm14
00007d07b35d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007d07b35d02eb  ptest xmm12, xmm12
00007d07b35d02f1  jnz 0x00007D07B35D53E8
00007d07b35d02f7  movaps [r15+0x150], xmm13
00007d07b35d02ff  movaps xmm14, xmm1
00007d07b35d0303  addpd xmm14, xmm10
00007d07b35d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007d07b35d030e  ptest xmm12, xmm12
00007d07b35d0314  jnz 0x00007D07B35D552C
00007d07b35d031a  movaps [r15+0x160], xmm14
00007d07b35d0322  movaps xmm1, xmm7
00007d07b35d0325  addpd xmm1, xmm11
00007d07b35d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007d07b35d032f  ptest xmm12, xmm12
00007d07b35d0335  jnz 0x00007D07B35D566F
00007d07b35d033b  movaps [r15+0x120], xmm1
00007d07b35d0343  mov eax, 0x430920
00007d07b35d0348  movups [r13+rax*1], xmm15
00007d07b35d034e  mov eax, 0x430930
00007d07b35d0353  movups [r13+rax*1], xmm13
00007d07b35d0359  mov eax, 0x430940
00007d07b35d035e  movups [r13+rax*1], xmm14
00007d07b35d0364  mov eax, 0x430950
00007d07b35d0369  movups [r13+rax*1], xmm1
00007d07b35d036f  mov eax, [r15+0x108]
00007d07b35d0376  sahf
00007d07b35d0377  jnz 0x00007D07B35D03A9
00007d07b35d0379  cmp dword ptr [r15+0x318], 0x00
00007d07b35d0381  jz 0x00007D07B35DB900
00007d07b35d0387  nop [rax+rax*1], ax
00007d07b35d0390  nop [rax+rax*1], eax
00007d07b35d0398  mov eax, 0x410444
00007d07b35d039d  mov [r15+0x100], rax
00007d07b35d03a4  jmp 0x00007D07B33FE110
00007d07b35d03a9  cmp dword ptr [r15+0x318], 0x00
00007d07b35d03b1  jz 0x00007D07B35D57E0
00007d07b35d03b7  nop [rax+rax*1], ax
00007d07b35d03c0  nop [rax+rax*1], eax
00007d07b35d03c8  mov eax, 0x410278
00007d07b35d03cd  mov [r15+0x100], rax
00007d07b35d03d4  jmp 0x00007D07B33FE110
00007d07b35d03d9  int3
00007d07b35d03da  call 0x00007D07B34B52F0
00007d07b35d03df  jmp 0x00007D07B35CF016
00007d07b35d03e4  call 0x00007D07B34C4620
00007d07b35d03e9  jmp 0x00007D07B35CF023
00007d07b35d03ee  call 0x00007D07B34C33A0
00007d07b35d03f3  jmp 0x00007D07B35CF035
00007d07b35d03f8  call 0x00007D07B34C2120
00007d07b35d03fd  jmp 0x00007D07B35CF03F
00007d07b35d0402  call 0x00007D07B34C0860
00007d07b35d0407  jmp 0x00007D07B35CF067
00007d07b35d040c  call 0x00007D07B34BF5F0
00007d07b35d0411  jmp 0x00007D07B35CF073
00007d07b35d0416  call 0x00007D07B34C0860
00007d07b35d041b  jmp 0x00007D07B35CF0A5
00007d07b35d0420  call 0x00007D07B34BF5F0
00007d07b35d0425  jmp 0x00007D07B35CF0B1
00007d07b35d042a  call 0x00007D07B34C4740
00007d07b35d042f  jmp 0x00007D07B35CF0BE
00007d07b35d0434  call 0x00007D07B34B5400
00007d07b35d0439  jmp 0x00007D07B35CF0CB
00007d07b35d043e  call 0x00007D07B34B52F0
00007d07b35d0443  jmp 0x00007D07B35CF0D8
00007d07b35d0448  call 0x00007D07B34C4620
00007d07b35d044d  jmp 0x00007D07B35CF0E5
00007d07b35d0452  call 0x00007D07B34C0860
00007d07b35d0457  jmp 0x00007D07B35CF10D
00007d07b35d045c  call 0x00007D07B34BF5F0
00007d07b35d0461  jmp 0x00007D07B35CF119
00007d07b35d0466  call 0x00007D07B3409D70
00007d07b35d046b  jmp 0x00007D07B35CF11F
00007d07b35d0470  call 0x00007D07B34BE9C0
00007d07b35d0475  jmp 0x00007D07B35CF129
00007d07b35d047a  call 0x00007D07B34C0860
00007d07b35d047f  jmp 0x00007D07B35CF151
00007d07b35d0484  call 0x00007D07B34BF5F0
00007d07b35d0489  jmp 0x00007D07B35CF15D
00007d07b35d048e  call 0x00007D07B34BD750
00007d07b35d0493  jmp 0x00007D07B35CF16A
00007d07b35d0498  call 0x00007D07B34BC4E0
00007d07b35d049d  jmp 0x00007D07B35CF177
00007d07b35d04a2  call 0x00007D07B34C4740
00007d07b35d04a7  jmp 0x00007D07B35CF184
00007d07b35d04ac  call 0x00007D07B34B5400
00007d07b35d04b1  jmp 0x00007D07B35CF191
00007d07b35d04b6  call 0x00007D07B34B52F0
00007d07b35d04bb  jmp 0x00007D07B35CF19E
00007d07b35d04c0  call 0x00007D07B34C4620
00007d07b35d04c5  jmp 0x00007D07B35CF1AB
00007d07b35d04ca  call 0x00007D07B34C0860
00007d07b35d04cf  jmp 0x00007D07B35CF1BE
00007d07b35d04d4  call 0x00007D07B34BB270
00007d07b35d04d9  jmp 0x00007D07B35CF1CB
00007d07b35d04de  call 0x00007D07B34BA000
00007d07b35d04e3  jmp 0x00007D07B35CF1D8
00007d07b35d04e8  call 0x00007D07B34B8D90
00007d07b35d04ed  jmp 0x00007D07B35CF1E5
00007d07b35d04f2  call 0x00007D07B34B8A20
00007d07b35d04f7  jmp 0x00007D07B35CF1F2
00007d07b35d04fc  call 0x00007D07B34B5400
00007d07b35d0501  jmp 0x00007D07B35CF1FC
00007d07b35d0506  call 0x00007D07B34C2240
00007d07b35d050b  jmp 0x00007D07B35CF206
00007d07b35d0510  call 0x00007D07B34B52F0
00007d07b35d0515  jmp 0x00007D07B35CF210
00007d07b35d051a  call 0x00007D07B34C2120
00007d07b35d051f  jmp 0x00007D07B35CF21A
00007d07b35d0524  call 0x00007D07B34B77B0
00007d07b35d0529  jmp 0x00007D07B35CF224
00007d07b35d052e  call 0x00007D07B34B6550
00007d07b35d0533  jmp 0x00007D07B35CF22E
00007d07b35d0538  call 0x00007D07B34BFD50
00007d07b35d053d  jmp 0x00007D07B35CF240
00007d07b35d0542  call 0x00007D07B34B8EA0
00007d07b35d0547  jmp 0x00007D07B35CF24A
00007d07b35d054c  call 0x00007D07B34BFC30
00007d07b35d0551  jmp 0x00007D07B35CF257
00007d07b35d0556  call 0x00007D07B34B8D90
00007d07b35d055b  jmp 0x00007D07B35CF264
00007d07b35d0560  call 0x00007D07B34C2240
00007d07b35d0565  jmp 0x00007D07B35CF271
00007d07b35d056a  call 0x00007D07B34B5400
00007d07b35d056f  jmp 0x00007D07B35CF27E
00007d07b35d0574  call 0x00007D07B34B52F0
00007d07b35d0579  jmp 0x00007D07B35CF28B
00007d07b35d057e  call 0x00007D07B34C2120
00007d07b35d0583  jmp 0x00007D07B35CF298
00007d07b35d0588  call 0x00007D07B34B52F0
00007d07b35d058d  jmp 0x00007D07B35CF2AB
00007d07b35d0592  call 0x00007D07B34B52F0
00007d07b35d0597  jmp 0x00007D07B35CF2BE
00007d07b35d059c  call 0x00007D07B34B52F0
00007d07b35d05a1  jmp 0x00007D07B35CF2D1
00007d07b35d05a6  call 0x00007D07B34B52F0
00007d07b35d05ab  jmp 0x00007D07B35CF2E4
00007d07b35d05b0  call 0x00007D07B34C2240
00007d07b35d05b5  jmp 0x00007D07B35CF2F9
00007d07b35d05ba  call 0x00007D07B34C2240
00007d07b35d05bf  jmp 0x00007D07B35CF30C
00007d07b35d05c4  call 0x00007D07B34C2120
00007d07b35d05c9  jmp 0x00007D07B35CF319
00007d07b35d05ce  call 0x00007D07B34B52F0
00007d07b35d05d3  jmp 0x00007D07B35CF32C
00007d07b35d05d8  call 0x00007D07B34B52F0
00007d07b35d05dd  jmp 0x00007D07B35CF34F
00007d07b35d05e2  call 0x00007D07B34B52F0
00007d07b35d05e7  jmp 0x00007D07B35CF362
00007d07b35d05ec  call 0x00007D07B33FF540
00007d07b35d05f1  jmp 0x00007D07B35CF380
00007d07b35d05f6  call 0x00007D07B3408C20
00007d07b35d05fb  jmp 0x00007D07B35CF38A
00007d07b35d0600  call 0x00007D07B34D6600
00007d07b35d0605  jmp 0x00007D07B35CF396
00007d07b35d060a  call 0x00007D07B33FF540
00007d07b35d060f  jmp 0x00007D07B35CF3A6
00007d07b35d0614  call 0x00007D07B34C0370
00007d07b35d0619  jmp 0x00007D07B35CF3D4
00007d07b35d061e  call 0x00007D07B34BF100
00007d07b35d0623  jmp 0x00007D07B35CF3DD
00007d07b35d0628  call 0x00007D07B34C0370
00007d07b35d062d  jmp 0x00007D07B35CF43B
00007d07b35d0632  call 0x00007D07B34BF100
00007d07b35d0637  jmp 0x00007D07B35CF444
00007d07b35d063c  call 0x00007D07B34C0370
00007d07b35d0641  jmp 0x00007D07B35CF48B
00007d07b35d0646  call 0x00007D07B34BF100
00007d07b35d064b  jmp 0x00007D07B35CF494
00007d07b35d0650  call 0x00007D07B340B720
00007d07b35d0655  jmp 0x00007D07B35CF4D7
00007d07b35d065a  call 0x00007D07B34B47C0
00007d07b35d065f  jmp 0x00007D07B35CF4EA
00007d07b35d0664  call 0x00007D07B3408B00
00007d07b35d0669  jmp 0x00007D07B35CF501
00007d07b35d066e  call 0x00007D07B33FF430
00007d07b35d0673  jmp 0x00007D07B35CF514
00007d07b35d0678  call 0x00007D07B33FF430
00007d07b35d067d  jmp 0x00007D07B35CF527
00007d07b35d0682  sub rsp, 0x08
00007d07b35d0686  push rax
00007d07b35d0687  push rcx
00007d07b35d0688  push rdx
00007d07b35d0689  push rdi
00007d07b35d068a  push rsi
00007d07b35d068b  push r8
00007d07b35d068d  push r9
00007d07b35d068f  push r10
00007d07b35d0691  push r11
00007d07b35d0693  sub rsp, 0xF0
00007d07b35d069a  vmovaps [rsp], xmm0
00007d07b35d069f  vmovaps [rsp+0x10], xmm2
00007d07b35d06a5  vmovaps [rsp+0x20], xmm3
00007d07b35d06ab  vmovaps [rsp+0x30], xmm4
00007d07b35d06b1  vmovaps [rsp+0x40], xmm5
00007d07b35d06b7  vmovaps [rsp+0x50], xmm6
00007d07b35d06bd  vmovaps [rsp+0x60], xmm7
00007d07b35d06c3  vmovaps [rsp+0x70], xmm8
00007d07b35d06c9  vmovaps [rsp+0x80], xmm9
00007d07b35d06d2  vmovaps [rsp+0x90], xmm10
00007d07b35d06db  vmovaps [rsp+0xA0], xmm11
00007d07b35d06e4  vmovaps [rsp+0xB0], xmm12
00007d07b35d06ed  vmovaps [rsp+0xC0], xmm13
00007d07b35d06f6  vmovaps [rsp+0xD0], xmm14
00007d07b35d06ff  vmovaps [rsp+0xE0], xmm15
00007d07b35d0708  sub rsp, 0x30
00007d07b35d070c  movaps [rsp], xmm1
00007d07b35d0710  movaps [rsp+0x10], xmm15
00007d07b35d0716  movaps [rsp+0x20], xmm14
00007d07b35d071c  lea rdi, [rsp]
00007d07b35d0720  mov esi, 0x00
00007d07b35d0725  mov rax, 0x5D0AA712D530
00007d07b35d072f  call rax
00007d07b35d0731  movaps xmm1, [rsp]
00007d07b35d0735  add rsp, 0x30
00007d07b35d0739  vmovaps xmm0, [rsp]
00007d07b35d073e  vmovaps xmm2, [rsp+0x10]
00007d07b35d0744  vmovaps xmm3, [rsp+0x20]
00007d07b35d074a  vmovaps xmm4, [rsp+0x30]
00007d07b35d0750  vmovaps xmm5, [rsp+0x40]
00007d07b35d0756  vmovaps xmm6, [rsp+0x50]
00007d07b35d075c  vmovaps xmm7, [rsp+0x60]
00007d07b35d0762  vmovaps xmm8, [rsp+0x70]
00007d07b35d0768  vmovaps xmm9, [rsp+0x80]
00007d07b35d0771  vmovaps xmm10, [rsp+0x90]
00007d07b35d077a  vmovaps xmm11, [rsp+0xA0]
00007d07b35d0783  vmovaps xmm12, [rsp+0xB0]
00007d07b35d078c  vmovaps xmm13, [rsp+0xC0]
00007d07b35d0795  vmovaps xmm14, [rsp+0xD0]
00007d07b35d079e  vmovaps xmm15, [rsp+0xE0]
00007d07b35d07a7  add rsp, 0xF0
00007d07b35d07ae  pop r11
00007d07b35d07b0  pop r10
00007d07b35d07b2  pop r9
00007d07b35d07b4  pop r8
00007d07b35d07b6  pop rsi
00007d07b35d07b7  pop rdi
00007d07b35d07b8  pop rdx
00007d07b35d07b9  pop rcx
00007d07b35d07ba  pop rax
00007d07b35d07bb  add rsp, 0x08
00007d07b35d07bf  jmp 0x00007D07B35CF581
00007d07b35d07c4  sub rsp, 0x08
00007d07b35d07c8  push rax
00007d07b35d07c9  push rcx
00007d07b35d07ca  push rdx
00007d07b35d07cb  push rdi
00007d07b35d07cc  push rsi
00007d07b35d07cd  push r8
00007d07b35d07cf  push r9
00007d07b35d07d1  push r10
00007d07b35d07d3  push r11
00007d07b35d07d5  sub rsp, 0xF0
00007d07b35d07dc  vmovaps [rsp], xmm0
00007d07b35d07e1  vmovaps [rsp+0x10], xmm1
00007d07b35d07e7  vmovaps [rsp+0x20], xmm2
00007d07b35d07ed  vmovaps [rsp+0x30], xmm3
00007d07b35d07f3  vmovaps [rsp+0x40], xmm4
00007d07b35d07f9  vmovaps [rsp+0x50], xmm5
00007d07b35d07ff  vmovaps [rsp+0x60], xmm6
00007d07b35d0805  vmovaps [rsp+0x70], xmm7
00007d07b35d080b  vmovaps [rsp+0x80], xmm8
00007d07b35d0814  vmovaps [rsp+0x90], xmm9
00007d07b35d081d  vmovaps [rsp+0xA0], xmm10
00007d07b35d0826  vmovaps [rsp+0xB0], xmm11
00007d07b35d082f  vmovaps [rsp+0xC0], xmm12
00007d07b35d0838  vmovaps [rsp+0xD0], xmm14
00007d07b35d0841  vmovaps [rsp+0xE0], xmm15
00007d07b35d084a  sub rsp, 0x30
00007d07b35d084e  movaps [rsp], xmm13
00007d07b35d0853  movaps [rsp+0x10], xmm1
00007d07b35d0858  movaps [rsp+0x20], xmm14
00007d07b35d085e  lea rdi, [rsp]
00007d07b35d0862  mov esi, 0x00
00007d07b35d0867  mov rax, 0x5D0AA712D530
00007d07b35d0871  call rax
00007d07b35d0873  movaps xmm13, [rsp]
00007d07b35d0878  add rsp, 0x30
00007d07b35d087c  vmovaps xmm0, [rsp]
00007d07b35d0881  vmovaps xmm1, [rsp+0x10]
00007d07b35d0887  vmovaps xmm2, [rsp+0x20]
00007d07b35d088d  vmovaps xmm3, [rsp+0x30]
00007d07b35d0893  vmovaps xmm4, [rsp+0x40]
00007d07b35d0899  vmovaps xmm5, [rsp+0x50]
00007d07b35d089f  vmovaps xmm6, [rsp+0x60]
00007d07b35d08a5  vmovaps xmm7, [rsp+0x70]
00007d07b35d08ab  vmovaps xmm8, [rsp+0x80]
00007d07b35d08b4  vmovaps xmm9, [rsp+0x90]
00007d07b35d08bd  vmovaps xmm10, [rsp+0xA0]
00007d07b35d08c6  vmovaps xmm11, [rsp+0xB0]
00007d07b35d08cf  vmovaps xmm12, [rsp+0xC0]
00007d07b35d08d8  vmovaps xmm14, [rsp+0xD0]
00007d07b35d08e1  vmovaps xmm15, [rsp+0xE0]
00007d07b35d08ea  add rsp, 0xF0
00007d07b35d08f1  pop r11
00007d07b35d08f3  pop r10
00007d07b35d08f5  pop r9
00007d07b35d08f7  pop r8
00007d07b35d08f9  pop rsi
00007d07b35d08fa  pop rdi
00007d07b35d08fb  pop rdx
00007d07b35d08fc  pop rcx
00007d07b35d08fd  pop rax
00007d07b35d08fe  add rsp, 0x08
00007d07b35d0902  jmp 0x00007D07B35CF5CF
00007d07b35d0907  sub rsp, 0x08
00007d07b35d090b  push rax
00007d07b35d090c  push rcx
00007d07b35d090d  push rdx
00007d07b35d090e  push rdi
00007d07b35d090f  push rsi
00007d07b35d0910  push r8
00007d07b35d0912  push r9
00007d07b35d0914  push r10
00007d07b35d0916  push r11
00007d07b35d0918  sub rsp, 0xF0
00007d07b35d091f  vmovaps [rsp], xmm0
00007d07b35d0924  vmovaps [rsp+0x10], xmm1
00007d07b35d092a  vmovaps [rsp+0x20], xmm2
00007d07b35d0930  vmovaps [rsp+0x30], xmm3
00007d07b35d0936  vmovaps [rsp+0x40], xmm4
00007d07b35d093c  vmovaps [rsp+0x50], xmm5
00007d07b35d0942  vmovaps [rsp+0x60], xmm6
00007d07b35d0948  vmovaps [rsp+0x70], xmm7
00007d07b35d094e  vmovaps [rsp+0x80], xmm8
00007d07b35d0957  vmovaps [rsp+0x90], xmm9
00007d07b35d0960  vmovaps [rsp+0xA0], xmm10
00007d07b35d0969  vmovaps [rsp+0xB0], xmm11
00007d07b35d0972  vmovaps [rsp+0xC0], xmm12
00007d07b35d097b  vmovaps [rsp+0xD0], xmm13
00007d07b35d0984  vmovaps [rsp+0xE0], xmm14
00007d07b35d098d  sub rsp, 0x30
00007d07b35d0991  movaps [rsp], xmm15
00007d07b35d0996  movaps [rsp+0x10], xmm14
00007d07b35d099c  movaps [rsp+0x20], xmm1
00007d07b35d09a1  lea rdi, [rsp]
00007d07b35d09a5  mov esi, 0x00
00007d07b35d09aa  mov rax, 0x5D0AA712D530
00007d07b35d09b4  call rax
00007d07b35d09b6  movaps xmm15, [rsp]
00007d07b35d09bb  add rsp, 0x30
00007d07b35d09bf  vmovaps xmm0, [rsp]
00007d07b35d09c4  vmovaps xmm1, [rsp+0x10]
00007d07b35d09ca  vmovaps xmm2, [rsp+0x20]
00007d07b35d09d0  vmovaps xmm3, [rsp+0x30]
00007d07b35d09d6  vmovaps xmm4, [rsp+0x40]
00007d07b35d09dc  vmovaps xmm5, [rsp+0x50]
00007d07b35d09e2  vmovaps xmm6, [rsp+0x60]
00007d07b35d09e8  vmovaps xmm7, [rsp+0x70]
00007d07b35d09ee  vmovaps xmm8, [rsp+0x80]
00007d07b35d09f7  vmovaps xmm9, [rsp+0x90]
00007d07b35d0a00  vmovaps xmm10, [rsp+0xA0]
00007d07b35d0a09  vmovaps xmm11, [rsp+0xB0]
00007d07b35d0a12  vmovaps xmm12, [rsp+0xC0]
00007d07b35d0a1b  vmovaps xmm13, [rsp+0xD0]
00007d07b35d0a24  vmovaps xmm14, [rsp+0xE0]
00007d07b35d0a2d  add rsp, 0xF0
00007d07b35d0a34  pop r11
00007d07b35d0a36  pop r10
00007d07b35d0a38  pop r9
00007d07b35d0a3a  pop r8
00007d07b35d0a3c  pop rsi
00007d07b35d0a3d  pop rdi
00007d07b35d0a3e  pop rdx
00007d07b35d0a3f  pop rcx
00007d07b35d0a40  pop rax
00007d07b35d0a41  add rsp, 0x08
00007d07b35d0a45  jmp 0x00007D07B35CF617
00007d07b35d0a4a  sub rsp, 0x08
00007d07b35d0a4e  push rax
00007d07b35d0a4f  push rcx
00007d07b35d0a50  push rdx
00007d07b35d0a51  push rdi
00007d07b35d0a52  push rsi
00007d07b35d0a53  push r8
00007d07b35d0a55  push r9
00007d07b35d0a57  push r10
00007d07b35d0a59  push r11
00007d07b35d0a5b  sub rsp, 0xF0
00007d07b35d0a62  vmovaps [rsp], xmm0
00007d07b35d0a67  vmovaps [rsp+0x10], xmm2
00007d07b35d0a6d  vmovaps [rsp+0x20], xmm3
00007d07b35d0a73  vmovaps [rsp+0x30], xmm4
00007d07b35d0a79  vmovaps [rsp+0x40], xmm5
00007d07b35d0a7f  vmovaps [rsp+0x50], xmm6
00007d07b35d0a85  vmovaps [rsp+0x60], xmm7
00007d07b35d0a8b  vmovaps [rsp+0x70], xmm8
00007d07b35d0a91  vmovaps [rsp+0x80], xmm9
00007d07b35d0a9a  vmovaps [rsp+0x90], xmm10
00007d07b35d0aa3  vmovaps [rsp+0xA0], xmm11
00007d07b35d0aac  vmovaps [rsp+0xB0], xmm12
00007d07b35d0ab5  vmovaps [rsp+0xC0], xmm13
00007d07b35d0abe  vmovaps [rsp+0xD0], xmm14
00007d07b35d0ac7  vmovaps [rsp+0xE0], xmm15
00007d07b35d0ad0  sub rsp, 0x30
00007d07b35d0ad4  movaps [rsp], xmm1
00007d07b35d0ad8  movaps [rsp+0x10], xmm14
00007d07b35d0ade  movaps [rsp+0x20], xmm10
00007d07b35d0ae4  lea rdi, [rsp]
00007d07b35d0ae8  mov esi, 0x00
00007d07b35d0aed  mov rax, 0x5D0AA712D530
00007d07b35d0af7  call rax
00007d07b35d0af9  movaps xmm1, [rsp]
00007d07b35d0afd  add rsp, 0x30
00007d07b35d0b01  vmovaps xmm0, [rsp]
00007d07b35d0b06  vmovaps xmm2, [rsp+0x10]
00007d07b35d0b0c  vmovaps xmm3, [rsp+0x20]
00007d07b35d0b12  vmovaps xmm4, [rsp+0x30]
00007d07b35d0b18  vmovaps xmm5, [rsp+0x40]
00007d07b35d0b1e  vmovaps xmm6, [rsp+0x50]
00007d07b35d0b24  vmovaps xmm7, [rsp+0x60]
00007d07b35d0b2a  vmovaps xmm8, [rsp+0x70]
00007d07b35d0b30  vmovaps xmm9, [rsp+0x80]
00007d07b35d0b39  vmovaps xmm10, [rsp+0x90]
00007d07b35d0b42  vmovaps xmm11, [rsp+0xA0]
00007d07b35d0b4b  vmovaps xmm12, [rsp+0xB0]
00007d07b35d0b54  vmovaps xmm13, [rsp+0xC0]
00007d07b35d0b5d  vmovaps xmm14, [rsp+0xD0]
00007d07b35d0b66  vmovaps xmm15, [rsp+0xE0]
00007d07b35d0b6f  add rsp, 0xF0
00007d07b35d0b76  pop r11
00007d07b35d0b78  pop r10
00007d07b35d0b7a  pop r9
00007d07b35d0b7c  pop r8
00007d07b35d0b7e  pop rsi
00007d07b35d0b7f  pop rdi
00007d07b35d0b80  pop rdx
00007d07b35d0b81  pop rcx
00007d07b35d0b82  pop rax
00007d07b35d0b83  add rsp, 0x08
00007d07b35d0b87  jmp 0x00007D07B35CF631
00007d07b35d0b8c  sub rsp, 0x08
00007d07b35d0b90  push rax
00007d07b35d0b91  push rcx
00007d07b35d0b92  push rdx
00007d07b35d0b93  push rdi
00007d07b35d0b94  push rsi
00007d07b35d0b95  push r8
00007d07b35d0b97  push r9
00007d07b35d0b99  push r10
00007d07b35d0b9b  push r11
00007d07b35d0b9d  sub rsp, 0xF0
00007d07b35d0ba4  vmovaps [rsp], xmm0
00007d07b35d0ba9  vmovaps [rsp+0x10], xmm1
00007d07b35d0baf  vmovaps [rsp+0x20], xmm2
00007d07b35d0bb5  vmovaps [rsp+0x30], xmm3
00007d07b35d0bbb  vmovaps [rsp+0x40], xmm4
00007d07b35d0bc1  vmovaps [rsp+0x50], xmm5
00007d07b35d0bc7  vmovaps [rsp+0x60], xmm6
00007d07b35d0bcd  vmovaps [rsp+0x70], xmm7
00007d07b35d0bd3  vmovaps [rsp+0x80], xmm8
00007d07b35d0bdc  vmovaps [rsp+0x90], xmm9
00007d07b35d0be5  vmovaps [rsp+0xA0], xmm10
00007d07b35d0bee  vmovaps [rsp+0xB0], xmm11
00007d07b35d0bf7  vmovaps [rsp+0xC0], xmm12
00007d07b35d0c00  vmovaps [rsp+0xD0], xmm14
00007d07b35d0c09  vmovaps [rsp+0xE0], xmm15
00007d07b35d0c12  sub rsp, 0x30
00007d07b35d0c16  movaps [rsp], xmm13
00007d07b35d0c1b  movaps [rsp+0x10], xmm14
00007d07b35d0c21  movaps [rsp+0x20], xmm2
00007d07b35d0c26  lea rdi, [rsp]
00007d07b35d0c2a  mov esi, 0x00
00007d07b35d0c2f  mov rax, 0x5D0AA712D530
00007d07b35d0c39  call rax
00007d07b35d0c3b  movaps xmm13, [rsp]
00007d07b35d0c40  add rsp, 0x30
00007d07b35d0c44  vmovaps xmm0, [rsp]
00007d07b35d0c49  vmovaps xmm1, [rsp+0x10]
00007d07b35d0c4f  vmovaps xmm2, [rsp+0x20]
00007d07b35d0c55  vmovaps xmm3, [rsp+0x30]
00007d07b35d0c5b  vmovaps xmm4, [rsp+0x40]
00007d07b35d0c61  vmovaps xmm5, [rsp+0x50]
00007d07b35d0c67  vmovaps xmm6, [rsp+0x60]
00007d07b35d0c6d  vmovaps xmm7, [rsp+0x70]
00007d07b35d0c73  vmovaps xmm8, [rsp+0x80]
00007d07b35d0c7c  vmovaps xmm9, [rsp+0x90]
00007d07b35d0c85  vmovaps xmm10, [rsp+0xA0]
00007d07b35d0c8e  vmovaps xmm11, [rsp+0xB0]
00007d07b35d0c97  vmovaps xmm12, [rsp+0xC0]
00007d07b35d0ca0  vmovaps xmm14, [rsp+0xD0]
00007d07b35d0ca9  vmovaps xmm15, [rsp+0xE0]
00007d07b35d0cb2  add rsp, 0xF0
00007d07b35d0cb9  pop r11
00007d07b35d0cbb  pop r10
00007d07b35d0cbd  pop r9
00007d07b35d0cbf  pop r8
00007d07b35d0cc1  pop rsi
00007d07b35d0cc2  pop rdi
00007d07b35d0cc3  pop rdx
00007d07b35d0cc4  pop rcx
00007d07b35d0cc5  pop rax
00007d07b35d0cc6  add rsp, 0x08
00007d07b35d0cca  jmp 0x00007D07B35CF64C
00007d07b35d0ccf  sub rsp, 0x08
00007d07b35d0cd3  push rax
00007d07b35d0cd4  push rcx
00007d07b35d0cd5  push rdx
00007d07b35d0cd6  push rdi
00007d07b35d0cd7  push rsi
00007d07b35d0cd8  push r8
00007d07b35d0cda  push r9
00007d07b35d0cdc  push r10
00007d07b35d0cde  push r11
00007d07b35d0ce0  sub rsp, 0xF0
00007d07b35d0ce7  vmovaps [rsp], xmm0
00007d07b35d0cec  vmovaps [rsp+0x10], xmm2
00007d07b35d0cf2  vmovaps [rsp+0x20], xmm3
00007d07b35d0cf8  vmovaps [rsp+0x30], xmm4
00007d07b35d0cfe  vmovaps [rsp+0x40], xmm5
00007d07b35d0d04  vmovaps [rsp+0x50], xmm6
00007d07b35d0d0a  vmovaps [rsp+0x60], xmm7
00007d07b35d0d10  vmovaps [rsp+0x70], xmm8
00007d07b35d0d16  vmovaps [rsp+0x80], xmm9
00007d07b35d0d1f  vmovaps [rsp+0x90], xmm10
00007d07b35d0d28  vmovaps [rsp+0xA0], xmm11
00007d07b35d0d31  vmovaps [rsp+0xB0], xmm12
00007d07b35d0d3a  vmovaps [rsp+0xC0], xmm13
00007d07b35d0d43  vmovaps [rsp+0xD0], xmm14
00007d07b35d0d4c  vmovaps [rsp+0xE0], xmm15
00007d07b35d0d55  sub rsp, 0x30
00007d07b35d0d59  movaps [rsp], xmm1
00007d07b35d0d5d  movaps [rsp+0x10], xmm10
00007d07b35d0d63  movaps [rsp+0x20], xmm2
00007d07b35d0d68  lea rdi, [rsp]
00007d07b35d0d6c  mov esi, 0x00
00007d07b35d0d71  mov rax, 0x5D0AA712D530
00007d07b35d0d7b  call rax
00007d07b35d0d7d  movaps xmm1, [rsp]
00007d07b35d0d81  add rsp, 0x30
00007d07b35d0d85  vmovaps xmm0, [rsp]
00007d07b35d0d8a  vmovaps xmm2, [rsp+0x10]
00007d07b35d0d90  vmovaps xmm3, [rsp+0x20]
00007d07b35d0d96  vmovaps xmm4, [rsp+0x30]
00007d07b35d0d9c  vmovaps xmm5, [rsp+0x40]
00007d07b35d0da2  vmovaps xmm6, [rsp+0x50]
00007d07b35d0da8  vmovaps xmm7, [rsp+0x60]
00007d07b35d0dae  vmovaps xmm8, [rsp+0x70]
00007d07b35d0db4  vmovaps xmm9, [rsp+0x80]
00007d07b35d0dbd  vmovaps xmm10, [rsp+0x90]
00007d07b35d0dc6  vmovaps xmm11, [rsp+0xA0]
00007d07b35d0dcf  vmovaps xmm12, [rsp+0xB0]
00007d07b35d0dd8  vmovaps xmm13, [rsp+0xC0]
00007d07b35d0de1  vmovaps xmm14, [rsp+0xD0]
00007d07b35d0dea  vmovaps xmm15, [rsp+0xE0]
00007d07b35d0df3  add rsp, 0xF0
00007d07b35d0dfa  pop r11
00007d07b35d0dfc  pop r10
00007d07b35d0dfe  pop r9
00007d07b35d0e00  pop r8
00007d07b35d0e02  pop rsi
00007d07b35d0e03  pop rdi
00007d07b35d0e04  pop rdx
00007d07b35d0e05  pop rcx
00007d07b35d0e06  pop rax
00007d07b35d0e07  add rsp, 0x08
00007d07b35d0e0b  jmp 0x00007D07B35CF6B4
00007d07b35d0e10  sub rsp, 0x08
00007d07b35d0e14  push rax
00007d07b35d0e15  push rcx
00007d07b35d0e16  push rdx
00007d07b35d0e17  push rdi
00007d07b35d0e18  push rsi
00007d07b35d0e19  push r8
00007d07b35d0e1b  push r9
00007d07b35d0e1d  push r10
00007d07b35d0e1f  push r11
00007d07b35d0e21  sub rsp, 0xF0
00007d07b35d0e28  vmovaps [rsp], xmm0
00007d07b35d0e2d  vmovaps [rsp+0x10], xmm1
00007d07b35d0e33  vmovaps [rsp+0x20], xmm2
00007d07b35d0e39  vmovaps [rsp+0x30], xmm3
00007d07b35d0e3f  vmovaps [rsp+0x40], xmm4
00007d07b35d0e45  vmovaps [rsp+0x50], xmm5
00007d07b35d0e4b  vmovaps [rsp+0x60], xmm6
00007d07b35d0e51  vmovaps [rsp+0x70], xmm7
00007d07b35d0e57  vmovaps [rsp+0x80], xmm8
00007d07b35d0e60  vmovaps [rsp+0x90], xmm9
00007d07b35d0e69  vmovaps [rsp+0xA0], xmm10
00007d07b35d0e72  vmovaps [rsp+0xB0], xmm11
00007d07b35d0e7b  vmovaps [rsp+0xC0], xmm12
00007d07b35d0e84  vmovaps [rsp+0xD0], xmm13
00007d07b35d0e8d  vmovaps [rsp+0xE0], xmm14
00007d07b35d0e96  sub rsp, 0x30
00007d07b35d0e9a  movaps [rsp], xmm15
00007d07b35d0e9f  movaps [rsp+0x10], xmm10
00007d07b35d0ea5  movaps [rsp+0x20], xmm2
00007d07b35d0eaa  lea rdi, [rsp]
00007d07b35d0eae  mov esi, 0x00
00007d07b35d0eb3  mov rax, 0x5D0AA712D530
00007d07b35d0ebd  call rax
00007d07b35d0ebf  movaps xmm15, [rsp]
00007d07b35d0ec4  add rsp, 0x30
00007d07b35d0ec8  vmovaps xmm0, [rsp]
00007d07b35d0ecd  vmovaps xmm1, [rsp+0x10]
00007d07b35d0ed3  vmovaps xmm2, [rsp+0x20]
00007d07b35d0ed9  vmovaps xmm3, [rsp+0x30]
00007d07b35d0edf  vmovaps xmm4, [rsp+0x40]
00007d07b35d0ee5  vmovaps xmm5, [rsp+0x50]
00007d07b35d0eeb  vmovaps xmm6, [rsp+0x60]
00007d07b35d0ef1  vmovaps xmm7, [rsp+0x70]
00007d07b35d0ef7  vmovaps xmm8, [rsp+0x80]
00007d07b35d0f00  vmovaps xmm9, [rsp+0x90]
00007d07b35d0f09  vmovaps xmm10, [rsp+0xA0]
00007d07b35d0f12  vmovaps xmm11, [rsp+0xB0]
00007d07b35d0f1b  vmovaps xmm12, [rsp+0xC0]
00007d07b35d0f24  vmovaps xmm13, [rsp+0xD0]
00007d07b35d0f2d  vmovaps xmm14, [rsp+0xE0]
00007d07b35d0f36  add rsp, 0xF0
00007d07b35d0f3d  pop r11
00007d07b35d0f3f  pop r10
00007d07b35d0f41  pop r9
00007d07b35d0f43  pop r8
00007d07b35d0f45  pop rsi
00007d07b35d0f46  pop rdi
00007d07b35d0f47  pop rdx
00007d07b35d0f48  pop rcx
00007d07b35d0f49  pop rax
00007d07b35d0f4a  add rsp, 0x08
00007d07b35d0f4e  jmp 0x00007D07B35CF706
00007d07b35d0f53  sub rsp, 0x08
00007d07b35d0f57  push rax
00007d07b35d0f58  push rcx
00007d07b35d0f59  push rdx
00007d07b35d0f5a  push rdi
00007d07b35d0f5b  push rsi
00007d07b35d0f5c  push r8
00007d07b35d0f5e  push r9
00007d07b35d0f60  push r10
00007d07b35d0f62  push r11
00007d07b35d0f64  sub rsp, 0xF0
00007d07b35d0f6b  vmovaps [rsp], xmm0
00007d07b35d0f70  vmovaps [rsp+0x10], xmm2
00007d07b35d0f76  vmovaps [rsp+0x20], xmm3
00007d07b35d0f7c  vmovaps [rsp+0x30], xmm4
00007d07b35d0f82  vmovaps [rsp+0x40], xmm5
00007d07b35d0f88  vmovaps [rsp+0x50], xmm6
00007d07b35d0f8e  vmovaps [rsp+0x60], xmm7
00007d07b35d0f94  vmovaps [rsp+0x70], xmm8
00007d07b35d0f9a  vmovaps [rsp+0x80], xmm9
00007d07b35d0fa3  vmovaps [rsp+0x90], xmm10
00007d07b35d0fac  vmovaps [rsp+0xA0], xmm11
00007d07b35d0fb5  vmovaps [rsp+0xB0], xmm12
00007d07b35d0fbe  vmovaps [rsp+0xC0], xmm13
00007d07b35d0fc7  vmovaps [rsp+0xD0], xmm14
00007d07b35d0fd0  vmovaps [rsp+0xE0], xmm15
00007d07b35d0fd9  sub rsp, 0x30
00007d07b35d0fdd  movaps [rsp], xmm1
00007d07b35d0fe1  movaps [rsp+0x10], xmm10
00007d07b35d0fe7  movaps [rsp+0x20], xmm12
00007d07b35d0fed  lea rdi, [rsp]
00007d07b35d0ff1  mov esi, 0x00
00007d07b35d0ff6  mov rax, 0x5D0AA712D530
00007d07b35d1000  call rax
00007d07b35d1002  movaps xmm1, [rsp]
00007d07b35d1006  add rsp, 0x30
00007d07b35d100a  vmovaps xmm0, [rsp]
00007d07b35d100f  vmovaps xmm2, [rsp+0x10]
00007d07b35d1015  vmovaps xmm3, [rsp+0x20]
00007d07b35d101b  vmovaps xmm4, [rsp+0x30]
00007d07b35d1021  vmovaps xmm5, [rsp+0x40]
00007d07b35d1027  vmovaps xmm6, [rsp+0x50]
00007d07b35d102d  vmovaps xmm7, [rsp+0x60]
00007d07b35d1033  vmovaps xmm8, [rsp+0x70]
00007d07b35d1039  vmovaps xmm9, [rsp+0x80]
00007d07b35d1042  vmovaps xmm10, [rsp+0x90]
00007d07b35d104b  vmovaps xmm11, [rsp+0xA0]
00007d07b35d1054  vmovaps xmm12, [rsp+0xB0]
00007d07b35d105d  vmovaps xmm13, [rsp+0xC0]
00007d07b35d1066  vmovaps xmm14, [rsp+0xD0]
00007d07b35d106f  vmovaps xmm15, [rsp+0xE0]
00007d07b35d1078  add rsp, 0xF0
00007d07b35d107f  pop r11
00007d07b35d1081  pop r10
00007d07b35d1083  pop r9
00007d07b35d1085  pop r8
00007d07b35d1087  pop rsi
00007d07b35d1088  pop rdi
00007d07b35d1089  pop rdx
00007d07b35d108a  pop rcx
00007d07b35d108b  pop rax
00007d07b35d108c  add rsp, 0x08
00007d07b35d1090  jmp 0x00007D07B35CF732
00007d07b35d1095  sub rsp, 0x08
00007d07b35d1099  push rax
00007d07b35d109a  push rcx
00007d07b35d109b  push rdx
00007d07b35d109c  push rdi
00007d07b35d109d  push rsi
00007d07b35d109e  push r8
00007d07b35d10a0  push r9
00007d07b35d10a2  push r10
00007d07b35d10a4  push r11
00007d07b35d10a6  sub rsp, 0xF0
00007d07b35d10ad  vmovaps [rsp], xmm0
00007d07b35d10b2  vmovaps [rsp+0x10], xmm1
00007d07b35d10b8  vmovaps [rsp+0x20], xmm2
00007d07b35d10be  vmovaps [rsp+0x30], xmm3
00007d07b35d10c4  vmovaps [rsp+0x40], xmm4
00007d07b35d10ca  vmovaps [rsp+0x50], xmm5
00007d07b35d10d0  vmovaps [rsp+0x60], xmm6
00007d07b35d10d6  vmovaps [rsp+0x70], xmm7
00007d07b35d10dc  vmovaps [rsp+0x80], xmm8
00007d07b35d10e5  vmovaps [rsp+0x90], xmm9
00007d07b35d10ee  vmovaps [rsp+0xA0], xmm10
00007d07b35d10f7  vmovaps [rsp+0xB0], xmm11
00007d07b35d1100  vmovaps [rsp+0xC0], xmm12
00007d07b35d1109  vmovaps [rsp+0xD0], xmm13
00007d07b35d1112  vmovaps [rsp+0xE0], xmm14
00007d07b35d111b  sub rsp, 0x30
00007d07b35d111f  movaps [rsp], xmm15
00007d07b35d1124  movaps [rsp+0x10], xmm10
00007d07b35d112a  movaps [rsp+0x20], xmm12
00007d07b35d1130  lea rdi, [rsp]
00007d07b35d1134  mov esi, 0x00
00007d07b35d1139  mov rax, 0x5D0AA712D530
00007d07b35d1143  call rax
00007d07b35d1145  movaps xmm15, [rsp]
00007d07b35d114a  add rsp, 0x30
00007d07b35d114e  vmovaps xmm0, [rsp]
00007d07b35d1153  vmovaps xmm1, [rsp+0x10]
00007d07b35d1159  vmovaps xmm2, [rsp+0x20]
00007d07b35d115f  vmovaps xmm3, [rsp+0x30]
00007d07b35d1165  vmovaps xmm4, [rsp+0x40]
00007d07b35d116b  vmovaps xmm5, [rsp+0x50]
00007d07b35d1171  vmovaps xmm6, [rsp+0x60]
00007d07b35d1177  vmovaps xmm7, [rsp+0x70]
00007d07b35d117d  vmovaps xmm8, [rsp+0x80]
00007d07b35d1186  vmovaps xmm9, [rsp+0x90]
00007d07b35d118f  vmovaps xmm10, [rsp+0xA0]
00007d07b35d1198  vmovaps xmm11, [rsp+0xB0]
00007d07b35d11a1  vmovaps xmm12, [rsp+0xC0]
00007d07b35d11aa  vmovaps xmm13, [rsp+0xD0]
00007d07b35d11b3  vmovaps xmm14, [rsp+0xE0]
00007d07b35d11bc  add rsp, 0xF0
00007d07b35d11c3  pop r11
00007d07b35d11c5  pop r10
00007d07b35d11c7  pop r9
00007d07b35d11c9  pop r8
00007d07b35d11cb  pop rsi
00007d07b35d11cc  pop rdi
00007d07b35d11cd  pop rdx
00007d07b35d11ce  pop rcx
00007d07b35d11cf  pop rax
00007d07b35d11d0  add rsp, 0x08
00007d07b35d11d4  jmp 0x00007D07B35CF75E
00007d07b35d11d9  call 0x00007D07B33FF430
00007d07b35d11de  jmp 0x00007D07B35CF7EE
00007d07b35d11e3  call 0x00007D07B33FF430
00007d07b35d11e8  jmp 0x00007D07B35CF801
00007d07b35d11ed  sub rsp, 0x08
00007d07b35d11f1  push rax
00007d07b35d11f2  push rcx
00007d07b35d11f3  push rdx
00007d07b35d11f4  push rdi
00007d07b35d11f5  push rsi
00007d07b35d11f6  push r8
00007d07b35d11f8  push r9
00007d07b35d11fa  push r10
00007d07b35d11fc  push r11
00007d07b35d11fe  sub rsp, 0xF0
00007d07b35d1205  vmovaps [rsp], xmm0
00007d07b35d120a  vmovaps [rsp+0x10], xmm2
00007d07b35d1210  vmovaps [rsp+0x20], xmm3
00007d07b35d1216  vmovaps [rsp+0x30], xmm4
00007d07b35d121c  vmovaps [rsp+0x40], xmm5
00007d07b35d1222  vmovaps [rsp+0x50], xmm6
00007d07b35d1228  vmovaps [rsp+0x60], xmm7
00007d07b35d122e  vmovaps [rsp+0x70], xmm8
00007d07b35d1234  vmovaps [rsp+0x80], xmm9
00007d07b35d123d  vmovaps [rsp+0x90], xmm10
00007d07b35d1246  vmovaps [rsp+0xA0], xmm11
00007d07b35d124f  vmovaps [rsp+0xB0], xmm12
00007d07b35d1258  vmovaps [rsp+0xC0], xmm13
00007d07b35d1261  vmovaps [rsp+0xD0], xmm14
00007d07b35d126a  vmovaps [rsp+0xE0], xmm15
00007d07b35d1273  sub rsp, 0x30
00007d07b35d1277  movaps [rsp], xmm1
00007d07b35d127b  movaps [rsp+0x10], xmm13
00007d07b35d1281  movaps [rsp+0x20], xmm2
00007d07b35d1286  lea rdi, [rsp]
00007d07b35d128a  mov esi, 0x00
00007d07b35d128f  mov rax, 0x5D0AA712D530
00007d07b35d1299  call rax
00007d07b35d129b  movaps xmm1, [rsp]
00007d07b35d129f  add rsp, 0x30
00007d07b35d12a3  vmovaps xmm0, [rsp]
00007d07b35d12a8  vmovaps xmm2, [rsp+0x10]
00007d07b35d12ae  vmovaps xmm3, [rsp+0x20]
00007d07b35d12b4  vmovaps xmm4, [rsp+0x30]
00007d07b35d12ba  vmovaps xmm5, [rsp+0x40]
00007d07b35d12c0  vmovaps xmm6, [rsp+0x50]
00007d07b35d12c6  vmovaps xmm7, [rsp+0x60]
00007d07b35d12cc  vmovaps xmm8, [rsp+0x70]
00007d07b35d12d2  vmovaps xmm9, [rsp+0x80]
00007d07b35d12db  vmovaps xmm10, [rsp+0x90]
00007d07b35d12e4  vmovaps xmm11, [rsp+0xA0]
00007d07b35d12ed  vmovaps xmm12, [rsp+0xB0]
00007d07b35d12f6  vmovaps xmm13, [rsp+0xC0]
00007d07b35d12ff  vmovaps xmm14, [rsp+0xD0]
00007d07b35d1308  vmovaps xmm15, [rsp+0xE0]
00007d07b35d1311  add rsp, 0xF0
00007d07b35d1318  pop r11
00007d07b35d131a  pop r10
00007d07b35d131c  pop r9
00007d07b35d131e  pop r8
00007d07b35d1320  pop rsi
00007d07b35d1321  pop rdi
00007d07b35d1322  pop rdx
00007d07b35d1323  pop rcx
00007d07b35d1324  pop rax
00007d07b35d1325  add rsp, 0x08
00007d07b35d1329  jmp 0x00007D07B35CF82C
00007d07b35d132e  call 0x00007D07B340E760
00007d07b35d1333  jmp 0x00007D07B35CF839
00007d07b35d1338  sub rsp, 0x08
00007d07b35d133c  push rax
00007d07b35d133d  push rcx
00007d07b35d133e  push rdx
00007d07b35d133f  push rdi
00007d07b35d1340  push rsi
00007d07b35d1341  push r8
00007d07b35d1343  push r9
00007d07b35d1345  push r10
00007d07b35d1347  push r11
00007d07b35d1349  sub rsp, 0xF0
00007d07b35d1350  vmovaps [rsp], xmm0
00007d07b35d1355  vmovaps [rsp+0x10], xmm1
00007d07b35d135b  vmovaps [rsp+0x20], xmm2
00007d07b35d1361  vmovaps [rsp+0x30], xmm3
00007d07b35d1367  vmovaps [rsp+0x40], xmm4
00007d07b35d136d  vmovaps [rsp+0x50], xmm5
00007d07b35d1373  vmovaps [rsp+0x60], xmm6
00007d07b35d1379  vmovaps [rsp+0x70], xmm7
00007d07b35d137f  vmovaps [rsp+0x80], xmm8
00007d07b35d1388  vmovaps [rsp+0x90], xmm9
00007d07b35d1391  vmovaps [rsp+0xA0], xmm10
00007d07b35d139a  vmovaps [rsp+0xB0], xmm11
00007d07b35d13a3  vmovaps [rsp+0xC0], xmm12
00007d07b35d13ac  vmovaps [rsp+0xD0], xmm14
00007d07b35d13b5  vmovaps [rsp+0xE0], xmm15
00007d07b35d13be  sub rsp, 0x30
00007d07b35d13c2  movaps [rsp], xmm13
00007d07b35d13c7  movaps [rsp+0x10], xmm2
00007d07b35d13cc  movaps [rsp+0x20], xmm1
00007d07b35d13d1  lea rdi, [rsp]
00007d07b35d13d5  mov esi, 0x00
00007d07b35d13da  mov rax, 0x5D0AA712D530
00007d07b35d13e4  call rax
00007d07b35d13e6  movaps xmm13, [rsp]
00007d07b35d13eb  add rsp, 0x30
00007d07b35d13ef  vmovaps xmm0, [rsp]
00007d07b35d13f4  vmovaps xmm1, [rsp+0x10]
00007d07b35d13fa  vmovaps xmm2, [rsp+0x20]
00007d07b35d1400  vmovaps xmm3, [rsp+0x30]
00007d07b35d1406  vmovaps xmm4, [rsp+0x40]
00007d07b35d140c  vmovaps xmm5, [rsp+0x50]
00007d07b35d1412  vmovaps xmm6, [rsp+0x60]
00007d07b35d1418  vmovaps xmm7, [rsp+0x70]
00007d07b35d141e  vmovaps xmm8, [rsp+0x80]
00007d07b35d1427  vmovaps xmm9, [rsp+0x90]
00007d07b35d1430  vmovaps xmm10, [rsp+0xA0]
00007d07b35d1439  vmovaps xmm11, [rsp+0xB0]
00007d07b35d1442  vmovaps xmm12, [rsp+0xC0]
00007d07b35d144b  vmovaps xmm14, [rsp+0xD0]
00007d07b35d1454  vmovaps xmm15, [rsp+0xE0]
00007d07b35d145d  add rsp, 0xF0
00007d07b35d1464  pop r11
00007d07b35d1466  pop r10
00007d07b35d1468  pop r9
00007d07b35d146a  pop r8
00007d07b35d146c  pop rsi
00007d07b35d146d  pop rdi
00007d07b35d146e  pop rdx
00007d07b35d146f  pop rcx
00007d07b35d1470  pop rax
00007d07b35d1471  add rsp, 0x08
00007d07b35d1475  jmp 0x00007D07B35CF878
00007d07b35d147a  sub rsp, 0x08
00007d07b35d147e  push rax
00007d07b35d147f  push rcx
00007d07b35d1480  push rdx
00007d07b35d1481  push rdi
00007d07b35d1482  push rsi
00007d07b35d1483  push r8
00007d07b35d1485  push r9
00007d07b35d1487  push r10
00007d07b35d1489  push r11
00007d07b35d148b  sub rsp, 0xF0
00007d07b35d1492  vmovaps [rsp], xmm0
00007d07b35d1497  vmovaps [rsp+0x10], xmm2
00007d07b35d149d  vmovaps [rsp+0x20], xmm3
00007d07b35d14a3  vmovaps [rsp+0x30], xmm4
00007d07b35d14a9  vmovaps [rsp+0x40], xmm5
00007d07b35d14af  vmovaps [rsp+0x50], xmm6
00007d07b35d14b5  vmovaps [rsp+0x60], xmm7
00007d07b35d14bb  vmovaps [rsp+0x70], xmm8
00007d07b35d14c1  vmovaps [rsp+0x80], xmm9
00007d07b35d14ca  vmovaps [rsp+0x90], xmm10
00007d07b35d14d3  vmovaps [rsp+0xA0], xmm11
00007d07b35d14dc  vmovaps [rsp+0xB0], xmm12
00007d07b35d14e5  vmovaps [rsp+0xC0], xmm13
00007d07b35d14ee  vmovaps [rsp+0xD0], xmm14
00007d07b35d14f7  vmovaps [rsp+0xE0], xmm15
00007d07b35d1500  sub rsp, 0x30
00007d07b35d1504  movaps [rsp], xmm1
00007d07b35d1508  movaps [rsp+0x10], xmm15
00007d07b35d150e  movaps [rsp+0x20], xmm2
00007d07b35d1513  lea rdi, [rsp]
00007d07b35d1517  mov esi, 0x00
00007d07b35d151c  mov rax, 0x5D0AA712D530
00007d07b35d1526  call rax
00007d07b35d1528  movaps xmm1, [rsp]
00007d07b35d152c  add rsp, 0x30
00007d07b35d1530  vmovaps xmm0, [rsp]
00007d07b35d1535  vmovaps xmm2, [rsp+0x10]
00007d07b35d153b  vmovaps xmm3, [rsp+0x20]
00007d07b35d1541  vmovaps xmm4, [rsp+0x30]
00007d07b35d1547  vmovaps xmm5, [rsp+0x40]
00007d07b35d154d  vmovaps xmm6, [rsp+0x50]
00007d07b35d1553  vmovaps xmm7, [rsp+0x60]
00007d07b35d1559  vmovaps xmm8, [rsp+0x70]
00007d07b35d155f  vmovaps xmm9, [rsp+0x80]
00007d07b35d1568  vmovaps xmm10, [rsp+0x90]
00007d07b35d1571  vmovaps xmm11, [rsp+0xA0]
00007d07b35d157a  vmovaps xmm12, [rsp+0xB0]
00007d07b35d1583  vmovaps xmm13, [rsp+0xC0]
00007d07b35d158c  vmovaps xmm14, [rsp+0xD0]
00007d07b35d1595  vmovaps xmm15, [rsp+0xE0]
00007d07b35d159e  add rsp, 0xF0
00007d07b35d15a5  pop r11
00007d07b35d15a7  pop r10
00007d07b35d15a9  pop r9
00007d07b35d15ab  pop r8
00007d07b35d15ad  pop rsi
00007d07b35d15ae  pop rdi
00007d07b35d15af  pop rdx
00007d07b35d15b0  pop rcx
00007d07b35d15b1  pop rax
00007d07b35d15b2  add rsp, 0x08
00007d07b35d15b6  jmp 0x00007D07B35CF8AC
00007d07b35d15bb  sub rsp, 0x08
00007d07b35d15bf  push rax
00007d07b35d15c0  push rcx
00007d07b35d15c1  push rdx
00007d07b35d15c2  push rdi
00007d07b35d15c3  push rsi
00007d07b35d15c4  push r8
00007d07b35d15c6  push r9
00007d07b35d15c8  push r10
00007d07b35d15ca  push r11
00007d07b35d15cc  sub rsp, 0xF0
00007d07b35d15d3  vmovaps [rsp], xmm0
00007d07b35d15d8  vmovaps [rsp+0x10], xmm1
00007d07b35d15de  vmovaps [rsp+0x20], xmm2
00007d07b35d15e4  vmovaps [rsp+0x30], xmm3
00007d07b35d15ea  vmovaps [rsp+0x40], xmm4
00007d07b35d15f0  vmovaps [rsp+0x50], xmm5
00007d07b35d15f6  vmovaps [rsp+0x60], xmm6
00007d07b35d15fc  vmovaps [rsp+0x70], xmm7
00007d07b35d1602  vmovaps [rsp+0x80], xmm8
00007d07b35d160b  vmovaps [rsp+0x90], xmm9
00007d07b35d1614  vmovaps [rsp+0xA0], xmm10
00007d07b35d161d  vmovaps [rsp+0xB0], xmm11
00007d07b35d1626  vmovaps [rsp+0xC0], xmm12
00007d07b35d162f  vmovaps [rsp+0xD0], xmm13
00007d07b35d1638  vmovaps [rsp+0xE0], xmm15
00007d07b35d1641  sub rsp, 0x30
00007d07b35d1645  movaps [rsp], xmm14
00007d07b35d164a  movaps [rsp+0x10], xmm2
00007d07b35d164f  movaps [rsp+0x20], xmm15
00007d07b35d1655  lea rdi, [rsp]
00007d07b35d1659  mov esi, 0x00
00007d07b35d165e  mov rax, 0x5D0AA712D530
00007d07b35d1668  call rax
00007d07b35d166a  movaps xmm14, [rsp]
00007d07b35d166f  add rsp, 0x30
00007d07b35d1673  vmovaps xmm0, [rsp]
00007d07b35d1678  vmovaps xmm1, [rsp+0x10]
00007d07b35d167e  vmovaps xmm2, [rsp+0x20]
00007d07b35d1684  vmovaps xmm3, [rsp+0x30]
00007d07b35d168a  vmovaps xmm4, [rsp+0x40]
00007d07b35d1690  vmovaps xmm5, [rsp+0x50]
00007d07b35d1696  vmovaps xmm6, [rsp+0x60]
00007d07b35d169c  vmovaps xmm7, [rsp+0x70]
00007d07b35d16a2  vmovaps xmm8, [rsp+0x80]
00007d07b35d16ab  vmovaps xmm9, [rsp+0x90]
00007d07b35d16b4  vmovaps xmm10, [rsp+0xA0]
00007d07b35d16bd  vmovaps xmm11, [rsp+0xB0]
00007d07b35d16c6  vmovaps xmm12, [rsp+0xC0]
00007d07b35d16cf  vmovaps xmm13, [rsp+0xD0]
00007d07b35d16d8  vmovaps xmm15, [rsp+0xE0]
00007d07b35d16e1  add rsp, 0xF0
00007d07b35d16e8  pop r11
00007d07b35d16ea  pop r10
00007d07b35d16ec  pop r9
00007d07b35d16ee  pop r8
00007d07b35d16f0  pop rsi
00007d07b35d16f1  pop rdi
00007d07b35d16f2  pop rdx
00007d07b35d16f3  pop rcx
00007d07b35d16f4  pop rax
00007d07b35d16f5  add rsp, 0x08
00007d07b35d16f9  jmp 0x00007D07B35CF8E7
00007d07b35d16fe  sub rsp, 0x08
00007d07b35d1702  push rax
00007d07b35d1703  push rcx
00007d07b35d1704  push rdx
00007d07b35d1705  push rdi
00007d07b35d1706  push rsi
00007d07b35d1707  push r8
00007d07b35d1709  push r9
00007d07b35d170b  push r10
00007d07b35d170d  push r11
00007d07b35d170f  sub rsp, 0xF0
00007d07b35d1716  vmovaps [rsp], xmm0
00007d07b35d171b  vmovaps [rsp+0x10], xmm1
00007d07b35d1721  vmovaps [rsp+0x20], xmm2
00007d07b35d1727  vmovaps [rsp+0x30], xmm3
00007d07b35d172d  vmovaps [rsp+0x40], xmm4
00007d07b35d1733  vmovaps [rsp+0x50], xmm5
00007d07b35d1739  vmovaps [rsp+0x60], xmm6
00007d07b35d173f  vmovaps [rsp+0x70], xmm7
00007d07b35d1745  vmovaps [rsp+0x80], xmm8
00007d07b35d174e  vmovaps [rsp+0x90], xmm9
00007d07b35d1757  vmovaps [rsp+0xA0], xmm10
00007d07b35d1760  vmovaps [rsp+0xB0], xmm11
00007d07b35d1769  vmovaps [rsp+0xC0], xmm12
00007d07b35d1772  vmovaps [rsp+0xD0], xmm13
00007d07b35d177b  vmovaps [rsp+0xE0], xmm14
00007d07b35d1784  sub rsp, 0x30
00007d07b35d1788  movaps [rsp], xmm15
00007d07b35d178d  movaps [rsp+0x10], xmm2
00007d07b35d1792  movaps [rsp+0x20], xmm1
00007d07b35d1797  lea rdi, [rsp]
00007d07b35d179b  mov esi, 0x00
00007d07b35d17a0  mov rax, 0x5D0AA712D530
00007d07b35d17aa  call rax
00007d07b35d17ac  movaps xmm15, [rsp]
00007d07b35d17b1  add rsp, 0x30
00007d07b35d17b5  vmovaps xmm0, [rsp]
00007d07b35d17ba  vmovaps xmm1, [rsp+0x10]
00007d07b35d17c0  vmovaps xmm2, [rsp+0x20]
00007d07b35d17c6  vmovaps xmm3, [rsp+0x30]
00007d07b35d17cc  vmovaps xmm4, [rsp+0x40]
00007d07b35d17d2  vmovaps xmm5, [rsp+0x50]
00007d07b35d17d8  vmovaps xmm6, [rsp+0x60]
00007d07b35d17de  vmovaps xmm7, [rsp+0x70]
00007d07b35d17e4  vmovaps xmm8, [rsp+0x80]
00007d07b35d17ed  vmovaps xmm9, [rsp+0x90]
00007d07b35d17f6  vmovaps xmm10, [rsp+0xA0]
00007d07b35d17ff  vmovaps xmm11, [rsp+0xB0]
00007d07b35d1808  vmovaps xmm12, [rsp+0xC0]
00007d07b35d1811  vmovaps xmm13, [rsp+0xD0]
00007d07b35d181a  vmovaps xmm14, [rsp+0xE0]
00007d07b35d1823  add rsp, 0xF0
00007d07b35d182a  pop r11
00007d07b35d182c  pop r10
00007d07b35d182e  pop r9
00007d07b35d1830  pop r8
00007d07b35d1832  pop rsi
00007d07b35d1833  pop rdi
00007d07b35d1834  pop rdx
00007d07b35d1835  pop rcx
00007d07b35d1836  pop rax
00007d07b35d1837  add rsp, 0x08
00007d07b35d183b  jmp 0x00007D07B35CF923
00007d07b35d1840  call 0x00007D07B33FF430
00007d07b35d1845  jmp 0x00007D07B35CF930
00007d07b35d184a  sub rsp, 0x08
00007d07b35d184e  push rax
00007d07b35d184f  push rcx
00007d07b35d1850  push rdx
00007d07b35d1851  push rdi
00007d07b35d1852  push rsi
00007d07b35d1853  push r8
00007d07b35d1855  push r9
00007d07b35d1857  push r10
00007d07b35d1859  push r11
00007d07b35d185b  sub rsp, 0xF0
00007d07b35d1862  vmovaps [rsp], xmm0
00007d07b35d1867  vmovaps [rsp+0x10], xmm1
00007d07b35d186d  vmovaps [rsp+0x20], xmm3
00007d07b35d1873  vmovaps [rsp+0x30], xmm4
00007d07b35d1879  vmovaps [rsp+0x40], xmm5
00007d07b35d187f  vmovaps [rsp+0x50], xmm6
00007d07b35d1885  vmovaps [rsp+0x60], xmm7
00007d07b35d188b  vmovaps [rsp+0x70], xmm8
00007d07b35d1891  vmovaps [rsp+0x80], xmm9
00007d07b35d189a  vmovaps [rsp+0x90], xmm10
00007d07b35d18a3  vmovaps [rsp+0xA0], xmm11
00007d07b35d18ac  vmovaps [rsp+0xB0], xmm12
00007d07b35d18b5  vmovaps [rsp+0xC0], xmm13
00007d07b35d18be  vmovaps [rsp+0xD0], xmm14
00007d07b35d18c7  vmovaps [rsp+0xE0], xmm15
00007d07b35d18d0  sub rsp, 0x30
00007d07b35d18d4  movaps [rsp], xmm2
00007d07b35d18d8  movaps [rsp+0x10], xmm1
00007d07b35d18dd  movaps [rsp+0x20], xmm14
00007d07b35d18e3  lea rdi, [rsp]
00007d07b35d18e7  mov esi, 0x00
00007d07b35d18ec  mov rax, 0x5D0AA712D530
00007d07b35d18f6  call rax
00007d07b35d18f8  movaps xmm2, [rsp]
00007d07b35d18fc  add rsp, 0x30
00007d07b35d1900  vmovaps xmm0, [rsp]
00007d07b35d1905  vmovaps xmm1, [rsp+0x10]
00007d07b35d190b  vmovaps xmm3, [rsp+0x20]
00007d07b35d1911  vmovaps xmm4, [rsp+0x30]
00007d07b35d1917  vmovaps xmm5, [rsp+0x40]
00007d07b35d191d  vmovaps xmm6, [rsp+0x50]
00007d07b35d1923  vmovaps xmm7, [rsp+0x60]
00007d07b35d1929  vmovaps xmm8, [rsp+0x70]
00007d07b35d192f  vmovaps xmm9, [rsp+0x80]
00007d07b35d1938  vmovaps xmm10, [rsp+0x90]
00007d07b35d1941  vmovaps xmm11, [rsp+0xA0]
00007d07b35d194a  vmovaps xmm12, [rsp+0xB0]
00007d07b35d1953  vmovaps xmm13, [rsp+0xC0]
00007d07b35d195c  vmovaps xmm14, [rsp+0xD0]
00007d07b35d1965  vmovaps xmm15, [rsp+0xE0]
00007d07b35d196e  add rsp, 0xF0
00007d07b35d1975  pop r11
00007d07b35d1977  pop r10
00007d07b35d1979  pop r9
00007d07b35d197b  pop r8
00007d07b35d197d  pop rsi
00007d07b35d197e  pop rdi
00007d07b35d197f  pop rdx
00007d07b35d1980  pop rcx
00007d07b35d1981  pop rax
00007d07b35d1982  add rsp, 0x08
00007d07b35d1986  jmp 0x00007D07B35CF96D
00007d07b35d198b  sub rsp, 0x08
00007d07b35d198f  push rax
00007d07b35d1990  push rcx
00007d07b35d1991  push rdx
00007d07b35d1992  push rdi
00007d07b35d1993  push rsi
00007d07b35d1994  push r8
00007d07b35d1996  push r9
00007d07b35d1998  push r10
00007d07b35d199a  push r11
00007d07b35d199c  sub rsp, 0xF0
00007d07b35d19a3  vmovaps [rsp], xmm0
00007d07b35d19a8  vmovaps [rsp+0x10], xmm1
00007d07b35d19ae  vmovaps [rsp+0x20], xmm2
00007d07b35d19b4  vmovaps [rsp+0x30], xmm3
00007d07b35d19ba  vmovaps [rsp+0x40], xmm4
00007d07b35d19c0  vmovaps [rsp+0x50], xmm5
00007d07b35d19c6  vmovaps [rsp+0x60], xmm6
00007d07b35d19cc  vmovaps [rsp+0x70], xmm7
00007d07b35d19d2  vmovaps [rsp+0x80], xmm8
00007d07b35d19db  vmovaps [rsp+0x90], xmm9
00007d07b35d19e4  vmovaps [rsp+0xA0], xmm10
00007d07b35d19ed  vmovaps [rsp+0xB0], xmm11
00007d07b35d19f6  vmovaps [rsp+0xC0], xmm12
00007d07b35d19ff  vmovaps [rsp+0xD0], xmm13
00007d07b35d1a08  vmovaps [rsp+0xE0], xmm14
00007d07b35d1a11  sub rsp, 0x30
00007d07b35d1a15  movaps [rsp], xmm15
00007d07b35d1a1a  movaps [rsp+0x10], xmm14
00007d07b35d1a20  movaps [rsp+0x20], xmm1
00007d07b35d1a25  lea rdi, [rsp]
00007d07b35d1a29  mov esi, 0x00
00007d07b35d1a2e  mov rax, 0x5D0AA712D530
00007d07b35d1a38  call rax
00007d07b35d1a3a  movaps xmm15, [rsp]
00007d07b35d1a3f  add rsp, 0x30
00007d07b35d1a43  vmovaps xmm0, [rsp]
00007d07b35d1a48  vmovaps xmm1, [rsp+0x10]
00007d07b35d1a4e  vmovaps xmm2, [rsp+0x20]
00007d07b35d1a54  vmovaps xmm3, [rsp+0x30]
00007d07b35d1a5a  vmovaps xmm4, [rsp+0x40]
00007d07b35d1a60  vmovaps xmm5, [rsp+0x50]
00007d07b35d1a66  vmovaps xmm6, [rsp+0x60]
00007d07b35d1a6c  vmovaps xmm7, [rsp+0x70]
00007d07b35d1a72  vmovaps xmm8, [rsp+0x80]
00007d07b35d1a7b  vmovaps xmm9, [rsp+0x90]
00007d07b35d1a84  vmovaps xmm10, [rsp+0xA0]
00007d07b35d1a8d  vmovaps xmm11, [rsp+0xB0]
00007d07b35d1a96  vmovaps xmm12, [rsp+0xC0]
00007d07b35d1a9f  vmovaps xmm13, [rsp+0xD0]
00007d07b35d1aa8  vmovaps xmm14, [rsp+0xE0]
00007d07b35d1ab1  add rsp, 0xF0
00007d07b35d1ab8  pop r11
00007d07b35d1aba  pop r10
00007d07b35d1abc  pop r9
00007d07b35d1abe  pop r8
00007d07b35d1ac0  pop rsi
00007d07b35d1ac1  pop rdi
00007d07b35d1ac2  pop rdx
00007d07b35d1ac3  pop rcx
00007d07b35d1ac4  pop rax
00007d07b35d1ac5  add rsp, 0x08
00007d07b35d1ac9  jmp 0x00007D07B35CF9E7
00007d07b35d1ace  call 0x00007D07B33FF430
00007d07b35d1ad3  jmp 0x00007D07B35CF9F4
00007d07b35d1ad8  sub rsp, 0x08
00007d07b35d1adc  push rax
00007d07b35d1add  push rcx
00007d07b35d1ade  push rdx
00007d07b35d1adf  push rdi
00007d07b35d1ae0  push rsi
00007d07b35d1ae1  push r8
00007d07b35d1ae3  push r9
00007d07b35d1ae5  push r10
00007d07b35d1ae7  push r11
00007d07b35d1ae9  sub rsp, 0xF0
00007d07b35d1af0  vmovaps [rsp], xmm0
00007d07b35d1af5  vmovaps [rsp+0x10], xmm1
00007d07b35d1afb  vmovaps [rsp+0x20], xmm2
00007d07b35d1b01  vmovaps [rsp+0x30], xmm3
00007d07b35d1b07  vmovaps [rsp+0x40], xmm4
00007d07b35d1b0d  vmovaps [rsp+0x50], xmm5
00007d07b35d1b13  vmovaps [rsp+0x60], xmm6
00007d07b35d1b19  vmovaps [rsp+0x70], xmm7
00007d07b35d1b1f  vmovaps [rsp+0x80], xmm8
00007d07b35d1b28  vmovaps [rsp+0x90], xmm9
00007d07b35d1b31  vmovaps [rsp+0xA0], xmm10
00007d07b35d1b3a  vmovaps [rsp+0xB0], xmm11
00007d07b35d1b43  vmovaps [rsp+0xC0], xmm12
00007d07b35d1b4c  vmovaps [rsp+0xD0], xmm13
00007d07b35d1b55  vmovaps [rsp+0xE0], xmm15
00007d07b35d1b5e  sub rsp, 0x30
00007d07b35d1b62  movaps [rsp], xmm14
00007d07b35d1b67  movaps [rsp+0x10], xmm13
00007d07b35d1b6d  movaps [rsp+0x20], xmm1
00007d07b35d1b72  lea rdi, [rsp]
00007d07b35d1b76  mov esi, 0x00
00007d07b35d1b7b  mov rax, 0x5D0AA712D530
00007d07b35d1b85  call rax
00007d07b35d1b87  movaps xmm14, [rsp]
00007d07b35d1b8c  add rsp, 0x30
00007d07b35d1b90  vmovaps xmm0, [rsp]
00007d07b35d1b95  vmovaps xmm1, [rsp+0x10]
00007d07b35d1b9b  vmovaps xmm2, [rsp+0x20]
00007d07b35d1ba1  vmovaps xmm3, [rsp+0x30]
00007d07b35d1ba7  vmovaps xmm4, [rsp+0x40]
00007d07b35d1bad  vmovaps xmm5, [rsp+0x50]
00007d07b35d1bb3  vmovaps xmm6, [rsp+0x60]
00007d07b35d1bb9  vmovaps xmm7, [rsp+0x70]
00007d07b35d1bbf  vmovaps xmm8, [rsp+0x80]
00007d07b35d1bc8  vmovaps xmm9, [rsp+0x90]
00007d07b35d1bd1  vmovaps xmm10, [rsp+0xA0]
00007d07b35d1bda  vmovaps xmm11, [rsp+0xB0]
00007d07b35d1be3  vmovaps xmm12, [rsp+0xC0]
00007d07b35d1bec  vmovaps xmm13, [rsp+0xD0]
00007d07b35d1bf5  vmovaps xmm15, [rsp+0xE0]
00007d07b35d1bfe  add rsp, 0xF0
00007d07b35d1c05  pop r11
00007d07b35d1c07  pop r10
00007d07b35d1c09  pop r9
00007d07b35d1c0b  pop r8
00007d07b35d1c0d  pop rsi
00007d07b35d1c0e  pop rdi
00007d07b35d1c0f  pop rdx
00007d07b35d1c10  pop rcx
00007d07b35d1c11  pop rax
00007d07b35d1c12  add rsp, 0x08
00007d07b35d1c16  jmp 0x00007D07B35CFAAF
00007d07b35d1c1b  sub rsp, 0x08
00007d07b35d1c1f  push rax
00007d07b35d1c20  push rcx
00007d07b35d1c21  push rdx
00007d07b35d1c22  push rdi
00007d07b35d1c23  push rsi
00007d07b35d1c24  push r8
00007d07b35d1c26  push r9
00007d07b35d1c28  push r10
00007d07b35d1c2a  push r11
00007d07b35d1c2c  sub rsp, 0xF0
00007d07b35d1c33  vmovaps [rsp], xmm0
00007d07b35d1c38  vmovaps [rsp+0x10], xmm1
00007d07b35d1c3e  vmovaps [rsp+0x20], xmm2
00007d07b35d1c44  vmovaps [rsp+0x30], xmm3
00007d07b35d1c4a  vmovaps [rsp+0x40], xmm4
00007d07b35d1c50  vmovaps [rsp+0x50], xmm5
00007d07b35d1c56  vmovaps [rsp+0x60], xmm6
00007d07b35d1c5c  vmovaps [rsp+0x70], xmm7
00007d07b35d1c62  vmovaps [rsp+0x80], xmm8
00007d07b35d1c6b  vmovaps [rsp+0x90], xmm9
00007d07b35d1c74  vmovaps [rsp+0xA0], xmm10
00007d07b35d1c7d  vmovaps [rsp+0xB0], xmm11
00007d07b35d1c86  vmovaps [rsp+0xC0], xmm12
00007d07b35d1c8f  vmovaps [rsp+0xD0], xmm13
00007d07b35d1c98  vmovaps [rsp+0xE0], xmm14
00007d07b35d1ca1  sub rsp, 0x30
00007d07b35d1ca5  movaps [rsp], xmm15
00007d07b35d1caa  movaps [rsp+0x10], xmm13
00007d07b35d1cb0  movaps [rsp+0x20], xmm1
00007d07b35d1cb5  lea rdi, [rsp]
00007d07b35d1cb9  mov esi, 0x00
00007d07b35d1cbe  mov rax, 0x5D0AA712D530
00007d07b35d1cc8  call rax
00007d07b35d1cca  movaps xmm15, [rsp]
00007d07b35d1ccf  add rsp, 0x30
00007d07b35d1cd3  vmovaps xmm0, [rsp]
00007d07b35d1cd8  vmovaps xmm1, [rsp+0x10]
00007d07b35d1cde  vmovaps xmm2, [rsp+0x20]
00007d07b35d1ce4  vmovaps xmm3, [rsp+0x30]
00007d07b35d1cea  vmovaps xmm4, [rsp+0x40]
00007d07b35d1cf0  vmovaps xmm5, [rsp+0x50]
00007d07b35d1cf6  vmovaps xmm6, [rsp+0x60]
00007d07b35d1cfc  vmovaps xmm7, [rsp+0x70]
00007d07b35d1d02  vmovaps xmm8, [rsp+0x80]
00007d07b35d1d0b  vmovaps xmm9, [rsp+0x90]
00007d07b35d1d14  vmovaps xmm10, [rsp+0xA0]
00007d07b35d1d1d  vmovaps xmm11, [rsp+0xB0]
00007d07b35d1d26  vmovaps xmm12, [rsp+0xC0]
00007d07b35d1d2f  vmovaps xmm13, [rsp+0xD0]
00007d07b35d1d38  vmovaps xmm14, [rsp+0xE0]
00007d07b35d1d41  add rsp, 0xF0
00007d07b35d1d48  pop r11
00007d07b35d1d4a  pop r10
00007d07b35d1d4c  pop r9
00007d07b35d1d4e  pop r8
00007d07b35d1d50  pop rsi
00007d07b35d1d51  pop rdi
00007d07b35d1d52  pop rdx
00007d07b35d1d53  pop rcx
00007d07b35d1d54  pop rax
00007d07b35d1d55  add rsp, 0x08
00007d07b35d1d59  jmp 0x00007D07B35CFAEB
00007d07b35d1d5e  call 0x00007D07B33FF430
00007d07b35d1d63  jmp 0x00007D07B35CFAF8
00007d07b35d1d68  sub rsp, 0x08
00007d07b35d1d6c  push rax
00007d07b35d1d6d  push rcx
00007d07b35d1d6e  push rdx
00007d07b35d1d6f  push rdi
00007d07b35d1d70  push rsi
00007d07b35d1d71  push r8
00007d07b35d1d73  push r9
00007d07b35d1d75  push r10
00007d07b35d1d77  push r11
00007d07b35d1d79  sub rsp, 0xF0
00007d07b35d1d80  vmovaps [rsp], xmm0
00007d07b35d1d85  vmovaps [rsp+0x10], xmm1
00007d07b35d1d8b  vmovaps [rsp+0x20], xmm2
00007d07b35d1d91  vmovaps [rsp+0x30], xmm3
00007d07b35d1d97  vmovaps [rsp+0x40], xmm4
00007d07b35d1d9d  vmovaps [rsp+0x50], xmm5
00007d07b35d1da3  vmovaps [rsp+0x60], xmm6
00007d07b35d1da9  vmovaps [rsp+0x70], xmm7
00007d07b35d1daf  vmovaps [rsp+0x80], xmm8
00007d07b35d1db8  vmovaps [rsp+0x90], xmm9
00007d07b35d1dc1  vmovaps [rsp+0xA0], xmm10
00007d07b35d1dca  vmovaps [rsp+0xB0], xmm11
00007d07b35d1dd3  vmovaps [rsp+0xC0], xmm12
00007d07b35d1ddc  vmovaps [rsp+0xD0], xmm13
00007d07b35d1de5  vmovaps [rsp+0xE0], xmm15
00007d07b35d1dee  sub rsp, 0x30
00007d07b35d1df2  movaps [rsp], xmm14
00007d07b35d1df7  movaps [rsp+0x10], xmm13
00007d07b35d1dfd  movaps [rsp+0x20], xmm2
00007d07b35d1e02  lea rdi, [rsp]
00007d07b35d1e06  mov esi, 0x00
00007d07b35d1e0b  mov rax, 0x5D0AA712D530
00007d07b35d1e15  call rax
00007d07b35d1e17  movaps xmm14, [rsp]
00007d07b35d1e1c  add rsp, 0x30
00007d07b35d1e20  vmovaps xmm0, [rsp]
00007d07b35d1e25  vmovaps xmm1, [rsp+0x10]
00007d07b35d1e2b  vmovaps xmm2, [rsp+0x20]
00007d07b35d1e31  vmovaps xmm3, [rsp+0x30]
00007d07b35d1e37  vmovaps xmm4, [rsp+0x40]
00007d07b35d1e3d  vmovaps xmm5, [rsp+0x50]
00007d07b35d1e43  vmovaps xmm6, [rsp+0x60]
00007d07b35d1e49  vmovaps xmm7, [rsp+0x70]
00007d07b35d1e4f  vmovaps xmm8, [rsp+0x80]
00007d07b35d1e58  vmovaps xmm9, [rsp+0x90]
00007d07b35d1e61  vmovaps xmm10, [rsp+0xA0]
00007d07b35d1e6a  vmovaps xmm11, [rsp+0xB0]
00007d07b35d1e73  vmovaps xmm12, [rsp+0xC0]
00007d07b35d1e7c  vmovaps xmm13, [rsp+0xD0]
00007d07b35d1e85  vmovaps xmm15, [rsp+0xE0]
00007d07b35d1e8e  add rsp, 0xF0
00007d07b35d1e95  pop r11
00007d07b35d1e97  pop r10
00007d07b35d1e99  pop r9
00007d07b35d1e9b  pop r8
00007d07b35d1e9d  pop rsi
00007d07b35d1e9e  pop rdi
00007d07b35d1e9f  pop rdx
00007d07b35d1ea0  pop rcx
00007d07b35d1ea1  pop rax
00007d07b35d1ea2  add rsp, 0x08
00007d07b35d1ea6  jmp 0x00007D07B35CFB24
00007d07b35d1eab  sub rsp, 0x08
00007d07b35d1eaf  push rax
00007d07b35d1eb0  push rcx
00007d07b35d1eb1  push rdx
00007d07b35d1eb2  push rdi
00007d07b35d1eb3  push rsi
00007d07b35d1eb4  push r8
00007d07b35d1eb6  push r9
00007d07b35d1eb8  push r10
00007d07b35d1eba  push r11
00007d07b35d1ebc  sub rsp, 0xF0
00007d07b35d1ec3  vmovaps [rsp], xmm0
00007d07b35d1ec8  vmovaps [rsp+0x10], xmm2
00007d07b35d1ece  vmovaps [rsp+0x20], xmm3
00007d07b35d1ed4  vmovaps [rsp+0x30], xmm4
00007d07b35d1eda  vmovaps [rsp+0x40], xmm5
00007d07b35d1ee0  vmovaps [rsp+0x50], xmm6
00007d07b35d1ee6  vmovaps [rsp+0x60], xmm7
00007d07b35d1eec  vmovaps [rsp+0x70], xmm8
00007d07b35d1ef2  vmovaps [rsp+0x80], xmm9
00007d07b35d1efb  vmovaps [rsp+0x90], xmm10
00007d07b35d1f04  vmovaps [rsp+0xA0], xmm11
00007d07b35d1f0d  vmovaps [rsp+0xB0], xmm12
00007d07b35d1f16  vmovaps [rsp+0xC0], xmm13
00007d07b35d1f1f  vmovaps [rsp+0xD0], xmm14
00007d07b35d1f28  vmovaps [rsp+0xE0], xmm15
00007d07b35d1f31  sub rsp, 0x30
00007d07b35d1f35  movaps [rsp], xmm1
00007d07b35d1f39  movaps [rsp+0x10], xmm13
00007d07b35d1f3f  movaps [rsp+0x20], xmm2
00007d07b35d1f44  lea rdi, [rsp]
00007d07b35d1f48  mov esi, 0x00
00007d07b35d1f4d  mov rax, 0x5D0AA712D530
00007d07b35d1f57  call rax
00007d07b35d1f59  movaps xmm1, [rsp]
00007d07b35d1f5d  add rsp, 0x30
00007d07b35d1f61  vmovaps xmm0, [rsp]
00007d07b35d1f66  vmovaps xmm2, [rsp+0x10]
00007d07b35d1f6c  vmovaps xmm3, [rsp+0x20]
00007d07b35d1f72  vmovaps xmm4, [rsp+0x30]
00007d07b35d1f78  vmovaps xmm5, [rsp+0x40]
00007d07b35d1f7e  vmovaps xmm6, [rsp+0x50]
00007d07b35d1f84  vmovaps xmm7, [rsp+0x60]
00007d07b35d1f8a  vmovaps xmm8, [rsp+0x70]
00007d07b35d1f90  vmovaps xmm9, [rsp+0x80]
00007d07b35d1f99  vmovaps xmm10, [rsp+0x90]
00007d07b35d1fa2  vmovaps xmm11, [rsp+0xA0]
00007d07b35d1fab  vmovaps xmm12, [rsp+0xB0]
00007d07b35d1fb4  vmovaps xmm13, [rsp+0xC0]
00007d07b35d1fbd  vmovaps xmm14, [rsp+0xD0]
00007d07b35d1fc6  vmovaps xmm15, [rsp+0xE0]
00007d07b35d1fcf  add rsp, 0xF0
00007d07b35d1fd6  pop r11
00007d07b35d1fd8  pop r10
00007d07b35d1fda  pop r9
00007d07b35d1fdc  pop r8
00007d07b35d1fde  pop rsi
00007d07b35d1fdf  pop rdi
00007d07b35d1fe0  pop rdx
00007d07b35d1fe1  pop rcx
00007d07b35d1fe2  pop rax
00007d07b35d1fe3  add rsp, 0x08
00007d07b35d1fe7  jmp 0x00007D07B35CFB52
00007d07b35d1fec  sub rsp, 0x08
00007d07b35d1ff0  push rax
00007d07b35d1ff1  push rcx
00007d07b35d1ff2  push rdx
00007d07b35d1ff3  push rdi
00007d07b35d1ff4  push rsi
00007d07b35d1ff5  push r8
00007d07b35d1ff7  push r9
00007d07b35d1ff9  push r10
00007d07b35d1ffb  push r11
00007d07b35d1ffd  sub rsp, 0xF0
00007d07b35d2004  vmovaps [rsp], xmm0
00007d07b35d2009  vmovaps [rsp+0x10], xmm1
00007d07b35d200f  vmovaps [rsp+0x20], xmm3
00007d07b35d2015  vmovaps [rsp+0x30], xmm4
00007d07b35d201b  vmovaps [rsp+0x40], xmm5
00007d07b35d2021  vmovaps [rsp+0x50], xmm6
00007d07b35d2027  vmovaps [rsp+0x60], xmm7
00007d07b35d202d  vmovaps [rsp+0x70], xmm8
00007d07b35d2033  vmovaps [rsp+0x80], xmm9
00007d07b35d203c  vmovaps [rsp+0x90], xmm10
00007d07b35d2045  vmovaps [rsp+0xA0], xmm11
00007d07b35d204e  vmovaps [rsp+0xB0], xmm12
00007d07b35d2057  vmovaps [rsp+0xC0], xmm13
00007d07b35d2060  vmovaps [rsp+0xD0], xmm14
00007d07b35d2069  vmovaps [rsp+0xE0], xmm15
00007d07b35d2072  sub rsp, 0x30
00007d07b35d2076  movaps [rsp], xmm2
00007d07b35d207a  movaps [rsp+0x10], xmm1
00007d07b35d207f  movaps [rsp+0x20], xmm13
00007d07b35d2085  lea rdi, [rsp]
00007d07b35d2089  mov esi, 0x00
00007d07b35d208e  mov rax, 0x5D0AA712D530
00007d07b35d2098  call rax
00007d07b35d209a  movaps xmm2, [rsp]
00007d07b35d209e  add rsp, 0x30
00007d07b35d20a2  vmovaps xmm0, [rsp]
00007d07b35d20a7  vmovaps xmm1, [rsp+0x10]
00007d07b35d20ad  vmovaps xmm3, [rsp+0x20]
00007d07b35d20b3  vmovaps xmm4, [rsp+0x30]
00007d07b35d20b9  vmovaps xmm5, [rsp+0x40]
00007d07b35d20bf  vmovaps xmm6, [rsp+0x50]
00007d07b35d20c5  vmovaps xmm7, [rsp+0x60]
00007d07b35d20cb  vmovaps xmm8, [rsp+0x70]
00007d07b35d20d1  vmovaps xmm9, [rsp+0x80]
00007d07b35d20da  vmovaps xmm10, [rsp+0x90]
00007d07b35d20e3  vmovaps xmm11, [rsp+0xA0]
00007d07b35d20ec  vmovaps xmm12, [rsp+0xB0]
00007d07b35d20f5  vmovaps xmm13, [rsp+0xC0]
00007d07b35d20fe  vmovaps xmm14, [rsp+0xD0]
00007d07b35d2107  vmovaps xmm15, [rsp+0xE0]
00007d07b35d2110  add rsp, 0xF0
00007d07b35d2117  pop r11
00007d07b35d2119  pop r10
00007d07b35d211b  pop r9
00007d07b35d211d  pop r8
00007d07b35d211f  pop rsi
00007d07b35d2120  pop rdi
00007d07b35d2121  pop rdx
00007d07b35d2122  pop rcx
00007d07b35d2123  pop rax
00007d07b35d2124  add rsp, 0x08
00007d07b35d2128  jmp 0x00007D07B35CFBAB
00007d07b35d212d  call 0x00007D07B33FF430
00007d07b35d2132  jmp 0x00007D07B35CFBB8
00007d07b35d2137  sub rsp, 0x08
00007d07b35d213b  push rax
00007d07b35d213c  push rcx
00007d07b35d213d  push rdx
00007d07b35d213e  push rdi
00007d07b35d213f  push rsi
00007d07b35d2140  push r8
00007d07b35d2142  push r9
00007d07b35d2144  push r10
00007d07b35d2146  push r11
00007d07b35d2148  sub rsp, 0xF0
00007d07b35d214f  vmovaps [rsp], xmm0
00007d07b35d2154  vmovaps [rsp+0x10], xmm1
00007d07b35d215a  vmovaps [rsp+0x20], xmm2
00007d07b35d2160  vmovaps [rsp+0x30], xmm3
00007d07b35d2166  vmovaps [rsp+0x40], xmm4
00007d07b35d216c  vmovaps [rsp+0x50], xmm5
00007d07b35d2172  vmovaps [rsp+0x60], xmm6
00007d07b35d2178  vmovaps [rsp+0x70], xmm7
00007d07b35d217e  vmovaps [rsp+0x80], xmm8
00007d07b35d2187  vmovaps [rsp+0x90], xmm9
00007d07b35d2190  vmovaps [rsp+0xA0], xmm10
00007d07b35d2199  vmovaps [rsp+0xB0], xmm11
00007d07b35d21a2  vmovaps [rsp+0xC0], xmm12
00007d07b35d21ab  vmovaps [rsp+0xD0], xmm13
00007d07b35d21b4  vmovaps [rsp+0xE0], xmm14
00007d07b35d21bd  sub rsp, 0x30
00007d07b35d21c1  movaps [rsp], xmm15
00007d07b35d21c6  movaps [rsp+0x10], xmm13
00007d07b35d21cc  movaps [rsp+0x20], xmm1
00007d07b35d21d1  lea rdi, [rsp]
00007d07b35d21d5  mov esi, 0x00
00007d07b35d21da  mov rax, 0x5D0AA712D530
00007d07b35d21e4  call rax
00007d07b35d21e6  movaps xmm15, [rsp]
00007d07b35d21eb  add rsp, 0x30
00007d07b35d21ef  vmovaps xmm0, [rsp]
00007d07b35d21f4  vmovaps xmm1, [rsp+0x10]
00007d07b35d21fa  vmovaps xmm2, [rsp+0x20]
00007d07b35d2200  vmovaps xmm3, [rsp+0x30]
00007d07b35d2206  vmovaps xmm4, [rsp+0x40]
00007d07b35d220c  vmovaps xmm5, [rsp+0x50]
00007d07b35d2212  vmovaps xmm6, [rsp+0x60]
00007d07b35d2218  vmovaps xmm7, [rsp+0x70]
00007d07b35d221e  vmovaps xmm8, [rsp+0x80]
00007d07b35d2227  vmovaps xmm9, [rsp+0x90]
00007d07b35d2230  vmovaps xmm10, [rsp+0xA0]
00007d07b35d2239  vmovaps xmm11, [rsp+0xB0]
00007d07b35d2242  vmovaps xmm12, [rsp+0xC0]
00007d07b35d224b  vmovaps xmm13, [rsp+0xD0]
00007d07b35d2254  vmovaps xmm14, [rsp+0xE0]
00007d07b35d225d  add rsp, 0xF0
00007d07b35d2264  pop r11
00007d07b35d2266  pop r10
00007d07b35d2268  pop r9
00007d07b35d226a  pop r8
00007d07b35d226c  pop rsi
00007d07b35d226d  pop rdi
00007d07b35d226e  pop rdx
00007d07b35d226f  pop rcx
00007d07b35d2270  pop rax
00007d07b35d2271  add rsp, 0x08
00007d07b35d2275  jmp 0x00007D07B35CFBF7
00007d07b35d227a  sub rsp, 0x08
00007d07b35d227e  push rax
00007d07b35d227f  push rcx
00007d07b35d2280  push rdx
00007d07b35d2281  push rdi
00007d07b35d2282  push rsi
00007d07b35d2283  push r8
00007d07b35d2285  push r9
00007d07b35d2287  push r10
00007d07b35d2289  push r11
00007d07b35d228b  sub rsp, 0xF0
00007d07b35d2292  vmovaps [rsp], xmm0
00007d07b35d2297  vmovaps [rsp+0x10], xmm1
00007d07b35d229d  vmovaps [rsp+0x20], xmm2
00007d07b35d22a3  vmovaps [rsp+0x30], xmm3
00007d07b35d22a9  vmovaps [rsp+0x40], xmm4
00007d07b35d22af  vmovaps [rsp+0x50], xmm5
00007d07b35d22b5  vmovaps [rsp+0x60], xmm6
00007d07b35d22bb  vmovaps [rsp+0x70], xmm7
00007d07b35d22c1  vmovaps [rsp+0x80], xmm8
00007d07b35d22ca  vmovaps [rsp+0x90], xmm9
00007d07b35d22d3  vmovaps [rsp+0xA0], xmm10
00007d07b35d22dc  vmovaps [rsp+0xB0], xmm11
00007d07b35d22e5  vmovaps [rsp+0xC0], xmm12
00007d07b35d22ee  vmovaps [rsp+0xD0], xmm13
00007d07b35d22f7  vmovaps [rsp+0xE0], xmm15
00007d07b35d2300  sub rsp, 0x30
00007d07b35d2304  movaps [rsp], xmm14
00007d07b35d2309  movaps [rsp+0x10], xmm11
00007d07b35d230f  movaps [rsp+0x20], xmm1
00007d07b35d2314  lea rdi, [rsp]
00007d07b35d2318  mov esi, 0x00
00007d07b35d231d  mov rax, 0x5D0AA712D530
00007d07b35d2327  call rax
00007d07b35d2329  movaps xmm14, [rsp]
00007d07b35d232e  add rsp, 0x30
00007d07b35d2332  vmovaps xmm0, [rsp]
00007d07b35d2337  vmovaps xmm1, [rsp+0x10]
00007d07b35d233d  vmovaps xmm2, [rsp+0x20]
00007d07b35d2343  vmovaps xmm3, [rsp+0x30]
00007d07b35d2349  vmovaps xmm4, [rsp+0x40]
00007d07b35d234f  vmovaps xmm5, [rsp+0x50]
00007d07b35d2355  vmovaps xmm6, [rsp+0x60]
00007d07b35d235b  vmovaps xmm7, [rsp+0x70]
00007d07b35d2361  vmovaps xmm8, [rsp+0x80]
00007d07b35d236a  vmovaps xmm9, [rsp+0x90]
00007d07b35d2373  vmovaps xmm10, [rsp+0xA0]
00007d07b35d237c  vmovaps xmm11, [rsp+0xB0]
00007d07b35d2385  vmovaps xmm12, [rsp+0xC0]
00007d07b35d238e  vmovaps xmm13, [rsp+0xD0]
00007d07b35d2397  vmovaps xmm15, [rsp+0xE0]
00007d07b35d23a0  add rsp, 0xF0
00007d07b35d23a7  pop r11
00007d07b35d23a9  pop r10
00007d07b35d23ab  pop r9
00007d07b35d23ad  pop r8
00007d07b35d23af  pop rsi
00007d07b35d23b0  pop rdi
00007d07b35d23b1  pop rdx
00007d07b35d23b2  pop rcx
00007d07b35d23b3  pop rax
00007d07b35d23b4  add rsp, 0x08
00007d07b35d23b8  jmp 0x00007D07B35CFC21
00007d07b35d23bd  sub rsp, 0x08
00007d07b35d23c1  push rax
00007d07b35d23c2  push rcx
00007d07b35d23c3  push rdx
00007d07b35d23c4  push rdi
00007d07b35d23c5  push rsi
00007d07b35d23c6  push r8
00007d07b35d23c8  push r9
00007d07b35d23ca  push r10
00007d07b35d23cc  push r11
00007d07b35d23ce  sub rsp, 0xF0
00007d07b35d23d5  vmovaps [rsp], xmm0
00007d07b35d23da  vmovaps [rsp+0x10], xmm1
00007d07b35d23e0  vmovaps [rsp+0x20], xmm2
00007d07b35d23e6  vmovaps [rsp+0x30], xmm3
00007d07b35d23ec  vmovaps [rsp+0x40], xmm4
00007d07b35d23f2  vmovaps [rsp+0x50], xmm5
00007d07b35d23f8  vmovaps [rsp+0x60], xmm6
00007d07b35d23fe  vmovaps [rsp+0x70], xmm7
00007d07b35d2404  vmovaps [rsp+0x80], xmm8
00007d07b35d240d  vmovaps [rsp+0x90], xmm9
00007d07b35d2416  vmovaps [rsp+0xA0], xmm10
00007d07b35d241f  vmovaps [rsp+0xB0], xmm11
00007d07b35d2428  vmovaps [rsp+0xC0], xmm12
00007d07b35d2431  vmovaps [rsp+0xD0], xmm14
00007d07b35d243a  vmovaps [rsp+0xE0], xmm15
00007d07b35d2443  sub rsp, 0x30
00007d07b35d2447  movaps [rsp], xmm13
00007d07b35d244c  movaps [rsp+0x10], xmm11
00007d07b35d2452  movaps [rsp+0x20], xmm1
00007d07b35d2457  lea rdi, [rsp]
00007d07b35d245b  mov esi, 0x00
00007d07b35d2460  mov rax, 0x5D0AA712D530
00007d07b35d246a  call rax
00007d07b35d246c  movaps xmm13, [rsp]
00007d07b35d2471  add rsp, 0x30
00007d07b35d2475  vmovaps xmm0, [rsp]
00007d07b35d247a  vmovaps xmm1, [rsp+0x10]
00007d07b35d2480  vmovaps xmm2, [rsp+0x20]
00007d07b35d2486  vmovaps xmm3, [rsp+0x30]
00007d07b35d248c  vmovaps xmm4, [rsp+0x40]
00007d07b35d2492  vmovaps xmm5, [rsp+0x50]
00007d07b35d2498  vmovaps xmm6, [rsp+0x60]
00007d07b35d249e  vmovaps xmm7, [rsp+0x70]
00007d07b35d24a4  vmovaps xmm8, [rsp+0x80]
00007d07b35d24ad  vmovaps xmm9, [rsp+0x90]
00007d07b35d24b6  vmovaps xmm10, [rsp+0xA0]
00007d07b35d24bf  vmovaps xmm11, [rsp+0xB0]
00007d07b35d24c8  vmovaps xmm12, [rsp+0xC0]
00007d07b35d24d1  vmovaps xmm14, [rsp+0xD0]
00007d07b35d24da  vmovaps xmm15, [rsp+0xE0]
00007d07b35d24e3  add rsp, 0xF0
00007d07b35d24ea  pop r11
00007d07b35d24ec  pop r10
00007d07b35d24ee  pop r9
00007d07b35d24f0  pop r8
00007d07b35d24f2  pop rsi
00007d07b35d24f3  pop rdi
00007d07b35d24f4  pop rdx
00007d07b35d24f5  pop rcx
00007d07b35d24f6  pop rax
00007d07b35d24f7  add rsp, 0x08
00007d07b35d24fb  jmp 0x00007D07B35CFC76
00007d07b35d2500  call 0x00007D07B33FF430
00007d07b35d2505  jmp 0x00007D07B35CFC83
00007d07b35d250a  sub rsp, 0x08
00007d07b35d250e  push rax
00007d07b35d250f  push rcx
00007d07b35d2510  push rdx
00007d07b35d2511  push rdi
00007d07b35d2512  push rsi
00007d07b35d2513  push r8
00007d07b35d2515  push r9
00007d07b35d2517  push r10
00007d07b35d2519  push r11
00007d07b35d251b  sub rsp, 0xF0
00007d07b35d2522  vmovaps [rsp], xmm0
00007d07b35d2527  vmovaps [rsp+0x10], xmm1
00007d07b35d252d  vmovaps [rsp+0x20], xmm2
00007d07b35d2533  vmovaps [rsp+0x30], xmm3
00007d07b35d2539  vmovaps [rsp+0x40], xmm4
00007d07b35d253f  vmovaps [rsp+0x50], xmm5
00007d07b35d2545  vmovaps [rsp+0x60], xmm6
00007d07b35d254b  vmovaps [rsp+0x70], xmm7
00007d07b35d2551  vmovaps [rsp+0x80], xmm8
00007d07b35d255a  vmovaps [rsp+0x90], xmm9
00007d07b35d2563  vmovaps [rsp+0xA0], xmm10
00007d07b35d256c  vmovaps [rsp+0xB0], xmm11
00007d07b35d2575  vmovaps [rsp+0xC0], xmm12
00007d07b35d257e  vmovaps [rsp+0xD0], xmm13
00007d07b35d2587  vmovaps [rsp+0xE0], xmm14
00007d07b35d2590  sub rsp, 0x30
00007d07b35d2594  movaps [rsp], xmm15
00007d07b35d2599  movaps [rsp+0x10], xmm11
00007d07b35d259f  movaps [rsp+0x20], xmm1
00007d07b35d25a4  lea rdi, [rsp]
00007d07b35d25a8  mov esi, 0x00
00007d07b35d25ad  mov rax, 0x5D0AA712D530
00007d07b35d25b7  call rax
00007d07b35d25b9  movaps xmm15, [rsp]
00007d07b35d25be  add rsp, 0x30
00007d07b35d25c2  vmovaps xmm0, [rsp]
00007d07b35d25c7  vmovaps xmm1, [rsp+0x10]
00007d07b35d25cd  vmovaps xmm2, [rsp+0x20]
00007d07b35d25d3  vmovaps xmm3, [rsp+0x30]
00007d07b35d25d9  vmovaps xmm4, [rsp+0x40]
00007d07b35d25df  vmovaps xmm5, [rsp+0x50]
00007d07b35d25e5  vmovaps xmm6, [rsp+0x60]
00007d07b35d25eb  vmovaps xmm7, [rsp+0x70]
00007d07b35d25f1  vmovaps xmm8, [rsp+0x80]
00007d07b35d25fa  vmovaps xmm9, [rsp+0x90]
00007d07b35d2603  vmovaps xmm10, [rsp+0xA0]
00007d07b35d260c  vmovaps xmm11, [rsp+0xB0]
00007d07b35d2615  vmovaps xmm12, [rsp+0xC0]
00007d07b35d261e  vmovaps xmm13, [rsp+0xD0]
00007d07b35d2627  vmovaps xmm14, [rsp+0xE0]
00007d07b35d2630  add rsp, 0xF0
00007d07b35d2637  pop r11
00007d07b35d2639  pop r10
00007d07b35d263b  pop r9
00007d07b35d263d  pop r8
00007d07b35d263f  pop rsi
00007d07b35d2640  pop rdi
00007d07b35d2641  pop rdx
00007d07b35d2642  pop rcx
00007d07b35d2643  pop rax
00007d07b35d2644  add rsp, 0x08
00007d07b35d2648  jmp 0x00007D07B35CFCBC
00007d07b35d264d  sub rsp, 0x08
00007d07b35d2651  push rax
00007d07b35d2652  push rcx
00007d07b35d2653  push rdx
00007d07b35d2654  push rdi
00007d07b35d2655  push rsi
00007d07b35d2656  push r8
00007d07b35d2658  push r9
00007d07b35d265a  push r10
00007d07b35d265c  push r11
00007d07b35d265e  sub rsp, 0xF0
00007d07b35d2665  vmovaps [rsp], xmm0
00007d07b35d266a  vmovaps [rsp+0x10], xmm1
00007d07b35d2670  vmovaps [rsp+0x20], xmm2
00007d07b35d2676  vmovaps [rsp+0x30], xmm3
00007d07b35d267c  vmovaps [rsp+0x40], xmm4
00007d07b35d2682  vmovaps [rsp+0x50], xmm5
00007d07b35d2688  vmovaps [rsp+0x60], xmm6
00007d07b35d268e  vmovaps [rsp+0x70], xmm7
00007d07b35d2694  vmovaps [rsp+0x80], xmm8
00007d07b35d269d  vmovaps [rsp+0x90], xmm9
00007d07b35d26a6  vmovaps [rsp+0xA0], xmm10
00007d07b35d26af  vmovaps [rsp+0xB0], xmm12
00007d07b35d26b8  vmovaps [rsp+0xC0], xmm13
00007d07b35d26c1  vmovaps [rsp+0xD0], xmm14
00007d07b35d26ca  vmovaps [rsp+0xE0], xmm15
00007d07b35d26d3  sub rsp, 0x30
00007d07b35d26d7  movaps [rsp], xmm11
00007d07b35d26dc  movaps [rsp+0x10], xmm6
00007d07b35d26e1  movaps [rsp+0x20], xmm14
00007d07b35d26e7  lea rdi, [rsp]
00007d07b35d26eb  mov esi, 0x00
00007d07b35d26f0  mov rax, 0x5D0AA712D530
00007d07b35d26fa  call rax
00007d07b35d26fc  movaps xmm11, [rsp]
00007d07b35d2701  add rsp, 0x30
00007d07b35d2705  vmovaps xmm0, [rsp]
00007d07b35d270a  vmovaps xmm1, [rsp+0x10]
00007d07b35d2710  vmovaps xmm2, [rsp+0x20]
00007d07b35d2716  vmovaps xmm3, [rsp+0x30]
00007d07b35d271c  vmovaps xmm4, [rsp+0x40]
00007d07b35d2722  vmovaps xmm5, [rsp+0x50]
00007d07b35d2728  vmovaps xmm6, [rsp+0x60]
00007d07b35d272e  vmovaps xmm7, [rsp+0x70]
00007d07b35d2734  vmovaps xmm8, [rsp+0x80]
00007d07b35d273d  vmovaps xmm9, [rsp+0x90]
00007d07b35d2746  vmovaps xmm10, [rsp+0xA0]
00007d07b35d274f  vmovaps xmm12, [rsp+0xB0]
00007d07b35d2758  vmovaps xmm13, [rsp+0xC0]
00007d07b35d2761  vmovaps xmm14, [rsp+0xD0]
00007d07b35d276a  vmovaps xmm15, [rsp+0xE0]
00007d07b35d2773  add rsp, 0xF0
00007d07b35d277a  pop r11
00007d07b35d277c  pop r10
00007d07b35d277e  pop r9
00007d07b35d2780  pop r8
00007d07b35d2782  pop rsi
00007d07b35d2783  pop rdi
00007d07b35d2784  pop rdx
00007d07b35d2785  pop rcx
00007d07b35d2786  pop rax
00007d07b35d2787  add rsp, 0x08
00007d07b35d278b  jmp 0x00007D07B35CFD34
00007d07b35d2790  call 0x00007D07B33FF430
00007d07b35d2795  jmp 0x00007D07B35CFD3E
00007d07b35d279a  sub rsp, 0x08
00007d07b35d279e  push rax
00007d07b35d279f  push rcx
00007d07b35d27a0  push rdx
00007d07b35d27a1  push rdi
00007d07b35d27a2  push rsi
00007d07b35d27a3  push r8
00007d07b35d27a5  push r9
00007d07b35d27a7  push r10
00007d07b35d27a9  push r11
00007d07b35d27ab  sub rsp, 0xF0
00007d07b35d27b2  vmovaps [rsp], xmm0
00007d07b35d27b7  vmovaps [rsp+0x10], xmm1
00007d07b35d27bd  vmovaps [rsp+0x20], xmm2
00007d07b35d27c3  vmovaps [rsp+0x30], xmm3
00007d07b35d27c9  vmovaps [rsp+0x40], xmm4
00007d07b35d27cf  vmovaps [rsp+0x50], xmm5
00007d07b35d27d5  vmovaps [rsp+0x60], xmm6
00007d07b35d27db  vmovaps [rsp+0x70], xmm7
00007d07b35d27e1  vmovaps [rsp+0x80], xmm8
00007d07b35d27ea  vmovaps [rsp+0x90], xmm9
00007d07b35d27f3  vmovaps [rsp+0xA0], xmm10
00007d07b35d27fc  vmovaps [rsp+0xB0], xmm11
00007d07b35d2805  vmovaps [rsp+0xC0], xmm12
00007d07b35d280e  vmovaps [rsp+0xD0], xmm13
00007d07b35d2817  vmovaps [rsp+0xE0], xmm15
00007d07b35d2820  sub rsp, 0x30
00007d07b35d2824  movaps [rsp], xmm14
00007d07b35d2829  movaps [rsp+0x10], xmm6
00007d07b35d282e  movaps [rsp+0x20], xmm2
00007d07b35d2833  lea rdi, [rsp]
00007d07b35d2837  mov esi, 0x00
00007d07b35d283c  mov rax, 0x5D0AA712D530
00007d07b35d2846  call rax
00007d07b35d2848  movaps xmm14, [rsp]
00007d07b35d284d  add rsp, 0x30
00007d07b35d2851  vmovaps xmm0, [rsp]
00007d07b35d2856  vmovaps xmm1, [rsp+0x10]
00007d07b35d285c  vmovaps xmm2, [rsp+0x20]
00007d07b35d2862  vmovaps xmm3, [rsp+0x30]
00007d07b35d2868  vmovaps xmm4, [rsp+0x40]
00007d07b35d286e  vmovaps xmm5, [rsp+0x50]
00007d07b35d2874  vmovaps xmm6, [rsp+0x60]
00007d07b35d287a  vmovaps xmm7, [rsp+0x70]
00007d07b35d2880  vmovaps xmm8, [rsp+0x80]
00007d07b35d2889  vmovaps xmm9, [rsp+0x90]
00007d07b35d2892  vmovaps xmm10, [rsp+0xA0]
00007d07b35d289b  vmovaps xmm11, [rsp+0xB0]
00007d07b35d28a4  vmovaps xmm12, [rsp+0xC0]
00007d07b35d28ad  vmovaps xmm13, [rsp+0xD0]
00007d07b35d28b6  vmovaps xmm15, [rsp+0xE0]
00007d07b35d28bf  add rsp, 0xF0
00007d07b35d28c6  pop r11
00007d07b35d28c8  pop r10
00007d07b35d28ca  pop r9
00007d07b35d28cc  pop r8
00007d07b35d28ce  pop rsi
00007d07b35d28cf  pop rdi
00007d07b35d28d0  pop rdx
00007d07b35d28d1  pop rcx
00007d07b35d28d2  pop rax
00007d07b35d28d3  add rsp, 0x08
00007d07b35d28d7  jmp 0x00007D07B35CFD72
00007d07b35d28dc  sub rsp, 0x08
00007d07b35d28e0  push rax
00007d07b35d28e1  push rcx
00007d07b35d28e2  push rdx
00007d07b35d28e3  push rdi
00007d07b35d28e4  push rsi
00007d07b35d28e5  push r8
00007d07b35d28e7  push r9
00007d07b35d28e9  push r10
00007d07b35d28eb  push r11
00007d07b35d28ed  sub rsp, 0xF0
00007d07b35d28f4  vmovaps [rsp], xmm0
00007d07b35d28f9  vmovaps [rsp+0x10], xmm1
00007d07b35d28ff  vmovaps [rsp+0x20], xmm2
00007d07b35d2905  vmovaps [rsp+0x30], xmm3
00007d07b35d290b  vmovaps [rsp+0x40], xmm4
00007d07b35d2911  vmovaps [rsp+0x50], xmm5
00007d07b35d2917  vmovaps [rsp+0x60], xmm7
00007d07b35d291d  vmovaps [rsp+0x70], xmm8
00007d07b35d2923  vmovaps [rsp+0x80], xmm9
00007d07b35d292c  vmovaps [rsp+0x90], xmm10
00007d07b35d2935  vmovaps [rsp+0xA0], xmm11
00007d07b35d293e  vmovaps [rsp+0xB0], xmm12
00007d07b35d2947  vmovaps [rsp+0xC0], xmm13
00007d07b35d2950  vmovaps [rsp+0xD0], xmm14
00007d07b35d2959  vmovaps [rsp+0xE0], xmm15
00007d07b35d2962  sub rsp, 0x30
00007d07b35d2966  movaps [rsp], xmm6
00007d07b35d296a  movaps [rsp+0x10], xmm5
00007d07b35d296f  movaps [rsp+0x20], xmm1
00007d07b35d2974  lea rdi, [rsp]
00007d07b35d2978  mov esi, 0x00
00007d07b35d297d  mov rax, 0x5D0AA712D530
00007d07b35d2987  call rax
00007d07b35d2989  movaps xmm6, [rsp]
00007d07b35d298d  add rsp, 0x30
00007d07b35d2991  vmovaps xmm0, [rsp]
00007d07b35d2996  vmovaps xmm1, [rsp+0x10]
00007d07b35d299c  vmovaps xmm2, [rsp+0x20]
00007d07b35d29a2  vmovaps xmm3, [rsp+0x30]
00007d07b35d29a8  vmovaps xmm4, [rsp+0x40]
00007d07b35d29ae  vmovaps xmm5, [rsp+0x50]
00007d07b35d29b4  vmovaps xmm7, [rsp+0x60]
00007d07b35d29ba  vmovaps xmm8, [rsp+0x70]
00007d07b35d29c0  vmovaps xmm9, [rsp+0x80]
00007d07b35d29c9  vmovaps xmm10, [rsp+0x90]
00007d07b35d29d2  vmovaps xmm11, [rsp+0xA0]
00007d07b35d29db  vmovaps xmm12, [rsp+0xB0]
00007d07b35d29e4  vmovaps xmm13, [rsp+0xC0]
00007d07b35d29ed  vmovaps xmm14, [rsp+0xD0]
00007d07b35d29f6  vmovaps xmm15, [rsp+0xE0]
00007d07b35d29ff  add rsp, 0xF0
00007d07b35d2a06  pop r11
00007d07b35d2a08  pop r10
00007d07b35d2a0a  pop r9
00007d07b35d2a0c  pop r8
00007d07b35d2a0e  pop rsi
00007d07b35d2a0f  pop rdi
00007d07b35d2a10  pop rdx
00007d07b35d2a11  pop rcx
00007d07b35d2a12  pop rax
00007d07b35d2a13  add rsp, 0x08
00007d07b35d2a17  jmp 0x00007D07B35CFD98
00007d07b35d2a1c  sub rsp, 0x08
00007d07b35d2a20  push rax
00007d07b35d2a21  push rcx
00007d07b35d2a22  push rdx
00007d07b35d2a23  push rdi
00007d07b35d2a24  push rsi
00007d07b35d2a25  push r8
00007d07b35d2a27  push r9
00007d07b35d2a29  push r10
00007d07b35d2a2b  push r11
00007d07b35d2a2d  sub rsp, 0xF0
00007d07b35d2a34  vmovaps [rsp], xmm0
00007d07b35d2a39  vmovaps [rsp+0x10], xmm2
00007d07b35d2a3f  vmovaps [rsp+0x20], xmm3
00007d07b35d2a45  vmovaps [rsp+0x30], xmm4
00007d07b35d2a4b  vmovaps [rsp+0x40], xmm5
00007d07b35d2a51  vmovaps [rsp+0x50], xmm6
00007d07b35d2a57  vmovaps [rsp+0x60], xmm7
00007d07b35d2a5d  vmovaps [rsp+0x70], xmm8
00007d07b35d2a63  vmovaps [rsp+0x80], xmm9
00007d07b35d2a6c  vmovaps [rsp+0x90], xmm10
00007d07b35d2a75  vmovaps [rsp+0xA0], xmm11
00007d07b35d2a7e  vmovaps [rsp+0xB0], xmm12
00007d07b35d2a87  vmovaps [rsp+0xC0], xmm13
00007d07b35d2a90  vmovaps [rsp+0xD0], xmm14
00007d07b35d2a99  vmovaps [rsp+0xE0], xmm15
00007d07b35d2aa2  sub rsp, 0x30
00007d07b35d2aa6  movaps [rsp], xmm1
00007d07b35d2aaa  movaps [rsp+0x10], xmm5
00007d07b35d2aaf  movaps [rsp+0x20], xmm13
00007d07b35d2ab5  lea rdi, [rsp]
00007d07b35d2ab9  mov esi, 0x00
00007d07b35d2abe  mov rax, 0x5D0AA712D530
00007d07b35d2ac8  call rax
00007d07b35d2aca  movaps xmm1, [rsp]
00007d07b35d2ace  add rsp, 0x30
00007d07b35d2ad2  vmovaps xmm0, [rsp]
00007d07b35d2ad7  vmovaps xmm2, [rsp+0x10]
00007d07b35d2add  vmovaps xmm3, [rsp+0x20]
00007d07b35d2ae3  vmovaps xmm4, [rsp+0x30]
00007d07b35d2ae9  vmovaps xmm5, [rsp+0x40]
00007d07b35d2aef  vmovaps xmm6, [rsp+0x50]
00007d07b35d2af5  vmovaps xmm7, [rsp+0x60]
00007d07b35d2afb  vmovaps xmm8, [rsp+0x70]
00007d07b35d2b01  vmovaps xmm9, [rsp+0x80]
00007d07b35d2b0a  vmovaps xmm10, [rsp+0x90]
00007d07b35d2b13  vmovaps xmm11, [rsp+0xA0]
00007d07b35d2b1c  vmovaps xmm12, [rsp+0xB0]
00007d07b35d2b25  vmovaps xmm13, [rsp+0xC0]
00007d07b35d2b2e  vmovaps xmm14, [rsp+0xD0]
00007d07b35d2b37  vmovaps xmm15, [rsp+0xE0]
00007d07b35d2b40  add rsp, 0xF0
00007d07b35d2b47  pop r11
00007d07b35d2b49  pop r10
00007d07b35d2b4b  pop r9
00007d07b35d2b4d  pop r8
00007d07b35d2b4f  pop rsi
00007d07b35d2b50  pop rdi
00007d07b35d2b51  pop rdx
00007d07b35d2b52  pop rcx
00007d07b35d2b53  pop rax
00007d07b35d2b54  add rsp, 0x08
00007d07b35d2b58  jmp 0x00007D07B35CFDB6
00007d07b35d2b5d  sub rsp, 0x08
00007d07b35d2b61  push rax
00007d07b35d2b62  push rcx
00007d07b35d2b63  push rdx
00007d07b35d2b64  push rdi
00007d07b35d2b65  push rsi
00007d07b35d2b66  push r8
00007d07b35d2b68  push r9
00007d07b35d2b6a  push r10
00007d07b35d2b6c  push r11
00007d07b35d2b6e  sub rsp, 0xF0
00007d07b35d2b75  vmovaps [rsp], xmm0
00007d07b35d2b7a  vmovaps [rsp+0x10], xmm1
00007d07b35d2b80  vmovaps [rsp+0x20], xmm2
00007d07b35d2b86  vmovaps [rsp+0x30], xmm3
00007d07b35d2b8c  vmovaps [rsp+0x40], xmm4
00007d07b35d2b92  vmovaps [rsp+0x50], xmm6
00007d07b35d2b98  vmovaps [rsp+0x60], xmm7
00007d07b35d2b9e  vmovaps [rsp+0x70], xmm8
00007d07b35d2ba4  vmovaps [rsp+0x80], xmm9
00007d07b35d2bad  vmovaps [rsp+0x90], xmm10
00007d07b35d2bb6  vmovaps [rsp+0xA0], xmm11
00007d07b35d2bbf  vmovaps [rsp+0xB0], xmm12
00007d07b35d2bc8  vmovaps [rsp+0xC0], xmm13
00007d07b35d2bd1  vmovaps [rsp+0xD0], xmm14
00007d07b35d2bda  vmovaps [rsp+0xE0], xmm15
00007d07b35d2be3  sub rsp, 0x30
00007d07b35d2be7  movaps [rsp], xmm5
00007d07b35d2beb  movaps [rsp+0x10], xmm2
00007d07b35d2bf0  movaps [rsp+0x20], xmm13
00007d07b35d2bf6  lea rdi, [rsp]
00007d07b35d2bfa  mov esi, 0x00
00007d07b35d2bff  mov rax, 0x5D0AA712D530
00007d07b35d2c09  call rax
00007d07b35d2c0b  movaps xmm5, [rsp]
00007d07b35d2c0f  add rsp, 0x30
00007d07b35d2c13  vmovaps xmm0, [rsp]
00007d07b35d2c18  vmovaps xmm1, [rsp+0x10]
00007d07b35d2c1e  vmovaps xmm2, [rsp+0x20]
00007d07b35d2c24  vmovaps xmm3, [rsp+0x30]
00007d07b35d2c2a  vmovaps xmm4, [rsp+0x40]
00007d07b35d2c30  vmovaps xmm6, [rsp+0x50]
00007d07b35d2c36  vmovaps xmm7, [rsp+0x60]
00007d07b35d2c3c  vmovaps xmm8, [rsp+0x70]
00007d07b35d2c42  vmovaps xmm9, [rsp+0x80]
00007d07b35d2c4b  vmovaps xmm10, [rsp+0x90]
00007d07b35d2c54  vmovaps xmm11, [rsp+0xA0]
00007d07b35d2c5d  vmovaps xmm12, [rsp+0xB0]
00007d07b35d2c66  vmovaps xmm13, [rsp+0xC0]
00007d07b35d2c6f  vmovaps xmm14, [rsp+0xD0]
00007d07b35d2c78  vmovaps xmm15, [rsp+0xE0]
00007d07b35d2c81  add rsp, 0xF0
00007d07b35d2c88  pop r11
00007d07b35d2c8a  pop r10
00007d07b35d2c8c  pop r9
00007d07b35d2c8e  pop r8
00007d07b35d2c90  pop rsi
00007d07b35d2c91  pop rdi
00007d07b35d2c92  pop rdx
00007d07b35d2c93  pop rcx
00007d07b35d2c94  pop rax
00007d07b35d2c95  add rsp, 0x08
00007d07b35d2c99  jmp 0x00007D07B35CFDEC
00007d07b35d2c9e  sub rsp, 0x08
00007d07b35d2ca2  push rax
00007d07b35d2ca3  push rcx
00007d07b35d2ca4  push rdx
00007d07b35d2ca5  push rdi
00007d07b35d2ca6  push rsi
00007d07b35d2ca7  push r8
00007d07b35d2ca9  push r9
00007d07b35d2cab  push r10
00007d07b35d2cad  push r11
00007d07b35d2caf  sub rsp, 0xF0
00007d07b35d2cb6  vmovaps [rsp], xmm0
00007d07b35d2cbb  vmovaps [rsp+0x10], xmm1
00007d07b35d2cc1  vmovaps [rsp+0x20], xmm2
00007d07b35d2cc7  vmovaps [rsp+0x30], xmm3
00007d07b35d2ccd  vmovaps [rsp+0x40], xmm4
00007d07b35d2cd3  vmovaps [rsp+0x50], xmm5
00007d07b35d2cd9  vmovaps [rsp+0x60], xmm6
00007d07b35d2cdf  vmovaps [rsp+0x70], xmm7
00007d07b35d2ce5  vmovaps [rsp+0x80], xmm8
00007d07b35d2cee  vmovaps [rsp+0x90], xmm9
00007d07b35d2cf7  vmovaps [rsp+0xA0], xmm10
00007d07b35d2d00  vmovaps [rsp+0xB0], xmm11
00007d07b35d2d09  vmovaps [rsp+0xC0], xmm12
00007d07b35d2d12  vmovaps [rsp+0xD0], xmm14
00007d07b35d2d1b  vmovaps [rsp+0xE0], xmm15
00007d07b35d2d24  sub rsp, 0x30
00007d07b35d2d28  movaps [rsp], xmm13
00007d07b35d2d2d  movaps [rsp+0x10], xmm10
00007d07b35d2d33  movaps [rsp+0x20], xmm1
00007d07b35d2d38  lea rdi, [rsp]
00007d07b35d2d3c  mov esi, 0x00
00007d07b35d2d41  mov rax, 0x5D0AA712D530
00007d07b35d2d4b  call rax
00007d07b35d2d4d  movaps xmm13, [rsp]
00007d07b35d2d52  add rsp, 0x30
00007d07b35d2d56  vmovaps xmm0, [rsp]
00007d07b35d2d5b  vmovaps xmm1, [rsp+0x10]
00007d07b35d2d61  vmovaps xmm2, [rsp+0x20]
00007d07b35d2d67  vmovaps xmm3, [rsp+0x30]
00007d07b35d2d6d  vmovaps xmm4, [rsp+0x40]
00007d07b35d2d73  vmovaps xmm5, [rsp+0x50]
00007d07b35d2d79  vmovaps xmm6, [rsp+0x60]
00007d07b35d2d7f  vmovaps xmm7, [rsp+0x70]
00007d07b35d2d85  vmovaps xmm8, [rsp+0x80]
00007d07b35d2d8e  vmovaps xmm9, [rsp+0x90]
00007d07b35d2d97  vmovaps xmm10, [rsp+0xA0]
00007d07b35d2da0  vmovaps xmm11, [rsp+0xB0]
00007d07b35d2da9  vmovaps xmm12, [rsp+0xC0]
00007d07b35d2db2  vmovaps xmm14, [rsp+0xD0]
00007d07b35d2dbb  vmovaps xmm15, [rsp+0xE0]
00007d07b35d2dc4  add rsp, 0xF0
00007d07b35d2dcb  pop r11
00007d07b35d2dcd  pop r10
00007d07b35d2dcf  pop r9
00007d07b35d2dd1  pop r8
00007d07b35d2dd3  pop rsi
00007d07b35d2dd4  pop rdi
00007d07b35d2dd5  pop rdx
00007d07b35d2dd6  pop rcx
00007d07b35d2dd7  pop rax
00007d07b35d2dd8  add rsp, 0x08
00007d07b35d2ddc  jmp 0x00007D07B35CFE15
00007d07b35d2de1  sub rsp, 0x08
00007d07b35d2de5  push rax
00007d07b35d2de6  push rcx
00007d07b35d2de7  push rdx
00007d07b35d2de8  push rdi
00007d07b35d2de9  push rsi
00007d07b35d2dea  push r8
00007d07b35d2dec  push r9
00007d07b35d2dee  push r10
00007d07b35d2df0  push r11
00007d07b35d2df2  sub rsp, 0xF0
00007d07b35d2df9  vmovaps [rsp], xmm0
00007d07b35d2dfe  vmovaps [rsp+0x10], xmm2
00007d07b35d2e04  vmovaps [rsp+0x20], xmm3
00007d07b35d2e0a  vmovaps [rsp+0x30], xmm4
00007d07b35d2e10  vmovaps [rsp+0x40], xmm5
00007d07b35d2e16  vmovaps [rsp+0x50], xmm6
00007d07b35d2e1c  vmovaps [rsp+0x60], xmm7
00007d07b35d2e22  vmovaps [rsp+0x70], xmm8
00007d07b35d2e28  vmovaps [rsp+0x80], xmm9
00007d07b35d2e31  vmovaps [rsp+0x90], xmm10
00007d07b35d2e3a  vmovaps [rsp+0xA0], xmm11
00007d07b35d2e43  vmovaps [rsp+0xB0], xmm12
00007d07b35d2e4c  vmovaps [rsp+0xC0], xmm13
00007d07b35d2e55  vmovaps [rsp+0xD0], xmm14
00007d07b35d2e5e  vmovaps [rsp+0xE0], xmm15
00007d07b35d2e67  sub rsp, 0x30
00007d07b35d2e6b  movaps [rsp], xmm1
00007d07b35d2e6f  movaps [rsp+0x10], xmm15
00007d07b35d2e75  movaps [rsp+0x20], xmm10
00007d07b35d2e7b  lea rdi, [rsp]
00007d07b35d2e7f  mov esi, 0x00
00007d07b35d2e84  mov rax, 0x5D0AA712D530
00007d07b35d2e8e  call rax
00007d07b35d2e90  movaps xmm1, [rsp]
00007d07b35d2e94  add rsp, 0x30
00007d07b35d2e98  vmovaps xmm0, [rsp]
00007d07b35d2e9d  vmovaps xmm2, [rsp+0x10]
00007d07b35d2ea3  vmovaps xmm3, [rsp+0x20]
00007d07b35d2ea9  vmovaps xmm4, [rsp+0x30]
00007d07b35d2eaf  vmovaps xmm5, [rsp+0x40]
00007d07b35d2eb5  vmovaps xmm6, [rsp+0x50]
00007d07b35d2ebb  vmovaps xmm7, [rsp+0x60]
00007d07b35d2ec1  vmovaps xmm8, [rsp+0x70]
00007d07b35d2ec7  vmovaps xmm9, [rsp+0x80]
00007d07b35d2ed0  vmovaps xmm10, [rsp+0x90]
00007d07b35d2ed9  vmovaps xmm11, [rsp+0xA0]
00007d07b35d2ee2  vmovaps xmm12, [rsp+0xB0]
00007d07b35d2eeb  vmovaps xmm13, [rsp+0xC0]
00007d07b35d2ef4  vmovaps xmm14, [rsp+0xD0]
00007d07b35d2efd  vmovaps xmm15, [rsp+0xE0]
00007d07b35d2f06  add rsp, 0xF0
00007d07b35d2f0d  pop r11
00007d07b35d2f0f  pop r10
00007d07b35d2f11  pop r9
00007d07b35d2f13  pop r8
00007d07b35d2f15  pop rsi
00007d07b35d2f16  pop rdi
00007d07b35d2f17  pop rdx
00007d07b35d2f18  pop rcx
00007d07b35d2f19  pop rax
00007d07b35d2f1a  add rsp, 0x08
00007d07b35d2f1e  jmp 0x00007D07B35CFE34
00007d07b35d2f23  sub rsp, 0x08
00007d07b35d2f27  push rax
00007d07b35d2f28  push rcx
00007d07b35d2f29  push rdx
00007d07b35d2f2a  push rdi
00007d07b35d2f2b  push rsi
00007d07b35d2f2c  push r8
00007d07b35d2f2e  push r9
00007d07b35d2f30  push r10
00007d07b35d2f32  push r11
00007d07b35d2f34  sub rsp, 0xF0
00007d07b35d2f3b  vmovaps [rsp], xmm0
00007d07b35d2f40  vmovaps [rsp+0x10], xmm1
00007d07b35d2f46  vmovaps [rsp+0x20], xmm2
00007d07b35d2f4c  vmovaps [rsp+0x30], xmm3
00007d07b35d2f52  vmovaps [rsp+0x40], xmm4
00007d07b35d2f58  vmovaps [rsp+0x50], xmm5
00007d07b35d2f5e  vmovaps [rsp+0x60], xmm6
00007d07b35d2f64  vmovaps [rsp+0x70], xmm7
00007d07b35d2f6a  vmovaps [rsp+0x80], xmm8
00007d07b35d2f73  vmovaps [rsp+0x90], xmm9
00007d07b35d2f7c  vmovaps [rsp+0xA0], xmm10
00007d07b35d2f85  vmovaps [rsp+0xB0], xmm11
00007d07b35d2f8e  vmovaps [rsp+0xC0], xmm12
00007d07b35d2f97  vmovaps [rsp+0xD0], xmm13
00007d07b35d2fa0  vmovaps [rsp+0xE0], xmm14
00007d07b35d2fa9  sub rsp, 0x30
00007d07b35d2fad  movaps [rsp], xmm15
00007d07b35d2fb2  movaps [rsp+0x10], xmm10
00007d07b35d2fb8  movaps [rsp+0x20], xmm11
00007d07b35d2fbe  lea rdi, [rsp]
00007d07b35d2fc2  mov esi, 0x00
00007d07b35d2fc7  mov rax, 0x5D0AA712D530
00007d07b35d2fd1  call rax
00007d07b35d2fd3  movaps xmm15, [rsp]
00007d07b35d2fd8  add rsp, 0x30
00007d07b35d2fdc  vmovaps xmm0, [rsp]
00007d07b35d2fe1  vmovaps xmm1, [rsp+0x10]
00007d07b35d2fe7  vmovaps xmm2, [rsp+0x20]
00007d07b35d2fed  vmovaps xmm3, [rsp+0x30]
00007d07b35d2ff3  vmovaps xmm4, [rsp+0x40]
00007d07b35d2ff9  vmovaps xmm5, [rsp+0x50]
00007d07b35d2fff  vmovaps xmm6, [rsp+0x60]
00007d07b35d3005  vmovaps xmm7, [rsp+0x70]
00007d07b35d300b  vmovaps xmm8, [rsp+0x80]
00007d07b35d3014  vmovaps xmm9, [rsp+0x90]
00007d07b35d301d  vmovaps xmm10, [rsp+0xA0]
00007d07b35d3026  vmovaps xmm11, [rsp+0xB0]
00007d07b35d302f  vmovaps xmm12, [rsp+0xC0]
00007d07b35d3038  vmovaps xmm13, [rsp+0xD0]
00007d07b35d3041  vmovaps xmm14, [rsp+0xE0]
00007d07b35d304a  add rsp, 0xF0
00007d07b35d3051  pop r11
00007d07b35d3053  pop r10
00007d07b35d3055  pop r9
00007d07b35d3057  pop r8
00007d07b35d3059  pop rsi
00007d07b35d305a  pop rdi
00007d07b35d305b  pop rdx
00007d07b35d305c  pop rcx
00007d07b35d305d  pop rax
00007d07b35d305e  add rsp, 0x08
00007d07b35d3062  jmp 0x00007D07B35CFE57
00007d07b35d3067  sub rsp, 0x08
00007d07b35d306b  push rax
00007d07b35d306c  push rcx
00007d07b35d306d  push rdx
00007d07b35d306e  push rdi
00007d07b35d306f  push rsi
00007d07b35d3070  push r8
00007d07b35d3072  push r9
00007d07b35d3074  push r10
00007d07b35d3076  push r11
00007d07b35d3078  sub rsp, 0xF0
00007d07b35d307f  vmovaps [rsp], xmm0
00007d07b35d3084  vmovaps [rsp+0x10], xmm1
00007d07b35d308a  vmovaps [rsp+0x20], xmm2
00007d07b35d3090  vmovaps [rsp+0x30], xmm3
00007d07b35d3096  vmovaps [rsp+0x40], xmm4
00007d07b35d309c  vmovaps [rsp+0x50], xmm5
00007d07b35d30a2  vmovaps [rsp+0x60], xmm6
00007d07b35d30a8  vmovaps [rsp+0x70], xmm7
00007d07b35d30ae  vmovaps [rsp+0x80], xmm8
00007d07b35d30b7  vmovaps [rsp+0x90], xmm9
00007d07b35d30c0  vmovaps [rsp+0xA0], xmm11
00007d07b35d30c9  vmovaps [rsp+0xB0], xmm12
00007d07b35d30d2  vmovaps [rsp+0xC0], xmm13
00007d07b35d30db  vmovaps [rsp+0xD0], xmm14
00007d07b35d30e4  vmovaps [rsp+0xE0], xmm15
00007d07b35d30ed  sub rsp, 0x30
00007d07b35d30f1  movaps [rsp], xmm10
00007d07b35d30f6  movaps [rsp+0x10], xmm12
00007d07b35d30fc  movaps [rsp+0x20], xmm11
00007d07b35d3102  lea rdi, [rsp]
00007d07b35d3106  mov esi, 0x00
00007d07b35d310b  mov rax, 0x5D0AA712D530
00007d07b35d3115  call rax
00007d07b35d3117  movaps xmm10, [rsp]
00007d07b35d311c  add rsp, 0x30
00007d07b35d3120  vmovaps xmm0, [rsp]
00007d07b35d3125  vmovaps xmm1, [rsp+0x10]
00007d07b35d312b  vmovaps xmm2, [rsp+0x20]
00007d07b35d3131  vmovaps xmm3, [rsp+0x30]
00007d07b35d3137  vmovaps xmm4, [rsp+0x40]
00007d07b35d313d  vmovaps xmm5, [rsp+0x50]
00007d07b35d3143  vmovaps xmm6, [rsp+0x60]
00007d07b35d3149  vmovaps xmm7, [rsp+0x70]
00007d07b35d314f  vmovaps xmm8, [rsp+0x80]
00007d07b35d3158  vmovaps xmm9, [rsp+0x90]
00007d07b35d3161  vmovaps xmm11, [rsp+0xA0]
00007d07b35d316a  vmovaps xmm12, [rsp+0xB0]
00007d07b35d3173  vmovaps xmm13, [rsp+0xC0]
00007d07b35d317c  vmovaps xmm14, [rsp+0xD0]
00007d07b35d3185  vmovaps xmm15, [rsp+0xE0]
00007d07b35d318e  add rsp, 0xF0
00007d07b35d3195  pop r11
00007d07b35d3197  pop r10
00007d07b35d3199  pop r9
00007d07b35d319b  pop r8
00007d07b35d319d  pop rsi
00007d07b35d319e  pop rdi
00007d07b35d319f  pop rdx
00007d07b35d31a0  pop rcx
00007d07b35d31a1  pop rax
00007d07b35d31a2  add rsp, 0x08
00007d07b35d31a6  jmp 0x00007D07B35CFE80
00007d07b35d31ab  sub rsp, 0x08
00007d07b35d31af  push rax
00007d07b35d31b0  push rcx
00007d07b35d31b1  push rdx
00007d07b35d31b2  push rdi
00007d07b35d31b3  push rsi
00007d07b35d31b4  push r8
00007d07b35d31b6  push r9
00007d07b35d31b8  push r10
00007d07b35d31ba  push r11
00007d07b35d31bc  sub rsp, 0xF0
00007d07b35d31c3  vmovaps [rsp], xmm0
00007d07b35d31c8  vmovaps [rsp+0x10], xmm1
00007d07b35d31ce  vmovaps [rsp+0x20], xmm2
00007d07b35d31d4  vmovaps [rsp+0x30], xmm3
00007d07b35d31da  vmovaps [rsp+0x40], xmm4
00007d07b35d31e0  vmovaps [rsp+0x50], xmm5
00007d07b35d31e6  vmovaps [rsp+0x60], xmm6
00007d07b35d31ec  vmovaps [rsp+0x70], xmm7
00007d07b35d31f2  vmovaps [rsp+0x80], xmm8
00007d07b35d31fb  vmovaps [rsp+0x90], xmm9
00007d07b35d3204  vmovaps [rsp+0xA0], xmm10
00007d07b35d320d  vmovaps [rsp+0xB0], xmm12
00007d07b35d3216  vmovaps [rsp+0xC0], xmm13
00007d07b35d321f  vmovaps [rsp+0xD0], xmm14
00007d07b35d3228  vmovaps [rsp+0xE0], xmm15
00007d07b35d3231  sub rsp, 0x30
00007d07b35d3235  movaps [rsp], xmm11
00007d07b35d323a  movaps [rsp+0x10], xmm2
00007d07b35d323f  movaps [rsp+0x20], xmm12
00007d07b35d3245  lea rdi, [rsp]
00007d07b35d3249  mov esi, 0x00
00007d07b35d324e  mov rax, 0x5D0AA712D530
00007d07b35d3258  call rax
00007d07b35d325a  movaps xmm11, [rsp]
00007d07b35d325f  add rsp, 0x30
00007d07b35d3263  vmovaps xmm0, [rsp]
00007d07b35d3268  vmovaps xmm1, [rsp+0x10]
00007d07b35d326e  vmovaps xmm2, [rsp+0x20]
00007d07b35d3274  vmovaps xmm3, [rsp+0x30]
00007d07b35d327a  vmovaps xmm4, [rsp+0x40]
00007d07b35d3280  vmovaps xmm5, [rsp+0x50]
00007d07b35d3286  vmovaps xmm6, [rsp+0x60]
00007d07b35d328c  vmovaps xmm7, [rsp+0x70]
00007d07b35d3292  vmovaps xmm8, [rsp+0x80]
00007d07b35d329b  vmovaps xmm9, [rsp+0x90]
00007d07b35d32a4  vmovaps xmm10, [rsp+0xA0]
00007d07b35d32ad  vmovaps xmm12, [rsp+0xB0]
00007d07b35d32b6  vmovaps xmm13, [rsp+0xC0]
00007d07b35d32bf  vmovaps xmm14, [rsp+0xD0]
00007d07b35d32c8  vmovaps xmm15, [rsp+0xE0]
00007d07b35d32d1  add rsp, 0xF0
00007d07b35d32d8  pop r11
00007d07b35d32da  pop r10
00007d07b35d32dc  pop r9
00007d07b35d32de  pop r8
00007d07b35d32e0  pop rsi
00007d07b35d32e1  pop rdi
00007d07b35d32e2  pop rdx
00007d07b35d32e3  pop rcx
00007d07b35d32e4  pop rax
00007d07b35d32e5  add rsp, 0x08
00007d07b35d32e9  jmp 0x00007D07B35CFEB8
00007d07b35d32ee  sub rsp, 0x08
00007d07b35d32f2  push rax
00007d07b35d32f3  push rcx
00007d07b35d32f4  push rdx
00007d07b35d32f5  push rdi
00007d07b35d32f6  push rsi
00007d07b35d32f7  push r8
00007d07b35d32f9  push r9
00007d07b35d32fb  push r10
00007d07b35d32fd  push r11
00007d07b35d32ff  sub rsp, 0xF0
00007d07b35d3306  vmovaps [rsp], xmm0
00007d07b35d330b  vmovaps [rsp+0x10], xmm2
00007d07b35d3311  vmovaps [rsp+0x20], xmm3
00007d07b35d3317  vmovaps [rsp+0x30], xmm4
00007d07b35d331d  vmovaps [rsp+0x40], xmm5
00007d07b35d3323  vmovaps [rsp+0x50], xmm6
00007d07b35d3329  vmovaps [rsp+0x60], xmm7
00007d07b35d332f  vmovaps [rsp+0x70], xmm8
00007d07b35d3335  vmovaps [rsp+0x80], xmm9
00007d07b35d333e  vmovaps [rsp+0x90], xmm10
00007d07b35d3347  vmovaps [rsp+0xA0], xmm11
00007d07b35d3350  vmovaps [rsp+0xB0], xmm12
00007d07b35d3359  vmovaps [rsp+0xC0], xmm13
00007d07b35d3362  vmovaps [rsp+0xD0], xmm14
00007d07b35d336b  vmovaps [rsp+0xE0], xmm15
00007d07b35d3374  sub rsp, 0x30
00007d07b35d3378  movaps [rsp], xmm1
00007d07b35d337c  movaps [rsp+0x10], xmm14
00007d07b35d3382  movaps [rsp+0x20], xmm6
00007d07b35d3387  lea rdi, [rsp]
00007d07b35d338b  mov esi, 0x00
00007d07b35d3390  mov rax, 0x5D0AA712D530
00007d07b35d339a  call rax
00007d07b35d339c  movaps xmm1, [rsp]
00007d07b35d33a0  add rsp, 0x30
00007d07b35d33a4  vmovaps xmm0, [rsp]
00007d07b35d33a9  vmovaps xmm2, [rsp+0x10]
00007d07b35d33af  vmovaps xmm3, [rsp+0x20]
00007d07b35d33b5  vmovaps xmm4, [rsp+0x30]
00007d07b35d33bb  vmovaps xmm5, [rsp+0x40]
00007d07b35d33c1  vmovaps xmm6, [rsp+0x50]
00007d07b35d33c7  vmovaps xmm7, [rsp+0x60]
00007d07b35d33cd  vmovaps xmm8, [rsp+0x70]
00007d07b35d33d3  vmovaps xmm9, [rsp+0x80]
00007d07b35d33dc  vmovaps xmm10, [rsp+0x90]
00007d07b35d33e5  vmovaps xmm11, [rsp+0xA0]
00007d07b35d33ee  vmovaps xmm12, [rsp+0xB0]
00007d07b35d33f7  vmovaps xmm13, [rsp+0xC0]
00007d07b35d3400  vmovaps xmm14, [rsp+0xD0]
00007d07b35d3409  vmovaps xmm15, [rsp+0xE0]
00007d07b35d3412  add rsp, 0xF0
00007d07b35d3419  pop r11
00007d07b35d341b  pop r10
00007d07b35d341d  pop r9
00007d07b35d341f  pop r8
00007d07b35d3421  pop rsi
00007d07b35d3422  pop rdi
00007d07b35d3423  pop rdx
00007d07b35d3424  pop rcx
00007d07b35d3425  pop rax
00007d07b35d3426  add rsp, 0x08
00007d07b35d342a  jmp 0x00007D07B35CFED1
00007d07b35d342f  sub rsp, 0x08
00007d07b35d3433  push rax
00007d07b35d3434  push rcx
00007d07b35d3435  push rdx
00007d07b35d3436  push rdi
00007d07b35d3437  push rsi
00007d07b35d3438  push r8
00007d07b35d343a  push r9
00007d07b35d343c  push r10
00007d07b35d343e  push r11
00007d07b35d3440  sub rsp, 0xF0
00007d07b35d3447  vmovaps [rsp], xmm0
00007d07b35d344c  vmovaps [rsp+0x10], xmm1
00007d07b35d3452  vmovaps [rsp+0x20], xmm2
00007d07b35d3458  vmovaps [rsp+0x30], xmm3
00007d07b35d345e  vmovaps [rsp+0x40], xmm4
00007d07b35d3464  vmovaps [rsp+0x50], xmm5
00007d07b35d346a  vmovaps [rsp+0x60], xmm6
00007d07b35d3470  vmovaps [rsp+0x70], xmm7
00007d07b35d3476  vmovaps [rsp+0x80], xmm8
00007d07b35d347f  vmovaps [rsp+0x90], xmm9
00007d07b35d3488  vmovaps [rsp+0xA0], xmm10
00007d07b35d3491  vmovaps [rsp+0xB0], xmm11
00007d07b35d349a  vmovaps [rsp+0xC0], xmm12
00007d07b35d34a3  vmovaps [rsp+0xD0], xmm13
00007d07b35d34ac  vmovaps [rsp+0xE0], xmm15
00007d07b35d34b5  sub rsp, 0x30
00007d07b35d34b9  movaps [rsp], xmm14
00007d07b35d34be  movaps [rsp+0x10], xmm12
00007d07b35d34c4  movaps [rsp+0x20], xmm5
00007d07b35d34c9  lea rdi, [rsp]
00007d07b35d34cd  mov esi, 0x00
00007d07b35d34d2  mov rax, 0x5D0AA712D530
00007d07b35d34dc  call rax
00007d07b35d34de  movaps xmm14, [rsp]
00007d07b35d34e3  add rsp, 0x30
00007d07b35d34e7  vmovaps xmm0, [rsp]
00007d07b35d34ec  vmovaps xmm1, [rsp+0x10]
00007d07b35d34f2  vmovaps xmm2, [rsp+0x20]
00007d07b35d34f8  vmovaps xmm3, [rsp+0x30]
00007d07b35d34fe  vmovaps xmm4, [rsp+0x40]
00007d07b35d3504  vmovaps xmm5, [rsp+0x50]
00007d07b35d350a  vmovaps xmm6, [rsp+0x60]
00007d07b35d3510  vmovaps xmm7, [rsp+0x70]
00007d07b35d3516  vmovaps xmm8, [rsp+0x80]
00007d07b35d351f  vmovaps xmm9, [rsp+0x90]
00007d07b35d3528  vmovaps xmm10, [rsp+0xA0]
00007d07b35d3531  vmovaps xmm11, [rsp+0xB0]
00007d07b35d353a  vmovaps xmm12, [rsp+0xC0]
00007d07b35d3543  vmovaps xmm13, [rsp+0xD0]
00007d07b35d354c  vmovaps xmm15, [rsp+0xE0]
00007d07b35d3555  add rsp, 0xF0
00007d07b35d355c  pop r11
00007d07b35d355e  pop r10
00007d07b35d3560  pop r9
00007d07b35d3562  pop r8
00007d07b35d3564  pop rsi
00007d07b35d3565  pop rdi
00007d07b35d3566  pop rdx
00007d07b35d3567  pop rcx
00007d07b35d3568  pop rax
00007d07b35d3569  add rsp, 0x08
00007d07b35d356d  jmp 0x00007D07B35CFEF1
00007d07b35d3572  sub rsp, 0x08
00007d07b35d3576  push rax
00007d07b35d3577  push rcx
00007d07b35d3578  push rdx
00007d07b35d3579  push rdi
00007d07b35d357a  push rsi
00007d07b35d357b  push r8
00007d07b35d357d  push r9
00007d07b35d357f  push r10
00007d07b35d3581  push r11
00007d07b35d3583  sub rsp, 0xF0
00007d07b35d358a  vmovaps [rsp], xmm0
00007d07b35d358f  vmovaps [rsp+0x10], xmm1
00007d07b35d3595  vmovaps [rsp+0x20], xmm2
00007d07b35d359b  vmovaps [rsp+0x30], xmm3
00007d07b35d35a1  vmovaps [rsp+0x40], xmm4
00007d07b35d35a7  vmovaps [rsp+0x50], xmm5
00007d07b35d35ad  vmovaps [rsp+0x60], xmm7
00007d07b35d35b3  vmovaps [rsp+0x70], xmm8
00007d07b35d35b9  vmovaps [rsp+0x80], xmm9
00007d07b35d35c2  vmovaps [rsp+0x90], xmm10
00007d07b35d35cb  vmovaps [rsp+0xA0], xmm11
00007d07b35d35d4  vmovaps [rsp+0xB0], xmm12
00007d07b35d35dd  vmovaps [rsp+0xC0], xmm13
00007d07b35d35e6  vmovaps [rsp+0xD0], xmm14
00007d07b35d35ef  vmovaps [rsp+0xE0], xmm15
00007d07b35d35f8  sub rsp, 0x30
00007d07b35d35fc  movaps [rsp], xmm6
00007d07b35d3600  movaps [rsp+0x10], xmm9
00007d07b35d3606  movaps [rsp+0x20], xmm12
00007d07b35d360c  lea rdi, [rsp]
00007d07b35d3610  mov esi, 0x00
00007d07b35d3615  mov rax, 0x5D0AA712D530
00007d07b35d361f  call rax
00007d07b35d3621  movaps xmm6, [rsp]
00007d07b35d3625  add rsp, 0x30
00007d07b35d3629  vmovaps xmm0, [rsp]
00007d07b35d362e  vmovaps xmm1, [rsp+0x10]
00007d07b35d3634  vmovaps xmm2, [rsp+0x20]
00007d07b35d363a  vmovaps xmm3, [rsp+0x30]
00007d07b35d3640  vmovaps xmm4, [rsp+0x40]
00007d07b35d3646  vmovaps xmm5, [rsp+0x50]
00007d07b35d364c  vmovaps xmm7, [rsp+0x60]
00007d07b35d3652  vmovaps xmm8, [rsp+0x70]
00007d07b35d3658  vmovaps xmm9, [rsp+0x80]
00007d07b35d3661  vmovaps xmm10, [rsp+0x90]
00007d07b35d366a  vmovaps xmm11, [rsp+0xA0]
00007d07b35d3673  vmovaps xmm12, [rsp+0xB0]
00007d07b35d367c  vmovaps xmm13, [rsp+0xC0]
00007d07b35d3685  vmovaps xmm14, [rsp+0xD0]
00007d07b35d368e  vmovaps xmm15, [rsp+0xE0]
00007d07b35d3697  add rsp, 0xF0
00007d07b35d369e  pop r11
00007d07b35d36a0  pop r10
00007d07b35d36a2  pop r9
00007d07b35d36a4  pop r8
00007d07b35d36a6  pop rsi
00007d07b35d36a7  pop rdi
00007d07b35d36a8  pop rdx
00007d07b35d36a9  pop rcx
00007d07b35d36aa  pop rax
00007d07b35d36ab  add rsp, 0x08
00007d07b35d36af  jmp 0x00007D07B35CFF19
00007d07b35d36b4  sub rsp, 0x08
00007d07b35d36b8  push rax
00007d07b35d36b9  push rcx
00007d07b35d36ba  push rdx
00007d07b35d36bb  push rdi
00007d07b35d36bc  push rsi
00007d07b35d36bd  push r8
00007d07b35d36bf  push r9
00007d07b35d36c1  push r10
00007d07b35d36c3  push r11
00007d07b35d36c5  sub rsp, 0xF0
00007d07b35d36cc  vmovaps [rsp], xmm0
00007d07b35d36d1  vmovaps [rsp+0x10], xmm1
00007d07b35d36d7  vmovaps [rsp+0x20], xmm2
00007d07b35d36dd  vmovaps [rsp+0x30], xmm3
00007d07b35d36e3  vmovaps [rsp+0x40], xmm4
00007d07b35d36e9  vmovaps [rsp+0x50], xmm5
00007d07b35d36ef  vmovaps [rsp+0x60], xmm6
00007d07b35d36f5  vmovaps [rsp+0x70], xmm7
00007d07b35d36fb  vmovaps [rsp+0x80], xmm8
00007d07b35d3704  vmovaps [rsp+0x90], xmm9
00007d07b35d370d  vmovaps [rsp+0xA0], xmm10
00007d07b35d3716  vmovaps [rsp+0xB0], xmm11
00007d07b35d371f  vmovaps [rsp+0xC0], xmm13
00007d07b35d3728  vmovaps [rsp+0xD0], xmm14
00007d07b35d3731  vmovaps [rsp+0xE0], xmm15
00007d07b35d373a  sub rsp, 0x30
00007d07b35d373e  movaps [rsp], xmm12
00007d07b35d3743  movaps [rsp+0x10], xmm15
00007d07b35d3749  movaps [rsp+0x20], xmm13
00007d07b35d374f  lea rdi, [rsp]
00007d07b35d3753  mov esi, 0x00
00007d07b35d3758  mov rax, 0x5D0AA712D530
00007d07b35d3762  call rax
00007d07b35d3764  movaps xmm12, [rsp]
00007d07b35d3769  add rsp, 0x30
00007d07b35d376d  vmovaps xmm0, [rsp]
00007d07b35d3772  vmovaps xmm1, [rsp+0x10]
00007d07b35d3778  vmovaps xmm2, [rsp+0x20]
00007d07b35d377e  vmovaps xmm3, [rsp+0x30]
00007d07b35d3784  vmovaps xmm4, [rsp+0x40]
00007d07b35d378a  vmovaps xmm5, [rsp+0x50]
00007d07b35d3790  vmovaps xmm6, [rsp+0x60]
00007d07b35d3796  vmovaps xmm7, [rsp+0x70]
00007d07b35d379c  vmovaps xmm8, [rsp+0x80]
00007d07b35d37a5  vmovaps xmm9, [rsp+0x90]
00007d07b35d37ae  vmovaps xmm10, [rsp+0xA0]
00007d07b35d37b7  vmovaps xmm11, [rsp+0xB0]
00007d07b35d37c0  vmovaps xmm13, [rsp+0xC0]
00007d07b35d37c9  vmovaps xmm14, [rsp+0xD0]
00007d07b35d37d2  vmovaps xmm15, [rsp+0xE0]
00007d07b35d37db  add rsp, 0xF0
00007d07b35d37e2  pop r11
00007d07b35d37e4  pop r10
00007d07b35d37e6  pop r9
00007d07b35d37e8  pop r8
00007d07b35d37ea  pop rsi
00007d07b35d37eb  pop rdi
00007d07b35d37ec  pop rdx
00007d07b35d37ed  pop rcx
00007d07b35d37ee  pop rax
00007d07b35d37ef  add rsp, 0x08
00007d07b35d37f3  jmp 0x00007D07B35CFF34
00007d07b35d37f8  sub rsp, 0x08
00007d07b35d37fc  push rax
00007d07b35d37fd  push rcx
00007d07b35d37fe  push rdx
00007d07b35d37ff  push rdi
00007d07b35d3800  push rsi
00007d07b35d3801  push r8
00007d07b35d3803  push r9
00007d07b35d3805  push r10
00007d07b35d3807  push r11
00007d07b35d3809  sub rsp, 0xF0
00007d07b35d3810  vmovaps [rsp], xmm0
00007d07b35d3815  vmovaps [rsp+0x10], xmm1
00007d07b35d381b  vmovaps [rsp+0x20], xmm2
00007d07b35d3821  vmovaps [rsp+0x30], xmm3
00007d07b35d3827  vmovaps [rsp+0x40], xmm4
00007d07b35d382d  vmovaps [rsp+0x50], xmm5
00007d07b35d3833  vmovaps [rsp+0x60], xmm6
00007d07b35d3839  vmovaps [rsp+0x70], xmm7
00007d07b35d383f  vmovaps [rsp+0x80], xmm8
00007d07b35d3848  vmovaps [rsp+0x90], xmm9
00007d07b35d3851  vmovaps [rsp+0xA0], xmm10
00007d07b35d385a  vmovaps [rsp+0xB0], xmm11
00007d07b35d3863  vmovaps [rsp+0xC0], xmm12
00007d07b35d386c  vmovaps [rsp+0xD0], xmm13
00007d07b35d3875  vmovaps [rsp+0xE0], xmm14
00007d07b35d387e  sub rsp, 0x30
00007d07b35d3882  movaps [rsp], xmm15
00007d07b35d3887  movaps [rsp+0x10], xmm13
00007d07b35d388d  movaps [rsp+0x20], xmm10
00007d07b35d3893  lea rdi, [rsp]
00007d07b35d3897  mov esi, 0x00
00007d07b35d389c  mov rax, 0x5D0AA712D530
00007d07b35d38a6  call rax
00007d07b35d38a8  movaps xmm15, [rsp]
00007d07b35d38ad  add rsp, 0x30
00007d07b35d38b1  vmovaps xmm0, [rsp]
00007d07b35d38b6  vmovaps xmm1, [rsp+0x10]
00007d07b35d38bc  vmovaps xmm2, [rsp+0x20]
00007d07b35d38c2  vmovaps xmm3, [rsp+0x30]
00007d07b35d38c8  vmovaps xmm4, [rsp+0x40]
00007d07b35d38ce  vmovaps xmm5, [rsp+0x50]
00007d07b35d38d4  vmovaps xmm6, [rsp+0x60]
00007d07b35d38da  vmovaps xmm7, [rsp+0x70]
00007d07b35d38e0  vmovaps xmm8, [rsp+0x80]
00007d07b35d38e9  vmovaps xmm9, [rsp+0x90]
00007d07b35d38f2  vmovaps xmm10, [rsp+0xA0]
00007d07b35d38fb  vmovaps xmm11, [rsp+0xB0]
00007d07b35d3904  vmovaps xmm12, [rsp+0xC0]
00007d07b35d390d  vmovaps xmm13, [rsp+0xD0]
00007d07b35d3916  vmovaps xmm14, [rsp+0xE0]
00007d07b35d391f  add rsp, 0xF0
00007d07b35d3926  pop r11
00007d07b35d3928  pop r10
00007d07b35d392a  pop r9
00007d07b35d392c  pop r8
00007d07b35d392e  pop rsi
00007d07b35d392f  pop rdi
00007d07b35d3930  pop rdx
00007d07b35d3931  pop rcx
00007d07b35d3932  pop rax
00007d07b35d3933  add rsp, 0x08
00007d07b35d3937  jmp 0x00007D07B35CFF55
00007d07b35d393c  call 0x00007D07B340C260
00007d07b35d3941  jmp 0x00007D07B35CFFB0
00007d07b35d3946  sub rsp, 0x08
00007d07b35d394a  push rax
00007d07b35d394b  push rcx
00007d07b35d394c  push rdx
00007d07b35d394d  push rdi
00007d07b35d394e  push rsi
00007d07b35d394f  push r8
00007d07b35d3951  push r9
00007d07b35d3953  push r10
00007d07b35d3955  push r11
00007d07b35d3957  sub rsp, 0xF0
00007d07b35d395e  vmovaps [rsp], xmm0
00007d07b35d3963  vmovaps [rsp+0x10], xmm1
00007d07b35d3969  vmovaps [rsp+0x20], xmm2
00007d07b35d396f  vmovaps [rsp+0x30], xmm3
00007d07b35d3975  vmovaps [rsp+0x40], xmm4
00007d07b35d397b  vmovaps [rsp+0x50], xmm5
00007d07b35d3981  vmovaps [rsp+0x60], xmm6
00007d07b35d3987  vmovaps [rsp+0x70], xmm7
00007d07b35d398d  vmovaps [rsp+0x80], xmm8
00007d07b35d3996  vmovaps [rsp+0x90], xmm10
00007d07b35d399f  vmovaps [rsp+0xA0], xmm11
00007d07b35d39a8  vmovaps [rsp+0xB0], xmm12
00007d07b35d39b1  vmovaps [rsp+0xC0], xmm13
00007d07b35d39ba  vmovaps [rsp+0xD0], xmm14
00007d07b35d39c3  vmovaps [rsp+0xE0], xmm15
00007d07b35d39cc  sub rsp, 0x30
00007d07b35d39d0  movaps [rsp], xmm9
00007d07b35d39d5  movaps [rsp+0x10], xmm8
00007d07b35d39db  movaps [rsp+0x20], xmm10
00007d07b35d39e1  lea rdi, [rsp]
00007d07b35d39e5  mov esi, 0x00
00007d07b35d39ea  mov rax, 0x5D0AA712D530
00007d07b35d39f4  call rax
00007d07b35d39f6  movaps xmm9, [rsp]
00007d07b35d39fb  add rsp, 0x30
00007d07b35d39ff  vmovaps xmm0, [rsp]
00007d07b35d3a04  vmovaps xmm1, [rsp+0x10]
00007d07b35d3a0a  vmovaps xmm2, [rsp+0x20]
00007d07b35d3a10  vmovaps xmm3, [rsp+0x30]
00007d07b35d3a16  vmovaps xmm4, [rsp+0x40]
00007d07b35d3a1c  vmovaps xmm5, [rsp+0x50]
00007d07b35d3a22  vmovaps xmm6, [rsp+0x60]
00007d07b35d3a28  vmovaps xmm7, [rsp+0x70]
00007d07b35d3a2e  vmovaps xmm8, [rsp+0x80]
00007d07b35d3a37  vmovaps xmm10, [rsp+0x90]
00007d07b35d3a40  vmovaps xmm11, [rsp+0xA0]
00007d07b35d3a49  vmovaps xmm12, [rsp+0xB0]
00007d07b35d3a52  vmovaps xmm13, [rsp+0xC0]
00007d07b35d3a5b  vmovaps xmm14, [rsp+0xD0]
00007d07b35d3a64  vmovaps xmm15, [rsp+0xE0]
00007d07b35d3a6d  add rsp, 0xF0
00007d07b35d3a74  pop r11
00007d07b35d3a76  pop r10
00007d07b35d3a78  pop r9
00007d07b35d3a7a  pop r8
00007d07b35d3a7c  pop rsi
00007d07b35d3a7d  pop rdi
00007d07b35d3a7e  pop rdx
00007d07b35d3a7f  pop rcx
00007d07b35d3a80  pop rax
00007d07b35d3a81  add rsp, 0x08
00007d07b35d3a85  jmp 0x00007D07B35CFFE1
00007d07b35d3a8a  sub rsp, 0x08
00007d07b35d3a8e  push rax
00007d07b35d3a8f  push rcx
00007d07b35d3a90  push rdx
00007d07b35d3a91  push rdi
00007d07b35d3a92  push rsi
00007d07b35d3a93  push r8
00007d07b35d3a95  push r9
00007d07b35d3a97  push r10
00007d07b35d3a99  push r11
00007d07b35d3a9b  sub rsp, 0xF0
00007d07b35d3aa2  vmovaps [rsp], xmm0
00007d07b35d3aa7  vmovaps [rsp+0x10], xmm1
00007d07b35d3aad  vmovaps [rsp+0x20], xmm2
00007d07b35d3ab3  vmovaps [rsp+0x30], xmm3
00007d07b35d3ab9  vmovaps [rsp+0x40], xmm4
00007d07b35d3abf  vmovaps [rsp+0x50], xmm5
00007d07b35d3ac5  vmovaps [rsp+0x60], xmm6
00007d07b35d3acb  vmovaps [rsp+0x70], xmm7
00007d07b35d3ad1  vmovaps [rsp+0x80], xmm8
00007d07b35d3ada  vmovaps [rsp+0x90], xmm9
00007d07b35d3ae3  vmovaps [rsp+0xA0], xmm11
00007d07b35d3aec  vmovaps [rsp+0xB0], xmm12
00007d07b35d3af5  vmovaps [rsp+0xC0], xmm13
00007d07b35d3afe  vmovaps [rsp+0xD0], xmm14
00007d07b35d3b07  vmovaps [rsp+0xE0], xmm15
00007d07b35d3b10  sub rsp, 0x30
00007d07b35d3b14  movaps [rsp], xmm10
00007d07b35d3b19  movaps [rsp+0x10], xmm1
00007d07b35d3b1e  movaps [rsp+0x20], xmm11
00007d07b35d3b24  lea rdi, [rsp]
00007d07b35d3b28  mov esi, 0x00
00007d07b35d3b2d  mov rax, 0x5D0AA712D530
00007d07b35d3b37  call rax
00007d07b35d3b39  movaps xmm10, [rsp]
00007d07b35d3b3e  add rsp, 0x30
00007d07b35d3b42  vmovaps xmm0, [rsp]
00007d07b35d3b47  vmovaps xmm1, [rsp+0x10]
00007d07b35d3b4d  vmovaps xmm2, [rsp+0x20]
00007d07b35d3b53  vmovaps xmm3, [rsp+0x30]
00007d07b35d3b59  vmovaps xmm4, [rsp+0x40]
00007d07b35d3b5f  vmovaps xmm5, [rsp+0x50]
00007d07b35d3b65  vmovaps xmm6, [rsp+0x60]
00007d07b35d3b6b  vmovaps xmm7, [rsp+0x70]
00007d07b35d3b71  vmovaps xmm8, [rsp+0x80]
00007d07b35d3b7a  vmovaps xmm9, [rsp+0x90]
00007d07b35d3b83  vmovaps xmm11, [rsp+0xA0]
00007d07b35d3b8c  vmovaps xmm12, [rsp+0xB0]
00007d07b35d3b95  vmovaps xmm13, [rsp+0xC0]
00007d07b35d3b9e  vmovaps xmm14, [rsp+0xD0]
00007d07b35d3ba7  vmovaps xmm15, [rsp+0xE0]
00007d07b35d3bb0  add rsp, 0xF0
00007d07b35d3bb7  pop r11
00007d07b35d3bb9  pop r10
00007d07b35d3bbb  pop r9
00007d07b35d3bbd  pop r8
00007d07b35d3bbf  pop rsi
00007d07b35d3bc0  pop rdi
00007d07b35d3bc1  pop rdx
00007d07b35d3bc2  pop rcx
00007d07b35d3bc3  pop rax
00007d07b35d3bc4  add rsp, 0x08
00007d07b35d3bc8  jmp 0x00007D07B35CFFFC
00007d07b35d3bcd  sub rsp, 0x08
00007d07b35d3bd1  push rax
00007d07b35d3bd2  push rcx
00007d07b35d3bd3  push rdx
00007d07b35d3bd4  push rdi
00007d07b35d3bd5  push rsi
00007d07b35d3bd6  push r8
00007d07b35d3bd8  push r9
00007d07b35d3bda  push r10
00007d07b35d3bdc  push r11
00007d07b35d3bde  sub rsp, 0xF0
00007d07b35d3be5  vmovaps [rsp], xmm0
00007d07b35d3bea  vmovaps [rsp+0x10], xmm2
00007d07b35d3bf0  vmovaps [rsp+0x20], xmm3
00007d07b35d3bf6  vmovaps [rsp+0x30], xmm4
00007d07b35d3bfc  vmovaps [rsp+0x40], xmm5
00007d07b35d3c02  vmovaps [rsp+0x50], xmm6
00007d07b35d3c08  vmovaps [rsp+0x60], xmm7
00007d07b35d3c0e  vmovaps [rsp+0x70], xmm8
00007d07b35d3c14  vmovaps [rsp+0x80], xmm9
00007d07b35d3c1d  vmovaps [rsp+0x90], xmm10
00007d07b35d3c26  vmovaps [rsp+0xA0], xmm11
00007d07b35d3c2f  vmovaps [rsp+0xB0], xmm12
00007d07b35d3c38  vmovaps [rsp+0xC0], xmm13
00007d07b35d3c41  vmovaps [rsp+0xD0], xmm14
00007d07b35d3c4a  vmovaps [rsp+0xE0], xmm15
00007d07b35d3c53  sub rsp, 0x30
00007d07b35d3c57  movaps [rsp], xmm1
00007d07b35d3c5b  movaps [rsp+0x10], xmm14
00007d07b35d3c61  movaps [rsp+0x20], xmm6
00007d07b35d3c66  lea rdi, [rsp]
00007d07b35d3c6a  mov esi, 0x00
00007d07b35d3c6f  mov rax, 0x5D0AA712D530
00007d07b35d3c79  call rax
00007d07b35d3c7b  movaps xmm1, [rsp]
00007d07b35d3c7f  add rsp, 0x30
00007d07b35d3c83  vmovaps xmm0, [rsp]
00007d07b35d3c88  vmovaps xmm2, [rsp+0x10]
00007d07b35d3c8e  vmovaps xmm3, [rsp+0x20]
00007d07b35d3c94  vmovaps xmm4, [rsp+0x30]
00007d07b35d3c9a  vmovaps xmm5, [rsp+0x40]
00007d07b35d3ca0  vmovaps xmm6, [rsp+0x50]
00007d07b35d3ca6  vmovaps xmm7, [rsp+0x60]
00007d07b35d3cac  vmovaps xmm8, [rsp+0x70]
00007d07b35d3cb2  vmovaps xmm9, [rsp+0x80]
00007d07b35d3cbb  vmovaps xmm10, [rsp+0x90]
00007d07b35d3cc4  vmovaps xmm11, [rsp+0xA0]
00007d07b35d3ccd  vmovaps xmm12, [rsp+0xB0]
00007d07b35d3cd6  vmovaps xmm13, [rsp+0xC0]
00007d07b35d3cdf  vmovaps xmm14, [rsp+0xD0]
00007d07b35d3ce8  vmovaps xmm15, [rsp+0xE0]
00007d07b35d3cf1  add rsp, 0xF0
00007d07b35d3cf8  pop r11
00007d07b35d3cfa  pop r10
00007d07b35d3cfc  pop r9
00007d07b35d3cfe  pop r8
00007d07b35d3d00  pop rsi
00007d07b35d3d01  pop rdi
00007d07b35d3d02  pop rdx
00007d07b35d3d03  pop rcx
00007d07b35d3d04  pop rax
00007d07b35d3d05  add rsp, 0x08
00007d07b35d3d09  jmp 0x00007D07B35D0015
00007d07b35d3d0e  sub rsp, 0x08
00007d07b35d3d12  push rax
00007d07b35d3d13  push rcx
00007d07b35d3d14  push rdx
00007d07b35d3d15  push rdi
00007d07b35d3d16  push rsi
00007d07b35d3d17  push r8
00007d07b35d3d19  push r9
00007d07b35d3d1b  push r10
00007d07b35d3d1d  push r11
00007d07b35d3d1f  sub rsp, 0xF0
00007d07b35d3d26  vmovaps [rsp], xmm0
00007d07b35d3d2b  vmovaps [rsp+0x10], xmm1
00007d07b35d3d31  vmovaps [rsp+0x20], xmm2
00007d07b35d3d37  vmovaps [rsp+0x30], xmm3
00007d07b35d3d3d  vmovaps [rsp+0x40], xmm4
00007d07b35d3d43  vmovaps [rsp+0x50], xmm5
00007d07b35d3d49  vmovaps [rsp+0x60], xmm6
00007d07b35d3d4f  vmovaps [rsp+0x70], xmm7
00007d07b35d3d55  vmovaps [rsp+0x80], xmm8
00007d07b35d3d5e  vmovaps [rsp+0x90], xmm9
00007d07b35d3d67  vmovaps [rsp+0xA0], xmm10
00007d07b35d3d70  vmovaps [rsp+0xB0], xmm12
00007d07b35d3d79  vmovaps [rsp+0xC0], xmm13
00007d07b35d3d82  vmovaps [rsp+0xD0], xmm14
00007d07b35d3d8b  vmovaps [rsp+0xE0], xmm15
00007d07b35d3d94  sub rsp, 0x30
00007d07b35d3d98  movaps [rsp], xmm11
00007d07b35d3d9d  movaps [rsp+0x10], xmm13
00007d07b35d3da3  movaps [rsp+0x20], xmm14
00007d07b35d3da9  lea rdi, [rsp]
00007d07b35d3dad  mov esi, 0x00
00007d07b35d3db2  mov rax, 0x5D0AA712D530
00007d07b35d3dbc  call rax
00007d07b35d3dbe  movaps xmm11, [rsp]
00007d07b35d3dc3  add rsp, 0x30
00007d07b35d3dc7  vmovaps xmm0, [rsp]
00007d07b35d3dcc  vmovaps xmm1, [rsp+0x10]
00007d07b35d3dd2  vmovaps xmm2, [rsp+0x20]
00007d07b35d3dd8  vmovaps xmm3, [rsp+0x30]
00007d07b35d3dde  vmovaps xmm4, [rsp+0x40]
00007d07b35d3de4  vmovaps xmm5, [rsp+0x50]
00007d07b35d3dea  vmovaps xmm6, [rsp+0x60]
00007d07b35d3df0  vmovaps xmm7, [rsp+0x70]
00007d07b35d3df6  vmovaps xmm8, [rsp+0x80]
00007d07b35d3dff  vmovaps xmm9, [rsp+0x90]
00007d07b35d3e08  vmovaps xmm10, [rsp+0xA0]
00007d07b35d3e11  vmovaps xmm12, [rsp+0xB0]
00007d07b35d3e1a  vmovaps xmm13, [rsp+0xC0]
00007d07b35d3e23  vmovaps xmm14, [rsp+0xD0]
00007d07b35d3e2c  vmovaps xmm15, [rsp+0xE0]
00007d07b35d3e35  add rsp, 0xF0
00007d07b35d3e3c  pop r11
00007d07b35d3e3e  pop r10
00007d07b35d3e40  pop r9
00007d07b35d3e42  pop r8
00007d07b35d3e44  pop rsi
00007d07b35d3e45  pop rdi
00007d07b35d3e46  pop rdx
00007d07b35d3e47  pop rcx
00007d07b35d3e48  pop rax
00007d07b35d3e49  add rsp, 0x08
00007d07b35d3e4d  jmp 0x00007D07B35D003F
00007d07b35d3e52  sub rsp, 0x08
00007d07b35d3e56  push rax
00007d07b35d3e57  push rcx
00007d07b35d3e58  push rdx
00007d07b35d3e59  push rdi
00007d07b35d3e5a  push rsi
00007d07b35d3e5b  push r8
00007d07b35d3e5d  push r9
00007d07b35d3e5f  push r10
00007d07b35d3e61  push r11
00007d07b35d3e63  sub rsp, 0xF0
00007d07b35d3e6a  vmovaps [rsp], xmm0
00007d07b35d3e6f  vmovaps [rsp+0x10], xmm1
00007d07b35d3e75  vmovaps [rsp+0x20], xmm2
00007d07b35d3e7b  vmovaps [rsp+0x30], xmm3
00007d07b35d3e81  vmovaps [rsp+0x40], xmm4
00007d07b35d3e87  vmovaps [rsp+0x50], xmm5
00007d07b35d3e8d  vmovaps [rsp+0x60], xmm6
00007d07b35d3e93  vmovaps [rsp+0x70], xmm7
00007d07b35d3e99  vmovaps [rsp+0x80], xmm8
00007d07b35d3ea2  vmovaps [rsp+0x90], xmm9
00007d07b35d3eab  vmovaps [rsp+0xA0], xmm10
00007d07b35d3eb4  vmovaps [rsp+0xB0], xmm11
00007d07b35d3ebd  vmovaps [rsp+0xC0], xmm12
00007d07b35d3ec6  vmovaps [rsp+0xD0], xmm14
00007d07b35d3ecf  vmovaps [rsp+0xE0], xmm15
00007d07b35d3ed8  sub rsp, 0x30
00007d07b35d3edc  movaps [rsp], xmm13
00007d07b35d3ee1  movaps [rsp+0x10], xmm8
00007d07b35d3ee7  movaps [rsp+0x20], xmm14
00007d07b35d3eed  lea rdi, [rsp]
00007d07b35d3ef1  mov esi, 0x00
00007d07b35d3ef6  mov rax, 0x5D0AA712D530
00007d07b35d3f00  call rax
00007d07b35d3f02  movaps xmm13, [rsp]
00007d07b35d3f07  add rsp, 0x30
00007d07b35d3f0b  vmovaps xmm0, [rsp]
00007d07b35d3f10  vmovaps xmm1, [rsp+0x10]
00007d07b35d3f16  vmovaps xmm2, [rsp+0x20]
00007d07b35d3f1c  vmovaps xmm3, [rsp+0x30]
00007d07b35d3f22  vmovaps xmm4, [rsp+0x40]
00007d07b35d3f28  vmovaps xmm5, [rsp+0x50]
00007d07b35d3f2e  vmovaps xmm6, [rsp+0x60]
00007d07b35d3f34  vmovaps xmm7, [rsp+0x70]
00007d07b35d3f3a  vmovaps xmm8, [rsp+0x80]
00007d07b35d3f43  vmovaps xmm9, [rsp+0x90]
00007d07b35d3f4c  vmovaps xmm10, [rsp+0xA0]
00007d07b35d3f55  vmovaps xmm11, [rsp+0xB0]
00007d07b35d3f5e  vmovaps xmm12, [rsp+0xC0]
00007d07b35d3f67  vmovaps xmm14, [rsp+0xD0]
00007d07b35d3f70  vmovaps xmm15, [rsp+0xE0]
00007d07b35d3f79  add rsp, 0xF0
00007d07b35d3f80  pop r11
00007d07b35d3f82  pop r10
00007d07b35d3f84  pop r9
00007d07b35d3f86  pop r8
00007d07b35d3f88  pop rsi
00007d07b35d3f89  pop rdi
00007d07b35d3f8a  pop rdx
00007d07b35d3f8b  pop rcx
00007d07b35d3f8c  pop rax
00007d07b35d3f8d  add rsp, 0x08
00007d07b35d3f91  jmp 0x00007D07B35D006E
00007d07b35d3f96  sub rsp, 0x08
00007d07b35d3f9a  push rax
00007d07b35d3f9b  push rcx
00007d07b35d3f9c  push rdx
00007d07b35d3f9d  push rdi
00007d07b35d3f9e  push rsi
00007d07b35d3f9f  push r8
00007d07b35d3fa1  push r9
00007d07b35d3fa3  push r10
00007d07b35d3fa5  push r11
00007d07b35d3fa7  sub rsp, 0xF0
00007d07b35d3fae  vmovaps [rsp], xmm0
00007d07b35d3fb3  vmovaps [rsp+0x10], xmm1
00007d07b35d3fb9  vmovaps [rsp+0x20], xmm2
00007d07b35d3fbf  vmovaps [rsp+0x30], xmm3
00007d07b35d3fc5  vmovaps [rsp+0x40], xmm4
00007d07b35d3fcb  vmovaps [rsp+0x50], xmm5
00007d07b35d3fd1  vmovaps [rsp+0x60], xmm6
00007d07b35d3fd7  vmovaps [rsp+0x70], xmm7
00007d07b35d3fdd  vmovaps [rsp+0x80], xmm9
00007d07b35d3fe6  vmovaps [rsp+0x90], xmm10
00007d07b35d3fef  vmovaps [rsp+0xA0], xmm11
00007d07b35d3ff8  vmovaps [rsp+0xB0], xmm12
00007d07b35d4001  vmovaps [rsp+0xC0], xmm13
00007d07b35d400a  vmovaps [rsp+0xD0], xmm14
00007d07b35d4013  vmovaps [rsp+0xE0], xmm15
00007d07b35d401c  sub rsp, 0x30
00007d07b35d4020  movaps [rsp], xmm8
00007d07b35d4025  movaps [rsp+0x10], xmm7
00007d07b35d402a  movaps [rsp+0x20], xmm14
00007d07b35d4030  lea rdi, [rsp]
00007d07b35d4034  mov esi, 0x00
00007d07b35d4039  mov rax, 0x5D0AA712D530
00007d07b35d4043  call rax
00007d07b35d4045  movaps xmm8, [rsp]
00007d07b35d404a  add rsp, 0x30
00007d07b35d404e  vmovaps xmm0, [rsp]
00007d07b35d4053  vmovaps xmm1, [rsp+0x10]
00007d07b35d4059  vmovaps xmm2, [rsp+0x20]
00007d07b35d405f  vmovaps xmm3, [rsp+0x30]
00007d07b35d4065  vmovaps xmm4, [rsp+0x40]
00007d07b35d406b  vmovaps xmm5, [rsp+0x50]
00007d07b35d4071  vmovaps xmm6, [rsp+0x60]
00007d07b35d4077  vmovaps xmm7, [rsp+0x70]
00007d07b35d407d  vmovaps xmm9, [rsp+0x80]
00007d07b35d4086  vmovaps xmm10, [rsp+0x90]
00007d07b35d408f  vmovaps xmm11, [rsp+0xA0]
00007d07b35d4098  vmovaps xmm12, [rsp+0xB0]
00007d07b35d40a1  vmovaps xmm13, [rsp+0xC0]
00007d07b35d40aa  vmovaps xmm14, [rsp+0xD0]
00007d07b35d40b3  vmovaps xmm15, [rsp+0xE0]
00007d07b35d40bc  add rsp, 0xF0
00007d07b35d40c3  pop r11
00007d07b35d40c5  pop r10
00007d07b35d40c7  pop r9
00007d07b35d40c9  pop r8
00007d07b35d40cb  pop rsi
00007d07b35d40cc  pop rdi
00007d07b35d40cd  pop rdx
00007d07b35d40ce  pop rcx
00007d07b35d40cf  pop rax
00007d07b35d40d0  add rsp, 0x08
00007d07b35d40d4  jmp 0x00007D07B35D0094
00007d07b35d40d9  sub rsp, 0x08
00007d07b35d40dd  push rax
00007d07b35d40de  push rcx
00007d07b35d40df  push rdx
00007d07b35d40e0  push rdi
00007d07b35d40e1  push rsi
00007d07b35d40e2  push r8
00007d07b35d40e4  push r9
00007d07b35d40e6  push r10
00007d07b35d40e8  push r11
00007d07b35d40ea  sub rsp, 0xF0
00007d07b35d40f1  vmovaps [rsp], xmm0
00007d07b35d40f6  vmovaps [rsp+0x10], xmm1
00007d07b35d40fc  vmovaps [rsp+0x20], xmm2
00007d07b35d4102  vmovaps [rsp+0x30], xmm3
00007d07b35d4108  vmovaps [rsp+0x40], xmm4
00007d07b35d410e  vmovaps [rsp+0x50], xmm5
00007d07b35d4114  vmovaps [rsp+0x60], xmm6
00007d07b35d411a  vmovaps [rsp+0x70], xmm7
00007d07b35d4120  vmovaps [rsp+0x80], xmm8
00007d07b35d4129  vmovaps [rsp+0x90], xmm9
00007d07b35d4132  vmovaps [rsp+0xA0], xmm10
00007d07b35d413b  vmovaps [rsp+0xB0], xmm11
00007d07b35d4144  vmovaps [rsp+0xC0], xmm12
00007d07b35d414d  vmovaps [rsp+0xD0], xmm13
00007d07b35d4156  vmovaps [rsp+0xE0], xmm15
00007d07b35d415f  sub rsp, 0x30
00007d07b35d4163  movaps [rsp], xmm14
00007d07b35d4168  movaps [rsp+0x10], xmm12
00007d07b35d416e  movaps [rsp+0x20], xmm9
00007d07b35d4174  lea rdi, [rsp]
00007d07b35d4178  mov esi, 0x00
00007d07b35d417d  mov rax, 0x5D0AA712D530
00007d07b35d4187  call rax
00007d07b35d4189  movaps xmm14, [rsp]
00007d07b35d418e  add rsp, 0x30
00007d07b35d4192  vmovaps xmm0, [rsp]
00007d07b35d4197  vmovaps xmm1, [rsp+0x10]
00007d07b35d419d  vmovaps xmm2, [rsp+0x20]
00007d07b35d41a3  vmovaps xmm3, [rsp+0x30]
00007d07b35d41a9  vmovaps xmm4, [rsp+0x40]
00007d07b35d41af  vmovaps xmm5, [rsp+0x50]
00007d07b35d41b5  vmovaps xmm6, [rsp+0x60]
00007d07b35d41bb  vmovaps xmm7, [rsp+0x70]
00007d07b35d41c1  vmovaps xmm8, [rsp+0x80]
00007d07b35d41ca  vmovaps xmm9, [rsp+0x90]
00007d07b35d41d3  vmovaps xmm10, [rsp+0xA0]
00007d07b35d41dc  vmovaps xmm11, [rsp+0xB0]
00007d07b35d41e5  vmovaps xmm12, [rsp+0xC0]
00007d07b35d41ee  vmovaps xmm13, [rsp+0xD0]
00007d07b35d41f7  vmovaps xmm15, [rsp+0xE0]
00007d07b35d4200  add rsp, 0xF0
00007d07b35d4207  pop r11
00007d07b35d4209  pop r10
00007d07b35d420b  pop r9
00007d07b35d420d  pop r8
00007d07b35d420f  pop rsi
00007d07b35d4210  pop rdi
00007d07b35d4211  pop rdx
00007d07b35d4212  pop rcx
00007d07b35d4213  pop rax
00007d07b35d4214  add rsp, 0x08
00007d07b35d4218  jmp 0x00007D07B35D00AE
00007d07b35d421d  sub rsp, 0x08
00007d07b35d4221  push rax
00007d07b35d4222  push rcx
00007d07b35d4223  push rdx
00007d07b35d4224  push rdi
00007d07b35d4225  push rsi
00007d07b35d4226  push r8
00007d07b35d4228  push r9
00007d07b35d422a  push r10
00007d07b35d422c  push r11
00007d07b35d422e  sub rsp, 0xF0
00007d07b35d4235  vmovaps [rsp], xmm0
00007d07b35d423a  vmovaps [rsp+0x10], xmm1
00007d07b35d4240  vmovaps [rsp+0x20], xmm2
00007d07b35d4246  vmovaps [rsp+0x30], xmm3
00007d07b35d424c  vmovaps [rsp+0x40], xmm4
00007d07b35d4252  vmovaps [rsp+0x50], xmm5
00007d07b35d4258  vmovaps [rsp+0x60], xmm6
00007d07b35d425e  vmovaps [rsp+0x70], xmm7
00007d07b35d4264  vmovaps [rsp+0x80], xmm8
00007d07b35d426d  vmovaps [rsp+0x90], xmm10
00007d07b35d4276  vmovaps [rsp+0xA0], xmm11
00007d07b35d427f  vmovaps [rsp+0xB0], xmm12
00007d07b35d4288  vmovaps [rsp+0xC0], xmm13
00007d07b35d4291  vmovaps [rsp+0xD0], xmm14
00007d07b35d429a  vmovaps [rsp+0xE0], xmm15
00007d07b35d42a3  sub rsp, 0x30
00007d07b35d42a7  movaps [rsp], xmm9
00007d07b35d42ac  movaps [rsp+0x10], xmm7
00007d07b35d42b1  movaps [rsp+0x20], xmm12
00007d07b35d42b7  lea rdi, [rsp]
00007d07b35d42bb  mov esi, 0x00
00007d07b35d42c0  mov rax, 0x5D0AA712D530
00007d07b35d42ca  call rax
00007d07b35d42cc  movaps xmm9, [rsp]
00007d07b35d42d1  add rsp, 0x30
00007d07b35d42d5  vmovaps xmm0, [rsp]
00007d07b35d42da  vmovaps xmm1, [rsp+0x10]
00007d07b35d42e0  vmovaps xmm2, [rsp+0x20]
00007d07b35d42e6  vmovaps xmm3, [rsp+0x30]
00007d07b35d42ec  vmovaps xmm4, [rsp+0x40]
00007d07b35d42f2  vmovaps xmm5, [rsp+0x50]
00007d07b35d42f8  vmovaps xmm6, [rsp+0x60]
00007d07b35d42fe  vmovaps xmm7, [rsp+0x70]
00007d07b35d4304  vmovaps xmm8, [rsp+0x80]
00007d07b35d430d  vmovaps xmm10, [rsp+0x90]
00007d07b35d4316  vmovaps xmm11, [rsp+0xA0]
00007d07b35d431f  vmovaps xmm12, [rsp+0xB0]
00007d07b35d4328  vmovaps xmm13, [rsp+0xC0]
00007d07b35d4331  vmovaps xmm14, [rsp+0xD0]
00007d07b35d433a  vmovaps xmm15, [rsp+0xE0]
00007d07b35d4343  add rsp, 0xF0
00007d07b35d434a  pop r11
00007d07b35d434c  pop r10
00007d07b35d434e  pop r9
00007d07b35d4350  pop r8
00007d07b35d4352  pop rsi
00007d07b35d4353  pop rdi
00007d07b35d4354  pop rdx
00007d07b35d4355  pop rcx
00007d07b35d4356  pop rax
00007d07b35d4357  add rsp, 0x08
00007d07b35d435b  jmp 0x00007D07B35D00DD
00007d07b35d4360  sub rsp, 0x08
00007d07b35d4364  push rax
00007d07b35d4365  push rcx
00007d07b35d4366  push rdx
00007d07b35d4367  push rdi
00007d07b35d4368  push rsi
00007d07b35d4369  push r8
00007d07b35d436b  push r9
00007d07b35d436d  push r10
00007d07b35d436f  push r11
00007d07b35d4371  sub rsp, 0xF0
00007d07b35d4378  vmovaps [rsp], xmm0
00007d07b35d437d  vmovaps [rsp+0x10], xmm1
00007d07b35d4383  vmovaps [rsp+0x20], xmm2
00007d07b35d4389  vmovaps [rsp+0x30], xmm3
00007d07b35d438f  vmovaps [rsp+0x40], xmm4
00007d07b35d4395  vmovaps [rsp+0x50], xmm5
00007d07b35d439b  vmovaps [rsp+0x60], xmm6
00007d07b35d43a1  vmovaps [rsp+0x70], xmm7
00007d07b35d43a7  vmovaps [rsp+0x80], xmm8
00007d07b35d43b0  vmovaps [rsp+0x90], xmm9
00007d07b35d43b9  vmovaps [rsp+0xA0], xmm10
00007d07b35d43c2  vmovaps [rsp+0xB0], xmm11
00007d07b35d43cb  vmovaps [rsp+0xC0], xmm13
00007d07b35d43d4  vmovaps [rsp+0xD0], xmm14
00007d07b35d43dd  vmovaps [rsp+0xE0], xmm15
00007d07b35d43e6  sub rsp, 0x30
00007d07b35d43ea  movaps [rsp], xmm12
00007d07b35d43ef  movaps [rsp+0x10], xmm15
00007d07b35d43f5  movaps [rsp+0x20], xmm11
00007d07b35d43fb  lea rdi, [rsp]
00007d07b35d43ff  mov esi, 0x00
00007d07b35d4404  mov rax, 0x5D0AA712D530
00007d07b35d440e  call rax
00007d07b35d4410  movaps xmm12, [rsp]
00007d07b35d4415  add rsp, 0x30
00007d07b35d4419  vmovaps xmm0, [rsp]
00007d07b35d441e  vmovaps xmm1, [rsp+0x10]
00007d07b35d4424  vmovaps xmm2, [rsp+0x20]
00007d07b35d442a  vmovaps xmm3, [rsp+0x30]
00007d07b35d4430  vmovaps xmm4, [rsp+0x40]
00007d07b35d4436  vmovaps xmm5, [rsp+0x50]
00007d07b35d443c  vmovaps xmm6, [rsp+0x60]
00007d07b35d4442  vmovaps xmm7, [rsp+0x70]
00007d07b35d4448  vmovaps xmm8, [rsp+0x80]
00007d07b35d4451  vmovaps xmm9, [rsp+0x90]
00007d07b35d445a  vmovaps xmm10, [rsp+0xA0]
00007d07b35d4463  vmovaps xmm11, [rsp+0xB0]
00007d07b35d446c  vmovaps xmm13, [rsp+0xC0]
00007d07b35d4475  vmovaps xmm14, [rsp+0xD0]
00007d07b35d447e  vmovaps xmm15, [rsp+0xE0]
00007d07b35d4487  add rsp, 0xF0
00007d07b35d448e  pop r11
00007d07b35d4490  pop r10
00007d07b35d4492  pop r9
00007d07b35d4494  pop r8
00007d07b35d4496  pop rsi
00007d07b35d4497  pop rdi
00007d07b35d4498  pop rdx
00007d07b35d4499  pop rcx
00007d07b35d449a  pop rax
00007d07b35d449b  add rsp, 0x08
00007d07b35d449f  jmp 0x00007D07B35D00F7
00007d07b35d44a4  sub rsp, 0x08
00007d07b35d44a8  push rax
00007d07b35d44a9  push rcx
00007d07b35d44aa  push rdx
00007d07b35d44ab  push rdi
00007d07b35d44ac  push rsi
00007d07b35d44ad  push r8
00007d07b35d44af  push r9
00007d07b35d44b1  push r10
00007d07b35d44b3  push r11
00007d07b35d44b5  sub rsp, 0xF0
00007d07b35d44bc  vmovaps [rsp], xmm0
00007d07b35d44c1  vmovaps [rsp+0x10], xmm1
00007d07b35d44c7  vmovaps [rsp+0x20], xmm2
00007d07b35d44cd  vmovaps [rsp+0x30], xmm3
00007d07b35d44d3  vmovaps [rsp+0x40], xmm4
00007d07b35d44d9  vmovaps [rsp+0x50], xmm5
00007d07b35d44df  vmovaps [rsp+0x60], xmm6
00007d07b35d44e5  vmovaps [rsp+0x70], xmm7
00007d07b35d44eb  vmovaps [rsp+0x80], xmm8
00007d07b35d44f4  vmovaps [rsp+0x90], xmm9
00007d07b35d44fd  vmovaps [rsp+0xA0], xmm10
00007d07b35d4506  vmovaps [rsp+0xB0], xmm12
00007d07b35d450f  vmovaps [rsp+0xC0], xmm13
00007d07b35d4518  vmovaps [rsp+0xD0], xmm14
00007d07b35d4521  vmovaps [rsp+0xE0], xmm15
00007d07b35d452a  sub rsp, 0x30
00007d07b35d452e  movaps [rsp], xmm11
00007d07b35d4533  movaps [rsp+0x10], xmm7
00007d07b35d4538  movaps [rsp+0x20], xmm15
00007d07b35d453e  lea rdi, [rsp]
00007d07b35d4542  mov esi, 0x00
00007d07b35d4547  mov rax, 0x5D0AA712D530
00007d07b35d4551  call rax
00007d07b35d4553  movaps xmm11, [rsp]
00007d07b35d4558  add rsp, 0x30
00007d07b35d455c  vmovaps xmm0, [rsp]
00007d07b35d4561  vmovaps xmm1, [rsp+0x10]
00007d07b35d4567  vmovaps xmm2, [rsp+0x20]
00007d07b35d456d  vmovaps xmm3, [rsp+0x30]
00007d07b35d4573  vmovaps xmm4, [rsp+0x40]
00007d07b35d4579  vmovaps xmm5, [rsp+0x50]
00007d07b35d457f  vmovaps xmm6, [rsp+0x60]
00007d07b35d4585  vmovaps xmm7, [rsp+0x70]
00007d07b35d458b  vmovaps xmm8, [rsp+0x80]
00007d07b35d4594  vmovaps xmm9, [rsp+0x90]
00007d07b35d459d  vmovaps xmm10, [rsp+0xA0]
00007d07b35d45a6  vmovaps xmm12, [rsp+0xB0]
00007d07b35d45af  vmovaps xmm13, [rsp+0xC0]
00007d07b35d45b8  vmovaps xmm14, [rsp+0xD0]
00007d07b35d45c1  vmovaps xmm15, [rsp+0xE0]
00007d07b35d45ca  add rsp, 0xF0
00007d07b35d45d1  pop r11
00007d07b35d45d3  pop r10
00007d07b35d45d5  pop r9
00007d07b35d45d7  pop r8
00007d07b35d45d9  pop rsi
00007d07b35d45da  pop rdi
00007d07b35d45db  pop rdx
00007d07b35d45dc  pop rcx
00007d07b35d45dd  pop rax
00007d07b35d45de  add rsp, 0x08
00007d07b35d45e2  jmp 0x00007D07B35D0123
00007d07b35d45e7  sub rsp, 0x08
00007d07b35d45eb  push rax
00007d07b35d45ec  push rcx
00007d07b35d45ed  push rdx
00007d07b35d45ee  push rdi
00007d07b35d45ef  push rsi
00007d07b35d45f0  push r8
00007d07b35d45f2  push r9
00007d07b35d45f4  push r10
00007d07b35d45f6  push r11
00007d07b35d45f8  sub rsp, 0xF0
00007d07b35d45ff  vmovaps [rsp], xmm0
00007d07b35d4604  vmovaps [rsp+0x10], xmm1
00007d07b35d460a  vmovaps [rsp+0x20], xmm2
00007d07b35d4610  vmovaps [rsp+0x30], xmm3
00007d07b35d4616  vmovaps [rsp+0x40], xmm4
00007d07b35d461c  vmovaps [rsp+0x50], xmm5
00007d07b35d4622  vmovaps [rsp+0x60], xmm6
00007d07b35d4628  vmovaps [rsp+0x70], xmm7
00007d07b35d462e  vmovaps [rsp+0x80], xmm8
00007d07b35d4637  vmovaps [rsp+0x90], xmm9
00007d07b35d4640  vmovaps [rsp+0xA0], xmm10
00007d07b35d4649  vmovaps [rsp+0xB0], xmm11
00007d07b35d4652  vmovaps [rsp+0xC0], xmm12
00007d07b35d465b  vmovaps [rsp+0xD0], xmm13
00007d07b35d4664  vmovaps [rsp+0xE0], xmm14
00007d07b35d466d  sub rsp, 0x30
00007d07b35d4671  movaps [rsp], xmm15
00007d07b35d4676  movaps [rsp+0x10], xmm10
00007d07b35d467c  movaps [rsp+0x20], xmm13
00007d07b35d4682  lea rdi, [rsp]
00007d07b35d4686  mov esi, 0x00
00007d07b35d468b  mov rax, 0x5D0AA712D530
00007d07b35d4695  call rax
00007d07b35d4697  movaps xmm15, [rsp]
00007d07b35d469c  add rsp, 0x30
00007d07b35d46a0  vmovaps xmm0, [rsp]
00007d07b35d46a5  vmovaps xmm1, [rsp+0x10]
00007d07b35d46ab  vmovaps xmm2, [rsp+0x20]
00007d07b35d46b1  vmovaps xmm3, [rsp+0x30]
00007d07b35d46b7  vmovaps xmm4, [rsp+0x40]
00007d07b35d46bd  vmovaps xmm5, [rsp+0x50]
00007d07b35d46c3  vmovaps xmm6, [rsp+0x60]
00007d07b35d46c9  vmovaps xmm7, [rsp+0x70]
00007d07b35d46cf  vmovaps xmm8, [rsp+0x80]
00007d07b35d46d8  vmovaps xmm9, [rsp+0x90]
00007d07b35d46e1  vmovaps xmm10, [rsp+0xA0]
00007d07b35d46ea  vmovaps xmm11, [rsp+0xB0]
00007d07b35d46f3  vmovaps xmm12, [rsp+0xC0]
00007d07b35d46fc  vmovaps xmm13, [rsp+0xD0]
00007d07b35d4705  vmovaps xmm14, [rsp+0xE0]
00007d07b35d470e  add rsp, 0xF0
00007d07b35d4715  pop r11
00007d07b35d4717  pop r10
00007d07b35d4719  pop r9
00007d07b35d471b  pop r8
00007d07b35d471d  pop rsi
00007d07b35d471e  pop rdi
00007d07b35d471f  pop rdx
00007d07b35d4720  pop rcx
00007d07b35d4721  pop rax
00007d07b35d4722  add rsp, 0x08
00007d07b35d4726  jmp 0x00007D07B35D013D
00007d07b35d472b  sub rsp, 0x08
00007d07b35d472f  push rax
00007d07b35d4730  push rcx
00007d07b35d4731  push rdx
00007d07b35d4732  push rdi
00007d07b35d4733  push rsi
00007d07b35d4734  push r8
00007d07b35d4736  push r9
00007d07b35d4738  push r10
00007d07b35d473a  push r11
00007d07b35d473c  sub rsp, 0xF0
00007d07b35d4743  vmovaps [rsp], xmm0
00007d07b35d4748  vmovaps [rsp+0x10], xmm1
00007d07b35d474e  vmovaps [rsp+0x20], xmm2
00007d07b35d4754  vmovaps [rsp+0x30], xmm3
00007d07b35d475a  vmovaps [rsp+0x40], xmm4
00007d07b35d4760  vmovaps [rsp+0x50], xmm5
00007d07b35d4766  vmovaps [rsp+0x60], xmm6
00007d07b35d476c  vmovaps [rsp+0x70], xmm7
00007d07b35d4772  vmovaps [rsp+0x80], xmm8
00007d07b35d477b  vmovaps [rsp+0x90], xmm9
00007d07b35d4784  vmovaps [rsp+0xA0], xmm11
00007d07b35d478d  vmovaps [rsp+0xB0], xmm12
00007d07b35d4796  vmovaps [rsp+0xC0], xmm13
00007d07b35d479f  vmovaps [rsp+0xD0], xmm14
00007d07b35d47a8  vmovaps [rsp+0xE0], xmm15
00007d07b35d47b1  sub rsp, 0x30
00007d07b35d47b5  movaps [rsp], xmm10
00007d07b35d47ba  movaps [rsp+0x10], xmm7
00007d07b35d47bf  movaps [rsp+0x20], xmm13
00007d07b35d47c5  lea rdi, [rsp]
00007d07b35d47c9  mov esi, 0x00
00007d07b35d47ce  mov rax, 0x5D0AA712D530
00007d07b35d47d8  call rax
00007d07b35d47da  movaps xmm10, [rsp]
00007d07b35d47df  add rsp, 0x30
00007d07b35d47e3  vmovaps xmm0, [rsp]
00007d07b35d47e8  vmovaps xmm1, [rsp+0x10]
00007d07b35d47ee  vmovaps xmm2, [rsp+0x20]
00007d07b35d47f4  vmovaps xmm3, [rsp+0x30]
00007d07b35d47fa  vmovaps xmm4, [rsp+0x40]
00007d07b35d4800  vmovaps xmm5, [rsp+0x50]
00007d07b35d4806  vmovaps xmm6, [rsp+0x60]
00007d07b35d480c  vmovaps xmm7, [rsp+0x70]
00007d07b35d4812  vmovaps xmm8, [rsp+0x80]
00007d07b35d481b  vmovaps xmm9, [rsp+0x90]
00007d07b35d4824  vmovaps xmm11, [rsp+0xA0]
00007d07b35d482d  vmovaps xmm12, [rsp+0xB0]
00007d07b35d4836  vmovaps xmm13, [rsp+0xC0]
00007d07b35d483f  vmovaps xmm14, [rsp+0xD0]
00007d07b35d4848  vmovaps xmm15, [rsp+0xE0]
00007d07b35d4851  add rsp, 0xF0
00007d07b35d4858  pop r11
00007d07b35d485a  pop r10
00007d07b35d485c  pop r9
00007d07b35d485e  pop r8
00007d07b35d4860  pop rsi
00007d07b35d4861  pop rdi
00007d07b35d4862  pop rdx
00007d07b35d4863  pop rcx
00007d07b35d4864  pop rax
00007d07b35d4865  add rsp, 0x08
00007d07b35d4869  jmp 0x00007D07B35D0169
00007d07b35d486e  sub rsp, 0x08
00007d07b35d4872  push rax
00007d07b35d4873  push rcx
00007d07b35d4874  push rdx
00007d07b35d4875  push rdi
00007d07b35d4876  push rsi
00007d07b35d4877  push r8
00007d07b35d4879  push r9
00007d07b35d487b  push r10
00007d07b35d487d  push r11
00007d07b35d487f  sub rsp, 0xF0
00007d07b35d4886  vmovaps [rsp], xmm0
00007d07b35d488b  vmovaps [rsp+0x10], xmm1
00007d07b35d4891  vmovaps [rsp+0x20], xmm2
00007d07b35d4897  vmovaps [rsp+0x30], xmm3
00007d07b35d489d  vmovaps [rsp+0x40], xmm4
00007d07b35d48a3  vmovaps [rsp+0x50], xmm5
00007d07b35d48a9  vmovaps [rsp+0x60], xmm6
00007d07b35d48af  vmovaps [rsp+0x70], xmm7
00007d07b35d48b5  vmovaps [rsp+0x80], xmm8
00007d07b35d48be  vmovaps [rsp+0x90], xmm9
00007d07b35d48c7  vmovaps [rsp+0xA0], xmm10
00007d07b35d48d0  vmovaps [rsp+0xB0], xmm11
00007d07b35d48d9  vmovaps [rsp+0xC0], xmm12
00007d07b35d48e2  vmovaps [rsp+0xD0], xmm14
00007d07b35d48eb  vmovaps [rsp+0xE0], xmm15
00007d07b35d48f4  sub rsp, 0x30
00007d07b35d48f8  movaps [rsp], xmm13
00007d07b35d48fd  movaps [rsp+0x10], xmm1
00007d07b35d4902  movaps [rsp+0x20], xmm8
00007d07b35d4908  lea rdi, [rsp]
00007d07b35d490c  mov esi, 0x00
00007d07b35d4911  mov rax, 0x5D0AA712D530
00007d07b35d491b  call rax
00007d07b35d491d  movaps xmm13, [rsp]
00007d07b35d4922  add rsp, 0x30
00007d07b35d4926  vmovaps xmm0, [rsp]
00007d07b35d492b  vmovaps xmm1, [rsp+0x10]
00007d07b35d4931  vmovaps xmm2, [rsp+0x20]
00007d07b35d4937  vmovaps xmm3, [rsp+0x30]
00007d07b35d493d  vmovaps xmm4, [rsp+0x40]
00007d07b35d4943  vmovaps xmm5, [rsp+0x50]
00007d07b35d4949  vmovaps xmm6, [rsp+0x60]
00007d07b35d494f  vmovaps xmm7, [rsp+0x70]
00007d07b35d4955  vmovaps xmm8, [rsp+0x80]
00007d07b35d495e  vmovaps xmm9, [rsp+0x90]
00007d07b35d4967  vmovaps xmm10, [rsp+0xA0]
00007d07b35d4970  vmovaps xmm11, [rsp+0xB0]
00007d07b35d4979  vmovaps xmm12, [rsp+0xC0]
00007d07b35d4982  vmovaps xmm14, [rsp+0xD0]
00007d07b35d498b  vmovaps xmm15, [rsp+0xE0]
00007d07b35d4994  add rsp, 0xF0
00007d07b35d499b  pop r11
00007d07b35d499d  pop r10
00007d07b35d499f  pop r9
00007d07b35d49a1  pop r8
00007d07b35d49a3  pop rsi
00007d07b35d49a4  pop rdi
00007d07b35d49a5  pop rdx
00007d07b35d49a6  pop rcx
00007d07b35d49a7  pop rax
00007d07b35d49a8  add rsp, 0x08
00007d07b35d49ac  jmp 0x00007D07B35D0183
00007d07b35d49b1  call 0x00007D07B33FF430
00007d07b35d49b6  jmp 0x00007D07B35D018D
00007d07b35d49bb  sub rsp, 0x08
00007d07b35d49bf  push rax
00007d07b35d49c0  push rcx
00007d07b35d49c1  push rdx
00007d07b35d49c2  push rdi
00007d07b35d49c3  push rsi
00007d07b35d49c4  push r8
00007d07b35d49c6  push r9
00007d07b35d49c8  push r10
00007d07b35d49ca  push r11
00007d07b35d49cc  sub rsp, 0xF0
00007d07b35d49d3  vmovaps [rsp], xmm0
00007d07b35d49d8  vmovaps [rsp+0x10], xmm1
00007d07b35d49de  vmovaps [rsp+0x20], xmm2
00007d07b35d49e4  vmovaps [rsp+0x30], xmm3
00007d07b35d49ea  vmovaps [rsp+0x40], xmm4
00007d07b35d49f0  vmovaps [rsp+0x50], xmm5
00007d07b35d49f6  vmovaps [rsp+0x60], xmm6
00007d07b35d49fc  vmovaps [rsp+0x70], xmm7
00007d07b35d4a02  vmovaps [rsp+0x80], xmm9
00007d07b35d4a0b  vmovaps [rsp+0x90], xmm10
00007d07b35d4a14  vmovaps [rsp+0xA0], xmm11
00007d07b35d4a1d  vmovaps [rsp+0xB0], xmm12
00007d07b35d4a26  vmovaps [rsp+0xC0], xmm13
00007d07b35d4a2f  vmovaps [rsp+0xD0], xmm14
00007d07b35d4a38  vmovaps [rsp+0xE0], xmm15
00007d07b35d4a41  sub rsp, 0x30
00007d07b35d4a45  movaps [rsp], xmm8
00007d07b35d4a4a  movaps [rsp+0x10], xmm14
00007d07b35d4a50  movaps [rsp+0x20], xmm9
00007d07b35d4a56  lea rdi, [rsp]
00007d07b35d4a5a  mov esi, 0x00
00007d07b35d4a5f  mov rax, 0x5D0AA712D530
00007d07b35d4a69  call rax
00007d07b35d4a6b  movaps xmm8, [rsp]
00007d07b35d4a70  add rsp, 0x30
00007d07b35d4a74  vmovaps xmm0, [rsp]
00007d07b35d4a79  vmovaps xmm1, [rsp+0x10]
00007d07b35d4a7f  vmovaps xmm2, [rsp+0x20]
00007d07b35d4a85  vmovaps xmm3, [rsp+0x30]
00007d07b35d4a8b  vmovaps xmm4, [rsp+0x40]
00007d07b35d4a91  vmovaps xmm5, [rsp+0x50]
00007d07b35d4a97  vmovaps xmm6, [rsp+0x60]
00007d07b35d4a9d  vmovaps xmm7, [rsp+0x70]
00007d07b35d4aa3  vmovaps xmm9, [rsp+0x80]
00007d07b35d4aac  vmovaps xmm10, [rsp+0x90]
00007d07b35d4ab5  vmovaps xmm11, [rsp+0xA0]
00007d07b35d4abe  vmovaps xmm12, [rsp+0xB0]
00007d07b35d4ac7  vmovaps xmm13, [rsp+0xC0]
00007d07b35d4ad0  vmovaps xmm14, [rsp+0xD0]
00007d07b35d4ad9  vmovaps xmm15, [rsp+0xE0]
00007d07b35d4ae2  add rsp, 0xF0
00007d07b35d4ae9  pop r11
00007d07b35d4aeb  pop r10
00007d07b35d4aed  pop r9
00007d07b35d4aef  pop r8
00007d07b35d4af1  pop rsi
00007d07b35d4af2  pop rdi
00007d07b35d4af3  pop rdx
00007d07b35d4af4  pop rcx
00007d07b35d4af5  pop rax
00007d07b35d4af6  add rsp, 0x08
00007d07b35d4afa  jmp 0x00007D07B35D01AF
00007d07b35d4aff  sub rsp, 0x08
00007d07b35d4b03  push rax
00007d07b35d4b04  push rcx
00007d07b35d4b05  push rdx
00007d07b35d4b06  push rdi
00007d07b35d4b07  push rsi
00007d07b35d4b08  push r8
00007d07b35d4b0a  push r9
00007d07b35d4b0c  push r10
00007d07b35d4b0e  push r11
00007d07b35d4b10  sub rsp, 0xF0
00007d07b35d4b17  vmovaps [rsp], xmm0
00007d07b35d4b1c  vmovaps [rsp+0x10], xmm1
00007d07b35d4b22  vmovaps [rsp+0x20], xmm2
00007d07b35d4b28  vmovaps [rsp+0x30], xmm3
00007d07b35d4b2e  vmovaps [rsp+0x40], xmm4
00007d07b35d4b34  vmovaps [rsp+0x50], xmm5
00007d07b35d4b3a  vmovaps [rsp+0x60], xmm6
00007d07b35d4b40  vmovaps [rsp+0x70], xmm7
00007d07b35d4b46  vmovaps [rsp+0x80], xmm8
00007d07b35d4b4f  vmovaps [rsp+0x90], xmm10
00007d07b35d4b58  vmovaps [rsp+0xA0], xmm11
00007d07b35d4b61  vmovaps [rsp+0xB0], xmm12
00007d07b35d4b6a  vmovaps [rsp+0xC0], xmm13
00007d07b35d4b73  vmovaps [rsp+0xD0], xmm14
00007d07b35d4b7c  vmovaps [rsp+0xE0], xmm15
00007d07b35d4b85  sub rsp, 0x30
00007d07b35d4b89  movaps [rsp], xmm9
00007d07b35d4b8e  movaps [rsp+0x10], xmm1
00007d07b35d4b93  movaps [rsp+0x20], xmm14
00007d07b35d4b99  lea rdi, [rsp]
00007d07b35d4b9d  mov esi, 0x00
00007d07b35d4ba2  mov rax, 0x5D0AA712D530
00007d07b35d4bac  call rax
00007d07b35d4bae  movaps xmm9, [rsp]
00007d07b35d4bb3  add rsp, 0x30
00007d07b35d4bb7  vmovaps xmm0, [rsp]
00007d07b35d4bbc  vmovaps xmm1, [rsp+0x10]
00007d07b35d4bc2  vmovaps xmm2, [rsp+0x20]
00007d07b35d4bc8  vmovaps xmm3, [rsp+0x30]
00007d07b35d4bce  vmovaps xmm4, [rsp+0x40]
00007d07b35d4bd4  vmovaps xmm5, [rsp+0x50]
00007d07b35d4bda  vmovaps xmm6, [rsp+0x60]
00007d07b35d4be0  vmovaps xmm7, [rsp+0x70]
00007d07b35d4be6  vmovaps xmm8, [rsp+0x80]
00007d07b35d4bef  vmovaps xmm10, [rsp+0x90]
00007d07b35d4bf8  vmovaps xmm11, [rsp+0xA0]
00007d07b35d4c01  vmovaps xmm12, [rsp+0xB0]
00007d07b35d4c0a  vmovaps xmm13, [rsp+0xC0]
00007d07b35d4c13  vmovaps xmm14, [rsp+0xD0]
00007d07b35d4c1c  vmovaps xmm15, [rsp+0xE0]
00007d07b35d4c25  add rsp, 0xF0
00007d07b35d4c2c  pop r11
00007d07b35d4c2e  pop r10
00007d07b35d4c30  pop r9
00007d07b35d4c32  pop r8
00007d07b35d4c34  pop rsi
00007d07b35d4c35  pop rdi
00007d07b35d4c36  pop rdx
00007d07b35d4c37  pop rcx
00007d07b35d4c38  pop rax
00007d07b35d4c39  add rsp, 0x08
00007d07b35d4c3d  jmp 0x00007D07B35D01DD
00007d07b35d4c42  sub rsp, 0x08
00007d07b35d4c46  push rax
00007d07b35d4c47  push rcx
00007d07b35d4c48  push rdx
00007d07b35d4c49  push rdi
00007d07b35d4c4a  push rsi
00007d07b35d4c4b  push r8
00007d07b35d4c4d  push r9
00007d07b35d4c4f  push r10
00007d07b35d4c51  push r11
00007d07b35d4c53  sub rsp, 0xF0
00007d07b35d4c5a  vmovaps [rsp], xmm0
00007d07b35d4c5f  vmovaps [rsp+0x10], xmm1
00007d07b35d4c65  vmovaps [rsp+0x20], xmm2
00007d07b35d4c6b  vmovaps [rsp+0x30], xmm3
00007d07b35d4c71  vmovaps [rsp+0x40], xmm4
00007d07b35d4c77  vmovaps [rsp+0x50], xmm5
00007d07b35d4c7d  vmovaps [rsp+0x60], xmm6
00007d07b35d4c83  vmovaps [rsp+0x70], xmm7
00007d07b35d4c89  vmovaps [rsp+0x80], xmm8
00007d07b35d4c92  vmovaps [rsp+0x90], xmm9
00007d07b35d4c9b  vmovaps [rsp+0xA0], xmm10
00007d07b35d4ca4  vmovaps [rsp+0xB0], xmm11
00007d07b35d4cad  vmovaps [rsp+0xC0], xmm12
00007d07b35d4cb6  vmovaps [rsp+0xD0], xmm13
00007d07b35d4cbf  vmovaps [rsp+0xE0], xmm15
00007d07b35d4cc8  sub rsp, 0x30
00007d07b35d4ccc  movaps [rsp], xmm14
00007d07b35d4cd1  movaps [rsp+0x10], xmm4
00007d07b35d4cd6  movaps [rsp+0x20], xmm1
00007d07b35d4cdb  lea rdi, [rsp]
00007d07b35d4cdf  mov esi, 0x00
00007d07b35d4ce4  mov rax, 0x5D0AA712D530
00007d07b35d4cee  call rax
00007d07b35d4cf0  movaps xmm14, [rsp]
00007d07b35d4cf5  add rsp, 0x30
00007d07b35d4cf9  vmovaps xmm0, [rsp]
00007d07b35d4cfe  vmovaps xmm1, [rsp+0x10]
00007d07b35d4d04  vmovaps xmm2, [rsp+0x20]
00007d07b35d4d0a  vmovaps xmm3, [rsp+0x30]
00007d07b35d4d10  vmovaps xmm4, [rsp+0x40]
00007d07b35d4d16  vmovaps xmm5, [rsp+0x50]
00007d07b35d4d1c  vmovaps xmm6, [rsp+0x60]
00007d07b35d4d22  vmovaps xmm7, [rsp+0x70]
00007d07b35d4d28  vmovaps xmm8, [rsp+0x80]
00007d07b35d4d31  vmovaps xmm9, [rsp+0x90]
00007d07b35d4d3a  vmovaps xmm10, [rsp+0xA0]
00007d07b35d4d43  vmovaps xmm11, [rsp+0xB0]
00007d07b35d4d4c  vmovaps xmm12, [rsp+0xC0]
00007d07b35d4d55  vmovaps xmm13, [rsp+0xD0]
00007d07b35d4d5e  vmovaps xmm15, [rsp+0xE0]
00007d07b35d4d67  add rsp, 0xF0
00007d07b35d4d6e  pop r11
00007d07b35d4d70  pop r10
00007d07b35d4d72  pop r9
00007d07b35d4d74  pop r8
00007d07b35d4d76  pop rsi
00007d07b35d4d77  pop rdi
00007d07b35d4d78  pop rdx
00007d07b35d4d79  pop rcx
00007d07b35d4d7a  pop rax
00007d07b35d4d7b  add rsp, 0x08
00007d07b35d4d7f  jmp 0x00007D07B35D0203
00007d07b35d4d84  sub rsp, 0x08
00007d07b35d4d88  push rax
00007d07b35d4d89  push rcx
00007d07b35d4d8a  push rdx
00007d07b35d4d8b  push rdi
00007d07b35d4d8c  push rsi
00007d07b35d4d8d  push r8
00007d07b35d4d8f  push r9
00007d07b35d4d91  push r10
00007d07b35d4d93  push r11
00007d07b35d4d95  sub rsp, 0xF0
00007d07b35d4d9c  vmovaps [rsp], xmm0
00007d07b35d4da1  vmovaps [rsp+0x10], xmm2
00007d07b35d4da7  vmovaps [rsp+0x20], xmm3
00007d07b35d4dad  vmovaps [rsp+0x30], xmm4
00007d07b35d4db3  vmovaps [rsp+0x40], xmm5
00007d07b35d4db9  vmovaps [rsp+0x50], xmm6
00007d07b35d4dbf  vmovaps [rsp+0x60], xmm7
00007d07b35d4dc5  vmovaps [rsp+0x70], xmm8
00007d07b35d4dcb  vmovaps [rsp+0x80], xmm9
00007d07b35d4dd4  vmovaps [rsp+0x90], xmm10
00007d07b35d4ddd  vmovaps [rsp+0xA0], xmm11
00007d07b35d4de6  vmovaps [rsp+0xB0], xmm12
00007d07b35d4def  vmovaps [rsp+0xC0], xmm13
00007d07b35d4df8  vmovaps [rsp+0xD0], xmm14
00007d07b35d4e01  vmovaps [rsp+0xE0], xmm15
00007d07b35d4e0a  sub rsp, 0x30
00007d07b35d4e0e  movaps [rsp], xmm1
00007d07b35d4e12  movaps [rsp+0x10], xmm12
00007d07b35d4e18  movaps [rsp+0x20], xmm11
00007d07b35d4e1e  lea rdi, [rsp]
00007d07b35d4e22  mov esi, 0x00
00007d07b35d4e27  mov rax, 0x5D0AA712D530
00007d07b35d4e31  call rax
00007d07b35d4e33  movaps xmm1, [rsp]
00007d07b35d4e37  add rsp, 0x30
00007d07b35d4e3b  vmovaps xmm0, [rsp]
00007d07b35d4e40  vmovaps xmm2, [rsp+0x10]
00007d07b35d4e46  vmovaps xmm3, [rsp+0x20]
00007d07b35d4e4c  vmovaps xmm4, [rsp+0x30]
00007d07b35d4e52  vmovaps xmm5, [rsp+0x40]
00007d07b35d4e58  vmovaps xmm6, [rsp+0x50]
00007d07b35d4e5e  vmovaps xmm7, [rsp+0x60]
00007d07b35d4e64  vmovaps xmm8, [rsp+0x70]
00007d07b35d4e6a  vmovaps xmm9, [rsp+0x80]
00007d07b35d4e73  vmovaps xmm10, [rsp+0x90]
00007d07b35d4e7c  vmovaps xmm11, [rsp+0xA0]
00007d07b35d4e85  vmovaps xmm12, [rsp+0xB0]
00007d07b35d4e8e  vmovaps xmm13, [rsp+0xC0]
00007d07b35d4e97  vmovaps xmm14, [rsp+0xD0]
00007d07b35d4ea0  vmovaps xmm15, [rsp+0xE0]
00007d07b35d4ea9  add rsp, 0xF0
00007d07b35d4eb0  pop r11
00007d07b35d4eb2  pop r10
00007d07b35d4eb4  pop r9
00007d07b35d4eb6  pop r8
00007d07b35d4eb8  pop rsi
00007d07b35d4eb9  pop rdi
00007d07b35d4eba  pop rdx
00007d07b35d4ebb  pop rcx
00007d07b35d4ebc  pop rax
00007d07b35d4ebd  add rsp, 0x08
00007d07b35d4ec1  jmp 0x00007D07B35D0224
00007d07b35d4ec6  call 0x00007D07B34E20A0
00007d07b35d4ecb  jmp 0x00007D07B35D0232
00007d07b35d4ed0  call 0x00007D07B3409D70
00007d07b35d4ed5  jmp 0x00007D07B35D023C
00007d07b35d4eda  sub rsp, 0x08
00007d07b35d4ede  push rax
00007d07b35d4edf  push rcx
00007d07b35d4ee0  push rdx
00007d07b35d4ee1  push rdi
00007d07b35d4ee2  push rsi
00007d07b35d4ee3  push r8
00007d07b35d4ee5  push r9
00007d07b35d4ee7  push r10
00007d07b35d4ee9  push r11
00007d07b35d4eeb  sub rsp, 0xF0
00007d07b35d4ef2  vmovaps [rsp], xmm0
00007d07b35d4ef7  vmovaps [rsp+0x10], xmm1
00007d07b35d4efd  vmovaps [rsp+0x20], xmm2
00007d07b35d4f03  vmovaps [rsp+0x30], xmm3
00007d07b35d4f09  vmovaps [rsp+0x40], xmm4
00007d07b35d4f0f  vmovaps [rsp+0x50], xmm5
00007d07b35d4f15  vmovaps [rsp+0x60], xmm6
00007d07b35d4f1b  vmovaps [rsp+0x70], xmm8
00007d07b35d4f21  vmovaps [rsp+0x80], xmm9
00007d07b35d4f2a  vmovaps [rsp+0x90], xmm10
00007d07b35d4f33  vmovaps [rsp+0xA0], xmm11
00007d07b35d4f3c  vmovaps [rsp+0xB0], xmm12
00007d07b35d4f45  vmovaps [rsp+0xC0], xmm13
00007d07b35d4f4e  vmovaps [rsp+0xD0], xmm14
00007d07b35d4f57  vmovaps [rsp+0xE0], xmm15
00007d07b35d4f60  sub rsp, 0x30
00007d07b35d4f64  movaps [rsp], xmm7
00007d07b35d4f68  movaps [rsp+0x10], xmm15
00007d07b35d4f6e  movaps [rsp+0x20], xmm10
00007d07b35d4f74  lea rdi, [rsp]
00007d07b35d4f78  mov esi, 0x00
00007d07b35d4f7d  mov rax, 0x5D0AA712D530
00007d07b35d4f87  call rax
00007d07b35d4f89  movaps xmm7, [rsp]
00007d07b35d4f8d  add rsp, 0x30
00007d07b35d4f91  vmovaps xmm0, [rsp]
00007d07b35d4f96  vmovaps xmm1, [rsp+0x10]
00007d07b35d4f9c  vmovaps xmm2, [rsp+0x20]
00007d07b35d4fa2  vmovaps xmm3, [rsp+0x30]
00007d07b35d4fa8  vmovaps xmm4, [rsp+0x40]
00007d07b35d4fae  vmovaps xmm5, [rsp+0x50]
00007d07b35d4fb4  vmovaps xmm6, [rsp+0x60]
00007d07b35d4fba  vmovaps xmm8, [rsp+0x70]
00007d07b35d4fc0  vmovaps xmm9, [rsp+0x80]
00007d07b35d4fc9  vmovaps xmm10, [rsp+0x90]
00007d07b35d4fd2  vmovaps xmm11, [rsp+0xA0]
00007d07b35d4fdb  vmovaps xmm12, [rsp+0xB0]
00007d07b35d4fe4  vmovaps xmm13, [rsp+0xC0]
00007d07b35d4fed  vmovaps xmm14, [rsp+0xD0]
00007d07b35d4ff6  vmovaps xmm15, [rsp+0xE0]
00007d07b35d4fff  add rsp, 0xF0
00007d07b35d5006  pop r11
00007d07b35d5008  pop r10
00007d07b35d500a  pop r9
00007d07b35d500c  pop r8
00007d07b35d500e  pop rsi
00007d07b35d500f  pop rdi
00007d07b35d5010  pop rdx
00007d07b35d5011  pop rcx
00007d07b35d5012  pop rax
00007d07b35d5013  add rsp, 0x08
00007d07b35d5017  jmp 0x00007D07B35D025D
00007d07b35d501c  sub rsp, 0x08
00007d07b35d5020  push rax
00007d07b35d5021  push rcx
00007d07b35d5022  push rdx
00007d07b35d5023  push rdi
00007d07b35d5024  push rsi
00007d07b35d5025  push r8
00007d07b35d5027  push r9
00007d07b35d5029  push r10
00007d07b35d502b  push r11
00007d07b35d502d  sub rsp, 0xF0
00007d07b35d5034  vmovaps [rsp], xmm0
00007d07b35d5039  vmovaps [rsp+0x10], xmm1
00007d07b35d503f  vmovaps [rsp+0x20], xmm2
00007d07b35d5045  vmovaps [rsp+0x30], xmm3
00007d07b35d504b  vmovaps [rsp+0x40], xmm4
00007d07b35d5051  vmovaps [rsp+0x50], xmm5
00007d07b35d5057  vmovaps [rsp+0x60], xmm6
00007d07b35d505d  vmovaps [rsp+0x70], xmm7
00007d07b35d5063  vmovaps [rsp+0x80], xmm8
00007d07b35d506c  vmovaps [rsp+0x90], xmm9
00007d07b35d5075  vmovaps [rsp+0xA0], xmm11
00007d07b35d507e  vmovaps [rsp+0xB0], xmm12
00007d07b35d5087  vmovaps [rsp+0xC0], xmm13
00007d07b35d5090  vmovaps [rsp+0xD0], xmm14
00007d07b35d5099  vmovaps [rsp+0xE0], xmm15
00007d07b35d50a2  sub rsp, 0x30
00007d07b35d50a6  movaps [rsp], xmm10
00007d07b35d50ab  movaps [rsp+0x10], xmm11
00007d07b35d50b1  movaps [rsp+0x20], xmm15
00007d07b35d50b7  lea rdi, [rsp]
00007d07b35d50bb  mov esi, 0x00
00007d07b35d50c0  mov rax, 0x5D0AA712D530
00007d07b35d50ca  call rax
00007d07b35d50cc  movaps xmm10, [rsp]
00007d07b35d50d1  add rsp, 0x30
00007d07b35d50d5  vmovaps xmm0, [rsp]
00007d07b35d50da  vmovaps xmm1, [rsp+0x10]
00007d07b35d50e0  vmovaps xmm2, [rsp+0x20]
00007d07b35d50e6  vmovaps xmm3, [rsp+0x30]
00007d07b35d50ec  vmovaps xmm4, [rsp+0x40]
00007d07b35d50f2  vmovaps xmm5, [rsp+0x50]
00007d07b35d50f8  vmovaps xmm6, [rsp+0x60]
00007d07b35d50fe  vmovaps xmm7, [rsp+0x70]
00007d07b35d5104  vmovaps xmm8, [rsp+0x80]
00007d07b35d510d  vmovaps xmm9, [rsp+0x90]
00007d07b35d5116  vmovaps xmm11, [rsp+0xA0]
00007d07b35d511f  vmovaps xmm12, [rsp+0xB0]
00007d07b35d5128  vmovaps xmm13, [rsp+0xC0]
00007d07b35d5131  vmovaps xmm14, [rsp+0xD0]
00007d07b35d513a  vmovaps xmm15, [rsp+0xE0]
00007d07b35d5143  add rsp, 0xF0
00007d07b35d514a  pop r11
00007d07b35d514c  pop r10
00007d07b35d514e  pop r9
00007d07b35d5150  pop r8
00007d07b35d5152  pop rsi
00007d07b35d5153  pop rdi
00007d07b35d5154  pop rdx
00007d07b35d5155  pop rcx
00007d07b35d5156  pop rax
00007d07b35d5157  add rsp, 0x08
00007d07b35d515b  jmp 0x00007D07B35D028B
00007d07b35d5160  sub rsp, 0x08
00007d07b35d5164  push rax
00007d07b35d5165  push rcx
00007d07b35d5166  push rdx
00007d07b35d5167  push rdi
00007d07b35d5168  push rsi
00007d07b35d5169  push r8
00007d07b35d516b  push r9
00007d07b35d516d  push r10
00007d07b35d516f  push r11
00007d07b35d5171  sub rsp, 0xF0
00007d07b35d5178  vmovaps [rsp], xmm0
00007d07b35d517d  vmovaps [rsp+0x10], xmm1
00007d07b35d5183  vmovaps [rsp+0x20], xmm2
00007d07b35d5189  vmovaps [rsp+0x30], xmm3
00007d07b35d518f  vmovaps [rsp+0x40], xmm4
00007d07b35d5195  vmovaps [rsp+0x50], xmm5
00007d07b35d519b  vmovaps [rsp+0x60], xmm6
00007d07b35d51a1  vmovaps [rsp+0x70], xmm7
00007d07b35d51a7  vmovaps [rsp+0x80], xmm8
00007d07b35d51b0  vmovaps [rsp+0x90], xmm9
00007d07b35d51b9  vmovaps [rsp+0xA0], xmm10
00007d07b35d51c2  vmovaps [rsp+0xB0], xmm12
00007d07b35d51cb  vmovaps [rsp+0xC0], xmm13
00007d07b35d51d4  vmovaps [rsp+0xD0], xmm14
00007d07b35d51dd  vmovaps [rsp+0xE0], xmm15
00007d07b35d51e6  sub rsp, 0x30
00007d07b35d51ea  movaps [rsp], xmm11
00007d07b35d51ef  movaps [rsp+0x10], xmm12
00007d07b35d51f5  movaps [rsp+0x20], xmm15
00007d07b35d51fb  lea rdi, [rsp]
00007d07b35d51ff  mov esi, 0x00
00007d07b35d5204  mov rax, 0x5D0AA712D530
00007d07b35d520e  call rax
00007d07b35d5210  movaps xmm11, [rsp]
00007d07b35d5215  add rsp, 0x30
00007d07b35d5219  vmovaps xmm0, [rsp]
00007d07b35d521e  vmovaps xmm1, [rsp+0x10]
00007d07b35d5224  vmovaps xmm2, [rsp+0x20]
00007d07b35d522a  vmovaps xmm3, [rsp+0x30]
00007d07b35d5230  vmovaps xmm4, [rsp+0x40]
00007d07b35d5236  vmovaps xmm5, [rsp+0x50]
00007d07b35d523c  vmovaps xmm6, [rsp+0x60]
00007d07b35d5242  vmovaps xmm7, [rsp+0x70]
00007d07b35d5248  vmovaps xmm8, [rsp+0x80]
00007d07b35d5251  vmovaps xmm9, [rsp+0x90]
00007d07b35d525a  vmovaps xmm10, [rsp+0xA0]
00007d07b35d5263  vmovaps xmm12, [rsp+0xB0]
00007d07b35d526c  vmovaps xmm13, [rsp+0xC0]
00007d07b35d5275  vmovaps xmm14, [rsp+0xD0]
00007d07b35d527e  vmovaps xmm15, [rsp+0xE0]
00007d07b35d5287  add rsp, 0xF0
00007d07b35d528e  pop r11
00007d07b35d5290  pop r10
00007d07b35d5292  pop r9
00007d07b35d5294  pop r8
00007d07b35d5296  pop rsi
00007d07b35d5297  pop rdi
00007d07b35d5298  pop rdx
00007d07b35d5299  pop rcx
00007d07b35d529a  pop rax
00007d07b35d529b  add rsp, 0x08
00007d07b35d529f  jmp 0x00007D07B35D02B9
00007d07b35d52a4  sub rsp, 0x08
00007d07b35d52a8  push rax
00007d07b35d52a9  push rcx
00007d07b35d52aa  push rdx
00007d07b35d52ab  push rdi
00007d07b35d52ac  push rsi
00007d07b35d52ad  push r8
00007d07b35d52af  push r9
00007d07b35d52b1  push r10
00007d07b35d52b3  push r11
00007d07b35d52b5  sub rsp, 0xF0
00007d07b35d52bc  vmovaps [rsp], xmm0
00007d07b35d52c1  vmovaps [rsp+0x10], xmm1
00007d07b35d52c7  vmovaps [rsp+0x20], xmm2
00007d07b35d52cd  vmovaps [rsp+0x30], xmm3
00007d07b35d52d3  vmovaps [rsp+0x40], xmm4
00007d07b35d52d9  vmovaps [rsp+0x50], xmm5
00007d07b35d52df  vmovaps [rsp+0x60], xmm6
00007d07b35d52e5  vmovaps [rsp+0x70], xmm7
00007d07b35d52eb  vmovaps [rsp+0x80], xmm8
00007d07b35d52f4  vmovaps [rsp+0x90], xmm9
00007d07b35d52fd  vmovaps [rsp+0xA0], xmm10
00007d07b35d5306  vmovaps [rsp+0xB0], xmm11
00007d07b35d530f  vmovaps [rsp+0xC0], xmm12
00007d07b35d5318  vmovaps [rsp+0xD0], xmm13
00007d07b35d5321  vmovaps [rsp+0xE0], xmm14
00007d07b35d532a  sub rsp, 0x30
00007d07b35d532e  movaps [rsp], xmm15
00007d07b35d5333  movaps [rsp+0x10], xmm13
00007d07b35d5339  movaps [rsp+0x20], xmm9
00007d07b35d533f  lea rdi, [rsp]
00007d07b35d5343  mov esi, 0x00
00007d07b35d5348  mov rax, 0x5D0AA712D530
00007d07b35d5352  call rax
00007d07b35d5354  movaps xmm15, [rsp]
00007d07b35d5359  add rsp, 0x30
00007d07b35d535d  vmovaps xmm0, [rsp]
00007d07b35d5362  vmovaps xmm1, [rsp+0x10]
00007d07b35d5368  vmovaps xmm2, [rsp+0x20]
00007d07b35d536e  vmovaps xmm3, [rsp+0x30]
00007d07b35d5374  vmovaps xmm4, [rsp+0x40]
00007d07b35d537a  vmovaps xmm5, [rsp+0x50]
00007d07b35d5380  vmovaps xmm6, [rsp+0x60]
00007d07b35d5386  vmovaps xmm7, [rsp+0x70]
00007d07b35d538c  vmovaps xmm8, [rsp+0x80]
00007d07b35d5395  vmovaps xmm9, [rsp+0x90]
00007d07b35d539e  vmovaps xmm10, [rsp+0xA0]
00007d07b35d53a7  vmovaps xmm11, [rsp+0xB0]
00007d07b35d53b0  vmovaps xmm12, [rsp+0xC0]
00007d07b35d53b9  vmovaps xmm13, [rsp+0xD0]
00007d07b35d53c2  vmovaps xmm14, [rsp+0xE0]
00007d07b35d53cb  add rsp, 0xF0
00007d07b35d53d2  pop r11
00007d07b35d53d4  pop r10
00007d07b35d53d6  pop r9
00007d07b35d53d8  pop r8
00007d07b35d53da  pop rsi
00007d07b35d53db  pop rdi
00007d07b35d53dc  pop rdx
00007d07b35d53dd  pop rcx
00007d07b35d53de  pop rax
00007d07b35d53df  add rsp, 0x08
00007d07b35d53e3  jmp 0x00007D07B35D02D4
00007d07b35d53e8  sub rsp, 0x08
00007d07b35d53ec  push rax
00007d07b35d53ed  push rcx
00007d07b35d53ee  push rdx
00007d07b35d53ef  push rdi
00007d07b35d53f0  push rsi
00007d07b35d53f1  push r8
00007d07b35d53f3  push r9
00007d07b35d53f5  push r10
00007d07b35d53f7  push r11
00007d07b35d53f9  sub rsp, 0xF0
00007d07b35d5400  vmovaps [rsp], xmm0
00007d07b35d5405  vmovaps [rsp+0x10], xmm1
00007d07b35d540b  vmovaps [rsp+0x20], xmm2
00007d07b35d5411  vmovaps [rsp+0x30], xmm3
00007d07b35d5417  vmovaps [rsp+0x40], xmm4
00007d07b35d541d  vmovaps [rsp+0x50], xmm5
00007d07b35d5423  vmovaps [rsp+0x60], xmm6
00007d07b35d5429  vmovaps [rsp+0x70], xmm7
00007d07b35d542f  vmovaps [rsp+0x80], xmm8
00007d07b35d5438  vmovaps [rsp+0x90], xmm9
00007d07b35d5441  vmovaps [rsp+0xA0], xmm10
00007d07b35d544a  vmovaps [rsp+0xB0], xmm11
00007d07b35d5453  vmovaps [rsp+0xC0], xmm12
00007d07b35d545c  vmovaps [rsp+0xD0], xmm14
00007d07b35d5465  vmovaps [rsp+0xE0], xmm15
00007d07b35d546e  sub rsp, 0x30
00007d07b35d5472  movaps [rsp], xmm13
00007d07b35d5477  movaps [rsp+0x10], xmm8
00007d07b35d547d  movaps [rsp+0x20], xmm14
00007d07b35d5483  lea rdi, [rsp]
00007d07b35d5487  mov esi, 0x00
00007d07b35d548c  mov rax, 0x5D0AA712D530
00007d07b35d5496  call rax
00007d07b35d5498  movaps xmm13, [rsp]
00007d07b35d549d  add rsp, 0x30
00007d07b35d54a1  vmovaps xmm0, [rsp]
00007d07b35d54a6  vmovaps xmm1, [rsp+0x10]
00007d07b35d54ac  vmovaps xmm2, [rsp+0x20]
00007d07b35d54b2  vmovaps xmm3, [rsp+0x30]
00007d07b35d54b8  vmovaps xmm4, [rsp+0x40]
00007d07b35d54be  vmovaps xmm5, [rsp+0x50]
00007d07b35d54c4  vmovaps xmm6, [rsp+0x60]
00007d07b35d54ca  vmovaps xmm7, [rsp+0x70]
00007d07b35d54d0  vmovaps xmm8, [rsp+0x80]
00007d07b35d54d9  vmovaps xmm9, [rsp+0x90]
00007d07b35d54e2  vmovaps xmm10, [rsp+0xA0]
00007d07b35d54eb  vmovaps xmm11, [rsp+0xB0]
00007d07b35d54f4  vmovaps xmm12, [rsp+0xC0]
00007d07b35d54fd  vmovaps xmm14, [rsp+0xD0]
00007d07b35d5506  vmovaps xmm15, [rsp+0xE0]
00007d07b35d550f  add rsp, 0xF0
00007d07b35d5516  pop r11
00007d07b35d5518  pop r10
00007d07b35d551a  pop r9
00007d07b35d551c  pop r8
00007d07b35d551e  pop rsi
00007d07b35d551f  pop rdi
00007d07b35d5520  pop rdx
00007d07b35d5521  pop rcx
00007d07b35d5522  pop rax
00007d07b35d5523  add rsp, 0x08
00007d07b35d5527  jmp 0x00007D07B35D02F7
00007d07b35d552c  sub rsp, 0x08
00007d07b35d5530  push rax
00007d07b35d5531  push rcx
00007d07b35d5532  push rdx
00007d07b35d5533  push rdi
00007d07b35d5534  push rsi
00007d07b35d5535  push r8
00007d07b35d5537  push r9
00007d07b35d5539  push r10
00007d07b35d553b  push r11
00007d07b35d553d  sub rsp, 0xF0
00007d07b35d5544  vmovaps [rsp], xmm0
00007d07b35d5549  vmovaps [rsp+0x10], xmm1
00007d07b35d554f  vmovaps [rsp+0x20], xmm2
00007d07b35d5555  vmovaps [rsp+0x30], xmm3
00007d07b35d555b  vmovaps [rsp+0x40], xmm4
00007d07b35d5561  vmovaps [rsp+0x50], xmm5
00007d07b35d5567  vmovaps [rsp+0x60], xmm6
00007d07b35d556d  vmovaps [rsp+0x70], xmm7
00007d07b35d5573  vmovaps [rsp+0x80], xmm8
00007d07b35d557c  vmovaps [rsp+0x90], xmm9
00007d07b35d5585  vmovaps [rsp+0xA0], xmm10
00007d07b35d558e  vmovaps [rsp+0xB0], xmm11
00007d07b35d5597  vmovaps [rsp+0xC0], xmm12
00007d07b35d55a0  vmovaps [rsp+0xD0], xmm13
00007d07b35d55a9  vmovaps [rsp+0xE0], xmm15
00007d07b35d55b2  sub rsp, 0x30
00007d07b35d55b6  movaps [rsp], xmm14
00007d07b35d55bb  movaps [rsp+0x10], xmm1
00007d07b35d55c0  movaps [rsp+0x20], xmm10
00007d07b35d55c6  lea rdi, [rsp]
00007d07b35d55ca  mov esi, 0x00
00007d07b35d55cf  mov rax, 0x5D0AA712D530
00007d07b35d55d9  call rax
00007d07b35d55db  movaps xmm14, [rsp]
00007d07b35d55e0  add rsp, 0x30
00007d07b35d55e4  vmovaps xmm0, [rsp]
00007d07b35d55e9  vmovaps xmm1, [rsp+0x10]
00007d07b35d55ef  vmovaps xmm2, [rsp+0x20]
00007d07b35d55f5  vmovaps xmm3, [rsp+0x30]
00007d07b35d55fb  vmovaps xmm4, [rsp+0x40]
00007d07b35d5601  vmovaps xmm5, [rsp+0x50]
00007d07b35d5607  vmovaps xmm6, [rsp+0x60]
00007d07b35d560d  vmovaps xmm7, [rsp+0x70]
00007d07b35d5613  vmovaps xmm8, [rsp+0x80]
00007d07b35d561c  vmovaps xmm9, [rsp+0x90]
00007d07b35d5625  vmovaps xmm10, [rsp+0xA0]
00007d07b35d562e  vmovaps xmm11, [rsp+0xB0]
00007d07b35d5637  vmovaps xmm12, [rsp+0xC0]
00007d07b35d5640  vmovaps xmm13, [rsp+0xD0]
00007d07b35d5649  vmovaps xmm15, [rsp+0xE0]
00007d07b35d5652  add rsp, 0xF0
00007d07b35d5659  pop r11
00007d07b35d565b  pop r10
00007d07b35d565d  pop r9
00007d07b35d565f  pop r8
00007d07b35d5661  pop rsi
00007d07b35d5662  pop rdi
00007d07b35d5663  pop rdx
00007d07b35d5664  pop rcx
00007d07b35d5665  pop rax
00007d07b35d5666  add rsp, 0x08
00007d07b35d566a  jmp 0x00007D07B35D031A
00007d07b35d566f  sub rsp, 0x08
00007d07b35d5673  push rax
00007d07b35d5674  push rcx
00007d07b35d5675  push rdx
00007d07b35d5676  push rdi
00007d07b35d5677  push rsi
00007d07b35d5678  push r8
00007d07b35d567a  push r9
00007d07b35d567c  push r10
00007d07b35d567e  push r11
00007d07b35d5680  sub rsp, 0xF0
00007d07b35d5687  vmovaps [rsp], xmm0
00007d07b35d568c  vmovaps [rsp+0x10], xmm2
00007d07b35d5692  vmovaps [rsp+0x20], xmm3
00007d07b35d5698  vmovaps [rsp+0x30], xmm4
00007d07b35d569e  vmovaps [rsp+0x40], xmm5
00007d07b35d56a4  vmovaps [rsp+0x50], xmm6
00007d07b35d56aa  vmovaps [rsp+0x60], xmm7
00007d07b35d56b0  vmovaps [rsp+0x70], xmm8
00007d07b35d56b6  vmovaps [rsp+0x80], xmm9
00007d07b35d56bf  vmovaps [rsp+0x90], xmm10
00007d07b35d56c8  vmovaps [rsp+0xA0], xmm11
00007d07b35d56d1  vmovaps [rsp+0xB0], xmm12
00007d07b35d56da  vmovaps [rsp+0xC0], xmm13
00007d07b35d56e3  vmovaps [rsp+0xD0], xmm14
00007d07b35d56ec  vmovaps [rsp+0xE0], xmm15
00007d07b35d56f5  sub rsp, 0x30
00007d07b35d56f9  movaps [rsp], xmm1
00007d07b35d56fd  movaps [rsp+0x10], xmm7
00007d07b35d5702  movaps [rsp+0x20], xmm11
00007d07b35d5708  lea rdi, [rsp]
00007d07b35d570c  mov esi, 0x00
00007d07b35d5711  mov rax, 0x5D0AA712D530
00007d07b35d571b  call rax
00007d07b35d571d  movaps xmm1, [rsp]
00007d07b35d5721  add rsp, 0x30
00007d07b35d5725  vmovaps xmm0, [rsp]
00007d07b35d572a  vmovaps xmm2, [rsp+0x10]
00007d07b35d5730  vmovaps xmm3, [rsp+0x20]
00007d07b35d5736  vmovaps xmm4, [rsp+0x30]
00007d07b35d573c  vmovaps xmm5, [rsp+0x40]
00007d07b35d5742  vmovaps xmm6, [rsp+0x50]
00007d07b35d5748  vmovaps xmm7, [rsp+0x60]
00007d07b35d574e  vmovaps xmm8, [rsp+0x70]
00007d07b35d5754  vmovaps xmm9, [rsp+0x80]
00007d07b35d575d  vmovaps xmm10, [rsp+0x90]
00007d07b35d5766  vmovaps xmm11, [rsp+0xA0]
00007d07b35d576f  vmovaps xmm12, [rsp+0xB0]
00007d07b35d5778  vmovaps xmm13, [rsp+0xC0]
00007d07b35d5781  vmovaps xmm14, [rsp+0xD0]
00007d07b35d578a  vmovaps xmm15, [rsp+0xE0]
00007d07b35d5793  add rsp, 0xF0
00007d07b35d579a  pop r11
00007d07b35d579c  pop r10
00007d07b35d579e  pop r9
00007d07b35d57a0  pop r8
00007d07b35d57a2  pop rsi
00007d07b35d57a3  pop rdi
00007d07b35d57a4  pop rdx
00007d07b35d57a5  pop rcx
00007d07b35d57a6  pop rax
00007d07b35d57a7  add rsp, 0x08
00007d07b35d57ab  jmp 0x00007D07B35D033B
00007d07b35d57b0  call 0x00007D07B340E880
00007d07b35d57b5  jmp 0x00007D07B35D034E
00007d07b35d57ba  call 0x00007D07B340C380
00007d07b35d57bf  jmp 0x00007D07B35D0359
00007d07b35d57c4  call 0x00007D07B340D600
00007d07b35d57c9  jmp 0x00007D07B35D0364
00007d07b35d57ce  call 0x00007D07B33FF540
00007d07b35d57d3  jmp 0x00007D07B35D036F
00007d07b35d57d8  int3
00007d07b35d57d9  nop [rax], eax
00007d07b35d57e0  mov rax, [r15+0x40]
00007d07b35d57e4  mov r14, [r15+0x58]
00007d07b35d57e8  lea r12, [rax+r14*1]
00007d07b35d57ec  movaps xmm1, [r15+0x1D0]
00007d07b35d57f4  vmovaps [rsp+0x10], xmm1
00007d07b35d57fa  vmovaps xmm15, [rsp+0x10]
00007d07b35d5800  por xmm1, xmm15
00007d07b35d5805  movaps xmm14, [r15+0x1A0]
00007d07b35d580d  vmovaps [rsp+0x10], xmm14
00007d07b35d5813  vmovaps xmm13, [rsp+0x10]
00007d07b35d5819  por xmm14, xmm13
00007d07b35d581e  lea rax, [r12+0x30]
00007d07b35d5823  mov r11, [r13+rax*1]
00007d07b35d5828  lea rax, [r12+0x38]
00007d07b35d582d  mov r10, [r13+rax*1]
00007d07b35d5832  movq xmm13, r11
00007d07b35d5837  movq xmm12, r10
00007d07b35d583c  movq xmm13, xmm13
00007d07b35d5841  vmovaps [rsp+0x10], xmm13
00007d07b35d5847  movq xmm13, xmm13
00007d07b35d584c  movaps [r15+0x130], xmm13
00007d07b35d5854  movq xmm12, xmm12
00007d07b35d5859  vmovaps [rsp+0x20], xmm12
00007d07b35d585f  movq xmm12, xmm12
00007d07b35d5864  movaps [r15+0x280], xmm12
00007d07b35d586c  movaps xmm13, [r15+0x270]
00007d07b35d5874  vmovaps [rsp+0x30], xmm13
00007d07b35d587a  vmovaps xmm12, [rsp+0x30]
00007d07b35d5880  por xmm13, xmm12
00007d07b35d5885  lea rax, [r12+0x20]
00007d07b35d588a  mov r11, [r13+rax*1]
00007d07b35d588f  lea rax, [r12+0x28]
00007d07b35d5894  mov r10, [r13+rax*1]
00007d07b35d5899  movq xmm12, r11
00007d07b35d589e  movq xmm11, r10
00007d07b35d58a3  movq xmm12, xmm12
00007d07b35d58a8  vmovaps [rsp+0x30], xmm12
00007d07b35d58ae  movq xmm12, xmm12
00007d07b35d58b3  movaps [r15+0x150], xmm12
00007d07b35d58bb  movq xmm11, xmm11
00007d07b35d58c0  vmovaps [rsp+0x40], xmm11
00007d07b35d58c6  movq xmm11, xmm11
00007d07b35d58cb  movaps [r15+0x140], xmm11
00007d07b35d58d3  lea rax, [r12+0x10]
00007d07b35d58d8  mov r11, [r13+rax*1]
00007d07b35d58dd  lea rax, [r12+0x18]
00007d07b35d58e2  mov r10, [r13+rax*1]
00007d07b35d58e7  movq xmm12, r11
00007d07b35d58ec  movq xmm11, r10
00007d07b35d58f1  movq xmm12, xmm12
00007d07b35d58f6  vmovaps [rsp+0x50], xmm12
00007d07b35d58fc  movq xmm12, xmm12
00007d07b35d5901  movaps [r15+0x170], xmm12
00007d07b35d5909  movq xmm11, xmm11
00007d07b35d590e  vmovaps [rsp+0x60], xmm11
00007d07b35d5914  movq xmm11, xmm11
00007d07b35d5919  movaps [r15+0x160], xmm11
00007d07b35d5921  mov rax, [r13+r12*1]
00007d07b35d5926  vmovq xmm12, rax
00007d07b35d592b  vpbroadcastq xmm12, xmm12
00007d07b35d5930  lea rax, [r12+0x08]
00007d07b35d5935  mov r12, [r13+rax*1]
00007d07b35d593a  movq xmm11, r12
00007d07b35d593f  movaps [r15+0x230], xmm11
00007d07b35d5947  mov rax, [r15+0xF8]
00007d07b35d594e  lea r12, [rax+0x50]
00007d07b35d5952  movups xmm11, [r13+r12*1]
00007d07b35d5958  lea r12, [rax+0x60]
00007d07b35d595c  movups xmm10, [r13+r12*1]
00007d07b35d5962  lea r12, [rax+0x30]
00007d07b35d5966  movups xmm9, [r13+r12*1]
00007d07b35d596c  mov r12, [r15+0x50]
00007d07b35d5970  lea r11, [r12+r14*1]
00007d07b35d5974  mov [r15+0x60], r11
00007d07b35d5978  lea r12, [r14+0x40]
00007d07b35d597c  mov [r15+0x58], r12
00007d07b35d5980  movaps xmm8, xmm12
00007d07b35d5984  mulpd xmm8, xmm15
00007d07b35d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007d07b35d598f  ptest xmm7, xmm7
00007d07b35d5994  jnz 0x00007D07B35D67B7
00007d07b35d599a  movq xmm15, qword ptr [r15+0x230]
00007d07b35d59a3  vmovaps [rsp+0x70], xmm15
00007d07b35d59a9  vpermilpd xmm15, xmm15, 0x00
00007d07b35d59af  movaps xmm7, xmm9
00007d07b35d59b3  mulpd xmm7, xmm15
00007d07b35d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007d07b35d59bd  ptest xmm6, xmm6
00007d07b35d59c2  jnz 0x00007D07B35D68FB
00007d07b35d59c8  vxorps xmm15, xmm15, xmm15
00007d07b35d59cd  vpbroadcastq xmm15, xmm15
00007d07b35d59d2  movaps xmm9, xmm12
00007d07b35d59d6  mulpd xmm9, xmm10
00007d07b35d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007d07b35d59e1  ptest xmm6, xmm6
00007d07b35d59e6  jnz 0x00007D07B35D6A3D
00007d07b35d59ec  movaps xmm10, xmm12
00007d07b35d59f0  mulpd xmm10, xmm11
00007d07b35d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d07b35d59fb  ptest xmm6, xmm6
00007d07b35d5a00  jnz 0x00007D07B35D6B81
00007d07b35d5a06  movaps xmm11, [r15+0x1F0]
00007d07b35d5a0e  movaps xmm6, xmm12
00007d07b35d5a12  mulpd xmm6, xmm11
00007d07b35d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007d07b35d5a1c  ptest xmm5, xmm5
00007d07b35d5a21  jnz 0x00007D07B35D6CC5
00007d07b35d5a27  movaps xmm12, [r15+0x2A0]
00007d07b35d5a2f  vmovaps [rsp+0x80], xmm12
00007d07b35d5a38  vmovaps xmm11, [rsp+0x80]
00007d07b35d5a41  por xmm12, xmm11
00007d07b35d5a46  movaps xmm11, [r15+0x250]
00007d07b35d5a4e  vmovaps [rsp+0x80], xmm11
00007d07b35d5a57  vmovaps xmm5, [rsp+0x80]
00007d07b35d5a60  por xmm11, xmm5
00007d07b35d5a65  vmovaps xmm4, [rsp+0x70]
00007d07b35d5a6b  vpermilpd xmm4, xmm4, 0x00
00007d07b35d5a71  movaps xmm3, xmm5
00007d07b35d5a74  mulpd xmm3, xmm4
00007d07b35d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007d07b35d5a7d  ptest xmm2, xmm2
00007d07b35d5a82  jnz 0x00007D07B35D6E07
00007d07b35d5a88  mov [rsp+0x80], rax
00007d07b35d5a90  xor eax, eax
00007d07b35d5a92  mov r14d, 0x200
00007d07b35d5a98  cmp r12, r14
00007d07b35d5a9b  cmc
00007d07b35d5a9c  lahf
00007d07b35d5a9d  seto al
00007d07b35d5aa0  mov [r15+0x108], eax
00007d07b35d5aa7  movaps xmm5, xmm8
00007d07b35d5aab  addpd xmm5, xmm15
00007d07b35d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007d07b35d5ab5  ptest xmm4, xmm4
00007d07b35d5aba  jnz 0x00007D07B35D6F47
00007d07b35d5ac0  movaps xmm8, [r15+0x1B0]
00007d07b35d5ac8  movaps xmm4, xmm9
00007d07b35d5acc  addpd xmm4, xmm8
00007d07b35d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007d07b35d5ad6  ptest xmm2, xmm2
00007d07b35d5adb  jnz 0x00007D07B35D7089
00007d07b35d5ae1  movaps xmm9, xmm10
00007d07b35d5ae5  addpd xmm9, xmm8
00007d07b35d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007d07b35d5af0  ptest xmm2, xmm2
00007d07b35d5af5  jnz 0x00007D07B35D71CB
00007d07b35d5afb  movaps xmm10, [r15+0x2F0]
00007d07b35d5b03  vmovaps [rsp+0x90], xmm10
00007d07b35d5b0c  vmovaps xmm8, [rsp+0x90]
00007d07b35d5b15  por xmm10, xmm8
00007d07b35d5b1a  movaps xmm8, [r15+0x2E0]
00007d07b35d5b22  vmovaps [rsp+0x90], xmm8
00007d07b35d5b2b  vmovaps xmm2, [rsp+0x90]
00007d07b35d5b34  por xmm8, xmm2
00007d07b35d5b39  movaps xmm2, [r15+0x2D0]
00007d07b35d5b41  vmovaps [rsp+0x90], xmm2
00007d07b35d5b4a  vmovaps [rsp+0xA0], xmm1
00007d07b35d5b53  vmovaps xmm1, [rsp+0x90]
00007d07b35d5b5c  por xmm2, xmm1
00007d07b35d5b60  movaps xmm1, [r15+0x200]
00007d07b35d5b68  vmovaps [rsp+0x90], xmm1
00007d07b35d5b71  vmovaps [rsp+0xB0], xmm15
00007d07b35d5b7a  vmovaps xmm15, [rsp+0x90]
00007d07b35d5b83  por xmm1, xmm15
00007d07b35d5b88  movaps xmm15, [r15+0x1C0]
00007d07b35d5b90  vmovaps [rsp+0x90], xmm15
00007d07b35d5b99  vmovaps [rsp+0xC0], xmm1
00007d07b35d5ba2  vmovaps xmm1, [rsp+0x90]
00007d07b35d5bab  por xmm15, xmm1
00007d07b35d5bb0  movaps xmm1, [r15+0x190]
00007d07b35d5bb8  vmovaps [rsp+0x90], xmm1
00007d07b35d5bc1  vmovaps [rsp+0xD0], xmm15
00007d07b35d5bca  vmovaps xmm15, [rsp+0x90]
00007d07b35d5bd3  por xmm1, xmm15
00007d07b35d5bd8  movaps xmm15, [r15+0x300]
00007d07b35d5be0  vmovaps [rsp+0x90], xmm15
00007d07b35d5be9  vmovaps [rsp+0xE0], xmm1
00007d07b35d5bf2  vmovaps xmm1, [rsp+0x90]
00007d07b35d5bfb  por xmm15, xmm1
00007d07b35d5c00  mov rax, [rsp+0x80]
00007d07b35d5c08  lea r14, [rax+0xA0]
00007d07b35d5c0f  movups xmm1, [r13+r14*1]
00007d07b35d5c15  lea r14, [rax+0xB0]
00007d07b35d5c1c  vmovaps [rsp+0x80], xmm1
00007d07b35d5c25  movups xmm1, [r13+r14*1]
00007d07b35d5c2b  vmovaps [rsp+0x90], xmm1
00007d07b35d5c34  vmovaps [rsp+0xF0], xmm15
00007d07b35d5c3d  vmovaps xmm15, [rsp+0xB0]
00007d07b35d5c46  vmovaps [rsp+0xB0], xmm14
00007d07b35d5c4f  movaps xmm1, xmm6
00007d07b35d5c52  addpd xmm1, xmm15
00007d07b35d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007d07b35d5c5c  ptest xmm14, xmm14
00007d07b35d5c62  jnz 0x00007D07B35D7323
00007d07b35d5c68  lea r14, [rax+0xF0]
00007d07b35d5c6f  movups xmm15, [r13+r14*1]
00007d07b35d5c75  movaps xmm14, xmm4
00007d07b35d5c79  addpd xmm14, xmm3
00007d07b35d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007d07b35d5c84  ptest xmm6, xmm6
00007d07b35d5c89  jnz 0x00007D07B35D746E
00007d07b35d5c8f  movaps xmm6, xmm9
00007d07b35d5c93  addpd xmm6, xmm7
00007d07b35d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007d07b35d5c9c  ptest xmm4, xmm4
00007d07b35d5ca1  jnz 0x00007D07B35D75B0
00007d07b35d5ca7  vmovaps xmm9, [rsp+0x70]
00007d07b35d5cad  vpermilpd xmm9, xmm9, 0x00
00007d07b35d5cb3  vmovaps xmm4, [rsp+0x90]
00007d07b35d5cbc  movaps xmm7, xmm4
00007d07b35d5cbf  mulpd xmm7, xmm9
00007d07b35d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007d07b35d5cc9  ptest xmm3, xmm3
00007d07b35d5cce  jnz 0x00007D07B35D76F1
00007d07b35d5cd4  vmovaps xmm9, [rsp+0x50]
00007d07b35d5cda  vpermilpd xmm9, xmm9, 0x00
00007d07b35d5ce0  movaps xmm4, xmm15
00007d07b35d5ce4  mulpd xmm4, xmm9
00007d07b35d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007d07b35d5cee  ptest xmm3, xmm3
00007d07b35d5cf3  jnz 0x00007D07B35D7832
00007d07b35d5cf9  lea r14, [rax+0xE0]
00007d07b35d5d00  movups xmm15, [r13+r14*1]
00007d07b35d5d06  vmovaps xmm9, [rsp+0x70]
00007d07b35d5d0c  vpermilpd xmm9, xmm9, 0x00
00007d07b35d5d12  vmovaps [rsp+0x70], xmm1
00007d07b35d5d18  vmovaps xmm1, [rsp+0x80]
00007d07b35d5d21  vmovaps [rsp+0x80], xmm15
00007d07b35d5d2a  movaps xmm3, xmm1
00007d07b35d5d2d  mulpd xmm3, xmm9
00007d07b35d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007d07b35d5d37  ptest xmm15, xmm15
00007d07b35d5d3d  jnz 0x00007D07B35D797E
00007d07b35d5d43  vmovaps xmm1, [rsp+0xF0]
00007d07b35d5d4c  vmovaps xmm15, [rsp+0xF0]
00007d07b35d5d55  por xmm1, xmm15
00007d07b35d5d5a  movaps [r15+0x300], xmm1
00007d07b35d5d62  vmovaps xmm15, [rsp+0xE0]
00007d07b35d5d6b  vmovaps xmm9, [rsp+0xE0]
00007d07b35d5d74  por xmm15, xmm9
00007d07b35d5d79  movaps [r15+0x190], xmm15
00007d07b35d5d81  vmovaps xmm9, [rsp+0x50]
00007d07b35d5d87  vpermilpd xmm9, xmm9, 0x00
00007d07b35d5d8d  vmovaps [rsp+0x90], xmm1
00007d07b35d5d96  vmovaps [rsp+0xE0], xmm15
00007d07b35d5d9f  vmovaps xmm15, [rsp+0x80]
00007d07b35d5da8  vmovaps [rsp+0x80], xmm14
00007d07b35d5db1  movaps xmm1, xmm15
00007d07b35d5db5  mulpd xmm1, xmm9
00007d07b35d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007d07b35d5dbf  ptest xmm14, xmm14
00007d07b35d5dc5  jnz 0x00007D07B35D7ABF
00007d07b35d5dcb  lea r14, [rax+0x90]
00007d07b35d5dd2  movups xmm15, [r13+r14*1]
00007d07b35d5dd8  vmovaps xmm14, [rsp+0xD0]
00007d07b35d5de1  vmovaps xmm9, [rsp+0xD0]
00007d07b35d5dea  por xmm14, xmm9
00007d07b35d5def  movaps [r15+0x1C0], xmm14
00007d07b35d5df7  vmovaps xmm9, [rsp+0xC0]
00007d07b35d5e00  vmovaps [rsp+0xD0], xmm1
00007d07b35d5e09  vmovaps xmm1, [rsp+0xC0]
00007d07b35d5e12  por xmm9, xmm1
00007d07b35d5e17  movaps [r15+0x200], xmm9
00007d07b35d5e1f  vmovaps [rsp+0xC0], xmm2
00007d07b35d5e28  vmovaps xmm1, [rsp+0xC0]
00007d07b35d5e31  por xmm2, xmm1
00007d07b35d5e35  movaps [r15+0x2D0], xmm2
00007d07b35d5e3d  vmovaps [rsp+0xC0], xmm8
00007d07b35d5e46  vmovaps xmm1, [rsp+0xC0]
00007d07b35d5e4f  por xmm8, xmm1
00007d07b35d5e54  movaps [r15+0x2E0], xmm8
00007d07b35d5e5c  vmovaps [rsp+0xC0], xmm15
00007d07b35d5e65  movaps xmm1, xmm5
00007d07b35d5e68  addpd xmm1, xmm7
00007d07b35d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007d07b35d5e71  ptest xmm15, xmm15
00007d07b35d5e77  jnz 0x00007D07B35D7C0B
00007d07b35d5e7d  vmovaps xmm15, [rsp+0x50]
00007d07b35d5e83  vpermilpd xmm15, xmm15, 0x00
00007d07b35d5e89  vmovaps xmm5, [rsp+0xC0]
00007d07b35d5e92  vmovaps [rsp+0xC0], xmm1
00007d07b35d5e9b  movaps xmm7, xmm5
00007d07b35d5e9e  mulpd xmm7, xmm15
00007d07b35d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007d07b35d5ea8  ptest xmm1, xmm1
00007d07b35d5ead  jnz 0x00007D07B35D7D4B
00007d07b35d5eb3  lea r14, [rax+0x80]
00007d07b35d5eba  movups xmm1, [r13+r14*1]
00007d07b35d5ec0  vmovaps xmm5, [rsp+0x70]
00007d07b35d5ec6  vmovaps [rsp+0x70], xmm1
00007d07b35d5ecc  movaps xmm15, xmm5
00007d07b35d5ed0  addpd xmm15, xmm3
00007d07b35d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d07b35d5edb  ptest xmm1, xmm1
00007d07b35d5ee0  jnz 0x00007D07B35D7E96
00007d07b35d5ee6  vmovaps xmm5, [rsp+0x80]
00007d07b35d5eef  movaps xmm1, xmm5
00007d07b35d5ef2  addpd xmm1, xmm4
00007d07b35d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007d07b35d5efb  ptest xmm3, xmm3
00007d07b35d5f00  jnz 0x00007D07B35D7FD8
00007d07b35d5f06  vmovaps [rsp+0x80], xmm10
00007d07b35d5f0f  vmovaps xmm5, [rsp+0x80]
00007d07b35d5f18  por xmm10, xmm5
00007d07b35d5f1d  movaps [r15+0x2F0], xmm10
00007d07b35d5f25  vmovaps xmm5, [rsp+0x50]
00007d07b35d5f2b  vpermilpd xmm5, xmm5, 0x00
00007d07b35d5f31  vmovaps xmm3, [rsp+0x70]
00007d07b35d5f37  vmovaps [rsp+0x50], xmm1
00007d07b35d5f3d  movaps xmm4, xmm3
00007d07b35d5f40  mulpd xmm4, xmm5
00007d07b35d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007d07b35d5f49  ptest xmm1, xmm1
00007d07b35d5f4e  jnz 0x00007D07B35D8118
00007d07b35d5f54  lea r14, [rax+0xD0]
00007d07b35d5f5b  movups xmm1, [r13+r14*1]
00007d07b35d5f61  vmovaps xmm3, [rsp+0xD0]
00007d07b35d5f6a  vmovaps [rsp+0x70], xmm1
00007d07b35d5f70  movaps xmm5, xmm6
00007d07b35d5f73  addpd xmm5, xmm3
00007d07b35d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007d07b35d5f7c  ptest xmm1, xmm1
00007d07b35d5f81  jnz 0x00007D07B35D8262
00007d07b35d5f87  vmovaps xmm1, [rsp+0x60]
00007d07b35d5f8d  vpermilpd xmm1, xmm1, 0x00
00007d07b35d5f93  movaps xmm6, xmm9
00007d07b35d5f97  mulpd xmm6, xmm1
00007d07b35d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007d07b35d5fa0  ptest xmm3, xmm3
00007d07b35d5fa5  jnz 0x00007D07B35D83A2
00007d07b35d5fab  movaps [r15+0x260], xmm6
00007d07b35d5fb3  vxorps xmm1, xmm1, xmm1
00007d07b35d5fb7  vpbroadcastq xmm1, xmm1
00007d07b35d5fbc  movaps [r15+0x1B0], xmm1
00007d07b35d5fc4  vmovaps xmm1, [rsp+0x60]
00007d07b35d5fca  vpermilpd xmm1, xmm1, 0x00
00007d07b35d5fd0  vmovaps xmm3, [rsp+0x70]
00007d07b35d5fd6  vmovaps [rsp+0x70], xmm15
00007d07b35d5fdc  movaps xmm9, xmm3
00007d07b35d5fe0  mulpd xmm9, xmm1
00007d07b35d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007d07b35d5feb  ptest xmm15, xmm15
00007d07b35d5ff1  jnz 0x00007D07B35D84E3
00007d07b35d5ff7  lea r14, [rax+0xC0]
00007d07b35d5ffe  movups xmm1, [r13+r14*1]
00007d07b35d6004  vmovaps xmm3, [rsp+0xC0]
00007d07b35d600d  vmovaps [rsp+0x80], xmm1
00007d07b35d6016  movaps xmm15, xmm3
00007d07b35d601a  addpd xmm15, xmm7
00007d07b35d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007d07b35d6025  ptest xmm1, xmm1
00007d07b35d602a  jnz 0x00007D07B35D862F
00007d07b35d6030  vmovaps [rsp+0xC0], xmm13
00007d07b35d6039  vmovaps xmm1, [rsp+0xC0]
00007d07b35d6042  por xmm13, xmm1
00007d07b35d6047  movaps [r15+0x270], xmm13
00007d07b35d604f  vmovaps xmm1, [rsp+0xB0]
00007d07b35d6058  vmovaps xmm7, [rsp+0xB0]
00007d07b35d6061  por xmm1, xmm7
00007d07b35d6065  movaps [r15+0x1A0], xmm1
00007d07b35d606d  vmovaps xmm1, [rsp+0x60]
00007d07b35d6073  vpermilpd xmm1, xmm1, 0x00
00007d07b35d6079  vmovaps [rsp+0xB0], xmm1
00007d07b35d6082  vmovaps xmm1, [rsp+0x80]
00007d07b35d608b  vmovaps [rsp+0x80], xmm15
00007d07b35d6094  vmovaps xmm15, [rsp+0xB0]
00007d07b35d609d  vmovaps [rsp+0xB0], xmm14
00007d07b35d60a6  movaps xmm3, xmm1
00007d07b35d60a9  mulpd xmm3, xmm15
00007d07b35d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007d07b35d60b3  ptest xmm14, xmm14
00007d07b35d60b9  jnz 0x00007D07B35D8771
00007d07b35d60bf  lea r14, [rax+0x20]
00007d07b35d60c3  movups xmm1, [r13+r14*1]
00007d07b35d60c9  movaps [r15+0x110], xmm1
00007d07b35d60d1  vmovaps xmm14, [rsp+0x70]
00007d07b35d60d7  vmovaps [rsp+0x70], xmm1
00007d07b35d60dd  movaps xmm15, xmm14
00007d07b35d60e1  addpd xmm15, xmm4
00007d07b35d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007d07b35d60ec  ptest xmm1, xmm1
00007d07b35d60f1  jnz 0x00007D07B35D88BC
00007d07b35d60f7  vmovaps xmm1, [rsp+0x60]
00007d07b35d60fd  vpermilpd xmm1, xmm1, 0x00
00007d07b35d6103  movaps xmm14, xmm2
00007d07b35d6107  mulpd xmm14, xmm1
00007d07b35d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007d07b35d6112  ptest xmm4, xmm4
00007d07b35d6117  jnz 0x00007D07B35D89FF
00007d07b35d611d  vmovaps xmm4, [rsp+0x50]
00007d07b35d6123  movaps xmm1, xmm4
00007d07b35d6126  addpd xmm1, xmm9
00007d07b35d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d07b35d6130  ptest xmm2, xmm2
00007d07b35d6135  jnz 0x00007D07B35D8B41
00007d07b35d613b  vmovaps xmm9, [rsp+0x30]
00007d07b35d6141  vpermilpd xmm9, xmm9, 0x00
00007d07b35d6147  vmovaps xmm2, [rsp+0x70]
00007d07b35d614d  vmovaps [rsp+0x50], xmm1
00007d07b35d6153  movaps xmm4, xmm2
00007d07b35d6156  mulpd xmm4, xmm9
00007d07b35d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007d07b35d6160  ptest xmm1, xmm1
00007d07b35d6165  jnz 0x00007D07B35D8C82
00007d07b35d616b  vmovaps xmm1, [rsp+0x30]
00007d07b35d6171  vpermilpd xmm1, xmm1, 0x00
00007d07b35d6177  vmovaps xmm2, [rsp+0x90]
00007d07b35d6180  vmovaps [rsp+0x60], xmm15
00007d07b35d6186  movaps xmm9, xmm2
00007d07b35d618a  mulpd xmm9, xmm1
00007d07b35d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007d07b35d6195  ptest xmm15, xmm15
00007d07b35d619b  jnz 0x00007D07B35D8DC3
00007d07b35d61a1  vmovaps xmm15, [rsp+0x80]
00007d07b35d61aa  movaps xmm1, xmm15
00007d07b35d61ae  addpd xmm1, xmm6
00007d07b35d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007d07b35d61b7  ptest xmm2, xmm2
00007d07b35d61bc  jnz 0x00007D07B35D8F05
00007d07b35d61c2  movaps xmm15, xmm5
00007d07b35d61c6  addpd xmm15, xmm3
00007d07b35d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007d07b35d61d1  ptest xmm6, xmm6
00007d07b35d61d6  jnz 0x00007D07B35D9046
00007d07b35d61dc  vmovaps xmm6, [rsp+0x30]
00007d07b35d61e2  vpermilpd xmm6, xmm6, 0x00
00007d07b35d61e8  movaps xmm5, xmm8
00007d07b35d61ec  mulpd xmm5, xmm6
00007d07b35d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007d07b35d61f5  ptest xmm3, xmm3
00007d07b35d61fa  jnz 0x00007D07B35D9188
00007d07b35d6200  vmovaps xmm8, [rsp+0x30]
00007d07b35d6206  vpermilpd xmm8, xmm8, 0x00
00007d07b35d620c  movaps xmm6, xmm10
00007d07b35d6210  mulpd xmm6, xmm8
00007d07b35d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007d07b35d621a  ptest xmm3, xmm3
00007d07b35d621f  jnz 0x00007D07B35D92C9
00007d07b35d6225  vmovaps xmm8, [rsp+0x60]
00007d07b35d622b  movaps xmm10, xmm8
00007d07b35d622f  addpd xmm10, xmm14
00007d07b35d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007d07b35d623a  ptest xmm3, xmm3
00007d07b35d623f  jnz 0x00007D07B35D940B
00007d07b35d6245  vmovaps xmm8, [rsp+0x50]
00007d07b35d624b  movaps xmm14, xmm8
00007d07b35d624f  addpd xmm14, xmm4
00007d07b35d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007d07b35d625a  ptest xmm3, xmm3
00007d07b35d625f  jnz 0x00007D07B35D954F
00007d07b35d6265  vmovaps xmm8, [rsp+0x40]
00007d07b35d626b  vpermilpd xmm8, xmm8, 0x00
00007d07b35d6271  movaps xmm4, xmm13
00007d07b35d6275  mulpd xmm4, xmm8
00007d07b35d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007d07b35d627f  ptest xmm3, xmm3
00007d07b35d6284  jnz 0x00007D07B35D9692
00007d07b35d628a  movaps xmm13, xmm15
00007d07b35d628e  addpd xmm13, xmm9
00007d07b35d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007d07b35d6299  ptest xmm8, xmm8
00007d07b35d629f  jnz 0x00007D07B35D97D4
00007d07b35d62a5  movaps xmm15, xmm1
00007d07b35d62a9  addpd xmm15, xmm5
00007d07b35d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007d07b35d62b4  ptest xmm9, xmm9
00007d07b35d62ba  jnz 0x00007D07B35D9918
00007d07b35d62c0  vmovaps [rsp+0x30], xmm11
00007d07b35d62c6  vmovaps xmm1, [rsp+0x30]
00007d07b35d62cc  por xmm11, xmm1
00007d07b35d62d1  movaps [r15+0x250], xmm11
00007d07b35d62d9  vmovaps [rsp+0x30], xmm12
00007d07b35d62df  vmovaps xmm1, [rsp+0x30]
00007d07b35d62e5  por xmm12, xmm1
00007d07b35d62ea  movaps [r15+0x2A0], xmm12
00007d07b35d62f2  vmovaps xmm1, [rsp+0xA0]
00007d07b35d62fb  vmovaps xmm11, [rsp+0xA0]
00007d07b35d6304  por xmm1, xmm11
00007d07b35d6309  movaps [r15+0x1D0], xmm1
00007d07b35d6311  lea r14, [rax+0x40]
00007d07b35d6315  movups xmm1, [r13+r14*1]
00007d07b35d631b  movaps [r15+0x2C0], xmm1
00007d07b35d6323  vmovaps xmm11, [rsp+0x40]
00007d07b35d6329  vpermilpd xmm11, xmm11, 0x00
00007d07b35d632f  vmovaps xmm8, [rsp+0xE0]
00007d07b35d6338  movaps xmm9, xmm8
00007d07b35d633c  mulpd xmm9, xmm11
00007d07b35d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007d07b35d6347  ptest xmm5, xmm5
00007d07b35d634c  jnz 0x00007D07B35D9A64
00007d07b35d6352  movaps xmm11, xmm10
00007d07b35d6356  addpd xmm11, xmm6
00007d07b35d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007d07b35d6361  ptest xmm8, xmm8
00007d07b35d6367  jnz 0x00007D07B35D9BA8
00007d07b35d636d  movaps xmm10, xmm14
00007d07b35d6371  addpd xmm10, xmm4
00007d07b35d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007d07b35d637c  ptest xmm8, xmm8
00007d07b35d6382  jnz 0x00007D07B35D9CEB
00007d07b35d6388  vmovaps xmm14, [rsp+0x40]
00007d07b35d638e  vpermilpd xmm14, xmm14, 0x00
00007d07b35d6394  movaps xmm8, xmm1
00007d07b35d6398  mulpd xmm8, xmm14
00007d07b35d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007d07b35d63a3  ptest xmm6, xmm6
00007d07b35d63a8  jnz 0x00007D07B35D9E2E
00007d07b35d63ae  movaps xmm1, [r15+0x2B0]
00007d07b35d63b6  vmovaps xmm14, [rsp+0x40]
00007d07b35d63bc  vpermilpd xmm14, xmm14, 0x00
00007d07b35d63c2  movaps xmm6, xmm1
00007d07b35d63c5  mulpd xmm6, xmm14
00007d07b35d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007d07b35d63cf  ptest xmm5, xmm5
00007d07b35d63d4  jnz 0x00007D07B35D9F71
00007d07b35d63da  vmovaps xmm1, [rsp+0x10]
00007d07b35d63e0  vpermilpd xmm1, xmm1, 0x00
00007d07b35d63e6  movaps xmm14, xmm12
00007d07b35d63ea  mulpd xmm14, xmm1
00007d07b35d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007d07b35d63f5  ptest xmm5, xmm5
00007d07b35d63fa  jnz 0x00007D07B35DA0B2
00007d07b35d6400  movaps xmm1, xmm13
00007d07b35d6404  addpd xmm1, xmm9
00007d07b35d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007d07b35d640e  ptest xmm12, xmm12
00007d07b35d6414  jnz 0x00007D07B35DA1F5
00007d07b35d641a  vmovaps xmm13, [rsp+0x10]
00007d07b35d6420  vpermilpd xmm13, xmm13, 0x00
00007d07b35d6426  movaps xmm12, xmm7
00007d07b35d642a  mulpd xmm12, xmm13
00007d07b35d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007d07b35d6435  ptest xmm9, xmm9
00007d07b35d643b  jnz 0x00007D07B35DA337
00007d07b35d6441  movaps xmm13, xmm15
00007d07b35d6445  addpd xmm13, xmm8
00007d07b35d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007d07b35d6450  ptest xmm9, xmm9
00007d07b35d6456  jnz 0x00007D07B35DA47A
00007d07b35d645c  movaps xmm15, [r15+0x290]
00007d07b35d6464  vmovaps xmm9, [rsp+0x10]
00007d07b35d646a  vpermilpd xmm9, xmm9, 0x00
00007d07b35d6470  movaps xmm8, xmm15
00007d07b35d6474  mulpd xmm8, xmm9
00007d07b35d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007d07b35d647f  ptest xmm7, xmm7
00007d07b35d6484  jnz 0x00007D07B35DA5BE
00007d07b35d648a  movaps xmm15, xmm11
00007d07b35d648e  addpd xmm15, xmm6
00007d07b35d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007d07b35d6499  ptest xmm9, xmm9
00007d07b35d649f  jnz 0x00007D07B35DA702
00007d07b35d64a5  movaps xmm11, [r15+0x1E0]
00007d07b35d64ad  vmovaps xmm9, [rsp+0x10]
00007d07b35d64b3  vpermilpd xmm9, xmm9, 0x00
00007d07b35d64b9  movaps xmm7, xmm11
00007d07b35d64bd  mulpd xmm7, xmm9
00007d07b35d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007d07b35d64c7  ptest xmm6, xmm6
00007d07b35d64cc  jnz 0x00007D07B35DA845
00007d07b35d64d2  movaps xmm11, xmm10
00007d07b35d64d6  addpd xmm11, xmm14
00007d07b35d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007d07b35d64e1  ptest xmm9, xmm9
00007d07b35d64e7  jnz 0x00007D07B35DA987
00007d07b35d64ed  lea r14, [rax+0x70]
00007d07b35d64f1  movups xmm14, [r13+r14*1]
00007d07b35d64f7  movaps [r15+0x240], xmm14
00007d07b35d64ff  movaps xmm10, xmm1
00007d07b35d6503  addpd xmm10, xmm12
00007d07b35d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007d07b35d650e  ptest xmm9, xmm9
00007d07b35d6514  jnz 0x00007D07B35DAAD5
00007d07b35d651a  movaps [r15+0x170], xmm10
00007d07b35d6522  vmovaps xmm1, [rsp+0x20]
00007d07b35d6528  vpermilpd xmm1, xmm1, 0x00
00007d07b35d652e  movaps xmm12, xmm14
00007d07b35d6532  mulpd xmm12, xmm1
00007d07b35d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007d07b35d653d  ptest xmm9, xmm9
00007d07b35d6543  jnz 0x00007D07B35DAC18
00007d07b35d6549  vmovaps xmm1, [rsp+0x20]
00007d07b35d654f  vpermilpd xmm1, xmm1, 0x00
00007d07b35d6555  vmovaps xmm9, [rsp+0xB0]
00007d07b35d655e  movaps xmm14, xmm9
00007d07b35d6562  mulpd xmm14, xmm1
00007d07b35d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007d07b35d656d  ptest xmm6, xmm6
00007d07b35d6572  jnz 0x00007D07B35DAD5B
00007d07b35d6578  movaps [r15+0x180], xmm14
00007d07b35d6580  movaps xmm1, xmm13
00007d07b35d6584  addpd xmm1, xmm8
00007d07b35d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007d07b35d658e  ptest xmm9, xmm9
00007d07b35d6594  jnz 0x00007D07B35DAE9E
00007d07b35d659a  movaps [r15+0x210], xmm1
00007d07b35d65a2  movups xmm13, [r13+rax*1]
00007d07b35d65a8  lea r14, [rax+0x10]
00007d07b35d65ac  movups xmm9, [r13+r14*1]
00007d07b35d65b2  movaps [r15+0x230], xmm9
00007d07b35d65ba  movaps xmm8, xmm15
00007d07b35d65be  addpd xmm8, xmm7
00007d07b35d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007d07b35d65c9  ptest xmm6, xmm6
00007d07b35d65ce  jnz 0x00007D07B35DAFF4
00007d07b35d65d4  movaps [r15+0x130], xmm8
00007d07b35d65dc  vmovaps xmm15, [rsp+0x20]
00007d07b35d65e2  vpermilpd xmm15, xmm15, 0x00
00007d07b35d65e8  movaps xmm7, xmm9
00007d07b35d65ec  mulpd xmm7, xmm15
00007d07b35d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007d07b35d65f6  ptest xmm6, xmm6
00007d07b35d65fb  jnz 0x00007D07B35DB137
00007d07b35d6601  movaps [r15+0x220], xmm7
00007d07b35d6609  vmovaps xmm15, [rsp+0x20]
00007d07b35d660f  vpermilpd xmm15, xmm15, 0x00
00007d07b35d6615  movaps xmm9, xmm13
00007d07b35d6619  mulpd xmm9, xmm15
00007d07b35d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007d07b35d6624  ptest xmm6, xmm6
00007d07b35d6629  jnz 0x00007D07B35DB279
00007d07b35d662f  movaps xmm15, xmm11
00007d07b35d6633  addpd xmm15, xmm12
00007d07b35d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007d07b35d663e  ptest xmm13, xmm13
00007d07b35d6644  jnz 0x00007D07B35DB3BD
00007d07b35d664a  movaps [r15+0x140], xmm15
00007d07b35d6652  movaps xmm13, xmm10
00007d07b35d6656  addpd xmm13, xmm14
00007d07b35d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007d07b35d6661  ptest xmm12, xmm12
00007d07b35d6667  jnz 0x00007D07B35DB501
00007d07b35d666d  movaps [r15+0x150], xmm13
00007d07b35d6675  movaps xmm14, xmm1
00007d07b35d6679  addpd xmm14, xmm7
00007d07b35d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007d07b35d6684  ptest xmm12, xmm12
00007d07b35d668a  jnz 0x00007D07B35DB645
00007d07b35d6690  movaps [r15+0x160], xmm14
00007d07b35d6698  movaps xmm1, xmm8
00007d07b35d669c  addpd xmm1, xmm9
00007d07b35d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007d07b35d66a6  ptest xmm12, xmm12
00007d07b35d66ac  jnz 0x00007D07B35DB787
00007d07b35d66b2  movaps [r15+0x120], xmm1
00007d07b35d66ba  movups [r13+r11*1], xmm15
00007d07b35d66c0  lea rax, [r11+0x10]
00007d07b35d66c4  movups [r13+rax*1], xmm13
00007d07b35d66ca  lea rax, [r11+0x20]
00007d07b35d66ce  movups [r13+rax*1], xmm14
00007d07b35d66d4  lea rax, [r11+0x30]
00007d07b35d66d8  movups [r13+rax*1], xmm1
00007d07b35d66de  mov eax, [r15+0x108]
00007d07b35d66e5  sahf
00007d07b35d66e6  jnz 0x00007D07B35D6718
00007d07b35d66e8  cmp dword ptr [r15+0x318], 0x00
00007d07b35d66f0  jz 0x00007D07B35DB900
00007d07b35d66f6  nop [rax+rax*1], ax
00007d07b35d66ff  nop [rax+rax*1], eax
00007d07b35d6707  mov eax, 0x410444
00007d07b35d670c  mov [r15+0x100], rax
00007d07b35d6713  jmp 0x00007D07B33FE110
00007d07b35d6718  cmp dword ptr [r15+0x318], 0x00
00007d07b35d6720  jz 0x00007D07B35D57E0
00007d07b35d6726  nop [rax+rax*1], ax
00007d07b35d672f  nop [rax+rax*1], eax
00007d07b35d6737  mov eax, 0x410278
00007d07b35d673c  mov [r15+0x100], rax
00007d07b35d6743  jmp 0x00007D07B33FE110
00007d07b35d6748  int3
00007d07b35d6749  call 0x00007D07B340A4B0
00007d07b35d674e  jmp 0x00007D07B35D5828
00007d07b35d6753  call 0x00007D07B3409240
00007d07b35d6758  jmp 0x00007D07B35D5832
00007d07b35d675d  call 0x00007D07B340A4B0
00007d07b35d6762  jmp 0x00007D07B35D588F
00007d07b35d6767  call 0x00007D07B3409240
00007d07b35d676c  jmp 0x00007D07B35D5899
00007d07b35d6771  call 0x00007D07B340A4B0
00007d07b35d6776  jmp 0x00007D07B35D58DD
00007d07b35d677b  call 0x00007D07B3409240
00007d07b35d6780  jmp 0x00007D07B35D58E7
00007d07b35d6785  call 0x00007D07B34B47C0
00007d07b35d678a  jmp 0x00007D07B35D5926
00007d07b35d678f  call 0x00007D07B340B720
00007d07b35d6794  jmp 0x00007D07B35D593A
00007d07b35d6799  call 0x00007D07B34BFC30
00007d07b35d679e  jmp 0x00007D07B35D5958
00007d07b35d67a3  call 0x00007D07B34BE9C0
00007d07b35d67a8  jmp 0x00007D07B35D5962
00007d07b35d67ad  call 0x00007D07B34BD750
00007d07b35d67b2  jmp 0x00007D07B35D596C
00007d07b35d67b7  sub rsp, 0x08
00007d07b35d67bb  push rax
00007d07b35d67bc  push rcx
00007d07b35d67bd  push rdx
00007d07b35d67be  push rdi
00007d07b35d67bf  push rsi
00007d07b35d67c0  push r8
00007d07b35d67c2  push r9
00007d07b35d67c4  push r10
00007d07b35d67c6  push r11
00007d07b35d67c8  sub rsp, 0xF0
00007d07b35d67cf  vmovaps [rsp], xmm0
00007d07b35d67d4  vmovaps [rsp+0x10], xmm1
00007d07b35d67da  vmovaps [rsp+0x20], xmm2
00007d07b35d67e0  vmovaps [rsp+0x30], xmm3
00007d07b35d67e6  vmovaps [rsp+0x40], xmm4
00007d07b35d67ec  vmovaps [rsp+0x50], xmm5
00007d07b35d67f2  vmovaps [rsp+0x60], xmm6
00007d07b35d67f8  vmovaps [rsp+0x70], xmm7
00007d07b35d67fe  vmovaps [rsp+0x80], xmm9
00007d07b35d6807  vmovaps [rsp+0x90], xmm10
00007d07b35d6810  vmovaps [rsp+0xA0], xmm11
00007d07b35d6819  vmovaps [rsp+0xB0], xmm12
00007d07b35d6822  vmovaps [rsp+0xC0], xmm13
00007d07b35d682b  vmovaps [rsp+0xD0], xmm14
00007d07b35d6834  vmovaps [rsp+0xE0], xmm15
00007d07b35d683d  sub rsp, 0x30
00007d07b35d6841  movaps [rsp], xmm8
00007d07b35d6846  movaps [rsp+0x10], xmm12
00007d07b35d684c  movaps [rsp+0x20], xmm15
00007d07b35d6852  lea rdi, [rsp]
00007d07b35d6856  mov esi, 0x00
00007d07b35d685b  mov rax, 0x5D0AA712D530
00007d07b35d6865  call rax
00007d07b35d6867  movaps xmm8, [rsp]
00007d07b35d686c  add rsp, 0x30
00007d07b35d6870  vmovaps xmm0, [rsp]
00007d07b35d6875  vmovaps xmm1, [rsp+0x10]
00007d07b35d687b  vmovaps xmm2, [rsp+0x20]
00007d07b35d6881  vmovaps xmm3, [rsp+0x30]
00007d07b35d6887  vmovaps xmm4, [rsp+0x40]
00007d07b35d688d  vmovaps xmm5, [rsp+0x50]
00007d07b35d6893  vmovaps xmm6, [rsp+0x60]
00007d07b35d6899  vmovaps xmm7, [rsp+0x70]
00007d07b35d689f  vmovaps xmm9, [rsp+0x80]
00007d07b35d68a8  vmovaps xmm10, [rsp+0x90]
00007d07b35d68b1  vmovaps xmm11, [rsp+0xA0]
00007d07b35d68ba  vmovaps xmm12, [rsp+0xB0]
00007d07b35d68c3  vmovaps xmm13, [rsp+0xC0]
00007d07b35d68cc  vmovaps xmm14, [rsp+0xD0]
00007d07b35d68d5  vmovaps xmm15, [rsp+0xE0]
00007d07b35d68de  add rsp, 0xF0
00007d07b35d68e5  pop r11
00007d07b35d68e7  pop r10
00007d07b35d68e9  pop r9
00007d07b35d68eb  pop r8
00007d07b35d68ed  pop rsi
00007d07b35d68ee  pop rdi
00007d07b35d68ef  pop rdx
00007d07b35d68f0  pop rcx
00007d07b35d68f1  pop rax
00007d07b35d68f2  add rsp, 0x08
00007d07b35d68f6  jmp 0x00007D07B35D599A
00007d07b35d68fb  sub rsp, 0x08
00007d07b35d68ff  push rax
00007d07b35d6900  push rcx
00007d07b35d6901  push rdx
00007d07b35d6902  push rdi
00007d07b35d6903  push rsi
00007d07b35d6904  push r8
00007d07b35d6906  push r9
00007d07b35d6908  push r10
00007d07b35d690a  push r11
00007d07b35d690c  sub rsp, 0xF0
00007d07b35d6913  vmovaps [rsp], xmm0
00007d07b35d6918  vmovaps [rsp+0x10], xmm1
00007d07b35d691e  vmovaps [rsp+0x20], xmm2
00007d07b35d6924  vmovaps [rsp+0x30], xmm3
00007d07b35d692a  vmovaps [rsp+0x40], xmm4
00007d07b35d6930  vmovaps [rsp+0x50], xmm5
00007d07b35d6936  vmovaps [rsp+0x60], xmm6
00007d07b35d693c  vmovaps [rsp+0x70], xmm8
00007d07b35d6942  vmovaps [rsp+0x80], xmm9
00007d07b35d694b  vmovaps [rsp+0x90], xmm10
00007d07b35d6954  vmovaps [rsp+0xA0], xmm11
00007d07b35d695d  vmovaps [rsp+0xB0], xmm12
00007d07b35d6966  vmovaps [rsp+0xC0], xmm13
00007d07b35d696f  vmovaps [rsp+0xD0], xmm14
00007d07b35d6978  vmovaps [rsp+0xE0], xmm15
00007d07b35d6981  sub rsp, 0x30
00007d07b35d6985  movaps [rsp], xmm7
00007d07b35d6989  movaps [rsp+0x10], xmm9
00007d07b35d698f  movaps [rsp+0x20], xmm15
00007d07b35d6995  lea rdi, [rsp]
00007d07b35d6999  mov esi, 0x00
00007d07b35d699e  mov rax, 0x5D0AA712D530
00007d07b35d69a8  call rax
00007d07b35d69aa  movaps xmm7, [rsp]
00007d07b35d69ae  add rsp, 0x30
00007d07b35d69b2  vmovaps xmm0, [rsp]
00007d07b35d69b7  vmovaps xmm1, [rsp+0x10]
00007d07b35d69bd  vmovaps xmm2, [rsp+0x20]
00007d07b35d69c3  vmovaps xmm3, [rsp+0x30]
00007d07b35d69c9  vmovaps xmm4, [rsp+0x40]
00007d07b35d69cf  vmovaps xmm5, [rsp+0x50]
00007d07b35d69d5  vmovaps xmm6, [rsp+0x60]
00007d07b35d69db  vmovaps xmm8, [rsp+0x70]
00007d07b35d69e1  vmovaps xmm9, [rsp+0x80]
00007d07b35d69ea  vmovaps xmm10, [rsp+0x90]
00007d07b35d69f3  vmovaps xmm11, [rsp+0xA0]
00007d07b35d69fc  vmovaps xmm12, [rsp+0xB0]
00007d07b35d6a05  vmovaps xmm13, [rsp+0xC0]
00007d07b35d6a0e  vmovaps xmm14, [rsp+0xD0]
00007d07b35d6a17  vmovaps xmm15, [rsp+0xE0]
00007d07b35d6a20  add rsp, 0xF0
00007d07b35d6a27  pop r11
00007d07b35d6a29  pop r10
00007d07b35d6a2b  pop r9
00007d07b35d6a2d  pop r8
00007d07b35d6a2f  pop rsi
00007d07b35d6a30  pop rdi
00007d07b35d6a31  pop rdx
00007d07b35d6a32  pop rcx
00007d07b35d6a33  pop rax
00007d07b35d6a34  add rsp, 0x08
00007d07b35d6a38  jmp 0x00007D07B35D59C8
00007d07b35d6a3d  sub rsp, 0x08
00007d07b35d6a41  push rax
00007d07b35d6a42  push rcx
00007d07b35d6a43  push rdx
00007d07b35d6a44  push rdi
00007d07b35d6a45  push rsi
00007d07b35d6a46  push r8
00007d07b35d6a48  push r9
00007d07b35d6a4a  push r10
00007d07b35d6a4c  push r11
00007d07b35d6a4e  sub rsp, 0xF0
00007d07b35d6a55  vmovaps [rsp], xmm0
00007d07b35d6a5a  vmovaps [rsp+0x10], xmm1
00007d07b35d6a60  vmovaps [rsp+0x20], xmm2
00007d07b35d6a66  vmovaps [rsp+0x30], xmm3
00007d07b35d6a6c  vmovaps [rsp+0x40], xmm4
00007d07b35d6a72  vmovaps [rsp+0x50], xmm5
00007d07b35d6a78  vmovaps [rsp+0x60], xmm6
00007d07b35d6a7e  vmovaps [rsp+0x70], xmm7
00007d07b35d6a84  vmovaps [rsp+0x80], xmm8
00007d07b35d6a8d  vmovaps [rsp+0x90], xmm10
00007d07b35d6a96  vmovaps [rsp+0xA0], xmm11
00007d07b35d6a9f  vmovaps [rsp+0xB0], xmm12
00007d07b35d6aa8  vmovaps [rsp+0xC0], xmm13
00007d07b35d6ab1  vmovaps [rsp+0xD0], xmm14
00007d07b35d6aba  vmovaps [rsp+0xE0], xmm15
00007d07b35d6ac3  sub rsp, 0x30
00007d07b35d6ac7  movaps [rsp], xmm9
00007d07b35d6acc  movaps [rsp+0x10], xmm12
00007d07b35d6ad2  movaps [rsp+0x20], xmm10
00007d07b35d6ad8  lea rdi, [rsp]
00007d07b35d6adc  mov esi, 0x00
00007d07b35d6ae1  mov rax, 0x5D0AA712D530
00007d07b35d6aeb  call rax
00007d07b35d6aed  movaps xmm9, [rsp]
00007d07b35d6af2  add rsp, 0x30
00007d07b35d6af6  vmovaps xmm0, [rsp]
00007d07b35d6afb  vmovaps xmm1, [rsp+0x10]
00007d07b35d6b01  vmovaps xmm2, [rsp+0x20]
00007d07b35d6b07  vmovaps xmm3, [rsp+0x30]
00007d07b35d6b0d  vmovaps xmm4, [rsp+0x40]
00007d07b35d6b13  vmovaps xmm5, [rsp+0x50]
00007d07b35d6b19  vmovaps xmm6, [rsp+0x60]
00007d07b35d6b1f  vmovaps xmm7, [rsp+0x70]
00007d07b35d6b25  vmovaps xmm8, [rsp+0x80]
00007d07b35d6b2e  vmovaps xmm10, [rsp+0x90]
00007d07b35d6b37  vmovaps xmm11, [rsp+0xA0]
00007d07b35d6b40  vmovaps xmm12, [rsp+0xB0]
00007d07b35d6b49  vmovaps xmm13, [rsp+0xC0]
00007d07b35d6b52  vmovaps xmm14, [rsp+0xD0]
00007d07b35d6b5b  vmovaps xmm15, [rsp+0xE0]
00007d07b35d6b64  add rsp, 0xF0
00007d07b35d6b6b  pop r11
00007d07b35d6b6d  pop r10
00007d07b35d6b6f  pop r9
00007d07b35d6b71  pop r8
00007d07b35d6b73  pop rsi
00007d07b35d6b74  pop rdi
00007d07b35d6b75  pop rdx
00007d07b35d6b76  pop rcx
00007d07b35d6b77  pop rax
00007d07b35d6b78  add rsp, 0x08
00007d07b35d6b7c  jmp 0x00007D07B35D59EC
00007d07b35d6b81  sub rsp, 0x08
00007d07b35d6b85  push rax
00007d07b35d6b86  push rcx
00007d07b35d6b87  push rdx
00007d07b35d6b88  push rdi
00007d07b35d6b89  push rsi
00007d07b35d6b8a  push r8
00007d07b35d6b8c  push r9
00007d07b35d6b8e  push r10
00007d07b35d6b90  push r11
00007d07b35d6b92  sub rsp, 0xF0
00007d07b35d6b99  vmovaps [rsp], xmm0
00007d07b35d6b9e  vmovaps [rsp+0x10], xmm1
00007d07b35d6ba4  vmovaps [rsp+0x20], xmm2
00007d07b35d6baa  vmovaps [rsp+0x30], xmm3
00007d07b35d6bb0  vmovaps [rsp+0x40], xmm4
00007d07b35d6bb6  vmovaps [rsp+0x50], xmm5
00007d07b35d6bbc  vmovaps [rsp+0x60], xmm6
00007d07b35d6bc2  vmovaps [rsp+0x70], xmm7
00007d07b35d6bc8  vmovaps [rsp+0x80], xmm8
00007d07b35d6bd1  vmovaps [rsp+0x90], xmm9
00007d07b35d6bda  vmovaps [rsp+0xA0], xmm11
00007d07b35d6be3  vmovaps [rsp+0xB0], xmm12
00007d07b35d6bec  vmovaps [rsp+0xC0], xmm13
00007d07b35d6bf5  vmovaps [rsp+0xD0], xmm14
00007d07b35d6bfe  vmovaps [rsp+0xE0], xmm15
00007d07b35d6c07  sub rsp, 0x30
00007d07b35d6c0b  movaps [rsp], xmm10
00007d07b35d6c10  movaps [rsp+0x10], xmm12
00007d07b35d6c16  movaps [rsp+0x20], xmm11
00007d07b35d6c1c  lea rdi, [rsp]
00007d07b35d6c20  mov esi, 0x00
00007d07b35d6c25  mov rax, 0x5D0AA712D530
00007d07b35d6c2f  call rax
00007d07b35d6c31  movaps xmm10, [rsp]
00007d07b35d6c36  add rsp, 0x30
00007d07b35d6c3a  vmovaps xmm0, [rsp]
00007d07b35d6c3f  vmovaps xmm1, [rsp+0x10]
00007d07b35d6c45  vmovaps xmm2, [rsp+0x20]
00007d07b35d6c4b  vmovaps xmm3, [rsp+0x30]
00007d07b35d6c51  vmovaps xmm4, [rsp+0x40]
00007d07b35d6c57  vmovaps xmm5, [rsp+0x50]
00007d07b35d6c5d  vmovaps xmm6, [rsp+0x60]
00007d07b35d6c63  vmovaps xmm7, [rsp+0x70]
00007d07b35d6c69  vmovaps xmm8, [rsp+0x80]
00007d07b35d6c72  vmovaps xmm9, [rsp+0x90]
00007d07b35d6c7b  vmovaps xmm11, [rsp+0xA0]
00007d07b35d6c84  vmovaps xmm12, [rsp+0xB0]
00007d07b35d6c8d  vmovaps xmm13, [rsp+0xC0]
00007d07b35d6c96  vmovaps xmm14, [rsp+0xD0]
00007d07b35d6c9f  vmovaps xmm15, [rsp+0xE0]
00007d07b35d6ca8  add rsp, 0xF0
00007d07b35d6caf  pop r11
00007d07b35d6cb1  pop r10
00007d07b35d6cb3  pop r9
00007d07b35d6cb5  pop r8
00007d07b35d6cb7  pop rsi
00007d07b35d6cb8  pop rdi
00007d07b35d6cb9  pop rdx
00007d07b35d6cba  pop rcx
00007d07b35d6cbb  pop rax
00007d07b35d6cbc  add rsp, 0x08
00007d07b35d6cc0  jmp 0x00007D07B35D5A06
00007d07b35d6cc5  sub rsp, 0x08
00007d07b35d6cc9  push rax
00007d07b35d6cca  push rcx
00007d07b35d6ccb  push rdx
00007d07b35d6ccc  push rdi
00007d07b35d6ccd  push rsi
00007d07b35d6cce  push r8
00007d07b35d6cd0  push r9
00007d07b35d6cd2  push r10
00007d07b35d6cd4  push r11
00007d07b35d6cd6  sub rsp, 0xF0
00007d07b35d6cdd  vmovaps [rsp], xmm0
00007d07b35d6ce2  vmovaps [rsp+0x10], xmm1
00007d07b35d6ce8  vmovaps [rsp+0x20], xmm2
00007d07b35d6cee  vmovaps [rsp+0x30], xmm3
00007d07b35d6cf4  vmovaps [rsp+0x40], xmm4
00007d07b35d6cfa  vmovaps [rsp+0x50], xmm5
00007d07b35d6d00  vmovaps [rsp+0x60], xmm7
00007d07b35d6d06  vmovaps [rsp+0x70], xmm8
00007d07b35d6d0c  vmovaps [rsp+0x80], xmm9
00007d07b35d6d15  vmovaps [rsp+0x90], xmm10
00007d07b35d6d1e  vmovaps [rsp+0xA0], xmm11
00007d07b35d6d27  vmovaps [rsp+0xB0], xmm12
00007d07b35d6d30  vmovaps [rsp+0xC0], xmm13
00007d07b35d6d39  vmovaps [rsp+0xD0], xmm14
00007d07b35d6d42  vmovaps [rsp+0xE0], xmm15
00007d07b35d6d4b  sub rsp, 0x30
00007d07b35d6d4f  movaps [rsp], xmm6
00007d07b35d6d53  movaps [rsp+0x10], xmm12
00007d07b35d6d59  movaps [rsp+0x20], xmm11
00007d07b35d6d5f  lea rdi, [rsp]
00007d07b35d6d63  mov esi, 0x00
00007d07b35d6d68  mov rax, 0x5D0AA712D530
00007d07b35d6d72  call rax
00007d07b35d6d74  movaps xmm6, [rsp]
00007d07b35d6d78  add rsp, 0x30
00007d07b35d6d7c  vmovaps xmm0, [rsp]
00007d07b35d6d81  vmovaps xmm1, [rsp+0x10]
00007d07b35d6d87  vmovaps xmm2, [rsp+0x20]
00007d07b35d6d8d  vmovaps xmm3, [rsp+0x30]
00007d07b35d6d93  vmovaps xmm4, [rsp+0x40]
00007d07b35d6d99  vmovaps xmm5, [rsp+0x50]
00007d07b35d6d9f  vmovaps xmm7, [rsp+0x60]
00007d07b35d6da5  vmovaps xmm8, [rsp+0x70]
00007d07b35d6dab  vmovaps xmm9, [rsp+0x80]
00007d07b35d6db4  vmovaps xmm10, [rsp+0x90]
00007d07b35d6dbd  vmovaps xmm11, [rsp+0xA0]
00007d07b35d6dc6  vmovaps xmm12, [rsp+0xB0]
00007d07b35d6dcf  vmovaps xmm13, [rsp+0xC0]
00007d07b35d6dd8  vmovaps xmm14, [rsp+0xD0]
00007d07b35d6de1  vmovaps xmm15, [rsp+0xE0]
00007d07b35d6dea  add rsp, 0xF0
00007d07b35d6df1  pop r11
00007d07b35d6df3  pop r10
00007d07b35d6df5  pop r9
00007d07b35d6df7  pop r8
00007d07b35d6df9  pop rsi
00007d07b35d6dfa  pop rdi
00007d07b35d6dfb  pop rdx
00007d07b35d6dfc  pop rcx
00007d07b35d6dfd  pop rax
00007d07b35d6dfe  add rsp, 0x08
00007d07b35d6e02  jmp 0x00007D07B35D5A27
00007d07b35d6e07  sub rsp, 0x08
00007d07b35d6e0b  push rax
00007d07b35d6e0c  push rcx
00007d07b35d6e0d  push rdx
00007d07b35d6e0e  push rdi
00007d07b35d6e0f  push rsi
00007d07b35d6e10  push r8
00007d07b35d6e12  push r9
00007d07b35d6e14  push r10
00007d07b35d6e16  push r11
00007d07b35d6e18  sub rsp, 0xF0
00007d07b35d6e1f  vmovaps [rsp], xmm0
00007d07b35d6e24  vmovaps [rsp+0x10], xmm1
00007d07b35d6e2a  vmovaps [rsp+0x20], xmm2
00007d07b35d6e30  vmovaps [rsp+0x30], xmm4
00007d07b35d6e36  vmovaps [rsp+0x40], xmm5
00007d07b35d6e3c  vmovaps [rsp+0x50], xmm6
00007d07b35d6e42  vmovaps [rsp+0x60], xmm7
00007d07b35d6e48  vmovaps [rsp+0x70], xmm8
00007d07b35d6e4e  vmovaps [rsp+0x80], xmm9
00007d07b35d6e57  vmovaps [rsp+0x90], xmm10
00007d07b35d6e60  vmovaps [rsp+0xA0], xmm11
00007d07b35d6e69  vmovaps [rsp+0xB0], xmm12
00007d07b35d6e72  vmovaps [rsp+0xC0], xmm13
00007d07b35d6e7b  vmovaps [rsp+0xD0], xmm14
00007d07b35d6e84  vmovaps [rsp+0xE0], xmm15
00007d07b35d6e8d  sub rsp, 0x30
00007d07b35d6e91  movaps [rsp], xmm3
00007d07b35d6e95  movaps [rsp+0x10], xmm5
00007d07b35d6e9a  movaps [rsp+0x20], xmm4
00007d07b35d6e9f  lea rdi, [rsp]
00007d07b35d6ea3  mov esi, 0x00
00007d07b35d6ea8  mov rax, 0x5D0AA712D530
00007d07b35d6eb2  call rax
00007d07b35d6eb4  movaps xmm3, [rsp]
00007d07b35d6eb8  add rsp, 0x30
00007d07b35d6ebc  vmovaps xmm0, [rsp]
00007d07b35d6ec1  vmovaps xmm1, [rsp+0x10]
00007d07b35d6ec7  vmovaps xmm2, [rsp+0x20]
00007d07b35d6ecd  vmovaps xmm4, [rsp+0x30]
00007d07b35d6ed3  vmovaps xmm5, [rsp+0x40]
00007d07b35d6ed9  vmovaps xmm6, [rsp+0x50]
00007d07b35d6edf  vmovaps xmm7, [rsp+0x60]
00007d07b35d6ee5  vmovaps xmm8, [rsp+0x70]
00007d07b35d6eeb  vmovaps xmm9, [rsp+0x80]
00007d07b35d6ef4  vmovaps xmm10, [rsp+0x90]
00007d07b35d6efd  vmovaps xmm11, [rsp+0xA0]
00007d07b35d6f06  vmovaps xmm12, [rsp+0xB0]
00007d07b35d6f0f  vmovaps xmm13, [rsp+0xC0]
00007d07b35d6f18  vmovaps xmm14, [rsp+0xD0]
00007d07b35d6f21  vmovaps xmm15, [rsp+0xE0]
00007d07b35d6f2a  add rsp, 0xF0
00007d07b35d6f31  pop r11
00007d07b35d6f33  pop r10
00007d07b35d6f35  pop r9
00007d07b35d6f37  pop r8
00007d07b35d6f39  pop rsi
00007d07b35d6f3a  pop rdi
00007d07b35d6f3b  pop rdx
00007d07b35d6f3c  pop rcx
00007d07b35d6f3d  pop rax
00007d07b35d6f3e  add rsp, 0x08
00007d07b35d6f42  jmp 0x00007D07B35D5A88
00007d07b35d6f47  sub rsp, 0x08
00007d07b35d6f4b  push rax
00007d07b35d6f4c  push rcx
00007d07b35d6f4d  push rdx
00007d07b35d6f4e  push rdi
00007d07b35d6f4f  push rsi
00007d07b35d6f50  push r8
00007d07b35d6f52  push r9
00007d07b35d6f54  push r10
00007d07b35d6f56  push r11
00007d07b35d6f58  sub rsp, 0xF0
00007d07b35d6f5f  vmovaps [rsp], xmm0
00007d07b35d6f64  vmovaps [rsp+0x10], xmm1
00007d07b35d6f6a  vmovaps [rsp+0x20], xmm2
00007d07b35d6f70  vmovaps [rsp+0x30], xmm3
00007d07b35d6f76  vmovaps [rsp+0x40], xmm4
00007d07b35d6f7c  vmovaps [rsp+0x50], xmm6
00007d07b35d6f82  vmovaps [rsp+0x60], xmm7
00007d07b35d6f88  vmovaps [rsp+0x70], xmm8
00007d07b35d6f8e  vmovaps [rsp+0x80], xmm9
00007d07b35d6f97  vmovaps [rsp+0x90], xmm10
00007d07b35d6fa0  vmovaps [rsp+0xA0], xmm11
00007d07b35d6fa9  vmovaps [rsp+0xB0], xmm12
00007d07b35d6fb2  vmovaps [rsp+0xC0], xmm13
00007d07b35d6fbb  vmovaps [rsp+0xD0], xmm14
00007d07b35d6fc4  vmovaps [rsp+0xE0], xmm15
00007d07b35d6fcd  sub rsp, 0x30
00007d07b35d6fd1  movaps [rsp], xmm5
00007d07b35d6fd5  movaps [rsp+0x10], xmm8
00007d07b35d6fdb  movaps [rsp+0x20], xmm15
00007d07b35d6fe1  lea rdi, [rsp]
00007d07b35d6fe5  mov esi, 0x00
00007d07b35d6fea  mov rax, 0x5D0AA712D530
00007d07b35d6ff4  call rax
00007d07b35d6ff6  movaps xmm5, [rsp]
00007d07b35d6ffa  add rsp, 0x30
00007d07b35d6ffe  vmovaps xmm0, [rsp]
00007d07b35d7003  vmovaps xmm1, [rsp+0x10]
00007d07b35d7009  vmovaps xmm2, [rsp+0x20]
00007d07b35d700f  vmovaps xmm3, [rsp+0x30]
00007d07b35d7015  vmovaps xmm4, [rsp+0x40]
00007d07b35d701b  vmovaps xmm6, [rsp+0x50]
00007d07b35d7021  vmovaps xmm7, [rsp+0x60]
00007d07b35d7027  vmovaps xmm8, [rsp+0x70]
00007d07b35d702d  vmovaps xmm9, [rsp+0x80]
00007d07b35d7036  vmovaps xmm10, [rsp+0x90]
00007d07b35d703f  vmovaps xmm11, [rsp+0xA0]
00007d07b35d7048  vmovaps xmm12, [rsp+0xB0]
00007d07b35d7051  vmovaps xmm13, [rsp+0xC0]
00007d07b35d705a  vmovaps xmm14, [rsp+0xD0]
00007d07b35d7063  vmovaps xmm15, [rsp+0xE0]
00007d07b35d706c  add rsp, 0xF0
00007d07b35d7073  pop r11
00007d07b35d7075  pop r10
00007d07b35d7077  pop r9
00007d07b35d7079  pop r8
00007d07b35d707b  pop rsi
00007d07b35d707c  pop rdi
00007d07b35d707d  pop rdx
00007d07b35d707e  pop rcx
00007d07b35d707f  pop rax
00007d07b35d7080  add rsp, 0x08
00007d07b35d7084  jmp 0x00007D07B35D5AC0
00007d07b35d7089  sub rsp, 0x08
00007d07b35d708d  push rax
00007d07b35d708e  push rcx
00007d07b35d708f  push rdx
00007d07b35d7090  push rdi
00007d07b35d7091  push rsi
00007d07b35d7092  push r8
00007d07b35d7094  push r9
00007d07b35d7096  push r10
00007d07b35d7098  push r11
00007d07b35d709a  sub rsp, 0xF0
00007d07b35d70a1  vmovaps [rsp], xmm0
00007d07b35d70a6  vmovaps [rsp+0x10], xmm1
00007d07b35d70ac  vmovaps [rsp+0x20], xmm2
00007d07b35d70b2  vmovaps [rsp+0x30], xmm3
00007d07b35d70b8  vmovaps [rsp+0x40], xmm5
00007d07b35d70be  vmovaps [rsp+0x50], xmm6
00007d07b35d70c4  vmovaps [rsp+0x60], xmm7
00007d07b35d70ca  vmovaps [rsp+0x70], xmm8
00007d07b35d70d0  vmovaps [rsp+0x80], xmm9
00007d07b35d70d9  vmovaps [rsp+0x90], xmm10
00007d07b35d70e2  vmovaps [rsp+0xA0], xmm11
00007d07b35d70eb  vmovaps [rsp+0xB0], xmm12
00007d07b35d70f4  vmovaps [rsp+0xC0], xmm13
00007d07b35d70fd  vmovaps [rsp+0xD0], xmm14
00007d07b35d7106  vmovaps [rsp+0xE0], xmm15
00007d07b35d710f  sub rsp, 0x30
00007d07b35d7113  movaps [rsp], xmm4
00007d07b35d7117  movaps [rsp+0x10], xmm9
00007d07b35d711d  movaps [rsp+0x20], xmm8
00007d07b35d7123  lea rdi, [rsp]
00007d07b35d7127  mov esi, 0x00
00007d07b35d712c  mov rax, 0x5D0AA712D530
00007d07b35d7136  call rax
00007d07b35d7138  movaps xmm4, [rsp]
00007d07b35d713c  add rsp, 0x30
00007d07b35d7140  vmovaps xmm0, [rsp]
00007d07b35d7145  vmovaps xmm1, [rsp+0x10]
00007d07b35d714b  vmovaps xmm2, [rsp+0x20]
00007d07b35d7151  vmovaps xmm3, [rsp+0x30]
00007d07b35d7157  vmovaps xmm5, [rsp+0x40]
00007d07b35d715d  vmovaps xmm6, [rsp+0x50]
00007d07b35d7163  vmovaps xmm7, [rsp+0x60]
00007d07b35d7169  vmovaps xmm8, [rsp+0x70]
00007d07b35d716f  vmovaps xmm9, [rsp+0x80]
00007d07b35d7178  vmovaps xmm10, [rsp+0x90]
00007d07b35d7181  vmovaps xmm11, [rsp+0xA0]
00007d07b35d718a  vmovaps xmm12, [rsp+0xB0]
00007d07b35d7193  vmovaps xmm13, [rsp+0xC0]
00007d07b35d719c  vmovaps xmm14, [rsp+0xD0]
00007d07b35d71a5  vmovaps xmm15, [rsp+0xE0]
00007d07b35d71ae  add rsp, 0xF0
00007d07b35d71b5  pop r11
00007d07b35d71b7  pop r10
00007d07b35d71b9  pop r9
00007d07b35d71bb  pop r8
00007d07b35d71bd  pop rsi
00007d07b35d71be  pop rdi
00007d07b35d71bf  pop rdx
00007d07b35d71c0  pop rcx
00007d07b35d71c1  pop rax
00007d07b35d71c2  add rsp, 0x08
00007d07b35d71c6  jmp 0x00007D07B35D5AE1
00007d07b35d71cb  sub rsp, 0x08
00007d07b35d71cf  push rax
00007d07b35d71d0  push rcx
00007d07b35d71d1  push rdx
00007d07b35d71d2  push rdi
00007d07b35d71d3  push rsi
00007d07b35d71d4  push r8
00007d07b35d71d6  push r9
00007d07b35d71d8  push r10
00007d07b35d71da  push r11
00007d07b35d71dc  sub rsp, 0xF0
00007d07b35d71e3  vmovaps [rsp], xmm0
00007d07b35d71e8  vmovaps [rsp+0x10], xmm1
00007d07b35d71ee  vmovaps [rsp+0x20], xmm2
00007d07b35d71f4  vmovaps [rsp+0x30], xmm3
00007d07b35d71fa  vmovaps [rsp+0x40], xmm4
00007d07b35d7200  vmovaps [rsp+0x50], xmm5
00007d07b35d7206  vmovaps [rsp+0x60], xmm6
00007d07b35d720c  vmovaps [rsp+0x70], xmm7
00007d07b35d7212  vmovaps [rsp+0x80], xmm8
00007d07b35d721b  vmovaps [rsp+0x90], xmm10
00007d07b35d7224  vmovaps [rsp+0xA0], xmm11
00007d07b35d722d  vmovaps [rsp+0xB0], xmm12
00007d07b35d7236  vmovaps [rsp+0xC0], xmm13
00007d07b35d723f  vmovaps [rsp+0xD0], xmm14
00007d07b35d7248  vmovaps [rsp+0xE0], xmm15
00007d07b35d7251  sub rsp, 0x30
00007d07b35d7255  movaps [rsp], xmm9
00007d07b35d725a  movaps [rsp+0x10], xmm10
00007d07b35d7260  movaps [rsp+0x20], xmm8
00007d07b35d7266  lea rdi, [rsp]
00007d07b35d726a  mov esi, 0x00
00007d07b35d726f  mov rax, 0x5D0AA712D530
00007d07b35d7279  call rax
00007d07b35d727b  movaps xmm9, [rsp]
00007d07b35d7280  add rsp, 0x30
00007d07b35d7284  vmovaps xmm0, [rsp]
00007d07b35d7289  vmovaps xmm1, [rsp+0x10]
00007d07b35d728f  vmovaps xmm2, [rsp+0x20]
00007d07b35d7295  vmovaps xmm3, [rsp+0x30]
00007d07b35d729b  vmovaps xmm4, [rsp+0x40]
00007d07b35d72a1  vmovaps xmm5, [rsp+0x50]
00007d07b35d72a7  vmovaps xmm6, [rsp+0x60]
00007d07b35d72ad  vmovaps xmm7, [rsp+0x70]
00007d07b35d72b3  vmovaps xmm8, [rsp+0x80]
00007d07b35d72bc  vmovaps xmm10, [rsp+0x90]
00007d07b35d72c5  vmovaps xmm11, [rsp+0xA0]
00007d07b35d72ce  vmovaps xmm12, [rsp+0xB0]
00007d07b35d72d7  vmovaps xmm13, [rsp+0xC0]
00007d07b35d72e0  vmovaps xmm14, [rsp+0xD0]
00007d07b35d72e9  vmovaps xmm15, [rsp+0xE0]
00007d07b35d72f2  add rsp, 0xF0
00007d07b35d72f9  pop r11
00007d07b35d72fb  pop r10
00007d07b35d72fd  pop r9
00007d07b35d72ff  pop r8
00007d07b35d7301  pop rsi
00007d07b35d7302  pop rdi
00007d07b35d7303  pop rdx
00007d07b35d7304  pop rcx
00007d07b35d7305  pop rax
00007d07b35d7306  add rsp, 0x08
00007d07b35d730a  jmp 0x00007D07B35D5AFB
00007d07b35d730f  call 0x00007D07B34D64F0
00007d07b35d7314  jmp 0x00007D07B35D5C15
00007d07b35d7319  call 0x00007D07B34D64F0
00007d07b35d731e  jmp 0x00007D07B35D5C2B
00007d07b35d7323  sub rsp, 0x08
00007d07b35d7327  push rax
00007d07b35d7328  push rcx
00007d07b35d7329  push rdx
00007d07b35d732a  push rdi
00007d07b35d732b  push rsi
00007d07b35d732c  push r8
00007d07b35d732e  push r9
00007d07b35d7330  push r10
00007d07b35d7332  push r11
00007d07b35d7334  sub rsp, 0xF0
00007d07b35d733b  vmovaps [rsp], xmm0
00007d07b35d7340  vmovaps [rsp+0x10], xmm2
00007d07b35d7346  vmovaps [rsp+0x20], xmm3
00007d07b35d734c  vmovaps [rsp+0x30], xmm4
00007d07b35d7352  vmovaps [rsp+0x40], xmm5
00007d07b35d7358  vmovaps [rsp+0x50], xmm6
00007d07b35d735e  vmovaps [rsp+0x60], xmm7
00007d07b35d7364  vmovaps [rsp+0x70], xmm8
00007d07b35d736a  vmovaps [rsp+0x80], xmm9
00007d07b35d7373  vmovaps [rsp+0x90], xmm10
00007d07b35d737c  vmovaps [rsp+0xA0], xmm11
00007d07b35d7385  vmovaps [rsp+0xB0], xmm12
00007d07b35d738e  vmovaps [rsp+0xC0], xmm13
00007d07b35d7397  vmovaps [rsp+0xD0], xmm14
00007d07b35d73a0  vmovaps [rsp+0xE0], xmm15
00007d07b35d73a9  sub rsp, 0x30
00007d07b35d73ad  movaps [rsp], xmm1
00007d07b35d73b1  movaps [rsp+0x10], xmm6
00007d07b35d73b6  movaps [rsp+0x20], xmm15
00007d07b35d73bc  lea rdi, [rsp]
00007d07b35d73c0  mov esi, 0x00
00007d07b35d73c5  mov rax, 0x5D0AA712D530
00007d07b35d73cf  call rax
00007d07b35d73d1  movaps xmm1, [rsp]
00007d07b35d73d5  add rsp, 0x30
00007d07b35d73d9  vmovaps xmm0, [rsp]
00007d07b35d73de  vmovaps xmm2, [rsp+0x10]
00007d07b35d73e4  vmovaps xmm3, [rsp+0x20]
00007d07b35d73ea  vmovaps xmm4, [rsp+0x30]
00007d07b35d73f0  vmovaps xmm5, [rsp+0x40]
00007d07b35d73f6  vmovaps xmm6, [rsp+0x50]
00007d07b35d73fc  vmovaps xmm7, [rsp+0x60]
00007d07b35d7402  vmovaps xmm8, [rsp+0x70]
00007d07b35d7408  vmovaps xmm9, [rsp+0x80]
00007d07b35d7411  vmovaps xmm10, [rsp+0x90]
00007d07b35d741a  vmovaps xmm11, [rsp+0xA0]
00007d07b35d7423  vmovaps xmm12, [rsp+0xB0]
00007d07b35d742c  vmovaps xmm13, [rsp+0xC0]
00007d07b35d7435  vmovaps xmm14, [rsp+0xD0]
00007d07b35d743e  vmovaps xmm15, [rsp+0xE0]
00007d07b35d7447  add rsp, 0xF0
00007d07b35d744e  pop r11
00007d07b35d7450  pop r10
00007d07b35d7452  pop r9
00007d07b35d7454  pop r8
00007d07b35d7456  pop rsi
00007d07b35d7457  pop rdi
00007d07b35d7458  pop rdx
00007d07b35d7459  pop rcx
00007d07b35d745a  pop rax
00007d07b35d745b  add rsp, 0x08
00007d07b35d745f  jmp 0x00007D07B35D5C68
00007d07b35d7464  call 0x00007D07B34E5820
00007d07b35d7469  jmp 0x00007D07B35D5C75
00007d07b35d746e  sub rsp, 0x08
00007d07b35d7472  push rax
00007d07b35d7473  push rcx
00007d07b35d7474  push rdx
00007d07b35d7475  push rdi
00007d07b35d7476  push rsi
00007d07b35d7477  push r8
00007d07b35d7479  push r9
00007d07b35d747b  push r10
00007d07b35d747d  push r11
00007d07b35d747f  sub rsp, 0xF0
00007d07b35d7486  vmovaps [rsp], xmm0
00007d07b35d748b  vmovaps [rsp+0x10], xmm1
00007d07b35d7491  vmovaps [rsp+0x20], xmm2
00007d07b35d7497  vmovaps [rsp+0x30], xmm3
00007d07b35d749d  vmovaps [rsp+0x40], xmm4
00007d07b35d74a3  vmovaps [rsp+0x50], xmm5
00007d07b35d74a9  vmovaps [rsp+0x60], xmm6
00007d07b35d74af  vmovaps [rsp+0x70], xmm7
00007d07b35d74b5  vmovaps [rsp+0x80], xmm8
00007d07b35d74be  vmovaps [rsp+0x90], xmm9
00007d07b35d74c7  vmovaps [rsp+0xA0], xmm10
00007d07b35d74d0  vmovaps [rsp+0xB0], xmm11
00007d07b35d74d9  vmovaps [rsp+0xC0], xmm12
00007d07b35d74e2  vmovaps [rsp+0xD0], xmm13
00007d07b35d74eb  vmovaps [rsp+0xE0], xmm15
00007d07b35d74f4  sub rsp, 0x30
00007d07b35d74f8  movaps [rsp], xmm14
00007d07b35d74fd  movaps [rsp+0x10], xmm4
00007d07b35d7502  movaps [rsp+0x20], xmm3
00007d07b35d7507  lea rdi, [rsp]
00007d07b35d750b  mov esi, 0x00
00007d07b35d7510  mov rax, 0x5D0AA712D530
00007d07b35d751a  call rax
00007d07b35d751c  movaps xmm14, [rsp]
00007d07b35d7521  add rsp, 0x30
00007d07b35d7525  vmovaps xmm0, [rsp]
00007d07b35d752a  vmovaps xmm1, [rsp+0x10]
00007d07b35d7530  vmovaps xmm2, [rsp+0x20]
00007d07b35d7536  vmovaps xmm3, [rsp+0x30]
00007d07b35d753c  vmovaps xmm4, [rsp+0x40]
00007d07b35d7542  vmovaps xmm5, [rsp+0x50]
00007d07b35d7548  vmovaps xmm6, [rsp+0x60]
00007d07b35d754e  vmovaps xmm7, [rsp+0x70]
00007d07b35d7554  vmovaps xmm8, [rsp+0x80]
00007d07b35d755d  vmovaps xmm9, [rsp+0x90]
00007d07b35d7566  vmovaps xmm10, [rsp+0xA0]
00007d07b35d756f  vmovaps xmm11, [rsp+0xB0]
00007d07b35d7578  vmovaps xmm12, [rsp+0xC0]
00007d07b35d7581  vmovaps xmm13, [rsp+0xD0]
00007d07b35d758a  vmovaps xmm15, [rsp+0xE0]
00007d07b35d7593  add rsp, 0xF0
00007d07b35d759a  pop r11
00007d07b35d759c  pop r10
00007d07b35d759e  pop r9
00007d07b35d75a0  pop r8
00007d07b35d75a2  pop rsi
00007d07b35d75a3  pop rdi
00007d07b35d75a4  pop rdx
00007d07b35d75a5  pop rcx
00007d07b35d75a6  pop rax
00007d07b35d75a7  add rsp, 0x08
00007d07b35d75ab  jmp 0x00007D07B35D5C8F
00007d07b35d75b0  sub rsp, 0x08
00007d07b35d75b4  push rax
00007d07b35d75b5  push rcx
00007d07b35d75b6  push rdx
00007d07b35d75b7  push rdi
00007d07b35d75b8  push rsi
00007d07b35d75b9  push r8
00007d07b35d75bb  push r9
00007d07b35d75bd  push r10
00007d07b35d75bf  push r11
00007d07b35d75c1  sub rsp, 0xF0
00007d07b35d75c8  vmovaps [rsp], xmm0
00007d07b35d75cd  vmovaps [rsp+0x10], xmm1
00007d07b35d75d3  vmovaps [rsp+0x20], xmm2
00007d07b35d75d9  vmovaps [rsp+0x30], xmm3
00007d07b35d75df  vmovaps [rsp+0x40], xmm4
00007d07b35d75e5  vmovaps [rsp+0x50], xmm5
00007d07b35d75eb  vmovaps [rsp+0x60], xmm7
00007d07b35d75f1  vmovaps [rsp+0x70], xmm8
00007d07b35d75f7  vmovaps [rsp+0x80], xmm9
00007d07b35d7600  vmovaps [rsp+0x90], xmm10
00007d07b35d7609  vmovaps [rsp+0xA0], xmm11
00007d07b35d7612  vmovaps [rsp+0xB0], xmm12
00007d07b35d761b  vmovaps [rsp+0xC0], xmm13
00007d07b35d7624  vmovaps [rsp+0xD0], xmm14
00007d07b35d762d  vmovaps [rsp+0xE0], xmm15
00007d07b35d7636  sub rsp, 0x30
00007d07b35d763a  movaps [rsp], xmm6
00007d07b35d763e  movaps [rsp+0x10], xmm9
00007d07b35d7644  movaps [rsp+0x20], xmm7
00007d07b35d7649  lea rdi, [rsp]
00007d07b35d764d  mov esi, 0x00
00007d07b35d7652  mov rax, 0x5D0AA712D530
00007d07b35d765c  call rax
00007d07b35d765e  movaps xmm6, [rsp]
00007d07b35d7662  add rsp, 0x30
00007d07b35d7666  vmovaps xmm0, [rsp]
00007d07b35d766b  vmovaps xmm1, [rsp+0x10]
00007d07b35d7671  vmovaps xmm2, [rsp+0x20]
00007d07b35d7677  vmovaps xmm3, [rsp+0x30]
00007d07b35d767d  vmovaps xmm4, [rsp+0x40]
00007d07b35d7683  vmovaps xmm5, [rsp+0x50]
00007d07b35d7689  vmovaps xmm7, [rsp+0x60]
00007d07b35d768f  vmovaps xmm8, [rsp+0x70]
00007d07b35d7695  vmovaps xmm9, [rsp+0x80]
00007d07b35d769e  vmovaps xmm10, [rsp+0x90]
00007d07b35d76a7  vmovaps xmm11, [rsp+0xA0]
00007d07b35d76b0  vmovaps xmm12, [rsp+0xB0]
00007d07b35d76b9  vmovaps xmm13, [rsp+0xC0]
00007d07b35d76c2  vmovaps xmm14, [rsp+0xD0]
00007d07b35d76cb  vmovaps xmm15, [rsp+0xE0]
00007d07b35d76d4  add rsp, 0xF0
00007d07b35d76db  pop r11
00007d07b35d76dd  pop r10
00007d07b35d76df  pop r9
00007d07b35d76e1  pop r8
00007d07b35d76e3  pop rsi
00007d07b35d76e4  pop rdi
00007d07b35d76e5  pop rdx
00007d07b35d76e6  pop rcx
00007d07b35d76e7  pop rax
00007d07b35d76e8  add rsp, 0x08
00007d07b35d76ec  jmp 0x00007D07B35D5CA7
00007d07b35d76f1  sub rsp, 0x08
00007d07b35d76f5  push rax
00007d07b35d76f6  push rcx
00007d07b35d76f7  push rdx
00007d07b35d76f8  push rdi
00007d07b35d76f9  push rsi
00007d07b35d76fa  push r8
00007d07b35d76fc  push r9
00007d07b35d76fe  push r10
00007d07b35d7700  push r11
00007d07b35d7702  sub rsp, 0xF0
00007d07b35d7709  vmovaps [rsp], xmm0
00007d07b35d770e  vmovaps [rsp+0x10], xmm1
00007d07b35d7714  vmovaps [rsp+0x20], xmm2
00007d07b35d771a  vmovaps [rsp+0x30], xmm3
00007d07b35d7720  vmovaps [rsp+0x40], xmm4
00007d07b35d7726  vmovaps [rsp+0x50], xmm5
00007d07b35d772c  vmovaps [rsp+0x60], xmm6
00007d07b35d7732  vmovaps [rsp+0x70], xmm8
00007d07b35d7738  vmovaps [rsp+0x80], xmm9
00007d07b35d7741  vmovaps [rsp+0x90], xmm10
00007d07b35d774a  vmovaps [rsp+0xA0], xmm11
00007d07b35d7753  vmovaps [rsp+0xB0], xmm12
00007d07b35d775c  vmovaps [rsp+0xC0], xmm13
00007d07b35d7765  vmovaps [rsp+0xD0], xmm14
00007d07b35d776e  vmovaps [rsp+0xE0], xmm15
00007d07b35d7777  sub rsp, 0x30
00007d07b35d777b  movaps [rsp], xmm7
00007d07b35d777f  movaps [rsp+0x10], xmm4
00007d07b35d7784  movaps [rsp+0x20], xmm9
00007d07b35d778a  lea rdi, [rsp]
00007d07b35d778e  mov esi, 0x00
00007d07b35d7793  mov rax, 0x5D0AA712D530
00007d07b35d779d  call rax
00007d07b35d779f  movaps xmm7, [rsp]
00007d07b35d77a3  add rsp, 0x30
00007d07b35d77a7  vmovaps xmm0, [rsp]
00007d07b35d77ac  vmovaps xmm1, [rsp+0x10]
00007d07b35d77b2  vmovaps xmm2, [rsp+0x20]
00007d07b35d77b8  vmovaps xmm3, [rsp+0x30]
00007d07b35d77be  vmovaps xmm4, [rsp+0x40]
00007d07b35d77c4  vmovaps xmm5, [rsp+0x50]
00007d07b35d77ca  vmovaps xmm6, [rsp+0x60]
00007d07b35d77d0  vmovaps xmm8, [rsp+0x70]
00007d07b35d77d6  vmovaps xmm9, [rsp+0x80]
00007d07b35d77df  vmovaps xmm10, [rsp+0x90]
00007d07b35d77e8  vmovaps xmm11, [rsp+0xA0]
00007d07b35d77f1  vmovaps xmm12, [rsp+0xB0]
00007d07b35d77fa  vmovaps xmm13, [rsp+0xC0]
00007d07b35d7803  vmovaps xmm14, [rsp+0xD0]
00007d07b35d780c  vmovaps xmm15, [rsp+0xE0]
00007d07b35d7815  add rsp, 0xF0
00007d07b35d781c  pop r11
00007d07b35d781e  pop r10
00007d07b35d7820  pop r9
00007d07b35d7822  pop r8
00007d07b35d7824  pop rsi
00007d07b35d7825  pop rdi
00007d07b35d7826  pop rdx
00007d07b35d7827  pop rcx
00007d07b35d7828  pop rax
00007d07b35d7829  add rsp, 0x08
00007d07b35d782d  jmp 0x00007D07B35D5CD4
00007d07b35d7832  sub rsp, 0x08
00007d07b35d7836  push rax
00007d07b35d7837  push rcx
00007d07b35d7838  push rdx
00007d07b35d7839  push rdi
00007d07b35d783a  push rsi
00007d07b35d783b  push r8
00007d07b35d783d  push r9
00007d07b35d783f  push r10
00007d07b35d7841  push r11
00007d07b35d7843  sub rsp, 0xF0
00007d07b35d784a  vmovaps [rsp], xmm0
00007d07b35d784f  vmovaps [rsp+0x10], xmm1
00007d07b35d7855  vmovaps [rsp+0x20], xmm2
00007d07b35d785b  vmovaps [rsp+0x30], xmm3
00007d07b35d7861  vmovaps [rsp+0x40], xmm5
00007d07b35d7867  vmovaps [rsp+0x50], xmm6
00007d07b35d786d  vmovaps [rsp+0x60], xmm7
00007d07b35d7873  vmovaps [rsp+0x70], xmm8
00007d07b35d7879  vmovaps [rsp+0x80], xmm9
00007d07b35d7882  vmovaps [rsp+0x90], xmm10
00007d07b35d788b  vmovaps [rsp+0xA0], xmm11
00007d07b35d7894  vmovaps [rsp+0xB0], xmm12
00007d07b35d789d  vmovaps [rsp+0xC0], xmm13
00007d07b35d78a6  vmovaps [rsp+0xD0], xmm14
00007d07b35d78af  vmovaps [rsp+0xE0], xmm15
00007d07b35d78b8  sub rsp, 0x30
00007d07b35d78bc  movaps [rsp], xmm4
00007d07b35d78c0  movaps [rsp+0x10], xmm15
00007d07b35d78c6  movaps [rsp+0x20], xmm9
00007d07b35d78cc  lea rdi, [rsp]
00007d07b35d78d0  mov esi, 0x00
00007d07b35d78d5  mov rax, 0x5D0AA712D530
00007d07b35d78df  call rax
00007d07b35d78e1  movaps xmm4, [rsp]
00007d07b35d78e5  add rsp, 0x30
00007d07b35d78e9  vmovaps xmm0, [rsp]
00007d07b35d78ee  vmovaps xmm1, [rsp+0x10]
00007d07b35d78f4  vmovaps xmm2, [rsp+0x20]
00007d07b35d78fa  vmovaps xmm3, [rsp+0x30]
00007d07b35d7900  vmovaps xmm5, [rsp+0x40]
00007d07b35d7906  vmovaps xmm6, [rsp+0x50]
00007d07b35d790c  vmovaps xmm7, [rsp+0x60]
00007d07b35d7912  vmovaps xmm8, [rsp+0x70]
00007d07b35d7918  vmovaps xmm9, [rsp+0x80]
00007d07b35d7921  vmovaps xmm10, [rsp+0x90]
00007d07b35d792a  vmovaps xmm11, [rsp+0xA0]
00007d07b35d7933  vmovaps xmm12, [rsp+0xB0]
00007d07b35d793c  vmovaps xmm13, [rsp+0xC0]
00007d07b35d7945  vmovaps xmm14, [rsp+0xD0]
00007d07b35d794e  vmovaps xmm15, [rsp+0xE0]
00007d07b35d7957  add rsp, 0xF0
00007d07b35d795e  pop r11
00007d07b35d7960  pop r10
00007d07b35d7962  pop r9
00007d07b35d7964  pop r8
00007d07b35d7966  pop rsi
00007d07b35d7967  pop rdi
00007d07b35d7968  pop rdx
00007d07b35d7969  pop rcx
00007d07b35d796a  pop rax
00007d07b35d796b  add rsp, 0x08
00007d07b35d796f  jmp 0x00007D07B35D5CF9
00007d07b35d7974  call 0x00007D07B34E5820
00007d07b35d7979  jmp 0x00007D07B35D5D06
00007d07b35d797e  sub rsp, 0x08
00007d07b35d7982  push rax
00007d07b35d7983  push rcx
00007d07b35d7984  push rdx
00007d07b35d7985  push rdi
00007d07b35d7986  push rsi
00007d07b35d7987  push r8
00007d07b35d7989  push r9
00007d07b35d798b  push r10
00007d07b35d798d  push r11
00007d07b35d798f  sub rsp, 0xF0
00007d07b35d7996  vmovaps [rsp], xmm0
00007d07b35d799b  vmovaps [rsp+0x10], xmm1
00007d07b35d79a1  vmovaps [rsp+0x20], xmm2
00007d07b35d79a7  vmovaps [rsp+0x30], xmm4
00007d07b35d79ad  vmovaps [rsp+0x40], xmm5
00007d07b35d79b3  vmovaps [rsp+0x50], xmm6
00007d07b35d79b9  vmovaps [rsp+0x60], xmm7
00007d07b35d79bf  vmovaps [rsp+0x70], xmm8
00007d07b35d79c5  vmovaps [rsp+0x80], xmm9
00007d07b35d79ce  vmovaps [rsp+0x90], xmm10
00007d07b35d79d7  vmovaps [rsp+0xA0], xmm11
00007d07b35d79e0  vmovaps [rsp+0xB0], xmm12
00007d07b35d79e9  vmovaps [rsp+0xC0], xmm13
00007d07b35d79f2  vmovaps [rsp+0xD0], xmm14
00007d07b35d79fb  vmovaps [rsp+0xE0], xmm15
00007d07b35d7a04  sub rsp, 0x30
00007d07b35d7a08  movaps [rsp], xmm3
00007d07b35d7a0c  movaps [rsp+0x10], xmm1
00007d07b35d7a11  movaps [rsp+0x20], xmm9
00007d07b35d7a17  lea rdi, [rsp]
00007d07b35d7a1b  mov esi, 0x00
00007d07b35d7a20  mov rax, 0x5D0AA712D530
00007d07b35d7a2a  call rax
00007d07b35d7a2c  movaps xmm3, [rsp]
00007d07b35d7a30  add rsp, 0x30
00007d07b35d7a34  vmovaps xmm0, [rsp]
00007d07b35d7a39  vmovaps xmm1, [rsp+0x10]
00007d07b35d7a3f  vmovaps xmm2, [rsp+0x20]
00007d07b35d7a45  vmovaps xmm4, [rsp+0x30]
00007d07b35d7a4b  vmovaps xmm5, [rsp+0x40]
00007d07b35d7a51  vmovaps xmm6, [rsp+0x50]
00007d07b35d7a57  vmovaps xmm7, [rsp+0x60]
00007d07b35d7a5d  vmovaps xmm8, [rsp+0x70]
00007d07b35d7a63  vmovaps xmm9, [rsp+0x80]
00007d07b35d7a6c  vmovaps xmm10, [rsp+0x90]
00007d07b35d7a75  vmovaps xmm11, [rsp+0xA0]
00007d07b35d7a7e  vmovaps xmm12, [rsp+0xB0]
00007d07b35d7a87  vmovaps xmm13, [rsp+0xC0]
00007d07b35d7a90  vmovaps xmm14, [rsp+0xD0]
00007d07b35d7a99  vmovaps xmm15, [rsp+0xE0]
00007d07b35d7aa2  add rsp, 0xF0
00007d07b35d7aa9  pop r11
00007d07b35d7aab  pop r10
00007d07b35d7aad  pop r9
00007d07b35d7aaf  pop r8
00007d07b35d7ab1  pop rsi
00007d07b35d7ab2  pop rdi
00007d07b35d7ab3  pop rdx
00007d07b35d7ab4  pop rcx
00007d07b35d7ab5  pop rax
00007d07b35d7ab6  add rsp, 0x08
00007d07b35d7aba  jmp 0x00007D07B35D5D43
00007d07b35d7abf  sub rsp, 0x08
00007d07b35d7ac3  push rax
00007d07b35d7ac4  push rcx
00007d07b35d7ac5  push rdx
00007d07b35d7ac6  push rdi
00007d07b35d7ac7  push rsi
00007d07b35d7ac8  push r8
00007d07b35d7aca  push r9
00007d07b35d7acc  push r10
00007d07b35d7ace  push r11
00007d07b35d7ad0  sub rsp, 0xF0
00007d07b35d7ad7  vmovaps [rsp], xmm0
00007d07b35d7adc  vmovaps [rsp+0x10], xmm2
00007d07b35d7ae2  vmovaps [rsp+0x20], xmm3
00007d07b35d7ae8  vmovaps [rsp+0x30], xmm4
00007d07b35d7aee  vmovaps [rsp+0x40], xmm5
00007d07b35d7af4  vmovaps [rsp+0x50], xmm6
00007d07b35d7afa  vmovaps [rsp+0x60], xmm7
00007d07b35d7b00  vmovaps [rsp+0x70], xmm8
00007d07b35d7b06  vmovaps [rsp+0x80], xmm9
00007d07b35d7b0f  vmovaps [rsp+0x90], xmm10
00007d07b35d7b18  vmovaps [rsp+0xA0], xmm11
00007d07b35d7b21  vmovaps [rsp+0xB0], xmm12
00007d07b35d7b2a  vmovaps [rsp+0xC0], xmm13
00007d07b35d7b33  vmovaps [rsp+0xD0], xmm14
00007d07b35d7b3c  vmovaps [rsp+0xE0], xmm15
00007d07b35d7b45  sub rsp, 0x30
00007d07b35d7b49  movaps [rsp], xmm1
00007d07b35d7b4d  movaps [rsp+0x10], xmm15
00007d07b35d7b53  movaps [rsp+0x20], xmm9
00007d07b35d7b59  lea rdi, [rsp]
00007d07b35d7b5d  mov esi, 0x00
00007d07b35d7b62  mov rax, 0x5D0AA712D530
00007d07b35d7b6c  call rax
00007d07b35d7b6e  movaps xmm1, [rsp]
00007d07b35d7b72  add rsp, 0x30
00007d07b35d7b76  vmovaps xmm0, [rsp]
00007d07b35d7b7b  vmovaps xmm2, [rsp+0x10]
00007d07b35d7b81  vmovaps xmm3, [rsp+0x20]
00007d07b35d7b87  vmovaps xmm4, [rsp+0x30]
00007d07b35d7b8d  vmovaps xmm5, [rsp+0x40]
00007d07b35d7b93  vmovaps xmm6, [rsp+0x50]
00007d07b35d7b99  vmovaps xmm7, [rsp+0x60]
00007d07b35d7b9f  vmovaps xmm8, [rsp+0x70]
00007d07b35d7ba5  vmovaps xmm9, [rsp+0x80]
00007d07b35d7bae  vmovaps xmm10, [rsp+0x90]
00007d07b35d7bb7  vmovaps xmm11, [rsp+0xA0]
00007d07b35d7bc0  vmovaps xmm12, [rsp+0xB0]
00007d07b35d7bc9  vmovaps xmm13, [rsp+0xC0]
00007d07b35d7bd2  vmovaps xmm14, [rsp+0xD0]
00007d07b35d7bdb  vmovaps xmm15, [rsp+0xE0]
00007d07b35d7be4  add rsp, 0xF0
00007d07b35d7beb  pop r11
00007d07b35d7bed  pop r10
00007d07b35d7bef  pop r9
00007d07b35d7bf1  pop r8
00007d07b35d7bf3  pop rsi
00007d07b35d7bf4  pop rdi
00007d07b35d7bf5  pop rdx
00007d07b35d7bf6  pop rcx
00007d07b35d7bf7  pop rax
00007d07b35d7bf8  add rsp, 0x08
00007d07b35d7bfc  jmp 0x00007D07B35D5DCB
00007d07b35d7c01  call 0x00007D07B34E5820
00007d07b35d7c06  jmp 0x00007D07B35D5DD8
00007d07b35d7c0b  sub rsp, 0x08
00007d07b35d7c0f  push rax
00007d07b35d7c10  push rcx
00007d07b35d7c11  push rdx
00007d07b35d7c12  push rdi
00007d07b35d7c13  push rsi
00007d07b35d7c14  push r8
00007d07b35d7c16  push r9
00007d07b35d7c18  push r10
00007d07b35d7c1a  push r11
00007d07b35d7c1c  sub rsp, 0xF0
00007d07b35d7c23  vmovaps [rsp], xmm0
00007d07b35d7c28  vmovaps [rsp+0x10], xmm2
00007d07b35d7c2e  vmovaps [rsp+0x20], xmm3
00007d07b35d7c34  vmovaps [rsp+0x30], xmm4
00007d07b35d7c3a  vmovaps [rsp+0x40], xmm5
00007d07b35d7c40  vmovaps [rsp+0x50], xmm6
00007d07b35d7c46  vmovaps [rsp+0x60], xmm7
00007d07b35d7c4c  vmovaps [rsp+0x70], xmm8
00007d07b35d7c52  vmovaps [rsp+0x80], xmm9
00007d07b35d7c5b  vmovaps [rsp+0x90], xmm10
00007d07b35d7c64  vmovaps [rsp+0xA0], xmm11
00007d07b35d7c6d  vmovaps [rsp+0xB0], xmm12
00007d07b35d7c76  vmovaps [rsp+0xC0], xmm13
00007d07b35d7c7f  vmovaps [rsp+0xD0], xmm14
00007d07b35d7c88  vmovaps [rsp+0xE0], xmm15
00007d07b35d7c91  sub rsp, 0x30
00007d07b35d7c95  movaps [rsp], xmm1
00007d07b35d7c99  movaps [rsp+0x10], xmm5
00007d07b35d7c9e  movaps [rsp+0x20], xmm7
00007d07b35d7ca3  lea rdi, [rsp]
00007d07b35d7ca7  mov esi, 0x00
00007d07b35d7cac  mov rax, 0x5D0AA712D530
00007d07b35d7cb6  call rax
00007d07b35d7cb8  movaps xmm1, [rsp]
00007d07b35d7cbc  add rsp, 0x30
00007d07b35d7cc0  vmovaps xmm0, [rsp]
00007d07b35d7cc5  vmovaps xmm2, [rsp+0x10]
00007d07b35d7ccb  vmovaps xmm3, [rsp+0x20]
00007d07b35d7cd1  vmovaps xmm4, [rsp+0x30]
00007d07b35d7cd7  vmovaps xmm5, [rsp+0x40]
00007d07b35d7cdd  vmovaps xmm6, [rsp+0x50]
00007d07b35d7ce3  vmovaps xmm7, [rsp+0x60]
00007d07b35d7ce9  vmovaps xmm8, [rsp+0x70]
00007d07b35d7cef  vmovaps xmm9, [rsp+0x80]
00007d07b35d7cf8  vmovaps xmm10, [rsp+0x90]
00007d07b35d7d01  vmovaps xmm11, [rsp+0xA0]
00007d07b35d7d0a  vmovaps xmm12, [rsp+0xB0]
00007d07b35d7d13  vmovaps xmm13, [rsp+0xC0]
00007d07b35d7d1c  vmovaps xmm14, [rsp+0xD0]
00007d07b35d7d25  vmovaps xmm15, [rsp+0xE0]
00007d07b35d7d2e  add rsp, 0xF0
00007d07b35d7d35  pop r11
00007d07b35d7d37  pop r10
00007d07b35d7d39  pop r9
00007d07b35d7d3b  pop r8
00007d07b35d7d3d  pop rsi
00007d07b35d7d3e  pop rdi
00007d07b35d7d3f  pop rdx
00007d07b35d7d40  pop rcx
00007d07b35d7d41  pop rax
00007d07b35d7d42  add rsp, 0x08
00007d07b35d7d46  jmp 0x00007D07B35D5E7D
00007d07b35d7d4b  sub rsp, 0x08
00007d07b35d7d4f  push rax
00007d07b35d7d50  push rcx
00007d07b35d7d51  push rdx
00007d07b35d7d52  push rdi
00007d07b35d7d53  push rsi
00007d07b35d7d54  push r8
00007d07b35d7d56  push r9
00007d07b35d7d58  push r10
00007d07b35d7d5a  push r11
00007d07b35d7d5c  sub rsp, 0xF0
00007d07b35d7d63  vmovaps [rsp], xmm0
00007d07b35d7d68  vmovaps [rsp+0x10], xmm1
00007d07b35d7d6e  vmovaps [rsp+0x20], xmm2
00007d07b35d7d74  vmovaps [rsp+0x30], xmm3
00007d07b35d7d7a  vmovaps [rsp+0x40], xmm4
00007d07b35d7d80  vmovaps [rsp+0x50], xmm5
00007d07b35d7d86  vmovaps [rsp+0x60], xmm6
00007d07b35d7d8c  vmovaps [rsp+0x70], xmm8
00007d07b35d7d92  vmovaps [rsp+0x80], xmm9
00007d07b35d7d9b  vmovaps [rsp+0x90], xmm10
00007d07b35d7da4  vmovaps [rsp+0xA0], xmm11
00007d07b35d7dad  vmovaps [rsp+0xB0], xmm12
00007d07b35d7db6  vmovaps [rsp+0xC0], xmm13
00007d07b35d7dbf  vmovaps [rsp+0xD0], xmm14
00007d07b35d7dc8  vmovaps [rsp+0xE0], xmm15
00007d07b35d7dd1  sub rsp, 0x30
00007d07b35d7dd5  movaps [rsp], xmm7
00007d07b35d7dd9  movaps [rsp+0x10], xmm5
00007d07b35d7dde  movaps [rsp+0x20], xmm15
00007d07b35d7de4  lea rdi, [rsp]
00007d07b35d7de8  mov esi, 0x00
00007d07b35d7ded  mov rax, 0x5D0AA712D530
00007d07b35d7df7  call rax
00007d07b35d7df9  movaps xmm7, [rsp]
00007d07b35d7dfd  add rsp, 0x30
00007d07b35d7e01  vmovaps xmm0, [rsp]
00007d07b35d7e06  vmovaps xmm1, [rsp+0x10]
00007d07b35d7e0c  vmovaps xmm2, [rsp+0x20]
00007d07b35d7e12  vmovaps xmm3, [rsp+0x30]
00007d07b35d7e18  vmovaps xmm4, [rsp+0x40]
00007d07b35d7e1e  vmovaps xmm5, [rsp+0x50]
00007d07b35d7e24  vmovaps xmm6, [rsp+0x60]
00007d07b35d7e2a  vmovaps xmm8, [rsp+0x70]
00007d07b35d7e30  vmovaps xmm9, [rsp+0x80]
00007d07b35d7e39  vmovaps xmm10, [rsp+0x90]
00007d07b35d7e42  vmovaps xmm11, [rsp+0xA0]
00007d07b35d7e4b  vmovaps xmm12, [rsp+0xB0]
00007d07b35d7e54  vmovaps xmm13, [rsp+0xC0]
00007d07b35d7e5d  vmovaps xmm14, [rsp+0xD0]
00007d07b35d7e66  vmovaps xmm15, [rsp+0xE0]
00007d07b35d7e6f  add rsp, 0xF0
00007d07b35d7e76  pop r11
00007d07b35d7e78  pop r10
00007d07b35d7e7a  pop r9
00007d07b35d7e7c  pop r8
00007d07b35d7e7e  pop rsi
00007d07b35d7e7f  pop rdi
00007d07b35d7e80  pop rdx
00007d07b35d7e81  pop rcx
00007d07b35d7e82  pop rax
00007d07b35d7e83  add rsp, 0x08
00007d07b35d7e87  jmp 0x00007D07B35D5EB3
00007d07b35d7e8c  call 0x00007D07B34D64F0
00007d07b35d7e91  jmp 0x00007D07B35D5EC0
00007d07b35d7e96  sub rsp, 0x08
00007d07b35d7e9a  push rax
00007d07b35d7e9b  push rcx
00007d07b35d7e9c  push rdx
00007d07b35d7e9d  push rdi
00007d07b35d7e9e  push rsi
00007d07b35d7e9f  push r8
00007d07b35d7ea1  push r9
00007d07b35d7ea3  push r10
00007d07b35d7ea5  push r11
00007d07b35d7ea7  sub rsp, 0xF0
00007d07b35d7eae  vmovaps [rsp], xmm0
00007d07b35d7eb3  vmovaps [rsp+0x10], xmm1
00007d07b35d7eb9  vmovaps [rsp+0x20], xmm2
00007d07b35d7ebf  vmovaps [rsp+0x30], xmm3
00007d07b35d7ec5  vmovaps [rsp+0x40], xmm4
00007d07b35d7ecb  vmovaps [rsp+0x50], xmm5
00007d07b35d7ed1  vmovaps [rsp+0x60], xmm6
00007d07b35d7ed7  vmovaps [rsp+0x70], xmm7
00007d07b35d7edd  vmovaps [rsp+0x80], xmm8
00007d07b35d7ee6  vmovaps [rsp+0x90], xmm9
00007d07b35d7eef  vmovaps [rsp+0xA0], xmm10
00007d07b35d7ef8  vmovaps [rsp+0xB0], xmm11
00007d07b35d7f01  vmovaps [rsp+0xC0], xmm12
00007d07b35d7f0a  vmovaps [rsp+0xD0], xmm13
00007d07b35d7f13  vmovaps [rsp+0xE0], xmm14
00007d07b35d7f1c  sub rsp, 0x30
00007d07b35d7f20  movaps [rsp], xmm15
00007d07b35d7f25  movaps [rsp+0x10], xmm5
00007d07b35d7f2a  movaps [rsp+0x20], xmm3
00007d07b35d7f2f  lea rdi, [rsp]
00007d07b35d7f33  mov esi, 0x00
00007d07b35d7f38  mov rax, 0x5D0AA712D530
00007d07b35d7f42  call rax
00007d07b35d7f44  movaps xmm15, [rsp]
00007d07b35d7f49  add rsp, 0x30
00007d07b35d7f4d  vmovaps xmm0, [rsp]
00007d07b35d7f52  vmovaps xmm1, [rsp+0x10]
00007d07b35d7f58  vmovaps xmm2, [rsp+0x20]
00007d07b35d7f5e  vmovaps xmm3, [rsp+0x30]
00007d07b35d7f64  vmovaps xmm4, [rsp+0x40]
00007d07b35d7f6a  vmovaps xmm5, [rsp+0x50]
00007d07b35d7f70  vmovaps xmm6, [rsp+0x60]
00007d07b35d7f76  vmovaps xmm7, [rsp+0x70]
00007d07b35d7f7c  vmovaps xmm8, [rsp+0x80]
00007d07b35d7f85  vmovaps xmm9, [rsp+0x90]
00007d07b35d7f8e  vmovaps xmm10, [rsp+0xA0]
00007d07b35d7f97  vmovaps xmm11, [rsp+0xB0]
00007d07b35d7fa0  vmovaps xmm12, [rsp+0xC0]
00007d07b35d7fa9  vmovaps xmm13, [rsp+0xD0]
00007d07b35d7fb2  vmovaps xmm14, [rsp+0xE0]
00007d07b35d7fbb  add rsp, 0xF0
00007d07b35d7fc2  pop r11
00007d07b35d7fc4  pop r10
00007d07b35d7fc6  pop r9
00007d07b35d7fc8  pop r8
00007d07b35d7fca  pop rsi
00007d07b35d7fcb  pop rdi
00007d07b35d7fcc  pop rdx
00007d07b35d7fcd  pop rcx
00007d07b35d7fce  pop rax
00007d07b35d7fcf  add rsp, 0x08
00007d07b35d7fd3  jmp 0x00007D07B35D5EE6
00007d07b35d7fd8  sub rsp, 0x08
00007d07b35d7fdc  push rax
00007d07b35d7fdd  push rcx
00007d07b35d7fde  push rdx
00007d07b35d7fdf  push rdi
00007d07b35d7fe0  push rsi
00007d07b35d7fe1  push r8
00007d07b35d7fe3  push r9
00007d07b35d7fe5  push r10
00007d07b35d7fe7  push r11
00007d07b35d7fe9  sub rsp, 0xF0
00007d07b35d7ff0  vmovaps [rsp], xmm0
00007d07b35d7ff5  vmovaps [rsp+0x10], xmm2
00007d07b35d7ffb  vmovaps [rsp+0x20], xmm3
00007d07b35d8001  vmovaps [rsp+0x30], xmm4
00007d07b35d8007  vmovaps [rsp+0x40], xmm5
00007d07b35d800d  vmovaps [rsp+0x50], xmm6
00007d07b35d8013  vmovaps [rsp+0x60], xmm7
00007d07b35d8019  vmovaps [rsp+0x70], xmm8
00007d07b35d801f  vmovaps [rsp+0x80], xmm9
00007d07b35d8028  vmovaps [rsp+0x90], xmm10
00007d07b35d8031  vmovaps [rsp+0xA0], xmm11
00007d07b35d803a  vmovaps [rsp+0xB0], xmm12
00007d07b35d8043  vmovaps [rsp+0xC0], xmm13
00007d07b35d804c  vmovaps [rsp+0xD0], xmm14
00007d07b35d8055  vmovaps [rsp+0xE0], xmm15
00007d07b35d805e  sub rsp, 0x30
00007d07b35d8062  movaps [rsp], xmm1
00007d07b35d8066  movaps [rsp+0x10], xmm5
00007d07b35d806b  movaps [rsp+0x20], xmm4
00007d07b35d8070  lea rdi, [rsp]
00007d07b35d8074  mov esi, 0x00
00007d07b35d8079  mov rax, 0x5D0AA712D530
00007d07b35d8083  call rax
00007d07b35d8085  movaps xmm1, [rsp]
00007d07b35d8089  add rsp, 0x30
00007d07b35d808d  vmovaps xmm0, [rsp]
00007d07b35d8092  vmovaps xmm2, [rsp+0x10]
00007d07b35d8098  vmovaps xmm3, [rsp+0x20]
00007d07b35d809e  vmovaps xmm4, [rsp+0x30]
00007d07b35d80a4  vmovaps xmm5, [rsp+0x40]
00007d07b35d80aa  vmovaps xmm6, [rsp+0x50]
00007d07b35d80b0  vmovaps xmm7, [rsp+0x60]
00007d07b35d80b6  vmovaps xmm8, [rsp+0x70]
00007d07b35d80bc  vmovaps xmm9, [rsp+0x80]
00007d07b35d80c5  vmovaps xmm10, [rsp+0x90]
00007d07b35d80ce  vmovaps xmm11, [rsp+0xA0]
00007d07b35d80d7  vmovaps xmm12, [rsp+0xB0]
00007d07b35d80e0  vmovaps xmm13, [rsp+0xC0]
00007d07b35d80e9  vmovaps xmm14, [rsp+0xD0]
00007d07b35d80f2  vmovaps xmm15, [rsp+0xE0]
00007d07b35d80fb  add rsp, 0xF0
00007d07b35d8102  pop r11
00007d07b35d8104  pop r10
00007d07b35d8106  pop r9
00007d07b35d8108  pop r8
00007d07b35d810a  pop rsi
00007d07b35d810b  pop rdi
00007d07b35d810c  pop rdx
00007d07b35d810d  pop rcx
00007d07b35d810e  pop rax
00007d07b35d810f  add rsp, 0x08
00007d07b35d8113  jmp 0x00007D07B35D5F06
00007d07b35d8118  sub rsp, 0x08
00007d07b35d811c  push rax
00007d07b35d811d  push rcx
00007d07b35d811e  push rdx
00007d07b35d811f  push rdi
00007d07b35d8120  push rsi
00007d07b35d8121  push r8
00007d07b35d8123  push r9
00007d07b35d8125  push r10
00007d07b35d8127  push r11
00007d07b35d8129  sub rsp, 0xF0
00007d07b35d8130  vmovaps [rsp], xmm0
00007d07b35d8135  vmovaps [rsp+0x10], xmm1
00007d07b35d813b  vmovaps [rsp+0x20], xmm2
00007d07b35d8141  vmovaps [rsp+0x30], xmm3
00007d07b35d8147  vmovaps [rsp+0x40], xmm5
00007d07b35d814d  vmovaps [rsp+0x50], xmm6
00007d07b35d8153  vmovaps [rsp+0x60], xmm7
00007d07b35d8159  vmovaps [rsp+0x70], xmm8
00007d07b35d815f  vmovaps [rsp+0x80], xmm9
00007d07b35d8168  vmovaps [rsp+0x90], xmm10
00007d07b35d8171  vmovaps [rsp+0xA0], xmm11
00007d07b35d817a  vmovaps [rsp+0xB0], xmm12
00007d07b35d8183  vmovaps [rsp+0xC0], xmm13
00007d07b35d818c  vmovaps [rsp+0xD0], xmm14
00007d07b35d8195  vmovaps [rsp+0xE0], xmm15
00007d07b35d819e  sub rsp, 0x30
00007d07b35d81a2  movaps [rsp], xmm4
00007d07b35d81a6  movaps [rsp+0x10], xmm3
00007d07b35d81ab  movaps [rsp+0x20], xmm5
00007d07b35d81b0  lea rdi, [rsp]
00007d07b35d81b4  mov esi, 0x00
00007d07b35d81b9  mov rax, 0x5D0AA712D530
00007d07b35d81c3  call rax
00007d07b35d81c5  movaps xmm4, [rsp]
00007d07b35d81c9  add rsp, 0x30
00007d07b35d81cd  vmovaps xmm0, [rsp]
00007d07b35d81d2  vmovaps xmm1, [rsp+0x10]
00007d07b35d81d8  vmovaps xmm2, [rsp+0x20]
00007d07b35d81de  vmovaps xmm3, [rsp+0x30]
00007d07b35d81e4  vmovaps xmm5, [rsp+0x40]
00007d07b35d81ea  vmovaps xmm6, [rsp+0x50]
00007d07b35d81f0  vmovaps xmm7, [rsp+0x60]
00007d07b35d81f6  vmovaps xmm8, [rsp+0x70]
00007d07b35d81fc  vmovaps xmm9, [rsp+0x80]
00007d07b35d8205  vmovaps xmm10, [rsp+0x90]
00007d07b35d820e  vmovaps xmm11, [rsp+0xA0]
00007d07b35d8217  vmovaps xmm12, [rsp+0xB0]
00007d07b35d8220  vmovaps xmm13, [rsp+0xC0]
00007d07b35d8229  vmovaps xmm14, [rsp+0xD0]
00007d07b35d8232  vmovaps xmm15, [rsp+0xE0]
00007d07b35d823b  add rsp, 0xF0
00007d07b35d8242  pop r11
00007d07b35d8244  pop r10
00007d07b35d8246  pop r9
00007d07b35d8248  pop r8
00007d07b35d824a  pop rsi
00007d07b35d824b  pop rdi
00007d07b35d824c  pop rdx
00007d07b35d824d  pop rcx
00007d07b35d824e  pop rax
00007d07b35d824f  add rsp, 0x08
00007d07b35d8253  jmp 0x00007D07B35D5F54
00007d07b35d8258  call 0x00007D07B34D64F0
00007d07b35d825d  jmp 0x00007D07B35D5F61
00007d07b35d8262  sub rsp, 0x08
00007d07b35d8266  push rax
00007d07b35d8267  push rcx
00007d07b35d8268  push rdx
00007d07b35d8269  push rdi
00007d07b35d826a  push rsi
00007d07b35d826b  push r8
00007d07b35d826d  push r9
00007d07b35d826f  push r10
00007d07b35d8271  push r11
00007d07b35d8273  sub rsp, 0xF0
00007d07b35d827a  vmovaps [rsp], xmm0
00007d07b35d827f  vmovaps [rsp+0x10], xmm1
00007d07b35d8285  vmovaps [rsp+0x20], xmm2
00007d07b35d828b  vmovaps [rsp+0x30], xmm3
00007d07b35d8291  vmovaps [rsp+0x40], xmm4
00007d07b35d8297  vmovaps [rsp+0x50], xmm6
00007d07b35d829d  vmovaps [rsp+0x60], xmm7
00007d07b35d82a3  vmovaps [rsp+0x70], xmm8
00007d07b35d82a9  vmovaps [rsp+0x80], xmm9
00007d07b35d82b2  vmovaps [rsp+0x90], xmm10
00007d07b35d82bb  vmovaps [rsp+0xA0], xmm11
00007d07b35d82c4  vmovaps [rsp+0xB0], xmm12
00007d07b35d82cd  vmovaps [rsp+0xC0], xmm13
00007d07b35d82d6  vmovaps [rsp+0xD0], xmm14
00007d07b35d82df  vmovaps [rsp+0xE0], xmm15
00007d07b35d82e8  sub rsp, 0x30
00007d07b35d82ec  movaps [rsp], xmm5
00007d07b35d82f0  movaps [rsp+0x10], xmm6
00007d07b35d82f5  movaps [rsp+0x20], xmm3
00007d07b35d82fa  lea rdi, [rsp]
00007d07b35d82fe  mov esi, 0x00
00007d07b35d8303  mov rax, 0x5D0AA712D530
00007d07b35d830d  call rax
00007d07b35d830f  movaps xmm5, [rsp]
00007d07b35d8313  add rsp, 0x30
00007d07b35d8317  vmovaps xmm0, [rsp]
00007d07b35d831c  vmovaps xmm1, [rsp+0x10]
00007d07b35d8322  vmovaps xmm2, [rsp+0x20]
00007d07b35d8328  vmovaps xmm3, [rsp+0x30]
00007d07b35d832e  vmovaps xmm4, [rsp+0x40]
00007d07b35d8334  vmovaps xmm6, [rsp+0x50]
00007d07b35d833a  vmovaps xmm7, [rsp+0x60]
00007d07b35d8340  vmovaps xmm8, [rsp+0x70]
00007d07b35d8346  vmovaps xmm9, [rsp+0x80]
00007d07b35d834f  vmovaps xmm10, [rsp+0x90]
00007d07b35d8358  vmovaps xmm11, [rsp+0xA0]
00007d07b35d8361  vmovaps xmm12, [rsp+0xB0]
00007d07b35d836a  vmovaps xmm13, [rsp+0xC0]
00007d07b35d8373  vmovaps xmm14, [rsp+0xD0]
00007d07b35d837c  vmovaps xmm15, [rsp+0xE0]
00007d07b35d8385  add rsp, 0xF0
00007d07b35d838c  pop r11
00007d07b35d838e  pop r10
00007d07b35d8390  pop r9
00007d07b35d8392  pop r8
00007d07b35d8394  pop rsi
00007d07b35d8395  pop rdi
00007d07b35d8396  pop rdx
00007d07b35d8397  pop rcx
00007d07b35d8398  pop rax
00007d07b35d8399  add rsp, 0x08
00007d07b35d839d  jmp 0x00007D07B35D5F87
00007d07b35d83a2  sub rsp, 0x08
00007d07b35d83a6  push rax
00007d07b35d83a7  push rcx
00007d07b35d83a8  push rdx
00007d07b35d83a9  push rdi
00007d07b35d83aa  push rsi
00007d07b35d83ab  push r8
00007d07b35d83ad  push r9
00007d07b35d83af  push r10
00007d07b35d83b1  push r11
00007d07b35d83b3  sub rsp, 0xF0
00007d07b35d83ba  vmovaps [rsp], xmm0
00007d07b35d83bf  vmovaps [rsp+0x10], xmm1
00007d07b35d83c5  vmovaps [rsp+0x20], xmm2
00007d07b35d83cb  vmovaps [rsp+0x30], xmm3
00007d07b35d83d1  vmovaps [rsp+0x40], xmm4
00007d07b35d83d7  vmovaps [rsp+0x50], xmm5
00007d07b35d83dd  vmovaps [rsp+0x60], xmm7
00007d07b35d83e3  vmovaps [rsp+0x70], xmm8
00007d07b35d83e9  vmovaps [rsp+0x80], xmm9
00007d07b35d83f2  vmovaps [rsp+0x90], xmm10
00007d07b35d83fb  vmovaps [rsp+0xA0], xmm11
00007d07b35d8404  vmovaps [rsp+0xB0], xmm12
00007d07b35d840d  vmovaps [rsp+0xC0], xmm13
00007d07b35d8416  vmovaps [rsp+0xD0], xmm14
00007d07b35d841f  vmovaps [rsp+0xE0], xmm15
00007d07b35d8428  sub rsp, 0x30
00007d07b35d842c  movaps [rsp], xmm6
00007d07b35d8430  movaps [rsp+0x10], xmm9
00007d07b35d8436  movaps [rsp+0x20], xmm1
00007d07b35d843b  lea rdi, [rsp]
00007d07b35d843f  mov esi, 0x00
00007d07b35d8444  mov rax, 0x5D0AA712D530
00007d07b35d844e  call rax
00007d07b35d8450  movaps xmm6, [rsp]
00007d07b35d8454  add rsp, 0x30
00007d07b35d8458  vmovaps xmm0, [rsp]
00007d07b35d845d  vmovaps xmm1, [rsp+0x10]
00007d07b35d8463  vmovaps xmm2, [rsp+0x20]
00007d07b35d8469  vmovaps xmm3, [rsp+0x30]
00007d07b35d846f  vmovaps xmm4, [rsp+0x40]
00007d07b35d8475  vmovaps xmm5, [rsp+0x50]
00007d07b35d847b  vmovaps xmm7, [rsp+0x60]
00007d07b35d8481  vmovaps xmm8, [rsp+0x70]
00007d07b35d8487  vmovaps xmm9, [rsp+0x80]
00007d07b35d8490  vmovaps xmm10, [rsp+0x90]
00007d07b35d8499  vmovaps xmm11, [rsp+0xA0]
00007d07b35d84a2  vmovaps xmm12, [rsp+0xB0]
00007d07b35d84ab  vmovaps xmm13, [rsp+0xC0]
00007d07b35d84b4  vmovaps xmm14, [rsp+0xD0]
00007d07b35d84bd  vmovaps xmm15, [rsp+0xE0]
00007d07b35d84c6  add rsp, 0xF0
00007d07b35d84cd  pop r11
00007d07b35d84cf  pop r10
00007d07b35d84d1  pop r9
00007d07b35d84d3  pop r8
00007d07b35d84d5  pop rsi
00007d07b35d84d6  pop rdi
00007d07b35d84d7  pop rdx
00007d07b35d84d8  pop rcx
00007d07b35d84d9  pop rax
00007d07b35d84da  add rsp, 0x08
00007d07b35d84de  jmp 0x00007D07B35D5FAB
00007d07b35d84e3  sub rsp, 0x08
00007d07b35d84e7  push rax
00007d07b35d84e8  push rcx
00007d07b35d84e9  push rdx
00007d07b35d84ea  push rdi
00007d07b35d84eb  push rsi
00007d07b35d84ec  push r8
00007d07b35d84ee  push r9
00007d07b35d84f0  push r10
00007d07b35d84f2  push r11
00007d07b35d84f4  sub rsp, 0xF0
00007d07b35d84fb  vmovaps [rsp], xmm0
00007d07b35d8500  vmovaps [rsp+0x10], xmm1
00007d07b35d8506  vmovaps [rsp+0x20], xmm2
00007d07b35d850c  vmovaps [rsp+0x30], xmm3
00007d07b35d8512  vmovaps [rsp+0x40], xmm4
00007d07b35d8518  vmovaps [rsp+0x50], xmm5
00007d07b35d851e  vmovaps [rsp+0x60], xmm6
00007d07b35d8524  vmovaps [rsp+0x70], xmm7
00007d07b35d852a  vmovaps [rsp+0x80], xmm8
00007d07b35d8533  vmovaps [rsp+0x90], xmm10
00007d07b35d853c  vmovaps [rsp+0xA0], xmm11
00007d07b35d8545  vmovaps [rsp+0xB0], xmm12
00007d07b35d854e  vmovaps [rsp+0xC0], xmm13
00007d07b35d8557  vmovaps [rsp+0xD0], xmm14
00007d07b35d8560  vmovaps [rsp+0xE0], xmm15
00007d07b35d8569  sub rsp, 0x30
00007d07b35d856d  movaps [rsp], xmm9
00007d07b35d8572  movaps [rsp+0x10], xmm3
00007d07b35d8577  movaps [rsp+0x20], xmm1
00007d07b35d857c  lea rdi, [rsp]
00007d07b35d8580  mov esi, 0x00
00007d07b35d8585  mov rax, 0x5D0AA712D530
00007d07b35d858f  call rax
00007d07b35d8591  movaps xmm9, [rsp]
00007d07b35d8596  add rsp, 0x30
00007d07b35d859a  vmovaps xmm0, [rsp]
00007d07b35d859f  vmovaps xmm1, [rsp+0x10]
00007d07b35d85a5  vmovaps xmm2, [rsp+0x20]
00007d07b35d85ab  vmovaps xmm3, [rsp+0x30]
00007d07b35d85b1  vmovaps xmm4, [rsp+0x40]
00007d07b35d85b7  vmovaps xmm5, [rsp+0x50]
00007d07b35d85bd  vmovaps xmm6, [rsp+0x60]
00007d07b35d85c3  vmovaps xmm7, [rsp+0x70]
00007d07b35d85c9  vmovaps xmm8, [rsp+0x80]
00007d07b35d85d2  vmovaps xmm10, [rsp+0x90]
00007d07b35d85db  vmovaps xmm11, [rsp+0xA0]
00007d07b35d85e4  vmovaps xmm12, [rsp+0xB0]
00007d07b35d85ed  vmovaps xmm13, [rsp+0xC0]
00007d07b35d85f6  vmovaps xmm14, [rsp+0xD0]
00007d07b35d85ff  vmovaps xmm15, [rsp+0xE0]
00007d07b35d8608  add rsp, 0xF0
00007d07b35d860f  pop r11
00007d07b35d8611  pop r10
00007d07b35d8613  pop r9
00007d07b35d8615  pop r8
00007d07b35d8617  pop rsi
00007d07b35d8618  pop rdi
00007d07b35d8619  pop rdx
00007d07b35d861a  pop rcx
00007d07b35d861b  pop rax
00007d07b35d861c  add rsp, 0x08
00007d07b35d8620  jmp 0x00007D07B35D5FF7
00007d07b35d8625  call 0x00007D07B34D64F0
00007d07b35d862a  jmp 0x00007D07B35D6004
00007d07b35d862f  sub rsp, 0x08
00007d07b35d8633  push rax
00007d07b35d8634  push rcx
00007d07b35d8635  push rdx
00007d07b35d8636  push rdi
00007d07b35d8637  push rsi
00007d07b35d8638  push r8
00007d07b35d863a  push r9
00007d07b35d863c  push r10
00007d07b35d863e  push r11
00007d07b35d8640  sub rsp, 0xF0
00007d07b35d8647  vmovaps [rsp], xmm0
00007d07b35d864c  vmovaps [rsp+0x10], xmm1
00007d07b35d8652  vmovaps [rsp+0x20], xmm2
00007d07b35d8658  vmovaps [rsp+0x30], xmm3
00007d07b35d865e  vmovaps [rsp+0x40], xmm4
00007d07b35d8664  vmovaps [rsp+0x50], xmm5
00007d07b35d866a  vmovaps [rsp+0x60], xmm6
00007d07b35d8670  vmovaps [rsp+0x70], xmm7
00007d07b35d8676  vmovaps [rsp+0x80], xmm8
00007d07b35d867f  vmovaps [rsp+0x90], xmm9
00007d07b35d8688  vmovaps [rsp+0xA0], xmm10
00007d07b35d8691  vmovaps [rsp+0xB0], xmm11
00007d07b35d869a  vmovaps [rsp+0xC0], xmm12
00007d07b35d86a3  vmovaps [rsp+0xD0], xmm13
00007d07b35d86ac  vmovaps [rsp+0xE0], xmm14
00007d07b35d86b5  sub rsp, 0x30
00007d07b35d86b9  movaps [rsp], xmm15
00007d07b35d86be  movaps [rsp+0x10], xmm3
00007d07b35d86c3  movaps [rsp+0x20], xmm7
00007d07b35d86c8  lea rdi, [rsp]
00007d07b35d86cc  mov esi, 0x00
00007d07b35d86d1  mov rax, 0x5D0AA712D530
00007d07b35d86db  call rax
00007d07b35d86dd  movaps xmm15, [rsp]
00007d07b35d86e2  add rsp, 0x30
00007d07b35d86e6  vmovaps xmm0, [rsp]
00007d07b35d86eb  vmovaps xmm1, [rsp+0x10]
00007d07b35d86f1  vmovaps xmm2, [rsp+0x20]
00007d07b35d86f7  vmovaps xmm3, [rsp+0x30]
00007d07b35d86fd  vmovaps xmm4, [rsp+0x40]
00007d07b35d8703  vmovaps xmm5, [rsp+0x50]
00007d07b35d8709  vmovaps xmm6, [rsp+0x60]
00007d07b35d870f  vmovaps xmm7, [rsp+0x70]
00007d07b35d8715  vmovaps xmm8, [rsp+0x80]
00007d07b35d871e  vmovaps xmm9, [rsp+0x90]
00007d07b35d8727  vmovaps xmm10, [rsp+0xA0]
00007d07b35d8730  vmovaps xmm11, [rsp+0xB0]
00007d07b35d8739  vmovaps xmm12, [rsp+0xC0]
00007d07b35d8742  vmovaps xmm13, [rsp+0xD0]
00007d07b35d874b  vmovaps xmm14, [rsp+0xE0]
00007d07b35d8754  add rsp, 0xF0
00007d07b35d875b  pop r11
00007d07b35d875d  pop r10
00007d07b35d875f  pop r9
00007d07b35d8761  pop r8
00007d07b35d8763  pop rsi
00007d07b35d8764  pop rdi
00007d07b35d8765  pop rdx
00007d07b35d8766  pop rcx
00007d07b35d8767  pop rax
00007d07b35d8768  add rsp, 0x08
00007d07b35d876c  jmp 0x00007D07B35D6030
00007d07b35d8771  sub rsp, 0x08
00007d07b35d8775  push rax
00007d07b35d8776  push rcx
00007d07b35d8777  push rdx
00007d07b35d8778  push rdi
00007d07b35d8779  push rsi
00007d07b35d877a  push r8
00007d07b35d877c  push r9
00007d07b35d877e  push r10
00007d07b35d8780  push r11
00007d07b35d8782  sub rsp, 0xF0
00007d07b35d8789  vmovaps [rsp], xmm0
00007d07b35d878e  vmovaps [rsp+0x10], xmm1
00007d07b35d8794  vmovaps [rsp+0x20], xmm2
00007d07b35d879a  vmovaps [rsp+0x30], xmm4
00007d07b35d87a0  vmovaps [rsp+0x40], xmm5
00007d07b35d87a6  vmovaps [rsp+0x50], xmm6
00007d07b35d87ac  vmovaps [rsp+0x60], xmm7
00007d07b35d87b2  vmovaps [rsp+0x70], xmm8
00007d07b35d87b8  vmovaps [rsp+0x80], xmm9
00007d07b35d87c1  vmovaps [rsp+0x90], xmm10
00007d07b35d87ca  vmovaps [rsp+0xA0], xmm11
00007d07b35d87d3  vmovaps [rsp+0xB0], xmm12
00007d07b35d87dc  vmovaps [rsp+0xC0], xmm13
00007d07b35d87e5  vmovaps [rsp+0xD0], xmm14
00007d07b35d87ee  vmovaps [rsp+0xE0], xmm15
00007d07b35d87f7  sub rsp, 0x30
00007d07b35d87fb  movaps [rsp], xmm3
00007d07b35d87ff  movaps [rsp+0x10], xmm1
00007d07b35d8804  movaps [rsp+0x20], xmm15
00007d07b35d880a  lea rdi, [rsp]
00007d07b35d880e  mov esi, 0x00
00007d07b35d8813  mov rax, 0x5D0AA712D530
00007d07b35d881d  call rax
00007d07b35d881f  movaps xmm3, [rsp]
00007d07b35d8823  add rsp, 0x30
00007d07b35d8827  vmovaps xmm0, [rsp]
00007d07b35d882c  vmovaps xmm1, [rsp+0x10]
00007d07b35d8832  vmovaps xmm2, [rsp+0x20]
00007d07b35d8838  vmovaps xmm4, [rsp+0x30]
00007d07b35d883e  vmovaps xmm5, [rsp+0x40]
00007d07b35d8844  vmovaps xmm6, [rsp+0x50]
00007d07b35d884a  vmovaps xmm7, [rsp+0x60]
00007d07b35d8850  vmovaps xmm8, [rsp+0x70]
00007d07b35d8856  vmovaps xmm9, [rsp+0x80]
00007d07b35d885f  vmovaps xmm10, [rsp+0x90]
00007d07b35d8868  vmovaps xmm11, [rsp+0xA0]
00007d07b35d8871  vmovaps xmm12, [rsp+0xB0]
00007d07b35d887a  vmovaps xmm13, [rsp+0xC0]
00007d07b35d8883  vmovaps xmm14, [rsp+0xD0]
00007d07b35d888c  vmovaps xmm15, [rsp+0xE0]
00007d07b35d8895  add rsp, 0xF0
00007d07b35d889c  pop r11
00007d07b35d889e  pop r10
00007d07b35d88a0  pop r9
00007d07b35d88a2  pop r8
00007d07b35d88a4  pop rsi
00007d07b35d88a5  pop rdi
00007d07b35d88a6  pop rdx
00007d07b35d88a7  pop rcx
00007d07b35d88a8  pop rax
00007d07b35d88a9  add rsp, 0x08
00007d07b35d88ad  jmp 0x00007D07B35D60BF
00007d07b35d88b2  call 0x00007D07B34D64F0
00007d07b35d88b7  jmp 0x00007D07B35D60C9
00007d07b35d88bc  sub rsp, 0x08
00007d07b35d88c0  push rax
00007d07b35d88c1  push rcx
00007d07b35d88c2  push rdx
00007d07b35d88c3  push rdi
00007d07b35d88c4  push rsi
00007d07b35d88c5  push r8
00007d07b35d88c7  push r9
00007d07b35d88c9  push r10
00007d07b35d88cb  push r11
00007d07b35d88cd  sub rsp, 0xF0
00007d07b35d88d4  vmovaps [rsp], xmm0
00007d07b35d88d9  vmovaps [rsp+0x10], xmm1
00007d07b35d88df  vmovaps [rsp+0x20], xmm2
00007d07b35d88e5  vmovaps [rsp+0x30], xmm3
00007d07b35d88eb  vmovaps [rsp+0x40], xmm4
00007d07b35d88f1  vmovaps [rsp+0x50], xmm5
00007d07b35d88f7  vmovaps [rsp+0x60], xmm6
00007d07b35d88fd  vmovaps [rsp+0x70], xmm7
00007d07b35d8903  vmovaps [rsp+0x80], xmm8
00007d07b35d890c  vmovaps [rsp+0x90], xmm9
00007d07b35d8915  vmovaps [rsp+0xA0], xmm10
00007d07b35d891e  vmovaps [rsp+0xB0], xmm11
00007d07b35d8927  vmovaps [rsp+0xC0], xmm12
00007d07b35d8930  vmovaps [rsp+0xD0], xmm13
00007d07b35d8939  vmovaps [rsp+0xE0], xmm14
00007d07b35d8942  sub rsp, 0x30
00007d07b35d8946  movaps [rsp], xmm15
00007d07b35d894b  movaps [rsp+0x10], xmm14
00007d07b35d8951  movaps [rsp+0x20], xmm4
00007d07b35d8956  lea rdi, [rsp]
00007d07b35d895a  mov esi, 0x00
00007d07b35d895f  mov rax, 0x5D0AA712D530
00007d07b35d8969  call rax
00007d07b35d896b  movaps xmm15, [rsp]
00007d07b35d8970  add rsp, 0x30
00007d07b35d8974  vmovaps xmm0, [rsp]
00007d07b35d8979  vmovaps xmm1, [rsp+0x10]
00007d07b35d897f  vmovaps xmm2, [rsp+0x20]
00007d07b35d8985  vmovaps xmm3, [rsp+0x30]
00007d07b35d898b  vmovaps xmm4, [rsp+0x40]
00007d07b35d8991  vmovaps xmm5, [rsp+0x50]
00007d07b35d8997  vmovaps xmm6, [rsp+0x60]
00007d07b35d899d  vmovaps xmm7, [rsp+0x70]
00007d07b35d89a3  vmovaps xmm8, [rsp+0x80]
00007d07b35d89ac  vmovaps xmm9, [rsp+0x90]
00007d07b35d89b5  vmovaps xmm10, [rsp+0xA0]
00007d07b35d89be  vmovaps xmm11, [rsp+0xB0]
00007d07b35d89c7  vmovaps xmm12, [rsp+0xC0]
00007d07b35d89d0  vmovaps xmm13, [rsp+0xD0]
00007d07b35d89d9  vmovaps xmm14, [rsp+0xE0]
00007d07b35d89e2  add rsp, 0xF0
00007d07b35d89e9  pop r11
00007d07b35d89eb  pop r10
00007d07b35d89ed  pop r9
00007d07b35d89ef  pop r8
00007d07b35d89f1  pop rsi
00007d07b35d89f2  pop rdi
00007d07b35d89f3  pop rdx
00007d07b35d89f4  pop rcx
00007d07b35d89f5  pop rax
00007d07b35d89f6  add rsp, 0x08
00007d07b35d89fa  jmp 0x00007D07B35D60F7
00007d07b35d89ff  sub rsp, 0x08
00007d07b35d8a03  push rax
00007d07b35d8a04  push rcx
00007d07b35d8a05  push rdx
00007d07b35d8a06  push rdi
00007d07b35d8a07  push rsi
00007d07b35d8a08  push r8
00007d07b35d8a0a  push r9
00007d07b35d8a0c  push r10
00007d07b35d8a0e  push r11
00007d07b35d8a10  sub rsp, 0xF0
00007d07b35d8a17  vmovaps [rsp], xmm0
00007d07b35d8a1c  vmovaps [rsp+0x10], xmm1
00007d07b35d8a22  vmovaps [rsp+0x20], xmm2
00007d07b35d8a28  vmovaps [rsp+0x30], xmm3
00007d07b35d8a2e  vmovaps [rsp+0x40], xmm4
00007d07b35d8a34  vmovaps [rsp+0x50], xmm5
00007d07b35d8a3a  vmovaps [rsp+0x60], xmm6
00007d07b35d8a40  vmovaps [rsp+0x70], xmm7
00007d07b35d8a46  vmovaps [rsp+0x80], xmm8
00007d07b35d8a4f  vmovaps [rsp+0x90], xmm9
00007d07b35d8a58  vmovaps [rsp+0xA0], xmm10
00007d07b35d8a61  vmovaps [rsp+0xB0], xmm11
00007d07b35d8a6a  vmovaps [rsp+0xC0], xmm12
00007d07b35d8a73  vmovaps [rsp+0xD0], xmm13
00007d07b35d8a7c  vmovaps [rsp+0xE0], xmm15
00007d07b35d8a85  sub rsp, 0x30
00007d07b35d8a89  movaps [rsp], xmm14
00007d07b35d8a8e  movaps [rsp+0x10], xmm2
00007d07b35d8a93  movaps [rsp+0x20], xmm1
00007d07b35d8a98  lea rdi, [rsp]
00007d07b35d8a9c  mov esi, 0x00
00007d07b35d8aa1  mov rax, 0x5D0AA712D530
00007d07b35d8aab  call rax
00007d07b35d8aad  movaps xmm14, [rsp]
00007d07b35d8ab2  add rsp, 0x30
00007d07b35d8ab6  vmovaps xmm0, [rsp]
00007d07b35d8abb  vmovaps xmm1, [rsp+0x10]
00007d07b35d8ac1  vmovaps xmm2, [rsp+0x20]
00007d07b35d8ac7  vmovaps xmm3, [rsp+0x30]
00007d07b35d8acd  vmovaps xmm4, [rsp+0x40]
00007d07b35d8ad3  vmovaps xmm5, [rsp+0x50]
00007d07b35d8ad9  vmovaps xmm6, [rsp+0x60]
00007d07b35d8adf  vmovaps xmm7, [rsp+0x70]
00007d07b35d8ae5  vmovaps xmm8, [rsp+0x80]
00007d07b35d8aee  vmovaps xmm9, [rsp+0x90]
00007d07b35d8af7  vmovaps xmm10, [rsp+0xA0]
00007d07b35d8b00  vmovaps xmm11, [rsp+0xB0]
00007d07b35d8b09  vmovaps xmm12, [rsp+0xC0]
00007d07b35d8b12  vmovaps xmm13, [rsp+0xD0]
00007d07b35d8b1b  vmovaps xmm15, [rsp+0xE0]
00007d07b35d8b24  add rsp, 0xF0
00007d07b35d8b2b  pop r11
00007d07b35d8b2d  pop r10
00007d07b35d8b2f  pop r9
00007d07b35d8b31  pop r8
00007d07b35d8b33  pop rsi
00007d07b35d8b34  pop rdi
00007d07b35d8b35  pop rdx
00007d07b35d8b36  pop rcx
00007d07b35d8b37  pop rax
00007d07b35d8b38  add rsp, 0x08
00007d07b35d8b3c  jmp 0x00007D07B35D611D
00007d07b35d8b41  sub rsp, 0x08
00007d07b35d8b45  push rax
00007d07b35d8b46  push rcx
00007d07b35d8b47  push rdx
00007d07b35d8b48  push rdi
00007d07b35d8b49  push rsi
00007d07b35d8b4a  push r8
00007d07b35d8b4c  push r9
00007d07b35d8b4e  push r10
00007d07b35d8b50  push r11
00007d07b35d8b52  sub rsp, 0xF0
00007d07b35d8b59  vmovaps [rsp], xmm0
00007d07b35d8b5e  vmovaps [rsp+0x10], xmm2
00007d07b35d8b64  vmovaps [rsp+0x20], xmm3
00007d07b35d8b6a  vmovaps [rsp+0x30], xmm4
00007d07b35d8b70  vmovaps [rsp+0x40], xmm5
00007d07b35d8b76  vmovaps [rsp+0x50], xmm6
00007d07b35d8b7c  vmovaps [rsp+0x60], xmm7
00007d07b35d8b82  vmovaps [rsp+0x70], xmm8
00007d07b35d8b88  vmovaps [rsp+0x80], xmm9
00007d07b35d8b91  vmovaps [rsp+0x90], xmm10
00007d07b35d8b9a  vmovaps [rsp+0xA0], xmm11
00007d07b35d8ba3  vmovaps [rsp+0xB0], xmm12
00007d07b35d8bac  vmovaps [rsp+0xC0], xmm13
00007d07b35d8bb5  vmovaps [rsp+0xD0], xmm14
00007d07b35d8bbe  vmovaps [rsp+0xE0], xmm15
00007d07b35d8bc7  sub rsp, 0x30
00007d07b35d8bcb  movaps [rsp], xmm1
00007d07b35d8bcf  movaps [rsp+0x10], xmm4
00007d07b35d8bd4  movaps [rsp+0x20], xmm9
00007d07b35d8bda  lea rdi, [rsp]
00007d07b35d8bde  mov esi, 0x00
00007d07b35d8be3  mov rax, 0x5D0AA712D530
00007d07b35d8bed  call rax
00007d07b35d8bef  movaps xmm1, [rsp]
00007d07b35d8bf3  add rsp, 0x30
00007d07b35d8bf7  vmovaps xmm0, [rsp]
00007d07b35d8bfc  vmovaps xmm2, [rsp+0x10]
00007d07b35d8c02  vmovaps xmm3, [rsp+0x20]
00007d07b35d8c08  vmovaps xmm4, [rsp+0x30]
00007d07b35d8c0e  vmovaps xmm5, [rsp+0x40]
00007d07b35d8c14  vmovaps xmm6, [rsp+0x50]
00007d07b35d8c1a  vmovaps xmm7, [rsp+0x60]
00007d07b35d8c20  vmovaps xmm8, [rsp+0x70]
00007d07b35d8c26  vmovaps xmm9, [rsp+0x80]
00007d07b35d8c2f  vmovaps xmm10, [rsp+0x90]
00007d07b35d8c38  vmovaps xmm11, [rsp+0xA0]
00007d07b35d8c41  vmovaps xmm12, [rsp+0xB0]
00007d07b35d8c4a  vmovaps xmm13, [rsp+0xC0]
00007d07b35d8c53  vmovaps xmm14, [rsp+0xD0]
00007d07b35d8c5c  vmovaps xmm15, [rsp+0xE0]
00007d07b35d8c65  add rsp, 0xF0
00007d07b35d8c6c  pop r11
00007d07b35d8c6e  pop r10
00007d07b35d8c70  pop r9
00007d07b35d8c72  pop r8
00007d07b35d8c74  pop rsi
00007d07b35d8c75  pop rdi
00007d07b35d8c76  pop rdx
00007d07b35d8c77  pop rcx
00007d07b35d8c78  pop rax
00007d07b35d8c79  add rsp, 0x08
00007d07b35d8c7d  jmp 0x00007D07B35D613B
00007d07b35d8c82  sub rsp, 0x08
00007d07b35d8c86  push rax
00007d07b35d8c87  push rcx
00007d07b35d8c88  push rdx
00007d07b35d8c89  push rdi
00007d07b35d8c8a  push rsi
00007d07b35d8c8b  push r8
00007d07b35d8c8d  push r9
00007d07b35d8c8f  push r10
00007d07b35d8c91  push r11
00007d07b35d8c93  sub rsp, 0xF0
00007d07b35d8c9a  vmovaps [rsp], xmm0
00007d07b35d8c9f  vmovaps [rsp+0x10], xmm1
00007d07b35d8ca5  vmovaps [rsp+0x20], xmm2
00007d07b35d8cab  vmovaps [rsp+0x30], xmm3
00007d07b35d8cb1  vmovaps [rsp+0x40], xmm5
00007d07b35d8cb7  vmovaps [rsp+0x50], xmm6
00007d07b35d8cbd  vmovaps [rsp+0x60], xmm7
00007d07b35d8cc3  vmovaps [rsp+0x70], xmm8
00007d07b35d8cc9  vmovaps [rsp+0x80], xmm9
00007d07b35d8cd2  vmovaps [rsp+0x90], xmm10
00007d07b35d8cdb  vmovaps [rsp+0xA0], xmm11
00007d07b35d8ce4  vmovaps [rsp+0xB0], xmm12
00007d07b35d8ced  vmovaps [rsp+0xC0], xmm13
00007d07b35d8cf6  vmovaps [rsp+0xD0], xmm14
00007d07b35d8cff  vmovaps [rsp+0xE0], xmm15
00007d07b35d8d08  sub rsp, 0x30
00007d07b35d8d0c  movaps [rsp], xmm4
00007d07b35d8d10  movaps [rsp+0x10], xmm2
00007d07b35d8d15  movaps [rsp+0x20], xmm9
00007d07b35d8d1b  lea rdi, [rsp]
00007d07b35d8d1f  mov esi, 0x00
00007d07b35d8d24  mov rax, 0x5D0AA712D530
00007d07b35d8d2e  call rax
00007d07b35d8d30  movaps xmm4, [rsp]
00007d07b35d8d34  add rsp, 0x30
00007d07b35d8d38  vmovaps xmm0, [rsp]
00007d07b35d8d3d  vmovaps xmm1, [rsp+0x10]
00007d07b35d8d43  vmovaps xmm2, [rsp+0x20]
00007d07b35d8d49  vmovaps xmm3, [rsp+0x30]
00007d07b35d8d4f  vmovaps xmm5, [rsp+0x40]
00007d07b35d8d55  vmovaps xmm6, [rsp+0x50]
00007d07b35d8d5b  vmovaps xmm7, [rsp+0x60]
00007d07b35d8d61  vmovaps xmm8, [rsp+0x70]
00007d07b35d8d67  vmovaps xmm9, [rsp+0x80]
00007d07b35d8d70  vmovaps xmm10, [rsp+0x90]
00007d07b35d8d79  vmovaps xmm11, [rsp+0xA0]
00007d07b35d8d82  vmovaps xmm12, [rsp+0xB0]
00007d07b35d8d8b  vmovaps xmm13, [rsp+0xC0]
00007d07b35d8d94  vmovaps xmm14, [rsp+0xD0]
00007d07b35d8d9d  vmovaps xmm15, [rsp+0xE0]
00007d07b35d8da6  add rsp, 0xF0
00007d07b35d8dad  pop r11
00007d07b35d8daf  pop r10
00007d07b35d8db1  pop r9
00007d07b35d8db3  pop r8
00007d07b35d8db5  pop rsi
00007d07b35d8db6  pop rdi
00007d07b35d8db7  pop rdx
00007d07b35d8db8  pop rcx
00007d07b35d8db9  pop rax
00007d07b35d8dba  add rsp, 0x08
00007d07b35d8dbe  jmp 0x00007D07B35D616B
00007d07b35d8dc3  sub rsp, 0x08
00007d07b35d8dc7  push rax
00007d07b35d8dc8  push rcx
00007d07b35d8dc9  push rdx
00007d07b35d8dca  push rdi
00007d07b35d8dcb  push rsi
00007d07b35d8dcc  push r8
00007d07b35d8dce  push r9
00007d07b35d8dd0  push r10
00007d07b35d8dd2  push r11
00007d07b35d8dd4  sub rsp, 0xF0
00007d07b35d8ddb  vmovaps [rsp], xmm0
00007d07b35d8de0  vmovaps [rsp+0x10], xmm1
00007d07b35d8de6  vmovaps [rsp+0x20], xmm2
00007d07b35d8dec  vmovaps [rsp+0x30], xmm3
00007d07b35d8df2  vmovaps [rsp+0x40], xmm4
00007d07b35d8df8  vmovaps [rsp+0x50], xmm5
00007d07b35d8dfe  vmovaps [rsp+0x60], xmm6
00007d07b35d8e04  vmovaps [rsp+0x70], xmm7
00007d07b35d8e0a  vmovaps [rsp+0x80], xmm8
00007d07b35d8e13  vmovaps [rsp+0x90], xmm10
00007d07b35d8e1c  vmovaps [rsp+0xA0], xmm11
00007d07b35d8e25  vmovaps [rsp+0xB0], xmm12
00007d07b35d8e2e  vmovaps [rsp+0xC0], xmm13
00007d07b35d8e37  vmovaps [rsp+0xD0], xmm14
00007d07b35d8e40  vmovaps [rsp+0xE0], xmm15
00007d07b35d8e49  sub rsp, 0x30
00007d07b35d8e4d  movaps [rsp], xmm9
00007d07b35d8e52  movaps [rsp+0x10], xmm2
00007d07b35d8e57  movaps [rsp+0x20], xmm1
00007d07b35d8e5c  lea rdi, [rsp]
00007d07b35d8e60  mov esi, 0x00
00007d07b35d8e65  mov rax, 0x5D0AA712D530
00007d07b35d8e6f  call rax
00007d07b35d8e71  movaps xmm9, [rsp]
00007d07b35d8e76  add rsp, 0x30
00007d07b35d8e7a  vmovaps xmm0, [rsp]
00007d07b35d8e7f  vmovaps xmm1, [rsp+0x10]
00007d07b35d8e85  vmovaps xmm2, [rsp+0x20]
00007d07b35d8e8b  vmovaps xmm3, [rsp+0x30]
00007d07b35d8e91  vmovaps xmm4, [rsp+0x40]
00007d07b35d8e97  vmovaps xmm5, [rsp+0x50]
00007d07b35d8e9d  vmovaps xmm6, [rsp+0x60]
00007d07b35d8ea3  vmovaps xmm7, [rsp+0x70]
00007d07b35d8ea9  vmovaps xmm8, [rsp+0x80]
00007d07b35d8eb2  vmovaps xmm10, [rsp+0x90]
00007d07b35d8ebb  vmovaps xmm11, [rsp+0xA0]
00007d07b35d8ec4  vmovaps xmm12, [rsp+0xB0]
00007d07b35d8ecd  vmovaps xmm13, [rsp+0xC0]
00007d07b35d8ed6  vmovaps xmm14, [rsp+0xD0]
00007d07b35d8edf  vmovaps xmm15, [rsp+0xE0]
00007d07b35d8ee8  add rsp, 0xF0
00007d07b35d8eef  pop r11
00007d07b35d8ef1  pop r10
00007d07b35d8ef3  pop r9
00007d07b35d8ef5  pop r8
00007d07b35d8ef7  pop rsi
00007d07b35d8ef8  pop rdi
00007d07b35d8ef9  pop rdx
00007d07b35d8efa  pop rcx
00007d07b35d8efb  pop rax
00007d07b35d8efc  add rsp, 0x08
00007d07b35d8f00  jmp 0x00007D07B35D61A1
00007d07b35d8f05  sub rsp, 0x08
00007d07b35d8f09  push rax
00007d07b35d8f0a  push rcx
00007d07b35d8f0b  push rdx
00007d07b35d8f0c  push rdi
00007d07b35d8f0d  push rsi
00007d07b35d8f0e  push r8
00007d07b35d8f10  push r9
00007d07b35d8f12  push r10
00007d07b35d8f14  push r11
00007d07b35d8f16  sub rsp, 0xF0
00007d07b35d8f1d  vmovaps [rsp], xmm0
00007d07b35d8f22  vmovaps [rsp+0x10], xmm2
00007d07b35d8f28  vmovaps [rsp+0x20], xmm3
00007d07b35d8f2e  vmovaps [rsp+0x30], xmm4
00007d07b35d8f34  vmovaps [rsp+0x40], xmm5
00007d07b35d8f3a  vmovaps [rsp+0x50], xmm6
00007d07b35d8f40  vmovaps [rsp+0x60], xmm7
00007d07b35d8f46  vmovaps [rsp+0x70], xmm8
00007d07b35d8f4c  vmovaps [rsp+0x80], xmm9
00007d07b35d8f55  vmovaps [rsp+0x90], xmm10
00007d07b35d8f5e  vmovaps [rsp+0xA0], xmm11
00007d07b35d8f67  vmovaps [rsp+0xB0], xmm12
00007d07b35d8f70  vmovaps [rsp+0xC0], xmm13
00007d07b35d8f79  vmovaps [rsp+0xD0], xmm14
00007d07b35d8f82  vmovaps [rsp+0xE0], xmm15
00007d07b35d8f8b  sub rsp, 0x30
00007d07b35d8f8f  movaps [rsp], xmm1
00007d07b35d8f93  movaps [rsp+0x10], xmm15
00007d07b35d8f99  movaps [rsp+0x20], xmm6
00007d07b35d8f9e  lea rdi, [rsp]
00007d07b35d8fa2  mov esi, 0x00
00007d07b35d8fa7  mov rax, 0x5D0AA712D530
00007d07b35d8fb1  call rax
00007d07b35d8fb3  movaps xmm1, [rsp]
00007d07b35d8fb7  add rsp, 0x30
00007d07b35d8fbb  vmovaps xmm0, [rsp]
00007d07b35d8fc0  vmovaps xmm2, [rsp+0x10]
00007d07b35d8fc6  vmovaps xmm3, [rsp+0x20]
00007d07b35d8fcc  vmovaps xmm4, [rsp+0x30]
00007d07b35d8fd2  vmovaps xmm5, [rsp+0x40]
00007d07b35d8fd8  vmovaps xmm6, [rsp+0x50]
00007d07b35d8fde  vmovaps xmm7, [rsp+0x60]
00007d07b35d8fe4  vmovaps xmm8, [rsp+0x70]
00007d07b35d8fea  vmovaps xmm9, [rsp+0x80]
00007d07b35d8ff3  vmovaps xmm10, [rsp+0x90]
00007d07b35d8ffc  vmovaps xmm11, [rsp+0xA0]
00007d07b35d9005  vmovaps xmm12, [rsp+0xB0]
00007d07b35d900e  vmovaps xmm13, [rsp+0xC0]
00007d07b35d9017  vmovaps xmm14, [rsp+0xD0]
00007d07b35d9020  vmovaps xmm15, [rsp+0xE0]
00007d07b35d9029  add rsp, 0xF0
00007d07b35d9030  pop r11
00007d07b35d9032  pop r10
00007d07b35d9034  pop r9
00007d07b35d9036  pop r8
00007d07b35d9038  pop rsi
00007d07b35d9039  pop rdi
00007d07b35d903a  pop rdx
00007d07b35d903b  pop rcx
00007d07b35d903c  pop rax
00007d07b35d903d  add rsp, 0x08
00007d07b35d9041  jmp 0x00007D07B35D61C2
00007d07b35d9046  sub rsp, 0x08
00007d07b35d904a  push rax
00007d07b35d904b  push rcx
00007d07b35d904c  push rdx
00007d07b35d904d  push rdi
00007d07b35d904e  push rsi
00007d07b35d904f  push r8
00007d07b35d9051  push r9
00007d07b35d9053  push r10
00007d07b35d9055  push r11
00007d07b35d9057  sub rsp, 0xF0
00007d07b35d905e  vmovaps [rsp], xmm0
00007d07b35d9063  vmovaps [rsp+0x10], xmm1
00007d07b35d9069  vmovaps [rsp+0x20], xmm2
00007d07b35d906f  vmovaps [rsp+0x30], xmm3
00007d07b35d9075  vmovaps [rsp+0x40], xmm4
00007d07b35d907b  vmovaps [rsp+0x50], xmm5
00007d07b35d9081  vmovaps [rsp+0x60], xmm6
00007d07b35d9087  vmovaps [rsp+0x70], xmm7
00007d07b35d908d  vmovaps [rsp+0x80], xmm8
00007d07b35d9096  vmovaps [rsp+0x90], xmm9
00007d07b35d909f  vmovaps [rsp+0xA0], xmm10
00007d07b35d90a8  vmovaps [rsp+0xB0], xmm11
00007d07b35d90b1  vmovaps [rsp+0xC0], xmm12
00007d07b35d90ba  vmovaps [rsp+0xD0], xmm13
00007d07b35d90c3  vmovaps [rsp+0xE0], xmm14
00007d07b35d90cc  sub rsp, 0x30
00007d07b35d90d0  movaps [rsp], xmm15
00007d07b35d90d5  movaps [rsp+0x10], xmm5
00007d07b35d90da  movaps [rsp+0x20], xmm3
00007d07b35d90df  lea rdi, [rsp]
00007d07b35d90e3  mov esi, 0x00
00007d07b35d90e8  mov rax, 0x5D0AA712D530
00007d07b35d90f2  call rax
00007d07b35d90f4  movaps xmm15, [rsp]
00007d07b35d90f9  add rsp, 0x30
00007d07b35d90fd  vmovaps xmm0, [rsp]
00007d07b35d9102  vmovaps xmm1, [rsp+0x10]
00007d07b35d9108  vmovaps xmm2, [rsp+0x20]
00007d07b35d910e  vmovaps xmm3, [rsp+0x30]
00007d07b35d9114  vmovaps xmm4, [rsp+0x40]
00007d07b35d911a  vmovaps xmm5, [rsp+0x50]
00007d07b35d9120  vmovaps xmm6, [rsp+0x60]
00007d07b35d9126  vmovaps xmm7, [rsp+0x70]
00007d07b35d912c  vmovaps xmm8, [rsp+0x80]
00007d07b35d9135  vmovaps xmm9, [rsp+0x90]
00007d07b35d913e  vmovaps xmm10, [rsp+0xA0]
00007d07b35d9147  vmovaps xmm11, [rsp+0xB0]
00007d07b35d9150  vmovaps xmm12, [rsp+0xC0]
00007d07b35d9159  vmovaps xmm13, [rsp+0xD0]
00007d07b35d9162  vmovaps xmm14, [rsp+0xE0]
00007d07b35d916b  add rsp, 0xF0
00007d07b35d9172  pop r11
00007d07b35d9174  pop r10
00007d07b35d9176  pop r9
00007d07b35d9178  pop r8
00007d07b35d917a  pop rsi
00007d07b35d917b  pop rdi
00007d07b35d917c  pop rdx
00007d07b35d917d  pop rcx
00007d07b35d917e  pop rax
00007d07b35d917f  add rsp, 0x08
00007d07b35d9183  jmp 0x00007D07B35D61DC
00007d07b35d9188  sub rsp, 0x08
00007d07b35d918c  push rax
00007d07b35d918d  push rcx
00007d07b35d918e  push rdx
00007d07b35d918f  push rdi
00007d07b35d9190  push rsi
00007d07b35d9191  push r8
00007d07b35d9193  push r9
00007d07b35d9195  push r10
00007d07b35d9197  push r11
00007d07b35d9199  sub rsp, 0xF0
00007d07b35d91a0  vmovaps [rsp], xmm0
00007d07b35d91a5  vmovaps [rsp+0x10], xmm1
00007d07b35d91ab  vmovaps [rsp+0x20], xmm2
00007d07b35d91b1  vmovaps [rsp+0x30], xmm3
00007d07b35d91b7  vmovaps [rsp+0x40], xmm4
00007d07b35d91bd  vmovaps [rsp+0x50], xmm6
00007d07b35d91c3  vmovaps [rsp+0x60], xmm7
00007d07b35d91c9  vmovaps [rsp+0x70], xmm8
00007d07b35d91cf  vmovaps [rsp+0x80], xmm9
00007d07b35d91d8  vmovaps [rsp+0x90], xmm10
00007d07b35d91e1  vmovaps [rsp+0xA0], xmm11
00007d07b35d91ea  vmovaps [rsp+0xB0], xmm12
00007d07b35d91f3  vmovaps [rsp+0xC0], xmm13
00007d07b35d91fc  vmovaps [rsp+0xD0], xmm14
00007d07b35d9205  vmovaps [rsp+0xE0], xmm15
00007d07b35d920e  sub rsp, 0x30
00007d07b35d9212  movaps [rsp], xmm5
00007d07b35d9216  movaps [rsp+0x10], xmm8
00007d07b35d921c  movaps [rsp+0x20], xmm6
00007d07b35d9221  lea rdi, [rsp]
00007d07b35d9225  mov esi, 0x00
00007d07b35d922a  mov rax, 0x5D0AA712D530
00007d07b35d9234  call rax
00007d07b35d9236  movaps xmm5, [rsp]
00007d07b35d923a  add rsp, 0x30
00007d07b35d923e  vmovaps xmm0, [rsp]
00007d07b35d9243  vmovaps xmm1, [rsp+0x10]
00007d07b35d9249  vmovaps xmm2, [rsp+0x20]
00007d07b35d924f  vmovaps xmm3, [rsp+0x30]
00007d07b35d9255  vmovaps xmm4, [rsp+0x40]
00007d07b35d925b  vmovaps xmm6, [rsp+0x50]
00007d07b35d9261  vmovaps xmm7, [rsp+0x60]
00007d07b35d9267  vmovaps xmm8, [rsp+0x70]
00007d07b35d926d  vmovaps xmm9, [rsp+0x80]
00007d07b35d9276  vmovaps xmm10, [rsp+0x90]
00007d07b35d927f  vmovaps xmm11, [rsp+0xA0]
00007d07b35d9288  vmovaps xmm12, [rsp+0xB0]
00007d07b35d9291  vmovaps xmm13, [rsp+0xC0]
00007d07b35d929a  vmovaps xmm14, [rsp+0xD0]
00007d07b35d92a3  vmovaps xmm15, [rsp+0xE0]
00007d07b35d92ac  add rsp, 0xF0
00007d07b35d92b3  pop r11
00007d07b35d92b5  pop r10
00007d07b35d92b7  pop r9
00007d07b35d92b9  pop r8
00007d07b35d92bb  pop rsi
00007d07b35d92bc  pop rdi
00007d07b35d92bd  pop rdx
00007d07b35d92be  pop rcx
00007d07b35d92bf  pop rax
00007d07b35d92c0  add rsp, 0x08
00007d07b35d92c4  jmp 0x00007D07B35D6200
00007d07b35d92c9  sub rsp, 0x08
00007d07b35d92cd  push rax
00007d07b35d92ce  push rcx
00007d07b35d92cf  push rdx
00007d07b35d92d0  push rdi
00007d07b35d92d1  push rsi
00007d07b35d92d2  push r8
00007d07b35d92d4  push r9
00007d07b35d92d6  push r10
00007d07b35d92d8  push r11
00007d07b35d92da  sub rsp, 0xF0
00007d07b35d92e1  vmovaps [rsp], xmm0
00007d07b35d92e6  vmovaps [rsp+0x10], xmm1
00007d07b35d92ec  vmovaps [rsp+0x20], xmm2
00007d07b35d92f2  vmovaps [rsp+0x30], xmm3
00007d07b35d92f8  vmovaps [rsp+0x40], xmm4
00007d07b35d92fe  vmovaps [rsp+0x50], xmm5
00007d07b35d9304  vmovaps [rsp+0x60], xmm7
00007d07b35d930a  vmovaps [rsp+0x70], xmm8
00007d07b35d9310  vmovaps [rsp+0x80], xmm9
00007d07b35d9319  vmovaps [rsp+0x90], xmm10
00007d07b35d9322  vmovaps [rsp+0xA0], xmm11
00007d07b35d932b  vmovaps [rsp+0xB0], xmm12
00007d07b35d9334  vmovaps [rsp+0xC0], xmm13
00007d07b35d933d  vmovaps [rsp+0xD0], xmm14
00007d07b35d9346  vmovaps [rsp+0xE0], xmm15
00007d07b35d934f  sub rsp, 0x30
00007d07b35d9353  movaps [rsp], xmm6
00007d07b35d9357  movaps [rsp+0x10], xmm10
00007d07b35d935d  movaps [rsp+0x20], xmm8
00007d07b35d9363  lea rdi, [rsp]
00007d07b35d9367  mov esi, 0x00
00007d07b35d936c  mov rax, 0x5D0AA712D530
00007d07b35d9376  call rax
00007d07b35d9378  movaps xmm6, [rsp]
00007d07b35d937c  add rsp, 0x30
00007d07b35d9380  vmovaps xmm0, [rsp]
00007d07b35d9385  vmovaps xmm1, [rsp+0x10]
00007d07b35d938b  vmovaps xmm2, [rsp+0x20]
00007d07b35d9391  vmovaps xmm3, [rsp+0x30]
00007d07b35d9397  vmovaps xmm4, [rsp+0x40]
00007d07b35d939d  vmovaps xmm5, [rsp+0x50]
00007d07b35d93a3  vmovaps xmm7, [rsp+0x60]
00007d07b35d93a9  vmovaps xmm8, [rsp+0x70]
00007d07b35d93af  vmovaps xmm9, [rsp+0x80]
00007d07b35d93b8  vmovaps xmm10, [rsp+0x90]
00007d07b35d93c1  vmovaps xmm11, [rsp+0xA0]
00007d07b35d93ca  vmovaps xmm12, [rsp+0xB0]
00007d07b35d93d3  vmovaps xmm13, [rsp+0xC0]
00007d07b35d93dc  vmovaps xmm14, [rsp+0xD0]
00007d07b35d93e5  vmovaps xmm15, [rsp+0xE0]
00007d07b35d93ee  add rsp, 0xF0
00007d07b35d93f5  pop r11
00007d07b35d93f7  pop r10
00007d07b35d93f9  pop r9
00007d07b35d93fb  pop r8
00007d07b35d93fd  pop rsi
00007d07b35d93fe  pop rdi
00007d07b35d93ff  pop rdx
00007d07b35d9400  pop rcx
00007d07b35d9401  pop rax
00007d07b35d9402  add rsp, 0x08
00007d07b35d9406  jmp 0x00007D07B35D6225
00007d07b35d940b  sub rsp, 0x08
00007d07b35d940f  push rax
00007d07b35d9410  push rcx
00007d07b35d9411  push rdx
00007d07b35d9412  push rdi
00007d07b35d9413  push rsi
00007d07b35d9414  push r8
00007d07b35d9416  push r9
00007d07b35d9418  push r10
00007d07b35d941a  push r11
00007d07b35d941c  sub rsp, 0xF0
00007d07b35d9423  vmovaps [rsp], xmm0
00007d07b35d9428  vmovaps [rsp+0x10], xmm1
00007d07b35d942e  vmovaps [rsp+0x20], xmm2
00007d07b35d9434  vmovaps [rsp+0x30], xmm3
00007d07b35d943a  vmovaps [rsp+0x40], xmm4
00007d07b35d9440  vmovaps [rsp+0x50], xmm5
00007d07b35d9446  vmovaps [rsp+0x60], xmm6
00007d07b35d944c  vmovaps [rsp+0x70], xmm7
00007d07b35d9452  vmovaps [rsp+0x80], xmm8
00007d07b35d945b  vmovaps [rsp+0x90], xmm9
00007d07b35d9464  vmovaps [rsp+0xA0], xmm11
00007d07b35d946d  vmovaps [rsp+0xB0], xmm12
00007d07b35d9476  vmovaps [rsp+0xC0], xmm13
00007d07b35d947f  vmovaps [rsp+0xD0], xmm14
00007d07b35d9488  vmovaps [rsp+0xE0], xmm15
00007d07b35d9491  sub rsp, 0x30
00007d07b35d9495  movaps [rsp], xmm10
00007d07b35d949a  movaps [rsp+0x10], xmm8
00007d07b35d94a0  movaps [rsp+0x20], xmm14
00007d07b35d94a6  lea rdi, [rsp]
00007d07b35d94aa  mov esi, 0x00
00007d07b35d94af  mov rax, 0x5D0AA712D530
00007d07b35d94b9  call rax
00007d07b35d94bb  movaps xmm10, [rsp]
00007d07b35d94c0  add rsp, 0x30
00007d07b35d94c4  vmovaps xmm0, [rsp]
00007d07b35d94c9  vmovaps xmm1, [rsp+0x10]
00007d07b35d94cf  vmovaps xmm2, [rsp+0x20]
00007d07b35d94d5  vmovaps xmm3, [rsp+0x30]
00007d07b35d94db  vmovaps xmm4, [rsp+0x40]
00007d07b35d94e1  vmovaps xmm5, [rsp+0x50]
00007d07b35d94e7  vmovaps xmm6, [rsp+0x60]
00007d07b35d94ed  vmovaps xmm7, [rsp+0x70]
00007d07b35d94f3  vmovaps xmm8, [rsp+0x80]
00007d07b35d94fc  vmovaps xmm9, [rsp+0x90]
00007d07b35d9505  vmovaps xmm11, [rsp+0xA0]
00007d07b35d950e  vmovaps xmm12, [rsp+0xB0]
00007d07b35d9517  vmovaps xmm13, [rsp+0xC0]
00007d07b35d9520  vmovaps xmm14, [rsp+0xD0]
00007d07b35d9529  vmovaps xmm15, [rsp+0xE0]
00007d07b35d9532  add rsp, 0xF0
00007d07b35d9539  pop r11
00007d07b35d953b  pop r10
00007d07b35d953d  pop r9
00007d07b35d953f  pop r8
00007d07b35d9541  pop rsi
00007d07b35d9542  pop rdi
00007d07b35d9543  pop rdx
00007d07b35d9544  pop rcx
00007d07b35d9545  pop rax
00007d07b35d9546  add rsp, 0x08
00007d07b35d954a  jmp 0x00007D07B35D6245
00007d07b35d954f  sub rsp, 0x08
00007d07b35d9553  push rax
00007d07b35d9554  push rcx
00007d07b35d9555  push rdx
00007d07b35d9556  push rdi
00007d07b35d9557  push rsi
00007d07b35d9558  push r8
00007d07b35d955a  push r9
00007d07b35d955c  push r10
00007d07b35d955e  push r11
00007d07b35d9560  sub rsp, 0xF0
00007d07b35d9567  vmovaps [rsp], xmm0
00007d07b35d956c  vmovaps [rsp+0x10], xmm1
00007d07b35d9572  vmovaps [rsp+0x20], xmm2
00007d07b35d9578  vmovaps [rsp+0x30], xmm3
00007d07b35d957e  vmovaps [rsp+0x40], xmm4
00007d07b35d9584  vmovaps [rsp+0x50], xmm5
00007d07b35d958a  vmovaps [rsp+0x60], xmm6
00007d07b35d9590  vmovaps [rsp+0x70], xmm7
00007d07b35d9596  vmovaps [rsp+0x80], xmm8
00007d07b35d959f  vmovaps [rsp+0x90], xmm9
00007d07b35d95a8  vmovaps [rsp+0xA0], xmm10
00007d07b35d95b1  vmovaps [rsp+0xB0], xmm11
00007d07b35d95ba  vmovaps [rsp+0xC0], xmm12
00007d07b35d95c3  vmovaps [rsp+0xD0], xmm13
00007d07b35d95cc  vmovaps [rsp+0xE0], xmm15
00007d07b35d95d5  sub rsp, 0x30
00007d07b35d95d9  movaps [rsp], xmm14
00007d07b35d95de  movaps [rsp+0x10], xmm8
00007d07b35d95e4  movaps [rsp+0x20], xmm4
00007d07b35d95e9  lea rdi, [rsp]
00007d07b35d95ed  mov esi, 0x00
00007d07b35d95f2  mov rax, 0x5D0AA712D530
00007d07b35d95fc  call rax
00007d07b35d95fe  movaps xmm14, [rsp]
00007d07b35d9603  add rsp, 0x30
00007d07b35d9607  vmovaps xmm0, [rsp]
00007d07b35d960c  vmovaps xmm1, [rsp+0x10]
00007d07b35d9612  vmovaps xmm2, [rsp+0x20]
00007d07b35d9618  vmovaps xmm3, [rsp+0x30]
00007d07b35d961e  vmovaps xmm4, [rsp+0x40]
00007d07b35d9624  vmovaps xmm5, [rsp+0x50]
00007d07b35d962a  vmovaps xmm6, [rsp+0x60]
00007d07b35d9630  vmovaps xmm7, [rsp+0x70]
00007d07b35d9636  vmovaps xmm8, [rsp+0x80]
00007d07b35d963f  vmovaps xmm9, [rsp+0x90]
00007d07b35d9648  vmovaps xmm10, [rsp+0xA0]
00007d07b35d9651  vmovaps xmm11, [rsp+0xB0]
00007d07b35d965a  vmovaps xmm12, [rsp+0xC0]
00007d07b35d9663  vmovaps xmm13, [rsp+0xD0]
00007d07b35d966c  vmovaps xmm15, [rsp+0xE0]
00007d07b35d9675  add rsp, 0xF0
00007d07b35d967c  pop r11
00007d07b35d967e  pop r10
00007d07b35d9680  pop r9
00007d07b35d9682  pop r8
00007d07b35d9684  pop rsi
00007d07b35d9685  pop rdi
00007d07b35d9686  pop rdx
00007d07b35d9687  pop rcx
00007d07b35d9688  pop rax
00007d07b35d9689  add rsp, 0x08
00007d07b35d968d  jmp 0x00007D07B35D6265
00007d07b35d9692  sub rsp, 0x08
00007d07b35d9696  push rax
00007d07b35d9697  push rcx
00007d07b35d9698  push rdx
00007d07b35d9699  push rdi
00007d07b35d969a  push rsi
00007d07b35d969b  push r8
00007d07b35d969d  push r9
00007d07b35d969f  push r10
00007d07b35d96a1  push r11
00007d07b35d96a3  sub rsp, 0xF0
00007d07b35d96aa  vmovaps [rsp], xmm0
00007d07b35d96af  vmovaps [rsp+0x10], xmm1
00007d07b35d96b5  vmovaps [rsp+0x20], xmm2
00007d07b35d96bb  vmovaps [rsp+0x30], xmm3
00007d07b35d96c1  vmovaps [rsp+0x40], xmm5
00007d07b35d96c7  vmovaps [rsp+0x50], xmm6
00007d07b35d96cd  vmovaps [rsp+0x60], xmm7
00007d07b35d96d3  vmovaps [rsp+0x70], xmm8
00007d07b35d96d9  vmovaps [rsp+0x80], xmm9
00007d07b35d96e2  vmovaps [rsp+0x90], xmm10
00007d07b35d96eb  vmovaps [rsp+0xA0], xmm11
00007d07b35d96f4  vmovaps [rsp+0xB0], xmm12
00007d07b35d96fd  vmovaps [rsp+0xC0], xmm13
00007d07b35d9706  vmovaps [rsp+0xD0], xmm14
00007d07b35d970f  vmovaps [rsp+0xE0], xmm15
00007d07b35d9718  sub rsp, 0x30
00007d07b35d971c  movaps [rsp], xmm4
00007d07b35d9720  movaps [rsp+0x10], xmm13
00007d07b35d9726  movaps [rsp+0x20], xmm8
00007d07b35d972c  lea rdi, [rsp]
00007d07b35d9730  mov esi, 0x00
00007d07b35d9735  mov rax, 0x5D0AA712D530
00007d07b35d973f  call rax
00007d07b35d9741  movaps xmm4, [rsp]
00007d07b35d9745  add rsp, 0x30
00007d07b35d9749  vmovaps xmm0, [rsp]
00007d07b35d974e  vmovaps xmm1, [rsp+0x10]
00007d07b35d9754  vmovaps xmm2, [rsp+0x20]
00007d07b35d975a  vmovaps xmm3, [rsp+0x30]
00007d07b35d9760  vmovaps xmm5, [rsp+0x40]
00007d07b35d9766  vmovaps xmm6, [rsp+0x50]
00007d07b35d976c  vmovaps xmm7, [rsp+0x60]
00007d07b35d9772  vmovaps xmm8, [rsp+0x70]
00007d07b35d9778  vmovaps xmm9, [rsp+0x80]
00007d07b35d9781  vmovaps xmm10, [rsp+0x90]
00007d07b35d978a  vmovaps xmm11, [rsp+0xA0]
00007d07b35d9793  vmovaps xmm12, [rsp+0xB0]
00007d07b35d979c  vmovaps xmm13, [rsp+0xC0]
00007d07b35d97a5  vmovaps xmm14, [rsp+0xD0]
00007d07b35d97ae  vmovaps xmm15, [rsp+0xE0]
00007d07b35d97b7  add rsp, 0xF0
00007d07b35d97be  pop r11
00007d07b35d97c0  pop r10
00007d07b35d97c2  pop r9
00007d07b35d97c4  pop r8
00007d07b35d97c6  pop rsi
00007d07b35d97c7  pop rdi
00007d07b35d97c8  pop rdx
00007d07b35d97c9  pop rcx
00007d07b35d97ca  pop rax
00007d07b35d97cb  add rsp, 0x08
00007d07b35d97cf  jmp 0x00007D07B35D628A
00007d07b35d97d4  sub rsp, 0x08
00007d07b35d97d8  push rax
00007d07b35d97d9  push rcx
00007d07b35d97da  push rdx
00007d07b35d97db  push rdi
00007d07b35d97dc  push rsi
00007d07b35d97dd  push r8
00007d07b35d97df  push r9
00007d07b35d97e1  push r10
00007d07b35d97e3  push r11
00007d07b35d97e5  sub rsp, 0xF0
00007d07b35d97ec  vmovaps [rsp], xmm0
00007d07b35d97f1  vmovaps [rsp+0x10], xmm1
00007d07b35d97f7  vmovaps [rsp+0x20], xmm2
00007d07b35d97fd  vmovaps [rsp+0x30], xmm3
00007d07b35d9803  vmovaps [rsp+0x40], xmm4
00007d07b35d9809  vmovaps [rsp+0x50], xmm5
00007d07b35d980f  vmovaps [rsp+0x60], xmm6
00007d07b35d9815  vmovaps [rsp+0x70], xmm7
00007d07b35d981b  vmovaps [rsp+0x80], xmm8
00007d07b35d9824  vmovaps [rsp+0x90], xmm9
00007d07b35d982d  vmovaps [rsp+0xA0], xmm10
00007d07b35d9836  vmovaps [rsp+0xB0], xmm11
00007d07b35d983f  vmovaps [rsp+0xC0], xmm12
00007d07b35d9848  vmovaps [rsp+0xD0], xmm14
00007d07b35d9851  vmovaps [rsp+0xE0], xmm15
00007d07b35d985a  sub rsp, 0x30
00007d07b35d985e  movaps [rsp], xmm13
00007d07b35d9863  movaps [rsp+0x10], xmm15
00007d07b35d9869  movaps [rsp+0x20], xmm9
00007d07b35d986f  lea rdi, [rsp]
00007d07b35d9873  mov esi, 0x00
00007d07b35d9878  mov rax, 0x5D0AA712D530
00007d07b35d9882  call rax
00007d07b35d9884  movaps xmm13, [rsp]
00007d07b35d9889  add rsp, 0x30
00007d07b35d988d  vmovaps xmm0, [rsp]
00007d07b35d9892  vmovaps xmm1, [rsp+0x10]
00007d07b35d9898  vmovaps xmm2, [rsp+0x20]
00007d07b35d989e  vmovaps xmm3, [rsp+0x30]
00007d07b35d98a4  vmovaps xmm4, [rsp+0x40]
00007d07b35d98aa  vmovaps xmm5, [rsp+0x50]
00007d07b35d98b0  vmovaps xmm6, [rsp+0x60]
00007d07b35d98b6  vmovaps xmm7, [rsp+0x70]
00007d07b35d98bc  vmovaps xmm8, [rsp+0x80]
00007d07b35d98c5  vmovaps xmm9, [rsp+0x90]
00007d07b35d98ce  vmovaps xmm10, [rsp+0xA0]
00007d07b35d98d7  vmovaps xmm11, [rsp+0xB0]
00007d07b35d98e0  vmovaps xmm12, [rsp+0xC0]
00007d07b35d98e9  vmovaps xmm14, [rsp+0xD0]
00007d07b35d98f2  vmovaps xmm15, [rsp+0xE0]
00007d07b35d98fb  add rsp, 0xF0
00007d07b35d9902  pop r11
00007d07b35d9904  pop r10
00007d07b35d9906  pop r9
00007d07b35d9908  pop r8
00007d07b35d990a  pop rsi
00007d07b35d990b  pop rdi
00007d07b35d990c  pop rdx
00007d07b35d990d  pop rcx
00007d07b35d990e  pop rax
00007d07b35d990f  add rsp, 0x08
00007d07b35d9913  jmp 0x00007D07B35D62A5
00007d07b35d9918  sub rsp, 0x08
00007d07b35d991c  push rax
00007d07b35d991d  push rcx
00007d07b35d991e  push rdx
00007d07b35d991f  push rdi
00007d07b35d9920  push rsi
00007d07b35d9921  push r8
00007d07b35d9923  push r9
00007d07b35d9925  push r10
00007d07b35d9927  push r11
00007d07b35d9929  sub rsp, 0xF0
00007d07b35d9930  vmovaps [rsp], xmm0
00007d07b35d9935  vmovaps [rsp+0x10], xmm1
00007d07b35d993b  vmovaps [rsp+0x20], xmm2
00007d07b35d9941  vmovaps [rsp+0x30], xmm3
00007d07b35d9947  vmovaps [rsp+0x40], xmm4
00007d07b35d994d  vmovaps [rsp+0x50], xmm5
00007d07b35d9953  vmovaps [rsp+0x60], xmm6
00007d07b35d9959  vmovaps [rsp+0x70], xmm7
00007d07b35d995f  vmovaps [rsp+0x80], xmm8
00007d07b35d9968  vmovaps [rsp+0x90], xmm9
00007d07b35d9971  vmovaps [rsp+0xA0], xmm10
00007d07b35d997a  vmovaps [rsp+0xB0], xmm11
00007d07b35d9983  vmovaps [rsp+0xC0], xmm12
00007d07b35d998c  vmovaps [rsp+0xD0], xmm13
00007d07b35d9995  vmovaps [rsp+0xE0], xmm14
00007d07b35d999e  sub rsp, 0x30
00007d07b35d99a2  movaps [rsp], xmm15
00007d07b35d99a7  movaps [rsp+0x10], xmm1
00007d07b35d99ac  movaps [rsp+0x20], xmm5
00007d07b35d99b1  lea rdi, [rsp]
00007d07b35d99b5  mov esi, 0x00
00007d07b35d99ba  mov rax, 0x5D0AA712D530
00007d07b35d99c4  call rax
00007d07b35d99c6  movaps xmm15, [rsp]
00007d07b35d99cb  add rsp, 0x30
00007d07b35d99cf  vmovaps xmm0, [rsp]
00007d07b35d99d4  vmovaps xmm1, [rsp+0x10]
00007d07b35d99da  vmovaps xmm2, [rsp+0x20]
00007d07b35d99e0  vmovaps xmm3, [rsp+0x30]
00007d07b35d99e6  vmovaps xmm4, [rsp+0x40]
00007d07b35d99ec  vmovaps xmm5, [rsp+0x50]
00007d07b35d99f2  vmovaps xmm6, [rsp+0x60]
00007d07b35d99f8  vmovaps xmm7, [rsp+0x70]
00007d07b35d99fe  vmovaps xmm8, [rsp+0x80]
00007d07b35d9a07  vmovaps xmm9, [rsp+0x90]
00007d07b35d9a10  vmovaps xmm10, [rsp+0xA0]
00007d07b35d9a19  vmovaps xmm11, [rsp+0xB0]
00007d07b35d9a22  vmovaps xmm12, [rsp+0xC0]
00007d07b35d9a2b  vmovaps xmm13, [rsp+0xD0]
00007d07b35d9a34  vmovaps xmm14, [rsp+0xE0]
00007d07b35d9a3d  add rsp, 0xF0
00007d07b35d9a44  pop r11
00007d07b35d9a46  pop r10
00007d07b35d9a48  pop r9
00007d07b35d9a4a  pop r8
00007d07b35d9a4c  pop rsi
00007d07b35d9a4d  pop rdi
00007d07b35d9a4e  pop rdx
00007d07b35d9a4f  pop rcx
00007d07b35d9a50  pop rax
00007d07b35d9a51  add rsp, 0x08
00007d07b35d9a55  jmp 0x00007D07B35D62C0
00007d07b35d9a5a  call 0x00007D07B34D64F0
00007d07b35d9a5f  jmp 0x00007D07B35D631B
00007d07b35d9a64  sub rsp, 0x08
00007d07b35d9a68  push rax
00007d07b35d9a69  push rcx
00007d07b35d9a6a  push rdx
00007d07b35d9a6b  push rdi
00007d07b35d9a6c  push rsi
00007d07b35d9a6d  push r8
00007d07b35d9a6f  push r9
00007d07b35d9a71  push r10
00007d07b35d9a73  push r11
00007d07b35d9a75  sub rsp, 0xF0
00007d07b35d9a7c  vmovaps [rsp], xmm0
00007d07b35d9a81  vmovaps [rsp+0x10], xmm1
00007d07b35d9a87  vmovaps [rsp+0x20], xmm2
00007d07b35d9a8d  vmovaps [rsp+0x30], xmm3
00007d07b35d9a93  vmovaps [rsp+0x40], xmm4
00007d07b35d9a99  vmovaps [rsp+0x50], xmm5
00007d07b35d9a9f  vmovaps [rsp+0x60], xmm6
00007d07b35d9aa5  vmovaps [rsp+0x70], xmm7
00007d07b35d9aab  vmovaps [rsp+0x80], xmm8
00007d07b35d9ab4  vmovaps [rsp+0x90], xmm10
00007d07b35d9abd  vmovaps [rsp+0xA0], xmm11
00007d07b35d9ac6  vmovaps [rsp+0xB0], xmm12
00007d07b35d9acf  vmovaps [rsp+0xC0], xmm13
00007d07b35d9ad8  vmovaps [rsp+0xD0], xmm14
00007d07b35d9ae1  vmovaps [rsp+0xE0], xmm15
00007d07b35d9aea  sub rsp, 0x30
00007d07b35d9aee  movaps [rsp], xmm9
00007d07b35d9af3  movaps [rsp+0x10], xmm8
00007d07b35d9af9  movaps [rsp+0x20], xmm11
00007d07b35d9aff  lea rdi, [rsp]
00007d07b35d9b03  mov esi, 0x00
00007d07b35d9b08  mov rax, 0x5D0AA712D530
00007d07b35d9b12  call rax
00007d07b35d9b14  movaps xmm9, [rsp]
00007d07b35d9b19  add rsp, 0x30
00007d07b35d9b1d  vmovaps xmm0, [rsp]
00007d07b35d9b22  vmovaps xmm1, [rsp+0x10]
00007d07b35d9b28  vmovaps xmm2, [rsp+0x20]
00007d07b35d9b2e  vmovaps xmm3, [rsp+0x30]
00007d07b35d9b34  vmovaps xmm4, [rsp+0x40]
00007d07b35d9b3a  vmovaps xmm5, [rsp+0x50]
00007d07b35d9b40  vmovaps xmm6, [rsp+0x60]
00007d07b35d9b46  vmovaps xmm7, [rsp+0x70]
00007d07b35d9b4c  vmovaps xmm8, [rsp+0x80]
00007d07b35d9b55  vmovaps xmm10, [rsp+0x90]
00007d07b35d9b5e  vmovaps xmm11, [rsp+0xA0]
00007d07b35d9b67  vmovaps xmm12, [rsp+0xB0]
00007d07b35d9b70  vmovaps xmm13, [rsp+0xC0]
00007d07b35d9b79  vmovaps xmm14, [rsp+0xD0]
00007d07b35d9b82  vmovaps xmm15, [rsp+0xE0]
00007d07b35d9b8b  add rsp, 0xF0
00007d07b35d9b92  pop r11
00007d07b35d9b94  pop r10
00007d07b35d9b96  pop r9
00007d07b35d9b98  pop r8
00007d07b35d9b9a  pop rsi
00007d07b35d9b9b  pop rdi
00007d07b35d9b9c  pop rdx
00007d07b35d9b9d  pop rcx
00007d07b35d9b9e  pop rax
00007d07b35d9b9f  add rsp, 0x08
00007d07b35d9ba3  jmp 0x00007D07B35D6352
00007d07b35d9ba8  sub rsp, 0x08
00007d07b35d9bac  push rax
00007d07b35d9bad  push rcx
00007d07b35d9bae  push rdx
00007d07b35d9baf  push rdi
00007d07b35d9bb0  push rsi
00007d07b35d9bb1  push r8
00007d07b35d9bb3  push r9
00007d07b35d9bb5  push r10
00007d07b35d9bb7  push r11
00007d07b35d9bb9  sub rsp, 0xF0
00007d07b35d9bc0  vmovaps [rsp], xmm0
00007d07b35d9bc5  vmovaps [rsp+0x10], xmm1
00007d07b35d9bcb  vmovaps [rsp+0x20], xmm2
00007d07b35d9bd1  vmovaps [rsp+0x30], xmm3
00007d07b35d9bd7  vmovaps [rsp+0x40], xmm4
00007d07b35d9bdd  vmovaps [rsp+0x50], xmm5
00007d07b35d9be3  vmovaps [rsp+0x60], xmm6
00007d07b35d9be9  vmovaps [rsp+0x70], xmm7
00007d07b35d9bef  vmovaps [rsp+0x80], xmm8
00007d07b35d9bf8  vmovaps [rsp+0x90], xmm9
00007d07b35d9c01  vmovaps [rsp+0xA0], xmm10
00007d07b35d9c0a  vmovaps [rsp+0xB0], xmm12
00007d07b35d9c13  vmovaps [rsp+0xC0], xmm13
00007d07b35d9c1c  vmovaps [rsp+0xD0], xmm14
00007d07b35d9c25  vmovaps [rsp+0xE0], xmm15
00007d07b35d9c2e  sub rsp, 0x30
00007d07b35d9c32  movaps [rsp], xmm11
00007d07b35d9c37  movaps [rsp+0x10], xmm10
00007d07b35d9c3d  movaps [rsp+0x20], xmm6
00007d07b35d9c42  lea rdi, [rsp]
00007d07b35d9c46  mov esi, 0x00
00007d07b35d9c4b  mov rax, 0x5D0AA712D530
00007d07b35d9c55  call rax
00007d07b35d9c57  movaps xmm11, [rsp]
00007d07b35d9c5c  add rsp, 0x30
00007d07b35d9c60  vmovaps xmm0, [rsp]
00007d07b35d9c65  vmovaps xmm1, [rsp+0x10]
00007d07b35d9c6b  vmovaps xmm2, [rsp+0x20]
00007d07b35d9c71  vmovaps xmm3, [rsp+0x30]
00007d07b35d9c77  vmovaps xmm4, [rsp+0x40]
00007d07b35d9c7d  vmovaps xmm5, [rsp+0x50]
00007d07b35d9c83  vmovaps xmm6, [rsp+0x60]
00007d07b35d9c89  vmovaps xmm7, [rsp+0x70]
00007d07b35d9c8f  vmovaps xmm8, [rsp+0x80]
00007d07b35d9c98  vmovaps xmm9, [rsp+0x90]
00007d07b35d9ca1  vmovaps xmm10, [rsp+0xA0]
00007d07b35d9caa  vmovaps xmm12, [rsp+0xB0]
00007d07b35d9cb3  vmovaps xmm13, [rsp+0xC0]
00007d07b35d9cbc  vmovaps xmm14, [rsp+0xD0]
00007d07b35d9cc5  vmovaps xmm15, [rsp+0xE0]
00007d07b35d9cce  add rsp, 0xF0
00007d07b35d9cd5  pop r11
00007d07b35d9cd7  pop r10
00007d07b35d9cd9  pop r9
00007d07b35d9cdb  pop r8
00007d07b35d9cdd  pop rsi
00007d07b35d9cde  pop rdi
00007d07b35d9cdf  pop rdx
00007d07b35d9ce0  pop rcx
00007d07b35d9ce1  pop rax
00007d07b35d9ce2  add rsp, 0x08
00007d07b35d9ce6  jmp 0x00007D07B35D636D
00007d07b35d9ceb  sub rsp, 0x08
00007d07b35d9cef  push rax
00007d07b35d9cf0  push rcx
00007d07b35d9cf1  push rdx
00007d07b35d9cf2  push rdi
00007d07b35d9cf3  push rsi
00007d07b35d9cf4  push r8
00007d07b35d9cf6  push r9
00007d07b35d9cf8  push r10
00007d07b35d9cfa  push r11
00007d07b35d9cfc  sub rsp, 0xF0
00007d07b35d9d03  vmovaps [rsp], xmm0
00007d07b35d9d08  vmovaps [rsp+0x10], xmm1
00007d07b35d9d0e  vmovaps [rsp+0x20], xmm2
00007d07b35d9d14  vmovaps [rsp+0x30], xmm3
00007d07b35d9d1a  vmovaps [rsp+0x40], xmm4
00007d07b35d9d20  vmovaps [rsp+0x50], xmm5
00007d07b35d9d26  vmovaps [rsp+0x60], xmm6
00007d07b35d9d2c  vmovaps [rsp+0x70], xmm7
00007d07b35d9d32  vmovaps [rsp+0x80], xmm8
00007d07b35d9d3b  vmovaps [rsp+0x90], xmm9
00007d07b35d9d44  vmovaps [rsp+0xA0], xmm11
00007d07b35d9d4d  vmovaps [rsp+0xB0], xmm12
00007d07b35d9d56  vmovaps [rsp+0xC0], xmm13
00007d07b35d9d5f  vmovaps [rsp+0xD0], xmm14
00007d07b35d9d68  vmovaps [rsp+0xE0], xmm15
00007d07b35d9d71  sub rsp, 0x30
00007d07b35d9d75  movaps [rsp], xmm10
00007d07b35d9d7a  movaps [rsp+0x10], xmm14
00007d07b35d9d80  movaps [rsp+0x20], xmm4
00007d07b35d9d85  lea rdi, [rsp]
00007d07b35d9d89  mov esi, 0x00
00007d07b35d9d8e  mov rax, 0x5D0AA712D530
00007d07b35d9d98  call rax
00007d07b35d9d9a  movaps xmm10, [rsp]
00007d07b35d9d9f  add rsp, 0x30
00007d07b35d9da3  vmovaps xmm0, [rsp]
00007d07b35d9da8  vmovaps xmm1, [rsp+0x10]
00007d07b35d9dae  vmovaps xmm2, [rsp+0x20]
00007d07b35d9db4  vmovaps xmm3, [rsp+0x30]
00007d07b35d9dba  vmovaps xmm4, [rsp+0x40]
00007d07b35d9dc0  vmovaps xmm5, [rsp+0x50]
00007d07b35d9dc6  vmovaps xmm6, [rsp+0x60]
00007d07b35d9dcc  vmovaps xmm7, [rsp+0x70]
00007d07b35d9dd2  vmovaps xmm8, [rsp+0x80]
00007d07b35d9ddb  vmovaps xmm9, [rsp+0x90]
00007d07b35d9de4  vmovaps xmm11, [rsp+0xA0]
00007d07b35d9ded  vmovaps xmm12, [rsp+0xB0]
00007d07b35d9df6  vmovaps xmm13, [rsp+0xC0]
00007d07b35d9dff  vmovaps xmm14, [rsp+0xD0]
00007d07b35d9e08  vmovaps xmm15, [rsp+0xE0]
00007d07b35d9e11  add rsp, 0xF0
00007d07b35d9e18  pop r11
00007d07b35d9e1a  pop r10
00007d07b35d9e1c  pop r9
00007d07b35d9e1e  pop r8
00007d07b35d9e20  pop rsi
00007d07b35d9e21  pop rdi
00007d07b35d9e22  pop rdx
00007d07b35d9e23  pop rcx
00007d07b35d9e24  pop rax
00007d07b35d9e25  add rsp, 0x08
00007d07b35d9e29  jmp 0x00007D07B35D6388
00007d07b35d9e2e  sub rsp, 0x08
00007d07b35d9e32  push rax
00007d07b35d9e33  push rcx
00007d07b35d9e34  push rdx
00007d07b35d9e35  push rdi
00007d07b35d9e36  push rsi
00007d07b35d9e37  push r8
00007d07b35d9e39  push r9
00007d07b35d9e3b  push r10
00007d07b35d9e3d  push r11
00007d07b35d9e3f  sub rsp, 0xF0
00007d07b35d9e46  vmovaps [rsp], xmm0
00007d07b35d9e4b  vmovaps [rsp+0x10], xmm1
00007d07b35d9e51  vmovaps [rsp+0x20], xmm2
00007d07b35d9e57  vmovaps [rsp+0x30], xmm3
00007d07b35d9e5d  vmovaps [rsp+0x40], xmm4
00007d07b35d9e63  vmovaps [rsp+0x50], xmm5
00007d07b35d9e69  vmovaps [rsp+0x60], xmm6
00007d07b35d9e6f  vmovaps [rsp+0x70], xmm7
00007d07b35d9e75  vmovaps [rsp+0x80], xmm9
00007d07b35d9e7e  vmovaps [rsp+0x90], xmm10
00007d07b35d9e87  vmovaps [rsp+0xA0], xmm11
00007d07b35d9e90  vmovaps [rsp+0xB0], xmm12
00007d07b35d9e99  vmovaps [rsp+0xC0], xmm13
00007d07b35d9ea2  vmovaps [rsp+0xD0], xmm14
00007d07b35d9eab  vmovaps [rsp+0xE0], xmm15
00007d07b35d9eb4  sub rsp, 0x30
00007d07b35d9eb8  movaps [rsp], xmm8
00007d07b35d9ebd  movaps [rsp+0x10], xmm1
00007d07b35d9ec2  movaps [rsp+0x20], xmm14
00007d07b35d9ec8  lea rdi, [rsp]
00007d07b35d9ecc  mov esi, 0x00
00007d07b35d9ed1  mov rax, 0x5D0AA712D530
00007d07b35d9edb  call rax
00007d07b35d9edd  movaps xmm8, [rsp]
00007d07b35d9ee2  add rsp, 0x30
00007d07b35d9ee6  vmovaps xmm0, [rsp]
00007d07b35d9eeb  vmovaps xmm1, [rsp+0x10]
00007d07b35d9ef1  vmovaps xmm2, [rsp+0x20]
00007d07b35d9ef7  vmovaps xmm3, [rsp+0x30]
00007d07b35d9efd  vmovaps xmm4, [rsp+0x40]
00007d07b35d9f03  vmovaps xmm5, [rsp+0x50]
00007d07b35d9f09  vmovaps xmm6, [rsp+0x60]
00007d07b35d9f0f  vmovaps xmm7, [rsp+0x70]
00007d07b35d9f15  vmovaps xmm9, [rsp+0x80]
00007d07b35d9f1e  vmovaps xmm10, [rsp+0x90]
00007d07b35d9f27  vmovaps xmm11, [rsp+0xA0]
00007d07b35d9f30  vmovaps xmm12, [rsp+0xB0]
00007d07b35d9f39  vmovaps xmm13, [rsp+0xC0]
00007d07b35d9f42  vmovaps xmm14, [rsp+0xD0]
00007d07b35d9f4b  vmovaps xmm15, [rsp+0xE0]
00007d07b35d9f54  add rsp, 0xF0
00007d07b35d9f5b  pop r11
00007d07b35d9f5d  pop r10
00007d07b35d9f5f  pop r9
00007d07b35d9f61  pop r8
00007d07b35d9f63  pop rsi
00007d07b35d9f64  pop rdi
00007d07b35d9f65  pop rdx
00007d07b35d9f66  pop rcx
00007d07b35d9f67  pop rax
00007d07b35d9f68  add rsp, 0x08
00007d07b35d9f6c  jmp 0x00007D07B35D63AE
00007d07b35d9f71  sub rsp, 0x08
00007d07b35d9f75  push rax
00007d07b35d9f76  push rcx
00007d07b35d9f77  push rdx
00007d07b35d9f78  push rdi
00007d07b35d9f79  push rsi
00007d07b35d9f7a  push r8
00007d07b35d9f7c  push r9
00007d07b35d9f7e  push r10
00007d07b35d9f80  push r11
00007d07b35d9f82  sub rsp, 0xF0
00007d07b35d9f89  vmovaps [rsp], xmm0
00007d07b35d9f8e  vmovaps [rsp+0x10], xmm1
00007d07b35d9f94  vmovaps [rsp+0x20], xmm2
00007d07b35d9f9a  vmovaps [rsp+0x30], xmm3
00007d07b35d9fa0  vmovaps [rsp+0x40], xmm4
00007d07b35d9fa6  vmovaps [rsp+0x50], xmm5
00007d07b35d9fac  vmovaps [rsp+0x60], xmm7
00007d07b35d9fb2  vmovaps [rsp+0x70], xmm8
00007d07b35d9fb8  vmovaps [rsp+0x80], xmm9
00007d07b35d9fc1  vmovaps [rsp+0x90], xmm10
00007d07b35d9fca  vmovaps [rsp+0xA0], xmm11
00007d07b35d9fd3  vmovaps [rsp+0xB0], xmm12
00007d07b35d9fdc  vmovaps [rsp+0xC0], xmm13
00007d07b35d9fe5  vmovaps [rsp+0xD0], xmm14
00007d07b35d9fee  vmovaps [rsp+0xE0], xmm15
00007d07b35d9ff7  sub rsp, 0x30
00007d07b35d9ffb  movaps [rsp], xmm6
00007d07b35d9fff  movaps [rsp+0x10], xmm1
00007d07b35da004  movaps [rsp+0x20], xmm14
00007d07b35da00a  lea rdi, [rsp]
00007d07b35da00e  mov esi, 0x00
00007d07b35da013  mov rax, 0x5D0AA712D530
00007d07b35da01d  call rax
00007d07b35da01f  movaps xmm6, [rsp]
00007d07b35da023  add rsp, 0x30
00007d07b35da027  vmovaps xmm0, [rsp]
00007d07b35da02c  vmovaps xmm1, [rsp+0x10]
00007d07b35da032  vmovaps xmm2, [rsp+0x20]
00007d07b35da038  vmovaps xmm3, [rsp+0x30]
00007d07b35da03e  vmovaps xmm4, [rsp+0x40]
00007d07b35da044  vmovaps xmm5, [rsp+0x50]
00007d07b35da04a  vmovaps xmm7, [rsp+0x60]
00007d07b35da050  vmovaps xmm8, [rsp+0x70]
00007d07b35da056  vmovaps xmm9, [rsp+0x80]
00007d07b35da05f  vmovaps xmm10, [rsp+0x90]
00007d07b35da068  vmovaps xmm11, [rsp+0xA0]
00007d07b35da071  vmovaps xmm12, [rsp+0xB0]
00007d07b35da07a  vmovaps xmm13, [rsp+0xC0]
00007d07b35da083  vmovaps xmm14, [rsp+0xD0]
00007d07b35da08c  vmovaps xmm15, [rsp+0xE0]
00007d07b35da095  add rsp, 0xF0
00007d07b35da09c  pop r11
00007d07b35da09e  pop r10
00007d07b35da0a0  pop r9
00007d07b35da0a2  pop r8
00007d07b35da0a4  pop rsi
00007d07b35da0a5  pop rdi
00007d07b35da0a6  pop rdx
00007d07b35da0a7  pop rcx
00007d07b35da0a8  pop rax
00007d07b35da0a9  add rsp, 0x08
00007d07b35da0ad  jmp 0x00007D07B35D63DA
00007d07b35da0b2  sub rsp, 0x08
00007d07b35da0b6  push rax
00007d07b35da0b7  push rcx
00007d07b35da0b8  push rdx
00007d07b35da0b9  push rdi
00007d07b35da0ba  push rsi
00007d07b35da0bb  push r8
00007d07b35da0bd  push r9
00007d07b35da0bf  push r10
00007d07b35da0c1  push r11
00007d07b35da0c3  sub rsp, 0xF0
00007d07b35da0ca  vmovaps [rsp], xmm0
00007d07b35da0cf  vmovaps [rsp+0x10], xmm1
00007d07b35da0d5  vmovaps [rsp+0x20], xmm2
00007d07b35da0db  vmovaps [rsp+0x30], xmm3
00007d07b35da0e1  vmovaps [rsp+0x40], xmm4
00007d07b35da0e7  vmovaps [rsp+0x50], xmm5
00007d07b35da0ed  vmovaps [rsp+0x60], xmm6
00007d07b35da0f3  vmovaps [rsp+0x70], xmm7
00007d07b35da0f9  vmovaps [rsp+0x80], xmm8
00007d07b35da102  vmovaps [rsp+0x90], xmm9
00007d07b35da10b  vmovaps [rsp+0xA0], xmm10
00007d07b35da114  vmovaps [rsp+0xB0], xmm11
00007d07b35da11d  vmovaps [rsp+0xC0], xmm12
00007d07b35da126  vmovaps [rsp+0xD0], xmm13
00007d07b35da12f  vmovaps [rsp+0xE0], xmm15
00007d07b35da138  sub rsp, 0x30
00007d07b35da13c  movaps [rsp], xmm14
00007d07b35da141  movaps [rsp+0x10], xmm12
00007d07b35da147  movaps [rsp+0x20], xmm1
00007d07b35da14c  lea rdi, [rsp]
00007d07b35da150  mov esi, 0x00
00007d07b35da155  mov rax, 0x5D0AA712D530
00007d07b35da15f  call rax
00007d07b35da161  movaps xmm14, [rsp]
00007d07b35da166  add rsp, 0x30
00007d07b35da16a  vmovaps xmm0, [rsp]
00007d07b35da16f  vmovaps xmm1, [rsp+0x10]
00007d07b35da175  vmovaps xmm2, [rsp+0x20]
00007d07b35da17b  vmovaps xmm3, [rsp+0x30]
00007d07b35da181  vmovaps xmm4, [rsp+0x40]
00007d07b35da187  vmovaps xmm5, [rsp+0x50]
00007d07b35da18d  vmovaps xmm6, [rsp+0x60]
00007d07b35da193  vmovaps xmm7, [rsp+0x70]
00007d07b35da199  vmovaps xmm8, [rsp+0x80]
00007d07b35da1a2  vmovaps xmm9, [rsp+0x90]
00007d07b35da1ab  vmovaps xmm10, [rsp+0xA0]
00007d07b35da1b4  vmovaps xmm11, [rsp+0xB0]
00007d07b35da1bd  vmovaps xmm12, [rsp+0xC0]
00007d07b35da1c6  vmovaps xmm13, [rsp+0xD0]
00007d07b35da1cf  vmovaps xmm15, [rsp+0xE0]
00007d07b35da1d8  add rsp, 0xF0
00007d07b35da1df  pop r11
00007d07b35da1e1  pop r10
00007d07b35da1e3  pop r9
00007d07b35da1e5  pop r8
00007d07b35da1e7  pop rsi
00007d07b35da1e8  pop rdi
00007d07b35da1e9  pop rdx
00007d07b35da1ea  pop rcx
00007d07b35da1eb  pop rax
00007d07b35da1ec  add rsp, 0x08
00007d07b35da1f0  jmp 0x00007D07B35D6400
00007d07b35da1f5  sub rsp, 0x08
00007d07b35da1f9  push rax
00007d07b35da1fa  push rcx
00007d07b35da1fb  push rdx
00007d07b35da1fc  push rdi
00007d07b35da1fd  push rsi
00007d07b35da1fe  push r8
00007d07b35da200  push r9
00007d07b35da202  push r10
00007d07b35da204  push r11
00007d07b35da206  sub rsp, 0xF0
00007d07b35da20d  vmovaps [rsp], xmm0
00007d07b35da212  vmovaps [rsp+0x10], xmm2
00007d07b35da218  vmovaps [rsp+0x20], xmm3
00007d07b35da21e  vmovaps [rsp+0x30], xmm4
00007d07b35da224  vmovaps [rsp+0x40], xmm5
00007d07b35da22a  vmovaps [rsp+0x50], xmm6
00007d07b35da230  vmovaps [rsp+0x60], xmm7
00007d07b35da236  vmovaps [rsp+0x70], xmm8
00007d07b35da23c  vmovaps [rsp+0x80], xmm9
00007d07b35da245  vmovaps [rsp+0x90], xmm10
00007d07b35da24e  vmovaps [rsp+0xA0], xmm11
00007d07b35da257  vmovaps [rsp+0xB0], xmm12
00007d07b35da260  vmovaps [rsp+0xC0], xmm13
00007d07b35da269  vmovaps [rsp+0xD0], xmm14
00007d07b35da272  vmovaps [rsp+0xE0], xmm15
00007d07b35da27b  sub rsp, 0x30
00007d07b35da27f  movaps [rsp], xmm1
00007d07b35da283  movaps [rsp+0x10], xmm13
00007d07b35da289  movaps [rsp+0x20], xmm9
00007d07b35da28f  lea rdi, [rsp]
00007d07b35da293  mov esi, 0x00
00007d07b35da298  mov rax, 0x5D0AA712D530
00007d07b35da2a2  call rax
00007d07b35da2a4  movaps xmm1, [rsp]
00007d07b35da2a8  add rsp, 0x30
00007d07b35da2ac  vmovaps xmm0, [rsp]
00007d07b35da2b1  vmovaps xmm2, [rsp+0x10]
00007d07b35da2b7  vmovaps xmm3, [rsp+0x20]
00007d07b35da2bd  vmovaps xmm4, [rsp+0x30]
00007d07b35da2c3  vmovaps xmm5, [rsp+0x40]
00007d07b35da2c9  vmovaps xmm6, [rsp+0x50]
00007d07b35da2cf  vmovaps xmm7, [rsp+0x60]
00007d07b35da2d5  vmovaps xmm8, [rsp+0x70]
00007d07b35da2db  vmovaps xmm9, [rsp+0x80]
00007d07b35da2e4  vmovaps xmm10, [rsp+0x90]
00007d07b35da2ed  vmovaps xmm11, [rsp+0xA0]
00007d07b35da2f6  vmovaps xmm12, [rsp+0xB0]
00007d07b35da2ff  vmovaps xmm13, [rsp+0xC0]
00007d07b35da308  vmovaps xmm14, [rsp+0xD0]
00007d07b35da311  vmovaps xmm15, [rsp+0xE0]
00007d07b35da31a  add rsp, 0xF0
00007d07b35da321  pop r11
00007d07b35da323  pop r10
00007d07b35da325  pop r9
00007d07b35da327  pop r8
00007d07b35da329  pop rsi
00007d07b35da32a  pop rdi
00007d07b35da32b  pop rdx
00007d07b35da32c  pop rcx
00007d07b35da32d  pop rax
00007d07b35da32e  add rsp, 0x08
00007d07b35da332  jmp 0x00007D07B35D641A
00007d07b35da337  sub rsp, 0x08
00007d07b35da33b  push rax
00007d07b35da33c  push rcx
00007d07b35da33d  push rdx
00007d07b35da33e  push rdi
00007d07b35da33f  push rsi
00007d07b35da340  push r8
00007d07b35da342  push r9
00007d07b35da344  push r10
00007d07b35da346  push r11
00007d07b35da348  sub rsp, 0xF0
00007d07b35da34f  vmovaps [rsp], xmm0
00007d07b35da354  vmovaps [rsp+0x10], xmm1
00007d07b35da35a  vmovaps [rsp+0x20], xmm2
00007d07b35da360  vmovaps [rsp+0x30], xmm3
00007d07b35da366  vmovaps [rsp+0x40], xmm4
00007d07b35da36c  vmovaps [rsp+0x50], xmm5
00007d07b35da372  vmovaps [rsp+0x60], xmm6
00007d07b35da378  vmovaps [rsp+0x70], xmm7
00007d07b35da37e  vmovaps [rsp+0x80], xmm8
00007d07b35da387  vmovaps [rsp+0x90], xmm9
00007d07b35da390  vmovaps [rsp+0xA0], xmm10
00007d07b35da399  vmovaps [rsp+0xB0], xmm11
00007d07b35da3a2  vmovaps [rsp+0xC0], xmm13
00007d07b35da3ab  vmovaps [rsp+0xD0], xmm14
00007d07b35da3b4  vmovaps [rsp+0xE0], xmm15
00007d07b35da3bd  sub rsp, 0x30
00007d07b35da3c1  movaps [rsp], xmm12
00007d07b35da3c6  movaps [rsp+0x10], xmm7
00007d07b35da3cb  movaps [rsp+0x20], xmm13
00007d07b35da3d1  lea rdi, [rsp]
00007d07b35da3d5  mov esi, 0x00
00007d07b35da3da  mov rax, 0x5D0AA712D530
00007d07b35da3e4  call rax
00007d07b35da3e6  movaps xmm12, [rsp]
00007d07b35da3eb  add rsp, 0x30
00007d07b35da3ef  vmovaps xmm0, [rsp]
00007d07b35da3f4  vmovaps xmm1, [rsp+0x10]
00007d07b35da3fa  vmovaps xmm2, [rsp+0x20]
00007d07b35da400  vmovaps xmm3, [rsp+0x30]
00007d07b35da406  vmovaps xmm4, [rsp+0x40]
00007d07b35da40c  vmovaps xmm5, [rsp+0x50]
00007d07b35da412  vmovaps xmm6, [rsp+0x60]
00007d07b35da418  vmovaps xmm7, [rsp+0x70]
00007d07b35da41e  vmovaps xmm8, [rsp+0x80]
00007d07b35da427  vmovaps xmm9, [rsp+0x90]
00007d07b35da430  vmovaps xmm10, [rsp+0xA0]
00007d07b35da439  vmovaps xmm11, [rsp+0xB0]
00007d07b35da442  vmovaps xmm13, [rsp+0xC0]
00007d07b35da44b  vmovaps xmm14, [rsp+0xD0]
00007d07b35da454  vmovaps xmm15, [rsp+0xE0]
00007d07b35da45d  add rsp, 0xF0
00007d07b35da464  pop r11
00007d07b35da466  pop r10
00007d07b35da468  pop r9
00007d07b35da46a  pop r8
00007d07b35da46c  pop rsi
00007d07b35da46d  pop rdi
00007d07b35da46e  pop rdx
00007d07b35da46f  pop rcx
00007d07b35da470  pop rax
00007d07b35da471  add rsp, 0x08
00007d07b35da475  jmp 0x00007D07B35D6441
00007d07b35da47a  sub rsp, 0x08
00007d07b35da47e  push rax
00007d07b35da47f  push rcx
00007d07b35da480  push rdx
00007d07b35da481  push rdi
00007d07b35da482  push rsi
00007d07b35da483  push r8
00007d07b35da485  push r9
00007d07b35da487  push r10
00007d07b35da489  push r11
00007d07b35da48b  sub rsp, 0xF0
00007d07b35da492  vmovaps [rsp], xmm0
00007d07b35da497  vmovaps [rsp+0x10], xmm1
00007d07b35da49d  vmovaps [rsp+0x20], xmm2
00007d07b35da4a3  vmovaps [rsp+0x30], xmm3
00007d07b35da4a9  vmovaps [rsp+0x40], xmm4
00007d07b35da4af  vmovaps [rsp+0x50], xmm5
00007d07b35da4b5  vmovaps [rsp+0x60], xmm6
00007d07b35da4bb  vmovaps [rsp+0x70], xmm7
00007d07b35da4c1  vmovaps [rsp+0x80], xmm8
00007d07b35da4ca  vmovaps [rsp+0x90], xmm9
00007d07b35da4d3  vmovaps [rsp+0xA0], xmm10
00007d07b35da4dc  vmovaps [rsp+0xB0], xmm11
00007d07b35da4e5  vmovaps [rsp+0xC0], xmm12
00007d07b35da4ee  vmovaps [rsp+0xD0], xmm14
00007d07b35da4f7  vmovaps [rsp+0xE0], xmm15
00007d07b35da500  sub rsp, 0x30
00007d07b35da504  movaps [rsp], xmm13
00007d07b35da509  movaps [rsp+0x10], xmm15
00007d07b35da50f  movaps [rsp+0x20], xmm8
00007d07b35da515  lea rdi, [rsp]
00007d07b35da519  mov esi, 0x00
00007d07b35da51e  mov rax, 0x5D0AA712D530
00007d07b35da528  call rax
00007d07b35da52a  movaps xmm13, [rsp]
00007d07b35da52f  add rsp, 0x30
00007d07b35da533  vmovaps xmm0, [rsp]
00007d07b35da538  vmovaps xmm1, [rsp+0x10]
00007d07b35da53e  vmovaps xmm2, [rsp+0x20]
00007d07b35da544  vmovaps xmm3, [rsp+0x30]
00007d07b35da54a  vmovaps xmm4, [rsp+0x40]
00007d07b35da550  vmovaps xmm5, [rsp+0x50]
00007d07b35da556  vmovaps xmm6, [rsp+0x60]
00007d07b35da55c  vmovaps xmm7, [rsp+0x70]
00007d07b35da562  vmovaps xmm8, [rsp+0x80]
00007d07b35da56b  vmovaps xmm9, [rsp+0x90]
00007d07b35da574  vmovaps xmm10, [rsp+0xA0]
00007d07b35da57d  vmovaps xmm11, [rsp+0xB0]
00007d07b35da586  vmovaps xmm12, [rsp+0xC0]
00007d07b35da58f  vmovaps xmm14, [rsp+0xD0]
00007d07b35da598  vmovaps xmm15, [rsp+0xE0]
00007d07b35da5a1  add rsp, 0xF0
00007d07b35da5a8  pop r11
00007d07b35da5aa  pop r10
00007d07b35da5ac  pop r9
00007d07b35da5ae  pop r8
00007d07b35da5b0  pop rsi
00007d07b35da5b1  pop rdi
00007d07b35da5b2  pop rdx
00007d07b35da5b3  pop rcx
00007d07b35da5b4  pop rax
00007d07b35da5b5  add rsp, 0x08
00007d07b35da5b9  jmp 0x00007D07B35D645C
00007d07b35da5be  sub rsp, 0x08
00007d07b35da5c2  push rax
00007d07b35da5c3  push rcx
00007d07b35da5c4  push rdx
00007d07b35da5c5  push rdi
00007d07b35da5c6  push rsi
00007d07b35da5c7  push r8
00007d07b35da5c9  push r9
00007d07b35da5cb  push r10
00007d07b35da5cd  push r11
00007d07b35da5cf  sub rsp, 0xF0
00007d07b35da5d6  vmovaps [rsp], xmm0
00007d07b35da5db  vmovaps [rsp+0x10], xmm1
00007d07b35da5e1  vmovaps [rsp+0x20], xmm2
00007d07b35da5e7  vmovaps [rsp+0x30], xmm3
00007d07b35da5ed  vmovaps [rsp+0x40], xmm4
00007d07b35da5f3  vmovaps [rsp+0x50], xmm5
00007d07b35da5f9  vmovaps [rsp+0x60], xmm6
00007d07b35da5ff  vmovaps [rsp+0x70], xmm7
00007d07b35da605  vmovaps [rsp+0x80], xmm9
00007d07b35da60e  vmovaps [rsp+0x90], xmm10
00007d07b35da617  vmovaps [rsp+0xA0], xmm11
00007d07b35da620  vmovaps [rsp+0xB0], xmm12
00007d07b35da629  vmovaps [rsp+0xC0], xmm13
00007d07b35da632  vmovaps [rsp+0xD0], xmm14
00007d07b35da63b  vmovaps [rsp+0xE0], xmm15
00007d07b35da644  sub rsp, 0x30
00007d07b35da648  movaps [rsp], xmm8
00007d07b35da64d  movaps [rsp+0x10], xmm15
00007d07b35da653  movaps [rsp+0x20], xmm9
00007d07b35da659  lea rdi, [rsp]
00007d07b35da65d  mov esi, 0x00
00007d07b35da662  mov rax, 0x5D0AA712D530
00007d07b35da66c  call rax
00007d07b35da66e  movaps xmm8, [rsp]
00007d07b35da673  add rsp, 0x30
00007d07b35da677  vmovaps xmm0, [rsp]
00007d07b35da67c  vmovaps xmm1, [rsp+0x10]
00007d07b35da682  vmovaps xmm2, [rsp+0x20]
00007d07b35da688  vmovaps xmm3, [rsp+0x30]
00007d07b35da68e  vmovaps xmm4, [rsp+0x40]
00007d07b35da694  vmovaps xmm5, [rsp+0x50]
00007d07b35da69a  vmovaps xmm6, [rsp+0x60]
00007d07b35da6a0  vmovaps xmm7, [rsp+0x70]
00007d07b35da6a6  vmovaps xmm9, [rsp+0x80]
00007d07b35da6af  vmovaps xmm10, [rsp+0x90]
00007d07b35da6b8  vmovaps xmm11, [rsp+0xA0]
00007d07b35da6c1  vmovaps xmm12, [rsp+0xB0]
00007d07b35da6ca  vmovaps xmm13, [rsp+0xC0]
00007d07b35da6d3  vmovaps xmm14, [rsp+0xD0]
00007d07b35da6dc  vmovaps xmm15, [rsp+0xE0]
00007d07b35da6e5  add rsp, 0xF0
00007d07b35da6ec  pop r11
00007d07b35da6ee  pop r10
00007d07b35da6f0  pop r9
00007d07b35da6f2  pop r8
00007d07b35da6f4  pop rsi
00007d07b35da6f5  pop rdi
00007d07b35da6f6  pop rdx
00007d07b35da6f7  pop rcx
00007d07b35da6f8  pop rax
00007d07b35da6f9  add rsp, 0x08
00007d07b35da6fd  jmp 0x00007D07B35D648A
00007d07b35da702  sub rsp, 0x08
00007d07b35da706  push rax
00007d07b35da707  push rcx
00007d07b35da708  push rdx
00007d07b35da709  push rdi
00007d07b35da70a  push rsi
00007d07b35da70b  push r8
00007d07b35da70d  push r9
00007d07b35da70f  push r10
00007d07b35da711  push r11
00007d07b35da713  sub rsp, 0xF0
00007d07b35da71a  vmovaps [rsp], xmm0
00007d07b35da71f  vmovaps [rsp+0x10], xmm1
00007d07b35da725  vmovaps [rsp+0x20], xmm2
00007d07b35da72b  vmovaps [rsp+0x30], xmm3
00007d07b35da731  vmovaps [rsp+0x40], xmm4
00007d07b35da737  vmovaps [rsp+0x50], xmm5
00007d07b35da73d  vmovaps [rsp+0x60], xmm6
00007d07b35da743  vmovaps [rsp+0x70], xmm7
00007d07b35da749  vmovaps [rsp+0x80], xmm8
00007d07b35da752  vmovaps [rsp+0x90], xmm9
00007d07b35da75b  vmovaps [rsp+0xA0], xmm10
00007d07b35da764  vmovaps [rsp+0xB0], xmm11
00007d07b35da76d  vmovaps [rsp+0xC0], xmm12
00007d07b35da776  vmovaps [rsp+0xD0], xmm13
00007d07b35da77f  vmovaps [rsp+0xE0], xmm14
00007d07b35da788  sub rsp, 0x30
00007d07b35da78c  movaps [rsp], xmm15
00007d07b35da791  movaps [rsp+0x10], xmm11
00007d07b35da797  movaps [rsp+0x20], xmm6
00007d07b35da79c  lea rdi, [rsp]
00007d07b35da7a0  mov esi, 0x00
00007d07b35da7a5  mov rax, 0x5D0AA712D530
00007d07b35da7af  call rax
00007d07b35da7b1  movaps xmm15, [rsp]
00007d07b35da7b6  add rsp, 0x30
00007d07b35da7ba  vmovaps xmm0, [rsp]
00007d07b35da7bf  vmovaps xmm1, [rsp+0x10]
00007d07b35da7c5  vmovaps xmm2, [rsp+0x20]
00007d07b35da7cb  vmovaps xmm3, [rsp+0x30]
00007d07b35da7d1  vmovaps xmm4, [rsp+0x40]
00007d07b35da7d7  vmovaps xmm5, [rsp+0x50]
00007d07b35da7dd  vmovaps xmm6, [rsp+0x60]
00007d07b35da7e3  vmovaps xmm7, [rsp+0x70]
00007d07b35da7e9  vmovaps xmm8, [rsp+0x80]
00007d07b35da7f2  vmovaps xmm9, [rsp+0x90]
00007d07b35da7fb  vmovaps xmm10, [rsp+0xA0]
00007d07b35da804  vmovaps xmm11, [rsp+0xB0]
00007d07b35da80d  vmovaps xmm12, [rsp+0xC0]
00007d07b35da816  vmovaps xmm13, [rsp+0xD0]
00007d07b35da81f  vmovaps xmm14, [rsp+0xE0]
00007d07b35da828  add rsp, 0xF0
00007d07b35da82f  pop r11
00007d07b35da831  pop r10
00007d07b35da833  pop r9
00007d07b35da835  pop r8
00007d07b35da837  pop rsi
00007d07b35da838  pop rdi
00007d07b35da839  pop rdx
00007d07b35da83a  pop rcx
00007d07b35da83b  pop rax
00007d07b35da83c  add rsp, 0x08
00007d07b35da840  jmp 0x00007D07B35D64A5
00007d07b35da845  sub rsp, 0x08
00007d07b35da849  push rax
00007d07b35da84a  push rcx
00007d07b35da84b  push rdx
00007d07b35da84c  push rdi
00007d07b35da84d  push rsi
00007d07b35da84e  push r8
00007d07b35da850  push r9
00007d07b35da852  push r10
00007d07b35da854  push r11
00007d07b35da856  sub rsp, 0xF0
00007d07b35da85d  vmovaps [rsp], xmm0
00007d07b35da862  vmovaps [rsp+0x10], xmm1
00007d07b35da868  vmovaps [rsp+0x20], xmm2
00007d07b35da86e  vmovaps [rsp+0x30], xmm3
00007d07b35da874  vmovaps [rsp+0x40], xmm4
00007d07b35da87a  vmovaps [rsp+0x50], xmm5
00007d07b35da880  vmovaps [rsp+0x60], xmm6
00007d07b35da886  vmovaps [rsp+0x70], xmm8
00007d07b35da88c  vmovaps [rsp+0x80], xmm9
00007d07b35da895  vmovaps [rsp+0x90], xmm10
00007d07b35da89e  vmovaps [rsp+0xA0], xmm11
00007d07b35da8a7  vmovaps [rsp+0xB0], xmm12
00007d07b35da8b0  vmovaps [rsp+0xC0], xmm13
00007d07b35da8b9  vmovaps [rsp+0xD0], xmm14
00007d07b35da8c2  vmovaps [rsp+0xE0], xmm15
00007d07b35da8cb  sub rsp, 0x30
00007d07b35da8cf  movaps [rsp], xmm7
00007d07b35da8d3  movaps [rsp+0x10], xmm11
00007d07b35da8d9  movaps [rsp+0x20], xmm9
00007d07b35da8df  lea rdi, [rsp]
00007d07b35da8e3  mov esi, 0x00
00007d07b35da8e8  mov rax, 0x5D0AA712D530
00007d07b35da8f2  call rax
00007d07b35da8f4  movaps xmm7, [rsp]
00007d07b35da8f8  add rsp, 0x30
00007d07b35da8fc  vmovaps xmm0, [rsp]
00007d07b35da901  vmovaps xmm1, [rsp+0x10]
00007d07b35da907  vmovaps xmm2, [rsp+0x20]
00007d07b35da90d  vmovaps xmm3, [rsp+0x30]
00007d07b35da913  vmovaps xmm4, [rsp+0x40]
00007d07b35da919  vmovaps xmm5, [rsp+0x50]
00007d07b35da91f  vmovaps xmm6, [rsp+0x60]
00007d07b35da925  vmovaps xmm8, [rsp+0x70]
00007d07b35da92b  vmovaps xmm9, [rsp+0x80]
00007d07b35da934  vmovaps xmm10, [rsp+0x90]
00007d07b35da93d  vmovaps xmm11, [rsp+0xA0]
00007d07b35da946  vmovaps xmm12, [rsp+0xB0]
00007d07b35da94f  vmovaps xmm13, [rsp+0xC0]
00007d07b35da958  vmovaps xmm14, [rsp+0xD0]
00007d07b35da961  vmovaps xmm15, [rsp+0xE0]
00007d07b35da96a  add rsp, 0xF0
00007d07b35da971  pop r11
00007d07b35da973  pop r10
00007d07b35da975  pop r9
00007d07b35da977  pop r8
00007d07b35da979  pop rsi
00007d07b35da97a  pop rdi
00007d07b35da97b  pop rdx
00007d07b35da97c  pop rcx
00007d07b35da97d  pop rax
00007d07b35da97e  add rsp, 0x08
00007d07b35da982  jmp 0x00007D07B35D64D2
00007d07b35da987  sub rsp, 0x08
00007d07b35da98b  push rax
00007d07b35da98c  push rcx
00007d07b35da98d  push rdx
00007d07b35da98e  push rdi
00007d07b35da98f  push rsi
00007d07b35da990  push r8
00007d07b35da992  push r9
00007d07b35da994  push r10
00007d07b35da996  push r11
00007d07b35da998  sub rsp, 0xF0
00007d07b35da99f  vmovaps [rsp], xmm0
00007d07b35da9a4  vmovaps [rsp+0x10], xmm1
00007d07b35da9aa  vmovaps [rsp+0x20], xmm2
00007d07b35da9b0  vmovaps [rsp+0x30], xmm3
00007d07b35da9b6  vmovaps [rsp+0x40], xmm4
00007d07b35da9bc  vmovaps [rsp+0x50], xmm5
00007d07b35da9c2  vmovaps [rsp+0x60], xmm6
00007d07b35da9c8  vmovaps [rsp+0x70], xmm7
00007d07b35da9ce  vmovaps [rsp+0x80], xmm8
00007d07b35da9d7  vmovaps [rsp+0x90], xmm9
00007d07b35da9e0  vmovaps [rsp+0xA0], xmm10
00007d07b35da9e9  vmovaps [rsp+0xB0], xmm12
00007d07b35da9f2  vmovaps [rsp+0xC0], xmm13
00007d07b35da9fb  vmovaps [rsp+0xD0], xmm14
00007d07b35daa04  vmovaps [rsp+0xE0], xmm15
00007d07b35daa0d  sub rsp, 0x30
00007d07b35daa11  movaps [rsp], xmm11
00007d07b35daa16  movaps [rsp+0x10], xmm10
00007d07b35daa1c  movaps [rsp+0x20], xmm14
00007d07b35daa22  lea rdi, [rsp]
00007d07b35daa26  mov esi, 0x00
00007d07b35daa2b  mov rax, 0x5D0AA712D530
00007d07b35daa35  call rax
00007d07b35daa37  movaps xmm11, [rsp]
00007d07b35daa3c  add rsp, 0x30
00007d07b35daa40  vmovaps xmm0, [rsp]
00007d07b35daa45  vmovaps xmm1, [rsp+0x10]
00007d07b35daa4b  vmovaps xmm2, [rsp+0x20]
00007d07b35daa51  vmovaps xmm3, [rsp+0x30]
00007d07b35daa57  vmovaps xmm4, [rsp+0x40]
00007d07b35daa5d  vmovaps xmm5, [rsp+0x50]
00007d07b35daa63  vmovaps xmm6, [rsp+0x60]
00007d07b35daa69  vmovaps xmm7, [rsp+0x70]
00007d07b35daa6f  vmovaps xmm8, [rsp+0x80]
00007d07b35daa78  vmovaps xmm9, [rsp+0x90]
00007d07b35daa81  vmovaps xmm10, [rsp+0xA0]
00007d07b35daa8a  vmovaps xmm12, [rsp+0xB0]
00007d07b35daa93  vmovaps xmm13, [rsp+0xC0]
00007d07b35daa9c  vmovaps xmm14, [rsp+0xD0]
00007d07b35daaa5  vmovaps xmm15, [rsp+0xE0]
00007d07b35daaae  add rsp, 0xF0
00007d07b35daab5  pop r11
00007d07b35daab7  pop r10
00007d07b35daab9  pop r9
00007d07b35daabb  pop r8
00007d07b35daabd  pop rsi
00007d07b35daabe  pop rdi
00007d07b35daabf  pop rdx
00007d07b35daac0  pop rcx
00007d07b35daac1  pop rax
00007d07b35daac2  add rsp, 0x08
00007d07b35daac6  jmp 0x00007D07B35D64ED
00007d07b35daacb  call 0x00007D07B34E45A0
00007d07b35daad0  jmp 0x00007D07B35D64F7
00007d07b35daad5  sub rsp, 0x08
00007d07b35daad9  push rax
00007d07b35daada  push rcx
00007d07b35daadb  push rdx
00007d07b35daadc  push rdi
00007d07b35daadd  push rsi
00007d07b35daade  push r8
00007d07b35daae0  push r9
00007d07b35daae2  push r10
00007d07b35daae4  push r11
00007d07b35daae6  sub rsp, 0xF0
00007d07b35daaed  vmovaps [rsp], xmm0
00007d07b35daaf2  vmovaps [rsp+0x10], xmm1
00007d07b35daaf8  vmovaps [rsp+0x20], xmm2
00007d07b35daafe  vmovaps [rsp+0x30], xmm3
00007d07b35dab04  vmovaps [rsp+0x40], xmm4
00007d07b35dab0a  vmovaps [rsp+0x50], xmm5
00007d07b35dab10  vmovaps [rsp+0x60], xmm6
00007d07b35dab16  vmovaps [rsp+0x70], xmm7
00007d07b35dab1c  vmovaps [rsp+0x80], xmm8
00007d07b35dab25  vmovaps [rsp+0x90], xmm9
00007d07b35dab2e  vmovaps [rsp+0xA0], xmm11
00007d07b35dab37  vmovaps [rsp+0xB0], xmm12
00007d07b35dab40  vmovaps [rsp+0xC0], xmm13
00007d07b35dab49  vmovaps [rsp+0xD0], xmm14
00007d07b35dab52  vmovaps [rsp+0xE0], xmm15
00007d07b35dab5b  sub rsp, 0x30
00007d07b35dab5f  movaps [rsp], xmm10
00007d07b35dab64  movaps [rsp+0x10], xmm1
00007d07b35dab69  movaps [rsp+0x20], xmm12
00007d07b35dab6f  lea rdi, [rsp]
00007d07b35dab73  mov esi, 0x00
00007d07b35dab78  mov rax, 0x5D0AA712D530
00007d07b35dab82  call rax
00007d07b35dab84  movaps xmm10, [rsp]
00007d07b35dab89  add rsp, 0x30
00007d07b35dab8d  vmovaps xmm0, [rsp]
00007d07b35dab92  vmovaps xmm1, [rsp+0x10]
00007d07b35dab98  vmovaps xmm2, [rsp+0x20]
00007d07b35dab9e  vmovaps xmm3, [rsp+0x30]
00007d07b35daba4  vmovaps xmm4, [rsp+0x40]
00007d07b35dabaa  vmovaps xmm5, [rsp+0x50]
00007d07b35dabb0  vmovaps xmm6, [rsp+0x60]
00007d07b35dabb6  vmovaps xmm7, [rsp+0x70]
00007d07b35dabbc  vmovaps xmm8, [rsp+0x80]
00007d07b35dabc5  vmovaps xmm9, [rsp+0x90]
00007d07b35dabce  vmovaps xmm11, [rsp+0xA0]
00007d07b35dabd7  vmovaps xmm12, [rsp+0xB0]
00007d07b35dabe0  vmovaps xmm13, [rsp+0xC0]
00007d07b35dabe9  vmovaps xmm14, [rsp+0xD0]
00007d07b35dabf2  vmovaps xmm15, [rsp+0xE0]
00007d07b35dabfb  add rsp, 0xF0
00007d07b35dac02  pop r11
00007d07b35dac04  pop r10
00007d07b35dac06  pop r9
00007d07b35dac08  pop r8
00007d07b35dac0a  pop rsi
00007d07b35dac0b  pop rdi
00007d07b35dac0c  pop rdx
00007d07b35dac0d  pop rcx
00007d07b35dac0e  pop rax
00007d07b35dac0f  add rsp, 0x08
00007d07b35dac13  jmp 0x00007D07B35D651A
00007d07b35dac18  sub rsp, 0x08
00007d07b35dac1c  push rax
00007d07b35dac1d  push rcx
00007d07b35dac1e  push rdx
00007d07b35dac1f  push rdi
00007d07b35dac20  push rsi
00007d07b35dac21  push r8
00007d07b35dac23  push r9
00007d07b35dac25  push r10
00007d07b35dac27  push r11
00007d07b35dac29  sub rsp, 0xF0
00007d07b35dac30  vmovaps [rsp], xmm0
00007d07b35dac35  vmovaps [rsp+0x10], xmm1
00007d07b35dac3b  vmovaps [rsp+0x20], xmm2
00007d07b35dac41  vmovaps [rsp+0x30], xmm3
00007d07b35dac47  vmovaps [rsp+0x40], xmm4
00007d07b35dac4d  vmovaps [rsp+0x50], xmm5
00007d07b35dac53  vmovaps [rsp+0x60], xmm6
00007d07b35dac59  vmovaps [rsp+0x70], xmm7
00007d07b35dac5f  vmovaps [rsp+0x80], xmm8
00007d07b35dac68  vmovaps [rsp+0x90], xmm9
00007d07b35dac71  vmovaps [rsp+0xA0], xmm10
00007d07b35dac7a  vmovaps [rsp+0xB0], xmm11
00007d07b35dac83  vmovaps [rsp+0xC0], xmm13
00007d07b35dac8c  vmovaps [rsp+0xD0], xmm14
00007d07b35dac95  vmovaps [rsp+0xE0], xmm15
00007d07b35dac9e  sub rsp, 0x30
00007d07b35daca2  movaps [rsp], xmm12
00007d07b35daca7  movaps [rsp+0x10], xmm14
00007d07b35dacad  movaps [rsp+0x20], xmm1
00007d07b35dacb2  lea rdi, [rsp]
00007d07b35dacb6  mov esi, 0x00
00007d07b35dacbb  mov rax, 0x5D0AA712D530
00007d07b35dacc5  call rax
00007d07b35dacc7  movaps xmm12, [rsp]
00007d07b35daccc  add rsp, 0x30
00007d07b35dacd0  vmovaps xmm0, [rsp]
00007d07b35dacd5  vmovaps xmm1, [rsp+0x10]
00007d07b35dacdb  vmovaps xmm2, [rsp+0x20]
00007d07b35dace1  vmovaps xmm3, [rsp+0x30]
00007d07b35dace7  vmovaps xmm4, [rsp+0x40]
00007d07b35daced  vmovaps xmm5, [rsp+0x50]
00007d07b35dacf3  vmovaps xmm6, [rsp+0x60]
00007d07b35dacf9  vmovaps xmm7, [rsp+0x70]
00007d07b35dacff  vmovaps xmm8, [rsp+0x80]
00007d07b35dad08  vmovaps xmm9, [rsp+0x90]
00007d07b35dad11  vmovaps xmm10, [rsp+0xA0]
00007d07b35dad1a  vmovaps xmm11, [rsp+0xB0]
00007d07b35dad23  vmovaps xmm13, [rsp+0xC0]
00007d07b35dad2c  vmovaps xmm14, [rsp+0xD0]
00007d07b35dad35  vmovaps xmm15, [rsp+0xE0]
00007d07b35dad3e  add rsp, 0xF0
00007d07b35dad45  pop r11
00007d07b35dad47  pop r10
00007d07b35dad49  pop r9
00007d07b35dad4b  pop r8
00007d07b35dad4d  pop rsi
00007d07b35dad4e  pop rdi
00007d07b35dad4f  pop rdx
00007d07b35dad50  pop rcx
00007d07b35dad51  pop rax
00007d07b35dad52  add rsp, 0x08
00007d07b35dad56  jmp 0x00007D07B35D6549
00007d07b35dad5b  sub rsp, 0x08
00007d07b35dad5f  push rax
00007d07b35dad60  push rcx
00007d07b35dad61  push rdx
00007d07b35dad62  push rdi
00007d07b35dad63  push rsi
00007d07b35dad64  push r8
00007d07b35dad66  push r9
00007d07b35dad68  push r10
00007d07b35dad6a  push r11
00007d07b35dad6c  sub rsp, 0xF0
00007d07b35dad73  vmovaps [rsp], xmm0
00007d07b35dad78  vmovaps [rsp+0x10], xmm1
00007d07b35dad7e  vmovaps [rsp+0x20], xmm2
00007d07b35dad84  vmovaps [rsp+0x30], xmm3
00007d07b35dad8a  vmovaps [rsp+0x40], xmm4
00007d07b35dad90  vmovaps [rsp+0x50], xmm5
00007d07b35dad96  vmovaps [rsp+0x60], xmm6
00007d07b35dad9c  vmovaps [rsp+0x70], xmm7
00007d07b35dada2  vmovaps [rsp+0x80], xmm8
00007d07b35dadab  vmovaps [rsp+0x90], xmm9
00007d07b35dadb4  vmovaps [rsp+0xA0], xmm10
00007d07b35dadbd  vmovaps [rsp+0xB0], xmm11
00007d07b35dadc6  vmovaps [rsp+0xC0], xmm12
00007d07b35dadcf  vmovaps [rsp+0xD0], xmm13
00007d07b35dadd8  vmovaps [rsp+0xE0], xmm15
00007d07b35dade1  sub rsp, 0x30
00007d07b35dade5  movaps [rsp], xmm14
00007d07b35dadea  movaps [rsp+0x10], xmm9
00007d07b35dadf0  movaps [rsp+0x20], xmm1
00007d07b35dadf5  lea rdi, [rsp]
00007d07b35dadf9  mov esi, 0x00
00007d07b35dadfe  mov rax, 0x5D0AA712D530
00007d07b35dae08  call rax
00007d07b35dae0a  movaps xmm14, [rsp]
00007d07b35dae0f  add rsp, 0x30
00007d07b35dae13  vmovaps xmm0, [rsp]
00007d07b35dae18  vmovaps xmm1, [rsp+0x10]
00007d07b35dae1e  vmovaps xmm2, [rsp+0x20]
00007d07b35dae24  vmovaps xmm3, [rsp+0x30]
00007d07b35dae2a  vmovaps xmm4, [rsp+0x40]
00007d07b35dae30  vmovaps xmm5, [rsp+0x50]
00007d07b35dae36  vmovaps xmm6, [rsp+0x60]
00007d07b35dae3c  vmovaps xmm7, [rsp+0x70]
00007d07b35dae42  vmovaps xmm8, [rsp+0x80]
00007d07b35dae4b  vmovaps xmm9, [rsp+0x90]
00007d07b35dae54  vmovaps xmm10, [rsp+0xA0]
00007d07b35dae5d  vmovaps xmm11, [rsp+0xB0]
00007d07b35dae66  vmovaps xmm12, [rsp+0xC0]
00007d07b35dae6f  vmovaps xmm13, [rsp+0xD0]
00007d07b35dae78  vmovaps xmm15, [rsp+0xE0]
00007d07b35dae81  add rsp, 0xF0
00007d07b35dae88  pop r11
00007d07b35dae8a  pop r10
00007d07b35dae8c  pop r9
00007d07b35dae8e  pop r8
00007d07b35dae90  pop rsi
00007d07b35dae91  pop rdi
00007d07b35dae92  pop rdx
00007d07b35dae93  pop rcx
00007d07b35dae94  pop rax
00007d07b35dae95  add rsp, 0x08
00007d07b35dae99  jmp 0x00007D07B35D6578
00007d07b35dae9e  sub rsp, 0x08
00007d07b35daea2  push rax
00007d07b35daea3  push rcx
00007d07b35daea4  push rdx
00007d07b35daea5  push rdi
00007d07b35daea6  push rsi
00007d07b35daea7  push r8
00007d07b35daea9  push r9
00007d07b35daeab  push r10
00007d07b35daead  push r11
00007d07b35daeaf  sub rsp, 0xF0
00007d07b35daeb6  vmovaps [rsp], xmm0
00007d07b35daebb  vmovaps [rsp+0x10], xmm2
00007d07b35daec1  vmovaps [rsp+0x20], xmm3
00007d07b35daec7  vmovaps [rsp+0x30], xmm4
00007d07b35daecd  vmovaps [rsp+0x40], xmm5
00007d07b35daed3  vmovaps [rsp+0x50], xmm6
00007d07b35daed9  vmovaps [rsp+0x60], xmm7
00007d07b35daedf  vmovaps [rsp+0x70], xmm8
00007d07b35daee5  vmovaps [rsp+0x80], xmm9
00007d07b35daeee  vmovaps [rsp+0x90], xmm10
00007d07b35daef7  vmovaps [rsp+0xA0], xmm11
00007d07b35daf00  vmovaps [rsp+0xB0], xmm12
00007d07b35daf09  vmovaps [rsp+0xC0], xmm13
00007d07b35daf12  vmovaps [rsp+0xD0], xmm14
00007d07b35daf1b  vmovaps [rsp+0xE0], xmm15
00007d07b35daf24  sub rsp, 0x30
00007d07b35daf28  movaps [rsp], xmm1
00007d07b35daf2c  movaps [rsp+0x10], xmm13
00007d07b35daf32  movaps [rsp+0x20], xmm8
00007d07b35daf38  lea rdi, [rsp]
00007d07b35daf3c  mov esi, 0x00
00007d07b35daf41  mov rax, 0x5D0AA712D530
00007d07b35daf4b  call rax
00007d07b35daf4d  movaps xmm1, [rsp]
00007d07b35daf51  add rsp, 0x30
00007d07b35daf55  vmovaps xmm0, [rsp]
00007d07b35daf5a  vmovaps xmm2, [rsp+0x10]
00007d07b35daf60  vmovaps xmm3, [rsp+0x20]
00007d07b35daf66  vmovaps xmm4, [rsp+0x30]
00007d07b35daf6c  vmovaps xmm5, [rsp+0x40]
00007d07b35daf72  vmovaps xmm6, [rsp+0x50]
00007d07b35daf78  vmovaps xmm7, [rsp+0x60]
00007d07b35daf7e  vmovaps xmm8, [rsp+0x70]
00007d07b35daf84  vmovaps xmm9, [rsp+0x80]
00007d07b35daf8d  vmovaps xmm10, [rsp+0x90]
00007d07b35daf96  vmovaps xmm11, [rsp+0xA0]
00007d07b35daf9f  vmovaps xmm12, [rsp+0xB0]
00007d07b35dafa8  vmovaps xmm13, [rsp+0xC0]
00007d07b35dafb1  vmovaps xmm14, [rsp+0xD0]
00007d07b35dafba  vmovaps xmm15, [rsp+0xE0]
00007d07b35dafc3  add rsp, 0xF0
00007d07b35dafca  pop r11
00007d07b35dafcc  pop r10
00007d07b35dafce  pop r9
00007d07b35dafd0  pop r8
00007d07b35dafd2  pop rsi
00007d07b35dafd3  pop rdi
00007d07b35dafd4  pop rdx
00007d07b35dafd5  pop rcx
00007d07b35dafd6  pop rax
00007d07b35dafd7  add rsp, 0x08
00007d07b35dafdb  jmp 0x00007D07B35D659A
00007d07b35dafe0  call 0x00007D07B340C260
00007d07b35dafe5  jmp 0x00007D07B35D65A8
00007d07b35dafea  call 0x00007D07B34DE950
00007d07b35dafef  jmp 0x00007D07B35D65B2
00007d07b35daff4  sub rsp, 0x08
00007d07b35daff8  push rax
00007d07b35daff9  push rcx
00007d07b35daffa  push rdx
00007d07b35daffb  push rdi
00007d07b35daffc  push rsi
00007d07b35daffd  push r8
00007d07b35dafff  push r9
00007d07b35db001  push r10
00007d07b35db003  push r11
00007d07b35db005  sub rsp, 0xF0
00007d07b35db00c  vmovaps [rsp], xmm0
00007d07b35db011  vmovaps [rsp+0x10], xmm1
00007d07b35db017  vmovaps [rsp+0x20], xmm2
00007d07b35db01d  vmovaps [rsp+0x30], xmm3
00007d07b35db023  vmovaps [rsp+0x40], xmm4
00007d07b35db029  vmovaps [rsp+0x50], xmm5
00007d07b35db02f  vmovaps [rsp+0x60], xmm6
00007d07b35db035  vmovaps [rsp+0x70], xmm7
00007d07b35db03b  vmovaps [rsp+0x80], xmm9
00007d07b35db044  vmovaps [rsp+0x90], xmm10
00007d07b35db04d  vmovaps [rsp+0xA0], xmm11
00007d07b35db056  vmovaps [rsp+0xB0], xmm12
00007d07b35db05f  vmovaps [rsp+0xC0], xmm13
00007d07b35db068  vmovaps [rsp+0xD0], xmm14
00007d07b35db071  vmovaps [rsp+0xE0], xmm15
00007d07b35db07a  sub rsp, 0x30
00007d07b35db07e  movaps [rsp], xmm8
00007d07b35db083  movaps [rsp+0x10], xmm15
00007d07b35db089  movaps [rsp+0x20], xmm7
00007d07b35db08e  lea rdi, [rsp]
00007d07b35db092  mov esi, 0x00
00007d07b35db097  mov rax, 0x5D0AA712D530
00007d07b35db0a1  call rax
00007d07b35db0a3  movaps xmm8, [rsp]
00007d07b35db0a8  add rsp, 0x30
00007d07b35db0ac  vmovaps xmm0, [rsp]
00007d07b35db0b1  vmovaps xmm1, [rsp+0x10]
00007d07b35db0b7  vmovaps xmm2, [rsp+0x20]
00007d07b35db0bd  vmovaps xmm3, [rsp+0x30]
00007d07b35db0c3  vmovaps xmm4, [rsp+0x40]
00007d07b35db0c9  vmovaps xmm5, [rsp+0x50]
00007d07b35db0cf  vmovaps xmm6, [rsp+0x60]
00007d07b35db0d5  vmovaps xmm7, [rsp+0x70]
00007d07b35db0db  vmovaps xmm9, [rsp+0x80]
00007d07b35db0e4  vmovaps xmm10, [rsp+0x90]
00007d07b35db0ed  vmovaps xmm11, [rsp+0xA0]
00007d07b35db0f6  vmovaps xmm12, [rsp+0xB0]
00007d07b35db0ff  vmovaps xmm13, [rsp+0xC0]
00007d07b35db108  vmovaps xmm14, [rsp+0xD0]
00007d07b35db111  vmovaps xmm15, [rsp+0xE0]
00007d07b35db11a  add rsp, 0xF0
00007d07b35db121  pop r11
00007d07b35db123  pop r10
00007d07b35db125  pop r9
00007d07b35db127  pop r8
00007d07b35db129  pop rsi
00007d07b35db12a  pop rdi
00007d07b35db12b  pop rdx
00007d07b35db12c  pop rcx
00007d07b35db12d  pop rax
00007d07b35db12e  add rsp, 0x08
00007d07b35db132  jmp 0x00007D07B35D65D4
00007d07b35db137  sub rsp, 0x08
00007d07b35db13b  push rax
00007d07b35db13c  push rcx
00007d07b35db13d  push rdx
00007d07b35db13e  push rdi
00007d07b35db13f  push rsi
00007d07b35db140  push r8
00007d07b35db142  push r9
00007d07b35db144  push r10
00007d07b35db146  push r11
00007d07b35db148  sub rsp, 0xF0
00007d07b35db14f  vmovaps [rsp], xmm0
00007d07b35db154  vmovaps [rsp+0x10], xmm1
00007d07b35db15a  vmovaps [rsp+0x20], xmm2
00007d07b35db160  vmovaps [rsp+0x30], xmm3
00007d07b35db166  vmovaps [rsp+0x40], xmm4
00007d07b35db16c  vmovaps [rsp+0x50], xmm5
00007d07b35db172  vmovaps [rsp+0x60], xmm6
00007d07b35db178  vmovaps [rsp+0x70], xmm8
00007d07b35db17e  vmovaps [rsp+0x80], xmm9
00007d07b35db187  vmovaps [rsp+0x90], xmm10
00007d07b35db190  vmovaps [rsp+0xA0], xmm11
00007d07b35db199  vmovaps [rsp+0xB0], xmm12
00007d07b35db1a2  vmovaps [rsp+0xC0], xmm13
00007d07b35db1ab  vmovaps [rsp+0xD0], xmm14
00007d07b35db1b4  vmovaps [rsp+0xE0], xmm15
00007d07b35db1bd  sub rsp, 0x30
00007d07b35db1c1  movaps [rsp], xmm7
00007d07b35db1c5  movaps [rsp+0x10], xmm9
00007d07b35db1cb  movaps [rsp+0x20], xmm15
00007d07b35db1d1  lea rdi, [rsp]
00007d07b35db1d5  mov esi, 0x00
00007d07b35db1da  mov rax, 0x5D0AA712D530
00007d07b35db1e4  call rax
00007d07b35db1e6  movaps xmm7, [rsp]
00007d07b35db1ea  add rsp, 0x30
00007d07b35db1ee  vmovaps xmm0, [rsp]
00007d07b35db1f3  vmovaps xmm1, [rsp+0x10]
00007d07b35db1f9  vmovaps xmm2, [rsp+0x20]
00007d07b35db1ff  vmovaps xmm3, [rsp+0x30]
00007d07b35db205  vmovaps xmm4, [rsp+0x40]
00007d07b35db20b  vmovaps xmm5, [rsp+0x50]
00007d07b35db211  vmovaps xmm6, [rsp+0x60]
00007d07b35db217  vmovaps xmm8, [rsp+0x70]
00007d07b35db21d  vmovaps xmm9, [rsp+0x80]
00007d07b35db226  vmovaps xmm10, [rsp+0x90]
00007d07b35db22f  vmovaps xmm11, [rsp+0xA0]
00007d07b35db238  vmovaps xmm12, [rsp+0xB0]
00007d07b35db241  vmovaps xmm13, [rsp+0xC0]
00007d07b35db24a  vmovaps xmm14, [rsp+0xD0]
00007d07b35db253  vmovaps xmm15, [rsp+0xE0]
00007d07b35db25c  add rsp, 0xF0
00007d07b35db263  pop r11
00007d07b35db265  pop r10
00007d07b35db267  pop r9
00007d07b35db269  pop r8
00007d07b35db26b  pop rsi
00007d07b35db26c  pop rdi
00007d07b35db26d  pop rdx
00007d07b35db26e  pop rcx
00007d07b35db26f  pop rax
00007d07b35db270  add rsp, 0x08
00007d07b35db274  jmp 0x00007D07B35D6601
00007d07b35db279  sub rsp, 0x08
00007d07b35db27d  push rax
00007d07b35db27e  push rcx
00007d07b35db27f  push rdx
00007d07b35db280  push rdi
00007d07b35db281  push rsi
00007d07b35db282  push r8
00007d07b35db284  push r9
00007d07b35db286  push r10
00007d07b35db288  push r11
00007d07b35db28a  sub rsp, 0xF0
00007d07b35db291  vmovaps [rsp], xmm0
00007d07b35db296  vmovaps [rsp+0x10], xmm1
00007d07b35db29c  vmovaps [rsp+0x20], xmm2
00007d07b35db2a2  vmovaps [rsp+0x30], xmm3
00007d07b35db2a8  vmovaps [rsp+0x40], xmm4
00007d07b35db2ae  vmovaps [rsp+0x50], xmm5
00007d07b35db2b4  vmovaps [rsp+0x60], xmm6
00007d07b35db2ba  vmovaps [rsp+0x70], xmm7
00007d07b35db2c0  vmovaps [rsp+0x80], xmm8
00007d07b35db2c9  vmovaps [rsp+0x90], xmm10
00007d07b35db2d2  vmovaps [rsp+0xA0], xmm11
00007d07b35db2db  vmovaps [rsp+0xB0], xmm12
00007d07b35db2e4  vmovaps [rsp+0xC0], xmm13
00007d07b35db2ed  vmovaps [rsp+0xD0], xmm14
00007d07b35db2f6  vmovaps [rsp+0xE0], xmm15
00007d07b35db2ff  sub rsp, 0x30
00007d07b35db303  movaps [rsp], xmm9
00007d07b35db308  movaps [rsp+0x10], xmm13
00007d07b35db30e  movaps [rsp+0x20], xmm15
00007d07b35db314  lea rdi, [rsp]
00007d07b35db318  mov esi, 0x00
00007d07b35db31d  mov rax, 0x5D0AA712D530
00007d07b35db327  call rax
00007d07b35db329  movaps xmm9, [rsp]
00007d07b35db32e  add rsp, 0x30
00007d07b35db332  vmovaps xmm0, [rsp]
00007d07b35db337  vmovaps xmm1, [rsp+0x10]
00007d07b35db33d  vmovaps xmm2, [rsp+0x20]
00007d07b35db343  vmovaps xmm3, [rsp+0x30]
00007d07b35db349  vmovaps xmm4, [rsp+0x40]
00007d07b35db34f  vmovaps xmm5, [rsp+0x50]
00007d07b35db355  vmovaps xmm6, [rsp+0x60]
00007d07b35db35b  vmovaps xmm7, [rsp+0x70]
00007d07b35db361  vmovaps xmm8, [rsp+0x80]
00007d07b35db36a  vmovaps xmm10, [rsp+0x90]
00007d07b35db373  vmovaps xmm11, [rsp+0xA0]
00007d07b35db37c  vmovaps xmm12, [rsp+0xB0]
00007d07b35db385  vmovaps xmm13, [rsp+0xC0]
00007d07b35db38e  vmovaps xmm14, [rsp+0xD0]
00007d07b35db397  vmovaps xmm15, [rsp+0xE0]
00007d07b35db3a0  add rsp, 0xF0
00007d07b35db3a7  pop r11
00007d07b35db3a9  pop r10
00007d07b35db3ab  pop r9
00007d07b35db3ad  pop r8
00007d07b35db3af  pop rsi
00007d07b35db3b0  pop rdi
00007d07b35db3b1  pop rdx
00007d07b35db3b2  pop rcx
00007d07b35db3b3  pop rax
00007d07b35db3b4  add rsp, 0x08
00007d07b35db3b8  jmp 0x00007D07B35D662F
00007d07b35db3bd  sub rsp, 0x08
00007d07b35db3c1  push rax
00007d07b35db3c2  push rcx
00007d07b35db3c3  push rdx
00007d07b35db3c4  push rdi
00007d07b35db3c5  push rsi
00007d07b35db3c6  push r8
00007d07b35db3c8  push r9
00007d07b35db3ca  push r10
00007d07b35db3cc  push r11
00007d07b35db3ce  sub rsp, 0xF0
00007d07b35db3d5  vmovaps [rsp], xmm0
00007d07b35db3da  vmovaps [rsp+0x10], xmm1
00007d07b35db3e0  vmovaps [rsp+0x20], xmm2
00007d07b35db3e6  vmovaps [rsp+0x30], xmm3
00007d07b35db3ec  vmovaps [rsp+0x40], xmm4
00007d07b35db3f2  vmovaps [rsp+0x50], xmm5
00007d07b35db3f8  vmovaps [rsp+0x60], xmm6
00007d07b35db3fe  vmovaps [rsp+0x70], xmm7
00007d07b35db404  vmovaps [rsp+0x80], xmm8
00007d07b35db40d  vmovaps [rsp+0x90], xmm9
00007d07b35db416  vmovaps [rsp+0xA0], xmm10
00007d07b35db41f  vmovaps [rsp+0xB0], xmm11
00007d07b35db428  vmovaps [rsp+0xC0], xmm12
00007d07b35db431  vmovaps [rsp+0xD0], xmm13
00007d07b35db43a  vmovaps [rsp+0xE0], xmm14
00007d07b35db443  sub rsp, 0x30
00007d07b35db447  movaps [rsp], xmm15
00007d07b35db44c  movaps [rsp+0x10], xmm11
00007d07b35db452  movaps [rsp+0x20], xmm12
00007d07b35db458  lea rdi, [rsp]
00007d07b35db45c  mov esi, 0x00
00007d07b35db461  mov rax, 0x5D0AA712D530
00007d07b35db46b  call rax
00007d07b35db46d  movaps xmm15, [rsp]
00007d07b35db472  add rsp, 0x30
00007d07b35db476  vmovaps xmm0, [rsp]
00007d07b35db47b  vmovaps xmm1, [rsp+0x10]
00007d07b35db481  vmovaps xmm2, [rsp+0x20]
00007d07b35db487  vmovaps xmm3, [rsp+0x30]
00007d07b35db48d  vmovaps xmm4, [rsp+0x40]
00007d07b35db493  vmovaps xmm5, [rsp+0x50]
00007d07b35db499  vmovaps xmm6, [rsp+0x60]
00007d07b35db49f  vmovaps xmm7, [rsp+0x70]
00007d07b35db4a5  vmovaps xmm8, [rsp+0x80]
00007d07b35db4ae  vmovaps xmm9, [rsp+0x90]
00007d07b35db4b7  vmovaps xmm10, [rsp+0xA0]
00007d07b35db4c0  vmovaps xmm11, [rsp+0xB0]
00007d07b35db4c9  vmovaps xmm12, [rsp+0xC0]
00007d07b35db4d2  vmovaps xmm13, [rsp+0xD0]
00007d07b35db4db  vmovaps xmm14, [rsp+0xE0]
00007d07b35db4e4  add rsp, 0xF0
00007d07b35db4eb  pop r11
00007d07b35db4ed  pop r10
00007d07b35db4ef  pop r9
00007d07b35db4f1  pop r8
00007d07b35db4f3  pop rsi
00007d07b35db4f4  pop rdi
00007d07b35db4f5  pop rdx
00007d07b35db4f6  pop rcx
00007d07b35db4f7  pop rax
00007d07b35db4f8  add rsp, 0x08
00007d07b35db4fc  jmp 0x00007D07B35D664A
00007d07b35db501  sub rsp, 0x08
00007d07b35db505  push rax
00007d07b35db506  push rcx
00007d07b35db507  push rdx
00007d07b35db508  push rdi
00007d07b35db509  push rsi
00007d07b35db50a  push r8
00007d07b35db50c  push r9
00007d07b35db50e  push r10
00007d07b35db510  push r11
00007d07b35db512  sub rsp, 0xF0
00007d07b35db519  vmovaps [rsp], xmm0
00007d07b35db51e  vmovaps [rsp+0x10], xmm1
00007d07b35db524  vmovaps [rsp+0x20], xmm2
00007d07b35db52a  vmovaps [rsp+0x30], xmm3
00007d07b35db530  vmovaps [rsp+0x40], xmm4
00007d07b35db536  vmovaps [rsp+0x50], xmm5
00007d07b35db53c  vmovaps [rsp+0x60], xmm6
00007d07b35db542  vmovaps [rsp+0x70], xmm7
00007d07b35db548  vmovaps [rsp+0x80], xmm8
00007d07b35db551  vmovaps [rsp+0x90], xmm9
00007d07b35db55a  vmovaps [rsp+0xA0], xmm10
00007d07b35db563  vmovaps [rsp+0xB0], xmm11
00007d07b35db56c  vmovaps [rsp+0xC0], xmm12
00007d07b35db575  vmovaps [rsp+0xD0], xmm14
00007d07b35db57e  vmovaps [rsp+0xE0], xmm15
00007d07b35db587  sub rsp, 0x30
00007d07b35db58b  movaps [rsp], xmm13
00007d07b35db590  movaps [rsp+0x10], xmm10
00007d07b35db596  movaps [rsp+0x20], xmm14
00007d07b35db59c  lea rdi, [rsp]
00007d07b35db5a0  mov esi, 0x00
00007d07b35db5a5  mov rax, 0x5D0AA712D530
00007d07b35db5af  call rax
00007d07b35db5b1  movaps xmm13, [rsp]
00007d07b35db5b6  add rsp, 0x30
00007d07b35db5ba  vmovaps xmm0, [rsp]
00007d07b35db5bf  vmovaps xmm1, [rsp+0x10]
00007d07b35db5c5  vmovaps xmm2, [rsp+0x20]
00007d07b35db5cb  vmovaps xmm3, [rsp+0x30]
00007d07b35db5d1  vmovaps xmm4, [rsp+0x40]
00007d07b35db5d7  vmovaps xmm5, [rsp+0x50]
00007d07b35db5dd  vmovaps xmm6, [rsp+0x60]
00007d07b35db5e3  vmovaps xmm7, [rsp+0x70]
00007d07b35db5e9  vmovaps xmm8, [rsp+0x80]
00007d07b35db5f2  vmovaps xmm9, [rsp+0x90]
00007d07b35db5fb  vmovaps xmm10, [rsp+0xA0]
00007d07b35db604  vmovaps xmm11, [rsp+0xB0]
00007d07b35db60d  vmovaps xmm12, [rsp+0xC0]
00007d07b35db616  vmovaps xmm14, [rsp+0xD0]
00007d07b35db61f  vmovaps xmm15, [rsp+0xE0]
00007d07b35db628  add rsp, 0xF0
00007d07b35db62f  pop r11
00007d07b35db631  pop r10
00007d07b35db633  pop r9
00007d07b35db635  pop r8
00007d07b35db637  pop rsi
00007d07b35db638  pop rdi
00007d07b35db639  pop rdx
00007d07b35db63a  pop rcx
00007d07b35db63b  pop rax
00007d07b35db63c  add rsp, 0x08
00007d07b35db640  jmp 0x00007D07B35D666D
00007d07b35db645  sub rsp, 0x08
00007d07b35db649  push rax
00007d07b35db64a  push rcx
00007d07b35db64b  push rdx
00007d07b35db64c  push rdi
00007d07b35db64d  push rsi
00007d07b35db64e  push r8
00007d07b35db650  push r9
00007d07b35db652  push r10
00007d07b35db654  push r11
00007d07b35db656  sub rsp, 0xF0
00007d07b35db65d  vmovaps [rsp], xmm0
00007d07b35db662  vmovaps [rsp+0x10], xmm1
00007d07b35db668  vmovaps [rsp+0x20], xmm2
00007d07b35db66e  vmovaps [rsp+0x30], xmm3
00007d07b35db674  vmovaps [rsp+0x40], xmm4
00007d07b35db67a  vmovaps [rsp+0x50], xmm5
00007d07b35db680  vmovaps [rsp+0x60], xmm6
00007d07b35db686  vmovaps [rsp+0x70], xmm7
00007d07b35db68c  vmovaps [rsp+0x80], xmm8
00007d07b35db695  vmovaps [rsp+0x90], xmm9
00007d07b35db69e  vmovaps [rsp+0xA0], xmm10
00007d07b35db6a7  vmovaps [rsp+0xB0], xmm11
00007d07b35db6b0  vmovaps [rsp+0xC0], xmm12
00007d07b35db6b9  vmovaps [rsp+0xD0], xmm13
00007d07b35db6c2  vmovaps [rsp+0xE0], xmm15
00007d07b35db6cb  sub rsp, 0x30
00007d07b35db6cf  movaps [rsp], xmm14
00007d07b35db6d4  movaps [rsp+0x10], xmm1
00007d07b35db6d9  movaps [rsp+0x20], xmm7
00007d07b35db6de  lea rdi, [rsp]
00007d07b35db6e2  mov esi, 0x00
00007d07b35db6e7  mov rax, 0x5D0AA712D530
00007d07b35db6f1  call rax
00007d07b35db6f3  movaps xmm14, [rsp]
00007d07b35db6f8  add rsp, 0x30
00007d07b35db6fc  vmovaps xmm0, [rsp]
00007d07b35db701  vmovaps xmm1, [rsp+0x10]
00007d07b35db707  vmovaps xmm2, [rsp+0x20]
00007d07b35db70d  vmovaps xmm3, [rsp+0x30]
00007d07b35db713  vmovaps xmm4, [rsp+0x40]
00007d07b35db719  vmovaps xmm5, [rsp+0x50]
00007d07b35db71f  vmovaps xmm6, [rsp+0x60]
00007d07b35db725  vmovaps xmm7, [rsp+0x70]
00007d07b35db72b  vmovaps xmm8, [rsp+0x80]
00007d07b35db734  vmovaps xmm9, [rsp+0x90]
00007d07b35db73d  vmovaps xmm10, [rsp+0xA0]
00007d07b35db746  vmovaps xmm11, [rsp+0xB0]
00007d07b35db74f  vmovaps xmm12, [rsp+0xC0]
00007d07b35db758  vmovaps xmm13, [rsp+0xD0]
00007d07b35db761  vmovaps xmm15, [rsp+0xE0]
00007d07b35db76a  add rsp, 0xF0
00007d07b35db771  pop r11
00007d07b35db773  pop r10
00007d07b35db775  pop r9
00007d07b35db777  pop r8
00007d07b35db779  pop rsi
00007d07b35db77a  pop rdi
00007d07b35db77b  pop rdx
00007d07b35db77c  pop rcx
00007d07b35db77d  pop rax
00007d07b35db77e  add rsp, 0x08
00007d07b35db782  jmp 0x00007D07B35D6690
00007d07b35db787  sub rsp, 0x08
00007d07b35db78b  push rax
00007d07b35db78c  push rcx
00007d07b35db78d  push rdx
00007d07b35db78e  push rdi
00007d07b35db78f  push rsi
00007d07b35db790  push r8
00007d07b35db792  push r9
00007d07b35db794  push r10
00007d07b35db796  push r11
00007d07b35db798  sub rsp, 0xF0
00007d07b35db79f  vmovaps [rsp], xmm0
00007d07b35db7a4  vmovaps [rsp+0x10], xmm2
00007d07b35db7aa  vmovaps [rsp+0x20], xmm3
00007d07b35db7b0  vmovaps [rsp+0x30], xmm4
00007d07b35db7b6  vmovaps [rsp+0x40], xmm5
00007d07b35db7bc  vmovaps [rsp+0x50], xmm6
00007d07b35db7c2  vmovaps [rsp+0x60], xmm7
00007d07b35db7c8  vmovaps [rsp+0x70], xmm8
00007d07b35db7ce  vmovaps [rsp+0x80], xmm9
00007d07b35db7d7  vmovaps [rsp+0x90], xmm10
00007d07b35db7e0  vmovaps [rsp+0xA0], xmm11
00007d07b35db7e9  vmovaps [rsp+0xB0], xmm12
00007d07b35db7f2  vmovaps [rsp+0xC0], xmm13
00007d07b35db7fb  vmovaps [rsp+0xD0], xmm14
00007d07b35db804  vmovaps [rsp+0xE0], xmm15
00007d07b35db80d  sub rsp, 0x30
00007d07b35db811  movaps [rsp], xmm1
00007d07b35db815  movaps [rsp+0x10], xmm8
00007d07b35db81b  movaps [rsp+0x20], xmm9
00007d07b35db821  lea rdi, [rsp]
00007d07b35db825  mov esi, 0x00
00007d07b35db82a  mov rax, 0x5D0AA712D530
00007d07b35db834  call rax
00007d07b35db836  movaps xmm1, [rsp]
00007d07b35db83a  add rsp, 0x30
00007d07b35db83e  vmovaps xmm0, [rsp]
00007d07b35db843  vmovaps xmm2, [rsp+0x10]
00007d07b35db849  vmovaps xmm3, [rsp+0x20]
00007d07b35db84f  vmovaps xmm4, [rsp+0x30]
00007d07b35db855  vmovaps xmm5, [rsp+0x40]
00007d07b35db85b  vmovaps xmm6, [rsp+0x50]
00007d07b35db861  vmovaps xmm7, [rsp+0x60]
00007d07b35db867  vmovaps xmm8, [rsp+0x70]
00007d07b35db86d  vmovaps xmm9, [rsp+0x80]
00007d07b35db876  vmovaps xmm10, [rsp+0x90]
00007d07b35db87f  vmovaps xmm11, [rsp+0xA0]
00007d07b35db888  vmovaps xmm12, [rsp+0xB0]
00007d07b35db891  vmovaps xmm13, [rsp+0xC0]
00007d07b35db89a  vmovaps xmm14, [rsp+0xD0]
00007d07b35db8a3  vmovaps xmm15, [rsp+0xE0]
00007d07b35db8ac  add rsp, 0xF0
00007d07b35db8b3  pop r11
00007d07b35db8b5  pop r10
00007d07b35db8b7  pop r9
00007d07b35db8b9  pop r8
00007d07b35db8bb  pop rsi
00007d07b35db8bc  pop rdi
00007d07b35db8bd  pop rdx
00007d07b35db8be  pop rcx
00007d07b35db8bf  pop rax
00007d07b35db8c0  add rsp, 0x08
00007d07b35db8c4  jmp 0x00007D07B35D66B2
00007d07b35db8c9  call 0x00007D07B34B3E40
00007d07b35db8ce  jmp 0x00007D07B35D66C0
00007d07b35db8d3  call 0x00007D07B340C380
00007d07b35db8d8  jmp 0x00007D07B35D66CA
00007d07b35db8dd  call 0x00007D07B340D600
00007d07b35db8e2  jmp 0x00007D07B35D66D4
00007d07b35db8e7  call 0x00007D07B33FF540
00007d07b35db8ec  jmp 0x00007D07B35D66DE
00007d07b35db8f1  int3
00007d07b35db8f2  nop [rax+rax*1], ax
00007d07b35db8fb  nop [rax+rax*1], eax
00007d07b35db900  mov eax, [r15+0x48]
00007d07b35db904  lea r14d, [eax+0x01]
00007d07b35db909  mov [rsp+0x10], r14d
00007d07b35db90e  mov r14d, r14d
00007d07b35db911  mov [r15+0x48], r14
00007d07b35db915  xor eax, eax
00007d07b35db917  mov r14d, [rsp+0x10]
00007d07b35db91c  cmp r14d, 0x1F4
00007d07b35db923  cmc
00007d07b35db924  lahf
00007d07b35db925  seto al
00007d07b35db928  mov [r15+0x108], eax
00007d07b35db92f  mov eax, [r15+0x108]
00007d07b35db936  sahf
00007d07b35db937  jnz 0x00007D07B35DB969
00007d07b35db939  cmp dword ptr [r15+0x318], 0x00
00007d07b35db941  jz 0x00007D07B35E1AB0
00007d07b35db947  nop [rax+rax*1], ax
00007d07b35db950  nop [rax+rax*1], eax
00007d07b35db958  mov eax, 0x410450
00007d07b35db95d  mov [r15+0x100], rax
00007d07b35db964  jmp 0x00007D07B33FE110
00007d07b35db969  cmp dword ptr [r15+0x318], 0x00
00007d07b35db971  jz 0x00007D07B35DB9A0
00007d07b35db977  nop [rax+rax*1], ax
00007d07b35db980  nop [rax+rax*1], eax
00007d07b35db988  mov eax, 0x410274
00007d07b35db98d  mov [r15+0x100], rax
00007d07b35db994  jmp 0x00007D07B33FE110
00007d07b35db999  int3
00007d07b35db99a  int3
00007d07b35db99b  nop [rax+rax*1], eax
00007d07b35db9a0  mov rax, [r15+0x40]
00007d07b35db9a4  movaps xmm1, [r15+0x1D0]
00007d07b35db9ac  vmovaps [rsp+0x10], xmm1
00007d07b35db9b2  vmovaps xmm15, [rsp+0x10]
00007d07b35db9b8  por xmm1, xmm15
00007d07b35db9bd  movaps xmm14, [r15+0x1A0]
00007d07b35db9c5  vmovaps [rsp+0x10], xmm14
00007d07b35db9cb  vmovaps xmm13, [rsp+0x10]
00007d07b35db9d1  por xmm14, xmm13
00007d07b35db9d6  lea r14, [rax+0x30]
00007d07b35db9da  mov r12, [r13+r14*1]
00007d07b35db9df  lea r14, [rax+0x38]
00007d07b35db9e3  mov r11, [r13+r14*1]
00007d07b35db9e8  movq xmm13, r12
00007d07b35db9ed  movq xmm12, r11
00007d07b35db9f2  movq xmm13, xmm13
00007d07b35db9f7  vmovaps [rsp+0x10], xmm13
00007d07b35db9fd  movq xmm13, xmm13
00007d07b35dba02  movaps [r15+0x130], xmm13
00007d07b35dba0a  movq xmm12, xmm12
00007d07b35dba0f  vmovaps [rsp+0x20], xmm12
00007d07b35dba15  movq xmm12, xmm12
00007d07b35dba1a  movaps [r15+0x280], xmm12
00007d07b35dba22  movaps xmm13, [r15+0x270]
00007d07b35dba2a  vmovaps [rsp+0x30], xmm13
00007d07b35dba30  vmovaps xmm12, [rsp+0x30]
00007d07b35dba36  por xmm13, xmm12
00007d07b35dba3b  lea r14, [rax+0x20]
00007d07b35dba3f  mov r12, [r13+r14*1]
00007d07b35dba44  lea r14, [rax+0x28]
00007d07b35dba48  mov r11, [r13+r14*1]
00007d07b35dba4d  movq xmm12, r12
00007d07b35dba52  movq xmm11, r11
00007d07b35dba57  movq xmm12, xmm12
00007d07b35dba5c  vmovaps [rsp+0x30], xmm12
00007d07b35dba62  movq xmm12, xmm12
00007d07b35dba67  movaps [r15+0x150], xmm12
00007d07b35dba6f  movq xmm11, xmm11
00007d07b35dba74  vmovaps [rsp+0x40], xmm11
00007d07b35dba7a  movq xmm11, xmm11
00007d07b35dba7f  movaps [r15+0x140], xmm11
00007d07b35dba87  lea r14, [rax+0x10]
00007d07b35dba8b  mov r12, [r13+r14*1]
00007d07b35dba90  lea r14, [rax+0x18]
00007d07b35dba94  mov r11, [r13+r14*1]
00007d07b35dba99  movq xmm12, r12
00007d07b35dba9e  movq xmm11, r11
00007d07b35dbaa3  movq xmm12, xmm12
00007d07b35dbaa8  vmovaps [rsp+0x50], xmm12
00007d07b35dbaae  movq xmm12, xmm12
00007d07b35dbab3  movaps [r15+0x170], xmm12
00007d07b35dbabb  movq xmm11, xmm11
00007d07b35dbac0  vmovaps [rsp+0x60], xmm11
00007d07b35dbac6  movq xmm11, xmm11
00007d07b35dbacb  movaps [r15+0x160], xmm11
00007d07b35dbad3  mov r14, [r13+rax*1]
00007d07b35dbad8  vmovq xmm12, r14
00007d07b35dbadd  vpbroadcastq xmm12, xmm12
00007d07b35dbae2  lea r14, [rax+0x08]
00007d07b35dbae6  mov rax, [r13+r14*1]
00007d07b35dbaeb  movq xmm11, rax
00007d07b35dbaf0  movaps [r15+0x230], xmm11
00007d07b35dbaf8  mov rax, [r15+0xF8]
00007d07b35dbaff  lea r14, [rax+0x50]
00007d07b35dbb03  movups xmm11, [r13+r14*1]
00007d07b35dbb09  lea r14, [rax+0x60]
00007d07b35dbb0d  movups xmm10, [r13+r14*1]
00007d07b35dbb13  lea r14, [rax+0x30]
00007d07b35dbb17  movups xmm9, [r13+r14*1]
00007d07b35dbb1d  mov r14, [r15+0x50]
00007d07b35dbb21  mov [r15+0x60], r14
00007d07b35dbb25  mov qword ptr [r15+0x58], 0x40
00007d07b35dbb2d  movaps xmm8, xmm12
00007d07b35dbb31  mulpd xmm8, xmm15
00007d07b35dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007d07b35dbb3c  ptest xmm7, xmm7
00007d07b35dbb41  jnz 0x00007D07B35DC96A
00007d07b35dbb47  movq xmm15, qword ptr [r15+0x230]
00007d07b35dbb50  vmovaps [rsp+0x70], xmm15
00007d07b35dbb56  vpermilpd xmm15, xmm15, 0x00
00007d07b35dbb5c  movaps xmm7, xmm9
00007d07b35dbb60  mulpd xmm7, xmm15
00007d07b35dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007d07b35dbb6a  ptest xmm6, xmm6
00007d07b35dbb6f  jnz 0x00007D07B35DCAAE
00007d07b35dbb75  vxorps xmm15, xmm15, xmm15
00007d07b35dbb7a  vpbroadcastq xmm15, xmm15
00007d07b35dbb7f  movaps xmm9, xmm12
00007d07b35dbb83  mulpd xmm9, xmm10
00007d07b35dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007d07b35dbb8e  ptest xmm6, xmm6
00007d07b35dbb93  jnz 0x00007D07B35DCBF0
00007d07b35dbb99  movaps xmm10, xmm12
00007d07b35dbb9d  mulpd xmm10, xmm11
00007d07b35dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007d07b35dbba8  ptest xmm6, xmm6
00007d07b35dbbad  jnz 0x00007D07B35DCD34
00007d07b35dbbb3  movaps xmm11, [r15+0x1F0]
00007d07b35dbbbb  movaps xmm6, xmm12
00007d07b35dbbbf  mulpd xmm6, xmm11
00007d07b35dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007d07b35dbbc9  ptest xmm5, xmm5
00007d07b35dbbce  jnz 0x00007D07B35DCE78
00007d07b35dbbd4  movaps xmm12, [r15+0x2A0]
00007d07b35dbbdc  vmovaps [rsp+0x80], xmm12
00007d07b35dbbe5  vmovaps xmm11, [rsp+0x80]
00007d07b35dbbee  por xmm12, xmm11
00007d07b35dbbf3  movaps xmm11, [r15+0x250]
00007d07b35dbbfb  vmovaps [rsp+0x80], xmm11
00007d07b35dbc04  vmovaps xmm5, [rsp+0x80]
00007d07b35dbc0d  por xmm11, xmm5
00007d07b35dbc12  vmovaps xmm4, [rsp+0x70]
00007d07b35dbc18  vpermilpd xmm4, xmm4, 0x00
00007d07b35dbc1e  movaps xmm3, xmm5
00007d07b35dbc21  mulpd xmm3, xmm4
00007d07b35dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007d07b35dbc2a  ptest xmm2, xmm2
00007d07b35dbc2f  jnz 0x00007D07B35DCFBA
00007d07b35dbc35  mov [rsp+0x80], rax
00007d07b35dbc3d  xor eax, eax
00007d07b35dbc3f  mov r12d, 0x40
00007d07b35dbc45  mov r11d, 0x200
00007d07b35dbc4b  cmp r12, r11
00007d07b35dbc4e  cmc
00007d07b35dbc4f  lahf
00007d07b35dbc50  seto al
00007d07b35dbc53  mov [r15+0x108], eax
00007d07b35dbc5a  movaps xmm5, xmm8
00007d07b35dbc5e  addpd xmm5, xmm15
00007d07b35dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007d07b35dbc68  ptest xmm4, xmm4
00007d07b35dbc6d  jnz 0x00007D07B35DD0FA
00007d07b35dbc73  movaps xmm8, [r15+0x1B0]
00007d07b35dbc7b  movaps xmm4, xmm9
00007d07b35dbc7f  addpd xmm4, xmm8
00007d07b35dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007d07b35dbc89  ptest xmm2, xmm2
00007d07b35dbc8e  jnz 0x00007D07B35DD23C
00007d07b35dbc94  movaps xmm9, xmm10
00007d07b35dbc98  addpd xmm9, xmm8
00007d07b35dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007d07b35dbca3  ptest xmm2, xmm2
00007d07b35dbca8  jnz 0x00007D07B35DD37E
00007d07b35dbcae  movaps xmm10, [r15+0x2F0]
00007d07b35dbcb6  vmovaps [rsp+0x90], xmm10
00007d07b35dbcbf  vmovaps xmm8, [rsp+0x90]
00007d07b35dbcc8  por xmm10, xmm8
00007d07b35dbccd  movaps xmm8, [r15+0x2E0]
00007d07b35dbcd5  vmovaps [rsp+0x90], xmm8
00007d07b35dbcde  vmovaps xmm2, [rsp+0x90]
00007d07b35dbce7  por xmm8, xmm2
00007d07b35dbcec  movaps xmm2, [r15+0x2D0]
00007d07b35dbcf4  vmovaps [rsp+0x90], xmm2
00007d07b35dbcfd  vmovaps [rsp+0xA0], xmm1
00007d07b35dbd06  vmovaps xmm1, [rsp+0x90]
00007d07b35dbd0f  por xmm2, xmm1
00007d07b35dbd13  movaps xmm1, [r15+0x200]
00007d07b35dbd1b  vmovaps [rsp+0x90], xmm1
00007d07b35dbd24  vmovaps [rsp+0xB0], xmm15
00007d07b35dbd2d  vmovaps xmm15, [rsp+0x90]
00007d07b35dbd36  por xmm1, xmm15
00007d07b35dbd3b  movaps xmm15, [r15+0x1C0]
00007d07b35dbd43  vmovaps [rsp+0x90], xmm15
00007d07b35dbd4c  vmovaps [rsp+0xC0], xmm1
00007d07b35dbd55  vmovaps xmm1, [rsp+0x90]
00007d07b35dbd5e  por xmm15, xmm1
00007d07b35dbd63  movaps xmm1, [r15+0x190]
00007d07b35dbd6b  vmovaps [rsp+0x90], xmm1
00007d07b35dbd74  vmovaps [rsp+0xD0], xmm15
00007d07b35dbd7d  vmovaps xmm15, [rsp+0x90]
00007d07b35dbd86  por xmm1, xmm15
00007d07b35dbd8b  movaps xmm15, [r15+0x300]
00007d07b35dbd93  vmovaps [rsp+0x90], xmm15
00007d07b35dbd9c  vmovaps [rsp+0xE0], xmm1
00007d07b35dbda5  vmovaps xmm1, [rsp+0x90]
00007d07b35dbdae  por xmm15, xmm1
00007d07b35dbdb3  mov rax, [rsp+0x80]
00007d07b35dbdbb  lea r12, [rax+0xA0]
00007d07b35dbdc2  movups xmm1, [r13+r12*1]
00007d07b35dbdc8  lea r12, [rax+0xB0]
00007d07b35dbdcf  vmovaps [rsp+0x80], xmm1
00007d07b35dbdd8  movups xmm1, [r13+r12*1]
00007d07b35dbdde  vmovaps [rsp+0x90], xmm1
00007d07b35dbde7  vmovaps [rsp+0xF0], xmm15
00007d07b35dbdf0  vmovaps xmm15, [rsp+0xB0]
00007d07b35dbdf9  vmovaps [rsp+0xB0], xmm14
00007d07b35dbe02  movaps xmm1, xmm6
00007d07b35dbe05  addpd xmm1, xmm15
00007d07b35dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007d07b35dbe0f  ptest xmm14, xmm14
00007d07b35dbe15  jnz 0x00007D07B35DD4D6
00007d07b35dbe1b  lea r12, [rax+0xF0]
00007d07b35dbe22  movups xmm15, [r13+r12*1]
00007d07b35dbe28  movaps xmm14, xmm4
00007d07b35dbe2c  addpd xmm14, xmm3
00007d07b35dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007d07b35dbe37  ptest xmm6, xmm6
00007d07b35dbe3c  jnz 0x00007D07B35DD621
00007d07b35dbe42  movaps xmm6, xmm9
00007d07b35dbe46  addpd xmm6, xmm7
00007d07b35dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007d07b35dbe4f  ptest xmm4, xmm4
00007d07b35dbe54  jnz 0x00007D07B35DD763
00007d07b35dbe5a  vmovaps xmm9, [rsp+0x70]
00007d07b35dbe60  vpermilpd xmm9, xmm9, 0x00
00007d07b35dbe66  vmovaps xmm4, [rsp+0x90]
00007d07b35dbe6f  movaps xmm7, xmm4
00007d07b35dbe72  mulpd xmm7, xmm9
00007d07b35dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007d07b35dbe7c  ptest xmm3, xmm3
00007d07b35dbe81  jnz 0x00007D07B35DD8A4
00007d07b35dbe87  vmovaps xmm9, [rsp+0x50]
00007d07b35dbe8d  vpermilpd xmm9, xmm9, 0x00
00007d07b35dbe93  movaps xmm4, xmm15
00007d07b35dbe97  mulpd xmm4, xmm9
00007d07b35dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007d07b35dbea1  ptest xmm3, xmm3
00007d07b35dbea6  jnz 0x00007D07B35DD9E5
00007d07b35dbeac  lea r12, [rax+0xE0]
00007d07b35dbeb3  movups xmm15, [r13+r12*1]
00007d07b35dbeb9  vmovaps xmm9, [rsp+0x70]
00007d07b35dbebf  vpermilpd xmm9, xmm9, 0x00
00007d07b35dbec5  vmovaps [rsp+0x70], xmm1
00007d07b35dbecb  vmovaps xmm1, [rsp+0x80]
00007d07b35dbed4  vmovaps [rsp+0x80], xmm15
00007d07b35dbedd  movaps xmm3, xmm1
00007d07b35dbee0  mulpd xmm3, xmm9
00007d07b35dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007d07b35dbeea  ptest xmm15, xmm15
00007d07b35dbef0  jnz 0x00007D07B35DDB31
00007d07b35dbef6  vmovaps xmm1, [rsp+0xF0]
00007d07b35dbeff  vmovaps xmm15, [rsp+0xF0]
00007d07b35dbf08  por xmm1, xmm15
00007d07b35dbf0d  movaps [r15+0x300], xmm1
00007d07b35dbf15  vmovaps xmm15, [rsp+0xE0]
00007d07b35dbf1e  vmovaps xmm9, [rsp+0xE0]
00007d07b35dbf27  por xmm15, xmm9
00007d07b35dbf2c  movaps [r15+0x190], xmm15
00007d07b35dbf34  vmovaps xmm9, [rsp+0x50]
00007d07b35dbf3a  vpermilpd xmm9, xmm9, 0x00
00007d07b35dbf40  vmovaps [rsp+0x90], xmm1
00007d07b35dbf49  vmovaps [rsp+0xE0], xmm15
00007d07b35dbf52  vmovaps xmm15, [rsp+0x80]
00007d07b35dbf5b  vmovaps [rsp+0x80], xmm14
00007d07b35dbf64  movaps xmm1, xmm15
00007d07b35dbf68  mulpd xmm1, xmm9
00007d07b35dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007d07b35dbf72  ptest xmm14, xmm14
00007d07b35dbf78  jnz 0x00007D07B35DDC72
00007d07b35dbf7e  lea r12, [rax+0x90]
00007d07b35dbf85  movups xmm15, [r13+r12*1]
00007d07b35dbf8b  vmovaps xmm14, [rsp+0xD0]
00007d07b35dbf94  vmovaps xmm9, [rsp+0xD0]
00007d07b35dbf9d  por xmm14, xmm9
00007d07b35dbfa2  movaps [r15+0x1C0], xmm14
00007d07b35dbfaa  vmovaps xmm9, [rsp+0xC0]
00007d07b35dbfb3  vmovaps [rsp+0xD0], xmm1
00007d07b35dbfbc  vmovaps xmm1, [rsp+0xC0]
00007d07b35dbfc5  por xmm9, xmm1
00007d07b35dbfca  movaps [r15+0x200], xmm9
00007d07b35dbfd2  vmovaps [rsp+0xC0], xmm2
00007d07b35dbfdb  vmovaps xmm1, [rsp+0xC0]
00007d07b35dbfe4  por xmm2, xmm1
00007d07b35dbfe8  movaps [r15+0x2D0], xmm2
00007d07b35dbff0  vmovaps [rsp+0xC0], xmm8
00007d07b35dbff9  vmovaps xmm1, [rsp+0xC0]
00007d07b35dc002  por xmm8, xmm1
00007d07b35dc007  movaps [r15+0x2E0], xmm8
00007d07b35dc00f  vmovaps [rsp+0xC0], xmm15
00007d07b35dc018  movaps xmm1, xmm5
00007d07b35dc01b  addpd xmm1, xmm7
00007d07b35dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007d07b35dc024  ptest xmm15, xmm15
00007d07b35dc02a  jnz 0x00007D07B35DDDBE
00007d07b35dc030  vmovaps xmm15, [rsp+0x50]
00007d07b35dc036  vpermilpd xmm15, xmm15, 0x00
00007d07b35dc03c  vmovaps xmm5, [rsp+0xC0]
00007d07b35dc045  vmovaps [rsp+0xC0], xmm1
00007d07b35dc04e  movaps xmm7, xmm5
00007d07b35dc051  mulpd xmm7, xmm15
00007d07b35dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007d07b35dc05b  ptest xmm1, xmm1
00007d07b35dc060  jnz 0x00007D07B35DDEFE
00007d07b35dc066  lea r12, [rax+0x80]
00007d07b35dc06d  movups xmm1, [r13+r12*1]
00007d07b35dc073  vmovaps xmm5, [rsp+0x70]
00007d07b35dc079  vmovaps [rsp+0x70], xmm1
00007d07b35dc07f  movaps xmm15, xmm5
00007d07b35dc083  addpd xmm15, xmm3
00007d07b35dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007d07b35dc08e  ptest xmm1, xmm1
00007d07b35dc093  jnz 0x00007D07B35DE049
00007d07b35dc099  vmovaps xmm5, [rsp+0x80]
00007d07b35dc0a2  movaps xmm1, xmm5
00007d07b35dc0a5  addpd xmm1, xmm4
00007d07b35dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007d07b35dc0ae  ptest xmm3, xmm3
00007d07b35dc0b3  jnz 0x00007D07B35DE18B
00007d07b35dc0b9  vmovaps [rsp+0x80], xmm10
00007d07b35dc0c2  vmovaps xmm5, [rsp+0x80]
00007d07b35dc0cb  por xmm10, xmm5
00007d07b35dc0d0  movaps [r15+0x2F0], xmm10
00007d07b35dc0d8  vmovaps xmm5, [rsp+0x50]
00007d07b35dc0de  vpermilpd xmm5, xmm5, 0x00
00007d07b35dc0e4  vmovaps xmm3, [rsp+0x70]
00007d07b35dc0ea  vmovaps [rsp+0x50], xmm1
00007d07b35dc0f0  movaps xmm4, xmm3
00007d07b35dc0f3  mulpd xmm4, xmm5
00007d07b35dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007d07b35dc0fc  ptest xmm1, xmm1
00007d07b35dc101  jnz 0x00007D07B35DE2CB
00007d07b35dc107  lea r12, [rax+0xD0]
00007d07b35dc10e  movups xmm1, [r13+r12*1]
00007d07b35dc114  vmovaps xmm3, [rsp+0xD0]
00007d07b35dc11d  vmovaps [rsp+0x70], xmm1
00007d07b35dc123  movaps xmm5, xmm6
00007d07b35dc126  addpd xmm5, xmm3
00007d07b35dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007d07b35dc12f  ptest xmm1, xmm1
00007d07b35dc134  jnz 0x00007D07B35DE415
00007d07b35dc13a  vmovaps xmm1, [rsp+0x60]
00007d07b35dc140  vpermilpd xmm1, xmm1, 0x00
00007d07b35dc146  movaps xmm6, xmm9
00007d07b35dc14a  mulpd xmm6, xmm1
00007d07b35dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007d07b35dc153  ptest xmm3, xmm3
00007d07b35dc158  jnz 0x00007D07B35DE555
00007d07b35dc15e  movaps [r15+0x260], xmm6
00007d07b35dc166  vxorps xmm1, xmm1, xmm1
00007d07b35dc16a  vpbroadcastq xmm1, xmm1
00007d07b35dc16f  movaps [r15+0x1B0], xmm1
00007d07b35dc177  vmovaps xmm1, [rsp+0x60]
00007d07b35dc17d  vpermilpd xmm1, xmm1, 0x00
00007d07b35dc183  vmovaps xmm3, [rsp+0x70]
00007d07b35dc189  vmovaps [rsp+0x70], xmm15
00007d07b35dc18f  movaps xmm9, xmm3
00007d07b35dc193  mulpd xmm9, xmm1
00007d07b35dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007d07b35dc19e  ptest xmm15, xmm15
00007d07b35dc1a4  jnz 0x00007D07B35DE696
00007d07b35dc1aa  lea r12, [rax+0xC0]
00007d07b35dc1b1  movups xmm1, [r13+r12*1]
00007d07b35dc1b7  vmovaps xmm3, [rsp+0xC0]
00007d07b35dc1c0  vmovaps [rsp+0x80], xmm1
00007d07b35dc1c9  movaps xmm15, xmm3
00007d07b35dc1cd  addpd xmm15, xmm7
00007d07b35dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007d07b35dc1d8  ptest xmm1, xmm1
00007d07b35dc1dd  jnz 0x00007D07B35DE7E2
00007d07b35dc1e3  vmovaps [rsp+0xC0], xmm13
00007d07b35dc1ec  vmovaps xmm1, [rsp+0xC0]
00007d07b35dc1f5  por xmm13, xmm1
00007d07b35dc1fa  movaps [r15+0x270], xmm13
00007d07b35dc202  vmovaps xmm1, [rsp+0xB0]
00007d07b35dc20b  vmovaps xmm7, [rsp+0xB0]
00007d07b35dc214  por xmm1, xmm7
00007d07b35dc218  movaps [r15+0x1A0], xmm1
00007d07b35dc220  vmovaps xmm1, [rsp+0x60]
00007d07b35dc226  vpermilpd xmm1, xmm1, 0x00
00007d07b35dc22c  vmovaps [rsp+0xB0], xmm1
00007d07b35dc235  vmovaps xmm1, [rsp+0x80]
00007d07b35dc23e  vmovaps [rsp+0x80], xmm15
00007d07b35dc247  vmovaps xmm15, [rsp+0xB0]
00007d07b35dc250  vmovaps [rsp+0xB0], xmm14
00007d07b35dc259  movaps xmm3, xmm1
00007d07b35dc25c  mulpd xmm3, xmm15
00007d07b35dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007d07b35dc266  ptest xmm14, xmm14
00007d07b35dc26c  jnz 0x00007D07B35DE924
00007d07b35dc272  lea r12, [rax+0x20]
00007d07b35dc276  movups xmm1, [r13+r12*1]
00007d07b35dc27c  movaps [r15+0x110], xmm1
00007d07b35dc284  vmovaps xmm14, [rsp+0x70]
00007d07b35dc28a  vmovaps [rsp+0x70], xmm1
00007d07b35dc290  movaps xmm15, xmm14
00007d07b35dc294  addpd xmm15, xmm4
00007d07b35dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007d07b35dc29f  ptest xmm1, xmm1
00007d07b35dc2a4  jnz 0x00007D07B35DEA6F
00007d07b35dc2aa  vmovaps xmm1, [rsp+0x60]
00007d07b35dc2b0  vpermilpd xmm1, xmm1, 0x00
00007d07b35dc2b6  movaps xmm14, xmm2
00007d07b35dc2ba  mulpd xmm14, xmm1
00007d07b35dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007d07b35dc2c5  ptest xmm4, xmm4
00007d07b35dc2ca  jnz 0x00007D07B35DEBB2
00007d07b35dc2d0  vmovaps xmm4, [rsp+0x50]
00007d07b35dc2d6  movaps xmm1, xmm4
00007d07b35dc2d9  addpd xmm1, xmm9
00007d07b35dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007d07b35dc2e3  ptest xmm2, xmm2
00007d07b35dc2e8  jnz 0x00007D07B35DECF4
00007d07b35dc2ee  vmovaps xmm9, [rsp+0x30]
00007d07b35dc2f4  vpermilpd xmm9, xmm9, 0x00
00007d07b35dc2fa  vmovaps xmm2, [rsp+0x70]
00007d07b35dc300  vmovaps [rsp+0x50], xmm1
00007d07b35dc306  movaps xmm4, xmm2
00007d07b35dc309  mulpd xmm4, xmm9
00007d07b35dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007d07b35dc313  ptest xmm1, xmm1
00007d07b35dc318  jnz 0x00007D07B35DEE35
00007d07b35dc31e  vmovaps xmm1, [rsp+0x30]
00007d07b35dc324  vpermilpd xmm1, xmm1, 0x00
00007d07b35dc32a  vmovaps xmm2, [rsp+0x90]
00007d07b35dc333  vmovaps [rsp+0x60], xmm15
00007d07b35dc339  movaps xmm9, xmm2
00007d07b35dc33d  mulpd xmm9, xmm1
00007d07b35dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007d07b35dc348  ptest xmm15, xmm15
00007d07b35dc34e  jnz 0x00007D07B35DEF76
00007d07b35dc354  vmovaps xmm15, [rsp+0x80]
00007d07b35dc35d  movaps xmm1, xmm15
00007d07b35dc361  addpd xmm1, xmm6
00007d07b35dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007d07b35dc36a  ptest xmm2, xmm2
00007d07b35dc36f  jnz 0x00007D07B35DF0B8
00007d07b35dc375  movaps xmm15, xmm5
00007d07b35dc379  addpd xmm15, xmm3
00007d07b35dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007d07b35dc384  ptest xmm6, xmm6
00007d07b35dc389  jnz 0x00007D07B35DF1F9
00007d07b35dc38f  vmovaps xmm6, [rsp+0x30]
00007d07b35dc395  vpermilpd xmm6, xmm6, 0x00
00007d07b35dc39b  movaps xmm5, xmm8
00007d07b35dc39f  mulpd xmm5, xmm6
00007d07b35dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007d07b35dc3a8  ptest xmm3, xmm3
00007d07b35dc3ad  jnz 0x00007D07B35DF33B
00007d07b35dc3b3  vmovaps xmm8, [rsp+0x30]
00007d07b35dc3b9  vpermilpd xmm8, xmm8, 0x00
00007d07b35dc3bf  movaps xmm6, xmm10
00007d07b35dc3c3  mulpd xmm6, xmm8
00007d07b35dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007d07b35dc3cd  ptest xmm3, xmm3
00007d07b35dc3d2  jnz 0x00007D07B35DF47C
00007d07b35dc3d8  vmovaps xmm8, [rsp+0x60]
00007d07b35dc3de  movaps xmm10, xmm8
00007d07b35dc3e2  addpd xmm10, xmm14
00007d07b35dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007d07b35dc3ed  ptest xmm3, xmm3
00007d07b35dc3f2  jnz 0x00007D07B35DF5BE
00007d07b35dc3f8  vmovaps xmm8, [rsp+0x50]
00007d07b35dc3fe  movaps xmm14, xmm8
00007d07b35dc402  addpd xmm14, xmm4
00007d07b35dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007d07b35dc40d  ptest xmm3, xmm3
00007d07b35dc412  jnz 0x00007D07B35DF702
00007d07b35dc418  vmovaps xmm8, [rsp+0x40]
00007d07b35dc41e  vpermilpd xmm8, xmm8, 0x00
00007d07b35dc424  movaps xmm4, xmm13
00007d07b35dc428  mulpd xmm4, xmm8
00007d07b35dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007d07b35dc432  ptest xmm3, xmm3
00007d07b35dc437  jnz 0x00007D07B35DF845
00007d07b35dc43d  movaps xmm13, xmm15
00007d07b35dc441  addpd xmm13, xmm9
00007d07b35dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007d07b35dc44c  ptest xmm8, xmm8
00007d07b35dc452  jnz 0x00007D07B35DF987
00007d07b35dc458  movaps xmm15, xmm1
00007d07b35dc45c  addpd xmm15, xmm5
00007d07b35dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007d07b35dc467  ptest xmm9, xmm9
00007d07b35dc46d  jnz 0x00007D07B35DFACB
00007d07b35dc473  vmovaps [rsp+0x30], xmm11
00007d07b35dc479  vmovaps xmm1, [rsp+0x30]
00007d07b35dc47f  por xmm11, xmm1
00007d07b35dc484  movaps [r15+0x250], xmm11
00007d07b35dc48c  vmovaps [rsp+0x30], xmm12
00007d07b35dc492  vmovaps xmm1, [rsp+0x30]
00007d07b35dc498  por xmm12, xmm1
00007d07b35dc49d  movaps [r15+0x2A0], xmm12
00007d07b35dc4a5  vmovaps xmm1, [rsp+0xA0]
00007d07b35dc4ae  vmovaps xmm11, [rsp+0xA0]
00007d07b35dc4b7  por xmm1, xmm11
00007d07b35dc4bc  movaps [r15+0x1D0], xmm1
00007d07b35dc4c4  lea r12, [rax+0x40]
00007d07b35dc4c8  movups xmm1, [r13+r12*1]
00007d07b35dc4ce  movaps [r15+0x2C0], xmm1
00007d07b35dc4d6  vmovaps xmm11, [rsp+0x40]
00007d07b35dc4dc  vpermilpd xmm11, xmm11, 0x00
00007d07b35dc4e2  vmovaps xmm8, [rsp+0xE0]
00007d07b35dc4eb  movaps xmm9, xmm8
00007d07b35dc4ef  mulpd xmm9, xmm11
00007d07b35dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007d07b35dc4fa  ptest xmm5, xmm5
00007d07b35dc4ff  jnz 0x00007D07B35DFC17
00007d07b35dc505  movaps xmm11, xmm10
00007d07b35dc509  addpd xmm11, xmm6
00007d07b35dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007d07b35dc514  ptest xmm8, xmm8
00007d07b35dc51a  jnz 0x00007D07B35DFD5B
00007d07b35dc520  movaps xmm10, xmm14
00007d07b35dc524  addpd xmm10, xmm4
00007d07b35dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007d07b35dc52f  ptest xmm8, xmm8
00007d07b35dc535  jnz 0x00007D07B35DFE9E
00007d07b35dc53b  vmovaps xmm14, [rsp+0x40]
00007d07b35dc541  vpermilpd xmm14, xmm14, 0x00
00007d07b35dc547  movaps xmm8, xmm1
00007d07b35dc54b  mulpd xmm8, xmm14
00007d07b35dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007d07b35dc556  ptest xmm6, xmm6
00007d07b35dc55b  jnz 0x00007D07B35DFFE1
00007d07b35dc561  movaps xmm1, [r15+0x2B0]
00007d07b35dc569  vmovaps xmm14, [rsp+0x40]
00007d07b35dc56f  vpermilpd xmm14, xmm14, 0x00
00007d07b35dc575  movaps xmm6, xmm1
00007d07b35dc578  mulpd xmm6, xmm14
00007d07b35dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007d07b35dc582  ptest xmm5, xmm5
00007d07b35dc587  jnz 0x00007D07B35E0124
00007d07b35dc58d  vmovaps xmm1, [rsp+0x10]
00007d07b35dc593  vpermilpd xmm1, xmm1, 0x00
00007d07b35dc599  movaps xmm14, xmm12
00007d07b35dc59d  mulpd xmm14, xmm1
00007d07b35dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007d07b35dc5a8  ptest xmm5, xmm5
00007d07b35dc5ad  jnz 0x00007D07B35E0265
00007d07b35dc5b3  movaps xmm1, xmm13
00007d07b35dc5b7  addpd xmm1, xmm9
00007d07b35dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007d07b35dc5c1  ptest xmm12, xmm12
00007d07b35dc5c7  jnz 0x00007D07B35E03A8
00007d07b35dc5cd  vmovaps xmm13, [rsp+0x10]
00007d07b35dc5d3  vpermilpd xmm13, xmm13, 0x00
00007d07b35dc5d9  movaps xmm12, xmm7
00007d07b35dc5dd  mulpd xmm12, xmm13
00007d07b35dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007d07b35dc5e8  ptest xmm9, xmm9
00007d07b35dc5ee  jnz 0x00007D07B35E04EA
00007d07b35dc5f4  movaps xmm13, xmm15
00007d07b35dc5f8  addpd xmm13, xmm8
00007d07b35dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007d07b35dc603  ptest xmm9, xmm9
00007d07b35dc609  jnz 0x00007D07B35E062D
00007d07b35dc60f  movaps xmm15, [r15+0x290]
00007d07b35dc617  vmovaps xmm9, [rsp+0x10]
00007d07b35dc61d  vpermilpd xmm9, xmm9, 0x00
00007d07b35dc623  movaps xmm8, xmm15
00007d07b35dc627  mulpd xmm8, xmm9
00007d07b35dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007d07b35dc632  ptest xmm7, xmm7
00007d07b35dc637  jnz 0x00007D07B35E0771
00007d07b35dc63d  movaps xmm15, xmm11
00007d07b35dc641  addpd xmm15, xmm6
00007d07b35dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007d07b35dc64c  ptest xmm9, xmm9
00007d07b35dc652  jnz 0x00007D07B35E08B5
00007d07b35dc658  movaps xmm11, [r15+0x1E0]
00007d07b35dc660  vmovaps xmm9, [rsp+0x10]
00007d07b35dc666  vpermilpd xmm9, xmm9, 0x00
00007d07b35dc66c  movaps xmm7, xmm11
00007d07b35dc670  mulpd xmm7, xmm9
00007d07b35dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007d07b35dc67a  ptest xmm6, xmm6
00007d07b35dc67f  jnz 0x00007D07B35E09F8
00007d07b35dc685  movaps xmm11, xmm10
00007d07b35dc689  addpd xmm11, xmm14
00007d07b35dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007d07b35dc694  ptest xmm9, xmm9
00007d07b35dc69a  jnz 0x00007D07B35E0B3A
00007d07b35dc6a0  lea r12, [rax+0x70]
00007d07b35dc6a4  movups xmm14, [r13+r12*1]
00007d07b35dc6aa  movaps [r15+0x240], xmm14
00007d07b35dc6b2  movaps xmm10, xmm1
00007d07b35dc6b6  addpd xmm10, xmm12
00007d07b35dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007d07b35dc6c1  ptest xmm9, xmm9
00007d07b35dc6c7  jnz 0x00007D07B35E0C88
00007d07b35dc6cd  movaps [r15+0x170], xmm10
00007d07b35dc6d5  vmovaps xmm1, [rsp+0x20]
00007d07b35dc6db  vpermilpd xmm1, xmm1, 0x00
00007d07b35dc6e1  movaps xmm12, xmm14
00007d07b35dc6e5  mulpd xmm12, xmm1
00007d07b35dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007d07b35dc6f0  ptest xmm9, xmm9
00007d07b35dc6f6  jnz 0x00007D07B35E0DCB
00007d07b35dc6fc  vmovaps xmm1, [rsp+0x20]
00007d07b35dc702  vpermilpd xmm1, xmm1, 0x00
00007d07b35dc708  vmovaps xmm9, [rsp+0xB0]
00007d07b35dc711  movaps xmm14, xmm9
00007d07b35dc715  mulpd xmm14, xmm1
00007d07b35dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007d07b35dc720  ptest xmm6, xmm6
00007d07b35dc725  jnz 0x00007D07B35E0F0E
00007d07b35dc72b  movaps [r15+0x180], xmm14
00007d07b35dc733  movaps xmm1, xmm13
00007d07b35dc737  addpd xmm1, xmm8
00007d07b35dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007d07b35dc741  ptest xmm9, xmm9
00007d07b35dc747  jnz 0x00007D07B35E1051
00007d07b35dc74d  movaps [r15+0x210], xmm1
00007d07b35dc755  movups xmm13, [r13+rax*1]
00007d07b35dc75b  lea r12, [rax+0x10]
00007d07b35dc75f  movups xmm9, [r13+r12*1]
00007d07b35dc765  movaps [r15+0x230], xmm9
00007d07b35dc76d  movaps xmm8, xmm15
00007d07b35dc771  addpd xmm8, xmm7
00007d07b35dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007d07b35dc77c  ptest xmm6, xmm6
00007d07b35dc781  jnz 0x00007D07B35E11A7
00007d07b35dc787  movaps [r15+0x130], xmm8
00007d07b35dc78f  vmovaps xmm15, [rsp+0x20]
00007d07b35dc795  vpermilpd xmm15, xmm15, 0x00
00007d07b35dc79b  movaps xmm7, xmm9
00007d07b35dc79f  mulpd xmm7, xmm15
00007d07b35dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007d07b35dc7a9  ptest xmm6, xmm6
00007d07b35dc7ae  jnz 0x00007D07B35E12EA
00007d07b35dc7b4  movaps [r15+0x220], xmm7
00007d07b35dc7bc  vmovaps xmm15, [rsp+0x20]
00007d07b35dc7c2  vpermilpd xmm15, xmm15, 0x00
00007d07b35dc7c8  movaps xmm9, xmm13
00007d07b35dc7cc  mulpd xmm9, xmm15
00007d07b35dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007d07b35dc7d7  ptest xmm6, xmm6
00007d07b35dc7dc  jnz 0x00007D07B35E142C
00007d07b35dc7e2  movaps xmm15, xmm11
00007d07b35dc7e6  addpd xmm15, xmm12
00007d07b35dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007d07b35dc7f1  ptest xmm13, xmm13
00007d07b35dc7f7  jnz 0x00007D07B35E1570
00007d07b35dc7fd  movaps [r15+0x140], xmm15
00007d07b35dc805  movaps xmm13, xmm10
00007d07b35dc809  addpd xmm13, xmm14
00007d07b35dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007d07b35dc814  ptest xmm12, xmm12
00007d07b35dc81a  jnz 0x00007D07B35E16B4
00007d07b35dc820  movaps [r15+0x150], xmm13
00007d07b35dc828  movaps xmm14, xmm1
00007d07b35dc82c  addpd xmm14, xmm7
00007d07b35dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007d07b35dc837  ptest xmm12, xmm12
00007d07b35dc83d  jnz 0x00007D07B35E17F8
00007d07b35dc843  movaps [r15+0x160], xmm14
00007d07b35dc84b  movaps xmm1, xmm8
00007d07b35dc84f  addpd xmm1, xmm9
00007d07b35dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007d07b35dc859  ptest xmm12, xmm12
00007d07b35dc85f  jnz 0x00007D07B35E193A
00007d07b35dc865  movaps [r15+0x120], xmm1
00007d07b35dc86d  movups [r13+r14*1], xmm15
00007d07b35dc873  lea rax, [r14+0x10]
00007d07b35dc877  movups [r13+rax*1], xmm13
00007d07b35dc87d  lea rax, [r14+0x20]
00007d07b35dc881  movups [r13+rax*1], xmm14
00007d07b35dc887  lea rax, [r14+0x30]
00007d07b35dc88b  movups [r13+rax*1], xmm1
00007d07b35dc891  mov eax, [r15+0x108]
00007d07b35dc898  sahf
00007d07b35dc899  jnz 0x00007D07B35DC8CB
00007d07b35dc89b  cmp dword ptr [r15+0x318], 0x00
00007d07b35dc8a3  jz 0x00007D07B35DB900
00007d07b35dc8a9  nop [rax+rax*1], ax
00007d07b35dc8b2  nop [rax+rax*1], eax
00007d07b35dc8ba  mov eax, 0x410444
00007d07b35dc8bf  mov [r15+0x100], rax
00007d07b35dc8c6  jmp 0x00007D07B33FE110
00007d07b35dc8cb  cmp dword ptr [r15+0x318], 0x00
00007d07b35dc8d3  jz 0x00007D07B35D57E0
00007d07b35dc8d9  nop [rax+rax*1], ax
00007d07b35dc8e2  nop [rax+rax*1], eax
00007d07b35dc8ea  mov eax, 0x410278
00007d07b35dc8ef  mov [r15+0x100], rax
00007d07b35dc8f6  jmp 0x00007D07B33FE110
00007d07b35dc8fb  int3
00007d07b35dc8fc  call 0x00007D07B34E27E0
00007d07b35dc901  jmp 0x00007D07B35DB9DF
00007d07b35dc906  call 0x00007D07B34E1570
00007d07b35dc90b  jmp 0x00007D07B35DB9E8
00007d07b35dc910  call 0x00007D07B34E27E0
00007d07b35dc915  jmp 0x00007D07B35DBA44
00007d07b35dc91a  call 0x00007D07B34E1570
00007d07b35dc91f  jmp 0x00007D07B35DBA4D
00007d07b35dc924  call 0x00007D07B34E27E0
00007d07b35dc929  jmp 0x00007D07B35DBA90
00007d07b35dc92e  call 0x00007D07B34E1570
00007d07b35dc933  jmp 0x00007D07B35DBA99
00007d07b35dc938  call 0x00007D07B340DC20
00007d07b35dc93d  jmp 0x00007D07B35DBAD8
00007d07b35dc942  call 0x00007D07B34D59C0
00007d07b35dc947  jmp 0x00007D07B35DBAEB
00007d07b35dc94c  call 0x00007D07B34E0E30
00007d07b35dc951  jmp 0x00007D07B35DBB09
00007d07b35dc956  call 0x00007D07B34DFBC0
00007d07b35dc95b  jmp 0x00007D07B35DBB13
00007d07b35dc960  call 0x00007D07B34DE950
00007d07b35dc965  jmp 0x00007D07B35DBB1D
00007d07b35dc96a  sub rsp, 0x08
00007d07b35dc96e  push rax
00007d07b35dc96f  push rcx
00007d07b35dc970  push rdx
00007d07b35dc971  push rdi
00007d07b35dc972  push rsi
00007d07b35dc973  push r8
00007d07b35dc975  push r9
00007d07b35dc977  push r10
00007d07b35dc979  push r11
00007d07b35dc97b  sub rsp, 0xF0
00007d07b35dc982  vmovaps [rsp], xmm0
00007d07b35dc987  vmovaps [rsp+0x10], xmm1
00007d07b35dc98d  vmovaps [rsp+0x20], xmm2
00007d07b35dc993  vmovaps [rsp+0x30], xmm3
00007d07b35dc999  vmovaps [rsp+0x40], xmm4
00007d07b35dc99f  vmovaps [rsp+0x50], xmm5
00007d07b35dc9a5  vmovaps [rsp+0x60], xmm6
00007d07b35dc9ab  vmovaps [rsp+0x70], xmm7
00007d07b35dc9b1  vmovaps [rsp+0x80], xmm9
00007d07b35dc9ba  vmovaps [rsp+0x90], xmm10
00007d07b35dc9c3  vmovaps [rsp+0xA0], xmm11
00007d07b35dc9cc  vmovaps [rsp+0xB0], xmm12
00007d07b35dc9d5  vmovaps [rsp+0xC0], xmm13
00007d07b35dc9de  vmovaps [rsp+0xD0], xmm14
00007d07b35dc9e7  vmovaps [rsp+0xE0], xmm15
00007d07b35dc9f0  sub rsp, 0x30
00007d07b35dc9f4  movaps [rsp], xmm8
00007d07b35dc9f9  movaps [rsp+0x10], xmm12
00007d07b35dc9ff  movaps [rsp+0x20], xmm15
00007d07b35dca05  lea rdi, [rsp]
00007d07b35dca09  mov esi, 0x00
00007d07b35dca0e  mov rax, 0x5D0AA712D530
00007d07b35dca18  call rax
00007d07b35dca1a  movaps xmm8, [rsp]
00007d07b35dca1f  add rsp, 0x30
00007d07b35dca23  vmovaps xmm0, [rsp]
00007d07b35dca28  vmovaps xmm1, [rsp+0x10]
00007d07b35dca2e  vmovaps xmm2, [rsp+0x20]
00007d07b35dca34  vmovaps xmm3, [rsp+0x30]
00007d07b35dca3a  vmovaps xmm4, [rsp+0x40]
00007d07b35dca40  vmovaps xmm5, [rsp+0x50]
00007d07b35dca46  vmovaps xmm6, [rsp+0x60]
00007d07b35dca4c  vmovaps xmm7, [rsp+0x70]
00007d07b35dca52  vmovaps xmm9, [rsp+0x80]
00007d07b35dca5b  vmovaps xmm10, [rsp+0x90]
00007d07b35dca64  vmovaps xmm11, [rsp+0xA0]
00007d07b35dca6d  vmovaps xmm12, [rsp+0xB0]
00007d07b35dca76  vmovaps xmm13, [rsp+0xC0]
00007d07b35dca7f  vmovaps xmm14, [rsp+0xD0]
00007d07b35dca88  vmovaps xmm15, [rsp+0xE0]
00007d07b35dca91  add rsp, 0xF0
00007d07b35dca98  pop r11
00007d07b35dca9a  pop r10
00007d07b35dca9c  pop r9
00007d07b35dca9e  pop r8
00007d07b35dcaa0  pop rsi
00007d07b35dcaa1  pop rdi
00007d07b35dcaa2  pop rdx
00007d07b35dcaa3  pop rcx
00007d07b35dcaa4  pop rax
00007d07b35dcaa5  add rsp, 0x08
00007d07b35dcaa9  jmp 0x00007D07B35DBB47
00007d07b35dcaae  sub rsp, 0x08
00007d07b35dcab2  push rax
00007d07b35dcab3  push rcx
00007d07b35dcab4  push rdx
00007d07b35dcab5  push rdi
00007d07b35dcab6  push rsi
00007d07b35dcab7  push r8
00007d07b35dcab9  push r9
00007d07b35dcabb  push r10
00007d07b35dcabd  push r11
00007d07b35dcabf  sub rsp, 0xF0
00007d07b35dcac6  vmovaps [rsp], xmm0
00007d07b35dcacb  vmovaps [rsp+0x10], xmm1
00007d07b35dcad1  vmovaps [rsp+0x20], xmm2
00007d07b35dcad7  vmovaps [rsp+0x30], xmm3
00007d07b35dcadd  vmovaps [rsp+0x40], xmm4
00007d07b35dcae3  vmovaps [rsp+0x50], xmm5
00007d07b35dcae9  vmovaps [rsp+0x60], xmm6
00007d07b35dcaef  vmovaps [rsp+0x70], xmm8
00007d07b35dcaf5  vmovaps [rsp+0x80], xmm9
00007d07b35dcafe  vmovaps [rsp+0x90], xmm10
00007d07b35dcb07  vmovaps [rsp+0xA0], xmm11
00007d07b35dcb10  vmovaps [rsp+0xB0], xmm12
00007d07b35dcb19  vmovaps [rsp+0xC0], xmm13
00007d07b35dcb22  vmovaps [rsp+0xD0], xmm14
00007d07b35dcb2b  vmovaps [rsp+0xE0], xmm15
00007d07b35dcb34  sub rsp, 0x30
00007d07b35dcb38  movaps [rsp], xmm7
00007d07b35dcb3c  movaps [rsp+0x10], xmm9
00007d07b35dcb42  movaps [rsp+0x20], xmm15
00007d07b35dcb48  lea rdi, [rsp]
00007d07b35dcb4c  mov esi, 0x00
00007d07b35dcb51  mov rax, 0x5D0AA712D530
00007d07b35dcb5b  call rax
00007d07b35dcb5d  movaps xmm7, [rsp]
00007d07b35dcb61  add rsp, 0x30
00007d07b35dcb65  vmovaps xmm0, [rsp]
00007d07b35dcb6a  vmovaps xmm1, [rsp+0x10]
00007d07b35dcb70  vmovaps xmm2, [rsp+0x20]
00007d07b35dcb76  vmovaps xmm3, [rsp+0x30]
00007d07b35dcb7c  vmovaps xmm4, [rsp+0x40]
00007d07b35dcb82  vmovaps xmm5, [rsp+0x50]
00007d07b35dcb88  vmovaps xmm6, [rsp+0x60]
00007d07b35dcb8e  vmovaps xmm8, [rsp+0x70]
00007d07b35dcb94  vmovaps xmm9, [rsp+0x80]
00007d07b35dcb9d  vmovaps xmm10, [rsp+0x90]
00007d07b35dcba6  vmovaps xmm11, [rsp+0xA0]
00007d07b35dcbaf  vmovaps xmm12, [rsp+0xB0]
00007d07b35dcbb8  vmovaps xmm13, [rsp+0xC0]
00007d07b35dcbc1  vmovaps xmm14, [rsp+0xD0]
00007d07b35dcbca  vmovaps xmm15, [rsp+0xE0]
00007d07b35dcbd3  add rsp, 0xF0
00007d07b35dcbda  pop r11
00007d07b35dcbdc  pop r10
00007d07b35dcbde  pop r9
00007d07b35dcbe0  pop r8
00007d07b35dcbe2  pop rsi
00007d07b35dcbe3  pop rdi
00007d07b35dcbe4  pop rdx
00007d07b35dcbe5  pop rcx
00007d07b35dcbe6  pop rax
00007d07b35dcbe7  add rsp, 0x08
00007d07b35dcbeb  jmp 0x00007D07B35DBB75
00007d07b35dcbf0  sub rsp, 0x08
00007d07b35dcbf4  push rax
00007d07b35dcbf5  push rcx
00007d07b35dcbf6  push rdx
00007d07b35dcbf7  push rdi
00007d07b35dcbf8  push rsi
00007d07b35dcbf9  push r8
00007d07b35dcbfb  push r9
00007d07b35dcbfd  push r10
00007d07b35dcbff  push r11
00007d07b35dcc01  sub rsp, 0xF0
00007d07b35dcc08  vmovaps [rsp], xmm0
00007d07b35dcc0d  vmovaps [rsp+0x10], xmm1
00007d07b35dcc13  vmovaps [rsp+0x20], xmm2
00007d07b35dcc19  vmovaps [rsp+0x30], xmm3
00007d07b35dcc1f  vmovaps [rsp+0x40], xmm4
00007d07b35dcc25  vmovaps [rsp+0x50], xmm5
00007d07b35dcc2b  vmovaps [rsp+0x60], xmm6
00007d07b35dcc31  vmovaps [rsp+0x70], xmm7
00007d07b35dcc37  vmovaps [rsp+0x80], xmm8
00007d07b35dcc40  vmovaps [rsp+0x90], xmm10
00007d07b35dcc49  vmovaps [rsp+0xA0], xmm11
00007d07b35dcc52  vmovaps [rsp+0xB0], xmm12
00007d07b35dcc5b  vmovaps [rsp+0xC0], xmm13
00007d07b35dcc64  vmovaps [rsp+0xD0], xmm14
00007d07b35dcc6d  vmovaps [rsp+0xE0], xmm15
00007d07b35dcc76  sub rsp, 0x30
00007d07b35dcc7a  movaps [rsp], xmm9
00007d07b35dcc7f  movaps [rsp+0x10], xmm12
00007d07b35dcc85  movaps [rsp+0x20], xmm10
00007d07b35dcc8b  lea rdi, [rsp]
00007d07b35dcc8f  mov esi, 0x00
00007d07b35dcc94  mov rax, 0x5D0AA712D530
00007d07b35dcc9e  call rax
00007d07b35dcca0  movaps xmm9, [rsp]
00007d07b35dcca5  add rsp, 0x30
00007d07b35dcca9  vmovaps xmm0, [rsp]
00007d07b35dccae  vmovaps xmm1, [rsp+0x10]
00007d07b35dccb4  vmovaps xmm2, [rsp+0x20]
00007d07b35dccba  vmovaps xmm3, [rsp+0x30]
00007d07b35dccc0  vmovaps xmm4, [rsp+0x40]
00007d07b35dccc6  vmovaps xmm5, [rsp+0x50]
00007d07b35dcccc  vmovaps xmm6, [rsp+0x60]
00007d07b35dccd2  vmovaps xmm7, [rsp+0x70]
00007d07b35dccd8  vmovaps xmm8, [rsp+0x80]
00007d07b35dcce1  vmovaps xmm10, [rsp+0x90]
00007d07b35dccea  vmovaps xmm11, [rsp+0xA0]
00007d07b35dccf3  vmovaps xmm12, [rsp+0xB0]
00007d07b35dccfc  vmovaps xmm13, [rsp+0xC0]
00007d07b35dcd05  vmovaps xmm14, [rsp+0xD0]
00007d07b35dcd0e  vmovaps xmm15, [rsp+0xE0]
00007d07b35dcd17  add rsp, 0xF0
00007d07b35dcd1e  pop r11
00007d07b35dcd20  pop r10
00007d07b35dcd22  pop r9
00007d07b35dcd24  pop r8
00007d07b35dcd26  pop rsi
00007d07b35dcd27  pop rdi
00007d07b35dcd28  pop rdx
00007d07b35dcd29  pop rcx
00007d07b35dcd2a  pop rax
00007d07b35dcd2b  add rsp, 0x08
00007d07b35dcd2f  jmp 0x00007D07B35DBB99
00007d07b35dcd34  sub rsp, 0x08
00007d07b35dcd38  push rax
00007d07b35dcd39  push rcx
00007d07b35dcd3a  push rdx
00007d07b35dcd3b  push rdi
00007d07b35dcd3c  push rsi
00007d07b35dcd3d  push r8
00007d07b35dcd3f  push r9
00007d07b35dcd41  push r10
00007d07b35dcd43  push r11
00007d07b35dcd45  sub rsp, 0xF0
00007d07b35dcd4c  vmovaps [rsp], xmm0
00007d07b35dcd51  vmovaps [rsp+0x10], xmm1
00007d07b35dcd57  vmovaps [rsp+0x20], xmm2
00007d07b35dcd5d  vmovaps [rsp+0x30], xmm3
00007d07b35dcd63  vmovaps [rsp+0x40], xmm4
00007d07b35dcd69  vmovaps [rsp+0x50], xmm5
00007d07b35dcd6f  vmovaps [rsp+0x60], xmm6
00007d07b35dcd75  vmovaps [rsp+0x70], xmm7
00007d07b35dcd7b  vmovaps [rsp+0x80], xmm8
00007d07b35dcd84  vmovaps [rsp+0x90], xmm9
00007d07b35dcd8d  vmovaps [rsp+0xA0], xmm11
00007d07b35dcd96  vmovaps [rsp+0xB0], xmm12
00007d07b35dcd9f  vmovaps [rsp+0xC0], xmm13
00007d07b35dcda8  vmovaps [rsp+0xD0], xmm14
00007d07b35dcdb1  vmovaps [rsp+0xE0], xmm15
00007d07b35dcdba  sub rsp, 0x30
00007d07b35dcdbe  movaps [rsp], xmm10
00007d07b35dcdc3  movaps [rsp+0x10], xmm12
00007d07b35dcdc9  movaps [rsp+0x20], xmm11
00007d07b35dcdcf  lea rdi, [rsp]
00007d07b35dcdd3  mov esi, 0x00
00007d07b35dcdd8  mov rax, 0x5D0AA712D530
00007d07b35dcde2  call rax
00007d07b35dcde4  movaps xmm10, [rsp]
00007d07b35dcde9  add rsp, 0x30
00007d07b35dcded  vmovaps xmm0, [rsp]
00007d07b35dcdf2  vmovaps xmm1, [rsp+0x10]
00007d07b35dcdf8  vmovaps xmm2, [rsp+0x20]
00007d07b35dcdfe  vmovaps xmm3, [rsp+0x30]
00007d07b35dce04  vmovaps xmm4, [rsp+0x40]
00007d07b35dce0a  vmovaps xmm5, [rsp+0x50]
00007d07b35dce10  vmovaps xmm6, [rsp+0x60]
00007d07b35dce16  vmovaps xmm7, [rsp+0x70]
00007d07b35dce1c  vmovaps xmm8, [rsp+0x80]
00007d07b35dce25  vmovaps xmm9, [rsp+0x90]
00007d07b35dce2e  vmovaps xmm11, [rsp+0xA0]
00007d07b35dce37  vmovaps xmm12, [rsp+0xB0]
00007d07b35dce40  vmovaps xmm13, [rsp+0xC0]
00007d07b35dce49  vmovaps xmm14, [rsp+0xD0]
00007d07b35dce52  vmovaps xmm15, [rsp+0xE0]
00007d07b35dce5b  add rsp, 0xF0
00007d07b35dce62  pop r11
00007d07b35dce64  pop r10
00007d07b35dce66  pop r9
00007d07b35dce68  pop r8
00007d07b35dce6a  pop rsi
00007d07b35dce6b  pop rdi
00007d07b35dce6c  pop rdx
00007d07b35dce6d  pop rcx
00007d07b35dce6e  pop rax
00007d07b35dce6f  add rsp, 0x08
00007d07b35dce73  jmp 0x00007D07B35DBBB3
00007d07b35dce78  sub rsp, 0x08
00007d07b35dce7c  push rax
00007d07b35dce7d  push rcx
00007d07b35dce7e  push rdx
00007d07b35dce7f  push rdi
00007d07b35dce80  push rsi
00007d07b35dce81  push r8
00007d07b35dce83  push r9
00007d07b35dce85  push r10
00007d07b35dce87  push r11
00007d07b35dce89  sub rsp, 0xF0
00007d07b35dce90  vmovaps [rsp], xmm0
00007d07b35dce95  vmovaps [rsp+0x10], xmm1
00007d07b35dce9b  vmovaps [rsp+0x20], xmm2
00007d07b35dcea1  vmovaps [rsp+0x30], xmm3
00007d07b35dcea7  vmovaps [rsp+0x40], xmm4
00007d07b35dcead  vmovaps [rsp+0x50], xmm5
00007d07b35dceb3  vmovaps [rsp+0x60], xmm7
00007d07b35dceb9  vmovaps [rsp+0x70], xmm8
00007d07b35dcebf  vmovaps [rsp+0x80], xmm9
00007d07b35dcec8  vmovaps [rsp+0x90], xmm10
00007d07b35dced1  vmovaps [rsp+0xA0], xmm11
00007d07b35dceda  vmovaps [rsp+0xB0], xmm12
00007d07b35dcee3  vmovaps [rsp+0xC0], xmm13
00007d07b35dceec  vmovaps [rsp+0xD0], xmm14
00007d07b35dcef5  vmovaps [rsp+0xE0], xmm15
00007d07b35dcefe  sub rsp, 0x30
00007d07b35dcf02  movaps [rsp], xmm6
00007d07b35dcf06  movaps [rsp+0x10], xmm12
00007d07b35dcf0c  movaps [rsp+0x20], xmm11
00007d07b35dcf12  lea rdi, [rsp]
00007d07b35dcf16  mov esi, 0x00
00007d07b35dcf1b  mov rax, 0x5D0AA712D530
00007d07b35dcf25  call rax
00007d07b35dcf27  movaps xmm6, [rsp]
00007d07b35dcf2b  add rsp, 0x30
00007d07b35dcf2f  vmovaps xmm0, [rsp]
00007d07b35dcf34  vmovaps xmm1, [rsp+0x10]
00007d07b35dcf3a  vmovaps xmm2, [rsp+0x20]
00007d07b35dcf40  vmovaps xmm3, [rsp+0x30]
00007d07b35dcf46  vmovaps xmm4, [rsp+0x40]
00007d07b35dcf4c  vmovaps xmm5, [rsp+0x50]
00007d07b35dcf52  vmovaps xmm7, [rsp+0x60]
00007d07b35dcf58  vmovaps xmm8, [rsp+0x70]
00007d07b35dcf5e  vmovaps xmm9, [rsp+0x80]
00007d07b35dcf67  vmovaps xmm10, [rsp+0x90]
00007d07b35dcf70  vmovaps xmm11, [rsp+0xA0]
00007d07b35dcf79  vmovaps xmm12, [rsp+0xB0]
00007d07b35dcf82  vmovaps xmm13, [rsp+0xC0]
00007d07b35dcf8b  vmovaps xmm14, [rsp+0xD0]
00007d07b35dcf94  vmovaps xmm15, [rsp+0xE0]
00007d07b35dcf9d  add rsp, 0xF0
00007d07b35dcfa4  pop r11
00007d07b35dcfa6  pop r10
00007d07b35dcfa8  pop r9
00007d07b35dcfaa  pop r8
00007d07b35dcfac  pop rsi
00007d07b35dcfad  pop rdi
00007d07b35dcfae  pop rdx
00007d07b35dcfaf  pop rcx
00007d07b35dcfb0  pop rax
00007d07b35dcfb1  add rsp, 0x08
00007d07b35dcfb5  jmp 0x00007D07B35DBBD4
00007d07b35dcfba  sub rsp, 0x08
00007d07b35dcfbe  push rax
00007d07b35dcfbf  push rcx
00007d07b35dcfc0  push rdx
00007d07b35dcfc1  push rdi
00007d07b35dcfc2  push rsi
00007d07b35dcfc3  push r8
00007d07b35dcfc5  push r9
00007d07b35dcfc7  push r10
00007d07b35dcfc9  push r11
00007d07b35dcfcb  sub rsp, 0xF0
00007d07b35dcfd2  vmovaps [rsp], xmm0
00007d07b35dcfd7  vmovaps [rsp+0x10], xmm1
00007d07b35dcfdd  vmovaps [rsp+0x20], xmm2
00007d07b35dcfe3  vmovaps [rsp+0x30], xmm4
00007d07b35dcfe9  vmovaps [rsp+0x40], xmm5
00007d07b35dcfef  vmovaps [rsp+0x50], xmm6
00007d07b35dcff5  vmovaps [rsp+0x60], xmm7
00007d07b35dcffb  vmovaps [rsp+0x70], xmm8
00007d07b35dd001  vmovaps [rsp+0x80], xmm9
00007d07b35dd00a  vmovaps [rsp+0x90], xmm10
00007d07b35dd013  vmovaps [rsp+0xA0], xmm11
00007d07b35dd01c  vmovaps [rsp+0xB0], xmm12
00007d07b35dd025  vmovaps [rsp+0xC0], xmm13
00007d07b35dd02e  vmovaps [rsp+0xD0], xmm14
00007d07b35dd037  vmovaps [rsp+0xE0], xmm15
00007d07b35dd040  sub rsp, 0x30
00007d07b35dd044  movaps [rsp], xmm3
00007d07b35dd048  movaps [rsp+0x10], xmm5
00007d07b35dd04d  movaps [rsp+0x20], xmm4
00007d07b35dd052  lea rdi, [rsp]
00007d07b35dd056  mov esi, 0x00
00007d07b35dd05b  mov rax, 0x5D0AA712D530
00007d07b35dd065  call rax
00007d07b35dd067  movaps xmm3, [rsp]
00007d07b35dd06b  add rsp, 0x30
00007d07b35dd06f  vmovaps xmm0, [rsp]
00007d07b35dd074  vmovaps xmm1, [rsp+0x10]
00007d07b35dd07a  vmovaps xmm2, [rsp+0x20]
00007d07b35dd080  vmovaps xmm4, [rsp+0x30]
00007d07b35dd086  vmovaps xmm5, [rsp+0x40]
00007d07b35dd08c  vmovaps xmm6, [rsp+0x50]
00007d07b35dd092  vmovaps xmm7, [rsp+0x60]
00007d07b35dd098  vmovaps xmm8, [rsp+0x70]
00007d07b35dd09e  vmovaps xmm9, [rsp+0x80]
00007d07b35dd0a7  vmovaps xmm10, [rsp+0x90]
00007d07b35dd0b0  vmovaps xmm11, [rsp+0xA0]
00007d07b35dd0b9  vmovaps xmm12, [rsp+0xB0]
00007d07b35dd0c2  vmovaps xmm13, [rsp+0xC0]
00007d07b35dd0cb  vmovaps xmm14, [rsp+0xD0]
00007d07b35dd0d4  vmovaps xmm15, [rsp+0xE0]
00007d07b35dd0dd  add rsp, 0xF0
00007d07b35dd0e4  pop r11
00007d07b35dd0e6  pop r10
00007d07b35dd0e8  pop r9
00007d07b35dd0ea  pop r8
00007d07b35dd0ec  pop rsi
00007d07b35dd0ed  pop rdi
00007d07b35dd0ee  pop rdx
00007d07b35dd0ef  pop rcx
00007d07b35dd0f0  pop rax
00007d07b35dd0f1  add rsp, 0x08
00007d07b35dd0f5  jmp 0x00007D07B35DBC35
00007d07b35dd0fa  sub rsp, 0x08
00007d07b35dd0fe  push rax
00007d07b35dd0ff  push rcx
00007d07b35dd100  push rdx
00007d07b35dd101  push rdi
00007d07b35dd102  push rsi
00007d07b35dd103  push r8
00007d07b35dd105  push r9
00007d07b35dd107  push r10
00007d07b35dd109  push r11
00007d07b35dd10b  sub rsp, 0xF0
00007d07b35dd112  vmovaps [rsp], xmm0
00007d07b35dd117  vmovaps [rsp+0x10], xmm1
00007d07b35dd11d  vmovaps [rsp+0x20], xmm2
00007d07b35dd123  vmovaps [rsp+0x30], xmm3
00007d07b35dd129  vmovaps [rsp+0x40], xmm4
00007d07b35dd12f  vmovaps [rsp+0x50], xmm6
00007d07b35dd135  vmovaps [rsp+0x60], xmm7
00007d07b35dd13b  vmovaps [rsp+0x70], xmm8
00007d07b35dd141  vmovaps [rsp+0x80], xmm9
00007d07b35dd14a  vmovaps [rsp+0x90], xmm10
00007d07b35dd153  vmovaps [rsp+0xA0], xmm11
00007d07b35dd15c  vmovaps [rsp+0xB0], xmm12
00007d07b35dd165  vmovaps [rsp+0xC0], xmm13
00007d07b35dd16e  vmovaps [rsp+0xD0], xmm14
00007d07b35dd177  vmovaps [rsp+0xE0], xmm15
00007d07b35dd180  sub rsp, 0x30
00007d07b35dd184  movaps [rsp], xmm5
00007d07b35dd188  movaps [rsp+0x10], xmm8
00007d07b35dd18e  movaps [rsp+0x20], xmm15
00007d07b35dd194  lea rdi, [rsp]
00007d07b35dd198  mov esi, 0x00
00007d07b35dd19d  mov rax, 0x5D0AA712D530
00007d07b35dd1a7  call rax
00007d07b35dd1a9  movaps xmm5, [rsp]
00007d07b35dd1ad  add rsp, 0x30
00007d07b35dd1b1  vmovaps xmm0, [rsp]
00007d07b35dd1b6  vmovaps xmm1, [rsp+0x10]
00007d07b35dd1bc  vmovaps xmm2, [rsp+0x20]
00007d07b35dd1c2  vmovaps xmm3, [rsp+0x30]
00007d07b35dd1c8  vmovaps xmm4, [rsp+0x40]
00007d07b35dd1ce  vmovaps xmm6, [rsp+0x50]
00007d07b35dd1d4  vmovaps xmm7, [rsp+0x60]
00007d07b35dd1da  vmovaps xmm8, [rsp+0x70]
00007d07b35dd1e0  vmovaps xmm9, [rsp+0x80]
00007d07b35dd1e9  vmovaps xmm10, [rsp+0x90]
00007d07b35dd1f2  vmovaps xmm11, [rsp+0xA0]
00007d07b35dd1fb  vmovaps xmm12, [rsp+0xB0]
00007d07b35dd204  vmovaps xmm13, [rsp+0xC0]
00007d07b35dd20d  vmovaps xmm14, [rsp+0xD0]
00007d07b35dd216  vmovaps xmm15, [rsp+0xE0]
00007d07b35dd21f  add rsp, 0xF0
00007d07b35dd226  pop r11
00007d07b35dd228  pop r10
00007d07b35dd22a  pop r9
00007d07b35dd22c  pop r8
00007d07b35dd22e  pop rsi
00007d07b35dd22f  pop rdi
00007d07b35dd230  pop rdx
00007d07b35dd231  pop rcx
00007d07b35dd232  pop rax
00007d07b35dd233  add rsp, 0x08
00007d07b35dd237  jmp 0x00007D07B35DBC73
00007d07b35dd23c  sub rsp, 0x08
00007d07b35dd240  push rax
00007d07b35dd241  push rcx
00007d07b35dd242  push rdx
00007d07b35dd243  push rdi
00007d07b35dd244  push rsi
00007d07b35dd245  push r8
00007d07b35dd247  push r9
00007d07b35dd249  push r10
00007d07b35dd24b  push r11
00007d07b35dd24d  sub rsp, 0xF0
00007d07b35dd254  vmovaps [rsp], xmm0
00007d07b35dd259  vmovaps [rsp+0x10], xmm1
00007d07b35dd25f  vmovaps [rsp+0x20], xmm2
00007d07b35dd265  vmovaps [rsp+0x30], xmm3
00007d07b35dd26b  vmovaps [rsp+0x40], xmm5
00007d07b35dd271  vmovaps [rsp+0x50], xmm6
00007d07b35dd277  vmovaps [rsp+0x60], xmm7
00007d07b35dd27d  vmovaps [rsp+0x70], xmm8
00007d07b35dd283  vmovaps [rsp+0x80], xmm9
00007d07b35dd28c  vmovaps [rsp+0x90], xmm10
00007d07b35dd295  vmovaps [rsp+0xA0], xmm11
00007d07b35dd29e  vmovaps [rsp+0xB0], xmm12
00007d07b35dd2a7  vmovaps [rsp+0xC0], xmm13
00007d07b35dd2b0  vmovaps [rsp+0xD0], xmm14
00007d07b35dd2b9  vmovaps [rsp+0xE0], xmm15
00007d07b35dd2c2  sub rsp, 0x30
00007d07b35dd2c6  movaps [rsp], xmm4
00007d07b35dd2ca  movaps [rsp+0x10], xmm9
00007d07b35dd2d0  movaps [rsp+0x20], xmm8
00007d07b35dd2d6  lea rdi, [rsp]
00007d07b35dd2da  mov esi, 0x00
00007d07b35dd2df  mov rax, 0x5D0AA712D530
00007d07b35dd2e9  call rax
00007d07b35dd2eb  movaps xmm4, [rsp]
00007d07b35dd2ef  add rsp, 0x30
00007d07b35dd2f3  vmovaps xmm0, [rsp]
00007d07b35dd2f8  vmovaps xmm1, [rsp+0x10]
00007d07b35dd2fe  vmovaps xmm2, [rsp+0x20]
00007d07b35dd304  vmovaps xmm3, [rsp+0x30]
00007d07b35dd30a  vmovaps xmm5, [rsp+0x40]
00007d07b35dd310  vmovaps xmm6, [rsp+0x50]
00007d07b35dd316  vmovaps xmm7, [rsp+0x60]
00007d07b35dd31c  vmovaps xmm8, [rsp+0x70]
00007d07b35dd322  vmovaps xmm9, [rsp+0x80]
00007d07b35dd32b  vmovaps xmm10, [rsp+0x90]
00007d07b35dd334  vmovaps xmm11, [rsp+0xA0]
00007d07b35dd33d  vmovaps xmm12, [rsp+0xB0]
00007d07b35dd346  vmovaps xmm13, [rsp+0xC0]
00007d07b35dd34f  vmovaps xmm14, [rsp+0xD0]
00007d07b35dd358  vmovaps xmm15, [rsp+0xE0]
00007d07b35dd361  add rsp, 0xF0
00007d07b35dd368  pop r11
00007d07b35dd36a  pop r10
00007d07b35dd36c  pop r9
00007d07b35dd36e  pop r8
00007d07b35dd370  pop rsi
00007d07b35dd371  pop rdi
00007d07b35dd372  pop rdx
00007d07b35dd373  pop rcx
00007d07b35dd374  pop rax
00007d07b35dd375  add rsp, 0x08
00007d07b35dd379  jmp 0x00007D07B35DBC94
00007d07b35dd37e  sub rsp, 0x08
00007d07b35dd382  push rax
00007d07b35dd383  push rcx
00007d07b35dd384  push rdx
00007d07b35dd385  push rdi
00007d07b35dd386  push rsi
00007d07b35dd387  push r8
00007d07b35dd389  push r9
00007d07b35dd38b  push r10
00007d07b35dd38d  push r11
00007d07b35dd38f  sub rsp, 0xF0
00007d07b35dd396  vmovaps [rsp], xmm0
00007d07b35dd39b  vmovaps [rsp+0x10], xmm1
00007d07b35dd3a1  vmovaps [rsp+0x20], xmm2
00007d07b35dd3a7  vmovaps [rsp+0x30], xmm3
00007d07b35dd3ad  vmovaps [rsp+0x40], xmm4
00007d07b35dd3b3  vmovaps [rsp+0x50], xmm5
00007d07b35dd3b9  vmovaps [rsp+0x60], xmm6
00007d07b35dd3bf  vmovaps [rsp+0x70], xmm7
00007d07b35dd3c5  vmovaps [rsp+0x80], xmm8
00007d07b35dd3ce  vmovaps [rsp+0x90], xmm10
00007d07b35dd3d7  vmovaps [rsp+0xA0], xmm11
00007d07b35dd3e0  vmovaps [rsp+0xB0], xmm12
00007d07b35dd3e9  vmovaps [rsp+0xC0], xmm13
00007d07b35dd3f2  vmovaps [rsp+0xD0], xmm14
00007d07b35dd3fb  vmovaps [rsp+0xE0], xmm15
00007d07b35dd404  sub rsp, 0x30
00007d07b35dd408  movaps [rsp], xmm9
00007d07b35dd40d  movaps [rsp+0x10], xmm10
00007d07b35dd413  movaps [rsp+0x20], xmm8
00007d07b35dd419  lea rdi, [rsp]
00007d07b35dd41d  mov esi, 0x00
00007d07b35dd422  mov rax, 0x5D0AA712D530
00007d07b35dd42c  call rax
00007d07b35dd42e  movaps xmm9, [rsp]
00007d07b35dd433  add rsp, 0x30
00007d07b35dd437  vmovaps xmm0, [rsp]
00007d07b35dd43c  vmovaps xmm1, [rsp+0x10]
00007d07b35dd442  vmovaps xmm2, [rsp+0x20]
00007d07b35dd448  vmovaps xmm3, [rsp+0x30]
00007d07b35dd44e  vmovaps xmm4, [rsp+0x40]
00007d07b35dd454  vmovaps xmm5, [rsp+0x50]
00007d07b35dd45a  vmovaps xmm6, [rsp+0x60]
00007d07b35dd460  vmovaps xmm7, [rsp+0x70]
00007d07b35dd466  vmovaps xmm8, [rsp+0x80]
00007d07b35dd46f  vmovaps xmm10, [rsp+0x90]
00007d07b35dd478  vmovaps xmm11, [rsp+0xA0]
00007d07b35dd481  vmovaps xmm12, [rsp+0xB0]
00007d07b35dd48a  vmovaps xmm13, [rsp+0xC0]
00007d07b35dd493  vmovaps xmm14, [rsp+0xD0]
00007d07b35dd49c  vmovaps xmm15, [rsp+0xE0]
00007d07b35dd4a5  add rsp, 0xF0
00007d07b35dd4ac  pop r11
00007d07b35dd4ae  pop r10
00007d07b35dd4b0  pop r9
00007d07b35dd4b2  pop r8
00007d07b35dd4b4  pop rsi
00007d07b35dd4b5  pop rdi
00007d07b35dd4b6  pop rdx
00007d07b35dd4b7  pop rcx
00007d07b35dd4b8  pop rax
00007d07b35dd4b9  add rsp, 0x08
00007d07b35dd4bd  jmp 0x00007D07B35DBCAE
00007d07b35dd4c2  call 0x00007D07B34B52F0
00007d07b35dd4c7  jmp 0x00007D07B35DBDC8
00007d07b35dd4cc  call 0x00007D07B34B52F0
00007d07b35dd4d1  jmp 0x00007D07B35DBDDE
00007d07b35dd4d6  sub rsp, 0x08
00007d07b35dd4da  push rax
00007d07b35dd4db  push rcx
00007d07b35dd4dc  push rdx
00007d07b35dd4dd  push rdi
00007d07b35dd4de  push rsi
00007d07b35dd4df  push r8
00007d07b35dd4e1  push r9
00007d07b35dd4e3  push r10
00007d07b35dd4e5  push r11
00007d07b35dd4e7  sub rsp, 0xF0
00007d07b35dd4ee  vmovaps [rsp], xmm0
00007d07b35dd4f3  vmovaps [rsp+0x10], xmm2
00007d07b35dd4f9  vmovaps [rsp+0x20], xmm3
00007d07b35dd4ff  vmovaps [rsp+0x30], xmm4
00007d07b35dd505  vmovaps [rsp+0x40], xmm5
00007d07b35dd50b  vmovaps [rsp+0x50], xmm6
00007d07b35dd511  vmovaps [rsp+0x60], xmm7
00007d07b35dd517  vmovaps [rsp+0x70], xmm8
00007d07b35dd51d  vmovaps [rsp+0x80], xmm9
00007d07b35dd526  vmovaps [rsp+0x90], xmm10
00007d07b35dd52f  vmovaps [rsp+0xA0], xmm11
00007d07b35dd538  vmovaps [rsp+0xB0], xmm12
00007d07b35dd541  vmovaps [rsp+0xC0], xmm13
00007d07b35dd54a  vmovaps [rsp+0xD0], xmm14
00007d07b35dd553  vmovaps [rsp+0xE0], xmm15
00007d07b35dd55c  sub rsp, 0x30
00007d07b35dd560  movaps [rsp], xmm1
00007d07b35dd564  movaps [rsp+0x10], xmm6
00007d07b35dd569  movaps [rsp+0x20], xmm15
00007d07b35dd56f  lea rdi, [rsp]
00007d07b35dd573  mov esi, 0x00
00007d07b35dd578  mov rax, 0x5D0AA712D530
00007d07b35dd582  call rax
00007d07b35dd584  movaps xmm1, [rsp]
00007d07b35dd588  add rsp, 0x30
00007d07b35dd58c  vmovaps xmm0, [rsp]
00007d07b35dd591  vmovaps xmm2, [rsp+0x10]
00007d07b35dd597  vmovaps xmm3, [rsp+0x20]
00007d07b35dd59d  vmovaps xmm4, [rsp+0x30]
00007d07b35dd5a3  vmovaps xmm5, [rsp+0x40]
00007d07b35dd5a9  vmovaps xmm6, [rsp+0x50]
00007d07b35dd5af  vmovaps xmm7, [rsp+0x60]
00007d07b35dd5b5  vmovaps xmm8, [rsp+0x70]
00007d07b35dd5bb  vmovaps xmm9, [rsp+0x80]
00007d07b35dd5c4  vmovaps xmm10, [rsp+0x90]
00007d07b35dd5cd  vmovaps xmm11, [rsp+0xA0]
00007d07b35dd5d6  vmovaps xmm12, [rsp+0xB0]
00007d07b35dd5df  vmovaps xmm13, [rsp+0xC0]
00007d07b35dd5e8  vmovaps xmm14, [rsp+0xD0]
00007d07b35dd5f1  vmovaps xmm15, [rsp+0xE0]
00007d07b35dd5fa  add rsp, 0xF0
00007d07b35dd601  pop r11
00007d07b35dd603  pop r10
00007d07b35dd605  pop r9
00007d07b35dd607  pop r8
00007d07b35dd609  pop rsi
00007d07b35dd60a  pop rdi
00007d07b35dd60b  pop rdx
00007d07b35dd60c  pop rcx
00007d07b35dd60d  pop rax
00007d07b35dd60e  add rsp, 0x08
00007d07b35dd612  jmp 0x00007D07B35DBE1B
00007d07b35dd617  call 0x00007D07B34C4620
00007d07b35dd61c  jmp 0x00007D07B35DBE28
00007d07b35dd621  sub rsp, 0x08
00007d07b35dd625  push rax
00007d07b35dd626  push rcx
00007d07b35dd627  push rdx
00007d07b35dd628  push rdi
00007d07b35dd629  push rsi
00007d07b35dd62a  push r8
00007d07b35dd62c  push r9
00007d07b35dd62e  push r10
00007d07b35dd630  push r11
00007d07b35dd632  sub rsp, 0xF0
00007d07b35dd639  vmovaps [rsp], xmm0
00007d07b35dd63e  vmovaps [rsp+0x10], xmm1
00007d07b35dd644  vmovaps [rsp+0x20], xmm2
00007d07b35dd64a  vmovaps [rsp+0x30], xmm3
00007d07b35dd650  vmovaps [rsp+0x40], xmm4
00007d07b35dd656  vmovaps [rsp+0x50], xmm5
00007d07b35dd65c  vmovaps [rsp+0x60], xmm6
00007d07b35dd662  vmovaps [rsp+0x70], xmm7
00007d07b35dd668  vmovaps [rsp+0x80], xmm8
00007d07b35dd671  vmovaps [rsp+0x90], xmm9
00007d07b35dd67a  vmovaps [rsp+0xA0], xmm10
00007d07b35dd683  vmovaps [rsp+0xB0], xmm11
00007d07b35dd68c  vmovaps [rsp+0xC0], xmm12
00007d07b35dd695  vmovaps [rsp+0xD0], xmm13
00007d07b35dd69e  vmovaps [rsp+0xE0], xmm15
00007d07b35dd6a7  sub rsp, 0x30
00007d07b35dd6ab  movaps [rsp], xmm14
00007d07b35dd6b0  movaps [rsp+0x10], xmm4
00007d07b35dd6b5  movaps [rsp+0x20], xmm3
00007d07b35dd6ba  lea rdi, [rsp]
00007d07b35dd6be  mov esi, 0x00
00007d07b35dd6c3  mov rax, 0x5D0AA712D530
00007d07b35dd6cd  call rax
00007d07b35dd6cf  movaps xmm14, [rsp]
00007d07b35dd6d4  add rsp, 0x30
00007d07b35dd6d8  vmovaps xmm0, [rsp]
00007d07b35dd6dd  vmovaps xmm1, [rsp+0x10]
00007d07b35dd6e3  vmovaps xmm2, [rsp+0x20]
00007d07b35dd6e9  vmovaps xmm3, [rsp+0x30]
00007d07b35dd6ef  vmovaps xmm4, [rsp+0x40]
00007d07b35dd6f5  vmovaps xmm5, [rsp+0x50]
00007d07b35dd6fb  vmovaps xmm6, [rsp+0x60]
00007d07b35dd701  vmovaps xmm7, [rsp+0x70]
00007d07b35dd707  vmovaps xmm8, [rsp+0x80]
00007d07b35dd710  vmovaps xmm9, [rsp+0x90]
00007d07b35dd719  vmovaps xmm10, [rsp+0xA0]
00007d07b35dd722  vmovaps xmm11, [rsp+0xB0]
00007d07b35dd72b  vmovaps xmm12, [rsp+0xC0]
00007d07b35dd734  vmovaps xmm13, [rsp+0xD0]
00007d07b35dd73d  vmovaps xmm15, [rsp+0xE0]
00007d07b35dd746  add rsp, 0xF0
00007d07b35dd74d  pop r11
00007d07b35dd74f  pop r10
00007d07b35dd751  pop r9
00007d07b35dd753  pop r8
00007d07b35dd755  pop rsi
00007d07b35dd756  pop rdi
00007d07b35dd757  pop rdx
00007d07b35dd758  pop rcx
00007d07b35dd759  pop rax
00007d07b35dd75a  add rsp, 0x08
00007d07b35dd75e  jmp 0x00007D07B35DBE42
00007d07b35dd763  sub rsp, 0x08
00007d07b35dd767  push rax
00007d07b35dd768  push rcx
00007d07b35dd769  push rdx
00007d07b35dd76a  push rdi
00007d07b35dd76b  push rsi
00007d07b35dd76c  push r8
00007d07b35dd76e  push r9
00007d07b35dd770  push r10
00007d07b35dd772  push r11
00007d07b35dd774  sub rsp, 0xF0
00007d07b35dd77b  vmovaps [rsp], xmm0
00007d07b35dd780  vmovaps [rsp+0x10], xmm1
00007d07b35dd786  vmovaps [rsp+0x20], xmm2
00007d07b35dd78c  vmovaps [rsp+0x30], xmm3
00007d07b35dd792  vmovaps [rsp+0x40], xmm4
00007d07b35dd798  vmovaps [rsp+0x50], xmm5
00007d07b35dd79e  vmovaps [rsp+0x60], xmm7
00007d07b35dd7a4  vmovaps [rsp+0x70], xmm8
00007d07b35dd7aa  vmovaps [rsp+0x80], xmm9
00007d07b35dd7b3  vmovaps [rsp+0x90], xmm10
00007d07b35dd7bc  vmovaps [rsp+0xA0], xmm11
00007d07b35dd7c5  vmovaps [rsp+0xB0], xmm12
00007d07b35dd7ce  vmovaps [rsp+0xC0], xmm13
00007d07b35dd7d7  vmovaps [rsp+0xD0], xmm14
00007d07b35dd7e0  vmovaps [rsp+0xE0], xmm15
00007d07b35dd7e9  sub rsp, 0x30
00007d07b35dd7ed  movaps [rsp], xmm6
00007d07b35dd7f1  movaps [rsp+0x10], xmm9
00007d07b35dd7f7  movaps [rsp+0x20], xmm7
00007d07b35dd7fc  lea rdi, [rsp]
00007d07b35dd800  mov esi, 0x00
00007d07b35dd805  mov rax, 0x5D0AA712D530
00007d07b35dd80f  call rax
00007d07b35dd811  movaps xmm6, [rsp]
00007d07b35dd815  add rsp, 0x30
00007d07b35dd819  vmovaps xmm0, [rsp]
00007d07b35dd81e  vmovaps xmm1, [rsp+0x10]
00007d07b35dd824  vmovaps xmm2, [rsp+0x20]
00007d07b35dd82a  vmovaps xmm3, [rsp+0x30]
00007d07b35dd830  vmovaps xmm4, [rsp+0x40]
00007d07b35dd836  vmovaps xmm5, [rsp+0x50]
00007d07b35dd83c  vmovaps xmm7, [rsp+0x60]
00007d07b35dd842  vmovaps xmm8, [rsp+0x70]
00007d07b35dd848  vmovaps xmm9, [rsp+0x80]
00007d07b35dd851  vmovaps xmm10, [rsp+0x90]
00007d07b35dd85a  vmovaps xmm11, [rsp+0xA0]
00007d07b35dd863  vmovaps xmm12, [rsp+0xB0]
00007d07b35dd86c  vmovaps xmm13, [rsp+0xC0]
00007d07b35dd875  vmovaps xmm14, [rsp+0xD0]
00007d07b35dd87e  vmovaps xmm15, [rsp+0xE0]
00007d07b35dd887  add rsp, 0xF0
00007d07b35dd88e  pop r11
00007d07b35dd890  pop r10
00007d07b35dd892  pop r9
00007d07b35dd894  pop r8
00007d07b35dd896  pop rsi
00007d07b35dd897  pop rdi
00007d07b35dd898  pop rdx
00007d07b35dd899  pop rcx
00007d07b35dd89a  pop rax
00007d07b35dd89b  add rsp, 0x08
00007d07b35dd89f  jmp 0x00007D07B35DBE5A
00007d07b35dd8a4  sub rsp, 0x08
00007d07b35dd8a8  push rax
00007d07b35dd8a9  push rcx
00007d07b35dd8aa  push rdx
00007d07b35dd8ab  push rdi
00007d07b35dd8ac  push rsi
00007d07b35dd8ad  push r8
00007d07b35dd8af  push r9
00007d07b35dd8b1  push r10
00007d07b35dd8b3  push r11
00007d07b35dd8b5  sub rsp, 0xF0
00007d07b35dd8bc  vmovaps [rsp], xmm0
00007d07b35dd8c1  vmovaps [rsp+0x10], xmm1
00007d07b35dd8c7  vmovaps [rsp+0x20], xmm2
00007d07b35dd8cd  vmovaps [rsp+0x30], xmm3
00007d07b35dd8d3  vmovaps [rsp+0x40], xmm4
00007d07b35dd8d9  vmovaps [rsp+0x50], xmm5
00007d07b35dd8df  vmovaps [rsp+0x60], xmm6
00007d07b35dd8e5  vmovaps [rsp+0x70], xmm8
00007d07b35dd8eb  vmovaps [rsp+0x80], xmm9
00007d07b35dd8f4  vmovaps [rsp+0x90], xmm10
00007d07b35dd8fd  vmovaps [rsp+0xA0], xmm11
00007d07b35dd906  vmovaps [rsp+0xB0], xmm12
00007d07b35dd90f  vmovaps [rsp+0xC0], xmm13
00007d07b35dd918  vmovaps [rsp+0xD0], xmm14
00007d07b35dd921  vmovaps [rsp+0xE0], xmm15
00007d07b35dd92a  sub rsp, 0x30
00007d07b35dd92e  movaps [rsp], xmm7
00007d07b35dd932  movaps [rsp+0x10], xmm4
00007d07b35dd937  movaps [rsp+0x20], xmm9
00007d07b35dd93d  lea rdi, [rsp]
00007d07b35dd941  mov esi, 0x00
00007d07b35dd946  mov rax, 0x5D0AA712D530
00007d07b35dd950  call rax
00007d07b35dd952  movaps xmm7, [rsp]
00007d07b35dd956  add rsp, 0x30
00007d07b35dd95a  vmovaps xmm0, [rsp]
00007d07b35dd95f  vmovaps xmm1, [rsp+0x10]
00007d07b35dd965  vmovaps xmm2, [rsp+0x20]
00007d07b35dd96b  vmovaps xmm3, [rsp+0x30]
00007d07b35dd971  vmovaps xmm4, [rsp+0x40]
00007d07b35dd977  vmovaps xmm5, [rsp+0x50]
00007d07b35dd97d  vmovaps xmm6, [rsp+0x60]
00007d07b35dd983  vmovaps xmm8, [rsp+0x70]
00007d07b35dd989  vmovaps xmm9, [rsp+0x80]
00007d07b35dd992  vmovaps xmm10, [rsp+0x90]
00007d07b35dd99b  vmovaps xmm11, [rsp+0xA0]
00007d07b35dd9a4  vmovaps xmm12, [rsp+0xB0]
00007d07b35dd9ad  vmovaps xmm13, [rsp+0xC0]
00007d07b35dd9b6  vmovaps xmm14, [rsp+0xD0]
00007d07b35dd9bf  vmovaps xmm15, [rsp+0xE0]
00007d07b35dd9c8  add rsp, 0xF0
00007d07b35dd9cf  pop r11
00007d07b35dd9d1  pop r10
00007d07b35dd9d3  pop r9
00007d07b35dd9d5  pop r8
00007d07b35dd9d7  pop rsi
00007d07b35dd9d8  pop rdi
00007d07b35dd9d9  pop rdx
00007d07b35dd9da  pop rcx
00007d07b35dd9db  pop rax
00007d07b35dd9dc  add rsp, 0x08
00007d07b35dd9e0  jmp 0x00007D07B35DBE87
00007d07b35dd9e5  sub rsp, 0x08
00007d07b35dd9e9  push rax
00007d07b35dd9ea  push rcx
00007d07b35dd9eb  push rdx
00007d07b35dd9ec  push rdi
00007d07b35dd9ed  push rsi
00007d07b35dd9ee  push r8
00007d07b35dd9f0  push r9
00007d07b35dd9f2  push r10
00007d07b35dd9f4  push r11
00007d07b35dd9f6  sub rsp, 0xF0
00007d07b35dd9fd  vmovaps [rsp], xmm0
00007d07b35dda02  vmovaps [rsp+0x10], xmm1
00007d07b35dda08  vmovaps [rsp+0x20], xmm2
00007d07b35dda0e  vmovaps [rsp+0x30], xmm3
00007d07b35dda14  vmovaps [rsp+0x40], xmm5
00007d07b35dda1a  vmovaps [rsp+0x50], xmm6
00007d07b35dda20  vmovaps [rsp+0x60], xmm7
00007d07b35dda26  vmovaps [rsp+0x70], xmm8
00007d07b35dda2c  vmovaps [rsp+0x80], xmm9
00007d07b35dda35  vmovaps [rsp+0x90], xmm10
00007d07b35dda3e  vmovaps [rsp+0xA0], xmm11
00007d07b35dda47  vmovaps [rsp+0xB0], xmm12
00007d07b35dda50  vmovaps [rsp+0xC0], xmm13
00007d07b35dda59  vmovaps [rsp+0xD0], xmm14
00007d07b35dda62  vmovaps [rsp+0xE0], xmm15
00007d07b35dda6b  sub rsp, 0x30
00007d07b35dda6f  movaps [rsp], xmm4
00007d07b35dda73  movaps [rsp+0x10], xmm15
00007d07b35dda79  movaps [rsp+0x20], xmm9
00007d07b35dda7f  lea rdi, [rsp]
00007d07b35dda83  mov esi, 0x00
00007d07b35dda88  mov rax, 0x5D0AA712D530
00007d07b35dda92  call rax
00007d07b35dda94  movaps xmm4, [rsp]
00007d07b35dda98  add rsp, 0x30
00007d07b35dda9c  vmovaps xmm0, [rsp]
00007d07b35ddaa1  vmovaps xmm1, [rsp+0x10]
00007d07b35ddaa7  vmovaps xmm2, [rsp+0x20]
00007d07b35ddaad  vmovaps xmm3, [rsp+0x30]
00007d07b35ddab3  vmovaps xmm5, [rsp+0x40]
00007d07b35ddab9  vmovaps xmm6, [rsp+0x50]
00007d07b35ddabf  vmovaps xmm7, [rsp+0x60]
00007d07b35ddac5  vmovaps xmm8, [rsp+0x70]
00007d07b35ddacb  vmovaps xmm9, [rsp+0x80]
00007d07b35ddad4  vmovaps xmm10, [rsp+0x90]
00007d07b35ddadd  vmovaps xmm11, [rsp+0xA0]
00007d07b35ddae6  vmovaps xmm12, [rsp+0xB0]
00007d07b35ddaef  vmovaps xmm13, [rsp+0xC0]
00007d07b35ddaf8  vmovaps xmm14, [rsp+0xD0]
00007d07b35ddb01  vmovaps xmm15, [rsp+0xE0]
00007d07b35ddb0a  add rsp, 0xF0
00007d07b35ddb11  pop r11
00007d07b35ddb13  pop r10
00007d07b35ddb15  pop r9
00007d07b35ddb17  pop r8
00007d07b35ddb19  pop rsi
00007d07b35ddb1a  pop rdi
00007d07b35ddb1b  pop rdx
00007d07b35ddb1c  pop rcx
00007d07b35ddb1d  pop rax
00007d07b35ddb1e  add rsp, 0x08
00007d07b35ddb22  jmp 0x00007D07B35DBEAC
00007d07b35ddb27  call 0x00007D07B34C4620
00007d07b35ddb2c  jmp 0x00007D07B35DBEB9
00007d07b35ddb31  sub rsp, 0x08
00007d07b35ddb35  push rax
00007d07b35ddb36  push rcx
00007d07b35ddb37  push rdx
00007d07b35ddb38  push rdi
00007d07b35ddb39  push rsi
00007d07b35ddb3a  push r8
00007d07b35ddb3c  push r9
00007d07b35ddb3e  push r10
00007d07b35ddb40  push r11
00007d07b35ddb42  sub rsp, 0xF0
00007d07b35ddb49  vmovaps [rsp], xmm0
00007d07b35ddb4e  vmovaps [rsp+0x10], xmm1
00007d07b35ddb54  vmovaps [rsp+0x20], xmm2
00007d07b35ddb5a  vmovaps [rsp+0x30], xmm4
00007d07b35ddb60  vmovaps [rsp+0x40], xmm5
00007d07b35ddb66  vmovaps [rsp+0x50], xmm6
00007d07b35ddb6c  vmovaps [rsp+0x60], xmm7
00007d07b35ddb72  vmovaps [rsp+0x70], xmm8
00007d07b35ddb78  vmovaps [rsp+0x80], xmm9
00007d07b35ddb81  vmovaps [rsp+0x90], xmm10
00007d07b35ddb8a  vmovaps [rsp+0xA0], xmm11
00007d07b35ddb93  vmovaps [rsp+0xB0], xmm12
00007d07b35ddb9c  vmovaps [rsp+0xC0], xmm13
00007d07b35ddba5  vmovaps [rsp+0xD0], xmm14
00007d07b35ddbae  vmovaps [rsp+0xE0], xmm15
00007d07b35ddbb7  sub rsp, 0x30
00007d07b35ddbbb  movaps [rsp], xmm3
00007d07b35ddbbf  movaps [rsp+0x10], xmm1
00007d07b35ddbc4  movaps [rsp+0x20], xmm9
00007d07b35ddbca  lea rdi, [rsp]
00007d07b35ddbce  mov esi, 0x00
00007d07b35ddbd3  mov rax, 0x5D0AA712D530
00007d07b35ddbdd  call rax
00007d07b35ddbdf  movaps xmm3, [rsp]
00007d07b35ddbe3  add rsp, 0x30
00007d07b35ddbe7  vmovaps xmm0, [rsp]
00007d07b35ddbec  vmovaps xmm1, [rsp+0x10]
00007d07b35ddbf2  vmovaps xmm2, [rsp+0x20]
00007d07b35ddbf8  vmovaps xmm4, [rsp+0x30]
00007d07b35ddbfe  vmovaps xmm5, [rsp+0x40]
00007d07b35ddc04  vmovaps xmm6, [rsp+0x50]
00007d07b35ddc0a  vmovaps xmm7, [rsp+0x60]
00007d07b35ddc10  vmovaps xmm8, [rsp+0x70]
00007d07b35ddc16  vmovaps xmm9, [rsp+0x80]
00007d07b35ddc1f  vmovaps xmm10, [rsp+0x90]
00007d07b35ddc28  vmovaps xmm11, [rsp+0xA0]
00007d07b35ddc31  vmovaps xmm12, [rsp+0xB0]
00007d07b35ddc3a  vmovaps xmm13, [rsp+0xC0]
00007d07b35ddc43  vmovaps xmm14, [rsp+0xD0]
00007d07b35ddc4c  vmovaps xmm15, [rsp+0xE0]
00007d07b35ddc55  add rsp, 0xF0
00007d07b35ddc5c  pop r11
00007d07b35ddc5e  pop r10
00007d07b35ddc60  pop r9
00007d07b35ddc62  pop r8
00007d07b35ddc64  pop rsi
00007d07b35ddc65  pop rdi
00007d07b35ddc66  pop rdx
00007d07b35ddc67  pop rcx
00007d07b35ddc68  pop rax
00007d07b35ddc69  add rsp, 0x08
00007d07b35ddc6d  jmp 0x00007D07B35DBEF6
00007d07b35ddc72  sub rsp, 0x08
00007d07b35ddc76  push rax
00007d07b35ddc77  push rcx
00007d07b35ddc78  push rdx
00007d07b35ddc79  push rdi
00007d07b35ddc7a  push rsi
00007d07b35ddc7b  push r8
00007d07b35ddc7d  push r9
00007d07b35ddc7f  push r10
00007d07b35ddc81  push r11
00007d07b35ddc83  sub rsp, 0xF0
00007d07b35ddc8a  vmovaps [rsp], xmm0
00007d07b35ddc8f  vmovaps [rsp+0x10], xmm2
00007d07b35ddc95  vmovaps [rsp+0x20], xmm3
00007d07b35ddc9b  vmovaps [rsp+0x30], xmm4
00007d07b35ddca1  vmovaps [rsp+0x40], xmm5
00007d07b35ddca7  vmovaps [rsp+0x50], xmm6
00007d07b35ddcad  vmovaps [rsp+0x60], xmm7
00007d07b35ddcb3  vmovaps [rsp+0x70], xmm8
00007d07b35ddcb9  vmovaps [rsp+0x80], xmm9
00007d07b35ddcc2  vmovaps [rsp+0x90], xmm10
00007d07b35ddccb  vmovaps [rsp+0xA0], xmm11
00007d07b35ddcd4  vmovaps [rsp+0xB0], xmm12
00007d07b35ddcdd  vmovaps [rsp+0xC0], xmm13
00007d07b35ddce6  vmovaps [rsp+0xD0], xmm14
00007d07b35ddcef  vmovaps [rsp+0xE0], xmm15
00007d07b35ddcf8  sub rsp, 0x30
00007d07b35ddcfc  movaps [rsp], xmm1
00007d07b35ddd00  movaps [rsp+0x10], xmm15
00007d07b35ddd06  movaps [rsp+0x20], xmm9
00007d07b35ddd0c  lea rdi, [rsp]
00007d07b35ddd10  mov esi, 0x00
00007d07b35ddd15  mov rax, 0x5D0AA712D530
00007d07b35ddd1f  call rax
00007d07b35ddd21  movaps xmm1, [rsp]
00007d07b35ddd25  add rsp, 0x30
00007d07b35ddd29  vmovaps xmm0, [rsp]
00007d07b35ddd2e  vmovaps xmm2, [rsp+0x10]
00007d07b35ddd34  vmovaps xmm3, [rsp+0x20]
00007d07b35ddd3a  vmovaps xmm4, [rsp+0x30]
00007d07b35ddd40  vmovaps xmm5, [rsp+0x40]
00007d07b35ddd46  vmovaps xmm6, [rsp+0x50]
00007d07b35ddd4c  vmovaps xmm7, [rsp+0x60]
00007d07b35ddd52  vmovaps xmm8, [rsp+0x70]
00007d07b35ddd58  vmovaps xmm9, [rsp+0x80]
00007d07b35ddd61  vmovaps xmm10, [rsp+0x90]
00007d07b35ddd6a  vmovaps xmm11, [rsp+0xA0]
00007d07b35ddd73  vmovaps xmm12, [rsp+0xB0]
00007d07b35ddd7c  vmovaps xmm13, [rsp+0xC0]
00007d07b35ddd85  vmovaps xmm14, [rsp+0xD0]
00007d07b35ddd8e  vmovaps xmm15, [rsp+0xE0]
00007d07b35ddd97  add rsp, 0xF0
00007d07b35ddd9e  pop r11
00007d07b35ddda0  pop r10
00007d07b35ddda2  pop r9
00007d07b35ddda4  pop r8
00007d07b35ddda6  pop rsi
00007d07b35ddda7  pop rdi
00007d07b35ddda8  pop rdx
00007d07b35ddda9  pop rcx
00007d07b35dddaa  pop rax
00007d07b35dddab  add rsp, 0x08
00007d07b35dddaf  jmp 0x00007D07B35DBF7E
00007d07b35dddb4  call 0x00007D07B34C4620
00007d07b35dddb9  jmp 0x00007D07B35DBF8B
00007d07b35dddbe  sub rsp, 0x08
00007d07b35dddc2  push rax
00007d07b35dddc3  push rcx
00007d07b35dddc4  push rdx
00007d07b35dddc5  push rdi
00007d07b35dddc6  push rsi
00007d07b35dddc7  push r8
00007d07b35dddc9  push r9
00007d07b35dddcb  push r10
00007d07b35dddcd  push r11
00007d07b35dddcf  sub rsp, 0xF0
00007d07b35dddd6  vmovaps [rsp], xmm0
00007d07b35ddddb  vmovaps [rsp+0x10], xmm2
00007d07b35ddde1  vmovaps [rsp+0x20], xmm3
00007d07b35ddde7  vmovaps [rsp+0x30], xmm4
00007d07b35ddded  vmovaps [rsp+0x40], xmm5
00007d07b35dddf3  vmovaps [rsp+0x50], xmm6
00007d07b35dddf9  vmovaps [rsp+0x60], xmm7
00007d07b35dddff  vmovaps [rsp+0x70], xmm8
00007d07b35dde05  vmovaps [rsp+0x80], xmm9
00007d07b35dde0e  vmovaps [rsp+0x90], xmm10
00007d07b35dde17  vmovaps [rsp+0xA0], xmm11
00007d07b35dde20  vmovaps [rsp+0xB0], xmm12
00007d07b35dde29  vmovaps [rsp+0xC0], xmm13
00007d07b35dde32  vmovaps [rsp+0xD0], xmm14
00007d07b35dde3b  vmovaps [rsp+0xE0], xmm15
00007d07b35dde44  sub rsp, 0x30
00007d07b35dde48  movaps [rsp], xmm1
00007d07b35dde4c  movaps [rsp+0x10], xmm5
00007d07b35dde51  movaps [rsp+0x20], xmm7
00007d07b35dde56  lea rdi, [rsp]
00007d07b35dde5a  mov esi, 0x00
00007d07b35dde5f  mov rax, 0x5D0AA712D530
00007d07b35dde69  call rax
00007d07b35dde6b  movaps xmm1, [rsp]
00007d07b35dde6f  add rsp, 0x30
00007d07b35dde73  vmovaps xmm0, [rsp]
00007d07b35dde78  vmovaps xmm2, [rsp+0x10]
00007d07b35dde7e  vmovaps xmm3, [rsp+0x20]
00007d07b35dde84  vmovaps xmm4, [rsp+0x30]
00007d07b35dde8a  vmovaps xmm5, [rsp+0x40]
00007d07b35dde90  vmovaps xmm6, [rsp+0x50]
00007d07b35dde96  vmovaps xmm7, [rsp+0x60]
00007d07b35dde9c  vmovaps xmm8, [rsp+0x70]
00007d07b35ddea2  vmovaps xmm9, [rsp+0x80]
00007d07b35ddeab  vmovaps xmm10, [rsp+0x90]
00007d07b35ddeb4  vmovaps xmm11, [rsp+0xA0]
00007d07b35ddebd  vmovaps xmm12, [rsp+0xB0]
00007d07b35ddec6  vmovaps xmm13, [rsp+0xC0]
00007d07b35ddecf  vmovaps xmm14, [rsp+0xD0]
00007d07b35dded8  vmovaps xmm15, [rsp+0xE0]
00007d07b35ddee1  add rsp, 0xF0
00007d07b35ddee8  pop r11
00007d07b35ddeea  pop r10
00007d07b35ddeec  pop r9
00007d07b35ddeee  pop r8
00007d07b35ddef0  pop rsi
00007d07b35ddef1  pop rdi
00007d07b35ddef2  pop rdx
00007d07b35ddef3  pop rcx
00007d07b35ddef4  pop rax
00007d07b35ddef5  add rsp, 0x08
00007d07b35ddef9  jmp 0x00007D07B35DC030
00007d07b35ddefe  sub rsp, 0x08
00007d07b35ddf02  push rax
00007d07b35ddf03  push rcx
00007d07b35ddf04  push rdx
00007d07b35ddf05  push rdi
00007d07b35ddf06  push rsi
00007d07b35ddf07  push r8
00007d07b35ddf09  push r9
00007d07b35ddf0b  push r10
00007d07b35ddf0d  push r11
00007d07b35ddf0f  sub rsp, 0xF0
00007d07b35ddf16  vmovaps [rsp], xmm0
00007d07b35ddf1b  vmovaps [rsp+0x10], xmm1
00007d07b35ddf21  vmovaps [rsp+0x20], xmm2
00007d07b35ddf27  vmovaps [rsp+0x30], xmm3
00007d07b35ddf2d  vmovaps [rsp+0x40], xmm4
00007d07b35ddf33  vmovaps [rsp+0x50], xmm5
00007d07b35ddf39  vmovaps [rsp+0x60], xmm6
00007d07b35ddf3f  vmovaps [rsp+0x70], xmm8
00007d07b35ddf45  vmovaps [rsp+0x80], xmm9
00007d07b35ddf4e  vmovaps [rsp+0x90], xmm10
00007d07b35ddf57  vmovaps [rsp+0xA0], xmm11
00007d07b35ddf60  vmovaps [rsp+0xB0], xmm12
00007d07b35ddf69  vmovaps [rsp+0xC0], xmm13
00007d07b35ddf72  vmovaps [rsp+0xD0], xmm14
00007d07b35ddf7b  vmovaps [rsp+0xE0], xmm15
00007d07b35ddf84  sub rsp, 0x30
00007d07b35ddf88  movaps [rsp], xmm7
00007d07b35ddf8c  movaps [rsp+0x10], xmm5
00007d07b35ddf91  movaps [rsp+0x20], xmm15
00007d07b35ddf97  lea rdi, [rsp]
00007d07b35ddf9b  mov esi, 0x00
00007d07b35ddfa0  mov rax, 0x5D0AA712D530
00007d07b35ddfaa  call rax
00007d07b35ddfac  movaps xmm7, [rsp]
00007d07b35ddfb0  add rsp, 0x30
00007d07b35ddfb4  vmovaps xmm0, [rsp]
00007d07b35ddfb9  vmovaps xmm1, [rsp+0x10]
00007d07b35ddfbf  vmovaps xmm2, [rsp+0x20]
00007d07b35ddfc5  vmovaps xmm3, [rsp+0x30]
00007d07b35ddfcb  vmovaps xmm4, [rsp+0x40]
00007d07b35ddfd1  vmovaps xmm5, [rsp+0x50]
00007d07b35ddfd7  vmovaps xmm6, [rsp+0x60]
00007d07b35ddfdd  vmovaps xmm8, [rsp+0x70]
00007d07b35ddfe3  vmovaps xmm9, [rsp+0x80]
00007d07b35ddfec  vmovaps xmm10, [rsp+0x90]
00007d07b35ddff5  vmovaps xmm11, [rsp+0xA0]
00007d07b35ddffe  vmovaps xmm12, [rsp+0xB0]
00007d07b35de007  vmovaps xmm13, [rsp+0xC0]
00007d07b35de010  vmovaps xmm14, [rsp+0xD0]
00007d07b35de019  vmovaps xmm15, [rsp+0xE0]
00007d07b35de022  add rsp, 0xF0
00007d07b35de029  pop r11
00007d07b35de02b  pop r10
00007d07b35de02d  pop r9
00007d07b35de02f  pop r8
00007d07b35de031  pop rsi
00007d07b35de032  pop rdi
00007d07b35de033  pop rdx
00007d07b35de034  pop rcx
00007d07b35de035  pop rax
00007d07b35de036  add rsp, 0x08
00007d07b35de03a  jmp 0x00007D07B35DC066
00007d07b35de03f  call 0x00007D07B34B52F0
00007d07b35de044  jmp 0x00007D07B35DC073
00007d07b35de049  sub rsp, 0x08
00007d07b35de04d  push rax
00007d07b35de04e  push rcx
00007d07b35de04f  push rdx
00007d07b35de050  push rdi
00007d07b35de051  push rsi
00007d07b35de052  push r8
00007d07b35de054  push r9
00007d07b35de056  push r10
00007d07b35de058  push r11
00007d07b35de05a  sub rsp, 0xF0
00007d07b35de061  vmovaps [rsp], xmm0
00007d07b35de066  vmovaps [rsp+0x10], xmm1
00007d07b35de06c  vmovaps [rsp+0x20], xmm2
00007d07b35de072  vmovaps [rsp+0x30], xmm3
00007d07b35de078  vmovaps [rsp+0x40], xmm4
00007d07b35de07e  vmovaps [rsp+0x50], xmm5
00007d07b35de084  vmovaps [rsp+0x60], xmm6
00007d07b35de08a  vmovaps [rsp+0x70], xmm7
00007d07b35de090  vmovaps [rsp+0x80], xmm8
00007d07b35de099  vmovaps [rsp+0x90], xmm9
00007d07b35de0a2  vmovaps [rsp+0xA0], xmm10
00007d07b35de0ab  vmovaps [rsp+0xB0], xmm11
00007d07b35de0b4  vmovaps [rsp+0xC0], xmm12
00007d07b35de0bd  vmovaps [rsp+0xD0], xmm13
00007d07b35de0c6  vmovaps [rsp+0xE0], xmm14
00007d07b35de0cf  sub rsp, 0x30
00007d07b35de0d3  movaps [rsp], xmm15
00007d07b35de0d8  movaps [rsp+0x10], xmm5
00007d07b35de0dd  movaps [rsp+0x20], xmm3
00007d07b35de0e2  lea rdi, [rsp]
00007d07b35de0e6  mov esi, 0x00
00007d07b35de0eb  mov rax, 0x5D0AA712D530
00007d07b35de0f5  call rax
00007d07b35de0f7  movaps xmm15, [rsp]
00007d07b35de0fc  add rsp, 0x30
00007d07b35de100  vmovaps xmm0, [rsp]
00007d07b35de105  vmovaps xmm1, [rsp+0x10]
00007d07b35de10b  vmovaps xmm2, [rsp+0x20]
00007d07b35de111  vmovaps xmm3, [rsp+0x30]
00007d07b35de117  vmovaps xmm4, [rsp+0x40]
00007d07b35de11d  vmovaps xmm5, [rsp+0x50]
00007d07b35de123  vmovaps xmm6, [rsp+0x60]
00007d07b35de129  vmovaps xmm7, [rsp+0x70]
00007d07b35de12f  vmovaps xmm8, [rsp+0x80]
00007d07b35de138  vmovaps xmm9, [rsp+0x90]
00007d07b35de141  vmovaps xmm10, [rsp+0xA0]
00007d07b35de14a  vmovaps xmm11, [rsp+0xB0]
00007d07b35de153  vmovaps xmm12, [rsp+0xC0]
00007d07b35de15c  vmovaps xmm13, [rsp+0xD0]
00007d07b35de165  vmovaps xmm14, [rsp+0xE0]
00007d07b35de16e  add rsp, 0xF0
00007d07b35de175  pop r11
00007d07b35de177  pop r10
00007d07b35de179  pop r9
00007d07b35de17b  pop r8
00007d07b35de17d  pop rsi
00007d07b35de17e  pop rdi
00007d07b35de17f  pop rdx
00007d07b35de180  pop rcx
00007d07b35de181  pop rax
00007d07b35de182  add rsp, 0x08
00007d07b35de186  jmp 0x00007D07B35DC099
00007d07b35de18b  sub rsp, 0x08
00007d07b35de18f  push rax
00007d07b35de190  push rcx
00007d07b35de191  push rdx
00007d07b35de192  push rdi
00007d07b35de193  push rsi
00007d07b35de194  push r8
00007d07b35de196  push r9
00007d07b35de198  push r10
00007d07b35de19a  push r11
00007d07b35de19c  sub rsp, 0xF0
00007d07b35de1a3  vmovaps [rsp], xmm0
00007d07b35de1a8  vmovaps [rsp+0x10], xmm2
00007d07b35de1ae  vmovaps [rsp+0x20], xmm3
00007d07b35de1b4  vmovaps [rsp+0x30], xmm4
00007d07b35de1ba  vmovaps [rsp+0x40], xmm5
00007d07b35de1c0  vmovaps [rsp+0x50], xmm6
00007d07b35de1c6  vmovaps [rsp+0x60], xmm7
00007d07b35de1cc  vmovaps [rsp+0x70], xmm8
00007d07b35de1d2  vmovaps [rsp+0x80], xmm9
00007d07b35de1db  vmovaps [rsp+0x90], xmm10
00007d07b35de1e4  vmovaps [rsp+0xA0], xmm11
00007d07b35de1ed  vmovaps [rsp+0xB0], xmm12
00007d07b35de1f6  vmovaps [rsp+0xC0], xmm13
00007d07b35de1ff  vmovaps [rsp+0xD0], xmm14
00007d07b35de208  vmovaps [rsp+0xE0], xmm15
00007d07b35de211  sub rsp, 0x30
00007d07b35de215  movaps [rsp], xmm1
00007d07b35de219  movaps [rsp+0x10], xmm5
00007d07b35de21e  movaps [rsp+0x20], xmm4
00007d07b35de223  lea rdi, [rsp]
00007d07b35de227  mov esi, 0x00
00007d07b35de22c  mov rax, 0x5D0AA712D530
00007d07b35de236  call rax
00007d07b35de238  movaps xmm1, [rsp]
00007d07b35de23c  add rsp, 0x30
00007d07b35de240  vmovaps xmm0, [rsp]
00007d07b35de245  vmovaps xmm2, [rsp+0x10]
00007d07b35de24b  vmovaps xmm3, [rsp+0x20]
00007d07b35de251  vmovaps xmm4, [rsp+0x30]
00007d07b35de257  vmovaps xmm5, [rsp+0x40]
00007d07b35de25d  vmovaps xmm6, [rsp+0x50]
00007d07b35de263  vmovaps xmm7, [rsp+0x60]
00007d07b35de269  vmovaps xmm8, [rsp+0x70]
00007d07b35de26f  vmovaps xmm9, [rsp+0x80]
00007d07b35de278  vmovaps xmm10, [rsp+0x90]
00007d07b35de281  vmovaps xmm11, [rsp+0xA0]
00007d07b35de28a  vmovaps xmm12, [rsp+0xB0]
00007d07b35de293  vmovaps xmm13, [rsp+0xC0]
00007d07b35de29c  vmovaps xmm14, [rsp+0xD0]
00007d07b35de2a5  vmovaps xmm15, [rsp+0xE0]
00007d07b35de2ae  add rsp, 0xF0
00007d07b35de2b5  pop r11
00007d07b35de2b7  pop r10
00007d07b35de2b9  pop r9
00007d07b35de2bb  pop r8
00007d07b35de2bd  pop rsi
00007d07b35de2be  pop rdi
00007d07b35de2bf  pop rdx
00007d07b35de2c0  pop rcx
00007d07b35de2c1  pop rax
00007d07b35de2c2  add rsp, 0x08
00007d07b35de2c6  jmp 0x00007D07B35DC0B9
00007d07b35de2cb  sub rsp, 0x08
00007d07b35de2cf  push rax
00007d07b35de2d0  push rcx
00007d07b35de2d1  push rdx
00007d07b35de2d2  push rdi
00007d07b35de2d3  push rsi
00007d07b35de2d4  push r8
00007d07b35de2d6  push r9
00007d07b35de2d8  push r10
00007d07b35de2da  push r11
00007d07b35de2dc  sub rsp, 0xF0
00007d07b35de2e3  vmovaps [rsp], xmm0
00007d07b35de2e8  vmovaps [rsp+0x10], xmm1
00007d07b35de2ee  vmovaps [rsp+0x20], xmm2
00007d07b35de2f4  vmovaps [rsp+0x30], xmm3
00007d07b35de2fa  vmovaps [rsp+0x40], xmm5
00007d07b35de300  vmovaps [rsp+0x50], xmm6
00007d07b35de306  vmovaps [rsp+0x60], xmm7
00007d07b35de30c  vmovaps [rsp+0x70], xmm8
00007d07b35de312  vmovaps [rsp+0x80], xmm9
00007d07b35de31b  vmovaps [rsp+0x90], xmm10
00007d07b35de324  vmovaps [rsp+0xA0], xmm11
00007d07b35de32d  vmovaps [rsp+0xB0], xmm12
00007d07b35de336  vmovaps [rsp+0xC0], xmm13
00007d07b35de33f  vmovaps [rsp+0xD0], xmm14
00007d07b35de348  vmovaps [rsp+0xE0], xmm15
00007d07b35de351  sub rsp, 0x30
00007d07b35de355  movaps [rsp], xmm4
00007d07b35de359  movaps [rsp+0x10], xmm3
00007d07b35de35e  movaps [rsp+0x20], xmm5
00007d07b35de363  lea rdi, [rsp]
00007d07b35de367  mov esi, 0x00
00007d07b35de36c  mov rax, 0x5D0AA712D530
00007d07b35de376  call rax
00007d07b35de378  movaps xmm4, [rsp]
00007d07b35de37c  add rsp, 0x30
00007d07b35de380  vmovaps xmm0, [rsp]
00007d07b35de385  vmovaps xmm1, [rsp+0x10]
00007d07b35de38b  vmovaps xmm2, [rsp+0x20]
00007d07b35de391  vmovaps xmm3, [rsp+0x30]
00007d07b35de397  vmovaps xmm5, [rsp+0x40]
00007d07b35de39d  vmovaps xmm6, [rsp+0x50]
00007d07b35de3a3  vmovaps xmm7, [rsp+0x60]
00007d07b35de3a9  vmovaps xmm8, [rsp+0x70]
00007d07b35de3af  vmovaps xmm9, [rsp+0x80]
00007d07b35de3b8  vmovaps xmm10, [rsp+0x90]
00007d07b35de3c1  vmovaps xmm11, [rsp+0xA0]
00007d07b35de3ca  vmovaps xmm12, [rsp+0xB0]
00007d07b35de3d3  vmovaps xmm13, [rsp+0xC0]
00007d07b35de3dc  vmovaps xmm14, [rsp+0xD0]
00007d07b35de3e5  vmovaps xmm15, [rsp+0xE0]
00007d07b35de3ee  add rsp, 0xF0
00007d07b35de3f5  pop r11
00007d07b35de3f7  pop r10
00007d07b35de3f9  pop r9
00007d07b35de3fb  pop r8
00007d07b35de3fd  pop rsi
00007d07b35de3fe  pop rdi
00007d07b35de3ff  pop rdx
00007d07b35de400  pop rcx
00007d07b35de401  pop rax
00007d07b35de402  add rsp, 0x08
00007d07b35de406  jmp 0x00007D07B35DC107
00007d07b35de40b  call 0x00007D07B34B52F0
00007d07b35de410  jmp 0x00007D07B35DC114
00007d07b35de415  sub rsp, 0x08
00007d07b35de419  push rax
00007d07b35de41a  push rcx
00007d07b35de41b  push rdx
00007d07b35de41c  push rdi
00007d07b35de41d  push rsi
00007d07b35de41e  push r8
00007d07b35de420  push r9
00007d07b35de422  push r10
00007d07b35de424  push r11
00007d07b35de426  sub rsp, 0xF0
00007d07b35de42d  vmovaps [rsp], xmm0
00007d07b35de432  vmovaps [rsp+0x10], xmm1
00007d07b35de438  vmovaps [rsp+0x20], xmm2
00007d07b35de43e  vmovaps [rsp+0x30], xmm3
00007d07b35de444  vmovaps [rsp+0x40], xmm4
00007d07b35de44a  vmovaps [rsp+0x50], xmm6
00007d07b35de450  vmovaps [rsp+0x60], xmm7
00007d07b35de456  vmovaps [rsp+0x70], xmm8
00007d07b35de45c  vmovaps [rsp+0x80], xmm9
00007d07b35de465  vmovaps [rsp+0x90], xmm10
00007d07b35de46e  vmovaps [rsp+0xA0], xmm11
00007d07b35de477  vmovaps [rsp+0xB0], xmm12
00007d07b35de480  vmovaps [rsp+0xC0], xmm13
00007d07b35de489  vmovaps [rsp+0xD0], xmm14
00007d07b35de492  vmovaps [rsp+0xE0], xmm15
00007d07b35de49b  sub rsp, 0x30
00007d07b35de49f  movaps [rsp], xmm5
00007d07b35de4a3  movaps [rsp+0x10], xmm6
00007d07b35de4a8  movaps [rsp+0x20], xmm3
00007d07b35de4ad  lea rdi, [rsp]
00007d07b35de4b1  mov esi, 0x00
00007d07b35de4b6  mov rax, 0x5D0AA712D530
00007d07b35de4c0  call rax
00007d07b35de4c2  movaps xmm5, [rsp]
00007d07b35de4c6  add rsp, 0x30
00007d07b35de4ca  vmovaps xmm0, [rsp]
00007d07b35de4cf  vmovaps xmm1, [rsp+0x10]
00007d07b35de4d5  vmovaps xmm2, [rsp+0x20]
00007d07b35de4db  vmovaps xmm3, [rsp+0x30]
00007d07b35de4e1  vmovaps xmm4, [rsp+0x40]
00007d07b35de4e7  vmovaps xmm6, [rsp+0x50]
00007d07b35de4ed  vmovaps xmm7, [rsp+0x60]
00007d07b35de4f3  vmovaps xmm8, [rsp+0x70]
00007d07b35de4f9  vmovaps xmm9, [rsp+0x80]
00007d07b35de502  vmovaps xmm10, [rsp+0x90]
00007d07b35de50b  vmovaps xmm11, [rsp+0xA0]
00007d07b35de514  vmovaps xmm12, [rsp+0xB0]
00007d07b35de51d  vmovaps xmm13, [rsp+0xC0]
00007d07b35de526  vmovaps xmm14, [rsp+0xD0]
00007d07b35de52f  vmovaps xmm15, [rsp+0xE0]
00007d07b35de538  add rsp, 0xF0
00007d07b35de53f  pop r11
00007d07b35de541  pop r10
00007d07b35de543  pop r9
00007d07b35de545  pop r8
00007d07b35de547  pop rsi
00007d07b35de548  pop rdi
00007d07b35de549  pop rdx
00007d07b35de54a  pop rcx
00007d07b35de54b  pop rax
00007d07b35de54c  add rsp, 0x08
00007d07b35de550  jmp 0x00007D07B35DC13A
00007d07b35de555  sub rsp, 0x08
00007d07b35de559  push rax
00007d07b35de55a  push rcx
00007d07b35de55b  push rdx
00007d07b35de55c  push rdi
00007d07b35de55d  push rsi
00007d07b35de55e  push r8
00007d07b35de560  push r9
00007d07b35de562  push r10
00007d07b35de564  push r11
00007d07b35de566  sub rsp, 0xF0
00007d07b35de56d  vmovaps [rsp], xmm0
00007d07b35de572  vmovaps [rsp+0x10], xmm1
00007d07b35de578  vmovaps [rsp+0x20], xmm2
00007d07b35de57e  vmovaps [rsp+0x30], xmm3
00007d07b35de584  vmovaps [rsp+0x40], xmm4
00007d07b35de58a  vmovaps [rsp+0x50], xmm5
00007d07b35de590  vmovaps [rsp+0x60], xmm7
00007d07b35de596  vmovaps [rsp+0x70], xmm8
00007d07b35de59c  vmovaps [rsp+0x80], xmm9
00007d07b35de5a5  vmovaps [rsp+0x90], xmm10
00007d07b35de5ae  vmovaps [rsp+0xA0], xmm11
00007d07b35de5b7  vmovaps [rsp+0xB0], xmm12
00007d07b35de5c0  vmovaps [rsp+0xC0], xmm13
00007d07b35de5c9  vmovaps [rsp+0xD0], xmm14
00007d07b35de5d2  vmovaps [rsp+0xE0], xmm15
00007d07b35de5db  sub rsp, 0x30
00007d07b35de5df  movaps [rsp], xmm6
00007d07b35de5e3  movaps [rsp+0x10], xmm9
00007d07b35de5e9  movaps [rsp+0x20], xmm1
00007d07b35de5ee  lea rdi, [rsp]
00007d07b35de5f2  mov esi, 0x00
00007d07b35de5f7  mov rax, 0x5D0AA712D530
00007d07b35de601  call rax
00007d07b35de603  movaps xmm6, [rsp]
00007d07b35de607  add rsp, 0x30
00007d07b35de60b  vmovaps xmm0, [rsp]
00007d07b35de610  vmovaps xmm1, [rsp+0x10]
00007d07b35de616  vmovaps xmm2, [rsp+0x20]
00007d07b35de61c  vmovaps xmm3, [rsp+0x30]
00007d07b35de622  vmovaps xmm4, [rsp+0x40]
00007d07b35de628  vmovaps xmm5, [rsp+0x50]
00007d07b35de62e  vmovaps xmm7, [rsp+0x60]
00007d07b35de634  vmovaps xmm8, [rsp+0x70]
00007d07b35de63a  vmovaps xmm9, [rsp+0x80]
00007d07b35de643  vmovaps xmm10, [rsp+0x90]
00007d07b35de64c  vmovaps xmm11, [rsp+0xA0]
00007d07b35de655  vmovaps xmm12, [rsp+0xB0]
00007d07b35de65e  vmovaps xmm13, [rsp+0xC0]
00007d07b35de667  vmovaps xmm14, [rsp+0xD0]
00007d07b35de670  vmovaps xmm15, [rsp+0xE0]
00007d07b35de679  add rsp, 0xF0
00007d07b35de680  pop r11
00007d07b35de682  pop r10
00007d07b35de684  pop r9
00007d07b35de686  pop r8
00007d07b35de688  pop rsi
00007d07b35de689  pop rdi
00007d07b35de68a  pop rdx
00007d07b35de68b  pop rcx
00007d07b35de68c  pop rax
00007d07b35de68d  add rsp, 0x08
00007d07b35de691  jmp 0x00007D07B35DC15E
00007d07b35de696  sub rsp, 0x08
00007d07b35de69a  push rax
00007d07b35de69b  push rcx
00007d07b35de69c  push rdx
00007d07b35de69d  push rdi
00007d07b35de69e  push rsi
00007d07b35de69f  push r8
00007d07b35de6a1  push r9
00007d07b35de6a3  push r10
00007d07b35de6a5  push r11
00007d07b35de6a7  sub rsp, 0xF0
00007d07b35de6ae  vmovaps [rsp], xmm0
00007d07b35de6b3  vmovaps [rsp+0x10], xmm1
00007d07b35de6b9  vmovaps [rsp+0x20], xmm2
00007d07b35de6bf  vmovaps [rsp+0x30], xmm3
00007d07b35de6c5  vmovaps [rsp+0x40], xmm4
00007d07b35de6cb  vmovaps [rsp+0x50], xmm5
00007d07b35de6d1  vmovaps [rsp+0x60], xmm6
00007d07b35de6d7  vmovaps [rsp+0x70], xmm7
00007d07b35de6dd  vmovaps [rsp+0x80], xmm8
00007d07b35de6e6  vmovaps [rsp+0x90], xmm10
00007d07b35de6ef  vmovaps [rsp+0xA0], xmm11
00007d07b35de6f8  vmovaps [rsp+0xB0], xmm12
00007d07b35de701  vmovaps [rsp+0xC0], xmm13
00007d07b35de70a  vmovaps [rsp+0xD0], xmm14
00007d07b35de713  vmovaps [rsp+0xE0], xmm15
00007d07b35de71c  sub rsp, 0x30
00007d07b35de720  movaps [rsp], xmm9
00007d07b35de725  movaps [rsp+0x10], xmm3
00007d07b35de72a  movaps [rsp+0x20], xmm1
00007d07b35de72f  lea rdi, [rsp]
00007d07b35de733  mov esi, 0x00
00007d07b35de738  mov rax, 0x5D0AA712D530
00007d07b35de742  call rax
00007d07b35de744  movaps xmm9, [rsp]
00007d07b35de749  add rsp, 0x30
00007d07b35de74d  vmovaps xmm0, [rsp]
00007d07b35de752  vmovaps xmm1, [rsp+0x10]
00007d07b35de758  vmovaps xmm2, [rsp+0x20]
00007d07b35de75e  vmovaps xmm3, [rsp+0x30]
00007d07b35de764  vmovaps xmm4, [rsp+0x40]
00007d07b35de76a  vmovaps xmm5, [rsp+0x50]
00007d07b35de770  vmovaps xmm6, [rsp+0x60]
00007d07b35de776  vmovaps xmm7, [rsp+0x70]
00007d07b35de77c  vmovaps xmm8, [rsp+0x80]
00007d07b35de785  vmovaps xmm10, [rsp+0x90]
00007d07b35de78e  vmovaps xmm11, [rsp+0xA0]
00007d07b35de797  vmovaps xmm12, [rsp+0xB0]
00007d07b35de7a0  vmovaps xmm13, [rsp+0xC0]
00007d07b35de7a9  vmovaps xmm14, [rsp+0xD0]
00007d07b35de7b2  vmovaps xmm15, [rsp+0xE0]
00007d07b35de7bb  add rsp, 0xF0
00007d07b35de7c2  pop r11
00007d07b35de7c4  pop r10
00007d07b35de7c6  pop r9
00007d07b35de7c8  pop r8
00007d07b35de7ca  pop rsi
00007d07b35de7cb  pop rdi
00007d07b35de7cc  pop rdx
00007d07b35de7cd  pop rcx
00007d07b35de7ce  pop rax
00007d07b35de7cf  add rsp, 0x08
00007d07b35de7d3  jmp 0x00007D07B35DC1AA
00007d07b35de7d8  call 0x00007D07B34B52F0
00007d07b35de7dd  jmp 0x00007D07B35DC1B7
00007d07b35de7e2  sub rsp, 0x08
00007d07b35de7e6  push rax
00007d07b35de7e7  push rcx
00007d07b35de7e8  push rdx
00007d07b35de7e9  push rdi
00007d07b35de7ea  push rsi
00007d07b35de7eb  push r8
00007d07b35de7ed  push r9
00007d07b35de7ef  push r10
00007d07b35de7f1  push r11
00007d07b35de7f3  sub rsp, 0xF0
00007d07b35de7fa  vmovaps [rsp], xmm0
00007d07b35de7ff  vmovaps [rsp+0x10], xmm1
00007d07b35de805  vmovaps [rsp+0x20], xmm2
00007d07b35de80b  vmovaps [rsp+0x30], xmm3
00007d07b35de811  vmovaps [rsp+0x40], xmm4
00007d07b35de817  vmovaps [rsp+0x50], xmm5
00007d07b35de81d  vmovaps [rsp+0x60], xmm6
00007d07b35de823  vmovaps [rsp+0x70], xmm7
00007d07b35de829  vmovaps [rsp+0x80], xmm8
00007d07b35de832  vmovaps [rsp+0x90], xmm9
00007d07b35de83b  vmovaps [rsp+0xA0], xmm10
00007d07b35de844  vmovaps [rsp+0xB0], xmm11
00007d07b35de84d  vmovaps [rsp+0xC0], xmm12
00007d07b35de856  vmovaps [rsp+0xD0], xmm13
00007d07b35de85f  vmovaps [rsp+0xE0], xmm14
00007d07b35de868  sub rsp, 0x30
00007d07b35de86c  movaps [rsp], xmm15
00007d07b35de871  movaps [rsp+0x10], xmm3
00007d07b35de876  movaps [rsp+0x20], xmm7
00007d07b35de87b  lea rdi, [rsp]
00007d07b35de87f  mov esi, 0x00
00007d07b35de884  mov rax, 0x5D0AA712D530
00007d07b35de88e  call rax
00007d07b35de890  movaps xmm15, [rsp]
00007d07b35de895  add rsp, 0x30
00007d07b35de899  vmovaps xmm0, [rsp]
00007d07b35de89e  vmovaps xmm1, [rsp+0x10]
00007d07b35de8a4  vmovaps xmm2, [rsp+0x20]
00007d07b35de8aa  vmovaps xmm3, [rsp+0x30]
00007d07b35de8b0  vmovaps xmm4, [rsp+0x40]
00007d07b35de8b6  vmovaps xmm5, [rsp+0x50]
00007d07b35de8bc  vmovaps xmm6, [rsp+0x60]
00007d07b35de8c2  vmovaps xmm7, [rsp+0x70]
00007d07b35de8c8  vmovaps xmm8, [rsp+0x80]
00007d07b35de8d1  vmovaps xmm9, [rsp+0x90]
00007d07b35de8da  vmovaps xmm10, [rsp+0xA0]
00007d07b35de8e3  vmovaps xmm11, [rsp+0xB0]
00007d07b35de8ec  vmovaps xmm12, [rsp+0xC0]
00007d07b35de8f5  vmovaps xmm13, [rsp+0xD0]
00007d07b35de8fe  vmovaps xmm14, [rsp+0xE0]
00007d07b35de907  add rsp, 0xF0
00007d07b35de90e  pop r11
00007d07b35de910  pop r10
00007d07b35de912  pop r9
00007d07b35de914  pop r8
00007d07b35de916  pop rsi
00007d07b35de917  pop rdi
00007d07b35de918  pop rdx
00007d07b35de919  pop rcx
00007d07b35de91a  pop rax
00007d07b35de91b  add rsp, 0x08
00007d07b35de91f  jmp 0x00007D07B35DC1E3
00007d07b35de924  sub rsp, 0x08
00007d07b35de928  push rax
00007d07b35de929  push rcx
00007d07b35de92a  push rdx
00007d07b35de92b  push rdi
00007d07b35de92c  push rsi
00007d07b35de92d  push r8
00007d07b35de92f  push r9
00007d07b35de931  push r10
00007d07b35de933  push r11
00007d07b35de935  sub rsp, 0xF0
00007d07b35de93c  vmovaps [rsp], xmm0
00007d07b35de941  vmovaps [rsp+0x10], xmm1
00007d07b35de947  vmovaps [rsp+0x20], xmm2
00007d07b35de94d  vmovaps [rsp+0x30], xmm4
00007d07b35de953  vmovaps [rsp+0x40], xmm5
00007d07b35de959  vmovaps [rsp+0x50], xmm6
00007d07b35de95f  vmovaps [rsp+0x60], xmm7
00007d07b35de965  vmovaps [rsp+0x70], xmm8
00007d07b35de96b  vmovaps [rsp+0x80], xmm9
00007d07b35de974  vmovaps [rsp+0x90], xmm10
00007d07b35de97d  vmovaps [rsp+0xA0], xmm11
00007d07b35de986  vmovaps [rsp+0xB0], xmm12
00007d07b35de98f  vmovaps [rsp+0xC0], xmm13
00007d07b35de998  vmovaps [rsp+0xD0], xmm14
00007d07b35de9a1  vmovaps [rsp+0xE0], xmm15
00007d07b35de9aa  sub rsp, 0x30
00007d07b35de9ae  movaps [rsp], xmm3
00007d07b35de9b2  movaps [rsp+0x10], xmm1
00007d07b35de9b7  movaps [rsp+0x20], xmm15
00007d07b35de9bd  lea rdi, [rsp]
00007d07b35de9c1  mov esi, 0x00
00007d07b35de9c6  mov rax, 0x5D0AA712D530
00007d07b35de9d0  call rax
00007d07b35de9d2  movaps xmm3, [rsp]
00007d07b35de9d6  add rsp, 0x30
00007d07b35de9da  vmovaps xmm0, [rsp]
00007d07b35de9df  vmovaps xmm1, [rsp+0x10]
00007d07b35de9e5  vmovaps xmm2, [rsp+0x20]
00007d07b35de9eb  vmovaps xmm4, [rsp+0x30]
00007d07b35de9f1  vmovaps xmm5, [rsp+0x40]
00007d07b35de9f7  vmovaps xmm6, [rsp+0x50]
00007d07b35de9fd  vmovaps xmm7, [rsp+0x60]
00007d07b35dea03  vmovaps xmm8, [rsp+0x70]
00007d07b35dea09  vmovaps xmm9, [rsp+0x80]
00007d07b35dea12  vmovaps xmm10, [rsp+0x90]
00007d07b35dea1b  vmovaps xmm11, [rsp+0xA0]
00007d07b35dea24  vmovaps xmm12, [rsp+0xB0]
00007d07b35dea2d  vmovaps xmm13, [rsp+0xC0]
00007d07b35dea36  vmovaps xmm14, [rsp+0xD0]
00007d07b35dea3f  vmovaps xmm15, [rsp+0xE0]
00007d07b35dea48  add rsp, 0xF0
00007d07b35dea4f  pop r11
00007d07b35dea51  pop r10
00007d07b35dea53  pop r9
00007d07b35dea55  pop r8
00007d07b35dea57  pop rsi
00007d07b35dea58  pop rdi
00007d07b35dea59  pop rdx
00007d07b35dea5a  pop rcx
00007d07b35dea5b  pop rax
00007d07b35dea5c  add rsp, 0x08
00007d07b35dea60  jmp 0x00007D07B35DC272
00007d07b35dea65  call 0x00007D07B34B52F0
00007d07b35dea6a  jmp 0x00007D07B35DC27C
00007d07b35dea6f  sub rsp, 0x08
00007d07b35dea73  push rax
00007d07b35dea74  push rcx
00007d07b35dea75  push rdx
00007d07b35dea76  push rdi
00007d07b35dea77  push rsi
00007d07b35dea78  push r8
00007d07b35dea7a  push r9
00007d07b35dea7c  push r10
00007d07b35dea7e  push r11
00007d07b35dea80  sub rsp, 0xF0
00007d07b35dea87  vmovaps [rsp], xmm0
00007d07b35dea8c  vmovaps [rsp+0x10], xmm1
00007d07b35dea92  vmovaps [rsp+0x20], xmm2
00007d07b35dea98  vmovaps [rsp+0x30], xmm3
00007d07b35dea9e  vmovaps [rsp+0x40], xmm4
00007d07b35deaa4  vmovaps [rsp+0x50], xmm5
00007d07b35deaaa  vmovaps [rsp+0x60], xmm6
00007d07b35deab0  vmovaps [rsp+0x70], xmm7
00007d07b35deab6  vmovaps [rsp+0x80], xmm8
00007d07b35deabf  vmovaps [rsp+0x90], xmm9
00007d07b35deac8  vmovaps [rsp+0xA0], xmm10
00007d07b35dead1  vmovaps [rsp+0xB0], xmm11
00007d07b35deada  vmovaps [rsp+0xC0], xmm12
00007d07b35deae3  vmovaps [rsp+0xD0], xmm13
00007d07b35deaec  vmovaps [rsp+0xE0], xmm14
00007d07b35deaf5  sub rsp, 0x30
00007d07b35deaf9  movaps [rsp], xmm15
00007d07b35deafe  movaps [rsp+0x10], xmm14
00007d07b35deb04  movaps [rsp+0x20], xmm4
00007d07b35deb09  lea rdi, [rsp]
00007d07b35deb0d  mov esi, 0x00
00007d07b35deb12  mov rax, 0x5D0AA712D530
00007d07b35deb1c  call rax
00007d07b35deb1e  movaps xmm15, [rsp]
00007d07b35deb23  add rsp, 0x30
00007d07b35deb27  vmovaps xmm0, [rsp]
00007d07b35deb2c  vmovaps xmm1, [rsp+0x10]
00007d07b35deb32  vmovaps xmm2, [rsp+0x20]
00007d07b35deb38  vmovaps xmm3, [rsp+0x30]
00007d07b35deb3e  vmovaps xmm4, [rsp+0x40]
00007d07b35deb44  vmovaps xmm5, [rsp+0x50]
00007d07b35deb4a  vmovaps xmm6, [rsp+0x60]
00007d07b35deb50  vmovaps xmm7, [rsp+0x70]
00007d07b35deb56  vmovaps xmm8, [rsp+0x80]
00007d07b35deb5f  vmovaps xmm9, [rsp+0x90]
00007d07b35deb68  vmovaps xmm10, [rsp+0xA0]
00007d07b35deb71  vmovaps xmm11, [rsp+0xB0]
00007d07b35deb7a  vmovaps xmm12, [rsp+0xC0]
00007d07b35deb83  vmovaps xmm13, [rsp+0xD0]
00007d07b35deb8c  vmovaps xmm14, [rsp+0xE0]
00007d07b35deb95  add rsp, 0xF0
00007d07b35deb9c  pop r11
00007d07b35deb9e  pop r10
00007d07b35deba0  pop r9
00007d07b35deba2  pop r8
00007d07b35deba4  pop rsi
00007d07b35deba5  pop rdi
00007d07b35deba6  pop rdx
00007d07b35deba7  pop rcx
00007d07b35deba8  pop rax
00007d07b35deba9  add rsp, 0x08
00007d07b35debad  jmp 0x00007D07B35DC2AA
00007d07b35debb2  sub rsp, 0x08
00007d07b35debb6  push rax
00007d07b35debb7  push rcx
00007d07b35debb8  push rdx
00007d07b35debb9  push rdi
00007d07b35debba  push rsi
00007d07b35debbb  push r8
00007d07b35debbd  push r9
00007d07b35debbf  push r10
00007d07b35debc1  push r11
00007d07b35debc3  sub rsp, 0xF0
00007d07b35debca  vmovaps [rsp], xmm0
00007d07b35debcf  vmovaps [rsp+0x10], xmm1
00007d07b35debd5  vmovaps [rsp+0x20], xmm2
00007d07b35debdb  vmovaps [rsp+0x30], xmm3
00007d07b35debe1  vmovaps [rsp+0x40], xmm4
00007d07b35debe7  vmovaps [rsp+0x50], xmm5
00007d07b35debed  vmovaps [rsp+0x60], xmm6
00007d07b35debf3  vmovaps [rsp+0x70], xmm7
00007d07b35debf9  vmovaps [rsp+0x80], xmm8
00007d07b35dec02  vmovaps [rsp+0x90], xmm9
00007d07b35dec0b  vmovaps [rsp+0xA0], xmm10
00007d07b35dec14  vmovaps [rsp+0xB0], xmm11
00007d07b35dec1d  vmovaps [rsp+0xC0], xmm12
00007d07b35dec26  vmovaps [rsp+0xD0], xmm13
00007d07b35dec2f  vmovaps [rsp+0xE0], xmm15
00007d07b35dec38  sub rsp, 0x30
00007d07b35dec3c  movaps [rsp], xmm14
00007d07b35dec41  movaps [rsp+0x10], xmm2
00007d07b35dec46  movaps [rsp+0x20], xmm1
00007d07b35dec4b  lea rdi, [rsp]
00007d07b35dec4f  mov esi, 0x00
00007d07b35dec54  mov rax, 0x5D0AA712D530
00007d07b35dec5e  call rax
00007d07b35dec60  movaps xmm14, [rsp]
00007d07b35dec65  add rsp, 0x30
00007d07b35dec69  vmovaps xmm0, [rsp]
00007d07b35dec6e  vmovaps xmm1, [rsp+0x10]
00007d07b35dec74  vmovaps xmm2, [rsp+0x20]
00007d07b35dec7a  vmovaps xmm3, [rsp+0x30]
00007d07b35dec80  vmovaps xmm4, [rsp+0x40]
00007d07b35dec86  vmovaps xmm5, [rsp+0x50]
00007d07b35dec8c  vmovaps xmm6, [rsp+0x60]
00007d07b35dec92  vmovaps xmm7, [rsp+0x70]
00007d07b35dec98  vmovaps xmm8, [rsp+0x80]
00007d07b35deca1  vmovaps xmm9, [rsp+0x90]
00007d07b35decaa  vmovaps xmm10, [rsp+0xA0]
00007d07b35decb3  vmovaps xmm11, [rsp+0xB0]
00007d07b35decbc  vmovaps xmm12, [rsp+0xC0]
00007d07b35decc5  vmovaps xmm13, [rsp+0xD0]
00007d07b35decce  vmovaps xmm15, [rsp+0xE0]
00007d07b35decd7  add rsp, 0xF0
00007d07b35decde  pop r11
00007d07b35dece0  pop r10
00007d07b35dece2  pop r9
00007d07b35dece4  pop r8
00007d07b35dece6  pop rsi
00007d07b35dece7  pop rdi
00007d07b35dece8  pop rdx
00007d07b35dece9  pop rcx
00007d07b35decea  pop rax
00007d07b35deceb  add rsp, 0x08
00007d07b35decef  jmp 0x00007D07B35DC2D0
00007d07b35decf4  sub rsp, 0x08
00007d07b35decf8  push rax
00007d07b35decf9  push rcx
00007d07b35decfa  push rdx
00007d07b35decfb  push rdi
00007d07b35decfc  push rsi
00007d07b35decfd  push r8
00007d07b35decff  push r9
00007d07b35ded01  push r10
00007d07b35ded03  push r11
00007d07b35ded05  sub rsp, 0xF0
00007d07b35ded0c  vmovaps [rsp], xmm0
00007d07b35ded11  vmovaps [rsp+0x10], xmm2
00007d07b35ded17  vmovaps [rsp+0x20], xmm3
00007d07b35ded1d  vmovaps [rsp+0x30], xmm4
00007d07b35ded23  vmovaps [rsp+0x40], xmm5
00007d07b35ded29  vmovaps [rsp+0x50], xmm6
00007d07b35ded2f  vmovaps [rsp+0x60], xmm7
00007d07b35ded35  vmovaps [rsp+0x70], xmm8
00007d07b35ded3b  vmovaps [rsp+0x80], xmm9
00007d07b35ded44  vmovaps [rsp+0x90], xmm10
00007d07b35ded4d  vmovaps [rsp+0xA0], xmm11
00007d07b35ded56  vmovaps [rsp+0xB0], xmm12
00007d07b35ded5f  vmovaps [rsp+0xC0], xmm13
00007d07b35ded68  vmovaps [rsp+0xD0], xmm14
00007d07b35ded71  vmovaps [rsp+0xE0], xmm15
00007d07b35ded7a  sub rsp, 0x30
00007d07b35ded7e  movaps [rsp], xmm1
00007d07b35ded82  movaps [rsp+0x10], xmm4
00007d07b35ded87  movaps [rsp+0x20], xmm9
00007d07b35ded8d  lea rdi, [rsp]
00007d07b35ded91  mov esi, 0x00
00007d07b35ded96  mov rax, 0x5D0AA712D530
00007d07b35deda0  call rax
00007d07b35deda2  movaps xmm1, [rsp]
00007d07b35deda6  add rsp, 0x30
00007d07b35dedaa  vmovaps xmm0, [rsp]
00007d07b35dedaf  vmovaps xmm2, [rsp+0x10]
00007d07b35dedb5  vmovaps xmm3, [rsp+0x20]
00007d07b35dedbb  vmovaps xmm4, [rsp+0x30]
00007d07b35dedc1  vmovaps xmm5, [rsp+0x40]
00007d07b35dedc7  vmovaps xmm6, [rsp+0x50]
00007d07b35dedcd  vmovaps xmm7, [rsp+0x60]
00007d07b35dedd3  vmovaps xmm8, [rsp+0x70]
00007d07b35dedd9  vmovaps xmm9, [rsp+0x80]
00007d07b35dede2  vmovaps xmm10, [rsp+0x90]
00007d07b35dedeb  vmovaps xmm11, [rsp+0xA0]
00007d07b35dedf4  vmovaps xmm12, [rsp+0xB0]
00007d07b35dedfd  vmovaps xmm13, [rsp+0xC0]
00007d07b35dee06  vmovaps xmm14, [rsp+0xD0]
00007d07b35dee0f  vmovaps xmm15, [rsp+0xE0]
00007d07b35dee18  add rsp, 0xF0
00007d07b35dee1f  pop r11
00007d07b35dee21  pop r10
00007d07b35dee23  pop r9
00007d07b35dee25  pop r8
00007d07b35dee27  pop rsi
00007d07b35dee28  pop rdi
00007d07b35dee29  pop rdx
00007d07b35dee2a  pop rcx
00007d07b35dee2b  pop rax
00007d07b35dee2c  add rsp, 0x08
00007d07b35dee30  jmp 0x00007D07B35DC2EE
00007d07b35dee35  sub rsp, 0x08
00007d07b35dee39  push rax
00007d07b35dee3a  push rcx
00007d07b35dee3b  push rdx
00007d07b35dee3c  push rdi
00007d07b35dee3d  push rsi
00007d07b35dee3e  push r8
00007d07b35dee40  push r9
00007d07b35dee42  push r10
00007d07b35dee44  push r11
00007d07b35dee46  sub rsp, 0xF0
00007d07b35dee4d  vmovaps [rsp], xmm0
00007d07b35dee52  vmovaps [rsp+0x10], xmm1
00007d07b35dee58  vmovaps [rsp+0x20], xmm2
00007d07b35dee5e  vmovaps [rsp+0x30], xmm3
00007d07b35dee64  vmovaps [rsp+0x40], xmm5
00007d07b35dee6a  vmovaps [rsp+0x50], xmm6
00007d07b35dee70  vmovaps [rsp+0x60], xmm7
00007d07b35dee76  vmovaps [rsp+0x70], xmm8
00007d07b35dee7c  vmovaps [rsp+0x80], xmm9
00007d07b35dee85  vmovaps [rsp+0x90], xmm10
00007d07b35dee8e  vmovaps [rsp+0xA0], xmm11
00007d07b35dee97  vmovaps [rsp+0xB0], xmm12
00007d07b35deea0  vmovaps [rsp+0xC0], xmm13
00007d07b35deea9  vmovaps [rsp+0xD0], xmm14
00007d07b35deeb2  vmovaps [rsp+0xE0], xmm15
00007d07b35deebb  sub rsp, 0x30
00007d07b35deebf  movaps [rsp], xmm4
00007d07b35deec3  movaps [rsp+0x10], xmm2
00007d07b35deec8  movaps [rsp+0x20], xmm9
00007d07b35deece  lea rdi, [rsp]
00007d07b35deed2  mov esi, 0x00
00007d07b35deed7  mov rax, 0x5D0AA712D530
00007d07b35deee1  call rax
00007d07b35deee3  movaps xmm4, [rsp]
00007d07b35deee7  add rsp, 0x30
00007d07b35deeeb  vmovaps xmm0, [rsp]
00007d07b35deef0  vmovaps xmm1, [rsp+0x10]
00007d07b35deef6  vmovaps xmm2, [rsp+0x20]
00007d07b35deefc  vmovaps xmm3, [rsp+0x30]
00007d07b35def02  vmovaps xmm5, [rsp+0x40]
00007d07b35def08  vmovaps xmm6, [rsp+0x50]
00007d07b35def0e  vmovaps xmm7, [rsp+0x60]
00007d07b35def14  vmovaps xmm8, [rsp+0x70]
00007d07b35def1a  vmovaps xmm9, [rsp+0x80]
00007d07b35def23  vmovaps xmm10, [rsp+0x90]
00007d07b35def2c  vmovaps xmm11, [rsp+0xA0]
00007d07b35def35  vmovaps xmm12, [rsp+0xB0]
00007d07b35def3e  vmovaps xmm13, [rsp+0xC0]
00007d07b35def47  vmovaps xmm14, [rsp+0xD0]
00007d07b35def50  vmovaps xmm15, [rsp+0xE0]
00007d07b35def59  add rsp, 0xF0
00007d07b35def60  pop r11
00007d07b35def62  pop r10
00007d07b35def64  pop r9
00007d07b35def66  pop r8
00007d07b35def68  pop rsi
00007d07b35def69  pop rdi
00007d07b35def6a  pop rdx
00007d07b35def6b  pop rcx
00007d07b35def6c  pop rax
00007d07b35def6d  add rsp, 0x08
00007d07b35def71  jmp 0x00007D07B35DC31E
00007d07b35def76  sub rsp, 0x08
00007d07b35def7a  push rax
00007d07b35def7b  push rcx
00007d07b35def7c  push rdx
00007d07b35def7d  push rdi
00007d07b35def7e  push rsi
00007d07b35def7f  push r8
00007d07b35def81  push r9
00007d07b35def83  push r10
00007d07b35def85  push r11
00007d07b35def87  sub rsp, 0xF0
00007d07b35def8e  vmovaps [rsp], xmm0
00007d07b35def93  vmovaps [rsp+0x10], xmm1
00007d07b35def99  vmovaps [rsp+0x20], xmm2
00007d07b35def9f  vmovaps [rsp+0x30], xmm3
00007d07b35defa5  vmovaps [rsp+0x40], xmm4
00007d07b35defab  vmovaps [rsp+0x50], xmm5
00007d07b35defb1  vmovaps [rsp+0x60], xmm6
00007d07b35defb7  vmovaps [rsp+0x70], xmm7
00007d07b35defbd  vmovaps [rsp+0x80], xmm8
00007d07b35defc6  vmovaps [rsp+0x90], xmm10
00007d07b35defcf  vmovaps [rsp+0xA0], xmm11
00007d07b35defd8  vmovaps [rsp+0xB0], xmm12
00007d07b35defe1  vmovaps [rsp+0xC0], xmm13
00007d07b35defea  vmovaps [rsp+0xD0], xmm14
00007d07b35deff3  vmovaps [rsp+0xE0], xmm15
00007d07b35deffc  sub rsp, 0x30
00007d07b35df000  movaps [rsp], xmm9
00007d07b35df005  movaps [rsp+0x10], xmm2
00007d07b35df00a  movaps [rsp+0x20], xmm1
00007d07b35df00f  lea rdi, [rsp]
00007d07b35df013  mov esi, 0x00
00007d07b35df018  mov rax, 0x5D0AA712D530
00007d07b35df022  call rax
00007d07b35df024  movaps xmm9, [rsp]
00007d07b35df029  add rsp, 0x30
00007d07b35df02d  vmovaps xmm0, [rsp]
00007d07b35df032  vmovaps xmm1, [rsp+0x10]
00007d07b35df038  vmovaps xmm2, [rsp+0x20]
00007d07b35df03e  vmovaps xmm3, [rsp+0x30]
00007d07b35df044  vmovaps xmm4, [rsp+0x40]
00007d07b35df04a  vmovaps xmm5, [rsp+0x50]
00007d07b35df050  vmovaps xmm6, [rsp+0x60]
00007d07b35df056  vmovaps xmm7, [rsp+0x70]
00007d07b35df05c  vmovaps xmm8, [rsp+0x80]
00007d07b35df065  vmovaps xmm10, [rsp+0x90]
00007d07b35df06e  vmovaps xmm11, [rsp+0xA0]
00007d07b35df077  vmovaps xmm12, [rsp+0xB0]
00007d07b35df080  vmovaps xmm13, [rsp+0xC0]
00007d07b35df089  vmovaps xmm14, [rsp+0xD0]
00007d07b35df092  vmovaps xmm15, [rsp+0xE0]
00007d07b35df09b  add rsp, 0xF0
00007d07b35df0a2  pop r11
00007d07b35df0a4  pop r10
00007d07b35df0a6  pop r9
00007d07b35df0a8  pop r8
00007d07b35df0aa  pop rsi
00007d07b35df0ab  pop rdi
00007d07b35df0ac  pop rdx
00007d07b35df0ad  pop rcx
00007d07b35df0ae  pop rax
00007d07b35df0af  add rsp, 0x08
00007d07b35df0b3  jmp 0x00007D07B35DC354
00007d07b35df0b8  sub rsp, 0x08
00007d07b35df0bc  push rax
00007d07b35df0bd  push rcx
00007d07b35df0be  push rdx
00007d07b35df0bf  push rdi
00007d07b35df0c0  push rsi
00007d07b35df0c1  push r8
00007d07b35df0c3  push r9
00007d07b35df0c5  push r10
00007d07b35df0c7  push r11
00007d07b35df0c9  sub rsp, 0xF0
00007d07b35df0d0  vmovaps [rsp], xmm0
00007d07b35df0d5  vmovaps [rsp+0x10], xmm2
00007d07b35df0db  vmovaps [rsp+0x20], xmm3
00007d07b35df0e1  vmovaps [rsp+0x30], xmm4
00007d07b35df0e7  vmovaps [rsp+0x40], xmm5
00007d07b35df0ed  vmovaps [rsp+0x50], xmm6
00007d07b35df0f3  vmovaps [rsp+0x60], xmm7
00007d07b35df0f9  vmovaps [rsp+0x70], xmm8
00007d07b35df0ff  vmovaps [rsp+0x80], xmm9
00007d07b35df108  vmovaps [rsp+0x90], xmm10
00007d07b35df111  vmovaps [rsp+0xA0], xmm11
00007d07b35df11a  vmovaps [rsp+0xB0], xmm12
00007d07b35df123  vmovaps [rsp+0xC0], xmm13
00007d07b35df12c  vmovaps [rsp+0xD0], xmm14
00007d07b35df135  vmovaps [rsp+0xE0], xmm15
00007d07b35df13e  sub rsp, 0x30
00007d07b35df142  movaps [rsp], xmm1
00007d07b35df146  movaps [rsp+0x10], xmm15
00007d07b35df14c  movaps [rsp+0x20], xmm6
00007d07b35df151  lea rdi, [rsp]
00007d07b35df155  mov esi, 0x00
00007d07b35df15a  mov rax, 0x5D0AA712D530
00007d07b35df164  call rax
00007d07b35df166  movaps xmm1, [rsp]
00007d07b35df16a  add rsp, 0x30
00007d07b35df16e  vmovaps xmm0, [rsp]
00007d07b35df173  vmovaps xmm2, [rsp+0x10]
00007d07b35df179  vmovaps xmm3, [rsp+0x20]
00007d07b35df17f  vmovaps xmm4, [rsp+0x30]
00007d07b35df185  vmovaps xmm5, [rsp+0x40]
00007d07b35df18b  vmovaps xmm6, [rsp+0x50]
00007d07b35df191  vmovaps xmm7, [rsp+0x60]
00007d07b35df197  vmovaps xmm8, [rsp+0x70]
00007d07b35df19d  vmovaps xmm9, [rsp+0x80]
00007d07b35df1a6  vmovaps xmm10, [rsp+0x90]
00007d07b35df1af  vmovaps xmm11, [rsp+0xA0]
00007d07b35df1b8  vmovaps xmm12, [rsp+0xB0]
00007d07b35df1c1  vmovaps xmm13, [rsp+0xC0]
00007d07b35df1ca  vmovaps xmm14, [rsp+0xD0]
00007d07b35df1d3  vmovaps xmm15, [rsp+0xE0]
00007d07b35df1dc  add rsp, 0xF0
00007d07b35df1e3  pop r11
00007d07b35df1e5  pop r10
00007d07b35df1e7  pop r9
00007d07b35df1e9  pop r8
00007d07b35df1eb  pop rsi
00007d07b35df1ec  pop rdi
00007d07b35df1ed  pop rdx
00007d07b35df1ee  pop rcx
00007d07b35df1ef  pop rax
00007d07b35df1f0  add rsp, 0x08
00007d07b35df1f4  jmp 0x00007D07B35DC375
00007d07b35df1f9  sub rsp, 0x08
00007d07b35df1fd  push rax
00007d07b35df1fe  push rcx
00007d07b35df1ff  push rdx
00007d07b35df200  push rdi
00007d07b35df201  push rsi
00007d07b35df202  push r8
00007d07b35df204  push r9
00007d07b35df206  push r10
00007d07b35df208  push r11
00007d07b35df20a  sub rsp, 0xF0
00007d07b35df211  vmovaps [rsp], xmm0
00007d07b35df216  vmovaps [rsp+0x10], xmm1
00007d07b35df21c  vmovaps [rsp+0x20], xmm2
00007d07b35df222  vmovaps [rsp+0x30], xmm3
00007d07b35df228  vmovaps [rsp+0x40], xmm4
00007d07b35df22e  vmovaps [rsp+0x50], xmm5
00007d07b35df234  vmovaps [rsp+0x60], xmm6
00007d07b35df23a  vmovaps [rsp+0x70], xmm7
00007d07b35df240  vmovaps [rsp+0x80], xmm8
00007d07b35df249  vmovaps [rsp+0x90], xmm9
00007d07b35df252  vmovaps [rsp+0xA0], xmm10
00007d07b35df25b  vmovaps [rsp+0xB0], xmm11
00007d07b35df264  vmovaps [rsp+0xC0], xmm12
00007d07b35df26d  vmovaps [rsp+0xD0], xmm13
00007d07b35df276  vmovaps [rsp+0xE0], xmm14
00007d07b35df27f  sub rsp, 0x30
00007d07b35df283  movaps [rsp], xmm15
00007d07b35df288  movaps [rsp+0x10], xmm5
00007d07b35df28d  movaps [rsp+0x20], xmm3
00007d07b35df292  lea rdi, [rsp]
00007d07b35df296  mov esi, 0x00
00007d07b35df29b  mov rax, 0x5D0AA712D530
00007d07b35df2a5  call rax
00007d07b35df2a7  movaps xmm15, [rsp]
00007d07b35df2ac  add rsp, 0x30
00007d07b35df2b0  vmovaps xmm0, [rsp]
00007d07b35df2b5  vmovaps xmm1, [rsp+0x10]
00007d07b35df2bb  vmovaps xmm2, [rsp+0x20]
00007d07b35df2c1  vmovaps xmm3, [rsp+0x30]
00007d07b35df2c7  vmovaps xmm4, [rsp+0x40]
00007d07b35df2cd  vmovaps xmm5, [rsp+0x50]
00007d07b35df2d3  vmovaps xmm6, [rsp+0x60]
00007d07b35df2d9  vmovaps xmm7, [rsp+0x70]
00007d07b35df2df  vmovaps xmm8, [rsp+0x80]
00007d07b35df2e8  vmovaps xmm9, [rsp+0x90]
00007d07b35df2f1  vmovaps xmm10, [rsp+0xA0]
00007d07b35df2fa  vmovaps xmm11, [rsp+0xB0]
00007d07b35df303  vmovaps xmm12, [rsp+0xC0]
00007d07b35df30c  vmovaps xmm13, [rsp+0xD0]
00007d07b35df315  vmovaps xmm14, [rsp+0xE0]
00007d07b35df31e  add rsp, 0xF0
00007d07b35df325  pop r11
00007d07b35df327  pop r10
00007d07b35df329  pop r9
00007d07b35df32b  pop r8
00007d07b35df32d  pop rsi
00007d07b35df32e  pop rdi
00007d07b35df32f  pop rdx
00007d07b35df330  pop rcx
00007d07b35df331  pop rax
00007d07b35df332  add rsp, 0x08
00007d07b35df336  jmp 0x00007D07B35DC38F
00007d07b35df33b  sub rsp, 0x08
00007d07b35df33f  push rax
00007d07b35df340  push rcx
00007d07b35df341  push rdx
00007d07b35df342  push rdi
00007d07b35df343  push rsi
00007d07b35df344  push r8
00007d07b35df346  push r9
00007d07b35df348  push r10
00007d07b35df34a  push r11
00007d07b35df34c  sub rsp, 0xF0
00007d07b35df353  vmovaps [rsp], xmm0
00007d07b35df358  vmovaps [rsp+0x10], xmm1
00007d07b35df35e  vmovaps [rsp+0x20], xmm2
00007d07b35df364  vmovaps [rsp+0x30], xmm3
00007d07b35df36a  vmovaps [rsp+0x40], xmm4
00007d07b35df370  vmovaps [rsp+0x50], xmm6
00007d07b35df376  vmovaps [rsp+0x60], xmm7
00007d07b35df37c  vmovaps [rsp+0x70], xmm8
00007d07b35df382  vmovaps [rsp+0x80], xmm9
00007d07b35df38b  vmovaps [rsp+0x90], xmm10
00007d07b35df394  vmovaps [rsp+0xA0], xmm11
00007d07b35df39d  vmovaps [rsp+0xB0], xmm12
00007d07b35df3a6  vmovaps [rsp+0xC0], xmm13
00007d07b35df3af  vmovaps [rsp+0xD0], xmm14
00007d07b35df3b8  vmovaps [rsp+0xE0], xmm15
00007d07b35df3c1  sub rsp, 0x30
00007d07b35df3c5  movaps [rsp], xmm5
00007d07b35df3c9  movaps [rsp+0x10], xmm8
00007d07b35df3cf  movaps [rsp+0x20], xmm6
00007d07b35df3d4  lea rdi, [rsp]
00007d07b35df3d8  mov esi, 0x00
00007d07b35df3dd  mov rax, 0x5D0AA712D530
00007d07b35df3e7  call rax
00007d07b35df3e9  movaps xmm5, [rsp]
00007d07b35df3ed  add rsp, 0x30
00007d07b35df3f1  vmovaps xmm0, [rsp]
00007d07b35df3f6  vmovaps xmm1, [rsp+0x10]
00007d07b35df3fc  vmovaps xmm2, [rsp+0x20]
00007d07b35df402  vmovaps xmm3, [rsp+0x30]
00007d07b35df408  vmovaps xmm4, [rsp+0x40]
00007d07b35df40e  vmovaps xmm6, [rsp+0x50]
00007d07b35df414  vmovaps xmm7, [rsp+0x60]
00007d07b35df41a  vmovaps xmm8, [rsp+0x70]
00007d07b35df420  vmovaps xmm9, [rsp+0x80]
00007d07b35df429  vmovaps xmm10, [rsp+0x90]
00007d07b35df432  vmovaps xmm11, [rsp+0xA0]
00007d07b35df43b  vmovaps xmm12, [rsp+0xB0]
00007d07b35df444  vmovaps xmm13, [rsp+0xC0]
00007d07b35df44d  vmovaps xmm14, [rsp+0xD0]
00007d07b35df456  vmovaps xmm15, [rsp+0xE0]
00007d07b35df45f  add rsp, 0xF0
00007d07b35df466  pop r11
00007d07b35df468  pop r10
00007d07b35df46a  pop r9
00007d07b35df46c  pop r8
00007d07b35df46e  pop rsi
00007d07b35df46f  pop rdi
00007d07b35df470  pop rdx
00007d07b35df471  pop rcx
00007d07b35df472  pop rax
00007d07b35df473  add rsp, 0x08
00007d07b35df477  jmp 0x00007D07B35DC3B3
00007d07b35df47c  sub rsp, 0x08
00007d07b35df480  push rax
00007d07b35df481  push rcx
00007d07b35df482  push rdx
00007d07b35df483  push rdi
00007d07b35df484  push rsi
00007d07b35df485  push r8
00007d07b35df487  push r9
00007d07b35df489  push r10
00007d07b35df48b  push r11
00007d07b35df48d  sub rsp, 0xF0
00007d07b35df494  vmovaps [rsp], xmm0
00007d07b35df499  vmovaps [rsp+0x10], xmm1
00007d07b35df49f  vmovaps [rsp+0x20], xmm2
00007d07b35df4a5  vmovaps [rsp+0x30], xmm3
00007d07b35df4ab  vmovaps [rsp+0x40], xmm4
00007d07b35df4b1  vmovaps [rsp+0x50], xmm5
00007d07b35df4b7  vmovaps [rsp+0x60], xmm7
00007d07b35df4bd  vmovaps [rsp+0x70], xmm8
00007d07b35df4c3  vmovaps [rsp+0x80], xmm9
00007d07b35df4cc  vmovaps [rsp+0x90], xmm10
00007d07b35df4d5  vmovaps [rsp+0xA0], xmm11
00007d07b35df4de  vmovaps [rsp+0xB0], xmm12
00007d07b35df4e7  vmovaps [rsp+0xC0], xmm13
00007d07b35df4f0  vmovaps [rsp+0xD0], xmm14
00007d07b35df4f9  vmovaps [rsp+0xE0], xmm15
00007d07b35df502  sub rsp, 0x30
00007d07b35df506  movaps [rsp], xmm6
00007d07b35df50a  movaps [rsp+0x10], xmm10
00007d07b35df510  movaps [rsp+0x20], xmm8
00007d07b35df516  lea rdi, [rsp]
00007d07b35df51a  mov esi, 0x00
00007d07b35df51f  mov rax, 0x5D0AA712D530
00007d07b35df529  call rax
00007d07b35df52b  movaps xmm6, [rsp]
00007d07b35df52f  add rsp, 0x30
00007d07b35df533  vmovaps xmm0, [rsp]
00007d07b35df538  vmovaps xmm1, [rsp+0x10]
00007d07b35df53e  vmovaps xmm2, [rsp+0x20]
00007d07b35df544  vmovaps xmm3, [rsp+0x30]
00007d07b35df54a  vmovaps xmm4, [rsp+0x40]
00007d07b35df550  vmovaps xmm5, [rsp+0x50]
00007d07b35df556  vmovaps xmm7, [rsp+0x60]
00007d07b35df55c  vmovaps xmm8, [rsp+0x70]
00007d07b35df562  vmovaps xmm9, [rsp+0x80]
00007d07b35df56b  vmovaps xmm10, [rsp+0x90]
00007d07b35df574  vmovaps xmm11, [rsp+0xA0]
00007d07b35df57d  vmovaps xmm12, [rsp+0xB0]
00007d07b35df586  vmovaps xmm13, [rsp+0xC0]
00007d07b35df58f  vmovaps xmm14, [rsp+0xD0]
00007d07b35df598  vmovaps xmm15, [rsp+0xE0]
00007d07b35df5a1  add rsp, 0xF0
00007d07b35df5a8  pop r11
00007d07b35df5aa  pop r10
00007d07b35df5ac  pop r9
00007d07b35df5ae  pop r8
00007d07b35df5b0  pop rsi
00007d07b35df5b1  pop rdi
00007d07b35df5b2  pop rdx
00007d07b35df5b3  pop rcx
00007d07b35df5b4  pop rax
00007d07b35df5b5  add rsp, 0x08
00007d07b35df5b9  jmp 0x00007D07B35DC3D8
00007d07b35df5be  sub rsp, 0x08
00007d07b35df5c2  push rax
00007d07b35df5c3  push rcx
00007d07b35df5c4  push rdx
00007d07b35df5c5  push rdi
00007d07b35df5c6  push rsi
00007d07b35df5c7  push r8
00007d07b35df5c9  push r9
00007d07b35df5cb  push r10
00007d07b35df5cd  push r11
00007d07b35df5cf  sub rsp, 0xF0
00007d07b35df5d6  vmovaps [rsp], xmm0
00007d07b35df5db  vmovaps [rsp+0x10], xmm1
00007d07b35df5e1  vmovaps [rsp+0x20], xmm2
00007d07b35df5e7  vmovaps [rsp+0x30], xmm3
00007d07b35df5ed  vmovaps [rsp+0x40], xmm4
00007d07b35df5f3  vmovaps [rsp+0x50], xmm5
00007d07b35df5f9  vmovaps [rsp+0x60], xmm6
00007d07b35df5ff  vmovaps [rsp+0x70], xmm7
00007d07b35df605  vmovaps [rsp+0x80], xmm8
00007d07b35df60e  vmovaps [rsp+0x90], xmm9
00007d07b35df617  vmovaps [rsp+0xA0], xmm11
00007d07b35df620  vmovaps [rsp+0xB0], xmm12
00007d07b35df629  vmovaps [rsp+0xC0], xmm13
00007d07b35df632  vmovaps [rsp+0xD0], xmm14
00007d07b35df63b  vmovaps [rsp+0xE0], xmm15
00007d07b35df644  sub rsp, 0x30
00007d07b35df648  movaps [rsp], xmm10
00007d07b35df64d  movaps [rsp+0x10], xmm8
00007d07b35df653  movaps [rsp+0x20], xmm14
00007d07b35df659  lea rdi, [rsp]
00007d07b35df65d  mov esi, 0x00
00007d07b35df662  mov rax, 0x5D0AA712D530
00007d07b35df66c  call rax
00007d07b35df66e  movaps xmm10, [rsp]
00007d07b35df673  add rsp, 0x30
00007d07b35df677  vmovaps xmm0, [rsp]
00007d07b35df67c  vmovaps xmm1, [rsp+0x10]
00007d07b35df682  vmovaps xmm2, [rsp+0x20]
00007d07b35df688  vmovaps xmm3, [rsp+0x30]
00007d07b35df68e  vmovaps xmm4, [rsp+0x40]
00007d07b35df694  vmovaps xmm5, [rsp+0x50]
00007d07b35df69a  vmovaps xmm6, [rsp+0x60]
00007d07b35df6a0  vmovaps xmm7, [rsp+0x70]
00007d07b35df6a6  vmovaps xmm8, [rsp+0x80]
00007d07b35df6af  vmovaps xmm9, [rsp+0x90]
00007d07b35df6b8  vmovaps xmm11, [rsp+0xA0]
00007d07b35df6c1  vmovaps xmm12, [rsp+0xB0]
00007d07b35df6ca  vmovaps xmm13, [rsp+0xC0]
00007d07b35df6d3  vmovaps xmm14, [rsp+0xD0]
00007d07b35df6dc  vmovaps xmm15, [rsp+0xE0]
00007d07b35df6e5  add rsp, 0xF0
00007d07b35df6ec  pop r11
00007d07b35df6ee  pop r10
00007d07b35df6f0  pop r9
00007d07b35df6f2  pop r8
00007d07b35df6f4  pop rsi
00007d07b35df6f5  pop rdi
00007d07b35df6f6  pop rdx
00007d07b35df6f7  pop rcx
00007d07b35df6f8  pop rax
00007d07b35df6f9  add rsp, 0x08
00007d07b35df6fd  jmp 0x00007D07B35DC3F8
00007d07b35df702  sub rsp, 0x08
00007d07b35df706  push rax
00007d07b35df707  push rcx
00007d07b35df708  push rdx
00007d07b35df709  push rdi
00007d07b35df70a  push rsi
00007d07b35df70b  push r8
00007d07b35df70d  push r9
00007d07b35df70f  push r10
00007d07b35df711  push r11
00007d07b35df713  sub rsp, 0xF0
00007d07b35df71a  vmovaps [rsp], xmm0
00007d07b35df71f  vmovaps [rsp+0x10], xmm1
00007d07b35df725  vmovaps [rsp+0x20], xmm2
00007d07b35df72b  vmovaps [rsp+0x30], xmm3
00007d07b35df731  vmovaps [rsp+0x40], xmm4
00007d07b35df737  vmovaps [rsp+0x50], xmm5
00007d07b35df73d  vmovaps [rsp+0x60], xmm6
00007d07b35df743  vmovaps [rsp+0x70], xmm7
00007d07b35df749  vmovaps [rsp+0x80], xmm8
00007d07b35df752  vmovaps [rsp+0x90], xmm9
00007d07b35df75b  vmovaps [rsp+0xA0], xmm10
00007d07b35df764  vmovaps [rsp+0xB0], xmm11
00007d07b35df76d  vmovaps [rsp+0xC0], xmm12
00007d07b35df776  vmovaps [rsp+0xD0], xmm13
00007d07b35df77f  vmovaps [rsp+0xE0], xmm15
00007d07b35df788  sub rsp, 0x30
00007d07b35df78c  movaps [rsp], xmm14
00007d07b35df791  movaps [rsp+0x10], xmm8
00007d07b35df797  movaps [rsp+0x20], xmm4
00007d07b35df79c  lea rdi, [rsp]
00007d07b35df7a0  mov esi, 0x00
00007d07b35df7a5  mov rax, 0x5D0AA712D530
00007d07b35df7af  call rax
00007d07b35df7b1  movaps xmm14, [rsp]
00007d07b35df7b6  add rsp, 0x30
00007d07b35df7ba  vmovaps xmm0, [rsp]
00007d07b35df7bf  vmovaps xmm1, [rsp+0x10]
00007d07b35df7c5  vmovaps xmm2, [rsp+0x20]
00007d07b35df7cb  vmovaps xmm3, [rsp+0x30]
00007d07b35df7d1  vmovaps xmm4, [rsp+0x40]
00007d07b35df7d7  vmovaps xmm5, [rsp+0x50]
00007d07b35df7dd  vmovaps xmm6, [rsp+0x60]
00007d07b35df7e3  vmovaps xmm7, [rsp+0x70]
00007d07b35df7e9  vmovaps xmm8, [rsp+0x80]
00007d07b35df7f2  vmovaps xmm9, [rsp+0x90]
00007d07b35df7fb  vmovaps xmm10, [rsp+0xA0]
00007d07b35df804  vmovaps xmm11, [rsp+0xB0]
00007d07b35df80d  vmovaps xmm12, [rsp+0xC0]
00007d07b35df816  vmovaps xmm13, [rsp+0xD0]
00007d07b35df81f  vmovaps xmm15, [rsp+0xE0]
00007d07b35df828  add rsp, 0xF0
00007d07b35df82f  pop r11
00007d07b35df831  pop r10
00007d07b35df833  pop r9
00007d07b35df835  pop r8
00007d07b35df837  pop rsi
00007d07b35df838  pop rdi
00007d07b35df839  pop rdx
00007d07b35df83a  pop rcx
00007d07b35df83b  pop rax
00007d07b35df83c  add rsp, 0x08
00007d07b35df840  jmp 0x00007D07B35DC418
00007d07b35df845  sub rsp, 0x08
00007d07b35df849  push rax
00007d07b35df84a  push rcx
00007d07b35df84b  push rdx
00007d07b35df84c  push rdi
00007d07b35df84d  push rsi
00007d07b35df84e  push r8
00007d07b35df850  push r9
00007d07b35df852  push r10
00007d07b35df854  push r11
00007d07b35df856  sub rsp, 0xF0
00007d07b35df85d  vmovaps [rsp], xmm0
00007d07b35df862  vmovaps [rsp+0x10], xmm1
00007d07b35df868  vmovaps [rsp+0x20], xmm2
00007d07b35df86e  vmovaps [rsp+0x30], xmm3
00007d07b35df874  vmovaps [rsp+0x40], xmm5
00007d07b35df87a  vmovaps [rsp+0x50], xmm6
00007d07b35df880  vmovaps [rsp+0x60], xmm7
00007d07b35df886  vmovaps [rsp+0x70], xmm8
00007d07b35df88c  vmovaps [rsp+0x80], xmm9
00007d07b35df895  vmovaps [rsp+0x90], xmm10
00007d07b35df89e  vmovaps [rsp+0xA0], xmm11
00007d07b35df8a7  vmovaps [rsp+0xB0], xmm12
00007d07b35df8b0  vmovaps [rsp+0xC0], xmm13
00007d07b35df8b9  vmovaps [rsp+0xD0], xmm14
00007d07b35df8c2  vmovaps [rsp+0xE0], xmm15
00007d07b35df8cb  sub rsp, 0x30
00007d07b35df8cf  movaps [rsp], xmm4
00007d07b35df8d3  movaps [rsp+0x10], xmm13
00007d07b35df8d9  movaps [rsp+0x20], xmm8
00007d07b35df8df  lea rdi, [rsp]
00007d07b35df8e3  mov esi, 0x00
00007d07b35df8e8  mov rax, 0x5D0AA712D530
00007d07b35df8f2  call rax
00007d07b35df8f4  movaps xmm4, [rsp]
00007d07b35df8f8  add rsp, 0x30
00007d07b35df8fc  vmovaps xmm0, [rsp]
00007d07b35df901  vmovaps xmm1, [rsp+0x10]
00007d07b35df907  vmovaps xmm2, [rsp+0x20]
00007d07b35df90d  vmovaps xmm3, [rsp+0x30]
00007d07b35df913  vmovaps xmm5, [rsp+0x40]
00007d07b35df919  vmovaps xmm6, [rsp+0x50]
00007d07b35df91f  vmovaps xmm7, [rsp+0x60]
00007d07b35df925  vmovaps xmm8, [rsp+0x70]
00007d07b35df92b  vmovaps xmm9, [rsp+0x80]
00007d07b35df934  vmovaps xmm10, [rsp+0x90]
00007d07b35df93d  vmovaps xmm11, [rsp+0xA0]
00007d07b35df946  vmovaps xmm12, [rsp+0xB0]
00007d07b35df94f  vmovaps xmm13, [rsp+0xC0]
00007d07b35df958  vmovaps xmm14, [rsp+0xD0]
00007d07b35df961  vmovaps xmm15, [rsp+0xE0]
00007d07b35df96a  add rsp, 0xF0
00007d07b35df971  pop r11
00007d07b35df973  pop r10
00007d07b35df975  pop r9
00007d07b35df977  pop r8
00007d07b35df979  pop rsi
00007d07b35df97a  pop rdi
00007d07b35df97b  pop rdx
00007d07b35df97c  pop rcx
00007d07b35df97d  pop rax
00007d07b35df97e  add rsp, 0x08
00007d07b35df982  jmp 0x00007D07B35DC43D
00007d07b35df987  sub rsp, 0x08
00007d07b35df98b  push rax
00007d07b35df98c  push rcx
00007d07b35df98d  push rdx
00007d07b35df98e  push rdi
00007d07b35df98f  push rsi
00007d07b35df990  push r8
00007d07b35df992  push r9
00007d07b35df994  push r10
00007d07b35df996  push r11
00007d07b35df998  sub rsp, 0xF0
00007d07b35df99f  vmovaps [rsp], xmm0
00007d07b35df9a4  vmovaps [rsp+0x10], xmm1
00007d07b35df9aa  vmovaps [rsp+0x20], xmm2
00007d07b35df9b0  vmovaps [rsp+0x30], xmm3
00007d07b35df9b6  vmovaps [rsp+0x40], xmm4
00007d07b35df9bc  vmovaps [rsp+0x50], xmm5
00007d07b35df9c2  vmovaps [rsp+0x60], xmm6
00007d07b35df9c8  vmovaps [rsp+0x70], xmm7
00007d07b35df9ce  vmovaps [rsp+0x80], xmm8
00007d07b35df9d7  vmovaps [rsp+0x90], xmm9
00007d07b35df9e0  vmovaps [rsp+0xA0], xmm10
00007d07b35df9e9  vmovaps [rsp+0xB0], xmm11
00007d07b35df9f2  vmovaps [rsp+0xC0], xmm12
00007d07b35df9fb  vmovaps [rsp+0xD0], xmm14
00007d07b35dfa04  vmovaps [rsp+0xE0], xmm15
00007d07b35dfa0d  sub rsp, 0x30
00007d07b35dfa11  movaps [rsp], xmm13
00007d07b35dfa16  movaps [rsp+0x10], xmm15
00007d07b35dfa1c  movaps [rsp+0x20], xmm9
00007d07b35dfa22  lea rdi, [rsp]
00007d07b35dfa26  mov esi, 0x00
00007d07b35dfa2b  mov rax, 0x5D0AA712D530
00007d07b35dfa35  call rax
00007d07b35dfa37  movaps xmm13, [rsp]
00007d07b35dfa3c  add rsp, 0x30
00007d07b35dfa40  vmovaps xmm0, [rsp]
00007d07b35dfa45  vmovaps xmm1, [rsp+0x10]
00007d07b35dfa4b  vmovaps xmm2, [rsp+0x20]
00007d07b35dfa51  vmovaps xmm3, [rsp+0x30]
00007d07b35dfa57  vmovaps xmm4, [rsp+0x40]
00007d07b35dfa5d  vmovaps xmm5, [rsp+0x50]
00007d07b35dfa63  vmovaps xmm6, [rsp+0x60]
00007d07b35dfa69  vmovaps xmm7, [rsp+0x70]
00007d07b35dfa6f  vmovaps xmm8, [rsp+0x80]
00007d07b35dfa78  vmovaps xmm9, [rsp+0x90]
00007d07b35dfa81  vmovaps xmm10, [rsp+0xA0]
00007d07b35dfa8a  vmovaps xmm11, [rsp+0xB0]
00007d07b35dfa93  vmovaps xmm12, [rsp+0xC0]
00007d07b35dfa9c  vmovaps xmm14, [rsp+0xD0]
00007d07b35dfaa5  vmovaps xmm15, [rsp+0xE0]
00007d07b35dfaae  add rsp, 0xF0
00007d07b35dfab5  pop r11
00007d07b35dfab7  pop r10
00007d07b35dfab9  pop r9
00007d07b35dfabb  pop r8
00007d07b35dfabd  pop rsi
00007d07b35dfabe  pop rdi
00007d07b35dfabf  pop rdx
00007d07b35dfac0  pop rcx
00007d07b35dfac1  pop rax
00007d07b35dfac2  add rsp, 0x08
00007d07b35dfac6  jmp 0x00007D07B35DC458
00007d07b35dfacb  sub rsp, 0x08
00007d07b35dfacf  push rax
00007d07b35dfad0  push rcx
00007d07b35dfad1  push rdx
00007d07b35dfad2  push rdi
00007d07b35dfad3  push rsi
00007d07b35dfad4  push r8
00007d07b35dfad6  push r9
00007d07b35dfad8  push r10
00007d07b35dfada  push r11
00007d07b35dfadc  sub rsp, 0xF0
00007d07b35dfae3  vmovaps [rsp], xmm0
00007d07b35dfae8  vmovaps [rsp+0x10], xmm1
00007d07b35dfaee  vmovaps [rsp+0x20], xmm2
00007d07b35dfaf4  vmovaps [rsp+0x30], xmm3
00007d07b35dfafa  vmovaps [rsp+0x40], xmm4
00007d07b35dfb00  vmovaps [rsp+0x50], xmm5
00007d07b35dfb06  vmovaps [rsp+0x60], xmm6
00007d07b35dfb0c  vmovaps [rsp+0x70], xmm7
00007d07b35dfb12  vmovaps [rsp+0x80], xmm8
00007d07b35dfb1b  vmovaps [rsp+0x90], xmm9
00007d07b35dfb24  vmovaps [rsp+0xA0], xmm10
00007d07b35dfb2d  vmovaps [rsp+0xB0], xmm11
00007d07b35dfb36  vmovaps [rsp+0xC0], xmm12
00007d07b35dfb3f  vmovaps [rsp+0xD0], xmm13
00007d07b35dfb48  vmovaps [rsp+0xE0], xmm14
00007d07b35dfb51  sub rsp, 0x30
00007d07b35dfb55  movaps [rsp], xmm15
00007d07b35dfb5a  movaps [rsp+0x10], xmm1
00007d07b35dfb5f  movaps [rsp+0x20], xmm5
00007d07b35dfb64  lea rdi, [rsp]
00007d07b35dfb68  mov esi, 0x00
00007d07b35dfb6d  mov rax, 0x5D0AA712D530
00007d07b35dfb77  call rax
00007d07b35dfb79  movaps xmm15, [rsp]
00007d07b35dfb7e  add rsp, 0x30
00007d07b35dfb82  vmovaps xmm0, [rsp]
00007d07b35dfb87  vmovaps xmm1, [rsp+0x10]
00007d07b35dfb8d  vmovaps xmm2, [rsp+0x20]
00007d07b35dfb93  vmovaps xmm3, [rsp+0x30]
00007d07b35dfb99  vmovaps xmm4, [rsp+0x40]
00007d07b35dfb9f  vmovaps xmm5, [rsp+0x50]
00007d07b35dfba5  vmovaps xmm6, [rsp+0x60]
00007d07b35dfbab  vmovaps xmm7, [rsp+0x70]
00007d07b35dfbb1  vmovaps xmm8, [rsp+0x80]
00007d07b35dfbba  vmovaps xmm9, [rsp+0x90]
00007d07b35dfbc3  vmovaps xmm10, [rsp+0xA0]
00007d07b35dfbcc  vmovaps xmm11, [rsp+0xB0]
00007d07b35dfbd5  vmovaps xmm12, [rsp+0xC0]
00007d07b35dfbde  vmovaps xmm13, [rsp+0xD0]
00007d07b35dfbe7  vmovaps xmm14, [rsp+0xE0]
00007d07b35dfbf0  add rsp, 0xF0
00007d07b35dfbf7  pop r11
00007d07b35dfbf9  pop r10
00007d07b35dfbfb  pop r9
00007d07b35dfbfd  pop r8
00007d07b35dfbff  pop rsi
00007d07b35dfc00  pop rdi
00007d07b35dfc01  pop rdx
00007d07b35dfc02  pop rcx
00007d07b35dfc03  pop rax
00007d07b35dfc04  add rsp, 0x08
00007d07b35dfc08  jmp 0x00007D07B35DC473
00007d07b35dfc0d  call 0x00007D07B34B52F0
00007d07b35dfc12  jmp 0x00007D07B35DC4CE
00007d07b35dfc17  sub rsp, 0x08
00007d07b35dfc1b  push rax
00007d07b35dfc1c  push rcx
00007d07b35dfc1d  push rdx
00007d07b35dfc1e  push rdi
00007d07b35dfc1f  push rsi
00007d07b35dfc20  push r8
00007d07b35dfc22  push r9
00007d07b35dfc24  push r10
00007d07b35dfc26  push r11
00007d07b35dfc28  sub rsp, 0xF0
00007d07b35dfc2f  vmovaps [rsp], xmm0
00007d07b35dfc34  vmovaps [rsp+0x10], xmm1
00007d07b35dfc3a  vmovaps [rsp+0x20], xmm2
00007d07b35dfc40  vmovaps [rsp+0x30], xmm3
00007d07b35dfc46  vmovaps [rsp+0x40], xmm4
00007d07b35dfc4c  vmovaps [rsp+0x50], xmm5
00007d07b35dfc52  vmovaps [rsp+0x60], xmm6
00007d07b35dfc58  vmovaps [rsp+0x70], xmm7
00007d07b35dfc5e  vmovaps [rsp+0x80], xmm8
00007d07b35dfc67  vmovaps [rsp+0x90], xmm10
00007d07b35dfc70  vmovaps [rsp+0xA0], xmm11
00007d07b35dfc79  vmovaps [rsp+0xB0], xmm12
00007d07b35dfc82  vmovaps [rsp+0xC0], xmm13
00007d07b35dfc8b  vmovaps [rsp+0xD0], xmm14
00007d07b35dfc94  vmovaps [rsp+0xE0], xmm15
00007d07b35dfc9d  sub rsp, 0x30
00007d07b35dfca1  movaps [rsp], xmm9
00007d07b35dfca6  movaps [rsp+0x10], xmm8
00007d07b35dfcac  movaps [rsp+0x20], xmm11
00007d07b35dfcb2  lea rdi, [rsp]
00007d07b35dfcb6  mov esi, 0x00
00007d07b35dfcbb  mov rax, 0x5D0AA712D530
00007d07b35dfcc5  call rax
00007d07b35dfcc7  movaps xmm9, [rsp]
00007d07b35dfccc  add rsp, 0x30
00007d07b35dfcd0  vmovaps xmm0, [rsp]
00007d07b35dfcd5  vmovaps xmm1, [rsp+0x10]
00007d07b35dfcdb  vmovaps xmm2, [rsp+0x20]
00007d07b35dfce1  vmovaps xmm3, [rsp+0x30]
00007d07b35dfce7  vmovaps xmm4, [rsp+0x40]
00007d07b35dfced  vmovaps xmm5, [rsp+0x50]
00007d07b35dfcf3  vmovaps xmm6, [rsp+0x60]
00007d07b35dfcf9  vmovaps xmm7, [rsp+0x70]
00007d07b35dfcff  vmovaps xmm8, [rsp+0x80]
00007d07b35dfd08  vmovaps xmm10, [rsp+0x90]
00007d07b35dfd11  vmovaps xmm11, [rsp+0xA0]
00007d07b35dfd1a  vmovaps xmm12, [rsp+0xB0]
00007d07b35dfd23  vmovaps xmm13, [rsp+0xC0]
00007d07b35dfd2c  vmovaps xmm14, [rsp+0xD0]
00007d07b35dfd35  vmovaps xmm15, [rsp+0xE0]
00007d07b35dfd3e  add rsp, 0xF0
00007d07b35dfd45  pop r11
00007d07b35dfd47  pop r10
00007d07b35dfd49  pop r9
00007d07b35dfd4b  pop r8
00007d07b35dfd4d  pop rsi
00007d07b35dfd4e  pop rdi
00007d07b35dfd4f  pop rdx
00007d07b35dfd50  pop rcx
00007d07b35dfd51  pop rax
00007d07b35dfd52  add rsp, 0x08
00007d07b35dfd56  jmp 0x00007D07B35DC505
00007d07b35dfd5b  sub rsp, 0x08
00007d07b35dfd5f  push rax
00007d07b35dfd60  push rcx
00007d07b35dfd61  push rdx
00007d07b35dfd62  push rdi
00007d07b35dfd63  push rsi
00007d07b35dfd64  push r8
00007d07b35dfd66  push r9
00007d07b35dfd68  push r10
00007d07b35dfd6a  push r11
00007d07b35dfd6c  sub rsp, 0xF0
00007d07b35dfd73  vmovaps [rsp], xmm0
00007d07b35dfd78  vmovaps [rsp+0x10], xmm1
00007d07b35dfd7e  vmovaps [rsp+0x20], xmm2
00007d07b35dfd84  vmovaps [rsp+0x30], xmm3
00007d07b35dfd8a  vmovaps [rsp+0x40], xmm4
00007d07b35dfd90  vmovaps [rsp+0x50], xmm5
00007d07b35dfd96  vmovaps [rsp+0x60], xmm6
00007d07b35dfd9c  vmovaps [rsp+0x70], xmm7
00007d07b35dfda2  vmovaps [rsp+0x80], xmm8
00007d07b35dfdab  vmovaps [rsp+0x90], xmm9
00007d07b35dfdb4  vmovaps [rsp+0xA0], xmm10
00007d07b35dfdbd  vmovaps [rsp+0xB0], xmm12
00007d07b35dfdc6  vmovaps [rsp+0xC0], xmm13
00007d07b35dfdcf  vmovaps [rsp+0xD0], xmm14
00007d07b35dfdd8  vmovaps [rsp+0xE0], xmm15
00007d07b35dfde1  sub rsp, 0x30
00007d07b35dfde5  movaps [rsp], xmm11
00007d07b35dfdea  movaps [rsp+0x10], xmm10
00007d07b35dfdf0  movaps [rsp+0x20], xmm6
00007d07b35dfdf5  lea rdi, [rsp]
00007d07b35dfdf9  mov esi, 0x00
00007d07b35dfdfe  mov rax, 0x5D0AA712D530
00007d07b35dfe08  call rax
00007d07b35dfe0a  movaps xmm11, [rsp]
00007d07b35dfe0f  add rsp, 0x30
00007d07b35dfe13  vmovaps xmm0, [rsp]
00007d07b35dfe18  vmovaps xmm1, [rsp+0x10]
00007d07b35dfe1e  vmovaps xmm2, [rsp+0x20]
00007d07b35dfe24  vmovaps xmm3, [rsp+0x30]
00007d07b35dfe2a  vmovaps xmm4, [rsp+0x40]
00007d07b35dfe30  vmovaps xmm5, [rsp+0x50]
00007d07b35dfe36  vmovaps xmm6, [rsp+0x60]
00007d07b35dfe3c  vmovaps xmm7, [rsp+0x70]
00007d07b35dfe42  vmovaps xmm8, [rsp+0x80]
00007d07b35dfe4b  vmovaps xmm9, [rsp+0x90]
00007d07b35dfe54  vmovaps xmm10, [rsp+0xA0]
00007d07b35dfe5d  vmovaps xmm12, [rsp+0xB0]
00007d07b35dfe66  vmovaps xmm13, [rsp+0xC0]
00007d07b35dfe6f  vmovaps xmm14, [rsp+0xD0]
00007d07b35dfe78  vmovaps xmm15, [rsp+0xE0]
00007d07b35dfe81  add rsp, 0xF0
00007d07b35dfe88  pop r11
00007d07b35dfe8a  pop r10
00007d07b35dfe8c  pop r9
00007d07b35dfe8e  pop r8
00007d07b35dfe90  pop rsi
00007d07b35dfe91  pop rdi
00007d07b35dfe92  pop rdx
00007d07b35dfe93  pop rcx
00007d07b35dfe94  pop rax
00007d07b35dfe95  add rsp, 0x08
00007d07b35dfe99  jmp 0x00007D07B35DC520
00007d07b35dfe9e  sub rsp, 0x08
00007d07b35dfea2  push rax
00007d07b35dfea3  push rcx
00007d07b35dfea4  push rdx
00007d07b35dfea5  push rdi
00007d07b35dfea6  push rsi
00007d07b35dfea7  push r8
00007d07b35dfea9  push r9
00007d07b35dfeab  push r10
00007d07b35dfead  push r11
00007d07b35dfeaf  sub rsp, 0xF0
00007d07b35dfeb6  vmovaps [rsp], xmm0
00007d07b35dfebb  vmovaps [rsp+0x10], xmm1
00007d07b35dfec1  vmovaps [rsp+0x20], xmm2
00007d07b35dfec7  vmovaps [rsp+0x30], xmm3
00007d07b35dfecd  vmovaps [rsp+0x40], xmm4
00007d07b35dfed3  vmovaps [rsp+0x50], xmm5
00007d07b35dfed9  vmovaps [rsp+0x60], xmm6
00007d07b35dfedf  vmovaps [rsp+0x70], xmm7
00007d07b35dfee5  vmovaps [rsp+0x80], xmm8
00007d07b35dfeee  vmovaps [rsp+0x90], xmm9
00007d07b35dfef7  vmovaps [rsp+0xA0], xmm11
00007d07b35dff00  vmovaps [rsp+0xB0], xmm12
00007d07b35dff09  vmovaps [rsp+0xC0], xmm13
00007d07b35dff12  vmovaps [rsp+0xD0], xmm14
00007d07b35dff1b  vmovaps [rsp+0xE0], xmm15
00007d07b35dff24  sub rsp, 0x30
00007d07b35dff28  movaps [rsp], xmm10
00007d07b35dff2d  movaps [rsp+0x10], xmm14
00007d07b35dff33  movaps [rsp+0x20], xmm4
00007d07b35dff38  lea rdi, [rsp]
00007d07b35dff3c  mov esi, 0x00
00007d07b35dff41  mov rax, 0x5D0AA712D530
00007d07b35dff4b  call rax
00007d07b35dff4d  movaps xmm10, [rsp]
00007d07b35dff52  add rsp, 0x30
00007d07b35dff56  vmovaps xmm0, [rsp]
00007d07b35dff5b  vmovaps xmm1, [rsp+0x10]
00007d07b35dff61  vmovaps xmm2, [rsp+0x20]
00007d07b35dff67  vmovaps xmm3, [rsp+0x30]
00007d07b35dff6d  vmovaps xmm4, [rsp+0x40]
00007d07b35dff73  vmovaps xmm5, [rsp+0x50]
00007d07b35dff79  vmovaps xmm6, [rsp+0x60]
00007d07b35dff7f  vmovaps xmm7, [rsp+0x70]
00007d07b35dff85  vmovaps xmm8, [rsp+0x80]
00007d07b35dff8e  vmovaps xmm9, [rsp+0x90]
00007d07b35dff97  vmovaps xmm11, [rsp+0xA0]
00007d07b35dffa0  vmovaps xmm12, [rsp+0xB0]
00007d07b35dffa9  vmovaps xmm13, [rsp+0xC0]
00007d07b35dffb2  vmovaps xmm14, [rsp+0xD0]
00007d07b35dffbb  vmovaps xmm15, [rsp+0xE0]
00007d07b35dffc4  add rsp, 0xF0
00007d07b35dffcb  pop r11
00007d07b35dffcd  pop r10
00007d07b35dffcf  pop r9
00007d07b35dffd1  pop r8
00007d07b35dffd3  pop rsi
00007d07b35dffd4  pop rdi
00007d07b35dffd5  pop rdx
00007d07b35dffd6  pop rcx
00007d07b35dffd7  pop rax
00007d07b35dffd8  add rsp, 0x08
00007d07b35dffdc  jmp 0x00007D07B35DC53B
00007d07b35dffe1  sub rsp, 0x08
00007d07b35dffe5  push rax
00007d07b35dffe6  push rcx
00007d07b35dffe7  push rdx
00007d07b35dffe8  push rdi
00007d07b35dffe9  push rsi
00007d07b35dffea  push r8
00007d07b35dffec  push r9
00007d07b35dffee  push r10
00007d07b35dfff0  push r11
00007d07b35dfff2  sub rsp, 0xF0
00007d07b35dfff9  vmovaps [rsp], xmm0
00007d07b35dfffe  vmovaps [rsp+0x10], xmm1
00007d07b35e0004  vmovaps [rsp+0x20], xmm2
00007d07b35e000a  vmovaps [rsp+0x30], xmm3
00007d07b35e0010  vmovaps [rsp+0x40], xmm4
00007d07b35e0016  vmovaps [rsp+0x50], xmm5
00007d07b35e001c  vmovaps [rsp+0x60], xmm6
00007d07b35e0022  vmovaps [rsp+0x70], xmm7
00007d07b35e0028  vmovaps [rsp+0x80], xmm9
00007d07b35e0031  vmovaps [rsp+0x90], xmm10
00007d07b35e003a  vmovaps [rsp+0xA0], xmm11
00007d07b35e0043  vmovaps [rsp+0xB0], xmm12
00007d07b35e004c  vmovaps [rsp+0xC0], xmm13
00007d07b35e0055  vmovaps [rsp+0xD0], xmm14
00007d07b35e005e  vmovaps [rsp+0xE0], xmm15
00007d07b35e0067  sub rsp, 0x30
00007d07b35e006b  movaps [rsp], xmm8
00007d07b35e0070  movaps [rsp+0x10], xmm1
00007d07b35e0075  movaps [rsp+0x20], xmm14
00007d07b35e007b  lea rdi, [rsp]
00007d07b35e007f  mov esi, 0x00
00007d07b35e0084  mov rax, 0x5D0AA712D530
00007d07b35e008e  call rax
00007d07b35e0090  movaps xmm8, [rsp]
00007d07b35e0095  add rsp, 0x30
00007d07b35e0099  vmovaps xmm0, [rsp]
00007d07b35e009e  vmovaps xmm1, [rsp+0x10]
00007d07b35e00a4  vmovaps xmm2, [rsp+0x20]
00007d07b35e00aa  vmovaps xmm3, [rsp+0x30]
00007d07b35e00b0  vmovaps xmm4, [rsp+0x40]
00007d07b35e00b6  vmovaps xmm5, [rsp+0x50]
00007d07b35e00bc  vmovaps xmm6, [rsp+0x60]
00007d07b35e00c2  vmovaps xmm7, [rsp+0x70]
00007d07b35e00c8  vmovaps xmm9, [rsp+0x80]
00007d07b35e00d1  vmovaps xmm10, [rsp+0x90]
00007d07b35e00da  vmovaps xmm11, [rsp+0xA0]
00007d07b35e00e3  vmovaps xmm12, [rsp+0xB0]
00007d07b35e00ec  vmovaps xmm13, [rsp+0xC0]
00007d07b35e00f5  vmovaps xmm14, [rsp+0xD0]
00007d07b35e00fe  vmovaps xmm15, [rsp+0xE0]
00007d07b35e0107  add rsp, 0xF0
00007d07b35e010e  pop r11
00007d07b35e0110  pop r10
00007d07b35e0112  pop r9
00007d07b35e0114  pop r8
00007d07b35e0116  pop rsi
00007d07b35e0117  pop rdi
00007d07b35e0118  pop rdx
00007d07b35e0119  pop rcx
00007d07b35e011a  pop rax
00007d07b35e011b  add rsp, 0x08
00007d07b35e011f  jmp 0x00007D07B35DC561
00007d07b35e0124  sub rsp, 0x08
00007d07b35e0128  push rax
00007d07b35e0129  push rcx
00007d07b35e012a  push rdx
00007d07b35e012b  push rdi
00007d07b35e012c  push rsi
00007d07b35e012d  push r8
00007d07b35e012f  push r9
00007d07b35e0131  push r10
00007d07b35e0133  push r11
00007d07b35e0135  sub rsp, 0xF0
00007d07b35e013c  vmovaps [rsp], xmm0
00007d07b35e0141  vmovaps [rsp+0x10], xmm1
00007d07b35e0147  vmovaps [rsp+0x20], xmm2
00007d07b35e014d  vmovaps [rsp+0x30], xmm3
00007d07b35e0153  vmovaps [rsp+0x40], xmm4
00007d07b35e0159  vmovaps [rsp+0x50], xmm5
00007d07b35e015f  vmovaps [rsp+0x60], xmm7
00007d07b35e0165  vmovaps [rsp+0x70], xmm8
00007d07b35e016b  vmovaps [rsp+0x80], xmm9
00007d07b35e0174  vmovaps [rsp+0x90], xmm10
00007d07b35e017d  vmovaps [rsp+0xA0], xmm11
00007d07b35e0186  vmovaps [rsp+0xB0], xmm12
00007d07b35e018f  vmovaps [rsp+0xC0], xmm13
00007d07b35e0198  vmovaps [rsp+0xD0], xmm14
00007d07b35e01a1  vmovaps [rsp+0xE0], xmm15
00007d07b35e01aa  sub rsp, 0x30
00007d07b35e01ae  movaps [rsp], xmm6
00007d07b35e01b2  movaps [rsp+0x10], xmm1
00007d07b35e01b7  movaps [rsp+0x20], xmm14
00007d07b35e01bd  lea rdi, [rsp]
00007d07b35e01c1  mov esi, 0x00
00007d07b35e01c6  mov rax, 0x5D0AA712D530
00007d07b35e01d0  call rax
00007d07b35e01d2  movaps xmm6, [rsp]
00007d07b35e01d6  add rsp, 0x30
00007d07b35e01da  vmovaps xmm0, [rsp]
00007d07b35e01df  vmovaps xmm1, [rsp+0x10]
00007d07b35e01e5  vmovaps xmm2, [rsp+0x20]
00007d07b35e01eb  vmovaps xmm3, [rsp+0x30]
00007d07b35e01f1  vmovaps xmm4, [rsp+0x40]
00007d07b35e01f7  vmovaps xmm5, [rsp+0x50]
00007d07b35e01fd  vmovaps xmm7, [rsp+0x60]
00007d07b35e0203  vmovaps xmm8, [rsp+0x70]
00007d07b35e0209  vmovaps xmm9, [rsp+0x80]
00007d07b35e0212  vmovaps xmm10, [rsp+0x90]
00007d07b35e021b  vmovaps xmm11, [rsp+0xA0]
00007d07b35e0224  vmovaps xmm12, [rsp+0xB0]
00007d07b35e022d  vmovaps xmm13, [rsp+0xC0]
00007d07b35e0236  vmovaps xmm14, [rsp+0xD0]
00007d07b35e023f  vmovaps xmm15, [rsp+0xE0]
00007d07b35e0248  add rsp, 0xF0
00007d07b35e024f  pop r11
00007d07b35e0251  pop r10
00007d07b35e0253  pop r9
00007d07b35e0255  pop r8
00007d07b35e0257  pop rsi
00007d07b35e0258  pop rdi
00007d07b35e0259  pop rdx
00007d07b35e025a  pop rcx
00007d07b35e025b  pop rax
00007d07b35e025c  add rsp, 0x08
00007d07b35e0260  jmp 0x00007D07B35DC58D
00007d07b35e0265  sub rsp, 0x08
00007d07b35e0269  push rax
00007d07b35e026a  push rcx
00007d07b35e026b  push rdx
00007d07b35e026c  push rdi
00007d07b35e026d  push rsi
00007d07b35e026e  push r8
00007d07b35e0270  push r9
00007d07b35e0272  push r10
00007d07b35e0274  push r11
00007d07b35e0276  sub rsp, 0xF0
00007d07b35e027d  vmovaps [rsp], xmm0
00007d07b35e0282  vmovaps [rsp+0x10], xmm1
00007d07b35e0288  vmovaps [rsp+0x20], xmm2
00007d07b35e028e  vmovaps [rsp+0x30], xmm3
00007d07b35e0294  vmovaps [rsp+0x40], xmm4
00007d07b35e029a  vmovaps [rsp+0x50], xmm5
00007d07b35e02a0  vmovaps [rsp+0x60], xmm6
00007d07b35e02a6  vmovaps [rsp+0x70], xmm7
00007d07b35e02ac  vmovaps [rsp+0x80], xmm8
00007d07b35e02b5  vmovaps [rsp+0x90], xmm9
00007d07b35e02be  vmovaps [rsp+0xA0], xmm10
00007d07b35e02c7  vmovaps [rsp+0xB0], xmm11
00007d07b35e02d0  vmovaps [rsp+0xC0], xmm12
00007d07b35e02d9  vmovaps [rsp+0xD0], xmm13
00007d07b35e02e2  vmovaps [rsp+0xE0], xmm15
00007d07b35e02eb  sub rsp, 0x30
00007d07b35e02ef  movaps [rsp], xmm14
00007d07b35e02f4  movaps [rsp+0x10], xmm12
00007d07b35e02fa  movaps [rsp+0x20], xmm1
00007d07b35e02ff  lea rdi, [rsp]
00007d07b35e0303  mov esi, 0x00
00007d07b35e0308  mov rax, 0x5D0AA712D530
00007d07b35e0312  call rax
00007d07b35e0314  movaps xmm14, [rsp]
00007d07b35e0319  add rsp, 0x30
00007d07b35e031d  vmovaps xmm0, [rsp]
00007d07b35e0322  vmovaps xmm1, [rsp+0x10]
00007d07b35e0328  vmovaps xmm2, [rsp+0x20]
00007d07b35e032e  vmovaps xmm3, [rsp+0x30]
00007d07b35e0334  vmovaps xmm4, [rsp+0x40]
00007d07b35e033a  vmovaps xmm5, [rsp+0x50]
00007d07b35e0340  vmovaps xmm6, [rsp+0x60]
00007d07b35e0346  vmovaps xmm7, [rsp+0x70]
00007d07b35e034c  vmovaps xmm8, [rsp+0x80]
00007d07b35e0355  vmovaps xmm9, [rsp+0x90]
00007d07b35e035e  vmovaps xmm10, [rsp+0xA0]
00007d07b35e0367  vmovaps xmm11, [rsp+0xB0]
00007d07b35e0370  vmovaps xmm12, [rsp+0xC0]
00007d07b35e0379  vmovaps xmm13, [rsp+0xD0]
00007d07b35e0382  vmovaps xmm15, [rsp+0xE0]
00007d07b35e038b  add rsp, 0xF0
00007d07b35e0392  pop r11
00007d07b35e0394  pop r10
00007d07b35e0396  pop r9
00007d07b35e0398  pop r8
00007d07b35e039a  pop rsi
00007d07b35e039b  pop rdi
00007d07b35e039c  pop rdx
00007d07b35e039d  pop rcx
00007d07b35e039e  pop rax
00007d07b35e039f  add rsp, 0x08
00007d07b35e03a3  jmp 0x00007D07B35DC5B3
00007d07b35e03a8  sub rsp, 0x08
00007d07b35e03ac  push rax
00007d07b35e03ad  push rcx
00007d07b35e03ae  push rdx
00007d07b35e03af  push rdi
00007d07b35e03b0  push rsi
00007d07b35e03b1  push r8
00007d07b35e03b3  push r9
00007d07b35e03b5  push r10
00007d07b35e03b7  push r11
00007d07b35e03b9  sub rsp, 0xF0
00007d07b35e03c0  vmovaps [rsp], xmm0
00007d07b35e03c5  vmovaps [rsp+0x10], xmm2
00007d07b35e03cb  vmovaps [rsp+0x20], xmm3
00007d07b35e03d1  vmovaps [rsp+0x30], xmm4
00007d07b35e03d7  vmovaps [rsp+0x40], xmm5
00007d07b35e03dd  vmovaps [rsp+0x50], xmm6
00007d07b35e03e3  vmovaps [rsp+0x60], xmm7
00007d07b35e03e9  vmovaps [rsp+0x70], xmm8
00007d07b35e03ef  vmovaps [rsp+0x80], xmm9
00007d07b35e03f8  vmovaps [rsp+0x90], xmm10
00007d07b35e0401  vmovaps [rsp+0xA0], xmm11
00007d07b35e040a  vmovaps [rsp+0xB0], xmm12
00007d07b35e0413  vmovaps [rsp+0xC0], xmm13
00007d07b35e041c  vmovaps [rsp+0xD0], xmm14
00007d07b35e0425  vmovaps [rsp+0xE0], xmm15
00007d07b35e042e  sub rsp, 0x30
00007d07b35e0432  movaps [rsp], xmm1
00007d07b35e0436  movaps [rsp+0x10], xmm13
00007d07b35e043c  movaps [rsp+0x20], xmm9
00007d07b35e0442  lea rdi, [rsp]
00007d07b35e0446  mov esi, 0x00
00007d07b35e044b  mov rax, 0x5D0AA712D530
00007d07b35e0455  call rax
00007d07b35e0457  movaps xmm1, [rsp]
00007d07b35e045b  add rsp, 0x30
00007d07b35e045f  vmovaps xmm0, [rsp]
00007d07b35e0464  vmovaps xmm2, [rsp+0x10]
00007d07b35e046a  vmovaps xmm3, [rsp+0x20]
00007d07b35e0470  vmovaps xmm4, [rsp+0x30]
00007d07b35e0476  vmovaps xmm5, [rsp+0x40]
00007d07b35e047c  vmovaps xmm6, [rsp+0x50]
00007d07b35e0482  vmovaps xmm7, [rsp+0x60]
00007d07b35e0488  vmovaps xmm8, [rsp+0x70]
00007d07b35e048e  vmovaps xmm9, [rsp+0x80]
00007d07b35e0497  vmovaps xmm10, [rsp+0x90]
00007d07b35e04a0  vmovaps xmm11, [rsp+0xA0]
00007d07b35e04a9  vmovaps xmm12, [rsp+0xB0]
00007d07b35e04b2  vmovaps xmm13, [rsp+0xC0]
00007d07b35e04bb  vmovaps xmm14, [rsp+0xD0]
00007d07b35e04c4  vmovaps xmm15, [rsp+0xE0]
00007d07b35e04cd  add rsp, 0xF0
00007d07b35e04d4  pop r11
00007d07b35e04d6  pop r10
00007d07b35e04d8  pop r9
00007d07b35e04da  pop r8
00007d07b35e04dc  pop rsi
00007d07b35e04dd  pop rdi
00007d07b35e04de  pop rdx
00007d07b35e04df  pop rcx
00007d07b35e04e0  pop rax
00007d07b35e04e1  add rsp, 0x08
00007d07b35e04e5  jmp 0x00007D07B35DC5CD
00007d07b35e04ea  sub rsp, 0x08
00007d07b35e04ee  push rax
00007d07b35e04ef  push rcx
00007d07b35e04f0  push rdx
00007d07b35e04f1  push rdi
00007d07b35e04f2  push rsi
00007d07b35e04f3  push r8
00007d07b35e04f5  push r9
00007d07b35e04f7  push r10
00007d07b35e04f9  push r11
00007d07b35e04fb  sub rsp, 0xF0
00007d07b35e0502  vmovaps [rsp], xmm0
00007d07b35e0507  vmovaps [rsp+0x10], xmm1
00007d07b35e050d  vmovaps [rsp+0x20], xmm2
00007d07b35e0513  vmovaps [rsp+0x30], xmm3
00007d07b35e0519  vmovaps [rsp+0x40], xmm4
00007d07b35e051f  vmovaps [rsp+0x50], xmm5
00007d07b35e0525  vmovaps [rsp+0x60], xmm6
00007d07b35e052b  vmovaps [rsp+0x70], xmm7
00007d07b35e0531  vmovaps [rsp+0x80], xmm8
00007d07b35e053a  vmovaps [rsp+0x90], xmm9
00007d07b35e0543  vmovaps [rsp+0xA0], xmm10
00007d07b35e054c  vmovaps [rsp+0xB0], xmm11
00007d07b35e0555  vmovaps [rsp+0xC0], xmm13
00007d07b35e055e  vmovaps [rsp+0xD0], xmm14
00007d07b35e0567  vmovaps [rsp+0xE0], xmm15
00007d07b35e0570  sub rsp, 0x30
00007d07b35e0574  movaps [rsp], xmm12
00007d07b35e0579  movaps [rsp+0x10], xmm7
00007d07b35e057e  movaps [rsp+0x20], xmm13
00007d07b35e0584  lea rdi, [rsp]
00007d07b35e0588  mov esi, 0x00
00007d07b35e058d  mov rax, 0x5D0AA712D530
00007d07b35e0597  call rax
00007d07b35e0599  movaps xmm12, [rsp]
00007d07b35e059e  add rsp, 0x30
00007d07b35e05a2  vmovaps xmm0, [rsp]
00007d07b35e05a7  vmovaps xmm1, [rsp+0x10]
00007d07b35e05ad  vmovaps xmm2, [rsp+0x20]
00007d07b35e05b3  vmovaps xmm3, [rsp+0x30]
00007d07b35e05b9  vmovaps xmm4, [rsp+0x40]
00007d07b35e05bf  vmovaps xmm5, [rsp+0x50]
00007d07b35e05c5  vmovaps xmm6, [rsp+0x60]
00007d07b35e05cb  vmovaps xmm7, [rsp+0x70]
00007d07b35e05d1  vmovaps xmm8, [rsp+0x80]
00007d07b35e05da  vmovaps xmm9, [rsp+0x90]
00007d07b35e05e3  vmovaps xmm10, [rsp+0xA0]
00007d07b35e05ec  vmovaps xmm11, [rsp+0xB0]
00007d07b35e05f5  vmovaps xmm13, [rsp+0xC0]
00007d07b35e05fe  vmovaps xmm14, [rsp+0xD0]
00007d07b35e0607  vmovaps xmm15, [rsp+0xE0]
00007d07b35e0610  add rsp, 0xF0
00007d07b35e0617  pop r11
00007d07b35e0619  pop r10
00007d07b35e061b  pop r9
00007d07b35e061d  pop r8
00007d07b35e061f  pop rsi
00007d07b35e0620  pop rdi
00007d07b35e0621  pop rdx
00007d07b35e0622  pop rcx
00007d07b35e0623  pop rax
00007d07b35e0624  add rsp, 0x08
00007d07b35e0628  jmp 0x00007D07B35DC5F4
00007d07b35e062d  sub rsp, 0x08
00007d07b35e0631  push rax
00007d07b35e0632  push rcx
00007d07b35e0633  push rdx
00007d07b35e0634  push rdi
00007d07b35e0635  push rsi
00007d07b35e0636  push r8
00007d07b35e0638  push r9
00007d07b35e063a  push r10
00007d07b35e063c  push r11
00007d07b35e063e  sub rsp, 0xF0
00007d07b35e0645  vmovaps [rsp], xmm0
00007d07b35e064a  vmovaps [rsp+0x10], xmm1
00007d07b35e0650  vmovaps [rsp+0x20], xmm2
00007d07b35e0656  vmovaps [rsp+0x30], xmm3
00007d07b35e065c  vmovaps [rsp+0x40], xmm4
00007d07b35e0662  vmovaps [rsp+0x50], xmm5
00007d07b35e0668  vmovaps [rsp+0x60], xmm6
00007d07b35e066e  vmovaps [rsp+0x70], xmm7
00007d07b35e0674  vmovaps [rsp+0x80], xmm8
00007d07b35e067d  vmovaps [rsp+0x90], xmm9
00007d07b35e0686  vmovaps [rsp+0xA0], xmm10
00007d07b35e068f  vmovaps [rsp+0xB0], xmm11
00007d07b35e0698  vmovaps [rsp+0xC0], xmm12
00007d07b35e06a1  vmovaps [rsp+0xD0], xmm14
00007d07b35e06aa  vmovaps [rsp+0xE0], xmm15
00007d07b35e06b3  sub rsp, 0x30
00007d07b35e06b7  movaps [rsp], xmm13
00007d07b35e06bc  movaps [rsp+0x10], xmm15
00007d07b35e06c2  movaps [rsp+0x20], xmm8
00007d07b35e06c8  lea rdi, [rsp]
00007d07b35e06cc  mov esi, 0x00
00007d07b35e06d1  mov rax, 0x5D0AA712D530
00007d07b35e06db  call rax
00007d07b35e06dd  movaps xmm13, [rsp]
00007d07b35e06e2  add rsp, 0x30
00007d07b35e06e6  vmovaps xmm0, [rsp]
00007d07b35e06eb  vmovaps xmm1, [rsp+0x10]
00007d07b35e06f1  vmovaps xmm2, [rsp+0x20]
00007d07b35e06f7  vmovaps xmm3, [rsp+0x30]
00007d07b35e06fd  vmovaps xmm4, [rsp+0x40]
00007d07b35e0703  vmovaps xmm5, [rsp+0x50]
00007d07b35e0709  vmovaps xmm6, [rsp+0x60]
00007d07b35e070f  vmovaps xmm7, [rsp+0x70]
00007d07b35e0715  vmovaps xmm8, [rsp+0x80]
00007d07b35e071e  vmovaps xmm9, [rsp+0x90]
00007d07b35e0727  vmovaps xmm10, [rsp+0xA0]
00007d07b35e0730  vmovaps xmm11, [rsp+0xB0]
00007d07b35e0739  vmovaps xmm12, [rsp+0xC0]
00007d07b35e0742  vmovaps xmm14, [rsp+0xD0]
00007d07b35e074b  vmovaps xmm15, [rsp+0xE0]
00007d07b35e0754  add rsp, 0xF0
00007d07b35e075b  pop r11
00007d07b35e075d  pop r10
00007d07b35e075f  pop r9
00007d07b35e0761  pop r8
00007d07b35e0763  pop rsi
00007d07b35e0764  pop rdi
00007d07b35e0765  pop rdx
00007d07b35e0766  pop rcx
00007d07b35e0767  pop rax
00007d07b35e0768  add rsp, 0x08
00007d07b35e076c  jmp 0x00007D07B35DC60F
00007d07b35e0771  sub rsp, 0x08
00007d07b35e0775  push rax
00007d07b35e0776  push rcx
00007d07b35e0777  push rdx
00007d07b35e0778  push rdi
00007d07b35e0779  push rsi
00007d07b35e077a  push r8
00007d07b35e077c  push r9
00007d07b35e077e  push r10
00007d07b35e0780  push r11
00007d07b35e0782  sub rsp, 0xF0
00007d07b35e0789  vmovaps [rsp], xmm0
00007d07b35e078e  vmovaps [rsp+0x10], xmm1
00007d07b35e0794  vmovaps [rsp+0x20], xmm2
00007d07b35e079a  vmovaps [rsp+0x30], xmm3
00007d07b35e07a0  vmovaps [rsp+0x40], xmm4
00007d07b35e07a6  vmovaps [rsp+0x50], xmm5
00007d07b35e07ac  vmovaps [rsp+0x60], xmm6
00007d07b35e07b2  vmovaps [rsp+0x70], xmm7
00007d07b35e07b8  vmovaps [rsp+0x80], xmm9
00007d07b35e07c1  vmovaps [rsp+0x90], xmm10
00007d07b35e07ca  vmovaps [rsp+0xA0], xmm11
00007d07b35e07d3  vmovaps [rsp+0xB0], xmm12
00007d07b35e07dc  vmovaps [rsp+0xC0], xmm13
00007d07b35e07e5  vmovaps [rsp+0xD0], xmm14
00007d07b35e07ee  vmovaps [rsp+0xE0], xmm15
00007d07b35e07f7  sub rsp, 0x30
00007d07b35e07fb  movaps [rsp], xmm8
00007d07b35e0800  movaps [rsp+0x10], xmm15
00007d07b35e0806  movaps [rsp+0x20], xmm9
00007d07b35e080c  lea rdi, [rsp]
00007d07b35e0810  mov esi, 0x00
00007d07b35e0815  mov rax, 0x5D0AA712D530
00007d07b35e081f  call rax
00007d07b35e0821  movaps xmm8, [rsp]
00007d07b35e0826  add rsp, 0x30
00007d07b35e082a  vmovaps xmm0, [rsp]
00007d07b35e082f  vmovaps xmm1, [rsp+0x10]
00007d07b35e0835  vmovaps xmm2, [rsp+0x20]
00007d07b35e083b  vmovaps xmm3, [rsp+0x30]
00007d07b35e0841  vmovaps xmm4, [rsp+0x40]
00007d07b35e0847  vmovaps xmm5, [rsp+0x50]
00007d07b35e084d  vmovaps xmm6, [rsp+0x60]
00007d07b35e0853  vmovaps xmm7, [rsp+0x70]
00007d07b35e0859  vmovaps xmm9, [rsp+0x80]
00007d07b35e0862  vmovaps xmm10, [rsp+0x90]
00007d07b35e086b  vmovaps xmm11, [rsp+0xA0]
00007d07b35e0874  vmovaps xmm12, [rsp+0xB0]
00007d07b35e087d  vmovaps xmm13, [rsp+0xC0]
00007d07b35e0886  vmovaps xmm14, [rsp+0xD0]
00007d07b35e088f  vmovaps xmm15, [rsp+0xE0]
00007d07b35e0898  add rsp, 0xF0
00007d07b35e089f  pop r11
00007d07b35e08a1  pop r10
00007d07b35e08a3  pop r9
00007d07b35e08a5  pop r8
00007d07b35e08a7  pop rsi
00007d07b35e08a8  pop rdi
00007d07b35e08a9  pop rdx
00007d07b35e08aa  pop rcx
00007d07b35e08ab  pop rax
00007d07b35e08ac  add rsp, 0x08
00007d07b35e08b0  jmp 0x00007D07B35DC63D
00007d07b35e08b5  sub rsp, 0x08
00007d07b35e08b9  push rax
00007d07b35e08ba  push rcx
00007d07b35e08bb  push rdx
00007d07b35e08bc  push rdi
00007d07b35e08bd  push rsi
00007d07b35e08be  push r8
00007d07b35e08c0  push r9
00007d07b35e08c2  push r10
00007d07b35e08c4  push r11
00007d07b35e08c6  sub rsp, 0xF0
00007d07b35e08cd  vmovaps [rsp], xmm0
00007d07b35e08d2  vmovaps [rsp+0x10], xmm1
00007d07b35e08d8  vmovaps [rsp+0x20], xmm2
00007d07b35e08de  vmovaps [rsp+0x30], xmm3
00007d07b35e08e4  vmovaps [rsp+0x40], xmm4
00007d07b35e08ea  vmovaps [rsp+0x50], xmm5
00007d07b35e08f0  vmovaps [rsp+0x60], xmm6
00007d07b35e08f6  vmovaps [rsp+0x70], xmm7
00007d07b35e08fc  vmovaps [rsp+0x80], xmm8
00007d07b35e0905  vmovaps [rsp+0x90], xmm9
00007d07b35e090e  vmovaps [rsp+0xA0], xmm10
00007d07b35e0917  vmovaps [rsp+0xB0], xmm11
00007d07b35e0920  vmovaps [rsp+0xC0], xmm12
00007d07b35e0929  vmovaps [rsp+0xD0], xmm13
00007d07b35e0932  vmovaps [rsp+0xE0], xmm14
00007d07b35e093b  sub rsp, 0x30
00007d07b35e093f  movaps [rsp], xmm15
00007d07b35e0944  movaps [rsp+0x10], xmm11
00007d07b35e094a  movaps [rsp+0x20], xmm6
00007d07b35e094f  lea rdi, [rsp]
00007d07b35e0953  mov esi, 0x00
00007d07b35e0958  mov rax, 0x5D0AA712D530
00007d07b35e0962  call rax
00007d07b35e0964  movaps xmm15, [rsp]
00007d07b35e0969  add rsp, 0x30
00007d07b35e096d  vmovaps xmm0, [rsp]
00007d07b35e0972  vmovaps xmm1, [rsp+0x10]
00007d07b35e0978  vmovaps xmm2, [rsp+0x20]
00007d07b35e097e  vmovaps xmm3, [rsp+0x30]
00007d07b35e0984  vmovaps xmm4, [rsp+0x40]
00007d07b35e098a  vmovaps xmm5, [rsp+0x50]
00007d07b35e0990  vmovaps xmm6, [rsp+0x60]
00007d07b35e0996  vmovaps xmm7, [rsp+0x70]
00007d07b35e099c  vmovaps xmm8, [rsp+0x80]
00007d07b35e09a5  vmovaps xmm9, [rsp+0x90]
00007d07b35e09ae  vmovaps xmm10, [rsp+0xA0]
00007d07b35e09b7  vmovaps xmm11, [rsp+0xB0]
00007d07b35e09c0  vmovaps xmm12, [rsp+0xC0]
00007d07b35e09c9  vmovaps xmm13, [rsp+0xD0]
00007d07b35e09d2  vmovaps xmm14, [rsp+0xE0]
00007d07b35e09db  add rsp, 0xF0
00007d07b35e09e2  pop r11
00007d07b35e09e4  pop r10
00007d07b35e09e6  pop r9
00007d07b35e09e8  pop r8
00007d07b35e09ea  pop rsi
00007d07b35e09eb  pop rdi
00007d07b35e09ec  pop rdx
00007d07b35e09ed  pop rcx
00007d07b35e09ee  pop rax
00007d07b35e09ef  add rsp, 0x08
00007d07b35e09f3  jmp 0x00007D07B35DC658
00007d07b35e09f8  sub rsp, 0x08
00007d07b35e09fc  push rax
00007d07b35e09fd  push rcx
00007d07b35e09fe  push rdx
00007d07b35e09ff  push rdi
00007d07b35e0a00  push rsi
00007d07b35e0a01  push r8
00007d07b35e0a03  push r9
00007d07b35e0a05  push r10
00007d07b35e0a07  push r11
00007d07b35e0a09  sub rsp, 0xF0
00007d07b35e0a10  vmovaps [rsp], xmm0
00007d07b35e0a15  vmovaps [rsp+0x10], xmm1
00007d07b35e0a1b  vmovaps [rsp+0x20], xmm2
00007d07b35e0a21  vmovaps [rsp+0x30], xmm3
00007d07b35e0a27  vmovaps [rsp+0x40], xmm4
00007d07b35e0a2d  vmovaps [rsp+0x50], xmm5
00007d07b35e0a33  vmovaps [rsp+0x60], xmm6
00007d07b35e0a39  vmovaps [rsp+0x70], xmm8
00007d07b35e0a3f  vmovaps [rsp+0x80], xmm9
00007d07b35e0a48  vmovaps [rsp+0x90], xmm10
00007d07b35e0a51  vmovaps [rsp+0xA0], xmm11
00007d07b35e0a5a  vmovaps [rsp+0xB0], xmm12
00007d07b35e0a63  vmovaps [rsp+0xC0], xmm13
00007d07b35e0a6c  vmovaps [rsp+0xD0], xmm14
00007d07b35e0a75  vmovaps [rsp+0xE0], xmm15
00007d07b35e0a7e  sub rsp, 0x30
00007d07b35e0a82  movaps [rsp], xmm7
00007d07b35e0a86  movaps [rsp+0x10], xmm11
00007d07b35e0a8c  movaps [rsp+0x20], xmm9
00007d07b35e0a92  lea rdi, [rsp]
00007d07b35e0a96  mov esi, 0x00
00007d07b35e0a9b  mov rax, 0x5D0AA712D530
00007d07b35e0aa5  call rax
00007d07b35e0aa7  movaps xmm7, [rsp]
00007d07b35e0aab  add rsp, 0x30
00007d07b35e0aaf  vmovaps xmm0, [rsp]
00007d07b35e0ab4  vmovaps xmm1, [rsp+0x10]
00007d07b35e0aba  vmovaps xmm2, [rsp+0x20]
00007d07b35e0ac0  vmovaps xmm3, [rsp+0x30]
00007d07b35e0ac6  vmovaps xmm4, [rsp+0x40]
00007d07b35e0acc  vmovaps xmm5, [rsp+0x50]
00007d07b35e0ad2  vmovaps xmm6, [rsp+0x60]
00007d07b35e0ad8  vmovaps xmm8, [rsp+0x70]
00007d07b35e0ade  vmovaps xmm9, [rsp+0x80]
00007d07b35e0ae7  vmovaps xmm10, [rsp+0x90]
00007d07b35e0af0  vmovaps xmm11, [rsp+0xA0]
00007d07b35e0af9  vmovaps xmm12, [rsp+0xB0]
00007d07b35e0b02  vmovaps xmm13, [rsp+0xC0]
00007d07b35e0b0b  vmovaps xmm14, [rsp+0xD0]
00007d07b35e0b14  vmovaps xmm15, [rsp+0xE0]
00007d07b35e0b1d  add rsp, 0xF0
00007d07b35e0b24  pop r11
00007d07b35e0b26  pop r10
00007d07b35e0b28  pop r9
00007d07b35e0b2a  pop r8
00007d07b35e0b2c  pop rsi
00007d07b35e0b2d  pop rdi
00007d07b35e0b2e  pop rdx
00007d07b35e0b2f  pop rcx
00007d07b35e0b30  pop rax
00007d07b35e0b31  add rsp, 0x08
00007d07b35e0b35  jmp 0x00007D07B35DC685
00007d07b35e0b3a  sub rsp, 0x08
00007d07b35e0b3e  push rax
00007d07b35e0b3f  push rcx
00007d07b35e0b40  push rdx
00007d07b35e0b41  push rdi
00007d07b35e0b42  push rsi
00007d07b35e0b43  push r8
00007d07b35e0b45  push r9
00007d07b35e0b47  push r10
00007d07b35e0b49  push r11
00007d07b35e0b4b  sub rsp, 0xF0
00007d07b35e0b52  vmovaps [rsp], xmm0
00007d07b35e0b57  vmovaps [rsp+0x10], xmm1
00007d07b35e0b5d  vmovaps [rsp+0x20], xmm2
00007d07b35e0b63  vmovaps [rsp+0x30], xmm3
00007d07b35e0b69  vmovaps [rsp+0x40], xmm4
00007d07b35e0b6f  vmovaps [rsp+0x50], xmm5
00007d07b35e0b75  vmovaps [rsp+0x60], xmm6
00007d07b35e0b7b  vmovaps [rsp+0x70], xmm7
00007d07b35e0b81  vmovaps [rsp+0x80], xmm8
00007d07b35e0b8a  vmovaps [rsp+0x90], xmm9
00007d07b35e0b93  vmovaps [rsp+0xA0], xmm10
00007d07b35e0b9c  vmovaps [rsp+0xB0], xmm12
00007d07b35e0ba5  vmovaps [rsp+0xC0], xmm13
00007d07b35e0bae  vmovaps [rsp+0xD0], xmm14
00007d07b35e0bb7  vmovaps [rsp+0xE0], xmm15
00007d07b35e0bc0  sub rsp, 0x30
00007d07b35e0bc4  movaps [rsp], xmm11
00007d07b35e0bc9  movaps [rsp+0x10], xmm10
00007d07b35e0bcf  movaps [rsp+0x20], xmm14
00007d07b35e0bd5  lea rdi, [rsp]
00007d07b35e0bd9  mov esi, 0x00
00007d07b35e0bde  mov rax, 0x5D0AA712D530
00007d07b35e0be8  call rax
00007d07b35e0bea  movaps xmm11, [rsp]
00007d07b35e0bef  add rsp, 0x30
00007d07b35e0bf3  vmovaps xmm0, [rsp]
00007d07b35e0bf8  vmovaps xmm1, [rsp+0x10]
00007d07b35e0bfe  vmovaps xmm2, [rsp+0x20]
00007d07b35e0c04  vmovaps xmm3, [rsp+0x30]
00007d07b35e0c0a  vmovaps xmm4, [rsp+0x40]
00007d07b35e0c10  vmovaps xmm5, [rsp+0x50]
00007d07b35e0c16  vmovaps xmm6, [rsp+0x60]
00007d07b35e0c1c  vmovaps xmm7, [rsp+0x70]
00007d07b35e0c22  vmovaps xmm8, [rsp+0x80]
00007d07b35e0c2b  vmovaps xmm9, [rsp+0x90]
00007d07b35e0c34  vmovaps xmm10, [rsp+0xA0]
00007d07b35e0c3d  vmovaps xmm12, [rsp+0xB0]
00007d07b35e0c46  vmovaps xmm13, [rsp+0xC0]
00007d07b35e0c4f  vmovaps xmm14, [rsp+0xD0]
00007d07b35e0c58  vmovaps xmm15, [rsp+0xE0]
00007d07b35e0c61  add rsp, 0xF0
00007d07b35e0c68  pop r11
00007d07b35e0c6a  pop r10
00007d07b35e0c6c  pop r9
00007d07b35e0c6e  pop r8
00007d07b35e0c70  pop rsi
00007d07b35e0c71  pop rdi
00007d07b35e0c72  pop rdx
00007d07b35e0c73  pop rcx
00007d07b35e0c74  pop rax
00007d07b35e0c75  add rsp, 0x08
00007d07b35e0c79  jmp 0x00007D07B35DC6A0
00007d07b35e0c7e  call 0x00007D07B34C33A0
00007d07b35e0c83  jmp 0x00007D07B35DC6AA
00007d07b35e0c88  sub rsp, 0x08
00007d07b35e0c8c  push rax
00007d07b35e0c8d  push rcx
00007d07b35e0c8e  push rdx
00007d07b35e0c8f  push rdi
00007d07b35e0c90  push rsi
00007d07b35e0c91  push r8
00007d07b35e0c93  push r9
00007d07b35e0c95  push r10
00007d07b35e0c97  push r11
00007d07b35e0c99  sub rsp, 0xF0
00007d07b35e0ca0  vmovaps [rsp], xmm0
00007d07b35e0ca5  vmovaps [rsp+0x10], xmm1
00007d07b35e0cab  vmovaps [rsp+0x20], xmm2
00007d07b35e0cb1  vmovaps [rsp+0x30], xmm3
00007d07b35e0cb7  vmovaps [rsp+0x40], xmm4
00007d07b35e0cbd  vmovaps [rsp+0x50], xmm5
00007d07b35e0cc3  vmovaps [rsp+0x60], xmm6
00007d07b35e0cc9  vmovaps [rsp+0x70], xmm7
00007d07b35e0ccf  vmovaps [rsp+0x80], xmm8
00007d07b35e0cd8  vmovaps [rsp+0x90], xmm9
00007d07b35e0ce1  vmovaps [rsp+0xA0], xmm11
00007d07b35e0cea  vmovaps [rsp+0xB0], xmm12
00007d07b35e0cf3  vmovaps [rsp+0xC0], xmm13
00007d07b35e0cfc  vmovaps [rsp+0xD0], xmm14
00007d07b35e0d05  vmovaps [rsp+0xE0], xmm15
00007d07b35e0d0e  sub rsp, 0x30
00007d07b35e0d12  movaps [rsp], xmm10
00007d07b35e0d17  movaps [rsp+0x10], xmm1
00007d07b35e0d1c  movaps [rsp+0x20], xmm12
00007d07b35e0d22  lea rdi, [rsp]
00007d07b35e0d26  mov esi, 0x00
00007d07b35e0d2b  mov rax, 0x5D0AA712D530
00007d07b35e0d35  call rax
00007d07b35e0d37  movaps xmm10, [rsp]
00007d07b35e0d3c  add rsp, 0x30
00007d07b35e0d40  vmovaps xmm0, [rsp]
00007d07b35e0d45  vmovaps xmm1, [rsp+0x10]
00007d07b35e0d4b  vmovaps xmm2, [rsp+0x20]
00007d07b35e0d51  vmovaps xmm3, [rsp+0x30]
00007d07b35e0d57  vmovaps xmm4, [rsp+0x40]
00007d07b35e0d5d  vmovaps xmm5, [rsp+0x50]
00007d07b35e0d63  vmovaps xmm6, [rsp+0x60]
00007d07b35e0d69  vmovaps xmm7, [rsp+0x70]
00007d07b35e0d6f  vmovaps xmm8, [rsp+0x80]
00007d07b35e0d78  vmovaps xmm9, [rsp+0x90]
00007d07b35e0d81  vmovaps xmm11, [rsp+0xA0]
00007d07b35e0d8a  vmovaps xmm12, [rsp+0xB0]
00007d07b35e0d93  vmovaps xmm13, [rsp+0xC0]
00007d07b35e0d9c  vmovaps xmm14, [rsp+0xD0]
00007d07b35e0da5  vmovaps xmm15, [rsp+0xE0]
00007d07b35e0dae  add rsp, 0xF0
00007d07b35e0db5  pop r11
00007d07b35e0db7  pop r10
00007d07b35e0db9  pop r9
00007d07b35e0dbb  pop r8
00007d07b35e0dbd  pop rsi
00007d07b35e0dbe  pop rdi
00007d07b35e0dbf  pop rdx
00007d07b35e0dc0  pop rcx
00007d07b35e0dc1  pop rax
00007d07b35e0dc2  add rsp, 0x08
00007d07b35e0dc6  jmp 0x00007D07B35DC6CD
00007d07b35e0dcb  sub rsp, 0x08
00007d07b35e0dcf  push rax
00007d07b35e0dd0  push rcx
00007d07b35e0dd1  push rdx
00007d07b35e0dd2  push rdi
00007d07b35e0dd3  push rsi
00007d07b35e0dd4  push r8
00007d07b35e0dd6  push r9
00007d07b35e0dd8  push r10
00007d07b35e0dda  push r11
00007d07b35e0ddc  sub rsp, 0xF0
00007d07b35e0de3  vmovaps [rsp], xmm0
00007d07b35e0de8  vmovaps [rsp+0x10], xmm1
00007d07b35e0dee  vmovaps [rsp+0x20], xmm2
00007d07b35e0df4  vmovaps [rsp+0x30], xmm3
00007d07b35e0dfa  vmovaps [rsp+0x40], xmm4
00007d07b35e0e00  vmovaps [rsp+0x50], xmm5
00007d07b35e0e06  vmovaps [rsp+0x60], xmm6
00007d07b35e0e0c  vmovaps [rsp+0x70], xmm7
00007d07b35e0e12  vmovaps [rsp+0x80], xmm8
00007d07b35e0e1b  vmovaps [rsp+0x90], xmm9
00007d07b35e0e24  vmovaps [rsp+0xA0], xmm10
00007d07b35e0e2d  vmovaps [rsp+0xB0], xmm11
00007d07b35e0e36  vmovaps [rsp+0xC0], xmm13
00007d07b35e0e3f  vmovaps [rsp+0xD0], xmm14
00007d07b35e0e48  vmovaps [rsp+0xE0], xmm15
00007d07b35e0e51  sub rsp, 0x30
00007d07b35e0e55  movaps [rsp], xmm12
00007d07b35e0e5a  movaps [rsp+0x10], xmm14
00007d07b35e0e60  movaps [rsp+0x20], xmm1
00007d07b35e0e65  lea rdi, [rsp]
00007d07b35e0e69  mov esi, 0x00
00007d07b35e0e6e  mov rax, 0x5D0AA712D530
00007d07b35e0e78  call rax
00007d07b35e0e7a  movaps xmm12, [rsp]
00007d07b35e0e7f  add rsp, 0x30
00007d07b35e0e83  vmovaps xmm0, [rsp]
00007d07b35e0e88  vmovaps xmm1, [rsp+0x10]
00007d07b35e0e8e  vmovaps xmm2, [rsp+0x20]
00007d07b35e0e94  vmovaps xmm3, [rsp+0x30]
00007d07b35e0e9a  vmovaps xmm4, [rsp+0x40]
00007d07b35e0ea0  vmovaps xmm5, [rsp+0x50]
00007d07b35e0ea6  vmovaps xmm6, [rsp+0x60]
00007d07b35e0eac  vmovaps xmm7, [rsp+0x70]
00007d07b35e0eb2  vmovaps xmm8, [rsp+0x80]
00007d07b35e0ebb  vmovaps xmm9, [rsp+0x90]
00007d07b35e0ec4  vmovaps xmm10, [rsp+0xA0]
00007d07b35e0ecd  vmovaps xmm11, [rsp+0xB0]
00007d07b35e0ed6  vmovaps xmm13, [rsp+0xC0]
00007d07b35e0edf  vmovaps xmm14, [rsp+0xD0]
00007d07b35e0ee8  vmovaps xmm15, [rsp+0xE0]
00007d07b35e0ef1  add rsp, 0xF0
00007d07b35e0ef8  pop r11
00007d07b35e0efa  pop r10
00007d07b35e0efc  pop r9
00007d07b35e0efe  pop r8
00007d07b35e0f00  pop rsi
00007d07b35e0f01  pop rdi
00007d07b35e0f02  pop rdx
00007d07b35e0f03  pop rcx
00007d07b35e0f04  pop rax
00007d07b35e0f05  add rsp, 0x08
00007d07b35e0f09  jmp 0x00007D07B35DC6FC
00007d07b35e0f0e  sub rsp, 0x08
00007d07b35e0f12  push rax
00007d07b35e0f13  push rcx
00007d07b35e0f14  push rdx
00007d07b35e0f15  push rdi
00007d07b35e0f16  push rsi
00007d07b35e0f17  push r8
00007d07b35e0f19  push r9
00007d07b35e0f1b  push r10
00007d07b35e0f1d  push r11
00007d07b35e0f1f  sub rsp, 0xF0
00007d07b35e0f26  vmovaps [rsp], xmm0
00007d07b35e0f2b  vmovaps [rsp+0x10], xmm1
00007d07b35e0f31  vmovaps [rsp+0x20], xmm2
00007d07b35e0f37  vmovaps [rsp+0x30], xmm3
00007d07b35e0f3d  vmovaps [rsp+0x40], xmm4
00007d07b35e0f43  vmovaps [rsp+0x50], xmm5
00007d07b35e0f49  vmovaps [rsp+0x60], xmm6
00007d07b35e0f4f  vmovaps [rsp+0x70], xmm7
00007d07b35e0f55  vmovaps [rsp+0x80], xmm8
00007d07b35e0f5e  vmovaps [rsp+0x90], xmm9
00007d07b35e0f67  vmovaps [rsp+0xA0], xmm10
00007d07b35e0f70  vmovaps [rsp+0xB0], xmm11
00007d07b35e0f79  vmovaps [rsp+0xC0], xmm12
00007d07b35e0f82  vmovaps [rsp+0xD0], xmm13
00007d07b35e0f8b  vmovaps [rsp+0xE0], xmm15
00007d07b35e0f94  sub rsp, 0x30
00007d07b35e0f98  movaps [rsp], xmm14
00007d07b35e0f9d  movaps [rsp+0x10], xmm9
00007d07b35e0fa3  movaps [rsp+0x20], xmm1
00007d07b35e0fa8  lea rdi, [rsp]
00007d07b35e0fac  mov esi, 0x00
00007d07b35e0fb1  mov rax, 0x5D0AA712D530
00007d07b35e0fbb  call rax
00007d07b35e0fbd  movaps xmm14, [rsp]
00007d07b35e0fc2  add rsp, 0x30
00007d07b35e0fc6  vmovaps xmm0, [rsp]
00007d07b35e0fcb  vmovaps xmm1, [rsp+0x10]
00007d07b35e0fd1  vmovaps xmm2, [rsp+0x20]
00007d07b35e0fd7  vmovaps xmm3, [rsp+0x30]
00007d07b35e0fdd  vmovaps xmm4, [rsp+0x40]
00007d07b35e0fe3  vmovaps xmm5, [rsp+0x50]
00007d07b35e0fe9  vmovaps xmm6, [rsp+0x60]
00007d07b35e0fef  vmovaps xmm7, [rsp+0x70]
00007d07b35e0ff5  vmovaps xmm8, [rsp+0x80]
00007d07b35e0ffe  vmovaps xmm9, [rsp+0x90]
00007d07b35e1007  vmovaps xmm10, [rsp+0xA0]
00007d07b35e1010  vmovaps xmm11, [rsp+0xB0]
00007d07b35e1019  vmovaps xmm12, [rsp+0xC0]
00007d07b35e1022  vmovaps xmm13, [rsp+0xD0]
00007d07b35e102b  vmovaps xmm15, [rsp+0xE0]
00007d07b35e1034  add rsp, 0xF0
00007d07b35e103b  pop r11
00007d07b35e103d  pop r10
00007d07b35e103f  pop r9
00007d07b35e1041  pop r8
00007d07b35e1043  pop rsi
00007d07b35e1044  pop rdi
00007d07b35e1045  pop rdx
00007d07b35e1046  pop rcx
00007d07b35e1047  pop rax
00007d07b35e1048  add rsp, 0x08
00007d07b35e104c  jmp 0x00007D07B35DC72B
00007d07b35e1051  sub rsp, 0x08
00007d07b35e1055  push rax
00007d07b35e1056  push rcx
00007d07b35e1057  push rdx
00007d07b35e1058  push rdi
00007d07b35e1059  push rsi
00007d07b35e105a  push r8
00007d07b35e105c  push r9
00007d07b35e105e  push r10
00007d07b35e1060  push r11
00007d07b35e1062  sub rsp, 0xF0
00007d07b35e1069  vmovaps [rsp], xmm0
00007d07b35e106e  vmovaps [rsp+0x10], xmm2
00007d07b35e1074  vmovaps [rsp+0x20], xmm3
00007d07b35e107a  vmovaps [rsp+0x30], xmm4
00007d07b35e1080  vmovaps [rsp+0x40], xmm5
00007d07b35e1086  vmovaps [rsp+0x50], xmm6
00007d07b35e108c  vmovaps [rsp+0x60], xmm7
00007d07b35e1092  vmovaps [rsp+0x70], xmm8
00007d07b35e1098  vmovaps [rsp+0x80], xmm9
00007d07b35e10a1  vmovaps [rsp+0x90], xmm10
00007d07b35e10aa  vmovaps [rsp+0xA0], xmm11
00007d07b35e10b3  vmovaps [rsp+0xB0], xmm12
00007d07b35e10bc  vmovaps [rsp+0xC0], xmm13
00007d07b35e10c5  vmovaps [rsp+0xD0], xmm14
00007d07b35e10ce  vmovaps [rsp+0xE0], xmm15
00007d07b35e10d7  sub rsp, 0x30
00007d07b35e10db  movaps [rsp], xmm1
00007d07b35e10df  movaps [rsp+0x10], xmm13
00007d07b35e10e5  movaps [rsp+0x20], xmm8
00007d07b35e10eb  lea rdi, [rsp]
00007d07b35e10ef  mov esi, 0x00
00007d07b35e10f4  mov rax, 0x5D0AA712D530
00007d07b35e10fe  call rax
00007d07b35e1100  movaps xmm1, [rsp]
00007d07b35e1104  add rsp, 0x30
00007d07b35e1108  vmovaps xmm0, [rsp]
00007d07b35e110d  vmovaps xmm2, [rsp+0x10]
00007d07b35e1113  vmovaps xmm3, [rsp+0x20]
00007d07b35e1119  vmovaps xmm4, [rsp+0x30]
00007d07b35e111f  vmovaps xmm5, [rsp+0x40]
00007d07b35e1125  vmovaps xmm6, [rsp+0x50]
00007d07b35e112b  vmovaps xmm7, [rsp+0x60]
00007d07b35e1131  vmovaps xmm8, [rsp+0x70]
00007d07b35e1137  vmovaps xmm9, [rsp+0x80]
00007d07b35e1140  vmovaps xmm10, [rsp+0x90]
00007d07b35e1149  vmovaps xmm11, [rsp+0xA0]
00007d07b35e1152  vmovaps xmm12, [rsp+0xB0]
00007d07b35e115b  vmovaps xmm13, [rsp+0xC0]
00007d07b35e1164  vmovaps xmm14, [rsp+0xD0]
00007d07b35e116d  vmovaps xmm15, [rsp+0xE0]
00007d07b35e1176  add rsp, 0xF0
00007d07b35e117d  pop r11
00007d07b35e117f  pop r10
00007d07b35e1181  pop r9
00007d07b35e1183  pop r8
00007d07b35e1185  pop rsi
00007d07b35e1186  pop rdi
00007d07b35e1187  pop rdx
00007d07b35e1188  pop rcx
00007d07b35e1189  pop rax
00007d07b35e118a  add rsp, 0x08
00007d07b35e118e  jmp 0x00007D07B35DC74D
00007d07b35e1193  call 0x00007D07B340C260
00007d07b35e1198  jmp 0x00007D07B35DC75B
00007d07b35e119d  call 0x00007D07B34BD750
00007d07b35e11a2  jmp 0x00007D07B35DC765
00007d07b35e11a7  sub rsp, 0x08
00007d07b35e11ab  push rax
00007d07b35e11ac  push rcx
00007d07b35e11ad  push rdx
00007d07b35e11ae  push rdi
00007d07b35e11af  push rsi
00007d07b35e11b0  push r8
00007d07b35e11b2  push r9
00007d07b35e11b4  push r10
00007d07b35e11b6  push r11
00007d07b35e11b8  sub rsp, 0xF0
00007d07b35e11bf  vmovaps [rsp], xmm0
00007d07b35e11c4  vmovaps [rsp+0x10], xmm1
00007d07b35e11ca  vmovaps [rsp+0x20], xmm2
00007d07b35e11d0  vmovaps [rsp+0x30], xmm3
00007d07b35e11d6  vmovaps [rsp+0x40], xmm4
00007d07b35e11dc  vmovaps [rsp+0x50], xmm5
00007d07b35e11e2  vmovaps [rsp+0x60], xmm6
00007d07b35e11e8  vmovaps [rsp+0x70], xmm7
00007d07b35e11ee  vmovaps [rsp+0x80], xmm9
00007d07b35e11f7  vmovaps [rsp+0x90], xmm10
00007d07b35e1200  vmovaps [rsp+0xA0], xmm11
00007d07b35e1209  vmovaps [rsp+0xB0], xmm12
00007d07b35e1212  vmovaps [rsp+0xC0], xmm13
00007d07b35e121b  vmovaps [rsp+0xD0], xmm14
00007d07b35e1224  vmovaps [rsp+0xE0], xmm15
00007d07b35e122d  sub rsp, 0x30
00007d07b35e1231  movaps [rsp], xmm8
00007d07b35e1236  movaps [rsp+0x10], xmm15
00007d07b35e123c  movaps [rsp+0x20], xmm7
00007d07b35e1241  lea rdi, [rsp]
00007d07b35e1245  mov esi, 0x00
00007d07b35e124a  mov rax, 0x5D0AA712D530
00007d07b35e1254  call rax
00007d07b35e1256  movaps xmm8, [rsp]
00007d07b35e125b  add rsp, 0x30
00007d07b35e125f  vmovaps xmm0, [rsp]
00007d07b35e1264  vmovaps xmm1, [rsp+0x10]
00007d07b35e126a  vmovaps xmm2, [rsp+0x20]
00007d07b35e1270  vmovaps xmm3, [rsp+0x30]
00007d07b35e1276  vmovaps xmm4, [rsp+0x40]
00007d07b35e127c  vmovaps xmm5, [rsp+0x50]
00007d07b35e1282  vmovaps xmm6, [rsp+0x60]
00007d07b35e1288  vmovaps xmm7, [rsp+0x70]
00007d07b35e128e  vmovaps xmm9, [rsp+0x80]
00007d07b35e1297  vmovaps xmm10, [rsp+0x90]
00007d07b35e12a0  vmovaps xmm11, [rsp+0xA0]
00007d07b35e12a9  vmovaps xmm12, [rsp+0xB0]
00007d07b35e12b2  vmovaps xmm13, [rsp+0xC0]
00007d07b35e12bb  vmovaps xmm14, [rsp+0xD0]
00007d07b35e12c4  vmovaps xmm15, [rsp+0xE0]
00007d07b35e12cd  add rsp, 0xF0
00007d07b35e12d4  pop r11
00007d07b35e12d6  pop r10
00007d07b35e12d8  pop r9
00007d07b35e12da  pop r8
00007d07b35e12dc  pop rsi
00007d07b35e12dd  pop rdi
00007d07b35e12de  pop rdx
00007d07b35e12df  pop rcx
00007d07b35e12e0  pop rax
00007d07b35e12e1  add rsp, 0x08
00007d07b35e12e5  jmp 0x00007D07B35DC787
00007d07b35e12ea  sub rsp, 0x08
00007d07b35e12ee  push rax
00007d07b35e12ef  push rcx
00007d07b35e12f0  push rdx
00007d07b35e12f1  push rdi
00007d07b35e12f2  push rsi
00007d07b35e12f3  push r8
00007d07b35e12f5  push r9
00007d07b35e12f7  push r10
00007d07b35e12f9  push r11
00007d07b35e12fb  sub rsp, 0xF0
00007d07b35e1302  vmovaps [rsp], xmm0
00007d07b35e1307  vmovaps [rsp+0x10], xmm1
00007d07b35e130d  vmovaps [rsp+0x20], xmm2
00007d07b35e1313  vmovaps [rsp+0x30], xmm3
00007d07b35e1319  vmovaps [rsp+0x40], xmm4
00007d07b35e131f  vmovaps [rsp+0x50], xmm5
00007d07b35e1325  vmovaps [rsp+0x60], xmm6
00007d07b35e132b  vmovaps [rsp+0x70], xmm8
00007d07b35e1331  vmovaps [rsp+0x80], xmm9
00007d07b35e133a  vmovaps [rsp+0x90], xmm10
00007d07b35e1343  vmovaps [rsp+0xA0], xmm11
00007d07b35e134c  vmovaps [rsp+0xB0], xmm12
00007d07b35e1355  vmovaps [rsp+0xC0], xmm13
00007d07b35e135e  vmovaps [rsp+0xD0], xmm14
00007d07b35e1367  vmovaps [rsp+0xE0], xmm15
00007d07b35e1370  sub rsp, 0x30
00007d07b35e1374  movaps [rsp], xmm7
00007d07b35e1378  movaps [rsp+0x10], xmm9
00007d07b35e137e  movaps [rsp+0x20], xmm15
00007d07b35e1384  lea rdi, [rsp]
00007d07b35e1388  mov esi, 0x00
00007d07b35e138d  mov rax, 0x5D0AA712D530
00007d07b35e1397  call rax
00007d07b35e1399  movaps xmm7, [rsp]
00007d07b35e139d  add rsp, 0x30
00007d07b35e13a1  vmovaps xmm0, [rsp]
00007d07b35e13a6  vmovaps xmm1, [rsp+0x10]
00007d07b35e13ac  vmovaps xmm2, [rsp+0x20]
00007d07b35e13b2  vmovaps xmm3, [rsp+0x30]
00007d07b35e13b8  vmovaps xmm4, [rsp+0x40]
00007d07b35e13be  vmovaps xmm5, [rsp+0x50]
00007d07b35e13c4  vmovaps xmm6, [rsp+0x60]
00007d07b35e13ca  vmovaps xmm8, [rsp+0x70]
00007d07b35e13d0  vmovaps xmm9, [rsp+0x80]
00007d07b35e13d9  vmovaps xmm10, [rsp+0x90]
00007d07b35e13e2  vmovaps xmm11, [rsp+0xA0]
00007d07b35e13eb  vmovaps xmm12, [rsp+0xB0]
00007d07b35e13f4  vmovaps xmm13, [rsp+0xC0]
00007d07b35e13fd  vmovaps xmm14, [rsp+0xD0]
00007d07b35e1406  vmovaps xmm15, [rsp+0xE0]
00007d07b35e140f  add rsp, 0xF0
00007d07b35e1416  pop r11
00007d07b35e1418  pop r10
00007d07b35e141a  pop r9
00007d07b35e141c  pop r8
00007d07b35e141e  pop rsi
00007d07b35e141f  pop rdi
00007d07b35e1420  pop rdx
00007d07b35e1421  pop rcx
00007d07b35e1422  pop rax
00007d07b35e1423  add rsp, 0x08
00007d07b35e1427  jmp 0x00007D07B35DC7B4
00007d07b35e142c  sub rsp, 0x08
00007d07b35e1430  push rax
00007d07b35e1431  push rcx
00007d07b35e1432  push rdx
00007d07b35e1433  push rdi
00007d07b35e1434  push rsi
00007d07b35e1435  push r8
00007d07b35e1437  push r9
00007d07b35e1439  push r10
00007d07b35e143b  push r11
00007d07b35e143d  sub rsp, 0xF0
00007d07b35e1444  vmovaps [rsp], xmm0
00007d07b35e1449  vmovaps [rsp+0x10], xmm1
00007d07b35e144f  vmovaps [rsp+0x20], xmm2
00007d07b35e1455  vmovaps [rsp+0x30], xmm3
00007d07b35e145b  vmovaps [rsp+0x40], xmm4
00007d07b35e1461  vmovaps [rsp+0x50], xmm5
00007d07b35e1467  vmovaps [rsp+0x60], xmm6
00007d07b35e146d  vmovaps [rsp+0x70], xmm7
00007d07b35e1473  vmovaps [rsp+0x80], xmm8
00007d07b35e147c  vmovaps [rsp+0x90], xmm10
00007d07b35e1485  vmovaps [rsp+0xA0], xmm11
00007d07b35e148e  vmovaps [rsp+0xB0], xmm12
00007d07b35e1497  vmovaps [rsp+0xC0], xmm13
00007d07b35e14a0  vmovaps [rsp+0xD0], xmm14
00007d07b35e14a9  vmovaps [rsp+0xE0], xmm15
00007d07b35e14b2  sub rsp, 0x30
00007d07b35e14b6  movaps [rsp], xmm9
00007d07b35e14bb  movaps [rsp+0x10], xmm13
00007d07b35e14c1  movaps [rsp+0x20], xmm15
00007d07b35e14c7  lea rdi, [rsp]
00007d07b35e14cb  mov esi, 0x00
00007d07b35e14d0  mov rax, 0x5D0AA712D530
00007d07b35e14da  call rax
00007d07b35e14dc  movaps xmm9, [rsp]
00007d07b35e14e1  add rsp, 0x30
00007d07b35e14e5  vmovaps xmm0, [rsp]
00007d07b35e14ea  vmovaps xmm1, [rsp+0x10]
00007d07b35e14f0  vmovaps xmm2, [rsp+0x20]
00007d07b35e14f6  vmovaps xmm3, [rsp+0x30]
00007d07b35e14fc  vmovaps xmm4, [rsp+0x40]
00007d07b35e1502  vmovaps xmm5, [rsp+0x50]
00007d07b35e1508  vmovaps xmm6, [rsp+0x60]
00007d07b35e150e  vmovaps xmm7, [rsp+0x70]
00007d07b35e1514  vmovaps xmm8, [rsp+0x80]
00007d07b35e151d  vmovaps xmm10, [rsp+0x90]
00007d07b35e1526  vmovaps xmm11, [rsp+0xA0]
00007d07b35e152f  vmovaps xmm12, [rsp+0xB0]
00007d07b35e1538  vmovaps xmm13, [rsp+0xC0]
00007d07b35e1541  vmovaps xmm14, [rsp+0xD0]
00007d07b35e154a  vmovaps xmm15, [rsp+0xE0]
00007d07b35e1553  add rsp, 0xF0
00007d07b35e155a  pop r11
00007d07b35e155c  pop r10
00007d07b35e155e  pop r9
00007d07b35e1560  pop r8
00007d07b35e1562  pop rsi
00007d07b35e1563  pop rdi
00007d07b35e1564  pop rdx
00007d07b35e1565  pop rcx
00007d07b35e1566  pop rax
00007d07b35e1567  add rsp, 0x08
00007d07b35e156b  jmp 0x00007D07B35DC7E2
00007d07b35e1570  sub rsp, 0x08
00007d07b35e1574  push rax
00007d07b35e1575  push rcx
00007d07b35e1576  push rdx
00007d07b35e1577  push rdi
00007d07b35e1578  push rsi
00007d07b35e1579  push r8
00007d07b35e157b  push r9
00007d07b35e157d  push r10
00007d07b35e157f  push r11
00007d07b35e1581  sub rsp, 0xF0
00007d07b35e1588  vmovaps [rsp], xmm0
00007d07b35e158d  vmovaps [rsp+0x10], xmm1
00007d07b35e1593  vmovaps [rsp+0x20], xmm2
00007d07b35e1599  vmovaps [rsp+0x30], xmm3
00007d07b35e159f  vmovaps [rsp+0x40], xmm4
00007d07b35e15a5  vmovaps [rsp+0x50], xmm5
00007d07b35e15ab  vmovaps [rsp+0x60], xmm6
00007d07b35e15b1  vmovaps [rsp+0x70], xmm7
00007d07b35e15b7  vmovaps [rsp+0x80], xmm8
00007d07b35e15c0  vmovaps [rsp+0x90], xmm9
00007d07b35e15c9  vmovaps [rsp+0xA0], xmm10
00007d07b35e15d2  vmovaps [rsp+0xB0], xmm11
00007d07b35e15db  vmovaps [rsp+0xC0], xmm12
00007d07b35e15e4  vmovaps [rsp+0xD0], xmm13
00007d07b35e15ed  vmovaps [rsp+0xE0], xmm14
00007d07b35e15f6  sub rsp, 0x30
00007d07b35e15fa  movaps [rsp], xmm15
00007d07b35e15ff  movaps [rsp+0x10], xmm11
00007d07b35e1605  movaps [rsp+0x20], xmm12
00007d07b35e160b  lea rdi, [rsp]
00007d07b35e160f  mov esi, 0x00
00007d07b35e1614  mov rax, 0x5D0AA712D530
00007d07b35e161e  call rax
00007d07b35e1620  movaps xmm15, [rsp]
00007d07b35e1625  add rsp, 0x30
00007d07b35e1629  vmovaps xmm0, [rsp]
00007d07b35e162e  vmovaps xmm1, [rsp+0x10]
00007d07b35e1634  vmovaps xmm2, [rsp+0x20]
00007d07b35e163a  vmovaps xmm3, [rsp+0x30]
00007d07b35e1640  vmovaps xmm4, [rsp+0x40]
00007d07b35e1646  vmovaps xmm5, [rsp+0x50]
00007d07b35e164c  vmovaps xmm6, [rsp+0x60]
00007d07b35e1652  vmovaps xmm7, [rsp+0x70]
00007d07b35e1658  vmovaps xmm8, [rsp+0x80]
00007d07b35e1661  vmovaps xmm9, [rsp+0x90]
00007d07b35e166a  vmovaps xmm10, [rsp+0xA0]
00007d07b35e1673  vmovaps xmm11, [rsp+0xB0]
00007d07b35e167c  vmovaps xmm12, [rsp+0xC0]
00007d07b35e1685  vmovaps xmm13, [rsp+0xD0]
00007d07b35e168e  vmovaps xmm14, [rsp+0xE0]
00007d07b35e1697  add rsp, 0xF0
00007d07b35e169e  pop r11
00007d07b35e16a0  pop r10
00007d07b35e16a2  pop r9
00007d07b35e16a4  pop r8
00007d07b35e16a6  pop rsi
00007d07b35e16a7  pop rdi
00007d07b35e16a8  pop rdx
00007d07b35e16a9  pop rcx
00007d07b35e16aa  pop rax
00007d07b35e16ab  add rsp, 0x08
00007d07b35e16af  jmp 0x00007D07B35DC7FD
00007d07b35e16b4  sub rsp, 0x08
00007d07b35e16b8  push rax
00007d07b35e16b9  push rcx
00007d07b35e16ba  push rdx
00007d07b35e16bb  push rdi
00007d07b35e16bc  push rsi
00007d07b35e16bd  push r8
00007d07b35e16bf  push r9
00007d07b35e16c1  push r10
00007d07b35e16c3  push r11
00007d07b35e16c5  sub rsp, 0xF0
00007d07b35e16cc  vmovaps [rsp], xmm0
00007d07b35e16d1  vmovaps [rsp+0x10], xmm1
00007d07b35e16d7  vmovaps [rsp+0x20], xmm2
00007d07b35e16dd  vmovaps [rsp+0x30], xmm3
00007d07b35e16e3  vmovaps [rsp+0x40], xmm4
00007d07b35e16e9  vmovaps [rsp+0x50], xmm5
00007d07b35e16ef  vmovaps [rsp+0x60], xmm6
00007d07b35e16f5  vmovaps [rsp+0x70], xmm7
00007d07b35e16fb  vmovaps [rsp+0x80], xmm8
00007d07b35e1704  vmovaps [rsp+0x90], xmm9
00007d07b35e170d  vmovaps [rsp+0xA0], xmm10
00007d07b35e1716  vmovaps [rsp+0xB0], xmm11
00007d07b35e171f  vmovaps [rsp+0xC0], xmm12
00007d07b35e1728  vmovaps [rsp+0xD0], xmm14
00007d07b35e1731  vmovaps [rsp+0xE0], xmm15
00007d07b35e173a  sub rsp, 0x30
00007d07b35e173e  movaps [rsp], xmm13
00007d07b35e1743  movaps [rsp+0x10], xmm10
00007d07b35e1749  movaps [rsp+0x20], xmm14
00007d07b35e174f  lea rdi, [rsp]
00007d07b35e1753  mov esi, 0x00
00007d07b35e1758  mov rax, 0x5D0AA712D530
00007d07b35e1762  call rax
00007d07b35e1764  movaps xmm13, [rsp]
00007d07b35e1769  add rsp, 0x30
00007d07b35e176d  vmovaps xmm0, [rsp]
00007d07b35e1772  vmovaps xmm1, [rsp+0x10]
00007d07b35e1778  vmovaps xmm2, [rsp+0x20]
00007d07b35e177e  vmovaps xmm3, [rsp+0x30]
00007d07b35e1784  vmovaps xmm4, [rsp+0x40]
00007d07b35e178a  vmovaps xmm5, [rsp+0x50]
00007d07b35e1790  vmovaps xmm6, [rsp+0x60]
00007d07b35e1796  vmovaps xmm7, [rsp+0x70]
00007d07b35e179c  vmovaps xmm8, [rsp+0x80]
00007d07b35e17a5  vmovaps xmm9, [rsp+0x90]
00007d07b35e17ae  vmovaps xmm10, [rsp+0xA0]
00007d07b35e17b7  vmovaps xmm11, [rsp+0xB0]
00007d07b35e17c0  vmovaps xmm12, [rsp+0xC0]
00007d07b35e17c9  vmovaps xmm14, [rsp+0xD0]
00007d07b35e17d2  vmovaps xmm15, [rsp+0xE0]
00007d07b35e17db  add rsp, 0xF0
00007d07b35e17e2  pop r11
00007d07b35e17e4  pop r10
00007d07b35e17e6  pop r9
00007d07b35e17e8  pop r8
00007d07b35e17ea  pop rsi
00007d07b35e17eb  pop rdi
00007d07b35e17ec  pop rdx
00007d07b35e17ed  pop rcx
00007d07b35e17ee  pop rax
00007d07b35e17ef  add rsp, 0x08
00007d07b35e17f3  jmp 0x00007D07B35DC820
00007d07b35e17f8  sub rsp, 0x08
00007d07b35e17fc  push rax
00007d07b35e17fd  push rcx
00007d07b35e17fe  push rdx
00007d07b35e17ff  push rdi
00007d07b35e1800  push rsi
00007d07b35e1801  push r8
00007d07b35e1803  push r9
00007d07b35e1805  push r10
00007d07b35e1807  push r11
00007d07b35e1809  sub rsp, 0xF0
00007d07b35e1810  vmovaps [rsp], xmm0
00007d07b35e1815  vmovaps [rsp+0x10], xmm1
00007d07b35e181b  vmovaps [rsp+0x20], xmm2
00007d07b35e1821  vmovaps [rsp+0x30], xmm3
00007d07b35e1827  vmovaps [rsp+0x40], xmm4
00007d07b35e182d  vmovaps [rsp+0x50], xmm5
00007d07b35e1833  vmovaps [rsp+0x60], xmm6
00007d07b35e1839  vmovaps [rsp+0x70], xmm7
00007d07b35e183f  vmovaps [rsp+0x80], xmm8
00007d07b35e1848  vmovaps [rsp+0x90], xmm9
00007d07b35e1851  vmovaps [rsp+0xA0], xmm10
00007d07b35e185a  vmovaps [rsp+0xB0], xmm11
00007d07b35e1863  vmovaps [rsp+0xC0], xmm12
00007d07b35e186c  vmovaps [rsp+0xD0], xmm13
00007d07b35e1875  vmovaps [rsp+0xE0], xmm15
00007d07b35e187e  sub rsp, 0x30
00007d07b35e1882  movaps [rsp], xmm14
00007d07b35e1887  movaps [rsp+0x10], xmm1
00007d07b35e188c  movaps [rsp+0x20], xmm7
00007d07b35e1891  lea rdi, [rsp]
00007d07b35e1895  mov esi, 0x00
00007d07b35e189a  mov rax, 0x5D0AA712D530
00007d07b35e18a4  call rax
00007d07b35e18a6  movaps xmm14, [rsp]
00007d07b35e18ab  add rsp, 0x30
00007d07b35e18af  vmovaps xmm0, [rsp]
00007d07b35e18b4  vmovaps xmm1, [rsp+0x10]
00007d07b35e18ba  vmovaps xmm2, [rsp+0x20]
00007d07b35e18c0  vmovaps xmm3, [rsp+0x30]
00007d07b35e18c6  vmovaps xmm4, [rsp+0x40]
00007d07b35e18cc  vmovaps xmm5, [rsp+0x50]
00007d07b35e18d2  vmovaps xmm6, [rsp+0x60]
00007d07b35e18d8  vmovaps xmm7, [rsp+0x70]
00007d07b35e18de  vmovaps xmm8, [rsp+0x80]
00007d07b35e18e7  vmovaps xmm9, [rsp+0x90]
00007d07b35e18f0  vmovaps xmm10, [rsp+0xA0]
00007d07b35e18f9  vmovaps xmm11, [rsp+0xB0]
00007d07b35e1902  vmovaps xmm12, [rsp+0xC0]
00007d07b35e190b  vmovaps xmm13, [rsp+0xD0]
00007d07b35e1914  vmovaps xmm15, [rsp+0xE0]
00007d07b35e191d  add rsp, 0xF0
00007d07b35e1924  pop r11
00007d07b35e1926  pop r10
00007d07b35e1928  pop r9
00007d07b35e192a  pop r8
00007d07b35e192c  pop rsi
00007d07b35e192d  pop rdi
00007d07b35e192e  pop rdx
00007d07b35e192f  pop rcx
00007d07b35e1930  pop rax
00007d07b35e1931  add rsp, 0x08
00007d07b35e1935  jmp 0x00007D07B35DC843
00007d07b35e193a  sub rsp, 0x08
00007d07b35e193e  push rax
00007d07b35e193f  push rcx
00007d07b35e1940  push rdx
00007d07b35e1941  push rdi
00007d07b35e1942  push rsi
00007d07b35e1943  push r8
00007d07b35e1945  push r9
00007d07b35e1947  push r10
00007d07b35e1949  push r11
00007d07b35e194b  sub rsp, 0xF0
00007d07b35e1952  vmovaps [rsp], xmm0
00007d07b35e1957  vmovaps [rsp+0x10], xmm2
00007d07b35e195d  vmovaps [rsp+0x20], xmm3
00007d07b35e1963  vmovaps [rsp+0x30], xmm4
00007d07b35e1969  vmovaps [rsp+0x40], xmm5
00007d07b35e196f  vmovaps [rsp+0x50], xmm6
00007d07b35e1975  vmovaps [rsp+0x60], xmm7
00007d07b35e197b  vmovaps [rsp+0x70], xmm8
00007d07b35e1981  vmovaps [rsp+0x80], xmm9
00007d07b35e198a  vmovaps [rsp+0x90], xmm10
00007d07b35e1993  vmovaps [rsp+0xA0], xmm11
00007d07b35e199c  vmovaps [rsp+0xB0], xmm12
00007d07b35e19a5  vmovaps [rsp+0xC0], xmm13
00007d07b35e19ae  vmovaps [rsp+0xD0], xmm14
00007d07b35e19b7  vmovaps [rsp+0xE0], xmm15
00007d07b35e19c0  sub rsp, 0x30
00007d07b35e19c4  movaps [rsp], xmm1
00007d07b35e19c8  movaps [rsp+0x10], xmm8
00007d07b35e19ce  movaps [rsp+0x20], xmm9
00007d07b35e19d4  lea rdi, [rsp]
00007d07b35e19d8  mov esi, 0x00
00007d07b35e19dd  mov rax, 0x5D0AA712D530
00007d07b35e19e7  call rax
00007d07b35e19e9  movaps xmm1, [rsp]
00007d07b35e19ed  add rsp, 0x30
00007d07b35e19f1  vmovaps xmm0, [rsp]
00007d07b35e19f6  vmovaps xmm2, [rsp+0x10]
00007d07b35e19fc  vmovaps xmm3, [rsp+0x20]
00007d07b35e1a02  vmovaps xmm4, [rsp+0x30]
00007d07b35e1a08  vmovaps xmm5, [rsp+0x40]
00007d07b35e1a0e  vmovaps xmm6, [rsp+0x50]
00007d07b35e1a14  vmovaps xmm7, [rsp+0x60]
00007d07b35e1a1a  vmovaps xmm8, [rsp+0x70]
00007d07b35e1a20  vmovaps xmm9, [rsp+0x80]
00007d07b35e1a29  vmovaps xmm10, [rsp+0x90]
00007d07b35e1a32  vmovaps xmm11, [rsp+0xA0]
00007d07b35e1a3b  vmovaps xmm12, [rsp+0xB0]
00007d07b35e1a44  vmovaps xmm13, [rsp+0xC0]
00007d07b35e1a4d  vmovaps xmm14, [rsp+0xD0]
00007d07b35e1a56  vmovaps xmm15, [rsp+0xE0]
00007d07b35e1a5f  add rsp, 0xF0
00007d07b35e1a66  pop r11
00007d07b35e1a68  pop r10
00007d07b35e1a6a  pop r9
00007d07b35e1a6c  pop r8
00007d07b35e1a6e  pop rsi
00007d07b35e1a6f  pop rdi
00007d07b35e1a70  pop rdx
00007d07b35e1a71  pop rcx
00007d07b35e1a72  pop rax
00007d07b35e1a73  add rsp, 0x08
00007d07b35e1a77  jmp 0x00007D07B35DC865
00007d07b35e1a7c  call 0x00007D07B34E5940
00007d07b35e1a81  jmp 0x00007D07B35DC873
00007d07b35e1a86  call 0x00007D07B340C380
00007d07b35e1a8b  jmp 0x00007D07B35DC87D
00007d07b35e1a90  call 0x00007D07B340D600
00007d07b35e1a95  jmp 0x00007D07B35DC887
00007d07b35e1a9a  call 0x00007D07B33FF540
00007d07b35e1a9f  jmp 0x00007D07B35DC891
00007d07b35e1aa4  int3
00007d07b35e1aa5  nop [rax+rax*1], ax
00007d07b35e1aae  nop
00007d07b35e1ab0  mov rax, [r15+0xF8]
00007d07b35e1ab7  lea r14, [rax+0x140]
00007d07b35e1abe  mov r12, [r13+r14*1]
00007d07b35e1ac3  mov [r15+0xE8], r12
00007d07b35e1aca  lea r14, [rax+0x130]
00007d07b35e1ad1  mov r12, [r13+r14*1]
00007d07b35e1ad6  lea r14, [rax+0x138]
00007d07b35e1add  mov r11, [r13+r14*1]
00007d07b35e1ae2  movq xmm1, r12
00007d07b35e1ae7  movq xmm15, r11
00007d07b35e1aec  movq xmm1, xmm1
00007d07b35e1af0  movq xmm1, xmm1
00007d07b35e1af4  movaps [r15+0x1A0], xmm1
00007d07b35e1afc  movq xmm15, xmm15
00007d07b35e1b01  movq xmm15, xmm15
00007d07b35e1b06  movaps [r15+0x190], xmm15
00007d07b35e1b0e  lea r14, [rax+0x120]
00007d07b35e1b15  mov r12, [r13+r14*1]
00007d07b35e1b1a  lea r14, [rax+0x128]
00007d07b35e1b21  mov r11, [r13+r14*1]
00007d07b35e1b26  movq xmm1, r12
00007d07b35e1b2b  movq xmm15, r11
00007d07b35e1b30  movq xmm1, xmm1
00007d07b35e1b34  movq xmm1, xmm1
00007d07b35e1b38  movaps [r15+0x1C0], xmm1
00007d07b35e1b40  movq xmm15, xmm15
00007d07b35e1b45  movq xmm15, xmm15
00007d07b35e1b4a  movaps [r15+0x1B0], xmm15
00007d07b35e1b52  lea r14, [rax+0x110]
00007d07b35e1b59  mov r12, [r13+r14*1]
00007d07b35e1b5e  lea r14, [rax+0x118]
00007d07b35e1b65  mov r11, [r13+r14*1]
00007d07b35e1b6a  movq xmm1, r12
00007d07b35e1b6f  movq xmm15, r11
00007d07b35e1b74  movq xmm1, xmm1
00007d07b35e1b78  movq xmm1, xmm1
00007d07b35e1b7c  movaps [r15+0x1E0], xmm1
00007d07b35e1b84  movq xmm15, xmm15
00007d07b35e1b89  movq xmm15, xmm15
00007d07b35e1b8e  movaps [r15+0x1D0], xmm15
00007d07b35e1b96  lea r14, [rax+0x100]
00007d07b35e1b9d  mov r12, [r13+r14*1]
00007d07b35e1ba2  lea r14, [rax+0x108]
00007d07b35e1ba9  mov r11, [r13+r14*1]
00007d07b35e1bae  movq xmm1, r12
00007d07b35e1bb3  movq xmm15, r11
00007d07b35e1bb8  movq xmm1, xmm1
00007d07b35e1bbc  movq xmm1, xmm1
00007d07b35e1bc0  movaps [r15+0x200], xmm1
00007d07b35e1bc8  movq xmm15, xmm15
00007d07b35e1bcd  movq xmm15, xmm15
00007d07b35e1bd2  movaps [r15+0x1F0], xmm15
00007d07b35e1bda  mov qword ptr [r15+0x40], 0x430000
00007d07b35e1be2  mov r14d, 0x430510
00007d07b35e1be8  mov r12, [r13+r14*1]
00007d07b35e1bed  movq xmm1, r12
00007d07b35e1bf2  lea r14, [rax+0x150]
00007d07b35e1bf9  mov [r15+0xF8], r14
00007d07b35e1c00  mov rax, [r15+0x50]
00007d07b35e1c04  movups xmm15, [r13+rax*1]
00007d07b35e1c0a  movaps [r15+0x120], xmm15
00007d07b35e1c12  mov qword ptr [r15+0x48], 0x10
00007d07b35e1c1a  xor eax, eax
00007d07b35e1c1c  mov r14d, 0x10
00007d07b35e1c22  mov r12d, 0x200
00007d07b35e1c28  cmp r14, r12
00007d07b35e1c2b  cmc
00007d07b35e1c2c  lahf
00007d07b35e1c2d  seto al
00007d07b35e1c30  mov [r15+0x108], eax
00007d07b35e1c37  pextrq rax, xmm15, 0x01
00007d07b35e1c3e  movq xmm14, rax
00007d07b35e1c43  movaps [r15+0x130], xmm14
00007d07b35e1c4b  movq rax, xmm1
00007d07b35e1c50  movq r14, xmm15
00007d07b35e1c55  vmovq xmm1, rax
00007d07b35e1c5a  vmovq xmm15, r14
00007d07b35e1c5f  movaps xmm13, xmm1
00007d07b35e1c63  addsd xmm13, xmm15
00007d07b35e1c68  ucomisd xmm13, xmm13
00007d07b35e1c6d  jp 0x00007D07B35E1D86
00007d07b35e1c73  movq xmm13, xmm13
00007d07b35e1c78  movq rax, xmm13
00007d07b35e1c7d  movq r14, xmm14
00007d07b35e1c82  vmovq xmm1, rax
00007d07b35e1c87  vmovq xmm15, r14
00007d07b35e1c8c  movaps xmm14, xmm1
00007d07b35e1c90  addsd xmm14, xmm15
00007d07b35e1c95  ucomisd xmm14, xmm14
00007d07b35e1c9a  jp 0x00007D07B35E1DCE
00007d07b35e1ca0  movq xmm14, xmm14
00007d07b35e1ca5  movaps [r15+0x110], xmm14
00007d07b35e1cad  mov eax, [r15+0x108]
00007d07b35e1cb4  sahf
00007d07b35e1cb5  jnz 0x00007D07B35E1CE7
00007d07b35e1cb7  cmp dword ptr [r15+0x318], 0x00
00007d07b35e1cbf  jz 0x00007D07B35E1FE0
00007d07b35e1cc5  nop [rax+rax*1], ax
00007d07b35e1cce  nop [rax+rax*1], eax
00007d07b35e1cd6  mov eax, 0x410490
00007d07b35e1cdb  mov [r15+0x100], rax
00007d07b35e1ce2  jmp 0x00007D07B33FE110
00007d07b35e1ce7  cmp dword ptr [r15+0x318], 0x00
00007d07b35e1cef  jz 0x00007D07B35E1E20
00007d07b35e1cf5  nop [rax+rax*1], ax
00007d07b35e1cfe  nop [rax+rax*1], eax
00007d07b35e1d06  mov eax, 0x410474
00007d07b35e1d0b  mov [r15+0x100], rax
00007d07b35e1d12  jmp 0x00007D07B33FE110
00007d07b35e1d17  int3
00007d07b35e1d18  call 0x00007D07B34E27E0
00007d07b35e1d1d  jmp 0x00007D07B35E1AC3
00007d07b35e1d22  call 0x00007D07B34E27E0
00007d07b35e1d27  jmp 0x00007D07B35E1AD6
00007d07b35e1d2c  call 0x00007D07B34E1570
00007d07b35e1d31  jmp 0x00007D07B35E1AE2
00007d07b35e1d36  call 0x00007D07B34E27E0
00007d07b35e1d3b  jmp 0x00007D07B35E1B1A
00007d07b35e1d40  call 0x00007D07B34E1570
00007d07b35e1d45  jmp 0x00007D07B35E1B26
00007d07b35e1d4a  call 0x00007D07B34E27E0
00007d07b35e1d4f  jmp 0x00007D07B35E1B5E
00007d07b35e1d54  call 0x00007D07B34E1570
00007d07b35e1d59  jmp 0x00007D07B35E1B6A
00007d07b35e1d5e  call 0x00007D07B34E27E0
00007d07b35e1d63  jmp 0x00007D07B35E1BA2
00007d07b35e1d68  call 0x00007D07B34E1570
00007d07b35e1d6d  jmp 0x00007D07B35E1BAE
00007d07b35e1d72  call 0x00007D07B34E27E0
00007d07b35e1d77  jmp 0x00007D07B35E1BED
00007d07b35e1d7c  call 0x00007D07B340E760
00007d07b35e1d81  jmp 0x00007D07B35E1C0A
00007d07b35e1d86  ucomisd xmm1, xmm15
00007d07b35e1d8b  jp 0x00007D07B35E1D9A
00007d07b35e1d8d  movaps xmm13, [0x00007D07B31FE060]
00007d07b35e1d95  jmp 0x00007D07B35E1C73
00007d07b35e1d9a  vxorps xmm0, xmm1, xmm15
00007d07b35e1d9f  pextrw eax, xmm0, 0x03
00007d07b35e1da4  and eax, 0x7FF8
00007d07b35e1da9  cmp eax, 0x08
00007d07b35e1dac  jnz 0x00007D07B35E1C73
00007d07b35e1db2  movq rax, xmm15
00007d07b35e1db7  shl rax, 0x0D
00007d07b35e1dbb  jbe 0x00007D07B35E1C73
00007d07b35e1dc1  vorps xmm13, xmm15, [0x00007D07B31FE070]
00007d07b35e1dc9  jmp 0x00007D07B35E1C73
00007d07b35e1dce  ucomisd xmm1, xmm15
00007d07b35e1dd3  jp 0x00007D07B35E1DE2
00007d07b35e1dd5  movaps xmm14, [0x00007D07B31FE060]
00007d07b35e1ddd  jmp 0x00007D07B35E1CA0
00007d07b35e1de2  vxorps xmm0, xmm1, xmm15
00007d07b35e1de7  pextrw eax, xmm0, 0x03
00007d07b35e1dec  and eax, 0x7FF8
00007d07b35e1df1  cmp eax, 0x08
00007d07b35e1df4  jnz 0x00007D07B35E1CA0
00007d07b35e1dfa  movq rax, xmm15
00007d07b35e1dff  shl rax, 0x0D
00007d07b35e1e03  jbe 0x00007D07B35E1CA0
00007d07b35e1e09  vorps xmm14, xmm15, [0x00007D07B31FE070]
00007d07b35e1e11  jmp 0x00007D07B35E1CA0
00007d07b35e1e16  int3
00007d07b35e1e17  nop [rax+rax*1], ax
00007d07b35e1e20  mov rax, [r15+0x48]
00007d07b35e1e24  mov r14, [r15+0x50]
00007d07b35e1e28  lea r12, [r14+rax*1]
00007d07b35e1e2c  movups xmm1, [r13+r12*1]
00007d07b35e1e32  movaps [r15+0x120], xmm1
00007d07b35e1e3a  lea r14, [rax+0x10]
00007d07b35e1e3e  mov [r15+0x48], r14
00007d07b35e1e42  xor eax, eax
00007d07b35e1e44  mov r12d, 0x200
00007d07b35e1e4a  cmp r14, r12
00007d07b35e1e4d  cmc
00007d07b35e1e4e  lahf
00007d07b35e1e4f  seto al
00007d07b35e1e52  mov [r15+0x108], eax
00007d07b35e1e59  pextrq rax, xmm1, 0x01
00007d07b35e1e60  movq xmm15, rax
00007d07b35e1e65  movaps [r15+0x130], xmm15
00007d07b35e1e6d  movaps xmm14, [r15+0x110]
00007d07b35e1e75  movq rax, xmm14
00007d07b35e1e7a  movq r14, xmm1
00007d07b35e1e7f  vmovq xmm1, rax
00007d07b35e1e84  vmovq xmm14, r14
00007d07b35e1e89  movaps xmm13, xmm1
00007d07b35e1e8d  addsd xmm13, xmm14
00007d07b35e1e92  ucomisd xmm13, xmm13
00007d07b35e1e97  jp 0x00007D07B35E1F4C
00007d07b35e1e9d  movq xmm13, xmm13
00007d07b35e1ea2  movq rax, xmm13
00007d07b35e1ea7  movq r14, xmm15
00007d07b35e1eac  vmovq xmm1, rax
00007d07b35e1eb1  vmovq xmm15, r14
00007d07b35e1eb6  movaps xmm14, xmm1
00007d07b35e1eba  addsd xmm14, xmm15
00007d07b35e1ebf  ucomisd xmm14, xmm14
00007d07b35e1ec4  jp 0x00007D07B35E1F94
00007d07b35e1eca  movq xmm14, xmm14
00007d07b35e1ecf  movaps [r15+0x110], xmm14
00007d07b35e1ed7  mov eax, [r15+0x108]
00007d07b35e1ede  sahf
00007d07b35e1edf  jnz 0x00007D07B35E1F11
00007d07b35e1ee1  cmp dword ptr [r15+0x318], 0x00
00007d07b35e1ee9  jz 0x00007D07B35E1FE0
00007d07b35e1eef  nop [rax+rax*1], ax
00007d07b35e1ef8  nop [rax+rax*1], eax
00007d07b35e1f00  mov eax, 0x410490
00007d07b35e1f05  mov [r15+0x100], rax
00007d07b35e1f0c  jmp 0x00007D07B33FE110
00007d07b35e1f11  cmp dword ptr [r15+0x318], 0x00
00007d07b35e1f19  jz 0x00007D07B35E1E20
00007d07b35e1f1f  nop [rax+rax*1], ax
00007d07b35e1f28  nop [rax+rax*1], eax
00007d07b35e1f30  mov eax, 0x410474
00007d07b35e1f35  mov [r15+0x100], rax
00007d07b35e1f3c  jmp 0x00007D07B33FE110
00007d07b35e1f41  int3
00007d07b35e1f42  call 0x00007D07B34B52F0
00007d07b35e1f47  jmp 0x00007D07B35E1E32
00007d07b35e1f4c  ucomisd xmm1, xmm14
00007d07b35e1f51  jp 0x00007D07B35E1F60
00007d07b35e1f53  movaps xmm13, [0x00007D07B31FE060]
00007d07b35e1f5b  jmp 0x00007D07B35E1E9D
00007d07b35e1f60  vxorps xmm0, xmm1, xmm14
00007d07b35e1f65  pextrw eax, xmm0, 0x03
00007d07b35e1f6a  and eax, 0x7FF8
00007d07b35e1f6f  cmp eax, 0x08
00007d07b35e1f72  jnz 0x00007D07B35E1E9D
00007d07b35e1f78  movq rax, xmm14
00007d07b35e1f7d  shl rax, 0x0D
00007d07b35e1f81  jbe 0x00007D07B35E1E9D
00007d07b35e1f87  vorps xmm13, xmm14, [0x00007D07B31FE070]
00007d07b35e1f8f  jmp 0x00007D07B35E1E9D
00007d07b35e1f94  ucomisd xmm1, xmm15
00007d07b35e1f99  jp 0x00007D07B35E1FA8
00007d07b35e1f9b  movaps xmm14, [0x00007D07B31FE060]
00007d07b35e1fa3  jmp 0x00007D07B35E1ECA
00007d07b35e1fa8  vxorps xmm0, xmm1, xmm15
00007d07b35e1fad  pextrw eax, xmm0, 0x03
00007d07b35e1fb2  and eax, 0x7FF8
00007d07b35e1fb7  cmp eax, 0x08
00007d07b35e1fba  jnz 0x00007D07B35E1ECA
00007d07b35e1fc0  movq rax, xmm15
00007d07b35e1fc5  shl rax, 0x0D
00007d07b35e1fc9  jbe 0x00007D07B35E1ECA
00007d07b35e1fcf  vorps xmm14, xmm15, [0x00007D07B31FE070]
00007d07b35e1fd7  jmp 0x00007D07B35E1ECA
00007d07b35e1fdc  int3
00007d07b35e1fdd  nop [rax], eax
00007d07b35e1fe0  mov rax, [r15+0x40]
00007d07b35e1fe4  lea r14, [rax+0x510]
00007d07b35e1feb  movaps xmm1, [r15+0x110]
00007d07b35e1ff3  movq rax, xmm1
00007d07b35e1ff8  mov [r13+r14*1], rax
00007d07b35e1ffd  mov rax, [r15+0xF0]
00007d07b35e2004  mov [r15+0x100], rax
00007d07b35e200b  jmp 0x00007D07B35CE5C0
00007d07b35e2010  int3
00007d07b35e2011  call 0x00007D07B34D5EB0
00007d07b35e2016  jmp 0x00007D07B35E1FFD
00007d07b35e201b  int3
00007d07b35e201c  nop [rax], eax
00007d07b35e2020  mov qword ptr [r15+0x100], 0x04
00007d07b35e202b  mov esi, 0x00
00007d07b35e2030  mov edx, 0x09
00007d07b35e2035  mov rdi, 0x7FFEF25C3110
00007d07b35e203f  mov rax, 0x5D0AA6FC0970
00007d07b35e2049  call rax
00007d07b35e204b  cmp dword ptr [r15+0x318], 0x00
00007d07b35e2053  jnz 0x00007D07B33FE110
00007d07b35e2059  jmp 0x00007D07B33FE0A0
00007d07b35e205e  int3
00007d07b35e205f  int3
