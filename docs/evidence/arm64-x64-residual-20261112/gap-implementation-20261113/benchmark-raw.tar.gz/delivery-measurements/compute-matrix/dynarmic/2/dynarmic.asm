000078d941fce69b  nop [rax+rax*1], eax
000078d941fce6a0  vmovaps xmm1, [0x000078D941BFE010]
000078d941fce6a8  movq xmm1, xmm1
000078d941fce6ac  movaps [r15+0x110], xmm1
000078d941fce6b4  vmovaps xmm1, [0x000078D941BFE020]
000078d941fce6bc  movq xmm1, xmm1
000078d941fce6c0  movaps [r15+0x120], xmm1
000078d941fce6c8  mov eax, 0x4204C0
000078d941fce6cd  mov r14, [r13+rax*1]
000078d941fce6d2  movq xmm1, r14
000078d941fce6d7  movaps [r15+0x130], xmm1
000078d941fce6df  vmovaps xmm1, [0x000078D941BFE030]
000078d941fce6e7  vpbroadcastq xmm1, xmm1
000078d941fce6ec  movaps [r15+0x140], xmm1
000078d941fce6f4  mov qword ptr [r15+0x40], 0x02
000078d941fce6fc  vmovaps xmm15, [0x000078D941BFE040]
000078d941fce704  movq xmm15, xmm15
000078d941fce709  movaps [r15+0x150], xmm15
000078d941fce711  mov qword ptr [r15+0x58], 0x420000
000078d941fce719  vmovaps xmm15, [0x000078D941BFE050]
000078d941fce721  vpbroadcastq xmm15, xmm15
000078d941fce726  movaps [r15+0x160], xmm15
000078d941fce72e  mov rax, [r15+0x40]
000078d941fce732  vmovq xmm14, rax
000078d941fce737  vpbroadcastq xmm14, xmm14
000078d941fce73c  movaps [r15+0x170], xmm14
000078d941fce744  mov eax, 0x4204D0
000078d941fce749  movups xmm13, [r13+rax*1]
000078d941fce74f  mov qword ptr [r15+0x40], 0x430518
000078d941fce757  mov qword ptr [r15+0x50], 0x430720
000078d941fce75f  vpmovqd xmm12, xmm13
000078d941fce765  pxor xmm11, xmm11
000078d941fce76a  punpcklqdq xmm12, xmm11
000078d941fce76f  movaps [r15+0x210], xmm12
000078d941fce777  movq xmm12, qword ptr [r15+0x120]
000078d941fce780  movq xmm11, qword ptr [r15+0x130]
000078d941fce789  psubd xmm12, xmm11
000078d941fce78e  movq xmm12, xmm12
000078d941fce793  paddq xmm13, xmm14
000078d941fce798  movaps [r15+0x180], xmm13
000078d941fce7a0  movq xmm14, qword ptr [r15+0x150]
000078d941fce7a9  paddd xmm11, xmm14
000078d941fce7ae  movq xmm11, xmm11
000078d941fce7b3  movq xmm11, xmm11
000078d941fce7b8  movaps [r15+0x130], xmm11
000078d941fce7c0  pmovzxdq xmm12, xmm12
000078d941fce7c6  psllq xmm12, 0x00
000078d941fce7cc  movq xmm14, qword ptr [r15+0x210]
000078d941fce7d5  movq xmm13, qword ptr [r15+0x110]
000078d941fce7de  paddd xmm14, xmm13
000078d941fce7e3  movq xmm14, xmm14
000078d941fce7e8  vcvtuqq2pd xmm12, xmm12
000078d941fce7ee  pmovzxdq xmm14, xmm14
000078d941fce7f4  psllq xmm14, 0x00
000078d941fce7fa  vcvtuqq2pd xmm14, xmm14
000078d941fce800  movaps xmm13, xmm12
000078d941fce804  mulpd xmm13, xmm1
000078d941fce809  vcmppd xmm11, xmm13, xmm13, 0x03
000078d941fce80f  ptest xmm11, xmm11
000078d941fce815  jnz 0x000078D941FCE8FF
000078d941fce81b  movaps [r15+0x220], xmm13
000078d941fce823  mov eax, 0x430720
000078d941fce828  movups [r13+rax*1], xmm13
000078d941fce82e  movaps xmm1, xmm14
000078d941fce832  mulpd xmm1, xmm15
000078d941fce837  vcmppd xmm13, xmm1, xmm1, 0x03
000078d941fce83c  ptest xmm13, xmm13
000078d941fce842  jnz 0x000078D941FCEA4C
000078d941fce848  movaps [r15+0x210], xmm1
000078d941fce850  mov eax, 0x430518
000078d941fce855  movups [r13+rax*1], xmm1
000078d941fce85b  mov qword ptr [r15+0x48], 0x10
000078d941fce863  xor eax, eax
000078d941fce865  mov r14d, 0x10
000078d941fce86b  mov r12d, 0x200
000078d941fce871  cmp r14, r12
000078d941fce874  cmc
000078d941fce875  lahf
000078d941fce876  seto al
000078d941fce879  mov [r15+0x108], eax
000078d941fce880  mov eax, [r15+0x108]
000078d941fce887  sahf
000078d941fce888  jnz 0x000078D941FCE8BA
000078d941fce88a  cmp dword ptr [r15+0x318], 0x00
000078d941fce892  jz 0x000078D941FCEFF0
000078d941fce898  nop [rax+rax*1], ax
000078d941fce8a1  nop [rax+rax*1], eax
000078d941fce8a9  mov eax, 0x4101EC
000078d941fce8ae  mov [r15+0x100], rax
000078d941fce8b5  jmp 0x000078D941DFE110
000078d941fce8ba  cmp dword ptr [r15+0x318], 0x00
000078d941fce8c2  jz 0x000078D941FCEBA0
000078d941fce8c8  nop [rax+rax*1], ax
000078d941fce8d1  nop [rax+rax*1], eax
000078d941fce8d9  mov eax, 0x4101AC
000078d941fce8de  mov [r15+0x100], rax
000078d941fce8e5  jmp 0x000078D941DFE110
000078d941fce8ea  int3
000078d941fce8eb  call 0x000078D941E0DC20
000078d941fce8f0  jmp 0x000078D941FCE6D2
000078d941fce8f5  call 0x000078D941E0C260
000078d941fce8fa  jmp 0x000078D941FCE74F
000078d941fce8ff  sub rsp, 0x08
000078d941fce903  push rax
000078d941fce904  push rcx
000078d941fce905  push rdx
000078d941fce906  push rdi
000078d941fce907  push rsi
000078d941fce908  push r8
000078d941fce90a  push r9
000078d941fce90c  push r10
000078d941fce90e  push r11
000078d941fce910  sub rsp, 0xF0
000078d941fce917  vmovaps [rsp], xmm0
000078d941fce91c  vmovaps [rsp+0x10], xmm1
000078d941fce922  vmovaps [rsp+0x20], xmm2
000078d941fce928  vmovaps [rsp+0x30], xmm3
000078d941fce92e  vmovaps [rsp+0x40], xmm4
000078d941fce934  vmovaps [rsp+0x50], xmm5
000078d941fce93a  vmovaps [rsp+0x60], xmm6
000078d941fce940  vmovaps [rsp+0x70], xmm7
000078d941fce946  vmovaps [rsp+0x80], xmm8
000078d941fce94f  vmovaps [rsp+0x90], xmm9
000078d941fce958  vmovaps [rsp+0xA0], xmm10
000078d941fce961  vmovaps [rsp+0xB0], xmm11
000078d941fce96a  vmovaps [rsp+0xC0], xmm12
000078d941fce973  vmovaps [rsp+0xD0], xmm14
000078d941fce97c  vmovaps [rsp+0xE0], xmm15
000078d941fce985  sub rsp, 0x30
000078d941fce989  movaps [rsp], xmm13
000078d941fce98e  movaps [rsp+0x10], xmm12
000078d941fce994  movaps [rsp+0x20], xmm1
000078d941fce999  lea rdi, [rsp]
000078d941fce99d  mov esi, 0x00
000078d941fce9a2  mov rax, 0x59BFBFBAA530
000078d941fce9ac  call rax
000078d941fce9ae  movaps xmm13, [rsp]
000078d941fce9b3  add rsp, 0x30
000078d941fce9b7  vmovaps xmm0, [rsp]
000078d941fce9bc  vmovaps xmm1, [rsp+0x10]
000078d941fce9c2  vmovaps xmm2, [rsp+0x20]
000078d941fce9c8  vmovaps xmm3, [rsp+0x30]
000078d941fce9ce  vmovaps xmm4, [rsp+0x40]
000078d941fce9d4  vmovaps xmm5, [rsp+0x50]
000078d941fce9da  vmovaps xmm6, [rsp+0x60]
000078d941fce9e0  vmovaps xmm7, [rsp+0x70]
000078d941fce9e6  vmovaps xmm8, [rsp+0x80]
000078d941fce9ef  vmovaps xmm9, [rsp+0x90]
000078d941fce9f8  vmovaps xmm10, [rsp+0xA0]
000078d941fcea01  vmovaps xmm11, [rsp+0xB0]
000078d941fcea0a  vmovaps xmm12, [rsp+0xC0]
000078d941fcea13  vmovaps xmm14, [rsp+0xD0]
000078d941fcea1c  vmovaps xmm15, [rsp+0xE0]
000078d941fcea25  add rsp, 0xF0
000078d941fcea2c  pop r11
000078d941fcea2e  pop r10
000078d941fcea30  pop r9
000078d941fcea32  pop r8
000078d941fcea34  pop rsi
000078d941fcea35  pop rdi
000078d941fcea36  pop rdx
000078d941fcea37  pop rcx
000078d941fcea38  pop rax
000078d941fcea39  add rsp, 0x08
000078d941fcea3d  jmp 0x000078D941FCE81B
000078d941fcea42  call 0x000078D941E0C380
000078d941fcea47  jmp 0x000078D941FCE82E
000078d941fcea4c  sub rsp, 0x08
000078d941fcea50  push rax
000078d941fcea51  push rcx
000078d941fcea52  push rdx
000078d941fcea53  push rdi
000078d941fcea54  push rsi
000078d941fcea55  push r8
000078d941fcea57  push r9
000078d941fcea59  push r10
000078d941fcea5b  push r11
000078d941fcea5d  sub rsp, 0xF0
000078d941fcea64  vmovaps [rsp], xmm0
000078d941fcea69  vmovaps [rsp+0x10], xmm2
000078d941fcea6f  vmovaps [rsp+0x20], xmm3
000078d941fcea75  vmovaps [rsp+0x30], xmm4
000078d941fcea7b  vmovaps [rsp+0x40], xmm5
000078d941fcea81  vmovaps [rsp+0x50], xmm6
000078d941fcea87  vmovaps [rsp+0x60], xmm7
000078d941fcea8d  vmovaps [rsp+0x70], xmm8
000078d941fcea93  vmovaps [rsp+0x80], xmm9
000078d941fcea9c  vmovaps [rsp+0x90], xmm10
000078d941fceaa5  vmovaps [rsp+0xA0], xmm11
000078d941fceaae  vmovaps [rsp+0xB0], xmm12
000078d941fceab7  vmovaps [rsp+0xC0], xmm13
000078d941fceac0  vmovaps [rsp+0xD0], xmm14
000078d941fceac9  vmovaps [rsp+0xE0], xmm15
000078d941fcead2  sub rsp, 0x30
000078d941fcead6  movaps [rsp], xmm1
000078d941fceada  movaps [rsp+0x10], xmm14
000078d941fceae0  movaps [rsp+0x20], xmm15
000078d941fceae6  lea rdi, [rsp]
000078d941fceaea  mov esi, 0x00
000078d941fceaef  mov rax, 0x59BFBFBAA530
000078d941fceaf9  call rax
000078d941fceafb  movaps xmm1, [rsp]
000078d941fceaff  add rsp, 0x30
000078d941fceb03  vmovaps xmm0, [rsp]
000078d941fceb08  vmovaps xmm2, [rsp+0x10]
000078d941fceb0e  vmovaps xmm3, [rsp+0x20]
000078d941fceb14  vmovaps xmm4, [rsp+0x30]
000078d941fceb1a  vmovaps xmm5, [rsp+0x40]
000078d941fceb20  vmovaps xmm6, [rsp+0x50]
000078d941fceb26  vmovaps xmm7, [rsp+0x60]
000078d941fceb2c  vmovaps xmm8, [rsp+0x70]
000078d941fceb32  vmovaps xmm9, [rsp+0x80]
000078d941fceb3b  vmovaps xmm10, [rsp+0x90]
000078d941fceb44  vmovaps xmm11, [rsp+0xA0]
000078d941fceb4d  vmovaps xmm12, [rsp+0xB0]
000078d941fceb56  vmovaps xmm13, [rsp+0xC0]
000078d941fceb5f  vmovaps xmm14, [rsp+0xD0]
000078d941fceb68  vmovaps xmm15, [rsp+0xE0]
000078d941fceb71  add rsp, 0xF0
000078d941fceb78  pop r11
000078d941fceb7a  pop r10
000078d941fceb7c  pop r9
000078d941fceb7e  pop r8
000078d941fceb80  pop rsi
000078d941fceb81  pop rdi
000078d941fceb82  pop rdx
000078d941fceb83  pop rcx
000078d941fceb84  pop rax
000078d941fceb85  add rsp, 0x08
000078d941fceb89  jmp 0x000078D941FCE848
000078d941fceb8e  call 0x000078D941DFF540
000078d941fceb93  jmp 0x000078D941FCE85B
000078d941fceb98  int3
000078d941fceb99  nop [rax], eax
000078d941fceba0  movaps xmm1, [r15+0x180]
000078d941fceba8  vpmovqd xmm15, xmm1
000078d941fcebae  pxor xmm14, xmm14
000078d941fcebb3  punpcklqdq xmm15, xmm14
000078d941fcebb8  movaps [r15+0x210], xmm15
000078d941fcebc0  movq xmm15, qword ptr [r15+0x120]
000078d941fcebc9  movq xmm14, qword ptr [r15+0x130]
000078d941fcebd2  psubd xmm15, xmm14
000078d941fcebd7  movq xmm15, xmm15
000078d941fcebdc  movaps xmm13, [r15+0x170]
000078d941fcebe4  paddq xmm1, xmm13
000078d941fcebe9  movaps [r15+0x180], xmm1
000078d941fcebf1  movq xmm1, qword ptr [r15+0x150]
000078d941fcebfa  paddd xmm14, xmm1
000078d941fcebff  movq xmm14, xmm14
000078d941fcec04  movq xmm14, xmm14
000078d941fcec09  movaps [r15+0x130], xmm14
000078d941fcec11  pmovzxdq xmm15, xmm15
000078d941fcec17  psllq xmm15, 0x00
000078d941fcec1d  movq xmm1, qword ptr [r15+0x210]
000078d941fcec26  movq xmm14, qword ptr [r15+0x110]
000078d941fcec2f  paddd xmm1, xmm14
000078d941fcec34  movq xmm1, xmm1
000078d941fcec38  vcvtuqq2pd xmm15, xmm15
000078d941fcec3e  pmovzxdq xmm1, xmm1
000078d941fcec43  psllq xmm1, 0x00
000078d941fcec48  vcvtuqq2pd xmm1, xmm1
000078d941fcec4e  movaps xmm14, [r15+0x140]
000078d941fcec56  movaps xmm13, xmm15
000078d941fcec5a  mulpd xmm13, xmm14
000078d941fcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000078d941fcec65  ptest xmm12, xmm12
000078d941fcec6b  jnz 0x000078D941FCED4E
000078d941fcec71  movaps [r15+0x220], xmm13
000078d941fcec79  mov rax, [r15+0x48]
000078d941fcec7d  mov r14, [r15+0x50]
000078d941fcec81  lea r12, [r14+rax*1]
000078d941fcec85  movups [r13+r12*1], xmm13
000078d941fcec8b  movaps xmm15, [r15+0x160]
000078d941fcec93  movaps xmm14, xmm1
000078d941fcec97  mulpd xmm14, xmm15
000078d941fcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000078d941fceca2  ptest xmm13, xmm13
000078d941fceca8  jnz 0x000078D941FCEE9C
000078d941fcecae  movaps [r15+0x210], xmm14
000078d941fcecb6  mov r14, [r15+0x40]
000078d941fcecba  lea r12, [r14+rax*1]
000078d941fcecbe  movups [r13+r12*1], xmm14
000078d941fcecc4  lea r14, [rax+0x10]
000078d941fcecc8  mov [r15+0x48], r14
000078d941fceccc  xor eax, eax
000078d941fcecce  mov r12d, 0x200
000078d941fcecd4  cmp r14, r12
000078d941fcecd7  cmc
000078d941fcecd8  lahf
000078d941fcecd9  seto al
000078d941fcecdc  mov [r15+0x108], eax
000078d941fcece3  mov eax, [r15+0x108]
000078d941fcecea  sahf
000078d941fceceb  jnz 0x000078D941FCED1D
000078d941fceced  cmp dword ptr [r15+0x318], 0x00
000078d941fcecf5  jz 0x000078D941FCEFF0
000078d941fcecfb  nop [rax+rax*1], ax
000078d941fced04  nop [rax+rax*1], eax
000078d941fced0c  mov eax, 0x4101EC
000078d941fced11  mov [r15+0x100], rax
000078d941fced18  jmp 0x000078D941DFE110
000078d941fced1d  cmp dword ptr [r15+0x318], 0x00
000078d941fced25  jz 0x000078D941FCEBA0
000078d941fced2b  nop [rax+rax*1], ax
000078d941fced34  nop [rax+rax*1], eax
000078d941fced3c  mov eax, 0x4101AC
000078d941fced41  mov [r15+0x100], rax
000078d941fced48  jmp 0x000078D941DFE110
000078d941fced4d  int3
000078d941fced4e  sub rsp, 0x08
000078d941fced52  push rax
000078d941fced53  push rcx
000078d941fced54  push rdx
000078d941fced55  push rdi
000078d941fced56  push rsi
000078d941fced57  push r8
000078d941fced59  push r9
000078d941fced5b  push r10
000078d941fced5d  push r11
000078d941fced5f  sub rsp, 0xF0
000078d941fced66  vmovaps [rsp], xmm0
000078d941fced6b  vmovaps [rsp+0x10], xmm1
000078d941fced71  vmovaps [rsp+0x20], xmm2
000078d941fced77  vmovaps [rsp+0x30], xmm3
000078d941fced7d  vmovaps [rsp+0x40], xmm4
000078d941fced83  vmovaps [rsp+0x50], xmm5
000078d941fced89  vmovaps [rsp+0x60], xmm6
000078d941fced8f  vmovaps [rsp+0x70], xmm7
000078d941fced95  vmovaps [rsp+0x80], xmm8
000078d941fced9e  vmovaps [rsp+0x90], xmm9
000078d941fceda7  vmovaps [rsp+0xA0], xmm10
000078d941fcedb0  vmovaps [rsp+0xB0], xmm11
000078d941fcedb9  vmovaps [rsp+0xC0], xmm12
000078d941fcedc2  vmovaps [rsp+0xD0], xmm14
000078d941fcedcb  vmovaps [rsp+0xE0], xmm15
000078d941fcedd4  sub rsp, 0x30
000078d941fcedd8  movaps [rsp], xmm13
000078d941fceddd  movaps [rsp+0x10], xmm15
000078d941fcede3  movaps [rsp+0x20], xmm14
000078d941fcede9  lea rdi, [rsp]
000078d941fceded  mov esi, 0x00
000078d941fcedf2  mov rax, 0x59BFBFBAA530
000078d941fcedfc  call rax
000078d941fcedfe  movaps xmm13, [rsp]
000078d941fcee03  add rsp, 0x30
000078d941fcee07  vmovaps xmm0, [rsp]
000078d941fcee0c  vmovaps xmm1, [rsp+0x10]
000078d941fcee12  vmovaps xmm2, [rsp+0x20]
000078d941fcee18  vmovaps xmm3, [rsp+0x30]
000078d941fcee1e  vmovaps xmm4, [rsp+0x40]
000078d941fcee24  vmovaps xmm5, [rsp+0x50]
000078d941fcee2a  vmovaps xmm6, [rsp+0x60]
000078d941fcee30  vmovaps xmm7, [rsp+0x70]
000078d941fcee36  vmovaps xmm8, [rsp+0x80]
000078d941fcee3f  vmovaps xmm9, [rsp+0x90]
000078d941fcee48  vmovaps xmm10, [rsp+0xA0]
000078d941fcee51  vmovaps xmm11, [rsp+0xB0]
000078d941fcee5a  vmovaps xmm12, [rsp+0xC0]
000078d941fcee63  vmovaps xmm14, [rsp+0xD0]
000078d941fcee6c  vmovaps xmm15, [rsp+0xE0]
000078d941fcee75  add rsp, 0xF0
000078d941fcee7c  pop r11
000078d941fcee7e  pop r10
000078d941fcee80  pop r9
000078d941fcee82  pop r8
000078d941fcee84  pop rsi
000078d941fcee85  pop rdi
000078d941fcee86  pop rdx
000078d941fcee87  pop rcx
000078d941fcee88  pop rax
000078d941fcee89  add rsp, 0x08
000078d941fcee8d  jmp 0x000078D941FCEC71
000078d941fcee92  call 0x000078D941EC2240
000078d941fcee97  jmp 0x000078D941FCEC8B
000078d941fcee9c  sub rsp, 0x08
000078d941fceea0  push rax
000078d941fceea1  push rcx
000078d941fceea2  push rdx
000078d941fceea3  push rdi
000078d941fceea4  push rsi
000078d941fceea5  push r8
000078d941fceea7  push r9
000078d941fceea9  push r10
000078d941fceeab  push r11
000078d941fceead  sub rsp, 0xF0
000078d941fceeb4  vmovaps [rsp], xmm0
000078d941fceeb9  vmovaps [rsp+0x10], xmm1
000078d941fceebf  vmovaps [rsp+0x20], xmm2
000078d941fceec5  vmovaps [rsp+0x30], xmm3
000078d941fceecb  vmovaps [rsp+0x40], xmm4
000078d941fceed1  vmovaps [rsp+0x50], xmm5
000078d941fceed7  vmovaps [rsp+0x60], xmm6
000078d941fceedd  vmovaps [rsp+0x70], xmm7
000078d941fceee3  vmovaps [rsp+0x80], xmm8
000078d941fceeec  vmovaps [rsp+0x90], xmm9
000078d941fceef5  vmovaps [rsp+0xA0], xmm10
000078d941fceefe  vmovaps [rsp+0xB0], xmm11
000078d941fcef07  vmovaps [rsp+0xC0], xmm12
000078d941fcef10  vmovaps [rsp+0xD0], xmm13
000078d941fcef19  vmovaps [rsp+0xE0], xmm15
000078d941fcef22  sub rsp, 0x30
000078d941fcef26  movaps [rsp], xmm14
000078d941fcef2b  movaps [rsp+0x10], xmm1
000078d941fcef30  movaps [rsp+0x20], xmm15
000078d941fcef36  lea rdi, [rsp]
000078d941fcef3a  mov esi, 0x00
000078d941fcef3f  mov rax, 0x59BFBFBAA530
000078d941fcef49  call rax
000078d941fcef4b  movaps xmm14, [rsp]
000078d941fcef50  add rsp, 0x30
000078d941fcef54  vmovaps xmm0, [rsp]
000078d941fcef59  vmovaps xmm1, [rsp+0x10]
000078d941fcef5f  vmovaps xmm2, [rsp+0x20]
000078d941fcef65  vmovaps xmm3, [rsp+0x30]
000078d941fcef6b  vmovaps xmm4, [rsp+0x40]
000078d941fcef71  vmovaps xmm5, [rsp+0x50]
000078d941fcef77  vmovaps xmm6, [rsp+0x60]
000078d941fcef7d  vmovaps xmm7, [rsp+0x70]
000078d941fcef83  vmovaps xmm8, [rsp+0x80]
000078d941fcef8c  vmovaps xmm9, [rsp+0x90]
000078d941fcef95  vmovaps xmm10, [rsp+0xA0]
000078d941fcef9e  vmovaps xmm11, [rsp+0xB0]
000078d941fcefa7  vmovaps xmm12, [rsp+0xC0]
000078d941fcefb0  vmovaps xmm13, [rsp+0xD0]
000078d941fcefb9  vmovaps xmm15, [rsp+0xE0]
000078d941fcefc2  add rsp, 0xF0
000078d941fcefc9  pop r11
000078d941fcefcb  pop r10
000078d941fcefcd  pop r9
000078d941fcefcf  pop r8
000078d941fcefd1  pop rsi
000078d941fcefd2  pop rdi
000078d941fcefd3  pop rdx
000078d941fcefd4  pop rcx
000078d941fcefd5  pop rax
000078d941fcefd6  add rsp, 0x08
000078d941fcefda  jmp 0x000078D941FCECAE
000078d941fcefdf  call 0x000078D941EC34C0
000078d941fcefe4  jmp 0x000078D941FCECC4
000078d941fcefe9  int3
000078d941fcefea  nop [rax+rax*1], ax
000078d941fceff0  mov rax, [r15+0xF8]
000078d941fceff7  lea r14, [rax-0x150]
000078d941fceffe  mov [r15+0xF8], r14
000078d941fcf005  mov rax, [r15+0x50]
000078d941fcf009  lea r12, [rax+0x80]
000078d941fcf010  movups xmm1, [r13+r12*1]
000078d941fcf016  lea r12, [rax+0x90]
000078d941fcf01d  movups xmm15, [r13+r12*1]
000078d941fcf023  mov qword ptr [r15+0x48], 0x00
000078d941fcf02b  lea r12, [rax+0x40]
000078d941fcf02f  movups xmm14, [r13+r12*1]
000078d941fcf035  lea r12, [rax+0x50]
000078d941fcf039  movups xmm13, [r13+r12*1]
000078d941fcf03f  lea r12, [r14+0x120]
000078d941fcf046  movq xmm12, qword ptr [r15+0x1C0]
000078d941fcf04f  movq xmm11, qword ptr [r15+0x1B0]
000078d941fcf058  movq r11, xmm12
000078d941fcf05d  movq r10, xmm11
000078d941fcf062  mov [r13+r12*1], r11
000078d941fcf067  lea r12, [r14+0x128]
000078d941fcf06e  mov [r13+r12*1], r10
000078d941fcf073  vxorps xmm12, xmm12, xmm12
000078d941fcf078  vpbroadcastq xmm12, xmm12
000078d941fcf07d  lea r12, [r14+0x100]
000078d941fcf084  movq xmm11, qword ptr [r15+0x200]
000078d941fcf08d  movq xmm10, qword ptr [r15+0x1F0]
000078d941fcf096  movq r11, xmm11
000078d941fcf09b  movq r10, xmm10
000078d941fcf0a0  mov [r13+r12*1], r11
000078d941fcf0a5  lea r12, [r14+0x108]
000078d941fcf0ac  mov [r13+r12*1], r10
000078d941fcf0b1  lea r12, [r14+0xE0]
000078d941fcf0b8  movups [r13+r12*1], xmm15
000078d941fcf0be  lea r12, [r14+0xF0]
000078d941fcf0c5  movups [r13+r12*1], xmm1
000078d941fcf0cb  lea r12, [rax+0xC0]
000078d941fcf0d2  movups xmm1, [r13+r12*1]
000078d941fcf0d8  lea r12, [rax+0xD0]
000078d941fcf0df  movups xmm15, [r13+r12*1]
000078d941fcf0e5  lea r12, [r14+0x110]
000078d941fcf0ec  movq xmm11, qword ptr [r15+0x1E0]
000078d941fcf0f5  movq xmm10, qword ptr [r15+0x1D0]
000078d941fcf0fe  movq r11, xmm11
000078d941fcf103  movq r10, xmm10
000078d941fcf108  mov [r13+r12*1], r11
000078d941fcf10d  lea r12, [r14+0x118]
000078d941fcf114  mov [r13+r12*1], r10
000078d941fcf119  movups xmm11, [r13+rax*1]
000078d941fcf11f  lea r12, [rax+0x10]
000078d941fcf123  movups xmm10, [r13+r12*1]
000078d941fcf129  lea r12, [r14+0x130]
000078d941fcf130  movq xmm9, qword ptr [r15+0x1A0]
000078d941fcf139  movq xmm8, qword ptr [r15+0x190]
000078d941fcf142  movq r11, xmm9
000078d941fcf147  movq r10, xmm8
000078d941fcf14c  mov [r13+r12*1], r11
000078d941fcf151  lea r12, [r14+0x138]
000078d941fcf158  mov [r13+r12*1], r10
000078d941fcf15d  lea r12, [rax+0x140]
000078d941fcf164  movups xmm9, [r13+r12*1]
000078d941fcf16a  lea r12, [rax+0x150]
000078d941fcf171  movups xmm8, [r13+r12*1]
000078d941fcf177  lea r12, [r14+0xC0]
000078d941fcf17e  movups [r13+r12*1], xmm15
000078d941fcf184  lea r12, [r14+0xD0]
000078d941fcf18b  movups [r13+r12*1], xmm1
000078d941fcf191  lea r12, [rax+0x100]
000078d941fcf198  movups xmm1, [r13+r12*1]
000078d941fcf19e  lea r12, [rax+0x110]
000078d941fcf1a5  movups xmm15, [r13+r12*1]
000078d941fcf1ab  lea r12, [r14+0x140]
000078d941fcf1b2  mov r11, [r15+0xE8]
000078d941fcf1b9  mov [r13+r12*1], r11
000078d941fcf1be  lea r12, [rax+0x180]
000078d941fcf1c5  movups xmm7, [r13+r12*1]
000078d941fcf1cb  lea r12, [rax+0x190]
000078d941fcf1d2  movups xmm6, [r13+r12*1]
000078d941fcf1d8  lea r12, [rax+0x1C0]
000078d941fcf1df  movups xmm5, [r13+r12*1]
000078d941fcf1e5  lea r12, [rax+0x1D0]
000078d941fcf1ec  movups xmm4, [r13+r12*1]
000078d941fcf1f2  lea r12, [r14+0x20]
000078d941fcf1f6  movups [r13+r12*1], xmm1
000078d941fcf1fc  lea r12, [r14+0x30]
000078d941fcf200  movups [r13+r12*1], xmm13
000078d941fcf206  lea r12, [rax+0x60]
000078d941fcf20a  movups xmm1, [r13+r12*1]
000078d941fcf210  lea r12, [rax+0x70]
000078d941fcf214  movups xmm13, [r13+r12*1]
000078d941fcf21a  lea r12, [rax+0x20]
000078d941fcf21e  movups xmm3, [r13+r12*1]
000078d941fcf224  lea r12, [rax+0x30]
000078d941fcf228  movups xmm2, [r13+r12*1]
000078d941fcf22e  movaps [r15+0x1F0], xmm2
000078d941fcf236  lea r12, [r14+0x60]
000078d941fcf23a  movups [r13+r12*1], xmm11
000078d941fcf240  lea r12, [r14+0x70]
000078d941fcf244  movups [r13+r12*1], xmm5
000078d941fcf24a  lea r12, [rax+0xE0]
000078d941fcf251  movups xmm11, [r13+r12*1]
000078d941fcf257  lea r12, [rax+0xF0]
000078d941fcf25e  movups xmm5, [r13+r12*1]
000078d941fcf264  lea r12, [r14+0xA0]
000078d941fcf26b  movups [r13+r12*1], xmm13
000078d941fcf271  lea r12, [r14+0xB0]
000078d941fcf278  movups [r13+r12*1], xmm1
000078d941fcf27e  lea r12, [rax+0xA0]
000078d941fcf285  movups xmm1, [r13+r12*1]
000078d941fcf28b  lea r12, [rax+0xB0]
000078d941fcf292  movups xmm13, [r13+r12*1]
000078d941fcf298  lea r12, [rax+0x120]
000078d941fcf29f  vmovaps [rsp+0x10], xmm1
000078d941fcf2a5  movups xmm1, [r13+r12*1]
000078d941fcf2ab  lea r12, [rax+0x130]
000078d941fcf2b2  vmovaps [rsp+0x20], xmm1
000078d941fcf2b8  movups xmm1, [r13+r12*1]
000078d941fcf2be  lea r12, [rax+0x160]
000078d941fcf2c5  vmovaps [rsp+0x30], xmm1
000078d941fcf2cb  movups xmm1, [r13+r12*1]
000078d941fcf2d1  lea r12, [rax+0x170]
000078d941fcf2d8  vmovaps [rsp+0x40], xmm1
000078d941fcf2de  movups xmm1, [r13+r12*1]
000078d941fcf2e4  movaps [r15+0x2B0], xmm1
000078d941fcf2ec  lea r12, [r14+0x80]
000078d941fcf2f3  movups [r13+r12*1], xmm13
000078d941fcf2f9  lea r12, [r14+0x90]
000078d941fcf300  vmovaps xmm13, [rsp+0x10]
000078d941fcf306  movups [r13+r12*1], xmm13
000078d941fcf30c  lea r12, [rax+0x1A0]
000078d941fcf313  movups xmm13, [r13+r12*1]
000078d941fcf319  lea r12, [rax+0x1B0]
000078d941fcf320  vmovaps [rsp+0x10], xmm1
000078d941fcf326  movups xmm1, [r13+r12*1]
000078d941fcf32c  movaps [r15+0x290], xmm13
000078d941fcf334  movaps [r15+0x1E0], xmm1
000078d941fcf33c  lea r12, [rax+0x1E0]
000078d941fcf343  vmovaps [rsp+0x50], xmm1
000078d941fcf349  movups xmm1, [r13+r12*1]
000078d941fcf34f  lea r12, [rax+0x1F0]
000078d941fcf356  vmovaps [rsp+0x60], xmm1
000078d941fcf35c  movups xmm1, [r13+r12*1]
000078d941fcf362  mov qword ptr [r15+0x50], 0x430920
000078d941fcf36a  lea rax, [r14+0x40]
000078d941fcf36e  vmovaps [rsp+0x70], xmm1
000078d941fcf374  vmovaps xmm1, [rsp+0x40]
000078d941fcf37a  movups [r13+rax*1], xmm1
000078d941fcf380  lea rax, [r14+0x50]
000078d941fcf384  movups [r13+rax*1], xmm10
000078d941fcf38a  vmovaps xmm1, [rsp+0x70]
000078d941fcf390  movups [r13+r14*1], xmm1
000078d941fcf396  lea rax, [r14+0x10]
000078d941fcf39a  vmovaps xmm1, [rsp+0x60]
000078d941fcf3a0  movups [r13+rax*1], xmm1
000078d941fcf3a6  mov rax, [r15+0x40]
000078d941fcf3aa  vmovaps [rsp+0x40], xmm3
000078d941fcf3b0  vmovaps xmm1, [rsp+0x40]
000078d941fcf3b6  por xmm3, xmm1
000078d941fcf3ba  vmovaps [rsp+0x40], xmm6
000078d941fcf3c0  vmovaps xmm10, [rsp+0x40]
000078d941fcf3c6  por xmm6, xmm10
000078d941fcf3cb  lea r12, [rax+0x30]
000078d941fcf3cf  mov r11, [r13+r12*1]
000078d941fcf3d4  lea r12, [rax+0x38]
000078d941fcf3d8  mov r10, [r13+r12*1]
000078d941fcf3dd  movq xmm10, r11
000078d941fcf3e2  vmovaps [rsp+0x40], xmm1
000078d941fcf3e8  movq xmm1, r10
000078d941fcf3ed  movq xmm10, xmm10
000078d941fcf3f2  vmovaps [rsp+0x60], xmm10
000078d941fcf3f8  movq xmm10, xmm10
000078d941fcf3fd  movaps [r15+0x130], xmm10
000078d941fcf405  movq xmm1, xmm1
000078d941fcf409  vmovaps [rsp+0x70], xmm1
000078d941fcf40f  movq xmm1, xmm1
000078d941fcf413  movaps [r15+0x280], xmm1
000078d941fcf41b  vmovaps [rsp+0x80], xmm9
000078d941fcf424  vmovaps xmm1, [rsp+0x80]
000078d941fcf42d  por xmm9, xmm1
000078d941fcf432  lea r12, [rax+0x20]
000078d941fcf436  mov r11, [r13+r12*1]
000078d941fcf43b  lea r12, [rax+0x28]
000078d941fcf43f  mov r10, [r13+r12*1]
000078d941fcf444  movq xmm1, r11
000078d941fcf449  movq xmm10, r10
000078d941fcf44e  movq xmm1, xmm1
000078d941fcf452  vmovaps [rsp+0x80], xmm1
000078d941fcf45b  movq xmm1, xmm1
000078d941fcf45f  movaps [r15+0x150], xmm1
000078d941fcf467  movq xmm10, xmm10
000078d941fcf46c  vmovaps [rsp+0x90], xmm10
000078d941fcf475  movq xmm10, xmm10
000078d941fcf47a  movaps [r15+0x140], xmm10
000078d941fcf482  lea r12, [rax+0x10]
000078d941fcf486  mov r11, [r13+r12*1]
000078d941fcf48b  lea r12, [rax+0x18]
000078d941fcf48f  mov r10, [r13+r12*1]
000078d941fcf494  movq xmm1, r11
000078d941fcf499  movq xmm10, r10
000078d941fcf49e  movq xmm1, xmm1
000078d941fcf4a2  vmovaps [rsp+0xA0], xmm1
000078d941fcf4ab  movq xmm1, xmm1
000078d941fcf4af  movaps [r15+0x170], xmm1
000078d941fcf4b7  movq xmm10, xmm10
000078d941fcf4bc  vmovaps [rsp+0xB0], xmm10
000078d941fcf4c5  movq xmm10, xmm10
000078d941fcf4ca  movaps [r15+0x160], xmm10
000078d941fcf4d2  mov r12, [r13+rax*1]
000078d941fcf4d7  vmovq xmm1, r12
000078d941fcf4dc  vpbroadcastq xmm1, xmm1
000078d941fcf4e1  lea r12, [rax+0x08]
000078d941fcf4e5  mov rax, [r13+r12*1]
000078d941fcf4ea  movq xmm10, rax
000078d941fcf4ef  movaps [r15+0x230], xmm10
000078d941fcf4f7  lea rax, [r14+0x50]
000078d941fcf4fb  movups xmm10, [r13+rax*1]
000078d941fcf501  lea rax, [r14+0x60]
000078d941fcf505  vmovaps [rsp+0xC0], xmm1
000078d941fcf50e  movups xmm1, [r13+rax*1]
000078d941fcf514  lea rax, [r14+0x30]
000078d941fcf518  vmovaps [rsp+0xD0], xmm1
000078d941fcf521  movups xmm1, [r13+rax*1]
000078d941fcf527  mov qword ptr [r15+0x60], 0x430920
000078d941fcf52f  mov qword ptr [r15+0x58], 0x40
000078d941fcf537  vmovaps [rsp+0xE0], xmm1
000078d941fcf540  vmovaps [rsp+0xF0], xmm15
000078d941fcf549  vmovaps xmm15, [rsp+0xC0]
000078d941fcf552  vmovaps [rsp+0xC0], xmm14
000078d941fcf55b  vmovaps xmm14, [rsp+0x40]
000078d941fcf561  vmovaps [rsp+0x40], xmm13
000078d941fcf567  movaps xmm1, xmm15
000078d941fcf56b  mulpd xmm1, xmm14
000078d941fcf570  vcmppd xmm13, xmm1, xmm1, 0x03
000078d941fcf575  ptest xmm13, xmm13
000078d941fcf57b  jnz 0x000078D941FD0682
000078d941fcf581  movq xmm14, qword ptr [r15+0x230]
000078d941fcf58a  vmovaps [rsp+0x100], xmm14
000078d941fcf593  vpermilpd xmm14, xmm14, 0x00
000078d941fcf599  vmovaps [rsp+0x110], xmm1
000078d941fcf5a2  vmovaps xmm1, [rsp+0xE0]
000078d941fcf5ab  vmovaps [rsp+0xE0], xmm15
000078d941fcf5b4  movaps xmm13, xmm1
000078d941fcf5b8  mulpd xmm13, xmm14
000078d941fcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000078d941fcf5c3  ptest xmm15, xmm15
000078d941fcf5c9  jnz 0x000078D941FD07C4
000078d941fcf5cf  vxorps xmm1, xmm1, xmm1
000078d941fcf5d3  vpbroadcastq xmm1, xmm1
000078d941fcf5d8  vmovaps xmm14, [rsp+0xE0]
000078d941fcf5e1  vmovaps [rsp+0xE0], xmm1
000078d941fcf5ea  vmovaps xmm1, [rsp+0xD0]
000078d941fcf5f3  vmovaps [rsp+0xD0], xmm13
000078d941fcf5fc  movaps xmm15, xmm14
000078d941fcf600  mulpd xmm15, xmm1
000078d941fcf605  vcmppd xmm13, xmm15, xmm15, 0x03
000078d941fcf60b  ptest xmm13, xmm13
000078d941fcf611  jnz 0x000078D941FD0907
000078d941fcf617  movaps xmm1, xmm14
000078d941fcf61b  mulpd xmm1, xmm10
000078d941fcf620  vcmppd xmm13, xmm1, xmm1, 0x03
000078d941fcf625  ptest xmm13, xmm13
000078d941fcf62b  jnz 0x000078D941FD0A4A
000078d941fcf631  movaps xmm13, xmm14
000078d941fcf635  mulpd xmm13, xmm2
000078d941fcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000078d941fcf640  ptest xmm10, xmm10
000078d941fcf646  jnz 0x000078D941FD0B8C
000078d941fcf64c  vmovaps [rsp+0x120], xmm7
000078d941fcf655  vmovaps xmm14, [rsp+0x120]
000078d941fcf65e  por xmm7, xmm14
000078d941fcf663  vmovaps xmm14, [rsp+0xC0]
000078d941fcf66c  vmovaps xmm10, [rsp+0xC0]
000078d941fcf675  por xmm14, xmm10
000078d941fcf67a  vmovaps xmm2, [rsp+0x100]
000078d941fcf683  vpermilpd xmm2, xmm2, 0x00
000078d941fcf689  vmovaps [rsp+0xC0], xmm1
000078d941fcf692  vmovaps [rsp+0x120], xmm15
000078d941fcf69b  movaps xmm1, xmm10
000078d941fcf69f  mulpd xmm1, xmm2
000078d941fcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000078d941fcf6a8  ptest xmm15, xmm15
000078d941fcf6ae  jnz 0x000078D941FD0CCF
000078d941fcf6b4  xor eax, eax
000078d941fcf6b6  mov r12d, 0x40
000078d941fcf6bc  mov r11d, 0x200
000078d941fcf6c2  cmp r12, r11
000078d941fcf6c5  cmc
000078d941fcf6c6  lahf
000078d941fcf6c7  seto al
000078d941fcf6ca  mov [r15+0x108], eax
000078d941fcf6d1  vmovaps xmm10, [rsp+0x110]
000078d941fcf6da  vmovaps xmm2, [rsp+0xE0]
000078d941fcf6e3  vmovaps [rsp+0xE0], xmm1
000078d941fcf6ec  movaps xmm15, xmm10
000078d941fcf6f0  addpd xmm15, xmm2
000078d941fcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000078d941fcf6fb  ptest xmm1, xmm1
000078d941fcf700  jnz 0x000078D941FD0E10
000078d941fcf706  vmovaps xmm10, [rsp+0x120]
000078d941fcf70f  vmovaps [rsp+0x110], xmm15
000078d941fcf718  movaps xmm1, xmm10
000078d941fcf71c  addpd xmm1, xmm12
000078d941fcf721  vcmppd xmm15, xmm1, xmm1, 0x03
000078d941fcf726  ptest xmm15, xmm15
000078d941fcf72c  jnz 0x000078D941FD0F53
000078d941fcf732  vmovaps xmm10, [rsp+0xC0]
000078d941fcf73b  vmovaps [rsp+0xC0], xmm1
000078d941fcf744  movaps xmm15, xmm10
000078d941fcf748  addpd xmm15, xmm12
000078d941fcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000078d941fcf753  ptest xmm1, xmm1
000078d941fcf758  jnz 0x000078D941FD1095
000078d941fcf75e  vmovaps xmm1, [rsp+0x30]
000078d941fcf764  vmovaps xmm12, [rsp+0x30]
000078d941fcf76a  por xmm1, xmm12
000078d941fcf76f  vmovaps xmm12, [rsp+0x20]
000078d941fcf775  vmovaps xmm10, [rsp+0x20]
000078d941fcf77b  por xmm12, xmm10
000078d941fcf780  vmovaps [rsp+0x20], xmm5
000078d941fcf786  vmovaps xmm10, [rsp+0x20]
000078d941fcf78c  por xmm5, xmm10
000078d941fcf791  vmovaps [rsp+0x20], xmm11
000078d941fcf797  vmovaps xmm10, [rsp+0x20]
000078d941fcf79d  por xmm11, xmm10
000078d941fcf7a2  vmovaps [rsp+0x20], xmm4
000078d941fcf7a8  vmovaps xmm10, [rsp+0x20]
000078d941fcf7ae  por xmm4, xmm10
000078d941fcf7b3  vmovaps [rsp+0x20], xmm8
000078d941fcf7b9  vmovaps xmm10, [rsp+0x20]
000078d941fcf7bf  por xmm8, xmm10
000078d941fcf7c4  vmovaps xmm10, [rsp+0xF0]
000078d941fcf7cd  vmovaps [rsp+0x20], xmm1
000078d941fcf7d3  vmovaps xmm1, [rsp+0xF0]
000078d941fcf7dc  por xmm10, xmm1
000078d941fcf7e1  lea rax, [r14+0xA0]
000078d941fcf7e8  movups xmm1, [r13+rax*1]
000078d941fcf7ee  lea rax, [r14+0xB0]
000078d941fcf7f5  vmovaps [rsp+0x30], xmm1
000078d941fcf7fb  movups xmm1, [r13+rax*1]
000078d941fcf801  vmovaps [rsp+0xF0], xmm1
000078d941fcf80a  vmovaps [rsp+0x120], xmm15
000078d941fcf813  movaps xmm1, xmm13
000078d941fcf817  addpd xmm1, xmm2
000078d941fcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000078d941fcf820  ptest xmm15, xmm15
000078d941fcf826  jnz 0x000078D941FD11ED
000078d941fcf82c  lea rax, [r14+0xF0]
000078d941fcf833  movups xmm15, [r13+rax*1]
000078d941fcf839  vmovaps xmm2, [rsp+0xC0]
000078d941fcf842  vmovaps [rsp+0xC0], xmm1
000078d941fcf84b  vmovaps xmm1, [rsp+0xE0]
000078d941fcf854  vmovaps [rsp+0xE0], xmm15
000078d941fcf85d  movaps xmm13, xmm2
000078d941fcf861  addpd xmm13, xmm1
000078d941fcf866  vcmppd xmm15, xmm13, xmm13, 0x03
000078d941fcf86c  ptest xmm15, xmm15
000078d941fcf872  jnz 0x000078D941FD1338
000078d941fcf878  vmovaps xmm15, [rsp+0x120]
000078d941fcf881  vmovaps xmm2, [rsp+0xD0]
000078d941fcf88a  vmovaps [rsp+0xD0], xmm14
000078d941fcf893  movaps xmm1, xmm15
000078d941fcf897  addpd xmm1, xmm2
000078d941fcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000078d941fcf8a0  ptest xmm14, xmm14
000078d941fcf8a6  jnz 0x000078D941FD147A
000078d941fcf8ac  vmovaps xmm15, [rsp+0x100]
000078d941fcf8b5  vpermilpd xmm15, xmm15, 0x00
000078d941fcf8bb  vmovaps xmm2, [rsp+0xF0]
000078d941fcf8c4  vmovaps [rsp+0xF0], xmm1
000078d941fcf8cd  movaps xmm14, xmm2
000078d941fcf8d1  mulpd xmm14, xmm15
000078d941fcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000078d941fcf8dc  ptest xmm1, xmm1
000078d941fcf8e1  jnz 0x000078D941FD15BB
000078d941fcf8e7  vmovaps xmm1, [rsp+0xA0]
000078d941fcf8f0  vpermilpd xmm1, xmm1, 0x00
000078d941fcf8f6  vmovaps xmm2, [rsp+0xE0]
000078d941fcf8ff  vmovaps [rsp+0xE0], xmm14
000078d941fcf908  movaps xmm15, xmm2
000078d941fcf90c  mulpd xmm15, xmm1
000078d941fcf911  vcmppd xmm14, xmm15, xmm15, 0x03
000078d941fcf917  ptest xmm14, xmm14
000078d941fcf91d  jnz 0x000078D941FD16FE
000078d941fcf923  lea rax, [r14+0xE0]
000078d941fcf92a  movups xmm1, [r13+rax*1]
000078d941fcf930  vmovaps xmm14, [rsp+0x100]
000078d941fcf939  vpermilpd xmm14, xmm14, 0x00
000078d941fcf93f  vmovaps [rsp+0x100], xmm1
000078d941fcf948  vmovaps xmm1, [rsp+0x30]
000078d941fcf94e  vmovaps [rsp+0x30], xmm15
000078d941fcf954  movaps xmm2, xmm1
000078d941fcf957  mulpd xmm2, xmm14
000078d941fcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000078d941fcf961  ptest xmm15, xmm15
000078d941fcf967  jnz 0x000078D941FD184A
000078d941fcf96d  vmovaps [rsp+0x120], xmm10
000078d941fcf976  vmovaps xmm1, [rsp+0x120]
000078d941fcf97f  por xmm10, xmm1
000078d941fcf984  movaps [r15+0x300], xmm10
000078d941fcf98c  vmovaps [rsp+0x120], xmm8
000078d941fcf995  vmovaps xmm1, [rsp+0x120]
000078d941fcf99e  por xmm8, xmm1
000078d941fcf9a3  movaps [r15+0x190], xmm8
000078d941fcf9ab  vmovaps xmm1, [rsp+0xA0]
000078d941fcf9b4  vpermilpd xmm1, xmm1, 0x00
000078d941fcf9ba  vmovaps xmm14, [rsp+0x100]
000078d941fcf9c3  vmovaps [rsp+0x100], xmm13
000078d941fcf9cc  movaps xmm15, xmm14
000078d941fcf9d0  mulpd xmm15, xmm1
000078d941fcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000078d941fcf9db  ptest xmm13, xmm13
000078d941fcf9e1  jnz 0x000078D941FD198B
000078d941fcf9e7  lea rax, [r14+0x90]
000078d941fcf9ee  movups xmm1, [r13+rax*1]
000078d941fcf9f4  vmovaps [rsp+0x120], xmm4
000078d941fcf9fd  vmovaps xmm14, [rsp+0x120]
000078d941fcfa06  por xmm4, xmm14
000078d941fcfa0b  movaps [r15+0x1C0], xmm4
000078d941fcfa13  vmovaps [rsp+0x120], xmm11
000078d941fcfa1c  vmovaps xmm14, [rsp+0x120]
000078d941fcfa25  por xmm11, xmm14
000078d941fcfa2a  movaps [r15+0x200], xmm11
000078d941fcfa32  vmovaps [rsp+0x120], xmm5
000078d941fcfa3b  vmovaps xmm14, [rsp+0x120]
000078d941fcfa44  por xmm5, xmm14
000078d941fcfa49  movaps [r15+0x2D0], xmm5
000078d941fcfa51  vmovaps [rsp+0x120], xmm12
000078d941fcfa5a  vmovaps xmm14, [rsp+0x120]
000078d941fcfa63  por xmm12, xmm14
000078d941fcfa68  movaps [r15+0x2E0], xmm12
000078d941fcfa70  vmovaps xmm13, [rsp+0x110]
000078d941fcfa79  vmovaps [rsp+0x110], xmm1
000078d941fcfa82  vmovaps xmm1, [rsp+0xE0]
000078d941fcfa8b  vmovaps [rsp+0xE0], xmm15
000078d941fcfa94  movaps xmm14, xmm13
000078d941fcfa98  addpd xmm14, xmm1
000078d941fcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000078d941fcfaa3  ptest xmm15, xmm15
000078d941fcfaa9  jnz 0x000078D941FD1AD8
000078d941fcfaaf  vmovaps xmm1, [rsp+0xA0]
000078d941fcfab8  vpermilpd xmm1, xmm1, 0x00
000078d941fcfabe  vmovaps xmm13, [rsp+0x110]
000078d941fcfac7  vmovaps [rsp+0x110], xmm14
000078d941fcfad0  movaps xmm15, xmm13
000078d941fcfad4  mulpd xmm15, xmm1
000078d941fcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000078d941fcfadf  ptest xmm14, xmm14
000078d941fcfae5  jnz 0x000078D941FD1C1B
000078d941fcfaeb  lea rax, [r14+0x80]
000078d941fcfaf2  movups xmm1, [r13+rax*1]
000078d941fcfaf8  vmovaps xmm13, [rsp+0xC0]
000078d941fcfb01  vmovaps [rsp+0xC0], xmm1
000078d941fcfb0a  movaps xmm14, xmm13
000078d941fcfb0e  addpd xmm14, xmm2
000078d941fcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000078d941fcfb19  ptest xmm1, xmm1
000078d941fcfb1e  jnz 0x000078D941FD1D68
000078d941fcfb24  vmovaps xmm13, [rsp+0x100]
000078d941fcfb2d  vmovaps xmm2, [rsp+0x30]
000078d941fcfb33  vmovaps [rsp+0x30], xmm15
000078d941fcfb39  movaps xmm1, xmm13
000078d941fcfb3d  addpd xmm1, xmm2
000078d941fcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000078d941fcfb46  ptest xmm15, xmm15
000078d941fcfb4c  jnz 0x000078D941FD1EAB
000078d941fcfb52  vmovaps xmm15, [rsp+0x20]
000078d941fcfb58  vmovaps xmm13, [rsp+0x20]
000078d941fcfb5e  por xmm15, xmm13
000078d941fcfb63  movaps [r15+0x2F0], xmm15
000078d941fcfb6b  vmovaps xmm13, [rsp+0xA0]
000078d941fcfb74  vpermilpd xmm13, xmm13, 0x00
000078d941fcfb7a  vmovaps [rsp+0x20], xmm1
000078d941fcfb80  vmovaps xmm1, [rsp+0xC0]
000078d941fcfb89  vmovaps [rsp+0xA0], xmm15
000078d941fcfb92  movaps xmm2, xmm1
000078d941fcfb95  mulpd xmm2, xmm13
000078d941fcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000078d941fcfb9f  ptest xmm15, xmm15
000078d941fcfba5  jnz 0x000078D941FD1FEC
000078d941fcfbab  lea rax, [r14+0xD0]
000078d941fcfbb2  movups xmm1, [r13+rax*1]
000078d941fcfbb8  vmovaps xmm13, [rsp+0xF0]
000078d941fcfbc1  vmovaps [rsp+0xC0], xmm1
000078d941fcfbca  vmovaps xmm1, [rsp+0xE0]
000078d941fcfbd3  vmovaps [rsp+0xE0], xmm14
000078d941fcfbdc  movaps xmm15, xmm13
000078d941fcfbe0  addpd xmm15, xmm1
000078d941fcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000078d941fcfbeb  ptest xmm14, xmm14
000078d941fcfbf1  jnz 0x000078D941FD2137
000078d941fcfbf7  vmovaps xmm1, [rsp+0xB0]
000078d941fcfc00  vpermilpd xmm1, xmm1, 0x00
000078d941fcfc06  movaps xmm14, xmm11
000078d941fcfc0a  mulpd xmm14, xmm1
000078d941fcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000078d941fcfc15  ptest xmm13, xmm13
000078d941fcfc1b  jnz 0x000078D941FD227A
000078d941fcfc21  movaps [r15+0x260], xmm14
000078d941fcfc29  vxorps xmm1, xmm1, xmm1
000078d941fcfc2d  vpbroadcastq xmm1, xmm1
000078d941fcfc32  movaps [r15+0x1B0], xmm1
000078d941fcfc3a  vmovaps xmm1, [rsp+0xB0]
000078d941fcfc43  vpermilpd xmm1, xmm1, 0x00
000078d941fcfc49  vmovaps xmm11, [rsp+0xC0]
000078d941fcfc52  vmovaps [rsp+0xC0], xmm15
000078d941fcfc5b  movaps xmm13, xmm11
000078d941fcfc5f  mulpd xmm13, xmm1
000078d941fcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000078d941fcfc6a  ptest xmm15, xmm15
000078d941fcfc70  jnz 0x000078D941FD23BD
000078d941fcfc76  lea rax, [r14+0xC0]
000078d941fcfc7d  movups xmm1, [r13+rax*1]
000078d941fcfc83  vmovaps xmm11, [rsp+0x110]
000078d941fcfc8c  vmovaps [rsp+0xF0], xmm1
000078d941fcfc95  vmovaps xmm1, [rsp+0x30]
000078d941fcfc9b  vmovaps [rsp+0x30], xmm14
000078d941fcfca1  movaps xmm15, xmm11
000078d941fcfca5  addpd xmm15, xmm1
000078d941fcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000078d941fcfcb0  ptest xmm14, xmm14
000078d941fcfcb6  jnz 0x000078D941FD250A
000078d941fcfcbc  vmovaps [rsp+0x100], xmm9
000078d941fcfcc5  vmovaps xmm1, [rsp+0x100]
000078d941fcfcce  por xmm9, xmm1
000078d941fcfcd3  movaps [r15+0x270], xmm9
000078d941fcfcdb  vmovaps [rsp+0x100], xmm6
000078d941fcfce4  vmovaps xmm1, [rsp+0x100]
000078d941fcfced  por xmm6, xmm1
000078d941fcfcf1  movaps [r15+0x1A0], xmm6
000078d941fcfcf9  vmovaps xmm14, [rsp+0xB0]
000078d941fcfd02  vpermilpd xmm14, xmm14, 0x00
000078d941fcfd08  vmovaps xmm6, [rsp+0xF0]
000078d941fcfd11  vmovaps [rsp+0xF0], xmm1
000078d941fcfd1a  movaps xmm11, xmm6
000078d941fcfd1e  mulpd xmm11, xmm14
000078d941fcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000078d941fcfd29  ptest xmm1, xmm1
000078d941fcfd2e  jnz 0x000078D941FD264D
000078d941fcfd34  lea rax, [r14+0x20]
000078d941fcfd38  movups xmm1, [r13+rax*1]
000078d941fcfd3e  movaps [r15+0x110], xmm1
000078d941fcfd46  vmovaps xmm6, [rsp+0xE0]
000078d941fcfd4f  vmovaps [rsp+0xE0], xmm1
000078d941fcfd58  movaps xmm14, xmm6
000078d941fcfd5c  addpd xmm14, xmm2
000078d941fcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000078d941fcfd67  ptest xmm1, xmm1
000078d941fcfd6c  jnz 0x000078D941FD279A
000078d941fcfd72  vmovaps xmm1, [rsp+0xB0]
000078d941fcfd7b  vpermilpd xmm1, xmm1, 0x00
000078d941fcfd81  movaps xmm6, xmm5
000078d941fcfd84  mulpd xmm6, xmm1
000078d941fcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000078d941fcfd8d  ptest xmm2, xmm2
000078d941fcfd92  jnz 0x000078D941FD28DC
000078d941fcfd98  vmovaps xmm5, [rsp+0x20]
000078d941fcfd9e  movaps xmm1, xmm5
000078d941fcfda1  addpd xmm1, xmm13
000078d941fcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000078d941fcfdab  ptest xmm2, xmm2
000078d941fcfdb0  jnz 0x000078D941FD2A1C
000078d941fcfdb6  vmovaps xmm13, [rsp+0x80]
000078d941fcfdbf  vpermilpd xmm13, xmm13, 0x00
000078d941fcfdc5  vmovaps xmm2, [rsp+0xE0]
000078d941fcfdce  vmovaps [rsp+0x20], xmm1
000078d941fcfdd4  movaps xmm5, xmm2
000078d941fcfdd7  mulpd xmm5, xmm13
000078d941fcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000078d941fcfde1  ptest xmm1, xmm1
000078d941fcfde6  jnz 0x000078D941FD2B5D
000078d941fcfdec  vmovaps xmm1, [rsp+0x80]
000078d941fcfdf5  vpermilpd xmm1, xmm1, 0x00
000078d941fcfdfb  movaps xmm13, xmm10
000078d941fcfdff  mulpd xmm13, xmm1
000078d941fcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000078d941fcfe0a  ptest xmm2, xmm2
000078d941fcfe0f  jnz 0x000078D941FD2C9E
000078d941fcfe15  vmovaps xmm10, [rsp+0x30]
000078d941fcfe1b  movaps xmm1, xmm15
000078d941fcfe1f  addpd xmm1, xmm10
000078d941fcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000078d941fcfe29  ptest xmm2, xmm2
000078d941fcfe2e  jnz 0x000078D941FD2DE1
000078d941fcfe34  vmovaps xmm10, [rsp+0xC0]
000078d941fcfe3d  movaps xmm15, xmm10
000078d941fcfe41  addpd xmm15, xmm11
000078d941fcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000078d941fcfe4c  ptest xmm2, xmm2
000078d941fcfe51  jnz 0x000078D941FD2F23
000078d941fcfe57  vmovaps xmm11, [rsp+0x80]
000078d941fcfe60  vpermilpd xmm11, xmm11, 0x00
000078d941fcfe66  movaps xmm10, xmm12
000078d941fcfe6a  mulpd xmm10, xmm11
000078d941fcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000078d941fcfe75  ptest xmm2, xmm2
000078d941fcfe7a  jnz 0x000078D941FD3067
000078d941fcfe80  vmovaps xmm12, [rsp+0x80]
000078d941fcfe89  vpermilpd xmm12, xmm12, 0x00
000078d941fcfe8f  vmovaps xmm2, [rsp+0xA0]
000078d941fcfe98  vmovaps [rsp+0x30], xmm1
000078d941fcfe9e  movaps xmm11, xmm2
000078d941fcfea2  mulpd xmm11, xmm12
000078d941fcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000078d941fcfead  ptest xmm1, xmm1
000078d941fcfeb2  jnz 0x000078D941FD31AB
000078d941fcfeb8  movaps xmm1, xmm14
000078d941fcfebc  addpd xmm1, xmm6
000078d941fcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000078d941fcfec5  ptest xmm12, xmm12
000078d941fcfecb  jnz 0x000078D941FD32EE
000078d941fcfed1  vmovaps xmm12, [rsp+0x20]
000078d941fcfed7  movaps xmm14, xmm12
000078d941fcfedb  addpd xmm14, xmm5
000078d941fcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000078d941fcfee6  ptest xmm6, xmm6
000078d941fcfeeb  jnz 0x000078D941FD342F
000078d941fcfef1  vmovaps xmm12, [rsp+0x90]
000078d941fcfefa  vpermilpd xmm12, xmm12, 0x00
000078d941fcff00  movaps xmm6, xmm9
000078d941fcff04  mulpd xmm6, xmm12
000078d941fcff09  vcmppd xmm5, xmm6, xmm6, 0x03
000078d941fcff0e  ptest xmm5, xmm5
000078d941fcff13  jnz 0x000078D941FD3572
000078d941fcff19  movaps xmm12, xmm15
000078d941fcff1d  addpd xmm12, xmm13
000078d941fcff22  vcmppd xmm9, xmm12, xmm12, 0x03
000078d941fcff28  ptest xmm9, xmm9
000078d941fcff2e  jnz 0x000078D941FD36B4
000078d941fcff34  vmovaps xmm13, [rsp+0x30]
000078d941fcff3a  movaps xmm15, xmm13
000078d941fcff3e  addpd xmm15, xmm10
000078d941fcff43  vcmppd xmm9, xmm15, xmm15, 0x03
000078d941fcff49  ptest xmm9, xmm9
000078d941fcff4f  jnz 0x000078D941FD37F8
000078d941fcff55  vmovaps xmm13, [rsp+0xD0]
000078d941fcff5e  vmovaps xmm10, [rsp+0xD0]
000078d941fcff67  por xmm13, xmm10
000078d941fcff6c  movaps [r15+0x250], xmm13
000078d941fcff74  vmovaps [rsp+0x20], xmm7
000078d941fcff7a  vmovaps xmm13, [rsp+0x20]
000078d941fcff80  por xmm7, xmm13
000078d941fcff85  movaps [r15+0x2A0], xmm7
000078d941fcff8d  vmovaps [rsp+0x20], xmm3
000078d941fcff93  vmovaps xmm13, [rsp+0x20]
000078d941fcff99  por xmm3, xmm13
000078d941fcff9e  movaps [r15+0x1D0], xmm3
000078d941fcffa6  lea rax, [r14+0x40]
000078d941fcffaa  movups xmm13, [r13+rax*1]
000078d941fcffb0  movaps [r15+0x2C0], xmm13
000078d941fcffb8  vmovaps xmm10, [rsp+0x90]
000078d941fcffc1  vpermilpd xmm10, xmm10, 0x00
000078d941fcffc7  movaps xmm9, xmm8
000078d941fcffcb  mulpd xmm9, xmm10
000078d941fcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000078d941fcffd6  ptest xmm5, xmm5
000078d941fcffdb  jnz 0x000078D941FD3946
000078d941fcffe1  movaps xmm10, xmm1
000078d941fcffe5  addpd xmm10, xmm11
000078d941fcffea  vcmppd xmm8, xmm10, xmm10, 0x03
000078d941fcfff0  ptest xmm8, xmm8
000078d941fcfff6  jnz 0x000078D941FD3A8A
000078d941fcfffc  movaps xmm1, xmm14
000078d941fd0000  addpd xmm1, xmm6
000078d941fd0004  vcmppd xmm11, xmm1, xmm1, 0x03
000078d941fd0009  ptest xmm11, xmm11
000078d941fd000f  jnz 0x000078D941FD3BCD
000078d941fd0015  vmovaps xmm14, [rsp+0x90]
000078d941fd001e  vpermilpd xmm14, xmm14, 0x00
000078d941fd0024  movaps xmm11, xmm13
000078d941fd0028  mulpd xmm11, xmm14
000078d941fd002d  vcmppd xmm8, xmm11, xmm11, 0x03
000078d941fd0033  ptest xmm8, xmm8
000078d941fd0039  jnz 0x000078D941FD3D0E
000078d941fd003f  vmovaps xmm14, [rsp+0x90]
000078d941fd0048  vpermilpd xmm14, xmm14, 0x00
000078d941fd004e  vmovaps xmm8, [rsp+0x10]
000078d941fd0054  movaps xmm13, xmm8
000078d941fd0058  mulpd xmm13, xmm14
000078d941fd005d  vcmppd xmm6, xmm13, xmm13, 0x03
000078d941fd0063  ptest xmm6, xmm6
000078d941fd0068  jnz 0x000078D941FD3E52
000078d941fd006e  vmovaps xmm14, [rsp+0x60]
000078d941fd0074  vpermilpd xmm14, xmm14, 0x00
000078d941fd007a  movaps xmm8, xmm7
000078d941fd007e  mulpd xmm8, xmm14
000078d941fd0083  vcmppd xmm6, xmm8, xmm8, 0x03
000078d941fd0089  ptest xmm6, xmm6
000078d941fd008e  jnz 0x000078D941FD3F96
000078d941fd0094  movaps xmm14, xmm12
000078d941fd0098  addpd xmm14, xmm9
000078d941fd009d  vcmppd xmm7, xmm14, xmm14, 0x03
000078d941fd00a3  ptest xmm7, xmm7
000078d941fd00a8  jnz 0x000078D941FD40D9
000078d941fd00ae  vmovaps xmm12, [rsp+0x60]
000078d941fd00b4  vpermilpd xmm12, xmm12, 0x00
000078d941fd00ba  vmovaps xmm7, [rsp+0xF0]
000078d941fd00c3  movaps xmm9, xmm7
000078d941fd00c7  mulpd xmm9, xmm12
000078d941fd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000078d941fd00d2  ptest xmm6, xmm6
000078d941fd00d7  jnz 0x000078D941FD421D
000078d941fd00dd  movaps xmm12, xmm15
000078d941fd00e1  addpd xmm12, xmm11
000078d941fd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000078d941fd00ec  ptest xmm7, xmm7
000078d941fd00f1  jnz 0x000078D941FD4360
000078d941fd00f7  vmovaps xmm15, [rsp+0x60]
000078d941fd00fd  vpermilpd xmm15, xmm15, 0x00
000078d941fd0103  vmovaps xmm7, [rsp+0x40]
000078d941fd0109  movaps xmm11, xmm7
000078d941fd010d  mulpd xmm11, xmm15
000078d941fd0112  vcmppd xmm6, xmm11, xmm11, 0x03
000078d941fd0118  ptest xmm6, xmm6
000078d941fd011d  jnz 0x000078D941FD44A4
000078d941fd0123  movaps xmm15, xmm10
000078d941fd0127  addpd xmm15, xmm13
000078d941fd012c  vcmppd xmm7, xmm15, xmm15, 0x03
000078d941fd0132  ptest xmm7, xmm7
000078d941fd0137  jnz 0x000078D941FD45E7
000078d941fd013d  vmovaps xmm13, [rsp+0x60]
000078d941fd0143  vpermilpd xmm13, xmm13, 0x00
000078d941fd0149  vmovaps xmm7, [rsp+0x50]
000078d941fd014f  movaps xmm10, xmm7
000078d941fd0153  mulpd xmm10, xmm13
000078d941fd0158  vcmppd xmm6, xmm10, xmm10, 0x03
000078d941fd015e  ptest xmm6, xmm6
000078d941fd0163  jnz 0x000078D941FD472B
000078d941fd0169  movaps xmm13, xmm1
000078d941fd016d  addpd xmm13, xmm8
000078d941fd0172  vcmppd xmm7, xmm13, xmm13, 0x03
000078d941fd0178  ptest xmm7, xmm7
000078d941fd017d  jnz 0x000078D941FD486E
000078d941fd0183  lea rax, [r14+0x70]
000078d941fd0187  movups xmm1, [r13+rax*1]
000078d941fd018d  movaps [r15+0x240], xmm1
000078d941fd0195  movaps xmm8, xmm14
000078d941fd0199  addpd xmm8, xmm9
000078d941fd019e  vcmppd xmm7, xmm8, xmm8, 0x03
000078d941fd01a4  ptest xmm7, xmm7
000078d941fd01a9  jnz 0x000078D941FD49BB
000078d941fd01af  movaps [r15+0x170], xmm8
000078d941fd01b7  vmovaps xmm14, [rsp+0x70]
000078d941fd01bd  vpermilpd xmm14, xmm14, 0x00
000078d941fd01c3  movaps xmm9, xmm1
000078d941fd01c7  mulpd xmm9, xmm14
000078d941fd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000078d941fd01d2  ptest xmm7, xmm7
000078d941fd01d7  jnz 0x000078D941FD4AFF
000078d941fd01dd  vmovaps xmm1, [rsp+0x70]
000078d941fd01e3  vpermilpd xmm1, xmm1, 0x00
000078d941fd01e9  movaps xmm14, xmm4
000078d941fd01ed  mulpd xmm14, xmm1
000078d941fd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000078d941fd01f8  ptest xmm7, xmm7
000078d941fd01fd  jnz 0x000078D941FD4C42
000078d941fd0203  movaps [r15+0x180], xmm14
000078d941fd020b  movaps xmm1, xmm12
000078d941fd020f  addpd xmm1, xmm11
000078d941fd0214  vcmppd xmm7, xmm1, xmm1, 0x03
000078d941fd0219  ptest xmm7, xmm7
000078d941fd021e  jnz 0x000078D941FD4D84
000078d941fd0224  movaps [r15+0x210], xmm1
000078d941fd022c  movups xmm12, [r13+r14*1]
000078d941fd0232  lea rax, [r14+0x10]
000078d941fd0236  movups xmm11, [r13+rax*1]
000078d941fd023c  movaps [r15+0x230], xmm11
000078d941fd0244  movaps xmm7, xmm15
000078d941fd0248  addpd xmm7, xmm10
000078d941fd024d  vcmppd xmm6, xmm7, xmm7, 0x03
000078d941fd0252  ptest xmm6, xmm6
000078d941fd0257  jnz 0x000078D941FD4EDA
000078d941fd025d  movaps [r15+0x130], xmm7
000078d941fd0265  vmovaps xmm15, [rsp+0x70]
000078d941fd026b  vpermilpd xmm15, xmm15, 0x00
000078d941fd0271  movaps xmm10, xmm11
000078d941fd0275  mulpd xmm10, xmm15
000078d941fd027a  vcmppd xmm6, xmm10, xmm10, 0x03
000078d941fd0280  ptest xmm6, xmm6
000078d941fd0285  jnz 0x000078D941FD501C
000078d941fd028b  movaps [r15+0x220], xmm10
000078d941fd0293  vmovaps xmm15, [rsp+0x70]
000078d941fd0299  vpermilpd xmm15, xmm15, 0x00
000078d941fd029f  movaps xmm11, xmm12
000078d941fd02a3  mulpd xmm11, xmm15
000078d941fd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000078d941fd02ae  ptest xmm6, xmm6
000078d941fd02b3  jnz 0x000078D941FD5160
000078d941fd02b9  movaps xmm15, xmm13
000078d941fd02bd  addpd xmm15, xmm9
000078d941fd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000078d941fd02c8  ptest xmm12, xmm12
000078d941fd02ce  jnz 0x000078D941FD52A4
000078d941fd02d4  movaps [r15+0x140], xmm15
000078d941fd02dc  movaps xmm13, xmm8
000078d941fd02e0  addpd xmm13, xmm14
000078d941fd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000078d941fd02eb  ptest xmm12, xmm12
000078d941fd02f1  jnz 0x000078D941FD53E8
000078d941fd02f7  movaps [r15+0x150], xmm13
000078d941fd02ff  movaps xmm14, xmm1
000078d941fd0303  addpd xmm14, xmm10
000078d941fd0308  vcmppd xmm12, xmm14, xmm14, 0x03
000078d941fd030e  ptest xmm12, xmm12
000078d941fd0314  jnz 0x000078D941FD552C
000078d941fd031a  movaps [r15+0x160], xmm14
000078d941fd0322  movaps xmm1, xmm7
000078d941fd0325  addpd xmm1, xmm11
000078d941fd032a  vcmppd xmm12, xmm1, xmm1, 0x03
000078d941fd032f  ptest xmm12, xmm12
000078d941fd0335  jnz 0x000078D941FD566F
000078d941fd033b  movaps [r15+0x120], xmm1
000078d941fd0343  mov eax, 0x430920
000078d941fd0348  movups [r13+rax*1], xmm15
000078d941fd034e  mov eax, 0x430930
000078d941fd0353  movups [r13+rax*1], xmm13
000078d941fd0359  mov eax, 0x430940
000078d941fd035e  movups [r13+rax*1], xmm14
000078d941fd0364  mov eax, 0x430950
000078d941fd0369  movups [r13+rax*1], xmm1
000078d941fd036f  mov eax, [r15+0x108]
000078d941fd0376  sahf
000078d941fd0377  jnz 0x000078D941FD03A9
000078d941fd0379  cmp dword ptr [r15+0x318], 0x00
000078d941fd0381  jz 0x000078D941FDB900
000078d941fd0387  nop [rax+rax*1], ax
000078d941fd0390  nop [rax+rax*1], eax
000078d941fd0398  mov eax, 0x410444
000078d941fd039d  mov [r15+0x100], rax
000078d941fd03a4  jmp 0x000078D941DFE110
000078d941fd03a9  cmp dword ptr [r15+0x318], 0x00
000078d941fd03b1  jz 0x000078D941FD57E0
000078d941fd03b7  nop [rax+rax*1], ax
000078d941fd03c0  nop [rax+rax*1], eax
000078d941fd03c8  mov eax, 0x410278
000078d941fd03cd  mov [r15+0x100], rax
000078d941fd03d4  jmp 0x000078D941DFE110
000078d941fd03d9  int3
000078d941fd03da  call 0x000078D941EB52F0
000078d941fd03df  jmp 0x000078D941FCF016
000078d941fd03e4  call 0x000078D941EC4620
000078d941fd03e9  jmp 0x000078D941FCF023
000078d941fd03ee  call 0x000078D941EC33A0
000078d941fd03f3  jmp 0x000078D941FCF035
000078d941fd03f8  call 0x000078D941EC2120
000078d941fd03fd  jmp 0x000078D941FCF03F
000078d941fd0402  call 0x000078D941EC0860
000078d941fd0407  jmp 0x000078D941FCF067
000078d941fd040c  call 0x000078D941EBF5F0
000078d941fd0411  jmp 0x000078D941FCF073
000078d941fd0416  call 0x000078D941EC0860
000078d941fd041b  jmp 0x000078D941FCF0A5
000078d941fd0420  call 0x000078D941EBF5F0
000078d941fd0425  jmp 0x000078D941FCF0B1
000078d941fd042a  call 0x000078D941EC4740
000078d941fd042f  jmp 0x000078D941FCF0BE
000078d941fd0434  call 0x000078D941EB5400
000078d941fd0439  jmp 0x000078D941FCF0CB
000078d941fd043e  call 0x000078D941EB52F0
000078d941fd0443  jmp 0x000078D941FCF0D8
000078d941fd0448  call 0x000078D941EC4620
000078d941fd044d  jmp 0x000078D941FCF0E5
000078d941fd0452  call 0x000078D941EC0860
000078d941fd0457  jmp 0x000078D941FCF10D
000078d941fd045c  call 0x000078D941EBF5F0
000078d941fd0461  jmp 0x000078D941FCF119
000078d941fd0466  call 0x000078D941E09D70
000078d941fd046b  jmp 0x000078D941FCF11F
000078d941fd0470  call 0x000078D941EBE9C0
000078d941fd0475  jmp 0x000078D941FCF129
000078d941fd047a  call 0x000078D941EC0860
000078d941fd047f  jmp 0x000078D941FCF151
000078d941fd0484  call 0x000078D941EBF5F0
000078d941fd0489  jmp 0x000078D941FCF15D
000078d941fd048e  call 0x000078D941EBD750
000078d941fd0493  jmp 0x000078D941FCF16A
000078d941fd0498  call 0x000078D941EBC4E0
000078d941fd049d  jmp 0x000078D941FCF177
000078d941fd04a2  call 0x000078D941EC4740
000078d941fd04a7  jmp 0x000078D941FCF184
000078d941fd04ac  call 0x000078D941EB5400
000078d941fd04b1  jmp 0x000078D941FCF191
000078d941fd04b6  call 0x000078D941EB52F0
000078d941fd04bb  jmp 0x000078D941FCF19E
000078d941fd04c0  call 0x000078D941EC4620
000078d941fd04c5  jmp 0x000078D941FCF1AB
000078d941fd04ca  call 0x000078D941EC0860
000078d941fd04cf  jmp 0x000078D941FCF1BE
000078d941fd04d4  call 0x000078D941EBB270
000078d941fd04d9  jmp 0x000078D941FCF1CB
000078d941fd04de  call 0x000078D941EBA000
000078d941fd04e3  jmp 0x000078D941FCF1D8
000078d941fd04e8  call 0x000078D941EB8D90
000078d941fd04ed  jmp 0x000078D941FCF1E5
000078d941fd04f2  call 0x000078D941EB8A20
000078d941fd04f7  jmp 0x000078D941FCF1F2
000078d941fd04fc  call 0x000078D941EB5400
000078d941fd0501  jmp 0x000078D941FCF1FC
000078d941fd0506  call 0x000078D941EC2240
000078d941fd050b  jmp 0x000078D941FCF206
000078d941fd0510  call 0x000078D941EB52F0
000078d941fd0515  jmp 0x000078D941FCF210
000078d941fd051a  call 0x000078D941EC2120
000078d941fd051f  jmp 0x000078D941FCF21A
000078d941fd0524  call 0x000078D941EB77B0
000078d941fd0529  jmp 0x000078D941FCF224
000078d941fd052e  call 0x000078D941EB6550
000078d941fd0533  jmp 0x000078D941FCF22E
000078d941fd0538  call 0x000078D941EBFD50
000078d941fd053d  jmp 0x000078D941FCF240
000078d941fd0542  call 0x000078D941EB8EA0
000078d941fd0547  jmp 0x000078D941FCF24A
000078d941fd054c  call 0x000078D941EBFC30
000078d941fd0551  jmp 0x000078D941FCF257
000078d941fd0556  call 0x000078D941EB8D90
000078d941fd055b  jmp 0x000078D941FCF264
000078d941fd0560  call 0x000078D941EC2240
000078d941fd0565  jmp 0x000078D941FCF271
000078d941fd056a  call 0x000078D941EB5400
000078d941fd056f  jmp 0x000078D941FCF27E
000078d941fd0574  call 0x000078D941EB52F0
000078d941fd0579  jmp 0x000078D941FCF28B
000078d941fd057e  call 0x000078D941EC2120
000078d941fd0583  jmp 0x000078D941FCF298
000078d941fd0588  call 0x000078D941EB52F0
000078d941fd058d  jmp 0x000078D941FCF2AB
000078d941fd0592  call 0x000078D941EB52F0
000078d941fd0597  jmp 0x000078D941FCF2BE
000078d941fd059c  call 0x000078D941EB52F0
000078d941fd05a1  jmp 0x000078D941FCF2D1
000078d941fd05a6  call 0x000078D941EB52F0
000078d941fd05ab  jmp 0x000078D941FCF2E4
000078d941fd05b0  call 0x000078D941EC2240
000078d941fd05b5  jmp 0x000078D941FCF2F9
000078d941fd05ba  call 0x000078D941EC2240
000078d941fd05bf  jmp 0x000078D941FCF30C
000078d941fd05c4  call 0x000078D941EC2120
000078d941fd05c9  jmp 0x000078D941FCF319
000078d941fd05ce  call 0x000078D941EB52F0
000078d941fd05d3  jmp 0x000078D941FCF32C
000078d941fd05d8  call 0x000078D941EB52F0
000078d941fd05dd  jmp 0x000078D941FCF34F
000078d941fd05e2  call 0x000078D941EB52F0
000078d941fd05e7  jmp 0x000078D941FCF362
000078d941fd05ec  call 0x000078D941DFF540
000078d941fd05f1  jmp 0x000078D941FCF380
000078d941fd05f6  call 0x000078D941E08C20
000078d941fd05fb  jmp 0x000078D941FCF38A
000078d941fd0600  call 0x000078D941ED6600
000078d941fd0605  jmp 0x000078D941FCF396
000078d941fd060a  call 0x000078D941DFF540
000078d941fd060f  jmp 0x000078D941FCF3A6
000078d941fd0614  call 0x000078D941EC0370
000078d941fd0619  jmp 0x000078D941FCF3D4
000078d941fd061e  call 0x000078D941EBF100
000078d941fd0623  jmp 0x000078D941FCF3DD
000078d941fd0628  call 0x000078D941EC0370
000078d941fd062d  jmp 0x000078D941FCF43B
000078d941fd0632  call 0x000078D941EBF100
000078d941fd0637  jmp 0x000078D941FCF444
000078d941fd063c  call 0x000078D941EC0370
000078d941fd0641  jmp 0x000078D941FCF48B
000078d941fd0646  call 0x000078D941EBF100
000078d941fd064b  jmp 0x000078D941FCF494
000078d941fd0650  call 0x000078D941E0B720
000078d941fd0655  jmp 0x000078D941FCF4D7
000078d941fd065a  call 0x000078D941EB47C0
000078d941fd065f  jmp 0x000078D941FCF4EA
000078d941fd0664  call 0x000078D941E08B00
000078d941fd0669  jmp 0x000078D941FCF501
000078d941fd066e  call 0x000078D941DFF430
000078d941fd0673  jmp 0x000078D941FCF514
000078d941fd0678  call 0x000078D941DFF430
000078d941fd067d  jmp 0x000078D941FCF527
000078d941fd0682  sub rsp, 0x08
000078d941fd0686  push rax
000078d941fd0687  push rcx
000078d941fd0688  push rdx
000078d941fd0689  push rdi
000078d941fd068a  push rsi
000078d941fd068b  push r8
000078d941fd068d  push r9
000078d941fd068f  push r10
000078d941fd0691  push r11
000078d941fd0693  sub rsp, 0xF0
000078d941fd069a  vmovaps [rsp], xmm0
000078d941fd069f  vmovaps [rsp+0x10], xmm2
000078d941fd06a5  vmovaps [rsp+0x20], xmm3
000078d941fd06ab  vmovaps [rsp+0x30], xmm4
000078d941fd06b1  vmovaps [rsp+0x40], xmm5
000078d941fd06b7  vmovaps [rsp+0x50], xmm6
000078d941fd06bd  vmovaps [rsp+0x60], xmm7
000078d941fd06c3  vmovaps [rsp+0x70], xmm8
000078d941fd06c9  vmovaps [rsp+0x80], xmm9
000078d941fd06d2  vmovaps [rsp+0x90], xmm10
000078d941fd06db  vmovaps [rsp+0xA0], xmm11
000078d941fd06e4  vmovaps [rsp+0xB0], xmm12
000078d941fd06ed  vmovaps [rsp+0xC0], xmm13
000078d941fd06f6  vmovaps [rsp+0xD0], xmm14
000078d941fd06ff  vmovaps [rsp+0xE0], xmm15
000078d941fd0708  sub rsp, 0x30
000078d941fd070c  movaps [rsp], xmm1
000078d941fd0710  movaps [rsp+0x10], xmm15
000078d941fd0716  movaps [rsp+0x20], xmm14
000078d941fd071c  lea rdi, [rsp]
000078d941fd0720  mov esi, 0x00
000078d941fd0725  mov rax, 0x59BFBFBAA530
000078d941fd072f  call rax
000078d941fd0731  movaps xmm1, [rsp]
000078d941fd0735  add rsp, 0x30
000078d941fd0739  vmovaps xmm0, [rsp]
000078d941fd073e  vmovaps xmm2, [rsp+0x10]
000078d941fd0744  vmovaps xmm3, [rsp+0x20]
000078d941fd074a  vmovaps xmm4, [rsp+0x30]
000078d941fd0750  vmovaps xmm5, [rsp+0x40]
000078d941fd0756  vmovaps xmm6, [rsp+0x50]
000078d941fd075c  vmovaps xmm7, [rsp+0x60]
000078d941fd0762  vmovaps xmm8, [rsp+0x70]
000078d941fd0768  vmovaps xmm9, [rsp+0x80]
000078d941fd0771  vmovaps xmm10, [rsp+0x90]
000078d941fd077a  vmovaps xmm11, [rsp+0xA0]
000078d941fd0783  vmovaps xmm12, [rsp+0xB0]
000078d941fd078c  vmovaps xmm13, [rsp+0xC0]
000078d941fd0795  vmovaps xmm14, [rsp+0xD0]
000078d941fd079e  vmovaps xmm15, [rsp+0xE0]
000078d941fd07a7  add rsp, 0xF0
000078d941fd07ae  pop r11
000078d941fd07b0  pop r10
000078d941fd07b2  pop r9
000078d941fd07b4  pop r8
000078d941fd07b6  pop rsi
000078d941fd07b7  pop rdi
000078d941fd07b8  pop rdx
000078d941fd07b9  pop rcx
000078d941fd07ba  pop rax
000078d941fd07bb  add rsp, 0x08
000078d941fd07bf  jmp 0x000078D941FCF581
000078d941fd07c4  sub rsp, 0x08
000078d941fd07c8  push rax
000078d941fd07c9  push rcx
000078d941fd07ca  push rdx
000078d941fd07cb  push rdi
000078d941fd07cc  push rsi
000078d941fd07cd  push r8
000078d941fd07cf  push r9
000078d941fd07d1  push r10
000078d941fd07d3  push r11
000078d941fd07d5  sub rsp, 0xF0
000078d941fd07dc  vmovaps [rsp], xmm0
000078d941fd07e1  vmovaps [rsp+0x10], xmm1
000078d941fd07e7  vmovaps [rsp+0x20], xmm2
000078d941fd07ed  vmovaps [rsp+0x30], xmm3
000078d941fd07f3  vmovaps [rsp+0x40], xmm4
000078d941fd07f9  vmovaps [rsp+0x50], xmm5
000078d941fd07ff  vmovaps [rsp+0x60], xmm6
000078d941fd0805  vmovaps [rsp+0x70], xmm7
000078d941fd080b  vmovaps [rsp+0x80], xmm8
000078d941fd0814  vmovaps [rsp+0x90], xmm9
000078d941fd081d  vmovaps [rsp+0xA0], xmm10
000078d941fd0826  vmovaps [rsp+0xB0], xmm11
000078d941fd082f  vmovaps [rsp+0xC0], xmm12
000078d941fd0838  vmovaps [rsp+0xD0], xmm14
000078d941fd0841  vmovaps [rsp+0xE0], xmm15
000078d941fd084a  sub rsp, 0x30
000078d941fd084e  movaps [rsp], xmm13
000078d941fd0853  movaps [rsp+0x10], xmm1
000078d941fd0858  movaps [rsp+0x20], xmm14
000078d941fd085e  lea rdi, [rsp]
000078d941fd0862  mov esi, 0x00
000078d941fd0867  mov rax, 0x59BFBFBAA530
000078d941fd0871  call rax
000078d941fd0873  movaps xmm13, [rsp]
000078d941fd0878  add rsp, 0x30
000078d941fd087c  vmovaps xmm0, [rsp]
000078d941fd0881  vmovaps xmm1, [rsp+0x10]
000078d941fd0887  vmovaps xmm2, [rsp+0x20]
000078d941fd088d  vmovaps xmm3, [rsp+0x30]
000078d941fd0893  vmovaps xmm4, [rsp+0x40]
000078d941fd0899  vmovaps xmm5, [rsp+0x50]
000078d941fd089f  vmovaps xmm6, [rsp+0x60]
000078d941fd08a5  vmovaps xmm7, [rsp+0x70]
000078d941fd08ab  vmovaps xmm8, [rsp+0x80]
000078d941fd08b4  vmovaps xmm9, [rsp+0x90]
000078d941fd08bd  vmovaps xmm10, [rsp+0xA0]
000078d941fd08c6  vmovaps xmm11, [rsp+0xB0]
000078d941fd08cf  vmovaps xmm12, [rsp+0xC0]
000078d941fd08d8  vmovaps xmm14, [rsp+0xD0]
000078d941fd08e1  vmovaps xmm15, [rsp+0xE0]
000078d941fd08ea  add rsp, 0xF0
000078d941fd08f1  pop r11
000078d941fd08f3  pop r10
000078d941fd08f5  pop r9
000078d941fd08f7  pop r8
000078d941fd08f9  pop rsi
000078d941fd08fa  pop rdi
000078d941fd08fb  pop rdx
000078d941fd08fc  pop rcx
000078d941fd08fd  pop rax
000078d941fd08fe  add rsp, 0x08
000078d941fd0902  jmp 0x000078D941FCF5CF
000078d941fd0907  sub rsp, 0x08
000078d941fd090b  push rax
000078d941fd090c  push rcx
000078d941fd090d  push rdx
000078d941fd090e  push rdi
000078d941fd090f  push rsi
000078d941fd0910  push r8
000078d941fd0912  push r9
000078d941fd0914  push r10
000078d941fd0916  push r11
000078d941fd0918  sub rsp, 0xF0
000078d941fd091f  vmovaps [rsp], xmm0
000078d941fd0924  vmovaps [rsp+0x10], xmm1
000078d941fd092a  vmovaps [rsp+0x20], xmm2
000078d941fd0930  vmovaps [rsp+0x30], xmm3
000078d941fd0936  vmovaps [rsp+0x40], xmm4
000078d941fd093c  vmovaps [rsp+0x50], xmm5
000078d941fd0942  vmovaps [rsp+0x60], xmm6
000078d941fd0948  vmovaps [rsp+0x70], xmm7
000078d941fd094e  vmovaps [rsp+0x80], xmm8
000078d941fd0957  vmovaps [rsp+0x90], xmm9
000078d941fd0960  vmovaps [rsp+0xA0], xmm10
000078d941fd0969  vmovaps [rsp+0xB0], xmm11
000078d941fd0972  vmovaps [rsp+0xC0], xmm12
000078d941fd097b  vmovaps [rsp+0xD0], xmm13
000078d941fd0984  vmovaps [rsp+0xE0], xmm14
000078d941fd098d  sub rsp, 0x30
000078d941fd0991  movaps [rsp], xmm15
000078d941fd0996  movaps [rsp+0x10], xmm14
000078d941fd099c  movaps [rsp+0x20], xmm1
000078d941fd09a1  lea rdi, [rsp]
000078d941fd09a5  mov esi, 0x00
000078d941fd09aa  mov rax, 0x59BFBFBAA530
000078d941fd09b4  call rax
000078d941fd09b6  movaps xmm15, [rsp]
000078d941fd09bb  add rsp, 0x30
000078d941fd09bf  vmovaps xmm0, [rsp]
000078d941fd09c4  vmovaps xmm1, [rsp+0x10]
000078d941fd09ca  vmovaps xmm2, [rsp+0x20]
000078d941fd09d0  vmovaps xmm3, [rsp+0x30]
000078d941fd09d6  vmovaps xmm4, [rsp+0x40]
000078d941fd09dc  vmovaps xmm5, [rsp+0x50]
000078d941fd09e2  vmovaps xmm6, [rsp+0x60]
000078d941fd09e8  vmovaps xmm7, [rsp+0x70]
000078d941fd09ee  vmovaps xmm8, [rsp+0x80]
000078d941fd09f7  vmovaps xmm9, [rsp+0x90]
000078d941fd0a00  vmovaps xmm10, [rsp+0xA0]
000078d941fd0a09  vmovaps xmm11, [rsp+0xB0]
000078d941fd0a12  vmovaps xmm12, [rsp+0xC0]
000078d941fd0a1b  vmovaps xmm13, [rsp+0xD0]
000078d941fd0a24  vmovaps xmm14, [rsp+0xE0]
000078d941fd0a2d  add rsp, 0xF0
000078d941fd0a34  pop r11
000078d941fd0a36  pop r10
000078d941fd0a38  pop r9
000078d941fd0a3a  pop r8
000078d941fd0a3c  pop rsi
000078d941fd0a3d  pop rdi
000078d941fd0a3e  pop rdx
000078d941fd0a3f  pop rcx
000078d941fd0a40  pop rax
000078d941fd0a41  add rsp, 0x08
000078d941fd0a45  jmp 0x000078D941FCF617
000078d941fd0a4a  sub rsp, 0x08
000078d941fd0a4e  push rax
000078d941fd0a4f  push rcx
000078d941fd0a50  push rdx
000078d941fd0a51  push rdi
000078d941fd0a52  push rsi
000078d941fd0a53  push r8
000078d941fd0a55  push r9
000078d941fd0a57  push r10
000078d941fd0a59  push r11
000078d941fd0a5b  sub rsp, 0xF0
000078d941fd0a62  vmovaps [rsp], xmm0
000078d941fd0a67  vmovaps [rsp+0x10], xmm2
000078d941fd0a6d  vmovaps [rsp+0x20], xmm3
000078d941fd0a73  vmovaps [rsp+0x30], xmm4
000078d941fd0a79  vmovaps [rsp+0x40], xmm5
000078d941fd0a7f  vmovaps [rsp+0x50], xmm6
000078d941fd0a85  vmovaps [rsp+0x60], xmm7
000078d941fd0a8b  vmovaps [rsp+0x70], xmm8
000078d941fd0a91  vmovaps [rsp+0x80], xmm9
000078d941fd0a9a  vmovaps [rsp+0x90], xmm10
000078d941fd0aa3  vmovaps [rsp+0xA0], xmm11
000078d941fd0aac  vmovaps [rsp+0xB0], xmm12
000078d941fd0ab5  vmovaps [rsp+0xC0], xmm13
000078d941fd0abe  vmovaps [rsp+0xD0], xmm14
000078d941fd0ac7  vmovaps [rsp+0xE0], xmm15
000078d941fd0ad0  sub rsp, 0x30
000078d941fd0ad4  movaps [rsp], xmm1
000078d941fd0ad8  movaps [rsp+0x10], xmm14
000078d941fd0ade  movaps [rsp+0x20], xmm10
000078d941fd0ae4  lea rdi, [rsp]
000078d941fd0ae8  mov esi, 0x00
000078d941fd0aed  mov rax, 0x59BFBFBAA530
000078d941fd0af7  call rax
000078d941fd0af9  movaps xmm1, [rsp]
000078d941fd0afd  add rsp, 0x30
000078d941fd0b01  vmovaps xmm0, [rsp]
000078d941fd0b06  vmovaps xmm2, [rsp+0x10]
000078d941fd0b0c  vmovaps xmm3, [rsp+0x20]
000078d941fd0b12  vmovaps xmm4, [rsp+0x30]
000078d941fd0b18  vmovaps xmm5, [rsp+0x40]
000078d941fd0b1e  vmovaps xmm6, [rsp+0x50]
000078d941fd0b24  vmovaps xmm7, [rsp+0x60]
000078d941fd0b2a  vmovaps xmm8, [rsp+0x70]
000078d941fd0b30  vmovaps xmm9, [rsp+0x80]
000078d941fd0b39  vmovaps xmm10, [rsp+0x90]
000078d941fd0b42  vmovaps xmm11, [rsp+0xA0]
000078d941fd0b4b  vmovaps xmm12, [rsp+0xB0]
000078d941fd0b54  vmovaps xmm13, [rsp+0xC0]
000078d941fd0b5d  vmovaps xmm14, [rsp+0xD0]
000078d941fd0b66  vmovaps xmm15, [rsp+0xE0]
000078d941fd0b6f  add rsp, 0xF0
000078d941fd0b76  pop r11
000078d941fd0b78  pop r10
000078d941fd0b7a  pop r9
000078d941fd0b7c  pop r8
000078d941fd0b7e  pop rsi
000078d941fd0b7f  pop rdi
000078d941fd0b80  pop rdx
000078d941fd0b81  pop rcx
000078d941fd0b82  pop rax
000078d941fd0b83  add rsp, 0x08
000078d941fd0b87  jmp 0x000078D941FCF631
000078d941fd0b8c  sub rsp, 0x08
000078d941fd0b90  push rax
000078d941fd0b91  push rcx
000078d941fd0b92  push rdx
000078d941fd0b93  push rdi
000078d941fd0b94  push rsi
000078d941fd0b95  push r8
000078d941fd0b97  push r9
000078d941fd0b99  push r10
000078d941fd0b9b  push r11
000078d941fd0b9d  sub rsp, 0xF0
000078d941fd0ba4  vmovaps [rsp], xmm0
000078d941fd0ba9  vmovaps [rsp+0x10], xmm1
000078d941fd0baf  vmovaps [rsp+0x20], xmm2
000078d941fd0bb5  vmovaps [rsp+0x30], xmm3
000078d941fd0bbb  vmovaps [rsp+0x40], xmm4
000078d941fd0bc1  vmovaps [rsp+0x50], xmm5
000078d941fd0bc7  vmovaps [rsp+0x60], xmm6
000078d941fd0bcd  vmovaps [rsp+0x70], xmm7
000078d941fd0bd3  vmovaps [rsp+0x80], xmm8
000078d941fd0bdc  vmovaps [rsp+0x90], xmm9
000078d941fd0be5  vmovaps [rsp+0xA0], xmm10
000078d941fd0bee  vmovaps [rsp+0xB0], xmm11
000078d941fd0bf7  vmovaps [rsp+0xC0], xmm12
000078d941fd0c00  vmovaps [rsp+0xD0], xmm14
000078d941fd0c09  vmovaps [rsp+0xE0], xmm15
000078d941fd0c12  sub rsp, 0x30
000078d941fd0c16  movaps [rsp], xmm13
000078d941fd0c1b  movaps [rsp+0x10], xmm14
000078d941fd0c21  movaps [rsp+0x20], xmm2
000078d941fd0c26  lea rdi, [rsp]
000078d941fd0c2a  mov esi, 0x00
000078d941fd0c2f  mov rax, 0x59BFBFBAA530
000078d941fd0c39  call rax
000078d941fd0c3b  movaps xmm13, [rsp]
000078d941fd0c40  add rsp, 0x30
000078d941fd0c44  vmovaps xmm0, [rsp]
000078d941fd0c49  vmovaps xmm1, [rsp+0x10]
000078d941fd0c4f  vmovaps xmm2, [rsp+0x20]
000078d941fd0c55  vmovaps xmm3, [rsp+0x30]
000078d941fd0c5b  vmovaps xmm4, [rsp+0x40]
000078d941fd0c61  vmovaps xmm5, [rsp+0x50]
000078d941fd0c67  vmovaps xmm6, [rsp+0x60]
000078d941fd0c6d  vmovaps xmm7, [rsp+0x70]
000078d941fd0c73  vmovaps xmm8, [rsp+0x80]
000078d941fd0c7c  vmovaps xmm9, [rsp+0x90]
000078d941fd0c85  vmovaps xmm10, [rsp+0xA0]
000078d941fd0c8e  vmovaps xmm11, [rsp+0xB0]
000078d941fd0c97  vmovaps xmm12, [rsp+0xC0]
000078d941fd0ca0  vmovaps xmm14, [rsp+0xD0]
000078d941fd0ca9  vmovaps xmm15, [rsp+0xE0]
000078d941fd0cb2  add rsp, 0xF0
000078d941fd0cb9  pop r11
000078d941fd0cbb  pop r10
000078d941fd0cbd  pop r9
000078d941fd0cbf  pop r8
000078d941fd0cc1  pop rsi
000078d941fd0cc2  pop rdi
000078d941fd0cc3  pop rdx
000078d941fd0cc4  pop rcx
000078d941fd0cc5  pop rax
000078d941fd0cc6  add rsp, 0x08
000078d941fd0cca  jmp 0x000078D941FCF64C
000078d941fd0ccf  sub rsp, 0x08
000078d941fd0cd3  push rax
000078d941fd0cd4  push rcx
000078d941fd0cd5  push rdx
000078d941fd0cd6  push rdi
000078d941fd0cd7  push rsi
000078d941fd0cd8  push r8
000078d941fd0cda  push r9
000078d941fd0cdc  push r10
000078d941fd0cde  push r11
000078d941fd0ce0  sub rsp, 0xF0
000078d941fd0ce7  vmovaps [rsp], xmm0
000078d941fd0cec  vmovaps [rsp+0x10], xmm2
000078d941fd0cf2  vmovaps [rsp+0x20], xmm3
000078d941fd0cf8  vmovaps [rsp+0x30], xmm4
000078d941fd0cfe  vmovaps [rsp+0x40], xmm5
000078d941fd0d04  vmovaps [rsp+0x50], xmm6
000078d941fd0d0a  vmovaps [rsp+0x60], xmm7
000078d941fd0d10  vmovaps [rsp+0x70], xmm8
000078d941fd0d16  vmovaps [rsp+0x80], xmm9
000078d941fd0d1f  vmovaps [rsp+0x90], xmm10
000078d941fd0d28  vmovaps [rsp+0xA0], xmm11
000078d941fd0d31  vmovaps [rsp+0xB0], xmm12
000078d941fd0d3a  vmovaps [rsp+0xC0], xmm13
000078d941fd0d43  vmovaps [rsp+0xD0], xmm14
000078d941fd0d4c  vmovaps [rsp+0xE0], xmm15
000078d941fd0d55  sub rsp, 0x30
000078d941fd0d59  movaps [rsp], xmm1
000078d941fd0d5d  movaps [rsp+0x10], xmm10
000078d941fd0d63  movaps [rsp+0x20], xmm2
000078d941fd0d68  lea rdi, [rsp]
000078d941fd0d6c  mov esi, 0x00
000078d941fd0d71  mov rax, 0x59BFBFBAA530
000078d941fd0d7b  call rax
000078d941fd0d7d  movaps xmm1, [rsp]
000078d941fd0d81  add rsp, 0x30
000078d941fd0d85  vmovaps xmm0, [rsp]
000078d941fd0d8a  vmovaps xmm2, [rsp+0x10]
000078d941fd0d90  vmovaps xmm3, [rsp+0x20]
000078d941fd0d96  vmovaps xmm4, [rsp+0x30]
000078d941fd0d9c  vmovaps xmm5, [rsp+0x40]
000078d941fd0da2  vmovaps xmm6, [rsp+0x50]
000078d941fd0da8  vmovaps xmm7, [rsp+0x60]
000078d941fd0dae  vmovaps xmm8, [rsp+0x70]
000078d941fd0db4  vmovaps xmm9, [rsp+0x80]
000078d941fd0dbd  vmovaps xmm10, [rsp+0x90]
000078d941fd0dc6  vmovaps xmm11, [rsp+0xA0]
000078d941fd0dcf  vmovaps xmm12, [rsp+0xB0]
000078d941fd0dd8  vmovaps xmm13, [rsp+0xC0]
000078d941fd0de1  vmovaps xmm14, [rsp+0xD0]
000078d941fd0dea  vmovaps xmm15, [rsp+0xE0]
000078d941fd0df3  add rsp, 0xF0
000078d941fd0dfa  pop r11
000078d941fd0dfc  pop r10
000078d941fd0dfe  pop r9
000078d941fd0e00  pop r8
000078d941fd0e02  pop rsi
000078d941fd0e03  pop rdi
000078d941fd0e04  pop rdx
000078d941fd0e05  pop rcx
000078d941fd0e06  pop rax
000078d941fd0e07  add rsp, 0x08
000078d941fd0e0b  jmp 0x000078D941FCF6B4
000078d941fd0e10  sub rsp, 0x08
000078d941fd0e14  push rax
000078d941fd0e15  push rcx
000078d941fd0e16  push rdx
000078d941fd0e17  push rdi
000078d941fd0e18  push rsi
000078d941fd0e19  push r8
000078d941fd0e1b  push r9
000078d941fd0e1d  push r10
000078d941fd0e1f  push r11
000078d941fd0e21  sub rsp, 0xF0
000078d941fd0e28  vmovaps [rsp], xmm0
000078d941fd0e2d  vmovaps [rsp+0x10], xmm1
000078d941fd0e33  vmovaps [rsp+0x20], xmm2
000078d941fd0e39  vmovaps [rsp+0x30], xmm3
000078d941fd0e3f  vmovaps [rsp+0x40], xmm4
000078d941fd0e45  vmovaps [rsp+0x50], xmm5
000078d941fd0e4b  vmovaps [rsp+0x60], xmm6
000078d941fd0e51  vmovaps [rsp+0x70], xmm7
000078d941fd0e57  vmovaps [rsp+0x80], xmm8
000078d941fd0e60  vmovaps [rsp+0x90], xmm9
000078d941fd0e69  vmovaps [rsp+0xA0], xmm10
000078d941fd0e72  vmovaps [rsp+0xB0], xmm11
000078d941fd0e7b  vmovaps [rsp+0xC0], xmm12
000078d941fd0e84  vmovaps [rsp+0xD0], xmm13
000078d941fd0e8d  vmovaps [rsp+0xE0], xmm14
000078d941fd0e96  sub rsp, 0x30
000078d941fd0e9a  movaps [rsp], xmm15
000078d941fd0e9f  movaps [rsp+0x10], xmm10
000078d941fd0ea5  movaps [rsp+0x20], xmm2
000078d941fd0eaa  lea rdi, [rsp]
000078d941fd0eae  mov esi, 0x00
000078d941fd0eb3  mov rax, 0x59BFBFBAA530
000078d941fd0ebd  call rax
000078d941fd0ebf  movaps xmm15, [rsp]
000078d941fd0ec4  add rsp, 0x30
000078d941fd0ec8  vmovaps xmm0, [rsp]
000078d941fd0ecd  vmovaps xmm1, [rsp+0x10]
000078d941fd0ed3  vmovaps xmm2, [rsp+0x20]
000078d941fd0ed9  vmovaps xmm3, [rsp+0x30]
000078d941fd0edf  vmovaps xmm4, [rsp+0x40]
000078d941fd0ee5  vmovaps xmm5, [rsp+0x50]
000078d941fd0eeb  vmovaps xmm6, [rsp+0x60]
000078d941fd0ef1  vmovaps xmm7, [rsp+0x70]
000078d941fd0ef7  vmovaps xmm8, [rsp+0x80]
000078d941fd0f00  vmovaps xmm9, [rsp+0x90]
000078d941fd0f09  vmovaps xmm10, [rsp+0xA0]
000078d941fd0f12  vmovaps xmm11, [rsp+0xB0]
000078d941fd0f1b  vmovaps xmm12, [rsp+0xC0]
000078d941fd0f24  vmovaps xmm13, [rsp+0xD0]
000078d941fd0f2d  vmovaps xmm14, [rsp+0xE0]
000078d941fd0f36  add rsp, 0xF0
000078d941fd0f3d  pop r11
000078d941fd0f3f  pop r10
000078d941fd0f41  pop r9
000078d941fd0f43  pop r8
000078d941fd0f45  pop rsi
000078d941fd0f46  pop rdi
000078d941fd0f47  pop rdx
000078d941fd0f48  pop rcx
000078d941fd0f49  pop rax
000078d941fd0f4a  add rsp, 0x08
000078d941fd0f4e  jmp 0x000078D941FCF706
000078d941fd0f53  sub rsp, 0x08
000078d941fd0f57  push rax
000078d941fd0f58  push rcx
000078d941fd0f59  push rdx
000078d941fd0f5a  push rdi
000078d941fd0f5b  push rsi
000078d941fd0f5c  push r8
000078d941fd0f5e  push r9
000078d941fd0f60  push r10
000078d941fd0f62  push r11
000078d941fd0f64  sub rsp, 0xF0
000078d941fd0f6b  vmovaps [rsp], xmm0
000078d941fd0f70  vmovaps [rsp+0x10], xmm2
000078d941fd0f76  vmovaps [rsp+0x20], xmm3
000078d941fd0f7c  vmovaps [rsp+0x30], xmm4
000078d941fd0f82  vmovaps [rsp+0x40], xmm5
000078d941fd0f88  vmovaps [rsp+0x50], xmm6
000078d941fd0f8e  vmovaps [rsp+0x60], xmm7
000078d941fd0f94  vmovaps [rsp+0x70], xmm8
000078d941fd0f9a  vmovaps [rsp+0x80], xmm9
000078d941fd0fa3  vmovaps [rsp+0x90], xmm10
000078d941fd0fac  vmovaps [rsp+0xA0], xmm11
000078d941fd0fb5  vmovaps [rsp+0xB0], xmm12
000078d941fd0fbe  vmovaps [rsp+0xC0], xmm13
000078d941fd0fc7  vmovaps [rsp+0xD0], xmm14
000078d941fd0fd0  vmovaps [rsp+0xE0], xmm15
000078d941fd0fd9  sub rsp, 0x30
000078d941fd0fdd  movaps [rsp], xmm1
000078d941fd0fe1  movaps [rsp+0x10], xmm10
000078d941fd0fe7  movaps [rsp+0x20], xmm12
000078d941fd0fed  lea rdi, [rsp]
000078d941fd0ff1  mov esi, 0x00
000078d941fd0ff6  mov rax, 0x59BFBFBAA530
000078d941fd1000  call rax
000078d941fd1002  movaps xmm1, [rsp]
000078d941fd1006  add rsp, 0x30
000078d941fd100a  vmovaps xmm0, [rsp]
000078d941fd100f  vmovaps xmm2, [rsp+0x10]
000078d941fd1015  vmovaps xmm3, [rsp+0x20]
000078d941fd101b  vmovaps xmm4, [rsp+0x30]
000078d941fd1021  vmovaps xmm5, [rsp+0x40]
000078d941fd1027  vmovaps xmm6, [rsp+0x50]
000078d941fd102d  vmovaps xmm7, [rsp+0x60]
000078d941fd1033  vmovaps xmm8, [rsp+0x70]
000078d941fd1039  vmovaps xmm9, [rsp+0x80]
000078d941fd1042  vmovaps xmm10, [rsp+0x90]
000078d941fd104b  vmovaps xmm11, [rsp+0xA0]
000078d941fd1054  vmovaps xmm12, [rsp+0xB0]
000078d941fd105d  vmovaps xmm13, [rsp+0xC0]
000078d941fd1066  vmovaps xmm14, [rsp+0xD0]
000078d941fd106f  vmovaps xmm15, [rsp+0xE0]
000078d941fd1078  add rsp, 0xF0
000078d941fd107f  pop r11
000078d941fd1081  pop r10
000078d941fd1083  pop r9
000078d941fd1085  pop r8
000078d941fd1087  pop rsi
000078d941fd1088  pop rdi
000078d941fd1089  pop rdx
000078d941fd108a  pop rcx
000078d941fd108b  pop rax
000078d941fd108c  add rsp, 0x08
000078d941fd1090  jmp 0x000078D941FCF732
000078d941fd1095  sub rsp, 0x08
000078d941fd1099  push rax
000078d941fd109a  push rcx
000078d941fd109b  push rdx
000078d941fd109c  push rdi
000078d941fd109d  push rsi
000078d941fd109e  push r8
000078d941fd10a0  push r9
000078d941fd10a2  push r10
000078d941fd10a4  push r11
000078d941fd10a6  sub rsp, 0xF0
000078d941fd10ad  vmovaps [rsp], xmm0
000078d941fd10b2  vmovaps [rsp+0x10], xmm1
000078d941fd10b8  vmovaps [rsp+0x20], xmm2
000078d941fd10be  vmovaps [rsp+0x30], xmm3
000078d941fd10c4  vmovaps [rsp+0x40], xmm4
000078d941fd10ca  vmovaps [rsp+0x50], xmm5
000078d941fd10d0  vmovaps [rsp+0x60], xmm6
000078d941fd10d6  vmovaps [rsp+0x70], xmm7
000078d941fd10dc  vmovaps [rsp+0x80], xmm8
000078d941fd10e5  vmovaps [rsp+0x90], xmm9
000078d941fd10ee  vmovaps [rsp+0xA0], xmm10
000078d941fd10f7  vmovaps [rsp+0xB0], xmm11
000078d941fd1100  vmovaps [rsp+0xC0], xmm12
000078d941fd1109  vmovaps [rsp+0xD0], xmm13
000078d941fd1112  vmovaps [rsp+0xE0], xmm14
000078d941fd111b  sub rsp, 0x30
000078d941fd111f  movaps [rsp], xmm15
000078d941fd1124  movaps [rsp+0x10], xmm10
000078d941fd112a  movaps [rsp+0x20], xmm12
000078d941fd1130  lea rdi, [rsp]
000078d941fd1134  mov esi, 0x00
000078d941fd1139  mov rax, 0x59BFBFBAA530
000078d941fd1143  call rax
000078d941fd1145  movaps xmm15, [rsp]
000078d941fd114a  add rsp, 0x30
000078d941fd114e  vmovaps xmm0, [rsp]
000078d941fd1153  vmovaps xmm1, [rsp+0x10]
000078d941fd1159  vmovaps xmm2, [rsp+0x20]
000078d941fd115f  vmovaps xmm3, [rsp+0x30]
000078d941fd1165  vmovaps xmm4, [rsp+0x40]
000078d941fd116b  vmovaps xmm5, [rsp+0x50]
000078d941fd1171  vmovaps xmm6, [rsp+0x60]
000078d941fd1177  vmovaps xmm7, [rsp+0x70]
000078d941fd117d  vmovaps xmm8, [rsp+0x80]
000078d941fd1186  vmovaps xmm9, [rsp+0x90]
000078d941fd118f  vmovaps xmm10, [rsp+0xA0]
000078d941fd1198  vmovaps xmm11, [rsp+0xB0]
000078d941fd11a1  vmovaps xmm12, [rsp+0xC0]
000078d941fd11aa  vmovaps xmm13, [rsp+0xD0]
000078d941fd11b3  vmovaps xmm14, [rsp+0xE0]
000078d941fd11bc  add rsp, 0xF0
000078d941fd11c3  pop r11
000078d941fd11c5  pop r10
000078d941fd11c7  pop r9
000078d941fd11c9  pop r8
000078d941fd11cb  pop rsi
000078d941fd11cc  pop rdi
000078d941fd11cd  pop rdx
000078d941fd11ce  pop rcx
000078d941fd11cf  pop rax
000078d941fd11d0  add rsp, 0x08
000078d941fd11d4  jmp 0x000078D941FCF75E
000078d941fd11d9  call 0x000078D941DFF430
000078d941fd11de  jmp 0x000078D941FCF7EE
000078d941fd11e3  call 0x000078D941DFF430
000078d941fd11e8  jmp 0x000078D941FCF801
000078d941fd11ed  sub rsp, 0x08
000078d941fd11f1  push rax
000078d941fd11f2  push rcx
000078d941fd11f3  push rdx
000078d941fd11f4  push rdi
000078d941fd11f5  push rsi
000078d941fd11f6  push r8
000078d941fd11f8  push r9
000078d941fd11fa  push r10
000078d941fd11fc  push r11
000078d941fd11fe  sub rsp, 0xF0
000078d941fd1205  vmovaps [rsp], xmm0
000078d941fd120a  vmovaps [rsp+0x10], xmm2
000078d941fd1210  vmovaps [rsp+0x20], xmm3
000078d941fd1216  vmovaps [rsp+0x30], xmm4
000078d941fd121c  vmovaps [rsp+0x40], xmm5
000078d941fd1222  vmovaps [rsp+0x50], xmm6
000078d941fd1228  vmovaps [rsp+0x60], xmm7
000078d941fd122e  vmovaps [rsp+0x70], xmm8
000078d941fd1234  vmovaps [rsp+0x80], xmm9
000078d941fd123d  vmovaps [rsp+0x90], xmm10
000078d941fd1246  vmovaps [rsp+0xA0], xmm11
000078d941fd124f  vmovaps [rsp+0xB0], xmm12
000078d941fd1258  vmovaps [rsp+0xC0], xmm13
000078d941fd1261  vmovaps [rsp+0xD0], xmm14
000078d941fd126a  vmovaps [rsp+0xE0], xmm15
000078d941fd1273  sub rsp, 0x30
000078d941fd1277  movaps [rsp], xmm1
000078d941fd127b  movaps [rsp+0x10], xmm13
000078d941fd1281  movaps [rsp+0x20], xmm2
000078d941fd1286  lea rdi, [rsp]
000078d941fd128a  mov esi, 0x00
000078d941fd128f  mov rax, 0x59BFBFBAA530
000078d941fd1299  call rax
000078d941fd129b  movaps xmm1, [rsp]
000078d941fd129f  add rsp, 0x30
000078d941fd12a3  vmovaps xmm0, [rsp]
000078d941fd12a8  vmovaps xmm2, [rsp+0x10]
000078d941fd12ae  vmovaps xmm3, [rsp+0x20]
000078d941fd12b4  vmovaps xmm4, [rsp+0x30]
000078d941fd12ba  vmovaps xmm5, [rsp+0x40]
000078d941fd12c0  vmovaps xmm6, [rsp+0x50]
000078d941fd12c6  vmovaps xmm7, [rsp+0x60]
000078d941fd12cc  vmovaps xmm8, [rsp+0x70]
000078d941fd12d2  vmovaps xmm9, [rsp+0x80]
000078d941fd12db  vmovaps xmm10, [rsp+0x90]
000078d941fd12e4  vmovaps xmm11, [rsp+0xA0]
000078d941fd12ed  vmovaps xmm12, [rsp+0xB0]
000078d941fd12f6  vmovaps xmm13, [rsp+0xC0]
000078d941fd12ff  vmovaps xmm14, [rsp+0xD0]
000078d941fd1308  vmovaps xmm15, [rsp+0xE0]
000078d941fd1311  add rsp, 0xF0
000078d941fd1318  pop r11
000078d941fd131a  pop r10
000078d941fd131c  pop r9
000078d941fd131e  pop r8
000078d941fd1320  pop rsi
000078d941fd1321  pop rdi
000078d941fd1322  pop rdx
000078d941fd1323  pop rcx
000078d941fd1324  pop rax
000078d941fd1325  add rsp, 0x08
000078d941fd1329  jmp 0x000078D941FCF82C
000078d941fd132e  call 0x000078D941E0E760
000078d941fd1333  jmp 0x000078D941FCF839
000078d941fd1338  sub rsp, 0x08
000078d941fd133c  push rax
000078d941fd133d  push rcx
000078d941fd133e  push rdx
000078d941fd133f  push rdi
000078d941fd1340  push rsi
000078d941fd1341  push r8
000078d941fd1343  push r9
000078d941fd1345  push r10
000078d941fd1347  push r11
000078d941fd1349  sub rsp, 0xF0
000078d941fd1350  vmovaps [rsp], xmm0
000078d941fd1355  vmovaps [rsp+0x10], xmm1
000078d941fd135b  vmovaps [rsp+0x20], xmm2
000078d941fd1361  vmovaps [rsp+0x30], xmm3
000078d941fd1367  vmovaps [rsp+0x40], xmm4
000078d941fd136d  vmovaps [rsp+0x50], xmm5
000078d941fd1373  vmovaps [rsp+0x60], xmm6
000078d941fd1379  vmovaps [rsp+0x70], xmm7
000078d941fd137f  vmovaps [rsp+0x80], xmm8
000078d941fd1388  vmovaps [rsp+0x90], xmm9
000078d941fd1391  vmovaps [rsp+0xA0], xmm10
000078d941fd139a  vmovaps [rsp+0xB0], xmm11
000078d941fd13a3  vmovaps [rsp+0xC0], xmm12
000078d941fd13ac  vmovaps [rsp+0xD0], xmm14
000078d941fd13b5  vmovaps [rsp+0xE0], xmm15
000078d941fd13be  sub rsp, 0x30
000078d941fd13c2  movaps [rsp], xmm13
000078d941fd13c7  movaps [rsp+0x10], xmm2
000078d941fd13cc  movaps [rsp+0x20], xmm1
000078d941fd13d1  lea rdi, [rsp]
000078d941fd13d5  mov esi, 0x00
000078d941fd13da  mov rax, 0x59BFBFBAA530
000078d941fd13e4  call rax
000078d941fd13e6  movaps xmm13, [rsp]
000078d941fd13eb  add rsp, 0x30
000078d941fd13ef  vmovaps xmm0, [rsp]
000078d941fd13f4  vmovaps xmm1, [rsp+0x10]
000078d941fd13fa  vmovaps xmm2, [rsp+0x20]
000078d941fd1400  vmovaps xmm3, [rsp+0x30]
000078d941fd1406  vmovaps xmm4, [rsp+0x40]
000078d941fd140c  vmovaps xmm5, [rsp+0x50]
000078d941fd1412  vmovaps xmm6, [rsp+0x60]
000078d941fd1418  vmovaps xmm7, [rsp+0x70]
000078d941fd141e  vmovaps xmm8, [rsp+0x80]
000078d941fd1427  vmovaps xmm9, [rsp+0x90]
000078d941fd1430  vmovaps xmm10, [rsp+0xA0]
000078d941fd1439  vmovaps xmm11, [rsp+0xB0]
000078d941fd1442  vmovaps xmm12, [rsp+0xC0]
000078d941fd144b  vmovaps xmm14, [rsp+0xD0]
000078d941fd1454  vmovaps xmm15, [rsp+0xE0]
000078d941fd145d  add rsp, 0xF0
000078d941fd1464  pop r11
000078d941fd1466  pop r10
000078d941fd1468  pop r9
000078d941fd146a  pop r8
000078d941fd146c  pop rsi
000078d941fd146d  pop rdi
000078d941fd146e  pop rdx
000078d941fd146f  pop rcx
000078d941fd1470  pop rax
000078d941fd1471  add rsp, 0x08
000078d941fd1475  jmp 0x000078D941FCF878
000078d941fd147a  sub rsp, 0x08
000078d941fd147e  push rax
000078d941fd147f  push rcx
000078d941fd1480  push rdx
000078d941fd1481  push rdi
000078d941fd1482  push rsi
000078d941fd1483  push r8
000078d941fd1485  push r9
000078d941fd1487  push r10
000078d941fd1489  push r11
000078d941fd148b  sub rsp, 0xF0
000078d941fd1492  vmovaps [rsp], xmm0
000078d941fd1497  vmovaps [rsp+0x10], xmm2
000078d941fd149d  vmovaps [rsp+0x20], xmm3
000078d941fd14a3  vmovaps [rsp+0x30], xmm4
000078d941fd14a9  vmovaps [rsp+0x40], xmm5
000078d941fd14af  vmovaps [rsp+0x50], xmm6
000078d941fd14b5  vmovaps [rsp+0x60], xmm7
000078d941fd14bb  vmovaps [rsp+0x70], xmm8
000078d941fd14c1  vmovaps [rsp+0x80], xmm9
000078d941fd14ca  vmovaps [rsp+0x90], xmm10
000078d941fd14d3  vmovaps [rsp+0xA0], xmm11
000078d941fd14dc  vmovaps [rsp+0xB0], xmm12
000078d941fd14e5  vmovaps [rsp+0xC0], xmm13
000078d941fd14ee  vmovaps [rsp+0xD0], xmm14
000078d941fd14f7  vmovaps [rsp+0xE0], xmm15
000078d941fd1500  sub rsp, 0x30
000078d941fd1504  movaps [rsp], xmm1
000078d941fd1508  movaps [rsp+0x10], xmm15
000078d941fd150e  movaps [rsp+0x20], xmm2
000078d941fd1513  lea rdi, [rsp]
000078d941fd1517  mov esi, 0x00
000078d941fd151c  mov rax, 0x59BFBFBAA530
000078d941fd1526  call rax
000078d941fd1528  movaps xmm1, [rsp]
000078d941fd152c  add rsp, 0x30
000078d941fd1530  vmovaps xmm0, [rsp]
000078d941fd1535  vmovaps xmm2, [rsp+0x10]
000078d941fd153b  vmovaps xmm3, [rsp+0x20]
000078d941fd1541  vmovaps xmm4, [rsp+0x30]
000078d941fd1547  vmovaps xmm5, [rsp+0x40]
000078d941fd154d  vmovaps xmm6, [rsp+0x50]
000078d941fd1553  vmovaps xmm7, [rsp+0x60]
000078d941fd1559  vmovaps xmm8, [rsp+0x70]
000078d941fd155f  vmovaps xmm9, [rsp+0x80]
000078d941fd1568  vmovaps xmm10, [rsp+0x90]
000078d941fd1571  vmovaps xmm11, [rsp+0xA0]
000078d941fd157a  vmovaps xmm12, [rsp+0xB0]
000078d941fd1583  vmovaps xmm13, [rsp+0xC0]
000078d941fd158c  vmovaps xmm14, [rsp+0xD0]
000078d941fd1595  vmovaps xmm15, [rsp+0xE0]
000078d941fd159e  add rsp, 0xF0
000078d941fd15a5  pop r11
000078d941fd15a7  pop r10
000078d941fd15a9  pop r9
000078d941fd15ab  pop r8
000078d941fd15ad  pop rsi
000078d941fd15ae  pop rdi
000078d941fd15af  pop rdx
000078d941fd15b0  pop rcx
000078d941fd15b1  pop rax
000078d941fd15b2  add rsp, 0x08
000078d941fd15b6  jmp 0x000078D941FCF8AC
000078d941fd15bb  sub rsp, 0x08
000078d941fd15bf  push rax
000078d941fd15c0  push rcx
000078d941fd15c1  push rdx
000078d941fd15c2  push rdi
000078d941fd15c3  push rsi
000078d941fd15c4  push r8
000078d941fd15c6  push r9
000078d941fd15c8  push r10
000078d941fd15ca  push r11
000078d941fd15cc  sub rsp, 0xF0
000078d941fd15d3  vmovaps [rsp], xmm0
000078d941fd15d8  vmovaps [rsp+0x10], xmm1
000078d941fd15de  vmovaps [rsp+0x20], xmm2
000078d941fd15e4  vmovaps [rsp+0x30], xmm3
000078d941fd15ea  vmovaps [rsp+0x40], xmm4
000078d941fd15f0  vmovaps [rsp+0x50], xmm5
000078d941fd15f6  vmovaps [rsp+0x60], xmm6
000078d941fd15fc  vmovaps [rsp+0x70], xmm7
000078d941fd1602  vmovaps [rsp+0x80], xmm8
000078d941fd160b  vmovaps [rsp+0x90], xmm9
000078d941fd1614  vmovaps [rsp+0xA0], xmm10
000078d941fd161d  vmovaps [rsp+0xB0], xmm11
000078d941fd1626  vmovaps [rsp+0xC0], xmm12
000078d941fd162f  vmovaps [rsp+0xD0], xmm13
000078d941fd1638  vmovaps [rsp+0xE0], xmm15
000078d941fd1641  sub rsp, 0x30
000078d941fd1645  movaps [rsp], xmm14
000078d941fd164a  movaps [rsp+0x10], xmm2
000078d941fd164f  movaps [rsp+0x20], xmm15
000078d941fd1655  lea rdi, [rsp]
000078d941fd1659  mov esi, 0x00
000078d941fd165e  mov rax, 0x59BFBFBAA530
000078d941fd1668  call rax
000078d941fd166a  movaps xmm14, [rsp]
000078d941fd166f  add rsp, 0x30
000078d941fd1673  vmovaps xmm0, [rsp]
000078d941fd1678  vmovaps xmm1, [rsp+0x10]
000078d941fd167e  vmovaps xmm2, [rsp+0x20]
000078d941fd1684  vmovaps xmm3, [rsp+0x30]
000078d941fd168a  vmovaps xmm4, [rsp+0x40]
000078d941fd1690  vmovaps xmm5, [rsp+0x50]
000078d941fd1696  vmovaps xmm6, [rsp+0x60]
000078d941fd169c  vmovaps xmm7, [rsp+0x70]
000078d941fd16a2  vmovaps xmm8, [rsp+0x80]
000078d941fd16ab  vmovaps xmm9, [rsp+0x90]
000078d941fd16b4  vmovaps xmm10, [rsp+0xA0]
000078d941fd16bd  vmovaps xmm11, [rsp+0xB0]
000078d941fd16c6  vmovaps xmm12, [rsp+0xC0]
000078d941fd16cf  vmovaps xmm13, [rsp+0xD0]
000078d941fd16d8  vmovaps xmm15, [rsp+0xE0]
000078d941fd16e1  add rsp, 0xF0
000078d941fd16e8  pop r11
000078d941fd16ea  pop r10
000078d941fd16ec  pop r9
000078d941fd16ee  pop r8
000078d941fd16f0  pop rsi
000078d941fd16f1  pop rdi
000078d941fd16f2  pop rdx
000078d941fd16f3  pop rcx
000078d941fd16f4  pop rax
000078d941fd16f5  add rsp, 0x08
000078d941fd16f9  jmp 0x000078D941FCF8E7
000078d941fd16fe  sub rsp, 0x08
000078d941fd1702  push rax
000078d941fd1703  push rcx
000078d941fd1704  push rdx
000078d941fd1705  push rdi
000078d941fd1706  push rsi
000078d941fd1707  push r8
000078d941fd1709  push r9
000078d941fd170b  push r10
000078d941fd170d  push r11
000078d941fd170f  sub rsp, 0xF0
000078d941fd1716  vmovaps [rsp], xmm0
000078d941fd171b  vmovaps [rsp+0x10], xmm1
000078d941fd1721  vmovaps [rsp+0x20], xmm2
000078d941fd1727  vmovaps [rsp+0x30], xmm3
000078d941fd172d  vmovaps [rsp+0x40], xmm4
000078d941fd1733  vmovaps [rsp+0x50], xmm5
000078d941fd1739  vmovaps [rsp+0x60], xmm6
000078d941fd173f  vmovaps [rsp+0x70], xmm7
000078d941fd1745  vmovaps [rsp+0x80], xmm8
000078d941fd174e  vmovaps [rsp+0x90], xmm9
000078d941fd1757  vmovaps [rsp+0xA0], xmm10
000078d941fd1760  vmovaps [rsp+0xB0], xmm11
000078d941fd1769  vmovaps [rsp+0xC0], xmm12
000078d941fd1772  vmovaps [rsp+0xD0], xmm13
000078d941fd177b  vmovaps [rsp+0xE0], xmm14
000078d941fd1784  sub rsp, 0x30
000078d941fd1788  movaps [rsp], xmm15
000078d941fd178d  movaps [rsp+0x10], xmm2
000078d941fd1792  movaps [rsp+0x20], xmm1
000078d941fd1797  lea rdi, [rsp]
000078d941fd179b  mov esi, 0x00
000078d941fd17a0  mov rax, 0x59BFBFBAA530
000078d941fd17aa  call rax
000078d941fd17ac  movaps xmm15, [rsp]
000078d941fd17b1  add rsp, 0x30
000078d941fd17b5  vmovaps xmm0, [rsp]
000078d941fd17ba  vmovaps xmm1, [rsp+0x10]
000078d941fd17c0  vmovaps xmm2, [rsp+0x20]
000078d941fd17c6  vmovaps xmm3, [rsp+0x30]
000078d941fd17cc  vmovaps xmm4, [rsp+0x40]
000078d941fd17d2  vmovaps xmm5, [rsp+0x50]
000078d941fd17d8  vmovaps xmm6, [rsp+0x60]
000078d941fd17de  vmovaps xmm7, [rsp+0x70]
000078d941fd17e4  vmovaps xmm8, [rsp+0x80]
000078d941fd17ed  vmovaps xmm9, [rsp+0x90]
000078d941fd17f6  vmovaps xmm10, [rsp+0xA0]
000078d941fd17ff  vmovaps xmm11, [rsp+0xB0]
000078d941fd1808  vmovaps xmm12, [rsp+0xC0]
000078d941fd1811  vmovaps xmm13, [rsp+0xD0]
000078d941fd181a  vmovaps xmm14, [rsp+0xE0]
000078d941fd1823  add rsp, 0xF0
000078d941fd182a  pop r11
000078d941fd182c  pop r10
000078d941fd182e  pop r9
000078d941fd1830  pop r8
000078d941fd1832  pop rsi
000078d941fd1833  pop rdi
000078d941fd1834  pop rdx
000078d941fd1835  pop rcx
000078d941fd1836  pop rax
000078d941fd1837  add rsp, 0x08
000078d941fd183b  jmp 0x000078D941FCF923
000078d941fd1840  call 0x000078D941DFF430
000078d941fd1845  jmp 0x000078D941FCF930
000078d941fd184a  sub rsp, 0x08
000078d941fd184e  push rax
000078d941fd184f  push rcx
000078d941fd1850  push rdx
000078d941fd1851  push rdi
000078d941fd1852  push rsi
000078d941fd1853  push r8
000078d941fd1855  push r9
000078d941fd1857  push r10
000078d941fd1859  push r11
000078d941fd185b  sub rsp, 0xF0
000078d941fd1862  vmovaps [rsp], xmm0
000078d941fd1867  vmovaps [rsp+0x10], xmm1
000078d941fd186d  vmovaps [rsp+0x20], xmm3
000078d941fd1873  vmovaps [rsp+0x30], xmm4
000078d941fd1879  vmovaps [rsp+0x40], xmm5
000078d941fd187f  vmovaps [rsp+0x50], xmm6
000078d941fd1885  vmovaps [rsp+0x60], xmm7
000078d941fd188b  vmovaps [rsp+0x70], xmm8
000078d941fd1891  vmovaps [rsp+0x80], xmm9
000078d941fd189a  vmovaps [rsp+0x90], xmm10
000078d941fd18a3  vmovaps [rsp+0xA0], xmm11
000078d941fd18ac  vmovaps [rsp+0xB0], xmm12
000078d941fd18b5  vmovaps [rsp+0xC0], xmm13
000078d941fd18be  vmovaps [rsp+0xD0], xmm14
000078d941fd18c7  vmovaps [rsp+0xE0], xmm15
000078d941fd18d0  sub rsp, 0x30
000078d941fd18d4  movaps [rsp], xmm2
000078d941fd18d8  movaps [rsp+0x10], xmm1
000078d941fd18dd  movaps [rsp+0x20], xmm14
000078d941fd18e3  lea rdi, [rsp]
000078d941fd18e7  mov esi, 0x00
000078d941fd18ec  mov rax, 0x59BFBFBAA530
000078d941fd18f6  call rax
000078d941fd18f8  movaps xmm2, [rsp]
000078d941fd18fc  add rsp, 0x30
000078d941fd1900  vmovaps xmm0, [rsp]
000078d941fd1905  vmovaps xmm1, [rsp+0x10]
000078d941fd190b  vmovaps xmm3, [rsp+0x20]
000078d941fd1911  vmovaps xmm4, [rsp+0x30]
000078d941fd1917  vmovaps xmm5, [rsp+0x40]
000078d941fd191d  vmovaps xmm6, [rsp+0x50]
000078d941fd1923  vmovaps xmm7, [rsp+0x60]
000078d941fd1929  vmovaps xmm8, [rsp+0x70]
000078d941fd192f  vmovaps xmm9, [rsp+0x80]
000078d941fd1938  vmovaps xmm10, [rsp+0x90]
000078d941fd1941  vmovaps xmm11, [rsp+0xA0]
000078d941fd194a  vmovaps xmm12, [rsp+0xB0]
000078d941fd1953  vmovaps xmm13, [rsp+0xC0]
000078d941fd195c  vmovaps xmm14, [rsp+0xD0]
000078d941fd1965  vmovaps xmm15, [rsp+0xE0]
000078d941fd196e  add rsp, 0xF0
000078d941fd1975  pop r11
000078d941fd1977  pop r10
000078d941fd1979  pop r9
000078d941fd197b  pop r8
000078d941fd197d  pop rsi
000078d941fd197e  pop rdi
000078d941fd197f  pop rdx
000078d941fd1980  pop rcx
000078d941fd1981  pop rax
000078d941fd1982  add rsp, 0x08
000078d941fd1986  jmp 0x000078D941FCF96D
000078d941fd198b  sub rsp, 0x08
000078d941fd198f  push rax
000078d941fd1990  push rcx
000078d941fd1991  push rdx
000078d941fd1992  push rdi
000078d941fd1993  push rsi
000078d941fd1994  push r8
000078d941fd1996  push r9
000078d941fd1998  push r10
000078d941fd199a  push r11
000078d941fd199c  sub rsp, 0xF0
000078d941fd19a3  vmovaps [rsp], xmm0
000078d941fd19a8  vmovaps [rsp+0x10], xmm1
000078d941fd19ae  vmovaps [rsp+0x20], xmm2
000078d941fd19b4  vmovaps [rsp+0x30], xmm3
000078d941fd19ba  vmovaps [rsp+0x40], xmm4
000078d941fd19c0  vmovaps [rsp+0x50], xmm5
000078d941fd19c6  vmovaps [rsp+0x60], xmm6
000078d941fd19cc  vmovaps [rsp+0x70], xmm7
000078d941fd19d2  vmovaps [rsp+0x80], xmm8
000078d941fd19db  vmovaps [rsp+0x90], xmm9
000078d941fd19e4  vmovaps [rsp+0xA0], xmm10
000078d941fd19ed  vmovaps [rsp+0xB0], xmm11
000078d941fd19f6  vmovaps [rsp+0xC0], xmm12
000078d941fd19ff  vmovaps [rsp+0xD0], xmm13
000078d941fd1a08  vmovaps [rsp+0xE0], xmm14
000078d941fd1a11  sub rsp, 0x30
000078d941fd1a15  movaps [rsp], xmm15
000078d941fd1a1a  movaps [rsp+0x10], xmm14
000078d941fd1a20  movaps [rsp+0x20], xmm1
000078d941fd1a25  lea rdi, [rsp]
000078d941fd1a29  mov esi, 0x00
000078d941fd1a2e  mov rax, 0x59BFBFBAA530
000078d941fd1a38  call rax
000078d941fd1a3a  movaps xmm15, [rsp]
000078d941fd1a3f  add rsp, 0x30
000078d941fd1a43  vmovaps xmm0, [rsp]
000078d941fd1a48  vmovaps xmm1, [rsp+0x10]
000078d941fd1a4e  vmovaps xmm2, [rsp+0x20]
000078d941fd1a54  vmovaps xmm3, [rsp+0x30]
000078d941fd1a5a  vmovaps xmm4, [rsp+0x40]
000078d941fd1a60  vmovaps xmm5, [rsp+0x50]
000078d941fd1a66  vmovaps xmm6, [rsp+0x60]
000078d941fd1a6c  vmovaps xmm7, [rsp+0x70]
000078d941fd1a72  vmovaps xmm8, [rsp+0x80]
000078d941fd1a7b  vmovaps xmm9, [rsp+0x90]
000078d941fd1a84  vmovaps xmm10, [rsp+0xA0]
000078d941fd1a8d  vmovaps xmm11, [rsp+0xB0]
000078d941fd1a96  vmovaps xmm12, [rsp+0xC0]
000078d941fd1a9f  vmovaps xmm13, [rsp+0xD0]
000078d941fd1aa8  vmovaps xmm14, [rsp+0xE0]
000078d941fd1ab1  add rsp, 0xF0
000078d941fd1ab8  pop r11
000078d941fd1aba  pop r10
000078d941fd1abc  pop r9
000078d941fd1abe  pop r8
000078d941fd1ac0  pop rsi
000078d941fd1ac1  pop rdi
000078d941fd1ac2  pop rdx
000078d941fd1ac3  pop rcx
000078d941fd1ac4  pop rax
000078d941fd1ac5  add rsp, 0x08
000078d941fd1ac9  jmp 0x000078D941FCF9E7
000078d941fd1ace  call 0x000078D941DFF430
000078d941fd1ad3  jmp 0x000078D941FCF9F4
000078d941fd1ad8  sub rsp, 0x08
000078d941fd1adc  push rax
000078d941fd1add  push rcx
000078d941fd1ade  push rdx
000078d941fd1adf  push rdi
000078d941fd1ae0  push rsi
000078d941fd1ae1  push r8
000078d941fd1ae3  push r9
000078d941fd1ae5  push r10
000078d941fd1ae7  push r11
000078d941fd1ae9  sub rsp, 0xF0
000078d941fd1af0  vmovaps [rsp], xmm0
000078d941fd1af5  vmovaps [rsp+0x10], xmm1
000078d941fd1afb  vmovaps [rsp+0x20], xmm2
000078d941fd1b01  vmovaps [rsp+0x30], xmm3
000078d941fd1b07  vmovaps [rsp+0x40], xmm4
000078d941fd1b0d  vmovaps [rsp+0x50], xmm5
000078d941fd1b13  vmovaps [rsp+0x60], xmm6
000078d941fd1b19  vmovaps [rsp+0x70], xmm7
000078d941fd1b1f  vmovaps [rsp+0x80], xmm8
000078d941fd1b28  vmovaps [rsp+0x90], xmm9
000078d941fd1b31  vmovaps [rsp+0xA0], xmm10
000078d941fd1b3a  vmovaps [rsp+0xB0], xmm11
000078d941fd1b43  vmovaps [rsp+0xC0], xmm12
000078d941fd1b4c  vmovaps [rsp+0xD0], xmm13
000078d941fd1b55  vmovaps [rsp+0xE0], xmm15
000078d941fd1b5e  sub rsp, 0x30
000078d941fd1b62  movaps [rsp], xmm14
000078d941fd1b67  movaps [rsp+0x10], xmm13
000078d941fd1b6d  movaps [rsp+0x20], xmm1
000078d941fd1b72  lea rdi, [rsp]
000078d941fd1b76  mov esi, 0x00
000078d941fd1b7b  mov rax, 0x59BFBFBAA530
000078d941fd1b85  call rax
000078d941fd1b87  movaps xmm14, [rsp]
000078d941fd1b8c  add rsp, 0x30
000078d941fd1b90  vmovaps xmm0, [rsp]
000078d941fd1b95  vmovaps xmm1, [rsp+0x10]
000078d941fd1b9b  vmovaps xmm2, [rsp+0x20]
000078d941fd1ba1  vmovaps xmm3, [rsp+0x30]
000078d941fd1ba7  vmovaps xmm4, [rsp+0x40]
000078d941fd1bad  vmovaps xmm5, [rsp+0x50]
000078d941fd1bb3  vmovaps xmm6, [rsp+0x60]
000078d941fd1bb9  vmovaps xmm7, [rsp+0x70]
000078d941fd1bbf  vmovaps xmm8, [rsp+0x80]
000078d941fd1bc8  vmovaps xmm9, [rsp+0x90]
000078d941fd1bd1  vmovaps xmm10, [rsp+0xA0]
000078d941fd1bda  vmovaps xmm11, [rsp+0xB0]
000078d941fd1be3  vmovaps xmm12, [rsp+0xC0]
000078d941fd1bec  vmovaps xmm13, [rsp+0xD0]
000078d941fd1bf5  vmovaps xmm15, [rsp+0xE0]
000078d941fd1bfe  add rsp, 0xF0
000078d941fd1c05  pop r11
000078d941fd1c07  pop r10
000078d941fd1c09  pop r9
000078d941fd1c0b  pop r8
000078d941fd1c0d  pop rsi
000078d941fd1c0e  pop rdi
000078d941fd1c0f  pop rdx
000078d941fd1c10  pop rcx
000078d941fd1c11  pop rax
000078d941fd1c12  add rsp, 0x08
000078d941fd1c16  jmp 0x000078D941FCFAAF
000078d941fd1c1b  sub rsp, 0x08
000078d941fd1c1f  push rax
000078d941fd1c20  push rcx
000078d941fd1c21  push rdx
000078d941fd1c22  push rdi
000078d941fd1c23  push rsi
000078d941fd1c24  push r8
000078d941fd1c26  push r9
000078d941fd1c28  push r10
000078d941fd1c2a  push r11
000078d941fd1c2c  sub rsp, 0xF0
000078d941fd1c33  vmovaps [rsp], xmm0
000078d941fd1c38  vmovaps [rsp+0x10], xmm1
000078d941fd1c3e  vmovaps [rsp+0x20], xmm2
000078d941fd1c44  vmovaps [rsp+0x30], xmm3
000078d941fd1c4a  vmovaps [rsp+0x40], xmm4
000078d941fd1c50  vmovaps [rsp+0x50], xmm5
000078d941fd1c56  vmovaps [rsp+0x60], xmm6
000078d941fd1c5c  vmovaps [rsp+0x70], xmm7
000078d941fd1c62  vmovaps [rsp+0x80], xmm8
000078d941fd1c6b  vmovaps [rsp+0x90], xmm9
000078d941fd1c74  vmovaps [rsp+0xA0], xmm10
000078d941fd1c7d  vmovaps [rsp+0xB0], xmm11
000078d941fd1c86  vmovaps [rsp+0xC0], xmm12
000078d941fd1c8f  vmovaps [rsp+0xD0], xmm13
000078d941fd1c98  vmovaps [rsp+0xE0], xmm14
000078d941fd1ca1  sub rsp, 0x30
000078d941fd1ca5  movaps [rsp], xmm15
000078d941fd1caa  movaps [rsp+0x10], xmm13
000078d941fd1cb0  movaps [rsp+0x20], xmm1
000078d941fd1cb5  lea rdi, [rsp]
000078d941fd1cb9  mov esi, 0x00
000078d941fd1cbe  mov rax, 0x59BFBFBAA530
000078d941fd1cc8  call rax
000078d941fd1cca  movaps xmm15, [rsp]
000078d941fd1ccf  add rsp, 0x30
000078d941fd1cd3  vmovaps xmm0, [rsp]
000078d941fd1cd8  vmovaps xmm1, [rsp+0x10]
000078d941fd1cde  vmovaps xmm2, [rsp+0x20]
000078d941fd1ce4  vmovaps xmm3, [rsp+0x30]
000078d941fd1cea  vmovaps xmm4, [rsp+0x40]
000078d941fd1cf0  vmovaps xmm5, [rsp+0x50]
000078d941fd1cf6  vmovaps xmm6, [rsp+0x60]
000078d941fd1cfc  vmovaps xmm7, [rsp+0x70]
000078d941fd1d02  vmovaps xmm8, [rsp+0x80]
000078d941fd1d0b  vmovaps xmm9, [rsp+0x90]
000078d941fd1d14  vmovaps xmm10, [rsp+0xA0]
000078d941fd1d1d  vmovaps xmm11, [rsp+0xB0]
000078d941fd1d26  vmovaps xmm12, [rsp+0xC0]
000078d941fd1d2f  vmovaps xmm13, [rsp+0xD0]
000078d941fd1d38  vmovaps xmm14, [rsp+0xE0]
000078d941fd1d41  add rsp, 0xF0
000078d941fd1d48  pop r11
000078d941fd1d4a  pop r10
000078d941fd1d4c  pop r9
000078d941fd1d4e  pop r8
000078d941fd1d50  pop rsi
000078d941fd1d51  pop rdi
000078d941fd1d52  pop rdx
000078d941fd1d53  pop rcx
000078d941fd1d54  pop rax
000078d941fd1d55  add rsp, 0x08
000078d941fd1d59  jmp 0x000078D941FCFAEB
000078d941fd1d5e  call 0x000078D941DFF430
000078d941fd1d63  jmp 0x000078D941FCFAF8
000078d941fd1d68  sub rsp, 0x08
000078d941fd1d6c  push rax
000078d941fd1d6d  push rcx
000078d941fd1d6e  push rdx
000078d941fd1d6f  push rdi
000078d941fd1d70  push rsi
000078d941fd1d71  push r8
000078d941fd1d73  push r9
000078d941fd1d75  push r10
000078d941fd1d77  push r11
000078d941fd1d79  sub rsp, 0xF0
000078d941fd1d80  vmovaps [rsp], xmm0
000078d941fd1d85  vmovaps [rsp+0x10], xmm1
000078d941fd1d8b  vmovaps [rsp+0x20], xmm2
000078d941fd1d91  vmovaps [rsp+0x30], xmm3
000078d941fd1d97  vmovaps [rsp+0x40], xmm4
000078d941fd1d9d  vmovaps [rsp+0x50], xmm5
000078d941fd1da3  vmovaps [rsp+0x60], xmm6
000078d941fd1da9  vmovaps [rsp+0x70], xmm7
000078d941fd1daf  vmovaps [rsp+0x80], xmm8
000078d941fd1db8  vmovaps [rsp+0x90], xmm9
000078d941fd1dc1  vmovaps [rsp+0xA0], xmm10
000078d941fd1dca  vmovaps [rsp+0xB0], xmm11
000078d941fd1dd3  vmovaps [rsp+0xC0], xmm12
000078d941fd1ddc  vmovaps [rsp+0xD0], xmm13
000078d941fd1de5  vmovaps [rsp+0xE0], xmm15
000078d941fd1dee  sub rsp, 0x30
000078d941fd1df2  movaps [rsp], xmm14
000078d941fd1df7  movaps [rsp+0x10], xmm13
000078d941fd1dfd  movaps [rsp+0x20], xmm2
000078d941fd1e02  lea rdi, [rsp]
000078d941fd1e06  mov esi, 0x00
000078d941fd1e0b  mov rax, 0x59BFBFBAA530
000078d941fd1e15  call rax
000078d941fd1e17  movaps xmm14, [rsp]
000078d941fd1e1c  add rsp, 0x30
000078d941fd1e20  vmovaps xmm0, [rsp]
000078d941fd1e25  vmovaps xmm1, [rsp+0x10]
000078d941fd1e2b  vmovaps xmm2, [rsp+0x20]
000078d941fd1e31  vmovaps xmm3, [rsp+0x30]
000078d941fd1e37  vmovaps xmm4, [rsp+0x40]
000078d941fd1e3d  vmovaps xmm5, [rsp+0x50]
000078d941fd1e43  vmovaps xmm6, [rsp+0x60]
000078d941fd1e49  vmovaps xmm7, [rsp+0x70]
000078d941fd1e4f  vmovaps xmm8, [rsp+0x80]
000078d941fd1e58  vmovaps xmm9, [rsp+0x90]
000078d941fd1e61  vmovaps xmm10, [rsp+0xA0]
000078d941fd1e6a  vmovaps xmm11, [rsp+0xB0]
000078d941fd1e73  vmovaps xmm12, [rsp+0xC0]
000078d941fd1e7c  vmovaps xmm13, [rsp+0xD0]
000078d941fd1e85  vmovaps xmm15, [rsp+0xE0]
000078d941fd1e8e  add rsp, 0xF0
000078d941fd1e95  pop r11
000078d941fd1e97  pop r10
000078d941fd1e99  pop r9
000078d941fd1e9b  pop r8
000078d941fd1e9d  pop rsi
000078d941fd1e9e  pop rdi
000078d941fd1e9f  pop rdx
000078d941fd1ea0  pop rcx
000078d941fd1ea1  pop rax
000078d941fd1ea2  add rsp, 0x08
000078d941fd1ea6  jmp 0x000078D941FCFB24
000078d941fd1eab  sub rsp, 0x08
000078d941fd1eaf  push rax
000078d941fd1eb0  push rcx
000078d941fd1eb1  push rdx
000078d941fd1eb2  push rdi
000078d941fd1eb3  push rsi
000078d941fd1eb4  push r8
000078d941fd1eb6  push r9
000078d941fd1eb8  push r10
000078d941fd1eba  push r11
000078d941fd1ebc  sub rsp, 0xF0
000078d941fd1ec3  vmovaps [rsp], xmm0
000078d941fd1ec8  vmovaps [rsp+0x10], xmm2
000078d941fd1ece  vmovaps [rsp+0x20], xmm3
000078d941fd1ed4  vmovaps [rsp+0x30], xmm4
000078d941fd1eda  vmovaps [rsp+0x40], xmm5
000078d941fd1ee0  vmovaps [rsp+0x50], xmm6
000078d941fd1ee6  vmovaps [rsp+0x60], xmm7
000078d941fd1eec  vmovaps [rsp+0x70], xmm8
000078d941fd1ef2  vmovaps [rsp+0x80], xmm9
000078d941fd1efb  vmovaps [rsp+0x90], xmm10
000078d941fd1f04  vmovaps [rsp+0xA0], xmm11
000078d941fd1f0d  vmovaps [rsp+0xB0], xmm12
000078d941fd1f16  vmovaps [rsp+0xC0], xmm13
000078d941fd1f1f  vmovaps [rsp+0xD0], xmm14
000078d941fd1f28  vmovaps [rsp+0xE0], xmm15
000078d941fd1f31  sub rsp, 0x30
000078d941fd1f35  movaps [rsp], xmm1
000078d941fd1f39  movaps [rsp+0x10], xmm13
000078d941fd1f3f  movaps [rsp+0x20], xmm2
000078d941fd1f44  lea rdi, [rsp]
000078d941fd1f48  mov esi, 0x00
000078d941fd1f4d  mov rax, 0x59BFBFBAA530
000078d941fd1f57  call rax
000078d941fd1f59  movaps xmm1, [rsp]
000078d941fd1f5d  add rsp, 0x30
000078d941fd1f61  vmovaps xmm0, [rsp]
000078d941fd1f66  vmovaps xmm2, [rsp+0x10]
000078d941fd1f6c  vmovaps xmm3, [rsp+0x20]
000078d941fd1f72  vmovaps xmm4, [rsp+0x30]
000078d941fd1f78  vmovaps xmm5, [rsp+0x40]
000078d941fd1f7e  vmovaps xmm6, [rsp+0x50]
000078d941fd1f84  vmovaps xmm7, [rsp+0x60]
000078d941fd1f8a  vmovaps xmm8, [rsp+0x70]
000078d941fd1f90  vmovaps xmm9, [rsp+0x80]
000078d941fd1f99  vmovaps xmm10, [rsp+0x90]
000078d941fd1fa2  vmovaps xmm11, [rsp+0xA0]
000078d941fd1fab  vmovaps xmm12, [rsp+0xB0]
000078d941fd1fb4  vmovaps xmm13, [rsp+0xC0]
000078d941fd1fbd  vmovaps xmm14, [rsp+0xD0]
000078d941fd1fc6  vmovaps xmm15, [rsp+0xE0]
000078d941fd1fcf  add rsp, 0xF0
000078d941fd1fd6  pop r11
000078d941fd1fd8  pop r10
000078d941fd1fda  pop r9
000078d941fd1fdc  pop r8
000078d941fd1fde  pop rsi
000078d941fd1fdf  pop rdi
000078d941fd1fe0  pop rdx
000078d941fd1fe1  pop rcx
000078d941fd1fe2  pop rax
000078d941fd1fe3  add rsp, 0x08
000078d941fd1fe7  jmp 0x000078D941FCFB52
000078d941fd1fec  sub rsp, 0x08
000078d941fd1ff0  push rax
000078d941fd1ff1  push rcx
000078d941fd1ff2  push rdx
000078d941fd1ff3  push rdi
000078d941fd1ff4  push rsi
000078d941fd1ff5  push r8
000078d941fd1ff7  push r9
000078d941fd1ff9  push r10
000078d941fd1ffb  push r11
000078d941fd1ffd  sub rsp, 0xF0
000078d941fd2004  vmovaps [rsp], xmm0
000078d941fd2009  vmovaps [rsp+0x10], xmm1
000078d941fd200f  vmovaps [rsp+0x20], xmm3
000078d941fd2015  vmovaps [rsp+0x30], xmm4
000078d941fd201b  vmovaps [rsp+0x40], xmm5
000078d941fd2021  vmovaps [rsp+0x50], xmm6
000078d941fd2027  vmovaps [rsp+0x60], xmm7
000078d941fd202d  vmovaps [rsp+0x70], xmm8
000078d941fd2033  vmovaps [rsp+0x80], xmm9
000078d941fd203c  vmovaps [rsp+0x90], xmm10
000078d941fd2045  vmovaps [rsp+0xA0], xmm11
000078d941fd204e  vmovaps [rsp+0xB0], xmm12
000078d941fd2057  vmovaps [rsp+0xC0], xmm13
000078d941fd2060  vmovaps [rsp+0xD0], xmm14
000078d941fd2069  vmovaps [rsp+0xE0], xmm15
000078d941fd2072  sub rsp, 0x30
000078d941fd2076  movaps [rsp], xmm2
000078d941fd207a  movaps [rsp+0x10], xmm1
000078d941fd207f  movaps [rsp+0x20], xmm13
000078d941fd2085  lea rdi, [rsp]
000078d941fd2089  mov esi, 0x00
000078d941fd208e  mov rax, 0x59BFBFBAA530
000078d941fd2098  call rax
000078d941fd209a  movaps xmm2, [rsp]
000078d941fd209e  add rsp, 0x30
000078d941fd20a2  vmovaps xmm0, [rsp]
000078d941fd20a7  vmovaps xmm1, [rsp+0x10]
000078d941fd20ad  vmovaps xmm3, [rsp+0x20]
000078d941fd20b3  vmovaps xmm4, [rsp+0x30]
000078d941fd20b9  vmovaps xmm5, [rsp+0x40]
000078d941fd20bf  vmovaps xmm6, [rsp+0x50]
000078d941fd20c5  vmovaps xmm7, [rsp+0x60]
000078d941fd20cb  vmovaps xmm8, [rsp+0x70]
000078d941fd20d1  vmovaps xmm9, [rsp+0x80]
000078d941fd20da  vmovaps xmm10, [rsp+0x90]
000078d941fd20e3  vmovaps xmm11, [rsp+0xA0]
000078d941fd20ec  vmovaps xmm12, [rsp+0xB0]
000078d941fd20f5  vmovaps xmm13, [rsp+0xC0]
000078d941fd20fe  vmovaps xmm14, [rsp+0xD0]
000078d941fd2107  vmovaps xmm15, [rsp+0xE0]
000078d941fd2110  add rsp, 0xF0
000078d941fd2117  pop r11
000078d941fd2119  pop r10
000078d941fd211b  pop r9
000078d941fd211d  pop r8
000078d941fd211f  pop rsi
000078d941fd2120  pop rdi
000078d941fd2121  pop rdx
000078d941fd2122  pop rcx
000078d941fd2123  pop rax
000078d941fd2124  add rsp, 0x08
000078d941fd2128  jmp 0x000078D941FCFBAB
000078d941fd212d  call 0x000078D941DFF430
000078d941fd2132  jmp 0x000078D941FCFBB8
000078d941fd2137  sub rsp, 0x08
000078d941fd213b  push rax
000078d941fd213c  push rcx
000078d941fd213d  push rdx
000078d941fd213e  push rdi
000078d941fd213f  push rsi
000078d941fd2140  push r8
000078d941fd2142  push r9
000078d941fd2144  push r10
000078d941fd2146  push r11
000078d941fd2148  sub rsp, 0xF0
000078d941fd214f  vmovaps [rsp], xmm0
000078d941fd2154  vmovaps [rsp+0x10], xmm1
000078d941fd215a  vmovaps [rsp+0x20], xmm2
000078d941fd2160  vmovaps [rsp+0x30], xmm3
000078d941fd2166  vmovaps [rsp+0x40], xmm4
000078d941fd216c  vmovaps [rsp+0x50], xmm5
000078d941fd2172  vmovaps [rsp+0x60], xmm6
000078d941fd2178  vmovaps [rsp+0x70], xmm7
000078d941fd217e  vmovaps [rsp+0x80], xmm8
000078d941fd2187  vmovaps [rsp+0x90], xmm9
000078d941fd2190  vmovaps [rsp+0xA0], xmm10
000078d941fd2199  vmovaps [rsp+0xB0], xmm11
000078d941fd21a2  vmovaps [rsp+0xC0], xmm12
000078d941fd21ab  vmovaps [rsp+0xD0], xmm13
000078d941fd21b4  vmovaps [rsp+0xE0], xmm14
000078d941fd21bd  sub rsp, 0x30
000078d941fd21c1  movaps [rsp], xmm15
000078d941fd21c6  movaps [rsp+0x10], xmm13
000078d941fd21cc  movaps [rsp+0x20], xmm1
000078d941fd21d1  lea rdi, [rsp]
000078d941fd21d5  mov esi, 0x00
000078d941fd21da  mov rax, 0x59BFBFBAA530
000078d941fd21e4  call rax
000078d941fd21e6  movaps xmm15, [rsp]
000078d941fd21eb  add rsp, 0x30
000078d941fd21ef  vmovaps xmm0, [rsp]
000078d941fd21f4  vmovaps xmm1, [rsp+0x10]
000078d941fd21fa  vmovaps xmm2, [rsp+0x20]
000078d941fd2200  vmovaps xmm3, [rsp+0x30]
000078d941fd2206  vmovaps xmm4, [rsp+0x40]
000078d941fd220c  vmovaps xmm5, [rsp+0x50]
000078d941fd2212  vmovaps xmm6, [rsp+0x60]
000078d941fd2218  vmovaps xmm7, [rsp+0x70]
000078d941fd221e  vmovaps xmm8, [rsp+0x80]
000078d941fd2227  vmovaps xmm9, [rsp+0x90]
000078d941fd2230  vmovaps xmm10, [rsp+0xA0]
000078d941fd2239  vmovaps xmm11, [rsp+0xB0]
000078d941fd2242  vmovaps xmm12, [rsp+0xC0]
000078d941fd224b  vmovaps xmm13, [rsp+0xD0]
000078d941fd2254  vmovaps xmm14, [rsp+0xE0]
000078d941fd225d  add rsp, 0xF0
000078d941fd2264  pop r11
000078d941fd2266  pop r10
000078d941fd2268  pop r9
000078d941fd226a  pop r8
000078d941fd226c  pop rsi
000078d941fd226d  pop rdi
000078d941fd226e  pop rdx
000078d941fd226f  pop rcx
000078d941fd2270  pop rax
000078d941fd2271  add rsp, 0x08
000078d941fd2275  jmp 0x000078D941FCFBF7
000078d941fd227a  sub rsp, 0x08
000078d941fd227e  push rax
000078d941fd227f  push rcx
000078d941fd2280  push rdx
000078d941fd2281  push rdi
000078d941fd2282  push rsi
000078d941fd2283  push r8
000078d941fd2285  push r9
000078d941fd2287  push r10
000078d941fd2289  push r11
000078d941fd228b  sub rsp, 0xF0
000078d941fd2292  vmovaps [rsp], xmm0
000078d941fd2297  vmovaps [rsp+0x10], xmm1
000078d941fd229d  vmovaps [rsp+0x20], xmm2
000078d941fd22a3  vmovaps [rsp+0x30], xmm3
000078d941fd22a9  vmovaps [rsp+0x40], xmm4
000078d941fd22af  vmovaps [rsp+0x50], xmm5
000078d941fd22b5  vmovaps [rsp+0x60], xmm6
000078d941fd22bb  vmovaps [rsp+0x70], xmm7
000078d941fd22c1  vmovaps [rsp+0x80], xmm8
000078d941fd22ca  vmovaps [rsp+0x90], xmm9
000078d941fd22d3  vmovaps [rsp+0xA0], xmm10
000078d941fd22dc  vmovaps [rsp+0xB0], xmm11
000078d941fd22e5  vmovaps [rsp+0xC0], xmm12
000078d941fd22ee  vmovaps [rsp+0xD0], xmm13
000078d941fd22f7  vmovaps [rsp+0xE0], xmm15
000078d941fd2300  sub rsp, 0x30
000078d941fd2304  movaps [rsp], xmm14
000078d941fd2309  movaps [rsp+0x10], xmm11
000078d941fd230f  movaps [rsp+0x20], xmm1
000078d941fd2314  lea rdi, [rsp]
000078d941fd2318  mov esi, 0x00
000078d941fd231d  mov rax, 0x59BFBFBAA530
000078d941fd2327  call rax
000078d941fd2329  movaps xmm14, [rsp]
000078d941fd232e  add rsp, 0x30
000078d941fd2332  vmovaps xmm0, [rsp]
000078d941fd2337  vmovaps xmm1, [rsp+0x10]
000078d941fd233d  vmovaps xmm2, [rsp+0x20]
000078d941fd2343  vmovaps xmm3, [rsp+0x30]
000078d941fd2349  vmovaps xmm4, [rsp+0x40]
000078d941fd234f  vmovaps xmm5, [rsp+0x50]
000078d941fd2355  vmovaps xmm6, [rsp+0x60]
000078d941fd235b  vmovaps xmm7, [rsp+0x70]
000078d941fd2361  vmovaps xmm8, [rsp+0x80]
000078d941fd236a  vmovaps xmm9, [rsp+0x90]
000078d941fd2373  vmovaps xmm10, [rsp+0xA0]
000078d941fd237c  vmovaps xmm11, [rsp+0xB0]
000078d941fd2385  vmovaps xmm12, [rsp+0xC0]
000078d941fd238e  vmovaps xmm13, [rsp+0xD0]
000078d941fd2397  vmovaps xmm15, [rsp+0xE0]
000078d941fd23a0  add rsp, 0xF0
000078d941fd23a7  pop r11
000078d941fd23a9  pop r10
000078d941fd23ab  pop r9
000078d941fd23ad  pop r8
000078d941fd23af  pop rsi
000078d941fd23b0  pop rdi
000078d941fd23b1  pop rdx
000078d941fd23b2  pop rcx
000078d941fd23b3  pop rax
000078d941fd23b4  add rsp, 0x08
000078d941fd23b8  jmp 0x000078D941FCFC21
000078d941fd23bd  sub rsp, 0x08
000078d941fd23c1  push rax
000078d941fd23c2  push rcx
000078d941fd23c3  push rdx
000078d941fd23c4  push rdi
000078d941fd23c5  push rsi
000078d941fd23c6  push r8
000078d941fd23c8  push r9
000078d941fd23ca  push r10
000078d941fd23cc  push r11
000078d941fd23ce  sub rsp, 0xF0
000078d941fd23d5  vmovaps [rsp], xmm0
000078d941fd23da  vmovaps [rsp+0x10], xmm1
000078d941fd23e0  vmovaps [rsp+0x20], xmm2
000078d941fd23e6  vmovaps [rsp+0x30], xmm3
000078d941fd23ec  vmovaps [rsp+0x40], xmm4
000078d941fd23f2  vmovaps [rsp+0x50], xmm5
000078d941fd23f8  vmovaps [rsp+0x60], xmm6
000078d941fd23fe  vmovaps [rsp+0x70], xmm7
000078d941fd2404  vmovaps [rsp+0x80], xmm8
000078d941fd240d  vmovaps [rsp+0x90], xmm9
000078d941fd2416  vmovaps [rsp+0xA0], xmm10
000078d941fd241f  vmovaps [rsp+0xB0], xmm11
000078d941fd2428  vmovaps [rsp+0xC0], xmm12
000078d941fd2431  vmovaps [rsp+0xD0], xmm14
000078d941fd243a  vmovaps [rsp+0xE0], xmm15
000078d941fd2443  sub rsp, 0x30
000078d941fd2447  movaps [rsp], xmm13
000078d941fd244c  movaps [rsp+0x10], xmm11
000078d941fd2452  movaps [rsp+0x20], xmm1
000078d941fd2457  lea rdi, [rsp]
000078d941fd245b  mov esi, 0x00
000078d941fd2460  mov rax, 0x59BFBFBAA530
000078d941fd246a  call rax
000078d941fd246c  movaps xmm13, [rsp]
000078d941fd2471  add rsp, 0x30
000078d941fd2475  vmovaps xmm0, [rsp]
000078d941fd247a  vmovaps xmm1, [rsp+0x10]
000078d941fd2480  vmovaps xmm2, [rsp+0x20]
000078d941fd2486  vmovaps xmm3, [rsp+0x30]
000078d941fd248c  vmovaps xmm4, [rsp+0x40]
000078d941fd2492  vmovaps xmm5, [rsp+0x50]
000078d941fd2498  vmovaps xmm6, [rsp+0x60]
000078d941fd249e  vmovaps xmm7, [rsp+0x70]
000078d941fd24a4  vmovaps xmm8, [rsp+0x80]
000078d941fd24ad  vmovaps xmm9, [rsp+0x90]
000078d941fd24b6  vmovaps xmm10, [rsp+0xA0]
000078d941fd24bf  vmovaps xmm11, [rsp+0xB0]
000078d941fd24c8  vmovaps xmm12, [rsp+0xC0]
000078d941fd24d1  vmovaps xmm14, [rsp+0xD0]
000078d941fd24da  vmovaps xmm15, [rsp+0xE0]
000078d941fd24e3  add rsp, 0xF0
000078d941fd24ea  pop r11
000078d941fd24ec  pop r10
000078d941fd24ee  pop r9
000078d941fd24f0  pop r8
000078d941fd24f2  pop rsi
000078d941fd24f3  pop rdi
000078d941fd24f4  pop rdx
000078d941fd24f5  pop rcx
000078d941fd24f6  pop rax
000078d941fd24f7  add rsp, 0x08
000078d941fd24fb  jmp 0x000078D941FCFC76
000078d941fd2500  call 0x000078D941DFF430
000078d941fd2505  jmp 0x000078D941FCFC83
000078d941fd250a  sub rsp, 0x08
000078d941fd250e  push rax
000078d941fd250f  push rcx
000078d941fd2510  push rdx
000078d941fd2511  push rdi
000078d941fd2512  push rsi
000078d941fd2513  push r8
000078d941fd2515  push r9
000078d941fd2517  push r10
000078d941fd2519  push r11
000078d941fd251b  sub rsp, 0xF0
000078d941fd2522  vmovaps [rsp], xmm0
000078d941fd2527  vmovaps [rsp+0x10], xmm1
000078d941fd252d  vmovaps [rsp+0x20], xmm2
000078d941fd2533  vmovaps [rsp+0x30], xmm3
000078d941fd2539  vmovaps [rsp+0x40], xmm4
000078d941fd253f  vmovaps [rsp+0x50], xmm5
000078d941fd2545  vmovaps [rsp+0x60], xmm6
000078d941fd254b  vmovaps [rsp+0x70], xmm7
000078d941fd2551  vmovaps [rsp+0x80], xmm8
000078d941fd255a  vmovaps [rsp+0x90], xmm9
000078d941fd2563  vmovaps [rsp+0xA0], xmm10
000078d941fd256c  vmovaps [rsp+0xB0], xmm11
000078d941fd2575  vmovaps [rsp+0xC0], xmm12
000078d941fd257e  vmovaps [rsp+0xD0], xmm13
000078d941fd2587  vmovaps [rsp+0xE0], xmm14
000078d941fd2590  sub rsp, 0x30
000078d941fd2594  movaps [rsp], xmm15
000078d941fd2599  movaps [rsp+0x10], xmm11
000078d941fd259f  movaps [rsp+0x20], xmm1
000078d941fd25a4  lea rdi, [rsp]
000078d941fd25a8  mov esi, 0x00
000078d941fd25ad  mov rax, 0x59BFBFBAA530
000078d941fd25b7  call rax
000078d941fd25b9  movaps xmm15, [rsp]
000078d941fd25be  add rsp, 0x30
000078d941fd25c2  vmovaps xmm0, [rsp]
000078d941fd25c7  vmovaps xmm1, [rsp+0x10]
000078d941fd25cd  vmovaps xmm2, [rsp+0x20]
000078d941fd25d3  vmovaps xmm3, [rsp+0x30]
000078d941fd25d9  vmovaps xmm4, [rsp+0x40]
000078d941fd25df  vmovaps xmm5, [rsp+0x50]
000078d941fd25e5  vmovaps xmm6, [rsp+0x60]
000078d941fd25eb  vmovaps xmm7, [rsp+0x70]
000078d941fd25f1  vmovaps xmm8, [rsp+0x80]
000078d941fd25fa  vmovaps xmm9, [rsp+0x90]
000078d941fd2603  vmovaps xmm10, [rsp+0xA0]
000078d941fd260c  vmovaps xmm11, [rsp+0xB0]
000078d941fd2615  vmovaps xmm12, [rsp+0xC0]
000078d941fd261e  vmovaps xmm13, [rsp+0xD0]
000078d941fd2627  vmovaps xmm14, [rsp+0xE0]
000078d941fd2630  add rsp, 0xF0
000078d941fd2637  pop r11
000078d941fd2639  pop r10
000078d941fd263b  pop r9
000078d941fd263d  pop r8
000078d941fd263f  pop rsi
000078d941fd2640  pop rdi
000078d941fd2641  pop rdx
000078d941fd2642  pop rcx
000078d941fd2643  pop rax
000078d941fd2644  add rsp, 0x08
000078d941fd2648  jmp 0x000078D941FCFCBC
000078d941fd264d  sub rsp, 0x08
000078d941fd2651  push rax
000078d941fd2652  push rcx
000078d941fd2653  push rdx
000078d941fd2654  push rdi
000078d941fd2655  push rsi
000078d941fd2656  push r8
000078d941fd2658  push r9
000078d941fd265a  push r10
000078d941fd265c  push r11
000078d941fd265e  sub rsp, 0xF0
000078d941fd2665  vmovaps [rsp], xmm0
000078d941fd266a  vmovaps [rsp+0x10], xmm1
000078d941fd2670  vmovaps [rsp+0x20], xmm2
000078d941fd2676  vmovaps [rsp+0x30], xmm3
000078d941fd267c  vmovaps [rsp+0x40], xmm4
000078d941fd2682  vmovaps [rsp+0x50], xmm5
000078d941fd2688  vmovaps [rsp+0x60], xmm6
000078d941fd268e  vmovaps [rsp+0x70], xmm7
000078d941fd2694  vmovaps [rsp+0x80], xmm8
000078d941fd269d  vmovaps [rsp+0x90], xmm9
000078d941fd26a6  vmovaps [rsp+0xA0], xmm10
000078d941fd26af  vmovaps [rsp+0xB0], xmm12
000078d941fd26b8  vmovaps [rsp+0xC0], xmm13
000078d941fd26c1  vmovaps [rsp+0xD0], xmm14
000078d941fd26ca  vmovaps [rsp+0xE0], xmm15
000078d941fd26d3  sub rsp, 0x30
000078d941fd26d7  movaps [rsp], xmm11
000078d941fd26dc  movaps [rsp+0x10], xmm6
000078d941fd26e1  movaps [rsp+0x20], xmm14
000078d941fd26e7  lea rdi, [rsp]
000078d941fd26eb  mov esi, 0x00
000078d941fd26f0  mov rax, 0x59BFBFBAA530
000078d941fd26fa  call rax
000078d941fd26fc  movaps xmm11, [rsp]
000078d941fd2701  add rsp, 0x30
000078d941fd2705  vmovaps xmm0, [rsp]
000078d941fd270a  vmovaps xmm1, [rsp+0x10]
000078d941fd2710  vmovaps xmm2, [rsp+0x20]
000078d941fd2716  vmovaps xmm3, [rsp+0x30]
000078d941fd271c  vmovaps xmm4, [rsp+0x40]
000078d941fd2722  vmovaps xmm5, [rsp+0x50]
000078d941fd2728  vmovaps xmm6, [rsp+0x60]
000078d941fd272e  vmovaps xmm7, [rsp+0x70]
000078d941fd2734  vmovaps xmm8, [rsp+0x80]
000078d941fd273d  vmovaps xmm9, [rsp+0x90]
000078d941fd2746  vmovaps xmm10, [rsp+0xA0]
000078d941fd274f  vmovaps xmm12, [rsp+0xB0]
000078d941fd2758  vmovaps xmm13, [rsp+0xC0]
000078d941fd2761  vmovaps xmm14, [rsp+0xD0]
000078d941fd276a  vmovaps xmm15, [rsp+0xE0]
000078d941fd2773  add rsp, 0xF0
000078d941fd277a  pop r11
000078d941fd277c  pop r10
000078d941fd277e  pop r9
000078d941fd2780  pop r8
000078d941fd2782  pop rsi
000078d941fd2783  pop rdi
000078d941fd2784  pop rdx
000078d941fd2785  pop rcx
000078d941fd2786  pop rax
000078d941fd2787  add rsp, 0x08
000078d941fd278b  jmp 0x000078D941FCFD34
000078d941fd2790  call 0x000078D941DFF430
000078d941fd2795  jmp 0x000078D941FCFD3E
000078d941fd279a  sub rsp, 0x08
000078d941fd279e  push rax
000078d941fd279f  push rcx
000078d941fd27a0  push rdx
000078d941fd27a1  push rdi
000078d941fd27a2  push rsi
000078d941fd27a3  push r8
000078d941fd27a5  push r9
000078d941fd27a7  push r10
000078d941fd27a9  push r11
000078d941fd27ab  sub rsp, 0xF0
000078d941fd27b2  vmovaps [rsp], xmm0
000078d941fd27b7  vmovaps [rsp+0x10], xmm1
000078d941fd27bd  vmovaps [rsp+0x20], xmm2
000078d941fd27c3  vmovaps [rsp+0x30], xmm3
000078d941fd27c9  vmovaps [rsp+0x40], xmm4
000078d941fd27cf  vmovaps [rsp+0x50], xmm5
000078d941fd27d5  vmovaps [rsp+0x60], xmm6
000078d941fd27db  vmovaps [rsp+0x70], xmm7
000078d941fd27e1  vmovaps [rsp+0x80], xmm8
000078d941fd27ea  vmovaps [rsp+0x90], xmm9
000078d941fd27f3  vmovaps [rsp+0xA0], xmm10
000078d941fd27fc  vmovaps [rsp+0xB0], xmm11
000078d941fd2805  vmovaps [rsp+0xC0], xmm12
000078d941fd280e  vmovaps [rsp+0xD0], xmm13
000078d941fd2817  vmovaps [rsp+0xE0], xmm15
000078d941fd2820  sub rsp, 0x30
000078d941fd2824  movaps [rsp], xmm14
000078d941fd2829  movaps [rsp+0x10], xmm6
000078d941fd282e  movaps [rsp+0x20], xmm2
000078d941fd2833  lea rdi, [rsp]
000078d941fd2837  mov esi, 0x00
000078d941fd283c  mov rax, 0x59BFBFBAA530
000078d941fd2846  call rax
000078d941fd2848  movaps xmm14, [rsp]
000078d941fd284d  add rsp, 0x30
000078d941fd2851  vmovaps xmm0, [rsp]
000078d941fd2856  vmovaps xmm1, [rsp+0x10]
000078d941fd285c  vmovaps xmm2, [rsp+0x20]
000078d941fd2862  vmovaps xmm3, [rsp+0x30]
000078d941fd2868  vmovaps xmm4, [rsp+0x40]
000078d941fd286e  vmovaps xmm5, [rsp+0x50]
000078d941fd2874  vmovaps xmm6, [rsp+0x60]
000078d941fd287a  vmovaps xmm7, [rsp+0x70]
000078d941fd2880  vmovaps xmm8, [rsp+0x80]
000078d941fd2889  vmovaps xmm9, [rsp+0x90]
000078d941fd2892  vmovaps xmm10, [rsp+0xA0]
000078d941fd289b  vmovaps xmm11, [rsp+0xB0]
000078d941fd28a4  vmovaps xmm12, [rsp+0xC0]
000078d941fd28ad  vmovaps xmm13, [rsp+0xD0]
000078d941fd28b6  vmovaps xmm15, [rsp+0xE0]
000078d941fd28bf  add rsp, 0xF0
000078d941fd28c6  pop r11
000078d941fd28c8  pop r10
000078d941fd28ca  pop r9
000078d941fd28cc  pop r8
000078d941fd28ce  pop rsi
000078d941fd28cf  pop rdi
000078d941fd28d0  pop rdx
000078d941fd28d1  pop rcx
000078d941fd28d2  pop rax
000078d941fd28d3  add rsp, 0x08
000078d941fd28d7  jmp 0x000078D941FCFD72
000078d941fd28dc  sub rsp, 0x08
000078d941fd28e0  push rax
000078d941fd28e1  push rcx
000078d941fd28e2  push rdx
000078d941fd28e3  push rdi
000078d941fd28e4  push rsi
000078d941fd28e5  push r8
000078d941fd28e7  push r9
000078d941fd28e9  push r10
000078d941fd28eb  push r11
000078d941fd28ed  sub rsp, 0xF0
000078d941fd28f4  vmovaps [rsp], xmm0
000078d941fd28f9  vmovaps [rsp+0x10], xmm1
000078d941fd28ff  vmovaps [rsp+0x20], xmm2
000078d941fd2905  vmovaps [rsp+0x30], xmm3
000078d941fd290b  vmovaps [rsp+0x40], xmm4
000078d941fd2911  vmovaps [rsp+0x50], xmm5
000078d941fd2917  vmovaps [rsp+0x60], xmm7
000078d941fd291d  vmovaps [rsp+0x70], xmm8
000078d941fd2923  vmovaps [rsp+0x80], xmm9
000078d941fd292c  vmovaps [rsp+0x90], xmm10
000078d941fd2935  vmovaps [rsp+0xA0], xmm11
000078d941fd293e  vmovaps [rsp+0xB0], xmm12
000078d941fd2947  vmovaps [rsp+0xC0], xmm13
000078d941fd2950  vmovaps [rsp+0xD0], xmm14
000078d941fd2959  vmovaps [rsp+0xE0], xmm15
000078d941fd2962  sub rsp, 0x30
000078d941fd2966  movaps [rsp], xmm6
000078d941fd296a  movaps [rsp+0x10], xmm5
000078d941fd296f  movaps [rsp+0x20], xmm1
000078d941fd2974  lea rdi, [rsp]
000078d941fd2978  mov esi, 0x00
000078d941fd297d  mov rax, 0x59BFBFBAA530
000078d941fd2987  call rax
000078d941fd2989  movaps xmm6, [rsp]
000078d941fd298d  add rsp, 0x30
000078d941fd2991  vmovaps xmm0, [rsp]
000078d941fd2996  vmovaps xmm1, [rsp+0x10]
000078d941fd299c  vmovaps xmm2, [rsp+0x20]
000078d941fd29a2  vmovaps xmm3, [rsp+0x30]
000078d941fd29a8  vmovaps xmm4, [rsp+0x40]
000078d941fd29ae  vmovaps xmm5, [rsp+0x50]
000078d941fd29b4  vmovaps xmm7, [rsp+0x60]
000078d941fd29ba  vmovaps xmm8, [rsp+0x70]
000078d941fd29c0  vmovaps xmm9, [rsp+0x80]
000078d941fd29c9  vmovaps xmm10, [rsp+0x90]
000078d941fd29d2  vmovaps xmm11, [rsp+0xA0]
000078d941fd29db  vmovaps xmm12, [rsp+0xB0]
000078d941fd29e4  vmovaps xmm13, [rsp+0xC0]
000078d941fd29ed  vmovaps xmm14, [rsp+0xD0]
000078d941fd29f6  vmovaps xmm15, [rsp+0xE0]
000078d941fd29ff  add rsp, 0xF0
000078d941fd2a06  pop r11
000078d941fd2a08  pop r10
000078d941fd2a0a  pop r9
000078d941fd2a0c  pop r8
000078d941fd2a0e  pop rsi
000078d941fd2a0f  pop rdi
000078d941fd2a10  pop rdx
000078d941fd2a11  pop rcx
000078d941fd2a12  pop rax
000078d941fd2a13  add rsp, 0x08
000078d941fd2a17  jmp 0x000078D941FCFD98
000078d941fd2a1c  sub rsp, 0x08
000078d941fd2a20  push rax
000078d941fd2a21  push rcx
000078d941fd2a22  push rdx
000078d941fd2a23  push rdi
000078d941fd2a24  push rsi
000078d941fd2a25  push r8
000078d941fd2a27  push r9
000078d941fd2a29  push r10
000078d941fd2a2b  push r11
000078d941fd2a2d  sub rsp, 0xF0
000078d941fd2a34  vmovaps [rsp], xmm0
000078d941fd2a39  vmovaps [rsp+0x10], xmm2
000078d941fd2a3f  vmovaps [rsp+0x20], xmm3
000078d941fd2a45  vmovaps [rsp+0x30], xmm4
000078d941fd2a4b  vmovaps [rsp+0x40], xmm5
000078d941fd2a51  vmovaps [rsp+0x50], xmm6
000078d941fd2a57  vmovaps [rsp+0x60], xmm7
000078d941fd2a5d  vmovaps [rsp+0x70], xmm8
000078d941fd2a63  vmovaps [rsp+0x80], xmm9
000078d941fd2a6c  vmovaps [rsp+0x90], xmm10
000078d941fd2a75  vmovaps [rsp+0xA0], xmm11
000078d941fd2a7e  vmovaps [rsp+0xB0], xmm12
000078d941fd2a87  vmovaps [rsp+0xC0], xmm13
000078d941fd2a90  vmovaps [rsp+0xD0], xmm14
000078d941fd2a99  vmovaps [rsp+0xE0], xmm15
000078d941fd2aa2  sub rsp, 0x30
000078d941fd2aa6  movaps [rsp], xmm1
000078d941fd2aaa  movaps [rsp+0x10], xmm5
000078d941fd2aaf  movaps [rsp+0x20], xmm13
000078d941fd2ab5  lea rdi, [rsp]
000078d941fd2ab9  mov esi, 0x00
000078d941fd2abe  mov rax, 0x59BFBFBAA530
000078d941fd2ac8  call rax
000078d941fd2aca  movaps xmm1, [rsp]
000078d941fd2ace  add rsp, 0x30
000078d941fd2ad2  vmovaps xmm0, [rsp]
000078d941fd2ad7  vmovaps xmm2, [rsp+0x10]
000078d941fd2add  vmovaps xmm3, [rsp+0x20]
000078d941fd2ae3  vmovaps xmm4, [rsp+0x30]
000078d941fd2ae9  vmovaps xmm5, [rsp+0x40]
000078d941fd2aef  vmovaps xmm6, [rsp+0x50]
000078d941fd2af5  vmovaps xmm7, [rsp+0x60]
000078d941fd2afb  vmovaps xmm8, [rsp+0x70]
000078d941fd2b01  vmovaps xmm9, [rsp+0x80]
000078d941fd2b0a  vmovaps xmm10, [rsp+0x90]
000078d941fd2b13  vmovaps xmm11, [rsp+0xA0]
000078d941fd2b1c  vmovaps xmm12, [rsp+0xB0]
000078d941fd2b25  vmovaps xmm13, [rsp+0xC0]
000078d941fd2b2e  vmovaps xmm14, [rsp+0xD0]
000078d941fd2b37  vmovaps xmm15, [rsp+0xE0]
000078d941fd2b40  add rsp, 0xF0
000078d941fd2b47  pop r11
000078d941fd2b49  pop r10
000078d941fd2b4b  pop r9
000078d941fd2b4d  pop r8
000078d941fd2b4f  pop rsi
000078d941fd2b50  pop rdi
000078d941fd2b51  pop rdx
000078d941fd2b52  pop rcx
000078d941fd2b53  pop rax
000078d941fd2b54  add rsp, 0x08
000078d941fd2b58  jmp 0x000078D941FCFDB6
000078d941fd2b5d  sub rsp, 0x08
000078d941fd2b61  push rax
000078d941fd2b62  push rcx
000078d941fd2b63  push rdx
000078d941fd2b64  push rdi
000078d941fd2b65  push rsi
000078d941fd2b66  push r8
000078d941fd2b68  push r9
000078d941fd2b6a  push r10
000078d941fd2b6c  push r11
000078d941fd2b6e  sub rsp, 0xF0
000078d941fd2b75  vmovaps [rsp], xmm0
000078d941fd2b7a  vmovaps [rsp+0x10], xmm1
000078d941fd2b80  vmovaps [rsp+0x20], xmm2
000078d941fd2b86  vmovaps [rsp+0x30], xmm3
000078d941fd2b8c  vmovaps [rsp+0x40], xmm4
000078d941fd2b92  vmovaps [rsp+0x50], xmm6
000078d941fd2b98  vmovaps [rsp+0x60], xmm7
000078d941fd2b9e  vmovaps [rsp+0x70], xmm8
000078d941fd2ba4  vmovaps [rsp+0x80], xmm9
000078d941fd2bad  vmovaps [rsp+0x90], xmm10
000078d941fd2bb6  vmovaps [rsp+0xA0], xmm11
000078d941fd2bbf  vmovaps [rsp+0xB0], xmm12
000078d941fd2bc8  vmovaps [rsp+0xC0], xmm13
000078d941fd2bd1  vmovaps [rsp+0xD0], xmm14
000078d941fd2bda  vmovaps [rsp+0xE0], xmm15
000078d941fd2be3  sub rsp, 0x30
000078d941fd2be7  movaps [rsp], xmm5
000078d941fd2beb  movaps [rsp+0x10], xmm2
000078d941fd2bf0  movaps [rsp+0x20], xmm13
000078d941fd2bf6  lea rdi, [rsp]
000078d941fd2bfa  mov esi, 0x00
000078d941fd2bff  mov rax, 0x59BFBFBAA530
000078d941fd2c09  call rax
000078d941fd2c0b  movaps xmm5, [rsp]
000078d941fd2c0f  add rsp, 0x30
000078d941fd2c13  vmovaps xmm0, [rsp]
000078d941fd2c18  vmovaps xmm1, [rsp+0x10]
000078d941fd2c1e  vmovaps xmm2, [rsp+0x20]
000078d941fd2c24  vmovaps xmm3, [rsp+0x30]
000078d941fd2c2a  vmovaps xmm4, [rsp+0x40]
000078d941fd2c30  vmovaps xmm6, [rsp+0x50]
000078d941fd2c36  vmovaps xmm7, [rsp+0x60]
000078d941fd2c3c  vmovaps xmm8, [rsp+0x70]
000078d941fd2c42  vmovaps xmm9, [rsp+0x80]
000078d941fd2c4b  vmovaps xmm10, [rsp+0x90]
000078d941fd2c54  vmovaps xmm11, [rsp+0xA0]
000078d941fd2c5d  vmovaps xmm12, [rsp+0xB0]
000078d941fd2c66  vmovaps xmm13, [rsp+0xC0]
000078d941fd2c6f  vmovaps xmm14, [rsp+0xD0]
000078d941fd2c78  vmovaps xmm15, [rsp+0xE0]
000078d941fd2c81  add rsp, 0xF0
000078d941fd2c88  pop r11
000078d941fd2c8a  pop r10
000078d941fd2c8c  pop r9
000078d941fd2c8e  pop r8
000078d941fd2c90  pop rsi
000078d941fd2c91  pop rdi
000078d941fd2c92  pop rdx
000078d941fd2c93  pop rcx
000078d941fd2c94  pop rax
000078d941fd2c95  add rsp, 0x08
000078d941fd2c99  jmp 0x000078D941FCFDEC
000078d941fd2c9e  sub rsp, 0x08
000078d941fd2ca2  push rax
000078d941fd2ca3  push rcx
000078d941fd2ca4  push rdx
000078d941fd2ca5  push rdi
000078d941fd2ca6  push rsi
000078d941fd2ca7  push r8
000078d941fd2ca9  push r9
000078d941fd2cab  push r10
000078d941fd2cad  push r11
000078d941fd2caf  sub rsp, 0xF0
000078d941fd2cb6  vmovaps [rsp], xmm0
000078d941fd2cbb  vmovaps [rsp+0x10], xmm1
000078d941fd2cc1  vmovaps [rsp+0x20], xmm2
000078d941fd2cc7  vmovaps [rsp+0x30], xmm3
000078d941fd2ccd  vmovaps [rsp+0x40], xmm4
000078d941fd2cd3  vmovaps [rsp+0x50], xmm5
000078d941fd2cd9  vmovaps [rsp+0x60], xmm6
000078d941fd2cdf  vmovaps [rsp+0x70], xmm7
000078d941fd2ce5  vmovaps [rsp+0x80], xmm8
000078d941fd2cee  vmovaps [rsp+0x90], xmm9
000078d941fd2cf7  vmovaps [rsp+0xA0], xmm10
000078d941fd2d00  vmovaps [rsp+0xB0], xmm11
000078d941fd2d09  vmovaps [rsp+0xC0], xmm12
000078d941fd2d12  vmovaps [rsp+0xD0], xmm14
000078d941fd2d1b  vmovaps [rsp+0xE0], xmm15
000078d941fd2d24  sub rsp, 0x30
000078d941fd2d28  movaps [rsp], xmm13
000078d941fd2d2d  movaps [rsp+0x10], xmm10
000078d941fd2d33  movaps [rsp+0x20], xmm1
000078d941fd2d38  lea rdi, [rsp]
000078d941fd2d3c  mov esi, 0x00
000078d941fd2d41  mov rax, 0x59BFBFBAA530
000078d941fd2d4b  call rax
000078d941fd2d4d  movaps xmm13, [rsp]
000078d941fd2d52  add rsp, 0x30
000078d941fd2d56  vmovaps xmm0, [rsp]
000078d941fd2d5b  vmovaps xmm1, [rsp+0x10]
000078d941fd2d61  vmovaps xmm2, [rsp+0x20]
000078d941fd2d67  vmovaps xmm3, [rsp+0x30]
000078d941fd2d6d  vmovaps xmm4, [rsp+0x40]
000078d941fd2d73  vmovaps xmm5, [rsp+0x50]
000078d941fd2d79  vmovaps xmm6, [rsp+0x60]
000078d941fd2d7f  vmovaps xmm7, [rsp+0x70]
000078d941fd2d85  vmovaps xmm8, [rsp+0x80]
000078d941fd2d8e  vmovaps xmm9, [rsp+0x90]
000078d941fd2d97  vmovaps xmm10, [rsp+0xA0]
000078d941fd2da0  vmovaps xmm11, [rsp+0xB0]
000078d941fd2da9  vmovaps xmm12, [rsp+0xC0]
000078d941fd2db2  vmovaps xmm14, [rsp+0xD0]
000078d941fd2dbb  vmovaps xmm15, [rsp+0xE0]
000078d941fd2dc4  add rsp, 0xF0
000078d941fd2dcb  pop r11
000078d941fd2dcd  pop r10
000078d941fd2dcf  pop r9
000078d941fd2dd1  pop r8
000078d941fd2dd3  pop rsi
000078d941fd2dd4  pop rdi
000078d941fd2dd5  pop rdx
000078d941fd2dd6  pop rcx
000078d941fd2dd7  pop rax
000078d941fd2dd8  add rsp, 0x08
000078d941fd2ddc  jmp 0x000078D941FCFE15
000078d941fd2de1  sub rsp, 0x08
000078d941fd2de5  push rax
000078d941fd2de6  push rcx
000078d941fd2de7  push rdx
000078d941fd2de8  push rdi
000078d941fd2de9  push rsi
000078d941fd2dea  push r8
000078d941fd2dec  push r9
000078d941fd2dee  push r10
000078d941fd2df0  push r11
000078d941fd2df2  sub rsp, 0xF0
000078d941fd2df9  vmovaps [rsp], xmm0
000078d941fd2dfe  vmovaps [rsp+0x10], xmm2
000078d941fd2e04  vmovaps [rsp+0x20], xmm3
000078d941fd2e0a  vmovaps [rsp+0x30], xmm4
000078d941fd2e10  vmovaps [rsp+0x40], xmm5
000078d941fd2e16  vmovaps [rsp+0x50], xmm6
000078d941fd2e1c  vmovaps [rsp+0x60], xmm7
000078d941fd2e22  vmovaps [rsp+0x70], xmm8
000078d941fd2e28  vmovaps [rsp+0x80], xmm9
000078d941fd2e31  vmovaps [rsp+0x90], xmm10
000078d941fd2e3a  vmovaps [rsp+0xA0], xmm11
000078d941fd2e43  vmovaps [rsp+0xB0], xmm12
000078d941fd2e4c  vmovaps [rsp+0xC0], xmm13
000078d941fd2e55  vmovaps [rsp+0xD0], xmm14
000078d941fd2e5e  vmovaps [rsp+0xE0], xmm15
000078d941fd2e67  sub rsp, 0x30
000078d941fd2e6b  movaps [rsp], xmm1
000078d941fd2e6f  movaps [rsp+0x10], xmm15
000078d941fd2e75  movaps [rsp+0x20], xmm10
000078d941fd2e7b  lea rdi, [rsp]
000078d941fd2e7f  mov esi, 0x00
000078d941fd2e84  mov rax, 0x59BFBFBAA530
000078d941fd2e8e  call rax
000078d941fd2e90  movaps xmm1, [rsp]
000078d941fd2e94  add rsp, 0x30
000078d941fd2e98  vmovaps xmm0, [rsp]
000078d941fd2e9d  vmovaps xmm2, [rsp+0x10]
000078d941fd2ea3  vmovaps xmm3, [rsp+0x20]
000078d941fd2ea9  vmovaps xmm4, [rsp+0x30]
000078d941fd2eaf  vmovaps xmm5, [rsp+0x40]
000078d941fd2eb5  vmovaps xmm6, [rsp+0x50]
000078d941fd2ebb  vmovaps xmm7, [rsp+0x60]
000078d941fd2ec1  vmovaps xmm8, [rsp+0x70]
000078d941fd2ec7  vmovaps xmm9, [rsp+0x80]
000078d941fd2ed0  vmovaps xmm10, [rsp+0x90]
000078d941fd2ed9  vmovaps xmm11, [rsp+0xA0]
000078d941fd2ee2  vmovaps xmm12, [rsp+0xB0]
000078d941fd2eeb  vmovaps xmm13, [rsp+0xC0]
000078d941fd2ef4  vmovaps xmm14, [rsp+0xD0]
000078d941fd2efd  vmovaps xmm15, [rsp+0xE0]
000078d941fd2f06  add rsp, 0xF0
000078d941fd2f0d  pop r11
000078d941fd2f0f  pop r10
000078d941fd2f11  pop r9
000078d941fd2f13  pop r8
000078d941fd2f15  pop rsi
000078d941fd2f16  pop rdi
000078d941fd2f17  pop rdx
000078d941fd2f18  pop rcx
000078d941fd2f19  pop rax
000078d941fd2f1a  add rsp, 0x08
000078d941fd2f1e  jmp 0x000078D941FCFE34
000078d941fd2f23  sub rsp, 0x08
000078d941fd2f27  push rax
000078d941fd2f28  push rcx
000078d941fd2f29  push rdx
000078d941fd2f2a  push rdi
000078d941fd2f2b  push rsi
000078d941fd2f2c  push r8
000078d941fd2f2e  push r9
000078d941fd2f30  push r10
000078d941fd2f32  push r11
000078d941fd2f34  sub rsp, 0xF0
000078d941fd2f3b  vmovaps [rsp], xmm0
000078d941fd2f40  vmovaps [rsp+0x10], xmm1
000078d941fd2f46  vmovaps [rsp+0x20], xmm2
000078d941fd2f4c  vmovaps [rsp+0x30], xmm3
000078d941fd2f52  vmovaps [rsp+0x40], xmm4
000078d941fd2f58  vmovaps [rsp+0x50], xmm5
000078d941fd2f5e  vmovaps [rsp+0x60], xmm6
000078d941fd2f64  vmovaps [rsp+0x70], xmm7
000078d941fd2f6a  vmovaps [rsp+0x80], xmm8
000078d941fd2f73  vmovaps [rsp+0x90], xmm9
000078d941fd2f7c  vmovaps [rsp+0xA0], xmm10
000078d941fd2f85  vmovaps [rsp+0xB0], xmm11
000078d941fd2f8e  vmovaps [rsp+0xC0], xmm12
000078d941fd2f97  vmovaps [rsp+0xD0], xmm13
000078d941fd2fa0  vmovaps [rsp+0xE0], xmm14
000078d941fd2fa9  sub rsp, 0x30
000078d941fd2fad  movaps [rsp], xmm15
000078d941fd2fb2  movaps [rsp+0x10], xmm10
000078d941fd2fb8  movaps [rsp+0x20], xmm11
000078d941fd2fbe  lea rdi, [rsp]
000078d941fd2fc2  mov esi, 0x00
000078d941fd2fc7  mov rax, 0x59BFBFBAA530
000078d941fd2fd1  call rax
000078d941fd2fd3  movaps xmm15, [rsp]
000078d941fd2fd8  add rsp, 0x30
000078d941fd2fdc  vmovaps xmm0, [rsp]
000078d941fd2fe1  vmovaps xmm1, [rsp+0x10]
000078d941fd2fe7  vmovaps xmm2, [rsp+0x20]
000078d941fd2fed  vmovaps xmm3, [rsp+0x30]
000078d941fd2ff3  vmovaps xmm4, [rsp+0x40]
000078d941fd2ff9  vmovaps xmm5, [rsp+0x50]
000078d941fd2fff  vmovaps xmm6, [rsp+0x60]
000078d941fd3005  vmovaps xmm7, [rsp+0x70]
000078d941fd300b  vmovaps xmm8, [rsp+0x80]
000078d941fd3014  vmovaps xmm9, [rsp+0x90]
000078d941fd301d  vmovaps xmm10, [rsp+0xA0]
000078d941fd3026  vmovaps xmm11, [rsp+0xB0]
000078d941fd302f  vmovaps xmm12, [rsp+0xC0]
000078d941fd3038  vmovaps xmm13, [rsp+0xD0]
000078d941fd3041  vmovaps xmm14, [rsp+0xE0]
000078d941fd304a  add rsp, 0xF0
000078d941fd3051  pop r11
000078d941fd3053  pop r10
000078d941fd3055  pop r9
000078d941fd3057  pop r8
000078d941fd3059  pop rsi
000078d941fd305a  pop rdi
000078d941fd305b  pop rdx
000078d941fd305c  pop rcx
000078d941fd305d  pop rax
000078d941fd305e  add rsp, 0x08
000078d941fd3062  jmp 0x000078D941FCFE57
000078d941fd3067  sub rsp, 0x08
000078d941fd306b  push rax
000078d941fd306c  push rcx
000078d941fd306d  push rdx
000078d941fd306e  push rdi
000078d941fd306f  push rsi
000078d941fd3070  push r8
000078d941fd3072  push r9
000078d941fd3074  push r10
000078d941fd3076  push r11
000078d941fd3078  sub rsp, 0xF0
000078d941fd307f  vmovaps [rsp], xmm0
000078d941fd3084  vmovaps [rsp+0x10], xmm1
000078d941fd308a  vmovaps [rsp+0x20], xmm2
000078d941fd3090  vmovaps [rsp+0x30], xmm3
000078d941fd3096  vmovaps [rsp+0x40], xmm4
000078d941fd309c  vmovaps [rsp+0x50], xmm5
000078d941fd30a2  vmovaps [rsp+0x60], xmm6
000078d941fd30a8  vmovaps [rsp+0x70], xmm7
000078d941fd30ae  vmovaps [rsp+0x80], xmm8
000078d941fd30b7  vmovaps [rsp+0x90], xmm9
000078d941fd30c0  vmovaps [rsp+0xA0], xmm11
000078d941fd30c9  vmovaps [rsp+0xB0], xmm12
000078d941fd30d2  vmovaps [rsp+0xC0], xmm13
000078d941fd30db  vmovaps [rsp+0xD0], xmm14
000078d941fd30e4  vmovaps [rsp+0xE0], xmm15
000078d941fd30ed  sub rsp, 0x30
000078d941fd30f1  movaps [rsp], xmm10
000078d941fd30f6  movaps [rsp+0x10], xmm12
000078d941fd30fc  movaps [rsp+0x20], xmm11
000078d941fd3102  lea rdi, [rsp]
000078d941fd3106  mov esi, 0x00
000078d941fd310b  mov rax, 0x59BFBFBAA530
000078d941fd3115  call rax
000078d941fd3117  movaps xmm10, [rsp]
000078d941fd311c  add rsp, 0x30
000078d941fd3120  vmovaps xmm0, [rsp]
000078d941fd3125  vmovaps xmm1, [rsp+0x10]
000078d941fd312b  vmovaps xmm2, [rsp+0x20]
000078d941fd3131  vmovaps xmm3, [rsp+0x30]
000078d941fd3137  vmovaps xmm4, [rsp+0x40]
000078d941fd313d  vmovaps xmm5, [rsp+0x50]
000078d941fd3143  vmovaps xmm6, [rsp+0x60]
000078d941fd3149  vmovaps xmm7, [rsp+0x70]
000078d941fd314f  vmovaps xmm8, [rsp+0x80]
000078d941fd3158  vmovaps xmm9, [rsp+0x90]
000078d941fd3161  vmovaps xmm11, [rsp+0xA0]
000078d941fd316a  vmovaps xmm12, [rsp+0xB0]
000078d941fd3173  vmovaps xmm13, [rsp+0xC0]
000078d941fd317c  vmovaps xmm14, [rsp+0xD0]
000078d941fd3185  vmovaps xmm15, [rsp+0xE0]
000078d941fd318e  add rsp, 0xF0
000078d941fd3195  pop r11
000078d941fd3197  pop r10
000078d941fd3199  pop r9
000078d941fd319b  pop r8
000078d941fd319d  pop rsi
000078d941fd319e  pop rdi
000078d941fd319f  pop rdx
000078d941fd31a0  pop rcx
000078d941fd31a1  pop rax
000078d941fd31a2  add rsp, 0x08
000078d941fd31a6  jmp 0x000078D941FCFE80
000078d941fd31ab  sub rsp, 0x08
000078d941fd31af  push rax
000078d941fd31b0  push rcx
000078d941fd31b1  push rdx
000078d941fd31b2  push rdi
000078d941fd31b3  push rsi
000078d941fd31b4  push r8
000078d941fd31b6  push r9
000078d941fd31b8  push r10
000078d941fd31ba  push r11
000078d941fd31bc  sub rsp, 0xF0
000078d941fd31c3  vmovaps [rsp], xmm0
000078d941fd31c8  vmovaps [rsp+0x10], xmm1
000078d941fd31ce  vmovaps [rsp+0x20], xmm2
000078d941fd31d4  vmovaps [rsp+0x30], xmm3
000078d941fd31da  vmovaps [rsp+0x40], xmm4
000078d941fd31e0  vmovaps [rsp+0x50], xmm5
000078d941fd31e6  vmovaps [rsp+0x60], xmm6
000078d941fd31ec  vmovaps [rsp+0x70], xmm7
000078d941fd31f2  vmovaps [rsp+0x80], xmm8
000078d941fd31fb  vmovaps [rsp+0x90], xmm9
000078d941fd3204  vmovaps [rsp+0xA0], xmm10
000078d941fd320d  vmovaps [rsp+0xB0], xmm12
000078d941fd3216  vmovaps [rsp+0xC0], xmm13
000078d941fd321f  vmovaps [rsp+0xD0], xmm14
000078d941fd3228  vmovaps [rsp+0xE0], xmm15
000078d941fd3231  sub rsp, 0x30
000078d941fd3235  movaps [rsp], xmm11
000078d941fd323a  movaps [rsp+0x10], xmm2
000078d941fd323f  movaps [rsp+0x20], xmm12
000078d941fd3245  lea rdi, [rsp]
000078d941fd3249  mov esi, 0x00
000078d941fd324e  mov rax, 0x59BFBFBAA530
000078d941fd3258  call rax
000078d941fd325a  movaps xmm11, [rsp]
000078d941fd325f  add rsp, 0x30
000078d941fd3263  vmovaps xmm0, [rsp]
000078d941fd3268  vmovaps xmm1, [rsp+0x10]
000078d941fd326e  vmovaps xmm2, [rsp+0x20]
000078d941fd3274  vmovaps xmm3, [rsp+0x30]
000078d941fd327a  vmovaps xmm4, [rsp+0x40]
000078d941fd3280  vmovaps xmm5, [rsp+0x50]
000078d941fd3286  vmovaps xmm6, [rsp+0x60]
000078d941fd328c  vmovaps xmm7, [rsp+0x70]
000078d941fd3292  vmovaps xmm8, [rsp+0x80]
000078d941fd329b  vmovaps xmm9, [rsp+0x90]
000078d941fd32a4  vmovaps xmm10, [rsp+0xA0]
000078d941fd32ad  vmovaps xmm12, [rsp+0xB0]
000078d941fd32b6  vmovaps xmm13, [rsp+0xC0]
000078d941fd32bf  vmovaps xmm14, [rsp+0xD0]
000078d941fd32c8  vmovaps xmm15, [rsp+0xE0]
000078d941fd32d1  add rsp, 0xF0
000078d941fd32d8  pop r11
000078d941fd32da  pop r10
000078d941fd32dc  pop r9
000078d941fd32de  pop r8
000078d941fd32e0  pop rsi
000078d941fd32e1  pop rdi
000078d941fd32e2  pop rdx
000078d941fd32e3  pop rcx
000078d941fd32e4  pop rax
000078d941fd32e5  add rsp, 0x08
000078d941fd32e9  jmp 0x000078D941FCFEB8
000078d941fd32ee  sub rsp, 0x08
000078d941fd32f2  push rax
000078d941fd32f3  push rcx
000078d941fd32f4  push rdx
000078d941fd32f5  push rdi
000078d941fd32f6  push rsi
000078d941fd32f7  push r8
000078d941fd32f9  push r9
000078d941fd32fb  push r10
000078d941fd32fd  push r11
000078d941fd32ff  sub rsp, 0xF0
000078d941fd3306  vmovaps [rsp], xmm0
000078d941fd330b  vmovaps [rsp+0x10], xmm2
000078d941fd3311  vmovaps [rsp+0x20], xmm3
000078d941fd3317  vmovaps [rsp+0x30], xmm4
000078d941fd331d  vmovaps [rsp+0x40], xmm5
000078d941fd3323  vmovaps [rsp+0x50], xmm6
000078d941fd3329  vmovaps [rsp+0x60], xmm7
000078d941fd332f  vmovaps [rsp+0x70], xmm8
000078d941fd3335  vmovaps [rsp+0x80], xmm9
000078d941fd333e  vmovaps [rsp+0x90], xmm10
000078d941fd3347  vmovaps [rsp+0xA0], xmm11
000078d941fd3350  vmovaps [rsp+0xB0], xmm12
000078d941fd3359  vmovaps [rsp+0xC0], xmm13
000078d941fd3362  vmovaps [rsp+0xD0], xmm14
000078d941fd336b  vmovaps [rsp+0xE0], xmm15
000078d941fd3374  sub rsp, 0x30
000078d941fd3378  movaps [rsp], xmm1
000078d941fd337c  movaps [rsp+0x10], xmm14
000078d941fd3382  movaps [rsp+0x20], xmm6
000078d941fd3387  lea rdi, [rsp]
000078d941fd338b  mov esi, 0x00
000078d941fd3390  mov rax, 0x59BFBFBAA530
000078d941fd339a  call rax
000078d941fd339c  movaps xmm1, [rsp]
000078d941fd33a0  add rsp, 0x30
000078d941fd33a4  vmovaps xmm0, [rsp]
000078d941fd33a9  vmovaps xmm2, [rsp+0x10]
000078d941fd33af  vmovaps xmm3, [rsp+0x20]
000078d941fd33b5  vmovaps xmm4, [rsp+0x30]
000078d941fd33bb  vmovaps xmm5, [rsp+0x40]
000078d941fd33c1  vmovaps xmm6, [rsp+0x50]
000078d941fd33c7  vmovaps xmm7, [rsp+0x60]
000078d941fd33cd  vmovaps xmm8, [rsp+0x70]
000078d941fd33d3  vmovaps xmm9, [rsp+0x80]
000078d941fd33dc  vmovaps xmm10, [rsp+0x90]
000078d941fd33e5  vmovaps xmm11, [rsp+0xA0]
000078d941fd33ee  vmovaps xmm12, [rsp+0xB0]
000078d941fd33f7  vmovaps xmm13, [rsp+0xC0]
000078d941fd3400  vmovaps xmm14, [rsp+0xD0]
000078d941fd3409  vmovaps xmm15, [rsp+0xE0]
000078d941fd3412  add rsp, 0xF0
000078d941fd3419  pop r11
000078d941fd341b  pop r10
000078d941fd341d  pop r9
000078d941fd341f  pop r8
000078d941fd3421  pop rsi
000078d941fd3422  pop rdi
000078d941fd3423  pop rdx
000078d941fd3424  pop rcx
000078d941fd3425  pop rax
000078d941fd3426  add rsp, 0x08
000078d941fd342a  jmp 0x000078D941FCFED1
000078d941fd342f  sub rsp, 0x08
000078d941fd3433  push rax
000078d941fd3434  push rcx
000078d941fd3435  push rdx
000078d941fd3436  push rdi
000078d941fd3437  push rsi
000078d941fd3438  push r8
000078d941fd343a  push r9
000078d941fd343c  push r10
000078d941fd343e  push r11
000078d941fd3440  sub rsp, 0xF0
000078d941fd3447  vmovaps [rsp], xmm0
000078d941fd344c  vmovaps [rsp+0x10], xmm1
000078d941fd3452  vmovaps [rsp+0x20], xmm2
000078d941fd3458  vmovaps [rsp+0x30], xmm3
000078d941fd345e  vmovaps [rsp+0x40], xmm4
000078d941fd3464  vmovaps [rsp+0x50], xmm5
000078d941fd346a  vmovaps [rsp+0x60], xmm6
000078d941fd3470  vmovaps [rsp+0x70], xmm7
000078d941fd3476  vmovaps [rsp+0x80], xmm8
000078d941fd347f  vmovaps [rsp+0x90], xmm9
000078d941fd3488  vmovaps [rsp+0xA0], xmm10
000078d941fd3491  vmovaps [rsp+0xB0], xmm11
000078d941fd349a  vmovaps [rsp+0xC0], xmm12
000078d941fd34a3  vmovaps [rsp+0xD0], xmm13
000078d941fd34ac  vmovaps [rsp+0xE0], xmm15
000078d941fd34b5  sub rsp, 0x30
000078d941fd34b9  movaps [rsp], xmm14
000078d941fd34be  movaps [rsp+0x10], xmm12
000078d941fd34c4  movaps [rsp+0x20], xmm5
000078d941fd34c9  lea rdi, [rsp]
000078d941fd34cd  mov esi, 0x00
000078d941fd34d2  mov rax, 0x59BFBFBAA530
000078d941fd34dc  call rax
000078d941fd34de  movaps xmm14, [rsp]
000078d941fd34e3  add rsp, 0x30
000078d941fd34e7  vmovaps xmm0, [rsp]
000078d941fd34ec  vmovaps xmm1, [rsp+0x10]
000078d941fd34f2  vmovaps xmm2, [rsp+0x20]
000078d941fd34f8  vmovaps xmm3, [rsp+0x30]
000078d941fd34fe  vmovaps xmm4, [rsp+0x40]
000078d941fd3504  vmovaps xmm5, [rsp+0x50]
000078d941fd350a  vmovaps xmm6, [rsp+0x60]
000078d941fd3510  vmovaps xmm7, [rsp+0x70]
000078d941fd3516  vmovaps xmm8, [rsp+0x80]
000078d941fd351f  vmovaps xmm9, [rsp+0x90]
000078d941fd3528  vmovaps xmm10, [rsp+0xA0]
000078d941fd3531  vmovaps xmm11, [rsp+0xB0]
000078d941fd353a  vmovaps xmm12, [rsp+0xC0]
000078d941fd3543  vmovaps xmm13, [rsp+0xD0]
000078d941fd354c  vmovaps xmm15, [rsp+0xE0]
000078d941fd3555  add rsp, 0xF0
000078d941fd355c  pop r11
000078d941fd355e  pop r10
000078d941fd3560  pop r9
000078d941fd3562  pop r8
000078d941fd3564  pop rsi
000078d941fd3565  pop rdi
000078d941fd3566  pop rdx
000078d941fd3567  pop rcx
000078d941fd3568  pop rax
000078d941fd3569  add rsp, 0x08
000078d941fd356d  jmp 0x000078D941FCFEF1
000078d941fd3572  sub rsp, 0x08
000078d941fd3576  push rax
000078d941fd3577  push rcx
000078d941fd3578  push rdx
000078d941fd3579  push rdi
000078d941fd357a  push rsi
000078d941fd357b  push r8
000078d941fd357d  push r9
000078d941fd357f  push r10
000078d941fd3581  push r11
000078d941fd3583  sub rsp, 0xF0
000078d941fd358a  vmovaps [rsp], xmm0
000078d941fd358f  vmovaps [rsp+0x10], xmm1
000078d941fd3595  vmovaps [rsp+0x20], xmm2
000078d941fd359b  vmovaps [rsp+0x30], xmm3
000078d941fd35a1  vmovaps [rsp+0x40], xmm4
000078d941fd35a7  vmovaps [rsp+0x50], xmm5
000078d941fd35ad  vmovaps [rsp+0x60], xmm7
000078d941fd35b3  vmovaps [rsp+0x70], xmm8
000078d941fd35b9  vmovaps [rsp+0x80], xmm9
000078d941fd35c2  vmovaps [rsp+0x90], xmm10
000078d941fd35cb  vmovaps [rsp+0xA0], xmm11
000078d941fd35d4  vmovaps [rsp+0xB0], xmm12
000078d941fd35dd  vmovaps [rsp+0xC0], xmm13
000078d941fd35e6  vmovaps [rsp+0xD0], xmm14
000078d941fd35ef  vmovaps [rsp+0xE0], xmm15
000078d941fd35f8  sub rsp, 0x30
000078d941fd35fc  movaps [rsp], xmm6
000078d941fd3600  movaps [rsp+0x10], xmm9
000078d941fd3606  movaps [rsp+0x20], xmm12
000078d941fd360c  lea rdi, [rsp]
000078d941fd3610  mov esi, 0x00
000078d941fd3615  mov rax, 0x59BFBFBAA530
000078d941fd361f  call rax
000078d941fd3621  movaps xmm6, [rsp]
000078d941fd3625  add rsp, 0x30
000078d941fd3629  vmovaps xmm0, [rsp]
000078d941fd362e  vmovaps xmm1, [rsp+0x10]
000078d941fd3634  vmovaps xmm2, [rsp+0x20]
000078d941fd363a  vmovaps xmm3, [rsp+0x30]
000078d941fd3640  vmovaps xmm4, [rsp+0x40]
000078d941fd3646  vmovaps xmm5, [rsp+0x50]
000078d941fd364c  vmovaps xmm7, [rsp+0x60]
000078d941fd3652  vmovaps xmm8, [rsp+0x70]
000078d941fd3658  vmovaps xmm9, [rsp+0x80]
000078d941fd3661  vmovaps xmm10, [rsp+0x90]
000078d941fd366a  vmovaps xmm11, [rsp+0xA0]
000078d941fd3673  vmovaps xmm12, [rsp+0xB0]
000078d941fd367c  vmovaps xmm13, [rsp+0xC0]
000078d941fd3685  vmovaps xmm14, [rsp+0xD0]
000078d941fd368e  vmovaps xmm15, [rsp+0xE0]
000078d941fd3697  add rsp, 0xF0
000078d941fd369e  pop r11
000078d941fd36a0  pop r10
000078d941fd36a2  pop r9
000078d941fd36a4  pop r8
000078d941fd36a6  pop rsi
000078d941fd36a7  pop rdi
000078d941fd36a8  pop rdx
000078d941fd36a9  pop rcx
000078d941fd36aa  pop rax
000078d941fd36ab  add rsp, 0x08
000078d941fd36af  jmp 0x000078D941FCFF19
000078d941fd36b4  sub rsp, 0x08
000078d941fd36b8  push rax
000078d941fd36b9  push rcx
000078d941fd36ba  push rdx
000078d941fd36bb  push rdi
000078d941fd36bc  push rsi
000078d941fd36bd  push r8
000078d941fd36bf  push r9
000078d941fd36c1  push r10
000078d941fd36c3  push r11
000078d941fd36c5  sub rsp, 0xF0
000078d941fd36cc  vmovaps [rsp], xmm0
000078d941fd36d1  vmovaps [rsp+0x10], xmm1
000078d941fd36d7  vmovaps [rsp+0x20], xmm2
000078d941fd36dd  vmovaps [rsp+0x30], xmm3
000078d941fd36e3  vmovaps [rsp+0x40], xmm4
000078d941fd36e9  vmovaps [rsp+0x50], xmm5
000078d941fd36ef  vmovaps [rsp+0x60], xmm6
000078d941fd36f5  vmovaps [rsp+0x70], xmm7
000078d941fd36fb  vmovaps [rsp+0x80], xmm8
000078d941fd3704  vmovaps [rsp+0x90], xmm9
000078d941fd370d  vmovaps [rsp+0xA0], xmm10
000078d941fd3716  vmovaps [rsp+0xB0], xmm11
000078d941fd371f  vmovaps [rsp+0xC0], xmm13
000078d941fd3728  vmovaps [rsp+0xD0], xmm14
000078d941fd3731  vmovaps [rsp+0xE0], xmm15
000078d941fd373a  sub rsp, 0x30
000078d941fd373e  movaps [rsp], xmm12
000078d941fd3743  movaps [rsp+0x10], xmm15
000078d941fd3749  movaps [rsp+0x20], xmm13
000078d941fd374f  lea rdi, [rsp]
000078d941fd3753  mov esi, 0x00
000078d941fd3758  mov rax, 0x59BFBFBAA530
000078d941fd3762  call rax
000078d941fd3764  movaps xmm12, [rsp]
000078d941fd3769  add rsp, 0x30
000078d941fd376d  vmovaps xmm0, [rsp]
000078d941fd3772  vmovaps xmm1, [rsp+0x10]
000078d941fd3778  vmovaps xmm2, [rsp+0x20]
000078d941fd377e  vmovaps xmm3, [rsp+0x30]
000078d941fd3784  vmovaps xmm4, [rsp+0x40]
000078d941fd378a  vmovaps xmm5, [rsp+0x50]
000078d941fd3790  vmovaps xmm6, [rsp+0x60]
000078d941fd3796  vmovaps xmm7, [rsp+0x70]
000078d941fd379c  vmovaps xmm8, [rsp+0x80]
000078d941fd37a5  vmovaps xmm9, [rsp+0x90]
000078d941fd37ae  vmovaps xmm10, [rsp+0xA0]
000078d941fd37b7  vmovaps xmm11, [rsp+0xB0]
000078d941fd37c0  vmovaps xmm13, [rsp+0xC0]
000078d941fd37c9  vmovaps xmm14, [rsp+0xD0]
000078d941fd37d2  vmovaps xmm15, [rsp+0xE0]
000078d941fd37db  add rsp, 0xF0
000078d941fd37e2  pop r11
000078d941fd37e4  pop r10
000078d941fd37e6  pop r9
000078d941fd37e8  pop r8
000078d941fd37ea  pop rsi
000078d941fd37eb  pop rdi
000078d941fd37ec  pop rdx
000078d941fd37ed  pop rcx
000078d941fd37ee  pop rax
000078d941fd37ef  add rsp, 0x08
000078d941fd37f3  jmp 0x000078D941FCFF34
000078d941fd37f8  sub rsp, 0x08
000078d941fd37fc  push rax
000078d941fd37fd  push rcx
000078d941fd37fe  push rdx
000078d941fd37ff  push rdi
000078d941fd3800  push rsi
000078d941fd3801  push r8
000078d941fd3803  push r9
000078d941fd3805  push r10
000078d941fd3807  push r11
000078d941fd3809  sub rsp, 0xF0
000078d941fd3810  vmovaps [rsp], xmm0
000078d941fd3815  vmovaps [rsp+0x10], xmm1
000078d941fd381b  vmovaps [rsp+0x20], xmm2
000078d941fd3821  vmovaps [rsp+0x30], xmm3
000078d941fd3827  vmovaps [rsp+0x40], xmm4
000078d941fd382d  vmovaps [rsp+0x50], xmm5
000078d941fd3833  vmovaps [rsp+0x60], xmm6
000078d941fd3839  vmovaps [rsp+0x70], xmm7
000078d941fd383f  vmovaps [rsp+0x80], xmm8
000078d941fd3848  vmovaps [rsp+0x90], xmm9
000078d941fd3851  vmovaps [rsp+0xA0], xmm10
000078d941fd385a  vmovaps [rsp+0xB0], xmm11
000078d941fd3863  vmovaps [rsp+0xC0], xmm12
000078d941fd386c  vmovaps [rsp+0xD0], xmm13
000078d941fd3875  vmovaps [rsp+0xE0], xmm14
000078d941fd387e  sub rsp, 0x30
000078d941fd3882  movaps [rsp], xmm15
000078d941fd3887  movaps [rsp+0x10], xmm13
000078d941fd388d  movaps [rsp+0x20], xmm10
000078d941fd3893  lea rdi, [rsp]
000078d941fd3897  mov esi, 0x00
000078d941fd389c  mov rax, 0x59BFBFBAA530
000078d941fd38a6  call rax
000078d941fd38a8  movaps xmm15, [rsp]
000078d941fd38ad  add rsp, 0x30
000078d941fd38b1  vmovaps xmm0, [rsp]
000078d941fd38b6  vmovaps xmm1, [rsp+0x10]
000078d941fd38bc  vmovaps xmm2, [rsp+0x20]
000078d941fd38c2  vmovaps xmm3, [rsp+0x30]
000078d941fd38c8  vmovaps xmm4, [rsp+0x40]
000078d941fd38ce  vmovaps xmm5, [rsp+0x50]
000078d941fd38d4  vmovaps xmm6, [rsp+0x60]
000078d941fd38da  vmovaps xmm7, [rsp+0x70]
000078d941fd38e0  vmovaps xmm8, [rsp+0x80]
000078d941fd38e9  vmovaps xmm9, [rsp+0x90]
000078d941fd38f2  vmovaps xmm10, [rsp+0xA0]
000078d941fd38fb  vmovaps xmm11, [rsp+0xB0]
000078d941fd3904  vmovaps xmm12, [rsp+0xC0]
000078d941fd390d  vmovaps xmm13, [rsp+0xD0]
000078d941fd3916  vmovaps xmm14, [rsp+0xE0]
000078d941fd391f  add rsp, 0xF0
000078d941fd3926  pop r11
000078d941fd3928  pop r10
000078d941fd392a  pop r9
000078d941fd392c  pop r8
000078d941fd392e  pop rsi
000078d941fd392f  pop rdi
000078d941fd3930  pop rdx
000078d941fd3931  pop rcx
000078d941fd3932  pop rax
000078d941fd3933  add rsp, 0x08
000078d941fd3937  jmp 0x000078D941FCFF55
000078d941fd393c  call 0x000078D941E0C260
000078d941fd3941  jmp 0x000078D941FCFFB0
000078d941fd3946  sub rsp, 0x08
000078d941fd394a  push rax
000078d941fd394b  push rcx
000078d941fd394c  push rdx
000078d941fd394d  push rdi
000078d941fd394e  push rsi
000078d941fd394f  push r8
000078d941fd3951  push r9
000078d941fd3953  push r10
000078d941fd3955  push r11
000078d941fd3957  sub rsp, 0xF0
000078d941fd395e  vmovaps [rsp], xmm0
000078d941fd3963  vmovaps [rsp+0x10], xmm1
000078d941fd3969  vmovaps [rsp+0x20], xmm2
000078d941fd396f  vmovaps [rsp+0x30], xmm3
000078d941fd3975  vmovaps [rsp+0x40], xmm4
000078d941fd397b  vmovaps [rsp+0x50], xmm5
000078d941fd3981  vmovaps [rsp+0x60], xmm6
000078d941fd3987  vmovaps [rsp+0x70], xmm7
000078d941fd398d  vmovaps [rsp+0x80], xmm8
000078d941fd3996  vmovaps [rsp+0x90], xmm10
000078d941fd399f  vmovaps [rsp+0xA0], xmm11
000078d941fd39a8  vmovaps [rsp+0xB0], xmm12
000078d941fd39b1  vmovaps [rsp+0xC0], xmm13
000078d941fd39ba  vmovaps [rsp+0xD0], xmm14
000078d941fd39c3  vmovaps [rsp+0xE0], xmm15
000078d941fd39cc  sub rsp, 0x30
000078d941fd39d0  movaps [rsp], xmm9
000078d941fd39d5  movaps [rsp+0x10], xmm8
000078d941fd39db  movaps [rsp+0x20], xmm10
000078d941fd39e1  lea rdi, [rsp]
000078d941fd39e5  mov esi, 0x00
000078d941fd39ea  mov rax, 0x59BFBFBAA530
000078d941fd39f4  call rax
000078d941fd39f6  movaps xmm9, [rsp]
000078d941fd39fb  add rsp, 0x30
000078d941fd39ff  vmovaps xmm0, [rsp]
000078d941fd3a04  vmovaps xmm1, [rsp+0x10]
000078d941fd3a0a  vmovaps xmm2, [rsp+0x20]
000078d941fd3a10  vmovaps xmm3, [rsp+0x30]
000078d941fd3a16  vmovaps xmm4, [rsp+0x40]
000078d941fd3a1c  vmovaps xmm5, [rsp+0x50]
000078d941fd3a22  vmovaps xmm6, [rsp+0x60]
000078d941fd3a28  vmovaps xmm7, [rsp+0x70]
000078d941fd3a2e  vmovaps xmm8, [rsp+0x80]
000078d941fd3a37  vmovaps xmm10, [rsp+0x90]
000078d941fd3a40  vmovaps xmm11, [rsp+0xA0]
000078d941fd3a49  vmovaps xmm12, [rsp+0xB0]
000078d941fd3a52  vmovaps xmm13, [rsp+0xC0]
000078d941fd3a5b  vmovaps xmm14, [rsp+0xD0]
000078d941fd3a64  vmovaps xmm15, [rsp+0xE0]
000078d941fd3a6d  add rsp, 0xF0
000078d941fd3a74  pop r11
000078d941fd3a76  pop r10
000078d941fd3a78  pop r9
000078d941fd3a7a  pop r8
000078d941fd3a7c  pop rsi
000078d941fd3a7d  pop rdi
000078d941fd3a7e  pop rdx
000078d941fd3a7f  pop rcx
000078d941fd3a80  pop rax
000078d941fd3a81  add rsp, 0x08
000078d941fd3a85  jmp 0x000078D941FCFFE1
000078d941fd3a8a  sub rsp, 0x08
000078d941fd3a8e  push rax
000078d941fd3a8f  push rcx
000078d941fd3a90  push rdx
000078d941fd3a91  push rdi
000078d941fd3a92  push rsi
000078d941fd3a93  push r8
000078d941fd3a95  push r9
000078d941fd3a97  push r10
000078d941fd3a99  push r11
000078d941fd3a9b  sub rsp, 0xF0
000078d941fd3aa2  vmovaps [rsp], xmm0
000078d941fd3aa7  vmovaps [rsp+0x10], xmm1
000078d941fd3aad  vmovaps [rsp+0x20], xmm2
000078d941fd3ab3  vmovaps [rsp+0x30], xmm3
000078d941fd3ab9  vmovaps [rsp+0x40], xmm4
000078d941fd3abf  vmovaps [rsp+0x50], xmm5
000078d941fd3ac5  vmovaps [rsp+0x60], xmm6
000078d941fd3acb  vmovaps [rsp+0x70], xmm7
000078d941fd3ad1  vmovaps [rsp+0x80], xmm8
000078d941fd3ada  vmovaps [rsp+0x90], xmm9
000078d941fd3ae3  vmovaps [rsp+0xA0], xmm11
000078d941fd3aec  vmovaps [rsp+0xB0], xmm12
000078d941fd3af5  vmovaps [rsp+0xC0], xmm13
000078d941fd3afe  vmovaps [rsp+0xD0], xmm14
000078d941fd3b07  vmovaps [rsp+0xE0], xmm15
000078d941fd3b10  sub rsp, 0x30
000078d941fd3b14  movaps [rsp], xmm10
000078d941fd3b19  movaps [rsp+0x10], xmm1
000078d941fd3b1e  movaps [rsp+0x20], xmm11
000078d941fd3b24  lea rdi, [rsp]
000078d941fd3b28  mov esi, 0x00
000078d941fd3b2d  mov rax, 0x59BFBFBAA530
000078d941fd3b37  call rax
000078d941fd3b39  movaps xmm10, [rsp]
000078d941fd3b3e  add rsp, 0x30
000078d941fd3b42  vmovaps xmm0, [rsp]
000078d941fd3b47  vmovaps xmm1, [rsp+0x10]
000078d941fd3b4d  vmovaps xmm2, [rsp+0x20]
000078d941fd3b53  vmovaps xmm3, [rsp+0x30]
000078d941fd3b59  vmovaps xmm4, [rsp+0x40]
000078d941fd3b5f  vmovaps xmm5, [rsp+0x50]
000078d941fd3b65  vmovaps xmm6, [rsp+0x60]
000078d941fd3b6b  vmovaps xmm7, [rsp+0x70]
000078d941fd3b71  vmovaps xmm8, [rsp+0x80]
000078d941fd3b7a  vmovaps xmm9, [rsp+0x90]
000078d941fd3b83  vmovaps xmm11, [rsp+0xA0]
000078d941fd3b8c  vmovaps xmm12, [rsp+0xB0]
000078d941fd3b95  vmovaps xmm13, [rsp+0xC0]
000078d941fd3b9e  vmovaps xmm14, [rsp+0xD0]
000078d941fd3ba7  vmovaps xmm15, [rsp+0xE0]
000078d941fd3bb0  add rsp, 0xF0
000078d941fd3bb7  pop r11
000078d941fd3bb9  pop r10
000078d941fd3bbb  pop r9
000078d941fd3bbd  pop r8
000078d941fd3bbf  pop rsi
000078d941fd3bc0  pop rdi
000078d941fd3bc1  pop rdx
000078d941fd3bc2  pop rcx
000078d941fd3bc3  pop rax
000078d941fd3bc4  add rsp, 0x08
000078d941fd3bc8  jmp 0x000078D941FCFFFC
000078d941fd3bcd  sub rsp, 0x08
000078d941fd3bd1  push rax
000078d941fd3bd2  push rcx
000078d941fd3bd3  push rdx
000078d941fd3bd4  push rdi
000078d941fd3bd5  push rsi
000078d941fd3bd6  push r8
000078d941fd3bd8  push r9
000078d941fd3bda  push r10
000078d941fd3bdc  push r11
000078d941fd3bde  sub rsp, 0xF0
000078d941fd3be5  vmovaps [rsp], xmm0
000078d941fd3bea  vmovaps [rsp+0x10], xmm2
000078d941fd3bf0  vmovaps [rsp+0x20], xmm3
000078d941fd3bf6  vmovaps [rsp+0x30], xmm4
000078d941fd3bfc  vmovaps [rsp+0x40], xmm5
000078d941fd3c02  vmovaps [rsp+0x50], xmm6
000078d941fd3c08  vmovaps [rsp+0x60], xmm7
000078d941fd3c0e  vmovaps [rsp+0x70], xmm8
000078d941fd3c14  vmovaps [rsp+0x80], xmm9
000078d941fd3c1d  vmovaps [rsp+0x90], xmm10
000078d941fd3c26  vmovaps [rsp+0xA0], xmm11
000078d941fd3c2f  vmovaps [rsp+0xB0], xmm12
000078d941fd3c38  vmovaps [rsp+0xC0], xmm13
000078d941fd3c41  vmovaps [rsp+0xD0], xmm14
000078d941fd3c4a  vmovaps [rsp+0xE0], xmm15
000078d941fd3c53  sub rsp, 0x30
000078d941fd3c57  movaps [rsp], xmm1
000078d941fd3c5b  movaps [rsp+0x10], xmm14
000078d941fd3c61  movaps [rsp+0x20], xmm6
000078d941fd3c66  lea rdi, [rsp]
000078d941fd3c6a  mov esi, 0x00
000078d941fd3c6f  mov rax, 0x59BFBFBAA530
000078d941fd3c79  call rax
000078d941fd3c7b  movaps xmm1, [rsp]
000078d941fd3c7f  add rsp, 0x30
000078d941fd3c83  vmovaps xmm0, [rsp]
000078d941fd3c88  vmovaps xmm2, [rsp+0x10]
000078d941fd3c8e  vmovaps xmm3, [rsp+0x20]
000078d941fd3c94  vmovaps xmm4, [rsp+0x30]
000078d941fd3c9a  vmovaps xmm5, [rsp+0x40]
000078d941fd3ca0  vmovaps xmm6, [rsp+0x50]
000078d941fd3ca6  vmovaps xmm7, [rsp+0x60]
000078d941fd3cac  vmovaps xmm8, [rsp+0x70]
000078d941fd3cb2  vmovaps xmm9, [rsp+0x80]
000078d941fd3cbb  vmovaps xmm10, [rsp+0x90]
000078d941fd3cc4  vmovaps xmm11, [rsp+0xA0]
000078d941fd3ccd  vmovaps xmm12, [rsp+0xB0]
000078d941fd3cd6  vmovaps xmm13, [rsp+0xC0]
000078d941fd3cdf  vmovaps xmm14, [rsp+0xD0]
000078d941fd3ce8  vmovaps xmm15, [rsp+0xE0]
000078d941fd3cf1  add rsp, 0xF0
000078d941fd3cf8  pop r11
000078d941fd3cfa  pop r10
000078d941fd3cfc  pop r9
000078d941fd3cfe  pop r8
000078d941fd3d00  pop rsi
000078d941fd3d01  pop rdi
000078d941fd3d02  pop rdx
000078d941fd3d03  pop rcx
000078d941fd3d04  pop rax
000078d941fd3d05  add rsp, 0x08
000078d941fd3d09  jmp 0x000078D941FD0015
000078d941fd3d0e  sub rsp, 0x08
000078d941fd3d12  push rax
000078d941fd3d13  push rcx
000078d941fd3d14  push rdx
000078d941fd3d15  push rdi
000078d941fd3d16  push rsi
000078d941fd3d17  push r8
000078d941fd3d19  push r9
000078d941fd3d1b  push r10
000078d941fd3d1d  push r11
000078d941fd3d1f  sub rsp, 0xF0
000078d941fd3d26  vmovaps [rsp], xmm0
000078d941fd3d2b  vmovaps [rsp+0x10], xmm1
000078d941fd3d31  vmovaps [rsp+0x20], xmm2
000078d941fd3d37  vmovaps [rsp+0x30], xmm3
000078d941fd3d3d  vmovaps [rsp+0x40], xmm4
000078d941fd3d43  vmovaps [rsp+0x50], xmm5
000078d941fd3d49  vmovaps [rsp+0x60], xmm6
000078d941fd3d4f  vmovaps [rsp+0x70], xmm7
000078d941fd3d55  vmovaps [rsp+0x80], xmm8
000078d941fd3d5e  vmovaps [rsp+0x90], xmm9
000078d941fd3d67  vmovaps [rsp+0xA0], xmm10
000078d941fd3d70  vmovaps [rsp+0xB0], xmm12
000078d941fd3d79  vmovaps [rsp+0xC0], xmm13
000078d941fd3d82  vmovaps [rsp+0xD0], xmm14
000078d941fd3d8b  vmovaps [rsp+0xE0], xmm15
000078d941fd3d94  sub rsp, 0x30
000078d941fd3d98  movaps [rsp], xmm11
000078d941fd3d9d  movaps [rsp+0x10], xmm13
000078d941fd3da3  movaps [rsp+0x20], xmm14
000078d941fd3da9  lea rdi, [rsp]
000078d941fd3dad  mov esi, 0x00
000078d941fd3db2  mov rax, 0x59BFBFBAA530
000078d941fd3dbc  call rax
000078d941fd3dbe  movaps xmm11, [rsp]
000078d941fd3dc3  add rsp, 0x30
000078d941fd3dc7  vmovaps xmm0, [rsp]
000078d941fd3dcc  vmovaps xmm1, [rsp+0x10]
000078d941fd3dd2  vmovaps xmm2, [rsp+0x20]
000078d941fd3dd8  vmovaps xmm3, [rsp+0x30]
000078d941fd3dde  vmovaps xmm4, [rsp+0x40]
000078d941fd3de4  vmovaps xmm5, [rsp+0x50]
000078d941fd3dea  vmovaps xmm6, [rsp+0x60]
000078d941fd3df0  vmovaps xmm7, [rsp+0x70]
000078d941fd3df6  vmovaps xmm8, [rsp+0x80]
000078d941fd3dff  vmovaps xmm9, [rsp+0x90]
000078d941fd3e08  vmovaps xmm10, [rsp+0xA0]
000078d941fd3e11  vmovaps xmm12, [rsp+0xB0]
000078d941fd3e1a  vmovaps xmm13, [rsp+0xC0]
000078d941fd3e23  vmovaps xmm14, [rsp+0xD0]
000078d941fd3e2c  vmovaps xmm15, [rsp+0xE0]
000078d941fd3e35  add rsp, 0xF0
000078d941fd3e3c  pop r11
000078d941fd3e3e  pop r10
000078d941fd3e40  pop r9
000078d941fd3e42  pop r8
000078d941fd3e44  pop rsi
000078d941fd3e45  pop rdi
000078d941fd3e46  pop rdx
000078d941fd3e47  pop rcx
000078d941fd3e48  pop rax
000078d941fd3e49  add rsp, 0x08
000078d941fd3e4d  jmp 0x000078D941FD003F
000078d941fd3e52  sub rsp, 0x08
000078d941fd3e56  push rax
000078d941fd3e57  push rcx
000078d941fd3e58  push rdx
000078d941fd3e59  push rdi
000078d941fd3e5a  push rsi
000078d941fd3e5b  push r8
000078d941fd3e5d  push r9
000078d941fd3e5f  push r10
000078d941fd3e61  push r11
000078d941fd3e63  sub rsp, 0xF0
000078d941fd3e6a  vmovaps [rsp], xmm0
000078d941fd3e6f  vmovaps [rsp+0x10], xmm1
000078d941fd3e75  vmovaps [rsp+0x20], xmm2
000078d941fd3e7b  vmovaps [rsp+0x30], xmm3
000078d941fd3e81  vmovaps [rsp+0x40], xmm4
000078d941fd3e87  vmovaps [rsp+0x50], xmm5
000078d941fd3e8d  vmovaps [rsp+0x60], xmm6
000078d941fd3e93  vmovaps [rsp+0x70], xmm7
000078d941fd3e99  vmovaps [rsp+0x80], xmm8
000078d941fd3ea2  vmovaps [rsp+0x90], xmm9
000078d941fd3eab  vmovaps [rsp+0xA0], xmm10
000078d941fd3eb4  vmovaps [rsp+0xB0], xmm11
000078d941fd3ebd  vmovaps [rsp+0xC0], xmm12
000078d941fd3ec6  vmovaps [rsp+0xD0], xmm14
000078d941fd3ecf  vmovaps [rsp+0xE0], xmm15
000078d941fd3ed8  sub rsp, 0x30
000078d941fd3edc  movaps [rsp], xmm13
000078d941fd3ee1  movaps [rsp+0x10], xmm8
000078d941fd3ee7  movaps [rsp+0x20], xmm14
000078d941fd3eed  lea rdi, [rsp]
000078d941fd3ef1  mov esi, 0x00
000078d941fd3ef6  mov rax, 0x59BFBFBAA530
000078d941fd3f00  call rax
000078d941fd3f02  movaps xmm13, [rsp]
000078d941fd3f07  add rsp, 0x30
000078d941fd3f0b  vmovaps xmm0, [rsp]
000078d941fd3f10  vmovaps xmm1, [rsp+0x10]
000078d941fd3f16  vmovaps xmm2, [rsp+0x20]
000078d941fd3f1c  vmovaps xmm3, [rsp+0x30]
000078d941fd3f22  vmovaps xmm4, [rsp+0x40]
000078d941fd3f28  vmovaps xmm5, [rsp+0x50]
000078d941fd3f2e  vmovaps xmm6, [rsp+0x60]
000078d941fd3f34  vmovaps xmm7, [rsp+0x70]
000078d941fd3f3a  vmovaps xmm8, [rsp+0x80]
000078d941fd3f43  vmovaps xmm9, [rsp+0x90]
000078d941fd3f4c  vmovaps xmm10, [rsp+0xA0]
000078d941fd3f55  vmovaps xmm11, [rsp+0xB0]
000078d941fd3f5e  vmovaps xmm12, [rsp+0xC0]
000078d941fd3f67  vmovaps xmm14, [rsp+0xD0]
000078d941fd3f70  vmovaps xmm15, [rsp+0xE0]
000078d941fd3f79  add rsp, 0xF0
000078d941fd3f80  pop r11
000078d941fd3f82  pop r10
000078d941fd3f84  pop r9
000078d941fd3f86  pop r8
000078d941fd3f88  pop rsi
000078d941fd3f89  pop rdi
000078d941fd3f8a  pop rdx
000078d941fd3f8b  pop rcx
000078d941fd3f8c  pop rax
000078d941fd3f8d  add rsp, 0x08
000078d941fd3f91  jmp 0x000078D941FD006E
000078d941fd3f96  sub rsp, 0x08
000078d941fd3f9a  push rax
000078d941fd3f9b  push rcx
000078d941fd3f9c  push rdx
000078d941fd3f9d  push rdi
000078d941fd3f9e  push rsi
000078d941fd3f9f  push r8
000078d941fd3fa1  push r9
000078d941fd3fa3  push r10
000078d941fd3fa5  push r11
000078d941fd3fa7  sub rsp, 0xF0
000078d941fd3fae  vmovaps [rsp], xmm0
000078d941fd3fb3  vmovaps [rsp+0x10], xmm1
000078d941fd3fb9  vmovaps [rsp+0x20], xmm2
000078d941fd3fbf  vmovaps [rsp+0x30], xmm3
000078d941fd3fc5  vmovaps [rsp+0x40], xmm4
000078d941fd3fcb  vmovaps [rsp+0x50], xmm5
000078d941fd3fd1  vmovaps [rsp+0x60], xmm6
000078d941fd3fd7  vmovaps [rsp+0x70], xmm7
000078d941fd3fdd  vmovaps [rsp+0x80], xmm9
000078d941fd3fe6  vmovaps [rsp+0x90], xmm10
000078d941fd3fef  vmovaps [rsp+0xA0], xmm11
000078d941fd3ff8  vmovaps [rsp+0xB0], xmm12
000078d941fd4001  vmovaps [rsp+0xC0], xmm13
000078d941fd400a  vmovaps [rsp+0xD0], xmm14
000078d941fd4013  vmovaps [rsp+0xE0], xmm15
000078d941fd401c  sub rsp, 0x30
000078d941fd4020  movaps [rsp], xmm8
000078d941fd4025  movaps [rsp+0x10], xmm7
000078d941fd402a  movaps [rsp+0x20], xmm14
000078d941fd4030  lea rdi, [rsp]
000078d941fd4034  mov esi, 0x00
000078d941fd4039  mov rax, 0x59BFBFBAA530
000078d941fd4043  call rax
000078d941fd4045  movaps xmm8, [rsp]
000078d941fd404a  add rsp, 0x30
000078d941fd404e  vmovaps xmm0, [rsp]
000078d941fd4053  vmovaps xmm1, [rsp+0x10]
000078d941fd4059  vmovaps xmm2, [rsp+0x20]
000078d941fd405f  vmovaps xmm3, [rsp+0x30]
000078d941fd4065  vmovaps xmm4, [rsp+0x40]
000078d941fd406b  vmovaps xmm5, [rsp+0x50]
000078d941fd4071  vmovaps xmm6, [rsp+0x60]
000078d941fd4077  vmovaps xmm7, [rsp+0x70]
000078d941fd407d  vmovaps xmm9, [rsp+0x80]
000078d941fd4086  vmovaps xmm10, [rsp+0x90]
000078d941fd408f  vmovaps xmm11, [rsp+0xA0]
000078d941fd4098  vmovaps xmm12, [rsp+0xB0]
000078d941fd40a1  vmovaps xmm13, [rsp+0xC0]
000078d941fd40aa  vmovaps xmm14, [rsp+0xD0]
000078d941fd40b3  vmovaps xmm15, [rsp+0xE0]
000078d941fd40bc  add rsp, 0xF0
000078d941fd40c3  pop r11
000078d941fd40c5  pop r10
000078d941fd40c7  pop r9
000078d941fd40c9  pop r8
000078d941fd40cb  pop rsi
000078d941fd40cc  pop rdi
000078d941fd40cd  pop rdx
000078d941fd40ce  pop rcx
000078d941fd40cf  pop rax
000078d941fd40d0  add rsp, 0x08
000078d941fd40d4  jmp 0x000078D941FD0094
000078d941fd40d9  sub rsp, 0x08
000078d941fd40dd  push rax
000078d941fd40de  push rcx
000078d941fd40df  push rdx
000078d941fd40e0  push rdi
000078d941fd40e1  push rsi
000078d941fd40e2  push r8
000078d941fd40e4  push r9
000078d941fd40e6  push r10
000078d941fd40e8  push r11
000078d941fd40ea  sub rsp, 0xF0
000078d941fd40f1  vmovaps [rsp], xmm0
000078d941fd40f6  vmovaps [rsp+0x10], xmm1
000078d941fd40fc  vmovaps [rsp+0x20], xmm2
000078d941fd4102  vmovaps [rsp+0x30], xmm3
000078d941fd4108  vmovaps [rsp+0x40], xmm4
000078d941fd410e  vmovaps [rsp+0x50], xmm5
000078d941fd4114  vmovaps [rsp+0x60], xmm6
000078d941fd411a  vmovaps [rsp+0x70], xmm7
000078d941fd4120  vmovaps [rsp+0x80], xmm8
000078d941fd4129  vmovaps [rsp+0x90], xmm9
000078d941fd4132  vmovaps [rsp+0xA0], xmm10
000078d941fd413b  vmovaps [rsp+0xB0], xmm11
000078d941fd4144  vmovaps [rsp+0xC0], xmm12
000078d941fd414d  vmovaps [rsp+0xD0], xmm13
000078d941fd4156  vmovaps [rsp+0xE0], xmm15
000078d941fd415f  sub rsp, 0x30
000078d941fd4163  movaps [rsp], xmm14
000078d941fd4168  movaps [rsp+0x10], xmm12
000078d941fd416e  movaps [rsp+0x20], xmm9
000078d941fd4174  lea rdi, [rsp]
000078d941fd4178  mov esi, 0x00
000078d941fd417d  mov rax, 0x59BFBFBAA530
000078d941fd4187  call rax
000078d941fd4189  movaps xmm14, [rsp]
000078d941fd418e  add rsp, 0x30
000078d941fd4192  vmovaps xmm0, [rsp]
000078d941fd4197  vmovaps xmm1, [rsp+0x10]
000078d941fd419d  vmovaps xmm2, [rsp+0x20]
000078d941fd41a3  vmovaps xmm3, [rsp+0x30]
000078d941fd41a9  vmovaps xmm4, [rsp+0x40]
000078d941fd41af  vmovaps xmm5, [rsp+0x50]
000078d941fd41b5  vmovaps xmm6, [rsp+0x60]
000078d941fd41bb  vmovaps xmm7, [rsp+0x70]
000078d941fd41c1  vmovaps xmm8, [rsp+0x80]
000078d941fd41ca  vmovaps xmm9, [rsp+0x90]
000078d941fd41d3  vmovaps xmm10, [rsp+0xA0]
000078d941fd41dc  vmovaps xmm11, [rsp+0xB0]
000078d941fd41e5  vmovaps xmm12, [rsp+0xC0]
000078d941fd41ee  vmovaps xmm13, [rsp+0xD0]
000078d941fd41f7  vmovaps xmm15, [rsp+0xE0]
000078d941fd4200  add rsp, 0xF0
000078d941fd4207  pop r11
000078d941fd4209  pop r10
000078d941fd420b  pop r9
000078d941fd420d  pop r8
000078d941fd420f  pop rsi
000078d941fd4210  pop rdi
000078d941fd4211  pop rdx
000078d941fd4212  pop rcx
000078d941fd4213  pop rax
000078d941fd4214  add rsp, 0x08
000078d941fd4218  jmp 0x000078D941FD00AE
000078d941fd421d  sub rsp, 0x08
000078d941fd4221  push rax
000078d941fd4222  push rcx
000078d941fd4223  push rdx
000078d941fd4224  push rdi
000078d941fd4225  push rsi
000078d941fd4226  push r8
000078d941fd4228  push r9
000078d941fd422a  push r10
000078d941fd422c  push r11
000078d941fd422e  sub rsp, 0xF0
000078d941fd4235  vmovaps [rsp], xmm0
000078d941fd423a  vmovaps [rsp+0x10], xmm1
000078d941fd4240  vmovaps [rsp+0x20], xmm2
000078d941fd4246  vmovaps [rsp+0x30], xmm3
000078d941fd424c  vmovaps [rsp+0x40], xmm4
000078d941fd4252  vmovaps [rsp+0x50], xmm5
000078d941fd4258  vmovaps [rsp+0x60], xmm6
000078d941fd425e  vmovaps [rsp+0x70], xmm7
000078d941fd4264  vmovaps [rsp+0x80], xmm8
000078d941fd426d  vmovaps [rsp+0x90], xmm10
000078d941fd4276  vmovaps [rsp+0xA0], xmm11
000078d941fd427f  vmovaps [rsp+0xB0], xmm12
000078d941fd4288  vmovaps [rsp+0xC0], xmm13
000078d941fd4291  vmovaps [rsp+0xD0], xmm14
000078d941fd429a  vmovaps [rsp+0xE0], xmm15
000078d941fd42a3  sub rsp, 0x30
000078d941fd42a7  movaps [rsp], xmm9
000078d941fd42ac  movaps [rsp+0x10], xmm7
000078d941fd42b1  movaps [rsp+0x20], xmm12
000078d941fd42b7  lea rdi, [rsp]
000078d941fd42bb  mov esi, 0x00
000078d941fd42c0  mov rax, 0x59BFBFBAA530
000078d941fd42ca  call rax
000078d941fd42cc  movaps xmm9, [rsp]
000078d941fd42d1  add rsp, 0x30
000078d941fd42d5  vmovaps xmm0, [rsp]
000078d941fd42da  vmovaps xmm1, [rsp+0x10]
000078d941fd42e0  vmovaps xmm2, [rsp+0x20]
000078d941fd42e6  vmovaps xmm3, [rsp+0x30]
000078d941fd42ec  vmovaps xmm4, [rsp+0x40]
000078d941fd42f2  vmovaps xmm5, [rsp+0x50]
000078d941fd42f8  vmovaps xmm6, [rsp+0x60]
000078d941fd42fe  vmovaps xmm7, [rsp+0x70]
000078d941fd4304  vmovaps xmm8, [rsp+0x80]
000078d941fd430d  vmovaps xmm10, [rsp+0x90]
000078d941fd4316  vmovaps xmm11, [rsp+0xA0]
000078d941fd431f  vmovaps xmm12, [rsp+0xB0]
000078d941fd4328  vmovaps xmm13, [rsp+0xC0]
000078d941fd4331  vmovaps xmm14, [rsp+0xD0]
000078d941fd433a  vmovaps xmm15, [rsp+0xE0]
000078d941fd4343  add rsp, 0xF0
000078d941fd434a  pop r11
000078d941fd434c  pop r10
000078d941fd434e  pop r9
000078d941fd4350  pop r8
000078d941fd4352  pop rsi
000078d941fd4353  pop rdi
000078d941fd4354  pop rdx
000078d941fd4355  pop rcx
000078d941fd4356  pop rax
000078d941fd4357  add rsp, 0x08
000078d941fd435b  jmp 0x000078D941FD00DD
000078d941fd4360  sub rsp, 0x08
000078d941fd4364  push rax
000078d941fd4365  push rcx
000078d941fd4366  push rdx
000078d941fd4367  push rdi
000078d941fd4368  push rsi
000078d941fd4369  push r8
000078d941fd436b  push r9
000078d941fd436d  push r10
000078d941fd436f  push r11
000078d941fd4371  sub rsp, 0xF0
000078d941fd4378  vmovaps [rsp], xmm0
000078d941fd437d  vmovaps [rsp+0x10], xmm1
000078d941fd4383  vmovaps [rsp+0x20], xmm2
000078d941fd4389  vmovaps [rsp+0x30], xmm3
000078d941fd438f  vmovaps [rsp+0x40], xmm4
000078d941fd4395  vmovaps [rsp+0x50], xmm5
000078d941fd439b  vmovaps [rsp+0x60], xmm6
000078d941fd43a1  vmovaps [rsp+0x70], xmm7
000078d941fd43a7  vmovaps [rsp+0x80], xmm8
000078d941fd43b0  vmovaps [rsp+0x90], xmm9
000078d941fd43b9  vmovaps [rsp+0xA0], xmm10
000078d941fd43c2  vmovaps [rsp+0xB0], xmm11
000078d941fd43cb  vmovaps [rsp+0xC0], xmm13
000078d941fd43d4  vmovaps [rsp+0xD0], xmm14
000078d941fd43dd  vmovaps [rsp+0xE0], xmm15
000078d941fd43e6  sub rsp, 0x30
000078d941fd43ea  movaps [rsp], xmm12
000078d941fd43ef  movaps [rsp+0x10], xmm15
000078d941fd43f5  movaps [rsp+0x20], xmm11
000078d941fd43fb  lea rdi, [rsp]
000078d941fd43ff  mov esi, 0x00
000078d941fd4404  mov rax, 0x59BFBFBAA530
000078d941fd440e  call rax
000078d941fd4410  movaps xmm12, [rsp]
000078d941fd4415  add rsp, 0x30
000078d941fd4419  vmovaps xmm0, [rsp]
000078d941fd441e  vmovaps xmm1, [rsp+0x10]
000078d941fd4424  vmovaps xmm2, [rsp+0x20]
000078d941fd442a  vmovaps xmm3, [rsp+0x30]
000078d941fd4430  vmovaps xmm4, [rsp+0x40]
000078d941fd4436  vmovaps xmm5, [rsp+0x50]
000078d941fd443c  vmovaps xmm6, [rsp+0x60]
000078d941fd4442  vmovaps xmm7, [rsp+0x70]
000078d941fd4448  vmovaps xmm8, [rsp+0x80]
000078d941fd4451  vmovaps xmm9, [rsp+0x90]
000078d941fd445a  vmovaps xmm10, [rsp+0xA0]
000078d941fd4463  vmovaps xmm11, [rsp+0xB0]
000078d941fd446c  vmovaps xmm13, [rsp+0xC0]
000078d941fd4475  vmovaps xmm14, [rsp+0xD0]
000078d941fd447e  vmovaps xmm15, [rsp+0xE0]
000078d941fd4487  add rsp, 0xF0
000078d941fd448e  pop r11
000078d941fd4490  pop r10
000078d941fd4492  pop r9
000078d941fd4494  pop r8
000078d941fd4496  pop rsi
000078d941fd4497  pop rdi
000078d941fd4498  pop rdx
000078d941fd4499  pop rcx
000078d941fd449a  pop rax
000078d941fd449b  add rsp, 0x08
000078d941fd449f  jmp 0x000078D941FD00F7
000078d941fd44a4  sub rsp, 0x08
000078d941fd44a8  push rax
000078d941fd44a9  push rcx
000078d941fd44aa  push rdx
000078d941fd44ab  push rdi
000078d941fd44ac  push rsi
000078d941fd44ad  push r8
000078d941fd44af  push r9
000078d941fd44b1  push r10
000078d941fd44b3  push r11
000078d941fd44b5  sub rsp, 0xF0
000078d941fd44bc  vmovaps [rsp], xmm0
000078d941fd44c1  vmovaps [rsp+0x10], xmm1
000078d941fd44c7  vmovaps [rsp+0x20], xmm2
000078d941fd44cd  vmovaps [rsp+0x30], xmm3
000078d941fd44d3  vmovaps [rsp+0x40], xmm4
000078d941fd44d9  vmovaps [rsp+0x50], xmm5
000078d941fd44df  vmovaps [rsp+0x60], xmm6
000078d941fd44e5  vmovaps [rsp+0x70], xmm7
000078d941fd44eb  vmovaps [rsp+0x80], xmm8
000078d941fd44f4  vmovaps [rsp+0x90], xmm9
000078d941fd44fd  vmovaps [rsp+0xA0], xmm10
000078d941fd4506  vmovaps [rsp+0xB0], xmm12
000078d941fd450f  vmovaps [rsp+0xC0], xmm13
000078d941fd4518  vmovaps [rsp+0xD0], xmm14
000078d941fd4521  vmovaps [rsp+0xE0], xmm15
000078d941fd452a  sub rsp, 0x30
000078d941fd452e  movaps [rsp], xmm11
000078d941fd4533  movaps [rsp+0x10], xmm7
000078d941fd4538  movaps [rsp+0x20], xmm15
000078d941fd453e  lea rdi, [rsp]
000078d941fd4542  mov esi, 0x00
000078d941fd4547  mov rax, 0x59BFBFBAA530
000078d941fd4551  call rax
000078d941fd4553  movaps xmm11, [rsp]
000078d941fd4558  add rsp, 0x30
000078d941fd455c  vmovaps xmm0, [rsp]
000078d941fd4561  vmovaps xmm1, [rsp+0x10]
000078d941fd4567  vmovaps xmm2, [rsp+0x20]
000078d941fd456d  vmovaps xmm3, [rsp+0x30]
000078d941fd4573  vmovaps xmm4, [rsp+0x40]
000078d941fd4579  vmovaps xmm5, [rsp+0x50]
000078d941fd457f  vmovaps xmm6, [rsp+0x60]
000078d941fd4585  vmovaps xmm7, [rsp+0x70]
000078d941fd458b  vmovaps xmm8, [rsp+0x80]
000078d941fd4594  vmovaps xmm9, [rsp+0x90]
000078d941fd459d  vmovaps xmm10, [rsp+0xA0]
000078d941fd45a6  vmovaps xmm12, [rsp+0xB0]
000078d941fd45af  vmovaps xmm13, [rsp+0xC0]
000078d941fd45b8  vmovaps xmm14, [rsp+0xD0]
000078d941fd45c1  vmovaps xmm15, [rsp+0xE0]
000078d941fd45ca  add rsp, 0xF0
000078d941fd45d1  pop r11
000078d941fd45d3  pop r10
000078d941fd45d5  pop r9
000078d941fd45d7  pop r8
000078d941fd45d9  pop rsi
000078d941fd45da  pop rdi
000078d941fd45db  pop rdx
000078d941fd45dc  pop rcx
000078d941fd45dd  pop rax
000078d941fd45de  add rsp, 0x08
000078d941fd45e2  jmp 0x000078D941FD0123
000078d941fd45e7  sub rsp, 0x08
000078d941fd45eb  push rax
000078d941fd45ec  push rcx
000078d941fd45ed  push rdx
000078d941fd45ee  push rdi
000078d941fd45ef  push rsi
000078d941fd45f0  push r8
000078d941fd45f2  push r9
000078d941fd45f4  push r10
000078d941fd45f6  push r11
000078d941fd45f8  sub rsp, 0xF0
000078d941fd45ff  vmovaps [rsp], xmm0
000078d941fd4604  vmovaps [rsp+0x10], xmm1
000078d941fd460a  vmovaps [rsp+0x20], xmm2
000078d941fd4610  vmovaps [rsp+0x30], xmm3
000078d941fd4616  vmovaps [rsp+0x40], xmm4
000078d941fd461c  vmovaps [rsp+0x50], xmm5
000078d941fd4622  vmovaps [rsp+0x60], xmm6
000078d941fd4628  vmovaps [rsp+0x70], xmm7
000078d941fd462e  vmovaps [rsp+0x80], xmm8
000078d941fd4637  vmovaps [rsp+0x90], xmm9
000078d941fd4640  vmovaps [rsp+0xA0], xmm10
000078d941fd4649  vmovaps [rsp+0xB0], xmm11
000078d941fd4652  vmovaps [rsp+0xC0], xmm12
000078d941fd465b  vmovaps [rsp+0xD0], xmm13
000078d941fd4664  vmovaps [rsp+0xE0], xmm14
000078d941fd466d  sub rsp, 0x30
000078d941fd4671  movaps [rsp], xmm15
000078d941fd4676  movaps [rsp+0x10], xmm10
000078d941fd467c  movaps [rsp+0x20], xmm13
000078d941fd4682  lea rdi, [rsp]
000078d941fd4686  mov esi, 0x00
000078d941fd468b  mov rax, 0x59BFBFBAA530
000078d941fd4695  call rax
000078d941fd4697  movaps xmm15, [rsp]
000078d941fd469c  add rsp, 0x30
000078d941fd46a0  vmovaps xmm0, [rsp]
000078d941fd46a5  vmovaps xmm1, [rsp+0x10]
000078d941fd46ab  vmovaps xmm2, [rsp+0x20]
000078d941fd46b1  vmovaps xmm3, [rsp+0x30]
000078d941fd46b7  vmovaps xmm4, [rsp+0x40]
000078d941fd46bd  vmovaps xmm5, [rsp+0x50]
000078d941fd46c3  vmovaps xmm6, [rsp+0x60]
000078d941fd46c9  vmovaps xmm7, [rsp+0x70]
000078d941fd46cf  vmovaps xmm8, [rsp+0x80]
000078d941fd46d8  vmovaps xmm9, [rsp+0x90]
000078d941fd46e1  vmovaps xmm10, [rsp+0xA0]
000078d941fd46ea  vmovaps xmm11, [rsp+0xB0]
000078d941fd46f3  vmovaps xmm12, [rsp+0xC0]
000078d941fd46fc  vmovaps xmm13, [rsp+0xD0]
000078d941fd4705  vmovaps xmm14, [rsp+0xE0]
000078d941fd470e  add rsp, 0xF0
000078d941fd4715  pop r11
000078d941fd4717  pop r10
000078d941fd4719  pop r9
000078d941fd471b  pop r8
000078d941fd471d  pop rsi
000078d941fd471e  pop rdi
000078d941fd471f  pop rdx
000078d941fd4720  pop rcx
000078d941fd4721  pop rax
000078d941fd4722  add rsp, 0x08
000078d941fd4726  jmp 0x000078D941FD013D
000078d941fd472b  sub rsp, 0x08
000078d941fd472f  push rax
000078d941fd4730  push rcx
000078d941fd4731  push rdx
000078d941fd4732  push rdi
000078d941fd4733  push rsi
000078d941fd4734  push r8
000078d941fd4736  push r9
000078d941fd4738  push r10
000078d941fd473a  push r11
000078d941fd473c  sub rsp, 0xF0
000078d941fd4743  vmovaps [rsp], xmm0
000078d941fd4748  vmovaps [rsp+0x10], xmm1
000078d941fd474e  vmovaps [rsp+0x20], xmm2
000078d941fd4754  vmovaps [rsp+0x30], xmm3
000078d941fd475a  vmovaps [rsp+0x40], xmm4
000078d941fd4760  vmovaps [rsp+0x50], xmm5
000078d941fd4766  vmovaps [rsp+0x60], xmm6
000078d941fd476c  vmovaps [rsp+0x70], xmm7
000078d941fd4772  vmovaps [rsp+0x80], xmm8
000078d941fd477b  vmovaps [rsp+0x90], xmm9
000078d941fd4784  vmovaps [rsp+0xA0], xmm11
000078d941fd478d  vmovaps [rsp+0xB0], xmm12
000078d941fd4796  vmovaps [rsp+0xC0], xmm13
000078d941fd479f  vmovaps [rsp+0xD0], xmm14
000078d941fd47a8  vmovaps [rsp+0xE0], xmm15
000078d941fd47b1  sub rsp, 0x30
000078d941fd47b5  movaps [rsp], xmm10
000078d941fd47ba  movaps [rsp+0x10], xmm7
000078d941fd47bf  movaps [rsp+0x20], xmm13
000078d941fd47c5  lea rdi, [rsp]
000078d941fd47c9  mov esi, 0x00
000078d941fd47ce  mov rax, 0x59BFBFBAA530
000078d941fd47d8  call rax
000078d941fd47da  movaps xmm10, [rsp]
000078d941fd47df  add rsp, 0x30
000078d941fd47e3  vmovaps xmm0, [rsp]
000078d941fd47e8  vmovaps xmm1, [rsp+0x10]
000078d941fd47ee  vmovaps xmm2, [rsp+0x20]
000078d941fd47f4  vmovaps xmm3, [rsp+0x30]
000078d941fd47fa  vmovaps xmm4, [rsp+0x40]
000078d941fd4800  vmovaps xmm5, [rsp+0x50]
000078d941fd4806  vmovaps xmm6, [rsp+0x60]
000078d941fd480c  vmovaps xmm7, [rsp+0x70]
000078d941fd4812  vmovaps xmm8, [rsp+0x80]
000078d941fd481b  vmovaps xmm9, [rsp+0x90]
000078d941fd4824  vmovaps xmm11, [rsp+0xA0]
000078d941fd482d  vmovaps xmm12, [rsp+0xB0]
000078d941fd4836  vmovaps xmm13, [rsp+0xC0]
000078d941fd483f  vmovaps xmm14, [rsp+0xD0]
000078d941fd4848  vmovaps xmm15, [rsp+0xE0]
000078d941fd4851  add rsp, 0xF0
000078d941fd4858  pop r11
000078d941fd485a  pop r10
000078d941fd485c  pop r9
000078d941fd485e  pop r8
000078d941fd4860  pop rsi
000078d941fd4861  pop rdi
000078d941fd4862  pop rdx
000078d941fd4863  pop rcx
000078d941fd4864  pop rax
000078d941fd4865  add rsp, 0x08
000078d941fd4869  jmp 0x000078D941FD0169
000078d941fd486e  sub rsp, 0x08
000078d941fd4872  push rax
000078d941fd4873  push rcx
000078d941fd4874  push rdx
000078d941fd4875  push rdi
000078d941fd4876  push rsi
000078d941fd4877  push r8
000078d941fd4879  push r9
000078d941fd487b  push r10
000078d941fd487d  push r11
000078d941fd487f  sub rsp, 0xF0
000078d941fd4886  vmovaps [rsp], xmm0
000078d941fd488b  vmovaps [rsp+0x10], xmm1
000078d941fd4891  vmovaps [rsp+0x20], xmm2
000078d941fd4897  vmovaps [rsp+0x30], xmm3
000078d941fd489d  vmovaps [rsp+0x40], xmm4
000078d941fd48a3  vmovaps [rsp+0x50], xmm5
000078d941fd48a9  vmovaps [rsp+0x60], xmm6
000078d941fd48af  vmovaps [rsp+0x70], xmm7
000078d941fd48b5  vmovaps [rsp+0x80], xmm8
000078d941fd48be  vmovaps [rsp+0x90], xmm9
000078d941fd48c7  vmovaps [rsp+0xA0], xmm10
000078d941fd48d0  vmovaps [rsp+0xB0], xmm11
000078d941fd48d9  vmovaps [rsp+0xC0], xmm12
000078d941fd48e2  vmovaps [rsp+0xD0], xmm14
000078d941fd48eb  vmovaps [rsp+0xE0], xmm15
000078d941fd48f4  sub rsp, 0x30
000078d941fd48f8  movaps [rsp], xmm13
000078d941fd48fd  movaps [rsp+0x10], xmm1
000078d941fd4902  movaps [rsp+0x20], xmm8
000078d941fd4908  lea rdi, [rsp]
000078d941fd490c  mov esi, 0x00
000078d941fd4911  mov rax, 0x59BFBFBAA530
000078d941fd491b  call rax
000078d941fd491d  movaps xmm13, [rsp]
000078d941fd4922  add rsp, 0x30
000078d941fd4926  vmovaps xmm0, [rsp]
000078d941fd492b  vmovaps xmm1, [rsp+0x10]
000078d941fd4931  vmovaps xmm2, [rsp+0x20]
000078d941fd4937  vmovaps xmm3, [rsp+0x30]
000078d941fd493d  vmovaps xmm4, [rsp+0x40]
000078d941fd4943  vmovaps xmm5, [rsp+0x50]
000078d941fd4949  vmovaps xmm6, [rsp+0x60]
000078d941fd494f  vmovaps xmm7, [rsp+0x70]
000078d941fd4955  vmovaps xmm8, [rsp+0x80]
000078d941fd495e  vmovaps xmm9, [rsp+0x90]
000078d941fd4967  vmovaps xmm10, [rsp+0xA0]
000078d941fd4970  vmovaps xmm11, [rsp+0xB0]
000078d941fd4979  vmovaps xmm12, [rsp+0xC0]
000078d941fd4982  vmovaps xmm14, [rsp+0xD0]
000078d941fd498b  vmovaps xmm15, [rsp+0xE0]
000078d941fd4994  add rsp, 0xF0
000078d941fd499b  pop r11
000078d941fd499d  pop r10
000078d941fd499f  pop r9
000078d941fd49a1  pop r8
000078d941fd49a3  pop rsi
000078d941fd49a4  pop rdi
000078d941fd49a5  pop rdx
000078d941fd49a6  pop rcx
000078d941fd49a7  pop rax
000078d941fd49a8  add rsp, 0x08
000078d941fd49ac  jmp 0x000078D941FD0183
000078d941fd49b1  call 0x000078D941DFF430
000078d941fd49b6  jmp 0x000078D941FD018D
000078d941fd49bb  sub rsp, 0x08
000078d941fd49bf  push rax
000078d941fd49c0  push rcx
000078d941fd49c1  push rdx
000078d941fd49c2  push rdi
000078d941fd49c3  push rsi
000078d941fd49c4  push r8
000078d941fd49c6  push r9
000078d941fd49c8  push r10
000078d941fd49ca  push r11
000078d941fd49cc  sub rsp, 0xF0
000078d941fd49d3  vmovaps [rsp], xmm0
000078d941fd49d8  vmovaps [rsp+0x10], xmm1
000078d941fd49de  vmovaps [rsp+0x20], xmm2
000078d941fd49e4  vmovaps [rsp+0x30], xmm3
000078d941fd49ea  vmovaps [rsp+0x40], xmm4
000078d941fd49f0  vmovaps [rsp+0x50], xmm5
000078d941fd49f6  vmovaps [rsp+0x60], xmm6
000078d941fd49fc  vmovaps [rsp+0x70], xmm7
000078d941fd4a02  vmovaps [rsp+0x80], xmm9
000078d941fd4a0b  vmovaps [rsp+0x90], xmm10
000078d941fd4a14  vmovaps [rsp+0xA0], xmm11
000078d941fd4a1d  vmovaps [rsp+0xB0], xmm12
000078d941fd4a26  vmovaps [rsp+0xC0], xmm13
000078d941fd4a2f  vmovaps [rsp+0xD0], xmm14
000078d941fd4a38  vmovaps [rsp+0xE0], xmm15
000078d941fd4a41  sub rsp, 0x30
000078d941fd4a45  movaps [rsp], xmm8
000078d941fd4a4a  movaps [rsp+0x10], xmm14
000078d941fd4a50  movaps [rsp+0x20], xmm9
000078d941fd4a56  lea rdi, [rsp]
000078d941fd4a5a  mov esi, 0x00
000078d941fd4a5f  mov rax, 0x59BFBFBAA530
000078d941fd4a69  call rax
000078d941fd4a6b  movaps xmm8, [rsp]
000078d941fd4a70  add rsp, 0x30
000078d941fd4a74  vmovaps xmm0, [rsp]
000078d941fd4a79  vmovaps xmm1, [rsp+0x10]
000078d941fd4a7f  vmovaps xmm2, [rsp+0x20]
000078d941fd4a85  vmovaps xmm3, [rsp+0x30]
000078d941fd4a8b  vmovaps xmm4, [rsp+0x40]
000078d941fd4a91  vmovaps xmm5, [rsp+0x50]
000078d941fd4a97  vmovaps xmm6, [rsp+0x60]
000078d941fd4a9d  vmovaps xmm7, [rsp+0x70]
000078d941fd4aa3  vmovaps xmm9, [rsp+0x80]
000078d941fd4aac  vmovaps xmm10, [rsp+0x90]
000078d941fd4ab5  vmovaps xmm11, [rsp+0xA0]
000078d941fd4abe  vmovaps xmm12, [rsp+0xB0]
000078d941fd4ac7  vmovaps xmm13, [rsp+0xC0]
000078d941fd4ad0  vmovaps xmm14, [rsp+0xD0]
000078d941fd4ad9  vmovaps xmm15, [rsp+0xE0]
000078d941fd4ae2  add rsp, 0xF0
000078d941fd4ae9  pop r11
000078d941fd4aeb  pop r10
000078d941fd4aed  pop r9
000078d941fd4aef  pop r8
000078d941fd4af1  pop rsi
000078d941fd4af2  pop rdi
000078d941fd4af3  pop rdx
000078d941fd4af4  pop rcx
000078d941fd4af5  pop rax
000078d941fd4af6  add rsp, 0x08
000078d941fd4afa  jmp 0x000078D941FD01AF
000078d941fd4aff  sub rsp, 0x08
000078d941fd4b03  push rax
000078d941fd4b04  push rcx
000078d941fd4b05  push rdx
000078d941fd4b06  push rdi
000078d941fd4b07  push rsi
000078d941fd4b08  push r8
000078d941fd4b0a  push r9
000078d941fd4b0c  push r10
000078d941fd4b0e  push r11
000078d941fd4b10  sub rsp, 0xF0
000078d941fd4b17  vmovaps [rsp], xmm0
000078d941fd4b1c  vmovaps [rsp+0x10], xmm1
000078d941fd4b22  vmovaps [rsp+0x20], xmm2
000078d941fd4b28  vmovaps [rsp+0x30], xmm3
000078d941fd4b2e  vmovaps [rsp+0x40], xmm4
000078d941fd4b34  vmovaps [rsp+0x50], xmm5
000078d941fd4b3a  vmovaps [rsp+0x60], xmm6
000078d941fd4b40  vmovaps [rsp+0x70], xmm7
000078d941fd4b46  vmovaps [rsp+0x80], xmm8
000078d941fd4b4f  vmovaps [rsp+0x90], xmm10
000078d941fd4b58  vmovaps [rsp+0xA0], xmm11
000078d941fd4b61  vmovaps [rsp+0xB0], xmm12
000078d941fd4b6a  vmovaps [rsp+0xC0], xmm13
000078d941fd4b73  vmovaps [rsp+0xD0], xmm14
000078d941fd4b7c  vmovaps [rsp+0xE0], xmm15
000078d941fd4b85  sub rsp, 0x30
000078d941fd4b89  movaps [rsp], xmm9
000078d941fd4b8e  movaps [rsp+0x10], xmm1
000078d941fd4b93  movaps [rsp+0x20], xmm14
000078d941fd4b99  lea rdi, [rsp]
000078d941fd4b9d  mov esi, 0x00
000078d941fd4ba2  mov rax, 0x59BFBFBAA530
000078d941fd4bac  call rax
000078d941fd4bae  movaps xmm9, [rsp]
000078d941fd4bb3  add rsp, 0x30
000078d941fd4bb7  vmovaps xmm0, [rsp]
000078d941fd4bbc  vmovaps xmm1, [rsp+0x10]
000078d941fd4bc2  vmovaps xmm2, [rsp+0x20]
000078d941fd4bc8  vmovaps xmm3, [rsp+0x30]
000078d941fd4bce  vmovaps xmm4, [rsp+0x40]
000078d941fd4bd4  vmovaps xmm5, [rsp+0x50]
000078d941fd4bda  vmovaps xmm6, [rsp+0x60]
000078d941fd4be0  vmovaps xmm7, [rsp+0x70]
000078d941fd4be6  vmovaps xmm8, [rsp+0x80]
000078d941fd4bef  vmovaps xmm10, [rsp+0x90]
000078d941fd4bf8  vmovaps xmm11, [rsp+0xA0]
000078d941fd4c01  vmovaps xmm12, [rsp+0xB0]
000078d941fd4c0a  vmovaps xmm13, [rsp+0xC0]
000078d941fd4c13  vmovaps xmm14, [rsp+0xD0]
000078d941fd4c1c  vmovaps xmm15, [rsp+0xE0]
000078d941fd4c25  add rsp, 0xF0
000078d941fd4c2c  pop r11
000078d941fd4c2e  pop r10
000078d941fd4c30  pop r9
000078d941fd4c32  pop r8
000078d941fd4c34  pop rsi
000078d941fd4c35  pop rdi
000078d941fd4c36  pop rdx
000078d941fd4c37  pop rcx
000078d941fd4c38  pop rax
000078d941fd4c39  add rsp, 0x08
000078d941fd4c3d  jmp 0x000078D941FD01DD
000078d941fd4c42  sub rsp, 0x08
000078d941fd4c46  push rax
000078d941fd4c47  push rcx
000078d941fd4c48  push rdx
000078d941fd4c49  push rdi
000078d941fd4c4a  push rsi
000078d941fd4c4b  push r8
000078d941fd4c4d  push r9
000078d941fd4c4f  push r10
000078d941fd4c51  push r11
000078d941fd4c53  sub rsp, 0xF0
000078d941fd4c5a  vmovaps [rsp], xmm0
000078d941fd4c5f  vmovaps [rsp+0x10], xmm1
000078d941fd4c65  vmovaps [rsp+0x20], xmm2
000078d941fd4c6b  vmovaps [rsp+0x30], xmm3
000078d941fd4c71  vmovaps [rsp+0x40], xmm4
000078d941fd4c77  vmovaps [rsp+0x50], xmm5
000078d941fd4c7d  vmovaps [rsp+0x60], xmm6
000078d941fd4c83  vmovaps [rsp+0x70], xmm7
000078d941fd4c89  vmovaps [rsp+0x80], xmm8
000078d941fd4c92  vmovaps [rsp+0x90], xmm9
000078d941fd4c9b  vmovaps [rsp+0xA0], xmm10
000078d941fd4ca4  vmovaps [rsp+0xB0], xmm11
000078d941fd4cad  vmovaps [rsp+0xC0], xmm12
000078d941fd4cb6  vmovaps [rsp+0xD0], xmm13
000078d941fd4cbf  vmovaps [rsp+0xE0], xmm15
000078d941fd4cc8  sub rsp, 0x30
000078d941fd4ccc  movaps [rsp], xmm14
000078d941fd4cd1  movaps [rsp+0x10], xmm4
000078d941fd4cd6  movaps [rsp+0x20], xmm1
000078d941fd4cdb  lea rdi, [rsp]
000078d941fd4cdf  mov esi, 0x00
000078d941fd4ce4  mov rax, 0x59BFBFBAA530
000078d941fd4cee  call rax
000078d941fd4cf0  movaps xmm14, [rsp]
000078d941fd4cf5  add rsp, 0x30
000078d941fd4cf9  vmovaps xmm0, [rsp]
000078d941fd4cfe  vmovaps xmm1, [rsp+0x10]
000078d941fd4d04  vmovaps xmm2, [rsp+0x20]
000078d941fd4d0a  vmovaps xmm3, [rsp+0x30]
000078d941fd4d10  vmovaps xmm4, [rsp+0x40]
000078d941fd4d16  vmovaps xmm5, [rsp+0x50]
000078d941fd4d1c  vmovaps xmm6, [rsp+0x60]
000078d941fd4d22  vmovaps xmm7, [rsp+0x70]
000078d941fd4d28  vmovaps xmm8, [rsp+0x80]
000078d941fd4d31  vmovaps xmm9, [rsp+0x90]
000078d941fd4d3a  vmovaps xmm10, [rsp+0xA0]
000078d941fd4d43  vmovaps xmm11, [rsp+0xB0]
000078d941fd4d4c  vmovaps xmm12, [rsp+0xC0]
000078d941fd4d55  vmovaps xmm13, [rsp+0xD0]
000078d941fd4d5e  vmovaps xmm15, [rsp+0xE0]
000078d941fd4d67  add rsp, 0xF0
000078d941fd4d6e  pop r11
000078d941fd4d70  pop r10
000078d941fd4d72  pop r9
000078d941fd4d74  pop r8
000078d941fd4d76  pop rsi
000078d941fd4d77  pop rdi
000078d941fd4d78  pop rdx
000078d941fd4d79  pop rcx
000078d941fd4d7a  pop rax
000078d941fd4d7b  add rsp, 0x08
000078d941fd4d7f  jmp 0x000078D941FD0203
000078d941fd4d84  sub rsp, 0x08
000078d941fd4d88  push rax
000078d941fd4d89  push rcx
000078d941fd4d8a  push rdx
000078d941fd4d8b  push rdi
000078d941fd4d8c  push rsi
000078d941fd4d8d  push r8
000078d941fd4d8f  push r9
000078d941fd4d91  push r10
000078d941fd4d93  push r11
000078d941fd4d95  sub rsp, 0xF0
000078d941fd4d9c  vmovaps [rsp], xmm0
000078d941fd4da1  vmovaps [rsp+0x10], xmm2
000078d941fd4da7  vmovaps [rsp+0x20], xmm3
000078d941fd4dad  vmovaps [rsp+0x30], xmm4
000078d941fd4db3  vmovaps [rsp+0x40], xmm5
000078d941fd4db9  vmovaps [rsp+0x50], xmm6
000078d941fd4dbf  vmovaps [rsp+0x60], xmm7
000078d941fd4dc5  vmovaps [rsp+0x70], xmm8
000078d941fd4dcb  vmovaps [rsp+0x80], xmm9
000078d941fd4dd4  vmovaps [rsp+0x90], xmm10
000078d941fd4ddd  vmovaps [rsp+0xA0], xmm11
000078d941fd4de6  vmovaps [rsp+0xB0], xmm12
000078d941fd4def  vmovaps [rsp+0xC0], xmm13
000078d941fd4df8  vmovaps [rsp+0xD0], xmm14
000078d941fd4e01  vmovaps [rsp+0xE0], xmm15
000078d941fd4e0a  sub rsp, 0x30
000078d941fd4e0e  movaps [rsp], xmm1
000078d941fd4e12  movaps [rsp+0x10], xmm12
000078d941fd4e18  movaps [rsp+0x20], xmm11
000078d941fd4e1e  lea rdi, [rsp]
000078d941fd4e22  mov esi, 0x00
000078d941fd4e27  mov rax, 0x59BFBFBAA530
000078d941fd4e31  call rax
000078d941fd4e33  movaps xmm1, [rsp]
000078d941fd4e37  add rsp, 0x30
000078d941fd4e3b  vmovaps xmm0, [rsp]
000078d941fd4e40  vmovaps xmm2, [rsp+0x10]
000078d941fd4e46  vmovaps xmm3, [rsp+0x20]
000078d941fd4e4c  vmovaps xmm4, [rsp+0x30]
000078d941fd4e52  vmovaps xmm5, [rsp+0x40]
000078d941fd4e58  vmovaps xmm6, [rsp+0x50]
000078d941fd4e5e  vmovaps xmm7, [rsp+0x60]
000078d941fd4e64  vmovaps xmm8, [rsp+0x70]
000078d941fd4e6a  vmovaps xmm9, [rsp+0x80]
000078d941fd4e73  vmovaps xmm10, [rsp+0x90]
000078d941fd4e7c  vmovaps xmm11, [rsp+0xA0]
000078d941fd4e85  vmovaps xmm12, [rsp+0xB0]
000078d941fd4e8e  vmovaps xmm13, [rsp+0xC0]
000078d941fd4e97  vmovaps xmm14, [rsp+0xD0]
000078d941fd4ea0  vmovaps xmm15, [rsp+0xE0]
000078d941fd4ea9  add rsp, 0xF0
000078d941fd4eb0  pop r11
000078d941fd4eb2  pop r10
000078d941fd4eb4  pop r9
000078d941fd4eb6  pop r8
000078d941fd4eb8  pop rsi
000078d941fd4eb9  pop rdi
000078d941fd4eba  pop rdx
000078d941fd4ebb  pop rcx
000078d941fd4ebc  pop rax
000078d941fd4ebd  add rsp, 0x08
000078d941fd4ec1  jmp 0x000078D941FD0224
000078d941fd4ec6  call 0x000078D941EE20A0
000078d941fd4ecb  jmp 0x000078D941FD0232
000078d941fd4ed0  call 0x000078D941E09D70
000078d941fd4ed5  jmp 0x000078D941FD023C
000078d941fd4eda  sub rsp, 0x08
000078d941fd4ede  push rax
000078d941fd4edf  push rcx
000078d941fd4ee0  push rdx
000078d941fd4ee1  push rdi
000078d941fd4ee2  push rsi
000078d941fd4ee3  push r8
000078d941fd4ee5  push r9
000078d941fd4ee7  push r10
000078d941fd4ee9  push r11
000078d941fd4eeb  sub rsp, 0xF0
000078d941fd4ef2  vmovaps [rsp], xmm0
000078d941fd4ef7  vmovaps [rsp+0x10], xmm1
000078d941fd4efd  vmovaps [rsp+0x20], xmm2
000078d941fd4f03  vmovaps [rsp+0x30], xmm3
000078d941fd4f09  vmovaps [rsp+0x40], xmm4
000078d941fd4f0f  vmovaps [rsp+0x50], xmm5
000078d941fd4f15  vmovaps [rsp+0x60], xmm6
000078d941fd4f1b  vmovaps [rsp+0x70], xmm8
000078d941fd4f21  vmovaps [rsp+0x80], xmm9
000078d941fd4f2a  vmovaps [rsp+0x90], xmm10
000078d941fd4f33  vmovaps [rsp+0xA0], xmm11
000078d941fd4f3c  vmovaps [rsp+0xB0], xmm12
000078d941fd4f45  vmovaps [rsp+0xC0], xmm13
000078d941fd4f4e  vmovaps [rsp+0xD0], xmm14
000078d941fd4f57  vmovaps [rsp+0xE0], xmm15
000078d941fd4f60  sub rsp, 0x30
000078d941fd4f64  movaps [rsp], xmm7
000078d941fd4f68  movaps [rsp+0x10], xmm15
000078d941fd4f6e  movaps [rsp+0x20], xmm10
000078d941fd4f74  lea rdi, [rsp]
000078d941fd4f78  mov esi, 0x00
000078d941fd4f7d  mov rax, 0x59BFBFBAA530
000078d941fd4f87  call rax
000078d941fd4f89  movaps xmm7, [rsp]
000078d941fd4f8d  add rsp, 0x30
000078d941fd4f91  vmovaps xmm0, [rsp]
000078d941fd4f96  vmovaps xmm1, [rsp+0x10]
000078d941fd4f9c  vmovaps xmm2, [rsp+0x20]
000078d941fd4fa2  vmovaps xmm3, [rsp+0x30]
000078d941fd4fa8  vmovaps xmm4, [rsp+0x40]
000078d941fd4fae  vmovaps xmm5, [rsp+0x50]
000078d941fd4fb4  vmovaps xmm6, [rsp+0x60]
000078d941fd4fba  vmovaps xmm8, [rsp+0x70]
000078d941fd4fc0  vmovaps xmm9, [rsp+0x80]
000078d941fd4fc9  vmovaps xmm10, [rsp+0x90]
000078d941fd4fd2  vmovaps xmm11, [rsp+0xA0]
000078d941fd4fdb  vmovaps xmm12, [rsp+0xB0]
000078d941fd4fe4  vmovaps xmm13, [rsp+0xC0]
000078d941fd4fed  vmovaps xmm14, [rsp+0xD0]
000078d941fd4ff6  vmovaps xmm15, [rsp+0xE0]
000078d941fd4fff  add rsp, 0xF0
000078d941fd5006  pop r11
000078d941fd5008  pop r10
000078d941fd500a  pop r9
000078d941fd500c  pop r8
000078d941fd500e  pop rsi
000078d941fd500f  pop rdi
000078d941fd5010  pop rdx
000078d941fd5011  pop rcx
000078d941fd5012  pop rax
000078d941fd5013  add rsp, 0x08
000078d941fd5017  jmp 0x000078D941FD025D
000078d941fd501c  sub rsp, 0x08
000078d941fd5020  push rax
000078d941fd5021  push rcx
000078d941fd5022  push rdx
000078d941fd5023  push rdi
000078d941fd5024  push rsi
000078d941fd5025  push r8
000078d941fd5027  push r9
000078d941fd5029  push r10
000078d941fd502b  push r11
000078d941fd502d  sub rsp, 0xF0
000078d941fd5034  vmovaps [rsp], xmm0
000078d941fd5039  vmovaps [rsp+0x10], xmm1
000078d941fd503f  vmovaps [rsp+0x20], xmm2
000078d941fd5045  vmovaps [rsp+0x30], xmm3
000078d941fd504b  vmovaps [rsp+0x40], xmm4
000078d941fd5051  vmovaps [rsp+0x50], xmm5
000078d941fd5057  vmovaps [rsp+0x60], xmm6
000078d941fd505d  vmovaps [rsp+0x70], xmm7
000078d941fd5063  vmovaps [rsp+0x80], xmm8
000078d941fd506c  vmovaps [rsp+0x90], xmm9
000078d941fd5075  vmovaps [rsp+0xA0], xmm11
000078d941fd507e  vmovaps [rsp+0xB0], xmm12
000078d941fd5087  vmovaps [rsp+0xC0], xmm13
000078d941fd5090  vmovaps [rsp+0xD0], xmm14
000078d941fd5099  vmovaps [rsp+0xE0], xmm15
000078d941fd50a2  sub rsp, 0x30
000078d941fd50a6  movaps [rsp], xmm10
000078d941fd50ab  movaps [rsp+0x10], xmm11
000078d941fd50b1  movaps [rsp+0x20], xmm15
000078d941fd50b7  lea rdi, [rsp]
000078d941fd50bb  mov esi, 0x00
000078d941fd50c0  mov rax, 0x59BFBFBAA530
000078d941fd50ca  call rax
000078d941fd50cc  movaps xmm10, [rsp]
000078d941fd50d1  add rsp, 0x30
000078d941fd50d5  vmovaps xmm0, [rsp]
000078d941fd50da  vmovaps xmm1, [rsp+0x10]
000078d941fd50e0  vmovaps xmm2, [rsp+0x20]
000078d941fd50e6  vmovaps xmm3, [rsp+0x30]
000078d941fd50ec  vmovaps xmm4, [rsp+0x40]
000078d941fd50f2  vmovaps xmm5, [rsp+0x50]
000078d941fd50f8  vmovaps xmm6, [rsp+0x60]
000078d941fd50fe  vmovaps xmm7, [rsp+0x70]
000078d941fd5104  vmovaps xmm8, [rsp+0x80]
000078d941fd510d  vmovaps xmm9, [rsp+0x90]
000078d941fd5116  vmovaps xmm11, [rsp+0xA0]
000078d941fd511f  vmovaps xmm12, [rsp+0xB0]
000078d941fd5128  vmovaps xmm13, [rsp+0xC0]
000078d941fd5131  vmovaps xmm14, [rsp+0xD0]
000078d941fd513a  vmovaps xmm15, [rsp+0xE0]
000078d941fd5143  add rsp, 0xF0
000078d941fd514a  pop r11
000078d941fd514c  pop r10
000078d941fd514e  pop r9
000078d941fd5150  pop r8
000078d941fd5152  pop rsi
000078d941fd5153  pop rdi
000078d941fd5154  pop rdx
000078d941fd5155  pop rcx
000078d941fd5156  pop rax
000078d941fd5157  add rsp, 0x08
000078d941fd515b  jmp 0x000078D941FD028B
000078d941fd5160  sub rsp, 0x08
000078d941fd5164  push rax
000078d941fd5165  push rcx
000078d941fd5166  push rdx
000078d941fd5167  push rdi
000078d941fd5168  push rsi
000078d941fd5169  push r8
000078d941fd516b  push r9
000078d941fd516d  push r10
000078d941fd516f  push r11
000078d941fd5171  sub rsp, 0xF0
000078d941fd5178  vmovaps [rsp], xmm0
000078d941fd517d  vmovaps [rsp+0x10], xmm1
000078d941fd5183  vmovaps [rsp+0x20], xmm2
000078d941fd5189  vmovaps [rsp+0x30], xmm3
000078d941fd518f  vmovaps [rsp+0x40], xmm4
000078d941fd5195  vmovaps [rsp+0x50], xmm5
000078d941fd519b  vmovaps [rsp+0x60], xmm6
000078d941fd51a1  vmovaps [rsp+0x70], xmm7
000078d941fd51a7  vmovaps [rsp+0x80], xmm8
000078d941fd51b0  vmovaps [rsp+0x90], xmm9
000078d941fd51b9  vmovaps [rsp+0xA0], xmm10
000078d941fd51c2  vmovaps [rsp+0xB0], xmm12
000078d941fd51cb  vmovaps [rsp+0xC0], xmm13
000078d941fd51d4  vmovaps [rsp+0xD0], xmm14
000078d941fd51dd  vmovaps [rsp+0xE0], xmm15
000078d941fd51e6  sub rsp, 0x30
000078d941fd51ea  movaps [rsp], xmm11
000078d941fd51ef  movaps [rsp+0x10], xmm12
000078d941fd51f5  movaps [rsp+0x20], xmm15
000078d941fd51fb  lea rdi, [rsp]
000078d941fd51ff  mov esi, 0x00
000078d941fd5204  mov rax, 0x59BFBFBAA530
000078d941fd520e  call rax
000078d941fd5210  movaps xmm11, [rsp]
000078d941fd5215  add rsp, 0x30
000078d941fd5219  vmovaps xmm0, [rsp]
000078d941fd521e  vmovaps xmm1, [rsp+0x10]
000078d941fd5224  vmovaps xmm2, [rsp+0x20]
000078d941fd522a  vmovaps xmm3, [rsp+0x30]
000078d941fd5230  vmovaps xmm4, [rsp+0x40]
000078d941fd5236  vmovaps xmm5, [rsp+0x50]
000078d941fd523c  vmovaps xmm6, [rsp+0x60]
000078d941fd5242  vmovaps xmm7, [rsp+0x70]
000078d941fd5248  vmovaps xmm8, [rsp+0x80]
000078d941fd5251  vmovaps xmm9, [rsp+0x90]
000078d941fd525a  vmovaps xmm10, [rsp+0xA0]
000078d941fd5263  vmovaps xmm12, [rsp+0xB0]
000078d941fd526c  vmovaps xmm13, [rsp+0xC0]
000078d941fd5275  vmovaps xmm14, [rsp+0xD0]
000078d941fd527e  vmovaps xmm15, [rsp+0xE0]
000078d941fd5287  add rsp, 0xF0
000078d941fd528e  pop r11
000078d941fd5290  pop r10
000078d941fd5292  pop r9
000078d941fd5294  pop r8
000078d941fd5296  pop rsi
000078d941fd5297  pop rdi
000078d941fd5298  pop rdx
000078d941fd5299  pop rcx
000078d941fd529a  pop rax
000078d941fd529b  add rsp, 0x08
000078d941fd529f  jmp 0x000078D941FD02B9
000078d941fd52a4  sub rsp, 0x08
000078d941fd52a8  push rax
000078d941fd52a9  push rcx
000078d941fd52aa  push rdx
000078d941fd52ab  push rdi
000078d941fd52ac  push rsi
000078d941fd52ad  push r8
000078d941fd52af  push r9
000078d941fd52b1  push r10
000078d941fd52b3  push r11
000078d941fd52b5  sub rsp, 0xF0
000078d941fd52bc  vmovaps [rsp], xmm0
000078d941fd52c1  vmovaps [rsp+0x10], xmm1
000078d941fd52c7  vmovaps [rsp+0x20], xmm2
000078d941fd52cd  vmovaps [rsp+0x30], xmm3
000078d941fd52d3  vmovaps [rsp+0x40], xmm4
000078d941fd52d9  vmovaps [rsp+0x50], xmm5
000078d941fd52df  vmovaps [rsp+0x60], xmm6
000078d941fd52e5  vmovaps [rsp+0x70], xmm7
000078d941fd52eb  vmovaps [rsp+0x80], xmm8
000078d941fd52f4  vmovaps [rsp+0x90], xmm9
000078d941fd52fd  vmovaps [rsp+0xA0], xmm10
000078d941fd5306  vmovaps [rsp+0xB0], xmm11
000078d941fd530f  vmovaps [rsp+0xC0], xmm12
000078d941fd5318  vmovaps [rsp+0xD0], xmm13
000078d941fd5321  vmovaps [rsp+0xE0], xmm14
000078d941fd532a  sub rsp, 0x30
000078d941fd532e  movaps [rsp], xmm15
000078d941fd5333  movaps [rsp+0x10], xmm13
000078d941fd5339  movaps [rsp+0x20], xmm9
000078d941fd533f  lea rdi, [rsp]
000078d941fd5343  mov esi, 0x00
000078d941fd5348  mov rax, 0x59BFBFBAA530
000078d941fd5352  call rax
000078d941fd5354  movaps xmm15, [rsp]
000078d941fd5359  add rsp, 0x30
000078d941fd535d  vmovaps xmm0, [rsp]
000078d941fd5362  vmovaps xmm1, [rsp+0x10]
000078d941fd5368  vmovaps xmm2, [rsp+0x20]
000078d941fd536e  vmovaps xmm3, [rsp+0x30]
000078d941fd5374  vmovaps xmm4, [rsp+0x40]
000078d941fd537a  vmovaps xmm5, [rsp+0x50]
000078d941fd5380  vmovaps xmm6, [rsp+0x60]
000078d941fd5386  vmovaps xmm7, [rsp+0x70]
000078d941fd538c  vmovaps xmm8, [rsp+0x80]
000078d941fd5395  vmovaps xmm9, [rsp+0x90]
000078d941fd539e  vmovaps xmm10, [rsp+0xA0]
000078d941fd53a7  vmovaps xmm11, [rsp+0xB0]
000078d941fd53b0  vmovaps xmm12, [rsp+0xC0]
000078d941fd53b9  vmovaps xmm13, [rsp+0xD0]
000078d941fd53c2  vmovaps xmm14, [rsp+0xE0]
000078d941fd53cb  add rsp, 0xF0
000078d941fd53d2  pop r11
000078d941fd53d4  pop r10
000078d941fd53d6  pop r9
000078d941fd53d8  pop r8
000078d941fd53da  pop rsi
000078d941fd53db  pop rdi
000078d941fd53dc  pop rdx
000078d941fd53dd  pop rcx
000078d941fd53de  pop rax
000078d941fd53df  add rsp, 0x08
000078d941fd53e3  jmp 0x000078D941FD02D4
000078d941fd53e8  sub rsp, 0x08
000078d941fd53ec  push rax
000078d941fd53ed  push rcx
000078d941fd53ee  push rdx
000078d941fd53ef  push rdi
000078d941fd53f0  push rsi
000078d941fd53f1  push r8
000078d941fd53f3  push r9
000078d941fd53f5  push r10
000078d941fd53f7  push r11
000078d941fd53f9  sub rsp, 0xF0
000078d941fd5400  vmovaps [rsp], xmm0
000078d941fd5405  vmovaps [rsp+0x10], xmm1
000078d941fd540b  vmovaps [rsp+0x20], xmm2
000078d941fd5411  vmovaps [rsp+0x30], xmm3
000078d941fd5417  vmovaps [rsp+0x40], xmm4
000078d941fd541d  vmovaps [rsp+0x50], xmm5
000078d941fd5423  vmovaps [rsp+0x60], xmm6
000078d941fd5429  vmovaps [rsp+0x70], xmm7
000078d941fd542f  vmovaps [rsp+0x80], xmm8
000078d941fd5438  vmovaps [rsp+0x90], xmm9
000078d941fd5441  vmovaps [rsp+0xA0], xmm10
000078d941fd544a  vmovaps [rsp+0xB0], xmm11
000078d941fd5453  vmovaps [rsp+0xC0], xmm12
000078d941fd545c  vmovaps [rsp+0xD0], xmm14
000078d941fd5465  vmovaps [rsp+0xE0], xmm15
000078d941fd546e  sub rsp, 0x30
000078d941fd5472  movaps [rsp], xmm13
000078d941fd5477  movaps [rsp+0x10], xmm8
000078d941fd547d  movaps [rsp+0x20], xmm14
000078d941fd5483  lea rdi, [rsp]
000078d941fd5487  mov esi, 0x00
000078d941fd548c  mov rax, 0x59BFBFBAA530
000078d941fd5496  call rax
000078d941fd5498  movaps xmm13, [rsp]
000078d941fd549d  add rsp, 0x30
000078d941fd54a1  vmovaps xmm0, [rsp]
000078d941fd54a6  vmovaps xmm1, [rsp+0x10]
000078d941fd54ac  vmovaps xmm2, [rsp+0x20]
000078d941fd54b2  vmovaps xmm3, [rsp+0x30]
000078d941fd54b8  vmovaps xmm4, [rsp+0x40]
000078d941fd54be  vmovaps xmm5, [rsp+0x50]
000078d941fd54c4  vmovaps xmm6, [rsp+0x60]
000078d941fd54ca  vmovaps xmm7, [rsp+0x70]
000078d941fd54d0  vmovaps xmm8, [rsp+0x80]
000078d941fd54d9  vmovaps xmm9, [rsp+0x90]
000078d941fd54e2  vmovaps xmm10, [rsp+0xA0]
000078d941fd54eb  vmovaps xmm11, [rsp+0xB0]
000078d941fd54f4  vmovaps xmm12, [rsp+0xC0]
000078d941fd54fd  vmovaps xmm14, [rsp+0xD0]
000078d941fd5506  vmovaps xmm15, [rsp+0xE0]
000078d941fd550f  add rsp, 0xF0
000078d941fd5516  pop r11
000078d941fd5518  pop r10
000078d941fd551a  pop r9
000078d941fd551c  pop r8
000078d941fd551e  pop rsi
000078d941fd551f  pop rdi
000078d941fd5520  pop rdx
000078d941fd5521  pop rcx
000078d941fd5522  pop rax
000078d941fd5523  add rsp, 0x08
000078d941fd5527  jmp 0x000078D941FD02F7
000078d941fd552c  sub rsp, 0x08
000078d941fd5530  push rax
000078d941fd5531  push rcx
000078d941fd5532  push rdx
000078d941fd5533  push rdi
000078d941fd5534  push rsi
000078d941fd5535  push r8
000078d941fd5537  push r9
000078d941fd5539  push r10
000078d941fd553b  push r11
000078d941fd553d  sub rsp, 0xF0
000078d941fd5544  vmovaps [rsp], xmm0
000078d941fd5549  vmovaps [rsp+0x10], xmm1
000078d941fd554f  vmovaps [rsp+0x20], xmm2
000078d941fd5555  vmovaps [rsp+0x30], xmm3
000078d941fd555b  vmovaps [rsp+0x40], xmm4
000078d941fd5561  vmovaps [rsp+0x50], xmm5
000078d941fd5567  vmovaps [rsp+0x60], xmm6
000078d941fd556d  vmovaps [rsp+0x70], xmm7
000078d941fd5573  vmovaps [rsp+0x80], xmm8
000078d941fd557c  vmovaps [rsp+0x90], xmm9
000078d941fd5585  vmovaps [rsp+0xA0], xmm10
000078d941fd558e  vmovaps [rsp+0xB0], xmm11
000078d941fd5597  vmovaps [rsp+0xC0], xmm12
000078d941fd55a0  vmovaps [rsp+0xD0], xmm13
000078d941fd55a9  vmovaps [rsp+0xE0], xmm15
000078d941fd55b2  sub rsp, 0x30
000078d941fd55b6  movaps [rsp], xmm14
000078d941fd55bb  movaps [rsp+0x10], xmm1
000078d941fd55c0  movaps [rsp+0x20], xmm10
000078d941fd55c6  lea rdi, [rsp]
000078d941fd55ca  mov esi, 0x00
000078d941fd55cf  mov rax, 0x59BFBFBAA530
000078d941fd55d9  call rax
000078d941fd55db  movaps xmm14, [rsp]
000078d941fd55e0  add rsp, 0x30
000078d941fd55e4  vmovaps xmm0, [rsp]
000078d941fd55e9  vmovaps xmm1, [rsp+0x10]
000078d941fd55ef  vmovaps xmm2, [rsp+0x20]
000078d941fd55f5  vmovaps xmm3, [rsp+0x30]
000078d941fd55fb  vmovaps xmm4, [rsp+0x40]
000078d941fd5601  vmovaps xmm5, [rsp+0x50]
000078d941fd5607  vmovaps xmm6, [rsp+0x60]
000078d941fd560d  vmovaps xmm7, [rsp+0x70]
000078d941fd5613  vmovaps xmm8, [rsp+0x80]
000078d941fd561c  vmovaps xmm9, [rsp+0x90]
000078d941fd5625  vmovaps xmm10, [rsp+0xA0]
000078d941fd562e  vmovaps xmm11, [rsp+0xB0]
000078d941fd5637  vmovaps xmm12, [rsp+0xC0]
000078d941fd5640  vmovaps xmm13, [rsp+0xD0]
000078d941fd5649  vmovaps xmm15, [rsp+0xE0]
000078d941fd5652  add rsp, 0xF0
000078d941fd5659  pop r11
000078d941fd565b  pop r10
000078d941fd565d  pop r9
000078d941fd565f  pop r8
000078d941fd5661  pop rsi
000078d941fd5662  pop rdi
000078d941fd5663  pop rdx
000078d941fd5664  pop rcx
000078d941fd5665  pop rax
000078d941fd5666  add rsp, 0x08
000078d941fd566a  jmp 0x000078D941FD031A
000078d941fd566f  sub rsp, 0x08
000078d941fd5673  push rax
000078d941fd5674  push rcx
000078d941fd5675  push rdx
000078d941fd5676  push rdi
000078d941fd5677  push rsi
000078d941fd5678  push r8
000078d941fd567a  push r9
000078d941fd567c  push r10
000078d941fd567e  push r11
000078d941fd5680  sub rsp, 0xF0
000078d941fd5687  vmovaps [rsp], xmm0
000078d941fd568c  vmovaps [rsp+0x10], xmm2
000078d941fd5692  vmovaps [rsp+0x20], xmm3
000078d941fd5698  vmovaps [rsp+0x30], xmm4
000078d941fd569e  vmovaps [rsp+0x40], xmm5
000078d941fd56a4  vmovaps [rsp+0x50], xmm6
000078d941fd56aa  vmovaps [rsp+0x60], xmm7
000078d941fd56b0  vmovaps [rsp+0x70], xmm8
000078d941fd56b6  vmovaps [rsp+0x80], xmm9
000078d941fd56bf  vmovaps [rsp+0x90], xmm10
000078d941fd56c8  vmovaps [rsp+0xA0], xmm11
000078d941fd56d1  vmovaps [rsp+0xB0], xmm12
000078d941fd56da  vmovaps [rsp+0xC0], xmm13
000078d941fd56e3  vmovaps [rsp+0xD0], xmm14
000078d941fd56ec  vmovaps [rsp+0xE0], xmm15
000078d941fd56f5  sub rsp, 0x30
000078d941fd56f9  movaps [rsp], xmm1
000078d941fd56fd  movaps [rsp+0x10], xmm7
000078d941fd5702  movaps [rsp+0x20], xmm11
000078d941fd5708  lea rdi, [rsp]
000078d941fd570c  mov esi, 0x00
000078d941fd5711  mov rax, 0x59BFBFBAA530
000078d941fd571b  call rax
000078d941fd571d  movaps xmm1, [rsp]
000078d941fd5721  add rsp, 0x30
000078d941fd5725  vmovaps xmm0, [rsp]
000078d941fd572a  vmovaps xmm2, [rsp+0x10]
000078d941fd5730  vmovaps xmm3, [rsp+0x20]
000078d941fd5736  vmovaps xmm4, [rsp+0x30]
000078d941fd573c  vmovaps xmm5, [rsp+0x40]
000078d941fd5742  vmovaps xmm6, [rsp+0x50]
000078d941fd5748  vmovaps xmm7, [rsp+0x60]
000078d941fd574e  vmovaps xmm8, [rsp+0x70]
000078d941fd5754  vmovaps xmm9, [rsp+0x80]
000078d941fd575d  vmovaps xmm10, [rsp+0x90]
000078d941fd5766  vmovaps xmm11, [rsp+0xA0]
000078d941fd576f  vmovaps xmm12, [rsp+0xB0]
000078d941fd5778  vmovaps xmm13, [rsp+0xC0]
000078d941fd5781  vmovaps xmm14, [rsp+0xD0]
000078d941fd578a  vmovaps xmm15, [rsp+0xE0]
000078d941fd5793  add rsp, 0xF0
000078d941fd579a  pop r11
000078d941fd579c  pop r10
000078d941fd579e  pop r9
000078d941fd57a0  pop r8
000078d941fd57a2  pop rsi
000078d941fd57a3  pop rdi
000078d941fd57a4  pop rdx
000078d941fd57a5  pop rcx
000078d941fd57a6  pop rax
000078d941fd57a7  add rsp, 0x08
000078d941fd57ab  jmp 0x000078D941FD033B
000078d941fd57b0  call 0x000078D941E0E880
000078d941fd57b5  jmp 0x000078D941FD034E
000078d941fd57ba  call 0x000078D941E0C380
000078d941fd57bf  jmp 0x000078D941FD0359
000078d941fd57c4  call 0x000078D941E0D600
000078d941fd57c9  jmp 0x000078D941FD0364
000078d941fd57ce  call 0x000078D941DFF540
000078d941fd57d3  jmp 0x000078D941FD036F
000078d941fd57d8  int3
000078d941fd57d9  nop [rax], eax
000078d941fd57e0  mov rax, [r15+0x40]
000078d941fd57e4  mov r14, [r15+0x58]
000078d941fd57e8  lea r12, [rax+r14*1]
000078d941fd57ec  movaps xmm1, [r15+0x1D0]
000078d941fd57f4  vmovaps [rsp+0x10], xmm1
000078d941fd57fa  vmovaps xmm15, [rsp+0x10]
000078d941fd5800  por xmm1, xmm15
000078d941fd5805  movaps xmm14, [r15+0x1A0]
000078d941fd580d  vmovaps [rsp+0x10], xmm14
000078d941fd5813  vmovaps xmm13, [rsp+0x10]
000078d941fd5819  por xmm14, xmm13
000078d941fd581e  lea rax, [r12+0x30]
000078d941fd5823  mov r11, [r13+rax*1]
000078d941fd5828  lea rax, [r12+0x38]
000078d941fd582d  mov r10, [r13+rax*1]
000078d941fd5832  movq xmm13, r11
000078d941fd5837  movq xmm12, r10
000078d941fd583c  movq xmm13, xmm13
000078d941fd5841  vmovaps [rsp+0x10], xmm13
000078d941fd5847  movq xmm13, xmm13
000078d941fd584c  movaps [r15+0x130], xmm13
000078d941fd5854  movq xmm12, xmm12
000078d941fd5859  vmovaps [rsp+0x20], xmm12
000078d941fd585f  movq xmm12, xmm12
000078d941fd5864  movaps [r15+0x280], xmm12
000078d941fd586c  movaps xmm13, [r15+0x270]
000078d941fd5874  vmovaps [rsp+0x30], xmm13
000078d941fd587a  vmovaps xmm12, [rsp+0x30]
000078d941fd5880  por xmm13, xmm12
000078d941fd5885  lea rax, [r12+0x20]
000078d941fd588a  mov r11, [r13+rax*1]
000078d941fd588f  lea rax, [r12+0x28]
000078d941fd5894  mov r10, [r13+rax*1]
000078d941fd5899  movq xmm12, r11
000078d941fd589e  movq xmm11, r10
000078d941fd58a3  movq xmm12, xmm12
000078d941fd58a8  vmovaps [rsp+0x30], xmm12
000078d941fd58ae  movq xmm12, xmm12
000078d941fd58b3  movaps [r15+0x150], xmm12
000078d941fd58bb  movq xmm11, xmm11
000078d941fd58c0  vmovaps [rsp+0x40], xmm11
000078d941fd58c6  movq xmm11, xmm11
000078d941fd58cb  movaps [r15+0x140], xmm11
000078d941fd58d3  lea rax, [r12+0x10]
000078d941fd58d8  mov r11, [r13+rax*1]
000078d941fd58dd  lea rax, [r12+0x18]
000078d941fd58e2  mov r10, [r13+rax*1]
000078d941fd58e7  movq xmm12, r11
000078d941fd58ec  movq xmm11, r10
000078d941fd58f1  movq xmm12, xmm12
000078d941fd58f6  vmovaps [rsp+0x50], xmm12
000078d941fd58fc  movq xmm12, xmm12
000078d941fd5901  movaps [r15+0x170], xmm12
000078d941fd5909  movq xmm11, xmm11
000078d941fd590e  vmovaps [rsp+0x60], xmm11
000078d941fd5914  movq xmm11, xmm11
000078d941fd5919  movaps [r15+0x160], xmm11
000078d941fd5921  mov rax, [r13+r12*1]
000078d941fd5926  vmovq xmm12, rax
000078d941fd592b  vpbroadcastq xmm12, xmm12
000078d941fd5930  lea rax, [r12+0x08]
000078d941fd5935  mov r12, [r13+rax*1]
000078d941fd593a  movq xmm11, r12
000078d941fd593f  movaps [r15+0x230], xmm11
000078d941fd5947  mov rax, [r15+0xF8]
000078d941fd594e  lea r12, [rax+0x50]
000078d941fd5952  movups xmm11, [r13+r12*1]
000078d941fd5958  lea r12, [rax+0x60]
000078d941fd595c  movups xmm10, [r13+r12*1]
000078d941fd5962  lea r12, [rax+0x30]
000078d941fd5966  movups xmm9, [r13+r12*1]
000078d941fd596c  mov r12, [r15+0x50]
000078d941fd5970  lea r11, [r12+r14*1]
000078d941fd5974  mov [r15+0x60], r11
000078d941fd5978  lea r12, [r14+0x40]
000078d941fd597c  mov [r15+0x58], r12
000078d941fd5980  movaps xmm8, xmm12
000078d941fd5984  mulpd xmm8, xmm15
000078d941fd5989  vcmppd xmm7, xmm8, xmm8, 0x03
000078d941fd598f  ptest xmm7, xmm7
000078d941fd5994  jnz 0x000078D941FD67B7
000078d941fd599a  movq xmm15, qword ptr [r15+0x230]
000078d941fd59a3  vmovaps [rsp+0x70], xmm15
000078d941fd59a9  vpermilpd xmm15, xmm15, 0x00
000078d941fd59af  movaps xmm7, xmm9
000078d941fd59b3  mulpd xmm7, xmm15
000078d941fd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000078d941fd59bd  ptest xmm6, xmm6
000078d941fd59c2  jnz 0x000078D941FD68FB
000078d941fd59c8  vxorps xmm15, xmm15, xmm15
000078d941fd59cd  vpbroadcastq xmm15, xmm15
000078d941fd59d2  movaps xmm9, xmm12
000078d941fd59d6  mulpd xmm9, xmm10
000078d941fd59db  vcmppd xmm6, xmm9, xmm9, 0x03
000078d941fd59e1  ptest xmm6, xmm6
000078d941fd59e6  jnz 0x000078D941FD6A3D
000078d941fd59ec  movaps xmm10, xmm12
000078d941fd59f0  mulpd xmm10, xmm11
000078d941fd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000078d941fd59fb  ptest xmm6, xmm6
000078d941fd5a00  jnz 0x000078D941FD6B81
000078d941fd5a06  movaps xmm11, [r15+0x1F0]
000078d941fd5a0e  movaps xmm6, xmm12
000078d941fd5a12  mulpd xmm6, xmm11
000078d941fd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000078d941fd5a1c  ptest xmm5, xmm5
000078d941fd5a21  jnz 0x000078D941FD6CC5
000078d941fd5a27  movaps xmm12, [r15+0x2A0]
000078d941fd5a2f  vmovaps [rsp+0x80], xmm12
000078d941fd5a38  vmovaps xmm11, [rsp+0x80]
000078d941fd5a41  por xmm12, xmm11
000078d941fd5a46  movaps xmm11, [r15+0x250]
000078d941fd5a4e  vmovaps [rsp+0x80], xmm11
000078d941fd5a57  vmovaps xmm5, [rsp+0x80]
000078d941fd5a60  por xmm11, xmm5
000078d941fd5a65  vmovaps xmm4, [rsp+0x70]
000078d941fd5a6b  vpermilpd xmm4, xmm4, 0x00
000078d941fd5a71  movaps xmm3, xmm5
000078d941fd5a74  mulpd xmm3, xmm4
000078d941fd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000078d941fd5a7d  ptest xmm2, xmm2
000078d941fd5a82  jnz 0x000078D941FD6E07
000078d941fd5a88  mov [rsp+0x80], rax
000078d941fd5a90  xor eax, eax
000078d941fd5a92  mov r14d, 0x200
000078d941fd5a98  cmp r12, r14
000078d941fd5a9b  cmc
000078d941fd5a9c  lahf
000078d941fd5a9d  seto al
000078d941fd5aa0  mov [r15+0x108], eax
000078d941fd5aa7  movaps xmm5, xmm8
000078d941fd5aab  addpd xmm5, xmm15
000078d941fd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000078d941fd5ab5  ptest xmm4, xmm4
000078d941fd5aba  jnz 0x000078D941FD6F47
000078d941fd5ac0  movaps xmm8, [r15+0x1B0]
000078d941fd5ac8  movaps xmm4, xmm9
000078d941fd5acc  addpd xmm4, xmm8
000078d941fd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000078d941fd5ad6  ptest xmm2, xmm2
000078d941fd5adb  jnz 0x000078D941FD7089
000078d941fd5ae1  movaps xmm9, xmm10
000078d941fd5ae5  addpd xmm9, xmm8
000078d941fd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000078d941fd5af0  ptest xmm2, xmm2
000078d941fd5af5  jnz 0x000078D941FD71CB
000078d941fd5afb  movaps xmm10, [r15+0x2F0]
000078d941fd5b03  vmovaps [rsp+0x90], xmm10
000078d941fd5b0c  vmovaps xmm8, [rsp+0x90]
000078d941fd5b15  por xmm10, xmm8
000078d941fd5b1a  movaps xmm8, [r15+0x2E0]
000078d941fd5b22  vmovaps [rsp+0x90], xmm8
000078d941fd5b2b  vmovaps xmm2, [rsp+0x90]
000078d941fd5b34  por xmm8, xmm2
000078d941fd5b39  movaps xmm2, [r15+0x2D0]
000078d941fd5b41  vmovaps [rsp+0x90], xmm2
000078d941fd5b4a  vmovaps [rsp+0xA0], xmm1
000078d941fd5b53  vmovaps xmm1, [rsp+0x90]
000078d941fd5b5c  por xmm2, xmm1
000078d941fd5b60  movaps xmm1, [r15+0x200]
000078d941fd5b68  vmovaps [rsp+0x90], xmm1
000078d941fd5b71  vmovaps [rsp+0xB0], xmm15
000078d941fd5b7a  vmovaps xmm15, [rsp+0x90]
000078d941fd5b83  por xmm1, xmm15
000078d941fd5b88  movaps xmm15, [r15+0x1C0]
000078d941fd5b90  vmovaps [rsp+0x90], xmm15
000078d941fd5b99  vmovaps [rsp+0xC0], xmm1
000078d941fd5ba2  vmovaps xmm1, [rsp+0x90]
000078d941fd5bab  por xmm15, xmm1
000078d941fd5bb0  movaps xmm1, [r15+0x190]
000078d941fd5bb8  vmovaps [rsp+0x90], xmm1
000078d941fd5bc1  vmovaps [rsp+0xD0], xmm15
000078d941fd5bca  vmovaps xmm15, [rsp+0x90]
000078d941fd5bd3  por xmm1, xmm15
000078d941fd5bd8  movaps xmm15, [r15+0x300]
000078d941fd5be0  vmovaps [rsp+0x90], xmm15
000078d941fd5be9  vmovaps [rsp+0xE0], xmm1
000078d941fd5bf2  vmovaps xmm1, [rsp+0x90]
000078d941fd5bfb  por xmm15, xmm1
000078d941fd5c00  mov rax, [rsp+0x80]
000078d941fd5c08  lea r14, [rax+0xA0]
000078d941fd5c0f  movups xmm1, [r13+r14*1]
000078d941fd5c15  lea r14, [rax+0xB0]
000078d941fd5c1c  vmovaps [rsp+0x80], xmm1
000078d941fd5c25  movups xmm1, [r13+r14*1]
000078d941fd5c2b  vmovaps [rsp+0x90], xmm1
000078d941fd5c34  vmovaps [rsp+0xF0], xmm15
000078d941fd5c3d  vmovaps xmm15, [rsp+0xB0]
000078d941fd5c46  vmovaps [rsp+0xB0], xmm14
000078d941fd5c4f  movaps xmm1, xmm6
000078d941fd5c52  addpd xmm1, xmm15
000078d941fd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000078d941fd5c5c  ptest xmm14, xmm14
000078d941fd5c62  jnz 0x000078D941FD7323
000078d941fd5c68  lea r14, [rax+0xF0]
000078d941fd5c6f  movups xmm15, [r13+r14*1]
000078d941fd5c75  movaps xmm14, xmm4
000078d941fd5c79  addpd xmm14, xmm3
000078d941fd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000078d941fd5c84  ptest xmm6, xmm6
000078d941fd5c89  jnz 0x000078D941FD746E
000078d941fd5c8f  movaps xmm6, xmm9
000078d941fd5c93  addpd xmm6, xmm7
000078d941fd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000078d941fd5c9c  ptest xmm4, xmm4
000078d941fd5ca1  jnz 0x000078D941FD75B0
000078d941fd5ca7  vmovaps xmm9, [rsp+0x70]
000078d941fd5cad  vpermilpd xmm9, xmm9, 0x00
000078d941fd5cb3  vmovaps xmm4, [rsp+0x90]
000078d941fd5cbc  movaps xmm7, xmm4
000078d941fd5cbf  mulpd xmm7, xmm9
000078d941fd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000078d941fd5cc9  ptest xmm3, xmm3
000078d941fd5cce  jnz 0x000078D941FD76F1
000078d941fd5cd4  vmovaps xmm9, [rsp+0x50]
000078d941fd5cda  vpermilpd xmm9, xmm9, 0x00
000078d941fd5ce0  movaps xmm4, xmm15
000078d941fd5ce4  mulpd xmm4, xmm9
000078d941fd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000078d941fd5cee  ptest xmm3, xmm3
000078d941fd5cf3  jnz 0x000078D941FD7832
000078d941fd5cf9  lea r14, [rax+0xE0]
000078d941fd5d00  movups xmm15, [r13+r14*1]
000078d941fd5d06  vmovaps xmm9, [rsp+0x70]
000078d941fd5d0c  vpermilpd xmm9, xmm9, 0x00
000078d941fd5d12  vmovaps [rsp+0x70], xmm1
000078d941fd5d18  vmovaps xmm1, [rsp+0x80]
000078d941fd5d21  vmovaps [rsp+0x80], xmm15
000078d941fd5d2a  movaps xmm3, xmm1
000078d941fd5d2d  mulpd xmm3, xmm9
000078d941fd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000078d941fd5d37  ptest xmm15, xmm15
000078d941fd5d3d  jnz 0x000078D941FD797E
000078d941fd5d43  vmovaps xmm1, [rsp+0xF0]
000078d941fd5d4c  vmovaps xmm15, [rsp+0xF0]
000078d941fd5d55  por xmm1, xmm15
000078d941fd5d5a  movaps [r15+0x300], xmm1
000078d941fd5d62  vmovaps xmm15, [rsp+0xE0]
000078d941fd5d6b  vmovaps xmm9, [rsp+0xE0]
000078d941fd5d74  por xmm15, xmm9
000078d941fd5d79  movaps [r15+0x190], xmm15
000078d941fd5d81  vmovaps xmm9, [rsp+0x50]
000078d941fd5d87  vpermilpd xmm9, xmm9, 0x00
000078d941fd5d8d  vmovaps [rsp+0x90], xmm1
000078d941fd5d96  vmovaps [rsp+0xE0], xmm15
000078d941fd5d9f  vmovaps xmm15, [rsp+0x80]
000078d941fd5da8  vmovaps [rsp+0x80], xmm14
000078d941fd5db1  movaps xmm1, xmm15
000078d941fd5db5  mulpd xmm1, xmm9
000078d941fd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000078d941fd5dbf  ptest xmm14, xmm14
000078d941fd5dc5  jnz 0x000078D941FD7ABF
000078d941fd5dcb  lea r14, [rax+0x90]
000078d941fd5dd2  movups xmm15, [r13+r14*1]
000078d941fd5dd8  vmovaps xmm14, [rsp+0xD0]
000078d941fd5de1  vmovaps xmm9, [rsp+0xD0]
000078d941fd5dea  por xmm14, xmm9
000078d941fd5def  movaps [r15+0x1C0], xmm14
000078d941fd5df7  vmovaps xmm9, [rsp+0xC0]
000078d941fd5e00  vmovaps [rsp+0xD0], xmm1
000078d941fd5e09  vmovaps xmm1, [rsp+0xC0]
000078d941fd5e12  por xmm9, xmm1
000078d941fd5e17  movaps [r15+0x200], xmm9
000078d941fd5e1f  vmovaps [rsp+0xC0], xmm2
000078d941fd5e28  vmovaps xmm1, [rsp+0xC0]
000078d941fd5e31  por xmm2, xmm1
000078d941fd5e35  movaps [r15+0x2D0], xmm2
000078d941fd5e3d  vmovaps [rsp+0xC0], xmm8
000078d941fd5e46  vmovaps xmm1, [rsp+0xC0]
000078d941fd5e4f  por xmm8, xmm1
000078d941fd5e54  movaps [r15+0x2E0], xmm8
000078d941fd5e5c  vmovaps [rsp+0xC0], xmm15
000078d941fd5e65  movaps xmm1, xmm5
000078d941fd5e68  addpd xmm1, xmm7
000078d941fd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000078d941fd5e71  ptest xmm15, xmm15
000078d941fd5e77  jnz 0x000078D941FD7C0B
000078d941fd5e7d  vmovaps xmm15, [rsp+0x50]
000078d941fd5e83  vpermilpd xmm15, xmm15, 0x00
000078d941fd5e89  vmovaps xmm5, [rsp+0xC0]
000078d941fd5e92  vmovaps [rsp+0xC0], xmm1
000078d941fd5e9b  movaps xmm7, xmm5
000078d941fd5e9e  mulpd xmm7, xmm15
000078d941fd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000078d941fd5ea8  ptest xmm1, xmm1
000078d941fd5ead  jnz 0x000078D941FD7D4B
000078d941fd5eb3  lea r14, [rax+0x80]
000078d941fd5eba  movups xmm1, [r13+r14*1]
000078d941fd5ec0  vmovaps xmm5, [rsp+0x70]
000078d941fd5ec6  vmovaps [rsp+0x70], xmm1
000078d941fd5ecc  movaps xmm15, xmm5
000078d941fd5ed0  addpd xmm15, xmm3
000078d941fd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000078d941fd5edb  ptest xmm1, xmm1
000078d941fd5ee0  jnz 0x000078D941FD7E96
000078d941fd5ee6  vmovaps xmm5, [rsp+0x80]
000078d941fd5eef  movaps xmm1, xmm5
000078d941fd5ef2  addpd xmm1, xmm4
000078d941fd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000078d941fd5efb  ptest xmm3, xmm3
000078d941fd5f00  jnz 0x000078D941FD7FD8
000078d941fd5f06  vmovaps [rsp+0x80], xmm10
000078d941fd5f0f  vmovaps xmm5, [rsp+0x80]
000078d941fd5f18  por xmm10, xmm5
000078d941fd5f1d  movaps [r15+0x2F0], xmm10
000078d941fd5f25  vmovaps xmm5, [rsp+0x50]
000078d941fd5f2b  vpermilpd xmm5, xmm5, 0x00
000078d941fd5f31  vmovaps xmm3, [rsp+0x70]
000078d941fd5f37  vmovaps [rsp+0x50], xmm1
000078d941fd5f3d  movaps xmm4, xmm3
000078d941fd5f40  mulpd xmm4, xmm5
000078d941fd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000078d941fd5f49  ptest xmm1, xmm1
000078d941fd5f4e  jnz 0x000078D941FD8118
000078d941fd5f54  lea r14, [rax+0xD0]
000078d941fd5f5b  movups xmm1, [r13+r14*1]
000078d941fd5f61  vmovaps xmm3, [rsp+0xD0]
000078d941fd5f6a  vmovaps [rsp+0x70], xmm1
000078d941fd5f70  movaps xmm5, xmm6
000078d941fd5f73  addpd xmm5, xmm3
000078d941fd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000078d941fd5f7c  ptest xmm1, xmm1
000078d941fd5f81  jnz 0x000078D941FD8262
000078d941fd5f87  vmovaps xmm1, [rsp+0x60]
000078d941fd5f8d  vpermilpd xmm1, xmm1, 0x00
000078d941fd5f93  movaps xmm6, xmm9
000078d941fd5f97  mulpd xmm6, xmm1
000078d941fd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000078d941fd5fa0  ptest xmm3, xmm3
000078d941fd5fa5  jnz 0x000078D941FD83A2
000078d941fd5fab  movaps [r15+0x260], xmm6
000078d941fd5fb3  vxorps xmm1, xmm1, xmm1
000078d941fd5fb7  vpbroadcastq xmm1, xmm1
000078d941fd5fbc  movaps [r15+0x1B0], xmm1
000078d941fd5fc4  vmovaps xmm1, [rsp+0x60]
000078d941fd5fca  vpermilpd xmm1, xmm1, 0x00
000078d941fd5fd0  vmovaps xmm3, [rsp+0x70]
000078d941fd5fd6  vmovaps [rsp+0x70], xmm15
000078d941fd5fdc  movaps xmm9, xmm3
000078d941fd5fe0  mulpd xmm9, xmm1
000078d941fd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000078d941fd5feb  ptest xmm15, xmm15
000078d941fd5ff1  jnz 0x000078D941FD84E3
000078d941fd5ff7  lea r14, [rax+0xC0]
000078d941fd5ffe  movups xmm1, [r13+r14*1]
000078d941fd6004  vmovaps xmm3, [rsp+0xC0]
000078d941fd600d  vmovaps [rsp+0x80], xmm1
000078d941fd6016  movaps xmm15, xmm3
000078d941fd601a  addpd xmm15, xmm7
000078d941fd601f  vcmppd xmm1, xmm15, xmm15, 0x03
000078d941fd6025  ptest xmm1, xmm1
000078d941fd602a  jnz 0x000078D941FD862F
000078d941fd6030  vmovaps [rsp+0xC0], xmm13
000078d941fd6039  vmovaps xmm1, [rsp+0xC0]
000078d941fd6042  por xmm13, xmm1
000078d941fd6047  movaps [r15+0x270], xmm13
000078d941fd604f  vmovaps xmm1, [rsp+0xB0]
000078d941fd6058  vmovaps xmm7, [rsp+0xB0]
000078d941fd6061  por xmm1, xmm7
000078d941fd6065  movaps [r15+0x1A0], xmm1
000078d941fd606d  vmovaps xmm1, [rsp+0x60]
000078d941fd6073  vpermilpd xmm1, xmm1, 0x00
000078d941fd6079  vmovaps [rsp+0xB0], xmm1
000078d941fd6082  vmovaps xmm1, [rsp+0x80]
000078d941fd608b  vmovaps [rsp+0x80], xmm15
000078d941fd6094  vmovaps xmm15, [rsp+0xB0]
000078d941fd609d  vmovaps [rsp+0xB0], xmm14
000078d941fd60a6  movaps xmm3, xmm1
000078d941fd60a9  mulpd xmm3, xmm15
000078d941fd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000078d941fd60b3  ptest xmm14, xmm14
000078d941fd60b9  jnz 0x000078D941FD8771
000078d941fd60bf  lea r14, [rax+0x20]
000078d941fd60c3  movups xmm1, [r13+r14*1]
000078d941fd60c9  movaps [r15+0x110], xmm1
000078d941fd60d1  vmovaps xmm14, [rsp+0x70]
000078d941fd60d7  vmovaps [rsp+0x70], xmm1
000078d941fd60dd  movaps xmm15, xmm14
000078d941fd60e1  addpd xmm15, xmm4
000078d941fd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000078d941fd60ec  ptest xmm1, xmm1
000078d941fd60f1  jnz 0x000078D941FD88BC
000078d941fd60f7  vmovaps xmm1, [rsp+0x60]
000078d941fd60fd  vpermilpd xmm1, xmm1, 0x00
000078d941fd6103  movaps xmm14, xmm2
000078d941fd6107  mulpd xmm14, xmm1
000078d941fd610c  vcmppd xmm4, xmm14, xmm14, 0x03
000078d941fd6112  ptest xmm4, xmm4
000078d941fd6117  jnz 0x000078D941FD89FF
000078d941fd611d  vmovaps xmm4, [rsp+0x50]
000078d941fd6123  movaps xmm1, xmm4
000078d941fd6126  addpd xmm1, xmm9
000078d941fd612b  vcmppd xmm2, xmm1, xmm1, 0x03
000078d941fd6130  ptest xmm2, xmm2
000078d941fd6135  jnz 0x000078D941FD8B41
000078d941fd613b  vmovaps xmm9, [rsp+0x30]
000078d941fd6141  vpermilpd xmm9, xmm9, 0x00
000078d941fd6147  vmovaps xmm2, [rsp+0x70]
000078d941fd614d  vmovaps [rsp+0x50], xmm1
000078d941fd6153  movaps xmm4, xmm2
000078d941fd6156  mulpd xmm4, xmm9
000078d941fd615b  vcmppd xmm1, xmm4, xmm4, 0x03
000078d941fd6160  ptest xmm1, xmm1
000078d941fd6165  jnz 0x000078D941FD8C82
000078d941fd616b  vmovaps xmm1, [rsp+0x30]
000078d941fd6171  vpermilpd xmm1, xmm1, 0x00
000078d941fd6177  vmovaps xmm2, [rsp+0x90]
000078d941fd6180  vmovaps [rsp+0x60], xmm15
000078d941fd6186  movaps xmm9, xmm2
000078d941fd618a  mulpd xmm9, xmm1
000078d941fd618f  vcmppd xmm15, xmm9, xmm9, 0x03
000078d941fd6195  ptest xmm15, xmm15
000078d941fd619b  jnz 0x000078D941FD8DC3
000078d941fd61a1  vmovaps xmm15, [rsp+0x80]
000078d941fd61aa  movaps xmm1, xmm15
000078d941fd61ae  addpd xmm1, xmm6
000078d941fd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000078d941fd61b7  ptest xmm2, xmm2
000078d941fd61bc  jnz 0x000078D941FD8F05
000078d941fd61c2  movaps xmm15, xmm5
000078d941fd61c6  addpd xmm15, xmm3
000078d941fd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000078d941fd61d1  ptest xmm6, xmm6
000078d941fd61d6  jnz 0x000078D941FD9046
000078d941fd61dc  vmovaps xmm6, [rsp+0x30]
000078d941fd61e2  vpermilpd xmm6, xmm6, 0x00
000078d941fd61e8  movaps xmm5, xmm8
000078d941fd61ec  mulpd xmm5, xmm6
000078d941fd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000078d941fd61f5  ptest xmm3, xmm3
000078d941fd61fa  jnz 0x000078D941FD9188
000078d941fd6200  vmovaps xmm8, [rsp+0x30]
000078d941fd6206  vpermilpd xmm8, xmm8, 0x00
000078d941fd620c  movaps xmm6, xmm10
000078d941fd6210  mulpd xmm6, xmm8
000078d941fd6215  vcmppd xmm3, xmm6, xmm6, 0x03
000078d941fd621a  ptest xmm3, xmm3
000078d941fd621f  jnz 0x000078D941FD92C9
000078d941fd6225  vmovaps xmm8, [rsp+0x60]
000078d941fd622b  movaps xmm10, xmm8
000078d941fd622f  addpd xmm10, xmm14
000078d941fd6234  vcmppd xmm3, xmm10, xmm10, 0x03
000078d941fd623a  ptest xmm3, xmm3
000078d941fd623f  jnz 0x000078D941FD940B
000078d941fd6245  vmovaps xmm8, [rsp+0x50]
000078d941fd624b  movaps xmm14, xmm8
000078d941fd624f  addpd xmm14, xmm4
000078d941fd6254  vcmppd xmm3, xmm14, xmm14, 0x03
000078d941fd625a  ptest xmm3, xmm3
000078d941fd625f  jnz 0x000078D941FD954F
000078d941fd6265  vmovaps xmm8, [rsp+0x40]
000078d941fd626b  vpermilpd xmm8, xmm8, 0x00
000078d941fd6271  movaps xmm4, xmm13
000078d941fd6275  mulpd xmm4, xmm8
000078d941fd627a  vcmppd xmm3, xmm4, xmm4, 0x03
000078d941fd627f  ptest xmm3, xmm3
000078d941fd6284  jnz 0x000078D941FD9692
000078d941fd628a  movaps xmm13, xmm15
000078d941fd628e  addpd xmm13, xmm9
000078d941fd6293  vcmppd xmm8, xmm13, xmm13, 0x03
000078d941fd6299  ptest xmm8, xmm8
000078d941fd629f  jnz 0x000078D941FD97D4
000078d941fd62a5  movaps xmm15, xmm1
000078d941fd62a9  addpd xmm15, xmm5
000078d941fd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000078d941fd62b4  ptest xmm9, xmm9
000078d941fd62ba  jnz 0x000078D941FD9918
000078d941fd62c0  vmovaps [rsp+0x30], xmm11
000078d941fd62c6  vmovaps xmm1, [rsp+0x30]
000078d941fd62cc  por xmm11, xmm1
000078d941fd62d1  movaps [r15+0x250], xmm11
000078d941fd62d9  vmovaps [rsp+0x30], xmm12
000078d941fd62df  vmovaps xmm1, [rsp+0x30]
000078d941fd62e5  por xmm12, xmm1
000078d941fd62ea  movaps [r15+0x2A0], xmm12
000078d941fd62f2  vmovaps xmm1, [rsp+0xA0]
000078d941fd62fb  vmovaps xmm11, [rsp+0xA0]
000078d941fd6304  por xmm1, xmm11
000078d941fd6309  movaps [r15+0x1D0], xmm1
000078d941fd6311  lea r14, [rax+0x40]
000078d941fd6315  movups xmm1, [r13+r14*1]
000078d941fd631b  movaps [r15+0x2C0], xmm1
000078d941fd6323  vmovaps xmm11, [rsp+0x40]
000078d941fd6329  vpermilpd xmm11, xmm11, 0x00
000078d941fd632f  vmovaps xmm8, [rsp+0xE0]
000078d941fd6338  movaps xmm9, xmm8
000078d941fd633c  mulpd xmm9, xmm11
000078d941fd6341  vcmppd xmm5, xmm9, xmm9, 0x03
000078d941fd6347  ptest xmm5, xmm5
000078d941fd634c  jnz 0x000078D941FD9A64
000078d941fd6352  movaps xmm11, xmm10
000078d941fd6356  addpd xmm11, xmm6
000078d941fd635b  vcmppd xmm8, xmm11, xmm11, 0x03
000078d941fd6361  ptest xmm8, xmm8
000078d941fd6367  jnz 0x000078D941FD9BA8
000078d941fd636d  movaps xmm10, xmm14
000078d941fd6371  addpd xmm10, xmm4
000078d941fd6376  vcmppd xmm8, xmm10, xmm10, 0x03
000078d941fd637c  ptest xmm8, xmm8
000078d941fd6382  jnz 0x000078D941FD9CEB
000078d941fd6388  vmovaps xmm14, [rsp+0x40]
000078d941fd638e  vpermilpd xmm14, xmm14, 0x00
000078d941fd6394  movaps xmm8, xmm1
000078d941fd6398  mulpd xmm8, xmm14
000078d941fd639d  vcmppd xmm6, xmm8, xmm8, 0x03
000078d941fd63a3  ptest xmm6, xmm6
000078d941fd63a8  jnz 0x000078D941FD9E2E
000078d941fd63ae  movaps xmm1, [r15+0x2B0]
000078d941fd63b6  vmovaps xmm14, [rsp+0x40]
000078d941fd63bc  vpermilpd xmm14, xmm14, 0x00
000078d941fd63c2  movaps xmm6, xmm1
000078d941fd63c5  mulpd xmm6, xmm14
000078d941fd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000078d941fd63cf  ptest xmm5, xmm5
000078d941fd63d4  jnz 0x000078D941FD9F71
000078d941fd63da  vmovaps xmm1, [rsp+0x10]
000078d941fd63e0  vpermilpd xmm1, xmm1, 0x00
000078d941fd63e6  movaps xmm14, xmm12
000078d941fd63ea  mulpd xmm14, xmm1
000078d941fd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000078d941fd63f5  ptest xmm5, xmm5
000078d941fd63fa  jnz 0x000078D941FDA0B2
000078d941fd6400  movaps xmm1, xmm13
000078d941fd6404  addpd xmm1, xmm9
000078d941fd6409  vcmppd xmm12, xmm1, xmm1, 0x03
000078d941fd640e  ptest xmm12, xmm12
000078d941fd6414  jnz 0x000078D941FDA1F5
000078d941fd641a  vmovaps xmm13, [rsp+0x10]
000078d941fd6420  vpermilpd xmm13, xmm13, 0x00
000078d941fd6426  movaps xmm12, xmm7
000078d941fd642a  mulpd xmm12, xmm13
000078d941fd642f  vcmppd xmm9, xmm12, xmm12, 0x03
000078d941fd6435  ptest xmm9, xmm9
000078d941fd643b  jnz 0x000078D941FDA337
000078d941fd6441  movaps xmm13, xmm15
000078d941fd6445  addpd xmm13, xmm8
000078d941fd644a  vcmppd xmm9, xmm13, xmm13, 0x03
000078d941fd6450  ptest xmm9, xmm9
000078d941fd6456  jnz 0x000078D941FDA47A
000078d941fd645c  movaps xmm15, [r15+0x290]
000078d941fd6464  vmovaps xmm9, [rsp+0x10]
000078d941fd646a  vpermilpd xmm9, xmm9, 0x00
000078d941fd6470  movaps xmm8, xmm15
000078d941fd6474  mulpd xmm8, xmm9
000078d941fd6479  vcmppd xmm7, xmm8, xmm8, 0x03
000078d941fd647f  ptest xmm7, xmm7
000078d941fd6484  jnz 0x000078D941FDA5BE
000078d941fd648a  movaps xmm15, xmm11
000078d941fd648e  addpd xmm15, xmm6
000078d941fd6493  vcmppd xmm9, xmm15, xmm15, 0x03
000078d941fd6499  ptest xmm9, xmm9
000078d941fd649f  jnz 0x000078D941FDA702
000078d941fd64a5  movaps xmm11, [r15+0x1E0]
000078d941fd64ad  vmovaps xmm9, [rsp+0x10]
000078d941fd64b3  vpermilpd xmm9, xmm9, 0x00
000078d941fd64b9  movaps xmm7, xmm11
000078d941fd64bd  mulpd xmm7, xmm9
000078d941fd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000078d941fd64c7  ptest xmm6, xmm6
000078d941fd64cc  jnz 0x000078D941FDA845
000078d941fd64d2  movaps xmm11, xmm10
000078d941fd64d6  addpd xmm11, xmm14
000078d941fd64db  vcmppd xmm9, xmm11, xmm11, 0x03
000078d941fd64e1  ptest xmm9, xmm9
000078d941fd64e7  jnz 0x000078D941FDA987
000078d941fd64ed  lea r14, [rax+0x70]
000078d941fd64f1  movups xmm14, [r13+r14*1]
000078d941fd64f7  movaps [r15+0x240], xmm14
000078d941fd64ff  movaps xmm10, xmm1
000078d941fd6503  addpd xmm10, xmm12
000078d941fd6508  vcmppd xmm9, xmm10, xmm10, 0x03
000078d941fd650e  ptest xmm9, xmm9
000078d941fd6514  jnz 0x000078D941FDAAD5
000078d941fd651a  movaps [r15+0x170], xmm10
000078d941fd6522  vmovaps xmm1, [rsp+0x20]
000078d941fd6528  vpermilpd xmm1, xmm1, 0x00
000078d941fd652e  movaps xmm12, xmm14
000078d941fd6532  mulpd xmm12, xmm1
000078d941fd6537  vcmppd xmm9, xmm12, xmm12, 0x03
000078d941fd653d  ptest xmm9, xmm9
000078d941fd6543  jnz 0x000078D941FDAC18
000078d941fd6549  vmovaps xmm1, [rsp+0x20]
000078d941fd654f  vpermilpd xmm1, xmm1, 0x00
000078d941fd6555  vmovaps xmm9, [rsp+0xB0]
000078d941fd655e  movaps xmm14, xmm9
000078d941fd6562  mulpd xmm14, xmm1
000078d941fd6567  vcmppd xmm6, xmm14, xmm14, 0x03
000078d941fd656d  ptest xmm6, xmm6
000078d941fd6572  jnz 0x000078D941FDAD5B
000078d941fd6578  movaps [r15+0x180], xmm14
000078d941fd6580  movaps xmm1, xmm13
000078d941fd6584  addpd xmm1, xmm8
000078d941fd6589  vcmppd xmm9, xmm1, xmm1, 0x03
000078d941fd658e  ptest xmm9, xmm9
000078d941fd6594  jnz 0x000078D941FDAE9E
000078d941fd659a  movaps [r15+0x210], xmm1
000078d941fd65a2  movups xmm13, [r13+rax*1]
000078d941fd65a8  lea r14, [rax+0x10]
000078d941fd65ac  movups xmm9, [r13+r14*1]
000078d941fd65b2  movaps [r15+0x230], xmm9
000078d941fd65ba  movaps xmm8, xmm15
000078d941fd65be  addpd xmm8, xmm7
000078d941fd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000078d941fd65c9  ptest xmm6, xmm6
000078d941fd65ce  jnz 0x000078D941FDAFF4
000078d941fd65d4  movaps [r15+0x130], xmm8
000078d941fd65dc  vmovaps xmm15, [rsp+0x20]
000078d941fd65e2  vpermilpd xmm15, xmm15, 0x00
000078d941fd65e8  movaps xmm7, xmm9
000078d941fd65ec  mulpd xmm7, xmm15
000078d941fd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000078d941fd65f6  ptest xmm6, xmm6
000078d941fd65fb  jnz 0x000078D941FDB137
000078d941fd6601  movaps [r15+0x220], xmm7
000078d941fd6609  vmovaps xmm15, [rsp+0x20]
000078d941fd660f  vpermilpd xmm15, xmm15, 0x00
000078d941fd6615  movaps xmm9, xmm13
000078d941fd6619  mulpd xmm9, xmm15
000078d941fd661e  vcmppd xmm6, xmm9, xmm9, 0x03
000078d941fd6624  ptest xmm6, xmm6
000078d941fd6629  jnz 0x000078D941FDB279
000078d941fd662f  movaps xmm15, xmm11
000078d941fd6633  addpd xmm15, xmm12
000078d941fd6638  vcmppd xmm13, xmm15, xmm15, 0x03
000078d941fd663e  ptest xmm13, xmm13
000078d941fd6644  jnz 0x000078D941FDB3BD
000078d941fd664a  movaps [r15+0x140], xmm15
000078d941fd6652  movaps xmm13, xmm10
000078d941fd6656  addpd xmm13, xmm14
000078d941fd665b  vcmppd xmm12, xmm13, xmm13, 0x03
000078d941fd6661  ptest xmm12, xmm12
000078d941fd6667  jnz 0x000078D941FDB501
000078d941fd666d  movaps [r15+0x150], xmm13
000078d941fd6675  movaps xmm14, xmm1
000078d941fd6679  addpd xmm14, xmm7
000078d941fd667e  vcmppd xmm12, xmm14, xmm14, 0x03
000078d941fd6684  ptest xmm12, xmm12
000078d941fd668a  jnz 0x000078D941FDB645
000078d941fd6690  movaps [r15+0x160], xmm14
000078d941fd6698  movaps xmm1, xmm8
000078d941fd669c  addpd xmm1, xmm9
000078d941fd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000078d941fd66a6  ptest xmm12, xmm12
000078d941fd66ac  jnz 0x000078D941FDB787
000078d941fd66b2  movaps [r15+0x120], xmm1
000078d941fd66ba  movups [r13+r11*1], xmm15
000078d941fd66c0  lea rax, [r11+0x10]
000078d941fd66c4  movups [r13+rax*1], xmm13
000078d941fd66ca  lea rax, [r11+0x20]
000078d941fd66ce  movups [r13+rax*1], xmm14
000078d941fd66d4  lea rax, [r11+0x30]
000078d941fd66d8  movups [r13+rax*1], xmm1
000078d941fd66de  mov eax, [r15+0x108]
000078d941fd66e5  sahf
000078d941fd66e6  jnz 0x000078D941FD6718
000078d941fd66e8  cmp dword ptr [r15+0x318], 0x00
000078d941fd66f0  jz 0x000078D941FDB900
000078d941fd66f6  nop [rax+rax*1], ax
000078d941fd66ff  nop [rax+rax*1], eax
000078d941fd6707  mov eax, 0x410444
000078d941fd670c  mov [r15+0x100], rax
000078d941fd6713  jmp 0x000078D941DFE110
000078d941fd6718  cmp dword ptr [r15+0x318], 0x00
000078d941fd6720  jz 0x000078D941FD57E0
000078d941fd6726  nop [rax+rax*1], ax
000078d941fd672f  nop [rax+rax*1], eax
000078d941fd6737  mov eax, 0x410278
000078d941fd673c  mov [r15+0x100], rax
000078d941fd6743  jmp 0x000078D941DFE110
000078d941fd6748  int3
000078d941fd6749  call 0x000078D941E0A4B0
000078d941fd674e  jmp 0x000078D941FD5828
000078d941fd6753  call 0x000078D941E09240
000078d941fd6758  jmp 0x000078D941FD5832
000078d941fd675d  call 0x000078D941E0A4B0
000078d941fd6762  jmp 0x000078D941FD588F
000078d941fd6767  call 0x000078D941E09240
000078d941fd676c  jmp 0x000078D941FD5899
000078d941fd6771  call 0x000078D941E0A4B0
000078d941fd6776  jmp 0x000078D941FD58DD
000078d941fd677b  call 0x000078D941E09240
000078d941fd6780  jmp 0x000078D941FD58E7
000078d941fd6785  call 0x000078D941EB47C0
000078d941fd678a  jmp 0x000078D941FD5926
000078d941fd678f  call 0x000078D941E0B720
000078d941fd6794  jmp 0x000078D941FD593A
000078d941fd6799  call 0x000078D941EBFC30
000078d941fd679e  jmp 0x000078D941FD5958
000078d941fd67a3  call 0x000078D941EBE9C0
000078d941fd67a8  jmp 0x000078D941FD5962
000078d941fd67ad  call 0x000078D941EBD750
000078d941fd67b2  jmp 0x000078D941FD596C
000078d941fd67b7  sub rsp, 0x08
000078d941fd67bb  push rax
000078d941fd67bc  push rcx
000078d941fd67bd  push rdx
000078d941fd67be  push rdi
000078d941fd67bf  push rsi
000078d941fd67c0  push r8
000078d941fd67c2  push r9
000078d941fd67c4  push r10
000078d941fd67c6  push r11
000078d941fd67c8  sub rsp, 0xF0
000078d941fd67cf  vmovaps [rsp], xmm0
000078d941fd67d4  vmovaps [rsp+0x10], xmm1
000078d941fd67da  vmovaps [rsp+0x20], xmm2
000078d941fd67e0  vmovaps [rsp+0x30], xmm3
000078d941fd67e6  vmovaps [rsp+0x40], xmm4
000078d941fd67ec  vmovaps [rsp+0x50], xmm5
000078d941fd67f2  vmovaps [rsp+0x60], xmm6
000078d941fd67f8  vmovaps [rsp+0x70], xmm7
000078d941fd67fe  vmovaps [rsp+0x80], xmm9
000078d941fd6807  vmovaps [rsp+0x90], xmm10
000078d941fd6810  vmovaps [rsp+0xA0], xmm11
000078d941fd6819  vmovaps [rsp+0xB0], xmm12
000078d941fd6822  vmovaps [rsp+0xC0], xmm13
000078d941fd682b  vmovaps [rsp+0xD0], xmm14
000078d941fd6834  vmovaps [rsp+0xE0], xmm15
000078d941fd683d  sub rsp, 0x30
000078d941fd6841  movaps [rsp], xmm8
000078d941fd6846  movaps [rsp+0x10], xmm12
000078d941fd684c  movaps [rsp+0x20], xmm15
000078d941fd6852  lea rdi, [rsp]
000078d941fd6856  mov esi, 0x00
000078d941fd685b  mov rax, 0x59BFBFBAA530
000078d941fd6865  call rax
000078d941fd6867  movaps xmm8, [rsp]
000078d941fd686c  add rsp, 0x30
000078d941fd6870  vmovaps xmm0, [rsp]
000078d941fd6875  vmovaps xmm1, [rsp+0x10]
000078d941fd687b  vmovaps xmm2, [rsp+0x20]
000078d941fd6881  vmovaps xmm3, [rsp+0x30]
000078d941fd6887  vmovaps xmm4, [rsp+0x40]
000078d941fd688d  vmovaps xmm5, [rsp+0x50]
000078d941fd6893  vmovaps xmm6, [rsp+0x60]
000078d941fd6899  vmovaps xmm7, [rsp+0x70]
000078d941fd689f  vmovaps xmm9, [rsp+0x80]
000078d941fd68a8  vmovaps xmm10, [rsp+0x90]
000078d941fd68b1  vmovaps xmm11, [rsp+0xA0]
000078d941fd68ba  vmovaps xmm12, [rsp+0xB0]
000078d941fd68c3  vmovaps xmm13, [rsp+0xC0]
000078d941fd68cc  vmovaps xmm14, [rsp+0xD0]
000078d941fd68d5  vmovaps xmm15, [rsp+0xE0]
000078d941fd68de  add rsp, 0xF0
000078d941fd68e5  pop r11
000078d941fd68e7  pop r10
000078d941fd68e9  pop r9
000078d941fd68eb  pop r8
000078d941fd68ed  pop rsi
000078d941fd68ee  pop rdi
000078d941fd68ef  pop rdx
000078d941fd68f0  pop rcx
000078d941fd68f1  pop rax
000078d941fd68f2  add rsp, 0x08
000078d941fd68f6  jmp 0x000078D941FD599A
000078d941fd68fb  sub rsp, 0x08
000078d941fd68ff  push rax
000078d941fd6900  push rcx
000078d941fd6901  push rdx
000078d941fd6902  push rdi
000078d941fd6903  push rsi
000078d941fd6904  push r8
000078d941fd6906  push r9
000078d941fd6908  push r10
000078d941fd690a  push r11
000078d941fd690c  sub rsp, 0xF0
000078d941fd6913  vmovaps [rsp], xmm0
000078d941fd6918  vmovaps [rsp+0x10], xmm1
000078d941fd691e  vmovaps [rsp+0x20], xmm2
000078d941fd6924  vmovaps [rsp+0x30], xmm3
000078d941fd692a  vmovaps [rsp+0x40], xmm4
000078d941fd6930  vmovaps [rsp+0x50], xmm5
000078d941fd6936  vmovaps [rsp+0x60], xmm6
000078d941fd693c  vmovaps [rsp+0x70], xmm8
000078d941fd6942  vmovaps [rsp+0x80], xmm9
000078d941fd694b  vmovaps [rsp+0x90], xmm10
000078d941fd6954  vmovaps [rsp+0xA0], xmm11
000078d941fd695d  vmovaps [rsp+0xB0], xmm12
000078d941fd6966  vmovaps [rsp+0xC0], xmm13
000078d941fd696f  vmovaps [rsp+0xD0], xmm14
000078d941fd6978  vmovaps [rsp+0xE0], xmm15
000078d941fd6981  sub rsp, 0x30
000078d941fd6985  movaps [rsp], xmm7
000078d941fd6989  movaps [rsp+0x10], xmm9
000078d941fd698f  movaps [rsp+0x20], xmm15
000078d941fd6995  lea rdi, [rsp]
000078d941fd6999  mov esi, 0x00
000078d941fd699e  mov rax, 0x59BFBFBAA530
000078d941fd69a8  call rax
000078d941fd69aa  movaps xmm7, [rsp]
000078d941fd69ae  add rsp, 0x30
000078d941fd69b2  vmovaps xmm0, [rsp]
000078d941fd69b7  vmovaps xmm1, [rsp+0x10]
000078d941fd69bd  vmovaps xmm2, [rsp+0x20]
000078d941fd69c3  vmovaps xmm3, [rsp+0x30]
000078d941fd69c9  vmovaps xmm4, [rsp+0x40]
000078d941fd69cf  vmovaps xmm5, [rsp+0x50]
000078d941fd69d5  vmovaps xmm6, [rsp+0x60]
000078d941fd69db  vmovaps xmm8, [rsp+0x70]
000078d941fd69e1  vmovaps xmm9, [rsp+0x80]
000078d941fd69ea  vmovaps xmm10, [rsp+0x90]
000078d941fd69f3  vmovaps xmm11, [rsp+0xA0]
000078d941fd69fc  vmovaps xmm12, [rsp+0xB0]
000078d941fd6a05  vmovaps xmm13, [rsp+0xC0]
000078d941fd6a0e  vmovaps xmm14, [rsp+0xD0]
000078d941fd6a17  vmovaps xmm15, [rsp+0xE0]
000078d941fd6a20  add rsp, 0xF0
000078d941fd6a27  pop r11
000078d941fd6a29  pop r10
000078d941fd6a2b  pop r9
000078d941fd6a2d  pop r8
000078d941fd6a2f  pop rsi
000078d941fd6a30  pop rdi
000078d941fd6a31  pop rdx
000078d941fd6a32  pop rcx
000078d941fd6a33  pop rax
000078d941fd6a34  add rsp, 0x08
000078d941fd6a38  jmp 0x000078D941FD59C8
000078d941fd6a3d  sub rsp, 0x08
000078d941fd6a41  push rax
000078d941fd6a42  push rcx
000078d941fd6a43  push rdx
000078d941fd6a44  push rdi
000078d941fd6a45  push rsi
000078d941fd6a46  push r8
000078d941fd6a48  push r9
000078d941fd6a4a  push r10
000078d941fd6a4c  push r11
000078d941fd6a4e  sub rsp, 0xF0
000078d941fd6a55  vmovaps [rsp], xmm0
000078d941fd6a5a  vmovaps [rsp+0x10], xmm1
000078d941fd6a60  vmovaps [rsp+0x20], xmm2
000078d941fd6a66  vmovaps [rsp+0x30], xmm3
000078d941fd6a6c  vmovaps [rsp+0x40], xmm4
000078d941fd6a72  vmovaps [rsp+0x50], xmm5
000078d941fd6a78  vmovaps [rsp+0x60], xmm6
000078d941fd6a7e  vmovaps [rsp+0x70], xmm7
000078d941fd6a84  vmovaps [rsp+0x80], xmm8
000078d941fd6a8d  vmovaps [rsp+0x90], xmm10
000078d941fd6a96  vmovaps [rsp+0xA0], xmm11
000078d941fd6a9f  vmovaps [rsp+0xB0], xmm12
000078d941fd6aa8  vmovaps [rsp+0xC0], xmm13
000078d941fd6ab1  vmovaps [rsp+0xD0], xmm14
000078d941fd6aba  vmovaps [rsp+0xE0], xmm15
000078d941fd6ac3  sub rsp, 0x30
000078d941fd6ac7  movaps [rsp], xmm9
000078d941fd6acc  movaps [rsp+0x10], xmm12
000078d941fd6ad2  movaps [rsp+0x20], xmm10
000078d941fd6ad8  lea rdi, [rsp]
000078d941fd6adc  mov esi, 0x00
000078d941fd6ae1  mov rax, 0x59BFBFBAA530
000078d941fd6aeb  call rax
000078d941fd6aed  movaps xmm9, [rsp]
000078d941fd6af2  add rsp, 0x30
000078d941fd6af6  vmovaps xmm0, [rsp]
000078d941fd6afb  vmovaps xmm1, [rsp+0x10]
000078d941fd6b01  vmovaps xmm2, [rsp+0x20]
000078d941fd6b07  vmovaps xmm3, [rsp+0x30]
000078d941fd6b0d  vmovaps xmm4, [rsp+0x40]
000078d941fd6b13  vmovaps xmm5, [rsp+0x50]
000078d941fd6b19  vmovaps xmm6, [rsp+0x60]
000078d941fd6b1f  vmovaps xmm7, [rsp+0x70]
000078d941fd6b25  vmovaps xmm8, [rsp+0x80]
000078d941fd6b2e  vmovaps xmm10, [rsp+0x90]
000078d941fd6b37  vmovaps xmm11, [rsp+0xA0]
000078d941fd6b40  vmovaps xmm12, [rsp+0xB0]
000078d941fd6b49  vmovaps xmm13, [rsp+0xC0]
000078d941fd6b52  vmovaps xmm14, [rsp+0xD0]
000078d941fd6b5b  vmovaps xmm15, [rsp+0xE0]
000078d941fd6b64  add rsp, 0xF0
000078d941fd6b6b  pop r11
000078d941fd6b6d  pop r10
000078d941fd6b6f  pop r9
000078d941fd6b71  pop r8
000078d941fd6b73  pop rsi
000078d941fd6b74  pop rdi
000078d941fd6b75  pop rdx
000078d941fd6b76  pop rcx
000078d941fd6b77  pop rax
000078d941fd6b78  add rsp, 0x08
000078d941fd6b7c  jmp 0x000078D941FD59EC
000078d941fd6b81  sub rsp, 0x08
000078d941fd6b85  push rax
000078d941fd6b86  push rcx
000078d941fd6b87  push rdx
000078d941fd6b88  push rdi
000078d941fd6b89  push rsi
000078d941fd6b8a  push r8
000078d941fd6b8c  push r9
000078d941fd6b8e  push r10
000078d941fd6b90  push r11
000078d941fd6b92  sub rsp, 0xF0
000078d941fd6b99  vmovaps [rsp], xmm0
000078d941fd6b9e  vmovaps [rsp+0x10], xmm1
000078d941fd6ba4  vmovaps [rsp+0x20], xmm2
000078d941fd6baa  vmovaps [rsp+0x30], xmm3
000078d941fd6bb0  vmovaps [rsp+0x40], xmm4
000078d941fd6bb6  vmovaps [rsp+0x50], xmm5
000078d941fd6bbc  vmovaps [rsp+0x60], xmm6
000078d941fd6bc2  vmovaps [rsp+0x70], xmm7
000078d941fd6bc8  vmovaps [rsp+0x80], xmm8
000078d941fd6bd1  vmovaps [rsp+0x90], xmm9
000078d941fd6bda  vmovaps [rsp+0xA0], xmm11
000078d941fd6be3  vmovaps [rsp+0xB0], xmm12
000078d941fd6bec  vmovaps [rsp+0xC0], xmm13
000078d941fd6bf5  vmovaps [rsp+0xD0], xmm14
000078d941fd6bfe  vmovaps [rsp+0xE0], xmm15
000078d941fd6c07  sub rsp, 0x30
000078d941fd6c0b  movaps [rsp], xmm10
000078d941fd6c10  movaps [rsp+0x10], xmm12
000078d941fd6c16  movaps [rsp+0x20], xmm11
000078d941fd6c1c  lea rdi, [rsp]
000078d941fd6c20  mov esi, 0x00
000078d941fd6c25  mov rax, 0x59BFBFBAA530
000078d941fd6c2f  call rax
000078d941fd6c31  movaps xmm10, [rsp]
000078d941fd6c36  add rsp, 0x30
000078d941fd6c3a  vmovaps xmm0, [rsp]
000078d941fd6c3f  vmovaps xmm1, [rsp+0x10]
000078d941fd6c45  vmovaps xmm2, [rsp+0x20]
000078d941fd6c4b  vmovaps xmm3, [rsp+0x30]
000078d941fd6c51  vmovaps xmm4, [rsp+0x40]
000078d941fd6c57  vmovaps xmm5, [rsp+0x50]
000078d941fd6c5d  vmovaps xmm6, [rsp+0x60]
000078d941fd6c63  vmovaps xmm7, [rsp+0x70]
000078d941fd6c69  vmovaps xmm8, [rsp+0x80]
000078d941fd6c72  vmovaps xmm9, [rsp+0x90]
000078d941fd6c7b  vmovaps xmm11, [rsp+0xA0]
000078d941fd6c84  vmovaps xmm12, [rsp+0xB0]
000078d941fd6c8d  vmovaps xmm13, [rsp+0xC0]
000078d941fd6c96  vmovaps xmm14, [rsp+0xD0]
000078d941fd6c9f  vmovaps xmm15, [rsp+0xE0]
000078d941fd6ca8  add rsp, 0xF0
000078d941fd6caf  pop r11
000078d941fd6cb1  pop r10
000078d941fd6cb3  pop r9
000078d941fd6cb5  pop r8
000078d941fd6cb7  pop rsi
000078d941fd6cb8  pop rdi
000078d941fd6cb9  pop rdx
000078d941fd6cba  pop rcx
000078d941fd6cbb  pop rax
000078d941fd6cbc  add rsp, 0x08
000078d941fd6cc0  jmp 0x000078D941FD5A06
000078d941fd6cc5  sub rsp, 0x08
000078d941fd6cc9  push rax
000078d941fd6cca  push rcx
000078d941fd6ccb  push rdx
000078d941fd6ccc  push rdi
000078d941fd6ccd  push rsi
000078d941fd6cce  push r8
000078d941fd6cd0  push r9
000078d941fd6cd2  push r10
000078d941fd6cd4  push r11
000078d941fd6cd6  sub rsp, 0xF0
000078d941fd6cdd  vmovaps [rsp], xmm0
000078d941fd6ce2  vmovaps [rsp+0x10], xmm1
000078d941fd6ce8  vmovaps [rsp+0x20], xmm2
000078d941fd6cee  vmovaps [rsp+0x30], xmm3
000078d941fd6cf4  vmovaps [rsp+0x40], xmm4
000078d941fd6cfa  vmovaps [rsp+0x50], xmm5
000078d941fd6d00  vmovaps [rsp+0x60], xmm7
000078d941fd6d06  vmovaps [rsp+0x70], xmm8
000078d941fd6d0c  vmovaps [rsp+0x80], xmm9
000078d941fd6d15  vmovaps [rsp+0x90], xmm10
000078d941fd6d1e  vmovaps [rsp+0xA0], xmm11
000078d941fd6d27  vmovaps [rsp+0xB0], xmm12
000078d941fd6d30  vmovaps [rsp+0xC0], xmm13
000078d941fd6d39  vmovaps [rsp+0xD0], xmm14
000078d941fd6d42  vmovaps [rsp+0xE0], xmm15
000078d941fd6d4b  sub rsp, 0x30
000078d941fd6d4f  movaps [rsp], xmm6
000078d941fd6d53  movaps [rsp+0x10], xmm12
000078d941fd6d59  movaps [rsp+0x20], xmm11
000078d941fd6d5f  lea rdi, [rsp]
000078d941fd6d63  mov esi, 0x00
000078d941fd6d68  mov rax, 0x59BFBFBAA530
000078d941fd6d72  call rax
000078d941fd6d74  movaps xmm6, [rsp]
000078d941fd6d78  add rsp, 0x30
000078d941fd6d7c  vmovaps xmm0, [rsp]
000078d941fd6d81  vmovaps xmm1, [rsp+0x10]
000078d941fd6d87  vmovaps xmm2, [rsp+0x20]
000078d941fd6d8d  vmovaps xmm3, [rsp+0x30]
000078d941fd6d93  vmovaps xmm4, [rsp+0x40]
000078d941fd6d99  vmovaps xmm5, [rsp+0x50]
000078d941fd6d9f  vmovaps xmm7, [rsp+0x60]
000078d941fd6da5  vmovaps xmm8, [rsp+0x70]
000078d941fd6dab  vmovaps xmm9, [rsp+0x80]
000078d941fd6db4  vmovaps xmm10, [rsp+0x90]
000078d941fd6dbd  vmovaps xmm11, [rsp+0xA0]
000078d941fd6dc6  vmovaps xmm12, [rsp+0xB0]
000078d941fd6dcf  vmovaps xmm13, [rsp+0xC0]
000078d941fd6dd8  vmovaps xmm14, [rsp+0xD0]
000078d941fd6de1  vmovaps xmm15, [rsp+0xE0]
000078d941fd6dea  add rsp, 0xF0
000078d941fd6df1  pop r11
000078d941fd6df3  pop r10
000078d941fd6df5  pop r9
000078d941fd6df7  pop r8
000078d941fd6df9  pop rsi
000078d941fd6dfa  pop rdi
000078d941fd6dfb  pop rdx
000078d941fd6dfc  pop rcx
000078d941fd6dfd  pop rax
000078d941fd6dfe  add rsp, 0x08
000078d941fd6e02  jmp 0x000078D941FD5A27
000078d941fd6e07  sub rsp, 0x08
000078d941fd6e0b  push rax
000078d941fd6e0c  push rcx
000078d941fd6e0d  push rdx
000078d941fd6e0e  push rdi
000078d941fd6e0f  push rsi
000078d941fd6e10  push r8
000078d941fd6e12  push r9
000078d941fd6e14  push r10
000078d941fd6e16  push r11
000078d941fd6e18  sub rsp, 0xF0
000078d941fd6e1f  vmovaps [rsp], xmm0
000078d941fd6e24  vmovaps [rsp+0x10], xmm1
000078d941fd6e2a  vmovaps [rsp+0x20], xmm2
000078d941fd6e30  vmovaps [rsp+0x30], xmm4
000078d941fd6e36  vmovaps [rsp+0x40], xmm5
000078d941fd6e3c  vmovaps [rsp+0x50], xmm6
000078d941fd6e42  vmovaps [rsp+0x60], xmm7
000078d941fd6e48  vmovaps [rsp+0x70], xmm8
000078d941fd6e4e  vmovaps [rsp+0x80], xmm9
000078d941fd6e57  vmovaps [rsp+0x90], xmm10
000078d941fd6e60  vmovaps [rsp+0xA0], xmm11
000078d941fd6e69  vmovaps [rsp+0xB0], xmm12
000078d941fd6e72  vmovaps [rsp+0xC0], xmm13
000078d941fd6e7b  vmovaps [rsp+0xD0], xmm14
000078d941fd6e84  vmovaps [rsp+0xE0], xmm15
000078d941fd6e8d  sub rsp, 0x30
000078d941fd6e91  movaps [rsp], xmm3
000078d941fd6e95  movaps [rsp+0x10], xmm5
000078d941fd6e9a  movaps [rsp+0x20], xmm4
000078d941fd6e9f  lea rdi, [rsp]
000078d941fd6ea3  mov esi, 0x00
000078d941fd6ea8  mov rax, 0x59BFBFBAA530
000078d941fd6eb2  call rax
000078d941fd6eb4  movaps xmm3, [rsp]
000078d941fd6eb8  add rsp, 0x30
000078d941fd6ebc  vmovaps xmm0, [rsp]
000078d941fd6ec1  vmovaps xmm1, [rsp+0x10]
000078d941fd6ec7  vmovaps xmm2, [rsp+0x20]
000078d941fd6ecd  vmovaps xmm4, [rsp+0x30]
000078d941fd6ed3  vmovaps xmm5, [rsp+0x40]
000078d941fd6ed9  vmovaps xmm6, [rsp+0x50]
000078d941fd6edf  vmovaps xmm7, [rsp+0x60]
000078d941fd6ee5  vmovaps xmm8, [rsp+0x70]
000078d941fd6eeb  vmovaps xmm9, [rsp+0x80]
000078d941fd6ef4  vmovaps xmm10, [rsp+0x90]
000078d941fd6efd  vmovaps xmm11, [rsp+0xA0]
000078d941fd6f06  vmovaps xmm12, [rsp+0xB0]
000078d941fd6f0f  vmovaps xmm13, [rsp+0xC0]
000078d941fd6f18  vmovaps xmm14, [rsp+0xD0]
000078d941fd6f21  vmovaps xmm15, [rsp+0xE0]
000078d941fd6f2a  add rsp, 0xF0
000078d941fd6f31  pop r11
000078d941fd6f33  pop r10
000078d941fd6f35  pop r9
000078d941fd6f37  pop r8
000078d941fd6f39  pop rsi
000078d941fd6f3a  pop rdi
000078d941fd6f3b  pop rdx
000078d941fd6f3c  pop rcx
000078d941fd6f3d  pop rax
000078d941fd6f3e  add rsp, 0x08
000078d941fd6f42  jmp 0x000078D941FD5A88
000078d941fd6f47  sub rsp, 0x08
000078d941fd6f4b  push rax
000078d941fd6f4c  push rcx
000078d941fd6f4d  push rdx
000078d941fd6f4e  push rdi
000078d941fd6f4f  push rsi
000078d941fd6f50  push r8
000078d941fd6f52  push r9
000078d941fd6f54  push r10
000078d941fd6f56  push r11
000078d941fd6f58  sub rsp, 0xF0
000078d941fd6f5f  vmovaps [rsp], xmm0
000078d941fd6f64  vmovaps [rsp+0x10], xmm1
000078d941fd6f6a  vmovaps [rsp+0x20], xmm2
000078d941fd6f70  vmovaps [rsp+0x30], xmm3
000078d941fd6f76  vmovaps [rsp+0x40], xmm4
000078d941fd6f7c  vmovaps [rsp+0x50], xmm6
000078d941fd6f82  vmovaps [rsp+0x60], xmm7
000078d941fd6f88  vmovaps [rsp+0x70], xmm8
000078d941fd6f8e  vmovaps [rsp+0x80], xmm9
000078d941fd6f97  vmovaps [rsp+0x90], xmm10
000078d941fd6fa0  vmovaps [rsp+0xA0], xmm11
000078d941fd6fa9  vmovaps [rsp+0xB0], xmm12
000078d941fd6fb2  vmovaps [rsp+0xC0], xmm13
000078d941fd6fbb  vmovaps [rsp+0xD0], xmm14
000078d941fd6fc4  vmovaps [rsp+0xE0], xmm15
000078d941fd6fcd  sub rsp, 0x30
000078d941fd6fd1  movaps [rsp], xmm5
000078d941fd6fd5  movaps [rsp+0x10], xmm8
000078d941fd6fdb  movaps [rsp+0x20], xmm15
000078d941fd6fe1  lea rdi, [rsp]
000078d941fd6fe5  mov esi, 0x00
000078d941fd6fea  mov rax, 0x59BFBFBAA530
000078d941fd6ff4  call rax
000078d941fd6ff6  movaps xmm5, [rsp]
000078d941fd6ffa  add rsp, 0x30
000078d941fd6ffe  vmovaps xmm0, [rsp]
000078d941fd7003  vmovaps xmm1, [rsp+0x10]
000078d941fd7009  vmovaps xmm2, [rsp+0x20]
000078d941fd700f  vmovaps xmm3, [rsp+0x30]
000078d941fd7015  vmovaps xmm4, [rsp+0x40]
000078d941fd701b  vmovaps xmm6, [rsp+0x50]
000078d941fd7021  vmovaps xmm7, [rsp+0x60]
000078d941fd7027  vmovaps xmm8, [rsp+0x70]
000078d941fd702d  vmovaps xmm9, [rsp+0x80]
000078d941fd7036  vmovaps xmm10, [rsp+0x90]
000078d941fd703f  vmovaps xmm11, [rsp+0xA0]
000078d941fd7048  vmovaps xmm12, [rsp+0xB0]
000078d941fd7051  vmovaps xmm13, [rsp+0xC0]
000078d941fd705a  vmovaps xmm14, [rsp+0xD0]
000078d941fd7063  vmovaps xmm15, [rsp+0xE0]
000078d941fd706c  add rsp, 0xF0
000078d941fd7073  pop r11
000078d941fd7075  pop r10
000078d941fd7077  pop r9
000078d941fd7079  pop r8
000078d941fd707b  pop rsi
000078d941fd707c  pop rdi
000078d941fd707d  pop rdx
000078d941fd707e  pop rcx
000078d941fd707f  pop rax
000078d941fd7080  add rsp, 0x08
000078d941fd7084  jmp 0x000078D941FD5AC0
000078d941fd7089  sub rsp, 0x08
000078d941fd708d  push rax
000078d941fd708e  push rcx
000078d941fd708f  push rdx
000078d941fd7090  push rdi
000078d941fd7091  push rsi
000078d941fd7092  push r8
000078d941fd7094  push r9
000078d941fd7096  push r10
000078d941fd7098  push r11
000078d941fd709a  sub rsp, 0xF0
000078d941fd70a1  vmovaps [rsp], xmm0
000078d941fd70a6  vmovaps [rsp+0x10], xmm1
000078d941fd70ac  vmovaps [rsp+0x20], xmm2
000078d941fd70b2  vmovaps [rsp+0x30], xmm3
000078d941fd70b8  vmovaps [rsp+0x40], xmm5
000078d941fd70be  vmovaps [rsp+0x50], xmm6
000078d941fd70c4  vmovaps [rsp+0x60], xmm7
000078d941fd70ca  vmovaps [rsp+0x70], xmm8
000078d941fd70d0  vmovaps [rsp+0x80], xmm9
000078d941fd70d9  vmovaps [rsp+0x90], xmm10
000078d941fd70e2  vmovaps [rsp+0xA0], xmm11
000078d941fd70eb  vmovaps [rsp+0xB0], xmm12
000078d941fd70f4  vmovaps [rsp+0xC0], xmm13
000078d941fd70fd  vmovaps [rsp+0xD0], xmm14
000078d941fd7106  vmovaps [rsp+0xE0], xmm15
000078d941fd710f  sub rsp, 0x30
000078d941fd7113  movaps [rsp], xmm4
000078d941fd7117  movaps [rsp+0x10], xmm9
000078d941fd711d  movaps [rsp+0x20], xmm8
000078d941fd7123  lea rdi, [rsp]
000078d941fd7127  mov esi, 0x00
000078d941fd712c  mov rax, 0x59BFBFBAA530
000078d941fd7136  call rax
000078d941fd7138  movaps xmm4, [rsp]
000078d941fd713c  add rsp, 0x30
000078d941fd7140  vmovaps xmm0, [rsp]
000078d941fd7145  vmovaps xmm1, [rsp+0x10]
000078d941fd714b  vmovaps xmm2, [rsp+0x20]
000078d941fd7151  vmovaps xmm3, [rsp+0x30]
000078d941fd7157  vmovaps xmm5, [rsp+0x40]
000078d941fd715d  vmovaps xmm6, [rsp+0x50]
000078d941fd7163  vmovaps xmm7, [rsp+0x60]
000078d941fd7169  vmovaps xmm8, [rsp+0x70]
000078d941fd716f  vmovaps xmm9, [rsp+0x80]
000078d941fd7178  vmovaps xmm10, [rsp+0x90]
000078d941fd7181  vmovaps xmm11, [rsp+0xA0]
000078d941fd718a  vmovaps xmm12, [rsp+0xB0]
000078d941fd7193  vmovaps xmm13, [rsp+0xC0]
000078d941fd719c  vmovaps xmm14, [rsp+0xD0]
000078d941fd71a5  vmovaps xmm15, [rsp+0xE0]
000078d941fd71ae  add rsp, 0xF0
000078d941fd71b5  pop r11
000078d941fd71b7  pop r10
000078d941fd71b9  pop r9
000078d941fd71bb  pop r8
000078d941fd71bd  pop rsi
000078d941fd71be  pop rdi
000078d941fd71bf  pop rdx
000078d941fd71c0  pop rcx
000078d941fd71c1  pop rax
000078d941fd71c2  add rsp, 0x08
000078d941fd71c6  jmp 0x000078D941FD5AE1
000078d941fd71cb  sub rsp, 0x08
000078d941fd71cf  push rax
000078d941fd71d0  push rcx
000078d941fd71d1  push rdx
000078d941fd71d2  push rdi
000078d941fd71d3  push rsi
000078d941fd71d4  push r8
000078d941fd71d6  push r9
000078d941fd71d8  push r10
000078d941fd71da  push r11
000078d941fd71dc  sub rsp, 0xF0
000078d941fd71e3  vmovaps [rsp], xmm0
000078d941fd71e8  vmovaps [rsp+0x10], xmm1
000078d941fd71ee  vmovaps [rsp+0x20], xmm2
000078d941fd71f4  vmovaps [rsp+0x30], xmm3
000078d941fd71fa  vmovaps [rsp+0x40], xmm4
000078d941fd7200  vmovaps [rsp+0x50], xmm5
000078d941fd7206  vmovaps [rsp+0x60], xmm6
000078d941fd720c  vmovaps [rsp+0x70], xmm7
000078d941fd7212  vmovaps [rsp+0x80], xmm8
000078d941fd721b  vmovaps [rsp+0x90], xmm10
000078d941fd7224  vmovaps [rsp+0xA0], xmm11
000078d941fd722d  vmovaps [rsp+0xB0], xmm12
000078d941fd7236  vmovaps [rsp+0xC0], xmm13
000078d941fd723f  vmovaps [rsp+0xD0], xmm14
000078d941fd7248  vmovaps [rsp+0xE0], xmm15
000078d941fd7251  sub rsp, 0x30
000078d941fd7255  movaps [rsp], xmm9
000078d941fd725a  movaps [rsp+0x10], xmm10
000078d941fd7260  movaps [rsp+0x20], xmm8
000078d941fd7266  lea rdi, [rsp]
000078d941fd726a  mov esi, 0x00
000078d941fd726f  mov rax, 0x59BFBFBAA530
000078d941fd7279  call rax
000078d941fd727b  movaps xmm9, [rsp]
000078d941fd7280  add rsp, 0x30
000078d941fd7284  vmovaps xmm0, [rsp]
000078d941fd7289  vmovaps xmm1, [rsp+0x10]
000078d941fd728f  vmovaps xmm2, [rsp+0x20]
000078d941fd7295  vmovaps xmm3, [rsp+0x30]
000078d941fd729b  vmovaps xmm4, [rsp+0x40]
000078d941fd72a1  vmovaps xmm5, [rsp+0x50]
000078d941fd72a7  vmovaps xmm6, [rsp+0x60]
000078d941fd72ad  vmovaps xmm7, [rsp+0x70]
000078d941fd72b3  vmovaps xmm8, [rsp+0x80]
000078d941fd72bc  vmovaps xmm10, [rsp+0x90]
000078d941fd72c5  vmovaps xmm11, [rsp+0xA0]
000078d941fd72ce  vmovaps xmm12, [rsp+0xB0]
000078d941fd72d7  vmovaps xmm13, [rsp+0xC0]
000078d941fd72e0  vmovaps xmm14, [rsp+0xD0]
000078d941fd72e9  vmovaps xmm15, [rsp+0xE0]
000078d941fd72f2  add rsp, 0xF0
000078d941fd72f9  pop r11
000078d941fd72fb  pop r10
000078d941fd72fd  pop r9
000078d941fd72ff  pop r8
000078d941fd7301  pop rsi
000078d941fd7302  pop rdi
000078d941fd7303  pop rdx
000078d941fd7304  pop rcx
000078d941fd7305  pop rax
000078d941fd7306  add rsp, 0x08
000078d941fd730a  jmp 0x000078D941FD5AFB
000078d941fd730f  call 0x000078D941ED64F0
000078d941fd7314  jmp 0x000078D941FD5C15
000078d941fd7319  call 0x000078D941ED64F0
000078d941fd731e  jmp 0x000078D941FD5C2B
000078d941fd7323  sub rsp, 0x08
000078d941fd7327  push rax
000078d941fd7328  push rcx
000078d941fd7329  push rdx
000078d941fd732a  push rdi
000078d941fd732b  push rsi
000078d941fd732c  push r8
000078d941fd732e  push r9
000078d941fd7330  push r10
000078d941fd7332  push r11
000078d941fd7334  sub rsp, 0xF0
000078d941fd733b  vmovaps [rsp], xmm0
000078d941fd7340  vmovaps [rsp+0x10], xmm2
000078d941fd7346  vmovaps [rsp+0x20], xmm3
000078d941fd734c  vmovaps [rsp+0x30], xmm4
000078d941fd7352  vmovaps [rsp+0x40], xmm5
000078d941fd7358  vmovaps [rsp+0x50], xmm6
000078d941fd735e  vmovaps [rsp+0x60], xmm7
000078d941fd7364  vmovaps [rsp+0x70], xmm8
000078d941fd736a  vmovaps [rsp+0x80], xmm9
000078d941fd7373  vmovaps [rsp+0x90], xmm10
000078d941fd737c  vmovaps [rsp+0xA0], xmm11
000078d941fd7385  vmovaps [rsp+0xB0], xmm12
000078d941fd738e  vmovaps [rsp+0xC0], xmm13
000078d941fd7397  vmovaps [rsp+0xD0], xmm14
000078d941fd73a0  vmovaps [rsp+0xE0], xmm15
000078d941fd73a9  sub rsp, 0x30
000078d941fd73ad  movaps [rsp], xmm1
000078d941fd73b1  movaps [rsp+0x10], xmm6
000078d941fd73b6  movaps [rsp+0x20], xmm15
000078d941fd73bc  lea rdi, [rsp]
000078d941fd73c0  mov esi, 0x00
000078d941fd73c5  mov rax, 0x59BFBFBAA530
000078d941fd73cf  call rax
000078d941fd73d1  movaps xmm1, [rsp]
000078d941fd73d5  add rsp, 0x30
000078d941fd73d9  vmovaps xmm0, [rsp]
000078d941fd73de  vmovaps xmm2, [rsp+0x10]
000078d941fd73e4  vmovaps xmm3, [rsp+0x20]
000078d941fd73ea  vmovaps xmm4, [rsp+0x30]
000078d941fd73f0  vmovaps xmm5, [rsp+0x40]
000078d941fd73f6  vmovaps xmm6, [rsp+0x50]
000078d941fd73fc  vmovaps xmm7, [rsp+0x60]
000078d941fd7402  vmovaps xmm8, [rsp+0x70]
000078d941fd7408  vmovaps xmm9, [rsp+0x80]
000078d941fd7411  vmovaps xmm10, [rsp+0x90]
000078d941fd741a  vmovaps xmm11, [rsp+0xA0]
000078d941fd7423  vmovaps xmm12, [rsp+0xB0]
000078d941fd742c  vmovaps xmm13, [rsp+0xC0]
000078d941fd7435  vmovaps xmm14, [rsp+0xD0]
000078d941fd743e  vmovaps xmm15, [rsp+0xE0]
000078d941fd7447  add rsp, 0xF0
000078d941fd744e  pop r11
000078d941fd7450  pop r10
000078d941fd7452  pop r9
000078d941fd7454  pop r8
000078d941fd7456  pop rsi
000078d941fd7457  pop rdi
000078d941fd7458  pop rdx
000078d941fd7459  pop rcx
000078d941fd745a  pop rax
000078d941fd745b  add rsp, 0x08
000078d941fd745f  jmp 0x000078D941FD5C68
000078d941fd7464  call 0x000078D941EE5820
000078d941fd7469  jmp 0x000078D941FD5C75
000078d941fd746e  sub rsp, 0x08
000078d941fd7472  push rax
000078d941fd7473  push rcx
000078d941fd7474  push rdx
000078d941fd7475  push rdi
000078d941fd7476  push rsi
000078d941fd7477  push r8
000078d941fd7479  push r9
000078d941fd747b  push r10
000078d941fd747d  push r11
000078d941fd747f  sub rsp, 0xF0
000078d941fd7486  vmovaps [rsp], xmm0
000078d941fd748b  vmovaps [rsp+0x10], xmm1
000078d941fd7491  vmovaps [rsp+0x20], xmm2
000078d941fd7497  vmovaps [rsp+0x30], xmm3
000078d941fd749d  vmovaps [rsp+0x40], xmm4
000078d941fd74a3  vmovaps [rsp+0x50], xmm5
000078d941fd74a9  vmovaps [rsp+0x60], xmm6
000078d941fd74af  vmovaps [rsp+0x70], xmm7
000078d941fd74b5  vmovaps [rsp+0x80], xmm8
000078d941fd74be  vmovaps [rsp+0x90], xmm9
000078d941fd74c7  vmovaps [rsp+0xA0], xmm10
000078d941fd74d0  vmovaps [rsp+0xB0], xmm11
000078d941fd74d9  vmovaps [rsp+0xC0], xmm12
000078d941fd74e2  vmovaps [rsp+0xD0], xmm13
000078d941fd74eb  vmovaps [rsp+0xE0], xmm15
000078d941fd74f4  sub rsp, 0x30
000078d941fd74f8  movaps [rsp], xmm14
000078d941fd74fd  movaps [rsp+0x10], xmm4
000078d941fd7502  movaps [rsp+0x20], xmm3
000078d941fd7507  lea rdi, [rsp]
000078d941fd750b  mov esi, 0x00
000078d941fd7510  mov rax, 0x59BFBFBAA530
000078d941fd751a  call rax
000078d941fd751c  movaps xmm14, [rsp]
000078d941fd7521  add rsp, 0x30
000078d941fd7525  vmovaps xmm0, [rsp]
000078d941fd752a  vmovaps xmm1, [rsp+0x10]
000078d941fd7530  vmovaps xmm2, [rsp+0x20]
000078d941fd7536  vmovaps xmm3, [rsp+0x30]
000078d941fd753c  vmovaps xmm4, [rsp+0x40]
000078d941fd7542  vmovaps xmm5, [rsp+0x50]
000078d941fd7548  vmovaps xmm6, [rsp+0x60]
000078d941fd754e  vmovaps xmm7, [rsp+0x70]
000078d941fd7554  vmovaps xmm8, [rsp+0x80]
000078d941fd755d  vmovaps xmm9, [rsp+0x90]
000078d941fd7566  vmovaps xmm10, [rsp+0xA0]
000078d941fd756f  vmovaps xmm11, [rsp+0xB0]
000078d941fd7578  vmovaps xmm12, [rsp+0xC0]
000078d941fd7581  vmovaps xmm13, [rsp+0xD0]
000078d941fd758a  vmovaps xmm15, [rsp+0xE0]
000078d941fd7593  add rsp, 0xF0
000078d941fd759a  pop r11
000078d941fd759c  pop r10
000078d941fd759e  pop r9
000078d941fd75a0  pop r8
000078d941fd75a2  pop rsi
000078d941fd75a3  pop rdi
000078d941fd75a4  pop rdx
000078d941fd75a5  pop rcx
000078d941fd75a6  pop rax
000078d941fd75a7  add rsp, 0x08
000078d941fd75ab  jmp 0x000078D941FD5C8F
000078d941fd75b0  sub rsp, 0x08
000078d941fd75b4  push rax
000078d941fd75b5  push rcx
000078d941fd75b6  push rdx
000078d941fd75b7  push rdi
000078d941fd75b8  push rsi
000078d941fd75b9  push r8
000078d941fd75bb  push r9
000078d941fd75bd  push r10
000078d941fd75bf  push r11
000078d941fd75c1  sub rsp, 0xF0
000078d941fd75c8  vmovaps [rsp], xmm0
000078d941fd75cd  vmovaps [rsp+0x10], xmm1
000078d941fd75d3  vmovaps [rsp+0x20], xmm2
000078d941fd75d9  vmovaps [rsp+0x30], xmm3
000078d941fd75df  vmovaps [rsp+0x40], xmm4
000078d941fd75e5  vmovaps [rsp+0x50], xmm5
000078d941fd75eb  vmovaps [rsp+0x60], xmm7
000078d941fd75f1  vmovaps [rsp+0x70], xmm8
000078d941fd75f7  vmovaps [rsp+0x80], xmm9
000078d941fd7600  vmovaps [rsp+0x90], xmm10
000078d941fd7609  vmovaps [rsp+0xA0], xmm11
000078d941fd7612  vmovaps [rsp+0xB0], xmm12
000078d941fd761b  vmovaps [rsp+0xC0], xmm13
000078d941fd7624  vmovaps [rsp+0xD0], xmm14
000078d941fd762d  vmovaps [rsp+0xE0], xmm15
000078d941fd7636  sub rsp, 0x30
000078d941fd763a  movaps [rsp], xmm6
000078d941fd763e  movaps [rsp+0x10], xmm9
000078d941fd7644  movaps [rsp+0x20], xmm7
000078d941fd7649  lea rdi, [rsp]
000078d941fd764d  mov esi, 0x00
000078d941fd7652  mov rax, 0x59BFBFBAA530
000078d941fd765c  call rax
000078d941fd765e  movaps xmm6, [rsp]
000078d941fd7662  add rsp, 0x30
000078d941fd7666  vmovaps xmm0, [rsp]
000078d941fd766b  vmovaps xmm1, [rsp+0x10]
000078d941fd7671  vmovaps xmm2, [rsp+0x20]
000078d941fd7677  vmovaps xmm3, [rsp+0x30]
000078d941fd767d  vmovaps xmm4, [rsp+0x40]
000078d941fd7683  vmovaps xmm5, [rsp+0x50]
000078d941fd7689  vmovaps xmm7, [rsp+0x60]
000078d941fd768f  vmovaps xmm8, [rsp+0x70]
000078d941fd7695  vmovaps xmm9, [rsp+0x80]
000078d941fd769e  vmovaps xmm10, [rsp+0x90]
000078d941fd76a7  vmovaps xmm11, [rsp+0xA0]
000078d941fd76b0  vmovaps xmm12, [rsp+0xB0]
000078d941fd76b9  vmovaps xmm13, [rsp+0xC0]
000078d941fd76c2  vmovaps xmm14, [rsp+0xD0]
000078d941fd76cb  vmovaps xmm15, [rsp+0xE0]
000078d941fd76d4  add rsp, 0xF0
000078d941fd76db  pop r11
000078d941fd76dd  pop r10
000078d941fd76df  pop r9
000078d941fd76e1  pop r8
000078d941fd76e3  pop rsi
000078d941fd76e4  pop rdi
000078d941fd76e5  pop rdx
000078d941fd76e6  pop rcx
000078d941fd76e7  pop rax
000078d941fd76e8  add rsp, 0x08
000078d941fd76ec  jmp 0x000078D941FD5CA7
000078d941fd76f1  sub rsp, 0x08
000078d941fd76f5  push rax
000078d941fd76f6  push rcx
000078d941fd76f7  push rdx
000078d941fd76f8  push rdi
000078d941fd76f9  push rsi
000078d941fd76fa  push r8
000078d941fd76fc  push r9
000078d941fd76fe  push r10
000078d941fd7700  push r11
000078d941fd7702  sub rsp, 0xF0
000078d941fd7709  vmovaps [rsp], xmm0
000078d941fd770e  vmovaps [rsp+0x10], xmm1
000078d941fd7714  vmovaps [rsp+0x20], xmm2
000078d941fd771a  vmovaps [rsp+0x30], xmm3
000078d941fd7720  vmovaps [rsp+0x40], xmm4
000078d941fd7726  vmovaps [rsp+0x50], xmm5
000078d941fd772c  vmovaps [rsp+0x60], xmm6
000078d941fd7732  vmovaps [rsp+0x70], xmm8
000078d941fd7738  vmovaps [rsp+0x80], xmm9
000078d941fd7741  vmovaps [rsp+0x90], xmm10
000078d941fd774a  vmovaps [rsp+0xA0], xmm11
000078d941fd7753  vmovaps [rsp+0xB0], xmm12
000078d941fd775c  vmovaps [rsp+0xC0], xmm13
000078d941fd7765  vmovaps [rsp+0xD0], xmm14
000078d941fd776e  vmovaps [rsp+0xE0], xmm15
000078d941fd7777  sub rsp, 0x30
000078d941fd777b  movaps [rsp], xmm7
000078d941fd777f  movaps [rsp+0x10], xmm4
000078d941fd7784  movaps [rsp+0x20], xmm9
000078d941fd778a  lea rdi, [rsp]
000078d941fd778e  mov esi, 0x00
000078d941fd7793  mov rax, 0x59BFBFBAA530
000078d941fd779d  call rax
000078d941fd779f  movaps xmm7, [rsp]
000078d941fd77a3  add rsp, 0x30
000078d941fd77a7  vmovaps xmm0, [rsp]
000078d941fd77ac  vmovaps xmm1, [rsp+0x10]
000078d941fd77b2  vmovaps xmm2, [rsp+0x20]
000078d941fd77b8  vmovaps xmm3, [rsp+0x30]
000078d941fd77be  vmovaps xmm4, [rsp+0x40]
000078d941fd77c4  vmovaps xmm5, [rsp+0x50]
000078d941fd77ca  vmovaps xmm6, [rsp+0x60]
000078d941fd77d0  vmovaps xmm8, [rsp+0x70]
000078d941fd77d6  vmovaps xmm9, [rsp+0x80]
000078d941fd77df  vmovaps xmm10, [rsp+0x90]
000078d941fd77e8  vmovaps xmm11, [rsp+0xA0]
000078d941fd77f1  vmovaps xmm12, [rsp+0xB0]
000078d941fd77fa  vmovaps xmm13, [rsp+0xC0]
000078d941fd7803  vmovaps xmm14, [rsp+0xD0]
000078d941fd780c  vmovaps xmm15, [rsp+0xE0]
000078d941fd7815  add rsp, 0xF0
000078d941fd781c  pop r11
000078d941fd781e  pop r10
000078d941fd7820  pop r9
000078d941fd7822  pop r8
000078d941fd7824  pop rsi
000078d941fd7825  pop rdi
000078d941fd7826  pop rdx
000078d941fd7827  pop rcx
000078d941fd7828  pop rax
000078d941fd7829  add rsp, 0x08
000078d941fd782d  jmp 0x000078D941FD5CD4
000078d941fd7832  sub rsp, 0x08
000078d941fd7836  push rax
000078d941fd7837  push rcx
000078d941fd7838  push rdx
000078d941fd7839  push rdi
000078d941fd783a  push rsi
000078d941fd783b  push r8
000078d941fd783d  push r9
000078d941fd783f  push r10
000078d941fd7841  push r11
000078d941fd7843  sub rsp, 0xF0
000078d941fd784a  vmovaps [rsp], xmm0
000078d941fd784f  vmovaps [rsp+0x10], xmm1
000078d941fd7855  vmovaps [rsp+0x20], xmm2
000078d941fd785b  vmovaps [rsp+0x30], xmm3
000078d941fd7861  vmovaps [rsp+0x40], xmm5
000078d941fd7867  vmovaps [rsp+0x50], xmm6
000078d941fd786d  vmovaps [rsp+0x60], xmm7
000078d941fd7873  vmovaps [rsp+0x70], xmm8
000078d941fd7879  vmovaps [rsp+0x80], xmm9
000078d941fd7882  vmovaps [rsp+0x90], xmm10
000078d941fd788b  vmovaps [rsp+0xA0], xmm11
000078d941fd7894  vmovaps [rsp+0xB0], xmm12
000078d941fd789d  vmovaps [rsp+0xC0], xmm13
000078d941fd78a6  vmovaps [rsp+0xD0], xmm14
000078d941fd78af  vmovaps [rsp+0xE0], xmm15
000078d941fd78b8  sub rsp, 0x30
000078d941fd78bc  movaps [rsp], xmm4
000078d941fd78c0  movaps [rsp+0x10], xmm15
000078d941fd78c6  movaps [rsp+0x20], xmm9
000078d941fd78cc  lea rdi, [rsp]
000078d941fd78d0  mov esi, 0x00
000078d941fd78d5  mov rax, 0x59BFBFBAA530
000078d941fd78df  call rax
000078d941fd78e1  movaps xmm4, [rsp]
000078d941fd78e5  add rsp, 0x30
000078d941fd78e9  vmovaps xmm0, [rsp]
000078d941fd78ee  vmovaps xmm1, [rsp+0x10]
000078d941fd78f4  vmovaps xmm2, [rsp+0x20]
000078d941fd78fa  vmovaps xmm3, [rsp+0x30]
000078d941fd7900  vmovaps xmm5, [rsp+0x40]
000078d941fd7906  vmovaps xmm6, [rsp+0x50]
000078d941fd790c  vmovaps xmm7, [rsp+0x60]
000078d941fd7912  vmovaps xmm8, [rsp+0x70]
000078d941fd7918  vmovaps xmm9, [rsp+0x80]
000078d941fd7921  vmovaps xmm10, [rsp+0x90]
000078d941fd792a  vmovaps xmm11, [rsp+0xA0]
000078d941fd7933  vmovaps xmm12, [rsp+0xB0]
000078d941fd793c  vmovaps xmm13, [rsp+0xC0]
000078d941fd7945  vmovaps xmm14, [rsp+0xD0]
000078d941fd794e  vmovaps xmm15, [rsp+0xE0]
000078d941fd7957  add rsp, 0xF0
000078d941fd795e  pop r11
000078d941fd7960  pop r10
000078d941fd7962  pop r9
000078d941fd7964  pop r8
000078d941fd7966  pop rsi
000078d941fd7967  pop rdi
000078d941fd7968  pop rdx
000078d941fd7969  pop rcx
000078d941fd796a  pop rax
000078d941fd796b  add rsp, 0x08
000078d941fd796f  jmp 0x000078D941FD5CF9
000078d941fd7974  call 0x000078D941EE5820
000078d941fd7979  jmp 0x000078D941FD5D06
000078d941fd797e  sub rsp, 0x08
000078d941fd7982  push rax
000078d941fd7983  push rcx
000078d941fd7984  push rdx
000078d941fd7985  push rdi
000078d941fd7986  push rsi
000078d941fd7987  push r8
000078d941fd7989  push r9
000078d941fd798b  push r10
000078d941fd798d  push r11
000078d941fd798f  sub rsp, 0xF0
000078d941fd7996  vmovaps [rsp], xmm0
000078d941fd799b  vmovaps [rsp+0x10], xmm1
000078d941fd79a1  vmovaps [rsp+0x20], xmm2
000078d941fd79a7  vmovaps [rsp+0x30], xmm4
000078d941fd79ad  vmovaps [rsp+0x40], xmm5
000078d941fd79b3  vmovaps [rsp+0x50], xmm6
000078d941fd79b9  vmovaps [rsp+0x60], xmm7
000078d941fd79bf  vmovaps [rsp+0x70], xmm8
000078d941fd79c5  vmovaps [rsp+0x80], xmm9
000078d941fd79ce  vmovaps [rsp+0x90], xmm10
000078d941fd79d7  vmovaps [rsp+0xA0], xmm11
000078d941fd79e0  vmovaps [rsp+0xB0], xmm12
000078d941fd79e9  vmovaps [rsp+0xC0], xmm13
000078d941fd79f2  vmovaps [rsp+0xD0], xmm14
000078d941fd79fb  vmovaps [rsp+0xE0], xmm15
000078d941fd7a04  sub rsp, 0x30
000078d941fd7a08  movaps [rsp], xmm3
000078d941fd7a0c  movaps [rsp+0x10], xmm1
000078d941fd7a11  movaps [rsp+0x20], xmm9
000078d941fd7a17  lea rdi, [rsp]
000078d941fd7a1b  mov esi, 0x00
000078d941fd7a20  mov rax, 0x59BFBFBAA530
000078d941fd7a2a  call rax
000078d941fd7a2c  movaps xmm3, [rsp]
000078d941fd7a30  add rsp, 0x30
000078d941fd7a34  vmovaps xmm0, [rsp]
000078d941fd7a39  vmovaps xmm1, [rsp+0x10]
000078d941fd7a3f  vmovaps xmm2, [rsp+0x20]
000078d941fd7a45  vmovaps xmm4, [rsp+0x30]
000078d941fd7a4b  vmovaps xmm5, [rsp+0x40]
000078d941fd7a51  vmovaps xmm6, [rsp+0x50]
000078d941fd7a57  vmovaps xmm7, [rsp+0x60]
000078d941fd7a5d  vmovaps xmm8, [rsp+0x70]
000078d941fd7a63  vmovaps xmm9, [rsp+0x80]
000078d941fd7a6c  vmovaps xmm10, [rsp+0x90]
000078d941fd7a75  vmovaps xmm11, [rsp+0xA0]
000078d941fd7a7e  vmovaps xmm12, [rsp+0xB0]
000078d941fd7a87  vmovaps xmm13, [rsp+0xC0]
000078d941fd7a90  vmovaps xmm14, [rsp+0xD0]
000078d941fd7a99  vmovaps xmm15, [rsp+0xE0]
000078d941fd7aa2  add rsp, 0xF0
000078d941fd7aa9  pop r11
000078d941fd7aab  pop r10
000078d941fd7aad  pop r9
000078d941fd7aaf  pop r8
000078d941fd7ab1  pop rsi
000078d941fd7ab2  pop rdi
000078d941fd7ab3  pop rdx
000078d941fd7ab4  pop rcx
000078d941fd7ab5  pop rax
000078d941fd7ab6  add rsp, 0x08
000078d941fd7aba  jmp 0x000078D941FD5D43
000078d941fd7abf  sub rsp, 0x08
000078d941fd7ac3  push rax
000078d941fd7ac4  push rcx
000078d941fd7ac5  push rdx
000078d941fd7ac6  push rdi
000078d941fd7ac7  push rsi
000078d941fd7ac8  push r8
000078d941fd7aca  push r9
000078d941fd7acc  push r10
000078d941fd7ace  push r11
000078d941fd7ad0  sub rsp, 0xF0
000078d941fd7ad7  vmovaps [rsp], xmm0
000078d941fd7adc  vmovaps [rsp+0x10], xmm2
000078d941fd7ae2  vmovaps [rsp+0x20], xmm3
000078d941fd7ae8  vmovaps [rsp+0x30], xmm4
000078d941fd7aee  vmovaps [rsp+0x40], xmm5
000078d941fd7af4  vmovaps [rsp+0x50], xmm6
000078d941fd7afa  vmovaps [rsp+0x60], xmm7
000078d941fd7b00  vmovaps [rsp+0x70], xmm8
000078d941fd7b06  vmovaps [rsp+0x80], xmm9
000078d941fd7b0f  vmovaps [rsp+0x90], xmm10
000078d941fd7b18  vmovaps [rsp+0xA0], xmm11
000078d941fd7b21  vmovaps [rsp+0xB0], xmm12
000078d941fd7b2a  vmovaps [rsp+0xC0], xmm13
000078d941fd7b33  vmovaps [rsp+0xD0], xmm14
000078d941fd7b3c  vmovaps [rsp+0xE0], xmm15
000078d941fd7b45  sub rsp, 0x30
000078d941fd7b49  movaps [rsp], xmm1
000078d941fd7b4d  movaps [rsp+0x10], xmm15
000078d941fd7b53  movaps [rsp+0x20], xmm9
000078d941fd7b59  lea rdi, [rsp]
000078d941fd7b5d  mov esi, 0x00
000078d941fd7b62  mov rax, 0x59BFBFBAA530
000078d941fd7b6c  call rax
000078d941fd7b6e  movaps xmm1, [rsp]
000078d941fd7b72  add rsp, 0x30
000078d941fd7b76  vmovaps xmm0, [rsp]
000078d941fd7b7b  vmovaps xmm2, [rsp+0x10]
000078d941fd7b81  vmovaps xmm3, [rsp+0x20]
000078d941fd7b87  vmovaps xmm4, [rsp+0x30]
000078d941fd7b8d  vmovaps xmm5, [rsp+0x40]
000078d941fd7b93  vmovaps xmm6, [rsp+0x50]
000078d941fd7b99  vmovaps xmm7, [rsp+0x60]
000078d941fd7b9f  vmovaps xmm8, [rsp+0x70]
000078d941fd7ba5  vmovaps xmm9, [rsp+0x80]
000078d941fd7bae  vmovaps xmm10, [rsp+0x90]
000078d941fd7bb7  vmovaps xmm11, [rsp+0xA0]
000078d941fd7bc0  vmovaps xmm12, [rsp+0xB0]
000078d941fd7bc9  vmovaps xmm13, [rsp+0xC0]
000078d941fd7bd2  vmovaps xmm14, [rsp+0xD0]
000078d941fd7bdb  vmovaps xmm15, [rsp+0xE0]
000078d941fd7be4  add rsp, 0xF0
000078d941fd7beb  pop r11
000078d941fd7bed  pop r10
000078d941fd7bef  pop r9
000078d941fd7bf1  pop r8
000078d941fd7bf3  pop rsi
000078d941fd7bf4  pop rdi
000078d941fd7bf5  pop rdx
000078d941fd7bf6  pop rcx
000078d941fd7bf7  pop rax
000078d941fd7bf8  add rsp, 0x08
000078d941fd7bfc  jmp 0x000078D941FD5DCB
000078d941fd7c01  call 0x000078D941EE5820
000078d941fd7c06  jmp 0x000078D941FD5DD8
000078d941fd7c0b  sub rsp, 0x08
000078d941fd7c0f  push rax
000078d941fd7c10  push rcx
000078d941fd7c11  push rdx
000078d941fd7c12  push rdi
000078d941fd7c13  push rsi
000078d941fd7c14  push r8
000078d941fd7c16  push r9
000078d941fd7c18  push r10
000078d941fd7c1a  push r11
000078d941fd7c1c  sub rsp, 0xF0
000078d941fd7c23  vmovaps [rsp], xmm0
000078d941fd7c28  vmovaps [rsp+0x10], xmm2
000078d941fd7c2e  vmovaps [rsp+0x20], xmm3
000078d941fd7c34  vmovaps [rsp+0x30], xmm4
000078d941fd7c3a  vmovaps [rsp+0x40], xmm5
000078d941fd7c40  vmovaps [rsp+0x50], xmm6
000078d941fd7c46  vmovaps [rsp+0x60], xmm7
000078d941fd7c4c  vmovaps [rsp+0x70], xmm8
000078d941fd7c52  vmovaps [rsp+0x80], xmm9
000078d941fd7c5b  vmovaps [rsp+0x90], xmm10
000078d941fd7c64  vmovaps [rsp+0xA0], xmm11
000078d941fd7c6d  vmovaps [rsp+0xB0], xmm12
000078d941fd7c76  vmovaps [rsp+0xC0], xmm13
000078d941fd7c7f  vmovaps [rsp+0xD0], xmm14
000078d941fd7c88  vmovaps [rsp+0xE0], xmm15
000078d941fd7c91  sub rsp, 0x30
000078d941fd7c95  movaps [rsp], xmm1
000078d941fd7c99  movaps [rsp+0x10], xmm5
000078d941fd7c9e  movaps [rsp+0x20], xmm7
000078d941fd7ca3  lea rdi, [rsp]
000078d941fd7ca7  mov esi, 0x00
000078d941fd7cac  mov rax, 0x59BFBFBAA530
000078d941fd7cb6  call rax
000078d941fd7cb8  movaps xmm1, [rsp]
000078d941fd7cbc  add rsp, 0x30
000078d941fd7cc0  vmovaps xmm0, [rsp]
000078d941fd7cc5  vmovaps xmm2, [rsp+0x10]
000078d941fd7ccb  vmovaps xmm3, [rsp+0x20]
000078d941fd7cd1  vmovaps xmm4, [rsp+0x30]
000078d941fd7cd7  vmovaps xmm5, [rsp+0x40]
000078d941fd7cdd  vmovaps xmm6, [rsp+0x50]
000078d941fd7ce3  vmovaps xmm7, [rsp+0x60]
000078d941fd7ce9  vmovaps xmm8, [rsp+0x70]
000078d941fd7cef  vmovaps xmm9, [rsp+0x80]
000078d941fd7cf8  vmovaps xmm10, [rsp+0x90]
000078d941fd7d01  vmovaps xmm11, [rsp+0xA0]
000078d941fd7d0a  vmovaps xmm12, [rsp+0xB0]
000078d941fd7d13  vmovaps xmm13, [rsp+0xC0]
000078d941fd7d1c  vmovaps xmm14, [rsp+0xD0]
000078d941fd7d25  vmovaps xmm15, [rsp+0xE0]
000078d941fd7d2e  add rsp, 0xF0
000078d941fd7d35  pop r11
000078d941fd7d37  pop r10
000078d941fd7d39  pop r9
000078d941fd7d3b  pop r8
000078d941fd7d3d  pop rsi
000078d941fd7d3e  pop rdi
000078d941fd7d3f  pop rdx
000078d941fd7d40  pop rcx
000078d941fd7d41  pop rax
000078d941fd7d42  add rsp, 0x08
000078d941fd7d46  jmp 0x000078D941FD5E7D
000078d941fd7d4b  sub rsp, 0x08
000078d941fd7d4f  push rax
000078d941fd7d50  push rcx
000078d941fd7d51  push rdx
000078d941fd7d52  push rdi
000078d941fd7d53  push rsi
000078d941fd7d54  push r8
000078d941fd7d56  push r9
000078d941fd7d58  push r10
000078d941fd7d5a  push r11
000078d941fd7d5c  sub rsp, 0xF0
000078d941fd7d63  vmovaps [rsp], xmm0
000078d941fd7d68  vmovaps [rsp+0x10], xmm1
000078d941fd7d6e  vmovaps [rsp+0x20], xmm2
000078d941fd7d74  vmovaps [rsp+0x30], xmm3
000078d941fd7d7a  vmovaps [rsp+0x40], xmm4
000078d941fd7d80  vmovaps [rsp+0x50], xmm5
000078d941fd7d86  vmovaps [rsp+0x60], xmm6
000078d941fd7d8c  vmovaps [rsp+0x70], xmm8
000078d941fd7d92  vmovaps [rsp+0x80], xmm9
000078d941fd7d9b  vmovaps [rsp+0x90], xmm10
000078d941fd7da4  vmovaps [rsp+0xA0], xmm11
000078d941fd7dad  vmovaps [rsp+0xB0], xmm12
000078d941fd7db6  vmovaps [rsp+0xC0], xmm13
000078d941fd7dbf  vmovaps [rsp+0xD0], xmm14
000078d941fd7dc8  vmovaps [rsp+0xE0], xmm15
000078d941fd7dd1  sub rsp, 0x30
000078d941fd7dd5  movaps [rsp], xmm7
000078d941fd7dd9  movaps [rsp+0x10], xmm5
000078d941fd7dde  movaps [rsp+0x20], xmm15
000078d941fd7de4  lea rdi, [rsp]
000078d941fd7de8  mov esi, 0x00
000078d941fd7ded  mov rax, 0x59BFBFBAA530
000078d941fd7df7  call rax
000078d941fd7df9  movaps xmm7, [rsp]
000078d941fd7dfd  add rsp, 0x30
000078d941fd7e01  vmovaps xmm0, [rsp]
000078d941fd7e06  vmovaps xmm1, [rsp+0x10]
000078d941fd7e0c  vmovaps xmm2, [rsp+0x20]
000078d941fd7e12  vmovaps xmm3, [rsp+0x30]
000078d941fd7e18  vmovaps xmm4, [rsp+0x40]
000078d941fd7e1e  vmovaps xmm5, [rsp+0x50]
000078d941fd7e24  vmovaps xmm6, [rsp+0x60]
000078d941fd7e2a  vmovaps xmm8, [rsp+0x70]
000078d941fd7e30  vmovaps xmm9, [rsp+0x80]
000078d941fd7e39  vmovaps xmm10, [rsp+0x90]
000078d941fd7e42  vmovaps xmm11, [rsp+0xA0]
000078d941fd7e4b  vmovaps xmm12, [rsp+0xB0]
000078d941fd7e54  vmovaps xmm13, [rsp+0xC0]
000078d941fd7e5d  vmovaps xmm14, [rsp+0xD0]
000078d941fd7e66  vmovaps xmm15, [rsp+0xE0]
000078d941fd7e6f  add rsp, 0xF0
000078d941fd7e76  pop r11
000078d941fd7e78  pop r10
000078d941fd7e7a  pop r9
000078d941fd7e7c  pop r8
000078d941fd7e7e  pop rsi
000078d941fd7e7f  pop rdi
000078d941fd7e80  pop rdx
000078d941fd7e81  pop rcx
000078d941fd7e82  pop rax
000078d941fd7e83  add rsp, 0x08
000078d941fd7e87  jmp 0x000078D941FD5EB3
000078d941fd7e8c  call 0x000078D941ED64F0
000078d941fd7e91  jmp 0x000078D941FD5EC0
000078d941fd7e96  sub rsp, 0x08
000078d941fd7e9a  push rax
000078d941fd7e9b  push rcx
000078d941fd7e9c  push rdx
000078d941fd7e9d  push rdi
000078d941fd7e9e  push rsi
000078d941fd7e9f  push r8
000078d941fd7ea1  push r9
000078d941fd7ea3  push r10
000078d941fd7ea5  push r11
000078d941fd7ea7  sub rsp, 0xF0
000078d941fd7eae  vmovaps [rsp], xmm0
000078d941fd7eb3  vmovaps [rsp+0x10], xmm1
000078d941fd7eb9  vmovaps [rsp+0x20], xmm2
000078d941fd7ebf  vmovaps [rsp+0x30], xmm3
000078d941fd7ec5  vmovaps [rsp+0x40], xmm4
000078d941fd7ecb  vmovaps [rsp+0x50], xmm5
000078d941fd7ed1  vmovaps [rsp+0x60], xmm6
000078d941fd7ed7  vmovaps [rsp+0x70], xmm7
000078d941fd7edd  vmovaps [rsp+0x80], xmm8
000078d941fd7ee6  vmovaps [rsp+0x90], xmm9
000078d941fd7eef  vmovaps [rsp+0xA0], xmm10
000078d941fd7ef8  vmovaps [rsp+0xB0], xmm11
000078d941fd7f01  vmovaps [rsp+0xC0], xmm12
000078d941fd7f0a  vmovaps [rsp+0xD0], xmm13
000078d941fd7f13  vmovaps [rsp+0xE0], xmm14
000078d941fd7f1c  sub rsp, 0x30
000078d941fd7f20  movaps [rsp], xmm15
000078d941fd7f25  movaps [rsp+0x10], xmm5
000078d941fd7f2a  movaps [rsp+0x20], xmm3
000078d941fd7f2f  lea rdi, [rsp]
000078d941fd7f33  mov esi, 0x00
000078d941fd7f38  mov rax, 0x59BFBFBAA530
000078d941fd7f42  call rax
000078d941fd7f44  movaps xmm15, [rsp]
000078d941fd7f49  add rsp, 0x30
000078d941fd7f4d  vmovaps xmm0, [rsp]
000078d941fd7f52  vmovaps xmm1, [rsp+0x10]
000078d941fd7f58  vmovaps xmm2, [rsp+0x20]
000078d941fd7f5e  vmovaps xmm3, [rsp+0x30]
000078d941fd7f64  vmovaps xmm4, [rsp+0x40]
000078d941fd7f6a  vmovaps xmm5, [rsp+0x50]
000078d941fd7f70  vmovaps xmm6, [rsp+0x60]
000078d941fd7f76  vmovaps xmm7, [rsp+0x70]
000078d941fd7f7c  vmovaps xmm8, [rsp+0x80]
000078d941fd7f85  vmovaps xmm9, [rsp+0x90]
000078d941fd7f8e  vmovaps xmm10, [rsp+0xA0]
000078d941fd7f97  vmovaps xmm11, [rsp+0xB0]
000078d941fd7fa0  vmovaps xmm12, [rsp+0xC0]
000078d941fd7fa9  vmovaps xmm13, [rsp+0xD0]
000078d941fd7fb2  vmovaps xmm14, [rsp+0xE0]
000078d941fd7fbb  add rsp, 0xF0
000078d941fd7fc2  pop r11
000078d941fd7fc4  pop r10
000078d941fd7fc6  pop r9
000078d941fd7fc8  pop r8
000078d941fd7fca  pop rsi
000078d941fd7fcb  pop rdi
000078d941fd7fcc  pop rdx
000078d941fd7fcd  pop rcx
000078d941fd7fce  pop rax
000078d941fd7fcf  add rsp, 0x08
000078d941fd7fd3  jmp 0x000078D941FD5EE6
000078d941fd7fd8  sub rsp, 0x08
000078d941fd7fdc  push rax
000078d941fd7fdd  push rcx
000078d941fd7fde  push rdx
000078d941fd7fdf  push rdi
000078d941fd7fe0  push rsi
000078d941fd7fe1  push r8
000078d941fd7fe3  push r9
000078d941fd7fe5  push r10
000078d941fd7fe7  push r11
000078d941fd7fe9  sub rsp, 0xF0
000078d941fd7ff0  vmovaps [rsp], xmm0
000078d941fd7ff5  vmovaps [rsp+0x10], xmm2
000078d941fd7ffb  vmovaps [rsp+0x20], xmm3
000078d941fd8001  vmovaps [rsp+0x30], xmm4
000078d941fd8007  vmovaps [rsp+0x40], xmm5
000078d941fd800d  vmovaps [rsp+0x50], xmm6
000078d941fd8013  vmovaps [rsp+0x60], xmm7
000078d941fd8019  vmovaps [rsp+0x70], xmm8
000078d941fd801f  vmovaps [rsp+0x80], xmm9
000078d941fd8028  vmovaps [rsp+0x90], xmm10
000078d941fd8031  vmovaps [rsp+0xA0], xmm11
000078d941fd803a  vmovaps [rsp+0xB0], xmm12
000078d941fd8043  vmovaps [rsp+0xC0], xmm13
000078d941fd804c  vmovaps [rsp+0xD0], xmm14
000078d941fd8055  vmovaps [rsp+0xE0], xmm15
000078d941fd805e  sub rsp, 0x30
000078d941fd8062  movaps [rsp], xmm1
000078d941fd8066  movaps [rsp+0x10], xmm5
000078d941fd806b  movaps [rsp+0x20], xmm4
000078d941fd8070  lea rdi, [rsp]
000078d941fd8074  mov esi, 0x00
000078d941fd8079  mov rax, 0x59BFBFBAA530
000078d941fd8083  call rax
000078d941fd8085  movaps xmm1, [rsp]
000078d941fd8089  add rsp, 0x30
000078d941fd808d  vmovaps xmm0, [rsp]
000078d941fd8092  vmovaps xmm2, [rsp+0x10]
000078d941fd8098  vmovaps xmm3, [rsp+0x20]
000078d941fd809e  vmovaps xmm4, [rsp+0x30]
000078d941fd80a4  vmovaps xmm5, [rsp+0x40]
000078d941fd80aa  vmovaps xmm6, [rsp+0x50]
000078d941fd80b0  vmovaps xmm7, [rsp+0x60]
000078d941fd80b6  vmovaps xmm8, [rsp+0x70]
000078d941fd80bc  vmovaps xmm9, [rsp+0x80]
000078d941fd80c5  vmovaps xmm10, [rsp+0x90]
000078d941fd80ce  vmovaps xmm11, [rsp+0xA0]
000078d941fd80d7  vmovaps xmm12, [rsp+0xB0]
000078d941fd80e0  vmovaps xmm13, [rsp+0xC0]
000078d941fd80e9  vmovaps xmm14, [rsp+0xD0]
000078d941fd80f2  vmovaps xmm15, [rsp+0xE0]
000078d941fd80fb  add rsp, 0xF0
000078d941fd8102  pop r11
000078d941fd8104  pop r10
000078d941fd8106  pop r9
000078d941fd8108  pop r8
000078d941fd810a  pop rsi
000078d941fd810b  pop rdi
000078d941fd810c  pop rdx
000078d941fd810d  pop rcx
000078d941fd810e  pop rax
000078d941fd810f  add rsp, 0x08
000078d941fd8113  jmp 0x000078D941FD5F06
000078d941fd8118  sub rsp, 0x08
000078d941fd811c  push rax
000078d941fd811d  push rcx
000078d941fd811e  push rdx
000078d941fd811f  push rdi
000078d941fd8120  push rsi
000078d941fd8121  push r8
000078d941fd8123  push r9
000078d941fd8125  push r10
000078d941fd8127  push r11
000078d941fd8129  sub rsp, 0xF0
000078d941fd8130  vmovaps [rsp], xmm0
000078d941fd8135  vmovaps [rsp+0x10], xmm1
000078d941fd813b  vmovaps [rsp+0x20], xmm2
000078d941fd8141  vmovaps [rsp+0x30], xmm3
000078d941fd8147  vmovaps [rsp+0x40], xmm5
000078d941fd814d  vmovaps [rsp+0x50], xmm6
000078d941fd8153  vmovaps [rsp+0x60], xmm7
000078d941fd8159  vmovaps [rsp+0x70], xmm8
000078d941fd815f  vmovaps [rsp+0x80], xmm9
000078d941fd8168  vmovaps [rsp+0x90], xmm10
000078d941fd8171  vmovaps [rsp+0xA0], xmm11
000078d941fd817a  vmovaps [rsp+0xB0], xmm12
000078d941fd8183  vmovaps [rsp+0xC0], xmm13
000078d941fd818c  vmovaps [rsp+0xD0], xmm14
000078d941fd8195  vmovaps [rsp+0xE0], xmm15
000078d941fd819e  sub rsp, 0x30
000078d941fd81a2  movaps [rsp], xmm4
000078d941fd81a6  movaps [rsp+0x10], xmm3
000078d941fd81ab  movaps [rsp+0x20], xmm5
000078d941fd81b0  lea rdi, [rsp]
000078d941fd81b4  mov esi, 0x00
000078d941fd81b9  mov rax, 0x59BFBFBAA530
000078d941fd81c3  call rax
000078d941fd81c5  movaps xmm4, [rsp]
000078d941fd81c9  add rsp, 0x30
000078d941fd81cd  vmovaps xmm0, [rsp]
000078d941fd81d2  vmovaps xmm1, [rsp+0x10]
000078d941fd81d8  vmovaps xmm2, [rsp+0x20]
000078d941fd81de  vmovaps xmm3, [rsp+0x30]
000078d941fd81e4  vmovaps xmm5, [rsp+0x40]
000078d941fd81ea  vmovaps xmm6, [rsp+0x50]
000078d941fd81f0  vmovaps xmm7, [rsp+0x60]
000078d941fd81f6  vmovaps xmm8, [rsp+0x70]
000078d941fd81fc  vmovaps xmm9, [rsp+0x80]
000078d941fd8205  vmovaps xmm10, [rsp+0x90]
000078d941fd820e  vmovaps xmm11, [rsp+0xA0]
000078d941fd8217  vmovaps xmm12, [rsp+0xB0]
000078d941fd8220  vmovaps xmm13, [rsp+0xC0]
000078d941fd8229  vmovaps xmm14, [rsp+0xD0]
000078d941fd8232  vmovaps xmm15, [rsp+0xE0]
000078d941fd823b  add rsp, 0xF0
000078d941fd8242  pop r11
000078d941fd8244  pop r10
000078d941fd8246  pop r9
000078d941fd8248  pop r8
000078d941fd824a  pop rsi
000078d941fd824b  pop rdi
000078d941fd824c  pop rdx
000078d941fd824d  pop rcx
000078d941fd824e  pop rax
000078d941fd824f  add rsp, 0x08
000078d941fd8253  jmp 0x000078D941FD5F54
000078d941fd8258  call 0x000078D941ED64F0
000078d941fd825d  jmp 0x000078D941FD5F61
000078d941fd8262  sub rsp, 0x08
000078d941fd8266  push rax
000078d941fd8267  push rcx
000078d941fd8268  push rdx
000078d941fd8269  push rdi
000078d941fd826a  push rsi
000078d941fd826b  push r8
000078d941fd826d  push r9
000078d941fd826f  push r10
000078d941fd8271  push r11
000078d941fd8273  sub rsp, 0xF0
000078d941fd827a  vmovaps [rsp], xmm0
000078d941fd827f  vmovaps [rsp+0x10], xmm1
000078d941fd8285  vmovaps [rsp+0x20], xmm2
000078d941fd828b  vmovaps [rsp+0x30], xmm3
000078d941fd8291  vmovaps [rsp+0x40], xmm4
000078d941fd8297  vmovaps [rsp+0x50], xmm6
000078d941fd829d  vmovaps [rsp+0x60], xmm7
000078d941fd82a3  vmovaps [rsp+0x70], xmm8
000078d941fd82a9  vmovaps [rsp+0x80], xmm9
000078d941fd82b2  vmovaps [rsp+0x90], xmm10
000078d941fd82bb  vmovaps [rsp+0xA0], xmm11
000078d941fd82c4  vmovaps [rsp+0xB0], xmm12
000078d941fd82cd  vmovaps [rsp+0xC0], xmm13
000078d941fd82d6  vmovaps [rsp+0xD0], xmm14
000078d941fd82df  vmovaps [rsp+0xE0], xmm15
000078d941fd82e8  sub rsp, 0x30
000078d941fd82ec  movaps [rsp], xmm5
000078d941fd82f0  movaps [rsp+0x10], xmm6
000078d941fd82f5  movaps [rsp+0x20], xmm3
000078d941fd82fa  lea rdi, [rsp]
000078d941fd82fe  mov esi, 0x00
000078d941fd8303  mov rax, 0x59BFBFBAA530
000078d941fd830d  call rax
000078d941fd830f  movaps xmm5, [rsp]
000078d941fd8313  add rsp, 0x30
000078d941fd8317  vmovaps xmm0, [rsp]
000078d941fd831c  vmovaps xmm1, [rsp+0x10]
000078d941fd8322  vmovaps xmm2, [rsp+0x20]
000078d941fd8328  vmovaps xmm3, [rsp+0x30]
000078d941fd832e  vmovaps xmm4, [rsp+0x40]
000078d941fd8334  vmovaps xmm6, [rsp+0x50]
000078d941fd833a  vmovaps xmm7, [rsp+0x60]
000078d941fd8340  vmovaps xmm8, [rsp+0x70]
000078d941fd8346  vmovaps xmm9, [rsp+0x80]
000078d941fd834f  vmovaps xmm10, [rsp+0x90]
000078d941fd8358  vmovaps xmm11, [rsp+0xA0]
000078d941fd8361  vmovaps xmm12, [rsp+0xB0]
000078d941fd836a  vmovaps xmm13, [rsp+0xC0]
000078d941fd8373  vmovaps xmm14, [rsp+0xD0]
000078d941fd837c  vmovaps xmm15, [rsp+0xE0]
000078d941fd8385  add rsp, 0xF0
000078d941fd838c  pop r11
000078d941fd838e  pop r10
000078d941fd8390  pop r9
000078d941fd8392  pop r8
000078d941fd8394  pop rsi
000078d941fd8395  pop rdi
000078d941fd8396  pop rdx
000078d941fd8397  pop rcx
000078d941fd8398  pop rax
000078d941fd8399  add rsp, 0x08
000078d941fd839d  jmp 0x000078D941FD5F87
000078d941fd83a2  sub rsp, 0x08
000078d941fd83a6  push rax
000078d941fd83a7  push rcx
000078d941fd83a8  push rdx
000078d941fd83a9  push rdi
000078d941fd83aa  push rsi
000078d941fd83ab  push r8
000078d941fd83ad  push r9
000078d941fd83af  push r10
000078d941fd83b1  push r11
000078d941fd83b3  sub rsp, 0xF0
000078d941fd83ba  vmovaps [rsp], xmm0
000078d941fd83bf  vmovaps [rsp+0x10], xmm1
000078d941fd83c5  vmovaps [rsp+0x20], xmm2
000078d941fd83cb  vmovaps [rsp+0x30], xmm3
000078d941fd83d1  vmovaps [rsp+0x40], xmm4
000078d941fd83d7  vmovaps [rsp+0x50], xmm5
000078d941fd83dd  vmovaps [rsp+0x60], xmm7
000078d941fd83e3  vmovaps [rsp+0x70], xmm8
000078d941fd83e9  vmovaps [rsp+0x80], xmm9
000078d941fd83f2  vmovaps [rsp+0x90], xmm10
000078d941fd83fb  vmovaps [rsp+0xA0], xmm11
000078d941fd8404  vmovaps [rsp+0xB0], xmm12
000078d941fd840d  vmovaps [rsp+0xC0], xmm13
000078d941fd8416  vmovaps [rsp+0xD0], xmm14
000078d941fd841f  vmovaps [rsp+0xE0], xmm15
000078d941fd8428  sub rsp, 0x30
000078d941fd842c  movaps [rsp], xmm6
000078d941fd8430  movaps [rsp+0x10], xmm9
000078d941fd8436  movaps [rsp+0x20], xmm1
000078d941fd843b  lea rdi, [rsp]
000078d941fd843f  mov esi, 0x00
000078d941fd8444  mov rax, 0x59BFBFBAA530
000078d941fd844e  call rax
000078d941fd8450  movaps xmm6, [rsp]
000078d941fd8454  add rsp, 0x30
000078d941fd8458  vmovaps xmm0, [rsp]
000078d941fd845d  vmovaps xmm1, [rsp+0x10]
000078d941fd8463  vmovaps xmm2, [rsp+0x20]
000078d941fd8469  vmovaps xmm3, [rsp+0x30]
000078d941fd846f  vmovaps xmm4, [rsp+0x40]
000078d941fd8475  vmovaps xmm5, [rsp+0x50]
000078d941fd847b  vmovaps xmm7, [rsp+0x60]
000078d941fd8481  vmovaps xmm8, [rsp+0x70]
000078d941fd8487  vmovaps xmm9, [rsp+0x80]
000078d941fd8490  vmovaps xmm10, [rsp+0x90]
000078d941fd8499  vmovaps xmm11, [rsp+0xA0]
000078d941fd84a2  vmovaps xmm12, [rsp+0xB0]
000078d941fd84ab  vmovaps xmm13, [rsp+0xC0]
000078d941fd84b4  vmovaps xmm14, [rsp+0xD0]
000078d941fd84bd  vmovaps xmm15, [rsp+0xE0]
000078d941fd84c6  add rsp, 0xF0
000078d941fd84cd  pop r11
000078d941fd84cf  pop r10
000078d941fd84d1  pop r9
000078d941fd84d3  pop r8
000078d941fd84d5  pop rsi
000078d941fd84d6  pop rdi
000078d941fd84d7  pop rdx
000078d941fd84d8  pop rcx
000078d941fd84d9  pop rax
000078d941fd84da  add rsp, 0x08
000078d941fd84de  jmp 0x000078D941FD5FAB
000078d941fd84e3  sub rsp, 0x08
000078d941fd84e7  push rax
000078d941fd84e8  push rcx
000078d941fd84e9  push rdx
000078d941fd84ea  push rdi
000078d941fd84eb  push rsi
000078d941fd84ec  push r8
000078d941fd84ee  push r9
000078d941fd84f0  push r10
000078d941fd84f2  push r11
000078d941fd84f4  sub rsp, 0xF0
000078d941fd84fb  vmovaps [rsp], xmm0
000078d941fd8500  vmovaps [rsp+0x10], xmm1
000078d941fd8506  vmovaps [rsp+0x20], xmm2
000078d941fd850c  vmovaps [rsp+0x30], xmm3
000078d941fd8512  vmovaps [rsp+0x40], xmm4
000078d941fd8518  vmovaps [rsp+0x50], xmm5
000078d941fd851e  vmovaps [rsp+0x60], xmm6
000078d941fd8524  vmovaps [rsp+0x70], xmm7
000078d941fd852a  vmovaps [rsp+0x80], xmm8
000078d941fd8533  vmovaps [rsp+0x90], xmm10
000078d941fd853c  vmovaps [rsp+0xA0], xmm11
000078d941fd8545  vmovaps [rsp+0xB0], xmm12
000078d941fd854e  vmovaps [rsp+0xC0], xmm13
000078d941fd8557  vmovaps [rsp+0xD0], xmm14
000078d941fd8560  vmovaps [rsp+0xE0], xmm15
000078d941fd8569  sub rsp, 0x30
000078d941fd856d  movaps [rsp], xmm9
000078d941fd8572  movaps [rsp+0x10], xmm3
000078d941fd8577  movaps [rsp+0x20], xmm1
000078d941fd857c  lea rdi, [rsp]
000078d941fd8580  mov esi, 0x00
000078d941fd8585  mov rax, 0x59BFBFBAA530
000078d941fd858f  call rax
000078d941fd8591  movaps xmm9, [rsp]
000078d941fd8596  add rsp, 0x30
000078d941fd859a  vmovaps xmm0, [rsp]
000078d941fd859f  vmovaps xmm1, [rsp+0x10]
000078d941fd85a5  vmovaps xmm2, [rsp+0x20]
000078d941fd85ab  vmovaps xmm3, [rsp+0x30]
000078d941fd85b1  vmovaps xmm4, [rsp+0x40]
000078d941fd85b7  vmovaps xmm5, [rsp+0x50]
000078d941fd85bd  vmovaps xmm6, [rsp+0x60]
000078d941fd85c3  vmovaps xmm7, [rsp+0x70]
000078d941fd85c9  vmovaps xmm8, [rsp+0x80]
000078d941fd85d2  vmovaps xmm10, [rsp+0x90]
000078d941fd85db  vmovaps xmm11, [rsp+0xA0]
000078d941fd85e4  vmovaps xmm12, [rsp+0xB0]
000078d941fd85ed  vmovaps xmm13, [rsp+0xC0]
000078d941fd85f6  vmovaps xmm14, [rsp+0xD0]
000078d941fd85ff  vmovaps xmm15, [rsp+0xE0]
000078d941fd8608  add rsp, 0xF0
000078d941fd860f  pop r11
000078d941fd8611  pop r10
000078d941fd8613  pop r9
000078d941fd8615  pop r8
000078d941fd8617  pop rsi
000078d941fd8618  pop rdi
000078d941fd8619  pop rdx
000078d941fd861a  pop rcx
000078d941fd861b  pop rax
000078d941fd861c  add rsp, 0x08
000078d941fd8620  jmp 0x000078D941FD5FF7
000078d941fd8625  call 0x000078D941ED64F0
000078d941fd862a  jmp 0x000078D941FD6004
000078d941fd862f  sub rsp, 0x08
000078d941fd8633  push rax
000078d941fd8634  push rcx
000078d941fd8635  push rdx
000078d941fd8636  push rdi
000078d941fd8637  push rsi
000078d941fd8638  push r8
000078d941fd863a  push r9
000078d941fd863c  push r10
000078d941fd863e  push r11
000078d941fd8640  sub rsp, 0xF0
000078d941fd8647  vmovaps [rsp], xmm0
000078d941fd864c  vmovaps [rsp+0x10], xmm1
000078d941fd8652  vmovaps [rsp+0x20], xmm2
000078d941fd8658  vmovaps [rsp+0x30], xmm3
000078d941fd865e  vmovaps [rsp+0x40], xmm4
000078d941fd8664  vmovaps [rsp+0x50], xmm5
000078d941fd866a  vmovaps [rsp+0x60], xmm6
000078d941fd8670  vmovaps [rsp+0x70], xmm7
000078d941fd8676  vmovaps [rsp+0x80], xmm8
000078d941fd867f  vmovaps [rsp+0x90], xmm9
000078d941fd8688  vmovaps [rsp+0xA0], xmm10
000078d941fd8691  vmovaps [rsp+0xB0], xmm11
000078d941fd869a  vmovaps [rsp+0xC0], xmm12
000078d941fd86a3  vmovaps [rsp+0xD0], xmm13
000078d941fd86ac  vmovaps [rsp+0xE0], xmm14
000078d941fd86b5  sub rsp, 0x30
000078d941fd86b9  movaps [rsp], xmm15
000078d941fd86be  movaps [rsp+0x10], xmm3
000078d941fd86c3  movaps [rsp+0x20], xmm7
000078d941fd86c8  lea rdi, [rsp]
000078d941fd86cc  mov esi, 0x00
000078d941fd86d1  mov rax, 0x59BFBFBAA530
000078d941fd86db  call rax
000078d941fd86dd  movaps xmm15, [rsp]
000078d941fd86e2  add rsp, 0x30
000078d941fd86e6  vmovaps xmm0, [rsp]
000078d941fd86eb  vmovaps xmm1, [rsp+0x10]
000078d941fd86f1  vmovaps xmm2, [rsp+0x20]
000078d941fd86f7  vmovaps xmm3, [rsp+0x30]
000078d941fd86fd  vmovaps xmm4, [rsp+0x40]
000078d941fd8703  vmovaps xmm5, [rsp+0x50]
000078d941fd8709  vmovaps xmm6, [rsp+0x60]
000078d941fd870f  vmovaps xmm7, [rsp+0x70]
000078d941fd8715  vmovaps xmm8, [rsp+0x80]
000078d941fd871e  vmovaps xmm9, [rsp+0x90]
000078d941fd8727  vmovaps xmm10, [rsp+0xA0]
000078d941fd8730  vmovaps xmm11, [rsp+0xB0]
000078d941fd8739  vmovaps xmm12, [rsp+0xC0]
000078d941fd8742  vmovaps xmm13, [rsp+0xD0]
000078d941fd874b  vmovaps xmm14, [rsp+0xE0]
000078d941fd8754  add rsp, 0xF0
000078d941fd875b  pop r11
000078d941fd875d  pop r10
000078d941fd875f  pop r9
000078d941fd8761  pop r8
000078d941fd8763  pop rsi
000078d941fd8764  pop rdi
000078d941fd8765  pop rdx
000078d941fd8766  pop rcx
000078d941fd8767  pop rax
000078d941fd8768  add rsp, 0x08
000078d941fd876c  jmp 0x000078D941FD6030
000078d941fd8771  sub rsp, 0x08
000078d941fd8775  push rax
000078d941fd8776  push rcx
000078d941fd8777  push rdx
000078d941fd8778  push rdi
000078d941fd8779  push rsi
000078d941fd877a  push r8
000078d941fd877c  push r9
000078d941fd877e  push r10
000078d941fd8780  push r11
000078d941fd8782  sub rsp, 0xF0
000078d941fd8789  vmovaps [rsp], xmm0
000078d941fd878e  vmovaps [rsp+0x10], xmm1
000078d941fd8794  vmovaps [rsp+0x20], xmm2
000078d941fd879a  vmovaps [rsp+0x30], xmm4
000078d941fd87a0  vmovaps [rsp+0x40], xmm5
000078d941fd87a6  vmovaps [rsp+0x50], xmm6
000078d941fd87ac  vmovaps [rsp+0x60], xmm7
000078d941fd87b2  vmovaps [rsp+0x70], xmm8
000078d941fd87b8  vmovaps [rsp+0x80], xmm9
000078d941fd87c1  vmovaps [rsp+0x90], xmm10
000078d941fd87ca  vmovaps [rsp+0xA0], xmm11
000078d941fd87d3  vmovaps [rsp+0xB0], xmm12
000078d941fd87dc  vmovaps [rsp+0xC0], xmm13
000078d941fd87e5  vmovaps [rsp+0xD0], xmm14
000078d941fd87ee  vmovaps [rsp+0xE0], xmm15
000078d941fd87f7  sub rsp, 0x30
000078d941fd87fb  movaps [rsp], xmm3
000078d941fd87ff  movaps [rsp+0x10], xmm1
000078d941fd8804  movaps [rsp+0x20], xmm15
000078d941fd880a  lea rdi, [rsp]
000078d941fd880e  mov esi, 0x00
000078d941fd8813  mov rax, 0x59BFBFBAA530
000078d941fd881d  call rax
000078d941fd881f  movaps xmm3, [rsp]
000078d941fd8823  add rsp, 0x30
000078d941fd8827  vmovaps xmm0, [rsp]
000078d941fd882c  vmovaps xmm1, [rsp+0x10]
000078d941fd8832  vmovaps xmm2, [rsp+0x20]
000078d941fd8838  vmovaps xmm4, [rsp+0x30]
000078d941fd883e  vmovaps xmm5, [rsp+0x40]
000078d941fd8844  vmovaps xmm6, [rsp+0x50]
000078d941fd884a  vmovaps xmm7, [rsp+0x60]
000078d941fd8850  vmovaps xmm8, [rsp+0x70]
000078d941fd8856  vmovaps xmm9, [rsp+0x80]
000078d941fd885f  vmovaps xmm10, [rsp+0x90]
000078d941fd8868  vmovaps xmm11, [rsp+0xA0]
000078d941fd8871  vmovaps xmm12, [rsp+0xB0]
000078d941fd887a  vmovaps xmm13, [rsp+0xC0]
000078d941fd8883  vmovaps xmm14, [rsp+0xD0]
000078d941fd888c  vmovaps xmm15, [rsp+0xE0]
000078d941fd8895  add rsp, 0xF0
000078d941fd889c  pop r11
000078d941fd889e  pop r10
000078d941fd88a0  pop r9
000078d941fd88a2  pop r8
000078d941fd88a4  pop rsi
000078d941fd88a5  pop rdi
000078d941fd88a6  pop rdx
000078d941fd88a7  pop rcx
000078d941fd88a8  pop rax
000078d941fd88a9  add rsp, 0x08
000078d941fd88ad  jmp 0x000078D941FD60BF
000078d941fd88b2  call 0x000078D941ED64F0
000078d941fd88b7  jmp 0x000078D941FD60C9
000078d941fd88bc  sub rsp, 0x08
000078d941fd88c0  push rax
000078d941fd88c1  push rcx
000078d941fd88c2  push rdx
000078d941fd88c3  push rdi
000078d941fd88c4  push rsi
000078d941fd88c5  push r8
000078d941fd88c7  push r9
000078d941fd88c9  push r10
000078d941fd88cb  push r11
000078d941fd88cd  sub rsp, 0xF0
000078d941fd88d4  vmovaps [rsp], xmm0
000078d941fd88d9  vmovaps [rsp+0x10], xmm1
000078d941fd88df  vmovaps [rsp+0x20], xmm2
000078d941fd88e5  vmovaps [rsp+0x30], xmm3
000078d941fd88eb  vmovaps [rsp+0x40], xmm4
000078d941fd88f1  vmovaps [rsp+0x50], xmm5
000078d941fd88f7  vmovaps [rsp+0x60], xmm6
000078d941fd88fd  vmovaps [rsp+0x70], xmm7
000078d941fd8903  vmovaps [rsp+0x80], xmm8
000078d941fd890c  vmovaps [rsp+0x90], xmm9
000078d941fd8915  vmovaps [rsp+0xA0], xmm10
000078d941fd891e  vmovaps [rsp+0xB0], xmm11
000078d941fd8927  vmovaps [rsp+0xC0], xmm12
000078d941fd8930  vmovaps [rsp+0xD0], xmm13
000078d941fd8939  vmovaps [rsp+0xE0], xmm14
000078d941fd8942  sub rsp, 0x30
000078d941fd8946  movaps [rsp], xmm15
000078d941fd894b  movaps [rsp+0x10], xmm14
000078d941fd8951  movaps [rsp+0x20], xmm4
000078d941fd8956  lea rdi, [rsp]
000078d941fd895a  mov esi, 0x00
000078d941fd895f  mov rax, 0x59BFBFBAA530
000078d941fd8969  call rax
000078d941fd896b  movaps xmm15, [rsp]
000078d941fd8970  add rsp, 0x30
000078d941fd8974  vmovaps xmm0, [rsp]
000078d941fd8979  vmovaps xmm1, [rsp+0x10]
000078d941fd897f  vmovaps xmm2, [rsp+0x20]
000078d941fd8985  vmovaps xmm3, [rsp+0x30]
000078d941fd898b  vmovaps xmm4, [rsp+0x40]
000078d941fd8991  vmovaps xmm5, [rsp+0x50]
000078d941fd8997  vmovaps xmm6, [rsp+0x60]
000078d941fd899d  vmovaps xmm7, [rsp+0x70]
000078d941fd89a3  vmovaps xmm8, [rsp+0x80]
000078d941fd89ac  vmovaps xmm9, [rsp+0x90]
000078d941fd89b5  vmovaps xmm10, [rsp+0xA0]
000078d941fd89be  vmovaps xmm11, [rsp+0xB0]
000078d941fd89c7  vmovaps xmm12, [rsp+0xC0]
000078d941fd89d0  vmovaps xmm13, [rsp+0xD0]
000078d941fd89d9  vmovaps xmm14, [rsp+0xE0]
000078d941fd89e2  add rsp, 0xF0
000078d941fd89e9  pop r11
000078d941fd89eb  pop r10
000078d941fd89ed  pop r9
000078d941fd89ef  pop r8
000078d941fd89f1  pop rsi
000078d941fd89f2  pop rdi
000078d941fd89f3  pop rdx
000078d941fd89f4  pop rcx
000078d941fd89f5  pop rax
000078d941fd89f6  add rsp, 0x08
000078d941fd89fa  jmp 0x000078D941FD60F7
000078d941fd89ff  sub rsp, 0x08
000078d941fd8a03  push rax
000078d941fd8a04  push rcx
000078d941fd8a05  push rdx
000078d941fd8a06  push rdi
000078d941fd8a07  push rsi
000078d941fd8a08  push r8
000078d941fd8a0a  push r9
000078d941fd8a0c  push r10
000078d941fd8a0e  push r11
000078d941fd8a10  sub rsp, 0xF0
000078d941fd8a17  vmovaps [rsp], xmm0
000078d941fd8a1c  vmovaps [rsp+0x10], xmm1
000078d941fd8a22  vmovaps [rsp+0x20], xmm2
000078d941fd8a28  vmovaps [rsp+0x30], xmm3
000078d941fd8a2e  vmovaps [rsp+0x40], xmm4
000078d941fd8a34  vmovaps [rsp+0x50], xmm5
000078d941fd8a3a  vmovaps [rsp+0x60], xmm6
000078d941fd8a40  vmovaps [rsp+0x70], xmm7
000078d941fd8a46  vmovaps [rsp+0x80], xmm8
000078d941fd8a4f  vmovaps [rsp+0x90], xmm9
000078d941fd8a58  vmovaps [rsp+0xA0], xmm10
000078d941fd8a61  vmovaps [rsp+0xB0], xmm11
000078d941fd8a6a  vmovaps [rsp+0xC0], xmm12
000078d941fd8a73  vmovaps [rsp+0xD0], xmm13
000078d941fd8a7c  vmovaps [rsp+0xE0], xmm15
000078d941fd8a85  sub rsp, 0x30
000078d941fd8a89  movaps [rsp], xmm14
000078d941fd8a8e  movaps [rsp+0x10], xmm2
000078d941fd8a93  movaps [rsp+0x20], xmm1
000078d941fd8a98  lea rdi, [rsp]
000078d941fd8a9c  mov esi, 0x00
000078d941fd8aa1  mov rax, 0x59BFBFBAA530
000078d941fd8aab  call rax
000078d941fd8aad  movaps xmm14, [rsp]
000078d941fd8ab2  add rsp, 0x30
000078d941fd8ab6  vmovaps xmm0, [rsp]
000078d941fd8abb  vmovaps xmm1, [rsp+0x10]
000078d941fd8ac1  vmovaps xmm2, [rsp+0x20]
000078d941fd8ac7  vmovaps xmm3, [rsp+0x30]
000078d941fd8acd  vmovaps xmm4, [rsp+0x40]
000078d941fd8ad3  vmovaps xmm5, [rsp+0x50]
000078d941fd8ad9  vmovaps xmm6, [rsp+0x60]
000078d941fd8adf  vmovaps xmm7, [rsp+0x70]
000078d941fd8ae5  vmovaps xmm8, [rsp+0x80]
000078d941fd8aee  vmovaps xmm9, [rsp+0x90]
000078d941fd8af7  vmovaps xmm10, [rsp+0xA0]
000078d941fd8b00  vmovaps xmm11, [rsp+0xB0]
000078d941fd8b09  vmovaps xmm12, [rsp+0xC0]
000078d941fd8b12  vmovaps xmm13, [rsp+0xD0]
000078d941fd8b1b  vmovaps xmm15, [rsp+0xE0]
000078d941fd8b24  add rsp, 0xF0
000078d941fd8b2b  pop r11
000078d941fd8b2d  pop r10
000078d941fd8b2f  pop r9
000078d941fd8b31  pop r8
000078d941fd8b33  pop rsi
000078d941fd8b34  pop rdi
000078d941fd8b35  pop rdx
000078d941fd8b36  pop rcx
000078d941fd8b37  pop rax
000078d941fd8b38  add rsp, 0x08
000078d941fd8b3c  jmp 0x000078D941FD611D
000078d941fd8b41  sub rsp, 0x08
000078d941fd8b45  push rax
000078d941fd8b46  push rcx
000078d941fd8b47  push rdx
000078d941fd8b48  push rdi
000078d941fd8b49  push rsi
000078d941fd8b4a  push r8
000078d941fd8b4c  push r9
000078d941fd8b4e  push r10
000078d941fd8b50  push r11
000078d941fd8b52  sub rsp, 0xF0
000078d941fd8b59  vmovaps [rsp], xmm0
000078d941fd8b5e  vmovaps [rsp+0x10], xmm2
000078d941fd8b64  vmovaps [rsp+0x20], xmm3
000078d941fd8b6a  vmovaps [rsp+0x30], xmm4
000078d941fd8b70  vmovaps [rsp+0x40], xmm5
000078d941fd8b76  vmovaps [rsp+0x50], xmm6
000078d941fd8b7c  vmovaps [rsp+0x60], xmm7
000078d941fd8b82  vmovaps [rsp+0x70], xmm8
000078d941fd8b88  vmovaps [rsp+0x80], xmm9
000078d941fd8b91  vmovaps [rsp+0x90], xmm10
000078d941fd8b9a  vmovaps [rsp+0xA0], xmm11
000078d941fd8ba3  vmovaps [rsp+0xB0], xmm12
000078d941fd8bac  vmovaps [rsp+0xC0], xmm13
000078d941fd8bb5  vmovaps [rsp+0xD0], xmm14
000078d941fd8bbe  vmovaps [rsp+0xE0], xmm15
000078d941fd8bc7  sub rsp, 0x30
000078d941fd8bcb  movaps [rsp], xmm1
000078d941fd8bcf  movaps [rsp+0x10], xmm4
000078d941fd8bd4  movaps [rsp+0x20], xmm9
000078d941fd8bda  lea rdi, [rsp]
000078d941fd8bde  mov esi, 0x00
000078d941fd8be3  mov rax, 0x59BFBFBAA530
000078d941fd8bed  call rax
000078d941fd8bef  movaps xmm1, [rsp]
000078d941fd8bf3  add rsp, 0x30
000078d941fd8bf7  vmovaps xmm0, [rsp]
000078d941fd8bfc  vmovaps xmm2, [rsp+0x10]
000078d941fd8c02  vmovaps xmm3, [rsp+0x20]
000078d941fd8c08  vmovaps xmm4, [rsp+0x30]
000078d941fd8c0e  vmovaps xmm5, [rsp+0x40]
000078d941fd8c14  vmovaps xmm6, [rsp+0x50]
000078d941fd8c1a  vmovaps xmm7, [rsp+0x60]
000078d941fd8c20  vmovaps xmm8, [rsp+0x70]
000078d941fd8c26  vmovaps xmm9, [rsp+0x80]
000078d941fd8c2f  vmovaps xmm10, [rsp+0x90]
000078d941fd8c38  vmovaps xmm11, [rsp+0xA0]
000078d941fd8c41  vmovaps xmm12, [rsp+0xB0]
000078d941fd8c4a  vmovaps xmm13, [rsp+0xC0]
000078d941fd8c53  vmovaps xmm14, [rsp+0xD0]
000078d941fd8c5c  vmovaps xmm15, [rsp+0xE0]
000078d941fd8c65  add rsp, 0xF0
000078d941fd8c6c  pop r11
000078d941fd8c6e  pop r10
000078d941fd8c70  pop r9
000078d941fd8c72  pop r8
000078d941fd8c74  pop rsi
000078d941fd8c75  pop rdi
000078d941fd8c76  pop rdx
000078d941fd8c77  pop rcx
000078d941fd8c78  pop rax
000078d941fd8c79  add rsp, 0x08
000078d941fd8c7d  jmp 0x000078D941FD613B
000078d941fd8c82  sub rsp, 0x08
000078d941fd8c86  push rax
000078d941fd8c87  push rcx
000078d941fd8c88  push rdx
000078d941fd8c89  push rdi
000078d941fd8c8a  push rsi
000078d941fd8c8b  push r8
000078d941fd8c8d  push r9
000078d941fd8c8f  push r10
000078d941fd8c91  push r11
000078d941fd8c93  sub rsp, 0xF0
000078d941fd8c9a  vmovaps [rsp], xmm0
000078d941fd8c9f  vmovaps [rsp+0x10], xmm1
000078d941fd8ca5  vmovaps [rsp+0x20], xmm2
000078d941fd8cab  vmovaps [rsp+0x30], xmm3
000078d941fd8cb1  vmovaps [rsp+0x40], xmm5
000078d941fd8cb7  vmovaps [rsp+0x50], xmm6
000078d941fd8cbd  vmovaps [rsp+0x60], xmm7
000078d941fd8cc3  vmovaps [rsp+0x70], xmm8
000078d941fd8cc9  vmovaps [rsp+0x80], xmm9
000078d941fd8cd2  vmovaps [rsp+0x90], xmm10
000078d941fd8cdb  vmovaps [rsp+0xA0], xmm11
000078d941fd8ce4  vmovaps [rsp+0xB0], xmm12
000078d941fd8ced  vmovaps [rsp+0xC0], xmm13
000078d941fd8cf6  vmovaps [rsp+0xD0], xmm14
000078d941fd8cff  vmovaps [rsp+0xE0], xmm15
000078d941fd8d08  sub rsp, 0x30
000078d941fd8d0c  movaps [rsp], xmm4
000078d941fd8d10  movaps [rsp+0x10], xmm2
000078d941fd8d15  movaps [rsp+0x20], xmm9
000078d941fd8d1b  lea rdi, [rsp]
000078d941fd8d1f  mov esi, 0x00
000078d941fd8d24  mov rax, 0x59BFBFBAA530
000078d941fd8d2e  call rax
000078d941fd8d30  movaps xmm4, [rsp]
000078d941fd8d34  add rsp, 0x30
000078d941fd8d38  vmovaps xmm0, [rsp]
000078d941fd8d3d  vmovaps xmm1, [rsp+0x10]
000078d941fd8d43  vmovaps xmm2, [rsp+0x20]
000078d941fd8d49  vmovaps xmm3, [rsp+0x30]
000078d941fd8d4f  vmovaps xmm5, [rsp+0x40]
000078d941fd8d55  vmovaps xmm6, [rsp+0x50]
000078d941fd8d5b  vmovaps xmm7, [rsp+0x60]
000078d941fd8d61  vmovaps xmm8, [rsp+0x70]
000078d941fd8d67  vmovaps xmm9, [rsp+0x80]
000078d941fd8d70  vmovaps xmm10, [rsp+0x90]
000078d941fd8d79  vmovaps xmm11, [rsp+0xA0]
000078d941fd8d82  vmovaps xmm12, [rsp+0xB0]
000078d941fd8d8b  vmovaps xmm13, [rsp+0xC0]
000078d941fd8d94  vmovaps xmm14, [rsp+0xD0]
000078d941fd8d9d  vmovaps xmm15, [rsp+0xE0]
000078d941fd8da6  add rsp, 0xF0
000078d941fd8dad  pop r11
000078d941fd8daf  pop r10
000078d941fd8db1  pop r9
000078d941fd8db3  pop r8
000078d941fd8db5  pop rsi
000078d941fd8db6  pop rdi
000078d941fd8db7  pop rdx
000078d941fd8db8  pop rcx
000078d941fd8db9  pop rax
000078d941fd8dba  add rsp, 0x08
000078d941fd8dbe  jmp 0x000078D941FD616B
000078d941fd8dc3  sub rsp, 0x08
000078d941fd8dc7  push rax
000078d941fd8dc8  push rcx
000078d941fd8dc9  push rdx
000078d941fd8dca  push rdi
000078d941fd8dcb  push rsi
000078d941fd8dcc  push r8
000078d941fd8dce  push r9
000078d941fd8dd0  push r10
000078d941fd8dd2  push r11
000078d941fd8dd4  sub rsp, 0xF0
000078d941fd8ddb  vmovaps [rsp], xmm0
000078d941fd8de0  vmovaps [rsp+0x10], xmm1
000078d941fd8de6  vmovaps [rsp+0x20], xmm2
000078d941fd8dec  vmovaps [rsp+0x30], xmm3
000078d941fd8df2  vmovaps [rsp+0x40], xmm4
000078d941fd8df8  vmovaps [rsp+0x50], xmm5
000078d941fd8dfe  vmovaps [rsp+0x60], xmm6
000078d941fd8e04  vmovaps [rsp+0x70], xmm7
000078d941fd8e0a  vmovaps [rsp+0x80], xmm8
000078d941fd8e13  vmovaps [rsp+0x90], xmm10
000078d941fd8e1c  vmovaps [rsp+0xA0], xmm11
000078d941fd8e25  vmovaps [rsp+0xB0], xmm12
000078d941fd8e2e  vmovaps [rsp+0xC0], xmm13
000078d941fd8e37  vmovaps [rsp+0xD0], xmm14
000078d941fd8e40  vmovaps [rsp+0xE0], xmm15
000078d941fd8e49  sub rsp, 0x30
000078d941fd8e4d  movaps [rsp], xmm9
000078d941fd8e52  movaps [rsp+0x10], xmm2
000078d941fd8e57  movaps [rsp+0x20], xmm1
000078d941fd8e5c  lea rdi, [rsp]
000078d941fd8e60  mov esi, 0x00
000078d941fd8e65  mov rax, 0x59BFBFBAA530
000078d941fd8e6f  call rax
000078d941fd8e71  movaps xmm9, [rsp]
000078d941fd8e76  add rsp, 0x30
000078d941fd8e7a  vmovaps xmm0, [rsp]
000078d941fd8e7f  vmovaps xmm1, [rsp+0x10]
000078d941fd8e85  vmovaps xmm2, [rsp+0x20]
000078d941fd8e8b  vmovaps xmm3, [rsp+0x30]
000078d941fd8e91  vmovaps xmm4, [rsp+0x40]
000078d941fd8e97  vmovaps xmm5, [rsp+0x50]
000078d941fd8e9d  vmovaps xmm6, [rsp+0x60]
000078d941fd8ea3  vmovaps xmm7, [rsp+0x70]
000078d941fd8ea9  vmovaps xmm8, [rsp+0x80]
000078d941fd8eb2  vmovaps xmm10, [rsp+0x90]
000078d941fd8ebb  vmovaps xmm11, [rsp+0xA0]
000078d941fd8ec4  vmovaps xmm12, [rsp+0xB0]
000078d941fd8ecd  vmovaps xmm13, [rsp+0xC0]
000078d941fd8ed6  vmovaps xmm14, [rsp+0xD0]
000078d941fd8edf  vmovaps xmm15, [rsp+0xE0]
000078d941fd8ee8  add rsp, 0xF0
000078d941fd8eef  pop r11
000078d941fd8ef1  pop r10
000078d941fd8ef3  pop r9
000078d941fd8ef5  pop r8
000078d941fd8ef7  pop rsi
000078d941fd8ef8  pop rdi
000078d941fd8ef9  pop rdx
000078d941fd8efa  pop rcx
000078d941fd8efb  pop rax
000078d941fd8efc  add rsp, 0x08
000078d941fd8f00  jmp 0x000078D941FD61A1
000078d941fd8f05  sub rsp, 0x08
000078d941fd8f09  push rax
000078d941fd8f0a  push rcx
000078d941fd8f0b  push rdx
000078d941fd8f0c  push rdi
000078d941fd8f0d  push rsi
000078d941fd8f0e  push r8
000078d941fd8f10  push r9
000078d941fd8f12  push r10
000078d941fd8f14  push r11
000078d941fd8f16  sub rsp, 0xF0
000078d941fd8f1d  vmovaps [rsp], xmm0
000078d941fd8f22  vmovaps [rsp+0x10], xmm2
000078d941fd8f28  vmovaps [rsp+0x20], xmm3
000078d941fd8f2e  vmovaps [rsp+0x30], xmm4
000078d941fd8f34  vmovaps [rsp+0x40], xmm5
000078d941fd8f3a  vmovaps [rsp+0x50], xmm6
000078d941fd8f40  vmovaps [rsp+0x60], xmm7
000078d941fd8f46  vmovaps [rsp+0x70], xmm8
000078d941fd8f4c  vmovaps [rsp+0x80], xmm9
000078d941fd8f55  vmovaps [rsp+0x90], xmm10
000078d941fd8f5e  vmovaps [rsp+0xA0], xmm11
000078d941fd8f67  vmovaps [rsp+0xB0], xmm12
000078d941fd8f70  vmovaps [rsp+0xC0], xmm13
000078d941fd8f79  vmovaps [rsp+0xD0], xmm14
000078d941fd8f82  vmovaps [rsp+0xE0], xmm15
000078d941fd8f8b  sub rsp, 0x30
000078d941fd8f8f  movaps [rsp], xmm1
000078d941fd8f93  movaps [rsp+0x10], xmm15
000078d941fd8f99  movaps [rsp+0x20], xmm6
000078d941fd8f9e  lea rdi, [rsp]
000078d941fd8fa2  mov esi, 0x00
000078d941fd8fa7  mov rax, 0x59BFBFBAA530
000078d941fd8fb1  call rax
000078d941fd8fb3  movaps xmm1, [rsp]
000078d941fd8fb7  add rsp, 0x30
000078d941fd8fbb  vmovaps xmm0, [rsp]
000078d941fd8fc0  vmovaps xmm2, [rsp+0x10]
000078d941fd8fc6  vmovaps xmm3, [rsp+0x20]
000078d941fd8fcc  vmovaps xmm4, [rsp+0x30]
000078d941fd8fd2  vmovaps xmm5, [rsp+0x40]
000078d941fd8fd8  vmovaps xmm6, [rsp+0x50]
000078d941fd8fde  vmovaps xmm7, [rsp+0x60]
000078d941fd8fe4  vmovaps xmm8, [rsp+0x70]
000078d941fd8fea  vmovaps xmm9, [rsp+0x80]
000078d941fd8ff3  vmovaps xmm10, [rsp+0x90]
000078d941fd8ffc  vmovaps xmm11, [rsp+0xA0]
000078d941fd9005  vmovaps xmm12, [rsp+0xB0]
000078d941fd900e  vmovaps xmm13, [rsp+0xC0]
000078d941fd9017  vmovaps xmm14, [rsp+0xD0]
000078d941fd9020  vmovaps xmm15, [rsp+0xE0]
000078d941fd9029  add rsp, 0xF0
000078d941fd9030  pop r11
000078d941fd9032  pop r10
000078d941fd9034  pop r9
000078d941fd9036  pop r8
000078d941fd9038  pop rsi
000078d941fd9039  pop rdi
000078d941fd903a  pop rdx
000078d941fd903b  pop rcx
000078d941fd903c  pop rax
000078d941fd903d  add rsp, 0x08
000078d941fd9041  jmp 0x000078D941FD61C2
000078d941fd9046  sub rsp, 0x08
000078d941fd904a  push rax
000078d941fd904b  push rcx
000078d941fd904c  push rdx
000078d941fd904d  push rdi
000078d941fd904e  push rsi
000078d941fd904f  push r8
000078d941fd9051  push r9
000078d941fd9053  push r10
000078d941fd9055  push r11
000078d941fd9057  sub rsp, 0xF0
000078d941fd905e  vmovaps [rsp], xmm0
000078d941fd9063  vmovaps [rsp+0x10], xmm1
000078d941fd9069  vmovaps [rsp+0x20], xmm2
000078d941fd906f  vmovaps [rsp+0x30], xmm3
000078d941fd9075  vmovaps [rsp+0x40], xmm4
000078d941fd907b  vmovaps [rsp+0x50], xmm5
000078d941fd9081  vmovaps [rsp+0x60], xmm6
000078d941fd9087  vmovaps [rsp+0x70], xmm7
000078d941fd908d  vmovaps [rsp+0x80], xmm8
000078d941fd9096  vmovaps [rsp+0x90], xmm9
000078d941fd909f  vmovaps [rsp+0xA0], xmm10
000078d941fd90a8  vmovaps [rsp+0xB0], xmm11
000078d941fd90b1  vmovaps [rsp+0xC0], xmm12
000078d941fd90ba  vmovaps [rsp+0xD0], xmm13
000078d941fd90c3  vmovaps [rsp+0xE0], xmm14
000078d941fd90cc  sub rsp, 0x30
000078d941fd90d0  movaps [rsp], xmm15
000078d941fd90d5  movaps [rsp+0x10], xmm5
000078d941fd90da  movaps [rsp+0x20], xmm3
000078d941fd90df  lea rdi, [rsp]
000078d941fd90e3  mov esi, 0x00
000078d941fd90e8  mov rax, 0x59BFBFBAA530
000078d941fd90f2  call rax
000078d941fd90f4  movaps xmm15, [rsp]
000078d941fd90f9  add rsp, 0x30
000078d941fd90fd  vmovaps xmm0, [rsp]
000078d941fd9102  vmovaps xmm1, [rsp+0x10]
000078d941fd9108  vmovaps xmm2, [rsp+0x20]
000078d941fd910e  vmovaps xmm3, [rsp+0x30]
000078d941fd9114  vmovaps xmm4, [rsp+0x40]
000078d941fd911a  vmovaps xmm5, [rsp+0x50]
000078d941fd9120  vmovaps xmm6, [rsp+0x60]
000078d941fd9126  vmovaps xmm7, [rsp+0x70]
000078d941fd912c  vmovaps xmm8, [rsp+0x80]
000078d941fd9135  vmovaps xmm9, [rsp+0x90]
000078d941fd913e  vmovaps xmm10, [rsp+0xA0]
000078d941fd9147  vmovaps xmm11, [rsp+0xB0]
000078d941fd9150  vmovaps xmm12, [rsp+0xC0]
000078d941fd9159  vmovaps xmm13, [rsp+0xD0]
000078d941fd9162  vmovaps xmm14, [rsp+0xE0]
000078d941fd916b  add rsp, 0xF0
000078d941fd9172  pop r11
000078d941fd9174  pop r10
000078d941fd9176  pop r9
000078d941fd9178  pop r8
000078d941fd917a  pop rsi
000078d941fd917b  pop rdi
000078d941fd917c  pop rdx
000078d941fd917d  pop rcx
000078d941fd917e  pop rax
000078d941fd917f  add rsp, 0x08
000078d941fd9183  jmp 0x000078D941FD61DC
000078d941fd9188  sub rsp, 0x08
000078d941fd918c  push rax
000078d941fd918d  push rcx
000078d941fd918e  push rdx
000078d941fd918f  push rdi
000078d941fd9190  push rsi
000078d941fd9191  push r8
000078d941fd9193  push r9
000078d941fd9195  push r10
000078d941fd9197  push r11
000078d941fd9199  sub rsp, 0xF0
000078d941fd91a0  vmovaps [rsp], xmm0
000078d941fd91a5  vmovaps [rsp+0x10], xmm1
000078d941fd91ab  vmovaps [rsp+0x20], xmm2
000078d941fd91b1  vmovaps [rsp+0x30], xmm3
000078d941fd91b7  vmovaps [rsp+0x40], xmm4
000078d941fd91bd  vmovaps [rsp+0x50], xmm6
000078d941fd91c3  vmovaps [rsp+0x60], xmm7
000078d941fd91c9  vmovaps [rsp+0x70], xmm8
000078d941fd91cf  vmovaps [rsp+0x80], xmm9
000078d941fd91d8  vmovaps [rsp+0x90], xmm10
000078d941fd91e1  vmovaps [rsp+0xA0], xmm11
000078d941fd91ea  vmovaps [rsp+0xB0], xmm12
000078d941fd91f3  vmovaps [rsp+0xC0], xmm13
000078d941fd91fc  vmovaps [rsp+0xD0], xmm14
000078d941fd9205  vmovaps [rsp+0xE0], xmm15
000078d941fd920e  sub rsp, 0x30
000078d941fd9212  movaps [rsp], xmm5
000078d941fd9216  movaps [rsp+0x10], xmm8
000078d941fd921c  movaps [rsp+0x20], xmm6
000078d941fd9221  lea rdi, [rsp]
000078d941fd9225  mov esi, 0x00
000078d941fd922a  mov rax, 0x59BFBFBAA530
000078d941fd9234  call rax
000078d941fd9236  movaps xmm5, [rsp]
000078d941fd923a  add rsp, 0x30
000078d941fd923e  vmovaps xmm0, [rsp]
000078d941fd9243  vmovaps xmm1, [rsp+0x10]
000078d941fd9249  vmovaps xmm2, [rsp+0x20]
000078d941fd924f  vmovaps xmm3, [rsp+0x30]
000078d941fd9255  vmovaps xmm4, [rsp+0x40]
000078d941fd925b  vmovaps xmm6, [rsp+0x50]
000078d941fd9261  vmovaps xmm7, [rsp+0x60]
000078d941fd9267  vmovaps xmm8, [rsp+0x70]
000078d941fd926d  vmovaps xmm9, [rsp+0x80]
000078d941fd9276  vmovaps xmm10, [rsp+0x90]
000078d941fd927f  vmovaps xmm11, [rsp+0xA0]
000078d941fd9288  vmovaps xmm12, [rsp+0xB0]
000078d941fd9291  vmovaps xmm13, [rsp+0xC0]
000078d941fd929a  vmovaps xmm14, [rsp+0xD0]
000078d941fd92a3  vmovaps xmm15, [rsp+0xE0]
000078d941fd92ac  add rsp, 0xF0
000078d941fd92b3  pop r11
000078d941fd92b5  pop r10
000078d941fd92b7  pop r9
000078d941fd92b9  pop r8
000078d941fd92bb  pop rsi
000078d941fd92bc  pop rdi
000078d941fd92bd  pop rdx
000078d941fd92be  pop rcx
000078d941fd92bf  pop rax
000078d941fd92c0  add rsp, 0x08
000078d941fd92c4  jmp 0x000078D941FD6200
000078d941fd92c9  sub rsp, 0x08
000078d941fd92cd  push rax
000078d941fd92ce  push rcx
000078d941fd92cf  push rdx
000078d941fd92d0  push rdi
000078d941fd92d1  push rsi
000078d941fd92d2  push r8
000078d941fd92d4  push r9
000078d941fd92d6  push r10
000078d941fd92d8  push r11
000078d941fd92da  sub rsp, 0xF0
000078d941fd92e1  vmovaps [rsp], xmm0
000078d941fd92e6  vmovaps [rsp+0x10], xmm1
000078d941fd92ec  vmovaps [rsp+0x20], xmm2
000078d941fd92f2  vmovaps [rsp+0x30], xmm3
000078d941fd92f8  vmovaps [rsp+0x40], xmm4
000078d941fd92fe  vmovaps [rsp+0x50], xmm5
000078d941fd9304  vmovaps [rsp+0x60], xmm7
000078d941fd930a  vmovaps [rsp+0x70], xmm8
000078d941fd9310  vmovaps [rsp+0x80], xmm9
000078d941fd9319  vmovaps [rsp+0x90], xmm10
000078d941fd9322  vmovaps [rsp+0xA0], xmm11
000078d941fd932b  vmovaps [rsp+0xB0], xmm12
000078d941fd9334  vmovaps [rsp+0xC0], xmm13
000078d941fd933d  vmovaps [rsp+0xD0], xmm14
000078d941fd9346  vmovaps [rsp+0xE0], xmm15
000078d941fd934f  sub rsp, 0x30
000078d941fd9353  movaps [rsp], xmm6
000078d941fd9357  movaps [rsp+0x10], xmm10
000078d941fd935d  movaps [rsp+0x20], xmm8
000078d941fd9363  lea rdi, [rsp]
000078d941fd9367  mov esi, 0x00
000078d941fd936c  mov rax, 0x59BFBFBAA530
000078d941fd9376  call rax
000078d941fd9378  movaps xmm6, [rsp]
000078d941fd937c  add rsp, 0x30
000078d941fd9380  vmovaps xmm0, [rsp]
000078d941fd9385  vmovaps xmm1, [rsp+0x10]
000078d941fd938b  vmovaps xmm2, [rsp+0x20]
000078d941fd9391  vmovaps xmm3, [rsp+0x30]
000078d941fd9397  vmovaps xmm4, [rsp+0x40]
000078d941fd939d  vmovaps xmm5, [rsp+0x50]
000078d941fd93a3  vmovaps xmm7, [rsp+0x60]
000078d941fd93a9  vmovaps xmm8, [rsp+0x70]
000078d941fd93af  vmovaps xmm9, [rsp+0x80]
000078d941fd93b8  vmovaps xmm10, [rsp+0x90]
000078d941fd93c1  vmovaps xmm11, [rsp+0xA0]
000078d941fd93ca  vmovaps xmm12, [rsp+0xB0]
000078d941fd93d3  vmovaps xmm13, [rsp+0xC0]
000078d941fd93dc  vmovaps xmm14, [rsp+0xD0]
000078d941fd93e5  vmovaps xmm15, [rsp+0xE0]
000078d941fd93ee  add rsp, 0xF0
000078d941fd93f5  pop r11
000078d941fd93f7  pop r10
000078d941fd93f9  pop r9
000078d941fd93fb  pop r8
000078d941fd93fd  pop rsi
000078d941fd93fe  pop rdi
000078d941fd93ff  pop rdx
000078d941fd9400  pop rcx
000078d941fd9401  pop rax
000078d941fd9402  add rsp, 0x08
000078d941fd9406  jmp 0x000078D941FD6225
000078d941fd940b  sub rsp, 0x08
000078d941fd940f  push rax
000078d941fd9410  push rcx
000078d941fd9411  push rdx
000078d941fd9412  push rdi
000078d941fd9413  push rsi
000078d941fd9414  push r8
000078d941fd9416  push r9
000078d941fd9418  push r10
000078d941fd941a  push r11
000078d941fd941c  sub rsp, 0xF0
000078d941fd9423  vmovaps [rsp], xmm0
000078d941fd9428  vmovaps [rsp+0x10], xmm1
000078d941fd942e  vmovaps [rsp+0x20], xmm2
000078d941fd9434  vmovaps [rsp+0x30], xmm3
000078d941fd943a  vmovaps [rsp+0x40], xmm4
000078d941fd9440  vmovaps [rsp+0x50], xmm5
000078d941fd9446  vmovaps [rsp+0x60], xmm6
000078d941fd944c  vmovaps [rsp+0x70], xmm7
000078d941fd9452  vmovaps [rsp+0x80], xmm8
000078d941fd945b  vmovaps [rsp+0x90], xmm9
000078d941fd9464  vmovaps [rsp+0xA0], xmm11
000078d941fd946d  vmovaps [rsp+0xB0], xmm12
000078d941fd9476  vmovaps [rsp+0xC0], xmm13
000078d941fd947f  vmovaps [rsp+0xD0], xmm14
000078d941fd9488  vmovaps [rsp+0xE0], xmm15
000078d941fd9491  sub rsp, 0x30
000078d941fd9495  movaps [rsp], xmm10
000078d941fd949a  movaps [rsp+0x10], xmm8
000078d941fd94a0  movaps [rsp+0x20], xmm14
000078d941fd94a6  lea rdi, [rsp]
000078d941fd94aa  mov esi, 0x00
000078d941fd94af  mov rax, 0x59BFBFBAA530
000078d941fd94b9  call rax
000078d941fd94bb  movaps xmm10, [rsp]
000078d941fd94c0  add rsp, 0x30
000078d941fd94c4  vmovaps xmm0, [rsp]
000078d941fd94c9  vmovaps xmm1, [rsp+0x10]
000078d941fd94cf  vmovaps xmm2, [rsp+0x20]
000078d941fd94d5  vmovaps xmm3, [rsp+0x30]
000078d941fd94db  vmovaps xmm4, [rsp+0x40]
000078d941fd94e1  vmovaps xmm5, [rsp+0x50]
000078d941fd94e7  vmovaps xmm6, [rsp+0x60]
000078d941fd94ed  vmovaps xmm7, [rsp+0x70]
000078d941fd94f3  vmovaps xmm8, [rsp+0x80]
000078d941fd94fc  vmovaps xmm9, [rsp+0x90]
000078d941fd9505  vmovaps xmm11, [rsp+0xA0]
000078d941fd950e  vmovaps xmm12, [rsp+0xB0]
000078d941fd9517  vmovaps xmm13, [rsp+0xC0]
000078d941fd9520  vmovaps xmm14, [rsp+0xD0]
000078d941fd9529  vmovaps xmm15, [rsp+0xE0]
000078d941fd9532  add rsp, 0xF0
000078d941fd9539  pop r11
000078d941fd953b  pop r10
000078d941fd953d  pop r9
000078d941fd953f  pop r8
000078d941fd9541  pop rsi
000078d941fd9542  pop rdi
000078d941fd9543  pop rdx
000078d941fd9544  pop rcx
000078d941fd9545  pop rax
000078d941fd9546  add rsp, 0x08
000078d941fd954a  jmp 0x000078D941FD6245
000078d941fd954f  sub rsp, 0x08
000078d941fd9553  push rax
000078d941fd9554  push rcx
000078d941fd9555  push rdx
000078d941fd9556  push rdi
000078d941fd9557  push rsi
000078d941fd9558  push r8
000078d941fd955a  push r9
000078d941fd955c  push r10
000078d941fd955e  push r11
000078d941fd9560  sub rsp, 0xF0
000078d941fd9567  vmovaps [rsp], xmm0
000078d941fd956c  vmovaps [rsp+0x10], xmm1
000078d941fd9572  vmovaps [rsp+0x20], xmm2
000078d941fd9578  vmovaps [rsp+0x30], xmm3
000078d941fd957e  vmovaps [rsp+0x40], xmm4
000078d941fd9584  vmovaps [rsp+0x50], xmm5
000078d941fd958a  vmovaps [rsp+0x60], xmm6
000078d941fd9590  vmovaps [rsp+0x70], xmm7
000078d941fd9596  vmovaps [rsp+0x80], xmm8
000078d941fd959f  vmovaps [rsp+0x90], xmm9
000078d941fd95a8  vmovaps [rsp+0xA0], xmm10
000078d941fd95b1  vmovaps [rsp+0xB0], xmm11
000078d941fd95ba  vmovaps [rsp+0xC0], xmm12
000078d941fd95c3  vmovaps [rsp+0xD0], xmm13
000078d941fd95cc  vmovaps [rsp+0xE0], xmm15
000078d941fd95d5  sub rsp, 0x30
000078d941fd95d9  movaps [rsp], xmm14
000078d941fd95de  movaps [rsp+0x10], xmm8
000078d941fd95e4  movaps [rsp+0x20], xmm4
000078d941fd95e9  lea rdi, [rsp]
000078d941fd95ed  mov esi, 0x00
000078d941fd95f2  mov rax, 0x59BFBFBAA530
000078d941fd95fc  call rax
000078d941fd95fe  movaps xmm14, [rsp]
000078d941fd9603  add rsp, 0x30
000078d941fd9607  vmovaps xmm0, [rsp]
000078d941fd960c  vmovaps xmm1, [rsp+0x10]
000078d941fd9612  vmovaps xmm2, [rsp+0x20]
000078d941fd9618  vmovaps xmm3, [rsp+0x30]
000078d941fd961e  vmovaps xmm4, [rsp+0x40]
000078d941fd9624  vmovaps xmm5, [rsp+0x50]
000078d941fd962a  vmovaps xmm6, [rsp+0x60]
000078d941fd9630  vmovaps xmm7, [rsp+0x70]
000078d941fd9636  vmovaps xmm8, [rsp+0x80]
000078d941fd963f  vmovaps xmm9, [rsp+0x90]
000078d941fd9648  vmovaps xmm10, [rsp+0xA0]
000078d941fd9651  vmovaps xmm11, [rsp+0xB0]
000078d941fd965a  vmovaps xmm12, [rsp+0xC0]
000078d941fd9663  vmovaps xmm13, [rsp+0xD0]
000078d941fd966c  vmovaps xmm15, [rsp+0xE0]
000078d941fd9675  add rsp, 0xF0
000078d941fd967c  pop r11
000078d941fd967e  pop r10
000078d941fd9680  pop r9
000078d941fd9682  pop r8
000078d941fd9684  pop rsi
000078d941fd9685  pop rdi
000078d941fd9686  pop rdx
000078d941fd9687  pop rcx
000078d941fd9688  pop rax
000078d941fd9689  add rsp, 0x08
000078d941fd968d  jmp 0x000078D941FD6265
000078d941fd9692  sub rsp, 0x08
000078d941fd9696  push rax
000078d941fd9697  push rcx
000078d941fd9698  push rdx
000078d941fd9699  push rdi
000078d941fd969a  push rsi
000078d941fd969b  push r8
000078d941fd969d  push r9
000078d941fd969f  push r10
000078d941fd96a1  push r11
000078d941fd96a3  sub rsp, 0xF0
000078d941fd96aa  vmovaps [rsp], xmm0
000078d941fd96af  vmovaps [rsp+0x10], xmm1
000078d941fd96b5  vmovaps [rsp+0x20], xmm2
000078d941fd96bb  vmovaps [rsp+0x30], xmm3
000078d941fd96c1  vmovaps [rsp+0x40], xmm5
000078d941fd96c7  vmovaps [rsp+0x50], xmm6
000078d941fd96cd  vmovaps [rsp+0x60], xmm7
000078d941fd96d3  vmovaps [rsp+0x70], xmm8
000078d941fd96d9  vmovaps [rsp+0x80], xmm9
000078d941fd96e2  vmovaps [rsp+0x90], xmm10
000078d941fd96eb  vmovaps [rsp+0xA0], xmm11
000078d941fd96f4  vmovaps [rsp+0xB0], xmm12
000078d941fd96fd  vmovaps [rsp+0xC0], xmm13
000078d941fd9706  vmovaps [rsp+0xD0], xmm14
000078d941fd970f  vmovaps [rsp+0xE0], xmm15
000078d941fd9718  sub rsp, 0x30
000078d941fd971c  movaps [rsp], xmm4
000078d941fd9720  movaps [rsp+0x10], xmm13
000078d941fd9726  movaps [rsp+0x20], xmm8
000078d941fd972c  lea rdi, [rsp]
000078d941fd9730  mov esi, 0x00
000078d941fd9735  mov rax, 0x59BFBFBAA530
000078d941fd973f  call rax
000078d941fd9741  movaps xmm4, [rsp]
000078d941fd9745  add rsp, 0x30
000078d941fd9749  vmovaps xmm0, [rsp]
000078d941fd974e  vmovaps xmm1, [rsp+0x10]
000078d941fd9754  vmovaps xmm2, [rsp+0x20]
000078d941fd975a  vmovaps xmm3, [rsp+0x30]
000078d941fd9760  vmovaps xmm5, [rsp+0x40]
000078d941fd9766  vmovaps xmm6, [rsp+0x50]
000078d941fd976c  vmovaps xmm7, [rsp+0x60]
000078d941fd9772  vmovaps xmm8, [rsp+0x70]
000078d941fd9778  vmovaps xmm9, [rsp+0x80]
000078d941fd9781  vmovaps xmm10, [rsp+0x90]
000078d941fd978a  vmovaps xmm11, [rsp+0xA0]
000078d941fd9793  vmovaps xmm12, [rsp+0xB0]
000078d941fd979c  vmovaps xmm13, [rsp+0xC0]
000078d941fd97a5  vmovaps xmm14, [rsp+0xD0]
000078d941fd97ae  vmovaps xmm15, [rsp+0xE0]
000078d941fd97b7  add rsp, 0xF0
000078d941fd97be  pop r11
000078d941fd97c0  pop r10
000078d941fd97c2  pop r9
000078d941fd97c4  pop r8
000078d941fd97c6  pop rsi
000078d941fd97c7  pop rdi
000078d941fd97c8  pop rdx
000078d941fd97c9  pop rcx
000078d941fd97ca  pop rax
000078d941fd97cb  add rsp, 0x08
000078d941fd97cf  jmp 0x000078D941FD628A
000078d941fd97d4  sub rsp, 0x08
000078d941fd97d8  push rax
000078d941fd97d9  push rcx
000078d941fd97da  push rdx
000078d941fd97db  push rdi
000078d941fd97dc  push rsi
000078d941fd97dd  push r8
000078d941fd97df  push r9
000078d941fd97e1  push r10
000078d941fd97e3  push r11
000078d941fd97e5  sub rsp, 0xF0
000078d941fd97ec  vmovaps [rsp], xmm0
000078d941fd97f1  vmovaps [rsp+0x10], xmm1
000078d941fd97f7  vmovaps [rsp+0x20], xmm2
000078d941fd97fd  vmovaps [rsp+0x30], xmm3
000078d941fd9803  vmovaps [rsp+0x40], xmm4
000078d941fd9809  vmovaps [rsp+0x50], xmm5
000078d941fd980f  vmovaps [rsp+0x60], xmm6
000078d941fd9815  vmovaps [rsp+0x70], xmm7
000078d941fd981b  vmovaps [rsp+0x80], xmm8
000078d941fd9824  vmovaps [rsp+0x90], xmm9
000078d941fd982d  vmovaps [rsp+0xA0], xmm10
000078d941fd9836  vmovaps [rsp+0xB0], xmm11
000078d941fd983f  vmovaps [rsp+0xC0], xmm12
000078d941fd9848  vmovaps [rsp+0xD0], xmm14
000078d941fd9851  vmovaps [rsp+0xE0], xmm15
000078d941fd985a  sub rsp, 0x30
000078d941fd985e  movaps [rsp], xmm13
000078d941fd9863  movaps [rsp+0x10], xmm15
000078d941fd9869  movaps [rsp+0x20], xmm9
000078d941fd986f  lea rdi, [rsp]
000078d941fd9873  mov esi, 0x00
000078d941fd9878  mov rax, 0x59BFBFBAA530
000078d941fd9882  call rax
000078d941fd9884  movaps xmm13, [rsp]
000078d941fd9889  add rsp, 0x30
000078d941fd988d  vmovaps xmm0, [rsp]
000078d941fd9892  vmovaps xmm1, [rsp+0x10]
000078d941fd9898  vmovaps xmm2, [rsp+0x20]
000078d941fd989e  vmovaps xmm3, [rsp+0x30]
000078d941fd98a4  vmovaps xmm4, [rsp+0x40]
000078d941fd98aa  vmovaps xmm5, [rsp+0x50]
000078d941fd98b0  vmovaps xmm6, [rsp+0x60]
000078d941fd98b6  vmovaps xmm7, [rsp+0x70]
000078d941fd98bc  vmovaps xmm8, [rsp+0x80]
000078d941fd98c5  vmovaps xmm9, [rsp+0x90]
000078d941fd98ce  vmovaps xmm10, [rsp+0xA0]
000078d941fd98d7  vmovaps xmm11, [rsp+0xB0]
000078d941fd98e0  vmovaps xmm12, [rsp+0xC0]
000078d941fd98e9  vmovaps xmm14, [rsp+0xD0]
000078d941fd98f2  vmovaps xmm15, [rsp+0xE0]
000078d941fd98fb  add rsp, 0xF0
000078d941fd9902  pop r11
000078d941fd9904  pop r10
000078d941fd9906  pop r9
000078d941fd9908  pop r8
000078d941fd990a  pop rsi
000078d941fd990b  pop rdi
000078d941fd990c  pop rdx
000078d941fd990d  pop rcx
000078d941fd990e  pop rax
000078d941fd990f  add rsp, 0x08
000078d941fd9913  jmp 0x000078D941FD62A5
000078d941fd9918  sub rsp, 0x08
000078d941fd991c  push rax
000078d941fd991d  push rcx
000078d941fd991e  push rdx
000078d941fd991f  push rdi
000078d941fd9920  push rsi
000078d941fd9921  push r8
000078d941fd9923  push r9
000078d941fd9925  push r10
000078d941fd9927  push r11
000078d941fd9929  sub rsp, 0xF0
000078d941fd9930  vmovaps [rsp], xmm0
000078d941fd9935  vmovaps [rsp+0x10], xmm1
000078d941fd993b  vmovaps [rsp+0x20], xmm2
000078d941fd9941  vmovaps [rsp+0x30], xmm3
000078d941fd9947  vmovaps [rsp+0x40], xmm4
000078d941fd994d  vmovaps [rsp+0x50], xmm5
000078d941fd9953  vmovaps [rsp+0x60], xmm6
000078d941fd9959  vmovaps [rsp+0x70], xmm7
000078d941fd995f  vmovaps [rsp+0x80], xmm8
000078d941fd9968  vmovaps [rsp+0x90], xmm9
000078d941fd9971  vmovaps [rsp+0xA0], xmm10
000078d941fd997a  vmovaps [rsp+0xB0], xmm11
000078d941fd9983  vmovaps [rsp+0xC0], xmm12
000078d941fd998c  vmovaps [rsp+0xD0], xmm13
000078d941fd9995  vmovaps [rsp+0xE0], xmm14
000078d941fd999e  sub rsp, 0x30
000078d941fd99a2  movaps [rsp], xmm15
000078d941fd99a7  movaps [rsp+0x10], xmm1
000078d941fd99ac  movaps [rsp+0x20], xmm5
000078d941fd99b1  lea rdi, [rsp]
000078d941fd99b5  mov esi, 0x00
000078d941fd99ba  mov rax, 0x59BFBFBAA530
000078d941fd99c4  call rax
000078d941fd99c6  movaps xmm15, [rsp]
000078d941fd99cb  add rsp, 0x30
000078d941fd99cf  vmovaps xmm0, [rsp]
000078d941fd99d4  vmovaps xmm1, [rsp+0x10]
000078d941fd99da  vmovaps xmm2, [rsp+0x20]
000078d941fd99e0  vmovaps xmm3, [rsp+0x30]
000078d941fd99e6  vmovaps xmm4, [rsp+0x40]
000078d941fd99ec  vmovaps xmm5, [rsp+0x50]
000078d941fd99f2  vmovaps xmm6, [rsp+0x60]
000078d941fd99f8  vmovaps xmm7, [rsp+0x70]
000078d941fd99fe  vmovaps xmm8, [rsp+0x80]
000078d941fd9a07  vmovaps xmm9, [rsp+0x90]
000078d941fd9a10  vmovaps xmm10, [rsp+0xA0]
000078d941fd9a19  vmovaps xmm11, [rsp+0xB0]
000078d941fd9a22  vmovaps xmm12, [rsp+0xC0]
000078d941fd9a2b  vmovaps xmm13, [rsp+0xD0]
000078d941fd9a34  vmovaps xmm14, [rsp+0xE0]
000078d941fd9a3d  add rsp, 0xF0
000078d941fd9a44  pop r11
000078d941fd9a46  pop r10
000078d941fd9a48  pop r9
000078d941fd9a4a  pop r8
000078d941fd9a4c  pop rsi
000078d941fd9a4d  pop rdi
000078d941fd9a4e  pop rdx
000078d941fd9a4f  pop rcx
000078d941fd9a50  pop rax
000078d941fd9a51  add rsp, 0x08
000078d941fd9a55  jmp 0x000078D941FD62C0
000078d941fd9a5a  call 0x000078D941ED64F0
000078d941fd9a5f  jmp 0x000078D941FD631B
000078d941fd9a64  sub rsp, 0x08
000078d941fd9a68  push rax
000078d941fd9a69  push rcx
000078d941fd9a6a  push rdx
000078d941fd9a6b  push rdi
000078d941fd9a6c  push rsi
000078d941fd9a6d  push r8
000078d941fd9a6f  push r9
000078d941fd9a71  push r10
000078d941fd9a73  push r11
000078d941fd9a75  sub rsp, 0xF0
000078d941fd9a7c  vmovaps [rsp], xmm0
000078d941fd9a81  vmovaps [rsp+0x10], xmm1
000078d941fd9a87  vmovaps [rsp+0x20], xmm2
000078d941fd9a8d  vmovaps [rsp+0x30], xmm3
000078d941fd9a93  vmovaps [rsp+0x40], xmm4
000078d941fd9a99  vmovaps [rsp+0x50], xmm5
000078d941fd9a9f  vmovaps [rsp+0x60], xmm6
000078d941fd9aa5  vmovaps [rsp+0x70], xmm7
000078d941fd9aab  vmovaps [rsp+0x80], xmm8
000078d941fd9ab4  vmovaps [rsp+0x90], xmm10
000078d941fd9abd  vmovaps [rsp+0xA0], xmm11
000078d941fd9ac6  vmovaps [rsp+0xB0], xmm12
000078d941fd9acf  vmovaps [rsp+0xC0], xmm13
000078d941fd9ad8  vmovaps [rsp+0xD0], xmm14
000078d941fd9ae1  vmovaps [rsp+0xE0], xmm15
000078d941fd9aea  sub rsp, 0x30
000078d941fd9aee  movaps [rsp], xmm9
000078d941fd9af3  movaps [rsp+0x10], xmm8
000078d941fd9af9  movaps [rsp+0x20], xmm11
000078d941fd9aff  lea rdi, [rsp]
000078d941fd9b03  mov esi, 0x00
000078d941fd9b08  mov rax, 0x59BFBFBAA530
000078d941fd9b12  call rax
000078d941fd9b14  movaps xmm9, [rsp]
000078d941fd9b19  add rsp, 0x30
000078d941fd9b1d  vmovaps xmm0, [rsp]
000078d941fd9b22  vmovaps xmm1, [rsp+0x10]
000078d941fd9b28  vmovaps xmm2, [rsp+0x20]
000078d941fd9b2e  vmovaps xmm3, [rsp+0x30]
000078d941fd9b34  vmovaps xmm4, [rsp+0x40]
000078d941fd9b3a  vmovaps xmm5, [rsp+0x50]
000078d941fd9b40  vmovaps xmm6, [rsp+0x60]
000078d941fd9b46  vmovaps xmm7, [rsp+0x70]
000078d941fd9b4c  vmovaps xmm8, [rsp+0x80]
000078d941fd9b55  vmovaps xmm10, [rsp+0x90]
000078d941fd9b5e  vmovaps xmm11, [rsp+0xA0]
000078d941fd9b67  vmovaps xmm12, [rsp+0xB0]
000078d941fd9b70  vmovaps xmm13, [rsp+0xC0]
000078d941fd9b79  vmovaps xmm14, [rsp+0xD0]
000078d941fd9b82  vmovaps xmm15, [rsp+0xE0]
000078d941fd9b8b  add rsp, 0xF0
000078d941fd9b92  pop r11
000078d941fd9b94  pop r10
000078d941fd9b96  pop r9
000078d941fd9b98  pop r8
000078d941fd9b9a  pop rsi
000078d941fd9b9b  pop rdi
000078d941fd9b9c  pop rdx
000078d941fd9b9d  pop rcx
000078d941fd9b9e  pop rax
000078d941fd9b9f  add rsp, 0x08
000078d941fd9ba3  jmp 0x000078D941FD6352
000078d941fd9ba8  sub rsp, 0x08
000078d941fd9bac  push rax
000078d941fd9bad  push rcx
000078d941fd9bae  push rdx
000078d941fd9baf  push rdi
000078d941fd9bb0  push rsi
000078d941fd9bb1  push r8
000078d941fd9bb3  push r9
000078d941fd9bb5  push r10
000078d941fd9bb7  push r11
000078d941fd9bb9  sub rsp, 0xF0
000078d941fd9bc0  vmovaps [rsp], xmm0
000078d941fd9bc5  vmovaps [rsp+0x10], xmm1
000078d941fd9bcb  vmovaps [rsp+0x20], xmm2
000078d941fd9bd1  vmovaps [rsp+0x30], xmm3
000078d941fd9bd7  vmovaps [rsp+0x40], xmm4
000078d941fd9bdd  vmovaps [rsp+0x50], xmm5
000078d941fd9be3  vmovaps [rsp+0x60], xmm6
000078d941fd9be9  vmovaps [rsp+0x70], xmm7
000078d941fd9bef  vmovaps [rsp+0x80], xmm8
000078d941fd9bf8  vmovaps [rsp+0x90], xmm9
000078d941fd9c01  vmovaps [rsp+0xA0], xmm10
000078d941fd9c0a  vmovaps [rsp+0xB0], xmm12
000078d941fd9c13  vmovaps [rsp+0xC0], xmm13
000078d941fd9c1c  vmovaps [rsp+0xD0], xmm14
000078d941fd9c25  vmovaps [rsp+0xE0], xmm15
000078d941fd9c2e  sub rsp, 0x30
000078d941fd9c32  movaps [rsp], xmm11
000078d941fd9c37  movaps [rsp+0x10], xmm10
000078d941fd9c3d  movaps [rsp+0x20], xmm6
000078d941fd9c42  lea rdi, [rsp]
000078d941fd9c46  mov esi, 0x00
000078d941fd9c4b  mov rax, 0x59BFBFBAA530
000078d941fd9c55  call rax
000078d941fd9c57  movaps xmm11, [rsp]
000078d941fd9c5c  add rsp, 0x30
000078d941fd9c60  vmovaps xmm0, [rsp]
000078d941fd9c65  vmovaps xmm1, [rsp+0x10]
000078d941fd9c6b  vmovaps xmm2, [rsp+0x20]
000078d941fd9c71  vmovaps xmm3, [rsp+0x30]
000078d941fd9c77  vmovaps xmm4, [rsp+0x40]
000078d941fd9c7d  vmovaps xmm5, [rsp+0x50]
000078d941fd9c83  vmovaps xmm6, [rsp+0x60]
000078d941fd9c89  vmovaps xmm7, [rsp+0x70]
000078d941fd9c8f  vmovaps xmm8, [rsp+0x80]
000078d941fd9c98  vmovaps xmm9, [rsp+0x90]
000078d941fd9ca1  vmovaps xmm10, [rsp+0xA0]
000078d941fd9caa  vmovaps xmm12, [rsp+0xB0]
000078d941fd9cb3  vmovaps xmm13, [rsp+0xC0]
000078d941fd9cbc  vmovaps xmm14, [rsp+0xD0]
000078d941fd9cc5  vmovaps xmm15, [rsp+0xE0]
000078d941fd9cce  add rsp, 0xF0
000078d941fd9cd5  pop r11
000078d941fd9cd7  pop r10
000078d941fd9cd9  pop r9
000078d941fd9cdb  pop r8
000078d941fd9cdd  pop rsi
000078d941fd9cde  pop rdi
000078d941fd9cdf  pop rdx
000078d941fd9ce0  pop rcx
000078d941fd9ce1  pop rax
000078d941fd9ce2  add rsp, 0x08
000078d941fd9ce6  jmp 0x000078D941FD636D
000078d941fd9ceb  sub rsp, 0x08
000078d941fd9cef  push rax
000078d941fd9cf0  push rcx
000078d941fd9cf1  push rdx
000078d941fd9cf2  push rdi
000078d941fd9cf3  push rsi
000078d941fd9cf4  push r8
000078d941fd9cf6  push r9
000078d941fd9cf8  push r10
000078d941fd9cfa  push r11
000078d941fd9cfc  sub rsp, 0xF0
000078d941fd9d03  vmovaps [rsp], xmm0
000078d941fd9d08  vmovaps [rsp+0x10], xmm1
000078d941fd9d0e  vmovaps [rsp+0x20], xmm2
000078d941fd9d14  vmovaps [rsp+0x30], xmm3
000078d941fd9d1a  vmovaps [rsp+0x40], xmm4
000078d941fd9d20  vmovaps [rsp+0x50], xmm5
000078d941fd9d26  vmovaps [rsp+0x60], xmm6
000078d941fd9d2c  vmovaps [rsp+0x70], xmm7
000078d941fd9d32  vmovaps [rsp+0x80], xmm8
000078d941fd9d3b  vmovaps [rsp+0x90], xmm9
000078d941fd9d44  vmovaps [rsp+0xA0], xmm11
000078d941fd9d4d  vmovaps [rsp+0xB0], xmm12
000078d941fd9d56  vmovaps [rsp+0xC0], xmm13
000078d941fd9d5f  vmovaps [rsp+0xD0], xmm14
000078d941fd9d68  vmovaps [rsp+0xE0], xmm15
000078d941fd9d71  sub rsp, 0x30
000078d941fd9d75  movaps [rsp], xmm10
000078d941fd9d7a  movaps [rsp+0x10], xmm14
000078d941fd9d80  movaps [rsp+0x20], xmm4
000078d941fd9d85  lea rdi, [rsp]
000078d941fd9d89  mov esi, 0x00
000078d941fd9d8e  mov rax, 0x59BFBFBAA530
000078d941fd9d98  call rax
000078d941fd9d9a  movaps xmm10, [rsp]
000078d941fd9d9f  add rsp, 0x30
000078d941fd9da3  vmovaps xmm0, [rsp]
000078d941fd9da8  vmovaps xmm1, [rsp+0x10]
000078d941fd9dae  vmovaps xmm2, [rsp+0x20]
000078d941fd9db4  vmovaps xmm3, [rsp+0x30]
000078d941fd9dba  vmovaps xmm4, [rsp+0x40]
000078d941fd9dc0  vmovaps xmm5, [rsp+0x50]
000078d941fd9dc6  vmovaps xmm6, [rsp+0x60]
000078d941fd9dcc  vmovaps xmm7, [rsp+0x70]
000078d941fd9dd2  vmovaps xmm8, [rsp+0x80]
000078d941fd9ddb  vmovaps xmm9, [rsp+0x90]
000078d941fd9de4  vmovaps xmm11, [rsp+0xA0]
000078d941fd9ded  vmovaps xmm12, [rsp+0xB0]
000078d941fd9df6  vmovaps xmm13, [rsp+0xC0]
000078d941fd9dff  vmovaps xmm14, [rsp+0xD0]
000078d941fd9e08  vmovaps xmm15, [rsp+0xE0]
000078d941fd9e11  add rsp, 0xF0
000078d941fd9e18  pop r11
000078d941fd9e1a  pop r10
000078d941fd9e1c  pop r9
000078d941fd9e1e  pop r8
000078d941fd9e20  pop rsi
000078d941fd9e21  pop rdi
000078d941fd9e22  pop rdx
000078d941fd9e23  pop rcx
000078d941fd9e24  pop rax
000078d941fd9e25  add rsp, 0x08
000078d941fd9e29  jmp 0x000078D941FD6388
000078d941fd9e2e  sub rsp, 0x08
000078d941fd9e32  push rax
000078d941fd9e33  push rcx
000078d941fd9e34  push rdx
000078d941fd9e35  push rdi
000078d941fd9e36  push rsi
000078d941fd9e37  push r8
000078d941fd9e39  push r9
000078d941fd9e3b  push r10
000078d941fd9e3d  push r11
000078d941fd9e3f  sub rsp, 0xF0
000078d941fd9e46  vmovaps [rsp], xmm0
000078d941fd9e4b  vmovaps [rsp+0x10], xmm1
000078d941fd9e51  vmovaps [rsp+0x20], xmm2
000078d941fd9e57  vmovaps [rsp+0x30], xmm3
000078d941fd9e5d  vmovaps [rsp+0x40], xmm4
000078d941fd9e63  vmovaps [rsp+0x50], xmm5
000078d941fd9e69  vmovaps [rsp+0x60], xmm6
000078d941fd9e6f  vmovaps [rsp+0x70], xmm7
000078d941fd9e75  vmovaps [rsp+0x80], xmm9
000078d941fd9e7e  vmovaps [rsp+0x90], xmm10
000078d941fd9e87  vmovaps [rsp+0xA0], xmm11
000078d941fd9e90  vmovaps [rsp+0xB0], xmm12
000078d941fd9e99  vmovaps [rsp+0xC0], xmm13
000078d941fd9ea2  vmovaps [rsp+0xD0], xmm14
000078d941fd9eab  vmovaps [rsp+0xE0], xmm15
000078d941fd9eb4  sub rsp, 0x30
000078d941fd9eb8  movaps [rsp], xmm8
000078d941fd9ebd  movaps [rsp+0x10], xmm1
000078d941fd9ec2  movaps [rsp+0x20], xmm14
000078d941fd9ec8  lea rdi, [rsp]
000078d941fd9ecc  mov esi, 0x00
000078d941fd9ed1  mov rax, 0x59BFBFBAA530
000078d941fd9edb  call rax
000078d941fd9edd  movaps xmm8, [rsp]
000078d941fd9ee2  add rsp, 0x30
000078d941fd9ee6  vmovaps xmm0, [rsp]
000078d941fd9eeb  vmovaps xmm1, [rsp+0x10]
000078d941fd9ef1  vmovaps xmm2, [rsp+0x20]
000078d941fd9ef7  vmovaps xmm3, [rsp+0x30]
000078d941fd9efd  vmovaps xmm4, [rsp+0x40]
000078d941fd9f03  vmovaps xmm5, [rsp+0x50]
000078d941fd9f09  vmovaps xmm6, [rsp+0x60]
000078d941fd9f0f  vmovaps xmm7, [rsp+0x70]
000078d941fd9f15  vmovaps xmm9, [rsp+0x80]
000078d941fd9f1e  vmovaps xmm10, [rsp+0x90]
000078d941fd9f27  vmovaps xmm11, [rsp+0xA0]
000078d941fd9f30  vmovaps xmm12, [rsp+0xB0]
000078d941fd9f39  vmovaps xmm13, [rsp+0xC0]
000078d941fd9f42  vmovaps xmm14, [rsp+0xD0]
000078d941fd9f4b  vmovaps xmm15, [rsp+0xE0]
000078d941fd9f54  add rsp, 0xF0
000078d941fd9f5b  pop r11
000078d941fd9f5d  pop r10
000078d941fd9f5f  pop r9
000078d941fd9f61  pop r8
000078d941fd9f63  pop rsi
000078d941fd9f64  pop rdi
000078d941fd9f65  pop rdx
000078d941fd9f66  pop rcx
000078d941fd9f67  pop rax
000078d941fd9f68  add rsp, 0x08
000078d941fd9f6c  jmp 0x000078D941FD63AE
000078d941fd9f71  sub rsp, 0x08
000078d941fd9f75  push rax
000078d941fd9f76  push rcx
000078d941fd9f77  push rdx
000078d941fd9f78  push rdi
000078d941fd9f79  push rsi
000078d941fd9f7a  push r8
000078d941fd9f7c  push r9
000078d941fd9f7e  push r10
000078d941fd9f80  push r11
000078d941fd9f82  sub rsp, 0xF0
000078d941fd9f89  vmovaps [rsp], xmm0
000078d941fd9f8e  vmovaps [rsp+0x10], xmm1
000078d941fd9f94  vmovaps [rsp+0x20], xmm2
000078d941fd9f9a  vmovaps [rsp+0x30], xmm3
000078d941fd9fa0  vmovaps [rsp+0x40], xmm4
000078d941fd9fa6  vmovaps [rsp+0x50], xmm5
000078d941fd9fac  vmovaps [rsp+0x60], xmm7
000078d941fd9fb2  vmovaps [rsp+0x70], xmm8
000078d941fd9fb8  vmovaps [rsp+0x80], xmm9
000078d941fd9fc1  vmovaps [rsp+0x90], xmm10
000078d941fd9fca  vmovaps [rsp+0xA0], xmm11
000078d941fd9fd3  vmovaps [rsp+0xB0], xmm12
000078d941fd9fdc  vmovaps [rsp+0xC0], xmm13
000078d941fd9fe5  vmovaps [rsp+0xD0], xmm14
000078d941fd9fee  vmovaps [rsp+0xE0], xmm15
000078d941fd9ff7  sub rsp, 0x30
000078d941fd9ffb  movaps [rsp], xmm6
000078d941fd9fff  movaps [rsp+0x10], xmm1
000078d941fda004  movaps [rsp+0x20], xmm14
000078d941fda00a  lea rdi, [rsp]
000078d941fda00e  mov esi, 0x00
000078d941fda013  mov rax, 0x59BFBFBAA530
000078d941fda01d  call rax
000078d941fda01f  movaps xmm6, [rsp]
000078d941fda023  add rsp, 0x30
000078d941fda027  vmovaps xmm0, [rsp]
000078d941fda02c  vmovaps xmm1, [rsp+0x10]
000078d941fda032  vmovaps xmm2, [rsp+0x20]
000078d941fda038  vmovaps xmm3, [rsp+0x30]
000078d941fda03e  vmovaps xmm4, [rsp+0x40]
000078d941fda044  vmovaps xmm5, [rsp+0x50]
000078d941fda04a  vmovaps xmm7, [rsp+0x60]
000078d941fda050  vmovaps xmm8, [rsp+0x70]
000078d941fda056  vmovaps xmm9, [rsp+0x80]
000078d941fda05f  vmovaps xmm10, [rsp+0x90]
000078d941fda068  vmovaps xmm11, [rsp+0xA0]
000078d941fda071  vmovaps xmm12, [rsp+0xB0]
000078d941fda07a  vmovaps xmm13, [rsp+0xC0]
000078d941fda083  vmovaps xmm14, [rsp+0xD0]
000078d941fda08c  vmovaps xmm15, [rsp+0xE0]
000078d941fda095  add rsp, 0xF0
000078d941fda09c  pop r11
000078d941fda09e  pop r10
000078d941fda0a0  pop r9
000078d941fda0a2  pop r8
000078d941fda0a4  pop rsi
000078d941fda0a5  pop rdi
000078d941fda0a6  pop rdx
000078d941fda0a7  pop rcx
000078d941fda0a8  pop rax
000078d941fda0a9  add rsp, 0x08
000078d941fda0ad  jmp 0x000078D941FD63DA
000078d941fda0b2  sub rsp, 0x08
000078d941fda0b6  push rax
000078d941fda0b7  push rcx
000078d941fda0b8  push rdx
000078d941fda0b9  push rdi
000078d941fda0ba  push rsi
000078d941fda0bb  push r8
000078d941fda0bd  push r9
000078d941fda0bf  push r10
000078d941fda0c1  push r11
000078d941fda0c3  sub rsp, 0xF0
000078d941fda0ca  vmovaps [rsp], xmm0
000078d941fda0cf  vmovaps [rsp+0x10], xmm1
000078d941fda0d5  vmovaps [rsp+0x20], xmm2
000078d941fda0db  vmovaps [rsp+0x30], xmm3
000078d941fda0e1  vmovaps [rsp+0x40], xmm4
000078d941fda0e7  vmovaps [rsp+0x50], xmm5
000078d941fda0ed  vmovaps [rsp+0x60], xmm6
000078d941fda0f3  vmovaps [rsp+0x70], xmm7
000078d941fda0f9  vmovaps [rsp+0x80], xmm8
000078d941fda102  vmovaps [rsp+0x90], xmm9
000078d941fda10b  vmovaps [rsp+0xA0], xmm10
000078d941fda114  vmovaps [rsp+0xB0], xmm11
000078d941fda11d  vmovaps [rsp+0xC0], xmm12
000078d941fda126  vmovaps [rsp+0xD0], xmm13
000078d941fda12f  vmovaps [rsp+0xE0], xmm15
000078d941fda138  sub rsp, 0x30
000078d941fda13c  movaps [rsp], xmm14
000078d941fda141  movaps [rsp+0x10], xmm12
000078d941fda147  movaps [rsp+0x20], xmm1
000078d941fda14c  lea rdi, [rsp]
000078d941fda150  mov esi, 0x00
000078d941fda155  mov rax, 0x59BFBFBAA530
000078d941fda15f  call rax
000078d941fda161  movaps xmm14, [rsp]
000078d941fda166  add rsp, 0x30
000078d941fda16a  vmovaps xmm0, [rsp]
000078d941fda16f  vmovaps xmm1, [rsp+0x10]
000078d941fda175  vmovaps xmm2, [rsp+0x20]
000078d941fda17b  vmovaps xmm3, [rsp+0x30]
000078d941fda181  vmovaps xmm4, [rsp+0x40]
000078d941fda187  vmovaps xmm5, [rsp+0x50]
000078d941fda18d  vmovaps xmm6, [rsp+0x60]
000078d941fda193  vmovaps xmm7, [rsp+0x70]
000078d941fda199  vmovaps xmm8, [rsp+0x80]
000078d941fda1a2  vmovaps xmm9, [rsp+0x90]
000078d941fda1ab  vmovaps xmm10, [rsp+0xA0]
000078d941fda1b4  vmovaps xmm11, [rsp+0xB0]
000078d941fda1bd  vmovaps xmm12, [rsp+0xC0]
000078d941fda1c6  vmovaps xmm13, [rsp+0xD0]
000078d941fda1cf  vmovaps xmm15, [rsp+0xE0]
000078d941fda1d8  add rsp, 0xF0
000078d941fda1df  pop r11
000078d941fda1e1  pop r10
000078d941fda1e3  pop r9
000078d941fda1e5  pop r8
000078d941fda1e7  pop rsi
000078d941fda1e8  pop rdi
000078d941fda1e9  pop rdx
000078d941fda1ea  pop rcx
000078d941fda1eb  pop rax
000078d941fda1ec  add rsp, 0x08
000078d941fda1f0  jmp 0x000078D941FD6400
000078d941fda1f5  sub rsp, 0x08
000078d941fda1f9  push rax
000078d941fda1fa  push rcx
000078d941fda1fb  push rdx
000078d941fda1fc  push rdi
000078d941fda1fd  push rsi
000078d941fda1fe  push r8
000078d941fda200  push r9
000078d941fda202  push r10
000078d941fda204  push r11
000078d941fda206  sub rsp, 0xF0
000078d941fda20d  vmovaps [rsp], xmm0
000078d941fda212  vmovaps [rsp+0x10], xmm2
000078d941fda218  vmovaps [rsp+0x20], xmm3
000078d941fda21e  vmovaps [rsp+0x30], xmm4
000078d941fda224  vmovaps [rsp+0x40], xmm5
000078d941fda22a  vmovaps [rsp+0x50], xmm6
000078d941fda230  vmovaps [rsp+0x60], xmm7
000078d941fda236  vmovaps [rsp+0x70], xmm8
000078d941fda23c  vmovaps [rsp+0x80], xmm9
000078d941fda245  vmovaps [rsp+0x90], xmm10
000078d941fda24e  vmovaps [rsp+0xA0], xmm11
000078d941fda257  vmovaps [rsp+0xB0], xmm12
000078d941fda260  vmovaps [rsp+0xC0], xmm13
000078d941fda269  vmovaps [rsp+0xD0], xmm14
000078d941fda272  vmovaps [rsp+0xE0], xmm15
000078d941fda27b  sub rsp, 0x30
000078d941fda27f  movaps [rsp], xmm1
000078d941fda283  movaps [rsp+0x10], xmm13
000078d941fda289  movaps [rsp+0x20], xmm9
000078d941fda28f  lea rdi, [rsp]
000078d941fda293  mov esi, 0x00
000078d941fda298  mov rax, 0x59BFBFBAA530
000078d941fda2a2  call rax
000078d941fda2a4  movaps xmm1, [rsp]
000078d941fda2a8  add rsp, 0x30
000078d941fda2ac  vmovaps xmm0, [rsp]
000078d941fda2b1  vmovaps xmm2, [rsp+0x10]
000078d941fda2b7  vmovaps xmm3, [rsp+0x20]
000078d941fda2bd  vmovaps xmm4, [rsp+0x30]
000078d941fda2c3  vmovaps xmm5, [rsp+0x40]
000078d941fda2c9  vmovaps xmm6, [rsp+0x50]
000078d941fda2cf  vmovaps xmm7, [rsp+0x60]
000078d941fda2d5  vmovaps xmm8, [rsp+0x70]
000078d941fda2db  vmovaps xmm9, [rsp+0x80]
000078d941fda2e4  vmovaps xmm10, [rsp+0x90]
000078d941fda2ed  vmovaps xmm11, [rsp+0xA0]
000078d941fda2f6  vmovaps xmm12, [rsp+0xB0]
000078d941fda2ff  vmovaps xmm13, [rsp+0xC0]
000078d941fda308  vmovaps xmm14, [rsp+0xD0]
000078d941fda311  vmovaps xmm15, [rsp+0xE0]
000078d941fda31a  add rsp, 0xF0
000078d941fda321  pop r11
000078d941fda323  pop r10
000078d941fda325  pop r9
000078d941fda327  pop r8
000078d941fda329  pop rsi
000078d941fda32a  pop rdi
000078d941fda32b  pop rdx
000078d941fda32c  pop rcx
000078d941fda32d  pop rax
000078d941fda32e  add rsp, 0x08
000078d941fda332  jmp 0x000078D941FD641A
000078d941fda337  sub rsp, 0x08
000078d941fda33b  push rax
000078d941fda33c  push rcx
000078d941fda33d  push rdx
000078d941fda33e  push rdi
000078d941fda33f  push rsi
000078d941fda340  push r8
000078d941fda342  push r9
000078d941fda344  push r10
000078d941fda346  push r11
000078d941fda348  sub rsp, 0xF0
000078d941fda34f  vmovaps [rsp], xmm0
000078d941fda354  vmovaps [rsp+0x10], xmm1
000078d941fda35a  vmovaps [rsp+0x20], xmm2
000078d941fda360  vmovaps [rsp+0x30], xmm3
000078d941fda366  vmovaps [rsp+0x40], xmm4
000078d941fda36c  vmovaps [rsp+0x50], xmm5
000078d941fda372  vmovaps [rsp+0x60], xmm6
000078d941fda378  vmovaps [rsp+0x70], xmm7
000078d941fda37e  vmovaps [rsp+0x80], xmm8
000078d941fda387  vmovaps [rsp+0x90], xmm9
000078d941fda390  vmovaps [rsp+0xA0], xmm10
000078d941fda399  vmovaps [rsp+0xB0], xmm11
000078d941fda3a2  vmovaps [rsp+0xC0], xmm13
000078d941fda3ab  vmovaps [rsp+0xD0], xmm14
000078d941fda3b4  vmovaps [rsp+0xE0], xmm15
000078d941fda3bd  sub rsp, 0x30
000078d941fda3c1  movaps [rsp], xmm12
000078d941fda3c6  movaps [rsp+0x10], xmm7
000078d941fda3cb  movaps [rsp+0x20], xmm13
000078d941fda3d1  lea rdi, [rsp]
000078d941fda3d5  mov esi, 0x00
000078d941fda3da  mov rax, 0x59BFBFBAA530
000078d941fda3e4  call rax
000078d941fda3e6  movaps xmm12, [rsp]
000078d941fda3eb  add rsp, 0x30
000078d941fda3ef  vmovaps xmm0, [rsp]
000078d941fda3f4  vmovaps xmm1, [rsp+0x10]
000078d941fda3fa  vmovaps xmm2, [rsp+0x20]
000078d941fda400  vmovaps xmm3, [rsp+0x30]
000078d941fda406  vmovaps xmm4, [rsp+0x40]
000078d941fda40c  vmovaps xmm5, [rsp+0x50]
000078d941fda412  vmovaps xmm6, [rsp+0x60]
000078d941fda418  vmovaps xmm7, [rsp+0x70]
000078d941fda41e  vmovaps xmm8, [rsp+0x80]
000078d941fda427  vmovaps xmm9, [rsp+0x90]
000078d941fda430  vmovaps xmm10, [rsp+0xA0]
000078d941fda439  vmovaps xmm11, [rsp+0xB0]
000078d941fda442  vmovaps xmm13, [rsp+0xC0]
000078d941fda44b  vmovaps xmm14, [rsp+0xD0]
000078d941fda454  vmovaps xmm15, [rsp+0xE0]
000078d941fda45d  add rsp, 0xF0
000078d941fda464  pop r11
000078d941fda466  pop r10
000078d941fda468  pop r9
000078d941fda46a  pop r8
000078d941fda46c  pop rsi
000078d941fda46d  pop rdi
000078d941fda46e  pop rdx
000078d941fda46f  pop rcx
000078d941fda470  pop rax
000078d941fda471  add rsp, 0x08
000078d941fda475  jmp 0x000078D941FD6441
000078d941fda47a  sub rsp, 0x08
000078d941fda47e  push rax
000078d941fda47f  push rcx
000078d941fda480  push rdx
000078d941fda481  push rdi
000078d941fda482  push rsi
000078d941fda483  push r8
000078d941fda485  push r9
000078d941fda487  push r10
000078d941fda489  push r11
000078d941fda48b  sub rsp, 0xF0
000078d941fda492  vmovaps [rsp], xmm0
000078d941fda497  vmovaps [rsp+0x10], xmm1
000078d941fda49d  vmovaps [rsp+0x20], xmm2
000078d941fda4a3  vmovaps [rsp+0x30], xmm3
000078d941fda4a9  vmovaps [rsp+0x40], xmm4
000078d941fda4af  vmovaps [rsp+0x50], xmm5
000078d941fda4b5  vmovaps [rsp+0x60], xmm6
000078d941fda4bb  vmovaps [rsp+0x70], xmm7
000078d941fda4c1  vmovaps [rsp+0x80], xmm8
000078d941fda4ca  vmovaps [rsp+0x90], xmm9
000078d941fda4d3  vmovaps [rsp+0xA0], xmm10
000078d941fda4dc  vmovaps [rsp+0xB0], xmm11
000078d941fda4e5  vmovaps [rsp+0xC0], xmm12
000078d941fda4ee  vmovaps [rsp+0xD0], xmm14
000078d941fda4f7  vmovaps [rsp+0xE0], xmm15
000078d941fda500  sub rsp, 0x30
000078d941fda504  movaps [rsp], xmm13
000078d941fda509  movaps [rsp+0x10], xmm15
000078d941fda50f  movaps [rsp+0x20], xmm8
000078d941fda515  lea rdi, [rsp]
000078d941fda519  mov esi, 0x00
000078d941fda51e  mov rax, 0x59BFBFBAA530
000078d941fda528  call rax
000078d941fda52a  movaps xmm13, [rsp]
000078d941fda52f  add rsp, 0x30
000078d941fda533  vmovaps xmm0, [rsp]
000078d941fda538  vmovaps xmm1, [rsp+0x10]
000078d941fda53e  vmovaps xmm2, [rsp+0x20]
000078d941fda544  vmovaps xmm3, [rsp+0x30]
000078d941fda54a  vmovaps xmm4, [rsp+0x40]
000078d941fda550  vmovaps xmm5, [rsp+0x50]
000078d941fda556  vmovaps xmm6, [rsp+0x60]
000078d941fda55c  vmovaps xmm7, [rsp+0x70]
000078d941fda562  vmovaps xmm8, [rsp+0x80]
000078d941fda56b  vmovaps xmm9, [rsp+0x90]
000078d941fda574  vmovaps xmm10, [rsp+0xA0]
000078d941fda57d  vmovaps xmm11, [rsp+0xB0]
000078d941fda586  vmovaps xmm12, [rsp+0xC0]
000078d941fda58f  vmovaps xmm14, [rsp+0xD0]
000078d941fda598  vmovaps xmm15, [rsp+0xE0]
000078d941fda5a1  add rsp, 0xF0
000078d941fda5a8  pop r11
000078d941fda5aa  pop r10
000078d941fda5ac  pop r9
000078d941fda5ae  pop r8
000078d941fda5b0  pop rsi
000078d941fda5b1  pop rdi
000078d941fda5b2  pop rdx
000078d941fda5b3  pop rcx
000078d941fda5b4  pop rax
000078d941fda5b5  add rsp, 0x08
000078d941fda5b9  jmp 0x000078D941FD645C
000078d941fda5be  sub rsp, 0x08
000078d941fda5c2  push rax
000078d941fda5c3  push rcx
000078d941fda5c4  push rdx
000078d941fda5c5  push rdi
000078d941fda5c6  push rsi
000078d941fda5c7  push r8
000078d941fda5c9  push r9
000078d941fda5cb  push r10
000078d941fda5cd  push r11
000078d941fda5cf  sub rsp, 0xF0
000078d941fda5d6  vmovaps [rsp], xmm0
000078d941fda5db  vmovaps [rsp+0x10], xmm1
000078d941fda5e1  vmovaps [rsp+0x20], xmm2
000078d941fda5e7  vmovaps [rsp+0x30], xmm3
000078d941fda5ed  vmovaps [rsp+0x40], xmm4
000078d941fda5f3  vmovaps [rsp+0x50], xmm5
000078d941fda5f9  vmovaps [rsp+0x60], xmm6
000078d941fda5ff  vmovaps [rsp+0x70], xmm7
000078d941fda605  vmovaps [rsp+0x80], xmm9
000078d941fda60e  vmovaps [rsp+0x90], xmm10
000078d941fda617  vmovaps [rsp+0xA0], xmm11
000078d941fda620  vmovaps [rsp+0xB0], xmm12
000078d941fda629  vmovaps [rsp+0xC0], xmm13
000078d941fda632  vmovaps [rsp+0xD0], xmm14
000078d941fda63b  vmovaps [rsp+0xE0], xmm15
000078d941fda644  sub rsp, 0x30
000078d941fda648  movaps [rsp], xmm8
000078d941fda64d  movaps [rsp+0x10], xmm15
000078d941fda653  movaps [rsp+0x20], xmm9
000078d941fda659  lea rdi, [rsp]
000078d941fda65d  mov esi, 0x00
000078d941fda662  mov rax, 0x59BFBFBAA530
000078d941fda66c  call rax
000078d941fda66e  movaps xmm8, [rsp]
000078d941fda673  add rsp, 0x30
000078d941fda677  vmovaps xmm0, [rsp]
000078d941fda67c  vmovaps xmm1, [rsp+0x10]
000078d941fda682  vmovaps xmm2, [rsp+0x20]
000078d941fda688  vmovaps xmm3, [rsp+0x30]
000078d941fda68e  vmovaps xmm4, [rsp+0x40]
000078d941fda694  vmovaps xmm5, [rsp+0x50]
000078d941fda69a  vmovaps xmm6, [rsp+0x60]
000078d941fda6a0  vmovaps xmm7, [rsp+0x70]
000078d941fda6a6  vmovaps xmm9, [rsp+0x80]
000078d941fda6af  vmovaps xmm10, [rsp+0x90]
000078d941fda6b8  vmovaps xmm11, [rsp+0xA0]
000078d941fda6c1  vmovaps xmm12, [rsp+0xB0]
000078d941fda6ca  vmovaps xmm13, [rsp+0xC0]
000078d941fda6d3  vmovaps xmm14, [rsp+0xD0]
000078d941fda6dc  vmovaps xmm15, [rsp+0xE0]
000078d941fda6e5  add rsp, 0xF0
000078d941fda6ec  pop r11
000078d941fda6ee  pop r10
000078d941fda6f0  pop r9
000078d941fda6f2  pop r8
000078d941fda6f4  pop rsi
000078d941fda6f5  pop rdi
000078d941fda6f6  pop rdx
000078d941fda6f7  pop rcx
000078d941fda6f8  pop rax
000078d941fda6f9  add rsp, 0x08
000078d941fda6fd  jmp 0x000078D941FD648A
000078d941fda702  sub rsp, 0x08
000078d941fda706  push rax
000078d941fda707  push rcx
000078d941fda708  push rdx
000078d941fda709  push rdi
000078d941fda70a  push rsi
000078d941fda70b  push r8
000078d941fda70d  push r9
000078d941fda70f  push r10
000078d941fda711  push r11
000078d941fda713  sub rsp, 0xF0
000078d941fda71a  vmovaps [rsp], xmm0
000078d941fda71f  vmovaps [rsp+0x10], xmm1
000078d941fda725  vmovaps [rsp+0x20], xmm2
000078d941fda72b  vmovaps [rsp+0x30], xmm3
000078d941fda731  vmovaps [rsp+0x40], xmm4
000078d941fda737  vmovaps [rsp+0x50], xmm5
000078d941fda73d  vmovaps [rsp+0x60], xmm6
000078d941fda743  vmovaps [rsp+0x70], xmm7
000078d941fda749  vmovaps [rsp+0x80], xmm8
000078d941fda752  vmovaps [rsp+0x90], xmm9
000078d941fda75b  vmovaps [rsp+0xA0], xmm10
000078d941fda764  vmovaps [rsp+0xB0], xmm11
000078d941fda76d  vmovaps [rsp+0xC0], xmm12
000078d941fda776  vmovaps [rsp+0xD0], xmm13
000078d941fda77f  vmovaps [rsp+0xE0], xmm14
000078d941fda788  sub rsp, 0x30
000078d941fda78c  movaps [rsp], xmm15
000078d941fda791  movaps [rsp+0x10], xmm11
000078d941fda797  movaps [rsp+0x20], xmm6
000078d941fda79c  lea rdi, [rsp]
000078d941fda7a0  mov esi, 0x00
000078d941fda7a5  mov rax, 0x59BFBFBAA530
000078d941fda7af  call rax
000078d941fda7b1  movaps xmm15, [rsp]
000078d941fda7b6  add rsp, 0x30
000078d941fda7ba  vmovaps xmm0, [rsp]
000078d941fda7bf  vmovaps xmm1, [rsp+0x10]
000078d941fda7c5  vmovaps xmm2, [rsp+0x20]
000078d941fda7cb  vmovaps xmm3, [rsp+0x30]
000078d941fda7d1  vmovaps xmm4, [rsp+0x40]
000078d941fda7d7  vmovaps xmm5, [rsp+0x50]
000078d941fda7dd  vmovaps xmm6, [rsp+0x60]
000078d941fda7e3  vmovaps xmm7, [rsp+0x70]
000078d941fda7e9  vmovaps xmm8, [rsp+0x80]
000078d941fda7f2  vmovaps xmm9, [rsp+0x90]
000078d941fda7fb  vmovaps xmm10, [rsp+0xA0]
000078d941fda804  vmovaps xmm11, [rsp+0xB0]
000078d941fda80d  vmovaps xmm12, [rsp+0xC0]
000078d941fda816  vmovaps xmm13, [rsp+0xD0]
000078d941fda81f  vmovaps xmm14, [rsp+0xE0]
000078d941fda828  add rsp, 0xF0
000078d941fda82f  pop r11
000078d941fda831  pop r10
000078d941fda833  pop r9
000078d941fda835  pop r8
000078d941fda837  pop rsi
000078d941fda838  pop rdi
000078d941fda839  pop rdx
000078d941fda83a  pop rcx
000078d941fda83b  pop rax
000078d941fda83c  add rsp, 0x08
000078d941fda840  jmp 0x000078D941FD64A5
000078d941fda845  sub rsp, 0x08
000078d941fda849  push rax
000078d941fda84a  push rcx
000078d941fda84b  push rdx
000078d941fda84c  push rdi
000078d941fda84d  push rsi
000078d941fda84e  push r8
000078d941fda850  push r9
000078d941fda852  push r10
000078d941fda854  push r11
000078d941fda856  sub rsp, 0xF0
000078d941fda85d  vmovaps [rsp], xmm0
000078d941fda862  vmovaps [rsp+0x10], xmm1
000078d941fda868  vmovaps [rsp+0x20], xmm2
000078d941fda86e  vmovaps [rsp+0x30], xmm3
000078d941fda874  vmovaps [rsp+0x40], xmm4
000078d941fda87a  vmovaps [rsp+0x50], xmm5
000078d941fda880  vmovaps [rsp+0x60], xmm6
000078d941fda886  vmovaps [rsp+0x70], xmm8
000078d941fda88c  vmovaps [rsp+0x80], xmm9
000078d941fda895  vmovaps [rsp+0x90], xmm10
000078d941fda89e  vmovaps [rsp+0xA0], xmm11
000078d941fda8a7  vmovaps [rsp+0xB0], xmm12
000078d941fda8b0  vmovaps [rsp+0xC0], xmm13
000078d941fda8b9  vmovaps [rsp+0xD0], xmm14
000078d941fda8c2  vmovaps [rsp+0xE0], xmm15
000078d941fda8cb  sub rsp, 0x30
000078d941fda8cf  movaps [rsp], xmm7
000078d941fda8d3  movaps [rsp+0x10], xmm11
000078d941fda8d9  movaps [rsp+0x20], xmm9
000078d941fda8df  lea rdi, [rsp]
000078d941fda8e3  mov esi, 0x00
000078d941fda8e8  mov rax, 0x59BFBFBAA530
000078d941fda8f2  call rax
000078d941fda8f4  movaps xmm7, [rsp]
000078d941fda8f8  add rsp, 0x30
000078d941fda8fc  vmovaps xmm0, [rsp]
000078d941fda901  vmovaps xmm1, [rsp+0x10]
000078d941fda907  vmovaps xmm2, [rsp+0x20]
000078d941fda90d  vmovaps xmm3, [rsp+0x30]
000078d941fda913  vmovaps xmm4, [rsp+0x40]
000078d941fda919  vmovaps xmm5, [rsp+0x50]
000078d941fda91f  vmovaps xmm6, [rsp+0x60]
000078d941fda925  vmovaps xmm8, [rsp+0x70]
000078d941fda92b  vmovaps xmm9, [rsp+0x80]
000078d941fda934  vmovaps xmm10, [rsp+0x90]
000078d941fda93d  vmovaps xmm11, [rsp+0xA0]
000078d941fda946  vmovaps xmm12, [rsp+0xB0]
000078d941fda94f  vmovaps xmm13, [rsp+0xC0]
000078d941fda958  vmovaps xmm14, [rsp+0xD0]
000078d941fda961  vmovaps xmm15, [rsp+0xE0]
000078d941fda96a  add rsp, 0xF0
000078d941fda971  pop r11
000078d941fda973  pop r10
000078d941fda975  pop r9
000078d941fda977  pop r8
000078d941fda979  pop rsi
000078d941fda97a  pop rdi
000078d941fda97b  pop rdx
000078d941fda97c  pop rcx
000078d941fda97d  pop rax
000078d941fda97e  add rsp, 0x08
000078d941fda982  jmp 0x000078D941FD64D2
000078d941fda987  sub rsp, 0x08
000078d941fda98b  push rax
000078d941fda98c  push rcx
000078d941fda98d  push rdx
000078d941fda98e  push rdi
000078d941fda98f  push rsi
000078d941fda990  push r8
000078d941fda992  push r9
000078d941fda994  push r10
000078d941fda996  push r11
000078d941fda998  sub rsp, 0xF0
000078d941fda99f  vmovaps [rsp], xmm0
000078d941fda9a4  vmovaps [rsp+0x10], xmm1
000078d941fda9aa  vmovaps [rsp+0x20], xmm2
000078d941fda9b0  vmovaps [rsp+0x30], xmm3
000078d941fda9b6  vmovaps [rsp+0x40], xmm4
000078d941fda9bc  vmovaps [rsp+0x50], xmm5
000078d941fda9c2  vmovaps [rsp+0x60], xmm6
000078d941fda9c8  vmovaps [rsp+0x70], xmm7
000078d941fda9ce  vmovaps [rsp+0x80], xmm8
000078d941fda9d7  vmovaps [rsp+0x90], xmm9
000078d941fda9e0  vmovaps [rsp+0xA0], xmm10
000078d941fda9e9  vmovaps [rsp+0xB0], xmm12
000078d941fda9f2  vmovaps [rsp+0xC0], xmm13
000078d941fda9fb  vmovaps [rsp+0xD0], xmm14
000078d941fdaa04  vmovaps [rsp+0xE0], xmm15
000078d941fdaa0d  sub rsp, 0x30
000078d941fdaa11  movaps [rsp], xmm11
000078d941fdaa16  movaps [rsp+0x10], xmm10
000078d941fdaa1c  movaps [rsp+0x20], xmm14
000078d941fdaa22  lea rdi, [rsp]
000078d941fdaa26  mov esi, 0x00
000078d941fdaa2b  mov rax, 0x59BFBFBAA530
000078d941fdaa35  call rax
000078d941fdaa37  movaps xmm11, [rsp]
000078d941fdaa3c  add rsp, 0x30
000078d941fdaa40  vmovaps xmm0, [rsp]
000078d941fdaa45  vmovaps xmm1, [rsp+0x10]
000078d941fdaa4b  vmovaps xmm2, [rsp+0x20]
000078d941fdaa51  vmovaps xmm3, [rsp+0x30]
000078d941fdaa57  vmovaps xmm4, [rsp+0x40]
000078d941fdaa5d  vmovaps xmm5, [rsp+0x50]
000078d941fdaa63  vmovaps xmm6, [rsp+0x60]
000078d941fdaa69  vmovaps xmm7, [rsp+0x70]
000078d941fdaa6f  vmovaps xmm8, [rsp+0x80]
000078d941fdaa78  vmovaps xmm9, [rsp+0x90]
000078d941fdaa81  vmovaps xmm10, [rsp+0xA0]
000078d941fdaa8a  vmovaps xmm12, [rsp+0xB0]
000078d941fdaa93  vmovaps xmm13, [rsp+0xC0]
000078d941fdaa9c  vmovaps xmm14, [rsp+0xD0]
000078d941fdaaa5  vmovaps xmm15, [rsp+0xE0]
000078d941fdaaae  add rsp, 0xF0
000078d941fdaab5  pop r11
000078d941fdaab7  pop r10
000078d941fdaab9  pop r9
000078d941fdaabb  pop r8
000078d941fdaabd  pop rsi
000078d941fdaabe  pop rdi
000078d941fdaabf  pop rdx
000078d941fdaac0  pop rcx
000078d941fdaac1  pop rax
000078d941fdaac2  add rsp, 0x08
000078d941fdaac6  jmp 0x000078D941FD64ED
000078d941fdaacb  call 0x000078D941EE45A0
000078d941fdaad0  jmp 0x000078D941FD64F7
000078d941fdaad5  sub rsp, 0x08
000078d941fdaad9  push rax
000078d941fdaada  push rcx
000078d941fdaadb  push rdx
000078d941fdaadc  push rdi
000078d941fdaadd  push rsi
000078d941fdaade  push r8
000078d941fdaae0  push r9
000078d941fdaae2  push r10
000078d941fdaae4  push r11
000078d941fdaae6  sub rsp, 0xF0
000078d941fdaaed  vmovaps [rsp], xmm0
000078d941fdaaf2  vmovaps [rsp+0x10], xmm1
000078d941fdaaf8  vmovaps [rsp+0x20], xmm2
000078d941fdaafe  vmovaps [rsp+0x30], xmm3
000078d941fdab04  vmovaps [rsp+0x40], xmm4
000078d941fdab0a  vmovaps [rsp+0x50], xmm5
000078d941fdab10  vmovaps [rsp+0x60], xmm6
000078d941fdab16  vmovaps [rsp+0x70], xmm7
000078d941fdab1c  vmovaps [rsp+0x80], xmm8
000078d941fdab25  vmovaps [rsp+0x90], xmm9
000078d941fdab2e  vmovaps [rsp+0xA0], xmm11
000078d941fdab37  vmovaps [rsp+0xB0], xmm12
000078d941fdab40  vmovaps [rsp+0xC0], xmm13
000078d941fdab49  vmovaps [rsp+0xD0], xmm14
000078d941fdab52  vmovaps [rsp+0xE0], xmm15
000078d941fdab5b  sub rsp, 0x30
000078d941fdab5f  movaps [rsp], xmm10
000078d941fdab64  movaps [rsp+0x10], xmm1
000078d941fdab69  movaps [rsp+0x20], xmm12
000078d941fdab6f  lea rdi, [rsp]
000078d941fdab73  mov esi, 0x00
000078d941fdab78  mov rax, 0x59BFBFBAA530
000078d941fdab82  call rax
000078d941fdab84  movaps xmm10, [rsp]
000078d941fdab89  add rsp, 0x30
000078d941fdab8d  vmovaps xmm0, [rsp]
000078d941fdab92  vmovaps xmm1, [rsp+0x10]
000078d941fdab98  vmovaps xmm2, [rsp+0x20]
000078d941fdab9e  vmovaps xmm3, [rsp+0x30]
000078d941fdaba4  vmovaps xmm4, [rsp+0x40]
000078d941fdabaa  vmovaps xmm5, [rsp+0x50]
000078d941fdabb0  vmovaps xmm6, [rsp+0x60]
000078d941fdabb6  vmovaps xmm7, [rsp+0x70]
000078d941fdabbc  vmovaps xmm8, [rsp+0x80]
000078d941fdabc5  vmovaps xmm9, [rsp+0x90]
000078d941fdabce  vmovaps xmm11, [rsp+0xA0]
000078d941fdabd7  vmovaps xmm12, [rsp+0xB0]
000078d941fdabe0  vmovaps xmm13, [rsp+0xC0]
000078d941fdabe9  vmovaps xmm14, [rsp+0xD0]
000078d941fdabf2  vmovaps xmm15, [rsp+0xE0]
000078d941fdabfb  add rsp, 0xF0
000078d941fdac02  pop r11
000078d941fdac04  pop r10
000078d941fdac06  pop r9
000078d941fdac08  pop r8
000078d941fdac0a  pop rsi
000078d941fdac0b  pop rdi
000078d941fdac0c  pop rdx
000078d941fdac0d  pop rcx
000078d941fdac0e  pop rax
000078d941fdac0f  add rsp, 0x08
000078d941fdac13  jmp 0x000078D941FD651A
000078d941fdac18  sub rsp, 0x08
000078d941fdac1c  push rax
000078d941fdac1d  push rcx
000078d941fdac1e  push rdx
000078d941fdac1f  push rdi
000078d941fdac20  push rsi
000078d941fdac21  push r8
000078d941fdac23  push r9
000078d941fdac25  push r10
000078d941fdac27  push r11
000078d941fdac29  sub rsp, 0xF0
000078d941fdac30  vmovaps [rsp], xmm0
000078d941fdac35  vmovaps [rsp+0x10], xmm1
000078d941fdac3b  vmovaps [rsp+0x20], xmm2
000078d941fdac41  vmovaps [rsp+0x30], xmm3
000078d941fdac47  vmovaps [rsp+0x40], xmm4
000078d941fdac4d  vmovaps [rsp+0x50], xmm5
000078d941fdac53  vmovaps [rsp+0x60], xmm6
000078d941fdac59  vmovaps [rsp+0x70], xmm7
000078d941fdac5f  vmovaps [rsp+0x80], xmm8
000078d941fdac68  vmovaps [rsp+0x90], xmm9
000078d941fdac71  vmovaps [rsp+0xA0], xmm10
000078d941fdac7a  vmovaps [rsp+0xB0], xmm11
000078d941fdac83  vmovaps [rsp+0xC0], xmm13
000078d941fdac8c  vmovaps [rsp+0xD0], xmm14
000078d941fdac95  vmovaps [rsp+0xE0], xmm15
000078d941fdac9e  sub rsp, 0x30
000078d941fdaca2  movaps [rsp], xmm12
000078d941fdaca7  movaps [rsp+0x10], xmm14
000078d941fdacad  movaps [rsp+0x20], xmm1
000078d941fdacb2  lea rdi, [rsp]
000078d941fdacb6  mov esi, 0x00
000078d941fdacbb  mov rax, 0x59BFBFBAA530
000078d941fdacc5  call rax
000078d941fdacc7  movaps xmm12, [rsp]
000078d941fdaccc  add rsp, 0x30
000078d941fdacd0  vmovaps xmm0, [rsp]
000078d941fdacd5  vmovaps xmm1, [rsp+0x10]
000078d941fdacdb  vmovaps xmm2, [rsp+0x20]
000078d941fdace1  vmovaps xmm3, [rsp+0x30]
000078d941fdace7  vmovaps xmm4, [rsp+0x40]
000078d941fdaced  vmovaps xmm5, [rsp+0x50]
000078d941fdacf3  vmovaps xmm6, [rsp+0x60]
000078d941fdacf9  vmovaps xmm7, [rsp+0x70]
000078d941fdacff  vmovaps xmm8, [rsp+0x80]
000078d941fdad08  vmovaps xmm9, [rsp+0x90]
000078d941fdad11  vmovaps xmm10, [rsp+0xA0]
000078d941fdad1a  vmovaps xmm11, [rsp+0xB0]
000078d941fdad23  vmovaps xmm13, [rsp+0xC0]
000078d941fdad2c  vmovaps xmm14, [rsp+0xD0]
000078d941fdad35  vmovaps xmm15, [rsp+0xE0]
000078d941fdad3e  add rsp, 0xF0
000078d941fdad45  pop r11
000078d941fdad47  pop r10
000078d941fdad49  pop r9
000078d941fdad4b  pop r8
000078d941fdad4d  pop rsi
000078d941fdad4e  pop rdi
000078d941fdad4f  pop rdx
000078d941fdad50  pop rcx
000078d941fdad51  pop rax
000078d941fdad52  add rsp, 0x08
000078d941fdad56  jmp 0x000078D941FD6549
000078d941fdad5b  sub rsp, 0x08
000078d941fdad5f  push rax
000078d941fdad60  push rcx
000078d941fdad61  push rdx
000078d941fdad62  push rdi
000078d941fdad63  push rsi
000078d941fdad64  push r8
000078d941fdad66  push r9
000078d941fdad68  push r10
000078d941fdad6a  push r11
000078d941fdad6c  sub rsp, 0xF0
000078d941fdad73  vmovaps [rsp], xmm0
000078d941fdad78  vmovaps [rsp+0x10], xmm1
000078d941fdad7e  vmovaps [rsp+0x20], xmm2
000078d941fdad84  vmovaps [rsp+0x30], xmm3
000078d941fdad8a  vmovaps [rsp+0x40], xmm4
000078d941fdad90  vmovaps [rsp+0x50], xmm5
000078d941fdad96  vmovaps [rsp+0x60], xmm6
000078d941fdad9c  vmovaps [rsp+0x70], xmm7
000078d941fdada2  vmovaps [rsp+0x80], xmm8
000078d941fdadab  vmovaps [rsp+0x90], xmm9
000078d941fdadb4  vmovaps [rsp+0xA0], xmm10
000078d941fdadbd  vmovaps [rsp+0xB0], xmm11
000078d941fdadc6  vmovaps [rsp+0xC0], xmm12
000078d941fdadcf  vmovaps [rsp+0xD0], xmm13
000078d941fdadd8  vmovaps [rsp+0xE0], xmm15
000078d941fdade1  sub rsp, 0x30
000078d941fdade5  movaps [rsp], xmm14
000078d941fdadea  movaps [rsp+0x10], xmm9
000078d941fdadf0  movaps [rsp+0x20], xmm1
000078d941fdadf5  lea rdi, [rsp]
000078d941fdadf9  mov esi, 0x00
000078d941fdadfe  mov rax, 0x59BFBFBAA530
000078d941fdae08  call rax
000078d941fdae0a  movaps xmm14, [rsp]
000078d941fdae0f  add rsp, 0x30
000078d941fdae13  vmovaps xmm0, [rsp]
000078d941fdae18  vmovaps xmm1, [rsp+0x10]
000078d941fdae1e  vmovaps xmm2, [rsp+0x20]
000078d941fdae24  vmovaps xmm3, [rsp+0x30]
000078d941fdae2a  vmovaps xmm4, [rsp+0x40]
000078d941fdae30  vmovaps xmm5, [rsp+0x50]
000078d941fdae36  vmovaps xmm6, [rsp+0x60]
000078d941fdae3c  vmovaps xmm7, [rsp+0x70]
000078d941fdae42  vmovaps xmm8, [rsp+0x80]
000078d941fdae4b  vmovaps xmm9, [rsp+0x90]
000078d941fdae54  vmovaps xmm10, [rsp+0xA0]
000078d941fdae5d  vmovaps xmm11, [rsp+0xB0]
000078d941fdae66  vmovaps xmm12, [rsp+0xC0]
000078d941fdae6f  vmovaps xmm13, [rsp+0xD0]
000078d941fdae78  vmovaps xmm15, [rsp+0xE0]
000078d941fdae81  add rsp, 0xF0
000078d941fdae88  pop r11
000078d941fdae8a  pop r10
000078d941fdae8c  pop r9
000078d941fdae8e  pop r8
000078d941fdae90  pop rsi
000078d941fdae91  pop rdi
000078d941fdae92  pop rdx
000078d941fdae93  pop rcx
000078d941fdae94  pop rax
000078d941fdae95  add rsp, 0x08
000078d941fdae99  jmp 0x000078D941FD6578
000078d941fdae9e  sub rsp, 0x08
000078d941fdaea2  push rax
000078d941fdaea3  push rcx
000078d941fdaea4  push rdx
000078d941fdaea5  push rdi
000078d941fdaea6  push rsi
000078d941fdaea7  push r8
000078d941fdaea9  push r9
000078d941fdaeab  push r10
000078d941fdaead  push r11
000078d941fdaeaf  sub rsp, 0xF0
000078d941fdaeb6  vmovaps [rsp], xmm0
000078d941fdaebb  vmovaps [rsp+0x10], xmm2
000078d941fdaec1  vmovaps [rsp+0x20], xmm3
000078d941fdaec7  vmovaps [rsp+0x30], xmm4
000078d941fdaecd  vmovaps [rsp+0x40], xmm5
000078d941fdaed3  vmovaps [rsp+0x50], xmm6
000078d941fdaed9  vmovaps [rsp+0x60], xmm7
000078d941fdaedf  vmovaps [rsp+0x70], xmm8
000078d941fdaee5  vmovaps [rsp+0x80], xmm9
000078d941fdaeee  vmovaps [rsp+0x90], xmm10
000078d941fdaef7  vmovaps [rsp+0xA0], xmm11
000078d941fdaf00  vmovaps [rsp+0xB0], xmm12
000078d941fdaf09  vmovaps [rsp+0xC0], xmm13
000078d941fdaf12  vmovaps [rsp+0xD0], xmm14
000078d941fdaf1b  vmovaps [rsp+0xE0], xmm15
000078d941fdaf24  sub rsp, 0x30
000078d941fdaf28  movaps [rsp], xmm1
000078d941fdaf2c  movaps [rsp+0x10], xmm13
000078d941fdaf32  movaps [rsp+0x20], xmm8
000078d941fdaf38  lea rdi, [rsp]
000078d941fdaf3c  mov esi, 0x00
000078d941fdaf41  mov rax, 0x59BFBFBAA530
000078d941fdaf4b  call rax
000078d941fdaf4d  movaps xmm1, [rsp]
000078d941fdaf51  add rsp, 0x30
000078d941fdaf55  vmovaps xmm0, [rsp]
000078d941fdaf5a  vmovaps xmm2, [rsp+0x10]
000078d941fdaf60  vmovaps xmm3, [rsp+0x20]
000078d941fdaf66  vmovaps xmm4, [rsp+0x30]
000078d941fdaf6c  vmovaps xmm5, [rsp+0x40]
000078d941fdaf72  vmovaps xmm6, [rsp+0x50]
000078d941fdaf78  vmovaps xmm7, [rsp+0x60]
000078d941fdaf7e  vmovaps xmm8, [rsp+0x70]
000078d941fdaf84  vmovaps xmm9, [rsp+0x80]
000078d941fdaf8d  vmovaps xmm10, [rsp+0x90]
000078d941fdaf96  vmovaps xmm11, [rsp+0xA0]
000078d941fdaf9f  vmovaps xmm12, [rsp+0xB0]
000078d941fdafa8  vmovaps xmm13, [rsp+0xC0]
000078d941fdafb1  vmovaps xmm14, [rsp+0xD0]
000078d941fdafba  vmovaps xmm15, [rsp+0xE0]
000078d941fdafc3  add rsp, 0xF0
000078d941fdafca  pop r11
000078d941fdafcc  pop r10
000078d941fdafce  pop r9
000078d941fdafd0  pop r8
000078d941fdafd2  pop rsi
000078d941fdafd3  pop rdi
000078d941fdafd4  pop rdx
000078d941fdafd5  pop rcx
000078d941fdafd6  pop rax
000078d941fdafd7  add rsp, 0x08
000078d941fdafdb  jmp 0x000078D941FD659A
000078d941fdafe0  call 0x000078D941E0C260
000078d941fdafe5  jmp 0x000078D941FD65A8
000078d941fdafea  call 0x000078D941EDE950
000078d941fdafef  jmp 0x000078D941FD65B2
000078d941fdaff4  sub rsp, 0x08
000078d941fdaff8  push rax
000078d941fdaff9  push rcx
000078d941fdaffa  push rdx
000078d941fdaffb  push rdi
000078d941fdaffc  push rsi
000078d941fdaffd  push r8
000078d941fdafff  push r9
000078d941fdb001  push r10
000078d941fdb003  push r11
000078d941fdb005  sub rsp, 0xF0
000078d941fdb00c  vmovaps [rsp], xmm0
000078d941fdb011  vmovaps [rsp+0x10], xmm1
000078d941fdb017  vmovaps [rsp+0x20], xmm2
000078d941fdb01d  vmovaps [rsp+0x30], xmm3
000078d941fdb023  vmovaps [rsp+0x40], xmm4
000078d941fdb029  vmovaps [rsp+0x50], xmm5
000078d941fdb02f  vmovaps [rsp+0x60], xmm6
000078d941fdb035  vmovaps [rsp+0x70], xmm7
000078d941fdb03b  vmovaps [rsp+0x80], xmm9
000078d941fdb044  vmovaps [rsp+0x90], xmm10
000078d941fdb04d  vmovaps [rsp+0xA0], xmm11
000078d941fdb056  vmovaps [rsp+0xB0], xmm12
000078d941fdb05f  vmovaps [rsp+0xC0], xmm13
000078d941fdb068  vmovaps [rsp+0xD0], xmm14
000078d941fdb071  vmovaps [rsp+0xE0], xmm15
000078d941fdb07a  sub rsp, 0x30
000078d941fdb07e  movaps [rsp], xmm8
000078d941fdb083  movaps [rsp+0x10], xmm15
000078d941fdb089  movaps [rsp+0x20], xmm7
000078d941fdb08e  lea rdi, [rsp]
000078d941fdb092  mov esi, 0x00
000078d941fdb097  mov rax, 0x59BFBFBAA530
000078d941fdb0a1  call rax
000078d941fdb0a3  movaps xmm8, [rsp]
000078d941fdb0a8  add rsp, 0x30
000078d941fdb0ac  vmovaps xmm0, [rsp]
000078d941fdb0b1  vmovaps xmm1, [rsp+0x10]
000078d941fdb0b7  vmovaps xmm2, [rsp+0x20]
000078d941fdb0bd  vmovaps xmm3, [rsp+0x30]
000078d941fdb0c3  vmovaps xmm4, [rsp+0x40]
000078d941fdb0c9  vmovaps xmm5, [rsp+0x50]
000078d941fdb0cf  vmovaps xmm6, [rsp+0x60]
000078d941fdb0d5  vmovaps xmm7, [rsp+0x70]
000078d941fdb0db  vmovaps xmm9, [rsp+0x80]
000078d941fdb0e4  vmovaps xmm10, [rsp+0x90]
000078d941fdb0ed  vmovaps xmm11, [rsp+0xA0]
000078d941fdb0f6  vmovaps xmm12, [rsp+0xB0]
000078d941fdb0ff  vmovaps xmm13, [rsp+0xC0]
000078d941fdb108  vmovaps xmm14, [rsp+0xD0]
000078d941fdb111  vmovaps xmm15, [rsp+0xE0]
000078d941fdb11a  add rsp, 0xF0
000078d941fdb121  pop r11
000078d941fdb123  pop r10
000078d941fdb125  pop r9
000078d941fdb127  pop r8
000078d941fdb129  pop rsi
000078d941fdb12a  pop rdi
000078d941fdb12b  pop rdx
000078d941fdb12c  pop rcx
000078d941fdb12d  pop rax
000078d941fdb12e  add rsp, 0x08
000078d941fdb132  jmp 0x000078D941FD65D4
000078d941fdb137  sub rsp, 0x08
000078d941fdb13b  push rax
000078d941fdb13c  push rcx
000078d941fdb13d  push rdx
000078d941fdb13e  push rdi
000078d941fdb13f  push rsi
000078d941fdb140  push r8
000078d941fdb142  push r9
000078d941fdb144  push r10
000078d941fdb146  push r11
000078d941fdb148  sub rsp, 0xF0
000078d941fdb14f  vmovaps [rsp], xmm0
000078d941fdb154  vmovaps [rsp+0x10], xmm1
000078d941fdb15a  vmovaps [rsp+0x20], xmm2
000078d941fdb160  vmovaps [rsp+0x30], xmm3
000078d941fdb166  vmovaps [rsp+0x40], xmm4
000078d941fdb16c  vmovaps [rsp+0x50], xmm5
000078d941fdb172  vmovaps [rsp+0x60], xmm6
000078d941fdb178  vmovaps [rsp+0x70], xmm8
000078d941fdb17e  vmovaps [rsp+0x80], xmm9
000078d941fdb187  vmovaps [rsp+0x90], xmm10
000078d941fdb190  vmovaps [rsp+0xA0], xmm11
000078d941fdb199  vmovaps [rsp+0xB0], xmm12
000078d941fdb1a2  vmovaps [rsp+0xC0], xmm13
000078d941fdb1ab  vmovaps [rsp+0xD0], xmm14
000078d941fdb1b4  vmovaps [rsp+0xE0], xmm15
000078d941fdb1bd  sub rsp, 0x30
000078d941fdb1c1  movaps [rsp], xmm7
000078d941fdb1c5  movaps [rsp+0x10], xmm9
000078d941fdb1cb  movaps [rsp+0x20], xmm15
000078d941fdb1d1  lea rdi, [rsp]
000078d941fdb1d5  mov esi, 0x00
000078d941fdb1da  mov rax, 0x59BFBFBAA530
000078d941fdb1e4  call rax
000078d941fdb1e6  movaps xmm7, [rsp]
000078d941fdb1ea  add rsp, 0x30
000078d941fdb1ee  vmovaps xmm0, [rsp]
000078d941fdb1f3  vmovaps xmm1, [rsp+0x10]
000078d941fdb1f9  vmovaps xmm2, [rsp+0x20]
000078d941fdb1ff  vmovaps xmm3, [rsp+0x30]
000078d941fdb205  vmovaps xmm4, [rsp+0x40]
000078d941fdb20b  vmovaps xmm5, [rsp+0x50]
000078d941fdb211  vmovaps xmm6, [rsp+0x60]
000078d941fdb217  vmovaps xmm8, [rsp+0x70]
000078d941fdb21d  vmovaps xmm9, [rsp+0x80]
000078d941fdb226  vmovaps xmm10, [rsp+0x90]
000078d941fdb22f  vmovaps xmm11, [rsp+0xA0]
000078d941fdb238  vmovaps xmm12, [rsp+0xB0]
000078d941fdb241  vmovaps xmm13, [rsp+0xC0]
000078d941fdb24a  vmovaps xmm14, [rsp+0xD0]
000078d941fdb253  vmovaps xmm15, [rsp+0xE0]
000078d941fdb25c  add rsp, 0xF0
000078d941fdb263  pop r11
000078d941fdb265  pop r10
000078d941fdb267  pop r9
000078d941fdb269  pop r8
000078d941fdb26b  pop rsi
000078d941fdb26c  pop rdi
000078d941fdb26d  pop rdx
000078d941fdb26e  pop rcx
000078d941fdb26f  pop rax
000078d941fdb270  add rsp, 0x08
000078d941fdb274  jmp 0x000078D941FD6601
000078d941fdb279  sub rsp, 0x08
000078d941fdb27d  push rax
000078d941fdb27e  push rcx
000078d941fdb27f  push rdx
000078d941fdb280  push rdi
000078d941fdb281  push rsi
000078d941fdb282  push r8
000078d941fdb284  push r9
000078d941fdb286  push r10
000078d941fdb288  push r11
000078d941fdb28a  sub rsp, 0xF0
000078d941fdb291  vmovaps [rsp], xmm0
000078d941fdb296  vmovaps [rsp+0x10], xmm1
000078d941fdb29c  vmovaps [rsp+0x20], xmm2
000078d941fdb2a2  vmovaps [rsp+0x30], xmm3
000078d941fdb2a8  vmovaps [rsp+0x40], xmm4
000078d941fdb2ae  vmovaps [rsp+0x50], xmm5
000078d941fdb2b4  vmovaps [rsp+0x60], xmm6
000078d941fdb2ba  vmovaps [rsp+0x70], xmm7
000078d941fdb2c0  vmovaps [rsp+0x80], xmm8
000078d941fdb2c9  vmovaps [rsp+0x90], xmm10
000078d941fdb2d2  vmovaps [rsp+0xA0], xmm11
000078d941fdb2db  vmovaps [rsp+0xB0], xmm12
000078d941fdb2e4  vmovaps [rsp+0xC0], xmm13
000078d941fdb2ed  vmovaps [rsp+0xD0], xmm14
000078d941fdb2f6  vmovaps [rsp+0xE0], xmm15
000078d941fdb2ff  sub rsp, 0x30
000078d941fdb303  movaps [rsp], xmm9
000078d941fdb308  movaps [rsp+0x10], xmm13
000078d941fdb30e  movaps [rsp+0x20], xmm15
000078d941fdb314  lea rdi, [rsp]
000078d941fdb318  mov esi, 0x00
000078d941fdb31d  mov rax, 0x59BFBFBAA530
000078d941fdb327  call rax
000078d941fdb329  movaps xmm9, [rsp]
000078d941fdb32e  add rsp, 0x30
000078d941fdb332  vmovaps xmm0, [rsp]
000078d941fdb337  vmovaps xmm1, [rsp+0x10]
000078d941fdb33d  vmovaps xmm2, [rsp+0x20]
000078d941fdb343  vmovaps xmm3, [rsp+0x30]
000078d941fdb349  vmovaps xmm4, [rsp+0x40]
000078d941fdb34f  vmovaps xmm5, [rsp+0x50]
000078d941fdb355  vmovaps xmm6, [rsp+0x60]
000078d941fdb35b  vmovaps xmm7, [rsp+0x70]
000078d941fdb361  vmovaps xmm8, [rsp+0x80]
000078d941fdb36a  vmovaps xmm10, [rsp+0x90]
000078d941fdb373  vmovaps xmm11, [rsp+0xA0]
000078d941fdb37c  vmovaps xmm12, [rsp+0xB0]
000078d941fdb385  vmovaps xmm13, [rsp+0xC0]
000078d941fdb38e  vmovaps xmm14, [rsp+0xD0]
000078d941fdb397  vmovaps xmm15, [rsp+0xE0]
000078d941fdb3a0  add rsp, 0xF0
000078d941fdb3a7  pop r11
000078d941fdb3a9  pop r10
000078d941fdb3ab  pop r9
000078d941fdb3ad  pop r8
000078d941fdb3af  pop rsi
000078d941fdb3b0  pop rdi
000078d941fdb3b1  pop rdx
000078d941fdb3b2  pop rcx
000078d941fdb3b3  pop rax
000078d941fdb3b4  add rsp, 0x08
000078d941fdb3b8  jmp 0x000078D941FD662F
000078d941fdb3bd  sub rsp, 0x08
000078d941fdb3c1  push rax
000078d941fdb3c2  push rcx
000078d941fdb3c3  push rdx
000078d941fdb3c4  push rdi
000078d941fdb3c5  push rsi
000078d941fdb3c6  push r8
000078d941fdb3c8  push r9
000078d941fdb3ca  push r10
000078d941fdb3cc  push r11
000078d941fdb3ce  sub rsp, 0xF0
000078d941fdb3d5  vmovaps [rsp], xmm0
000078d941fdb3da  vmovaps [rsp+0x10], xmm1
000078d941fdb3e0  vmovaps [rsp+0x20], xmm2
000078d941fdb3e6  vmovaps [rsp+0x30], xmm3
000078d941fdb3ec  vmovaps [rsp+0x40], xmm4
000078d941fdb3f2  vmovaps [rsp+0x50], xmm5
000078d941fdb3f8  vmovaps [rsp+0x60], xmm6
000078d941fdb3fe  vmovaps [rsp+0x70], xmm7
000078d941fdb404  vmovaps [rsp+0x80], xmm8
000078d941fdb40d  vmovaps [rsp+0x90], xmm9
000078d941fdb416  vmovaps [rsp+0xA0], xmm10
000078d941fdb41f  vmovaps [rsp+0xB0], xmm11
000078d941fdb428  vmovaps [rsp+0xC0], xmm12
000078d941fdb431  vmovaps [rsp+0xD0], xmm13
000078d941fdb43a  vmovaps [rsp+0xE0], xmm14
000078d941fdb443  sub rsp, 0x30
000078d941fdb447  movaps [rsp], xmm15
000078d941fdb44c  movaps [rsp+0x10], xmm11
000078d941fdb452  movaps [rsp+0x20], xmm12
000078d941fdb458  lea rdi, [rsp]
000078d941fdb45c  mov esi, 0x00
000078d941fdb461  mov rax, 0x59BFBFBAA530
000078d941fdb46b  call rax
000078d941fdb46d  movaps xmm15, [rsp]
000078d941fdb472  add rsp, 0x30
000078d941fdb476  vmovaps xmm0, [rsp]
000078d941fdb47b  vmovaps xmm1, [rsp+0x10]
000078d941fdb481  vmovaps xmm2, [rsp+0x20]
000078d941fdb487  vmovaps xmm3, [rsp+0x30]
000078d941fdb48d  vmovaps xmm4, [rsp+0x40]
000078d941fdb493  vmovaps xmm5, [rsp+0x50]
000078d941fdb499  vmovaps xmm6, [rsp+0x60]
000078d941fdb49f  vmovaps xmm7, [rsp+0x70]
000078d941fdb4a5  vmovaps xmm8, [rsp+0x80]
000078d941fdb4ae  vmovaps xmm9, [rsp+0x90]
000078d941fdb4b7  vmovaps xmm10, [rsp+0xA0]
000078d941fdb4c0  vmovaps xmm11, [rsp+0xB0]
000078d941fdb4c9  vmovaps xmm12, [rsp+0xC0]
000078d941fdb4d2  vmovaps xmm13, [rsp+0xD0]
000078d941fdb4db  vmovaps xmm14, [rsp+0xE0]
000078d941fdb4e4  add rsp, 0xF0
000078d941fdb4eb  pop r11
000078d941fdb4ed  pop r10
000078d941fdb4ef  pop r9
000078d941fdb4f1  pop r8
000078d941fdb4f3  pop rsi
000078d941fdb4f4  pop rdi
000078d941fdb4f5  pop rdx
000078d941fdb4f6  pop rcx
000078d941fdb4f7  pop rax
000078d941fdb4f8  add rsp, 0x08
000078d941fdb4fc  jmp 0x000078D941FD664A
000078d941fdb501  sub rsp, 0x08
000078d941fdb505  push rax
000078d941fdb506  push rcx
000078d941fdb507  push rdx
000078d941fdb508  push rdi
000078d941fdb509  push rsi
000078d941fdb50a  push r8
000078d941fdb50c  push r9
000078d941fdb50e  push r10
000078d941fdb510  push r11
000078d941fdb512  sub rsp, 0xF0
000078d941fdb519  vmovaps [rsp], xmm0
000078d941fdb51e  vmovaps [rsp+0x10], xmm1
000078d941fdb524  vmovaps [rsp+0x20], xmm2
000078d941fdb52a  vmovaps [rsp+0x30], xmm3
000078d941fdb530  vmovaps [rsp+0x40], xmm4
000078d941fdb536  vmovaps [rsp+0x50], xmm5
000078d941fdb53c  vmovaps [rsp+0x60], xmm6
000078d941fdb542  vmovaps [rsp+0x70], xmm7
000078d941fdb548  vmovaps [rsp+0x80], xmm8
000078d941fdb551  vmovaps [rsp+0x90], xmm9
000078d941fdb55a  vmovaps [rsp+0xA0], xmm10
000078d941fdb563  vmovaps [rsp+0xB0], xmm11
000078d941fdb56c  vmovaps [rsp+0xC0], xmm12
000078d941fdb575  vmovaps [rsp+0xD0], xmm14
000078d941fdb57e  vmovaps [rsp+0xE0], xmm15
000078d941fdb587  sub rsp, 0x30
000078d941fdb58b  movaps [rsp], xmm13
000078d941fdb590  movaps [rsp+0x10], xmm10
000078d941fdb596  movaps [rsp+0x20], xmm14
000078d941fdb59c  lea rdi, [rsp]
000078d941fdb5a0  mov esi, 0x00
000078d941fdb5a5  mov rax, 0x59BFBFBAA530
000078d941fdb5af  call rax
000078d941fdb5b1  movaps xmm13, [rsp]
000078d941fdb5b6  add rsp, 0x30
000078d941fdb5ba  vmovaps xmm0, [rsp]
000078d941fdb5bf  vmovaps xmm1, [rsp+0x10]
000078d941fdb5c5  vmovaps xmm2, [rsp+0x20]
000078d941fdb5cb  vmovaps xmm3, [rsp+0x30]
000078d941fdb5d1  vmovaps xmm4, [rsp+0x40]
000078d941fdb5d7  vmovaps xmm5, [rsp+0x50]
000078d941fdb5dd  vmovaps xmm6, [rsp+0x60]
000078d941fdb5e3  vmovaps xmm7, [rsp+0x70]
000078d941fdb5e9  vmovaps xmm8, [rsp+0x80]
000078d941fdb5f2  vmovaps xmm9, [rsp+0x90]
000078d941fdb5fb  vmovaps xmm10, [rsp+0xA0]
000078d941fdb604  vmovaps xmm11, [rsp+0xB0]
000078d941fdb60d  vmovaps xmm12, [rsp+0xC0]
000078d941fdb616  vmovaps xmm14, [rsp+0xD0]
000078d941fdb61f  vmovaps xmm15, [rsp+0xE0]
000078d941fdb628  add rsp, 0xF0
000078d941fdb62f  pop r11
000078d941fdb631  pop r10
000078d941fdb633  pop r9
000078d941fdb635  pop r8
000078d941fdb637  pop rsi
000078d941fdb638  pop rdi
000078d941fdb639  pop rdx
000078d941fdb63a  pop rcx
000078d941fdb63b  pop rax
000078d941fdb63c  add rsp, 0x08
000078d941fdb640  jmp 0x000078D941FD666D
000078d941fdb645  sub rsp, 0x08
000078d941fdb649  push rax
000078d941fdb64a  push rcx
000078d941fdb64b  push rdx
000078d941fdb64c  push rdi
000078d941fdb64d  push rsi
000078d941fdb64e  push r8
000078d941fdb650  push r9
000078d941fdb652  push r10
000078d941fdb654  push r11
000078d941fdb656  sub rsp, 0xF0
000078d941fdb65d  vmovaps [rsp], xmm0
000078d941fdb662  vmovaps [rsp+0x10], xmm1
000078d941fdb668  vmovaps [rsp+0x20], xmm2
000078d941fdb66e  vmovaps [rsp+0x30], xmm3
000078d941fdb674  vmovaps [rsp+0x40], xmm4
000078d941fdb67a  vmovaps [rsp+0x50], xmm5
000078d941fdb680  vmovaps [rsp+0x60], xmm6
000078d941fdb686  vmovaps [rsp+0x70], xmm7
000078d941fdb68c  vmovaps [rsp+0x80], xmm8
000078d941fdb695  vmovaps [rsp+0x90], xmm9
000078d941fdb69e  vmovaps [rsp+0xA0], xmm10
000078d941fdb6a7  vmovaps [rsp+0xB0], xmm11
000078d941fdb6b0  vmovaps [rsp+0xC0], xmm12
000078d941fdb6b9  vmovaps [rsp+0xD0], xmm13
000078d941fdb6c2  vmovaps [rsp+0xE0], xmm15
000078d941fdb6cb  sub rsp, 0x30
000078d941fdb6cf  movaps [rsp], xmm14
000078d941fdb6d4  movaps [rsp+0x10], xmm1
000078d941fdb6d9  movaps [rsp+0x20], xmm7
000078d941fdb6de  lea rdi, [rsp]
000078d941fdb6e2  mov esi, 0x00
000078d941fdb6e7  mov rax, 0x59BFBFBAA530
000078d941fdb6f1  call rax
000078d941fdb6f3  movaps xmm14, [rsp]
000078d941fdb6f8  add rsp, 0x30
000078d941fdb6fc  vmovaps xmm0, [rsp]
000078d941fdb701  vmovaps xmm1, [rsp+0x10]
000078d941fdb707  vmovaps xmm2, [rsp+0x20]
000078d941fdb70d  vmovaps xmm3, [rsp+0x30]
000078d941fdb713  vmovaps xmm4, [rsp+0x40]
000078d941fdb719  vmovaps xmm5, [rsp+0x50]
000078d941fdb71f  vmovaps xmm6, [rsp+0x60]
000078d941fdb725  vmovaps xmm7, [rsp+0x70]
000078d941fdb72b  vmovaps xmm8, [rsp+0x80]
000078d941fdb734  vmovaps xmm9, [rsp+0x90]
000078d941fdb73d  vmovaps xmm10, [rsp+0xA0]
000078d941fdb746  vmovaps xmm11, [rsp+0xB0]
000078d941fdb74f  vmovaps xmm12, [rsp+0xC0]
000078d941fdb758  vmovaps xmm13, [rsp+0xD0]
000078d941fdb761  vmovaps xmm15, [rsp+0xE0]
000078d941fdb76a  add rsp, 0xF0
000078d941fdb771  pop r11
000078d941fdb773  pop r10
000078d941fdb775  pop r9
000078d941fdb777  pop r8
000078d941fdb779  pop rsi
000078d941fdb77a  pop rdi
000078d941fdb77b  pop rdx
000078d941fdb77c  pop rcx
000078d941fdb77d  pop rax
000078d941fdb77e  add rsp, 0x08
000078d941fdb782  jmp 0x000078D941FD6690
000078d941fdb787  sub rsp, 0x08
000078d941fdb78b  push rax
000078d941fdb78c  push rcx
000078d941fdb78d  push rdx
000078d941fdb78e  push rdi
000078d941fdb78f  push rsi
000078d941fdb790  push r8
000078d941fdb792  push r9
000078d941fdb794  push r10
000078d941fdb796  push r11
000078d941fdb798  sub rsp, 0xF0
000078d941fdb79f  vmovaps [rsp], xmm0
000078d941fdb7a4  vmovaps [rsp+0x10], xmm2
000078d941fdb7aa  vmovaps [rsp+0x20], xmm3
000078d941fdb7b0  vmovaps [rsp+0x30], xmm4
000078d941fdb7b6  vmovaps [rsp+0x40], xmm5
000078d941fdb7bc  vmovaps [rsp+0x50], xmm6
000078d941fdb7c2  vmovaps [rsp+0x60], xmm7
000078d941fdb7c8  vmovaps [rsp+0x70], xmm8
000078d941fdb7ce  vmovaps [rsp+0x80], xmm9
000078d941fdb7d7  vmovaps [rsp+0x90], xmm10
000078d941fdb7e0  vmovaps [rsp+0xA0], xmm11
000078d941fdb7e9  vmovaps [rsp+0xB0], xmm12
000078d941fdb7f2  vmovaps [rsp+0xC0], xmm13
000078d941fdb7fb  vmovaps [rsp+0xD0], xmm14
000078d941fdb804  vmovaps [rsp+0xE0], xmm15
000078d941fdb80d  sub rsp, 0x30
000078d941fdb811  movaps [rsp], xmm1
000078d941fdb815  movaps [rsp+0x10], xmm8
000078d941fdb81b  movaps [rsp+0x20], xmm9
000078d941fdb821  lea rdi, [rsp]
000078d941fdb825  mov esi, 0x00
000078d941fdb82a  mov rax, 0x59BFBFBAA530
000078d941fdb834  call rax
000078d941fdb836  movaps xmm1, [rsp]
000078d941fdb83a  add rsp, 0x30
000078d941fdb83e  vmovaps xmm0, [rsp]
000078d941fdb843  vmovaps xmm2, [rsp+0x10]
000078d941fdb849  vmovaps xmm3, [rsp+0x20]
000078d941fdb84f  vmovaps xmm4, [rsp+0x30]
000078d941fdb855  vmovaps xmm5, [rsp+0x40]
000078d941fdb85b  vmovaps xmm6, [rsp+0x50]
000078d941fdb861  vmovaps xmm7, [rsp+0x60]
000078d941fdb867  vmovaps xmm8, [rsp+0x70]
000078d941fdb86d  vmovaps xmm9, [rsp+0x80]
000078d941fdb876  vmovaps xmm10, [rsp+0x90]
000078d941fdb87f  vmovaps xmm11, [rsp+0xA0]
000078d941fdb888  vmovaps xmm12, [rsp+0xB0]
000078d941fdb891  vmovaps xmm13, [rsp+0xC0]
000078d941fdb89a  vmovaps xmm14, [rsp+0xD0]
000078d941fdb8a3  vmovaps xmm15, [rsp+0xE0]
000078d941fdb8ac  add rsp, 0xF0
000078d941fdb8b3  pop r11
000078d941fdb8b5  pop r10
000078d941fdb8b7  pop r9
000078d941fdb8b9  pop r8
000078d941fdb8bb  pop rsi
000078d941fdb8bc  pop rdi
000078d941fdb8bd  pop rdx
000078d941fdb8be  pop rcx
000078d941fdb8bf  pop rax
000078d941fdb8c0  add rsp, 0x08
000078d941fdb8c4  jmp 0x000078D941FD66B2
000078d941fdb8c9  call 0x000078D941EB3E40
000078d941fdb8ce  jmp 0x000078D941FD66C0
000078d941fdb8d3  call 0x000078D941E0C380
000078d941fdb8d8  jmp 0x000078D941FD66CA
000078d941fdb8dd  call 0x000078D941E0D600
000078d941fdb8e2  jmp 0x000078D941FD66D4
000078d941fdb8e7  call 0x000078D941DFF540
000078d941fdb8ec  jmp 0x000078D941FD66DE
000078d941fdb8f1  int3
000078d941fdb8f2  nop [rax+rax*1], ax
000078d941fdb8fb  nop [rax+rax*1], eax
000078d941fdb900  mov eax, [r15+0x48]
000078d941fdb904  lea r14d, [eax+0x01]
000078d941fdb909  mov [rsp+0x10], r14d
000078d941fdb90e  mov r14d, r14d
000078d941fdb911  mov [r15+0x48], r14
000078d941fdb915  xor eax, eax
000078d941fdb917  mov r14d, [rsp+0x10]
000078d941fdb91c  cmp r14d, 0x1F4
000078d941fdb923  cmc
000078d941fdb924  lahf
000078d941fdb925  seto al
000078d941fdb928  mov [r15+0x108], eax
000078d941fdb92f  mov eax, [r15+0x108]
000078d941fdb936  sahf
000078d941fdb937  jnz 0x000078D941FDB969
000078d941fdb939  cmp dword ptr [r15+0x318], 0x00
000078d941fdb941  jz 0x000078D941FE1AB0
000078d941fdb947  nop [rax+rax*1], ax
000078d941fdb950  nop [rax+rax*1], eax
000078d941fdb958  mov eax, 0x410450
000078d941fdb95d  mov [r15+0x100], rax
000078d941fdb964  jmp 0x000078D941DFE110
000078d941fdb969  cmp dword ptr [r15+0x318], 0x00
000078d941fdb971  jz 0x000078D941FDB9A0
000078d941fdb977  nop [rax+rax*1], ax
000078d941fdb980  nop [rax+rax*1], eax
000078d941fdb988  mov eax, 0x410274
000078d941fdb98d  mov [r15+0x100], rax
000078d941fdb994  jmp 0x000078D941DFE110
000078d941fdb999  int3
000078d941fdb99a  int3
000078d941fdb99b  nop [rax+rax*1], eax
000078d941fdb9a0  mov rax, [r15+0x40]
000078d941fdb9a4  movaps xmm1, [r15+0x1D0]
000078d941fdb9ac  vmovaps [rsp+0x10], xmm1
000078d941fdb9b2  vmovaps xmm15, [rsp+0x10]
000078d941fdb9b8  por xmm1, xmm15
000078d941fdb9bd  movaps xmm14, [r15+0x1A0]
000078d941fdb9c5  vmovaps [rsp+0x10], xmm14
000078d941fdb9cb  vmovaps xmm13, [rsp+0x10]
000078d941fdb9d1  por xmm14, xmm13
000078d941fdb9d6  lea r14, [rax+0x30]
000078d941fdb9da  mov r12, [r13+r14*1]
000078d941fdb9df  lea r14, [rax+0x38]
000078d941fdb9e3  mov r11, [r13+r14*1]
000078d941fdb9e8  movq xmm13, r12
000078d941fdb9ed  movq xmm12, r11
000078d941fdb9f2  movq xmm13, xmm13
000078d941fdb9f7  vmovaps [rsp+0x10], xmm13
000078d941fdb9fd  movq xmm13, xmm13
000078d941fdba02  movaps [r15+0x130], xmm13
000078d941fdba0a  movq xmm12, xmm12
000078d941fdba0f  vmovaps [rsp+0x20], xmm12
000078d941fdba15  movq xmm12, xmm12
000078d941fdba1a  movaps [r15+0x280], xmm12
000078d941fdba22  movaps xmm13, [r15+0x270]
000078d941fdba2a  vmovaps [rsp+0x30], xmm13
000078d941fdba30  vmovaps xmm12, [rsp+0x30]
000078d941fdba36  por xmm13, xmm12
000078d941fdba3b  lea r14, [rax+0x20]
000078d941fdba3f  mov r12, [r13+r14*1]
000078d941fdba44  lea r14, [rax+0x28]
000078d941fdba48  mov r11, [r13+r14*1]
000078d941fdba4d  movq xmm12, r12
000078d941fdba52  movq xmm11, r11
000078d941fdba57  movq xmm12, xmm12
000078d941fdba5c  vmovaps [rsp+0x30], xmm12
000078d941fdba62  movq xmm12, xmm12
000078d941fdba67  movaps [r15+0x150], xmm12
000078d941fdba6f  movq xmm11, xmm11
000078d941fdba74  vmovaps [rsp+0x40], xmm11
000078d941fdba7a  movq xmm11, xmm11
000078d941fdba7f  movaps [r15+0x140], xmm11
000078d941fdba87  lea r14, [rax+0x10]
000078d941fdba8b  mov r12, [r13+r14*1]
000078d941fdba90  lea r14, [rax+0x18]
000078d941fdba94  mov r11, [r13+r14*1]
000078d941fdba99  movq xmm12, r12
000078d941fdba9e  movq xmm11, r11
000078d941fdbaa3  movq xmm12, xmm12
000078d941fdbaa8  vmovaps [rsp+0x50], xmm12
000078d941fdbaae  movq xmm12, xmm12
000078d941fdbab3  movaps [r15+0x170], xmm12
000078d941fdbabb  movq xmm11, xmm11
000078d941fdbac0  vmovaps [rsp+0x60], xmm11
000078d941fdbac6  movq xmm11, xmm11
000078d941fdbacb  movaps [r15+0x160], xmm11
000078d941fdbad3  mov r14, [r13+rax*1]
000078d941fdbad8  vmovq xmm12, r14
000078d941fdbadd  vpbroadcastq xmm12, xmm12
000078d941fdbae2  lea r14, [rax+0x08]
000078d941fdbae6  mov rax, [r13+r14*1]
000078d941fdbaeb  movq xmm11, rax
000078d941fdbaf0  movaps [r15+0x230], xmm11
000078d941fdbaf8  mov rax, [r15+0xF8]
000078d941fdbaff  lea r14, [rax+0x50]
000078d941fdbb03  movups xmm11, [r13+r14*1]
000078d941fdbb09  lea r14, [rax+0x60]
000078d941fdbb0d  movups xmm10, [r13+r14*1]
000078d941fdbb13  lea r14, [rax+0x30]
000078d941fdbb17  movups xmm9, [r13+r14*1]
000078d941fdbb1d  mov r14, [r15+0x50]
000078d941fdbb21  mov [r15+0x60], r14
000078d941fdbb25  mov qword ptr [r15+0x58], 0x40
000078d941fdbb2d  movaps xmm8, xmm12
000078d941fdbb31  mulpd xmm8, xmm15
000078d941fdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000078d941fdbb3c  ptest xmm7, xmm7
000078d941fdbb41  jnz 0x000078D941FDC96A
000078d941fdbb47  movq xmm15, qword ptr [r15+0x230]
000078d941fdbb50  vmovaps [rsp+0x70], xmm15
000078d941fdbb56  vpermilpd xmm15, xmm15, 0x00
000078d941fdbb5c  movaps xmm7, xmm9
000078d941fdbb60  mulpd xmm7, xmm15
000078d941fdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000078d941fdbb6a  ptest xmm6, xmm6
000078d941fdbb6f  jnz 0x000078D941FDCAAE
000078d941fdbb75  vxorps xmm15, xmm15, xmm15
000078d941fdbb7a  vpbroadcastq xmm15, xmm15
000078d941fdbb7f  movaps xmm9, xmm12
000078d941fdbb83  mulpd xmm9, xmm10
000078d941fdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000078d941fdbb8e  ptest xmm6, xmm6
000078d941fdbb93  jnz 0x000078D941FDCBF0
000078d941fdbb99  movaps xmm10, xmm12
000078d941fdbb9d  mulpd xmm10, xmm11
000078d941fdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000078d941fdbba8  ptest xmm6, xmm6
000078d941fdbbad  jnz 0x000078D941FDCD34
000078d941fdbbb3  movaps xmm11, [r15+0x1F0]
000078d941fdbbbb  movaps xmm6, xmm12
000078d941fdbbbf  mulpd xmm6, xmm11
000078d941fdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000078d941fdbbc9  ptest xmm5, xmm5
000078d941fdbbce  jnz 0x000078D941FDCE78
000078d941fdbbd4  movaps xmm12, [r15+0x2A0]
000078d941fdbbdc  vmovaps [rsp+0x80], xmm12
000078d941fdbbe5  vmovaps xmm11, [rsp+0x80]
000078d941fdbbee  por xmm12, xmm11
000078d941fdbbf3  movaps xmm11, [r15+0x250]
000078d941fdbbfb  vmovaps [rsp+0x80], xmm11
000078d941fdbc04  vmovaps xmm5, [rsp+0x80]
000078d941fdbc0d  por xmm11, xmm5
000078d941fdbc12  vmovaps xmm4, [rsp+0x70]
000078d941fdbc18  vpermilpd xmm4, xmm4, 0x00
000078d941fdbc1e  movaps xmm3, xmm5
000078d941fdbc21  mulpd xmm3, xmm4
000078d941fdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000078d941fdbc2a  ptest xmm2, xmm2
000078d941fdbc2f  jnz 0x000078D941FDCFBA
000078d941fdbc35  mov [rsp+0x80], rax
000078d941fdbc3d  xor eax, eax
000078d941fdbc3f  mov r12d, 0x40
000078d941fdbc45  mov r11d, 0x200
000078d941fdbc4b  cmp r12, r11
000078d941fdbc4e  cmc
000078d941fdbc4f  lahf
000078d941fdbc50  seto al
000078d941fdbc53  mov [r15+0x108], eax
000078d941fdbc5a  movaps xmm5, xmm8
000078d941fdbc5e  addpd xmm5, xmm15
000078d941fdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000078d941fdbc68  ptest xmm4, xmm4
000078d941fdbc6d  jnz 0x000078D941FDD0FA
000078d941fdbc73  movaps xmm8, [r15+0x1B0]
000078d941fdbc7b  movaps xmm4, xmm9
000078d941fdbc7f  addpd xmm4, xmm8
000078d941fdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000078d941fdbc89  ptest xmm2, xmm2
000078d941fdbc8e  jnz 0x000078D941FDD23C
000078d941fdbc94  movaps xmm9, xmm10
000078d941fdbc98  addpd xmm9, xmm8
000078d941fdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000078d941fdbca3  ptest xmm2, xmm2
000078d941fdbca8  jnz 0x000078D941FDD37E
000078d941fdbcae  movaps xmm10, [r15+0x2F0]
000078d941fdbcb6  vmovaps [rsp+0x90], xmm10
000078d941fdbcbf  vmovaps xmm8, [rsp+0x90]
000078d941fdbcc8  por xmm10, xmm8
000078d941fdbccd  movaps xmm8, [r15+0x2E0]
000078d941fdbcd5  vmovaps [rsp+0x90], xmm8
000078d941fdbcde  vmovaps xmm2, [rsp+0x90]
000078d941fdbce7  por xmm8, xmm2
000078d941fdbcec  movaps xmm2, [r15+0x2D0]
000078d941fdbcf4  vmovaps [rsp+0x90], xmm2
000078d941fdbcfd  vmovaps [rsp+0xA0], xmm1
000078d941fdbd06  vmovaps xmm1, [rsp+0x90]
000078d941fdbd0f  por xmm2, xmm1
000078d941fdbd13  movaps xmm1, [r15+0x200]
000078d941fdbd1b  vmovaps [rsp+0x90], xmm1
000078d941fdbd24  vmovaps [rsp+0xB0], xmm15
000078d941fdbd2d  vmovaps xmm15, [rsp+0x90]
000078d941fdbd36  por xmm1, xmm15
000078d941fdbd3b  movaps xmm15, [r15+0x1C0]
000078d941fdbd43  vmovaps [rsp+0x90], xmm15
000078d941fdbd4c  vmovaps [rsp+0xC0], xmm1
000078d941fdbd55  vmovaps xmm1, [rsp+0x90]
000078d941fdbd5e  por xmm15, xmm1
000078d941fdbd63  movaps xmm1, [r15+0x190]
000078d941fdbd6b  vmovaps [rsp+0x90], xmm1
000078d941fdbd74  vmovaps [rsp+0xD0], xmm15
000078d941fdbd7d  vmovaps xmm15, [rsp+0x90]
000078d941fdbd86  por xmm1, xmm15
000078d941fdbd8b  movaps xmm15, [r15+0x300]
000078d941fdbd93  vmovaps [rsp+0x90], xmm15
000078d941fdbd9c  vmovaps [rsp+0xE0], xmm1
000078d941fdbda5  vmovaps xmm1, [rsp+0x90]
000078d941fdbdae  por xmm15, xmm1
000078d941fdbdb3  mov rax, [rsp+0x80]
000078d941fdbdbb  lea r12, [rax+0xA0]
000078d941fdbdc2  movups xmm1, [r13+r12*1]
000078d941fdbdc8  lea r12, [rax+0xB0]
000078d941fdbdcf  vmovaps [rsp+0x80], xmm1
000078d941fdbdd8  movups xmm1, [r13+r12*1]
000078d941fdbdde  vmovaps [rsp+0x90], xmm1
000078d941fdbde7  vmovaps [rsp+0xF0], xmm15
000078d941fdbdf0  vmovaps xmm15, [rsp+0xB0]
000078d941fdbdf9  vmovaps [rsp+0xB0], xmm14
000078d941fdbe02  movaps xmm1, xmm6
000078d941fdbe05  addpd xmm1, xmm15
000078d941fdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000078d941fdbe0f  ptest xmm14, xmm14
000078d941fdbe15  jnz 0x000078D941FDD4D6
000078d941fdbe1b  lea r12, [rax+0xF0]
000078d941fdbe22  movups xmm15, [r13+r12*1]
000078d941fdbe28  movaps xmm14, xmm4
000078d941fdbe2c  addpd xmm14, xmm3
000078d941fdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000078d941fdbe37  ptest xmm6, xmm6
000078d941fdbe3c  jnz 0x000078D941FDD621
000078d941fdbe42  movaps xmm6, xmm9
000078d941fdbe46  addpd xmm6, xmm7
000078d941fdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000078d941fdbe4f  ptest xmm4, xmm4
000078d941fdbe54  jnz 0x000078D941FDD763
000078d941fdbe5a  vmovaps xmm9, [rsp+0x70]
000078d941fdbe60  vpermilpd xmm9, xmm9, 0x00
000078d941fdbe66  vmovaps xmm4, [rsp+0x90]
000078d941fdbe6f  movaps xmm7, xmm4
000078d941fdbe72  mulpd xmm7, xmm9
000078d941fdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000078d941fdbe7c  ptest xmm3, xmm3
000078d941fdbe81  jnz 0x000078D941FDD8A4
000078d941fdbe87  vmovaps xmm9, [rsp+0x50]
000078d941fdbe8d  vpermilpd xmm9, xmm9, 0x00
000078d941fdbe93  movaps xmm4, xmm15
000078d941fdbe97  mulpd xmm4, xmm9
000078d941fdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000078d941fdbea1  ptest xmm3, xmm3
000078d941fdbea6  jnz 0x000078D941FDD9E5
000078d941fdbeac  lea r12, [rax+0xE0]
000078d941fdbeb3  movups xmm15, [r13+r12*1]
000078d941fdbeb9  vmovaps xmm9, [rsp+0x70]
000078d941fdbebf  vpermilpd xmm9, xmm9, 0x00
000078d941fdbec5  vmovaps [rsp+0x70], xmm1
000078d941fdbecb  vmovaps xmm1, [rsp+0x80]
000078d941fdbed4  vmovaps [rsp+0x80], xmm15
000078d941fdbedd  movaps xmm3, xmm1
000078d941fdbee0  mulpd xmm3, xmm9
000078d941fdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000078d941fdbeea  ptest xmm15, xmm15
000078d941fdbef0  jnz 0x000078D941FDDB31
000078d941fdbef6  vmovaps xmm1, [rsp+0xF0]
000078d941fdbeff  vmovaps xmm15, [rsp+0xF0]
000078d941fdbf08  por xmm1, xmm15
000078d941fdbf0d  movaps [r15+0x300], xmm1
000078d941fdbf15  vmovaps xmm15, [rsp+0xE0]
000078d941fdbf1e  vmovaps xmm9, [rsp+0xE0]
000078d941fdbf27  por xmm15, xmm9
000078d941fdbf2c  movaps [r15+0x190], xmm15
000078d941fdbf34  vmovaps xmm9, [rsp+0x50]
000078d941fdbf3a  vpermilpd xmm9, xmm9, 0x00
000078d941fdbf40  vmovaps [rsp+0x90], xmm1
000078d941fdbf49  vmovaps [rsp+0xE0], xmm15
000078d941fdbf52  vmovaps xmm15, [rsp+0x80]
000078d941fdbf5b  vmovaps [rsp+0x80], xmm14
000078d941fdbf64  movaps xmm1, xmm15
000078d941fdbf68  mulpd xmm1, xmm9
000078d941fdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000078d941fdbf72  ptest xmm14, xmm14
000078d941fdbf78  jnz 0x000078D941FDDC72
000078d941fdbf7e  lea r12, [rax+0x90]
000078d941fdbf85  movups xmm15, [r13+r12*1]
000078d941fdbf8b  vmovaps xmm14, [rsp+0xD0]
000078d941fdbf94  vmovaps xmm9, [rsp+0xD0]
000078d941fdbf9d  por xmm14, xmm9
000078d941fdbfa2  movaps [r15+0x1C0], xmm14
000078d941fdbfaa  vmovaps xmm9, [rsp+0xC0]
000078d941fdbfb3  vmovaps [rsp+0xD0], xmm1
000078d941fdbfbc  vmovaps xmm1, [rsp+0xC0]
000078d941fdbfc5  por xmm9, xmm1
000078d941fdbfca  movaps [r15+0x200], xmm9
000078d941fdbfd2  vmovaps [rsp+0xC0], xmm2
000078d941fdbfdb  vmovaps xmm1, [rsp+0xC0]
000078d941fdbfe4  por xmm2, xmm1
000078d941fdbfe8  movaps [r15+0x2D0], xmm2
000078d941fdbff0  vmovaps [rsp+0xC0], xmm8
000078d941fdbff9  vmovaps xmm1, [rsp+0xC0]
000078d941fdc002  por xmm8, xmm1
000078d941fdc007  movaps [r15+0x2E0], xmm8
000078d941fdc00f  vmovaps [rsp+0xC0], xmm15
000078d941fdc018  movaps xmm1, xmm5
000078d941fdc01b  addpd xmm1, xmm7
000078d941fdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000078d941fdc024  ptest xmm15, xmm15
000078d941fdc02a  jnz 0x000078D941FDDDBE
000078d941fdc030  vmovaps xmm15, [rsp+0x50]
000078d941fdc036  vpermilpd xmm15, xmm15, 0x00
000078d941fdc03c  vmovaps xmm5, [rsp+0xC0]
000078d941fdc045  vmovaps [rsp+0xC0], xmm1
000078d941fdc04e  movaps xmm7, xmm5
000078d941fdc051  mulpd xmm7, xmm15
000078d941fdc056  vcmppd xmm1, xmm7, xmm7, 0x03
000078d941fdc05b  ptest xmm1, xmm1
000078d941fdc060  jnz 0x000078D941FDDEFE
000078d941fdc066  lea r12, [rax+0x80]
000078d941fdc06d  movups xmm1, [r13+r12*1]
000078d941fdc073  vmovaps xmm5, [rsp+0x70]
000078d941fdc079  vmovaps [rsp+0x70], xmm1
000078d941fdc07f  movaps xmm15, xmm5
000078d941fdc083  addpd xmm15, xmm3
000078d941fdc088  vcmppd xmm1, xmm15, xmm15, 0x03
000078d941fdc08e  ptest xmm1, xmm1
000078d941fdc093  jnz 0x000078D941FDE049
000078d941fdc099  vmovaps xmm5, [rsp+0x80]
000078d941fdc0a2  movaps xmm1, xmm5
000078d941fdc0a5  addpd xmm1, xmm4
000078d941fdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000078d941fdc0ae  ptest xmm3, xmm3
000078d941fdc0b3  jnz 0x000078D941FDE18B
000078d941fdc0b9  vmovaps [rsp+0x80], xmm10
000078d941fdc0c2  vmovaps xmm5, [rsp+0x80]
000078d941fdc0cb  por xmm10, xmm5
000078d941fdc0d0  movaps [r15+0x2F0], xmm10
000078d941fdc0d8  vmovaps xmm5, [rsp+0x50]
000078d941fdc0de  vpermilpd xmm5, xmm5, 0x00
000078d941fdc0e4  vmovaps xmm3, [rsp+0x70]
000078d941fdc0ea  vmovaps [rsp+0x50], xmm1
000078d941fdc0f0  movaps xmm4, xmm3
000078d941fdc0f3  mulpd xmm4, xmm5
000078d941fdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000078d941fdc0fc  ptest xmm1, xmm1
000078d941fdc101  jnz 0x000078D941FDE2CB
000078d941fdc107  lea r12, [rax+0xD0]
000078d941fdc10e  movups xmm1, [r13+r12*1]
000078d941fdc114  vmovaps xmm3, [rsp+0xD0]
000078d941fdc11d  vmovaps [rsp+0x70], xmm1
000078d941fdc123  movaps xmm5, xmm6
000078d941fdc126  addpd xmm5, xmm3
000078d941fdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000078d941fdc12f  ptest xmm1, xmm1
000078d941fdc134  jnz 0x000078D941FDE415
000078d941fdc13a  vmovaps xmm1, [rsp+0x60]
000078d941fdc140  vpermilpd xmm1, xmm1, 0x00
000078d941fdc146  movaps xmm6, xmm9
000078d941fdc14a  mulpd xmm6, xmm1
000078d941fdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000078d941fdc153  ptest xmm3, xmm3
000078d941fdc158  jnz 0x000078D941FDE555
000078d941fdc15e  movaps [r15+0x260], xmm6
000078d941fdc166  vxorps xmm1, xmm1, xmm1
000078d941fdc16a  vpbroadcastq xmm1, xmm1
000078d941fdc16f  movaps [r15+0x1B0], xmm1
000078d941fdc177  vmovaps xmm1, [rsp+0x60]
000078d941fdc17d  vpermilpd xmm1, xmm1, 0x00
000078d941fdc183  vmovaps xmm3, [rsp+0x70]
000078d941fdc189  vmovaps [rsp+0x70], xmm15
000078d941fdc18f  movaps xmm9, xmm3
000078d941fdc193  mulpd xmm9, xmm1
000078d941fdc198  vcmppd xmm15, xmm9, xmm9, 0x03
000078d941fdc19e  ptest xmm15, xmm15
000078d941fdc1a4  jnz 0x000078D941FDE696
000078d941fdc1aa  lea r12, [rax+0xC0]
000078d941fdc1b1  movups xmm1, [r13+r12*1]
000078d941fdc1b7  vmovaps xmm3, [rsp+0xC0]
000078d941fdc1c0  vmovaps [rsp+0x80], xmm1
000078d941fdc1c9  movaps xmm15, xmm3
000078d941fdc1cd  addpd xmm15, xmm7
000078d941fdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000078d941fdc1d8  ptest xmm1, xmm1
000078d941fdc1dd  jnz 0x000078D941FDE7E2
000078d941fdc1e3  vmovaps [rsp+0xC0], xmm13
000078d941fdc1ec  vmovaps xmm1, [rsp+0xC0]
000078d941fdc1f5  por xmm13, xmm1
000078d941fdc1fa  movaps [r15+0x270], xmm13
000078d941fdc202  vmovaps xmm1, [rsp+0xB0]
000078d941fdc20b  vmovaps xmm7, [rsp+0xB0]
000078d941fdc214  por xmm1, xmm7
000078d941fdc218  movaps [r15+0x1A0], xmm1
000078d941fdc220  vmovaps xmm1, [rsp+0x60]
000078d941fdc226  vpermilpd xmm1, xmm1, 0x00
000078d941fdc22c  vmovaps [rsp+0xB0], xmm1
000078d941fdc235  vmovaps xmm1, [rsp+0x80]
000078d941fdc23e  vmovaps [rsp+0x80], xmm15
000078d941fdc247  vmovaps xmm15, [rsp+0xB0]
000078d941fdc250  vmovaps [rsp+0xB0], xmm14
000078d941fdc259  movaps xmm3, xmm1
000078d941fdc25c  mulpd xmm3, xmm15
000078d941fdc261  vcmppd xmm14, xmm3, xmm3, 0x03
000078d941fdc266  ptest xmm14, xmm14
000078d941fdc26c  jnz 0x000078D941FDE924
000078d941fdc272  lea r12, [rax+0x20]
000078d941fdc276  movups xmm1, [r13+r12*1]
000078d941fdc27c  movaps [r15+0x110], xmm1
000078d941fdc284  vmovaps xmm14, [rsp+0x70]
000078d941fdc28a  vmovaps [rsp+0x70], xmm1
000078d941fdc290  movaps xmm15, xmm14
000078d941fdc294  addpd xmm15, xmm4
000078d941fdc299  vcmppd xmm1, xmm15, xmm15, 0x03
000078d941fdc29f  ptest xmm1, xmm1
000078d941fdc2a4  jnz 0x000078D941FDEA6F
000078d941fdc2aa  vmovaps xmm1, [rsp+0x60]
000078d941fdc2b0  vpermilpd xmm1, xmm1, 0x00
000078d941fdc2b6  movaps xmm14, xmm2
000078d941fdc2ba  mulpd xmm14, xmm1
000078d941fdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000078d941fdc2c5  ptest xmm4, xmm4
000078d941fdc2ca  jnz 0x000078D941FDEBB2
000078d941fdc2d0  vmovaps xmm4, [rsp+0x50]
000078d941fdc2d6  movaps xmm1, xmm4
000078d941fdc2d9  addpd xmm1, xmm9
000078d941fdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000078d941fdc2e3  ptest xmm2, xmm2
000078d941fdc2e8  jnz 0x000078D941FDECF4
000078d941fdc2ee  vmovaps xmm9, [rsp+0x30]
000078d941fdc2f4  vpermilpd xmm9, xmm9, 0x00
000078d941fdc2fa  vmovaps xmm2, [rsp+0x70]
000078d941fdc300  vmovaps [rsp+0x50], xmm1
000078d941fdc306  movaps xmm4, xmm2
000078d941fdc309  mulpd xmm4, xmm9
000078d941fdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000078d941fdc313  ptest xmm1, xmm1
000078d941fdc318  jnz 0x000078D941FDEE35
000078d941fdc31e  vmovaps xmm1, [rsp+0x30]
000078d941fdc324  vpermilpd xmm1, xmm1, 0x00
000078d941fdc32a  vmovaps xmm2, [rsp+0x90]
000078d941fdc333  vmovaps [rsp+0x60], xmm15
000078d941fdc339  movaps xmm9, xmm2
000078d941fdc33d  mulpd xmm9, xmm1
000078d941fdc342  vcmppd xmm15, xmm9, xmm9, 0x03
000078d941fdc348  ptest xmm15, xmm15
000078d941fdc34e  jnz 0x000078D941FDEF76
000078d941fdc354  vmovaps xmm15, [rsp+0x80]
000078d941fdc35d  movaps xmm1, xmm15
000078d941fdc361  addpd xmm1, xmm6
000078d941fdc365  vcmppd xmm2, xmm1, xmm1, 0x03
000078d941fdc36a  ptest xmm2, xmm2
000078d941fdc36f  jnz 0x000078D941FDF0B8
000078d941fdc375  movaps xmm15, xmm5
000078d941fdc379  addpd xmm15, xmm3
000078d941fdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000078d941fdc384  ptest xmm6, xmm6
000078d941fdc389  jnz 0x000078D941FDF1F9
000078d941fdc38f  vmovaps xmm6, [rsp+0x30]
000078d941fdc395  vpermilpd xmm6, xmm6, 0x00
000078d941fdc39b  movaps xmm5, xmm8
000078d941fdc39f  mulpd xmm5, xmm6
000078d941fdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000078d941fdc3a8  ptest xmm3, xmm3
000078d941fdc3ad  jnz 0x000078D941FDF33B
000078d941fdc3b3  vmovaps xmm8, [rsp+0x30]
000078d941fdc3b9  vpermilpd xmm8, xmm8, 0x00
000078d941fdc3bf  movaps xmm6, xmm10
000078d941fdc3c3  mulpd xmm6, xmm8
000078d941fdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000078d941fdc3cd  ptest xmm3, xmm3
000078d941fdc3d2  jnz 0x000078D941FDF47C
000078d941fdc3d8  vmovaps xmm8, [rsp+0x60]
000078d941fdc3de  movaps xmm10, xmm8
000078d941fdc3e2  addpd xmm10, xmm14
000078d941fdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000078d941fdc3ed  ptest xmm3, xmm3
000078d941fdc3f2  jnz 0x000078D941FDF5BE
000078d941fdc3f8  vmovaps xmm8, [rsp+0x50]
000078d941fdc3fe  movaps xmm14, xmm8
000078d941fdc402  addpd xmm14, xmm4
000078d941fdc407  vcmppd xmm3, xmm14, xmm14, 0x03
000078d941fdc40d  ptest xmm3, xmm3
000078d941fdc412  jnz 0x000078D941FDF702
000078d941fdc418  vmovaps xmm8, [rsp+0x40]
000078d941fdc41e  vpermilpd xmm8, xmm8, 0x00
000078d941fdc424  movaps xmm4, xmm13
000078d941fdc428  mulpd xmm4, xmm8
000078d941fdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000078d941fdc432  ptest xmm3, xmm3
000078d941fdc437  jnz 0x000078D941FDF845
000078d941fdc43d  movaps xmm13, xmm15
000078d941fdc441  addpd xmm13, xmm9
000078d941fdc446  vcmppd xmm8, xmm13, xmm13, 0x03
000078d941fdc44c  ptest xmm8, xmm8
000078d941fdc452  jnz 0x000078D941FDF987
000078d941fdc458  movaps xmm15, xmm1
000078d941fdc45c  addpd xmm15, xmm5
000078d941fdc461  vcmppd xmm9, xmm15, xmm15, 0x03
000078d941fdc467  ptest xmm9, xmm9
000078d941fdc46d  jnz 0x000078D941FDFACB
000078d941fdc473  vmovaps [rsp+0x30], xmm11
000078d941fdc479  vmovaps xmm1, [rsp+0x30]
000078d941fdc47f  por xmm11, xmm1
000078d941fdc484  movaps [r15+0x250], xmm11
000078d941fdc48c  vmovaps [rsp+0x30], xmm12
000078d941fdc492  vmovaps xmm1, [rsp+0x30]
000078d941fdc498  por xmm12, xmm1
000078d941fdc49d  movaps [r15+0x2A0], xmm12
000078d941fdc4a5  vmovaps xmm1, [rsp+0xA0]
000078d941fdc4ae  vmovaps xmm11, [rsp+0xA0]
000078d941fdc4b7  por xmm1, xmm11
000078d941fdc4bc  movaps [r15+0x1D0], xmm1
000078d941fdc4c4  lea r12, [rax+0x40]
000078d941fdc4c8  movups xmm1, [r13+r12*1]
000078d941fdc4ce  movaps [r15+0x2C0], xmm1
000078d941fdc4d6  vmovaps xmm11, [rsp+0x40]
000078d941fdc4dc  vpermilpd xmm11, xmm11, 0x00
000078d941fdc4e2  vmovaps xmm8, [rsp+0xE0]
000078d941fdc4eb  movaps xmm9, xmm8
000078d941fdc4ef  mulpd xmm9, xmm11
000078d941fdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000078d941fdc4fa  ptest xmm5, xmm5
000078d941fdc4ff  jnz 0x000078D941FDFC17
000078d941fdc505  movaps xmm11, xmm10
000078d941fdc509  addpd xmm11, xmm6
000078d941fdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000078d941fdc514  ptest xmm8, xmm8
000078d941fdc51a  jnz 0x000078D941FDFD5B
000078d941fdc520  movaps xmm10, xmm14
000078d941fdc524  addpd xmm10, xmm4
000078d941fdc529  vcmppd xmm8, xmm10, xmm10, 0x03
000078d941fdc52f  ptest xmm8, xmm8
000078d941fdc535  jnz 0x000078D941FDFE9E
000078d941fdc53b  vmovaps xmm14, [rsp+0x40]
000078d941fdc541  vpermilpd xmm14, xmm14, 0x00
000078d941fdc547  movaps xmm8, xmm1
000078d941fdc54b  mulpd xmm8, xmm14
000078d941fdc550  vcmppd xmm6, xmm8, xmm8, 0x03
000078d941fdc556  ptest xmm6, xmm6
000078d941fdc55b  jnz 0x000078D941FDFFE1
000078d941fdc561  movaps xmm1, [r15+0x2B0]
000078d941fdc569  vmovaps xmm14, [rsp+0x40]
000078d941fdc56f  vpermilpd xmm14, xmm14, 0x00
000078d941fdc575  movaps xmm6, xmm1
000078d941fdc578  mulpd xmm6, xmm14
000078d941fdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000078d941fdc582  ptest xmm5, xmm5
000078d941fdc587  jnz 0x000078D941FE0124
000078d941fdc58d  vmovaps xmm1, [rsp+0x10]
000078d941fdc593  vpermilpd xmm1, xmm1, 0x00
000078d941fdc599  movaps xmm14, xmm12
000078d941fdc59d  mulpd xmm14, xmm1
000078d941fdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000078d941fdc5a8  ptest xmm5, xmm5
000078d941fdc5ad  jnz 0x000078D941FE0265
000078d941fdc5b3  movaps xmm1, xmm13
000078d941fdc5b7  addpd xmm1, xmm9
000078d941fdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000078d941fdc5c1  ptest xmm12, xmm12
000078d941fdc5c7  jnz 0x000078D941FE03A8
000078d941fdc5cd  vmovaps xmm13, [rsp+0x10]
000078d941fdc5d3  vpermilpd xmm13, xmm13, 0x00
000078d941fdc5d9  movaps xmm12, xmm7
000078d941fdc5dd  mulpd xmm12, xmm13
000078d941fdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000078d941fdc5e8  ptest xmm9, xmm9
000078d941fdc5ee  jnz 0x000078D941FE04EA
000078d941fdc5f4  movaps xmm13, xmm15
000078d941fdc5f8  addpd xmm13, xmm8
000078d941fdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000078d941fdc603  ptest xmm9, xmm9
000078d941fdc609  jnz 0x000078D941FE062D
000078d941fdc60f  movaps xmm15, [r15+0x290]
000078d941fdc617  vmovaps xmm9, [rsp+0x10]
000078d941fdc61d  vpermilpd xmm9, xmm9, 0x00
000078d941fdc623  movaps xmm8, xmm15
000078d941fdc627  mulpd xmm8, xmm9
000078d941fdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000078d941fdc632  ptest xmm7, xmm7
000078d941fdc637  jnz 0x000078D941FE0771
000078d941fdc63d  movaps xmm15, xmm11
000078d941fdc641  addpd xmm15, xmm6
000078d941fdc646  vcmppd xmm9, xmm15, xmm15, 0x03
000078d941fdc64c  ptest xmm9, xmm9
000078d941fdc652  jnz 0x000078D941FE08B5
000078d941fdc658  movaps xmm11, [r15+0x1E0]
000078d941fdc660  vmovaps xmm9, [rsp+0x10]
000078d941fdc666  vpermilpd xmm9, xmm9, 0x00
000078d941fdc66c  movaps xmm7, xmm11
000078d941fdc670  mulpd xmm7, xmm9
000078d941fdc675  vcmppd xmm6, xmm7, xmm7, 0x03
000078d941fdc67a  ptest xmm6, xmm6
000078d941fdc67f  jnz 0x000078D941FE09F8
000078d941fdc685  movaps xmm11, xmm10
000078d941fdc689  addpd xmm11, xmm14
000078d941fdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000078d941fdc694  ptest xmm9, xmm9
000078d941fdc69a  jnz 0x000078D941FE0B3A
000078d941fdc6a0  lea r12, [rax+0x70]
000078d941fdc6a4  movups xmm14, [r13+r12*1]
000078d941fdc6aa  movaps [r15+0x240], xmm14
000078d941fdc6b2  movaps xmm10, xmm1
000078d941fdc6b6  addpd xmm10, xmm12
000078d941fdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000078d941fdc6c1  ptest xmm9, xmm9
000078d941fdc6c7  jnz 0x000078D941FE0C88
000078d941fdc6cd  movaps [r15+0x170], xmm10
000078d941fdc6d5  vmovaps xmm1, [rsp+0x20]
000078d941fdc6db  vpermilpd xmm1, xmm1, 0x00
000078d941fdc6e1  movaps xmm12, xmm14
000078d941fdc6e5  mulpd xmm12, xmm1
000078d941fdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000078d941fdc6f0  ptest xmm9, xmm9
000078d941fdc6f6  jnz 0x000078D941FE0DCB
000078d941fdc6fc  vmovaps xmm1, [rsp+0x20]
000078d941fdc702  vpermilpd xmm1, xmm1, 0x00
000078d941fdc708  vmovaps xmm9, [rsp+0xB0]
000078d941fdc711  movaps xmm14, xmm9
000078d941fdc715  mulpd xmm14, xmm1
000078d941fdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000078d941fdc720  ptest xmm6, xmm6
000078d941fdc725  jnz 0x000078D941FE0F0E
000078d941fdc72b  movaps [r15+0x180], xmm14
000078d941fdc733  movaps xmm1, xmm13
000078d941fdc737  addpd xmm1, xmm8
000078d941fdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000078d941fdc741  ptest xmm9, xmm9
000078d941fdc747  jnz 0x000078D941FE1051
000078d941fdc74d  movaps [r15+0x210], xmm1
000078d941fdc755  movups xmm13, [r13+rax*1]
000078d941fdc75b  lea r12, [rax+0x10]
000078d941fdc75f  movups xmm9, [r13+r12*1]
000078d941fdc765  movaps [r15+0x230], xmm9
000078d941fdc76d  movaps xmm8, xmm15
000078d941fdc771  addpd xmm8, xmm7
000078d941fdc776  vcmppd xmm6, xmm8, xmm8, 0x03
000078d941fdc77c  ptest xmm6, xmm6
000078d941fdc781  jnz 0x000078D941FE11A7
000078d941fdc787  movaps [r15+0x130], xmm8
000078d941fdc78f  vmovaps xmm15, [rsp+0x20]
000078d941fdc795  vpermilpd xmm15, xmm15, 0x00
000078d941fdc79b  movaps xmm7, xmm9
000078d941fdc79f  mulpd xmm7, xmm15
000078d941fdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000078d941fdc7a9  ptest xmm6, xmm6
000078d941fdc7ae  jnz 0x000078D941FE12EA
000078d941fdc7b4  movaps [r15+0x220], xmm7
000078d941fdc7bc  vmovaps xmm15, [rsp+0x20]
000078d941fdc7c2  vpermilpd xmm15, xmm15, 0x00
000078d941fdc7c8  movaps xmm9, xmm13
000078d941fdc7cc  mulpd xmm9, xmm15
000078d941fdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000078d941fdc7d7  ptest xmm6, xmm6
000078d941fdc7dc  jnz 0x000078D941FE142C
000078d941fdc7e2  movaps xmm15, xmm11
000078d941fdc7e6  addpd xmm15, xmm12
000078d941fdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000078d941fdc7f1  ptest xmm13, xmm13
000078d941fdc7f7  jnz 0x000078D941FE1570
000078d941fdc7fd  movaps [r15+0x140], xmm15
000078d941fdc805  movaps xmm13, xmm10
000078d941fdc809  addpd xmm13, xmm14
000078d941fdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000078d941fdc814  ptest xmm12, xmm12
000078d941fdc81a  jnz 0x000078D941FE16B4
000078d941fdc820  movaps [r15+0x150], xmm13
000078d941fdc828  movaps xmm14, xmm1
000078d941fdc82c  addpd xmm14, xmm7
000078d941fdc831  vcmppd xmm12, xmm14, xmm14, 0x03
000078d941fdc837  ptest xmm12, xmm12
000078d941fdc83d  jnz 0x000078D941FE17F8
000078d941fdc843  movaps [r15+0x160], xmm14
000078d941fdc84b  movaps xmm1, xmm8
000078d941fdc84f  addpd xmm1, xmm9
000078d941fdc854  vcmppd xmm12, xmm1, xmm1, 0x03
000078d941fdc859  ptest xmm12, xmm12
000078d941fdc85f  jnz 0x000078D941FE193A
000078d941fdc865  movaps [r15+0x120], xmm1
000078d941fdc86d  movups [r13+r14*1], xmm15
000078d941fdc873  lea rax, [r14+0x10]
000078d941fdc877  movups [r13+rax*1], xmm13
000078d941fdc87d  lea rax, [r14+0x20]
000078d941fdc881  movups [r13+rax*1], xmm14
000078d941fdc887  lea rax, [r14+0x30]
000078d941fdc88b  movups [r13+rax*1], xmm1
000078d941fdc891  mov eax, [r15+0x108]
000078d941fdc898  sahf
000078d941fdc899  jnz 0x000078D941FDC8CB
000078d941fdc89b  cmp dword ptr [r15+0x318], 0x00
000078d941fdc8a3  jz 0x000078D941FDB900
000078d941fdc8a9  nop [rax+rax*1], ax
000078d941fdc8b2  nop [rax+rax*1], eax
000078d941fdc8ba  mov eax, 0x410444
000078d941fdc8bf  mov [r15+0x100], rax
000078d941fdc8c6  jmp 0x000078D941DFE110
000078d941fdc8cb  cmp dword ptr [r15+0x318], 0x00
000078d941fdc8d3  jz 0x000078D941FD57E0
000078d941fdc8d9  nop [rax+rax*1], ax
000078d941fdc8e2  nop [rax+rax*1], eax
000078d941fdc8ea  mov eax, 0x410278
000078d941fdc8ef  mov [r15+0x100], rax
000078d941fdc8f6  jmp 0x000078D941DFE110
000078d941fdc8fb  int3
000078d941fdc8fc  call 0x000078D941EE27E0
000078d941fdc901  jmp 0x000078D941FDB9DF
000078d941fdc906  call 0x000078D941EE1570
000078d941fdc90b  jmp 0x000078D941FDB9E8
000078d941fdc910  call 0x000078D941EE27E0
000078d941fdc915  jmp 0x000078D941FDBA44
000078d941fdc91a  call 0x000078D941EE1570
000078d941fdc91f  jmp 0x000078D941FDBA4D
000078d941fdc924  call 0x000078D941EE27E0
000078d941fdc929  jmp 0x000078D941FDBA90
000078d941fdc92e  call 0x000078D941EE1570
000078d941fdc933  jmp 0x000078D941FDBA99
000078d941fdc938  call 0x000078D941E0DC20
000078d941fdc93d  jmp 0x000078D941FDBAD8
000078d941fdc942  call 0x000078D941ED59C0
000078d941fdc947  jmp 0x000078D941FDBAEB
000078d941fdc94c  call 0x000078D941EE0E30
000078d941fdc951  jmp 0x000078D941FDBB09
000078d941fdc956  call 0x000078D941EDFBC0
000078d941fdc95b  jmp 0x000078D941FDBB13
000078d941fdc960  call 0x000078D941EDE950
000078d941fdc965  jmp 0x000078D941FDBB1D
000078d941fdc96a  sub rsp, 0x08
000078d941fdc96e  push rax
000078d941fdc96f  push rcx
000078d941fdc970  push rdx
000078d941fdc971  push rdi
000078d941fdc972  push rsi
000078d941fdc973  push r8
000078d941fdc975  push r9
000078d941fdc977  push r10
000078d941fdc979  push r11
000078d941fdc97b  sub rsp, 0xF0
000078d941fdc982  vmovaps [rsp], xmm0
000078d941fdc987  vmovaps [rsp+0x10], xmm1
000078d941fdc98d  vmovaps [rsp+0x20], xmm2
000078d941fdc993  vmovaps [rsp+0x30], xmm3
000078d941fdc999  vmovaps [rsp+0x40], xmm4
000078d941fdc99f  vmovaps [rsp+0x50], xmm5
000078d941fdc9a5  vmovaps [rsp+0x60], xmm6
000078d941fdc9ab  vmovaps [rsp+0x70], xmm7
000078d941fdc9b1  vmovaps [rsp+0x80], xmm9
000078d941fdc9ba  vmovaps [rsp+0x90], xmm10
000078d941fdc9c3  vmovaps [rsp+0xA0], xmm11
000078d941fdc9cc  vmovaps [rsp+0xB0], xmm12
000078d941fdc9d5  vmovaps [rsp+0xC0], xmm13
000078d941fdc9de  vmovaps [rsp+0xD0], xmm14
000078d941fdc9e7  vmovaps [rsp+0xE0], xmm15
000078d941fdc9f0  sub rsp, 0x30
000078d941fdc9f4  movaps [rsp], xmm8
000078d941fdc9f9  movaps [rsp+0x10], xmm12
000078d941fdc9ff  movaps [rsp+0x20], xmm15
000078d941fdca05  lea rdi, [rsp]
000078d941fdca09  mov esi, 0x00
000078d941fdca0e  mov rax, 0x59BFBFBAA530
000078d941fdca18  call rax
000078d941fdca1a  movaps xmm8, [rsp]
000078d941fdca1f  add rsp, 0x30
000078d941fdca23  vmovaps xmm0, [rsp]
000078d941fdca28  vmovaps xmm1, [rsp+0x10]
000078d941fdca2e  vmovaps xmm2, [rsp+0x20]
000078d941fdca34  vmovaps xmm3, [rsp+0x30]
000078d941fdca3a  vmovaps xmm4, [rsp+0x40]
000078d941fdca40  vmovaps xmm5, [rsp+0x50]
000078d941fdca46  vmovaps xmm6, [rsp+0x60]
000078d941fdca4c  vmovaps xmm7, [rsp+0x70]
000078d941fdca52  vmovaps xmm9, [rsp+0x80]
000078d941fdca5b  vmovaps xmm10, [rsp+0x90]
000078d941fdca64  vmovaps xmm11, [rsp+0xA0]
000078d941fdca6d  vmovaps xmm12, [rsp+0xB0]
000078d941fdca76  vmovaps xmm13, [rsp+0xC0]
000078d941fdca7f  vmovaps xmm14, [rsp+0xD0]
000078d941fdca88  vmovaps xmm15, [rsp+0xE0]
000078d941fdca91  add rsp, 0xF0
000078d941fdca98  pop r11
000078d941fdca9a  pop r10
000078d941fdca9c  pop r9
000078d941fdca9e  pop r8
000078d941fdcaa0  pop rsi
000078d941fdcaa1  pop rdi
000078d941fdcaa2  pop rdx
000078d941fdcaa3  pop rcx
000078d941fdcaa4  pop rax
000078d941fdcaa5  add rsp, 0x08
000078d941fdcaa9  jmp 0x000078D941FDBB47
000078d941fdcaae  sub rsp, 0x08
000078d941fdcab2  push rax
000078d941fdcab3  push rcx
000078d941fdcab4  push rdx
000078d941fdcab5  push rdi
000078d941fdcab6  push rsi
000078d941fdcab7  push r8
000078d941fdcab9  push r9
000078d941fdcabb  push r10
000078d941fdcabd  push r11
000078d941fdcabf  sub rsp, 0xF0
000078d941fdcac6  vmovaps [rsp], xmm0
000078d941fdcacb  vmovaps [rsp+0x10], xmm1
000078d941fdcad1  vmovaps [rsp+0x20], xmm2
000078d941fdcad7  vmovaps [rsp+0x30], xmm3
000078d941fdcadd  vmovaps [rsp+0x40], xmm4
000078d941fdcae3  vmovaps [rsp+0x50], xmm5
000078d941fdcae9  vmovaps [rsp+0x60], xmm6
000078d941fdcaef  vmovaps [rsp+0x70], xmm8
000078d941fdcaf5  vmovaps [rsp+0x80], xmm9
000078d941fdcafe  vmovaps [rsp+0x90], xmm10
000078d941fdcb07  vmovaps [rsp+0xA0], xmm11
000078d941fdcb10  vmovaps [rsp+0xB0], xmm12
000078d941fdcb19  vmovaps [rsp+0xC0], xmm13
000078d941fdcb22  vmovaps [rsp+0xD0], xmm14
000078d941fdcb2b  vmovaps [rsp+0xE0], xmm15
000078d941fdcb34  sub rsp, 0x30
000078d941fdcb38  movaps [rsp], xmm7
000078d941fdcb3c  movaps [rsp+0x10], xmm9
000078d941fdcb42  movaps [rsp+0x20], xmm15
000078d941fdcb48  lea rdi, [rsp]
000078d941fdcb4c  mov esi, 0x00
000078d941fdcb51  mov rax, 0x59BFBFBAA530
000078d941fdcb5b  call rax
000078d941fdcb5d  movaps xmm7, [rsp]
000078d941fdcb61  add rsp, 0x30
000078d941fdcb65  vmovaps xmm0, [rsp]
000078d941fdcb6a  vmovaps xmm1, [rsp+0x10]
000078d941fdcb70  vmovaps xmm2, [rsp+0x20]
000078d941fdcb76  vmovaps xmm3, [rsp+0x30]
000078d941fdcb7c  vmovaps xmm4, [rsp+0x40]
000078d941fdcb82  vmovaps xmm5, [rsp+0x50]
000078d941fdcb88  vmovaps xmm6, [rsp+0x60]
000078d941fdcb8e  vmovaps xmm8, [rsp+0x70]
000078d941fdcb94  vmovaps xmm9, [rsp+0x80]
000078d941fdcb9d  vmovaps xmm10, [rsp+0x90]
000078d941fdcba6  vmovaps xmm11, [rsp+0xA0]
000078d941fdcbaf  vmovaps xmm12, [rsp+0xB0]
000078d941fdcbb8  vmovaps xmm13, [rsp+0xC0]
000078d941fdcbc1  vmovaps xmm14, [rsp+0xD0]
000078d941fdcbca  vmovaps xmm15, [rsp+0xE0]
000078d941fdcbd3  add rsp, 0xF0
000078d941fdcbda  pop r11
000078d941fdcbdc  pop r10
000078d941fdcbde  pop r9
000078d941fdcbe0  pop r8
000078d941fdcbe2  pop rsi
000078d941fdcbe3  pop rdi
000078d941fdcbe4  pop rdx
000078d941fdcbe5  pop rcx
000078d941fdcbe6  pop rax
000078d941fdcbe7  add rsp, 0x08
000078d941fdcbeb  jmp 0x000078D941FDBB75
000078d941fdcbf0  sub rsp, 0x08
000078d941fdcbf4  push rax
000078d941fdcbf5  push rcx
000078d941fdcbf6  push rdx
000078d941fdcbf7  push rdi
000078d941fdcbf8  push rsi
000078d941fdcbf9  push r8
000078d941fdcbfb  push r9
000078d941fdcbfd  push r10
000078d941fdcbff  push r11
000078d941fdcc01  sub rsp, 0xF0
000078d941fdcc08  vmovaps [rsp], xmm0
000078d941fdcc0d  vmovaps [rsp+0x10], xmm1
000078d941fdcc13  vmovaps [rsp+0x20], xmm2
000078d941fdcc19  vmovaps [rsp+0x30], xmm3
000078d941fdcc1f  vmovaps [rsp+0x40], xmm4
000078d941fdcc25  vmovaps [rsp+0x50], xmm5
000078d941fdcc2b  vmovaps [rsp+0x60], xmm6
000078d941fdcc31  vmovaps [rsp+0x70], xmm7
000078d941fdcc37  vmovaps [rsp+0x80], xmm8
000078d941fdcc40  vmovaps [rsp+0x90], xmm10
000078d941fdcc49  vmovaps [rsp+0xA0], xmm11
000078d941fdcc52  vmovaps [rsp+0xB0], xmm12
000078d941fdcc5b  vmovaps [rsp+0xC0], xmm13
000078d941fdcc64  vmovaps [rsp+0xD0], xmm14
000078d941fdcc6d  vmovaps [rsp+0xE0], xmm15
000078d941fdcc76  sub rsp, 0x30
000078d941fdcc7a  movaps [rsp], xmm9
000078d941fdcc7f  movaps [rsp+0x10], xmm12
000078d941fdcc85  movaps [rsp+0x20], xmm10
000078d941fdcc8b  lea rdi, [rsp]
000078d941fdcc8f  mov esi, 0x00
000078d941fdcc94  mov rax, 0x59BFBFBAA530
000078d941fdcc9e  call rax
000078d941fdcca0  movaps xmm9, [rsp]
000078d941fdcca5  add rsp, 0x30
000078d941fdcca9  vmovaps xmm0, [rsp]
000078d941fdccae  vmovaps xmm1, [rsp+0x10]
000078d941fdccb4  vmovaps xmm2, [rsp+0x20]
000078d941fdccba  vmovaps xmm3, [rsp+0x30]
000078d941fdccc0  vmovaps xmm4, [rsp+0x40]
000078d941fdccc6  vmovaps xmm5, [rsp+0x50]
000078d941fdcccc  vmovaps xmm6, [rsp+0x60]
000078d941fdccd2  vmovaps xmm7, [rsp+0x70]
000078d941fdccd8  vmovaps xmm8, [rsp+0x80]
000078d941fdcce1  vmovaps xmm10, [rsp+0x90]
000078d941fdccea  vmovaps xmm11, [rsp+0xA0]
000078d941fdccf3  vmovaps xmm12, [rsp+0xB0]
000078d941fdccfc  vmovaps xmm13, [rsp+0xC0]
000078d941fdcd05  vmovaps xmm14, [rsp+0xD0]
000078d941fdcd0e  vmovaps xmm15, [rsp+0xE0]
000078d941fdcd17  add rsp, 0xF0
000078d941fdcd1e  pop r11
000078d941fdcd20  pop r10
000078d941fdcd22  pop r9
000078d941fdcd24  pop r8
000078d941fdcd26  pop rsi
000078d941fdcd27  pop rdi
000078d941fdcd28  pop rdx
000078d941fdcd29  pop rcx
000078d941fdcd2a  pop rax
000078d941fdcd2b  add rsp, 0x08
000078d941fdcd2f  jmp 0x000078D941FDBB99
000078d941fdcd34  sub rsp, 0x08
000078d941fdcd38  push rax
000078d941fdcd39  push rcx
000078d941fdcd3a  push rdx
000078d941fdcd3b  push rdi
000078d941fdcd3c  push rsi
000078d941fdcd3d  push r8
000078d941fdcd3f  push r9
000078d941fdcd41  push r10
000078d941fdcd43  push r11
000078d941fdcd45  sub rsp, 0xF0
000078d941fdcd4c  vmovaps [rsp], xmm0
000078d941fdcd51  vmovaps [rsp+0x10], xmm1
000078d941fdcd57  vmovaps [rsp+0x20], xmm2
000078d941fdcd5d  vmovaps [rsp+0x30], xmm3
000078d941fdcd63  vmovaps [rsp+0x40], xmm4
000078d941fdcd69  vmovaps [rsp+0x50], xmm5
000078d941fdcd6f  vmovaps [rsp+0x60], xmm6
000078d941fdcd75  vmovaps [rsp+0x70], xmm7
000078d941fdcd7b  vmovaps [rsp+0x80], xmm8
000078d941fdcd84  vmovaps [rsp+0x90], xmm9
000078d941fdcd8d  vmovaps [rsp+0xA0], xmm11
000078d941fdcd96  vmovaps [rsp+0xB0], xmm12
000078d941fdcd9f  vmovaps [rsp+0xC0], xmm13
000078d941fdcda8  vmovaps [rsp+0xD0], xmm14
000078d941fdcdb1  vmovaps [rsp+0xE0], xmm15
000078d941fdcdba  sub rsp, 0x30
000078d941fdcdbe  movaps [rsp], xmm10
000078d941fdcdc3  movaps [rsp+0x10], xmm12
000078d941fdcdc9  movaps [rsp+0x20], xmm11
000078d941fdcdcf  lea rdi, [rsp]
000078d941fdcdd3  mov esi, 0x00
000078d941fdcdd8  mov rax, 0x59BFBFBAA530
000078d941fdcde2  call rax
000078d941fdcde4  movaps xmm10, [rsp]
000078d941fdcde9  add rsp, 0x30
000078d941fdcded  vmovaps xmm0, [rsp]
000078d941fdcdf2  vmovaps xmm1, [rsp+0x10]
000078d941fdcdf8  vmovaps xmm2, [rsp+0x20]
000078d941fdcdfe  vmovaps xmm3, [rsp+0x30]
000078d941fdce04  vmovaps xmm4, [rsp+0x40]
000078d941fdce0a  vmovaps xmm5, [rsp+0x50]
000078d941fdce10  vmovaps xmm6, [rsp+0x60]
000078d941fdce16  vmovaps xmm7, [rsp+0x70]
000078d941fdce1c  vmovaps xmm8, [rsp+0x80]
000078d941fdce25  vmovaps xmm9, [rsp+0x90]
000078d941fdce2e  vmovaps xmm11, [rsp+0xA0]
000078d941fdce37  vmovaps xmm12, [rsp+0xB0]
000078d941fdce40  vmovaps xmm13, [rsp+0xC0]
000078d941fdce49  vmovaps xmm14, [rsp+0xD0]
000078d941fdce52  vmovaps xmm15, [rsp+0xE0]
000078d941fdce5b  add rsp, 0xF0
000078d941fdce62  pop r11
000078d941fdce64  pop r10
000078d941fdce66  pop r9
000078d941fdce68  pop r8
000078d941fdce6a  pop rsi
000078d941fdce6b  pop rdi
000078d941fdce6c  pop rdx
000078d941fdce6d  pop rcx
000078d941fdce6e  pop rax
000078d941fdce6f  add rsp, 0x08
000078d941fdce73  jmp 0x000078D941FDBBB3
000078d941fdce78  sub rsp, 0x08
000078d941fdce7c  push rax
000078d941fdce7d  push rcx
000078d941fdce7e  push rdx
000078d941fdce7f  push rdi
000078d941fdce80  push rsi
000078d941fdce81  push r8
000078d941fdce83  push r9
000078d941fdce85  push r10
000078d941fdce87  push r11
000078d941fdce89  sub rsp, 0xF0
000078d941fdce90  vmovaps [rsp], xmm0
000078d941fdce95  vmovaps [rsp+0x10], xmm1
000078d941fdce9b  vmovaps [rsp+0x20], xmm2
000078d941fdcea1  vmovaps [rsp+0x30], xmm3
000078d941fdcea7  vmovaps [rsp+0x40], xmm4
000078d941fdcead  vmovaps [rsp+0x50], xmm5
000078d941fdceb3  vmovaps [rsp+0x60], xmm7
000078d941fdceb9  vmovaps [rsp+0x70], xmm8
000078d941fdcebf  vmovaps [rsp+0x80], xmm9
000078d941fdcec8  vmovaps [rsp+0x90], xmm10
000078d941fdced1  vmovaps [rsp+0xA0], xmm11
000078d941fdceda  vmovaps [rsp+0xB0], xmm12
000078d941fdcee3  vmovaps [rsp+0xC0], xmm13
000078d941fdceec  vmovaps [rsp+0xD0], xmm14
000078d941fdcef5  vmovaps [rsp+0xE0], xmm15
000078d941fdcefe  sub rsp, 0x30
000078d941fdcf02  movaps [rsp], xmm6
000078d941fdcf06  movaps [rsp+0x10], xmm12
000078d941fdcf0c  movaps [rsp+0x20], xmm11
000078d941fdcf12  lea rdi, [rsp]
000078d941fdcf16  mov esi, 0x00
000078d941fdcf1b  mov rax, 0x59BFBFBAA530
000078d941fdcf25  call rax
000078d941fdcf27  movaps xmm6, [rsp]
000078d941fdcf2b  add rsp, 0x30
000078d941fdcf2f  vmovaps xmm0, [rsp]
000078d941fdcf34  vmovaps xmm1, [rsp+0x10]
000078d941fdcf3a  vmovaps xmm2, [rsp+0x20]
000078d941fdcf40  vmovaps xmm3, [rsp+0x30]
000078d941fdcf46  vmovaps xmm4, [rsp+0x40]
000078d941fdcf4c  vmovaps xmm5, [rsp+0x50]
000078d941fdcf52  vmovaps xmm7, [rsp+0x60]
000078d941fdcf58  vmovaps xmm8, [rsp+0x70]
000078d941fdcf5e  vmovaps xmm9, [rsp+0x80]
000078d941fdcf67  vmovaps xmm10, [rsp+0x90]
000078d941fdcf70  vmovaps xmm11, [rsp+0xA0]
000078d941fdcf79  vmovaps xmm12, [rsp+0xB0]
000078d941fdcf82  vmovaps xmm13, [rsp+0xC0]
000078d941fdcf8b  vmovaps xmm14, [rsp+0xD0]
000078d941fdcf94  vmovaps xmm15, [rsp+0xE0]
000078d941fdcf9d  add rsp, 0xF0
000078d941fdcfa4  pop r11
000078d941fdcfa6  pop r10
000078d941fdcfa8  pop r9
000078d941fdcfaa  pop r8
000078d941fdcfac  pop rsi
000078d941fdcfad  pop rdi
000078d941fdcfae  pop rdx
000078d941fdcfaf  pop rcx
000078d941fdcfb0  pop rax
000078d941fdcfb1  add rsp, 0x08
000078d941fdcfb5  jmp 0x000078D941FDBBD4
000078d941fdcfba  sub rsp, 0x08
000078d941fdcfbe  push rax
000078d941fdcfbf  push rcx
000078d941fdcfc0  push rdx
000078d941fdcfc1  push rdi
000078d941fdcfc2  push rsi
000078d941fdcfc3  push r8
000078d941fdcfc5  push r9
000078d941fdcfc7  push r10
000078d941fdcfc9  push r11
000078d941fdcfcb  sub rsp, 0xF0
000078d941fdcfd2  vmovaps [rsp], xmm0
000078d941fdcfd7  vmovaps [rsp+0x10], xmm1
000078d941fdcfdd  vmovaps [rsp+0x20], xmm2
000078d941fdcfe3  vmovaps [rsp+0x30], xmm4
000078d941fdcfe9  vmovaps [rsp+0x40], xmm5
000078d941fdcfef  vmovaps [rsp+0x50], xmm6
000078d941fdcff5  vmovaps [rsp+0x60], xmm7
000078d941fdcffb  vmovaps [rsp+0x70], xmm8
000078d941fdd001  vmovaps [rsp+0x80], xmm9
000078d941fdd00a  vmovaps [rsp+0x90], xmm10
000078d941fdd013  vmovaps [rsp+0xA0], xmm11
000078d941fdd01c  vmovaps [rsp+0xB0], xmm12
000078d941fdd025  vmovaps [rsp+0xC0], xmm13
000078d941fdd02e  vmovaps [rsp+0xD0], xmm14
000078d941fdd037  vmovaps [rsp+0xE0], xmm15
000078d941fdd040  sub rsp, 0x30
000078d941fdd044  movaps [rsp], xmm3
000078d941fdd048  movaps [rsp+0x10], xmm5
000078d941fdd04d  movaps [rsp+0x20], xmm4
000078d941fdd052  lea rdi, [rsp]
000078d941fdd056  mov esi, 0x00
000078d941fdd05b  mov rax, 0x59BFBFBAA530
000078d941fdd065  call rax
000078d941fdd067  movaps xmm3, [rsp]
000078d941fdd06b  add rsp, 0x30
000078d941fdd06f  vmovaps xmm0, [rsp]
000078d941fdd074  vmovaps xmm1, [rsp+0x10]
000078d941fdd07a  vmovaps xmm2, [rsp+0x20]
000078d941fdd080  vmovaps xmm4, [rsp+0x30]
000078d941fdd086  vmovaps xmm5, [rsp+0x40]
000078d941fdd08c  vmovaps xmm6, [rsp+0x50]
000078d941fdd092  vmovaps xmm7, [rsp+0x60]
000078d941fdd098  vmovaps xmm8, [rsp+0x70]
000078d941fdd09e  vmovaps xmm9, [rsp+0x80]
000078d941fdd0a7  vmovaps xmm10, [rsp+0x90]
000078d941fdd0b0  vmovaps xmm11, [rsp+0xA0]
000078d941fdd0b9  vmovaps xmm12, [rsp+0xB0]
000078d941fdd0c2  vmovaps xmm13, [rsp+0xC0]
000078d941fdd0cb  vmovaps xmm14, [rsp+0xD0]
000078d941fdd0d4  vmovaps xmm15, [rsp+0xE0]
000078d941fdd0dd  add rsp, 0xF0
000078d941fdd0e4  pop r11
000078d941fdd0e6  pop r10
000078d941fdd0e8  pop r9
000078d941fdd0ea  pop r8
000078d941fdd0ec  pop rsi
000078d941fdd0ed  pop rdi
000078d941fdd0ee  pop rdx
000078d941fdd0ef  pop rcx
000078d941fdd0f0  pop rax
000078d941fdd0f1  add rsp, 0x08
000078d941fdd0f5  jmp 0x000078D941FDBC35
000078d941fdd0fa  sub rsp, 0x08
000078d941fdd0fe  push rax
000078d941fdd0ff  push rcx
000078d941fdd100  push rdx
000078d941fdd101  push rdi
000078d941fdd102  push rsi
000078d941fdd103  push r8
000078d941fdd105  push r9
000078d941fdd107  push r10
000078d941fdd109  push r11
000078d941fdd10b  sub rsp, 0xF0
000078d941fdd112  vmovaps [rsp], xmm0
000078d941fdd117  vmovaps [rsp+0x10], xmm1
000078d941fdd11d  vmovaps [rsp+0x20], xmm2
000078d941fdd123  vmovaps [rsp+0x30], xmm3
000078d941fdd129  vmovaps [rsp+0x40], xmm4
000078d941fdd12f  vmovaps [rsp+0x50], xmm6
000078d941fdd135  vmovaps [rsp+0x60], xmm7
000078d941fdd13b  vmovaps [rsp+0x70], xmm8
000078d941fdd141  vmovaps [rsp+0x80], xmm9
000078d941fdd14a  vmovaps [rsp+0x90], xmm10
000078d941fdd153  vmovaps [rsp+0xA0], xmm11
000078d941fdd15c  vmovaps [rsp+0xB0], xmm12
000078d941fdd165  vmovaps [rsp+0xC0], xmm13
000078d941fdd16e  vmovaps [rsp+0xD0], xmm14
000078d941fdd177  vmovaps [rsp+0xE0], xmm15
000078d941fdd180  sub rsp, 0x30
000078d941fdd184  movaps [rsp], xmm5
000078d941fdd188  movaps [rsp+0x10], xmm8
000078d941fdd18e  movaps [rsp+0x20], xmm15
000078d941fdd194  lea rdi, [rsp]
000078d941fdd198  mov esi, 0x00
000078d941fdd19d  mov rax, 0x59BFBFBAA530
000078d941fdd1a7  call rax
000078d941fdd1a9  movaps xmm5, [rsp]
000078d941fdd1ad  add rsp, 0x30
000078d941fdd1b1  vmovaps xmm0, [rsp]
000078d941fdd1b6  vmovaps xmm1, [rsp+0x10]
000078d941fdd1bc  vmovaps xmm2, [rsp+0x20]
000078d941fdd1c2  vmovaps xmm3, [rsp+0x30]
000078d941fdd1c8  vmovaps xmm4, [rsp+0x40]
000078d941fdd1ce  vmovaps xmm6, [rsp+0x50]
000078d941fdd1d4  vmovaps xmm7, [rsp+0x60]
000078d941fdd1da  vmovaps xmm8, [rsp+0x70]
000078d941fdd1e0  vmovaps xmm9, [rsp+0x80]
000078d941fdd1e9  vmovaps xmm10, [rsp+0x90]
000078d941fdd1f2  vmovaps xmm11, [rsp+0xA0]
000078d941fdd1fb  vmovaps xmm12, [rsp+0xB0]
000078d941fdd204  vmovaps xmm13, [rsp+0xC0]
000078d941fdd20d  vmovaps xmm14, [rsp+0xD0]
000078d941fdd216  vmovaps xmm15, [rsp+0xE0]
000078d941fdd21f  add rsp, 0xF0
000078d941fdd226  pop r11
000078d941fdd228  pop r10
000078d941fdd22a  pop r9
000078d941fdd22c  pop r8
000078d941fdd22e  pop rsi
000078d941fdd22f  pop rdi
000078d941fdd230  pop rdx
000078d941fdd231  pop rcx
000078d941fdd232  pop rax
000078d941fdd233  add rsp, 0x08
000078d941fdd237  jmp 0x000078D941FDBC73
000078d941fdd23c  sub rsp, 0x08
000078d941fdd240  push rax
000078d941fdd241  push rcx
000078d941fdd242  push rdx
000078d941fdd243  push rdi
000078d941fdd244  push rsi
000078d941fdd245  push r8
000078d941fdd247  push r9
000078d941fdd249  push r10
000078d941fdd24b  push r11
000078d941fdd24d  sub rsp, 0xF0
000078d941fdd254  vmovaps [rsp], xmm0
000078d941fdd259  vmovaps [rsp+0x10], xmm1
000078d941fdd25f  vmovaps [rsp+0x20], xmm2
000078d941fdd265  vmovaps [rsp+0x30], xmm3
000078d941fdd26b  vmovaps [rsp+0x40], xmm5
000078d941fdd271  vmovaps [rsp+0x50], xmm6
000078d941fdd277  vmovaps [rsp+0x60], xmm7
000078d941fdd27d  vmovaps [rsp+0x70], xmm8
000078d941fdd283  vmovaps [rsp+0x80], xmm9
000078d941fdd28c  vmovaps [rsp+0x90], xmm10
000078d941fdd295  vmovaps [rsp+0xA0], xmm11
000078d941fdd29e  vmovaps [rsp+0xB0], xmm12
000078d941fdd2a7  vmovaps [rsp+0xC0], xmm13
000078d941fdd2b0  vmovaps [rsp+0xD0], xmm14
000078d941fdd2b9  vmovaps [rsp+0xE0], xmm15
000078d941fdd2c2  sub rsp, 0x30
000078d941fdd2c6  movaps [rsp], xmm4
000078d941fdd2ca  movaps [rsp+0x10], xmm9
000078d941fdd2d0  movaps [rsp+0x20], xmm8
000078d941fdd2d6  lea rdi, [rsp]
000078d941fdd2da  mov esi, 0x00
000078d941fdd2df  mov rax, 0x59BFBFBAA530
000078d941fdd2e9  call rax
000078d941fdd2eb  movaps xmm4, [rsp]
000078d941fdd2ef  add rsp, 0x30
000078d941fdd2f3  vmovaps xmm0, [rsp]
000078d941fdd2f8  vmovaps xmm1, [rsp+0x10]
000078d941fdd2fe  vmovaps xmm2, [rsp+0x20]
000078d941fdd304  vmovaps xmm3, [rsp+0x30]
000078d941fdd30a  vmovaps xmm5, [rsp+0x40]
000078d941fdd310  vmovaps xmm6, [rsp+0x50]
000078d941fdd316  vmovaps xmm7, [rsp+0x60]
000078d941fdd31c  vmovaps xmm8, [rsp+0x70]
000078d941fdd322  vmovaps xmm9, [rsp+0x80]
000078d941fdd32b  vmovaps xmm10, [rsp+0x90]
000078d941fdd334  vmovaps xmm11, [rsp+0xA0]
000078d941fdd33d  vmovaps xmm12, [rsp+0xB0]
000078d941fdd346  vmovaps xmm13, [rsp+0xC0]
000078d941fdd34f  vmovaps xmm14, [rsp+0xD0]
000078d941fdd358  vmovaps xmm15, [rsp+0xE0]
000078d941fdd361  add rsp, 0xF0
000078d941fdd368  pop r11
000078d941fdd36a  pop r10
000078d941fdd36c  pop r9
000078d941fdd36e  pop r8
000078d941fdd370  pop rsi
000078d941fdd371  pop rdi
000078d941fdd372  pop rdx
000078d941fdd373  pop rcx
000078d941fdd374  pop rax
000078d941fdd375  add rsp, 0x08
000078d941fdd379  jmp 0x000078D941FDBC94
000078d941fdd37e  sub rsp, 0x08
000078d941fdd382  push rax
000078d941fdd383  push rcx
000078d941fdd384  push rdx
000078d941fdd385  push rdi
000078d941fdd386  push rsi
000078d941fdd387  push r8
000078d941fdd389  push r9
000078d941fdd38b  push r10
000078d941fdd38d  push r11
000078d941fdd38f  sub rsp, 0xF0
000078d941fdd396  vmovaps [rsp], xmm0
000078d941fdd39b  vmovaps [rsp+0x10], xmm1
000078d941fdd3a1  vmovaps [rsp+0x20], xmm2
000078d941fdd3a7  vmovaps [rsp+0x30], xmm3
000078d941fdd3ad  vmovaps [rsp+0x40], xmm4
000078d941fdd3b3  vmovaps [rsp+0x50], xmm5
000078d941fdd3b9  vmovaps [rsp+0x60], xmm6
000078d941fdd3bf  vmovaps [rsp+0x70], xmm7
000078d941fdd3c5  vmovaps [rsp+0x80], xmm8
000078d941fdd3ce  vmovaps [rsp+0x90], xmm10
000078d941fdd3d7  vmovaps [rsp+0xA0], xmm11
000078d941fdd3e0  vmovaps [rsp+0xB0], xmm12
000078d941fdd3e9  vmovaps [rsp+0xC0], xmm13
000078d941fdd3f2  vmovaps [rsp+0xD0], xmm14
000078d941fdd3fb  vmovaps [rsp+0xE0], xmm15
000078d941fdd404  sub rsp, 0x30
000078d941fdd408  movaps [rsp], xmm9
000078d941fdd40d  movaps [rsp+0x10], xmm10
000078d941fdd413  movaps [rsp+0x20], xmm8
000078d941fdd419  lea rdi, [rsp]
000078d941fdd41d  mov esi, 0x00
000078d941fdd422  mov rax, 0x59BFBFBAA530
000078d941fdd42c  call rax
000078d941fdd42e  movaps xmm9, [rsp]
000078d941fdd433  add rsp, 0x30
000078d941fdd437  vmovaps xmm0, [rsp]
000078d941fdd43c  vmovaps xmm1, [rsp+0x10]
000078d941fdd442  vmovaps xmm2, [rsp+0x20]
000078d941fdd448  vmovaps xmm3, [rsp+0x30]
000078d941fdd44e  vmovaps xmm4, [rsp+0x40]
000078d941fdd454  vmovaps xmm5, [rsp+0x50]
000078d941fdd45a  vmovaps xmm6, [rsp+0x60]
000078d941fdd460  vmovaps xmm7, [rsp+0x70]
000078d941fdd466  vmovaps xmm8, [rsp+0x80]
000078d941fdd46f  vmovaps xmm10, [rsp+0x90]
000078d941fdd478  vmovaps xmm11, [rsp+0xA0]
000078d941fdd481  vmovaps xmm12, [rsp+0xB0]
000078d941fdd48a  vmovaps xmm13, [rsp+0xC0]
000078d941fdd493  vmovaps xmm14, [rsp+0xD0]
000078d941fdd49c  vmovaps xmm15, [rsp+0xE0]
000078d941fdd4a5  add rsp, 0xF0
000078d941fdd4ac  pop r11
000078d941fdd4ae  pop r10
000078d941fdd4b0  pop r9
000078d941fdd4b2  pop r8
000078d941fdd4b4  pop rsi
000078d941fdd4b5  pop rdi
000078d941fdd4b6  pop rdx
000078d941fdd4b7  pop rcx
000078d941fdd4b8  pop rax
000078d941fdd4b9  add rsp, 0x08
000078d941fdd4bd  jmp 0x000078D941FDBCAE
000078d941fdd4c2  call 0x000078D941EB52F0
000078d941fdd4c7  jmp 0x000078D941FDBDC8
000078d941fdd4cc  call 0x000078D941EB52F0
000078d941fdd4d1  jmp 0x000078D941FDBDDE
000078d941fdd4d6  sub rsp, 0x08
000078d941fdd4da  push rax
000078d941fdd4db  push rcx
000078d941fdd4dc  push rdx
000078d941fdd4dd  push rdi
000078d941fdd4de  push rsi
000078d941fdd4df  push r8
000078d941fdd4e1  push r9
000078d941fdd4e3  push r10
000078d941fdd4e5  push r11
000078d941fdd4e7  sub rsp, 0xF0
000078d941fdd4ee  vmovaps [rsp], xmm0
000078d941fdd4f3  vmovaps [rsp+0x10], xmm2
000078d941fdd4f9  vmovaps [rsp+0x20], xmm3
000078d941fdd4ff  vmovaps [rsp+0x30], xmm4
000078d941fdd505  vmovaps [rsp+0x40], xmm5
000078d941fdd50b  vmovaps [rsp+0x50], xmm6
000078d941fdd511  vmovaps [rsp+0x60], xmm7
000078d941fdd517  vmovaps [rsp+0x70], xmm8
000078d941fdd51d  vmovaps [rsp+0x80], xmm9
000078d941fdd526  vmovaps [rsp+0x90], xmm10
000078d941fdd52f  vmovaps [rsp+0xA0], xmm11
000078d941fdd538  vmovaps [rsp+0xB0], xmm12
000078d941fdd541  vmovaps [rsp+0xC0], xmm13
000078d941fdd54a  vmovaps [rsp+0xD0], xmm14
000078d941fdd553  vmovaps [rsp+0xE0], xmm15
000078d941fdd55c  sub rsp, 0x30
000078d941fdd560  movaps [rsp], xmm1
000078d941fdd564  movaps [rsp+0x10], xmm6
000078d941fdd569  movaps [rsp+0x20], xmm15
000078d941fdd56f  lea rdi, [rsp]
000078d941fdd573  mov esi, 0x00
000078d941fdd578  mov rax, 0x59BFBFBAA530
000078d941fdd582  call rax
000078d941fdd584  movaps xmm1, [rsp]
000078d941fdd588  add rsp, 0x30
000078d941fdd58c  vmovaps xmm0, [rsp]
000078d941fdd591  vmovaps xmm2, [rsp+0x10]
000078d941fdd597  vmovaps xmm3, [rsp+0x20]
000078d941fdd59d  vmovaps xmm4, [rsp+0x30]
000078d941fdd5a3  vmovaps xmm5, [rsp+0x40]
000078d941fdd5a9  vmovaps xmm6, [rsp+0x50]
000078d941fdd5af  vmovaps xmm7, [rsp+0x60]
000078d941fdd5b5  vmovaps xmm8, [rsp+0x70]
000078d941fdd5bb  vmovaps xmm9, [rsp+0x80]
000078d941fdd5c4  vmovaps xmm10, [rsp+0x90]
000078d941fdd5cd  vmovaps xmm11, [rsp+0xA0]
000078d941fdd5d6  vmovaps xmm12, [rsp+0xB0]
000078d941fdd5df  vmovaps xmm13, [rsp+0xC0]
000078d941fdd5e8  vmovaps xmm14, [rsp+0xD0]
000078d941fdd5f1  vmovaps xmm15, [rsp+0xE0]
000078d941fdd5fa  add rsp, 0xF0
000078d941fdd601  pop r11
000078d941fdd603  pop r10
000078d941fdd605  pop r9
000078d941fdd607  pop r8
000078d941fdd609  pop rsi
000078d941fdd60a  pop rdi
000078d941fdd60b  pop rdx
000078d941fdd60c  pop rcx
000078d941fdd60d  pop rax
000078d941fdd60e  add rsp, 0x08
000078d941fdd612  jmp 0x000078D941FDBE1B
000078d941fdd617  call 0x000078D941EC4620
000078d941fdd61c  jmp 0x000078D941FDBE28
000078d941fdd621  sub rsp, 0x08
000078d941fdd625  push rax
000078d941fdd626  push rcx
000078d941fdd627  push rdx
000078d941fdd628  push rdi
000078d941fdd629  push rsi
000078d941fdd62a  push r8
000078d941fdd62c  push r9
000078d941fdd62e  push r10
000078d941fdd630  push r11
000078d941fdd632  sub rsp, 0xF0
000078d941fdd639  vmovaps [rsp], xmm0
000078d941fdd63e  vmovaps [rsp+0x10], xmm1
000078d941fdd644  vmovaps [rsp+0x20], xmm2
000078d941fdd64a  vmovaps [rsp+0x30], xmm3
000078d941fdd650  vmovaps [rsp+0x40], xmm4
000078d941fdd656  vmovaps [rsp+0x50], xmm5
000078d941fdd65c  vmovaps [rsp+0x60], xmm6
000078d941fdd662  vmovaps [rsp+0x70], xmm7
000078d941fdd668  vmovaps [rsp+0x80], xmm8
000078d941fdd671  vmovaps [rsp+0x90], xmm9
000078d941fdd67a  vmovaps [rsp+0xA0], xmm10
000078d941fdd683  vmovaps [rsp+0xB0], xmm11
000078d941fdd68c  vmovaps [rsp+0xC0], xmm12
000078d941fdd695  vmovaps [rsp+0xD0], xmm13
000078d941fdd69e  vmovaps [rsp+0xE0], xmm15
000078d941fdd6a7  sub rsp, 0x30
000078d941fdd6ab  movaps [rsp], xmm14
000078d941fdd6b0  movaps [rsp+0x10], xmm4
000078d941fdd6b5  movaps [rsp+0x20], xmm3
000078d941fdd6ba  lea rdi, [rsp]
000078d941fdd6be  mov esi, 0x00
000078d941fdd6c3  mov rax, 0x59BFBFBAA530
000078d941fdd6cd  call rax
000078d941fdd6cf  movaps xmm14, [rsp]
000078d941fdd6d4  add rsp, 0x30
000078d941fdd6d8  vmovaps xmm0, [rsp]
000078d941fdd6dd  vmovaps xmm1, [rsp+0x10]
000078d941fdd6e3  vmovaps xmm2, [rsp+0x20]
000078d941fdd6e9  vmovaps xmm3, [rsp+0x30]
000078d941fdd6ef  vmovaps xmm4, [rsp+0x40]
000078d941fdd6f5  vmovaps xmm5, [rsp+0x50]
000078d941fdd6fb  vmovaps xmm6, [rsp+0x60]
000078d941fdd701  vmovaps xmm7, [rsp+0x70]
000078d941fdd707  vmovaps xmm8, [rsp+0x80]
000078d941fdd710  vmovaps xmm9, [rsp+0x90]
000078d941fdd719  vmovaps xmm10, [rsp+0xA0]
000078d941fdd722  vmovaps xmm11, [rsp+0xB0]
000078d941fdd72b  vmovaps xmm12, [rsp+0xC0]
000078d941fdd734  vmovaps xmm13, [rsp+0xD0]
000078d941fdd73d  vmovaps xmm15, [rsp+0xE0]
000078d941fdd746  add rsp, 0xF0
000078d941fdd74d  pop r11
000078d941fdd74f  pop r10
000078d941fdd751  pop r9
000078d941fdd753  pop r8
000078d941fdd755  pop rsi
000078d941fdd756  pop rdi
000078d941fdd757  pop rdx
000078d941fdd758  pop rcx
000078d941fdd759  pop rax
000078d941fdd75a  add rsp, 0x08
000078d941fdd75e  jmp 0x000078D941FDBE42
000078d941fdd763  sub rsp, 0x08
000078d941fdd767  push rax
000078d941fdd768  push rcx
000078d941fdd769  push rdx
000078d941fdd76a  push rdi
000078d941fdd76b  push rsi
000078d941fdd76c  push r8
000078d941fdd76e  push r9
000078d941fdd770  push r10
000078d941fdd772  push r11
000078d941fdd774  sub rsp, 0xF0
000078d941fdd77b  vmovaps [rsp], xmm0
000078d941fdd780  vmovaps [rsp+0x10], xmm1
000078d941fdd786  vmovaps [rsp+0x20], xmm2
000078d941fdd78c  vmovaps [rsp+0x30], xmm3
000078d941fdd792  vmovaps [rsp+0x40], xmm4
000078d941fdd798  vmovaps [rsp+0x50], xmm5
000078d941fdd79e  vmovaps [rsp+0x60], xmm7
000078d941fdd7a4  vmovaps [rsp+0x70], xmm8
000078d941fdd7aa  vmovaps [rsp+0x80], xmm9
000078d941fdd7b3  vmovaps [rsp+0x90], xmm10
000078d941fdd7bc  vmovaps [rsp+0xA0], xmm11
000078d941fdd7c5  vmovaps [rsp+0xB0], xmm12
000078d941fdd7ce  vmovaps [rsp+0xC0], xmm13
000078d941fdd7d7  vmovaps [rsp+0xD0], xmm14
000078d941fdd7e0  vmovaps [rsp+0xE0], xmm15
000078d941fdd7e9  sub rsp, 0x30
000078d941fdd7ed  movaps [rsp], xmm6
000078d941fdd7f1  movaps [rsp+0x10], xmm9
000078d941fdd7f7  movaps [rsp+0x20], xmm7
000078d941fdd7fc  lea rdi, [rsp]
000078d941fdd800  mov esi, 0x00
000078d941fdd805  mov rax, 0x59BFBFBAA530
000078d941fdd80f  call rax
000078d941fdd811  movaps xmm6, [rsp]
000078d941fdd815  add rsp, 0x30
000078d941fdd819  vmovaps xmm0, [rsp]
000078d941fdd81e  vmovaps xmm1, [rsp+0x10]
000078d941fdd824  vmovaps xmm2, [rsp+0x20]
000078d941fdd82a  vmovaps xmm3, [rsp+0x30]
000078d941fdd830  vmovaps xmm4, [rsp+0x40]
000078d941fdd836  vmovaps xmm5, [rsp+0x50]
000078d941fdd83c  vmovaps xmm7, [rsp+0x60]
000078d941fdd842  vmovaps xmm8, [rsp+0x70]
000078d941fdd848  vmovaps xmm9, [rsp+0x80]
000078d941fdd851  vmovaps xmm10, [rsp+0x90]
000078d941fdd85a  vmovaps xmm11, [rsp+0xA0]
000078d941fdd863  vmovaps xmm12, [rsp+0xB0]
000078d941fdd86c  vmovaps xmm13, [rsp+0xC0]
000078d941fdd875  vmovaps xmm14, [rsp+0xD0]
000078d941fdd87e  vmovaps xmm15, [rsp+0xE0]
000078d941fdd887  add rsp, 0xF0
000078d941fdd88e  pop r11
000078d941fdd890  pop r10
000078d941fdd892  pop r9
000078d941fdd894  pop r8
000078d941fdd896  pop rsi
000078d941fdd897  pop rdi
000078d941fdd898  pop rdx
000078d941fdd899  pop rcx
000078d941fdd89a  pop rax
000078d941fdd89b  add rsp, 0x08
000078d941fdd89f  jmp 0x000078D941FDBE5A
000078d941fdd8a4  sub rsp, 0x08
000078d941fdd8a8  push rax
000078d941fdd8a9  push rcx
000078d941fdd8aa  push rdx
000078d941fdd8ab  push rdi
000078d941fdd8ac  push rsi
000078d941fdd8ad  push r8
000078d941fdd8af  push r9
000078d941fdd8b1  push r10
000078d941fdd8b3  push r11
000078d941fdd8b5  sub rsp, 0xF0
000078d941fdd8bc  vmovaps [rsp], xmm0
000078d941fdd8c1  vmovaps [rsp+0x10], xmm1
000078d941fdd8c7  vmovaps [rsp+0x20], xmm2
000078d941fdd8cd  vmovaps [rsp+0x30], xmm3
000078d941fdd8d3  vmovaps [rsp+0x40], xmm4
000078d941fdd8d9  vmovaps [rsp+0x50], xmm5
000078d941fdd8df  vmovaps [rsp+0x60], xmm6
000078d941fdd8e5  vmovaps [rsp+0x70], xmm8
000078d941fdd8eb  vmovaps [rsp+0x80], xmm9
000078d941fdd8f4  vmovaps [rsp+0x90], xmm10
000078d941fdd8fd  vmovaps [rsp+0xA0], xmm11
000078d941fdd906  vmovaps [rsp+0xB0], xmm12
000078d941fdd90f  vmovaps [rsp+0xC0], xmm13
000078d941fdd918  vmovaps [rsp+0xD0], xmm14
000078d941fdd921  vmovaps [rsp+0xE0], xmm15
000078d941fdd92a  sub rsp, 0x30
000078d941fdd92e  movaps [rsp], xmm7
000078d941fdd932  movaps [rsp+0x10], xmm4
000078d941fdd937  movaps [rsp+0x20], xmm9
000078d941fdd93d  lea rdi, [rsp]
000078d941fdd941  mov esi, 0x00
000078d941fdd946  mov rax, 0x59BFBFBAA530
000078d941fdd950  call rax
000078d941fdd952  movaps xmm7, [rsp]
000078d941fdd956  add rsp, 0x30
000078d941fdd95a  vmovaps xmm0, [rsp]
000078d941fdd95f  vmovaps xmm1, [rsp+0x10]
000078d941fdd965  vmovaps xmm2, [rsp+0x20]
000078d941fdd96b  vmovaps xmm3, [rsp+0x30]
000078d941fdd971  vmovaps xmm4, [rsp+0x40]
000078d941fdd977  vmovaps xmm5, [rsp+0x50]
000078d941fdd97d  vmovaps xmm6, [rsp+0x60]
000078d941fdd983  vmovaps xmm8, [rsp+0x70]
000078d941fdd989  vmovaps xmm9, [rsp+0x80]
000078d941fdd992  vmovaps xmm10, [rsp+0x90]
000078d941fdd99b  vmovaps xmm11, [rsp+0xA0]
000078d941fdd9a4  vmovaps xmm12, [rsp+0xB0]
000078d941fdd9ad  vmovaps xmm13, [rsp+0xC0]
000078d941fdd9b6  vmovaps xmm14, [rsp+0xD0]
000078d941fdd9bf  vmovaps xmm15, [rsp+0xE0]
000078d941fdd9c8  add rsp, 0xF0
000078d941fdd9cf  pop r11
000078d941fdd9d1  pop r10
000078d941fdd9d3  pop r9
000078d941fdd9d5  pop r8
000078d941fdd9d7  pop rsi
000078d941fdd9d8  pop rdi
000078d941fdd9d9  pop rdx
000078d941fdd9da  pop rcx
000078d941fdd9db  pop rax
000078d941fdd9dc  add rsp, 0x08
000078d941fdd9e0  jmp 0x000078D941FDBE87
000078d941fdd9e5  sub rsp, 0x08
000078d941fdd9e9  push rax
000078d941fdd9ea  push rcx
000078d941fdd9eb  push rdx
000078d941fdd9ec  push rdi
000078d941fdd9ed  push rsi
000078d941fdd9ee  push r8
000078d941fdd9f0  push r9
000078d941fdd9f2  push r10
000078d941fdd9f4  push r11
000078d941fdd9f6  sub rsp, 0xF0
000078d941fdd9fd  vmovaps [rsp], xmm0
000078d941fdda02  vmovaps [rsp+0x10], xmm1
000078d941fdda08  vmovaps [rsp+0x20], xmm2
000078d941fdda0e  vmovaps [rsp+0x30], xmm3
000078d941fdda14  vmovaps [rsp+0x40], xmm5
000078d941fdda1a  vmovaps [rsp+0x50], xmm6
000078d941fdda20  vmovaps [rsp+0x60], xmm7
000078d941fdda26  vmovaps [rsp+0x70], xmm8
000078d941fdda2c  vmovaps [rsp+0x80], xmm9
000078d941fdda35  vmovaps [rsp+0x90], xmm10
000078d941fdda3e  vmovaps [rsp+0xA0], xmm11
000078d941fdda47  vmovaps [rsp+0xB0], xmm12
000078d941fdda50  vmovaps [rsp+0xC0], xmm13
000078d941fdda59  vmovaps [rsp+0xD0], xmm14
000078d941fdda62  vmovaps [rsp+0xE0], xmm15
000078d941fdda6b  sub rsp, 0x30
000078d941fdda6f  movaps [rsp], xmm4
000078d941fdda73  movaps [rsp+0x10], xmm15
000078d941fdda79  movaps [rsp+0x20], xmm9
000078d941fdda7f  lea rdi, [rsp]
000078d941fdda83  mov esi, 0x00
000078d941fdda88  mov rax, 0x59BFBFBAA530
000078d941fdda92  call rax
000078d941fdda94  movaps xmm4, [rsp]
000078d941fdda98  add rsp, 0x30
000078d941fdda9c  vmovaps xmm0, [rsp]
000078d941fddaa1  vmovaps xmm1, [rsp+0x10]
000078d941fddaa7  vmovaps xmm2, [rsp+0x20]
000078d941fddaad  vmovaps xmm3, [rsp+0x30]
000078d941fddab3  vmovaps xmm5, [rsp+0x40]
000078d941fddab9  vmovaps xmm6, [rsp+0x50]
000078d941fddabf  vmovaps xmm7, [rsp+0x60]
000078d941fddac5  vmovaps xmm8, [rsp+0x70]
000078d941fddacb  vmovaps xmm9, [rsp+0x80]
000078d941fddad4  vmovaps xmm10, [rsp+0x90]
000078d941fddadd  vmovaps xmm11, [rsp+0xA0]
000078d941fddae6  vmovaps xmm12, [rsp+0xB0]
000078d941fddaef  vmovaps xmm13, [rsp+0xC0]
000078d941fddaf8  vmovaps xmm14, [rsp+0xD0]
000078d941fddb01  vmovaps xmm15, [rsp+0xE0]
000078d941fddb0a  add rsp, 0xF0
000078d941fddb11  pop r11
000078d941fddb13  pop r10
000078d941fddb15  pop r9
000078d941fddb17  pop r8
000078d941fddb19  pop rsi
000078d941fddb1a  pop rdi
000078d941fddb1b  pop rdx
000078d941fddb1c  pop rcx
000078d941fddb1d  pop rax
000078d941fddb1e  add rsp, 0x08
000078d941fddb22  jmp 0x000078D941FDBEAC
000078d941fddb27  call 0x000078D941EC4620
000078d941fddb2c  jmp 0x000078D941FDBEB9
000078d941fddb31  sub rsp, 0x08
000078d941fddb35  push rax
000078d941fddb36  push rcx
000078d941fddb37  push rdx
000078d941fddb38  push rdi
000078d941fddb39  push rsi
000078d941fddb3a  push r8
000078d941fddb3c  push r9
000078d941fddb3e  push r10
000078d941fddb40  push r11
000078d941fddb42  sub rsp, 0xF0
000078d941fddb49  vmovaps [rsp], xmm0
000078d941fddb4e  vmovaps [rsp+0x10], xmm1
000078d941fddb54  vmovaps [rsp+0x20], xmm2
000078d941fddb5a  vmovaps [rsp+0x30], xmm4
000078d941fddb60  vmovaps [rsp+0x40], xmm5
000078d941fddb66  vmovaps [rsp+0x50], xmm6
000078d941fddb6c  vmovaps [rsp+0x60], xmm7
000078d941fddb72  vmovaps [rsp+0x70], xmm8
000078d941fddb78  vmovaps [rsp+0x80], xmm9
000078d941fddb81  vmovaps [rsp+0x90], xmm10
000078d941fddb8a  vmovaps [rsp+0xA0], xmm11
000078d941fddb93  vmovaps [rsp+0xB0], xmm12
000078d941fddb9c  vmovaps [rsp+0xC0], xmm13
000078d941fddba5  vmovaps [rsp+0xD0], xmm14
000078d941fddbae  vmovaps [rsp+0xE0], xmm15
000078d941fddbb7  sub rsp, 0x30
000078d941fddbbb  movaps [rsp], xmm3
000078d941fddbbf  movaps [rsp+0x10], xmm1
000078d941fddbc4  movaps [rsp+0x20], xmm9
000078d941fddbca  lea rdi, [rsp]
000078d941fddbce  mov esi, 0x00
000078d941fddbd3  mov rax, 0x59BFBFBAA530
000078d941fddbdd  call rax
000078d941fddbdf  movaps xmm3, [rsp]
000078d941fddbe3  add rsp, 0x30
000078d941fddbe7  vmovaps xmm0, [rsp]
000078d941fddbec  vmovaps xmm1, [rsp+0x10]
000078d941fddbf2  vmovaps xmm2, [rsp+0x20]
000078d941fddbf8  vmovaps xmm4, [rsp+0x30]
000078d941fddbfe  vmovaps xmm5, [rsp+0x40]
000078d941fddc04  vmovaps xmm6, [rsp+0x50]
000078d941fddc0a  vmovaps xmm7, [rsp+0x60]
000078d941fddc10  vmovaps xmm8, [rsp+0x70]
000078d941fddc16  vmovaps xmm9, [rsp+0x80]
000078d941fddc1f  vmovaps xmm10, [rsp+0x90]
000078d941fddc28  vmovaps xmm11, [rsp+0xA0]
000078d941fddc31  vmovaps xmm12, [rsp+0xB0]
000078d941fddc3a  vmovaps xmm13, [rsp+0xC0]
000078d941fddc43  vmovaps xmm14, [rsp+0xD0]
000078d941fddc4c  vmovaps xmm15, [rsp+0xE0]
000078d941fddc55  add rsp, 0xF0
000078d941fddc5c  pop r11
000078d941fddc5e  pop r10
000078d941fddc60  pop r9
000078d941fddc62  pop r8
000078d941fddc64  pop rsi
000078d941fddc65  pop rdi
000078d941fddc66  pop rdx
000078d941fddc67  pop rcx
000078d941fddc68  pop rax
000078d941fddc69  add rsp, 0x08
000078d941fddc6d  jmp 0x000078D941FDBEF6
000078d941fddc72  sub rsp, 0x08
000078d941fddc76  push rax
000078d941fddc77  push rcx
000078d941fddc78  push rdx
000078d941fddc79  push rdi
000078d941fddc7a  push rsi
000078d941fddc7b  push r8
000078d941fddc7d  push r9
000078d941fddc7f  push r10
000078d941fddc81  push r11
000078d941fddc83  sub rsp, 0xF0
000078d941fddc8a  vmovaps [rsp], xmm0
000078d941fddc8f  vmovaps [rsp+0x10], xmm2
000078d941fddc95  vmovaps [rsp+0x20], xmm3
000078d941fddc9b  vmovaps [rsp+0x30], xmm4
000078d941fddca1  vmovaps [rsp+0x40], xmm5
000078d941fddca7  vmovaps [rsp+0x50], xmm6
000078d941fddcad  vmovaps [rsp+0x60], xmm7
000078d941fddcb3  vmovaps [rsp+0x70], xmm8
000078d941fddcb9  vmovaps [rsp+0x80], xmm9
000078d941fddcc2  vmovaps [rsp+0x90], xmm10
000078d941fddccb  vmovaps [rsp+0xA0], xmm11
000078d941fddcd4  vmovaps [rsp+0xB0], xmm12
000078d941fddcdd  vmovaps [rsp+0xC0], xmm13
000078d941fddce6  vmovaps [rsp+0xD0], xmm14
000078d941fddcef  vmovaps [rsp+0xE0], xmm15
000078d941fddcf8  sub rsp, 0x30
000078d941fddcfc  movaps [rsp], xmm1
000078d941fddd00  movaps [rsp+0x10], xmm15
000078d941fddd06  movaps [rsp+0x20], xmm9
000078d941fddd0c  lea rdi, [rsp]
000078d941fddd10  mov esi, 0x00
000078d941fddd15  mov rax, 0x59BFBFBAA530
000078d941fddd1f  call rax
000078d941fddd21  movaps xmm1, [rsp]
000078d941fddd25  add rsp, 0x30
000078d941fddd29  vmovaps xmm0, [rsp]
000078d941fddd2e  vmovaps xmm2, [rsp+0x10]
000078d941fddd34  vmovaps xmm3, [rsp+0x20]
000078d941fddd3a  vmovaps xmm4, [rsp+0x30]
000078d941fddd40  vmovaps xmm5, [rsp+0x40]
000078d941fddd46  vmovaps xmm6, [rsp+0x50]
000078d941fddd4c  vmovaps xmm7, [rsp+0x60]
000078d941fddd52  vmovaps xmm8, [rsp+0x70]
000078d941fddd58  vmovaps xmm9, [rsp+0x80]
000078d941fddd61  vmovaps xmm10, [rsp+0x90]
000078d941fddd6a  vmovaps xmm11, [rsp+0xA0]
000078d941fddd73  vmovaps xmm12, [rsp+0xB0]
000078d941fddd7c  vmovaps xmm13, [rsp+0xC0]
000078d941fddd85  vmovaps xmm14, [rsp+0xD0]
000078d941fddd8e  vmovaps xmm15, [rsp+0xE0]
000078d941fddd97  add rsp, 0xF0
000078d941fddd9e  pop r11
000078d941fddda0  pop r10
000078d941fddda2  pop r9
000078d941fddda4  pop r8
000078d941fddda6  pop rsi
000078d941fddda7  pop rdi
000078d941fddda8  pop rdx
000078d941fddda9  pop rcx
000078d941fdddaa  pop rax
000078d941fdddab  add rsp, 0x08
000078d941fdddaf  jmp 0x000078D941FDBF7E
000078d941fdddb4  call 0x000078D941EC4620
000078d941fdddb9  jmp 0x000078D941FDBF8B
000078d941fdddbe  sub rsp, 0x08
000078d941fdddc2  push rax
000078d941fdddc3  push rcx
000078d941fdddc4  push rdx
000078d941fdddc5  push rdi
000078d941fdddc6  push rsi
000078d941fdddc7  push r8
000078d941fdddc9  push r9
000078d941fdddcb  push r10
000078d941fdddcd  push r11
000078d941fdddcf  sub rsp, 0xF0
000078d941fdddd6  vmovaps [rsp], xmm0
000078d941fddddb  vmovaps [rsp+0x10], xmm2
000078d941fddde1  vmovaps [rsp+0x20], xmm3
000078d941fddde7  vmovaps [rsp+0x30], xmm4
000078d941fddded  vmovaps [rsp+0x40], xmm5
000078d941fdddf3  vmovaps [rsp+0x50], xmm6
000078d941fdddf9  vmovaps [rsp+0x60], xmm7
000078d941fdddff  vmovaps [rsp+0x70], xmm8
000078d941fdde05  vmovaps [rsp+0x80], xmm9
000078d941fdde0e  vmovaps [rsp+0x90], xmm10
000078d941fdde17  vmovaps [rsp+0xA0], xmm11
000078d941fdde20  vmovaps [rsp+0xB0], xmm12
000078d941fdde29  vmovaps [rsp+0xC0], xmm13
000078d941fdde32  vmovaps [rsp+0xD0], xmm14
000078d941fdde3b  vmovaps [rsp+0xE0], xmm15
000078d941fdde44  sub rsp, 0x30
000078d941fdde48  movaps [rsp], xmm1
000078d941fdde4c  movaps [rsp+0x10], xmm5
000078d941fdde51  movaps [rsp+0x20], xmm7
000078d941fdde56  lea rdi, [rsp]
000078d941fdde5a  mov esi, 0x00
000078d941fdde5f  mov rax, 0x59BFBFBAA530
000078d941fdde69  call rax
000078d941fdde6b  movaps xmm1, [rsp]
000078d941fdde6f  add rsp, 0x30
000078d941fdde73  vmovaps xmm0, [rsp]
000078d941fdde78  vmovaps xmm2, [rsp+0x10]
000078d941fdde7e  vmovaps xmm3, [rsp+0x20]
000078d941fdde84  vmovaps xmm4, [rsp+0x30]
000078d941fdde8a  vmovaps xmm5, [rsp+0x40]
000078d941fdde90  vmovaps xmm6, [rsp+0x50]
000078d941fdde96  vmovaps xmm7, [rsp+0x60]
000078d941fdde9c  vmovaps xmm8, [rsp+0x70]
000078d941fddea2  vmovaps xmm9, [rsp+0x80]
000078d941fddeab  vmovaps xmm10, [rsp+0x90]
000078d941fddeb4  vmovaps xmm11, [rsp+0xA0]
000078d941fddebd  vmovaps xmm12, [rsp+0xB0]
000078d941fddec6  vmovaps xmm13, [rsp+0xC0]
000078d941fddecf  vmovaps xmm14, [rsp+0xD0]
000078d941fdded8  vmovaps xmm15, [rsp+0xE0]
000078d941fddee1  add rsp, 0xF0
000078d941fddee8  pop r11
000078d941fddeea  pop r10
000078d941fddeec  pop r9
000078d941fddeee  pop r8
000078d941fddef0  pop rsi
000078d941fddef1  pop rdi
000078d941fddef2  pop rdx
000078d941fddef3  pop rcx
000078d941fddef4  pop rax
000078d941fddef5  add rsp, 0x08
000078d941fddef9  jmp 0x000078D941FDC030
000078d941fddefe  sub rsp, 0x08
000078d941fddf02  push rax
000078d941fddf03  push rcx
000078d941fddf04  push rdx
000078d941fddf05  push rdi
000078d941fddf06  push rsi
000078d941fddf07  push r8
000078d941fddf09  push r9
000078d941fddf0b  push r10
000078d941fddf0d  push r11
000078d941fddf0f  sub rsp, 0xF0
000078d941fddf16  vmovaps [rsp], xmm0
000078d941fddf1b  vmovaps [rsp+0x10], xmm1
000078d941fddf21  vmovaps [rsp+0x20], xmm2
000078d941fddf27  vmovaps [rsp+0x30], xmm3
000078d941fddf2d  vmovaps [rsp+0x40], xmm4
000078d941fddf33  vmovaps [rsp+0x50], xmm5
000078d941fddf39  vmovaps [rsp+0x60], xmm6
000078d941fddf3f  vmovaps [rsp+0x70], xmm8
000078d941fddf45  vmovaps [rsp+0x80], xmm9
000078d941fddf4e  vmovaps [rsp+0x90], xmm10
000078d941fddf57  vmovaps [rsp+0xA0], xmm11
000078d941fddf60  vmovaps [rsp+0xB0], xmm12
000078d941fddf69  vmovaps [rsp+0xC0], xmm13
000078d941fddf72  vmovaps [rsp+0xD0], xmm14
000078d941fddf7b  vmovaps [rsp+0xE0], xmm15
000078d941fddf84  sub rsp, 0x30
000078d941fddf88  movaps [rsp], xmm7
000078d941fddf8c  movaps [rsp+0x10], xmm5
000078d941fddf91  movaps [rsp+0x20], xmm15
000078d941fddf97  lea rdi, [rsp]
000078d941fddf9b  mov esi, 0x00
000078d941fddfa0  mov rax, 0x59BFBFBAA530
000078d941fddfaa  call rax
000078d941fddfac  movaps xmm7, [rsp]
000078d941fddfb0  add rsp, 0x30
000078d941fddfb4  vmovaps xmm0, [rsp]
000078d941fddfb9  vmovaps xmm1, [rsp+0x10]
000078d941fddfbf  vmovaps xmm2, [rsp+0x20]
000078d941fddfc5  vmovaps xmm3, [rsp+0x30]
000078d941fddfcb  vmovaps xmm4, [rsp+0x40]
000078d941fddfd1  vmovaps xmm5, [rsp+0x50]
000078d941fddfd7  vmovaps xmm6, [rsp+0x60]
000078d941fddfdd  vmovaps xmm8, [rsp+0x70]
000078d941fddfe3  vmovaps xmm9, [rsp+0x80]
000078d941fddfec  vmovaps xmm10, [rsp+0x90]
000078d941fddff5  vmovaps xmm11, [rsp+0xA0]
000078d941fddffe  vmovaps xmm12, [rsp+0xB0]
000078d941fde007  vmovaps xmm13, [rsp+0xC0]
000078d941fde010  vmovaps xmm14, [rsp+0xD0]
000078d941fde019  vmovaps xmm15, [rsp+0xE0]
000078d941fde022  add rsp, 0xF0
000078d941fde029  pop r11
000078d941fde02b  pop r10
000078d941fde02d  pop r9
000078d941fde02f  pop r8
000078d941fde031  pop rsi
000078d941fde032  pop rdi
000078d941fde033  pop rdx
000078d941fde034  pop rcx
000078d941fde035  pop rax
000078d941fde036  add rsp, 0x08
000078d941fde03a  jmp 0x000078D941FDC066
000078d941fde03f  call 0x000078D941EB52F0
000078d941fde044  jmp 0x000078D941FDC073
000078d941fde049  sub rsp, 0x08
000078d941fde04d  push rax
000078d941fde04e  push rcx
000078d941fde04f  push rdx
000078d941fde050  push rdi
000078d941fde051  push rsi
000078d941fde052  push r8
000078d941fde054  push r9
000078d941fde056  push r10
000078d941fde058  push r11
000078d941fde05a  sub rsp, 0xF0
000078d941fde061  vmovaps [rsp], xmm0
000078d941fde066  vmovaps [rsp+0x10], xmm1
000078d941fde06c  vmovaps [rsp+0x20], xmm2
000078d941fde072  vmovaps [rsp+0x30], xmm3
000078d941fde078  vmovaps [rsp+0x40], xmm4
000078d941fde07e  vmovaps [rsp+0x50], xmm5
000078d941fde084  vmovaps [rsp+0x60], xmm6
000078d941fde08a  vmovaps [rsp+0x70], xmm7
000078d941fde090  vmovaps [rsp+0x80], xmm8
000078d941fde099  vmovaps [rsp+0x90], xmm9
000078d941fde0a2  vmovaps [rsp+0xA0], xmm10
000078d941fde0ab  vmovaps [rsp+0xB0], xmm11
000078d941fde0b4  vmovaps [rsp+0xC0], xmm12
000078d941fde0bd  vmovaps [rsp+0xD0], xmm13
000078d941fde0c6  vmovaps [rsp+0xE0], xmm14
000078d941fde0cf  sub rsp, 0x30
000078d941fde0d3  movaps [rsp], xmm15
000078d941fde0d8  movaps [rsp+0x10], xmm5
000078d941fde0dd  movaps [rsp+0x20], xmm3
000078d941fde0e2  lea rdi, [rsp]
000078d941fde0e6  mov esi, 0x00
000078d941fde0eb  mov rax, 0x59BFBFBAA530
000078d941fde0f5  call rax
000078d941fde0f7  movaps xmm15, [rsp]
000078d941fde0fc  add rsp, 0x30
000078d941fde100  vmovaps xmm0, [rsp]
000078d941fde105  vmovaps xmm1, [rsp+0x10]
000078d941fde10b  vmovaps xmm2, [rsp+0x20]
000078d941fde111  vmovaps xmm3, [rsp+0x30]
000078d941fde117  vmovaps xmm4, [rsp+0x40]
000078d941fde11d  vmovaps xmm5, [rsp+0x50]
000078d941fde123  vmovaps xmm6, [rsp+0x60]
000078d941fde129  vmovaps xmm7, [rsp+0x70]
000078d941fde12f  vmovaps xmm8, [rsp+0x80]
000078d941fde138  vmovaps xmm9, [rsp+0x90]
000078d941fde141  vmovaps xmm10, [rsp+0xA0]
000078d941fde14a  vmovaps xmm11, [rsp+0xB0]
000078d941fde153  vmovaps xmm12, [rsp+0xC0]
000078d941fde15c  vmovaps xmm13, [rsp+0xD0]
000078d941fde165  vmovaps xmm14, [rsp+0xE0]
000078d941fde16e  add rsp, 0xF0
000078d941fde175  pop r11
000078d941fde177  pop r10
000078d941fde179  pop r9
000078d941fde17b  pop r8
000078d941fde17d  pop rsi
000078d941fde17e  pop rdi
000078d941fde17f  pop rdx
000078d941fde180  pop rcx
000078d941fde181  pop rax
000078d941fde182  add rsp, 0x08
000078d941fde186  jmp 0x000078D941FDC099
000078d941fde18b  sub rsp, 0x08
000078d941fde18f  push rax
000078d941fde190  push rcx
000078d941fde191  push rdx
000078d941fde192  push rdi
000078d941fde193  push rsi
000078d941fde194  push r8
000078d941fde196  push r9
000078d941fde198  push r10
000078d941fde19a  push r11
000078d941fde19c  sub rsp, 0xF0
000078d941fde1a3  vmovaps [rsp], xmm0
000078d941fde1a8  vmovaps [rsp+0x10], xmm2
000078d941fde1ae  vmovaps [rsp+0x20], xmm3
000078d941fde1b4  vmovaps [rsp+0x30], xmm4
000078d941fde1ba  vmovaps [rsp+0x40], xmm5
000078d941fde1c0  vmovaps [rsp+0x50], xmm6
000078d941fde1c6  vmovaps [rsp+0x60], xmm7
000078d941fde1cc  vmovaps [rsp+0x70], xmm8
000078d941fde1d2  vmovaps [rsp+0x80], xmm9
000078d941fde1db  vmovaps [rsp+0x90], xmm10
000078d941fde1e4  vmovaps [rsp+0xA0], xmm11
000078d941fde1ed  vmovaps [rsp+0xB0], xmm12
000078d941fde1f6  vmovaps [rsp+0xC0], xmm13
000078d941fde1ff  vmovaps [rsp+0xD0], xmm14
000078d941fde208  vmovaps [rsp+0xE0], xmm15
000078d941fde211  sub rsp, 0x30
000078d941fde215  movaps [rsp], xmm1
000078d941fde219  movaps [rsp+0x10], xmm5
000078d941fde21e  movaps [rsp+0x20], xmm4
000078d941fde223  lea rdi, [rsp]
000078d941fde227  mov esi, 0x00
000078d941fde22c  mov rax, 0x59BFBFBAA530
000078d941fde236  call rax
000078d941fde238  movaps xmm1, [rsp]
000078d941fde23c  add rsp, 0x30
000078d941fde240  vmovaps xmm0, [rsp]
000078d941fde245  vmovaps xmm2, [rsp+0x10]
000078d941fde24b  vmovaps xmm3, [rsp+0x20]
000078d941fde251  vmovaps xmm4, [rsp+0x30]
000078d941fde257  vmovaps xmm5, [rsp+0x40]
000078d941fde25d  vmovaps xmm6, [rsp+0x50]
000078d941fde263  vmovaps xmm7, [rsp+0x60]
000078d941fde269  vmovaps xmm8, [rsp+0x70]
000078d941fde26f  vmovaps xmm9, [rsp+0x80]
000078d941fde278  vmovaps xmm10, [rsp+0x90]
000078d941fde281  vmovaps xmm11, [rsp+0xA0]
000078d941fde28a  vmovaps xmm12, [rsp+0xB0]
000078d941fde293  vmovaps xmm13, [rsp+0xC0]
000078d941fde29c  vmovaps xmm14, [rsp+0xD0]
000078d941fde2a5  vmovaps xmm15, [rsp+0xE0]
000078d941fde2ae  add rsp, 0xF0
000078d941fde2b5  pop r11
000078d941fde2b7  pop r10
000078d941fde2b9  pop r9
000078d941fde2bb  pop r8
000078d941fde2bd  pop rsi
000078d941fde2be  pop rdi
000078d941fde2bf  pop rdx
000078d941fde2c0  pop rcx
000078d941fde2c1  pop rax
000078d941fde2c2  add rsp, 0x08
000078d941fde2c6  jmp 0x000078D941FDC0B9
000078d941fde2cb  sub rsp, 0x08
000078d941fde2cf  push rax
000078d941fde2d0  push rcx
000078d941fde2d1  push rdx
000078d941fde2d2  push rdi
000078d941fde2d3  push rsi
000078d941fde2d4  push r8
000078d941fde2d6  push r9
000078d941fde2d8  push r10
000078d941fde2da  push r11
000078d941fde2dc  sub rsp, 0xF0
000078d941fde2e3  vmovaps [rsp], xmm0
000078d941fde2e8  vmovaps [rsp+0x10], xmm1
000078d941fde2ee  vmovaps [rsp+0x20], xmm2
000078d941fde2f4  vmovaps [rsp+0x30], xmm3
000078d941fde2fa  vmovaps [rsp+0x40], xmm5
000078d941fde300  vmovaps [rsp+0x50], xmm6
000078d941fde306  vmovaps [rsp+0x60], xmm7
000078d941fde30c  vmovaps [rsp+0x70], xmm8
000078d941fde312  vmovaps [rsp+0x80], xmm9
000078d941fde31b  vmovaps [rsp+0x90], xmm10
000078d941fde324  vmovaps [rsp+0xA0], xmm11
000078d941fde32d  vmovaps [rsp+0xB0], xmm12
000078d941fde336  vmovaps [rsp+0xC0], xmm13
000078d941fde33f  vmovaps [rsp+0xD0], xmm14
000078d941fde348  vmovaps [rsp+0xE0], xmm15
000078d941fde351  sub rsp, 0x30
000078d941fde355  movaps [rsp], xmm4
000078d941fde359  movaps [rsp+0x10], xmm3
000078d941fde35e  movaps [rsp+0x20], xmm5
000078d941fde363  lea rdi, [rsp]
000078d941fde367  mov esi, 0x00
000078d941fde36c  mov rax, 0x59BFBFBAA530
000078d941fde376  call rax
000078d941fde378  movaps xmm4, [rsp]
000078d941fde37c  add rsp, 0x30
000078d941fde380  vmovaps xmm0, [rsp]
000078d941fde385  vmovaps xmm1, [rsp+0x10]
000078d941fde38b  vmovaps xmm2, [rsp+0x20]
000078d941fde391  vmovaps xmm3, [rsp+0x30]
000078d941fde397  vmovaps xmm5, [rsp+0x40]
000078d941fde39d  vmovaps xmm6, [rsp+0x50]
000078d941fde3a3  vmovaps xmm7, [rsp+0x60]
000078d941fde3a9  vmovaps xmm8, [rsp+0x70]
000078d941fde3af  vmovaps xmm9, [rsp+0x80]
000078d941fde3b8  vmovaps xmm10, [rsp+0x90]
000078d941fde3c1  vmovaps xmm11, [rsp+0xA0]
000078d941fde3ca  vmovaps xmm12, [rsp+0xB0]
000078d941fde3d3  vmovaps xmm13, [rsp+0xC0]
000078d941fde3dc  vmovaps xmm14, [rsp+0xD0]
000078d941fde3e5  vmovaps xmm15, [rsp+0xE0]
000078d941fde3ee  add rsp, 0xF0
000078d941fde3f5  pop r11
000078d941fde3f7  pop r10
000078d941fde3f9  pop r9
000078d941fde3fb  pop r8
000078d941fde3fd  pop rsi
000078d941fde3fe  pop rdi
000078d941fde3ff  pop rdx
000078d941fde400  pop rcx
000078d941fde401  pop rax
000078d941fde402  add rsp, 0x08
000078d941fde406  jmp 0x000078D941FDC107
000078d941fde40b  call 0x000078D941EB52F0
000078d941fde410  jmp 0x000078D941FDC114
000078d941fde415  sub rsp, 0x08
000078d941fde419  push rax
000078d941fde41a  push rcx
000078d941fde41b  push rdx
000078d941fde41c  push rdi
000078d941fde41d  push rsi
000078d941fde41e  push r8
000078d941fde420  push r9
000078d941fde422  push r10
000078d941fde424  push r11
000078d941fde426  sub rsp, 0xF0
000078d941fde42d  vmovaps [rsp], xmm0
000078d941fde432  vmovaps [rsp+0x10], xmm1
000078d941fde438  vmovaps [rsp+0x20], xmm2
000078d941fde43e  vmovaps [rsp+0x30], xmm3
000078d941fde444  vmovaps [rsp+0x40], xmm4
000078d941fde44a  vmovaps [rsp+0x50], xmm6
000078d941fde450  vmovaps [rsp+0x60], xmm7
000078d941fde456  vmovaps [rsp+0x70], xmm8
000078d941fde45c  vmovaps [rsp+0x80], xmm9
000078d941fde465  vmovaps [rsp+0x90], xmm10
000078d941fde46e  vmovaps [rsp+0xA0], xmm11
000078d941fde477  vmovaps [rsp+0xB0], xmm12
000078d941fde480  vmovaps [rsp+0xC0], xmm13
000078d941fde489  vmovaps [rsp+0xD0], xmm14
000078d941fde492  vmovaps [rsp+0xE0], xmm15
000078d941fde49b  sub rsp, 0x30
000078d941fde49f  movaps [rsp], xmm5
000078d941fde4a3  movaps [rsp+0x10], xmm6
000078d941fde4a8  movaps [rsp+0x20], xmm3
000078d941fde4ad  lea rdi, [rsp]
000078d941fde4b1  mov esi, 0x00
000078d941fde4b6  mov rax, 0x59BFBFBAA530
000078d941fde4c0  call rax
000078d941fde4c2  movaps xmm5, [rsp]
000078d941fde4c6  add rsp, 0x30
000078d941fde4ca  vmovaps xmm0, [rsp]
000078d941fde4cf  vmovaps xmm1, [rsp+0x10]
000078d941fde4d5  vmovaps xmm2, [rsp+0x20]
000078d941fde4db  vmovaps xmm3, [rsp+0x30]
000078d941fde4e1  vmovaps xmm4, [rsp+0x40]
000078d941fde4e7  vmovaps xmm6, [rsp+0x50]
000078d941fde4ed  vmovaps xmm7, [rsp+0x60]
000078d941fde4f3  vmovaps xmm8, [rsp+0x70]
000078d941fde4f9  vmovaps xmm9, [rsp+0x80]
000078d941fde502  vmovaps xmm10, [rsp+0x90]
000078d941fde50b  vmovaps xmm11, [rsp+0xA0]
000078d941fde514  vmovaps xmm12, [rsp+0xB0]
000078d941fde51d  vmovaps xmm13, [rsp+0xC0]
000078d941fde526  vmovaps xmm14, [rsp+0xD0]
000078d941fde52f  vmovaps xmm15, [rsp+0xE0]
000078d941fde538  add rsp, 0xF0
000078d941fde53f  pop r11
000078d941fde541  pop r10
000078d941fde543  pop r9
000078d941fde545  pop r8
000078d941fde547  pop rsi
000078d941fde548  pop rdi
000078d941fde549  pop rdx
000078d941fde54a  pop rcx
000078d941fde54b  pop rax
000078d941fde54c  add rsp, 0x08
000078d941fde550  jmp 0x000078D941FDC13A
000078d941fde555  sub rsp, 0x08
000078d941fde559  push rax
000078d941fde55a  push rcx
000078d941fde55b  push rdx
000078d941fde55c  push rdi
000078d941fde55d  push rsi
000078d941fde55e  push r8
000078d941fde560  push r9
000078d941fde562  push r10
000078d941fde564  push r11
000078d941fde566  sub rsp, 0xF0
000078d941fde56d  vmovaps [rsp], xmm0
000078d941fde572  vmovaps [rsp+0x10], xmm1
000078d941fde578  vmovaps [rsp+0x20], xmm2
000078d941fde57e  vmovaps [rsp+0x30], xmm3
000078d941fde584  vmovaps [rsp+0x40], xmm4
000078d941fde58a  vmovaps [rsp+0x50], xmm5
000078d941fde590  vmovaps [rsp+0x60], xmm7
000078d941fde596  vmovaps [rsp+0x70], xmm8
000078d941fde59c  vmovaps [rsp+0x80], xmm9
000078d941fde5a5  vmovaps [rsp+0x90], xmm10
000078d941fde5ae  vmovaps [rsp+0xA0], xmm11
000078d941fde5b7  vmovaps [rsp+0xB0], xmm12
000078d941fde5c0  vmovaps [rsp+0xC0], xmm13
000078d941fde5c9  vmovaps [rsp+0xD0], xmm14
000078d941fde5d2  vmovaps [rsp+0xE0], xmm15
000078d941fde5db  sub rsp, 0x30
000078d941fde5df  movaps [rsp], xmm6
000078d941fde5e3  movaps [rsp+0x10], xmm9
000078d941fde5e9  movaps [rsp+0x20], xmm1
000078d941fde5ee  lea rdi, [rsp]
000078d941fde5f2  mov esi, 0x00
000078d941fde5f7  mov rax, 0x59BFBFBAA530
000078d941fde601  call rax
000078d941fde603  movaps xmm6, [rsp]
000078d941fde607  add rsp, 0x30
000078d941fde60b  vmovaps xmm0, [rsp]
000078d941fde610  vmovaps xmm1, [rsp+0x10]
000078d941fde616  vmovaps xmm2, [rsp+0x20]
000078d941fde61c  vmovaps xmm3, [rsp+0x30]
000078d941fde622  vmovaps xmm4, [rsp+0x40]
000078d941fde628  vmovaps xmm5, [rsp+0x50]
000078d941fde62e  vmovaps xmm7, [rsp+0x60]
000078d941fde634  vmovaps xmm8, [rsp+0x70]
000078d941fde63a  vmovaps xmm9, [rsp+0x80]
000078d941fde643  vmovaps xmm10, [rsp+0x90]
000078d941fde64c  vmovaps xmm11, [rsp+0xA0]
000078d941fde655  vmovaps xmm12, [rsp+0xB0]
000078d941fde65e  vmovaps xmm13, [rsp+0xC0]
000078d941fde667  vmovaps xmm14, [rsp+0xD0]
000078d941fde670  vmovaps xmm15, [rsp+0xE0]
000078d941fde679  add rsp, 0xF0
000078d941fde680  pop r11
000078d941fde682  pop r10
000078d941fde684  pop r9
000078d941fde686  pop r8
000078d941fde688  pop rsi
000078d941fde689  pop rdi
000078d941fde68a  pop rdx
000078d941fde68b  pop rcx
000078d941fde68c  pop rax
000078d941fde68d  add rsp, 0x08
000078d941fde691  jmp 0x000078D941FDC15E
000078d941fde696  sub rsp, 0x08
000078d941fde69a  push rax
000078d941fde69b  push rcx
000078d941fde69c  push rdx
000078d941fde69d  push rdi
000078d941fde69e  push rsi
000078d941fde69f  push r8
000078d941fde6a1  push r9
000078d941fde6a3  push r10
000078d941fde6a5  push r11
000078d941fde6a7  sub rsp, 0xF0
000078d941fde6ae  vmovaps [rsp], xmm0
000078d941fde6b3  vmovaps [rsp+0x10], xmm1
000078d941fde6b9  vmovaps [rsp+0x20], xmm2
000078d941fde6bf  vmovaps [rsp+0x30], xmm3
000078d941fde6c5  vmovaps [rsp+0x40], xmm4
000078d941fde6cb  vmovaps [rsp+0x50], xmm5
000078d941fde6d1  vmovaps [rsp+0x60], xmm6
000078d941fde6d7  vmovaps [rsp+0x70], xmm7
000078d941fde6dd  vmovaps [rsp+0x80], xmm8
000078d941fde6e6  vmovaps [rsp+0x90], xmm10
000078d941fde6ef  vmovaps [rsp+0xA0], xmm11
000078d941fde6f8  vmovaps [rsp+0xB0], xmm12
000078d941fde701  vmovaps [rsp+0xC0], xmm13
000078d941fde70a  vmovaps [rsp+0xD0], xmm14
000078d941fde713  vmovaps [rsp+0xE0], xmm15
000078d941fde71c  sub rsp, 0x30
000078d941fde720  movaps [rsp], xmm9
000078d941fde725  movaps [rsp+0x10], xmm3
000078d941fde72a  movaps [rsp+0x20], xmm1
000078d941fde72f  lea rdi, [rsp]
000078d941fde733  mov esi, 0x00
000078d941fde738  mov rax, 0x59BFBFBAA530
000078d941fde742  call rax
000078d941fde744  movaps xmm9, [rsp]
000078d941fde749  add rsp, 0x30
000078d941fde74d  vmovaps xmm0, [rsp]
000078d941fde752  vmovaps xmm1, [rsp+0x10]
000078d941fde758  vmovaps xmm2, [rsp+0x20]
000078d941fde75e  vmovaps xmm3, [rsp+0x30]
000078d941fde764  vmovaps xmm4, [rsp+0x40]
000078d941fde76a  vmovaps xmm5, [rsp+0x50]
000078d941fde770  vmovaps xmm6, [rsp+0x60]
000078d941fde776  vmovaps xmm7, [rsp+0x70]
000078d941fde77c  vmovaps xmm8, [rsp+0x80]
000078d941fde785  vmovaps xmm10, [rsp+0x90]
000078d941fde78e  vmovaps xmm11, [rsp+0xA0]
000078d941fde797  vmovaps xmm12, [rsp+0xB0]
000078d941fde7a0  vmovaps xmm13, [rsp+0xC0]
000078d941fde7a9  vmovaps xmm14, [rsp+0xD0]
000078d941fde7b2  vmovaps xmm15, [rsp+0xE0]
000078d941fde7bb  add rsp, 0xF0
000078d941fde7c2  pop r11
000078d941fde7c4  pop r10
000078d941fde7c6  pop r9
000078d941fde7c8  pop r8
000078d941fde7ca  pop rsi
000078d941fde7cb  pop rdi
000078d941fde7cc  pop rdx
000078d941fde7cd  pop rcx
000078d941fde7ce  pop rax
000078d941fde7cf  add rsp, 0x08
000078d941fde7d3  jmp 0x000078D941FDC1AA
000078d941fde7d8  call 0x000078D941EB52F0
000078d941fde7dd  jmp 0x000078D941FDC1B7
000078d941fde7e2  sub rsp, 0x08
000078d941fde7e6  push rax
000078d941fde7e7  push rcx
000078d941fde7e8  push rdx
000078d941fde7e9  push rdi
000078d941fde7ea  push rsi
000078d941fde7eb  push r8
000078d941fde7ed  push r9
000078d941fde7ef  push r10
000078d941fde7f1  push r11
000078d941fde7f3  sub rsp, 0xF0
000078d941fde7fa  vmovaps [rsp], xmm0
000078d941fde7ff  vmovaps [rsp+0x10], xmm1
000078d941fde805  vmovaps [rsp+0x20], xmm2
000078d941fde80b  vmovaps [rsp+0x30], xmm3
000078d941fde811  vmovaps [rsp+0x40], xmm4
000078d941fde817  vmovaps [rsp+0x50], xmm5
000078d941fde81d  vmovaps [rsp+0x60], xmm6
000078d941fde823  vmovaps [rsp+0x70], xmm7
000078d941fde829  vmovaps [rsp+0x80], xmm8
000078d941fde832  vmovaps [rsp+0x90], xmm9
000078d941fde83b  vmovaps [rsp+0xA0], xmm10
000078d941fde844  vmovaps [rsp+0xB0], xmm11
000078d941fde84d  vmovaps [rsp+0xC0], xmm12
000078d941fde856  vmovaps [rsp+0xD0], xmm13
000078d941fde85f  vmovaps [rsp+0xE0], xmm14
000078d941fde868  sub rsp, 0x30
000078d941fde86c  movaps [rsp], xmm15
000078d941fde871  movaps [rsp+0x10], xmm3
000078d941fde876  movaps [rsp+0x20], xmm7
000078d941fde87b  lea rdi, [rsp]
000078d941fde87f  mov esi, 0x00
000078d941fde884  mov rax, 0x59BFBFBAA530
000078d941fde88e  call rax
000078d941fde890  movaps xmm15, [rsp]
000078d941fde895  add rsp, 0x30
000078d941fde899  vmovaps xmm0, [rsp]
000078d941fde89e  vmovaps xmm1, [rsp+0x10]
000078d941fde8a4  vmovaps xmm2, [rsp+0x20]
000078d941fde8aa  vmovaps xmm3, [rsp+0x30]
000078d941fde8b0  vmovaps xmm4, [rsp+0x40]
000078d941fde8b6  vmovaps xmm5, [rsp+0x50]
000078d941fde8bc  vmovaps xmm6, [rsp+0x60]
000078d941fde8c2  vmovaps xmm7, [rsp+0x70]
000078d941fde8c8  vmovaps xmm8, [rsp+0x80]
000078d941fde8d1  vmovaps xmm9, [rsp+0x90]
000078d941fde8da  vmovaps xmm10, [rsp+0xA0]
000078d941fde8e3  vmovaps xmm11, [rsp+0xB0]
000078d941fde8ec  vmovaps xmm12, [rsp+0xC0]
000078d941fde8f5  vmovaps xmm13, [rsp+0xD0]
000078d941fde8fe  vmovaps xmm14, [rsp+0xE0]
000078d941fde907  add rsp, 0xF0
000078d941fde90e  pop r11
000078d941fde910  pop r10
000078d941fde912  pop r9
000078d941fde914  pop r8
000078d941fde916  pop rsi
000078d941fde917  pop rdi
000078d941fde918  pop rdx
000078d941fde919  pop rcx
000078d941fde91a  pop rax
000078d941fde91b  add rsp, 0x08
000078d941fde91f  jmp 0x000078D941FDC1E3
000078d941fde924  sub rsp, 0x08
000078d941fde928  push rax
000078d941fde929  push rcx
000078d941fde92a  push rdx
000078d941fde92b  push rdi
000078d941fde92c  push rsi
000078d941fde92d  push r8
000078d941fde92f  push r9
000078d941fde931  push r10
000078d941fde933  push r11
000078d941fde935  sub rsp, 0xF0
000078d941fde93c  vmovaps [rsp], xmm0
000078d941fde941  vmovaps [rsp+0x10], xmm1
000078d941fde947  vmovaps [rsp+0x20], xmm2
000078d941fde94d  vmovaps [rsp+0x30], xmm4
000078d941fde953  vmovaps [rsp+0x40], xmm5
000078d941fde959  vmovaps [rsp+0x50], xmm6
000078d941fde95f  vmovaps [rsp+0x60], xmm7
000078d941fde965  vmovaps [rsp+0x70], xmm8
000078d941fde96b  vmovaps [rsp+0x80], xmm9
000078d941fde974  vmovaps [rsp+0x90], xmm10
000078d941fde97d  vmovaps [rsp+0xA0], xmm11
000078d941fde986  vmovaps [rsp+0xB0], xmm12
000078d941fde98f  vmovaps [rsp+0xC0], xmm13
000078d941fde998  vmovaps [rsp+0xD0], xmm14
000078d941fde9a1  vmovaps [rsp+0xE0], xmm15
000078d941fde9aa  sub rsp, 0x30
000078d941fde9ae  movaps [rsp], xmm3
000078d941fde9b2  movaps [rsp+0x10], xmm1
000078d941fde9b7  movaps [rsp+0x20], xmm15
000078d941fde9bd  lea rdi, [rsp]
000078d941fde9c1  mov esi, 0x00
000078d941fde9c6  mov rax, 0x59BFBFBAA530
000078d941fde9d0  call rax
000078d941fde9d2  movaps xmm3, [rsp]
000078d941fde9d6  add rsp, 0x30
000078d941fde9da  vmovaps xmm0, [rsp]
000078d941fde9df  vmovaps xmm1, [rsp+0x10]
000078d941fde9e5  vmovaps xmm2, [rsp+0x20]
000078d941fde9eb  vmovaps xmm4, [rsp+0x30]
000078d941fde9f1  vmovaps xmm5, [rsp+0x40]
000078d941fde9f7  vmovaps xmm6, [rsp+0x50]
000078d941fde9fd  vmovaps xmm7, [rsp+0x60]
000078d941fdea03  vmovaps xmm8, [rsp+0x70]
000078d941fdea09  vmovaps xmm9, [rsp+0x80]
000078d941fdea12  vmovaps xmm10, [rsp+0x90]
000078d941fdea1b  vmovaps xmm11, [rsp+0xA0]
000078d941fdea24  vmovaps xmm12, [rsp+0xB0]
000078d941fdea2d  vmovaps xmm13, [rsp+0xC0]
000078d941fdea36  vmovaps xmm14, [rsp+0xD0]
000078d941fdea3f  vmovaps xmm15, [rsp+0xE0]
000078d941fdea48  add rsp, 0xF0
000078d941fdea4f  pop r11
000078d941fdea51  pop r10
000078d941fdea53  pop r9
000078d941fdea55  pop r8
000078d941fdea57  pop rsi
000078d941fdea58  pop rdi
000078d941fdea59  pop rdx
000078d941fdea5a  pop rcx
000078d941fdea5b  pop rax
000078d941fdea5c  add rsp, 0x08
000078d941fdea60  jmp 0x000078D941FDC272
000078d941fdea65  call 0x000078D941EB52F0
000078d941fdea6a  jmp 0x000078D941FDC27C
000078d941fdea6f  sub rsp, 0x08
000078d941fdea73  push rax
000078d941fdea74  push rcx
000078d941fdea75  push rdx
000078d941fdea76  push rdi
000078d941fdea77  push rsi
000078d941fdea78  push r8
000078d941fdea7a  push r9
000078d941fdea7c  push r10
000078d941fdea7e  push r11
000078d941fdea80  sub rsp, 0xF0
000078d941fdea87  vmovaps [rsp], xmm0
000078d941fdea8c  vmovaps [rsp+0x10], xmm1
000078d941fdea92  vmovaps [rsp+0x20], xmm2
000078d941fdea98  vmovaps [rsp+0x30], xmm3
000078d941fdea9e  vmovaps [rsp+0x40], xmm4
000078d941fdeaa4  vmovaps [rsp+0x50], xmm5
000078d941fdeaaa  vmovaps [rsp+0x60], xmm6
000078d941fdeab0  vmovaps [rsp+0x70], xmm7
000078d941fdeab6  vmovaps [rsp+0x80], xmm8
000078d941fdeabf  vmovaps [rsp+0x90], xmm9
000078d941fdeac8  vmovaps [rsp+0xA0], xmm10
000078d941fdead1  vmovaps [rsp+0xB0], xmm11
000078d941fdeada  vmovaps [rsp+0xC0], xmm12
000078d941fdeae3  vmovaps [rsp+0xD0], xmm13
000078d941fdeaec  vmovaps [rsp+0xE0], xmm14
000078d941fdeaf5  sub rsp, 0x30
000078d941fdeaf9  movaps [rsp], xmm15
000078d941fdeafe  movaps [rsp+0x10], xmm14
000078d941fdeb04  movaps [rsp+0x20], xmm4
000078d941fdeb09  lea rdi, [rsp]
000078d941fdeb0d  mov esi, 0x00
000078d941fdeb12  mov rax, 0x59BFBFBAA530
000078d941fdeb1c  call rax
000078d941fdeb1e  movaps xmm15, [rsp]
000078d941fdeb23  add rsp, 0x30
000078d941fdeb27  vmovaps xmm0, [rsp]
000078d941fdeb2c  vmovaps xmm1, [rsp+0x10]
000078d941fdeb32  vmovaps xmm2, [rsp+0x20]
000078d941fdeb38  vmovaps xmm3, [rsp+0x30]
000078d941fdeb3e  vmovaps xmm4, [rsp+0x40]
000078d941fdeb44  vmovaps xmm5, [rsp+0x50]
000078d941fdeb4a  vmovaps xmm6, [rsp+0x60]
000078d941fdeb50  vmovaps xmm7, [rsp+0x70]
000078d941fdeb56  vmovaps xmm8, [rsp+0x80]
000078d941fdeb5f  vmovaps xmm9, [rsp+0x90]
000078d941fdeb68  vmovaps xmm10, [rsp+0xA0]
000078d941fdeb71  vmovaps xmm11, [rsp+0xB0]
000078d941fdeb7a  vmovaps xmm12, [rsp+0xC0]
000078d941fdeb83  vmovaps xmm13, [rsp+0xD0]
000078d941fdeb8c  vmovaps xmm14, [rsp+0xE0]
000078d941fdeb95  add rsp, 0xF0
000078d941fdeb9c  pop r11
000078d941fdeb9e  pop r10
000078d941fdeba0  pop r9
000078d941fdeba2  pop r8
000078d941fdeba4  pop rsi
000078d941fdeba5  pop rdi
000078d941fdeba6  pop rdx
000078d941fdeba7  pop rcx
000078d941fdeba8  pop rax
000078d941fdeba9  add rsp, 0x08
000078d941fdebad  jmp 0x000078D941FDC2AA
000078d941fdebb2  sub rsp, 0x08
000078d941fdebb6  push rax
000078d941fdebb7  push rcx
000078d941fdebb8  push rdx
000078d941fdebb9  push rdi
000078d941fdebba  push rsi
000078d941fdebbb  push r8
000078d941fdebbd  push r9
000078d941fdebbf  push r10
000078d941fdebc1  push r11
000078d941fdebc3  sub rsp, 0xF0
000078d941fdebca  vmovaps [rsp], xmm0
000078d941fdebcf  vmovaps [rsp+0x10], xmm1
000078d941fdebd5  vmovaps [rsp+0x20], xmm2
000078d941fdebdb  vmovaps [rsp+0x30], xmm3
000078d941fdebe1  vmovaps [rsp+0x40], xmm4
000078d941fdebe7  vmovaps [rsp+0x50], xmm5
000078d941fdebed  vmovaps [rsp+0x60], xmm6
000078d941fdebf3  vmovaps [rsp+0x70], xmm7
000078d941fdebf9  vmovaps [rsp+0x80], xmm8
000078d941fdec02  vmovaps [rsp+0x90], xmm9
000078d941fdec0b  vmovaps [rsp+0xA0], xmm10
000078d941fdec14  vmovaps [rsp+0xB0], xmm11
000078d941fdec1d  vmovaps [rsp+0xC0], xmm12
000078d941fdec26  vmovaps [rsp+0xD0], xmm13
000078d941fdec2f  vmovaps [rsp+0xE0], xmm15
000078d941fdec38  sub rsp, 0x30
000078d941fdec3c  movaps [rsp], xmm14
000078d941fdec41  movaps [rsp+0x10], xmm2
000078d941fdec46  movaps [rsp+0x20], xmm1
000078d941fdec4b  lea rdi, [rsp]
000078d941fdec4f  mov esi, 0x00
000078d941fdec54  mov rax, 0x59BFBFBAA530
000078d941fdec5e  call rax
000078d941fdec60  movaps xmm14, [rsp]
000078d941fdec65  add rsp, 0x30
000078d941fdec69  vmovaps xmm0, [rsp]
000078d941fdec6e  vmovaps xmm1, [rsp+0x10]
000078d941fdec74  vmovaps xmm2, [rsp+0x20]
000078d941fdec7a  vmovaps xmm3, [rsp+0x30]
000078d941fdec80  vmovaps xmm4, [rsp+0x40]
000078d941fdec86  vmovaps xmm5, [rsp+0x50]
000078d941fdec8c  vmovaps xmm6, [rsp+0x60]
000078d941fdec92  vmovaps xmm7, [rsp+0x70]
000078d941fdec98  vmovaps xmm8, [rsp+0x80]
000078d941fdeca1  vmovaps xmm9, [rsp+0x90]
000078d941fdecaa  vmovaps xmm10, [rsp+0xA0]
000078d941fdecb3  vmovaps xmm11, [rsp+0xB0]
000078d941fdecbc  vmovaps xmm12, [rsp+0xC0]
000078d941fdecc5  vmovaps xmm13, [rsp+0xD0]
000078d941fdecce  vmovaps xmm15, [rsp+0xE0]
000078d941fdecd7  add rsp, 0xF0
000078d941fdecde  pop r11
000078d941fdece0  pop r10
000078d941fdece2  pop r9
000078d941fdece4  pop r8
000078d941fdece6  pop rsi
000078d941fdece7  pop rdi
000078d941fdece8  pop rdx
000078d941fdece9  pop rcx
000078d941fdecea  pop rax
000078d941fdeceb  add rsp, 0x08
000078d941fdecef  jmp 0x000078D941FDC2D0
000078d941fdecf4  sub rsp, 0x08
000078d941fdecf8  push rax
000078d941fdecf9  push rcx
000078d941fdecfa  push rdx
000078d941fdecfb  push rdi
000078d941fdecfc  push rsi
000078d941fdecfd  push r8
000078d941fdecff  push r9
000078d941fded01  push r10
000078d941fded03  push r11
000078d941fded05  sub rsp, 0xF0
000078d941fded0c  vmovaps [rsp], xmm0
000078d941fded11  vmovaps [rsp+0x10], xmm2
000078d941fded17  vmovaps [rsp+0x20], xmm3
000078d941fded1d  vmovaps [rsp+0x30], xmm4
000078d941fded23  vmovaps [rsp+0x40], xmm5
000078d941fded29  vmovaps [rsp+0x50], xmm6
000078d941fded2f  vmovaps [rsp+0x60], xmm7
000078d941fded35  vmovaps [rsp+0x70], xmm8
000078d941fded3b  vmovaps [rsp+0x80], xmm9
000078d941fded44  vmovaps [rsp+0x90], xmm10
000078d941fded4d  vmovaps [rsp+0xA0], xmm11
000078d941fded56  vmovaps [rsp+0xB0], xmm12
000078d941fded5f  vmovaps [rsp+0xC0], xmm13
000078d941fded68  vmovaps [rsp+0xD0], xmm14
000078d941fded71  vmovaps [rsp+0xE0], xmm15
000078d941fded7a  sub rsp, 0x30
000078d941fded7e  movaps [rsp], xmm1
000078d941fded82  movaps [rsp+0x10], xmm4
000078d941fded87  movaps [rsp+0x20], xmm9
000078d941fded8d  lea rdi, [rsp]
000078d941fded91  mov esi, 0x00
000078d941fded96  mov rax, 0x59BFBFBAA530
000078d941fdeda0  call rax
000078d941fdeda2  movaps xmm1, [rsp]
000078d941fdeda6  add rsp, 0x30
000078d941fdedaa  vmovaps xmm0, [rsp]
000078d941fdedaf  vmovaps xmm2, [rsp+0x10]
000078d941fdedb5  vmovaps xmm3, [rsp+0x20]
000078d941fdedbb  vmovaps xmm4, [rsp+0x30]
000078d941fdedc1  vmovaps xmm5, [rsp+0x40]
000078d941fdedc7  vmovaps xmm6, [rsp+0x50]
000078d941fdedcd  vmovaps xmm7, [rsp+0x60]
000078d941fdedd3  vmovaps xmm8, [rsp+0x70]
000078d941fdedd9  vmovaps xmm9, [rsp+0x80]
000078d941fdede2  vmovaps xmm10, [rsp+0x90]
000078d941fdedeb  vmovaps xmm11, [rsp+0xA0]
000078d941fdedf4  vmovaps xmm12, [rsp+0xB0]
000078d941fdedfd  vmovaps xmm13, [rsp+0xC0]
000078d941fdee06  vmovaps xmm14, [rsp+0xD0]
000078d941fdee0f  vmovaps xmm15, [rsp+0xE0]
000078d941fdee18  add rsp, 0xF0
000078d941fdee1f  pop r11
000078d941fdee21  pop r10
000078d941fdee23  pop r9
000078d941fdee25  pop r8
000078d941fdee27  pop rsi
000078d941fdee28  pop rdi
000078d941fdee29  pop rdx
000078d941fdee2a  pop rcx
000078d941fdee2b  pop rax
000078d941fdee2c  add rsp, 0x08
000078d941fdee30  jmp 0x000078D941FDC2EE
000078d941fdee35  sub rsp, 0x08
000078d941fdee39  push rax
000078d941fdee3a  push rcx
000078d941fdee3b  push rdx
000078d941fdee3c  push rdi
000078d941fdee3d  push rsi
000078d941fdee3e  push r8
000078d941fdee40  push r9
000078d941fdee42  push r10
000078d941fdee44  push r11
000078d941fdee46  sub rsp, 0xF0
000078d941fdee4d  vmovaps [rsp], xmm0
000078d941fdee52  vmovaps [rsp+0x10], xmm1
000078d941fdee58  vmovaps [rsp+0x20], xmm2
000078d941fdee5e  vmovaps [rsp+0x30], xmm3
000078d941fdee64  vmovaps [rsp+0x40], xmm5
000078d941fdee6a  vmovaps [rsp+0x50], xmm6
000078d941fdee70  vmovaps [rsp+0x60], xmm7
000078d941fdee76  vmovaps [rsp+0x70], xmm8
000078d941fdee7c  vmovaps [rsp+0x80], xmm9
000078d941fdee85  vmovaps [rsp+0x90], xmm10
000078d941fdee8e  vmovaps [rsp+0xA0], xmm11
000078d941fdee97  vmovaps [rsp+0xB0], xmm12
000078d941fdeea0  vmovaps [rsp+0xC0], xmm13
000078d941fdeea9  vmovaps [rsp+0xD0], xmm14
000078d941fdeeb2  vmovaps [rsp+0xE0], xmm15
000078d941fdeebb  sub rsp, 0x30
000078d941fdeebf  movaps [rsp], xmm4
000078d941fdeec3  movaps [rsp+0x10], xmm2
000078d941fdeec8  movaps [rsp+0x20], xmm9
000078d941fdeece  lea rdi, [rsp]
000078d941fdeed2  mov esi, 0x00
000078d941fdeed7  mov rax, 0x59BFBFBAA530
000078d941fdeee1  call rax
000078d941fdeee3  movaps xmm4, [rsp]
000078d941fdeee7  add rsp, 0x30
000078d941fdeeeb  vmovaps xmm0, [rsp]
000078d941fdeef0  vmovaps xmm1, [rsp+0x10]
000078d941fdeef6  vmovaps xmm2, [rsp+0x20]
000078d941fdeefc  vmovaps xmm3, [rsp+0x30]
000078d941fdef02  vmovaps xmm5, [rsp+0x40]
000078d941fdef08  vmovaps xmm6, [rsp+0x50]
000078d941fdef0e  vmovaps xmm7, [rsp+0x60]
000078d941fdef14  vmovaps xmm8, [rsp+0x70]
000078d941fdef1a  vmovaps xmm9, [rsp+0x80]
000078d941fdef23  vmovaps xmm10, [rsp+0x90]
000078d941fdef2c  vmovaps xmm11, [rsp+0xA0]
000078d941fdef35  vmovaps xmm12, [rsp+0xB0]
000078d941fdef3e  vmovaps xmm13, [rsp+0xC0]
000078d941fdef47  vmovaps xmm14, [rsp+0xD0]
000078d941fdef50  vmovaps xmm15, [rsp+0xE0]
000078d941fdef59  add rsp, 0xF0
000078d941fdef60  pop r11
000078d941fdef62  pop r10
000078d941fdef64  pop r9
000078d941fdef66  pop r8
000078d941fdef68  pop rsi
000078d941fdef69  pop rdi
000078d941fdef6a  pop rdx
000078d941fdef6b  pop rcx
000078d941fdef6c  pop rax
000078d941fdef6d  add rsp, 0x08
000078d941fdef71  jmp 0x000078D941FDC31E
000078d941fdef76  sub rsp, 0x08
000078d941fdef7a  push rax
000078d941fdef7b  push rcx
000078d941fdef7c  push rdx
000078d941fdef7d  push rdi
000078d941fdef7e  push rsi
000078d941fdef7f  push r8
000078d941fdef81  push r9
000078d941fdef83  push r10
000078d941fdef85  push r11
000078d941fdef87  sub rsp, 0xF0
000078d941fdef8e  vmovaps [rsp], xmm0
000078d941fdef93  vmovaps [rsp+0x10], xmm1
000078d941fdef99  vmovaps [rsp+0x20], xmm2
000078d941fdef9f  vmovaps [rsp+0x30], xmm3
000078d941fdefa5  vmovaps [rsp+0x40], xmm4
000078d941fdefab  vmovaps [rsp+0x50], xmm5
000078d941fdefb1  vmovaps [rsp+0x60], xmm6
000078d941fdefb7  vmovaps [rsp+0x70], xmm7
000078d941fdefbd  vmovaps [rsp+0x80], xmm8
000078d941fdefc6  vmovaps [rsp+0x90], xmm10
000078d941fdefcf  vmovaps [rsp+0xA0], xmm11
000078d941fdefd8  vmovaps [rsp+0xB0], xmm12
000078d941fdefe1  vmovaps [rsp+0xC0], xmm13
000078d941fdefea  vmovaps [rsp+0xD0], xmm14
000078d941fdeff3  vmovaps [rsp+0xE0], xmm15
000078d941fdeffc  sub rsp, 0x30
000078d941fdf000  movaps [rsp], xmm9
000078d941fdf005  movaps [rsp+0x10], xmm2
000078d941fdf00a  movaps [rsp+0x20], xmm1
000078d941fdf00f  lea rdi, [rsp]
000078d941fdf013  mov esi, 0x00
000078d941fdf018  mov rax, 0x59BFBFBAA530
000078d941fdf022  call rax
000078d941fdf024  movaps xmm9, [rsp]
000078d941fdf029  add rsp, 0x30
000078d941fdf02d  vmovaps xmm0, [rsp]
000078d941fdf032  vmovaps xmm1, [rsp+0x10]
000078d941fdf038  vmovaps xmm2, [rsp+0x20]
000078d941fdf03e  vmovaps xmm3, [rsp+0x30]
000078d941fdf044  vmovaps xmm4, [rsp+0x40]
000078d941fdf04a  vmovaps xmm5, [rsp+0x50]
000078d941fdf050  vmovaps xmm6, [rsp+0x60]
000078d941fdf056  vmovaps xmm7, [rsp+0x70]
000078d941fdf05c  vmovaps xmm8, [rsp+0x80]
000078d941fdf065  vmovaps xmm10, [rsp+0x90]
000078d941fdf06e  vmovaps xmm11, [rsp+0xA0]
000078d941fdf077  vmovaps xmm12, [rsp+0xB0]
000078d941fdf080  vmovaps xmm13, [rsp+0xC0]
000078d941fdf089  vmovaps xmm14, [rsp+0xD0]
000078d941fdf092  vmovaps xmm15, [rsp+0xE0]
000078d941fdf09b  add rsp, 0xF0
000078d941fdf0a2  pop r11
000078d941fdf0a4  pop r10
000078d941fdf0a6  pop r9
000078d941fdf0a8  pop r8
000078d941fdf0aa  pop rsi
000078d941fdf0ab  pop rdi
000078d941fdf0ac  pop rdx
000078d941fdf0ad  pop rcx
000078d941fdf0ae  pop rax
000078d941fdf0af  add rsp, 0x08
000078d941fdf0b3  jmp 0x000078D941FDC354
000078d941fdf0b8  sub rsp, 0x08
000078d941fdf0bc  push rax
000078d941fdf0bd  push rcx
000078d941fdf0be  push rdx
000078d941fdf0bf  push rdi
000078d941fdf0c0  push rsi
000078d941fdf0c1  push r8
000078d941fdf0c3  push r9
000078d941fdf0c5  push r10
000078d941fdf0c7  push r11
000078d941fdf0c9  sub rsp, 0xF0
000078d941fdf0d0  vmovaps [rsp], xmm0
000078d941fdf0d5  vmovaps [rsp+0x10], xmm2
000078d941fdf0db  vmovaps [rsp+0x20], xmm3
000078d941fdf0e1  vmovaps [rsp+0x30], xmm4
000078d941fdf0e7  vmovaps [rsp+0x40], xmm5
000078d941fdf0ed  vmovaps [rsp+0x50], xmm6
000078d941fdf0f3  vmovaps [rsp+0x60], xmm7
000078d941fdf0f9  vmovaps [rsp+0x70], xmm8
000078d941fdf0ff  vmovaps [rsp+0x80], xmm9
000078d941fdf108  vmovaps [rsp+0x90], xmm10
000078d941fdf111  vmovaps [rsp+0xA0], xmm11
000078d941fdf11a  vmovaps [rsp+0xB0], xmm12
000078d941fdf123  vmovaps [rsp+0xC0], xmm13
000078d941fdf12c  vmovaps [rsp+0xD0], xmm14
000078d941fdf135  vmovaps [rsp+0xE0], xmm15
000078d941fdf13e  sub rsp, 0x30
000078d941fdf142  movaps [rsp], xmm1
000078d941fdf146  movaps [rsp+0x10], xmm15
000078d941fdf14c  movaps [rsp+0x20], xmm6
000078d941fdf151  lea rdi, [rsp]
000078d941fdf155  mov esi, 0x00
000078d941fdf15a  mov rax, 0x59BFBFBAA530
000078d941fdf164  call rax
000078d941fdf166  movaps xmm1, [rsp]
000078d941fdf16a  add rsp, 0x30
000078d941fdf16e  vmovaps xmm0, [rsp]
000078d941fdf173  vmovaps xmm2, [rsp+0x10]
000078d941fdf179  vmovaps xmm3, [rsp+0x20]
000078d941fdf17f  vmovaps xmm4, [rsp+0x30]
000078d941fdf185  vmovaps xmm5, [rsp+0x40]
000078d941fdf18b  vmovaps xmm6, [rsp+0x50]
000078d941fdf191  vmovaps xmm7, [rsp+0x60]
000078d941fdf197  vmovaps xmm8, [rsp+0x70]
000078d941fdf19d  vmovaps xmm9, [rsp+0x80]
000078d941fdf1a6  vmovaps xmm10, [rsp+0x90]
000078d941fdf1af  vmovaps xmm11, [rsp+0xA0]
000078d941fdf1b8  vmovaps xmm12, [rsp+0xB0]
000078d941fdf1c1  vmovaps xmm13, [rsp+0xC0]
000078d941fdf1ca  vmovaps xmm14, [rsp+0xD0]
000078d941fdf1d3  vmovaps xmm15, [rsp+0xE0]
000078d941fdf1dc  add rsp, 0xF0
000078d941fdf1e3  pop r11
000078d941fdf1e5  pop r10
000078d941fdf1e7  pop r9
000078d941fdf1e9  pop r8
000078d941fdf1eb  pop rsi
000078d941fdf1ec  pop rdi
000078d941fdf1ed  pop rdx
000078d941fdf1ee  pop rcx
000078d941fdf1ef  pop rax
000078d941fdf1f0  add rsp, 0x08
000078d941fdf1f4  jmp 0x000078D941FDC375
000078d941fdf1f9  sub rsp, 0x08
000078d941fdf1fd  push rax
000078d941fdf1fe  push rcx
000078d941fdf1ff  push rdx
000078d941fdf200  push rdi
000078d941fdf201  push rsi
000078d941fdf202  push r8
000078d941fdf204  push r9
000078d941fdf206  push r10
000078d941fdf208  push r11
000078d941fdf20a  sub rsp, 0xF0
000078d941fdf211  vmovaps [rsp], xmm0
000078d941fdf216  vmovaps [rsp+0x10], xmm1
000078d941fdf21c  vmovaps [rsp+0x20], xmm2
000078d941fdf222  vmovaps [rsp+0x30], xmm3
000078d941fdf228  vmovaps [rsp+0x40], xmm4
000078d941fdf22e  vmovaps [rsp+0x50], xmm5
000078d941fdf234  vmovaps [rsp+0x60], xmm6
000078d941fdf23a  vmovaps [rsp+0x70], xmm7
000078d941fdf240  vmovaps [rsp+0x80], xmm8
000078d941fdf249  vmovaps [rsp+0x90], xmm9
000078d941fdf252  vmovaps [rsp+0xA0], xmm10
000078d941fdf25b  vmovaps [rsp+0xB0], xmm11
000078d941fdf264  vmovaps [rsp+0xC0], xmm12
000078d941fdf26d  vmovaps [rsp+0xD0], xmm13
000078d941fdf276  vmovaps [rsp+0xE0], xmm14
000078d941fdf27f  sub rsp, 0x30
000078d941fdf283  movaps [rsp], xmm15
000078d941fdf288  movaps [rsp+0x10], xmm5
000078d941fdf28d  movaps [rsp+0x20], xmm3
000078d941fdf292  lea rdi, [rsp]
000078d941fdf296  mov esi, 0x00
000078d941fdf29b  mov rax, 0x59BFBFBAA530
000078d941fdf2a5  call rax
000078d941fdf2a7  movaps xmm15, [rsp]
000078d941fdf2ac  add rsp, 0x30
000078d941fdf2b0  vmovaps xmm0, [rsp]
000078d941fdf2b5  vmovaps xmm1, [rsp+0x10]
000078d941fdf2bb  vmovaps xmm2, [rsp+0x20]
000078d941fdf2c1  vmovaps xmm3, [rsp+0x30]
000078d941fdf2c7  vmovaps xmm4, [rsp+0x40]
000078d941fdf2cd  vmovaps xmm5, [rsp+0x50]
000078d941fdf2d3  vmovaps xmm6, [rsp+0x60]
000078d941fdf2d9  vmovaps xmm7, [rsp+0x70]
000078d941fdf2df  vmovaps xmm8, [rsp+0x80]
000078d941fdf2e8  vmovaps xmm9, [rsp+0x90]
000078d941fdf2f1  vmovaps xmm10, [rsp+0xA0]
000078d941fdf2fa  vmovaps xmm11, [rsp+0xB0]
000078d941fdf303  vmovaps xmm12, [rsp+0xC0]
000078d941fdf30c  vmovaps xmm13, [rsp+0xD0]
000078d941fdf315  vmovaps xmm14, [rsp+0xE0]
000078d941fdf31e  add rsp, 0xF0
000078d941fdf325  pop r11
000078d941fdf327  pop r10
000078d941fdf329  pop r9
000078d941fdf32b  pop r8
000078d941fdf32d  pop rsi
000078d941fdf32e  pop rdi
000078d941fdf32f  pop rdx
000078d941fdf330  pop rcx
000078d941fdf331  pop rax
000078d941fdf332  add rsp, 0x08
000078d941fdf336  jmp 0x000078D941FDC38F
000078d941fdf33b  sub rsp, 0x08
000078d941fdf33f  push rax
000078d941fdf340  push rcx
000078d941fdf341  push rdx
000078d941fdf342  push rdi
000078d941fdf343  push rsi
000078d941fdf344  push r8
000078d941fdf346  push r9
000078d941fdf348  push r10
000078d941fdf34a  push r11
000078d941fdf34c  sub rsp, 0xF0
000078d941fdf353  vmovaps [rsp], xmm0
000078d941fdf358  vmovaps [rsp+0x10], xmm1
000078d941fdf35e  vmovaps [rsp+0x20], xmm2
000078d941fdf364  vmovaps [rsp+0x30], xmm3
000078d941fdf36a  vmovaps [rsp+0x40], xmm4
000078d941fdf370  vmovaps [rsp+0x50], xmm6
000078d941fdf376  vmovaps [rsp+0x60], xmm7
000078d941fdf37c  vmovaps [rsp+0x70], xmm8
000078d941fdf382  vmovaps [rsp+0x80], xmm9
000078d941fdf38b  vmovaps [rsp+0x90], xmm10
000078d941fdf394  vmovaps [rsp+0xA0], xmm11
000078d941fdf39d  vmovaps [rsp+0xB0], xmm12
000078d941fdf3a6  vmovaps [rsp+0xC0], xmm13
000078d941fdf3af  vmovaps [rsp+0xD0], xmm14
000078d941fdf3b8  vmovaps [rsp+0xE0], xmm15
000078d941fdf3c1  sub rsp, 0x30
000078d941fdf3c5  movaps [rsp], xmm5
000078d941fdf3c9  movaps [rsp+0x10], xmm8
000078d941fdf3cf  movaps [rsp+0x20], xmm6
000078d941fdf3d4  lea rdi, [rsp]
000078d941fdf3d8  mov esi, 0x00
000078d941fdf3dd  mov rax, 0x59BFBFBAA530
000078d941fdf3e7  call rax
000078d941fdf3e9  movaps xmm5, [rsp]
000078d941fdf3ed  add rsp, 0x30
000078d941fdf3f1  vmovaps xmm0, [rsp]
000078d941fdf3f6  vmovaps xmm1, [rsp+0x10]
000078d941fdf3fc  vmovaps xmm2, [rsp+0x20]
000078d941fdf402  vmovaps xmm3, [rsp+0x30]
000078d941fdf408  vmovaps xmm4, [rsp+0x40]
000078d941fdf40e  vmovaps xmm6, [rsp+0x50]
000078d941fdf414  vmovaps xmm7, [rsp+0x60]
000078d941fdf41a  vmovaps xmm8, [rsp+0x70]
000078d941fdf420  vmovaps xmm9, [rsp+0x80]
000078d941fdf429  vmovaps xmm10, [rsp+0x90]
000078d941fdf432  vmovaps xmm11, [rsp+0xA0]
000078d941fdf43b  vmovaps xmm12, [rsp+0xB0]
000078d941fdf444  vmovaps xmm13, [rsp+0xC0]
000078d941fdf44d  vmovaps xmm14, [rsp+0xD0]
000078d941fdf456  vmovaps xmm15, [rsp+0xE0]
000078d941fdf45f  add rsp, 0xF0
000078d941fdf466  pop r11
000078d941fdf468  pop r10
000078d941fdf46a  pop r9
000078d941fdf46c  pop r8
000078d941fdf46e  pop rsi
000078d941fdf46f  pop rdi
000078d941fdf470  pop rdx
000078d941fdf471  pop rcx
000078d941fdf472  pop rax
000078d941fdf473  add rsp, 0x08
000078d941fdf477  jmp 0x000078D941FDC3B3
000078d941fdf47c  sub rsp, 0x08
000078d941fdf480  push rax
000078d941fdf481  push rcx
000078d941fdf482  push rdx
000078d941fdf483  push rdi
000078d941fdf484  push rsi
000078d941fdf485  push r8
000078d941fdf487  push r9
000078d941fdf489  push r10
000078d941fdf48b  push r11
000078d941fdf48d  sub rsp, 0xF0
000078d941fdf494  vmovaps [rsp], xmm0
000078d941fdf499  vmovaps [rsp+0x10], xmm1
000078d941fdf49f  vmovaps [rsp+0x20], xmm2
000078d941fdf4a5  vmovaps [rsp+0x30], xmm3
000078d941fdf4ab  vmovaps [rsp+0x40], xmm4
000078d941fdf4b1  vmovaps [rsp+0x50], xmm5
000078d941fdf4b7  vmovaps [rsp+0x60], xmm7
000078d941fdf4bd  vmovaps [rsp+0x70], xmm8
000078d941fdf4c3  vmovaps [rsp+0x80], xmm9
000078d941fdf4cc  vmovaps [rsp+0x90], xmm10
000078d941fdf4d5  vmovaps [rsp+0xA0], xmm11
000078d941fdf4de  vmovaps [rsp+0xB0], xmm12
000078d941fdf4e7  vmovaps [rsp+0xC0], xmm13
000078d941fdf4f0  vmovaps [rsp+0xD0], xmm14
000078d941fdf4f9  vmovaps [rsp+0xE0], xmm15
000078d941fdf502  sub rsp, 0x30
000078d941fdf506  movaps [rsp], xmm6
000078d941fdf50a  movaps [rsp+0x10], xmm10
000078d941fdf510  movaps [rsp+0x20], xmm8
000078d941fdf516  lea rdi, [rsp]
000078d941fdf51a  mov esi, 0x00
000078d941fdf51f  mov rax, 0x59BFBFBAA530
000078d941fdf529  call rax
000078d941fdf52b  movaps xmm6, [rsp]
000078d941fdf52f  add rsp, 0x30
000078d941fdf533  vmovaps xmm0, [rsp]
000078d941fdf538  vmovaps xmm1, [rsp+0x10]
000078d941fdf53e  vmovaps xmm2, [rsp+0x20]
000078d941fdf544  vmovaps xmm3, [rsp+0x30]
000078d941fdf54a  vmovaps xmm4, [rsp+0x40]
000078d941fdf550  vmovaps xmm5, [rsp+0x50]
000078d941fdf556  vmovaps xmm7, [rsp+0x60]
000078d941fdf55c  vmovaps xmm8, [rsp+0x70]
000078d941fdf562  vmovaps xmm9, [rsp+0x80]
000078d941fdf56b  vmovaps xmm10, [rsp+0x90]
000078d941fdf574  vmovaps xmm11, [rsp+0xA0]
000078d941fdf57d  vmovaps xmm12, [rsp+0xB0]
000078d941fdf586  vmovaps xmm13, [rsp+0xC0]
000078d941fdf58f  vmovaps xmm14, [rsp+0xD0]
000078d941fdf598  vmovaps xmm15, [rsp+0xE0]
000078d941fdf5a1  add rsp, 0xF0
000078d941fdf5a8  pop r11
000078d941fdf5aa  pop r10
000078d941fdf5ac  pop r9
000078d941fdf5ae  pop r8
000078d941fdf5b0  pop rsi
000078d941fdf5b1  pop rdi
000078d941fdf5b2  pop rdx
000078d941fdf5b3  pop rcx
000078d941fdf5b4  pop rax
000078d941fdf5b5  add rsp, 0x08
000078d941fdf5b9  jmp 0x000078D941FDC3D8
000078d941fdf5be  sub rsp, 0x08
000078d941fdf5c2  push rax
000078d941fdf5c3  push rcx
000078d941fdf5c4  push rdx
000078d941fdf5c5  push rdi
000078d941fdf5c6  push rsi
000078d941fdf5c7  push r8
000078d941fdf5c9  push r9
000078d941fdf5cb  push r10
000078d941fdf5cd  push r11
000078d941fdf5cf  sub rsp, 0xF0
000078d941fdf5d6  vmovaps [rsp], xmm0
000078d941fdf5db  vmovaps [rsp+0x10], xmm1
000078d941fdf5e1  vmovaps [rsp+0x20], xmm2
000078d941fdf5e7  vmovaps [rsp+0x30], xmm3
000078d941fdf5ed  vmovaps [rsp+0x40], xmm4
000078d941fdf5f3  vmovaps [rsp+0x50], xmm5
000078d941fdf5f9  vmovaps [rsp+0x60], xmm6
000078d941fdf5ff  vmovaps [rsp+0x70], xmm7
000078d941fdf605  vmovaps [rsp+0x80], xmm8
000078d941fdf60e  vmovaps [rsp+0x90], xmm9
000078d941fdf617  vmovaps [rsp+0xA0], xmm11
000078d941fdf620  vmovaps [rsp+0xB0], xmm12
000078d941fdf629  vmovaps [rsp+0xC0], xmm13
000078d941fdf632  vmovaps [rsp+0xD0], xmm14
000078d941fdf63b  vmovaps [rsp+0xE0], xmm15
000078d941fdf644  sub rsp, 0x30
000078d941fdf648  movaps [rsp], xmm10
000078d941fdf64d  movaps [rsp+0x10], xmm8
000078d941fdf653  movaps [rsp+0x20], xmm14
000078d941fdf659  lea rdi, [rsp]
000078d941fdf65d  mov esi, 0x00
000078d941fdf662  mov rax, 0x59BFBFBAA530
000078d941fdf66c  call rax
000078d941fdf66e  movaps xmm10, [rsp]
000078d941fdf673  add rsp, 0x30
000078d941fdf677  vmovaps xmm0, [rsp]
000078d941fdf67c  vmovaps xmm1, [rsp+0x10]
000078d941fdf682  vmovaps xmm2, [rsp+0x20]
000078d941fdf688  vmovaps xmm3, [rsp+0x30]
000078d941fdf68e  vmovaps xmm4, [rsp+0x40]
000078d941fdf694  vmovaps xmm5, [rsp+0x50]
000078d941fdf69a  vmovaps xmm6, [rsp+0x60]
000078d941fdf6a0  vmovaps xmm7, [rsp+0x70]
000078d941fdf6a6  vmovaps xmm8, [rsp+0x80]
000078d941fdf6af  vmovaps xmm9, [rsp+0x90]
000078d941fdf6b8  vmovaps xmm11, [rsp+0xA0]
000078d941fdf6c1  vmovaps xmm12, [rsp+0xB0]
000078d941fdf6ca  vmovaps xmm13, [rsp+0xC0]
000078d941fdf6d3  vmovaps xmm14, [rsp+0xD0]
000078d941fdf6dc  vmovaps xmm15, [rsp+0xE0]
000078d941fdf6e5  add rsp, 0xF0
000078d941fdf6ec  pop r11
000078d941fdf6ee  pop r10
000078d941fdf6f0  pop r9
000078d941fdf6f2  pop r8
000078d941fdf6f4  pop rsi
000078d941fdf6f5  pop rdi
000078d941fdf6f6  pop rdx
000078d941fdf6f7  pop rcx
000078d941fdf6f8  pop rax
000078d941fdf6f9  add rsp, 0x08
000078d941fdf6fd  jmp 0x000078D941FDC3F8
000078d941fdf702  sub rsp, 0x08
000078d941fdf706  push rax
000078d941fdf707  push rcx
000078d941fdf708  push rdx
000078d941fdf709  push rdi
000078d941fdf70a  push rsi
000078d941fdf70b  push r8
000078d941fdf70d  push r9
000078d941fdf70f  push r10
000078d941fdf711  push r11
000078d941fdf713  sub rsp, 0xF0
000078d941fdf71a  vmovaps [rsp], xmm0
000078d941fdf71f  vmovaps [rsp+0x10], xmm1
000078d941fdf725  vmovaps [rsp+0x20], xmm2
000078d941fdf72b  vmovaps [rsp+0x30], xmm3
000078d941fdf731  vmovaps [rsp+0x40], xmm4
000078d941fdf737  vmovaps [rsp+0x50], xmm5
000078d941fdf73d  vmovaps [rsp+0x60], xmm6
000078d941fdf743  vmovaps [rsp+0x70], xmm7
000078d941fdf749  vmovaps [rsp+0x80], xmm8
000078d941fdf752  vmovaps [rsp+0x90], xmm9
000078d941fdf75b  vmovaps [rsp+0xA0], xmm10
000078d941fdf764  vmovaps [rsp+0xB0], xmm11
000078d941fdf76d  vmovaps [rsp+0xC0], xmm12
000078d941fdf776  vmovaps [rsp+0xD0], xmm13
000078d941fdf77f  vmovaps [rsp+0xE0], xmm15
000078d941fdf788  sub rsp, 0x30
000078d941fdf78c  movaps [rsp], xmm14
000078d941fdf791  movaps [rsp+0x10], xmm8
000078d941fdf797  movaps [rsp+0x20], xmm4
000078d941fdf79c  lea rdi, [rsp]
000078d941fdf7a0  mov esi, 0x00
000078d941fdf7a5  mov rax, 0x59BFBFBAA530
000078d941fdf7af  call rax
000078d941fdf7b1  movaps xmm14, [rsp]
000078d941fdf7b6  add rsp, 0x30
000078d941fdf7ba  vmovaps xmm0, [rsp]
000078d941fdf7bf  vmovaps xmm1, [rsp+0x10]
000078d941fdf7c5  vmovaps xmm2, [rsp+0x20]
000078d941fdf7cb  vmovaps xmm3, [rsp+0x30]
000078d941fdf7d1  vmovaps xmm4, [rsp+0x40]
000078d941fdf7d7  vmovaps xmm5, [rsp+0x50]
000078d941fdf7dd  vmovaps xmm6, [rsp+0x60]
000078d941fdf7e3  vmovaps xmm7, [rsp+0x70]
000078d941fdf7e9  vmovaps xmm8, [rsp+0x80]
000078d941fdf7f2  vmovaps xmm9, [rsp+0x90]
000078d941fdf7fb  vmovaps xmm10, [rsp+0xA0]
000078d941fdf804  vmovaps xmm11, [rsp+0xB0]
000078d941fdf80d  vmovaps xmm12, [rsp+0xC0]
000078d941fdf816  vmovaps xmm13, [rsp+0xD0]
000078d941fdf81f  vmovaps xmm15, [rsp+0xE0]
000078d941fdf828  add rsp, 0xF0
000078d941fdf82f  pop r11
000078d941fdf831  pop r10
000078d941fdf833  pop r9
000078d941fdf835  pop r8
000078d941fdf837  pop rsi
000078d941fdf838  pop rdi
000078d941fdf839  pop rdx
000078d941fdf83a  pop rcx
000078d941fdf83b  pop rax
000078d941fdf83c  add rsp, 0x08
000078d941fdf840  jmp 0x000078D941FDC418
000078d941fdf845  sub rsp, 0x08
000078d941fdf849  push rax
000078d941fdf84a  push rcx
000078d941fdf84b  push rdx
000078d941fdf84c  push rdi
000078d941fdf84d  push rsi
000078d941fdf84e  push r8
000078d941fdf850  push r9
000078d941fdf852  push r10
000078d941fdf854  push r11
000078d941fdf856  sub rsp, 0xF0
000078d941fdf85d  vmovaps [rsp], xmm0
000078d941fdf862  vmovaps [rsp+0x10], xmm1
000078d941fdf868  vmovaps [rsp+0x20], xmm2
000078d941fdf86e  vmovaps [rsp+0x30], xmm3
000078d941fdf874  vmovaps [rsp+0x40], xmm5
000078d941fdf87a  vmovaps [rsp+0x50], xmm6
000078d941fdf880  vmovaps [rsp+0x60], xmm7
000078d941fdf886  vmovaps [rsp+0x70], xmm8
000078d941fdf88c  vmovaps [rsp+0x80], xmm9
000078d941fdf895  vmovaps [rsp+0x90], xmm10
000078d941fdf89e  vmovaps [rsp+0xA0], xmm11
000078d941fdf8a7  vmovaps [rsp+0xB0], xmm12
000078d941fdf8b0  vmovaps [rsp+0xC0], xmm13
000078d941fdf8b9  vmovaps [rsp+0xD0], xmm14
000078d941fdf8c2  vmovaps [rsp+0xE0], xmm15
000078d941fdf8cb  sub rsp, 0x30
000078d941fdf8cf  movaps [rsp], xmm4
000078d941fdf8d3  movaps [rsp+0x10], xmm13
000078d941fdf8d9  movaps [rsp+0x20], xmm8
000078d941fdf8df  lea rdi, [rsp]
000078d941fdf8e3  mov esi, 0x00
000078d941fdf8e8  mov rax, 0x59BFBFBAA530
000078d941fdf8f2  call rax
000078d941fdf8f4  movaps xmm4, [rsp]
000078d941fdf8f8  add rsp, 0x30
000078d941fdf8fc  vmovaps xmm0, [rsp]
000078d941fdf901  vmovaps xmm1, [rsp+0x10]
000078d941fdf907  vmovaps xmm2, [rsp+0x20]
000078d941fdf90d  vmovaps xmm3, [rsp+0x30]
000078d941fdf913  vmovaps xmm5, [rsp+0x40]
000078d941fdf919  vmovaps xmm6, [rsp+0x50]
000078d941fdf91f  vmovaps xmm7, [rsp+0x60]
000078d941fdf925  vmovaps xmm8, [rsp+0x70]
000078d941fdf92b  vmovaps xmm9, [rsp+0x80]
000078d941fdf934  vmovaps xmm10, [rsp+0x90]
000078d941fdf93d  vmovaps xmm11, [rsp+0xA0]
000078d941fdf946  vmovaps xmm12, [rsp+0xB0]
000078d941fdf94f  vmovaps xmm13, [rsp+0xC0]
000078d941fdf958  vmovaps xmm14, [rsp+0xD0]
000078d941fdf961  vmovaps xmm15, [rsp+0xE0]
000078d941fdf96a  add rsp, 0xF0
000078d941fdf971  pop r11
000078d941fdf973  pop r10
000078d941fdf975  pop r9
000078d941fdf977  pop r8
000078d941fdf979  pop rsi
000078d941fdf97a  pop rdi
000078d941fdf97b  pop rdx
000078d941fdf97c  pop rcx
000078d941fdf97d  pop rax
000078d941fdf97e  add rsp, 0x08
000078d941fdf982  jmp 0x000078D941FDC43D
000078d941fdf987  sub rsp, 0x08
000078d941fdf98b  push rax
000078d941fdf98c  push rcx
000078d941fdf98d  push rdx
000078d941fdf98e  push rdi
000078d941fdf98f  push rsi
000078d941fdf990  push r8
000078d941fdf992  push r9
000078d941fdf994  push r10
000078d941fdf996  push r11
000078d941fdf998  sub rsp, 0xF0
000078d941fdf99f  vmovaps [rsp], xmm0
000078d941fdf9a4  vmovaps [rsp+0x10], xmm1
000078d941fdf9aa  vmovaps [rsp+0x20], xmm2
000078d941fdf9b0  vmovaps [rsp+0x30], xmm3
000078d941fdf9b6  vmovaps [rsp+0x40], xmm4
000078d941fdf9bc  vmovaps [rsp+0x50], xmm5
000078d941fdf9c2  vmovaps [rsp+0x60], xmm6
000078d941fdf9c8  vmovaps [rsp+0x70], xmm7
000078d941fdf9ce  vmovaps [rsp+0x80], xmm8
000078d941fdf9d7  vmovaps [rsp+0x90], xmm9
000078d941fdf9e0  vmovaps [rsp+0xA0], xmm10
000078d941fdf9e9  vmovaps [rsp+0xB0], xmm11
000078d941fdf9f2  vmovaps [rsp+0xC0], xmm12
000078d941fdf9fb  vmovaps [rsp+0xD0], xmm14
000078d941fdfa04  vmovaps [rsp+0xE0], xmm15
000078d941fdfa0d  sub rsp, 0x30
000078d941fdfa11  movaps [rsp], xmm13
000078d941fdfa16  movaps [rsp+0x10], xmm15
000078d941fdfa1c  movaps [rsp+0x20], xmm9
000078d941fdfa22  lea rdi, [rsp]
000078d941fdfa26  mov esi, 0x00
000078d941fdfa2b  mov rax, 0x59BFBFBAA530
000078d941fdfa35  call rax
000078d941fdfa37  movaps xmm13, [rsp]
000078d941fdfa3c  add rsp, 0x30
000078d941fdfa40  vmovaps xmm0, [rsp]
000078d941fdfa45  vmovaps xmm1, [rsp+0x10]
000078d941fdfa4b  vmovaps xmm2, [rsp+0x20]
000078d941fdfa51  vmovaps xmm3, [rsp+0x30]
000078d941fdfa57  vmovaps xmm4, [rsp+0x40]
000078d941fdfa5d  vmovaps xmm5, [rsp+0x50]
000078d941fdfa63  vmovaps xmm6, [rsp+0x60]
000078d941fdfa69  vmovaps xmm7, [rsp+0x70]
000078d941fdfa6f  vmovaps xmm8, [rsp+0x80]
000078d941fdfa78  vmovaps xmm9, [rsp+0x90]
000078d941fdfa81  vmovaps xmm10, [rsp+0xA0]
000078d941fdfa8a  vmovaps xmm11, [rsp+0xB0]
000078d941fdfa93  vmovaps xmm12, [rsp+0xC0]
000078d941fdfa9c  vmovaps xmm14, [rsp+0xD0]
000078d941fdfaa5  vmovaps xmm15, [rsp+0xE0]
000078d941fdfaae  add rsp, 0xF0
000078d941fdfab5  pop r11
000078d941fdfab7  pop r10
000078d941fdfab9  pop r9
000078d941fdfabb  pop r8
000078d941fdfabd  pop rsi
000078d941fdfabe  pop rdi
000078d941fdfabf  pop rdx
000078d941fdfac0  pop rcx
000078d941fdfac1  pop rax
000078d941fdfac2  add rsp, 0x08
000078d941fdfac6  jmp 0x000078D941FDC458
000078d941fdfacb  sub rsp, 0x08
000078d941fdfacf  push rax
000078d941fdfad0  push rcx
000078d941fdfad1  push rdx
000078d941fdfad2  push rdi
000078d941fdfad3  push rsi
000078d941fdfad4  push r8
000078d941fdfad6  push r9
000078d941fdfad8  push r10
000078d941fdfada  push r11
000078d941fdfadc  sub rsp, 0xF0
000078d941fdfae3  vmovaps [rsp], xmm0
000078d941fdfae8  vmovaps [rsp+0x10], xmm1
000078d941fdfaee  vmovaps [rsp+0x20], xmm2
000078d941fdfaf4  vmovaps [rsp+0x30], xmm3
000078d941fdfafa  vmovaps [rsp+0x40], xmm4
000078d941fdfb00  vmovaps [rsp+0x50], xmm5
000078d941fdfb06  vmovaps [rsp+0x60], xmm6
000078d941fdfb0c  vmovaps [rsp+0x70], xmm7
000078d941fdfb12  vmovaps [rsp+0x80], xmm8
000078d941fdfb1b  vmovaps [rsp+0x90], xmm9
000078d941fdfb24  vmovaps [rsp+0xA0], xmm10
000078d941fdfb2d  vmovaps [rsp+0xB0], xmm11
000078d941fdfb36  vmovaps [rsp+0xC0], xmm12
000078d941fdfb3f  vmovaps [rsp+0xD0], xmm13
000078d941fdfb48  vmovaps [rsp+0xE0], xmm14
000078d941fdfb51  sub rsp, 0x30
000078d941fdfb55  movaps [rsp], xmm15
000078d941fdfb5a  movaps [rsp+0x10], xmm1
000078d941fdfb5f  movaps [rsp+0x20], xmm5
000078d941fdfb64  lea rdi, [rsp]
000078d941fdfb68  mov esi, 0x00
000078d941fdfb6d  mov rax, 0x59BFBFBAA530
000078d941fdfb77  call rax
000078d941fdfb79  movaps xmm15, [rsp]
000078d941fdfb7e  add rsp, 0x30
000078d941fdfb82  vmovaps xmm0, [rsp]
000078d941fdfb87  vmovaps xmm1, [rsp+0x10]
000078d941fdfb8d  vmovaps xmm2, [rsp+0x20]
000078d941fdfb93  vmovaps xmm3, [rsp+0x30]
000078d941fdfb99  vmovaps xmm4, [rsp+0x40]
000078d941fdfb9f  vmovaps xmm5, [rsp+0x50]
000078d941fdfba5  vmovaps xmm6, [rsp+0x60]
000078d941fdfbab  vmovaps xmm7, [rsp+0x70]
000078d941fdfbb1  vmovaps xmm8, [rsp+0x80]
000078d941fdfbba  vmovaps xmm9, [rsp+0x90]
000078d941fdfbc3  vmovaps xmm10, [rsp+0xA0]
000078d941fdfbcc  vmovaps xmm11, [rsp+0xB0]
000078d941fdfbd5  vmovaps xmm12, [rsp+0xC0]
000078d941fdfbde  vmovaps xmm13, [rsp+0xD0]
000078d941fdfbe7  vmovaps xmm14, [rsp+0xE0]
000078d941fdfbf0  add rsp, 0xF0
000078d941fdfbf7  pop r11
000078d941fdfbf9  pop r10
000078d941fdfbfb  pop r9
000078d941fdfbfd  pop r8
000078d941fdfbff  pop rsi
000078d941fdfc00  pop rdi
000078d941fdfc01  pop rdx
000078d941fdfc02  pop rcx
000078d941fdfc03  pop rax
000078d941fdfc04  add rsp, 0x08
000078d941fdfc08  jmp 0x000078D941FDC473
000078d941fdfc0d  call 0x000078D941EB52F0
000078d941fdfc12  jmp 0x000078D941FDC4CE
000078d941fdfc17  sub rsp, 0x08
000078d941fdfc1b  push rax
000078d941fdfc1c  push rcx
000078d941fdfc1d  push rdx
000078d941fdfc1e  push rdi
000078d941fdfc1f  push rsi
000078d941fdfc20  push r8
000078d941fdfc22  push r9
000078d941fdfc24  push r10
000078d941fdfc26  push r11
000078d941fdfc28  sub rsp, 0xF0
000078d941fdfc2f  vmovaps [rsp], xmm0
000078d941fdfc34  vmovaps [rsp+0x10], xmm1
000078d941fdfc3a  vmovaps [rsp+0x20], xmm2
000078d941fdfc40  vmovaps [rsp+0x30], xmm3
000078d941fdfc46  vmovaps [rsp+0x40], xmm4
000078d941fdfc4c  vmovaps [rsp+0x50], xmm5
000078d941fdfc52  vmovaps [rsp+0x60], xmm6
000078d941fdfc58  vmovaps [rsp+0x70], xmm7
000078d941fdfc5e  vmovaps [rsp+0x80], xmm8
000078d941fdfc67  vmovaps [rsp+0x90], xmm10
000078d941fdfc70  vmovaps [rsp+0xA0], xmm11
000078d941fdfc79  vmovaps [rsp+0xB0], xmm12
000078d941fdfc82  vmovaps [rsp+0xC0], xmm13
000078d941fdfc8b  vmovaps [rsp+0xD0], xmm14
000078d941fdfc94  vmovaps [rsp+0xE0], xmm15
000078d941fdfc9d  sub rsp, 0x30
000078d941fdfca1  movaps [rsp], xmm9
000078d941fdfca6  movaps [rsp+0x10], xmm8
000078d941fdfcac  movaps [rsp+0x20], xmm11
000078d941fdfcb2  lea rdi, [rsp]
000078d941fdfcb6  mov esi, 0x00
000078d941fdfcbb  mov rax, 0x59BFBFBAA530
000078d941fdfcc5  call rax
000078d941fdfcc7  movaps xmm9, [rsp]
000078d941fdfccc  add rsp, 0x30
000078d941fdfcd0  vmovaps xmm0, [rsp]
000078d941fdfcd5  vmovaps xmm1, [rsp+0x10]
000078d941fdfcdb  vmovaps xmm2, [rsp+0x20]
000078d941fdfce1  vmovaps xmm3, [rsp+0x30]
000078d941fdfce7  vmovaps xmm4, [rsp+0x40]
000078d941fdfced  vmovaps xmm5, [rsp+0x50]
000078d941fdfcf3  vmovaps xmm6, [rsp+0x60]
000078d941fdfcf9  vmovaps xmm7, [rsp+0x70]
000078d941fdfcff  vmovaps xmm8, [rsp+0x80]
000078d941fdfd08  vmovaps xmm10, [rsp+0x90]
000078d941fdfd11  vmovaps xmm11, [rsp+0xA0]
000078d941fdfd1a  vmovaps xmm12, [rsp+0xB0]
000078d941fdfd23  vmovaps xmm13, [rsp+0xC0]
000078d941fdfd2c  vmovaps xmm14, [rsp+0xD0]
000078d941fdfd35  vmovaps xmm15, [rsp+0xE0]
000078d941fdfd3e  add rsp, 0xF0
000078d941fdfd45  pop r11
000078d941fdfd47  pop r10
000078d941fdfd49  pop r9
000078d941fdfd4b  pop r8
000078d941fdfd4d  pop rsi
000078d941fdfd4e  pop rdi
000078d941fdfd4f  pop rdx
000078d941fdfd50  pop rcx
000078d941fdfd51  pop rax
000078d941fdfd52  add rsp, 0x08
000078d941fdfd56  jmp 0x000078D941FDC505
000078d941fdfd5b  sub rsp, 0x08
000078d941fdfd5f  push rax
000078d941fdfd60  push rcx
000078d941fdfd61  push rdx
000078d941fdfd62  push rdi
000078d941fdfd63  push rsi
000078d941fdfd64  push r8
000078d941fdfd66  push r9
000078d941fdfd68  push r10
000078d941fdfd6a  push r11
000078d941fdfd6c  sub rsp, 0xF0
000078d941fdfd73  vmovaps [rsp], xmm0
000078d941fdfd78  vmovaps [rsp+0x10], xmm1
000078d941fdfd7e  vmovaps [rsp+0x20], xmm2
000078d941fdfd84  vmovaps [rsp+0x30], xmm3
000078d941fdfd8a  vmovaps [rsp+0x40], xmm4
000078d941fdfd90  vmovaps [rsp+0x50], xmm5
000078d941fdfd96  vmovaps [rsp+0x60], xmm6
000078d941fdfd9c  vmovaps [rsp+0x70], xmm7
000078d941fdfda2  vmovaps [rsp+0x80], xmm8
000078d941fdfdab  vmovaps [rsp+0x90], xmm9
000078d941fdfdb4  vmovaps [rsp+0xA0], xmm10
000078d941fdfdbd  vmovaps [rsp+0xB0], xmm12
000078d941fdfdc6  vmovaps [rsp+0xC0], xmm13
000078d941fdfdcf  vmovaps [rsp+0xD0], xmm14
000078d941fdfdd8  vmovaps [rsp+0xE0], xmm15
000078d941fdfde1  sub rsp, 0x30
000078d941fdfde5  movaps [rsp], xmm11
000078d941fdfdea  movaps [rsp+0x10], xmm10
000078d941fdfdf0  movaps [rsp+0x20], xmm6
000078d941fdfdf5  lea rdi, [rsp]
000078d941fdfdf9  mov esi, 0x00
000078d941fdfdfe  mov rax, 0x59BFBFBAA530
000078d941fdfe08  call rax
000078d941fdfe0a  movaps xmm11, [rsp]
000078d941fdfe0f  add rsp, 0x30
000078d941fdfe13  vmovaps xmm0, [rsp]
000078d941fdfe18  vmovaps xmm1, [rsp+0x10]
000078d941fdfe1e  vmovaps xmm2, [rsp+0x20]
000078d941fdfe24  vmovaps xmm3, [rsp+0x30]
000078d941fdfe2a  vmovaps xmm4, [rsp+0x40]
000078d941fdfe30  vmovaps xmm5, [rsp+0x50]
000078d941fdfe36  vmovaps xmm6, [rsp+0x60]
000078d941fdfe3c  vmovaps xmm7, [rsp+0x70]
000078d941fdfe42  vmovaps xmm8, [rsp+0x80]
000078d941fdfe4b  vmovaps xmm9, [rsp+0x90]
000078d941fdfe54  vmovaps xmm10, [rsp+0xA0]
000078d941fdfe5d  vmovaps xmm12, [rsp+0xB0]
000078d941fdfe66  vmovaps xmm13, [rsp+0xC0]
000078d941fdfe6f  vmovaps xmm14, [rsp+0xD0]
000078d941fdfe78  vmovaps xmm15, [rsp+0xE0]
000078d941fdfe81  add rsp, 0xF0
000078d941fdfe88  pop r11
000078d941fdfe8a  pop r10
000078d941fdfe8c  pop r9
000078d941fdfe8e  pop r8
000078d941fdfe90  pop rsi
000078d941fdfe91  pop rdi
000078d941fdfe92  pop rdx
000078d941fdfe93  pop rcx
000078d941fdfe94  pop rax
000078d941fdfe95  add rsp, 0x08
000078d941fdfe99  jmp 0x000078D941FDC520
000078d941fdfe9e  sub rsp, 0x08
000078d941fdfea2  push rax
000078d941fdfea3  push rcx
000078d941fdfea4  push rdx
000078d941fdfea5  push rdi
000078d941fdfea6  push rsi
000078d941fdfea7  push r8
000078d941fdfea9  push r9
000078d941fdfeab  push r10
000078d941fdfead  push r11
000078d941fdfeaf  sub rsp, 0xF0
000078d941fdfeb6  vmovaps [rsp], xmm0
000078d941fdfebb  vmovaps [rsp+0x10], xmm1
000078d941fdfec1  vmovaps [rsp+0x20], xmm2
000078d941fdfec7  vmovaps [rsp+0x30], xmm3
000078d941fdfecd  vmovaps [rsp+0x40], xmm4
000078d941fdfed3  vmovaps [rsp+0x50], xmm5
000078d941fdfed9  vmovaps [rsp+0x60], xmm6
000078d941fdfedf  vmovaps [rsp+0x70], xmm7
000078d941fdfee5  vmovaps [rsp+0x80], xmm8
000078d941fdfeee  vmovaps [rsp+0x90], xmm9
000078d941fdfef7  vmovaps [rsp+0xA0], xmm11
000078d941fdff00  vmovaps [rsp+0xB0], xmm12
000078d941fdff09  vmovaps [rsp+0xC0], xmm13
000078d941fdff12  vmovaps [rsp+0xD0], xmm14
000078d941fdff1b  vmovaps [rsp+0xE0], xmm15
000078d941fdff24  sub rsp, 0x30
000078d941fdff28  movaps [rsp], xmm10
000078d941fdff2d  movaps [rsp+0x10], xmm14
000078d941fdff33  movaps [rsp+0x20], xmm4
000078d941fdff38  lea rdi, [rsp]
000078d941fdff3c  mov esi, 0x00
000078d941fdff41  mov rax, 0x59BFBFBAA530
000078d941fdff4b  call rax
000078d941fdff4d  movaps xmm10, [rsp]
000078d941fdff52  add rsp, 0x30
000078d941fdff56  vmovaps xmm0, [rsp]
000078d941fdff5b  vmovaps xmm1, [rsp+0x10]
000078d941fdff61  vmovaps xmm2, [rsp+0x20]
000078d941fdff67  vmovaps xmm3, [rsp+0x30]
000078d941fdff6d  vmovaps xmm4, [rsp+0x40]
000078d941fdff73  vmovaps xmm5, [rsp+0x50]
000078d941fdff79  vmovaps xmm6, [rsp+0x60]
000078d941fdff7f  vmovaps xmm7, [rsp+0x70]
000078d941fdff85  vmovaps xmm8, [rsp+0x80]
000078d941fdff8e  vmovaps xmm9, [rsp+0x90]
000078d941fdff97  vmovaps xmm11, [rsp+0xA0]
000078d941fdffa0  vmovaps xmm12, [rsp+0xB0]
000078d941fdffa9  vmovaps xmm13, [rsp+0xC0]
000078d941fdffb2  vmovaps xmm14, [rsp+0xD0]
000078d941fdffbb  vmovaps xmm15, [rsp+0xE0]
000078d941fdffc4  add rsp, 0xF0
000078d941fdffcb  pop r11
000078d941fdffcd  pop r10
000078d941fdffcf  pop r9
000078d941fdffd1  pop r8
000078d941fdffd3  pop rsi
000078d941fdffd4  pop rdi
000078d941fdffd5  pop rdx
000078d941fdffd6  pop rcx
000078d941fdffd7  pop rax
000078d941fdffd8  add rsp, 0x08
000078d941fdffdc  jmp 0x000078D941FDC53B
000078d941fdffe1  sub rsp, 0x08
000078d941fdffe5  push rax
000078d941fdffe6  push rcx
000078d941fdffe7  push rdx
000078d941fdffe8  push rdi
000078d941fdffe9  push rsi
000078d941fdffea  push r8
000078d941fdffec  push r9
000078d941fdffee  push r10
000078d941fdfff0  push r11
000078d941fdfff2  sub rsp, 0xF0
000078d941fdfff9  vmovaps [rsp], xmm0
000078d941fdfffe  vmovaps [rsp+0x10], xmm1
000078d941fe0004  vmovaps [rsp+0x20], xmm2
000078d941fe000a  vmovaps [rsp+0x30], xmm3
000078d941fe0010  vmovaps [rsp+0x40], xmm4
000078d941fe0016  vmovaps [rsp+0x50], xmm5
000078d941fe001c  vmovaps [rsp+0x60], xmm6
000078d941fe0022  vmovaps [rsp+0x70], xmm7
000078d941fe0028  vmovaps [rsp+0x80], xmm9
000078d941fe0031  vmovaps [rsp+0x90], xmm10
000078d941fe003a  vmovaps [rsp+0xA0], xmm11
000078d941fe0043  vmovaps [rsp+0xB0], xmm12
000078d941fe004c  vmovaps [rsp+0xC0], xmm13
000078d941fe0055  vmovaps [rsp+0xD0], xmm14
000078d941fe005e  vmovaps [rsp+0xE0], xmm15
000078d941fe0067  sub rsp, 0x30
000078d941fe006b  movaps [rsp], xmm8
000078d941fe0070  movaps [rsp+0x10], xmm1
000078d941fe0075  movaps [rsp+0x20], xmm14
000078d941fe007b  lea rdi, [rsp]
000078d941fe007f  mov esi, 0x00
000078d941fe0084  mov rax, 0x59BFBFBAA530
000078d941fe008e  call rax
000078d941fe0090  movaps xmm8, [rsp]
000078d941fe0095  add rsp, 0x30
000078d941fe0099  vmovaps xmm0, [rsp]
000078d941fe009e  vmovaps xmm1, [rsp+0x10]
000078d941fe00a4  vmovaps xmm2, [rsp+0x20]
000078d941fe00aa  vmovaps xmm3, [rsp+0x30]
000078d941fe00b0  vmovaps xmm4, [rsp+0x40]
000078d941fe00b6  vmovaps xmm5, [rsp+0x50]
000078d941fe00bc  vmovaps xmm6, [rsp+0x60]
000078d941fe00c2  vmovaps xmm7, [rsp+0x70]
000078d941fe00c8  vmovaps xmm9, [rsp+0x80]
000078d941fe00d1  vmovaps xmm10, [rsp+0x90]
000078d941fe00da  vmovaps xmm11, [rsp+0xA0]
000078d941fe00e3  vmovaps xmm12, [rsp+0xB0]
000078d941fe00ec  vmovaps xmm13, [rsp+0xC0]
000078d941fe00f5  vmovaps xmm14, [rsp+0xD0]
000078d941fe00fe  vmovaps xmm15, [rsp+0xE0]
000078d941fe0107  add rsp, 0xF0
000078d941fe010e  pop r11
000078d941fe0110  pop r10
000078d941fe0112  pop r9
000078d941fe0114  pop r8
000078d941fe0116  pop rsi
000078d941fe0117  pop rdi
000078d941fe0118  pop rdx
000078d941fe0119  pop rcx
000078d941fe011a  pop rax
000078d941fe011b  add rsp, 0x08
000078d941fe011f  jmp 0x000078D941FDC561
000078d941fe0124  sub rsp, 0x08
000078d941fe0128  push rax
000078d941fe0129  push rcx
000078d941fe012a  push rdx
000078d941fe012b  push rdi
000078d941fe012c  push rsi
000078d941fe012d  push r8
000078d941fe012f  push r9
000078d941fe0131  push r10
000078d941fe0133  push r11
000078d941fe0135  sub rsp, 0xF0
000078d941fe013c  vmovaps [rsp], xmm0
000078d941fe0141  vmovaps [rsp+0x10], xmm1
000078d941fe0147  vmovaps [rsp+0x20], xmm2
000078d941fe014d  vmovaps [rsp+0x30], xmm3
000078d941fe0153  vmovaps [rsp+0x40], xmm4
000078d941fe0159  vmovaps [rsp+0x50], xmm5
000078d941fe015f  vmovaps [rsp+0x60], xmm7
000078d941fe0165  vmovaps [rsp+0x70], xmm8
000078d941fe016b  vmovaps [rsp+0x80], xmm9
000078d941fe0174  vmovaps [rsp+0x90], xmm10
000078d941fe017d  vmovaps [rsp+0xA0], xmm11
000078d941fe0186  vmovaps [rsp+0xB0], xmm12
000078d941fe018f  vmovaps [rsp+0xC0], xmm13
000078d941fe0198  vmovaps [rsp+0xD0], xmm14
000078d941fe01a1  vmovaps [rsp+0xE0], xmm15
000078d941fe01aa  sub rsp, 0x30
000078d941fe01ae  movaps [rsp], xmm6
000078d941fe01b2  movaps [rsp+0x10], xmm1
000078d941fe01b7  movaps [rsp+0x20], xmm14
000078d941fe01bd  lea rdi, [rsp]
000078d941fe01c1  mov esi, 0x00
000078d941fe01c6  mov rax, 0x59BFBFBAA530
000078d941fe01d0  call rax
000078d941fe01d2  movaps xmm6, [rsp]
000078d941fe01d6  add rsp, 0x30
000078d941fe01da  vmovaps xmm0, [rsp]
000078d941fe01df  vmovaps xmm1, [rsp+0x10]
000078d941fe01e5  vmovaps xmm2, [rsp+0x20]
000078d941fe01eb  vmovaps xmm3, [rsp+0x30]
000078d941fe01f1  vmovaps xmm4, [rsp+0x40]
000078d941fe01f7  vmovaps xmm5, [rsp+0x50]
000078d941fe01fd  vmovaps xmm7, [rsp+0x60]
000078d941fe0203  vmovaps xmm8, [rsp+0x70]
000078d941fe0209  vmovaps xmm9, [rsp+0x80]
000078d941fe0212  vmovaps xmm10, [rsp+0x90]
000078d941fe021b  vmovaps xmm11, [rsp+0xA0]
000078d941fe0224  vmovaps xmm12, [rsp+0xB0]
000078d941fe022d  vmovaps xmm13, [rsp+0xC0]
000078d941fe0236  vmovaps xmm14, [rsp+0xD0]
000078d941fe023f  vmovaps xmm15, [rsp+0xE0]
000078d941fe0248  add rsp, 0xF0
000078d941fe024f  pop r11
000078d941fe0251  pop r10
000078d941fe0253  pop r9
000078d941fe0255  pop r8
000078d941fe0257  pop rsi
000078d941fe0258  pop rdi
000078d941fe0259  pop rdx
000078d941fe025a  pop rcx
000078d941fe025b  pop rax
000078d941fe025c  add rsp, 0x08
000078d941fe0260  jmp 0x000078D941FDC58D
000078d941fe0265  sub rsp, 0x08
000078d941fe0269  push rax
000078d941fe026a  push rcx
000078d941fe026b  push rdx
000078d941fe026c  push rdi
000078d941fe026d  push rsi
000078d941fe026e  push r8
000078d941fe0270  push r9
000078d941fe0272  push r10
000078d941fe0274  push r11
000078d941fe0276  sub rsp, 0xF0
000078d941fe027d  vmovaps [rsp], xmm0
000078d941fe0282  vmovaps [rsp+0x10], xmm1
000078d941fe0288  vmovaps [rsp+0x20], xmm2
000078d941fe028e  vmovaps [rsp+0x30], xmm3
000078d941fe0294  vmovaps [rsp+0x40], xmm4
000078d941fe029a  vmovaps [rsp+0x50], xmm5
000078d941fe02a0  vmovaps [rsp+0x60], xmm6
000078d941fe02a6  vmovaps [rsp+0x70], xmm7
000078d941fe02ac  vmovaps [rsp+0x80], xmm8
000078d941fe02b5  vmovaps [rsp+0x90], xmm9
000078d941fe02be  vmovaps [rsp+0xA0], xmm10
000078d941fe02c7  vmovaps [rsp+0xB0], xmm11
000078d941fe02d0  vmovaps [rsp+0xC0], xmm12
000078d941fe02d9  vmovaps [rsp+0xD0], xmm13
000078d941fe02e2  vmovaps [rsp+0xE0], xmm15
000078d941fe02eb  sub rsp, 0x30
000078d941fe02ef  movaps [rsp], xmm14
000078d941fe02f4  movaps [rsp+0x10], xmm12
000078d941fe02fa  movaps [rsp+0x20], xmm1
000078d941fe02ff  lea rdi, [rsp]
000078d941fe0303  mov esi, 0x00
000078d941fe0308  mov rax, 0x59BFBFBAA530
000078d941fe0312  call rax
000078d941fe0314  movaps xmm14, [rsp]
000078d941fe0319  add rsp, 0x30
000078d941fe031d  vmovaps xmm0, [rsp]
000078d941fe0322  vmovaps xmm1, [rsp+0x10]
000078d941fe0328  vmovaps xmm2, [rsp+0x20]
000078d941fe032e  vmovaps xmm3, [rsp+0x30]
000078d941fe0334  vmovaps xmm4, [rsp+0x40]
000078d941fe033a  vmovaps xmm5, [rsp+0x50]
000078d941fe0340  vmovaps xmm6, [rsp+0x60]
000078d941fe0346  vmovaps xmm7, [rsp+0x70]
000078d941fe034c  vmovaps xmm8, [rsp+0x80]
000078d941fe0355  vmovaps xmm9, [rsp+0x90]
000078d941fe035e  vmovaps xmm10, [rsp+0xA0]
000078d941fe0367  vmovaps xmm11, [rsp+0xB0]
000078d941fe0370  vmovaps xmm12, [rsp+0xC0]
000078d941fe0379  vmovaps xmm13, [rsp+0xD0]
000078d941fe0382  vmovaps xmm15, [rsp+0xE0]
000078d941fe038b  add rsp, 0xF0
000078d941fe0392  pop r11
000078d941fe0394  pop r10
000078d941fe0396  pop r9
000078d941fe0398  pop r8
000078d941fe039a  pop rsi
000078d941fe039b  pop rdi
000078d941fe039c  pop rdx
000078d941fe039d  pop rcx
000078d941fe039e  pop rax
000078d941fe039f  add rsp, 0x08
000078d941fe03a3  jmp 0x000078D941FDC5B3
000078d941fe03a8  sub rsp, 0x08
000078d941fe03ac  push rax
000078d941fe03ad  push rcx
000078d941fe03ae  push rdx
000078d941fe03af  push rdi
000078d941fe03b0  push rsi
000078d941fe03b1  push r8
000078d941fe03b3  push r9
000078d941fe03b5  push r10
000078d941fe03b7  push r11
000078d941fe03b9  sub rsp, 0xF0
000078d941fe03c0  vmovaps [rsp], xmm0
000078d941fe03c5  vmovaps [rsp+0x10], xmm2
000078d941fe03cb  vmovaps [rsp+0x20], xmm3
000078d941fe03d1  vmovaps [rsp+0x30], xmm4
000078d941fe03d7  vmovaps [rsp+0x40], xmm5
000078d941fe03dd  vmovaps [rsp+0x50], xmm6
000078d941fe03e3  vmovaps [rsp+0x60], xmm7
000078d941fe03e9  vmovaps [rsp+0x70], xmm8
000078d941fe03ef  vmovaps [rsp+0x80], xmm9
000078d941fe03f8  vmovaps [rsp+0x90], xmm10
000078d941fe0401  vmovaps [rsp+0xA0], xmm11
000078d941fe040a  vmovaps [rsp+0xB0], xmm12
000078d941fe0413  vmovaps [rsp+0xC0], xmm13
000078d941fe041c  vmovaps [rsp+0xD0], xmm14
000078d941fe0425  vmovaps [rsp+0xE0], xmm15
000078d941fe042e  sub rsp, 0x30
000078d941fe0432  movaps [rsp], xmm1
000078d941fe0436  movaps [rsp+0x10], xmm13
000078d941fe043c  movaps [rsp+0x20], xmm9
000078d941fe0442  lea rdi, [rsp]
000078d941fe0446  mov esi, 0x00
000078d941fe044b  mov rax, 0x59BFBFBAA530
000078d941fe0455  call rax
000078d941fe0457  movaps xmm1, [rsp]
000078d941fe045b  add rsp, 0x30
000078d941fe045f  vmovaps xmm0, [rsp]
000078d941fe0464  vmovaps xmm2, [rsp+0x10]
000078d941fe046a  vmovaps xmm3, [rsp+0x20]
000078d941fe0470  vmovaps xmm4, [rsp+0x30]
000078d941fe0476  vmovaps xmm5, [rsp+0x40]
000078d941fe047c  vmovaps xmm6, [rsp+0x50]
000078d941fe0482  vmovaps xmm7, [rsp+0x60]
000078d941fe0488  vmovaps xmm8, [rsp+0x70]
000078d941fe048e  vmovaps xmm9, [rsp+0x80]
000078d941fe0497  vmovaps xmm10, [rsp+0x90]
000078d941fe04a0  vmovaps xmm11, [rsp+0xA0]
000078d941fe04a9  vmovaps xmm12, [rsp+0xB0]
000078d941fe04b2  vmovaps xmm13, [rsp+0xC0]
000078d941fe04bb  vmovaps xmm14, [rsp+0xD0]
000078d941fe04c4  vmovaps xmm15, [rsp+0xE0]
000078d941fe04cd  add rsp, 0xF0
000078d941fe04d4  pop r11
000078d941fe04d6  pop r10
000078d941fe04d8  pop r9
000078d941fe04da  pop r8
000078d941fe04dc  pop rsi
000078d941fe04dd  pop rdi
000078d941fe04de  pop rdx
000078d941fe04df  pop rcx
000078d941fe04e0  pop rax
000078d941fe04e1  add rsp, 0x08
000078d941fe04e5  jmp 0x000078D941FDC5CD
000078d941fe04ea  sub rsp, 0x08
000078d941fe04ee  push rax
000078d941fe04ef  push rcx
000078d941fe04f0  push rdx
000078d941fe04f1  push rdi
000078d941fe04f2  push rsi
000078d941fe04f3  push r8
000078d941fe04f5  push r9
000078d941fe04f7  push r10
000078d941fe04f9  push r11
000078d941fe04fb  sub rsp, 0xF0
000078d941fe0502  vmovaps [rsp], xmm0
000078d941fe0507  vmovaps [rsp+0x10], xmm1
000078d941fe050d  vmovaps [rsp+0x20], xmm2
000078d941fe0513  vmovaps [rsp+0x30], xmm3
000078d941fe0519  vmovaps [rsp+0x40], xmm4
000078d941fe051f  vmovaps [rsp+0x50], xmm5
000078d941fe0525  vmovaps [rsp+0x60], xmm6
000078d941fe052b  vmovaps [rsp+0x70], xmm7
000078d941fe0531  vmovaps [rsp+0x80], xmm8
000078d941fe053a  vmovaps [rsp+0x90], xmm9
000078d941fe0543  vmovaps [rsp+0xA0], xmm10
000078d941fe054c  vmovaps [rsp+0xB0], xmm11
000078d941fe0555  vmovaps [rsp+0xC0], xmm13
000078d941fe055e  vmovaps [rsp+0xD0], xmm14
000078d941fe0567  vmovaps [rsp+0xE0], xmm15
000078d941fe0570  sub rsp, 0x30
000078d941fe0574  movaps [rsp], xmm12
000078d941fe0579  movaps [rsp+0x10], xmm7
000078d941fe057e  movaps [rsp+0x20], xmm13
000078d941fe0584  lea rdi, [rsp]
000078d941fe0588  mov esi, 0x00
000078d941fe058d  mov rax, 0x59BFBFBAA530
000078d941fe0597  call rax
000078d941fe0599  movaps xmm12, [rsp]
000078d941fe059e  add rsp, 0x30
000078d941fe05a2  vmovaps xmm0, [rsp]
000078d941fe05a7  vmovaps xmm1, [rsp+0x10]
000078d941fe05ad  vmovaps xmm2, [rsp+0x20]
000078d941fe05b3  vmovaps xmm3, [rsp+0x30]
000078d941fe05b9  vmovaps xmm4, [rsp+0x40]
000078d941fe05bf  vmovaps xmm5, [rsp+0x50]
000078d941fe05c5  vmovaps xmm6, [rsp+0x60]
000078d941fe05cb  vmovaps xmm7, [rsp+0x70]
000078d941fe05d1  vmovaps xmm8, [rsp+0x80]
000078d941fe05da  vmovaps xmm9, [rsp+0x90]
000078d941fe05e3  vmovaps xmm10, [rsp+0xA0]
000078d941fe05ec  vmovaps xmm11, [rsp+0xB0]
000078d941fe05f5  vmovaps xmm13, [rsp+0xC0]
000078d941fe05fe  vmovaps xmm14, [rsp+0xD0]
000078d941fe0607  vmovaps xmm15, [rsp+0xE0]
000078d941fe0610  add rsp, 0xF0
000078d941fe0617  pop r11
000078d941fe0619  pop r10
000078d941fe061b  pop r9
000078d941fe061d  pop r8
000078d941fe061f  pop rsi
000078d941fe0620  pop rdi
000078d941fe0621  pop rdx
000078d941fe0622  pop rcx
000078d941fe0623  pop rax
000078d941fe0624  add rsp, 0x08
000078d941fe0628  jmp 0x000078D941FDC5F4
000078d941fe062d  sub rsp, 0x08
000078d941fe0631  push rax
000078d941fe0632  push rcx
000078d941fe0633  push rdx
000078d941fe0634  push rdi
000078d941fe0635  push rsi
000078d941fe0636  push r8
000078d941fe0638  push r9
000078d941fe063a  push r10
000078d941fe063c  push r11
000078d941fe063e  sub rsp, 0xF0
000078d941fe0645  vmovaps [rsp], xmm0
000078d941fe064a  vmovaps [rsp+0x10], xmm1
000078d941fe0650  vmovaps [rsp+0x20], xmm2
000078d941fe0656  vmovaps [rsp+0x30], xmm3
000078d941fe065c  vmovaps [rsp+0x40], xmm4
000078d941fe0662  vmovaps [rsp+0x50], xmm5
000078d941fe0668  vmovaps [rsp+0x60], xmm6
000078d941fe066e  vmovaps [rsp+0x70], xmm7
000078d941fe0674  vmovaps [rsp+0x80], xmm8
000078d941fe067d  vmovaps [rsp+0x90], xmm9
000078d941fe0686  vmovaps [rsp+0xA0], xmm10
000078d941fe068f  vmovaps [rsp+0xB0], xmm11
000078d941fe0698  vmovaps [rsp+0xC0], xmm12
000078d941fe06a1  vmovaps [rsp+0xD0], xmm14
000078d941fe06aa  vmovaps [rsp+0xE0], xmm15
000078d941fe06b3  sub rsp, 0x30
000078d941fe06b7  movaps [rsp], xmm13
000078d941fe06bc  movaps [rsp+0x10], xmm15
000078d941fe06c2  movaps [rsp+0x20], xmm8
000078d941fe06c8  lea rdi, [rsp]
000078d941fe06cc  mov esi, 0x00
000078d941fe06d1  mov rax, 0x59BFBFBAA530
000078d941fe06db  call rax
000078d941fe06dd  movaps xmm13, [rsp]
000078d941fe06e2  add rsp, 0x30
000078d941fe06e6  vmovaps xmm0, [rsp]
000078d941fe06eb  vmovaps xmm1, [rsp+0x10]
000078d941fe06f1  vmovaps xmm2, [rsp+0x20]
000078d941fe06f7  vmovaps xmm3, [rsp+0x30]
000078d941fe06fd  vmovaps xmm4, [rsp+0x40]
000078d941fe0703  vmovaps xmm5, [rsp+0x50]
000078d941fe0709  vmovaps xmm6, [rsp+0x60]
000078d941fe070f  vmovaps xmm7, [rsp+0x70]
000078d941fe0715  vmovaps xmm8, [rsp+0x80]
000078d941fe071e  vmovaps xmm9, [rsp+0x90]
000078d941fe0727  vmovaps xmm10, [rsp+0xA0]
000078d941fe0730  vmovaps xmm11, [rsp+0xB0]
000078d941fe0739  vmovaps xmm12, [rsp+0xC0]
000078d941fe0742  vmovaps xmm14, [rsp+0xD0]
000078d941fe074b  vmovaps xmm15, [rsp+0xE0]
000078d941fe0754  add rsp, 0xF0
000078d941fe075b  pop r11
000078d941fe075d  pop r10
000078d941fe075f  pop r9
000078d941fe0761  pop r8
000078d941fe0763  pop rsi
000078d941fe0764  pop rdi
000078d941fe0765  pop rdx
000078d941fe0766  pop rcx
000078d941fe0767  pop rax
000078d941fe0768  add rsp, 0x08
000078d941fe076c  jmp 0x000078D941FDC60F
000078d941fe0771  sub rsp, 0x08
000078d941fe0775  push rax
000078d941fe0776  push rcx
000078d941fe0777  push rdx
000078d941fe0778  push rdi
000078d941fe0779  push rsi
000078d941fe077a  push r8
000078d941fe077c  push r9
000078d941fe077e  push r10
000078d941fe0780  push r11
000078d941fe0782  sub rsp, 0xF0
000078d941fe0789  vmovaps [rsp], xmm0
000078d941fe078e  vmovaps [rsp+0x10], xmm1
000078d941fe0794  vmovaps [rsp+0x20], xmm2
000078d941fe079a  vmovaps [rsp+0x30], xmm3
000078d941fe07a0  vmovaps [rsp+0x40], xmm4
000078d941fe07a6  vmovaps [rsp+0x50], xmm5
000078d941fe07ac  vmovaps [rsp+0x60], xmm6
000078d941fe07b2  vmovaps [rsp+0x70], xmm7
000078d941fe07b8  vmovaps [rsp+0x80], xmm9
000078d941fe07c1  vmovaps [rsp+0x90], xmm10
000078d941fe07ca  vmovaps [rsp+0xA0], xmm11
000078d941fe07d3  vmovaps [rsp+0xB0], xmm12
000078d941fe07dc  vmovaps [rsp+0xC0], xmm13
000078d941fe07e5  vmovaps [rsp+0xD0], xmm14
000078d941fe07ee  vmovaps [rsp+0xE0], xmm15
000078d941fe07f7  sub rsp, 0x30
000078d941fe07fb  movaps [rsp], xmm8
000078d941fe0800  movaps [rsp+0x10], xmm15
000078d941fe0806  movaps [rsp+0x20], xmm9
000078d941fe080c  lea rdi, [rsp]
000078d941fe0810  mov esi, 0x00
000078d941fe0815  mov rax, 0x59BFBFBAA530
000078d941fe081f  call rax
000078d941fe0821  movaps xmm8, [rsp]
000078d941fe0826  add rsp, 0x30
000078d941fe082a  vmovaps xmm0, [rsp]
000078d941fe082f  vmovaps xmm1, [rsp+0x10]
000078d941fe0835  vmovaps xmm2, [rsp+0x20]
000078d941fe083b  vmovaps xmm3, [rsp+0x30]
000078d941fe0841  vmovaps xmm4, [rsp+0x40]
000078d941fe0847  vmovaps xmm5, [rsp+0x50]
000078d941fe084d  vmovaps xmm6, [rsp+0x60]
000078d941fe0853  vmovaps xmm7, [rsp+0x70]
000078d941fe0859  vmovaps xmm9, [rsp+0x80]
000078d941fe0862  vmovaps xmm10, [rsp+0x90]
000078d941fe086b  vmovaps xmm11, [rsp+0xA0]
000078d941fe0874  vmovaps xmm12, [rsp+0xB0]
000078d941fe087d  vmovaps xmm13, [rsp+0xC0]
000078d941fe0886  vmovaps xmm14, [rsp+0xD0]
000078d941fe088f  vmovaps xmm15, [rsp+0xE0]
000078d941fe0898  add rsp, 0xF0
000078d941fe089f  pop r11
000078d941fe08a1  pop r10
000078d941fe08a3  pop r9
000078d941fe08a5  pop r8
000078d941fe08a7  pop rsi
000078d941fe08a8  pop rdi
000078d941fe08a9  pop rdx
000078d941fe08aa  pop rcx
000078d941fe08ab  pop rax
000078d941fe08ac  add rsp, 0x08
000078d941fe08b0  jmp 0x000078D941FDC63D
000078d941fe08b5  sub rsp, 0x08
000078d941fe08b9  push rax
000078d941fe08ba  push rcx
000078d941fe08bb  push rdx
000078d941fe08bc  push rdi
000078d941fe08bd  push rsi
000078d941fe08be  push r8
000078d941fe08c0  push r9
000078d941fe08c2  push r10
000078d941fe08c4  push r11
000078d941fe08c6  sub rsp, 0xF0
000078d941fe08cd  vmovaps [rsp], xmm0
000078d941fe08d2  vmovaps [rsp+0x10], xmm1
000078d941fe08d8  vmovaps [rsp+0x20], xmm2
000078d941fe08de  vmovaps [rsp+0x30], xmm3
000078d941fe08e4  vmovaps [rsp+0x40], xmm4
000078d941fe08ea  vmovaps [rsp+0x50], xmm5
000078d941fe08f0  vmovaps [rsp+0x60], xmm6
000078d941fe08f6  vmovaps [rsp+0x70], xmm7
000078d941fe08fc  vmovaps [rsp+0x80], xmm8
000078d941fe0905  vmovaps [rsp+0x90], xmm9
000078d941fe090e  vmovaps [rsp+0xA0], xmm10
000078d941fe0917  vmovaps [rsp+0xB0], xmm11
000078d941fe0920  vmovaps [rsp+0xC0], xmm12
000078d941fe0929  vmovaps [rsp+0xD0], xmm13
000078d941fe0932  vmovaps [rsp+0xE0], xmm14
000078d941fe093b  sub rsp, 0x30
000078d941fe093f  movaps [rsp], xmm15
000078d941fe0944  movaps [rsp+0x10], xmm11
000078d941fe094a  movaps [rsp+0x20], xmm6
000078d941fe094f  lea rdi, [rsp]
000078d941fe0953  mov esi, 0x00
000078d941fe0958  mov rax, 0x59BFBFBAA530
000078d941fe0962  call rax
000078d941fe0964  movaps xmm15, [rsp]
000078d941fe0969  add rsp, 0x30
000078d941fe096d  vmovaps xmm0, [rsp]
000078d941fe0972  vmovaps xmm1, [rsp+0x10]
000078d941fe0978  vmovaps xmm2, [rsp+0x20]
000078d941fe097e  vmovaps xmm3, [rsp+0x30]
000078d941fe0984  vmovaps xmm4, [rsp+0x40]
000078d941fe098a  vmovaps xmm5, [rsp+0x50]
000078d941fe0990  vmovaps xmm6, [rsp+0x60]
000078d941fe0996  vmovaps xmm7, [rsp+0x70]
000078d941fe099c  vmovaps xmm8, [rsp+0x80]
000078d941fe09a5  vmovaps xmm9, [rsp+0x90]
000078d941fe09ae  vmovaps xmm10, [rsp+0xA0]
000078d941fe09b7  vmovaps xmm11, [rsp+0xB0]
000078d941fe09c0  vmovaps xmm12, [rsp+0xC0]
000078d941fe09c9  vmovaps xmm13, [rsp+0xD0]
000078d941fe09d2  vmovaps xmm14, [rsp+0xE0]
000078d941fe09db  add rsp, 0xF0
000078d941fe09e2  pop r11
000078d941fe09e4  pop r10
000078d941fe09e6  pop r9
000078d941fe09e8  pop r8
000078d941fe09ea  pop rsi
000078d941fe09eb  pop rdi
000078d941fe09ec  pop rdx
000078d941fe09ed  pop rcx
000078d941fe09ee  pop rax
000078d941fe09ef  add rsp, 0x08
000078d941fe09f3  jmp 0x000078D941FDC658
000078d941fe09f8  sub rsp, 0x08
000078d941fe09fc  push rax
000078d941fe09fd  push rcx
000078d941fe09fe  push rdx
000078d941fe09ff  push rdi
000078d941fe0a00  push rsi
000078d941fe0a01  push r8
000078d941fe0a03  push r9
000078d941fe0a05  push r10
000078d941fe0a07  push r11
000078d941fe0a09  sub rsp, 0xF0
000078d941fe0a10  vmovaps [rsp], xmm0
000078d941fe0a15  vmovaps [rsp+0x10], xmm1
000078d941fe0a1b  vmovaps [rsp+0x20], xmm2
000078d941fe0a21  vmovaps [rsp+0x30], xmm3
000078d941fe0a27  vmovaps [rsp+0x40], xmm4
000078d941fe0a2d  vmovaps [rsp+0x50], xmm5
000078d941fe0a33  vmovaps [rsp+0x60], xmm6
000078d941fe0a39  vmovaps [rsp+0x70], xmm8
000078d941fe0a3f  vmovaps [rsp+0x80], xmm9
000078d941fe0a48  vmovaps [rsp+0x90], xmm10
000078d941fe0a51  vmovaps [rsp+0xA0], xmm11
000078d941fe0a5a  vmovaps [rsp+0xB0], xmm12
000078d941fe0a63  vmovaps [rsp+0xC0], xmm13
000078d941fe0a6c  vmovaps [rsp+0xD0], xmm14
000078d941fe0a75  vmovaps [rsp+0xE0], xmm15
000078d941fe0a7e  sub rsp, 0x30
000078d941fe0a82  movaps [rsp], xmm7
000078d941fe0a86  movaps [rsp+0x10], xmm11
000078d941fe0a8c  movaps [rsp+0x20], xmm9
000078d941fe0a92  lea rdi, [rsp]
000078d941fe0a96  mov esi, 0x00
000078d941fe0a9b  mov rax, 0x59BFBFBAA530
000078d941fe0aa5  call rax
000078d941fe0aa7  movaps xmm7, [rsp]
000078d941fe0aab  add rsp, 0x30
000078d941fe0aaf  vmovaps xmm0, [rsp]
000078d941fe0ab4  vmovaps xmm1, [rsp+0x10]
000078d941fe0aba  vmovaps xmm2, [rsp+0x20]
000078d941fe0ac0  vmovaps xmm3, [rsp+0x30]
000078d941fe0ac6  vmovaps xmm4, [rsp+0x40]
000078d941fe0acc  vmovaps xmm5, [rsp+0x50]
000078d941fe0ad2  vmovaps xmm6, [rsp+0x60]
000078d941fe0ad8  vmovaps xmm8, [rsp+0x70]
000078d941fe0ade  vmovaps xmm9, [rsp+0x80]
000078d941fe0ae7  vmovaps xmm10, [rsp+0x90]
000078d941fe0af0  vmovaps xmm11, [rsp+0xA0]
000078d941fe0af9  vmovaps xmm12, [rsp+0xB0]
000078d941fe0b02  vmovaps xmm13, [rsp+0xC0]
000078d941fe0b0b  vmovaps xmm14, [rsp+0xD0]
000078d941fe0b14  vmovaps xmm15, [rsp+0xE0]
000078d941fe0b1d  add rsp, 0xF0
000078d941fe0b24  pop r11
000078d941fe0b26  pop r10
000078d941fe0b28  pop r9
000078d941fe0b2a  pop r8
000078d941fe0b2c  pop rsi
000078d941fe0b2d  pop rdi
000078d941fe0b2e  pop rdx
000078d941fe0b2f  pop rcx
000078d941fe0b30  pop rax
000078d941fe0b31  add rsp, 0x08
000078d941fe0b35  jmp 0x000078D941FDC685
000078d941fe0b3a  sub rsp, 0x08
000078d941fe0b3e  push rax
000078d941fe0b3f  push rcx
000078d941fe0b40  push rdx
000078d941fe0b41  push rdi
000078d941fe0b42  push rsi
000078d941fe0b43  push r8
000078d941fe0b45  push r9
000078d941fe0b47  push r10
000078d941fe0b49  push r11
000078d941fe0b4b  sub rsp, 0xF0
000078d941fe0b52  vmovaps [rsp], xmm0
000078d941fe0b57  vmovaps [rsp+0x10], xmm1
000078d941fe0b5d  vmovaps [rsp+0x20], xmm2
000078d941fe0b63  vmovaps [rsp+0x30], xmm3
000078d941fe0b69  vmovaps [rsp+0x40], xmm4
000078d941fe0b6f  vmovaps [rsp+0x50], xmm5
000078d941fe0b75  vmovaps [rsp+0x60], xmm6
000078d941fe0b7b  vmovaps [rsp+0x70], xmm7
000078d941fe0b81  vmovaps [rsp+0x80], xmm8
000078d941fe0b8a  vmovaps [rsp+0x90], xmm9
000078d941fe0b93  vmovaps [rsp+0xA0], xmm10
000078d941fe0b9c  vmovaps [rsp+0xB0], xmm12
000078d941fe0ba5  vmovaps [rsp+0xC0], xmm13
000078d941fe0bae  vmovaps [rsp+0xD0], xmm14
000078d941fe0bb7  vmovaps [rsp+0xE0], xmm15
000078d941fe0bc0  sub rsp, 0x30
000078d941fe0bc4  movaps [rsp], xmm11
000078d941fe0bc9  movaps [rsp+0x10], xmm10
000078d941fe0bcf  movaps [rsp+0x20], xmm14
000078d941fe0bd5  lea rdi, [rsp]
000078d941fe0bd9  mov esi, 0x00
000078d941fe0bde  mov rax, 0x59BFBFBAA530
000078d941fe0be8  call rax
000078d941fe0bea  movaps xmm11, [rsp]
000078d941fe0bef  add rsp, 0x30
000078d941fe0bf3  vmovaps xmm0, [rsp]
000078d941fe0bf8  vmovaps xmm1, [rsp+0x10]
000078d941fe0bfe  vmovaps xmm2, [rsp+0x20]
000078d941fe0c04  vmovaps xmm3, [rsp+0x30]
000078d941fe0c0a  vmovaps xmm4, [rsp+0x40]
000078d941fe0c10  vmovaps xmm5, [rsp+0x50]
000078d941fe0c16  vmovaps xmm6, [rsp+0x60]
000078d941fe0c1c  vmovaps xmm7, [rsp+0x70]
000078d941fe0c22  vmovaps xmm8, [rsp+0x80]
000078d941fe0c2b  vmovaps xmm9, [rsp+0x90]
000078d941fe0c34  vmovaps xmm10, [rsp+0xA0]
000078d941fe0c3d  vmovaps xmm12, [rsp+0xB0]
000078d941fe0c46  vmovaps xmm13, [rsp+0xC0]
000078d941fe0c4f  vmovaps xmm14, [rsp+0xD0]
000078d941fe0c58  vmovaps xmm15, [rsp+0xE0]
000078d941fe0c61  add rsp, 0xF0
000078d941fe0c68  pop r11
000078d941fe0c6a  pop r10
000078d941fe0c6c  pop r9
000078d941fe0c6e  pop r8
000078d941fe0c70  pop rsi
000078d941fe0c71  pop rdi
000078d941fe0c72  pop rdx
000078d941fe0c73  pop rcx
000078d941fe0c74  pop rax
000078d941fe0c75  add rsp, 0x08
000078d941fe0c79  jmp 0x000078D941FDC6A0
000078d941fe0c7e  call 0x000078D941EC33A0
000078d941fe0c83  jmp 0x000078D941FDC6AA
000078d941fe0c88  sub rsp, 0x08
000078d941fe0c8c  push rax
000078d941fe0c8d  push rcx
000078d941fe0c8e  push rdx
000078d941fe0c8f  push rdi
000078d941fe0c90  push rsi
000078d941fe0c91  push r8
000078d941fe0c93  push r9
000078d941fe0c95  push r10
000078d941fe0c97  push r11
000078d941fe0c99  sub rsp, 0xF0
000078d941fe0ca0  vmovaps [rsp], xmm0
000078d941fe0ca5  vmovaps [rsp+0x10], xmm1
000078d941fe0cab  vmovaps [rsp+0x20], xmm2
000078d941fe0cb1  vmovaps [rsp+0x30], xmm3
000078d941fe0cb7  vmovaps [rsp+0x40], xmm4
000078d941fe0cbd  vmovaps [rsp+0x50], xmm5
000078d941fe0cc3  vmovaps [rsp+0x60], xmm6
000078d941fe0cc9  vmovaps [rsp+0x70], xmm7
000078d941fe0ccf  vmovaps [rsp+0x80], xmm8
000078d941fe0cd8  vmovaps [rsp+0x90], xmm9
000078d941fe0ce1  vmovaps [rsp+0xA0], xmm11
000078d941fe0cea  vmovaps [rsp+0xB0], xmm12
000078d941fe0cf3  vmovaps [rsp+0xC0], xmm13
000078d941fe0cfc  vmovaps [rsp+0xD0], xmm14
000078d941fe0d05  vmovaps [rsp+0xE0], xmm15
000078d941fe0d0e  sub rsp, 0x30
000078d941fe0d12  movaps [rsp], xmm10
000078d941fe0d17  movaps [rsp+0x10], xmm1
000078d941fe0d1c  movaps [rsp+0x20], xmm12
000078d941fe0d22  lea rdi, [rsp]
000078d941fe0d26  mov esi, 0x00
000078d941fe0d2b  mov rax, 0x59BFBFBAA530
000078d941fe0d35  call rax
000078d941fe0d37  movaps xmm10, [rsp]
000078d941fe0d3c  add rsp, 0x30
000078d941fe0d40  vmovaps xmm0, [rsp]
000078d941fe0d45  vmovaps xmm1, [rsp+0x10]
000078d941fe0d4b  vmovaps xmm2, [rsp+0x20]
000078d941fe0d51  vmovaps xmm3, [rsp+0x30]
000078d941fe0d57  vmovaps xmm4, [rsp+0x40]
000078d941fe0d5d  vmovaps xmm5, [rsp+0x50]
000078d941fe0d63  vmovaps xmm6, [rsp+0x60]
000078d941fe0d69  vmovaps xmm7, [rsp+0x70]
000078d941fe0d6f  vmovaps xmm8, [rsp+0x80]
000078d941fe0d78  vmovaps xmm9, [rsp+0x90]
000078d941fe0d81  vmovaps xmm11, [rsp+0xA0]
000078d941fe0d8a  vmovaps xmm12, [rsp+0xB0]
000078d941fe0d93  vmovaps xmm13, [rsp+0xC0]
000078d941fe0d9c  vmovaps xmm14, [rsp+0xD0]
000078d941fe0da5  vmovaps xmm15, [rsp+0xE0]
000078d941fe0dae  add rsp, 0xF0
000078d941fe0db5  pop r11
000078d941fe0db7  pop r10
000078d941fe0db9  pop r9
000078d941fe0dbb  pop r8
000078d941fe0dbd  pop rsi
000078d941fe0dbe  pop rdi
000078d941fe0dbf  pop rdx
000078d941fe0dc0  pop rcx
000078d941fe0dc1  pop rax
000078d941fe0dc2  add rsp, 0x08
000078d941fe0dc6  jmp 0x000078D941FDC6CD
000078d941fe0dcb  sub rsp, 0x08
000078d941fe0dcf  push rax
000078d941fe0dd0  push rcx
000078d941fe0dd1  push rdx
000078d941fe0dd2  push rdi
000078d941fe0dd3  push rsi
000078d941fe0dd4  push r8
000078d941fe0dd6  push r9
000078d941fe0dd8  push r10
000078d941fe0dda  push r11
000078d941fe0ddc  sub rsp, 0xF0
000078d941fe0de3  vmovaps [rsp], xmm0
000078d941fe0de8  vmovaps [rsp+0x10], xmm1
000078d941fe0dee  vmovaps [rsp+0x20], xmm2
000078d941fe0df4  vmovaps [rsp+0x30], xmm3
000078d941fe0dfa  vmovaps [rsp+0x40], xmm4
000078d941fe0e00  vmovaps [rsp+0x50], xmm5
000078d941fe0e06  vmovaps [rsp+0x60], xmm6
000078d941fe0e0c  vmovaps [rsp+0x70], xmm7
000078d941fe0e12  vmovaps [rsp+0x80], xmm8
000078d941fe0e1b  vmovaps [rsp+0x90], xmm9
000078d941fe0e24  vmovaps [rsp+0xA0], xmm10
000078d941fe0e2d  vmovaps [rsp+0xB0], xmm11
000078d941fe0e36  vmovaps [rsp+0xC0], xmm13
000078d941fe0e3f  vmovaps [rsp+0xD0], xmm14
000078d941fe0e48  vmovaps [rsp+0xE0], xmm15
000078d941fe0e51  sub rsp, 0x30
000078d941fe0e55  movaps [rsp], xmm12
000078d941fe0e5a  movaps [rsp+0x10], xmm14
000078d941fe0e60  movaps [rsp+0x20], xmm1
000078d941fe0e65  lea rdi, [rsp]
000078d941fe0e69  mov esi, 0x00
000078d941fe0e6e  mov rax, 0x59BFBFBAA530
000078d941fe0e78  call rax
000078d941fe0e7a  movaps xmm12, [rsp]
000078d941fe0e7f  add rsp, 0x30
000078d941fe0e83  vmovaps xmm0, [rsp]
000078d941fe0e88  vmovaps xmm1, [rsp+0x10]
000078d941fe0e8e  vmovaps xmm2, [rsp+0x20]
000078d941fe0e94  vmovaps xmm3, [rsp+0x30]
000078d941fe0e9a  vmovaps xmm4, [rsp+0x40]
000078d941fe0ea0  vmovaps xmm5, [rsp+0x50]
000078d941fe0ea6  vmovaps xmm6, [rsp+0x60]
000078d941fe0eac  vmovaps xmm7, [rsp+0x70]
000078d941fe0eb2  vmovaps xmm8, [rsp+0x80]
000078d941fe0ebb  vmovaps xmm9, [rsp+0x90]
000078d941fe0ec4  vmovaps xmm10, [rsp+0xA0]
000078d941fe0ecd  vmovaps xmm11, [rsp+0xB0]
000078d941fe0ed6  vmovaps xmm13, [rsp+0xC0]
000078d941fe0edf  vmovaps xmm14, [rsp+0xD0]
000078d941fe0ee8  vmovaps xmm15, [rsp+0xE0]
000078d941fe0ef1  add rsp, 0xF0
000078d941fe0ef8  pop r11
000078d941fe0efa  pop r10
000078d941fe0efc  pop r9
000078d941fe0efe  pop r8
000078d941fe0f00  pop rsi
000078d941fe0f01  pop rdi
000078d941fe0f02  pop rdx
000078d941fe0f03  pop rcx
000078d941fe0f04  pop rax
000078d941fe0f05  add rsp, 0x08
000078d941fe0f09  jmp 0x000078D941FDC6FC
000078d941fe0f0e  sub rsp, 0x08
000078d941fe0f12  push rax
000078d941fe0f13  push rcx
000078d941fe0f14  push rdx
000078d941fe0f15  push rdi
000078d941fe0f16  push rsi
000078d941fe0f17  push r8
000078d941fe0f19  push r9
000078d941fe0f1b  push r10
000078d941fe0f1d  push r11
000078d941fe0f1f  sub rsp, 0xF0
000078d941fe0f26  vmovaps [rsp], xmm0
000078d941fe0f2b  vmovaps [rsp+0x10], xmm1
000078d941fe0f31  vmovaps [rsp+0x20], xmm2
000078d941fe0f37  vmovaps [rsp+0x30], xmm3
000078d941fe0f3d  vmovaps [rsp+0x40], xmm4
000078d941fe0f43  vmovaps [rsp+0x50], xmm5
000078d941fe0f49  vmovaps [rsp+0x60], xmm6
000078d941fe0f4f  vmovaps [rsp+0x70], xmm7
000078d941fe0f55  vmovaps [rsp+0x80], xmm8
000078d941fe0f5e  vmovaps [rsp+0x90], xmm9
000078d941fe0f67  vmovaps [rsp+0xA0], xmm10
000078d941fe0f70  vmovaps [rsp+0xB0], xmm11
000078d941fe0f79  vmovaps [rsp+0xC0], xmm12
000078d941fe0f82  vmovaps [rsp+0xD0], xmm13
000078d941fe0f8b  vmovaps [rsp+0xE0], xmm15
000078d941fe0f94  sub rsp, 0x30
000078d941fe0f98  movaps [rsp], xmm14
000078d941fe0f9d  movaps [rsp+0x10], xmm9
000078d941fe0fa3  movaps [rsp+0x20], xmm1
000078d941fe0fa8  lea rdi, [rsp]
000078d941fe0fac  mov esi, 0x00
000078d941fe0fb1  mov rax, 0x59BFBFBAA530
000078d941fe0fbb  call rax
000078d941fe0fbd  movaps xmm14, [rsp]
000078d941fe0fc2  add rsp, 0x30
000078d941fe0fc6  vmovaps xmm0, [rsp]
000078d941fe0fcb  vmovaps xmm1, [rsp+0x10]
000078d941fe0fd1  vmovaps xmm2, [rsp+0x20]
000078d941fe0fd7  vmovaps xmm3, [rsp+0x30]
000078d941fe0fdd  vmovaps xmm4, [rsp+0x40]
000078d941fe0fe3  vmovaps xmm5, [rsp+0x50]
000078d941fe0fe9  vmovaps xmm6, [rsp+0x60]
000078d941fe0fef  vmovaps xmm7, [rsp+0x70]
000078d941fe0ff5  vmovaps xmm8, [rsp+0x80]
000078d941fe0ffe  vmovaps xmm9, [rsp+0x90]
000078d941fe1007  vmovaps xmm10, [rsp+0xA0]
000078d941fe1010  vmovaps xmm11, [rsp+0xB0]
000078d941fe1019  vmovaps xmm12, [rsp+0xC0]
000078d941fe1022  vmovaps xmm13, [rsp+0xD0]
000078d941fe102b  vmovaps xmm15, [rsp+0xE0]
000078d941fe1034  add rsp, 0xF0
000078d941fe103b  pop r11
000078d941fe103d  pop r10
000078d941fe103f  pop r9
000078d941fe1041  pop r8
000078d941fe1043  pop rsi
000078d941fe1044  pop rdi
000078d941fe1045  pop rdx
000078d941fe1046  pop rcx
000078d941fe1047  pop rax
000078d941fe1048  add rsp, 0x08
000078d941fe104c  jmp 0x000078D941FDC72B
000078d941fe1051  sub rsp, 0x08
000078d941fe1055  push rax
000078d941fe1056  push rcx
000078d941fe1057  push rdx
000078d941fe1058  push rdi
000078d941fe1059  push rsi
000078d941fe105a  push r8
000078d941fe105c  push r9
000078d941fe105e  push r10
000078d941fe1060  push r11
000078d941fe1062  sub rsp, 0xF0
000078d941fe1069  vmovaps [rsp], xmm0
000078d941fe106e  vmovaps [rsp+0x10], xmm2
000078d941fe1074  vmovaps [rsp+0x20], xmm3
000078d941fe107a  vmovaps [rsp+0x30], xmm4
000078d941fe1080  vmovaps [rsp+0x40], xmm5
000078d941fe1086  vmovaps [rsp+0x50], xmm6
000078d941fe108c  vmovaps [rsp+0x60], xmm7
000078d941fe1092  vmovaps [rsp+0x70], xmm8
000078d941fe1098  vmovaps [rsp+0x80], xmm9
000078d941fe10a1  vmovaps [rsp+0x90], xmm10
000078d941fe10aa  vmovaps [rsp+0xA0], xmm11
000078d941fe10b3  vmovaps [rsp+0xB0], xmm12
000078d941fe10bc  vmovaps [rsp+0xC0], xmm13
000078d941fe10c5  vmovaps [rsp+0xD0], xmm14
000078d941fe10ce  vmovaps [rsp+0xE0], xmm15
000078d941fe10d7  sub rsp, 0x30
000078d941fe10db  movaps [rsp], xmm1
000078d941fe10df  movaps [rsp+0x10], xmm13
000078d941fe10e5  movaps [rsp+0x20], xmm8
000078d941fe10eb  lea rdi, [rsp]
000078d941fe10ef  mov esi, 0x00
000078d941fe10f4  mov rax, 0x59BFBFBAA530
000078d941fe10fe  call rax
000078d941fe1100  movaps xmm1, [rsp]
000078d941fe1104  add rsp, 0x30
000078d941fe1108  vmovaps xmm0, [rsp]
000078d941fe110d  vmovaps xmm2, [rsp+0x10]
000078d941fe1113  vmovaps xmm3, [rsp+0x20]
000078d941fe1119  vmovaps xmm4, [rsp+0x30]
000078d941fe111f  vmovaps xmm5, [rsp+0x40]
000078d941fe1125  vmovaps xmm6, [rsp+0x50]
000078d941fe112b  vmovaps xmm7, [rsp+0x60]
000078d941fe1131  vmovaps xmm8, [rsp+0x70]
000078d941fe1137  vmovaps xmm9, [rsp+0x80]
000078d941fe1140  vmovaps xmm10, [rsp+0x90]
000078d941fe1149  vmovaps xmm11, [rsp+0xA0]
000078d941fe1152  vmovaps xmm12, [rsp+0xB0]
000078d941fe115b  vmovaps xmm13, [rsp+0xC0]
000078d941fe1164  vmovaps xmm14, [rsp+0xD0]
000078d941fe116d  vmovaps xmm15, [rsp+0xE0]
000078d941fe1176  add rsp, 0xF0
000078d941fe117d  pop r11
000078d941fe117f  pop r10
000078d941fe1181  pop r9
000078d941fe1183  pop r8
000078d941fe1185  pop rsi
000078d941fe1186  pop rdi
000078d941fe1187  pop rdx
000078d941fe1188  pop rcx
000078d941fe1189  pop rax
000078d941fe118a  add rsp, 0x08
000078d941fe118e  jmp 0x000078D941FDC74D
000078d941fe1193  call 0x000078D941E0C260
000078d941fe1198  jmp 0x000078D941FDC75B
000078d941fe119d  call 0x000078D941EBD750
000078d941fe11a2  jmp 0x000078D941FDC765
000078d941fe11a7  sub rsp, 0x08
000078d941fe11ab  push rax
000078d941fe11ac  push rcx
000078d941fe11ad  push rdx
000078d941fe11ae  push rdi
000078d941fe11af  push rsi
000078d941fe11b0  push r8
000078d941fe11b2  push r9
000078d941fe11b4  push r10
000078d941fe11b6  push r11
000078d941fe11b8  sub rsp, 0xF0
000078d941fe11bf  vmovaps [rsp], xmm0
000078d941fe11c4  vmovaps [rsp+0x10], xmm1
000078d941fe11ca  vmovaps [rsp+0x20], xmm2
000078d941fe11d0  vmovaps [rsp+0x30], xmm3
000078d941fe11d6  vmovaps [rsp+0x40], xmm4
000078d941fe11dc  vmovaps [rsp+0x50], xmm5
000078d941fe11e2  vmovaps [rsp+0x60], xmm6
000078d941fe11e8  vmovaps [rsp+0x70], xmm7
000078d941fe11ee  vmovaps [rsp+0x80], xmm9
000078d941fe11f7  vmovaps [rsp+0x90], xmm10
000078d941fe1200  vmovaps [rsp+0xA0], xmm11
000078d941fe1209  vmovaps [rsp+0xB0], xmm12
000078d941fe1212  vmovaps [rsp+0xC0], xmm13
000078d941fe121b  vmovaps [rsp+0xD0], xmm14
000078d941fe1224  vmovaps [rsp+0xE0], xmm15
000078d941fe122d  sub rsp, 0x30
000078d941fe1231  movaps [rsp], xmm8
000078d941fe1236  movaps [rsp+0x10], xmm15
000078d941fe123c  movaps [rsp+0x20], xmm7
000078d941fe1241  lea rdi, [rsp]
000078d941fe1245  mov esi, 0x00
000078d941fe124a  mov rax, 0x59BFBFBAA530
000078d941fe1254  call rax
000078d941fe1256  movaps xmm8, [rsp]
000078d941fe125b  add rsp, 0x30
000078d941fe125f  vmovaps xmm0, [rsp]
000078d941fe1264  vmovaps xmm1, [rsp+0x10]
000078d941fe126a  vmovaps xmm2, [rsp+0x20]
000078d941fe1270  vmovaps xmm3, [rsp+0x30]
000078d941fe1276  vmovaps xmm4, [rsp+0x40]
000078d941fe127c  vmovaps xmm5, [rsp+0x50]
000078d941fe1282  vmovaps xmm6, [rsp+0x60]
000078d941fe1288  vmovaps xmm7, [rsp+0x70]
000078d941fe128e  vmovaps xmm9, [rsp+0x80]
000078d941fe1297  vmovaps xmm10, [rsp+0x90]
000078d941fe12a0  vmovaps xmm11, [rsp+0xA0]
000078d941fe12a9  vmovaps xmm12, [rsp+0xB0]
000078d941fe12b2  vmovaps xmm13, [rsp+0xC0]
000078d941fe12bb  vmovaps xmm14, [rsp+0xD0]
000078d941fe12c4  vmovaps xmm15, [rsp+0xE0]
000078d941fe12cd  add rsp, 0xF0
000078d941fe12d4  pop r11
000078d941fe12d6  pop r10
000078d941fe12d8  pop r9
000078d941fe12da  pop r8
000078d941fe12dc  pop rsi
000078d941fe12dd  pop rdi
000078d941fe12de  pop rdx
000078d941fe12df  pop rcx
000078d941fe12e0  pop rax
000078d941fe12e1  add rsp, 0x08
000078d941fe12e5  jmp 0x000078D941FDC787
000078d941fe12ea  sub rsp, 0x08
000078d941fe12ee  push rax
000078d941fe12ef  push rcx
000078d941fe12f0  push rdx
000078d941fe12f1  push rdi
000078d941fe12f2  push rsi
000078d941fe12f3  push r8
000078d941fe12f5  push r9
000078d941fe12f7  push r10
000078d941fe12f9  push r11
000078d941fe12fb  sub rsp, 0xF0
000078d941fe1302  vmovaps [rsp], xmm0
000078d941fe1307  vmovaps [rsp+0x10], xmm1
000078d941fe130d  vmovaps [rsp+0x20], xmm2
000078d941fe1313  vmovaps [rsp+0x30], xmm3
000078d941fe1319  vmovaps [rsp+0x40], xmm4
000078d941fe131f  vmovaps [rsp+0x50], xmm5
000078d941fe1325  vmovaps [rsp+0x60], xmm6
000078d941fe132b  vmovaps [rsp+0x70], xmm8
000078d941fe1331  vmovaps [rsp+0x80], xmm9
000078d941fe133a  vmovaps [rsp+0x90], xmm10
000078d941fe1343  vmovaps [rsp+0xA0], xmm11
000078d941fe134c  vmovaps [rsp+0xB0], xmm12
000078d941fe1355  vmovaps [rsp+0xC0], xmm13
000078d941fe135e  vmovaps [rsp+0xD0], xmm14
000078d941fe1367  vmovaps [rsp+0xE0], xmm15
000078d941fe1370  sub rsp, 0x30
000078d941fe1374  movaps [rsp], xmm7
000078d941fe1378  movaps [rsp+0x10], xmm9
000078d941fe137e  movaps [rsp+0x20], xmm15
000078d941fe1384  lea rdi, [rsp]
000078d941fe1388  mov esi, 0x00
000078d941fe138d  mov rax, 0x59BFBFBAA530
000078d941fe1397  call rax
000078d941fe1399  movaps xmm7, [rsp]
000078d941fe139d  add rsp, 0x30
000078d941fe13a1  vmovaps xmm0, [rsp]
000078d941fe13a6  vmovaps xmm1, [rsp+0x10]
000078d941fe13ac  vmovaps xmm2, [rsp+0x20]
000078d941fe13b2  vmovaps xmm3, [rsp+0x30]
000078d941fe13b8  vmovaps xmm4, [rsp+0x40]
000078d941fe13be  vmovaps xmm5, [rsp+0x50]
000078d941fe13c4  vmovaps xmm6, [rsp+0x60]
000078d941fe13ca  vmovaps xmm8, [rsp+0x70]
000078d941fe13d0  vmovaps xmm9, [rsp+0x80]
000078d941fe13d9  vmovaps xmm10, [rsp+0x90]
000078d941fe13e2  vmovaps xmm11, [rsp+0xA0]
000078d941fe13eb  vmovaps xmm12, [rsp+0xB0]
000078d941fe13f4  vmovaps xmm13, [rsp+0xC0]
000078d941fe13fd  vmovaps xmm14, [rsp+0xD0]
000078d941fe1406  vmovaps xmm15, [rsp+0xE0]
000078d941fe140f  add rsp, 0xF0
000078d941fe1416  pop r11
000078d941fe1418  pop r10
000078d941fe141a  pop r9
000078d941fe141c  pop r8
000078d941fe141e  pop rsi
000078d941fe141f  pop rdi
000078d941fe1420  pop rdx
000078d941fe1421  pop rcx
000078d941fe1422  pop rax
000078d941fe1423  add rsp, 0x08
000078d941fe1427  jmp 0x000078D941FDC7B4
000078d941fe142c  sub rsp, 0x08
000078d941fe1430  push rax
000078d941fe1431  push rcx
000078d941fe1432  push rdx
000078d941fe1433  push rdi
000078d941fe1434  push rsi
000078d941fe1435  push r8
000078d941fe1437  push r9
000078d941fe1439  push r10
000078d941fe143b  push r11
000078d941fe143d  sub rsp, 0xF0
000078d941fe1444  vmovaps [rsp], xmm0
000078d941fe1449  vmovaps [rsp+0x10], xmm1
000078d941fe144f  vmovaps [rsp+0x20], xmm2
000078d941fe1455  vmovaps [rsp+0x30], xmm3
000078d941fe145b  vmovaps [rsp+0x40], xmm4
000078d941fe1461  vmovaps [rsp+0x50], xmm5
000078d941fe1467  vmovaps [rsp+0x60], xmm6
000078d941fe146d  vmovaps [rsp+0x70], xmm7
000078d941fe1473  vmovaps [rsp+0x80], xmm8
000078d941fe147c  vmovaps [rsp+0x90], xmm10
000078d941fe1485  vmovaps [rsp+0xA0], xmm11
000078d941fe148e  vmovaps [rsp+0xB0], xmm12
000078d941fe1497  vmovaps [rsp+0xC0], xmm13
000078d941fe14a0  vmovaps [rsp+0xD0], xmm14
000078d941fe14a9  vmovaps [rsp+0xE0], xmm15
000078d941fe14b2  sub rsp, 0x30
000078d941fe14b6  movaps [rsp], xmm9
000078d941fe14bb  movaps [rsp+0x10], xmm13
000078d941fe14c1  movaps [rsp+0x20], xmm15
000078d941fe14c7  lea rdi, [rsp]
000078d941fe14cb  mov esi, 0x00
000078d941fe14d0  mov rax, 0x59BFBFBAA530
000078d941fe14da  call rax
000078d941fe14dc  movaps xmm9, [rsp]
000078d941fe14e1  add rsp, 0x30
000078d941fe14e5  vmovaps xmm0, [rsp]
000078d941fe14ea  vmovaps xmm1, [rsp+0x10]
000078d941fe14f0  vmovaps xmm2, [rsp+0x20]
000078d941fe14f6  vmovaps xmm3, [rsp+0x30]
000078d941fe14fc  vmovaps xmm4, [rsp+0x40]
000078d941fe1502  vmovaps xmm5, [rsp+0x50]
000078d941fe1508  vmovaps xmm6, [rsp+0x60]
000078d941fe150e  vmovaps xmm7, [rsp+0x70]
000078d941fe1514  vmovaps xmm8, [rsp+0x80]
000078d941fe151d  vmovaps xmm10, [rsp+0x90]
000078d941fe1526  vmovaps xmm11, [rsp+0xA0]
000078d941fe152f  vmovaps xmm12, [rsp+0xB0]
000078d941fe1538  vmovaps xmm13, [rsp+0xC0]
000078d941fe1541  vmovaps xmm14, [rsp+0xD0]
000078d941fe154a  vmovaps xmm15, [rsp+0xE0]
000078d941fe1553  add rsp, 0xF0
000078d941fe155a  pop r11
000078d941fe155c  pop r10
000078d941fe155e  pop r9
000078d941fe1560  pop r8
000078d941fe1562  pop rsi
000078d941fe1563  pop rdi
000078d941fe1564  pop rdx
000078d941fe1565  pop rcx
000078d941fe1566  pop rax
000078d941fe1567  add rsp, 0x08
000078d941fe156b  jmp 0x000078D941FDC7E2
000078d941fe1570  sub rsp, 0x08
000078d941fe1574  push rax
000078d941fe1575  push rcx
000078d941fe1576  push rdx
000078d941fe1577  push rdi
000078d941fe1578  push rsi
000078d941fe1579  push r8
000078d941fe157b  push r9
000078d941fe157d  push r10
000078d941fe157f  push r11
000078d941fe1581  sub rsp, 0xF0
000078d941fe1588  vmovaps [rsp], xmm0
000078d941fe158d  vmovaps [rsp+0x10], xmm1
000078d941fe1593  vmovaps [rsp+0x20], xmm2
000078d941fe1599  vmovaps [rsp+0x30], xmm3
000078d941fe159f  vmovaps [rsp+0x40], xmm4
000078d941fe15a5  vmovaps [rsp+0x50], xmm5
000078d941fe15ab  vmovaps [rsp+0x60], xmm6
000078d941fe15b1  vmovaps [rsp+0x70], xmm7
000078d941fe15b7  vmovaps [rsp+0x80], xmm8
000078d941fe15c0  vmovaps [rsp+0x90], xmm9
000078d941fe15c9  vmovaps [rsp+0xA0], xmm10
000078d941fe15d2  vmovaps [rsp+0xB0], xmm11
000078d941fe15db  vmovaps [rsp+0xC0], xmm12
000078d941fe15e4  vmovaps [rsp+0xD0], xmm13
000078d941fe15ed  vmovaps [rsp+0xE0], xmm14
000078d941fe15f6  sub rsp, 0x30
000078d941fe15fa  movaps [rsp], xmm15
000078d941fe15ff  movaps [rsp+0x10], xmm11
000078d941fe1605  movaps [rsp+0x20], xmm12
000078d941fe160b  lea rdi, [rsp]
000078d941fe160f  mov esi, 0x00
000078d941fe1614  mov rax, 0x59BFBFBAA530
000078d941fe161e  call rax
000078d941fe1620  movaps xmm15, [rsp]
000078d941fe1625  add rsp, 0x30
000078d941fe1629  vmovaps xmm0, [rsp]
000078d941fe162e  vmovaps xmm1, [rsp+0x10]
000078d941fe1634  vmovaps xmm2, [rsp+0x20]
000078d941fe163a  vmovaps xmm3, [rsp+0x30]
000078d941fe1640  vmovaps xmm4, [rsp+0x40]
000078d941fe1646  vmovaps xmm5, [rsp+0x50]
000078d941fe164c  vmovaps xmm6, [rsp+0x60]
000078d941fe1652  vmovaps xmm7, [rsp+0x70]
000078d941fe1658  vmovaps xmm8, [rsp+0x80]
000078d941fe1661  vmovaps xmm9, [rsp+0x90]
000078d941fe166a  vmovaps xmm10, [rsp+0xA0]
000078d941fe1673  vmovaps xmm11, [rsp+0xB0]
000078d941fe167c  vmovaps xmm12, [rsp+0xC0]
000078d941fe1685  vmovaps xmm13, [rsp+0xD0]
000078d941fe168e  vmovaps xmm14, [rsp+0xE0]
000078d941fe1697  add rsp, 0xF0
000078d941fe169e  pop r11
000078d941fe16a0  pop r10
000078d941fe16a2  pop r9
000078d941fe16a4  pop r8
000078d941fe16a6  pop rsi
000078d941fe16a7  pop rdi
000078d941fe16a8  pop rdx
000078d941fe16a9  pop rcx
000078d941fe16aa  pop rax
000078d941fe16ab  add rsp, 0x08
000078d941fe16af  jmp 0x000078D941FDC7FD
000078d941fe16b4  sub rsp, 0x08
000078d941fe16b8  push rax
000078d941fe16b9  push rcx
000078d941fe16ba  push rdx
000078d941fe16bb  push rdi
000078d941fe16bc  push rsi
000078d941fe16bd  push r8
000078d941fe16bf  push r9
000078d941fe16c1  push r10
000078d941fe16c3  push r11
000078d941fe16c5  sub rsp, 0xF0
000078d941fe16cc  vmovaps [rsp], xmm0
000078d941fe16d1  vmovaps [rsp+0x10], xmm1
000078d941fe16d7  vmovaps [rsp+0x20], xmm2
000078d941fe16dd  vmovaps [rsp+0x30], xmm3
000078d941fe16e3  vmovaps [rsp+0x40], xmm4
000078d941fe16e9  vmovaps [rsp+0x50], xmm5
000078d941fe16ef  vmovaps [rsp+0x60], xmm6
000078d941fe16f5  vmovaps [rsp+0x70], xmm7
000078d941fe16fb  vmovaps [rsp+0x80], xmm8
000078d941fe1704  vmovaps [rsp+0x90], xmm9
000078d941fe170d  vmovaps [rsp+0xA0], xmm10
000078d941fe1716  vmovaps [rsp+0xB0], xmm11
000078d941fe171f  vmovaps [rsp+0xC0], xmm12
000078d941fe1728  vmovaps [rsp+0xD0], xmm14
000078d941fe1731  vmovaps [rsp+0xE0], xmm15
000078d941fe173a  sub rsp, 0x30
000078d941fe173e  movaps [rsp], xmm13
000078d941fe1743  movaps [rsp+0x10], xmm10
000078d941fe1749  movaps [rsp+0x20], xmm14
000078d941fe174f  lea rdi, [rsp]
000078d941fe1753  mov esi, 0x00
000078d941fe1758  mov rax, 0x59BFBFBAA530
000078d941fe1762  call rax
000078d941fe1764  movaps xmm13, [rsp]
000078d941fe1769  add rsp, 0x30
000078d941fe176d  vmovaps xmm0, [rsp]
000078d941fe1772  vmovaps xmm1, [rsp+0x10]
000078d941fe1778  vmovaps xmm2, [rsp+0x20]
000078d941fe177e  vmovaps xmm3, [rsp+0x30]
000078d941fe1784  vmovaps xmm4, [rsp+0x40]
000078d941fe178a  vmovaps xmm5, [rsp+0x50]
000078d941fe1790  vmovaps xmm6, [rsp+0x60]
000078d941fe1796  vmovaps xmm7, [rsp+0x70]
000078d941fe179c  vmovaps xmm8, [rsp+0x80]
000078d941fe17a5  vmovaps xmm9, [rsp+0x90]
000078d941fe17ae  vmovaps xmm10, [rsp+0xA0]
000078d941fe17b7  vmovaps xmm11, [rsp+0xB0]
000078d941fe17c0  vmovaps xmm12, [rsp+0xC0]
000078d941fe17c9  vmovaps xmm14, [rsp+0xD0]
000078d941fe17d2  vmovaps xmm15, [rsp+0xE0]
000078d941fe17db  add rsp, 0xF0
000078d941fe17e2  pop r11
000078d941fe17e4  pop r10
000078d941fe17e6  pop r9
000078d941fe17e8  pop r8
000078d941fe17ea  pop rsi
000078d941fe17eb  pop rdi
000078d941fe17ec  pop rdx
000078d941fe17ed  pop rcx
000078d941fe17ee  pop rax
000078d941fe17ef  add rsp, 0x08
000078d941fe17f3  jmp 0x000078D941FDC820
000078d941fe17f8  sub rsp, 0x08
000078d941fe17fc  push rax
000078d941fe17fd  push rcx
000078d941fe17fe  push rdx
000078d941fe17ff  push rdi
000078d941fe1800  push rsi
000078d941fe1801  push r8
000078d941fe1803  push r9
000078d941fe1805  push r10
000078d941fe1807  push r11
000078d941fe1809  sub rsp, 0xF0
000078d941fe1810  vmovaps [rsp], xmm0
000078d941fe1815  vmovaps [rsp+0x10], xmm1
000078d941fe181b  vmovaps [rsp+0x20], xmm2
000078d941fe1821  vmovaps [rsp+0x30], xmm3
000078d941fe1827  vmovaps [rsp+0x40], xmm4
000078d941fe182d  vmovaps [rsp+0x50], xmm5
000078d941fe1833  vmovaps [rsp+0x60], xmm6
000078d941fe1839  vmovaps [rsp+0x70], xmm7
000078d941fe183f  vmovaps [rsp+0x80], xmm8
000078d941fe1848  vmovaps [rsp+0x90], xmm9
000078d941fe1851  vmovaps [rsp+0xA0], xmm10
000078d941fe185a  vmovaps [rsp+0xB0], xmm11
000078d941fe1863  vmovaps [rsp+0xC0], xmm12
000078d941fe186c  vmovaps [rsp+0xD0], xmm13
000078d941fe1875  vmovaps [rsp+0xE0], xmm15
000078d941fe187e  sub rsp, 0x30
000078d941fe1882  movaps [rsp], xmm14
000078d941fe1887  movaps [rsp+0x10], xmm1
000078d941fe188c  movaps [rsp+0x20], xmm7
000078d941fe1891  lea rdi, [rsp]
000078d941fe1895  mov esi, 0x00
000078d941fe189a  mov rax, 0x59BFBFBAA530
000078d941fe18a4  call rax
000078d941fe18a6  movaps xmm14, [rsp]
000078d941fe18ab  add rsp, 0x30
000078d941fe18af  vmovaps xmm0, [rsp]
000078d941fe18b4  vmovaps xmm1, [rsp+0x10]
000078d941fe18ba  vmovaps xmm2, [rsp+0x20]
000078d941fe18c0  vmovaps xmm3, [rsp+0x30]
000078d941fe18c6  vmovaps xmm4, [rsp+0x40]
000078d941fe18cc  vmovaps xmm5, [rsp+0x50]
000078d941fe18d2  vmovaps xmm6, [rsp+0x60]
000078d941fe18d8  vmovaps xmm7, [rsp+0x70]
000078d941fe18de  vmovaps xmm8, [rsp+0x80]
000078d941fe18e7  vmovaps xmm9, [rsp+0x90]
000078d941fe18f0  vmovaps xmm10, [rsp+0xA0]
000078d941fe18f9  vmovaps xmm11, [rsp+0xB0]
000078d941fe1902  vmovaps xmm12, [rsp+0xC0]
000078d941fe190b  vmovaps xmm13, [rsp+0xD0]
000078d941fe1914  vmovaps xmm15, [rsp+0xE0]
000078d941fe191d  add rsp, 0xF0
000078d941fe1924  pop r11
000078d941fe1926  pop r10
000078d941fe1928  pop r9
000078d941fe192a  pop r8
000078d941fe192c  pop rsi
000078d941fe192d  pop rdi
000078d941fe192e  pop rdx
000078d941fe192f  pop rcx
000078d941fe1930  pop rax
000078d941fe1931  add rsp, 0x08
000078d941fe1935  jmp 0x000078D941FDC843
000078d941fe193a  sub rsp, 0x08
000078d941fe193e  push rax
000078d941fe193f  push rcx
000078d941fe1940  push rdx
000078d941fe1941  push rdi
000078d941fe1942  push rsi
000078d941fe1943  push r8
000078d941fe1945  push r9
000078d941fe1947  push r10
000078d941fe1949  push r11
000078d941fe194b  sub rsp, 0xF0
000078d941fe1952  vmovaps [rsp], xmm0
000078d941fe1957  vmovaps [rsp+0x10], xmm2
000078d941fe195d  vmovaps [rsp+0x20], xmm3
000078d941fe1963  vmovaps [rsp+0x30], xmm4
000078d941fe1969  vmovaps [rsp+0x40], xmm5
000078d941fe196f  vmovaps [rsp+0x50], xmm6
000078d941fe1975  vmovaps [rsp+0x60], xmm7
000078d941fe197b  vmovaps [rsp+0x70], xmm8
000078d941fe1981  vmovaps [rsp+0x80], xmm9
000078d941fe198a  vmovaps [rsp+0x90], xmm10
000078d941fe1993  vmovaps [rsp+0xA0], xmm11
000078d941fe199c  vmovaps [rsp+0xB0], xmm12
000078d941fe19a5  vmovaps [rsp+0xC0], xmm13
000078d941fe19ae  vmovaps [rsp+0xD0], xmm14
000078d941fe19b7  vmovaps [rsp+0xE0], xmm15
000078d941fe19c0  sub rsp, 0x30
000078d941fe19c4  movaps [rsp], xmm1
000078d941fe19c8  movaps [rsp+0x10], xmm8
000078d941fe19ce  movaps [rsp+0x20], xmm9
000078d941fe19d4  lea rdi, [rsp]
000078d941fe19d8  mov esi, 0x00
000078d941fe19dd  mov rax, 0x59BFBFBAA530
000078d941fe19e7  call rax
000078d941fe19e9  movaps xmm1, [rsp]
000078d941fe19ed  add rsp, 0x30
000078d941fe19f1  vmovaps xmm0, [rsp]
000078d941fe19f6  vmovaps xmm2, [rsp+0x10]
000078d941fe19fc  vmovaps xmm3, [rsp+0x20]
000078d941fe1a02  vmovaps xmm4, [rsp+0x30]
000078d941fe1a08  vmovaps xmm5, [rsp+0x40]
000078d941fe1a0e  vmovaps xmm6, [rsp+0x50]
000078d941fe1a14  vmovaps xmm7, [rsp+0x60]
000078d941fe1a1a  vmovaps xmm8, [rsp+0x70]
000078d941fe1a20  vmovaps xmm9, [rsp+0x80]
000078d941fe1a29  vmovaps xmm10, [rsp+0x90]
000078d941fe1a32  vmovaps xmm11, [rsp+0xA0]
000078d941fe1a3b  vmovaps xmm12, [rsp+0xB0]
000078d941fe1a44  vmovaps xmm13, [rsp+0xC0]
000078d941fe1a4d  vmovaps xmm14, [rsp+0xD0]
000078d941fe1a56  vmovaps xmm15, [rsp+0xE0]
000078d941fe1a5f  add rsp, 0xF0
000078d941fe1a66  pop r11
000078d941fe1a68  pop r10
000078d941fe1a6a  pop r9
000078d941fe1a6c  pop r8
000078d941fe1a6e  pop rsi
000078d941fe1a6f  pop rdi
000078d941fe1a70  pop rdx
000078d941fe1a71  pop rcx
000078d941fe1a72  pop rax
000078d941fe1a73  add rsp, 0x08
000078d941fe1a77  jmp 0x000078D941FDC865
000078d941fe1a7c  call 0x000078D941EE5940
000078d941fe1a81  jmp 0x000078D941FDC873
000078d941fe1a86  call 0x000078D941E0C380
000078d941fe1a8b  jmp 0x000078D941FDC87D
000078d941fe1a90  call 0x000078D941E0D600
000078d941fe1a95  jmp 0x000078D941FDC887
000078d941fe1a9a  call 0x000078D941DFF540
000078d941fe1a9f  jmp 0x000078D941FDC891
000078d941fe1aa4  int3
000078d941fe1aa5  nop [rax+rax*1], ax
000078d941fe1aae  nop
000078d941fe1ab0  mov rax, [r15+0xF8]
000078d941fe1ab7  lea r14, [rax+0x140]
000078d941fe1abe  mov r12, [r13+r14*1]
000078d941fe1ac3  mov [r15+0xE8], r12
000078d941fe1aca  lea r14, [rax+0x130]
000078d941fe1ad1  mov r12, [r13+r14*1]
000078d941fe1ad6  lea r14, [rax+0x138]
000078d941fe1add  mov r11, [r13+r14*1]
000078d941fe1ae2  movq xmm1, r12
000078d941fe1ae7  movq xmm15, r11
000078d941fe1aec  movq xmm1, xmm1
000078d941fe1af0  movq xmm1, xmm1
000078d941fe1af4  movaps [r15+0x1A0], xmm1
000078d941fe1afc  movq xmm15, xmm15
000078d941fe1b01  movq xmm15, xmm15
000078d941fe1b06  movaps [r15+0x190], xmm15
000078d941fe1b0e  lea r14, [rax+0x120]
000078d941fe1b15  mov r12, [r13+r14*1]
000078d941fe1b1a  lea r14, [rax+0x128]
000078d941fe1b21  mov r11, [r13+r14*1]
000078d941fe1b26  movq xmm1, r12
000078d941fe1b2b  movq xmm15, r11
000078d941fe1b30  movq xmm1, xmm1
000078d941fe1b34  movq xmm1, xmm1
000078d941fe1b38  movaps [r15+0x1C0], xmm1
000078d941fe1b40  movq xmm15, xmm15
000078d941fe1b45  movq xmm15, xmm15
000078d941fe1b4a  movaps [r15+0x1B0], xmm15
000078d941fe1b52  lea r14, [rax+0x110]
000078d941fe1b59  mov r12, [r13+r14*1]
000078d941fe1b5e  lea r14, [rax+0x118]
000078d941fe1b65  mov r11, [r13+r14*1]
000078d941fe1b6a  movq xmm1, r12
000078d941fe1b6f  movq xmm15, r11
000078d941fe1b74  movq xmm1, xmm1
000078d941fe1b78  movq xmm1, xmm1
000078d941fe1b7c  movaps [r15+0x1E0], xmm1
000078d941fe1b84  movq xmm15, xmm15
000078d941fe1b89  movq xmm15, xmm15
000078d941fe1b8e  movaps [r15+0x1D0], xmm15
000078d941fe1b96  lea r14, [rax+0x100]
000078d941fe1b9d  mov r12, [r13+r14*1]
000078d941fe1ba2  lea r14, [rax+0x108]
000078d941fe1ba9  mov r11, [r13+r14*1]
000078d941fe1bae  movq xmm1, r12
000078d941fe1bb3  movq xmm15, r11
000078d941fe1bb8  movq xmm1, xmm1
000078d941fe1bbc  movq xmm1, xmm1
000078d941fe1bc0  movaps [r15+0x200], xmm1
000078d941fe1bc8  movq xmm15, xmm15
000078d941fe1bcd  movq xmm15, xmm15
000078d941fe1bd2  movaps [r15+0x1F0], xmm15
000078d941fe1bda  mov qword ptr [r15+0x40], 0x430000
000078d941fe1be2  mov r14d, 0x430510
000078d941fe1be8  mov r12, [r13+r14*1]
000078d941fe1bed  movq xmm1, r12
000078d941fe1bf2  lea r14, [rax+0x150]
000078d941fe1bf9  mov [r15+0xF8], r14
000078d941fe1c00  mov rax, [r15+0x50]
000078d941fe1c04  movups xmm15, [r13+rax*1]
000078d941fe1c0a  movaps [r15+0x120], xmm15
000078d941fe1c12  mov qword ptr [r15+0x48], 0x10
000078d941fe1c1a  xor eax, eax
000078d941fe1c1c  mov r14d, 0x10
000078d941fe1c22  mov r12d, 0x200
000078d941fe1c28  cmp r14, r12
000078d941fe1c2b  cmc
000078d941fe1c2c  lahf
000078d941fe1c2d  seto al
000078d941fe1c30  mov [r15+0x108], eax
000078d941fe1c37  pextrq rax, xmm15, 0x01
000078d941fe1c3e  movq xmm14, rax
000078d941fe1c43  movaps [r15+0x130], xmm14
000078d941fe1c4b  movq rax, xmm1
000078d941fe1c50  movq r14, xmm15
000078d941fe1c55  vmovq xmm1, rax
000078d941fe1c5a  vmovq xmm15, r14
000078d941fe1c5f  movaps xmm13, xmm1
000078d941fe1c63  addsd xmm13, xmm15
000078d941fe1c68  ucomisd xmm13, xmm13
000078d941fe1c6d  jp 0x000078D941FE1D86
000078d941fe1c73  movq xmm13, xmm13
000078d941fe1c78  movq rax, xmm13
000078d941fe1c7d  movq r14, xmm14
000078d941fe1c82  vmovq xmm1, rax
000078d941fe1c87  vmovq xmm15, r14
000078d941fe1c8c  movaps xmm14, xmm1
000078d941fe1c90  addsd xmm14, xmm15
000078d941fe1c95  ucomisd xmm14, xmm14
000078d941fe1c9a  jp 0x000078D941FE1DCE
000078d941fe1ca0  movq xmm14, xmm14
000078d941fe1ca5  movaps [r15+0x110], xmm14
000078d941fe1cad  mov eax, [r15+0x108]
000078d941fe1cb4  sahf
000078d941fe1cb5  jnz 0x000078D941FE1CE7
000078d941fe1cb7  cmp dword ptr [r15+0x318], 0x00
000078d941fe1cbf  jz 0x000078D941FE1FE0
000078d941fe1cc5  nop [rax+rax*1], ax
000078d941fe1cce  nop [rax+rax*1], eax
000078d941fe1cd6  mov eax, 0x410490
000078d941fe1cdb  mov [r15+0x100], rax
000078d941fe1ce2  jmp 0x000078D941DFE110
000078d941fe1ce7  cmp dword ptr [r15+0x318], 0x00
000078d941fe1cef  jz 0x000078D941FE1E20
000078d941fe1cf5  nop [rax+rax*1], ax
000078d941fe1cfe  nop [rax+rax*1], eax
000078d941fe1d06  mov eax, 0x410474
000078d941fe1d0b  mov [r15+0x100], rax
000078d941fe1d12  jmp 0x000078D941DFE110
000078d941fe1d17  int3
000078d941fe1d18  call 0x000078D941EE27E0
000078d941fe1d1d  jmp 0x000078D941FE1AC3
000078d941fe1d22  call 0x000078D941EE27E0
000078d941fe1d27  jmp 0x000078D941FE1AD6
000078d941fe1d2c  call 0x000078D941EE1570
000078d941fe1d31  jmp 0x000078D941FE1AE2
000078d941fe1d36  call 0x000078D941EE27E0
000078d941fe1d3b  jmp 0x000078D941FE1B1A
000078d941fe1d40  call 0x000078D941EE1570
000078d941fe1d45  jmp 0x000078D941FE1B26
000078d941fe1d4a  call 0x000078D941EE27E0
000078d941fe1d4f  jmp 0x000078D941FE1B5E
000078d941fe1d54  call 0x000078D941EE1570
000078d941fe1d59  jmp 0x000078D941FE1B6A
000078d941fe1d5e  call 0x000078D941EE27E0
000078d941fe1d63  jmp 0x000078D941FE1BA2
000078d941fe1d68  call 0x000078D941EE1570
000078d941fe1d6d  jmp 0x000078D941FE1BAE
000078d941fe1d72  call 0x000078D941EE27E0
000078d941fe1d77  jmp 0x000078D941FE1BED
000078d941fe1d7c  call 0x000078D941E0E760
000078d941fe1d81  jmp 0x000078D941FE1C0A
000078d941fe1d86  ucomisd xmm1, xmm15
000078d941fe1d8b  jp 0x000078D941FE1D9A
000078d941fe1d8d  movaps xmm13, [0x000078D941BFE060]
000078d941fe1d95  jmp 0x000078D941FE1C73
000078d941fe1d9a  vxorps xmm0, xmm1, xmm15
000078d941fe1d9f  pextrw eax, xmm0, 0x03
000078d941fe1da4  and eax, 0x7FF8
000078d941fe1da9  cmp eax, 0x08
000078d941fe1dac  jnz 0x000078D941FE1C73
000078d941fe1db2  movq rax, xmm15
000078d941fe1db7  shl rax, 0x0D
000078d941fe1dbb  jbe 0x000078D941FE1C73
000078d941fe1dc1  vorps xmm13, xmm15, [0x000078D941BFE070]
000078d941fe1dc9  jmp 0x000078D941FE1C73
000078d941fe1dce  ucomisd xmm1, xmm15
000078d941fe1dd3  jp 0x000078D941FE1DE2
000078d941fe1dd5  movaps xmm14, [0x000078D941BFE060]
000078d941fe1ddd  jmp 0x000078D941FE1CA0
000078d941fe1de2  vxorps xmm0, xmm1, xmm15
000078d941fe1de7  pextrw eax, xmm0, 0x03
000078d941fe1dec  and eax, 0x7FF8
000078d941fe1df1  cmp eax, 0x08
000078d941fe1df4  jnz 0x000078D941FE1CA0
000078d941fe1dfa  movq rax, xmm15
000078d941fe1dff  shl rax, 0x0D
000078d941fe1e03  jbe 0x000078D941FE1CA0
000078d941fe1e09  vorps xmm14, xmm15, [0x000078D941BFE070]
000078d941fe1e11  jmp 0x000078D941FE1CA0
000078d941fe1e16  int3
000078d941fe1e17  nop [rax+rax*1], ax
000078d941fe1e20  mov rax, [r15+0x48]
000078d941fe1e24  mov r14, [r15+0x50]
000078d941fe1e28  lea r12, [r14+rax*1]
000078d941fe1e2c  movups xmm1, [r13+r12*1]
000078d941fe1e32  movaps [r15+0x120], xmm1
000078d941fe1e3a  lea r14, [rax+0x10]
000078d941fe1e3e  mov [r15+0x48], r14
000078d941fe1e42  xor eax, eax
000078d941fe1e44  mov r12d, 0x200
000078d941fe1e4a  cmp r14, r12
000078d941fe1e4d  cmc
000078d941fe1e4e  lahf
000078d941fe1e4f  seto al
000078d941fe1e52  mov [r15+0x108], eax
000078d941fe1e59  pextrq rax, xmm1, 0x01
000078d941fe1e60  movq xmm15, rax
000078d941fe1e65  movaps [r15+0x130], xmm15
000078d941fe1e6d  movaps xmm14, [r15+0x110]
000078d941fe1e75  movq rax, xmm14
000078d941fe1e7a  movq r14, xmm1
000078d941fe1e7f  vmovq xmm1, rax
000078d941fe1e84  vmovq xmm14, r14
000078d941fe1e89  movaps xmm13, xmm1
000078d941fe1e8d  addsd xmm13, xmm14
000078d941fe1e92  ucomisd xmm13, xmm13
000078d941fe1e97  jp 0x000078D941FE1F4C
000078d941fe1e9d  movq xmm13, xmm13
000078d941fe1ea2  movq rax, xmm13
000078d941fe1ea7  movq r14, xmm15
000078d941fe1eac  vmovq xmm1, rax
000078d941fe1eb1  vmovq xmm15, r14
000078d941fe1eb6  movaps xmm14, xmm1
000078d941fe1eba  addsd xmm14, xmm15
000078d941fe1ebf  ucomisd xmm14, xmm14
000078d941fe1ec4  jp 0x000078D941FE1F94
000078d941fe1eca  movq xmm14, xmm14
000078d941fe1ecf  movaps [r15+0x110], xmm14
000078d941fe1ed7  mov eax, [r15+0x108]
000078d941fe1ede  sahf
000078d941fe1edf  jnz 0x000078D941FE1F11
000078d941fe1ee1  cmp dword ptr [r15+0x318], 0x00
000078d941fe1ee9  jz 0x000078D941FE1FE0
000078d941fe1eef  nop [rax+rax*1], ax
000078d941fe1ef8  nop [rax+rax*1], eax
000078d941fe1f00  mov eax, 0x410490
000078d941fe1f05  mov [r15+0x100], rax
000078d941fe1f0c  jmp 0x000078D941DFE110
000078d941fe1f11  cmp dword ptr [r15+0x318], 0x00
000078d941fe1f19  jz 0x000078D941FE1E20
000078d941fe1f1f  nop [rax+rax*1], ax
000078d941fe1f28  nop [rax+rax*1], eax
000078d941fe1f30  mov eax, 0x410474
000078d941fe1f35  mov [r15+0x100], rax
000078d941fe1f3c  jmp 0x000078D941DFE110
000078d941fe1f41  int3
000078d941fe1f42  call 0x000078D941EB52F0
000078d941fe1f47  jmp 0x000078D941FE1E32
000078d941fe1f4c  ucomisd xmm1, xmm14
000078d941fe1f51  jp 0x000078D941FE1F60
000078d941fe1f53  movaps xmm13, [0x000078D941BFE060]
000078d941fe1f5b  jmp 0x000078D941FE1E9D
000078d941fe1f60  vxorps xmm0, xmm1, xmm14
000078d941fe1f65  pextrw eax, xmm0, 0x03
000078d941fe1f6a  and eax, 0x7FF8
000078d941fe1f6f  cmp eax, 0x08
000078d941fe1f72  jnz 0x000078D941FE1E9D
000078d941fe1f78  movq rax, xmm14
000078d941fe1f7d  shl rax, 0x0D
000078d941fe1f81  jbe 0x000078D941FE1E9D
000078d941fe1f87  vorps xmm13, xmm14, [0x000078D941BFE070]
000078d941fe1f8f  jmp 0x000078D941FE1E9D
000078d941fe1f94  ucomisd xmm1, xmm15
000078d941fe1f99  jp 0x000078D941FE1FA8
000078d941fe1f9b  movaps xmm14, [0x000078D941BFE060]
000078d941fe1fa3  jmp 0x000078D941FE1ECA
000078d941fe1fa8  vxorps xmm0, xmm1, xmm15
000078d941fe1fad  pextrw eax, xmm0, 0x03
000078d941fe1fb2  and eax, 0x7FF8
000078d941fe1fb7  cmp eax, 0x08
000078d941fe1fba  jnz 0x000078D941FE1ECA
000078d941fe1fc0  movq rax, xmm15
000078d941fe1fc5  shl rax, 0x0D
000078d941fe1fc9  jbe 0x000078D941FE1ECA
000078d941fe1fcf  vorps xmm14, xmm15, [0x000078D941BFE070]
000078d941fe1fd7  jmp 0x000078D941FE1ECA
000078d941fe1fdc  int3
000078d941fe1fdd  nop [rax], eax
000078d941fe1fe0  mov rax, [r15+0x40]
000078d941fe1fe4  lea r14, [rax+0x510]
000078d941fe1feb  movaps xmm1, [r15+0x110]
000078d941fe1ff3  movq rax, xmm1
000078d941fe1ff8  mov [r13+r14*1], rax
000078d941fe1ffd  mov rax, [r15+0xF0]
000078d941fe2004  mov [r15+0x100], rax
000078d941fe200b  jmp 0x000078D941FCE5C0
000078d941fe2010  int3
000078d941fe2011  call 0x000078D941ED5EB0
000078d941fe2016  jmp 0x000078D941FE1FFD
000078d941fe201b  int3
000078d941fe201c  nop [rax], eax
000078d941fe2020  mov qword ptr [r15+0x100], 0x04
000078d941fe202b  mov esi, 0x00
000078d941fe2030  mov edx, 0x09
000078d941fe2035  mov rdi, 0x7FFDC43E3A60
000078d941fe203f  mov rax, 0x59BFBFA3D970
000078d941fe2049  call rax
000078d941fe204b  cmp dword ptr [r15+0x318], 0x00
000078d941fe2053  jnz 0x000078D941DFE110
000078d941fe2059  jmp 0x000078D941DFE0A0
000078d941fe205e  int3
000078d941fe205f  int3
