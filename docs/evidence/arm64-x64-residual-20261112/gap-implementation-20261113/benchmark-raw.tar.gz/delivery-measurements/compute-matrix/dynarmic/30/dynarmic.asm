00007f582cdce69b  nop [rax+rax*1], eax
00007f582cdce6a0  vmovaps xmm1, [0x00007F582C9FE010]
00007f582cdce6a8  movq xmm1, xmm1
00007f582cdce6ac  movaps [r15+0x110], xmm1
00007f582cdce6b4  vmovaps xmm1, [0x00007F582C9FE020]
00007f582cdce6bc  movq xmm1, xmm1
00007f582cdce6c0  movaps [r15+0x120], xmm1
00007f582cdce6c8  mov eax, 0x4204C0
00007f582cdce6cd  mov r14, [r13+rax*1]
00007f582cdce6d2  movq xmm1, r14
00007f582cdce6d7  movaps [r15+0x130], xmm1
00007f582cdce6df  vmovaps xmm1, [0x00007F582C9FE030]
00007f582cdce6e7  vpbroadcastq xmm1, xmm1
00007f582cdce6ec  movaps [r15+0x140], xmm1
00007f582cdce6f4  mov qword ptr [r15+0x40], 0x02
00007f582cdce6fc  vmovaps xmm15, [0x00007F582C9FE040]
00007f582cdce704  movq xmm15, xmm15
00007f582cdce709  movaps [r15+0x150], xmm15
00007f582cdce711  mov qword ptr [r15+0x58], 0x420000
00007f582cdce719  vmovaps xmm15, [0x00007F582C9FE050]
00007f582cdce721  vpbroadcastq xmm15, xmm15
00007f582cdce726  movaps [r15+0x160], xmm15
00007f582cdce72e  mov rax, [r15+0x40]
00007f582cdce732  vmovq xmm14, rax
00007f582cdce737  vpbroadcastq xmm14, xmm14
00007f582cdce73c  movaps [r15+0x170], xmm14
00007f582cdce744  mov eax, 0x4204D0
00007f582cdce749  movups xmm13, [r13+rax*1]
00007f582cdce74f  mov qword ptr [r15+0x40], 0x430518
00007f582cdce757  mov qword ptr [r15+0x50], 0x430720
00007f582cdce75f  vpmovqd xmm12, xmm13
00007f582cdce765  pxor xmm11, xmm11
00007f582cdce76a  punpcklqdq xmm12, xmm11
00007f582cdce76f  movaps [r15+0x210], xmm12
00007f582cdce777  movq xmm12, qword ptr [r15+0x120]
00007f582cdce780  movq xmm11, qword ptr [r15+0x130]
00007f582cdce789  psubd xmm12, xmm11
00007f582cdce78e  movq xmm12, xmm12
00007f582cdce793  paddq xmm13, xmm14
00007f582cdce798  movaps [r15+0x180], xmm13
00007f582cdce7a0  movq xmm14, qword ptr [r15+0x150]
00007f582cdce7a9  paddd xmm11, xmm14
00007f582cdce7ae  movq xmm11, xmm11
00007f582cdce7b3  movq xmm11, xmm11
00007f582cdce7b8  movaps [r15+0x130], xmm11
00007f582cdce7c0  pmovzxdq xmm12, xmm12
00007f582cdce7c6  psllq xmm12, 0x00
00007f582cdce7cc  movq xmm14, qword ptr [r15+0x210]
00007f582cdce7d5  movq xmm13, qword ptr [r15+0x110]
00007f582cdce7de  paddd xmm14, xmm13
00007f582cdce7e3  movq xmm14, xmm14
00007f582cdce7e8  vcvtuqq2pd xmm12, xmm12
00007f582cdce7ee  pmovzxdq xmm14, xmm14
00007f582cdce7f4  psllq xmm14, 0x00
00007f582cdce7fa  vcvtuqq2pd xmm14, xmm14
00007f582cdce800  movaps xmm13, xmm12
00007f582cdce804  mulpd xmm13, xmm1
00007f582cdce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007f582cdce80f  ptest xmm11, xmm11
00007f582cdce815  jnz 0x00007F582CDCE8FF
00007f582cdce81b  movaps [r15+0x220], xmm13
00007f582cdce823  mov eax, 0x430720
00007f582cdce828  movups [r13+rax*1], xmm13
00007f582cdce82e  movaps xmm1, xmm14
00007f582cdce832  mulpd xmm1, xmm15
00007f582cdce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007f582cdce83c  ptest xmm13, xmm13
00007f582cdce842  jnz 0x00007F582CDCEA4C
00007f582cdce848  movaps [r15+0x210], xmm1
00007f582cdce850  mov eax, 0x430518
00007f582cdce855  movups [r13+rax*1], xmm1
00007f582cdce85b  mov qword ptr [r15+0x48], 0x10
00007f582cdce863  xor eax, eax
00007f582cdce865  mov r14d, 0x10
00007f582cdce86b  mov r12d, 0x200
00007f582cdce871  cmp r14, r12
00007f582cdce874  cmc
00007f582cdce875  lahf
00007f582cdce876  seto al
00007f582cdce879  mov [r15+0x108], eax
00007f582cdce880  mov eax, [r15+0x108]
00007f582cdce887  sahf
00007f582cdce888  jnz 0x00007F582CDCE8BA
00007f582cdce88a  cmp dword ptr [r15+0x318], 0x00
00007f582cdce892  jz 0x00007F582CDCEFF0
00007f582cdce898  nop [rax+rax*1], ax
00007f582cdce8a1  nop [rax+rax*1], eax
00007f582cdce8a9  mov eax, 0x4101EC
00007f582cdce8ae  mov [r15+0x100], rax
00007f582cdce8b5  jmp 0x00007F582CBFE110
00007f582cdce8ba  cmp dword ptr [r15+0x318], 0x00
00007f582cdce8c2  jz 0x00007F582CDCEBA0
00007f582cdce8c8  nop [rax+rax*1], ax
00007f582cdce8d1  nop [rax+rax*1], eax
00007f582cdce8d9  mov eax, 0x4101AC
00007f582cdce8de  mov [r15+0x100], rax
00007f582cdce8e5  jmp 0x00007F582CBFE110
00007f582cdce8ea  int3
00007f582cdce8eb  call 0x00007F582CC0DC20
00007f582cdce8f0  jmp 0x00007F582CDCE6D2
00007f582cdce8f5  call 0x00007F582CC0C260
00007f582cdce8fa  jmp 0x00007F582CDCE74F
00007f582cdce8ff  sub rsp, 0x08
00007f582cdce903  push rax
00007f582cdce904  push rcx
00007f582cdce905  push rdx
00007f582cdce906  push rdi
00007f582cdce907  push rsi
00007f582cdce908  push r8
00007f582cdce90a  push r9
00007f582cdce90c  push r10
00007f582cdce90e  push r11
00007f582cdce910  sub rsp, 0xF0
00007f582cdce917  vmovaps [rsp], xmm0
00007f582cdce91c  vmovaps [rsp+0x10], xmm1
00007f582cdce922  vmovaps [rsp+0x20], xmm2
00007f582cdce928  vmovaps [rsp+0x30], xmm3
00007f582cdce92e  vmovaps [rsp+0x40], xmm4
00007f582cdce934  vmovaps [rsp+0x50], xmm5
00007f582cdce93a  vmovaps [rsp+0x60], xmm6
00007f582cdce940  vmovaps [rsp+0x70], xmm7
00007f582cdce946  vmovaps [rsp+0x80], xmm8
00007f582cdce94f  vmovaps [rsp+0x90], xmm9
00007f582cdce958  vmovaps [rsp+0xA0], xmm10
00007f582cdce961  vmovaps [rsp+0xB0], xmm11
00007f582cdce96a  vmovaps [rsp+0xC0], xmm12
00007f582cdce973  vmovaps [rsp+0xD0], xmm14
00007f582cdce97c  vmovaps [rsp+0xE0], xmm15
00007f582cdce985  sub rsp, 0x30
00007f582cdce989  movaps [rsp], xmm13
00007f582cdce98e  movaps [rsp+0x10], xmm12
00007f582cdce994  movaps [rsp+0x20], xmm1
00007f582cdce999  lea rdi, [rsp]
00007f582cdce99d  mov esi, 0x00
00007f582cdce9a2  mov rax, 0x653B0D9BF530
00007f582cdce9ac  call rax
00007f582cdce9ae  movaps xmm13, [rsp]
00007f582cdce9b3  add rsp, 0x30
00007f582cdce9b7  vmovaps xmm0, [rsp]
00007f582cdce9bc  vmovaps xmm1, [rsp+0x10]
00007f582cdce9c2  vmovaps xmm2, [rsp+0x20]
00007f582cdce9c8  vmovaps xmm3, [rsp+0x30]
00007f582cdce9ce  vmovaps xmm4, [rsp+0x40]
00007f582cdce9d4  vmovaps xmm5, [rsp+0x50]
00007f582cdce9da  vmovaps xmm6, [rsp+0x60]
00007f582cdce9e0  vmovaps xmm7, [rsp+0x70]
00007f582cdce9e6  vmovaps xmm8, [rsp+0x80]
00007f582cdce9ef  vmovaps xmm9, [rsp+0x90]
00007f582cdce9f8  vmovaps xmm10, [rsp+0xA0]
00007f582cdcea01  vmovaps xmm11, [rsp+0xB0]
00007f582cdcea0a  vmovaps xmm12, [rsp+0xC0]
00007f582cdcea13  vmovaps xmm14, [rsp+0xD0]
00007f582cdcea1c  vmovaps xmm15, [rsp+0xE0]
00007f582cdcea25  add rsp, 0xF0
00007f582cdcea2c  pop r11
00007f582cdcea2e  pop r10
00007f582cdcea30  pop r9
00007f582cdcea32  pop r8
00007f582cdcea34  pop rsi
00007f582cdcea35  pop rdi
00007f582cdcea36  pop rdx
00007f582cdcea37  pop rcx
00007f582cdcea38  pop rax
00007f582cdcea39  add rsp, 0x08
00007f582cdcea3d  jmp 0x00007F582CDCE81B
00007f582cdcea42  call 0x00007F582CC0C380
00007f582cdcea47  jmp 0x00007F582CDCE82E
00007f582cdcea4c  sub rsp, 0x08
00007f582cdcea50  push rax
00007f582cdcea51  push rcx
00007f582cdcea52  push rdx
00007f582cdcea53  push rdi
00007f582cdcea54  push rsi
00007f582cdcea55  push r8
00007f582cdcea57  push r9
00007f582cdcea59  push r10
00007f582cdcea5b  push r11
00007f582cdcea5d  sub rsp, 0xF0
00007f582cdcea64  vmovaps [rsp], xmm0
00007f582cdcea69  vmovaps [rsp+0x10], xmm2
00007f582cdcea6f  vmovaps [rsp+0x20], xmm3
00007f582cdcea75  vmovaps [rsp+0x30], xmm4
00007f582cdcea7b  vmovaps [rsp+0x40], xmm5
00007f582cdcea81  vmovaps [rsp+0x50], xmm6
00007f582cdcea87  vmovaps [rsp+0x60], xmm7
00007f582cdcea8d  vmovaps [rsp+0x70], xmm8
00007f582cdcea93  vmovaps [rsp+0x80], xmm9
00007f582cdcea9c  vmovaps [rsp+0x90], xmm10
00007f582cdceaa5  vmovaps [rsp+0xA0], xmm11
00007f582cdceaae  vmovaps [rsp+0xB0], xmm12
00007f582cdceab7  vmovaps [rsp+0xC0], xmm13
00007f582cdceac0  vmovaps [rsp+0xD0], xmm14
00007f582cdceac9  vmovaps [rsp+0xE0], xmm15
00007f582cdcead2  sub rsp, 0x30
00007f582cdcead6  movaps [rsp], xmm1
00007f582cdceada  movaps [rsp+0x10], xmm14
00007f582cdceae0  movaps [rsp+0x20], xmm15
00007f582cdceae6  lea rdi, [rsp]
00007f582cdceaea  mov esi, 0x00
00007f582cdceaef  mov rax, 0x653B0D9BF530
00007f582cdceaf9  call rax
00007f582cdceafb  movaps xmm1, [rsp]
00007f582cdceaff  add rsp, 0x30
00007f582cdceb03  vmovaps xmm0, [rsp]
00007f582cdceb08  vmovaps xmm2, [rsp+0x10]
00007f582cdceb0e  vmovaps xmm3, [rsp+0x20]
00007f582cdceb14  vmovaps xmm4, [rsp+0x30]
00007f582cdceb1a  vmovaps xmm5, [rsp+0x40]
00007f582cdceb20  vmovaps xmm6, [rsp+0x50]
00007f582cdceb26  vmovaps xmm7, [rsp+0x60]
00007f582cdceb2c  vmovaps xmm8, [rsp+0x70]
00007f582cdceb32  vmovaps xmm9, [rsp+0x80]
00007f582cdceb3b  vmovaps xmm10, [rsp+0x90]
00007f582cdceb44  vmovaps xmm11, [rsp+0xA0]
00007f582cdceb4d  vmovaps xmm12, [rsp+0xB0]
00007f582cdceb56  vmovaps xmm13, [rsp+0xC0]
00007f582cdceb5f  vmovaps xmm14, [rsp+0xD0]
00007f582cdceb68  vmovaps xmm15, [rsp+0xE0]
00007f582cdceb71  add rsp, 0xF0
00007f582cdceb78  pop r11
00007f582cdceb7a  pop r10
00007f582cdceb7c  pop r9
00007f582cdceb7e  pop r8
00007f582cdceb80  pop rsi
00007f582cdceb81  pop rdi
00007f582cdceb82  pop rdx
00007f582cdceb83  pop rcx
00007f582cdceb84  pop rax
00007f582cdceb85  add rsp, 0x08
00007f582cdceb89  jmp 0x00007F582CDCE848
00007f582cdceb8e  call 0x00007F582CBFF540
00007f582cdceb93  jmp 0x00007F582CDCE85B
00007f582cdceb98  int3
00007f582cdceb99  nop [rax], eax
00007f582cdceba0  movaps xmm1, [r15+0x180]
00007f582cdceba8  vpmovqd xmm15, xmm1
00007f582cdcebae  pxor xmm14, xmm14
00007f582cdcebb3  punpcklqdq xmm15, xmm14
00007f582cdcebb8  movaps [r15+0x210], xmm15
00007f582cdcebc0  movq xmm15, qword ptr [r15+0x120]
00007f582cdcebc9  movq xmm14, qword ptr [r15+0x130]
00007f582cdcebd2  psubd xmm15, xmm14
00007f582cdcebd7  movq xmm15, xmm15
00007f582cdcebdc  movaps xmm13, [r15+0x170]
00007f582cdcebe4  paddq xmm1, xmm13
00007f582cdcebe9  movaps [r15+0x180], xmm1
00007f582cdcebf1  movq xmm1, qword ptr [r15+0x150]
00007f582cdcebfa  paddd xmm14, xmm1
00007f582cdcebff  movq xmm14, xmm14
00007f582cdcec04  movq xmm14, xmm14
00007f582cdcec09  movaps [r15+0x130], xmm14
00007f582cdcec11  pmovzxdq xmm15, xmm15
00007f582cdcec17  psllq xmm15, 0x00
00007f582cdcec1d  movq xmm1, qword ptr [r15+0x210]
00007f582cdcec26  movq xmm14, qword ptr [r15+0x110]
00007f582cdcec2f  paddd xmm1, xmm14
00007f582cdcec34  movq xmm1, xmm1
00007f582cdcec38  vcvtuqq2pd xmm15, xmm15
00007f582cdcec3e  pmovzxdq xmm1, xmm1
00007f582cdcec43  psllq xmm1, 0x00
00007f582cdcec48  vcvtuqq2pd xmm1, xmm1
00007f582cdcec4e  movaps xmm14, [r15+0x140]
00007f582cdcec56  movaps xmm13, xmm15
00007f582cdcec5a  mulpd xmm13, xmm14
00007f582cdcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007f582cdcec65  ptest xmm12, xmm12
00007f582cdcec6b  jnz 0x00007F582CDCED4E
00007f582cdcec71  movaps [r15+0x220], xmm13
00007f582cdcec79  mov rax, [r15+0x48]
00007f582cdcec7d  mov r14, [r15+0x50]
00007f582cdcec81  lea r12, [r14+rax*1]
00007f582cdcec85  movups [r13+r12*1], xmm13
00007f582cdcec8b  movaps xmm15, [r15+0x160]
00007f582cdcec93  movaps xmm14, xmm1
00007f582cdcec97  mulpd xmm14, xmm15
00007f582cdcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007f582cdceca2  ptest xmm13, xmm13
00007f582cdceca8  jnz 0x00007F582CDCEE9C
00007f582cdcecae  movaps [r15+0x210], xmm14
00007f582cdcecb6  mov r14, [r15+0x40]
00007f582cdcecba  lea r12, [r14+rax*1]
00007f582cdcecbe  movups [r13+r12*1], xmm14
00007f582cdcecc4  lea r14, [rax+0x10]
00007f582cdcecc8  mov [r15+0x48], r14
00007f582cdceccc  xor eax, eax
00007f582cdcecce  mov r12d, 0x200
00007f582cdcecd4  cmp r14, r12
00007f582cdcecd7  cmc
00007f582cdcecd8  lahf
00007f582cdcecd9  seto al
00007f582cdcecdc  mov [r15+0x108], eax
00007f582cdcece3  mov eax, [r15+0x108]
00007f582cdcecea  sahf
00007f582cdceceb  jnz 0x00007F582CDCED1D
00007f582cdceced  cmp dword ptr [r15+0x318], 0x00
00007f582cdcecf5  jz 0x00007F582CDCEFF0
00007f582cdcecfb  nop [rax+rax*1], ax
00007f582cdced04  nop [rax+rax*1], eax
00007f582cdced0c  mov eax, 0x4101EC
00007f582cdced11  mov [r15+0x100], rax
00007f582cdced18  jmp 0x00007F582CBFE110
00007f582cdced1d  cmp dword ptr [r15+0x318], 0x00
00007f582cdced25  jz 0x00007F582CDCEBA0
00007f582cdced2b  nop [rax+rax*1], ax
00007f582cdced34  nop [rax+rax*1], eax
00007f582cdced3c  mov eax, 0x4101AC
00007f582cdced41  mov [r15+0x100], rax
00007f582cdced48  jmp 0x00007F582CBFE110
00007f582cdced4d  int3
00007f582cdced4e  sub rsp, 0x08
00007f582cdced52  push rax
00007f582cdced53  push rcx
00007f582cdced54  push rdx
00007f582cdced55  push rdi
00007f582cdced56  push rsi
00007f582cdced57  push r8
00007f582cdced59  push r9
00007f582cdced5b  push r10
00007f582cdced5d  push r11
00007f582cdced5f  sub rsp, 0xF0
00007f582cdced66  vmovaps [rsp], xmm0
00007f582cdced6b  vmovaps [rsp+0x10], xmm1
00007f582cdced71  vmovaps [rsp+0x20], xmm2
00007f582cdced77  vmovaps [rsp+0x30], xmm3
00007f582cdced7d  vmovaps [rsp+0x40], xmm4
00007f582cdced83  vmovaps [rsp+0x50], xmm5
00007f582cdced89  vmovaps [rsp+0x60], xmm6
00007f582cdced8f  vmovaps [rsp+0x70], xmm7
00007f582cdced95  vmovaps [rsp+0x80], xmm8
00007f582cdced9e  vmovaps [rsp+0x90], xmm9
00007f582cdceda7  vmovaps [rsp+0xA0], xmm10
00007f582cdcedb0  vmovaps [rsp+0xB0], xmm11
00007f582cdcedb9  vmovaps [rsp+0xC0], xmm12
00007f582cdcedc2  vmovaps [rsp+0xD0], xmm14
00007f582cdcedcb  vmovaps [rsp+0xE0], xmm15
00007f582cdcedd4  sub rsp, 0x30
00007f582cdcedd8  movaps [rsp], xmm13
00007f582cdceddd  movaps [rsp+0x10], xmm15
00007f582cdcede3  movaps [rsp+0x20], xmm14
00007f582cdcede9  lea rdi, [rsp]
00007f582cdceded  mov esi, 0x00
00007f582cdcedf2  mov rax, 0x653B0D9BF530
00007f582cdcedfc  call rax
00007f582cdcedfe  movaps xmm13, [rsp]
00007f582cdcee03  add rsp, 0x30
00007f582cdcee07  vmovaps xmm0, [rsp]
00007f582cdcee0c  vmovaps xmm1, [rsp+0x10]
00007f582cdcee12  vmovaps xmm2, [rsp+0x20]
00007f582cdcee18  vmovaps xmm3, [rsp+0x30]
00007f582cdcee1e  vmovaps xmm4, [rsp+0x40]
00007f582cdcee24  vmovaps xmm5, [rsp+0x50]
00007f582cdcee2a  vmovaps xmm6, [rsp+0x60]
00007f582cdcee30  vmovaps xmm7, [rsp+0x70]
00007f582cdcee36  vmovaps xmm8, [rsp+0x80]
00007f582cdcee3f  vmovaps xmm9, [rsp+0x90]
00007f582cdcee48  vmovaps xmm10, [rsp+0xA0]
00007f582cdcee51  vmovaps xmm11, [rsp+0xB0]
00007f582cdcee5a  vmovaps xmm12, [rsp+0xC0]
00007f582cdcee63  vmovaps xmm14, [rsp+0xD0]
00007f582cdcee6c  vmovaps xmm15, [rsp+0xE0]
00007f582cdcee75  add rsp, 0xF0
00007f582cdcee7c  pop r11
00007f582cdcee7e  pop r10
00007f582cdcee80  pop r9
00007f582cdcee82  pop r8
00007f582cdcee84  pop rsi
00007f582cdcee85  pop rdi
00007f582cdcee86  pop rdx
00007f582cdcee87  pop rcx
00007f582cdcee88  pop rax
00007f582cdcee89  add rsp, 0x08
00007f582cdcee8d  jmp 0x00007F582CDCEC71
00007f582cdcee92  call 0x00007F582CCC2240
00007f582cdcee97  jmp 0x00007F582CDCEC8B
00007f582cdcee9c  sub rsp, 0x08
00007f582cdceea0  push rax
00007f582cdceea1  push rcx
00007f582cdceea2  push rdx
00007f582cdceea3  push rdi
00007f582cdceea4  push rsi
00007f582cdceea5  push r8
00007f582cdceea7  push r9
00007f582cdceea9  push r10
00007f582cdceeab  push r11
00007f582cdceead  sub rsp, 0xF0
00007f582cdceeb4  vmovaps [rsp], xmm0
00007f582cdceeb9  vmovaps [rsp+0x10], xmm1
00007f582cdceebf  vmovaps [rsp+0x20], xmm2
00007f582cdceec5  vmovaps [rsp+0x30], xmm3
00007f582cdceecb  vmovaps [rsp+0x40], xmm4
00007f582cdceed1  vmovaps [rsp+0x50], xmm5
00007f582cdceed7  vmovaps [rsp+0x60], xmm6
00007f582cdceedd  vmovaps [rsp+0x70], xmm7
00007f582cdceee3  vmovaps [rsp+0x80], xmm8
00007f582cdceeec  vmovaps [rsp+0x90], xmm9
00007f582cdceef5  vmovaps [rsp+0xA0], xmm10
00007f582cdceefe  vmovaps [rsp+0xB0], xmm11
00007f582cdcef07  vmovaps [rsp+0xC0], xmm12
00007f582cdcef10  vmovaps [rsp+0xD0], xmm13
00007f582cdcef19  vmovaps [rsp+0xE0], xmm15
00007f582cdcef22  sub rsp, 0x30
00007f582cdcef26  movaps [rsp], xmm14
00007f582cdcef2b  movaps [rsp+0x10], xmm1
00007f582cdcef30  movaps [rsp+0x20], xmm15
00007f582cdcef36  lea rdi, [rsp]
00007f582cdcef3a  mov esi, 0x00
00007f582cdcef3f  mov rax, 0x653B0D9BF530
00007f582cdcef49  call rax
00007f582cdcef4b  movaps xmm14, [rsp]
00007f582cdcef50  add rsp, 0x30
00007f582cdcef54  vmovaps xmm0, [rsp]
00007f582cdcef59  vmovaps xmm1, [rsp+0x10]
00007f582cdcef5f  vmovaps xmm2, [rsp+0x20]
00007f582cdcef65  vmovaps xmm3, [rsp+0x30]
00007f582cdcef6b  vmovaps xmm4, [rsp+0x40]
00007f582cdcef71  vmovaps xmm5, [rsp+0x50]
00007f582cdcef77  vmovaps xmm6, [rsp+0x60]
00007f582cdcef7d  vmovaps xmm7, [rsp+0x70]
00007f582cdcef83  vmovaps xmm8, [rsp+0x80]
00007f582cdcef8c  vmovaps xmm9, [rsp+0x90]
00007f582cdcef95  vmovaps xmm10, [rsp+0xA0]
00007f582cdcef9e  vmovaps xmm11, [rsp+0xB0]
00007f582cdcefa7  vmovaps xmm12, [rsp+0xC0]
00007f582cdcefb0  vmovaps xmm13, [rsp+0xD0]
00007f582cdcefb9  vmovaps xmm15, [rsp+0xE0]
00007f582cdcefc2  add rsp, 0xF0
00007f582cdcefc9  pop r11
00007f582cdcefcb  pop r10
00007f582cdcefcd  pop r9
00007f582cdcefcf  pop r8
00007f582cdcefd1  pop rsi
00007f582cdcefd2  pop rdi
00007f582cdcefd3  pop rdx
00007f582cdcefd4  pop rcx
00007f582cdcefd5  pop rax
00007f582cdcefd6  add rsp, 0x08
00007f582cdcefda  jmp 0x00007F582CDCECAE
00007f582cdcefdf  call 0x00007F582CCC34C0
00007f582cdcefe4  jmp 0x00007F582CDCECC4
00007f582cdcefe9  int3
00007f582cdcefea  nop [rax+rax*1], ax
00007f582cdceff0  mov rax, [r15+0xF8]
00007f582cdceff7  lea r14, [rax-0x150]
00007f582cdceffe  mov [r15+0xF8], r14
00007f582cdcf005  mov rax, [r15+0x50]
00007f582cdcf009  lea r12, [rax+0x80]
00007f582cdcf010  movups xmm1, [r13+r12*1]
00007f582cdcf016  lea r12, [rax+0x90]
00007f582cdcf01d  movups xmm15, [r13+r12*1]
00007f582cdcf023  mov qword ptr [r15+0x48], 0x00
00007f582cdcf02b  lea r12, [rax+0x40]
00007f582cdcf02f  movups xmm14, [r13+r12*1]
00007f582cdcf035  lea r12, [rax+0x50]
00007f582cdcf039  movups xmm13, [r13+r12*1]
00007f582cdcf03f  lea r12, [r14+0x120]
00007f582cdcf046  movq xmm12, qword ptr [r15+0x1C0]
00007f582cdcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007f582cdcf058  movq r11, xmm12
00007f582cdcf05d  movq r10, xmm11
00007f582cdcf062  mov [r13+r12*1], r11
00007f582cdcf067  lea r12, [r14+0x128]
00007f582cdcf06e  mov [r13+r12*1], r10
00007f582cdcf073  vxorps xmm12, xmm12, xmm12
00007f582cdcf078  vpbroadcastq xmm12, xmm12
00007f582cdcf07d  lea r12, [r14+0x100]
00007f582cdcf084  movq xmm11, qword ptr [r15+0x200]
00007f582cdcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007f582cdcf096  movq r11, xmm11
00007f582cdcf09b  movq r10, xmm10
00007f582cdcf0a0  mov [r13+r12*1], r11
00007f582cdcf0a5  lea r12, [r14+0x108]
00007f582cdcf0ac  mov [r13+r12*1], r10
00007f582cdcf0b1  lea r12, [r14+0xE0]
00007f582cdcf0b8  movups [r13+r12*1], xmm15
00007f582cdcf0be  lea r12, [r14+0xF0]
00007f582cdcf0c5  movups [r13+r12*1], xmm1
00007f582cdcf0cb  lea r12, [rax+0xC0]
00007f582cdcf0d2  movups xmm1, [r13+r12*1]
00007f582cdcf0d8  lea r12, [rax+0xD0]
00007f582cdcf0df  movups xmm15, [r13+r12*1]
00007f582cdcf0e5  lea r12, [r14+0x110]
00007f582cdcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007f582cdcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007f582cdcf0fe  movq r11, xmm11
00007f582cdcf103  movq r10, xmm10
00007f582cdcf108  mov [r13+r12*1], r11
00007f582cdcf10d  lea r12, [r14+0x118]
00007f582cdcf114  mov [r13+r12*1], r10
00007f582cdcf119  movups xmm11, [r13+rax*1]
00007f582cdcf11f  lea r12, [rax+0x10]
00007f582cdcf123  movups xmm10, [r13+r12*1]
00007f582cdcf129  lea r12, [r14+0x130]
00007f582cdcf130  movq xmm9, qword ptr [r15+0x1A0]
00007f582cdcf139  movq xmm8, qword ptr [r15+0x190]
00007f582cdcf142  movq r11, xmm9
00007f582cdcf147  movq r10, xmm8
00007f582cdcf14c  mov [r13+r12*1], r11
00007f582cdcf151  lea r12, [r14+0x138]
00007f582cdcf158  mov [r13+r12*1], r10
00007f582cdcf15d  lea r12, [rax+0x140]
00007f582cdcf164  movups xmm9, [r13+r12*1]
00007f582cdcf16a  lea r12, [rax+0x150]
00007f582cdcf171  movups xmm8, [r13+r12*1]
00007f582cdcf177  lea r12, [r14+0xC0]
00007f582cdcf17e  movups [r13+r12*1], xmm15
00007f582cdcf184  lea r12, [r14+0xD0]
00007f582cdcf18b  movups [r13+r12*1], xmm1
00007f582cdcf191  lea r12, [rax+0x100]
00007f582cdcf198  movups xmm1, [r13+r12*1]
00007f582cdcf19e  lea r12, [rax+0x110]
00007f582cdcf1a5  movups xmm15, [r13+r12*1]
00007f582cdcf1ab  lea r12, [r14+0x140]
00007f582cdcf1b2  mov r11, [r15+0xE8]
00007f582cdcf1b9  mov [r13+r12*1], r11
00007f582cdcf1be  lea r12, [rax+0x180]
00007f582cdcf1c5  movups xmm7, [r13+r12*1]
00007f582cdcf1cb  lea r12, [rax+0x190]
00007f582cdcf1d2  movups xmm6, [r13+r12*1]
00007f582cdcf1d8  lea r12, [rax+0x1C0]
00007f582cdcf1df  movups xmm5, [r13+r12*1]
00007f582cdcf1e5  lea r12, [rax+0x1D0]
00007f582cdcf1ec  movups xmm4, [r13+r12*1]
00007f582cdcf1f2  lea r12, [r14+0x20]
00007f582cdcf1f6  movups [r13+r12*1], xmm1
00007f582cdcf1fc  lea r12, [r14+0x30]
00007f582cdcf200  movups [r13+r12*1], xmm13
00007f582cdcf206  lea r12, [rax+0x60]
00007f582cdcf20a  movups xmm1, [r13+r12*1]
00007f582cdcf210  lea r12, [rax+0x70]
00007f582cdcf214  movups xmm13, [r13+r12*1]
00007f582cdcf21a  lea r12, [rax+0x20]
00007f582cdcf21e  movups xmm3, [r13+r12*1]
00007f582cdcf224  lea r12, [rax+0x30]
00007f582cdcf228  movups xmm2, [r13+r12*1]
00007f582cdcf22e  movaps [r15+0x1F0], xmm2
00007f582cdcf236  lea r12, [r14+0x60]
00007f582cdcf23a  movups [r13+r12*1], xmm11
00007f582cdcf240  lea r12, [r14+0x70]
00007f582cdcf244  movups [r13+r12*1], xmm5
00007f582cdcf24a  lea r12, [rax+0xE0]
00007f582cdcf251  movups xmm11, [r13+r12*1]
00007f582cdcf257  lea r12, [rax+0xF0]
00007f582cdcf25e  movups xmm5, [r13+r12*1]
00007f582cdcf264  lea r12, [r14+0xA0]
00007f582cdcf26b  movups [r13+r12*1], xmm13
00007f582cdcf271  lea r12, [r14+0xB0]
00007f582cdcf278  movups [r13+r12*1], xmm1
00007f582cdcf27e  lea r12, [rax+0xA0]
00007f582cdcf285  movups xmm1, [r13+r12*1]
00007f582cdcf28b  lea r12, [rax+0xB0]
00007f582cdcf292  movups xmm13, [r13+r12*1]
00007f582cdcf298  lea r12, [rax+0x120]
00007f582cdcf29f  vmovaps [rsp+0x10], xmm1
00007f582cdcf2a5  movups xmm1, [r13+r12*1]
00007f582cdcf2ab  lea r12, [rax+0x130]
00007f582cdcf2b2  vmovaps [rsp+0x20], xmm1
00007f582cdcf2b8  movups xmm1, [r13+r12*1]
00007f582cdcf2be  lea r12, [rax+0x160]
00007f582cdcf2c5  vmovaps [rsp+0x30], xmm1
00007f582cdcf2cb  movups xmm1, [r13+r12*1]
00007f582cdcf2d1  lea r12, [rax+0x170]
00007f582cdcf2d8  vmovaps [rsp+0x40], xmm1
00007f582cdcf2de  movups xmm1, [r13+r12*1]
00007f582cdcf2e4  movaps [r15+0x2B0], xmm1
00007f582cdcf2ec  lea r12, [r14+0x80]
00007f582cdcf2f3  movups [r13+r12*1], xmm13
00007f582cdcf2f9  lea r12, [r14+0x90]
00007f582cdcf300  vmovaps xmm13, [rsp+0x10]
00007f582cdcf306  movups [r13+r12*1], xmm13
00007f582cdcf30c  lea r12, [rax+0x1A0]
00007f582cdcf313  movups xmm13, [r13+r12*1]
00007f582cdcf319  lea r12, [rax+0x1B0]
00007f582cdcf320  vmovaps [rsp+0x10], xmm1
00007f582cdcf326  movups xmm1, [r13+r12*1]
00007f582cdcf32c  movaps [r15+0x290], xmm13
00007f582cdcf334  movaps [r15+0x1E0], xmm1
00007f582cdcf33c  lea r12, [rax+0x1E0]
00007f582cdcf343  vmovaps [rsp+0x50], xmm1
00007f582cdcf349  movups xmm1, [r13+r12*1]
00007f582cdcf34f  lea r12, [rax+0x1F0]
00007f582cdcf356  vmovaps [rsp+0x60], xmm1
00007f582cdcf35c  movups xmm1, [r13+r12*1]
00007f582cdcf362  mov qword ptr [r15+0x50], 0x430920
00007f582cdcf36a  lea rax, [r14+0x40]
00007f582cdcf36e  vmovaps [rsp+0x70], xmm1
00007f582cdcf374  vmovaps xmm1, [rsp+0x40]
00007f582cdcf37a  movups [r13+rax*1], xmm1
00007f582cdcf380  lea rax, [r14+0x50]
00007f582cdcf384  movups [r13+rax*1], xmm10
00007f582cdcf38a  vmovaps xmm1, [rsp+0x70]
00007f582cdcf390  movups [r13+r14*1], xmm1
00007f582cdcf396  lea rax, [r14+0x10]
00007f582cdcf39a  vmovaps xmm1, [rsp+0x60]
00007f582cdcf3a0  movups [r13+rax*1], xmm1
00007f582cdcf3a6  mov rax, [r15+0x40]
00007f582cdcf3aa  vmovaps [rsp+0x40], xmm3
00007f582cdcf3b0  vmovaps xmm1, [rsp+0x40]
00007f582cdcf3b6  por xmm3, xmm1
00007f582cdcf3ba  vmovaps [rsp+0x40], xmm6
00007f582cdcf3c0  vmovaps xmm10, [rsp+0x40]
00007f582cdcf3c6  por xmm6, xmm10
00007f582cdcf3cb  lea r12, [rax+0x30]
00007f582cdcf3cf  mov r11, [r13+r12*1]
00007f582cdcf3d4  lea r12, [rax+0x38]
00007f582cdcf3d8  mov r10, [r13+r12*1]
00007f582cdcf3dd  movq xmm10, r11
00007f582cdcf3e2  vmovaps [rsp+0x40], xmm1
00007f582cdcf3e8  movq xmm1, r10
00007f582cdcf3ed  movq xmm10, xmm10
00007f582cdcf3f2  vmovaps [rsp+0x60], xmm10
00007f582cdcf3f8  movq xmm10, xmm10
00007f582cdcf3fd  movaps [r15+0x130], xmm10
00007f582cdcf405  movq xmm1, xmm1
00007f582cdcf409  vmovaps [rsp+0x70], xmm1
00007f582cdcf40f  movq xmm1, xmm1
00007f582cdcf413  movaps [r15+0x280], xmm1
00007f582cdcf41b  vmovaps [rsp+0x80], xmm9
00007f582cdcf424  vmovaps xmm1, [rsp+0x80]
00007f582cdcf42d  por xmm9, xmm1
00007f582cdcf432  lea r12, [rax+0x20]
00007f582cdcf436  mov r11, [r13+r12*1]
00007f582cdcf43b  lea r12, [rax+0x28]
00007f582cdcf43f  mov r10, [r13+r12*1]
00007f582cdcf444  movq xmm1, r11
00007f582cdcf449  movq xmm10, r10
00007f582cdcf44e  movq xmm1, xmm1
00007f582cdcf452  vmovaps [rsp+0x80], xmm1
00007f582cdcf45b  movq xmm1, xmm1
00007f582cdcf45f  movaps [r15+0x150], xmm1
00007f582cdcf467  movq xmm10, xmm10
00007f582cdcf46c  vmovaps [rsp+0x90], xmm10
00007f582cdcf475  movq xmm10, xmm10
00007f582cdcf47a  movaps [r15+0x140], xmm10
00007f582cdcf482  lea r12, [rax+0x10]
00007f582cdcf486  mov r11, [r13+r12*1]
00007f582cdcf48b  lea r12, [rax+0x18]
00007f582cdcf48f  mov r10, [r13+r12*1]
00007f582cdcf494  movq xmm1, r11
00007f582cdcf499  movq xmm10, r10
00007f582cdcf49e  movq xmm1, xmm1
00007f582cdcf4a2  vmovaps [rsp+0xA0], xmm1
00007f582cdcf4ab  movq xmm1, xmm1
00007f582cdcf4af  movaps [r15+0x170], xmm1
00007f582cdcf4b7  movq xmm10, xmm10
00007f582cdcf4bc  vmovaps [rsp+0xB0], xmm10
00007f582cdcf4c5  movq xmm10, xmm10
00007f582cdcf4ca  movaps [r15+0x160], xmm10
00007f582cdcf4d2  mov r12, [r13+rax*1]
00007f582cdcf4d7  vmovq xmm1, r12
00007f582cdcf4dc  vpbroadcastq xmm1, xmm1
00007f582cdcf4e1  lea r12, [rax+0x08]
00007f582cdcf4e5  mov rax, [r13+r12*1]
00007f582cdcf4ea  movq xmm10, rax
00007f582cdcf4ef  movaps [r15+0x230], xmm10
00007f582cdcf4f7  lea rax, [r14+0x50]
00007f582cdcf4fb  movups xmm10, [r13+rax*1]
00007f582cdcf501  lea rax, [r14+0x60]
00007f582cdcf505  vmovaps [rsp+0xC0], xmm1
00007f582cdcf50e  movups xmm1, [r13+rax*1]
00007f582cdcf514  lea rax, [r14+0x30]
00007f582cdcf518  vmovaps [rsp+0xD0], xmm1
00007f582cdcf521  movups xmm1, [r13+rax*1]
00007f582cdcf527  mov qword ptr [r15+0x60], 0x430920
00007f582cdcf52f  mov qword ptr [r15+0x58], 0x40
00007f582cdcf537  vmovaps [rsp+0xE0], xmm1
00007f582cdcf540  vmovaps [rsp+0xF0], xmm15
00007f582cdcf549  vmovaps xmm15, [rsp+0xC0]
00007f582cdcf552  vmovaps [rsp+0xC0], xmm14
00007f582cdcf55b  vmovaps xmm14, [rsp+0x40]
00007f582cdcf561  vmovaps [rsp+0x40], xmm13
00007f582cdcf567  movaps xmm1, xmm15
00007f582cdcf56b  mulpd xmm1, xmm14
00007f582cdcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007f582cdcf575  ptest xmm13, xmm13
00007f582cdcf57b  jnz 0x00007F582CDD0682
00007f582cdcf581  movq xmm14, qword ptr [r15+0x230]
00007f582cdcf58a  vmovaps [rsp+0x100], xmm14
00007f582cdcf593  vpermilpd xmm14, xmm14, 0x00
00007f582cdcf599  vmovaps [rsp+0x110], xmm1
00007f582cdcf5a2  vmovaps xmm1, [rsp+0xE0]
00007f582cdcf5ab  vmovaps [rsp+0xE0], xmm15
00007f582cdcf5b4  movaps xmm13, xmm1
00007f582cdcf5b8  mulpd xmm13, xmm14
00007f582cdcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007f582cdcf5c3  ptest xmm15, xmm15
00007f582cdcf5c9  jnz 0x00007F582CDD07C4
00007f582cdcf5cf  vxorps xmm1, xmm1, xmm1
00007f582cdcf5d3  vpbroadcastq xmm1, xmm1
00007f582cdcf5d8  vmovaps xmm14, [rsp+0xE0]
00007f582cdcf5e1  vmovaps [rsp+0xE0], xmm1
00007f582cdcf5ea  vmovaps xmm1, [rsp+0xD0]
00007f582cdcf5f3  vmovaps [rsp+0xD0], xmm13
00007f582cdcf5fc  movaps xmm15, xmm14
00007f582cdcf600  mulpd xmm15, xmm1
00007f582cdcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007f582cdcf60b  ptest xmm13, xmm13
00007f582cdcf611  jnz 0x00007F582CDD0907
00007f582cdcf617  movaps xmm1, xmm14
00007f582cdcf61b  mulpd xmm1, xmm10
00007f582cdcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007f582cdcf625  ptest xmm13, xmm13
00007f582cdcf62b  jnz 0x00007F582CDD0A4A
00007f582cdcf631  movaps xmm13, xmm14
00007f582cdcf635  mulpd xmm13, xmm2
00007f582cdcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007f582cdcf640  ptest xmm10, xmm10
00007f582cdcf646  jnz 0x00007F582CDD0B8C
00007f582cdcf64c  vmovaps [rsp+0x120], xmm7
00007f582cdcf655  vmovaps xmm14, [rsp+0x120]
00007f582cdcf65e  por xmm7, xmm14
00007f582cdcf663  vmovaps xmm14, [rsp+0xC0]
00007f582cdcf66c  vmovaps xmm10, [rsp+0xC0]
00007f582cdcf675  por xmm14, xmm10
00007f582cdcf67a  vmovaps xmm2, [rsp+0x100]
00007f582cdcf683  vpermilpd xmm2, xmm2, 0x00
00007f582cdcf689  vmovaps [rsp+0xC0], xmm1
00007f582cdcf692  vmovaps [rsp+0x120], xmm15
00007f582cdcf69b  movaps xmm1, xmm10
00007f582cdcf69f  mulpd xmm1, xmm2
00007f582cdcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007f582cdcf6a8  ptest xmm15, xmm15
00007f582cdcf6ae  jnz 0x00007F582CDD0CCF
00007f582cdcf6b4  xor eax, eax
00007f582cdcf6b6  mov r12d, 0x40
00007f582cdcf6bc  mov r11d, 0x200
00007f582cdcf6c2  cmp r12, r11
00007f582cdcf6c5  cmc
00007f582cdcf6c6  lahf
00007f582cdcf6c7  seto al
00007f582cdcf6ca  mov [r15+0x108], eax
00007f582cdcf6d1  vmovaps xmm10, [rsp+0x110]
00007f582cdcf6da  vmovaps xmm2, [rsp+0xE0]
00007f582cdcf6e3  vmovaps [rsp+0xE0], xmm1
00007f582cdcf6ec  movaps xmm15, xmm10
00007f582cdcf6f0  addpd xmm15, xmm2
00007f582cdcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f582cdcf6fb  ptest xmm1, xmm1
00007f582cdcf700  jnz 0x00007F582CDD0E10
00007f582cdcf706  vmovaps xmm10, [rsp+0x120]
00007f582cdcf70f  vmovaps [rsp+0x110], xmm15
00007f582cdcf718  movaps xmm1, xmm10
00007f582cdcf71c  addpd xmm1, xmm12
00007f582cdcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007f582cdcf726  ptest xmm15, xmm15
00007f582cdcf72c  jnz 0x00007F582CDD0F53
00007f582cdcf732  vmovaps xmm10, [rsp+0xC0]
00007f582cdcf73b  vmovaps [rsp+0xC0], xmm1
00007f582cdcf744  movaps xmm15, xmm10
00007f582cdcf748  addpd xmm15, xmm12
00007f582cdcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007f582cdcf753  ptest xmm1, xmm1
00007f582cdcf758  jnz 0x00007F582CDD1095
00007f582cdcf75e  vmovaps xmm1, [rsp+0x30]
00007f582cdcf764  vmovaps xmm12, [rsp+0x30]
00007f582cdcf76a  por xmm1, xmm12
00007f582cdcf76f  vmovaps xmm12, [rsp+0x20]
00007f582cdcf775  vmovaps xmm10, [rsp+0x20]
00007f582cdcf77b  por xmm12, xmm10
00007f582cdcf780  vmovaps [rsp+0x20], xmm5
00007f582cdcf786  vmovaps xmm10, [rsp+0x20]
00007f582cdcf78c  por xmm5, xmm10
00007f582cdcf791  vmovaps [rsp+0x20], xmm11
00007f582cdcf797  vmovaps xmm10, [rsp+0x20]
00007f582cdcf79d  por xmm11, xmm10
00007f582cdcf7a2  vmovaps [rsp+0x20], xmm4
00007f582cdcf7a8  vmovaps xmm10, [rsp+0x20]
00007f582cdcf7ae  por xmm4, xmm10
00007f582cdcf7b3  vmovaps [rsp+0x20], xmm8
00007f582cdcf7b9  vmovaps xmm10, [rsp+0x20]
00007f582cdcf7bf  por xmm8, xmm10
00007f582cdcf7c4  vmovaps xmm10, [rsp+0xF0]
00007f582cdcf7cd  vmovaps [rsp+0x20], xmm1
00007f582cdcf7d3  vmovaps xmm1, [rsp+0xF0]
00007f582cdcf7dc  por xmm10, xmm1
00007f582cdcf7e1  lea rax, [r14+0xA0]
00007f582cdcf7e8  movups xmm1, [r13+rax*1]
00007f582cdcf7ee  lea rax, [r14+0xB0]
00007f582cdcf7f5  vmovaps [rsp+0x30], xmm1
00007f582cdcf7fb  movups xmm1, [r13+rax*1]
00007f582cdcf801  vmovaps [rsp+0xF0], xmm1
00007f582cdcf80a  vmovaps [rsp+0x120], xmm15
00007f582cdcf813  movaps xmm1, xmm13
00007f582cdcf817  addpd xmm1, xmm2
00007f582cdcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007f582cdcf820  ptest xmm15, xmm15
00007f582cdcf826  jnz 0x00007F582CDD11ED
00007f582cdcf82c  lea rax, [r14+0xF0]
00007f582cdcf833  movups xmm15, [r13+rax*1]
00007f582cdcf839  vmovaps xmm2, [rsp+0xC0]
00007f582cdcf842  vmovaps [rsp+0xC0], xmm1
00007f582cdcf84b  vmovaps xmm1, [rsp+0xE0]
00007f582cdcf854  vmovaps [rsp+0xE0], xmm15
00007f582cdcf85d  movaps xmm13, xmm2
00007f582cdcf861  addpd xmm13, xmm1
00007f582cdcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007f582cdcf86c  ptest xmm15, xmm15
00007f582cdcf872  jnz 0x00007F582CDD1338
00007f582cdcf878  vmovaps xmm15, [rsp+0x120]
00007f582cdcf881  vmovaps xmm2, [rsp+0xD0]
00007f582cdcf88a  vmovaps [rsp+0xD0], xmm14
00007f582cdcf893  movaps xmm1, xmm15
00007f582cdcf897  addpd xmm1, xmm2
00007f582cdcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007f582cdcf8a0  ptest xmm14, xmm14
00007f582cdcf8a6  jnz 0x00007F582CDD147A
00007f582cdcf8ac  vmovaps xmm15, [rsp+0x100]
00007f582cdcf8b5  vpermilpd xmm15, xmm15, 0x00
00007f582cdcf8bb  vmovaps xmm2, [rsp+0xF0]
00007f582cdcf8c4  vmovaps [rsp+0xF0], xmm1
00007f582cdcf8cd  movaps xmm14, xmm2
00007f582cdcf8d1  mulpd xmm14, xmm15
00007f582cdcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007f582cdcf8dc  ptest xmm1, xmm1
00007f582cdcf8e1  jnz 0x00007F582CDD15BB
00007f582cdcf8e7  vmovaps xmm1, [rsp+0xA0]
00007f582cdcf8f0  vpermilpd xmm1, xmm1, 0x00
00007f582cdcf8f6  vmovaps xmm2, [rsp+0xE0]
00007f582cdcf8ff  vmovaps [rsp+0xE0], xmm14
00007f582cdcf908  movaps xmm15, xmm2
00007f582cdcf90c  mulpd xmm15, xmm1
00007f582cdcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007f582cdcf917  ptest xmm14, xmm14
00007f582cdcf91d  jnz 0x00007F582CDD16FE
00007f582cdcf923  lea rax, [r14+0xE0]
00007f582cdcf92a  movups xmm1, [r13+rax*1]
00007f582cdcf930  vmovaps xmm14, [rsp+0x100]
00007f582cdcf939  vpermilpd xmm14, xmm14, 0x00
00007f582cdcf93f  vmovaps [rsp+0x100], xmm1
00007f582cdcf948  vmovaps xmm1, [rsp+0x30]
00007f582cdcf94e  vmovaps [rsp+0x30], xmm15
00007f582cdcf954  movaps xmm2, xmm1
00007f582cdcf957  mulpd xmm2, xmm14
00007f582cdcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007f582cdcf961  ptest xmm15, xmm15
00007f582cdcf967  jnz 0x00007F582CDD184A
00007f582cdcf96d  vmovaps [rsp+0x120], xmm10
00007f582cdcf976  vmovaps xmm1, [rsp+0x120]
00007f582cdcf97f  por xmm10, xmm1
00007f582cdcf984  movaps [r15+0x300], xmm10
00007f582cdcf98c  vmovaps [rsp+0x120], xmm8
00007f582cdcf995  vmovaps xmm1, [rsp+0x120]
00007f582cdcf99e  por xmm8, xmm1
00007f582cdcf9a3  movaps [r15+0x190], xmm8
00007f582cdcf9ab  vmovaps xmm1, [rsp+0xA0]
00007f582cdcf9b4  vpermilpd xmm1, xmm1, 0x00
00007f582cdcf9ba  vmovaps xmm14, [rsp+0x100]
00007f582cdcf9c3  vmovaps [rsp+0x100], xmm13
00007f582cdcf9cc  movaps xmm15, xmm14
00007f582cdcf9d0  mulpd xmm15, xmm1
00007f582cdcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007f582cdcf9db  ptest xmm13, xmm13
00007f582cdcf9e1  jnz 0x00007F582CDD198B
00007f582cdcf9e7  lea rax, [r14+0x90]
00007f582cdcf9ee  movups xmm1, [r13+rax*1]
00007f582cdcf9f4  vmovaps [rsp+0x120], xmm4
00007f582cdcf9fd  vmovaps xmm14, [rsp+0x120]
00007f582cdcfa06  por xmm4, xmm14
00007f582cdcfa0b  movaps [r15+0x1C0], xmm4
00007f582cdcfa13  vmovaps [rsp+0x120], xmm11
00007f582cdcfa1c  vmovaps xmm14, [rsp+0x120]
00007f582cdcfa25  por xmm11, xmm14
00007f582cdcfa2a  movaps [r15+0x200], xmm11
00007f582cdcfa32  vmovaps [rsp+0x120], xmm5
00007f582cdcfa3b  vmovaps xmm14, [rsp+0x120]
00007f582cdcfa44  por xmm5, xmm14
00007f582cdcfa49  movaps [r15+0x2D0], xmm5
00007f582cdcfa51  vmovaps [rsp+0x120], xmm12
00007f582cdcfa5a  vmovaps xmm14, [rsp+0x120]
00007f582cdcfa63  por xmm12, xmm14
00007f582cdcfa68  movaps [r15+0x2E0], xmm12
00007f582cdcfa70  vmovaps xmm13, [rsp+0x110]
00007f582cdcfa79  vmovaps [rsp+0x110], xmm1
00007f582cdcfa82  vmovaps xmm1, [rsp+0xE0]
00007f582cdcfa8b  vmovaps [rsp+0xE0], xmm15
00007f582cdcfa94  movaps xmm14, xmm13
00007f582cdcfa98  addpd xmm14, xmm1
00007f582cdcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007f582cdcfaa3  ptest xmm15, xmm15
00007f582cdcfaa9  jnz 0x00007F582CDD1AD8
00007f582cdcfaaf  vmovaps xmm1, [rsp+0xA0]
00007f582cdcfab8  vpermilpd xmm1, xmm1, 0x00
00007f582cdcfabe  vmovaps xmm13, [rsp+0x110]
00007f582cdcfac7  vmovaps [rsp+0x110], xmm14
00007f582cdcfad0  movaps xmm15, xmm13
00007f582cdcfad4  mulpd xmm15, xmm1
00007f582cdcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007f582cdcfadf  ptest xmm14, xmm14
00007f582cdcfae5  jnz 0x00007F582CDD1C1B
00007f582cdcfaeb  lea rax, [r14+0x80]
00007f582cdcfaf2  movups xmm1, [r13+rax*1]
00007f582cdcfaf8  vmovaps xmm13, [rsp+0xC0]
00007f582cdcfb01  vmovaps [rsp+0xC0], xmm1
00007f582cdcfb0a  movaps xmm14, xmm13
00007f582cdcfb0e  addpd xmm14, xmm2
00007f582cdcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007f582cdcfb19  ptest xmm1, xmm1
00007f582cdcfb1e  jnz 0x00007F582CDD1D68
00007f582cdcfb24  vmovaps xmm13, [rsp+0x100]
00007f582cdcfb2d  vmovaps xmm2, [rsp+0x30]
00007f582cdcfb33  vmovaps [rsp+0x30], xmm15
00007f582cdcfb39  movaps xmm1, xmm13
00007f582cdcfb3d  addpd xmm1, xmm2
00007f582cdcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007f582cdcfb46  ptest xmm15, xmm15
00007f582cdcfb4c  jnz 0x00007F582CDD1EAB
00007f582cdcfb52  vmovaps xmm15, [rsp+0x20]
00007f582cdcfb58  vmovaps xmm13, [rsp+0x20]
00007f582cdcfb5e  por xmm15, xmm13
00007f582cdcfb63  movaps [r15+0x2F0], xmm15
00007f582cdcfb6b  vmovaps xmm13, [rsp+0xA0]
00007f582cdcfb74  vpermilpd xmm13, xmm13, 0x00
00007f582cdcfb7a  vmovaps [rsp+0x20], xmm1
00007f582cdcfb80  vmovaps xmm1, [rsp+0xC0]
00007f582cdcfb89  vmovaps [rsp+0xA0], xmm15
00007f582cdcfb92  movaps xmm2, xmm1
00007f582cdcfb95  mulpd xmm2, xmm13
00007f582cdcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007f582cdcfb9f  ptest xmm15, xmm15
00007f582cdcfba5  jnz 0x00007F582CDD1FEC
00007f582cdcfbab  lea rax, [r14+0xD0]
00007f582cdcfbb2  movups xmm1, [r13+rax*1]
00007f582cdcfbb8  vmovaps xmm13, [rsp+0xF0]
00007f582cdcfbc1  vmovaps [rsp+0xC0], xmm1
00007f582cdcfbca  vmovaps xmm1, [rsp+0xE0]
00007f582cdcfbd3  vmovaps [rsp+0xE0], xmm14
00007f582cdcfbdc  movaps xmm15, xmm13
00007f582cdcfbe0  addpd xmm15, xmm1
00007f582cdcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007f582cdcfbeb  ptest xmm14, xmm14
00007f582cdcfbf1  jnz 0x00007F582CDD2137
00007f582cdcfbf7  vmovaps xmm1, [rsp+0xB0]
00007f582cdcfc00  vpermilpd xmm1, xmm1, 0x00
00007f582cdcfc06  movaps xmm14, xmm11
00007f582cdcfc0a  mulpd xmm14, xmm1
00007f582cdcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007f582cdcfc15  ptest xmm13, xmm13
00007f582cdcfc1b  jnz 0x00007F582CDD227A
00007f582cdcfc21  movaps [r15+0x260], xmm14
00007f582cdcfc29  vxorps xmm1, xmm1, xmm1
00007f582cdcfc2d  vpbroadcastq xmm1, xmm1
00007f582cdcfc32  movaps [r15+0x1B0], xmm1
00007f582cdcfc3a  vmovaps xmm1, [rsp+0xB0]
00007f582cdcfc43  vpermilpd xmm1, xmm1, 0x00
00007f582cdcfc49  vmovaps xmm11, [rsp+0xC0]
00007f582cdcfc52  vmovaps [rsp+0xC0], xmm15
00007f582cdcfc5b  movaps xmm13, xmm11
00007f582cdcfc5f  mulpd xmm13, xmm1
00007f582cdcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007f582cdcfc6a  ptest xmm15, xmm15
00007f582cdcfc70  jnz 0x00007F582CDD23BD
00007f582cdcfc76  lea rax, [r14+0xC0]
00007f582cdcfc7d  movups xmm1, [r13+rax*1]
00007f582cdcfc83  vmovaps xmm11, [rsp+0x110]
00007f582cdcfc8c  vmovaps [rsp+0xF0], xmm1
00007f582cdcfc95  vmovaps xmm1, [rsp+0x30]
00007f582cdcfc9b  vmovaps [rsp+0x30], xmm14
00007f582cdcfca1  movaps xmm15, xmm11
00007f582cdcfca5  addpd xmm15, xmm1
00007f582cdcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007f582cdcfcb0  ptest xmm14, xmm14
00007f582cdcfcb6  jnz 0x00007F582CDD250A
00007f582cdcfcbc  vmovaps [rsp+0x100], xmm9
00007f582cdcfcc5  vmovaps xmm1, [rsp+0x100]
00007f582cdcfcce  por xmm9, xmm1
00007f582cdcfcd3  movaps [r15+0x270], xmm9
00007f582cdcfcdb  vmovaps [rsp+0x100], xmm6
00007f582cdcfce4  vmovaps xmm1, [rsp+0x100]
00007f582cdcfced  por xmm6, xmm1
00007f582cdcfcf1  movaps [r15+0x1A0], xmm6
00007f582cdcfcf9  vmovaps xmm14, [rsp+0xB0]
00007f582cdcfd02  vpermilpd xmm14, xmm14, 0x00
00007f582cdcfd08  vmovaps xmm6, [rsp+0xF0]
00007f582cdcfd11  vmovaps [rsp+0xF0], xmm1
00007f582cdcfd1a  movaps xmm11, xmm6
00007f582cdcfd1e  mulpd xmm11, xmm14
00007f582cdcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007f582cdcfd29  ptest xmm1, xmm1
00007f582cdcfd2e  jnz 0x00007F582CDD264D
00007f582cdcfd34  lea rax, [r14+0x20]
00007f582cdcfd38  movups xmm1, [r13+rax*1]
00007f582cdcfd3e  movaps [r15+0x110], xmm1
00007f582cdcfd46  vmovaps xmm6, [rsp+0xE0]
00007f582cdcfd4f  vmovaps [rsp+0xE0], xmm1
00007f582cdcfd58  movaps xmm14, xmm6
00007f582cdcfd5c  addpd xmm14, xmm2
00007f582cdcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007f582cdcfd67  ptest xmm1, xmm1
00007f582cdcfd6c  jnz 0x00007F582CDD279A
00007f582cdcfd72  vmovaps xmm1, [rsp+0xB0]
00007f582cdcfd7b  vpermilpd xmm1, xmm1, 0x00
00007f582cdcfd81  movaps xmm6, xmm5
00007f582cdcfd84  mulpd xmm6, xmm1
00007f582cdcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007f582cdcfd8d  ptest xmm2, xmm2
00007f582cdcfd92  jnz 0x00007F582CDD28DC
00007f582cdcfd98  vmovaps xmm5, [rsp+0x20]
00007f582cdcfd9e  movaps xmm1, xmm5
00007f582cdcfda1  addpd xmm1, xmm13
00007f582cdcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007f582cdcfdab  ptest xmm2, xmm2
00007f582cdcfdb0  jnz 0x00007F582CDD2A1C
00007f582cdcfdb6  vmovaps xmm13, [rsp+0x80]
00007f582cdcfdbf  vpermilpd xmm13, xmm13, 0x00
00007f582cdcfdc5  vmovaps xmm2, [rsp+0xE0]
00007f582cdcfdce  vmovaps [rsp+0x20], xmm1
00007f582cdcfdd4  movaps xmm5, xmm2
00007f582cdcfdd7  mulpd xmm5, xmm13
00007f582cdcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007f582cdcfde1  ptest xmm1, xmm1
00007f582cdcfde6  jnz 0x00007F582CDD2B5D
00007f582cdcfdec  vmovaps xmm1, [rsp+0x80]
00007f582cdcfdf5  vpermilpd xmm1, xmm1, 0x00
00007f582cdcfdfb  movaps xmm13, xmm10
00007f582cdcfdff  mulpd xmm13, xmm1
00007f582cdcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007f582cdcfe0a  ptest xmm2, xmm2
00007f582cdcfe0f  jnz 0x00007F582CDD2C9E
00007f582cdcfe15  vmovaps xmm10, [rsp+0x30]
00007f582cdcfe1b  movaps xmm1, xmm15
00007f582cdcfe1f  addpd xmm1, xmm10
00007f582cdcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007f582cdcfe29  ptest xmm2, xmm2
00007f582cdcfe2e  jnz 0x00007F582CDD2DE1
00007f582cdcfe34  vmovaps xmm10, [rsp+0xC0]
00007f582cdcfe3d  movaps xmm15, xmm10
00007f582cdcfe41  addpd xmm15, xmm11
00007f582cdcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007f582cdcfe4c  ptest xmm2, xmm2
00007f582cdcfe51  jnz 0x00007F582CDD2F23
00007f582cdcfe57  vmovaps xmm11, [rsp+0x80]
00007f582cdcfe60  vpermilpd xmm11, xmm11, 0x00
00007f582cdcfe66  movaps xmm10, xmm12
00007f582cdcfe6a  mulpd xmm10, xmm11
00007f582cdcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007f582cdcfe75  ptest xmm2, xmm2
00007f582cdcfe7a  jnz 0x00007F582CDD3067
00007f582cdcfe80  vmovaps xmm12, [rsp+0x80]
00007f582cdcfe89  vpermilpd xmm12, xmm12, 0x00
00007f582cdcfe8f  vmovaps xmm2, [rsp+0xA0]
00007f582cdcfe98  vmovaps [rsp+0x30], xmm1
00007f582cdcfe9e  movaps xmm11, xmm2
00007f582cdcfea2  mulpd xmm11, xmm12
00007f582cdcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007f582cdcfead  ptest xmm1, xmm1
00007f582cdcfeb2  jnz 0x00007F582CDD31AB
00007f582cdcfeb8  movaps xmm1, xmm14
00007f582cdcfebc  addpd xmm1, xmm6
00007f582cdcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007f582cdcfec5  ptest xmm12, xmm12
00007f582cdcfecb  jnz 0x00007F582CDD32EE
00007f582cdcfed1  vmovaps xmm12, [rsp+0x20]
00007f582cdcfed7  movaps xmm14, xmm12
00007f582cdcfedb  addpd xmm14, xmm5
00007f582cdcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007f582cdcfee6  ptest xmm6, xmm6
00007f582cdcfeeb  jnz 0x00007F582CDD342F
00007f582cdcfef1  vmovaps xmm12, [rsp+0x90]
00007f582cdcfefa  vpermilpd xmm12, xmm12, 0x00
00007f582cdcff00  movaps xmm6, xmm9
00007f582cdcff04  mulpd xmm6, xmm12
00007f582cdcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007f582cdcff0e  ptest xmm5, xmm5
00007f582cdcff13  jnz 0x00007F582CDD3572
00007f582cdcff19  movaps xmm12, xmm15
00007f582cdcff1d  addpd xmm12, xmm13
00007f582cdcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007f582cdcff28  ptest xmm9, xmm9
00007f582cdcff2e  jnz 0x00007F582CDD36B4
00007f582cdcff34  vmovaps xmm13, [rsp+0x30]
00007f582cdcff3a  movaps xmm15, xmm13
00007f582cdcff3e  addpd xmm15, xmm10
00007f582cdcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007f582cdcff49  ptest xmm9, xmm9
00007f582cdcff4f  jnz 0x00007F582CDD37F8
00007f582cdcff55  vmovaps xmm13, [rsp+0xD0]
00007f582cdcff5e  vmovaps xmm10, [rsp+0xD0]
00007f582cdcff67  por xmm13, xmm10
00007f582cdcff6c  movaps [r15+0x250], xmm13
00007f582cdcff74  vmovaps [rsp+0x20], xmm7
00007f582cdcff7a  vmovaps xmm13, [rsp+0x20]
00007f582cdcff80  por xmm7, xmm13
00007f582cdcff85  movaps [r15+0x2A0], xmm7
00007f582cdcff8d  vmovaps [rsp+0x20], xmm3
00007f582cdcff93  vmovaps xmm13, [rsp+0x20]
00007f582cdcff99  por xmm3, xmm13
00007f582cdcff9e  movaps [r15+0x1D0], xmm3
00007f582cdcffa6  lea rax, [r14+0x40]
00007f582cdcffaa  movups xmm13, [r13+rax*1]
00007f582cdcffb0  movaps [r15+0x2C0], xmm13
00007f582cdcffb8  vmovaps xmm10, [rsp+0x90]
00007f582cdcffc1  vpermilpd xmm10, xmm10, 0x00
00007f582cdcffc7  movaps xmm9, xmm8
00007f582cdcffcb  mulpd xmm9, xmm10
00007f582cdcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007f582cdcffd6  ptest xmm5, xmm5
00007f582cdcffdb  jnz 0x00007F582CDD3946
00007f582cdcffe1  movaps xmm10, xmm1
00007f582cdcffe5  addpd xmm10, xmm11
00007f582cdcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007f582cdcfff0  ptest xmm8, xmm8
00007f582cdcfff6  jnz 0x00007F582CDD3A8A
00007f582cdcfffc  movaps xmm1, xmm14
00007f582cdd0000  addpd xmm1, xmm6
00007f582cdd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007f582cdd0009  ptest xmm11, xmm11
00007f582cdd000f  jnz 0x00007F582CDD3BCD
00007f582cdd0015  vmovaps xmm14, [rsp+0x90]
00007f582cdd001e  vpermilpd xmm14, xmm14, 0x00
00007f582cdd0024  movaps xmm11, xmm13
00007f582cdd0028  mulpd xmm11, xmm14
00007f582cdd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007f582cdd0033  ptest xmm8, xmm8
00007f582cdd0039  jnz 0x00007F582CDD3D0E
00007f582cdd003f  vmovaps xmm14, [rsp+0x90]
00007f582cdd0048  vpermilpd xmm14, xmm14, 0x00
00007f582cdd004e  vmovaps xmm8, [rsp+0x10]
00007f582cdd0054  movaps xmm13, xmm8
00007f582cdd0058  mulpd xmm13, xmm14
00007f582cdd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007f582cdd0063  ptest xmm6, xmm6
00007f582cdd0068  jnz 0x00007F582CDD3E52
00007f582cdd006e  vmovaps xmm14, [rsp+0x60]
00007f582cdd0074  vpermilpd xmm14, xmm14, 0x00
00007f582cdd007a  movaps xmm8, xmm7
00007f582cdd007e  mulpd xmm8, xmm14
00007f582cdd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007f582cdd0089  ptest xmm6, xmm6
00007f582cdd008e  jnz 0x00007F582CDD3F96
00007f582cdd0094  movaps xmm14, xmm12
00007f582cdd0098  addpd xmm14, xmm9
00007f582cdd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007f582cdd00a3  ptest xmm7, xmm7
00007f582cdd00a8  jnz 0x00007F582CDD40D9
00007f582cdd00ae  vmovaps xmm12, [rsp+0x60]
00007f582cdd00b4  vpermilpd xmm12, xmm12, 0x00
00007f582cdd00ba  vmovaps xmm7, [rsp+0xF0]
00007f582cdd00c3  movaps xmm9, xmm7
00007f582cdd00c7  mulpd xmm9, xmm12
00007f582cdd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007f582cdd00d2  ptest xmm6, xmm6
00007f582cdd00d7  jnz 0x00007F582CDD421D
00007f582cdd00dd  movaps xmm12, xmm15
00007f582cdd00e1  addpd xmm12, xmm11
00007f582cdd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007f582cdd00ec  ptest xmm7, xmm7
00007f582cdd00f1  jnz 0x00007F582CDD4360
00007f582cdd00f7  vmovaps xmm15, [rsp+0x60]
00007f582cdd00fd  vpermilpd xmm15, xmm15, 0x00
00007f582cdd0103  vmovaps xmm7, [rsp+0x40]
00007f582cdd0109  movaps xmm11, xmm7
00007f582cdd010d  mulpd xmm11, xmm15
00007f582cdd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007f582cdd0118  ptest xmm6, xmm6
00007f582cdd011d  jnz 0x00007F582CDD44A4
00007f582cdd0123  movaps xmm15, xmm10
00007f582cdd0127  addpd xmm15, xmm13
00007f582cdd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007f582cdd0132  ptest xmm7, xmm7
00007f582cdd0137  jnz 0x00007F582CDD45E7
00007f582cdd013d  vmovaps xmm13, [rsp+0x60]
00007f582cdd0143  vpermilpd xmm13, xmm13, 0x00
00007f582cdd0149  vmovaps xmm7, [rsp+0x50]
00007f582cdd014f  movaps xmm10, xmm7
00007f582cdd0153  mulpd xmm10, xmm13
00007f582cdd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007f582cdd015e  ptest xmm6, xmm6
00007f582cdd0163  jnz 0x00007F582CDD472B
00007f582cdd0169  movaps xmm13, xmm1
00007f582cdd016d  addpd xmm13, xmm8
00007f582cdd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007f582cdd0178  ptest xmm7, xmm7
00007f582cdd017d  jnz 0x00007F582CDD486E
00007f582cdd0183  lea rax, [r14+0x70]
00007f582cdd0187  movups xmm1, [r13+rax*1]
00007f582cdd018d  movaps [r15+0x240], xmm1
00007f582cdd0195  movaps xmm8, xmm14
00007f582cdd0199  addpd xmm8, xmm9
00007f582cdd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007f582cdd01a4  ptest xmm7, xmm7
00007f582cdd01a9  jnz 0x00007F582CDD49BB
00007f582cdd01af  movaps [r15+0x170], xmm8
00007f582cdd01b7  vmovaps xmm14, [rsp+0x70]
00007f582cdd01bd  vpermilpd xmm14, xmm14, 0x00
00007f582cdd01c3  movaps xmm9, xmm1
00007f582cdd01c7  mulpd xmm9, xmm14
00007f582cdd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007f582cdd01d2  ptest xmm7, xmm7
00007f582cdd01d7  jnz 0x00007F582CDD4AFF
00007f582cdd01dd  vmovaps xmm1, [rsp+0x70]
00007f582cdd01e3  vpermilpd xmm1, xmm1, 0x00
00007f582cdd01e9  movaps xmm14, xmm4
00007f582cdd01ed  mulpd xmm14, xmm1
00007f582cdd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007f582cdd01f8  ptest xmm7, xmm7
00007f582cdd01fd  jnz 0x00007F582CDD4C42
00007f582cdd0203  movaps [r15+0x180], xmm14
00007f582cdd020b  movaps xmm1, xmm12
00007f582cdd020f  addpd xmm1, xmm11
00007f582cdd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007f582cdd0219  ptest xmm7, xmm7
00007f582cdd021e  jnz 0x00007F582CDD4D84
00007f582cdd0224  movaps [r15+0x210], xmm1
00007f582cdd022c  movups xmm12, [r13+r14*1]
00007f582cdd0232  lea rax, [r14+0x10]
00007f582cdd0236  movups xmm11, [r13+rax*1]
00007f582cdd023c  movaps [r15+0x230], xmm11
00007f582cdd0244  movaps xmm7, xmm15
00007f582cdd0248  addpd xmm7, xmm10
00007f582cdd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007f582cdd0252  ptest xmm6, xmm6
00007f582cdd0257  jnz 0x00007F582CDD4EDA
00007f582cdd025d  movaps [r15+0x130], xmm7
00007f582cdd0265  vmovaps xmm15, [rsp+0x70]
00007f582cdd026b  vpermilpd xmm15, xmm15, 0x00
00007f582cdd0271  movaps xmm10, xmm11
00007f582cdd0275  mulpd xmm10, xmm15
00007f582cdd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007f582cdd0280  ptest xmm6, xmm6
00007f582cdd0285  jnz 0x00007F582CDD501C
00007f582cdd028b  movaps [r15+0x220], xmm10
00007f582cdd0293  vmovaps xmm15, [rsp+0x70]
00007f582cdd0299  vpermilpd xmm15, xmm15, 0x00
00007f582cdd029f  movaps xmm11, xmm12
00007f582cdd02a3  mulpd xmm11, xmm15
00007f582cdd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007f582cdd02ae  ptest xmm6, xmm6
00007f582cdd02b3  jnz 0x00007F582CDD5160
00007f582cdd02b9  movaps xmm15, xmm13
00007f582cdd02bd  addpd xmm15, xmm9
00007f582cdd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007f582cdd02c8  ptest xmm12, xmm12
00007f582cdd02ce  jnz 0x00007F582CDD52A4
00007f582cdd02d4  movaps [r15+0x140], xmm15
00007f582cdd02dc  movaps xmm13, xmm8
00007f582cdd02e0  addpd xmm13, xmm14
00007f582cdd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007f582cdd02eb  ptest xmm12, xmm12
00007f582cdd02f1  jnz 0x00007F582CDD53E8
00007f582cdd02f7  movaps [r15+0x150], xmm13
00007f582cdd02ff  movaps xmm14, xmm1
00007f582cdd0303  addpd xmm14, xmm10
00007f582cdd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007f582cdd030e  ptest xmm12, xmm12
00007f582cdd0314  jnz 0x00007F582CDD552C
00007f582cdd031a  movaps [r15+0x160], xmm14
00007f582cdd0322  movaps xmm1, xmm7
00007f582cdd0325  addpd xmm1, xmm11
00007f582cdd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007f582cdd032f  ptest xmm12, xmm12
00007f582cdd0335  jnz 0x00007F582CDD566F
00007f582cdd033b  movaps [r15+0x120], xmm1
00007f582cdd0343  mov eax, 0x430920
00007f582cdd0348  movups [r13+rax*1], xmm15
00007f582cdd034e  mov eax, 0x430930
00007f582cdd0353  movups [r13+rax*1], xmm13
00007f582cdd0359  mov eax, 0x430940
00007f582cdd035e  movups [r13+rax*1], xmm14
00007f582cdd0364  mov eax, 0x430950
00007f582cdd0369  movups [r13+rax*1], xmm1
00007f582cdd036f  mov eax, [r15+0x108]
00007f582cdd0376  sahf
00007f582cdd0377  jnz 0x00007F582CDD03A9
00007f582cdd0379  cmp dword ptr [r15+0x318], 0x00
00007f582cdd0381  jz 0x00007F582CDDB900
00007f582cdd0387  nop [rax+rax*1], ax
00007f582cdd0390  nop [rax+rax*1], eax
00007f582cdd0398  mov eax, 0x410444
00007f582cdd039d  mov [r15+0x100], rax
00007f582cdd03a4  jmp 0x00007F582CBFE110
00007f582cdd03a9  cmp dword ptr [r15+0x318], 0x00
00007f582cdd03b1  jz 0x00007F582CDD57E0
00007f582cdd03b7  nop [rax+rax*1], ax
00007f582cdd03c0  nop [rax+rax*1], eax
00007f582cdd03c8  mov eax, 0x410278
00007f582cdd03cd  mov [r15+0x100], rax
00007f582cdd03d4  jmp 0x00007F582CBFE110
00007f582cdd03d9  int3
00007f582cdd03da  call 0x00007F582CCB52F0
00007f582cdd03df  jmp 0x00007F582CDCF016
00007f582cdd03e4  call 0x00007F582CCC4620
00007f582cdd03e9  jmp 0x00007F582CDCF023
00007f582cdd03ee  call 0x00007F582CCC33A0
00007f582cdd03f3  jmp 0x00007F582CDCF035
00007f582cdd03f8  call 0x00007F582CCC2120
00007f582cdd03fd  jmp 0x00007F582CDCF03F
00007f582cdd0402  call 0x00007F582CCC0860
00007f582cdd0407  jmp 0x00007F582CDCF067
00007f582cdd040c  call 0x00007F582CCBF5F0
00007f582cdd0411  jmp 0x00007F582CDCF073
00007f582cdd0416  call 0x00007F582CCC0860
00007f582cdd041b  jmp 0x00007F582CDCF0A5
00007f582cdd0420  call 0x00007F582CCBF5F0
00007f582cdd0425  jmp 0x00007F582CDCF0B1
00007f582cdd042a  call 0x00007F582CCC4740
00007f582cdd042f  jmp 0x00007F582CDCF0BE
00007f582cdd0434  call 0x00007F582CCB5400
00007f582cdd0439  jmp 0x00007F582CDCF0CB
00007f582cdd043e  call 0x00007F582CCB52F0
00007f582cdd0443  jmp 0x00007F582CDCF0D8
00007f582cdd0448  call 0x00007F582CCC4620
00007f582cdd044d  jmp 0x00007F582CDCF0E5
00007f582cdd0452  call 0x00007F582CCC0860
00007f582cdd0457  jmp 0x00007F582CDCF10D
00007f582cdd045c  call 0x00007F582CCBF5F0
00007f582cdd0461  jmp 0x00007F582CDCF119
00007f582cdd0466  call 0x00007F582CC09D70
00007f582cdd046b  jmp 0x00007F582CDCF11F
00007f582cdd0470  call 0x00007F582CCBE9C0
00007f582cdd0475  jmp 0x00007F582CDCF129
00007f582cdd047a  call 0x00007F582CCC0860
00007f582cdd047f  jmp 0x00007F582CDCF151
00007f582cdd0484  call 0x00007F582CCBF5F0
00007f582cdd0489  jmp 0x00007F582CDCF15D
00007f582cdd048e  call 0x00007F582CCBD750
00007f582cdd0493  jmp 0x00007F582CDCF16A
00007f582cdd0498  call 0x00007F582CCBC4E0
00007f582cdd049d  jmp 0x00007F582CDCF177
00007f582cdd04a2  call 0x00007F582CCC4740
00007f582cdd04a7  jmp 0x00007F582CDCF184
00007f582cdd04ac  call 0x00007F582CCB5400
00007f582cdd04b1  jmp 0x00007F582CDCF191
00007f582cdd04b6  call 0x00007F582CCB52F0
00007f582cdd04bb  jmp 0x00007F582CDCF19E
00007f582cdd04c0  call 0x00007F582CCC4620
00007f582cdd04c5  jmp 0x00007F582CDCF1AB
00007f582cdd04ca  call 0x00007F582CCC0860
00007f582cdd04cf  jmp 0x00007F582CDCF1BE
00007f582cdd04d4  call 0x00007F582CCBB270
00007f582cdd04d9  jmp 0x00007F582CDCF1CB
00007f582cdd04de  call 0x00007F582CCBA000
00007f582cdd04e3  jmp 0x00007F582CDCF1D8
00007f582cdd04e8  call 0x00007F582CCB8D90
00007f582cdd04ed  jmp 0x00007F582CDCF1E5
00007f582cdd04f2  call 0x00007F582CCB8A20
00007f582cdd04f7  jmp 0x00007F582CDCF1F2
00007f582cdd04fc  call 0x00007F582CCB5400
00007f582cdd0501  jmp 0x00007F582CDCF1FC
00007f582cdd0506  call 0x00007F582CCC2240
00007f582cdd050b  jmp 0x00007F582CDCF206
00007f582cdd0510  call 0x00007F582CCB52F0
00007f582cdd0515  jmp 0x00007F582CDCF210
00007f582cdd051a  call 0x00007F582CCC2120
00007f582cdd051f  jmp 0x00007F582CDCF21A
00007f582cdd0524  call 0x00007F582CCB77B0
00007f582cdd0529  jmp 0x00007F582CDCF224
00007f582cdd052e  call 0x00007F582CCB6550
00007f582cdd0533  jmp 0x00007F582CDCF22E
00007f582cdd0538  call 0x00007F582CCBFD50
00007f582cdd053d  jmp 0x00007F582CDCF240
00007f582cdd0542  call 0x00007F582CCB8EA0
00007f582cdd0547  jmp 0x00007F582CDCF24A
00007f582cdd054c  call 0x00007F582CCBFC30
00007f582cdd0551  jmp 0x00007F582CDCF257
00007f582cdd0556  call 0x00007F582CCB8D90
00007f582cdd055b  jmp 0x00007F582CDCF264
00007f582cdd0560  call 0x00007F582CCC2240
00007f582cdd0565  jmp 0x00007F582CDCF271
00007f582cdd056a  call 0x00007F582CCB5400
00007f582cdd056f  jmp 0x00007F582CDCF27E
00007f582cdd0574  call 0x00007F582CCB52F0
00007f582cdd0579  jmp 0x00007F582CDCF28B
00007f582cdd057e  call 0x00007F582CCC2120
00007f582cdd0583  jmp 0x00007F582CDCF298
00007f582cdd0588  call 0x00007F582CCB52F0
00007f582cdd058d  jmp 0x00007F582CDCF2AB
00007f582cdd0592  call 0x00007F582CCB52F0
00007f582cdd0597  jmp 0x00007F582CDCF2BE
00007f582cdd059c  call 0x00007F582CCB52F0
00007f582cdd05a1  jmp 0x00007F582CDCF2D1
00007f582cdd05a6  call 0x00007F582CCB52F0
00007f582cdd05ab  jmp 0x00007F582CDCF2E4
00007f582cdd05b0  call 0x00007F582CCC2240
00007f582cdd05b5  jmp 0x00007F582CDCF2F9
00007f582cdd05ba  call 0x00007F582CCC2240
00007f582cdd05bf  jmp 0x00007F582CDCF30C
00007f582cdd05c4  call 0x00007F582CCC2120
00007f582cdd05c9  jmp 0x00007F582CDCF319
00007f582cdd05ce  call 0x00007F582CCB52F0
00007f582cdd05d3  jmp 0x00007F582CDCF32C
00007f582cdd05d8  call 0x00007F582CCB52F0
00007f582cdd05dd  jmp 0x00007F582CDCF34F
00007f582cdd05e2  call 0x00007F582CCB52F0
00007f582cdd05e7  jmp 0x00007F582CDCF362
00007f582cdd05ec  call 0x00007F582CBFF540
00007f582cdd05f1  jmp 0x00007F582CDCF380
00007f582cdd05f6  call 0x00007F582CC08C20
00007f582cdd05fb  jmp 0x00007F582CDCF38A
00007f582cdd0600  call 0x00007F582CCD6600
00007f582cdd0605  jmp 0x00007F582CDCF396
00007f582cdd060a  call 0x00007F582CBFF540
00007f582cdd060f  jmp 0x00007F582CDCF3A6
00007f582cdd0614  call 0x00007F582CCC0370
00007f582cdd0619  jmp 0x00007F582CDCF3D4
00007f582cdd061e  call 0x00007F582CCBF100
00007f582cdd0623  jmp 0x00007F582CDCF3DD
00007f582cdd0628  call 0x00007F582CCC0370
00007f582cdd062d  jmp 0x00007F582CDCF43B
00007f582cdd0632  call 0x00007F582CCBF100
00007f582cdd0637  jmp 0x00007F582CDCF444
00007f582cdd063c  call 0x00007F582CCC0370
00007f582cdd0641  jmp 0x00007F582CDCF48B
00007f582cdd0646  call 0x00007F582CCBF100
00007f582cdd064b  jmp 0x00007F582CDCF494
00007f582cdd0650  call 0x00007F582CC0B720
00007f582cdd0655  jmp 0x00007F582CDCF4D7
00007f582cdd065a  call 0x00007F582CCB47C0
00007f582cdd065f  jmp 0x00007F582CDCF4EA
00007f582cdd0664  call 0x00007F582CC08B00
00007f582cdd0669  jmp 0x00007F582CDCF501
00007f582cdd066e  call 0x00007F582CBFF430
00007f582cdd0673  jmp 0x00007F582CDCF514
00007f582cdd0678  call 0x00007F582CBFF430
00007f582cdd067d  jmp 0x00007F582CDCF527
00007f582cdd0682  sub rsp, 0x08
00007f582cdd0686  push rax
00007f582cdd0687  push rcx
00007f582cdd0688  push rdx
00007f582cdd0689  push rdi
00007f582cdd068a  push rsi
00007f582cdd068b  push r8
00007f582cdd068d  push r9
00007f582cdd068f  push r10
00007f582cdd0691  push r11
00007f582cdd0693  sub rsp, 0xF0
00007f582cdd069a  vmovaps [rsp], xmm0
00007f582cdd069f  vmovaps [rsp+0x10], xmm2
00007f582cdd06a5  vmovaps [rsp+0x20], xmm3
00007f582cdd06ab  vmovaps [rsp+0x30], xmm4
00007f582cdd06b1  vmovaps [rsp+0x40], xmm5
00007f582cdd06b7  vmovaps [rsp+0x50], xmm6
00007f582cdd06bd  vmovaps [rsp+0x60], xmm7
00007f582cdd06c3  vmovaps [rsp+0x70], xmm8
00007f582cdd06c9  vmovaps [rsp+0x80], xmm9
00007f582cdd06d2  vmovaps [rsp+0x90], xmm10
00007f582cdd06db  vmovaps [rsp+0xA0], xmm11
00007f582cdd06e4  vmovaps [rsp+0xB0], xmm12
00007f582cdd06ed  vmovaps [rsp+0xC0], xmm13
00007f582cdd06f6  vmovaps [rsp+0xD0], xmm14
00007f582cdd06ff  vmovaps [rsp+0xE0], xmm15
00007f582cdd0708  sub rsp, 0x30
00007f582cdd070c  movaps [rsp], xmm1
00007f582cdd0710  movaps [rsp+0x10], xmm15
00007f582cdd0716  movaps [rsp+0x20], xmm14
00007f582cdd071c  lea rdi, [rsp]
00007f582cdd0720  mov esi, 0x00
00007f582cdd0725  mov rax, 0x653B0D9BF530
00007f582cdd072f  call rax
00007f582cdd0731  movaps xmm1, [rsp]
00007f582cdd0735  add rsp, 0x30
00007f582cdd0739  vmovaps xmm0, [rsp]
00007f582cdd073e  vmovaps xmm2, [rsp+0x10]
00007f582cdd0744  vmovaps xmm3, [rsp+0x20]
00007f582cdd074a  vmovaps xmm4, [rsp+0x30]
00007f582cdd0750  vmovaps xmm5, [rsp+0x40]
00007f582cdd0756  vmovaps xmm6, [rsp+0x50]
00007f582cdd075c  vmovaps xmm7, [rsp+0x60]
00007f582cdd0762  vmovaps xmm8, [rsp+0x70]
00007f582cdd0768  vmovaps xmm9, [rsp+0x80]
00007f582cdd0771  vmovaps xmm10, [rsp+0x90]
00007f582cdd077a  vmovaps xmm11, [rsp+0xA0]
00007f582cdd0783  vmovaps xmm12, [rsp+0xB0]
00007f582cdd078c  vmovaps xmm13, [rsp+0xC0]
00007f582cdd0795  vmovaps xmm14, [rsp+0xD0]
00007f582cdd079e  vmovaps xmm15, [rsp+0xE0]
00007f582cdd07a7  add rsp, 0xF0
00007f582cdd07ae  pop r11
00007f582cdd07b0  pop r10
00007f582cdd07b2  pop r9
00007f582cdd07b4  pop r8
00007f582cdd07b6  pop rsi
00007f582cdd07b7  pop rdi
00007f582cdd07b8  pop rdx
00007f582cdd07b9  pop rcx
00007f582cdd07ba  pop rax
00007f582cdd07bb  add rsp, 0x08
00007f582cdd07bf  jmp 0x00007F582CDCF581
00007f582cdd07c4  sub rsp, 0x08
00007f582cdd07c8  push rax
00007f582cdd07c9  push rcx
00007f582cdd07ca  push rdx
00007f582cdd07cb  push rdi
00007f582cdd07cc  push rsi
00007f582cdd07cd  push r8
00007f582cdd07cf  push r9
00007f582cdd07d1  push r10
00007f582cdd07d3  push r11
00007f582cdd07d5  sub rsp, 0xF0
00007f582cdd07dc  vmovaps [rsp], xmm0
00007f582cdd07e1  vmovaps [rsp+0x10], xmm1
00007f582cdd07e7  vmovaps [rsp+0x20], xmm2
00007f582cdd07ed  vmovaps [rsp+0x30], xmm3
00007f582cdd07f3  vmovaps [rsp+0x40], xmm4
00007f582cdd07f9  vmovaps [rsp+0x50], xmm5
00007f582cdd07ff  vmovaps [rsp+0x60], xmm6
00007f582cdd0805  vmovaps [rsp+0x70], xmm7
00007f582cdd080b  vmovaps [rsp+0x80], xmm8
00007f582cdd0814  vmovaps [rsp+0x90], xmm9
00007f582cdd081d  vmovaps [rsp+0xA0], xmm10
00007f582cdd0826  vmovaps [rsp+0xB0], xmm11
00007f582cdd082f  vmovaps [rsp+0xC0], xmm12
00007f582cdd0838  vmovaps [rsp+0xD0], xmm14
00007f582cdd0841  vmovaps [rsp+0xE0], xmm15
00007f582cdd084a  sub rsp, 0x30
00007f582cdd084e  movaps [rsp], xmm13
00007f582cdd0853  movaps [rsp+0x10], xmm1
00007f582cdd0858  movaps [rsp+0x20], xmm14
00007f582cdd085e  lea rdi, [rsp]
00007f582cdd0862  mov esi, 0x00
00007f582cdd0867  mov rax, 0x653B0D9BF530
00007f582cdd0871  call rax
00007f582cdd0873  movaps xmm13, [rsp]
00007f582cdd0878  add rsp, 0x30
00007f582cdd087c  vmovaps xmm0, [rsp]
00007f582cdd0881  vmovaps xmm1, [rsp+0x10]
00007f582cdd0887  vmovaps xmm2, [rsp+0x20]
00007f582cdd088d  vmovaps xmm3, [rsp+0x30]
00007f582cdd0893  vmovaps xmm4, [rsp+0x40]
00007f582cdd0899  vmovaps xmm5, [rsp+0x50]
00007f582cdd089f  vmovaps xmm6, [rsp+0x60]
00007f582cdd08a5  vmovaps xmm7, [rsp+0x70]
00007f582cdd08ab  vmovaps xmm8, [rsp+0x80]
00007f582cdd08b4  vmovaps xmm9, [rsp+0x90]
00007f582cdd08bd  vmovaps xmm10, [rsp+0xA0]
00007f582cdd08c6  vmovaps xmm11, [rsp+0xB0]
00007f582cdd08cf  vmovaps xmm12, [rsp+0xC0]
00007f582cdd08d8  vmovaps xmm14, [rsp+0xD0]
00007f582cdd08e1  vmovaps xmm15, [rsp+0xE0]
00007f582cdd08ea  add rsp, 0xF0
00007f582cdd08f1  pop r11
00007f582cdd08f3  pop r10
00007f582cdd08f5  pop r9
00007f582cdd08f7  pop r8
00007f582cdd08f9  pop rsi
00007f582cdd08fa  pop rdi
00007f582cdd08fb  pop rdx
00007f582cdd08fc  pop rcx
00007f582cdd08fd  pop rax
00007f582cdd08fe  add rsp, 0x08
00007f582cdd0902  jmp 0x00007F582CDCF5CF
00007f582cdd0907  sub rsp, 0x08
00007f582cdd090b  push rax
00007f582cdd090c  push rcx
00007f582cdd090d  push rdx
00007f582cdd090e  push rdi
00007f582cdd090f  push rsi
00007f582cdd0910  push r8
00007f582cdd0912  push r9
00007f582cdd0914  push r10
00007f582cdd0916  push r11
00007f582cdd0918  sub rsp, 0xF0
00007f582cdd091f  vmovaps [rsp], xmm0
00007f582cdd0924  vmovaps [rsp+0x10], xmm1
00007f582cdd092a  vmovaps [rsp+0x20], xmm2
00007f582cdd0930  vmovaps [rsp+0x30], xmm3
00007f582cdd0936  vmovaps [rsp+0x40], xmm4
00007f582cdd093c  vmovaps [rsp+0x50], xmm5
00007f582cdd0942  vmovaps [rsp+0x60], xmm6
00007f582cdd0948  vmovaps [rsp+0x70], xmm7
00007f582cdd094e  vmovaps [rsp+0x80], xmm8
00007f582cdd0957  vmovaps [rsp+0x90], xmm9
00007f582cdd0960  vmovaps [rsp+0xA0], xmm10
00007f582cdd0969  vmovaps [rsp+0xB0], xmm11
00007f582cdd0972  vmovaps [rsp+0xC0], xmm12
00007f582cdd097b  vmovaps [rsp+0xD0], xmm13
00007f582cdd0984  vmovaps [rsp+0xE0], xmm14
00007f582cdd098d  sub rsp, 0x30
00007f582cdd0991  movaps [rsp], xmm15
00007f582cdd0996  movaps [rsp+0x10], xmm14
00007f582cdd099c  movaps [rsp+0x20], xmm1
00007f582cdd09a1  lea rdi, [rsp]
00007f582cdd09a5  mov esi, 0x00
00007f582cdd09aa  mov rax, 0x653B0D9BF530
00007f582cdd09b4  call rax
00007f582cdd09b6  movaps xmm15, [rsp]
00007f582cdd09bb  add rsp, 0x30
00007f582cdd09bf  vmovaps xmm0, [rsp]
00007f582cdd09c4  vmovaps xmm1, [rsp+0x10]
00007f582cdd09ca  vmovaps xmm2, [rsp+0x20]
00007f582cdd09d0  vmovaps xmm3, [rsp+0x30]
00007f582cdd09d6  vmovaps xmm4, [rsp+0x40]
00007f582cdd09dc  vmovaps xmm5, [rsp+0x50]
00007f582cdd09e2  vmovaps xmm6, [rsp+0x60]
00007f582cdd09e8  vmovaps xmm7, [rsp+0x70]
00007f582cdd09ee  vmovaps xmm8, [rsp+0x80]
00007f582cdd09f7  vmovaps xmm9, [rsp+0x90]
00007f582cdd0a00  vmovaps xmm10, [rsp+0xA0]
00007f582cdd0a09  vmovaps xmm11, [rsp+0xB0]
00007f582cdd0a12  vmovaps xmm12, [rsp+0xC0]
00007f582cdd0a1b  vmovaps xmm13, [rsp+0xD0]
00007f582cdd0a24  vmovaps xmm14, [rsp+0xE0]
00007f582cdd0a2d  add rsp, 0xF0
00007f582cdd0a34  pop r11
00007f582cdd0a36  pop r10
00007f582cdd0a38  pop r9
00007f582cdd0a3a  pop r8
00007f582cdd0a3c  pop rsi
00007f582cdd0a3d  pop rdi
00007f582cdd0a3e  pop rdx
00007f582cdd0a3f  pop rcx
00007f582cdd0a40  pop rax
00007f582cdd0a41  add rsp, 0x08
00007f582cdd0a45  jmp 0x00007F582CDCF617
00007f582cdd0a4a  sub rsp, 0x08
00007f582cdd0a4e  push rax
00007f582cdd0a4f  push rcx
00007f582cdd0a50  push rdx
00007f582cdd0a51  push rdi
00007f582cdd0a52  push rsi
00007f582cdd0a53  push r8
00007f582cdd0a55  push r9
00007f582cdd0a57  push r10
00007f582cdd0a59  push r11
00007f582cdd0a5b  sub rsp, 0xF0
00007f582cdd0a62  vmovaps [rsp], xmm0
00007f582cdd0a67  vmovaps [rsp+0x10], xmm2
00007f582cdd0a6d  vmovaps [rsp+0x20], xmm3
00007f582cdd0a73  vmovaps [rsp+0x30], xmm4
00007f582cdd0a79  vmovaps [rsp+0x40], xmm5
00007f582cdd0a7f  vmovaps [rsp+0x50], xmm6
00007f582cdd0a85  vmovaps [rsp+0x60], xmm7
00007f582cdd0a8b  vmovaps [rsp+0x70], xmm8
00007f582cdd0a91  vmovaps [rsp+0x80], xmm9
00007f582cdd0a9a  vmovaps [rsp+0x90], xmm10
00007f582cdd0aa3  vmovaps [rsp+0xA0], xmm11
00007f582cdd0aac  vmovaps [rsp+0xB0], xmm12
00007f582cdd0ab5  vmovaps [rsp+0xC0], xmm13
00007f582cdd0abe  vmovaps [rsp+0xD0], xmm14
00007f582cdd0ac7  vmovaps [rsp+0xE0], xmm15
00007f582cdd0ad0  sub rsp, 0x30
00007f582cdd0ad4  movaps [rsp], xmm1
00007f582cdd0ad8  movaps [rsp+0x10], xmm14
00007f582cdd0ade  movaps [rsp+0x20], xmm10
00007f582cdd0ae4  lea rdi, [rsp]
00007f582cdd0ae8  mov esi, 0x00
00007f582cdd0aed  mov rax, 0x653B0D9BF530
00007f582cdd0af7  call rax
00007f582cdd0af9  movaps xmm1, [rsp]
00007f582cdd0afd  add rsp, 0x30
00007f582cdd0b01  vmovaps xmm0, [rsp]
00007f582cdd0b06  vmovaps xmm2, [rsp+0x10]
00007f582cdd0b0c  vmovaps xmm3, [rsp+0x20]
00007f582cdd0b12  vmovaps xmm4, [rsp+0x30]
00007f582cdd0b18  vmovaps xmm5, [rsp+0x40]
00007f582cdd0b1e  vmovaps xmm6, [rsp+0x50]
00007f582cdd0b24  vmovaps xmm7, [rsp+0x60]
00007f582cdd0b2a  vmovaps xmm8, [rsp+0x70]
00007f582cdd0b30  vmovaps xmm9, [rsp+0x80]
00007f582cdd0b39  vmovaps xmm10, [rsp+0x90]
00007f582cdd0b42  vmovaps xmm11, [rsp+0xA0]
00007f582cdd0b4b  vmovaps xmm12, [rsp+0xB0]
00007f582cdd0b54  vmovaps xmm13, [rsp+0xC0]
00007f582cdd0b5d  vmovaps xmm14, [rsp+0xD0]
00007f582cdd0b66  vmovaps xmm15, [rsp+0xE0]
00007f582cdd0b6f  add rsp, 0xF0
00007f582cdd0b76  pop r11
00007f582cdd0b78  pop r10
00007f582cdd0b7a  pop r9
00007f582cdd0b7c  pop r8
00007f582cdd0b7e  pop rsi
00007f582cdd0b7f  pop rdi
00007f582cdd0b80  pop rdx
00007f582cdd0b81  pop rcx
00007f582cdd0b82  pop rax
00007f582cdd0b83  add rsp, 0x08
00007f582cdd0b87  jmp 0x00007F582CDCF631
00007f582cdd0b8c  sub rsp, 0x08
00007f582cdd0b90  push rax
00007f582cdd0b91  push rcx
00007f582cdd0b92  push rdx
00007f582cdd0b93  push rdi
00007f582cdd0b94  push rsi
00007f582cdd0b95  push r8
00007f582cdd0b97  push r9
00007f582cdd0b99  push r10
00007f582cdd0b9b  push r11
00007f582cdd0b9d  sub rsp, 0xF0
00007f582cdd0ba4  vmovaps [rsp], xmm0
00007f582cdd0ba9  vmovaps [rsp+0x10], xmm1
00007f582cdd0baf  vmovaps [rsp+0x20], xmm2
00007f582cdd0bb5  vmovaps [rsp+0x30], xmm3
00007f582cdd0bbb  vmovaps [rsp+0x40], xmm4
00007f582cdd0bc1  vmovaps [rsp+0x50], xmm5
00007f582cdd0bc7  vmovaps [rsp+0x60], xmm6
00007f582cdd0bcd  vmovaps [rsp+0x70], xmm7
00007f582cdd0bd3  vmovaps [rsp+0x80], xmm8
00007f582cdd0bdc  vmovaps [rsp+0x90], xmm9
00007f582cdd0be5  vmovaps [rsp+0xA0], xmm10
00007f582cdd0bee  vmovaps [rsp+0xB0], xmm11
00007f582cdd0bf7  vmovaps [rsp+0xC0], xmm12
00007f582cdd0c00  vmovaps [rsp+0xD0], xmm14
00007f582cdd0c09  vmovaps [rsp+0xE0], xmm15
00007f582cdd0c12  sub rsp, 0x30
00007f582cdd0c16  movaps [rsp], xmm13
00007f582cdd0c1b  movaps [rsp+0x10], xmm14
00007f582cdd0c21  movaps [rsp+0x20], xmm2
00007f582cdd0c26  lea rdi, [rsp]
00007f582cdd0c2a  mov esi, 0x00
00007f582cdd0c2f  mov rax, 0x653B0D9BF530
00007f582cdd0c39  call rax
00007f582cdd0c3b  movaps xmm13, [rsp]
00007f582cdd0c40  add rsp, 0x30
00007f582cdd0c44  vmovaps xmm0, [rsp]
00007f582cdd0c49  vmovaps xmm1, [rsp+0x10]
00007f582cdd0c4f  vmovaps xmm2, [rsp+0x20]
00007f582cdd0c55  vmovaps xmm3, [rsp+0x30]
00007f582cdd0c5b  vmovaps xmm4, [rsp+0x40]
00007f582cdd0c61  vmovaps xmm5, [rsp+0x50]
00007f582cdd0c67  vmovaps xmm6, [rsp+0x60]
00007f582cdd0c6d  vmovaps xmm7, [rsp+0x70]
00007f582cdd0c73  vmovaps xmm8, [rsp+0x80]
00007f582cdd0c7c  vmovaps xmm9, [rsp+0x90]
00007f582cdd0c85  vmovaps xmm10, [rsp+0xA0]
00007f582cdd0c8e  vmovaps xmm11, [rsp+0xB0]
00007f582cdd0c97  vmovaps xmm12, [rsp+0xC0]
00007f582cdd0ca0  vmovaps xmm14, [rsp+0xD0]
00007f582cdd0ca9  vmovaps xmm15, [rsp+0xE0]
00007f582cdd0cb2  add rsp, 0xF0
00007f582cdd0cb9  pop r11
00007f582cdd0cbb  pop r10
00007f582cdd0cbd  pop r9
00007f582cdd0cbf  pop r8
00007f582cdd0cc1  pop rsi
00007f582cdd0cc2  pop rdi
00007f582cdd0cc3  pop rdx
00007f582cdd0cc4  pop rcx
00007f582cdd0cc5  pop rax
00007f582cdd0cc6  add rsp, 0x08
00007f582cdd0cca  jmp 0x00007F582CDCF64C
00007f582cdd0ccf  sub rsp, 0x08
00007f582cdd0cd3  push rax
00007f582cdd0cd4  push rcx
00007f582cdd0cd5  push rdx
00007f582cdd0cd6  push rdi
00007f582cdd0cd7  push rsi
00007f582cdd0cd8  push r8
00007f582cdd0cda  push r9
00007f582cdd0cdc  push r10
00007f582cdd0cde  push r11
00007f582cdd0ce0  sub rsp, 0xF0
00007f582cdd0ce7  vmovaps [rsp], xmm0
00007f582cdd0cec  vmovaps [rsp+0x10], xmm2
00007f582cdd0cf2  vmovaps [rsp+0x20], xmm3
00007f582cdd0cf8  vmovaps [rsp+0x30], xmm4
00007f582cdd0cfe  vmovaps [rsp+0x40], xmm5
00007f582cdd0d04  vmovaps [rsp+0x50], xmm6
00007f582cdd0d0a  vmovaps [rsp+0x60], xmm7
00007f582cdd0d10  vmovaps [rsp+0x70], xmm8
00007f582cdd0d16  vmovaps [rsp+0x80], xmm9
00007f582cdd0d1f  vmovaps [rsp+0x90], xmm10
00007f582cdd0d28  vmovaps [rsp+0xA0], xmm11
00007f582cdd0d31  vmovaps [rsp+0xB0], xmm12
00007f582cdd0d3a  vmovaps [rsp+0xC0], xmm13
00007f582cdd0d43  vmovaps [rsp+0xD0], xmm14
00007f582cdd0d4c  vmovaps [rsp+0xE0], xmm15
00007f582cdd0d55  sub rsp, 0x30
00007f582cdd0d59  movaps [rsp], xmm1
00007f582cdd0d5d  movaps [rsp+0x10], xmm10
00007f582cdd0d63  movaps [rsp+0x20], xmm2
00007f582cdd0d68  lea rdi, [rsp]
00007f582cdd0d6c  mov esi, 0x00
00007f582cdd0d71  mov rax, 0x653B0D9BF530
00007f582cdd0d7b  call rax
00007f582cdd0d7d  movaps xmm1, [rsp]
00007f582cdd0d81  add rsp, 0x30
00007f582cdd0d85  vmovaps xmm0, [rsp]
00007f582cdd0d8a  vmovaps xmm2, [rsp+0x10]
00007f582cdd0d90  vmovaps xmm3, [rsp+0x20]
00007f582cdd0d96  vmovaps xmm4, [rsp+0x30]
00007f582cdd0d9c  vmovaps xmm5, [rsp+0x40]
00007f582cdd0da2  vmovaps xmm6, [rsp+0x50]
00007f582cdd0da8  vmovaps xmm7, [rsp+0x60]
00007f582cdd0dae  vmovaps xmm8, [rsp+0x70]
00007f582cdd0db4  vmovaps xmm9, [rsp+0x80]
00007f582cdd0dbd  vmovaps xmm10, [rsp+0x90]
00007f582cdd0dc6  vmovaps xmm11, [rsp+0xA0]
00007f582cdd0dcf  vmovaps xmm12, [rsp+0xB0]
00007f582cdd0dd8  vmovaps xmm13, [rsp+0xC0]
00007f582cdd0de1  vmovaps xmm14, [rsp+0xD0]
00007f582cdd0dea  vmovaps xmm15, [rsp+0xE0]
00007f582cdd0df3  add rsp, 0xF0
00007f582cdd0dfa  pop r11
00007f582cdd0dfc  pop r10
00007f582cdd0dfe  pop r9
00007f582cdd0e00  pop r8
00007f582cdd0e02  pop rsi
00007f582cdd0e03  pop rdi
00007f582cdd0e04  pop rdx
00007f582cdd0e05  pop rcx
00007f582cdd0e06  pop rax
00007f582cdd0e07  add rsp, 0x08
00007f582cdd0e0b  jmp 0x00007F582CDCF6B4
00007f582cdd0e10  sub rsp, 0x08
00007f582cdd0e14  push rax
00007f582cdd0e15  push rcx
00007f582cdd0e16  push rdx
00007f582cdd0e17  push rdi
00007f582cdd0e18  push rsi
00007f582cdd0e19  push r8
00007f582cdd0e1b  push r9
00007f582cdd0e1d  push r10
00007f582cdd0e1f  push r11
00007f582cdd0e21  sub rsp, 0xF0
00007f582cdd0e28  vmovaps [rsp], xmm0
00007f582cdd0e2d  vmovaps [rsp+0x10], xmm1
00007f582cdd0e33  vmovaps [rsp+0x20], xmm2
00007f582cdd0e39  vmovaps [rsp+0x30], xmm3
00007f582cdd0e3f  vmovaps [rsp+0x40], xmm4
00007f582cdd0e45  vmovaps [rsp+0x50], xmm5
00007f582cdd0e4b  vmovaps [rsp+0x60], xmm6
00007f582cdd0e51  vmovaps [rsp+0x70], xmm7
00007f582cdd0e57  vmovaps [rsp+0x80], xmm8
00007f582cdd0e60  vmovaps [rsp+0x90], xmm9
00007f582cdd0e69  vmovaps [rsp+0xA0], xmm10
00007f582cdd0e72  vmovaps [rsp+0xB0], xmm11
00007f582cdd0e7b  vmovaps [rsp+0xC0], xmm12
00007f582cdd0e84  vmovaps [rsp+0xD0], xmm13
00007f582cdd0e8d  vmovaps [rsp+0xE0], xmm14
00007f582cdd0e96  sub rsp, 0x30
00007f582cdd0e9a  movaps [rsp], xmm15
00007f582cdd0e9f  movaps [rsp+0x10], xmm10
00007f582cdd0ea5  movaps [rsp+0x20], xmm2
00007f582cdd0eaa  lea rdi, [rsp]
00007f582cdd0eae  mov esi, 0x00
00007f582cdd0eb3  mov rax, 0x653B0D9BF530
00007f582cdd0ebd  call rax
00007f582cdd0ebf  movaps xmm15, [rsp]
00007f582cdd0ec4  add rsp, 0x30
00007f582cdd0ec8  vmovaps xmm0, [rsp]
00007f582cdd0ecd  vmovaps xmm1, [rsp+0x10]
00007f582cdd0ed3  vmovaps xmm2, [rsp+0x20]
00007f582cdd0ed9  vmovaps xmm3, [rsp+0x30]
00007f582cdd0edf  vmovaps xmm4, [rsp+0x40]
00007f582cdd0ee5  vmovaps xmm5, [rsp+0x50]
00007f582cdd0eeb  vmovaps xmm6, [rsp+0x60]
00007f582cdd0ef1  vmovaps xmm7, [rsp+0x70]
00007f582cdd0ef7  vmovaps xmm8, [rsp+0x80]
00007f582cdd0f00  vmovaps xmm9, [rsp+0x90]
00007f582cdd0f09  vmovaps xmm10, [rsp+0xA0]
00007f582cdd0f12  vmovaps xmm11, [rsp+0xB0]
00007f582cdd0f1b  vmovaps xmm12, [rsp+0xC0]
00007f582cdd0f24  vmovaps xmm13, [rsp+0xD0]
00007f582cdd0f2d  vmovaps xmm14, [rsp+0xE0]
00007f582cdd0f36  add rsp, 0xF0
00007f582cdd0f3d  pop r11
00007f582cdd0f3f  pop r10
00007f582cdd0f41  pop r9
00007f582cdd0f43  pop r8
00007f582cdd0f45  pop rsi
00007f582cdd0f46  pop rdi
00007f582cdd0f47  pop rdx
00007f582cdd0f48  pop rcx
00007f582cdd0f49  pop rax
00007f582cdd0f4a  add rsp, 0x08
00007f582cdd0f4e  jmp 0x00007F582CDCF706
00007f582cdd0f53  sub rsp, 0x08
00007f582cdd0f57  push rax
00007f582cdd0f58  push rcx
00007f582cdd0f59  push rdx
00007f582cdd0f5a  push rdi
00007f582cdd0f5b  push rsi
00007f582cdd0f5c  push r8
00007f582cdd0f5e  push r9
00007f582cdd0f60  push r10
00007f582cdd0f62  push r11
00007f582cdd0f64  sub rsp, 0xF0
00007f582cdd0f6b  vmovaps [rsp], xmm0
00007f582cdd0f70  vmovaps [rsp+0x10], xmm2
00007f582cdd0f76  vmovaps [rsp+0x20], xmm3
00007f582cdd0f7c  vmovaps [rsp+0x30], xmm4
00007f582cdd0f82  vmovaps [rsp+0x40], xmm5
00007f582cdd0f88  vmovaps [rsp+0x50], xmm6
00007f582cdd0f8e  vmovaps [rsp+0x60], xmm7
00007f582cdd0f94  vmovaps [rsp+0x70], xmm8
00007f582cdd0f9a  vmovaps [rsp+0x80], xmm9
00007f582cdd0fa3  vmovaps [rsp+0x90], xmm10
00007f582cdd0fac  vmovaps [rsp+0xA0], xmm11
00007f582cdd0fb5  vmovaps [rsp+0xB0], xmm12
00007f582cdd0fbe  vmovaps [rsp+0xC0], xmm13
00007f582cdd0fc7  vmovaps [rsp+0xD0], xmm14
00007f582cdd0fd0  vmovaps [rsp+0xE0], xmm15
00007f582cdd0fd9  sub rsp, 0x30
00007f582cdd0fdd  movaps [rsp], xmm1
00007f582cdd0fe1  movaps [rsp+0x10], xmm10
00007f582cdd0fe7  movaps [rsp+0x20], xmm12
00007f582cdd0fed  lea rdi, [rsp]
00007f582cdd0ff1  mov esi, 0x00
00007f582cdd0ff6  mov rax, 0x653B0D9BF530
00007f582cdd1000  call rax
00007f582cdd1002  movaps xmm1, [rsp]
00007f582cdd1006  add rsp, 0x30
00007f582cdd100a  vmovaps xmm0, [rsp]
00007f582cdd100f  vmovaps xmm2, [rsp+0x10]
00007f582cdd1015  vmovaps xmm3, [rsp+0x20]
00007f582cdd101b  vmovaps xmm4, [rsp+0x30]
00007f582cdd1021  vmovaps xmm5, [rsp+0x40]
00007f582cdd1027  vmovaps xmm6, [rsp+0x50]
00007f582cdd102d  vmovaps xmm7, [rsp+0x60]
00007f582cdd1033  vmovaps xmm8, [rsp+0x70]
00007f582cdd1039  vmovaps xmm9, [rsp+0x80]
00007f582cdd1042  vmovaps xmm10, [rsp+0x90]
00007f582cdd104b  vmovaps xmm11, [rsp+0xA0]
00007f582cdd1054  vmovaps xmm12, [rsp+0xB0]
00007f582cdd105d  vmovaps xmm13, [rsp+0xC0]
00007f582cdd1066  vmovaps xmm14, [rsp+0xD0]
00007f582cdd106f  vmovaps xmm15, [rsp+0xE0]
00007f582cdd1078  add rsp, 0xF0
00007f582cdd107f  pop r11
00007f582cdd1081  pop r10
00007f582cdd1083  pop r9
00007f582cdd1085  pop r8
00007f582cdd1087  pop rsi
00007f582cdd1088  pop rdi
00007f582cdd1089  pop rdx
00007f582cdd108a  pop rcx
00007f582cdd108b  pop rax
00007f582cdd108c  add rsp, 0x08
00007f582cdd1090  jmp 0x00007F582CDCF732
00007f582cdd1095  sub rsp, 0x08
00007f582cdd1099  push rax
00007f582cdd109a  push rcx
00007f582cdd109b  push rdx
00007f582cdd109c  push rdi
00007f582cdd109d  push rsi
00007f582cdd109e  push r8
00007f582cdd10a0  push r9
00007f582cdd10a2  push r10
00007f582cdd10a4  push r11
00007f582cdd10a6  sub rsp, 0xF0
00007f582cdd10ad  vmovaps [rsp], xmm0
00007f582cdd10b2  vmovaps [rsp+0x10], xmm1
00007f582cdd10b8  vmovaps [rsp+0x20], xmm2
00007f582cdd10be  vmovaps [rsp+0x30], xmm3
00007f582cdd10c4  vmovaps [rsp+0x40], xmm4
00007f582cdd10ca  vmovaps [rsp+0x50], xmm5
00007f582cdd10d0  vmovaps [rsp+0x60], xmm6
00007f582cdd10d6  vmovaps [rsp+0x70], xmm7
00007f582cdd10dc  vmovaps [rsp+0x80], xmm8
00007f582cdd10e5  vmovaps [rsp+0x90], xmm9
00007f582cdd10ee  vmovaps [rsp+0xA0], xmm10
00007f582cdd10f7  vmovaps [rsp+0xB0], xmm11
00007f582cdd1100  vmovaps [rsp+0xC0], xmm12
00007f582cdd1109  vmovaps [rsp+0xD0], xmm13
00007f582cdd1112  vmovaps [rsp+0xE0], xmm14
00007f582cdd111b  sub rsp, 0x30
00007f582cdd111f  movaps [rsp], xmm15
00007f582cdd1124  movaps [rsp+0x10], xmm10
00007f582cdd112a  movaps [rsp+0x20], xmm12
00007f582cdd1130  lea rdi, [rsp]
00007f582cdd1134  mov esi, 0x00
00007f582cdd1139  mov rax, 0x653B0D9BF530
00007f582cdd1143  call rax
00007f582cdd1145  movaps xmm15, [rsp]
00007f582cdd114a  add rsp, 0x30
00007f582cdd114e  vmovaps xmm0, [rsp]
00007f582cdd1153  vmovaps xmm1, [rsp+0x10]
00007f582cdd1159  vmovaps xmm2, [rsp+0x20]
00007f582cdd115f  vmovaps xmm3, [rsp+0x30]
00007f582cdd1165  vmovaps xmm4, [rsp+0x40]
00007f582cdd116b  vmovaps xmm5, [rsp+0x50]
00007f582cdd1171  vmovaps xmm6, [rsp+0x60]
00007f582cdd1177  vmovaps xmm7, [rsp+0x70]
00007f582cdd117d  vmovaps xmm8, [rsp+0x80]
00007f582cdd1186  vmovaps xmm9, [rsp+0x90]
00007f582cdd118f  vmovaps xmm10, [rsp+0xA0]
00007f582cdd1198  vmovaps xmm11, [rsp+0xB0]
00007f582cdd11a1  vmovaps xmm12, [rsp+0xC0]
00007f582cdd11aa  vmovaps xmm13, [rsp+0xD0]
00007f582cdd11b3  vmovaps xmm14, [rsp+0xE0]
00007f582cdd11bc  add rsp, 0xF0
00007f582cdd11c3  pop r11
00007f582cdd11c5  pop r10
00007f582cdd11c7  pop r9
00007f582cdd11c9  pop r8
00007f582cdd11cb  pop rsi
00007f582cdd11cc  pop rdi
00007f582cdd11cd  pop rdx
00007f582cdd11ce  pop rcx
00007f582cdd11cf  pop rax
00007f582cdd11d0  add rsp, 0x08
00007f582cdd11d4  jmp 0x00007F582CDCF75E
00007f582cdd11d9  call 0x00007F582CBFF430
00007f582cdd11de  jmp 0x00007F582CDCF7EE
00007f582cdd11e3  call 0x00007F582CBFF430
00007f582cdd11e8  jmp 0x00007F582CDCF801
00007f582cdd11ed  sub rsp, 0x08
00007f582cdd11f1  push rax
00007f582cdd11f2  push rcx
00007f582cdd11f3  push rdx
00007f582cdd11f4  push rdi
00007f582cdd11f5  push rsi
00007f582cdd11f6  push r8
00007f582cdd11f8  push r9
00007f582cdd11fa  push r10
00007f582cdd11fc  push r11
00007f582cdd11fe  sub rsp, 0xF0
00007f582cdd1205  vmovaps [rsp], xmm0
00007f582cdd120a  vmovaps [rsp+0x10], xmm2
00007f582cdd1210  vmovaps [rsp+0x20], xmm3
00007f582cdd1216  vmovaps [rsp+0x30], xmm4
00007f582cdd121c  vmovaps [rsp+0x40], xmm5
00007f582cdd1222  vmovaps [rsp+0x50], xmm6
00007f582cdd1228  vmovaps [rsp+0x60], xmm7
00007f582cdd122e  vmovaps [rsp+0x70], xmm8
00007f582cdd1234  vmovaps [rsp+0x80], xmm9
00007f582cdd123d  vmovaps [rsp+0x90], xmm10
00007f582cdd1246  vmovaps [rsp+0xA0], xmm11
00007f582cdd124f  vmovaps [rsp+0xB0], xmm12
00007f582cdd1258  vmovaps [rsp+0xC0], xmm13
00007f582cdd1261  vmovaps [rsp+0xD0], xmm14
00007f582cdd126a  vmovaps [rsp+0xE0], xmm15
00007f582cdd1273  sub rsp, 0x30
00007f582cdd1277  movaps [rsp], xmm1
00007f582cdd127b  movaps [rsp+0x10], xmm13
00007f582cdd1281  movaps [rsp+0x20], xmm2
00007f582cdd1286  lea rdi, [rsp]
00007f582cdd128a  mov esi, 0x00
00007f582cdd128f  mov rax, 0x653B0D9BF530
00007f582cdd1299  call rax
00007f582cdd129b  movaps xmm1, [rsp]
00007f582cdd129f  add rsp, 0x30
00007f582cdd12a3  vmovaps xmm0, [rsp]
00007f582cdd12a8  vmovaps xmm2, [rsp+0x10]
00007f582cdd12ae  vmovaps xmm3, [rsp+0x20]
00007f582cdd12b4  vmovaps xmm4, [rsp+0x30]
00007f582cdd12ba  vmovaps xmm5, [rsp+0x40]
00007f582cdd12c0  vmovaps xmm6, [rsp+0x50]
00007f582cdd12c6  vmovaps xmm7, [rsp+0x60]
00007f582cdd12cc  vmovaps xmm8, [rsp+0x70]
00007f582cdd12d2  vmovaps xmm9, [rsp+0x80]
00007f582cdd12db  vmovaps xmm10, [rsp+0x90]
00007f582cdd12e4  vmovaps xmm11, [rsp+0xA0]
00007f582cdd12ed  vmovaps xmm12, [rsp+0xB0]
00007f582cdd12f6  vmovaps xmm13, [rsp+0xC0]
00007f582cdd12ff  vmovaps xmm14, [rsp+0xD0]
00007f582cdd1308  vmovaps xmm15, [rsp+0xE0]
00007f582cdd1311  add rsp, 0xF0
00007f582cdd1318  pop r11
00007f582cdd131a  pop r10
00007f582cdd131c  pop r9
00007f582cdd131e  pop r8
00007f582cdd1320  pop rsi
00007f582cdd1321  pop rdi
00007f582cdd1322  pop rdx
00007f582cdd1323  pop rcx
00007f582cdd1324  pop rax
00007f582cdd1325  add rsp, 0x08
00007f582cdd1329  jmp 0x00007F582CDCF82C
00007f582cdd132e  call 0x00007F582CC0E760
00007f582cdd1333  jmp 0x00007F582CDCF839
00007f582cdd1338  sub rsp, 0x08
00007f582cdd133c  push rax
00007f582cdd133d  push rcx
00007f582cdd133e  push rdx
00007f582cdd133f  push rdi
00007f582cdd1340  push rsi
00007f582cdd1341  push r8
00007f582cdd1343  push r9
00007f582cdd1345  push r10
00007f582cdd1347  push r11
00007f582cdd1349  sub rsp, 0xF0
00007f582cdd1350  vmovaps [rsp], xmm0
00007f582cdd1355  vmovaps [rsp+0x10], xmm1
00007f582cdd135b  vmovaps [rsp+0x20], xmm2
00007f582cdd1361  vmovaps [rsp+0x30], xmm3
00007f582cdd1367  vmovaps [rsp+0x40], xmm4
00007f582cdd136d  vmovaps [rsp+0x50], xmm5
00007f582cdd1373  vmovaps [rsp+0x60], xmm6
00007f582cdd1379  vmovaps [rsp+0x70], xmm7
00007f582cdd137f  vmovaps [rsp+0x80], xmm8
00007f582cdd1388  vmovaps [rsp+0x90], xmm9
00007f582cdd1391  vmovaps [rsp+0xA0], xmm10
00007f582cdd139a  vmovaps [rsp+0xB0], xmm11
00007f582cdd13a3  vmovaps [rsp+0xC0], xmm12
00007f582cdd13ac  vmovaps [rsp+0xD0], xmm14
00007f582cdd13b5  vmovaps [rsp+0xE0], xmm15
00007f582cdd13be  sub rsp, 0x30
00007f582cdd13c2  movaps [rsp], xmm13
00007f582cdd13c7  movaps [rsp+0x10], xmm2
00007f582cdd13cc  movaps [rsp+0x20], xmm1
00007f582cdd13d1  lea rdi, [rsp]
00007f582cdd13d5  mov esi, 0x00
00007f582cdd13da  mov rax, 0x653B0D9BF530
00007f582cdd13e4  call rax
00007f582cdd13e6  movaps xmm13, [rsp]
00007f582cdd13eb  add rsp, 0x30
00007f582cdd13ef  vmovaps xmm0, [rsp]
00007f582cdd13f4  vmovaps xmm1, [rsp+0x10]
00007f582cdd13fa  vmovaps xmm2, [rsp+0x20]
00007f582cdd1400  vmovaps xmm3, [rsp+0x30]
00007f582cdd1406  vmovaps xmm4, [rsp+0x40]
00007f582cdd140c  vmovaps xmm5, [rsp+0x50]
00007f582cdd1412  vmovaps xmm6, [rsp+0x60]
00007f582cdd1418  vmovaps xmm7, [rsp+0x70]
00007f582cdd141e  vmovaps xmm8, [rsp+0x80]
00007f582cdd1427  vmovaps xmm9, [rsp+0x90]
00007f582cdd1430  vmovaps xmm10, [rsp+0xA0]
00007f582cdd1439  vmovaps xmm11, [rsp+0xB0]
00007f582cdd1442  vmovaps xmm12, [rsp+0xC0]
00007f582cdd144b  vmovaps xmm14, [rsp+0xD0]
00007f582cdd1454  vmovaps xmm15, [rsp+0xE0]
00007f582cdd145d  add rsp, 0xF0
00007f582cdd1464  pop r11
00007f582cdd1466  pop r10
00007f582cdd1468  pop r9
00007f582cdd146a  pop r8
00007f582cdd146c  pop rsi
00007f582cdd146d  pop rdi
00007f582cdd146e  pop rdx
00007f582cdd146f  pop rcx
00007f582cdd1470  pop rax
00007f582cdd1471  add rsp, 0x08
00007f582cdd1475  jmp 0x00007F582CDCF878
00007f582cdd147a  sub rsp, 0x08
00007f582cdd147e  push rax
00007f582cdd147f  push rcx
00007f582cdd1480  push rdx
00007f582cdd1481  push rdi
00007f582cdd1482  push rsi
00007f582cdd1483  push r8
00007f582cdd1485  push r9
00007f582cdd1487  push r10
00007f582cdd1489  push r11
00007f582cdd148b  sub rsp, 0xF0
00007f582cdd1492  vmovaps [rsp], xmm0
00007f582cdd1497  vmovaps [rsp+0x10], xmm2
00007f582cdd149d  vmovaps [rsp+0x20], xmm3
00007f582cdd14a3  vmovaps [rsp+0x30], xmm4
00007f582cdd14a9  vmovaps [rsp+0x40], xmm5
00007f582cdd14af  vmovaps [rsp+0x50], xmm6
00007f582cdd14b5  vmovaps [rsp+0x60], xmm7
00007f582cdd14bb  vmovaps [rsp+0x70], xmm8
00007f582cdd14c1  vmovaps [rsp+0x80], xmm9
00007f582cdd14ca  vmovaps [rsp+0x90], xmm10
00007f582cdd14d3  vmovaps [rsp+0xA0], xmm11
00007f582cdd14dc  vmovaps [rsp+0xB0], xmm12
00007f582cdd14e5  vmovaps [rsp+0xC0], xmm13
00007f582cdd14ee  vmovaps [rsp+0xD0], xmm14
00007f582cdd14f7  vmovaps [rsp+0xE0], xmm15
00007f582cdd1500  sub rsp, 0x30
00007f582cdd1504  movaps [rsp], xmm1
00007f582cdd1508  movaps [rsp+0x10], xmm15
00007f582cdd150e  movaps [rsp+0x20], xmm2
00007f582cdd1513  lea rdi, [rsp]
00007f582cdd1517  mov esi, 0x00
00007f582cdd151c  mov rax, 0x653B0D9BF530
00007f582cdd1526  call rax
00007f582cdd1528  movaps xmm1, [rsp]
00007f582cdd152c  add rsp, 0x30
00007f582cdd1530  vmovaps xmm0, [rsp]
00007f582cdd1535  vmovaps xmm2, [rsp+0x10]
00007f582cdd153b  vmovaps xmm3, [rsp+0x20]
00007f582cdd1541  vmovaps xmm4, [rsp+0x30]
00007f582cdd1547  vmovaps xmm5, [rsp+0x40]
00007f582cdd154d  vmovaps xmm6, [rsp+0x50]
00007f582cdd1553  vmovaps xmm7, [rsp+0x60]
00007f582cdd1559  vmovaps xmm8, [rsp+0x70]
00007f582cdd155f  vmovaps xmm9, [rsp+0x80]
00007f582cdd1568  vmovaps xmm10, [rsp+0x90]
00007f582cdd1571  vmovaps xmm11, [rsp+0xA0]
00007f582cdd157a  vmovaps xmm12, [rsp+0xB0]
00007f582cdd1583  vmovaps xmm13, [rsp+0xC0]
00007f582cdd158c  vmovaps xmm14, [rsp+0xD0]
00007f582cdd1595  vmovaps xmm15, [rsp+0xE0]
00007f582cdd159e  add rsp, 0xF0
00007f582cdd15a5  pop r11
00007f582cdd15a7  pop r10
00007f582cdd15a9  pop r9
00007f582cdd15ab  pop r8
00007f582cdd15ad  pop rsi
00007f582cdd15ae  pop rdi
00007f582cdd15af  pop rdx
00007f582cdd15b0  pop rcx
00007f582cdd15b1  pop rax
00007f582cdd15b2  add rsp, 0x08
00007f582cdd15b6  jmp 0x00007F582CDCF8AC
00007f582cdd15bb  sub rsp, 0x08
00007f582cdd15bf  push rax
00007f582cdd15c0  push rcx
00007f582cdd15c1  push rdx
00007f582cdd15c2  push rdi
00007f582cdd15c3  push rsi
00007f582cdd15c4  push r8
00007f582cdd15c6  push r9
00007f582cdd15c8  push r10
00007f582cdd15ca  push r11
00007f582cdd15cc  sub rsp, 0xF0
00007f582cdd15d3  vmovaps [rsp], xmm0
00007f582cdd15d8  vmovaps [rsp+0x10], xmm1
00007f582cdd15de  vmovaps [rsp+0x20], xmm2
00007f582cdd15e4  vmovaps [rsp+0x30], xmm3
00007f582cdd15ea  vmovaps [rsp+0x40], xmm4
00007f582cdd15f0  vmovaps [rsp+0x50], xmm5
00007f582cdd15f6  vmovaps [rsp+0x60], xmm6
00007f582cdd15fc  vmovaps [rsp+0x70], xmm7
00007f582cdd1602  vmovaps [rsp+0x80], xmm8
00007f582cdd160b  vmovaps [rsp+0x90], xmm9
00007f582cdd1614  vmovaps [rsp+0xA0], xmm10
00007f582cdd161d  vmovaps [rsp+0xB0], xmm11
00007f582cdd1626  vmovaps [rsp+0xC0], xmm12
00007f582cdd162f  vmovaps [rsp+0xD0], xmm13
00007f582cdd1638  vmovaps [rsp+0xE0], xmm15
00007f582cdd1641  sub rsp, 0x30
00007f582cdd1645  movaps [rsp], xmm14
00007f582cdd164a  movaps [rsp+0x10], xmm2
00007f582cdd164f  movaps [rsp+0x20], xmm15
00007f582cdd1655  lea rdi, [rsp]
00007f582cdd1659  mov esi, 0x00
00007f582cdd165e  mov rax, 0x653B0D9BF530
00007f582cdd1668  call rax
00007f582cdd166a  movaps xmm14, [rsp]
00007f582cdd166f  add rsp, 0x30
00007f582cdd1673  vmovaps xmm0, [rsp]
00007f582cdd1678  vmovaps xmm1, [rsp+0x10]
00007f582cdd167e  vmovaps xmm2, [rsp+0x20]
00007f582cdd1684  vmovaps xmm3, [rsp+0x30]
00007f582cdd168a  vmovaps xmm4, [rsp+0x40]
00007f582cdd1690  vmovaps xmm5, [rsp+0x50]
00007f582cdd1696  vmovaps xmm6, [rsp+0x60]
00007f582cdd169c  vmovaps xmm7, [rsp+0x70]
00007f582cdd16a2  vmovaps xmm8, [rsp+0x80]
00007f582cdd16ab  vmovaps xmm9, [rsp+0x90]
00007f582cdd16b4  vmovaps xmm10, [rsp+0xA0]
00007f582cdd16bd  vmovaps xmm11, [rsp+0xB0]
00007f582cdd16c6  vmovaps xmm12, [rsp+0xC0]
00007f582cdd16cf  vmovaps xmm13, [rsp+0xD0]
00007f582cdd16d8  vmovaps xmm15, [rsp+0xE0]
00007f582cdd16e1  add rsp, 0xF0
00007f582cdd16e8  pop r11
00007f582cdd16ea  pop r10
00007f582cdd16ec  pop r9
00007f582cdd16ee  pop r8
00007f582cdd16f0  pop rsi
00007f582cdd16f1  pop rdi
00007f582cdd16f2  pop rdx
00007f582cdd16f3  pop rcx
00007f582cdd16f4  pop rax
00007f582cdd16f5  add rsp, 0x08
00007f582cdd16f9  jmp 0x00007F582CDCF8E7
00007f582cdd16fe  sub rsp, 0x08
00007f582cdd1702  push rax
00007f582cdd1703  push rcx
00007f582cdd1704  push rdx
00007f582cdd1705  push rdi
00007f582cdd1706  push rsi
00007f582cdd1707  push r8
00007f582cdd1709  push r9
00007f582cdd170b  push r10
00007f582cdd170d  push r11
00007f582cdd170f  sub rsp, 0xF0
00007f582cdd1716  vmovaps [rsp], xmm0
00007f582cdd171b  vmovaps [rsp+0x10], xmm1
00007f582cdd1721  vmovaps [rsp+0x20], xmm2
00007f582cdd1727  vmovaps [rsp+0x30], xmm3
00007f582cdd172d  vmovaps [rsp+0x40], xmm4
00007f582cdd1733  vmovaps [rsp+0x50], xmm5
00007f582cdd1739  vmovaps [rsp+0x60], xmm6
00007f582cdd173f  vmovaps [rsp+0x70], xmm7
00007f582cdd1745  vmovaps [rsp+0x80], xmm8
00007f582cdd174e  vmovaps [rsp+0x90], xmm9
00007f582cdd1757  vmovaps [rsp+0xA0], xmm10
00007f582cdd1760  vmovaps [rsp+0xB0], xmm11
00007f582cdd1769  vmovaps [rsp+0xC0], xmm12
00007f582cdd1772  vmovaps [rsp+0xD0], xmm13
00007f582cdd177b  vmovaps [rsp+0xE0], xmm14
00007f582cdd1784  sub rsp, 0x30
00007f582cdd1788  movaps [rsp], xmm15
00007f582cdd178d  movaps [rsp+0x10], xmm2
00007f582cdd1792  movaps [rsp+0x20], xmm1
00007f582cdd1797  lea rdi, [rsp]
00007f582cdd179b  mov esi, 0x00
00007f582cdd17a0  mov rax, 0x653B0D9BF530
00007f582cdd17aa  call rax
00007f582cdd17ac  movaps xmm15, [rsp]
00007f582cdd17b1  add rsp, 0x30
00007f582cdd17b5  vmovaps xmm0, [rsp]
00007f582cdd17ba  vmovaps xmm1, [rsp+0x10]
00007f582cdd17c0  vmovaps xmm2, [rsp+0x20]
00007f582cdd17c6  vmovaps xmm3, [rsp+0x30]
00007f582cdd17cc  vmovaps xmm4, [rsp+0x40]
00007f582cdd17d2  vmovaps xmm5, [rsp+0x50]
00007f582cdd17d8  vmovaps xmm6, [rsp+0x60]
00007f582cdd17de  vmovaps xmm7, [rsp+0x70]
00007f582cdd17e4  vmovaps xmm8, [rsp+0x80]
00007f582cdd17ed  vmovaps xmm9, [rsp+0x90]
00007f582cdd17f6  vmovaps xmm10, [rsp+0xA0]
00007f582cdd17ff  vmovaps xmm11, [rsp+0xB0]
00007f582cdd1808  vmovaps xmm12, [rsp+0xC0]
00007f582cdd1811  vmovaps xmm13, [rsp+0xD0]
00007f582cdd181a  vmovaps xmm14, [rsp+0xE0]
00007f582cdd1823  add rsp, 0xF0
00007f582cdd182a  pop r11
00007f582cdd182c  pop r10
00007f582cdd182e  pop r9
00007f582cdd1830  pop r8
00007f582cdd1832  pop rsi
00007f582cdd1833  pop rdi
00007f582cdd1834  pop rdx
00007f582cdd1835  pop rcx
00007f582cdd1836  pop rax
00007f582cdd1837  add rsp, 0x08
00007f582cdd183b  jmp 0x00007F582CDCF923
00007f582cdd1840  call 0x00007F582CBFF430
00007f582cdd1845  jmp 0x00007F582CDCF930
00007f582cdd184a  sub rsp, 0x08
00007f582cdd184e  push rax
00007f582cdd184f  push rcx
00007f582cdd1850  push rdx
00007f582cdd1851  push rdi
00007f582cdd1852  push rsi
00007f582cdd1853  push r8
00007f582cdd1855  push r9
00007f582cdd1857  push r10
00007f582cdd1859  push r11
00007f582cdd185b  sub rsp, 0xF0
00007f582cdd1862  vmovaps [rsp], xmm0
00007f582cdd1867  vmovaps [rsp+0x10], xmm1
00007f582cdd186d  vmovaps [rsp+0x20], xmm3
00007f582cdd1873  vmovaps [rsp+0x30], xmm4
00007f582cdd1879  vmovaps [rsp+0x40], xmm5
00007f582cdd187f  vmovaps [rsp+0x50], xmm6
00007f582cdd1885  vmovaps [rsp+0x60], xmm7
00007f582cdd188b  vmovaps [rsp+0x70], xmm8
00007f582cdd1891  vmovaps [rsp+0x80], xmm9
00007f582cdd189a  vmovaps [rsp+0x90], xmm10
00007f582cdd18a3  vmovaps [rsp+0xA0], xmm11
00007f582cdd18ac  vmovaps [rsp+0xB0], xmm12
00007f582cdd18b5  vmovaps [rsp+0xC0], xmm13
00007f582cdd18be  vmovaps [rsp+0xD0], xmm14
00007f582cdd18c7  vmovaps [rsp+0xE0], xmm15
00007f582cdd18d0  sub rsp, 0x30
00007f582cdd18d4  movaps [rsp], xmm2
00007f582cdd18d8  movaps [rsp+0x10], xmm1
00007f582cdd18dd  movaps [rsp+0x20], xmm14
00007f582cdd18e3  lea rdi, [rsp]
00007f582cdd18e7  mov esi, 0x00
00007f582cdd18ec  mov rax, 0x653B0D9BF530
00007f582cdd18f6  call rax
00007f582cdd18f8  movaps xmm2, [rsp]
00007f582cdd18fc  add rsp, 0x30
00007f582cdd1900  vmovaps xmm0, [rsp]
00007f582cdd1905  vmovaps xmm1, [rsp+0x10]
00007f582cdd190b  vmovaps xmm3, [rsp+0x20]
00007f582cdd1911  vmovaps xmm4, [rsp+0x30]
00007f582cdd1917  vmovaps xmm5, [rsp+0x40]
00007f582cdd191d  vmovaps xmm6, [rsp+0x50]
00007f582cdd1923  vmovaps xmm7, [rsp+0x60]
00007f582cdd1929  vmovaps xmm8, [rsp+0x70]
00007f582cdd192f  vmovaps xmm9, [rsp+0x80]
00007f582cdd1938  vmovaps xmm10, [rsp+0x90]
00007f582cdd1941  vmovaps xmm11, [rsp+0xA0]
00007f582cdd194a  vmovaps xmm12, [rsp+0xB0]
00007f582cdd1953  vmovaps xmm13, [rsp+0xC0]
00007f582cdd195c  vmovaps xmm14, [rsp+0xD0]
00007f582cdd1965  vmovaps xmm15, [rsp+0xE0]
00007f582cdd196e  add rsp, 0xF0
00007f582cdd1975  pop r11
00007f582cdd1977  pop r10
00007f582cdd1979  pop r9
00007f582cdd197b  pop r8
00007f582cdd197d  pop rsi
00007f582cdd197e  pop rdi
00007f582cdd197f  pop rdx
00007f582cdd1980  pop rcx
00007f582cdd1981  pop rax
00007f582cdd1982  add rsp, 0x08
00007f582cdd1986  jmp 0x00007F582CDCF96D
00007f582cdd198b  sub rsp, 0x08
00007f582cdd198f  push rax
00007f582cdd1990  push rcx
00007f582cdd1991  push rdx
00007f582cdd1992  push rdi
00007f582cdd1993  push rsi
00007f582cdd1994  push r8
00007f582cdd1996  push r9
00007f582cdd1998  push r10
00007f582cdd199a  push r11
00007f582cdd199c  sub rsp, 0xF0
00007f582cdd19a3  vmovaps [rsp], xmm0
00007f582cdd19a8  vmovaps [rsp+0x10], xmm1
00007f582cdd19ae  vmovaps [rsp+0x20], xmm2
00007f582cdd19b4  vmovaps [rsp+0x30], xmm3
00007f582cdd19ba  vmovaps [rsp+0x40], xmm4
00007f582cdd19c0  vmovaps [rsp+0x50], xmm5
00007f582cdd19c6  vmovaps [rsp+0x60], xmm6
00007f582cdd19cc  vmovaps [rsp+0x70], xmm7
00007f582cdd19d2  vmovaps [rsp+0x80], xmm8
00007f582cdd19db  vmovaps [rsp+0x90], xmm9
00007f582cdd19e4  vmovaps [rsp+0xA0], xmm10
00007f582cdd19ed  vmovaps [rsp+0xB0], xmm11
00007f582cdd19f6  vmovaps [rsp+0xC0], xmm12
00007f582cdd19ff  vmovaps [rsp+0xD0], xmm13
00007f582cdd1a08  vmovaps [rsp+0xE0], xmm14
00007f582cdd1a11  sub rsp, 0x30
00007f582cdd1a15  movaps [rsp], xmm15
00007f582cdd1a1a  movaps [rsp+0x10], xmm14
00007f582cdd1a20  movaps [rsp+0x20], xmm1
00007f582cdd1a25  lea rdi, [rsp]
00007f582cdd1a29  mov esi, 0x00
00007f582cdd1a2e  mov rax, 0x653B0D9BF530
00007f582cdd1a38  call rax
00007f582cdd1a3a  movaps xmm15, [rsp]
00007f582cdd1a3f  add rsp, 0x30
00007f582cdd1a43  vmovaps xmm0, [rsp]
00007f582cdd1a48  vmovaps xmm1, [rsp+0x10]
00007f582cdd1a4e  vmovaps xmm2, [rsp+0x20]
00007f582cdd1a54  vmovaps xmm3, [rsp+0x30]
00007f582cdd1a5a  vmovaps xmm4, [rsp+0x40]
00007f582cdd1a60  vmovaps xmm5, [rsp+0x50]
00007f582cdd1a66  vmovaps xmm6, [rsp+0x60]
00007f582cdd1a6c  vmovaps xmm7, [rsp+0x70]
00007f582cdd1a72  vmovaps xmm8, [rsp+0x80]
00007f582cdd1a7b  vmovaps xmm9, [rsp+0x90]
00007f582cdd1a84  vmovaps xmm10, [rsp+0xA0]
00007f582cdd1a8d  vmovaps xmm11, [rsp+0xB0]
00007f582cdd1a96  vmovaps xmm12, [rsp+0xC0]
00007f582cdd1a9f  vmovaps xmm13, [rsp+0xD0]
00007f582cdd1aa8  vmovaps xmm14, [rsp+0xE0]
00007f582cdd1ab1  add rsp, 0xF0
00007f582cdd1ab8  pop r11
00007f582cdd1aba  pop r10
00007f582cdd1abc  pop r9
00007f582cdd1abe  pop r8
00007f582cdd1ac0  pop rsi
00007f582cdd1ac1  pop rdi
00007f582cdd1ac2  pop rdx
00007f582cdd1ac3  pop rcx
00007f582cdd1ac4  pop rax
00007f582cdd1ac5  add rsp, 0x08
00007f582cdd1ac9  jmp 0x00007F582CDCF9E7
00007f582cdd1ace  call 0x00007F582CBFF430
00007f582cdd1ad3  jmp 0x00007F582CDCF9F4
00007f582cdd1ad8  sub rsp, 0x08
00007f582cdd1adc  push rax
00007f582cdd1add  push rcx
00007f582cdd1ade  push rdx
00007f582cdd1adf  push rdi
00007f582cdd1ae0  push rsi
00007f582cdd1ae1  push r8
00007f582cdd1ae3  push r9
00007f582cdd1ae5  push r10
00007f582cdd1ae7  push r11
00007f582cdd1ae9  sub rsp, 0xF0
00007f582cdd1af0  vmovaps [rsp], xmm0
00007f582cdd1af5  vmovaps [rsp+0x10], xmm1
00007f582cdd1afb  vmovaps [rsp+0x20], xmm2
00007f582cdd1b01  vmovaps [rsp+0x30], xmm3
00007f582cdd1b07  vmovaps [rsp+0x40], xmm4
00007f582cdd1b0d  vmovaps [rsp+0x50], xmm5
00007f582cdd1b13  vmovaps [rsp+0x60], xmm6
00007f582cdd1b19  vmovaps [rsp+0x70], xmm7
00007f582cdd1b1f  vmovaps [rsp+0x80], xmm8
00007f582cdd1b28  vmovaps [rsp+0x90], xmm9
00007f582cdd1b31  vmovaps [rsp+0xA0], xmm10
00007f582cdd1b3a  vmovaps [rsp+0xB0], xmm11
00007f582cdd1b43  vmovaps [rsp+0xC0], xmm12
00007f582cdd1b4c  vmovaps [rsp+0xD0], xmm13
00007f582cdd1b55  vmovaps [rsp+0xE0], xmm15
00007f582cdd1b5e  sub rsp, 0x30
00007f582cdd1b62  movaps [rsp], xmm14
00007f582cdd1b67  movaps [rsp+0x10], xmm13
00007f582cdd1b6d  movaps [rsp+0x20], xmm1
00007f582cdd1b72  lea rdi, [rsp]
00007f582cdd1b76  mov esi, 0x00
00007f582cdd1b7b  mov rax, 0x653B0D9BF530
00007f582cdd1b85  call rax
00007f582cdd1b87  movaps xmm14, [rsp]
00007f582cdd1b8c  add rsp, 0x30
00007f582cdd1b90  vmovaps xmm0, [rsp]
00007f582cdd1b95  vmovaps xmm1, [rsp+0x10]
00007f582cdd1b9b  vmovaps xmm2, [rsp+0x20]
00007f582cdd1ba1  vmovaps xmm3, [rsp+0x30]
00007f582cdd1ba7  vmovaps xmm4, [rsp+0x40]
00007f582cdd1bad  vmovaps xmm5, [rsp+0x50]
00007f582cdd1bb3  vmovaps xmm6, [rsp+0x60]
00007f582cdd1bb9  vmovaps xmm7, [rsp+0x70]
00007f582cdd1bbf  vmovaps xmm8, [rsp+0x80]
00007f582cdd1bc8  vmovaps xmm9, [rsp+0x90]
00007f582cdd1bd1  vmovaps xmm10, [rsp+0xA0]
00007f582cdd1bda  vmovaps xmm11, [rsp+0xB0]
00007f582cdd1be3  vmovaps xmm12, [rsp+0xC0]
00007f582cdd1bec  vmovaps xmm13, [rsp+0xD0]
00007f582cdd1bf5  vmovaps xmm15, [rsp+0xE0]
00007f582cdd1bfe  add rsp, 0xF0
00007f582cdd1c05  pop r11
00007f582cdd1c07  pop r10
00007f582cdd1c09  pop r9
00007f582cdd1c0b  pop r8
00007f582cdd1c0d  pop rsi
00007f582cdd1c0e  pop rdi
00007f582cdd1c0f  pop rdx
00007f582cdd1c10  pop rcx
00007f582cdd1c11  pop rax
00007f582cdd1c12  add rsp, 0x08
00007f582cdd1c16  jmp 0x00007F582CDCFAAF
00007f582cdd1c1b  sub rsp, 0x08
00007f582cdd1c1f  push rax
00007f582cdd1c20  push rcx
00007f582cdd1c21  push rdx
00007f582cdd1c22  push rdi
00007f582cdd1c23  push rsi
00007f582cdd1c24  push r8
00007f582cdd1c26  push r9
00007f582cdd1c28  push r10
00007f582cdd1c2a  push r11
00007f582cdd1c2c  sub rsp, 0xF0
00007f582cdd1c33  vmovaps [rsp], xmm0
00007f582cdd1c38  vmovaps [rsp+0x10], xmm1
00007f582cdd1c3e  vmovaps [rsp+0x20], xmm2
00007f582cdd1c44  vmovaps [rsp+0x30], xmm3
00007f582cdd1c4a  vmovaps [rsp+0x40], xmm4
00007f582cdd1c50  vmovaps [rsp+0x50], xmm5
00007f582cdd1c56  vmovaps [rsp+0x60], xmm6
00007f582cdd1c5c  vmovaps [rsp+0x70], xmm7
00007f582cdd1c62  vmovaps [rsp+0x80], xmm8
00007f582cdd1c6b  vmovaps [rsp+0x90], xmm9
00007f582cdd1c74  vmovaps [rsp+0xA0], xmm10
00007f582cdd1c7d  vmovaps [rsp+0xB0], xmm11
00007f582cdd1c86  vmovaps [rsp+0xC0], xmm12
00007f582cdd1c8f  vmovaps [rsp+0xD0], xmm13
00007f582cdd1c98  vmovaps [rsp+0xE0], xmm14
00007f582cdd1ca1  sub rsp, 0x30
00007f582cdd1ca5  movaps [rsp], xmm15
00007f582cdd1caa  movaps [rsp+0x10], xmm13
00007f582cdd1cb0  movaps [rsp+0x20], xmm1
00007f582cdd1cb5  lea rdi, [rsp]
00007f582cdd1cb9  mov esi, 0x00
00007f582cdd1cbe  mov rax, 0x653B0D9BF530
00007f582cdd1cc8  call rax
00007f582cdd1cca  movaps xmm15, [rsp]
00007f582cdd1ccf  add rsp, 0x30
00007f582cdd1cd3  vmovaps xmm0, [rsp]
00007f582cdd1cd8  vmovaps xmm1, [rsp+0x10]
00007f582cdd1cde  vmovaps xmm2, [rsp+0x20]
00007f582cdd1ce4  vmovaps xmm3, [rsp+0x30]
00007f582cdd1cea  vmovaps xmm4, [rsp+0x40]
00007f582cdd1cf0  vmovaps xmm5, [rsp+0x50]
00007f582cdd1cf6  vmovaps xmm6, [rsp+0x60]
00007f582cdd1cfc  vmovaps xmm7, [rsp+0x70]
00007f582cdd1d02  vmovaps xmm8, [rsp+0x80]
00007f582cdd1d0b  vmovaps xmm9, [rsp+0x90]
00007f582cdd1d14  vmovaps xmm10, [rsp+0xA0]
00007f582cdd1d1d  vmovaps xmm11, [rsp+0xB0]
00007f582cdd1d26  vmovaps xmm12, [rsp+0xC0]
00007f582cdd1d2f  vmovaps xmm13, [rsp+0xD0]
00007f582cdd1d38  vmovaps xmm14, [rsp+0xE0]
00007f582cdd1d41  add rsp, 0xF0
00007f582cdd1d48  pop r11
00007f582cdd1d4a  pop r10
00007f582cdd1d4c  pop r9
00007f582cdd1d4e  pop r8
00007f582cdd1d50  pop rsi
00007f582cdd1d51  pop rdi
00007f582cdd1d52  pop rdx
00007f582cdd1d53  pop rcx
00007f582cdd1d54  pop rax
00007f582cdd1d55  add rsp, 0x08
00007f582cdd1d59  jmp 0x00007F582CDCFAEB
00007f582cdd1d5e  call 0x00007F582CBFF430
00007f582cdd1d63  jmp 0x00007F582CDCFAF8
00007f582cdd1d68  sub rsp, 0x08
00007f582cdd1d6c  push rax
00007f582cdd1d6d  push rcx
00007f582cdd1d6e  push rdx
00007f582cdd1d6f  push rdi
00007f582cdd1d70  push rsi
00007f582cdd1d71  push r8
00007f582cdd1d73  push r9
00007f582cdd1d75  push r10
00007f582cdd1d77  push r11
00007f582cdd1d79  sub rsp, 0xF0
00007f582cdd1d80  vmovaps [rsp], xmm0
00007f582cdd1d85  vmovaps [rsp+0x10], xmm1
00007f582cdd1d8b  vmovaps [rsp+0x20], xmm2
00007f582cdd1d91  vmovaps [rsp+0x30], xmm3
00007f582cdd1d97  vmovaps [rsp+0x40], xmm4
00007f582cdd1d9d  vmovaps [rsp+0x50], xmm5
00007f582cdd1da3  vmovaps [rsp+0x60], xmm6
00007f582cdd1da9  vmovaps [rsp+0x70], xmm7
00007f582cdd1daf  vmovaps [rsp+0x80], xmm8
00007f582cdd1db8  vmovaps [rsp+0x90], xmm9
00007f582cdd1dc1  vmovaps [rsp+0xA0], xmm10
00007f582cdd1dca  vmovaps [rsp+0xB0], xmm11
00007f582cdd1dd3  vmovaps [rsp+0xC0], xmm12
00007f582cdd1ddc  vmovaps [rsp+0xD0], xmm13
00007f582cdd1de5  vmovaps [rsp+0xE0], xmm15
00007f582cdd1dee  sub rsp, 0x30
00007f582cdd1df2  movaps [rsp], xmm14
00007f582cdd1df7  movaps [rsp+0x10], xmm13
00007f582cdd1dfd  movaps [rsp+0x20], xmm2
00007f582cdd1e02  lea rdi, [rsp]
00007f582cdd1e06  mov esi, 0x00
00007f582cdd1e0b  mov rax, 0x653B0D9BF530
00007f582cdd1e15  call rax
00007f582cdd1e17  movaps xmm14, [rsp]
00007f582cdd1e1c  add rsp, 0x30
00007f582cdd1e20  vmovaps xmm0, [rsp]
00007f582cdd1e25  vmovaps xmm1, [rsp+0x10]
00007f582cdd1e2b  vmovaps xmm2, [rsp+0x20]
00007f582cdd1e31  vmovaps xmm3, [rsp+0x30]
00007f582cdd1e37  vmovaps xmm4, [rsp+0x40]
00007f582cdd1e3d  vmovaps xmm5, [rsp+0x50]
00007f582cdd1e43  vmovaps xmm6, [rsp+0x60]
00007f582cdd1e49  vmovaps xmm7, [rsp+0x70]
00007f582cdd1e4f  vmovaps xmm8, [rsp+0x80]
00007f582cdd1e58  vmovaps xmm9, [rsp+0x90]
00007f582cdd1e61  vmovaps xmm10, [rsp+0xA0]
00007f582cdd1e6a  vmovaps xmm11, [rsp+0xB0]
00007f582cdd1e73  vmovaps xmm12, [rsp+0xC0]
00007f582cdd1e7c  vmovaps xmm13, [rsp+0xD0]
00007f582cdd1e85  vmovaps xmm15, [rsp+0xE0]
00007f582cdd1e8e  add rsp, 0xF0
00007f582cdd1e95  pop r11
00007f582cdd1e97  pop r10
00007f582cdd1e99  pop r9
00007f582cdd1e9b  pop r8
00007f582cdd1e9d  pop rsi
00007f582cdd1e9e  pop rdi
00007f582cdd1e9f  pop rdx
00007f582cdd1ea0  pop rcx
00007f582cdd1ea1  pop rax
00007f582cdd1ea2  add rsp, 0x08
00007f582cdd1ea6  jmp 0x00007F582CDCFB24
00007f582cdd1eab  sub rsp, 0x08
00007f582cdd1eaf  push rax
00007f582cdd1eb0  push rcx
00007f582cdd1eb1  push rdx
00007f582cdd1eb2  push rdi
00007f582cdd1eb3  push rsi
00007f582cdd1eb4  push r8
00007f582cdd1eb6  push r9
00007f582cdd1eb8  push r10
00007f582cdd1eba  push r11
00007f582cdd1ebc  sub rsp, 0xF0
00007f582cdd1ec3  vmovaps [rsp], xmm0
00007f582cdd1ec8  vmovaps [rsp+0x10], xmm2
00007f582cdd1ece  vmovaps [rsp+0x20], xmm3
00007f582cdd1ed4  vmovaps [rsp+0x30], xmm4
00007f582cdd1eda  vmovaps [rsp+0x40], xmm5
00007f582cdd1ee0  vmovaps [rsp+0x50], xmm6
00007f582cdd1ee6  vmovaps [rsp+0x60], xmm7
00007f582cdd1eec  vmovaps [rsp+0x70], xmm8
00007f582cdd1ef2  vmovaps [rsp+0x80], xmm9
00007f582cdd1efb  vmovaps [rsp+0x90], xmm10
00007f582cdd1f04  vmovaps [rsp+0xA0], xmm11
00007f582cdd1f0d  vmovaps [rsp+0xB0], xmm12
00007f582cdd1f16  vmovaps [rsp+0xC0], xmm13
00007f582cdd1f1f  vmovaps [rsp+0xD0], xmm14
00007f582cdd1f28  vmovaps [rsp+0xE0], xmm15
00007f582cdd1f31  sub rsp, 0x30
00007f582cdd1f35  movaps [rsp], xmm1
00007f582cdd1f39  movaps [rsp+0x10], xmm13
00007f582cdd1f3f  movaps [rsp+0x20], xmm2
00007f582cdd1f44  lea rdi, [rsp]
00007f582cdd1f48  mov esi, 0x00
00007f582cdd1f4d  mov rax, 0x653B0D9BF530
00007f582cdd1f57  call rax
00007f582cdd1f59  movaps xmm1, [rsp]
00007f582cdd1f5d  add rsp, 0x30
00007f582cdd1f61  vmovaps xmm0, [rsp]
00007f582cdd1f66  vmovaps xmm2, [rsp+0x10]
00007f582cdd1f6c  vmovaps xmm3, [rsp+0x20]
00007f582cdd1f72  vmovaps xmm4, [rsp+0x30]
00007f582cdd1f78  vmovaps xmm5, [rsp+0x40]
00007f582cdd1f7e  vmovaps xmm6, [rsp+0x50]
00007f582cdd1f84  vmovaps xmm7, [rsp+0x60]
00007f582cdd1f8a  vmovaps xmm8, [rsp+0x70]
00007f582cdd1f90  vmovaps xmm9, [rsp+0x80]
00007f582cdd1f99  vmovaps xmm10, [rsp+0x90]
00007f582cdd1fa2  vmovaps xmm11, [rsp+0xA0]
00007f582cdd1fab  vmovaps xmm12, [rsp+0xB0]
00007f582cdd1fb4  vmovaps xmm13, [rsp+0xC0]
00007f582cdd1fbd  vmovaps xmm14, [rsp+0xD0]
00007f582cdd1fc6  vmovaps xmm15, [rsp+0xE0]
00007f582cdd1fcf  add rsp, 0xF0
00007f582cdd1fd6  pop r11
00007f582cdd1fd8  pop r10
00007f582cdd1fda  pop r9
00007f582cdd1fdc  pop r8
00007f582cdd1fde  pop rsi
00007f582cdd1fdf  pop rdi
00007f582cdd1fe0  pop rdx
00007f582cdd1fe1  pop rcx
00007f582cdd1fe2  pop rax
00007f582cdd1fe3  add rsp, 0x08
00007f582cdd1fe7  jmp 0x00007F582CDCFB52
00007f582cdd1fec  sub rsp, 0x08
00007f582cdd1ff0  push rax
00007f582cdd1ff1  push rcx
00007f582cdd1ff2  push rdx
00007f582cdd1ff3  push rdi
00007f582cdd1ff4  push rsi
00007f582cdd1ff5  push r8
00007f582cdd1ff7  push r9
00007f582cdd1ff9  push r10
00007f582cdd1ffb  push r11
00007f582cdd1ffd  sub rsp, 0xF0
00007f582cdd2004  vmovaps [rsp], xmm0
00007f582cdd2009  vmovaps [rsp+0x10], xmm1
00007f582cdd200f  vmovaps [rsp+0x20], xmm3
00007f582cdd2015  vmovaps [rsp+0x30], xmm4
00007f582cdd201b  vmovaps [rsp+0x40], xmm5
00007f582cdd2021  vmovaps [rsp+0x50], xmm6
00007f582cdd2027  vmovaps [rsp+0x60], xmm7
00007f582cdd202d  vmovaps [rsp+0x70], xmm8
00007f582cdd2033  vmovaps [rsp+0x80], xmm9
00007f582cdd203c  vmovaps [rsp+0x90], xmm10
00007f582cdd2045  vmovaps [rsp+0xA0], xmm11
00007f582cdd204e  vmovaps [rsp+0xB0], xmm12
00007f582cdd2057  vmovaps [rsp+0xC0], xmm13
00007f582cdd2060  vmovaps [rsp+0xD0], xmm14
00007f582cdd2069  vmovaps [rsp+0xE0], xmm15
00007f582cdd2072  sub rsp, 0x30
00007f582cdd2076  movaps [rsp], xmm2
00007f582cdd207a  movaps [rsp+0x10], xmm1
00007f582cdd207f  movaps [rsp+0x20], xmm13
00007f582cdd2085  lea rdi, [rsp]
00007f582cdd2089  mov esi, 0x00
00007f582cdd208e  mov rax, 0x653B0D9BF530
00007f582cdd2098  call rax
00007f582cdd209a  movaps xmm2, [rsp]
00007f582cdd209e  add rsp, 0x30
00007f582cdd20a2  vmovaps xmm0, [rsp]
00007f582cdd20a7  vmovaps xmm1, [rsp+0x10]
00007f582cdd20ad  vmovaps xmm3, [rsp+0x20]
00007f582cdd20b3  vmovaps xmm4, [rsp+0x30]
00007f582cdd20b9  vmovaps xmm5, [rsp+0x40]
00007f582cdd20bf  vmovaps xmm6, [rsp+0x50]
00007f582cdd20c5  vmovaps xmm7, [rsp+0x60]
00007f582cdd20cb  vmovaps xmm8, [rsp+0x70]
00007f582cdd20d1  vmovaps xmm9, [rsp+0x80]
00007f582cdd20da  vmovaps xmm10, [rsp+0x90]
00007f582cdd20e3  vmovaps xmm11, [rsp+0xA0]
00007f582cdd20ec  vmovaps xmm12, [rsp+0xB0]
00007f582cdd20f5  vmovaps xmm13, [rsp+0xC0]
00007f582cdd20fe  vmovaps xmm14, [rsp+0xD0]
00007f582cdd2107  vmovaps xmm15, [rsp+0xE0]
00007f582cdd2110  add rsp, 0xF0
00007f582cdd2117  pop r11
00007f582cdd2119  pop r10
00007f582cdd211b  pop r9
00007f582cdd211d  pop r8
00007f582cdd211f  pop rsi
00007f582cdd2120  pop rdi
00007f582cdd2121  pop rdx
00007f582cdd2122  pop rcx
00007f582cdd2123  pop rax
00007f582cdd2124  add rsp, 0x08
00007f582cdd2128  jmp 0x00007F582CDCFBAB
00007f582cdd212d  call 0x00007F582CBFF430
00007f582cdd2132  jmp 0x00007F582CDCFBB8
00007f582cdd2137  sub rsp, 0x08
00007f582cdd213b  push rax
00007f582cdd213c  push rcx
00007f582cdd213d  push rdx
00007f582cdd213e  push rdi
00007f582cdd213f  push rsi
00007f582cdd2140  push r8
00007f582cdd2142  push r9
00007f582cdd2144  push r10
00007f582cdd2146  push r11
00007f582cdd2148  sub rsp, 0xF0
00007f582cdd214f  vmovaps [rsp], xmm0
00007f582cdd2154  vmovaps [rsp+0x10], xmm1
00007f582cdd215a  vmovaps [rsp+0x20], xmm2
00007f582cdd2160  vmovaps [rsp+0x30], xmm3
00007f582cdd2166  vmovaps [rsp+0x40], xmm4
00007f582cdd216c  vmovaps [rsp+0x50], xmm5
00007f582cdd2172  vmovaps [rsp+0x60], xmm6
00007f582cdd2178  vmovaps [rsp+0x70], xmm7
00007f582cdd217e  vmovaps [rsp+0x80], xmm8
00007f582cdd2187  vmovaps [rsp+0x90], xmm9
00007f582cdd2190  vmovaps [rsp+0xA0], xmm10
00007f582cdd2199  vmovaps [rsp+0xB0], xmm11
00007f582cdd21a2  vmovaps [rsp+0xC0], xmm12
00007f582cdd21ab  vmovaps [rsp+0xD0], xmm13
00007f582cdd21b4  vmovaps [rsp+0xE0], xmm14
00007f582cdd21bd  sub rsp, 0x30
00007f582cdd21c1  movaps [rsp], xmm15
00007f582cdd21c6  movaps [rsp+0x10], xmm13
00007f582cdd21cc  movaps [rsp+0x20], xmm1
00007f582cdd21d1  lea rdi, [rsp]
00007f582cdd21d5  mov esi, 0x00
00007f582cdd21da  mov rax, 0x653B0D9BF530
00007f582cdd21e4  call rax
00007f582cdd21e6  movaps xmm15, [rsp]
00007f582cdd21eb  add rsp, 0x30
00007f582cdd21ef  vmovaps xmm0, [rsp]
00007f582cdd21f4  vmovaps xmm1, [rsp+0x10]
00007f582cdd21fa  vmovaps xmm2, [rsp+0x20]
00007f582cdd2200  vmovaps xmm3, [rsp+0x30]
00007f582cdd2206  vmovaps xmm4, [rsp+0x40]
00007f582cdd220c  vmovaps xmm5, [rsp+0x50]
00007f582cdd2212  vmovaps xmm6, [rsp+0x60]
00007f582cdd2218  vmovaps xmm7, [rsp+0x70]
00007f582cdd221e  vmovaps xmm8, [rsp+0x80]
00007f582cdd2227  vmovaps xmm9, [rsp+0x90]
00007f582cdd2230  vmovaps xmm10, [rsp+0xA0]
00007f582cdd2239  vmovaps xmm11, [rsp+0xB0]
00007f582cdd2242  vmovaps xmm12, [rsp+0xC0]
00007f582cdd224b  vmovaps xmm13, [rsp+0xD0]
00007f582cdd2254  vmovaps xmm14, [rsp+0xE0]
00007f582cdd225d  add rsp, 0xF0
00007f582cdd2264  pop r11
00007f582cdd2266  pop r10
00007f582cdd2268  pop r9
00007f582cdd226a  pop r8
00007f582cdd226c  pop rsi
00007f582cdd226d  pop rdi
00007f582cdd226e  pop rdx
00007f582cdd226f  pop rcx
00007f582cdd2270  pop rax
00007f582cdd2271  add rsp, 0x08
00007f582cdd2275  jmp 0x00007F582CDCFBF7
00007f582cdd227a  sub rsp, 0x08
00007f582cdd227e  push rax
00007f582cdd227f  push rcx
00007f582cdd2280  push rdx
00007f582cdd2281  push rdi
00007f582cdd2282  push rsi
00007f582cdd2283  push r8
00007f582cdd2285  push r9
00007f582cdd2287  push r10
00007f582cdd2289  push r11
00007f582cdd228b  sub rsp, 0xF0
00007f582cdd2292  vmovaps [rsp], xmm0
00007f582cdd2297  vmovaps [rsp+0x10], xmm1
00007f582cdd229d  vmovaps [rsp+0x20], xmm2
00007f582cdd22a3  vmovaps [rsp+0x30], xmm3
00007f582cdd22a9  vmovaps [rsp+0x40], xmm4
00007f582cdd22af  vmovaps [rsp+0x50], xmm5
00007f582cdd22b5  vmovaps [rsp+0x60], xmm6
00007f582cdd22bb  vmovaps [rsp+0x70], xmm7
00007f582cdd22c1  vmovaps [rsp+0x80], xmm8
00007f582cdd22ca  vmovaps [rsp+0x90], xmm9
00007f582cdd22d3  vmovaps [rsp+0xA0], xmm10
00007f582cdd22dc  vmovaps [rsp+0xB0], xmm11
00007f582cdd22e5  vmovaps [rsp+0xC0], xmm12
00007f582cdd22ee  vmovaps [rsp+0xD0], xmm13
00007f582cdd22f7  vmovaps [rsp+0xE0], xmm15
00007f582cdd2300  sub rsp, 0x30
00007f582cdd2304  movaps [rsp], xmm14
00007f582cdd2309  movaps [rsp+0x10], xmm11
00007f582cdd230f  movaps [rsp+0x20], xmm1
00007f582cdd2314  lea rdi, [rsp]
00007f582cdd2318  mov esi, 0x00
00007f582cdd231d  mov rax, 0x653B0D9BF530
00007f582cdd2327  call rax
00007f582cdd2329  movaps xmm14, [rsp]
00007f582cdd232e  add rsp, 0x30
00007f582cdd2332  vmovaps xmm0, [rsp]
00007f582cdd2337  vmovaps xmm1, [rsp+0x10]
00007f582cdd233d  vmovaps xmm2, [rsp+0x20]
00007f582cdd2343  vmovaps xmm3, [rsp+0x30]
00007f582cdd2349  vmovaps xmm4, [rsp+0x40]
00007f582cdd234f  vmovaps xmm5, [rsp+0x50]
00007f582cdd2355  vmovaps xmm6, [rsp+0x60]
00007f582cdd235b  vmovaps xmm7, [rsp+0x70]
00007f582cdd2361  vmovaps xmm8, [rsp+0x80]
00007f582cdd236a  vmovaps xmm9, [rsp+0x90]
00007f582cdd2373  vmovaps xmm10, [rsp+0xA0]
00007f582cdd237c  vmovaps xmm11, [rsp+0xB0]
00007f582cdd2385  vmovaps xmm12, [rsp+0xC0]
00007f582cdd238e  vmovaps xmm13, [rsp+0xD0]
00007f582cdd2397  vmovaps xmm15, [rsp+0xE0]
00007f582cdd23a0  add rsp, 0xF0
00007f582cdd23a7  pop r11
00007f582cdd23a9  pop r10
00007f582cdd23ab  pop r9
00007f582cdd23ad  pop r8
00007f582cdd23af  pop rsi
00007f582cdd23b0  pop rdi
00007f582cdd23b1  pop rdx
00007f582cdd23b2  pop rcx
00007f582cdd23b3  pop rax
00007f582cdd23b4  add rsp, 0x08
00007f582cdd23b8  jmp 0x00007F582CDCFC21
00007f582cdd23bd  sub rsp, 0x08
00007f582cdd23c1  push rax
00007f582cdd23c2  push rcx
00007f582cdd23c3  push rdx
00007f582cdd23c4  push rdi
00007f582cdd23c5  push rsi
00007f582cdd23c6  push r8
00007f582cdd23c8  push r9
00007f582cdd23ca  push r10
00007f582cdd23cc  push r11
00007f582cdd23ce  sub rsp, 0xF0
00007f582cdd23d5  vmovaps [rsp], xmm0
00007f582cdd23da  vmovaps [rsp+0x10], xmm1
00007f582cdd23e0  vmovaps [rsp+0x20], xmm2
00007f582cdd23e6  vmovaps [rsp+0x30], xmm3
00007f582cdd23ec  vmovaps [rsp+0x40], xmm4
00007f582cdd23f2  vmovaps [rsp+0x50], xmm5
00007f582cdd23f8  vmovaps [rsp+0x60], xmm6
00007f582cdd23fe  vmovaps [rsp+0x70], xmm7
00007f582cdd2404  vmovaps [rsp+0x80], xmm8
00007f582cdd240d  vmovaps [rsp+0x90], xmm9
00007f582cdd2416  vmovaps [rsp+0xA0], xmm10
00007f582cdd241f  vmovaps [rsp+0xB0], xmm11
00007f582cdd2428  vmovaps [rsp+0xC0], xmm12
00007f582cdd2431  vmovaps [rsp+0xD0], xmm14
00007f582cdd243a  vmovaps [rsp+0xE0], xmm15
00007f582cdd2443  sub rsp, 0x30
00007f582cdd2447  movaps [rsp], xmm13
00007f582cdd244c  movaps [rsp+0x10], xmm11
00007f582cdd2452  movaps [rsp+0x20], xmm1
00007f582cdd2457  lea rdi, [rsp]
00007f582cdd245b  mov esi, 0x00
00007f582cdd2460  mov rax, 0x653B0D9BF530
00007f582cdd246a  call rax
00007f582cdd246c  movaps xmm13, [rsp]
00007f582cdd2471  add rsp, 0x30
00007f582cdd2475  vmovaps xmm0, [rsp]
00007f582cdd247a  vmovaps xmm1, [rsp+0x10]
00007f582cdd2480  vmovaps xmm2, [rsp+0x20]
00007f582cdd2486  vmovaps xmm3, [rsp+0x30]
00007f582cdd248c  vmovaps xmm4, [rsp+0x40]
00007f582cdd2492  vmovaps xmm5, [rsp+0x50]
00007f582cdd2498  vmovaps xmm6, [rsp+0x60]
00007f582cdd249e  vmovaps xmm7, [rsp+0x70]
00007f582cdd24a4  vmovaps xmm8, [rsp+0x80]
00007f582cdd24ad  vmovaps xmm9, [rsp+0x90]
00007f582cdd24b6  vmovaps xmm10, [rsp+0xA0]
00007f582cdd24bf  vmovaps xmm11, [rsp+0xB0]
00007f582cdd24c8  vmovaps xmm12, [rsp+0xC0]
00007f582cdd24d1  vmovaps xmm14, [rsp+0xD0]
00007f582cdd24da  vmovaps xmm15, [rsp+0xE0]
00007f582cdd24e3  add rsp, 0xF0
00007f582cdd24ea  pop r11
00007f582cdd24ec  pop r10
00007f582cdd24ee  pop r9
00007f582cdd24f0  pop r8
00007f582cdd24f2  pop rsi
00007f582cdd24f3  pop rdi
00007f582cdd24f4  pop rdx
00007f582cdd24f5  pop rcx
00007f582cdd24f6  pop rax
00007f582cdd24f7  add rsp, 0x08
00007f582cdd24fb  jmp 0x00007F582CDCFC76
00007f582cdd2500  call 0x00007F582CBFF430
00007f582cdd2505  jmp 0x00007F582CDCFC83
00007f582cdd250a  sub rsp, 0x08
00007f582cdd250e  push rax
00007f582cdd250f  push rcx
00007f582cdd2510  push rdx
00007f582cdd2511  push rdi
00007f582cdd2512  push rsi
00007f582cdd2513  push r8
00007f582cdd2515  push r9
00007f582cdd2517  push r10
00007f582cdd2519  push r11
00007f582cdd251b  sub rsp, 0xF0
00007f582cdd2522  vmovaps [rsp], xmm0
00007f582cdd2527  vmovaps [rsp+0x10], xmm1
00007f582cdd252d  vmovaps [rsp+0x20], xmm2
00007f582cdd2533  vmovaps [rsp+0x30], xmm3
00007f582cdd2539  vmovaps [rsp+0x40], xmm4
00007f582cdd253f  vmovaps [rsp+0x50], xmm5
00007f582cdd2545  vmovaps [rsp+0x60], xmm6
00007f582cdd254b  vmovaps [rsp+0x70], xmm7
00007f582cdd2551  vmovaps [rsp+0x80], xmm8
00007f582cdd255a  vmovaps [rsp+0x90], xmm9
00007f582cdd2563  vmovaps [rsp+0xA0], xmm10
00007f582cdd256c  vmovaps [rsp+0xB0], xmm11
00007f582cdd2575  vmovaps [rsp+0xC0], xmm12
00007f582cdd257e  vmovaps [rsp+0xD0], xmm13
00007f582cdd2587  vmovaps [rsp+0xE0], xmm14
00007f582cdd2590  sub rsp, 0x30
00007f582cdd2594  movaps [rsp], xmm15
00007f582cdd2599  movaps [rsp+0x10], xmm11
00007f582cdd259f  movaps [rsp+0x20], xmm1
00007f582cdd25a4  lea rdi, [rsp]
00007f582cdd25a8  mov esi, 0x00
00007f582cdd25ad  mov rax, 0x653B0D9BF530
00007f582cdd25b7  call rax
00007f582cdd25b9  movaps xmm15, [rsp]
00007f582cdd25be  add rsp, 0x30
00007f582cdd25c2  vmovaps xmm0, [rsp]
00007f582cdd25c7  vmovaps xmm1, [rsp+0x10]
00007f582cdd25cd  vmovaps xmm2, [rsp+0x20]
00007f582cdd25d3  vmovaps xmm3, [rsp+0x30]
00007f582cdd25d9  vmovaps xmm4, [rsp+0x40]
00007f582cdd25df  vmovaps xmm5, [rsp+0x50]
00007f582cdd25e5  vmovaps xmm6, [rsp+0x60]
00007f582cdd25eb  vmovaps xmm7, [rsp+0x70]
00007f582cdd25f1  vmovaps xmm8, [rsp+0x80]
00007f582cdd25fa  vmovaps xmm9, [rsp+0x90]
00007f582cdd2603  vmovaps xmm10, [rsp+0xA0]
00007f582cdd260c  vmovaps xmm11, [rsp+0xB0]
00007f582cdd2615  vmovaps xmm12, [rsp+0xC0]
00007f582cdd261e  vmovaps xmm13, [rsp+0xD0]
00007f582cdd2627  vmovaps xmm14, [rsp+0xE0]
00007f582cdd2630  add rsp, 0xF0
00007f582cdd2637  pop r11
00007f582cdd2639  pop r10
00007f582cdd263b  pop r9
00007f582cdd263d  pop r8
00007f582cdd263f  pop rsi
00007f582cdd2640  pop rdi
00007f582cdd2641  pop rdx
00007f582cdd2642  pop rcx
00007f582cdd2643  pop rax
00007f582cdd2644  add rsp, 0x08
00007f582cdd2648  jmp 0x00007F582CDCFCBC
00007f582cdd264d  sub rsp, 0x08
00007f582cdd2651  push rax
00007f582cdd2652  push rcx
00007f582cdd2653  push rdx
00007f582cdd2654  push rdi
00007f582cdd2655  push rsi
00007f582cdd2656  push r8
00007f582cdd2658  push r9
00007f582cdd265a  push r10
00007f582cdd265c  push r11
00007f582cdd265e  sub rsp, 0xF0
00007f582cdd2665  vmovaps [rsp], xmm0
00007f582cdd266a  vmovaps [rsp+0x10], xmm1
00007f582cdd2670  vmovaps [rsp+0x20], xmm2
00007f582cdd2676  vmovaps [rsp+0x30], xmm3
00007f582cdd267c  vmovaps [rsp+0x40], xmm4
00007f582cdd2682  vmovaps [rsp+0x50], xmm5
00007f582cdd2688  vmovaps [rsp+0x60], xmm6
00007f582cdd268e  vmovaps [rsp+0x70], xmm7
00007f582cdd2694  vmovaps [rsp+0x80], xmm8
00007f582cdd269d  vmovaps [rsp+0x90], xmm9
00007f582cdd26a6  vmovaps [rsp+0xA0], xmm10
00007f582cdd26af  vmovaps [rsp+0xB0], xmm12
00007f582cdd26b8  vmovaps [rsp+0xC0], xmm13
00007f582cdd26c1  vmovaps [rsp+0xD0], xmm14
00007f582cdd26ca  vmovaps [rsp+0xE0], xmm15
00007f582cdd26d3  sub rsp, 0x30
00007f582cdd26d7  movaps [rsp], xmm11
00007f582cdd26dc  movaps [rsp+0x10], xmm6
00007f582cdd26e1  movaps [rsp+0x20], xmm14
00007f582cdd26e7  lea rdi, [rsp]
00007f582cdd26eb  mov esi, 0x00
00007f582cdd26f0  mov rax, 0x653B0D9BF530
00007f582cdd26fa  call rax
00007f582cdd26fc  movaps xmm11, [rsp]
00007f582cdd2701  add rsp, 0x30
00007f582cdd2705  vmovaps xmm0, [rsp]
00007f582cdd270a  vmovaps xmm1, [rsp+0x10]
00007f582cdd2710  vmovaps xmm2, [rsp+0x20]
00007f582cdd2716  vmovaps xmm3, [rsp+0x30]
00007f582cdd271c  vmovaps xmm4, [rsp+0x40]
00007f582cdd2722  vmovaps xmm5, [rsp+0x50]
00007f582cdd2728  vmovaps xmm6, [rsp+0x60]
00007f582cdd272e  vmovaps xmm7, [rsp+0x70]
00007f582cdd2734  vmovaps xmm8, [rsp+0x80]
00007f582cdd273d  vmovaps xmm9, [rsp+0x90]
00007f582cdd2746  vmovaps xmm10, [rsp+0xA0]
00007f582cdd274f  vmovaps xmm12, [rsp+0xB0]
00007f582cdd2758  vmovaps xmm13, [rsp+0xC0]
00007f582cdd2761  vmovaps xmm14, [rsp+0xD0]
00007f582cdd276a  vmovaps xmm15, [rsp+0xE0]
00007f582cdd2773  add rsp, 0xF0
00007f582cdd277a  pop r11
00007f582cdd277c  pop r10
00007f582cdd277e  pop r9
00007f582cdd2780  pop r8
00007f582cdd2782  pop rsi
00007f582cdd2783  pop rdi
00007f582cdd2784  pop rdx
00007f582cdd2785  pop rcx
00007f582cdd2786  pop rax
00007f582cdd2787  add rsp, 0x08
00007f582cdd278b  jmp 0x00007F582CDCFD34
00007f582cdd2790  call 0x00007F582CBFF430
00007f582cdd2795  jmp 0x00007F582CDCFD3E
00007f582cdd279a  sub rsp, 0x08
00007f582cdd279e  push rax
00007f582cdd279f  push rcx
00007f582cdd27a0  push rdx
00007f582cdd27a1  push rdi
00007f582cdd27a2  push rsi
00007f582cdd27a3  push r8
00007f582cdd27a5  push r9
00007f582cdd27a7  push r10
00007f582cdd27a9  push r11
00007f582cdd27ab  sub rsp, 0xF0
00007f582cdd27b2  vmovaps [rsp], xmm0
00007f582cdd27b7  vmovaps [rsp+0x10], xmm1
00007f582cdd27bd  vmovaps [rsp+0x20], xmm2
00007f582cdd27c3  vmovaps [rsp+0x30], xmm3
00007f582cdd27c9  vmovaps [rsp+0x40], xmm4
00007f582cdd27cf  vmovaps [rsp+0x50], xmm5
00007f582cdd27d5  vmovaps [rsp+0x60], xmm6
00007f582cdd27db  vmovaps [rsp+0x70], xmm7
00007f582cdd27e1  vmovaps [rsp+0x80], xmm8
00007f582cdd27ea  vmovaps [rsp+0x90], xmm9
00007f582cdd27f3  vmovaps [rsp+0xA0], xmm10
00007f582cdd27fc  vmovaps [rsp+0xB0], xmm11
00007f582cdd2805  vmovaps [rsp+0xC0], xmm12
00007f582cdd280e  vmovaps [rsp+0xD0], xmm13
00007f582cdd2817  vmovaps [rsp+0xE0], xmm15
00007f582cdd2820  sub rsp, 0x30
00007f582cdd2824  movaps [rsp], xmm14
00007f582cdd2829  movaps [rsp+0x10], xmm6
00007f582cdd282e  movaps [rsp+0x20], xmm2
00007f582cdd2833  lea rdi, [rsp]
00007f582cdd2837  mov esi, 0x00
00007f582cdd283c  mov rax, 0x653B0D9BF530
00007f582cdd2846  call rax
00007f582cdd2848  movaps xmm14, [rsp]
00007f582cdd284d  add rsp, 0x30
00007f582cdd2851  vmovaps xmm0, [rsp]
00007f582cdd2856  vmovaps xmm1, [rsp+0x10]
00007f582cdd285c  vmovaps xmm2, [rsp+0x20]
00007f582cdd2862  vmovaps xmm3, [rsp+0x30]
00007f582cdd2868  vmovaps xmm4, [rsp+0x40]
00007f582cdd286e  vmovaps xmm5, [rsp+0x50]
00007f582cdd2874  vmovaps xmm6, [rsp+0x60]
00007f582cdd287a  vmovaps xmm7, [rsp+0x70]
00007f582cdd2880  vmovaps xmm8, [rsp+0x80]
00007f582cdd2889  vmovaps xmm9, [rsp+0x90]
00007f582cdd2892  vmovaps xmm10, [rsp+0xA0]
00007f582cdd289b  vmovaps xmm11, [rsp+0xB0]
00007f582cdd28a4  vmovaps xmm12, [rsp+0xC0]
00007f582cdd28ad  vmovaps xmm13, [rsp+0xD0]
00007f582cdd28b6  vmovaps xmm15, [rsp+0xE0]
00007f582cdd28bf  add rsp, 0xF0
00007f582cdd28c6  pop r11
00007f582cdd28c8  pop r10
00007f582cdd28ca  pop r9
00007f582cdd28cc  pop r8
00007f582cdd28ce  pop rsi
00007f582cdd28cf  pop rdi
00007f582cdd28d0  pop rdx
00007f582cdd28d1  pop rcx
00007f582cdd28d2  pop rax
00007f582cdd28d3  add rsp, 0x08
00007f582cdd28d7  jmp 0x00007F582CDCFD72
00007f582cdd28dc  sub rsp, 0x08
00007f582cdd28e0  push rax
00007f582cdd28e1  push rcx
00007f582cdd28e2  push rdx
00007f582cdd28e3  push rdi
00007f582cdd28e4  push rsi
00007f582cdd28e5  push r8
00007f582cdd28e7  push r9
00007f582cdd28e9  push r10
00007f582cdd28eb  push r11
00007f582cdd28ed  sub rsp, 0xF0
00007f582cdd28f4  vmovaps [rsp], xmm0
00007f582cdd28f9  vmovaps [rsp+0x10], xmm1
00007f582cdd28ff  vmovaps [rsp+0x20], xmm2
00007f582cdd2905  vmovaps [rsp+0x30], xmm3
00007f582cdd290b  vmovaps [rsp+0x40], xmm4
00007f582cdd2911  vmovaps [rsp+0x50], xmm5
00007f582cdd2917  vmovaps [rsp+0x60], xmm7
00007f582cdd291d  vmovaps [rsp+0x70], xmm8
00007f582cdd2923  vmovaps [rsp+0x80], xmm9
00007f582cdd292c  vmovaps [rsp+0x90], xmm10
00007f582cdd2935  vmovaps [rsp+0xA0], xmm11
00007f582cdd293e  vmovaps [rsp+0xB0], xmm12
00007f582cdd2947  vmovaps [rsp+0xC0], xmm13
00007f582cdd2950  vmovaps [rsp+0xD0], xmm14
00007f582cdd2959  vmovaps [rsp+0xE0], xmm15
00007f582cdd2962  sub rsp, 0x30
00007f582cdd2966  movaps [rsp], xmm6
00007f582cdd296a  movaps [rsp+0x10], xmm5
00007f582cdd296f  movaps [rsp+0x20], xmm1
00007f582cdd2974  lea rdi, [rsp]
00007f582cdd2978  mov esi, 0x00
00007f582cdd297d  mov rax, 0x653B0D9BF530
00007f582cdd2987  call rax
00007f582cdd2989  movaps xmm6, [rsp]
00007f582cdd298d  add rsp, 0x30
00007f582cdd2991  vmovaps xmm0, [rsp]
00007f582cdd2996  vmovaps xmm1, [rsp+0x10]
00007f582cdd299c  vmovaps xmm2, [rsp+0x20]
00007f582cdd29a2  vmovaps xmm3, [rsp+0x30]
00007f582cdd29a8  vmovaps xmm4, [rsp+0x40]
00007f582cdd29ae  vmovaps xmm5, [rsp+0x50]
00007f582cdd29b4  vmovaps xmm7, [rsp+0x60]
00007f582cdd29ba  vmovaps xmm8, [rsp+0x70]
00007f582cdd29c0  vmovaps xmm9, [rsp+0x80]
00007f582cdd29c9  vmovaps xmm10, [rsp+0x90]
00007f582cdd29d2  vmovaps xmm11, [rsp+0xA0]
00007f582cdd29db  vmovaps xmm12, [rsp+0xB0]
00007f582cdd29e4  vmovaps xmm13, [rsp+0xC0]
00007f582cdd29ed  vmovaps xmm14, [rsp+0xD0]
00007f582cdd29f6  vmovaps xmm15, [rsp+0xE0]
00007f582cdd29ff  add rsp, 0xF0
00007f582cdd2a06  pop r11
00007f582cdd2a08  pop r10
00007f582cdd2a0a  pop r9
00007f582cdd2a0c  pop r8
00007f582cdd2a0e  pop rsi
00007f582cdd2a0f  pop rdi
00007f582cdd2a10  pop rdx
00007f582cdd2a11  pop rcx
00007f582cdd2a12  pop rax
00007f582cdd2a13  add rsp, 0x08
00007f582cdd2a17  jmp 0x00007F582CDCFD98
00007f582cdd2a1c  sub rsp, 0x08
00007f582cdd2a20  push rax
00007f582cdd2a21  push rcx
00007f582cdd2a22  push rdx
00007f582cdd2a23  push rdi
00007f582cdd2a24  push rsi
00007f582cdd2a25  push r8
00007f582cdd2a27  push r9
00007f582cdd2a29  push r10
00007f582cdd2a2b  push r11
00007f582cdd2a2d  sub rsp, 0xF0
00007f582cdd2a34  vmovaps [rsp], xmm0
00007f582cdd2a39  vmovaps [rsp+0x10], xmm2
00007f582cdd2a3f  vmovaps [rsp+0x20], xmm3
00007f582cdd2a45  vmovaps [rsp+0x30], xmm4
00007f582cdd2a4b  vmovaps [rsp+0x40], xmm5
00007f582cdd2a51  vmovaps [rsp+0x50], xmm6
00007f582cdd2a57  vmovaps [rsp+0x60], xmm7
00007f582cdd2a5d  vmovaps [rsp+0x70], xmm8
00007f582cdd2a63  vmovaps [rsp+0x80], xmm9
00007f582cdd2a6c  vmovaps [rsp+0x90], xmm10
00007f582cdd2a75  vmovaps [rsp+0xA0], xmm11
00007f582cdd2a7e  vmovaps [rsp+0xB0], xmm12
00007f582cdd2a87  vmovaps [rsp+0xC0], xmm13
00007f582cdd2a90  vmovaps [rsp+0xD0], xmm14
00007f582cdd2a99  vmovaps [rsp+0xE0], xmm15
00007f582cdd2aa2  sub rsp, 0x30
00007f582cdd2aa6  movaps [rsp], xmm1
00007f582cdd2aaa  movaps [rsp+0x10], xmm5
00007f582cdd2aaf  movaps [rsp+0x20], xmm13
00007f582cdd2ab5  lea rdi, [rsp]
00007f582cdd2ab9  mov esi, 0x00
00007f582cdd2abe  mov rax, 0x653B0D9BF530
00007f582cdd2ac8  call rax
00007f582cdd2aca  movaps xmm1, [rsp]
00007f582cdd2ace  add rsp, 0x30
00007f582cdd2ad2  vmovaps xmm0, [rsp]
00007f582cdd2ad7  vmovaps xmm2, [rsp+0x10]
00007f582cdd2add  vmovaps xmm3, [rsp+0x20]
00007f582cdd2ae3  vmovaps xmm4, [rsp+0x30]
00007f582cdd2ae9  vmovaps xmm5, [rsp+0x40]
00007f582cdd2aef  vmovaps xmm6, [rsp+0x50]
00007f582cdd2af5  vmovaps xmm7, [rsp+0x60]
00007f582cdd2afb  vmovaps xmm8, [rsp+0x70]
00007f582cdd2b01  vmovaps xmm9, [rsp+0x80]
00007f582cdd2b0a  vmovaps xmm10, [rsp+0x90]
00007f582cdd2b13  vmovaps xmm11, [rsp+0xA0]
00007f582cdd2b1c  vmovaps xmm12, [rsp+0xB0]
00007f582cdd2b25  vmovaps xmm13, [rsp+0xC0]
00007f582cdd2b2e  vmovaps xmm14, [rsp+0xD0]
00007f582cdd2b37  vmovaps xmm15, [rsp+0xE0]
00007f582cdd2b40  add rsp, 0xF0
00007f582cdd2b47  pop r11
00007f582cdd2b49  pop r10
00007f582cdd2b4b  pop r9
00007f582cdd2b4d  pop r8
00007f582cdd2b4f  pop rsi
00007f582cdd2b50  pop rdi
00007f582cdd2b51  pop rdx
00007f582cdd2b52  pop rcx
00007f582cdd2b53  pop rax
00007f582cdd2b54  add rsp, 0x08
00007f582cdd2b58  jmp 0x00007F582CDCFDB6
00007f582cdd2b5d  sub rsp, 0x08
00007f582cdd2b61  push rax
00007f582cdd2b62  push rcx
00007f582cdd2b63  push rdx
00007f582cdd2b64  push rdi
00007f582cdd2b65  push rsi
00007f582cdd2b66  push r8
00007f582cdd2b68  push r9
00007f582cdd2b6a  push r10
00007f582cdd2b6c  push r11
00007f582cdd2b6e  sub rsp, 0xF0
00007f582cdd2b75  vmovaps [rsp], xmm0
00007f582cdd2b7a  vmovaps [rsp+0x10], xmm1
00007f582cdd2b80  vmovaps [rsp+0x20], xmm2
00007f582cdd2b86  vmovaps [rsp+0x30], xmm3
00007f582cdd2b8c  vmovaps [rsp+0x40], xmm4
00007f582cdd2b92  vmovaps [rsp+0x50], xmm6
00007f582cdd2b98  vmovaps [rsp+0x60], xmm7
00007f582cdd2b9e  vmovaps [rsp+0x70], xmm8
00007f582cdd2ba4  vmovaps [rsp+0x80], xmm9
00007f582cdd2bad  vmovaps [rsp+0x90], xmm10
00007f582cdd2bb6  vmovaps [rsp+0xA0], xmm11
00007f582cdd2bbf  vmovaps [rsp+0xB0], xmm12
00007f582cdd2bc8  vmovaps [rsp+0xC0], xmm13
00007f582cdd2bd1  vmovaps [rsp+0xD0], xmm14
00007f582cdd2bda  vmovaps [rsp+0xE0], xmm15
00007f582cdd2be3  sub rsp, 0x30
00007f582cdd2be7  movaps [rsp], xmm5
00007f582cdd2beb  movaps [rsp+0x10], xmm2
00007f582cdd2bf0  movaps [rsp+0x20], xmm13
00007f582cdd2bf6  lea rdi, [rsp]
00007f582cdd2bfa  mov esi, 0x00
00007f582cdd2bff  mov rax, 0x653B0D9BF530
00007f582cdd2c09  call rax
00007f582cdd2c0b  movaps xmm5, [rsp]
00007f582cdd2c0f  add rsp, 0x30
00007f582cdd2c13  vmovaps xmm0, [rsp]
00007f582cdd2c18  vmovaps xmm1, [rsp+0x10]
00007f582cdd2c1e  vmovaps xmm2, [rsp+0x20]
00007f582cdd2c24  vmovaps xmm3, [rsp+0x30]
00007f582cdd2c2a  vmovaps xmm4, [rsp+0x40]
00007f582cdd2c30  vmovaps xmm6, [rsp+0x50]
00007f582cdd2c36  vmovaps xmm7, [rsp+0x60]
00007f582cdd2c3c  vmovaps xmm8, [rsp+0x70]
00007f582cdd2c42  vmovaps xmm9, [rsp+0x80]
00007f582cdd2c4b  vmovaps xmm10, [rsp+0x90]
00007f582cdd2c54  vmovaps xmm11, [rsp+0xA0]
00007f582cdd2c5d  vmovaps xmm12, [rsp+0xB0]
00007f582cdd2c66  vmovaps xmm13, [rsp+0xC0]
00007f582cdd2c6f  vmovaps xmm14, [rsp+0xD0]
00007f582cdd2c78  vmovaps xmm15, [rsp+0xE0]
00007f582cdd2c81  add rsp, 0xF0
00007f582cdd2c88  pop r11
00007f582cdd2c8a  pop r10
00007f582cdd2c8c  pop r9
00007f582cdd2c8e  pop r8
00007f582cdd2c90  pop rsi
00007f582cdd2c91  pop rdi
00007f582cdd2c92  pop rdx
00007f582cdd2c93  pop rcx
00007f582cdd2c94  pop rax
00007f582cdd2c95  add rsp, 0x08
00007f582cdd2c99  jmp 0x00007F582CDCFDEC
00007f582cdd2c9e  sub rsp, 0x08
00007f582cdd2ca2  push rax
00007f582cdd2ca3  push rcx
00007f582cdd2ca4  push rdx
00007f582cdd2ca5  push rdi
00007f582cdd2ca6  push rsi
00007f582cdd2ca7  push r8
00007f582cdd2ca9  push r9
00007f582cdd2cab  push r10
00007f582cdd2cad  push r11
00007f582cdd2caf  sub rsp, 0xF0
00007f582cdd2cb6  vmovaps [rsp], xmm0
00007f582cdd2cbb  vmovaps [rsp+0x10], xmm1
00007f582cdd2cc1  vmovaps [rsp+0x20], xmm2
00007f582cdd2cc7  vmovaps [rsp+0x30], xmm3
00007f582cdd2ccd  vmovaps [rsp+0x40], xmm4
00007f582cdd2cd3  vmovaps [rsp+0x50], xmm5
00007f582cdd2cd9  vmovaps [rsp+0x60], xmm6
00007f582cdd2cdf  vmovaps [rsp+0x70], xmm7
00007f582cdd2ce5  vmovaps [rsp+0x80], xmm8
00007f582cdd2cee  vmovaps [rsp+0x90], xmm9
00007f582cdd2cf7  vmovaps [rsp+0xA0], xmm10
00007f582cdd2d00  vmovaps [rsp+0xB0], xmm11
00007f582cdd2d09  vmovaps [rsp+0xC0], xmm12
00007f582cdd2d12  vmovaps [rsp+0xD0], xmm14
00007f582cdd2d1b  vmovaps [rsp+0xE0], xmm15
00007f582cdd2d24  sub rsp, 0x30
00007f582cdd2d28  movaps [rsp], xmm13
00007f582cdd2d2d  movaps [rsp+0x10], xmm10
00007f582cdd2d33  movaps [rsp+0x20], xmm1
00007f582cdd2d38  lea rdi, [rsp]
00007f582cdd2d3c  mov esi, 0x00
00007f582cdd2d41  mov rax, 0x653B0D9BF530
00007f582cdd2d4b  call rax
00007f582cdd2d4d  movaps xmm13, [rsp]
00007f582cdd2d52  add rsp, 0x30
00007f582cdd2d56  vmovaps xmm0, [rsp]
00007f582cdd2d5b  vmovaps xmm1, [rsp+0x10]
00007f582cdd2d61  vmovaps xmm2, [rsp+0x20]
00007f582cdd2d67  vmovaps xmm3, [rsp+0x30]
00007f582cdd2d6d  vmovaps xmm4, [rsp+0x40]
00007f582cdd2d73  vmovaps xmm5, [rsp+0x50]
00007f582cdd2d79  vmovaps xmm6, [rsp+0x60]
00007f582cdd2d7f  vmovaps xmm7, [rsp+0x70]
00007f582cdd2d85  vmovaps xmm8, [rsp+0x80]
00007f582cdd2d8e  vmovaps xmm9, [rsp+0x90]
00007f582cdd2d97  vmovaps xmm10, [rsp+0xA0]
00007f582cdd2da0  vmovaps xmm11, [rsp+0xB0]
00007f582cdd2da9  vmovaps xmm12, [rsp+0xC0]
00007f582cdd2db2  vmovaps xmm14, [rsp+0xD0]
00007f582cdd2dbb  vmovaps xmm15, [rsp+0xE0]
00007f582cdd2dc4  add rsp, 0xF0
00007f582cdd2dcb  pop r11
00007f582cdd2dcd  pop r10
00007f582cdd2dcf  pop r9
00007f582cdd2dd1  pop r8
00007f582cdd2dd3  pop rsi
00007f582cdd2dd4  pop rdi
00007f582cdd2dd5  pop rdx
00007f582cdd2dd6  pop rcx
00007f582cdd2dd7  pop rax
00007f582cdd2dd8  add rsp, 0x08
00007f582cdd2ddc  jmp 0x00007F582CDCFE15
00007f582cdd2de1  sub rsp, 0x08
00007f582cdd2de5  push rax
00007f582cdd2de6  push rcx
00007f582cdd2de7  push rdx
00007f582cdd2de8  push rdi
00007f582cdd2de9  push rsi
00007f582cdd2dea  push r8
00007f582cdd2dec  push r9
00007f582cdd2dee  push r10
00007f582cdd2df0  push r11
00007f582cdd2df2  sub rsp, 0xF0
00007f582cdd2df9  vmovaps [rsp], xmm0
00007f582cdd2dfe  vmovaps [rsp+0x10], xmm2
00007f582cdd2e04  vmovaps [rsp+0x20], xmm3
00007f582cdd2e0a  vmovaps [rsp+0x30], xmm4
00007f582cdd2e10  vmovaps [rsp+0x40], xmm5
00007f582cdd2e16  vmovaps [rsp+0x50], xmm6
00007f582cdd2e1c  vmovaps [rsp+0x60], xmm7
00007f582cdd2e22  vmovaps [rsp+0x70], xmm8
00007f582cdd2e28  vmovaps [rsp+0x80], xmm9
00007f582cdd2e31  vmovaps [rsp+0x90], xmm10
00007f582cdd2e3a  vmovaps [rsp+0xA0], xmm11
00007f582cdd2e43  vmovaps [rsp+0xB0], xmm12
00007f582cdd2e4c  vmovaps [rsp+0xC0], xmm13
00007f582cdd2e55  vmovaps [rsp+0xD0], xmm14
00007f582cdd2e5e  vmovaps [rsp+0xE0], xmm15
00007f582cdd2e67  sub rsp, 0x30
00007f582cdd2e6b  movaps [rsp], xmm1
00007f582cdd2e6f  movaps [rsp+0x10], xmm15
00007f582cdd2e75  movaps [rsp+0x20], xmm10
00007f582cdd2e7b  lea rdi, [rsp]
00007f582cdd2e7f  mov esi, 0x00
00007f582cdd2e84  mov rax, 0x653B0D9BF530
00007f582cdd2e8e  call rax
00007f582cdd2e90  movaps xmm1, [rsp]
00007f582cdd2e94  add rsp, 0x30
00007f582cdd2e98  vmovaps xmm0, [rsp]
00007f582cdd2e9d  vmovaps xmm2, [rsp+0x10]
00007f582cdd2ea3  vmovaps xmm3, [rsp+0x20]
00007f582cdd2ea9  vmovaps xmm4, [rsp+0x30]
00007f582cdd2eaf  vmovaps xmm5, [rsp+0x40]
00007f582cdd2eb5  vmovaps xmm6, [rsp+0x50]
00007f582cdd2ebb  vmovaps xmm7, [rsp+0x60]
00007f582cdd2ec1  vmovaps xmm8, [rsp+0x70]
00007f582cdd2ec7  vmovaps xmm9, [rsp+0x80]
00007f582cdd2ed0  vmovaps xmm10, [rsp+0x90]
00007f582cdd2ed9  vmovaps xmm11, [rsp+0xA0]
00007f582cdd2ee2  vmovaps xmm12, [rsp+0xB0]
00007f582cdd2eeb  vmovaps xmm13, [rsp+0xC0]
00007f582cdd2ef4  vmovaps xmm14, [rsp+0xD0]
00007f582cdd2efd  vmovaps xmm15, [rsp+0xE0]
00007f582cdd2f06  add rsp, 0xF0
00007f582cdd2f0d  pop r11
00007f582cdd2f0f  pop r10
00007f582cdd2f11  pop r9
00007f582cdd2f13  pop r8
00007f582cdd2f15  pop rsi
00007f582cdd2f16  pop rdi
00007f582cdd2f17  pop rdx
00007f582cdd2f18  pop rcx
00007f582cdd2f19  pop rax
00007f582cdd2f1a  add rsp, 0x08
00007f582cdd2f1e  jmp 0x00007F582CDCFE34
00007f582cdd2f23  sub rsp, 0x08
00007f582cdd2f27  push rax
00007f582cdd2f28  push rcx
00007f582cdd2f29  push rdx
00007f582cdd2f2a  push rdi
00007f582cdd2f2b  push rsi
00007f582cdd2f2c  push r8
00007f582cdd2f2e  push r9
00007f582cdd2f30  push r10
00007f582cdd2f32  push r11
00007f582cdd2f34  sub rsp, 0xF0
00007f582cdd2f3b  vmovaps [rsp], xmm0
00007f582cdd2f40  vmovaps [rsp+0x10], xmm1
00007f582cdd2f46  vmovaps [rsp+0x20], xmm2
00007f582cdd2f4c  vmovaps [rsp+0x30], xmm3
00007f582cdd2f52  vmovaps [rsp+0x40], xmm4
00007f582cdd2f58  vmovaps [rsp+0x50], xmm5
00007f582cdd2f5e  vmovaps [rsp+0x60], xmm6
00007f582cdd2f64  vmovaps [rsp+0x70], xmm7
00007f582cdd2f6a  vmovaps [rsp+0x80], xmm8
00007f582cdd2f73  vmovaps [rsp+0x90], xmm9
00007f582cdd2f7c  vmovaps [rsp+0xA0], xmm10
00007f582cdd2f85  vmovaps [rsp+0xB0], xmm11
00007f582cdd2f8e  vmovaps [rsp+0xC0], xmm12
00007f582cdd2f97  vmovaps [rsp+0xD0], xmm13
00007f582cdd2fa0  vmovaps [rsp+0xE0], xmm14
00007f582cdd2fa9  sub rsp, 0x30
00007f582cdd2fad  movaps [rsp], xmm15
00007f582cdd2fb2  movaps [rsp+0x10], xmm10
00007f582cdd2fb8  movaps [rsp+0x20], xmm11
00007f582cdd2fbe  lea rdi, [rsp]
00007f582cdd2fc2  mov esi, 0x00
00007f582cdd2fc7  mov rax, 0x653B0D9BF530
00007f582cdd2fd1  call rax
00007f582cdd2fd3  movaps xmm15, [rsp]
00007f582cdd2fd8  add rsp, 0x30
00007f582cdd2fdc  vmovaps xmm0, [rsp]
00007f582cdd2fe1  vmovaps xmm1, [rsp+0x10]
00007f582cdd2fe7  vmovaps xmm2, [rsp+0x20]
00007f582cdd2fed  vmovaps xmm3, [rsp+0x30]
00007f582cdd2ff3  vmovaps xmm4, [rsp+0x40]
00007f582cdd2ff9  vmovaps xmm5, [rsp+0x50]
00007f582cdd2fff  vmovaps xmm6, [rsp+0x60]
00007f582cdd3005  vmovaps xmm7, [rsp+0x70]
00007f582cdd300b  vmovaps xmm8, [rsp+0x80]
00007f582cdd3014  vmovaps xmm9, [rsp+0x90]
00007f582cdd301d  vmovaps xmm10, [rsp+0xA0]
00007f582cdd3026  vmovaps xmm11, [rsp+0xB0]
00007f582cdd302f  vmovaps xmm12, [rsp+0xC0]
00007f582cdd3038  vmovaps xmm13, [rsp+0xD0]
00007f582cdd3041  vmovaps xmm14, [rsp+0xE0]
00007f582cdd304a  add rsp, 0xF0
00007f582cdd3051  pop r11
00007f582cdd3053  pop r10
00007f582cdd3055  pop r9
00007f582cdd3057  pop r8
00007f582cdd3059  pop rsi
00007f582cdd305a  pop rdi
00007f582cdd305b  pop rdx
00007f582cdd305c  pop rcx
00007f582cdd305d  pop rax
00007f582cdd305e  add rsp, 0x08
00007f582cdd3062  jmp 0x00007F582CDCFE57
00007f582cdd3067  sub rsp, 0x08
00007f582cdd306b  push rax
00007f582cdd306c  push rcx
00007f582cdd306d  push rdx
00007f582cdd306e  push rdi
00007f582cdd306f  push rsi
00007f582cdd3070  push r8
00007f582cdd3072  push r9
00007f582cdd3074  push r10
00007f582cdd3076  push r11
00007f582cdd3078  sub rsp, 0xF0
00007f582cdd307f  vmovaps [rsp], xmm0
00007f582cdd3084  vmovaps [rsp+0x10], xmm1
00007f582cdd308a  vmovaps [rsp+0x20], xmm2
00007f582cdd3090  vmovaps [rsp+0x30], xmm3
00007f582cdd3096  vmovaps [rsp+0x40], xmm4
00007f582cdd309c  vmovaps [rsp+0x50], xmm5
00007f582cdd30a2  vmovaps [rsp+0x60], xmm6
00007f582cdd30a8  vmovaps [rsp+0x70], xmm7
00007f582cdd30ae  vmovaps [rsp+0x80], xmm8
00007f582cdd30b7  vmovaps [rsp+0x90], xmm9
00007f582cdd30c0  vmovaps [rsp+0xA0], xmm11
00007f582cdd30c9  vmovaps [rsp+0xB0], xmm12
00007f582cdd30d2  vmovaps [rsp+0xC0], xmm13
00007f582cdd30db  vmovaps [rsp+0xD0], xmm14
00007f582cdd30e4  vmovaps [rsp+0xE0], xmm15
00007f582cdd30ed  sub rsp, 0x30
00007f582cdd30f1  movaps [rsp], xmm10
00007f582cdd30f6  movaps [rsp+0x10], xmm12
00007f582cdd30fc  movaps [rsp+0x20], xmm11
00007f582cdd3102  lea rdi, [rsp]
00007f582cdd3106  mov esi, 0x00
00007f582cdd310b  mov rax, 0x653B0D9BF530
00007f582cdd3115  call rax
00007f582cdd3117  movaps xmm10, [rsp]
00007f582cdd311c  add rsp, 0x30
00007f582cdd3120  vmovaps xmm0, [rsp]
00007f582cdd3125  vmovaps xmm1, [rsp+0x10]
00007f582cdd312b  vmovaps xmm2, [rsp+0x20]
00007f582cdd3131  vmovaps xmm3, [rsp+0x30]
00007f582cdd3137  vmovaps xmm4, [rsp+0x40]
00007f582cdd313d  vmovaps xmm5, [rsp+0x50]
00007f582cdd3143  vmovaps xmm6, [rsp+0x60]
00007f582cdd3149  vmovaps xmm7, [rsp+0x70]
00007f582cdd314f  vmovaps xmm8, [rsp+0x80]
00007f582cdd3158  vmovaps xmm9, [rsp+0x90]
00007f582cdd3161  vmovaps xmm11, [rsp+0xA0]
00007f582cdd316a  vmovaps xmm12, [rsp+0xB0]
00007f582cdd3173  vmovaps xmm13, [rsp+0xC0]
00007f582cdd317c  vmovaps xmm14, [rsp+0xD0]
00007f582cdd3185  vmovaps xmm15, [rsp+0xE0]
00007f582cdd318e  add rsp, 0xF0
00007f582cdd3195  pop r11
00007f582cdd3197  pop r10
00007f582cdd3199  pop r9
00007f582cdd319b  pop r8
00007f582cdd319d  pop rsi
00007f582cdd319e  pop rdi
00007f582cdd319f  pop rdx
00007f582cdd31a0  pop rcx
00007f582cdd31a1  pop rax
00007f582cdd31a2  add rsp, 0x08
00007f582cdd31a6  jmp 0x00007F582CDCFE80
00007f582cdd31ab  sub rsp, 0x08
00007f582cdd31af  push rax
00007f582cdd31b0  push rcx
00007f582cdd31b1  push rdx
00007f582cdd31b2  push rdi
00007f582cdd31b3  push rsi
00007f582cdd31b4  push r8
00007f582cdd31b6  push r9
00007f582cdd31b8  push r10
00007f582cdd31ba  push r11
00007f582cdd31bc  sub rsp, 0xF0
00007f582cdd31c3  vmovaps [rsp], xmm0
00007f582cdd31c8  vmovaps [rsp+0x10], xmm1
00007f582cdd31ce  vmovaps [rsp+0x20], xmm2
00007f582cdd31d4  vmovaps [rsp+0x30], xmm3
00007f582cdd31da  vmovaps [rsp+0x40], xmm4
00007f582cdd31e0  vmovaps [rsp+0x50], xmm5
00007f582cdd31e6  vmovaps [rsp+0x60], xmm6
00007f582cdd31ec  vmovaps [rsp+0x70], xmm7
00007f582cdd31f2  vmovaps [rsp+0x80], xmm8
00007f582cdd31fb  vmovaps [rsp+0x90], xmm9
00007f582cdd3204  vmovaps [rsp+0xA0], xmm10
00007f582cdd320d  vmovaps [rsp+0xB0], xmm12
00007f582cdd3216  vmovaps [rsp+0xC0], xmm13
00007f582cdd321f  vmovaps [rsp+0xD0], xmm14
00007f582cdd3228  vmovaps [rsp+0xE0], xmm15
00007f582cdd3231  sub rsp, 0x30
00007f582cdd3235  movaps [rsp], xmm11
00007f582cdd323a  movaps [rsp+0x10], xmm2
00007f582cdd323f  movaps [rsp+0x20], xmm12
00007f582cdd3245  lea rdi, [rsp]
00007f582cdd3249  mov esi, 0x00
00007f582cdd324e  mov rax, 0x653B0D9BF530
00007f582cdd3258  call rax
00007f582cdd325a  movaps xmm11, [rsp]
00007f582cdd325f  add rsp, 0x30
00007f582cdd3263  vmovaps xmm0, [rsp]
00007f582cdd3268  vmovaps xmm1, [rsp+0x10]
00007f582cdd326e  vmovaps xmm2, [rsp+0x20]
00007f582cdd3274  vmovaps xmm3, [rsp+0x30]
00007f582cdd327a  vmovaps xmm4, [rsp+0x40]
00007f582cdd3280  vmovaps xmm5, [rsp+0x50]
00007f582cdd3286  vmovaps xmm6, [rsp+0x60]
00007f582cdd328c  vmovaps xmm7, [rsp+0x70]
00007f582cdd3292  vmovaps xmm8, [rsp+0x80]
00007f582cdd329b  vmovaps xmm9, [rsp+0x90]
00007f582cdd32a4  vmovaps xmm10, [rsp+0xA0]
00007f582cdd32ad  vmovaps xmm12, [rsp+0xB0]
00007f582cdd32b6  vmovaps xmm13, [rsp+0xC0]
00007f582cdd32bf  vmovaps xmm14, [rsp+0xD0]
00007f582cdd32c8  vmovaps xmm15, [rsp+0xE0]
00007f582cdd32d1  add rsp, 0xF0
00007f582cdd32d8  pop r11
00007f582cdd32da  pop r10
00007f582cdd32dc  pop r9
00007f582cdd32de  pop r8
00007f582cdd32e0  pop rsi
00007f582cdd32e1  pop rdi
00007f582cdd32e2  pop rdx
00007f582cdd32e3  pop rcx
00007f582cdd32e4  pop rax
00007f582cdd32e5  add rsp, 0x08
00007f582cdd32e9  jmp 0x00007F582CDCFEB8
00007f582cdd32ee  sub rsp, 0x08
00007f582cdd32f2  push rax
00007f582cdd32f3  push rcx
00007f582cdd32f4  push rdx
00007f582cdd32f5  push rdi
00007f582cdd32f6  push rsi
00007f582cdd32f7  push r8
00007f582cdd32f9  push r9
00007f582cdd32fb  push r10
00007f582cdd32fd  push r11
00007f582cdd32ff  sub rsp, 0xF0
00007f582cdd3306  vmovaps [rsp], xmm0
00007f582cdd330b  vmovaps [rsp+0x10], xmm2
00007f582cdd3311  vmovaps [rsp+0x20], xmm3
00007f582cdd3317  vmovaps [rsp+0x30], xmm4
00007f582cdd331d  vmovaps [rsp+0x40], xmm5
00007f582cdd3323  vmovaps [rsp+0x50], xmm6
00007f582cdd3329  vmovaps [rsp+0x60], xmm7
00007f582cdd332f  vmovaps [rsp+0x70], xmm8
00007f582cdd3335  vmovaps [rsp+0x80], xmm9
00007f582cdd333e  vmovaps [rsp+0x90], xmm10
00007f582cdd3347  vmovaps [rsp+0xA0], xmm11
00007f582cdd3350  vmovaps [rsp+0xB0], xmm12
00007f582cdd3359  vmovaps [rsp+0xC0], xmm13
00007f582cdd3362  vmovaps [rsp+0xD0], xmm14
00007f582cdd336b  vmovaps [rsp+0xE0], xmm15
00007f582cdd3374  sub rsp, 0x30
00007f582cdd3378  movaps [rsp], xmm1
00007f582cdd337c  movaps [rsp+0x10], xmm14
00007f582cdd3382  movaps [rsp+0x20], xmm6
00007f582cdd3387  lea rdi, [rsp]
00007f582cdd338b  mov esi, 0x00
00007f582cdd3390  mov rax, 0x653B0D9BF530
00007f582cdd339a  call rax
00007f582cdd339c  movaps xmm1, [rsp]
00007f582cdd33a0  add rsp, 0x30
00007f582cdd33a4  vmovaps xmm0, [rsp]
00007f582cdd33a9  vmovaps xmm2, [rsp+0x10]
00007f582cdd33af  vmovaps xmm3, [rsp+0x20]
00007f582cdd33b5  vmovaps xmm4, [rsp+0x30]
00007f582cdd33bb  vmovaps xmm5, [rsp+0x40]
00007f582cdd33c1  vmovaps xmm6, [rsp+0x50]
00007f582cdd33c7  vmovaps xmm7, [rsp+0x60]
00007f582cdd33cd  vmovaps xmm8, [rsp+0x70]
00007f582cdd33d3  vmovaps xmm9, [rsp+0x80]
00007f582cdd33dc  vmovaps xmm10, [rsp+0x90]
00007f582cdd33e5  vmovaps xmm11, [rsp+0xA0]
00007f582cdd33ee  vmovaps xmm12, [rsp+0xB0]
00007f582cdd33f7  vmovaps xmm13, [rsp+0xC0]
00007f582cdd3400  vmovaps xmm14, [rsp+0xD0]
00007f582cdd3409  vmovaps xmm15, [rsp+0xE0]
00007f582cdd3412  add rsp, 0xF0
00007f582cdd3419  pop r11
00007f582cdd341b  pop r10
00007f582cdd341d  pop r9
00007f582cdd341f  pop r8
00007f582cdd3421  pop rsi
00007f582cdd3422  pop rdi
00007f582cdd3423  pop rdx
00007f582cdd3424  pop rcx
00007f582cdd3425  pop rax
00007f582cdd3426  add rsp, 0x08
00007f582cdd342a  jmp 0x00007F582CDCFED1
00007f582cdd342f  sub rsp, 0x08
00007f582cdd3433  push rax
00007f582cdd3434  push rcx
00007f582cdd3435  push rdx
00007f582cdd3436  push rdi
00007f582cdd3437  push rsi
00007f582cdd3438  push r8
00007f582cdd343a  push r9
00007f582cdd343c  push r10
00007f582cdd343e  push r11
00007f582cdd3440  sub rsp, 0xF0
00007f582cdd3447  vmovaps [rsp], xmm0
00007f582cdd344c  vmovaps [rsp+0x10], xmm1
00007f582cdd3452  vmovaps [rsp+0x20], xmm2
00007f582cdd3458  vmovaps [rsp+0x30], xmm3
00007f582cdd345e  vmovaps [rsp+0x40], xmm4
00007f582cdd3464  vmovaps [rsp+0x50], xmm5
00007f582cdd346a  vmovaps [rsp+0x60], xmm6
00007f582cdd3470  vmovaps [rsp+0x70], xmm7
00007f582cdd3476  vmovaps [rsp+0x80], xmm8
00007f582cdd347f  vmovaps [rsp+0x90], xmm9
00007f582cdd3488  vmovaps [rsp+0xA0], xmm10
00007f582cdd3491  vmovaps [rsp+0xB0], xmm11
00007f582cdd349a  vmovaps [rsp+0xC0], xmm12
00007f582cdd34a3  vmovaps [rsp+0xD0], xmm13
00007f582cdd34ac  vmovaps [rsp+0xE0], xmm15
00007f582cdd34b5  sub rsp, 0x30
00007f582cdd34b9  movaps [rsp], xmm14
00007f582cdd34be  movaps [rsp+0x10], xmm12
00007f582cdd34c4  movaps [rsp+0x20], xmm5
00007f582cdd34c9  lea rdi, [rsp]
00007f582cdd34cd  mov esi, 0x00
00007f582cdd34d2  mov rax, 0x653B0D9BF530
00007f582cdd34dc  call rax
00007f582cdd34de  movaps xmm14, [rsp]
00007f582cdd34e3  add rsp, 0x30
00007f582cdd34e7  vmovaps xmm0, [rsp]
00007f582cdd34ec  vmovaps xmm1, [rsp+0x10]
00007f582cdd34f2  vmovaps xmm2, [rsp+0x20]
00007f582cdd34f8  vmovaps xmm3, [rsp+0x30]
00007f582cdd34fe  vmovaps xmm4, [rsp+0x40]
00007f582cdd3504  vmovaps xmm5, [rsp+0x50]
00007f582cdd350a  vmovaps xmm6, [rsp+0x60]
00007f582cdd3510  vmovaps xmm7, [rsp+0x70]
00007f582cdd3516  vmovaps xmm8, [rsp+0x80]
00007f582cdd351f  vmovaps xmm9, [rsp+0x90]
00007f582cdd3528  vmovaps xmm10, [rsp+0xA0]
00007f582cdd3531  vmovaps xmm11, [rsp+0xB0]
00007f582cdd353a  vmovaps xmm12, [rsp+0xC0]
00007f582cdd3543  vmovaps xmm13, [rsp+0xD0]
00007f582cdd354c  vmovaps xmm15, [rsp+0xE0]
00007f582cdd3555  add rsp, 0xF0
00007f582cdd355c  pop r11
00007f582cdd355e  pop r10
00007f582cdd3560  pop r9
00007f582cdd3562  pop r8
00007f582cdd3564  pop rsi
00007f582cdd3565  pop rdi
00007f582cdd3566  pop rdx
00007f582cdd3567  pop rcx
00007f582cdd3568  pop rax
00007f582cdd3569  add rsp, 0x08
00007f582cdd356d  jmp 0x00007F582CDCFEF1
00007f582cdd3572  sub rsp, 0x08
00007f582cdd3576  push rax
00007f582cdd3577  push rcx
00007f582cdd3578  push rdx
00007f582cdd3579  push rdi
00007f582cdd357a  push rsi
00007f582cdd357b  push r8
00007f582cdd357d  push r9
00007f582cdd357f  push r10
00007f582cdd3581  push r11
00007f582cdd3583  sub rsp, 0xF0
00007f582cdd358a  vmovaps [rsp], xmm0
00007f582cdd358f  vmovaps [rsp+0x10], xmm1
00007f582cdd3595  vmovaps [rsp+0x20], xmm2
00007f582cdd359b  vmovaps [rsp+0x30], xmm3
00007f582cdd35a1  vmovaps [rsp+0x40], xmm4
00007f582cdd35a7  vmovaps [rsp+0x50], xmm5
00007f582cdd35ad  vmovaps [rsp+0x60], xmm7
00007f582cdd35b3  vmovaps [rsp+0x70], xmm8
00007f582cdd35b9  vmovaps [rsp+0x80], xmm9
00007f582cdd35c2  vmovaps [rsp+0x90], xmm10
00007f582cdd35cb  vmovaps [rsp+0xA0], xmm11
00007f582cdd35d4  vmovaps [rsp+0xB0], xmm12
00007f582cdd35dd  vmovaps [rsp+0xC0], xmm13
00007f582cdd35e6  vmovaps [rsp+0xD0], xmm14
00007f582cdd35ef  vmovaps [rsp+0xE0], xmm15
00007f582cdd35f8  sub rsp, 0x30
00007f582cdd35fc  movaps [rsp], xmm6
00007f582cdd3600  movaps [rsp+0x10], xmm9
00007f582cdd3606  movaps [rsp+0x20], xmm12
00007f582cdd360c  lea rdi, [rsp]
00007f582cdd3610  mov esi, 0x00
00007f582cdd3615  mov rax, 0x653B0D9BF530
00007f582cdd361f  call rax
00007f582cdd3621  movaps xmm6, [rsp]
00007f582cdd3625  add rsp, 0x30
00007f582cdd3629  vmovaps xmm0, [rsp]
00007f582cdd362e  vmovaps xmm1, [rsp+0x10]
00007f582cdd3634  vmovaps xmm2, [rsp+0x20]
00007f582cdd363a  vmovaps xmm3, [rsp+0x30]
00007f582cdd3640  vmovaps xmm4, [rsp+0x40]
00007f582cdd3646  vmovaps xmm5, [rsp+0x50]
00007f582cdd364c  vmovaps xmm7, [rsp+0x60]
00007f582cdd3652  vmovaps xmm8, [rsp+0x70]
00007f582cdd3658  vmovaps xmm9, [rsp+0x80]
00007f582cdd3661  vmovaps xmm10, [rsp+0x90]
00007f582cdd366a  vmovaps xmm11, [rsp+0xA0]
00007f582cdd3673  vmovaps xmm12, [rsp+0xB0]
00007f582cdd367c  vmovaps xmm13, [rsp+0xC0]
00007f582cdd3685  vmovaps xmm14, [rsp+0xD0]
00007f582cdd368e  vmovaps xmm15, [rsp+0xE0]
00007f582cdd3697  add rsp, 0xF0
00007f582cdd369e  pop r11
00007f582cdd36a0  pop r10
00007f582cdd36a2  pop r9
00007f582cdd36a4  pop r8
00007f582cdd36a6  pop rsi
00007f582cdd36a7  pop rdi
00007f582cdd36a8  pop rdx
00007f582cdd36a9  pop rcx
00007f582cdd36aa  pop rax
00007f582cdd36ab  add rsp, 0x08
00007f582cdd36af  jmp 0x00007F582CDCFF19
00007f582cdd36b4  sub rsp, 0x08
00007f582cdd36b8  push rax
00007f582cdd36b9  push rcx
00007f582cdd36ba  push rdx
00007f582cdd36bb  push rdi
00007f582cdd36bc  push rsi
00007f582cdd36bd  push r8
00007f582cdd36bf  push r9
00007f582cdd36c1  push r10
00007f582cdd36c3  push r11
00007f582cdd36c5  sub rsp, 0xF0
00007f582cdd36cc  vmovaps [rsp], xmm0
00007f582cdd36d1  vmovaps [rsp+0x10], xmm1
00007f582cdd36d7  vmovaps [rsp+0x20], xmm2
00007f582cdd36dd  vmovaps [rsp+0x30], xmm3
00007f582cdd36e3  vmovaps [rsp+0x40], xmm4
00007f582cdd36e9  vmovaps [rsp+0x50], xmm5
00007f582cdd36ef  vmovaps [rsp+0x60], xmm6
00007f582cdd36f5  vmovaps [rsp+0x70], xmm7
00007f582cdd36fb  vmovaps [rsp+0x80], xmm8
00007f582cdd3704  vmovaps [rsp+0x90], xmm9
00007f582cdd370d  vmovaps [rsp+0xA0], xmm10
00007f582cdd3716  vmovaps [rsp+0xB0], xmm11
00007f582cdd371f  vmovaps [rsp+0xC0], xmm13
00007f582cdd3728  vmovaps [rsp+0xD0], xmm14
00007f582cdd3731  vmovaps [rsp+0xE0], xmm15
00007f582cdd373a  sub rsp, 0x30
00007f582cdd373e  movaps [rsp], xmm12
00007f582cdd3743  movaps [rsp+0x10], xmm15
00007f582cdd3749  movaps [rsp+0x20], xmm13
00007f582cdd374f  lea rdi, [rsp]
00007f582cdd3753  mov esi, 0x00
00007f582cdd3758  mov rax, 0x653B0D9BF530
00007f582cdd3762  call rax
00007f582cdd3764  movaps xmm12, [rsp]
00007f582cdd3769  add rsp, 0x30
00007f582cdd376d  vmovaps xmm0, [rsp]
00007f582cdd3772  vmovaps xmm1, [rsp+0x10]
00007f582cdd3778  vmovaps xmm2, [rsp+0x20]
00007f582cdd377e  vmovaps xmm3, [rsp+0x30]
00007f582cdd3784  vmovaps xmm4, [rsp+0x40]
00007f582cdd378a  vmovaps xmm5, [rsp+0x50]
00007f582cdd3790  vmovaps xmm6, [rsp+0x60]
00007f582cdd3796  vmovaps xmm7, [rsp+0x70]
00007f582cdd379c  vmovaps xmm8, [rsp+0x80]
00007f582cdd37a5  vmovaps xmm9, [rsp+0x90]
00007f582cdd37ae  vmovaps xmm10, [rsp+0xA0]
00007f582cdd37b7  vmovaps xmm11, [rsp+0xB0]
00007f582cdd37c0  vmovaps xmm13, [rsp+0xC0]
00007f582cdd37c9  vmovaps xmm14, [rsp+0xD0]
00007f582cdd37d2  vmovaps xmm15, [rsp+0xE0]
00007f582cdd37db  add rsp, 0xF0
00007f582cdd37e2  pop r11
00007f582cdd37e4  pop r10
00007f582cdd37e6  pop r9
00007f582cdd37e8  pop r8
00007f582cdd37ea  pop rsi
00007f582cdd37eb  pop rdi
00007f582cdd37ec  pop rdx
00007f582cdd37ed  pop rcx
00007f582cdd37ee  pop rax
00007f582cdd37ef  add rsp, 0x08
00007f582cdd37f3  jmp 0x00007F582CDCFF34
00007f582cdd37f8  sub rsp, 0x08
00007f582cdd37fc  push rax
00007f582cdd37fd  push rcx
00007f582cdd37fe  push rdx
00007f582cdd37ff  push rdi
00007f582cdd3800  push rsi
00007f582cdd3801  push r8
00007f582cdd3803  push r9
00007f582cdd3805  push r10
00007f582cdd3807  push r11
00007f582cdd3809  sub rsp, 0xF0
00007f582cdd3810  vmovaps [rsp], xmm0
00007f582cdd3815  vmovaps [rsp+0x10], xmm1
00007f582cdd381b  vmovaps [rsp+0x20], xmm2
00007f582cdd3821  vmovaps [rsp+0x30], xmm3
00007f582cdd3827  vmovaps [rsp+0x40], xmm4
00007f582cdd382d  vmovaps [rsp+0x50], xmm5
00007f582cdd3833  vmovaps [rsp+0x60], xmm6
00007f582cdd3839  vmovaps [rsp+0x70], xmm7
00007f582cdd383f  vmovaps [rsp+0x80], xmm8
00007f582cdd3848  vmovaps [rsp+0x90], xmm9
00007f582cdd3851  vmovaps [rsp+0xA0], xmm10
00007f582cdd385a  vmovaps [rsp+0xB0], xmm11
00007f582cdd3863  vmovaps [rsp+0xC0], xmm12
00007f582cdd386c  vmovaps [rsp+0xD0], xmm13
00007f582cdd3875  vmovaps [rsp+0xE0], xmm14
00007f582cdd387e  sub rsp, 0x30
00007f582cdd3882  movaps [rsp], xmm15
00007f582cdd3887  movaps [rsp+0x10], xmm13
00007f582cdd388d  movaps [rsp+0x20], xmm10
00007f582cdd3893  lea rdi, [rsp]
00007f582cdd3897  mov esi, 0x00
00007f582cdd389c  mov rax, 0x653B0D9BF530
00007f582cdd38a6  call rax
00007f582cdd38a8  movaps xmm15, [rsp]
00007f582cdd38ad  add rsp, 0x30
00007f582cdd38b1  vmovaps xmm0, [rsp]
00007f582cdd38b6  vmovaps xmm1, [rsp+0x10]
00007f582cdd38bc  vmovaps xmm2, [rsp+0x20]
00007f582cdd38c2  vmovaps xmm3, [rsp+0x30]
00007f582cdd38c8  vmovaps xmm4, [rsp+0x40]
00007f582cdd38ce  vmovaps xmm5, [rsp+0x50]
00007f582cdd38d4  vmovaps xmm6, [rsp+0x60]
00007f582cdd38da  vmovaps xmm7, [rsp+0x70]
00007f582cdd38e0  vmovaps xmm8, [rsp+0x80]
00007f582cdd38e9  vmovaps xmm9, [rsp+0x90]
00007f582cdd38f2  vmovaps xmm10, [rsp+0xA0]
00007f582cdd38fb  vmovaps xmm11, [rsp+0xB0]
00007f582cdd3904  vmovaps xmm12, [rsp+0xC0]
00007f582cdd390d  vmovaps xmm13, [rsp+0xD0]
00007f582cdd3916  vmovaps xmm14, [rsp+0xE0]
00007f582cdd391f  add rsp, 0xF0
00007f582cdd3926  pop r11
00007f582cdd3928  pop r10
00007f582cdd392a  pop r9
00007f582cdd392c  pop r8
00007f582cdd392e  pop rsi
00007f582cdd392f  pop rdi
00007f582cdd3930  pop rdx
00007f582cdd3931  pop rcx
00007f582cdd3932  pop rax
00007f582cdd3933  add rsp, 0x08
00007f582cdd3937  jmp 0x00007F582CDCFF55
00007f582cdd393c  call 0x00007F582CC0C260
00007f582cdd3941  jmp 0x00007F582CDCFFB0
00007f582cdd3946  sub rsp, 0x08
00007f582cdd394a  push rax
00007f582cdd394b  push rcx
00007f582cdd394c  push rdx
00007f582cdd394d  push rdi
00007f582cdd394e  push rsi
00007f582cdd394f  push r8
00007f582cdd3951  push r9
00007f582cdd3953  push r10
00007f582cdd3955  push r11
00007f582cdd3957  sub rsp, 0xF0
00007f582cdd395e  vmovaps [rsp], xmm0
00007f582cdd3963  vmovaps [rsp+0x10], xmm1
00007f582cdd3969  vmovaps [rsp+0x20], xmm2
00007f582cdd396f  vmovaps [rsp+0x30], xmm3
00007f582cdd3975  vmovaps [rsp+0x40], xmm4
00007f582cdd397b  vmovaps [rsp+0x50], xmm5
00007f582cdd3981  vmovaps [rsp+0x60], xmm6
00007f582cdd3987  vmovaps [rsp+0x70], xmm7
00007f582cdd398d  vmovaps [rsp+0x80], xmm8
00007f582cdd3996  vmovaps [rsp+0x90], xmm10
00007f582cdd399f  vmovaps [rsp+0xA0], xmm11
00007f582cdd39a8  vmovaps [rsp+0xB0], xmm12
00007f582cdd39b1  vmovaps [rsp+0xC0], xmm13
00007f582cdd39ba  vmovaps [rsp+0xD0], xmm14
00007f582cdd39c3  vmovaps [rsp+0xE0], xmm15
00007f582cdd39cc  sub rsp, 0x30
00007f582cdd39d0  movaps [rsp], xmm9
00007f582cdd39d5  movaps [rsp+0x10], xmm8
00007f582cdd39db  movaps [rsp+0x20], xmm10
00007f582cdd39e1  lea rdi, [rsp]
00007f582cdd39e5  mov esi, 0x00
00007f582cdd39ea  mov rax, 0x653B0D9BF530
00007f582cdd39f4  call rax
00007f582cdd39f6  movaps xmm9, [rsp]
00007f582cdd39fb  add rsp, 0x30
00007f582cdd39ff  vmovaps xmm0, [rsp]
00007f582cdd3a04  vmovaps xmm1, [rsp+0x10]
00007f582cdd3a0a  vmovaps xmm2, [rsp+0x20]
00007f582cdd3a10  vmovaps xmm3, [rsp+0x30]
00007f582cdd3a16  vmovaps xmm4, [rsp+0x40]
00007f582cdd3a1c  vmovaps xmm5, [rsp+0x50]
00007f582cdd3a22  vmovaps xmm6, [rsp+0x60]
00007f582cdd3a28  vmovaps xmm7, [rsp+0x70]
00007f582cdd3a2e  vmovaps xmm8, [rsp+0x80]
00007f582cdd3a37  vmovaps xmm10, [rsp+0x90]
00007f582cdd3a40  vmovaps xmm11, [rsp+0xA0]
00007f582cdd3a49  vmovaps xmm12, [rsp+0xB0]
00007f582cdd3a52  vmovaps xmm13, [rsp+0xC0]
00007f582cdd3a5b  vmovaps xmm14, [rsp+0xD0]
00007f582cdd3a64  vmovaps xmm15, [rsp+0xE0]
00007f582cdd3a6d  add rsp, 0xF0
00007f582cdd3a74  pop r11
00007f582cdd3a76  pop r10
00007f582cdd3a78  pop r9
00007f582cdd3a7a  pop r8
00007f582cdd3a7c  pop rsi
00007f582cdd3a7d  pop rdi
00007f582cdd3a7e  pop rdx
00007f582cdd3a7f  pop rcx
00007f582cdd3a80  pop rax
00007f582cdd3a81  add rsp, 0x08
00007f582cdd3a85  jmp 0x00007F582CDCFFE1
00007f582cdd3a8a  sub rsp, 0x08
00007f582cdd3a8e  push rax
00007f582cdd3a8f  push rcx
00007f582cdd3a90  push rdx
00007f582cdd3a91  push rdi
00007f582cdd3a92  push rsi
00007f582cdd3a93  push r8
00007f582cdd3a95  push r9
00007f582cdd3a97  push r10
00007f582cdd3a99  push r11
00007f582cdd3a9b  sub rsp, 0xF0
00007f582cdd3aa2  vmovaps [rsp], xmm0
00007f582cdd3aa7  vmovaps [rsp+0x10], xmm1
00007f582cdd3aad  vmovaps [rsp+0x20], xmm2
00007f582cdd3ab3  vmovaps [rsp+0x30], xmm3
00007f582cdd3ab9  vmovaps [rsp+0x40], xmm4
00007f582cdd3abf  vmovaps [rsp+0x50], xmm5
00007f582cdd3ac5  vmovaps [rsp+0x60], xmm6
00007f582cdd3acb  vmovaps [rsp+0x70], xmm7
00007f582cdd3ad1  vmovaps [rsp+0x80], xmm8
00007f582cdd3ada  vmovaps [rsp+0x90], xmm9
00007f582cdd3ae3  vmovaps [rsp+0xA0], xmm11
00007f582cdd3aec  vmovaps [rsp+0xB0], xmm12
00007f582cdd3af5  vmovaps [rsp+0xC0], xmm13
00007f582cdd3afe  vmovaps [rsp+0xD0], xmm14
00007f582cdd3b07  vmovaps [rsp+0xE0], xmm15
00007f582cdd3b10  sub rsp, 0x30
00007f582cdd3b14  movaps [rsp], xmm10
00007f582cdd3b19  movaps [rsp+0x10], xmm1
00007f582cdd3b1e  movaps [rsp+0x20], xmm11
00007f582cdd3b24  lea rdi, [rsp]
00007f582cdd3b28  mov esi, 0x00
00007f582cdd3b2d  mov rax, 0x653B0D9BF530
00007f582cdd3b37  call rax
00007f582cdd3b39  movaps xmm10, [rsp]
00007f582cdd3b3e  add rsp, 0x30
00007f582cdd3b42  vmovaps xmm0, [rsp]
00007f582cdd3b47  vmovaps xmm1, [rsp+0x10]
00007f582cdd3b4d  vmovaps xmm2, [rsp+0x20]
00007f582cdd3b53  vmovaps xmm3, [rsp+0x30]
00007f582cdd3b59  vmovaps xmm4, [rsp+0x40]
00007f582cdd3b5f  vmovaps xmm5, [rsp+0x50]
00007f582cdd3b65  vmovaps xmm6, [rsp+0x60]
00007f582cdd3b6b  vmovaps xmm7, [rsp+0x70]
00007f582cdd3b71  vmovaps xmm8, [rsp+0x80]
00007f582cdd3b7a  vmovaps xmm9, [rsp+0x90]
00007f582cdd3b83  vmovaps xmm11, [rsp+0xA0]
00007f582cdd3b8c  vmovaps xmm12, [rsp+0xB0]
00007f582cdd3b95  vmovaps xmm13, [rsp+0xC0]
00007f582cdd3b9e  vmovaps xmm14, [rsp+0xD0]
00007f582cdd3ba7  vmovaps xmm15, [rsp+0xE0]
00007f582cdd3bb0  add rsp, 0xF0
00007f582cdd3bb7  pop r11
00007f582cdd3bb9  pop r10
00007f582cdd3bbb  pop r9
00007f582cdd3bbd  pop r8
00007f582cdd3bbf  pop rsi
00007f582cdd3bc0  pop rdi
00007f582cdd3bc1  pop rdx
00007f582cdd3bc2  pop rcx
00007f582cdd3bc3  pop rax
00007f582cdd3bc4  add rsp, 0x08
00007f582cdd3bc8  jmp 0x00007F582CDCFFFC
00007f582cdd3bcd  sub rsp, 0x08
00007f582cdd3bd1  push rax
00007f582cdd3bd2  push rcx
00007f582cdd3bd3  push rdx
00007f582cdd3bd4  push rdi
00007f582cdd3bd5  push rsi
00007f582cdd3bd6  push r8
00007f582cdd3bd8  push r9
00007f582cdd3bda  push r10
00007f582cdd3bdc  push r11
00007f582cdd3bde  sub rsp, 0xF0
00007f582cdd3be5  vmovaps [rsp], xmm0
00007f582cdd3bea  vmovaps [rsp+0x10], xmm2
00007f582cdd3bf0  vmovaps [rsp+0x20], xmm3
00007f582cdd3bf6  vmovaps [rsp+0x30], xmm4
00007f582cdd3bfc  vmovaps [rsp+0x40], xmm5
00007f582cdd3c02  vmovaps [rsp+0x50], xmm6
00007f582cdd3c08  vmovaps [rsp+0x60], xmm7
00007f582cdd3c0e  vmovaps [rsp+0x70], xmm8
00007f582cdd3c14  vmovaps [rsp+0x80], xmm9
00007f582cdd3c1d  vmovaps [rsp+0x90], xmm10
00007f582cdd3c26  vmovaps [rsp+0xA0], xmm11
00007f582cdd3c2f  vmovaps [rsp+0xB0], xmm12
00007f582cdd3c38  vmovaps [rsp+0xC0], xmm13
00007f582cdd3c41  vmovaps [rsp+0xD0], xmm14
00007f582cdd3c4a  vmovaps [rsp+0xE0], xmm15
00007f582cdd3c53  sub rsp, 0x30
00007f582cdd3c57  movaps [rsp], xmm1
00007f582cdd3c5b  movaps [rsp+0x10], xmm14
00007f582cdd3c61  movaps [rsp+0x20], xmm6
00007f582cdd3c66  lea rdi, [rsp]
00007f582cdd3c6a  mov esi, 0x00
00007f582cdd3c6f  mov rax, 0x653B0D9BF530
00007f582cdd3c79  call rax
00007f582cdd3c7b  movaps xmm1, [rsp]
00007f582cdd3c7f  add rsp, 0x30
00007f582cdd3c83  vmovaps xmm0, [rsp]
00007f582cdd3c88  vmovaps xmm2, [rsp+0x10]
00007f582cdd3c8e  vmovaps xmm3, [rsp+0x20]
00007f582cdd3c94  vmovaps xmm4, [rsp+0x30]
00007f582cdd3c9a  vmovaps xmm5, [rsp+0x40]
00007f582cdd3ca0  vmovaps xmm6, [rsp+0x50]
00007f582cdd3ca6  vmovaps xmm7, [rsp+0x60]
00007f582cdd3cac  vmovaps xmm8, [rsp+0x70]
00007f582cdd3cb2  vmovaps xmm9, [rsp+0x80]
00007f582cdd3cbb  vmovaps xmm10, [rsp+0x90]
00007f582cdd3cc4  vmovaps xmm11, [rsp+0xA0]
00007f582cdd3ccd  vmovaps xmm12, [rsp+0xB0]
00007f582cdd3cd6  vmovaps xmm13, [rsp+0xC0]
00007f582cdd3cdf  vmovaps xmm14, [rsp+0xD0]
00007f582cdd3ce8  vmovaps xmm15, [rsp+0xE0]
00007f582cdd3cf1  add rsp, 0xF0
00007f582cdd3cf8  pop r11
00007f582cdd3cfa  pop r10
00007f582cdd3cfc  pop r9
00007f582cdd3cfe  pop r8
00007f582cdd3d00  pop rsi
00007f582cdd3d01  pop rdi
00007f582cdd3d02  pop rdx
00007f582cdd3d03  pop rcx
00007f582cdd3d04  pop rax
00007f582cdd3d05  add rsp, 0x08
00007f582cdd3d09  jmp 0x00007F582CDD0015
00007f582cdd3d0e  sub rsp, 0x08
00007f582cdd3d12  push rax
00007f582cdd3d13  push rcx
00007f582cdd3d14  push rdx
00007f582cdd3d15  push rdi
00007f582cdd3d16  push rsi
00007f582cdd3d17  push r8
00007f582cdd3d19  push r9
00007f582cdd3d1b  push r10
00007f582cdd3d1d  push r11
00007f582cdd3d1f  sub rsp, 0xF0
00007f582cdd3d26  vmovaps [rsp], xmm0
00007f582cdd3d2b  vmovaps [rsp+0x10], xmm1
00007f582cdd3d31  vmovaps [rsp+0x20], xmm2
00007f582cdd3d37  vmovaps [rsp+0x30], xmm3
00007f582cdd3d3d  vmovaps [rsp+0x40], xmm4
00007f582cdd3d43  vmovaps [rsp+0x50], xmm5
00007f582cdd3d49  vmovaps [rsp+0x60], xmm6
00007f582cdd3d4f  vmovaps [rsp+0x70], xmm7
00007f582cdd3d55  vmovaps [rsp+0x80], xmm8
00007f582cdd3d5e  vmovaps [rsp+0x90], xmm9
00007f582cdd3d67  vmovaps [rsp+0xA0], xmm10
00007f582cdd3d70  vmovaps [rsp+0xB0], xmm12
00007f582cdd3d79  vmovaps [rsp+0xC0], xmm13
00007f582cdd3d82  vmovaps [rsp+0xD0], xmm14
00007f582cdd3d8b  vmovaps [rsp+0xE0], xmm15
00007f582cdd3d94  sub rsp, 0x30
00007f582cdd3d98  movaps [rsp], xmm11
00007f582cdd3d9d  movaps [rsp+0x10], xmm13
00007f582cdd3da3  movaps [rsp+0x20], xmm14
00007f582cdd3da9  lea rdi, [rsp]
00007f582cdd3dad  mov esi, 0x00
00007f582cdd3db2  mov rax, 0x653B0D9BF530
00007f582cdd3dbc  call rax
00007f582cdd3dbe  movaps xmm11, [rsp]
00007f582cdd3dc3  add rsp, 0x30
00007f582cdd3dc7  vmovaps xmm0, [rsp]
00007f582cdd3dcc  vmovaps xmm1, [rsp+0x10]
00007f582cdd3dd2  vmovaps xmm2, [rsp+0x20]
00007f582cdd3dd8  vmovaps xmm3, [rsp+0x30]
00007f582cdd3dde  vmovaps xmm4, [rsp+0x40]
00007f582cdd3de4  vmovaps xmm5, [rsp+0x50]
00007f582cdd3dea  vmovaps xmm6, [rsp+0x60]
00007f582cdd3df0  vmovaps xmm7, [rsp+0x70]
00007f582cdd3df6  vmovaps xmm8, [rsp+0x80]
00007f582cdd3dff  vmovaps xmm9, [rsp+0x90]
00007f582cdd3e08  vmovaps xmm10, [rsp+0xA0]
00007f582cdd3e11  vmovaps xmm12, [rsp+0xB0]
00007f582cdd3e1a  vmovaps xmm13, [rsp+0xC0]
00007f582cdd3e23  vmovaps xmm14, [rsp+0xD0]
00007f582cdd3e2c  vmovaps xmm15, [rsp+0xE0]
00007f582cdd3e35  add rsp, 0xF0
00007f582cdd3e3c  pop r11
00007f582cdd3e3e  pop r10
00007f582cdd3e40  pop r9
00007f582cdd3e42  pop r8
00007f582cdd3e44  pop rsi
00007f582cdd3e45  pop rdi
00007f582cdd3e46  pop rdx
00007f582cdd3e47  pop rcx
00007f582cdd3e48  pop rax
00007f582cdd3e49  add rsp, 0x08
00007f582cdd3e4d  jmp 0x00007F582CDD003F
00007f582cdd3e52  sub rsp, 0x08
00007f582cdd3e56  push rax
00007f582cdd3e57  push rcx
00007f582cdd3e58  push rdx
00007f582cdd3e59  push rdi
00007f582cdd3e5a  push rsi
00007f582cdd3e5b  push r8
00007f582cdd3e5d  push r9
00007f582cdd3e5f  push r10
00007f582cdd3e61  push r11
00007f582cdd3e63  sub rsp, 0xF0
00007f582cdd3e6a  vmovaps [rsp], xmm0
00007f582cdd3e6f  vmovaps [rsp+0x10], xmm1
00007f582cdd3e75  vmovaps [rsp+0x20], xmm2
00007f582cdd3e7b  vmovaps [rsp+0x30], xmm3
00007f582cdd3e81  vmovaps [rsp+0x40], xmm4
00007f582cdd3e87  vmovaps [rsp+0x50], xmm5
00007f582cdd3e8d  vmovaps [rsp+0x60], xmm6
00007f582cdd3e93  vmovaps [rsp+0x70], xmm7
00007f582cdd3e99  vmovaps [rsp+0x80], xmm8
00007f582cdd3ea2  vmovaps [rsp+0x90], xmm9
00007f582cdd3eab  vmovaps [rsp+0xA0], xmm10
00007f582cdd3eb4  vmovaps [rsp+0xB0], xmm11
00007f582cdd3ebd  vmovaps [rsp+0xC0], xmm12
00007f582cdd3ec6  vmovaps [rsp+0xD0], xmm14
00007f582cdd3ecf  vmovaps [rsp+0xE0], xmm15
00007f582cdd3ed8  sub rsp, 0x30
00007f582cdd3edc  movaps [rsp], xmm13
00007f582cdd3ee1  movaps [rsp+0x10], xmm8
00007f582cdd3ee7  movaps [rsp+0x20], xmm14
00007f582cdd3eed  lea rdi, [rsp]
00007f582cdd3ef1  mov esi, 0x00
00007f582cdd3ef6  mov rax, 0x653B0D9BF530
00007f582cdd3f00  call rax
00007f582cdd3f02  movaps xmm13, [rsp]
00007f582cdd3f07  add rsp, 0x30
00007f582cdd3f0b  vmovaps xmm0, [rsp]
00007f582cdd3f10  vmovaps xmm1, [rsp+0x10]
00007f582cdd3f16  vmovaps xmm2, [rsp+0x20]
00007f582cdd3f1c  vmovaps xmm3, [rsp+0x30]
00007f582cdd3f22  vmovaps xmm4, [rsp+0x40]
00007f582cdd3f28  vmovaps xmm5, [rsp+0x50]
00007f582cdd3f2e  vmovaps xmm6, [rsp+0x60]
00007f582cdd3f34  vmovaps xmm7, [rsp+0x70]
00007f582cdd3f3a  vmovaps xmm8, [rsp+0x80]
00007f582cdd3f43  vmovaps xmm9, [rsp+0x90]
00007f582cdd3f4c  vmovaps xmm10, [rsp+0xA0]
00007f582cdd3f55  vmovaps xmm11, [rsp+0xB0]
00007f582cdd3f5e  vmovaps xmm12, [rsp+0xC0]
00007f582cdd3f67  vmovaps xmm14, [rsp+0xD0]
00007f582cdd3f70  vmovaps xmm15, [rsp+0xE0]
00007f582cdd3f79  add rsp, 0xF0
00007f582cdd3f80  pop r11
00007f582cdd3f82  pop r10
00007f582cdd3f84  pop r9
00007f582cdd3f86  pop r8
00007f582cdd3f88  pop rsi
00007f582cdd3f89  pop rdi
00007f582cdd3f8a  pop rdx
00007f582cdd3f8b  pop rcx
00007f582cdd3f8c  pop rax
00007f582cdd3f8d  add rsp, 0x08
00007f582cdd3f91  jmp 0x00007F582CDD006E
00007f582cdd3f96  sub rsp, 0x08
00007f582cdd3f9a  push rax
00007f582cdd3f9b  push rcx
00007f582cdd3f9c  push rdx
00007f582cdd3f9d  push rdi
00007f582cdd3f9e  push rsi
00007f582cdd3f9f  push r8
00007f582cdd3fa1  push r9
00007f582cdd3fa3  push r10
00007f582cdd3fa5  push r11
00007f582cdd3fa7  sub rsp, 0xF0
00007f582cdd3fae  vmovaps [rsp], xmm0
00007f582cdd3fb3  vmovaps [rsp+0x10], xmm1
00007f582cdd3fb9  vmovaps [rsp+0x20], xmm2
00007f582cdd3fbf  vmovaps [rsp+0x30], xmm3
00007f582cdd3fc5  vmovaps [rsp+0x40], xmm4
00007f582cdd3fcb  vmovaps [rsp+0x50], xmm5
00007f582cdd3fd1  vmovaps [rsp+0x60], xmm6
00007f582cdd3fd7  vmovaps [rsp+0x70], xmm7
00007f582cdd3fdd  vmovaps [rsp+0x80], xmm9
00007f582cdd3fe6  vmovaps [rsp+0x90], xmm10
00007f582cdd3fef  vmovaps [rsp+0xA0], xmm11
00007f582cdd3ff8  vmovaps [rsp+0xB0], xmm12
00007f582cdd4001  vmovaps [rsp+0xC0], xmm13
00007f582cdd400a  vmovaps [rsp+0xD0], xmm14
00007f582cdd4013  vmovaps [rsp+0xE0], xmm15
00007f582cdd401c  sub rsp, 0x30
00007f582cdd4020  movaps [rsp], xmm8
00007f582cdd4025  movaps [rsp+0x10], xmm7
00007f582cdd402a  movaps [rsp+0x20], xmm14
00007f582cdd4030  lea rdi, [rsp]
00007f582cdd4034  mov esi, 0x00
00007f582cdd4039  mov rax, 0x653B0D9BF530
00007f582cdd4043  call rax
00007f582cdd4045  movaps xmm8, [rsp]
00007f582cdd404a  add rsp, 0x30
00007f582cdd404e  vmovaps xmm0, [rsp]
00007f582cdd4053  vmovaps xmm1, [rsp+0x10]
00007f582cdd4059  vmovaps xmm2, [rsp+0x20]
00007f582cdd405f  vmovaps xmm3, [rsp+0x30]
00007f582cdd4065  vmovaps xmm4, [rsp+0x40]
00007f582cdd406b  vmovaps xmm5, [rsp+0x50]
00007f582cdd4071  vmovaps xmm6, [rsp+0x60]
00007f582cdd4077  vmovaps xmm7, [rsp+0x70]
00007f582cdd407d  vmovaps xmm9, [rsp+0x80]
00007f582cdd4086  vmovaps xmm10, [rsp+0x90]
00007f582cdd408f  vmovaps xmm11, [rsp+0xA0]
00007f582cdd4098  vmovaps xmm12, [rsp+0xB0]
00007f582cdd40a1  vmovaps xmm13, [rsp+0xC0]
00007f582cdd40aa  vmovaps xmm14, [rsp+0xD0]
00007f582cdd40b3  vmovaps xmm15, [rsp+0xE0]
00007f582cdd40bc  add rsp, 0xF0
00007f582cdd40c3  pop r11
00007f582cdd40c5  pop r10
00007f582cdd40c7  pop r9
00007f582cdd40c9  pop r8
00007f582cdd40cb  pop rsi
00007f582cdd40cc  pop rdi
00007f582cdd40cd  pop rdx
00007f582cdd40ce  pop rcx
00007f582cdd40cf  pop rax
00007f582cdd40d0  add rsp, 0x08
00007f582cdd40d4  jmp 0x00007F582CDD0094
00007f582cdd40d9  sub rsp, 0x08
00007f582cdd40dd  push rax
00007f582cdd40de  push rcx
00007f582cdd40df  push rdx
00007f582cdd40e0  push rdi
00007f582cdd40e1  push rsi
00007f582cdd40e2  push r8
00007f582cdd40e4  push r9
00007f582cdd40e6  push r10
00007f582cdd40e8  push r11
00007f582cdd40ea  sub rsp, 0xF0
00007f582cdd40f1  vmovaps [rsp], xmm0
00007f582cdd40f6  vmovaps [rsp+0x10], xmm1
00007f582cdd40fc  vmovaps [rsp+0x20], xmm2
00007f582cdd4102  vmovaps [rsp+0x30], xmm3
00007f582cdd4108  vmovaps [rsp+0x40], xmm4
00007f582cdd410e  vmovaps [rsp+0x50], xmm5
00007f582cdd4114  vmovaps [rsp+0x60], xmm6
00007f582cdd411a  vmovaps [rsp+0x70], xmm7
00007f582cdd4120  vmovaps [rsp+0x80], xmm8
00007f582cdd4129  vmovaps [rsp+0x90], xmm9
00007f582cdd4132  vmovaps [rsp+0xA0], xmm10
00007f582cdd413b  vmovaps [rsp+0xB0], xmm11
00007f582cdd4144  vmovaps [rsp+0xC0], xmm12
00007f582cdd414d  vmovaps [rsp+0xD0], xmm13
00007f582cdd4156  vmovaps [rsp+0xE0], xmm15
00007f582cdd415f  sub rsp, 0x30
00007f582cdd4163  movaps [rsp], xmm14
00007f582cdd4168  movaps [rsp+0x10], xmm12
00007f582cdd416e  movaps [rsp+0x20], xmm9
00007f582cdd4174  lea rdi, [rsp]
00007f582cdd4178  mov esi, 0x00
00007f582cdd417d  mov rax, 0x653B0D9BF530
00007f582cdd4187  call rax
00007f582cdd4189  movaps xmm14, [rsp]
00007f582cdd418e  add rsp, 0x30
00007f582cdd4192  vmovaps xmm0, [rsp]
00007f582cdd4197  vmovaps xmm1, [rsp+0x10]
00007f582cdd419d  vmovaps xmm2, [rsp+0x20]
00007f582cdd41a3  vmovaps xmm3, [rsp+0x30]
00007f582cdd41a9  vmovaps xmm4, [rsp+0x40]
00007f582cdd41af  vmovaps xmm5, [rsp+0x50]
00007f582cdd41b5  vmovaps xmm6, [rsp+0x60]
00007f582cdd41bb  vmovaps xmm7, [rsp+0x70]
00007f582cdd41c1  vmovaps xmm8, [rsp+0x80]
00007f582cdd41ca  vmovaps xmm9, [rsp+0x90]
00007f582cdd41d3  vmovaps xmm10, [rsp+0xA0]
00007f582cdd41dc  vmovaps xmm11, [rsp+0xB0]
00007f582cdd41e5  vmovaps xmm12, [rsp+0xC0]
00007f582cdd41ee  vmovaps xmm13, [rsp+0xD0]
00007f582cdd41f7  vmovaps xmm15, [rsp+0xE0]
00007f582cdd4200  add rsp, 0xF0
00007f582cdd4207  pop r11
00007f582cdd4209  pop r10
00007f582cdd420b  pop r9
00007f582cdd420d  pop r8
00007f582cdd420f  pop rsi
00007f582cdd4210  pop rdi
00007f582cdd4211  pop rdx
00007f582cdd4212  pop rcx
00007f582cdd4213  pop rax
00007f582cdd4214  add rsp, 0x08
00007f582cdd4218  jmp 0x00007F582CDD00AE
00007f582cdd421d  sub rsp, 0x08
00007f582cdd4221  push rax
00007f582cdd4222  push rcx
00007f582cdd4223  push rdx
00007f582cdd4224  push rdi
00007f582cdd4225  push rsi
00007f582cdd4226  push r8
00007f582cdd4228  push r9
00007f582cdd422a  push r10
00007f582cdd422c  push r11
00007f582cdd422e  sub rsp, 0xF0
00007f582cdd4235  vmovaps [rsp], xmm0
00007f582cdd423a  vmovaps [rsp+0x10], xmm1
00007f582cdd4240  vmovaps [rsp+0x20], xmm2
00007f582cdd4246  vmovaps [rsp+0x30], xmm3
00007f582cdd424c  vmovaps [rsp+0x40], xmm4
00007f582cdd4252  vmovaps [rsp+0x50], xmm5
00007f582cdd4258  vmovaps [rsp+0x60], xmm6
00007f582cdd425e  vmovaps [rsp+0x70], xmm7
00007f582cdd4264  vmovaps [rsp+0x80], xmm8
00007f582cdd426d  vmovaps [rsp+0x90], xmm10
00007f582cdd4276  vmovaps [rsp+0xA0], xmm11
00007f582cdd427f  vmovaps [rsp+0xB0], xmm12
00007f582cdd4288  vmovaps [rsp+0xC0], xmm13
00007f582cdd4291  vmovaps [rsp+0xD0], xmm14
00007f582cdd429a  vmovaps [rsp+0xE0], xmm15
00007f582cdd42a3  sub rsp, 0x30
00007f582cdd42a7  movaps [rsp], xmm9
00007f582cdd42ac  movaps [rsp+0x10], xmm7
00007f582cdd42b1  movaps [rsp+0x20], xmm12
00007f582cdd42b7  lea rdi, [rsp]
00007f582cdd42bb  mov esi, 0x00
00007f582cdd42c0  mov rax, 0x653B0D9BF530
00007f582cdd42ca  call rax
00007f582cdd42cc  movaps xmm9, [rsp]
00007f582cdd42d1  add rsp, 0x30
00007f582cdd42d5  vmovaps xmm0, [rsp]
00007f582cdd42da  vmovaps xmm1, [rsp+0x10]
00007f582cdd42e0  vmovaps xmm2, [rsp+0x20]
00007f582cdd42e6  vmovaps xmm3, [rsp+0x30]
00007f582cdd42ec  vmovaps xmm4, [rsp+0x40]
00007f582cdd42f2  vmovaps xmm5, [rsp+0x50]
00007f582cdd42f8  vmovaps xmm6, [rsp+0x60]
00007f582cdd42fe  vmovaps xmm7, [rsp+0x70]
00007f582cdd4304  vmovaps xmm8, [rsp+0x80]
00007f582cdd430d  vmovaps xmm10, [rsp+0x90]
00007f582cdd4316  vmovaps xmm11, [rsp+0xA0]
00007f582cdd431f  vmovaps xmm12, [rsp+0xB0]
00007f582cdd4328  vmovaps xmm13, [rsp+0xC0]
00007f582cdd4331  vmovaps xmm14, [rsp+0xD0]
00007f582cdd433a  vmovaps xmm15, [rsp+0xE0]
00007f582cdd4343  add rsp, 0xF0
00007f582cdd434a  pop r11
00007f582cdd434c  pop r10
00007f582cdd434e  pop r9
00007f582cdd4350  pop r8
00007f582cdd4352  pop rsi
00007f582cdd4353  pop rdi
00007f582cdd4354  pop rdx
00007f582cdd4355  pop rcx
00007f582cdd4356  pop rax
00007f582cdd4357  add rsp, 0x08
00007f582cdd435b  jmp 0x00007F582CDD00DD
00007f582cdd4360  sub rsp, 0x08
00007f582cdd4364  push rax
00007f582cdd4365  push rcx
00007f582cdd4366  push rdx
00007f582cdd4367  push rdi
00007f582cdd4368  push rsi
00007f582cdd4369  push r8
00007f582cdd436b  push r9
00007f582cdd436d  push r10
00007f582cdd436f  push r11
00007f582cdd4371  sub rsp, 0xF0
00007f582cdd4378  vmovaps [rsp], xmm0
00007f582cdd437d  vmovaps [rsp+0x10], xmm1
00007f582cdd4383  vmovaps [rsp+0x20], xmm2
00007f582cdd4389  vmovaps [rsp+0x30], xmm3
00007f582cdd438f  vmovaps [rsp+0x40], xmm4
00007f582cdd4395  vmovaps [rsp+0x50], xmm5
00007f582cdd439b  vmovaps [rsp+0x60], xmm6
00007f582cdd43a1  vmovaps [rsp+0x70], xmm7
00007f582cdd43a7  vmovaps [rsp+0x80], xmm8
00007f582cdd43b0  vmovaps [rsp+0x90], xmm9
00007f582cdd43b9  vmovaps [rsp+0xA0], xmm10
00007f582cdd43c2  vmovaps [rsp+0xB0], xmm11
00007f582cdd43cb  vmovaps [rsp+0xC0], xmm13
00007f582cdd43d4  vmovaps [rsp+0xD0], xmm14
00007f582cdd43dd  vmovaps [rsp+0xE0], xmm15
00007f582cdd43e6  sub rsp, 0x30
00007f582cdd43ea  movaps [rsp], xmm12
00007f582cdd43ef  movaps [rsp+0x10], xmm15
00007f582cdd43f5  movaps [rsp+0x20], xmm11
00007f582cdd43fb  lea rdi, [rsp]
00007f582cdd43ff  mov esi, 0x00
00007f582cdd4404  mov rax, 0x653B0D9BF530
00007f582cdd440e  call rax
00007f582cdd4410  movaps xmm12, [rsp]
00007f582cdd4415  add rsp, 0x30
00007f582cdd4419  vmovaps xmm0, [rsp]
00007f582cdd441e  vmovaps xmm1, [rsp+0x10]
00007f582cdd4424  vmovaps xmm2, [rsp+0x20]
00007f582cdd442a  vmovaps xmm3, [rsp+0x30]
00007f582cdd4430  vmovaps xmm4, [rsp+0x40]
00007f582cdd4436  vmovaps xmm5, [rsp+0x50]
00007f582cdd443c  vmovaps xmm6, [rsp+0x60]
00007f582cdd4442  vmovaps xmm7, [rsp+0x70]
00007f582cdd4448  vmovaps xmm8, [rsp+0x80]
00007f582cdd4451  vmovaps xmm9, [rsp+0x90]
00007f582cdd445a  vmovaps xmm10, [rsp+0xA0]
00007f582cdd4463  vmovaps xmm11, [rsp+0xB0]
00007f582cdd446c  vmovaps xmm13, [rsp+0xC0]
00007f582cdd4475  vmovaps xmm14, [rsp+0xD0]
00007f582cdd447e  vmovaps xmm15, [rsp+0xE0]
00007f582cdd4487  add rsp, 0xF0
00007f582cdd448e  pop r11
00007f582cdd4490  pop r10
00007f582cdd4492  pop r9
00007f582cdd4494  pop r8
00007f582cdd4496  pop rsi
00007f582cdd4497  pop rdi
00007f582cdd4498  pop rdx
00007f582cdd4499  pop rcx
00007f582cdd449a  pop rax
00007f582cdd449b  add rsp, 0x08
00007f582cdd449f  jmp 0x00007F582CDD00F7
00007f582cdd44a4  sub rsp, 0x08
00007f582cdd44a8  push rax
00007f582cdd44a9  push rcx
00007f582cdd44aa  push rdx
00007f582cdd44ab  push rdi
00007f582cdd44ac  push rsi
00007f582cdd44ad  push r8
00007f582cdd44af  push r9
00007f582cdd44b1  push r10
00007f582cdd44b3  push r11
00007f582cdd44b5  sub rsp, 0xF0
00007f582cdd44bc  vmovaps [rsp], xmm0
00007f582cdd44c1  vmovaps [rsp+0x10], xmm1
00007f582cdd44c7  vmovaps [rsp+0x20], xmm2
00007f582cdd44cd  vmovaps [rsp+0x30], xmm3
00007f582cdd44d3  vmovaps [rsp+0x40], xmm4
00007f582cdd44d9  vmovaps [rsp+0x50], xmm5
00007f582cdd44df  vmovaps [rsp+0x60], xmm6
00007f582cdd44e5  vmovaps [rsp+0x70], xmm7
00007f582cdd44eb  vmovaps [rsp+0x80], xmm8
00007f582cdd44f4  vmovaps [rsp+0x90], xmm9
00007f582cdd44fd  vmovaps [rsp+0xA0], xmm10
00007f582cdd4506  vmovaps [rsp+0xB0], xmm12
00007f582cdd450f  vmovaps [rsp+0xC0], xmm13
00007f582cdd4518  vmovaps [rsp+0xD0], xmm14
00007f582cdd4521  vmovaps [rsp+0xE0], xmm15
00007f582cdd452a  sub rsp, 0x30
00007f582cdd452e  movaps [rsp], xmm11
00007f582cdd4533  movaps [rsp+0x10], xmm7
00007f582cdd4538  movaps [rsp+0x20], xmm15
00007f582cdd453e  lea rdi, [rsp]
00007f582cdd4542  mov esi, 0x00
00007f582cdd4547  mov rax, 0x653B0D9BF530
00007f582cdd4551  call rax
00007f582cdd4553  movaps xmm11, [rsp]
00007f582cdd4558  add rsp, 0x30
00007f582cdd455c  vmovaps xmm0, [rsp]
00007f582cdd4561  vmovaps xmm1, [rsp+0x10]
00007f582cdd4567  vmovaps xmm2, [rsp+0x20]
00007f582cdd456d  vmovaps xmm3, [rsp+0x30]
00007f582cdd4573  vmovaps xmm4, [rsp+0x40]
00007f582cdd4579  vmovaps xmm5, [rsp+0x50]
00007f582cdd457f  vmovaps xmm6, [rsp+0x60]
00007f582cdd4585  vmovaps xmm7, [rsp+0x70]
00007f582cdd458b  vmovaps xmm8, [rsp+0x80]
00007f582cdd4594  vmovaps xmm9, [rsp+0x90]
00007f582cdd459d  vmovaps xmm10, [rsp+0xA0]
00007f582cdd45a6  vmovaps xmm12, [rsp+0xB0]
00007f582cdd45af  vmovaps xmm13, [rsp+0xC0]
00007f582cdd45b8  vmovaps xmm14, [rsp+0xD0]
00007f582cdd45c1  vmovaps xmm15, [rsp+0xE0]
00007f582cdd45ca  add rsp, 0xF0
00007f582cdd45d1  pop r11
00007f582cdd45d3  pop r10
00007f582cdd45d5  pop r9
00007f582cdd45d7  pop r8
00007f582cdd45d9  pop rsi
00007f582cdd45da  pop rdi
00007f582cdd45db  pop rdx
00007f582cdd45dc  pop rcx
00007f582cdd45dd  pop rax
00007f582cdd45de  add rsp, 0x08
00007f582cdd45e2  jmp 0x00007F582CDD0123
00007f582cdd45e7  sub rsp, 0x08
00007f582cdd45eb  push rax
00007f582cdd45ec  push rcx
00007f582cdd45ed  push rdx
00007f582cdd45ee  push rdi
00007f582cdd45ef  push rsi
00007f582cdd45f0  push r8
00007f582cdd45f2  push r9
00007f582cdd45f4  push r10
00007f582cdd45f6  push r11
00007f582cdd45f8  sub rsp, 0xF0
00007f582cdd45ff  vmovaps [rsp], xmm0
00007f582cdd4604  vmovaps [rsp+0x10], xmm1
00007f582cdd460a  vmovaps [rsp+0x20], xmm2
00007f582cdd4610  vmovaps [rsp+0x30], xmm3
00007f582cdd4616  vmovaps [rsp+0x40], xmm4
00007f582cdd461c  vmovaps [rsp+0x50], xmm5
00007f582cdd4622  vmovaps [rsp+0x60], xmm6
00007f582cdd4628  vmovaps [rsp+0x70], xmm7
00007f582cdd462e  vmovaps [rsp+0x80], xmm8
00007f582cdd4637  vmovaps [rsp+0x90], xmm9
00007f582cdd4640  vmovaps [rsp+0xA0], xmm10
00007f582cdd4649  vmovaps [rsp+0xB0], xmm11
00007f582cdd4652  vmovaps [rsp+0xC0], xmm12
00007f582cdd465b  vmovaps [rsp+0xD0], xmm13
00007f582cdd4664  vmovaps [rsp+0xE0], xmm14
00007f582cdd466d  sub rsp, 0x30
00007f582cdd4671  movaps [rsp], xmm15
00007f582cdd4676  movaps [rsp+0x10], xmm10
00007f582cdd467c  movaps [rsp+0x20], xmm13
00007f582cdd4682  lea rdi, [rsp]
00007f582cdd4686  mov esi, 0x00
00007f582cdd468b  mov rax, 0x653B0D9BF530
00007f582cdd4695  call rax
00007f582cdd4697  movaps xmm15, [rsp]
00007f582cdd469c  add rsp, 0x30
00007f582cdd46a0  vmovaps xmm0, [rsp]
00007f582cdd46a5  vmovaps xmm1, [rsp+0x10]
00007f582cdd46ab  vmovaps xmm2, [rsp+0x20]
00007f582cdd46b1  vmovaps xmm3, [rsp+0x30]
00007f582cdd46b7  vmovaps xmm4, [rsp+0x40]
00007f582cdd46bd  vmovaps xmm5, [rsp+0x50]
00007f582cdd46c3  vmovaps xmm6, [rsp+0x60]
00007f582cdd46c9  vmovaps xmm7, [rsp+0x70]
00007f582cdd46cf  vmovaps xmm8, [rsp+0x80]
00007f582cdd46d8  vmovaps xmm9, [rsp+0x90]
00007f582cdd46e1  vmovaps xmm10, [rsp+0xA0]
00007f582cdd46ea  vmovaps xmm11, [rsp+0xB0]
00007f582cdd46f3  vmovaps xmm12, [rsp+0xC0]
00007f582cdd46fc  vmovaps xmm13, [rsp+0xD0]
00007f582cdd4705  vmovaps xmm14, [rsp+0xE0]
00007f582cdd470e  add rsp, 0xF0
00007f582cdd4715  pop r11
00007f582cdd4717  pop r10
00007f582cdd4719  pop r9
00007f582cdd471b  pop r8
00007f582cdd471d  pop rsi
00007f582cdd471e  pop rdi
00007f582cdd471f  pop rdx
00007f582cdd4720  pop rcx
00007f582cdd4721  pop rax
00007f582cdd4722  add rsp, 0x08
00007f582cdd4726  jmp 0x00007F582CDD013D
00007f582cdd472b  sub rsp, 0x08
00007f582cdd472f  push rax
00007f582cdd4730  push rcx
00007f582cdd4731  push rdx
00007f582cdd4732  push rdi
00007f582cdd4733  push rsi
00007f582cdd4734  push r8
00007f582cdd4736  push r9
00007f582cdd4738  push r10
00007f582cdd473a  push r11
00007f582cdd473c  sub rsp, 0xF0
00007f582cdd4743  vmovaps [rsp], xmm0
00007f582cdd4748  vmovaps [rsp+0x10], xmm1
00007f582cdd474e  vmovaps [rsp+0x20], xmm2
00007f582cdd4754  vmovaps [rsp+0x30], xmm3
00007f582cdd475a  vmovaps [rsp+0x40], xmm4
00007f582cdd4760  vmovaps [rsp+0x50], xmm5
00007f582cdd4766  vmovaps [rsp+0x60], xmm6
00007f582cdd476c  vmovaps [rsp+0x70], xmm7
00007f582cdd4772  vmovaps [rsp+0x80], xmm8
00007f582cdd477b  vmovaps [rsp+0x90], xmm9
00007f582cdd4784  vmovaps [rsp+0xA0], xmm11
00007f582cdd478d  vmovaps [rsp+0xB0], xmm12
00007f582cdd4796  vmovaps [rsp+0xC0], xmm13
00007f582cdd479f  vmovaps [rsp+0xD0], xmm14
00007f582cdd47a8  vmovaps [rsp+0xE0], xmm15
00007f582cdd47b1  sub rsp, 0x30
00007f582cdd47b5  movaps [rsp], xmm10
00007f582cdd47ba  movaps [rsp+0x10], xmm7
00007f582cdd47bf  movaps [rsp+0x20], xmm13
00007f582cdd47c5  lea rdi, [rsp]
00007f582cdd47c9  mov esi, 0x00
00007f582cdd47ce  mov rax, 0x653B0D9BF530
00007f582cdd47d8  call rax
00007f582cdd47da  movaps xmm10, [rsp]
00007f582cdd47df  add rsp, 0x30
00007f582cdd47e3  vmovaps xmm0, [rsp]
00007f582cdd47e8  vmovaps xmm1, [rsp+0x10]
00007f582cdd47ee  vmovaps xmm2, [rsp+0x20]
00007f582cdd47f4  vmovaps xmm3, [rsp+0x30]
00007f582cdd47fa  vmovaps xmm4, [rsp+0x40]
00007f582cdd4800  vmovaps xmm5, [rsp+0x50]
00007f582cdd4806  vmovaps xmm6, [rsp+0x60]
00007f582cdd480c  vmovaps xmm7, [rsp+0x70]
00007f582cdd4812  vmovaps xmm8, [rsp+0x80]
00007f582cdd481b  vmovaps xmm9, [rsp+0x90]
00007f582cdd4824  vmovaps xmm11, [rsp+0xA0]
00007f582cdd482d  vmovaps xmm12, [rsp+0xB0]
00007f582cdd4836  vmovaps xmm13, [rsp+0xC0]
00007f582cdd483f  vmovaps xmm14, [rsp+0xD0]
00007f582cdd4848  vmovaps xmm15, [rsp+0xE0]
00007f582cdd4851  add rsp, 0xF0
00007f582cdd4858  pop r11
00007f582cdd485a  pop r10
00007f582cdd485c  pop r9
00007f582cdd485e  pop r8
00007f582cdd4860  pop rsi
00007f582cdd4861  pop rdi
00007f582cdd4862  pop rdx
00007f582cdd4863  pop rcx
00007f582cdd4864  pop rax
00007f582cdd4865  add rsp, 0x08
00007f582cdd4869  jmp 0x00007F582CDD0169
00007f582cdd486e  sub rsp, 0x08
00007f582cdd4872  push rax
00007f582cdd4873  push rcx
00007f582cdd4874  push rdx
00007f582cdd4875  push rdi
00007f582cdd4876  push rsi
00007f582cdd4877  push r8
00007f582cdd4879  push r9
00007f582cdd487b  push r10
00007f582cdd487d  push r11
00007f582cdd487f  sub rsp, 0xF0
00007f582cdd4886  vmovaps [rsp], xmm0
00007f582cdd488b  vmovaps [rsp+0x10], xmm1
00007f582cdd4891  vmovaps [rsp+0x20], xmm2
00007f582cdd4897  vmovaps [rsp+0x30], xmm3
00007f582cdd489d  vmovaps [rsp+0x40], xmm4
00007f582cdd48a3  vmovaps [rsp+0x50], xmm5
00007f582cdd48a9  vmovaps [rsp+0x60], xmm6
00007f582cdd48af  vmovaps [rsp+0x70], xmm7
00007f582cdd48b5  vmovaps [rsp+0x80], xmm8
00007f582cdd48be  vmovaps [rsp+0x90], xmm9
00007f582cdd48c7  vmovaps [rsp+0xA0], xmm10
00007f582cdd48d0  vmovaps [rsp+0xB0], xmm11
00007f582cdd48d9  vmovaps [rsp+0xC0], xmm12
00007f582cdd48e2  vmovaps [rsp+0xD0], xmm14
00007f582cdd48eb  vmovaps [rsp+0xE0], xmm15
00007f582cdd48f4  sub rsp, 0x30
00007f582cdd48f8  movaps [rsp], xmm13
00007f582cdd48fd  movaps [rsp+0x10], xmm1
00007f582cdd4902  movaps [rsp+0x20], xmm8
00007f582cdd4908  lea rdi, [rsp]
00007f582cdd490c  mov esi, 0x00
00007f582cdd4911  mov rax, 0x653B0D9BF530
00007f582cdd491b  call rax
00007f582cdd491d  movaps xmm13, [rsp]
00007f582cdd4922  add rsp, 0x30
00007f582cdd4926  vmovaps xmm0, [rsp]
00007f582cdd492b  vmovaps xmm1, [rsp+0x10]
00007f582cdd4931  vmovaps xmm2, [rsp+0x20]
00007f582cdd4937  vmovaps xmm3, [rsp+0x30]
00007f582cdd493d  vmovaps xmm4, [rsp+0x40]
00007f582cdd4943  vmovaps xmm5, [rsp+0x50]
00007f582cdd4949  vmovaps xmm6, [rsp+0x60]
00007f582cdd494f  vmovaps xmm7, [rsp+0x70]
00007f582cdd4955  vmovaps xmm8, [rsp+0x80]
00007f582cdd495e  vmovaps xmm9, [rsp+0x90]
00007f582cdd4967  vmovaps xmm10, [rsp+0xA0]
00007f582cdd4970  vmovaps xmm11, [rsp+0xB0]
00007f582cdd4979  vmovaps xmm12, [rsp+0xC0]
00007f582cdd4982  vmovaps xmm14, [rsp+0xD0]
00007f582cdd498b  vmovaps xmm15, [rsp+0xE0]
00007f582cdd4994  add rsp, 0xF0
00007f582cdd499b  pop r11
00007f582cdd499d  pop r10
00007f582cdd499f  pop r9
00007f582cdd49a1  pop r8
00007f582cdd49a3  pop rsi
00007f582cdd49a4  pop rdi
00007f582cdd49a5  pop rdx
00007f582cdd49a6  pop rcx
00007f582cdd49a7  pop rax
00007f582cdd49a8  add rsp, 0x08
00007f582cdd49ac  jmp 0x00007F582CDD0183
00007f582cdd49b1  call 0x00007F582CBFF430
00007f582cdd49b6  jmp 0x00007F582CDD018D
00007f582cdd49bb  sub rsp, 0x08
00007f582cdd49bf  push rax
00007f582cdd49c0  push rcx
00007f582cdd49c1  push rdx
00007f582cdd49c2  push rdi
00007f582cdd49c3  push rsi
00007f582cdd49c4  push r8
00007f582cdd49c6  push r9
00007f582cdd49c8  push r10
00007f582cdd49ca  push r11
00007f582cdd49cc  sub rsp, 0xF0
00007f582cdd49d3  vmovaps [rsp], xmm0
00007f582cdd49d8  vmovaps [rsp+0x10], xmm1
00007f582cdd49de  vmovaps [rsp+0x20], xmm2
00007f582cdd49e4  vmovaps [rsp+0x30], xmm3
00007f582cdd49ea  vmovaps [rsp+0x40], xmm4
00007f582cdd49f0  vmovaps [rsp+0x50], xmm5
00007f582cdd49f6  vmovaps [rsp+0x60], xmm6
00007f582cdd49fc  vmovaps [rsp+0x70], xmm7
00007f582cdd4a02  vmovaps [rsp+0x80], xmm9
00007f582cdd4a0b  vmovaps [rsp+0x90], xmm10
00007f582cdd4a14  vmovaps [rsp+0xA0], xmm11
00007f582cdd4a1d  vmovaps [rsp+0xB0], xmm12
00007f582cdd4a26  vmovaps [rsp+0xC0], xmm13
00007f582cdd4a2f  vmovaps [rsp+0xD0], xmm14
00007f582cdd4a38  vmovaps [rsp+0xE0], xmm15
00007f582cdd4a41  sub rsp, 0x30
00007f582cdd4a45  movaps [rsp], xmm8
00007f582cdd4a4a  movaps [rsp+0x10], xmm14
00007f582cdd4a50  movaps [rsp+0x20], xmm9
00007f582cdd4a56  lea rdi, [rsp]
00007f582cdd4a5a  mov esi, 0x00
00007f582cdd4a5f  mov rax, 0x653B0D9BF530
00007f582cdd4a69  call rax
00007f582cdd4a6b  movaps xmm8, [rsp]
00007f582cdd4a70  add rsp, 0x30
00007f582cdd4a74  vmovaps xmm0, [rsp]
00007f582cdd4a79  vmovaps xmm1, [rsp+0x10]
00007f582cdd4a7f  vmovaps xmm2, [rsp+0x20]
00007f582cdd4a85  vmovaps xmm3, [rsp+0x30]
00007f582cdd4a8b  vmovaps xmm4, [rsp+0x40]
00007f582cdd4a91  vmovaps xmm5, [rsp+0x50]
00007f582cdd4a97  vmovaps xmm6, [rsp+0x60]
00007f582cdd4a9d  vmovaps xmm7, [rsp+0x70]
00007f582cdd4aa3  vmovaps xmm9, [rsp+0x80]
00007f582cdd4aac  vmovaps xmm10, [rsp+0x90]
00007f582cdd4ab5  vmovaps xmm11, [rsp+0xA0]
00007f582cdd4abe  vmovaps xmm12, [rsp+0xB0]
00007f582cdd4ac7  vmovaps xmm13, [rsp+0xC0]
00007f582cdd4ad0  vmovaps xmm14, [rsp+0xD0]
00007f582cdd4ad9  vmovaps xmm15, [rsp+0xE0]
00007f582cdd4ae2  add rsp, 0xF0
00007f582cdd4ae9  pop r11
00007f582cdd4aeb  pop r10
00007f582cdd4aed  pop r9
00007f582cdd4aef  pop r8
00007f582cdd4af1  pop rsi
00007f582cdd4af2  pop rdi
00007f582cdd4af3  pop rdx
00007f582cdd4af4  pop rcx
00007f582cdd4af5  pop rax
00007f582cdd4af6  add rsp, 0x08
00007f582cdd4afa  jmp 0x00007F582CDD01AF
00007f582cdd4aff  sub rsp, 0x08
00007f582cdd4b03  push rax
00007f582cdd4b04  push rcx
00007f582cdd4b05  push rdx
00007f582cdd4b06  push rdi
00007f582cdd4b07  push rsi
00007f582cdd4b08  push r8
00007f582cdd4b0a  push r9
00007f582cdd4b0c  push r10
00007f582cdd4b0e  push r11
00007f582cdd4b10  sub rsp, 0xF0
00007f582cdd4b17  vmovaps [rsp], xmm0
00007f582cdd4b1c  vmovaps [rsp+0x10], xmm1
00007f582cdd4b22  vmovaps [rsp+0x20], xmm2
00007f582cdd4b28  vmovaps [rsp+0x30], xmm3
00007f582cdd4b2e  vmovaps [rsp+0x40], xmm4
00007f582cdd4b34  vmovaps [rsp+0x50], xmm5
00007f582cdd4b3a  vmovaps [rsp+0x60], xmm6
00007f582cdd4b40  vmovaps [rsp+0x70], xmm7
00007f582cdd4b46  vmovaps [rsp+0x80], xmm8
00007f582cdd4b4f  vmovaps [rsp+0x90], xmm10
00007f582cdd4b58  vmovaps [rsp+0xA0], xmm11
00007f582cdd4b61  vmovaps [rsp+0xB0], xmm12
00007f582cdd4b6a  vmovaps [rsp+0xC0], xmm13
00007f582cdd4b73  vmovaps [rsp+0xD0], xmm14
00007f582cdd4b7c  vmovaps [rsp+0xE0], xmm15
00007f582cdd4b85  sub rsp, 0x30
00007f582cdd4b89  movaps [rsp], xmm9
00007f582cdd4b8e  movaps [rsp+0x10], xmm1
00007f582cdd4b93  movaps [rsp+0x20], xmm14
00007f582cdd4b99  lea rdi, [rsp]
00007f582cdd4b9d  mov esi, 0x00
00007f582cdd4ba2  mov rax, 0x653B0D9BF530
00007f582cdd4bac  call rax
00007f582cdd4bae  movaps xmm9, [rsp]
00007f582cdd4bb3  add rsp, 0x30
00007f582cdd4bb7  vmovaps xmm0, [rsp]
00007f582cdd4bbc  vmovaps xmm1, [rsp+0x10]
00007f582cdd4bc2  vmovaps xmm2, [rsp+0x20]
00007f582cdd4bc8  vmovaps xmm3, [rsp+0x30]
00007f582cdd4bce  vmovaps xmm4, [rsp+0x40]
00007f582cdd4bd4  vmovaps xmm5, [rsp+0x50]
00007f582cdd4bda  vmovaps xmm6, [rsp+0x60]
00007f582cdd4be0  vmovaps xmm7, [rsp+0x70]
00007f582cdd4be6  vmovaps xmm8, [rsp+0x80]
00007f582cdd4bef  vmovaps xmm10, [rsp+0x90]
00007f582cdd4bf8  vmovaps xmm11, [rsp+0xA0]
00007f582cdd4c01  vmovaps xmm12, [rsp+0xB0]
00007f582cdd4c0a  vmovaps xmm13, [rsp+0xC0]
00007f582cdd4c13  vmovaps xmm14, [rsp+0xD0]
00007f582cdd4c1c  vmovaps xmm15, [rsp+0xE0]
00007f582cdd4c25  add rsp, 0xF0
00007f582cdd4c2c  pop r11
00007f582cdd4c2e  pop r10
00007f582cdd4c30  pop r9
00007f582cdd4c32  pop r8
00007f582cdd4c34  pop rsi
00007f582cdd4c35  pop rdi
00007f582cdd4c36  pop rdx
00007f582cdd4c37  pop rcx
00007f582cdd4c38  pop rax
00007f582cdd4c39  add rsp, 0x08
00007f582cdd4c3d  jmp 0x00007F582CDD01DD
00007f582cdd4c42  sub rsp, 0x08
00007f582cdd4c46  push rax
00007f582cdd4c47  push rcx
00007f582cdd4c48  push rdx
00007f582cdd4c49  push rdi
00007f582cdd4c4a  push rsi
00007f582cdd4c4b  push r8
00007f582cdd4c4d  push r9
00007f582cdd4c4f  push r10
00007f582cdd4c51  push r11
00007f582cdd4c53  sub rsp, 0xF0
00007f582cdd4c5a  vmovaps [rsp], xmm0
00007f582cdd4c5f  vmovaps [rsp+0x10], xmm1
00007f582cdd4c65  vmovaps [rsp+0x20], xmm2
00007f582cdd4c6b  vmovaps [rsp+0x30], xmm3
00007f582cdd4c71  vmovaps [rsp+0x40], xmm4
00007f582cdd4c77  vmovaps [rsp+0x50], xmm5
00007f582cdd4c7d  vmovaps [rsp+0x60], xmm6
00007f582cdd4c83  vmovaps [rsp+0x70], xmm7
00007f582cdd4c89  vmovaps [rsp+0x80], xmm8
00007f582cdd4c92  vmovaps [rsp+0x90], xmm9
00007f582cdd4c9b  vmovaps [rsp+0xA0], xmm10
00007f582cdd4ca4  vmovaps [rsp+0xB0], xmm11
00007f582cdd4cad  vmovaps [rsp+0xC0], xmm12
00007f582cdd4cb6  vmovaps [rsp+0xD0], xmm13
00007f582cdd4cbf  vmovaps [rsp+0xE0], xmm15
00007f582cdd4cc8  sub rsp, 0x30
00007f582cdd4ccc  movaps [rsp], xmm14
00007f582cdd4cd1  movaps [rsp+0x10], xmm4
00007f582cdd4cd6  movaps [rsp+0x20], xmm1
00007f582cdd4cdb  lea rdi, [rsp]
00007f582cdd4cdf  mov esi, 0x00
00007f582cdd4ce4  mov rax, 0x653B0D9BF530
00007f582cdd4cee  call rax
00007f582cdd4cf0  movaps xmm14, [rsp]
00007f582cdd4cf5  add rsp, 0x30
00007f582cdd4cf9  vmovaps xmm0, [rsp]
00007f582cdd4cfe  vmovaps xmm1, [rsp+0x10]
00007f582cdd4d04  vmovaps xmm2, [rsp+0x20]
00007f582cdd4d0a  vmovaps xmm3, [rsp+0x30]
00007f582cdd4d10  vmovaps xmm4, [rsp+0x40]
00007f582cdd4d16  vmovaps xmm5, [rsp+0x50]
00007f582cdd4d1c  vmovaps xmm6, [rsp+0x60]
00007f582cdd4d22  vmovaps xmm7, [rsp+0x70]
00007f582cdd4d28  vmovaps xmm8, [rsp+0x80]
00007f582cdd4d31  vmovaps xmm9, [rsp+0x90]
00007f582cdd4d3a  vmovaps xmm10, [rsp+0xA0]
00007f582cdd4d43  vmovaps xmm11, [rsp+0xB0]
00007f582cdd4d4c  vmovaps xmm12, [rsp+0xC0]
00007f582cdd4d55  vmovaps xmm13, [rsp+0xD0]
00007f582cdd4d5e  vmovaps xmm15, [rsp+0xE0]
00007f582cdd4d67  add rsp, 0xF0
00007f582cdd4d6e  pop r11
00007f582cdd4d70  pop r10
00007f582cdd4d72  pop r9
00007f582cdd4d74  pop r8
00007f582cdd4d76  pop rsi
00007f582cdd4d77  pop rdi
00007f582cdd4d78  pop rdx
00007f582cdd4d79  pop rcx
00007f582cdd4d7a  pop rax
00007f582cdd4d7b  add rsp, 0x08
00007f582cdd4d7f  jmp 0x00007F582CDD0203
00007f582cdd4d84  sub rsp, 0x08
00007f582cdd4d88  push rax
00007f582cdd4d89  push rcx
00007f582cdd4d8a  push rdx
00007f582cdd4d8b  push rdi
00007f582cdd4d8c  push rsi
00007f582cdd4d8d  push r8
00007f582cdd4d8f  push r9
00007f582cdd4d91  push r10
00007f582cdd4d93  push r11
00007f582cdd4d95  sub rsp, 0xF0
00007f582cdd4d9c  vmovaps [rsp], xmm0
00007f582cdd4da1  vmovaps [rsp+0x10], xmm2
00007f582cdd4da7  vmovaps [rsp+0x20], xmm3
00007f582cdd4dad  vmovaps [rsp+0x30], xmm4
00007f582cdd4db3  vmovaps [rsp+0x40], xmm5
00007f582cdd4db9  vmovaps [rsp+0x50], xmm6
00007f582cdd4dbf  vmovaps [rsp+0x60], xmm7
00007f582cdd4dc5  vmovaps [rsp+0x70], xmm8
00007f582cdd4dcb  vmovaps [rsp+0x80], xmm9
00007f582cdd4dd4  vmovaps [rsp+0x90], xmm10
00007f582cdd4ddd  vmovaps [rsp+0xA0], xmm11
00007f582cdd4de6  vmovaps [rsp+0xB0], xmm12
00007f582cdd4def  vmovaps [rsp+0xC0], xmm13
00007f582cdd4df8  vmovaps [rsp+0xD0], xmm14
00007f582cdd4e01  vmovaps [rsp+0xE0], xmm15
00007f582cdd4e0a  sub rsp, 0x30
00007f582cdd4e0e  movaps [rsp], xmm1
00007f582cdd4e12  movaps [rsp+0x10], xmm12
00007f582cdd4e18  movaps [rsp+0x20], xmm11
00007f582cdd4e1e  lea rdi, [rsp]
00007f582cdd4e22  mov esi, 0x00
00007f582cdd4e27  mov rax, 0x653B0D9BF530
00007f582cdd4e31  call rax
00007f582cdd4e33  movaps xmm1, [rsp]
00007f582cdd4e37  add rsp, 0x30
00007f582cdd4e3b  vmovaps xmm0, [rsp]
00007f582cdd4e40  vmovaps xmm2, [rsp+0x10]
00007f582cdd4e46  vmovaps xmm3, [rsp+0x20]
00007f582cdd4e4c  vmovaps xmm4, [rsp+0x30]
00007f582cdd4e52  vmovaps xmm5, [rsp+0x40]
00007f582cdd4e58  vmovaps xmm6, [rsp+0x50]
00007f582cdd4e5e  vmovaps xmm7, [rsp+0x60]
00007f582cdd4e64  vmovaps xmm8, [rsp+0x70]
00007f582cdd4e6a  vmovaps xmm9, [rsp+0x80]
00007f582cdd4e73  vmovaps xmm10, [rsp+0x90]
00007f582cdd4e7c  vmovaps xmm11, [rsp+0xA0]
00007f582cdd4e85  vmovaps xmm12, [rsp+0xB0]
00007f582cdd4e8e  vmovaps xmm13, [rsp+0xC0]
00007f582cdd4e97  vmovaps xmm14, [rsp+0xD0]
00007f582cdd4ea0  vmovaps xmm15, [rsp+0xE0]
00007f582cdd4ea9  add rsp, 0xF0
00007f582cdd4eb0  pop r11
00007f582cdd4eb2  pop r10
00007f582cdd4eb4  pop r9
00007f582cdd4eb6  pop r8
00007f582cdd4eb8  pop rsi
00007f582cdd4eb9  pop rdi
00007f582cdd4eba  pop rdx
00007f582cdd4ebb  pop rcx
00007f582cdd4ebc  pop rax
00007f582cdd4ebd  add rsp, 0x08
00007f582cdd4ec1  jmp 0x00007F582CDD0224
00007f582cdd4ec6  call 0x00007F582CCE20A0
00007f582cdd4ecb  jmp 0x00007F582CDD0232
00007f582cdd4ed0  call 0x00007F582CC09D70
00007f582cdd4ed5  jmp 0x00007F582CDD023C
00007f582cdd4eda  sub rsp, 0x08
00007f582cdd4ede  push rax
00007f582cdd4edf  push rcx
00007f582cdd4ee0  push rdx
00007f582cdd4ee1  push rdi
00007f582cdd4ee2  push rsi
00007f582cdd4ee3  push r8
00007f582cdd4ee5  push r9
00007f582cdd4ee7  push r10
00007f582cdd4ee9  push r11
00007f582cdd4eeb  sub rsp, 0xF0
00007f582cdd4ef2  vmovaps [rsp], xmm0
00007f582cdd4ef7  vmovaps [rsp+0x10], xmm1
00007f582cdd4efd  vmovaps [rsp+0x20], xmm2
00007f582cdd4f03  vmovaps [rsp+0x30], xmm3
00007f582cdd4f09  vmovaps [rsp+0x40], xmm4
00007f582cdd4f0f  vmovaps [rsp+0x50], xmm5
00007f582cdd4f15  vmovaps [rsp+0x60], xmm6
00007f582cdd4f1b  vmovaps [rsp+0x70], xmm8
00007f582cdd4f21  vmovaps [rsp+0x80], xmm9
00007f582cdd4f2a  vmovaps [rsp+0x90], xmm10
00007f582cdd4f33  vmovaps [rsp+0xA0], xmm11
00007f582cdd4f3c  vmovaps [rsp+0xB0], xmm12
00007f582cdd4f45  vmovaps [rsp+0xC0], xmm13
00007f582cdd4f4e  vmovaps [rsp+0xD0], xmm14
00007f582cdd4f57  vmovaps [rsp+0xE0], xmm15
00007f582cdd4f60  sub rsp, 0x30
00007f582cdd4f64  movaps [rsp], xmm7
00007f582cdd4f68  movaps [rsp+0x10], xmm15
00007f582cdd4f6e  movaps [rsp+0x20], xmm10
00007f582cdd4f74  lea rdi, [rsp]
00007f582cdd4f78  mov esi, 0x00
00007f582cdd4f7d  mov rax, 0x653B0D9BF530
00007f582cdd4f87  call rax
00007f582cdd4f89  movaps xmm7, [rsp]
00007f582cdd4f8d  add rsp, 0x30
00007f582cdd4f91  vmovaps xmm0, [rsp]
00007f582cdd4f96  vmovaps xmm1, [rsp+0x10]
00007f582cdd4f9c  vmovaps xmm2, [rsp+0x20]
00007f582cdd4fa2  vmovaps xmm3, [rsp+0x30]
00007f582cdd4fa8  vmovaps xmm4, [rsp+0x40]
00007f582cdd4fae  vmovaps xmm5, [rsp+0x50]
00007f582cdd4fb4  vmovaps xmm6, [rsp+0x60]
00007f582cdd4fba  vmovaps xmm8, [rsp+0x70]
00007f582cdd4fc0  vmovaps xmm9, [rsp+0x80]
00007f582cdd4fc9  vmovaps xmm10, [rsp+0x90]
00007f582cdd4fd2  vmovaps xmm11, [rsp+0xA0]
00007f582cdd4fdb  vmovaps xmm12, [rsp+0xB0]
00007f582cdd4fe4  vmovaps xmm13, [rsp+0xC0]
00007f582cdd4fed  vmovaps xmm14, [rsp+0xD0]
00007f582cdd4ff6  vmovaps xmm15, [rsp+0xE0]
00007f582cdd4fff  add rsp, 0xF0
00007f582cdd5006  pop r11
00007f582cdd5008  pop r10
00007f582cdd500a  pop r9
00007f582cdd500c  pop r8
00007f582cdd500e  pop rsi
00007f582cdd500f  pop rdi
00007f582cdd5010  pop rdx
00007f582cdd5011  pop rcx
00007f582cdd5012  pop rax
00007f582cdd5013  add rsp, 0x08
00007f582cdd5017  jmp 0x00007F582CDD025D
00007f582cdd501c  sub rsp, 0x08
00007f582cdd5020  push rax
00007f582cdd5021  push rcx
00007f582cdd5022  push rdx
00007f582cdd5023  push rdi
00007f582cdd5024  push rsi
00007f582cdd5025  push r8
00007f582cdd5027  push r9
00007f582cdd5029  push r10
00007f582cdd502b  push r11
00007f582cdd502d  sub rsp, 0xF0
00007f582cdd5034  vmovaps [rsp], xmm0
00007f582cdd5039  vmovaps [rsp+0x10], xmm1
00007f582cdd503f  vmovaps [rsp+0x20], xmm2
00007f582cdd5045  vmovaps [rsp+0x30], xmm3
00007f582cdd504b  vmovaps [rsp+0x40], xmm4
00007f582cdd5051  vmovaps [rsp+0x50], xmm5
00007f582cdd5057  vmovaps [rsp+0x60], xmm6
00007f582cdd505d  vmovaps [rsp+0x70], xmm7
00007f582cdd5063  vmovaps [rsp+0x80], xmm8
00007f582cdd506c  vmovaps [rsp+0x90], xmm9
00007f582cdd5075  vmovaps [rsp+0xA0], xmm11
00007f582cdd507e  vmovaps [rsp+0xB0], xmm12
00007f582cdd5087  vmovaps [rsp+0xC0], xmm13
00007f582cdd5090  vmovaps [rsp+0xD0], xmm14
00007f582cdd5099  vmovaps [rsp+0xE0], xmm15
00007f582cdd50a2  sub rsp, 0x30
00007f582cdd50a6  movaps [rsp], xmm10
00007f582cdd50ab  movaps [rsp+0x10], xmm11
00007f582cdd50b1  movaps [rsp+0x20], xmm15
00007f582cdd50b7  lea rdi, [rsp]
00007f582cdd50bb  mov esi, 0x00
00007f582cdd50c0  mov rax, 0x653B0D9BF530
00007f582cdd50ca  call rax
00007f582cdd50cc  movaps xmm10, [rsp]
00007f582cdd50d1  add rsp, 0x30
00007f582cdd50d5  vmovaps xmm0, [rsp]
00007f582cdd50da  vmovaps xmm1, [rsp+0x10]
00007f582cdd50e0  vmovaps xmm2, [rsp+0x20]
00007f582cdd50e6  vmovaps xmm3, [rsp+0x30]
00007f582cdd50ec  vmovaps xmm4, [rsp+0x40]
00007f582cdd50f2  vmovaps xmm5, [rsp+0x50]
00007f582cdd50f8  vmovaps xmm6, [rsp+0x60]
00007f582cdd50fe  vmovaps xmm7, [rsp+0x70]
00007f582cdd5104  vmovaps xmm8, [rsp+0x80]
00007f582cdd510d  vmovaps xmm9, [rsp+0x90]
00007f582cdd5116  vmovaps xmm11, [rsp+0xA0]
00007f582cdd511f  vmovaps xmm12, [rsp+0xB0]
00007f582cdd5128  vmovaps xmm13, [rsp+0xC0]
00007f582cdd5131  vmovaps xmm14, [rsp+0xD0]
00007f582cdd513a  vmovaps xmm15, [rsp+0xE0]
00007f582cdd5143  add rsp, 0xF0
00007f582cdd514a  pop r11
00007f582cdd514c  pop r10
00007f582cdd514e  pop r9
00007f582cdd5150  pop r8
00007f582cdd5152  pop rsi
00007f582cdd5153  pop rdi
00007f582cdd5154  pop rdx
00007f582cdd5155  pop rcx
00007f582cdd5156  pop rax
00007f582cdd5157  add rsp, 0x08
00007f582cdd515b  jmp 0x00007F582CDD028B
00007f582cdd5160  sub rsp, 0x08
00007f582cdd5164  push rax
00007f582cdd5165  push rcx
00007f582cdd5166  push rdx
00007f582cdd5167  push rdi
00007f582cdd5168  push rsi
00007f582cdd5169  push r8
00007f582cdd516b  push r9
00007f582cdd516d  push r10
00007f582cdd516f  push r11
00007f582cdd5171  sub rsp, 0xF0
00007f582cdd5178  vmovaps [rsp], xmm0
00007f582cdd517d  vmovaps [rsp+0x10], xmm1
00007f582cdd5183  vmovaps [rsp+0x20], xmm2
00007f582cdd5189  vmovaps [rsp+0x30], xmm3
00007f582cdd518f  vmovaps [rsp+0x40], xmm4
00007f582cdd5195  vmovaps [rsp+0x50], xmm5
00007f582cdd519b  vmovaps [rsp+0x60], xmm6
00007f582cdd51a1  vmovaps [rsp+0x70], xmm7
00007f582cdd51a7  vmovaps [rsp+0x80], xmm8
00007f582cdd51b0  vmovaps [rsp+0x90], xmm9
00007f582cdd51b9  vmovaps [rsp+0xA0], xmm10
00007f582cdd51c2  vmovaps [rsp+0xB0], xmm12
00007f582cdd51cb  vmovaps [rsp+0xC0], xmm13
00007f582cdd51d4  vmovaps [rsp+0xD0], xmm14
00007f582cdd51dd  vmovaps [rsp+0xE0], xmm15
00007f582cdd51e6  sub rsp, 0x30
00007f582cdd51ea  movaps [rsp], xmm11
00007f582cdd51ef  movaps [rsp+0x10], xmm12
00007f582cdd51f5  movaps [rsp+0x20], xmm15
00007f582cdd51fb  lea rdi, [rsp]
00007f582cdd51ff  mov esi, 0x00
00007f582cdd5204  mov rax, 0x653B0D9BF530
00007f582cdd520e  call rax
00007f582cdd5210  movaps xmm11, [rsp]
00007f582cdd5215  add rsp, 0x30
00007f582cdd5219  vmovaps xmm0, [rsp]
00007f582cdd521e  vmovaps xmm1, [rsp+0x10]
00007f582cdd5224  vmovaps xmm2, [rsp+0x20]
00007f582cdd522a  vmovaps xmm3, [rsp+0x30]
00007f582cdd5230  vmovaps xmm4, [rsp+0x40]
00007f582cdd5236  vmovaps xmm5, [rsp+0x50]
00007f582cdd523c  vmovaps xmm6, [rsp+0x60]
00007f582cdd5242  vmovaps xmm7, [rsp+0x70]
00007f582cdd5248  vmovaps xmm8, [rsp+0x80]
00007f582cdd5251  vmovaps xmm9, [rsp+0x90]
00007f582cdd525a  vmovaps xmm10, [rsp+0xA0]
00007f582cdd5263  vmovaps xmm12, [rsp+0xB0]
00007f582cdd526c  vmovaps xmm13, [rsp+0xC0]
00007f582cdd5275  vmovaps xmm14, [rsp+0xD0]
00007f582cdd527e  vmovaps xmm15, [rsp+0xE0]
00007f582cdd5287  add rsp, 0xF0
00007f582cdd528e  pop r11
00007f582cdd5290  pop r10
00007f582cdd5292  pop r9
00007f582cdd5294  pop r8
00007f582cdd5296  pop rsi
00007f582cdd5297  pop rdi
00007f582cdd5298  pop rdx
00007f582cdd5299  pop rcx
00007f582cdd529a  pop rax
00007f582cdd529b  add rsp, 0x08
00007f582cdd529f  jmp 0x00007F582CDD02B9
00007f582cdd52a4  sub rsp, 0x08
00007f582cdd52a8  push rax
00007f582cdd52a9  push rcx
00007f582cdd52aa  push rdx
00007f582cdd52ab  push rdi
00007f582cdd52ac  push rsi
00007f582cdd52ad  push r8
00007f582cdd52af  push r9
00007f582cdd52b1  push r10
00007f582cdd52b3  push r11
00007f582cdd52b5  sub rsp, 0xF0
00007f582cdd52bc  vmovaps [rsp], xmm0
00007f582cdd52c1  vmovaps [rsp+0x10], xmm1
00007f582cdd52c7  vmovaps [rsp+0x20], xmm2
00007f582cdd52cd  vmovaps [rsp+0x30], xmm3
00007f582cdd52d3  vmovaps [rsp+0x40], xmm4
00007f582cdd52d9  vmovaps [rsp+0x50], xmm5
00007f582cdd52df  vmovaps [rsp+0x60], xmm6
00007f582cdd52e5  vmovaps [rsp+0x70], xmm7
00007f582cdd52eb  vmovaps [rsp+0x80], xmm8
00007f582cdd52f4  vmovaps [rsp+0x90], xmm9
00007f582cdd52fd  vmovaps [rsp+0xA0], xmm10
00007f582cdd5306  vmovaps [rsp+0xB0], xmm11
00007f582cdd530f  vmovaps [rsp+0xC0], xmm12
00007f582cdd5318  vmovaps [rsp+0xD0], xmm13
00007f582cdd5321  vmovaps [rsp+0xE0], xmm14
00007f582cdd532a  sub rsp, 0x30
00007f582cdd532e  movaps [rsp], xmm15
00007f582cdd5333  movaps [rsp+0x10], xmm13
00007f582cdd5339  movaps [rsp+0x20], xmm9
00007f582cdd533f  lea rdi, [rsp]
00007f582cdd5343  mov esi, 0x00
00007f582cdd5348  mov rax, 0x653B0D9BF530
00007f582cdd5352  call rax
00007f582cdd5354  movaps xmm15, [rsp]
00007f582cdd5359  add rsp, 0x30
00007f582cdd535d  vmovaps xmm0, [rsp]
00007f582cdd5362  vmovaps xmm1, [rsp+0x10]
00007f582cdd5368  vmovaps xmm2, [rsp+0x20]
00007f582cdd536e  vmovaps xmm3, [rsp+0x30]
00007f582cdd5374  vmovaps xmm4, [rsp+0x40]
00007f582cdd537a  vmovaps xmm5, [rsp+0x50]
00007f582cdd5380  vmovaps xmm6, [rsp+0x60]
00007f582cdd5386  vmovaps xmm7, [rsp+0x70]
00007f582cdd538c  vmovaps xmm8, [rsp+0x80]
00007f582cdd5395  vmovaps xmm9, [rsp+0x90]
00007f582cdd539e  vmovaps xmm10, [rsp+0xA0]
00007f582cdd53a7  vmovaps xmm11, [rsp+0xB0]
00007f582cdd53b0  vmovaps xmm12, [rsp+0xC0]
00007f582cdd53b9  vmovaps xmm13, [rsp+0xD0]
00007f582cdd53c2  vmovaps xmm14, [rsp+0xE0]
00007f582cdd53cb  add rsp, 0xF0
00007f582cdd53d2  pop r11
00007f582cdd53d4  pop r10
00007f582cdd53d6  pop r9
00007f582cdd53d8  pop r8
00007f582cdd53da  pop rsi
00007f582cdd53db  pop rdi
00007f582cdd53dc  pop rdx
00007f582cdd53dd  pop rcx
00007f582cdd53de  pop rax
00007f582cdd53df  add rsp, 0x08
00007f582cdd53e3  jmp 0x00007F582CDD02D4
00007f582cdd53e8  sub rsp, 0x08
00007f582cdd53ec  push rax
00007f582cdd53ed  push rcx
00007f582cdd53ee  push rdx
00007f582cdd53ef  push rdi
00007f582cdd53f0  push rsi
00007f582cdd53f1  push r8
00007f582cdd53f3  push r9
00007f582cdd53f5  push r10
00007f582cdd53f7  push r11
00007f582cdd53f9  sub rsp, 0xF0
00007f582cdd5400  vmovaps [rsp], xmm0
00007f582cdd5405  vmovaps [rsp+0x10], xmm1
00007f582cdd540b  vmovaps [rsp+0x20], xmm2
00007f582cdd5411  vmovaps [rsp+0x30], xmm3
00007f582cdd5417  vmovaps [rsp+0x40], xmm4
00007f582cdd541d  vmovaps [rsp+0x50], xmm5
00007f582cdd5423  vmovaps [rsp+0x60], xmm6
00007f582cdd5429  vmovaps [rsp+0x70], xmm7
00007f582cdd542f  vmovaps [rsp+0x80], xmm8
00007f582cdd5438  vmovaps [rsp+0x90], xmm9
00007f582cdd5441  vmovaps [rsp+0xA0], xmm10
00007f582cdd544a  vmovaps [rsp+0xB0], xmm11
00007f582cdd5453  vmovaps [rsp+0xC0], xmm12
00007f582cdd545c  vmovaps [rsp+0xD0], xmm14
00007f582cdd5465  vmovaps [rsp+0xE0], xmm15
00007f582cdd546e  sub rsp, 0x30
00007f582cdd5472  movaps [rsp], xmm13
00007f582cdd5477  movaps [rsp+0x10], xmm8
00007f582cdd547d  movaps [rsp+0x20], xmm14
00007f582cdd5483  lea rdi, [rsp]
00007f582cdd5487  mov esi, 0x00
00007f582cdd548c  mov rax, 0x653B0D9BF530
00007f582cdd5496  call rax
00007f582cdd5498  movaps xmm13, [rsp]
00007f582cdd549d  add rsp, 0x30
00007f582cdd54a1  vmovaps xmm0, [rsp]
00007f582cdd54a6  vmovaps xmm1, [rsp+0x10]
00007f582cdd54ac  vmovaps xmm2, [rsp+0x20]
00007f582cdd54b2  vmovaps xmm3, [rsp+0x30]
00007f582cdd54b8  vmovaps xmm4, [rsp+0x40]
00007f582cdd54be  vmovaps xmm5, [rsp+0x50]
00007f582cdd54c4  vmovaps xmm6, [rsp+0x60]
00007f582cdd54ca  vmovaps xmm7, [rsp+0x70]
00007f582cdd54d0  vmovaps xmm8, [rsp+0x80]
00007f582cdd54d9  vmovaps xmm9, [rsp+0x90]
00007f582cdd54e2  vmovaps xmm10, [rsp+0xA0]
00007f582cdd54eb  vmovaps xmm11, [rsp+0xB0]
00007f582cdd54f4  vmovaps xmm12, [rsp+0xC0]
00007f582cdd54fd  vmovaps xmm14, [rsp+0xD0]
00007f582cdd5506  vmovaps xmm15, [rsp+0xE0]
00007f582cdd550f  add rsp, 0xF0
00007f582cdd5516  pop r11
00007f582cdd5518  pop r10
00007f582cdd551a  pop r9
00007f582cdd551c  pop r8
00007f582cdd551e  pop rsi
00007f582cdd551f  pop rdi
00007f582cdd5520  pop rdx
00007f582cdd5521  pop rcx
00007f582cdd5522  pop rax
00007f582cdd5523  add rsp, 0x08
00007f582cdd5527  jmp 0x00007F582CDD02F7
00007f582cdd552c  sub rsp, 0x08
00007f582cdd5530  push rax
00007f582cdd5531  push rcx
00007f582cdd5532  push rdx
00007f582cdd5533  push rdi
00007f582cdd5534  push rsi
00007f582cdd5535  push r8
00007f582cdd5537  push r9
00007f582cdd5539  push r10
00007f582cdd553b  push r11
00007f582cdd553d  sub rsp, 0xF0
00007f582cdd5544  vmovaps [rsp], xmm0
00007f582cdd5549  vmovaps [rsp+0x10], xmm1
00007f582cdd554f  vmovaps [rsp+0x20], xmm2
00007f582cdd5555  vmovaps [rsp+0x30], xmm3
00007f582cdd555b  vmovaps [rsp+0x40], xmm4
00007f582cdd5561  vmovaps [rsp+0x50], xmm5
00007f582cdd5567  vmovaps [rsp+0x60], xmm6
00007f582cdd556d  vmovaps [rsp+0x70], xmm7
00007f582cdd5573  vmovaps [rsp+0x80], xmm8
00007f582cdd557c  vmovaps [rsp+0x90], xmm9
00007f582cdd5585  vmovaps [rsp+0xA0], xmm10
00007f582cdd558e  vmovaps [rsp+0xB0], xmm11
00007f582cdd5597  vmovaps [rsp+0xC0], xmm12
00007f582cdd55a0  vmovaps [rsp+0xD0], xmm13
00007f582cdd55a9  vmovaps [rsp+0xE0], xmm15
00007f582cdd55b2  sub rsp, 0x30
00007f582cdd55b6  movaps [rsp], xmm14
00007f582cdd55bb  movaps [rsp+0x10], xmm1
00007f582cdd55c0  movaps [rsp+0x20], xmm10
00007f582cdd55c6  lea rdi, [rsp]
00007f582cdd55ca  mov esi, 0x00
00007f582cdd55cf  mov rax, 0x653B0D9BF530
00007f582cdd55d9  call rax
00007f582cdd55db  movaps xmm14, [rsp]
00007f582cdd55e0  add rsp, 0x30
00007f582cdd55e4  vmovaps xmm0, [rsp]
00007f582cdd55e9  vmovaps xmm1, [rsp+0x10]
00007f582cdd55ef  vmovaps xmm2, [rsp+0x20]
00007f582cdd55f5  vmovaps xmm3, [rsp+0x30]
00007f582cdd55fb  vmovaps xmm4, [rsp+0x40]
00007f582cdd5601  vmovaps xmm5, [rsp+0x50]
00007f582cdd5607  vmovaps xmm6, [rsp+0x60]
00007f582cdd560d  vmovaps xmm7, [rsp+0x70]
00007f582cdd5613  vmovaps xmm8, [rsp+0x80]
00007f582cdd561c  vmovaps xmm9, [rsp+0x90]
00007f582cdd5625  vmovaps xmm10, [rsp+0xA0]
00007f582cdd562e  vmovaps xmm11, [rsp+0xB0]
00007f582cdd5637  vmovaps xmm12, [rsp+0xC0]
00007f582cdd5640  vmovaps xmm13, [rsp+0xD0]
00007f582cdd5649  vmovaps xmm15, [rsp+0xE0]
00007f582cdd5652  add rsp, 0xF0
00007f582cdd5659  pop r11
00007f582cdd565b  pop r10
00007f582cdd565d  pop r9
00007f582cdd565f  pop r8
00007f582cdd5661  pop rsi
00007f582cdd5662  pop rdi
00007f582cdd5663  pop rdx
00007f582cdd5664  pop rcx
00007f582cdd5665  pop rax
00007f582cdd5666  add rsp, 0x08
00007f582cdd566a  jmp 0x00007F582CDD031A
00007f582cdd566f  sub rsp, 0x08
00007f582cdd5673  push rax
00007f582cdd5674  push rcx
00007f582cdd5675  push rdx
00007f582cdd5676  push rdi
00007f582cdd5677  push rsi
00007f582cdd5678  push r8
00007f582cdd567a  push r9
00007f582cdd567c  push r10
00007f582cdd567e  push r11
00007f582cdd5680  sub rsp, 0xF0
00007f582cdd5687  vmovaps [rsp], xmm0
00007f582cdd568c  vmovaps [rsp+0x10], xmm2
00007f582cdd5692  vmovaps [rsp+0x20], xmm3
00007f582cdd5698  vmovaps [rsp+0x30], xmm4
00007f582cdd569e  vmovaps [rsp+0x40], xmm5
00007f582cdd56a4  vmovaps [rsp+0x50], xmm6
00007f582cdd56aa  vmovaps [rsp+0x60], xmm7
00007f582cdd56b0  vmovaps [rsp+0x70], xmm8
00007f582cdd56b6  vmovaps [rsp+0x80], xmm9
00007f582cdd56bf  vmovaps [rsp+0x90], xmm10
00007f582cdd56c8  vmovaps [rsp+0xA0], xmm11
00007f582cdd56d1  vmovaps [rsp+0xB0], xmm12
00007f582cdd56da  vmovaps [rsp+0xC0], xmm13
00007f582cdd56e3  vmovaps [rsp+0xD0], xmm14
00007f582cdd56ec  vmovaps [rsp+0xE0], xmm15
00007f582cdd56f5  sub rsp, 0x30
00007f582cdd56f9  movaps [rsp], xmm1
00007f582cdd56fd  movaps [rsp+0x10], xmm7
00007f582cdd5702  movaps [rsp+0x20], xmm11
00007f582cdd5708  lea rdi, [rsp]
00007f582cdd570c  mov esi, 0x00
00007f582cdd5711  mov rax, 0x653B0D9BF530
00007f582cdd571b  call rax
00007f582cdd571d  movaps xmm1, [rsp]
00007f582cdd5721  add rsp, 0x30
00007f582cdd5725  vmovaps xmm0, [rsp]
00007f582cdd572a  vmovaps xmm2, [rsp+0x10]
00007f582cdd5730  vmovaps xmm3, [rsp+0x20]
00007f582cdd5736  vmovaps xmm4, [rsp+0x30]
00007f582cdd573c  vmovaps xmm5, [rsp+0x40]
00007f582cdd5742  vmovaps xmm6, [rsp+0x50]
00007f582cdd5748  vmovaps xmm7, [rsp+0x60]
00007f582cdd574e  vmovaps xmm8, [rsp+0x70]
00007f582cdd5754  vmovaps xmm9, [rsp+0x80]
00007f582cdd575d  vmovaps xmm10, [rsp+0x90]
00007f582cdd5766  vmovaps xmm11, [rsp+0xA0]
00007f582cdd576f  vmovaps xmm12, [rsp+0xB0]
00007f582cdd5778  vmovaps xmm13, [rsp+0xC0]
00007f582cdd5781  vmovaps xmm14, [rsp+0xD0]
00007f582cdd578a  vmovaps xmm15, [rsp+0xE0]
00007f582cdd5793  add rsp, 0xF0
00007f582cdd579a  pop r11
00007f582cdd579c  pop r10
00007f582cdd579e  pop r9
00007f582cdd57a0  pop r8
00007f582cdd57a2  pop rsi
00007f582cdd57a3  pop rdi
00007f582cdd57a4  pop rdx
00007f582cdd57a5  pop rcx
00007f582cdd57a6  pop rax
00007f582cdd57a7  add rsp, 0x08
00007f582cdd57ab  jmp 0x00007F582CDD033B
00007f582cdd57b0  call 0x00007F582CC0E880
00007f582cdd57b5  jmp 0x00007F582CDD034E
00007f582cdd57ba  call 0x00007F582CC0C380
00007f582cdd57bf  jmp 0x00007F582CDD0359
00007f582cdd57c4  call 0x00007F582CC0D600
00007f582cdd57c9  jmp 0x00007F582CDD0364
00007f582cdd57ce  call 0x00007F582CBFF540
00007f582cdd57d3  jmp 0x00007F582CDD036F
00007f582cdd57d8  int3
00007f582cdd57d9  nop [rax], eax
00007f582cdd57e0  mov rax, [r15+0x40]
00007f582cdd57e4  mov r14, [r15+0x58]
00007f582cdd57e8  lea r12, [rax+r14*1]
00007f582cdd57ec  movaps xmm1, [r15+0x1D0]
00007f582cdd57f4  vmovaps [rsp+0x10], xmm1
00007f582cdd57fa  vmovaps xmm15, [rsp+0x10]
00007f582cdd5800  por xmm1, xmm15
00007f582cdd5805  movaps xmm14, [r15+0x1A0]
00007f582cdd580d  vmovaps [rsp+0x10], xmm14
00007f582cdd5813  vmovaps xmm13, [rsp+0x10]
00007f582cdd5819  por xmm14, xmm13
00007f582cdd581e  lea rax, [r12+0x30]
00007f582cdd5823  mov r11, [r13+rax*1]
00007f582cdd5828  lea rax, [r12+0x38]
00007f582cdd582d  mov r10, [r13+rax*1]
00007f582cdd5832  movq xmm13, r11
00007f582cdd5837  movq xmm12, r10
00007f582cdd583c  movq xmm13, xmm13
00007f582cdd5841  vmovaps [rsp+0x10], xmm13
00007f582cdd5847  movq xmm13, xmm13
00007f582cdd584c  movaps [r15+0x130], xmm13
00007f582cdd5854  movq xmm12, xmm12
00007f582cdd5859  vmovaps [rsp+0x20], xmm12
00007f582cdd585f  movq xmm12, xmm12
00007f582cdd5864  movaps [r15+0x280], xmm12
00007f582cdd586c  movaps xmm13, [r15+0x270]
00007f582cdd5874  vmovaps [rsp+0x30], xmm13
00007f582cdd587a  vmovaps xmm12, [rsp+0x30]
00007f582cdd5880  por xmm13, xmm12
00007f582cdd5885  lea rax, [r12+0x20]
00007f582cdd588a  mov r11, [r13+rax*1]
00007f582cdd588f  lea rax, [r12+0x28]
00007f582cdd5894  mov r10, [r13+rax*1]
00007f582cdd5899  movq xmm12, r11
00007f582cdd589e  movq xmm11, r10
00007f582cdd58a3  movq xmm12, xmm12
00007f582cdd58a8  vmovaps [rsp+0x30], xmm12
00007f582cdd58ae  movq xmm12, xmm12
00007f582cdd58b3  movaps [r15+0x150], xmm12
00007f582cdd58bb  movq xmm11, xmm11
00007f582cdd58c0  vmovaps [rsp+0x40], xmm11
00007f582cdd58c6  movq xmm11, xmm11
00007f582cdd58cb  movaps [r15+0x140], xmm11
00007f582cdd58d3  lea rax, [r12+0x10]
00007f582cdd58d8  mov r11, [r13+rax*1]
00007f582cdd58dd  lea rax, [r12+0x18]
00007f582cdd58e2  mov r10, [r13+rax*1]
00007f582cdd58e7  movq xmm12, r11
00007f582cdd58ec  movq xmm11, r10
00007f582cdd58f1  movq xmm12, xmm12
00007f582cdd58f6  vmovaps [rsp+0x50], xmm12
00007f582cdd58fc  movq xmm12, xmm12
00007f582cdd5901  movaps [r15+0x170], xmm12
00007f582cdd5909  movq xmm11, xmm11
00007f582cdd590e  vmovaps [rsp+0x60], xmm11
00007f582cdd5914  movq xmm11, xmm11
00007f582cdd5919  movaps [r15+0x160], xmm11
00007f582cdd5921  mov rax, [r13+r12*1]
00007f582cdd5926  vmovq xmm12, rax
00007f582cdd592b  vpbroadcastq xmm12, xmm12
00007f582cdd5930  lea rax, [r12+0x08]
00007f582cdd5935  mov r12, [r13+rax*1]
00007f582cdd593a  movq xmm11, r12
00007f582cdd593f  movaps [r15+0x230], xmm11
00007f582cdd5947  mov rax, [r15+0xF8]
00007f582cdd594e  lea r12, [rax+0x50]
00007f582cdd5952  movups xmm11, [r13+r12*1]
00007f582cdd5958  lea r12, [rax+0x60]
00007f582cdd595c  movups xmm10, [r13+r12*1]
00007f582cdd5962  lea r12, [rax+0x30]
00007f582cdd5966  movups xmm9, [r13+r12*1]
00007f582cdd596c  mov r12, [r15+0x50]
00007f582cdd5970  lea r11, [r12+r14*1]
00007f582cdd5974  mov [r15+0x60], r11
00007f582cdd5978  lea r12, [r14+0x40]
00007f582cdd597c  mov [r15+0x58], r12
00007f582cdd5980  movaps xmm8, xmm12
00007f582cdd5984  mulpd xmm8, xmm15
00007f582cdd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007f582cdd598f  ptest xmm7, xmm7
00007f582cdd5994  jnz 0x00007F582CDD67B7
00007f582cdd599a  movq xmm15, qword ptr [r15+0x230]
00007f582cdd59a3  vmovaps [rsp+0x70], xmm15
00007f582cdd59a9  vpermilpd xmm15, xmm15, 0x00
00007f582cdd59af  movaps xmm7, xmm9
00007f582cdd59b3  mulpd xmm7, xmm15
00007f582cdd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007f582cdd59bd  ptest xmm6, xmm6
00007f582cdd59c2  jnz 0x00007F582CDD68FB
00007f582cdd59c8  vxorps xmm15, xmm15, xmm15
00007f582cdd59cd  vpbroadcastq xmm15, xmm15
00007f582cdd59d2  movaps xmm9, xmm12
00007f582cdd59d6  mulpd xmm9, xmm10
00007f582cdd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007f582cdd59e1  ptest xmm6, xmm6
00007f582cdd59e6  jnz 0x00007F582CDD6A3D
00007f582cdd59ec  movaps xmm10, xmm12
00007f582cdd59f0  mulpd xmm10, xmm11
00007f582cdd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007f582cdd59fb  ptest xmm6, xmm6
00007f582cdd5a00  jnz 0x00007F582CDD6B81
00007f582cdd5a06  movaps xmm11, [r15+0x1F0]
00007f582cdd5a0e  movaps xmm6, xmm12
00007f582cdd5a12  mulpd xmm6, xmm11
00007f582cdd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007f582cdd5a1c  ptest xmm5, xmm5
00007f582cdd5a21  jnz 0x00007F582CDD6CC5
00007f582cdd5a27  movaps xmm12, [r15+0x2A0]
00007f582cdd5a2f  vmovaps [rsp+0x80], xmm12
00007f582cdd5a38  vmovaps xmm11, [rsp+0x80]
00007f582cdd5a41  por xmm12, xmm11
00007f582cdd5a46  movaps xmm11, [r15+0x250]
00007f582cdd5a4e  vmovaps [rsp+0x80], xmm11
00007f582cdd5a57  vmovaps xmm5, [rsp+0x80]
00007f582cdd5a60  por xmm11, xmm5
00007f582cdd5a65  vmovaps xmm4, [rsp+0x70]
00007f582cdd5a6b  vpermilpd xmm4, xmm4, 0x00
00007f582cdd5a71  movaps xmm3, xmm5
00007f582cdd5a74  mulpd xmm3, xmm4
00007f582cdd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007f582cdd5a7d  ptest xmm2, xmm2
00007f582cdd5a82  jnz 0x00007F582CDD6E07
00007f582cdd5a88  mov [rsp+0x80], rax
00007f582cdd5a90  xor eax, eax
00007f582cdd5a92  mov r14d, 0x200
00007f582cdd5a98  cmp r12, r14
00007f582cdd5a9b  cmc
00007f582cdd5a9c  lahf
00007f582cdd5a9d  seto al
00007f582cdd5aa0  mov [r15+0x108], eax
00007f582cdd5aa7  movaps xmm5, xmm8
00007f582cdd5aab  addpd xmm5, xmm15
00007f582cdd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007f582cdd5ab5  ptest xmm4, xmm4
00007f582cdd5aba  jnz 0x00007F582CDD6F47
00007f582cdd5ac0  movaps xmm8, [r15+0x1B0]
00007f582cdd5ac8  movaps xmm4, xmm9
00007f582cdd5acc  addpd xmm4, xmm8
00007f582cdd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007f582cdd5ad6  ptest xmm2, xmm2
00007f582cdd5adb  jnz 0x00007F582CDD7089
00007f582cdd5ae1  movaps xmm9, xmm10
00007f582cdd5ae5  addpd xmm9, xmm8
00007f582cdd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007f582cdd5af0  ptest xmm2, xmm2
00007f582cdd5af5  jnz 0x00007F582CDD71CB
00007f582cdd5afb  movaps xmm10, [r15+0x2F0]
00007f582cdd5b03  vmovaps [rsp+0x90], xmm10
00007f582cdd5b0c  vmovaps xmm8, [rsp+0x90]
00007f582cdd5b15  por xmm10, xmm8
00007f582cdd5b1a  movaps xmm8, [r15+0x2E0]
00007f582cdd5b22  vmovaps [rsp+0x90], xmm8
00007f582cdd5b2b  vmovaps xmm2, [rsp+0x90]
00007f582cdd5b34  por xmm8, xmm2
00007f582cdd5b39  movaps xmm2, [r15+0x2D0]
00007f582cdd5b41  vmovaps [rsp+0x90], xmm2
00007f582cdd5b4a  vmovaps [rsp+0xA0], xmm1
00007f582cdd5b53  vmovaps xmm1, [rsp+0x90]
00007f582cdd5b5c  por xmm2, xmm1
00007f582cdd5b60  movaps xmm1, [r15+0x200]
00007f582cdd5b68  vmovaps [rsp+0x90], xmm1
00007f582cdd5b71  vmovaps [rsp+0xB0], xmm15
00007f582cdd5b7a  vmovaps xmm15, [rsp+0x90]
00007f582cdd5b83  por xmm1, xmm15
00007f582cdd5b88  movaps xmm15, [r15+0x1C0]
00007f582cdd5b90  vmovaps [rsp+0x90], xmm15
00007f582cdd5b99  vmovaps [rsp+0xC0], xmm1
00007f582cdd5ba2  vmovaps xmm1, [rsp+0x90]
00007f582cdd5bab  por xmm15, xmm1
00007f582cdd5bb0  movaps xmm1, [r15+0x190]
00007f582cdd5bb8  vmovaps [rsp+0x90], xmm1
00007f582cdd5bc1  vmovaps [rsp+0xD0], xmm15
00007f582cdd5bca  vmovaps xmm15, [rsp+0x90]
00007f582cdd5bd3  por xmm1, xmm15
00007f582cdd5bd8  movaps xmm15, [r15+0x300]
00007f582cdd5be0  vmovaps [rsp+0x90], xmm15
00007f582cdd5be9  vmovaps [rsp+0xE0], xmm1
00007f582cdd5bf2  vmovaps xmm1, [rsp+0x90]
00007f582cdd5bfb  por xmm15, xmm1
00007f582cdd5c00  mov rax, [rsp+0x80]
00007f582cdd5c08  lea r14, [rax+0xA0]
00007f582cdd5c0f  movups xmm1, [r13+r14*1]
00007f582cdd5c15  lea r14, [rax+0xB0]
00007f582cdd5c1c  vmovaps [rsp+0x80], xmm1
00007f582cdd5c25  movups xmm1, [r13+r14*1]
00007f582cdd5c2b  vmovaps [rsp+0x90], xmm1
00007f582cdd5c34  vmovaps [rsp+0xF0], xmm15
00007f582cdd5c3d  vmovaps xmm15, [rsp+0xB0]
00007f582cdd5c46  vmovaps [rsp+0xB0], xmm14
00007f582cdd5c4f  movaps xmm1, xmm6
00007f582cdd5c52  addpd xmm1, xmm15
00007f582cdd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007f582cdd5c5c  ptest xmm14, xmm14
00007f582cdd5c62  jnz 0x00007F582CDD7323
00007f582cdd5c68  lea r14, [rax+0xF0]
00007f582cdd5c6f  movups xmm15, [r13+r14*1]
00007f582cdd5c75  movaps xmm14, xmm4
00007f582cdd5c79  addpd xmm14, xmm3
00007f582cdd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007f582cdd5c84  ptest xmm6, xmm6
00007f582cdd5c89  jnz 0x00007F582CDD746E
00007f582cdd5c8f  movaps xmm6, xmm9
00007f582cdd5c93  addpd xmm6, xmm7
00007f582cdd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007f582cdd5c9c  ptest xmm4, xmm4
00007f582cdd5ca1  jnz 0x00007F582CDD75B0
00007f582cdd5ca7  vmovaps xmm9, [rsp+0x70]
00007f582cdd5cad  vpermilpd xmm9, xmm9, 0x00
00007f582cdd5cb3  vmovaps xmm4, [rsp+0x90]
00007f582cdd5cbc  movaps xmm7, xmm4
00007f582cdd5cbf  mulpd xmm7, xmm9
00007f582cdd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007f582cdd5cc9  ptest xmm3, xmm3
00007f582cdd5cce  jnz 0x00007F582CDD76F1
00007f582cdd5cd4  vmovaps xmm9, [rsp+0x50]
00007f582cdd5cda  vpermilpd xmm9, xmm9, 0x00
00007f582cdd5ce0  movaps xmm4, xmm15
00007f582cdd5ce4  mulpd xmm4, xmm9
00007f582cdd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007f582cdd5cee  ptest xmm3, xmm3
00007f582cdd5cf3  jnz 0x00007F582CDD7832
00007f582cdd5cf9  lea r14, [rax+0xE0]
00007f582cdd5d00  movups xmm15, [r13+r14*1]
00007f582cdd5d06  vmovaps xmm9, [rsp+0x70]
00007f582cdd5d0c  vpermilpd xmm9, xmm9, 0x00
00007f582cdd5d12  vmovaps [rsp+0x70], xmm1
00007f582cdd5d18  vmovaps xmm1, [rsp+0x80]
00007f582cdd5d21  vmovaps [rsp+0x80], xmm15
00007f582cdd5d2a  movaps xmm3, xmm1
00007f582cdd5d2d  mulpd xmm3, xmm9
00007f582cdd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007f582cdd5d37  ptest xmm15, xmm15
00007f582cdd5d3d  jnz 0x00007F582CDD797E
00007f582cdd5d43  vmovaps xmm1, [rsp+0xF0]
00007f582cdd5d4c  vmovaps xmm15, [rsp+0xF0]
00007f582cdd5d55  por xmm1, xmm15
00007f582cdd5d5a  movaps [r15+0x300], xmm1
00007f582cdd5d62  vmovaps xmm15, [rsp+0xE0]
00007f582cdd5d6b  vmovaps xmm9, [rsp+0xE0]
00007f582cdd5d74  por xmm15, xmm9
00007f582cdd5d79  movaps [r15+0x190], xmm15
00007f582cdd5d81  vmovaps xmm9, [rsp+0x50]
00007f582cdd5d87  vpermilpd xmm9, xmm9, 0x00
00007f582cdd5d8d  vmovaps [rsp+0x90], xmm1
00007f582cdd5d96  vmovaps [rsp+0xE0], xmm15
00007f582cdd5d9f  vmovaps xmm15, [rsp+0x80]
00007f582cdd5da8  vmovaps [rsp+0x80], xmm14
00007f582cdd5db1  movaps xmm1, xmm15
00007f582cdd5db5  mulpd xmm1, xmm9
00007f582cdd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007f582cdd5dbf  ptest xmm14, xmm14
00007f582cdd5dc5  jnz 0x00007F582CDD7ABF
00007f582cdd5dcb  lea r14, [rax+0x90]
00007f582cdd5dd2  movups xmm15, [r13+r14*1]
00007f582cdd5dd8  vmovaps xmm14, [rsp+0xD0]
00007f582cdd5de1  vmovaps xmm9, [rsp+0xD0]
00007f582cdd5dea  por xmm14, xmm9
00007f582cdd5def  movaps [r15+0x1C0], xmm14
00007f582cdd5df7  vmovaps xmm9, [rsp+0xC0]
00007f582cdd5e00  vmovaps [rsp+0xD0], xmm1
00007f582cdd5e09  vmovaps xmm1, [rsp+0xC0]
00007f582cdd5e12  por xmm9, xmm1
00007f582cdd5e17  movaps [r15+0x200], xmm9
00007f582cdd5e1f  vmovaps [rsp+0xC0], xmm2
00007f582cdd5e28  vmovaps xmm1, [rsp+0xC0]
00007f582cdd5e31  por xmm2, xmm1
00007f582cdd5e35  movaps [r15+0x2D0], xmm2
00007f582cdd5e3d  vmovaps [rsp+0xC0], xmm8
00007f582cdd5e46  vmovaps xmm1, [rsp+0xC0]
00007f582cdd5e4f  por xmm8, xmm1
00007f582cdd5e54  movaps [r15+0x2E0], xmm8
00007f582cdd5e5c  vmovaps [rsp+0xC0], xmm15
00007f582cdd5e65  movaps xmm1, xmm5
00007f582cdd5e68  addpd xmm1, xmm7
00007f582cdd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007f582cdd5e71  ptest xmm15, xmm15
00007f582cdd5e77  jnz 0x00007F582CDD7C0B
00007f582cdd5e7d  vmovaps xmm15, [rsp+0x50]
00007f582cdd5e83  vpermilpd xmm15, xmm15, 0x00
00007f582cdd5e89  vmovaps xmm5, [rsp+0xC0]
00007f582cdd5e92  vmovaps [rsp+0xC0], xmm1
00007f582cdd5e9b  movaps xmm7, xmm5
00007f582cdd5e9e  mulpd xmm7, xmm15
00007f582cdd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007f582cdd5ea8  ptest xmm1, xmm1
00007f582cdd5ead  jnz 0x00007F582CDD7D4B
00007f582cdd5eb3  lea r14, [rax+0x80]
00007f582cdd5eba  movups xmm1, [r13+r14*1]
00007f582cdd5ec0  vmovaps xmm5, [rsp+0x70]
00007f582cdd5ec6  vmovaps [rsp+0x70], xmm1
00007f582cdd5ecc  movaps xmm15, xmm5
00007f582cdd5ed0  addpd xmm15, xmm3
00007f582cdd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f582cdd5edb  ptest xmm1, xmm1
00007f582cdd5ee0  jnz 0x00007F582CDD7E96
00007f582cdd5ee6  vmovaps xmm5, [rsp+0x80]
00007f582cdd5eef  movaps xmm1, xmm5
00007f582cdd5ef2  addpd xmm1, xmm4
00007f582cdd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007f582cdd5efb  ptest xmm3, xmm3
00007f582cdd5f00  jnz 0x00007F582CDD7FD8
00007f582cdd5f06  vmovaps [rsp+0x80], xmm10
00007f582cdd5f0f  vmovaps xmm5, [rsp+0x80]
00007f582cdd5f18  por xmm10, xmm5
00007f582cdd5f1d  movaps [r15+0x2F0], xmm10
00007f582cdd5f25  vmovaps xmm5, [rsp+0x50]
00007f582cdd5f2b  vpermilpd xmm5, xmm5, 0x00
00007f582cdd5f31  vmovaps xmm3, [rsp+0x70]
00007f582cdd5f37  vmovaps [rsp+0x50], xmm1
00007f582cdd5f3d  movaps xmm4, xmm3
00007f582cdd5f40  mulpd xmm4, xmm5
00007f582cdd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007f582cdd5f49  ptest xmm1, xmm1
00007f582cdd5f4e  jnz 0x00007F582CDD8118
00007f582cdd5f54  lea r14, [rax+0xD0]
00007f582cdd5f5b  movups xmm1, [r13+r14*1]
00007f582cdd5f61  vmovaps xmm3, [rsp+0xD0]
00007f582cdd5f6a  vmovaps [rsp+0x70], xmm1
00007f582cdd5f70  movaps xmm5, xmm6
00007f582cdd5f73  addpd xmm5, xmm3
00007f582cdd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007f582cdd5f7c  ptest xmm1, xmm1
00007f582cdd5f81  jnz 0x00007F582CDD8262
00007f582cdd5f87  vmovaps xmm1, [rsp+0x60]
00007f582cdd5f8d  vpermilpd xmm1, xmm1, 0x00
00007f582cdd5f93  movaps xmm6, xmm9
00007f582cdd5f97  mulpd xmm6, xmm1
00007f582cdd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007f582cdd5fa0  ptest xmm3, xmm3
00007f582cdd5fa5  jnz 0x00007F582CDD83A2
00007f582cdd5fab  movaps [r15+0x260], xmm6
00007f582cdd5fb3  vxorps xmm1, xmm1, xmm1
00007f582cdd5fb7  vpbroadcastq xmm1, xmm1
00007f582cdd5fbc  movaps [r15+0x1B0], xmm1
00007f582cdd5fc4  vmovaps xmm1, [rsp+0x60]
00007f582cdd5fca  vpermilpd xmm1, xmm1, 0x00
00007f582cdd5fd0  vmovaps xmm3, [rsp+0x70]
00007f582cdd5fd6  vmovaps [rsp+0x70], xmm15
00007f582cdd5fdc  movaps xmm9, xmm3
00007f582cdd5fe0  mulpd xmm9, xmm1
00007f582cdd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007f582cdd5feb  ptest xmm15, xmm15
00007f582cdd5ff1  jnz 0x00007F582CDD84E3
00007f582cdd5ff7  lea r14, [rax+0xC0]
00007f582cdd5ffe  movups xmm1, [r13+r14*1]
00007f582cdd6004  vmovaps xmm3, [rsp+0xC0]
00007f582cdd600d  vmovaps [rsp+0x80], xmm1
00007f582cdd6016  movaps xmm15, xmm3
00007f582cdd601a  addpd xmm15, xmm7
00007f582cdd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007f582cdd6025  ptest xmm1, xmm1
00007f582cdd602a  jnz 0x00007F582CDD862F
00007f582cdd6030  vmovaps [rsp+0xC0], xmm13
00007f582cdd6039  vmovaps xmm1, [rsp+0xC0]
00007f582cdd6042  por xmm13, xmm1
00007f582cdd6047  movaps [r15+0x270], xmm13
00007f582cdd604f  vmovaps xmm1, [rsp+0xB0]
00007f582cdd6058  vmovaps xmm7, [rsp+0xB0]
00007f582cdd6061  por xmm1, xmm7
00007f582cdd6065  movaps [r15+0x1A0], xmm1
00007f582cdd606d  vmovaps xmm1, [rsp+0x60]
00007f582cdd6073  vpermilpd xmm1, xmm1, 0x00
00007f582cdd6079  vmovaps [rsp+0xB0], xmm1
00007f582cdd6082  vmovaps xmm1, [rsp+0x80]
00007f582cdd608b  vmovaps [rsp+0x80], xmm15
00007f582cdd6094  vmovaps xmm15, [rsp+0xB0]
00007f582cdd609d  vmovaps [rsp+0xB0], xmm14
00007f582cdd60a6  movaps xmm3, xmm1
00007f582cdd60a9  mulpd xmm3, xmm15
00007f582cdd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007f582cdd60b3  ptest xmm14, xmm14
00007f582cdd60b9  jnz 0x00007F582CDD8771
00007f582cdd60bf  lea r14, [rax+0x20]
00007f582cdd60c3  movups xmm1, [r13+r14*1]
00007f582cdd60c9  movaps [r15+0x110], xmm1
00007f582cdd60d1  vmovaps xmm14, [rsp+0x70]
00007f582cdd60d7  vmovaps [rsp+0x70], xmm1
00007f582cdd60dd  movaps xmm15, xmm14
00007f582cdd60e1  addpd xmm15, xmm4
00007f582cdd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007f582cdd60ec  ptest xmm1, xmm1
00007f582cdd60f1  jnz 0x00007F582CDD88BC
00007f582cdd60f7  vmovaps xmm1, [rsp+0x60]
00007f582cdd60fd  vpermilpd xmm1, xmm1, 0x00
00007f582cdd6103  movaps xmm14, xmm2
00007f582cdd6107  mulpd xmm14, xmm1
00007f582cdd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007f582cdd6112  ptest xmm4, xmm4
00007f582cdd6117  jnz 0x00007F582CDD89FF
00007f582cdd611d  vmovaps xmm4, [rsp+0x50]
00007f582cdd6123  movaps xmm1, xmm4
00007f582cdd6126  addpd xmm1, xmm9
00007f582cdd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007f582cdd6130  ptest xmm2, xmm2
00007f582cdd6135  jnz 0x00007F582CDD8B41
00007f582cdd613b  vmovaps xmm9, [rsp+0x30]
00007f582cdd6141  vpermilpd xmm9, xmm9, 0x00
00007f582cdd6147  vmovaps xmm2, [rsp+0x70]
00007f582cdd614d  vmovaps [rsp+0x50], xmm1
00007f582cdd6153  movaps xmm4, xmm2
00007f582cdd6156  mulpd xmm4, xmm9
00007f582cdd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007f582cdd6160  ptest xmm1, xmm1
00007f582cdd6165  jnz 0x00007F582CDD8C82
00007f582cdd616b  vmovaps xmm1, [rsp+0x30]
00007f582cdd6171  vpermilpd xmm1, xmm1, 0x00
00007f582cdd6177  vmovaps xmm2, [rsp+0x90]
00007f582cdd6180  vmovaps [rsp+0x60], xmm15
00007f582cdd6186  movaps xmm9, xmm2
00007f582cdd618a  mulpd xmm9, xmm1
00007f582cdd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007f582cdd6195  ptest xmm15, xmm15
00007f582cdd619b  jnz 0x00007F582CDD8DC3
00007f582cdd61a1  vmovaps xmm15, [rsp+0x80]
00007f582cdd61aa  movaps xmm1, xmm15
00007f582cdd61ae  addpd xmm1, xmm6
00007f582cdd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007f582cdd61b7  ptest xmm2, xmm2
00007f582cdd61bc  jnz 0x00007F582CDD8F05
00007f582cdd61c2  movaps xmm15, xmm5
00007f582cdd61c6  addpd xmm15, xmm3
00007f582cdd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007f582cdd61d1  ptest xmm6, xmm6
00007f582cdd61d6  jnz 0x00007F582CDD9046
00007f582cdd61dc  vmovaps xmm6, [rsp+0x30]
00007f582cdd61e2  vpermilpd xmm6, xmm6, 0x00
00007f582cdd61e8  movaps xmm5, xmm8
00007f582cdd61ec  mulpd xmm5, xmm6
00007f582cdd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007f582cdd61f5  ptest xmm3, xmm3
00007f582cdd61fa  jnz 0x00007F582CDD9188
00007f582cdd6200  vmovaps xmm8, [rsp+0x30]
00007f582cdd6206  vpermilpd xmm8, xmm8, 0x00
00007f582cdd620c  movaps xmm6, xmm10
00007f582cdd6210  mulpd xmm6, xmm8
00007f582cdd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007f582cdd621a  ptest xmm3, xmm3
00007f582cdd621f  jnz 0x00007F582CDD92C9
00007f582cdd6225  vmovaps xmm8, [rsp+0x60]
00007f582cdd622b  movaps xmm10, xmm8
00007f582cdd622f  addpd xmm10, xmm14
00007f582cdd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007f582cdd623a  ptest xmm3, xmm3
00007f582cdd623f  jnz 0x00007F582CDD940B
00007f582cdd6245  vmovaps xmm8, [rsp+0x50]
00007f582cdd624b  movaps xmm14, xmm8
00007f582cdd624f  addpd xmm14, xmm4
00007f582cdd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007f582cdd625a  ptest xmm3, xmm3
00007f582cdd625f  jnz 0x00007F582CDD954F
00007f582cdd6265  vmovaps xmm8, [rsp+0x40]
00007f582cdd626b  vpermilpd xmm8, xmm8, 0x00
00007f582cdd6271  movaps xmm4, xmm13
00007f582cdd6275  mulpd xmm4, xmm8
00007f582cdd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007f582cdd627f  ptest xmm3, xmm3
00007f582cdd6284  jnz 0x00007F582CDD9692
00007f582cdd628a  movaps xmm13, xmm15
00007f582cdd628e  addpd xmm13, xmm9
00007f582cdd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007f582cdd6299  ptest xmm8, xmm8
00007f582cdd629f  jnz 0x00007F582CDD97D4
00007f582cdd62a5  movaps xmm15, xmm1
00007f582cdd62a9  addpd xmm15, xmm5
00007f582cdd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007f582cdd62b4  ptest xmm9, xmm9
00007f582cdd62ba  jnz 0x00007F582CDD9918
00007f582cdd62c0  vmovaps [rsp+0x30], xmm11
00007f582cdd62c6  vmovaps xmm1, [rsp+0x30]
00007f582cdd62cc  por xmm11, xmm1
00007f582cdd62d1  movaps [r15+0x250], xmm11
00007f582cdd62d9  vmovaps [rsp+0x30], xmm12
00007f582cdd62df  vmovaps xmm1, [rsp+0x30]
00007f582cdd62e5  por xmm12, xmm1
00007f582cdd62ea  movaps [r15+0x2A0], xmm12
00007f582cdd62f2  vmovaps xmm1, [rsp+0xA0]
00007f582cdd62fb  vmovaps xmm11, [rsp+0xA0]
00007f582cdd6304  por xmm1, xmm11
00007f582cdd6309  movaps [r15+0x1D0], xmm1
00007f582cdd6311  lea r14, [rax+0x40]
00007f582cdd6315  movups xmm1, [r13+r14*1]
00007f582cdd631b  movaps [r15+0x2C0], xmm1
00007f582cdd6323  vmovaps xmm11, [rsp+0x40]
00007f582cdd6329  vpermilpd xmm11, xmm11, 0x00
00007f582cdd632f  vmovaps xmm8, [rsp+0xE0]
00007f582cdd6338  movaps xmm9, xmm8
00007f582cdd633c  mulpd xmm9, xmm11
00007f582cdd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007f582cdd6347  ptest xmm5, xmm5
00007f582cdd634c  jnz 0x00007F582CDD9A64
00007f582cdd6352  movaps xmm11, xmm10
00007f582cdd6356  addpd xmm11, xmm6
00007f582cdd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007f582cdd6361  ptest xmm8, xmm8
00007f582cdd6367  jnz 0x00007F582CDD9BA8
00007f582cdd636d  movaps xmm10, xmm14
00007f582cdd6371  addpd xmm10, xmm4
00007f582cdd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007f582cdd637c  ptest xmm8, xmm8
00007f582cdd6382  jnz 0x00007F582CDD9CEB
00007f582cdd6388  vmovaps xmm14, [rsp+0x40]
00007f582cdd638e  vpermilpd xmm14, xmm14, 0x00
00007f582cdd6394  movaps xmm8, xmm1
00007f582cdd6398  mulpd xmm8, xmm14
00007f582cdd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007f582cdd63a3  ptest xmm6, xmm6
00007f582cdd63a8  jnz 0x00007F582CDD9E2E
00007f582cdd63ae  movaps xmm1, [r15+0x2B0]
00007f582cdd63b6  vmovaps xmm14, [rsp+0x40]
00007f582cdd63bc  vpermilpd xmm14, xmm14, 0x00
00007f582cdd63c2  movaps xmm6, xmm1
00007f582cdd63c5  mulpd xmm6, xmm14
00007f582cdd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007f582cdd63cf  ptest xmm5, xmm5
00007f582cdd63d4  jnz 0x00007F582CDD9F71
00007f582cdd63da  vmovaps xmm1, [rsp+0x10]
00007f582cdd63e0  vpermilpd xmm1, xmm1, 0x00
00007f582cdd63e6  movaps xmm14, xmm12
00007f582cdd63ea  mulpd xmm14, xmm1
00007f582cdd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007f582cdd63f5  ptest xmm5, xmm5
00007f582cdd63fa  jnz 0x00007F582CDDA0B2
00007f582cdd6400  movaps xmm1, xmm13
00007f582cdd6404  addpd xmm1, xmm9
00007f582cdd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007f582cdd640e  ptest xmm12, xmm12
00007f582cdd6414  jnz 0x00007F582CDDA1F5
00007f582cdd641a  vmovaps xmm13, [rsp+0x10]
00007f582cdd6420  vpermilpd xmm13, xmm13, 0x00
00007f582cdd6426  movaps xmm12, xmm7
00007f582cdd642a  mulpd xmm12, xmm13
00007f582cdd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007f582cdd6435  ptest xmm9, xmm9
00007f582cdd643b  jnz 0x00007F582CDDA337
00007f582cdd6441  movaps xmm13, xmm15
00007f582cdd6445  addpd xmm13, xmm8
00007f582cdd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007f582cdd6450  ptest xmm9, xmm9
00007f582cdd6456  jnz 0x00007F582CDDA47A
00007f582cdd645c  movaps xmm15, [r15+0x290]
00007f582cdd6464  vmovaps xmm9, [rsp+0x10]
00007f582cdd646a  vpermilpd xmm9, xmm9, 0x00
00007f582cdd6470  movaps xmm8, xmm15
00007f582cdd6474  mulpd xmm8, xmm9
00007f582cdd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007f582cdd647f  ptest xmm7, xmm7
00007f582cdd6484  jnz 0x00007F582CDDA5BE
00007f582cdd648a  movaps xmm15, xmm11
00007f582cdd648e  addpd xmm15, xmm6
00007f582cdd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007f582cdd6499  ptest xmm9, xmm9
00007f582cdd649f  jnz 0x00007F582CDDA702
00007f582cdd64a5  movaps xmm11, [r15+0x1E0]
00007f582cdd64ad  vmovaps xmm9, [rsp+0x10]
00007f582cdd64b3  vpermilpd xmm9, xmm9, 0x00
00007f582cdd64b9  movaps xmm7, xmm11
00007f582cdd64bd  mulpd xmm7, xmm9
00007f582cdd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007f582cdd64c7  ptest xmm6, xmm6
00007f582cdd64cc  jnz 0x00007F582CDDA845
00007f582cdd64d2  movaps xmm11, xmm10
00007f582cdd64d6  addpd xmm11, xmm14
00007f582cdd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007f582cdd64e1  ptest xmm9, xmm9
00007f582cdd64e7  jnz 0x00007F582CDDA987
00007f582cdd64ed  lea r14, [rax+0x70]
00007f582cdd64f1  movups xmm14, [r13+r14*1]
00007f582cdd64f7  movaps [r15+0x240], xmm14
00007f582cdd64ff  movaps xmm10, xmm1
00007f582cdd6503  addpd xmm10, xmm12
00007f582cdd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007f582cdd650e  ptest xmm9, xmm9
00007f582cdd6514  jnz 0x00007F582CDDAAD5
00007f582cdd651a  movaps [r15+0x170], xmm10
00007f582cdd6522  vmovaps xmm1, [rsp+0x20]
00007f582cdd6528  vpermilpd xmm1, xmm1, 0x00
00007f582cdd652e  movaps xmm12, xmm14
00007f582cdd6532  mulpd xmm12, xmm1
00007f582cdd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007f582cdd653d  ptest xmm9, xmm9
00007f582cdd6543  jnz 0x00007F582CDDAC18
00007f582cdd6549  vmovaps xmm1, [rsp+0x20]
00007f582cdd654f  vpermilpd xmm1, xmm1, 0x00
00007f582cdd6555  vmovaps xmm9, [rsp+0xB0]
00007f582cdd655e  movaps xmm14, xmm9
00007f582cdd6562  mulpd xmm14, xmm1
00007f582cdd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007f582cdd656d  ptest xmm6, xmm6
00007f582cdd6572  jnz 0x00007F582CDDAD5B
00007f582cdd6578  movaps [r15+0x180], xmm14
00007f582cdd6580  movaps xmm1, xmm13
00007f582cdd6584  addpd xmm1, xmm8
00007f582cdd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007f582cdd658e  ptest xmm9, xmm9
00007f582cdd6594  jnz 0x00007F582CDDAE9E
00007f582cdd659a  movaps [r15+0x210], xmm1
00007f582cdd65a2  movups xmm13, [r13+rax*1]
00007f582cdd65a8  lea r14, [rax+0x10]
00007f582cdd65ac  movups xmm9, [r13+r14*1]
00007f582cdd65b2  movaps [r15+0x230], xmm9
00007f582cdd65ba  movaps xmm8, xmm15
00007f582cdd65be  addpd xmm8, xmm7
00007f582cdd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007f582cdd65c9  ptest xmm6, xmm6
00007f582cdd65ce  jnz 0x00007F582CDDAFF4
00007f582cdd65d4  movaps [r15+0x130], xmm8
00007f582cdd65dc  vmovaps xmm15, [rsp+0x20]
00007f582cdd65e2  vpermilpd xmm15, xmm15, 0x00
00007f582cdd65e8  movaps xmm7, xmm9
00007f582cdd65ec  mulpd xmm7, xmm15
00007f582cdd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007f582cdd65f6  ptest xmm6, xmm6
00007f582cdd65fb  jnz 0x00007F582CDDB137
00007f582cdd6601  movaps [r15+0x220], xmm7
00007f582cdd6609  vmovaps xmm15, [rsp+0x20]
00007f582cdd660f  vpermilpd xmm15, xmm15, 0x00
00007f582cdd6615  movaps xmm9, xmm13
00007f582cdd6619  mulpd xmm9, xmm15
00007f582cdd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007f582cdd6624  ptest xmm6, xmm6
00007f582cdd6629  jnz 0x00007F582CDDB279
00007f582cdd662f  movaps xmm15, xmm11
00007f582cdd6633  addpd xmm15, xmm12
00007f582cdd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007f582cdd663e  ptest xmm13, xmm13
00007f582cdd6644  jnz 0x00007F582CDDB3BD
00007f582cdd664a  movaps [r15+0x140], xmm15
00007f582cdd6652  movaps xmm13, xmm10
00007f582cdd6656  addpd xmm13, xmm14
00007f582cdd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007f582cdd6661  ptest xmm12, xmm12
00007f582cdd6667  jnz 0x00007F582CDDB501
00007f582cdd666d  movaps [r15+0x150], xmm13
00007f582cdd6675  movaps xmm14, xmm1
00007f582cdd6679  addpd xmm14, xmm7
00007f582cdd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007f582cdd6684  ptest xmm12, xmm12
00007f582cdd668a  jnz 0x00007F582CDDB645
00007f582cdd6690  movaps [r15+0x160], xmm14
00007f582cdd6698  movaps xmm1, xmm8
00007f582cdd669c  addpd xmm1, xmm9
00007f582cdd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007f582cdd66a6  ptest xmm12, xmm12
00007f582cdd66ac  jnz 0x00007F582CDDB787
00007f582cdd66b2  movaps [r15+0x120], xmm1
00007f582cdd66ba  movups [r13+r11*1], xmm15
00007f582cdd66c0  lea rax, [r11+0x10]
00007f582cdd66c4  movups [r13+rax*1], xmm13
00007f582cdd66ca  lea rax, [r11+0x20]
00007f582cdd66ce  movups [r13+rax*1], xmm14
00007f582cdd66d4  lea rax, [r11+0x30]
00007f582cdd66d8  movups [r13+rax*1], xmm1
00007f582cdd66de  mov eax, [r15+0x108]
00007f582cdd66e5  sahf
00007f582cdd66e6  jnz 0x00007F582CDD6718
00007f582cdd66e8  cmp dword ptr [r15+0x318], 0x00
00007f582cdd66f0  jz 0x00007F582CDDB900
00007f582cdd66f6  nop [rax+rax*1], ax
00007f582cdd66ff  nop [rax+rax*1], eax
00007f582cdd6707  mov eax, 0x410444
00007f582cdd670c  mov [r15+0x100], rax
00007f582cdd6713  jmp 0x00007F582CBFE110
00007f582cdd6718  cmp dword ptr [r15+0x318], 0x00
00007f582cdd6720  jz 0x00007F582CDD57E0
00007f582cdd6726  nop [rax+rax*1], ax
00007f582cdd672f  nop [rax+rax*1], eax
00007f582cdd6737  mov eax, 0x410278
00007f582cdd673c  mov [r15+0x100], rax
00007f582cdd6743  jmp 0x00007F582CBFE110
00007f582cdd6748  int3
00007f582cdd6749  call 0x00007F582CC0A4B0
00007f582cdd674e  jmp 0x00007F582CDD5828
00007f582cdd6753  call 0x00007F582CC09240
00007f582cdd6758  jmp 0x00007F582CDD5832
00007f582cdd675d  call 0x00007F582CC0A4B0
00007f582cdd6762  jmp 0x00007F582CDD588F
00007f582cdd6767  call 0x00007F582CC09240
00007f582cdd676c  jmp 0x00007F582CDD5899
00007f582cdd6771  call 0x00007F582CC0A4B0
00007f582cdd6776  jmp 0x00007F582CDD58DD
00007f582cdd677b  call 0x00007F582CC09240
00007f582cdd6780  jmp 0x00007F582CDD58E7
00007f582cdd6785  call 0x00007F582CCB47C0
00007f582cdd678a  jmp 0x00007F582CDD5926
00007f582cdd678f  call 0x00007F582CC0B720
00007f582cdd6794  jmp 0x00007F582CDD593A
00007f582cdd6799  call 0x00007F582CCBFC30
00007f582cdd679e  jmp 0x00007F582CDD5958
00007f582cdd67a3  call 0x00007F582CCBE9C0
00007f582cdd67a8  jmp 0x00007F582CDD5962
00007f582cdd67ad  call 0x00007F582CCBD750
00007f582cdd67b2  jmp 0x00007F582CDD596C
00007f582cdd67b7  sub rsp, 0x08
00007f582cdd67bb  push rax
00007f582cdd67bc  push rcx
00007f582cdd67bd  push rdx
00007f582cdd67be  push rdi
00007f582cdd67bf  push rsi
00007f582cdd67c0  push r8
00007f582cdd67c2  push r9
00007f582cdd67c4  push r10
00007f582cdd67c6  push r11
00007f582cdd67c8  sub rsp, 0xF0
00007f582cdd67cf  vmovaps [rsp], xmm0
00007f582cdd67d4  vmovaps [rsp+0x10], xmm1
00007f582cdd67da  vmovaps [rsp+0x20], xmm2
00007f582cdd67e0  vmovaps [rsp+0x30], xmm3
00007f582cdd67e6  vmovaps [rsp+0x40], xmm4
00007f582cdd67ec  vmovaps [rsp+0x50], xmm5
00007f582cdd67f2  vmovaps [rsp+0x60], xmm6
00007f582cdd67f8  vmovaps [rsp+0x70], xmm7
00007f582cdd67fe  vmovaps [rsp+0x80], xmm9
00007f582cdd6807  vmovaps [rsp+0x90], xmm10
00007f582cdd6810  vmovaps [rsp+0xA0], xmm11
00007f582cdd6819  vmovaps [rsp+0xB0], xmm12
00007f582cdd6822  vmovaps [rsp+0xC0], xmm13
00007f582cdd682b  vmovaps [rsp+0xD0], xmm14
00007f582cdd6834  vmovaps [rsp+0xE0], xmm15
00007f582cdd683d  sub rsp, 0x30
00007f582cdd6841  movaps [rsp], xmm8
00007f582cdd6846  movaps [rsp+0x10], xmm12
00007f582cdd684c  movaps [rsp+0x20], xmm15
00007f582cdd6852  lea rdi, [rsp]
00007f582cdd6856  mov esi, 0x00
00007f582cdd685b  mov rax, 0x653B0D9BF530
00007f582cdd6865  call rax
00007f582cdd6867  movaps xmm8, [rsp]
00007f582cdd686c  add rsp, 0x30
00007f582cdd6870  vmovaps xmm0, [rsp]
00007f582cdd6875  vmovaps xmm1, [rsp+0x10]
00007f582cdd687b  vmovaps xmm2, [rsp+0x20]
00007f582cdd6881  vmovaps xmm3, [rsp+0x30]
00007f582cdd6887  vmovaps xmm4, [rsp+0x40]
00007f582cdd688d  vmovaps xmm5, [rsp+0x50]
00007f582cdd6893  vmovaps xmm6, [rsp+0x60]
00007f582cdd6899  vmovaps xmm7, [rsp+0x70]
00007f582cdd689f  vmovaps xmm9, [rsp+0x80]
00007f582cdd68a8  vmovaps xmm10, [rsp+0x90]
00007f582cdd68b1  vmovaps xmm11, [rsp+0xA0]
00007f582cdd68ba  vmovaps xmm12, [rsp+0xB0]
00007f582cdd68c3  vmovaps xmm13, [rsp+0xC0]
00007f582cdd68cc  vmovaps xmm14, [rsp+0xD0]
00007f582cdd68d5  vmovaps xmm15, [rsp+0xE0]
00007f582cdd68de  add rsp, 0xF0
00007f582cdd68e5  pop r11
00007f582cdd68e7  pop r10
00007f582cdd68e9  pop r9
00007f582cdd68eb  pop r8
00007f582cdd68ed  pop rsi
00007f582cdd68ee  pop rdi
00007f582cdd68ef  pop rdx
00007f582cdd68f0  pop rcx
00007f582cdd68f1  pop rax
00007f582cdd68f2  add rsp, 0x08
00007f582cdd68f6  jmp 0x00007F582CDD599A
00007f582cdd68fb  sub rsp, 0x08
00007f582cdd68ff  push rax
00007f582cdd6900  push rcx
00007f582cdd6901  push rdx
00007f582cdd6902  push rdi
00007f582cdd6903  push rsi
00007f582cdd6904  push r8
00007f582cdd6906  push r9
00007f582cdd6908  push r10
00007f582cdd690a  push r11
00007f582cdd690c  sub rsp, 0xF0
00007f582cdd6913  vmovaps [rsp], xmm0
00007f582cdd6918  vmovaps [rsp+0x10], xmm1
00007f582cdd691e  vmovaps [rsp+0x20], xmm2
00007f582cdd6924  vmovaps [rsp+0x30], xmm3
00007f582cdd692a  vmovaps [rsp+0x40], xmm4
00007f582cdd6930  vmovaps [rsp+0x50], xmm5
00007f582cdd6936  vmovaps [rsp+0x60], xmm6
00007f582cdd693c  vmovaps [rsp+0x70], xmm8
00007f582cdd6942  vmovaps [rsp+0x80], xmm9
00007f582cdd694b  vmovaps [rsp+0x90], xmm10
00007f582cdd6954  vmovaps [rsp+0xA0], xmm11
00007f582cdd695d  vmovaps [rsp+0xB0], xmm12
00007f582cdd6966  vmovaps [rsp+0xC0], xmm13
00007f582cdd696f  vmovaps [rsp+0xD0], xmm14
00007f582cdd6978  vmovaps [rsp+0xE0], xmm15
00007f582cdd6981  sub rsp, 0x30
00007f582cdd6985  movaps [rsp], xmm7
00007f582cdd6989  movaps [rsp+0x10], xmm9
00007f582cdd698f  movaps [rsp+0x20], xmm15
00007f582cdd6995  lea rdi, [rsp]
00007f582cdd6999  mov esi, 0x00
00007f582cdd699e  mov rax, 0x653B0D9BF530
00007f582cdd69a8  call rax
00007f582cdd69aa  movaps xmm7, [rsp]
00007f582cdd69ae  add rsp, 0x30
00007f582cdd69b2  vmovaps xmm0, [rsp]
00007f582cdd69b7  vmovaps xmm1, [rsp+0x10]
00007f582cdd69bd  vmovaps xmm2, [rsp+0x20]
00007f582cdd69c3  vmovaps xmm3, [rsp+0x30]
00007f582cdd69c9  vmovaps xmm4, [rsp+0x40]
00007f582cdd69cf  vmovaps xmm5, [rsp+0x50]
00007f582cdd69d5  vmovaps xmm6, [rsp+0x60]
00007f582cdd69db  vmovaps xmm8, [rsp+0x70]
00007f582cdd69e1  vmovaps xmm9, [rsp+0x80]
00007f582cdd69ea  vmovaps xmm10, [rsp+0x90]
00007f582cdd69f3  vmovaps xmm11, [rsp+0xA0]
00007f582cdd69fc  vmovaps xmm12, [rsp+0xB0]
00007f582cdd6a05  vmovaps xmm13, [rsp+0xC0]
00007f582cdd6a0e  vmovaps xmm14, [rsp+0xD0]
00007f582cdd6a17  vmovaps xmm15, [rsp+0xE0]
00007f582cdd6a20  add rsp, 0xF0
00007f582cdd6a27  pop r11
00007f582cdd6a29  pop r10
00007f582cdd6a2b  pop r9
00007f582cdd6a2d  pop r8
00007f582cdd6a2f  pop rsi
00007f582cdd6a30  pop rdi
00007f582cdd6a31  pop rdx
00007f582cdd6a32  pop rcx
00007f582cdd6a33  pop rax
00007f582cdd6a34  add rsp, 0x08
00007f582cdd6a38  jmp 0x00007F582CDD59C8
00007f582cdd6a3d  sub rsp, 0x08
00007f582cdd6a41  push rax
00007f582cdd6a42  push rcx
00007f582cdd6a43  push rdx
00007f582cdd6a44  push rdi
00007f582cdd6a45  push rsi
00007f582cdd6a46  push r8
00007f582cdd6a48  push r9
00007f582cdd6a4a  push r10
00007f582cdd6a4c  push r11
00007f582cdd6a4e  sub rsp, 0xF0
00007f582cdd6a55  vmovaps [rsp], xmm0
00007f582cdd6a5a  vmovaps [rsp+0x10], xmm1
00007f582cdd6a60  vmovaps [rsp+0x20], xmm2
00007f582cdd6a66  vmovaps [rsp+0x30], xmm3
00007f582cdd6a6c  vmovaps [rsp+0x40], xmm4
00007f582cdd6a72  vmovaps [rsp+0x50], xmm5
00007f582cdd6a78  vmovaps [rsp+0x60], xmm6
00007f582cdd6a7e  vmovaps [rsp+0x70], xmm7
00007f582cdd6a84  vmovaps [rsp+0x80], xmm8
00007f582cdd6a8d  vmovaps [rsp+0x90], xmm10
00007f582cdd6a96  vmovaps [rsp+0xA0], xmm11
00007f582cdd6a9f  vmovaps [rsp+0xB0], xmm12
00007f582cdd6aa8  vmovaps [rsp+0xC0], xmm13
00007f582cdd6ab1  vmovaps [rsp+0xD0], xmm14
00007f582cdd6aba  vmovaps [rsp+0xE0], xmm15
00007f582cdd6ac3  sub rsp, 0x30
00007f582cdd6ac7  movaps [rsp], xmm9
00007f582cdd6acc  movaps [rsp+0x10], xmm12
00007f582cdd6ad2  movaps [rsp+0x20], xmm10
00007f582cdd6ad8  lea rdi, [rsp]
00007f582cdd6adc  mov esi, 0x00
00007f582cdd6ae1  mov rax, 0x653B0D9BF530
00007f582cdd6aeb  call rax
00007f582cdd6aed  movaps xmm9, [rsp]
00007f582cdd6af2  add rsp, 0x30
00007f582cdd6af6  vmovaps xmm0, [rsp]
00007f582cdd6afb  vmovaps xmm1, [rsp+0x10]
00007f582cdd6b01  vmovaps xmm2, [rsp+0x20]
00007f582cdd6b07  vmovaps xmm3, [rsp+0x30]
00007f582cdd6b0d  vmovaps xmm4, [rsp+0x40]
00007f582cdd6b13  vmovaps xmm5, [rsp+0x50]
00007f582cdd6b19  vmovaps xmm6, [rsp+0x60]
00007f582cdd6b1f  vmovaps xmm7, [rsp+0x70]
00007f582cdd6b25  vmovaps xmm8, [rsp+0x80]
00007f582cdd6b2e  vmovaps xmm10, [rsp+0x90]
00007f582cdd6b37  vmovaps xmm11, [rsp+0xA0]
00007f582cdd6b40  vmovaps xmm12, [rsp+0xB0]
00007f582cdd6b49  vmovaps xmm13, [rsp+0xC0]
00007f582cdd6b52  vmovaps xmm14, [rsp+0xD0]
00007f582cdd6b5b  vmovaps xmm15, [rsp+0xE0]
00007f582cdd6b64  add rsp, 0xF0
00007f582cdd6b6b  pop r11
00007f582cdd6b6d  pop r10
00007f582cdd6b6f  pop r9
00007f582cdd6b71  pop r8
00007f582cdd6b73  pop rsi
00007f582cdd6b74  pop rdi
00007f582cdd6b75  pop rdx
00007f582cdd6b76  pop rcx
00007f582cdd6b77  pop rax
00007f582cdd6b78  add rsp, 0x08
00007f582cdd6b7c  jmp 0x00007F582CDD59EC
00007f582cdd6b81  sub rsp, 0x08
00007f582cdd6b85  push rax
00007f582cdd6b86  push rcx
00007f582cdd6b87  push rdx
00007f582cdd6b88  push rdi
00007f582cdd6b89  push rsi
00007f582cdd6b8a  push r8
00007f582cdd6b8c  push r9
00007f582cdd6b8e  push r10
00007f582cdd6b90  push r11
00007f582cdd6b92  sub rsp, 0xF0
00007f582cdd6b99  vmovaps [rsp], xmm0
00007f582cdd6b9e  vmovaps [rsp+0x10], xmm1
00007f582cdd6ba4  vmovaps [rsp+0x20], xmm2
00007f582cdd6baa  vmovaps [rsp+0x30], xmm3
00007f582cdd6bb0  vmovaps [rsp+0x40], xmm4
00007f582cdd6bb6  vmovaps [rsp+0x50], xmm5
00007f582cdd6bbc  vmovaps [rsp+0x60], xmm6
00007f582cdd6bc2  vmovaps [rsp+0x70], xmm7
00007f582cdd6bc8  vmovaps [rsp+0x80], xmm8
00007f582cdd6bd1  vmovaps [rsp+0x90], xmm9
00007f582cdd6bda  vmovaps [rsp+0xA0], xmm11
00007f582cdd6be3  vmovaps [rsp+0xB0], xmm12
00007f582cdd6bec  vmovaps [rsp+0xC0], xmm13
00007f582cdd6bf5  vmovaps [rsp+0xD0], xmm14
00007f582cdd6bfe  vmovaps [rsp+0xE0], xmm15
00007f582cdd6c07  sub rsp, 0x30
00007f582cdd6c0b  movaps [rsp], xmm10
00007f582cdd6c10  movaps [rsp+0x10], xmm12
00007f582cdd6c16  movaps [rsp+0x20], xmm11
00007f582cdd6c1c  lea rdi, [rsp]
00007f582cdd6c20  mov esi, 0x00
00007f582cdd6c25  mov rax, 0x653B0D9BF530
00007f582cdd6c2f  call rax
00007f582cdd6c31  movaps xmm10, [rsp]
00007f582cdd6c36  add rsp, 0x30
00007f582cdd6c3a  vmovaps xmm0, [rsp]
00007f582cdd6c3f  vmovaps xmm1, [rsp+0x10]
00007f582cdd6c45  vmovaps xmm2, [rsp+0x20]
00007f582cdd6c4b  vmovaps xmm3, [rsp+0x30]
00007f582cdd6c51  vmovaps xmm4, [rsp+0x40]
00007f582cdd6c57  vmovaps xmm5, [rsp+0x50]
00007f582cdd6c5d  vmovaps xmm6, [rsp+0x60]
00007f582cdd6c63  vmovaps xmm7, [rsp+0x70]
00007f582cdd6c69  vmovaps xmm8, [rsp+0x80]
00007f582cdd6c72  vmovaps xmm9, [rsp+0x90]
00007f582cdd6c7b  vmovaps xmm11, [rsp+0xA0]
00007f582cdd6c84  vmovaps xmm12, [rsp+0xB0]
00007f582cdd6c8d  vmovaps xmm13, [rsp+0xC0]
00007f582cdd6c96  vmovaps xmm14, [rsp+0xD0]
00007f582cdd6c9f  vmovaps xmm15, [rsp+0xE0]
00007f582cdd6ca8  add rsp, 0xF0
00007f582cdd6caf  pop r11
00007f582cdd6cb1  pop r10
00007f582cdd6cb3  pop r9
00007f582cdd6cb5  pop r8
00007f582cdd6cb7  pop rsi
00007f582cdd6cb8  pop rdi
00007f582cdd6cb9  pop rdx
00007f582cdd6cba  pop rcx
00007f582cdd6cbb  pop rax
00007f582cdd6cbc  add rsp, 0x08
00007f582cdd6cc0  jmp 0x00007F582CDD5A06
00007f582cdd6cc5  sub rsp, 0x08
00007f582cdd6cc9  push rax
00007f582cdd6cca  push rcx
00007f582cdd6ccb  push rdx
00007f582cdd6ccc  push rdi
00007f582cdd6ccd  push rsi
00007f582cdd6cce  push r8
00007f582cdd6cd0  push r9
00007f582cdd6cd2  push r10
00007f582cdd6cd4  push r11
00007f582cdd6cd6  sub rsp, 0xF0
00007f582cdd6cdd  vmovaps [rsp], xmm0
00007f582cdd6ce2  vmovaps [rsp+0x10], xmm1
00007f582cdd6ce8  vmovaps [rsp+0x20], xmm2
00007f582cdd6cee  vmovaps [rsp+0x30], xmm3
00007f582cdd6cf4  vmovaps [rsp+0x40], xmm4
00007f582cdd6cfa  vmovaps [rsp+0x50], xmm5
00007f582cdd6d00  vmovaps [rsp+0x60], xmm7
00007f582cdd6d06  vmovaps [rsp+0x70], xmm8
00007f582cdd6d0c  vmovaps [rsp+0x80], xmm9
00007f582cdd6d15  vmovaps [rsp+0x90], xmm10
00007f582cdd6d1e  vmovaps [rsp+0xA0], xmm11
00007f582cdd6d27  vmovaps [rsp+0xB0], xmm12
00007f582cdd6d30  vmovaps [rsp+0xC0], xmm13
00007f582cdd6d39  vmovaps [rsp+0xD0], xmm14
00007f582cdd6d42  vmovaps [rsp+0xE0], xmm15
00007f582cdd6d4b  sub rsp, 0x30
00007f582cdd6d4f  movaps [rsp], xmm6
00007f582cdd6d53  movaps [rsp+0x10], xmm12
00007f582cdd6d59  movaps [rsp+0x20], xmm11
00007f582cdd6d5f  lea rdi, [rsp]
00007f582cdd6d63  mov esi, 0x00
00007f582cdd6d68  mov rax, 0x653B0D9BF530
00007f582cdd6d72  call rax
00007f582cdd6d74  movaps xmm6, [rsp]
00007f582cdd6d78  add rsp, 0x30
00007f582cdd6d7c  vmovaps xmm0, [rsp]
00007f582cdd6d81  vmovaps xmm1, [rsp+0x10]
00007f582cdd6d87  vmovaps xmm2, [rsp+0x20]
00007f582cdd6d8d  vmovaps xmm3, [rsp+0x30]
00007f582cdd6d93  vmovaps xmm4, [rsp+0x40]
00007f582cdd6d99  vmovaps xmm5, [rsp+0x50]
00007f582cdd6d9f  vmovaps xmm7, [rsp+0x60]
00007f582cdd6da5  vmovaps xmm8, [rsp+0x70]
00007f582cdd6dab  vmovaps xmm9, [rsp+0x80]
00007f582cdd6db4  vmovaps xmm10, [rsp+0x90]
00007f582cdd6dbd  vmovaps xmm11, [rsp+0xA0]
00007f582cdd6dc6  vmovaps xmm12, [rsp+0xB0]
00007f582cdd6dcf  vmovaps xmm13, [rsp+0xC0]
00007f582cdd6dd8  vmovaps xmm14, [rsp+0xD0]
00007f582cdd6de1  vmovaps xmm15, [rsp+0xE0]
00007f582cdd6dea  add rsp, 0xF0
00007f582cdd6df1  pop r11
00007f582cdd6df3  pop r10
00007f582cdd6df5  pop r9
00007f582cdd6df7  pop r8
00007f582cdd6df9  pop rsi
00007f582cdd6dfa  pop rdi
00007f582cdd6dfb  pop rdx
00007f582cdd6dfc  pop rcx
00007f582cdd6dfd  pop rax
00007f582cdd6dfe  add rsp, 0x08
00007f582cdd6e02  jmp 0x00007F582CDD5A27
00007f582cdd6e07  sub rsp, 0x08
00007f582cdd6e0b  push rax
00007f582cdd6e0c  push rcx
00007f582cdd6e0d  push rdx
00007f582cdd6e0e  push rdi
00007f582cdd6e0f  push rsi
00007f582cdd6e10  push r8
00007f582cdd6e12  push r9
00007f582cdd6e14  push r10
00007f582cdd6e16  push r11
00007f582cdd6e18  sub rsp, 0xF0
00007f582cdd6e1f  vmovaps [rsp], xmm0
00007f582cdd6e24  vmovaps [rsp+0x10], xmm1
00007f582cdd6e2a  vmovaps [rsp+0x20], xmm2
00007f582cdd6e30  vmovaps [rsp+0x30], xmm4
00007f582cdd6e36  vmovaps [rsp+0x40], xmm5
00007f582cdd6e3c  vmovaps [rsp+0x50], xmm6
00007f582cdd6e42  vmovaps [rsp+0x60], xmm7
00007f582cdd6e48  vmovaps [rsp+0x70], xmm8
00007f582cdd6e4e  vmovaps [rsp+0x80], xmm9
00007f582cdd6e57  vmovaps [rsp+0x90], xmm10
00007f582cdd6e60  vmovaps [rsp+0xA0], xmm11
00007f582cdd6e69  vmovaps [rsp+0xB0], xmm12
00007f582cdd6e72  vmovaps [rsp+0xC0], xmm13
00007f582cdd6e7b  vmovaps [rsp+0xD0], xmm14
00007f582cdd6e84  vmovaps [rsp+0xE0], xmm15
00007f582cdd6e8d  sub rsp, 0x30
00007f582cdd6e91  movaps [rsp], xmm3
00007f582cdd6e95  movaps [rsp+0x10], xmm5
00007f582cdd6e9a  movaps [rsp+0x20], xmm4
00007f582cdd6e9f  lea rdi, [rsp]
00007f582cdd6ea3  mov esi, 0x00
00007f582cdd6ea8  mov rax, 0x653B0D9BF530
00007f582cdd6eb2  call rax
00007f582cdd6eb4  movaps xmm3, [rsp]
00007f582cdd6eb8  add rsp, 0x30
00007f582cdd6ebc  vmovaps xmm0, [rsp]
00007f582cdd6ec1  vmovaps xmm1, [rsp+0x10]
00007f582cdd6ec7  vmovaps xmm2, [rsp+0x20]
00007f582cdd6ecd  vmovaps xmm4, [rsp+0x30]
00007f582cdd6ed3  vmovaps xmm5, [rsp+0x40]
00007f582cdd6ed9  vmovaps xmm6, [rsp+0x50]
00007f582cdd6edf  vmovaps xmm7, [rsp+0x60]
00007f582cdd6ee5  vmovaps xmm8, [rsp+0x70]
00007f582cdd6eeb  vmovaps xmm9, [rsp+0x80]
00007f582cdd6ef4  vmovaps xmm10, [rsp+0x90]
00007f582cdd6efd  vmovaps xmm11, [rsp+0xA0]
00007f582cdd6f06  vmovaps xmm12, [rsp+0xB0]
00007f582cdd6f0f  vmovaps xmm13, [rsp+0xC0]
00007f582cdd6f18  vmovaps xmm14, [rsp+0xD0]
00007f582cdd6f21  vmovaps xmm15, [rsp+0xE0]
00007f582cdd6f2a  add rsp, 0xF0
00007f582cdd6f31  pop r11
00007f582cdd6f33  pop r10
00007f582cdd6f35  pop r9
00007f582cdd6f37  pop r8
00007f582cdd6f39  pop rsi
00007f582cdd6f3a  pop rdi
00007f582cdd6f3b  pop rdx
00007f582cdd6f3c  pop rcx
00007f582cdd6f3d  pop rax
00007f582cdd6f3e  add rsp, 0x08
00007f582cdd6f42  jmp 0x00007F582CDD5A88
00007f582cdd6f47  sub rsp, 0x08
00007f582cdd6f4b  push rax
00007f582cdd6f4c  push rcx
00007f582cdd6f4d  push rdx
00007f582cdd6f4e  push rdi
00007f582cdd6f4f  push rsi
00007f582cdd6f50  push r8
00007f582cdd6f52  push r9
00007f582cdd6f54  push r10
00007f582cdd6f56  push r11
00007f582cdd6f58  sub rsp, 0xF0
00007f582cdd6f5f  vmovaps [rsp], xmm0
00007f582cdd6f64  vmovaps [rsp+0x10], xmm1
00007f582cdd6f6a  vmovaps [rsp+0x20], xmm2
00007f582cdd6f70  vmovaps [rsp+0x30], xmm3
00007f582cdd6f76  vmovaps [rsp+0x40], xmm4
00007f582cdd6f7c  vmovaps [rsp+0x50], xmm6
00007f582cdd6f82  vmovaps [rsp+0x60], xmm7
00007f582cdd6f88  vmovaps [rsp+0x70], xmm8
00007f582cdd6f8e  vmovaps [rsp+0x80], xmm9
00007f582cdd6f97  vmovaps [rsp+0x90], xmm10
00007f582cdd6fa0  vmovaps [rsp+0xA0], xmm11
00007f582cdd6fa9  vmovaps [rsp+0xB0], xmm12
00007f582cdd6fb2  vmovaps [rsp+0xC0], xmm13
00007f582cdd6fbb  vmovaps [rsp+0xD0], xmm14
00007f582cdd6fc4  vmovaps [rsp+0xE0], xmm15
00007f582cdd6fcd  sub rsp, 0x30
00007f582cdd6fd1  movaps [rsp], xmm5
00007f582cdd6fd5  movaps [rsp+0x10], xmm8
00007f582cdd6fdb  movaps [rsp+0x20], xmm15
00007f582cdd6fe1  lea rdi, [rsp]
00007f582cdd6fe5  mov esi, 0x00
00007f582cdd6fea  mov rax, 0x653B0D9BF530
00007f582cdd6ff4  call rax
00007f582cdd6ff6  movaps xmm5, [rsp]
00007f582cdd6ffa  add rsp, 0x30
00007f582cdd6ffe  vmovaps xmm0, [rsp]
00007f582cdd7003  vmovaps xmm1, [rsp+0x10]
00007f582cdd7009  vmovaps xmm2, [rsp+0x20]
00007f582cdd700f  vmovaps xmm3, [rsp+0x30]
00007f582cdd7015  vmovaps xmm4, [rsp+0x40]
00007f582cdd701b  vmovaps xmm6, [rsp+0x50]
00007f582cdd7021  vmovaps xmm7, [rsp+0x60]
00007f582cdd7027  vmovaps xmm8, [rsp+0x70]
00007f582cdd702d  vmovaps xmm9, [rsp+0x80]
00007f582cdd7036  vmovaps xmm10, [rsp+0x90]
00007f582cdd703f  vmovaps xmm11, [rsp+0xA0]
00007f582cdd7048  vmovaps xmm12, [rsp+0xB0]
00007f582cdd7051  vmovaps xmm13, [rsp+0xC0]
00007f582cdd705a  vmovaps xmm14, [rsp+0xD0]
00007f582cdd7063  vmovaps xmm15, [rsp+0xE0]
00007f582cdd706c  add rsp, 0xF0
00007f582cdd7073  pop r11
00007f582cdd7075  pop r10
00007f582cdd7077  pop r9
00007f582cdd7079  pop r8
00007f582cdd707b  pop rsi
00007f582cdd707c  pop rdi
00007f582cdd707d  pop rdx
00007f582cdd707e  pop rcx
00007f582cdd707f  pop rax
00007f582cdd7080  add rsp, 0x08
00007f582cdd7084  jmp 0x00007F582CDD5AC0
00007f582cdd7089  sub rsp, 0x08
00007f582cdd708d  push rax
00007f582cdd708e  push rcx
00007f582cdd708f  push rdx
00007f582cdd7090  push rdi
00007f582cdd7091  push rsi
00007f582cdd7092  push r8
00007f582cdd7094  push r9
00007f582cdd7096  push r10
00007f582cdd7098  push r11
00007f582cdd709a  sub rsp, 0xF0
00007f582cdd70a1  vmovaps [rsp], xmm0
00007f582cdd70a6  vmovaps [rsp+0x10], xmm1
00007f582cdd70ac  vmovaps [rsp+0x20], xmm2
00007f582cdd70b2  vmovaps [rsp+0x30], xmm3
00007f582cdd70b8  vmovaps [rsp+0x40], xmm5
00007f582cdd70be  vmovaps [rsp+0x50], xmm6
00007f582cdd70c4  vmovaps [rsp+0x60], xmm7
00007f582cdd70ca  vmovaps [rsp+0x70], xmm8
00007f582cdd70d0  vmovaps [rsp+0x80], xmm9
00007f582cdd70d9  vmovaps [rsp+0x90], xmm10
00007f582cdd70e2  vmovaps [rsp+0xA0], xmm11
00007f582cdd70eb  vmovaps [rsp+0xB0], xmm12
00007f582cdd70f4  vmovaps [rsp+0xC0], xmm13
00007f582cdd70fd  vmovaps [rsp+0xD0], xmm14
00007f582cdd7106  vmovaps [rsp+0xE0], xmm15
00007f582cdd710f  sub rsp, 0x30
00007f582cdd7113  movaps [rsp], xmm4
00007f582cdd7117  movaps [rsp+0x10], xmm9
00007f582cdd711d  movaps [rsp+0x20], xmm8
00007f582cdd7123  lea rdi, [rsp]
00007f582cdd7127  mov esi, 0x00
00007f582cdd712c  mov rax, 0x653B0D9BF530
00007f582cdd7136  call rax
00007f582cdd7138  movaps xmm4, [rsp]
00007f582cdd713c  add rsp, 0x30
00007f582cdd7140  vmovaps xmm0, [rsp]
00007f582cdd7145  vmovaps xmm1, [rsp+0x10]
00007f582cdd714b  vmovaps xmm2, [rsp+0x20]
00007f582cdd7151  vmovaps xmm3, [rsp+0x30]
00007f582cdd7157  vmovaps xmm5, [rsp+0x40]
00007f582cdd715d  vmovaps xmm6, [rsp+0x50]
00007f582cdd7163  vmovaps xmm7, [rsp+0x60]
00007f582cdd7169  vmovaps xmm8, [rsp+0x70]
00007f582cdd716f  vmovaps xmm9, [rsp+0x80]
00007f582cdd7178  vmovaps xmm10, [rsp+0x90]
00007f582cdd7181  vmovaps xmm11, [rsp+0xA0]
00007f582cdd718a  vmovaps xmm12, [rsp+0xB0]
00007f582cdd7193  vmovaps xmm13, [rsp+0xC0]
00007f582cdd719c  vmovaps xmm14, [rsp+0xD0]
00007f582cdd71a5  vmovaps xmm15, [rsp+0xE0]
00007f582cdd71ae  add rsp, 0xF0
00007f582cdd71b5  pop r11
00007f582cdd71b7  pop r10
00007f582cdd71b9  pop r9
00007f582cdd71bb  pop r8
00007f582cdd71bd  pop rsi
00007f582cdd71be  pop rdi
00007f582cdd71bf  pop rdx
00007f582cdd71c0  pop rcx
00007f582cdd71c1  pop rax
00007f582cdd71c2  add rsp, 0x08
00007f582cdd71c6  jmp 0x00007F582CDD5AE1
00007f582cdd71cb  sub rsp, 0x08
00007f582cdd71cf  push rax
00007f582cdd71d0  push rcx
00007f582cdd71d1  push rdx
00007f582cdd71d2  push rdi
00007f582cdd71d3  push rsi
00007f582cdd71d4  push r8
00007f582cdd71d6  push r9
00007f582cdd71d8  push r10
00007f582cdd71da  push r11
00007f582cdd71dc  sub rsp, 0xF0
00007f582cdd71e3  vmovaps [rsp], xmm0
00007f582cdd71e8  vmovaps [rsp+0x10], xmm1
00007f582cdd71ee  vmovaps [rsp+0x20], xmm2
00007f582cdd71f4  vmovaps [rsp+0x30], xmm3
00007f582cdd71fa  vmovaps [rsp+0x40], xmm4
00007f582cdd7200  vmovaps [rsp+0x50], xmm5
00007f582cdd7206  vmovaps [rsp+0x60], xmm6
00007f582cdd720c  vmovaps [rsp+0x70], xmm7
00007f582cdd7212  vmovaps [rsp+0x80], xmm8
00007f582cdd721b  vmovaps [rsp+0x90], xmm10
00007f582cdd7224  vmovaps [rsp+0xA0], xmm11
00007f582cdd722d  vmovaps [rsp+0xB0], xmm12
00007f582cdd7236  vmovaps [rsp+0xC0], xmm13
00007f582cdd723f  vmovaps [rsp+0xD0], xmm14
00007f582cdd7248  vmovaps [rsp+0xE0], xmm15
00007f582cdd7251  sub rsp, 0x30
00007f582cdd7255  movaps [rsp], xmm9
00007f582cdd725a  movaps [rsp+0x10], xmm10
00007f582cdd7260  movaps [rsp+0x20], xmm8
00007f582cdd7266  lea rdi, [rsp]
00007f582cdd726a  mov esi, 0x00
00007f582cdd726f  mov rax, 0x653B0D9BF530
00007f582cdd7279  call rax
00007f582cdd727b  movaps xmm9, [rsp]
00007f582cdd7280  add rsp, 0x30
00007f582cdd7284  vmovaps xmm0, [rsp]
00007f582cdd7289  vmovaps xmm1, [rsp+0x10]
00007f582cdd728f  vmovaps xmm2, [rsp+0x20]
00007f582cdd7295  vmovaps xmm3, [rsp+0x30]
00007f582cdd729b  vmovaps xmm4, [rsp+0x40]
00007f582cdd72a1  vmovaps xmm5, [rsp+0x50]
00007f582cdd72a7  vmovaps xmm6, [rsp+0x60]
00007f582cdd72ad  vmovaps xmm7, [rsp+0x70]
00007f582cdd72b3  vmovaps xmm8, [rsp+0x80]
00007f582cdd72bc  vmovaps xmm10, [rsp+0x90]
00007f582cdd72c5  vmovaps xmm11, [rsp+0xA0]
00007f582cdd72ce  vmovaps xmm12, [rsp+0xB0]
00007f582cdd72d7  vmovaps xmm13, [rsp+0xC0]
00007f582cdd72e0  vmovaps xmm14, [rsp+0xD0]
00007f582cdd72e9  vmovaps xmm15, [rsp+0xE0]
00007f582cdd72f2  add rsp, 0xF0
00007f582cdd72f9  pop r11
00007f582cdd72fb  pop r10
00007f582cdd72fd  pop r9
00007f582cdd72ff  pop r8
00007f582cdd7301  pop rsi
00007f582cdd7302  pop rdi
00007f582cdd7303  pop rdx
00007f582cdd7304  pop rcx
00007f582cdd7305  pop rax
00007f582cdd7306  add rsp, 0x08
00007f582cdd730a  jmp 0x00007F582CDD5AFB
00007f582cdd730f  call 0x00007F582CCD64F0
00007f582cdd7314  jmp 0x00007F582CDD5C15
00007f582cdd7319  call 0x00007F582CCD64F0
00007f582cdd731e  jmp 0x00007F582CDD5C2B
00007f582cdd7323  sub rsp, 0x08
00007f582cdd7327  push rax
00007f582cdd7328  push rcx
00007f582cdd7329  push rdx
00007f582cdd732a  push rdi
00007f582cdd732b  push rsi
00007f582cdd732c  push r8
00007f582cdd732e  push r9
00007f582cdd7330  push r10
00007f582cdd7332  push r11
00007f582cdd7334  sub rsp, 0xF0
00007f582cdd733b  vmovaps [rsp], xmm0
00007f582cdd7340  vmovaps [rsp+0x10], xmm2
00007f582cdd7346  vmovaps [rsp+0x20], xmm3
00007f582cdd734c  vmovaps [rsp+0x30], xmm4
00007f582cdd7352  vmovaps [rsp+0x40], xmm5
00007f582cdd7358  vmovaps [rsp+0x50], xmm6
00007f582cdd735e  vmovaps [rsp+0x60], xmm7
00007f582cdd7364  vmovaps [rsp+0x70], xmm8
00007f582cdd736a  vmovaps [rsp+0x80], xmm9
00007f582cdd7373  vmovaps [rsp+0x90], xmm10
00007f582cdd737c  vmovaps [rsp+0xA0], xmm11
00007f582cdd7385  vmovaps [rsp+0xB0], xmm12
00007f582cdd738e  vmovaps [rsp+0xC0], xmm13
00007f582cdd7397  vmovaps [rsp+0xD0], xmm14
00007f582cdd73a0  vmovaps [rsp+0xE0], xmm15
00007f582cdd73a9  sub rsp, 0x30
00007f582cdd73ad  movaps [rsp], xmm1
00007f582cdd73b1  movaps [rsp+0x10], xmm6
00007f582cdd73b6  movaps [rsp+0x20], xmm15
00007f582cdd73bc  lea rdi, [rsp]
00007f582cdd73c0  mov esi, 0x00
00007f582cdd73c5  mov rax, 0x653B0D9BF530
00007f582cdd73cf  call rax
00007f582cdd73d1  movaps xmm1, [rsp]
00007f582cdd73d5  add rsp, 0x30
00007f582cdd73d9  vmovaps xmm0, [rsp]
00007f582cdd73de  vmovaps xmm2, [rsp+0x10]
00007f582cdd73e4  vmovaps xmm3, [rsp+0x20]
00007f582cdd73ea  vmovaps xmm4, [rsp+0x30]
00007f582cdd73f0  vmovaps xmm5, [rsp+0x40]
00007f582cdd73f6  vmovaps xmm6, [rsp+0x50]
00007f582cdd73fc  vmovaps xmm7, [rsp+0x60]
00007f582cdd7402  vmovaps xmm8, [rsp+0x70]
00007f582cdd7408  vmovaps xmm9, [rsp+0x80]
00007f582cdd7411  vmovaps xmm10, [rsp+0x90]
00007f582cdd741a  vmovaps xmm11, [rsp+0xA0]
00007f582cdd7423  vmovaps xmm12, [rsp+0xB0]
00007f582cdd742c  vmovaps xmm13, [rsp+0xC0]
00007f582cdd7435  vmovaps xmm14, [rsp+0xD0]
00007f582cdd743e  vmovaps xmm15, [rsp+0xE0]
00007f582cdd7447  add rsp, 0xF0
00007f582cdd744e  pop r11
00007f582cdd7450  pop r10
00007f582cdd7452  pop r9
00007f582cdd7454  pop r8
00007f582cdd7456  pop rsi
00007f582cdd7457  pop rdi
00007f582cdd7458  pop rdx
00007f582cdd7459  pop rcx
00007f582cdd745a  pop rax
00007f582cdd745b  add rsp, 0x08
00007f582cdd745f  jmp 0x00007F582CDD5C68
00007f582cdd7464  call 0x00007F582CCE5820
00007f582cdd7469  jmp 0x00007F582CDD5C75
00007f582cdd746e  sub rsp, 0x08
00007f582cdd7472  push rax
00007f582cdd7473  push rcx
00007f582cdd7474  push rdx
00007f582cdd7475  push rdi
00007f582cdd7476  push rsi
00007f582cdd7477  push r8
00007f582cdd7479  push r9
00007f582cdd747b  push r10
00007f582cdd747d  push r11
00007f582cdd747f  sub rsp, 0xF0
00007f582cdd7486  vmovaps [rsp], xmm0
00007f582cdd748b  vmovaps [rsp+0x10], xmm1
00007f582cdd7491  vmovaps [rsp+0x20], xmm2
00007f582cdd7497  vmovaps [rsp+0x30], xmm3
00007f582cdd749d  vmovaps [rsp+0x40], xmm4
00007f582cdd74a3  vmovaps [rsp+0x50], xmm5
00007f582cdd74a9  vmovaps [rsp+0x60], xmm6
00007f582cdd74af  vmovaps [rsp+0x70], xmm7
00007f582cdd74b5  vmovaps [rsp+0x80], xmm8
00007f582cdd74be  vmovaps [rsp+0x90], xmm9
00007f582cdd74c7  vmovaps [rsp+0xA0], xmm10
00007f582cdd74d0  vmovaps [rsp+0xB0], xmm11
00007f582cdd74d9  vmovaps [rsp+0xC0], xmm12
00007f582cdd74e2  vmovaps [rsp+0xD0], xmm13
00007f582cdd74eb  vmovaps [rsp+0xE0], xmm15
00007f582cdd74f4  sub rsp, 0x30
00007f582cdd74f8  movaps [rsp], xmm14
00007f582cdd74fd  movaps [rsp+0x10], xmm4
00007f582cdd7502  movaps [rsp+0x20], xmm3
00007f582cdd7507  lea rdi, [rsp]
00007f582cdd750b  mov esi, 0x00
00007f582cdd7510  mov rax, 0x653B0D9BF530
00007f582cdd751a  call rax
00007f582cdd751c  movaps xmm14, [rsp]
00007f582cdd7521  add rsp, 0x30
00007f582cdd7525  vmovaps xmm0, [rsp]
00007f582cdd752a  vmovaps xmm1, [rsp+0x10]
00007f582cdd7530  vmovaps xmm2, [rsp+0x20]
00007f582cdd7536  vmovaps xmm3, [rsp+0x30]
00007f582cdd753c  vmovaps xmm4, [rsp+0x40]
00007f582cdd7542  vmovaps xmm5, [rsp+0x50]
00007f582cdd7548  vmovaps xmm6, [rsp+0x60]
00007f582cdd754e  vmovaps xmm7, [rsp+0x70]
00007f582cdd7554  vmovaps xmm8, [rsp+0x80]
00007f582cdd755d  vmovaps xmm9, [rsp+0x90]
00007f582cdd7566  vmovaps xmm10, [rsp+0xA0]
00007f582cdd756f  vmovaps xmm11, [rsp+0xB0]
00007f582cdd7578  vmovaps xmm12, [rsp+0xC0]
00007f582cdd7581  vmovaps xmm13, [rsp+0xD0]
00007f582cdd758a  vmovaps xmm15, [rsp+0xE0]
00007f582cdd7593  add rsp, 0xF0
00007f582cdd759a  pop r11
00007f582cdd759c  pop r10
00007f582cdd759e  pop r9
00007f582cdd75a0  pop r8
00007f582cdd75a2  pop rsi
00007f582cdd75a3  pop rdi
00007f582cdd75a4  pop rdx
00007f582cdd75a5  pop rcx
00007f582cdd75a6  pop rax
00007f582cdd75a7  add rsp, 0x08
00007f582cdd75ab  jmp 0x00007F582CDD5C8F
00007f582cdd75b0  sub rsp, 0x08
00007f582cdd75b4  push rax
00007f582cdd75b5  push rcx
00007f582cdd75b6  push rdx
00007f582cdd75b7  push rdi
00007f582cdd75b8  push rsi
00007f582cdd75b9  push r8
00007f582cdd75bb  push r9
00007f582cdd75bd  push r10
00007f582cdd75bf  push r11
00007f582cdd75c1  sub rsp, 0xF0
00007f582cdd75c8  vmovaps [rsp], xmm0
00007f582cdd75cd  vmovaps [rsp+0x10], xmm1
00007f582cdd75d3  vmovaps [rsp+0x20], xmm2
00007f582cdd75d9  vmovaps [rsp+0x30], xmm3
00007f582cdd75df  vmovaps [rsp+0x40], xmm4
00007f582cdd75e5  vmovaps [rsp+0x50], xmm5
00007f582cdd75eb  vmovaps [rsp+0x60], xmm7
00007f582cdd75f1  vmovaps [rsp+0x70], xmm8
00007f582cdd75f7  vmovaps [rsp+0x80], xmm9
00007f582cdd7600  vmovaps [rsp+0x90], xmm10
00007f582cdd7609  vmovaps [rsp+0xA0], xmm11
00007f582cdd7612  vmovaps [rsp+0xB0], xmm12
00007f582cdd761b  vmovaps [rsp+0xC0], xmm13
00007f582cdd7624  vmovaps [rsp+0xD0], xmm14
00007f582cdd762d  vmovaps [rsp+0xE0], xmm15
00007f582cdd7636  sub rsp, 0x30
00007f582cdd763a  movaps [rsp], xmm6
00007f582cdd763e  movaps [rsp+0x10], xmm9
00007f582cdd7644  movaps [rsp+0x20], xmm7
00007f582cdd7649  lea rdi, [rsp]
00007f582cdd764d  mov esi, 0x00
00007f582cdd7652  mov rax, 0x653B0D9BF530
00007f582cdd765c  call rax
00007f582cdd765e  movaps xmm6, [rsp]
00007f582cdd7662  add rsp, 0x30
00007f582cdd7666  vmovaps xmm0, [rsp]
00007f582cdd766b  vmovaps xmm1, [rsp+0x10]
00007f582cdd7671  vmovaps xmm2, [rsp+0x20]
00007f582cdd7677  vmovaps xmm3, [rsp+0x30]
00007f582cdd767d  vmovaps xmm4, [rsp+0x40]
00007f582cdd7683  vmovaps xmm5, [rsp+0x50]
00007f582cdd7689  vmovaps xmm7, [rsp+0x60]
00007f582cdd768f  vmovaps xmm8, [rsp+0x70]
00007f582cdd7695  vmovaps xmm9, [rsp+0x80]
00007f582cdd769e  vmovaps xmm10, [rsp+0x90]
00007f582cdd76a7  vmovaps xmm11, [rsp+0xA0]
00007f582cdd76b0  vmovaps xmm12, [rsp+0xB0]
00007f582cdd76b9  vmovaps xmm13, [rsp+0xC0]
00007f582cdd76c2  vmovaps xmm14, [rsp+0xD0]
00007f582cdd76cb  vmovaps xmm15, [rsp+0xE0]
00007f582cdd76d4  add rsp, 0xF0
00007f582cdd76db  pop r11
00007f582cdd76dd  pop r10
00007f582cdd76df  pop r9
00007f582cdd76e1  pop r8
00007f582cdd76e3  pop rsi
00007f582cdd76e4  pop rdi
00007f582cdd76e5  pop rdx
00007f582cdd76e6  pop rcx
00007f582cdd76e7  pop rax
00007f582cdd76e8  add rsp, 0x08
00007f582cdd76ec  jmp 0x00007F582CDD5CA7
00007f582cdd76f1  sub rsp, 0x08
00007f582cdd76f5  push rax
00007f582cdd76f6  push rcx
00007f582cdd76f7  push rdx
00007f582cdd76f8  push rdi
00007f582cdd76f9  push rsi
00007f582cdd76fa  push r8
00007f582cdd76fc  push r9
00007f582cdd76fe  push r10
00007f582cdd7700  push r11
00007f582cdd7702  sub rsp, 0xF0
00007f582cdd7709  vmovaps [rsp], xmm0
00007f582cdd770e  vmovaps [rsp+0x10], xmm1
00007f582cdd7714  vmovaps [rsp+0x20], xmm2
00007f582cdd771a  vmovaps [rsp+0x30], xmm3
00007f582cdd7720  vmovaps [rsp+0x40], xmm4
00007f582cdd7726  vmovaps [rsp+0x50], xmm5
00007f582cdd772c  vmovaps [rsp+0x60], xmm6
00007f582cdd7732  vmovaps [rsp+0x70], xmm8
00007f582cdd7738  vmovaps [rsp+0x80], xmm9
00007f582cdd7741  vmovaps [rsp+0x90], xmm10
00007f582cdd774a  vmovaps [rsp+0xA0], xmm11
00007f582cdd7753  vmovaps [rsp+0xB0], xmm12
00007f582cdd775c  vmovaps [rsp+0xC0], xmm13
00007f582cdd7765  vmovaps [rsp+0xD0], xmm14
00007f582cdd776e  vmovaps [rsp+0xE0], xmm15
00007f582cdd7777  sub rsp, 0x30
00007f582cdd777b  movaps [rsp], xmm7
00007f582cdd777f  movaps [rsp+0x10], xmm4
00007f582cdd7784  movaps [rsp+0x20], xmm9
00007f582cdd778a  lea rdi, [rsp]
00007f582cdd778e  mov esi, 0x00
00007f582cdd7793  mov rax, 0x653B0D9BF530
00007f582cdd779d  call rax
00007f582cdd779f  movaps xmm7, [rsp]
00007f582cdd77a3  add rsp, 0x30
00007f582cdd77a7  vmovaps xmm0, [rsp]
00007f582cdd77ac  vmovaps xmm1, [rsp+0x10]
00007f582cdd77b2  vmovaps xmm2, [rsp+0x20]
00007f582cdd77b8  vmovaps xmm3, [rsp+0x30]
00007f582cdd77be  vmovaps xmm4, [rsp+0x40]
00007f582cdd77c4  vmovaps xmm5, [rsp+0x50]
00007f582cdd77ca  vmovaps xmm6, [rsp+0x60]
00007f582cdd77d0  vmovaps xmm8, [rsp+0x70]
00007f582cdd77d6  vmovaps xmm9, [rsp+0x80]
00007f582cdd77df  vmovaps xmm10, [rsp+0x90]
00007f582cdd77e8  vmovaps xmm11, [rsp+0xA0]
00007f582cdd77f1  vmovaps xmm12, [rsp+0xB0]
00007f582cdd77fa  vmovaps xmm13, [rsp+0xC0]
00007f582cdd7803  vmovaps xmm14, [rsp+0xD0]
00007f582cdd780c  vmovaps xmm15, [rsp+0xE0]
00007f582cdd7815  add rsp, 0xF0
00007f582cdd781c  pop r11
00007f582cdd781e  pop r10
00007f582cdd7820  pop r9
00007f582cdd7822  pop r8
00007f582cdd7824  pop rsi
00007f582cdd7825  pop rdi
00007f582cdd7826  pop rdx
00007f582cdd7827  pop rcx
00007f582cdd7828  pop rax
00007f582cdd7829  add rsp, 0x08
00007f582cdd782d  jmp 0x00007F582CDD5CD4
00007f582cdd7832  sub rsp, 0x08
00007f582cdd7836  push rax
00007f582cdd7837  push rcx
00007f582cdd7838  push rdx
00007f582cdd7839  push rdi
00007f582cdd783a  push rsi
00007f582cdd783b  push r8
00007f582cdd783d  push r9
00007f582cdd783f  push r10
00007f582cdd7841  push r11
00007f582cdd7843  sub rsp, 0xF0
00007f582cdd784a  vmovaps [rsp], xmm0
00007f582cdd784f  vmovaps [rsp+0x10], xmm1
00007f582cdd7855  vmovaps [rsp+0x20], xmm2
00007f582cdd785b  vmovaps [rsp+0x30], xmm3
00007f582cdd7861  vmovaps [rsp+0x40], xmm5
00007f582cdd7867  vmovaps [rsp+0x50], xmm6
00007f582cdd786d  vmovaps [rsp+0x60], xmm7
00007f582cdd7873  vmovaps [rsp+0x70], xmm8
00007f582cdd7879  vmovaps [rsp+0x80], xmm9
00007f582cdd7882  vmovaps [rsp+0x90], xmm10
00007f582cdd788b  vmovaps [rsp+0xA0], xmm11
00007f582cdd7894  vmovaps [rsp+0xB0], xmm12
00007f582cdd789d  vmovaps [rsp+0xC0], xmm13
00007f582cdd78a6  vmovaps [rsp+0xD0], xmm14
00007f582cdd78af  vmovaps [rsp+0xE0], xmm15
00007f582cdd78b8  sub rsp, 0x30
00007f582cdd78bc  movaps [rsp], xmm4
00007f582cdd78c0  movaps [rsp+0x10], xmm15
00007f582cdd78c6  movaps [rsp+0x20], xmm9
00007f582cdd78cc  lea rdi, [rsp]
00007f582cdd78d0  mov esi, 0x00
00007f582cdd78d5  mov rax, 0x653B0D9BF530
00007f582cdd78df  call rax
00007f582cdd78e1  movaps xmm4, [rsp]
00007f582cdd78e5  add rsp, 0x30
00007f582cdd78e9  vmovaps xmm0, [rsp]
00007f582cdd78ee  vmovaps xmm1, [rsp+0x10]
00007f582cdd78f4  vmovaps xmm2, [rsp+0x20]
00007f582cdd78fa  vmovaps xmm3, [rsp+0x30]
00007f582cdd7900  vmovaps xmm5, [rsp+0x40]
00007f582cdd7906  vmovaps xmm6, [rsp+0x50]
00007f582cdd790c  vmovaps xmm7, [rsp+0x60]
00007f582cdd7912  vmovaps xmm8, [rsp+0x70]
00007f582cdd7918  vmovaps xmm9, [rsp+0x80]
00007f582cdd7921  vmovaps xmm10, [rsp+0x90]
00007f582cdd792a  vmovaps xmm11, [rsp+0xA0]
00007f582cdd7933  vmovaps xmm12, [rsp+0xB0]
00007f582cdd793c  vmovaps xmm13, [rsp+0xC0]
00007f582cdd7945  vmovaps xmm14, [rsp+0xD0]
00007f582cdd794e  vmovaps xmm15, [rsp+0xE0]
00007f582cdd7957  add rsp, 0xF0
00007f582cdd795e  pop r11
00007f582cdd7960  pop r10
00007f582cdd7962  pop r9
00007f582cdd7964  pop r8
00007f582cdd7966  pop rsi
00007f582cdd7967  pop rdi
00007f582cdd7968  pop rdx
00007f582cdd7969  pop rcx
00007f582cdd796a  pop rax
00007f582cdd796b  add rsp, 0x08
00007f582cdd796f  jmp 0x00007F582CDD5CF9
00007f582cdd7974  call 0x00007F582CCE5820
00007f582cdd7979  jmp 0x00007F582CDD5D06
00007f582cdd797e  sub rsp, 0x08
00007f582cdd7982  push rax
00007f582cdd7983  push rcx
00007f582cdd7984  push rdx
00007f582cdd7985  push rdi
00007f582cdd7986  push rsi
00007f582cdd7987  push r8
00007f582cdd7989  push r9
00007f582cdd798b  push r10
00007f582cdd798d  push r11
00007f582cdd798f  sub rsp, 0xF0
00007f582cdd7996  vmovaps [rsp], xmm0
00007f582cdd799b  vmovaps [rsp+0x10], xmm1
00007f582cdd79a1  vmovaps [rsp+0x20], xmm2
00007f582cdd79a7  vmovaps [rsp+0x30], xmm4
00007f582cdd79ad  vmovaps [rsp+0x40], xmm5
00007f582cdd79b3  vmovaps [rsp+0x50], xmm6
00007f582cdd79b9  vmovaps [rsp+0x60], xmm7
00007f582cdd79bf  vmovaps [rsp+0x70], xmm8
00007f582cdd79c5  vmovaps [rsp+0x80], xmm9
00007f582cdd79ce  vmovaps [rsp+0x90], xmm10
00007f582cdd79d7  vmovaps [rsp+0xA0], xmm11
00007f582cdd79e0  vmovaps [rsp+0xB0], xmm12
00007f582cdd79e9  vmovaps [rsp+0xC0], xmm13
00007f582cdd79f2  vmovaps [rsp+0xD0], xmm14
00007f582cdd79fb  vmovaps [rsp+0xE0], xmm15
00007f582cdd7a04  sub rsp, 0x30
00007f582cdd7a08  movaps [rsp], xmm3
00007f582cdd7a0c  movaps [rsp+0x10], xmm1
00007f582cdd7a11  movaps [rsp+0x20], xmm9
00007f582cdd7a17  lea rdi, [rsp]
00007f582cdd7a1b  mov esi, 0x00
00007f582cdd7a20  mov rax, 0x653B0D9BF530
00007f582cdd7a2a  call rax
00007f582cdd7a2c  movaps xmm3, [rsp]
00007f582cdd7a30  add rsp, 0x30
00007f582cdd7a34  vmovaps xmm0, [rsp]
00007f582cdd7a39  vmovaps xmm1, [rsp+0x10]
00007f582cdd7a3f  vmovaps xmm2, [rsp+0x20]
00007f582cdd7a45  vmovaps xmm4, [rsp+0x30]
00007f582cdd7a4b  vmovaps xmm5, [rsp+0x40]
00007f582cdd7a51  vmovaps xmm6, [rsp+0x50]
00007f582cdd7a57  vmovaps xmm7, [rsp+0x60]
00007f582cdd7a5d  vmovaps xmm8, [rsp+0x70]
00007f582cdd7a63  vmovaps xmm9, [rsp+0x80]
00007f582cdd7a6c  vmovaps xmm10, [rsp+0x90]
00007f582cdd7a75  vmovaps xmm11, [rsp+0xA0]
00007f582cdd7a7e  vmovaps xmm12, [rsp+0xB0]
00007f582cdd7a87  vmovaps xmm13, [rsp+0xC0]
00007f582cdd7a90  vmovaps xmm14, [rsp+0xD0]
00007f582cdd7a99  vmovaps xmm15, [rsp+0xE0]
00007f582cdd7aa2  add rsp, 0xF0
00007f582cdd7aa9  pop r11
00007f582cdd7aab  pop r10
00007f582cdd7aad  pop r9
00007f582cdd7aaf  pop r8
00007f582cdd7ab1  pop rsi
00007f582cdd7ab2  pop rdi
00007f582cdd7ab3  pop rdx
00007f582cdd7ab4  pop rcx
00007f582cdd7ab5  pop rax
00007f582cdd7ab6  add rsp, 0x08
00007f582cdd7aba  jmp 0x00007F582CDD5D43
00007f582cdd7abf  sub rsp, 0x08
00007f582cdd7ac3  push rax
00007f582cdd7ac4  push rcx
00007f582cdd7ac5  push rdx
00007f582cdd7ac6  push rdi
00007f582cdd7ac7  push rsi
00007f582cdd7ac8  push r8
00007f582cdd7aca  push r9
00007f582cdd7acc  push r10
00007f582cdd7ace  push r11
00007f582cdd7ad0  sub rsp, 0xF0
00007f582cdd7ad7  vmovaps [rsp], xmm0
00007f582cdd7adc  vmovaps [rsp+0x10], xmm2
00007f582cdd7ae2  vmovaps [rsp+0x20], xmm3
00007f582cdd7ae8  vmovaps [rsp+0x30], xmm4
00007f582cdd7aee  vmovaps [rsp+0x40], xmm5
00007f582cdd7af4  vmovaps [rsp+0x50], xmm6
00007f582cdd7afa  vmovaps [rsp+0x60], xmm7
00007f582cdd7b00  vmovaps [rsp+0x70], xmm8
00007f582cdd7b06  vmovaps [rsp+0x80], xmm9
00007f582cdd7b0f  vmovaps [rsp+0x90], xmm10
00007f582cdd7b18  vmovaps [rsp+0xA0], xmm11
00007f582cdd7b21  vmovaps [rsp+0xB0], xmm12
00007f582cdd7b2a  vmovaps [rsp+0xC0], xmm13
00007f582cdd7b33  vmovaps [rsp+0xD0], xmm14
00007f582cdd7b3c  vmovaps [rsp+0xE0], xmm15
00007f582cdd7b45  sub rsp, 0x30
00007f582cdd7b49  movaps [rsp], xmm1
00007f582cdd7b4d  movaps [rsp+0x10], xmm15
00007f582cdd7b53  movaps [rsp+0x20], xmm9
00007f582cdd7b59  lea rdi, [rsp]
00007f582cdd7b5d  mov esi, 0x00
00007f582cdd7b62  mov rax, 0x653B0D9BF530
00007f582cdd7b6c  call rax
00007f582cdd7b6e  movaps xmm1, [rsp]
00007f582cdd7b72  add rsp, 0x30
00007f582cdd7b76  vmovaps xmm0, [rsp]
00007f582cdd7b7b  vmovaps xmm2, [rsp+0x10]
00007f582cdd7b81  vmovaps xmm3, [rsp+0x20]
00007f582cdd7b87  vmovaps xmm4, [rsp+0x30]
00007f582cdd7b8d  vmovaps xmm5, [rsp+0x40]
00007f582cdd7b93  vmovaps xmm6, [rsp+0x50]
00007f582cdd7b99  vmovaps xmm7, [rsp+0x60]
00007f582cdd7b9f  vmovaps xmm8, [rsp+0x70]
00007f582cdd7ba5  vmovaps xmm9, [rsp+0x80]
00007f582cdd7bae  vmovaps xmm10, [rsp+0x90]
00007f582cdd7bb7  vmovaps xmm11, [rsp+0xA0]
00007f582cdd7bc0  vmovaps xmm12, [rsp+0xB0]
00007f582cdd7bc9  vmovaps xmm13, [rsp+0xC0]
00007f582cdd7bd2  vmovaps xmm14, [rsp+0xD0]
00007f582cdd7bdb  vmovaps xmm15, [rsp+0xE0]
00007f582cdd7be4  add rsp, 0xF0
00007f582cdd7beb  pop r11
00007f582cdd7bed  pop r10
00007f582cdd7bef  pop r9
00007f582cdd7bf1  pop r8
00007f582cdd7bf3  pop rsi
00007f582cdd7bf4  pop rdi
00007f582cdd7bf5  pop rdx
00007f582cdd7bf6  pop rcx
00007f582cdd7bf7  pop rax
00007f582cdd7bf8  add rsp, 0x08
00007f582cdd7bfc  jmp 0x00007F582CDD5DCB
00007f582cdd7c01  call 0x00007F582CCE5820
00007f582cdd7c06  jmp 0x00007F582CDD5DD8
00007f582cdd7c0b  sub rsp, 0x08
00007f582cdd7c0f  push rax
00007f582cdd7c10  push rcx
00007f582cdd7c11  push rdx
00007f582cdd7c12  push rdi
00007f582cdd7c13  push rsi
00007f582cdd7c14  push r8
00007f582cdd7c16  push r9
00007f582cdd7c18  push r10
00007f582cdd7c1a  push r11
00007f582cdd7c1c  sub rsp, 0xF0
00007f582cdd7c23  vmovaps [rsp], xmm0
00007f582cdd7c28  vmovaps [rsp+0x10], xmm2
00007f582cdd7c2e  vmovaps [rsp+0x20], xmm3
00007f582cdd7c34  vmovaps [rsp+0x30], xmm4
00007f582cdd7c3a  vmovaps [rsp+0x40], xmm5
00007f582cdd7c40  vmovaps [rsp+0x50], xmm6
00007f582cdd7c46  vmovaps [rsp+0x60], xmm7
00007f582cdd7c4c  vmovaps [rsp+0x70], xmm8
00007f582cdd7c52  vmovaps [rsp+0x80], xmm9
00007f582cdd7c5b  vmovaps [rsp+0x90], xmm10
00007f582cdd7c64  vmovaps [rsp+0xA0], xmm11
00007f582cdd7c6d  vmovaps [rsp+0xB0], xmm12
00007f582cdd7c76  vmovaps [rsp+0xC0], xmm13
00007f582cdd7c7f  vmovaps [rsp+0xD0], xmm14
00007f582cdd7c88  vmovaps [rsp+0xE0], xmm15
00007f582cdd7c91  sub rsp, 0x30
00007f582cdd7c95  movaps [rsp], xmm1
00007f582cdd7c99  movaps [rsp+0x10], xmm5
00007f582cdd7c9e  movaps [rsp+0x20], xmm7
00007f582cdd7ca3  lea rdi, [rsp]
00007f582cdd7ca7  mov esi, 0x00
00007f582cdd7cac  mov rax, 0x653B0D9BF530
00007f582cdd7cb6  call rax
00007f582cdd7cb8  movaps xmm1, [rsp]
00007f582cdd7cbc  add rsp, 0x30
00007f582cdd7cc0  vmovaps xmm0, [rsp]
00007f582cdd7cc5  vmovaps xmm2, [rsp+0x10]
00007f582cdd7ccb  vmovaps xmm3, [rsp+0x20]
00007f582cdd7cd1  vmovaps xmm4, [rsp+0x30]
00007f582cdd7cd7  vmovaps xmm5, [rsp+0x40]
00007f582cdd7cdd  vmovaps xmm6, [rsp+0x50]
00007f582cdd7ce3  vmovaps xmm7, [rsp+0x60]
00007f582cdd7ce9  vmovaps xmm8, [rsp+0x70]
00007f582cdd7cef  vmovaps xmm9, [rsp+0x80]
00007f582cdd7cf8  vmovaps xmm10, [rsp+0x90]
00007f582cdd7d01  vmovaps xmm11, [rsp+0xA0]
00007f582cdd7d0a  vmovaps xmm12, [rsp+0xB0]
00007f582cdd7d13  vmovaps xmm13, [rsp+0xC0]
00007f582cdd7d1c  vmovaps xmm14, [rsp+0xD0]
00007f582cdd7d25  vmovaps xmm15, [rsp+0xE0]
00007f582cdd7d2e  add rsp, 0xF0
00007f582cdd7d35  pop r11
00007f582cdd7d37  pop r10
00007f582cdd7d39  pop r9
00007f582cdd7d3b  pop r8
00007f582cdd7d3d  pop rsi
00007f582cdd7d3e  pop rdi
00007f582cdd7d3f  pop rdx
00007f582cdd7d40  pop rcx
00007f582cdd7d41  pop rax
00007f582cdd7d42  add rsp, 0x08
00007f582cdd7d46  jmp 0x00007F582CDD5E7D
00007f582cdd7d4b  sub rsp, 0x08
00007f582cdd7d4f  push rax
00007f582cdd7d50  push rcx
00007f582cdd7d51  push rdx
00007f582cdd7d52  push rdi
00007f582cdd7d53  push rsi
00007f582cdd7d54  push r8
00007f582cdd7d56  push r9
00007f582cdd7d58  push r10
00007f582cdd7d5a  push r11
00007f582cdd7d5c  sub rsp, 0xF0
00007f582cdd7d63  vmovaps [rsp], xmm0
00007f582cdd7d68  vmovaps [rsp+0x10], xmm1
00007f582cdd7d6e  vmovaps [rsp+0x20], xmm2
00007f582cdd7d74  vmovaps [rsp+0x30], xmm3
00007f582cdd7d7a  vmovaps [rsp+0x40], xmm4
00007f582cdd7d80  vmovaps [rsp+0x50], xmm5
00007f582cdd7d86  vmovaps [rsp+0x60], xmm6
00007f582cdd7d8c  vmovaps [rsp+0x70], xmm8
00007f582cdd7d92  vmovaps [rsp+0x80], xmm9
00007f582cdd7d9b  vmovaps [rsp+0x90], xmm10
00007f582cdd7da4  vmovaps [rsp+0xA0], xmm11
00007f582cdd7dad  vmovaps [rsp+0xB0], xmm12
00007f582cdd7db6  vmovaps [rsp+0xC0], xmm13
00007f582cdd7dbf  vmovaps [rsp+0xD0], xmm14
00007f582cdd7dc8  vmovaps [rsp+0xE0], xmm15
00007f582cdd7dd1  sub rsp, 0x30
00007f582cdd7dd5  movaps [rsp], xmm7
00007f582cdd7dd9  movaps [rsp+0x10], xmm5
00007f582cdd7dde  movaps [rsp+0x20], xmm15
00007f582cdd7de4  lea rdi, [rsp]
00007f582cdd7de8  mov esi, 0x00
00007f582cdd7ded  mov rax, 0x653B0D9BF530
00007f582cdd7df7  call rax
00007f582cdd7df9  movaps xmm7, [rsp]
00007f582cdd7dfd  add rsp, 0x30
00007f582cdd7e01  vmovaps xmm0, [rsp]
00007f582cdd7e06  vmovaps xmm1, [rsp+0x10]
00007f582cdd7e0c  vmovaps xmm2, [rsp+0x20]
00007f582cdd7e12  vmovaps xmm3, [rsp+0x30]
00007f582cdd7e18  vmovaps xmm4, [rsp+0x40]
00007f582cdd7e1e  vmovaps xmm5, [rsp+0x50]
00007f582cdd7e24  vmovaps xmm6, [rsp+0x60]
00007f582cdd7e2a  vmovaps xmm8, [rsp+0x70]
00007f582cdd7e30  vmovaps xmm9, [rsp+0x80]
00007f582cdd7e39  vmovaps xmm10, [rsp+0x90]
00007f582cdd7e42  vmovaps xmm11, [rsp+0xA0]
00007f582cdd7e4b  vmovaps xmm12, [rsp+0xB0]
00007f582cdd7e54  vmovaps xmm13, [rsp+0xC0]
00007f582cdd7e5d  vmovaps xmm14, [rsp+0xD0]
00007f582cdd7e66  vmovaps xmm15, [rsp+0xE0]
00007f582cdd7e6f  add rsp, 0xF0
00007f582cdd7e76  pop r11
00007f582cdd7e78  pop r10
00007f582cdd7e7a  pop r9
00007f582cdd7e7c  pop r8
00007f582cdd7e7e  pop rsi
00007f582cdd7e7f  pop rdi
00007f582cdd7e80  pop rdx
00007f582cdd7e81  pop rcx
00007f582cdd7e82  pop rax
00007f582cdd7e83  add rsp, 0x08
00007f582cdd7e87  jmp 0x00007F582CDD5EB3
00007f582cdd7e8c  call 0x00007F582CCD64F0
00007f582cdd7e91  jmp 0x00007F582CDD5EC0
00007f582cdd7e96  sub rsp, 0x08
00007f582cdd7e9a  push rax
00007f582cdd7e9b  push rcx
00007f582cdd7e9c  push rdx
00007f582cdd7e9d  push rdi
00007f582cdd7e9e  push rsi
00007f582cdd7e9f  push r8
00007f582cdd7ea1  push r9
00007f582cdd7ea3  push r10
00007f582cdd7ea5  push r11
00007f582cdd7ea7  sub rsp, 0xF0
00007f582cdd7eae  vmovaps [rsp], xmm0
00007f582cdd7eb3  vmovaps [rsp+0x10], xmm1
00007f582cdd7eb9  vmovaps [rsp+0x20], xmm2
00007f582cdd7ebf  vmovaps [rsp+0x30], xmm3
00007f582cdd7ec5  vmovaps [rsp+0x40], xmm4
00007f582cdd7ecb  vmovaps [rsp+0x50], xmm5
00007f582cdd7ed1  vmovaps [rsp+0x60], xmm6
00007f582cdd7ed7  vmovaps [rsp+0x70], xmm7
00007f582cdd7edd  vmovaps [rsp+0x80], xmm8
00007f582cdd7ee6  vmovaps [rsp+0x90], xmm9
00007f582cdd7eef  vmovaps [rsp+0xA0], xmm10
00007f582cdd7ef8  vmovaps [rsp+0xB0], xmm11
00007f582cdd7f01  vmovaps [rsp+0xC0], xmm12
00007f582cdd7f0a  vmovaps [rsp+0xD0], xmm13
00007f582cdd7f13  vmovaps [rsp+0xE0], xmm14
00007f582cdd7f1c  sub rsp, 0x30
00007f582cdd7f20  movaps [rsp], xmm15
00007f582cdd7f25  movaps [rsp+0x10], xmm5
00007f582cdd7f2a  movaps [rsp+0x20], xmm3
00007f582cdd7f2f  lea rdi, [rsp]
00007f582cdd7f33  mov esi, 0x00
00007f582cdd7f38  mov rax, 0x653B0D9BF530
00007f582cdd7f42  call rax
00007f582cdd7f44  movaps xmm15, [rsp]
00007f582cdd7f49  add rsp, 0x30
00007f582cdd7f4d  vmovaps xmm0, [rsp]
00007f582cdd7f52  vmovaps xmm1, [rsp+0x10]
00007f582cdd7f58  vmovaps xmm2, [rsp+0x20]
00007f582cdd7f5e  vmovaps xmm3, [rsp+0x30]
00007f582cdd7f64  vmovaps xmm4, [rsp+0x40]
00007f582cdd7f6a  vmovaps xmm5, [rsp+0x50]
00007f582cdd7f70  vmovaps xmm6, [rsp+0x60]
00007f582cdd7f76  vmovaps xmm7, [rsp+0x70]
00007f582cdd7f7c  vmovaps xmm8, [rsp+0x80]
00007f582cdd7f85  vmovaps xmm9, [rsp+0x90]
00007f582cdd7f8e  vmovaps xmm10, [rsp+0xA0]
00007f582cdd7f97  vmovaps xmm11, [rsp+0xB0]
00007f582cdd7fa0  vmovaps xmm12, [rsp+0xC0]
00007f582cdd7fa9  vmovaps xmm13, [rsp+0xD0]
00007f582cdd7fb2  vmovaps xmm14, [rsp+0xE0]
00007f582cdd7fbb  add rsp, 0xF0
00007f582cdd7fc2  pop r11
00007f582cdd7fc4  pop r10
00007f582cdd7fc6  pop r9
00007f582cdd7fc8  pop r8
00007f582cdd7fca  pop rsi
00007f582cdd7fcb  pop rdi
00007f582cdd7fcc  pop rdx
00007f582cdd7fcd  pop rcx
00007f582cdd7fce  pop rax
00007f582cdd7fcf  add rsp, 0x08
00007f582cdd7fd3  jmp 0x00007F582CDD5EE6
00007f582cdd7fd8  sub rsp, 0x08
00007f582cdd7fdc  push rax
00007f582cdd7fdd  push rcx
00007f582cdd7fde  push rdx
00007f582cdd7fdf  push rdi
00007f582cdd7fe0  push rsi
00007f582cdd7fe1  push r8
00007f582cdd7fe3  push r9
00007f582cdd7fe5  push r10
00007f582cdd7fe7  push r11
00007f582cdd7fe9  sub rsp, 0xF0
00007f582cdd7ff0  vmovaps [rsp], xmm0
00007f582cdd7ff5  vmovaps [rsp+0x10], xmm2
00007f582cdd7ffb  vmovaps [rsp+0x20], xmm3
00007f582cdd8001  vmovaps [rsp+0x30], xmm4
00007f582cdd8007  vmovaps [rsp+0x40], xmm5
00007f582cdd800d  vmovaps [rsp+0x50], xmm6
00007f582cdd8013  vmovaps [rsp+0x60], xmm7
00007f582cdd8019  vmovaps [rsp+0x70], xmm8
00007f582cdd801f  vmovaps [rsp+0x80], xmm9
00007f582cdd8028  vmovaps [rsp+0x90], xmm10
00007f582cdd8031  vmovaps [rsp+0xA0], xmm11
00007f582cdd803a  vmovaps [rsp+0xB0], xmm12
00007f582cdd8043  vmovaps [rsp+0xC0], xmm13
00007f582cdd804c  vmovaps [rsp+0xD0], xmm14
00007f582cdd8055  vmovaps [rsp+0xE0], xmm15
00007f582cdd805e  sub rsp, 0x30
00007f582cdd8062  movaps [rsp], xmm1
00007f582cdd8066  movaps [rsp+0x10], xmm5
00007f582cdd806b  movaps [rsp+0x20], xmm4
00007f582cdd8070  lea rdi, [rsp]
00007f582cdd8074  mov esi, 0x00
00007f582cdd8079  mov rax, 0x653B0D9BF530
00007f582cdd8083  call rax
00007f582cdd8085  movaps xmm1, [rsp]
00007f582cdd8089  add rsp, 0x30
00007f582cdd808d  vmovaps xmm0, [rsp]
00007f582cdd8092  vmovaps xmm2, [rsp+0x10]
00007f582cdd8098  vmovaps xmm3, [rsp+0x20]
00007f582cdd809e  vmovaps xmm4, [rsp+0x30]
00007f582cdd80a4  vmovaps xmm5, [rsp+0x40]
00007f582cdd80aa  vmovaps xmm6, [rsp+0x50]
00007f582cdd80b0  vmovaps xmm7, [rsp+0x60]
00007f582cdd80b6  vmovaps xmm8, [rsp+0x70]
00007f582cdd80bc  vmovaps xmm9, [rsp+0x80]
00007f582cdd80c5  vmovaps xmm10, [rsp+0x90]
00007f582cdd80ce  vmovaps xmm11, [rsp+0xA0]
00007f582cdd80d7  vmovaps xmm12, [rsp+0xB0]
00007f582cdd80e0  vmovaps xmm13, [rsp+0xC0]
00007f582cdd80e9  vmovaps xmm14, [rsp+0xD0]
00007f582cdd80f2  vmovaps xmm15, [rsp+0xE0]
00007f582cdd80fb  add rsp, 0xF0
00007f582cdd8102  pop r11
00007f582cdd8104  pop r10
00007f582cdd8106  pop r9
00007f582cdd8108  pop r8
00007f582cdd810a  pop rsi
00007f582cdd810b  pop rdi
00007f582cdd810c  pop rdx
00007f582cdd810d  pop rcx
00007f582cdd810e  pop rax
00007f582cdd810f  add rsp, 0x08
00007f582cdd8113  jmp 0x00007F582CDD5F06
00007f582cdd8118  sub rsp, 0x08
00007f582cdd811c  push rax
00007f582cdd811d  push rcx
00007f582cdd811e  push rdx
00007f582cdd811f  push rdi
00007f582cdd8120  push rsi
00007f582cdd8121  push r8
00007f582cdd8123  push r9
00007f582cdd8125  push r10
00007f582cdd8127  push r11
00007f582cdd8129  sub rsp, 0xF0
00007f582cdd8130  vmovaps [rsp], xmm0
00007f582cdd8135  vmovaps [rsp+0x10], xmm1
00007f582cdd813b  vmovaps [rsp+0x20], xmm2
00007f582cdd8141  vmovaps [rsp+0x30], xmm3
00007f582cdd8147  vmovaps [rsp+0x40], xmm5
00007f582cdd814d  vmovaps [rsp+0x50], xmm6
00007f582cdd8153  vmovaps [rsp+0x60], xmm7
00007f582cdd8159  vmovaps [rsp+0x70], xmm8
00007f582cdd815f  vmovaps [rsp+0x80], xmm9
00007f582cdd8168  vmovaps [rsp+0x90], xmm10
00007f582cdd8171  vmovaps [rsp+0xA0], xmm11
00007f582cdd817a  vmovaps [rsp+0xB0], xmm12
00007f582cdd8183  vmovaps [rsp+0xC0], xmm13
00007f582cdd818c  vmovaps [rsp+0xD0], xmm14
00007f582cdd8195  vmovaps [rsp+0xE0], xmm15
00007f582cdd819e  sub rsp, 0x30
00007f582cdd81a2  movaps [rsp], xmm4
00007f582cdd81a6  movaps [rsp+0x10], xmm3
00007f582cdd81ab  movaps [rsp+0x20], xmm5
00007f582cdd81b0  lea rdi, [rsp]
00007f582cdd81b4  mov esi, 0x00
00007f582cdd81b9  mov rax, 0x653B0D9BF530
00007f582cdd81c3  call rax
00007f582cdd81c5  movaps xmm4, [rsp]
00007f582cdd81c9  add rsp, 0x30
00007f582cdd81cd  vmovaps xmm0, [rsp]
00007f582cdd81d2  vmovaps xmm1, [rsp+0x10]
00007f582cdd81d8  vmovaps xmm2, [rsp+0x20]
00007f582cdd81de  vmovaps xmm3, [rsp+0x30]
00007f582cdd81e4  vmovaps xmm5, [rsp+0x40]
00007f582cdd81ea  vmovaps xmm6, [rsp+0x50]
00007f582cdd81f0  vmovaps xmm7, [rsp+0x60]
00007f582cdd81f6  vmovaps xmm8, [rsp+0x70]
00007f582cdd81fc  vmovaps xmm9, [rsp+0x80]
00007f582cdd8205  vmovaps xmm10, [rsp+0x90]
00007f582cdd820e  vmovaps xmm11, [rsp+0xA0]
00007f582cdd8217  vmovaps xmm12, [rsp+0xB0]
00007f582cdd8220  vmovaps xmm13, [rsp+0xC0]
00007f582cdd8229  vmovaps xmm14, [rsp+0xD0]
00007f582cdd8232  vmovaps xmm15, [rsp+0xE0]
00007f582cdd823b  add rsp, 0xF0
00007f582cdd8242  pop r11
00007f582cdd8244  pop r10
00007f582cdd8246  pop r9
00007f582cdd8248  pop r8
00007f582cdd824a  pop rsi
00007f582cdd824b  pop rdi
00007f582cdd824c  pop rdx
00007f582cdd824d  pop rcx
00007f582cdd824e  pop rax
00007f582cdd824f  add rsp, 0x08
00007f582cdd8253  jmp 0x00007F582CDD5F54
00007f582cdd8258  call 0x00007F582CCD64F0
00007f582cdd825d  jmp 0x00007F582CDD5F61
00007f582cdd8262  sub rsp, 0x08
00007f582cdd8266  push rax
00007f582cdd8267  push rcx
00007f582cdd8268  push rdx
00007f582cdd8269  push rdi
00007f582cdd826a  push rsi
00007f582cdd826b  push r8
00007f582cdd826d  push r9
00007f582cdd826f  push r10
00007f582cdd8271  push r11
00007f582cdd8273  sub rsp, 0xF0
00007f582cdd827a  vmovaps [rsp], xmm0
00007f582cdd827f  vmovaps [rsp+0x10], xmm1
00007f582cdd8285  vmovaps [rsp+0x20], xmm2
00007f582cdd828b  vmovaps [rsp+0x30], xmm3
00007f582cdd8291  vmovaps [rsp+0x40], xmm4
00007f582cdd8297  vmovaps [rsp+0x50], xmm6
00007f582cdd829d  vmovaps [rsp+0x60], xmm7
00007f582cdd82a3  vmovaps [rsp+0x70], xmm8
00007f582cdd82a9  vmovaps [rsp+0x80], xmm9
00007f582cdd82b2  vmovaps [rsp+0x90], xmm10
00007f582cdd82bb  vmovaps [rsp+0xA0], xmm11
00007f582cdd82c4  vmovaps [rsp+0xB0], xmm12
00007f582cdd82cd  vmovaps [rsp+0xC0], xmm13
00007f582cdd82d6  vmovaps [rsp+0xD0], xmm14
00007f582cdd82df  vmovaps [rsp+0xE0], xmm15
00007f582cdd82e8  sub rsp, 0x30
00007f582cdd82ec  movaps [rsp], xmm5
00007f582cdd82f0  movaps [rsp+0x10], xmm6
00007f582cdd82f5  movaps [rsp+0x20], xmm3
00007f582cdd82fa  lea rdi, [rsp]
00007f582cdd82fe  mov esi, 0x00
00007f582cdd8303  mov rax, 0x653B0D9BF530
00007f582cdd830d  call rax
00007f582cdd830f  movaps xmm5, [rsp]
00007f582cdd8313  add rsp, 0x30
00007f582cdd8317  vmovaps xmm0, [rsp]
00007f582cdd831c  vmovaps xmm1, [rsp+0x10]
00007f582cdd8322  vmovaps xmm2, [rsp+0x20]
00007f582cdd8328  vmovaps xmm3, [rsp+0x30]
00007f582cdd832e  vmovaps xmm4, [rsp+0x40]
00007f582cdd8334  vmovaps xmm6, [rsp+0x50]
00007f582cdd833a  vmovaps xmm7, [rsp+0x60]
00007f582cdd8340  vmovaps xmm8, [rsp+0x70]
00007f582cdd8346  vmovaps xmm9, [rsp+0x80]
00007f582cdd834f  vmovaps xmm10, [rsp+0x90]
00007f582cdd8358  vmovaps xmm11, [rsp+0xA0]
00007f582cdd8361  vmovaps xmm12, [rsp+0xB0]
00007f582cdd836a  vmovaps xmm13, [rsp+0xC0]
00007f582cdd8373  vmovaps xmm14, [rsp+0xD0]
00007f582cdd837c  vmovaps xmm15, [rsp+0xE0]
00007f582cdd8385  add rsp, 0xF0
00007f582cdd838c  pop r11
00007f582cdd838e  pop r10
00007f582cdd8390  pop r9
00007f582cdd8392  pop r8
00007f582cdd8394  pop rsi
00007f582cdd8395  pop rdi
00007f582cdd8396  pop rdx
00007f582cdd8397  pop rcx
00007f582cdd8398  pop rax
00007f582cdd8399  add rsp, 0x08
00007f582cdd839d  jmp 0x00007F582CDD5F87
00007f582cdd83a2  sub rsp, 0x08
00007f582cdd83a6  push rax
00007f582cdd83a7  push rcx
00007f582cdd83a8  push rdx
00007f582cdd83a9  push rdi
00007f582cdd83aa  push rsi
00007f582cdd83ab  push r8
00007f582cdd83ad  push r9
00007f582cdd83af  push r10
00007f582cdd83b1  push r11
00007f582cdd83b3  sub rsp, 0xF0
00007f582cdd83ba  vmovaps [rsp], xmm0
00007f582cdd83bf  vmovaps [rsp+0x10], xmm1
00007f582cdd83c5  vmovaps [rsp+0x20], xmm2
00007f582cdd83cb  vmovaps [rsp+0x30], xmm3
00007f582cdd83d1  vmovaps [rsp+0x40], xmm4
00007f582cdd83d7  vmovaps [rsp+0x50], xmm5
00007f582cdd83dd  vmovaps [rsp+0x60], xmm7
00007f582cdd83e3  vmovaps [rsp+0x70], xmm8
00007f582cdd83e9  vmovaps [rsp+0x80], xmm9
00007f582cdd83f2  vmovaps [rsp+0x90], xmm10
00007f582cdd83fb  vmovaps [rsp+0xA0], xmm11
00007f582cdd8404  vmovaps [rsp+0xB0], xmm12
00007f582cdd840d  vmovaps [rsp+0xC0], xmm13
00007f582cdd8416  vmovaps [rsp+0xD0], xmm14
00007f582cdd841f  vmovaps [rsp+0xE0], xmm15
00007f582cdd8428  sub rsp, 0x30
00007f582cdd842c  movaps [rsp], xmm6
00007f582cdd8430  movaps [rsp+0x10], xmm9
00007f582cdd8436  movaps [rsp+0x20], xmm1
00007f582cdd843b  lea rdi, [rsp]
00007f582cdd843f  mov esi, 0x00
00007f582cdd8444  mov rax, 0x653B0D9BF530
00007f582cdd844e  call rax
00007f582cdd8450  movaps xmm6, [rsp]
00007f582cdd8454  add rsp, 0x30
00007f582cdd8458  vmovaps xmm0, [rsp]
00007f582cdd845d  vmovaps xmm1, [rsp+0x10]
00007f582cdd8463  vmovaps xmm2, [rsp+0x20]
00007f582cdd8469  vmovaps xmm3, [rsp+0x30]
00007f582cdd846f  vmovaps xmm4, [rsp+0x40]
00007f582cdd8475  vmovaps xmm5, [rsp+0x50]
00007f582cdd847b  vmovaps xmm7, [rsp+0x60]
00007f582cdd8481  vmovaps xmm8, [rsp+0x70]
00007f582cdd8487  vmovaps xmm9, [rsp+0x80]
00007f582cdd8490  vmovaps xmm10, [rsp+0x90]
00007f582cdd8499  vmovaps xmm11, [rsp+0xA0]
00007f582cdd84a2  vmovaps xmm12, [rsp+0xB0]
00007f582cdd84ab  vmovaps xmm13, [rsp+0xC0]
00007f582cdd84b4  vmovaps xmm14, [rsp+0xD0]
00007f582cdd84bd  vmovaps xmm15, [rsp+0xE0]
00007f582cdd84c6  add rsp, 0xF0
00007f582cdd84cd  pop r11
00007f582cdd84cf  pop r10
00007f582cdd84d1  pop r9
00007f582cdd84d3  pop r8
00007f582cdd84d5  pop rsi
00007f582cdd84d6  pop rdi
00007f582cdd84d7  pop rdx
00007f582cdd84d8  pop rcx
00007f582cdd84d9  pop rax
00007f582cdd84da  add rsp, 0x08
00007f582cdd84de  jmp 0x00007F582CDD5FAB
00007f582cdd84e3  sub rsp, 0x08
00007f582cdd84e7  push rax
00007f582cdd84e8  push rcx
00007f582cdd84e9  push rdx
00007f582cdd84ea  push rdi
00007f582cdd84eb  push rsi
00007f582cdd84ec  push r8
00007f582cdd84ee  push r9
00007f582cdd84f0  push r10
00007f582cdd84f2  push r11
00007f582cdd84f4  sub rsp, 0xF0
00007f582cdd84fb  vmovaps [rsp], xmm0
00007f582cdd8500  vmovaps [rsp+0x10], xmm1
00007f582cdd8506  vmovaps [rsp+0x20], xmm2
00007f582cdd850c  vmovaps [rsp+0x30], xmm3
00007f582cdd8512  vmovaps [rsp+0x40], xmm4
00007f582cdd8518  vmovaps [rsp+0x50], xmm5
00007f582cdd851e  vmovaps [rsp+0x60], xmm6
00007f582cdd8524  vmovaps [rsp+0x70], xmm7
00007f582cdd852a  vmovaps [rsp+0x80], xmm8
00007f582cdd8533  vmovaps [rsp+0x90], xmm10
00007f582cdd853c  vmovaps [rsp+0xA0], xmm11
00007f582cdd8545  vmovaps [rsp+0xB0], xmm12
00007f582cdd854e  vmovaps [rsp+0xC0], xmm13
00007f582cdd8557  vmovaps [rsp+0xD0], xmm14
00007f582cdd8560  vmovaps [rsp+0xE0], xmm15
00007f582cdd8569  sub rsp, 0x30
00007f582cdd856d  movaps [rsp], xmm9
00007f582cdd8572  movaps [rsp+0x10], xmm3
00007f582cdd8577  movaps [rsp+0x20], xmm1
00007f582cdd857c  lea rdi, [rsp]
00007f582cdd8580  mov esi, 0x00
00007f582cdd8585  mov rax, 0x653B0D9BF530
00007f582cdd858f  call rax
00007f582cdd8591  movaps xmm9, [rsp]
00007f582cdd8596  add rsp, 0x30
00007f582cdd859a  vmovaps xmm0, [rsp]
00007f582cdd859f  vmovaps xmm1, [rsp+0x10]
00007f582cdd85a5  vmovaps xmm2, [rsp+0x20]
00007f582cdd85ab  vmovaps xmm3, [rsp+0x30]
00007f582cdd85b1  vmovaps xmm4, [rsp+0x40]
00007f582cdd85b7  vmovaps xmm5, [rsp+0x50]
00007f582cdd85bd  vmovaps xmm6, [rsp+0x60]
00007f582cdd85c3  vmovaps xmm7, [rsp+0x70]
00007f582cdd85c9  vmovaps xmm8, [rsp+0x80]
00007f582cdd85d2  vmovaps xmm10, [rsp+0x90]
00007f582cdd85db  vmovaps xmm11, [rsp+0xA0]
00007f582cdd85e4  vmovaps xmm12, [rsp+0xB0]
00007f582cdd85ed  vmovaps xmm13, [rsp+0xC0]
00007f582cdd85f6  vmovaps xmm14, [rsp+0xD0]
00007f582cdd85ff  vmovaps xmm15, [rsp+0xE0]
00007f582cdd8608  add rsp, 0xF0
00007f582cdd860f  pop r11
00007f582cdd8611  pop r10
00007f582cdd8613  pop r9
00007f582cdd8615  pop r8
00007f582cdd8617  pop rsi
00007f582cdd8618  pop rdi
00007f582cdd8619  pop rdx
00007f582cdd861a  pop rcx
00007f582cdd861b  pop rax
00007f582cdd861c  add rsp, 0x08
00007f582cdd8620  jmp 0x00007F582CDD5FF7
00007f582cdd8625  call 0x00007F582CCD64F0
00007f582cdd862a  jmp 0x00007F582CDD6004
00007f582cdd862f  sub rsp, 0x08
00007f582cdd8633  push rax
00007f582cdd8634  push rcx
00007f582cdd8635  push rdx
00007f582cdd8636  push rdi
00007f582cdd8637  push rsi
00007f582cdd8638  push r8
00007f582cdd863a  push r9
00007f582cdd863c  push r10
00007f582cdd863e  push r11
00007f582cdd8640  sub rsp, 0xF0
00007f582cdd8647  vmovaps [rsp], xmm0
00007f582cdd864c  vmovaps [rsp+0x10], xmm1
00007f582cdd8652  vmovaps [rsp+0x20], xmm2
00007f582cdd8658  vmovaps [rsp+0x30], xmm3
00007f582cdd865e  vmovaps [rsp+0x40], xmm4
00007f582cdd8664  vmovaps [rsp+0x50], xmm5
00007f582cdd866a  vmovaps [rsp+0x60], xmm6
00007f582cdd8670  vmovaps [rsp+0x70], xmm7
00007f582cdd8676  vmovaps [rsp+0x80], xmm8
00007f582cdd867f  vmovaps [rsp+0x90], xmm9
00007f582cdd8688  vmovaps [rsp+0xA0], xmm10
00007f582cdd8691  vmovaps [rsp+0xB0], xmm11
00007f582cdd869a  vmovaps [rsp+0xC0], xmm12
00007f582cdd86a3  vmovaps [rsp+0xD0], xmm13
00007f582cdd86ac  vmovaps [rsp+0xE0], xmm14
00007f582cdd86b5  sub rsp, 0x30
00007f582cdd86b9  movaps [rsp], xmm15
00007f582cdd86be  movaps [rsp+0x10], xmm3
00007f582cdd86c3  movaps [rsp+0x20], xmm7
00007f582cdd86c8  lea rdi, [rsp]
00007f582cdd86cc  mov esi, 0x00
00007f582cdd86d1  mov rax, 0x653B0D9BF530
00007f582cdd86db  call rax
00007f582cdd86dd  movaps xmm15, [rsp]
00007f582cdd86e2  add rsp, 0x30
00007f582cdd86e6  vmovaps xmm0, [rsp]
00007f582cdd86eb  vmovaps xmm1, [rsp+0x10]
00007f582cdd86f1  vmovaps xmm2, [rsp+0x20]
00007f582cdd86f7  vmovaps xmm3, [rsp+0x30]
00007f582cdd86fd  vmovaps xmm4, [rsp+0x40]
00007f582cdd8703  vmovaps xmm5, [rsp+0x50]
00007f582cdd8709  vmovaps xmm6, [rsp+0x60]
00007f582cdd870f  vmovaps xmm7, [rsp+0x70]
00007f582cdd8715  vmovaps xmm8, [rsp+0x80]
00007f582cdd871e  vmovaps xmm9, [rsp+0x90]
00007f582cdd8727  vmovaps xmm10, [rsp+0xA0]
00007f582cdd8730  vmovaps xmm11, [rsp+0xB0]
00007f582cdd8739  vmovaps xmm12, [rsp+0xC0]
00007f582cdd8742  vmovaps xmm13, [rsp+0xD0]
00007f582cdd874b  vmovaps xmm14, [rsp+0xE0]
00007f582cdd8754  add rsp, 0xF0
00007f582cdd875b  pop r11
00007f582cdd875d  pop r10
00007f582cdd875f  pop r9
00007f582cdd8761  pop r8
00007f582cdd8763  pop rsi
00007f582cdd8764  pop rdi
00007f582cdd8765  pop rdx
00007f582cdd8766  pop rcx
00007f582cdd8767  pop rax
00007f582cdd8768  add rsp, 0x08
00007f582cdd876c  jmp 0x00007F582CDD6030
00007f582cdd8771  sub rsp, 0x08
00007f582cdd8775  push rax
00007f582cdd8776  push rcx
00007f582cdd8777  push rdx
00007f582cdd8778  push rdi
00007f582cdd8779  push rsi
00007f582cdd877a  push r8
00007f582cdd877c  push r9
00007f582cdd877e  push r10
00007f582cdd8780  push r11
00007f582cdd8782  sub rsp, 0xF0
00007f582cdd8789  vmovaps [rsp], xmm0
00007f582cdd878e  vmovaps [rsp+0x10], xmm1
00007f582cdd8794  vmovaps [rsp+0x20], xmm2
00007f582cdd879a  vmovaps [rsp+0x30], xmm4
00007f582cdd87a0  vmovaps [rsp+0x40], xmm5
00007f582cdd87a6  vmovaps [rsp+0x50], xmm6
00007f582cdd87ac  vmovaps [rsp+0x60], xmm7
00007f582cdd87b2  vmovaps [rsp+0x70], xmm8
00007f582cdd87b8  vmovaps [rsp+0x80], xmm9
00007f582cdd87c1  vmovaps [rsp+0x90], xmm10
00007f582cdd87ca  vmovaps [rsp+0xA0], xmm11
00007f582cdd87d3  vmovaps [rsp+0xB0], xmm12
00007f582cdd87dc  vmovaps [rsp+0xC0], xmm13
00007f582cdd87e5  vmovaps [rsp+0xD0], xmm14
00007f582cdd87ee  vmovaps [rsp+0xE0], xmm15
00007f582cdd87f7  sub rsp, 0x30
00007f582cdd87fb  movaps [rsp], xmm3
00007f582cdd87ff  movaps [rsp+0x10], xmm1
00007f582cdd8804  movaps [rsp+0x20], xmm15
00007f582cdd880a  lea rdi, [rsp]
00007f582cdd880e  mov esi, 0x00
00007f582cdd8813  mov rax, 0x653B0D9BF530
00007f582cdd881d  call rax
00007f582cdd881f  movaps xmm3, [rsp]
00007f582cdd8823  add rsp, 0x30
00007f582cdd8827  vmovaps xmm0, [rsp]
00007f582cdd882c  vmovaps xmm1, [rsp+0x10]
00007f582cdd8832  vmovaps xmm2, [rsp+0x20]
00007f582cdd8838  vmovaps xmm4, [rsp+0x30]
00007f582cdd883e  vmovaps xmm5, [rsp+0x40]
00007f582cdd8844  vmovaps xmm6, [rsp+0x50]
00007f582cdd884a  vmovaps xmm7, [rsp+0x60]
00007f582cdd8850  vmovaps xmm8, [rsp+0x70]
00007f582cdd8856  vmovaps xmm9, [rsp+0x80]
00007f582cdd885f  vmovaps xmm10, [rsp+0x90]
00007f582cdd8868  vmovaps xmm11, [rsp+0xA0]
00007f582cdd8871  vmovaps xmm12, [rsp+0xB0]
00007f582cdd887a  vmovaps xmm13, [rsp+0xC0]
00007f582cdd8883  vmovaps xmm14, [rsp+0xD0]
00007f582cdd888c  vmovaps xmm15, [rsp+0xE0]
00007f582cdd8895  add rsp, 0xF0
00007f582cdd889c  pop r11
00007f582cdd889e  pop r10
00007f582cdd88a0  pop r9
00007f582cdd88a2  pop r8
00007f582cdd88a4  pop rsi
00007f582cdd88a5  pop rdi
00007f582cdd88a6  pop rdx
00007f582cdd88a7  pop rcx
00007f582cdd88a8  pop rax
00007f582cdd88a9  add rsp, 0x08
00007f582cdd88ad  jmp 0x00007F582CDD60BF
00007f582cdd88b2  call 0x00007F582CCD64F0
00007f582cdd88b7  jmp 0x00007F582CDD60C9
00007f582cdd88bc  sub rsp, 0x08
00007f582cdd88c0  push rax
00007f582cdd88c1  push rcx
00007f582cdd88c2  push rdx
00007f582cdd88c3  push rdi
00007f582cdd88c4  push rsi
00007f582cdd88c5  push r8
00007f582cdd88c7  push r9
00007f582cdd88c9  push r10
00007f582cdd88cb  push r11
00007f582cdd88cd  sub rsp, 0xF0
00007f582cdd88d4  vmovaps [rsp], xmm0
00007f582cdd88d9  vmovaps [rsp+0x10], xmm1
00007f582cdd88df  vmovaps [rsp+0x20], xmm2
00007f582cdd88e5  vmovaps [rsp+0x30], xmm3
00007f582cdd88eb  vmovaps [rsp+0x40], xmm4
00007f582cdd88f1  vmovaps [rsp+0x50], xmm5
00007f582cdd88f7  vmovaps [rsp+0x60], xmm6
00007f582cdd88fd  vmovaps [rsp+0x70], xmm7
00007f582cdd8903  vmovaps [rsp+0x80], xmm8
00007f582cdd890c  vmovaps [rsp+0x90], xmm9
00007f582cdd8915  vmovaps [rsp+0xA0], xmm10
00007f582cdd891e  vmovaps [rsp+0xB0], xmm11
00007f582cdd8927  vmovaps [rsp+0xC0], xmm12
00007f582cdd8930  vmovaps [rsp+0xD0], xmm13
00007f582cdd8939  vmovaps [rsp+0xE0], xmm14
00007f582cdd8942  sub rsp, 0x30
00007f582cdd8946  movaps [rsp], xmm15
00007f582cdd894b  movaps [rsp+0x10], xmm14
00007f582cdd8951  movaps [rsp+0x20], xmm4
00007f582cdd8956  lea rdi, [rsp]
00007f582cdd895a  mov esi, 0x00
00007f582cdd895f  mov rax, 0x653B0D9BF530
00007f582cdd8969  call rax
00007f582cdd896b  movaps xmm15, [rsp]
00007f582cdd8970  add rsp, 0x30
00007f582cdd8974  vmovaps xmm0, [rsp]
00007f582cdd8979  vmovaps xmm1, [rsp+0x10]
00007f582cdd897f  vmovaps xmm2, [rsp+0x20]
00007f582cdd8985  vmovaps xmm3, [rsp+0x30]
00007f582cdd898b  vmovaps xmm4, [rsp+0x40]
00007f582cdd8991  vmovaps xmm5, [rsp+0x50]
00007f582cdd8997  vmovaps xmm6, [rsp+0x60]
00007f582cdd899d  vmovaps xmm7, [rsp+0x70]
00007f582cdd89a3  vmovaps xmm8, [rsp+0x80]
00007f582cdd89ac  vmovaps xmm9, [rsp+0x90]
00007f582cdd89b5  vmovaps xmm10, [rsp+0xA0]
00007f582cdd89be  vmovaps xmm11, [rsp+0xB0]
00007f582cdd89c7  vmovaps xmm12, [rsp+0xC0]
00007f582cdd89d0  vmovaps xmm13, [rsp+0xD0]
00007f582cdd89d9  vmovaps xmm14, [rsp+0xE0]
00007f582cdd89e2  add rsp, 0xF0
00007f582cdd89e9  pop r11
00007f582cdd89eb  pop r10
00007f582cdd89ed  pop r9
00007f582cdd89ef  pop r8
00007f582cdd89f1  pop rsi
00007f582cdd89f2  pop rdi
00007f582cdd89f3  pop rdx
00007f582cdd89f4  pop rcx
00007f582cdd89f5  pop rax
00007f582cdd89f6  add rsp, 0x08
00007f582cdd89fa  jmp 0x00007F582CDD60F7
00007f582cdd89ff  sub rsp, 0x08
00007f582cdd8a03  push rax
00007f582cdd8a04  push rcx
00007f582cdd8a05  push rdx
00007f582cdd8a06  push rdi
00007f582cdd8a07  push rsi
00007f582cdd8a08  push r8
00007f582cdd8a0a  push r9
00007f582cdd8a0c  push r10
00007f582cdd8a0e  push r11
00007f582cdd8a10  sub rsp, 0xF0
00007f582cdd8a17  vmovaps [rsp], xmm0
00007f582cdd8a1c  vmovaps [rsp+0x10], xmm1
00007f582cdd8a22  vmovaps [rsp+0x20], xmm2
00007f582cdd8a28  vmovaps [rsp+0x30], xmm3
00007f582cdd8a2e  vmovaps [rsp+0x40], xmm4
00007f582cdd8a34  vmovaps [rsp+0x50], xmm5
00007f582cdd8a3a  vmovaps [rsp+0x60], xmm6
00007f582cdd8a40  vmovaps [rsp+0x70], xmm7
00007f582cdd8a46  vmovaps [rsp+0x80], xmm8
00007f582cdd8a4f  vmovaps [rsp+0x90], xmm9
00007f582cdd8a58  vmovaps [rsp+0xA0], xmm10
00007f582cdd8a61  vmovaps [rsp+0xB0], xmm11
00007f582cdd8a6a  vmovaps [rsp+0xC0], xmm12
00007f582cdd8a73  vmovaps [rsp+0xD0], xmm13
00007f582cdd8a7c  vmovaps [rsp+0xE0], xmm15
00007f582cdd8a85  sub rsp, 0x30
00007f582cdd8a89  movaps [rsp], xmm14
00007f582cdd8a8e  movaps [rsp+0x10], xmm2
00007f582cdd8a93  movaps [rsp+0x20], xmm1
00007f582cdd8a98  lea rdi, [rsp]
00007f582cdd8a9c  mov esi, 0x00
00007f582cdd8aa1  mov rax, 0x653B0D9BF530
00007f582cdd8aab  call rax
00007f582cdd8aad  movaps xmm14, [rsp]
00007f582cdd8ab2  add rsp, 0x30
00007f582cdd8ab6  vmovaps xmm0, [rsp]
00007f582cdd8abb  vmovaps xmm1, [rsp+0x10]
00007f582cdd8ac1  vmovaps xmm2, [rsp+0x20]
00007f582cdd8ac7  vmovaps xmm3, [rsp+0x30]
00007f582cdd8acd  vmovaps xmm4, [rsp+0x40]
00007f582cdd8ad3  vmovaps xmm5, [rsp+0x50]
00007f582cdd8ad9  vmovaps xmm6, [rsp+0x60]
00007f582cdd8adf  vmovaps xmm7, [rsp+0x70]
00007f582cdd8ae5  vmovaps xmm8, [rsp+0x80]
00007f582cdd8aee  vmovaps xmm9, [rsp+0x90]
00007f582cdd8af7  vmovaps xmm10, [rsp+0xA0]
00007f582cdd8b00  vmovaps xmm11, [rsp+0xB0]
00007f582cdd8b09  vmovaps xmm12, [rsp+0xC0]
00007f582cdd8b12  vmovaps xmm13, [rsp+0xD0]
00007f582cdd8b1b  vmovaps xmm15, [rsp+0xE0]
00007f582cdd8b24  add rsp, 0xF0
00007f582cdd8b2b  pop r11
00007f582cdd8b2d  pop r10
00007f582cdd8b2f  pop r9
00007f582cdd8b31  pop r8
00007f582cdd8b33  pop rsi
00007f582cdd8b34  pop rdi
00007f582cdd8b35  pop rdx
00007f582cdd8b36  pop rcx
00007f582cdd8b37  pop rax
00007f582cdd8b38  add rsp, 0x08
00007f582cdd8b3c  jmp 0x00007F582CDD611D
00007f582cdd8b41  sub rsp, 0x08
00007f582cdd8b45  push rax
00007f582cdd8b46  push rcx
00007f582cdd8b47  push rdx
00007f582cdd8b48  push rdi
00007f582cdd8b49  push rsi
00007f582cdd8b4a  push r8
00007f582cdd8b4c  push r9
00007f582cdd8b4e  push r10
00007f582cdd8b50  push r11
00007f582cdd8b52  sub rsp, 0xF0
00007f582cdd8b59  vmovaps [rsp], xmm0
00007f582cdd8b5e  vmovaps [rsp+0x10], xmm2
00007f582cdd8b64  vmovaps [rsp+0x20], xmm3
00007f582cdd8b6a  vmovaps [rsp+0x30], xmm4
00007f582cdd8b70  vmovaps [rsp+0x40], xmm5
00007f582cdd8b76  vmovaps [rsp+0x50], xmm6
00007f582cdd8b7c  vmovaps [rsp+0x60], xmm7
00007f582cdd8b82  vmovaps [rsp+0x70], xmm8
00007f582cdd8b88  vmovaps [rsp+0x80], xmm9
00007f582cdd8b91  vmovaps [rsp+0x90], xmm10
00007f582cdd8b9a  vmovaps [rsp+0xA0], xmm11
00007f582cdd8ba3  vmovaps [rsp+0xB0], xmm12
00007f582cdd8bac  vmovaps [rsp+0xC0], xmm13
00007f582cdd8bb5  vmovaps [rsp+0xD0], xmm14
00007f582cdd8bbe  vmovaps [rsp+0xE0], xmm15
00007f582cdd8bc7  sub rsp, 0x30
00007f582cdd8bcb  movaps [rsp], xmm1
00007f582cdd8bcf  movaps [rsp+0x10], xmm4
00007f582cdd8bd4  movaps [rsp+0x20], xmm9
00007f582cdd8bda  lea rdi, [rsp]
00007f582cdd8bde  mov esi, 0x00
00007f582cdd8be3  mov rax, 0x653B0D9BF530
00007f582cdd8bed  call rax
00007f582cdd8bef  movaps xmm1, [rsp]
00007f582cdd8bf3  add rsp, 0x30
00007f582cdd8bf7  vmovaps xmm0, [rsp]
00007f582cdd8bfc  vmovaps xmm2, [rsp+0x10]
00007f582cdd8c02  vmovaps xmm3, [rsp+0x20]
00007f582cdd8c08  vmovaps xmm4, [rsp+0x30]
00007f582cdd8c0e  vmovaps xmm5, [rsp+0x40]
00007f582cdd8c14  vmovaps xmm6, [rsp+0x50]
00007f582cdd8c1a  vmovaps xmm7, [rsp+0x60]
00007f582cdd8c20  vmovaps xmm8, [rsp+0x70]
00007f582cdd8c26  vmovaps xmm9, [rsp+0x80]
00007f582cdd8c2f  vmovaps xmm10, [rsp+0x90]
00007f582cdd8c38  vmovaps xmm11, [rsp+0xA0]
00007f582cdd8c41  vmovaps xmm12, [rsp+0xB0]
00007f582cdd8c4a  vmovaps xmm13, [rsp+0xC0]
00007f582cdd8c53  vmovaps xmm14, [rsp+0xD0]
00007f582cdd8c5c  vmovaps xmm15, [rsp+0xE0]
00007f582cdd8c65  add rsp, 0xF0
00007f582cdd8c6c  pop r11
00007f582cdd8c6e  pop r10
00007f582cdd8c70  pop r9
00007f582cdd8c72  pop r8
00007f582cdd8c74  pop rsi
00007f582cdd8c75  pop rdi
00007f582cdd8c76  pop rdx
00007f582cdd8c77  pop rcx
00007f582cdd8c78  pop rax
00007f582cdd8c79  add rsp, 0x08
00007f582cdd8c7d  jmp 0x00007F582CDD613B
00007f582cdd8c82  sub rsp, 0x08
00007f582cdd8c86  push rax
00007f582cdd8c87  push rcx
00007f582cdd8c88  push rdx
00007f582cdd8c89  push rdi
00007f582cdd8c8a  push rsi
00007f582cdd8c8b  push r8
00007f582cdd8c8d  push r9
00007f582cdd8c8f  push r10
00007f582cdd8c91  push r11
00007f582cdd8c93  sub rsp, 0xF0
00007f582cdd8c9a  vmovaps [rsp], xmm0
00007f582cdd8c9f  vmovaps [rsp+0x10], xmm1
00007f582cdd8ca5  vmovaps [rsp+0x20], xmm2
00007f582cdd8cab  vmovaps [rsp+0x30], xmm3
00007f582cdd8cb1  vmovaps [rsp+0x40], xmm5
00007f582cdd8cb7  vmovaps [rsp+0x50], xmm6
00007f582cdd8cbd  vmovaps [rsp+0x60], xmm7
00007f582cdd8cc3  vmovaps [rsp+0x70], xmm8
00007f582cdd8cc9  vmovaps [rsp+0x80], xmm9
00007f582cdd8cd2  vmovaps [rsp+0x90], xmm10
00007f582cdd8cdb  vmovaps [rsp+0xA0], xmm11
00007f582cdd8ce4  vmovaps [rsp+0xB0], xmm12
00007f582cdd8ced  vmovaps [rsp+0xC0], xmm13
00007f582cdd8cf6  vmovaps [rsp+0xD0], xmm14
00007f582cdd8cff  vmovaps [rsp+0xE0], xmm15
00007f582cdd8d08  sub rsp, 0x30
00007f582cdd8d0c  movaps [rsp], xmm4
00007f582cdd8d10  movaps [rsp+0x10], xmm2
00007f582cdd8d15  movaps [rsp+0x20], xmm9
00007f582cdd8d1b  lea rdi, [rsp]
00007f582cdd8d1f  mov esi, 0x00
00007f582cdd8d24  mov rax, 0x653B0D9BF530
00007f582cdd8d2e  call rax
00007f582cdd8d30  movaps xmm4, [rsp]
00007f582cdd8d34  add rsp, 0x30
00007f582cdd8d38  vmovaps xmm0, [rsp]
00007f582cdd8d3d  vmovaps xmm1, [rsp+0x10]
00007f582cdd8d43  vmovaps xmm2, [rsp+0x20]
00007f582cdd8d49  vmovaps xmm3, [rsp+0x30]
00007f582cdd8d4f  vmovaps xmm5, [rsp+0x40]
00007f582cdd8d55  vmovaps xmm6, [rsp+0x50]
00007f582cdd8d5b  vmovaps xmm7, [rsp+0x60]
00007f582cdd8d61  vmovaps xmm8, [rsp+0x70]
00007f582cdd8d67  vmovaps xmm9, [rsp+0x80]
00007f582cdd8d70  vmovaps xmm10, [rsp+0x90]
00007f582cdd8d79  vmovaps xmm11, [rsp+0xA0]
00007f582cdd8d82  vmovaps xmm12, [rsp+0xB0]
00007f582cdd8d8b  vmovaps xmm13, [rsp+0xC0]
00007f582cdd8d94  vmovaps xmm14, [rsp+0xD0]
00007f582cdd8d9d  vmovaps xmm15, [rsp+0xE0]
00007f582cdd8da6  add rsp, 0xF0
00007f582cdd8dad  pop r11
00007f582cdd8daf  pop r10
00007f582cdd8db1  pop r9
00007f582cdd8db3  pop r8
00007f582cdd8db5  pop rsi
00007f582cdd8db6  pop rdi
00007f582cdd8db7  pop rdx
00007f582cdd8db8  pop rcx
00007f582cdd8db9  pop rax
00007f582cdd8dba  add rsp, 0x08
00007f582cdd8dbe  jmp 0x00007F582CDD616B
00007f582cdd8dc3  sub rsp, 0x08
00007f582cdd8dc7  push rax
00007f582cdd8dc8  push rcx
00007f582cdd8dc9  push rdx
00007f582cdd8dca  push rdi
00007f582cdd8dcb  push rsi
00007f582cdd8dcc  push r8
00007f582cdd8dce  push r9
00007f582cdd8dd0  push r10
00007f582cdd8dd2  push r11
00007f582cdd8dd4  sub rsp, 0xF0
00007f582cdd8ddb  vmovaps [rsp], xmm0
00007f582cdd8de0  vmovaps [rsp+0x10], xmm1
00007f582cdd8de6  vmovaps [rsp+0x20], xmm2
00007f582cdd8dec  vmovaps [rsp+0x30], xmm3
00007f582cdd8df2  vmovaps [rsp+0x40], xmm4
00007f582cdd8df8  vmovaps [rsp+0x50], xmm5
00007f582cdd8dfe  vmovaps [rsp+0x60], xmm6
00007f582cdd8e04  vmovaps [rsp+0x70], xmm7
00007f582cdd8e0a  vmovaps [rsp+0x80], xmm8
00007f582cdd8e13  vmovaps [rsp+0x90], xmm10
00007f582cdd8e1c  vmovaps [rsp+0xA0], xmm11
00007f582cdd8e25  vmovaps [rsp+0xB0], xmm12
00007f582cdd8e2e  vmovaps [rsp+0xC0], xmm13
00007f582cdd8e37  vmovaps [rsp+0xD0], xmm14
00007f582cdd8e40  vmovaps [rsp+0xE0], xmm15
00007f582cdd8e49  sub rsp, 0x30
00007f582cdd8e4d  movaps [rsp], xmm9
00007f582cdd8e52  movaps [rsp+0x10], xmm2
00007f582cdd8e57  movaps [rsp+0x20], xmm1
00007f582cdd8e5c  lea rdi, [rsp]
00007f582cdd8e60  mov esi, 0x00
00007f582cdd8e65  mov rax, 0x653B0D9BF530
00007f582cdd8e6f  call rax
00007f582cdd8e71  movaps xmm9, [rsp]
00007f582cdd8e76  add rsp, 0x30
00007f582cdd8e7a  vmovaps xmm0, [rsp]
00007f582cdd8e7f  vmovaps xmm1, [rsp+0x10]
00007f582cdd8e85  vmovaps xmm2, [rsp+0x20]
00007f582cdd8e8b  vmovaps xmm3, [rsp+0x30]
00007f582cdd8e91  vmovaps xmm4, [rsp+0x40]
00007f582cdd8e97  vmovaps xmm5, [rsp+0x50]
00007f582cdd8e9d  vmovaps xmm6, [rsp+0x60]
00007f582cdd8ea3  vmovaps xmm7, [rsp+0x70]
00007f582cdd8ea9  vmovaps xmm8, [rsp+0x80]
00007f582cdd8eb2  vmovaps xmm10, [rsp+0x90]
00007f582cdd8ebb  vmovaps xmm11, [rsp+0xA0]
00007f582cdd8ec4  vmovaps xmm12, [rsp+0xB0]
00007f582cdd8ecd  vmovaps xmm13, [rsp+0xC0]
00007f582cdd8ed6  vmovaps xmm14, [rsp+0xD0]
00007f582cdd8edf  vmovaps xmm15, [rsp+0xE0]
00007f582cdd8ee8  add rsp, 0xF0
00007f582cdd8eef  pop r11
00007f582cdd8ef1  pop r10
00007f582cdd8ef3  pop r9
00007f582cdd8ef5  pop r8
00007f582cdd8ef7  pop rsi
00007f582cdd8ef8  pop rdi
00007f582cdd8ef9  pop rdx
00007f582cdd8efa  pop rcx
00007f582cdd8efb  pop rax
00007f582cdd8efc  add rsp, 0x08
00007f582cdd8f00  jmp 0x00007F582CDD61A1
00007f582cdd8f05  sub rsp, 0x08
00007f582cdd8f09  push rax
00007f582cdd8f0a  push rcx
00007f582cdd8f0b  push rdx
00007f582cdd8f0c  push rdi
00007f582cdd8f0d  push rsi
00007f582cdd8f0e  push r8
00007f582cdd8f10  push r9
00007f582cdd8f12  push r10
00007f582cdd8f14  push r11
00007f582cdd8f16  sub rsp, 0xF0
00007f582cdd8f1d  vmovaps [rsp], xmm0
00007f582cdd8f22  vmovaps [rsp+0x10], xmm2
00007f582cdd8f28  vmovaps [rsp+0x20], xmm3
00007f582cdd8f2e  vmovaps [rsp+0x30], xmm4
00007f582cdd8f34  vmovaps [rsp+0x40], xmm5
00007f582cdd8f3a  vmovaps [rsp+0x50], xmm6
00007f582cdd8f40  vmovaps [rsp+0x60], xmm7
00007f582cdd8f46  vmovaps [rsp+0x70], xmm8
00007f582cdd8f4c  vmovaps [rsp+0x80], xmm9
00007f582cdd8f55  vmovaps [rsp+0x90], xmm10
00007f582cdd8f5e  vmovaps [rsp+0xA0], xmm11
00007f582cdd8f67  vmovaps [rsp+0xB0], xmm12
00007f582cdd8f70  vmovaps [rsp+0xC0], xmm13
00007f582cdd8f79  vmovaps [rsp+0xD0], xmm14
00007f582cdd8f82  vmovaps [rsp+0xE0], xmm15
00007f582cdd8f8b  sub rsp, 0x30
00007f582cdd8f8f  movaps [rsp], xmm1
00007f582cdd8f93  movaps [rsp+0x10], xmm15
00007f582cdd8f99  movaps [rsp+0x20], xmm6
00007f582cdd8f9e  lea rdi, [rsp]
00007f582cdd8fa2  mov esi, 0x00
00007f582cdd8fa7  mov rax, 0x653B0D9BF530
00007f582cdd8fb1  call rax
00007f582cdd8fb3  movaps xmm1, [rsp]
00007f582cdd8fb7  add rsp, 0x30
00007f582cdd8fbb  vmovaps xmm0, [rsp]
00007f582cdd8fc0  vmovaps xmm2, [rsp+0x10]
00007f582cdd8fc6  vmovaps xmm3, [rsp+0x20]
00007f582cdd8fcc  vmovaps xmm4, [rsp+0x30]
00007f582cdd8fd2  vmovaps xmm5, [rsp+0x40]
00007f582cdd8fd8  vmovaps xmm6, [rsp+0x50]
00007f582cdd8fde  vmovaps xmm7, [rsp+0x60]
00007f582cdd8fe4  vmovaps xmm8, [rsp+0x70]
00007f582cdd8fea  vmovaps xmm9, [rsp+0x80]
00007f582cdd8ff3  vmovaps xmm10, [rsp+0x90]
00007f582cdd8ffc  vmovaps xmm11, [rsp+0xA0]
00007f582cdd9005  vmovaps xmm12, [rsp+0xB0]
00007f582cdd900e  vmovaps xmm13, [rsp+0xC0]
00007f582cdd9017  vmovaps xmm14, [rsp+0xD0]
00007f582cdd9020  vmovaps xmm15, [rsp+0xE0]
00007f582cdd9029  add rsp, 0xF0
00007f582cdd9030  pop r11
00007f582cdd9032  pop r10
00007f582cdd9034  pop r9
00007f582cdd9036  pop r8
00007f582cdd9038  pop rsi
00007f582cdd9039  pop rdi
00007f582cdd903a  pop rdx
00007f582cdd903b  pop rcx
00007f582cdd903c  pop rax
00007f582cdd903d  add rsp, 0x08
00007f582cdd9041  jmp 0x00007F582CDD61C2
00007f582cdd9046  sub rsp, 0x08
00007f582cdd904a  push rax
00007f582cdd904b  push rcx
00007f582cdd904c  push rdx
00007f582cdd904d  push rdi
00007f582cdd904e  push rsi
00007f582cdd904f  push r8
00007f582cdd9051  push r9
00007f582cdd9053  push r10
00007f582cdd9055  push r11
00007f582cdd9057  sub rsp, 0xF0
00007f582cdd905e  vmovaps [rsp], xmm0
00007f582cdd9063  vmovaps [rsp+0x10], xmm1
00007f582cdd9069  vmovaps [rsp+0x20], xmm2
00007f582cdd906f  vmovaps [rsp+0x30], xmm3
00007f582cdd9075  vmovaps [rsp+0x40], xmm4
00007f582cdd907b  vmovaps [rsp+0x50], xmm5
00007f582cdd9081  vmovaps [rsp+0x60], xmm6
00007f582cdd9087  vmovaps [rsp+0x70], xmm7
00007f582cdd908d  vmovaps [rsp+0x80], xmm8
00007f582cdd9096  vmovaps [rsp+0x90], xmm9
00007f582cdd909f  vmovaps [rsp+0xA0], xmm10
00007f582cdd90a8  vmovaps [rsp+0xB0], xmm11
00007f582cdd90b1  vmovaps [rsp+0xC0], xmm12
00007f582cdd90ba  vmovaps [rsp+0xD0], xmm13
00007f582cdd90c3  vmovaps [rsp+0xE0], xmm14
00007f582cdd90cc  sub rsp, 0x30
00007f582cdd90d0  movaps [rsp], xmm15
00007f582cdd90d5  movaps [rsp+0x10], xmm5
00007f582cdd90da  movaps [rsp+0x20], xmm3
00007f582cdd90df  lea rdi, [rsp]
00007f582cdd90e3  mov esi, 0x00
00007f582cdd90e8  mov rax, 0x653B0D9BF530
00007f582cdd90f2  call rax
00007f582cdd90f4  movaps xmm15, [rsp]
00007f582cdd90f9  add rsp, 0x30
00007f582cdd90fd  vmovaps xmm0, [rsp]
00007f582cdd9102  vmovaps xmm1, [rsp+0x10]
00007f582cdd9108  vmovaps xmm2, [rsp+0x20]
00007f582cdd910e  vmovaps xmm3, [rsp+0x30]
00007f582cdd9114  vmovaps xmm4, [rsp+0x40]
00007f582cdd911a  vmovaps xmm5, [rsp+0x50]
00007f582cdd9120  vmovaps xmm6, [rsp+0x60]
00007f582cdd9126  vmovaps xmm7, [rsp+0x70]
00007f582cdd912c  vmovaps xmm8, [rsp+0x80]
00007f582cdd9135  vmovaps xmm9, [rsp+0x90]
00007f582cdd913e  vmovaps xmm10, [rsp+0xA0]
00007f582cdd9147  vmovaps xmm11, [rsp+0xB0]
00007f582cdd9150  vmovaps xmm12, [rsp+0xC0]
00007f582cdd9159  vmovaps xmm13, [rsp+0xD0]
00007f582cdd9162  vmovaps xmm14, [rsp+0xE0]
00007f582cdd916b  add rsp, 0xF0
00007f582cdd9172  pop r11
00007f582cdd9174  pop r10
00007f582cdd9176  pop r9
00007f582cdd9178  pop r8
00007f582cdd917a  pop rsi
00007f582cdd917b  pop rdi
00007f582cdd917c  pop rdx
00007f582cdd917d  pop rcx
00007f582cdd917e  pop rax
00007f582cdd917f  add rsp, 0x08
00007f582cdd9183  jmp 0x00007F582CDD61DC
00007f582cdd9188  sub rsp, 0x08
00007f582cdd918c  push rax
00007f582cdd918d  push rcx
00007f582cdd918e  push rdx
00007f582cdd918f  push rdi
00007f582cdd9190  push rsi
00007f582cdd9191  push r8
00007f582cdd9193  push r9
00007f582cdd9195  push r10
00007f582cdd9197  push r11
00007f582cdd9199  sub rsp, 0xF0
00007f582cdd91a0  vmovaps [rsp], xmm0
00007f582cdd91a5  vmovaps [rsp+0x10], xmm1
00007f582cdd91ab  vmovaps [rsp+0x20], xmm2
00007f582cdd91b1  vmovaps [rsp+0x30], xmm3
00007f582cdd91b7  vmovaps [rsp+0x40], xmm4
00007f582cdd91bd  vmovaps [rsp+0x50], xmm6
00007f582cdd91c3  vmovaps [rsp+0x60], xmm7
00007f582cdd91c9  vmovaps [rsp+0x70], xmm8
00007f582cdd91cf  vmovaps [rsp+0x80], xmm9
00007f582cdd91d8  vmovaps [rsp+0x90], xmm10
00007f582cdd91e1  vmovaps [rsp+0xA0], xmm11
00007f582cdd91ea  vmovaps [rsp+0xB0], xmm12
00007f582cdd91f3  vmovaps [rsp+0xC0], xmm13
00007f582cdd91fc  vmovaps [rsp+0xD0], xmm14
00007f582cdd9205  vmovaps [rsp+0xE0], xmm15
00007f582cdd920e  sub rsp, 0x30
00007f582cdd9212  movaps [rsp], xmm5
00007f582cdd9216  movaps [rsp+0x10], xmm8
00007f582cdd921c  movaps [rsp+0x20], xmm6
00007f582cdd9221  lea rdi, [rsp]
00007f582cdd9225  mov esi, 0x00
00007f582cdd922a  mov rax, 0x653B0D9BF530
00007f582cdd9234  call rax
00007f582cdd9236  movaps xmm5, [rsp]
00007f582cdd923a  add rsp, 0x30
00007f582cdd923e  vmovaps xmm0, [rsp]
00007f582cdd9243  vmovaps xmm1, [rsp+0x10]
00007f582cdd9249  vmovaps xmm2, [rsp+0x20]
00007f582cdd924f  vmovaps xmm3, [rsp+0x30]
00007f582cdd9255  vmovaps xmm4, [rsp+0x40]
00007f582cdd925b  vmovaps xmm6, [rsp+0x50]
00007f582cdd9261  vmovaps xmm7, [rsp+0x60]
00007f582cdd9267  vmovaps xmm8, [rsp+0x70]
00007f582cdd926d  vmovaps xmm9, [rsp+0x80]
00007f582cdd9276  vmovaps xmm10, [rsp+0x90]
00007f582cdd927f  vmovaps xmm11, [rsp+0xA0]
00007f582cdd9288  vmovaps xmm12, [rsp+0xB0]
00007f582cdd9291  vmovaps xmm13, [rsp+0xC0]
00007f582cdd929a  vmovaps xmm14, [rsp+0xD0]
00007f582cdd92a3  vmovaps xmm15, [rsp+0xE0]
00007f582cdd92ac  add rsp, 0xF0
00007f582cdd92b3  pop r11
00007f582cdd92b5  pop r10
00007f582cdd92b7  pop r9
00007f582cdd92b9  pop r8
00007f582cdd92bb  pop rsi
00007f582cdd92bc  pop rdi
00007f582cdd92bd  pop rdx
00007f582cdd92be  pop rcx
00007f582cdd92bf  pop rax
00007f582cdd92c0  add rsp, 0x08
00007f582cdd92c4  jmp 0x00007F582CDD6200
00007f582cdd92c9  sub rsp, 0x08
00007f582cdd92cd  push rax
00007f582cdd92ce  push rcx
00007f582cdd92cf  push rdx
00007f582cdd92d0  push rdi
00007f582cdd92d1  push rsi
00007f582cdd92d2  push r8
00007f582cdd92d4  push r9
00007f582cdd92d6  push r10
00007f582cdd92d8  push r11
00007f582cdd92da  sub rsp, 0xF0
00007f582cdd92e1  vmovaps [rsp], xmm0
00007f582cdd92e6  vmovaps [rsp+0x10], xmm1
00007f582cdd92ec  vmovaps [rsp+0x20], xmm2
00007f582cdd92f2  vmovaps [rsp+0x30], xmm3
00007f582cdd92f8  vmovaps [rsp+0x40], xmm4
00007f582cdd92fe  vmovaps [rsp+0x50], xmm5
00007f582cdd9304  vmovaps [rsp+0x60], xmm7
00007f582cdd930a  vmovaps [rsp+0x70], xmm8
00007f582cdd9310  vmovaps [rsp+0x80], xmm9
00007f582cdd9319  vmovaps [rsp+0x90], xmm10
00007f582cdd9322  vmovaps [rsp+0xA0], xmm11
00007f582cdd932b  vmovaps [rsp+0xB0], xmm12
00007f582cdd9334  vmovaps [rsp+0xC0], xmm13
00007f582cdd933d  vmovaps [rsp+0xD0], xmm14
00007f582cdd9346  vmovaps [rsp+0xE0], xmm15
00007f582cdd934f  sub rsp, 0x30
00007f582cdd9353  movaps [rsp], xmm6
00007f582cdd9357  movaps [rsp+0x10], xmm10
00007f582cdd935d  movaps [rsp+0x20], xmm8
00007f582cdd9363  lea rdi, [rsp]
00007f582cdd9367  mov esi, 0x00
00007f582cdd936c  mov rax, 0x653B0D9BF530
00007f582cdd9376  call rax
00007f582cdd9378  movaps xmm6, [rsp]
00007f582cdd937c  add rsp, 0x30
00007f582cdd9380  vmovaps xmm0, [rsp]
00007f582cdd9385  vmovaps xmm1, [rsp+0x10]
00007f582cdd938b  vmovaps xmm2, [rsp+0x20]
00007f582cdd9391  vmovaps xmm3, [rsp+0x30]
00007f582cdd9397  vmovaps xmm4, [rsp+0x40]
00007f582cdd939d  vmovaps xmm5, [rsp+0x50]
00007f582cdd93a3  vmovaps xmm7, [rsp+0x60]
00007f582cdd93a9  vmovaps xmm8, [rsp+0x70]
00007f582cdd93af  vmovaps xmm9, [rsp+0x80]
00007f582cdd93b8  vmovaps xmm10, [rsp+0x90]
00007f582cdd93c1  vmovaps xmm11, [rsp+0xA0]
00007f582cdd93ca  vmovaps xmm12, [rsp+0xB0]
00007f582cdd93d3  vmovaps xmm13, [rsp+0xC0]
00007f582cdd93dc  vmovaps xmm14, [rsp+0xD0]
00007f582cdd93e5  vmovaps xmm15, [rsp+0xE0]
00007f582cdd93ee  add rsp, 0xF0
00007f582cdd93f5  pop r11
00007f582cdd93f7  pop r10
00007f582cdd93f9  pop r9
00007f582cdd93fb  pop r8
00007f582cdd93fd  pop rsi
00007f582cdd93fe  pop rdi
00007f582cdd93ff  pop rdx
00007f582cdd9400  pop rcx
00007f582cdd9401  pop rax
00007f582cdd9402  add rsp, 0x08
00007f582cdd9406  jmp 0x00007F582CDD6225
00007f582cdd940b  sub rsp, 0x08
00007f582cdd940f  push rax
00007f582cdd9410  push rcx
00007f582cdd9411  push rdx
00007f582cdd9412  push rdi
00007f582cdd9413  push rsi
00007f582cdd9414  push r8
00007f582cdd9416  push r9
00007f582cdd9418  push r10
00007f582cdd941a  push r11
00007f582cdd941c  sub rsp, 0xF0
00007f582cdd9423  vmovaps [rsp], xmm0
00007f582cdd9428  vmovaps [rsp+0x10], xmm1
00007f582cdd942e  vmovaps [rsp+0x20], xmm2
00007f582cdd9434  vmovaps [rsp+0x30], xmm3
00007f582cdd943a  vmovaps [rsp+0x40], xmm4
00007f582cdd9440  vmovaps [rsp+0x50], xmm5
00007f582cdd9446  vmovaps [rsp+0x60], xmm6
00007f582cdd944c  vmovaps [rsp+0x70], xmm7
00007f582cdd9452  vmovaps [rsp+0x80], xmm8
00007f582cdd945b  vmovaps [rsp+0x90], xmm9
00007f582cdd9464  vmovaps [rsp+0xA0], xmm11
00007f582cdd946d  vmovaps [rsp+0xB0], xmm12
00007f582cdd9476  vmovaps [rsp+0xC0], xmm13
00007f582cdd947f  vmovaps [rsp+0xD0], xmm14
00007f582cdd9488  vmovaps [rsp+0xE0], xmm15
00007f582cdd9491  sub rsp, 0x30
00007f582cdd9495  movaps [rsp], xmm10
00007f582cdd949a  movaps [rsp+0x10], xmm8
00007f582cdd94a0  movaps [rsp+0x20], xmm14
00007f582cdd94a6  lea rdi, [rsp]
00007f582cdd94aa  mov esi, 0x00
00007f582cdd94af  mov rax, 0x653B0D9BF530
00007f582cdd94b9  call rax
00007f582cdd94bb  movaps xmm10, [rsp]
00007f582cdd94c0  add rsp, 0x30
00007f582cdd94c4  vmovaps xmm0, [rsp]
00007f582cdd94c9  vmovaps xmm1, [rsp+0x10]
00007f582cdd94cf  vmovaps xmm2, [rsp+0x20]
00007f582cdd94d5  vmovaps xmm3, [rsp+0x30]
00007f582cdd94db  vmovaps xmm4, [rsp+0x40]
00007f582cdd94e1  vmovaps xmm5, [rsp+0x50]
00007f582cdd94e7  vmovaps xmm6, [rsp+0x60]
00007f582cdd94ed  vmovaps xmm7, [rsp+0x70]
00007f582cdd94f3  vmovaps xmm8, [rsp+0x80]
00007f582cdd94fc  vmovaps xmm9, [rsp+0x90]
00007f582cdd9505  vmovaps xmm11, [rsp+0xA0]
00007f582cdd950e  vmovaps xmm12, [rsp+0xB0]
00007f582cdd9517  vmovaps xmm13, [rsp+0xC0]
00007f582cdd9520  vmovaps xmm14, [rsp+0xD0]
00007f582cdd9529  vmovaps xmm15, [rsp+0xE0]
00007f582cdd9532  add rsp, 0xF0
00007f582cdd9539  pop r11
00007f582cdd953b  pop r10
00007f582cdd953d  pop r9
00007f582cdd953f  pop r8
00007f582cdd9541  pop rsi
00007f582cdd9542  pop rdi
00007f582cdd9543  pop rdx
00007f582cdd9544  pop rcx
00007f582cdd9545  pop rax
00007f582cdd9546  add rsp, 0x08
00007f582cdd954a  jmp 0x00007F582CDD6245
00007f582cdd954f  sub rsp, 0x08
00007f582cdd9553  push rax
00007f582cdd9554  push rcx
00007f582cdd9555  push rdx
00007f582cdd9556  push rdi
00007f582cdd9557  push rsi
00007f582cdd9558  push r8
00007f582cdd955a  push r9
00007f582cdd955c  push r10
00007f582cdd955e  push r11
00007f582cdd9560  sub rsp, 0xF0
00007f582cdd9567  vmovaps [rsp], xmm0
00007f582cdd956c  vmovaps [rsp+0x10], xmm1
00007f582cdd9572  vmovaps [rsp+0x20], xmm2
00007f582cdd9578  vmovaps [rsp+0x30], xmm3
00007f582cdd957e  vmovaps [rsp+0x40], xmm4
00007f582cdd9584  vmovaps [rsp+0x50], xmm5
00007f582cdd958a  vmovaps [rsp+0x60], xmm6
00007f582cdd9590  vmovaps [rsp+0x70], xmm7
00007f582cdd9596  vmovaps [rsp+0x80], xmm8
00007f582cdd959f  vmovaps [rsp+0x90], xmm9
00007f582cdd95a8  vmovaps [rsp+0xA0], xmm10
00007f582cdd95b1  vmovaps [rsp+0xB0], xmm11
00007f582cdd95ba  vmovaps [rsp+0xC0], xmm12
00007f582cdd95c3  vmovaps [rsp+0xD0], xmm13
00007f582cdd95cc  vmovaps [rsp+0xE0], xmm15
00007f582cdd95d5  sub rsp, 0x30
00007f582cdd95d9  movaps [rsp], xmm14
00007f582cdd95de  movaps [rsp+0x10], xmm8
00007f582cdd95e4  movaps [rsp+0x20], xmm4
00007f582cdd95e9  lea rdi, [rsp]
00007f582cdd95ed  mov esi, 0x00
00007f582cdd95f2  mov rax, 0x653B0D9BF530
00007f582cdd95fc  call rax
00007f582cdd95fe  movaps xmm14, [rsp]
00007f582cdd9603  add rsp, 0x30
00007f582cdd9607  vmovaps xmm0, [rsp]
00007f582cdd960c  vmovaps xmm1, [rsp+0x10]
00007f582cdd9612  vmovaps xmm2, [rsp+0x20]
00007f582cdd9618  vmovaps xmm3, [rsp+0x30]
00007f582cdd961e  vmovaps xmm4, [rsp+0x40]
00007f582cdd9624  vmovaps xmm5, [rsp+0x50]
00007f582cdd962a  vmovaps xmm6, [rsp+0x60]
00007f582cdd9630  vmovaps xmm7, [rsp+0x70]
00007f582cdd9636  vmovaps xmm8, [rsp+0x80]
00007f582cdd963f  vmovaps xmm9, [rsp+0x90]
00007f582cdd9648  vmovaps xmm10, [rsp+0xA0]
00007f582cdd9651  vmovaps xmm11, [rsp+0xB0]
00007f582cdd965a  vmovaps xmm12, [rsp+0xC0]
00007f582cdd9663  vmovaps xmm13, [rsp+0xD0]
00007f582cdd966c  vmovaps xmm15, [rsp+0xE0]
00007f582cdd9675  add rsp, 0xF0
00007f582cdd967c  pop r11
00007f582cdd967e  pop r10
00007f582cdd9680  pop r9
00007f582cdd9682  pop r8
00007f582cdd9684  pop rsi
00007f582cdd9685  pop rdi
00007f582cdd9686  pop rdx
00007f582cdd9687  pop rcx
00007f582cdd9688  pop rax
00007f582cdd9689  add rsp, 0x08
00007f582cdd968d  jmp 0x00007F582CDD6265
00007f582cdd9692  sub rsp, 0x08
00007f582cdd9696  push rax
00007f582cdd9697  push rcx
00007f582cdd9698  push rdx
00007f582cdd9699  push rdi
00007f582cdd969a  push rsi
00007f582cdd969b  push r8
00007f582cdd969d  push r9
00007f582cdd969f  push r10
00007f582cdd96a1  push r11
00007f582cdd96a3  sub rsp, 0xF0
00007f582cdd96aa  vmovaps [rsp], xmm0
00007f582cdd96af  vmovaps [rsp+0x10], xmm1
00007f582cdd96b5  vmovaps [rsp+0x20], xmm2
00007f582cdd96bb  vmovaps [rsp+0x30], xmm3
00007f582cdd96c1  vmovaps [rsp+0x40], xmm5
00007f582cdd96c7  vmovaps [rsp+0x50], xmm6
00007f582cdd96cd  vmovaps [rsp+0x60], xmm7
00007f582cdd96d3  vmovaps [rsp+0x70], xmm8
00007f582cdd96d9  vmovaps [rsp+0x80], xmm9
00007f582cdd96e2  vmovaps [rsp+0x90], xmm10
00007f582cdd96eb  vmovaps [rsp+0xA0], xmm11
00007f582cdd96f4  vmovaps [rsp+0xB0], xmm12
00007f582cdd96fd  vmovaps [rsp+0xC0], xmm13
00007f582cdd9706  vmovaps [rsp+0xD0], xmm14
00007f582cdd970f  vmovaps [rsp+0xE0], xmm15
00007f582cdd9718  sub rsp, 0x30
00007f582cdd971c  movaps [rsp], xmm4
00007f582cdd9720  movaps [rsp+0x10], xmm13
00007f582cdd9726  movaps [rsp+0x20], xmm8
00007f582cdd972c  lea rdi, [rsp]
00007f582cdd9730  mov esi, 0x00
00007f582cdd9735  mov rax, 0x653B0D9BF530
00007f582cdd973f  call rax
00007f582cdd9741  movaps xmm4, [rsp]
00007f582cdd9745  add rsp, 0x30
00007f582cdd9749  vmovaps xmm0, [rsp]
00007f582cdd974e  vmovaps xmm1, [rsp+0x10]
00007f582cdd9754  vmovaps xmm2, [rsp+0x20]
00007f582cdd975a  vmovaps xmm3, [rsp+0x30]
00007f582cdd9760  vmovaps xmm5, [rsp+0x40]
00007f582cdd9766  vmovaps xmm6, [rsp+0x50]
00007f582cdd976c  vmovaps xmm7, [rsp+0x60]
00007f582cdd9772  vmovaps xmm8, [rsp+0x70]
00007f582cdd9778  vmovaps xmm9, [rsp+0x80]
00007f582cdd9781  vmovaps xmm10, [rsp+0x90]
00007f582cdd978a  vmovaps xmm11, [rsp+0xA0]
00007f582cdd9793  vmovaps xmm12, [rsp+0xB0]
00007f582cdd979c  vmovaps xmm13, [rsp+0xC0]
00007f582cdd97a5  vmovaps xmm14, [rsp+0xD0]
00007f582cdd97ae  vmovaps xmm15, [rsp+0xE0]
00007f582cdd97b7  add rsp, 0xF0
00007f582cdd97be  pop r11
00007f582cdd97c0  pop r10
00007f582cdd97c2  pop r9
00007f582cdd97c4  pop r8
00007f582cdd97c6  pop rsi
00007f582cdd97c7  pop rdi
00007f582cdd97c8  pop rdx
00007f582cdd97c9  pop rcx
00007f582cdd97ca  pop rax
00007f582cdd97cb  add rsp, 0x08
00007f582cdd97cf  jmp 0x00007F582CDD628A
00007f582cdd97d4  sub rsp, 0x08
00007f582cdd97d8  push rax
00007f582cdd97d9  push rcx
00007f582cdd97da  push rdx
00007f582cdd97db  push rdi
00007f582cdd97dc  push rsi
00007f582cdd97dd  push r8
00007f582cdd97df  push r9
00007f582cdd97e1  push r10
00007f582cdd97e3  push r11
00007f582cdd97e5  sub rsp, 0xF0
00007f582cdd97ec  vmovaps [rsp], xmm0
00007f582cdd97f1  vmovaps [rsp+0x10], xmm1
00007f582cdd97f7  vmovaps [rsp+0x20], xmm2
00007f582cdd97fd  vmovaps [rsp+0x30], xmm3
00007f582cdd9803  vmovaps [rsp+0x40], xmm4
00007f582cdd9809  vmovaps [rsp+0x50], xmm5
00007f582cdd980f  vmovaps [rsp+0x60], xmm6
00007f582cdd9815  vmovaps [rsp+0x70], xmm7
00007f582cdd981b  vmovaps [rsp+0x80], xmm8
00007f582cdd9824  vmovaps [rsp+0x90], xmm9
00007f582cdd982d  vmovaps [rsp+0xA0], xmm10
00007f582cdd9836  vmovaps [rsp+0xB0], xmm11
00007f582cdd983f  vmovaps [rsp+0xC0], xmm12
00007f582cdd9848  vmovaps [rsp+0xD0], xmm14
00007f582cdd9851  vmovaps [rsp+0xE0], xmm15
00007f582cdd985a  sub rsp, 0x30
00007f582cdd985e  movaps [rsp], xmm13
00007f582cdd9863  movaps [rsp+0x10], xmm15
00007f582cdd9869  movaps [rsp+0x20], xmm9
00007f582cdd986f  lea rdi, [rsp]
00007f582cdd9873  mov esi, 0x00
00007f582cdd9878  mov rax, 0x653B0D9BF530
00007f582cdd9882  call rax
00007f582cdd9884  movaps xmm13, [rsp]
00007f582cdd9889  add rsp, 0x30
00007f582cdd988d  vmovaps xmm0, [rsp]
00007f582cdd9892  vmovaps xmm1, [rsp+0x10]
00007f582cdd9898  vmovaps xmm2, [rsp+0x20]
00007f582cdd989e  vmovaps xmm3, [rsp+0x30]
00007f582cdd98a4  vmovaps xmm4, [rsp+0x40]
00007f582cdd98aa  vmovaps xmm5, [rsp+0x50]
00007f582cdd98b0  vmovaps xmm6, [rsp+0x60]
00007f582cdd98b6  vmovaps xmm7, [rsp+0x70]
00007f582cdd98bc  vmovaps xmm8, [rsp+0x80]
00007f582cdd98c5  vmovaps xmm9, [rsp+0x90]
00007f582cdd98ce  vmovaps xmm10, [rsp+0xA0]
00007f582cdd98d7  vmovaps xmm11, [rsp+0xB0]
00007f582cdd98e0  vmovaps xmm12, [rsp+0xC0]
00007f582cdd98e9  vmovaps xmm14, [rsp+0xD0]
00007f582cdd98f2  vmovaps xmm15, [rsp+0xE0]
00007f582cdd98fb  add rsp, 0xF0
00007f582cdd9902  pop r11
00007f582cdd9904  pop r10
00007f582cdd9906  pop r9
00007f582cdd9908  pop r8
00007f582cdd990a  pop rsi
00007f582cdd990b  pop rdi
00007f582cdd990c  pop rdx
00007f582cdd990d  pop rcx
00007f582cdd990e  pop rax
00007f582cdd990f  add rsp, 0x08
00007f582cdd9913  jmp 0x00007F582CDD62A5
00007f582cdd9918  sub rsp, 0x08
00007f582cdd991c  push rax
00007f582cdd991d  push rcx
00007f582cdd991e  push rdx
00007f582cdd991f  push rdi
00007f582cdd9920  push rsi
00007f582cdd9921  push r8
00007f582cdd9923  push r9
00007f582cdd9925  push r10
00007f582cdd9927  push r11
00007f582cdd9929  sub rsp, 0xF0
00007f582cdd9930  vmovaps [rsp], xmm0
00007f582cdd9935  vmovaps [rsp+0x10], xmm1
00007f582cdd993b  vmovaps [rsp+0x20], xmm2
00007f582cdd9941  vmovaps [rsp+0x30], xmm3
00007f582cdd9947  vmovaps [rsp+0x40], xmm4
00007f582cdd994d  vmovaps [rsp+0x50], xmm5
00007f582cdd9953  vmovaps [rsp+0x60], xmm6
00007f582cdd9959  vmovaps [rsp+0x70], xmm7
00007f582cdd995f  vmovaps [rsp+0x80], xmm8
00007f582cdd9968  vmovaps [rsp+0x90], xmm9
00007f582cdd9971  vmovaps [rsp+0xA0], xmm10
00007f582cdd997a  vmovaps [rsp+0xB0], xmm11
00007f582cdd9983  vmovaps [rsp+0xC0], xmm12
00007f582cdd998c  vmovaps [rsp+0xD0], xmm13
00007f582cdd9995  vmovaps [rsp+0xE0], xmm14
00007f582cdd999e  sub rsp, 0x30
00007f582cdd99a2  movaps [rsp], xmm15
00007f582cdd99a7  movaps [rsp+0x10], xmm1
00007f582cdd99ac  movaps [rsp+0x20], xmm5
00007f582cdd99b1  lea rdi, [rsp]
00007f582cdd99b5  mov esi, 0x00
00007f582cdd99ba  mov rax, 0x653B0D9BF530
00007f582cdd99c4  call rax
00007f582cdd99c6  movaps xmm15, [rsp]
00007f582cdd99cb  add rsp, 0x30
00007f582cdd99cf  vmovaps xmm0, [rsp]
00007f582cdd99d4  vmovaps xmm1, [rsp+0x10]
00007f582cdd99da  vmovaps xmm2, [rsp+0x20]
00007f582cdd99e0  vmovaps xmm3, [rsp+0x30]
00007f582cdd99e6  vmovaps xmm4, [rsp+0x40]
00007f582cdd99ec  vmovaps xmm5, [rsp+0x50]
00007f582cdd99f2  vmovaps xmm6, [rsp+0x60]
00007f582cdd99f8  vmovaps xmm7, [rsp+0x70]
00007f582cdd99fe  vmovaps xmm8, [rsp+0x80]
00007f582cdd9a07  vmovaps xmm9, [rsp+0x90]
00007f582cdd9a10  vmovaps xmm10, [rsp+0xA0]
00007f582cdd9a19  vmovaps xmm11, [rsp+0xB0]
00007f582cdd9a22  vmovaps xmm12, [rsp+0xC0]
00007f582cdd9a2b  vmovaps xmm13, [rsp+0xD0]
00007f582cdd9a34  vmovaps xmm14, [rsp+0xE0]
00007f582cdd9a3d  add rsp, 0xF0
00007f582cdd9a44  pop r11
00007f582cdd9a46  pop r10
00007f582cdd9a48  pop r9
00007f582cdd9a4a  pop r8
00007f582cdd9a4c  pop rsi
00007f582cdd9a4d  pop rdi
00007f582cdd9a4e  pop rdx
00007f582cdd9a4f  pop rcx
00007f582cdd9a50  pop rax
00007f582cdd9a51  add rsp, 0x08
00007f582cdd9a55  jmp 0x00007F582CDD62C0
00007f582cdd9a5a  call 0x00007F582CCD64F0
00007f582cdd9a5f  jmp 0x00007F582CDD631B
00007f582cdd9a64  sub rsp, 0x08
00007f582cdd9a68  push rax
00007f582cdd9a69  push rcx
00007f582cdd9a6a  push rdx
00007f582cdd9a6b  push rdi
00007f582cdd9a6c  push rsi
00007f582cdd9a6d  push r8
00007f582cdd9a6f  push r9
00007f582cdd9a71  push r10
00007f582cdd9a73  push r11
00007f582cdd9a75  sub rsp, 0xF0
00007f582cdd9a7c  vmovaps [rsp], xmm0
00007f582cdd9a81  vmovaps [rsp+0x10], xmm1
00007f582cdd9a87  vmovaps [rsp+0x20], xmm2
00007f582cdd9a8d  vmovaps [rsp+0x30], xmm3
00007f582cdd9a93  vmovaps [rsp+0x40], xmm4
00007f582cdd9a99  vmovaps [rsp+0x50], xmm5
00007f582cdd9a9f  vmovaps [rsp+0x60], xmm6
00007f582cdd9aa5  vmovaps [rsp+0x70], xmm7
00007f582cdd9aab  vmovaps [rsp+0x80], xmm8
00007f582cdd9ab4  vmovaps [rsp+0x90], xmm10
00007f582cdd9abd  vmovaps [rsp+0xA0], xmm11
00007f582cdd9ac6  vmovaps [rsp+0xB0], xmm12
00007f582cdd9acf  vmovaps [rsp+0xC0], xmm13
00007f582cdd9ad8  vmovaps [rsp+0xD0], xmm14
00007f582cdd9ae1  vmovaps [rsp+0xE0], xmm15
00007f582cdd9aea  sub rsp, 0x30
00007f582cdd9aee  movaps [rsp], xmm9
00007f582cdd9af3  movaps [rsp+0x10], xmm8
00007f582cdd9af9  movaps [rsp+0x20], xmm11
00007f582cdd9aff  lea rdi, [rsp]
00007f582cdd9b03  mov esi, 0x00
00007f582cdd9b08  mov rax, 0x653B0D9BF530
00007f582cdd9b12  call rax
00007f582cdd9b14  movaps xmm9, [rsp]
00007f582cdd9b19  add rsp, 0x30
00007f582cdd9b1d  vmovaps xmm0, [rsp]
00007f582cdd9b22  vmovaps xmm1, [rsp+0x10]
00007f582cdd9b28  vmovaps xmm2, [rsp+0x20]
00007f582cdd9b2e  vmovaps xmm3, [rsp+0x30]
00007f582cdd9b34  vmovaps xmm4, [rsp+0x40]
00007f582cdd9b3a  vmovaps xmm5, [rsp+0x50]
00007f582cdd9b40  vmovaps xmm6, [rsp+0x60]
00007f582cdd9b46  vmovaps xmm7, [rsp+0x70]
00007f582cdd9b4c  vmovaps xmm8, [rsp+0x80]
00007f582cdd9b55  vmovaps xmm10, [rsp+0x90]
00007f582cdd9b5e  vmovaps xmm11, [rsp+0xA0]
00007f582cdd9b67  vmovaps xmm12, [rsp+0xB0]
00007f582cdd9b70  vmovaps xmm13, [rsp+0xC0]
00007f582cdd9b79  vmovaps xmm14, [rsp+0xD0]
00007f582cdd9b82  vmovaps xmm15, [rsp+0xE0]
00007f582cdd9b8b  add rsp, 0xF0
00007f582cdd9b92  pop r11
00007f582cdd9b94  pop r10
00007f582cdd9b96  pop r9
00007f582cdd9b98  pop r8
00007f582cdd9b9a  pop rsi
00007f582cdd9b9b  pop rdi
00007f582cdd9b9c  pop rdx
00007f582cdd9b9d  pop rcx
00007f582cdd9b9e  pop rax
00007f582cdd9b9f  add rsp, 0x08
00007f582cdd9ba3  jmp 0x00007F582CDD6352
00007f582cdd9ba8  sub rsp, 0x08
00007f582cdd9bac  push rax
00007f582cdd9bad  push rcx
00007f582cdd9bae  push rdx
00007f582cdd9baf  push rdi
00007f582cdd9bb0  push rsi
00007f582cdd9bb1  push r8
00007f582cdd9bb3  push r9
00007f582cdd9bb5  push r10
00007f582cdd9bb7  push r11
00007f582cdd9bb9  sub rsp, 0xF0
00007f582cdd9bc0  vmovaps [rsp], xmm0
00007f582cdd9bc5  vmovaps [rsp+0x10], xmm1
00007f582cdd9bcb  vmovaps [rsp+0x20], xmm2
00007f582cdd9bd1  vmovaps [rsp+0x30], xmm3
00007f582cdd9bd7  vmovaps [rsp+0x40], xmm4
00007f582cdd9bdd  vmovaps [rsp+0x50], xmm5
00007f582cdd9be3  vmovaps [rsp+0x60], xmm6
00007f582cdd9be9  vmovaps [rsp+0x70], xmm7
00007f582cdd9bef  vmovaps [rsp+0x80], xmm8
00007f582cdd9bf8  vmovaps [rsp+0x90], xmm9
00007f582cdd9c01  vmovaps [rsp+0xA0], xmm10
00007f582cdd9c0a  vmovaps [rsp+0xB0], xmm12
00007f582cdd9c13  vmovaps [rsp+0xC0], xmm13
00007f582cdd9c1c  vmovaps [rsp+0xD0], xmm14
00007f582cdd9c25  vmovaps [rsp+0xE0], xmm15
00007f582cdd9c2e  sub rsp, 0x30
00007f582cdd9c32  movaps [rsp], xmm11
00007f582cdd9c37  movaps [rsp+0x10], xmm10
00007f582cdd9c3d  movaps [rsp+0x20], xmm6
00007f582cdd9c42  lea rdi, [rsp]
00007f582cdd9c46  mov esi, 0x00
00007f582cdd9c4b  mov rax, 0x653B0D9BF530
00007f582cdd9c55  call rax
00007f582cdd9c57  movaps xmm11, [rsp]
00007f582cdd9c5c  add rsp, 0x30
00007f582cdd9c60  vmovaps xmm0, [rsp]
00007f582cdd9c65  vmovaps xmm1, [rsp+0x10]
00007f582cdd9c6b  vmovaps xmm2, [rsp+0x20]
00007f582cdd9c71  vmovaps xmm3, [rsp+0x30]
00007f582cdd9c77  vmovaps xmm4, [rsp+0x40]
00007f582cdd9c7d  vmovaps xmm5, [rsp+0x50]
00007f582cdd9c83  vmovaps xmm6, [rsp+0x60]
00007f582cdd9c89  vmovaps xmm7, [rsp+0x70]
00007f582cdd9c8f  vmovaps xmm8, [rsp+0x80]
00007f582cdd9c98  vmovaps xmm9, [rsp+0x90]
00007f582cdd9ca1  vmovaps xmm10, [rsp+0xA0]
00007f582cdd9caa  vmovaps xmm12, [rsp+0xB0]
00007f582cdd9cb3  vmovaps xmm13, [rsp+0xC0]
00007f582cdd9cbc  vmovaps xmm14, [rsp+0xD0]
00007f582cdd9cc5  vmovaps xmm15, [rsp+0xE0]
00007f582cdd9cce  add rsp, 0xF0
00007f582cdd9cd5  pop r11
00007f582cdd9cd7  pop r10
00007f582cdd9cd9  pop r9
00007f582cdd9cdb  pop r8
00007f582cdd9cdd  pop rsi
00007f582cdd9cde  pop rdi
00007f582cdd9cdf  pop rdx
00007f582cdd9ce0  pop rcx
00007f582cdd9ce1  pop rax
00007f582cdd9ce2  add rsp, 0x08
00007f582cdd9ce6  jmp 0x00007F582CDD636D
00007f582cdd9ceb  sub rsp, 0x08
00007f582cdd9cef  push rax
00007f582cdd9cf0  push rcx
00007f582cdd9cf1  push rdx
00007f582cdd9cf2  push rdi
00007f582cdd9cf3  push rsi
00007f582cdd9cf4  push r8
00007f582cdd9cf6  push r9
00007f582cdd9cf8  push r10
00007f582cdd9cfa  push r11
00007f582cdd9cfc  sub rsp, 0xF0
00007f582cdd9d03  vmovaps [rsp], xmm0
00007f582cdd9d08  vmovaps [rsp+0x10], xmm1
00007f582cdd9d0e  vmovaps [rsp+0x20], xmm2
00007f582cdd9d14  vmovaps [rsp+0x30], xmm3
00007f582cdd9d1a  vmovaps [rsp+0x40], xmm4
00007f582cdd9d20  vmovaps [rsp+0x50], xmm5
00007f582cdd9d26  vmovaps [rsp+0x60], xmm6
00007f582cdd9d2c  vmovaps [rsp+0x70], xmm7
00007f582cdd9d32  vmovaps [rsp+0x80], xmm8
00007f582cdd9d3b  vmovaps [rsp+0x90], xmm9
00007f582cdd9d44  vmovaps [rsp+0xA0], xmm11
00007f582cdd9d4d  vmovaps [rsp+0xB0], xmm12
00007f582cdd9d56  vmovaps [rsp+0xC0], xmm13
00007f582cdd9d5f  vmovaps [rsp+0xD0], xmm14
00007f582cdd9d68  vmovaps [rsp+0xE0], xmm15
00007f582cdd9d71  sub rsp, 0x30
00007f582cdd9d75  movaps [rsp], xmm10
00007f582cdd9d7a  movaps [rsp+0x10], xmm14
00007f582cdd9d80  movaps [rsp+0x20], xmm4
00007f582cdd9d85  lea rdi, [rsp]
00007f582cdd9d89  mov esi, 0x00
00007f582cdd9d8e  mov rax, 0x653B0D9BF530
00007f582cdd9d98  call rax
00007f582cdd9d9a  movaps xmm10, [rsp]
00007f582cdd9d9f  add rsp, 0x30
00007f582cdd9da3  vmovaps xmm0, [rsp]
00007f582cdd9da8  vmovaps xmm1, [rsp+0x10]
00007f582cdd9dae  vmovaps xmm2, [rsp+0x20]
00007f582cdd9db4  vmovaps xmm3, [rsp+0x30]
00007f582cdd9dba  vmovaps xmm4, [rsp+0x40]
00007f582cdd9dc0  vmovaps xmm5, [rsp+0x50]
00007f582cdd9dc6  vmovaps xmm6, [rsp+0x60]
00007f582cdd9dcc  vmovaps xmm7, [rsp+0x70]
00007f582cdd9dd2  vmovaps xmm8, [rsp+0x80]
00007f582cdd9ddb  vmovaps xmm9, [rsp+0x90]
00007f582cdd9de4  vmovaps xmm11, [rsp+0xA0]
00007f582cdd9ded  vmovaps xmm12, [rsp+0xB0]
00007f582cdd9df6  vmovaps xmm13, [rsp+0xC0]
00007f582cdd9dff  vmovaps xmm14, [rsp+0xD0]
00007f582cdd9e08  vmovaps xmm15, [rsp+0xE0]
00007f582cdd9e11  add rsp, 0xF0
00007f582cdd9e18  pop r11
00007f582cdd9e1a  pop r10
00007f582cdd9e1c  pop r9
00007f582cdd9e1e  pop r8
00007f582cdd9e20  pop rsi
00007f582cdd9e21  pop rdi
00007f582cdd9e22  pop rdx
00007f582cdd9e23  pop rcx
00007f582cdd9e24  pop rax
00007f582cdd9e25  add rsp, 0x08
00007f582cdd9e29  jmp 0x00007F582CDD6388
00007f582cdd9e2e  sub rsp, 0x08
00007f582cdd9e32  push rax
00007f582cdd9e33  push rcx
00007f582cdd9e34  push rdx
00007f582cdd9e35  push rdi
00007f582cdd9e36  push rsi
00007f582cdd9e37  push r8
00007f582cdd9e39  push r9
00007f582cdd9e3b  push r10
00007f582cdd9e3d  push r11
00007f582cdd9e3f  sub rsp, 0xF0
00007f582cdd9e46  vmovaps [rsp], xmm0
00007f582cdd9e4b  vmovaps [rsp+0x10], xmm1
00007f582cdd9e51  vmovaps [rsp+0x20], xmm2
00007f582cdd9e57  vmovaps [rsp+0x30], xmm3
00007f582cdd9e5d  vmovaps [rsp+0x40], xmm4
00007f582cdd9e63  vmovaps [rsp+0x50], xmm5
00007f582cdd9e69  vmovaps [rsp+0x60], xmm6
00007f582cdd9e6f  vmovaps [rsp+0x70], xmm7
00007f582cdd9e75  vmovaps [rsp+0x80], xmm9
00007f582cdd9e7e  vmovaps [rsp+0x90], xmm10
00007f582cdd9e87  vmovaps [rsp+0xA0], xmm11
00007f582cdd9e90  vmovaps [rsp+0xB0], xmm12
00007f582cdd9e99  vmovaps [rsp+0xC0], xmm13
00007f582cdd9ea2  vmovaps [rsp+0xD0], xmm14
00007f582cdd9eab  vmovaps [rsp+0xE0], xmm15
00007f582cdd9eb4  sub rsp, 0x30
00007f582cdd9eb8  movaps [rsp], xmm8
00007f582cdd9ebd  movaps [rsp+0x10], xmm1
00007f582cdd9ec2  movaps [rsp+0x20], xmm14
00007f582cdd9ec8  lea rdi, [rsp]
00007f582cdd9ecc  mov esi, 0x00
00007f582cdd9ed1  mov rax, 0x653B0D9BF530
00007f582cdd9edb  call rax
00007f582cdd9edd  movaps xmm8, [rsp]
00007f582cdd9ee2  add rsp, 0x30
00007f582cdd9ee6  vmovaps xmm0, [rsp]
00007f582cdd9eeb  vmovaps xmm1, [rsp+0x10]
00007f582cdd9ef1  vmovaps xmm2, [rsp+0x20]
00007f582cdd9ef7  vmovaps xmm3, [rsp+0x30]
00007f582cdd9efd  vmovaps xmm4, [rsp+0x40]
00007f582cdd9f03  vmovaps xmm5, [rsp+0x50]
00007f582cdd9f09  vmovaps xmm6, [rsp+0x60]
00007f582cdd9f0f  vmovaps xmm7, [rsp+0x70]
00007f582cdd9f15  vmovaps xmm9, [rsp+0x80]
00007f582cdd9f1e  vmovaps xmm10, [rsp+0x90]
00007f582cdd9f27  vmovaps xmm11, [rsp+0xA0]
00007f582cdd9f30  vmovaps xmm12, [rsp+0xB0]
00007f582cdd9f39  vmovaps xmm13, [rsp+0xC0]
00007f582cdd9f42  vmovaps xmm14, [rsp+0xD0]
00007f582cdd9f4b  vmovaps xmm15, [rsp+0xE0]
00007f582cdd9f54  add rsp, 0xF0
00007f582cdd9f5b  pop r11
00007f582cdd9f5d  pop r10
00007f582cdd9f5f  pop r9
00007f582cdd9f61  pop r8
00007f582cdd9f63  pop rsi
00007f582cdd9f64  pop rdi
00007f582cdd9f65  pop rdx
00007f582cdd9f66  pop rcx
00007f582cdd9f67  pop rax
00007f582cdd9f68  add rsp, 0x08
00007f582cdd9f6c  jmp 0x00007F582CDD63AE
00007f582cdd9f71  sub rsp, 0x08
00007f582cdd9f75  push rax
00007f582cdd9f76  push rcx
00007f582cdd9f77  push rdx
00007f582cdd9f78  push rdi
00007f582cdd9f79  push rsi
00007f582cdd9f7a  push r8
00007f582cdd9f7c  push r9
00007f582cdd9f7e  push r10
00007f582cdd9f80  push r11
00007f582cdd9f82  sub rsp, 0xF0
00007f582cdd9f89  vmovaps [rsp], xmm0
00007f582cdd9f8e  vmovaps [rsp+0x10], xmm1
00007f582cdd9f94  vmovaps [rsp+0x20], xmm2
00007f582cdd9f9a  vmovaps [rsp+0x30], xmm3
00007f582cdd9fa0  vmovaps [rsp+0x40], xmm4
00007f582cdd9fa6  vmovaps [rsp+0x50], xmm5
00007f582cdd9fac  vmovaps [rsp+0x60], xmm7
00007f582cdd9fb2  vmovaps [rsp+0x70], xmm8
00007f582cdd9fb8  vmovaps [rsp+0x80], xmm9
00007f582cdd9fc1  vmovaps [rsp+0x90], xmm10
00007f582cdd9fca  vmovaps [rsp+0xA0], xmm11
00007f582cdd9fd3  vmovaps [rsp+0xB0], xmm12
00007f582cdd9fdc  vmovaps [rsp+0xC0], xmm13
00007f582cdd9fe5  vmovaps [rsp+0xD0], xmm14
00007f582cdd9fee  vmovaps [rsp+0xE0], xmm15
00007f582cdd9ff7  sub rsp, 0x30
00007f582cdd9ffb  movaps [rsp], xmm6
00007f582cdd9fff  movaps [rsp+0x10], xmm1
00007f582cdda004  movaps [rsp+0x20], xmm14
00007f582cdda00a  lea rdi, [rsp]
00007f582cdda00e  mov esi, 0x00
00007f582cdda013  mov rax, 0x653B0D9BF530
00007f582cdda01d  call rax
00007f582cdda01f  movaps xmm6, [rsp]
00007f582cdda023  add rsp, 0x30
00007f582cdda027  vmovaps xmm0, [rsp]
00007f582cdda02c  vmovaps xmm1, [rsp+0x10]
00007f582cdda032  vmovaps xmm2, [rsp+0x20]
00007f582cdda038  vmovaps xmm3, [rsp+0x30]
00007f582cdda03e  vmovaps xmm4, [rsp+0x40]
00007f582cdda044  vmovaps xmm5, [rsp+0x50]
00007f582cdda04a  vmovaps xmm7, [rsp+0x60]
00007f582cdda050  vmovaps xmm8, [rsp+0x70]
00007f582cdda056  vmovaps xmm9, [rsp+0x80]
00007f582cdda05f  vmovaps xmm10, [rsp+0x90]
00007f582cdda068  vmovaps xmm11, [rsp+0xA0]
00007f582cdda071  vmovaps xmm12, [rsp+0xB0]
00007f582cdda07a  vmovaps xmm13, [rsp+0xC0]
00007f582cdda083  vmovaps xmm14, [rsp+0xD0]
00007f582cdda08c  vmovaps xmm15, [rsp+0xE0]
00007f582cdda095  add rsp, 0xF0
00007f582cdda09c  pop r11
00007f582cdda09e  pop r10
00007f582cdda0a0  pop r9
00007f582cdda0a2  pop r8
00007f582cdda0a4  pop rsi
00007f582cdda0a5  pop rdi
00007f582cdda0a6  pop rdx
00007f582cdda0a7  pop rcx
00007f582cdda0a8  pop rax
00007f582cdda0a9  add rsp, 0x08
00007f582cdda0ad  jmp 0x00007F582CDD63DA
00007f582cdda0b2  sub rsp, 0x08
00007f582cdda0b6  push rax
00007f582cdda0b7  push rcx
00007f582cdda0b8  push rdx
00007f582cdda0b9  push rdi
00007f582cdda0ba  push rsi
00007f582cdda0bb  push r8
00007f582cdda0bd  push r9
00007f582cdda0bf  push r10
00007f582cdda0c1  push r11
00007f582cdda0c3  sub rsp, 0xF0
00007f582cdda0ca  vmovaps [rsp], xmm0
00007f582cdda0cf  vmovaps [rsp+0x10], xmm1
00007f582cdda0d5  vmovaps [rsp+0x20], xmm2
00007f582cdda0db  vmovaps [rsp+0x30], xmm3
00007f582cdda0e1  vmovaps [rsp+0x40], xmm4
00007f582cdda0e7  vmovaps [rsp+0x50], xmm5
00007f582cdda0ed  vmovaps [rsp+0x60], xmm6
00007f582cdda0f3  vmovaps [rsp+0x70], xmm7
00007f582cdda0f9  vmovaps [rsp+0x80], xmm8
00007f582cdda102  vmovaps [rsp+0x90], xmm9
00007f582cdda10b  vmovaps [rsp+0xA0], xmm10
00007f582cdda114  vmovaps [rsp+0xB0], xmm11
00007f582cdda11d  vmovaps [rsp+0xC0], xmm12
00007f582cdda126  vmovaps [rsp+0xD0], xmm13
00007f582cdda12f  vmovaps [rsp+0xE0], xmm15
00007f582cdda138  sub rsp, 0x30
00007f582cdda13c  movaps [rsp], xmm14
00007f582cdda141  movaps [rsp+0x10], xmm12
00007f582cdda147  movaps [rsp+0x20], xmm1
00007f582cdda14c  lea rdi, [rsp]
00007f582cdda150  mov esi, 0x00
00007f582cdda155  mov rax, 0x653B0D9BF530
00007f582cdda15f  call rax
00007f582cdda161  movaps xmm14, [rsp]
00007f582cdda166  add rsp, 0x30
00007f582cdda16a  vmovaps xmm0, [rsp]
00007f582cdda16f  vmovaps xmm1, [rsp+0x10]
00007f582cdda175  vmovaps xmm2, [rsp+0x20]
00007f582cdda17b  vmovaps xmm3, [rsp+0x30]
00007f582cdda181  vmovaps xmm4, [rsp+0x40]
00007f582cdda187  vmovaps xmm5, [rsp+0x50]
00007f582cdda18d  vmovaps xmm6, [rsp+0x60]
00007f582cdda193  vmovaps xmm7, [rsp+0x70]
00007f582cdda199  vmovaps xmm8, [rsp+0x80]
00007f582cdda1a2  vmovaps xmm9, [rsp+0x90]
00007f582cdda1ab  vmovaps xmm10, [rsp+0xA0]
00007f582cdda1b4  vmovaps xmm11, [rsp+0xB0]
00007f582cdda1bd  vmovaps xmm12, [rsp+0xC0]
00007f582cdda1c6  vmovaps xmm13, [rsp+0xD0]
00007f582cdda1cf  vmovaps xmm15, [rsp+0xE0]
00007f582cdda1d8  add rsp, 0xF0
00007f582cdda1df  pop r11
00007f582cdda1e1  pop r10
00007f582cdda1e3  pop r9
00007f582cdda1e5  pop r8
00007f582cdda1e7  pop rsi
00007f582cdda1e8  pop rdi
00007f582cdda1e9  pop rdx
00007f582cdda1ea  pop rcx
00007f582cdda1eb  pop rax
00007f582cdda1ec  add rsp, 0x08
00007f582cdda1f0  jmp 0x00007F582CDD6400
00007f582cdda1f5  sub rsp, 0x08
00007f582cdda1f9  push rax
00007f582cdda1fa  push rcx
00007f582cdda1fb  push rdx
00007f582cdda1fc  push rdi
00007f582cdda1fd  push rsi
00007f582cdda1fe  push r8
00007f582cdda200  push r9
00007f582cdda202  push r10
00007f582cdda204  push r11
00007f582cdda206  sub rsp, 0xF0
00007f582cdda20d  vmovaps [rsp], xmm0
00007f582cdda212  vmovaps [rsp+0x10], xmm2
00007f582cdda218  vmovaps [rsp+0x20], xmm3
00007f582cdda21e  vmovaps [rsp+0x30], xmm4
00007f582cdda224  vmovaps [rsp+0x40], xmm5
00007f582cdda22a  vmovaps [rsp+0x50], xmm6
00007f582cdda230  vmovaps [rsp+0x60], xmm7
00007f582cdda236  vmovaps [rsp+0x70], xmm8
00007f582cdda23c  vmovaps [rsp+0x80], xmm9
00007f582cdda245  vmovaps [rsp+0x90], xmm10
00007f582cdda24e  vmovaps [rsp+0xA0], xmm11
00007f582cdda257  vmovaps [rsp+0xB0], xmm12
00007f582cdda260  vmovaps [rsp+0xC0], xmm13
00007f582cdda269  vmovaps [rsp+0xD0], xmm14
00007f582cdda272  vmovaps [rsp+0xE0], xmm15
00007f582cdda27b  sub rsp, 0x30
00007f582cdda27f  movaps [rsp], xmm1
00007f582cdda283  movaps [rsp+0x10], xmm13
00007f582cdda289  movaps [rsp+0x20], xmm9
00007f582cdda28f  lea rdi, [rsp]
00007f582cdda293  mov esi, 0x00
00007f582cdda298  mov rax, 0x653B0D9BF530
00007f582cdda2a2  call rax
00007f582cdda2a4  movaps xmm1, [rsp]
00007f582cdda2a8  add rsp, 0x30
00007f582cdda2ac  vmovaps xmm0, [rsp]
00007f582cdda2b1  vmovaps xmm2, [rsp+0x10]
00007f582cdda2b7  vmovaps xmm3, [rsp+0x20]
00007f582cdda2bd  vmovaps xmm4, [rsp+0x30]
00007f582cdda2c3  vmovaps xmm5, [rsp+0x40]
00007f582cdda2c9  vmovaps xmm6, [rsp+0x50]
00007f582cdda2cf  vmovaps xmm7, [rsp+0x60]
00007f582cdda2d5  vmovaps xmm8, [rsp+0x70]
00007f582cdda2db  vmovaps xmm9, [rsp+0x80]
00007f582cdda2e4  vmovaps xmm10, [rsp+0x90]
00007f582cdda2ed  vmovaps xmm11, [rsp+0xA0]
00007f582cdda2f6  vmovaps xmm12, [rsp+0xB0]
00007f582cdda2ff  vmovaps xmm13, [rsp+0xC0]
00007f582cdda308  vmovaps xmm14, [rsp+0xD0]
00007f582cdda311  vmovaps xmm15, [rsp+0xE0]
00007f582cdda31a  add rsp, 0xF0
00007f582cdda321  pop r11
00007f582cdda323  pop r10
00007f582cdda325  pop r9
00007f582cdda327  pop r8
00007f582cdda329  pop rsi
00007f582cdda32a  pop rdi
00007f582cdda32b  pop rdx
00007f582cdda32c  pop rcx
00007f582cdda32d  pop rax
00007f582cdda32e  add rsp, 0x08
00007f582cdda332  jmp 0x00007F582CDD641A
00007f582cdda337  sub rsp, 0x08
00007f582cdda33b  push rax
00007f582cdda33c  push rcx
00007f582cdda33d  push rdx
00007f582cdda33e  push rdi
00007f582cdda33f  push rsi
00007f582cdda340  push r8
00007f582cdda342  push r9
00007f582cdda344  push r10
00007f582cdda346  push r11
00007f582cdda348  sub rsp, 0xF0
00007f582cdda34f  vmovaps [rsp], xmm0
00007f582cdda354  vmovaps [rsp+0x10], xmm1
00007f582cdda35a  vmovaps [rsp+0x20], xmm2
00007f582cdda360  vmovaps [rsp+0x30], xmm3
00007f582cdda366  vmovaps [rsp+0x40], xmm4
00007f582cdda36c  vmovaps [rsp+0x50], xmm5
00007f582cdda372  vmovaps [rsp+0x60], xmm6
00007f582cdda378  vmovaps [rsp+0x70], xmm7
00007f582cdda37e  vmovaps [rsp+0x80], xmm8
00007f582cdda387  vmovaps [rsp+0x90], xmm9
00007f582cdda390  vmovaps [rsp+0xA0], xmm10
00007f582cdda399  vmovaps [rsp+0xB0], xmm11
00007f582cdda3a2  vmovaps [rsp+0xC0], xmm13
00007f582cdda3ab  vmovaps [rsp+0xD0], xmm14
00007f582cdda3b4  vmovaps [rsp+0xE0], xmm15
00007f582cdda3bd  sub rsp, 0x30
00007f582cdda3c1  movaps [rsp], xmm12
00007f582cdda3c6  movaps [rsp+0x10], xmm7
00007f582cdda3cb  movaps [rsp+0x20], xmm13
00007f582cdda3d1  lea rdi, [rsp]
00007f582cdda3d5  mov esi, 0x00
00007f582cdda3da  mov rax, 0x653B0D9BF530
00007f582cdda3e4  call rax
00007f582cdda3e6  movaps xmm12, [rsp]
00007f582cdda3eb  add rsp, 0x30
00007f582cdda3ef  vmovaps xmm0, [rsp]
00007f582cdda3f4  vmovaps xmm1, [rsp+0x10]
00007f582cdda3fa  vmovaps xmm2, [rsp+0x20]
00007f582cdda400  vmovaps xmm3, [rsp+0x30]
00007f582cdda406  vmovaps xmm4, [rsp+0x40]
00007f582cdda40c  vmovaps xmm5, [rsp+0x50]
00007f582cdda412  vmovaps xmm6, [rsp+0x60]
00007f582cdda418  vmovaps xmm7, [rsp+0x70]
00007f582cdda41e  vmovaps xmm8, [rsp+0x80]
00007f582cdda427  vmovaps xmm9, [rsp+0x90]
00007f582cdda430  vmovaps xmm10, [rsp+0xA0]
00007f582cdda439  vmovaps xmm11, [rsp+0xB0]
00007f582cdda442  vmovaps xmm13, [rsp+0xC0]
00007f582cdda44b  vmovaps xmm14, [rsp+0xD0]
00007f582cdda454  vmovaps xmm15, [rsp+0xE0]
00007f582cdda45d  add rsp, 0xF0
00007f582cdda464  pop r11
00007f582cdda466  pop r10
00007f582cdda468  pop r9
00007f582cdda46a  pop r8
00007f582cdda46c  pop rsi
00007f582cdda46d  pop rdi
00007f582cdda46e  pop rdx
00007f582cdda46f  pop rcx
00007f582cdda470  pop rax
00007f582cdda471  add rsp, 0x08
00007f582cdda475  jmp 0x00007F582CDD6441
00007f582cdda47a  sub rsp, 0x08
00007f582cdda47e  push rax
00007f582cdda47f  push rcx
00007f582cdda480  push rdx
00007f582cdda481  push rdi
00007f582cdda482  push rsi
00007f582cdda483  push r8
00007f582cdda485  push r9
00007f582cdda487  push r10
00007f582cdda489  push r11
00007f582cdda48b  sub rsp, 0xF0
00007f582cdda492  vmovaps [rsp], xmm0
00007f582cdda497  vmovaps [rsp+0x10], xmm1
00007f582cdda49d  vmovaps [rsp+0x20], xmm2
00007f582cdda4a3  vmovaps [rsp+0x30], xmm3
00007f582cdda4a9  vmovaps [rsp+0x40], xmm4
00007f582cdda4af  vmovaps [rsp+0x50], xmm5
00007f582cdda4b5  vmovaps [rsp+0x60], xmm6
00007f582cdda4bb  vmovaps [rsp+0x70], xmm7
00007f582cdda4c1  vmovaps [rsp+0x80], xmm8
00007f582cdda4ca  vmovaps [rsp+0x90], xmm9
00007f582cdda4d3  vmovaps [rsp+0xA0], xmm10
00007f582cdda4dc  vmovaps [rsp+0xB0], xmm11
00007f582cdda4e5  vmovaps [rsp+0xC0], xmm12
00007f582cdda4ee  vmovaps [rsp+0xD0], xmm14
00007f582cdda4f7  vmovaps [rsp+0xE0], xmm15
00007f582cdda500  sub rsp, 0x30
00007f582cdda504  movaps [rsp], xmm13
00007f582cdda509  movaps [rsp+0x10], xmm15
00007f582cdda50f  movaps [rsp+0x20], xmm8
00007f582cdda515  lea rdi, [rsp]
00007f582cdda519  mov esi, 0x00
00007f582cdda51e  mov rax, 0x653B0D9BF530
00007f582cdda528  call rax
00007f582cdda52a  movaps xmm13, [rsp]
00007f582cdda52f  add rsp, 0x30
00007f582cdda533  vmovaps xmm0, [rsp]
00007f582cdda538  vmovaps xmm1, [rsp+0x10]
00007f582cdda53e  vmovaps xmm2, [rsp+0x20]
00007f582cdda544  vmovaps xmm3, [rsp+0x30]
00007f582cdda54a  vmovaps xmm4, [rsp+0x40]
00007f582cdda550  vmovaps xmm5, [rsp+0x50]
00007f582cdda556  vmovaps xmm6, [rsp+0x60]
00007f582cdda55c  vmovaps xmm7, [rsp+0x70]
00007f582cdda562  vmovaps xmm8, [rsp+0x80]
00007f582cdda56b  vmovaps xmm9, [rsp+0x90]
00007f582cdda574  vmovaps xmm10, [rsp+0xA0]
00007f582cdda57d  vmovaps xmm11, [rsp+0xB0]
00007f582cdda586  vmovaps xmm12, [rsp+0xC0]
00007f582cdda58f  vmovaps xmm14, [rsp+0xD0]
00007f582cdda598  vmovaps xmm15, [rsp+0xE0]
00007f582cdda5a1  add rsp, 0xF0
00007f582cdda5a8  pop r11
00007f582cdda5aa  pop r10
00007f582cdda5ac  pop r9
00007f582cdda5ae  pop r8
00007f582cdda5b0  pop rsi
00007f582cdda5b1  pop rdi
00007f582cdda5b2  pop rdx
00007f582cdda5b3  pop rcx
00007f582cdda5b4  pop rax
00007f582cdda5b5  add rsp, 0x08
00007f582cdda5b9  jmp 0x00007F582CDD645C
00007f582cdda5be  sub rsp, 0x08
00007f582cdda5c2  push rax
00007f582cdda5c3  push rcx
00007f582cdda5c4  push rdx
00007f582cdda5c5  push rdi
00007f582cdda5c6  push rsi
00007f582cdda5c7  push r8
00007f582cdda5c9  push r9
00007f582cdda5cb  push r10
00007f582cdda5cd  push r11
00007f582cdda5cf  sub rsp, 0xF0
00007f582cdda5d6  vmovaps [rsp], xmm0
00007f582cdda5db  vmovaps [rsp+0x10], xmm1
00007f582cdda5e1  vmovaps [rsp+0x20], xmm2
00007f582cdda5e7  vmovaps [rsp+0x30], xmm3
00007f582cdda5ed  vmovaps [rsp+0x40], xmm4
00007f582cdda5f3  vmovaps [rsp+0x50], xmm5
00007f582cdda5f9  vmovaps [rsp+0x60], xmm6
00007f582cdda5ff  vmovaps [rsp+0x70], xmm7
00007f582cdda605  vmovaps [rsp+0x80], xmm9
00007f582cdda60e  vmovaps [rsp+0x90], xmm10
00007f582cdda617  vmovaps [rsp+0xA0], xmm11
00007f582cdda620  vmovaps [rsp+0xB0], xmm12
00007f582cdda629  vmovaps [rsp+0xC0], xmm13
00007f582cdda632  vmovaps [rsp+0xD0], xmm14
00007f582cdda63b  vmovaps [rsp+0xE0], xmm15
00007f582cdda644  sub rsp, 0x30
00007f582cdda648  movaps [rsp], xmm8
00007f582cdda64d  movaps [rsp+0x10], xmm15
00007f582cdda653  movaps [rsp+0x20], xmm9
00007f582cdda659  lea rdi, [rsp]
00007f582cdda65d  mov esi, 0x00
00007f582cdda662  mov rax, 0x653B0D9BF530
00007f582cdda66c  call rax
00007f582cdda66e  movaps xmm8, [rsp]
00007f582cdda673  add rsp, 0x30
00007f582cdda677  vmovaps xmm0, [rsp]
00007f582cdda67c  vmovaps xmm1, [rsp+0x10]
00007f582cdda682  vmovaps xmm2, [rsp+0x20]
00007f582cdda688  vmovaps xmm3, [rsp+0x30]
00007f582cdda68e  vmovaps xmm4, [rsp+0x40]
00007f582cdda694  vmovaps xmm5, [rsp+0x50]
00007f582cdda69a  vmovaps xmm6, [rsp+0x60]
00007f582cdda6a0  vmovaps xmm7, [rsp+0x70]
00007f582cdda6a6  vmovaps xmm9, [rsp+0x80]
00007f582cdda6af  vmovaps xmm10, [rsp+0x90]
00007f582cdda6b8  vmovaps xmm11, [rsp+0xA0]
00007f582cdda6c1  vmovaps xmm12, [rsp+0xB0]
00007f582cdda6ca  vmovaps xmm13, [rsp+0xC0]
00007f582cdda6d3  vmovaps xmm14, [rsp+0xD0]
00007f582cdda6dc  vmovaps xmm15, [rsp+0xE0]
00007f582cdda6e5  add rsp, 0xF0
00007f582cdda6ec  pop r11
00007f582cdda6ee  pop r10
00007f582cdda6f0  pop r9
00007f582cdda6f2  pop r8
00007f582cdda6f4  pop rsi
00007f582cdda6f5  pop rdi
00007f582cdda6f6  pop rdx
00007f582cdda6f7  pop rcx
00007f582cdda6f8  pop rax
00007f582cdda6f9  add rsp, 0x08
00007f582cdda6fd  jmp 0x00007F582CDD648A
00007f582cdda702  sub rsp, 0x08
00007f582cdda706  push rax
00007f582cdda707  push rcx
00007f582cdda708  push rdx
00007f582cdda709  push rdi
00007f582cdda70a  push rsi
00007f582cdda70b  push r8
00007f582cdda70d  push r9
00007f582cdda70f  push r10
00007f582cdda711  push r11
00007f582cdda713  sub rsp, 0xF0
00007f582cdda71a  vmovaps [rsp], xmm0
00007f582cdda71f  vmovaps [rsp+0x10], xmm1
00007f582cdda725  vmovaps [rsp+0x20], xmm2
00007f582cdda72b  vmovaps [rsp+0x30], xmm3
00007f582cdda731  vmovaps [rsp+0x40], xmm4
00007f582cdda737  vmovaps [rsp+0x50], xmm5
00007f582cdda73d  vmovaps [rsp+0x60], xmm6
00007f582cdda743  vmovaps [rsp+0x70], xmm7
00007f582cdda749  vmovaps [rsp+0x80], xmm8
00007f582cdda752  vmovaps [rsp+0x90], xmm9
00007f582cdda75b  vmovaps [rsp+0xA0], xmm10
00007f582cdda764  vmovaps [rsp+0xB0], xmm11
00007f582cdda76d  vmovaps [rsp+0xC0], xmm12
00007f582cdda776  vmovaps [rsp+0xD0], xmm13
00007f582cdda77f  vmovaps [rsp+0xE0], xmm14
00007f582cdda788  sub rsp, 0x30
00007f582cdda78c  movaps [rsp], xmm15
00007f582cdda791  movaps [rsp+0x10], xmm11
00007f582cdda797  movaps [rsp+0x20], xmm6
00007f582cdda79c  lea rdi, [rsp]
00007f582cdda7a0  mov esi, 0x00
00007f582cdda7a5  mov rax, 0x653B0D9BF530
00007f582cdda7af  call rax
00007f582cdda7b1  movaps xmm15, [rsp]
00007f582cdda7b6  add rsp, 0x30
00007f582cdda7ba  vmovaps xmm0, [rsp]
00007f582cdda7bf  vmovaps xmm1, [rsp+0x10]
00007f582cdda7c5  vmovaps xmm2, [rsp+0x20]
00007f582cdda7cb  vmovaps xmm3, [rsp+0x30]
00007f582cdda7d1  vmovaps xmm4, [rsp+0x40]
00007f582cdda7d7  vmovaps xmm5, [rsp+0x50]
00007f582cdda7dd  vmovaps xmm6, [rsp+0x60]
00007f582cdda7e3  vmovaps xmm7, [rsp+0x70]
00007f582cdda7e9  vmovaps xmm8, [rsp+0x80]
00007f582cdda7f2  vmovaps xmm9, [rsp+0x90]
00007f582cdda7fb  vmovaps xmm10, [rsp+0xA0]
00007f582cdda804  vmovaps xmm11, [rsp+0xB0]
00007f582cdda80d  vmovaps xmm12, [rsp+0xC0]
00007f582cdda816  vmovaps xmm13, [rsp+0xD0]
00007f582cdda81f  vmovaps xmm14, [rsp+0xE0]
00007f582cdda828  add rsp, 0xF0
00007f582cdda82f  pop r11
00007f582cdda831  pop r10
00007f582cdda833  pop r9
00007f582cdda835  pop r8
00007f582cdda837  pop rsi
00007f582cdda838  pop rdi
00007f582cdda839  pop rdx
00007f582cdda83a  pop rcx
00007f582cdda83b  pop rax
00007f582cdda83c  add rsp, 0x08
00007f582cdda840  jmp 0x00007F582CDD64A5
00007f582cdda845  sub rsp, 0x08
00007f582cdda849  push rax
00007f582cdda84a  push rcx
00007f582cdda84b  push rdx
00007f582cdda84c  push rdi
00007f582cdda84d  push rsi
00007f582cdda84e  push r8
00007f582cdda850  push r9
00007f582cdda852  push r10
00007f582cdda854  push r11
00007f582cdda856  sub rsp, 0xF0
00007f582cdda85d  vmovaps [rsp], xmm0
00007f582cdda862  vmovaps [rsp+0x10], xmm1
00007f582cdda868  vmovaps [rsp+0x20], xmm2
00007f582cdda86e  vmovaps [rsp+0x30], xmm3
00007f582cdda874  vmovaps [rsp+0x40], xmm4
00007f582cdda87a  vmovaps [rsp+0x50], xmm5
00007f582cdda880  vmovaps [rsp+0x60], xmm6
00007f582cdda886  vmovaps [rsp+0x70], xmm8
00007f582cdda88c  vmovaps [rsp+0x80], xmm9
00007f582cdda895  vmovaps [rsp+0x90], xmm10
00007f582cdda89e  vmovaps [rsp+0xA0], xmm11
00007f582cdda8a7  vmovaps [rsp+0xB0], xmm12
00007f582cdda8b0  vmovaps [rsp+0xC0], xmm13
00007f582cdda8b9  vmovaps [rsp+0xD0], xmm14
00007f582cdda8c2  vmovaps [rsp+0xE0], xmm15
00007f582cdda8cb  sub rsp, 0x30
00007f582cdda8cf  movaps [rsp], xmm7
00007f582cdda8d3  movaps [rsp+0x10], xmm11
00007f582cdda8d9  movaps [rsp+0x20], xmm9
00007f582cdda8df  lea rdi, [rsp]
00007f582cdda8e3  mov esi, 0x00
00007f582cdda8e8  mov rax, 0x653B0D9BF530
00007f582cdda8f2  call rax
00007f582cdda8f4  movaps xmm7, [rsp]
00007f582cdda8f8  add rsp, 0x30
00007f582cdda8fc  vmovaps xmm0, [rsp]
00007f582cdda901  vmovaps xmm1, [rsp+0x10]
00007f582cdda907  vmovaps xmm2, [rsp+0x20]
00007f582cdda90d  vmovaps xmm3, [rsp+0x30]
00007f582cdda913  vmovaps xmm4, [rsp+0x40]
00007f582cdda919  vmovaps xmm5, [rsp+0x50]
00007f582cdda91f  vmovaps xmm6, [rsp+0x60]
00007f582cdda925  vmovaps xmm8, [rsp+0x70]
00007f582cdda92b  vmovaps xmm9, [rsp+0x80]
00007f582cdda934  vmovaps xmm10, [rsp+0x90]
00007f582cdda93d  vmovaps xmm11, [rsp+0xA0]
00007f582cdda946  vmovaps xmm12, [rsp+0xB0]
00007f582cdda94f  vmovaps xmm13, [rsp+0xC0]
00007f582cdda958  vmovaps xmm14, [rsp+0xD0]
00007f582cdda961  vmovaps xmm15, [rsp+0xE0]
00007f582cdda96a  add rsp, 0xF0
00007f582cdda971  pop r11
00007f582cdda973  pop r10
00007f582cdda975  pop r9
00007f582cdda977  pop r8
00007f582cdda979  pop rsi
00007f582cdda97a  pop rdi
00007f582cdda97b  pop rdx
00007f582cdda97c  pop rcx
00007f582cdda97d  pop rax
00007f582cdda97e  add rsp, 0x08
00007f582cdda982  jmp 0x00007F582CDD64D2
00007f582cdda987  sub rsp, 0x08
00007f582cdda98b  push rax
00007f582cdda98c  push rcx
00007f582cdda98d  push rdx
00007f582cdda98e  push rdi
00007f582cdda98f  push rsi
00007f582cdda990  push r8
00007f582cdda992  push r9
00007f582cdda994  push r10
00007f582cdda996  push r11
00007f582cdda998  sub rsp, 0xF0
00007f582cdda99f  vmovaps [rsp], xmm0
00007f582cdda9a4  vmovaps [rsp+0x10], xmm1
00007f582cdda9aa  vmovaps [rsp+0x20], xmm2
00007f582cdda9b0  vmovaps [rsp+0x30], xmm3
00007f582cdda9b6  vmovaps [rsp+0x40], xmm4
00007f582cdda9bc  vmovaps [rsp+0x50], xmm5
00007f582cdda9c2  vmovaps [rsp+0x60], xmm6
00007f582cdda9c8  vmovaps [rsp+0x70], xmm7
00007f582cdda9ce  vmovaps [rsp+0x80], xmm8
00007f582cdda9d7  vmovaps [rsp+0x90], xmm9
00007f582cdda9e0  vmovaps [rsp+0xA0], xmm10
00007f582cdda9e9  vmovaps [rsp+0xB0], xmm12
00007f582cdda9f2  vmovaps [rsp+0xC0], xmm13
00007f582cdda9fb  vmovaps [rsp+0xD0], xmm14
00007f582cddaa04  vmovaps [rsp+0xE0], xmm15
00007f582cddaa0d  sub rsp, 0x30
00007f582cddaa11  movaps [rsp], xmm11
00007f582cddaa16  movaps [rsp+0x10], xmm10
00007f582cddaa1c  movaps [rsp+0x20], xmm14
00007f582cddaa22  lea rdi, [rsp]
00007f582cddaa26  mov esi, 0x00
00007f582cddaa2b  mov rax, 0x653B0D9BF530
00007f582cddaa35  call rax
00007f582cddaa37  movaps xmm11, [rsp]
00007f582cddaa3c  add rsp, 0x30
00007f582cddaa40  vmovaps xmm0, [rsp]
00007f582cddaa45  vmovaps xmm1, [rsp+0x10]
00007f582cddaa4b  vmovaps xmm2, [rsp+0x20]
00007f582cddaa51  vmovaps xmm3, [rsp+0x30]
00007f582cddaa57  vmovaps xmm4, [rsp+0x40]
00007f582cddaa5d  vmovaps xmm5, [rsp+0x50]
00007f582cddaa63  vmovaps xmm6, [rsp+0x60]
00007f582cddaa69  vmovaps xmm7, [rsp+0x70]
00007f582cddaa6f  vmovaps xmm8, [rsp+0x80]
00007f582cddaa78  vmovaps xmm9, [rsp+0x90]
00007f582cddaa81  vmovaps xmm10, [rsp+0xA0]
00007f582cddaa8a  vmovaps xmm12, [rsp+0xB0]
00007f582cddaa93  vmovaps xmm13, [rsp+0xC0]
00007f582cddaa9c  vmovaps xmm14, [rsp+0xD0]
00007f582cddaaa5  vmovaps xmm15, [rsp+0xE0]
00007f582cddaaae  add rsp, 0xF0
00007f582cddaab5  pop r11
00007f582cddaab7  pop r10
00007f582cddaab9  pop r9
00007f582cddaabb  pop r8
00007f582cddaabd  pop rsi
00007f582cddaabe  pop rdi
00007f582cddaabf  pop rdx
00007f582cddaac0  pop rcx
00007f582cddaac1  pop rax
00007f582cddaac2  add rsp, 0x08
00007f582cddaac6  jmp 0x00007F582CDD64ED
00007f582cddaacb  call 0x00007F582CCE45A0
00007f582cddaad0  jmp 0x00007F582CDD64F7
00007f582cddaad5  sub rsp, 0x08
00007f582cddaad9  push rax
00007f582cddaada  push rcx
00007f582cddaadb  push rdx
00007f582cddaadc  push rdi
00007f582cddaadd  push rsi
00007f582cddaade  push r8
00007f582cddaae0  push r9
00007f582cddaae2  push r10
00007f582cddaae4  push r11
00007f582cddaae6  sub rsp, 0xF0
00007f582cddaaed  vmovaps [rsp], xmm0
00007f582cddaaf2  vmovaps [rsp+0x10], xmm1
00007f582cddaaf8  vmovaps [rsp+0x20], xmm2
00007f582cddaafe  vmovaps [rsp+0x30], xmm3
00007f582cddab04  vmovaps [rsp+0x40], xmm4
00007f582cddab0a  vmovaps [rsp+0x50], xmm5
00007f582cddab10  vmovaps [rsp+0x60], xmm6
00007f582cddab16  vmovaps [rsp+0x70], xmm7
00007f582cddab1c  vmovaps [rsp+0x80], xmm8
00007f582cddab25  vmovaps [rsp+0x90], xmm9
00007f582cddab2e  vmovaps [rsp+0xA0], xmm11
00007f582cddab37  vmovaps [rsp+0xB0], xmm12
00007f582cddab40  vmovaps [rsp+0xC0], xmm13
00007f582cddab49  vmovaps [rsp+0xD0], xmm14
00007f582cddab52  vmovaps [rsp+0xE0], xmm15
00007f582cddab5b  sub rsp, 0x30
00007f582cddab5f  movaps [rsp], xmm10
00007f582cddab64  movaps [rsp+0x10], xmm1
00007f582cddab69  movaps [rsp+0x20], xmm12
00007f582cddab6f  lea rdi, [rsp]
00007f582cddab73  mov esi, 0x00
00007f582cddab78  mov rax, 0x653B0D9BF530
00007f582cddab82  call rax
00007f582cddab84  movaps xmm10, [rsp]
00007f582cddab89  add rsp, 0x30
00007f582cddab8d  vmovaps xmm0, [rsp]
00007f582cddab92  vmovaps xmm1, [rsp+0x10]
00007f582cddab98  vmovaps xmm2, [rsp+0x20]
00007f582cddab9e  vmovaps xmm3, [rsp+0x30]
00007f582cddaba4  vmovaps xmm4, [rsp+0x40]
00007f582cddabaa  vmovaps xmm5, [rsp+0x50]
00007f582cddabb0  vmovaps xmm6, [rsp+0x60]
00007f582cddabb6  vmovaps xmm7, [rsp+0x70]
00007f582cddabbc  vmovaps xmm8, [rsp+0x80]
00007f582cddabc5  vmovaps xmm9, [rsp+0x90]
00007f582cddabce  vmovaps xmm11, [rsp+0xA0]
00007f582cddabd7  vmovaps xmm12, [rsp+0xB0]
00007f582cddabe0  vmovaps xmm13, [rsp+0xC0]
00007f582cddabe9  vmovaps xmm14, [rsp+0xD0]
00007f582cddabf2  vmovaps xmm15, [rsp+0xE0]
00007f582cddabfb  add rsp, 0xF0
00007f582cddac02  pop r11
00007f582cddac04  pop r10
00007f582cddac06  pop r9
00007f582cddac08  pop r8
00007f582cddac0a  pop rsi
00007f582cddac0b  pop rdi
00007f582cddac0c  pop rdx
00007f582cddac0d  pop rcx
00007f582cddac0e  pop rax
00007f582cddac0f  add rsp, 0x08
00007f582cddac13  jmp 0x00007F582CDD651A
00007f582cddac18  sub rsp, 0x08
00007f582cddac1c  push rax
00007f582cddac1d  push rcx
00007f582cddac1e  push rdx
00007f582cddac1f  push rdi
00007f582cddac20  push rsi
00007f582cddac21  push r8
00007f582cddac23  push r9
00007f582cddac25  push r10
00007f582cddac27  push r11
00007f582cddac29  sub rsp, 0xF0
00007f582cddac30  vmovaps [rsp], xmm0
00007f582cddac35  vmovaps [rsp+0x10], xmm1
00007f582cddac3b  vmovaps [rsp+0x20], xmm2
00007f582cddac41  vmovaps [rsp+0x30], xmm3
00007f582cddac47  vmovaps [rsp+0x40], xmm4
00007f582cddac4d  vmovaps [rsp+0x50], xmm5
00007f582cddac53  vmovaps [rsp+0x60], xmm6
00007f582cddac59  vmovaps [rsp+0x70], xmm7
00007f582cddac5f  vmovaps [rsp+0x80], xmm8
00007f582cddac68  vmovaps [rsp+0x90], xmm9
00007f582cddac71  vmovaps [rsp+0xA0], xmm10
00007f582cddac7a  vmovaps [rsp+0xB0], xmm11
00007f582cddac83  vmovaps [rsp+0xC0], xmm13
00007f582cddac8c  vmovaps [rsp+0xD0], xmm14
00007f582cddac95  vmovaps [rsp+0xE0], xmm15
00007f582cddac9e  sub rsp, 0x30
00007f582cddaca2  movaps [rsp], xmm12
00007f582cddaca7  movaps [rsp+0x10], xmm14
00007f582cddacad  movaps [rsp+0x20], xmm1
00007f582cddacb2  lea rdi, [rsp]
00007f582cddacb6  mov esi, 0x00
00007f582cddacbb  mov rax, 0x653B0D9BF530
00007f582cddacc5  call rax
00007f582cddacc7  movaps xmm12, [rsp]
00007f582cddaccc  add rsp, 0x30
00007f582cddacd0  vmovaps xmm0, [rsp]
00007f582cddacd5  vmovaps xmm1, [rsp+0x10]
00007f582cddacdb  vmovaps xmm2, [rsp+0x20]
00007f582cddace1  vmovaps xmm3, [rsp+0x30]
00007f582cddace7  vmovaps xmm4, [rsp+0x40]
00007f582cddaced  vmovaps xmm5, [rsp+0x50]
00007f582cddacf3  vmovaps xmm6, [rsp+0x60]
00007f582cddacf9  vmovaps xmm7, [rsp+0x70]
00007f582cddacff  vmovaps xmm8, [rsp+0x80]
00007f582cddad08  vmovaps xmm9, [rsp+0x90]
00007f582cddad11  vmovaps xmm10, [rsp+0xA0]
00007f582cddad1a  vmovaps xmm11, [rsp+0xB0]
00007f582cddad23  vmovaps xmm13, [rsp+0xC0]
00007f582cddad2c  vmovaps xmm14, [rsp+0xD0]
00007f582cddad35  vmovaps xmm15, [rsp+0xE0]
00007f582cddad3e  add rsp, 0xF0
00007f582cddad45  pop r11
00007f582cddad47  pop r10
00007f582cddad49  pop r9
00007f582cddad4b  pop r8
00007f582cddad4d  pop rsi
00007f582cddad4e  pop rdi
00007f582cddad4f  pop rdx
00007f582cddad50  pop rcx
00007f582cddad51  pop rax
00007f582cddad52  add rsp, 0x08
00007f582cddad56  jmp 0x00007F582CDD6549
00007f582cddad5b  sub rsp, 0x08
00007f582cddad5f  push rax
00007f582cddad60  push rcx
00007f582cddad61  push rdx
00007f582cddad62  push rdi
00007f582cddad63  push rsi
00007f582cddad64  push r8
00007f582cddad66  push r9
00007f582cddad68  push r10
00007f582cddad6a  push r11
00007f582cddad6c  sub rsp, 0xF0
00007f582cddad73  vmovaps [rsp], xmm0
00007f582cddad78  vmovaps [rsp+0x10], xmm1
00007f582cddad7e  vmovaps [rsp+0x20], xmm2
00007f582cddad84  vmovaps [rsp+0x30], xmm3
00007f582cddad8a  vmovaps [rsp+0x40], xmm4
00007f582cddad90  vmovaps [rsp+0x50], xmm5
00007f582cddad96  vmovaps [rsp+0x60], xmm6
00007f582cddad9c  vmovaps [rsp+0x70], xmm7
00007f582cddada2  vmovaps [rsp+0x80], xmm8
00007f582cddadab  vmovaps [rsp+0x90], xmm9
00007f582cddadb4  vmovaps [rsp+0xA0], xmm10
00007f582cddadbd  vmovaps [rsp+0xB0], xmm11
00007f582cddadc6  vmovaps [rsp+0xC0], xmm12
00007f582cddadcf  vmovaps [rsp+0xD0], xmm13
00007f582cddadd8  vmovaps [rsp+0xE0], xmm15
00007f582cddade1  sub rsp, 0x30
00007f582cddade5  movaps [rsp], xmm14
00007f582cddadea  movaps [rsp+0x10], xmm9
00007f582cddadf0  movaps [rsp+0x20], xmm1
00007f582cddadf5  lea rdi, [rsp]
00007f582cddadf9  mov esi, 0x00
00007f582cddadfe  mov rax, 0x653B0D9BF530
00007f582cddae08  call rax
00007f582cddae0a  movaps xmm14, [rsp]
00007f582cddae0f  add rsp, 0x30
00007f582cddae13  vmovaps xmm0, [rsp]
00007f582cddae18  vmovaps xmm1, [rsp+0x10]
00007f582cddae1e  vmovaps xmm2, [rsp+0x20]
00007f582cddae24  vmovaps xmm3, [rsp+0x30]
00007f582cddae2a  vmovaps xmm4, [rsp+0x40]
00007f582cddae30  vmovaps xmm5, [rsp+0x50]
00007f582cddae36  vmovaps xmm6, [rsp+0x60]
00007f582cddae3c  vmovaps xmm7, [rsp+0x70]
00007f582cddae42  vmovaps xmm8, [rsp+0x80]
00007f582cddae4b  vmovaps xmm9, [rsp+0x90]
00007f582cddae54  vmovaps xmm10, [rsp+0xA0]
00007f582cddae5d  vmovaps xmm11, [rsp+0xB0]
00007f582cddae66  vmovaps xmm12, [rsp+0xC0]
00007f582cddae6f  vmovaps xmm13, [rsp+0xD0]
00007f582cddae78  vmovaps xmm15, [rsp+0xE0]
00007f582cddae81  add rsp, 0xF0
00007f582cddae88  pop r11
00007f582cddae8a  pop r10
00007f582cddae8c  pop r9
00007f582cddae8e  pop r8
00007f582cddae90  pop rsi
00007f582cddae91  pop rdi
00007f582cddae92  pop rdx
00007f582cddae93  pop rcx
00007f582cddae94  pop rax
00007f582cddae95  add rsp, 0x08
00007f582cddae99  jmp 0x00007F582CDD6578
00007f582cddae9e  sub rsp, 0x08
00007f582cddaea2  push rax
00007f582cddaea3  push rcx
00007f582cddaea4  push rdx
00007f582cddaea5  push rdi
00007f582cddaea6  push rsi
00007f582cddaea7  push r8
00007f582cddaea9  push r9
00007f582cddaeab  push r10
00007f582cddaead  push r11
00007f582cddaeaf  sub rsp, 0xF0
00007f582cddaeb6  vmovaps [rsp], xmm0
00007f582cddaebb  vmovaps [rsp+0x10], xmm2
00007f582cddaec1  vmovaps [rsp+0x20], xmm3
00007f582cddaec7  vmovaps [rsp+0x30], xmm4
00007f582cddaecd  vmovaps [rsp+0x40], xmm5
00007f582cddaed3  vmovaps [rsp+0x50], xmm6
00007f582cddaed9  vmovaps [rsp+0x60], xmm7
00007f582cddaedf  vmovaps [rsp+0x70], xmm8
00007f582cddaee5  vmovaps [rsp+0x80], xmm9
00007f582cddaeee  vmovaps [rsp+0x90], xmm10
00007f582cddaef7  vmovaps [rsp+0xA0], xmm11
00007f582cddaf00  vmovaps [rsp+0xB0], xmm12
00007f582cddaf09  vmovaps [rsp+0xC0], xmm13
00007f582cddaf12  vmovaps [rsp+0xD0], xmm14
00007f582cddaf1b  vmovaps [rsp+0xE0], xmm15
00007f582cddaf24  sub rsp, 0x30
00007f582cddaf28  movaps [rsp], xmm1
00007f582cddaf2c  movaps [rsp+0x10], xmm13
00007f582cddaf32  movaps [rsp+0x20], xmm8
00007f582cddaf38  lea rdi, [rsp]
00007f582cddaf3c  mov esi, 0x00
00007f582cddaf41  mov rax, 0x653B0D9BF530
00007f582cddaf4b  call rax
00007f582cddaf4d  movaps xmm1, [rsp]
00007f582cddaf51  add rsp, 0x30
00007f582cddaf55  vmovaps xmm0, [rsp]
00007f582cddaf5a  vmovaps xmm2, [rsp+0x10]
00007f582cddaf60  vmovaps xmm3, [rsp+0x20]
00007f582cddaf66  vmovaps xmm4, [rsp+0x30]
00007f582cddaf6c  vmovaps xmm5, [rsp+0x40]
00007f582cddaf72  vmovaps xmm6, [rsp+0x50]
00007f582cddaf78  vmovaps xmm7, [rsp+0x60]
00007f582cddaf7e  vmovaps xmm8, [rsp+0x70]
00007f582cddaf84  vmovaps xmm9, [rsp+0x80]
00007f582cddaf8d  vmovaps xmm10, [rsp+0x90]
00007f582cddaf96  vmovaps xmm11, [rsp+0xA0]
00007f582cddaf9f  vmovaps xmm12, [rsp+0xB0]
00007f582cddafa8  vmovaps xmm13, [rsp+0xC0]
00007f582cddafb1  vmovaps xmm14, [rsp+0xD0]
00007f582cddafba  vmovaps xmm15, [rsp+0xE0]
00007f582cddafc3  add rsp, 0xF0
00007f582cddafca  pop r11
00007f582cddafcc  pop r10
00007f582cddafce  pop r9
00007f582cddafd0  pop r8
00007f582cddafd2  pop rsi
00007f582cddafd3  pop rdi
00007f582cddafd4  pop rdx
00007f582cddafd5  pop rcx
00007f582cddafd6  pop rax
00007f582cddafd7  add rsp, 0x08
00007f582cddafdb  jmp 0x00007F582CDD659A
00007f582cddafe0  call 0x00007F582CC0C260
00007f582cddafe5  jmp 0x00007F582CDD65A8
00007f582cddafea  call 0x00007F582CCDE950
00007f582cddafef  jmp 0x00007F582CDD65B2
00007f582cddaff4  sub rsp, 0x08
00007f582cddaff8  push rax
00007f582cddaff9  push rcx
00007f582cddaffa  push rdx
00007f582cddaffb  push rdi
00007f582cddaffc  push rsi
00007f582cddaffd  push r8
00007f582cddafff  push r9
00007f582cddb001  push r10
00007f582cddb003  push r11
00007f582cddb005  sub rsp, 0xF0
00007f582cddb00c  vmovaps [rsp], xmm0
00007f582cddb011  vmovaps [rsp+0x10], xmm1
00007f582cddb017  vmovaps [rsp+0x20], xmm2
00007f582cddb01d  vmovaps [rsp+0x30], xmm3
00007f582cddb023  vmovaps [rsp+0x40], xmm4
00007f582cddb029  vmovaps [rsp+0x50], xmm5
00007f582cddb02f  vmovaps [rsp+0x60], xmm6
00007f582cddb035  vmovaps [rsp+0x70], xmm7
00007f582cddb03b  vmovaps [rsp+0x80], xmm9
00007f582cddb044  vmovaps [rsp+0x90], xmm10
00007f582cddb04d  vmovaps [rsp+0xA0], xmm11
00007f582cddb056  vmovaps [rsp+0xB0], xmm12
00007f582cddb05f  vmovaps [rsp+0xC0], xmm13
00007f582cddb068  vmovaps [rsp+0xD0], xmm14
00007f582cddb071  vmovaps [rsp+0xE0], xmm15
00007f582cddb07a  sub rsp, 0x30
00007f582cddb07e  movaps [rsp], xmm8
00007f582cddb083  movaps [rsp+0x10], xmm15
00007f582cddb089  movaps [rsp+0x20], xmm7
00007f582cddb08e  lea rdi, [rsp]
00007f582cddb092  mov esi, 0x00
00007f582cddb097  mov rax, 0x653B0D9BF530
00007f582cddb0a1  call rax
00007f582cddb0a3  movaps xmm8, [rsp]
00007f582cddb0a8  add rsp, 0x30
00007f582cddb0ac  vmovaps xmm0, [rsp]
00007f582cddb0b1  vmovaps xmm1, [rsp+0x10]
00007f582cddb0b7  vmovaps xmm2, [rsp+0x20]
00007f582cddb0bd  vmovaps xmm3, [rsp+0x30]
00007f582cddb0c3  vmovaps xmm4, [rsp+0x40]
00007f582cddb0c9  vmovaps xmm5, [rsp+0x50]
00007f582cddb0cf  vmovaps xmm6, [rsp+0x60]
00007f582cddb0d5  vmovaps xmm7, [rsp+0x70]
00007f582cddb0db  vmovaps xmm9, [rsp+0x80]
00007f582cddb0e4  vmovaps xmm10, [rsp+0x90]
00007f582cddb0ed  vmovaps xmm11, [rsp+0xA0]
00007f582cddb0f6  vmovaps xmm12, [rsp+0xB0]
00007f582cddb0ff  vmovaps xmm13, [rsp+0xC0]
00007f582cddb108  vmovaps xmm14, [rsp+0xD0]
00007f582cddb111  vmovaps xmm15, [rsp+0xE0]
00007f582cddb11a  add rsp, 0xF0
00007f582cddb121  pop r11
00007f582cddb123  pop r10
00007f582cddb125  pop r9
00007f582cddb127  pop r8
00007f582cddb129  pop rsi
00007f582cddb12a  pop rdi
00007f582cddb12b  pop rdx
00007f582cddb12c  pop rcx
00007f582cddb12d  pop rax
00007f582cddb12e  add rsp, 0x08
00007f582cddb132  jmp 0x00007F582CDD65D4
00007f582cddb137  sub rsp, 0x08
00007f582cddb13b  push rax
00007f582cddb13c  push rcx
00007f582cddb13d  push rdx
00007f582cddb13e  push rdi
00007f582cddb13f  push rsi
00007f582cddb140  push r8
00007f582cddb142  push r9
00007f582cddb144  push r10
00007f582cddb146  push r11
00007f582cddb148  sub rsp, 0xF0
00007f582cddb14f  vmovaps [rsp], xmm0
00007f582cddb154  vmovaps [rsp+0x10], xmm1
00007f582cddb15a  vmovaps [rsp+0x20], xmm2
00007f582cddb160  vmovaps [rsp+0x30], xmm3
00007f582cddb166  vmovaps [rsp+0x40], xmm4
00007f582cddb16c  vmovaps [rsp+0x50], xmm5
00007f582cddb172  vmovaps [rsp+0x60], xmm6
00007f582cddb178  vmovaps [rsp+0x70], xmm8
00007f582cddb17e  vmovaps [rsp+0x80], xmm9
00007f582cddb187  vmovaps [rsp+0x90], xmm10
00007f582cddb190  vmovaps [rsp+0xA0], xmm11
00007f582cddb199  vmovaps [rsp+0xB0], xmm12
00007f582cddb1a2  vmovaps [rsp+0xC0], xmm13
00007f582cddb1ab  vmovaps [rsp+0xD0], xmm14
00007f582cddb1b4  vmovaps [rsp+0xE0], xmm15
00007f582cddb1bd  sub rsp, 0x30
00007f582cddb1c1  movaps [rsp], xmm7
00007f582cddb1c5  movaps [rsp+0x10], xmm9
00007f582cddb1cb  movaps [rsp+0x20], xmm15
00007f582cddb1d1  lea rdi, [rsp]
00007f582cddb1d5  mov esi, 0x00
00007f582cddb1da  mov rax, 0x653B0D9BF530
00007f582cddb1e4  call rax
00007f582cddb1e6  movaps xmm7, [rsp]
00007f582cddb1ea  add rsp, 0x30
00007f582cddb1ee  vmovaps xmm0, [rsp]
00007f582cddb1f3  vmovaps xmm1, [rsp+0x10]
00007f582cddb1f9  vmovaps xmm2, [rsp+0x20]
00007f582cddb1ff  vmovaps xmm3, [rsp+0x30]
00007f582cddb205  vmovaps xmm4, [rsp+0x40]
00007f582cddb20b  vmovaps xmm5, [rsp+0x50]
00007f582cddb211  vmovaps xmm6, [rsp+0x60]
00007f582cddb217  vmovaps xmm8, [rsp+0x70]
00007f582cddb21d  vmovaps xmm9, [rsp+0x80]
00007f582cddb226  vmovaps xmm10, [rsp+0x90]
00007f582cddb22f  vmovaps xmm11, [rsp+0xA0]
00007f582cddb238  vmovaps xmm12, [rsp+0xB0]
00007f582cddb241  vmovaps xmm13, [rsp+0xC0]
00007f582cddb24a  vmovaps xmm14, [rsp+0xD0]
00007f582cddb253  vmovaps xmm15, [rsp+0xE0]
00007f582cddb25c  add rsp, 0xF0
00007f582cddb263  pop r11
00007f582cddb265  pop r10
00007f582cddb267  pop r9
00007f582cddb269  pop r8
00007f582cddb26b  pop rsi
00007f582cddb26c  pop rdi
00007f582cddb26d  pop rdx
00007f582cddb26e  pop rcx
00007f582cddb26f  pop rax
00007f582cddb270  add rsp, 0x08
00007f582cddb274  jmp 0x00007F582CDD6601
00007f582cddb279  sub rsp, 0x08
00007f582cddb27d  push rax
00007f582cddb27e  push rcx
00007f582cddb27f  push rdx
00007f582cddb280  push rdi
00007f582cddb281  push rsi
00007f582cddb282  push r8
00007f582cddb284  push r9
00007f582cddb286  push r10
00007f582cddb288  push r11
00007f582cddb28a  sub rsp, 0xF0
00007f582cddb291  vmovaps [rsp], xmm0
00007f582cddb296  vmovaps [rsp+0x10], xmm1
00007f582cddb29c  vmovaps [rsp+0x20], xmm2
00007f582cddb2a2  vmovaps [rsp+0x30], xmm3
00007f582cddb2a8  vmovaps [rsp+0x40], xmm4
00007f582cddb2ae  vmovaps [rsp+0x50], xmm5
00007f582cddb2b4  vmovaps [rsp+0x60], xmm6
00007f582cddb2ba  vmovaps [rsp+0x70], xmm7
00007f582cddb2c0  vmovaps [rsp+0x80], xmm8
00007f582cddb2c9  vmovaps [rsp+0x90], xmm10
00007f582cddb2d2  vmovaps [rsp+0xA0], xmm11
00007f582cddb2db  vmovaps [rsp+0xB0], xmm12
00007f582cddb2e4  vmovaps [rsp+0xC0], xmm13
00007f582cddb2ed  vmovaps [rsp+0xD0], xmm14
00007f582cddb2f6  vmovaps [rsp+0xE0], xmm15
00007f582cddb2ff  sub rsp, 0x30
00007f582cddb303  movaps [rsp], xmm9
00007f582cddb308  movaps [rsp+0x10], xmm13
00007f582cddb30e  movaps [rsp+0x20], xmm15
00007f582cddb314  lea rdi, [rsp]
00007f582cddb318  mov esi, 0x00
00007f582cddb31d  mov rax, 0x653B0D9BF530
00007f582cddb327  call rax
00007f582cddb329  movaps xmm9, [rsp]
00007f582cddb32e  add rsp, 0x30
00007f582cddb332  vmovaps xmm0, [rsp]
00007f582cddb337  vmovaps xmm1, [rsp+0x10]
00007f582cddb33d  vmovaps xmm2, [rsp+0x20]
00007f582cddb343  vmovaps xmm3, [rsp+0x30]
00007f582cddb349  vmovaps xmm4, [rsp+0x40]
00007f582cddb34f  vmovaps xmm5, [rsp+0x50]
00007f582cddb355  vmovaps xmm6, [rsp+0x60]
00007f582cddb35b  vmovaps xmm7, [rsp+0x70]
00007f582cddb361  vmovaps xmm8, [rsp+0x80]
00007f582cddb36a  vmovaps xmm10, [rsp+0x90]
00007f582cddb373  vmovaps xmm11, [rsp+0xA0]
00007f582cddb37c  vmovaps xmm12, [rsp+0xB0]
00007f582cddb385  vmovaps xmm13, [rsp+0xC0]
00007f582cddb38e  vmovaps xmm14, [rsp+0xD0]
00007f582cddb397  vmovaps xmm15, [rsp+0xE0]
00007f582cddb3a0  add rsp, 0xF0
00007f582cddb3a7  pop r11
00007f582cddb3a9  pop r10
00007f582cddb3ab  pop r9
00007f582cddb3ad  pop r8
00007f582cddb3af  pop rsi
00007f582cddb3b0  pop rdi
00007f582cddb3b1  pop rdx
00007f582cddb3b2  pop rcx
00007f582cddb3b3  pop rax
00007f582cddb3b4  add rsp, 0x08
00007f582cddb3b8  jmp 0x00007F582CDD662F
00007f582cddb3bd  sub rsp, 0x08
00007f582cddb3c1  push rax
00007f582cddb3c2  push rcx
00007f582cddb3c3  push rdx
00007f582cddb3c4  push rdi
00007f582cddb3c5  push rsi
00007f582cddb3c6  push r8
00007f582cddb3c8  push r9
00007f582cddb3ca  push r10
00007f582cddb3cc  push r11
00007f582cddb3ce  sub rsp, 0xF0
00007f582cddb3d5  vmovaps [rsp], xmm0
00007f582cddb3da  vmovaps [rsp+0x10], xmm1
00007f582cddb3e0  vmovaps [rsp+0x20], xmm2
00007f582cddb3e6  vmovaps [rsp+0x30], xmm3
00007f582cddb3ec  vmovaps [rsp+0x40], xmm4
00007f582cddb3f2  vmovaps [rsp+0x50], xmm5
00007f582cddb3f8  vmovaps [rsp+0x60], xmm6
00007f582cddb3fe  vmovaps [rsp+0x70], xmm7
00007f582cddb404  vmovaps [rsp+0x80], xmm8
00007f582cddb40d  vmovaps [rsp+0x90], xmm9
00007f582cddb416  vmovaps [rsp+0xA0], xmm10
00007f582cddb41f  vmovaps [rsp+0xB0], xmm11
00007f582cddb428  vmovaps [rsp+0xC0], xmm12
00007f582cddb431  vmovaps [rsp+0xD0], xmm13
00007f582cddb43a  vmovaps [rsp+0xE0], xmm14
00007f582cddb443  sub rsp, 0x30
00007f582cddb447  movaps [rsp], xmm15
00007f582cddb44c  movaps [rsp+0x10], xmm11
00007f582cddb452  movaps [rsp+0x20], xmm12
00007f582cddb458  lea rdi, [rsp]
00007f582cddb45c  mov esi, 0x00
00007f582cddb461  mov rax, 0x653B0D9BF530
00007f582cddb46b  call rax
00007f582cddb46d  movaps xmm15, [rsp]
00007f582cddb472  add rsp, 0x30
00007f582cddb476  vmovaps xmm0, [rsp]
00007f582cddb47b  vmovaps xmm1, [rsp+0x10]
00007f582cddb481  vmovaps xmm2, [rsp+0x20]
00007f582cddb487  vmovaps xmm3, [rsp+0x30]
00007f582cddb48d  vmovaps xmm4, [rsp+0x40]
00007f582cddb493  vmovaps xmm5, [rsp+0x50]
00007f582cddb499  vmovaps xmm6, [rsp+0x60]
00007f582cddb49f  vmovaps xmm7, [rsp+0x70]
00007f582cddb4a5  vmovaps xmm8, [rsp+0x80]
00007f582cddb4ae  vmovaps xmm9, [rsp+0x90]
00007f582cddb4b7  vmovaps xmm10, [rsp+0xA0]
00007f582cddb4c0  vmovaps xmm11, [rsp+0xB0]
00007f582cddb4c9  vmovaps xmm12, [rsp+0xC0]
00007f582cddb4d2  vmovaps xmm13, [rsp+0xD0]
00007f582cddb4db  vmovaps xmm14, [rsp+0xE0]
00007f582cddb4e4  add rsp, 0xF0
00007f582cddb4eb  pop r11
00007f582cddb4ed  pop r10
00007f582cddb4ef  pop r9
00007f582cddb4f1  pop r8
00007f582cddb4f3  pop rsi
00007f582cddb4f4  pop rdi
00007f582cddb4f5  pop rdx
00007f582cddb4f6  pop rcx
00007f582cddb4f7  pop rax
00007f582cddb4f8  add rsp, 0x08
00007f582cddb4fc  jmp 0x00007F582CDD664A
00007f582cddb501  sub rsp, 0x08
00007f582cddb505  push rax
00007f582cddb506  push rcx
00007f582cddb507  push rdx
00007f582cddb508  push rdi
00007f582cddb509  push rsi
00007f582cddb50a  push r8
00007f582cddb50c  push r9
00007f582cddb50e  push r10
00007f582cddb510  push r11
00007f582cddb512  sub rsp, 0xF0
00007f582cddb519  vmovaps [rsp], xmm0
00007f582cddb51e  vmovaps [rsp+0x10], xmm1
00007f582cddb524  vmovaps [rsp+0x20], xmm2
00007f582cddb52a  vmovaps [rsp+0x30], xmm3
00007f582cddb530  vmovaps [rsp+0x40], xmm4
00007f582cddb536  vmovaps [rsp+0x50], xmm5
00007f582cddb53c  vmovaps [rsp+0x60], xmm6
00007f582cddb542  vmovaps [rsp+0x70], xmm7
00007f582cddb548  vmovaps [rsp+0x80], xmm8
00007f582cddb551  vmovaps [rsp+0x90], xmm9
00007f582cddb55a  vmovaps [rsp+0xA0], xmm10
00007f582cddb563  vmovaps [rsp+0xB0], xmm11
00007f582cddb56c  vmovaps [rsp+0xC0], xmm12
00007f582cddb575  vmovaps [rsp+0xD0], xmm14
00007f582cddb57e  vmovaps [rsp+0xE0], xmm15
00007f582cddb587  sub rsp, 0x30
00007f582cddb58b  movaps [rsp], xmm13
00007f582cddb590  movaps [rsp+0x10], xmm10
00007f582cddb596  movaps [rsp+0x20], xmm14
00007f582cddb59c  lea rdi, [rsp]
00007f582cddb5a0  mov esi, 0x00
00007f582cddb5a5  mov rax, 0x653B0D9BF530
00007f582cddb5af  call rax
00007f582cddb5b1  movaps xmm13, [rsp]
00007f582cddb5b6  add rsp, 0x30
00007f582cddb5ba  vmovaps xmm0, [rsp]
00007f582cddb5bf  vmovaps xmm1, [rsp+0x10]
00007f582cddb5c5  vmovaps xmm2, [rsp+0x20]
00007f582cddb5cb  vmovaps xmm3, [rsp+0x30]
00007f582cddb5d1  vmovaps xmm4, [rsp+0x40]
00007f582cddb5d7  vmovaps xmm5, [rsp+0x50]
00007f582cddb5dd  vmovaps xmm6, [rsp+0x60]
00007f582cddb5e3  vmovaps xmm7, [rsp+0x70]
00007f582cddb5e9  vmovaps xmm8, [rsp+0x80]
00007f582cddb5f2  vmovaps xmm9, [rsp+0x90]
00007f582cddb5fb  vmovaps xmm10, [rsp+0xA0]
00007f582cddb604  vmovaps xmm11, [rsp+0xB0]
00007f582cddb60d  vmovaps xmm12, [rsp+0xC0]
00007f582cddb616  vmovaps xmm14, [rsp+0xD0]
00007f582cddb61f  vmovaps xmm15, [rsp+0xE0]
00007f582cddb628  add rsp, 0xF0
00007f582cddb62f  pop r11
00007f582cddb631  pop r10
00007f582cddb633  pop r9
00007f582cddb635  pop r8
00007f582cddb637  pop rsi
00007f582cddb638  pop rdi
00007f582cddb639  pop rdx
00007f582cddb63a  pop rcx
00007f582cddb63b  pop rax
00007f582cddb63c  add rsp, 0x08
00007f582cddb640  jmp 0x00007F582CDD666D
00007f582cddb645  sub rsp, 0x08
00007f582cddb649  push rax
00007f582cddb64a  push rcx
00007f582cddb64b  push rdx
00007f582cddb64c  push rdi
00007f582cddb64d  push rsi
00007f582cddb64e  push r8
00007f582cddb650  push r9
00007f582cddb652  push r10
00007f582cddb654  push r11
00007f582cddb656  sub rsp, 0xF0
00007f582cddb65d  vmovaps [rsp], xmm0
00007f582cddb662  vmovaps [rsp+0x10], xmm1
00007f582cddb668  vmovaps [rsp+0x20], xmm2
00007f582cddb66e  vmovaps [rsp+0x30], xmm3
00007f582cddb674  vmovaps [rsp+0x40], xmm4
00007f582cddb67a  vmovaps [rsp+0x50], xmm5
00007f582cddb680  vmovaps [rsp+0x60], xmm6
00007f582cddb686  vmovaps [rsp+0x70], xmm7
00007f582cddb68c  vmovaps [rsp+0x80], xmm8
00007f582cddb695  vmovaps [rsp+0x90], xmm9
00007f582cddb69e  vmovaps [rsp+0xA0], xmm10
00007f582cddb6a7  vmovaps [rsp+0xB0], xmm11
00007f582cddb6b0  vmovaps [rsp+0xC0], xmm12
00007f582cddb6b9  vmovaps [rsp+0xD0], xmm13
00007f582cddb6c2  vmovaps [rsp+0xE0], xmm15
00007f582cddb6cb  sub rsp, 0x30
00007f582cddb6cf  movaps [rsp], xmm14
00007f582cddb6d4  movaps [rsp+0x10], xmm1
00007f582cddb6d9  movaps [rsp+0x20], xmm7
00007f582cddb6de  lea rdi, [rsp]
00007f582cddb6e2  mov esi, 0x00
00007f582cddb6e7  mov rax, 0x653B0D9BF530
00007f582cddb6f1  call rax
00007f582cddb6f3  movaps xmm14, [rsp]
00007f582cddb6f8  add rsp, 0x30
00007f582cddb6fc  vmovaps xmm0, [rsp]
00007f582cddb701  vmovaps xmm1, [rsp+0x10]
00007f582cddb707  vmovaps xmm2, [rsp+0x20]
00007f582cddb70d  vmovaps xmm3, [rsp+0x30]
00007f582cddb713  vmovaps xmm4, [rsp+0x40]
00007f582cddb719  vmovaps xmm5, [rsp+0x50]
00007f582cddb71f  vmovaps xmm6, [rsp+0x60]
00007f582cddb725  vmovaps xmm7, [rsp+0x70]
00007f582cddb72b  vmovaps xmm8, [rsp+0x80]
00007f582cddb734  vmovaps xmm9, [rsp+0x90]
00007f582cddb73d  vmovaps xmm10, [rsp+0xA0]
00007f582cddb746  vmovaps xmm11, [rsp+0xB0]
00007f582cddb74f  vmovaps xmm12, [rsp+0xC0]
00007f582cddb758  vmovaps xmm13, [rsp+0xD0]
00007f582cddb761  vmovaps xmm15, [rsp+0xE0]
00007f582cddb76a  add rsp, 0xF0
00007f582cddb771  pop r11
00007f582cddb773  pop r10
00007f582cddb775  pop r9
00007f582cddb777  pop r8
00007f582cddb779  pop rsi
00007f582cddb77a  pop rdi
00007f582cddb77b  pop rdx
00007f582cddb77c  pop rcx
00007f582cddb77d  pop rax
00007f582cddb77e  add rsp, 0x08
00007f582cddb782  jmp 0x00007F582CDD6690
00007f582cddb787  sub rsp, 0x08
00007f582cddb78b  push rax
00007f582cddb78c  push rcx
00007f582cddb78d  push rdx
00007f582cddb78e  push rdi
00007f582cddb78f  push rsi
00007f582cddb790  push r8
00007f582cddb792  push r9
00007f582cddb794  push r10
00007f582cddb796  push r11
00007f582cddb798  sub rsp, 0xF0
00007f582cddb79f  vmovaps [rsp], xmm0
00007f582cddb7a4  vmovaps [rsp+0x10], xmm2
00007f582cddb7aa  vmovaps [rsp+0x20], xmm3
00007f582cddb7b0  vmovaps [rsp+0x30], xmm4
00007f582cddb7b6  vmovaps [rsp+0x40], xmm5
00007f582cddb7bc  vmovaps [rsp+0x50], xmm6
00007f582cddb7c2  vmovaps [rsp+0x60], xmm7
00007f582cddb7c8  vmovaps [rsp+0x70], xmm8
00007f582cddb7ce  vmovaps [rsp+0x80], xmm9
00007f582cddb7d7  vmovaps [rsp+0x90], xmm10
00007f582cddb7e0  vmovaps [rsp+0xA0], xmm11
00007f582cddb7e9  vmovaps [rsp+0xB0], xmm12
00007f582cddb7f2  vmovaps [rsp+0xC0], xmm13
00007f582cddb7fb  vmovaps [rsp+0xD0], xmm14
00007f582cddb804  vmovaps [rsp+0xE0], xmm15
00007f582cddb80d  sub rsp, 0x30
00007f582cddb811  movaps [rsp], xmm1
00007f582cddb815  movaps [rsp+0x10], xmm8
00007f582cddb81b  movaps [rsp+0x20], xmm9
00007f582cddb821  lea rdi, [rsp]
00007f582cddb825  mov esi, 0x00
00007f582cddb82a  mov rax, 0x653B0D9BF530
00007f582cddb834  call rax
00007f582cddb836  movaps xmm1, [rsp]
00007f582cddb83a  add rsp, 0x30
00007f582cddb83e  vmovaps xmm0, [rsp]
00007f582cddb843  vmovaps xmm2, [rsp+0x10]
00007f582cddb849  vmovaps xmm3, [rsp+0x20]
00007f582cddb84f  vmovaps xmm4, [rsp+0x30]
00007f582cddb855  vmovaps xmm5, [rsp+0x40]
00007f582cddb85b  vmovaps xmm6, [rsp+0x50]
00007f582cddb861  vmovaps xmm7, [rsp+0x60]
00007f582cddb867  vmovaps xmm8, [rsp+0x70]
00007f582cddb86d  vmovaps xmm9, [rsp+0x80]
00007f582cddb876  vmovaps xmm10, [rsp+0x90]
00007f582cddb87f  vmovaps xmm11, [rsp+0xA0]
00007f582cddb888  vmovaps xmm12, [rsp+0xB0]
00007f582cddb891  vmovaps xmm13, [rsp+0xC0]
00007f582cddb89a  vmovaps xmm14, [rsp+0xD0]
00007f582cddb8a3  vmovaps xmm15, [rsp+0xE0]
00007f582cddb8ac  add rsp, 0xF0
00007f582cddb8b3  pop r11
00007f582cddb8b5  pop r10
00007f582cddb8b7  pop r9
00007f582cddb8b9  pop r8
00007f582cddb8bb  pop rsi
00007f582cddb8bc  pop rdi
00007f582cddb8bd  pop rdx
00007f582cddb8be  pop rcx
00007f582cddb8bf  pop rax
00007f582cddb8c0  add rsp, 0x08
00007f582cddb8c4  jmp 0x00007F582CDD66B2
00007f582cddb8c9  call 0x00007F582CCB3E40
00007f582cddb8ce  jmp 0x00007F582CDD66C0
00007f582cddb8d3  call 0x00007F582CC0C380
00007f582cddb8d8  jmp 0x00007F582CDD66CA
00007f582cddb8dd  call 0x00007F582CC0D600
00007f582cddb8e2  jmp 0x00007F582CDD66D4
00007f582cddb8e7  call 0x00007F582CBFF540
00007f582cddb8ec  jmp 0x00007F582CDD66DE
00007f582cddb8f1  int3
00007f582cddb8f2  nop [rax+rax*1], ax
00007f582cddb8fb  nop [rax+rax*1], eax
00007f582cddb900  mov eax, [r15+0x48]
00007f582cddb904  lea r14d, [eax+0x01]
00007f582cddb909  mov [rsp+0x10], r14d
00007f582cddb90e  mov r14d, r14d
00007f582cddb911  mov [r15+0x48], r14
00007f582cddb915  xor eax, eax
00007f582cddb917  mov r14d, [rsp+0x10]
00007f582cddb91c  cmp r14d, 0x1F4
00007f582cddb923  cmc
00007f582cddb924  lahf
00007f582cddb925  seto al
00007f582cddb928  mov [r15+0x108], eax
00007f582cddb92f  mov eax, [r15+0x108]
00007f582cddb936  sahf
00007f582cddb937  jnz 0x00007F582CDDB969
00007f582cddb939  cmp dword ptr [r15+0x318], 0x00
00007f582cddb941  jz 0x00007F582CDE1AB0
00007f582cddb947  nop [rax+rax*1], ax
00007f582cddb950  nop [rax+rax*1], eax
00007f582cddb958  mov eax, 0x410450
00007f582cddb95d  mov [r15+0x100], rax
00007f582cddb964  jmp 0x00007F582CBFE110
00007f582cddb969  cmp dword ptr [r15+0x318], 0x00
00007f582cddb971  jz 0x00007F582CDDB9A0
00007f582cddb977  nop [rax+rax*1], ax
00007f582cddb980  nop [rax+rax*1], eax
00007f582cddb988  mov eax, 0x410274
00007f582cddb98d  mov [r15+0x100], rax
00007f582cddb994  jmp 0x00007F582CBFE110
00007f582cddb999  int3
00007f582cddb99a  int3
00007f582cddb99b  nop [rax+rax*1], eax
00007f582cddb9a0  mov rax, [r15+0x40]
00007f582cddb9a4  movaps xmm1, [r15+0x1D0]
00007f582cddb9ac  vmovaps [rsp+0x10], xmm1
00007f582cddb9b2  vmovaps xmm15, [rsp+0x10]
00007f582cddb9b8  por xmm1, xmm15
00007f582cddb9bd  movaps xmm14, [r15+0x1A0]
00007f582cddb9c5  vmovaps [rsp+0x10], xmm14
00007f582cddb9cb  vmovaps xmm13, [rsp+0x10]
00007f582cddb9d1  por xmm14, xmm13
00007f582cddb9d6  lea r14, [rax+0x30]
00007f582cddb9da  mov r12, [r13+r14*1]
00007f582cddb9df  lea r14, [rax+0x38]
00007f582cddb9e3  mov r11, [r13+r14*1]
00007f582cddb9e8  movq xmm13, r12
00007f582cddb9ed  movq xmm12, r11
00007f582cddb9f2  movq xmm13, xmm13
00007f582cddb9f7  vmovaps [rsp+0x10], xmm13
00007f582cddb9fd  movq xmm13, xmm13
00007f582cddba02  movaps [r15+0x130], xmm13
00007f582cddba0a  movq xmm12, xmm12
00007f582cddba0f  vmovaps [rsp+0x20], xmm12
00007f582cddba15  movq xmm12, xmm12
00007f582cddba1a  movaps [r15+0x280], xmm12
00007f582cddba22  movaps xmm13, [r15+0x270]
00007f582cddba2a  vmovaps [rsp+0x30], xmm13
00007f582cddba30  vmovaps xmm12, [rsp+0x30]
00007f582cddba36  por xmm13, xmm12
00007f582cddba3b  lea r14, [rax+0x20]
00007f582cddba3f  mov r12, [r13+r14*1]
00007f582cddba44  lea r14, [rax+0x28]
00007f582cddba48  mov r11, [r13+r14*1]
00007f582cddba4d  movq xmm12, r12
00007f582cddba52  movq xmm11, r11
00007f582cddba57  movq xmm12, xmm12
00007f582cddba5c  vmovaps [rsp+0x30], xmm12
00007f582cddba62  movq xmm12, xmm12
00007f582cddba67  movaps [r15+0x150], xmm12
00007f582cddba6f  movq xmm11, xmm11
00007f582cddba74  vmovaps [rsp+0x40], xmm11
00007f582cddba7a  movq xmm11, xmm11
00007f582cddba7f  movaps [r15+0x140], xmm11
00007f582cddba87  lea r14, [rax+0x10]
00007f582cddba8b  mov r12, [r13+r14*1]
00007f582cddba90  lea r14, [rax+0x18]
00007f582cddba94  mov r11, [r13+r14*1]
00007f582cddba99  movq xmm12, r12
00007f582cddba9e  movq xmm11, r11
00007f582cddbaa3  movq xmm12, xmm12
00007f582cddbaa8  vmovaps [rsp+0x50], xmm12
00007f582cddbaae  movq xmm12, xmm12
00007f582cddbab3  movaps [r15+0x170], xmm12
00007f582cddbabb  movq xmm11, xmm11
00007f582cddbac0  vmovaps [rsp+0x60], xmm11
00007f582cddbac6  movq xmm11, xmm11
00007f582cddbacb  movaps [r15+0x160], xmm11
00007f582cddbad3  mov r14, [r13+rax*1]
00007f582cddbad8  vmovq xmm12, r14
00007f582cddbadd  vpbroadcastq xmm12, xmm12
00007f582cddbae2  lea r14, [rax+0x08]
00007f582cddbae6  mov rax, [r13+r14*1]
00007f582cddbaeb  movq xmm11, rax
00007f582cddbaf0  movaps [r15+0x230], xmm11
00007f582cddbaf8  mov rax, [r15+0xF8]
00007f582cddbaff  lea r14, [rax+0x50]
00007f582cddbb03  movups xmm11, [r13+r14*1]
00007f582cddbb09  lea r14, [rax+0x60]
00007f582cddbb0d  movups xmm10, [r13+r14*1]
00007f582cddbb13  lea r14, [rax+0x30]
00007f582cddbb17  movups xmm9, [r13+r14*1]
00007f582cddbb1d  mov r14, [r15+0x50]
00007f582cddbb21  mov [r15+0x60], r14
00007f582cddbb25  mov qword ptr [r15+0x58], 0x40
00007f582cddbb2d  movaps xmm8, xmm12
00007f582cddbb31  mulpd xmm8, xmm15
00007f582cddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007f582cddbb3c  ptest xmm7, xmm7
00007f582cddbb41  jnz 0x00007F582CDDC96A
00007f582cddbb47  movq xmm15, qword ptr [r15+0x230]
00007f582cddbb50  vmovaps [rsp+0x70], xmm15
00007f582cddbb56  vpermilpd xmm15, xmm15, 0x00
00007f582cddbb5c  movaps xmm7, xmm9
00007f582cddbb60  mulpd xmm7, xmm15
00007f582cddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007f582cddbb6a  ptest xmm6, xmm6
00007f582cddbb6f  jnz 0x00007F582CDDCAAE
00007f582cddbb75  vxorps xmm15, xmm15, xmm15
00007f582cddbb7a  vpbroadcastq xmm15, xmm15
00007f582cddbb7f  movaps xmm9, xmm12
00007f582cddbb83  mulpd xmm9, xmm10
00007f582cddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007f582cddbb8e  ptest xmm6, xmm6
00007f582cddbb93  jnz 0x00007F582CDDCBF0
00007f582cddbb99  movaps xmm10, xmm12
00007f582cddbb9d  mulpd xmm10, xmm11
00007f582cddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007f582cddbba8  ptest xmm6, xmm6
00007f582cddbbad  jnz 0x00007F582CDDCD34
00007f582cddbbb3  movaps xmm11, [r15+0x1F0]
00007f582cddbbbb  movaps xmm6, xmm12
00007f582cddbbbf  mulpd xmm6, xmm11
00007f582cddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007f582cddbbc9  ptest xmm5, xmm5
00007f582cddbbce  jnz 0x00007F582CDDCE78
00007f582cddbbd4  movaps xmm12, [r15+0x2A0]
00007f582cddbbdc  vmovaps [rsp+0x80], xmm12
00007f582cddbbe5  vmovaps xmm11, [rsp+0x80]
00007f582cddbbee  por xmm12, xmm11
00007f582cddbbf3  movaps xmm11, [r15+0x250]
00007f582cddbbfb  vmovaps [rsp+0x80], xmm11
00007f582cddbc04  vmovaps xmm5, [rsp+0x80]
00007f582cddbc0d  por xmm11, xmm5
00007f582cddbc12  vmovaps xmm4, [rsp+0x70]
00007f582cddbc18  vpermilpd xmm4, xmm4, 0x00
00007f582cddbc1e  movaps xmm3, xmm5
00007f582cddbc21  mulpd xmm3, xmm4
00007f582cddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007f582cddbc2a  ptest xmm2, xmm2
00007f582cddbc2f  jnz 0x00007F582CDDCFBA
00007f582cddbc35  mov [rsp+0x80], rax
00007f582cddbc3d  xor eax, eax
00007f582cddbc3f  mov r12d, 0x40
00007f582cddbc45  mov r11d, 0x200
00007f582cddbc4b  cmp r12, r11
00007f582cddbc4e  cmc
00007f582cddbc4f  lahf
00007f582cddbc50  seto al
00007f582cddbc53  mov [r15+0x108], eax
00007f582cddbc5a  movaps xmm5, xmm8
00007f582cddbc5e  addpd xmm5, xmm15
00007f582cddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007f582cddbc68  ptest xmm4, xmm4
00007f582cddbc6d  jnz 0x00007F582CDDD0FA
00007f582cddbc73  movaps xmm8, [r15+0x1B0]
00007f582cddbc7b  movaps xmm4, xmm9
00007f582cddbc7f  addpd xmm4, xmm8
00007f582cddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007f582cddbc89  ptest xmm2, xmm2
00007f582cddbc8e  jnz 0x00007F582CDDD23C
00007f582cddbc94  movaps xmm9, xmm10
00007f582cddbc98  addpd xmm9, xmm8
00007f582cddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007f582cddbca3  ptest xmm2, xmm2
00007f582cddbca8  jnz 0x00007F582CDDD37E
00007f582cddbcae  movaps xmm10, [r15+0x2F0]
00007f582cddbcb6  vmovaps [rsp+0x90], xmm10
00007f582cddbcbf  vmovaps xmm8, [rsp+0x90]
00007f582cddbcc8  por xmm10, xmm8
00007f582cddbccd  movaps xmm8, [r15+0x2E0]
00007f582cddbcd5  vmovaps [rsp+0x90], xmm8
00007f582cddbcde  vmovaps xmm2, [rsp+0x90]
00007f582cddbce7  por xmm8, xmm2
00007f582cddbcec  movaps xmm2, [r15+0x2D0]
00007f582cddbcf4  vmovaps [rsp+0x90], xmm2
00007f582cddbcfd  vmovaps [rsp+0xA0], xmm1
00007f582cddbd06  vmovaps xmm1, [rsp+0x90]
00007f582cddbd0f  por xmm2, xmm1
00007f582cddbd13  movaps xmm1, [r15+0x200]
00007f582cddbd1b  vmovaps [rsp+0x90], xmm1
00007f582cddbd24  vmovaps [rsp+0xB0], xmm15
00007f582cddbd2d  vmovaps xmm15, [rsp+0x90]
00007f582cddbd36  por xmm1, xmm15
00007f582cddbd3b  movaps xmm15, [r15+0x1C0]
00007f582cddbd43  vmovaps [rsp+0x90], xmm15
00007f582cddbd4c  vmovaps [rsp+0xC0], xmm1
00007f582cddbd55  vmovaps xmm1, [rsp+0x90]
00007f582cddbd5e  por xmm15, xmm1
00007f582cddbd63  movaps xmm1, [r15+0x190]
00007f582cddbd6b  vmovaps [rsp+0x90], xmm1
00007f582cddbd74  vmovaps [rsp+0xD0], xmm15
00007f582cddbd7d  vmovaps xmm15, [rsp+0x90]
00007f582cddbd86  por xmm1, xmm15
00007f582cddbd8b  movaps xmm15, [r15+0x300]
00007f582cddbd93  vmovaps [rsp+0x90], xmm15
00007f582cddbd9c  vmovaps [rsp+0xE0], xmm1
00007f582cddbda5  vmovaps xmm1, [rsp+0x90]
00007f582cddbdae  por xmm15, xmm1
00007f582cddbdb3  mov rax, [rsp+0x80]
00007f582cddbdbb  lea r12, [rax+0xA0]
00007f582cddbdc2  movups xmm1, [r13+r12*1]
00007f582cddbdc8  lea r12, [rax+0xB0]
00007f582cddbdcf  vmovaps [rsp+0x80], xmm1
00007f582cddbdd8  movups xmm1, [r13+r12*1]
00007f582cddbdde  vmovaps [rsp+0x90], xmm1
00007f582cddbde7  vmovaps [rsp+0xF0], xmm15
00007f582cddbdf0  vmovaps xmm15, [rsp+0xB0]
00007f582cddbdf9  vmovaps [rsp+0xB0], xmm14
00007f582cddbe02  movaps xmm1, xmm6
00007f582cddbe05  addpd xmm1, xmm15
00007f582cddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007f582cddbe0f  ptest xmm14, xmm14
00007f582cddbe15  jnz 0x00007F582CDDD4D6
00007f582cddbe1b  lea r12, [rax+0xF0]
00007f582cddbe22  movups xmm15, [r13+r12*1]
00007f582cddbe28  movaps xmm14, xmm4
00007f582cddbe2c  addpd xmm14, xmm3
00007f582cddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007f582cddbe37  ptest xmm6, xmm6
00007f582cddbe3c  jnz 0x00007F582CDDD621
00007f582cddbe42  movaps xmm6, xmm9
00007f582cddbe46  addpd xmm6, xmm7
00007f582cddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007f582cddbe4f  ptest xmm4, xmm4
00007f582cddbe54  jnz 0x00007F582CDDD763
00007f582cddbe5a  vmovaps xmm9, [rsp+0x70]
00007f582cddbe60  vpermilpd xmm9, xmm9, 0x00
00007f582cddbe66  vmovaps xmm4, [rsp+0x90]
00007f582cddbe6f  movaps xmm7, xmm4
00007f582cddbe72  mulpd xmm7, xmm9
00007f582cddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007f582cddbe7c  ptest xmm3, xmm3
00007f582cddbe81  jnz 0x00007F582CDDD8A4
00007f582cddbe87  vmovaps xmm9, [rsp+0x50]
00007f582cddbe8d  vpermilpd xmm9, xmm9, 0x00
00007f582cddbe93  movaps xmm4, xmm15
00007f582cddbe97  mulpd xmm4, xmm9
00007f582cddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007f582cddbea1  ptest xmm3, xmm3
00007f582cddbea6  jnz 0x00007F582CDDD9E5
00007f582cddbeac  lea r12, [rax+0xE0]
00007f582cddbeb3  movups xmm15, [r13+r12*1]
00007f582cddbeb9  vmovaps xmm9, [rsp+0x70]
00007f582cddbebf  vpermilpd xmm9, xmm9, 0x00
00007f582cddbec5  vmovaps [rsp+0x70], xmm1
00007f582cddbecb  vmovaps xmm1, [rsp+0x80]
00007f582cddbed4  vmovaps [rsp+0x80], xmm15
00007f582cddbedd  movaps xmm3, xmm1
00007f582cddbee0  mulpd xmm3, xmm9
00007f582cddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007f582cddbeea  ptest xmm15, xmm15
00007f582cddbef0  jnz 0x00007F582CDDDB31
00007f582cddbef6  vmovaps xmm1, [rsp+0xF0]
00007f582cddbeff  vmovaps xmm15, [rsp+0xF0]
00007f582cddbf08  por xmm1, xmm15
00007f582cddbf0d  movaps [r15+0x300], xmm1
00007f582cddbf15  vmovaps xmm15, [rsp+0xE0]
00007f582cddbf1e  vmovaps xmm9, [rsp+0xE0]
00007f582cddbf27  por xmm15, xmm9
00007f582cddbf2c  movaps [r15+0x190], xmm15
00007f582cddbf34  vmovaps xmm9, [rsp+0x50]
00007f582cddbf3a  vpermilpd xmm9, xmm9, 0x00
00007f582cddbf40  vmovaps [rsp+0x90], xmm1
00007f582cddbf49  vmovaps [rsp+0xE0], xmm15
00007f582cddbf52  vmovaps xmm15, [rsp+0x80]
00007f582cddbf5b  vmovaps [rsp+0x80], xmm14
00007f582cddbf64  movaps xmm1, xmm15
00007f582cddbf68  mulpd xmm1, xmm9
00007f582cddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007f582cddbf72  ptest xmm14, xmm14
00007f582cddbf78  jnz 0x00007F582CDDDC72
00007f582cddbf7e  lea r12, [rax+0x90]
00007f582cddbf85  movups xmm15, [r13+r12*1]
00007f582cddbf8b  vmovaps xmm14, [rsp+0xD0]
00007f582cddbf94  vmovaps xmm9, [rsp+0xD0]
00007f582cddbf9d  por xmm14, xmm9
00007f582cddbfa2  movaps [r15+0x1C0], xmm14
00007f582cddbfaa  vmovaps xmm9, [rsp+0xC0]
00007f582cddbfb3  vmovaps [rsp+0xD0], xmm1
00007f582cddbfbc  vmovaps xmm1, [rsp+0xC0]
00007f582cddbfc5  por xmm9, xmm1
00007f582cddbfca  movaps [r15+0x200], xmm9
00007f582cddbfd2  vmovaps [rsp+0xC0], xmm2
00007f582cddbfdb  vmovaps xmm1, [rsp+0xC0]
00007f582cddbfe4  por xmm2, xmm1
00007f582cddbfe8  movaps [r15+0x2D0], xmm2
00007f582cddbff0  vmovaps [rsp+0xC0], xmm8
00007f582cddbff9  vmovaps xmm1, [rsp+0xC0]
00007f582cddc002  por xmm8, xmm1
00007f582cddc007  movaps [r15+0x2E0], xmm8
00007f582cddc00f  vmovaps [rsp+0xC0], xmm15
00007f582cddc018  movaps xmm1, xmm5
00007f582cddc01b  addpd xmm1, xmm7
00007f582cddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007f582cddc024  ptest xmm15, xmm15
00007f582cddc02a  jnz 0x00007F582CDDDDBE
00007f582cddc030  vmovaps xmm15, [rsp+0x50]
00007f582cddc036  vpermilpd xmm15, xmm15, 0x00
00007f582cddc03c  vmovaps xmm5, [rsp+0xC0]
00007f582cddc045  vmovaps [rsp+0xC0], xmm1
00007f582cddc04e  movaps xmm7, xmm5
00007f582cddc051  mulpd xmm7, xmm15
00007f582cddc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007f582cddc05b  ptest xmm1, xmm1
00007f582cddc060  jnz 0x00007F582CDDDEFE
00007f582cddc066  lea r12, [rax+0x80]
00007f582cddc06d  movups xmm1, [r13+r12*1]
00007f582cddc073  vmovaps xmm5, [rsp+0x70]
00007f582cddc079  vmovaps [rsp+0x70], xmm1
00007f582cddc07f  movaps xmm15, xmm5
00007f582cddc083  addpd xmm15, xmm3
00007f582cddc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007f582cddc08e  ptest xmm1, xmm1
00007f582cddc093  jnz 0x00007F582CDDE049
00007f582cddc099  vmovaps xmm5, [rsp+0x80]
00007f582cddc0a2  movaps xmm1, xmm5
00007f582cddc0a5  addpd xmm1, xmm4
00007f582cddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007f582cddc0ae  ptest xmm3, xmm3
00007f582cddc0b3  jnz 0x00007F582CDDE18B
00007f582cddc0b9  vmovaps [rsp+0x80], xmm10
00007f582cddc0c2  vmovaps xmm5, [rsp+0x80]
00007f582cddc0cb  por xmm10, xmm5
00007f582cddc0d0  movaps [r15+0x2F0], xmm10
00007f582cddc0d8  vmovaps xmm5, [rsp+0x50]
00007f582cddc0de  vpermilpd xmm5, xmm5, 0x00
00007f582cddc0e4  vmovaps xmm3, [rsp+0x70]
00007f582cddc0ea  vmovaps [rsp+0x50], xmm1
00007f582cddc0f0  movaps xmm4, xmm3
00007f582cddc0f3  mulpd xmm4, xmm5
00007f582cddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007f582cddc0fc  ptest xmm1, xmm1
00007f582cddc101  jnz 0x00007F582CDDE2CB
00007f582cddc107  lea r12, [rax+0xD0]
00007f582cddc10e  movups xmm1, [r13+r12*1]
00007f582cddc114  vmovaps xmm3, [rsp+0xD0]
00007f582cddc11d  vmovaps [rsp+0x70], xmm1
00007f582cddc123  movaps xmm5, xmm6
00007f582cddc126  addpd xmm5, xmm3
00007f582cddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007f582cddc12f  ptest xmm1, xmm1
00007f582cddc134  jnz 0x00007F582CDDE415
00007f582cddc13a  vmovaps xmm1, [rsp+0x60]
00007f582cddc140  vpermilpd xmm1, xmm1, 0x00
00007f582cddc146  movaps xmm6, xmm9
00007f582cddc14a  mulpd xmm6, xmm1
00007f582cddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007f582cddc153  ptest xmm3, xmm3
00007f582cddc158  jnz 0x00007F582CDDE555
00007f582cddc15e  movaps [r15+0x260], xmm6
00007f582cddc166  vxorps xmm1, xmm1, xmm1
00007f582cddc16a  vpbroadcastq xmm1, xmm1
00007f582cddc16f  movaps [r15+0x1B0], xmm1
00007f582cddc177  vmovaps xmm1, [rsp+0x60]
00007f582cddc17d  vpermilpd xmm1, xmm1, 0x00
00007f582cddc183  vmovaps xmm3, [rsp+0x70]
00007f582cddc189  vmovaps [rsp+0x70], xmm15
00007f582cddc18f  movaps xmm9, xmm3
00007f582cddc193  mulpd xmm9, xmm1
00007f582cddc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007f582cddc19e  ptest xmm15, xmm15
00007f582cddc1a4  jnz 0x00007F582CDDE696
00007f582cddc1aa  lea r12, [rax+0xC0]
00007f582cddc1b1  movups xmm1, [r13+r12*1]
00007f582cddc1b7  vmovaps xmm3, [rsp+0xC0]
00007f582cddc1c0  vmovaps [rsp+0x80], xmm1
00007f582cddc1c9  movaps xmm15, xmm3
00007f582cddc1cd  addpd xmm15, xmm7
00007f582cddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007f582cddc1d8  ptest xmm1, xmm1
00007f582cddc1dd  jnz 0x00007F582CDDE7E2
00007f582cddc1e3  vmovaps [rsp+0xC0], xmm13
00007f582cddc1ec  vmovaps xmm1, [rsp+0xC0]
00007f582cddc1f5  por xmm13, xmm1
00007f582cddc1fa  movaps [r15+0x270], xmm13
00007f582cddc202  vmovaps xmm1, [rsp+0xB0]
00007f582cddc20b  vmovaps xmm7, [rsp+0xB0]
00007f582cddc214  por xmm1, xmm7
00007f582cddc218  movaps [r15+0x1A0], xmm1
00007f582cddc220  vmovaps xmm1, [rsp+0x60]
00007f582cddc226  vpermilpd xmm1, xmm1, 0x00
00007f582cddc22c  vmovaps [rsp+0xB0], xmm1
00007f582cddc235  vmovaps xmm1, [rsp+0x80]
00007f582cddc23e  vmovaps [rsp+0x80], xmm15
00007f582cddc247  vmovaps xmm15, [rsp+0xB0]
00007f582cddc250  vmovaps [rsp+0xB0], xmm14
00007f582cddc259  movaps xmm3, xmm1
00007f582cddc25c  mulpd xmm3, xmm15
00007f582cddc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007f582cddc266  ptest xmm14, xmm14
00007f582cddc26c  jnz 0x00007F582CDDE924
00007f582cddc272  lea r12, [rax+0x20]
00007f582cddc276  movups xmm1, [r13+r12*1]
00007f582cddc27c  movaps [r15+0x110], xmm1
00007f582cddc284  vmovaps xmm14, [rsp+0x70]
00007f582cddc28a  vmovaps [rsp+0x70], xmm1
00007f582cddc290  movaps xmm15, xmm14
00007f582cddc294  addpd xmm15, xmm4
00007f582cddc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007f582cddc29f  ptest xmm1, xmm1
00007f582cddc2a4  jnz 0x00007F582CDDEA6F
00007f582cddc2aa  vmovaps xmm1, [rsp+0x60]
00007f582cddc2b0  vpermilpd xmm1, xmm1, 0x00
00007f582cddc2b6  movaps xmm14, xmm2
00007f582cddc2ba  mulpd xmm14, xmm1
00007f582cddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007f582cddc2c5  ptest xmm4, xmm4
00007f582cddc2ca  jnz 0x00007F582CDDEBB2
00007f582cddc2d0  vmovaps xmm4, [rsp+0x50]
00007f582cddc2d6  movaps xmm1, xmm4
00007f582cddc2d9  addpd xmm1, xmm9
00007f582cddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007f582cddc2e3  ptest xmm2, xmm2
00007f582cddc2e8  jnz 0x00007F582CDDECF4
00007f582cddc2ee  vmovaps xmm9, [rsp+0x30]
00007f582cddc2f4  vpermilpd xmm9, xmm9, 0x00
00007f582cddc2fa  vmovaps xmm2, [rsp+0x70]
00007f582cddc300  vmovaps [rsp+0x50], xmm1
00007f582cddc306  movaps xmm4, xmm2
00007f582cddc309  mulpd xmm4, xmm9
00007f582cddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007f582cddc313  ptest xmm1, xmm1
00007f582cddc318  jnz 0x00007F582CDDEE35
00007f582cddc31e  vmovaps xmm1, [rsp+0x30]
00007f582cddc324  vpermilpd xmm1, xmm1, 0x00
00007f582cddc32a  vmovaps xmm2, [rsp+0x90]
00007f582cddc333  vmovaps [rsp+0x60], xmm15
00007f582cddc339  movaps xmm9, xmm2
00007f582cddc33d  mulpd xmm9, xmm1
00007f582cddc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007f582cddc348  ptest xmm15, xmm15
00007f582cddc34e  jnz 0x00007F582CDDEF76
00007f582cddc354  vmovaps xmm15, [rsp+0x80]
00007f582cddc35d  movaps xmm1, xmm15
00007f582cddc361  addpd xmm1, xmm6
00007f582cddc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007f582cddc36a  ptest xmm2, xmm2
00007f582cddc36f  jnz 0x00007F582CDDF0B8
00007f582cddc375  movaps xmm15, xmm5
00007f582cddc379  addpd xmm15, xmm3
00007f582cddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007f582cddc384  ptest xmm6, xmm6
00007f582cddc389  jnz 0x00007F582CDDF1F9
00007f582cddc38f  vmovaps xmm6, [rsp+0x30]
00007f582cddc395  vpermilpd xmm6, xmm6, 0x00
00007f582cddc39b  movaps xmm5, xmm8
00007f582cddc39f  mulpd xmm5, xmm6
00007f582cddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007f582cddc3a8  ptest xmm3, xmm3
00007f582cddc3ad  jnz 0x00007F582CDDF33B
00007f582cddc3b3  vmovaps xmm8, [rsp+0x30]
00007f582cddc3b9  vpermilpd xmm8, xmm8, 0x00
00007f582cddc3bf  movaps xmm6, xmm10
00007f582cddc3c3  mulpd xmm6, xmm8
00007f582cddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007f582cddc3cd  ptest xmm3, xmm3
00007f582cddc3d2  jnz 0x00007F582CDDF47C
00007f582cddc3d8  vmovaps xmm8, [rsp+0x60]
00007f582cddc3de  movaps xmm10, xmm8
00007f582cddc3e2  addpd xmm10, xmm14
00007f582cddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007f582cddc3ed  ptest xmm3, xmm3
00007f582cddc3f2  jnz 0x00007F582CDDF5BE
00007f582cddc3f8  vmovaps xmm8, [rsp+0x50]
00007f582cddc3fe  movaps xmm14, xmm8
00007f582cddc402  addpd xmm14, xmm4
00007f582cddc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007f582cddc40d  ptest xmm3, xmm3
00007f582cddc412  jnz 0x00007F582CDDF702
00007f582cddc418  vmovaps xmm8, [rsp+0x40]
00007f582cddc41e  vpermilpd xmm8, xmm8, 0x00
00007f582cddc424  movaps xmm4, xmm13
00007f582cddc428  mulpd xmm4, xmm8
00007f582cddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007f582cddc432  ptest xmm3, xmm3
00007f582cddc437  jnz 0x00007F582CDDF845
00007f582cddc43d  movaps xmm13, xmm15
00007f582cddc441  addpd xmm13, xmm9
00007f582cddc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007f582cddc44c  ptest xmm8, xmm8
00007f582cddc452  jnz 0x00007F582CDDF987
00007f582cddc458  movaps xmm15, xmm1
00007f582cddc45c  addpd xmm15, xmm5
00007f582cddc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007f582cddc467  ptest xmm9, xmm9
00007f582cddc46d  jnz 0x00007F582CDDFACB
00007f582cddc473  vmovaps [rsp+0x30], xmm11
00007f582cddc479  vmovaps xmm1, [rsp+0x30]
00007f582cddc47f  por xmm11, xmm1
00007f582cddc484  movaps [r15+0x250], xmm11
00007f582cddc48c  vmovaps [rsp+0x30], xmm12
00007f582cddc492  vmovaps xmm1, [rsp+0x30]
00007f582cddc498  por xmm12, xmm1
00007f582cddc49d  movaps [r15+0x2A0], xmm12
00007f582cddc4a5  vmovaps xmm1, [rsp+0xA0]
00007f582cddc4ae  vmovaps xmm11, [rsp+0xA0]
00007f582cddc4b7  por xmm1, xmm11
00007f582cddc4bc  movaps [r15+0x1D0], xmm1
00007f582cddc4c4  lea r12, [rax+0x40]
00007f582cddc4c8  movups xmm1, [r13+r12*1]
00007f582cddc4ce  movaps [r15+0x2C0], xmm1
00007f582cddc4d6  vmovaps xmm11, [rsp+0x40]
00007f582cddc4dc  vpermilpd xmm11, xmm11, 0x00
00007f582cddc4e2  vmovaps xmm8, [rsp+0xE0]
00007f582cddc4eb  movaps xmm9, xmm8
00007f582cddc4ef  mulpd xmm9, xmm11
00007f582cddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007f582cddc4fa  ptest xmm5, xmm5
00007f582cddc4ff  jnz 0x00007F582CDDFC17
00007f582cddc505  movaps xmm11, xmm10
00007f582cddc509  addpd xmm11, xmm6
00007f582cddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007f582cddc514  ptest xmm8, xmm8
00007f582cddc51a  jnz 0x00007F582CDDFD5B
00007f582cddc520  movaps xmm10, xmm14
00007f582cddc524  addpd xmm10, xmm4
00007f582cddc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007f582cddc52f  ptest xmm8, xmm8
00007f582cddc535  jnz 0x00007F582CDDFE9E
00007f582cddc53b  vmovaps xmm14, [rsp+0x40]
00007f582cddc541  vpermilpd xmm14, xmm14, 0x00
00007f582cddc547  movaps xmm8, xmm1
00007f582cddc54b  mulpd xmm8, xmm14
00007f582cddc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007f582cddc556  ptest xmm6, xmm6
00007f582cddc55b  jnz 0x00007F582CDDFFE1
00007f582cddc561  movaps xmm1, [r15+0x2B0]
00007f582cddc569  vmovaps xmm14, [rsp+0x40]
00007f582cddc56f  vpermilpd xmm14, xmm14, 0x00
00007f582cddc575  movaps xmm6, xmm1
00007f582cddc578  mulpd xmm6, xmm14
00007f582cddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007f582cddc582  ptest xmm5, xmm5
00007f582cddc587  jnz 0x00007F582CDE0124
00007f582cddc58d  vmovaps xmm1, [rsp+0x10]
00007f582cddc593  vpermilpd xmm1, xmm1, 0x00
00007f582cddc599  movaps xmm14, xmm12
00007f582cddc59d  mulpd xmm14, xmm1
00007f582cddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007f582cddc5a8  ptest xmm5, xmm5
00007f582cddc5ad  jnz 0x00007F582CDE0265
00007f582cddc5b3  movaps xmm1, xmm13
00007f582cddc5b7  addpd xmm1, xmm9
00007f582cddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007f582cddc5c1  ptest xmm12, xmm12
00007f582cddc5c7  jnz 0x00007F582CDE03A8
00007f582cddc5cd  vmovaps xmm13, [rsp+0x10]
00007f582cddc5d3  vpermilpd xmm13, xmm13, 0x00
00007f582cddc5d9  movaps xmm12, xmm7
00007f582cddc5dd  mulpd xmm12, xmm13
00007f582cddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007f582cddc5e8  ptest xmm9, xmm9
00007f582cddc5ee  jnz 0x00007F582CDE04EA
00007f582cddc5f4  movaps xmm13, xmm15
00007f582cddc5f8  addpd xmm13, xmm8
00007f582cddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007f582cddc603  ptest xmm9, xmm9
00007f582cddc609  jnz 0x00007F582CDE062D
00007f582cddc60f  movaps xmm15, [r15+0x290]
00007f582cddc617  vmovaps xmm9, [rsp+0x10]
00007f582cddc61d  vpermilpd xmm9, xmm9, 0x00
00007f582cddc623  movaps xmm8, xmm15
00007f582cddc627  mulpd xmm8, xmm9
00007f582cddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007f582cddc632  ptest xmm7, xmm7
00007f582cddc637  jnz 0x00007F582CDE0771
00007f582cddc63d  movaps xmm15, xmm11
00007f582cddc641  addpd xmm15, xmm6
00007f582cddc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007f582cddc64c  ptest xmm9, xmm9
00007f582cddc652  jnz 0x00007F582CDE08B5
00007f582cddc658  movaps xmm11, [r15+0x1E0]
00007f582cddc660  vmovaps xmm9, [rsp+0x10]
00007f582cddc666  vpermilpd xmm9, xmm9, 0x00
00007f582cddc66c  movaps xmm7, xmm11
00007f582cddc670  mulpd xmm7, xmm9
00007f582cddc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007f582cddc67a  ptest xmm6, xmm6
00007f582cddc67f  jnz 0x00007F582CDE09F8
00007f582cddc685  movaps xmm11, xmm10
00007f582cddc689  addpd xmm11, xmm14
00007f582cddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007f582cddc694  ptest xmm9, xmm9
00007f582cddc69a  jnz 0x00007F582CDE0B3A
00007f582cddc6a0  lea r12, [rax+0x70]
00007f582cddc6a4  movups xmm14, [r13+r12*1]
00007f582cddc6aa  movaps [r15+0x240], xmm14
00007f582cddc6b2  movaps xmm10, xmm1
00007f582cddc6b6  addpd xmm10, xmm12
00007f582cddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007f582cddc6c1  ptest xmm9, xmm9
00007f582cddc6c7  jnz 0x00007F582CDE0C88
00007f582cddc6cd  movaps [r15+0x170], xmm10
00007f582cddc6d5  vmovaps xmm1, [rsp+0x20]
00007f582cddc6db  vpermilpd xmm1, xmm1, 0x00
00007f582cddc6e1  movaps xmm12, xmm14
00007f582cddc6e5  mulpd xmm12, xmm1
00007f582cddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007f582cddc6f0  ptest xmm9, xmm9
00007f582cddc6f6  jnz 0x00007F582CDE0DCB
00007f582cddc6fc  vmovaps xmm1, [rsp+0x20]
00007f582cddc702  vpermilpd xmm1, xmm1, 0x00
00007f582cddc708  vmovaps xmm9, [rsp+0xB0]
00007f582cddc711  movaps xmm14, xmm9
00007f582cddc715  mulpd xmm14, xmm1
00007f582cddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007f582cddc720  ptest xmm6, xmm6
00007f582cddc725  jnz 0x00007F582CDE0F0E
00007f582cddc72b  movaps [r15+0x180], xmm14
00007f582cddc733  movaps xmm1, xmm13
00007f582cddc737  addpd xmm1, xmm8
00007f582cddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007f582cddc741  ptest xmm9, xmm9
00007f582cddc747  jnz 0x00007F582CDE1051
00007f582cddc74d  movaps [r15+0x210], xmm1
00007f582cddc755  movups xmm13, [r13+rax*1]
00007f582cddc75b  lea r12, [rax+0x10]
00007f582cddc75f  movups xmm9, [r13+r12*1]
00007f582cddc765  movaps [r15+0x230], xmm9
00007f582cddc76d  movaps xmm8, xmm15
00007f582cddc771  addpd xmm8, xmm7
00007f582cddc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007f582cddc77c  ptest xmm6, xmm6
00007f582cddc781  jnz 0x00007F582CDE11A7
00007f582cddc787  movaps [r15+0x130], xmm8
00007f582cddc78f  vmovaps xmm15, [rsp+0x20]
00007f582cddc795  vpermilpd xmm15, xmm15, 0x00
00007f582cddc79b  movaps xmm7, xmm9
00007f582cddc79f  mulpd xmm7, xmm15
00007f582cddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007f582cddc7a9  ptest xmm6, xmm6
00007f582cddc7ae  jnz 0x00007F582CDE12EA
00007f582cddc7b4  movaps [r15+0x220], xmm7
00007f582cddc7bc  vmovaps xmm15, [rsp+0x20]
00007f582cddc7c2  vpermilpd xmm15, xmm15, 0x00
00007f582cddc7c8  movaps xmm9, xmm13
00007f582cddc7cc  mulpd xmm9, xmm15
00007f582cddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007f582cddc7d7  ptest xmm6, xmm6
00007f582cddc7dc  jnz 0x00007F582CDE142C
00007f582cddc7e2  movaps xmm15, xmm11
00007f582cddc7e6  addpd xmm15, xmm12
00007f582cddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007f582cddc7f1  ptest xmm13, xmm13
00007f582cddc7f7  jnz 0x00007F582CDE1570
00007f582cddc7fd  movaps [r15+0x140], xmm15
00007f582cddc805  movaps xmm13, xmm10
00007f582cddc809  addpd xmm13, xmm14
00007f582cddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007f582cddc814  ptest xmm12, xmm12
00007f582cddc81a  jnz 0x00007F582CDE16B4
00007f582cddc820  movaps [r15+0x150], xmm13
00007f582cddc828  movaps xmm14, xmm1
00007f582cddc82c  addpd xmm14, xmm7
00007f582cddc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007f582cddc837  ptest xmm12, xmm12
00007f582cddc83d  jnz 0x00007F582CDE17F8
00007f582cddc843  movaps [r15+0x160], xmm14
00007f582cddc84b  movaps xmm1, xmm8
00007f582cddc84f  addpd xmm1, xmm9
00007f582cddc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007f582cddc859  ptest xmm12, xmm12
00007f582cddc85f  jnz 0x00007F582CDE193A
00007f582cddc865  movaps [r15+0x120], xmm1
00007f582cddc86d  movups [r13+r14*1], xmm15
00007f582cddc873  lea rax, [r14+0x10]
00007f582cddc877  movups [r13+rax*1], xmm13
00007f582cddc87d  lea rax, [r14+0x20]
00007f582cddc881  movups [r13+rax*1], xmm14
00007f582cddc887  lea rax, [r14+0x30]
00007f582cddc88b  movups [r13+rax*1], xmm1
00007f582cddc891  mov eax, [r15+0x108]
00007f582cddc898  sahf
00007f582cddc899  jnz 0x00007F582CDDC8CB
00007f582cddc89b  cmp dword ptr [r15+0x318], 0x00
00007f582cddc8a3  jz 0x00007F582CDDB900
00007f582cddc8a9  nop [rax+rax*1], ax
00007f582cddc8b2  nop [rax+rax*1], eax
00007f582cddc8ba  mov eax, 0x410444
00007f582cddc8bf  mov [r15+0x100], rax
00007f582cddc8c6  jmp 0x00007F582CBFE110
00007f582cddc8cb  cmp dword ptr [r15+0x318], 0x00
00007f582cddc8d3  jz 0x00007F582CDD57E0
00007f582cddc8d9  nop [rax+rax*1], ax
00007f582cddc8e2  nop [rax+rax*1], eax
00007f582cddc8ea  mov eax, 0x410278
00007f582cddc8ef  mov [r15+0x100], rax
00007f582cddc8f6  jmp 0x00007F582CBFE110
00007f582cddc8fb  int3
00007f582cddc8fc  call 0x00007F582CCE27E0
00007f582cddc901  jmp 0x00007F582CDDB9DF
00007f582cddc906  call 0x00007F582CCE1570
00007f582cddc90b  jmp 0x00007F582CDDB9E8
00007f582cddc910  call 0x00007F582CCE27E0
00007f582cddc915  jmp 0x00007F582CDDBA44
00007f582cddc91a  call 0x00007F582CCE1570
00007f582cddc91f  jmp 0x00007F582CDDBA4D
00007f582cddc924  call 0x00007F582CCE27E0
00007f582cddc929  jmp 0x00007F582CDDBA90
00007f582cddc92e  call 0x00007F582CCE1570
00007f582cddc933  jmp 0x00007F582CDDBA99
00007f582cddc938  call 0x00007F582CC0DC20
00007f582cddc93d  jmp 0x00007F582CDDBAD8
00007f582cddc942  call 0x00007F582CCD59C0
00007f582cddc947  jmp 0x00007F582CDDBAEB
00007f582cddc94c  call 0x00007F582CCE0E30
00007f582cddc951  jmp 0x00007F582CDDBB09
00007f582cddc956  call 0x00007F582CCDFBC0
00007f582cddc95b  jmp 0x00007F582CDDBB13
00007f582cddc960  call 0x00007F582CCDE950
00007f582cddc965  jmp 0x00007F582CDDBB1D
00007f582cddc96a  sub rsp, 0x08
00007f582cddc96e  push rax
00007f582cddc96f  push rcx
00007f582cddc970  push rdx
00007f582cddc971  push rdi
00007f582cddc972  push rsi
00007f582cddc973  push r8
00007f582cddc975  push r9
00007f582cddc977  push r10
00007f582cddc979  push r11
00007f582cddc97b  sub rsp, 0xF0
00007f582cddc982  vmovaps [rsp], xmm0
00007f582cddc987  vmovaps [rsp+0x10], xmm1
00007f582cddc98d  vmovaps [rsp+0x20], xmm2
00007f582cddc993  vmovaps [rsp+0x30], xmm3
00007f582cddc999  vmovaps [rsp+0x40], xmm4
00007f582cddc99f  vmovaps [rsp+0x50], xmm5
00007f582cddc9a5  vmovaps [rsp+0x60], xmm6
00007f582cddc9ab  vmovaps [rsp+0x70], xmm7
00007f582cddc9b1  vmovaps [rsp+0x80], xmm9
00007f582cddc9ba  vmovaps [rsp+0x90], xmm10
00007f582cddc9c3  vmovaps [rsp+0xA0], xmm11
00007f582cddc9cc  vmovaps [rsp+0xB0], xmm12
00007f582cddc9d5  vmovaps [rsp+0xC0], xmm13
00007f582cddc9de  vmovaps [rsp+0xD0], xmm14
00007f582cddc9e7  vmovaps [rsp+0xE0], xmm15
00007f582cddc9f0  sub rsp, 0x30
00007f582cddc9f4  movaps [rsp], xmm8
00007f582cddc9f9  movaps [rsp+0x10], xmm12
00007f582cddc9ff  movaps [rsp+0x20], xmm15
00007f582cddca05  lea rdi, [rsp]
00007f582cddca09  mov esi, 0x00
00007f582cddca0e  mov rax, 0x653B0D9BF530
00007f582cddca18  call rax
00007f582cddca1a  movaps xmm8, [rsp]
00007f582cddca1f  add rsp, 0x30
00007f582cddca23  vmovaps xmm0, [rsp]
00007f582cddca28  vmovaps xmm1, [rsp+0x10]
00007f582cddca2e  vmovaps xmm2, [rsp+0x20]
00007f582cddca34  vmovaps xmm3, [rsp+0x30]
00007f582cddca3a  vmovaps xmm4, [rsp+0x40]
00007f582cddca40  vmovaps xmm5, [rsp+0x50]
00007f582cddca46  vmovaps xmm6, [rsp+0x60]
00007f582cddca4c  vmovaps xmm7, [rsp+0x70]
00007f582cddca52  vmovaps xmm9, [rsp+0x80]
00007f582cddca5b  vmovaps xmm10, [rsp+0x90]
00007f582cddca64  vmovaps xmm11, [rsp+0xA0]
00007f582cddca6d  vmovaps xmm12, [rsp+0xB0]
00007f582cddca76  vmovaps xmm13, [rsp+0xC0]
00007f582cddca7f  vmovaps xmm14, [rsp+0xD0]
00007f582cddca88  vmovaps xmm15, [rsp+0xE0]
00007f582cddca91  add rsp, 0xF0
00007f582cddca98  pop r11
00007f582cddca9a  pop r10
00007f582cddca9c  pop r9
00007f582cddca9e  pop r8
00007f582cddcaa0  pop rsi
00007f582cddcaa1  pop rdi
00007f582cddcaa2  pop rdx
00007f582cddcaa3  pop rcx
00007f582cddcaa4  pop rax
00007f582cddcaa5  add rsp, 0x08
00007f582cddcaa9  jmp 0x00007F582CDDBB47
00007f582cddcaae  sub rsp, 0x08
00007f582cddcab2  push rax
00007f582cddcab3  push rcx
00007f582cddcab4  push rdx
00007f582cddcab5  push rdi
00007f582cddcab6  push rsi
00007f582cddcab7  push r8
00007f582cddcab9  push r9
00007f582cddcabb  push r10
00007f582cddcabd  push r11
00007f582cddcabf  sub rsp, 0xF0
00007f582cddcac6  vmovaps [rsp], xmm0
00007f582cddcacb  vmovaps [rsp+0x10], xmm1
00007f582cddcad1  vmovaps [rsp+0x20], xmm2
00007f582cddcad7  vmovaps [rsp+0x30], xmm3
00007f582cddcadd  vmovaps [rsp+0x40], xmm4
00007f582cddcae3  vmovaps [rsp+0x50], xmm5
00007f582cddcae9  vmovaps [rsp+0x60], xmm6
00007f582cddcaef  vmovaps [rsp+0x70], xmm8
00007f582cddcaf5  vmovaps [rsp+0x80], xmm9
00007f582cddcafe  vmovaps [rsp+0x90], xmm10
00007f582cddcb07  vmovaps [rsp+0xA0], xmm11
00007f582cddcb10  vmovaps [rsp+0xB0], xmm12
00007f582cddcb19  vmovaps [rsp+0xC0], xmm13
00007f582cddcb22  vmovaps [rsp+0xD0], xmm14
00007f582cddcb2b  vmovaps [rsp+0xE0], xmm15
00007f582cddcb34  sub rsp, 0x30
00007f582cddcb38  movaps [rsp], xmm7
00007f582cddcb3c  movaps [rsp+0x10], xmm9
00007f582cddcb42  movaps [rsp+0x20], xmm15
00007f582cddcb48  lea rdi, [rsp]
00007f582cddcb4c  mov esi, 0x00
00007f582cddcb51  mov rax, 0x653B0D9BF530
00007f582cddcb5b  call rax
00007f582cddcb5d  movaps xmm7, [rsp]
00007f582cddcb61  add rsp, 0x30
00007f582cddcb65  vmovaps xmm0, [rsp]
00007f582cddcb6a  vmovaps xmm1, [rsp+0x10]
00007f582cddcb70  vmovaps xmm2, [rsp+0x20]
00007f582cddcb76  vmovaps xmm3, [rsp+0x30]
00007f582cddcb7c  vmovaps xmm4, [rsp+0x40]
00007f582cddcb82  vmovaps xmm5, [rsp+0x50]
00007f582cddcb88  vmovaps xmm6, [rsp+0x60]
00007f582cddcb8e  vmovaps xmm8, [rsp+0x70]
00007f582cddcb94  vmovaps xmm9, [rsp+0x80]
00007f582cddcb9d  vmovaps xmm10, [rsp+0x90]
00007f582cddcba6  vmovaps xmm11, [rsp+0xA0]
00007f582cddcbaf  vmovaps xmm12, [rsp+0xB0]
00007f582cddcbb8  vmovaps xmm13, [rsp+0xC0]
00007f582cddcbc1  vmovaps xmm14, [rsp+0xD0]
00007f582cddcbca  vmovaps xmm15, [rsp+0xE0]
00007f582cddcbd3  add rsp, 0xF0
00007f582cddcbda  pop r11
00007f582cddcbdc  pop r10
00007f582cddcbde  pop r9
00007f582cddcbe0  pop r8
00007f582cddcbe2  pop rsi
00007f582cddcbe3  pop rdi
00007f582cddcbe4  pop rdx
00007f582cddcbe5  pop rcx
00007f582cddcbe6  pop rax
00007f582cddcbe7  add rsp, 0x08
00007f582cddcbeb  jmp 0x00007F582CDDBB75
00007f582cddcbf0  sub rsp, 0x08
00007f582cddcbf4  push rax
00007f582cddcbf5  push rcx
00007f582cddcbf6  push rdx
00007f582cddcbf7  push rdi
00007f582cddcbf8  push rsi
00007f582cddcbf9  push r8
00007f582cddcbfb  push r9
00007f582cddcbfd  push r10
00007f582cddcbff  push r11
00007f582cddcc01  sub rsp, 0xF0
00007f582cddcc08  vmovaps [rsp], xmm0
00007f582cddcc0d  vmovaps [rsp+0x10], xmm1
00007f582cddcc13  vmovaps [rsp+0x20], xmm2
00007f582cddcc19  vmovaps [rsp+0x30], xmm3
00007f582cddcc1f  vmovaps [rsp+0x40], xmm4
00007f582cddcc25  vmovaps [rsp+0x50], xmm5
00007f582cddcc2b  vmovaps [rsp+0x60], xmm6
00007f582cddcc31  vmovaps [rsp+0x70], xmm7
00007f582cddcc37  vmovaps [rsp+0x80], xmm8
00007f582cddcc40  vmovaps [rsp+0x90], xmm10
00007f582cddcc49  vmovaps [rsp+0xA0], xmm11
00007f582cddcc52  vmovaps [rsp+0xB0], xmm12
00007f582cddcc5b  vmovaps [rsp+0xC0], xmm13
00007f582cddcc64  vmovaps [rsp+0xD0], xmm14
00007f582cddcc6d  vmovaps [rsp+0xE0], xmm15
00007f582cddcc76  sub rsp, 0x30
00007f582cddcc7a  movaps [rsp], xmm9
00007f582cddcc7f  movaps [rsp+0x10], xmm12
00007f582cddcc85  movaps [rsp+0x20], xmm10
00007f582cddcc8b  lea rdi, [rsp]
00007f582cddcc8f  mov esi, 0x00
00007f582cddcc94  mov rax, 0x653B0D9BF530
00007f582cddcc9e  call rax
00007f582cddcca0  movaps xmm9, [rsp]
00007f582cddcca5  add rsp, 0x30
00007f582cddcca9  vmovaps xmm0, [rsp]
00007f582cddccae  vmovaps xmm1, [rsp+0x10]
00007f582cddccb4  vmovaps xmm2, [rsp+0x20]
00007f582cddccba  vmovaps xmm3, [rsp+0x30]
00007f582cddccc0  vmovaps xmm4, [rsp+0x40]
00007f582cddccc6  vmovaps xmm5, [rsp+0x50]
00007f582cddcccc  vmovaps xmm6, [rsp+0x60]
00007f582cddccd2  vmovaps xmm7, [rsp+0x70]
00007f582cddccd8  vmovaps xmm8, [rsp+0x80]
00007f582cddcce1  vmovaps xmm10, [rsp+0x90]
00007f582cddccea  vmovaps xmm11, [rsp+0xA0]
00007f582cddccf3  vmovaps xmm12, [rsp+0xB0]
00007f582cddccfc  vmovaps xmm13, [rsp+0xC0]
00007f582cddcd05  vmovaps xmm14, [rsp+0xD0]
00007f582cddcd0e  vmovaps xmm15, [rsp+0xE0]
00007f582cddcd17  add rsp, 0xF0
00007f582cddcd1e  pop r11
00007f582cddcd20  pop r10
00007f582cddcd22  pop r9
00007f582cddcd24  pop r8
00007f582cddcd26  pop rsi
00007f582cddcd27  pop rdi
00007f582cddcd28  pop rdx
00007f582cddcd29  pop rcx
00007f582cddcd2a  pop rax
00007f582cddcd2b  add rsp, 0x08
00007f582cddcd2f  jmp 0x00007F582CDDBB99
00007f582cddcd34  sub rsp, 0x08
00007f582cddcd38  push rax
00007f582cddcd39  push rcx
00007f582cddcd3a  push rdx
00007f582cddcd3b  push rdi
00007f582cddcd3c  push rsi
00007f582cddcd3d  push r8
00007f582cddcd3f  push r9
00007f582cddcd41  push r10
00007f582cddcd43  push r11
00007f582cddcd45  sub rsp, 0xF0
00007f582cddcd4c  vmovaps [rsp], xmm0
00007f582cddcd51  vmovaps [rsp+0x10], xmm1
00007f582cddcd57  vmovaps [rsp+0x20], xmm2
00007f582cddcd5d  vmovaps [rsp+0x30], xmm3
00007f582cddcd63  vmovaps [rsp+0x40], xmm4
00007f582cddcd69  vmovaps [rsp+0x50], xmm5
00007f582cddcd6f  vmovaps [rsp+0x60], xmm6
00007f582cddcd75  vmovaps [rsp+0x70], xmm7
00007f582cddcd7b  vmovaps [rsp+0x80], xmm8
00007f582cddcd84  vmovaps [rsp+0x90], xmm9
00007f582cddcd8d  vmovaps [rsp+0xA0], xmm11
00007f582cddcd96  vmovaps [rsp+0xB0], xmm12
00007f582cddcd9f  vmovaps [rsp+0xC0], xmm13
00007f582cddcda8  vmovaps [rsp+0xD0], xmm14
00007f582cddcdb1  vmovaps [rsp+0xE0], xmm15
00007f582cddcdba  sub rsp, 0x30
00007f582cddcdbe  movaps [rsp], xmm10
00007f582cddcdc3  movaps [rsp+0x10], xmm12
00007f582cddcdc9  movaps [rsp+0x20], xmm11
00007f582cddcdcf  lea rdi, [rsp]
00007f582cddcdd3  mov esi, 0x00
00007f582cddcdd8  mov rax, 0x653B0D9BF530
00007f582cddcde2  call rax
00007f582cddcde4  movaps xmm10, [rsp]
00007f582cddcde9  add rsp, 0x30
00007f582cddcded  vmovaps xmm0, [rsp]
00007f582cddcdf2  vmovaps xmm1, [rsp+0x10]
00007f582cddcdf8  vmovaps xmm2, [rsp+0x20]
00007f582cddcdfe  vmovaps xmm3, [rsp+0x30]
00007f582cddce04  vmovaps xmm4, [rsp+0x40]
00007f582cddce0a  vmovaps xmm5, [rsp+0x50]
00007f582cddce10  vmovaps xmm6, [rsp+0x60]
00007f582cddce16  vmovaps xmm7, [rsp+0x70]
00007f582cddce1c  vmovaps xmm8, [rsp+0x80]
00007f582cddce25  vmovaps xmm9, [rsp+0x90]
00007f582cddce2e  vmovaps xmm11, [rsp+0xA0]
00007f582cddce37  vmovaps xmm12, [rsp+0xB0]
00007f582cddce40  vmovaps xmm13, [rsp+0xC0]
00007f582cddce49  vmovaps xmm14, [rsp+0xD0]
00007f582cddce52  vmovaps xmm15, [rsp+0xE0]
00007f582cddce5b  add rsp, 0xF0
00007f582cddce62  pop r11
00007f582cddce64  pop r10
00007f582cddce66  pop r9
00007f582cddce68  pop r8
00007f582cddce6a  pop rsi
00007f582cddce6b  pop rdi
00007f582cddce6c  pop rdx
00007f582cddce6d  pop rcx
00007f582cddce6e  pop rax
00007f582cddce6f  add rsp, 0x08
00007f582cddce73  jmp 0x00007F582CDDBBB3
00007f582cddce78  sub rsp, 0x08
00007f582cddce7c  push rax
00007f582cddce7d  push rcx
00007f582cddce7e  push rdx
00007f582cddce7f  push rdi
00007f582cddce80  push rsi
00007f582cddce81  push r8
00007f582cddce83  push r9
00007f582cddce85  push r10
00007f582cddce87  push r11
00007f582cddce89  sub rsp, 0xF0
00007f582cddce90  vmovaps [rsp], xmm0
00007f582cddce95  vmovaps [rsp+0x10], xmm1
00007f582cddce9b  vmovaps [rsp+0x20], xmm2
00007f582cddcea1  vmovaps [rsp+0x30], xmm3
00007f582cddcea7  vmovaps [rsp+0x40], xmm4
00007f582cddcead  vmovaps [rsp+0x50], xmm5
00007f582cddceb3  vmovaps [rsp+0x60], xmm7
00007f582cddceb9  vmovaps [rsp+0x70], xmm8
00007f582cddcebf  vmovaps [rsp+0x80], xmm9
00007f582cddcec8  vmovaps [rsp+0x90], xmm10
00007f582cddced1  vmovaps [rsp+0xA0], xmm11
00007f582cddceda  vmovaps [rsp+0xB0], xmm12
00007f582cddcee3  vmovaps [rsp+0xC0], xmm13
00007f582cddceec  vmovaps [rsp+0xD0], xmm14
00007f582cddcef5  vmovaps [rsp+0xE0], xmm15
00007f582cddcefe  sub rsp, 0x30
00007f582cddcf02  movaps [rsp], xmm6
00007f582cddcf06  movaps [rsp+0x10], xmm12
00007f582cddcf0c  movaps [rsp+0x20], xmm11
00007f582cddcf12  lea rdi, [rsp]
00007f582cddcf16  mov esi, 0x00
00007f582cddcf1b  mov rax, 0x653B0D9BF530
00007f582cddcf25  call rax
00007f582cddcf27  movaps xmm6, [rsp]
00007f582cddcf2b  add rsp, 0x30
00007f582cddcf2f  vmovaps xmm0, [rsp]
00007f582cddcf34  vmovaps xmm1, [rsp+0x10]
00007f582cddcf3a  vmovaps xmm2, [rsp+0x20]
00007f582cddcf40  vmovaps xmm3, [rsp+0x30]
00007f582cddcf46  vmovaps xmm4, [rsp+0x40]
00007f582cddcf4c  vmovaps xmm5, [rsp+0x50]
00007f582cddcf52  vmovaps xmm7, [rsp+0x60]
00007f582cddcf58  vmovaps xmm8, [rsp+0x70]
00007f582cddcf5e  vmovaps xmm9, [rsp+0x80]
00007f582cddcf67  vmovaps xmm10, [rsp+0x90]
00007f582cddcf70  vmovaps xmm11, [rsp+0xA0]
00007f582cddcf79  vmovaps xmm12, [rsp+0xB0]
00007f582cddcf82  vmovaps xmm13, [rsp+0xC0]
00007f582cddcf8b  vmovaps xmm14, [rsp+0xD0]
00007f582cddcf94  vmovaps xmm15, [rsp+0xE0]
00007f582cddcf9d  add rsp, 0xF0
00007f582cddcfa4  pop r11
00007f582cddcfa6  pop r10
00007f582cddcfa8  pop r9
00007f582cddcfaa  pop r8
00007f582cddcfac  pop rsi
00007f582cddcfad  pop rdi
00007f582cddcfae  pop rdx
00007f582cddcfaf  pop rcx
00007f582cddcfb0  pop rax
00007f582cddcfb1  add rsp, 0x08
00007f582cddcfb5  jmp 0x00007F582CDDBBD4
00007f582cddcfba  sub rsp, 0x08
00007f582cddcfbe  push rax
00007f582cddcfbf  push rcx
00007f582cddcfc0  push rdx
00007f582cddcfc1  push rdi
00007f582cddcfc2  push rsi
00007f582cddcfc3  push r8
00007f582cddcfc5  push r9
00007f582cddcfc7  push r10
00007f582cddcfc9  push r11
00007f582cddcfcb  sub rsp, 0xF0
00007f582cddcfd2  vmovaps [rsp], xmm0
00007f582cddcfd7  vmovaps [rsp+0x10], xmm1
00007f582cddcfdd  vmovaps [rsp+0x20], xmm2
00007f582cddcfe3  vmovaps [rsp+0x30], xmm4
00007f582cddcfe9  vmovaps [rsp+0x40], xmm5
00007f582cddcfef  vmovaps [rsp+0x50], xmm6
00007f582cddcff5  vmovaps [rsp+0x60], xmm7
00007f582cddcffb  vmovaps [rsp+0x70], xmm8
00007f582cddd001  vmovaps [rsp+0x80], xmm9
00007f582cddd00a  vmovaps [rsp+0x90], xmm10
00007f582cddd013  vmovaps [rsp+0xA0], xmm11
00007f582cddd01c  vmovaps [rsp+0xB0], xmm12
00007f582cddd025  vmovaps [rsp+0xC0], xmm13
00007f582cddd02e  vmovaps [rsp+0xD0], xmm14
00007f582cddd037  vmovaps [rsp+0xE0], xmm15
00007f582cddd040  sub rsp, 0x30
00007f582cddd044  movaps [rsp], xmm3
00007f582cddd048  movaps [rsp+0x10], xmm5
00007f582cddd04d  movaps [rsp+0x20], xmm4
00007f582cddd052  lea rdi, [rsp]
00007f582cddd056  mov esi, 0x00
00007f582cddd05b  mov rax, 0x653B0D9BF530
00007f582cddd065  call rax
00007f582cddd067  movaps xmm3, [rsp]
00007f582cddd06b  add rsp, 0x30
00007f582cddd06f  vmovaps xmm0, [rsp]
00007f582cddd074  vmovaps xmm1, [rsp+0x10]
00007f582cddd07a  vmovaps xmm2, [rsp+0x20]
00007f582cddd080  vmovaps xmm4, [rsp+0x30]
00007f582cddd086  vmovaps xmm5, [rsp+0x40]
00007f582cddd08c  vmovaps xmm6, [rsp+0x50]
00007f582cddd092  vmovaps xmm7, [rsp+0x60]
00007f582cddd098  vmovaps xmm8, [rsp+0x70]
00007f582cddd09e  vmovaps xmm9, [rsp+0x80]
00007f582cddd0a7  vmovaps xmm10, [rsp+0x90]
00007f582cddd0b0  vmovaps xmm11, [rsp+0xA0]
00007f582cddd0b9  vmovaps xmm12, [rsp+0xB0]
00007f582cddd0c2  vmovaps xmm13, [rsp+0xC0]
00007f582cddd0cb  vmovaps xmm14, [rsp+0xD0]
00007f582cddd0d4  vmovaps xmm15, [rsp+0xE0]
00007f582cddd0dd  add rsp, 0xF0
00007f582cddd0e4  pop r11
00007f582cddd0e6  pop r10
00007f582cddd0e8  pop r9
00007f582cddd0ea  pop r8
00007f582cddd0ec  pop rsi
00007f582cddd0ed  pop rdi
00007f582cddd0ee  pop rdx
00007f582cddd0ef  pop rcx
00007f582cddd0f0  pop rax
00007f582cddd0f1  add rsp, 0x08
00007f582cddd0f5  jmp 0x00007F582CDDBC35
00007f582cddd0fa  sub rsp, 0x08
00007f582cddd0fe  push rax
00007f582cddd0ff  push rcx
00007f582cddd100  push rdx
00007f582cddd101  push rdi
00007f582cddd102  push rsi
00007f582cddd103  push r8
00007f582cddd105  push r9
00007f582cddd107  push r10
00007f582cddd109  push r11
00007f582cddd10b  sub rsp, 0xF0
00007f582cddd112  vmovaps [rsp], xmm0
00007f582cddd117  vmovaps [rsp+0x10], xmm1
00007f582cddd11d  vmovaps [rsp+0x20], xmm2
00007f582cddd123  vmovaps [rsp+0x30], xmm3
00007f582cddd129  vmovaps [rsp+0x40], xmm4
00007f582cddd12f  vmovaps [rsp+0x50], xmm6
00007f582cddd135  vmovaps [rsp+0x60], xmm7
00007f582cddd13b  vmovaps [rsp+0x70], xmm8
00007f582cddd141  vmovaps [rsp+0x80], xmm9
00007f582cddd14a  vmovaps [rsp+0x90], xmm10
00007f582cddd153  vmovaps [rsp+0xA0], xmm11
00007f582cddd15c  vmovaps [rsp+0xB0], xmm12
00007f582cddd165  vmovaps [rsp+0xC0], xmm13
00007f582cddd16e  vmovaps [rsp+0xD0], xmm14
00007f582cddd177  vmovaps [rsp+0xE0], xmm15
00007f582cddd180  sub rsp, 0x30
00007f582cddd184  movaps [rsp], xmm5
00007f582cddd188  movaps [rsp+0x10], xmm8
00007f582cddd18e  movaps [rsp+0x20], xmm15
00007f582cddd194  lea rdi, [rsp]
00007f582cddd198  mov esi, 0x00
00007f582cddd19d  mov rax, 0x653B0D9BF530
00007f582cddd1a7  call rax
00007f582cddd1a9  movaps xmm5, [rsp]
00007f582cddd1ad  add rsp, 0x30
00007f582cddd1b1  vmovaps xmm0, [rsp]
00007f582cddd1b6  vmovaps xmm1, [rsp+0x10]
00007f582cddd1bc  vmovaps xmm2, [rsp+0x20]
00007f582cddd1c2  vmovaps xmm3, [rsp+0x30]
00007f582cddd1c8  vmovaps xmm4, [rsp+0x40]
00007f582cddd1ce  vmovaps xmm6, [rsp+0x50]
00007f582cddd1d4  vmovaps xmm7, [rsp+0x60]
00007f582cddd1da  vmovaps xmm8, [rsp+0x70]
00007f582cddd1e0  vmovaps xmm9, [rsp+0x80]
00007f582cddd1e9  vmovaps xmm10, [rsp+0x90]
00007f582cddd1f2  vmovaps xmm11, [rsp+0xA0]
00007f582cddd1fb  vmovaps xmm12, [rsp+0xB0]
00007f582cddd204  vmovaps xmm13, [rsp+0xC0]
00007f582cddd20d  vmovaps xmm14, [rsp+0xD0]
00007f582cddd216  vmovaps xmm15, [rsp+0xE0]
00007f582cddd21f  add rsp, 0xF0
00007f582cddd226  pop r11
00007f582cddd228  pop r10
00007f582cddd22a  pop r9
00007f582cddd22c  pop r8
00007f582cddd22e  pop rsi
00007f582cddd22f  pop rdi
00007f582cddd230  pop rdx
00007f582cddd231  pop rcx
00007f582cddd232  pop rax
00007f582cddd233  add rsp, 0x08
00007f582cddd237  jmp 0x00007F582CDDBC73
00007f582cddd23c  sub rsp, 0x08
00007f582cddd240  push rax
00007f582cddd241  push rcx
00007f582cddd242  push rdx
00007f582cddd243  push rdi
00007f582cddd244  push rsi
00007f582cddd245  push r8
00007f582cddd247  push r9
00007f582cddd249  push r10
00007f582cddd24b  push r11
00007f582cddd24d  sub rsp, 0xF0
00007f582cddd254  vmovaps [rsp], xmm0
00007f582cddd259  vmovaps [rsp+0x10], xmm1
00007f582cddd25f  vmovaps [rsp+0x20], xmm2
00007f582cddd265  vmovaps [rsp+0x30], xmm3
00007f582cddd26b  vmovaps [rsp+0x40], xmm5
00007f582cddd271  vmovaps [rsp+0x50], xmm6
00007f582cddd277  vmovaps [rsp+0x60], xmm7
00007f582cddd27d  vmovaps [rsp+0x70], xmm8
00007f582cddd283  vmovaps [rsp+0x80], xmm9
00007f582cddd28c  vmovaps [rsp+0x90], xmm10
00007f582cddd295  vmovaps [rsp+0xA0], xmm11
00007f582cddd29e  vmovaps [rsp+0xB0], xmm12
00007f582cddd2a7  vmovaps [rsp+0xC0], xmm13
00007f582cddd2b0  vmovaps [rsp+0xD0], xmm14
00007f582cddd2b9  vmovaps [rsp+0xE0], xmm15
00007f582cddd2c2  sub rsp, 0x30
00007f582cddd2c6  movaps [rsp], xmm4
00007f582cddd2ca  movaps [rsp+0x10], xmm9
00007f582cddd2d0  movaps [rsp+0x20], xmm8
00007f582cddd2d6  lea rdi, [rsp]
00007f582cddd2da  mov esi, 0x00
00007f582cddd2df  mov rax, 0x653B0D9BF530
00007f582cddd2e9  call rax
00007f582cddd2eb  movaps xmm4, [rsp]
00007f582cddd2ef  add rsp, 0x30
00007f582cddd2f3  vmovaps xmm0, [rsp]
00007f582cddd2f8  vmovaps xmm1, [rsp+0x10]
00007f582cddd2fe  vmovaps xmm2, [rsp+0x20]
00007f582cddd304  vmovaps xmm3, [rsp+0x30]
00007f582cddd30a  vmovaps xmm5, [rsp+0x40]
00007f582cddd310  vmovaps xmm6, [rsp+0x50]
00007f582cddd316  vmovaps xmm7, [rsp+0x60]
00007f582cddd31c  vmovaps xmm8, [rsp+0x70]
00007f582cddd322  vmovaps xmm9, [rsp+0x80]
00007f582cddd32b  vmovaps xmm10, [rsp+0x90]
00007f582cddd334  vmovaps xmm11, [rsp+0xA0]
00007f582cddd33d  vmovaps xmm12, [rsp+0xB0]
00007f582cddd346  vmovaps xmm13, [rsp+0xC0]
00007f582cddd34f  vmovaps xmm14, [rsp+0xD0]
00007f582cddd358  vmovaps xmm15, [rsp+0xE0]
00007f582cddd361  add rsp, 0xF0
00007f582cddd368  pop r11
00007f582cddd36a  pop r10
00007f582cddd36c  pop r9
00007f582cddd36e  pop r8
00007f582cddd370  pop rsi
00007f582cddd371  pop rdi
00007f582cddd372  pop rdx
00007f582cddd373  pop rcx
00007f582cddd374  pop rax
00007f582cddd375  add rsp, 0x08
00007f582cddd379  jmp 0x00007F582CDDBC94
00007f582cddd37e  sub rsp, 0x08
00007f582cddd382  push rax
00007f582cddd383  push rcx
00007f582cddd384  push rdx
00007f582cddd385  push rdi
00007f582cddd386  push rsi
00007f582cddd387  push r8
00007f582cddd389  push r9
00007f582cddd38b  push r10
00007f582cddd38d  push r11
00007f582cddd38f  sub rsp, 0xF0
00007f582cddd396  vmovaps [rsp], xmm0
00007f582cddd39b  vmovaps [rsp+0x10], xmm1
00007f582cddd3a1  vmovaps [rsp+0x20], xmm2
00007f582cddd3a7  vmovaps [rsp+0x30], xmm3
00007f582cddd3ad  vmovaps [rsp+0x40], xmm4
00007f582cddd3b3  vmovaps [rsp+0x50], xmm5
00007f582cddd3b9  vmovaps [rsp+0x60], xmm6
00007f582cddd3bf  vmovaps [rsp+0x70], xmm7
00007f582cddd3c5  vmovaps [rsp+0x80], xmm8
00007f582cddd3ce  vmovaps [rsp+0x90], xmm10
00007f582cddd3d7  vmovaps [rsp+0xA0], xmm11
00007f582cddd3e0  vmovaps [rsp+0xB0], xmm12
00007f582cddd3e9  vmovaps [rsp+0xC0], xmm13
00007f582cddd3f2  vmovaps [rsp+0xD0], xmm14
00007f582cddd3fb  vmovaps [rsp+0xE0], xmm15
00007f582cddd404  sub rsp, 0x30
00007f582cddd408  movaps [rsp], xmm9
00007f582cddd40d  movaps [rsp+0x10], xmm10
00007f582cddd413  movaps [rsp+0x20], xmm8
00007f582cddd419  lea rdi, [rsp]
00007f582cddd41d  mov esi, 0x00
00007f582cddd422  mov rax, 0x653B0D9BF530
00007f582cddd42c  call rax
00007f582cddd42e  movaps xmm9, [rsp]
00007f582cddd433  add rsp, 0x30
00007f582cddd437  vmovaps xmm0, [rsp]
00007f582cddd43c  vmovaps xmm1, [rsp+0x10]
00007f582cddd442  vmovaps xmm2, [rsp+0x20]
00007f582cddd448  vmovaps xmm3, [rsp+0x30]
00007f582cddd44e  vmovaps xmm4, [rsp+0x40]
00007f582cddd454  vmovaps xmm5, [rsp+0x50]
00007f582cddd45a  vmovaps xmm6, [rsp+0x60]
00007f582cddd460  vmovaps xmm7, [rsp+0x70]
00007f582cddd466  vmovaps xmm8, [rsp+0x80]
00007f582cddd46f  vmovaps xmm10, [rsp+0x90]
00007f582cddd478  vmovaps xmm11, [rsp+0xA0]
00007f582cddd481  vmovaps xmm12, [rsp+0xB0]
00007f582cddd48a  vmovaps xmm13, [rsp+0xC0]
00007f582cddd493  vmovaps xmm14, [rsp+0xD0]
00007f582cddd49c  vmovaps xmm15, [rsp+0xE0]
00007f582cddd4a5  add rsp, 0xF0
00007f582cddd4ac  pop r11
00007f582cddd4ae  pop r10
00007f582cddd4b0  pop r9
00007f582cddd4b2  pop r8
00007f582cddd4b4  pop rsi
00007f582cddd4b5  pop rdi
00007f582cddd4b6  pop rdx
00007f582cddd4b7  pop rcx
00007f582cddd4b8  pop rax
00007f582cddd4b9  add rsp, 0x08
00007f582cddd4bd  jmp 0x00007F582CDDBCAE
00007f582cddd4c2  call 0x00007F582CCB52F0
00007f582cddd4c7  jmp 0x00007F582CDDBDC8
00007f582cddd4cc  call 0x00007F582CCB52F0
00007f582cddd4d1  jmp 0x00007F582CDDBDDE
00007f582cddd4d6  sub rsp, 0x08
00007f582cddd4da  push rax
00007f582cddd4db  push rcx
00007f582cddd4dc  push rdx
00007f582cddd4dd  push rdi
00007f582cddd4de  push rsi
00007f582cddd4df  push r8
00007f582cddd4e1  push r9
00007f582cddd4e3  push r10
00007f582cddd4e5  push r11
00007f582cddd4e7  sub rsp, 0xF0
00007f582cddd4ee  vmovaps [rsp], xmm0
00007f582cddd4f3  vmovaps [rsp+0x10], xmm2
00007f582cddd4f9  vmovaps [rsp+0x20], xmm3
00007f582cddd4ff  vmovaps [rsp+0x30], xmm4
00007f582cddd505  vmovaps [rsp+0x40], xmm5
00007f582cddd50b  vmovaps [rsp+0x50], xmm6
00007f582cddd511  vmovaps [rsp+0x60], xmm7
00007f582cddd517  vmovaps [rsp+0x70], xmm8
00007f582cddd51d  vmovaps [rsp+0x80], xmm9
00007f582cddd526  vmovaps [rsp+0x90], xmm10
00007f582cddd52f  vmovaps [rsp+0xA0], xmm11
00007f582cddd538  vmovaps [rsp+0xB0], xmm12
00007f582cddd541  vmovaps [rsp+0xC0], xmm13
00007f582cddd54a  vmovaps [rsp+0xD0], xmm14
00007f582cddd553  vmovaps [rsp+0xE0], xmm15
00007f582cddd55c  sub rsp, 0x30
00007f582cddd560  movaps [rsp], xmm1
00007f582cddd564  movaps [rsp+0x10], xmm6
00007f582cddd569  movaps [rsp+0x20], xmm15
00007f582cddd56f  lea rdi, [rsp]
00007f582cddd573  mov esi, 0x00
00007f582cddd578  mov rax, 0x653B0D9BF530
00007f582cddd582  call rax
00007f582cddd584  movaps xmm1, [rsp]
00007f582cddd588  add rsp, 0x30
00007f582cddd58c  vmovaps xmm0, [rsp]
00007f582cddd591  vmovaps xmm2, [rsp+0x10]
00007f582cddd597  vmovaps xmm3, [rsp+0x20]
00007f582cddd59d  vmovaps xmm4, [rsp+0x30]
00007f582cddd5a3  vmovaps xmm5, [rsp+0x40]
00007f582cddd5a9  vmovaps xmm6, [rsp+0x50]
00007f582cddd5af  vmovaps xmm7, [rsp+0x60]
00007f582cddd5b5  vmovaps xmm8, [rsp+0x70]
00007f582cddd5bb  vmovaps xmm9, [rsp+0x80]
00007f582cddd5c4  vmovaps xmm10, [rsp+0x90]
00007f582cddd5cd  vmovaps xmm11, [rsp+0xA0]
00007f582cddd5d6  vmovaps xmm12, [rsp+0xB0]
00007f582cddd5df  vmovaps xmm13, [rsp+0xC0]
00007f582cddd5e8  vmovaps xmm14, [rsp+0xD0]
00007f582cddd5f1  vmovaps xmm15, [rsp+0xE0]
00007f582cddd5fa  add rsp, 0xF0
00007f582cddd601  pop r11
00007f582cddd603  pop r10
00007f582cddd605  pop r9
00007f582cddd607  pop r8
00007f582cddd609  pop rsi
00007f582cddd60a  pop rdi
00007f582cddd60b  pop rdx
00007f582cddd60c  pop rcx
00007f582cddd60d  pop rax
00007f582cddd60e  add rsp, 0x08
00007f582cddd612  jmp 0x00007F582CDDBE1B
00007f582cddd617  call 0x00007F582CCC4620
00007f582cddd61c  jmp 0x00007F582CDDBE28
00007f582cddd621  sub rsp, 0x08
00007f582cddd625  push rax
00007f582cddd626  push rcx
00007f582cddd627  push rdx
00007f582cddd628  push rdi
00007f582cddd629  push rsi
00007f582cddd62a  push r8
00007f582cddd62c  push r9
00007f582cddd62e  push r10
00007f582cddd630  push r11
00007f582cddd632  sub rsp, 0xF0
00007f582cddd639  vmovaps [rsp], xmm0
00007f582cddd63e  vmovaps [rsp+0x10], xmm1
00007f582cddd644  vmovaps [rsp+0x20], xmm2
00007f582cddd64a  vmovaps [rsp+0x30], xmm3
00007f582cddd650  vmovaps [rsp+0x40], xmm4
00007f582cddd656  vmovaps [rsp+0x50], xmm5
00007f582cddd65c  vmovaps [rsp+0x60], xmm6
00007f582cddd662  vmovaps [rsp+0x70], xmm7
00007f582cddd668  vmovaps [rsp+0x80], xmm8
00007f582cddd671  vmovaps [rsp+0x90], xmm9
00007f582cddd67a  vmovaps [rsp+0xA0], xmm10
00007f582cddd683  vmovaps [rsp+0xB0], xmm11
00007f582cddd68c  vmovaps [rsp+0xC0], xmm12
00007f582cddd695  vmovaps [rsp+0xD0], xmm13
00007f582cddd69e  vmovaps [rsp+0xE0], xmm15
00007f582cddd6a7  sub rsp, 0x30
00007f582cddd6ab  movaps [rsp], xmm14
00007f582cddd6b0  movaps [rsp+0x10], xmm4
00007f582cddd6b5  movaps [rsp+0x20], xmm3
00007f582cddd6ba  lea rdi, [rsp]
00007f582cddd6be  mov esi, 0x00
00007f582cddd6c3  mov rax, 0x653B0D9BF530
00007f582cddd6cd  call rax
00007f582cddd6cf  movaps xmm14, [rsp]
00007f582cddd6d4  add rsp, 0x30
00007f582cddd6d8  vmovaps xmm0, [rsp]
00007f582cddd6dd  vmovaps xmm1, [rsp+0x10]
00007f582cddd6e3  vmovaps xmm2, [rsp+0x20]
00007f582cddd6e9  vmovaps xmm3, [rsp+0x30]
00007f582cddd6ef  vmovaps xmm4, [rsp+0x40]
00007f582cddd6f5  vmovaps xmm5, [rsp+0x50]
00007f582cddd6fb  vmovaps xmm6, [rsp+0x60]
00007f582cddd701  vmovaps xmm7, [rsp+0x70]
00007f582cddd707  vmovaps xmm8, [rsp+0x80]
00007f582cddd710  vmovaps xmm9, [rsp+0x90]
00007f582cddd719  vmovaps xmm10, [rsp+0xA0]
00007f582cddd722  vmovaps xmm11, [rsp+0xB0]
00007f582cddd72b  vmovaps xmm12, [rsp+0xC0]
00007f582cddd734  vmovaps xmm13, [rsp+0xD0]
00007f582cddd73d  vmovaps xmm15, [rsp+0xE0]
00007f582cddd746  add rsp, 0xF0
00007f582cddd74d  pop r11
00007f582cddd74f  pop r10
00007f582cddd751  pop r9
00007f582cddd753  pop r8
00007f582cddd755  pop rsi
00007f582cddd756  pop rdi
00007f582cddd757  pop rdx
00007f582cddd758  pop rcx
00007f582cddd759  pop rax
00007f582cddd75a  add rsp, 0x08
00007f582cddd75e  jmp 0x00007F582CDDBE42
00007f582cddd763  sub rsp, 0x08
00007f582cddd767  push rax
00007f582cddd768  push rcx
00007f582cddd769  push rdx
00007f582cddd76a  push rdi
00007f582cddd76b  push rsi
00007f582cddd76c  push r8
00007f582cddd76e  push r9
00007f582cddd770  push r10
00007f582cddd772  push r11
00007f582cddd774  sub rsp, 0xF0
00007f582cddd77b  vmovaps [rsp], xmm0
00007f582cddd780  vmovaps [rsp+0x10], xmm1
00007f582cddd786  vmovaps [rsp+0x20], xmm2
00007f582cddd78c  vmovaps [rsp+0x30], xmm3
00007f582cddd792  vmovaps [rsp+0x40], xmm4
00007f582cddd798  vmovaps [rsp+0x50], xmm5
00007f582cddd79e  vmovaps [rsp+0x60], xmm7
00007f582cddd7a4  vmovaps [rsp+0x70], xmm8
00007f582cddd7aa  vmovaps [rsp+0x80], xmm9
00007f582cddd7b3  vmovaps [rsp+0x90], xmm10
00007f582cddd7bc  vmovaps [rsp+0xA0], xmm11
00007f582cddd7c5  vmovaps [rsp+0xB0], xmm12
00007f582cddd7ce  vmovaps [rsp+0xC0], xmm13
00007f582cddd7d7  vmovaps [rsp+0xD0], xmm14
00007f582cddd7e0  vmovaps [rsp+0xE0], xmm15
00007f582cddd7e9  sub rsp, 0x30
00007f582cddd7ed  movaps [rsp], xmm6
00007f582cddd7f1  movaps [rsp+0x10], xmm9
00007f582cddd7f7  movaps [rsp+0x20], xmm7
00007f582cddd7fc  lea rdi, [rsp]
00007f582cddd800  mov esi, 0x00
00007f582cddd805  mov rax, 0x653B0D9BF530
00007f582cddd80f  call rax
00007f582cddd811  movaps xmm6, [rsp]
00007f582cddd815  add rsp, 0x30
00007f582cddd819  vmovaps xmm0, [rsp]
00007f582cddd81e  vmovaps xmm1, [rsp+0x10]
00007f582cddd824  vmovaps xmm2, [rsp+0x20]
00007f582cddd82a  vmovaps xmm3, [rsp+0x30]
00007f582cddd830  vmovaps xmm4, [rsp+0x40]
00007f582cddd836  vmovaps xmm5, [rsp+0x50]
00007f582cddd83c  vmovaps xmm7, [rsp+0x60]
00007f582cddd842  vmovaps xmm8, [rsp+0x70]
00007f582cddd848  vmovaps xmm9, [rsp+0x80]
00007f582cddd851  vmovaps xmm10, [rsp+0x90]
00007f582cddd85a  vmovaps xmm11, [rsp+0xA0]
00007f582cddd863  vmovaps xmm12, [rsp+0xB0]
00007f582cddd86c  vmovaps xmm13, [rsp+0xC0]
00007f582cddd875  vmovaps xmm14, [rsp+0xD0]
00007f582cddd87e  vmovaps xmm15, [rsp+0xE0]
00007f582cddd887  add rsp, 0xF0
00007f582cddd88e  pop r11
00007f582cddd890  pop r10
00007f582cddd892  pop r9
00007f582cddd894  pop r8
00007f582cddd896  pop rsi
00007f582cddd897  pop rdi
00007f582cddd898  pop rdx
00007f582cddd899  pop rcx
00007f582cddd89a  pop rax
00007f582cddd89b  add rsp, 0x08
00007f582cddd89f  jmp 0x00007F582CDDBE5A
00007f582cddd8a4  sub rsp, 0x08
00007f582cddd8a8  push rax
00007f582cddd8a9  push rcx
00007f582cddd8aa  push rdx
00007f582cddd8ab  push rdi
00007f582cddd8ac  push rsi
00007f582cddd8ad  push r8
00007f582cddd8af  push r9
00007f582cddd8b1  push r10
00007f582cddd8b3  push r11
00007f582cddd8b5  sub rsp, 0xF0
00007f582cddd8bc  vmovaps [rsp], xmm0
00007f582cddd8c1  vmovaps [rsp+0x10], xmm1
00007f582cddd8c7  vmovaps [rsp+0x20], xmm2
00007f582cddd8cd  vmovaps [rsp+0x30], xmm3
00007f582cddd8d3  vmovaps [rsp+0x40], xmm4
00007f582cddd8d9  vmovaps [rsp+0x50], xmm5
00007f582cddd8df  vmovaps [rsp+0x60], xmm6
00007f582cddd8e5  vmovaps [rsp+0x70], xmm8
00007f582cddd8eb  vmovaps [rsp+0x80], xmm9
00007f582cddd8f4  vmovaps [rsp+0x90], xmm10
00007f582cddd8fd  vmovaps [rsp+0xA0], xmm11
00007f582cddd906  vmovaps [rsp+0xB0], xmm12
00007f582cddd90f  vmovaps [rsp+0xC0], xmm13
00007f582cddd918  vmovaps [rsp+0xD0], xmm14
00007f582cddd921  vmovaps [rsp+0xE0], xmm15
00007f582cddd92a  sub rsp, 0x30
00007f582cddd92e  movaps [rsp], xmm7
00007f582cddd932  movaps [rsp+0x10], xmm4
00007f582cddd937  movaps [rsp+0x20], xmm9
00007f582cddd93d  lea rdi, [rsp]
00007f582cddd941  mov esi, 0x00
00007f582cddd946  mov rax, 0x653B0D9BF530
00007f582cddd950  call rax
00007f582cddd952  movaps xmm7, [rsp]
00007f582cddd956  add rsp, 0x30
00007f582cddd95a  vmovaps xmm0, [rsp]
00007f582cddd95f  vmovaps xmm1, [rsp+0x10]
00007f582cddd965  vmovaps xmm2, [rsp+0x20]
00007f582cddd96b  vmovaps xmm3, [rsp+0x30]
00007f582cddd971  vmovaps xmm4, [rsp+0x40]
00007f582cddd977  vmovaps xmm5, [rsp+0x50]
00007f582cddd97d  vmovaps xmm6, [rsp+0x60]
00007f582cddd983  vmovaps xmm8, [rsp+0x70]
00007f582cddd989  vmovaps xmm9, [rsp+0x80]
00007f582cddd992  vmovaps xmm10, [rsp+0x90]
00007f582cddd99b  vmovaps xmm11, [rsp+0xA0]
00007f582cddd9a4  vmovaps xmm12, [rsp+0xB0]
00007f582cddd9ad  vmovaps xmm13, [rsp+0xC0]
00007f582cddd9b6  vmovaps xmm14, [rsp+0xD0]
00007f582cddd9bf  vmovaps xmm15, [rsp+0xE0]
00007f582cddd9c8  add rsp, 0xF0
00007f582cddd9cf  pop r11
00007f582cddd9d1  pop r10
00007f582cddd9d3  pop r9
00007f582cddd9d5  pop r8
00007f582cddd9d7  pop rsi
00007f582cddd9d8  pop rdi
00007f582cddd9d9  pop rdx
00007f582cddd9da  pop rcx
00007f582cddd9db  pop rax
00007f582cddd9dc  add rsp, 0x08
00007f582cddd9e0  jmp 0x00007F582CDDBE87
00007f582cddd9e5  sub rsp, 0x08
00007f582cddd9e9  push rax
00007f582cddd9ea  push rcx
00007f582cddd9eb  push rdx
00007f582cddd9ec  push rdi
00007f582cddd9ed  push rsi
00007f582cddd9ee  push r8
00007f582cddd9f0  push r9
00007f582cddd9f2  push r10
00007f582cddd9f4  push r11
00007f582cddd9f6  sub rsp, 0xF0
00007f582cddd9fd  vmovaps [rsp], xmm0
00007f582cddda02  vmovaps [rsp+0x10], xmm1
00007f582cddda08  vmovaps [rsp+0x20], xmm2
00007f582cddda0e  vmovaps [rsp+0x30], xmm3
00007f582cddda14  vmovaps [rsp+0x40], xmm5
00007f582cddda1a  vmovaps [rsp+0x50], xmm6
00007f582cddda20  vmovaps [rsp+0x60], xmm7
00007f582cddda26  vmovaps [rsp+0x70], xmm8
00007f582cddda2c  vmovaps [rsp+0x80], xmm9
00007f582cddda35  vmovaps [rsp+0x90], xmm10
00007f582cddda3e  vmovaps [rsp+0xA0], xmm11
00007f582cddda47  vmovaps [rsp+0xB0], xmm12
00007f582cddda50  vmovaps [rsp+0xC0], xmm13
00007f582cddda59  vmovaps [rsp+0xD0], xmm14
00007f582cddda62  vmovaps [rsp+0xE0], xmm15
00007f582cddda6b  sub rsp, 0x30
00007f582cddda6f  movaps [rsp], xmm4
00007f582cddda73  movaps [rsp+0x10], xmm15
00007f582cddda79  movaps [rsp+0x20], xmm9
00007f582cddda7f  lea rdi, [rsp]
00007f582cddda83  mov esi, 0x00
00007f582cddda88  mov rax, 0x653B0D9BF530
00007f582cddda92  call rax
00007f582cddda94  movaps xmm4, [rsp]
00007f582cddda98  add rsp, 0x30
00007f582cddda9c  vmovaps xmm0, [rsp]
00007f582cdddaa1  vmovaps xmm1, [rsp+0x10]
00007f582cdddaa7  vmovaps xmm2, [rsp+0x20]
00007f582cdddaad  vmovaps xmm3, [rsp+0x30]
00007f582cdddab3  vmovaps xmm5, [rsp+0x40]
00007f582cdddab9  vmovaps xmm6, [rsp+0x50]
00007f582cdddabf  vmovaps xmm7, [rsp+0x60]
00007f582cdddac5  vmovaps xmm8, [rsp+0x70]
00007f582cdddacb  vmovaps xmm9, [rsp+0x80]
00007f582cdddad4  vmovaps xmm10, [rsp+0x90]
00007f582cdddadd  vmovaps xmm11, [rsp+0xA0]
00007f582cdddae6  vmovaps xmm12, [rsp+0xB0]
00007f582cdddaef  vmovaps xmm13, [rsp+0xC0]
00007f582cdddaf8  vmovaps xmm14, [rsp+0xD0]
00007f582cdddb01  vmovaps xmm15, [rsp+0xE0]
00007f582cdddb0a  add rsp, 0xF0
00007f582cdddb11  pop r11
00007f582cdddb13  pop r10
00007f582cdddb15  pop r9
00007f582cdddb17  pop r8
00007f582cdddb19  pop rsi
00007f582cdddb1a  pop rdi
00007f582cdddb1b  pop rdx
00007f582cdddb1c  pop rcx
00007f582cdddb1d  pop rax
00007f582cdddb1e  add rsp, 0x08
00007f582cdddb22  jmp 0x00007F582CDDBEAC
00007f582cdddb27  call 0x00007F582CCC4620
00007f582cdddb2c  jmp 0x00007F582CDDBEB9
00007f582cdddb31  sub rsp, 0x08
00007f582cdddb35  push rax
00007f582cdddb36  push rcx
00007f582cdddb37  push rdx
00007f582cdddb38  push rdi
00007f582cdddb39  push rsi
00007f582cdddb3a  push r8
00007f582cdddb3c  push r9
00007f582cdddb3e  push r10
00007f582cdddb40  push r11
00007f582cdddb42  sub rsp, 0xF0
00007f582cdddb49  vmovaps [rsp], xmm0
00007f582cdddb4e  vmovaps [rsp+0x10], xmm1
00007f582cdddb54  vmovaps [rsp+0x20], xmm2
00007f582cdddb5a  vmovaps [rsp+0x30], xmm4
00007f582cdddb60  vmovaps [rsp+0x40], xmm5
00007f582cdddb66  vmovaps [rsp+0x50], xmm6
00007f582cdddb6c  vmovaps [rsp+0x60], xmm7
00007f582cdddb72  vmovaps [rsp+0x70], xmm8
00007f582cdddb78  vmovaps [rsp+0x80], xmm9
00007f582cdddb81  vmovaps [rsp+0x90], xmm10
00007f582cdddb8a  vmovaps [rsp+0xA0], xmm11
00007f582cdddb93  vmovaps [rsp+0xB0], xmm12
00007f582cdddb9c  vmovaps [rsp+0xC0], xmm13
00007f582cdddba5  vmovaps [rsp+0xD0], xmm14
00007f582cdddbae  vmovaps [rsp+0xE0], xmm15
00007f582cdddbb7  sub rsp, 0x30
00007f582cdddbbb  movaps [rsp], xmm3
00007f582cdddbbf  movaps [rsp+0x10], xmm1
00007f582cdddbc4  movaps [rsp+0x20], xmm9
00007f582cdddbca  lea rdi, [rsp]
00007f582cdddbce  mov esi, 0x00
00007f582cdddbd3  mov rax, 0x653B0D9BF530
00007f582cdddbdd  call rax
00007f582cdddbdf  movaps xmm3, [rsp]
00007f582cdddbe3  add rsp, 0x30
00007f582cdddbe7  vmovaps xmm0, [rsp]
00007f582cdddbec  vmovaps xmm1, [rsp+0x10]
00007f582cdddbf2  vmovaps xmm2, [rsp+0x20]
00007f582cdddbf8  vmovaps xmm4, [rsp+0x30]
00007f582cdddbfe  vmovaps xmm5, [rsp+0x40]
00007f582cdddc04  vmovaps xmm6, [rsp+0x50]
00007f582cdddc0a  vmovaps xmm7, [rsp+0x60]
00007f582cdddc10  vmovaps xmm8, [rsp+0x70]
00007f582cdddc16  vmovaps xmm9, [rsp+0x80]
00007f582cdddc1f  vmovaps xmm10, [rsp+0x90]
00007f582cdddc28  vmovaps xmm11, [rsp+0xA0]
00007f582cdddc31  vmovaps xmm12, [rsp+0xB0]
00007f582cdddc3a  vmovaps xmm13, [rsp+0xC0]
00007f582cdddc43  vmovaps xmm14, [rsp+0xD0]
00007f582cdddc4c  vmovaps xmm15, [rsp+0xE0]
00007f582cdddc55  add rsp, 0xF0
00007f582cdddc5c  pop r11
00007f582cdddc5e  pop r10
00007f582cdddc60  pop r9
00007f582cdddc62  pop r8
00007f582cdddc64  pop rsi
00007f582cdddc65  pop rdi
00007f582cdddc66  pop rdx
00007f582cdddc67  pop rcx
00007f582cdddc68  pop rax
00007f582cdddc69  add rsp, 0x08
00007f582cdddc6d  jmp 0x00007F582CDDBEF6
00007f582cdddc72  sub rsp, 0x08
00007f582cdddc76  push rax
00007f582cdddc77  push rcx
00007f582cdddc78  push rdx
00007f582cdddc79  push rdi
00007f582cdddc7a  push rsi
00007f582cdddc7b  push r8
00007f582cdddc7d  push r9
00007f582cdddc7f  push r10
00007f582cdddc81  push r11
00007f582cdddc83  sub rsp, 0xF0
00007f582cdddc8a  vmovaps [rsp], xmm0
00007f582cdddc8f  vmovaps [rsp+0x10], xmm2
00007f582cdddc95  vmovaps [rsp+0x20], xmm3
00007f582cdddc9b  vmovaps [rsp+0x30], xmm4
00007f582cdddca1  vmovaps [rsp+0x40], xmm5
00007f582cdddca7  vmovaps [rsp+0x50], xmm6
00007f582cdddcad  vmovaps [rsp+0x60], xmm7
00007f582cdddcb3  vmovaps [rsp+0x70], xmm8
00007f582cdddcb9  vmovaps [rsp+0x80], xmm9
00007f582cdddcc2  vmovaps [rsp+0x90], xmm10
00007f582cdddccb  vmovaps [rsp+0xA0], xmm11
00007f582cdddcd4  vmovaps [rsp+0xB0], xmm12
00007f582cdddcdd  vmovaps [rsp+0xC0], xmm13
00007f582cdddce6  vmovaps [rsp+0xD0], xmm14
00007f582cdddcef  vmovaps [rsp+0xE0], xmm15
00007f582cdddcf8  sub rsp, 0x30
00007f582cdddcfc  movaps [rsp], xmm1
00007f582cdddd00  movaps [rsp+0x10], xmm15
00007f582cdddd06  movaps [rsp+0x20], xmm9
00007f582cdddd0c  lea rdi, [rsp]
00007f582cdddd10  mov esi, 0x00
00007f582cdddd15  mov rax, 0x653B0D9BF530
00007f582cdddd1f  call rax
00007f582cdddd21  movaps xmm1, [rsp]
00007f582cdddd25  add rsp, 0x30
00007f582cdddd29  vmovaps xmm0, [rsp]
00007f582cdddd2e  vmovaps xmm2, [rsp+0x10]
00007f582cdddd34  vmovaps xmm3, [rsp+0x20]
00007f582cdddd3a  vmovaps xmm4, [rsp+0x30]
00007f582cdddd40  vmovaps xmm5, [rsp+0x40]
00007f582cdddd46  vmovaps xmm6, [rsp+0x50]
00007f582cdddd4c  vmovaps xmm7, [rsp+0x60]
00007f582cdddd52  vmovaps xmm8, [rsp+0x70]
00007f582cdddd58  vmovaps xmm9, [rsp+0x80]
00007f582cdddd61  vmovaps xmm10, [rsp+0x90]
00007f582cdddd6a  vmovaps xmm11, [rsp+0xA0]
00007f582cdddd73  vmovaps xmm12, [rsp+0xB0]
00007f582cdddd7c  vmovaps xmm13, [rsp+0xC0]
00007f582cdddd85  vmovaps xmm14, [rsp+0xD0]
00007f582cdddd8e  vmovaps xmm15, [rsp+0xE0]
00007f582cdddd97  add rsp, 0xF0
00007f582cdddd9e  pop r11
00007f582cdddda0  pop r10
00007f582cdddda2  pop r9
00007f582cdddda4  pop r8
00007f582cdddda6  pop rsi
00007f582cdddda7  pop rdi
00007f582cdddda8  pop rdx
00007f582cdddda9  pop rcx
00007f582cddddaa  pop rax
00007f582cddddab  add rsp, 0x08
00007f582cddddaf  jmp 0x00007F582CDDBF7E
00007f582cddddb4  call 0x00007F582CCC4620
00007f582cddddb9  jmp 0x00007F582CDDBF8B
00007f582cddddbe  sub rsp, 0x08
00007f582cddddc2  push rax
00007f582cddddc3  push rcx
00007f582cddddc4  push rdx
00007f582cddddc5  push rdi
00007f582cddddc6  push rsi
00007f582cddddc7  push r8
00007f582cddddc9  push r9
00007f582cddddcb  push r10
00007f582cddddcd  push r11
00007f582cddddcf  sub rsp, 0xF0
00007f582cddddd6  vmovaps [rsp], xmm0
00007f582cdddddb  vmovaps [rsp+0x10], xmm2
00007f582cdddde1  vmovaps [rsp+0x20], xmm3
00007f582cdddde7  vmovaps [rsp+0x30], xmm4
00007f582cdddded  vmovaps [rsp+0x40], xmm5
00007f582cddddf3  vmovaps [rsp+0x50], xmm6
00007f582cddddf9  vmovaps [rsp+0x60], xmm7
00007f582cddddff  vmovaps [rsp+0x70], xmm8
00007f582cddde05  vmovaps [rsp+0x80], xmm9
00007f582cddde0e  vmovaps [rsp+0x90], xmm10
00007f582cddde17  vmovaps [rsp+0xA0], xmm11
00007f582cddde20  vmovaps [rsp+0xB0], xmm12
00007f582cddde29  vmovaps [rsp+0xC0], xmm13
00007f582cddde32  vmovaps [rsp+0xD0], xmm14
00007f582cddde3b  vmovaps [rsp+0xE0], xmm15
00007f582cddde44  sub rsp, 0x30
00007f582cddde48  movaps [rsp], xmm1
00007f582cddde4c  movaps [rsp+0x10], xmm5
00007f582cddde51  movaps [rsp+0x20], xmm7
00007f582cddde56  lea rdi, [rsp]
00007f582cddde5a  mov esi, 0x00
00007f582cddde5f  mov rax, 0x653B0D9BF530
00007f582cddde69  call rax
00007f582cddde6b  movaps xmm1, [rsp]
00007f582cddde6f  add rsp, 0x30
00007f582cddde73  vmovaps xmm0, [rsp]
00007f582cddde78  vmovaps xmm2, [rsp+0x10]
00007f582cddde7e  vmovaps xmm3, [rsp+0x20]
00007f582cddde84  vmovaps xmm4, [rsp+0x30]
00007f582cddde8a  vmovaps xmm5, [rsp+0x40]
00007f582cddde90  vmovaps xmm6, [rsp+0x50]
00007f582cddde96  vmovaps xmm7, [rsp+0x60]
00007f582cddde9c  vmovaps xmm8, [rsp+0x70]
00007f582cdddea2  vmovaps xmm9, [rsp+0x80]
00007f582cdddeab  vmovaps xmm10, [rsp+0x90]
00007f582cdddeb4  vmovaps xmm11, [rsp+0xA0]
00007f582cdddebd  vmovaps xmm12, [rsp+0xB0]
00007f582cdddec6  vmovaps xmm13, [rsp+0xC0]
00007f582cdddecf  vmovaps xmm14, [rsp+0xD0]
00007f582cddded8  vmovaps xmm15, [rsp+0xE0]
00007f582cdddee1  add rsp, 0xF0
00007f582cdddee8  pop r11
00007f582cdddeea  pop r10
00007f582cdddeec  pop r9
00007f582cdddeee  pop r8
00007f582cdddef0  pop rsi
00007f582cdddef1  pop rdi
00007f582cdddef2  pop rdx
00007f582cdddef3  pop rcx
00007f582cdddef4  pop rax
00007f582cdddef5  add rsp, 0x08
00007f582cdddef9  jmp 0x00007F582CDDC030
00007f582cdddefe  sub rsp, 0x08
00007f582cdddf02  push rax
00007f582cdddf03  push rcx
00007f582cdddf04  push rdx
00007f582cdddf05  push rdi
00007f582cdddf06  push rsi
00007f582cdddf07  push r8
00007f582cdddf09  push r9
00007f582cdddf0b  push r10
00007f582cdddf0d  push r11
00007f582cdddf0f  sub rsp, 0xF0
00007f582cdddf16  vmovaps [rsp], xmm0
00007f582cdddf1b  vmovaps [rsp+0x10], xmm1
00007f582cdddf21  vmovaps [rsp+0x20], xmm2
00007f582cdddf27  vmovaps [rsp+0x30], xmm3
00007f582cdddf2d  vmovaps [rsp+0x40], xmm4
00007f582cdddf33  vmovaps [rsp+0x50], xmm5
00007f582cdddf39  vmovaps [rsp+0x60], xmm6
00007f582cdddf3f  vmovaps [rsp+0x70], xmm8
00007f582cdddf45  vmovaps [rsp+0x80], xmm9
00007f582cdddf4e  vmovaps [rsp+0x90], xmm10
00007f582cdddf57  vmovaps [rsp+0xA0], xmm11
00007f582cdddf60  vmovaps [rsp+0xB0], xmm12
00007f582cdddf69  vmovaps [rsp+0xC0], xmm13
00007f582cdddf72  vmovaps [rsp+0xD0], xmm14
00007f582cdddf7b  vmovaps [rsp+0xE0], xmm15
00007f582cdddf84  sub rsp, 0x30
00007f582cdddf88  movaps [rsp], xmm7
00007f582cdddf8c  movaps [rsp+0x10], xmm5
00007f582cdddf91  movaps [rsp+0x20], xmm15
00007f582cdddf97  lea rdi, [rsp]
00007f582cdddf9b  mov esi, 0x00
00007f582cdddfa0  mov rax, 0x653B0D9BF530
00007f582cdddfaa  call rax
00007f582cdddfac  movaps xmm7, [rsp]
00007f582cdddfb0  add rsp, 0x30
00007f582cdddfb4  vmovaps xmm0, [rsp]
00007f582cdddfb9  vmovaps xmm1, [rsp+0x10]
00007f582cdddfbf  vmovaps xmm2, [rsp+0x20]
00007f582cdddfc5  vmovaps xmm3, [rsp+0x30]
00007f582cdddfcb  vmovaps xmm4, [rsp+0x40]
00007f582cdddfd1  vmovaps xmm5, [rsp+0x50]
00007f582cdddfd7  vmovaps xmm6, [rsp+0x60]
00007f582cdddfdd  vmovaps xmm8, [rsp+0x70]
00007f582cdddfe3  vmovaps xmm9, [rsp+0x80]
00007f582cdddfec  vmovaps xmm10, [rsp+0x90]
00007f582cdddff5  vmovaps xmm11, [rsp+0xA0]
00007f582cdddffe  vmovaps xmm12, [rsp+0xB0]
00007f582cdde007  vmovaps xmm13, [rsp+0xC0]
00007f582cdde010  vmovaps xmm14, [rsp+0xD0]
00007f582cdde019  vmovaps xmm15, [rsp+0xE0]
00007f582cdde022  add rsp, 0xF0
00007f582cdde029  pop r11
00007f582cdde02b  pop r10
00007f582cdde02d  pop r9
00007f582cdde02f  pop r8
00007f582cdde031  pop rsi
00007f582cdde032  pop rdi
00007f582cdde033  pop rdx
00007f582cdde034  pop rcx
00007f582cdde035  pop rax
00007f582cdde036  add rsp, 0x08
00007f582cdde03a  jmp 0x00007F582CDDC066
00007f582cdde03f  call 0x00007F582CCB52F0
00007f582cdde044  jmp 0x00007F582CDDC073
00007f582cdde049  sub rsp, 0x08
00007f582cdde04d  push rax
00007f582cdde04e  push rcx
00007f582cdde04f  push rdx
00007f582cdde050  push rdi
00007f582cdde051  push rsi
00007f582cdde052  push r8
00007f582cdde054  push r9
00007f582cdde056  push r10
00007f582cdde058  push r11
00007f582cdde05a  sub rsp, 0xF0
00007f582cdde061  vmovaps [rsp], xmm0
00007f582cdde066  vmovaps [rsp+0x10], xmm1
00007f582cdde06c  vmovaps [rsp+0x20], xmm2
00007f582cdde072  vmovaps [rsp+0x30], xmm3
00007f582cdde078  vmovaps [rsp+0x40], xmm4
00007f582cdde07e  vmovaps [rsp+0x50], xmm5
00007f582cdde084  vmovaps [rsp+0x60], xmm6
00007f582cdde08a  vmovaps [rsp+0x70], xmm7
00007f582cdde090  vmovaps [rsp+0x80], xmm8
00007f582cdde099  vmovaps [rsp+0x90], xmm9
00007f582cdde0a2  vmovaps [rsp+0xA0], xmm10
00007f582cdde0ab  vmovaps [rsp+0xB0], xmm11
00007f582cdde0b4  vmovaps [rsp+0xC0], xmm12
00007f582cdde0bd  vmovaps [rsp+0xD0], xmm13
00007f582cdde0c6  vmovaps [rsp+0xE0], xmm14
00007f582cdde0cf  sub rsp, 0x30
00007f582cdde0d3  movaps [rsp], xmm15
00007f582cdde0d8  movaps [rsp+0x10], xmm5
00007f582cdde0dd  movaps [rsp+0x20], xmm3
00007f582cdde0e2  lea rdi, [rsp]
00007f582cdde0e6  mov esi, 0x00
00007f582cdde0eb  mov rax, 0x653B0D9BF530
00007f582cdde0f5  call rax
00007f582cdde0f7  movaps xmm15, [rsp]
00007f582cdde0fc  add rsp, 0x30
00007f582cdde100  vmovaps xmm0, [rsp]
00007f582cdde105  vmovaps xmm1, [rsp+0x10]
00007f582cdde10b  vmovaps xmm2, [rsp+0x20]
00007f582cdde111  vmovaps xmm3, [rsp+0x30]
00007f582cdde117  vmovaps xmm4, [rsp+0x40]
00007f582cdde11d  vmovaps xmm5, [rsp+0x50]
00007f582cdde123  vmovaps xmm6, [rsp+0x60]
00007f582cdde129  vmovaps xmm7, [rsp+0x70]
00007f582cdde12f  vmovaps xmm8, [rsp+0x80]
00007f582cdde138  vmovaps xmm9, [rsp+0x90]
00007f582cdde141  vmovaps xmm10, [rsp+0xA0]
00007f582cdde14a  vmovaps xmm11, [rsp+0xB0]
00007f582cdde153  vmovaps xmm12, [rsp+0xC0]
00007f582cdde15c  vmovaps xmm13, [rsp+0xD0]
00007f582cdde165  vmovaps xmm14, [rsp+0xE0]
00007f582cdde16e  add rsp, 0xF0
00007f582cdde175  pop r11
00007f582cdde177  pop r10
00007f582cdde179  pop r9
00007f582cdde17b  pop r8
00007f582cdde17d  pop rsi
00007f582cdde17e  pop rdi
00007f582cdde17f  pop rdx
00007f582cdde180  pop rcx
00007f582cdde181  pop rax
00007f582cdde182  add rsp, 0x08
00007f582cdde186  jmp 0x00007F582CDDC099
00007f582cdde18b  sub rsp, 0x08
00007f582cdde18f  push rax
00007f582cdde190  push rcx
00007f582cdde191  push rdx
00007f582cdde192  push rdi
00007f582cdde193  push rsi
00007f582cdde194  push r8
00007f582cdde196  push r9
00007f582cdde198  push r10
00007f582cdde19a  push r11
00007f582cdde19c  sub rsp, 0xF0
00007f582cdde1a3  vmovaps [rsp], xmm0
00007f582cdde1a8  vmovaps [rsp+0x10], xmm2
00007f582cdde1ae  vmovaps [rsp+0x20], xmm3
00007f582cdde1b4  vmovaps [rsp+0x30], xmm4
00007f582cdde1ba  vmovaps [rsp+0x40], xmm5
00007f582cdde1c0  vmovaps [rsp+0x50], xmm6
00007f582cdde1c6  vmovaps [rsp+0x60], xmm7
00007f582cdde1cc  vmovaps [rsp+0x70], xmm8
00007f582cdde1d2  vmovaps [rsp+0x80], xmm9
00007f582cdde1db  vmovaps [rsp+0x90], xmm10
00007f582cdde1e4  vmovaps [rsp+0xA0], xmm11
00007f582cdde1ed  vmovaps [rsp+0xB0], xmm12
00007f582cdde1f6  vmovaps [rsp+0xC0], xmm13
00007f582cdde1ff  vmovaps [rsp+0xD0], xmm14
00007f582cdde208  vmovaps [rsp+0xE0], xmm15
00007f582cdde211  sub rsp, 0x30
00007f582cdde215  movaps [rsp], xmm1
00007f582cdde219  movaps [rsp+0x10], xmm5
00007f582cdde21e  movaps [rsp+0x20], xmm4
00007f582cdde223  lea rdi, [rsp]
00007f582cdde227  mov esi, 0x00
00007f582cdde22c  mov rax, 0x653B0D9BF530
00007f582cdde236  call rax
00007f582cdde238  movaps xmm1, [rsp]
00007f582cdde23c  add rsp, 0x30
00007f582cdde240  vmovaps xmm0, [rsp]
00007f582cdde245  vmovaps xmm2, [rsp+0x10]
00007f582cdde24b  vmovaps xmm3, [rsp+0x20]
00007f582cdde251  vmovaps xmm4, [rsp+0x30]
00007f582cdde257  vmovaps xmm5, [rsp+0x40]
00007f582cdde25d  vmovaps xmm6, [rsp+0x50]
00007f582cdde263  vmovaps xmm7, [rsp+0x60]
00007f582cdde269  vmovaps xmm8, [rsp+0x70]
00007f582cdde26f  vmovaps xmm9, [rsp+0x80]
00007f582cdde278  vmovaps xmm10, [rsp+0x90]
00007f582cdde281  vmovaps xmm11, [rsp+0xA0]
00007f582cdde28a  vmovaps xmm12, [rsp+0xB0]
00007f582cdde293  vmovaps xmm13, [rsp+0xC0]
00007f582cdde29c  vmovaps xmm14, [rsp+0xD0]
00007f582cdde2a5  vmovaps xmm15, [rsp+0xE0]
00007f582cdde2ae  add rsp, 0xF0
00007f582cdde2b5  pop r11
00007f582cdde2b7  pop r10
00007f582cdde2b9  pop r9
00007f582cdde2bb  pop r8
00007f582cdde2bd  pop rsi
00007f582cdde2be  pop rdi
00007f582cdde2bf  pop rdx
00007f582cdde2c0  pop rcx
00007f582cdde2c1  pop rax
00007f582cdde2c2  add rsp, 0x08
00007f582cdde2c6  jmp 0x00007F582CDDC0B9
00007f582cdde2cb  sub rsp, 0x08
00007f582cdde2cf  push rax
00007f582cdde2d0  push rcx
00007f582cdde2d1  push rdx
00007f582cdde2d2  push rdi
00007f582cdde2d3  push rsi
00007f582cdde2d4  push r8
00007f582cdde2d6  push r9
00007f582cdde2d8  push r10
00007f582cdde2da  push r11
00007f582cdde2dc  sub rsp, 0xF0
00007f582cdde2e3  vmovaps [rsp], xmm0
00007f582cdde2e8  vmovaps [rsp+0x10], xmm1
00007f582cdde2ee  vmovaps [rsp+0x20], xmm2
00007f582cdde2f4  vmovaps [rsp+0x30], xmm3
00007f582cdde2fa  vmovaps [rsp+0x40], xmm5
00007f582cdde300  vmovaps [rsp+0x50], xmm6
00007f582cdde306  vmovaps [rsp+0x60], xmm7
00007f582cdde30c  vmovaps [rsp+0x70], xmm8
00007f582cdde312  vmovaps [rsp+0x80], xmm9
00007f582cdde31b  vmovaps [rsp+0x90], xmm10
00007f582cdde324  vmovaps [rsp+0xA0], xmm11
00007f582cdde32d  vmovaps [rsp+0xB0], xmm12
00007f582cdde336  vmovaps [rsp+0xC0], xmm13
00007f582cdde33f  vmovaps [rsp+0xD0], xmm14
00007f582cdde348  vmovaps [rsp+0xE0], xmm15
00007f582cdde351  sub rsp, 0x30
00007f582cdde355  movaps [rsp], xmm4
00007f582cdde359  movaps [rsp+0x10], xmm3
00007f582cdde35e  movaps [rsp+0x20], xmm5
00007f582cdde363  lea rdi, [rsp]
00007f582cdde367  mov esi, 0x00
00007f582cdde36c  mov rax, 0x653B0D9BF530
00007f582cdde376  call rax
00007f582cdde378  movaps xmm4, [rsp]
00007f582cdde37c  add rsp, 0x30
00007f582cdde380  vmovaps xmm0, [rsp]
00007f582cdde385  vmovaps xmm1, [rsp+0x10]
00007f582cdde38b  vmovaps xmm2, [rsp+0x20]
00007f582cdde391  vmovaps xmm3, [rsp+0x30]
00007f582cdde397  vmovaps xmm5, [rsp+0x40]
00007f582cdde39d  vmovaps xmm6, [rsp+0x50]
00007f582cdde3a3  vmovaps xmm7, [rsp+0x60]
00007f582cdde3a9  vmovaps xmm8, [rsp+0x70]
00007f582cdde3af  vmovaps xmm9, [rsp+0x80]
00007f582cdde3b8  vmovaps xmm10, [rsp+0x90]
00007f582cdde3c1  vmovaps xmm11, [rsp+0xA0]
00007f582cdde3ca  vmovaps xmm12, [rsp+0xB0]
00007f582cdde3d3  vmovaps xmm13, [rsp+0xC0]
00007f582cdde3dc  vmovaps xmm14, [rsp+0xD0]
00007f582cdde3e5  vmovaps xmm15, [rsp+0xE0]
00007f582cdde3ee  add rsp, 0xF0
00007f582cdde3f5  pop r11
00007f582cdde3f7  pop r10
00007f582cdde3f9  pop r9
00007f582cdde3fb  pop r8
00007f582cdde3fd  pop rsi
00007f582cdde3fe  pop rdi
00007f582cdde3ff  pop rdx
00007f582cdde400  pop rcx
00007f582cdde401  pop rax
00007f582cdde402  add rsp, 0x08
00007f582cdde406  jmp 0x00007F582CDDC107
00007f582cdde40b  call 0x00007F582CCB52F0
00007f582cdde410  jmp 0x00007F582CDDC114
00007f582cdde415  sub rsp, 0x08
00007f582cdde419  push rax
00007f582cdde41a  push rcx
00007f582cdde41b  push rdx
00007f582cdde41c  push rdi
00007f582cdde41d  push rsi
00007f582cdde41e  push r8
00007f582cdde420  push r9
00007f582cdde422  push r10
00007f582cdde424  push r11
00007f582cdde426  sub rsp, 0xF0
00007f582cdde42d  vmovaps [rsp], xmm0
00007f582cdde432  vmovaps [rsp+0x10], xmm1
00007f582cdde438  vmovaps [rsp+0x20], xmm2
00007f582cdde43e  vmovaps [rsp+0x30], xmm3
00007f582cdde444  vmovaps [rsp+0x40], xmm4
00007f582cdde44a  vmovaps [rsp+0x50], xmm6
00007f582cdde450  vmovaps [rsp+0x60], xmm7
00007f582cdde456  vmovaps [rsp+0x70], xmm8
00007f582cdde45c  vmovaps [rsp+0x80], xmm9
00007f582cdde465  vmovaps [rsp+0x90], xmm10
00007f582cdde46e  vmovaps [rsp+0xA0], xmm11
00007f582cdde477  vmovaps [rsp+0xB0], xmm12
00007f582cdde480  vmovaps [rsp+0xC0], xmm13
00007f582cdde489  vmovaps [rsp+0xD0], xmm14
00007f582cdde492  vmovaps [rsp+0xE0], xmm15
00007f582cdde49b  sub rsp, 0x30
00007f582cdde49f  movaps [rsp], xmm5
00007f582cdde4a3  movaps [rsp+0x10], xmm6
00007f582cdde4a8  movaps [rsp+0x20], xmm3
00007f582cdde4ad  lea rdi, [rsp]
00007f582cdde4b1  mov esi, 0x00
00007f582cdde4b6  mov rax, 0x653B0D9BF530
00007f582cdde4c0  call rax
00007f582cdde4c2  movaps xmm5, [rsp]
00007f582cdde4c6  add rsp, 0x30
00007f582cdde4ca  vmovaps xmm0, [rsp]
00007f582cdde4cf  vmovaps xmm1, [rsp+0x10]
00007f582cdde4d5  vmovaps xmm2, [rsp+0x20]
00007f582cdde4db  vmovaps xmm3, [rsp+0x30]
00007f582cdde4e1  vmovaps xmm4, [rsp+0x40]
00007f582cdde4e7  vmovaps xmm6, [rsp+0x50]
00007f582cdde4ed  vmovaps xmm7, [rsp+0x60]
00007f582cdde4f3  vmovaps xmm8, [rsp+0x70]
00007f582cdde4f9  vmovaps xmm9, [rsp+0x80]
00007f582cdde502  vmovaps xmm10, [rsp+0x90]
00007f582cdde50b  vmovaps xmm11, [rsp+0xA0]
00007f582cdde514  vmovaps xmm12, [rsp+0xB0]
00007f582cdde51d  vmovaps xmm13, [rsp+0xC0]
00007f582cdde526  vmovaps xmm14, [rsp+0xD0]
00007f582cdde52f  vmovaps xmm15, [rsp+0xE0]
00007f582cdde538  add rsp, 0xF0
00007f582cdde53f  pop r11
00007f582cdde541  pop r10
00007f582cdde543  pop r9
00007f582cdde545  pop r8
00007f582cdde547  pop rsi
00007f582cdde548  pop rdi
00007f582cdde549  pop rdx
00007f582cdde54a  pop rcx
00007f582cdde54b  pop rax
00007f582cdde54c  add rsp, 0x08
00007f582cdde550  jmp 0x00007F582CDDC13A
00007f582cdde555  sub rsp, 0x08
00007f582cdde559  push rax
00007f582cdde55a  push rcx
00007f582cdde55b  push rdx
00007f582cdde55c  push rdi
00007f582cdde55d  push rsi
00007f582cdde55e  push r8
00007f582cdde560  push r9
00007f582cdde562  push r10
00007f582cdde564  push r11
00007f582cdde566  sub rsp, 0xF0
00007f582cdde56d  vmovaps [rsp], xmm0
00007f582cdde572  vmovaps [rsp+0x10], xmm1
00007f582cdde578  vmovaps [rsp+0x20], xmm2
00007f582cdde57e  vmovaps [rsp+0x30], xmm3
00007f582cdde584  vmovaps [rsp+0x40], xmm4
00007f582cdde58a  vmovaps [rsp+0x50], xmm5
00007f582cdde590  vmovaps [rsp+0x60], xmm7
00007f582cdde596  vmovaps [rsp+0x70], xmm8
00007f582cdde59c  vmovaps [rsp+0x80], xmm9
00007f582cdde5a5  vmovaps [rsp+0x90], xmm10
00007f582cdde5ae  vmovaps [rsp+0xA0], xmm11
00007f582cdde5b7  vmovaps [rsp+0xB0], xmm12
00007f582cdde5c0  vmovaps [rsp+0xC0], xmm13
00007f582cdde5c9  vmovaps [rsp+0xD0], xmm14
00007f582cdde5d2  vmovaps [rsp+0xE0], xmm15
00007f582cdde5db  sub rsp, 0x30
00007f582cdde5df  movaps [rsp], xmm6
00007f582cdde5e3  movaps [rsp+0x10], xmm9
00007f582cdde5e9  movaps [rsp+0x20], xmm1
00007f582cdde5ee  lea rdi, [rsp]
00007f582cdde5f2  mov esi, 0x00
00007f582cdde5f7  mov rax, 0x653B0D9BF530
00007f582cdde601  call rax
00007f582cdde603  movaps xmm6, [rsp]
00007f582cdde607  add rsp, 0x30
00007f582cdde60b  vmovaps xmm0, [rsp]
00007f582cdde610  vmovaps xmm1, [rsp+0x10]
00007f582cdde616  vmovaps xmm2, [rsp+0x20]
00007f582cdde61c  vmovaps xmm3, [rsp+0x30]
00007f582cdde622  vmovaps xmm4, [rsp+0x40]
00007f582cdde628  vmovaps xmm5, [rsp+0x50]
00007f582cdde62e  vmovaps xmm7, [rsp+0x60]
00007f582cdde634  vmovaps xmm8, [rsp+0x70]
00007f582cdde63a  vmovaps xmm9, [rsp+0x80]
00007f582cdde643  vmovaps xmm10, [rsp+0x90]
00007f582cdde64c  vmovaps xmm11, [rsp+0xA0]
00007f582cdde655  vmovaps xmm12, [rsp+0xB0]
00007f582cdde65e  vmovaps xmm13, [rsp+0xC0]
00007f582cdde667  vmovaps xmm14, [rsp+0xD0]
00007f582cdde670  vmovaps xmm15, [rsp+0xE0]
00007f582cdde679  add rsp, 0xF0
00007f582cdde680  pop r11
00007f582cdde682  pop r10
00007f582cdde684  pop r9
00007f582cdde686  pop r8
00007f582cdde688  pop rsi
00007f582cdde689  pop rdi
00007f582cdde68a  pop rdx
00007f582cdde68b  pop rcx
00007f582cdde68c  pop rax
00007f582cdde68d  add rsp, 0x08
00007f582cdde691  jmp 0x00007F582CDDC15E
00007f582cdde696  sub rsp, 0x08
00007f582cdde69a  push rax
00007f582cdde69b  push rcx
00007f582cdde69c  push rdx
00007f582cdde69d  push rdi
00007f582cdde69e  push rsi
00007f582cdde69f  push r8
00007f582cdde6a1  push r9
00007f582cdde6a3  push r10
00007f582cdde6a5  push r11
00007f582cdde6a7  sub rsp, 0xF0
00007f582cdde6ae  vmovaps [rsp], xmm0
00007f582cdde6b3  vmovaps [rsp+0x10], xmm1
00007f582cdde6b9  vmovaps [rsp+0x20], xmm2
00007f582cdde6bf  vmovaps [rsp+0x30], xmm3
00007f582cdde6c5  vmovaps [rsp+0x40], xmm4
00007f582cdde6cb  vmovaps [rsp+0x50], xmm5
00007f582cdde6d1  vmovaps [rsp+0x60], xmm6
00007f582cdde6d7  vmovaps [rsp+0x70], xmm7
00007f582cdde6dd  vmovaps [rsp+0x80], xmm8
00007f582cdde6e6  vmovaps [rsp+0x90], xmm10
00007f582cdde6ef  vmovaps [rsp+0xA0], xmm11
00007f582cdde6f8  vmovaps [rsp+0xB0], xmm12
00007f582cdde701  vmovaps [rsp+0xC0], xmm13
00007f582cdde70a  vmovaps [rsp+0xD0], xmm14
00007f582cdde713  vmovaps [rsp+0xE0], xmm15
00007f582cdde71c  sub rsp, 0x30
00007f582cdde720  movaps [rsp], xmm9
00007f582cdde725  movaps [rsp+0x10], xmm3
00007f582cdde72a  movaps [rsp+0x20], xmm1
00007f582cdde72f  lea rdi, [rsp]
00007f582cdde733  mov esi, 0x00
00007f582cdde738  mov rax, 0x653B0D9BF530
00007f582cdde742  call rax
00007f582cdde744  movaps xmm9, [rsp]
00007f582cdde749  add rsp, 0x30
00007f582cdde74d  vmovaps xmm0, [rsp]
00007f582cdde752  vmovaps xmm1, [rsp+0x10]
00007f582cdde758  vmovaps xmm2, [rsp+0x20]
00007f582cdde75e  vmovaps xmm3, [rsp+0x30]
00007f582cdde764  vmovaps xmm4, [rsp+0x40]
00007f582cdde76a  vmovaps xmm5, [rsp+0x50]
00007f582cdde770  vmovaps xmm6, [rsp+0x60]
00007f582cdde776  vmovaps xmm7, [rsp+0x70]
00007f582cdde77c  vmovaps xmm8, [rsp+0x80]
00007f582cdde785  vmovaps xmm10, [rsp+0x90]
00007f582cdde78e  vmovaps xmm11, [rsp+0xA0]
00007f582cdde797  vmovaps xmm12, [rsp+0xB0]
00007f582cdde7a0  vmovaps xmm13, [rsp+0xC0]
00007f582cdde7a9  vmovaps xmm14, [rsp+0xD0]
00007f582cdde7b2  vmovaps xmm15, [rsp+0xE0]
00007f582cdde7bb  add rsp, 0xF0
00007f582cdde7c2  pop r11
00007f582cdde7c4  pop r10
00007f582cdde7c6  pop r9
00007f582cdde7c8  pop r8
00007f582cdde7ca  pop rsi
00007f582cdde7cb  pop rdi
00007f582cdde7cc  pop rdx
00007f582cdde7cd  pop rcx
00007f582cdde7ce  pop rax
00007f582cdde7cf  add rsp, 0x08
00007f582cdde7d3  jmp 0x00007F582CDDC1AA
00007f582cdde7d8  call 0x00007F582CCB52F0
00007f582cdde7dd  jmp 0x00007F582CDDC1B7
00007f582cdde7e2  sub rsp, 0x08
00007f582cdde7e6  push rax
00007f582cdde7e7  push rcx
00007f582cdde7e8  push rdx
00007f582cdde7e9  push rdi
00007f582cdde7ea  push rsi
00007f582cdde7eb  push r8
00007f582cdde7ed  push r9
00007f582cdde7ef  push r10
00007f582cdde7f1  push r11
00007f582cdde7f3  sub rsp, 0xF0
00007f582cdde7fa  vmovaps [rsp], xmm0
00007f582cdde7ff  vmovaps [rsp+0x10], xmm1
00007f582cdde805  vmovaps [rsp+0x20], xmm2
00007f582cdde80b  vmovaps [rsp+0x30], xmm3
00007f582cdde811  vmovaps [rsp+0x40], xmm4
00007f582cdde817  vmovaps [rsp+0x50], xmm5
00007f582cdde81d  vmovaps [rsp+0x60], xmm6
00007f582cdde823  vmovaps [rsp+0x70], xmm7
00007f582cdde829  vmovaps [rsp+0x80], xmm8
00007f582cdde832  vmovaps [rsp+0x90], xmm9
00007f582cdde83b  vmovaps [rsp+0xA0], xmm10
00007f582cdde844  vmovaps [rsp+0xB0], xmm11
00007f582cdde84d  vmovaps [rsp+0xC0], xmm12
00007f582cdde856  vmovaps [rsp+0xD0], xmm13
00007f582cdde85f  vmovaps [rsp+0xE0], xmm14
00007f582cdde868  sub rsp, 0x30
00007f582cdde86c  movaps [rsp], xmm15
00007f582cdde871  movaps [rsp+0x10], xmm3
00007f582cdde876  movaps [rsp+0x20], xmm7
00007f582cdde87b  lea rdi, [rsp]
00007f582cdde87f  mov esi, 0x00
00007f582cdde884  mov rax, 0x653B0D9BF530
00007f582cdde88e  call rax
00007f582cdde890  movaps xmm15, [rsp]
00007f582cdde895  add rsp, 0x30
00007f582cdde899  vmovaps xmm0, [rsp]
00007f582cdde89e  vmovaps xmm1, [rsp+0x10]
00007f582cdde8a4  vmovaps xmm2, [rsp+0x20]
00007f582cdde8aa  vmovaps xmm3, [rsp+0x30]
00007f582cdde8b0  vmovaps xmm4, [rsp+0x40]
00007f582cdde8b6  vmovaps xmm5, [rsp+0x50]
00007f582cdde8bc  vmovaps xmm6, [rsp+0x60]
00007f582cdde8c2  vmovaps xmm7, [rsp+0x70]
00007f582cdde8c8  vmovaps xmm8, [rsp+0x80]
00007f582cdde8d1  vmovaps xmm9, [rsp+0x90]
00007f582cdde8da  vmovaps xmm10, [rsp+0xA0]
00007f582cdde8e3  vmovaps xmm11, [rsp+0xB0]
00007f582cdde8ec  vmovaps xmm12, [rsp+0xC0]
00007f582cdde8f5  vmovaps xmm13, [rsp+0xD0]
00007f582cdde8fe  vmovaps xmm14, [rsp+0xE0]
00007f582cdde907  add rsp, 0xF0
00007f582cdde90e  pop r11
00007f582cdde910  pop r10
00007f582cdde912  pop r9
00007f582cdde914  pop r8
00007f582cdde916  pop rsi
00007f582cdde917  pop rdi
00007f582cdde918  pop rdx
00007f582cdde919  pop rcx
00007f582cdde91a  pop rax
00007f582cdde91b  add rsp, 0x08
00007f582cdde91f  jmp 0x00007F582CDDC1E3
00007f582cdde924  sub rsp, 0x08
00007f582cdde928  push rax
00007f582cdde929  push rcx
00007f582cdde92a  push rdx
00007f582cdde92b  push rdi
00007f582cdde92c  push rsi
00007f582cdde92d  push r8
00007f582cdde92f  push r9
00007f582cdde931  push r10
00007f582cdde933  push r11
00007f582cdde935  sub rsp, 0xF0
00007f582cdde93c  vmovaps [rsp], xmm0
00007f582cdde941  vmovaps [rsp+0x10], xmm1
00007f582cdde947  vmovaps [rsp+0x20], xmm2
00007f582cdde94d  vmovaps [rsp+0x30], xmm4
00007f582cdde953  vmovaps [rsp+0x40], xmm5
00007f582cdde959  vmovaps [rsp+0x50], xmm6
00007f582cdde95f  vmovaps [rsp+0x60], xmm7
00007f582cdde965  vmovaps [rsp+0x70], xmm8
00007f582cdde96b  vmovaps [rsp+0x80], xmm9
00007f582cdde974  vmovaps [rsp+0x90], xmm10
00007f582cdde97d  vmovaps [rsp+0xA0], xmm11
00007f582cdde986  vmovaps [rsp+0xB0], xmm12
00007f582cdde98f  vmovaps [rsp+0xC0], xmm13
00007f582cdde998  vmovaps [rsp+0xD0], xmm14
00007f582cdde9a1  vmovaps [rsp+0xE0], xmm15
00007f582cdde9aa  sub rsp, 0x30
00007f582cdde9ae  movaps [rsp], xmm3
00007f582cdde9b2  movaps [rsp+0x10], xmm1
00007f582cdde9b7  movaps [rsp+0x20], xmm15
00007f582cdde9bd  lea rdi, [rsp]
00007f582cdde9c1  mov esi, 0x00
00007f582cdde9c6  mov rax, 0x653B0D9BF530
00007f582cdde9d0  call rax
00007f582cdde9d2  movaps xmm3, [rsp]
00007f582cdde9d6  add rsp, 0x30
00007f582cdde9da  vmovaps xmm0, [rsp]
00007f582cdde9df  vmovaps xmm1, [rsp+0x10]
00007f582cdde9e5  vmovaps xmm2, [rsp+0x20]
00007f582cdde9eb  vmovaps xmm4, [rsp+0x30]
00007f582cdde9f1  vmovaps xmm5, [rsp+0x40]
00007f582cdde9f7  vmovaps xmm6, [rsp+0x50]
00007f582cdde9fd  vmovaps xmm7, [rsp+0x60]
00007f582cddea03  vmovaps xmm8, [rsp+0x70]
00007f582cddea09  vmovaps xmm9, [rsp+0x80]
00007f582cddea12  vmovaps xmm10, [rsp+0x90]
00007f582cddea1b  vmovaps xmm11, [rsp+0xA0]
00007f582cddea24  vmovaps xmm12, [rsp+0xB0]
00007f582cddea2d  vmovaps xmm13, [rsp+0xC0]
00007f582cddea36  vmovaps xmm14, [rsp+0xD0]
00007f582cddea3f  vmovaps xmm15, [rsp+0xE0]
00007f582cddea48  add rsp, 0xF0
00007f582cddea4f  pop r11
00007f582cddea51  pop r10
00007f582cddea53  pop r9
00007f582cddea55  pop r8
00007f582cddea57  pop rsi
00007f582cddea58  pop rdi
00007f582cddea59  pop rdx
00007f582cddea5a  pop rcx
00007f582cddea5b  pop rax
00007f582cddea5c  add rsp, 0x08
00007f582cddea60  jmp 0x00007F582CDDC272
00007f582cddea65  call 0x00007F582CCB52F0
00007f582cddea6a  jmp 0x00007F582CDDC27C
00007f582cddea6f  sub rsp, 0x08
00007f582cddea73  push rax
00007f582cddea74  push rcx
00007f582cddea75  push rdx
00007f582cddea76  push rdi
00007f582cddea77  push rsi
00007f582cddea78  push r8
00007f582cddea7a  push r9
00007f582cddea7c  push r10
00007f582cddea7e  push r11
00007f582cddea80  sub rsp, 0xF0
00007f582cddea87  vmovaps [rsp], xmm0
00007f582cddea8c  vmovaps [rsp+0x10], xmm1
00007f582cddea92  vmovaps [rsp+0x20], xmm2
00007f582cddea98  vmovaps [rsp+0x30], xmm3
00007f582cddea9e  vmovaps [rsp+0x40], xmm4
00007f582cddeaa4  vmovaps [rsp+0x50], xmm5
00007f582cddeaaa  vmovaps [rsp+0x60], xmm6
00007f582cddeab0  vmovaps [rsp+0x70], xmm7
00007f582cddeab6  vmovaps [rsp+0x80], xmm8
00007f582cddeabf  vmovaps [rsp+0x90], xmm9
00007f582cddeac8  vmovaps [rsp+0xA0], xmm10
00007f582cddead1  vmovaps [rsp+0xB0], xmm11
00007f582cddeada  vmovaps [rsp+0xC0], xmm12
00007f582cddeae3  vmovaps [rsp+0xD0], xmm13
00007f582cddeaec  vmovaps [rsp+0xE0], xmm14
00007f582cddeaf5  sub rsp, 0x30
00007f582cddeaf9  movaps [rsp], xmm15
00007f582cddeafe  movaps [rsp+0x10], xmm14
00007f582cddeb04  movaps [rsp+0x20], xmm4
00007f582cddeb09  lea rdi, [rsp]
00007f582cddeb0d  mov esi, 0x00
00007f582cddeb12  mov rax, 0x653B0D9BF530
00007f582cddeb1c  call rax
00007f582cddeb1e  movaps xmm15, [rsp]
00007f582cddeb23  add rsp, 0x30
00007f582cddeb27  vmovaps xmm0, [rsp]
00007f582cddeb2c  vmovaps xmm1, [rsp+0x10]
00007f582cddeb32  vmovaps xmm2, [rsp+0x20]
00007f582cddeb38  vmovaps xmm3, [rsp+0x30]
00007f582cddeb3e  vmovaps xmm4, [rsp+0x40]
00007f582cddeb44  vmovaps xmm5, [rsp+0x50]
00007f582cddeb4a  vmovaps xmm6, [rsp+0x60]
00007f582cddeb50  vmovaps xmm7, [rsp+0x70]
00007f582cddeb56  vmovaps xmm8, [rsp+0x80]
00007f582cddeb5f  vmovaps xmm9, [rsp+0x90]
00007f582cddeb68  vmovaps xmm10, [rsp+0xA0]
00007f582cddeb71  vmovaps xmm11, [rsp+0xB0]
00007f582cddeb7a  vmovaps xmm12, [rsp+0xC0]
00007f582cddeb83  vmovaps xmm13, [rsp+0xD0]
00007f582cddeb8c  vmovaps xmm14, [rsp+0xE0]
00007f582cddeb95  add rsp, 0xF0
00007f582cddeb9c  pop r11
00007f582cddeb9e  pop r10
00007f582cddeba0  pop r9
00007f582cddeba2  pop r8
00007f582cddeba4  pop rsi
00007f582cddeba5  pop rdi
00007f582cddeba6  pop rdx
00007f582cddeba7  pop rcx
00007f582cddeba8  pop rax
00007f582cddeba9  add rsp, 0x08
00007f582cddebad  jmp 0x00007F582CDDC2AA
00007f582cddebb2  sub rsp, 0x08
00007f582cddebb6  push rax
00007f582cddebb7  push rcx
00007f582cddebb8  push rdx
00007f582cddebb9  push rdi
00007f582cddebba  push rsi
00007f582cddebbb  push r8
00007f582cddebbd  push r9
00007f582cddebbf  push r10
00007f582cddebc1  push r11
00007f582cddebc3  sub rsp, 0xF0
00007f582cddebca  vmovaps [rsp], xmm0
00007f582cddebcf  vmovaps [rsp+0x10], xmm1
00007f582cddebd5  vmovaps [rsp+0x20], xmm2
00007f582cddebdb  vmovaps [rsp+0x30], xmm3
00007f582cddebe1  vmovaps [rsp+0x40], xmm4
00007f582cddebe7  vmovaps [rsp+0x50], xmm5
00007f582cddebed  vmovaps [rsp+0x60], xmm6
00007f582cddebf3  vmovaps [rsp+0x70], xmm7
00007f582cddebf9  vmovaps [rsp+0x80], xmm8
00007f582cddec02  vmovaps [rsp+0x90], xmm9
00007f582cddec0b  vmovaps [rsp+0xA0], xmm10
00007f582cddec14  vmovaps [rsp+0xB0], xmm11
00007f582cddec1d  vmovaps [rsp+0xC0], xmm12
00007f582cddec26  vmovaps [rsp+0xD0], xmm13
00007f582cddec2f  vmovaps [rsp+0xE0], xmm15
00007f582cddec38  sub rsp, 0x30
00007f582cddec3c  movaps [rsp], xmm14
00007f582cddec41  movaps [rsp+0x10], xmm2
00007f582cddec46  movaps [rsp+0x20], xmm1
00007f582cddec4b  lea rdi, [rsp]
00007f582cddec4f  mov esi, 0x00
00007f582cddec54  mov rax, 0x653B0D9BF530
00007f582cddec5e  call rax
00007f582cddec60  movaps xmm14, [rsp]
00007f582cddec65  add rsp, 0x30
00007f582cddec69  vmovaps xmm0, [rsp]
00007f582cddec6e  vmovaps xmm1, [rsp+0x10]
00007f582cddec74  vmovaps xmm2, [rsp+0x20]
00007f582cddec7a  vmovaps xmm3, [rsp+0x30]
00007f582cddec80  vmovaps xmm4, [rsp+0x40]
00007f582cddec86  vmovaps xmm5, [rsp+0x50]
00007f582cddec8c  vmovaps xmm6, [rsp+0x60]
00007f582cddec92  vmovaps xmm7, [rsp+0x70]
00007f582cddec98  vmovaps xmm8, [rsp+0x80]
00007f582cddeca1  vmovaps xmm9, [rsp+0x90]
00007f582cddecaa  vmovaps xmm10, [rsp+0xA0]
00007f582cddecb3  vmovaps xmm11, [rsp+0xB0]
00007f582cddecbc  vmovaps xmm12, [rsp+0xC0]
00007f582cddecc5  vmovaps xmm13, [rsp+0xD0]
00007f582cddecce  vmovaps xmm15, [rsp+0xE0]
00007f582cddecd7  add rsp, 0xF0
00007f582cddecde  pop r11
00007f582cddece0  pop r10
00007f582cddece2  pop r9
00007f582cddece4  pop r8
00007f582cddece6  pop rsi
00007f582cddece7  pop rdi
00007f582cddece8  pop rdx
00007f582cddece9  pop rcx
00007f582cddecea  pop rax
00007f582cddeceb  add rsp, 0x08
00007f582cddecef  jmp 0x00007F582CDDC2D0
00007f582cddecf4  sub rsp, 0x08
00007f582cddecf8  push rax
00007f582cddecf9  push rcx
00007f582cddecfa  push rdx
00007f582cddecfb  push rdi
00007f582cddecfc  push rsi
00007f582cddecfd  push r8
00007f582cddecff  push r9
00007f582cdded01  push r10
00007f582cdded03  push r11
00007f582cdded05  sub rsp, 0xF0
00007f582cdded0c  vmovaps [rsp], xmm0
00007f582cdded11  vmovaps [rsp+0x10], xmm2
00007f582cdded17  vmovaps [rsp+0x20], xmm3
00007f582cdded1d  vmovaps [rsp+0x30], xmm4
00007f582cdded23  vmovaps [rsp+0x40], xmm5
00007f582cdded29  vmovaps [rsp+0x50], xmm6
00007f582cdded2f  vmovaps [rsp+0x60], xmm7
00007f582cdded35  vmovaps [rsp+0x70], xmm8
00007f582cdded3b  vmovaps [rsp+0x80], xmm9
00007f582cdded44  vmovaps [rsp+0x90], xmm10
00007f582cdded4d  vmovaps [rsp+0xA0], xmm11
00007f582cdded56  vmovaps [rsp+0xB0], xmm12
00007f582cdded5f  vmovaps [rsp+0xC0], xmm13
00007f582cdded68  vmovaps [rsp+0xD0], xmm14
00007f582cdded71  vmovaps [rsp+0xE0], xmm15
00007f582cdded7a  sub rsp, 0x30
00007f582cdded7e  movaps [rsp], xmm1
00007f582cdded82  movaps [rsp+0x10], xmm4
00007f582cdded87  movaps [rsp+0x20], xmm9
00007f582cdded8d  lea rdi, [rsp]
00007f582cdded91  mov esi, 0x00
00007f582cdded96  mov rax, 0x653B0D9BF530
00007f582cddeda0  call rax
00007f582cddeda2  movaps xmm1, [rsp]
00007f582cddeda6  add rsp, 0x30
00007f582cddedaa  vmovaps xmm0, [rsp]
00007f582cddedaf  vmovaps xmm2, [rsp+0x10]
00007f582cddedb5  vmovaps xmm3, [rsp+0x20]
00007f582cddedbb  vmovaps xmm4, [rsp+0x30]
00007f582cddedc1  vmovaps xmm5, [rsp+0x40]
00007f582cddedc7  vmovaps xmm6, [rsp+0x50]
00007f582cddedcd  vmovaps xmm7, [rsp+0x60]
00007f582cddedd3  vmovaps xmm8, [rsp+0x70]
00007f582cddedd9  vmovaps xmm9, [rsp+0x80]
00007f582cddede2  vmovaps xmm10, [rsp+0x90]
00007f582cddedeb  vmovaps xmm11, [rsp+0xA0]
00007f582cddedf4  vmovaps xmm12, [rsp+0xB0]
00007f582cddedfd  vmovaps xmm13, [rsp+0xC0]
00007f582cddee06  vmovaps xmm14, [rsp+0xD0]
00007f582cddee0f  vmovaps xmm15, [rsp+0xE0]
00007f582cddee18  add rsp, 0xF0
00007f582cddee1f  pop r11
00007f582cddee21  pop r10
00007f582cddee23  pop r9
00007f582cddee25  pop r8
00007f582cddee27  pop rsi
00007f582cddee28  pop rdi
00007f582cddee29  pop rdx
00007f582cddee2a  pop rcx
00007f582cddee2b  pop rax
00007f582cddee2c  add rsp, 0x08
00007f582cddee30  jmp 0x00007F582CDDC2EE
00007f582cddee35  sub rsp, 0x08
00007f582cddee39  push rax
00007f582cddee3a  push rcx
00007f582cddee3b  push rdx
00007f582cddee3c  push rdi
00007f582cddee3d  push rsi
00007f582cddee3e  push r8
00007f582cddee40  push r9
00007f582cddee42  push r10
00007f582cddee44  push r11
00007f582cddee46  sub rsp, 0xF0
00007f582cddee4d  vmovaps [rsp], xmm0
00007f582cddee52  vmovaps [rsp+0x10], xmm1
00007f582cddee58  vmovaps [rsp+0x20], xmm2
00007f582cddee5e  vmovaps [rsp+0x30], xmm3
00007f582cddee64  vmovaps [rsp+0x40], xmm5
00007f582cddee6a  vmovaps [rsp+0x50], xmm6
00007f582cddee70  vmovaps [rsp+0x60], xmm7
00007f582cddee76  vmovaps [rsp+0x70], xmm8
00007f582cddee7c  vmovaps [rsp+0x80], xmm9
00007f582cddee85  vmovaps [rsp+0x90], xmm10
00007f582cddee8e  vmovaps [rsp+0xA0], xmm11
00007f582cddee97  vmovaps [rsp+0xB0], xmm12
00007f582cddeea0  vmovaps [rsp+0xC0], xmm13
00007f582cddeea9  vmovaps [rsp+0xD0], xmm14
00007f582cddeeb2  vmovaps [rsp+0xE0], xmm15
00007f582cddeebb  sub rsp, 0x30
00007f582cddeebf  movaps [rsp], xmm4
00007f582cddeec3  movaps [rsp+0x10], xmm2
00007f582cddeec8  movaps [rsp+0x20], xmm9
00007f582cddeece  lea rdi, [rsp]
00007f582cddeed2  mov esi, 0x00
00007f582cddeed7  mov rax, 0x653B0D9BF530
00007f582cddeee1  call rax
00007f582cddeee3  movaps xmm4, [rsp]
00007f582cddeee7  add rsp, 0x30
00007f582cddeeeb  vmovaps xmm0, [rsp]
00007f582cddeef0  vmovaps xmm1, [rsp+0x10]
00007f582cddeef6  vmovaps xmm2, [rsp+0x20]
00007f582cddeefc  vmovaps xmm3, [rsp+0x30]
00007f582cddef02  vmovaps xmm5, [rsp+0x40]
00007f582cddef08  vmovaps xmm6, [rsp+0x50]
00007f582cddef0e  vmovaps xmm7, [rsp+0x60]
00007f582cddef14  vmovaps xmm8, [rsp+0x70]
00007f582cddef1a  vmovaps xmm9, [rsp+0x80]
00007f582cddef23  vmovaps xmm10, [rsp+0x90]
00007f582cddef2c  vmovaps xmm11, [rsp+0xA0]
00007f582cddef35  vmovaps xmm12, [rsp+0xB0]
00007f582cddef3e  vmovaps xmm13, [rsp+0xC0]
00007f582cddef47  vmovaps xmm14, [rsp+0xD0]
00007f582cddef50  vmovaps xmm15, [rsp+0xE0]
00007f582cddef59  add rsp, 0xF0
00007f582cddef60  pop r11
00007f582cddef62  pop r10
00007f582cddef64  pop r9
00007f582cddef66  pop r8
00007f582cddef68  pop rsi
00007f582cddef69  pop rdi
00007f582cddef6a  pop rdx
00007f582cddef6b  pop rcx
00007f582cddef6c  pop rax
00007f582cddef6d  add rsp, 0x08
00007f582cddef71  jmp 0x00007F582CDDC31E
00007f582cddef76  sub rsp, 0x08
00007f582cddef7a  push rax
00007f582cddef7b  push rcx
00007f582cddef7c  push rdx
00007f582cddef7d  push rdi
00007f582cddef7e  push rsi
00007f582cddef7f  push r8
00007f582cddef81  push r9
00007f582cddef83  push r10
00007f582cddef85  push r11
00007f582cddef87  sub rsp, 0xF0
00007f582cddef8e  vmovaps [rsp], xmm0
00007f582cddef93  vmovaps [rsp+0x10], xmm1
00007f582cddef99  vmovaps [rsp+0x20], xmm2
00007f582cddef9f  vmovaps [rsp+0x30], xmm3
00007f582cddefa5  vmovaps [rsp+0x40], xmm4
00007f582cddefab  vmovaps [rsp+0x50], xmm5
00007f582cddefb1  vmovaps [rsp+0x60], xmm6
00007f582cddefb7  vmovaps [rsp+0x70], xmm7
00007f582cddefbd  vmovaps [rsp+0x80], xmm8
00007f582cddefc6  vmovaps [rsp+0x90], xmm10
00007f582cddefcf  vmovaps [rsp+0xA0], xmm11
00007f582cddefd8  vmovaps [rsp+0xB0], xmm12
00007f582cddefe1  vmovaps [rsp+0xC0], xmm13
00007f582cddefea  vmovaps [rsp+0xD0], xmm14
00007f582cddeff3  vmovaps [rsp+0xE0], xmm15
00007f582cddeffc  sub rsp, 0x30
00007f582cddf000  movaps [rsp], xmm9
00007f582cddf005  movaps [rsp+0x10], xmm2
00007f582cddf00a  movaps [rsp+0x20], xmm1
00007f582cddf00f  lea rdi, [rsp]
00007f582cddf013  mov esi, 0x00
00007f582cddf018  mov rax, 0x653B0D9BF530
00007f582cddf022  call rax
00007f582cddf024  movaps xmm9, [rsp]
00007f582cddf029  add rsp, 0x30
00007f582cddf02d  vmovaps xmm0, [rsp]
00007f582cddf032  vmovaps xmm1, [rsp+0x10]
00007f582cddf038  vmovaps xmm2, [rsp+0x20]
00007f582cddf03e  vmovaps xmm3, [rsp+0x30]
00007f582cddf044  vmovaps xmm4, [rsp+0x40]
00007f582cddf04a  vmovaps xmm5, [rsp+0x50]
00007f582cddf050  vmovaps xmm6, [rsp+0x60]
00007f582cddf056  vmovaps xmm7, [rsp+0x70]
00007f582cddf05c  vmovaps xmm8, [rsp+0x80]
00007f582cddf065  vmovaps xmm10, [rsp+0x90]
00007f582cddf06e  vmovaps xmm11, [rsp+0xA0]
00007f582cddf077  vmovaps xmm12, [rsp+0xB0]
00007f582cddf080  vmovaps xmm13, [rsp+0xC0]
00007f582cddf089  vmovaps xmm14, [rsp+0xD0]
00007f582cddf092  vmovaps xmm15, [rsp+0xE0]
00007f582cddf09b  add rsp, 0xF0
00007f582cddf0a2  pop r11
00007f582cddf0a4  pop r10
00007f582cddf0a6  pop r9
00007f582cddf0a8  pop r8
00007f582cddf0aa  pop rsi
00007f582cddf0ab  pop rdi
00007f582cddf0ac  pop rdx
00007f582cddf0ad  pop rcx
00007f582cddf0ae  pop rax
00007f582cddf0af  add rsp, 0x08
00007f582cddf0b3  jmp 0x00007F582CDDC354
00007f582cddf0b8  sub rsp, 0x08
00007f582cddf0bc  push rax
00007f582cddf0bd  push rcx
00007f582cddf0be  push rdx
00007f582cddf0bf  push rdi
00007f582cddf0c0  push rsi
00007f582cddf0c1  push r8
00007f582cddf0c3  push r9
00007f582cddf0c5  push r10
00007f582cddf0c7  push r11
00007f582cddf0c9  sub rsp, 0xF0
00007f582cddf0d0  vmovaps [rsp], xmm0
00007f582cddf0d5  vmovaps [rsp+0x10], xmm2
00007f582cddf0db  vmovaps [rsp+0x20], xmm3
00007f582cddf0e1  vmovaps [rsp+0x30], xmm4
00007f582cddf0e7  vmovaps [rsp+0x40], xmm5
00007f582cddf0ed  vmovaps [rsp+0x50], xmm6
00007f582cddf0f3  vmovaps [rsp+0x60], xmm7
00007f582cddf0f9  vmovaps [rsp+0x70], xmm8
00007f582cddf0ff  vmovaps [rsp+0x80], xmm9
00007f582cddf108  vmovaps [rsp+0x90], xmm10
00007f582cddf111  vmovaps [rsp+0xA0], xmm11
00007f582cddf11a  vmovaps [rsp+0xB0], xmm12
00007f582cddf123  vmovaps [rsp+0xC0], xmm13
00007f582cddf12c  vmovaps [rsp+0xD0], xmm14
00007f582cddf135  vmovaps [rsp+0xE0], xmm15
00007f582cddf13e  sub rsp, 0x30
00007f582cddf142  movaps [rsp], xmm1
00007f582cddf146  movaps [rsp+0x10], xmm15
00007f582cddf14c  movaps [rsp+0x20], xmm6
00007f582cddf151  lea rdi, [rsp]
00007f582cddf155  mov esi, 0x00
00007f582cddf15a  mov rax, 0x653B0D9BF530
00007f582cddf164  call rax
00007f582cddf166  movaps xmm1, [rsp]
00007f582cddf16a  add rsp, 0x30
00007f582cddf16e  vmovaps xmm0, [rsp]
00007f582cddf173  vmovaps xmm2, [rsp+0x10]
00007f582cddf179  vmovaps xmm3, [rsp+0x20]
00007f582cddf17f  vmovaps xmm4, [rsp+0x30]
00007f582cddf185  vmovaps xmm5, [rsp+0x40]
00007f582cddf18b  vmovaps xmm6, [rsp+0x50]
00007f582cddf191  vmovaps xmm7, [rsp+0x60]
00007f582cddf197  vmovaps xmm8, [rsp+0x70]
00007f582cddf19d  vmovaps xmm9, [rsp+0x80]
00007f582cddf1a6  vmovaps xmm10, [rsp+0x90]
00007f582cddf1af  vmovaps xmm11, [rsp+0xA0]
00007f582cddf1b8  vmovaps xmm12, [rsp+0xB0]
00007f582cddf1c1  vmovaps xmm13, [rsp+0xC0]
00007f582cddf1ca  vmovaps xmm14, [rsp+0xD0]
00007f582cddf1d3  vmovaps xmm15, [rsp+0xE0]
00007f582cddf1dc  add rsp, 0xF0
00007f582cddf1e3  pop r11
00007f582cddf1e5  pop r10
00007f582cddf1e7  pop r9
00007f582cddf1e9  pop r8
00007f582cddf1eb  pop rsi
00007f582cddf1ec  pop rdi
00007f582cddf1ed  pop rdx
00007f582cddf1ee  pop rcx
00007f582cddf1ef  pop rax
00007f582cddf1f0  add rsp, 0x08
00007f582cddf1f4  jmp 0x00007F582CDDC375
00007f582cddf1f9  sub rsp, 0x08
00007f582cddf1fd  push rax
00007f582cddf1fe  push rcx
00007f582cddf1ff  push rdx
00007f582cddf200  push rdi
00007f582cddf201  push rsi
00007f582cddf202  push r8
00007f582cddf204  push r9
00007f582cddf206  push r10
00007f582cddf208  push r11
00007f582cddf20a  sub rsp, 0xF0
00007f582cddf211  vmovaps [rsp], xmm0
00007f582cddf216  vmovaps [rsp+0x10], xmm1
00007f582cddf21c  vmovaps [rsp+0x20], xmm2
00007f582cddf222  vmovaps [rsp+0x30], xmm3
00007f582cddf228  vmovaps [rsp+0x40], xmm4
00007f582cddf22e  vmovaps [rsp+0x50], xmm5
00007f582cddf234  vmovaps [rsp+0x60], xmm6
00007f582cddf23a  vmovaps [rsp+0x70], xmm7
00007f582cddf240  vmovaps [rsp+0x80], xmm8
00007f582cddf249  vmovaps [rsp+0x90], xmm9
00007f582cddf252  vmovaps [rsp+0xA0], xmm10
00007f582cddf25b  vmovaps [rsp+0xB0], xmm11
00007f582cddf264  vmovaps [rsp+0xC0], xmm12
00007f582cddf26d  vmovaps [rsp+0xD0], xmm13
00007f582cddf276  vmovaps [rsp+0xE0], xmm14
00007f582cddf27f  sub rsp, 0x30
00007f582cddf283  movaps [rsp], xmm15
00007f582cddf288  movaps [rsp+0x10], xmm5
00007f582cddf28d  movaps [rsp+0x20], xmm3
00007f582cddf292  lea rdi, [rsp]
00007f582cddf296  mov esi, 0x00
00007f582cddf29b  mov rax, 0x653B0D9BF530
00007f582cddf2a5  call rax
00007f582cddf2a7  movaps xmm15, [rsp]
00007f582cddf2ac  add rsp, 0x30
00007f582cddf2b0  vmovaps xmm0, [rsp]
00007f582cddf2b5  vmovaps xmm1, [rsp+0x10]
00007f582cddf2bb  vmovaps xmm2, [rsp+0x20]
00007f582cddf2c1  vmovaps xmm3, [rsp+0x30]
00007f582cddf2c7  vmovaps xmm4, [rsp+0x40]
00007f582cddf2cd  vmovaps xmm5, [rsp+0x50]
00007f582cddf2d3  vmovaps xmm6, [rsp+0x60]
00007f582cddf2d9  vmovaps xmm7, [rsp+0x70]
00007f582cddf2df  vmovaps xmm8, [rsp+0x80]
00007f582cddf2e8  vmovaps xmm9, [rsp+0x90]
00007f582cddf2f1  vmovaps xmm10, [rsp+0xA0]
00007f582cddf2fa  vmovaps xmm11, [rsp+0xB0]
00007f582cddf303  vmovaps xmm12, [rsp+0xC0]
00007f582cddf30c  vmovaps xmm13, [rsp+0xD0]
00007f582cddf315  vmovaps xmm14, [rsp+0xE0]
00007f582cddf31e  add rsp, 0xF0
00007f582cddf325  pop r11
00007f582cddf327  pop r10
00007f582cddf329  pop r9
00007f582cddf32b  pop r8
00007f582cddf32d  pop rsi
00007f582cddf32e  pop rdi
00007f582cddf32f  pop rdx
00007f582cddf330  pop rcx
00007f582cddf331  pop rax
00007f582cddf332  add rsp, 0x08
00007f582cddf336  jmp 0x00007F582CDDC38F
00007f582cddf33b  sub rsp, 0x08
00007f582cddf33f  push rax
00007f582cddf340  push rcx
00007f582cddf341  push rdx
00007f582cddf342  push rdi
00007f582cddf343  push rsi
00007f582cddf344  push r8
00007f582cddf346  push r9
00007f582cddf348  push r10
00007f582cddf34a  push r11
00007f582cddf34c  sub rsp, 0xF0
00007f582cddf353  vmovaps [rsp], xmm0
00007f582cddf358  vmovaps [rsp+0x10], xmm1
00007f582cddf35e  vmovaps [rsp+0x20], xmm2
00007f582cddf364  vmovaps [rsp+0x30], xmm3
00007f582cddf36a  vmovaps [rsp+0x40], xmm4
00007f582cddf370  vmovaps [rsp+0x50], xmm6
00007f582cddf376  vmovaps [rsp+0x60], xmm7
00007f582cddf37c  vmovaps [rsp+0x70], xmm8
00007f582cddf382  vmovaps [rsp+0x80], xmm9
00007f582cddf38b  vmovaps [rsp+0x90], xmm10
00007f582cddf394  vmovaps [rsp+0xA0], xmm11
00007f582cddf39d  vmovaps [rsp+0xB0], xmm12
00007f582cddf3a6  vmovaps [rsp+0xC0], xmm13
00007f582cddf3af  vmovaps [rsp+0xD0], xmm14
00007f582cddf3b8  vmovaps [rsp+0xE0], xmm15
00007f582cddf3c1  sub rsp, 0x30
00007f582cddf3c5  movaps [rsp], xmm5
00007f582cddf3c9  movaps [rsp+0x10], xmm8
00007f582cddf3cf  movaps [rsp+0x20], xmm6
00007f582cddf3d4  lea rdi, [rsp]
00007f582cddf3d8  mov esi, 0x00
00007f582cddf3dd  mov rax, 0x653B0D9BF530
00007f582cddf3e7  call rax
00007f582cddf3e9  movaps xmm5, [rsp]
00007f582cddf3ed  add rsp, 0x30
00007f582cddf3f1  vmovaps xmm0, [rsp]
00007f582cddf3f6  vmovaps xmm1, [rsp+0x10]
00007f582cddf3fc  vmovaps xmm2, [rsp+0x20]
00007f582cddf402  vmovaps xmm3, [rsp+0x30]
00007f582cddf408  vmovaps xmm4, [rsp+0x40]
00007f582cddf40e  vmovaps xmm6, [rsp+0x50]
00007f582cddf414  vmovaps xmm7, [rsp+0x60]
00007f582cddf41a  vmovaps xmm8, [rsp+0x70]
00007f582cddf420  vmovaps xmm9, [rsp+0x80]
00007f582cddf429  vmovaps xmm10, [rsp+0x90]
00007f582cddf432  vmovaps xmm11, [rsp+0xA0]
00007f582cddf43b  vmovaps xmm12, [rsp+0xB0]
00007f582cddf444  vmovaps xmm13, [rsp+0xC0]
00007f582cddf44d  vmovaps xmm14, [rsp+0xD0]
00007f582cddf456  vmovaps xmm15, [rsp+0xE0]
00007f582cddf45f  add rsp, 0xF0
00007f582cddf466  pop r11
00007f582cddf468  pop r10
00007f582cddf46a  pop r9
00007f582cddf46c  pop r8
00007f582cddf46e  pop rsi
00007f582cddf46f  pop rdi
00007f582cddf470  pop rdx
00007f582cddf471  pop rcx
00007f582cddf472  pop rax
00007f582cddf473  add rsp, 0x08
00007f582cddf477  jmp 0x00007F582CDDC3B3
00007f582cddf47c  sub rsp, 0x08
00007f582cddf480  push rax
00007f582cddf481  push rcx
00007f582cddf482  push rdx
00007f582cddf483  push rdi
00007f582cddf484  push rsi
00007f582cddf485  push r8
00007f582cddf487  push r9
00007f582cddf489  push r10
00007f582cddf48b  push r11
00007f582cddf48d  sub rsp, 0xF0
00007f582cddf494  vmovaps [rsp], xmm0
00007f582cddf499  vmovaps [rsp+0x10], xmm1
00007f582cddf49f  vmovaps [rsp+0x20], xmm2
00007f582cddf4a5  vmovaps [rsp+0x30], xmm3
00007f582cddf4ab  vmovaps [rsp+0x40], xmm4
00007f582cddf4b1  vmovaps [rsp+0x50], xmm5
00007f582cddf4b7  vmovaps [rsp+0x60], xmm7
00007f582cddf4bd  vmovaps [rsp+0x70], xmm8
00007f582cddf4c3  vmovaps [rsp+0x80], xmm9
00007f582cddf4cc  vmovaps [rsp+0x90], xmm10
00007f582cddf4d5  vmovaps [rsp+0xA0], xmm11
00007f582cddf4de  vmovaps [rsp+0xB0], xmm12
00007f582cddf4e7  vmovaps [rsp+0xC0], xmm13
00007f582cddf4f0  vmovaps [rsp+0xD0], xmm14
00007f582cddf4f9  vmovaps [rsp+0xE0], xmm15
00007f582cddf502  sub rsp, 0x30
00007f582cddf506  movaps [rsp], xmm6
00007f582cddf50a  movaps [rsp+0x10], xmm10
00007f582cddf510  movaps [rsp+0x20], xmm8
00007f582cddf516  lea rdi, [rsp]
00007f582cddf51a  mov esi, 0x00
00007f582cddf51f  mov rax, 0x653B0D9BF530
00007f582cddf529  call rax
00007f582cddf52b  movaps xmm6, [rsp]
00007f582cddf52f  add rsp, 0x30
00007f582cddf533  vmovaps xmm0, [rsp]
00007f582cddf538  vmovaps xmm1, [rsp+0x10]
00007f582cddf53e  vmovaps xmm2, [rsp+0x20]
00007f582cddf544  vmovaps xmm3, [rsp+0x30]
00007f582cddf54a  vmovaps xmm4, [rsp+0x40]
00007f582cddf550  vmovaps xmm5, [rsp+0x50]
00007f582cddf556  vmovaps xmm7, [rsp+0x60]
00007f582cddf55c  vmovaps xmm8, [rsp+0x70]
00007f582cddf562  vmovaps xmm9, [rsp+0x80]
00007f582cddf56b  vmovaps xmm10, [rsp+0x90]
00007f582cddf574  vmovaps xmm11, [rsp+0xA0]
00007f582cddf57d  vmovaps xmm12, [rsp+0xB0]
00007f582cddf586  vmovaps xmm13, [rsp+0xC0]
00007f582cddf58f  vmovaps xmm14, [rsp+0xD0]
00007f582cddf598  vmovaps xmm15, [rsp+0xE0]
00007f582cddf5a1  add rsp, 0xF0
00007f582cddf5a8  pop r11
00007f582cddf5aa  pop r10
00007f582cddf5ac  pop r9
00007f582cddf5ae  pop r8
00007f582cddf5b0  pop rsi
00007f582cddf5b1  pop rdi
00007f582cddf5b2  pop rdx
00007f582cddf5b3  pop rcx
00007f582cddf5b4  pop rax
00007f582cddf5b5  add rsp, 0x08
00007f582cddf5b9  jmp 0x00007F582CDDC3D8
00007f582cddf5be  sub rsp, 0x08
00007f582cddf5c2  push rax
00007f582cddf5c3  push rcx
00007f582cddf5c4  push rdx
00007f582cddf5c5  push rdi
00007f582cddf5c6  push rsi
00007f582cddf5c7  push r8
00007f582cddf5c9  push r9
00007f582cddf5cb  push r10
00007f582cddf5cd  push r11
00007f582cddf5cf  sub rsp, 0xF0
00007f582cddf5d6  vmovaps [rsp], xmm0
00007f582cddf5db  vmovaps [rsp+0x10], xmm1
00007f582cddf5e1  vmovaps [rsp+0x20], xmm2
00007f582cddf5e7  vmovaps [rsp+0x30], xmm3
00007f582cddf5ed  vmovaps [rsp+0x40], xmm4
00007f582cddf5f3  vmovaps [rsp+0x50], xmm5
00007f582cddf5f9  vmovaps [rsp+0x60], xmm6
00007f582cddf5ff  vmovaps [rsp+0x70], xmm7
00007f582cddf605  vmovaps [rsp+0x80], xmm8
00007f582cddf60e  vmovaps [rsp+0x90], xmm9
00007f582cddf617  vmovaps [rsp+0xA0], xmm11
00007f582cddf620  vmovaps [rsp+0xB0], xmm12
00007f582cddf629  vmovaps [rsp+0xC0], xmm13
00007f582cddf632  vmovaps [rsp+0xD0], xmm14
00007f582cddf63b  vmovaps [rsp+0xE0], xmm15
00007f582cddf644  sub rsp, 0x30
00007f582cddf648  movaps [rsp], xmm10
00007f582cddf64d  movaps [rsp+0x10], xmm8
00007f582cddf653  movaps [rsp+0x20], xmm14
00007f582cddf659  lea rdi, [rsp]
00007f582cddf65d  mov esi, 0x00
00007f582cddf662  mov rax, 0x653B0D9BF530
00007f582cddf66c  call rax
00007f582cddf66e  movaps xmm10, [rsp]
00007f582cddf673  add rsp, 0x30
00007f582cddf677  vmovaps xmm0, [rsp]
00007f582cddf67c  vmovaps xmm1, [rsp+0x10]
00007f582cddf682  vmovaps xmm2, [rsp+0x20]
00007f582cddf688  vmovaps xmm3, [rsp+0x30]
00007f582cddf68e  vmovaps xmm4, [rsp+0x40]
00007f582cddf694  vmovaps xmm5, [rsp+0x50]
00007f582cddf69a  vmovaps xmm6, [rsp+0x60]
00007f582cddf6a0  vmovaps xmm7, [rsp+0x70]
00007f582cddf6a6  vmovaps xmm8, [rsp+0x80]
00007f582cddf6af  vmovaps xmm9, [rsp+0x90]
00007f582cddf6b8  vmovaps xmm11, [rsp+0xA0]
00007f582cddf6c1  vmovaps xmm12, [rsp+0xB0]
00007f582cddf6ca  vmovaps xmm13, [rsp+0xC0]
00007f582cddf6d3  vmovaps xmm14, [rsp+0xD0]
00007f582cddf6dc  vmovaps xmm15, [rsp+0xE0]
00007f582cddf6e5  add rsp, 0xF0
00007f582cddf6ec  pop r11
00007f582cddf6ee  pop r10
00007f582cddf6f0  pop r9
00007f582cddf6f2  pop r8
00007f582cddf6f4  pop rsi
00007f582cddf6f5  pop rdi
00007f582cddf6f6  pop rdx
00007f582cddf6f7  pop rcx
00007f582cddf6f8  pop rax
00007f582cddf6f9  add rsp, 0x08
00007f582cddf6fd  jmp 0x00007F582CDDC3F8
00007f582cddf702  sub rsp, 0x08
00007f582cddf706  push rax
00007f582cddf707  push rcx
00007f582cddf708  push rdx
00007f582cddf709  push rdi
00007f582cddf70a  push rsi
00007f582cddf70b  push r8
00007f582cddf70d  push r9
00007f582cddf70f  push r10
00007f582cddf711  push r11
00007f582cddf713  sub rsp, 0xF0
00007f582cddf71a  vmovaps [rsp], xmm0
00007f582cddf71f  vmovaps [rsp+0x10], xmm1
00007f582cddf725  vmovaps [rsp+0x20], xmm2
00007f582cddf72b  vmovaps [rsp+0x30], xmm3
00007f582cddf731  vmovaps [rsp+0x40], xmm4
00007f582cddf737  vmovaps [rsp+0x50], xmm5
00007f582cddf73d  vmovaps [rsp+0x60], xmm6
00007f582cddf743  vmovaps [rsp+0x70], xmm7
00007f582cddf749  vmovaps [rsp+0x80], xmm8
00007f582cddf752  vmovaps [rsp+0x90], xmm9
00007f582cddf75b  vmovaps [rsp+0xA0], xmm10
00007f582cddf764  vmovaps [rsp+0xB0], xmm11
00007f582cddf76d  vmovaps [rsp+0xC0], xmm12
00007f582cddf776  vmovaps [rsp+0xD0], xmm13
00007f582cddf77f  vmovaps [rsp+0xE0], xmm15
00007f582cddf788  sub rsp, 0x30
00007f582cddf78c  movaps [rsp], xmm14
00007f582cddf791  movaps [rsp+0x10], xmm8
00007f582cddf797  movaps [rsp+0x20], xmm4
00007f582cddf79c  lea rdi, [rsp]
00007f582cddf7a0  mov esi, 0x00
00007f582cddf7a5  mov rax, 0x653B0D9BF530
00007f582cddf7af  call rax
00007f582cddf7b1  movaps xmm14, [rsp]
00007f582cddf7b6  add rsp, 0x30
00007f582cddf7ba  vmovaps xmm0, [rsp]
00007f582cddf7bf  vmovaps xmm1, [rsp+0x10]
00007f582cddf7c5  vmovaps xmm2, [rsp+0x20]
00007f582cddf7cb  vmovaps xmm3, [rsp+0x30]
00007f582cddf7d1  vmovaps xmm4, [rsp+0x40]
00007f582cddf7d7  vmovaps xmm5, [rsp+0x50]
00007f582cddf7dd  vmovaps xmm6, [rsp+0x60]
00007f582cddf7e3  vmovaps xmm7, [rsp+0x70]
00007f582cddf7e9  vmovaps xmm8, [rsp+0x80]
00007f582cddf7f2  vmovaps xmm9, [rsp+0x90]
00007f582cddf7fb  vmovaps xmm10, [rsp+0xA0]
00007f582cddf804  vmovaps xmm11, [rsp+0xB0]
00007f582cddf80d  vmovaps xmm12, [rsp+0xC0]
00007f582cddf816  vmovaps xmm13, [rsp+0xD0]
00007f582cddf81f  vmovaps xmm15, [rsp+0xE0]
00007f582cddf828  add rsp, 0xF0
00007f582cddf82f  pop r11
00007f582cddf831  pop r10
00007f582cddf833  pop r9
00007f582cddf835  pop r8
00007f582cddf837  pop rsi
00007f582cddf838  pop rdi
00007f582cddf839  pop rdx
00007f582cddf83a  pop rcx
00007f582cddf83b  pop rax
00007f582cddf83c  add rsp, 0x08
00007f582cddf840  jmp 0x00007F582CDDC418
00007f582cddf845  sub rsp, 0x08
00007f582cddf849  push rax
00007f582cddf84a  push rcx
00007f582cddf84b  push rdx
00007f582cddf84c  push rdi
00007f582cddf84d  push rsi
00007f582cddf84e  push r8
00007f582cddf850  push r9
00007f582cddf852  push r10
00007f582cddf854  push r11
00007f582cddf856  sub rsp, 0xF0
00007f582cddf85d  vmovaps [rsp], xmm0
00007f582cddf862  vmovaps [rsp+0x10], xmm1
00007f582cddf868  vmovaps [rsp+0x20], xmm2
00007f582cddf86e  vmovaps [rsp+0x30], xmm3
00007f582cddf874  vmovaps [rsp+0x40], xmm5
00007f582cddf87a  vmovaps [rsp+0x50], xmm6
00007f582cddf880  vmovaps [rsp+0x60], xmm7
00007f582cddf886  vmovaps [rsp+0x70], xmm8
00007f582cddf88c  vmovaps [rsp+0x80], xmm9
00007f582cddf895  vmovaps [rsp+0x90], xmm10
00007f582cddf89e  vmovaps [rsp+0xA0], xmm11
00007f582cddf8a7  vmovaps [rsp+0xB0], xmm12
00007f582cddf8b0  vmovaps [rsp+0xC0], xmm13
00007f582cddf8b9  vmovaps [rsp+0xD0], xmm14
00007f582cddf8c2  vmovaps [rsp+0xE0], xmm15
00007f582cddf8cb  sub rsp, 0x30
00007f582cddf8cf  movaps [rsp], xmm4
00007f582cddf8d3  movaps [rsp+0x10], xmm13
00007f582cddf8d9  movaps [rsp+0x20], xmm8
00007f582cddf8df  lea rdi, [rsp]
00007f582cddf8e3  mov esi, 0x00
00007f582cddf8e8  mov rax, 0x653B0D9BF530
00007f582cddf8f2  call rax
00007f582cddf8f4  movaps xmm4, [rsp]
00007f582cddf8f8  add rsp, 0x30
00007f582cddf8fc  vmovaps xmm0, [rsp]
00007f582cddf901  vmovaps xmm1, [rsp+0x10]
00007f582cddf907  vmovaps xmm2, [rsp+0x20]
00007f582cddf90d  vmovaps xmm3, [rsp+0x30]
00007f582cddf913  vmovaps xmm5, [rsp+0x40]
00007f582cddf919  vmovaps xmm6, [rsp+0x50]
00007f582cddf91f  vmovaps xmm7, [rsp+0x60]
00007f582cddf925  vmovaps xmm8, [rsp+0x70]
00007f582cddf92b  vmovaps xmm9, [rsp+0x80]
00007f582cddf934  vmovaps xmm10, [rsp+0x90]
00007f582cddf93d  vmovaps xmm11, [rsp+0xA0]
00007f582cddf946  vmovaps xmm12, [rsp+0xB0]
00007f582cddf94f  vmovaps xmm13, [rsp+0xC0]
00007f582cddf958  vmovaps xmm14, [rsp+0xD0]
00007f582cddf961  vmovaps xmm15, [rsp+0xE0]
00007f582cddf96a  add rsp, 0xF0
00007f582cddf971  pop r11
00007f582cddf973  pop r10
00007f582cddf975  pop r9
00007f582cddf977  pop r8
00007f582cddf979  pop rsi
00007f582cddf97a  pop rdi
00007f582cddf97b  pop rdx
00007f582cddf97c  pop rcx
00007f582cddf97d  pop rax
00007f582cddf97e  add rsp, 0x08
00007f582cddf982  jmp 0x00007F582CDDC43D
00007f582cddf987  sub rsp, 0x08
00007f582cddf98b  push rax
00007f582cddf98c  push rcx
00007f582cddf98d  push rdx
00007f582cddf98e  push rdi
00007f582cddf98f  push rsi
00007f582cddf990  push r8
00007f582cddf992  push r9
00007f582cddf994  push r10
00007f582cddf996  push r11
00007f582cddf998  sub rsp, 0xF0
00007f582cddf99f  vmovaps [rsp], xmm0
00007f582cddf9a4  vmovaps [rsp+0x10], xmm1
00007f582cddf9aa  vmovaps [rsp+0x20], xmm2
00007f582cddf9b0  vmovaps [rsp+0x30], xmm3
00007f582cddf9b6  vmovaps [rsp+0x40], xmm4
00007f582cddf9bc  vmovaps [rsp+0x50], xmm5
00007f582cddf9c2  vmovaps [rsp+0x60], xmm6
00007f582cddf9c8  vmovaps [rsp+0x70], xmm7
00007f582cddf9ce  vmovaps [rsp+0x80], xmm8
00007f582cddf9d7  vmovaps [rsp+0x90], xmm9
00007f582cddf9e0  vmovaps [rsp+0xA0], xmm10
00007f582cddf9e9  vmovaps [rsp+0xB0], xmm11
00007f582cddf9f2  vmovaps [rsp+0xC0], xmm12
00007f582cddf9fb  vmovaps [rsp+0xD0], xmm14
00007f582cddfa04  vmovaps [rsp+0xE0], xmm15
00007f582cddfa0d  sub rsp, 0x30
00007f582cddfa11  movaps [rsp], xmm13
00007f582cddfa16  movaps [rsp+0x10], xmm15
00007f582cddfa1c  movaps [rsp+0x20], xmm9
00007f582cddfa22  lea rdi, [rsp]
00007f582cddfa26  mov esi, 0x00
00007f582cddfa2b  mov rax, 0x653B0D9BF530
00007f582cddfa35  call rax
00007f582cddfa37  movaps xmm13, [rsp]
00007f582cddfa3c  add rsp, 0x30
00007f582cddfa40  vmovaps xmm0, [rsp]
00007f582cddfa45  vmovaps xmm1, [rsp+0x10]
00007f582cddfa4b  vmovaps xmm2, [rsp+0x20]
00007f582cddfa51  vmovaps xmm3, [rsp+0x30]
00007f582cddfa57  vmovaps xmm4, [rsp+0x40]
00007f582cddfa5d  vmovaps xmm5, [rsp+0x50]
00007f582cddfa63  vmovaps xmm6, [rsp+0x60]
00007f582cddfa69  vmovaps xmm7, [rsp+0x70]
00007f582cddfa6f  vmovaps xmm8, [rsp+0x80]
00007f582cddfa78  vmovaps xmm9, [rsp+0x90]
00007f582cddfa81  vmovaps xmm10, [rsp+0xA0]
00007f582cddfa8a  vmovaps xmm11, [rsp+0xB0]
00007f582cddfa93  vmovaps xmm12, [rsp+0xC0]
00007f582cddfa9c  vmovaps xmm14, [rsp+0xD0]
00007f582cddfaa5  vmovaps xmm15, [rsp+0xE0]
00007f582cddfaae  add rsp, 0xF0
00007f582cddfab5  pop r11
00007f582cddfab7  pop r10
00007f582cddfab9  pop r9
00007f582cddfabb  pop r8
00007f582cddfabd  pop rsi
00007f582cddfabe  pop rdi
00007f582cddfabf  pop rdx
00007f582cddfac0  pop rcx
00007f582cddfac1  pop rax
00007f582cddfac2  add rsp, 0x08
00007f582cddfac6  jmp 0x00007F582CDDC458
00007f582cddfacb  sub rsp, 0x08
00007f582cddfacf  push rax
00007f582cddfad0  push rcx
00007f582cddfad1  push rdx
00007f582cddfad2  push rdi
00007f582cddfad3  push rsi
00007f582cddfad4  push r8
00007f582cddfad6  push r9
00007f582cddfad8  push r10
00007f582cddfada  push r11
00007f582cddfadc  sub rsp, 0xF0
00007f582cddfae3  vmovaps [rsp], xmm0
00007f582cddfae8  vmovaps [rsp+0x10], xmm1
00007f582cddfaee  vmovaps [rsp+0x20], xmm2
00007f582cddfaf4  vmovaps [rsp+0x30], xmm3
00007f582cddfafa  vmovaps [rsp+0x40], xmm4
00007f582cddfb00  vmovaps [rsp+0x50], xmm5
00007f582cddfb06  vmovaps [rsp+0x60], xmm6
00007f582cddfb0c  vmovaps [rsp+0x70], xmm7
00007f582cddfb12  vmovaps [rsp+0x80], xmm8
00007f582cddfb1b  vmovaps [rsp+0x90], xmm9
00007f582cddfb24  vmovaps [rsp+0xA0], xmm10
00007f582cddfb2d  vmovaps [rsp+0xB0], xmm11
00007f582cddfb36  vmovaps [rsp+0xC0], xmm12
00007f582cddfb3f  vmovaps [rsp+0xD0], xmm13
00007f582cddfb48  vmovaps [rsp+0xE0], xmm14
00007f582cddfb51  sub rsp, 0x30
00007f582cddfb55  movaps [rsp], xmm15
00007f582cddfb5a  movaps [rsp+0x10], xmm1
00007f582cddfb5f  movaps [rsp+0x20], xmm5
00007f582cddfb64  lea rdi, [rsp]
00007f582cddfb68  mov esi, 0x00
00007f582cddfb6d  mov rax, 0x653B0D9BF530
00007f582cddfb77  call rax
00007f582cddfb79  movaps xmm15, [rsp]
00007f582cddfb7e  add rsp, 0x30
00007f582cddfb82  vmovaps xmm0, [rsp]
00007f582cddfb87  vmovaps xmm1, [rsp+0x10]
00007f582cddfb8d  vmovaps xmm2, [rsp+0x20]
00007f582cddfb93  vmovaps xmm3, [rsp+0x30]
00007f582cddfb99  vmovaps xmm4, [rsp+0x40]
00007f582cddfb9f  vmovaps xmm5, [rsp+0x50]
00007f582cddfba5  vmovaps xmm6, [rsp+0x60]
00007f582cddfbab  vmovaps xmm7, [rsp+0x70]
00007f582cddfbb1  vmovaps xmm8, [rsp+0x80]
00007f582cddfbba  vmovaps xmm9, [rsp+0x90]
00007f582cddfbc3  vmovaps xmm10, [rsp+0xA0]
00007f582cddfbcc  vmovaps xmm11, [rsp+0xB0]
00007f582cddfbd5  vmovaps xmm12, [rsp+0xC0]
00007f582cddfbde  vmovaps xmm13, [rsp+0xD0]
00007f582cddfbe7  vmovaps xmm14, [rsp+0xE0]
00007f582cddfbf0  add rsp, 0xF0
00007f582cddfbf7  pop r11
00007f582cddfbf9  pop r10
00007f582cddfbfb  pop r9
00007f582cddfbfd  pop r8
00007f582cddfbff  pop rsi
00007f582cddfc00  pop rdi
00007f582cddfc01  pop rdx
00007f582cddfc02  pop rcx
00007f582cddfc03  pop rax
00007f582cddfc04  add rsp, 0x08
00007f582cddfc08  jmp 0x00007F582CDDC473
00007f582cddfc0d  call 0x00007F582CCB52F0
00007f582cddfc12  jmp 0x00007F582CDDC4CE
00007f582cddfc17  sub rsp, 0x08
00007f582cddfc1b  push rax
00007f582cddfc1c  push rcx
00007f582cddfc1d  push rdx
00007f582cddfc1e  push rdi
00007f582cddfc1f  push rsi
00007f582cddfc20  push r8
00007f582cddfc22  push r9
00007f582cddfc24  push r10
00007f582cddfc26  push r11
00007f582cddfc28  sub rsp, 0xF0
00007f582cddfc2f  vmovaps [rsp], xmm0
00007f582cddfc34  vmovaps [rsp+0x10], xmm1
00007f582cddfc3a  vmovaps [rsp+0x20], xmm2
00007f582cddfc40  vmovaps [rsp+0x30], xmm3
00007f582cddfc46  vmovaps [rsp+0x40], xmm4
00007f582cddfc4c  vmovaps [rsp+0x50], xmm5
00007f582cddfc52  vmovaps [rsp+0x60], xmm6
00007f582cddfc58  vmovaps [rsp+0x70], xmm7
00007f582cddfc5e  vmovaps [rsp+0x80], xmm8
00007f582cddfc67  vmovaps [rsp+0x90], xmm10
00007f582cddfc70  vmovaps [rsp+0xA0], xmm11
00007f582cddfc79  vmovaps [rsp+0xB0], xmm12
00007f582cddfc82  vmovaps [rsp+0xC0], xmm13
00007f582cddfc8b  vmovaps [rsp+0xD0], xmm14
00007f582cddfc94  vmovaps [rsp+0xE0], xmm15
00007f582cddfc9d  sub rsp, 0x30
00007f582cddfca1  movaps [rsp], xmm9
00007f582cddfca6  movaps [rsp+0x10], xmm8
00007f582cddfcac  movaps [rsp+0x20], xmm11
00007f582cddfcb2  lea rdi, [rsp]
00007f582cddfcb6  mov esi, 0x00
00007f582cddfcbb  mov rax, 0x653B0D9BF530
00007f582cddfcc5  call rax
00007f582cddfcc7  movaps xmm9, [rsp]
00007f582cddfccc  add rsp, 0x30
00007f582cddfcd0  vmovaps xmm0, [rsp]
00007f582cddfcd5  vmovaps xmm1, [rsp+0x10]
00007f582cddfcdb  vmovaps xmm2, [rsp+0x20]
00007f582cddfce1  vmovaps xmm3, [rsp+0x30]
00007f582cddfce7  vmovaps xmm4, [rsp+0x40]
00007f582cddfced  vmovaps xmm5, [rsp+0x50]
00007f582cddfcf3  vmovaps xmm6, [rsp+0x60]
00007f582cddfcf9  vmovaps xmm7, [rsp+0x70]
00007f582cddfcff  vmovaps xmm8, [rsp+0x80]
00007f582cddfd08  vmovaps xmm10, [rsp+0x90]
00007f582cddfd11  vmovaps xmm11, [rsp+0xA0]
00007f582cddfd1a  vmovaps xmm12, [rsp+0xB0]
00007f582cddfd23  vmovaps xmm13, [rsp+0xC0]
00007f582cddfd2c  vmovaps xmm14, [rsp+0xD0]
00007f582cddfd35  vmovaps xmm15, [rsp+0xE0]
00007f582cddfd3e  add rsp, 0xF0
00007f582cddfd45  pop r11
00007f582cddfd47  pop r10
00007f582cddfd49  pop r9
00007f582cddfd4b  pop r8
00007f582cddfd4d  pop rsi
00007f582cddfd4e  pop rdi
00007f582cddfd4f  pop rdx
00007f582cddfd50  pop rcx
00007f582cddfd51  pop rax
00007f582cddfd52  add rsp, 0x08
00007f582cddfd56  jmp 0x00007F582CDDC505
00007f582cddfd5b  sub rsp, 0x08
00007f582cddfd5f  push rax
00007f582cddfd60  push rcx
00007f582cddfd61  push rdx
00007f582cddfd62  push rdi
00007f582cddfd63  push rsi
00007f582cddfd64  push r8
00007f582cddfd66  push r9
00007f582cddfd68  push r10
00007f582cddfd6a  push r11
00007f582cddfd6c  sub rsp, 0xF0
00007f582cddfd73  vmovaps [rsp], xmm0
00007f582cddfd78  vmovaps [rsp+0x10], xmm1
00007f582cddfd7e  vmovaps [rsp+0x20], xmm2
00007f582cddfd84  vmovaps [rsp+0x30], xmm3
00007f582cddfd8a  vmovaps [rsp+0x40], xmm4
00007f582cddfd90  vmovaps [rsp+0x50], xmm5
00007f582cddfd96  vmovaps [rsp+0x60], xmm6
00007f582cddfd9c  vmovaps [rsp+0x70], xmm7
00007f582cddfda2  vmovaps [rsp+0x80], xmm8
00007f582cddfdab  vmovaps [rsp+0x90], xmm9
00007f582cddfdb4  vmovaps [rsp+0xA0], xmm10
00007f582cddfdbd  vmovaps [rsp+0xB0], xmm12
00007f582cddfdc6  vmovaps [rsp+0xC0], xmm13
00007f582cddfdcf  vmovaps [rsp+0xD0], xmm14
00007f582cddfdd8  vmovaps [rsp+0xE0], xmm15
00007f582cddfde1  sub rsp, 0x30
00007f582cddfde5  movaps [rsp], xmm11
00007f582cddfdea  movaps [rsp+0x10], xmm10
00007f582cddfdf0  movaps [rsp+0x20], xmm6
00007f582cddfdf5  lea rdi, [rsp]
00007f582cddfdf9  mov esi, 0x00
00007f582cddfdfe  mov rax, 0x653B0D9BF530
00007f582cddfe08  call rax
00007f582cddfe0a  movaps xmm11, [rsp]
00007f582cddfe0f  add rsp, 0x30
00007f582cddfe13  vmovaps xmm0, [rsp]
00007f582cddfe18  vmovaps xmm1, [rsp+0x10]
00007f582cddfe1e  vmovaps xmm2, [rsp+0x20]
00007f582cddfe24  vmovaps xmm3, [rsp+0x30]
00007f582cddfe2a  vmovaps xmm4, [rsp+0x40]
00007f582cddfe30  vmovaps xmm5, [rsp+0x50]
00007f582cddfe36  vmovaps xmm6, [rsp+0x60]
00007f582cddfe3c  vmovaps xmm7, [rsp+0x70]
00007f582cddfe42  vmovaps xmm8, [rsp+0x80]
00007f582cddfe4b  vmovaps xmm9, [rsp+0x90]
00007f582cddfe54  vmovaps xmm10, [rsp+0xA0]
00007f582cddfe5d  vmovaps xmm12, [rsp+0xB0]
00007f582cddfe66  vmovaps xmm13, [rsp+0xC0]
00007f582cddfe6f  vmovaps xmm14, [rsp+0xD0]
00007f582cddfe78  vmovaps xmm15, [rsp+0xE0]
00007f582cddfe81  add rsp, 0xF0
00007f582cddfe88  pop r11
00007f582cddfe8a  pop r10
00007f582cddfe8c  pop r9
00007f582cddfe8e  pop r8
00007f582cddfe90  pop rsi
00007f582cddfe91  pop rdi
00007f582cddfe92  pop rdx
00007f582cddfe93  pop rcx
00007f582cddfe94  pop rax
00007f582cddfe95  add rsp, 0x08
00007f582cddfe99  jmp 0x00007F582CDDC520
00007f582cddfe9e  sub rsp, 0x08
00007f582cddfea2  push rax
00007f582cddfea3  push rcx
00007f582cddfea4  push rdx
00007f582cddfea5  push rdi
00007f582cddfea6  push rsi
00007f582cddfea7  push r8
00007f582cddfea9  push r9
00007f582cddfeab  push r10
00007f582cddfead  push r11
00007f582cddfeaf  sub rsp, 0xF0
00007f582cddfeb6  vmovaps [rsp], xmm0
00007f582cddfebb  vmovaps [rsp+0x10], xmm1
00007f582cddfec1  vmovaps [rsp+0x20], xmm2
00007f582cddfec7  vmovaps [rsp+0x30], xmm3
00007f582cddfecd  vmovaps [rsp+0x40], xmm4
00007f582cddfed3  vmovaps [rsp+0x50], xmm5
00007f582cddfed9  vmovaps [rsp+0x60], xmm6
00007f582cddfedf  vmovaps [rsp+0x70], xmm7
00007f582cddfee5  vmovaps [rsp+0x80], xmm8
00007f582cddfeee  vmovaps [rsp+0x90], xmm9
00007f582cddfef7  vmovaps [rsp+0xA0], xmm11
00007f582cddff00  vmovaps [rsp+0xB0], xmm12
00007f582cddff09  vmovaps [rsp+0xC0], xmm13
00007f582cddff12  vmovaps [rsp+0xD0], xmm14
00007f582cddff1b  vmovaps [rsp+0xE0], xmm15
00007f582cddff24  sub rsp, 0x30
00007f582cddff28  movaps [rsp], xmm10
00007f582cddff2d  movaps [rsp+0x10], xmm14
00007f582cddff33  movaps [rsp+0x20], xmm4
00007f582cddff38  lea rdi, [rsp]
00007f582cddff3c  mov esi, 0x00
00007f582cddff41  mov rax, 0x653B0D9BF530
00007f582cddff4b  call rax
00007f582cddff4d  movaps xmm10, [rsp]
00007f582cddff52  add rsp, 0x30
00007f582cddff56  vmovaps xmm0, [rsp]
00007f582cddff5b  vmovaps xmm1, [rsp+0x10]
00007f582cddff61  vmovaps xmm2, [rsp+0x20]
00007f582cddff67  vmovaps xmm3, [rsp+0x30]
00007f582cddff6d  vmovaps xmm4, [rsp+0x40]
00007f582cddff73  vmovaps xmm5, [rsp+0x50]
00007f582cddff79  vmovaps xmm6, [rsp+0x60]
00007f582cddff7f  vmovaps xmm7, [rsp+0x70]
00007f582cddff85  vmovaps xmm8, [rsp+0x80]
00007f582cddff8e  vmovaps xmm9, [rsp+0x90]
00007f582cddff97  vmovaps xmm11, [rsp+0xA0]
00007f582cddffa0  vmovaps xmm12, [rsp+0xB0]
00007f582cddffa9  vmovaps xmm13, [rsp+0xC0]
00007f582cddffb2  vmovaps xmm14, [rsp+0xD0]
00007f582cddffbb  vmovaps xmm15, [rsp+0xE0]
00007f582cddffc4  add rsp, 0xF0
00007f582cddffcb  pop r11
00007f582cddffcd  pop r10
00007f582cddffcf  pop r9
00007f582cddffd1  pop r8
00007f582cddffd3  pop rsi
00007f582cddffd4  pop rdi
00007f582cddffd5  pop rdx
00007f582cddffd6  pop rcx
00007f582cddffd7  pop rax
00007f582cddffd8  add rsp, 0x08
00007f582cddffdc  jmp 0x00007F582CDDC53B
00007f582cddffe1  sub rsp, 0x08
00007f582cddffe5  push rax
00007f582cddffe6  push rcx
00007f582cddffe7  push rdx
00007f582cddffe8  push rdi
00007f582cddffe9  push rsi
00007f582cddffea  push r8
00007f582cddffec  push r9
00007f582cddffee  push r10
00007f582cddfff0  push r11
00007f582cddfff2  sub rsp, 0xF0
00007f582cddfff9  vmovaps [rsp], xmm0
00007f582cddfffe  vmovaps [rsp+0x10], xmm1
00007f582cde0004  vmovaps [rsp+0x20], xmm2
00007f582cde000a  vmovaps [rsp+0x30], xmm3
00007f582cde0010  vmovaps [rsp+0x40], xmm4
00007f582cde0016  vmovaps [rsp+0x50], xmm5
00007f582cde001c  vmovaps [rsp+0x60], xmm6
00007f582cde0022  vmovaps [rsp+0x70], xmm7
00007f582cde0028  vmovaps [rsp+0x80], xmm9
00007f582cde0031  vmovaps [rsp+0x90], xmm10
00007f582cde003a  vmovaps [rsp+0xA0], xmm11
00007f582cde0043  vmovaps [rsp+0xB0], xmm12
00007f582cde004c  vmovaps [rsp+0xC0], xmm13
00007f582cde0055  vmovaps [rsp+0xD0], xmm14
00007f582cde005e  vmovaps [rsp+0xE0], xmm15
00007f582cde0067  sub rsp, 0x30
00007f582cde006b  movaps [rsp], xmm8
00007f582cde0070  movaps [rsp+0x10], xmm1
00007f582cde0075  movaps [rsp+0x20], xmm14
00007f582cde007b  lea rdi, [rsp]
00007f582cde007f  mov esi, 0x00
00007f582cde0084  mov rax, 0x653B0D9BF530
00007f582cde008e  call rax
00007f582cde0090  movaps xmm8, [rsp]
00007f582cde0095  add rsp, 0x30
00007f582cde0099  vmovaps xmm0, [rsp]
00007f582cde009e  vmovaps xmm1, [rsp+0x10]
00007f582cde00a4  vmovaps xmm2, [rsp+0x20]
00007f582cde00aa  vmovaps xmm3, [rsp+0x30]
00007f582cde00b0  vmovaps xmm4, [rsp+0x40]
00007f582cde00b6  vmovaps xmm5, [rsp+0x50]
00007f582cde00bc  vmovaps xmm6, [rsp+0x60]
00007f582cde00c2  vmovaps xmm7, [rsp+0x70]
00007f582cde00c8  vmovaps xmm9, [rsp+0x80]
00007f582cde00d1  vmovaps xmm10, [rsp+0x90]
00007f582cde00da  vmovaps xmm11, [rsp+0xA0]
00007f582cde00e3  vmovaps xmm12, [rsp+0xB0]
00007f582cde00ec  vmovaps xmm13, [rsp+0xC0]
00007f582cde00f5  vmovaps xmm14, [rsp+0xD0]
00007f582cde00fe  vmovaps xmm15, [rsp+0xE0]
00007f582cde0107  add rsp, 0xF0
00007f582cde010e  pop r11
00007f582cde0110  pop r10
00007f582cde0112  pop r9
00007f582cde0114  pop r8
00007f582cde0116  pop rsi
00007f582cde0117  pop rdi
00007f582cde0118  pop rdx
00007f582cde0119  pop rcx
00007f582cde011a  pop rax
00007f582cde011b  add rsp, 0x08
00007f582cde011f  jmp 0x00007F582CDDC561
00007f582cde0124  sub rsp, 0x08
00007f582cde0128  push rax
00007f582cde0129  push rcx
00007f582cde012a  push rdx
00007f582cde012b  push rdi
00007f582cde012c  push rsi
00007f582cde012d  push r8
00007f582cde012f  push r9
00007f582cde0131  push r10
00007f582cde0133  push r11
00007f582cde0135  sub rsp, 0xF0
00007f582cde013c  vmovaps [rsp], xmm0
00007f582cde0141  vmovaps [rsp+0x10], xmm1
00007f582cde0147  vmovaps [rsp+0x20], xmm2
00007f582cde014d  vmovaps [rsp+0x30], xmm3
00007f582cde0153  vmovaps [rsp+0x40], xmm4
00007f582cde0159  vmovaps [rsp+0x50], xmm5
00007f582cde015f  vmovaps [rsp+0x60], xmm7
00007f582cde0165  vmovaps [rsp+0x70], xmm8
00007f582cde016b  vmovaps [rsp+0x80], xmm9
00007f582cde0174  vmovaps [rsp+0x90], xmm10
00007f582cde017d  vmovaps [rsp+0xA0], xmm11
00007f582cde0186  vmovaps [rsp+0xB0], xmm12
00007f582cde018f  vmovaps [rsp+0xC0], xmm13
00007f582cde0198  vmovaps [rsp+0xD0], xmm14
00007f582cde01a1  vmovaps [rsp+0xE0], xmm15
00007f582cde01aa  sub rsp, 0x30
00007f582cde01ae  movaps [rsp], xmm6
00007f582cde01b2  movaps [rsp+0x10], xmm1
00007f582cde01b7  movaps [rsp+0x20], xmm14
00007f582cde01bd  lea rdi, [rsp]
00007f582cde01c1  mov esi, 0x00
00007f582cde01c6  mov rax, 0x653B0D9BF530
00007f582cde01d0  call rax
00007f582cde01d2  movaps xmm6, [rsp]
00007f582cde01d6  add rsp, 0x30
00007f582cde01da  vmovaps xmm0, [rsp]
00007f582cde01df  vmovaps xmm1, [rsp+0x10]
00007f582cde01e5  vmovaps xmm2, [rsp+0x20]
00007f582cde01eb  vmovaps xmm3, [rsp+0x30]
00007f582cde01f1  vmovaps xmm4, [rsp+0x40]
00007f582cde01f7  vmovaps xmm5, [rsp+0x50]
00007f582cde01fd  vmovaps xmm7, [rsp+0x60]
00007f582cde0203  vmovaps xmm8, [rsp+0x70]
00007f582cde0209  vmovaps xmm9, [rsp+0x80]
00007f582cde0212  vmovaps xmm10, [rsp+0x90]
00007f582cde021b  vmovaps xmm11, [rsp+0xA0]
00007f582cde0224  vmovaps xmm12, [rsp+0xB0]
00007f582cde022d  vmovaps xmm13, [rsp+0xC0]
00007f582cde0236  vmovaps xmm14, [rsp+0xD0]
00007f582cde023f  vmovaps xmm15, [rsp+0xE0]
00007f582cde0248  add rsp, 0xF0
00007f582cde024f  pop r11
00007f582cde0251  pop r10
00007f582cde0253  pop r9
00007f582cde0255  pop r8
00007f582cde0257  pop rsi
00007f582cde0258  pop rdi
00007f582cde0259  pop rdx
00007f582cde025a  pop rcx
00007f582cde025b  pop rax
00007f582cde025c  add rsp, 0x08
00007f582cde0260  jmp 0x00007F582CDDC58D
00007f582cde0265  sub rsp, 0x08
00007f582cde0269  push rax
00007f582cde026a  push rcx
00007f582cde026b  push rdx
00007f582cde026c  push rdi
00007f582cde026d  push rsi
00007f582cde026e  push r8
00007f582cde0270  push r9
00007f582cde0272  push r10
00007f582cde0274  push r11
00007f582cde0276  sub rsp, 0xF0
00007f582cde027d  vmovaps [rsp], xmm0
00007f582cde0282  vmovaps [rsp+0x10], xmm1
00007f582cde0288  vmovaps [rsp+0x20], xmm2
00007f582cde028e  vmovaps [rsp+0x30], xmm3
00007f582cde0294  vmovaps [rsp+0x40], xmm4
00007f582cde029a  vmovaps [rsp+0x50], xmm5
00007f582cde02a0  vmovaps [rsp+0x60], xmm6
00007f582cde02a6  vmovaps [rsp+0x70], xmm7
00007f582cde02ac  vmovaps [rsp+0x80], xmm8
00007f582cde02b5  vmovaps [rsp+0x90], xmm9
00007f582cde02be  vmovaps [rsp+0xA0], xmm10
00007f582cde02c7  vmovaps [rsp+0xB0], xmm11
00007f582cde02d0  vmovaps [rsp+0xC0], xmm12
00007f582cde02d9  vmovaps [rsp+0xD0], xmm13
00007f582cde02e2  vmovaps [rsp+0xE0], xmm15
00007f582cde02eb  sub rsp, 0x30
00007f582cde02ef  movaps [rsp], xmm14
00007f582cde02f4  movaps [rsp+0x10], xmm12
00007f582cde02fa  movaps [rsp+0x20], xmm1
00007f582cde02ff  lea rdi, [rsp]
00007f582cde0303  mov esi, 0x00
00007f582cde0308  mov rax, 0x653B0D9BF530
00007f582cde0312  call rax
00007f582cde0314  movaps xmm14, [rsp]
00007f582cde0319  add rsp, 0x30
00007f582cde031d  vmovaps xmm0, [rsp]
00007f582cde0322  vmovaps xmm1, [rsp+0x10]
00007f582cde0328  vmovaps xmm2, [rsp+0x20]
00007f582cde032e  vmovaps xmm3, [rsp+0x30]
00007f582cde0334  vmovaps xmm4, [rsp+0x40]
00007f582cde033a  vmovaps xmm5, [rsp+0x50]
00007f582cde0340  vmovaps xmm6, [rsp+0x60]
00007f582cde0346  vmovaps xmm7, [rsp+0x70]
00007f582cde034c  vmovaps xmm8, [rsp+0x80]
00007f582cde0355  vmovaps xmm9, [rsp+0x90]
00007f582cde035e  vmovaps xmm10, [rsp+0xA0]
00007f582cde0367  vmovaps xmm11, [rsp+0xB0]
00007f582cde0370  vmovaps xmm12, [rsp+0xC0]
00007f582cde0379  vmovaps xmm13, [rsp+0xD0]
00007f582cde0382  vmovaps xmm15, [rsp+0xE0]
00007f582cde038b  add rsp, 0xF0
00007f582cde0392  pop r11
00007f582cde0394  pop r10
00007f582cde0396  pop r9
00007f582cde0398  pop r8
00007f582cde039a  pop rsi
00007f582cde039b  pop rdi
00007f582cde039c  pop rdx
00007f582cde039d  pop rcx
00007f582cde039e  pop rax
00007f582cde039f  add rsp, 0x08
00007f582cde03a3  jmp 0x00007F582CDDC5B3
00007f582cde03a8  sub rsp, 0x08
00007f582cde03ac  push rax
00007f582cde03ad  push rcx
00007f582cde03ae  push rdx
00007f582cde03af  push rdi
00007f582cde03b0  push rsi
00007f582cde03b1  push r8
00007f582cde03b3  push r9
00007f582cde03b5  push r10
00007f582cde03b7  push r11
00007f582cde03b9  sub rsp, 0xF0
00007f582cde03c0  vmovaps [rsp], xmm0
00007f582cde03c5  vmovaps [rsp+0x10], xmm2
00007f582cde03cb  vmovaps [rsp+0x20], xmm3
00007f582cde03d1  vmovaps [rsp+0x30], xmm4
00007f582cde03d7  vmovaps [rsp+0x40], xmm5
00007f582cde03dd  vmovaps [rsp+0x50], xmm6
00007f582cde03e3  vmovaps [rsp+0x60], xmm7
00007f582cde03e9  vmovaps [rsp+0x70], xmm8
00007f582cde03ef  vmovaps [rsp+0x80], xmm9
00007f582cde03f8  vmovaps [rsp+0x90], xmm10
00007f582cde0401  vmovaps [rsp+0xA0], xmm11
00007f582cde040a  vmovaps [rsp+0xB0], xmm12
00007f582cde0413  vmovaps [rsp+0xC0], xmm13
00007f582cde041c  vmovaps [rsp+0xD0], xmm14
00007f582cde0425  vmovaps [rsp+0xE0], xmm15
00007f582cde042e  sub rsp, 0x30
00007f582cde0432  movaps [rsp], xmm1
00007f582cde0436  movaps [rsp+0x10], xmm13
00007f582cde043c  movaps [rsp+0x20], xmm9
00007f582cde0442  lea rdi, [rsp]
00007f582cde0446  mov esi, 0x00
00007f582cde044b  mov rax, 0x653B0D9BF530
00007f582cde0455  call rax
00007f582cde0457  movaps xmm1, [rsp]
00007f582cde045b  add rsp, 0x30
00007f582cde045f  vmovaps xmm0, [rsp]
00007f582cde0464  vmovaps xmm2, [rsp+0x10]
00007f582cde046a  vmovaps xmm3, [rsp+0x20]
00007f582cde0470  vmovaps xmm4, [rsp+0x30]
00007f582cde0476  vmovaps xmm5, [rsp+0x40]
00007f582cde047c  vmovaps xmm6, [rsp+0x50]
00007f582cde0482  vmovaps xmm7, [rsp+0x60]
00007f582cde0488  vmovaps xmm8, [rsp+0x70]
00007f582cde048e  vmovaps xmm9, [rsp+0x80]
00007f582cde0497  vmovaps xmm10, [rsp+0x90]
00007f582cde04a0  vmovaps xmm11, [rsp+0xA0]
00007f582cde04a9  vmovaps xmm12, [rsp+0xB0]
00007f582cde04b2  vmovaps xmm13, [rsp+0xC0]
00007f582cde04bb  vmovaps xmm14, [rsp+0xD0]
00007f582cde04c4  vmovaps xmm15, [rsp+0xE0]
00007f582cde04cd  add rsp, 0xF0
00007f582cde04d4  pop r11
00007f582cde04d6  pop r10
00007f582cde04d8  pop r9
00007f582cde04da  pop r8
00007f582cde04dc  pop rsi
00007f582cde04dd  pop rdi
00007f582cde04de  pop rdx
00007f582cde04df  pop rcx
00007f582cde04e0  pop rax
00007f582cde04e1  add rsp, 0x08
00007f582cde04e5  jmp 0x00007F582CDDC5CD
00007f582cde04ea  sub rsp, 0x08
00007f582cde04ee  push rax
00007f582cde04ef  push rcx
00007f582cde04f0  push rdx
00007f582cde04f1  push rdi
00007f582cde04f2  push rsi
00007f582cde04f3  push r8
00007f582cde04f5  push r9
00007f582cde04f7  push r10
00007f582cde04f9  push r11
00007f582cde04fb  sub rsp, 0xF0
00007f582cde0502  vmovaps [rsp], xmm0
00007f582cde0507  vmovaps [rsp+0x10], xmm1
00007f582cde050d  vmovaps [rsp+0x20], xmm2
00007f582cde0513  vmovaps [rsp+0x30], xmm3
00007f582cde0519  vmovaps [rsp+0x40], xmm4
00007f582cde051f  vmovaps [rsp+0x50], xmm5
00007f582cde0525  vmovaps [rsp+0x60], xmm6
00007f582cde052b  vmovaps [rsp+0x70], xmm7
00007f582cde0531  vmovaps [rsp+0x80], xmm8
00007f582cde053a  vmovaps [rsp+0x90], xmm9
00007f582cde0543  vmovaps [rsp+0xA0], xmm10
00007f582cde054c  vmovaps [rsp+0xB0], xmm11
00007f582cde0555  vmovaps [rsp+0xC0], xmm13
00007f582cde055e  vmovaps [rsp+0xD0], xmm14
00007f582cde0567  vmovaps [rsp+0xE0], xmm15
00007f582cde0570  sub rsp, 0x30
00007f582cde0574  movaps [rsp], xmm12
00007f582cde0579  movaps [rsp+0x10], xmm7
00007f582cde057e  movaps [rsp+0x20], xmm13
00007f582cde0584  lea rdi, [rsp]
00007f582cde0588  mov esi, 0x00
00007f582cde058d  mov rax, 0x653B0D9BF530
00007f582cde0597  call rax
00007f582cde0599  movaps xmm12, [rsp]
00007f582cde059e  add rsp, 0x30
00007f582cde05a2  vmovaps xmm0, [rsp]
00007f582cde05a7  vmovaps xmm1, [rsp+0x10]
00007f582cde05ad  vmovaps xmm2, [rsp+0x20]
00007f582cde05b3  vmovaps xmm3, [rsp+0x30]
00007f582cde05b9  vmovaps xmm4, [rsp+0x40]
00007f582cde05bf  vmovaps xmm5, [rsp+0x50]
00007f582cde05c5  vmovaps xmm6, [rsp+0x60]
00007f582cde05cb  vmovaps xmm7, [rsp+0x70]
00007f582cde05d1  vmovaps xmm8, [rsp+0x80]
00007f582cde05da  vmovaps xmm9, [rsp+0x90]
00007f582cde05e3  vmovaps xmm10, [rsp+0xA0]
00007f582cde05ec  vmovaps xmm11, [rsp+0xB0]
00007f582cde05f5  vmovaps xmm13, [rsp+0xC0]
00007f582cde05fe  vmovaps xmm14, [rsp+0xD0]
00007f582cde0607  vmovaps xmm15, [rsp+0xE0]
00007f582cde0610  add rsp, 0xF0
00007f582cde0617  pop r11
00007f582cde0619  pop r10
00007f582cde061b  pop r9
00007f582cde061d  pop r8
00007f582cde061f  pop rsi
00007f582cde0620  pop rdi
00007f582cde0621  pop rdx
00007f582cde0622  pop rcx
00007f582cde0623  pop rax
00007f582cde0624  add rsp, 0x08
00007f582cde0628  jmp 0x00007F582CDDC5F4
00007f582cde062d  sub rsp, 0x08
00007f582cde0631  push rax
00007f582cde0632  push rcx
00007f582cde0633  push rdx
00007f582cde0634  push rdi
00007f582cde0635  push rsi
00007f582cde0636  push r8
00007f582cde0638  push r9
00007f582cde063a  push r10
00007f582cde063c  push r11
00007f582cde063e  sub rsp, 0xF0
00007f582cde0645  vmovaps [rsp], xmm0
00007f582cde064a  vmovaps [rsp+0x10], xmm1
00007f582cde0650  vmovaps [rsp+0x20], xmm2
00007f582cde0656  vmovaps [rsp+0x30], xmm3
00007f582cde065c  vmovaps [rsp+0x40], xmm4
00007f582cde0662  vmovaps [rsp+0x50], xmm5
00007f582cde0668  vmovaps [rsp+0x60], xmm6
00007f582cde066e  vmovaps [rsp+0x70], xmm7
00007f582cde0674  vmovaps [rsp+0x80], xmm8
00007f582cde067d  vmovaps [rsp+0x90], xmm9
00007f582cde0686  vmovaps [rsp+0xA0], xmm10
00007f582cde068f  vmovaps [rsp+0xB0], xmm11
00007f582cde0698  vmovaps [rsp+0xC0], xmm12
00007f582cde06a1  vmovaps [rsp+0xD0], xmm14
00007f582cde06aa  vmovaps [rsp+0xE0], xmm15
00007f582cde06b3  sub rsp, 0x30
00007f582cde06b7  movaps [rsp], xmm13
00007f582cde06bc  movaps [rsp+0x10], xmm15
00007f582cde06c2  movaps [rsp+0x20], xmm8
00007f582cde06c8  lea rdi, [rsp]
00007f582cde06cc  mov esi, 0x00
00007f582cde06d1  mov rax, 0x653B0D9BF530
00007f582cde06db  call rax
00007f582cde06dd  movaps xmm13, [rsp]
00007f582cde06e2  add rsp, 0x30
00007f582cde06e6  vmovaps xmm0, [rsp]
00007f582cde06eb  vmovaps xmm1, [rsp+0x10]
00007f582cde06f1  vmovaps xmm2, [rsp+0x20]
00007f582cde06f7  vmovaps xmm3, [rsp+0x30]
00007f582cde06fd  vmovaps xmm4, [rsp+0x40]
00007f582cde0703  vmovaps xmm5, [rsp+0x50]
00007f582cde0709  vmovaps xmm6, [rsp+0x60]
00007f582cde070f  vmovaps xmm7, [rsp+0x70]
00007f582cde0715  vmovaps xmm8, [rsp+0x80]
00007f582cde071e  vmovaps xmm9, [rsp+0x90]
00007f582cde0727  vmovaps xmm10, [rsp+0xA0]
00007f582cde0730  vmovaps xmm11, [rsp+0xB0]
00007f582cde0739  vmovaps xmm12, [rsp+0xC0]
00007f582cde0742  vmovaps xmm14, [rsp+0xD0]
00007f582cde074b  vmovaps xmm15, [rsp+0xE0]
00007f582cde0754  add rsp, 0xF0
00007f582cde075b  pop r11
00007f582cde075d  pop r10
00007f582cde075f  pop r9
00007f582cde0761  pop r8
00007f582cde0763  pop rsi
00007f582cde0764  pop rdi
00007f582cde0765  pop rdx
00007f582cde0766  pop rcx
00007f582cde0767  pop rax
00007f582cde0768  add rsp, 0x08
00007f582cde076c  jmp 0x00007F582CDDC60F
00007f582cde0771  sub rsp, 0x08
00007f582cde0775  push rax
00007f582cde0776  push rcx
00007f582cde0777  push rdx
00007f582cde0778  push rdi
00007f582cde0779  push rsi
00007f582cde077a  push r8
00007f582cde077c  push r9
00007f582cde077e  push r10
00007f582cde0780  push r11
00007f582cde0782  sub rsp, 0xF0
00007f582cde0789  vmovaps [rsp], xmm0
00007f582cde078e  vmovaps [rsp+0x10], xmm1
00007f582cde0794  vmovaps [rsp+0x20], xmm2
00007f582cde079a  vmovaps [rsp+0x30], xmm3
00007f582cde07a0  vmovaps [rsp+0x40], xmm4
00007f582cde07a6  vmovaps [rsp+0x50], xmm5
00007f582cde07ac  vmovaps [rsp+0x60], xmm6
00007f582cde07b2  vmovaps [rsp+0x70], xmm7
00007f582cde07b8  vmovaps [rsp+0x80], xmm9
00007f582cde07c1  vmovaps [rsp+0x90], xmm10
00007f582cde07ca  vmovaps [rsp+0xA0], xmm11
00007f582cde07d3  vmovaps [rsp+0xB0], xmm12
00007f582cde07dc  vmovaps [rsp+0xC0], xmm13
00007f582cde07e5  vmovaps [rsp+0xD0], xmm14
00007f582cde07ee  vmovaps [rsp+0xE0], xmm15
00007f582cde07f7  sub rsp, 0x30
00007f582cde07fb  movaps [rsp], xmm8
00007f582cde0800  movaps [rsp+0x10], xmm15
00007f582cde0806  movaps [rsp+0x20], xmm9
00007f582cde080c  lea rdi, [rsp]
00007f582cde0810  mov esi, 0x00
00007f582cde0815  mov rax, 0x653B0D9BF530
00007f582cde081f  call rax
00007f582cde0821  movaps xmm8, [rsp]
00007f582cde0826  add rsp, 0x30
00007f582cde082a  vmovaps xmm0, [rsp]
00007f582cde082f  vmovaps xmm1, [rsp+0x10]
00007f582cde0835  vmovaps xmm2, [rsp+0x20]
00007f582cde083b  vmovaps xmm3, [rsp+0x30]
00007f582cde0841  vmovaps xmm4, [rsp+0x40]
00007f582cde0847  vmovaps xmm5, [rsp+0x50]
00007f582cde084d  vmovaps xmm6, [rsp+0x60]
00007f582cde0853  vmovaps xmm7, [rsp+0x70]
00007f582cde0859  vmovaps xmm9, [rsp+0x80]
00007f582cde0862  vmovaps xmm10, [rsp+0x90]
00007f582cde086b  vmovaps xmm11, [rsp+0xA0]
00007f582cde0874  vmovaps xmm12, [rsp+0xB0]
00007f582cde087d  vmovaps xmm13, [rsp+0xC0]
00007f582cde0886  vmovaps xmm14, [rsp+0xD0]
00007f582cde088f  vmovaps xmm15, [rsp+0xE0]
00007f582cde0898  add rsp, 0xF0
00007f582cde089f  pop r11
00007f582cde08a1  pop r10
00007f582cde08a3  pop r9
00007f582cde08a5  pop r8
00007f582cde08a7  pop rsi
00007f582cde08a8  pop rdi
00007f582cde08a9  pop rdx
00007f582cde08aa  pop rcx
00007f582cde08ab  pop rax
00007f582cde08ac  add rsp, 0x08
00007f582cde08b0  jmp 0x00007F582CDDC63D
00007f582cde08b5  sub rsp, 0x08
00007f582cde08b9  push rax
00007f582cde08ba  push rcx
00007f582cde08bb  push rdx
00007f582cde08bc  push rdi
00007f582cde08bd  push rsi
00007f582cde08be  push r8
00007f582cde08c0  push r9
00007f582cde08c2  push r10
00007f582cde08c4  push r11
00007f582cde08c6  sub rsp, 0xF0
00007f582cde08cd  vmovaps [rsp], xmm0
00007f582cde08d2  vmovaps [rsp+0x10], xmm1
00007f582cde08d8  vmovaps [rsp+0x20], xmm2
00007f582cde08de  vmovaps [rsp+0x30], xmm3
00007f582cde08e4  vmovaps [rsp+0x40], xmm4
00007f582cde08ea  vmovaps [rsp+0x50], xmm5
00007f582cde08f0  vmovaps [rsp+0x60], xmm6
00007f582cde08f6  vmovaps [rsp+0x70], xmm7
00007f582cde08fc  vmovaps [rsp+0x80], xmm8
00007f582cde0905  vmovaps [rsp+0x90], xmm9
00007f582cde090e  vmovaps [rsp+0xA0], xmm10
00007f582cde0917  vmovaps [rsp+0xB0], xmm11
00007f582cde0920  vmovaps [rsp+0xC0], xmm12
00007f582cde0929  vmovaps [rsp+0xD0], xmm13
00007f582cde0932  vmovaps [rsp+0xE0], xmm14
00007f582cde093b  sub rsp, 0x30
00007f582cde093f  movaps [rsp], xmm15
00007f582cde0944  movaps [rsp+0x10], xmm11
00007f582cde094a  movaps [rsp+0x20], xmm6
00007f582cde094f  lea rdi, [rsp]
00007f582cde0953  mov esi, 0x00
00007f582cde0958  mov rax, 0x653B0D9BF530
00007f582cde0962  call rax
00007f582cde0964  movaps xmm15, [rsp]
00007f582cde0969  add rsp, 0x30
00007f582cde096d  vmovaps xmm0, [rsp]
00007f582cde0972  vmovaps xmm1, [rsp+0x10]
00007f582cde0978  vmovaps xmm2, [rsp+0x20]
00007f582cde097e  vmovaps xmm3, [rsp+0x30]
00007f582cde0984  vmovaps xmm4, [rsp+0x40]
00007f582cde098a  vmovaps xmm5, [rsp+0x50]
00007f582cde0990  vmovaps xmm6, [rsp+0x60]
00007f582cde0996  vmovaps xmm7, [rsp+0x70]
00007f582cde099c  vmovaps xmm8, [rsp+0x80]
00007f582cde09a5  vmovaps xmm9, [rsp+0x90]
00007f582cde09ae  vmovaps xmm10, [rsp+0xA0]
00007f582cde09b7  vmovaps xmm11, [rsp+0xB0]
00007f582cde09c0  vmovaps xmm12, [rsp+0xC0]
00007f582cde09c9  vmovaps xmm13, [rsp+0xD0]
00007f582cde09d2  vmovaps xmm14, [rsp+0xE0]
00007f582cde09db  add rsp, 0xF0
00007f582cde09e2  pop r11
00007f582cde09e4  pop r10
00007f582cde09e6  pop r9
00007f582cde09e8  pop r8
00007f582cde09ea  pop rsi
00007f582cde09eb  pop rdi
00007f582cde09ec  pop rdx
00007f582cde09ed  pop rcx
00007f582cde09ee  pop rax
00007f582cde09ef  add rsp, 0x08
00007f582cde09f3  jmp 0x00007F582CDDC658
00007f582cde09f8  sub rsp, 0x08
00007f582cde09fc  push rax
00007f582cde09fd  push rcx
00007f582cde09fe  push rdx
00007f582cde09ff  push rdi
00007f582cde0a00  push rsi
00007f582cde0a01  push r8
00007f582cde0a03  push r9
00007f582cde0a05  push r10
00007f582cde0a07  push r11
00007f582cde0a09  sub rsp, 0xF0
00007f582cde0a10  vmovaps [rsp], xmm0
00007f582cde0a15  vmovaps [rsp+0x10], xmm1
00007f582cde0a1b  vmovaps [rsp+0x20], xmm2
00007f582cde0a21  vmovaps [rsp+0x30], xmm3
00007f582cde0a27  vmovaps [rsp+0x40], xmm4
00007f582cde0a2d  vmovaps [rsp+0x50], xmm5
00007f582cde0a33  vmovaps [rsp+0x60], xmm6
00007f582cde0a39  vmovaps [rsp+0x70], xmm8
00007f582cde0a3f  vmovaps [rsp+0x80], xmm9
00007f582cde0a48  vmovaps [rsp+0x90], xmm10
00007f582cde0a51  vmovaps [rsp+0xA0], xmm11
00007f582cde0a5a  vmovaps [rsp+0xB0], xmm12
00007f582cde0a63  vmovaps [rsp+0xC0], xmm13
00007f582cde0a6c  vmovaps [rsp+0xD0], xmm14
00007f582cde0a75  vmovaps [rsp+0xE0], xmm15
00007f582cde0a7e  sub rsp, 0x30
00007f582cde0a82  movaps [rsp], xmm7
00007f582cde0a86  movaps [rsp+0x10], xmm11
00007f582cde0a8c  movaps [rsp+0x20], xmm9
00007f582cde0a92  lea rdi, [rsp]
00007f582cde0a96  mov esi, 0x00
00007f582cde0a9b  mov rax, 0x653B0D9BF530
00007f582cde0aa5  call rax
00007f582cde0aa7  movaps xmm7, [rsp]
00007f582cde0aab  add rsp, 0x30
00007f582cde0aaf  vmovaps xmm0, [rsp]
00007f582cde0ab4  vmovaps xmm1, [rsp+0x10]
00007f582cde0aba  vmovaps xmm2, [rsp+0x20]
00007f582cde0ac0  vmovaps xmm3, [rsp+0x30]
00007f582cde0ac6  vmovaps xmm4, [rsp+0x40]
00007f582cde0acc  vmovaps xmm5, [rsp+0x50]
00007f582cde0ad2  vmovaps xmm6, [rsp+0x60]
00007f582cde0ad8  vmovaps xmm8, [rsp+0x70]
00007f582cde0ade  vmovaps xmm9, [rsp+0x80]
00007f582cde0ae7  vmovaps xmm10, [rsp+0x90]
00007f582cde0af0  vmovaps xmm11, [rsp+0xA0]
00007f582cde0af9  vmovaps xmm12, [rsp+0xB0]
00007f582cde0b02  vmovaps xmm13, [rsp+0xC0]
00007f582cde0b0b  vmovaps xmm14, [rsp+0xD0]
00007f582cde0b14  vmovaps xmm15, [rsp+0xE0]
00007f582cde0b1d  add rsp, 0xF0
00007f582cde0b24  pop r11
00007f582cde0b26  pop r10
00007f582cde0b28  pop r9
00007f582cde0b2a  pop r8
00007f582cde0b2c  pop rsi
00007f582cde0b2d  pop rdi
00007f582cde0b2e  pop rdx
00007f582cde0b2f  pop rcx
00007f582cde0b30  pop rax
00007f582cde0b31  add rsp, 0x08
00007f582cde0b35  jmp 0x00007F582CDDC685
00007f582cde0b3a  sub rsp, 0x08
00007f582cde0b3e  push rax
00007f582cde0b3f  push rcx
00007f582cde0b40  push rdx
00007f582cde0b41  push rdi
00007f582cde0b42  push rsi
00007f582cde0b43  push r8
00007f582cde0b45  push r9
00007f582cde0b47  push r10
00007f582cde0b49  push r11
00007f582cde0b4b  sub rsp, 0xF0
00007f582cde0b52  vmovaps [rsp], xmm0
00007f582cde0b57  vmovaps [rsp+0x10], xmm1
00007f582cde0b5d  vmovaps [rsp+0x20], xmm2
00007f582cde0b63  vmovaps [rsp+0x30], xmm3
00007f582cde0b69  vmovaps [rsp+0x40], xmm4
00007f582cde0b6f  vmovaps [rsp+0x50], xmm5
00007f582cde0b75  vmovaps [rsp+0x60], xmm6
00007f582cde0b7b  vmovaps [rsp+0x70], xmm7
00007f582cde0b81  vmovaps [rsp+0x80], xmm8
00007f582cde0b8a  vmovaps [rsp+0x90], xmm9
00007f582cde0b93  vmovaps [rsp+0xA0], xmm10
00007f582cde0b9c  vmovaps [rsp+0xB0], xmm12
00007f582cde0ba5  vmovaps [rsp+0xC0], xmm13
00007f582cde0bae  vmovaps [rsp+0xD0], xmm14
00007f582cde0bb7  vmovaps [rsp+0xE0], xmm15
00007f582cde0bc0  sub rsp, 0x30
00007f582cde0bc4  movaps [rsp], xmm11
00007f582cde0bc9  movaps [rsp+0x10], xmm10
00007f582cde0bcf  movaps [rsp+0x20], xmm14
00007f582cde0bd5  lea rdi, [rsp]
00007f582cde0bd9  mov esi, 0x00
00007f582cde0bde  mov rax, 0x653B0D9BF530
00007f582cde0be8  call rax
00007f582cde0bea  movaps xmm11, [rsp]
00007f582cde0bef  add rsp, 0x30
00007f582cde0bf3  vmovaps xmm0, [rsp]
00007f582cde0bf8  vmovaps xmm1, [rsp+0x10]
00007f582cde0bfe  vmovaps xmm2, [rsp+0x20]
00007f582cde0c04  vmovaps xmm3, [rsp+0x30]
00007f582cde0c0a  vmovaps xmm4, [rsp+0x40]
00007f582cde0c10  vmovaps xmm5, [rsp+0x50]
00007f582cde0c16  vmovaps xmm6, [rsp+0x60]
00007f582cde0c1c  vmovaps xmm7, [rsp+0x70]
00007f582cde0c22  vmovaps xmm8, [rsp+0x80]
00007f582cde0c2b  vmovaps xmm9, [rsp+0x90]
00007f582cde0c34  vmovaps xmm10, [rsp+0xA0]
00007f582cde0c3d  vmovaps xmm12, [rsp+0xB0]
00007f582cde0c46  vmovaps xmm13, [rsp+0xC0]
00007f582cde0c4f  vmovaps xmm14, [rsp+0xD0]
00007f582cde0c58  vmovaps xmm15, [rsp+0xE0]
00007f582cde0c61  add rsp, 0xF0
00007f582cde0c68  pop r11
00007f582cde0c6a  pop r10
00007f582cde0c6c  pop r9
00007f582cde0c6e  pop r8
00007f582cde0c70  pop rsi
00007f582cde0c71  pop rdi
00007f582cde0c72  pop rdx
00007f582cde0c73  pop rcx
00007f582cde0c74  pop rax
00007f582cde0c75  add rsp, 0x08
00007f582cde0c79  jmp 0x00007F582CDDC6A0
00007f582cde0c7e  call 0x00007F582CCC33A0
00007f582cde0c83  jmp 0x00007F582CDDC6AA
00007f582cde0c88  sub rsp, 0x08
00007f582cde0c8c  push rax
00007f582cde0c8d  push rcx
00007f582cde0c8e  push rdx
00007f582cde0c8f  push rdi
00007f582cde0c90  push rsi
00007f582cde0c91  push r8
00007f582cde0c93  push r9
00007f582cde0c95  push r10
00007f582cde0c97  push r11
00007f582cde0c99  sub rsp, 0xF0
00007f582cde0ca0  vmovaps [rsp], xmm0
00007f582cde0ca5  vmovaps [rsp+0x10], xmm1
00007f582cde0cab  vmovaps [rsp+0x20], xmm2
00007f582cde0cb1  vmovaps [rsp+0x30], xmm3
00007f582cde0cb7  vmovaps [rsp+0x40], xmm4
00007f582cde0cbd  vmovaps [rsp+0x50], xmm5
00007f582cde0cc3  vmovaps [rsp+0x60], xmm6
00007f582cde0cc9  vmovaps [rsp+0x70], xmm7
00007f582cde0ccf  vmovaps [rsp+0x80], xmm8
00007f582cde0cd8  vmovaps [rsp+0x90], xmm9
00007f582cde0ce1  vmovaps [rsp+0xA0], xmm11
00007f582cde0cea  vmovaps [rsp+0xB0], xmm12
00007f582cde0cf3  vmovaps [rsp+0xC0], xmm13
00007f582cde0cfc  vmovaps [rsp+0xD0], xmm14
00007f582cde0d05  vmovaps [rsp+0xE0], xmm15
00007f582cde0d0e  sub rsp, 0x30
00007f582cde0d12  movaps [rsp], xmm10
00007f582cde0d17  movaps [rsp+0x10], xmm1
00007f582cde0d1c  movaps [rsp+0x20], xmm12
00007f582cde0d22  lea rdi, [rsp]
00007f582cde0d26  mov esi, 0x00
00007f582cde0d2b  mov rax, 0x653B0D9BF530
00007f582cde0d35  call rax
00007f582cde0d37  movaps xmm10, [rsp]
00007f582cde0d3c  add rsp, 0x30
00007f582cde0d40  vmovaps xmm0, [rsp]
00007f582cde0d45  vmovaps xmm1, [rsp+0x10]
00007f582cde0d4b  vmovaps xmm2, [rsp+0x20]
00007f582cde0d51  vmovaps xmm3, [rsp+0x30]
00007f582cde0d57  vmovaps xmm4, [rsp+0x40]
00007f582cde0d5d  vmovaps xmm5, [rsp+0x50]
00007f582cde0d63  vmovaps xmm6, [rsp+0x60]
00007f582cde0d69  vmovaps xmm7, [rsp+0x70]
00007f582cde0d6f  vmovaps xmm8, [rsp+0x80]
00007f582cde0d78  vmovaps xmm9, [rsp+0x90]
00007f582cde0d81  vmovaps xmm11, [rsp+0xA0]
00007f582cde0d8a  vmovaps xmm12, [rsp+0xB0]
00007f582cde0d93  vmovaps xmm13, [rsp+0xC0]
00007f582cde0d9c  vmovaps xmm14, [rsp+0xD0]
00007f582cde0da5  vmovaps xmm15, [rsp+0xE0]
00007f582cde0dae  add rsp, 0xF0
00007f582cde0db5  pop r11
00007f582cde0db7  pop r10
00007f582cde0db9  pop r9
00007f582cde0dbb  pop r8
00007f582cde0dbd  pop rsi
00007f582cde0dbe  pop rdi
00007f582cde0dbf  pop rdx
00007f582cde0dc0  pop rcx
00007f582cde0dc1  pop rax
00007f582cde0dc2  add rsp, 0x08
00007f582cde0dc6  jmp 0x00007F582CDDC6CD
00007f582cde0dcb  sub rsp, 0x08
00007f582cde0dcf  push rax
00007f582cde0dd0  push rcx
00007f582cde0dd1  push rdx
00007f582cde0dd2  push rdi
00007f582cde0dd3  push rsi
00007f582cde0dd4  push r8
00007f582cde0dd6  push r9
00007f582cde0dd8  push r10
00007f582cde0dda  push r11
00007f582cde0ddc  sub rsp, 0xF0
00007f582cde0de3  vmovaps [rsp], xmm0
00007f582cde0de8  vmovaps [rsp+0x10], xmm1
00007f582cde0dee  vmovaps [rsp+0x20], xmm2
00007f582cde0df4  vmovaps [rsp+0x30], xmm3
00007f582cde0dfa  vmovaps [rsp+0x40], xmm4
00007f582cde0e00  vmovaps [rsp+0x50], xmm5
00007f582cde0e06  vmovaps [rsp+0x60], xmm6
00007f582cde0e0c  vmovaps [rsp+0x70], xmm7
00007f582cde0e12  vmovaps [rsp+0x80], xmm8
00007f582cde0e1b  vmovaps [rsp+0x90], xmm9
00007f582cde0e24  vmovaps [rsp+0xA0], xmm10
00007f582cde0e2d  vmovaps [rsp+0xB0], xmm11
00007f582cde0e36  vmovaps [rsp+0xC0], xmm13
00007f582cde0e3f  vmovaps [rsp+0xD0], xmm14
00007f582cde0e48  vmovaps [rsp+0xE0], xmm15
00007f582cde0e51  sub rsp, 0x30
00007f582cde0e55  movaps [rsp], xmm12
00007f582cde0e5a  movaps [rsp+0x10], xmm14
00007f582cde0e60  movaps [rsp+0x20], xmm1
00007f582cde0e65  lea rdi, [rsp]
00007f582cde0e69  mov esi, 0x00
00007f582cde0e6e  mov rax, 0x653B0D9BF530
00007f582cde0e78  call rax
00007f582cde0e7a  movaps xmm12, [rsp]
00007f582cde0e7f  add rsp, 0x30
00007f582cde0e83  vmovaps xmm0, [rsp]
00007f582cde0e88  vmovaps xmm1, [rsp+0x10]
00007f582cde0e8e  vmovaps xmm2, [rsp+0x20]
00007f582cde0e94  vmovaps xmm3, [rsp+0x30]
00007f582cde0e9a  vmovaps xmm4, [rsp+0x40]
00007f582cde0ea0  vmovaps xmm5, [rsp+0x50]
00007f582cde0ea6  vmovaps xmm6, [rsp+0x60]
00007f582cde0eac  vmovaps xmm7, [rsp+0x70]
00007f582cde0eb2  vmovaps xmm8, [rsp+0x80]
00007f582cde0ebb  vmovaps xmm9, [rsp+0x90]
00007f582cde0ec4  vmovaps xmm10, [rsp+0xA0]
00007f582cde0ecd  vmovaps xmm11, [rsp+0xB0]
00007f582cde0ed6  vmovaps xmm13, [rsp+0xC0]
00007f582cde0edf  vmovaps xmm14, [rsp+0xD0]
00007f582cde0ee8  vmovaps xmm15, [rsp+0xE0]
00007f582cde0ef1  add rsp, 0xF0
00007f582cde0ef8  pop r11
00007f582cde0efa  pop r10
00007f582cde0efc  pop r9
00007f582cde0efe  pop r8
00007f582cde0f00  pop rsi
00007f582cde0f01  pop rdi
00007f582cde0f02  pop rdx
00007f582cde0f03  pop rcx
00007f582cde0f04  pop rax
00007f582cde0f05  add rsp, 0x08
00007f582cde0f09  jmp 0x00007F582CDDC6FC
00007f582cde0f0e  sub rsp, 0x08
00007f582cde0f12  push rax
00007f582cde0f13  push rcx
00007f582cde0f14  push rdx
00007f582cde0f15  push rdi
00007f582cde0f16  push rsi
00007f582cde0f17  push r8
00007f582cde0f19  push r9
00007f582cde0f1b  push r10
00007f582cde0f1d  push r11
00007f582cde0f1f  sub rsp, 0xF0
00007f582cde0f26  vmovaps [rsp], xmm0
00007f582cde0f2b  vmovaps [rsp+0x10], xmm1
00007f582cde0f31  vmovaps [rsp+0x20], xmm2
00007f582cde0f37  vmovaps [rsp+0x30], xmm3
00007f582cde0f3d  vmovaps [rsp+0x40], xmm4
00007f582cde0f43  vmovaps [rsp+0x50], xmm5
00007f582cde0f49  vmovaps [rsp+0x60], xmm6
00007f582cde0f4f  vmovaps [rsp+0x70], xmm7
00007f582cde0f55  vmovaps [rsp+0x80], xmm8
00007f582cde0f5e  vmovaps [rsp+0x90], xmm9
00007f582cde0f67  vmovaps [rsp+0xA0], xmm10
00007f582cde0f70  vmovaps [rsp+0xB0], xmm11
00007f582cde0f79  vmovaps [rsp+0xC0], xmm12
00007f582cde0f82  vmovaps [rsp+0xD0], xmm13
00007f582cde0f8b  vmovaps [rsp+0xE0], xmm15
00007f582cde0f94  sub rsp, 0x30
00007f582cde0f98  movaps [rsp], xmm14
00007f582cde0f9d  movaps [rsp+0x10], xmm9
00007f582cde0fa3  movaps [rsp+0x20], xmm1
00007f582cde0fa8  lea rdi, [rsp]
00007f582cde0fac  mov esi, 0x00
00007f582cde0fb1  mov rax, 0x653B0D9BF530
00007f582cde0fbb  call rax
00007f582cde0fbd  movaps xmm14, [rsp]
00007f582cde0fc2  add rsp, 0x30
00007f582cde0fc6  vmovaps xmm0, [rsp]
00007f582cde0fcb  vmovaps xmm1, [rsp+0x10]
00007f582cde0fd1  vmovaps xmm2, [rsp+0x20]
00007f582cde0fd7  vmovaps xmm3, [rsp+0x30]
00007f582cde0fdd  vmovaps xmm4, [rsp+0x40]
00007f582cde0fe3  vmovaps xmm5, [rsp+0x50]
00007f582cde0fe9  vmovaps xmm6, [rsp+0x60]
00007f582cde0fef  vmovaps xmm7, [rsp+0x70]
00007f582cde0ff5  vmovaps xmm8, [rsp+0x80]
00007f582cde0ffe  vmovaps xmm9, [rsp+0x90]
00007f582cde1007  vmovaps xmm10, [rsp+0xA0]
00007f582cde1010  vmovaps xmm11, [rsp+0xB0]
00007f582cde1019  vmovaps xmm12, [rsp+0xC0]
00007f582cde1022  vmovaps xmm13, [rsp+0xD0]
00007f582cde102b  vmovaps xmm15, [rsp+0xE0]
00007f582cde1034  add rsp, 0xF0
00007f582cde103b  pop r11
00007f582cde103d  pop r10
00007f582cde103f  pop r9
00007f582cde1041  pop r8
00007f582cde1043  pop rsi
00007f582cde1044  pop rdi
00007f582cde1045  pop rdx
00007f582cde1046  pop rcx
00007f582cde1047  pop rax
00007f582cde1048  add rsp, 0x08
00007f582cde104c  jmp 0x00007F582CDDC72B
00007f582cde1051  sub rsp, 0x08
00007f582cde1055  push rax
00007f582cde1056  push rcx
00007f582cde1057  push rdx
00007f582cde1058  push rdi
00007f582cde1059  push rsi
00007f582cde105a  push r8
00007f582cde105c  push r9
00007f582cde105e  push r10
00007f582cde1060  push r11
00007f582cde1062  sub rsp, 0xF0
00007f582cde1069  vmovaps [rsp], xmm0
00007f582cde106e  vmovaps [rsp+0x10], xmm2
00007f582cde1074  vmovaps [rsp+0x20], xmm3
00007f582cde107a  vmovaps [rsp+0x30], xmm4
00007f582cde1080  vmovaps [rsp+0x40], xmm5
00007f582cde1086  vmovaps [rsp+0x50], xmm6
00007f582cde108c  vmovaps [rsp+0x60], xmm7
00007f582cde1092  vmovaps [rsp+0x70], xmm8
00007f582cde1098  vmovaps [rsp+0x80], xmm9
00007f582cde10a1  vmovaps [rsp+0x90], xmm10
00007f582cde10aa  vmovaps [rsp+0xA0], xmm11
00007f582cde10b3  vmovaps [rsp+0xB0], xmm12
00007f582cde10bc  vmovaps [rsp+0xC0], xmm13
00007f582cde10c5  vmovaps [rsp+0xD0], xmm14
00007f582cde10ce  vmovaps [rsp+0xE0], xmm15
00007f582cde10d7  sub rsp, 0x30
00007f582cde10db  movaps [rsp], xmm1
00007f582cde10df  movaps [rsp+0x10], xmm13
00007f582cde10e5  movaps [rsp+0x20], xmm8
00007f582cde10eb  lea rdi, [rsp]
00007f582cde10ef  mov esi, 0x00
00007f582cde10f4  mov rax, 0x653B0D9BF530
00007f582cde10fe  call rax
00007f582cde1100  movaps xmm1, [rsp]
00007f582cde1104  add rsp, 0x30
00007f582cde1108  vmovaps xmm0, [rsp]
00007f582cde110d  vmovaps xmm2, [rsp+0x10]
00007f582cde1113  vmovaps xmm3, [rsp+0x20]
00007f582cde1119  vmovaps xmm4, [rsp+0x30]
00007f582cde111f  vmovaps xmm5, [rsp+0x40]
00007f582cde1125  vmovaps xmm6, [rsp+0x50]
00007f582cde112b  vmovaps xmm7, [rsp+0x60]
00007f582cde1131  vmovaps xmm8, [rsp+0x70]
00007f582cde1137  vmovaps xmm9, [rsp+0x80]
00007f582cde1140  vmovaps xmm10, [rsp+0x90]
00007f582cde1149  vmovaps xmm11, [rsp+0xA0]
00007f582cde1152  vmovaps xmm12, [rsp+0xB0]
00007f582cde115b  vmovaps xmm13, [rsp+0xC0]
00007f582cde1164  vmovaps xmm14, [rsp+0xD0]
00007f582cde116d  vmovaps xmm15, [rsp+0xE0]
00007f582cde1176  add rsp, 0xF0
00007f582cde117d  pop r11
00007f582cde117f  pop r10
00007f582cde1181  pop r9
00007f582cde1183  pop r8
00007f582cde1185  pop rsi
00007f582cde1186  pop rdi
00007f582cde1187  pop rdx
00007f582cde1188  pop rcx
00007f582cde1189  pop rax
00007f582cde118a  add rsp, 0x08
00007f582cde118e  jmp 0x00007F582CDDC74D
00007f582cde1193  call 0x00007F582CC0C260
00007f582cde1198  jmp 0x00007F582CDDC75B
00007f582cde119d  call 0x00007F582CCBD750
00007f582cde11a2  jmp 0x00007F582CDDC765
00007f582cde11a7  sub rsp, 0x08
00007f582cde11ab  push rax
00007f582cde11ac  push rcx
00007f582cde11ad  push rdx
00007f582cde11ae  push rdi
00007f582cde11af  push rsi
00007f582cde11b0  push r8
00007f582cde11b2  push r9
00007f582cde11b4  push r10
00007f582cde11b6  push r11
00007f582cde11b8  sub rsp, 0xF0
00007f582cde11bf  vmovaps [rsp], xmm0
00007f582cde11c4  vmovaps [rsp+0x10], xmm1
00007f582cde11ca  vmovaps [rsp+0x20], xmm2
00007f582cde11d0  vmovaps [rsp+0x30], xmm3
00007f582cde11d6  vmovaps [rsp+0x40], xmm4
00007f582cde11dc  vmovaps [rsp+0x50], xmm5
00007f582cde11e2  vmovaps [rsp+0x60], xmm6
00007f582cde11e8  vmovaps [rsp+0x70], xmm7
00007f582cde11ee  vmovaps [rsp+0x80], xmm9
00007f582cde11f7  vmovaps [rsp+0x90], xmm10
00007f582cde1200  vmovaps [rsp+0xA0], xmm11
00007f582cde1209  vmovaps [rsp+0xB0], xmm12
00007f582cde1212  vmovaps [rsp+0xC0], xmm13
00007f582cde121b  vmovaps [rsp+0xD0], xmm14
00007f582cde1224  vmovaps [rsp+0xE0], xmm15
00007f582cde122d  sub rsp, 0x30
00007f582cde1231  movaps [rsp], xmm8
00007f582cde1236  movaps [rsp+0x10], xmm15
00007f582cde123c  movaps [rsp+0x20], xmm7
00007f582cde1241  lea rdi, [rsp]
00007f582cde1245  mov esi, 0x00
00007f582cde124a  mov rax, 0x653B0D9BF530
00007f582cde1254  call rax
00007f582cde1256  movaps xmm8, [rsp]
00007f582cde125b  add rsp, 0x30
00007f582cde125f  vmovaps xmm0, [rsp]
00007f582cde1264  vmovaps xmm1, [rsp+0x10]
00007f582cde126a  vmovaps xmm2, [rsp+0x20]
00007f582cde1270  vmovaps xmm3, [rsp+0x30]
00007f582cde1276  vmovaps xmm4, [rsp+0x40]
00007f582cde127c  vmovaps xmm5, [rsp+0x50]
00007f582cde1282  vmovaps xmm6, [rsp+0x60]
00007f582cde1288  vmovaps xmm7, [rsp+0x70]
00007f582cde128e  vmovaps xmm9, [rsp+0x80]
00007f582cde1297  vmovaps xmm10, [rsp+0x90]
00007f582cde12a0  vmovaps xmm11, [rsp+0xA0]
00007f582cde12a9  vmovaps xmm12, [rsp+0xB0]
00007f582cde12b2  vmovaps xmm13, [rsp+0xC0]
00007f582cde12bb  vmovaps xmm14, [rsp+0xD0]
00007f582cde12c4  vmovaps xmm15, [rsp+0xE0]
00007f582cde12cd  add rsp, 0xF0
00007f582cde12d4  pop r11
00007f582cde12d6  pop r10
00007f582cde12d8  pop r9
00007f582cde12da  pop r8
00007f582cde12dc  pop rsi
00007f582cde12dd  pop rdi
00007f582cde12de  pop rdx
00007f582cde12df  pop rcx
00007f582cde12e0  pop rax
00007f582cde12e1  add rsp, 0x08
00007f582cde12e5  jmp 0x00007F582CDDC787
00007f582cde12ea  sub rsp, 0x08
00007f582cde12ee  push rax
00007f582cde12ef  push rcx
00007f582cde12f0  push rdx
00007f582cde12f1  push rdi
00007f582cde12f2  push rsi
00007f582cde12f3  push r8
00007f582cde12f5  push r9
00007f582cde12f7  push r10
00007f582cde12f9  push r11
00007f582cde12fb  sub rsp, 0xF0
00007f582cde1302  vmovaps [rsp], xmm0
00007f582cde1307  vmovaps [rsp+0x10], xmm1
00007f582cde130d  vmovaps [rsp+0x20], xmm2
00007f582cde1313  vmovaps [rsp+0x30], xmm3
00007f582cde1319  vmovaps [rsp+0x40], xmm4
00007f582cde131f  vmovaps [rsp+0x50], xmm5
00007f582cde1325  vmovaps [rsp+0x60], xmm6
00007f582cde132b  vmovaps [rsp+0x70], xmm8
00007f582cde1331  vmovaps [rsp+0x80], xmm9
00007f582cde133a  vmovaps [rsp+0x90], xmm10
00007f582cde1343  vmovaps [rsp+0xA0], xmm11
00007f582cde134c  vmovaps [rsp+0xB0], xmm12
00007f582cde1355  vmovaps [rsp+0xC0], xmm13
00007f582cde135e  vmovaps [rsp+0xD0], xmm14
00007f582cde1367  vmovaps [rsp+0xE0], xmm15
00007f582cde1370  sub rsp, 0x30
00007f582cde1374  movaps [rsp], xmm7
00007f582cde1378  movaps [rsp+0x10], xmm9
00007f582cde137e  movaps [rsp+0x20], xmm15
00007f582cde1384  lea rdi, [rsp]
00007f582cde1388  mov esi, 0x00
00007f582cde138d  mov rax, 0x653B0D9BF530
00007f582cde1397  call rax
00007f582cde1399  movaps xmm7, [rsp]
00007f582cde139d  add rsp, 0x30
00007f582cde13a1  vmovaps xmm0, [rsp]
00007f582cde13a6  vmovaps xmm1, [rsp+0x10]
00007f582cde13ac  vmovaps xmm2, [rsp+0x20]
00007f582cde13b2  vmovaps xmm3, [rsp+0x30]
00007f582cde13b8  vmovaps xmm4, [rsp+0x40]
00007f582cde13be  vmovaps xmm5, [rsp+0x50]
00007f582cde13c4  vmovaps xmm6, [rsp+0x60]
00007f582cde13ca  vmovaps xmm8, [rsp+0x70]
00007f582cde13d0  vmovaps xmm9, [rsp+0x80]
00007f582cde13d9  vmovaps xmm10, [rsp+0x90]
00007f582cde13e2  vmovaps xmm11, [rsp+0xA0]
00007f582cde13eb  vmovaps xmm12, [rsp+0xB0]
00007f582cde13f4  vmovaps xmm13, [rsp+0xC0]
00007f582cde13fd  vmovaps xmm14, [rsp+0xD0]
00007f582cde1406  vmovaps xmm15, [rsp+0xE0]
00007f582cde140f  add rsp, 0xF0
00007f582cde1416  pop r11
00007f582cde1418  pop r10
00007f582cde141a  pop r9
00007f582cde141c  pop r8
00007f582cde141e  pop rsi
00007f582cde141f  pop rdi
00007f582cde1420  pop rdx
00007f582cde1421  pop rcx
00007f582cde1422  pop rax
00007f582cde1423  add rsp, 0x08
00007f582cde1427  jmp 0x00007F582CDDC7B4
00007f582cde142c  sub rsp, 0x08
00007f582cde1430  push rax
00007f582cde1431  push rcx
00007f582cde1432  push rdx
00007f582cde1433  push rdi
00007f582cde1434  push rsi
00007f582cde1435  push r8
00007f582cde1437  push r9
00007f582cde1439  push r10
00007f582cde143b  push r11
00007f582cde143d  sub rsp, 0xF0
00007f582cde1444  vmovaps [rsp], xmm0
00007f582cde1449  vmovaps [rsp+0x10], xmm1
00007f582cde144f  vmovaps [rsp+0x20], xmm2
00007f582cde1455  vmovaps [rsp+0x30], xmm3
00007f582cde145b  vmovaps [rsp+0x40], xmm4
00007f582cde1461  vmovaps [rsp+0x50], xmm5
00007f582cde1467  vmovaps [rsp+0x60], xmm6
00007f582cde146d  vmovaps [rsp+0x70], xmm7
00007f582cde1473  vmovaps [rsp+0x80], xmm8
00007f582cde147c  vmovaps [rsp+0x90], xmm10
00007f582cde1485  vmovaps [rsp+0xA0], xmm11
00007f582cde148e  vmovaps [rsp+0xB0], xmm12
00007f582cde1497  vmovaps [rsp+0xC0], xmm13
00007f582cde14a0  vmovaps [rsp+0xD0], xmm14
00007f582cde14a9  vmovaps [rsp+0xE0], xmm15
00007f582cde14b2  sub rsp, 0x30
00007f582cde14b6  movaps [rsp], xmm9
00007f582cde14bb  movaps [rsp+0x10], xmm13
00007f582cde14c1  movaps [rsp+0x20], xmm15
00007f582cde14c7  lea rdi, [rsp]
00007f582cde14cb  mov esi, 0x00
00007f582cde14d0  mov rax, 0x653B0D9BF530
00007f582cde14da  call rax
00007f582cde14dc  movaps xmm9, [rsp]
00007f582cde14e1  add rsp, 0x30
00007f582cde14e5  vmovaps xmm0, [rsp]
00007f582cde14ea  vmovaps xmm1, [rsp+0x10]
00007f582cde14f0  vmovaps xmm2, [rsp+0x20]
00007f582cde14f6  vmovaps xmm3, [rsp+0x30]
00007f582cde14fc  vmovaps xmm4, [rsp+0x40]
00007f582cde1502  vmovaps xmm5, [rsp+0x50]
00007f582cde1508  vmovaps xmm6, [rsp+0x60]
00007f582cde150e  vmovaps xmm7, [rsp+0x70]
00007f582cde1514  vmovaps xmm8, [rsp+0x80]
00007f582cde151d  vmovaps xmm10, [rsp+0x90]
00007f582cde1526  vmovaps xmm11, [rsp+0xA0]
00007f582cde152f  vmovaps xmm12, [rsp+0xB0]
00007f582cde1538  vmovaps xmm13, [rsp+0xC0]
00007f582cde1541  vmovaps xmm14, [rsp+0xD0]
00007f582cde154a  vmovaps xmm15, [rsp+0xE0]
00007f582cde1553  add rsp, 0xF0
00007f582cde155a  pop r11
00007f582cde155c  pop r10
00007f582cde155e  pop r9
00007f582cde1560  pop r8
00007f582cde1562  pop rsi
00007f582cde1563  pop rdi
00007f582cde1564  pop rdx
00007f582cde1565  pop rcx
00007f582cde1566  pop rax
00007f582cde1567  add rsp, 0x08
00007f582cde156b  jmp 0x00007F582CDDC7E2
00007f582cde1570  sub rsp, 0x08
00007f582cde1574  push rax
00007f582cde1575  push rcx
00007f582cde1576  push rdx
00007f582cde1577  push rdi
00007f582cde1578  push rsi
00007f582cde1579  push r8
00007f582cde157b  push r9
00007f582cde157d  push r10
00007f582cde157f  push r11
00007f582cde1581  sub rsp, 0xF0
00007f582cde1588  vmovaps [rsp], xmm0
00007f582cde158d  vmovaps [rsp+0x10], xmm1
00007f582cde1593  vmovaps [rsp+0x20], xmm2
00007f582cde1599  vmovaps [rsp+0x30], xmm3
00007f582cde159f  vmovaps [rsp+0x40], xmm4
00007f582cde15a5  vmovaps [rsp+0x50], xmm5
00007f582cde15ab  vmovaps [rsp+0x60], xmm6
00007f582cde15b1  vmovaps [rsp+0x70], xmm7
00007f582cde15b7  vmovaps [rsp+0x80], xmm8
00007f582cde15c0  vmovaps [rsp+0x90], xmm9
00007f582cde15c9  vmovaps [rsp+0xA0], xmm10
00007f582cde15d2  vmovaps [rsp+0xB0], xmm11
00007f582cde15db  vmovaps [rsp+0xC0], xmm12
00007f582cde15e4  vmovaps [rsp+0xD0], xmm13
00007f582cde15ed  vmovaps [rsp+0xE0], xmm14
00007f582cde15f6  sub rsp, 0x30
00007f582cde15fa  movaps [rsp], xmm15
00007f582cde15ff  movaps [rsp+0x10], xmm11
00007f582cde1605  movaps [rsp+0x20], xmm12
00007f582cde160b  lea rdi, [rsp]
00007f582cde160f  mov esi, 0x00
00007f582cde1614  mov rax, 0x653B0D9BF530
00007f582cde161e  call rax
00007f582cde1620  movaps xmm15, [rsp]
00007f582cde1625  add rsp, 0x30
00007f582cde1629  vmovaps xmm0, [rsp]
00007f582cde162e  vmovaps xmm1, [rsp+0x10]
00007f582cde1634  vmovaps xmm2, [rsp+0x20]
00007f582cde163a  vmovaps xmm3, [rsp+0x30]
00007f582cde1640  vmovaps xmm4, [rsp+0x40]
00007f582cde1646  vmovaps xmm5, [rsp+0x50]
00007f582cde164c  vmovaps xmm6, [rsp+0x60]
00007f582cde1652  vmovaps xmm7, [rsp+0x70]
00007f582cde1658  vmovaps xmm8, [rsp+0x80]
00007f582cde1661  vmovaps xmm9, [rsp+0x90]
00007f582cde166a  vmovaps xmm10, [rsp+0xA0]
00007f582cde1673  vmovaps xmm11, [rsp+0xB0]
00007f582cde167c  vmovaps xmm12, [rsp+0xC0]
00007f582cde1685  vmovaps xmm13, [rsp+0xD0]
00007f582cde168e  vmovaps xmm14, [rsp+0xE0]
00007f582cde1697  add rsp, 0xF0
00007f582cde169e  pop r11
00007f582cde16a0  pop r10
00007f582cde16a2  pop r9
00007f582cde16a4  pop r8
00007f582cde16a6  pop rsi
00007f582cde16a7  pop rdi
00007f582cde16a8  pop rdx
00007f582cde16a9  pop rcx
00007f582cde16aa  pop rax
00007f582cde16ab  add rsp, 0x08
00007f582cde16af  jmp 0x00007F582CDDC7FD
00007f582cde16b4  sub rsp, 0x08
00007f582cde16b8  push rax
00007f582cde16b9  push rcx
00007f582cde16ba  push rdx
00007f582cde16bb  push rdi
00007f582cde16bc  push rsi
00007f582cde16bd  push r8
00007f582cde16bf  push r9
00007f582cde16c1  push r10
00007f582cde16c3  push r11
00007f582cde16c5  sub rsp, 0xF0
00007f582cde16cc  vmovaps [rsp], xmm0
00007f582cde16d1  vmovaps [rsp+0x10], xmm1
00007f582cde16d7  vmovaps [rsp+0x20], xmm2
00007f582cde16dd  vmovaps [rsp+0x30], xmm3
00007f582cde16e3  vmovaps [rsp+0x40], xmm4
00007f582cde16e9  vmovaps [rsp+0x50], xmm5
00007f582cde16ef  vmovaps [rsp+0x60], xmm6
00007f582cde16f5  vmovaps [rsp+0x70], xmm7
00007f582cde16fb  vmovaps [rsp+0x80], xmm8
00007f582cde1704  vmovaps [rsp+0x90], xmm9
00007f582cde170d  vmovaps [rsp+0xA0], xmm10
00007f582cde1716  vmovaps [rsp+0xB0], xmm11
00007f582cde171f  vmovaps [rsp+0xC0], xmm12
00007f582cde1728  vmovaps [rsp+0xD0], xmm14
00007f582cde1731  vmovaps [rsp+0xE0], xmm15
00007f582cde173a  sub rsp, 0x30
00007f582cde173e  movaps [rsp], xmm13
00007f582cde1743  movaps [rsp+0x10], xmm10
00007f582cde1749  movaps [rsp+0x20], xmm14
00007f582cde174f  lea rdi, [rsp]
00007f582cde1753  mov esi, 0x00
00007f582cde1758  mov rax, 0x653B0D9BF530
00007f582cde1762  call rax
00007f582cde1764  movaps xmm13, [rsp]
00007f582cde1769  add rsp, 0x30
00007f582cde176d  vmovaps xmm0, [rsp]
00007f582cde1772  vmovaps xmm1, [rsp+0x10]
00007f582cde1778  vmovaps xmm2, [rsp+0x20]
00007f582cde177e  vmovaps xmm3, [rsp+0x30]
00007f582cde1784  vmovaps xmm4, [rsp+0x40]
00007f582cde178a  vmovaps xmm5, [rsp+0x50]
00007f582cde1790  vmovaps xmm6, [rsp+0x60]
00007f582cde1796  vmovaps xmm7, [rsp+0x70]
00007f582cde179c  vmovaps xmm8, [rsp+0x80]
00007f582cde17a5  vmovaps xmm9, [rsp+0x90]
00007f582cde17ae  vmovaps xmm10, [rsp+0xA0]
00007f582cde17b7  vmovaps xmm11, [rsp+0xB0]
00007f582cde17c0  vmovaps xmm12, [rsp+0xC0]
00007f582cde17c9  vmovaps xmm14, [rsp+0xD0]
00007f582cde17d2  vmovaps xmm15, [rsp+0xE0]
00007f582cde17db  add rsp, 0xF0
00007f582cde17e2  pop r11
00007f582cde17e4  pop r10
00007f582cde17e6  pop r9
00007f582cde17e8  pop r8
00007f582cde17ea  pop rsi
00007f582cde17eb  pop rdi
00007f582cde17ec  pop rdx
00007f582cde17ed  pop rcx
00007f582cde17ee  pop rax
00007f582cde17ef  add rsp, 0x08
00007f582cde17f3  jmp 0x00007F582CDDC820
00007f582cde17f8  sub rsp, 0x08
00007f582cde17fc  push rax
00007f582cde17fd  push rcx
00007f582cde17fe  push rdx
00007f582cde17ff  push rdi
00007f582cde1800  push rsi
00007f582cde1801  push r8
00007f582cde1803  push r9
00007f582cde1805  push r10
00007f582cde1807  push r11
00007f582cde1809  sub rsp, 0xF0
00007f582cde1810  vmovaps [rsp], xmm0
00007f582cde1815  vmovaps [rsp+0x10], xmm1
00007f582cde181b  vmovaps [rsp+0x20], xmm2
00007f582cde1821  vmovaps [rsp+0x30], xmm3
00007f582cde1827  vmovaps [rsp+0x40], xmm4
00007f582cde182d  vmovaps [rsp+0x50], xmm5
00007f582cde1833  vmovaps [rsp+0x60], xmm6
00007f582cde1839  vmovaps [rsp+0x70], xmm7
00007f582cde183f  vmovaps [rsp+0x80], xmm8
00007f582cde1848  vmovaps [rsp+0x90], xmm9
00007f582cde1851  vmovaps [rsp+0xA0], xmm10
00007f582cde185a  vmovaps [rsp+0xB0], xmm11
00007f582cde1863  vmovaps [rsp+0xC0], xmm12
00007f582cde186c  vmovaps [rsp+0xD0], xmm13
00007f582cde1875  vmovaps [rsp+0xE0], xmm15
00007f582cde187e  sub rsp, 0x30
00007f582cde1882  movaps [rsp], xmm14
00007f582cde1887  movaps [rsp+0x10], xmm1
00007f582cde188c  movaps [rsp+0x20], xmm7
00007f582cde1891  lea rdi, [rsp]
00007f582cde1895  mov esi, 0x00
00007f582cde189a  mov rax, 0x653B0D9BF530
00007f582cde18a4  call rax
00007f582cde18a6  movaps xmm14, [rsp]
00007f582cde18ab  add rsp, 0x30
00007f582cde18af  vmovaps xmm0, [rsp]
00007f582cde18b4  vmovaps xmm1, [rsp+0x10]
00007f582cde18ba  vmovaps xmm2, [rsp+0x20]
00007f582cde18c0  vmovaps xmm3, [rsp+0x30]
00007f582cde18c6  vmovaps xmm4, [rsp+0x40]
00007f582cde18cc  vmovaps xmm5, [rsp+0x50]
00007f582cde18d2  vmovaps xmm6, [rsp+0x60]
00007f582cde18d8  vmovaps xmm7, [rsp+0x70]
00007f582cde18de  vmovaps xmm8, [rsp+0x80]
00007f582cde18e7  vmovaps xmm9, [rsp+0x90]
00007f582cde18f0  vmovaps xmm10, [rsp+0xA0]
00007f582cde18f9  vmovaps xmm11, [rsp+0xB0]
00007f582cde1902  vmovaps xmm12, [rsp+0xC0]
00007f582cde190b  vmovaps xmm13, [rsp+0xD0]
00007f582cde1914  vmovaps xmm15, [rsp+0xE0]
00007f582cde191d  add rsp, 0xF0
00007f582cde1924  pop r11
00007f582cde1926  pop r10
00007f582cde1928  pop r9
00007f582cde192a  pop r8
00007f582cde192c  pop rsi
00007f582cde192d  pop rdi
00007f582cde192e  pop rdx
00007f582cde192f  pop rcx
00007f582cde1930  pop rax
00007f582cde1931  add rsp, 0x08
00007f582cde1935  jmp 0x00007F582CDDC843
00007f582cde193a  sub rsp, 0x08
00007f582cde193e  push rax
00007f582cde193f  push rcx
00007f582cde1940  push rdx
00007f582cde1941  push rdi
00007f582cde1942  push rsi
00007f582cde1943  push r8
00007f582cde1945  push r9
00007f582cde1947  push r10
00007f582cde1949  push r11
00007f582cde194b  sub rsp, 0xF0
00007f582cde1952  vmovaps [rsp], xmm0
00007f582cde1957  vmovaps [rsp+0x10], xmm2
00007f582cde195d  vmovaps [rsp+0x20], xmm3
00007f582cde1963  vmovaps [rsp+0x30], xmm4
00007f582cde1969  vmovaps [rsp+0x40], xmm5
00007f582cde196f  vmovaps [rsp+0x50], xmm6
00007f582cde1975  vmovaps [rsp+0x60], xmm7
00007f582cde197b  vmovaps [rsp+0x70], xmm8
00007f582cde1981  vmovaps [rsp+0x80], xmm9
00007f582cde198a  vmovaps [rsp+0x90], xmm10
00007f582cde1993  vmovaps [rsp+0xA0], xmm11
00007f582cde199c  vmovaps [rsp+0xB0], xmm12
00007f582cde19a5  vmovaps [rsp+0xC0], xmm13
00007f582cde19ae  vmovaps [rsp+0xD0], xmm14
00007f582cde19b7  vmovaps [rsp+0xE0], xmm15
00007f582cde19c0  sub rsp, 0x30
00007f582cde19c4  movaps [rsp], xmm1
00007f582cde19c8  movaps [rsp+0x10], xmm8
00007f582cde19ce  movaps [rsp+0x20], xmm9
00007f582cde19d4  lea rdi, [rsp]
00007f582cde19d8  mov esi, 0x00
00007f582cde19dd  mov rax, 0x653B0D9BF530
00007f582cde19e7  call rax
00007f582cde19e9  movaps xmm1, [rsp]
00007f582cde19ed  add rsp, 0x30
00007f582cde19f1  vmovaps xmm0, [rsp]
00007f582cde19f6  vmovaps xmm2, [rsp+0x10]
00007f582cde19fc  vmovaps xmm3, [rsp+0x20]
00007f582cde1a02  vmovaps xmm4, [rsp+0x30]
00007f582cde1a08  vmovaps xmm5, [rsp+0x40]
00007f582cde1a0e  vmovaps xmm6, [rsp+0x50]
00007f582cde1a14  vmovaps xmm7, [rsp+0x60]
00007f582cde1a1a  vmovaps xmm8, [rsp+0x70]
00007f582cde1a20  vmovaps xmm9, [rsp+0x80]
00007f582cde1a29  vmovaps xmm10, [rsp+0x90]
00007f582cde1a32  vmovaps xmm11, [rsp+0xA0]
00007f582cde1a3b  vmovaps xmm12, [rsp+0xB0]
00007f582cde1a44  vmovaps xmm13, [rsp+0xC0]
00007f582cde1a4d  vmovaps xmm14, [rsp+0xD0]
00007f582cde1a56  vmovaps xmm15, [rsp+0xE0]
00007f582cde1a5f  add rsp, 0xF0
00007f582cde1a66  pop r11
00007f582cde1a68  pop r10
00007f582cde1a6a  pop r9
00007f582cde1a6c  pop r8
00007f582cde1a6e  pop rsi
00007f582cde1a6f  pop rdi
00007f582cde1a70  pop rdx
00007f582cde1a71  pop rcx
00007f582cde1a72  pop rax
00007f582cde1a73  add rsp, 0x08
00007f582cde1a77  jmp 0x00007F582CDDC865
00007f582cde1a7c  call 0x00007F582CCE5940
00007f582cde1a81  jmp 0x00007F582CDDC873
00007f582cde1a86  call 0x00007F582CC0C380
00007f582cde1a8b  jmp 0x00007F582CDDC87D
00007f582cde1a90  call 0x00007F582CC0D600
00007f582cde1a95  jmp 0x00007F582CDDC887
00007f582cde1a9a  call 0x00007F582CBFF540
00007f582cde1a9f  jmp 0x00007F582CDDC891
00007f582cde1aa4  int3
00007f582cde1aa5  nop [rax+rax*1], ax
00007f582cde1aae  nop
00007f582cde1ab0  mov rax, [r15+0xF8]
00007f582cde1ab7  lea r14, [rax+0x140]
00007f582cde1abe  mov r12, [r13+r14*1]
00007f582cde1ac3  mov [r15+0xE8], r12
00007f582cde1aca  lea r14, [rax+0x130]
00007f582cde1ad1  mov r12, [r13+r14*1]
00007f582cde1ad6  lea r14, [rax+0x138]
00007f582cde1add  mov r11, [r13+r14*1]
00007f582cde1ae2  movq xmm1, r12
00007f582cde1ae7  movq xmm15, r11
00007f582cde1aec  movq xmm1, xmm1
00007f582cde1af0  movq xmm1, xmm1
00007f582cde1af4  movaps [r15+0x1A0], xmm1
00007f582cde1afc  movq xmm15, xmm15
00007f582cde1b01  movq xmm15, xmm15
00007f582cde1b06  movaps [r15+0x190], xmm15
00007f582cde1b0e  lea r14, [rax+0x120]
00007f582cde1b15  mov r12, [r13+r14*1]
00007f582cde1b1a  lea r14, [rax+0x128]
00007f582cde1b21  mov r11, [r13+r14*1]
00007f582cde1b26  movq xmm1, r12
00007f582cde1b2b  movq xmm15, r11
00007f582cde1b30  movq xmm1, xmm1
00007f582cde1b34  movq xmm1, xmm1
00007f582cde1b38  movaps [r15+0x1C0], xmm1
00007f582cde1b40  movq xmm15, xmm15
00007f582cde1b45  movq xmm15, xmm15
00007f582cde1b4a  movaps [r15+0x1B0], xmm15
00007f582cde1b52  lea r14, [rax+0x110]
00007f582cde1b59  mov r12, [r13+r14*1]
00007f582cde1b5e  lea r14, [rax+0x118]
00007f582cde1b65  mov r11, [r13+r14*1]
00007f582cde1b6a  movq xmm1, r12
00007f582cde1b6f  movq xmm15, r11
00007f582cde1b74  movq xmm1, xmm1
00007f582cde1b78  movq xmm1, xmm1
00007f582cde1b7c  movaps [r15+0x1E0], xmm1
00007f582cde1b84  movq xmm15, xmm15
00007f582cde1b89  movq xmm15, xmm15
00007f582cde1b8e  movaps [r15+0x1D0], xmm15
00007f582cde1b96  lea r14, [rax+0x100]
00007f582cde1b9d  mov r12, [r13+r14*1]
00007f582cde1ba2  lea r14, [rax+0x108]
00007f582cde1ba9  mov r11, [r13+r14*1]
00007f582cde1bae  movq xmm1, r12
00007f582cde1bb3  movq xmm15, r11
00007f582cde1bb8  movq xmm1, xmm1
00007f582cde1bbc  movq xmm1, xmm1
00007f582cde1bc0  movaps [r15+0x200], xmm1
00007f582cde1bc8  movq xmm15, xmm15
00007f582cde1bcd  movq xmm15, xmm15
00007f582cde1bd2  movaps [r15+0x1F0], xmm15
00007f582cde1bda  mov qword ptr [r15+0x40], 0x430000
00007f582cde1be2  mov r14d, 0x430510
00007f582cde1be8  mov r12, [r13+r14*1]
00007f582cde1bed  movq xmm1, r12
00007f582cde1bf2  lea r14, [rax+0x150]
00007f582cde1bf9  mov [r15+0xF8], r14
00007f582cde1c00  mov rax, [r15+0x50]
00007f582cde1c04  movups xmm15, [r13+rax*1]
00007f582cde1c0a  movaps [r15+0x120], xmm15
00007f582cde1c12  mov qword ptr [r15+0x48], 0x10
00007f582cde1c1a  xor eax, eax
00007f582cde1c1c  mov r14d, 0x10
00007f582cde1c22  mov r12d, 0x200
00007f582cde1c28  cmp r14, r12
00007f582cde1c2b  cmc
00007f582cde1c2c  lahf
00007f582cde1c2d  seto al
00007f582cde1c30  mov [r15+0x108], eax
00007f582cde1c37  pextrq rax, xmm15, 0x01
00007f582cde1c3e  movq xmm14, rax
00007f582cde1c43  movaps [r15+0x130], xmm14
00007f582cde1c4b  movq rax, xmm1
00007f582cde1c50  movq r14, xmm15
00007f582cde1c55  vmovq xmm1, rax
00007f582cde1c5a  vmovq xmm15, r14
00007f582cde1c5f  movaps xmm13, xmm1
00007f582cde1c63  addsd xmm13, xmm15
00007f582cde1c68  ucomisd xmm13, xmm13
00007f582cde1c6d  jp 0x00007F582CDE1D86
00007f582cde1c73  movq xmm13, xmm13
00007f582cde1c78  movq rax, xmm13
00007f582cde1c7d  movq r14, xmm14
00007f582cde1c82  vmovq xmm1, rax
00007f582cde1c87  vmovq xmm15, r14
00007f582cde1c8c  movaps xmm14, xmm1
00007f582cde1c90  addsd xmm14, xmm15
00007f582cde1c95  ucomisd xmm14, xmm14
00007f582cde1c9a  jp 0x00007F582CDE1DCE
00007f582cde1ca0  movq xmm14, xmm14
00007f582cde1ca5  movaps [r15+0x110], xmm14
00007f582cde1cad  mov eax, [r15+0x108]
00007f582cde1cb4  sahf
00007f582cde1cb5  jnz 0x00007F582CDE1CE7
00007f582cde1cb7  cmp dword ptr [r15+0x318], 0x00
00007f582cde1cbf  jz 0x00007F582CDE1FE0
00007f582cde1cc5  nop [rax+rax*1], ax
00007f582cde1cce  nop [rax+rax*1], eax
00007f582cde1cd6  mov eax, 0x410490
00007f582cde1cdb  mov [r15+0x100], rax
00007f582cde1ce2  jmp 0x00007F582CBFE110
00007f582cde1ce7  cmp dword ptr [r15+0x318], 0x00
00007f582cde1cef  jz 0x00007F582CDE1E20
00007f582cde1cf5  nop [rax+rax*1], ax
00007f582cde1cfe  nop [rax+rax*1], eax
00007f582cde1d06  mov eax, 0x410474
00007f582cde1d0b  mov [r15+0x100], rax
00007f582cde1d12  jmp 0x00007F582CBFE110
00007f582cde1d17  int3
00007f582cde1d18  call 0x00007F582CCE27E0
00007f582cde1d1d  jmp 0x00007F582CDE1AC3
00007f582cde1d22  call 0x00007F582CCE27E0
00007f582cde1d27  jmp 0x00007F582CDE1AD6
00007f582cde1d2c  call 0x00007F582CCE1570
00007f582cde1d31  jmp 0x00007F582CDE1AE2
00007f582cde1d36  call 0x00007F582CCE27E0
00007f582cde1d3b  jmp 0x00007F582CDE1B1A
00007f582cde1d40  call 0x00007F582CCE1570
00007f582cde1d45  jmp 0x00007F582CDE1B26
00007f582cde1d4a  call 0x00007F582CCE27E0
00007f582cde1d4f  jmp 0x00007F582CDE1B5E
00007f582cde1d54  call 0x00007F582CCE1570
00007f582cde1d59  jmp 0x00007F582CDE1B6A
00007f582cde1d5e  call 0x00007F582CCE27E0
00007f582cde1d63  jmp 0x00007F582CDE1BA2
00007f582cde1d68  call 0x00007F582CCE1570
00007f582cde1d6d  jmp 0x00007F582CDE1BAE
00007f582cde1d72  call 0x00007F582CCE27E0
00007f582cde1d77  jmp 0x00007F582CDE1BED
00007f582cde1d7c  call 0x00007F582CC0E760
00007f582cde1d81  jmp 0x00007F582CDE1C0A
00007f582cde1d86  ucomisd xmm1, xmm15
00007f582cde1d8b  jp 0x00007F582CDE1D9A
00007f582cde1d8d  movaps xmm13, [0x00007F582C9FE060]
00007f582cde1d95  jmp 0x00007F582CDE1C73
00007f582cde1d9a  vxorps xmm0, xmm1, xmm15
00007f582cde1d9f  pextrw eax, xmm0, 0x03
00007f582cde1da4  and eax, 0x7FF8
00007f582cde1da9  cmp eax, 0x08
00007f582cde1dac  jnz 0x00007F582CDE1C73
00007f582cde1db2  movq rax, xmm15
00007f582cde1db7  shl rax, 0x0D
00007f582cde1dbb  jbe 0x00007F582CDE1C73
00007f582cde1dc1  vorps xmm13, xmm15, [0x00007F582C9FE070]
00007f582cde1dc9  jmp 0x00007F582CDE1C73
00007f582cde1dce  ucomisd xmm1, xmm15
00007f582cde1dd3  jp 0x00007F582CDE1DE2
00007f582cde1dd5  movaps xmm14, [0x00007F582C9FE060]
00007f582cde1ddd  jmp 0x00007F582CDE1CA0
00007f582cde1de2  vxorps xmm0, xmm1, xmm15
00007f582cde1de7  pextrw eax, xmm0, 0x03
00007f582cde1dec  and eax, 0x7FF8
00007f582cde1df1  cmp eax, 0x08
00007f582cde1df4  jnz 0x00007F582CDE1CA0
00007f582cde1dfa  movq rax, xmm15
00007f582cde1dff  shl rax, 0x0D
00007f582cde1e03  jbe 0x00007F582CDE1CA0
00007f582cde1e09  vorps xmm14, xmm15, [0x00007F582C9FE070]
00007f582cde1e11  jmp 0x00007F582CDE1CA0
00007f582cde1e16  int3
00007f582cde1e17  nop [rax+rax*1], ax
00007f582cde1e20  mov rax, [r15+0x48]
00007f582cde1e24  mov r14, [r15+0x50]
00007f582cde1e28  lea r12, [r14+rax*1]
00007f582cde1e2c  movups xmm1, [r13+r12*1]
00007f582cde1e32  movaps [r15+0x120], xmm1
00007f582cde1e3a  lea r14, [rax+0x10]
00007f582cde1e3e  mov [r15+0x48], r14
00007f582cde1e42  xor eax, eax
00007f582cde1e44  mov r12d, 0x200
00007f582cde1e4a  cmp r14, r12
00007f582cde1e4d  cmc
00007f582cde1e4e  lahf
00007f582cde1e4f  seto al
00007f582cde1e52  mov [r15+0x108], eax
00007f582cde1e59  pextrq rax, xmm1, 0x01
00007f582cde1e60  movq xmm15, rax
00007f582cde1e65  movaps [r15+0x130], xmm15
00007f582cde1e6d  movaps xmm14, [r15+0x110]
00007f582cde1e75  movq rax, xmm14
00007f582cde1e7a  movq r14, xmm1
00007f582cde1e7f  vmovq xmm1, rax
00007f582cde1e84  vmovq xmm14, r14
00007f582cde1e89  movaps xmm13, xmm1
00007f582cde1e8d  addsd xmm13, xmm14
00007f582cde1e92  ucomisd xmm13, xmm13
00007f582cde1e97  jp 0x00007F582CDE1F4C
00007f582cde1e9d  movq xmm13, xmm13
00007f582cde1ea2  movq rax, xmm13
00007f582cde1ea7  movq r14, xmm15
00007f582cde1eac  vmovq xmm1, rax
00007f582cde1eb1  vmovq xmm15, r14
00007f582cde1eb6  movaps xmm14, xmm1
00007f582cde1eba  addsd xmm14, xmm15
00007f582cde1ebf  ucomisd xmm14, xmm14
00007f582cde1ec4  jp 0x00007F582CDE1F94
00007f582cde1eca  movq xmm14, xmm14
00007f582cde1ecf  movaps [r15+0x110], xmm14
00007f582cde1ed7  mov eax, [r15+0x108]
00007f582cde1ede  sahf
00007f582cde1edf  jnz 0x00007F582CDE1F11
00007f582cde1ee1  cmp dword ptr [r15+0x318], 0x00
00007f582cde1ee9  jz 0x00007F582CDE1FE0
00007f582cde1eef  nop [rax+rax*1], ax
00007f582cde1ef8  nop [rax+rax*1], eax
00007f582cde1f00  mov eax, 0x410490
00007f582cde1f05  mov [r15+0x100], rax
00007f582cde1f0c  jmp 0x00007F582CBFE110
00007f582cde1f11  cmp dword ptr [r15+0x318], 0x00
00007f582cde1f19  jz 0x00007F582CDE1E20
00007f582cde1f1f  nop [rax+rax*1], ax
00007f582cde1f28  nop [rax+rax*1], eax
00007f582cde1f30  mov eax, 0x410474
00007f582cde1f35  mov [r15+0x100], rax
00007f582cde1f3c  jmp 0x00007F582CBFE110
00007f582cde1f41  int3
00007f582cde1f42  call 0x00007F582CCB52F0
00007f582cde1f47  jmp 0x00007F582CDE1E32
00007f582cde1f4c  ucomisd xmm1, xmm14
00007f582cde1f51  jp 0x00007F582CDE1F60
00007f582cde1f53  movaps xmm13, [0x00007F582C9FE060]
00007f582cde1f5b  jmp 0x00007F582CDE1E9D
00007f582cde1f60  vxorps xmm0, xmm1, xmm14
00007f582cde1f65  pextrw eax, xmm0, 0x03
00007f582cde1f6a  and eax, 0x7FF8
00007f582cde1f6f  cmp eax, 0x08
00007f582cde1f72  jnz 0x00007F582CDE1E9D
00007f582cde1f78  movq rax, xmm14
00007f582cde1f7d  shl rax, 0x0D
00007f582cde1f81  jbe 0x00007F582CDE1E9D
00007f582cde1f87  vorps xmm13, xmm14, [0x00007F582C9FE070]
00007f582cde1f8f  jmp 0x00007F582CDE1E9D
00007f582cde1f94  ucomisd xmm1, xmm15
00007f582cde1f99  jp 0x00007F582CDE1FA8
00007f582cde1f9b  movaps xmm14, [0x00007F582C9FE060]
00007f582cde1fa3  jmp 0x00007F582CDE1ECA
00007f582cde1fa8  vxorps xmm0, xmm1, xmm15
00007f582cde1fad  pextrw eax, xmm0, 0x03
00007f582cde1fb2  and eax, 0x7FF8
00007f582cde1fb7  cmp eax, 0x08
00007f582cde1fba  jnz 0x00007F582CDE1ECA
00007f582cde1fc0  movq rax, xmm15
00007f582cde1fc5  shl rax, 0x0D
00007f582cde1fc9  jbe 0x00007F582CDE1ECA
00007f582cde1fcf  vorps xmm14, xmm15, [0x00007F582C9FE070]
00007f582cde1fd7  jmp 0x00007F582CDE1ECA
00007f582cde1fdc  int3
00007f582cde1fdd  nop [rax], eax
00007f582cde1fe0  mov rax, [r15+0x40]
00007f582cde1fe4  lea r14, [rax+0x510]
00007f582cde1feb  movaps xmm1, [r15+0x110]
00007f582cde1ff3  movq rax, xmm1
00007f582cde1ff8  mov [r13+r14*1], rax
00007f582cde1ffd  mov rax, [r15+0xF0]
00007f582cde2004  mov [r15+0x100], rax
00007f582cde200b  jmp 0x00007F582CDCE5C0
00007f582cde2010  int3
00007f582cde2011  call 0x00007F582CCD5EB0
00007f582cde2016  jmp 0x00007F582CDE1FFD
00007f582cde201b  int3
00007f582cde201c  nop [rax], eax
00007f582cde2020  mov qword ptr [r15+0x100], 0x04
00007f582cde202b  mov esi, 0x00
00007f582cde2030  mov edx, 0x09
00007f582cde2035  mov rdi, 0x7FFDC909A4A0
00007f582cde203f  mov rax, 0x653B0D852970
00007f582cde2049  call rax
00007f582cde204b  cmp dword ptr [r15+0x318], 0x00
00007f582cde2053  jnz 0x00007F582CBFE110
00007f582cde2059  jmp 0x00007F582CBFE0A0
00007f582cde205e  int3
00007f582cde205f  int3
