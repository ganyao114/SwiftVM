000079a3731ce69b  nop [rax+rax*1], eax
000079a3731ce6a0  vmovaps xmm1, [0x000079A372DFE010]
000079a3731ce6a8  movq xmm1, xmm1
000079a3731ce6ac  movaps [r15+0x110], xmm1
000079a3731ce6b4  vmovaps xmm1, [0x000079A372DFE020]
000079a3731ce6bc  movq xmm1, xmm1
000079a3731ce6c0  movaps [r15+0x120], xmm1
000079a3731ce6c8  mov eax, 0x4204C0
000079a3731ce6cd  mov r14, [r13+rax*1]
000079a3731ce6d2  movq xmm1, r14
000079a3731ce6d7  movaps [r15+0x130], xmm1
000079a3731ce6df  vmovaps xmm1, [0x000079A372DFE030]
000079a3731ce6e7  vpbroadcastq xmm1, xmm1
000079a3731ce6ec  movaps [r15+0x140], xmm1
000079a3731ce6f4  mov qword ptr [r15+0x40], 0x02
000079a3731ce6fc  vmovaps xmm15, [0x000079A372DFE040]
000079a3731ce704  movq xmm15, xmm15
000079a3731ce709  movaps [r15+0x150], xmm15
000079a3731ce711  mov qword ptr [r15+0x58], 0x420000
000079a3731ce719  vmovaps xmm15, [0x000079A372DFE050]
000079a3731ce721  vpbroadcastq xmm15, xmm15
000079a3731ce726  movaps [r15+0x160], xmm15
000079a3731ce72e  mov rax, [r15+0x40]
000079a3731ce732  vmovq xmm14, rax
000079a3731ce737  vpbroadcastq xmm14, xmm14
000079a3731ce73c  movaps [r15+0x170], xmm14
000079a3731ce744  mov eax, 0x4204D0
000079a3731ce749  movups xmm13, [r13+rax*1]
000079a3731ce74f  mov qword ptr [r15+0x40], 0x430518
000079a3731ce757  mov qword ptr [r15+0x50], 0x430720
000079a3731ce75f  vpmovqd xmm12, xmm13
000079a3731ce765  pxor xmm11, xmm11
000079a3731ce76a  punpcklqdq xmm12, xmm11
000079a3731ce76f  movaps [r15+0x210], xmm12
000079a3731ce777  movq xmm12, qword ptr [r15+0x120]
000079a3731ce780  movq xmm11, qword ptr [r15+0x130]
000079a3731ce789  psubd xmm12, xmm11
000079a3731ce78e  movq xmm12, xmm12
000079a3731ce793  paddq xmm13, xmm14
000079a3731ce798  movaps [r15+0x180], xmm13
000079a3731ce7a0  movq xmm14, qword ptr [r15+0x150]
000079a3731ce7a9  paddd xmm11, xmm14
000079a3731ce7ae  movq xmm11, xmm11
000079a3731ce7b3  movq xmm11, xmm11
000079a3731ce7b8  movaps [r15+0x130], xmm11
000079a3731ce7c0  pmovzxdq xmm12, xmm12
000079a3731ce7c6  psllq xmm12, 0x00
000079a3731ce7cc  movq xmm14, qword ptr [r15+0x210]
000079a3731ce7d5  movq xmm13, qword ptr [r15+0x110]
000079a3731ce7de  paddd xmm14, xmm13
000079a3731ce7e3  movq xmm14, xmm14
000079a3731ce7e8  vcvtuqq2pd xmm12, xmm12
000079a3731ce7ee  pmovzxdq xmm14, xmm14
000079a3731ce7f4  psllq xmm14, 0x00
000079a3731ce7fa  vcvtuqq2pd xmm14, xmm14
000079a3731ce800  movaps xmm13, xmm12
000079a3731ce804  mulpd xmm13, xmm1
000079a3731ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000079a3731ce80f  ptest xmm11, xmm11
000079a3731ce815  jnz 0x000079A3731CE8FF
000079a3731ce81b  movaps [r15+0x220], xmm13
000079a3731ce823  mov eax, 0x430720
000079a3731ce828  movups [r13+rax*1], xmm13
000079a3731ce82e  movaps xmm1, xmm14
000079a3731ce832  mulpd xmm1, xmm15
000079a3731ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000079a3731ce83c  ptest xmm13, xmm13
000079a3731ce842  jnz 0x000079A3731CEA4C
000079a3731ce848  movaps [r15+0x210], xmm1
000079a3731ce850  mov eax, 0x430518
000079a3731ce855  movups [r13+rax*1], xmm1
000079a3731ce85b  mov qword ptr [r15+0x48], 0x10
000079a3731ce863  xor eax, eax
000079a3731ce865  mov r14d, 0x10
000079a3731ce86b  mov r12d, 0x200
000079a3731ce871  cmp r14, r12
000079a3731ce874  cmc
000079a3731ce875  lahf
000079a3731ce876  seto al
000079a3731ce879  mov [r15+0x108], eax
000079a3731ce880  mov eax, [r15+0x108]
000079a3731ce887  sahf
000079a3731ce888  jnz 0x000079A3731CE8BA
000079a3731ce88a  cmp dword ptr [r15+0x318], 0x00
000079a3731ce892  jz 0x000079A3731CEFF0
000079a3731ce898  nop [rax+rax*1], ax
000079a3731ce8a1  nop [rax+rax*1], eax
000079a3731ce8a9  mov eax, 0x4101EC
000079a3731ce8ae  mov [r15+0x100], rax
000079a3731ce8b5  jmp 0x000079A372FFE110
000079a3731ce8ba  cmp dword ptr [r15+0x318], 0x00
000079a3731ce8c2  jz 0x000079A3731CEBA0
000079a3731ce8c8  nop [rax+rax*1], ax
000079a3731ce8d1  nop [rax+rax*1], eax
000079a3731ce8d9  mov eax, 0x4101AC
000079a3731ce8de  mov [r15+0x100], rax
000079a3731ce8e5  jmp 0x000079A372FFE110
000079a3731ce8ea  int3
000079a3731ce8eb  call 0x000079A37300DC20
000079a3731ce8f0  jmp 0x000079A3731CE6D2
000079a3731ce8f5  call 0x000079A37300C260
000079a3731ce8fa  jmp 0x000079A3731CE74F
000079a3731ce8ff  sub rsp, 0x08
000079a3731ce903  push rax
000079a3731ce904  push rcx
000079a3731ce905  push rdx
000079a3731ce906  push rdi
000079a3731ce907  push rsi
000079a3731ce908  push r8
000079a3731ce90a  push r9
000079a3731ce90c  push r10
000079a3731ce90e  push r11
000079a3731ce910  sub rsp, 0xF0
000079a3731ce917  vmovaps [rsp], xmm0
000079a3731ce91c  vmovaps [rsp+0x10], xmm1
000079a3731ce922  vmovaps [rsp+0x20], xmm2
000079a3731ce928  vmovaps [rsp+0x30], xmm3
000079a3731ce92e  vmovaps [rsp+0x40], xmm4
000079a3731ce934  vmovaps [rsp+0x50], xmm5
000079a3731ce93a  vmovaps [rsp+0x60], xmm6
000079a3731ce940  vmovaps [rsp+0x70], xmm7
000079a3731ce946  vmovaps [rsp+0x80], xmm8
000079a3731ce94f  vmovaps [rsp+0x90], xmm9
000079a3731ce958  vmovaps [rsp+0xA0], xmm10
000079a3731ce961  vmovaps [rsp+0xB0], xmm11
000079a3731ce96a  vmovaps [rsp+0xC0], xmm12
000079a3731ce973  vmovaps [rsp+0xD0], xmm14
000079a3731ce97c  vmovaps [rsp+0xE0], xmm15
000079a3731ce985  sub rsp, 0x30
000079a3731ce989  movaps [rsp], xmm13
000079a3731ce98e  movaps [rsp+0x10], xmm12
000079a3731ce994  movaps [rsp+0x20], xmm1
000079a3731ce999  lea rdi, [rsp]
000079a3731ce99d  mov esi, 0x00
000079a3731ce9a2  mov rax, 0x64F127B95530
000079a3731ce9ac  call rax
000079a3731ce9ae  movaps xmm13, [rsp]
000079a3731ce9b3  add rsp, 0x30
000079a3731ce9b7  vmovaps xmm0, [rsp]
000079a3731ce9bc  vmovaps xmm1, [rsp+0x10]
000079a3731ce9c2  vmovaps xmm2, [rsp+0x20]
000079a3731ce9c8  vmovaps xmm3, [rsp+0x30]
000079a3731ce9ce  vmovaps xmm4, [rsp+0x40]
000079a3731ce9d4  vmovaps xmm5, [rsp+0x50]
000079a3731ce9da  vmovaps xmm6, [rsp+0x60]
000079a3731ce9e0  vmovaps xmm7, [rsp+0x70]
000079a3731ce9e6  vmovaps xmm8, [rsp+0x80]
000079a3731ce9ef  vmovaps xmm9, [rsp+0x90]
000079a3731ce9f8  vmovaps xmm10, [rsp+0xA0]
000079a3731cea01  vmovaps xmm11, [rsp+0xB0]
000079a3731cea0a  vmovaps xmm12, [rsp+0xC0]
000079a3731cea13  vmovaps xmm14, [rsp+0xD0]
000079a3731cea1c  vmovaps xmm15, [rsp+0xE0]
000079a3731cea25  add rsp, 0xF0
000079a3731cea2c  pop r11
000079a3731cea2e  pop r10
000079a3731cea30  pop r9
000079a3731cea32  pop r8
000079a3731cea34  pop rsi
000079a3731cea35  pop rdi
000079a3731cea36  pop rdx
000079a3731cea37  pop rcx
000079a3731cea38  pop rax
000079a3731cea39  add rsp, 0x08
000079a3731cea3d  jmp 0x000079A3731CE81B
000079a3731cea42  call 0x000079A37300C380
000079a3731cea47  jmp 0x000079A3731CE82E
000079a3731cea4c  sub rsp, 0x08
000079a3731cea50  push rax
000079a3731cea51  push rcx
000079a3731cea52  push rdx
000079a3731cea53  push rdi
000079a3731cea54  push rsi
000079a3731cea55  push r8
000079a3731cea57  push r9
000079a3731cea59  push r10
000079a3731cea5b  push r11
000079a3731cea5d  sub rsp, 0xF0
000079a3731cea64  vmovaps [rsp], xmm0
000079a3731cea69  vmovaps [rsp+0x10], xmm2
000079a3731cea6f  vmovaps [rsp+0x20], xmm3
000079a3731cea75  vmovaps [rsp+0x30], xmm4
000079a3731cea7b  vmovaps [rsp+0x40], xmm5
000079a3731cea81  vmovaps [rsp+0x50], xmm6
000079a3731cea87  vmovaps [rsp+0x60], xmm7
000079a3731cea8d  vmovaps [rsp+0x70], xmm8
000079a3731cea93  vmovaps [rsp+0x80], xmm9
000079a3731cea9c  vmovaps [rsp+0x90], xmm10
000079a3731ceaa5  vmovaps [rsp+0xA0], xmm11
000079a3731ceaae  vmovaps [rsp+0xB0], xmm12
000079a3731ceab7  vmovaps [rsp+0xC0], xmm13
000079a3731ceac0  vmovaps [rsp+0xD0], xmm14
000079a3731ceac9  vmovaps [rsp+0xE0], xmm15
000079a3731cead2  sub rsp, 0x30
000079a3731cead6  movaps [rsp], xmm1
000079a3731ceada  movaps [rsp+0x10], xmm14
000079a3731ceae0  movaps [rsp+0x20], xmm15
000079a3731ceae6  lea rdi, [rsp]
000079a3731ceaea  mov esi, 0x00
000079a3731ceaef  mov rax, 0x64F127B95530
000079a3731ceaf9  call rax
000079a3731ceafb  movaps xmm1, [rsp]
000079a3731ceaff  add rsp, 0x30
000079a3731ceb03  vmovaps xmm0, [rsp]
000079a3731ceb08  vmovaps xmm2, [rsp+0x10]
000079a3731ceb0e  vmovaps xmm3, [rsp+0x20]
000079a3731ceb14  vmovaps xmm4, [rsp+0x30]
000079a3731ceb1a  vmovaps xmm5, [rsp+0x40]
000079a3731ceb20  vmovaps xmm6, [rsp+0x50]
000079a3731ceb26  vmovaps xmm7, [rsp+0x60]
000079a3731ceb2c  vmovaps xmm8, [rsp+0x70]
000079a3731ceb32  vmovaps xmm9, [rsp+0x80]
000079a3731ceb3b  vmovaps xmm10, [rsp+0x90]
000079a3731ceb44  vmovaps xmm11, [rsp+0xA0]
000079a3731ceb4d  vmovaps xmm12, [rsp+0xB0]
000079a3731ceb56  vmovaps xmm13, [rsp+0xC0]
000079a3731ceb5f  vmovaps xmm14, [rsp+0xD0]
000079a3731ceb68  vmovaps xmm15, [rsp+0xE0]
000079a3731ceb71  add rsp, 0xF0
000079a3731ceb78  pop r11
000079a3731ceb7a  pop r10
000079a3731ceb7c  pop r9
000079a3731ceb7e  pop r8
000079a3731ceb80  pop rsi
000079a3731ceb81  pop rdi
000079a3731ceb82  pop rdx
000079a3731ceb83  pop rcx
000079a3731ceb84  pop rax
000079a3731ceb85  add rsp, 0x08
000079a3731ceb89  jmp 0x000079A3731CE848
000079a3731ceb8e  call 0x000079A372FFF540
000079a3731ceb93  jmp 0x000079A3731CE85B
000079a3731ceb98  int3
000079a3731ceb99  nop [rax], eax
000079a3731ceba0  movaps xmm1, [r15+0x180]
000079a3731ceba8  vpmovqd xmm15, xmm1
000079a3731cebae  pxor xmm14, xmm14
000079a3731cebb3  punpcklqdq xmm15, xmm14
000079a3731cebb8  movaps [r15+0x210], xmm15
000079a3731cebc0  movq xmm15, qword ptr [r15+0x120]
000079a3731cebc9  movq xmm14, qword ptr [r15+0x130]
000079a3731cebd2  psubd xmm15, xmm14
000079a3731cebd7  movq xmm15, xmm15
000079a3731cebdc  movaps xmm13, [r15+0x170]
000079a3731cebe4  paddq xmm1, xmm13
000079a3731cebe9  movaps [r15+0x180], xmm1
000079a3731cebf1  movq xmm1, qword ptr [r15+0x150]
000079a3731cebfa  paddd xmm14, xmm1
000079a3731cebff  movq xmm14, xmm14
000079a3731cec04  movq xmm14, xmm14
000079a3731cec09  movaps [r15+0x130], xmm14
000079a3731cec11  pmovzxdq xmm15, xmm15
000079a3731cec17  psllq xmm15, 0x00
000079a3731cec1d  movq xmm1, qword ptr [r15+0x210]
000079a3731cec26  movq xmm14, qword ptr [r15+0x110]
000079a3731cec2f  paddd xmm1, xmm14
000079a3731cec34  movq xmm1, xmm1
000079a3731cec38  vcvtuqq2pd xmm15, xmm15
000079a3731cec3e  pmovzxdq xmm1, xmm1
000079a3731cec43  psllq xmm1, 0x00
000079a3731cec48  vcvtuqq2pd xmm1, xmm1
000079a3731cec4e  movaps xmm14, [r15+0x140]
000079a3731cec56  movaps xmm13, xmm15
000079a3731cec5a  mulpd xmm13, xmm14
000079a3731cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000079a3731cec65  ptest xmm12, xmm12
000079a3731cec6b  jnz 0x000079A3731CED4E
000079a3731cec71  movaps [r15+0x220], xmm13
000079a3731cec79  mov rax, [r15+0x48]
000079a3731cec7d  mov r14, [r15+0x50]
000079a3731cec81  lea r12, [r14+rax*1]
000079a3731cec85  movups [r13+r12*1], xmm13
000079a3731cec8b  movaps xmm15, [r15+0x160]
000079a3731cec93  movaps xmm14, xmm1
000079a3731cec97  mulpd xmm14, xmm15
000079a3731cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000079a3731ceca2  ptest xmm13, xmm13
000079a3731ceca8  jnz 0x000079A3731CEE9C
000079a3731cecae  movaps [r15+0x210], xmm14
000079a3731cecb6  mov r14, [r15+0x40]
000079a3731cecba  lea r12, [r14+rax*1]
000079a3731cecbe  movups [r13+r12*1], xmm14
000079a3731cecc4  lea r14, [rax+0x10]
000079a3731cecc8  mov [r15+0x48], r14
000079a3731ceccc  xor eax, eax
000079a3731cecce  mov r12d, 0x200
000079a3731cecd4  cmp r14, r12
000079a3731cecd7  cmc
000079a3731cecd8  lahf
000079a3731cecd9  seto al
000079a3731cecdc  mov [r15+0x108], eax
000079a3731cece3  mov eax, [r15+0x108]
000079a3731cecea  sahf
000079a3731ceceb  jnz 0x000079A3731CED1D
000079a3731ceced  cmp dword ptr [r15+0x318], 0x00
000079a3731cecf5  jz 0x000079A3731CEFF0
000079a3731cecfb  nop [rax+rax*1], ax
000079a3731ced04  nop [rax+rax*1], eax
000079a3731ced0c  mov eax, 0x4101EC
000079a3731ced11  mov [r15+0x100], rax
000079a3731ced18  jmp 0x000079A372FFE110
000079a3731ced1d  cmp dword ptr [r15+0x318], 0x00
000079a3731ced25  jz 0x000079A3731CEBA0
000079a3731ced2b  nop [rax+rax*1], ax
000079a3731ced34  nop [rax+rax*1], eax
000079a3731ced3c  mov eax, 0x4101AC
000079a3731ced41  mov [r15+0x100], rax
000079a3731ced48  jmp 0x000079A372FFE110
000079a3731ced4d  int3
000079a3731ced4e  sub rsp, 0x08
000079a3731ced52  push rax
000079a3731ced53  push rcx
000079a3731ced54  push rdx
000079a3731ced55  push rdi
000079a3731ced56  push rsi
000079a3731ced57  push r8
000079a3731ced59  push r9
000079a3731ced5b  push r10
000079a3731ced5d  push r11
000079a3731ced5f  sub rsp, 0xF0
000079a3731ced66  vmovaps [rsp], xmm0
000079a3731ced6b  vmovaps [rsp+0x10], xmm1
000079a3731ced71  vmovaps [rsp+0x20], xmm2
000079a3731ced77  vmovaps [rsp+0x30], xmm3
000079a3731ced7d  vmovaps [rsp+0x40], xmm4
000079a3731ced83  vmovaps [rsp+0x50], xmm5
000079a3731ced89  vmovaps [rsp+0x60], xmm6
000079a3731ced8f  vmovaps [rsp+0x70], xmm7
000079a3731ced95  vmovaps [rsp+0x80], xmm8
000079a3731ced9e  vmovaps [rsp+0x90], xmm9
000079a3731ceda7  vmovaps [rsp+0xA0], xmm10
000079a3731cedb0  vmovaps [rsp+0xB0], xmm11
000079a3731cedb9  vmovaps [rsp+0xC0], xmm12
000079a3731cedc2  vmovaps [rsp+0xD0], xmm14
000079a3731cedcb  vmovaps [rsp+0xE0], xmm15
000079a3731cedd4  sub rsp, 0x30
000079a3731cedd8  movaps [rsp], xmm13
000079a3731ceddd  movaps [rsp+0x10], xmm15
000079a3731cede3  movaps [rsp+0x20], xmm14
000079a3731cede9  lea rdi, [rsp]
000079a3731ceded  mov esi, 0x00
000079a3731cedf2  mov rax, 0x64F127B95530
000079a3731cedfc  call rax
000079a3731cedfe  movaps xmm13, [rsp]
000079a3731cee03  add rsp, 0x30
000079a3731cee07  vmovaps xmm0, [rsp]
000079a3731cee0c  vmovaps xmm1, [rsp+0x10]
000079a3731cee12  vmovaps xmm2, [rsp+0x20]
000079a3731cee18  vmovaps xmm3, [rsp+0x30]
000079a3731cee1e  vmovaps xmm4, [rsp+0x40]
000079a3731cee24  vmovaps xmm5, [rsp+0x50]
000079a3731cee2a  vmovaps xmm6, [rsp+0x60]
000079a3731cee30  vmovaps xmm7, [rsp+0x70]
000079a3731cee36  vmovaps xmm8, [rsp+0x80]
000079a3731cee3f  vmovaps xmm9, [rsp+0x90]
000079a3731cee48  vmovaps xmm10, [rsp+0xA0]
000079a3731cee51  vmovaps xmm11, [rsp+0xB0]
000079a3731cee5a  vmovaps xmm12, [rsp+0xC0]
000079a3731cee63  vmovaps xmm14, [rsp+0xD0]
000079a3731cee6c  vmovaps xmm15, [rsp+0xE0]
000079a3731cee75  add rsp, 0xF0
000079a3731cee7c  pop r11
000079a3731cee7e  pop r10
000079a3731cee80  pop r9
000079a3731cee82  pop r8
000079a3731cee84  pop rsi
000079a3731cee85  pop rdi
000079a3731cee86  pop rdx
000079a3731cee87  pop rcx
000079a3731cee88  pop rax
000079a3731cee89  add rsp, 0x08
000079a3731cee8d  jmp 0x000079A3731CEC71
000079a3731cee92  call 0x000079A3730C2240
000079a3731cee97  jmp 0x000079A3731CEC8B
000079a3731cee9c  sub rsp, 0x08
000079a3731ceea0  push rax
000079a3731ceea1  push rcx
000079a3731ceea2  push rdx
000079a3731ceea3  push rdi
000079a3731ceea4  push rsi
000079a3731ceea5  push r8
000079a3731ceea7  push r9
000079a3731ceea9  push r10
000079a3731ceeab  push r11
000079a3731ceead  sub rsp, 0xF0
000079a3731ceeb4  vmovaps [rsp], xmm0
000079a3731ceeb9  vmovaps [rsp+0x10], xmm1
000079a3731ceebf  vmovaps [rsp+0x20], xmm2
000079a3731ceec5  vmovaps [rsp+0x30], xmm3
000079a3731ceecb  vmovaps [rsp+0x40], xmm4
000079a3731ceed1  vmovaps [rsp+0x50], xmm5
000079a3731ceed7  vmovaps [rsp+0x60], xmm6
000079a3731ceedd  vmovaps [rsp+0x70], xmm7
000079a3731ceee3  vmovaps [rsp+0x80], xmm8
000079a3731ceeec  vmovaps [rsp+0x90], xmm9
000079a3731ceef5  vmovaps [rsp+0xA0], xmm10
000079a3731ceefe  vmovaps [rsp+0xB0], xmm11
000079a3731cef07  vmovaps [rsp+0xC0], xmm12
000079a3731cef10  vmovaps [rsp+0xD0], xmm13
000079a3731cef19  vmovaps [rsp+0xE0], xmm15
000079a3731cef22  sub rsp, 0x30
000079a3731cef26  movaps [rsp], xmm14
000079a3731cef2b  movaps [rsp+0x10], xmm1
000079a3731cef30  movaps [rsp+0x20], xmm15
000079a3731cef36  lea rdi, [rsp]
000079a3731cef3a  mov esi, 0x00
000079a3731cef3f  mov rax, 0x64F127B95530
000079a3731cef49  call rax
000079a3731cef4b  movaps xmm14, [rsp]
000079a3731cef50  add rsp, 0x30
000079a3731cef54  vmovaps xmm0, [rsp]
000079a3731cef59  vmovaps xmm1, [rsp+0x10]
000079a3731cef5f  vmovaps xmm2, [rsp+0x20]
000079a3731cef65  vmovaps xmm3, [rsp+0x30]
000079a3731cef6b  vmovaps xmm4, [rsp+0x40]
000079a3731cef71  vmovaps xmm5, [rsp+0x50]
000079a3731cef77  vmovaps xmm6, [rsp+0x60]
000079a3731cef7d  vmovaps xmm7, [rsp+0x70]
000079a3731cef83  vmovaps xmm8, [rsp+0x80]
000079a3731cef8c  vmovaps xmm9, [rsp+0x90]
000079a3731cef95  vmovaps xmm10, [rsp+0xA0]
000079a3731cef9e  vmovaps xmm11, [rsp+0xB0]
000079a3731cefa7  vmovaps xmm12, [rsp+0xC0]
000079a3731cefb0  vmovaps xmm13, [rsp+0xD0]
000079a3731cefb9  vmovaps xmm15, [rsp+0xE0]
000079a3731cefc2  add rsp, 0xF0
000079a3731cefc9  pop r11
000079a3731cefcb  pop r10
000079a3731cefcd  pop r9
000079a3731cefcf  pop r8
000079a3731cefd1  pop rsi
000079a3731cefd2  pop rdi
000079a3731cefd3  pop rdx
000079a3731cefd4  pop rcx
000079a3731cefd5  pop rax
000079a3731cefd6  add rsp, 0x08
000079a3731cefda  jmp 0x000079A3731CECAE
000079a3731cefdf  call 0x000079A3730C34C0
000079a3731cefe4  jmp 0x000079A3731CECC4
000079a3731cefe9  int3
000079a3731cefea  nop [rax+rax*1], ax
000079a3731ceff0  mov rax, [r15+0xF8]
000079a3731ceff7  lea r14, [rax-0x150]
000079a3731ceffe  mov [r15+0xF8], r14
000079a3731cf005  mov rax, [r15+0x50]
000079a3731cf009  lea r12, [rax+0x80]
000079a3731cf010  movups xmm1, [r13+r12*1]
000079a3731cf016  lea r12, [rax+0x90]
000079a3731cf01d  movups xmm15, [r13+r12*1]
000079a3731cf023  mov qword ptr [r15+0x48], 0x00
000079a3731cf02b  lea r12, [rax+0x40]
000079a3731cf02f  movups xmm14, [r13+r12*1]
000079a3731cf035  lea r12, [rax+0x50]
000079a3731cf039  movups xmm13, [r13+r12*1]
000079a3731cf03f  lea r12, [r14+0x120]
000079a3731cf046  movq xmm12, qword ptr [r15+0x1C0]
000079a3731cf04f  movq xmm11, qword ptr [r15+0x1B0]
000079a3731cf058  movq r11, xmm12
000079a3731cf05d  movq r10, xmm11
000079a3731cf062  mov [r13+r12*1], r11
000079a3731cf067  lea r12, [r14+0x128]
000079a3731cf06e  mov [r13+r12*1], r10
000079a3731cf073  vxorps xmm12, xmm12, xmm12
000079a3731cf078  vpbroadcastq xmm12, xmm12
000079a3731cf07d  lea r12, [r14+0x100]
000079a3731cf084  movq xmm11, qword ptr [r15+0x200]
000079a3731cf08d  movq xmm10, qword ptr [r15+0x1F0]
000079a3731cf096  movq r11, xmm11
000079a3731cf09b  movq r10, xmm10
000079a3731cf0a0  mov [r13+r12*1], r11
000079a3731cf0a5  lea r12, [r14+0x108]
000079a3731cf0ac  mov [r13+r12*1], r10
000079a3731cf0b1  lea r12, [r14+0xE0]
000079a3731cf0b8  movups [r13+r12*1], xmm15
000079a3731cf0be  lea r12, [r14+0xF0]
000079a3731cf0c5  movups [r13+r12*1], xmm1
000079a3731cf0cb  lea r12, [rax+0xC0]
000079a3731cf0d2  movups xmm1, [r13+r12*1]
000079a3731cf0d8  lea r12, [rax+0xD0]
000079a3731cf0df  movups xmm15, [r13+r12*1]
000079a3731cf0e5  lea r12, [r14+0x110]
000079a3731cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000079a3731cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000079a3731cf0fe  movq r11, xmm11
000079a3731cf103  movq r10, xmm10
000079a3731cf108  mov [r13+r12*1], r11
000079a3731cf10d  lea r12, [r14+0x118]
000079a3731cf114  mov [r13+r12*1], r10
000079a3731cf119  movups xmm11, [r13+rax*1]
000079a3731cf11f  lea r12, [rax+0x10]
000079a3731cf123  movups xmm10, [r13+r12*1]
000079a3731cf129  lea r12, [r14+0x130]
000079a3731cf130  movq xmm9, qword ptr [r15+0x1A0]
000079a3731cf139  movq xmm8, qword ptr [r15+0x190]
000079a3731cf142  movq r11, xmm9
000079a3731cf147  movq r10, xmm8
000079a3731cf14c  mov [r13+r12*1], r11
000079a3731cf151  lea r12, [r14+0x138]
000079a3731cf158  mov [r13+r12*1], r10
000079a3731cf15d  lea r12, [rax+0x140]
000079a3731cf164  movups xmm9, [r13+r12*1]
000079a3731cf16a  lea r12, [rax+0x150]
000079a3731cf171  movups xmm8, [r13+r12*1]
000079a3731cf177  lea r12, [r14+0xC0]
000079a3731cf17e  movups [r13+r12*1], xmm15
000079a3731cf184  lea r12, [r14+0xD0]
000079a3731cf18b  movups [r13+r12*1], xmm1
000079a3731cf191  lea r12, [rax+0x100]
000079a3731cf198  movups xmm1, [r13+r12*1]
000079a3731cf19e  lea r12, [rax+0x110]
000079a3731cf1a5  movups xmm15, [r13+r12*1]
000079a3731cf1ab  lea r12, [r14+0x140]
000079a3731cf1b2  mov r11, [r15+0xE8]
000079a3731cf1b9  mov [r13+r12*1], r11
000079a3731cf1be  lea r12, [rax+0x180]
000079a3731cf1c5  movups xmm7, [r13+r12*1]
000079a3731cf1cb  lea r12, [rax+0x190]
000079a3731cf1d2  movups xmm6, [r13+r12*1]
000079a3731cf1d8  lea r12, [rax+0x1C0]
000079a3731cf1df  movups xmm5, [r13+r12*1]
000079a3731cf1e5  lea r12, [rax+0x1D0]
000079a3731cf1ec  movups xmm4, [r13+r12*1]
000079a3731cf1f2  lea r12, [r14+0x20]
000079a3731cf1f6  movups [r13+r12*1], xmm1
000079a3731cf1fc  lea r12, [r14+0x30]
000079a3731cf200  movups [r13+r12*1], xmm13
000079a3731cf206  lea r12, [rax+0x60]
000079a3731cf20a  movups xmm1, [r13+r12*1]
000079a3731cf210  lea r12, [rax+0x70]
000079a3731cf214  movups xmm13, [r13+r12*1]
000079a3731cf21a  lea r12, [rax+0x20]
000079a3731cf21e  movups xmm3, [r13+r12*1]
000079a3731cf224  lea r12, [rax+0x30]
000079a3731cf228  movups xmm2, [r13+r12*1]
000079a3731cf22e  movaps [r15+0x1F0], xmm2
000079a3731cf236  lea r12, [r14+0x60]
000079a3731cf23a  movups [r13+r12*1], xmm11
000079a3731cf240  lea r12, [r14+0x70]
000079a3731cf244  movups [r13+r12*1], xmm5
000079a3731cf24a  lea r12, [rax+0xE0]
000079a3731cf251  movups xmm11, [r13+r12*1]
000079a3731cf257  lea r12, [rax+0xF0]
000079a3731cf25e  movups xmm5, [r13+r12*1]
000079a3731cf264  lea r12, [r14+0xA0]
000079a3731cf26b  movups [r13+r12*1], xmm13
000079a3731cf271  lea r12, [r14+0xB0]
000079a3731cf278  movups [r13+r12*1], xmm1
000079a3731cf27e  lea r12, [rax+0xA0]
000079a3731cf285  movups xmm1, [r13+r12*1]
000079a3731cf28b  lea r12, [rax+0xB0]
000079a3731cf292  movups xmm13, [r13+r12*1]
000079a3731cf298  lea r12, [rax+0x120]
000079a3731cf29f  vmovaps [rsp+0x10], xmm1
000079a3731cf2a5  movups xmm1, [r13+r12*1]
000079a3731cf2ab  lea r12, [rax+0x130]
000079a3731cf2b2  vmovaps [rsp+0x20], xmm1
000079a3731cf2b8  movups xmm1, [r13+r12*1]
000079a3731cf2be  lea r12, [rax+0x160]
000079a3731cf2c5  vmovaps [rsp+0x30], xmm1
000079a3731cf2cb  movups xmm1, [r13+r12*1]
000079a3731cf2d1  lea r12, [rax+0x170]
000079a3731cf2d8  vmovaps [rsp+0x40], xmm1
000079a3731cf2de  movups xmm1, [r13+r12*1]
000079a3731cf2e4  movaps [r15+0x2B0], xmm1
000079a3731cf2ec  lea r12, [r14+0x80]
000079a3731cf2f3  movups [r13+r12*1], xmm13
000079a3731cf2f9  lea r12, [r14+0x90]
000079a3731cf300  vmovaps xmm13, [rsp+0x10]
000079a3731cf306  movups [r13+r12*1], xmm13
000079a3731cf30c  lea r12, [rax+0x1A0]
000079a3731cf313  movups xmm13, [r13+r12*1]
000079a3731cf319  lea r12, [rax+0x1B0]
000079a3731cf320  vmovaps [rsp+0x10], xmm1
000079a3731cf326  movups xmm1, [r13+r12*1]
000079a3731cf32c  movaps [r15+0x290], xmm13
000079a3731cf334  movaps [r15+0x1E0], xmm1
000079a3731cf33c  lea r12, [rax+0x1E0]
000079a3731cf343  vmovaps [rsp+0x50], xmm1
000079a3731cf349  movups xmm1, [r13+r12*1]
000079a3731cf34f  lea r12, [rax+0x1F0]
000079a3731cf356  vmovaps [rsp+0x60], xmm1
000079a3731cf35c  movups xmm1, [r13+r12*1]
000079a3731cf362  mov qword ptr [r15+0x50], 0x430920
000079a3731cf36a  lea rax, [r14+0x40]
000079a3731cf36e  vmovaps [rsp+0x70], xmm1
000079a3731cf374  vmovaps xmm1, [rsp+0x40]
000079a3731cf37a  movups [r13+rax*1], xmm1
000079a3731cf380  lea rax, [r14+0x50]
000079a3731cf384  movups [r13+rax*1], xmm10
000079a3731cf38a  vmovaps xmm1, [rsp+0x70]
000079a3731cf390  movups [r13+r14*1], xmm1
000079a3731cf396  lea rax, [r14+0x10]
000079a3731cf39a  vmovaps xmm1, [rsp+0x60]
000079a3731cf3a0  movups [r13+rax*1], xmm1
000079a3731cf3a6  mov rax, [r15+0x40]
000079a3731cf3aa  vmovaps [rsp+0x40], xmm3
000079a3731cf3b0  vmovaps xmm1, [rsp+0x40]
000079a3731cf3b6  por xmm3, xmm1
000079a3731cf3ba  vmovaps [rsp+0x40], xmm6
000079a3731cf3c0  vmovaps xmm10, [rsp+0x40]
000079a3731cf3c6  por xmm6, xmm10
000079a3731cf3cb  lea r12, [rax+0x30]
000079a3731cf3cf  mov r11, [r13+r12*1]
000079a3731cf3d4  lea r12, [rax+0x38]
000079a3731cf3d8  mov r10, [r13+r12*1]
000079a3731cf3dd  movq xmm10, r11
000079a3731cf3e2  vmovaps [rsp+0x40], xmm1
000079a3731cf3e8  movq xmm1, r10
000079a3731cf3ed  movq xmm10, xmm10
000079a3731cf3f2  vmovaps [rsp+0x60], xmm10
000079a3731cf3f8  movq xmm10, xmm10
000079a3731cf3fd  movaps [r15+0x130], xmm10
000079a3731cf405  movq xmm1, xmm1
000079a3731cf409  vmovaps [rsp+0x70], xmm1
000079a3731cf40f  movq xmm1, xmm1
000079a3731cf413  movaps [r15+0x280], xmm1
000079a3731cf41b  vmovaps [rsp+0x80], xmm9
000079a3731cf424  vmovaps xmm1, [rsp+0x80]
000079a3731cf42d  por xmm9, xmm1
000079a3731cf432  lea r12, [rax+0x20]
000079a3731cf436  mov r11, [r13+r12*1]
000079a3731cf43b  lea r12, [rax+0x28]
000079a3731cf43f  mov r10, [r13+r12*1]
000079a3731cf444  movq xmm1, r11
000079a3731cf449  movq xmm10, r10
000079a3731cf44e  movq xmm1, xmm1
000079a3731cf452  vmovaps [rsp+0x80], xmm1
000079a3731cf45b  movq xmm1, xmm1
000079a3731cf45f  movaps [r15+0x150], xmm1
000079a3731cf467  movq xmm10, xmm10
000079a3731cf46c  vmovaps [rsp+0x90], xmm10
000079a3731cf475  movq xmm10, xmm10
000079a3731cf47a  movaps [r15+0x140], xmm10
000079a3731cf482  lea r12, [rax+0x10]
000079a3731cf486  mov r11, [r13+r12*1]
000079a3731cf48b  lea r12, [rax+0x18]
000079a3731cf48f  mov r10, [r13+r12*1]
000079a3731cf494  movq xmm1, r11
000079a3731cf499  movq xmm10, r10
000079a3731cf49e  movq xmm1, xmm1
000079a3731cf4a2  vmovaps [rsp+0xA0], xmm1
000079a3731cf4ab  movq xmm1, xmm1
000079a3731cf4af  movaps [r15+0x170], xmm1
000079a3731cf4b7  movq xmm10, xmm10
000079a3731cf4bc  vmovaps [rsp+0xB0], xmm10
000079a3731cf4c5  movq xmm10, xmm10
000079a3731cf4ca  movaps [r15+0x160], xmm10
000079a3731cf4d2  mov r12, [r13+rax*1]
000079a3731cf4d7  vmovq xmm1, r12
000079a3731cf4dc  vpbroadcastq xmm1, xmm1
000079a3731cf4e1  lea r12, [rax+0x08]
000079a3731cf4e5  mov rax, [r13+r12*1]
000079a3731cf4ea  movq xmm10, rax
000079a3731cf4ef  movaps [r15+0x230], xmm10
000079a3731cf4f7  lea rax, [r14+0x50]
000079a3731cf4fb  movups xmm10, [r13+rax*1]
000079a3731cf501  lea rax, [r14+0x60]
000079a3731cf505  vmovaps [rsp+0xC0], xmm1
000079a3731cf50e  movups xmm1, [r13+rax*1]
000079a3731cf514  lea rax, [r14+0x30]
000079a3731cf518  vmovaps [rsp+0xD0], xmm1
000079a3731cf521  movups xmm1, [r13+rax*1]
000079a3731cf527  mov qword ptr [r15+0x60], 0x430920
000079a3731cf52f  mov qword ptr [r15+0x58], 0x40
000079a3731cf537  vmovaps [rsp+0xE0], xmm1
000079a3731cf540  vmovaps [rsp+0xF0], xmm15
000079a3731cf549  vmovaps xmm15, [rsp+0xC0]
000079a3731cf552  vmovaps [rsp+0xC0], xmm14
000079a3731cf55b  vmovaps xmm14, [rsp+0x40]
000079a3731cf561  vmovaps [rsp+0x40], xmm13
000079a3731cf567  movaps xmm1, xmm15
000079a3731cf56b  mulpd xmm1, xmm14
000079a3731cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000079a3731cf575  ptest xmm13, xmm13
000079a3731cf57b  jnz 0x000079A3731D0682
000079a3731cf581  movq xmm14, qword ptr [r15+0x230]
000079a3731cf58a  vmovaps [rsp+0x100], xmm14
000079a3731cf593  vpermilpd xmm14, xmm14, 0x00
000079a3731cf599  vmovaps [rsp+0x110], xmm1
000079a3731cf5a2  vmovaps xmm1, [rsp+0xE0]
000079a3731cf5ab  vmovaps [rsp+0xE0], xmm15
000079a3731cf5b4  movaps xmm13, xmm1
000079a3731cf5b8  mulpd xmm13, xmm14
000079a3731cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000079a3731cf5c3  ptest xmm15, xmm15
000079a3731cf5c9  jnz 0x000079A3731D07C4
000079a3731cf5cf  vxorps xmm1, xmm1, xmm1
000079a3731cf5d3  vpbroadcastq xmm1, xmm1
000079a3731cf5d8  vmovaps xmm14, [rsp+0xE0]
000079a3731cf5e1  vmovaps [rsp+0xE0], xmm1
000079a3731cf5ea  vmovaps xmm1, [rsp+0xD0]
000079a3731cf5f3  vmovaps [rsp+0xD0], xmm13
000079a3731cf5fc  movaps xmm15, xmm14
000079a3731cf600  mulpd xmm15, xmm1
000079a3731cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000079a3731cf60b  ptest xmm13, xmm13
000079a3731cf611  jnz 0x000079A3731D0907
000079a3731cf617  movaps xmm1, xmm14
000079a3731cf61b  mulpd xmm1, xmm10
000079a3731cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000079a3731cf625  ptest xmm13, xmm13
000079a3731cf62b  jnz 0x000079A3731D0A4A
000079a3731cf631  movaps xmm13, xmm14
000079a3731cf635  mulpd xmm13, xmm2
000079a3731cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000079a3731cf640  ptest xmm10, xmm10
000079a3731cf646  jnz 0x000079A3731D0B8C
000079a3731cf64c  vmovaps [rsp+0x120], xmm7
000079a3731cf655  vmovaps xmm14, [rsp+0x120]
000079a3731cf65e  por xmm7, xmm14
000079a3731cf663  vmovaps xmm14, [rsp+0xC0]
000079a3731cf66c  vmovaps xmm10, [rsp+0xC0]
000079a3731cf675  por xmm14, xmm10
000079a3731cf67a  vmovaps xmm2, [rsp+0x100]
000079a3731cf683  vpermilpd xmm2, xmm2, 0x00
000079a3731cf689  vmovaps [rsp+0xC0], xmm1
000079a3731cf692  vmovaps [rsp+0x120], xmm15
000079a3731cf69b  movaps xmm1, xmm10
000079a3731cf69f  mulpd xmm1, xmm2
000079a3731cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000079a3731cf6a8  ptest xmm15, xmm15
000079a3731cf6ae  jnz 0x000079A3731D0CCF
000079a3731cf6b4  xor eax, eax
000079a3731cf6b6  mov r12d, 0x40
000079a3731cf6bc  mov r11d, 0x200
000079a3731cf6c2  cmp r12, r11
000079a3731cf6c5  cmc
000079a3731cf6c6  lahf
000079a3731cf6c7  seto al
000079a3731cf6ca  mov [r15+0x108], eax
000079a3731cf6d1  vmovaps xmm10, [rsp+0x110]
000079a3731cf6da  vmovaps xmm2, [rsp+0xE0]
000079a3731cf6e3  vmovaps [rsp+0xE0], xmm1
000079a3731cf6ec  movaps xmm15, xmm10
000079a3731cf6f0  addpd xmm15, xmm2
000079a3731cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000079a3731cf6fb  ptest xmm1, xmm1
000079a3731cf700  jnz 0x000079A3731D0E10
000079a3731cf706  vmovaps xmm10, [rsp+0x120]
000079a3731cf70f  vmovaps [rsp+0x110], xmm15
000079a3731cf718  movaps xmm1, xmm10
000079a3731cf71c  addpd xmm1, xmm12
000079a3731cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000079a3731cf726  ptest xmm15, xmm15
000079a3731cf72c  jnz 0x000079A3731D0F53
000079a3731cf732  vmovaps xmm10, [rsp+0xC0]
000079a3731cf73b  vmovaps [rsp+0xC0], xmm1
000079a3731cf744  movaps xmm15, xmm10
000079a3731cf748  addpd xmm15, xmm12
000079a3731cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000079a3731cf753  ptest xmm1, xmm1
000079a3731cf758  jnz 0x000079A3731D1095
000079a3731cf75e  vmovaps xmm1, [rsp+0x30]
000079a3731cf764  vmovaps xmm12, [rsp+0x30]
000079a3731cf76a  por xmm1, xmm12
000079a3731cf76f  vmovaps xmm12, [rsp+0x20]
000079a3731cf775  vmovaps xmm10, [rsp+0x20]
000079a3731cf77b  por xmm12, xmm10
000079a3731cf780  vmovaps [rsp+0x20], xmm5
000079a3731cf786  vmovaps xmm10, [rsp+0x20]
000079a3731cf78c  por xmm5, xmm10
000079a3731cf791  vmovaps [rsp+0x20], xmm11
000079a3731cf797  vmovaps xmm10, [rsp+0x20]
000079a3731cf79d  por xmm11, xmm10
000079a3731cf7a2  vmovaps [rsp+0x20], xmm4
000079a3731cf7a8  vmovaps xmm10, [rsp+0x20]
000079a3731cf7ae  por xmm4, xmm10
000079a3731cf7b3  vmovaps [rsp+0x20], xmm8
000079a3731cf7b9  vmovaps xmm10, [rsp+0x20]
000079a3731cf7bf  por xmm8, xmm10
000079a3731cf7c4  vmovaps xmm10, [rsp+0xF0]
000079a3731cf7cd  vmovaps [rsp+0x20], xmm1
000079a3731cf7d3  vmovaps xmm1, [rsp+0xF0]
000079a3731cf7dc  por xmm10, xmm1
000079a3731cf7e1  lea rax, [r14+0xA0]
000079a3731cf7e8  movups xmm1, [r13+rax*1]
000079a3731cf7ee  lea rax, [r14+0xB0]
000079a3731cf7f5  vmovaps [rsp+0x30], xmm1
000079a3731cf7fb  movups xmm1, [r13+rax*1]
000079a3731cf801  vmovaps [rsp+0xF0], xmm1
000079a3731cf80a  vmovaps [rsp+0x120], xmm15
000079a3731cf813  movaps xmm1, xmm13
000079a3731cf817  addpd xmm1, xmm2
000079a3731cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000079a3731cf820  ptest xmm15, xmm15
000079a3731cf826  jnz 0x000079A3731D11ED
000079a3731cf82c  lea rax, [r14+0xF0]
000079a3731cf833  movups xmm15, [r13+rax*1]
000079a3731cf839  vmovaps xmm2, [rsp+0xC0]
000079a3731cf842  vmovaps [rsp+0xC0], xmm1
000079a3731cf84b  vmovaps xmm1, [rsp+0xE0]
000079a3731cf854  vmovaps [rsp+0xE0], xmm15
000079a3731cf85d  movaps xmm13, xmm2
000079a3731cf861  addpd xmm13, xmm1
000079a3731cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000079a3731cf86c  ptest xmm15, xmm15
000079a3731cf872  jnz 0x000079A3731D1338
000079a3731cf878  vmovaps xmm15, [rsp+0x120]
000079a3731cf881  vmovaps xmm2, [rsp+0xD0]
000079a3731cf88a  vmovaps [rsp+0xD0], xmm14
000079a3731cf893  movaps xmm1, xmm15
000079a3731cf897  addpd xmm1, xmm2
000079a3731cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000079a3731cf8a0  ptest xmm14, xmm14
000079a3731cf8a6  jnz 0x000079A3731D147A
000079a3731cf8ac  vmovaps xmm15, [rsp+0x100]
000079a3731cf8b5  vpermilpd xmm15, xmm15, 0x00
000079a3731cf8bb  vmovaps xmm2, [rsp+0xF0]
000079a3731cf8c4  vmovaps [rsp+0xF0], xmm1
000079a3731cf8cd  movaps xmm14, xmm2
000079a3731cf8d1  mulpd xmm14, xmm15
000079a3731cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000079a3731cf8dc  ptest xmm1, xmm1
000079a3731cf8e1  jnz 0x000079A3731D15BB
000079a3731cf8e7  vmovaps xmm1, [rsp+0xA0]
000079a3731cf8f0  vpermilpd xmm1, xmm1, 0x00
000079a3731cf8f6  vmovaps xmm2, [rsp+0xE0]
000079a3731cf8ff  vmovaps [rsp+0xE0], xmm14
000079a3731cf908  movaps xmm15, xmm2
000079a3731cf90c  mulpd xmm15, xmm1
000079a3731cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000079a3731cf917  ptest xmm14, xmm14
000079a3731cf91d  jnz 0x000079A3731D16FE
000079a3731cf923  lea rax, [r14+0xE0]
000079a3731cf92a  movups xmm1, [r13+rax*1]
000079a3731cf930  vmovaps xmm14, [rsp+0x100]
000079a3731cf939  vpermilpd xmm14, xmm14, 0x00
000079a3731cf93f  vmovaps [rsp+0x100], xmm1
000079a3731cf948  vmovaps xmm1, [rsp+0x30]
000079a3731cf94e  vmovaps [rsp+0x30], xmm15
000079a3731cf954  movaps xmm2, xmm1
000079a3731cf957  mulpd xmm2, xmm14
000079a3731cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000079a3731cf961  ptest xmm15, xmm15
000079a3731cf967  jnz 0x000079A3731D184A
000079a3731cf96d  vmovaps [rsp+0x120], xmm10
000079a3731cf976  vmovaps xmm1, [rsp+0x120]
000079a3731cf97f  por xmm10, xmm1
000079a3731cf984  movaps [r15+0x300], xmm10
000079a3731cf98c  vmovaps [rsp+0x120], xmm8
000079a3731cf995  vmovaps xmm1, [rsp+0x120]
000079a3731cf99e  por xmm8, xmm1
000079a3731cf9a3  movaps [r15+0x190], xmm8
000079a3731cf9ab  vmovaps xmm1, [rsp+0xA0]
000079a3731cf9b4  vpermilpd xmm1, xmm1, 0x00
000079a3731cf9ba  vmovaps xmm14, [rsp+0x100]
000079a3731cf9c3  vmovaps [rsp+0x100], xmm13
000079a3731cf9cc  movaps xmm15, xmm14
000079a3731cf9d0  mulpd xmm15, xmm1
000079a3731cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000079a3731cf9db  ptest xmm13, xmm13
000079a3731cf9e1  jnz 0x000079A3731D198B
000079a3731cf9e7  lea rax, [r14+0x90]
000079a3731cf9ee  movups xmm1, [r13+rax*1]
000079a3731cf9f4  vmovaps [rsp+0x120], xmm4
000079a3731cf9fd  vmovaps xmm14, [rsp+0x120]
000079a3731cfa06  por xmm4, xmm14
000079a3731cfa0b  movaps [r15+0x1C0], xmm4
000079a3731cfa13  vmovaps [rsp+0x120], xmm11
000079a3731cfa1c  vmovaps xmm14, [rsp+0x120]
000079a3731cfa25  por xmm11, xmm14
000079a3731cfa2a  movaps [r15+0x200], xmm11
000079a3731cfa32  vmovaps [rsp+0x120], xmm5
000079a3731cfa3b  vmovaps xmm14, [rsp+0x120]
000079a3731cfa44  por xmm5, xmm14
000079a3731cfa49  movaps [r15+0x2D0], xmm5
000079a3731cfa51  vmovaps [rsp+0x120], xmm12
000079a3731cfa5a  vmovaps xmm14, [rsp+0x120]
000079a3731cfa63  por xmm12, xmm14
000079a3731cfa68  movaps [r15+0x2E0], xmm12
000079a3731cfa70  vmovaps xmm13, [rsp+0x110]
000079a3731cfa79  vmovaps [rsp+0x110], xmm1
000079a3731cfa82  vmovaps xmm1, [rsp+0xE0]
000079a3731cfa8b  vmovaps [rsp+0xE0], xmm15
000079a3731cfa94  movaps xmm14, xmm13
000079a3731cfa98  addpd xmm14, xmm1
000079a3731cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000079a3731cfaa3  ptest xmm15, xmm15
000079a3731cfaa9  jnz 0x000079A3731D1AD8
000079a3731cfaaf  vmovaps xmm1, [rsp+0xA0]
000079a3731cfab8  vpermilpd xmm1, xmm1, 0x00
000079a3731cfabe  vmovaps xmm13, [rsp+0x110]
000079a3731cfac7  vmovaps [rsp+0x110], xmm14
000079a3731cfad0  movaps xmm15, xmm13
000079a3731cfad4  mulpd xmm15, xmm1
000079a3731cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000079a3731cfadf  ptest xmm14, xmm14
000079a3731cfae5  jnz 0x000079A3731D1C1B
000079a3731cfaeb  lea rax, [r14+0x80]
000079a3731cfaf2  movups xmm1, [r13+rax*1]
000079a3731cfaf8  vmovaps xmm13, [rsp+0xC0]
000079a3731cfb01  vmovaps [rsp+0xC0], xmm1
000079a3731cfb0a  movaps xmm14, xmm13
000079a3731cfb0e  addpd xmm14, xmm2
000079a3731cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000079a3731cfb19  ptest xmm1, xmm1
000079a3731cfb1e  jnz 0x000079A3731D1D68
000079a3731cfb24  vmovaps xmm13, [rsp+0x100]
000079a3731cfb2d  vmovaps xmm2, [rsp+0x30]
000079a3731cfb33  vmovaps [rsp+0x30], xmm15
000079a3731cfb39  movaps xmm1, xmm13
000079a3731cfb3d  addpd xmm1, xmm2
000079a3731cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000079a3731cfb46  ptest xmm15, xmm15
000079a3731cfb4c  jnz 0x000079A3731D1EAB
000079a3731cfb52  vmovaps xmm15, [rsp+0x20]
000079a3731cfb58  vmovaps xmm13, [rsp+0x20]
000079a3731cfb5e  por xmm15, xmm13
000079a3731cfb63  movaps [r15+0x2F0], xmm15
000079a3731cfb6b  vmovaps xmm13, [rsp+0xA0]
000079a3731cfb74  vpermilpd xmm13, xmm13, 0x00
000079a3731cfb7a  vmovaps [rsp+0x20], xmm1
000079a3731cfb80  vmovaps xmm1, [rsp+0xC0]
000079a3731cfb89  vmovaps [rsp+0xA0], xmm15
000079a3731cfb92  movaps xmm2, xmm1
000079a3731cfb95  mulpd xmm2, xmm13
000079a3731cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000079a3731cfb9f  ptest xmm15, xmm15
000079a3731cfba5  jnz 0x000079A3731D1FEC
000079a3731cfbab  lea rax, [r14+0xD0]
000079a3731cfbb2  movups xmm1, [r13+rax*1]
000079a3731cfbb8  vmovaps xmm13, [rsp+0xF0]
000079a3731cfbc1  vmovaps [rsp+0xC0], xmm1
000079a3731cfbca  vmovaps xmm1, [rsp+0xE0]
000079a3731cfbd3  vmovaps [rsp+0xE0], xmm14
000079a3731cfbdc  movaps xmm15, xmm13
000079a3731cfbe0  addpd xmm15, xmm1
000079a3731cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000079a3731cfbeb  ptest xmm14, xmm14
000079a3731cfbf1  jnz 0x000079A3731D2137
000079a3731cfbf7  vmovaps xmm1, [rsp+0xB0]
000079a3731cfc00  vpermilpd xmm1, xmm1, 0x00
000079a3731cfc06  movaps xmm14, xmm11
000079a3731cfc0a  mulpd xmm14, xmm1
000079a3731cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000079a3731cfc15  ptest xmm13, xmm13
000079a3731cfc1b  jnz 0x000079A3731D227A
000079a3731cfc21  movaps [r15+0x260], xmm14
000079a3731cfc29  vxorps xmm1, xmm1, xmm1
000079a3731cfc2d  vpbroadcastq xmm1, xmm1
000079a3731cfc32  movaps [r15+0x1B0], xmm1
000079a3731cfc3a  vmovaps xmm1, [rsp+0xB0]
000079a3731cfc43  vpermilpd xmm1, xmm1, 0x00
000079a3731cfc49  vmovaps xmm11, [rsp+0xC0]
000079a3731cfc52  vmovaps [rsp+0xC0], xmm15
000079a3731cfc5b  movaps xmm13, xmm11
000079a3731cfc5f  mulpd xmm13, xmm1
000079a3731cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000079a3731cfc6a  ptest xmm15, xmm15
000079a3731cfc70  jnz 0x000079A3731D23BD
000079a3731cfc76  lea rax, [r14+0xC0]
000079a3731cfc7d  movups xmm1, [r13+rax*1]
000079a3731cfc83  vmovaps xmm11, [rsp+0x110]
000079a3731cfc8c  vmovaps [rsp+0xF0], xmm1
000079a3731cfc95  vmovaps xmm1, [rsp+0x30]
000079a3731cfc9b  vmovaps [rsp+0x30], xmm14
000079a3731cfca1  movaps xmm15, xmm11
000079a3731cfca5  addpd xmm15, xmm1
000079a3731cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000079a3731cfcb0  ptest xmm14, xmm14
000079a3731cfcb6  jnz 0x000079A3731D250A
000079a3731cfcbc  vmovaps [rsp+0x100], xmm9
000079a3731cfcc5  vmovaps xmm1, [rsp+0x100]
000079a3731cfcce  por xmm9, xmm1
000079a3731cfcd3  movaps [r15+0x270], xmm9
000079a3731cfcdb  vmovaps [rsp+0x100], xmm6
000079a3731cfce4  vmovaps xmm1, [rsp+0x100]
000079a3731cfced  por xmm6, xmm1
000079a3731cfcf1  movaps [r15+0x1A0], xmm6
000079a3731cfcf9  vmovaps xmm14, [rsp+0xB0]
000079a3731cfd02  vpermilpd xmm14, xmm14, 0x00
000079a3731cfd08  vmovaps xmm6, [rsp+0xF0]
000079a3731cfd11  vmovaps [rsp+0xF0], xmm1
000079a3731cfd1a  movaps xmm11, xmm6
000079a3731cfd1e  mulpd xmm11, xmm14
000079a3731cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000079a3731cfd29  ptest xmm1, xmm1
000079a3731cfd2e  jnz 0x000079A3731D264D
000079a3731cfd34  lea rax, [r14+0x20]
000079a3731cfd38  movups xmm1, [r13+rax*1]
000079a3731cfd3e  movaps [r15+0x110], xmm1
000079a3731cfd46  vmovaps xmm6, [rsp+0xE0]
000079a3731cfd4f  vmovaps [rsp+0xE0], xmm1
000079a3731cfd58  movaps xmm14, xmm6
000079a3731cfd5c  addpd xmm14, xmm2
000079a3731cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000079a3731cfd67  ptest xmm1, xmm1
000079a3731cfd6c  jnz 0x000079A3731D279A
000079a3731cfd72  vmovaps xmm1, [rsp+0xB0]
000079a3731cfd7b  vpermilpd xmm1, xmm1, 0x00
000079a3731cfd81  movaps xmm6, xmm5
000079a3731cfd84  mulpd xmm6, xmm1
000079a3731cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000079a3731cfd8d  ptest xmm2, xmm2
000079a3731cfd92  jnz 0x000079A3731D28DC
000079a3731cfd98  vmovaps xmm5, [rsp+0x20]
000079a3731cfd9e  movaps xmm1, xmm5
000079a3731cfda1  addpd xmm1, xmm13
000079a3731cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000079a3731cfdab  ptest xmm2, xmm2
000079a3731cfdb0  jnz 0x000079A3731D2A1C
000079a3731cfdb6  vmovaps xmm13, [rsp+0x80]
000079a3731cfdbf  vpermilpd xmm13, xmm13, 0x00
000079a3731cfdc5  vmovaps xmm2, [rsp+0xE0]
000079a3731cfdce  vmovaps [rsp+0x20], xmm1
000079a3731cfdd4  movaps xmm5, xmm2
000079a3731cfdd7  mulpd xmm5, xmm13
000079a3731cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000079a3731cfde1  ptest xmm1, xmm1
000079a3731cfde6  jnz 0x000079A3731D2B5D
000079a3731cfdec  vmovaps xmm1, [rsp+0x80]
000079a3731cfdf5  vpermilpd xmm1, xmm1, 0x00
000079a3731cfdfb  movaps xmm13, xmm10
000079a3731cfdff  mulpd xmm13, xmm1
000079a3731cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000079a3731cfe0a  ptest xmm2, xmm2
000079a3731cfe0f  jnz 0x000079A3731D2C9E
000079a3731cfe15  vmovaps xmm10, [rsp+0x30]
000079a3731cfe1b  movaps xmm1, xmm15
000079a3731cfe1f  addpd xmm1, xmm10
000079a3731cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000079a3731cfe29  ptest xmm2, xmm2
000079a3731cfe2e  jnz 0x000079A3731D2DE1
000079a3731cfe34  vmovaps xmm10, [rsp+0xC0]
000079a3731cfe3d  movaps xmm15, xmm10
000079a3731cfe41  addpd xmm15, xmm11
000079a3731cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000079a3731cfe4c  ptest xmm2, xmm2
000079a3731cfe51  jnz 0x000079A3731D2F23
000079a3731cfe57  vmovaps xmm11, [rsp+0x80]
000079a3731cfe60  vpermilpd xmm11, xmm11, 0x00
000079a3731cfe66  movaps xmm10, xmm12
000079a3731cfe6a  mulpd xmm10, xmm11
000079a3731cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000079a3731cfe75  ptest xmm2, xmm2
000079a3731cfe7a  jnz 0x000079A3731D3067
000079a3731cfe80  vmovaps xmm12, [rsp+0x80]
000079a3731cfe89  vpermilpd xmm12, xmm12, 0x00
000079a3731cfe8f  vmovaps xmm2, [rsp+0xA0]
000079a3731cfe98  vmovaps [rsp+0x30], xmm1
000079a3731cfe9e  movaps xmm11, xmm2
000079a3731cfea2  mulpd xmm11, xmm12
000079a3731cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000079a3731cfead  ptest xmm1, xmm1
000079a3731cfeb2  jnz 0x000079A3731D31AB
000079a3731cfeb8  movaps xmm1, xmm14
000079a3731cfebc  addpd xmm1, xmm6
000079a3731cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000079a3731cfec5  ptest xmm12, xmm12
000079a3731cfecb  jnz 0x000079A3731D32EE
000079a3731cfed1  vmovaps xmm12, [rsp+0x20]
000079a3731cfed7  movaps xmm14, xmm12
000079a3731cfedb  addpd xmm14, xmm5
000079a3731cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000079a3731cfee6  ptest xmm6, xmm6
000079a3731cfeeb  jnz 0x000079A3731D342F
000079a3731cfef1  vmovaps xmm12, [rsp+0x90]
000079a3731cfefa  vpermilpd xmm12, xmm12, 0x00
000079a3731cff00  movaps xmm6, xmm9
000079a3731cff04  mulpd xmm6, xmm12
000079a3731cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000079a3731cff0e  ptest xmm5, xmm5
000079a3731cff13  jnz 0x000079A3731D3572
000079a3731cff19  movaps xmm12, xmm15
000079a3731cff1d  addpd xmm12, xmm13
000079a3731cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000079a3731cff28  ptest xmm9, xmm9
000079a3731cff2e  jnz 0x000079A3731D36B4
000079a3731cff34  vmovaps xmm13, [rsp+0x30]
000079a3731cff3a  movaps xmm15, xmm13
000079a3731cff3e  addpd xmm15, xmm10
000079a3731cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000079a3731cff49  ptest xmm9, xmm9
000079a3731cff4f  jnz 0x000079A3731D37F8
000079a3731cff55  vmovaps xmm13, [rsp+0xD0]
000079a3731cff5e  vmovaps xmm10, [rsp+0xD0]
000079a3731cff67  por xmm13, xmm10
000079a3731cff6c  movaps [r15+0x250], xmm13
000079a3731cff74  vmovaps [rsp+0x20], xmm7
000079a3731cff7a  vmovaps xmm13, [rsp+0x20]
000079a3731cff80  por xmm7, xmm13
000079a3731cff85  movaps [r15+0x2A0], xmm7
000079a3731cff8d  vmovaps [rsp+0x20], xmm3
000079a3731cff93  vmovaps xmm13, [rsp+0x20]
000079a3731cff99  por xmm3, xmm13
000079a3731cff9e  movaps [r15+0x1D0], xmm3
000079a3731cffa6  lea rax, [r14+0x40]
000079a3731cffaa  movups xmm13, [r13+rax*1]
000079a3731cffb0  movaps [r15+0x2C0], xmm13
000079a3731cffb8  vmovaps xmm10, [rsp+0x90]
000079a3731cffc1  vpermilpd xmm10, xmm10, 0x00
000079a3731cffc7  movaps xmm9, xmm8
000079a3731cffcb  mulpd xmm9, xmm10
000079a3731cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000079a3731cffd6  ptest xmm5, xmm5
000079a3731cffdb  jnz 0x000079A3731D3946
000079a3731cffe1  movaps xmm10, xmm1
000079a3731cffe5  addpd xmm10, xmm11
000079a3731cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000079a3731cfff0  ptest xmm8, xmm8
000079a3731cfff6  jnz 0x000079A3731D3A8A
000079a3731cfffc  movaps xmm1, xmm14
000079a3731d0000  addpd xmm1, xmm6
000079a3731d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000079a3731d0009  ptest xmm11, xmm11
000079a3731d000f  jnz 0x000079A3731D3BCD
000079a3731d0015  vmovaps xmm14, [rsp+0x90]
000079a3731d001e  vpermilpd xmm14, xmm14, 0x00
000079a3731d0024  movaps xmm11, xmm13
000079a3731d0028  mulpd xmm11, xmm14
000079a3731d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000079a3731d0033  ptest xmm8, xmm8
000079a3731d0039  jnz 0x000079A3731D3D0E
000079a3731d003f  vmovaps xmm14, [rsp+0x90]
000079a3731d0048  vpermilpd xmm14, xmm14, 0x00
000079a3731d004e  vmovaps xmm8, [rsp+0x10]
000079a3731d0054  movaps xmm13, xmm8
000079a3731d0058  mulpd xmm13, xmm14
000079a3731d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000079a3731d0063  ptest xmm6, xmm6
000079a3731d0068  jnz 0x000079A3731D3E52
000079a3731d006e  vmovaps xmm14, [rsp+0x60]
000079a3731d0074  vpermilpd xmm14, xmm14, 0x00
000079a3731d007a  movaps xmm8, xmm7
000079a3731d007e  mulpd xmm8, xmm14
000079a3731d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000079a3731d0089  ptest xmm6, xmm6
000079a3731d008e  jnz 0x000079A3731D3F96
000079a3731d0094  movaps xmm14, xmm12
000079a3731d0098  addpd xmm14, xmm9
000079a3731d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000079a3731d00a3  ptest xmm7, xmm7
000079a3731d00a8  jnz 0x000079A3731D40D9
000079a3731d00ae  vmovaps xmm12, [rsp+0x60]
000079a3731d00b4  vpermilpd xmm12, xmm12, 0x00
000079a3731d00ba  vmovaps xmm7, [rsp+0xF0]
000079a3731d00c3  movaps xmm9, xmm7
000079a3731d00c7  mulpd xmm9, xmm12
000079a3731d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000079a3731d00d2  ptest xmm6, xmm6
000079a3731d00d7  jnz 0x000079A3731D421D
000079a3731d00dd  movaps xmm12, xmm15
000079a3731d00e1  addpd xmm12, xmm11
000079a3731d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000079a3731d00ec  ptest xmm7, xmm7
000079a3731d00f1  jnz 0x000079A3731D4360
000079a3731d00f7  vmovaps xmm15, [rsp+0x60]
000079a3731d00fd  vpermilpd xmm15, xmm15, 0x00
000079a3731d0103  vmovaps xmm7, [rsp+0x40]
000079a3731d0109  movaps xmm11, xmm7
000079a3731d010d  mulpd xmm11, xmm15
000079a3731d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000079a3731d0118  ptest xmm6, xmm6
000079a3731d011d  jnz 0x000079A3731D44A4
000079a3731d0123  movaps xmm15, xmm10
000079a3731d0127  addpd xmm15, xmm13
000079a3731d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000079a3731d0132  ptest xmm7, xmm7
000079a3731d0137  jnz 0x000079A3731D45E7
000079a3731d013d  vmovaps xmm13, [rsp+0x60]
000079a3731d0143  vpermilpd xmm13, xmm13, 0x00
000079a3731d0149  vmovaps xmm7, [rsp+0x50]
000079a3731d014f  movaps xmm10, xmm7
000079a3731d0153  mulpd xmm10, xmm13
000079a3731d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000079a3731d015e  ptest xmm6, xmm6
000079a3731d0163  jnz 0x000079A3731D472B
000079a3731d0169  movaps xmm13, xmm1
000079a3731d016d  addpd xmm13, xmm8
000079a3731d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000079a3731d0178  ptest xmm7, xmm7
000079a3731d017d  jnz 0x000079A3731D486E
000079a3731d0183  lea rax, [r14+0x70]
000079a3731d0187  movups xmm1, [r13+rax*1]
000079a3731d018d  movaps [r15+0x240], xmm1
000079a3731d0195  movaps xmm8, xmm14
000079a3731d0199  addpd xmm8, xmm9
000079a3731d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000079a3731d01a4  ptest xmm7, xmm7
000079a3731d01a9  jnz 0x000079A3731D49BB
000079a3731d01af  movaps [r15+0x170], xmm8
000079a3731d01b7  vmovaps xmm14, [rsp+0x70]
000079a3731d01bd  vpermilpd xmm14, xmm14, 0x00
000079a3731d01c3  movaps xmm9, xmm1
000079a3731d01c7  mulpd xmm9, xmm14
000079a3731d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000079a3731d01d2  ptest xmm7, xmm7
000079a3731d01d7  jnz 0x000079A3731D4AFF
000079a3731d01dd  vmovaps xmm1, [rsp+0x70]
000079a3731d01e3  vpermilpd xmm1, xmm1, 0x00
000079a3731d01e9  movaps xmm14, xmm4
000079a3731d01ed  mulpd xmm14, xmm1
000079a3731d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000079a3731d01f8  ptest xmm7, xmm7
000079a3731d01fd  jnz 0x000079A3731D4C42
000079a3731d0203  movaps [r15+0x180], xmm14
000079a3731d020b  movaps xmm1, xmm12
000079a3731d020f  addpd xmm1, xmm11
000079a3731d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000079a3731d0219  ptest xmm7, xmm7
000079a3731d021e  jnz 0x000079A3731D4D84
000079a3731d0224  movaps [r15+0x210], xmm1
000079a3731d022c  movups xmm12, [r13+r14*1]
000079a3731d0232  lea rax, [r14+0x10]
000079a3731d0236  movups xmm11, [r13+rax*1]
000079a3731d023c  movaps [r15+0x230], xmm11
000079a3731d0244  movaps xmm7, xmm15
000079a3731d0248  addpd xmm7, xmm10
000079a3731d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000079a3731d0252  ptest xmm6, xmm6
000079a3731d0257  jnz 0x000079A3731D4EDA
000079a3731d025d  movaps [r15+0x130], xmm7
000079a3731d0265  vmovaps xmm15, [rsp+0x70]
000079a3731d026b  vpermilpd xmm15, xmm15, 0x00
000079a3731d0271  movaps xmm10, xmm11
000079a3731d0275  mulpd xmm10, xmm15
000079a3731d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000079a3731d0280  ptest xmm6, xmm6
000079a3731d0285  jnz 0x000079A3731D501C
000079a3731d028b  movaps [r15+0x220], xmm10
000079a3731d0293  vmovaps xmm15, [rsp+0x70]
000079a3731d0299  vpermilpd xmm15, xmm15, 0x00
000079a3731d029f  movaps xmm11, xmm12
000079a3731d02a3  mulpd xmm11, xmm15
000079a3731d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000079a3731d02ae  ptest xmm6, xmm6
000079a3731d02b3  jnz 0x000079A3731D5160
000079a3731d02b9  movaps xmm15, xmm13
000079a3731d02bd  addpd xmm15, xmm9
000079a3731d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000079a3731d02c8  ptest xmm12, xmm12
000079a3731d02ce  jnz 0x000079A3731D52A4
000079a3731d02d4  movaps [r15+0x140], xmm15
000079a3731d02dc  movaps xmm13, xmm8
000079a3731d02e0  addpd xmm13, xmm14
000079a3731d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000079a3731d02eb  ptest xmm12, xmm12
000079a3731d02f1  jnz 0x000079A3731D53E8
000079a3731d02f7  movaps [r15+0x150], xmm13
000079a3731d02ff  movaps xmm14, xmm1
000079a3731d0303  addpd xmm14, xmm10
000079a3731d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000079a3731d030e  ptest xmm12, xmm12
000079a3731d0314  jnz 0x000079A3731D552C
000079a3731d031a  movaps [r15+0x160], xmm14
000079a3731d0322  movaps xmm1, xmm7
000079a3731d0325  addpd xmm1, xmm11
000079a3731d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000079a3731d032f  ptest xmm12, xmm12
000079a3731d0335  jnz 0x000079A3731D566F
000079a3731d033b  movaps [r15+0x120], xmm1
000079a3731d0343  mov eax, 0x430920
000079a3731d0348  movups [r13+rax*1], xmm15
000079a3731d034e  mov eax, 0x430930
000079a3731d0353  movups [r13+rax*1], xmm13
000079a3731d0359  mov eax, 0x430940
000079a3731d035e  movups [r13+rax*1], xmm14
000079a3731d0364  mov eax, 0x430950
000079a3731d0369  movups [r13+rax*1], xmm1
000079a3731d036f  mov eax, [r15+0x108]
000079a3731d0376  sahf
000079a3731d0377  jnz 0x000079A3731D03A9
000079a3731d0379  cmp dword ptr [r15+0x318], 0x00
000079a3731d0381  jz 0x000079A3731DB900
000079a3731d0387  nop [rax+rax*1], ax
000079a3731d0390  nop [rax+rax*1], eax
000079a3731d0398  mov eax, 0x410444
000079a3731d039d  mov [r15+0x100], rax
000079a3731d03a4  jmp 0x000079A372FFE110
000079a3731d03a9  cmp dword ptr [r15+0x318], 0x00
000079a3731d03b1  jz 0x000079A3731D57E0
000079a3731d03b7  nop [rax+rax*1], ax
000079a3731d03c0  nop [rax+rax*1], eax
000079a3731d03c8  mov eax, 0x410278
000079a3731d03cd  mov [r15+0x100], rax
000079a3731d03d4  jmp 0x000079A372FFE110
000079a3731d03d9  int3
000079a3731d03da  call 0x000079A3730B52F0
000079a3731d03df  jmp 0x000079A3731CF016
000079a3731d03e4  call 0x000079A3730C4620
000079a3731d03e9  jmp 0x000079A3731CF023
000079a3731d03ee  call 0x000079A3730C33A0
000079a3731d03f3  jmp 0x000079A3731CF035
000079a3731d03f8  call 0x000079A3730C2120
000079a3731d03fd  jmp 0x000079A3731CF03F
000079a3731d0402  call 0x000079A3730C0860
000079a3731d0407  jmp 0x000079A3731CF067
000079a3731d040c  call 0x000079A3730BF5F0
000079a3731d0411  jmp 0x000079A3731CF073
000079a3731d0416  call 0x000079A3730C0860
000079a3731d041b  jmp 0x000079A3731CF0A5
000079a3731d0420  call 0x000079A3730BF5F0
000079a3731d0425  jmp 0x000079A3731CF0B1
000079a3731d042a  call 0x000079A3730C4740
000079a3731d042f  jmp 0x000079A3731CF0BE
000079a3731d0434  call 0x000079A3730B5400
000079a3731d0439  jmp 0x000079A3731CF0CB
000079a3731d043e  call 0x000079A3730B52F0
000079a3731d0443  jmp 0x000079A3731CF0D8
000079a3731d0448  call 0x000079A3730C4620
000079a3731d044d  jmp 0x000079A3731CF0E5
000079a3731d0452  call 0x000079A3730C0860
000079a3731d0457  jmp 0x000079A3731CF10D
000079a3731d045c  call 0x000079A3730BF5F0
000079a3731d0461  jmp 0x000079A3731CF119
000079a3731d0466  call 0x000079A373009D70
000079a3731d046b  jmp 0x000079A3731CF11F
000079a3731d0470  call 0x000079A3730BE9C0
000079a3731d0475  jmp 0x000079A3731CF129
000079a3731d047a  call 0x000079A3730C0860
000079a3731d047f  jmp 0x000079A3731CF151
000079a3731d0484  call 0x000079A3730BF5F0
000079a3731d0489  jmp 0x000079A3731CF15D
000079a3731d048e  call 0x000079A3730BD750
000079a3731d0493  jmp 0x000079A3731CF16A
000079a3731d0498  call 0x000079A3730BC4E0
000079a3731d049d  jmp 0x000079A3731CF177
000079a3731d04a2  call 0x000079A3730C4740
000079a3731d04a7  jmp 0x000079A3731CF184
000079a3731d04ac  call 0x000079A3730B5400
000079a3731d04b1  jmp 0x000079A3731CF191
000079a3731d04b6  call 0x000079A3730B52F0
000079a3731d04bb  jmp 0x000079A3731CF19E
000079a3731d04c0  call 0x000079A3730C4620
000079a3731d04c5  jmp 0x000079A3731CF1AB
000079a3731d04ca  call 0x000079A3730C0860
000079a3731d04cf  jmp 0x000079A3731CF1BE
000079a3731d04d4  call 0x000079A3730BB270
000079a3731d04d9  jmp 0x000079A3731CF1CB
000079a3731d04de  call 0x000079A3730BA000
000079a3731d04e3  jmp 0x000079A3731CF1D8
000079a3731d04e8  call 0x000079A3730B8D90
000079a3731d04ed  jmp 0x000079A3731CF1E5
000079a3731d04f2  call 0x000079A3730B8A20
000079a3731d04f7  jmp 0x000079A3731CF1F2
000079a3731d04fc  call 0x000079A3730B5400
000079a3731d0501  jmp 0x000079A3731CF1FC
000079a3731d0506  call 0x000079A3730C2240
000079a3731d050b  jmp 0x000079A3731CF206
000079a3731d0510  call 0x000079A3730B52F0
000079a3731d0515  jmp 0x000079A3731CF210
000079a3731d051a  call 0x000079A3730C2120
000079a3731d051f  jmp 0x000079A3731CF21A
000079a3731d0524  call 0x000079A3730B77B0
000079a3731d0529  jmp 0x000079A3731CF224
000079a3731d052e  call 0x000079A3730B6550
000079a3731d0533  jmp 0x000079A3731CF22E
000079a3731d0538  call 0x000079A3730BFD50
000079a3731d053d  jmp 0x000079A3731CF240
000079a3731d0542  call 0x000079A3730B8EA0
000079a3731d0547  jmp 0x000079A3731CF24A
000079a3731d054c  call 0x000079A3730BFC30
000079a3731d0551  jmp 0x000079A3731CF257
000079a3731d0556  call 0x000079A3730B8D90
000079a3731d055b  jmp 0x000079A3731CF264
000079a3731d0560  call 0x000079A3730C2240
000079a3731d0565  jmp 0x000079A3731CF271
000079a3731d056a  call 0x000079A3730B5400
000079a3731d056f  jmp 0x000079A3731CF27E
000079a3731d0574  call 0x000079A3730B52F0
000079a3731d0579  jmp 0x000079A3731CF28B
000079a3731d057e  call 0x000079A3730C2120
000079a3731d0583  jmp 0x000079A3731CF298
000079a3731d0588  call 0x000079A3730B52F0
000079a3731d058d  jmp 0x000079A3731CF2AB
000079a3731d0592  call 0x000079A3730B52F0
000079a3731d0597  jmp 0x000079A3731CF2BE
000079a3731d059c  call 0x000079A3730B52F0
000079a3731d05a1  jmp 0x000079A3731CF2D1
000079a3731d05a6  call 0x000079A3730B52F0
000079a3731d05ab  jmp 0x000079A3731CF2E4
000079a3731d05b0  call 0x000079A3730C2240
000079a3731d05b5  jmp 0x000079A3731CF2F9
000079a3731d05ba  call 0x000079A3730C2240
000079a3731d05bf  jmp 0x000079A3731CF30C
000079a3731d05c4  call 0x000079A3730C2120
000079a3731d05c9  jmp 0x000079A3731CF319
000079a3731d05ce  call 0x000079A3730B52F0
000079a3731d05d3  jmp 0x000079A3731CF32C
000079a3731d05d8  call 0x000079A3730B52F0
000079a3731d05dd  jmp 0x000079A3731CF34F
000079a3731d05e2  call 0x000079A3730B52F0
000079a3731d05e7  jmp 0x000079A3731CF362
000079a3731d05ec  call 0x000079A372FFF540
000079a3731d05f1  jmp 0x000079A3731CF380
000079a3731d05f6  call 0x000079A373008C20
000079a3731d05fb  jmp 0x000079A3731CF38A
000079a3731d0600  call 0x000079A3730D6600
000079a3731d0605  jmp 0x000079A3731CF396
000079a3731d060a  call 0x000079A372FFF540
000079a3731d060f  jmp 0x000079A3731CF3A6
000079a3731d0614  call 0x000079A3730C0370
000079a3731d0619  jmp 0x000079A3731CF3D4
000079a3731d061e  call 0x000079A3730BF100
000079a3731d0623  jmp 0x000079A3731CF3DD
000079a3731d0628  call 0x000079A3730C0370
000079a3731d062d  jmp 0x000079A3731CF43B
000079a3731d0632  call 0x000079A3730BF100
000079a3731d0637  jmp 0x000079A3731CF444
000079a3731d063c  call 0x000079A3730C0370
000079a3731d0641  jmp 0x000079A3731CF48B
000079a3731d0646  call 0x000079A3730BF100
000079a3731d064b  jmp 0x000079A3731CF494
000079a3731d0650  call 0x000079A37300B720
000079a3731d0655  jmp 0x000079A3731CF4D7
000079a3731d065a  call 0x000079A3730B47C0
000079a3731d065f  jmp 0x000079A3731CF4EA
000079a3731d0664  call 0x000079A373008B00
000079a3731d0669  jmp 0x000079A3731CF501
000079a3731d066e  call 0x000079A372FFF430
000079a3731d0673  jmp 0x000079A3731CF514
000079a3731d0678  call 0x000079A372FFF430
000079a3731d067d  jmp 0x000079A3731CF527
000079a3731d0682  sub rsp, 0x08
000079a3731d0686  push rax
000079a3731d0687  push rcx
000079a3731d0688  push rdx
000079a3731d0689  push rdi
000079a3731d068a  push rsi
000079a3731d068b  push r8
000079a3731d068d  push r9
000079a3731d068f  push r10
000079a3731d0691  push r11
000079a3731d0693  sub rsp, 0xF0
000079a3731d069a  vmovaps [rsp], xmm0
000079a3731d069f  vmovaps [rsp+0x10], xmm2
000079a3731d06a5  vmovaps [rsp+0x20], xmm3
000079a3731d06ab  vmovaps [rsp+0x30], xmm4
000079a3731d06b1  vmovaps [rsp+0x40], xmm5
000079a3731d06b7  vmovaps [rsp+0x50], xmm6
000079a3731d06bd  vmovaps [rsp+0x60], xmm7
000079a3731d06c3  vmovaps [rsp+0x70], xmm8
000079a3731d06c9  vmovaps [rsp+0x80], xmm9
000079a3731d06d2  vmovaps [rsp+0x90], xmm10
000079a3731d06db  vmovaps [rsp+0xA0], xmm11
000079a3731d06e4  vmovaps [rsp+0xB0], xmm12
000079a3731d06ed  vmovaps [rsp+0xC0], xmm13
000079a3731d06f6  vmovaps [rsp+0xD0], xmm14
000079a3731d06ff  vmovaps [rsp+0xE0], xmm15
000079a3731d0708  sub rsp, 0x30
000079a3731d070c  movaps [rsp], xmm1
000079a3731d0710  movaps [rsp+0x10], xmm15
000079a3731d0716  movaps [rsp+0x20], xmm14
000079a3731d071c  lea rdi, [rsp]
000079a3731d0720  mov esi, 0x00
000079a3731d0725  mov rax, 0x64F127B95530
000079a3731d072f  call rax
000079a3731d0731  movaps xmm1, [rsp]
000079a3731d0735  add rsp, 0x30
000079a3731d0739  vmovaps xmm0, [rsp]
000079a3731d073e  vmovaps xmm2, [rsp+0x10]
000079a3731d0744  vmovaps xmm3, [rsp+0x20]
000079a3731d074a  vmovaps xmm4, [rsp+0x30]
000079a3731d0750  vmovaps xmm5, [rsp+0x40]
000079a3731d0756  vmovaps xmm6, [rsp+0x50]
000079a3731d075c  vmovaps xmm7, [rsp+0x60]
000079a3731d0762  vmovaps xmm8, [rsp+0x70]
000079a3731d0768  vmovaps xmm9, [rsp+0x80]
000079a3731d0771  vmovaps xmm10, [rsp+0x90]
000079a3731d077a  vmovaps xmm11, [rsp+0xA0]
000079a3731d0783  vmovaps xmm12, [rsp+0xB0]
000079a3731d078c  vmovaps xmm13, [rsp+0xC0]
000079a3731d0795  vmovaps xmm14, [rsp+0xD0]
000079a3731d079e  vmovaps xmm15, [rsp+0xE0]
000079a3731d07a7  add rsp, 0xF0
000079a3731d07ae  pop r11
000079a3731d07b0  pop r10
000079a3731d07b2  pop r9
000079a3731d07b4  pop r8
000079a3731d07b6  pop rsi
000079a3731d07b7  pop rdi
000079a3731d07b8  pop rdx
000079a3731d07b9  pop rcx
000079a3731d07ba  pop rax
000079a3731d07bb  add rsp, 0x08
000079a3731d07bf  jmp 0x000079A3731CF581
000079a3731d07c4  sub rsp, 0x08
000079a3731d07c8  push rax
000079a3731d07c9  push rcx
000079a3731d07ca  push rdx
000079a3731d07cb  push rdi
000079a3731d07cc  push rsi
000079a3731d07cd  push r8
000079a3731d07cf  push r9
000079a3731d07d1  push r10
000079a3731d07d3  push r11
000079a3731d07d5  sub rsp, 0xF0
000079a3731d07dc  vmovaps [rsp], xmm0
000079a3731d07e1  vmovaps [rsp+0x10], xmm1
000079a3731d07e7  vmovaps [rsp+0x20], xmm2
000079a3731d07ed  vmovaps [rsp+0x30], xmm3
000079a3731d07f3  vmovaps [rsp+0x40], xmm4
000079a3731d07f9  vmovaps [rsp+0x50], xmm5
000079a3731d07ff  vmovaps [rsp+0x60], xmm6
000079a3731d0805  vmovaps [rsp+0x70], xmm7
000079a3731d080b  vmovaps [rsp+0x80], xmm8
000079a3731d0814  vmovaps [rsp+0x90], xmm9
000079a3731d081d  vmovaps [rsp+0xA0], xmm10
000079a3731d0826  vmovaps [rsp+0xB0], xmm11
000079a3731d082f  vmovaps [rsp+0xC0], xmm12
000079a3731d0838  vmovaps [rsp+0xD0], xmm14
000079a3731d0841  vmovaps [rsp+0xE0], xmm15
000079a3731d084a  sub rsp, 0x30
000079a3731d084e  movaps [rsp], xmm13
000079a3731d0853  movaps [rsp+0x10], xmm1
000079a3731d0858  movaps [rsp+0x20], xmm14
000079a3731d085e  lea rdi, [rsp]
000079a3731d0862  mov esi, 0x00
000079a3731d0867  mov rax, 0x64F127B95530
000079a3731d0871  call rax
000079a3731d0873  movaps xmm13, [rsp]
000079a3731d0878  add rsp, 0x30
000079a3731d087c  vmovaps xmm0, [rsp]
000079a3731d0881  vmovaps xmm1, [rsp+0x10]
000079a3731d0887  vmovaps xmm2, [rsp+0x20]
000079a3731d088d  vmovaps xmm3, [rsp+0x30]
000079a3731d0893  vmovaps xmm4, [rsp+0x40]
000079a3731d0899  vmovaps xmm5, [rsp+0x50]
000079a3731d089f  vmovaps xmm6, [rsp+0x60]
000079a3731d08a5  vmovaps xmm7, [rsp+0x70]
000079a3731d08ab  vmovaps xmm8, [rsp+0x80]
000079a3731d08b4  vmovaps xmm9, [rsp+0x90]
000079a3731d08bd  vmovaps xmm10, [rsp+0xA0]
000079a3731d08c6  vmovaps xmm11, [rsp+0xB0]
000079a3731d08cf  vmovaps xmm12, [rsp+0xC0]
000079a3731d08d8  vmovaps xmm14, [rsp+0xD0]
000079a3731d08e1  vmovaps xmm15, [rsp+0xE0]
000079a3731d08ea  add rsp, 0xF0
000079a3731d08f1  pop r11
000079a3731d08f3  pop r10
000079a3731d08f5  pop r9
000079a3731d08f7  pop r8
000079a3731d08f9  pop rsi
000079a3731d08fa  pop rdi
000079a3731d08fb  pop rdx
000079a3731d08fc  pop rcx
000079a3731d08fd  pop rax
000079a3731d08fe  add rsp, 0x08
000079a3731d0902  jmp 0x000079A3731CF5CF
000079a3731d0907  sub rsp, 0x08
000079a3731d090b  push rax
000079a3731d090c  push rcx
000079a3731d090d  push rdx
000079a3731d090e  push rdi
000079a3731d090f  push rsi
000079a3731d0910  push r8
000079a3731d0912  push r9
000079a3731d0914  push r10
000079a3731d0916  push r11
000079a3731d0918  sub rsp, 0xF0
000079a3731d091f  vmovaps [rsp], xmm0
000079a3731d0924  vmovaps [rsp+0x10], xmm1
000079a3731d092a  vmovaps [rsp+0x20], xmm2
000079a3731d0930  vmovaps [rsp+0x30], xmm3
000079a3731d0936  vmovaps [rsp+0x40], xmm4
000079a3731d093c  vmovaps [rsp+0x50], xmm5
000079a3731d0942  vmovaps [rsp+0x60], xmm6
000079a3731d0948  vmovaps [rsp+0x70], xmm7
000079a3731d094e  vmovaps [rsp+0x80], xmm8
000079a3731d0957  vmovaps [rsp+0x90], xmm9
000079a3731d0960  vmovaps [rsp+0xA0], xmm10
000079a3731d0969  vmovaps [rsp+0xB0], xmm11
000079a3731d0972  vmovaps [rsp+0xC0], xmm12
000079a3731d097b  vmovaps [rsp+0xD0], xmm13
000079a3731d0984  vmovaps [rsp+0xE0], xmm14
000079a3731d098d  sub rsp, 0x30
000079a3731d0991  movaps [rsp], xmm15
000079a3731d0996  movaps [rsp+0x10], xmm14
000079a3731d099c  movaps [rsp+0x20], xmm1
000079a3731d09a1  lea rdi, [rsp]
000079a3731d09a5  mov esi, 0x00
000079a3731d09aa  mov rax, 0x64F127B95530
000079a3731d09b4  call rax
000079a3731d09b6  movaps xmm15, [rsp]
000079a3731d09bb  add rsp, 0x30
000079a3731d09bf  vmovaps xmm0, [rsp]
000079a3731d09c4  vmovaps xmm1, [rsp+0x10]
000079a3731d09ca  vmovaps xmm2, [rsp+0x20]
000079a3731d09d0  vmovaps xmm3, [rsp+0x30]
000079a3731d09d6  vmovaps xmm4, [rsp+0x40]
000079a3731d09dc  vmovaps xmm5, [rsp+0x50]
000079a3731d09e2  vmovaps xmm6, [rsp+0x60]
000079a3731d09e8  vmovaps xmm7, [rsp+0x70]
000079a3731d09ee  vmovaps xmm8, [rsp+0x80]
000079a3731d09f7  vmovaps xmm9, [rsp+0x90]
000079a3731d0a00  vmovaps xmm10, [rsp+0xA0]
000079a3731d0a09  vmovaps xmm11, [rsp+0xB0]
000079a3731d0a12  vmovaps xmm12, [rsp+0xC0]
000079a3731d0a1b  vmovaps xmm13, [rsp+0xD0]
000079a3731d0a24  vmovaps xmm14, [rsp+0xE0]
000079a3731d0a2d  add rsp, 0xF0
000079a3731d0a34  pop r11
000079a3731d0a36  pop r10
000079a3731d0a38  pop r9
000079a3731d0a3a  pop r8
000079a3731d0a3c  pop rsi
000079a3731d0a3d  pop rdi
000079a3731d0a3e  pop rdx
000079a3731d0a3f  pop rcx
000079a3731d0a40  pop rax
000079a3731d0a41  add rsp, 0x08
000079a3731d0a45  jmp 0x000079A3731CF617
000079a3731d0a4a  sub rsp, 0x08
000079a3731d0a4e  push rax
000079a3731d0a4f  push rcx
000079a3731d0a50  push rdx
000079a3731d0a51  push rdi
000079a3731d0a52  push rsi
000079a3731d0a53  push r8
000079a3731d0a55  push r9
000079a3731d0a57  push r10
000079a3731d0a59  push r11
000079a3731d0a5b  sub rsp, 0xF0
000079a3731d0a62  vmovaps [rsp], xmm0
000079a3731d0a67  vmovaps [rsp+0x10], xmm2
000079a3731d0a6d  vmovaps [rsp+0x20], xmm3
000079a3731d0a73  vmovaps [rsp+0x30], xmm4
000079a3731d0a79  vmovaps [rsp+0x40], xmm5
000079a3731d0a7f  vmovaps [rsp+0x50], xmm6
000079a3731d0a85  vmovaps [rsp+0x60], xmm7
000079a3731d0a8b  vmovaps [rsp+0x70], xmm8
000079a3731d0a91  vmovaps [rsp+0x80], xmm9
000079a3731d0a9a  vmovaps [rsp+0x90], xmm10
000079a3731d0aa3  vmovaps [rsp+0xA0], xmm11
000079a3731d0aac  vmovaps [rsp+0xB0], xmm12
000079a3731d0ab5  vmovaps [rsp+0xC0], xmm13
000079a3731d0abe  vmovaps [rsp+0xD0], xmm14
000079a3731d0ac7  vmovaps [rsp+0xE0], xmm15
000079a3731d0ad0  sub rsp, 0x30
000079a3731d0ad4  movaps [rsp], xmm1
000079a3731d0ad8  movaps [rsp+0x10], xmm14
000079a3731d0ade  movaps [rsp+0x20], xmm10
000079a3731d0ae4  lea rdi, [rsp]
000079a3731d0ae8  mov esi, 0x00
000079a3731d0aed  mov rax, 0x64F127B95530
000079a3731d0af7  call rax
000079a3731d0af9  movaps xmm1, [rsp]
000079a3731d0afd  add rsp, 0x30
000079a3731d0b01  vmovaps xmm0, [rsp]
000079a3731d0b06  vmovaps xmm2, [rsp+0x10]
000079a3731d0b0c  vmovaps xmm3, [rsp+0x20]
000079a3731d0b12  vmovaps xmm4, [rsp+0x30]
000079a3731d0b18  vmovaps xmm5, [rsp+0x40]
000079a3731d0b1e  vmovaps xmm6, [rsp+0x50]
000079a3731d0b24  vmovaps xmm7, [rsp+0x60]
000079a3731d0b2a  vmovaps xmm8, [rsp+0x70]
000079a3731d0b30  vmovaps xmm9, [rsp+0x80]
000079a3731d0b39  vmovaps xmm10, [rsp+0x90]
000079a3731d0b42  vmovaps xmm11, [rsp+0xA0]
000079a3731d0b4b  vmovaps xmm12, [rsp+0xB0]
000079a3731d0b54  vmovaps xmm13, [rsp+0xC0]
000079a3731d0b5d  vmovaps xmm14, [rsp+0xD0]
000079a3731d0b66  vmovaps xmm15, [rsp+0xE0]
000079a3731d0b6f  add rsp, 0xF0
000079a3731d0b76  pop r11
000079a3731d0b78  pop r10
000079a3731d0b7a  pop r9
000079a3731d0b7c  pop r8
000079a3731d0b7e  pop rsi
000079a3731d0b7f  pop rdi
000079a3731d0b80  pop rdx
000079a3731d0b81  pop rcx
000079a3731d0b82  pop rax
000079a3731d0b83  add rsp, 0x08
000079a3731d0b87  jmp 0x000079A3731CF631
000079a3731d0b8c  sub rsp, 0x08
000079a3731d0b90  push rax
000079a3731d0b91  push rcx
000079a3731d0b92  push rdx
000079a3731d0b93  push rdi
000079a3731d0b94  push rsi
000079a3731d0b95  push r8
000079a3731d0b97  push r9
000079a3731d0b99  push r10
000079a3731d0b9b  push r11
000079a3731d0b9d  sub rsp, 0xF0
000079a3731d0ba4  vmovaps [rsp], xmm0
000079a3731d0ba9  vmovaps [rsp+0x10], xmm1
000079a3731d0baf  vmovaps [rsp+0x20], xmm2
000079a3731d0bb5  vmovaps [rsp+0x30], xmm3
000079a3731d0bbb  vmovaps [rsp+0x40], xmm4
000079a3731d0bc1  vmovaps [rsp+0x50], xmm5
000079a3731d0bc7  vmovaps [rsp+0x60], xmm6
000079a3731d0bcd  vmovaps [rsp+0x70], xmm7
000079a3731d0bd3  vmovaps [rsp+0x80], xmm8
000079a3731d0bdc  vmovaps [rsp+0x90], xmm9
000079a3731d0be5  vmovaps [rsp+0xA0], xmm10
000079a3731d0bee  vmovaps [rsp+0xB0], xmm11
000079a3731d0bf7  vmovaps [rsp+0xC0], xmm12
000079a3731d0c00  vmovaps [rsp+0xD0], xmm14
000079a3731d0c09  vmovaps [rsp+0xE0], xmm15
000079a3731d0c12  sub rsp, 0x30
000079a3731d0c16  movaps [rsp], xmm13
000079a3731d0c1b  movaps [rsp+0x10], xmm14
000079a3731d0c21  movaps [rsp+0x20], xmm2
000079a3731d0c26  lea rdi, [rsp]
000079a3731d0c2a  mov esi, 0x00
000079a3731d0c2f  mov rax, 0x64F127B95530
000079a3731d0c39  call rax
000079a3731d0c3b  movaps xmm13, [rsp]
000079a3731d0c40  add rsp, 0x30
000079a3731d0c44  vmovaps xmm0, [rsp]
000079a3731d0c49  vmovaps xmm1, [rsp+0x10]
000079a3731d0c4f  vmovaps xmm2, [rsp+0x20]
000079a3731d0c55  vmovaps xmm3, [rsp+0x30]
000079a3731d0c5b  vmovaps xmm4, [rsp+0x40]
000079a3731d0c61  vmovaps xmm5, [rsp+0x50]
000079a3731d0c67  vmovaps xmm6, [rsp+0x60]
000079a3731d0c6d  vmovaps xmm7, [rsp+0x70]
000079a3731d0c73  vmovaps xmm8, [rsp+0x80]
000079a3731d0c7c  vmovaps xmm9, [rsp+0x90]
000079a3731d0c85  vmovaps xmm10, [rsp+0xA0]
000079a3731d0c8e  vmovaps xmm11, [rsp+0xB0]
000079a3731d0c97  vmovaps xmm12, [rsp+0xC0]
000079a3731d0ca0  vmovaps xmm14, [rsp+0xD0]
000079a3731d0ca9  vmovaps xmm15, [rsp+0xE0]
000079a3731d0cb2  add rsp, 0xF0
000079a3731d0cb9  pop r11
000079a3731d0cbb  pop r10
000079a3731d0cbd  pop r9
000079a3731d0cbf  pop r8
000079a3731d0cc1  pop rsi
000079a3731d0cc2  pop rdi
000079a3731d0cc3  pop rdx
000079a3731d0cc4  pop rcx
000079a3731d0cc5  pop rax
000079a3731d0cc6  add rsp, 0x08
000079a3731d0cca  jmp 0x000079A3731CF64C
000079a3731d0ccf  sub rsp, 0x08
000079a3731d0cd3  push rax
000079a3731d0cd4  push rcx
000079a3731d0cd5  push rdx
000079a3731d0cd6  push rdi
000079a3731d0cd7  push rsi
000079a3731d0cd8  push r8
000079a3731d0cda  push r9
000079a3731d0cdc  push r10
000079a3731d0cde  push r11
000079a3731d0ce0  sub rsp, 0xF0
000079a3731d0ce7  vmovaps [rsp], xmm0
000079a3731d0cec  vmovaps [rsp+0x10], xmm2
000079a3731d0cf2  vmovaps [rsp+0x20], xmm3
000079a3731d0cf8  vmovaps [rsp+0x30], xmm4
000079a3731d0cfe  vmovaps [rsp+0x40], xmm5
000079a3731d0d04  vmovaps [rsp+0x50], xmm6
000079a3731d0d0a  vmovaps [rsp+0x60], xmm7
000079a3731d0d10  vmovaps [rsp+0x70], xmm8
000079a3731d0d16  vmovaps [rsp+0x80], xmm9
000079a3731d0d1f  vmovaps [rsp+0x90], xmm10
000079a3731d0d28  vmovaps [rsp+0xA0], xmm11
000079a3731d0d31  vmovaps [rsp+0xB0], xmm12
000079a3731d0d3a  vmovaps [rsp+0xC0], xmm13
000079a3731d0d43  vmovaps [rsp+0xD0], xmm14
000079a3731d0d4c  vmovaps [rsp+0xE0], xmm15
000079a3731d0d55  sub rsp, 0x30
000079a3731d0d59  movaps [rsp], xmm1
000079a3731d0d5d  movaps [rsp+0x10], xmm10
000079a3731d0d63  movaps [rsp+0x20], xmm2
000079a3731d0d68  lea rdi, [rsp]
000079a3731d0d6c  mov esi, 0x00
000079a3731d0d71  mov rax, 0x64F127B95530
000079a3731d0d7b  call rax
000079a3731d0d7d  movaps xmm1, [rsp]
000079a3731d0d81  add rsp, 0x30
000079a3731d0d85  vmovaps xmm0, [rsp]
000079a3731d0d8a  vmovaps xmm2, [rsp+0x10]
000079a3731d0d90  vmovaps xmm3, [rsp+0x20]
000079a3731d0d96  vmovaps xmm4, [rsp+0x30]
000079a3731d0d9c  vmovaps xmm5, [rsp+0x40]
000079a3731d0da2  vmovaps xmm6, [rsp+0x50]
000079a3731d0da8  vmovaps xmm7, [rsp+0x60]
000079a3731d0dae  vmovaps xmm8, [rsp+0x70]
000079a3731d0db4  vmovaps xmm9, [rsp+0x80]
000079a3731d0dbd  vmovaps xmm10, [rsp+0x90]
000079a3731d0dc6  vmovaps xmm11, [rsp+0xA0]
000079a3731d0dcf  vmovaps xmm12, [rsp+0xB0]
000079a3731d0dd8  vmovaps xmm13, [rsp+0xC0]
000079a3731d0de1  vmovaps xmm14, [rsp+0xD0]
000079a3731d0dea  vmovaps xmm15, [rsp+0xE0]
000079a3731d0df3  add rsp, 0xF0
000079a3731d0dfa  pop r11
000079a3731d0dfc  pop r10
000079a3731d0dfe  pop r9
000079a3731d0e00  pop r8
000079a3731d0e02  pop rsi
000079a3731d0e03  pop rdi
000079a3731d0e04  pop rdx
000079a3731d0e05  pop rcx
000079a3731d0e06  pop rax
000079a3731d0e07  add rsp, 0x08
000079a3731d0e0b  jmp 0x000079A3731CF6B4
000079a3731d0e10  sub rsp, 0x08
000079a3731d0e14  push rax
000079a3731d0e15  push rcx
000079a3731d0e16  push rdx
000079a3731d0e17  push rdi
000079a3731d0e18  push rsi
000079a3731d0e19  push r8
000079a3731d0e1b  push r9
000079a3731d0e1d  push r10
000079a3731d0e1f  push r11
000079a3731d0e21  sub rsp, 0xF0
000079a3731d0e28  vmovaps [rsp], xmm0
000079a3731d0e2d  vmovaps [rsp+0x10], xmm1
000079a3731d0e33  vmovaps [rsp+0x20], xmm2
000079a3731d0e39  vmovaps [rsp+0x30], xmm3
000079a3731d0e3f  vmovaps [rsp+0x40], xmm4
000079a3731d0e45  vmovaps [rsp+0x50], xmm5
000079a3731d0e4b  vmovaps [rsp+0x60], xmm6
000079a3731d0e51  vmovaps [rsp+0x70], xmm7
000079a3731d0e57  vmovaps [rsp+0x80], xmm8
000079a3731d0e60  vmovaps [rsp+0x90], xmm9
000079a3731d0e69  vmovaps [rsp+0xA0], xmm10
000079a3731d0e72  vmovaps [rsp+0xB0], xmm11
000079a3731d0e7b  vmovaps [rsp+0xC0], xmm12
000079a3731d0e84  vmovaps [rsp+0xD0], xmm13
000079a3731d0e8d  vmovaps [rsp+0xE0], xmm14
000079a3731d0e96  sub rsp, 0x30
000079a3731d0e9a  movaps [rsp], xmm15
000079a3731d0e9f  movaps [rsp+0x10], xmm10
000079a3731d0ea5  movaps [rsp+0x20], xmm2
000079a3731d0eaa  lea rdi, [rsp]
000079a3731d0eae  mov esi, 0x00
000079a3731d0eb3  mov rax, 0x64F127B95530
000079a3731d0ebd  call rax
000079a3731d0ebf  movaps xmm15, [rsp]
000079a3731d0ec4  add rsp, 0x30
000079a3731d0ec8  vmovaps xmm0, [rsp]
000079a3731d0ecd  vmovaps xmm1, [rsp+0x10]
000079a3731d0ed3  vmovaps xmm2, [rsp+0x20]
000079a3731d0ed9  vmovaps xmm3, [rsp+0x30]
000079a3731d0edf  vmovaps xmm4, [rsp+0x40]
000079a3731d0ee5  vmovaps xmm5, [rsp+0x50]
000079a3731d0eeb  vmovaps xmm6, [rsp+0x60]
000079a3731d0ef1  vmovaps xmm7, [rsp+0x70]
000079a3731d0ef7  vmovaps xmm8, [rsp+0x80]
000079a3731d0f00  vmovaps xmm9, [rsp+0x90]
000079a3731d0f09  vmovaps xmm10, [rsp+0xA0]
000079a3731d0f12  vmovaps xmm11, [rsp+0xB0]
000079a3731d0f1b  vmovaps xmm12, [rsp+0xC0]
000079a3731d0f24  vmovaps xmm13, [rsp+0xD0]
000079a3731d0f2d  vmovaps xmm14, [rsp+0xE0]
000079a3731d0f36  add rsp, 0xF0
000079a3731d0f3d  pop r11
000079a3731d0f3f  pop r10
000079a3731d0f41  pop r9
000079a3731d0f43  pop r8
000079a3731d0f45  pop rsi
000079a3731d0f46  pop rdi
000079a3731d0f47  pop rdx
000079a3731d0f48  pop rcx
000079a3731d0f49  pop rax
000079a3731d0f4a  add rsp, 0x08
000079a3731d0f4e  jmp 0x000079A3731CF706
000079a3731d0f53  sub rsp, 0x08
000079a3731d0f57  push rax
000079a3731d0f58  push rcx
000079a3731d0f59  push rdx
000079a3731d0f5a  push rdi
000079a3731d0f5b  push rsi
000079a3731d0f5c  push r8
000079a3731d0f5e  push r9
000079a3731d0f60  push r10
000079a3731d0f62  push r11
000079a3731d0f64  sub rsp, 0xF0
000079a3731d0f6b  vmovaps [rsp], xmm0
000079a3731d0f70  vmovaps [rsp+0x10], xmm2
000079a3731d0f76  vmovaps [rsp+0x20], xmm3
000079a3731d0f7c  vmovaps [rsp+0x30], xmm4
000079a3731d0f82  vmovaps [rsp+0x40], xmm5
000079a3731d0f88  vmovaps [rsp+0x50], xmm6
000079a3731d0f8e  vmovaps [rsp+0x60], xmm7
000079a3731d0f94  vmovaps [rsp+0x70], xmm8
000079a3731d0f9a  vmovaps [rsp+0x80], xmm9
000079a3731d0fa3  vmovaps [rsp+0x90], xmm10
000079a3731d0fac  vmovaps [rsp+0xA0], xmm11
000079a3731d0fb5  vmovaps [rsp+0xB0], xmm12
000079a3731d0fbe  vmovaps [rsp+0xC0], xmm13
000079a3731d0fc7  vmovaps [rsp+0xD0], xmm14
000079a3731d0fd0  vmovaps [rsp+0xE0], xmm15
000079a3731d0fd9  sub rsp, 0x30
000079a3731d0fdd  movaps [rsp], xmm1
000079a3731d0fe1  movaps [rsp+0x10], xmm10
000079a3731d0fe7  movaps [rsp+0x20], xmm12
000079a3731d0fed  lea rdi, [rsp]
000079a3731d0ff1  mov esi, 0x00
000079a3731d0ff6  mov rax, 0x64F127B95530
000079a3731d1000  call rax
000079a3731d1002  movaps xmm1, [rsp]
000079a3731d1006  add rsp, 0x30
000079a3731d100a  vmovaps xmm0, [rsp]
000079a3731d100f  vmovaps xmm2, [rsp+0x10]
000079a3731d1015  vmovaps xmm3, [rsp+0x20]
000079a3731d101b  vmovaps xmm4, [rsp+0x30]
000079a3731d1021  vmovaps xmm5, [rsp+0x40]
000079a3731d1027  vmovaps xmm6, [rsp+0x50]
000079a3731d102d  vmovaps xmm7, [rsp+0x60]
000079a3731d1033  vmovaps xmm8, [rsp+0x70]
000079a3731d1039  vmovaps xmm9, [rsp+0x80]
000079a3731d1042  vmovaps xmm10, [rsp+0x90]
000079a3731d104b  vmovaps xmm11, [rsp+0xA0]
000079a3731d1054  vmovaps xmm12, [rsp+0xB0]
000079a3731d105d  vmovaps xmm13, [rsp+0xC0]
000079a3731d1066  vmovaps xmm14, [rsp+0xD0]
000079a3731d106f  vmovaps xmm15, [rsp+0xE0]
000079a3731d1078  add rsp, 0xF0
000079a3731d107f  pop r11
000079a3731d1081  pop r10
000079a3731d1083  pop r9
000079a3731d1085  pop r8
000079a3731d1087  pop rsi
000079a3731d1088  pop rdi
000079a3731d1089  pop rdx
000079a3731d108a  pop rcx
000079a3731d108b  pop rax
000079a3731d108c  add rsp, 0x08
000079a3731d1090  jmp 0x000079A3731CF732
000079a3731d1095  sub rsp, 0x08
000079a3731d1099  push rax
000079a3731d109a  push rcx
000079a3731d109b  push rdx
000079a3731d109c  push rdi
000079a3731d109d  push rsi
000079a3731d109e  push r8
000079a3731d10a0  push r9
000079a3731d10a2  push r10
000079a3731d10a4  push r11
000079a3731d10a6  sub rsp, 0xF0
000079a3731d10ad  vmovaps [rsp], xmm0
000079a3731d10b2  vmovaps [rsp+0x10], xmm1
000079a3731d10b8  vmovaps [rsp+0x20], xmm2
000079a3731d10be  vmovaps [rsp+0x30], xmm3
000079a3731d10c4  vmovaps [rsp+0x40], xmm4
000079a3731d10ca  vmovaps [rsp+0x50], xmm5
000079a3731d10d0  vmovaps [rsp+0x60], xmm6
000079a3731d10d6  vmovaps [rsp+0x70], xmm7
000079a3731d10dc  vmovaps [rsp+0x80], xmm8
000079a3731d10e5  vmovaps [rsp+0x90], xmm9
000079a3731d10ee  vmovaps [rsp+0xA0], xmm10
000079a3731d10f7  vmovaps [rsp+0xB0], xmm11
000079a3731d1100  vmovaps [rsp+0xC0], xmm12
000079a3731d1109  vmovaps [rsp+0xD0], xmm13
000079a3731d1112  vmovaps [rsp+0xE0], xmm14
000079a3731d111b  sub rsp, 0x30
000079a3731d111f  movaps [rsp], xmm15
000079a3731d1124  movaps [rsp+0x10], xmm10
000079a3731d112a  movaps [rsp+0x20], xmm12
000079a3731d1130  lea rdi, [rsp]
000079a3731d1134  mov esi, 0x00
000079a3731d1139  mov rax, 0x64F127B95530
000079a3731d1143  call rax
000079a3731d1145  movaps xmm15, [rsp]
000079a3731d114a  add rsp, 0x30
000079a3731d114e  vmovaps xmm0, [rsp]
000079a3731d1153  vmovaps xmm1, [rsp+0x10]
000079a3731d1159  vmovaps xmm2, [rsp+0x20]
000079a3731d115f  vmovaps xmm3, [rsp+0x30]
000079a3731d1165  vmovaps xmm4, [rsp+0x40]
000079a3731d116b  vmovaps xmm5, [rsp+0x50]
000079a3731d1171  vmovaps xmm6, [rsp+0x60]
000079a3731d1177  vmovaps xmm7, [rsp+0x70]
000079a3731d117d  vmovaps xmm8, [rsp+0x80]
000079a3731d1186  vmovaps xmm9, [rsp+0x90]
000079a3731d118f  vmovaps xmm10, [rsp+0xA0]
000079a3731d1198  vmovaps xmm11, [rsp+0xB0]
000079a3731d11a1  vmovaps xmm12, [rsp+0xC0]
000079a3731d11aa  vmovaps xmm13, [rsp+0xD0]
000079a3731d11b3  vmovaps xmm14, [rsp+0xE0]
000079a3731d11bc  add rsp, 0xF0
000079a3731d11c3  pop r11
000079a3731d11c5  pop r10
000079a3731d11c7  pop r9
000079a3731d11c9  pop r8
000079a3731d11cb  pop rsi
000079a3731d11cc  pop rdi
000079a3731d11cd  pop rdx
000079a3731d11ce  pop rcx
000079a3731d11cf  pop rax
000079a3731d11d0  add rsp, 0x08
000079a3731d11d4  jmp 0x000079A3731CF75E
000079a3731d11d9  call 0x000079A372FFF430
000079a3731d11de  jmp 0x000079A3731CF7EE
000079a3731d11e3  call 0x000079A372FFF430
000079a3731d11e8  jmp 0x000079A3731CF801
000079a3731d11ed  sub rsp, 0x08
000079a3731d11f1  push rax
000079a3731d11f2  push rcx
000079a3731d11f3  push rdx
000079a3731d11f4  push rdi
000079a3731d11f5  push rsi
000079a3731d11f6  push r8
000079a3731d11f8  push r9
000079a3731d11fa  push r10
000079a3731d11fc  push r11
000079a3731d11fe  sub rsp, 0xF0
000079a3731d1205  vmovaps [rsp], xmm0
000079a3731d120a  vmovaps [rsp+0x10], xmm2
000079a3731d1210  vmovaps [rsp+0x20], xmm3
000079a3731d1216  vmovaps [rsp+0x30], xmm4
000079a3731d121c  vmovaps [rsp+0x40], xmm5
000079a3731d1222  vmovaps [rsp+0x50], xmm6
000079a3731d1228  vmovaps [rsp+0x60], xmm7
000079a3731d122e  vmovaps [rsp+0x70], xmm8
000079a3731d1234  vmovaps [rsp+0x80], xmm9
000079a3731d123d  vmovaps [rsp+0x90], xmm10
000079a3731d1246  vmovaps [rsp+0xA0], xmm11
000079a3731d124f  vmovaps [rsp+0xB0], xmm12
000079a3731d1258  vmovaps [rsp+0xC0], xmm13
000079a3731d1261  vmovaps [rsp+0xD0], xmm14
000079a3731d126a  vmovaps [rsp+0xE0], xmm15
000079a3731d1273  sub rsp, 0x30
000079a3731d1277  movaps [rsp], xmm1
000079a3731d127b  movaps [rsp+0x10], xmm13
000079a3731d1281  movaps [rsp+0x20], xmm2
000079a3731d1286  lea rdi, [rsp]
000079a3731d128a  mov esi, 0x00
000079a3731d128f  mov rax, 0x64F127B95530
000079a3731d1299  call rax
000079a3731d129b  movaps xmm1, [rsp]
000079a3731d129f  add rsp, 0x30
000079a3731d12a3  vmovaps xmm0, [rsp]
000079a3731d12a8  vmovaps xmm2, [rsp+0x10]
000079a3731d12ae  vmovaps xmm3, [rsp+0x20]
000079a3731d12b4  vmovaps xmm4, [rsp+0x30]
000079a3731d12ba  vmovaps xmm5, [rsp+0x40]
000079a3731d12c0  vmovaps xmm6, [rsp+0x50]
000079a3731d12c6  vmovaps xmm7, [rsp+0x60]
000079a3731d12cc  vmovaps xmm8, [rsp+0x70]
000079a3731d12d2  vmovaps xmm9, [rsp+0x80]
000079a3731d12db  vmovaps xmm10, [rsp+0x90]
000079a3731d12e4  vmovaps xmm11, [rsp+0xA0]
000079a3731d12ed  vmovaps xmm12, [rsp+0xB0]
000079a3731d12f6  vmovaps xmm13, [rsp+0xC0]
000079a3731d12ff  vmovaps xmm14, [rsp+0xD0]
000079a3731d1308  vmovaps xmm15, [rsp+0xE0]
000079a3731d1311  add rsp, 0xF0
000079a3731d1318  pop r11
000079a3731d131a  pop r10
000079a3731d131c  pop r9
000079a3731d131e  pop r8
000079a3731d1320  pop rsi
000079a3731d1321  pop rdi
000079a3731d1322  pop rdx
000079a3731d1323  pop rcx
000079a3731d1324  pop rax
000079a3731d1325  add rsp, 0x08
000079a3731d1329  jmp 0x000079A3731CF82C
000079a3731d132e  call 0x000079A37300E760
000079a3731d1333  jmp 0x000079A3731CF839
000079a3731d1338  sub rsp, 0x08
000079a3731d133c  push rax
000079a3731d133d  push rcx
000079a3731d133e  push rdx
000079a3731d133f  push rdi
000079a3731d1340  push rsi
000079a3731d1341  push r8
000079a3731d1343  push r9
000079a3731d1345  push r10
000079a3731d1347  push r11
000079a3731d1349  sub rsp, 0xF0
000079a3731d1350  vmovaps [rsp], xmm0
000079a3731d1355  vmovaps [rsp+0x10], xmm1
000079a3731d135b  vmovaps [rsp+0x20], xmm2
000079a3731d1361  vmovaps [rsp+0x30], xmm3
000079a3731d1367  vmovaps [rsp+0x40], xmm4
000079a3731d136d  vmovaps [rsp+0x50], xmm5
000079a3731d1373  vmovaps [rsp+0x60], xmm6
000079a3731d1379  vmovaps [rsp+0x70], xmm7
000079a3731d137f  vmovaps [rsp+0x80], xmm8
000079a3731d1388  vmovaps [rsp+0x90], xmm9
000079a3731d1391  vmovaps [rsp+0xA0], xmm10
000079a3731d139a  vmovaps [rsp+0xB0], xmm11
000079a3731d13a3  vmovaps [rsp+0xC0], xmm12
000079a3731d13ac  vmovaps [rsp+0xD0], xmm14
000079a3731d13b5  vmovaps [rsp+0xE0], xmm15
000079a3731d13be  sub rsp, 0x30
000079a3731d13c2  movaps [rsp], xmm13
000079a3731d13c7  movaps [rsp+0x10], xmm2
000079a3731d13cc  movaps [rsp+0x20], xmm1
000079a3731d13d1  lea rdi, [rsp]
000079a3731d13d5  mov esi, 0x00
000079a3731d13da  mov rax, 0x64F127B95530
000079a3731d13e4  call rax
000079a3731d13e6  movaps xmm13, [rsp]
000079a3731d13eb  add rsp, 0x30
000079a3731d13ef  vmovaps xmm0, [rsp]
000079a3731d13f4  vmovaps xmm1, [rsp+0x10]
000079a3731d13fa  vmovaps xmm2, [rsp+0x20]
000079a3731d1400  vmovaps xmm3, [rsp+0x30]
000079a3731d1406  vmovaps xmm4, [rsp+0x40]
000079a3731d140c  vmovaps xmm5, [rsp+0x50]
000079a3731d1412  vmovaps xmm6, [rsp+0x60]
000079a3731d1418  vmovaps xmm7, [rsp+0x70]
000079a3731d141e  vmovaps xmm8, [rsp+0x80]
000079a3731d1427  vmovaps xmm9, [rsp+0x90]
000079a3731d1430  vmovaps xmm10, [rsp+0xA0]
000079a3731d1439  vmovaps xmm11, [rsp+0xB0]
000079a3731d1442  vmovaps xmm12, [rsp+0xC0]
000079a3731d144b  vmovaps xmm14, [rsp+0xD0]
000079a3731d1454  vmovaps xmm15, [rsp+0xE0]
000079a3731d145d  add rsp, 0xF0
000079a3731d1464  pop r11
000079a3731d1466  pop r10
000079a3731d1468  pop r9
000079a3731d146a  pop r8
000079a3731d146c  pop rsi
000079a3731d146d  pop rdi
000079a3731d146e  pop rdx
000079a3731d146f  pop rcx
000079a3731d1470  pop rax
000079a3731d1471  add rsp, 0x08
000079a3731d1475  jmp 0x000079A3731CF878
000079a3731d147a  sub rsp, 0x08
000079a3731d147e  push rax
000079a3731d147f  push rcx
000079a3731d1480  push rdx
000079a3731d1481  push rdi
000079a3731d1482  push rsi
000079a3731d1483  push r8
000079a3731d1485  push r9
000079a3731d1487  push r10
000079a3731d1489  push r11
000079a3731d148b  sub rsp, 0xF0
000079a3731d1492  vmovaps [rsp], xmm0
000079a3731d1497  vmovaps [rsp+0x10], xmm2
000079a3731d149d  vmovaps [rsp+0x20], xmm3
000079a3731d14a3  vmovaps [rsp+0x30], xmm4
000079a3731d14a9  vmovaps [rsp+0x40], xmm5
000079a3731d14af  vmovaps [rsp+0x50], xmm6
000079a3731d14b5  vmovaps [rsp+0x60], xmm7
000079a3731d14bb  vmovaps [rsp+0x70], xmm8
000079a3731d14c1  vmovaps [rsp+0x80], xmm9
000079a3731d14ca  vmovaps [rsp+0x90], xmm10
000079a3731d14d3  vmovaps [rsp+0xA0], xmm11
000079a3731d14dc  vmovaps [rsp+0xB0], xmm12
000079a3731d14e5  vmovaps [rsp+0xC0], xmm13
000079a3731d14ee  vmovaps [rsp+0xD0], xmm14
000079a3731d14f7  vmovaps [rsp+0xE0], xmm15
000079a3731d1500  sub rsp, 0x30
000079a3731d1504  movaps [rsp], xmm1
000079a3731d1508  movaps [rsp+0x10], xmm15
000079a3731d150e  movaps [rsp+0x20], xmm2
000079a3731d1513  lea rdi, [rsp]
000079a3731d1517  mov esi, 0x00
000079a3731d151c  mov rax, 0x64F127B95530
000079a3731d1526  call rax
000079a3731d1528  movaps xmm1, [rsp]
000079a3731d152c  add rsp, 0x30
000079a3731d1530  vmovaps xmm0, [rsp]
000079a3731d1535  vmovaps xmm2, [rsp+0x10]
000079a3731d153b  vmovaps xmm3, [rsp+0x20]
000079a3731d1541  vmovaps xmm4, [rsp+0x30]
000079a3731d1547  vmovaps xmm5, [rsp+0x40]
000079a3731d154d  vmovaps xmm6, [rsp+0x50]
000079a3731d1553  vmovaps xmm7, [rsp+0x60]
000079a3731d1559  vmovaps xmm8, [rsp+0x70]
000079a3731d155f  vmovaps xmm9, [rsp+0x80]
000079a3731d1568  vmovaps xmm10, [rsp+0x90]
000079a3731d1571  vmovaps xmm11, [rsp+0xA0]
000079a3731d157a  vmovaps xmm12, [rsp+0xB0]
000079a3731d1583  vmovaps xmm13, [rsp+0xC0]
000079a3731d158c  vmovaps xmm14, [rsp+0xD0]
000079a3731d1595  vmovaps xmm15, [rsp+0xE0]
000079a3731d159e  add rsp, 0xF0
000079a3731d15a5  pop r11
000079a3731d15a7  pop r10
000079a3731d15a9  pop r9
000079a3731d15ab  pop r8
000079a3731d15ad  pop rsi
000079a3731d15ae  pop rdi
000079a3731d15af  pop rdx
000079a3731d15b0  pop rcx
000079a3731d15b1  pop rax
000079a3731d15b2  add rsp, 0x08
000079a3731d15b6  jmp 0x000079A3731CF8AC
000079a3731d15bb  sub rsp, 0x08
000079a3731d15bf  push rax
000079a3731d15c0  push rcx
000079a3731d15c1  push rdx
000079a3731d15c2  push rdi
000079a3731d15c3  push rsi
000079a3731d15c4  push r8
000079a3731d15c6  push r9
000079a3731d15c8  push r10
000079a3731d15ca  push r11
000079a3731d15cc  sub rsp, 0xF0
000079a3731d15d3  vmovaps [rsp], xmm0
000079a3731d15d8  vmovaps [rsp+0x10], xmm1
000079a3731d15de  vmovaps [rsp+0x20], xmm2
000079a3731d15e4  vmovaps [rsp+0x30], xmm3
000079a3731d15ea  vmovaps [rsp+0x40], xmm4
000079a3731d15f0  vmovaps [rsp+0x50], xmm5
000079a3731d15f6  vmovaps [rsp+0x60], xmm6
000079a3731d15fc  vmovaps [rsp+0x70], xmm7
000079a3731d1602  vmovaps [rsp+0x80], xmm8
000079a3731d160b  vmovaps [rsp+0x90], xmm9
000079a3731d1614  vmovaps [rsp+0xA0], xmm10
000079a3731d161d  vmovaps [rsp+0xB0], xmm11
000079a3731d1626  vmovaps [rsp+0xC0], xmm12
000079a3731d162f  vmovaps [rsp+0xD0], xmm13
000079a3731d1638  vmovaps [rsp+0xE0], xmm15
000079a3731d1641  sub rsp, 0x30
000079a3731d1645  movaps [rsp], xmm14
000079a3731d164a  movaps [rsp+0x10], xmm2
000079a3731d164f  movaps [rsp+0x20], xmm15
000079a3731d1655  lea rdi, [rsp]
000079a3731d1659  mov esi, 0x00
000079a3731d165e  mov rax, 0x64F127B95530
000079a3731d1668  call rax
000079a3731d166a  movaps xmm14, [rsp]
000079a3731d166f  add rsp, 0x30
000079a3731d1673  vmovaps xmm0, [rsp]
000079a3731d1678  vmovaps xmm1, [rsp+0x10]
000079a3731d167e  vmovaps xmm2, [rsp+0x20]
000079a3731d1684  vmovaps xmm3, [rsp+0x30]
000079a3731d168a  vmovaps xmm4, [rsp+0x40]
000079a3731d1690  vmovaps xmm5, [rsp+0x50]
000079a3731d1696  vmovaps xmm6, [rsp+0x60]
000079a3731d169c  vmovaps xmm7, [rsp+0x70]
000079a3731d16a2  vmovaps xmm8, [rsp+0x80]
000079a3731d16ab  vmovaps xmm9, [rsp+0x90]
000079a3731d16b4  vmovaps xmm10, [rsp+0xA0]
000079a3731d16bd  vmovaps xmm11, [rsp+0xB0]
000079a3731d16c6  vmovaps xmm12, [rsp+0xC0]
000079a3731d16cf  vmovaps xmm13, [rsp+0xD0]
000079a3731d16d8  vmovaps xmm15, [rsp+0xE0]
000079a3731d16e1  add rsp, 0xF0
000079a3731d16e8  pop r11
000079a3731d16ea  pop r10
000079a3731d16ec  pop r9
000079a3731d16ee  pop r8
000079a3731d16f0  pop rsi
000079a3731d16f1  pop rdi
000079a3731d16f2  pop rdx
000079a3731d16f3  pop rcx
000079a3731d16f4  pop rax
000079a3731d16f5  add rsp, 0x08
000079a3731d16f9  jmp 0x000079A3731CF8E7
000079a3731d16fe  sub rsp, 0x08
000079a3731d1702  push rax
000079a3731d1703  push rcx
000079a3731d1704  push rdx
000079a3731d1705  push rdi
000079a3731d1706  push rsi
000079a3731d1707  push r8
000079a3731d1709  push r9
000079a3731d170b  push r10
000079a3731d170d  push r11
000079a3731d170f  sub rsp, 0xF0
000079a3731d1716  vmovaps [rsp], xmm0
000079a3731d171b  vmovaps [rsp+0x10], xmm1
000079a3731d1721  vmovaps [rsp+0x20], xmm2
000079a3731d1727  vmovaps [rsp+0x30], xmm3
000079a3731d172d  vmovaps [rsp+0x40], xmm4
000079a3731d1733  vmovaps [rsp+0x50], xmm5
000079a3731d1739  vmovaps [rsp+0x60], xmm6
000079a3731d173f  vmovaps [rsp+0x70], xmm7
000079a3731d1745  vmovaps [rsp+0x80], xmm8
000079a3731d174e  vmovaps [rsp+0x90], xmm9
000079a3731d1757  vmovaps [rsp+0xA0], xmm10
000079a3731d1760  vmovaps [rsp+0xB0], xmm11
000079a3731d1769  vmovaps [rsp+0xC0], xmm12
000079a3731d1772  vmovaps [rsp+0xD0], xmm13
000079a3731d177b  vmovaps [rsp+0xE0], xmm14
000079a3731d1784  sub rsp, 0x30
000079a3731d1788  movaps [rsp], xmm15
000079a3731d178d  movaps [rsp+0x10], xmm2
000079a3731d1792  movaps [rsp+0x20], xmm1
000079a3731d1797  lea rdi, [rsp]
000079a3731d179b  mov esi, 0x00
000079a3731d17a0  mov rax, 0x64F127B95530
000079a3731d17aa  call rax
000079a3731d17ac  movaps xmm15, [rsp]
000079a3731d17b1  add rsp, 0x30
000079a3731d17b5  vmovaps xmm0, [rsp]
000079a3731d17ba  vmovaps xmm1, [rsp+0x10]
000079a3731d17c0  vmovaps xmm2, [rsp+0x20]
000079a3731d17c6  vmovaps xmm3, [rsp+0x30]
000079a3731d17cc  vmovaps xmm4, [rsp+0x40]
000079a3731d17d2  vmovaps xmm5, [rsp+0x50]
000079a3731d17d8  vmovaps xmm6, [rsp+0x60]
000079a3731d17de  vmovaps xmm7, [rsp+0x70]
000079a3731d17e4  vmovaps xmm8, [rsp+0x80]
000079a3731d17ed  vmovaps xmm9, [rsp+0x90]
000079a3731d17f6  vmovaps xmm10, [rsp+0xA0]
000079a3731d17ff  vmovaps xmm11, [rsp+0xB0]
000079a3731d1808  vmovaps xmm12, [rsp+0xC0]
000079a3731d1811  vmovaps xmm13, [rsp+0xD0]
000079a3731d181a  vmovaps xmm14, [rsp+0xE0]
000079a3731d1823  add rsp, 0xF0
000079a3731d182a  pop r11
000079a3731d182c  pop r10
000079a3731d182e  pop r9
000079a3731d1830  pop r8
000079a3731d1832  pop rsi
000079a3731d1833  pop rdi
000079a3731d1834  pop rdx
000079a3731d1835  pop rcx
000079a3731d1836  pop rax
000079a3731d1837  add rsp, 0x08
000079a3731d183b  jmp 0x000079A3731CF923
000079a3731d1840  call 0x000079A372FFF430
000079a3731d1845  jmp 0x000079A3731CF930
000079a3731d184a  sub rsp, 0x08
000079a3731d184e  push rax
000079a3731d184f  push rcx
000079a3731d1850  push rdx
000079a3731d1851  push rdi
000079a3731d1852  push rsi
000079a3731d1853  push r8
000079a3731d1855  push r9
000079a3731d1857  push r10
000079a3731d1859  push r11
000079a3731d185b  sub rsp, 0xF0
000079a3731d1862  vmovaps [rsp], xmm0
000079a3731d1867  vmovaps [rsp+0x10], xmm1
000079a3731d186d  vmovaps [rsp+0x20], xmm3
000079a3731d1873  vmovaps [rsp+0x30], xmm4
000079a3731d1879  vmovaps [rsp+0x40], xmm5
000079a3731d187f  vmovaps [rsp+0x50], xmm6
000079a3731d1885  vmovaps [rsp+0x60], xmm7
000079a3731d188b  vmovaps [rsp+0x70], xmm8
000079a3731d1891  vmovaps [rsp+0x80], xmm9
000079a3731d189a  vmovaps [rsp+0x90], xmm10
000079a3731d18a3  vmovaps [rsp+0xA0], xmm11
000079a3731d18ac  vmovaps [rsp+0xB0], xmm12
000079a3731d18b5  vmovaps [rsp+0xC0], xmm13
000079a3731d18be  vmovaps [rsp+0xD0], xmm14
000079a3731d18c7  vmovaps [rsp+0xE0], xmm15
000079a3731d18d0  sub rsp, 0x30
000079a3731d18d4  movaps [rsp], xmm2
000079a3731d18d8  movaps [rsp+0x10], xmm1
000079a3731d18dd  movaps [rsp+0x20], xmm14
000079a3731d18e3  lea rdi, [rsp]
000079a3731d18e7  mov esi, 0x00
000079a3731d18ec  mov rax, 0x64F127B95530
000079a3731d18f6  call rax
000079a3731d18f8  movaps xmm2, [rsp]
000079a3731d18fc  add rsp, 0x30
000079a3731d1900  vmovaps xmm0, [rsp]
000079a3731d1905  vmovaps xmm1, [rsp+0x10]
000079a3731d190b  vmovaps xmm3, [rsp+0x20]
000079a3731d1911  vmovaps xmm4, [rsp+0x30]
000079a3731d1917  vmovaps xmm5, [rsp+0x40]
000079a3731d191d  vmovaps xmm6, [rsp+0x50]
000079a3731d1923  vmovaps xmm7, [rsp+0x60]
000079a3731d1929  vmovaps xmm8, [rsp+0x70]
000079a3731d192f  vmovaps xmm9, [rsp+0x80]
000079a3731d1938  vmovaps xmm10, [rsp+0x90]
000079a3731d1941  vmovaps xmm11, [rsp+0xA0]
000079a3731d194a  vmovaps xmm12, [rsp+0xB0]
000079a3731d1953  vmovaps xmm13, [rsp+0xC0]
000079a3731d195c  vmovaps xmm14, [rsp+0xD0]
000079a3731d1965  vmovaps xmm15, [rsp+0xE0]
000079a3731d196e  add rsp, 0xF0
000079a3731d1975  pop r11
000079a3731d1977  pop r10
000079a3731d1979  pop r9
000079a3731d197b  pop r8
000079a3731d197d  pop rsi
000079a3731d197e  pop rdi
000079a3731d197f  pop rdx
000079a3731d1980  pop rcx
000079a3731d1981  pop rax
000079a3731d1982  add rsp, 0x08
000079a3731d1986  jmp 0x000079A3731CF96D
000079a3731d198b  sub rsp, 0x08
000079a3731d198f  push rax
000079a3731d1990  push rcx
000079a3731d1991  push rdx
000079a3731d1992  push rdi
000079a3731d1993  push rsi
000079a3731d1994  push r8
000079a3731d1996  push r9
000079a3731d1998  push r10
000079a3731d199a  push r11
000079a3731d199c  sub rsp, 0xF0
000079a3731d19a3  vmovaps [rsp], xmm0
000079a3731d19a8  vmovaps [rsp+0x10], xmm1
000079a3731d19ae  vmovaps [rsp+0x20], xmm2
000079a3731d19b4  vmovaps [rsp+0x30], xmm3
000079a3731d19ba  vmovaps [rsp+0x40], xmm4
000079a3731d19c0  vmovaps [rsp+0x50], xmm5
000079a3731d19c6  vmovaps [rsp+0x60], xmm6
000079a3731d19cc  vmovaps [rsp+0x70], xmm7
000079a3731d19d2  vmovaps [rsp+0x80], xmm8
000079a3731d19db  vmovaps [rsp+0x90], xmm9
000079a3731d19e4  vmovaps [rsp+0xA0], xmm10
000079a3731d19ed  vmovaps [rsp+0xB0], xmm11
000079a3731d19f6  vmovaps [rsp+0xC0], xmm12
000079a3731d19ff  vmovaps [rsp+0xD0], xmm13
000079a3731d1a08  vmovaps [rsp+0xE0], xmm14
000079a3731d1a11  sub rsp, 0x30
000079a3731d1a15  movaps [rsp], xmm15
000079a3731d1a1a  movaps [rsp+0x10], xmm14
000079a3731d1a20  movaps [rsp+0x20], xmm1
000079a3731d1a25  lea rdi, [rsp]
000079a3731d1a29  mov esi, 0x00
000079a3731d1a2e  mov rax, 0x64F127B95530
000079a3731d1a38  call rax
000079a3731d1a3a  movaps xmm15, [rsp]
000079a3731d1a3f  add rsp, 0x30
000079a3731d1a43  vmovaps xmm0, [rsp]
000079a3731d1a48  vmovaps xmm1, [rsp+0x10]
000079a3731d1a4e  vmovaps xmm2, [rsp+0x20]
000079a3731d1a54  vmovaps xmm3, [rsp+0x30]
000079a3731d1a5a  vmovaps xmm4, [rsp+0x40]
000079a3731d1a60  vmovaps xmm5, [rsp+0x50]
000079a3731d1a66  vmovaps xmm6, [rsp+0x60]
000079a3731d1a6c  vmovaps xmm7, [rsp+0x70]
000079a3731d1a72  vmovaps xmm8, [rsp+0x80]
000079a3731d1a7b  vmovaps xmm9, [rsp+0x90]
000079a3731d1a84  vmovaps xmm10, [rsp+0xA0]
000079a3731d1a8d  vmovaps xmm11, [rsp+0xB0]
000079a3731d1a96  vmovaps xmm12, [rsp+0xC0]
000079a3731d1a9f  vmovaps xmm13, [rsp+0xD0]
000079a3731d1aa8  vmovaps xmm14, [rsp+0xE0]
000079a3731d1ab1  add rsp, 0xF0
000079a3731d1ab8  pop r11
000079a3731d1aba  pop r10
000079a3731d1abc  pop r9
000079a3731d1abe  pop r8
000079a3731d1ac0  pop rsi
000079a3731d1ac1  pop rdi
000079a3731d1ac2  pop rdx
000079a3731d1ac3  pop rcx
000079a3731d1ac4  pop rax
000079a3731d1ac5  add rsp, 0x08
000079a3731d1ac9  jmp 0x000079A3731CF9E7
000079a3731d1ace  call 0x000079A372FFF430
000079a3731d1ad3  jmp 0x000079A3731CF9F4
000079a3731d1ad8  sub rsp, 0x08
000079a3731d1adc  push rax
000079a3731d1add  push rcx
000079a3731d1ade  push rdx
000079a3731d1adf  push rdi
000079a3731d1ae0  push rsi
000079a3731d1ae1  push r8
000079a3731d1ae3  push r9
000079a3731d1ae5  push r10
000079a3731d1ae7  push r11
000079a3731d1ae9  sub rsp, 0xF0
000079a3731d1af0  vmovaps [rsp], xmm0
000079a3731d1af5  vmovaps [rsp+0x10], xmm1
000079a3731d1afb  vmovaps [rsp+0x20], xmm2
000079a3731d1b01  vmovaps [rsp+0x30], xmm3
000079a3731d1b07  vmovaps [rsp+0x40], xmm4
000079a3731d1b0d  vmovaps [rsp+0x50], xmm5
000079a3731d1b13  vmovaps [rsp+0x60], xmm6
000079a3731d1b19  vmovaps [rsp+0x70], xmm7
000079a3731d1b1f  vmovaps [rsp+0x80], xmm8
000079a3731d1b28  vmovaps [rsp+0x90], xmm9
000079a3731d1b31  vmovaps [rsp+0xA0], xmm10
000079a3731d1b3a  vmovaps [rsp+0xB0], xmm11
000079a3731d1b43  vmovaps [rsp+0xC0], xmm12
000079a3731d1b4c  vmovaps [rsp+0xD0], xmm13
000079a3731d1b55  vmovaps [rsp+0xE0], xmm15
000079a3731d1b5e  sub rsp, 0x30
000079a3731d1b62  movaps [rsp], xmm14
000079a3731d1b67  movaps [rsp+0x10], xmm13
000079a3731d1b6d  movaps [rsp+0x20], xmm1
000079a3731d1b72  lea rdi, [rsp]
000079a3731d1b76  mov esi, 0x00
000079a3731d1b7b  mov rax, 0x64F127B95530
000079a3731d1b85  call rax
000079a3731d1b87  movaps xmm14, [rsp]
000079a3731d1b8c  add rsp, 0x30
000079a3731d1b90  vmovaps xmm0, [rsp]
000079a3731d1b95  vmovaps xmm1, [rsp+0x10]
000079a3731d1b9b  vmovaps xmm2, [rsp+0x20]
000079a3731d1ba1  vmovaps xmm3, [rsp+0x30]
000079a3731d1ba7  vmovaps xmm4, [rsp+0x40]
000079a3731d1bad  vmovaps xmm5, [rsp+0x50]
000079a3731d1bb3  vmovaps xmm6, [rsp+0x60]
000079a3731d1bb9  vmovaps xmm7, [rsp+0x70]
000079a3731d1bbf  vmovaps xmm8, [rsp+0x80]
000079a3731d1bc8  vmovaps xmm9, [rsp+0x90]
000079a3731d1bd1  vmovaps xmm10, [rsp+0xA0]
000079a3731d1bda  vmovaps xmm11, [rsp+0xB0]
000079a3731d1be3  vmovaps xmm12, [rsp+0xC0]
000079a3731d1bec  vmovaps xmm13, [rsp+0xD0]
000079a3731d1bf5  vmovaps xmm15, [rsp+0xE0]
000079a3731d1bfe  add rsp, 0xF0
000079a3731d1c05  pop r11
000079a3731d1c07  pop r10
000079a3731d1c09  pop r9
000079a3731d1c0b  pop r8
000079a3731d1c0d  pop rsi
000079a3731d1c0e  pop rdi
000079a3731d1c0f  pop rdx
000079a3731d1c10  pop rcx
000079a3731d1c11  pop rax
000079a3731d1c12  add rsp, 0x08
000079a3731d1c16  jmp 0x000079A3731CFAAF
000079a3731d1c1b  sub rsp, 0x08
000079a3731d1c1f  push rax
000079a3731d1c20  push rcx
000079a3731d1c21  push rdx
000079a3731d1c22  push rdi
000079a3731d1c23  push rsi
000079a3731d1c24  push r8
000079a3731d1c26  push r9
000079a3731d1c28  push r10
000079a3731d1c2a  push r11
000079a3731d1c2c  sub rsp, 0xF0
000079a3731d1c33  vmovaps [rsp], xmm0
000079a3731d1c38  vmovaps [rsp+0x10], xmm1
000079a3731d1c3e  vmovaps [rsp+0x20], xmm2
000079a3731d1c44  vmovaps [rsp+0x30], xmm3
000079a3731d1c4a  vmovaps [rsp+0x40], xmm4
000079a3731d1c50  vmovaps [rsp+0x50], xmm5
000079a3731d1c56  vmovaps [rsp+0x60], xmm6
000079a3731d1c5c  vmovaps [rsp+0x70], xmm7
000079a3731d1c62  vmovaps [rsp+0x80], xmm8
000079a3731d1c6b  vmovaps [rsp+0x90], xmm9
000079a3731d1c74  vmovaps [rsp+0xA0], xmm10
000079a3731d1c7d  vmovaps [rsp+0xB0], xmm11
000079a3731d1c86  vmovaps [rsp+0xC0], xmm12
000079a3731d1c8f  vmovaps [rsp+0xD0], xmm13
000079a3731d1c98  vmovaps [rsp+0xE0], xmm14
000079a3731d1ca1  sub rsp, 0x30
000079a3731d1ca5  movaps [rsp], xmm15
000079a3731d1caa  movaps [rsp+0x10], xmm13
000079a3731d1cb0  movaps [rsp+0x20], xmm1
000079a3731d1cb5  lea rdi, [rsp]
000079a3731d1cb9  mov esi, 0x00
000079a3731d1cbe  mov rax, 0x64F127B95530
000079a3731d1cc8  call rax
000079a3731d1cca  movaps xmm15, [rsp]
000079a3731d1ccf  add rsp, 0x30
000079a3731d1cd3  vmovaps xmm0, [rsp]
000079a3731d1cd8  vmovaps xmm1, [rsp+0x10]
000079a3731d1cde  vmovaps xmm2, [rsp+0x20]
000079a3731d1ce4  vmovaps xmm3, [rsp+0x30]
000079a3731d1cea  vmovaps xmm4, [rsp+0x40]
000079a3731d1cf0  vmovaps xmm5, [rsp+0x50]
000079a3731d1cf6  vmovaps xmm6, [rsp+0x60]
000079a3731d1cfc  vmovaps xmm7, [rsp+0x70]
000079a3731d1d02  vmovaps xmm8, [rsp+0x80]
000079a3731d1d0b  vmovaps xmm9, [rsp+0x90]
000079a3731d1d14  vmovaps xmm10, [rsp+0xA0]
000079a3731d1d1d  vmovaps xmm11, [rsp+0xB0]
000079a3731d1d26  vmovaps xmm12, [rsp+0xC0]
000079a3731d1d2f  vmovaps xmm13, [rsp+0xD0]
000079a3731d1d38  vmovaps xmm14, [rsp+0xE0]
000079a3731d1d41  add rsp, 0xF0
000079a3731d1d48  pop r11
000079a3731d1d4a  pop r10
000079a3731d1d4c  pop r9
000079a3731d1d4e  pop r8
000079a3731d1d50  pop rsi
000079a3731d1d51  pop rdi
000079a3731d1d52  pop rdx
000079a3731d1d53  pop rcx
000079a3731d1d54  pop rax
000079a3731d1d55  add rsp, 0x08
000079a3731d1d59  jmp 0x000079A3731CFAEB
000079a3731d1d5e  call 0x000079A372FFF430
000079a3731d1d63  jmp 0x000079A3731CFAF8
000079a3731d1d68  sub rsp, 0x08
000079a3731d1d6c  push rax
000079a3731d1d6d  push rcx
000079a3731d1d6e  push rdx
000079a3731d1d6f  push rdi
000079a3731d1d70  push rsi
000079a3731d1d71  push r8
000079a3731d1d73  push r9
000079a3731d1d75  push r10
000079a3731d1d77  push r11
000079a3731d1d79  sub rsp, 0xF0
000079a3731d1d80  vmovaps [rsp], xmm0
000079a3731d1d85  vmovaps [rsp+0x10], xmm1
000079a3731d1d8b  vmovaps [rsp+0x20], xmm2
000079a3731d1d91  vmovaps [rsp+0x30], xmm3
000079a3731d1d97  vmovaps [rsp+0x40], xmm4
000079a3731d1d9d  vmovaps [rsp+0x50], xmm5
000079a3731d1da3  vmovaps [rsp+0x60], xmm6
000079a3731d1da9  vmovaps [rsp+0x70], xmm7
000079a3731d1daf  vmovaps [rsp+0x80], xmm8
000079a3731d1db8  vmovaps [rsp+0x90], xmm9
000079a3731d1dc1  vmovaps [rsp+0xA0], xmm10
000079a3731d1dca  vmovaps [rsp+0xB0], xmm11
000079a3731d1dd3  vmovaps [rsp+0xC0], xmm12
000079a3731d1ddc  vmovaps [rsp+0xD0], xmm13
000079a3731d1de5  vmovaps [rsp+0xE0], xmm15
000079a3731d1dee  sub rsp, 0x30
000079a3731d1df2  movaps [rsp], xmm14
000079a3731d1df7  movaps [rsp+0x10], xmm13
000079a3731d1dfd  movaps [rsp+0x20], xmm2
000079a3731d1e02  lea rdi, [rsp]
000079a3731d1e06  mov esi, 0x00
000079a3731d1e0b  mov rax, 0x64F127B95530
000079a3731d1e15  call rax
000079a3731d1e17  movaps xmm14, [rsp]
000079a3731d1e1c  add rsp, 0x30
000079a3731d1e20  vmovaps xmm0, [rsp]
000079a3731d1e25  vmovaps xmm1, [rsp+0x10]
000079a3731d1e2b  vmovaps xmm2, [rsp+0x20]
000079a3731d1e31  vmovaps xmm3, [rsp+0x30]
000079a3731d1e37  vmovaps xmm4, [rsp+0x40]
000079a3731d1e3d  vmovaps xmm5, [rsp+0x50]
000079a3731d1e43  vmovaps xmm6, [rsp+0x60]
000079a3731d1e49  vmovaps xmm7, [rsp+0x70]
000079a3731d1e4f  vmovaps xmm8, [rsp+0x80]
000079a3731d1e58  vmovaps xmm9, [rsp+0x90]
000079a3731d1e61  vmovaps xmm10, [rsp+0xA0]
000079a3731d1e6a  vmovaps xmm11, [rsp+0xB0]
000079a3731d1e73  vmovaps xmm12, [rsp+0xC0]
000079a3731d1e7c  vmovaps xmm13, [rsp+0xD0]
000079a3731d1e85  vmovaps xmm15, [rsp+0xE0]
000079a3731d1e8e  add rsp, 0xF0
000079a3731d1e95  pop r11
000079a3731d1e97  pop r10
000079a3731d1e99  pop r9
000079a3731d1e9b  pop r8
000079a3731d1e9d  pop rsi
000079a3731d1e9e  pop rdi
000079a3731d1e9f  pop rdx
000079a3731d1ea0  pop rcx
000079a3731d1ea1  pop rax
000079a3731d1ea2  add rsp, 0x08
000079a3731d1ea6  jmp 0x000079A3731CFB24
000079a3731d1eab  sub rsp, 0x08
000079a3731d1eaf  push rax
000079a3731d1eb0  push rcx
000079a3731d1eb1  push rdx
000079a3731d1eb2  push rdi
000079a3731d1eb3  push rsi
000079a3731d1eb4  push r8
000079a3731d1eb6  push r9
000079a3731d1eb8  push r10
000079a3731d1eba  push r11
000079a3731d1ebc  sub rsp, 0xF0
000079a3731d1ec3  vmovaps [rsp], xmm0
000079a3731d1ec8  vmovaps [rsp+0x10], xmm2
000079a3731d1ece  vmovaps [rsp+0x20], xmm3
000079a3731d1ed4  vmovaps [rsp+0x30], xmm4
000079a3731d1eda  vmovaps [rsp+0x40], xmm5
000079a3731d1ee0  vmovaps [rsp+0x50], xmm6
000079a3731d1ee6  vmovaps [rsp+0x60], xmm7
000079a3731d1eec  vmovaps [rsp+0x70], xmm8
000079a3731d1ef2  vmovaps [rsp+0x80], xmm9
000079a3731d1efb  vmovaps [rsp+0x90], xmm10
000079a3731d1f04  vmovaps [rsp+0xA0], xmm11
000079a3731d1f0d  vmovaps [rsp+0xB0], xmm12
000079a3731d1f16  vmovaps [rsp+0xC0], xmm13
000079a3731d1f1f  vmovaps [rsp+0xD0], xmm14
000079a3731d1f28  vmovaps [rsp+0xE0], xmm15
000079a3731d1f31  sub rsp, 0x30
000079a3731d1f35  movaps [rsp], xmm1
000079a3731d1f39  movaps [rsp+0x10], xmm13
000079a3731d1f3f  movaps [rsp+0x20], xmm2
000079a3731d1f44  lea rdi, [rsp]
000079a3731d1f48  mov esi, 0x00
000079a3731d1f4d  mov rax, 0x64F127B95530
000079a3731d1f57  call rax
000079a3731d1f59  movaps xmm1, [rsp]
000079a3731d1f5d  add rsp, 0x30
000079a3731d1f61  vmovaps xmm0, [rsp]
000079a3731d1f66  vmovaps xmm2, [rsp+0x10]
000079a3731d1f6c  vmovaps xmm3, [rsp+0x20]
000079a3731d1f72  vmovaps xmm4, [rsp+0x30]
000079a3731d1f78  vmovaps xmm5, [rsp+0x40]
000079a3731d1f7e  vmovaps xmm6, [rsp+0x50]
000079a3731d1f84  vmovaps xmm7, [rsp+0x60]
000079a3731d1f8a  vmovaps xmm8, [rsp+0x70]
000079a3731d1f90  vmovaps xmm9, [rsp+0x80]
000079a3731d1f99  vmovaps xmm10, [rsp+0x90]
000079a3731d1fa2  vmovaps xmm11, [rsp+0xA0]
000079a3731d1fab  vmovaps xmm12, [rsp+0xB0]
000079a3731d1fb4  vmovaps xmm13, [rsp+0xC0]
000079a3731d1fbd  vmovaps xmm14, [rsp+0xD0]
000079a3731d1fc6  vmovaps xmm15, [rsp+0xE0]
000079a3731d1fcf  add rsp, 0xF0
000079a3731d1fd6  pop r11
000079a3731d1fd8  pop r10
000079a3731d1fda  pop r9
000079a3731d1fdc  pop r8
000079a3731d1fde  pop rsi
000079a3731d1fdf  pop rdi
000079a3731d1fe0  pop rdx
000079a3731d1fe1  pop rcx
000079a3731d1fe2  pop rax
000079a3731d1fe3  add rsp, 0x08
000079a3731d1fe7  jmp 0x000079A3731CFB52
000079a3731d1fec  sub rsp, 0x08
000079a3731d1ff0  push rax
000079a3731d1ff1  push rcx
000079a3731d1ff2  push rdx
000079a3731d1ff3  push rdi
000079a3731d1ff4  push rsi
000079a3731d1ff5  push r8
000079a3731d1ff7  push r9
000079a3731d1ff9  push r10
000079a3731d1ffb  push r11
000079a3731d1ffd  sub rsp, 0xF0
000079a3731d2004  vmovaps [rsp], xmm0
000079a3731d2009  vmovaps [rsp+0x10], xmm1
000079a3731d200f  vmovaps [rsp+0x20], xmm3
000079a3731d2015  vmovaps [rsp+0x30], xmm4
000079a3731d201b  vmovaps [rsp+0x40], xmm5
000079a3731d2021  vmovaps [rsp+0x50], xmm6
000079a3731d2027  vmovaps [rsp+0x60], xmm7
000079a3731d202d  vmovaps [rsp+0x70], xmm8
000079a3731d2033  vmovaps [rsp+0x80], xmm9
000079a3731d203c  vmovaps [rsp+0x90], xmm10
000079a3731d2045  vmovaps [rsp+0xA0], xmm11
000079a3731d204e  vmovaps [rsp+0xB0], xmm12
000079a3731d2057  vmovaps [rsp+0xC0], xmm13
000079a3731d2060  vmovaps [rsp+0xD0], xmm14
000079a3731d2069  vmovaps [rsp+0xE0], xmm15
000079a3731d2072  sub rsp, 0x30
000079a3731d2076  movaps [rsp], xmm2
000079a3731d207a  movaps [rsp+0x10], xmm1
000079a3731d207f  movaps [rsp+0x20], xmm13
000079a3731d2085  lea rdi, [rsp]
000079a3731d2089  mov esi, 0x00
000079a3731d208e  mov rax, 0x64F127B95530
000079a3731d2098  call rax
000079a3731d209a  movaps xmm2, [rsp]
000079a3731d209e  add rsp, 0x30
000079a3731d20a2  vmovaps xmm0, [rsp]
000079a3731d20a7  vmovaps xmm1, [rsp+0x10]
000079a3731d20ad  vmovaps xmm3, [rsp+0x20]
000079a3731d20b3  vmovaps xmm4, [rsp+0x30]
000079a3731d20b9  vmovaps xmm5, [rsp+0x40]
000079a3731d20bf  vmovaps xmm6, [rsp+0x50]
000079a3731d20c5  vmovaps xmm7, [rsp+0x60]
000079a3731d20cb  vmovaps xmm8, [rsp+0x70]
000079a3731d20d1  vmovaps xmm9, [rsp+0x80]
000079a3731d20da  vmovaps xmm10, [rsp+0x90]
000079a3731d20e3  vmovaps xmm11, [rsp+0xA0]
000079a3731d20ec  vmovaps xmm12, [rsp+0xB0]
000079a3731d20f5  vmovaps xmm13, [rsp+0xC0]
000079a3731d20fe  vmovaps xmm14, [rsp+0xD0]
000079a3731d2107  vmovaps xmm15, [rsp+0xE0]
000079a3731d2110  add rsp, 0xF0
000079a3731d2117  pop r11
000079a3731d2119  pop r10
000079a3731d211b  pop r9
000079a3731d211d  pop r8
000079a3731d211f  pop rsi
000079a3731d2120  pop rdi
000079a3731d2121  pop rdx
000079a3731d2122  pop rcx
000079a3731d2123  pop rax
000079a3731d2124  add rsp, 0x08
000079a3731d2128  jmp 0x000079A3731CFBAB
000079a3731d212d  call 0x000079A372FFF430
000079a3731d2132  jmp 0x000079A3731CFBB8
000079a3731d2137  sub rsp, 0x08
000079a3731d213b  push rax
000079a3731d213c  push rcx
000079a3731d213d  push rdx
000079a3731d213e  push rdi
000079a3731d213f  push rsi
000079a3731d2140  push r8
000079a3731d2142  push r9
000079a3731d2144  push r10
000079a3731d2146  push r11
000079a3731d2148  sub rsp, 0xF0
000079a3731d214f  vmovaps [rsp], xmm0
000079a3731d2154  vmovaps [rsp+0x10], xmm1
000079a3731d215a  vmovaps [rsp+0x20], xmm2
000079a3731d2160  vmovaps [rsp+0x30], xmm3
000079a3731d2166  vmovaps [rsp+0x40], xmm4
000079a3731d216c  vmovaps [rsp+0x50], xmm5
000079a3731d2172  vmovaps [rsp+0x60], xmm6
000079a3731d2178  vmovaps [rsp+0x70], xmm7
000079a3731d217e  vmovaps [rsp+0x80], xmm8
000079a3731d2187  vmovaps [rsp+0x90], xmm9
000079a3731d2190  vmovaps [rsp+0xA0], xmm10
000079a3731d2199  vmovaps [rsp+0xB0], xmm11
000079a3731d21a2  vmovaps [rsp+0xC0], xmm12
000079a3731d21ab  vmovaps [rsp+0xD0], xmm13
000079a3731d21b4  vmovaps [rsp+0xE0], xmm14
000079a3731d21bd  sub rsp, 0x30
000079a3731d21c1  movaps [rsp], xmm15
000079a3731d21c6  movaps [rsp+0x10], xmm13
000079a3731d21cc  movaps [rsp+0x20], xmm1
000079a3731d21d1  lea rdi, [rsp]
000079a3731d21d5  mov esi, 0x00
000079a3731d21da  mov rax, 0x64F127B95530
000079a3731d21e4  call rax
000079a3731d21e6  movaps xmm15, [rsp]
000079a3731d21eb  add rsp, 0x30
000079a3731d21ef  vmovaps xmm0, [rsp]
000079a3731d21f4  vmovaps xmm1, [rsp+0x10]
000079a3731d21fa  vmovaps xmm2, [rsp+0x20]
000079a3731d2200  vmovaps xmm3, [rsp+0x30]
000079a3731d2206  vmovaps xmm4, [rsp+0x40]
000079a3731d220c  vmovaps xmm5, [rsp+0x50]
000079a3731d2212  vmovaps xmm6, [rsp+0x60]
000079a3731d2218  vmovaps xmm7, [rsp+0x70]
000079a3731d221e  vmovaps xmm8, [rsp+0x80]
000079a3731d2227  vmovaps xmm9, [rsp+0x90]
000079a3731d2230  vmovaps xmm10, [rsp+0xA0]
000079a3731d2239  vmovaps xmm11, [rsp+0xB0]
000079a3731d2242  vmovaps xmm12, [rsp+0xC0]
000079a3731d224b  vmovaps xmm13, [rsp+0xD0]
000079a3731d2254  vmovaps xmm14, [rsp+0xE0]
000079a3731d225d  add rsp, 0xF0
000079a3731d2264  pop r11
000079a3731d2266  pop r10
000079a3731d2268  pop r9
000079a3731d226a  pop r8
000079a3731d226c  pop rsi
000079a3731d226d  pop rdi
000079a3731d226e  pop rdx
000079a3731d226f  pop rcx
000079a3731d2270  pop rax
000079a3731d2271  add rsp, 0x08
000079a3731d2275  jmp 0x000079A3731CFBF7
000079a3731d227a  sub rsp, 0x08
000079a3731d227e  push rax
000079a3731d227f  push rcx
000079a3731d2280  push rdx
000079a3731d2281  push rdi
000079a3731d2282  push rsi
000079a3731d2283  push r8
000079a3731d2285  push r9
000079a3731d2287  push r10
000079a3731d2289  push r11
000079a3731d228b  sub rsp, 0xF0
000079a3731d2292  vmovaps [rsp], xmm0
000079a3731d2297  vmovaps [rsp+0x10], xmm1
000079a3731d229d  vmovaps [rsp+0x20], xmm2
000079a3731d22a3  vmovaps [rsp+0x30], xmm3
000079a3731d22a9  vmovaps [rsp+0x40], xmm4
000079a3731d22af  vmovaps [rsp+0x50], xmm5
000079a3731d22b5  vmovaps [rsp+0x60], xmm6
000079a3731d22bb  vmovaps [rsp+0x70], xmm7
000079a3731d22c1  vmovaps [rsp+0x80], xmm8
000079a3731d22ca  vmovaps [rsp+0x90], xmm9
000079a3731d22d3  vmovaps [rsp+0xA0], xmm10
000079a3731d22dc  vmovaps [rsp+0xB0], xmm11
000079a3731d22e5  vmovaps [rsp+0xC0], xmm12
000079a3731d22ee  vmovaps [rsp+0xD0], xmm13
000079a3731d22f7  vmovaps [rsp+0xE0], xmm15
000079a3731d2300  sub rsp, 0x30
000079a3731d2304  movaps [rsp], xmm14
000079a3731d2309  movaps [rsp+0x10], xmm11
000079a3731d230f  movaps [rsp+0x20], xmm1
000079a3731d2314  lea rdi, [rsp]
000079a3731d2318  mov esi, 0x00
000079a3731d231d  mov rax, 0x64F127B95530
000079a3731d2327  call rax
000079a3731d2329  movaps xmm14, [rsp]
000079a3731d232e  add rsp, 0x30
000079a3731d2332  vmovaps xmm0, [rsp]
000079a3731d2337  vmovaps xmm1, [rsp+0x10]
000079a3731d233d  vmovaps xmm2, [rsp+0x20]
000079a3731d2343  vmovaps xmm3, [rsp+0x30]
000079a3731d2349  vmovaps xmm4, [rsp+0x40]
000079a3731d234f  vmovaps xmm5, [rsp+0x50]
000079a3731d2355  vmovaps xmm6, [rsp+0x60]
000079a3731d235b  vmovaps xmm7, [rsp+0x70]
000079a3731d2361  vmovaps xmm8, [rsp+0x80]
000079a3731d236a  vmovaps xmm9, [rsp+0x90]
000079a3731d2373  vmovaps xmm10, [rsp+0xA0]
000079a3731d237c  vmovaps xmm11, [rsp+0xB0]
000079a3731d2385  vmovaps xmm12, [rsp+0xC0]
000079a3731d238e  vmovaps xmm13, [rsp+0xD0]
000079a3731d2397  vmovaps xmm15, [rsp+0xE0]
000079a3731d23a0  add rsp, 0xF0
000079a3731d23a7  pop r11
000079a3731d23a9  pop r10
000079a3731d23ab  pop r9
000079a3731d23ad  pop r8
000079a3731d23af  pop rsi
000079a3731d23b0  pop rdi
000079a3731d23b1  pop rdx
000079a3731d23b2  pop rcx
000079a3731d23b3  pop rax
000079a3731d23b4  add rsp, 0x08
000079a3731d23b8  jmp 0x000079A3731CFC21
000079a3731d23bd  sub rsp, 0x08
000079a3731d23c1  push rax
000079a3731d23c2  push rcx
000079a3731d23c3  push rdx
000079a3731d23c4  push rdi
000079a3731d23c5  push rsi
000079a3731d23c6  push r8
000079a3731d23c8  push r9
000079a3731d23ca  push r10
000079a3731d23cc  push r11
000079a3731d23ce  sub rsp, 0xF0
000079a3731d23d5  vmovaps [rsp], xmm0
000079a3731d23da  vmovaps [rsp+0x10], xmm1
000079a3731d23e0  vmovaps [rsp+0x20], xmm2
000079a3731d23e6  vmovaps [rsp+0x30], xmm3
000079a3731d23ec  vmovaps [rsp+0x40], xmm4
000079a3731d23f2  vmovaps [rsp+0x50], xmm5
000079a3731d23f8  vmovaps [rsp+0x60], xmm6
000079a3731d23fe  vmovaps [rsp+0x70], xmm7
000079a3731d2404  vmovaps [rsp+0x80], xmm8
000079a3731d240d  vmovaps [rsp+0x90], xmm9
000079a3731d2416  vmovaps [rsp+0xA0], xmm10
000079a3731d241f  vmovaps [rsp+0xB0], xmm11
000079a3731d2428  vmovaps [rsp+0xC0], xmm12
000079a3731d2431  vmovaps [rsp+0xD0], xmm14
000079a3731d243a  vmovaps [rsp+0xE0], xmm15
000079a3731d2443  sub rsp, 0x30
000079a3731d2447  movaps [rsp], xmm13
000079a3731d244c  movaps [rsp+0x10], xmm11
000079a3731d2452  movaps [rsp+0x20], xmm1
000079a3731d2457  lea rdi, [rsp]
000079a3731d245b  mov esi, 0x00
000079a3731d2460  mov rax, 0x64F127B95530
000079a3731d246a  call rax
000079a3731d246c  movaps xmm13, [rsp]
000079a3731d2471  add rsp, 0x30
000079a3731d2475  vmovaps xmm0, [rsp]
000079a3731d247a  vmovaps xmm1, [rsp+0x10]
000079a3731d2480  vmovaps xmm2, [rsp+0x20]
000079a3731d2486  vmovaps xmm3, [rsp+0x30]
000079a3731d248c  vmovaps xmm4, [rsp+0x40]
000079a3731d2492  vmovaps xmm5, [rsp+0x50]
000079a3731d2498  vmovaps xmm6, [rsp+0x60]
000079a3731d249e  vmovaps xmm7, [rsp+0x70]
000079a3731d24a4  vmovaps xmm8, [rsp+0x80]
000079a3731d24ad  vmovaps xmm9, [rsp+0x90]
000079a3731d24b6  vmovaps xmm10, [rsp+0xA0]
000079a3731d24bf  vmovaps xmm11, [rsp+0xB0]
000079a3731d24c8  vmovaps xmm12, [rsp+0xC0]
000079a3731d24d1  vmovaps xmm14, [rsp+0xD0]
000079a3731d24da  vmovaps xmm15, [rsp+0xE0]
000079a3731d24e3  add rsp, 0xF0
000079a3731d24ea  pop r11
000079a3731d24ec  pop r10
000079a3731d24ee  pop r9
000079a3731d24f0  pop r8
000079a3731d24f2  pop rsi
000079a3731d24f3  pop rdi
000079a3731d24f4  pop rdx
000079a3731d24f5  pop rcx
000079a3731d24f6  pop rax
000079a3731d24f7  add rsp, 0x08
000079a3731d24fb  jmp 0x000079A3731CFC76
000079a3731d2500  call 0x000079A372FFF430
000079a3731d2505  jmp 0x000079A3731CFC83
000079a3731d250a  sub rsp, 0x08
000079a3731d250e  push rax
000079a3731d250f  push rcx
000079a3731d2510  push rdx
000079a3731d2511  push rdi
000079a3731d2512  push rsi
000079a3731d2513  push r8
000079a3731d2515  push r9
000079a3731d2517  push r10
000079a3731d2519  push r11
000079a3731d251b  sub rsp, 0xF0
000079a3731d2522  vmovaps [rsp], xmm0
000079a3731d2527  vmovaps [rsp+0x10], xmm1
000079a3731d252d  vmovaps [rsp+0x20], xmm2
000079a3731d2533  vmovaps [rsp+0x30], xmm3
000079a3731d2539  vmovaps [rsp+0x40], xmm4
000079a3731d253f  vmovaps [rsp+0x50], xmm5
000079a3731d2545  vmovaps [rsp+0x60], xmm6
000079a3731d254b  vmovaps [rsp+0x70], xmm7
000079a3731d2551  vmovaps [rsp+0x80], xmm8
000079a3731d255a  vmovaps [rsp+0x90], xmm9
000079a3731d2563  vmovaps [rsp+0xA0], xmm10
000079a3731d256c  vmovaps [rsp+0xB0], xmm11
000079a3731d2575  vmovaps [rsp+0xC0], xmm12
000079a3731d257e  vmovaps [rsp+0xD0], xmm13
000079a3731d2587  vmovaps [rsp+0xE0], xmm14
000079a3731d2590  sub rsp, 0x30
000079a3731d2594  movaps [rsp], xmm15
000079a3731d2599  movaps [rsp+0x10], xmm11
000079a3731d259f  movaps [rsp+0x20], xmm1
000079a3731d25a4  lea rdi, [rsp]
000079a3731d25a8  mov esi, 0x00
000079a3731d25ad  mov rax, 0x64F127B95530
000079a3731d25b7  call rax
000079a3731d25b9  movaps xmm15, [rsp]
000079a3731d25be  add rsp, 0x30
000079a3731d25c2  vmovaps xmm0, [rsp]
000079a3731d25c7  vmovaps xmm1, [rsp+0x10]
000079a3731d25cd  vmovaps xmm2, [rsp+0x20]
000079a3731d25d3  vmovaps xmm3, [rsp+0x30]
000079a3731d25d9  vmovaps xmm4, [rsp+0x40]
000079a3731d25df  vmovaps xmm5, [rsp+0x50]
000079a3731d25e5  vmovaps xmm6, [rsp+0x60]
000079a3731d25eb  vmovaps xmm7, [rsp+0x70]
000079a3731d25f1  vmovaps xmm8, [rsp+0x80]
000079a3731d25fa  vmovaps xmm9, [rsp+0x90]
000079a3731d2603  vmovaps xmm10, [rsp+0xA0]
000079a3731d260c  vmovaps xmm11, [rsp+0xB0]
000079a3731d2615  vmovaps xmm12, [rsp+0xC0]
000079a3731d261e  vmovaps xmm13, [rsp+0xD0]
000079a3731d2627  vmovaps xmm14, [rsp+0xE0]
000079a3731d2630  add rsp, 0xF0
000079a3731d2637  pop r11
000079a3731d2639  pop r10
000079a3731d263b  pop r9
000079a3731d263d  pop r8
000079a3731d263f  pop rsi
000079a3731d2640  pop rdi
000079a3731d2641  pop rdx
000079a3731d2642  pop rcx
000079a3731d2643  pop rax
000079a3731d2644  add rsp, 0x08
000079a3731d2648  jmp 0x000079A3731CFCBC
000079a3731d264d  sub rsp, 0x08
000079a3731d2651  push rax
000079a3731d2652  push rcx
000079a3731d2653  push rdx
000079a3731d2654  push rdi
000079a3731d2655  push rsi
000079a3731d2656  push r8
000079a3731d2658  push r9
000079a3731d265a  push r10
000079a3731d265c  push r11
000079a3731d265e  sub rsp, 0xF0
000079a3731d2665  vmovaps [rsp], xmm0
000079a3731d266a  vmovaps [rsp+0x10], xmm1
000079a3731d2670  vmovaps [rsp+0x20], xmm2
000079a3731d2676  vmovaps [rsp+0x30], xmm3
000079a3731d267c  vmovaps [rsp+0x40], xmm4
000079a3731d2682  vmovaps [rsp+0x50], xmm5
000079a3731d2688  vmovaps [rsp+0x60], xmm6
000079a3731d268e  vmovaps [rsp+0x70], xmm7
000079a3731d2694  vmovaps [rsp+0x80], xmm8
000079a3731d269d  vmovaps [rsp+0x90], xmm9
000079a3731d26a6  vmovaps [rsp+0xA0], xmm10
000079a3731d26af  vmovaps [rsp+0xB0], xmm12
000079a3731d26b8  vmovaps [rsp+0xC0], xmm13
000079a3731d26c1  vmovaps [rsp+0xD0], xmm14
000079a3731d26ca  vmovaps [rsp+0xE0], xmm15
000079a3731d26d3  sub rsp, 0x30
000079a3731d26d7  movaps [rsp], xmm11
000079a3731d26dc  movaps [rsp+0x10], xmm6
000079a3731d26e1  movaps [rsp+0x20], xmm14
000079a3731d26e7  lea rdi, [rsp]
000079a3731d26eb  mov esi, 0x00
000079a3731d26f0  mov rax, 0x64F127B95530
000079a3731d26fa  call rax
000079a3731d26fc  movaps xmm11, [rsp]
000079a3731d2701  add rsp, 0x30
000079a3731d2705  vmovaps xmm0, [rsp]
000079a3731d270a  vmovaps xmm1, [rsp+0x10]
000079a3731d2710  vmovaps xmm2, [rsp+0x20]
000079a3731d2716  vmovaps xmm3, [rsp+0x30]
000079a3731d271c  vmovaps xmm4, [rsp+0x40]
000079a3731d2722  vmovaps xmm5, [rsp+0x50]
000079a3731d2728  vmovaps xmm6, [rsp+0x60]
000079a3731d272e  vmovaps xmm7, [rsp+0x70]
000079a3731d2734  vmovaps xmm8, [rsp+0x80]
000079a3731d273d  vmovaps xmm9, [rsp+0x90]
000079a3731d2746  vmovaps xmm10, [rsp+0xA0]
000079a3731d274f  vmovaps xmm12, [rsp+0xB0]
000079a3731d2758  vmovaps xmm13, [rsp+0xC0]
000079a3731d2761  vmovaps xmm14, [rsp+0xD0]
000079a3731d276a  vmovaps xmm15, [rsp+0xE0]
000079a3731d2773  add rsp, 0xF0
000079a3731d277a  pop r11
000079a3731d277c  pop r10
000079a3731d277e  pop r9
000079a3731d2780  pop r8
000079a3731d2782  pop rsi
000079a3731d2783  pop rdi
000079a3731d2784  pop rdx
000079a3731d2785  pop rcx
000079a3731d2786  pop rax
000079a3731d2787  add rsp, 0x08
000079a3731d278b  jmp 0x000079A3731CFD34
000079a3731d2790  call 0x000079A372FFF430
000079a3731d2795  jmp 0x000079A3731CFD3E
000079a3731d279a  sub rsp, 0x08
000079a3731d279e  push rax
000079a3731d279f  push rcx
000079a3731d27a0  push rdx
000079a3731d27a1  push rdi
000079a3731d27a2  push rsi
000079a3731d27a3  push r8
000079a3731d27a5  push r9
000079a3731d27a7  push r10
000079a3731d27a9  push r11
000079a3731d27ab  sub rsp, 0xF0
000079a3731d27b2  vmovaps [rsp], xmm0
000079a3731d27b7  vmovaps [rsp+0x10], xmm1
000079a3731d27bd  vmovaps [rsp+0x20], xmm2
000079a3731d27c3  vmovaps [rsp+0x30], xmm3
000079a3731d27c9  vmovaps [rsp+0x40], xmm4
000079a3731d27cf  vmovaps [rsp+0x50], xmm5
000079a3731d27d5  vmovaps [rsp+0x60], xmm6
000079a3731d27db  vmovaps [rsp+0x70], xmm7
000079a3731d27e1  vmovaps [rsp+0x80], xmm8
000079a3731d27ea  vmovaps [rsp+0x90], xmm9
000079a3731d27f3  vmovaps [rsp+0xA0], xmm10
000079a3731d27fc  vmovaps [rsp+0xB0], xmm11
000079a3731d2805  vmovaps [rsp+0xC0], xmm12
000079a3731d280e  vmovaps [rsp+0xD0], xmm13
000079a3731d2817  vmovaps [rsp+0xE0], xmm15
000079a3731d2820  sub rsp, 0x30
000079a3731d2824  movaps [rsp], xmm14
000079a3731d2829  movaps [rsp+0x10], xmm6
000079a3731d282e  movaps [rsp+0x20], xmm2
000079a3731d2833  lea rdi, [rsp]
000079a3731d2837  mov esi, 0x00
000079a3731d283c  mov rax, 0x64F127B95530
000079a3731d2846  call rax
000079a3731d2848  movaps xmm14, [rsp]
000079a3731d284d  add rsp, 0x30
000079a3731d2851  vmovaps xmm0, [rsp]
000079a3731d2856  vmovaps xmm1, [rsp+0x10]
000079a3731d285c  vmovaps xmm2, [rsp+0x20]
000079a3731d2862  vmovaps xmm3, [rsp+0x30]
000079a3731d2868  vmovaps xmm4, [rsp+0x40]
000079a3731d286e  vmovaps xmm5, [rsp+0x50]
000079a3731d2874  vmovaps xmm6, [rsp+0x60]
000079a3731d287a  vmovaps xmm7, [rsp+0x70]
000079a3731d2880  vmovaps xmm8, [rsp+0x80]
000079a3731d2889  vmovaps xmm9, [rsp+0x90]
000079a3731d2892  vmovaps xmm10, [rsp+0xA0]
000079a3731d289b  vmovaps xmm11, [rsp+0xB0]
000079a3731d28a4  vmovaps xmm12, [rsp+0xC0]
000079a3731d28ad  vmovaps xmm13, [rsp+0xD0]
000079a3731d28b6  vmovaps xmm15, [rsp+0xE0]
000079a3731d28bf  add rsp, 0xF0
000079a3731d28c6  pop r11
000079a3731d28c8  pop r10
000079a3731d28ca  pop r9
000079a3731d28cc  pop r8
000079a3731d28ce  pop rsi
000079a3731d28cf  pop rdi
000079a3731d28d0  pop rdx
000079a3731d28d1  pop rcx
000079a3731d28d2  pop rax
000079a3731d28d3  add rsp, 0x08
000079a3731d28d7  jmp 0x000079A3731CFD72
000079a3731d28dc  sub rsp, 0x08
000079a3731d28e0  push rax
000079a3731d28e1  push rcx
000079a3731d28e2  push rdx
000079a3731d28e3  push rdi
000079a3731d28e4  push rsi
000079a3731d28e5  push r8
000079a3731d28e7  push r9
000079a3731d28e9  push r10
000079a3731d28eb  push r11
000079a3731d28ed  sub rsp, 0xF0
000079a3731d28f4  vmovaps [rsp], xmm0
000079a3731d28f9  vmovaps [rsp+0x10], xmm1
000079a3731d28ff  vmovaps [rsp+0x20], xmm2
000079a3731d2905  vmovaps [rsp+0x30], xmm3
000079a3731d290b  vmovaps [rsp+0x40], xmm4
000079a3731d2911  vmovaps [rsp+0x50], xmm5
000079a3731d2917  vmovaps [rsp+0x60], xmm7
000079a3731d291d  vmovaps [rsp+0x70], xmm8
000079a3731d2923  vmovaps [rsp+0x80], xmm9
000079a3731d292c  vmovaps [rsp+0x90], xmm10
000079a3731d2935  vmovaps [rsp+0xA0], xmm11
000079a3731d293e  vmovaps [rsp+0xB0], xmm12
000079a3731d2947  vmovaps [rsp+0xC0], xmm13
000079a3731d2950  vmovaps [rsp+0xD0], xmm14
000079a3731d2959  vmovaps [rsp+0xE0], xmm15
000079a3731d2962  sub rsp, 0x30
000079a3731d2966  movaps [rsp], xmm6
000079a3731d296a  movaps [rsp+0x10], xmm5
000079a3731d296f  movaps [rsp+0x20], xmm1
000079a3731d2974  lea rdi, [rsp]
000079a3731d2978  mov esi, 0x00
000079a3731d297d  mov rax, 0x64F127B95530
000079a3731d2987  call rax
000079a3731d2989  movaps xmm6, [rsp]
000079a3731d298d  add rsp, 0x30
000079a3731d2991  vmovaps xmm0, [rsp]
000079a3731d2996  vmovaps xmm1, [rsp+0x10]
000079a3731d299c  vmovaps xmm2, [rsp+0x20]
000079a3731d29a2  vmovaps xmm3, [rsp+0x30]
000079a3731d29a8  vmovaps xmm4, [rsp+0x40]
000079a3731d29ae  vmovaps xmm5, [rsp+0x50]
000079a3731d29b4  vmovaps xmm7, [rsp+0x60]
000079a3731d29ba  vmovaps xmm8, [rsp+0x70]
000079a3731d29c0  vmovaps xmm9, [rsp+0x80]
000079a3731d29c9  vmovaps xmm10, [rsp+0x90]
000079a3731d29d2  vmovaps xmm11, [rsp+0xA0]
000079a3731d29db  vmovaps xmm12, [rsp+0xB0]
000079a3731d29e4  vmovaps xmm13, [rsp+0xC0]
000079a3731d29ed  vmovaps xmm14, [rsp+0xD0]
000079a3731d29f6  vmovaps xmm15, [rsp+0xE0]
000079a3731d29ff  add rsp, 0xF0
000079a3731d2a06  pop r11
000079a3731d2a08  pop r10
000079a3731d2a0a  pop r9
000079a3731d2a0c  pop r8
000079a3731d2a0e  pop rsi
000079a3731d2a0f  pop rdi
000079a3731d2a10  pop rdx
000079a3731d2a11  pop rcx
000079a3731d2a12  pop rax
000079a3731d2a13  add rsp, 0x08
000079a3731d2a17  jmp 0x000079A3731CFD98
000079a3731d2a1c  sub rsp, 0x08
000079a3731d2a20  push rax
000079a3731d2a21  push rcx
000079a3731d2a22  push rdx
000079a3731d2a23  push rdi
000079a3731d2a24  push rsi
000079a3731d2a25  push r8
000079a3731d2a27  push r9
000079a3731d2a29  push r10
000079a3731d2a2b  push r11
000079a3731d2a2d  sub rsp, 0xF0
000079a3731d2a34  vmovaps [rsp], xmm0
000079a3731d2a39  vmovaps [rsp+0x10], xmm2
000079a3731d2a3f  vmovaps [rsp+0x20], xmm3
000079a3731d2a45  vmovaps [rsp+0x30], xmm4
000079a3731d2a4b  vmovaps [rsp+0x40], xmm5
000079a3731d2a51  vmovaps [rsp+0x50], xmm6
000079a3731d2a57  vmovaps [rsp+0x60], xmm7
000079a3731d2a5d  vmovaps [rsp+0x70], xmm8
000079a3731d2a63  vmovaps [rsp+0x80], xmm9
000079a3731d2a6c  vmovaps [rsp+0x90], xmm10
000079a3731d2a75  vmovaps [rsp+0xA0], xmm11
000079a3731d2a7e  vmovaps [rsp+0xB0], xmm12
000079a3731d2a87  vmovaps [rsp+0xC0], xmm13
000079a3731d2a90  vmovaps [rsp+0xD0], xmm14
000079a3731d2a99  vmovaps [rsp+0xE0], xmm15
000079a3731d2aa2  sub rsp, 0x30
000079a3731d2aa6  movaps [rsp], xmm1
000079a3731d2aaa  movaps [rsp+0x10], xmm5
000079a3731d2aaf  movaps [rsp+0x20], xmm13
000079a3731d2ab5  lea rdi, [rsp]
000079a3731d2ab9  mov esi, 0x00
000079a3731d2abe  mov rax, 0x64F127B95530
000079a3731d2ac8  call rax
000079a3731d2aca  movaps xmm1, [rsp]
000079a3731d2ace  add rsp, 0x30
000079a3731d2ad2  vmovaps xmm0, [rsp]
000079a3731d2ad7  vmovaps xmm2, [rsp+0x10]
000079a3731d2add  vmovaps xmm3, [rsp+0x20]
000079a3731d2ae3  vmovaps xmm4, [rsp+0x30]
000079a3731d2ae9  vmovaps xmm5, [rsp+0x40]
000079a3731d2aef  vmovaps xmm6, [rsp+0x50]
000079a3731d2af5  vmovaps xmm7, [rsp+0x60]
000079a3731d2afb  vmovaps xmm8, [rsp+0x70]
000079a3731d2b01  vmovaps xmm9, [rsp+0x80]
000079a3731d2b0a  vmovaps xmm10, [rsp+0x90]
000079a3731d2b13  vmovaps xmm11, [rsp+0xA0]
000079a3731d2b1c  vmovaps xmm12, [rsp+0xB0]
000079a3731d2b25  vmovaps xmm13, [rsp+0xC0]
000079a3731d2b2e  vmovaps xmm14, [rsp+0xD0]
000079a3731d2b37  vmovaps xmm15, [rsp+0xE0]
000079a3731d2b40  add rsp, 0xF0
000079a3731d2b47  pop r11
000079a3731d2b49  pop r10
000079a3731d2b4b  pop r9
000079a3731d2b4d  pop r8
000079a3731d2b4f  pop rsi
000079a3731d2b50  pop rdi
000079a3731d2b51  pop rdx
000079a3731d2b52  pop rcx
000079a3731d2b53  pop rax
000079a3731d2b54  add rsp, 0x08
000079a3731d2b58  jmp 0x000079A3731CFDB6
000079a3731d2b5d  sub rsp, 0x08
000079a3731d2b61  push rax
000079a3731d2b62  push rcx
000079a3731d2b63  push rdx
000079a3731d2b64  push rdi
000079a3731d2b65  push rsi
000079a3731d2b66  push r8
000079a3731d2b68  push r9
000079a3731d2b6a  push r10
000079a3731d2b6c  push r11
000079a3731d2b6e  sub rsp, 0xF0
000079a3731d2b75  vmovaps [rsp], xmm0
000079a3731d2b7a  vmovaps [rsp+0x10], xmm1
000079a3731d2b80  vmovaps [rsp+0x20], xmm2
000079a3731d2b86  vmovaps [rsp+0x30], xmm3
000079a3731d2b8c  vmovaps [rsp+0x40], xmm4
000079a3731d2b92  vmovaps [rsp+0x50], xmm6
000079a3731d2b98  vmovaps [rsp+0x60], xmm7
000079a3731d2b9e  vmovaps [rsp+0x70], xmm8
000079a3731d2ba4  vmovaps [rsp+0x80], xmm9
000079a3731d2bad  vmovaps [rsp+0x90], xmm10
000079a3731d2bb6  vmovaps [rsp+0xA0], xmm11
000079a3731d2bbf  vmovaps [rsp+0xB0], xmm12
000079a3731d2bc8  vmovaps [rsp+0xC0], xmm13
000079a3731d2bd1  vmovaps [rsp+0xD0], xmm14
000079a3731d2bda  vmovaps [rsp+0xE0], xmm15
000079a3731d2be3  sub rsp, 0x30
000079a3731d2be7  movaps [rsp], xmm5
000079a3731d2beb  movaps [rsp+0x10], xmm2
000079a3731d2bf0  movaps [rsp+0x20], xmm13
000079a3731d2bf6  lea rdi, [rsp]
000079a3731d2bfa  mov esi, 0x00
000079a3731d2bff  mov rax, 0x64F127B95530
000079a3731d2c09  call rax
000079a3731d2c0b  movaps xmm5, [rsp]
000079a3731d2c0f  add rsp, 0x30
000079a3731d2c13  vmovaps xmm0, [rsp]
000079a3731d2c18  vmovaps xmm1, [rsp+0x10]
000079a3731d2c1e  vmovaps xmm2, [rsp+0x20]
000079a3731d2c24  vmovaps xmm3, [rsp+0x30]
000079a3731d2c2a  vmovaps xmm4, [rsp+0x40]
000079a3731d2c30  vmovaps xmm6, [rsp+0x50]
000079a3731d2c36  vmovaps xmm7, [rsp+0x60]
000079a3731d2c3c  vmovaps xmm8, [rsp+0x70]
000079a3731d2c42  vmovaps xmm9, [rsp+0x80]
000079a3731d2c4b  vmovaps xmm10, [rsp+0x90]
000079a3731d2c54  vmovaps xmm11, [rsp+0xA0]
000079a3731d2c5d  vmovaps xmm12, [rsp+0xB0]
000079a3731d2c66  vmovaps xmm13, [rsp+0xC0]
000079a3731d2c6f  vmovaps xmm14, [rsp+0xD0]
000079a3731d2c78  vmovaps xmm15, [rsp+0xE0]
000079a3731d2c81  add rsp, 0xF0
000079a3731d2c88  pop r11
000079a3731d2c8a  pop r10
000079a3731d2c8c  pop r9
000079a3731d2c8e  pop r8
000079a3731d2c90  pop rsi
000079a3731d2c91  pop rdi
000079a3731d2c92  pop rdx
000079a3731d2c93  pop rcx
000079a3731d2c94  pop rax
000079a3731d2c95  add rsp, 0x08
000079a3731d2c99  jmp 0x000079A3731CFDEC
000079a3731d2c9e  sub rsp, 0x08
000079a3731d2ca2  push rax
000079a3731d2ca3  push rcx
000079a3731d2ca4  push rdx
000079a3731d2ca5  push rdi
000079a3731d2ca6  push rsi
000079a3731d2ca7  push r8
000079a3731d2ca9  push r9
000079a3731d2cab  push r10
000079a3731d2cad  push r11
000079a3731d2caf  sub rsp, 0xF0
000079a3731d2cb6  vmovaps [rsp], xmm0
000079a3731d2cbb  vmovaps [rsp+0x10], xmm1
000079a3731d2cc1  vmovaps [rsp+0x20], xmm2
000079a3731d2cc7  vmovaps [rsp+0x30], xmm3
000079a3731d2ccd  vmovaps [rsp+0x40], xmm4
000079a3731d2cd3  vmovaps [rsp+0x50], xmm5
000079a3731d2cd9  vmovaps [rsp+0x60], xmm6
000079a3731d2cdf  vmovaps [rsp+0x70], xmm7
000079a3731d2ce5  vmovaps [rsp+0x80], xmm8
000079a3731d2cee  vmovaps [rsp+0x90], xmm9
000079a3731d2cf7  vmovaps [rsp+0xA0], xmm10
000079a3731d2d00  vmovaps [rsp+0xB0], xmm11
000079a3731d2d09  vmovaps [rsp+0xC0], xmm12
000079a3731d2d12  vmovaps [rsp+0xD0], xmm14
000079a3731d2d1b  vmovaps [rsp+0xE0], xmm15
000079a3731d2d24  sub rsp, 0x30
000079a3731d2d28  movaps [rsp], xmm13
000079a3731d2d2d  movaps [rsp+0x10], xmm10
000079a3731d2d33  movaps [rsp+0x20], xmm1
000079a3731d2d38  lea rdi, [rsp]
000079a3731d2d3c  mov esi, 0x00
000079a3731d2d41  mov rax, 0x64F127B95530
000079a3731d2d4b  call rax
000079a3731d2d4d  movaps xmm13, [rsp]
000079a3731d2d52  add rsp, 0x30
000079a3731d2d56  vmovaps xmm0, [rsp]
000079a3731d2d5b  vmovaps xmm1, [rsp+0x10]
000079a3731d2d61  vmovaps xmm2, [rsp+0x20]
000079a3731d2d67  vmovaps xmm3, [rsp+0x30]
000079a3731d2d6d  vmovaps xmm4, [rsp+0x40]
000079a3731d2d73  vmovaps xmm5, [rsp+0x50]
000079a3731d2d79  vmovaps xmm6, [rsp+0x60]
000079a3731d2d7f  vmovaps xmm7, [rsp+0x70]
000079a3731d2d85  vmovaps xmm8, [rsp+0x80]
000079a3731d2d8e  vmovaps xmm9, [rsp+0x90]
000079a3731d2d97  vmovaps xmm10, [rsp+0xA0]
000079a3731d2da0  vmovaps xmm11, [rsp+0xB0]
000079a3731d2da9  vmovaps xmm12, [rsp+0xC0]
000079a3731d2db2  vmovaps xmm14, [rsp+0xD0]
000079a3731d2dbb  vmovaps xmm15, [rsp+0xE0]
000079a3731d2dc4  add rsp, 0xF0
000079a3731d2dcb  pop r11
000079a3731d2dcd  pop r10
000079a3731d2dcf  pop r9
000079a3731d2dd1  pop r8
000079a3731d2dd3  pop rsi
000079a3731d2dd4  pop rdi
000079a3731d2dd5  pop rdx
000079a3731d2dd6  pop rcx
000079a3731d2dd7  pop rax
000079a3731d2dd8  add rsp, 0x08
000079a3731d2ddc  jmp 0x000079A3731CFE15
000079a3731d2de1  sub rsp, 0x08
000079a3731d2de5  push rax
000079a3731d2de6  push rcx
000079a3731d2de7  push rdx
000079a3731d2de8  push rdi
000079a3731d2de9  push rsi
000079a3731d2dea  push r8
000079a3731d2dec  push r9
000079a3731d2dee  push r10
000079a3731d2df0  push r11
000079a3731d2df2  sub rsp, 0xF0
000079a3731d2df9  vmovaps [rsp], xmm0
000079a3731d2dfe  vmovaps [rsp+0x10], xmm2
000079a3731d2e04  vmovaps [rsp+0x20], xmm3
000079a3731d2e0a  vmovaps [rsp+0x30], xmm4
000079a3731d2e10  vmovaps [rsp+0x40], xmm5
000079a3731d2e16  vmovaps [rsp+0x50], xmm6
000079a3731d2e1c  vmovaps [rsp+0x60], xmm7
000079a3731d2e22  vmovaps [rsp+0x70], xmm8
000079a3731d2e28  vmovaps [rsp+0x80], xmm9
000079a3731d2e31  vmovaps [rsp+0x90], xmm10
000079a3731d2e3a  vmovaps [rsp+0xA0], xmm11
000079a3731d2e43  vmovaps [rsp+0xB0], xmm12
000079a3731d2e4c  vmovaps [rsp+0xC0], xmm13
000079a3731d2e55  vmovaps [rsp+0xD0], xmm14
000079a3731d2e5e  vmovaps [rsp+0xE0], xmm15
000079a3731d2e67  sub rsp, 0x30
000079a3731d2e6b  movaps [rsp], xmm1
000079a3731d2e6f  movaps [rsp+0x10], xmm15
000079a3731d2e75  movaps [rsp+0x20], xmm10
000079a3731d2e7b  lea rdi, [rsp]
000079a3731d2e7f  mov esi, 0x00
000079a3731d2e84  mov rax, 0x64F127B95530
000079a3731d2e8e  call rax
000079a3731d2e90  movaps xmm1, [rsp]
000079a3731d2e94  add rsp, 0x30
000079a3731d2e98  vmovaps xmm0, [rsp]
000079a3731d2e9d  vmovaps xmm2, [rsp+0x10]
000079a3731d2ea3  vmovaps xmm3, [rsp+0x20]
000079a3731d2ea9  vmovaps xmm4, [rsp+0x30]
000079a3731d2eaf  vmovaps xmm5, [rsp+0x40]
000079a3731d2eb5  vmovaps xmm6, [rsp+0x50]
000079a3731d2ebb  vmovaps xmm7, [rsp+0x60]
000079a3731d2ec1  vmovaps xmm8, [rsp+0x70]
000079a3731d2ec7  vmovaps xmm9, [rsp+0x80]
000079a3731d2ed0  vmovaps xmm10, [rsp+0x90]
000079a3731d2ed9  vmovaps xmm11, [rsp+0xA0]
000079a3731d2ee2  vmovaps xmm12, [rsp+0xB0]
000079a3731d2eeb  vmovaps xmm13, [rsp+0xC0]
000079a3731d2ef4  vmovaps xmm14, [rsp+0xD0]
000079a3731d2efd  vmovaps xmm15, [rsp+0xE0]
000079a3731d2f06  add rsp, 0xF0
000079a3731d2f0d  pop r11
000079a3731d2f0f  pop r10
000079a3731d2f11  pop r9
000079a3731d2f13  pop r8
000079a3731d2f15  pop rsi
000079a3731d2f16  pop rdi
000079a3731d2f17  pop rdx
000079a3731d2f18  pop rcx
000079a3731d2f19  pop rax
000079a3731d2f1a  add rsp, 0x08
000079a3731d2f1e  jmp 0x000079A3731CFE34
000079a3731d2f23  sub rsp, 0x08
000079a3731d2f27  push rax
000079a3731d2f28  push rcx
000079a3731d2f29  push rdx
000079a3731d2f2a  push rdi
000079a3731d2f2b  push rsi
000079a3731d2f2c  push r8
000079a3731d2f2e  push r9
000079a3731d2f30  push r10
000079a3731d2f32  push r11
000079a3731d2f34  sub rsp, 0xF0
000079a3731d2f3b  vmovaps [rsp], xmm0
000079a3731d2f40  vmovaps [rsp+0x10], xmm1
000079a3731d2f46  vmovaps [rsp+0x20], xmm2
000079a3731d2f4c  vmovaps [rsp+0x30], xmm3
000079a3731d2f52  vmovaps [rsp+0x40], xmm4
000079a3731d2f58  vmovaps [rsp+0x50], xmm5
000079a3731d2f5e  vmovaps [rsp+0x60], xmm6
000079a3731d2f64  vmovaps [rsp+0x70], xmm7
000079a3731d2f6a  vmovaps [rsp+0x80], xmm8
000079a3731d2f73  vmovaps [rsp+0x90], xmm9
000079a3731d2f7c  vmovaps [rsp+0xA0], xmm10
000079a3731d2f85  vmovaps [rsp+0xB0], xmm11
000079a3731d2f8e  vmovaps [rsp+0xC0], xmm12
000079a3731d2f97  vmovaps [rsp+0xD0], xmm13
000079a3731d2fa0  vmovaps [rsp+0xE0], xmm14
000079a3731d2fa9  sub rsp, 0x30
000079a3731d2fad  movaps [rsp], xmm15
000079a3731d2fb2  movaps [rsp+0x10], xmm10
000079a3731d2fb8  movaps [rsp+0x20], xmm11
000079a3731d2fbe  lea rdi, [rsp]
000079a3731d2fc2  mov esi, 0x00
000079a3731d2fc7  mov rax, 0x64F127B95530
000079a3731d2fd1  call rax
000079a3731d2fd3  movaps xmm15, [rsp]
000079a3731d2fd8  add rsp, 0x30
000079a3731d2fdc  vmovaps xmm0, [rsp]
000079a3731d2fe1  vmovaps xmm1, [rsp+0x10]
000079a3731d2fe7  vmovaps xmm2, [rsp+0x20]
000079a3731d2fed  vmovaps xmm3, [rsp+0x30]
000079a3731d2ff3  vmovaps xmm4, [rsp+0x40]
000079a3731d2ff9  vmovaps xmm5, [rsp+0x50]
000079a3731d2fff  vmovaps xmm6, [rsp+0x60]
000079a3731d3005  vmovaps xmm7, [rsp+0x70]
000079a3731d300b  vmovaps xmm8, [rsp+0x80]
000079a3731d3014  vmovaps xmm9, [rsp+0x90]
000079a3731d301d  vmovaps xmm10, [rsp+0xA0]
000079a3731d3026  vmovaps xmm11, [rsp+0xB0]
000079a3731d302f  vmovaps xmm12, [rsp+0xC0]
000079a3731d3038  vmovaps xmm13, [rsp+0xD0]
000079a3731d3041  vmovaps xmm14, [rsp+0xE0]
000079a3731d304a  add rsp, 0xF0
000079a3731d3051  pop r11
000079a3731d3053  pop r10
000079a3731d3055  pop r9
000079a3731d3057  pop r8
000079a3731d3059  pop rsi
000079a3731d305a  pop rdi
000079a3731d305b  pop rdx
000079a3731d305c  pop rcx
000079a3731d305d  pop rax
000079a3731d305e  add rsp, 0x08
000079a3731d3062  jmp 0x000079A3731CFE57
000079a3731d3067  sub rsp, 0x08
000079a3731d306b  push rax
000079a3731d306c  push rcx
000079a3731d306d  push rdx
000079a3731d306e  push rdi
000079a3731d306f  push rsi
000079a3731d3070  push r8
000079a3731d3072  push r9
000079a3731d3074  push r10
000079a3731d3076  push r11
000079a3731d3078  sub rsp, 0xF0
000079a3731d307f  vmovaps [rsp], xmm0
000079a3731d3084  vmovaps [rsp+0x10], xmm1
000079a3731d308a  vmovaps [rsp+0x20], xmm2
000079a3731d3090  vmovaps [rsp+0x30], xmm3
000079a3731d3096  vmovaps [rsp+0x40], xmm4
000079a3731d309c  vmovaps [rsp+0x50], xmm5
000079a3731d30a2  vmovaps [rsp+0x60], xmm6
000079a3731d30a8  vmovaps [rsp+0x70], xmm7
000079a3731d30ae  vmovaps [rsp+0x80], xmm8
000079a3731d30b7  vmovaps [rsp+0x90], xmm9
000079a3731d30c0  vmovaps [rsp+0xA0], xmm11
000079a3731d30c9  vmovaps [rsp+0xB0], xmm12
000079a3731d30d2  vmovaps [rsp+0xC0], xmm13
000079a3731d30db  vmovaps [rsp+0xD0], xmm14
000079a3731d30e4  vmovaps [rsp+0xE0], xmm15
000079a3731d30ed  sub rsp, 0x30
000079a3731d30f1  movaps [rsp], xmm10
000079a3731d30f6  movaps [rsp+0x10], xmm12
000079a3731d30fc  movaps [rsp+0x20], xmm11
000079a3731d3102  lea rdi, [rsp]
000079a3731d3106  mov esi, 0x00
000079a3731d310b  mov rax, 0x64F127B95530
000079a3731d3115  call rax
000079a3731d3117  movaps xmm10, [rsp]
000079a3731d311c  add rsp, 0x30
000079a3731d3120  vmovaps xmm0, [rsp]
000079a3731d3125  vmovaps xmm1, [rsp+0x10]
000079a3731d312b  vmovaps xmm2, [rsp+0x20]
000079a3731d3131  vmovaps xmm3, [rsp+0x30]
000079a3731d3137  vmovaps xmm4, [rsp+0x40]
000079a3731d313d  vmovaps xmm5, [rsp+0x50]
000079a3731d3143  vmovaps xmm6, [rsp+0x60]
000079a3731d3149  vmovaps xmm7, [rsp+0x70]
000079a3731d314f  vmovaps xmm8, [rsp+0x80]
000079a3731d3158  vmovaps xmm9, [rsp+0x90]
000079a3731d3161  vmovaps xmm11, [rsp+0xA0]
000079a3731d316a  vmovaps xmm12, [rsp+0xB0]
000079a3731d3173  vmovaps xmm13, [rsp+0xC0]
000079a3731d317c  vmovaps xmm14, [rsp+0xD0]
000079a3731d3185  vmovaps xmm15, [rsp+0xE0]
000079a3731d318e  add rsp, 0xF0
000079a3731d3195  pop r11
000079a3731d3197  pop r10
000079a3731d3199  pop r9
000079a3731d319b  pop r8
000079a3731d319d  pop rsi
000079a3731d319e  pop rdi
000079a3731d319f  pop rdx
000079a3731d31a0  pop rcx
000079a3731d31a1  pop rax
000079a3731d31a2  add rsp, 0x08
000079a3731d31a6  jmp 0x000079A3731CFE80
000079a3731d31ab  sub rsp, 0x08
000079a3731d31af  push rax
000079a3731d31b0  push rcx
000079a3731d31b1  push rdx
000079a3731d31b2  push rdi
000079a3731d31b3  push rsi
000079a3731d31b4  push r8
000079a3731d31b6  push r9
000079a3731d31b8  push r10
000079a3731d31ba  push r11
000079a3731d31bc  sub rsp, 0xF0
000079a3731d31c3  vmovaps [rsp], xmm0
000079a3731d31c8  vmovaps [rsp+0x10], xmm1
000079a3731d31ce  vmovaps [rsp+0x20], xmm2
000079a3731d31d4  vmovaps [rsp+0x30], xmm3
000079a3731d31da  vmovaps [rsp+0x40], xmm4
000079a3731d31e0  vmovaps [rsp+0x50], xmm5
000079a3731d31e6  vmovaps [rsp+0x60], xmm6
000079a3731d31ec  vmovaps [rsp+0x70], xmm7
000079a3731d31f2  vmovaps [rsp+0x80], xmm8
000079a3731d31fb  vmovaps [rsp+0x90], xmm9
000079a3731d3204  vmovaps [rsp+0xA0], xmm10
000079a3731d320d  vmovaps [rsp+0xB0], xmm12
000079a3731d3216  vmovaps [rsp+0xC0], xmm13
000079a3731d321f  vmovaps [rsp+0xD0], xmm14
000079a3731d3228  vmovaps [rsp+0xE0], xmm15
000079a3731d3231  sub rsp, 0x30
000079a3731d3235  movaps [rsp], xmm11
000079a3731d323a  movaps [rsp+0x10], xmm2
000079a3731d323f  movaps [rsp+0x20], xmm12
000079a3731d3245  lea rdi, [rsp]
000079a3731d3249  mov esi, 0x00
000079a3731d324e  mov rax, 0x64F127B95530
000079a3731d3258  call rax
000079a3731d325a  movaps xmm11, [rsp]
000079a3731d325f  add rsp, 0x30
000079a3731d3263  vmovaps xmm0, [rsp]
000079a3731d3268  vmovaps xmm1, [rsp+0x10]
000079a3731d326e  vmovaps xmm2, [rsp+0x20]
000079a3731d3274  vmovaps xmm3, [rsp+0x30]
000079a3731d327a  vmovaps xmm4, [rsp+0x40]
000079a3731d3280  vmovaps xmm5, [rsp+0x50]
000079a3731d3286  vmovaps xmm6, [rsp+0x60]
000079a3731d328c  vmovaps xmm7, [rsp+0x70]
000079a3731d3292  vmovaps xmm8, [rsp+0x80]
000079a3731d329b  vmovaps xmm9, [rsp+0x90]
000079a3731d32a4  vmovaps xmm10, [rsp+0xA0]
000079a3731d32ad  vmovaps xmm12, [rsp+0xB0]
000079a3731d32b6  vmovaps xmm13, [rsp+0xC0]
000079a3731d32bf  vmovaps xmm14, [rsp+0xD0]
000079a3731d32c8  vmovaps xmm15, [rsp+0xE0]
000079a3731d32d1  add rsp, 0xF0
000079a3731d32d8  pop r11
000079a3731d32da  pop r10
000079a3731d32dc  pop r9
000079a3731d32de  pop r8
000079a3731d32e0  pop rsi
000079a3731d32e1  pop rdi
000079a3731d32e2  pop rdx
000079a3731d32e3  pop rcx
000079a3731d32e4  pop rax
000079a3731d32e5  add rsp, 0x08
000079a3731d32e9  jmp 0x000079A3731CFEB8
000079a3731d32ee  sub rsp, 0x08
000079a3731d32f2  push rax
000079a3731d32f3  push rcx
000079a3731d32f4  push rdx
000079a3731d32f5  push rdi
000079a3731d32f6  push rsi
000079a3731d32f7  push r8
000079a3731d32f9  push r9
000079a3731d32fb  push r10
000079a3731d32fd  push r11
000079a3731d32ff  sub rsp, 0xF0
000079a3731d3306  vmovaps [rsp], xmm0
000079a3731d330b  vmovaps [rsp+0x10], xmm2
000079a3731d3311  vmovaps [rsp+0x20], xmm3
000079a3731d3317  vmovaps [rsp+0x30], xmm4
000079a3731d331d  vmovaps [rsp+0x40], xmm5
000079a3731d3323  vmovaps [rsp+0x50], xmm6
000079a3731d3329  vmovaps [rsp+0x60], xmm7
000079a3731d332f  vmovaps [rsp+0x70], xmm8
000079a3731d3335  vmovaps [rsp+0x80], xmm9
000079a3731d333e  vmovaps [rsp+0x90], xmm10
000079a3731d3347  vmovaps [rsp+0xA0], xmm11
000079a3731d3350  vmovaps [rsp+0xB0], xmm12
000079a3731d3359  vmovaps [rsp+0xC0], xmm13
000079a3731d3362  vmovaps [rsp+0xD0], xmm14
000079a3731d336b  vmovaps [rsp+0xE0], xmm15
000079a3731d3374  sub rsp, 0x30
000079a3731d3378  movaps [rsp], xmm1
000079a3731d337c  movaps [rsp+0x10], xmm14
000079a3731d3382  movaps [rsp+0x20], xmm6
000079a3731d3387  lea rdi, [rsp]
000079a3731d338b  mov esi, 0x00
000079a3731d3390  mov rax, 0x64F127B95530
000079a3731d339a  call rax
000079a3731d339c  movaps xmm1, [rsp]
000079a3731d33a0  add rsp, 0x30
000079a3731d33a4  vmovaps xmm0, [rsp]
000079a3731d33a9  vmovaps xmm2, [rsp+0x10]
000079a3731d33af  vmovaps xmm3, [rsp+0x20]
000079a3731d33b5  vmovaps xmm4, [rsp+0x30]
000079a3731d33bb  vmovaps xmm5, [rsp+0x40]
000079a3731d33c1  vmovaps xmm6, [rsp+0x50]
000079a3731d33c7  vmovaps xmm7, [rsp+0x60]
000079a3731d33cd  vmovaps xmm8, [rsp+0x70]
000079a3731d33d3  vmovaps xmm9, [rsp+0x80]
000079a3731d33dc  vmovaps xmm10, [rsp+0x90]
000079a3731d33e5  vmovaps xmm11, [rsp+0xA0]
000079a3731d33ee  vmovaps xmm12, [rsp+0xB0]
000079a3731d33f7  vmovaps xmm13, [rsp+0xC0]
000079a3731d3400  vmovaps xmm14, [rsp+0xD0]
000079a3731d3409  vmovaps xmm15, [rsp+0xE0]
000079a3731d3412  add rsp, 0xF0
000079a3731d3419  pop r11
000079a3731d341b  pop r10
000079a3731d341d  pop r9
000079a3731d341f  pop r8
000079a3731d3421  pop rsi
000079a3731d3422  pop rdi
000079a3731d3423  pop rdx
000079a3731d3424  pop rcx
000079a3731d3425  pop rax
000079a3731d3426  add rsp, 0x08
000079a3731d342a  jmp 0x000079A3731CFED1
000079a3731d342f  sub rsp, 0x08
000079a3731d3433  push rax
000079a3731d3434  push rcx
000079a3731d3435  push rdx
000079a3731d3436  push rdi
000079a3731d3437  push rsi
000079a3731d3438  push r8
000079a3731d343a  push r9
000079a3731d343c  push r10
000079a3731d343e  push r11
000079a3731d3440  sub rsp, 0xF0
000079a3731d3447  vmovaps [rsp], xmm0
000079a3731d344c  vmovaps [rsp+0x10], xmm1
000079a3731d3452  vmovaps [rsp+0x20], xmm2
000079a3731d3458  vmovaps [rsp+0x30], xmm3
000079a3731d345e  vmovaps [rsp+0x40], xmm4
000079a3731d3464  vmovaps [rsp+0x50], xmm5
000079a3731d346a  vmovaps [rsp+0x60], xmm6
000079a3731d3470  vmovaps [rsp+0x70], xmm7
000079a3731d3476  vmovaps [rsp+0x80], xmm8
000079a3731d347f  vmovaps [rsp+0x90], xmm9
000079a3731d3488  vmovaps [rsp+0xA0], xmm10
000079a3731d3491  vmovaps [rsp+0xB0], xmm11
000079a3731d349a  vmovaps [rsp+0xC0], xmm12
000079a3731d34a3  vmovaps [rsp+0xD0], xmm13
000079a3731d34ac  vmovaps [rsp+0xE0], xmm15
000079a3731d34b5  sub rsp, 0x30
000079a3731d34b9  movaps [rsp], xmm14
000079a3731d34be  movaps [rsp+0x10], xmm12
000079a3731d34c4  movaps [rsp+0x20], xmm5
000079a3731d34c9  lea rdi, [rsp]
000079a3731d34cd  mov esi, 0x00
000079a3731d34d2  mov rax, 0x64F127B95530
000079a3731d34dc  call rax
000079a3731d34de  movaps xmm14, [rsp]
000079a3731d34e3  add rsp, 0x30
000079a3731d34e7  vmovaps xmm0, [rsp]
000079a3731d34ec  vmovaps xmm1, [rsp+0x10]
000079a3731d34f2  vmovaps xmm2, [rsp+0x20]
000079a3731d34f8  vmovaps xmm3, [rsp+0x30]
000079a3731d34fe  vmovaps xmm4, [rsp+0x40]
000079a3731d3504  vmovaps xmm5, [rsp+0x50]
000079a3731d350a  vmovaps xmm6, [rsp+0x60]
000079a3731d3510  vmovaps xmm7, [rsp+0x70]
000079a3731d3516  vmovaps xmm8, [rsp+0x80]
000079a3731d351f  vmovaps xmm9, [rsp+0x90]
000079a3731d3528  vmovaps xmm10, [rsp+0xA0]
000079a3731d3531  vmovaps xmm11, [rsp+0xB0]
000079a3731d353a  vmovaps xmm12, [rsp+0xC0]
000079a3731d3543  vmovaps xmm13, [rsp+0xD0]
000079a3731d354c  vmovaps xmm15, [rsp+0xE0]
000079a3731d3555  add rsp, 0xF0
000079a3731d355c  pop r11
000079a3731d355e  pop r10
000079a3731d3560  pop r9
000079a3731d3562  pop r8
000079a3731d3564  pop rsi
000079a3731d3565  pop rdi
000079a3731d3566  pop rdx
000079a3731d3567  pop rcx
000079a3731d3568  pop rax
000079a3731d3569  add rsp, 0x08
000079a3731d356d  jmp 0x000079A3731CFEF1
000079a3731d3572  sub rsp, 0x08
000079a3731d3576  push rax
000079a3731d3577  push rcx
000079a3731d3578  push rdx
000079a3731d3579  push rdi
000079a3731d357a  push rsi
000079a3731d357b  push r8
000079a3731d357d  push r9
000079a3731d357f  push r10
000079a3731d3581  push r11
000079a3731d3583  sub rsp, 0xF0
000079a3731d358a  vmovaps [rsp], xmm0
000079a3731d358f  vmovaps [rsp+0x10], xmm1
000079a3731d3595  vmovaps [rsp+0x20], xmm2
000079a3731d359b  vmovaps [rsp+0x30], xmm3
000079a3731d35a1  vmovaps [rsp+0x40], xmm4
000079a3731d35a7  vmovaps [rsp+0x50], xmm5
000079a3731d35ad  vmovaps [rsp+0x60], xmm7
000079a3731d35b3  vmovaps [rsp+0x70], xmm8
000079a3731d35b9  vmovaps [rsp+0x80], xmm9
000079a3731d35c2  vmovaps [rsp+0x90], xmm10
000079a3731d35cb  vmovaps [rsp+0xA0], xmm11
000079a3731d35d4  vmovaps [rsp+0xB0], xmm12
000079a3731d35dd  vmovaps [rsp+0xC0], xmm13
000079a3731d35e6  vmovaps [rsp+0xD0], xmm14
000079a3731d35ef  vmovaps [rsp+0xE0], xmm15
000079a3731d35f8  sub rsp, 0x30
000079a3731d35fc  movaps [rsp], xmm6
000079a3731d3600  movaps [rsp+0x10], xmm9
000079a3731d3606  movaps [rsp+0x20], xmm12
000079a3731d360c  lea rdi, [rsp]
000079a3731d3610  mov esi, 0x00
000079a3731d3615  mov rax, 0x64F127B95530
000079a3731d361f  call rax
000079a3731d3621  movaps xmm6, [rsp]
000079a3731d3625  add rsp, 0x30
000079a3731d3629  vmovaps xmm0, [rsp]
000079a3731d362e  vmovaps xmm1, [rsp+0x10]
000079a3731d3634  vmovaps xmm2, [rsp+0x20]
000079a3731d363a  vmovaps xmm3, [rsp+0x30]
000079a3731d3640  vmovaps xmm4, [rsp+0x40]
000079a3731d3646  vmovaps xmm5, [rsp+0x50]
000079a3731d364c  vmovaps xmm7, [rsp+0x60]
000079a3731d3652  vmovaps xmm8, [rsp+0x70]
000079a3731d3658  vmovaps xmm9, [rsp+0x80]
000079a3731d3661  vmovaps xmm10, [rsp+0x90]
000079a3731d366a  vmovaps xmm11, [rsp+0xA0]
000079a3731d3673  vmovaps xmm12, [rsp+0xB0]
000079a3731d367c  vmovaps xmm13, [rsp+0xC0]
000079a3731d3685  vmovaps xmm14, [rsp+0xD0]
000079a3731d368e  vmovaps xmm15, [rsp+0xE0]
000079a3731d3697  add rsp, 0xF0
000079a3731d369e  pop r11
000079a3731d36a0  pop r10
000079a3731d36a2  pop r9
000079a3731d36a4  pop r8
000079a3731d36a6  pop rsi
000079a3731d36a7  pop rdi
000079a3731d36a8  pop rdx
000079a3731d36a9  pop rcx
000079a3731d36aa  pop rax
000079a3731d36ab  add rsp, 0x08
000079a3731d36af  jmp 0x000079A3731CFF19
000079a3731d36b4  sub rsp, 0x08
000079a3731d36b8  push rax
000079a3731d36b9  push rcx
000079a3731d36ba  push rdx
000079a3731d36bb  push rdi
000079a3731d36bc  push rsi
000079a3731d36bd  push r8
000079a3731d36bf  push r9
000079a3731d36c1  push r10
000079a3731d36c3  push r11
000079a3731d36c5  sub rsp, 0xF0
000079a3731d36cc  vmovaps [rsp], xmm0
000079a3731d36d1  vmovaps [rsp+0x10], xmm1
000079a3731d36d7  vmovaps [rsp+0x20], xmm2
000079a3731d36dd  vmovaps [rsp+0x30], xmm3
000079a3731d36e3  vmovaps [rsp+0x40], xmm4
000079a3731d36e9  vmovaps [rsp+0x50], xmm5
000079a3731d36ef  vmovaps [rsp+0x60], xmm6
000079a3731d36f5  vmovaps [rsp+0x70], xmm7
000079a3731d36fb  vmovaps [rsp+0x80], xmm8
000079a3731d3704  vmovaps [rsp+0x90], xmm9
000079a3731d370d  vmovaps [rsp+0xA0], xmm10
000079a3731d3716  vmovaps [rsp+0xB0], xmm11
000079a3731d371f  vmovaps [rsp+0xC0], xmm13
000079a3731d3728  vmovaps [rsp+0xD0], xmm14
000079a3731d3731  vmovaps [rsp+0xE0], xmm15
000079a3731d373a  sub rsp, 0x30
000079a3731d373e  movaps [rsp], xmm12
000079a3731d3743  movaps [rsp+0x10], xmm15
000079a3731d3749  movaps [rsp+0x20], xmm13
000079a3731d374f  lea rdi, [rsp]
000079a3731d3753  mov esi, 0x00
000079a3731d3758  mov rax, 0x64F127B95530
000079a3731d3762  call rax
000079a3731d3764  movaps xmm12, [rsp]
000079a3731d3769  add rsp, 0x30
000079a3731d376d  vmovaps xmm0, [rsp]
000079a3731d3772  vmovaps xmm1, [rsp+0x10]
000079a3731d3778  vmovaps xmm2, [rsp+0x20]
000079a3731d377e  vmovaps xmm3, [rsp+0x30]
000079a3731d3784  vmovaps xmm4, [rsp+0x40]
000079a3731d378a  vmovaps xmm5, [rsp+0x50]
000079a3731d3790  vmovaps xmm6, [rsp+0x60]
000079a3731d3796  vmovaps xmm7, [rsp+0x70]
000079a3731d379c  vmovaps xmm8, [rsp+0x80]
000079a3731d37a5  vmovaps xmm9, [rsp+0x90]
000079a3731d37ae  vmovaps xmm10, [rsp+0xA0]
000079a3731d37b7  vmovaps xmm11, [rsp+0xB0]
000079a3731d37c0  vmovaps xmm13, [rsp+0xC0]
000079a3731d37c9  vmovaps xmm14, [rsp+0xD0]
000079a3731d37d2  vmovaps xmm15, [rsp+0xE0]
000079a3731d37db  add rsp, 0xF0
000079a3731d37e2  pop r11
000079a3731d37e4  pop r10
000079a3731d37e6  pop r9
000079a3731d37e8  pop r8
000079a3731d37ea  pop rsi
000079a3731d37eb  pop rdi
000079a3731d37ec  pop rdx
000079a3731d37ed  pop rcx
000079a3731d37ee  pop rax
000079a3731d37ef  add rsp, 0x08
000079a3731d37f3  jmp 0x000079A3731CFF34
000079a3731d37f8  sub rsp, 0x08
000079a3731d37fc  push rax
000079a3731d37fd  push rcx
000079a3731d37fe  push rdx
000079a3731d37ff  push rdi
000079a3731d3800  push rsi
000079a3731d3801  push r8
000079a3731d3803  push r9
000079a3731d3805  push r10
000079a3731d3807  push r11
000079a3731d3809  sub rsp, 0xF0
000079a3731d3810  vmovaps [rsp], xmm0
000079a3731d3815  vmovaps [rsp+0x10], xmm1
000079a3731d381b  vmovaps [rsp+0x20], xmm2
000079a3731d3821  vmovaps [rsp+0x30], xmm3
000079a3731d3827  vmovaps [rsp+0x40], xmm4
000079a3731d382d  vmovaps [rsp+0x50], xmm5
000079a3731d3833  vmovaps [rsp+0x60], xmm6
000079a3731d3839  vmovaps [rsp+0x70], xmm7
000079a3731d383f  vmovaps [rsp+0x80], xmm8
000079a3731d3848  vmovaps [rsp+0x90], xmm9
000079a3731d3851  vmovaps [rsp+0xA0], xmm10
000079a3731d385a  vmovaps [rsp+0xB0], xmm11
000079a3731d3863  vmovaps [rsp+0xC0], xmm12
000079a3731d386c  vmovaps [rsp+0xD0], xmm13
000079a3731d3875  vmovaps [rsp+0xE0], xmm14
000079a3731d387e  sub rsp, 0x30
000079a3731d3882  movaps [rsp], xmm15
000079a3731d3887  movaps [rsp+0x10], xmm13
000079a3731d388d  movaps [rsp+0x20], xmm10
000079a3731d3893  lea rdi, [rsp]
000079a3731d3897  mov esi, 0x00
000079a3731d389c  mov rax, 0x64F127B95530
000079a3731d38a6  call rax
000079a3731d38a8  movaps xmm15, [rsp]
000079a3731d38ad  add rsp, 0x30
000079a3731d38b1  vmovaps xmm0, [rsp]
000079a3731d38b6  vmovaps xmm1, [rsp+0x10]
000079a3731d38bc  vmovaps xmm2, [rsp+0x20]
000079a3731d38c2  vmovaps xmm3, [rsp+0x30]
000079a3731d38c8  vmovaps xmm4, [rsp+0x40]
000079a3731d38ce  vmovaps xmm5, [rsp+0x50]
000079a3731d38d4  vmovaps xmm6, [rsp+0x60]
000079a3731d38da  vmovaps xmm7, [rsp+0x70]
000079a3731d38e0  vmovaps xmm8, [rsp+0x80]
000079a3731d38e9  vmovaps xmm9, [rsp+0x90]
000079a3731d38f2  vmovaps xmm10, [rsp+0xA0]
000079a3731d38fb  vmovaps xmm11, [rsp+0xB0]
000079a3731d3904  vmovaps xmm12, [rsp+0xC0]
000079a3731d390d  vmovaps xmm13, [rsp+0xD0]
000079a3731d3916  vmovaps xmm14, [rsp+0xE0]
000079a3731d391f  add rsp, 0xF0
000079a3731d3926  pop r11
000079a3731d3928  pop r10
000079a3731d392a  pop r9
000079a3731d392c  pop r8
000079a3731d392e  pop rsi
000079a3731d392f  pop rdi
000079a3731d3930  pop rdx
000079a3731d3931  pop rcx
000079a3731d3932  pop rax
000079a3731d3933  add rsp, 0x08
000079a3731d3937  jmp 0x000079A3731CFF55
000079a3731d393c  call 0x000079A37300C260
000079a3731d3941  jmp 0x000079A3731CFFB0
000079a3731d3946  sub rsp, 0x08
000079a3731d394a  push rax
000079a3731d394b  push rcx
000079a3731d394c  push rdx
000079a3731d394d  push rdi
000079a3731d394e  push rsi
000079a3731d394f  push r8
000079a3731d3951  push r9
000079a3731d3953  push r10
000079a3731d3955  push r11
000079a3731d3957  sub rsp, 0xF0
000079a3731d395e  vmovaps [rsp], xmm0
000079a3731d3963  vmovaps [rsp+0x10], xmm1
000079a3731d3969  vmovaps [rsp+0x20], xmm2
000079a3731d396f  vmovaps [rsp+0x30], xmm3
000079a3731d3975  vmovaps [rsp+0x40], xmm4
000079a3731d397b  vmovaps [rsp+0x50], xmm5
000079a3731d3981  vmovaps [rsp+0x60], xmm6
000079a3731d3987  vmovaps [rsp+0x70], xmm7
000079a3731d398d  vmovaps [rsp+0x80], xmm8
000079a3731d3996  vmovaps [rsp+0x90], xmm10
000079a3731d399f  vmovaps [rsp+0xA0], xmm11
000079a3731d39a8  vmovaps [rsp+0xB0], xmm12
000079a3731d39b1  vmovaps [rsp+0xC0], xmm13
000079a3731d39ba  vmovaps [rsp+0xD0], xmm14
000079a3731d39c3  vmovaps [rsp+0xE0], xmm15
000079a3731d39cc  sub rsp, 0x30
000079a3731d39d0  movaps [rsp], xmm9
000079a3731d39d5  movaps [rsp+0x10], xmm8
000079a3731d39db  movaps [rsp+0x20], xmm10
000079a3731d39e1  lea rdi, [rsp]
000079a3731d39e5  mov esi, 0x00
000079a3731d39ea  mov rax, 0x64F127B95530
000079a3731d39f4  call rax
000079a3731d39f6  movaps xmm9, [rsp]
000079a3731d39fb  add rsp, 0x30
000079a3731d39ff  vmovaps xmm0, [rsp]
000079a3731d3a04  vmovaps xmm1, [rsp+0x10]
000079a3731d3a0a  vmovaps xmm2, [rsp+0x20]
000079a3731d3a10  vmovaps xmm3, [rsp+0x30]
000079a3731d3a16  vmovaps xmm4, [rsp+0x40]
000079a3731d3a1c  vmovaps xmm5, [rsp+0x50]
000079a3731d3a22  vmovaps xmm6, [rsp+0x60]
000079a3731d3a28  vmovaps xmm7, [rsp+0x70]
000079a3731d3a2e  vmovaps xmm8, [rsp+0x80]
000079a3731d3a37  vmovaps xmm10, [rsp+0x90]
000079a3731d3a40  vmovaps xmm11, [rsp+0xA0]
000079a3731d3a49  vmovaps xmm12, [rsp+0xB0]
000079a3731d3a52  vmovaps xmm13, [rsp+0xC0]
000079a3731d3a5b  vmovaps xmm14, [rsp+0xD0]
000079a3731d3a64  vmovaps xmm15, [rsp+0xE0]
000079a3731d3a6d  add rsp, 0xF0
000079a3731d3a74  pop r11
000079a3731d3a76  pop r10
000079a3731d3a78  pop r9
000079a3731d3a7a  pop r8
000079a3731d3a7c  pop rsi
000079a3731d3a7d  pop rdi
000079a3731d3a7e  pop rdx
000079a3731d3a7f  pop rcx
000079a3731d3a80  pop rax
000079a3731d3a81  add rsp, 0x08
000079a3731d3a85  jmp 0x000079A3731CFFE1
000079a3731d3a8a  sub rsp, 0x08
000079a3731d3a8e  push rax
000079a3731d3a8f  push rcx
000079a3731d3a90  push rdx
000079a3731d3a91  push rdi
000079a3731d3a92  push rsi
000079a3731d3a93  push r8
000079a3731d3a95  push r9
000079a3731d3a97  push r10
000079a3731d3a99  push r11
000079a3731d3a9b  sub rsp, 0xF0
000079a3731d3aa2  vmovaps [rsp], xmm0
000079a3731d3aa7  vmovaps [rsp+0x10], xmm1
000079a3731d3aad  vmovaps [rsp+0x20], xmm2
000079a3731d3ab3  vmovaps [rsp+0x30], xmm3
000079a3731d3ab9  vmovaps [rsp+0x40], xmm4
000079a3731d3abf  vmovaps [rsp+0x50], xmm5
000079a3731d3ac5  vmovaps [rsp+0x60], xmm6
000079a3731d3acb  vmovaps [rsp+0x70], xmm7
000079a3731d3ad1  vmovaps [rsp+0x80], xmm8
000079a3731d3ada  vmovaps [rsp+0x90], xmm9
000079a3731d3ae3  vmovaps [rsp+0xA0], xmm11
000079a3731d3aec  vmovaps [rsp+0xB0], xmm12
000079a3731d3af5  vmovaps [rsp+0xC0], xmm13
000079a3731d3afe  vmovaps [rsp+0xD0], xmm14
000079a3731d3b07  vmovaps [rsp+0xE0], xmm15
000079a3731d3b10  sub rsp, 0x30
000079a3731d3b14  movaps [rsp], xmm10
000079a3731d3b19  movaps [rsp+0x10], xmm1
000079a3731d3b1e  movaps [rsp+0x20], xmm11
000079a3731d3b24  lea rdi, [rsp]
000079a3731d3b28  mov esi, 0x00
000079a3731d3b2d  mov rax, 0x64F127B95530
000079a3731d3b37  call rax
000079a3731d3b39  movaps xmm10, [rsp]
000079a3731d3b3e  add rsp, 0x30
000079a3731d3b42  vmovaps xmm0, [rsp]
000079a3731d3b47  vmovaps xmm1, [rsp+0x10]
000079a3731d3b4d  vmovaps xmm2, [rsp+0x20]
000079a3731d3b53  vmovaps xmm3, [rsp+0x30]
000079a3731d3b59  vmovaps xmm4, [rsp+0x40]
000079a3731d3b5f  vmovaps xmm5, [rsp+0x50]
000079a3731d3b65  vmovaps xmm6, [rsp+0x60]
000079a3731d3b6b  vmovaps xmm7, [rsp+0x70]
000079a3731d3b71  vmovaps xmm8, [rsp+0x80]
000079a3731d3b7a  vmovaps xmm9, [rsp+0x90]
000079a3731d3b83  vmovaps xmm11, [rsp+0xA0]
000079a3731d3b8c  vmovaps xmm12, [rsp+0xB0]
000079a3731d3b95  vmovaps xmm13, [rsp+0xC0]
000079a3731d3b9e  vmovaps xmm14, [rsp+0xD0]
000079a3731d3ba7  vmovaps xmm15, [rsp+0xE0]
000079a3731d3bb0  add rsp, 0xF0
000079a3731d3bb7  pop r11
000079a3731d3bb9  pop r10
000079a3731d3bbb  pop r9
000079a3731d3bbd  pop r8
000079a3731d3bbf  pop rsi
000079a3731d3bc0  pop rdi
000079a3731d3bc1  pop rdx
000079a3731d3bc2  pop rcx
000079a3731d3bc3  pop rax
000079a3731d3bc4  add rsp, 0x08
000079a3731d3bc8  jmp 0x000079A3731CFFFC
000079a3731d3bcd  sub rsp, 0x08
000079a3731d3bd1  push rax
000079a3731d3bd2  push rcx
000079a3731d3bd3  push rdx
000079a3731d3bd4  push rdi
000079a3731d3bd5  push rsi
000079a3731d3bd6  push r8
000079a3731d3bd8  push r9
000079a3731d3bda  push r10
000079a3731d3bdc  push r11
000079a3731d3bde  sub rsp, 0xF0
000079a3731d3be5  vmovaps [rsp], xmm0
000079a3731d3bea  vmovaps [rsp+0x10], xmm2
000079a3731d3bf0  vmovaps [rsp+0x20], xmm3
000079a3731d3bf6  vmovaps [rsp+0x30], xmm4
000079a3731d3bfc  vmovaps [rsp+0x40], xmm5
000079a3731d3c02  vmovaps [rsp+0x50], xmm6
000079a3731d3c08  vmovaps [rsp+0x60], xmm7
000079a3731d3c0e  vmovaps [rsp+0x70], xmm8
000079a3731d3c14  vmovaps [rsp+0x80], xmm9
000079a3731d3c1d  vmovaps [rsp+0x90], xmm10
000079a3731d3c26  vmovaps [rsp+0xA0], xmm11
000079a3731d3c2f  vmovaps [rsp+0xB0], xmm12
000079a3731d3c38  vmovaps [rsp+0xC0], xmm13
000079a3731d3c41  vmovaps [rsp+0xD0], xmm14
000079a3731d3c4a  vmovaps [rsp+0xE0], xmm15
000079a3731d3c53  sub rsp, 0x30
000079a3731d3c57  movaps [rsp], xmm1
000079a3731d3c5b  movaps [rsp+0x10], xmm14
000079a3731d3c61  movaps [rsp+0x20], xmm6
000079a3731d3c66  lea rdi, [rsp]
000079a3731d3c6a  mov esi, 0x00
000079a3731d3c6f  mov rax, 0x64F127B95530
000079a3731d3c79  call rax
000079a3731d3c7b  movaps xmm1, [rsp]
000079a3731d3c7f  add rsp, 0x30
000079a3731d3c83  vmovaps xmm0, [rsp]
000079a3731d3c88  vmovaps xmm2, [rsp+0x10]
000079a3731d3c8e  vmovaps xmm3, [rsp+0x20]
000079a3731d3c94  vmovaps xmm4, [rsp+0x30]
000079a3731d3c9a  vmovaps xmm5, [rsp+0x40]
000079a3731d3ca0  vmovaps xmm6, [rsp+0x50]
000079a3731d3ca6  vmovaps xmm7, [rsp+0x60]
000079a3731d3cac  vmovaps xmm8, [rsp+0x70]
000079a3731d3cb2  vmovaps xmm9, [rsp+0x80]
000079a3731d3cbb  vmovaps xmm10, [rsp+0x90]
000079a3731d3cc4  vmovaps xmm11, [rsp+0xA0]
000079a3731d3ccd  vmovaps xmm12, [rsp+0xB0]
000079a3731d3cd6  vmovaps xmm13, [rsp+0xC0]
000079a3731d3cdf  vmovaps xmm14, [rsp+0xD0]
000079a3731d3ce8  vmovaps xmm15, [rsp+0xE0]
000079a3731d3cf1  add rsp, 0xF0
000079a3731d3cf8  pop r11
000079a3731d3cfa  pop r10
000079a3731d3cfc  pop r9
000079a3731d3cfe  pop r8
000079a3731d3d00  pop rsi
000079a3731d3d01  pop rdi
000079a3731d3d02  pop rdx
000079a3731d3d03  pop rcx
000079a3731d3d04  pop rax
000079a3731d3d05  add rsp, 0x08
000079a3731d3d09  jmp 0x000079A3731D0015
000079a3731d3d0e  sub rsp, 0x08
000079a3731d3d12  push rax
000079a3731d3d13  push rcx
000079a3731d3d14  push rdx
000079a3731d3d15  push rdi
000079a3731d3d16  push rsi
000079a3731d3d17  push r8
000079a3731d3d19  push r9
000079a3731d3d1b  push r10
000079a3731d3d1d  push r11
000079a3731d3d1f  sub rsp, 0xF0
000079a3731d3d26  vmovaps [rsp], xmm0
000079a3731d3d2b  vmovaps [rsp+0x10], xmm1
000079a3731d3d31  vmovaps [rsp+0x20], xmm2
000079a3731d3d37  vmovaps [rsp+0x30], xmm3
000079a3731d3d3d  vmovaps [rsp+0x40], xmm4
000079a3731d3d43  vmovaps [rsp+0x50], xmm5
000079a3731d3d49  vmovaps [rsp+0x60], xmm6
000079a3731d3d4f  vmovaps [rsp+0x70], xmm7
000079a3731d3d55  vmovaps [rsp+0x80], xmm8
000079a3731d3d5e  vmovaps [rsp+0x90], xmm9
000079a3731d3d67  vmovaps [rsp+0xA0], xmm10
000079a3731d3d70  vmovaps [rsp+0xB0], xmm12
000079a3731d3d79  vmovaps [rsp+0xC0], xmm13
000079a3731d3d82  vmovaps [rsp+0xD0], xmm14
000079a3731d3d8b  vmovaps [rsp+0xE0], xmm15
000079a3731d3d94  sub rsp, 0x30
000079a3731d3d98  movaps [rsp], xmm11
000079a3731d3d9d  movaps [rsp+0x10], xmm13
000079a3731d3da3  movaps [rsp+0x20], xmm14
000079a3731d3da9  lea rdi, [rsp]
000079a3731d3dad  mov esi, 0x00
000079a3731d3db2  mov rax, 0x64F127B95530
000079a3731d3dbc  call rax
000079a3731d3dbe  movaps xmm11, [rsp]
000079a3731d3dc3  add rsp, 0x30
000079a3731d3dc7  vmovaps xmm0, [rsp]
000079a3731d3dcc  vmovaps xmm1, [rsp+0x10]
000079a3731d3dd2  vmovaps xmm2, [rsp+0x20]
000079a3731d3dd8  vmovaps xmm3, [rsp+0x30]
000079a3731d3dde  vmovaps xmm4, [rsp+0x40]
000079a3731d3de4  vmovaps xmm5, [rsp+0x50]
000079a3731d3dea  vmovaps xmm6, [rsp+0x60]
000079a3731d3df0  vmovaps xmm7, [rsp+0x70]
000079a3731d3df6  vmovaps xmm8, [rsp+0x80]
000079a3731d3dff  vmovaps xmm9, [rsp+0x90]
000079a3731d3e08  vmovaps xmm10, [rsp+0xA0]
000079a3731d3e11  vmovaps xmm12, [rsp+0xB0]
000079a3731d3e1a  vmovaps xmm13, [rsp+0xC0]
000079a3731d3e23  vmovaps xmm14, [rsp+0xD0]
000079a3731d3e2c  vmovaps xmm15, [rsp+0xE0]
000079a3731d3e35  add rsp, 0xF0
000079a3731d3e3c  pop r11
000079a3731d3e3e  pop r10
000079a3731d3e40  pop r9
000079a3731d3e42  pop r8
000079a3731d3e44  pop rsi
000079a3731d3e45  pop rdi
000079a3731d3e46  pop rdx
000079a3731d3e47  pop rcx
000079a3731d3e48  pop rax
000079a3731d3e49  add rsp, 0x08
000079a3731d3e4d  jmp 0x000079A3731D003F
000079a3731d3e52  sub rsp, 0x08
000079a3731d3e56  push rax
000079a3731d3e57  push rcx
000079a3731d3e58  push rdx
000079a3731d3e59  push rdi
000079a3731d3e5a  push rsi
000079a3731d3e5b  push r8
000079a3731d3e5d  push r9
000079a3731d3e5f  push r10
000079a3731d3e61  push r11
000079a3731d3e63  sub rsp, 0xF0
000079a3731d3e6a  vmovaps [rsp], xmm0
000079a3731d3e6f  vmovaps [rsp+0x10], xmm1
000079a3731d3e75  vmovaps [rsp+0x20], xmm2
000079a3731d3e7b  vmovaps [rsp+0x30], xmm3
000079a3731d3e81  vmovaps [rsp+0x40], xmm4
000079a3731d3e87  vmovaps [rsp+0x50], xmm5
000079a3731d3e8d  vmovaps [rsp+0x60], xmm6
000079a3731d3e93  vmovaps [rsp+0x70], xmm7
000079a3731d3e99  vmovaps [rsp+0x80], xmm8
000079a3731d3ea2  vmovaps [rsp+0x90], xmm9
000079a3731d3eab  vmovaps [rsp+0xA0], xmm10
000079a3731d3eb4  vmovaps [rsp+0xB0], xmm11
000079a3731d3ebd  vmovaps [rsp+0xC0], xmm12
000079a3731d3ec6  vmovaps [rsp+0xD0], xmm14
000079a3731d3ecf  vmovaps [rsp+0xE0], xmm15
000079a3731d3ed8  sub rsp, 0x30
000079a3731d3edc  movaps [rsp], xmm13
000079a3731d3ee1  movaps [rsp+0x10], xmm8
000079a3731d3ee7  movaps [rsp+0x20], xmm14
000079a3731d3eed  lea rdi, [rsp]
000079a3731d3ef1  mov esi, 0x00
000079a3731d3ef6  mov rax, 0x64F127B95530
000079a3731d3f00  call rax
000079a3731d3f02  movaps xmm13, [rsp]
000079a3731d3f07  add rsp, 0x30
000079a3731d3f0b  vmovaps xmm0, [rsp]
000079a3731d3f10  vmovaps xmm1, [rsp+0x10]
000079a3731d3f16  vmovaps xmm2, [rsp+0x20]
000079a3731d3f1c  vmovaps xmm3, [rsp+0x30]
000079a3731d3f22  vmovaps xmm4, [rsp+0x40]
000079a3731d3f28  vmovaps xmm5, [rsp+0x50]
000079a3731d3f2e  vmovaps xmm6, [rsp+0x60]
000079a3731d3f34  vmovaps xmm7, [rsp+0x70]
000079a3731d3f3a  vmovaps xmm8, [rsp+0x80]
000079a3731d3f43  vmovaps xmm9, [rsp+0x90]
000079a3731d3f4c  vmovaps xmm10, [rsp+0xA0]
000079a3731d3f55  vmovaps xmm11, [rsp+0xB0]
000079a3731d3f5e  vmovaps xmm12, [rsp+0xC0]
000079a3731d3f67  vmovaps xmm14, [rsp+0xD0]
000079a3731d3f70  vmovaps xmm15, [rsp+0xE0]
000079a3731d3f79  add rsp, 0xF0
000079a3731d3f80  pop r11
000079a3731d3f82  pop r10
000079a3731d3f84  pop r9
000079a3731d3f86  pop r8
000079a3731d3f88  pop rsi
000079a3731d3f89  pop rdi
000079a3731d3f8a  pop rdx
000079a3731d3f8b  pop rcx
000079a3731d3f8c  pop rax
000079a3731d3f8d  add rsp, 0x08
000079a3731d3f91  jmp 0x000079A3731D006E
000079a3731d3f96  sub rsp, 0x08
000079a3731d3f9a  push rax
000079a3731d3f9b  push rcx
000079a3731d3f9c  push rdx
000079a3731d3f9d  push rdi
000079a3731d3f9e  push rsi
000079a3731d3f9f  push r8
000079a3731d3fa1  push r9
000079a3731d3fa3  push r10
000079a3731d3fa5  push r11
000079a3731d3fa7  sub rsp, 0xF0
000079a3731d3fae  vmovaps [rsp], xmm0
000079a3731d3fb3  vmovaps [rsp+0x10], xmm1
000079a3731d3fb9  vmovaps [rsp+0x20], xmm2
000079a3731d3fbf  vmovaps [rsp+0x30], xmm3
000079a3731d3fc5  vmovaps [rsp+0x40], xmm4
000079a3731d3fcb  vmovaps [rsp+0x50], xmm5
000079a3731d3fd1  vmovaps [rsp+0x60], xmm6
000079a3731d3fd7  vmovaps [rsp+0x70], xmm7
000079a3731d3fdd  vmovaps [rsp+0x80], xmm9
000079a3731d3fe6  vmovaps [rsp+0x90], xmm10
000079a3731d3fef  vmovaps [rsp+0xA0], xmm11
000079a3731d3ff8  vmovaps [rsp+0xB0], xmm12
000079a3731d4001  vmovaps [rsp+0xC0], xmm13
000079a3731d400a  vmovaps [rsp+0xD0], xmm14
000079a3731d4013  vmovaps [rsp+0xE0], xmm15
000079a3731d401c  sub rsp, 0x30
000079a3731d4020  movaps [rsp], xmm8
000079a3731d4025  movaps [rsp+0x10], xmm7
000079a3731d402a  movaps [rsp+0x20], xmm14
000079a3731d4030  lea rdi, [rsp]
000079a3731d4034  mov esi, 0x00
000079a3731d4039  mov rax, 0x64F127B95530
000079a3731d4043  call rax
000079a3731d4045  movaps xmm8, [rsp]
000079a3731d404a  add rsp, 0x30
000079a3731d404e  vmovaps xmm0, [rsp]
000079a3731d4053  vmovaps xmm1, [rsp+0x10]
000079a3731d4059  vmovaps xmm2, [rsp+0x20]
000079a3731d405f  vmovaps xmm3, [rsp+0x30]
000079a3731d4065  vmovaps xmm4, [rsp+0x40]
000079a3731d406b  vmovaps xmm5, [rsp+0x50]
000079a3731d4071  vmovaps xmm6, [rsp+0x60]
000079a3731d4077  vmovaps xmm7, [rsp+0x70]
000079a3731d407d  vmovaps xmm9, [rsp+0x80]
000079a3731d4086  vmovaps xmm10, [rsp+0x90]
000079a3731d408f  vmovaps xmm11, [rsp+0xA0]
000079a3731d4098  vmovaps xmm12, [rsp+0xB0]
000079a3731d40a1  vmovaps xmm13, [rsp+0xC0]
000079a3731d40aa  vmovaps xmm14, [rsp+0xD0]
000079a3731d40b3  vmovaps xmm15, [rsp+0xE0]
000079a3731d40bc  add rsp, 0xF0
000079a3731d40c3  pop r11
000079a3731d40c5  pop r10
000079a3731d40c7  pop r9
000079a3731d40c9  pop r8
000079a3731d40cb  pop rsi
000079a3731d40cc  pop rdi
000079a3731d40cd  pop rdx
000079a3731d40ce  pop rcx
000079a3731d40cf  pop rax
000079a3731d40d0  add rsp, 0x08
000079a3731d40d4  jmp 0x000079A3731D0094
000079a3731d40d9  sub rsp, 0x08
000079a3731d40dd  push rax
000079a3731d40de  push rcx
000079a3731d40df  push rdx
000079a3731d40e0  push rdi
000079a3731d40e1  push rsi
000079a3731d40e2  push r8
000079a3731d40e4  push r9
000079a3731d40e6  push r10
000079a3731d40e8  push r11
000079a3731d40ea  sub rsp, 0xF0
000079a3731d40f1  vmovaps [rsp], xmm0
000079a3731d40f6  vmovaps [rsp+0x10], xmm1
000079a3731d40fc  vmovaps [rsp+0x20], xmm2
000079a3731d4102  vmovaps [rsp+0x30], xmm3
000079a3731d4108  vmovaps [rsp+0x40], xmm4
000079a3731d410e  vmovaps [rsp+0x50], xmm5
000079a3731d4114  vmovaps [rsp+0x60], xmm6
000079a3731d411a  vmovaps [rsp+0x70], xmm7
000079a3731d4120  vmovaps [rsp+0x80], xmm8
000079a3731d4129  vmovaps [rsp+0x90], xmm9
000079a3731d4132  vmovaps [rsp+0xA0], xmm10
000079a3731d413b  vmovaps [rsp+0xB0], xmm11
000079a3731d4144  vmovaps [rsp+0xC0], xmm12
000079a3731d414d  vmovaps [rsp+0xD0], xmm13
000079a3731d4156  vmovaps [rsp+0xE0], xmm15
000079a3731d415f  sub rsp, 0x30
000079a3731d4163  movaps [rsp], xmm14
000079a3731d4168  movaps [rsp+0x10], xmm12
000079a3731d416e  movaps [rsp+0x20], xmm9
000079a3731d4174  lea rdi, [rsp]
000079a3731d4178  mov esi, 0x00
000079a3731d417d  mov rax, 0x64F127B95530
000079a3731d4187  call rax
000079a3731d4189  movaps xmm14, [rsp]
000079a3731d418e  add rsp, 0x30
000079a3731d4192  vmovaps xmm0, [rsp]
000079a3731d4197  vmovaps xmm1, [rsp+0x10]
000079a3731d419d  vmovaps xmm2, [rsp+0x20]
000079a3731d41a3  vmovaps xmm3, [rsp+0x30]
000079a3731d41a9  vmovaps xmm4, [rsp+0x40]
000079a3731d41af  vmovaps xmm5, [rsp+0x50]
000079a3731d41b5  vmovaps xmm6, [rsp+0x60]
000079a3731d41bb  vmovaps xmm7, [rsp+0x70]
000079a3731d41c1  vmovaps xmm8, [rsp+0x80]
000079a3731d41ca  vmovaps xmm9, [rsp+0x90]
000079a3731d41d3  vmovaps xmm10, [rsp+0xA0]
000079a3731d41dc  vmovaps xmm11, [rsp+0xB0]
000079a3731d41e5  vmovaps xmm12, [rsp+0xC0]
000079a3731d41ee  vmovaps xmm13, [rsp+0xD0]
000079a3731d41f7  vmovaps xmm15, [rsp+0xE0]
000079a3731d4200  add rsp, 0xF0
000079a3731d4207  pop r11
000079a3731d4209  pop r10
000079a3731d420b  pop r9
000079a3731d420d  pop r8
000079a3731d420f  pop rsi
000079a3731d4210  pop rdi
000079a3731d4211  pop rdx
000079a3731d4212  pop rcx
000079a3731d4213  pop rax
000079a3731d4214  add rsp, 0x08
000079a3731d4218  jmp 0x000079A3731D00AE
000079a3731d421d  sub rsp, 0x08
000079a3731d4221  push rax
000079a3731d4222  push rcx
000079a3731d4223  push rdx
000079a3731d4224  push rdi
000079a3731d4225  push rsi
000079a3731d4226  push r8
000079a3731d4228  push r9
000079a3731d422a  push r10
000079a3731d422c  push r11
000079a3731d422e  sub rsp, 0xF0
000079a3731d4235  vmovaps [rsp], xmm0
000079a3731d423a  vmovaps [rsp+0x10], xmm1
000079a3731d4240  vmovaps [rsp+0x20], xmm2
000079a3731d4246  vmovaps [rsp+0x30], xmm3
000079a3731d424c  vmovaps [rsp+0x40], xmm4
000079a3731d4252  vmovaps [rsp+0x50], xmm5
000079a3731d4258  vmovaps [rsp+0x60], xmm6
000079a3731d425e  vmovaps [rsp+0x70], xmm7
000079a3731d4264  vmovaps [rsp+0x80], xmm8
000079a3731d426d  vmovaps [rsp+0x90], xmm10
000079a3731d4276  vmovaps [rsp+0xA0], xmm11
000079a3731d427f  vmovaps [rsp+0xB0], xmm12
000079a3731d4288  vmovaps [rsp+0xC0], xmm13
000079a3731d4291  vmovaps [rsp+0xD0], xmm14
000079a3731d429a  vmovaps [rsp+0xE0], xmm15
000079a3731d42a3  sub rsp, 0x30
000079a3731d42a7  movaps [rsp], xmm9
000079a3731d42ac  movaps [rsp+0x10], xmm7
000079a3731d42b1  movaps [rsp+0x20], xmm12
000079a3731d42b7  lea rdi, [rsp]
000079a3731d42bb  mov esi, 0x00
000079a3731d42c0  mov rax, 0x64F127B95530
000079a3731d42ca  call rax
000079a3731d42cc  movaps xmm9, [rsp]
000079a3731d42d1  add rsp, 0x30
000079a3731d42d5  vmovaps xmm0, [rsp]
000079a3731d42da  vmovaps xmm1, [rsp+0x10]
000079a3731d42e0  vmovaps xmm2, [rsp+0x20]
000079a3731d42e6  vmovaps xmm3, [rsp+0x30]
000079a3731d42ec  vmovaps xmm4, [rsp+0x40]
000079a3731d42f2  vmovaps xmm5, [rsp+0x50]
000079a3731d42f8  vmovaps xmm6, [rsp+0x60]
000079a3731d42fe  vmovaps xmm7, [rsp+0x70]
000079a3731d4304  vmovaps xmm8, [rsp+0x80]
000079a3731d430d  vmovaps xmm10, [rsp+0x90]
000079a3731d4316  vmovaps xmm11, [rsp+0xA0]
000079a3731d431f  vmovaps xmm12, [rsp+0xB0]
000079a3731d4328  vmovaps xmm13, [rsp+0xC0]
000079a3731d4331  vmovaps xmm14, [rsp+0xD0]
000079a3731d433a  vmovaps xmm15, [rsp+0xE0]
000079a3731d4343  add rsp, 0xF0
000079a3731d434a  pop r11
000079a3731d434c  pop r10
000079a3731d434e  pop r9
000079a3731d4350  pop r8
000079a3731d4352  pop rsi
000079a3731d4353  pop rdi
000079a3731d4354  pop rdx
000079a3731d4355  pop rcx
000079a3731d4356  pop rax
000079a3731d4357  add rsp, 0x08
000079a3731d435b  jmp 0x000079A3731D00DD
000079a3731d4360  sub rsp, 0x08
000079a3731d4364  push rax
000079a3731d4365  push rcx
000079a3731d4366  push rdx
000079a3731d4367  push rdi
000079a3731d4368  push rsi
000079a3731d4369  push r8
000079a3731d436b  push r9
000079a3731d436d  push r10
000079a3731d436f  push r11
000079a3731d4371  sub rsp, 0xF0
000079a3731d4378  vmovaps [rsp], xmm0
000079a3731d437d  vmovaps [rsp+0x10], xmm1
000079a3731d4383  vmovaps [rsp+0x20], xmm2
000079a3731d4389  vmovaps [rsp+0x30], xmm3
000079a3731d438f  vmovaps [rsp+0x40], xmm4
000079a3731d4395  vmovaps [rsp+0x50], xmm5
000079a3731d439b  vmovaps [rsp+0x60], xmm6
000079a3731d43a1  vmovaps [rsp+0x70], xmm7
000079a3731d43a7  vmovaps [rsp+0x80], xmm8
000079a3731d43b0  vmovaps [rsp+0x90], xmm9
000079a3731d43b9  vmovaps [rsp+0xA0], xmm10
000079a3731d43c2  vmovaps [rsp+0xB0], xmm11
000079a3731d43cb  vmovaps [rsp+0xC0], xmm13
000079a3731d43d4  vmovaps [rsp+0xD0], xmm14
000079a3731d43dd  vmovaps [rsp+0xE0], xmm15
000079a3731d43e6  sub rsp, 0x30
000079a3731d43ea  movaps [rsp], xmm12
000079a3731d43ef  movaps [rsp+0x10], xmm15
000079a3731d43f5  movaps [rsp+0x20], xmm11
000079a3731d43fb  lea rdi, [rsp]
000079a3731d43ff  mov esi, 0x00
000079a3731d4404  mov rax, 0x64F127B95530
000079a3731d440e  call rax
000079a3731d4410  movaps xmm12, [rsp]
000079a3731d4415  add rsp, 0x30
000079a3731d4419  vmovaps xmm0, [rsp]
000079a3731d441e  vmovaps xmm1, [rsp+0x10]
000079a3731d4424  vmovaps xmm2, [rsp+0x20]
000079a3731d442a  vmovaps xmm3, [rsp+0x30]
000079a3731d4430  vmovaps xmm4, [rsp+0x40]
000079a3731d4436  vmovaps xmm5, [rsp+0x50]
000079a3731d443c  vmovaps xmm6, [rsp+0x60]
000079a3731d4442  vmovaps xmm7, [rsp+0x70]
000079a3731d4448  vmovaps xmm8, [rsp+0x80]
000079a3731d4451  vmovaps xmm9, [rsp+0x90]
000079a3731d445a  vmovaps xmm10, [rsp+0xA0]
000079a3731d4463  vmovaps xmm11, [rsp+0xB0]
000079a3731d446c  vmovaps xmm13, [rsp+0xC0]
000079a3731d4475  vmovaps xmm14, [rsp+0xD0]
000079a3731d447e  vmovaps xmm15, [rsp+0xE0]
000079a3731d4487  add rsp, 0xF0
000079a3731d448e  pop r11
000079a3731d4490  pop r10
000079a3731d4492  pop r9
000079a3731d4494  pop r8
000079a3731d4496  pop rsi
000079a3731d4497  pop rdi
000079a3731d4498  pop rdx
000079a3731d4499  pop rcx
000079a3731d449a  pop rax
000079a3731d449b  add rsp, 0x08
000079a3731d449f  jmp 0x000079A3731D00F7
000079a3731d44a4  sub rsp, 0x08
000079a3731d44a8  push rax
000079a3731d44a9  push rcx
000079a3731d44aa  push rdx
000079a3731d44ab  push rdi
000079a3731d44ac  push rsi
000079a3731d44ad  push r8
000079a3731d44af  push r9
000079a3731d44b1  push r10
000079a3731d44b3  push r11
000079a3731d44b5  sub rsp, 0xF0
000079a3731d44bc  vmovaps [rsp], xmm0
000079a3731d44c1  vmovaps [rsp+0x10], xmm1
000079a3731d44c7  vmovaps [rsp+0x20], xmm2
000079a3731d44cd  vmovaps [rsp+0x30], xmm3
000079a3731d44d3  vmovaps [rsp+0x40], xmm4
000079a3731d44d9  vmovaps [rsp+0x50], xmm5
000079a3731d44df  vmovaps [rsp+0x60], xmm6
000079a3731d44e5  vmovaps [rsp+0x70], xmm7
000079a3731d44eb  vmovaps [rsp+0x80], xmm8
000079a3731d44f4  vmovaps [rsp+0x90], xmm9
000079a3731d44fd  vmovaps [rsp+0xA0], xmm10
000079a3731d4506  vmovaps [rsp+0xB0], xmm12
000079a3731d450f  vmovaps [rsp+0xC0], xmm13
000079a3731d4518  vmovaps [rsp+0xD0], xmm14
000079a3731d4521  vmovaps [rsp+0xE0], xmm15
000079a3731d452a  sub rsp, 0x30
000079a3731d452e  movaps [rsp], xmm11
000079a3731d4533  movaps [rsp+0x10], xmm7
000079a3731d4538  movaps [rsp+0x20], xmm15
000079a3731d453e  lea rdi, [rsp]
000079a3731d4542  mov esi, 0x00
000079a3731d4547  mov rax, 0x64F127B95530
000079a3731d4551  call rax
000079a3731d4553  movaps xmm11, [rsp]
000079a3731d4558  add rsp, 0x30
000079a3731d455c  vmovaps xmm0, [rsp]
000079a3731d4561  vmovaps xmm1, [rsp+0x10]
000079a3731d4567  vmovaps xmm2, [rsp+0x20]
000079a3731d456d  vmovaps xmm3, [rsp+0x30]
000079a3731d4573  vmovaps xmm4, [rsp+0x40]
000079a3731d4579  vmovaps xmm5, [rsp+0x50]
000079a3731d457f  vmovaps xmm6, [rsp+0x60]
000079a3731d4585  vmovaps xmm7, [rsp+0x70]
000079a3731d458b  vmovaps xmm8, [rsp+0x80]
000079a3731d4594  vmovaps xmm9, [rsp+0x90]
000079a3731d459d  vmovaps xmm10, [rsp+0xA0]
000079a3731d45a6  vmovaps xmm12, [rsp+0xB0]
000079a3731d45af  vmovaps xmm13, [rsp+0xC0]
000079a3731d45b8  vmovaps xmm14, [rsp+0xD0]
000079a3731d45c1  vmovaps xmm15, [rsp+0xE0]
000079a3731d45ca  add rsp, 0xF0
000079a3731d45d1  pop r11
000079a3731d45d3  pop r10
000079a3731d45d5  pop r9
000079a3731d45d7  pop r8
000079a3731d45d9  pop rsi
000079a3731d45da  pop rdi
000079a3731d45db  pop rdx
000079a3731d45dc  pop rcx
000079a3731d45dd  pop rax
000079a3731d45de  add rsp, 0x08
000079a3731d45e2  jmp 0x000079A3731D0123
000079a3731d45e7  sub rsp, 0x08
000079a3731d45eb  push rax
000079a3731d45ec  push rcx
000079a3731d45ed  push rdx
000079a3731d45ee  push rdi
000079a3731d45ef  push rsi
000079a3731d45f0  push r8
000079a3731d45f2  push r9
000079a3731d45f4  push r10
000079a3731d45f6  push r11
000079a3731d45f8  sub rsp, 0xF0
000079a3731d45ff  vmovaps [rsp], xmm0
000079a3731d4604  vmovaps [rsp+0x10], xmm1
000079a3731d460a  vmovaps [rsp+0x20], xmm2
000079a3731d4610  vmovaps [rsp+0x30], xmm3
000079a3731d4616  vmovaps [rsp+0x40], xmm4
000079a3731d461c  vmovaps [rsp+0x50], xmm5
000079a3731d4622  vmovaps [rsp+0x60], xmm6
000079a3731d4628  vmovaps [rsp+0x70], xmm7
000079a3731d462e  vmovaps [rsp+0x80], xmm8
000079a3731d4637  vmovaps [rsp+0x90], xmm9
000079a3731d4640  vmovaps [rsp+0xA0], xmm10
000079a3731d4649  vmovaps [rsp+0xB0], xmm11
000079a3731d4652  vmovaps [rsp+0xC0], xmm12
000079a3731d465b  vmovaps [rsp+0xD0], xmm13
000079a3731d4664  vmovaps [rsp+0xE0], xmm14
000079a3731d466d  sub rsp, 0x30
000079a3731d4671  movaps [rsp], xmm15
000079a3731d4676  movaps [rsp+0x10], xmm10
000079a3731d467c  movaps [rsp+0x20], xmm13
000079a3731d4682  lea rdi, [rsp]
000079a3731d4686  mov esi, 0x00
000079a3731d468b  mov rax, 0x64F127B95530
000079a3731d4695  call rax
000079a3731d4697  movaps xmm15, [rsp]
000079a3731d469c  add rsp, 0x30
000079a3731d46a0  vmovaps xmm0, [rsp]
000079a3731d46a5  vmovaps xmm1, [rsp+0x10]
000079a3731d46ab  vmovaps xmm2, [rsp+0x20]
000079a3731d46b1  vmovaps xmm3, [rsp+0x30]
000079a3731d46b7  vmovaps xmm4, [rsp+0x40]
000079a3731d46bd  vmovaps xmm5, [rsp+0x50]
000079a3731d46c3  vmovaps xmm6, [rsp+0x60]
000079a3731d46c9  vmovaps xmm7, [rsp+0x70]
000079a3731d46cf  vmovaps xmm8, [rsp+0x80]
000079a3731d46d8  vmovaps xmm9, [rsp+0x90]
000079a3731d46e1  vmovaps xmm10, [rsp+0xA0]
000079a3731d46ea  vmovaps xmm11, [rsp+0xB0]
000079a3731d46f3  vmovaps xmm12, [rsp+0xC0]
000079a3731d46fc  vmovaps xmm13, [rsp+0xD0]
000079a3731d4705  vmovaps xmm14, [rsp+0xE0]
000079a3731d470e  add rsp, 0xF0
000079a3731d4715  pop r11
000079a3731d4717  pop r10
000079a3731d4719  pop r9
000079a3731d471b  pop r8
000079a3731d471d  pop rsi
000079a3731d471e  pop rdi
000079a3731d471f  pop rdx
000079a3731d4720  pop rcx
000079a3731d4721  pop rax
000079a3731d4722  add rsp, 0x08
000079a3731d4726  jmp 0x000079A3731D013D
000079a3731d472b  sub rsp, 0x08
000079a3731d472f  push rax
000079a3731d4730  push rcx
000079a3731d4731  push rdx
000079a3731d4732  push rdi
000079a3731d4733  push rsi
000079a3731d4734  push r8
000079a3731d4736  push r9
000079a3731d4738  push r10
000079a3731d473a  push r11
000079a3731d473c  sub rsp, 0xF0
000079a3731d4743  vmovaps [rsp], xmm0
000079a3731d4748  vmovaps [rsp+0x10], xmm1
000079a3731d474e  vmovaps [rsp+0x20], xmm2
000079a3731d4754  vmovaps [rsp+0x30], xmm3
000079a3731d475a  vmovaps [rsp+0x40], xmm4
000079a3731d4760  vmovaps [rsp+0x50], xmm5
000079a3731d4766  vmovaps [rsp+0x60], xmm6
000079a3731d476c  vmovaps [rsp+0x70], xmm7
000079a3731d4772  vmovaps [rsp+0x80], xmm8
000079a3731d477b  vmovaps [rsp+0x90], xmm9
000079a3731d4784  vmovaps [rsp+0xA0], xmm11
000079a3731d478d  vmovaps [rsp+0xB0], xmm12
000079a3731d4796  vmovaps [rsp+0xC0], xmm13
000079a3731d479f  vmovaps [rsp+0xD0], xmm14
000079a3731d47a8  vmovaps [rsp+0xE0], xmm15
000079a3731d47b1  sub rsp, 0x30
000079a3731d47b5  movaps [rsp], xmm10
000079a3731d47ba  movaps [rsp+0x10], xmm7
000079a3731d47bf  movaps [rsp+0x20], xmm13
000079a3731d47c5  lea rdi, [rsp]
000079a3731d47c9  mov esi, 0x00
000079a3731d47ce  mov rax, 0x64F127B95530
000079a3731d47d8  call rax
000079a3731d47da  movaps xmm10, [rsp]
000079a3731d47df  add rsp, 0x30
000079a3731d47e3  vmovaps xmm0, [rsp]
000079a3731d47e8  vmovaps xmm1, [rsp+0x10]
000079a3731d47ee  vmovaps xmm2, [rsp+0x20]
000079a3731d47f4  vmovaps xmm3, [rsp+0x30]
000079a3731d47fa  vmovaps xmm4, [rsp+0x40]
000079a3731d4800  vmovaps xmm5, [rsp+0x50]
000079a3731d4806  vmovaps xmm6, [rsp+0x60]
000079a3731d480c  vmovaps xmm7, [rsp+0x70]
000079a3731d4812  vmovaps xmm8, [rsp+0x80]
000079a3731d481b  vmovaps xmm9, [rsp+0x90]
000079a3731d4824  vmovaps xmm11, [rsp+0xA0]
000079a3731d482d  vmovaps xmm12, [rsp+0xB0]
000079a3731d4836  vmovaps xmm13, [rsp+0xC0]
000079a3731d483f  vmovaps xmm14, [rsp+0xD0]
000079a3731d4848  vmovaps xmm15, [rsp+0xE0]
000079a3731d4851  add rsp, 0xF0
000079a3731d4858  pop r11
000079a3731d485a  pop r10
000079a3731d485c  pop r9
000079a3731d485e  pop r8
000079a3731d4860  pop rsi
000079a3731d4861  pop rdi
000079a3731d4862  pop rdx
000079a3731d4863  pop rcx
000079a3731d4864  pop rax
000079a3731d4865  add rsp, 0x08
000079a3731d4869  jmp 0x000079A3731D0169
000079a3731d486e  sub rsp, 0x08
000079a3731d4872  push rax
000079a3731d4873  push rcx
000079a3731d4874  push rdx
000079a3731d4875  push rdi
000079a3731d4876  push rsi
000079a3731d4877  push r8
000079a3731d4879  push r9
000079a3731d487b  push r10
000079a3731d487d  push r11
000079a3731d487f  sub rsp, 0xF0
000079a3731d4886  vmovaps [rsp], xmm0
000079a3731d488b  vmovaps [rsp+0x10], xmm1
000079a3731d4891  vmovaps [rsp+0x20], xmm2
000079a3731d4897  vmovaps [rsp+0x30], xmm3
000079a3731d489d  vmovaps [rsp+0x40], xmm4
000079a3731d48a3  vmovaps [rsp+0x50], xmm5
000079a3731d48a9  vmovaps [rsp+0x60], xmm6
000079a3731d48af  vmovaps [rsp+0x70], xmm7
000079a3731d48b5  vmovaps [rsp+0x80], xmm8
000079a3731d48be  vmovaps [rsp+0x90], xmm9
000079a3731d48c7  vmovaps [rsp+0xA0], xmm10
000079a3731d48d0  vmovaps [rsp+0xB0], xmm11
000079a3731d48d9  vmovaps [rsp+0xC0], xmm12
000079a3731d48e2  vmovaps [rsp+0xD0], xmm14
000079a3731d48eb  vmovaps [rsp+0xE0], xmm15
000079a3731d48f4  sub rsp, 0x30
000079a3731d48f8  movaps [rsp], xmm13
000079a3731d48fd  movaps [rsp+0x10], xmm1
000079a3731d4902  movaps [rsp+0x20], xmm8
000079a3731d4908  lea rdi, [rsp]
000079a3731d490c  mov esi, 0x00
000079a3731d4911  mov rax, 0x64F127B95530
000079a3731d491b  call rax
000079a3731d491d  movaps xmm13, [rsp]
000079a3731d4922  add rsp, 0x30
000079a3731d4926  vmovaps xmm0, [rsp]
000079a3731d492b  vmovaps xmm1, [rsp+0x10]
000079a3731d4931  vmovaps xmm2, [rsp+0x20]
000079a3731d4937  vmovaps xmm3, [rsp+0x30]
000079a3731d493d  vmovaps xmm4, [rsp+0x40]
000079a3731d4943  vmovaps xmm5, [rsp+0x50]
000079a3731d4949  vmovaps xmm6, [rsp+0x60]
000079a3731d494f  vmovaps xmm7, [rsp+0x70]
000079a3731d4955  vmovaps xmm8, [rsp+0x80]
000079a3731d495e  vmovaps xmm9, [rsp+0x90]
000079a3731d4967  vmovaps xmm10, [rsp+0xA0]
000079a3731d4970  vmovaps xmm11, [rsp+0xB0]
000079a3731d4979  vmovaps xmm12, [rsp+0xC0]
000079a3731d4982  vmovaps xmm14, [rsp+0xD0]
000079a3731d498b  vmovaps xmm15, [rsp+0xE0]
000079a3731d4994  add rsp, 0xF0
000079a3731d499b  pop r11
000079a3731d499d  pop r10
000079a3731d499f  pop r9
000079a3731d49a1  pop r8
000079a3731d49a3  pop rsi
000079a3731d49a4  pop rdi
000079a3731d49a5  pop rdx
000079a3731d49a6  pop rcx
000079a3731d49a7  pop rax
000079a3731d49a8  add rsp, 0x08
000079a3731d49ac  jmp 0x000079A3731D0183
000079a3731d49b1  call 0x000079A372FFF430
000079a3731d49b6  jmp 0x000079A3731D018D
000079a3731d49bb  sub rsp, 0x08
000079a3731d49bf  push rax
000079a3731d49c0  push rcx
000079a3731d49c1  push rdx
000079a3731d49c2  push rdi
000079a3731d49c3  push rsi
000079a3731d49c4  push r8
000079a3731d49c6  push r9
000079a3731d49c8  push r10
000079a3731d49ca  push r11
000079a3731d49cc  sub rsp, 0xF0
000079a3731d49d3  vmovaps [rsp], xmm0
000079a3731d49d8  vmovaps [rsp+0x10], xmm1
000079a3731d49de  vmovaps [rsp+0x20], xmm2
000079a3731d49e4  vmovaps [rsp+0x30], xmm3
000079a3731d49ea  vmovaps [rsp+0x40], xmm4
000079a3731d49f0  vmovaps [rsp+0x50], xmm5
000079a3731d49f6  vmovaps [rsp+0x60], xmm6
000079a3731d49fc  vmovaps [rsp+0x70], xmm7
000079a3731d4a02  vmovaps [rsp+0x80], xmm9
000079a3731d4a0b  vmovaps [rsp+0x90], xmm10
000079a3731d4a14  vmovaps [rsp+0xA0], xmm11
000079a3731d4a1d  vmovaps [rsp+0xB0], xmm12
000079a3731d4a26  vmovaps [rsp+0xC0], xmm13
000079a3731d4a2f  vmovaps [rsp+0xD0], xmm14
000079a3731d4a38  vmovaps [rsp+0xE0], xmm15
000079a3731d4a41  sub rsp, 0x30
000079a3731d4a45  movaps [rsp], xmm8
000079a3731d4a4a  movaps [rsp+0x10], xmm14
000079a3731d4a50  movaps [rsp+0x20], xmm9
000079a3731d4a56  lea rdi, [rsp]
000079a3731d4a5a  mov esi, 0x00
000079a3731d4a5f  mov rax, 0x64F127B95530
000079a3731d4a69  call rax
000079a3731d4a6b  movaps xmm8, [rsp]
000079a3731d4a70  add rsp, 0x30
000079a3731d4a74  vmovaps xmm0, [rsp]
000079a3731d4a79  vmovaps xmm1, [rsp+0x10]
000079a3731d4a7f  vmovaps xmm2, [rsp+0x20]
000079a3731d4a85  vmovaps xmm3, [rsp+0x30]
000079a3731d4a8b  vmovaps xmm4, [rsp+0x40]
000079a3731d4a91  vmovaps xmm5, [rsp+0x50]
000079a3731d4a97  vmovaps xmm6, [rsp+0x60]
000079a3731d4a9d  vmovaps xmm7, [rsp+0x70]
000079a3731d4aa3  vmovaps xmm9, [rsp+0x80]
000079a3731d4aac  vmovaps xmm10, [rsp+0x90]
000079a3731d4ab5  vmovaps xmm11, [rsp+0xA0]
000079a3731d4abe  vmovaps xmm12, [rsp+0xB0]
000079a3731d4ac7  vmovaps xmm13, [rsp+0xC0]
000079a3731d4ad0  vmovaps xmm14, [rsp+0xD0]
000079a3731d4ad9  vmovaps xmm15, [rsp+0xE0]
000079a3731d4ae2  add rsp, 0xF0
000079a3731d4ae9  pop r11
000079a3731d4aeb  pop r10
000079a3731d4aed  pop r9
000079a3731d4aef  pop r8
000079a3731d4af1  pop rsi
000079a3731d4af2  pop rdi
000079a3731d4af3  pop rdx
000079a3731d4af4  pop rcx
000079a3731d4af5  pop rax
000079a3731d4af6  add rsp, 0x08
000079a3731d4afa  jmp 0x000079A3731D01AF
000079a3731d4aff  sub rsp, 0x08
000079a3731d4b03  push rax
000079a3731d4b04  push rcx
000079a3731d4b05  push rdx
000079a3731d4b06  push rdi
000079a3731d4b07  push rsi
000079a3731d4b08  push r8
000079a3731d4b0a  push r9
000079a3731d4b0c  push r10
000079a3731d4b0e  push r11
000079a3731d4b10  sub rsp, 0xF0
000079a3731d4b17  vmovaps [rsp], xmm0
000079a3731d4b1c  vmovaps [rsp+0x10], xmm1
000079a3731d4b22  vmovaps [rsp+0x20], xmm2
000079a3731d4b28  vmovaps [rsp+0x30], xmm3
000079a3731d4b2e  vmovaps [rsp+0x40], xmm4
000079a3731d4b34  vmovaps [rsp+0x50], xmm5
000079a3731d4b3a  vmovaps [rsp+0x60], xmm6
000079a3731d4b40  vmovaps [rsp+0x70], xmm7
000079a3731d4b46  vmovaps [rsp+0x80], xmm8
000079a3731d4b4f  vmovaps [rsp+0x90], xmm10
000079a3731d4b58  vmovaps [rsp+0xA0], xmm11
000079a3731d4b61  vmovaps [rsp+0xB0], xmm12
000079a3731d4b6a  vmovaps [rsp+0xC0], xmm13
000079a3731d4b73  vmovaps [rsp+0xD0], xmm14
000079a3731d4b7c  vmovaps [rsp+0xE0], xmm15
000079a3731d4b85  sub rsp, 0x30
000079a3731d4b89  movaps [rsp], xmm9
000079a3731d4b8e  movaps [rsp+0x10], xmm1
000079a3731d4b93  movaps [rsp+0x20], xmm14
000079a3731d4b99  lea rdi, [rsp]
000079a3731d4b9d  mov esi, 0x00
000079a3731d4ba2  mov rax, 0x64F127B95530
000079a3731d4bac  call rax
000079a3731d4bae  movaps xmm9, [rsp]
000079a3731d4bb3  add rsp, 0x30
000079a3731d4bb7  vmovaps xmm0, [rsp]
000079a3731d4bbc  vmovaps xmm1, [rsp+0x10]
000079a3731d4bc2  vmovaps xmm2, [rsp+0x20]
000079a3731d4bc8  vmovaps xmm3, [rsp+0x30]
000079a3731d4bce  vmovaps xmm4, [rsp+0x40]
000079a3731d4bd4  vmovaps xmm5, [rsp+0x50]
000079a3731d4bda  vmovaps xmm6, [rsp+0x60]
000079a3731d4be0  vmovaps xmm7, [rsp+0x70]
000079a3731d4be6  vmovaps xmm8, [rsp+0x80]
000079a3731d4bef  vmovaps xmm10, [rsp+0x90]
000079a3731d4bf8  vmovaps xmm11, [rsp+0xA0]
000079a3731d4c01  vmovaps xmm12, [rsp+0xB0]
000079a3731d4c0a  vmovaps xmm13, [rsp+0xC0]
000079a3731d4c13  vmovaps xmm14, [rsp+0xD0]
000079a3731d4c1c  vmovaps xmm15, [rsp+0xE0]
000079a3731d4c25  add rsp, 0xF0
000079a3731d4c2c  pop r11
000079a3731d4c2e  pop r10
000079a3731d4c30  pop r9
000079a3731d4c32  pop r8
000079a3731d4c34  pop rsi
000079a3731d4c35  pop rdi
000079a3731d4c36  pop rdx
000079a3731d4c37  pop rcx
000079a3731d4c38  pop rax
000079a3731d4c39  add rsp, 0x08
000079a3731d4c3d  jmp 0x000079A3731D01DD
000079a3731d4c42  sub rsp, 0x08
000079a3731d4c46  push rax
000079a3731d4c47  push rcx
000079a3731d4c48  push rdx
000079a3731d4c49  push rdi
000079a3731d4c4a  push rsi
000079a3731d4c4b  push r8
000079a3731d4c4d  push r9
000079a3731d4c4f  push r10
000079a3731d4c51  push r11
000079a3731d4c53  sub rsp, 0xF0
000079a3731d4c5a  vmovaps [rsp], xmm0
000079a3731d4c5f  vmovaps [rsp+0x10], xmm1
000079a3731d4c65  vmovaps [rsp+0x20], xmm2
000079a3731d4c6b  vmovaps [rsp+0x30], xmm3
000079a3731d4c71  vmovaps [rsp+0x40], xmm4
000079a3731d4c77  vmovaps [rsp+0x50], xmm5
000079a3731d4c7d  vmovaps [rsp+0x60], xmm6
000079a3731d4c83  vmovaps [rsp+0x70], xmm7
000079a3731d4c89  vmovaps [rsp+0x80], xmm8
000079a3731d4c92  vmovaps [rsp+0x90], xmm9
000079a3731d4c9b  vmovaps [rsp+0xA0], xmm10
000079a3731d4ca4  vmovaps [rsp+0xB0], xmm11
000079a3731d4cad  vmovaps [rsp+0xC0], xmm12
000079a3731d4cb6  vmovaps [rsp+0xD0], xmm13
000079a3731d4cbf  vmovaps [rsp+0xE0], xmm15
000079a3731d4cc8  sub rsp, 0x30
000079a3731d4ccc  movaps [rsp], xmm14
000079a3731d4cd1  movaps [rsp+0x10], xmm4
000079a3731d4cd6  movaps [rsp+0x20], xmm1
000079a3731d4cdb  lea rdi, [rsp]
000079a3731d4cdf  mov esi, 0x00
000079a3731d4ce4  mov rax, 0x64F127B95530
000079a3731d4cee  call rax
000079a3731d4cf0  movaps xmm14, [rsp]
000079a3731d4cf5  add rsp, 0x30
000079a3731d4cf9  vmovaps xmm0, [rsp]
000079a3731d4cfe  vmovaps xmm1, [rsp+0x10]
000079a3731d4d04  vmovaps xmm2, [rsp+0x20]
000079a3731d4d0a  vmovaps xmm3, [rsp+0x30]
000079a3731d4d10  vmovaps xmm4, [rsp+0x40]
000079a3731d4d16  vmovaps xmm5, [rsp+0x50]
000079a3731d4d1c  vmovaps xmm6, [rsp+0x60]
000079a3731d4d22  vmovaps xmm7, [rsp+0x70]
000079a3731d4d28  vmovaps xmm8, [rsp+0x80]
000079a3731d4d31  vmovaps xmm9, [rsp+0x90]
000079a3731d4d3a  vmovaps xmm10, [rsp+0xA0]
000079a3731d4d43  vmovaps xmm11, [rsp+0xB0]
000079a3731d4d4c  vmovaps xmm12, [rsp+0xC0]
000079a3731d4d55  vmovaps xmm13, [rsp+0xD0]
000079a3731d4d5e  vmovaps xmm15, [rsp+0xE0]
000079a3731d4d67  add rsp, 0xF0
000079a3731d4d6e  pop r11
000079a3731d4d70  pop r10
000079a3731d4d72  pop r9
000079a3731d4d74  pop r8
000079a3731d4d76  pop rsi
000079a3731d4d77  pop rdi
000079a3731d4d78  pop rdx
000079a3731d4d79  pop rcx
000079a3731d4d7a  pop rax
000079a3731d4d7b  add rsp, 0x08
000079a3731d4d7f  jmp 0x000079A3731D0203
000079a3731d4d84  sub rsp, 0x08
000079a3731d4d88  push rax
000079a3731d4d89  push rcx
000079a3731d4d8a  push rdx
000079a3731d4d8b  push rdi
000079a3731d4d8c  push rsi
000079a3731d4d8d  push r8
000079a3731d4d8f  push r9
000079a3731d4d91  push r10
000079a3731d4d93  push r11
000079a3731d4d95  sub rsp, 0xF0
000079a3731d4d9c  vmovaps [rsp], xmm0
000079a3731d4da1  vmovaps [rsp+0x10], xmm2
000079a3731d4da7  vmovaps [rsp+0x20], xmm3
000079a3731d4dad  vmovaps [rsp+0x30], xmm4
000079a3731d4db3  vmovaps [rsp+0x40], xmm5
000079a3731d4db9  vmovaps [rsp+0x50], xmm6
000079a3731d4dbf  vmovaps [rsp+0x60], xmm7
000079a3731d4dc5  vmovaps [rsp+0x70], xmm8
000079a3731d4dcb  vmovaps [rsp+0x80], xmm9
000079a3731d4dd4  vmovaps [rsp+0x90], xmm10
000079a3731d4ddd  vmovaps [rsp+0xA0], xmm11
000079a3731d4de6  vmovaps [rsp+0xB0], xmm12
000079a3731d4def  vmovaps [rsp+0xC0], xmm13
000079a3731d4df8  vmovaps [rsp+0xD0], xmm14
000079a3731d4e01  vmovaps [rsp+0xE0], xmm15
000079a3731d4e0a  sub rsp, 0x30
000079a3731d4e0e  movaps [rsp], xmm1
000079a3731d4e12  movaps [rsp+0x10], xmm12
000079a3731d4e18  movaps [rsp+0x20], xmm11
000079a3731d4e1e  lea rdi, [rsp]
000079a3731d4e22  mov esi, 0x00
000079a3731d4e27  mov rax, 0x64F127B95530
000079a3731d4e31  call rax
000079a3731d4e33  movaps xmm1, [rsp]
000079a3731d4e37  add rsp, 0x30
000079a3731d4e3b  vmovaps xmm0, [rsp]
000079a3731d4e40  vmovaps xmm2, [rsp+0x10]
000079a3731d4e46  vmovaps xmm3, [rsp+0x20]
000079a3731d4e4c  vmovaps xmm4, [rsp+0x30]
000079a3731d4e52  vmovaps xmm5, [rsp+0x40]
000079a3731d4e58  vmovaps xmm6, [rsp+0x50]
000079a3731d4e5e  vmovaps xmm7, [rsp+0x60]
000079a3731d4e64  vmovaps xmm8, [rsp+0x70]
000079a3731d4e6a  vmovaps xmm9, [rsp+0x80]
000079a3731d4e73  vmovaps xmm10, [rsp+0x90]
000079a3731d4e7c  vmovaps xmm11, [rsp+0xA0]
000079a3731d4e85  vmovaps xmm12, [rsp+0xB0]
000079a3731d4e8e  vmovaps xmm13, [rsp+0xC0]
000079a3731d4e97  vmovaps xmm14, [rsp+0xD0]
000079a3731d4ea0  vmovaps xmm15, [rsp+0xE0]
000079a3731d4ea9  add rsp, 0xF0
000079a3731d4eb0  pop r11
000079a3731d4eb2  pop r10
000079a3731d4eb4  pop r9
000079a3731d4eb6  pop r8
000079a3731d4eb8  pop rsi
000079a3731d4eb9  pop rdi
000079a3731d4eba  pop rdx
000079a3731d4ebb  pop rcx
000079a3731d4ebc  pop rax
000079a3731d4ebd  add rsp, 0x08
000079a3731d4ec1  jmp 0x000079A3731D0224
000079a3731d4ec6  call 0x000079A3730E20A0
000079a3731d4ecb  jmp 0x000079A3731D0232
000079a3731d4ed0  call 0x000079A373009D70
000079a3731d4ed5  jmp 0x000079A3731D023C
000079a3731d4eda  sub rsp, 0x08
000079a3731d4ede  push rax
000079a3731d4edf  push rcx
000079a3731d4ee0  push rdx
000079a3731d4ee1  push rdi
000079a3731d4ee2  push rsi
000079a3731d4ee3  push r8
000079a3731d4ee5  push r9
000079a3731d4ee7  push r10
000079a3731d4ee9  push r11
000079a3731d4eeb  sub rsp, 0xF0
000079a3731d4ef2  vmovaps [rsp], xmm0
000079a3731d4ef7  vmovaps [rsp+0x10], xmm1
000079a3731d4efd  vmovaps [rsp+0x20], xmm2
000079a3731d4f03  vmovaps [rsp+0x30], xmm3
000079a3731d4f09  vmovaps [rsp+0x40], xmm4
000079a3731d4f0f  vmovaps [rsp+0x50], xmm5
000079a3731d4f15  vmovaps [rsp+0x60], xmm6
000079a3731d4f1b  vmovaps [rsp+0x70], xmm8
000079a3731d4f21  vmovaps [rsp+0x80], xmm9
000079a3731d4f2a  vmovaps [rsp+0x90], xmm10
000079a3731d4f33  vmovaps [rsp+0xA0], xmm11
000079a3731d4f3c  vmovaps [rsp+0xB0], xmm12
000079a3731d4f45  vmovaps [rsp+0xC0], xmm13
000079a3731d4f4e  vmovaps [rsp+0xD0], xmm14
000079a3731d4f57  vmovaps [rsp+0xE0], xmm15
000079a3731d4f60  sub rsp, 0x30
000079a3731d4f64  movaps [rsp], xmm7
000079a3731d4f68  movaps [rsp+0x10], xmm15
000079a3731d4f6e  movaps [rsp+0x20], xmm10
000079a3731d4f74  lea rdi, [rsp]
000079a3731d4f78  mov esi, 0x00
000079a3731d4f7d  mov rax, 0x64F127B95530
000079a3731d4f87  call rax
000079a3731d4f89  movaps xmm7, [rsp]
000079a3731d4f8d  add rsp, 0x30
000079a3731d4f91  vmovaps xmm0, [rsp]
000079a3731d4f96  vmovaps xmm1, [rsp+0x10]
000079a3731d4f9c  vmovaps xmm2, [rsp+0x20]
000079a3731d4fa2  vmovaps xmm3, [rsp+0x30]
000079a3731d4fa8  vmovaps xmm4, [rsp+0x40]
000079a3731d4fae  vmovaps xmm5, [rsp+0x50]
000079a3731d4fb4  vmovaps xmm6, [rsp+0x60]
000079a3731d4fba  vmovaps xmm8, [rsp+0x70]
000079a3731d4fc0  vmovaps xmm9, [rsp+0x80]
000079a3731d4fc9  vmovaps xmm10, [rsp+0x90]
000079a3731d4fd2  vmovaps xmm11, [rsp+0xA0]
000079a3731d4fdb  vmovaps xmm12, [rsp+0xB0]
000079a3731d4fe4  vmovaps xmm13, [rsp+0xC0]
000079a3731d4fed  vmovaps xmm14, [rsp+0xD0]
000079a3731d4ff6  vmovaps xmm15, [rsp+0xE0]
000079a3731d4fff  add rsp, 0xF0
000079a3731d5006  pop r11
000079a3731d5008  pop r10
000079a3731d500a  pop r9
000079a3731d500c  pop r8
000079a3731d500e  pop rsi
000079a3731d500f  pop rdi
000079a3731d5010  pop rdx
000079a3731d5011  pop rcx
000079a3731d5012  pop rax
000079a3731d5013  add rsp, 0x08
000079a3731d5017  jmp 0x000079A3731D025D
000079a3731d501c  sub rsp, 0x08
000079a3731d5020  push rax
000079a3731d5021  push rcx
000079a3731d5022  push rdx
000079a3731d5023  push rdi
000079a3731d5024  push rsi
000079a3731d5025  push r8
000079a3731d5027  push r9
000079a3731d5029  push r10
000079a3731d502b  push r11
000079a3731d502d  sub rsp, 0xF0
000079a3731d5034  vmovaps [rsp], xmm0
000079a3731d5039  vmovaps [rsp+0x10], xmm1
000079a3731d503f  vmovaps [rsp+0x20], xmm2
000079a3731d5045  vmovaps [rsp+0x30], xmm3
000079a3731d504b  vmovaps [rsp+0x40], xmm4
000079a3731d5051  vmovaps [rsp+0x50], xmm5
000079a3731d5057  vmovaps [rsp+0x60], xmm6
000079a3731d505d  vmovaps [rsp+0x70], xmm7
000079a3731d5063  vmovaps [rsp+0x80], xmm8
000079a3731d506c  vmovaps [rsp+0x90], xmm9
000079a3731d5075  vmovaps [rsp+0xA0], xmm11
000079a3731d507e  vmovaps [rsp+0xB0], xmm12
000079a3731d5087  vmovaps [rsp+0xC0], xmm13
000079a3731d5090  vmovaps [rsp+0xD0], xmm14
000079a3731d5099  vmovaps [rsp+0xE0], xmm15
000079a3731d50a2  sub rsp, 0x30
000079a3731d50a6  movaps [rsp], xmm10
000079a3731d50ab  movaps [rsp+0x10], xmm11
000079a3731d50b1  movaps [rsp+0x20], xmm15
000079a3731d50b7  lea rdi, [rsp]
000079a3731d50bb  mov esi, 0x00
000079a3731d50c0  mov rax, 0x64F127B95530
000079a3731d50ca  call rax
000079a3731d50cc  movaps xmm10, [rsp]
000079a3731d50d1  add rsp, 0x30
000079a3731d50d5  vmovaps xmm0, [rsp]
000079a3731d50da  vmovaps xmm1, [rsp+0x10]
000079a3731d50e0  vmovaps xmm2, [rsp+0x20]
000079a3731d50e6  vmovaps xmm3, [rsp+0x30]
000079a3731d50ec  vmovaps xmm4, [rsp+0x40]
000079a3731d50f2  vmovaps xmm5, [rsp+0x50]
000079a3731d50f8  vmovaps xmm6, [rsp+0x60]
000079a3731d50fe  vmovaps xmm7, [rsp+0x70]
000079a3731d5104  vmovaps xmm8, [rsp+0x80]
000079a3731d510d  vmovaps xmm9, [rsp+0x90]
000079a3731d5116  vmovaps xmm11, [rsp+0xA0]
000079a3731d511f  vmovaps xmm12, [rsp+0xB0]
000079a3731d5128  vmovaps xmm13, [rsp+0xC0]
000079a3731d5131  vmovaps xmm14, [rsp+0xD0]
000079a3731d513a  vmovaps xmm15, [rsp+0xE0]
000079a3731d5143  add rsp, 0xF0
000079a3731d514a  pop r11
000079a3731d514c  pop r10
000079a3731d514e  pop r9
000079a3731d5150  pop r8
000079a3731d5152  pop rsi
000079a3731d5153  pop rdi
000079a3731d5154  pop rdx
000079a3731d5155  pop rcx
000079a3731d5156  pop rax
000079a3731d5157  add rsp, 0x08
000079a3731d515b  jmp 0x000079A3731D028B
000079a3731d5160  sub rsp, 0x08
000079a3731d5164  push rax
000079a3731d5165  push rcx
000079a3731d5166  push rdx
000079a3731d5167  push rdi
000079a3731d5168  push rsi
000079a3731d5169  push r8
000079a3731d516b  push r9
000079a3731d516d  push r10
000079a3731d516f  push r11
000079a3731d5171  sub rsp, 0xF0
000079a3731d5178  vmovaps [rsp], xmm0
000079a3731d517d  vmovaps [rsp+0x10], xmm1
000079a3731d5183  vmovaps [rsp+0x20], xmm2
000079a3731d5189  vmovaps [rsp+0x30], xmm3
000079a3731d518f  vmovaps [rsp+0x40], xmm4
000079a3731d5195  vmovaps [rsp+0x50], xmm5
000079a3731d519b  vmovaps [rsp+0x60], xmm6
000079a3731d51a1  vmovaps [rsp+0x70], xmm7
000079a3731d51a7  vmovaps [rsp+0x80], xmm8
000079a3731d51b0  vmovaps [rsp+0x90], xmm9
000079a3731d51b9  vmovaps [rsp+0xA0], xmm10
000079a3731d51c2  vmovaps [rsp+0xB0], xmm12
000079a3731d51cb  vmovaps [rsp+0xC0], xmm13
000079a3731d51d4  vmovaps [rsp+0xD0], xmm14
000079a3731d51dd  vmovaps [rsp+0xE0], xmm15
000079a3731d51e6  sub rsp, 0x30
000079a3731d51ea  movaps [rsp], xmm11
000079a3731d51ef  movaps [rsp+0x10], xmm12
000079a3731d51f5  movaps [rsp+0x20], xmm15
000079a3731d51fb  lea rdi, [rsp]
000079a3731d51ff  mov esi, 0x00
000079a3731d5204  mov rax, 0x64F127B95530
000079a3731d520e  call rax
000079a3731d5210  movaps xmm11, [rsp]
000079a3731d5215  add rsp, 0x30
000079a3731d5219  vmovaps xmm0, [rsp]
000079a3731d521e  vmovaps xmm1, [rsp+0x10]
000079a3731d5224  vmovaps xmm2, [rsp+0x20]
000079a3731d522a  vmovaps xmm3, [rsp+0x30]
000079a3731d5230  vmovaps xmm4, [rsp+0x40]
000079a3731d5236  vmovaps xmm5, [rsp+0x50]
000079a3731d523c  vmovaps xmm6, [rsp+0x60]
000079a3731d5242  vmovaps xmm7, [rsp+0x70]
000079a3731d5248  vmovaps xmm8, [rsp+0x80]
000079a3731d5251  vmovaps xmm9, [rsp+0x90]
000079a3731d525a  vmovaps xmm10, [rsp+0xA0]
000079a3731d5263  vmovaps xmm12, [rsp+0xB0]
000079a3731d526c  vmovaps xmm13, [rsp+0xC0]
000079a3731d5275  vmovaps xmm14, [rsp+0xD0]
000079a3731d527e  vmovaps xmm15, [rsp+0xE0]
000079a3731d5287  add rsp, 0xF0
000079a3731d528e  pop r11
000079a3731d5290  pop r10
000079a3731d5292  pop r9
000079a3731d5294  pop r8
000079a3731d5296  pop rsi
000079a3731d5297  pop rdi
000079a3731d5298  pop rdx
000079a3731d5299  pop rcx
000079a3731d529a  pop rax
000079a3731d529b  add rsp, 0x08
000079a3731d529f  jmp 0x000079A3731D02B9
000079a3731d52a4  sub rsp, 0x08
000079a3731d52a8  push rax
000079a3731d52a9  push rcx
000079a3731d52aa  push rdx
000079a3731d52ab  push rdi
000079a3731d52ac  push rsi
000079a3731d52ad  push r8
000079a3731d52af  push r9
000079a3731d52b1  push r10
000079a3731d52b3  push r11
000079a3731d52b5  sub rsp, 0xF0
000079a3731d52bc  vmovaps [rsp], xmm0
000079a3731d52c1  vmovaps [rsp+0x10], xmm1
000079a3731d52c7  vmovaps [rsp+0x20], xmm2
000079a3731d52cd  vmovaps [rsp+0x30], xmm3
000079a3731d52d3  vmovaps [rsp+0x40], xmm4
000079a3731d52d9  vmovaps [rsp+0x50], xmm5
000079a3731d52df  vmovaps [rsp+0x60], xmm6
000079a3731d52e5  vmovaps [rsp+0x70], xmm7
000079a3731d52eb  vmovaps [rsp+0x80], xmm8
000079a3731d52f4  vmovaps [rsp+0x90], xmm9
000079a3731d52fd  vmovaps [rsp+0xA0], xmm10
000079a3731d5306  vmovaps [rsp+0xB0], xmm11
000079a3731d530f  vmovaps [rsp+0xC0], xmm12
000079a3731d5318  vmovaps [rsp+0xD0], xmm13
000079a3731d5321  vmovaps [rsp+0xE0], xmm14
000079a3731d532a  sub rsp, 0x30
000079a3731d532e  movaps [rsp], xmm15
000079a3731d5333  movaps [rsp+0x10], xmm13
000079a3731d5339  movaps [rsp+0x20], xmm9
000079a3731d533f  lea rdi, [rsp]
000079a3731d5343  mov esi, 0x00
000079a3731d5348  mov rax, 0x64F127B95530
000079a3731d5352  call rax
000079a3731d5354  movaps xmm15, [rsp]
000079a3731d5359  add rsp, 0x30
000079a3731d535d  vmovaps xmm0, [rsp]
000079a3731d5362  vmovaps xmm1, [rsp+0x10]
000079a3731d5368  vmovaps xmm2, [rsp+0x20]
000079a3731d536e  vmovaps xmm3, [rsp+0x30]
000079a3731d5374  vmovaps xmm4, [rsp+0x40]
000079a3731d537a  vmovaps xmm5, [rsp+0x50]
000079a3731d5380  vmovaps xmm6, [rsp+0x60]
000079a3731d5386  vmovaps xmm7, [rsp+0x70]
000079a3731d538c  vmovaps xmm8, [rsp+0x80]
000079a3731d5395  vmovaps xmm9, [rsp+0x90]
000079a3731d539e  vmovaps xmm10, [rsp+0xA0]
000079a3731d53a7  vmovaps xmm11, [rsp+0xB0]
000079a3731d53b0  vmovaps xmm12, [rsp+0xC0]
000079a3731d53b9  vmovaps xmm13, [rsp+0xD0]
000079a3731d53c2  vmovaps xmm14, [rsp+0xE0]
000079a3731d53cb  add rsp, 0xF0
000079a3731d53d2  pop r11
000079a3731d53d4  pop r10
000079a3731d53d6  pop r9
000079a3731d53d8  pop r8
000079a3731d53da  pop rsi
000079a3731d53db  pop rdi
000079a3731d53dc  pop rdx
000079a3731d53dd  pop rcx
000079a3731d53de  pop rax
000079a3731d53df  add rsp, 0x08
000079a3731d53e3  jmp 0x000079A3731D02D4
000079a3731d53e8  sub rsp, 0x08
000079a3731d53ec  push rax
000079a3731d53ed  push rcx
000079a3731d53ee  push rdx
000079a3731d53ef  push rdi
000079a3731d53f0  push rsi
000079a3731d53f1  push r8
000079a3731d53f3  push r9
000079a3731d53f5  push r10
000079a3731d53f7  push r11
000079a3731d53f9  sub rsp, 0xF0
000079a3731d5400  vmovaps [rsp], xmm0
000079a3731d5405  vmovaps [rsp+0x10], xmm1
000079a3731d540b  vmovaps [rsp+0x20], xmm2
000079a3731d5411  vmovaps [rsp+0x30], xmm3
000079a3731d5417  vmovaps [rsp+0x40], xmm4
000079a3731d541d  vmovaps [rsp+0x50], xmm5
000079a3731d5423  vmovaps [rsp+0x60], xmm6
000079a3731d5429  vmovaps [rsp+0x70], xmm7
000079a3731d542f  vmovaps [rsp+0x80], xmm8
000079a3731d5438  vmovaps [rsp+0x90], xmm9
000079a3731d5441  vmovaps [rsp+0xA0], xmm10
000079a3731d544a  vmovaps [rsp+0xB0], xmm11
000079a3731d5453  vmovaps [rsp+0xC0], xmm12
000079a3731d545c  vmovaps [rsp+0xD0], xmm14
000079a3731d5465  vmovaps [rsp+0xE0], xmm15
000079a3731d546e  sub rsp, 0x30
000079a3731d5472  movaps [rsp], xmm13
000079a3731d5477  movaps [rsp+0x10], xmm8
000079a3731d547d  movaps [rsp+0x20], xmm14
000079a3731d5483  lea rdi, [rsp]
000079a3731d5487  mov esi, 0x00
000079a3731d548c  mov rax, 0x64F127B95530
000079a3731d5496  call rax
000079a3731d5498  movaps xmm13, [rsp]
000079a3731d549d  add rsp, 0x30
000079a3731d54a1  vmovaps xmm0, [rsp]
000079a3731d54a6  vmovaps xmm1, [rsp+0x10]
000079a3731d54ac  vmovaps xmm2, [rsp+0x20]
000079a3731d54b2  vmovaps xmm3, [rsp+0x30]
000079a3731d54b8  vmovaps xmm4, [rsp+0x40]
000079a3731d54be  vmovaps xmm5, [rsp+0x50]
000079a3731d54c4  vmovaps xmm6, [rsp+0x60]
000079a3731d54ca  vmovaps xmm7, [rsp+0x70]
000079a3731d54d0  vmovaps xmm8, [rsp+0x80]
000079a3731d54d9  vmovaps xmm9, [rsp+0x90]
000079a3731d54e2  vmovaps xmm10, [rsp+0xA0]
000079a3731d54eb  vmovaps xmm11, [rsp+0xB0]
000079a3731d54f4  vmovaps xmm12, [rsp+0xC0]
000079a3731d54fd  vmovaps xmm14, [rsp+0xD0]
000079a3731d5506  vmovaps xmm15, [rsp+0xE0]
000079a3731d550f  add rsp, 0xF0
000079a3731d5516  pop r11
000079a3731d5518  pop r10
000079a3731d551a  pop r9
000079a3731d551c  pop r8
000079a3731d551e  pop rsi
000079a3731d551f  pop rdi
000079a3731d5520  pop rdx
000079a3731d5521  pop rcx
000079a3731d5522  pop rax
000079a3731d5523  add rsp, 0x08
000079a3731d5527  jmp 0x000079A3731D02F7
000079a3731d552c  sub rsp, 0x08
000079a3731d5530  push rax
000079a3731d5531  push rcx
000079a3731d5532  push rdx
000079a3731d5533  push rdi
000079a3731d5534  push rsi
000079a3731d5535  push r8
000079a3731d5537  push r9
000079a3731d5539  push r10
000079a3731d553b  push r11
000079a3731d553d  sub rsp, 0xF0
000079a3731d5544  vmovaps [rsp], xmm0
000079a3731d5549  vmovaps [rsp+0x10], xmm1
000079a3731d554f  vmovaps [rsp+0x20], xmm2
000079a3731d5555  vmovaps [rsp+0x30], xmm3
000079a3731d555b  vmovaps [rsp+0x40], xmm4
000079a3731d5561  vmovaps [rsp+0x50], xmm5
000079a3731d5567  vmovaps [rsp+0x60], xmm6
000079a3731d556d  vmovaps [rsp+0x70], xmm7
000079a3731d5573  vmovaps [rsp+0x80], xmm8
000079a3731d557c  vmovaps [rsp+0x90], xmm9
000079a3731d5585  vmovaps [rsp+0xA0], xmm10
000079a3731d558e  vmovaps [rsp+0xB0], xmm11
000079a3731d5597  vmovaps [rsp+0xC0], xmm12
000079a3731d55a0  vmovaps [rsp+0xD0], xmm13
000079a3731d55a9  vmovaps [rsp+0xE0], xmm15
000079a3731d55b2  sub rsp, 0x30
000079a3731d55b6  movaps [rsp], xmm14
000079a3731d55bb  movaps [rsp+0x10], xmm1
000079a3731d55c0  movaps [rsp+0x20], xmm10
000079a3731d55c6  lea rdi, [rsp]
000079a3731d55ca  mov esi, 0x00
000079a3731d55cf  mov rax, 0x64F127B95530
000079a3731d55d9  call rax
000079a3731d55db  movaps xmm14, [rsp]
000079a3731d55e0  add rsp, 0x30
000079a3731d55e4  vmovaps xmm0, [rsp]
000079a3731d55e9  vmovaps xmm1, [rsp+0x10]
000079a3731d55ef  vmovaps xmm2, [rsp+0x20]
000079a3731d55f5  vmovaps xmm3, [rsp+0x30]
000079a3731d55fb  vmovaps xmm4, [rsp+0x40]
000079a3731d5601  vmovaps xmm5, [rsp+0x50]
000079a3731d5607  vmovaps xmm6, [rsp+0x60]
000079a3731d560d  vmovaps xmm7, [rsp+0x70]
000079a3731d5613  vmovaps xmm8, [rsp+0x80]
000079a3731d561c  vmovaps xmm9, [rsp+0x90]
000079a3731d5625  vmovaps xmm10, [rsp+0xA0]
000079a3731d562e  vmovaps xmm11, [rsp+0xB0]
000079a3731d5637  vmovaps xmm12, [rsp+0xC0]
000079a3731d5640  vmovaps xmm13, [rsp+0xD0]
000079a3731d5649  vmovaps xmm15, [rsp+0xE0]
000079a3731d5652  add rsp, 0xF0
000079a3731d5659  pop r11
000079a3731d565b  pop r10
000079a3731d565d  pop r9
000079a3731d565f  pop r8
000079a3731d5661  pop rsi
000079a3731d5662  pop rdi
000079a3731d5663  pop rdx
000079a3731d5664  pop rcx
000079a3731d5665  pop rax
000079a3731d5666  add rsp, 0x08
000079a3731d566a  jmp 0x000079A3731D031A
000079a3731d566f  sub rsp, 0x08
000079a3731d5673  push rax
000079a3731d5674  push rcx
000079a3731d5675  push rdx
000079a3731d5676  push rdi
000079a3731d5677  push rsi
000079a3731d5678  push r8
000079a3731d567a  push r9
000079a3731d567c  push r10
000079a3731d567e  push r11
000079a3731d5680  sub rsp, 0xF0
000079a3731d5687  vmovaps [rsp], xmm0
000079a3731d568c  vmovaps [rsp+0x10], xmm2
000079a3731d5692  vmovaps [rsp+0x20], xmm3
000079a3731d5698  vmovaps [rsp+0x30], xmm4
000079a3731d569e  vmovaps [rsp+0x40], xmm5
000079a3731d56a4  vmovaps [rsp+0x50], xmm6
000079a3731d56aa  vmovaps [rsp+0x60], xmm7
000079a3731d56b0  vmovaps [rsp+0x70], xmm8
000079a3731d56b6  vmovaps [rsp+0x80], xmm9
000079a3731d56bf  vmovaps [rsp+0x90], xmm10
000079a3731d56c8  vmovaps [rsp+0xA0], xmm11
000079a3731d56d1  vmovaps [rsp+0xB0], xmm12
000079a3731d56da  vmovaps [rsp+0xC0], xmm13
000079a3731d56e3  vmovaps [rsp+0xD0], xmm14
000079a3731d56ec  vmovaps [rsp+0xE0], xmm15
000079a3731d56f5  sub rsp, 0x30
000079a3731d56f9  movaps [rsp], xmm1
000079a3731d56fd  movaps [rsp+0x10], xmm7
000079a3731d5702  movaps [rsp+0x20], xmm11
000079a3731d5708  lea rdi, [rsp]
000079a3731d570c  mov esi, 0x00
000079a3731d5711  mov rax, 0x64F127B95530
000079a3731d571b  call rax
000079a3731d571d  movaps xmm1, [rsp]
000079a3731d5721  add rsp, 0x30
000079a3731d5725  vmovaps xmm0, [rsp]
000079a3731d572a  vmovaps xmm2, [rsp+0x10]
000079a3731d5730  vmovaps xmm3, [rsp+0x20]
000079a3731d5736  vmovaps xmm4, [rsp+0x30]
000079a3731d573c  vmovaps xmm5, [rsp+0x40]
000079a3731d5742  vmovaps xmm6, [rsp+0x50]
000079a3731d5748  vmovaps xmm7, [rsp+0x60]
000079a3731d574e  vmovaps xmm8, [rsp+0x70]
000079a3731d5754  vmovaps xmm9, [rsp+0x80]
000079a3731d575d  vmovaps xmm10, [rsp+0x90]
000079a3731d5766  vmovaps xmm11, [rsp+0xA0]
000079a3731d576f  vmovaps xmm12, [rsp+0xB0]
000079a3731d5778  vmovaps xmm13, [rsp+0xC0]
000079a3731d5781  vmovaps xmm14, [rsp+0xD0]
000079a3731d578a  vmovaps xmm15, [rsp+0xE0]
000079a3731d5793  add rsp, 0xF0
000079a3731d579a  pop r11
000079a3731d579c  pop r10
000079a3731d579e  pop r9
000079a3731d57a0  pop r8
000079a3731d57a2  pop rsi
000079a3731d57a3  pop rdi
000079a3731d57a4  pop rdx
000079a3731d57a5  pop rcx
000079a3731d57a6  pop rax
000079a3731d57a7  add rsp, 0x08
000079a3731d57ab  jmp 0x000079A3731D033B
000079a3731d57b0  call 0x000079A37300E880
000079a3731d57b5  jmp 0x000079A3731D034E
000079a3731d57ba  call 0x000079A37300C380
000079a3731d57bf  jmp 0x000079A3731D0359
000079a3731d57c4  call 0x000079A37300D600
000079a3731d57c9  jmp 0x000079A3731D0364
000079a3731d57ce  call 0x000079A372FFF540
000079a3731d57d3  jmp 0x000079A3731D036F
000079a3731d57d8  int3
000079a3731d57d9  nop [rax], eax
000079a3731d57e0  mov rax, [r15+0x40]
000079a3731d57e4  mov r14, [r15+0x58]
000079a3731d57e8  lea r12, [rax+r14*1]
000079a3731d57ec  movaps xmm1, [r15+0x1D0]
000079a3731d57f4  vmovaps [rsp+0x10], xmm1
000079a3731d57fa  vmovaps xmm15, [rsp+0x10]
000079a3731d5800  por xmm1, xmm15
000079a3731d5805  movaps xmm14, [r15+0x1A0]
000079a3731d580d  vmovaps [rsp+0x10], xmm14
000079a3731d5813  vmovaps xmm13, [rsp+0x10]
000079a3731d5819  por xmm14, xmm13
000079a3731d581e  lea rax, [r12+0x30]
000079a3731d5823  mov r11, [r13+rax*1]
000079a3731d5828  lea rax, [r12+0x38]
000079a3731d582d  mov r10, [r13+rax*1]
000079a3731d5832  movq xmm13, r11
000079a3731d5837  movq xmm12, r10
000079a3731d583c  movq xmm13, xmm13
000079a3731d5841  vmovaps [rsp+0x10], xmm13
000079a3731d5847  movq xmm13, xmm13
000079a3731d584c  movaps [r15+0x130], xmm13
000079a3731d5854  movq xmm12, xmm12
000079a3731d5859  vmovaps [rsp+0x20], xmm12
000079a3731d585f  movq xmm12, xmm12
000079a3731d5864  movaps [r15+0x280], xmm12
000079a3731d586c  movaps xmm13, [r15+0x270]
000079a3731d5874  vmovaps [rsp+0x30], xmm13
000079a3731d587a  vmovaps xmm12, [rsp+0x30]
000079a3731d5880  por xmm13, xmm12
000079a3731d5885  lea rax, [r12+0x20]
000079a3731d588a  mov r11, [r13+rax*1]
000079a3731d588f  lea rax, [r12+0x28]
000079a3731d5894  mov r10, [r13+rax*1]
000079a3731d5899  movq xmm12, r11
000079a3731d589e  movq xmm11, r10
000079a3731d58a3  movq xmm12, xmm12
000079a3731d58a8  vmovaps [rsp+0x30], xmm12
000079a3731d58ae  movq xmm12, xmm12
000079a3731d58b3  movaps [r15+0x150], xmm12
000079a3731d58bb  movq xmm11, xmm11
000079a3731d58c0  vmovaps [rsp+0x40], xmm11
000079a3731d58c6  movq xmm11, xmm11
000079a3731d58cb  movaps [r15+0x140], xmm11
000079a3731d58d3  lea rax, [r12+0x10]
000079a3731d58d8  mov r11, [r13+rax*1]
000079a3731d58dd  lea rax, [r12+0x18]
000079a3731d58e2  mov r10, [r13+rax*1]
000079a3731d58e7  movq xmm12, r11
000079a3731d58ec  movq xmm11, r10
000079a3731d58f1  movq xmm12, xmm12
000079a3731d58f6  vmovaps [rsp+0x50], xmm12
000079a3731d58fc  movq xmm12, xmm12
000079a3731d5901  movaps [r15+0x170], xmm12
000079a3731d5909  movq xmm11, xmm11
000079a3731d590e  vmovaps [rsp+0x60], xmm11
000079a3731d5914  movq xmm11, xmm11
000079a3731d5919  movaps [r15+0x160], xmm11
000079a3731d5921  mov rax, [r13+r12*1]
000079a3731d5926  vmovq xmm12, rax
000079a3731d592b  vpbroadcastq xmm12, xmm12
000079a3731d5930  lea rax, [r12+0x08]
000079a3731d5935  mov r12, [r13+rax*1]
000079a3731d593a  movq xmm11, r12
000079a3731d593f  movaps [r15+0x230], xmm11
000079a3731d5947  mov rax, [r15+0xF8]
000079a3731d594e  lea r12, [rax+0x50]
000079a3731d5952  movups xmm11, [r13+r12*1]
000079a3731d5958  lea r12, [rax+0x60]
000079a3731d595c  movups xmm10, [r13+r12*1]
000079a3731d5962  lea r12, [rax+0x30]
000079a3731d5966  movups xmm9, [r13+r12*1]
000079a3731d596c  mov r12, [r15+0x50]
000079a3731d5970  lea r11, [r12+r14*1]
000079a3731d5974  mov [r15+0x60], r11
000079a3731d5978  lea r12, [r14+0x40]
000079a3731d597c  mov [r15+0x58], r12
000079a3731d5980  movaps xmm8, xmm12
000079a3731d5984  mulpd xmm8, xmm15
000079a3731d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000079a3731d598f  ptest xmm7, xmm7
000079a3731d5994  jnz 0x000079A3731D67B7
000079a3731d599a  movq xmm15, qword ptr [r15+0x230]
000079a3731d59a3  vmovaps [rsp+0x70], xmm15
000079a3731d59a9  vpermilpd xmm15, xmm15, 0x00
000079a3731d59af  movaps xmm7, xmm9
000079a3731d59b3  mulpd xmm7, xmm15
000079a3731d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000079a3731d59bd  ptest xmm6, xmm6
000079a3731d59c2  jnz 0x000079A3731D68FB
000079a3731d59c8  vxorps xmm15, xmm15, xmm15
000079a3731d59cd  vpbroadcastq xmm15, xmm15
000079a3731d59d2  movaps xmm9, xmm12
000079a3731d59d6  mulpd xmm9, xmm10
000079a3731d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000079a3731d59e1  ptest xmm6, xmm6
000079a3731d59e6  jnz 0x000079A3731D6A3D
000079a3731d59ec  movaps xmm10, xmm12
000079a3731d59f0  mulpd xmm10, xmm11
000079a3731d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000079a3731d59fb  ptest xmm6, xmm6
000079a3731d5a00  jnz 0x000079A3731D6B81
000079a3731d5a06  movaps xmm11, [r15+0x1F0]
000079a3731d5a0e  movaps xmm6, xmm12
000079a3731d5a12  mulpd xmm6, xmm11
000079a3731d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000079a3731d5a1c  ptest xmm5, xmm5
000079a3731d5a21  jnz 0x000079A3731D6CC5
000079a3731d5a27  movaps xmm12, [r15+0x2A0]
000079a3731d5a2f  vmovaps [rsp+0x80], xmm12
000079a3731d5a38  vmovaps xmm11, [rsp+0x80]
000079a3731d5a41  por xmm12, xmm11
000079a3731d5a46  movaps xmm11, [r15+0x250]
000079a3731d5a4e  vmovaps [rsp+0x80], xmm11
000079a3731d5a57  vmovaps xmm5, [rsp+0x80]
000079a3731d5a60  por xmm11, xmm5
000079a3731d5a65  vmovaps xmm4, [rsp+0x70]
000079a3731d5a6b  vpermilpd xmm4, xmm4, 0x00
000079a3731d5a71  movaps xmm3, xmm5
000079a3731d5a74  mulpd xmm3, xmm4
000079a3731d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000079a3731d5a7d  ptest xmm2, xmm2
000079a3731d5a82  jnz 0x000079A3731D6E07
000079a3731d5a88  mov [rsp+0x80], rax
000079a3731d5a90  xor eax, eax
000079a3731d5a92  mov r14d, 0x200
000079a3731d5a98  cmp r12, r14
000079a3731d5a9b  cmc
000079a3731d5a9c  lahf
000079a3731d5a9d  seto al
000079a3731d5aa0  mov [r15+0x108], eax
000079a3731d5aa7  movaps xmm5, xmm8
000079a3731d5aab  addpd xmm5, xmm15
000079a3731d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000079a3731d5ab5  ptest xmm4, xmm4
000079a3731d5aba  jnz 0x000079A3731D6F47
000079a3731d5ac0  movaps xmm8, [r15+0x1B0]
000079a3731d5ac8  movaps xmm4, xmm9
000079a3731d5acc  addpd xmm4, xmm8
000079a3731d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000079a3731d5ad6  ptest xmm2, xmm2
000079a3731d5adb  jnz 0x000079A3731D7089
000079a3731d5ae1  movaps xmm9, xmm10
000079a3731d5ae5  addpd xmm9, xmm8
000079a3731d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000079a3731d5af0  ptest xmm2, xmm2
000079a3731d5af5  jnz 0x000079A3731D71CB
000079a3731d5afb  movaps xmm10, [r15+0x2F0]
000079a3731d5b03  vmovaps [rsp+0x90], xmm10
000079a3731d5b0c  vmovaps xmm8, [rsp+0x90]
000079a3731d5b15  por xmm10, xmm8
000079a3731d5b1a  movaps xmm8, [r15+0x2E0]
000079a3731d5b22  vmovaps [rsp+0x90], xmm8
000079a3731d5b2b  vmovaps xmm2, [rsp+0x90]
000079a3731d5b34  por xmm8, xmm2
000079a3731d5b39  movaps xmm2, [r15+0x2D0]
000079a3731d5b41  vmovaps [rsp+0x90], xmm2
000079a3731d5b4a  vmovaps [rsp+0xA0], xmm1
000079a3731d5b53  vmovaps xmm1, [rsp+0x90]
000079a3731d5b5c  por xmm2, xmm1
000079a3731d5b60  movaps xmm1, [r15+0x200]
000079a3731d5b68  vmovaps [rsp+0x90], xmm1
000079a3731d5b71  vmovaps [rsp+0xB0], xmm15
000079a3731d5b7a  vmovaps xmm15, [rsp+0x90]
000079a3731d5b83  por xmm1, xmm15
000079a3731d5b88  movaps xmm15, [r15+0x1C0]
000079a3731d5b90  vmovaps [rsp+0x90], xmm15
000079a3731d5b99  vmovaps [rsp+0xC0], xmm1
000079a3731d5ba2  vmovaps xmm1, [rsp+0x90]
000079a3731d5bab  por xmm15, xmm1
000079a3731d5bb0  movaps xmm1, [r15+0x190]
000079a3731d5bb8  vmovaps [rsp+0x90], xmm1
000079a3731d5bc1  vmovaps [rsp+0xD0], xmm15
000079a3731d5bca  vmovaps xmm15, [rsp+0x90]
000079a3731d5bd3  por xmm1, xmm15
000079a3731d5bd8  movaps xmm15, [r15+0x300]
000079a3731d5be0  vmovaps [rsp+0x90], xmm15
000079a3731d5be9  vmovaps [rsp+0xE0], xmm1
000079a3731d5bf2  vmovaps xmm1, [rsp+0x90]
000079a3731d5bfb  por xmm15, xmm1
000079a3731d5c00  mov rax, [rsp+0x80]
000079a3731d5c08  lea r14, [rax+0xA0]
000079a3731d5c0f  movups xmm1, [r13+r14*1]
000079a3731d5c15  lea r14, [rax+0xB0]
000079a3731d5c1c  vmovaps [rsp+0x80], xmm1
000079a3731d5c25  movups xmm1, [r13+r14*1]
000079a3731d5c2b  vmovaps [rsp+0x90], xmm1
000079a3731d5c34  vmovaps [rsp+0xF0], xmm15
000079a3731d5c3d  vmovaps xmm15, [rsp+0xB0]
000079a3731d5c46  vmovaps [rsp+0xB0], xmm14
000079a3731d5c4f  movaps xmm1, xmm6
000079a3731d5c52  addpd xmm1, xmm15
000079a3731d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000079a3731d5c5c  ptest xmm14, xmm14
000079a3731d5c62  jnz 0x000079A3731D7323
000079a3731d5c68  lea r14, [rax+0xF0]
000079a3731d5c6f  movups xmm15, [r13+r14*1]
000079a3731d5c75  movaps xmm14, xmm4
000079a3731d5c79  addpd xmm14, xmm3
000079a3731d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000079a3731d5c84  ptest xmm6, xmm6
000079a3731d5c89  jnz 0x000079A3731D746E
000079a3731d5c8f  movaps xmm6, xmm9
000079a3731d5c93  addpd xmm6, xmm7
000079a3731d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000079a3731d5c9c  ptest xmm4, xmm4
000079a3731d5ca1  jnz 0x000079A3731D75B0
000079a3731d5ca7  vmovaps xmm9, [rsp+0x70]
000079a3731d5cad  vpermilpd xmm9, xmm9, 0x00
000079a3731d5cb3  vmovaps xmm4, [rsp+0x90]
000079a3731d5cbc  movaps xmm7, xmm4
000079a3731d5cbf  mulpd xmm7, xmm9
000079a3731d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000079a3731d5cc9  ptest xmm3, xmm3
000079a3731d5cce  jnz 0x000079A3731D76F1
000079a3731d5cd4  vmovaps xmm9, [rsp+0x50]
000079a3731d5cda  vpermilpd xmm9, xmm9, 0x00
000079a3731d5ce0  movaps xmm4, xmm15
000079a3731d5ce4  mulpd xmm4, xmm9
000079a3731d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000079a3731d5cee  ptest xmm3, xmm3
000079a3731d5cf3  jnz 0x000079A3731D7832
000079a3731d5cf9  lea r14, [rax+0xE0]
000079a3731d5d00  movups xmm15, [r13+r14*1]
000079a3731d5d06  vmovaps xmm9, [rsp+0x70]
000079a3731d5d0c  vpermilpd xmm9, xmm9, 0x00
000079a3731d5d12  vmovaps [rsp+0x70], xmm1
000079a3731d5d18  vmovaps xmm1, [rsp+0x80]
000079a3731d5d21  vmovaps [rsp+0x80], xmm15
000079a3731d5d2a  movaps xmm3, xmm1
000079a3731d5d2d  mulpd xmm3, xmm9
000079a3731d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000079a3731d5d37  ptest xmm15, xmm15
000079a3731d5d3d  jnz 0x000079A3731D797E
000079a3731d5d43  vmovaps xmm1, [rsp+0xF0]
000079a3731d5d4c  vmovaps xmm15, [rsp+0xF0]
000079a3731d5d55  por xmm1, xmm15
000079a3731d5d5a  movaps [r15+0x300], xmm1
000079a3731d5d62  vmovaps xmm15, [rsp+0xE0]
000079a3731d5d6b  vmovaps xmm9, [rsp+0xE0]
000079a3731d5d74  por xmm15, xmm9
000079a3731d5d79  movaps [r15+0x190], xmm15
000079a3731d5d81  vmovaps xmm9, [rsp+0x50]
000079a3731d5d87  vpermilpd xmm9, xmm9, 0x00
000079a3731d5d8d  vmovaps [rsp+0x90], xmm1
000079a3731d5d96  vmovaps [rsp+0xE0], xmm15
000079a3731d5d9f  vmovaps xmm15, [rsp+0x80]
000079a3731d5da8  vmovaps [rsp+0x80], xmm14
000079a3731d5db1  movaps xmm1, xmm15
000079a3731d5db5  mulpd xmm1, xmm9
000079a3731d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000079a3731d5dbf  ptest xmm14, xmm14
000079a3731d5dc5  jnz 0x000079A3731D7ABF
000079a3731d5dcb  lea r14, [rax+0x90]
000079a3731d5dd2  movups xmm15, [r13+r14*1]
000079a3731d5dd8  vmovaps xmm14, [rsp+0xD0]
000079a3731d5de1  vmovaps xmm9, [rsp+0xD0]
000079a3731d5dea  por xmm14, xmm9
000079a3731d5def  movaps [r15+0x1C0], xmm14
000079a3731d5df7  vmovaps xmm9, [rsp+0xC0]
000079a3731d5e00  vmovaps [rsp+0xD0], xmm1
000079a3731d5e09  vmovaps xmm1, [rsp+0xC0]
000079a3731d5e12  por xmm9, xmm1
000079a3731d5e17  movaps [r15+0x200], xmm9
000079a3731d5e1f  vmovaps [rsp+0xC0], xmm2
000079a3731d5e28  vmovaps xmm1, [rsp+0xC0]
000079a3731d5e31  por xmm2, xmm1
000079a3731d5e35  movaps [r15+0x2D0], xmm2
000079a3731d5e3d  vmovaps [rsp+0xC0], xmm8
000079a3731d5e46  vmovaps xmm1, [rsp+0xC0]
000079a3731d5e4f  por xmm8, xmm1
000079a3731d5e54  movaps [r15+0x2E0], xmm8
000079a3731d5e5c  vmovaps [rsp+0xC0], xmm15
000079a3731d5e65  movaps xmm1, xmm5
000079a3731d5e68  addpd xmm1, xmm7
000079a3731d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000079a3731d5e71  ptest xmm15, xmm15
000079a3731d5e77  jnz 0x000079A3731D7C0B
000079a3731d5e7d  vmovaps xmm15, [rsp+0x50]
000079a3731d5e83  vpermilpd xmm15, xmm15, 0x00
000079a3731d5e89  vmovaps xmm5, [rsp+0xC0]
000079a3731d5e92  vmovaps [rsp+0xC0], xmm1
000079a3731d5e9b  movaps xmm7, xmm5
000079a3731d5e9e  mulpd xmm7, xmm15
000079a3731d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000079a3731d5ea8  ptest xmm1, xmm1
000079a3731d5ead  jnz 0x000079A3731D7D4B
000079a3731d5eb3  lea r14, [rax+0x80]
000079a3731d5eba  movups xmm1, [r13+r14*1]
000079a3731d5ec0  vmovaps xmm5, [rsp+0x70]
000079a3731d5ec6  vmovaps [rsp+0x70], xmm1
000079a3731d5ecc  movaps xmm15, xmm5
000079a3731d5ed0  addpd xmm15, xmm3
000079a3731d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000079a3731d5edb  ptest xmm1, xmm1
000079a3731d5ee0  jnz 0x000079A3731D7E96
000079a3731d5ee6  vmovaps xmm5, [rsp+0x80]
000079a3731d5eef  movaps xmm1, xmm5
000079a3731d5ef2  addpd xmm1, xmm4
000079a3731d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000079a3731d5efb  ptest xmm3, xmm3
000079a3731d5f00  jnz 0x000079A3731D7FD8
000079a3731d5f06  vmovaps [rsp+0x80], xmm10
000079a3731d5f0f  vmovaps xmm5, [rsp+0x80]
000079a3731d5f18  por xmm10, xmm5
000079a3731d5f1d  movaps [r15+0x2F0], xmm10
000079a3731d5f25  vmovaps xmm5, [rsp+0x50]
000079a3731d5f2b  vpermilpd xmm5, xmm5, 0x00
000079a3731d5f31  vmovaps xmm3, [rsp+0x70]
000079a3731d5f37  vmovaps [rsp+0x50], xmm1
000079a3731d5f3d  movaps xmm4, xmm3
000079a3731d5f40  mulpd xmm4, xmm5
000079a3731d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000079a3731d5f49  ptest xmm1, xmm1
000079a3731d5f4e  jnz 0x000079A3731D8118
000079a3731d5f54  lea r14, [rax+0xD0]
000079a3731d5f5b  movups xmm1, [r13+r14*1]
000079a3731d5f61  vmovaps xmm3, [rsp+0xD0]
000079a3731d5f6a  vmovaps [rsp+0x70], xmm1
000079a3731d5f70  movaps xmm5, xmm6
000079a3731d5f73  addpd xmm5, xmm3
000079a3731d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000079a3731d5f7c  ptest xmm1, xmm1
000079a3731d5f81  jnz 0x000079A3731D8262
000079a3731d5f87  vmovaps xmm1, [rsp+0x60]
000079a3731d5f8d  vpermilpd xmm1, xmm1, 0x00
000079a3731d5f93  movaps xmm6, xmm9
000079a3731d5f97  mulpd xmm6, xmm1
000079a3731d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000079a3731d5fa0  ptest xmm3, xmm3
000079a3731d5fa5  jnz 0x000079A3731D83A2
000079a3731d5fab  movaps [r15+0x260], xmm6
000079a3731d5fb3  vxorps xmm1, xmm1, xmm1
000079a3731d5fb7  vpbroadcastq xmm1, xmm1
000079a3731d5fbc  movaps [r15+0x1B0], xmm1
000079a3731d5fc4  vmovaps xmm1, [rsp+0x60]
000079a3731d5fca  vpermilpd xmm1, xmm1, 0x00
000079a3731d5fd0  vmovaps xmm3, [rsp+0x70]
000079a3731d5fd6  vmovaps [rsp+0x70], xmm15
000079a3731d5fdc  movaps xmm9, xmm3
000079a3731d5fe0  mulpd xmm9, xmm1
000079a3731d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000079a3731d5feb  ptest xmm15, xmm15
000079a3731d5ff1  jnz 0x000079A3731D84E3
000079a3731d5ff7  lea r14, [rax+0xC0]
000079a3731d5ffe  movups xmm1, [r13+r14*1]
000079a3731d6004  vmovaps xmm3, [rsp+0xC0]
000079a3731d600d  vmovaps [rsp+0x80], xmm1
000079a3731d6016  movaps xmm15, xmm3
000079a3731d601a  addpd xmm15, xmm7
000079a3731d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000079a3731d6025  ptest xmm1, xmm1
000079a3731d602a  jnz 0x000079A3731D862F
000079a3731d6030  vmovaps [rsp+0xC0], xmm13
000079a3731d6039  vmovaps xmm1, [rsp+0xC0]
000079a3731d6042  por xmm13, xmm1
000079a3731d6047  movaps [r15+0x270], xmm13
000079a3731d604f  vmovaps xmm1, [rsp+0xB0]
000079a3731d6058  vmovaps xmm7, [rsp+0xB0]
000079a3731d6061  por xmm1, xmm7
000079a3731d6065  movaps [r15+0x1A0], xmm1
000079a3731d606d  vmovaps xmm1, [rsp+0x60]
000079a3731d6073  vpermilpd xmm1, xmm1, 0x00
000079a3731d6079  vmovaps [rsp+0xB0], xmm1
000079a3731d6082  vmovaps xmm1, [rsp+0x80]
000079a3731d608b  vmovaps [rsp+0x80], xmm15
000079a3731d6094  vmovaps xmm15, [rsp+0xB0]
000079a3731d609d  vmovaps [rsp+0xB0], xmm14
000079a3731d60a6  movaps xmm3, xmm1
000079a3731d60a9  mulpd xmm3, xmm15
000079a3731d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000079a3731d60b3  ptest xmm14, xmm14
000079a3731d60b9  jnz 0x000079A3731D8771
000079a3731d60bf  lea r14, [rax+0x20]
000079a3731d60c3  movups xmm1, [r13+r14*1]
000079a3731d60c9  movaps [r15+0x110], xmm1
000079a3731d60d1  vmovaps xmm14, [rsp+0x70]
000079a3731d60d7  vmovaps [rsp+0x70], xmm1
000079a3731d60dd  movaps xmm15, xmm14
000079a3731d60e1  addpd xmm15, xmm4
000079a3731d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000079a3731d60ec  ptest xmm1, xmm1
000079a3731d60f1  jnz 0x000079A3731D88BC
000079a3731d60f7  vmovaps xmm1, [rsp+0x60]
000079a3731d60fd  vpermilpd xmm1, xmm1, 0x00
000079a3731d6103  movaps xmm14, xmm2
000079a3731d6107  mulpd xmm14, xmm1
000079a3731d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000079a3731d6112  ptest xmm4, xmm4
000079a3731d6117  jnz 0x000079A3731D89FF
000079a3731d611d  vmovaps xmm4, [rsp+0x50]
000079a3731d6123  movaps xmm1, xmm4
000079a3731d6126  addpd xmm1, xmm9
000079a3731d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000079a3731d6130  ptest xmm2, xmm2
000079a3731d6135  jnz 0x000079A3731D8B41
000079a3731d613b  vmovaps xmm9, [rsp+0x30]
000079a3731d6141  vpermilpd xmm9, xmm9, 0x00
000079a3731d6147  vmovaps xmm2, [rsp+0x70]
000079a3731d614d  vmovaps [rsp+0x50], xmm1
000079a3731d6153  movaps xmm4, xmm2
000079a3731d6156  mulpd xmm4, xmm9
000079a3731d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000079a3731d6160  ptest xmm1, xmm1
000079a3731d6165  jnz 0x000079A3731D8C82
000079a3731d616b  vmovaps xmm1, [rsp+0x30]
000079a3731d6171  vpermilpd xmm1, xmm1, 0x00
000079a3731d6177  vmovaps xmm2, [rsp+0x90]
000079a3731d6180  vmovaps [rsp+0x60], xmm15
000079a3731d6186  movaps xmm9, xmm2
000079a3731d618a  mulpd xmm9, xmm1
000079a3731d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000079a3731d6195  ptest xmm15, xmm15
000079a3731d619b  jnz 0x000079A3731D8DC3
000079a3731d61a1  vmovaps xmm15, [rsp+0x80]
000079a3731d61aa  movaps xmm1, xmm15
000079a3731d61ae  addpd xmm1, xmm6
000079a3731d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000079a3731d61b7  ptest xmm2, xmm2
000079a3731d61bc  jnz 0x000079A3731D8F05
000079a3731d61c2  movaps xmm15, xmm5
000079a3731d61c6  addpd xmm15, xmm3
000079a3731d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000079a3731d61d1  ptest xmm6, xmm6
000079a3731d61d6  jnz 0x000079A3731D9046
000079a3731d61dc  vmovaps xmm6, [rsp+0x30]
000079a3731d61e2  vpermilpd xmm6, xmm6, 0x00
000079a3731d61e8  movaps xmm5, xmm8
000079a3731d61ec  mulpd xmm5, xmm6
000079a3731d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000079a3731d61f5  ptest xmm3, xmm3
000079a3731d61fa  jnz 0x000079A3731D9188
000079a3731d6200  vmovaps xmm8, [rsp+0x30]
000079a3731d6206  vpermilpd xmm8, xmm8, 0x00
000079a3731d620c  movaps xmm6, xmm10
000079a3731d6210  mulpd xmm6, xmm8
000079a3731d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000079a3731d621a  ptest xmm3, xmm3
000079a3731d621f  jnz 0x000079A3731D92C9
000079a3731d6225  vmovaps xmm8, [rsp+0x60]
000079a3731d622b  movaps xmm10, xmm8
000079a3731d622f  addpd xmm10, xmm14
000079a3731d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000079a3731d623a  ptest xmm3, xmm3
000079a3731d623f  jnz 0x000079A3731D940B
000079a3731d6245  vmovaps xmm8, [rsp+0x50]
000079a3731d624b  movaps xmm14, xmm8
000079a3731d624f  addpd xmm14, xmm4
000079a3731d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000079a3731d625a  ptest xmm3, xmm3
000079a3731d625f  jnz 0x000079A3731D954F
000079a3731d6265  vmovaps xmm8, [rsp+0x40]
000079a3731d626b  vpermilpd xmm8, xmm8, 0x00
000079a3731d6271  movaps xmm4, xmm13
000079a3731d6275  mulpd xmm4, xmm8
000079a3731d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000079a3731d627f  ptest xmm3, xmm3
000079a3731d6284  jnz 0x000079A3731D9692
000079a3731d628a  movaps xmm13, xmm15
000079a3731d628e  addpd xmm13, xmm9
000079a3731d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000079a3731d6299  ptest xmm8, xmm8
000079a3731d629f  jnz 0x000079A3731D97D4
000079a3731d62a5  movaps xmm15, xmm1
000079a3731d62a9  addpd xmm15, xmm5
000079a3731d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000079a3731d62b4  ptest xmm9, xmm9
000079a3731d62ba  jnz 0x000079A3731D9918
000079a3731d62c0  vmovaps [rsp+0x30], xmm11
000079a3731d62c6  vmovaps xmm1, [rsp+0x30]
000079a3731d62cc  por xmm11, xmm1
000079a3731d62d1  movaps [r15+0x250], xmm11
000079a3731d62d9  vmovaps [rsp+0x30], xmm12
000079a3731d62df  vmovaps xmm1, [rsp+0x30]
000079a3731d62e5  por xmm12, xmm1
000079a3731d62ea  movaps [r15+0x2A0], xmm12
000079a3731d62f2  vmovaps xmm1, [rsp+0xA0]
000079a3731d62fb  vmovaps xmm11, [rsp+0xA0]
000079a3731d6304  por xmm1, xmm11
000079a3731d6309  movaps [r15+0x1D0], xmm1
000079a3731d6311  lea r14, [rax+0x40]
000079a3731d6315  movups xmm1, [r13+r14*1]
000079a3731d631b  movaps [r15+0x2C0], xmm1
000079a3731d6323  vmovaps xmm11, [rsp+0x40]
000079a3731d6329  vpermilpd xmm11, xmm11, 0x00
000079a3731d632f  vmovaps xmm8, [rsp+0xE0]
000079a3731d6338  movaps xmm9, xmm8
000079a3731d633c  mulpd xmm9, xmm11
000079a3731d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000079a3731d6347  ptest xmm5, xmm5
000079a3731d634c  jnz 0x000079A3731D9A64
000079a3731d6352  movaps xmm11, xmm10
000079a3731d6356  addpd xmm11, xmm6
000079a3731d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000079a3731d6361  ptest xmm8, xmm8
000079a3731d6367  jnz 0x000079A3731D9BA8
000079a3731d636d  movaps xmm10, xmm14
000079a3731d6371  addpd xmm10, xmm4
000079a3731d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000079a3731d637c  ptest xmm8, xmm8
000079a3731d6382  jnz 0x000079A3731D9CEB
000079a3731d6388  vmovaps xmm14, [rsp+0x40]
000079a3731d638e  vpermilpd xmm14, xmm14, 0x00
000079a3731d6394  movaps xmm8, xmm1
000079a3731d6398  mulpd xmm8, xmm14
000079a3731d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000079a3731d63a3  ptest xmm6, xmm6
000079a3731d63a8  jnz 0x000079A3731D9E2E
000079a3731d63ae  movaps xmm1, [r15+0x2B0]
000079a3731d63b6  vmovaps xmm14, [rsp+0x40]
000079a3731d63bc  vpermilpd xmm14, xmm14, 0x00
000079a3731d63c2  movaps xmm6, xmm1
000079a3731d63c5  mulpd xmm6, xmm14
000079a3731d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000079a3731d63cf  ptest xmm5, xmm5
000079a3731d63d4  jnz 0x000079A3731D9F71
000079a3731d63da  vmovaps xmm1, [rsp+0x10]
000079a3731d63e0  vpermilpd xmm1, xmm1, 0x00
000079a3731d63e6  movaps xmm14, xmm12
000079a3731d63ea  mulpd xmm14, xmm1
000079a3731d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000079a3731d63f5  ptest xmm5, xmm5
000079a3731d63fa  jnz 0x000079A3731DA0B2
000079a3731d6400  movaps xmm1, xmm13
000079a3731d6404  addpd xmm1, xmm9
000079a3731d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000079a3731d640e  ptest xmm12, xmm12
000079a3731d6414  jnz 0x000079A3731DA1F5
000079a3731d641a  vmovaps xmm13, [rsp+0x10]
000079a3731d6420  vpermilpd xmm13, xmm13, 0x00
000079a3731d6426  movaps xmm12, xmm7
000079a3731d642a  mulpd xmm12, xmm13
000079a3731d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000079a3731d6435  ptest xmm9, xmm9
000079a3731d643b  jnz 0x000079A3731DA337
000079a3731d6441  movaps xmm13, xmm15
000079a3731d6445  addpd xmm13, xmm8
000079a3731d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000079a3731d6450  ptest xmm9, xmm9
000079a3731d6456  jnz 0x000079A3731DA47A
000079a3731d645c  movaps xmm15, [r15+0x290]
000079a3731d6464  vmovaps xmm9, [rsp+0x10]
000079a3731d646a  vpermilpd xmm9, xmm9, 0x00
000079a3731d6470  movaps xmm8, xmm15
000079a3731d6474  mulpd xmm8, xmm9
000079a3731d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000079a3731d647f  ptest xmm7, xmm7
000079a3731d6484  jnz 0x000079A3731DA5BE
000079a3731d648a  movaps xmm15, xmm11
000079a3731d648e  addpd xmm15, xmm6
000079a3731d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000079a3731d6499  ptest xmm9, xmm9
000079a3731d649f  jnz 0x000079A3731DA702
000079a3731d64a5  movaps xmm11, [r15+0x1E0]
000079a3731d64ad  vmovaps xmm9, [rsp+0x10]
000079a3731d64b3  vpermilpd xmm9, xmm9, 0x00
000079a3731d64b9  movaps xmm7, xmm11
000079a3731d64bd  mulpd xmm7, xmm9
000079a3731d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000079a3731d64c7  ptest xmm6, xmm6
000079a3731d64cc  jnz 0x000079A3731DA845
000079a3731d64d2  movaps xmm11, xmm10
000079a3731d64d6  addpd xmm11, xmm14
000079a3731d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000079a3731d64e1  ptest xmm9, xmm9
000079a3731d64e7  jnz 0x000079A3731DA987
000079a3731d64ed  lea r14, [rax+0x70]
000079a3731d64f1  movups xmm14, [r13+r14*1]
000079a3731d64f7  movaps [r15+0x240], xmm14
000079a3731d64ff  movaps xmm10, xmm1
000079a3731d6503  addpd xmm10, xmm12
000079a3731d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000079a3731d650e  ptest xmm9, xmm9
000079a3731d6514  jnz 0x000079A3731DAAD5
000079a3731d651a  movaps [r15+0x170], xmm10
000079a3731d6522  vmovaps xmm1, [rsp+0x20]
000079a3731d6528  vpermilpd xmm1, xmm1, 0x00
000079a3731d652e  movaps xmm12, xmm14
000079a3731d6532  mulpd xmm12, xmm1
000079a3731d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000079a3731d653d  ptest xmm9, xmm9
000079a3731d6543  jnz 0x000079A3731DAC18
000079a3731d6549  vmovaps xmm1, [rsp+0x20]
000079a3731d654f  vpermilpd xmm1, xmm1, 0x00
000079a3731d6555  vmovaps xmm9, [rsp+0xB0]
000079a3731d655e  movaps xmm14, xmm9
000079a3731d6562  mulpd xmm14, xmm1
000079a3731d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000079a3731d656d  ptest xmm6, xmm6
000079a3731d6572  jnz 0x000079A3731DAD5B
000079a3731d6578  movaps [r15+0x180], xmm14
000079a3731d6580  movaps xmm1, xmm13
000079a3731d6584  addpd xmm1, xmm8
000079a3731d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000079a3731d658e  ptest xmm9, xmm9
000079a3731d6594  jnz 0x000079A3731DAE9E
000079a3731d659a  movaps [r15+0x210], xmm1
000079a3731d65a2  movups xmm13, [r13+rax*1]
000079a3731d65a8  lea r14, [rax+0x10]
000079a3731d65ac  movups xmm9, [r13+r14*1]
000079a3731d65b2  movaps [r15+0x230], xmm9
000079a3731d65ba  movaps xmm8, xmm15
000079a3731d65be  addpd xmm8, xmm7
000079a3731d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000079a3731d65c9  ptest xmm6, xmm6
000079a3731d65ce  jnz 0x000079A3731DAFF4
000079a3731d65d4  movaps [r15+0x130], xmm8
000079a3731d65dc  vmovaps xmm15, [rsp+0x20]
000079a3731d65e2  vpermilpd xmm15, xmm15, 0x00
000079a3731d65e8  movaps xmm7, xmm9
000079a3731d65ec  mulpd xmm7, xmm15
000079a3731d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000079a3731d65f6  ptest xmm6, xmm6
000079a3731d65fb  jnz 0x000079A3731DB137
000079a3731d6601  movaps [r15+0x220], xmm7
000079a3731d6609  vmovaps xmm15, [rsp+0x20]
000079a3731d660f  vpermilpd xmm15, xmm15, 0x00
000079a3731d6615  movaps xmm9, xmm13
000079a3731d6619  mulpd xmm9, xmm15
000079a3731d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000079a3731d6624  ptest xmm6, xmm6
000079a3731d6629  jnz 0x000079A3731DB279
000079a3731d662f  movaps xmm15, xmm11
000079a3731d6633  addpd xmm15, xmm12
000079a3731d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000079a3731d663e  ptest xmm13, xmm13
000079a3731d6644  jnz 0x000079A3731DB3BD
000079a3731d664a  movaps [r15+0x140], xmm15
000079a3731d6652  movaps xmm13, xmm10
000079a3731d6656  addpd xmm13, xmm14
000079a3731d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000079a3731d6661  ptest xmm12, xmm12
000079a3731d6667  jnz 0x000079A3731DB501
000079a3731d666d  movaps [r15+0x150], xmm13
000079a3731d6675  movaps xmm14, xmm1
000079a3731d6679  addpd xmm14, xmm7
000079a3731d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000079a3731d6684  ptest xmm12, xmm12
000079a3731d668a  jnz 0x000079A3731DB645
000079a3731d6690  movaps [r15+0x160], xmm14
000079a3731d6698  movaps xmm1, xmm8
000079a3731d669c  addpd xmm1, xmm9
000079a3731d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000079a3731d66a6  ptest xmm12, xmm12
000079a3731d66ac  jnz 0x000079A3731DB787
000079a3731d66b2  movaps [r15+0x120], xmm1
000079a3731d66ba  movups [r13+r11*1], xmm15
000079a3731d66c0  lea rax, [r11+0x10]
000079a3731d66c4  movups [r13+rax*1], xmm13
000079a3731d66ca  lea rax, [r11+0x20]
000079a3731d66ce  movups [r13+rax*1], xmm14
000079a3731d66d4  lea rax, [r11+0x30]
000079a3731d66d8  movups [r13+rax*1], xmm1
000079a3731d66de  mov eax, [r15+0x108]
000079a3731d66e5  sahf
000079a3731d66e6  jnz 0x000079A3731D6718
000079a3731d66e8  cmp dword ptr [r15+0x318], 0x00
000079a3731d66f0  jz 0x000079A3731DB900
000079a3731d66f6  nop [rax+rax*1], ax
000079a3731d66ff  nop [rax+rax*1], eax
000079a3731d6707  mov eax, 0x410444
000079a3731d670c  mov [r15+0x100], rax
000079a3731d6713  jmp 0x000079A372FFE110
000079a3731d6718  cmp dword ptr [r15+0x318], 0x00
000079a3731d6720  jz 0x000079A3731D57E0
000079a3731d6726  nop [rax+rax*1], ax
000079a3731d672f  nop [rax+rax*1], eax
000079a3731d6737  mov eax, 0x410278
000079a3731d673c  mov [r15+0x100], rax
000079a3731d6743  jmp 0x000079A372FFE110
000079a3731d6748  int3
000079a3731d6749  call 0x000079A37300A4B0
000079a3731d674e  jmp 0x000079A3731D5828
000079a3731d6753  call 0x000079A373009240
000079a3731d6758  jmp 0x000079A3731D5832
000079a3731d675d  call 0x000079A37300A4B0
000079a3731d6762  jmp 0x000079A3731D588F
000079a3731d6767  call 0x000079A373009240
000079a3731d676c  jmp 0x000079A3731D5899
000079a3731d6771  call 0x000079A37300A4B0
000079a3731d6776  jmp 0x000079A3731D58DD
000079a3731d677b  call 0x000079A373009240
000079a3731d6780  jmp 0x000079A3731D58E7
000079a3731d6785  call 0x000079A3730B47C0
000079a3731d678a  jmp 0x000079A3731D5926
000079a3731d678f  call 0x000079A37300B720
000079a3731d6794  jmp 0x000079A3731D593A
000079a3731d6799  call 0x000079A3730BFC30
000079a3731d679e  jmp 0x000079A3731D5958
000079a3731d67a3  call 0x000079A3730BE9C0
000079a3731d67a8  jmp 0x000079A3731D5962
000079a3731d67ad  call 0x000079A3730BD750
000079a3731d67b2  jmp 0x000079A3731D596C
000079a3731d67b7  sub rsp, 0x08
000079a3731d67bb  push rax
000079a3731d67bc  push rcx
000079a3731d67bd  push rdx
000079a3731d67be  push rdi
000079a3731d67bf  push rsi
000079a3731d67c0  push r8
000079a3731d67c2  push r9
000079a3731d67c4  push r10
000079a3731d67c6  push r11
000079a3731d67c8  sub rsp, 0xF0
000079a3731d67cf  vmovaps [rsp], xmm0
000079a3731d67d4  vmovaps [rsp+0x10], xmm1
000079a3731d67da  vmovaps [rsp+0x20], xmm2
000079a3731d67e0  vmovaps [rsp+0x30], xmm3
000079a3731d67e6  vmovaps [rsp+0x40], xmm4
000079a3731d67ec  vmovaps [rsp+0x50], xmm5
000079a3731d67f2  vmovaps [rsp+0x60], xmm6
000079a3731d67f8  vmovaps [rsp+0x70], xmm7
000079a3731d67fe  vmovaps [rsp+0x80], xmm9
000079a3731d6807  vmovaps [rsp+0x90], xmm10
000079a3731d6810  vmovaps [rsp+0xA0], xmm11
000079a3731d6819  vmovaps [rsp+0xB0], xmm12
000079a3731d6822  vmovaps [rsp+0xC0], xmm13
000079a3731d682b  vmovaps [rsp+0xD0], xmm14
000079a3731d6834  vmovaps [rsp+0xE0], xmm15
000079a3731d683d  sub rsp, 0x30
000079a3731d6841  movaps [rsp], xmm8
000079a3731d6846  movaps [rsp+0x10], xmm12
000079a3731d684c  movaps [rsp+0x20], xmm15
000079a3731d6852  lea rdi, [rsp]
000079a3731d6856  mov esi, 0x00
000079a3731d685b  mov rax, 0x64F127B95530
000079a3731d6865  call rax
000079a3731d6867  movaps xmm8, [rsp]
000079a3731d686c  add rsp, 0x30
000079a3731d6870  vmovaps xmm0, [rsp]
000079a3731d6875  vmovaps xmm1, [rsp+0x10]
000079a3731d687b  vmovaps xmm2, [rsp+0x20]
000079a3731d6881  vmovaps xmm3, [rsp+0x30]
000079a3731d6887  vmovaps xmm4, [rsp+0x40]
000079a3731d688d  vmovaps xmm5, [rsp+0x50]
000079a3731d6893  vmovaps xmm6, [rsp+0x60]
000079a3731d6899  vmovaps xmm7, [rsp+0x70]
000079a3731d689f  vmovaps xmm9, [rsp+0x80]
000079a3731d68a8  vmovaps xmm10, [rsp+0x90]
000079a3731d68b1  vmovaps xmm11, [rsp+0xA0]
000079a3731d68ba  vmovaps xmm12, [rsp+0xB0]
000079a3731d68c3  vmovaps xmm13, [rsp+0xC0]
000079a3731d68cc  vmovaps xmm14, [rsp+0xD0]
000079a3731d68d5  vmovaps xmm15, [rsp+0xE0]
000079a3731d68de  add rsp, 0xF0
000079a3731d68e5  pop r11
000079a3731d68e7  pop r10
000079a3731d68e9  pop r9
000079a3731d68eb  pop r8
000079a3731d68ed  pop rsi
000079a3731d68ee  pop rdi
000079a3731d68ef  pop rdx
000079a3731d68f0  pop rcx
000079a3731d68f1  pop rax
000079a3731d68f2  add rsp, 0x08
000079a3731d68f6  jmp 0x000079A3731D599A
000079a3731d68fb  sub rsp, 0x08
000079a3731d68ff  push rax
000079a3731d6900  push rcx
000079a3731d6901  push rdx
000079a3731d6902  push rdi
000079a3731d6903  push rsi
000079a3731d6904  push r8
000079a3731d6906  push r9
000079a3731d6908  push r10
000079a3731d690a  push r11
000079a3731d690c  sub rsp, 0xF0
000079a3731d6913  vmovaps [rsp], xmm0
000079a3731d6918  vmovaps [rsp+0x10], xmm1
000079a3731d691e  vmovaps [rsp+0x20], xmm2
000079a3731d6924  vmovaps [rsp+0x30], xmm3
000079a3731d692a  vmovaps [rsp+0x40], xmm4
000079a3731d6930  vmovaps [rsp+0x50], xmm5
000079a3731d6936  vmovaps [rsp+0x60], xmm6
000079a3731d693c  vmovaps [rsp+0x70], xmm8
000079a3731d6942  vmovaps [rsp+0x80], xmm9
000079a3731d694b  vmovaps [rsp+0x90], xmm10
000079a3731d6954  vmovaps [rsp+0xA0], xmm11
000079a3731d695d  vmovaps [rsp+0xB0], xmm12
000079a3731d6966  vmovaps [rsp+0xC0], xmm13
000079a3731d696f  vmovaps [rsp+0xD0], xmm14
000079a3731d6978  vmovaps [rsp+0xE0], xmm15
000079a3731d6981  sub rsp, 0x30
000079a3731d6985  movaps [rsp], xmm7
000079a3731d6989  movaps [rsp+0x10], xmm9
000079a3731d698f  movaps [rsp+0x20], xmm15
000079a3731d6995  lea rdi, [rsp]
000079a3731d6999  mov esi, 0x00
000079a3731d699e  mov rax, 0x64F127B95530
000079a3731d69a8  call rax
000079a3731d69aa  movaps xmm7, [rsp]
000079a3731d69ae  add rsp, 0x30
000079a3731d69b2  vmovaps xmm0, [rsp]
000079a3731d69b7  vmovaps xmm1, [rsp+0x10]
000079a3731d69bd  vmovaps xmm2, [rsp+0x20]
000079a3731d69c3  vmovaps xmm3, [rsp+0x30]
000079a3731d69c9  vmovaps xmm4, [rsp+0x40]
000079a3731d69cf  vmovaps xmm5, [rsp+0x50]
000079a3731d69d5  vmovaps xmm6, [rsp+0x60]
000079a3731d69db  vmovaps xmm8, [rsp+0x70]
000079a3731d69e1  vmovaps xmm9, [rsp+0x80]
000079a3731d69ea  vmovaps xmm10, [rsp+0x90]
000079a3731d69f3  vmovaps xmm11, [rsp+0xA0]
000079a3731d69fc  vmovaps xmm12, [rsp+0xB0]
000079a3731d6a05  vmovaps xmm13, [rsp+0xC0]
000079a3731d6a0e  vmovaps xmm14, [rsp+0xD0]
000079a3731d6a17  vmovaps xmm15, [rsp+0xE0]
000079a3731d6a20  add rsp, 0xF0
000079a3731d6a27  pop r11
000079a3731d6a29  pop r10
000079a3731d6a2b  pop r9
000079a3731d6a2d  pop r8
000079a3731d6a2f  pop rsi
000079a3731d6a30  pop rdi
000079a3731d6a31  pop rdx
000079a3731d6a32  pop rcx
000079a3731d6a33  pop rax
000079a3731d6a34  add rsp, 0x08
000079a3731d6a38  jmp 0x000079A3731D59C8
000079a3731d6a3d  sub rsp, 0x08
000079a3731d6a41  push rax
000079a3731d6a42  push rcx
000079a3731d6a43  push rdx
000079a3731d6a44  push rdi
000079a3731d6a45  push rsi
000079a3731d6a46  push r8
000079a3731d6a48  push r9
000079a3731d6a4a  push r10
000079a3731d6a4c  push r11
000079a3731d6a4e  sub rsp, 0xF0
000079a3731d6a55  vmovaps [rsp], xmm0
000079a3731d6a5a  vmovaps [rsp+0x10], xmm1
000079a3731d6a60  vmovaps [rsp+0x20], xmm2
000079a3731d6a66  vmovaps [rsp+0x30], xmm3
000079a3731d6a6c  vmovaps [rsp+0x40], xmm4
000079a3731d6a72  vmovaps [rsp+0x50], xmm5
000079a3731d6a78  vmovaps [rsp+0x60], xmm6
000079a3731d6a7e  vmovaps [rsp+0x70], xmm7
000079a3731d6a84  vmovaps [rsp+0x80], xmm8
000079a3731d6a8d  vmovaps [rsp+0x90], xmm10
000079a3731d6a96  vmovaps [rsp+0xA0], xmm11
000079a3731d6a9f  vmovaps [rsp+0xB0], xmm12
000079a3731d6aa8  vmovaps [rsp+0xC0], xmm13
000079a3731d6ab1  vmovaps [rsp+0xD0], xmm14
000079a3731d6aba  vmovaps [rsp+0xE0], xmm15
000079a3731d6ac3  sub rsp, 0x30
000079a3731d6ac7  movaps [rsp], xmm9
000079a3731d6acc  movaps [rsp+0x10], xmm12
000079a3731d6ad2  movaps [rsp+0x20], xmm10
000079a3731d6ad8  lea rdi, [rsp]
000079a3731d6adc  mov esi, 0x00
000079a3731d6ae1  mov rax, 0x64F127B95530
000079a3731d6aeb  call rax
000079a3731d6aed  movaps xmm9, [rsp]
000079a3731d6af2  add rsp, 0x30
000079a3731d6af6  vmovaps xmm0, [rsp]
000079a3731d6afb  vmovaps xmm1, [rsp+0x10]
000079a3731d6b01  vmovaps xmm2, [rsp+0x20]
000079a3731d6b07  vmovaps xmm3, [rsp+0x30]
000079a3731d6b0d  vmovaps xmm4, [rsp+0x40]
000079a3731d6b13  vmovaps xmm5, [rsp+0x50]
000079a3731d6b19  vmovaps xmm6, [rsp+0x60]
000079a3731d6b1f  vmovaps xmm7, [rsp+0x70]
000079a3731d6b25  vmovaps xmm8, [rsp+0x80]
000079a3731d6b2e  vmovaps xmm10, [rsp+0x90]
000079a3731d6b37  vmovaps xmm11, [rsp+0xA0]
000079a3731d6b40  vmovaps xmm12, [rsp+0xB0]
000079a3731d6b49  vmovaps xmm13, [rsp+0xC0]
000079a3731d6b52  vmovaps xmm14, [rsp+0xD0]
000079a3731d6b5b  vmovaps xmm15, [rsp+0xE0]
000079a3731d6b64  add rsp, 0xF0
000079a3731d6b6b  pop r11
000079a3731d6b6d  pop r10
000079a3731d6b6f  pop r9
000079a3731d6b71  pop r8
000079a3731d6b73  pop rsi
000079a3731d6b74  pop rdi
000079a3731d6b75  pop rdx
000079a3731d6b76  pop rcx
000079a3731d6b77  pop rax
000079a3731d6b78  add rsp, 0x08
000079a3731d6b7c  jmp 0x000079A3731D59EC
000079a3731d6b81  sub rsp, 0x08
000079a3731d6b85  push rax
000079a3731d6b86  push rcx
000079a3731d6b87  push rdx
000079a3731d6b88  push rdi
000079a3731d6b89  push rsi
000079a3731d6b8a  push r8
000079a3731d6b8c  push r9
000079a3731d6b8e  push r10
000079a3731d6b90  push r11
000079a3731d6b92  sub rsp, 0xF0
000079a3731d6b99  vmovaps [rsp], xmm0
000079a3731d6b9e  vmovaps [rsp+0x10], xmm1
000079a3731d6ba4  vmovaps [rsp+0x20], xmm2
000079a3731d6baa  vmovaps [rsp+0x30], xmm3
000079a3731d6bb0  vmovaps [rsp+0x40], xmm4
000079a3731d6bb6  vmovaps [rsp+0x50], xmm5
000079a3731d6bbc  vmovaps [rsp+0x60], xmm6
000079a3731d6bc2  vmovaps [rsp+0x70], xmm7
000079a3731d6bc8  vmovaps [rsp+0x80], xmm8
000079a3731d6bd1  vmovaps [rsp+0x90], xmm9
000079a3731d6bda  vmovaps [rsp+0xA0], xmm11
000079a3731d6be3  vmovaps [rsp+0xB0], xmm12
000079a3731d6bec  vmovaps [rsp+0xC0], xmm13
000079a3731d6bf5  vmovaps [rsp+0xD0], xmm14
000079a3731d6bfe  vmovaps [rsp+0xE0], xmm15
000079a3731d6c07  sub rsp, 0x30
000079a3731d6c0b  movaps [rsp], xmm10
000079a3731d6c10  movaps [rsp+0x10], xmm12
000079a3731d6c16  movaps [rsp+0x20], xmm11
000079a3731d6c1c  lea rdi, [rsp]
000079a3731d6c20  mov esi, 0x00
000079a3731d6c25  mov rax, 0x64F127B95530
000079a3731d6c2f  call rax
000079a3731d6c31  movaps xmm10, [rsp]
000079a3731d6c36  add rsp, 0x30
000079a3731d6c3a  vmovaps xmm0, [rsp]
000079a3731d6c3f  vmovaps xmm1, [rsp+0x10]
000079a3731d6c45  vmovaps xmm2, [rsp+0x20]
000079a3731d6c4b  vmovaps xmm3, [rsp+0x30]
000079a3731d6c51  vmovaps xmm4, [rsp+0x40]
000079a3731d6c57  vmovaps xmm5, [rsp+0x50]
000079a3731d6c5d  vmovaps xmm6, [rsp+0x60]
000079a3731d6c63  vmovaps xmm7, [rsp+0x70]
000079a3731d6c69  vmovaps xmm8, [rsp+0x80]
000079a3731d6c72  vmovaps xmm9, [rsp+0x90]
000079a3731d6c7b  vmovaps xmm11, [rsp+0xA0]
000079a3731d6c84  vmovaps xmm12, [rsp+0xB0]
000079a3731d6c8d  vmovaps xmm13, [rsp+0xC0]
000079a3731d6c96  vmovaps xmm14, [rsp+0xD0]
000079a3731d6c9f  vmovaps xmm15, [rsp+0xE0]
000079a3731d6ca8  add rsp, 0xF0
000079a3731d6caf  pop r11
000079a3731d6cb1  pop r10
000079a3731d6cb3  pop r9
000079a3731d6cb5  pop r8
000079a3731d6cb7  pop rsi
000079a3731d6cb8  pop rdi
000079a3731d6cb9  pop rdx
000079a3731d6cba  pop rcx
000079a3731d6cbb  pop rax
000079a3731d6cbc  add rsp, 0x08
000079a3731d6cc0  jmp 0x000079A3731D5A06
000079a3731d6cc5  sub rsp, 0x08
000079a3731d6cc9  push rax
000079a3731d6cca  push rcx
000079a3731d6ccb  push rdx
000079a3731d6ccc  push rdi
000079a3731d6ccd  push rsi
000079a3731d6cce  push r8
000079a3731d6cd0  push r9
000079a3731d6cd2  push r10
000079a3731d6cd4  push r11
000079a3731d6cd6  sub rsp, 0xF0
000079a3731d6cdd  vmovaps [rsp], xmm0
000079a3731d6ce2  vmovaps [rsp+0x10], xmm1
000079a3731d6ce8  vmovaps [rsp+0x20], xmm2
000079a3731d6cee  vmovaps [rsp+0x30], xmm3
000079a3731d6cf4  vmovaps [rsp+0x40], xmm4
000079a3731d6cfa  vmovaps [rsp+0x50], xmm5
000079a3731d6d00  vmovaps [rsp+0x60], xmm7
000079a3731d6d06  vmovaps [rsp+0x70], xmm8
000079a3731d6d0c  vmovaps [rsp+0x80], xmm9
000079a3731d6d15  vmovaps [rsp+0x90], xmm10
000079a3731d6d1e  vmovaps [rsp+0xA0], xmm11
000079a3731d6d27  vmovaps [rsp+0xB0], xmm12
000079a3731d6d30  vmovaps [rsp+0xC0], xmm13
000079a3731d6d39  vmovaps [rsp+0xD0], xmm14
000079a3731d6d42  vmovaps [rsp+0xE0], xmm15
000079a3731d6d4b  sub rsp, 0x30
000079a3731d6d4f  movaps [rsp], xmm6
000079a3731d6d53  movaps [rsp+0x10], xmm12
000079a3731d6d59  movaps [rsp+0x20], xmm11
000079a3731d6d5f  lea rdi, [rsp]
000079a3731d6d63  mov esi, 0x00
000079a3731d6d68  mov rax, 0x64F127B95530
000079a3731d6d72  call rax
000079a3731d6d74  movaps xmm6, [rsp]
000079a3731d6d78  add rsp, 0x30
000079a3731d6d7c  vmovaps xmm0, [rsp]
000079a3731d6d81  vmovaps xmm1, [rsp+0x10]
000079a3731d6d87  vmovaps xmm2, [rsp+0x20]
000079a3731d6d8d  vmovaps xmm3, [rsp+0x30]
000079a3731d6d93  vmovaps xmm4, [rsp+0x40]
000079a3731d6d99  vmovaps xmm5, [rsp+0x50]
000079a3731d6d9f  vmovaps xmm7, [rsp+0x60]
000079a3731d6da5  vmovaps xmm8, [rsp+0x70]
000079a3731d6dab  vmovaps xmm9, [rsp+0x80]
000079a3731d6db4  vmovaps xmm10, [rsp+0x90]
000079a3731d6dbd  vmovaps xmm11, [rsp+0xA0]
000079a3731d6dc6  vmovaps xmm12, [rsp+0xB0]
000079a3731d6dcf  vmovaps xmm13, [rsp+0xC0]
000079a3731d6dd8  vmovaps xmm14, [rsp+0xD0]
000079a3731d6de1  vmovaps xmm15, [rsp+0xE0]
000079a3731d6dea  add rsp, 0xF0
000079a3731d6df1  pop r11
000079a3731d6df3  pop r10
000079a3731d6df5  pop r9
000079a3731d6df7  pop r8
000079a3731d6df9  pop rsi
000079a3731d6dfa  pop rdi
000079a3731d6dfb  pop rdx
000079a3731d6dfc  pop rcx
000079a3731d6dfd  pop rax
000079a3731d6dfe  add rsp, 0x08
000079a3731d6e02  jmp 0x000079A3731D5A27
000079a3731d6e07  sub rsp, 0x08
000079a3731d6e0b  push rax
000079a3731d6e0c  push rcx
000079a3731d6e0d  push rdx
000079a3731d6e0e  push rdi
000079a3731d6e0f  push rsi
000079a3731d6e10  push r8
000079a3731d6e12  push r9
000079a3731d6e14  push r10
000079a3731d6e16  push r11
000079a3731d6e18  sub rsp, 0xF0
000079a3731d6e1f  vmovaps [rsp], xmm0
000079a3731d6e24  vmovaps [rsp+0x10], xmm1
000079a3731d6e2a  vmovaps [rsp+0x20], xmm2
000079a3731d6e30  vmovaps [rsp+0x30], xmm4
000079a3731d6e36  vmovaps [rsp+0x40], xmm5
000079a3731d6e3c  vmovaps [rsp+0x50], xmm6
000079a3731d6e42  vmovaps [rsp+0x60], xmm7
000079a3731d6e48  vmovaps [rsp+0x70], xmm8
000079a3731d6e4e  vmovaps [rsp+0x80], xmm9
000079a3731d6e57  vmovaps [rsp+0x90], xmm10
000079a3731d6e60  vmovaps [rsp+0xA0], xmm11
000079a3731d6e69  vmovaps [rsp+0xB0], xmm12
000079a3731d6e72  vmovaps [rsp+0xC0], xmm13
000079a3731d6e7b  vmovaps [rsp+0xD0], xmm14
000079a3731d6e84  vmovaps [rsp+0xE0], xmm15
000079a3731d6e8d  sub rsp, 0x30
000079a3731d6e91  movaps [rsp], xmm3
000079a3731d6e95  movaps [rsp+0x10], xmm5
000079a3731d6e9a  movaps [rsp+0x20], xmm4
000079a3731d6e9f  lea rdi, [rsp]
000079a3731d6ea3  mov esi, 0x00
000079a3731d6ea8  mov rax, 0x64F127B95530
000079a3731d6eb2  call rax
000079a3731d6eb4  movaps xmm3, [rsp]
000079a3731d6eb8  add rsp, 0x30
000079a3731d6ebc  vmovaps xmm0, [rsp]
000079a3731d6ec1  vmovaps xmm1, [rsp+0x10]
000079a3731d6ec7  vmovaps xmm2, [rsp+0x20]
000079a3731d6ecd  vmovaps xmm4, [rsp+0x30]
000079a3731d6ed3  vmovaps xmm5, [rsp+0x40]
000079a3731d6ed9  vmovaps xmm6, [rsp+0x50]
000079a3731d6edf  vmovaps xmm7, [rsp+0x60]
000079a3731d6ee5  vmovaps xmm8, [rsp+0x70]
000079a3731d6eeb  vmovaps xmm9, [rsp+0x80]
000079a3731d6ef4  vmovaps xmm10, [rsp+0x90]
000079a3731d6efd  vmovaps xmm11, [rsp+0xA0]
000079a3731d6f06  vmovaps xmm12, [rsp+0xB0]
000079a3731d6f0f  vmovaps xmm13, [rsp+0xC0]
000079a3731d6f18  vmovaps xmm14, [rsp+0xD0]
000079a3731d6f21  vmovaps xmm15, [rsp+0xE0]
000079a3731d6f2a  add rsp, 0xF0
000079a3731d6f31  pop r11
000079a3731d6f33  pop r10
000079a3731d6f35  pop r9
000079a3731d6f37  pop r8
000079a3731d6f39  pop rsi
000079a3731d6f3a  pop rdi
000079a3731d6f3b  pop rdx
000079a3731d6f3c  pop rcx
000079a3731d6f3d  pop rax
000079a3731d6f3e  add rsp, 0x08
000079a3731d6f42  jmp 0x000079A3731D5A88
000079a3731d6f47  sub rsp, 0x08
000079a3731d6f4b  push rax
000079a3731d6f4c  push rcx
000079a3731d6f4d  push rdx
000079a3731d6f4e  push rdi
000079a3731d6f4f  push rsi
000079a3731d6f50  push r8
000079a3731d6f52  push r9
000079a3731d6f54  push r10
000079a3731d6f56  push r11
000079a3731d6f58  sub rsp, 0xF0
000079a3731d6f5f  vmovaps [rsp], xmm0
000079a3731d6f64  vmovaps [rsp+0x10], xmm1
000079a3731d6f6a  vmovaps [rsp+0x20], xmm2
000079a3731d6f70  vmovaps [rsp+0x30], xmm3
000079a3731d6f76  vmovaps [rsp+0x40], xmm4
000079a3731d6f7c  vmovaps [rsp+0x50], xmm6
000079a3731d6f82  vmovaps [rsp+0x60], xmm7
000079a3731d6f88  vmovaps [rsp+0x70], xmm8
000079a3731d6f8e  vmovaps [rsp+0x80], xmm9
000079a3731d6f97  vmovaps [rsp+0x90], xmm10
000079a3731d6fa0  vmovaps [rsp+0xA0], xmm11
000079a3731d6fa9  vmovaps [rsp+0xB0], xmm12
000079a3731d6fb2  vmovaps [rsp+0xC0], xmm13
000079a3731d6fbb  vmovaps [rsp+0xD0], xmm14
000079a3731d6fc4  vmovaps [rsp+0xE0], xmm15
000079a3731d6fcd  sub rsp, 0x30
000079a3731d6fd1  movaps [rsp], xmm5
000079a3731d6fd5  movaps [rsp+0x10], xmm8
000079a3731d6fdb  movaps [rsp+0x20], xmm15
000079a3731d6fe1  lea rdi, [rsp]
000079a3731d6fe5  mov esi, 0x00
000079a3731d6fea  mov rax, 0x64F127B95530
000079a3731d6ff4  call rax
000079a3731d6ff6  movaps xmm5, [rsp]
000079a3731d6ffa  add rsp, 0x30
000079a3731d6ffe  vmovaps xmm0, [rsp]
000079a3731d7003  vmovaps xmm1, [rsp+0x10]
000079a3731d7009  vmovaps xmm2, [rsp+0x20]
000079a3731d700f  vmovaps xmm3, [rsp+0x30]
000079a3731d7015  vmovaps xmm4, [rsp+0x40]
000079a3731d701b  vmovaps xmm6, [rsp+0x50]
000079a3731d7021  vmovaps xmm7, [rsp+0x60]
000079a3731d7027  vmovaps xmm8, [rsp+0x70]
000079a3731d702d  vmovaps xmm9, [rsp+0x80]
000079a3731d7036  vmovaps xmm10, [rsp+0x90]
000079a3731d703f  vmovaps xmm11, [rsp+0xA0]
000079a3731d7048  vmovaps xmm12, [rsp+0xB0]
000079a3731d7051  vmovaps xmm13, [rsp+0xC0]
000079a3731d705a  vmovaps xmm14, [rsp+0xD0]
000079a3731d7063  vmovaps xmm15, [rsp+0xE0]
000079a3731d706c  add rsp, 0xF0
000079a3731d7073  pop r11
000079a3731d7075  pop r10
000079a3731d7077  pop r9
000079a3731d7079  pop r8
000079a3731d707b  pop rsi
000079a3731d707c  pop rdi
000079a3731d707d  pop rdx
000079a3731d707e  pop rcx
000079a3731d707f  pop rax
000079a3731d7080  add rsp, 0x08
000079a3731d7084  jmp 0x000079A3731D5AC0
000079a3731d7089  sub rsp, 0x08
000079a3731d708d  push rax
000079a3731d708e  push rcx
000079a3731d708f  push rdx
000079a3731d7090  push rdi
000079a3731d7091  push rsi
000079a3731d7092  push r8
000079a3731d7094  push r9
000079a3731d7096  push r10
000079a3731d7098  push r11
000079a3731d709a  sub rsp, 0xF0
000079a3731d70a1  vmovaps [rsp], xmm0
000079a3731d70a6  vmovaps [rsp+0x10], xmm1
000079a3731d70ac  vmovaps [rsp+0x20], xmm2
000079a3731d70b2  vmovaps [rsp+0x30], xmm3
000079a3731d70b8  vmovaps [rsp+0x40], xmm5
000079a3731d70be  vmovaps [rsp+0x50], xmm6
000079a3731d70c4  vmovaps [rsp+0x60], xmm7
000079a3731d70ca  vmovaps [rsp+0x70], xmm8
000079a3731d70d0  vmovaps [rsp+0x80], xmm9
000079a3731d70d9  vmovaps [rsp+0x90], xmm10
000079a3731d70e2  vmovaps [rsp+0xA0], xmm11
000079a3731d70eb  vmovaps [rsp+0xB0], xmm12
000079a3731d70f4  vmovaps [rsp+0xC0], xmm13
000079a3731d70fd  vmovaps [rsp+0xD0], xmm14
000079a3731d7106  vmovaps [rsp+0xE0], xmm15
000079a3731d710f  sub rsp, 0x30
000079a3731d7113  movaps [rsp], xmm4
000079a3731d7117  movaps [rsp+0x10], xmm9
000079a3731d711d  movaps [rsp+0x20], xmm8
000079a3731d7123  lea rdi, [rsp]
000079a3731d7127  mov esi, 0x00
000079a3731d712c  mov rax, 0x64F127B95530
000079a3731d7136  call rax
000079a3731d7138  movaps xmm4, [rsp]
000079a3731d713c  add rsp, 0x30
000079a3731d7140  vmovaps xmm0, [rsp]
000079a3731d7145  vmovaps xmm1, [rsp+0x10]
000079a3731d714b  vmovaps xmm2, [rsp+0x20]
000079a3731d7151  vmovaps xmm3, [rsp+0x30]
000079a3731d7157  vmovaps xmm5, [rsp+0x40]
000079a3731d715d  vmovaps xmm6, [rsp+0x50]
000079a3731d7163  vmovaps xmm7, [rsp+0x60]
000079a3731d7169  vmovaps xmm8, [rsp+0x70]
000079a3731d716f  vmovaps xmm9, [rsp+0x80]
000079a3731d7178  vmovaps xmm10, [rsp+0x90]
000079a3731d7181  vmovaps xmm11, [rsp+0xA0]
000079a3731d718a  vmovaps xmm12, [rsp+0xB0]
000079a3731d7193  vmovaps xmm13, [rsp+0xC0]
000079a3731d719c  vmovaps xmm14, [rsp+0xD0]
000079a3731d71a5  vmovaps xmm15, [rsp+0xE0]
000079a3731d71ae  add rsp, 0xF0
000079a3731d71b5  pop r11
000079a3731d71b7  pop r10
000079a3731d71b9  pop r9
000079a3731d71bb  pop r8
000079a3731d71bd  pop rsi
000079a3731d71be  pop rdi
000079a3731d71bf  pop rdx
000079a3731d71c0  pop rcx
000079a3731d71c1  pop rax
000079a3731d71c2  add rsp, 0x08
000079a3731d71c6  jmp 0x000079A3731D5AE1
000079a3731d71cb  sub rsp, 0x08
000079a3731d71cf  push rax
000079a3731d71d0  push rcx
000079a3731d71d1  push rdx
000079a3731d71d2  push rdi
000079a3731d71d3  push rsi
000079a3731d71d4  push r8
000079a3731d71d6  push r9
000079a3731d71d8  push r10
000079a3731d71da  push r11
000079a3731d71dc  sub rsp, 0xF0
000079a3731d71e3  vmovaps [rsp], xmm0
000079a3731d71e8  vmovaps [rsp+0x10], xmm1
000079a3731d71ee  vmovaps [rsp+0x20], xmm2
000079a3731d71f4  vmovaps [rsp+0x30], xmm3
000079a3731d71fa  vmovaps [rsp+0x40], xmm4
000079a3731d7200  vmovaps [rsp+0x50], xmm5
000079a3731d7206  vmovaps [rsp+0x60], xmm6
000079a3731d720c  vmovaps [rsp+0x70], xmm7
000079a3731d7212  vmovaps [rsp+0x80], xmm8
000079a3731d721b  vmovaps [rsp+0x90], xmm10
000079a3731d7224  vmovaps [rsp+0xA0], xmm11
000079a3731d722d  vmovaps [rsp+0xB0], xmm12
000079a3731d7236  vmovaps [rsp+0xC0], xmm13
000079a3731d723f  vmovaps [rsp+0xD0], xmm14
000079a3731d7248  vmovaps [rsp+0xE0], xmm15
000079a3731d7251  sub rsp, 0x30
000079a3731d7255  movaps [rsp], xmm9
000079a3731d725a  movaps [rsp+0x10], xmm10
000079a3731d7260  movaps [rsp+0x20], xmm8
000079a3731d7266  lea rdi, [rsp]
000079a3731d726a  mov esi, 0x00
000079a3731d726f  mov rax, 0x64F127B95530
000079a3731d7279  call rax
000079a3731d727b  movaps xmm9, [rsp]
000079a3731d7280  add rsp, 0x30
000079a3731d7284  vmovaps xmm0, [rsp]
000079a3731d7289  vmovaps xmm1, [rsp+0x10]
000079a3731d728f  vmovaps xmm2, [rsp+0x20]
000079a3731d7295  vmovaps xmm3, [rsp+0x30]
000079a3731d729b  vmovaps xmm4, [rsp+0x40]
000079a3731d72a1  vmovaps xmm5, [rsp+0x50]
000079a3731d72a7  vmovaps xmm6, [rsp+0x60]
000079a3731d72ad  vmovaps xmm7, [rsp+0x70]
000079a3731d72b3  vmovaps xmm8, [rsp+0x80]
000079a3731d72bc  vmovaps xmm10, [rsp+0x90]
000079a3731d72c5  vmovaps xmm11, [rsp+0xA0]
000079a3731d72ce  vmovaps xmm12, [rsp+0xB0]
000079a3731d72d7  vmovaps xmm13, [rsp+0xC0]
000079a3731d72e0  vmovaps xmm14, [rsp+0xD0]
000079a3731d72e9  vmovaps xmm15, [rsp+0xE0]
000079a3731d72f2  add rsp, 0xF0
000079a3731d72f9  pop r11
000079a3731d72fb  pop r10
000079a3731d72fd  pop r9
000079a3731d72ff  pop r8
000079a3731d7301  pop rsi
000079a3731d7302  pop rdi
000079a3731d7303  pop rdx
000079a3731d7304  pop rcx
000079a3731d7305  pop rax
000079a3731d7306  add rsp, 0x08
000079a3731d730a  jmp 0x000079A3731D5AFB
000079a3731d730f  call 0x000079A3730D64F0
000079a3731d7314  jmp 0x000079A3731D5C15
000079a3731d7319  call 0x000079A3730D64F0
000079a3731d731e  jmp 0x000079A3731D5C2B
000079a3731d7323  sub rsp, 0x08
000079a3731d7327  push rax
000079a3731d7328  push rcx
000079a3731d7329  push rdx
000079a3731d732a  push rdi
000079a3731d732b  push rsi
000079a3731d732c  push r8
000079a3731d732e  push r9
000079a3731d7330  push r10
000079a3731d7332  push r11
000079a3731d7334  sub rsp, 0xF0
000079a3731d733b  vmovaps [rsp], xmm0
000079a3731d7340  vmovaps [rsp+0x10], xmm2
000079a3731d7346  vmovaps [rsp+0x20], xmm3
000079a3731d734c  vmovaps [rsp+0x30], xmm4
000079a3731d7352  vmovaps [rsp+0x40], xmm5
000079a3731d7358  vmovaps [rsp+0x50], xmm6
000079a3731d735e  vmovaps [rsp+0x60], xmm7
000079a3731d7364  vmovaps [rsp+0x70], xmm8
000079a3731d736a  vmovaps [rsp+0x80], xmm9
000079a3731d7373  vmovaps [rsp+0x90], xmm10
000079a3731d737c  vmovaps [rsp+0xA0], xmm11
000079a3731d7385  vmovaps [rsp+0xB0], xmm12
000079a3731d738e  vmovaps [rsp+0xC0], xmm13
000079a3731d7397  vmovaps [rsp+0xD0], xmm14
000079a3731d73a0  vmovaps [rsp+0xE0], xmm15
000079a3731d73a9  sub rsp, 0x30
000079a3731d73ad  movaps [rsp], xmm1
000079a3731d73b1  movaps [rsp+0x10], xmm6
000079a3731d73b6  movaps [rsp+0x20], xmm15
000079a3731d73bc  lea rdi, [rsp]
000079a3731d73c0  mov esi, 0x00
000079a3731d73c5  mov rax, 0x64F127B95530
000079a3731d73cf  call rax
000079a3731d73d1  movaps xmm1, [rsp]
000079a3731d73d5  add rsp, 0x30
000079a3731d73d9  vmovaps xmm0, [rsp]
000079a3731d73de  vmovaps xmm2, [rsp+0x10]
000079a3731d73e4  vmovaps xmm3, [rsp+0x20]
000079a3731d73ea  vmovaps xmm4, [rsp+0x30]
000079a3731d73f0  vmovaps xmm5, [rsp+0x40]
000079a3731d73f6  vmovaps xmm6, [rsp+0x50]
000079a3731d73fc  vmovaps xmm7, [rsp+0x60]
000079a3731d7402  vmovaps xmm8, [rsp+0x70]
000079a3731d7408  vmovaps xmm9, [rsp+0x80]
000079a3731d7411  vmovaps xmm10, [rsp+0x90]
000079a3731d741a  vmovaps xmm11, [rsp+0xA0]
000079a3731d7423  vmovaps xmm12, [rsp+0xB0]
000079a3731d742c  vmovaps xmm13, [rsp+0xC0]
000079a3731d7435  vmovaps xmm14, [rsp+0xD0]
000079a3731d743e  vmovaps xmm15, [rsp+0xE0]
000079a3731d7447  add rsp, 0xF0
000079a3731d744e  pop r11
000079a3731d7450  pop r10
000079a3731d7452  pop r9
000079a3731d7454  pop r8
000079a3731d7456  pop rsi
000079a3731d7457  pop rdi
000079a3731d7458  pop rdx
000079a3731d7459  pop rcx
000079a3731d745a  pop rax
000079a3731d745b  add rsp, 0x08
000079a3731d745f  jmp 0x000079A3731D5C68
000079a3731d7464  call 0x000079A3730E5820
000079a3731d7469  jmp 0x000079A3731D5C75
000079a3731d746e  sub rsp, 0x08
000079a3731d7472  push rax
000079a3731d7473  push rcx
000079a3731d7474  push rdx
000079a3731d7475  push rdi
000079a3731d7476  push rsi
000079a3731d7477  push r8
000079a3731d7479  push r9
000079a3731d747b  push r10
000079a3731d747d  push r11
000079a3731d747f  sub rsp, 0xF0
000079a3731d7486  vmovaps [rsp], xmm0
000079a3731d748b  vmovaps [rsp+0x10], xmm1
000079a3731d7491  vmovaps [rsp+0x20], xmm2
000079a3731d7497  vmovaps [rsp+0x30], xmm3
000079a3731d749d  vmovaps [rsp+0x40], xmm4
000079a3731d74a3  vmovaps [rsp+0x50], xmm5
000079a3731d74a9  vmovaps [rsp+0x60], xmm6
000079a3731d74af  vmovaps [rsp+0x70], xmm7
000079a3731d74b5  vmovaps [rsp+0x80], xmm8
000079a3731d74be  vmovaps [rsp+0x90], xmm9
000079a3731d74c7  vmovaps [rsp+0xA0], xmm10
000079a3731d74d0  vmovaps [rsp+0xB0], xmm11
000079a3731d74d9  vmovaps [rsp+0xC0], xmm12
000079a3731d74e2  vmovaps [rsp+0xD0], xmm13
000079a3731d74eb  vmovaps [rsp+0xE0], xmm15
000079a3731d74f4  sub rsp, 0x30
000079a3731d74f8  movaps [rsp], xmm14
000079a3731d74fd  movaps [rsp+0x10], xmm4
000079a3731d7502  movaps [rsp+0x20], xmm3
000079a3731d7507  lea rdi, [rsp]
000079a3731d750b  mov esi, 0x00
000079a3731d7510  mov rax, 0x64F127B95530
000079a3731d751a  call rax
000079a3731d751c  movaps xmm14, [rsp]
000079a3731d7521  add rsp, 0x30
000079a3731d7525  vmovaps xmm0, [rsp]
000079a3731d752a  vmovaps xmm1, [rsp+0x10]
000079a3731d7530  vmovaps xmm2, [rsp+0x20]
000079a3731d7536  vmovaps xmm3, [rsp+0x30]
000079a3731d753c  vmovaps xmm4, [rsp+0x40]
000079a3731d7542  vmovaps xmm5, [rsp+0x50]
000079a3731d7548  vmovaps xmm6, [rsp+0x60]
000079a3731d754e  vmovaps xmm7, [rsp+0x70]
000079a3731d7554  vmovaps xmm8, [rsp+0x80]
000079a3731d755d  vmovaps xmm9, [rsp+0x90]
000079a3731d7566  vmovaps xmm10, [rsp+0xA0]
000079a3731d756f  vmovaps xmm11, [rsp+0xB0]
000079a3731d7578  vmovaps xmm12, [rsp+0xC0]
000079a3731d7581  vmovaps xmm13, [rsp+0xD0]
000079a3731d758a  vmovaps xmm15, [rsp+0xE0]
000079a3731d7593  add rsp, 0xF0
000079a3731d759a  pop r11
000079a3731d759c  pop r10
000079a3731d759e  pop r9
000079a3731d75a0  pop r8
000079a3731d75a2  pop rsi
000079a3731d75a3  pop rdi
000079a3731d75a4  pop rdx
000079a3731d75a5  pop rcx
000079a3731d75a6  pop rax
000079a3731d75a7  add rsp, 0x08
000079a3731d75ab  jmp 0x000079A3731D5C8F
000079a3731d75b0  sub rsp, 0x08
000079a3731d75b4  push rax
000079a3731d75b5  push rcx
000079a3731d75b6  push rdx
000079a3731d75b7  push rdi
000079a3731d75b8  push rsi
000079a3731d75b9  push r8
000079a3731d75bb  push r9
000079a3731d75bd  push r10
000079a3731d75bf  push r11
000079a3731d75c1  sub rsp, 0xF0
000079a3731d75c8  vmovaps [rsp], xmm0
000079a3731d75cd  vmovaps [rsp+0x10], xmm1
000079a3731d75d3  vmovaps [rsp+0x20], xmm2
000079a3731d75d9  vmovaps [rsp+0x30], xmm3
000079a3731d75df  vmovaps [rsp+0x40], xmm4
000079a3731d75e5  vmovaps [rsp+0x50], xmm5
000079a3731d75eb  vmovaps [rsp+0x60], xmm7
000079a3731d75f1  vmovaps [rsp+0x70], xmm8
000079a3731d75f7  vmovaps [rsp+0x80], xmm9
000079a3731d7600  vmovaps [rsp+0x90], xmm10
000079a3731d7609  vmovaps [rsp+0xA0], xmm11
000079a3731d7612  vmovaps [rsp+0xB0], xmm12
000079a3731d761b  vmovaps [rsp+0xC0], xmm13
000079a3731d7624  vmovaps [rsp+0xD0], xmm14
000079a3731d762d  vmovaps [rsp+0xE0], xmm15
000079a3731d7636  sub rsp, 0x30
000079a3731d763a  movaps [rsp], xmm6
000079a3731d763e  movaps [rsp+0x10], xmm9
000079a3731d7644  movaps [rsp+0x20], xmm7
000079a3731d7649  lea rdi, [rsp]
000079a3731d764d  mov esi, 0x00
000079a3731d7652  mov rax, 0x64F127B95530
000079a3731d765c  call rax
000079a3731d765e  movaps xmm6, [rsp]
000079a3731d7662  add rsp, 0x30
000079a3731d7666  vmovaps xmm0, [rsp]
000079a3731d766b  vmovaps xmm1, [rsp+0x10]
000079a3731d7671  vmovaps xmm2, [rsp+0x20]
000079a3731d7677  vmovaps xmm3, [rsp+0x30]
000079a3731d767d  vmovaps xmm4, [rsp+0x40]
000079a3731d7683  vmovaps xmm5, [rsp+0x50]
000079a3731d7689  vmovaps xmm7, [rsp+0x60]
000079a3731d768f  vmovaps xmm8, [rsp+0x70]
000079a3731d7695  vmovaps xmm9, [rsp+0x80]
000079a3731d769e  vmovaps xmm10, [rsp+0x90]
000079a3731d76a7  vmovaps xmm11, [rsp+0xA0]
000079a3731d76b0  vmovaps xmm12, [rsp+0xB0]
000079a3731d76b9  vmovaps xmm13, [rsp+0xC0]
000079a3731d76c2  vmovaps xmm14, [rsp+0xD0]
000079a3731d76cb  vmovaps xmm15, [rsp+0xE0]
000079a3731d76d4  add rsp, 0xF0
000079a3731d76db  pop r11
000079a3731d76dd  pop r10
000079a3731d76df  pop r9
000079a3731d76e1  pop r8
000079a3731d76e3  pop rsi
000079a3731d76e4  pop rdi
000079a3731d76e5  pop rdx
000079a3731d76e6  pop rcx
000079a3731d76e7  pop rax
000079a3731d76e8  add rsp, 0x08
000079a3731d76ec  jmp 0x000079A3731D5CA7
000079a3731d76f1  sub rsp, 0x08
000079a3731d76f5  push rax
000079a3731d76f6  push rcx
000079a3731d76f7  push rdx
000079a3731d76f8  push rdi
000079a3731d76f9  push rsi
000079a3731d76fa  push r8
000079a3731d76fc  push r9
000079a3731d76fe  push r10
000079a3731d7700  push r11
000079a3731d7702  sub rsp, 0xF0
000079a3731d7709  vmovaps [rsp], xmm0
000079a3731d770e  vmovaps [rsp+0x10], xmm1
000079a3731d7714  vmovaps [rsp+0x20], xmm2
000079a3731d771a  vmovaps [rsp+0x30], xmm3
000079a3731d7720  vmovaps [rsp+0x40], xmm4
000079a3731d7726  vmovaps [rsp+0x50], xmm5
000079a3731d772c  vmovaps [rsp+0x60], xmm6
000079a3731d7732  vmovaps [rsp+0x70], xmm8
000079a3731d7738  vmovaps [rsp+0x80], xmm9
000079a3731d7741  vmovaps [rsp+0x90], xmm10
000079a3731d774a  vmovaps [rsp+0xA0], xmm11
000079a3731d7753  vmovaps [rsp+0xB0], xmm12
000079a3731d775c  vmovaps [rsp+0xC0], xmm13
000079a3731d7765  vmovaps [rsp+0xD0], xmm14
000079a3731d776e  vmovaps [rsp+0xE0], xmm15
000079a3731d7777  sub rsp, 0x30
000079a3731d777b  movaps [rsp], xmm7
000079a3731d777f  movaps [rsp+0x10], xmm4
000079a3731d7784  movaps [rsp+0x20], xmm9
000079a3731d778a  lea rdi, [rsp]
000079a3731d778e  mov esi, 0x00
000079a3731d7793  mov rax, 0x64F127B95530
000079a3731d779d  call rax
000079a3731d779f  movaps xmm7, [rsp]
000079a3731d77a3  add rsp, 0x30
000079a3731d77a7  vmovaps xmm0, [rsp]
000079a3731d77ac  vmovaps xmm1, [rsp+0x10]
000079a3731d77b2  vmovaps xmm2, [rsp+0x20]
000079a3731d77b8  vmovaps xmm3, [rsp+0x30]
000079a3731d77be  vmovaps xmm4, [rsp+0x40]
000079a3731d77c4  vmovaps xmm5, [rsp+0x50]
000079a3731d77ca  vmovaps xmm6, [rsp+0x60]
000079a3731d77d0  vmovaps xmm8, [rsp+0x70]
000079a3731d77d6  vmovaps xmm9, [rsp+0x80]
000079a3731d77df  vmovaps xmm10, [rsp+0x90]
000079a3731d77e8  vmovaps xmm11, [rsp+0xA0]
000079a3731d77f1  vmovaps xmm12, [rsp+0xB0]
000079a3731d77fa  vmovaps xmm13, [rsp+0xC0]
000079a3731d7803  vmovaps xmm14, [rsp+0xD0]
000079a3731d780c  vmovaps xmm15, [rsp+0xE0]
000079a3731d7815  add rsp, 0xF0
000079a3731d781c  pop r11
000079a3731d781e  pop r10
000079a3731d7820  pop r9
000079a3731d7822  pop r8
000079a3731d7824  pop rsi
000079a3731d7825  pop rdi
000079a3731d7826  pop rdx
000079a3731d7827  pop rcx
000079a3731d7828  pop rax
000079a3731d7829  add rsp, 0x08
000079a3731d782d  jmp 0x000079A3731D5CD4
000079a3731d7832  sub rsp, 0x08
000079a3731d7836  push rax
000079a3731d7837  push rcx
000079a3731d7838  push rdx
000079a3731d7839  push rdi
000079a3731d783a  push rsi
000079a3731d783b  push r8
000079a3731d783d  push r9
000079a3731d783f  push r10
000079a3731d7841  push r11
000079a3731d7843  sub rsp, 0xF0
000079a3731d784a  vmovaps [rsp], xmm0
000079a3731d784f  vmovaps [rsp+0x10], xmm1
000079a3731d7855  vmovaps [rsp+0x20], xmm2
000079a3731d785b  vmovaps [rsp+0x30], xmm3
000079a3731d7861  vmovaps [rsp+0x40], xmm5
000079a3731d7867  vmovaps [rsp+0x50], xmm6
000079a3731d786d  vmovaps [rsp+0x60], xmm7
000079a3731d7873  vmovaps [rsp+0x70], xmm8
000079a3731d7879  vmovaps [rsp+0x80], xmm9
000079a3731d7882  vmovaps [rsp+0x90], xmm10
000079a3731d788b  vmovaps [rsp+0xA0], xmm11
000079a3731d7894  vmovaps [rsp+0xB0], xmm12
000079a3731d789d  vmovaps [rsp+0xC0], xmm13
000079a3731d78a6  vmovaps [rsp+0xD0], xmm14
000079a3731d78af  vmovaps [rsp+0xE0], xmm15
000079a3731d78b8  sub rsp, 0x30
000079a3731d78bc  movaps [rsp], xmm4
000079a3731d78c0  movaps [rsp+0x10], xmm15
000079a3731d78c6  movaps [rsp+0x20], xmm9
000079a3731d78cc  lea rdi, [rsp]
000079a3731d78d0  mov esi, 0x00
000079a3731d78d5  mov rax, 0x64F127B95530
000079a3731d78df  call rax
000079a3731d78e1  movaps xmm4, [rsp]
000079a3731d78e5  add rsp, 0x30
000079a3731d78e9  vmovaps xmm0, [rsp]
000079a3731d78ee  vmovaps xmm1, [rsp+0x10]
000079a3731d78f4  vmovaps xmm2, [rsp+0x20]
000079a3731d78fa  vmovaps xmm3, [rsp+0x30]
000079a3731d7900  vmovaps xmm5, [rsp+0x40]
000079a3731d7906  vmovaps xmm6, [rsp+0x50]
000079a3731d790c  vmovaps xmm7, [rsp+0x60]
000079a3731d7912  vmovaps xmm8, [rsp+0x70]
000079a3731d7918  vmovaps xmm9, [rsp+0x80]
000079a3731d7921  vmovaps xmm10, [rsp+0x90]
000079a3731d792a  vmovaps xmm11, [rsp+0xA0]
000079a3731d7933  vmovaps xmm12, [rsp+0xB0]
000079a3731d793c  vmovaps xmm13, [rsp+0xC0]
000079a3731d7945  vmovaps xmm14, [rsp+0xD0]
000079a3731d794e  vmovaps xmm15, [rsp+0xE0]
000079a3731d7957  add rsp, 0xF0
000079a3731d795e  pop r11
000079a3731d7960  pop r10
000079a3731d7962  pop r9
000079a3731d7964  pop r8
000079a3731d7966  pop rsi
000079a3731d7967  pop rdi
000079a3731d7968  pop rdx
000079a3731d7969  pop rcx
000079a3731d796a  pop rax
000079a3731d796b  add rsp, 0x08
000079a3731d796f  jmp 0x000079A3731D5CF9
000079a3731d7974  call 0x000079A3730E5820
000079a3731d7979  jmp 0x000079A3731D5D06
000079a3731d797e  sub rsp, 0x08
000079a3731d7982  push rax
000079a3731d7983  push rcx
000079a3731d7984  push rdx
000079a3731d7985  push rdi
000079a3731d7986  push rsi
000079a3731d7987  push r8
000079a3731d7989  push r9
000079a3731d798b  push r10
000079a3731d798d  push r11
000079a3731d798f  sub rsp, 0xF0
000079a3731d7996  vmovaps [rsp], xmm0
000079a3731d799b  vmovaps [rsp+0x10], xmm1
000079a3731d79a1  vmovaps [rsp+0x20], xmm2
000079a3731d79a7  vmovaps [rsp+0x30], xmm4
000079a3731d79ad  vmovaps [rsp+0x40], xmm5
000079a3731d79b3  vmovaps [rsp+0x50], xmm6
000079a3731d79b9  vmovaps [rsp+0x60], xmm7
000079a3731d79bf  vmovaps [rsp+0x70], xmm8
000079a3731d79c5  vmovaps [rsp+0x80], xmm9
000079a3731d79ce  vmovaps [rsp+0x90], xmm10
000079a3731d79d7  vmovaps [rsp+0xA0], xmm11
000079a3731d79e0  vmovaps [rsp+0xB0], xmm12
000079a3731d79e9  vmovaps [rsp+0xC0], xmm13
000079a3731d79f2  vmovaps [rsp+0xD0], xmm14
000079a3731d79fb  vmovaps [rsp+0xE0], xmm15
000079a3731d7a04  sub rsp, 0x30
000079a3731d7a08  movaps [rsp], xmm3
000079a3731d7a0c  movaps [rsp+0x10], xmm1
000079a3731d7a11  movaps [rsp+0x20], xmm9
000079a3731d7a17  lea rdi, [rsp]
000079a3731d7a1b  mov esi, 0x00
000079a3731d7a20  mov rax, 0x64F127B95530
000079a3731d7a2a  call rax
000079a3731d7a2c  movaps xmm3, [rsp]
000079a3731d7a30  add rsp, 0x30
000079a3731d7a34  vmovaps xmm0, [rsp]
000079a3731d7a39  vmovaps xmm1, [rsp+0x10]
000079a3731d7a3f  vmovaps xmm2, [rsp+0x20]
000079a3731d7a45  vmovaps xmm4, [rsp+0x30]
000079a3731d7a4b  vmovaps xmm5, [rsp+0x40]
000079a3731d7a51  vmovaps xmm6, [rsp+0x50]
000079a3731d7a57  vmovaps xmm7, [rsp+0x60]
000079a3731d7a5d  vmovaps xmm8, [rsp+0x70]
000079a3731d7a63  vmovaps xmm9, [rsp+0x80]
000079a3731d7a6c  vmovaps xmm10, [rsp+0x90]
000079a3731d7a75  vmovaps xmm11, [rsp+0xA0]
000079a3731d7a7e  vmovaps xmm12, [rsp+0xB0]
000079a3731d7a87  vmovaps xmm13, [rsp+0xC0]
000079a3731d7a90  vmovaps xmm14, [rsp+0xD0]
000079a3731d7a99  vmovaps xmm15, [rsp+0xE0]
000079a3731d7aa2  add rsp, 0xF0
000079a3731d7aa9  pop r11
000079a3731d7aab  pop r10
000079a3731d7aad  pop r9
000079a3731d7aaf  pop r8
000079a3731d7ab1  pop rsi
000079a3731d7ab2  pop rdi
000079a3731d7ab3  pop rdx
000079a3731d7ab4  pop rcx
000079a3731d7ab5  pop rax
000079a3731d7ab6  add rsp, 0x08
000079a3731d7aba  jmp 0x000079A3731D5D43
000079a3731d7abf  sub rsp, 0x08
000079a3731d7ac3  push rax
000079a3731d7ac4  push rcx
000079a3731d7ac5  push rdx
000079a3731d7ac6  push rdi
000079a3731d7ac7  push rsi
000079a3731d7ac8  push r8
000079a3731d7aca  push r9
000079a3731d7acc  push r10
000079a3731d7ace  push r11
000079a3731d7ad0  sub rsp, 0xF0
000079a3731d7ad7  vmovaps [rsp], xmm0
000079a3731d7adc  vmovaps [rsp+0x10], xmm2
000079a3731d7ae2  vmovaps [rsp+0x20], xmm3
000079a3731d7ae8  vmovaps [rsp+0x30], xmm4
000079a3731d7aee  vmovaps [rsp+0x40], xmm5
000079a3731d7af4  vmovaps [rsp+0x50], xmm6
000079a3731d7afa  vmovaps [rsp+0x60], xmm7
000079a3731d7b00  vmovaps [rsp+0x70], xmm8
000079a3731d7b06  vmovaps [rsp+0x80], xmm9
000079a3731d7b0f  vmovaps [rsp+0x90], xmm10
000079a3731d7b18  vmovaps [rsp+0xA0], xmm11
000079a3731d7b21  vmovaps [rsp+0xB0], xmm12
000079a3731d7b2a  vmovaps [rsp+0xC0], xmm13
000079a3731d7b33  vmovaps [rsp+0xD0], xmm14
000079a3731d7b3c  vmovaps [rsp+0xE0], xmm15
000079a3731d7b45  sub rsp, 0x30
000079a3731d7b49  movaps [rsp], xmm1
000079a3731d7b4d  movaps [rsp+0x10], xmm15
000079a3731d7b53  movaps [rsp+0x20], xmm9
000079a3731d7b59  lea rdi, [rsp]
000079a3731d7b5d  mov esi, 0x00
000079a3731d7b62  mov rax, 0x64F127B95530
000079a3731d7b6c  call rax
000079a3731d7b6e  movaps xmm1, [rsp]
000079a3731d7b72  add rsp, 0x30
000079a3731d7b76  vmovaps xmm0, [rsp]
000079a3731d7b7b  vmovaps xmm2, [rsp+0x10]
000079a3731d7b81  vmovaps xmm3, [rsp+0x20]
000079a3731d7b87  vmovaps xmm4, [rsp+0x30]
000079a3731d7b8d  vmovaps xmm5, [rsp+0x40]
000079a3731d7b93  vmovaps xmm6, [rsp+0x50]
000079a3731d7b99  vmovaps xmm7, [rsp+0x60]
000079a3731d7b9f  vmovaps xmm8, [rsp+0x70]
000079a3731d7ba5  vmovaps xmm9, [rsp+0x80]
000079a3731d7bae  vmovaps xmm10, [rsp+0x90]
000079a3731d7bb7  vmovaps xmm11, [rsp+0xA0]
000079a3731d7bc0  vmovaps xmm12, [rsp+0xB0]
000079a3731d7bc9  vmovaps xmm13, [rsp+0xC0]
000079a3731d7bd2  vmovaps xmm14, [rsp+0xD0]
000079a3731d7bdb  vmovaps xmm15, [rsp+0xE0]
000079a3731d7be4  add rsp, 0xF0
000079a3731d7beb  pop r11
000079a3731d7bed  pop r10
000079a3731d7bef  pop r9
000079a3731d7bf1  pop r8
000079a3731d7bf3  pop rsi
000079a3731d7bf4  pop rdi
000079a3731d7bf5  pop rdx
000079a3731d7bf6  pop rcx
000079a3731d7bf7  pop rax
000079a3731d7bf8  add rsp, 0x08
000079a3731d7bfc  jmp 0x000079A3731D5DCB
000079a3731d7c01  call 0x000079A3730E5820
000079a3731d7c06  jmp 0x000079A3731D5DD8
000079a3731d7c0b  sub rsp, 0x08
000079a3731d7c0f  push rax
000079a3731d7c10  push rcx
000079a3731d7c11  push rdx
000079a3731d7c12  push rdi
000079a3731d7c13  push rsi
000079a3731d7c14  push r8
000079a3731d7c16  push r9
000079a3731d7c18  push r10
000079a3731d7c1a  push r11
000079a3731d7c1c  sub rsp, 0xF0
000079a3731d7c23  vmovaps [rsp], xmm0
000079a3731d7c28  vmovaps [rsp+0x10], xmm2
000079a3731d7c2e  vmovaps [rsp+0x20], xmm3
000079a3731d7c34  vmovaps [rsp+0x30], xmm4
000079a3731d7c3a  vmovaps [rsp+0x40], xmm5
000079a3731d7c40  vmovaps [rsp+0x50], xmm6
000079a3731d7c46  vmovaps [rsp+0x60], xmm7
000079a3731d7c4c  vmovaps [rsp+0x70], xmm8
000079a3731d7c52  vmovaps [rsp+0x80], xmm9
000079a3731d7c5b  vmovaps [rsp+0x90], xmm10
000079a3731d7c64  vmovaps [rsp+0xA0], xmm11
000079a3731d7c6d  vmovaps [rsp+0xB0], xmm12
000079a3731d7c76  vmovaps [rsp+0xC0], xmm13
000079a3731d7c7f  vmovaps [rsp+0xD0], xmm14
000079a3731d7c88  vmovaps [rsp+0xE0], xmm15
000079a3731d7c91  sub rsp, 0x30
000079a3731d7c95  movaps [rsp], xmm1
000079a3731d7c99  movaps [rsp+0x10], xmm5
000079a3731d7c9e  movaps [rsp+0x20], xmm7
000079a3731d7ca3  lea rdi, [rsp]
000079a3731d7ca7  mov esi, 0x00
000079a3731d7cac  mov rax, 0x64F127B95530
000079a3731d7cb6  call rax
000079a3731d7cb8  movaps xmm1, [rsp]
000079a3731d7cbc  add rsp, 0x30
000079a3731d7cc0  vmovaps xmm0, [rsp]
000079a3731d7cc5  vmovaps xmm2, [rsp+0x10]
000079a3731d7ccb  vmovaps xmm3, [rsp+0x20]
000079a3731d7cd1  vmovaps xmm4, [rsp+0x30]
000079a3731d7cd7  vmovaps xmm5, [rsp+0x40]
000079a3731d7cdd  vmovaps xmm6, [rsp+0x50]
000079a3731d7ce3  vmovaps xmm7, [rsp+0x60]
000079a3731d7ce9  vmovaps xmm8, [rsp+0x70]
000079a3731d7cef  vmovaps xmm9, [rsp+0x80]
000079a3731d7cf8  vmovaps xmm10, [rsp+0x90]
000079a3731d7d01  vmovaps xmm11, [rsp+0xA0]
000079a3731d7d0a  vmovaps xmm12, [rsp+0xB0]
000079a3731d7d13  vmovaps xmm13, [rsp+0xC0]
000079a3731d7d1c  vmovaps xmm14, [rsp+0xD0]
000079a3731d7d25  vmovaps xmm15, [rsp+0xE0]
000079a3731d7d2e  add rsp, 0xF0
000079a3731d7d35  pop r11
000079a3731d7d37  pop r10
000079a3731d7d39  pop r9
000079a3731d7d3b  pop r8
000079a3731d7d3d  pop rsi
000079a3731d7d3e  pop rdi
000079a3731d7d3f  pop rdx
000079a3731d7d40  pop rcx
000079a3731d7d41  pop rax
000079a3731d7d42  add rsp, 0x08
000079a3731d7d46  jmp 0x000079A3731D5E7D
000079a3731d7d4b  sub rsp, 0x08
000079a3731d7d4f  push rax
000079a3731d7d50  push rcx
000079a3731d7d51  push rdx
000079a3731d7d52  push rdi
000079a3731d7d53  push rsi
000079a3731d7d54  push r8
000079a3731d7d56  push r9
000079a3731d7d58  push r10
000079a3731d7d5a  push r11
000079a3731d7d5c  sub rsp, 0xF0
000079a3731d7d63  vmovaps [rsp], xmm0
000079a3731d7d68  vmovaps [rsp+0x10], xmm1
000079a3731d7d6e  vmovaps [rsp+0x20], xmm2
000079a3731d7d74  vmovaps [rsp+0x30], xmm3
000079a3731d7d7a  vmovaps [rsp+0x40], xmm4
000079a3731d7d80  vmovaps [rsp+0x50], xmm5
000079a3731d7d86  vmovaps [rsp+0x60], xmm6
000079a3731d7d8c  vmovaps [rsp+0x70], xmm8
000079a3731d7d92  vmovaps [rsp+0x80], xmm9
000079a3731d7d9b  vmovaps [rsp+0x90], xmm10
000079a3731d7da4  vmovaps [rsp+0xA0], xmm11
000079a3731d7dad  vmovaps [rsp+0xB0], xmm12
000079a3731d7db6  vmovaps [rsp+0xC0], xmm13
000079a3731d7dbf  vmovaps [rsp+0xD0], xmm14
000079a3731d7dc8  vmovaps [rsp+0xE0], xmm15
000079a3731d7dd1  sub rsp, 0x30
000079a3731d7dd5  movaps [rsp], xmm7
000079a3731d7dd9  movaps [rsp+0x10], xmm5
000079a3731d7dde  movaps [rsp+0x20], xmm15
000079a3731d7de4  lea rdi, [rsp]
000079a3731d7de8  mov esi, 0x00
000079a3731d7ded  mov rax, 0x64F127B95530
000079a3731d7df7  call rax
000079a3731d7df9  movaps xmm7, [rsp]
000079a3731d7dfd  add rsp, 0x30
000079a3731d7e01  vmovaps xmm0, [rsp]
000079a3731d7e06  vmovaps xmm1, [rsp+0x10]
000079a3731d7e0c  vmovaps xmm2, [rsp+0x20]
000079a3731d7e12  vmovaps xmm3, [rsp+0x30]
000079a3731d7e18  vmovaps xmm4, [rsp+0x40]
000079a3731d7e1e  vmovaps xmm5, [rsp+0x50]
000079a3731d7e24  vmovaps xmm6, [rsp+0x60]
000079a3731d7e2a  vmovaps xmm8, [rsp+0x70]
000079a3731d7e30  vmovaps xmm9, [rsp+0x80]
000079a3731d7e39  vmovaps xmm10, [rsp+0x90]
000079a3731d7e42  vmovaps xmm11, [rsp+0xA0]
000079a3731d7e4b  vmovaps xmm12, [rsp+0xB0]
000079a3731d7e54  vmovaps xmm13, [rsp+0xC0]
000079a3731d7e5d  vmovaps xmm14, [rsp+0xD0]
000079a3731d7e66  vmovaps xmm15, [rsp+0xE0]
000079a3731d7e6f  add rsp, 0xF0
000079a3731d7e76  pop r11
000079a3731d7e78  pop r10
000079a3731d7e7a  pop r9
000079a3731d7e7c  pop r8
000079a3731d7e7e  pop rsi
000079a3731d7e7f  pop rdi
000079a3731d7e80  pop rdx
000079a3731d7e81  pop rcx
000079a3731d7e82  pop rax
000079a3731d7e83  add rsp, 0x08
000079a3731d7e87  jmp 0x000079A3731D5EB3
000079a3731d7e8c  call 0x000079A3730D64F0
000079a3731d7e91  jmp 0x000079A3731D5EC0
000079a3731d7e96  sub rsp, 0x08
000079a3731d7e9a  push rax
000079a3731d7e9b  push rcx
000079a3731d7e9c  push rdx
000079a3731d7e9d  push rdi
000079a3731d7e9e  push rsi
000079a3731d7e9f  push r8
000079a3731d7ea1  push r9
000079a3731d7ea3  push r10
000079a3731d7ea5  push r11
000079a3731d7ea7  sub rsp, 0xF0
000079a3731d7eae  vmovaps [rsp], xmm0
000079a3731d7eb3  vmovaps [rsp+0x10], xmm1
000079a3731d7eb9  vmovaps [rsp+0x20], xmm2
000079a3731d7ebf  vmovaps [rsp+0x30], xmm3
000079a3731d7ec5  vmovaps [rsp+0x40], xmm4
000079a3731d7ecb  vmovaps [rsp+0x50], xmm5
000079a3731d7ed1  vmovaps [rsp+0x60], xmm6
000079a3731d7ed7  vmovaps [rsp+0x70], xmm7
000079a3731d7edd  vmovaps [rsp+0x80], xmm8
000079a3731d7ee6  vmovaps [rsp+0x90], xmm9
000079a3731d7eef  vmovaps [rsp+0xA0], xmm10
000079a3731d7ef8  vmovaps [rsp+0xB0], xmm11
000079a3731d7f01  vmovaps [rsp+0xC0], xmm12
000079a3731d7f0a  vmovaps [rsp+0xD0], xmm13
000079a3731d7f13  vmovaps [rsp+0xE0], xmm14
000079a3731d7f1c  sub rsp, 0x30
000079a3731d7f20  movaps [rsp], xmm15
000079a3731d7f25  movaps [rsp+0x10], xmm5
000079a3731d7f2a  movaps [rsp+0x20], xmm3
000079a3731d7f2f  lea rdi, [rsp]
000079a3731d7f33  mov esi, 0x00
000079a3731d7f38  mov rax, 0x64F127B95530
000079a3731d7f42  call rax
000079a3731d7f44  movaps xmm15, [rsp]
000079a3731d7f49  add rsp, 0x30
000079a3731d7f4d  vmovaps xmm0, [rsp]
000079a3731d7f52  vmovaps xmm1, [rsp+0x10]
000079a3731d7f58  vmovaps xmm2, [rsp+0x20]
000079a3731d7f5e  vmovaps xmm3, [rsp+0x30]
000079a3731d7f64  vmovaps xmm4, [rsp+0x40]
000079a3731d7f6a  vmovaps xmm5, [rsp+0x50]
000079a3731d7f70  vmovaps xmm6, [rsp+0x60]
000079a3731d7f76  vmovaps xmm7, [rsp+0x70]
000079a3731d7f7c  vmovaps xmm8, [rsp+0x80]
000079a3731d7f85  vmovaps xmm9, [rsp+0x90]
000079a3731d7f8e  vmovaps xmm10, [rsp+0xA0]
000079a3731d7f97  vmovaps xmm11, [rsp+0xB0]
000079a3731d7fa0  vmovaps xmm12, [rsp+0xC0]
000079a3731d7fa9  vmovaps xmm13, [rsp+0xD0]
000079a3731d7fb2  vmovaps xmm14, [rsp+0xE0]
000079a3731d7fbb  add rsp, 0xF0
000079a3731d7fc2  pop r11
000079a3731d7fc4  pop r10
000079a3731d7fc6  pop r9
000079a3731d7fc8  pop r8
000079a3731d7fca  pop rsi
000079a3731d7fcb  pop rdi
000079a3731d7fcc  pop rdx
000079a3731d7fcd  pop rcx
000079a3731d7fce  pop rax
000079a3731d7fcf  add rsp, 0x08
000079a3731d7fd3  jmp 0x000079A3731D5EE6
000079a3731d7fd8  sub rsp, 0x08
000079a3731d7fdc  push rax
000079a3731d7fdd  push rcx
000079a3731d7fde  push rdx
000079a3731d7fdf  push rdi
000079a3731d7fe0  push rsi
000079a3731d7fe1  push r8
000079a3731d7fe3  push r9
000079a3731d7fe5  push r10
000079a3731d7fe7  push r11
000079a3731d7fe9  sub rsp, 0xF0
000079a3731d7ff0  vmovaps [rsp], xmm0
000079a3731d7ff5  vmovaps [rsp+0x10], xmm2
000079a3731d7ffb  vmovaps [rsp+0x20], xmm3
000079a3731d8001  vmovaps [rsp+0x30], xmm4
000079a3731d8007  vmovaps [rsp+0x40], xmm5
000079a3731d800d  vmovaps [rsp+0x50], xmm6
000079a3731d8013  vmovaps [rsp+0x60], xmm7
000079a3731d8019  vmovaps [rsp+0x70], xmm8
000079a3731d801f  vmovaps [rsp+0x80], xmm9
000079a3731d8028  vmovaps [rsp+0x90], xmm10
000079a3731d8031  vmovaps [rsp+0xA0], xmm11
000079a3731d803a  vmovaps [rsp+0xB0], xmm12
000079a3731d8043  vmovaps [rsp+0xC0], xmm13
000079a3731d804c  vmovaps [rsp+0xD0], xmm14
000079a3731d8055  vmovaps [rsp+0xE0], xmm15
000079a3731d805e  sub rsp, 0x30
000079a3731d8062  movaps [rsp], xmm1
000079a3731d8066  movaps [rsp+0x10], xmm5
000079a3731d806b  movaps [rsp+0x20], xmm4
000079a3731d8070  lea rdi, [rsp]
000079a3731d8074  mov esi, 0x00
000079a3731d8079  mov rax, 0x64F127B95530
000079a3731d8083  call rax
000079a3731d8085  movaps xmm1, [rsp]
000079a3731d8089  add rsp, 0x30
000079a3731d808d  vmovaps xmm0, [rsp]
000079a3731d8092  vmovaps xmm2, [rsp+0x10]
000079a3731d8098  vmovaps xmm3, [rsp+0x20]
000079a3731d809e  vmovaps xmm4, [rsp+0x30]
000079a3731d80a4  vmovaps xmm5, [rsp+0x40]
000079a3731d80aa  vmovaps xmm6, [rsp+0x50]
000079a3731d80b0  vmovaps xmm7, [rsp+0x60]
000079a3731d80b6  vmovaps xmm8, [rsp+0x70]
000079a3731d80bc  vmovaps xmm9, [rsp+0x80]
000079a3731d80c5  vmovaps xmm10, [rsp+0x90]
000079a3731d80ce  vmovaps xmm11, [rsp+0xA0]
000079a3731d80d7  vmovaps xmm12, [rsp+0xB0]
000079a3731d80e0  vmovaps xmm13, [rsp+0xC0]
000079a3731d80e9  vmovaps xmm14, [rsp+0xD0]
000079a3731d80f2  vmovaps xmm15, [rsp+0xE0]
000079a3731d80fb  add rsp, 0xF0
000079a3731d8102  pop r11
000079a3731d8104  pop r10
000079a3731d8106  pop r9
000079a3731d8108  pop r8
000079a3731d810a  pop rsi
000079a3731d810b  pop rdi
000079a3731d810c  pop rdx
000079a3731d810d  pop rcx
000079a3731d810e  pop rax
000079a3731d810f  add rsp, 0x08
000079a3731d8113  jmp 0x000079A3731D5F06
000079a3731d8118  sub rsp, 0x08
000079a3731d811c  push rax
000079a3731d811d  push rcx
000079a3731d811e  push rdx
000079a3731d811f  push rdi
000079a3731d8120  push rsi
000079a3731d8121  push r8
000079a3731d8123  push r9
000079a3731d8125  push r10
000079a3731d8127  push r11
000079a3731d8129  sub rsp, 0xF0
000079a3731d8130  vmovaps [rsp], xmm0
000079a3731d8135  vmovaps [rsp+0x10], xmm1
000079a3731d813b  vmovaps [rsp+0x20], xmm2
000079a3731d8141  vmovaps [rsp+0x30], xmm3
000079a3731d8147  vmovaps [rsp+0x40], xmm5
000079a3731d814d  vmovaps [rsp+0x50], xmm6
000079a3731d8153  vmovaps [rsp+0x60], xmm7
000079a3731d8159  vmovaps [rsp+0x70], xmm8
000079a3731d815f  vmovaps [rsp+0x80], xmm9
000079a3731d8168  vmovaps [rsp+0x90], xmm10
000079a3731d8171  vmovaps [rsp+0xA0], xmm11
000079a3731d817a  vmovaps [rsp+0xB0], xmm12
000079a3731d8183  vmovaps [rsp+0xC0], xmm13
000079a3731d818c  vmovaps [rsp+0xD0], xmm14
000079a3731d8195  vmovaps [rsp+0xE0], xmm15
000079a3731d819e  sub rsp, 0x30
000079a3731d81a2  movaps [rsp], xmm4
000079a3731d81a6  movaps [rsp+0x10], xmm3
000079a3731d81ab  movaps [rsp+0x20], xmm5
000079a3731d81b0  lea rdi, [rsp]
000079a3731d81b4  mov esi, 0x00
000079a3731d81b9  mov rax, 0x64F127B95530
000079a3731d81c3  call rax
000079a3731d81c5  movaps xmm4, [rsp]
000079a3731d81c9  add rsp, 0x30
000079a3731d81cd  vmovaps xmm0, [rsp]
000079a3731d81d2  vmovaps xmm1, [rsp+0x10]
000079a3731d81d8  vmovaps xmm2, [rsp+0x20]
000079a3731d81de  vmovaps xmm3, [rsp+0x30]
000079a3731d81e4  vmovaps xmm5, [rsp+0x40]
000079a3731d81ea  vmovaps xmm6, [rsp+0x50]
000079a3731d81f0  vmovaps xmm7, [rsp+0x60]
000079a3731d81f6  vmovaps xmm8, [rsp+0x70]
000079a3731d81fc  vmovaps xmm9, [rsp+0x80]
000079a3731d8205  vmovaps xmm10, [rsp+0x90]
000079a3731d820e  vmovaps xmm11, [rsp+0xA0]
000079a3731d8217  vmovaps xmm12, [rsp+0xB0]
000079a3731d8220  vmovaps xmm13, [rsp+0xC0]
000079a3731d8229  vmovaps xmm14, [rsp+0xD0]
000079a3731d8232  vmovaps xmm15, [rsp+0xE0]
000079a3731d823b  add rsp, 0xF0
000079a3731d8242  pop r11
000079a3731d8244  pop r10
000079a3731d8246  pop r9
000079a3731d8248  pop r8
000079a3731d824a  pop rsi
000079a3731d824b  pop rdi
000079a3731d824c  pop rdx
000079a3731d824d  pop rcx
000079a3731d824e  pop rax
000079a3731d824f  add rsp, 0x08
000079a3731d8253  jmp 0x000079A3731D5F54
000079a3731d8258  call 0x000079A3730D64F0
000079a3731d825d  jmp 0x000079A3731D5F61
000079a3731d8262  sub rsp, 0x08
000079a3731d8266  push rax
000079a3731d8267  push rcx
000079a3731d8268  push rdx
000079a3731d8269  push rdi
000079a3731d826a  push rsi
000079a3731d826b  push r8
000079a3731d826d  push r9
000079a3731d826f  push r10
000079a3731d8271  push r11
000079a3731d8273  sub rsp, 0xF0
000079a3731d827a  vmovaps [rsp], xmm0
000079a3731d827f  vmovaps [rsp+0x10], xmm1
000079a3731d8285  vmovaps [rsp+0x20], xmm2
000079a3731d828b  vmovaps [rsp+0x30], xmm3
000079a3731d8291  vmovaps [rsp+0x40], xmm4
000079a3731d8297  vmovaps [rsp+0x50], xmm6
000079a3731d829d  vmovaps [rsp+0x60], xmm7
000079a3731d82a3  vmovaps [rsp+0x70], xmm8
000079a3731d82a9  vmovaps [rsp+0x80], xmm9
000079a3731d82b2  vmovaps [rsp+0x90], xmm10
000079a3731d82bb  vmovaps [rsp+0xA0], xmm11
000079a3731d82c4  vmovaps [rsp+0xB0], xmm12
000079a3731d82cd  vmovaps [rsp+0xC0], xmm13
000079a3731d82d6  vmovaps [rsp+0xD0], xmm14
000079a3731d82df  vmovaps [rsp+0xE0], xmm15
000079a3731d82e8  sub rsp, 0x30
000079a3731d82ec  movaps [rsp], xmm5
000079a3731d82f0  movaps [rsp+0x10], xmm6
000079a3731d82f5  movaps [rsp+0x20], xmm3
000079a3731d82fa  lea rdi, [rsp]
000079a3731d82fe  mov esi, 0x00
000079a3731d8303  mov rax, 0x64F127B95530
000079a3731d830d  call rax
000079a3731d830f  movaps xmm5, [rsp]
000079a3731d8313  add rsp, 0x30
000079a3731d8317  vmovaps xmm0, [rsp]
000079a3731d831c  vmovaps xmm1, [rsp+0x10]
000079a3731d8322  vmovaps xmm2, [rsp+0x20]
000079a3731d8328  vmovaps xmm3, [rsp+0x30]
000079a3731d832e  vmovaps xmm4, [rsp+0x40]
000079a3731d8334  vmovaps xmm6, [rsp+0x50]
000079a3731d833a  vmovaps xmm7, [rsp+0x60]
000079a3731d8340  vmovaps xmm8, [rsp+0x70]
000079a3731d8346  vmovaps xmm9, [rsp+0x80]
000079a3731d834f  vmovaps xmm10, [rsp+0x90]
000079a3731d8358  vmovaps xmm11, [rsp+0xA0]
000079a3731d8361  vmovaps xmm12, [rsp+0xB0]
000079a3731d836a  vmovaps xmm13, [rsp+0xC0]
000079a3731d8373  vmovaps xmm14, [rsp+0xD0]
000079a3731d837c  vmovaps xmm15, [rsp+0xE0]
000079a3731d8385  add rsp, 0xF0
000079a3731d838c  pop r11
000079a3731d838e  pop r10
000079a3731d8390  pop r9
000079a3731d8392  pop r8
000079a3731d8394  pop rsi
000079a3731d8395  pop rdi
000079a3731d8396  pop rdx
000079a3731d8397  pop rcx
000079a3731d8398  pop rax
000079a3731d8399  add rsp, 0x08
000079a3731d839d  jmp 0x000079A3731D5F87
000079a3731d83a2  sub rsp, 0x08
000079a3731d83a6  push rax
000079a3731d83a7  push rcx
000079a3731d83a8  push rdx
000079a3731d83a9  push rdi
000079a3731d83aa  push rsi
000079a3731d83ab  push r8
000079a3731d83ad  push r9
000079a3731d83af  push r10
000079a3731d83b1  push r11
000079a3731d83b3  sub rsp, 0xF0
000079a3731d83ba  vmovaps [rsp], xmm0
000079a3731d83bf  vmovaps [rsp+0x10], xmm1
000079a3731d83c5  vmovaps [rsp+0x20], xmm2
000079a3731d83cb  vmovaps [rsp+0x30], xmm3
000079a3731d83d1  vmovaps [rsp+0x40], xmm4
000079a3731d83d7  vmovaps [rsp+0x50], xmm5
000079a3731d83dd  vmovaps [rsp+0x60], xmm7
000079a3731d83e3  vmovaps [rsp+0x70], xmm8
000079a3731d83e9  vmovaps [rsp+0x80], xmm9
000079a3731d83f2  vmovaps [rsp+0x90], xmm10
000079a3731d83fb  vmovaps [rsp+0xA0], xmm11
000079a3731d8404  vmovaps [rsp+0xB0], xmm12
000079a3731d840d  vmovaps [rsp+0xC0], xmm13
000079a3731d8416  vmovaps [rsp+0xD0], xmm14
000079a3731d841f  vmovaps [rsp+0xE0], xmm15
000079a3731d8428  sub rsp, 0x30
000079a3731d842c  movaps [rsp], xmm6
000079a3731d8430  movaps [rsp+0x10], xmm9
000079a3731d8436  movaps [rsp+0x20], xmm1
000079a3731d843b  lea rdi, [rsp]
000079a3731d843f  mov esi, 0x00
000079a3731d8444  mov rax, 0x64F127B95530
000079a3731d844e  call rax
000079a3731d8450  movaps xmm6, [rsp]
000079a3731d8454  add rsp, 0x30
000079a3731d8458  vmovaps xmm0, [rsp]
000079a3731d845d  vmovaps xmm1, [rsp+0x10]
000079a3731d8463  vmovaps xmm2, [rsp+0x20]
000079a3731d8469  vmovaps xmm3, [rsp+0x30]
000079a3731d846f  vmovaps xmm4, [rsp+0x40]
000079a3731d8475  vmovaps xmm5, [rsp+0x50]
000079a3731d847b  vmovaps xmm7, [rsp+0x60]
000079a3731d8481  vmovaps xmm8, [rsp+0x70]
000079a3731d8487  vmovaps xmm9, [rsp+0x80]
000079a3731d8490  vmovaps xmm10, [rsp+0x90]
000079a3731d8499  vmovaps xmm11, [rsp+0xA0]
000079a3731d84a2  vmovaps xmm12, [rsp+0xB0]
000079a3731d84ab  vmovaps xmm13, [rsp+0xC0]
000079a3731d84b4  vmovaps xmm14, [rsp+0xD0]
000079a3731d84bd  vmovaps xmm15, [rsp+0xE0]
000079a3731d84c6  add rsp, 0xF0
000079a3731d84cd  pop r11
000079a3731d84cf  pop r10
000079a3731d84d1  pop r9
000079a3731d84d3  pop r8
000079a3731d84d5  pop rsi
000079a3731d84d6  pop rdi
000079a3731d84d7  pop rdx
000079a3731d84d8  pop rcx
000079a3731d84d9  pop rax
000079a3731d84da  add rsp, 0x08
000079a3731d84de  jmp 0x000079A3731D5FAB
000079a3731d84e3  sub rsp, 0x08
000079a3731d84e7  push rax
000079a3731d84e8  push rcx
000079a3731d84e9  push rdx
000079a3731d84ea  push rdi
000079a3731d84eb  push rsi
000079a3731d84ec  push r8
000079a3731d84ee  push r9
000079a3731d84f0  push r10
000079a3731d84f2  push r11
000079a3731d84f4  sub rsp, 0xF0
000079a3731d84fb  vmovaps [rsp], xmm0
000079a3731d8500  vmovaps [rsp+0x10], xmm1
000079a3731d8506  vmovaps [rsp+0x20], xmm2
000079a3731d850c  vmovaps [rsp+0x30], xmm3
000079a3731d8512  vmovaps [rsp+0x40], xmm4
000079a3731d8518  vmovaps [rsp+0x50], xmm5
000079a3731d851e  vmovaps [rsp+0x60], xmm6
000079a3731d8524  vmovaps [rsp+0x70], xmm7
000079a3731d852a  vmovaps [rsp+0x80], xmm8
000079a3731d8533  vmovaps [rsp+0x90], xmm10
000079a3731d853c  vmovaps [rsp+0xA0], xmm11
000079a3731d8545  vmovaps [rsp+0xB0], xmm12
000079a3731d854e  vmovaps [rsp+0xC0], xmm13
000079a3731d8557  vmovaps [rsp+0xD0], xmm14
000079a3731d8560  vmovaps [rsp+0xE0], xmm15
000079a3731d8569  sub rsp, 0x30
000079a3731d856d  movaps [rsp], xmm9
000079a3731d8572  movaps [rsp+0x10], xmm3
000079a3731d8577  movaps [rsp+0x20], xmm1
000079a3731d857c  lea rdi, [rsp]
000079a3731d8580  mov esi, 0x00
000079a3731d8585  mov rax, 0x64F127B95530
000079a3731d858f  call rax
000079a3731d8591  movaps xmm9, [rsp]
000079a3731d8596  add rsp, 0x30
000079a3731d859a  vmovaps xmm0, [rsp]
000079a3731d859f  vmovaps xmm1, [rsp+0x10]
000079a3731d85a5  vmovaps xmm2, [rsp+0x20]
000079a3731d85ab  vmovaps xmm3, [rsp+0x30]
000079a3731d85b1  vmovaps xmm4, [rsp+0x40]
000079a3731d85b7  vmovaps xmm5, [rsp+0x50]
000079a3731d85bd  vmovaps xmm6, [rsp+0x60]
000079a3731d85c3  vmovaps xmm7, [rsp+0x70]
000079a3731d85c9  vmovaps xmm8, [rsp+0x80]
000079a3731d85d2  vmovaps xmm10, [rsp+0x90]
000079a3731d85db  vmovaps xmm11, [rsp+0xA0]
000079a3731d85e4  vmovaps xmm12, [rsp+0xB0]
000079a3731d85ed  vmovaps xmm13, [rsp+0xC0]
000079a3731d85f6  vmovaps xmm14, [rsp+0xD0]
000079a3731d85ff  vmovaps xmm15, [rsp+0xE0]
000079a3731d8608  add rsp, 0xF0
000079a3731d860f  pop r11
000079a3731d8611  pop r10
000079a3731d8613  pop r9
000079a3731d8615  pop r8
000079a3731d8617  pop rsi
000079a3731d8618  pop rdi
000079a3731d8619  pop rdx
000079a3731d861a  pop rcx
000079a3731d861b  pop rax
000079a3731d861c  add rsp, 0x08
000079a3731d8620  jmp 0x000079A3731D5FF7
000079a3731d8625  call 0x000079A3730D64F0
000079a3731d862a  jmp 0x000079A3731D6004
000079a3731d862f  sub rsp, 0x08
000079a3731d8633  push rax
000079a3731d8634  push rcx
000079a3731d8635  push rdx
000079a3731d8636  push rdi
000079a3731d8637  push rsi
000079a3731d8638  push r8
000079a3731d863a  push r9
000079a3731d863c  push r10
000079a3731d863e  push r11
000079a3731d8640  sub rsp, 0xF0
000079a3731d8647  vmovaps [rsp], xmm0
000079a3731d864c  vmovaps [rsp+0x10], xmm1
000079a3731d8652  vmovaps [rsp+0x20], xmm2
000079a3731d8658  vmovaps [rsp+0x30], xmm3
000079a3731d865e  vmovaps [rsp+0x40], xmm4
000079a3731d8664  vmovaps [rsp+0x50], xmm5
000079a3731d866a  vmovaps [rsp+0x60], xmm6
000079a3731d8670  vmovaps [rsp+0x70], xmm7
000079a3731d8676  vmovaps [rsp+0x80], xmm8
000079a3731d867f  vmovaps [rsp+0x90], xmm9
000079a3731d8688  vmovaps [rsp+0xA0], xmm10
000079a3731d8691  vmovaps [rsp+0xB0], xmm11
000079a3731d869a  vmovaps [rsp+0xC0], xmm12
000079a3731d86a3  vmovaps [rsp+0xD0], xmm13
000079a3731d86ac  vmovaps [rsp+0xE0], xmm14
000079a3731d86b5  sub rsp, 0x30
000079a3731d86b9  movaps [rsp], xmm15
000079a3731d86be  movaps [rsp+0x10], xmm3
000079a3731d86c3  movaps [rsp+0x20], xmm7
000079a3731d86c8  lea rdi, [rsp]
000079a3731d86cc  mov esi, 0x00
000079a3731d86d1  mov rax, 0x64F127B95530
000079a3731d86db  call rax
000079a3731d86dd  movaps xmm15, [rsp]
000079a3731d86e2  add rsp, 0x30
000079a3731d86e6  vmovaps xmm0, [rsp]
000079a3731d86eb  vmovaps xmm1, [rsp+0x10]
000079a3731d86f1  vmovaps xmm2, [rsp+0x20]
000079a3731d86f7  vmovaps xmm3, [rsp+0x30]
000079a3731d86fd  vmovaps xmm4, [rsp+0x40]
000079a3731d8703  vmovaps xmm5, [rsp+0x50]
000079a3731d8709  vmovaps xmm6, [rsp+0x60]
000079a3731d870f  vmovaps xmm7, [rsp+0x70]
000079a3731d8715  vmovaps xmm8, [rsp+0x80]
000079a3731d871e  vmovaps xmm9, [rsp+0x90]
000079a3731d8727  vmovaps xmm10, [rsp+0xA0]
000079a3731d8730  vmovaps xmm11, [rsp+0xB0]
000079a3731d8739  vmovaps xmm12, [rsp+0xC0]
000079a3731d8742  vmovaps xmm13, [rsp+0xD0]
000079a3731d874b  vmovaps xmm14, [rsp+0xE0]
000079a3731d8754  add rsp, 0xF0
000079a3731d875b  pop r11
000079a3731d875d  pop r10
000079a3731d875f  pop r9
000079a3731d8761  pop r8
000079a3731d8763  pop rsi
000079a3731d8764  pop rdi
000079a3731d8765  pop rdx
000079a3731d8766  pop rcx
000079a3731d8767  pop rax
000079a3731d8768  add rsp, 0x08
000079a3731d876c  jmp 0x000079A3731D6030
000079a3731d8771  sub rsp, 0x08
000079a3731d8775  push rax
000079a3731d8776  push rcx
000079a3731d8777  push rdx
000079a3731d8778  push rdi
000079a3731d8779  push rsi
000079a3731d877a  push r8
000079a3731d877c  push r9
000079a3731d877e  push r10
000079a3731d8780  push r11
000079a3731d8782  sub rsp, 0xF0
000079a3731d8789  vmovaps [rsp], xmm0
000079a3731d878e  vmovaps [rsp+0x10], xmm1
000079a3731d8794  vmovaps [rsp+0x20], xmm2
000079a3731d879a  vmovaps [rsp+0x30], xmm4
000079a3731d87a0  vmovaps [rsp+0x40], xmm5
000079a3731d87a6  vmovaps [rsp+0x50], xmm6
000079a3731d87ac  vmovaps [rsp+0x60], xmm7
000079a3731d87b2  vmovaps [rsp+0x70], xmm8
000079a3731d87b8  vmovaps [rsp+0x80], xmm9
000079a3731d87c1  vmovaps [rsp+0x90], xmm10
000079a3731d87ca  vmovaps [rsp+0xA0], xmm11
000079a3731d87d3  vmovaps [rsp+0xB0], xmm12
000079a3731d87dc  vmovaps [rsp+0xC0], xmm13
000079a3731d87e5  vmovaps [rsp+0xD0], xmm14
000079a3731d87ee  vmovaps [rsp+0xE0], xmm15
000079a3731d87f7  sub rsp, 0x30
000079a3731d87fb  movaps [rsp], xmm3
000079a3731d87ff  movaps [rsp+0x10], xmm1
000079a3731d8804  movaps [rsp+0x20], xmm15
000079a3731d880a  lea rdi, [rsp]
000079a3731d880e  mov esi, 0x00
000079a3731d8813  mov rax, 0x64F127B95530
000079a3731d881d  call rax
000079a3731d881f  movaps xmm3, [rsp]
000079a3731d8823  add rsp, 0x30
000079a3731d8827  vmovaps xmm0, [rsp]
000079a3731d882c  vmovaps xmm1, [rsp+0x10]
000079a3731d8832  vmovaps xmm2, [rsp+0x20]
000079a3731d8838  vmovaps xmm4, [rsp+0x30]
000079a3731d883e  vmovaps xmm5, [rsp+0x40]
000079a3731d8844  vmovaps xmm6, [rsp+0x50]
000079a3731d884a  vmovaps xmm7, [rsp+0x60]
000079a3731d8850  vmovaps xmm8, [rsp+0x70]
000079a3731d8856  vmovaps xmm9, [rsp+0x80]
000079a3731d885f  vmovaps xmm10, [rsp+0x90]
000079a3731d8868  vmovaps xmm11, [rsp+0xA0]
000079a3731d8871  vmovaps xmm12, [rsp+0xB0]
000079a3731d887a  vmovaps xmm13, [rsp+0xC0]
000079a3731d8883  vmovaps xmm14, [rsp+0xD0]
000079a3731d888c  vmovaps xmm15, [rsp+0xE0]
000079a3731d8895  add rsp, 0xF0
000079a3731d889c  pop r11
000079a3731d889e  pop r10
000079a3731d88a0  pop r9
000079a3731d88a2  pop r8
000079a3731d88a4  pop rsi
000079a3731d88a5  pop rdi
000079a3731d88a6  pop rdx
000079a3731d88a7  pop rcx
000079a3731d88a8  pop rax
000079a3731d88a9  add rsp, 0x08
000079a3731d88ad  jmp 0x000079A3731D60BF
000079a3731d88b2  call 0x000079A3730D64F0
000079a3731d88b7  jmp 0x000079A3731D60C9
000079a3731d88bc  sub rsp, 0x08
000079a3731d88c0  push rax
000079a3731d88c1  push rcx
000079a3731d88c2  push rdx
000079a3731d88c3  push rdi
000079a3731d88c4  push rsi
000079a3731d88c5  push r8
000079a3731d88c7  push r9
000079a3731d88c9  push r10
000079a3731d88cb  push r11
000079a3731d88cd  sub rsp, 0xF0
000079a3731d88d4  vmovaps [rsp], xmm0
000079a3731d88d9  vmovaps [rsp+0x10], xmm1
000079a3731d88df  vmovaps [rsp+0x20], xmm2
000079a3731d88e5  vmovaps [rsp+0x30], xmm3
000079a3731d88eb  vmovaps [rsp+0x40], xmm4
000079a3731d88f1  vmovaps [rsp+0x50], xmm5
000079a3731d88f7  vmovaps [rsp+0x60], xmm6
000079a3731d88fd  vmovaps [rsp+0x70], xmm7
000079a3731d8903  vmovaps [rsp+0x80], xmm8
000079a3731d890c  vmovaps [rsp+0x90], xmm9
000079a3731d8915  vmovaps [rsp+0xA0], xmm10
000079a3731d891e  vmovaps [rsp+0xB0], xmm11
000079a3731d8927  vmovaps [rsp+0xC0], xmm12
000079a3731d8930  vmovaps [rsp+0xD0], xmm13
000079a3731d8939  vmovaps [rsp+0xE0], xmm14
000079a3731d8942  sub rsp, 0x30
000079a3731d8946  movaps [rsp], xmm15
000079a3731d894b  movaps [rsp+0x10], xmm14
000079a3731d8951  movaps [rsp+0x20], xmm4
000079a3731d8956  lea rdi, [rsp]
000079a3731d895a  mov esi, 0x00
000079a3731d895f  mov rax, 0x64F127B95530
000079a3731d8969  call rax
000079a3731d896b  movaps xmm15, [rsp]
000079a3731d8970  add rsp, 0x30
000079a3731d8974  vmovaps xmm0, [rsp]
000079a3731d8979  vmovaps xmm1, [rsp+0x10]
000079a3731d897f  vmovaps xmm2, [rsp+0x20]
000079a3731d8985  vmovaps xmm3, [rsp+0x30]
000079a3731d898b  vmovaps xmm4, [rsp+0x40]
000079a3731d8991  vmovaps xmm5, [rsp+0x50]
000079a3731d8997  vmovaps xmm6, [rsp+0x60]
000079a3731d899d  vmovaps xmm7, [rsp+0x70]
000079a3731d89a3  vmovaps xmm8, [rsp+0x80]
000079a3731d89ac  vmovaps xmm9, [rsp+0x90]
000079a3731d89b5  vmovaps xmm10, [rsp+0xA0]
000079a3731d89be  vmovaps xmm11, [rsp+0xB0]
000079a3731d89c7  vmovaps xmm12, [rsp+0xC0]
000079a3731d89d0  vmovaps xmm13, [rsp+0xD0]
000079a3731d89d9  vmovaps xmm14, [rsp+0xE0]
000079a3731d89e2  add rsp, 0xF0
000079a3731d89e9  pop r11
000079a3731d89eb  pop r10
000079a3731d89ed  pop r9
000079a3731d89ef  pop r8
000079a3731d89f1  pop rsi
000079a3731d89f2  pop rdi
000079a3731d89f3  pop rdx
000079a3731d89f4  pop rcx
000079a3731d89f5  pop rax
000079a3731d89f6  add rsp, 0x08
000079a3731d89fa  jmp 0x000079A3731D60F7
000079a3731d89ff  sub rsp, 0x08
000079a3731d8a03  push rax
000079a3731d8a04  push rcx
000079a3731d8a05  push rdx
000079a3731d8a06  push rdi
000079a3731d8a07  push rsi
000079a3731d8a08  push r8
000079a3731d8a0a  push r9
000079a3731d8a0c  push r10
000079a3731d8a0e  push r11
000079a3731d8a10  sub rsp, 0xF0
000079a3731d8a17  vmovaps [rsp], xmm0
000079a3731d8a1c  vmovaps [rsp+0x10], xmm1
000079a3731d8a22  vmovaps [rsp+0x20], xmm2
000079a3731d8a28  vmovaps [rsp+0x30], xmm3
000079a3731d8a2e  vmovaps [rsp+0x40], xmm4
000079a3731d8a34  vmovaps [rsp+0x50], xmm5
000079a3731d8a3a  vmovaps [rsp+0x60], xmm6
000079a3731d8a40  vmovaps [rsp+0x70], xmm7
000079a3731d8a46  vmovaps [rsp+0x80], xmm8
000079a3731d8a4f  vmovaps [rsp+0x90], xmm9
000079a3731d8a58  vmovaps [rsp+0xA0], xmm10
000079a3731d8a61  vmovaps [rsp+0xB0], xmm11
000079a3731d8a6a  vmovaps [rsp+0xC0], xmm12
000079a3731d8a73  vmovaps [rsp+0xD0], xmm13
000079a3731d8a7c  vmovaps [rsp+0xE0], xmm15
000079a3731d8a85  sub rsp, 0x30
000079a3731d8a89  movaps [rsp], xmm14
000079a3731d8a8e  movaps [rsp+0x10], xmm2
000079a3731d8a93  movaps [rsp+0x20], xmm1
000079a3731d8a98  lea rdi, [rsp]
000079a3731d8a9c  mov esi, 0x00
000079a3731d8aa1  mov rax, 0x64F127B95530
000079a3731d8aab  call rax
000079a3731d8aad  movaps xmm14, [rsp]
000079a3731d8ab2  add rsp, 0x30
000079a3731d8ab6  vmovaps xmm0, [rsp]
000079a3731d8abb  vmovaps xmm1, [rsp+0x10]
000079a3731d8ac1  vmovaps xmm2, [rsp+0x20]
000079a3731d8ac7  vmovaps xmm3, [rsp+0x30]
000079a3731d8acd  vmovaps xmm4, [rsp+0x40]
000079a3731d8ad3  vmovaps xmm5, [rsp+0x50]
000079a3731d8ad9  vmovaps xmm6, [rsp+0x60]
000079a3731d8adf  vmovaps xmm7, [rsp+0x70]
000079a3731d8ae5  vmovaps xmm8, [rsp+0x80]
000079a3731d8aee  vmovaps xmm9, [rsp+0x90]
000079a3731d8af7  vmovaps xmm10, [rsp+0xA0]
000079a3731d8b00  vmovaps xmm11, [rsp+0xB0]
000079a3731d8b09  vmovaps xmm12, [rsp+0xC0]
000079a3731d8b12  vmovaps xmm13, [rsp+0xD0]
000079a3731d8b1b  vmovaps xmm15, [rsp+0xE0]
000079a3731d8b24  add rsp, 0xF0
000079a3731d8b2b  pop r11
000079a3731d8b2d  pop r10
000079a3731d8b2f  pop r9
000079a3731d8b31  pop r8
000079a3731d8b33  pop rsi
000079a3731d8b34  pop rdi
000079a3731d8b35  pop rdx
000079a3731d8b36  pop rcx
000079a3731d8b37  pop rax
000079a3731d8b38  add rsp, 0x08
000079a3731d8b3c  jmp 0x000079A3731D611D
000079a3731d8b41  sub rsp, 0x08
000079a3731d8b45  push rax
000079a3731d8b46  push rcx
000079a3731d8b47  push rdx
000079a3731d8b48  push rdi
000079a3731d8b49  push rsi
000079a3731d8b4a  push r8
000079a3731d8b4c  push r9
000079a3731d8b4e  push r10
000079a3731d8b50  push r11
000079a3731d8b52  sub rsp, 0xF0
000079a3731d8b59  vmovaps [rsp], xmm0
000079a3731d8b5e  vmovaps [rsp+0x10], xmm2
000079a3731d8b64  vmovaps [rsp+0x20], xmm3
000079a3731d8b6a  vmovaps [rsp+0x30], xmm4
000079a3731d8b70  vmovaps [rsp+0x40], xmm5
000079a3731d8b76  vmovaps [rsp+0x50], xmm6
000079a3731d8b7c  vmovaps [rsp+0x60], xmm7
000079a3731d8b82  vmovaps [rsp+0x70], xmm8
000079a3731d8b88  vmovaps [rsp+0x80], xmm9
000079a3731d8b91  vmovaps [rsp+0x90], xmm10
000079a3731d8b9a  vmovaps [rsp+0xA0], xmm11
000079a3731d8ba3  vmovaps [rsp+0xB0], xmm12
000079a3731d8bac  vmovaps [rsp+0xC0], xmm13
000079a3731d8bb5  vmovaps [rsp+0xD0], xmm14
000079a3731d8bbe  vmovaps [rsp+0xE0], xmm15
000079a3731d8bc7  sub rsp, 0x30
000079a3731d8bcb  movaps [rsp], xmm1
000079a3731d8bcf  movaps [rsp+0x10], xmm4
000079a3731d8bd4  movaps [rsp+0x20], xmm9
000079a3731d8bda  lea rdi, [rsp]
000079a3731d8bde  mov esi, 0x00
000079a3731d8be3  mov rax, 0x64F127B95530
000079a3731d8bed  call rax
000079a3731d8bef  movaps xmm1, [rsp]
000079a3731d8bf3  add rsp, 0x30
000079a3731d8bf7  vmovaps xmm0, [rsp]
000079a3731d8bfc  vmovaps xmm2, [rsp+0x10]
000079a3731d8c02  vmovaps xmm3, [rsp+0x20]
000079a3731d8c08  vmovaps xmm4, [rsp+0x30]
000079a3731d8c0e  vmovaps xmm5, [rsp+0x40]
000079a3731d8c14  vmovaps xmm6, [rsp+0x50]
000079a3731d8c1a  vmovaps xmm7, [rsp+0x60]
000079a3731d8c20  vmovaps xmm8, [rsp+0x70]
000079a3731d8c26  vmovaps xmm9, [rsp+0x80]
000079a3731d8c2f  vmovaps xmm10, [rsp+0x90]
000079a3731d8c38  vmovaps xmm11, [rsp+0xA0]
000079a3731d8c41  vmovaps xmm12, [rsp+0xB0]
000079a3731d8c4a  vmovaps xmm13, [rsp+0xC0]
000079a3731d8c53  vmovaps xmm14, [rsp+0xD0]
000079a3731d8c5c  vmovaps xmm15, [rsp+0xE0]
000079a3731d8c65  add rsp, 0xF0
000079a3731d8c6c  pop r11
000079a3731d8c6e  pop r10
000079a3731d8c70  pop r9
000079a3731d8c72  pop r8
000079a3731d8c74  pop rsi
000079a3731d8c75  pop rdi
000079a3731d8c76  pop rdx
000079a3731d8c77  pop rcx
000079a3731d8c78  pop rax
000079a3731d8c79  add rsp, 0x08
000079a3731d8c7d  jmp 0x000079A3731D613B
000079a3731d8c82  sub rsp, 0x08
000079a3731d8c86  push rax
000079a3731d8c87  push rcx
000079a3731d8c88  push rdx
000079a3731d8c89  push rdi
000079a3731d8c8a  push rsi
000079a3731d8c8b  push r8
000079a3731d8c8d  push r9
000079a3731d8c8f  push r10
000079a3731d8c91  push r11
000079a3731d8c93  sub rsp, 0xF0
000079a3731d8c9a  vmovaps [rsp], xmm0
000079a3731d8c9f  vmovaps [rsp+0x10], xmm1
000079a3731d8ca5  vmovaps [rsp+0x20], xmm2
000079a3731d8cab  vmovaps [rsp+0x30], xmm3
000079a3731d8cb1  vmovaps [rsp+0x40], xmm5
000079a3731d8cb7  vmovaps [rsp+0x50], xmm6
000079a3731d8cbd  vmovaps [rsp+0x60], xmm7
000079a3731d8cc3  vmovaps [rsp+0x70], xmm8
000079a3731d8cc9  vmovaps [rsp+0x80], xmm9
000079a3731d8cd2  vmovaps [rsp+0x90], xmm10
000079a3731d8cdb  vmovaps [rsp+0xA0], xmm11
000079a3731d8ce4  vmovaps [rsp+0xB0], xmm12
000079a3731d8ced  vmovaps [rsp+0xC0], xmm13
000079a3731d8cf6  vmovaps [rsp+0xD0], xmm14
000079a3731d8cff  vmovaps [rsp+0xE0], xmm15
000079a3731d8d08  sub rsp, 0x30
000079a3731d8d0c  movaps [rsp], xmm4
000079a3731d8d10  movaps [rsp+0x10], xmm2
000079a3731d8d15  movaps [rsp+0x20], xmm9
000079a3731d8d1b  lea rdi, [rsp]
000079a3731d8d1f  mov esi, 0x00
000079a3731d8d24  mov rax, 0x64F127B95530
000079a3731d8d2e  call rax
000079a3731d8d30  movaps xmm4, [rsp]
000079a3731d8d34  add rsp, 0x30
000079a3731d8d38  vmovaps xmm0, [rsp]
000079a3731d8d3d  vmovaps xmm1, [rsp+0x10]
000079a3731d8d43  vmovaps xmm2, [rsp+0x20]
000079a3731d8d49  vmovaps xmm3, [rsp+0x30]
000079a3731d8d4f  vmovaps xmm5, [rsp+0x40]
000079a3731d8d55  vmovaps xmm6, [rsp+0x50]
000079a3731d8d5b  vmovaps xmm7, [rsp+0x60]
000079a3731d8d61  vmovaps xmm8, [rsp+0x70]
000079a3731d8d67  vmovaps xmm9, [rsp+0x80]
000079a3731d8d70  vmovaps xmm10, [rsp+0x90]
000079a3731d8d79  vmovaps xmm11, [rsp+0xA0]
000079a3731d8d82  vmovaps xmm12, [rsp+0xB0]
000079a3731d8d8b  vmovaps xmm13, [rsp+0xC0]
000079a3731d8d94  vmovaps xmm14, [rsp+0xD0]
000079a3731d8d9d  vmovaps xmm15, [rsp+0xE0]
000079a3731d8da6  add rsp, 0xF0
000079a3731d8dad  pop r11
000079a3731d8daf  pop r10
000079a3731d8db1  pop r9
000079a3731d8db3  pop r8
000079a3731d8db5  pop rsi
000079a3731d8db6  pop rdi
000079a3731d8db7  pop rdx
000079a3731d8db8  pop rcx
000079a3731d8db9  pop rax
000079a3731d8dba  add rsp, 0x08
000079a3731d8dbe  jmp 0x000079A3731D616B
000079a3731d8dc3  sub rsp, 0x08
000079a3731d8dc7  push rax
000079a3731d8dc8  push rcx
000079a3731d8dc9  push rdx
000079a3731d8dca  push rdi
000079a3731d8dcb  push rsi
000079a3731d8dcc  push r8
000079a3731d8dce  push r9
000079a3731d8dd0  push r10
000079a3731d8dd2  push r11
000079a3731d8dd4  sub rsp, 0xF0
000079a3731d8ddb  vmovaps [rsp], xmm0
000079a3731d8de0  vmovaps [rsp+0x10], xmm1
000079a3731d8de6  vmovaps [rsp+0x20], xmm2
000079a3731d8dec  vmovaps [rsp+0x30], xmm3
000079a3731d8df2  vmovaps [rsp+0x40], xmm4
000079a3731d8df8  vmovaps [rsp+0x50], xmm5
000079a3731d8dfe  vmovaps [rsp+0x60], xmm6
000079a3731d8e04  vmovaps [rsp+0x70], xmm7
000079a3731d8e0a  vmovaps [rsp+0x80], xmm8
000079a3731d8e13  vmovaps [rsp+0x90], xmm10
000079a3731d8e1c  vmovaps [rsp+0xA0], xmm11
000079a3731d8e25  vmovaps [rsp+0xB0], xmm12
000079a3731d8e2e  vmovaps [rsp+0xC0], xmm13
000079a3731d8e37  vmovaps [rsp+0xD0], xmm14
000079a3731d8e40  vmovaps [rsp+0xE0], xmm15
000079a3731d8e49  sub rsp, 0x30
000079a3731d8e4d  movaps [rsp], xmm9
000079a3731d8e52  movaps [rsp+0x10], xmm2
000079a3731d8e57  movaps [rsp+0x20], xmm1
000079a3731d8e5c  lea rdi, [rsp]
000079a3731d8e60  mov esi, 0x00
000079a3731d8e65  mov rax, 0x64F127B95530
000079a3731d8e6f  call rax
000079a3731d8e71  movaps xmm9, [rsp]
000079a3731d8e76  add rsp, 0x30
000079a3731d8e7a  vmovaps xmm0, [rsp]
000079a3731d8e7f  vmovaps xmm1, [rsp+0x10]
000079a3731d8e85  vmovaps xmm2, [rsp+0x20]
000079a3731d8e8b  vmovaps xmm3, [rsp+0x30]
000079a3731d8e91  vmovaps xmm4, [rsp+0x40]
000079a3731d8e97  vmovaps xmm5, [rsp+0x50]
000079a3731d8e9d  vmovaps xmm6, [rsp+0x60]
000079a3731d8ea3  vmovaps xmm7, [rsp+0x70]
000079a3731d8ea9  vmovaps xmm8, [rsp+0x80]
000079a3731d8eb2  vmovaps xmm10, [rsp+0x90]
000079a3731d8ebb  vmovaps xmm11, [rsp+0xA0]
000079a3731d8ec4  vmovaps xmm12, [rsp+0xB0]
000079a3731d8ecd  vmovaps xmm13, [rsp+0xC0]
000079a3731d8ed6  vmovaps xmm14, [rsp+0xD0]
000079a3731d8edf  vmovaps xmm15, [rsp+0xE0]
000079a3731d8ee8  add rsp, 0xF0
000079a3731d8eef  pop r11
000079a3731d8ef1  pop r10
000079a3731d8ef3  pop r9
000079a3731d8ef5  pop r8
000079a3731d8ef7  pop rsi
000079a3731d8ef8  pop rdi
000079a3731d8ef9  pop rdx
000079a3731d8efa  pop rcx
000079a3731d8efb  pop rax
000079a3731d8efc  add rsp, 0x08
000079a3731d8f00  jmp 0x000079A3731D61A1
000079a3731d8f05  sub rsp, 0x08
000079a3731d8f09  push rax
000079a3731d8f0a  push rcx
000079a3731d8f0b  push rdx
000079a3731d8f0c  push rdi
000079a3731d8f0d  push rsi
000079a3731d8f0e  push r8
000079a3731d8f10  push r9
000079a3731d8f12  push r10
000079a3731d8f14  push r11
000079a3731d8f16  sub rsp, 0xF0
000079a3731d8f1d  vmovaps [rsp], xmm0
000079a3731d8f22  vmovaps [rsp+0x10], xmm2
000079a3731d8f28  vmovaps [rsp+0x20], xmm3
000079a3731d8f2e  vmovaps [rsp+0x30], xmm4
000079a3731d8f34  vmovaps [rsp+0x40], xmm5
000079a3731d8f3a  vmovaps [rsp+0x50], xmm6
000079a3731d8f40  vmovaps [rsp+0x60], xmm7
000079a3731d8f46  vmovaps [rsp+0x70], xmm8
000079a3731d8f4c  vmovaps [rsp+0x80], xmm9
000079a3731d8f55  vmovaps [rsp+0x90], xmm10
000079a3731d8f5e  vmovaps [rsp+0xA0], xmm11
000079a3731d8f67  vmovaps [rsp+0xB0], xmm12
000079a3731d8f70  vmovaps [rsp+0xC0], xmm13
000079a3731d8f79  vmovaps [rsp+0xD0], xmm14
000079a3731d8f82  vmovaps [rsp+0xE0], xmm15
000079a3731d8f8b  sub rsp, 0x30
000079a3731d8f8f  movaps [rsp], xmm1
000079a3731d8f93  movaps [rsp+0x10], xmm15
000079a3731d8f99  movaps [rsp+0x20], xmm6
000079a3731d8f9e  lea rdi, [rsp]
000079a3731d8fa2  mov esi, 0x00
000079a3731d8fa7  mov rax, 0x64F127B95530
000079a3731d8fb1  call rax
000079a3731d8fb3  movaps xmm1, [rsp]
000079a3731d8fb7  add rsp, 0x30
000079a3731d8fbb  vmovaps xmm0, [rsp]
000079a3731d8fc0  vmovaps xmm2, [rsp+0x10]
000079a3731d8fc6  vmovaps xmm3, [rsp+0x20]
000079a3731d8fcc  vmovaps xmm4, [rsp+0x30]
000079a3731d8fd2  vmovaps xmm5, [rsp+0x40]
000079a3731d8fd8  vmovaps xmm6, [rsp+0x50]
000079a3731d8fde  vmovaps xmm7, [rsp+0x60]
000079a3731d8fe4  vmovaps xmm8, [rsp+0x70]
000079a3731d8fea  vmovaps xmm9, [rsp+0x80]
000079a3731d8ff3  vmovaps xmm10, [rsp+0x90]
000079a3731d8ffc  vmovaps xmm11, [rsp+0xA0]
000079a3731d9005  vmovaps xmm12, [rsp+0xB0]
000079a3731d900e  vmovaps xmm13, [rsp+0xC0]
000079a3731d9017  vmovaps xmm14, [rsp+0xD0]
000079a3731d9020  vmovaps xmm15, [rsp+0xE0]
000079a3731d9029  add rsp, 0xF0
000079a3731d9030  pop r11
000079a3731d9032  pop r10
000079a3731d9034  pop r9
000079a3731d9036  pop r8
000079a3731d9038  pop rsi
000079a3731d9039  pop rdi
000079a3731d903a  pop rdx
000079a3731d903b  pop rcx
000079a3731d903c  pop rax
000079a3731d903d  add rsp, 0x08
000079a3731d9041  jmp 0x000079A3731D61C2
000079a3731d9046  sub rsp, 0x08
000079a3731d904a  push rax
000079a3731d904b  push rcx
000079a3731d904c  push rdx
000079a3731d904d  push rdi
000079a3731d904e  push rsi
000079a3731d904f  push r8
000079a3731d9051  push r9
000079a3731d9053  push r10
000079a3731d9055  push r11
000079a3731d9057  sub rsp, 0xF0
000079a3731d905e  vmovaps [rsp], xmm0
000079a3731d9063  vmovaps [rsp+0x10], xmm1
000079a3731d9069  vmovaps [rsp+0x20], xmm2
000079a3731d906f  vmovaps [rsp+0x30], xmm3
000079a3731d9075  vmovaps [rsp+0x40], xmm4
000079a3731d907b  vmovaps [rsp+0x50], xmm5
000079a3731d9081  vmovaps [rsp+0x60], xmm6
000079a3731d9087  vmovaps [rsp+0x70], xmm7
000079a3731d908d  vmovaps [rsp+0x80], xmm8
000079a3731d9096  vmovaps [rsp+0x90], xmm9
000079a3731d909f  vmovaps [rsp+0xA0], xmm10
000079a3731d90a8  vmovaps [rsp+0xB0], xmm11
000079a3731d90b1  vmovaps [rsp+0xC0], xmm12
000079a3731d90ba  vmovaps [rsp+0xD0], xmm13
000079a3731d90c3  vmovaps [rsp+0xE0], xmm14
000079a3731d90cc  sub rsp, 0x30
000079a3731d90d0  movaps [rsp], xmm15
000079a3731d90d5  movaps [rsp+0x10], xmm5
000079a3731d90da  movaps [rsp+0x20], xmm3
000079a3731d90df  lea rdi, [rsp]
000079a3731d90e3  mov esi, 0x00
000079a3731d90e8  mov rax, 0x64F127B95530
000079a3731d90f2  call rax
000079a3731d90f4  movaps xmm15, [rsp]
000079a3731d90f9  add rsp, 0x30
000079a3731d90fd  vmovaps xmm0, [rsp]
000079a3731d9102  vmovaps xmm1, [rsp+0x10]
000079a3731d9108  vmovaps xmm2, [rsp+0x20]
000079a3731d910e  vmovaps xmm3, [rsp+0x30]
000079a3731d9114  vmovaps xmm4, [rsp+0x40]
000079a3731d911a  vmovaps xmm5, [rsp+0x50]
000079a3731d9120  vmovaps xmm6, [rsp+0x60]
000079a3731d9126  vmovaps xmm7, [rsp+0x70]
000079a3731d912c  vmovaps xmm8, [rsp+0x80]
000079a3731d9135  vmovaps xmm9, [rsp+0x90]
000079a3731d913e  vmovaps xmm10, [rsp+0xA0]
000079a3731d9147  vmovaps xmm11, [rsp+0xB0]
000079a3731d9150  vmovaps xmm12, [rsp+0xC0]
000079a3731d9159  vmovaps xmm13, [rsp+0xD0]
000079a3731d9162  vmovaps xmm14, [rsp+0xE0]
000079a3731d916b  add rsp, 0xF0
000079a3731d9172  pop r11
000079a3731d9174  pop r10
000079a3731d9176  pop r9
000079a3731d9178  pop r8
000079a3731d917a  pop rsi
000079a3731d917b  pop rdi
000079a3731d917c  pop rdx
000079a3731d917d  pop rcx
000079a3731d917e  pop rax
000079a3731d917f  add rsp, 0x08
000079a3731d9183  jmp 0x000079A3731D61DC
000079a3731d9188  sub rsp, 0x08
000079a3731d918c  push rax
000079a3731d918d  push rcx
000079a3731d918e  push rdx
000079a3731d918f  push rdi
000079a3731d9190  push rsi
000079a3731d9191  push r8
000079a3731d9193  push r9
000079a3731d9195  push r10
000079a3731d9197  push r11
000079a3731d9199  sub rsp, 0xF0
000079a3731d91a0  vmovaps [rsp], xmm0
000079a3731d91a5  vmovaps [rsp+0x10], xmm1
000079a3731d91ab  vmovaps [rsp+0x20], xmm2
000079a3731d91b1  vmovaps [rsp+0x30], xmm3
000079a3731d91b7  vmovaps [rsp+0x40], xmm4
000079a3731d91bd  vmovaps [rsp+0x50], xmm6
000079a3731d91c3  vmovaps [rsp+0x60], xmm7
000079a3731d91c9  vmovaps [rsp+0x70], xmm8
000079a3731d91cf  vmovaps [rsp+0x80], xmm9
000079a3731d91d8  vmovaps [rsp+0x90], xmm10
000079a3731d91e1  vmovaps [rsp+0xA0], xmm11
000079a3731d91ea  vmovaps [rsp+0xB0], xmm12
000079a3731d91f3  vmovaps [rsp+0xC0], xmm13
000079a3731d91fc  vmovaps [rsp+0xD0], xmm14
000079a3731d9205  vmovaps [rsp+0xE0], xmm15
000079a3731d920e  sub rsp, 0x30
000079a3731d9212  movaps [rsp], xmm5
000079a3731d9216  movaps [rsp+0x10], xmm8
000079a3731d921c  movaps [rsp+0x20], xmm6
000079a3731d9221  lea rdi, [rsp]
000079a3731d9225  mov esi, 0x00
000079a3731d922a  mov rax, 0x64F127B95530
000079a3731d9234  call rax
000079a3731d9236  movaps xmm5, [rsp]
000079a3731d923a  add rsp, 0x30
000079a3731d923e  vmovaps xmm0, [rsp]
000079a3731d9243  vmovaps xmm1, [rsp+0x10]
000079a3731d9249  vmovaps xmm2, [rsp+0x20]
000079a3731d924f  vmovaps xmm3, [rsp+0x30]
000079a3731d9255  vmovaps xmm4, [rsp+0x40]
000079a3731d925b  vmovaps xmm6, [rsp+0x50]
000079a3731d9261  vmovaps xmm7, [rsp+0x60]
000079a3731d9267  vmovaps xmm8, [rsp+0x70]
000079a3731d926d  vmovaps xmm9, [rsp+0x80]
000079a3731d9276  vmovaps xmm10, [rsp+0x90]
000079a3731d927f  vmovaps xmm11, [rsp+0xA0]
000079a3731d9288  vmovaps xmm12, [rsp+0xB0]
000079a3731d9291  vmovaps xmm13, [rsp+0xC0]
000079a3731d929a  vmovaps xmm14, [rsp+0xD0]
000079a3731d92a3  vmovaps xmm15, [rsp+0xE0]
000079a3731d92ac  add rsp, 0xF0
000079a3731d92b3  pop r11
000079a3731d92b5  pop r10
000079a3731d92b7  pop r9
000079a3731d92b9  pop r8
000079a3731d92bb  pop rsi
000079a3731d92bc  pop rdi
000079a3731d92bd  pop rdx
000079a3731d92be  pop rcx
000079a3731d92bf  pop rax
000079a3731d92c0  add rsp, 0x08
000079a3731d92c4  jmp 0x000079A3731D6200
000079a3731d92c9  sub rsp, 0x08
000079a3731d92cd  push rax
000079a3731d92ce  push rcx
000079a3731d92cf  push rdx
000079a3731d92d0  push rdi
000079a3731d92d1  push rsi
000079a3731d92d2  push r8
000079a3731d92d4  push r9
000079a3731d92d6  push r10
000079a3731d92d8  push r11
000079a3731d92da  sub rsp, 0xF0
000079a3731d92e1  vmovaps [rsp], xmm0
000079a3731d92e6  vmovaps [rsp+0x10], xmm1
000079a3731d92ec  vmovaps [rsp+0x20], xmm2
000079a3731d92f2  vmovaps [rsp+0x30], xmm3
000079a3731d92f8  vmovaps [rsp+0x40], xmm4
000079a3731d92fe  vmovaps [rsp+0x50], xmm5
000079a3731d9304  vmovaps [rsp+0x60], xmm7
000079a3731d930a  vmovaps [rsp+0x70], xmm8
000079a3731d9310  vmovaps [rsp+0x80], xmm9
000079a3731d9319  vmovaps [rsp+0x90], xmm10
000079a3731d9322  vmovaps [rsp+0xA0], xmm11
000079a3731d932b  vmovaps [rsp+0xB0], xmm12
000079a3731d9334  vmovaps [rsp+0xC0], xmm13
000079a3731d933d  vmovaps [rsp+0xD0], xmm14
000079a3731d9346  vmovaps [rsp+0xE0], xmm15
000079a3731d934f  sub rsp, 0x30
000079a3731d9353  movaps [rsp], xmm6
000079a3731d9357  movaps [rsp+0x10], xmm10
000079a3731d935d  movaps [rsp+0x20], xmm8
000079a3731d9363  lea rdi, [rsp]
000079a3731d9367  mov esi, 0x00
000079a3731d936c  mov rax, 0x64F127B95530
000079a3731d9376  call rax
000079a3731d9378  movaps xmm6, [rsp]
000079a3731d937c  add rsp, 0x30
000079a3731d9380  vmovaps xmm0, [rsp]
000079a3731d9385  vmovaps xmm1, [rsp+0x10]
000079a3731d938b  vmovaps xmm2, [rsp+0x20]
000079a3731d9391  vmovaps xmm3, [rsp+0x30]
000079a3731d9397  vmovaps xmm4, [rsp+0x40]
000079a3731d939d  vmovaps xmm5, [rsp+0x50]
000079a3731d93a3  vmovaps xmm7, [rsp+0x60]
000079a3731d93a9  vmovaps xmm8, [rsp+0x70]
000079a3731d93af  vmovaps xmm9, [rsp+0x80]
000079a3731d93b8  vmovaps xmm10, [rsp+0x90]
000079a3731d93c1  vmovaps xmm11, [rsp+0xA0]
000079a3731d93ca  vmovaps xmm12, [rsp+0xB0]
000079a3731d93d3  vmovaps xmm13, [rsp+0xC0]
000079a3731d93dc  vmovaps xmm14, [rsp+0xD0]
000079a3731d93e5  vmovaps xmm15, [rsp+0xE0]
000079a3731d93ee  add rsp, 0xF0
000079a3731d93f5  pop r11
000079a3731d93f7  pop r10
000079a3731d93f9  pop r9
000079a3731d93fb  pop r8
000079a3731d93fd  pop rsi
000079a3731d93fe  pop rdi
000079a3731d93ff  pop rdx
000079a3731d9400  pop rcx
000079a3731d9401  pop rax
000079a3731d9402  add rsp, 0x08
000079a3731d9406  jmp 0x000079A3731D6225
000079a3731d940b  sub rsp, 0x08
000079a3731d940f  push rax
000079a3731d9410  push rcx
000079a3731d9411  push rdx
000079a3731d9412  push rdi
000079a3731d9413  push rsi
000079a3731d9414  push r8
000079a3731d9416  push r9
000079a3731d9418  push r10
000079a3731d941a  push r11
000079a3731d941c  sub rsp, 0xF0
000079a3731d9423  vmovaps [rsp], xmm0
000079a3731d9428  vmovaps [rsp+0x10], xmm1
000079a3731d942e  vmovaps [rsp+0x20], xmm2
000079a3731d9434  vmovaps [rsp+0x30], xmm3
000079a3731d943a  vmovaps [rsp+0x40], xmm4
000079a3731d9440  vmovaps [rsp+0x50], xmm5
000079a3731d9446  vmovaps [rsp+0x60], xmm6
000079a3731d944c  vmovaps [rsp+0x70], xmm7
000079a3731d9452  vmovaps [rsp+0x80], xmm8
000079a3731d945b  vmovaps [rsp+0x90], xmm9
000079a3731d9464  vmovaps [rsp+0xA0], xmm11
000079a3731d946d  vmovaps [rsp+0xB0], xmm12
000079a3731d9476  vmovaps [rsp+0xC0], xmm13
000079a3731d947f  vmovaps [rsp+0xD0], xmm14
000079a3731d9488  vmovaps [rsp+0xE0], xmm15
000079a3731d9491  sub rsp, 0x30
000079a3731d9495  movaps [rsp], xmm10
000079a3731d949a  movaps [rsp+0x10], xmm8
000079a3731d94a0  movaps [rsp+0x20], xmm14
000079a3731d94a6  lea rdi, [rsp]
000079a3731d94aa  mov esi, 0x00
000079a3731d94af  mov rax, 0x64F127B95530
000079a3731d94b9  call rax
000079a3731d94bb  movaps xmm10, [rsp]
000079a3731d94c0  add rsp, 0x30
000079a3731d94c4  vmovaps xmm0, [rsp]
000079a3731d94c9  vmovaps xmm1, [rsp+0x10]
000079a3731d94cf  vmovaps xmm2, [rsp+0x20]
000079a3731d94d5  vmovaps xmm3, [rsp+0x30]
000079a3731d94db  vmovaps xmm4, [rsp+0x40]
000079a3731d94e1  vmovaps xmm5, [rsp+0x50]
000079a3731d94e7  vmovaps xmm6, [rsp+0x60]
000079a3731d94ed  vmovaps xmm7, [rsp+0x70]
000079a3731d94f3  vmovaps xmm8, [rsp+0x80]
000079a3731d94fc  vmovaps xmm9, [rsp+0x90]
000079a3731d9505  vmovaps xmm11, [rsp+0xA0]
000079a3731d950e  vmovaps xmm12, [rsp+0xB0]
000079a3731d9517  vmovaps xmm13, [rsp+0xC0]
000079a3731d9520  vmovaps xmm14, [rsp+0xD0]
000079a3731d9529  vmovaps xmm15, [rsp+0xE0]
000079a3731d9532  add rsp, 0xF0
000079a3731d9539  pop r11
000079a3731d953b  pop r10
000079a3731d953d  pop r9
000079a3731d953f  pop r8
000079a3731d9541  pop rsi
000079a3731d9542  pop rdi
000079a3731d9543  pop rdx
000079a3731d9544  pop rcx
000079a3731d9545  pop rax
000079a3731d9546  add rsp, 0x08
000079a3731d954a  jmp 0x000079A3731D6245
000079a3731d954f  sub rsp, 0x08
000079a3731d9553  push rax
000079a3731d9554  push rcx
000079a3731d9555  push rdx
000079a3731d9556  push rdi
000079a3731d9557  push rsi
000079a3731d9558  push r8
000079a3731d955a  push r9
000079a3731d955c  push r10
000079a3731d955e  push r11
000079a3731d9560  sub rsp, 0xF0
000079a3731d9567  vmovaps [rsp], xmm0
000079a3731d956c  vmovaps [rsp+0x10], xmm1
000079a3731d9572  vmovaps [rsp+0x20], xmm2
000079a3731d9578  vmovaps [rsp+0x30], xmm3
000079a3731d957e  vmovaps [rsp+0x40], xmm4
000079a3731d9584  vmovaps [rsp+0x50], xmm5
000079a3731d958a  vmovaps [rsp+0x60], xmm6
000079a3731d9590  vmovaps [rsp+0x70], xmm7
000079a3731d9596  vmovaps [rsp+0x80], xmm8
000079a3731d959f  vmovaps [rsp+0x90], xmm9
000079a3731d95a8  vmovaps [rsp+0xA0], xmm10
000079a3731d95b1  vmovaps [rsp+0xB0], xmm11
000079a3731d95ba  vmovaps [rsp+0xC0], xmm12
000079a3731d95c3  vmovaps [rsp+0xD0], xmm13
000079a3731d95cc  vmovaps [rsp+0xE0], xmm15
000079a3731d95d5  sub rsp, 0x30
000079a3731d95d9  movaps [rsp], xmm14
000079a3731d95de  movaps [rsp+0x10], xmm8
000079a3731d95e4  movaps [rsp+0x20], xmm4
000079a3731d95e9  lea rdi, [rsp]
000079a3731d95ed  mov esi, 0x00
000079a3731d95f2  mov rax, 0x64F127B95530
000079a3731d95fc  call rax
000079a3731d95fe  movaps xmm14, [rsp]
000079a3731d9603  add rsp, 0x30
000079a3731d9607  vmovaps xmm0, [rsp]
000079a3731d960c  vmovaps xmm1, [rsp+0x10]
000079a3731d9612  vmovaps xmm2, [rsp+0x20]
000079a3731d9618  vmovaps xmm3, [rsp+0x30]
000079a3731d961e  vmovaps xmm4, [rsp+0x40]
000079a3731d9624  vmovaps xmm5, [rsp+0x50]
000079a3731d962a  vmovaps xmm6, [rsp+0x60]
000079a3731d9630  vmovaps xmm7, [rsp+0x70]
000079a3731d9636  vmovaps xmm8, [rsp+0x80]
000079a3731d963f  vmovaps xmm9, [rsp+0x90]
000079a3731d9648  vmovaps xmm10, [rsp+0xA0]
000079a3731d9651  vmovaps xmm11, [rsp+0xB0]
000079a3731d965a  vmovaps xmm12, [rsp+0xC0]
000079a3731d9663  vmovaps xmm13, [rsp+0xD0]
000079a3731d966c  vmovaps xmm15, [rsp+0xE0]
000079a3731d9675  add rsp, 0xF0
000079a3731d967c  pop r11
000079a3731d967e  pop r10
000079a3731d9680  pop r9
000079a3731d9682  pop r8
000079a3731d9684  pop rsi
000079a3731d9685  pop rdi
000079a3731d9686  pop rdx
000079a3731d9687  pop rcx
000079a3731d9688  pop rax
000079a3731d9689  add rsp, 0x08
000079a3731d968d  jmp 0x000079A3731D6265
000079a3731d9692  sub rsp, 0x08
000079a3731d9696  push rax
000079a3731d9697  push rcx
000079a3731d9698  push rdx
000079a3731d9699  push rdi
000079a3731d969a  push rsi
000079a3731d969b  push r8
000079a3731d969d  push r9
000079a3731d969f  push r10
000079a3731d96a1  push r11
000079a3731d96a3  sub rsp, 0xF0
000079a3731d96aa  vmovaps [rsp], xmm0
000079a3731d96af  vmovaps [rsp+0x10], xmm1
000079a3731d96b5  vmovaps [rsp+0x20], xmm2
000079a3731d96bb  vmovaps [rsp+0x30], xmm3
000079a3731d96c1  vmovaps [rsp+0x40], xmm5
000079a3731d96c7  vmovaps [rsp+0x50], xmm6
000079a3731d96cd  vmovaps [rsp+0x60], xmm7
000079a3731d96d3  vmovaps [rsp+0x70], xmm8
000079a3731d96d9  vmovaps [rsp+0x80], xmm9
000079a3731d96e2  vmovaps [rsp+0x90], xmm10
000079a3731d96eb  vmovaps [rsp+0xA0], xmm11
000079a3731d96f4  vmovaps [rsp+0xB0], xmm12
000079a3731d96fd  vmovaps [rsp+0xC0], xmm13
000079a3731d9706  vmovaps [rsp+0xD0], xmm14
000079a3731d970f  vmovaps [rsp+0xE0], xmm15
000079a3731d9718  sub rsp, 0x30
000079a3731d971c  movaps [rsp], xmm4
000079a3731d9720  movaps [rsp+0x10], xmm13
000079a3731d9726  movaps [rsp+0x20], xmm8
000079a3731d972c  lea rdi, [rsp]
000079a3731d9730  mov esi, 0x00
000079a3731d9735  mov rax, 0x64F127B95530
000079a3731d973f  call rax
000079a3731d9741  movaps xmm4, [rsp]
000079a3731d9745  add rsp, 0x30
000079a3731d9749  vmovaps xmm0, [rsp]
000079a3731d974e  vmovaps xmm1, [rsp+0x10]
000079a3731d9754  vmovaps xmm2, [rsp+0x20]
000079a3731d975a  vmovaps xmm3, [rsp+0x30]
000079a3731d9760  vmovaps xmm5, [rsp+0x40]
000079a3731d9766  vmovaps xmm6, [rsp+0x50]
000079a3731d976c  vmovaps xmm7, [rsp+0x60]
000079a3731d9772  vmovaps xmm8, [rsp+0x70]
000079a3731d9778  vmovaps xmm9, [rsp+0x80]
000079a3731d9781  vmovaps xmm10, [rsp+0x90]
000079a3731d978a  vmovaps xmm11, [rsp+0xA0]
000079a3731d9793  vmovaps xmm12, [rsp+0xB0]
000079a3731d979c  vmovaps xmm13, [rsp+0xC0]
000079a3731d97a5  vmovaps xmm14, [rsp+0xD0]
000079a3731d97ae  vmovaps xmm15, [rsp+0xE0]
000079a3731d97b7  add rsp, 0xF0
000079a3731d97be  pop r11
000079a3731d97c0  pop r10
000079a3731d97c2  pop r9
000079a3731d97c4  pop r8
000079a3731d97c6  pop rsi
000079a3731d97c7  pop rdi
000079a3731d97c8  pop rdx
000079a3731d97c9  pop rcx
000079a3731d97ca  pop rax
000079a3731d97cb  add rsp, 0x08
000079a3731d97cf  jmp 0x000079A3731D628A
000079a3731d97d4  sub rsp, 0x08
000079a3731d97d8  push rax
000079a3731d97d9  push rcx
000079a3731d97da  push rdx
000079a3731d97db  push rdi
000079a3731d97dc  push rsi
000079a3731d97dd  push r8
000079a3731d97df  push r9
000079a3731d97e1  push r10
000079a3731d97e3  push r11
000079a3731d97e5  sub rsp, 0xF0
000079a3731d97ec  vmovaps [rsp], xmm0
000079a3731d97f1  vmovaps [rsp+0x10], xmm1
000079a3731d97f7  vmovaps [rsp+0x20], xmm2
000079a3731d97fd  vmovaps [rsp+0x30], xmm3
000079a3731d9803  vmovaps [rsp+0x40], xmm4
000079a3731d9809  vmovaps [rsp+0x50], xmm5
000079a3731d980f  vmovaps [rsp+0x60], xmm6
000079a3731d9815  vmovaps [rsp+0x70], xmm7
000079a3731d981b  vmovaps [rsp+0x80], xmm8
000079a3731d9824  vmovaps [rsp+0x90], xmm9
000079a3731d982d  vmovaps [rsp+0xA0], xmm10
000079a3731d9836  vmovaps [rsp+0xB0], xmm11
000079a3731d983f  vmovaps [rsp+0xC0], xmm12
000079a3731d9848  vmovaps [rsp+0xD0], xmm14
000079a3731d9851  vmovaps [rsp+0xE0], xmm15
000079a3731d985a  sub rsp, 0x30
000079a3731d985e  movaps [rsp], xmm13
000079a3731d9863  movaps [rsp+0x10], xmm15
000079a3731d9869  movaps [rsp+0x20], xmm9
000079a3731d986f  lea rdi, [rsp]
000079a3731d9873  mov esi, 0x00
000079a3731d9878  mov rax, 0x64F127B95530
000079a3731d9882  call rax
000079a3731d9884  movaps xmm13, [rsp]
000079a3731d9889  add rsp, 0x30
000079a3731d988d  vmovaps xmm0, [rsp]
000079a3731d9892  vmovaps xmm1, [rsp+0x10]
000079a3731d9898  vmovaps xmm2, [rsp+0x20]
000079a3731d989e  vmovaps xmm3, [rsp+0x30]
000079a3731d98a4  vmovaps xmm4, [rsp+0x40]
000079a3731d98aa  vmovaps xmm5, [rsp+0x50]
000079a3731d98b0  vmovaps xmm6, [rsp+0x60]
000079a3731d98b6  vmovaps xmm7, [rsp+0x70]
000079a3731d98bc  vmovaps xmm8, [rsp+0x80]
000079a3731d98c5  vmovaps xmm9, [rsp+0x90]
000079a3731d98ce  vmovaps xmm10, [rsp+0xA0]
000079a3731d98d7  vmovaps xmm11, [rsp+0xB0]
000079a3731d98e0  vmovaps xmm12, [rsp+0xC0]
000079a3731d98e9  vmovaps xmm14, [rsp+0xD0]
000079a3731d98f2  vmovaps xmm15, [rsp+0xE0]
000079a3731d98fb  add rsp, 0xF0
000079a3731d9902  pop r11
000079a3731d9904  pop r10
000079a3731d9906  pop r9
000079a3731d9908  pop r8
000079a3731d990a  pop rsi
000079a3731d990b  pop rdi
000079a3731d990c  pop rdx
000079a3731d990d  pop rcx
000079a3731d990e  pop rax
000079a3731d990f  add rsp, 0x08
000079a3731d9913  jmp 0x000079A3731D62A5
000079a3731d9918  sub rsp, 0x08
000079a3731d991c  push rax
000079a3731d991d  push rcx
000079a3731d991e  push rdx
000079a3731d991f  push rdi
000079a3731d9920  push rsi
000079a3731d9921  push r8
000079a3731d9923  push r9
000079a3731d9925  push r10
000079a3731d9927  push r11
000079a3731d9929  sub rsp, 0xF0
000079a3731d9930  vmovaps [rsp], xmm0
000079a3731d9935  vmovaps [rsp+0x10], xmm1
000079a3731d993b  vmovaps [rsp+0x20], xmm2
000079a3731d9941  vmovaps [rsp+0x30], xmm3
000079a3731d9947  vmovaps [rsp+0x40], xmm4
000079a3731d994d  vmovaps [rsp+0x50], xmm5
000079a3731d9953  vmovaps [rsp+0x60], xmm6
000079a3731d9959  vmovaps [rsp+0x70], xmm7
000079a3731d995f  vmovaps [rsp+0x80], xmm8
000079a3731d9968  vmovaps [rsp+0x90], xmm9
000079a3731d9971  vmovaps [rsp+0xA0], xmm10
000079a3731d997a  vmovaps [rsp+0xB0], xmm11
000079a3731d9983  vmovaps [rsp+0xC0], xmm12
000079a3731d998c  vmovaps [rsp+0xD0], xmm13
000079a3731d9995  vmovaps [rsp+0xE0], xmm14
000079a3731d999e  sub rsp, 0x30
000079a3731d99a2  movaps [rsp], xmm15
000079a3731d99a7  movaps [rsp+0x10], xmm1
000079a3731d99ac  movaps [rsp+0x20], xmm5
000079a3731d99b1  lea rdi, [rsp]
000079a3731d99b5  mov esi, 0x00
000079a3731d99ba  mov rax, 0x64F127B95530
000079a3731d99c4  call rax
000079a3731d99c6  movaps xmm15, [rsp]
000079a3731d99cb  add rsp, 0x30
000079a3731d99cf  vmovaps xmm0, [rsp]
000079a3731d99d4  vmovaps xmm1, [rsp+0x10]
000079a3731d99da  vmovaps xmm2, [rsp+0x20]
000079a3731d99e0  vmovaps xmm3, [rsp+0x30]
000079a3731d99e6  vmovaps xmm4, [rsp+0x40]
000079a3731d99ec  vmovaps xmm5, [rsp+0x50]
000079a3731d99f2  vmovaps xmm6, [rsp+0x60]
000079a3731d99f8  vmovaps xmm7, [rsp+0x70]
000079a3731d99fe  vmovaps xmm8, [rsp+0x80]
000079a3731d9a07  vmovaps xmm9, [rsp+0x90]
000079a3731d9a10  vmovaps xmm10, [rsp+0xA0]
000079a3731d9a19  vmovaps xmm11, [rsp+0xB0]
000079a3731d9a22  vmovaps xmm12, [rsp+0xC0]
000079a3731d9a2b  vmovaps xmm13, [rsp+0xD0]
000079a3731d9a34  vmovaps xmm14, [rsp+0xE0]
000079a3731d9a3d  add rsp, 0xF0
000079a3731d9a44  pop r11
000079a3731d9a46  pop r10
000079a3731d9a48  pop r9
000079a3731d9a4a  pop r8
000079a3731d9a4c  pop rsi
000079a3731d9a4d  pop rdi
000079a3731d9a4e  pop rdx
000079a3731d9a4f  pop rcx
000079a3731d9a50  pop rax
000079a3731d9a51  add rsp, 0x08
000079a3731d9a55  jmp 0x000079A3731D62C0
000079a3731d9a5a  call 0x000079A3730D64F0
000079a3731d9a5f  jmp 0x000079A3731D631B
000079a3731d9a64  sub rsp, 0x08
000079a3731d9a68  push rax
000079a3731d9a69  push rcx
000079a3731d9a6a  push rdx
000079a3731d9a6b  push rdi
000079a3731d9a6c  push rsi
000079a3731d9a6d  push r8
000079a3731d9a6f  push r9
000079a3731d9a71  push r10
000079a3731d9a73  push r11
000079a3731d9a75  sub rsp, 0xF0
000079a3731d9a7c  vmovaps [rsp], xmm0
000079a3731d9a81  vmovaps [rsp+0x10], xmm1
000079a3731d9a87  vmovaps [rsp+0x20], xmm2
000079a3731d9a8d  vmovaps [rsp+0x30], xmm3
000079a3731d9a93  vmovaps [rsp+0x40], xmm4
000079a3731d9a99  vmovaps [rsp+0x50], xmm5
000079a3731d9a9f  vmovaps [rsp+0x60], xmm6
000079a3731d9aa5  vmovaps [rsp+0x70], xmm7
000079a3731d9aab  vmovaps [rsp+0x80], xmm8
000079a3731d9ab4  vmovaps [rsp+0x90], xmm10
000079a3731d9abd  vmovaps [rsp+0xA0], xmm11
000079a3731d9ac6  vmovaps [rsp+0xB0], xmm12
000079a3731d9acf  vmovaps [rsp+0xC0], xmm13
000079a3731d9ad8  vmovaps [rsp+0xD0], xmm14
000079a3731d9ae1  vmovaps [rsp+0xE0], xmm15
000079a3731d9aea  sub rsp, 0x30
000079a3731d9aee  movaps [rsp], xmm9
000079a3731d9af3  movaps [rsp+0x10], xmm8
000079a3731d9af9  movaps [rsp+0x20], xmm11
000079a3731d9aff  lea rdi, [rsp]
000079a3731d9b03  mov esi, 0x00
000079a3731d9b08  mov rax, 0x64F127B95530
000079a3731d9b12  call rax
000079a3731d9b14  movaps xmm9, [rsp]
000079a3731d9b19  add rsp, 0x30
000079a3731d9b1d  vmovaps xmm0, [rsp]
000079a3731d9b22  vmovaps xmm1, [rsp+0x10]
000079a3731d9b28  vmovaps xmm2, [rsp+0x20]
000079a3731d9b2e  vmovaps xmm3, [rsp+0x30]
000079a3731d9b34  vmovaps xmm4, [rsp+0x40]
000079a3731d9b3a  vmovaps xmm5, [rsp+0x50]
000079a3731d9b40  vmovaps xmm6, [rsp+0x60]
000079a3731d9b46  vmovaps xmm7, [rsp+0x70]
000079a3731d9b4c  vmovaps xmm8, [rsp+0x80]
000079a3731d9b55  vmovaps xmm10, [rsp+0x90]
000079a3731d9b5e  vmovaps xmm11, [rsp+0xA0]
000079a3731d9b67  vmovaps xmm12, [rsp+0xB0]
000079a3731d9b70  vmovaps xmm13, [rsp+0xC0]
000079a3731d9b79  vmovaps xmm14, [rsp+0xD0]
000079a3731d9b82  vmovaps xmm15, [rsp+0xE0]
000079a3731d9b8b  add rsp, 0xF0
000079a3731d9b92  pop r11
000079a3731d9b94  pop r10
000079a3731d9b96  pop r9
000079a3731d9b98  pop r8
000079a3731d9b9a  pop rsi
000079a3731d9b9b  pop rdi
000079a3731d9b9c  pop rdx
000079a3731d9b9d  pop rcx
000079a3731d9b9e  pop rax
000079a3731d9b9f  add rsp, 0x08
000079a3731d9ba3  jmp 0x000079A3731D6352
000079a3731d9ba8  sub rsp, 0x08
000079a3731d9bac  push rax
000079a3731d9bad  push rcx
000079a3731d9bae  push rdx
000079a3731d9baf  push rdi
000079a3731d9bb0  push rsi
000079a3731d9bb1  push r8
000079a3731d9bb3  push r9
000079a3731d9bb5  push r10
000079a3731d9bb7  push r11
000079a3731d9bb9  sub rsp, 0xF0
000079a3731d9bc0  vmovaps [rsp], xmm0
000079a3731d9bc5  vmovaps [rsp+0x10], xmm1
000079a3731d9bcb  vmovaps [rsp+0x20], xmm2
000079a3731d9bd1  vmovaps [rsp+0x30], xmm3
000079a3731d9bd7  vmovaps [rsp+0x40], xmm4
000079a3731d9bdd  vmovaps [rsp+0x50], xmm5
000079a3731d9be3  vmovaps [rsp+0x60], xmm6
000079a3731d9be9  vmovaps [rsp+0x70], xmm7
000079a3731d9bef  vmovaps [rsp+0x80], xmm8
000079a3731d9bf8  vmovaps [rsp+0x90], xmm9
000079a3731d9c01  vmovaps [rsp+0xA0], xmm10
000079a3731d9c0a  vmovaps [rsp+0xB0], xmm12
000079a3731d9c13  vmovaps [rsp+0xC0], xmm13
000079a3731d9c1c  vmovaps [rsp+0xD0], xmm14
000079a3731d9c25  vmovaps [rsp+0xE0], xmm15
000079a3731d9c2e  sub rsp, 0x30
000079a3731d9c32  movaps [rsp], xmm11
000079a3731d9c37  movaps [rsp+0x10], xmm10
000079a3731d9c3d  movaps [rsp+0x20], xmm6
000079a3731d9c42  lea rdi, [rsp]
000079a3731d9c46  mov esi, 0x00
000079a3731d9c4b  mov rax, 0x64F127B95530
000079a3731d9c55  call rax
000079a3731d9c57  movaps xmm11, [rsp]
000079a3731d9c5c  add rsp, 0x30
000079a3731d9c60  vmovaps xmm0, [rsp]
000079a3731d9c65  vmovaps xmm1, [rsp+0x10]
000079a3731d9c6b  vmovaps xmm2, [rsp+0x20]
000079a3731d9c71  vmovaps xmm3, [rsp+0x30]
000079a3731d9c77  vmovaps xmm4, [rsp+0x40]
000079a3731d9c7d  vmovaps xmm5, [rsp+0x50]
000079a3731d9c83  vmovaps xmm6, [rsp+0x60]
000079a3731d9c89  vmovaps xmm7, [rsp+0x70]
000079a3731d9c8f  vmovaps xmm8, [rsp+0x80]
000079a3731d9c98  vmovaps xmm9, [rsp+0x90]
000079a3731d9ca1  vmovaps xmm10, [rsp+0xA0]
000079a3731d9caa  vmovaps xmm12, [rsp+0xB0]
000079a3731d9cb3  vmovaps xmm13, [rsp+0xC0]
000079a3731d9cbc  vmovaps xmm14, [rsp+0xD0]
000079a3731d9cc5  vmovaps xmm15, [rsp+0xE0]
000079a3731d9cce  add rsp, 0xF0
000079a3731d9cd5  pop r11
000079a3731d9cd7  pop r10
000079a3731d9cd9  pop r9
000079a3731d9cdb  pop r8
000079a3731d9cdd  pop rsi
000079a3731d9cde  pop rdi
000079a3731d9cdf  pop rdx
000079a3731d9ce0  pop rcx
000079a3731d9ce1  pop rax
000079a3731d9ce2  add rsp, 0x08
000079a3731d9ce6  jmp 0x000079A3731D636D
000079a3731d9ceb  sub rsp, 0x08
000079a3731d9cef  push rax
000079a3731d9cf0  push rcx
000079a3731d9cf1  push rdx
000079a3731d9cf2  push rdi
000079a3731d9cf3  push rsi
000079a3731d9cf4  push r8
000079a3731d9cf6  push r9
000079a3731d9cf8  push r10
000079a3731d9cfa  push r11
000079a3731d9cfc  sub rsp, 0xF0
000079a3731d9d03  vmovaps [rsp], xmm0
000079a3731d9d08  vmovaps [rsp+0x10], xmm1
000079a3731d9d0e  vmovaps [rsp+0x20], xmm2
000079a3731d9d14  vmovaps [rsp+0x30], xmm3
000079a3731d9d1a  vmovaps [rsp+0x40], xmm4
000079a3731d9d20  vmovaps [rsp+0x50], xmm5
000079a3731d9d26  vmovaps [rsp+0x60], xmm6
000079a3731d9d2c  vmovaps [rsp+0x70], xmm7
000079a3731d9d32  vmovaps [rsp+0x80], xmm8
000079a3731d9d3b  vmovaps [rsp+0x90], xmm9
000079a3731d9d44  vmovaps [rsp+0xA0], xmm11
000079a3731d9d4d  vmovaps [rsp+0xB0], xmm12
000079a3731d9d56  vmovaps [rsp+0xC0], xmm13
000079a3731d9d5f  vmovaps [rsp+0xD0], xmm14
000079a3731d9d68  vmovaps [rsp+0xE0], xmm15
000079a3731d9d71  sub rsp, 0x30
000079a3731d9d75  movaps [rsp], xmm10
000079a3731d9d7a  movaps [rsp+0x10], xmm14
000079a3731d9d80  movaps [rsp+0x20], xmm4
000079a3731d9d85  lea rdi, [rsp]
000079a3731d9d89  mov esi, 0x00
000079a3731d9d8e  mov rax, 0x64F127B95530
000079a3731d9d98  call rax
000079a3731d9d9a  movaps xmm10, [rsp]
000079a3731d9d9f  add rsp, 0x30
000079a3731d9da3  vmovaps xmm0, [rsp]
000079a3731d9da8  vmovaps xmm1, [rsp+0x10]
000079a3731d9dae  vmovaps xmm2, [rsp+0x20]
000079a3731d9db4  vmovaps xmm3, [rsp+0x30]
000079a3731d9dba  vmovaps xmm4, [rsp+0x40]
000079a3731d9dc0  vmovaps xmm5, [rsp+0x50]
000079a3731d9dc6  vmovaps xmm6, [rsp+0x60]
000079a3731d9dcc  vmovaps xmm7, [rsp+0x70]
000079a3731d9dd2  vmovaps xmm8, [rsp+0x80]
000079a3731d9ddb  vmovaps xmm9, [rsp+0x90]
000079a3731d9de4  vmovaps xmm11, [rsp+0xA0]
000079a3731d9ded  vmovaps xmm12, [rsp+0xB0]
000079a3731d9df6  vmovaps xmm13, [rsp+0xC0]
000079a3731d9dff  vmovaps xmm14, [rsp+0xD0]
000079a3731d9e08  vmovaps xmm15, [rsp+0xE0]
000079a3731d9e11  add rsp, 0xF0
000079a3731d9e18  pop r11
000079a3731d9e1a  pop r10
000079a3731d9e1c  pop r9
000079a3731d9e1e  pop r8
000079a3731d9e20  pop rsi
000079a3731d9e21  pop rdi
000079a3731d9e22  pop rdx
000079a3731d9e23  pop rcx
000079a3731d9e24  pop rax
000079a3731d9e25  add rsp, 0x08
000079a3731d9e29  jmp 0x000079A3731D6388
000079a3731d9e2e  sub rsp, 0x08
000079a3731d9e32  push rax
000079a3731d9e33  push rcx
000079a3731d9e34  push rdx
000079a3731d9e35  push rdi
000079a3731d9e36  push rsi
000079a3731d9e37  push r8
000079a3731d9e39  push r9
000079a3731d9e3b  push r10
000079a3731d9e3d  push r11
000079a3731d9e3f  sub rsp, 0xF0
000079a3731d9e46  vmovaps [rsp], xmm0
000079a3731d9e4b  vmovaps [rsp+0x10], xmm1
000079a3731d9e51  vmovaps [rsp+0x20], xmm2
000079a3731d9e57  vmovaps [rsp+0x30], xmm3
000079a3731d9e5d  vmovaps [rsp+0x40], xmm4
000079a3731d9e63  vmovaps [rsp+0x50], xmm5
000079a3731d9e69  vmovaps [rsp+0x60], xmm6
000079a3731d9e6f  vmovaps [rsp+0x70], xmm7
000079a3731d9e75  vmovaps [rsp+0x80], xmm9
000079a3731d9e7e  vmovaps [rsp+0x90], xmm10
000079a3731d9e87  vmovaps [rsp+0xA0], xmm11
000079a3731d9e90  vmovaps [rsp+0xB0], xmm12
000079a3731d9e99  vmovaps [rsp+0xC0], xmm13
000079a3731d9ea2  vmovaps [rsp+0xD0], xmm14
000079a3731d9eab  vmovaps [rsp+0xE0], xmm15
000079a3731d9eb4  sub rsp, 0x30
000079a3731d9eb8  movaps [rsp], xmm8
000079a3731d9ebd  movaps [rsp+0x10], xmm1
000079a3731d9ec2  movaps [rsp+0x20], xmm14
000079a3731d9ec8  lea rdi, [rsp]
000079a3731d9ecc  mov esi, 0x00
000079a3731d9ed1  mov rax, 0x64F127B95530
000079a3731d9edb  call rax
000079a3731d9edd  movaps xmm8, [rsp]
000079a3731d9ee2  add rsp, 0x30
000079a3731d9ee6  vmovaps xmm0, [rsp]
000079a3731d9eeb  vmovaps xmm1, [rsp+0x10]
000079a3731d9ef1  vmovaps xmm2, [rsp+0x20]
000079a3731d9ef7  vmovaps xmm3, [rsp+0x30]
000079a3731d9efd  vmovaps xmm4, [rsp+0x40]
000079a3731d9f03  vmovaps xmm5, [rsp+0x50]
000079a3731d9f09  vmovaps xmm6, [rsp+0x60]
000079a3731d9f0f  vmovaps xmm7, [rsp+0x70]
000079a3731d9f15  vmovaps xmm9, [rsp+0x80]
000079a3731d9f1e  vmovaps xmm10, [rsp+0x90]
000079a3731d9f27  vmovaps xmm11, [rsp+0xA0]
000079a3731d9f30  vmovaps xmm12, [rsp+0xB0]
000079a3731d9f39  vmovaps xmm13, [rsp+0xC0]
000079a3731d9f42  vmovaps xmm14, [rsp+0xD0]
000079a3731d9f4b  vmovaps xmm15, [rsp+0xE0]
000079a3731d9f54  add rsp, 0xF0
000079a3731d9f5b  pop r11
000079a3731d9f5d  pop r10
000079a3731d9f5f  pop r9
000079a3731d9f61  pop r8
000079a3731d9f63  pop rsi
000079a3731d9f64  pop rdi
000079a3731d9f65  pop rdx
000079a3731d9f66  pop rcx
000079a3731d9f67  pop rax
000079a3731d9f68  add rsp, 0x08
000079a3731d9f6c  jmp 0x000079A3731D63AE
000079a3731d9f71  sub rsp, 0x08
000079a3731d9f75  push rax
000079a3731d9f76  push rcx
000079a3731d9f77  push rdx
000079a3731d9f78  push rdi
000079a3731d9f79  push rsi
000079a3731d9f7a  push r8
000079a3731d9f7c  push r9
000079a3731d9f7e  push r10
000079a3731d9f80  push r11
000079a3731d9f82  sub rsp, 0xF0
000079a3731d9f89  vmovaps [rsp], xmm0
000079a3731d9f8e  vmovaps [rsp+0x10], xmm1
000079a3731d9f94  vmovaps [rsp+0x20], xmm2
000079a3731d9f9a  vmovaps [rsp+0x30], xmm3
000079a3731d9fa0  vmovaps [rsp+0x40], xmm4
000079a3731d9fa6  vmovaps [rsp+0x50], xmm5
000079a3731d9fac  vmovaps [rsp+0x60], xmm7
000079a3731d9fb2  vmovaps [rsp+0x70], xmm8
000079a3731d9fb8  vmovaps [rsp+0x80], xmm9
000079a3731d9fc1  vmovaps [rsp+0x90], xmm10
000079a3731d9fca  vmovaps [rsp+0xA0], xmm11
000079a3731d9fd3  vmovaps [rsp+0xB0], xmm12
000079a3731d9fdc  vmovaps [rsp+0xC0], xmm13
000079a3731d9fe5  vmovaps [rsp+0xD0], xmm14
000079a3731d9fee  vmovaps [rsp+0xE0], xmm15
000079a3731d9ff7  sub rsp, 0x30
000079a3731d9ffb  movaps [rsp], xmm6
000079a3731d9fff  movaps [rsp+0x10], xmm1
000079a3731da004  movaps [rsp+0x20], xmm14
000079a3731da00a  lea rdi, [rsp]
000079a3731da00e  mov esi, 0x00
000079a3731da013  mov rax, 0x64F127B95530
000079a3731da01d  call rax
000079a3731da01f  movaps xmm6, [rsp]
000079a3731da023  add rsp, 0x30
000079a3731da027  vmovaps xmm0, [rsp]
000079a3731da02c  vmovaps xmm1, [rsp+0x10]
000079a3731da032  vmovaps xmm2, [rsp+0x20]
000079a3731da038  vmovaps xmm3, [rsp+0x30]
000079a3731da03e  vmovaps xmm4, [rsp+0x40]
000079a3731da044  vmovaps xmm5, [rsp+0x50]
000079a3731da04a  vmovaps xmm7, [rsp+0x60]
000079a3731da050  vmovaps xmm8, [rsp+0x70]
000079a3731da056  vmovaps xmm9, [rsp+0x80]
000079a3731da05f  vmovaps xmm10, [rsp+0x90]
000079a3731da068  vmovaps xmm11, [rsp+0xA0]
000079a3731da071  vmovaps xmm12, [rsp+0xB0]
000079a3731da07a  vmovaps xmm13, [rsp+0xC0]
000079a3731da083  vmovaps xmm14, [rsp+0xD0]
000079a3731da08c  vmovaps xmm15, [rsp+0xE0]
000079a3731da095  add rsp, 0xF0
000079a3731da09c  pop r11
000079a3731da09e  pop r10
000079a3731da0a0  pop r9
000079a3731da0a2  pop r8
000079a3731da0a4  pop rsi
000079a3731da0a5  pop rdi
000079a3731da0a6  pop rdx
000079a3731da0a7  pop rcx
000079a3731da0a8  pop rax
000079a3731da0a9  add rsp, 0x08
000079a3731da0ad  jmp 0x000079A3731D63DA
000079a3731da0b2  sub rsp, 0x08
000079a3731da0b6  push rax
000079a3731da0b7  push rcx
000079a3731da0b8  push rdx
000079a3731da0b9  push rdi
000079a3731da0ba  push rsi
000079a3731da0bb  push r8
000079a3731da0bd  push r9
000079a3731da0bf  push r10
000079a3731da0c1  push r11
000079a3731da0c3  sub rsp, 0xF0
000079a3731da0ca  vmovaps [rsp], xmm0
000079a3731da0cf  vmovaps [rsp+0x10], xmm1
000079a3731da0d5  vmovaps [rsp+0x20], xmm2
000079a3731da0db  vmovaps [rsp+0x30], xmm3
000079a3731da0e1  vmovaps [rsp+0x40], xmm4
000079a3731da0e7  vmovaps [rsp+0x50], xmm5
000079a3731da0ed  vmovaps [rsp+0x60], xmm6
000079a3731da0f3  vmovaps [rsp+0x70], xmm7
000079a3731da0f9  vmovaps [rsp+0x80], xmm8
000079a3731da102  vmovaps [rsp+0x90], xmm9
000079a3731da10b  vmovaps [rsp+0xA0], xmm10
000079a3731da114  vmovaps [rsp+0xB0], xmm11
000079a3731da11d  vmovaps [rsp+0xC0], xmm12
000079a3731da126  vmovaps [rsp+0xD0], xmm13
000079a3731da12f  vmovaps [rsp+0xE0], xmm15
000079a3731da138  sub rsp, 0x30
000079a3731da13c  movaps [rsp], xmm14
000079a3731da141  movaps [rsp+0x10], xmm12
000079a3731da147  movaps [rsp+0x20], xmm1
000079a3731da14c  lea rdi, [rsp]
000079a3731da150  mov esi, 0x00
000079a3731da155  mov rax, 0x64F127B95530
000079a3731da15f  call rax
000079a3731da161  movaps xmm14, [rsp]
000079a3731da166  add rsp, 0x30
000079a3731da16a  vmovaps xmm0, [rsp]
000079a3731da16f  vmovaps xmm1, [rsp+0x10]
000079a3731da175  vmovaps xmm2, [rsp+0x20]
000079a3731da17b  vmovaps xmm3, [rsp+0x30]
000079a3731da181  vmovaps xmm4, [rsp+0x40]
000079a3731da187  vmovaps xmm5, [rsp+0x50]
000079a3731da18d  vmovaps xmm6, [rsp+0x60]
000079a3731da193  vmovaps xmm7, [rsp+0x70]
000079a3731da199  vmovaps xmm8, [rsp+0x80]
000079a3731da1a2  vmovaps xmm9, [rsp+0x90]
000079a3731da1ab  vmovaps xmm10, [rsp+0xA0]
000079a3731da1b4  vmovaps xmm11, [rsp+0xB0]
000079a3731da1bd  vmovaps xmm12, [rsp+0xC0]
000079a3731da1c6  vmovaps xmm13, [rsp+0xD0]
000079a3731da1cf  vmovaps xmm15, [rsp+0xE0]
000079a3731da1d8  add rsp, 0xF0
000079a3731da1df  pop r11
000079a3731da1e1  pop r10
000079a3731da1e3  pop r9
000079a3731da1e5  pop r8
000079a3731da1e7  pop rsi
000079a3731da1e8  pop rdi
000079a3731da1e9  pop rdx
000079a3731da1ea  pop rcx
000079a3731da1eb  pop rax
000079a3731da1ec  add rsp, 0x08
000079a3731da1f0  jmp 0x000079A3731D6400
000079a3731da1f5  sub rsp, 0x08
000079a3731da1f9  push rax
000079a3731da1fa  push rcx
000079a3731da1fb  push rdx
000079a3731da1fc  push rdi
000079a3731da1fd  push rsi
000079a3731da1fe  push r8
000079a3731da200  push r9
000079a3731da202  push r10
000079a3731da204  push r11
000079a3731da206  sub rsp, 0xF0
000079a3731da20d  vmovaps [rsp], xmm0
000079a3731da212  vmovaps [rsp+0x10], xmm2
000079a3731da218  vmovaps [rsp+0x20], xmm3
000079a3731da21e  vmovaps [rsp+0x30], xmm4
000079a3731da224  vmovaps [rsp+0x40], xmm5
000079a3731da22a  vmovaps [rsp+0x50], xmm6
000079a3731da230  vmovaps [rsp+0x60], xmm7
000079a3731da236  vmovaps [rsp+0x70], xmm8
000079a3731da23c  vmovaps [rsp+0x80], xmm9
000079a3731da245  vmovaps [rsp+0x90], xmm10
000079a3731da24e  vmovaps [rsp+0xA0], xmm11
000079a3731da257  vmovaps [rsp+0xB0], xmm12
000079a3731da260  vmovaps [rsp+0xC0], xmm13
000079a3731da269  vmovaps [rsp+0xD0], xmm14
000079a3731da272  vmovaps [rsp+0xE0], xmm15
000079a3731da27b  sub rsp, 0x30
000079a3731da27f  movaps [rsp], xmm1
000079a3731da283  movaps [rsp+0x10], xmm13
000079a3731da289  movaps [rsp+0x20], xmm9
000079a3731da28f  lea rdi, [rsp]
000079a3731da293  mov esi, 0x00
000079a3731da298  mov rax, 0x64F127B95530
000079a3731da2a2  call rax
000079a3731da2a4  movaps xmm1, [rsp]
000079a3731da2a8  add rsp, 0x30
000079a3731da2ac  vmovaps xmm0, [rsp]
000079a3731da2b1  vmovaps xmm2, [rsp+0x10]
000079a3731da2b7  vmovaps xmm3, [rsp+0x20]
000079a3731da2bd  vmovaps xmm4, [rsp+0x30]
000079a3731da2c3  vmovaps xmm5, [rsp+0x40]
000079a3731da2c9  vmovaps xmm6, [rsp+0x50]
000079a3731da2cf  vmovaps xmm7, [rsp+0x60]
000079a3731da2d5  vmovaps xmm8, [rsp+0x70]
000079a3731da2db  vmovaps xmm9, [rsp+0x80]
000079a3731da2e4  vmovaps xmm10, [rsp+0x90]
000079a3731da2ed  vmovaps xmm11, [rsp+0xA0]
000079a3731da2f6  vmovaps xmm12, [rsp+0xB0]
000079a3731da2ff  vmovaps xmm13, [rsp+0xC0]
000079a3731da308  vmovaps xmm14, [rsp+0xD0]
000079a3731da311  vmovaps xmm15, [rsp+0xE0]
000079a3731da31a  add rsp, 0xF0
000079a3731da321  pop r11
000079a3731da323  pop r10
000079a3731da325  pop r9
000079a3731da327  pop r8
000079a3731da329  pop rsi
000079a3731da32a  pop rdi
000079a3731da32b  pop rdx
000079a3731da32c  pop rcx
000079a3731da32d  pop rax
000079a3731da32e  add rsp, 0x08
000079a3731da332  jmp 0x000079A3731D641A
000079a3731da337  sub rsp, 0x08
000079a3731da33b  push rax
000079a3731da33c  push rcx
000079a3731da33d  push rdx
000079a3731da33e  push rdi
000079a3731da33f  push rsi
000079a3731da340  push r8
000079a3731da342  push r9
000079a3731da344  push r10
000079a3731da346  push r11
000079a3731da348  sub rsp, 0xF0
000079a3731da34f  vmovaps [rsp], xmm0
000079a3731da354  vmovaps [rsp+0x10], xmm1
000079a3731da35a  vmovaps [rsp+0x20], xmm2
000079a3731da360  vmovaps [rsp+0x30], xmm3
000079a3731da366  vmovaps [rsp+0x40], xmm4
000079a3731da36c  vmovaps [rsp+0x50], xmm5
000079a3731da372  vmovaps [rsp+0x60], xmm6
000079a3731da378  vmovaps [rsp+0x70], xmm7
000079a3731da37e  vmovaps [rsp+0x80], xmm8
000079a3731da387  vmovaps [rsp+0x90], xmm9
000079a3731da390  vmovaps [rsp+0xA0], xmm10
000079a3731da399  vmovaps [rsp+0xB0], xmm11
000079a3731da3a2  vmovaps [rsp+0xC0], xmm13
000079a3731da3ab  vmovaps [rsp+0xD0], xmm14
000079a3731da3b4  vmovaps [rsp+0xE0], xmm15
000079a3731da3bd  sub rsp, 0x30
000079a3731da3c1  movaps [rsp], xmm12
000079a3731da3c6  movaps [rsp+0x10], xmm7
000079a3731da3cb  movaps [rsp+0x20], xmm13
000079a3731da3d1  lea rdi, [rsp]
000079a3731da3d5  mov esi, 0x00
000079a3731da3da  mov rax, 0x64F127B95530
000079a3731da3e4  call rax
000079a3731da3e6  movaps xmm12, [rsp]
000079a3731da3eb  add rsp, 0x30
000079a3731da3ef  vmovaps xmm0, [rsp]
000079a3731da3f4  vmovaps xmm1, [rsp+0x10]
000079a3731da3fa  vmovaps xmm2, [rsp+0x20]
000079a3731da400  vmovaps xmm3, [rsp+0x30]
000079a3731da406  vmovaps xmm4, [rsp+0x40]
000079a3731da40c  vmovaps xmm5, [rsp+0x50]
000079a3731da412  vmovaps xmm6, [rsp+0x60]
000079a3731da418  vmovaps xmm7, [rsp+0x70]
000079a3731da41e  vmovaps xmm8, [rsp+0x80]
000079a3731da427  vmovaps xmm9, [rsp+0x90]
000079a3731da430  vmovaps xmm10, [rsp+0xA0]
000079a3731da439  vmovaps xmm11, [rsp+0xB0]
000079a3731da442  vmovaps xmm13, [rsp+0xC0]
000079a3731da44b  vmovaps xmm14, [rsp+0xD0]
000079a3731da454  vmovaps xmm15, [rsp+0xE0]
000079a3731da45d  add rsp, 0xF0
000079a3731da464  pop r11
000079a3731da466  pop r10
000079a3731da468  pop r9
000079a3731da46a  pop r8
000079a3731da46c  pop rsi
000079a3731da46d  pop rdi
000079a3731da46e  pop rdx
000079a3731da46f  pop rcx
000079a3731da470  pop rax
000079a3731da471  add rsp, 0x08
000079a3731da475  jmp 0x000079A3731D6441
000079a3731da47a  sub rsp, 0x08
000079a3731da47e  push rax
000079a3731da47f  push rcx
000079a3731da480  push rdx
000079a3731da481  push rdi
000079a3731da482  push rsi
000079a3731da483  push r8
000079a3731da485  push r9
000079a3731da487  push r10
000079a3731da489  push r11
000079a3731da48b  sub rsp, 0xF0
000079a3731da492  vmovaps [rsp], xmm0
000079a3731da497  vmovaps [rsp+0x10], xmm1
000079a3731da49d  vmovaps [rsp+0x20], xmm2
000079a3731da4a3  vmovaps [rsp+0x30], xmm3
000079a3731da4a9  vmovaps [rsp+0x40], xmm4
000079a3731da4af  vmovaps [rsp+0x50], xmm5
000079a3731da4b5  vmovaps [rsp+0x60], xmm6
000079a3731da4bb  vmovaps [rsp+0x70], xmm7
000079a3731da4c1  vmovaps [rsp+0x80], xmm8
000079a3731da4ca  vmovaps [rsp+0x90], xmm9
000079a3731da4d3  vmovaps [rsp+0xA0], xmm10
000079a3731da4dc  vmovaps [rsp+0xB0], xmm11
000079a3731da4e5  vmovaps [rsp+0xC0], xmm12
000079a3731da4ee  vmovaps [rsp+0xD0], xmm14
000079a3731da4f7  vmovaps [rsp+0xE0], xmm15
000079a3731da500  sub rsp, 0x30
000079a3731da504  movaps [rsp], xmm13
000079a3731da509  movaps [rsp+0x10], xmm15
000079a3731da50f  movaps [rsp+0x20], xmm8
000079a3731da515  lea rdi, [rsp]
000079a3731da519  mov esi, 0x00
000079a3731da51e  mov rax, 0x64F127B95530
000079a3731da528  call rax
000079a3731da52a  movaps xmm13, [rsp]
000079a3731da52f  add rsp, 0x30
000079a3731da533  vmovaps xmm0, [rsp]
000079a3731da538  vmovaps xmm1, [rsp+0x10]
000079a3731da53e  vmovaps xmm2, [rsp+0x20]
000079a3731da544  vmovaps xmm3, [rsp+0x30]
000079a3731da54a  vmovaps xmm4, [rsp+0x40]
000079a3731da550  vmovaps xmm5, [rsp+0x50]
000079a3731da556  vmovaps xmm6, [rsp+0x60]
000079a3731da55c  vmovaps xmm7, [rsp+0x70]
000079a3731da562  vmovaps xmm8, [rsp+0x80]
000079a3731da56b  vmovaps xmm9, [rsp+0x90]
000079a3731da574  vmovaps xmm10, [rsp+0xA0]
000079a3731da57d  vmovaps xmm11, [rsp+0xB0]
000079a3731da586  vmovaps xmm12, [rsp+0xC0]
000079a3731da58f  vmovaps xmm14, [rsp+0xD0]
000079a3731da598  vmovaps xmm15, [rsp+0xE0]
000079a3731da5a1  add rsp, 0xF0
000079a3731da5a8  pop r11
000079a3731da5aa  pop r10
000079a3731da5ac  pop r9
000079a3731da5ae  pop r8
000079a3731da5b0  pop rsi
000079a3731da5b1  pop rdi
000079a3731da5b2  pop rdx
000079a3731da5b3  pop rcx
000079a3731da5b4  pop rax
000079a3731da5b5  add rsp, 0x08
000079a3731da5b9  jmp 0x000079A3731D645C
000079a3731da5be  sub rsp, 0x08
000079a3731da5c2  push rax
000079a3731da5c3  push rcx
000079a3731da5c4  push rdx
000079a3731da5c5  push rdi
000079a3731da5c6  push rsi
000079a3731da5c7  push r8
000079a3731da5c9  push r9
000079a3731da5cb  push r10
000079a3731da5cd  push r11
000079a3731da5cf  sub rsp, 0xF0
000079a3731da5d6  vmovaps [rsp], xmm0
000079a3731da5db  vmovaps [rsp+0x10], xmm1
000079a3731da5e1  vmovaps [rsp+0x20], xmm2
000079a3731da5e7  vmovaps [rsp+0x30], xmm3
000079a3731da5ed  vmovaps [rsp+0x40], xmm4
000079a3731da5f3  vmovaps [rsp+0x50], xmm5
000079a3731da5f9  vmovaps [rsp+0x60], xmm6
000079a3731da5ff  vmovaps [rsp+0x70], xmm7
000079a3731da605  vmovaps [rsp+0x80], xmm9
000079a3731da60e  vmovaps [rsp+0x90], xmm10
000079a3731da617  vmovaps [rsp+0xA0], xmm11
000079a3731da620  vmovaps [rsp+0xB0], xmm12
000079a3731da629  vmovaps [rsp+0xC0], xmm13
000079a3731da632  vmovaps [rsp+0xD0], xmm14
000079a3731da63b  vmovaps [rsp+0xE0], xmm15
000079a3731da644  sub rsp, 0x30
000079a3731da648  movaps [rsp], xmm8
000079a3731da64d  movaps [rsp+0x10], xmm15
000079a3731da653  movaps [rsp+0x20], xmm9
000079a3731da659  lea rdi, [rsp]
000079a3731da65d  mov esi, 0x00
000079a3731da662  mov rax, 0x64F127B95530
000079a3731da66c  call rax
000079a3731da66e  movaps xmm8, [rsp]
000079a3731da673  add rsp, 0x30
000079a3731da677  vmovaps xmm0, [rsp]
000079a3731da67c  vmovaps xmm1, [rsp+0x10]
000079a3731da682  vmovaps xmm2, [rsp+0x20]
000079a3731da688  vmovaps xmm3, [rsp+0x30]
000079a3731da68e  vmovaps xmm4, [rsp+0x40]
000079a3731da694  vmovaps xmm5, [rsp+0x50]
000079a3731da69a  vmovaps xmm6, [rsp+0x60]
000079a3731da6a0  vmovaps xmm7, [rsp+0x70]
000079a3731da6a6  vmovaps xmm9, [rsp+0x80]
000079a3731da6af  vmovaps xmm10, [rsp+0x90]
000079a3731da6b8  vmovaps xmm11, [rsp+0xA0]
000079a3731da6c1  vmovaps xmm12, [rsp+0xB0]
000079a3731da6ca  vmovaps xmm13, [rsp+0xC0]
000079a3731da6d3  vmovaps xmm14, [rsp+0xD0]
000079a3731da6dc  vmovaps xmm15, [rsp+0xE0]
000079a3731da6e5  add rsp, 0xF0
000079a3731da6ec  pop r11
000079a3731da6ee  pop r10
000079a3731da6f0  pop r9
000079a3731da6f2  pop r8
000079a3731da6f4  pop rsi
000079a3731da6f5  pop rdi
000079a3731da6f6  pop rdx
000079a3731da6f7  pop rcx
000079a3731da6f8  pop rax
000079a3731da6f9  add rsp, 0x08
000079a3731da6fd  jmp 0x000079A3731D648A
000079a3731da702  sub rsp, 0x08
000079a3731da706  push rax
000079a3731da707  push rcx
000079a3731da708  push rdx
000079a3731da709  push rdi
000079a3731da70a  push rsi
000079a3731da70b  push r8
000079a3731da70d  push r9
000079a3731da70f  push r10
000079a3731da711  push r11
000079a3731da713  sub rsp, 0xF0
000079a3731da71a  vmovaps [rsp], xmm0
000079a3731da71f  vmovaps [rsp+0x10], xmm1
000079a3731da725  vmovaps [rsp+0x20], xmm2
000079a3731da72b  vmovaps [rsp+0x30], xmm3
000079a3731da731  vmovaps [rsp+0x40], xmm4
000079a3731da737  vmovaps [rsp+0x50], xmm5
000079a3731da73d  vmovaps [rsp+0x60], xmm6
000079a3731da743  vmovaps [rsp+0x70], xmm7
000079a3731da749  vmovaps [rsp+0x80], xmm8
000079a3731da752  vmovaps [rsp+0x90], xmm9
000079a3731da75b  vmovaps [rsp+0xA0], xmm10
000079a3731da764  vmovaps [rsp+0xB0], xmm11
000079a3731da76d  vmovaps [rsp+0xC0], xmm12
000079a3731da776  vmovaps [rsp+0xD0], xmm13
000079a3731da77f  vmovaps [rsp+0xE0], xmm14
000079a3731da788  sub rsp, 0x30
000079a3731da78c  movaps [rsp], xmm15
000079a3731da791  movaps [rsp+0x10], xmm11
000079a3731da797  movaps [rsp+0x20], xmm6
000079a3731da79c  lea rdi, [rsp]
000079a3731da7a0  mov esi, 0x00
000079a3731da7a5  mov rax, 0x64F127B95530
000079a3731da7af  call rax
000079a3731da7b1  movaps xmm15, [rsp]
000079a3731da7b6  add rsp, 0x30
000079a3731da7ba  vmovaps xmm0, [rsp]
000079a3731da7bf  vmovaps xmm1, [rsp+0x10]
000079a3731da7c5  vmovaps xmm2, [rsp+0x20]
000079a3731da7cb  vmovaps xmm3, [rsp+0x30]
000079a3731da7d1  vmovaps xmm4, [rsp+0x40]
000079a3731da7d7  vmovaps xmm5, [rsp+0x50]
000079a3731da7dd  vmovaps xmm6, [rsp+0x60]
000079a3731da7e3  vmovaps xmm7, [rsp+0x70]
000079a3731da7e9  vmovaps xmm8, [rsp+0x80]
000079a3731da7f2  vmovaps xmm9, [rsp+0x90]
000079a3731da7fb  vmovaps xmm10, [rsp+0xA0]
000079a3731da804  vmovaps xmm11, [rsp+0xB0]
000079a3731da80d  vmovaps xmm12, [rsp+0xC0]
000079a3731da816  vmovaps xmm13, [rsp+0xD0]
000079a3731da81f  vmovaps xmm14, [rsp+0xE0]
000079a3731da828  add rsp, 0xF0
000079a3731da82f  pop r11
000079a3731da831  pop r10
000079a3731da833  pop r9
000079a3731da835  pop r8
000079a3731da837  pop rsi
000079a3731da838  pop rdi
000079a3731da839  pop rdx
000079a3731da83a  pop rcx
000079a3731da83b  pop rax
000079a3731da83c  add rsp, 0x08
000079a3731da840  jmp 0x000079A3731D64A5
000079a3731da845  sub rsp, 0x08
000079a3731da849  push rax
000079a3731da84a  push rcx
000079a3731da84b  push rdx
000079a3731da84c  push rdi
000079a3731da84d  push rsi
000079a3731da84e  push r8
000079a3731da850  push r9
000079a3731da852  push r10
000079a3731da854  push r11
000079a3731da856  sub rsp, 0xF0
000079a3731da85d  vmovaps [rsp], xmm0
000079a3731da862  vmovaps [rsp+0x10], xmm1
000079a3731da868  vmovaps [rsp+0x20], xmm2
000079a3731da86e  vmovaps [rsp+0x30], xmm3
000079a3731da874  vmovaps [rsp+0x40], xmm4
000079a3731da87a  vmovaps [rsp+0x50], xmm5
000079a3731da880  vmovaps [rsp+0x60], xmm6
000079a3731da886  vmovaps [rsp+0x70], xmm8
000079a3731da88c  vmovaps [rsp+0x80], xmm9
000079a3731da895  vmovaps [rsp+0x90], xmm10
000079a3731da89e  vmovaps [rsp+0xA0], xmm11
000079a3731da8a7  vmovaps [rsp+0xB0], xmm12
000079a3731da8b0  vmovaps [rsp+0xC0], xmm13
000079a3731da8b9  vmovaps [rsp+0xD0], xmm14
000079a3731da8c2  vmovaps [rsp+0xE0], xmm15
000079a3731da8cb  sub rsp, 0x30
000079a3731da8cf  movaps [rsp], xmm7
000079a3731da8d3  movaps [rsp+0x10], xmm11
000079a3731da8d9  movaps [rsp+0x20], xmm9
000079a3731da8df  lea rdi, [rsp]
000079a3731da8e3  mov esi, 0x00
000079a3731da8e8  mov rax, 0x64F127B95530
000079a3731da8f2  call rax
000079a3731da8f4  movaps xmm7, [rsp]
000079a3731da8f8  add rsp, 0x30
000079a3731da8fc  vmovaps xmm0, [rsp]
000079a3731da901  vmovaps xmm1, [rsp+0x10]
000079a3731da907  vmovaps xmm2, [rsp+0x20]
000079a3731da90d  vmovaps xmm3, [rsp+0x30]
000079a3731da913  vmovaps xmm4, [rsp+0x40]
000079a3731da919  vmovaps xmm5, [rsp+0x50]
000079a3731da91f  vmovaps xmm6, [rsp+0x60]
000079a3731da925  vmovaps xmm8, [rsp+0x70]
000079a3731da92b  vmovaps xmm9, [rsp+0x80]
000079a3731da934  vmovaps xmm10, [rsp+0x90]
000079a3731da93d  vmovaps xmm11, [rsp+0xA0]
000079a3731da946  vmovaps xmm12, [rsp+0xB0]
000079a3731da94f  vmovaps xmm13, [rsp+0xC0]
000079a3731da958  vmovaps xmm14, [rsp+0xD0]
000079a3731da961  vmovaps xmm15, [rsp+0xE0]
000079a3731da96a  add rsp, 0xF0
000079a3731da971  pop r11
000079a3731da973  pop r10
000079a3731da975  pop r9
000079a3731da977  pop r8
000079a3731da979  pop rsi
000079a3731da97a  pop rdi
000079a3731da97b  pop rdx
000079a3731da97c  pop rcx
000079a3731da97d  pop rax
000079a3731da97e  add rsp, 0x08
000079a3731da982  jmp 0x000079A3731D64D2
000079a3731da987  sub rsp, 0x08
000079a3731da98b  push rax
000079a3731da98c  push rcx
000079a3731da98d  push rdx
000079a3731da98e  push rdi
000079a3731da98f  push rsi
000079a3731da990  push r8
000079a3731da992  push r9
000079a3731da994  push r10
000079a3731da996  push r11
000079a3731da998  sub rsp, 0xF0
000079a3731da99f  vmovaps [rsp], xmm0
000079a3731da9a4  vmovaps [rsp+0x10], xmm1
000079a3731da9aa  vmovaps [rsp+0x20], xmm2
000079a3731da9b0  vmovaps [rsp+0x30], xmm3
000079a3731da9b6  vmovaps [rsp+0x40], xmm4
000079a3731da9bc  vmovaps [rsp+0x50], xmm5
000079a3731da9c2  vmovaps [rsp+0x60], xmm6
000079a3731da9c8  vmovaps [rsp+0x70], xmm7
000079a3731da9ce  vmovaps [rsp+0x80], xmm8
000079a3731da9d7  vmovaps [rsp+0x90], xmm9
000079a3731da9e0  vmovaps [rsp+0xA0], xmm10
000079a3731da9e9  vmovaps [rsp+0xB0], xmm12
000079a3731da9f2  vmovaps [rsp+0xC0], xmm13
000079a3731da9fb  vmovaps [rsp+0xD0], xmm14
000079a3731daa04  vmovaps [rsp+0xE0], xmm15
000079a3731daa0d  sub rsp, 0x30
000079a3731daa11  movaps [rsp], xmm11
000079a3731daa16  movaps [rsp+0x10], xmm10
000079a3731daa1c  movaps [rsp+0x20], xmm14
000079a3731daa22  lea rdi, [rsp]
000079a3731daa26  mov esi, 0x00
000079a3731daa2b  mov rax, 0x64F127B95530
000079a3731daa35  call rax
000079a3731daa37  movaps xmm11, [rsp]
000079a3731daa3c  add rsp, 0x30
000079a3731daa40  vmovaps xmm0, [rsp]
000079a3731daa45  vmovaps xmm1, [rsp+0x10]
000079a3731daa4b  vmovaps xmm2, [rsp+0x20]
000079a3731daa51  vmovaps xmm3, [rsp+0x30]
000079a3731daa57  vmovaps xmm4, [rsp+0x40]
000079a3731daa5d  vmovaps xmm5, [rsp+0x50]
000079a3731daa63  vmovaps xmm6, [rsp+0x60]
000079a3731daa69  vmovaps xmm7, [rsp+0x70]
000079a3731daa6f  vmovaps xmm8, [rsp+0x80]
000079a3731daa78  vmovaps xmm9, [rsp+0x90]
000079a3731daa81  vmovaps xmm10, [rsp+0xA0]
000079a3731daa8a  vmovaps xmm12, [rsp+0xB0]
000079a3731daa93  vmovaps xmm13, [rsp+0xC0]
000079a3731daa9c  vmovaps xmm14, [rsp+0xD0]
000079a3731daaa5  vmovaps xmm15, [rsp+0xE0]
000079a3731daaae  add rsp, 0xF0
000079a3731daab5  pop r11
000079a3731daab7  pop r10
000079a3731daab9  pop r9
000079a3731daabb  pop r8
000079a3731daabd  pop rsi
000079a3731daabe  pop rdi
000079a3731daabf  pop rdx
000079a3731daac0  pop rcx
000079a3731daac1  pop rax
000079a3731daac2  add rsp, 0x08
000079a3731daac6  jmp 0x000079A3731D64ED
000079a3731daacb  call 0x000079A3730E45A0
000079a3731daad0  jmp 0x000079A3731D64F7
000079a3731daad5  sub rsp, 0x08
000079a3731daad9  push rax
000079a3731daada  push rcx
000079a3731daadb  push rdx
000079a3731daadc  push rdi
000079a3731daadd  push rsi
000079a3731daade  push r8
000079a3731daae0  push r9
000079a3731daae2  push r10
000079a3731daae4  push r11
000079a3731daae6  sub rsp, 0xF0
000079a3731daaed  vmovaps [rsp], xmm0
000079a3731daaf2  vmovaps [rsp+0x10], xmm1
000079a3731daaf8  vmovaps [rsp+0x20], xmm2
000079a3731daafe  vmovaps [rsp+0x30], xmm3
000079a3731dab04  vmovaps [rsp+0x40], xmm4
000079a3731dab0a  vmovaps [rsp+0x50], xmm5
000079a3731dab10  vmovaps [rsp+0x60], xmm6
000079a3731dab16  vmovaps [rsp+0x70], xmm7
000079a3731dab1c  vmovaps [rsp+0x80], xmm8
000079a3731dab25  vmovaps [rsp+0x90], xmm9
000079a3731dab2e  vmovaps [rsp+0xA0], xmm11
000079a3731dab37  vmovaps [rsp+0xB0], xmm12
000079a3731dab40  vmovaps [rsp+0xC0], xmm13
000079a3731dab49  vmovaps [rsp+0xD0], xmm14
000079a3731dab52  vmovaps [rsp+0xE0], xmm15
000079a3731dab5b  sub rsp, 0x30
000079a3731dab5f  movaps [rsp], xmm10
000079a3731dab64  movaps [rsp+0x10], xmm1
000079a3731dab69  movaps [rsp+0x20], xmm12
000079a3731dab6f  lea rdi, [rsp]
000079a3731dab73  mov esi, 0x00
000079a3731dab78  mov rax, 0x64F127B95530
000079a3731dab82  call rax
000079a3731dab84  movaps xmm10, [rsp]
000079a3731dab89  add rsp, 0x30
000079a3731dab8d  vmovaps xmm0, [rsp]
000079a3731dab92  vmovaps xmm1, [rsp+0x10]
000079a3731dab98  vmovaps xmm2, [rsp+0x20]
000079a3731dab9e  vmovaps xmm3, [rsp+0x30]
000079a3731daba4  vmovaps xmm4, [rsp+0x40]
000079a3731dabaa  vmovaps xmm5, [rsp+0x50]
000079a3731dabb0  vmovaps xmm6, [rsp+0x60]
000079a3731dabb6  vmovaps xmm7, [rsp+0x70]
000079a3731dabbc  vmovaps xmm8, [rsp+0x80]
000079a3731dabc5  vmovaps xmm9, [rsp+0x90]
000079a3731dabce  vmovaps xmm11, [rsp+0xA0]
000079a3731dabd7  vmovaps xmm12, [rsp+0xB0]
000079a3731dabe0  vmovaps xmm13, [rsp+0xC0]
000079a3731dabe9  vmovaps xmm14, [rsp+0xD0]
000079a3731dabf2  vmovaps xmm15, [rsp+0xE0]
000079a3731dabfb  add rsp, 0xF0
000079a3731dac02  pop r11
000079a3731dac04  pop r10
000079a3731dac06  pop r9
000079a3731dac08  pop r8
000079a3731dac0a  pop rsi
000079a3731dac0b  pop rdi
000079a3731dac0c  pop rdx
000079a3731dac0d  pop rcx
000079a3731dac0e  pop rax
000079a3731dac0f  add rsp, 0x08
000079a3731dac13  jmp 0x000079A3731D651A
000079a3731dac18  sub rsp, 0x08
000079a3731dac1c  push rax
000079a3731dac1d  push rcx
000079a3731dac1e  push rdx
000079a3731dac1f  push rdi
000079a3731dac20  push rsi
000079a3731dac21  push r8
000079a3731dac23  push r9
000079a3731dac25  push r10
000079a3731dac27  push r11
000079a3731dac29  sub rsp, 0xF0
000079a3731dac30  vmovaps [rsp], xmm0
000079a3731dac35  vmovaps [rsp+0x10], xmm1
000079a3731dac3b  vmovaps [rsp+0x20], xmm2
000079a3731dac41  vmovaps [rsp+0x30], xmm3
000079a3731dac47  vmovaps [rsp+0x40], xmm4
000079a3731dac4d  vmovaps [rsp+0x50], xmm5
000079a3731dac53  vmovaps [rsp+0x60], xmm6
000079a3731dac59  vmovaps [rsp+0x70], xmm7
000079a3731dac5f  vmovaps [rsp+0x80], xmm8
000079a3731dac68  vmovaps [rsp+0x90], xmm9
000079a3731dac71  vmovaps [rsp+0xA0], xmm10
000079a3731dac7a  vmovaps [rsp+0xB0], xmm11
000079a3731dac83  vmovaps [rsp+0xC0], xmm13
000079a3731dac8c  vmovaps [rsp+0xD0], xmm14
000079a3731dac95  vmovaps [rsp+0xE0], xmm15
000079a3731dac9e  sub rsp, 0x30
000079a3731daca2  movaps [rsp], xmm12
000079a3731daca7  movaps [rsp+0x10], xmm14
000079a3731dacad  movaps [rsp+0x20], xmm1
000079a3731dacb2  lea rdi, [rsp]
000079a3731dacb6  mov esi, 0x00
000079a3731dacbb  mov rax, 0x64F127B95530
000079a3731dacc5  call rax
000079a3731dacc7  movaps xmm12, [rsp]
000079a3731daccc  add rsp, 0x30
000079a3731dacd0  vmovaps xmm0, [rsp]
000079a3731dacd5  vmovaps xmm1, [rsp+0x10]
000079a3731dacdb  vmovaps xmm2, [rsp+0x20]
000079a3731dace1  vmovaps xmm3, [rsp+0x30]
000079a3731dace7  vmovaps xmm4, [rsp+0x40]
000079a3731daced  vmovaps xmm5, [rsp+0x50]
000079a3731dacf3  vmovaps xmm6, [rsp+0x60]
000079a3731dacf9  vmovaps xmm7, [rsp+0x70]
000079a3731dacff  vmovaps xmm8, [rsp+0x80]
000079a3731dad08  vmovaps xmm9, [rsp+0x90]
000079a3731dad11  vmovaps xmm10, [rsp+0xA0]
000079a3731dad1a  vmovaps xmm11, [rsp+0xB0]
000079a3731dad23  vmovaps xmm13, [rsp+0xC0]
000079a3731dad2c  vmovaps xmm14, [rsp+0xD0]
000079a3731dad35  vmovaps xmm15, [rsp+0xE0]
000079a3731dad3e  add rsp, 0xF0
000079a3731dad45  pop r11
000079a3731dad47  pop r10
000079a3731dad49  pop r9
000079a3731dad4b  pop r8
000079a3731dad4d  pop rsi
000079a3731dad4e  pop rdi
000079a3731dad4f  pop rdx
000079a3731dad50  pop rcx
000079a3731dad51  pop rax
000079a3731dad52  add rsp, 0x08
000079a3731dad56  jmp 0x000079A3731D6549
000079a3731dad5b  sub rsp, 0x08
000079a3731dad5f  push rax
000079a3731dad60  push rcx
000079a3731dad61  push rdx
000079a3731dad62  push rdi
000079a3731dad63  push rsi
000079a3731dad64  push r8
000079a3731dad66  push r9
000079a3731dad68  push r10
000079a3731dad6a  push r11
000079a3731dad6c  sub rsp, 0xF0
000079a3731dad73  vmovaps [rsp], xmm0
000079a3731dad78  vmovaps [rsp+0x10], xmm1
000079a3731dad7e  vmovaps [rsp+0x20], xmm2
000079a3731dad84  vmovaps [rsp+0x30], xmm3
000079a3731dad8a  vmovaps [rsp+0x40], xmm4
000079a3731dad90  vmovaps [rsp+0x50], xmm5
000079a3731dad96  vmovaps [rsp+0x60], xmm6
000079a3731dad9c  vmovaps [rsp+0x70], xmm7
000079a3731dada2  vmovaps [rsp+0x80], xmm8
000079a3731dadab  vmovaps [rsp+0x90], xmm9
000079a3731dadb4  vmovaps [rsp+0xA0], xmm10
000079a3731dadbd  vmovaps [rsp+0xB0], xmm11
000079a3731dadc6  vmovaps [rsp+0xC0], xmm12
000079a3731dadcf  vmovaps [rsp+0xD0], xmm13
000079a3731dadd8  vmovaps [rsp+0xE0], xmm15
000079a3731dade1  sub rsp, 0x30
000079a3731dade5  movaps [rsp], xmm14
000079a3731dadea  movaps [rsp+0x10], xmm9
000079a3731dadf0  movaps [rsp+0x20], xmm1
000079a3731dadf5  lea rdi, [rsp]
000079a3731dadf9  mov esi, 0x00
000079a3731dadfe  mov rax, 0x64F127B95530
000079a3731dae08  call rax
000079a3731dae0a  movaps xmm14, [rsp]
000079a3731dae0f  add rsp, 0x30
000079a3731dae13  vmovaps xmm0, [rsp]
000079a3731dae18  vmovaps xmm1, [rsp+0x10]
000079a3731dae1e  vmovaps xmm2, [rsp+0x20]
000079a3731dae24  vmovaps xmm3, [rsp+0x30]
000079a3731dae2a  vmovaps xmm4, [rsp+0x40]
000079a3731dae30  vmovaps xmm5, [rsp+0x50]
000079a3731dae36  vmovaps xmm6, [rsp+0x60]
000079a3731dae3c  vmovaps xmm7, [rsp+0x70]
000079a3731dae42  vmovaps xmm8, [rsp+0x80]
000079a3731dae4b  vmovaps xmm9, [rsp+0x90]
000079a3731dae54  vmovaps xmm10, [rsp+0xA0]
000079a3731dae5d  vmovaps xmm11, [rsp+0xB0]
000079a3731dae66  vmovaps xmm12, [rsp+0xC0]
000079a3731dae6f  vmovaps xmm13, [rsp+0xD0]
000079a3731dae78  vmovaps xmm15, [rsp+0xE0]
000079a3731dae81  add rsp, 0xF0
000079a3731dae88  pop r11
000079a3731dae8a  pop r10
000079a3731dae8c  pop r9
000079a3731dae8e  pop r8
000079a3731dae90  pop rsi
000079a3731dae91  pop rdi
000079a3731dae92  pop rdx
000079a3731dae93  pop rcx
000079a3731dae94  pop rax
000079a3731dae95  add rsp, 0x08
000079a3731dae99  jmp 0x000079A3731D6578
000079a3731dae9e  sub rsp, 0x08
000079a3731daea2  push rax
000079a3731daea3  push rcx
000079a3731daea4  push rdx
000079a3731daea5  push rdi
000079a3731daea6  push rsi
000079a3731daea7  push r8
000079a3731daea9  push r9
000079a3731daeab  push r10
000079a3731daead  push r11
000079a3731daeaf  sub rsp, 0xF0
000079a3731daeb6  vmovaps [rsp], xmm0
000079a3731daebb  vmovaps [rsp+0x10], xmm2
000079a3731daec1  vmovaps [rsp+0x20], xmm3
000079a3731daec7  vmovaps [rsp+0x30], xmm4
000079a3731daecd  vmovaps [rsp+0x40], xmm5
000079a3731daed3  vmovaps [rsp+0x50], xmm6
000079a3731daed9  vmovaps [rsp+0x60], xmm7
000079a3731daedf  vmovaps [rsp+0x70], xmm8
000079a3731daee5  vmovaps [rsp+0x80], xmm9
000079a3731daeee  vmovaps [rsp+0x90], xmm10
000079a3731daef7  vmovaps [rsp+0xA0], xmm11
000079a3731daf00  vmovaps [rsp+0xB0], xmm12
000079a3731daf09  vmovaps [rsp+0xC0], xmm13
000079a3731daf12  vmovaps [rsp+0xD0], xmm14
000079a3731daf1b  vmovaps [rsp+0xE0], xmm15
000079a3731daf24  sub rsp, 0x30
000079a3731daf28  movaps [rsp], xmm1
000079a3731daf2c  movaps [rsp+0x10], xmm13
000079a3731daf32  movaps [rsp+0x20], xmm8
000079a3731daf38  lea rdi, [rsp]
000079a3731daf3c  mov esi, 0x00
000079a3731daf41  mov rax, 0x64F127B95530
000079a3731daf4b  call rax
000079a3731daf4d  movaps xmm1, [rsp]
000079a3731daf51  add rsp, 0x30
000079a3731daf55  vmovaps xmm0, [rsp]
000079a3731daf5a  vmovaps xmm2, [rsp+0x10]
000079a3731daf60  vmovaps xmm3, [rsp+0x20]
000079a3731daf66  vmovaps xmm4, [rsp+0x30]
000079a3731daf6c  vmovaps xmm5, [rsp+0x40]
000079a3731daf72  vmovaps xmm6, [rsp+0x50]
000079a3731daf78  vmovaps xmm7, [rsp+0x60]
000079a3731daf7e  vmovaps xmm8, [rsp+0x70]
000079a3731daf84  vmovaps xmm9, [rsp+0x80]
000079a3731daf8d  vmovaps xmm10, [rsp+0x90]
000079a3731daf96  vmovaps xmm11, [rsp+0xA0]
000079a3731daf9f  vmovaps xmm12, [rsp+0xB0]
000079a3731dafa8  vmovaps xmm13, [rsp+0xC0]
000079a3731dafb1  vmovaps xmm14, [rsp+0xD0]
000079a3731dafba  vmovaps xmm15, [rsp+0xE0]
000079a3731dafc3  add rsp, 0xF0
000079a3731dafca  pop r11
000079a3731dafcc  pop r10
000079a3731dafce  pop r9
000079a3731dafd0  pop r8
000079a3731dafd2  pop rsi
000079a3731dafd3  pop rdi
000079a3731dafd4  pop rdx
000079a3731dafd5  pop rcx
000079a3731dafd6  pop rax
000079a3731dafd7  add rsp, 0x08
000079a3731dafdb  jmp 0x000079A3731D659A
000079a3731dafe0  call 0x000079A37300C260
000079a3731dafe5  jmp 0x000079A3731D65A8
000079a3731dafea  call 0x000079A3730DE950
000079a3731dafef  jmp 0x000079A3731D65B2
000079a3731daff4  sub rsp, 0x08
000079a3731daff8  push rax
000079a3731daff9  push rcx
000079a3731daffa  push rdx
000079a3731daffb  push rdi
000079a3731daffc  push rsi
000079a3731daffd  push r8
000079a3731dafff  push r9
000079a3731db001  push r10
000079a3731db003  push r11
000079a3731db005  sub rsp, 0xF0
000079a3731db00c  vmovaps [rsp], xmm0
000079a3731db011  vmovaps [rsp+0x10], xmm1
000079a3731db017  vmovaps [rsp+0x20], xmm2
000079a3731db01d  vmovaps [rsp+0x30], xmm3
000079a3731db023  vmovaps [rsp+0x40], xmm4
000079a3731db029  vmovaps [rsp+0x50], xmm5
000079a3731db02f  vmovaps [rsp+0x60], xmm6
000079a3731db035  vmovaps [rsp+0x70], xmm7
000079a3731db03b  vmovaps [rsp+0x80], xmm9
000079a3731db044  vmovaps [rsp+0x90], xmm10
000079a3731db04d  vmovaps [rsp+0xA0], xmm11
000079a3731db056  vmovaps [rsp+0xB0], xmm12
000079a3731db05f  vmovaps [rsp+0xC0], xmm13
000079a3731db068  vmovaps [rsp+0xD0], xmm14
000079a3731db071  vmovaps [rsp+0xE0], xmm15
000079a3731db07a  sub rsp, 0x30
000079a3731db07e  movaps [rsp], xmm8
000079a3731db083  movaps [rsp+0x10], xmm15
000079a3731db089  movaps [rsp+0x20], xmm7
000079a3731db08e  lea rdi, [rsp]
000079a3731db092  mov esi, 0x00
000079a3731db097  mov rax, 0x64F127B95530
000079a3731db0a1  call rax
000079a3731db0a3  movaps xmm8, [rsp]
000079a3731db0a8  add rsp, 0x30
000079a3731db0ac  vmovaps xmm0, [rsp]
000079a3731db0b1  vmovaps xmm1, [rsp+0x10]
000079a3731db0b7  vmovaps xmm2, [rsp+0x20]
000079a3731db0bd  vmovaps xmm3, [rsp+0x30]
000079a3731db0c3  vmovaps xmm4, [rsp+0x40]
000079a3731db0c9  vmovaps xmm5, [rsp+0x50]
000079a3731db0cf  vmovaps xmm6, [rsp+0x60]
000079a3731db0d5  vmovaps xmm7, [rsp+0x70]
000079a3731db0db  vmovaps xmm9, [rsp+0x80]
000079a3731db0e4  vmovaps xmm10, [rsp+0x90]
000079a3731db0ed  vmovaps xmm11, [rsp+0xA0]
000079a3731db0f6  vmovaps xmm12, [rsp+0xB0]
000079a3731db0ff  vmovaps xmm13, [rsp+0xC0]
000079a3731db108  vmovaps xmm14, [rsp+0xD0]
000079a3731db111  vmovaps xmm15, [rsp+0xE0]
000079a3731db11a  add rsp, 0xF0
000079a3731db121  pop r11
000079a3731db123  pop r10
000079a3731db125  pop r9
000079a3731db127  pop r8
000079a3731db129  pop rsi
000079a3731db12a  pop rdi
000079a3731db12b  pop rdx
000079a3731db12c  pop rcx
000079a3731db12d  pop rax
000079a3731db12e  add rsp, 0x08
000079a3731db132  jmp 0x000079A3731D65D4
000079a3731db137  sub rsp, 0x08
000079a3731db13b  push rax
000079a3731db13c  push rcx
000079a3731db13d  push rdx
000079a3731db13e  push rdi
000079a3731db13f  push rsi
000079a3731db140  push r8
000079a3731db142  push r9
000079a3731db144  push r10
000079a3731db146  push r11
000079a3731db148  sub rsp, 0xF0
000079a3731db14f  vmovaps [rsp], xmm0
000079a3731db154  vmovaps [rsp+0x10], xmm1
000079a3731db15a  vmovaps [rsp+0x20], xmm2
000079a3731db160  vmovaps [rsp+0x30], xmm3
000079a3731db166  vmovaps [rsp+0x40], xmm4
000079a3731db16c  vmovaps [rsp+0x50], xmm5
000079a3731db172  vmovaps [rsp+0x60], xmm6
000079a3731db178  vmovaps [rsp+0x70], xmm8
000079a3731db17e  vmovaps [rsp+0x80], xmm9
000079a3731db187  vmovaps [rsp+0x90], xmm10
000079a3731db190  vmovaps [rsp+0xA0], xmm11
000079a3731db199  vmovaps [rsp+0xB0], xmm12
000079a3731db1a2  vmovaps [rsp+0xC0], xmm13
000079a3731db1ab  vmovaps [rsp+0xD0], xmm14
000079a3731db1b4  vmovaps [rsp+0xE0], xmm15
000079a3731db1bd  sub rsp, 0x30
000079a3731db1c1  movaps [rsp], xmm7
000079a3731db1c5  movaps [rsp+0x10], xmm9
000079a3731db1cb  movaps [rsp+0x20], xmm15
000079a3731db1d1  lea rdi, [rsp]
000079a3731db1d5  mov esi, 0x00
000079a3731db1da  mov rax, 0x64F127B95530
000079a3731db1e4  call rax
000079a3731db1e6  movaps xmm7, [rsp]
000079a3731db1ea  add rsp, 0x30
000079a3731db1ee  vmovaps xmm0, [rsp]
000079a3731db1f3  vmovaps xmm1, [rsp+0x10]
000079a3731db1f9  vmovaps xmm2, [rsp+0x20]
000079a3731db1ff  vmovaps xmm3, [rsp+0x30]
000079a3731db205  vmovaps xmm4, [rsp+0x40]
000079a3731db20b  vmovaps xmm5, [rsp+0x50]
000079a3731db211  vmovaps xmm6, [rsp+0x60]
000079a3731db217  vmovaps xmm8, [rsp+0x70]
000079a3731db21d  vmovaps xmm9, [rsp+0x80]
000079a3731db226  vmovaps xmm10, [rsp+0x90]
000079a3731db22f  vmovaps xmm11, [rsp+0xA0]
000079a3731db238  vmovaps xmm12, [rsp+0xB0]
000079a3731db241  vmovaps xmm13, [rsp+0xC0]
000079a3731db24a  vmovaps xmm14, [rsp+0xD0]
000079a3731db253  vmovaps xmm15, [rsp+0xE0]
000079a3731db25c  add rsp, 0xF0
000079a3731db263  pop r11
000079a3731db265  pop r10
000079a3731db267  pop r9
000079a3731db269  pop r8
000079a3731db26b  pop rsi
000079a3731db26c  pop rdi
000079a3731db26d  pop rdx
000079a3731db26e  pop rcx
000079a3731db26f  pop rax
000079a3731db270  add rsp, 0x08
000079a3731db274  jmp 0x000079A3731D6601
000079a3731db279  sub rsp, 0x08
000079a3731db27d  push rax
000079a3731db27e  push rcx
000079a3731db27f  push rdx
000079a3731db280  push rdi
000079a3731db281  push rsi
000079a3731db282  push r8
000079a3731db284  push r9
000079a3731db286  push r10
000079a3731db288  push r11
000079a3731db28a  sub rsp, 0xF0
000079a3731db291  vmovaps [rsp], xmm0
000079a3731db296  vmovaps [rsp+0x10], xmm1
000079a3731db29c  vmovaps [rsp+0x20], xmm2
000079a3731db2a2  vmovaps [rsp+0x30], xmm3
000079a3731db2a8  vmovaps [rsp+0x40], xmm4
000079a3731db2ae  vmovaps [rsp+0x50], xmm5
000079a3731db2b4  vmovaps [rsp+0x60], xmm6
000079a3731db2ba  vmovaps [rsp+0x70], xmm7
000079a3731db2c0  vmovaps [rsp+0x80], xmm8
000079a3731db2c9  vmovaps [rsp+0x90], xmm10
000079a3731db2d2  vmovaps [rsp+0xA0], xmm11
000079a3731db2db  vmovaps [rsp+0xB0], xmm12
000079a3731db2e4  vmovaps [rsp+0xC0], xmm13
000079a3731db2ed  vmovaps [rsp+0xD0], xmm14
000079a3731db2f6  vmovaps [rsp+0xE0], xmm15
000079a3731db2ff  sub rsp, 0x30
000079a3731db303  movaps [rsp], xmm9
000079a3731db308  movaps [rsp+0x10], xmm13
000079a3731db30e  movaps [rsp+0x20], xmm15
000079a3731db314  lea rdi, [rsp]
000079a3731db318  mov esi, 0x00
000079a3731db31d  mov rax, 0x64F127B95530
000079a3731db327  call rax
000079a3731db329  movaps xmm9, [rsp]
000079a3731db32e  add rsp, 0x30
000079a3731db332  vmovaps xmm0, [rsp]
000079a3731db337  vmovaps xmm1, [rsp+0x10]
000079a3731db33d  vmovaps xmm2, [rsp+0x20]
000079a3731db343  vmovaps xmm3, [rsp+0x30]
000079a3731db349  vmovaps xmm4, [rsp+0x40]
000079a3731db34f  vmovaps xmm5, [rsp+0x50]
000079a3731db355  vmovaps xmm6, [rsp+0x60]
000079a3731db35b  vmovaps xmm7, [rsp+0x70]
000079a3731db361  vmovaps xmm8, [rsp+0x80]
000079a3731db36a  vmovaps xmm10, [rsp+0x90]
000079a3731db373  vmovaps xmm11, [rsp+0xA0]
000079a3731db37c  vmovaps xmm12, [rsp+0xB0]
000079a3731db385  vmovaps xmm13, [rsp+0xC0]
000079a3731db38e  vmovaps xmm14, [rsp+0xD0]
000079a3731db397  vmovaps xmm15, [rsp+0xE0]
000079a3731db3a0  add rsp, 0xF0
000079a3731db3a7  pop r11
000079a3731db3a9  pop r10
000079a3731db3ab  pop r9
000079a3731db3ad  pop r8
000079a3731db3af  pop rsi
000079a3731db3b0  pop rdi
000079a3731db3b1  pop rdx
000079a3731db3b2  pop rcx
000079a3731db3b3  pop rax
000079a3731db3b4  add rsp, 0x08
000079a3731db3b8  jmp 0x000079A3731D662F
000079a3731db3bd  sub rsp, 0x08
000079a3731db3c1  push rax
000079a3731db3c2  push rcx
000079a3731db3c3  push rdx
000079a3731db3c4  push rdi
000079a3731db3c5  push rsi
000079a3731db3c6  push r8
000079a3731db3c8  push r9
000079a3731db3ca  push r10
000079a3731db3cc  push r11
000079a3731db3ce  sub rsp, 0xF0
000079a3731db3d5  vmovaps [rsp], xmm0
000079a3731db3da  vmovaps [rsp+0x10], xmm1
000079a3731db3e0  vmovaps [rsp+0x20], xmm2
000079a3731db3e6  vmovaps [rsp+0x30], xmm3
000079a3731db3ec  vmovaps [rsp+0x40], xmm4
000079a3731db3f2  vmovaps [rsp+0x50], xmm5
000079a3731db3f8  vmovaps [rsp+0x60], xmm6
000079a3731db3fe  vmovaps [rsp+0x70], xmm7
000079a3731db404  vmovaps [rsp+0x80], xmm8
000079a3731db40d  vmovaps [rsp+0x90], xmm9
000079a3731db416  vmovaps [rsp+0xA0], xmm10
000079a3731db41f  vmovaps [rsp+0xB0], xmm11
000079a3731db428  vmovaps [rsp+0xC0], xmm12
000079a3731db431  vmovaps [rsp+0xD0], xmm13
000079a3731db43a  vmovaps [rsp+0xE0], xmm14
000079a3731db443  sub rsp, 0x30
000079a3731db447  movaps [rsp], xmm15
000079a3731db44c  movaps [rsp+0x10], xmm11
000079a3731db452  movaps [rsp+0x20], xmm12
000079a3731db458  lea rdi, [rsp]
000079a3731db45c  mov esi, 0x00
000079a3731db461  mov rax, 0x64F127B95530
000079a3731db46b  call rax
000079a3731db46d  movaps xmm15, [rsp]
000079a3731db472  add rsp, 0x30
000079a3731db476  vmovaps xmm0, [rsp]
000079a3731db47b  vmovaps xmm1, [rsp+0x10]
000079a3731db481  vmovaps xmm2, [rsp+0x20]
000079a3731db487  vmovaps xmm3, [rsp+0x30]
000079a3731db48d  vmovaps xmm4, [rsp+0x40]
000079a3731db493  vmovaps xmm5, [rsp+0x50]
000079a3731db499  vmovaps xmm6, [rsp+0x60]
000079a3731db49f  vmovaps xmm7, [rsp+0x70]
000079a3731db4a5  vmovaps xmm8, [rsp+0x80]
000079a3731db4ae  vmovaps xmm9, [rsp+0x90]
000079a3731db4b7  vmovaps xmm10, [rsp+0xA0]
000079a3731db4c0  vmovaps xmm11, [rsp+0xB0]
000079a3731db4c9  vmovaps xmm12, [rsp+0xC0]
000079a3731db4d2  vmovaps xmm13, [rsp+0xD0]
000079a3731db4db  vmovaps xmm14, [rsp+0xE0]
000079a3731db4e4  add rsp, 0xF0
000079a3731db4eb  pop r11
000079a3731db4ed  pop r10
000079a3731db4ef  pop r9
000079a3731db4f1  pop r8
000079a3731db4f3  pop rsi
000079a3731db4f4  pop rdi
000079a3731db4f5  pop rdx
000079a3731db4f6  pop rcx
000079a3731db4f7  pop rax
000079a3731db4f8  add rsp, 0x08
000079a3731db4fc  jmp 0x000079A3731D664A
000079a3731db501  sub rsp, 0x08
000079a3731db505  push rax
000079a3731db506  push rcx
000079a3731db507  push rdx
000079a3731db508  push rdi
000079a3731db509  push rsi
000079a3731db50a  push r8
000079a3731db50c  push r9
000079a3731db50e  push r10
000079a3731db510  push r11
000079a3731db512  sub rsp, 0xF0
000079a3731db519  vmovaps [rsp], xmm0
000079a3731db51e  vmovaps [rsp+0x10], xmm1
000079a3731db524  vmovaps [rsp+0x20], xmm2
000079a3731db52a  vmovaps [rsp+0x30], xmm3
000079a3731db530  vmovaps [rsp+0x40], xmm4
000079a3731db536  vmovaps [rsp+0x50], xmm5
000079a3731db53c  vmovaps [rsp+0x60], xmm6
000079a3731db542  vmovaps [rsp+0x70], xmm7
000079a3731db548  vmovaps [rsp+0x80], xmm8
000079a3731db551  vmovaps [rsp+0x90], xmm9
000079a3731db55a  vmovaps [rsp+0xA0], xmm10
000079a3731db563  vmovaps [rsp+0xB0], xmm11
000079a3731db56c  vmovaps [rsp+0xC0], xmm12
000079a3731db575  vmovaps [rsp+0xD0], xmm14
000079a3731db57e  vmovaps [rsp+0xE0], xmm15
000079a3731db587  sub rsp, 0x30
000079a3731db58b  movaps [rsp], xmm13
000079a3731db590  movaps [rsp+0x10], xmm10
000079a3731db596  movaps [rsp+0x20], xmm14
000079a3731db59c  lea rdi, [rsp]
000079a3731db5a0  mov esi, 0x00
000079a3731db5a5  mov rax, 0x64F127B95530
000079a3731db5af  call rax
000079a3731db5b1  movaps xmm13, [rsp]
000079a3731db5b6  add rsp, 0x30
000079a3731db5ba  vmovaps xmm0, [rsp]
000079a3731db5bf  vmovaps xmm1, [rsp+0x10]
000079a3731db5c5  vmovaps xmm2, [rsp+0x20]
000079a3731db5cb  vmovaps xmm3, [rsp+0x30]
000079a3731db5d1  vmovaps xmm4, [rsp+0x40]
000079a3731db5d7  vmovaps xmm5, [rsp+0x50]
000079a3731db5dd  vmovaps xmm6, [rsp+0x60]
000079a3731db5e3  vmovaps xmm7, [rsp+0x70]
000079a3731db5e9  vmovaps xmm8, [rsp+0x80]
000079a3731db5f2  vmovaps xmm9, [rsp+0x90]
000079a3731db5fb  vmovaps xmm10, [rsp+0xA0]
000079a3731db604  vmovaps xmm11, [rsp+0xB0]
000079a3731db60d  vmovaps xmm12, [rsp+0xC0]
000079a3731db616  vmovaps xmm14, [rsp+0xD0]
000079a3731db61f  vmovaps xmm15, [rsp+0xE0]
000079a3731db628  add rsp, 0xF0
000079a3731db62f  pop r11
000079a3731db631  pop r10
000079a3731db633  pop r9
000079a3731db635  pop r8
000079a3731db637  pop rsi
000079a3731db638  pop rdi
000079a3731db639  pop rdx
000079a3731db63a  pop rcx
000079a3731db63b  pop rax
000079a3731db63c  add rsp, 0x08
000079a3731db640  jmp 0x000079A3731D666D
000079a3731db645  sub rsp, 0x08
000079a3731db649  push rax
000079a3731db64a  push rcx
000079a3731db64b  push rdx
000079a3731db64c  push rdi
000079a3731db64d  push rsi
000079a3731db64e  push r8
000079a3731db650  push r9
000079a3731db652  push r10
000079a3731db654  push r11
000079a3731db656  sub rsp, 0xF0
000079a3731db65d  vmovaps [rsp], xmm0
000079a3731db662  vmovaps [rsp+0x10], xmm1
000079a3731db668  vmovaps [rsp+0x20], xmm2
000079a3731db66e  vmovaps [rsp+0x30], xmm3
000079a3731db674  vmovaps [rsp+0x40], xmm4
000079a3731db67a  vmovaps [rsp+0x50], xmm5
000079a3731db680  vmovaps [rsp+0x60], xmm6
000079a3731db686  vmovaps [rsp+0x70], xmm7
000079a3731db68c  vmovaps [rsp+0x80], xmm8
000079a3731db695  vmovaps [rsp+0x90], xmm9
000079a3731db69e  vmovaps [rsp+0xA0], xmm10
000079a3731db6a7  vmovaps [rsp+0xB0], xmm11
000079a3731db6b0  vmovaps [rsp+0xC0], xmm12
000079a3731db6b9  vmovaps [rsp+0xD0], xmm13
000079a3731db6c2  vmovaps [rsp+0xE0], xmm15
000079a3731db6cb  sub rsp, 0x30
000079a3731db6cf  movaps [rsp], xmm14
000079a3731db6d4  movaps [rsp+0x10], xmm1
000079a3731db6d9  movaps [rsp+0x20], xmm7
000079a3731db6de  lea rdi, [rsp]
000079a3731db6e2  mov esi, 0x00
000079a3731db6e7  mov rax, 0x64F127B95530
000079a3731db6f1  call rax
000079a3731db6f3  movaps xmm14, [rsp]
000079a3731db6f8  add rsp, 0x30
000079a3731db6fc  vmovaps xmm0, [rsp]
000079a3731db701  vmovaps xmm1, [rsp+0x10]
000079a3731db707  vmovaps xmm2, [rsp+0x20]
000079a3731db70d  vmovaps xmm3, [rsp+0x30]
000079a3731db713  vmovaps xmm4, [rsp+0x40]
000079a3731db719  vmovaps xmm5, [rsp+0x50]
000079a3731db71f  vmovaps xmm6, [rsp+0x60]
000079a3731db725  vmovaps xmm7, [rsp+0x70]
000079a3731db72b  vmovaps xmm8, [rsp+0x80]
000079a3731db734  vmovaps xmm9, [rsp+0x90]
000079a3731db73d  vmovaps xmm10, [rsp+0xA0]
000079a3731db746  vmovaps xmm11, [rsp+0xB0]
000079a3731db74f  vmovaps xmm12, [rsp+0xC0]
000079a3731db758  vmovaps xmm13, [rsp+0xD0]
000079a3731db761  vmovaps xmm15, [rsp+0xE0]
000079a3731db76a  add rsp, 0xF0
000079a3731db771  pop r11
000079a3731db773  pop r10
000079a3731db775  pop r9
000079a3731db777  pop r8
000079a3731db779  pop rsi
000079a3731db77a  pop rdi
000079a3731db77b  pop rdx
000079a3731db77c  pop rcx
000079a3731db77d  pop rax
000079a3731db77e  add rsp, 0x08
000079a3731db782  jmp 0x000079A3731D6690
000079a3731db787  sub rsp, 0x08
000079a3731db78b  push rax
000079a3731db78c  push rcx
000079a3731db78d  push rdx
000079a3731db78e  push rdi
000079a3731db78f  push rsi
000079a3731db790  push r8
000079a3731db792  push r9
000079a3731db794  push r10
000079a3731db796  push r11
000079a3731db798  sub rsp, 0xF0
000079a3731db79f  vmovaps [rsp], xmm0
000079a3731db7a4  vmovaps [rsp+0x10], xmm2
000079a3731db7aa  vmovaps [rsp+0x20], xmm3
000079a3731db7b0  vmovaps [rsp+0x30], xmm4
000079a3731db7b6  vmovaps [rsp+0x40], xmm5
000079a3731db7bc  vmovaps [rsp+0x50], xmm6
000079a3731db7c2  vmovaps [rsp+0x60], xmm7
000079a3731db7c8  vmovaps [rsp+0x70], xmm8
000079a3731db7ce  vmovaps [rsp+0x80], xmm9
000079a3731db7d7  vmovaps [rsp+0x90], xmm10
000079a3731db7e0  vmovaps [rsp+0xA0], xmm11
000079a3731db7e9  vmovaps [rsp+0xB0], xmm12
000079a3731db7f2  vmovaps [rsp+0xC0], xmm13
000079a3731db7fb  vmovaps [rsp+0xD0], xmm14
000079a3731db804  vmovaps [rsp+0xE0], xmm15
000079a3731db80d  sub rsp, 0x30
000079a3731db811  movaps [rsp], xmm1
000079a3731db815  movaps [rsp+0x10], xmm8
000079a3731db81b  movaps [rsp+0x20], xmm9
000079a3731db821  lea rdi, [rsp]
000079a3731db825  mov esi, 0x00
000079a3731db82a  mov rax, 0x64F127B95530
000079a3731db834  call rax
000079a3731db836  movaps xmm1, [rsp]
000079a3731db83a  add rsp, 0x30
000079a3731db83e  vmovaps xmm0, [rsp]
000079a3731db843  vmovaps xmm2, [rsp+0x10]
000079a3731db849  vmovaps xmm3, [rsp+0x20]
000079a3731db84f  vmovaps xmm4, [rsp+0x30]
000079a3731db855  vmovaps xmm5, [rsp+0x40]
000079a3731db85b  vmovaps xmm6, [rsp+0x50]
000079a3731db861  vmovaps xmm7, [rsp+0x60]
000079a3731db867  vmovaps xmm8, [rsp+0x70]
000079a3731db86d  vmovaps xmm9, [rsp+0x80]
000079a3731db876  vmovaps xmm10, [rsp+0x90]
000079a3731db87f  vmovaps xmm11, [rsp+0xA0]
000079a3731db888  vmovaps xmm12, [rsp+0xB0]
000079a3731db891  vmovaps xmm13, [rsp+0xC0]
000079a3731db89a  vmovaps xmm14, [rsp+0xD0]
000079a3731db8a3  vmovaps xmm15, [rsp+0xE0]
000079a3731db8ac  add rsp, 0xF0
000079a3731db8b3  pop r11
000079a3731db8b5  pop r10
000079a3731db8b7  pop r9
000079a3731db8b9  pop r8
000079a3731db8bb  pop rsi
000079a3731db8bc  pop rdi
000079a3731db8bd  pop rdx
000079a3731db8be  pop rcx
000079a3731db8bf  pop rax
000079a3731db8c0  add rsp, 0x08
000079a3731db8c4  jmp 0x000079A3731D66B2
000079a3731db8c9  call 0x000079A3730B3E40
000079a3731db8ce  jmp 0x000079A3731D66C0
000079a3731db8d3  call 0x000079A37300C380
000079a3731db8d8  jmp 0x000079A3731D66CA
000079a3731db8dd  call 0x000079A37300D600
000079a3731db8e2  jmp 0x000079A3731D66D4
000079a3731db8e7  call 0x000079A372FFF540
000079a3731db8ec  jmp 0x000079A3731D66DE
000079a3731db8f1  int3
000079a3731db8f2  nop [rax+rax*1], ax
000079a3731db8fb  nop [rax+rax*1], eax
000079a3731db900  mov eax, [r15+0x48]
000079a3731db904  lea r14d, [eax+0x01]
000079a3731db909  mov [rsp+0x10], r14d
000079a3731db90e  mov r14d, r14d
000079a3731db911  mov [r15+0x48], r14
000079a3731db915  xor eax, eax
000079a3731db917  mov r14d, [rsp+0x10]
000079a3731db91c  cmp r14d, 0x1F4
000079a3731db923  cmc
000079a3731db924  lahf
000079a3731db925  seto al
000079a3731db928  mov [r15+0x108], eax
000079a3731db92f  mov eax, [r15+0x108]
000079a3731db936  sahf
000079a3731db937  jnz 0x000079A3731DB969
000079a3731db939  cmp dword ptr [r15+0x318], 0x00
000079a3731db941  jz 0x000079A3731E1AB0
000079a3731db947  nop [rax+rax*1], ax
000079a3731db950  nop [rax+rax*1], eax
000079a3731db958  mov eax, 0x410450
000079a3731db95d  mov [r15+0x100], rax
000079a3731db964  jmp 0x000079A372FFE110
000079a3731db969  cmp dword ptr [r15+0x318], 0x00
000079a3731db971  jz 0x000079A3731DB9A0
000079a3731db977  nop [rax+rax*1], ax
000079a3731db980  nop [rax+rax*1], eax
000079a3731db988  mov eax, 0x410274
000079a3731db98d  mov [r15+0x100], rax
000079a3731db994  jmp 0x000079A372FFE110
000079a3731db999  int3
000079a3731db99a  int3
000079a3731db99b  nop [rax+rax*1], eax
000079a3731db9a0  mov rax, [r15+0x40]
000079a3731db9a4  movaps xmm1, [r15+0x1D0]
000079a3731db9ac  vmovaps [rsp+0x10], xmm1
000079a3731db9b2  vmovaps xmm15, [rsp+0x10]
000079a3731db9b8  por xmm1, xmm15
000079a3731db9bd  movaps xmm14, [r15+0x1A0]
000079a3731db9c5  vmovaps [rsp+0x10], xmm14
000079a3731db9cb  vmovaps xmm13, [rsp+0x10]
000079a3731db9d1  por xmm14, xmm13
000079a3731db9d6  lea r14, [rax+0x30]
000079a3731db9da  mov r12, [r13+r14*1]
000079a3731db9df  lea r14, [rax+0x38]
000079a3731db9e3  mov r11, [r13+r14*1]
000079a3731db9e8  movq xmm13, r12
000079a3731db9ed  movq xmm12, r11
000079a3731db9f2  movq xmm13, xmm13
000079a3731db9f7  vmovaps [rsp+0x10], xmm13
000079a3731db9fd  movq xmm13, xmm13
000079a3731dba02  movaps [r15+0x130], xmm13
000079a3731dba0a  movq xmm12, xmm12
000079a3731dba0f  vmovaps [rsp+0x20], xmm12
000079a3731dba15  movq xmm12, xmm12
000079a3731dba1a  movaps [r15+0x280], xmm12
000079a3731dba22  movaps xmm13, [r15+0x270]
000079a3731dba2a  vmovaps [rsp+0x30], xmm13
000079a3731dba30  vmovaps xmm12, [rsp+0x30]
000079a3731dba36  por xmm13, xmm12
000079a3731dba3b  lea r14, [rax+0x20]
000079a3731dba3f  mov r12, [r13+r14*1]
000079a3731dba44  lea r14, [rax+0x28]
000079a3731dba48  mov r11, [r13+r14*1]
000079a3731dba4d  movq xmm12, r12
000079a3731dba52  movq xmm11, r11
000079a3731dba57  movq xmm12, xmm12
000079a3731dba5c  vmovaps [rsp+0x30], xmm12
000079a3731dba62  movq xmm12, xmm12
000079a3731dba67  movaps [r15+0x150], xmm12
000079a3731dba6f  movq xmm11, xmm11
000079a3731dba74  vmovaps [rsp+0x40], xmm11
000079a3731dba7a  movq xmm11, xmm11
000079a3731dba7f  movaps [r15+0x140], xmm11
000079a3731dba87  lea r14, [rax+0x10]
000079a3731dba8b  mov r12, [r13+r14*1]
000079a3731dba90  lea r14, [rax+0x18]
000079a3731dba94  mov r11, [r13+r14*1]
000079a3731dba99  movq xmm12, r12
000079a3731dba9e  movq xmm11, r11
000079a3731dbaa3  movq xmm12, xmm12
000079a3731dbaa8  vmovaps [rsp+0x50], xmm12
000079a3731dbaae  movq xmm12, xmm12
000079a3731dbab3  movaps [r15+0x170], xmm12
000079a3731dbabb  movq xmm11, xmm11
000079a3731dbac0  vmovaps [rsp+0x60], xmm11
000079a3731dbac6  movq xmm11, xmm11
000079a3731dbacb  movaps [r15+0x160], xmm11
000079a3731dbad3  mov r14, [r13+rax*1]
000079a3731dbad8  vmovq xmm12, r14
000079a3731dbadd  vpbroadcastq xmm12, xmm12
000079a3731dbae2  lea r14, [rax+0x08]
000079a3731dbae6  mov rax, [r13+r14*1]
000079a3731dbaeb  movq xmm11, rax
000079a3731dbaf0  movaps [r15+0x230], xmm11
000079a3731dbaf8  mov rax, [r15+0xF8]
000079a3731dbaff  lea r14, [rax+0x50]
000079a3731dbb03  movups xmm11, [r13+r14*1]
000079a3731dbb09  lea r14, [rax+0x60]
000079a3731dbb0d  movups xmm10, [r13+r14*1]
000079a3731dbb13  lea r14, [rax+0x30]
000079a3731dbb17  movups xmm9, [r13+r14*1]
000079a3731dbb1d  mov r14, [r15+0x50]
000079a3731dbb21  mov [r15+0x60], r14
000079a3731dbb25  mov qword ptr [r15+0x58], 0x40
000079a3731dbb2d  movaps xmm8, xmm12
000079a3731dbb31  mulpd xmm8, xmm15
000079a3731dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000079a3731dbb3c  ptest xmm7, xmm7
000079a3731dbb41  jnz 0x000079A3731DC96A
000079a3731dbb47  movq xmm15, qword ptr [r15+0x230]
000079a3731dbb50  vmovaps [rsp+0x70], xmm15
000079a3731dbb56  vpermilpd xmm15, xmm15, 0x00
000079a3731dbb5c  movaps xmm7, xmm9
000079a3731dbb60  mulpd xmm7, xmm15
000079a3731dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000079a3731dbb6a  ptest xmm6, xmm6
000079a3731dbb6f  jnz 0x000079A3731DCAAE
000079a3731dbb75  vxorps xmm15, xmm15, xmm15
000079a3731dbb7a  vpbroadcastq xmm15, xmm15
000079a3731dbb7f  movaps xmm9, xmm12
000079a3731dbb83  mulpd xmm9, xmm10
000079a3731dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000079a3731dbb8e  ptest xmm6, xmm6
000079a3731dbb93  jnz 0x000079A3731DCBF0
000079a3731dbb99  movaps xmm10, xmm12
000079a3731dbb9d  mulpd xmm10, xmm11
000079a3731dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000079a3731dbba8  ptest xmm6, xmm6
000079a3731dbbad  jnz 0x000079A3731DCD34
000079a3731dbbb3  movaps xmm11, [r15+0x1F0]
000079a3731dbbbb  movaps xmm6, xmm12
000079a3731dbbbf  mulpd xmm6, xmm11
000079a3731dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000079a3731dbbc9  ptest xmm5, xmm5
000079a3731dbbce  jnz 0x000079A3731DCE78
000079a3731dbbd4  movaps xmm12, [r15+0x2A0]
000079a3731dbbdc  vmovaps [rsp+0x80], xmm12
000079a3731dbbe5  vmovaps xmm11, [rsp+0x80]
000079a3731dbbee  por xmm12, xmm11
000079a3731dbbf3  movaps xmm11, [r15+0x250]
000079a3731dbbfb  vmovaps [rsp+0x80], xmm11
000079a3731dbc04  vmovaps xmm5, [rsp+0x80]
000079a3731dbc0d  por xmm11, xmm5
000079a3731dbc12  vmovaps xmm4, [rsp+0x70]
000079a3731dbc18  vpermilpd xmm4, xmm4, 0x00
000079a3731dbc1e  movaps xmm3, xmm5
000079a3731dbc21  mulpd xmm3, xmm4
000079a3731dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000079a3731dbc2a  ptest xmm2, xmm2
000079a3731dbc2f  jnz 0x000079A3731DCFBA
000079a3731dbc35  mov [rsp+0x80], rax
000079a3731dbc3d  xor eax, eax
000079a3731dbc3f  mov r12d, 0x40
000079a3731dbc45  mov r11d, 0x200
000079a3731dbc4b  cmp r12, r11
000079a3731dbc4e  cmc
000079a3731dbc4f  lahf
000079a3731dbc50  seto al
000079a3731dbc53  mov [r15+0x108], eax
000079a3731dbc5a  movaps xmm5, xmm8
000079a3731dbc5e  addpd xmm5, xmm15
000079a3731dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000079a3731dbc68  ptest xmm4, xmm4
000079a3731dbc6d  jnz 0x000079A3731DD0FA
000079a3731dbc73  movaps xmm8, [r15+0x1B0]
000079a3731dbc7b  movaps xmm4, xmm9
000079a3731dbc7f  addpd xmm4, xmm8
000079a3731dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000079a3731dbc89  ptest xmm2, xmm2
000079a3731dbc8e  jnz 0x000079A3731DD23C
000079a3731dbc94  movaps xmm9, xmm10
000079a3731dbc98  addpd xmm9, xmm8
000079a3731dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000079a3731dbca3  ptest xmm2, xmm2
000079a3731dbca8  jnz 0x000079A3731DD37E
000079a3731dbcae  movaps xmm10, [r15+0x2F0]
000079a3731dbcb6  vmovaps [rsp+0x90], xmm10
000079a3731dbcbf  vmovaps xmm8, [rsp+0x90]
000079a3731dbcc8  por xmm10, xmm8
000079a3731dbccd  movaps xmm8, [r15+0x2E0]
000079a3731dbcd5  vmovaps [rsp+0x90], xmm8
000079a3731dbcde  vmovaps xmm2, [rsp+0x90]
000079a3731dbce7  por xmm8, xmm2
000079a3731dbcec  movaps xmm2, [r15+0x2D0]
000079a3731dbcf4  vmovaps [rsp+0x90], xmm2
000079a3731dbcfd  vmovaps [rsp+0xA0], xmm1
000079a3731dbd06  vmovaps xmm1, [rsp+0x90]
000079a3731dbd0f  por xmm2, xmm1
000079a3731dbd13  movaps xmm1, [r15+0x200]
000079a3731dbd1b  vmovaps [rsp+0x90], xmm1
000079a3731dbd24  vmovaps [rsp+0xB0], xmm15
000079a3731dbd2d  vmovaps xmm15, [rsp+0x90]
000079a3731dbd36  por xmm1, xmm15
000079a3731dbd3b  movaps xmm15, [r15+0x1C0]
000079a3731dbd43  vmovaps [rsp+0x90], xmm15
000079a3731dbd4c  vmovaps [rsp+0xC0], xmm1
000079a3731dbd55  vmovaps xmm1, [rsp+0x90]
000079a3731dbd5e  por xmm15, xmm1
000079a3731dbd63  movaps xmm1, [r15+0x190]
000079a3731dbd6b  vmovaps [rsp+0x90], xmm1
000079a3731dbd74  vmovaps [rsp+0xD0], xmm15
000079a3731dbd7d  vmovaps xmm15, [rsp+0x90]
000079a3731dbd86  por xmm1, xmm15
000079a3731dbd8b  movaps xmm15, [r15+0x300]
000079a3731dbd93  vmovaps [rsp+0x90], xmm15
000079a3731dbd9c  vmovaps [rsp+0xE0], xmm1
000079a3731dbda5  vmovaps xmm1, [rsp+0x90]
000079a3731dbdae  por xmm15, xmm1
000079a3731dbdb3  mov rax, [rsp+0x80]
000079a3731dbdbb  lea r12, [rax+0xA0]
000079a3731dbdc2  movups xmm1, [r13+r12*1]
000079a3731dbdc8  lea r12, [rax+0xB0]
000079a3731dbdcf  vmovaps [rsp+0x80], xmm1
000079a3731dbdd8  movups xmm1, [r13+r12*1]
000079a3731dbdde  vmovaps [rsp+0x90], xmm1
000079a3731dbde7  vmovaps [rsp+0xF0], xmm15
000079a3731dbdf0  vmovaps xmm15, [rsp+0xB0]
000079a3731dbdf9  vmovaps [rsp+0xB0], xmm14
000079a3731dbe02  movaps xmm1, xmm6
000079a3731dbe05  addpd xmm1, xmm15
000079a3731dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000079a3731dbe0f  ptest xmm14, xmm14
000079a3731dbe15  jnz 0x000079A3731DD4D6
000079a3731dbe1b  lea r12, [rax+0xF0]
000079a3731dbe22  movups xmm15, [r13+r12*1]
000079a3731dbe28  movaps xmm14, xmm4
000079a3731dbe2c  addpd xmm14, xmm3
000079a3731dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000079a3731dbe37  ptest xmm6, xmm6
000079a3731dbe3c  jnz 0x000079A3731DD621
000079a3731dbe42  movaps xmm6, xmm9
000079a3731dbe46  addpd xmm6, xmm7
000079a3731dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000079a3731dbe4f  ptest xmm4, xmm4
000079a3731dbe54  jnz 0x000079A3731DD763
000079a3731dbe5a  vmovaps xmm9, [rsp+0x70]
000079a3731dbe60  vpermilpd xmm9, xmm9, 0x00
000079a3731dbe66  vmovaps xmm4, [rsp+0x90]
000079a3731dbe6f  movaps xmm7, xmm4
000079a3731dbe72  mulpd xmm7, xmm9
000079a3731dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000079a3731dbe7c  ptest xmm3, xmm3
000079a3731dbe81  jnz 0x000079A3731DD8A4
000079a3731dbe87  vmovaps xmm9, [rsp+0x50]
000079a3731dbe8d  vpermilpd xmm9, xmm9, 0x00
000079a3731dbe93  movaps xmm4, xmm15
000079a3731dbe97  mulpd xmm4, xmm9
000079a3731dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000079a3731dbea1  ptest xmm3, xmm3
000079a3731dbea6  jnz 0x000079A3731DD9E5
000079a3731dbeac  lea r12, [rax+0xE0]
000079a3731dbeb3  movups xmm15, [r13+r12*1]
000079a3731dbeb9  vmovaps xmm9, [rsp+0x70]
000079a3731dbebf  vpermilpd xmm9, xmm9, 0x00
000079a3731dbec5  vmovaps [rsp+0x70], xmm1
000079a3731dbecb  vmovaps xmm1, [rsp+0x80]
000079a3731dbed4  vmovaps [rsp+0x80], xmm15
000079a3731dbedd  movaps xmm3, xmm1
000079a3731dbee0  mulpd xmm3, xmm9
000079a3731dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000079a3731dbeea  ptest xmm15, xmm15
000079a3731dbef0  jnz 0x000079A3731DDB31
000079a3731dbef6  vmovaps xmm1, [rsp+0xF0]
000079a3731dbeff  vmovaps xmm15, [rsp+0xF0]
000079a3731dbf08  por xmm1, xmm15
000079a3731dbf0d  movaps [r15+0x300], xmm1
000079a3731dbf15  vmovaps xmm15, [rsp+0xE0]
000079a3731dbf1e  vmovaps xmm9, [rsp+0xE0]
000079a3731dbf27  por xmm15, xmm9
000079a3731dbf2c  movaps [r15+0x190], xmm15
000079a3731dbf34  vmovaps xmm9, [rsp+0x50]
000079a3731dbf3a  vpermilpd xmm9, xmm9, 0x00
000079a3731dbf40  vmovaps [rsp+0x90], xmm1
000079a3731dbf49  vmovaps [rsp+0xE0], xmm15
000079a3731dbf52  vmovaps xmm15, [rsp+0x80]
000079a3731dbf5b  vmovaps [rsp+0x80], xmm14
000079a3731dbf64  movaps xmm1, xmm15
000079a3731dbf68  mulpd xmm1, xmm9
000079a3731dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000079a3731dbf72  ptest xmm14, xmm14
000079a3731dbf78  jnz 0x000079A3731DDC72
000079a3731dbf7e  lea r12, [rax+0x90]
000079a3731dbf85  movups xmm15, [r13+r12*1]
000079a3731dbf8b  vmovaps xmm14, [rsp+0xD0]
000079a3731dbf94  vmovaps xmm9, [rsp+0xD0]
000079a3731dbf9d  por xmm14, xmm9
000079a3731dbfa2  movaps [r15+0x1C0], xmm14
000079a3731dbfaa  vmovaps xmm9, [rsp+0xC0]
000079a3731dbfb3  vmovaps [rsp+0xD0], xmm1
000079a3731dbfbc  vmovaps xmm1, [rsp+0xC0]
000079a3731dbfc5  por xmm9, xmm1
000079a3731dbfca  movaps [r15+0x200], xmm9
000079a3731dbfd2  vmovaps [rsp+0xC0], xmm2
000079a3731dbfdb  vmovaps xmm1, [rsp+0xC0]
000079a3731dbfe4  por xmm2, xmm1
000079a3731dbfe8  movaps [r15+0x2D0], xmm2
000079a3731dbff0  vmovaps [rsp+0xC0], xmm8
000079a3731dbff9  vmovaps xmm1, [rsp+0xC0]
000079a3731dc002  por xmm8, xmm1
000079a3731dc007  movaps [r15+0x2E0], xmm8
000079a3731dc00f  vmovaps [rsp+0xC0], xmm15
000079a3731dc018  movaps xmm1, xmm5
000079a3731dc01b  addpd xmm1, xmm7
000079a3731dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000079a3731dc024  ptest xmm15, xmm15
000079a3731dc02a  jnz 0x000079A3731DDDBE
000079a3731dc030  vmovaps xmm15, [rsp+0x50]
000079a3731dc036  vpermilpd xmm15, xmm15, 0x00
000079a3731dc03c  vmovaps xmm5, [rsp+0xC0]
000079a3731dc045  vmovaps [rsp+0xC0], xmm1
000079a3731dc04e  movaps xmm7, xmm5
000079a3731dc051  mulpd xmm7, xmm15
000079a3731dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000079a3731dc05b  ptest xmm1, xmm1
000079a3731dc060  jnz 0x000079A3731DDEFE
000079a3731dc066  lea r12, [rax+0x80]
000079a3731dc06d  movups xmm1, [r13+r12*1]
000079a3731dc073  vmovaps xmm5, [rsp+0x70]
000079a3731dc079  vmovaps [rsp+0x70], xmm1
000079a3731dc07f  movaps xmm15, xmm5
000079a3731dc083  addpd xmm15, xmm3
000079a3731dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000079a3731dc08e  ptest xmm1, xmm1
000079a3731dc093  jnz 0x000079A3731DE049
000079a3731dc099  vmovaps xmm5, [rsp+0x80]
000079a3731dc0a2  movaps xmm1, xmm5
000079a3731dc0a5  addpd xmm1, xmm4
000079a3731dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000079a3731dc0ae  ptest xmm3, xmm3
000079a3731dc0b3  jnz 0x000079A3731DE18B
000079a3731dc0b9  vmovaps [rsp+0x80], xmm10
000079a3731dc0c2  vmovaps xmm5, [rsp+0x80]
000079a3731dc0cb  por xmm10, xmm5
000079a3731dc0d0  movaps [r15+0x2F0], xmm10
000079a3731dc0d8  vmovaps xmm5, [rsp+0x50]
000079a3731dc0de  vpermilpd xmm5, xmm5, 0x00
000079a3731dc0e4  vmovaps xmm3, [rsp+0x70]
000079a3731dc0ea  vmovaps [rsp+0x50], xmm1
000079a3731dc0f0  movaps xmm4, xmm3
000079a3731dc0f3  mulpd xmm4, xmm5
000079a3731dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000079a3731dc0fc  ptest xmm1, xmm1
000079a3731dc101  jnz 0x000079A3731DE2CB
000079a3731dc107  lea r12, [rax+0xD0]
000079a3731dc10e  movups xmm1, [r13+r12*1]
000079a3731dc114  vmovaps xmm3, [rsp+0xD0]
000079a3731dc11d  vmovaps [rsp+0x70], xmm1
000079a3731dc123  movaps xmm5, xmm6
000079a3731dc126  addpd xmm5, xmm3
000079a3731dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000079a3731dc12f  ptest xmm1, xmm1
000079a3731dc134  jnz 0x000079A3731DE415
000079a3731dc13a  vmovaps xmm1, [rsp+0x60]
000079a3731dc140  vpermilpd xmm1, xmm1, 0x00
000079a3731dc146  movaps xmm6, xmm9
000079a3731dc14a  mulpd xmm6, xmm1
000079a3731dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000079a3731dc153  ptest xmm3, xmm3
000079a3731dc158  jnz 0x000079A3731DE555
000079a3731dc15e  movaps [r15+0x260], xmm6
000079a3731dc166  vxorps xmm1, xmm1, xmm1
000079a3731dc16a  vpbroadcastq xmm1, xmm1
000079a3731dc16f  movaps [r15+0x1B0], xmm1
000079a3731dc177  vmovaps xmm1, [rsp+0x60]
000079a3731dc17d  vpermilpd xmm1, xmm1, 0x00
000079a3731dc183  vmovaps xmm3, [rsp+0x70]
000079a3731dc189  vmovaps [rsp+0x70], xmm15
000079a3731dc18f  movaps xmm9, xmm3
000079a3731dc193  mulpd xmm9, xmm1
000079a3731dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000079a3731dc19e  ptest xmm15, xmm15
000079a3731dc1a4  jnz 0x000079A3731DE696
000079a3731dc1aa  lea r12, [rax+0xC0]
000079a3731dc1b1  movups xmm1, [r13+r12*1]
000079a3731dc1b7  vmovaps xmm3, [rsp+0xC0]
000079a3731dc1c0  vmovaps [rsp+0x80], xmm1
000079a3731dc1c9  movaps xmm15, xmm3
000079a3731dc1cd  addpd xmm15, xmm7
000079a3731dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000079a3731dc1d8  ptest xmm1, xmm1
000079a3731dc1dd  jnz 0x000079A3731DE7E2
000079a3731dc1e3  vmovaps [rsp+0xC0], xmm13
000079a3731dc1ec  vmovaps xmm1, [rsp+0xC0]
000079a3731dc1f5  por xmm13, xmm1
000079a3731dc1fa  movaps [r15+0x270], xmm13
000079a3731dc202  vmovaps xmm1, [rsp+0xB0]
000079a3731dc20b  vmovaps xmm7, [rsp+0xB0]
000079a3731dc214  por xmm1, xmm7
000079a3731dc218  movaps [r15+0x1A0], xmm1
000079a3731dc220  vmovaps xmm1, [rsp+0x60]
000079a3731dc226  vpermilpd xmm1, xmm1, 0x00
000079a3731dc22c  vmovaps [rsp+0xB0], xmm1
000079a3731dc235  vmovaps xmm1, [rsp+0x80]
000079a3731dc23e  vmovaps [rsp+0x80], xmm15
000079a3731dc247  vmovaps xmm15, [rsp+0xB0]
000079a3731dc250  vmovaps [rsp+0xB0], xmm14
000079a3731dc259  movaps xmm3, xmm1
000079a3731dc25c  mulpd xmm3, xmm15
000079a3731dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000079a3731dc266  ptest xmm14, xmm14
000079a3731dc26c  jnz 0x000079A3731DE924
000079a3731dc272  lea r12, [rax+0x20]
000079a3731dc276  movups xmm1, [r13+r12*1]
000079a3731dc27c  movaps [r15+0x110], xmm1
000079a3731dc284  vmovaps xmm14, [rsp+0x70]
000079a3731dc28a  vmovaps [rsp+0x70], xmm1
000079a3731dc290  movaps xmm15, xmm14
000079a3731dc294  addpd xmm15, xmm4
000079a3731dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000079a3731dc29f  ptest xmm1, xmm1
000079a3731dc2a4  jnz 0x000079A3731DEA6F
000079a3731dc2aa  vmovaps xmm1, [rsp+0x60]
000079a3731dc2b0  vpermilpd xmm1, xmm1, 0x00
000079a3731dc2b6  movaps xmm14, xmm2
000079a3731dc2ba  mulpd xmm14, xmm1
000079a3731dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000079a3731dc2c5  ptest xmm4, xmm4
000079a3731dc2ca  jnz 0x000079A3731DEBB2
000079a3731dc2d0  vmovaps xmm4, [rsp+0x50]
000079a3731dc2d6  movaps xmm1, xmm4
000079a3731dc2d9  addpd xmm1, xmm9
000079a3731dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000079a3731dc2e3  ptest xmm2, xmm2
000079a3731dc2e8  jnz 0x000079A3731DECF4
000079a3731dc2ee  vmovaps xmm9, [rsp+0x30]
000079a3731dc2f4  vpermilpd xmm9, xmm9, 0x00
000079a3731dc2fa  vmovaps xmm2, [rsp+0x70]
000079a3731dc300  vmovaps [rsp+0x50], xmm1
000079a3731dc306  movaps xmm4, xmm2
000079a3731dc309  mulpd xmm4, xmm9
000079a3731dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000079a3731dc313  ptest xmm1, xmm1
000079a3731dc318  jnz 0x000079A3731DEE35
000079a3731dc31e  vmovaps xmm1, [rsp+0x30]
000079a3731dc324  vpermilpd xmm1, xmm1, 0x00
000079a3731dc32a  vmovaps xmm2, [rsp+0x90]
000079a3731dc333  vmovaps [rsp+0x60], xmm15
000079a3731dc339  movaps xmm9, xmm2
000079a3731dc33d  mulpd xmm9, xmm1
000079a3731dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000079a3731dc348  ptest xmm15, xmm15
000079a3731dc34e  jnz 0x000079A3731DEF76
000079a3731dc354  vmovaps xmm15, [rsp+0x80]
000079a3731dc35d  movaps xmm1, xmm15
000079a3731dc361  addpd xmm1, xmm6
000079a3731dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000079a3731dc36a  ptest xmm2, xmm2
000079a3731dc36f  jnz 0x000079A3731DF0B8
000079a3731dc375  movaps xmm15, xmm5
000079a3731dc379  addpd xmm15, xmm3
000079a3731dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000079a3731dc384  ptest xmm6, xmm6
000079a3731dc389  jnz 0x000079A3731DF1F9
000079a3731dc38f  vmovaps xmm6, [rsp+0x30]
000079a3731dc395  vpermilpd xmm6, xmm6, 0x00
000079a3731dc39b  movaps xmm5, xmm8
000079a3731dc39f  mulpd xmm5, xmm6
000079a3731dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000079a3731dc3a8  ptest xmm3, xmm3
000079a3731dc3ad  jnz 0x000079A3731DF33B
000079a3731dc3b3  vmovaps xmm8, [rsp+0x30]
000079a3731dc3b9  vpermilpd xmm8, xmm8, 0x00
000079a3731dc3bf  movaps xmm6, xmm10
000079a3731dc3c3  mulpd xmm6, xmm8
000079a3731dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000079a3731dc3cd  ptest xmm3, xmm3
000079a3731dc3d2  jnz 0x000079A3731DF47C
000079a3731dc3d8  vmovaps xmm8, [rsp+0x60]
000079a3731dc3de  movaps xmm10, xmm8
000079a3731dc3e2  addpd xmm10, xmm14
000079a3731dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000079a3731dc3ed  ptest xmm3, xmm3
000079a3731dc3f2  jnz 0x000079A3731DF5BE
000079a3731dc3f8  vmovaps xmm8, [rsp+0x50]
000079a3731dc3fe  movaps xmm14, xmm8
000079a3731dc402  addpd xmm14, xmm4
000079a3731dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000079a3731dc40d  ptest xmm3, xmm3
000079a3731dc412  jnz 0x000079A3731DF702
000079a3731dc418  vmovaps xmm8, [rsp+0x40]
000079a3731dc41e  vpermilpd xmm8, xmm8, 0x00
000079a3731dc424  movaps xmm4, xmm13
000079a3731dc428  mulpd xmm4, xmm8
000079a3731dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000079a3731dc432  ptest xmm3, xmm3
000079a3731dc437  jnz 0x000079A3731DF845
000079a3731dc43d  movaps xmm13, xmm15
000079a3731dc441  addpd xmm13, xmm9
000079a3731dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000079a3731dc44c  ptest xmm8, xmm8
000079a3731dc452  jnz 0x000079A3731DF987
000079a3731dc458  movaps xmm15, xmm1
000079a3731dc45c  addpd xmm15, xmm5
000079a3731dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000079a3731dc467  ptest xmm9, xmm9
000079a3731dc46d  jnz 0x000079A3731DFACB
000079a3731dc473  vmovaps [rsp+0x30], xmm11
000079a3731dc479  vmovaps xmm1, [rsp+0x30]
000079a3731dc47f  por xmm11, xmm1
000079a3731dc484  movaps [r15+0x250], xmm11
000079a3731dc48c  vmovaps [rsp+0x30], xmm12
000079a3731dc492  vmovaps xmm1, [rsp+0x30]
000079a3731dc498  por xmm12, xmm1
000079a3731dc49d  movaps [r15+0x2A0], xmm12
000079a3731dc4a5  vmovaps xmm1, [rsp+0xA0]
000079a3731dc4ae  vmovaps xmm11, [rsp+0xA0]
000079a3731dc4b7  por xmm1, xmm11
000079a3731dc4bc  movaps [r15+0x1D0], xmm1
000079a3731dc4c4  lea r12, [rax+0x40]
000079a3731dc4c8  movups xmm1, [r13+r12*1]
000079a3731dc4ce  movaps [r15+0x2C0], xmm1
000079a3731dc4d6  vmovaps xmm11, [rsp+0x40]
000079a3731dc4dc  vpermilpd xmm11, xmm11, 0x00
000079a3731dc4e2  vmovaps xmm8, [rsp+0xE0]
000079a3731dc4eb  movaps xmm9, xmm8
000079a3731dc4ef  mulpd xmm9, xmm11
000079a3731dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000079a3731dc4fa  ptest xmm5, xmm5
000079a3731dc4ff  jnz 0x000079A3731DFC17
000079a3731dc505  movaps xmm11, xmm10
000079a3731dc509  addpd xmm11, xmm6
000079a3731dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000079a3731dc514  ptest xmm8, xmm8
000079a3731dc51a  jnz 0x000079A3731DFD5B
000079a3731dc520  movaps xmm10, xmm14
000079a3731dc524  addpd xmm10, xmm4
000079a3731dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000079a3731dc52f  ptest xmm8, xmm8
000079a3731dc535  jnz 0x000079A3731DFE9E
000079a3731dc53b  vmovaps xmm14, [rsp+0x40]
000079a3731dc541  vpermilpd xmm14, xmm14, 0x00
000079a3731dc547  movaps xmm8, xmm1
000079a3731dc54b  mulpd xmm8, xmm14
000079a3731dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000079a3731dc556  ptest xmm6, xmm6
000079a3731dc55b  jnz 0x000079A3731DFFE1
000079a3731dc561  movaps xmm1, [r15+0x2B0]
000079a3731dc569  vmovaps xmm14, [rsp+0x40]
000079a3731dc56f  vpermilpd xmm14, xmm14, 0x00
000079a3731dc575  movaps xmm6, xmm1
000079a3731dc578  mulpd xmm6, xmm14
000079a3731dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000079a3731dc582  ptest xmm5, xmm5
000079a3731dc587  jnz 0x000079A3731E0124
000079a3731dc58d  vmovaps xmm1, [rsp+0x10]
000079a3731dc593  vpermilpd xmm1, xmm1, 0x00
000079a3731dc599  movaps xmm14, xmm12
000079a3731dc59d  mulpd xmm14, xmm1
000079a3731dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000079a3731dc5a8  ptest xmm5, xmm5
000079a3731dc5ad  jnz 0x000079A3731E0265
000079a3731dc5b3  movaps xmm1, xmm13
000079a3731dc5b7  addpd xmm1, xmm9
000079a3731dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000079a3731dc5c1  ptest xmm12, xmm12
000079a3731dc5c7  jnz 0x000079A3731E03A8
000079a3731dc5cd  vmovaps xmm13, [rsp+0x10]
000079a3731dc5d3  vpermilpd xmm13, xmm13, 0x00
000079a3731dc5d9  movaps xmm12, xmm7
000079a3731dc5dd  mulpd xmm12, xmm13
000079a3731dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000079a3731dc5e8  ptest xmm9, xmm9
000079a3731dc5ee  jnz 0x000079A3731E04EA
000079a3731dc5f4  movaps xmm13, xmm15
000079a3731dc5f8  addpd xmm13, xmm8
000079a3731dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000079a3731dc603  ptest xmm9, xmm9
000079a3731dc609  jnz 0x000079A3731E062D
000079a3731dc60f  movaps xmm15, [r15+0x290]
000079a3731dc617  vmovaps xmm9, [rsp+0x10]
000079a3731dc61d  vpermilpd xmm9, xmm9, 0x00
000079a3731dc623  movaps xmm8, xmm15
000079a3731dc627  mulpd xmm8, xmm9
000079a3731dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000079a3731dc632  ptest xmm7, xmm7
000079a3731dc637  jnz 0x000079A3731E0771
000079a3731dc63d  movaps xmm15, xmm11
000079a3731dc641  addpd xmm15, xmm6
000079a3731dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000079a3731dc64c  ptest xmm9, xmm9
000079a3731dc652  jnz 0x000079A3731E08B5
000079a3731dc658  movaps xmm11, [r15+0x1E0]
000079a3731dc660  vmovaps xmm9, [rsp+0x10]
000079a3731dc666  vpermilpd xmm9, xmm9, 0x00
000079a3731dc66c  movaps xmm7, xmm11
000079a3731dc670  mulpd xmm7, xmm9
000079a3731dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000079a3731dc67a  ptest xmm6, xmm6
000079a3731dc67f  jnz 0x000079A3731E09F8
000079a3731dc685  movaps xmm11, xmm10
000079a3731dc689  addpd xmm11, xmm14
000079a3731dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000079a3731dc694  ptest xmm9, xmm9
000079a3731dc69a  jnz 0x000079A3731E0B3A
000079a3731dc6a0  lea r12, [rax+0x70]
000079a3731dc6a4  movups xmm14, [r13+r12*1]
000079a3731dc6aa  movaps [r15+0x240], xmm14
000079a3731dc6b2  movaps xmm10, xmm1
000079a3731dc6b6  addpd xmm10, xmm12
000079a3731dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000079a3731dc6c1  ptest xmm9, xmm9
000079a3731dc6c7  jnz 0x000079A3731E0C88
000079a3731dc6cd  movaps [r15+0x170], xmm10
000079a3731dc6d5  vmovaps xmm1, [rsp+0x20]
000079a3731dc6db  vpermilpd xmm1, xmm1, 0x00
000079a3731dc6e1  movaps xmm12, xmm14
000079a3731dc6e5  mulpd xmm12, xmm1
000079a3731dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000079a3731dc6f0  ptest xmm9, xmm9
000079a3731dc6f6  jnz 0x000079A3731E0DCB
000079a3731dc6fc  vmovaps xmm1, [rsp+0x20]
000079a3731dc702  vpermilpd xmm1, xmm1, 0x00
000079a3731dc708  vmovaps xmm9, [rsp+0xB0]
000079a3731dc711  movaps xmm14, xmm9
000079a3731dc715  mulpd xmm14, xmm1
000079a3731dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000079a3731dc720  ptest xmm6, xmm6
000079a3731dc725  jnz 0x000079A3731E0F0E
000079a3731dc72b  movaps [r15+0x180], xmm14
000079a3731dc733  movaps xmm1, xmm13
000079a3731dc737  addpd xmm1, xmm8
000079a3731dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000079a3731dc741  ptest xmm9, xmm9
000079a3731dc747  jnz 0x000079A3731E1051
000079a3731dc74d  movaps [r15+0x210], xmm1
000079a3731dc755  movups xmm13, [r13+rax*1]
000079a3731dc75b  lea r12, [rax+0x10]
000079a3731dc75f  movups xmm9, [r13+r12*1]
000079a3731dc765  movaps [r15+0x230], xmm9
000079a3731dc76d  movaps xmm8, xmm15
000079a3731dc771  addpd xmm8, xmm7
000079a3731dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000079a3731dc77c  ptest xmm6, xmm6
000079a3731dc781  jnz 0x000079A3731E11A7
000079a3731dc787  movaps [r15+0x130], xmm8
000079a3731dc78f  vmovaps xmm15, [rsp+0x20]
000079a3731dc795  vpermilpd xmm15, xmm15, 0x00
000079a3731dc79b  movaps xmm7, xmm9
000079a3731dc79f  mulpd xmm7, xmm15
000079a3731dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000079a3731dc7a9  ptest xmm6, xmm6
000079a3731dc7ae  jnz 0x000079A3731E12EA
000079a3731dc7b4  movaps [r15+0x220], xmm7
000079a3731dc7bc  vmovaps xmm15, [rsp+0x20]
000079a3731dc7c2  vpermilpd xmm15, xmm15, 0x00
000079a3731dc7c8  movaps xmm9, xmm13
000079a3731dc7cc  mulpd xmm9, xmm15
000079a3731dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000079a3731dc7d7  ptest xmm6, xmm6
000079a3731dc7dc  jnz 0x000079A3731E142C
000079a3731dc7e2  movaps xmm15, xmm11
000079a3731dc7e6  addpd xmm15, xmm12
000079a3731dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000079a3731dc7f1  ptest xmm13, xmm13
000079a3731dc7f7  jnz 0x000079A3731E1570
000079a3731dc7fd  movaps [r15+0x140], xmm15
000079a3731dc805  movaps xmm13, xmm10
000079a3731dc809  addpd xmm13, xmm14
000079a3731dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000079a3731dc814  ptest xmm12, xmm12
000079a3731dc81a  jnz 0x000079A3731E16B4
000079a3731dc820  movaps [r15+0x150], xmm13
000079a3731dc828  movaps xmm14, xmm1
000079a3731dc82c  addpd xmm14, xmm7
000079a3731dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000079a3731dc837  ptest xmm12, xmm12
000079a3731dc83d  jnz 0x000079A3731E17F8
000079a3731dc843  movaps [r15+0x160], xmm14
000079a3731dc84b  movaps xmm1, xmm8
000079a3731dc84f  addpd xmm1, xmm9
000079a3731dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000079a3731dc859  ptest xmm12, xmm12
000079a3731dc85f  jnz 0x000079A3731E193A
000079a3731dc865  movaps [r15+0x120], xmm1
000079a3731dc86d  movups [r13+r14*1], xmm15
000079a3731dc873  lea rax, [r14+0x10]
000079a3731dc877  movups [r13+rax*1], xmm13
000079a3731dc87d  lea rax, [r14+0x20]
000079a3731dc881  movups [r13+rax*1], xmm14
000079a3731dc887  lea rax, [r14+0x30]
000079a3731dc88b  movups [r13+rax*1], xmm1
000079a3731dc891  mov eax, [r15+0x108]
000079a3731dc898  sahf
000079a3731dc899  jnz 0x000079A3731DC8CB
000079a3731dc89b  cmp dword ptr [r15+0x318], 0x00
000079a3731dc8a3  jz 0x000079A3731DB900
000079a3731dc8a9  nop [rax+rax*1], ax
000079a3731dc8b2  nop [rax+rax*1], eax
000079a3731dc8ba  mov eax, 0x410444
000079a3731dc8bf  mov [r15+0x100], rax
000079a3731dc8c6  jmp 0x000079A372FFE110
000079a3731dc8cb  cmp dword ptr [r15+0x318], 0x00
000079a3731dc8d3  jz 0x000079A3731D57E0
000079a3731dc8d9  nop [rax+rax*1], ax
000079a3731dc8e2  nop [rax+rax*1], eax
000079a3731dc8ea  mov eax, 0x410278
000079a3731dc8ef  mov [r15+0x100], rax
000079a3731dc8f6  jmp 0x000079A372FFE110
000079a3731dc8fb  int3
000079a3731dc8fc  call 0x000079A3730E27E0
000079a3731dc901  jmp 0x000079A3731DB9DF
000079a3731dc906  call 0x000079A3730E1570
000079a3731dc90b  jmp 0x000079A3731DB9E8
000079a3731dc910  call 0x000079A3730E27E0
000079a3731dc915  jmp 0x000079A3731DBA44
000079a3731dc91a  call 0x000079A3730E1570
000079a3731dc91f  jmp 0x000079A3731DBA4D
000079a3731dc924  call 0x000079A3730E27E0
000079a3731dc929  jmp 0x000079A3731DBA90
000079a3731dc92e  call 0x000079A3730E1570
000079a3731dc933  jmp 0x000079A3731DBA99
000079a3731dc938  call 0x000079A37300DC20
000079a3731dc93d  jmp 0x000079A3731DBAD8
000079a3731dc942  call 0x000079A3730D59C0
000079a3731dc947  jmp 0x000079A3731DBAEB
000079a3731dc94c  call 0x000079A3730E0E30
000079a3731dc951  jmp 0x000079A3731DBB09
000079a3731dc956  call 0x000079A3730DFBC0
000079a3731dc95b  jmp 0x000079A3731DBB13
000079a3731dc960  call 0x000079A3730DE950
000079a3731dc965  jmp 0x000079A3731DBB1D
000079a3731dc96a  sub rsp, 0x08
000079a3731dc96e  push rax
000079a3731dc96f  push rcx
000079a3731dc970  push rdx
000079a3731dc971  push rdi
000079a3731dc972  push rsi
000079a3731dc973  push r8
000079a3731dc975  push r9
000079a3731dc977  push r10
000079a3731dc979  push r11
000079a3731dc97b  sub rsp, 0xF0
000079a3731dc982  vmovaps [rsp], xmm0
000079a3731dc987  vmovaps [rsp+0x10], xmm1
000079a3731dc98d  vmovaps [rsp+0x20], xmm2
000079a3731dc993  vmovaps [rsp+0x30], xmm3
000079a3731dc999  vmovaps [rsp+0x40], xmm4
000079a3731dc99f  vmovaps [rsp+0x50], xmm5
000079a3731dc9a5  vmovaps [rsp+0x60], xmm6
000079a3731dc9ab  vmovaps [rsp+0x70], xmm7
000079a3731dc9b1  vmovaps [rsp+0x80], xmm9
000079a3731dc9ba  vmovaps [rsp+0x90], xmm10
000079a3731dc9c3  vmovaps [rsp+0xA0], xmm11
000079a3731dc9cc  vmovaps [rsp+0xB0], xmm12
000079a3731dc9d5  vmovaps [rsp+0xC0], xmm13
000079a3731dc9de  vmovaps [rsp+0xD0], xmm14
000079a3731dc9e7  vmovaps [rsp+0xE0], xmm15
000079a3731dc9f0  sub rsp, 0x30
000079a3731dc9f4  movaps [rsp], xmm8
000079a3731dc9f9  movaps [rsp+0x10], xmm12
000079a3731dc9ff  movaps [rsp+0x20], xmm15
000079a3731dca05  lea rdi, [rsp]
000079a3731dca09  mov esi, 0x00
000079a3731dca0e  mov rax, 0x64F127B95530
000079a3731dca18  call rax
000079a3731dca1a  movaps xmm8, [rsp]
000079a3731dca1f  add rsp, 0x30
000079a3731dca23  vmovaps xmm0, [rsp]
000079a3731dca28  vmovaps xmm1, [rsp+0x10]
000079a3731dca2e  vmovaps xmm2, [rsp+0x20]
000079a3731dca34  vmovaps xmm3, [rsp+0x30]
000079a3731dca3a  vmovaps xmm4, [rsp+0x40]
000079a3731dca40  vmovaps xmm5, [rsp+0x50]
000079a3731dca46  vmovaps xmm6, [rsp+0x60]
000079a3731dca4c  vmovaps xmm7, [rsp+0x70]
000079a3731dca52  vmovaps xmm9, [rsp+0x80]
000079a3731dca5b  vmovaps xmm10, [rsp+0x90]
000079a3731dca64  vmovaps xmm11, [rsp+0xA0]
000079a3731dca6d  vmovaps xmm12, [rsp+0xB0]
000079a3731dca76  vmovaps xmm13, [rsp+0xC0]
000079a3731dca7f  vmovaps xmm14, [rsp+0xD0]
000079a3731dca88  vmovaps xmm15, [rsp+0xE0]
000079a3731dca91  add rsp, 0xF0
000079a3731dca98  pop r11
000079a3731dca9a  pop r10
000079a3731dca9c  pop r9
000079a3731dca9e  pop r8
000079a3731dcaa0  pop rsi
000079a3731dcaa1  pop rdi
000079a3731dcaa2  pop rdx
000079a3731dcaa3  pop rcx
000079a3731dcaa4  pop rax
000079a3731dcaa5  add rsp, 0x08
000079a3731dcaa9  jmp 0x000079A3731DBB47
000079a3731dcaae  sub rsp, 0x08
000079a3731dcab2  push rax
000079a3731dcab3  push rcx
000079a3731dcab4  push rdx
000079a3731dcab5  push rdi
000079a3731dcab6  push rsi
000079a3731dcab7  push r8
000079a3731dcab9  push r9
000079a3731dcabb  push r10
000079a3731dcabd  push r11
000079a3731dcabf  sub rsp, 0xF0
000079a3731dcac6  vmovaps [rsp], xmm0
000079a3731dcacb  vmovaps [rsp+0x10], xmm1
000079a3731dcad1  vmovaps [rsp+0x20], xmm2
000079a3731dcad7  vmovaps [rsp+0x30], xmm3
000079a3731dcadd  vmovaps [rsp+0x40], xmm4
000079a3731dcae3  vmovaps [rsp+0x50], xmm5
000079a3731dcae9  vmovaps [rsp+0x60], xmm6
000079a3731dcaef  vmovaps [rsp+0x70], xmm8
000079a3731dcaf5  vmovaps [rsp+0x80], xmm9
000079a3731dcafe  vmovaps [rsp+0x90], xmm10
000079a3731dcb07  vmovaps [rsp+0xA0], xmm11
000079a3731dcb10  vmovaps [rsp+0xB0], xmm12
000079a3731dcb19  vmovaps [rsp+0xC0], xmm13
000079a3731dcb22  vmovaps [rsp+0xD0], xmm14
000079a3731dcb2b  vmovaps [rsp+0xE0], xmm15
000079a3731dcb34  sub rsp, 0x30
000079a3731dcb38  movaps [rsp], xmm7
000079a3731dcb3c  movaps [rsp+0x10], xmm9
000079a3731dcb42  movaps [rsp+0x20], xmm15
000079a3731dcb48  lea rdi, [rsp]
000079a3731dcb4c  mov esi, 0x00
000079a3731dcb51  mov rax, 0x64F127B95530
000079a3731dcb5b  call rax
000079a3731dcb5d  movaps xmm7, [rsp]
000079a3731dcb61  add rsp, 0x30
000079a3731dcb65  vmovaps xmm0, [rsp]
000079a3731dcb6a  vmovaps xmm1, [rsp+0x10]
000079a3731dcb70  vmovaps xmm2, [rsp+0x20]
000079a3731dcb76  vmovaps xmm3, [rsp+0x30]
000079a3731dcb7c  vmovaps xmm4, [rsp+0x40]
000079a3731dcb82  vmovaps xmm5, [rsp+0x50]
000079a3731dcb88  vmovaps xmm6, [rsp+0x60]
000079a3731dcb8e  vmovaps xmm8, [rsp+0x70]
000079a3731dcb94  vmovaps xmm9, [rsp+0x80]
000079a3731dcb9d  vmovaps xmm10, [rsp+0x90]
000079a3731dcba6  vmovaps xmm11, [rsp+0xA0]
000079a3731dcbaf  vmovaps xmm12, [rsp+0xB0]
000079a3731dcbb8  vmovaps xmm13, [rsp+0xC0]
000079a3731dcbc1  vmovaps xmm14, [rsp+0xD0]
000079a3731dcbca  vmovaps xmm15, [rsp+0xE0]
000079a3731dcbd3  add rsp, 0xF0
000079a3731dcbda  pop r11
000079a3731dcbdc  pop r10
000079a3731dcbde  pop r9
000079a3731dcbe0  pop r8
000079a3731dcbe2  pop rsi
000079a3731dcbe3  pop rdi
000079a3731dcbe4  pop rdx
000079a3731dcbe5  pop rcx
000079a3731dcbe6  pop rax
000079a3731dcbe7  add rsp, 0x08
000079a3731dcbeb  jmp 0x000079A3731DBB75
000079a3731dcbf0  sub rsp, 0x08
000079a3731dcbf4  push rax
000079a3731dcbf5  push rcx
000079a3731dcbf6  push rdx
000079a3731dcbf7  push rdi
000079a3731dcbf8  push rsi
000079a3731dcbf9  push r8
000079a3731dcbfb  push r9
000079a3731dcbfd  push r10
000079a3731dcbff  push r11
000079a3731dcc01  sub rsp, 0xF0
000079a3731dcc08  vmovaps [rsp], xmm0
000079a3731dcc0d  vmovaps [rsp+0x10], xmm1
000079a3731dcc13  vmovaps [rsp+0x20], xmm2
000079a3731dcc19  vmovaps [rsp+0x30], xmm3
000079a3731dcc1f  vmovaps [rsp+0x40], xmm4
000079a3731dcc25  vmovaps [rsp+0x50], xmm5
000079a3731dcc2b  vmovaps [rsp+0x60], xmm6
000079a3731dcc31  vmovaps [rsp+0x70], xmm7
000079a3731dcc37  vmovaps [rsp+0x80], xmm8
000079a3731dcc40  vmovaps [rsp+0x90], xmm10
000079a3731dcc49  vmovaps [rsp+0xA0], xmm11
000079a3731dcc52  vmovaps [rsp+0xB0], xmm12
000079a3731dcc5b  vmovaps [rsp+0xC0], xmm13
000079a3731dcc64  vmovaps [rsp+0xD0], xmm14
000079a3731dcc6d  vmovaps [rsp+0xE0], xmm15
000079a3731dcc76  sub rsp, 0x30
000079a3731dcc7a  movaps [rsp], xmm9
000079a3731dcc7f  movaps [rsp+0x10], xmm12
000079a3731dcc85  movaps [rsp+0x20], xmm10
000079a3731dcc8b  lea rdi, [rsp]
000079a3731dcc8f  mov esi, 0x00
000079a3731dcc94  mov rax, 0x64F127B95530
000079a3731dcc9e  call rax
000079a3731dcca0  movaps xmm9, [rsp]
000079a3731dcca5  add rsp, 0x30
000079a3731dcca9  vmovaps xmm0, [rsp]
000079a3731dccae  vmovaps xmm1, [rsp+0x10]
000079a3731dccb4  vmovaps xmm2, [rsp+0x20]
000079a3731dccba  vmovaps xmm3, [rsp+0x30]
000079a3731dccc0  vmovaps xmm4, [rsp+0x40]
000079a3731dccc6  vmovaps xmm5, [rsp+0x50]
000079a3731dcccc  vmovaps xmm6, [rsp+0x60]
000079a3731dccd2  vmovaps xmm7, [rsp+0x70]
000079a3731dccd8  vmovaps xmm8, [rsp+0x80]
000079a3731dcce1  vmovaps xmm10, [rsp+0x90]
000079a3731dccea  vmovaps xmm11, [rsp+0xA0]
000079a3731dccf3  vmovaps xmm12, [rsp+0xB0]
000079a3731dccfc  vmovaps xmm13, [rsp+0xC0]
000079a3731dcd05  vmovaps xmm14, [rsp+0xD0]
000079a3731dcd0e  vmovaps xmm15, [rsp+0xE0]
000079a3731dcd17  add rsp, 0xF0
000079a3731dcd1e  pop r11
000079a3731dcd20  pop r10
000079a3731dcd22  pop r9
000079a3731dcd24  pop r8
000079a3731dcd26  pop rsi
000079a3731dcd27  pop rdi
000079a3731dcd28  pop rdx
000079a3731dcd29  pop rcx
000079a3731dcd2a  pop rax
000079a3731dcd2b  add rsp, 0x08
000079a3731dcd2f  jmp 0x000079A3731DBB99
000079a3731dcd34  sub rsp, 0x08
000079a3731dcd38  push rax
000079a3731dcd39  push rcx
000079a3731dcd3a  push rdx
000079a3731dcd3b  push rdi
000079a3731dcd3c  push rsi
000079a3731dcd3d  push r8
000079a3731dcd3f  push r9
000079a3731dcd41  push r10
000079a3731dcd43  push r11
000079a3731dcd45  sub rsp, 0xF0
000079a3731dcd4c  vmovaps [rsp], xmm0
000079a3731dcd51  vmovaps [rsp+0x10], xmm1
000079a3731dcd57  vmovaps [rsp+0x20], xmm2
000079a3731dcd5d  vmovaps [rsp+0x30], xmm3
000079a3731dcd63  vmovaps [rsp+0x40], xmm4
000079a3731dcd69  vmovaps [rsp+0x50], xmm5
000079a3731dcd6f  vmovaps [rsp+0x60], xmm6
000079a3731dcd75  vmovaps [rsp+0x70], xmm7
000079a3731dcd7b  vmovaps [rsp+0x80], xmm8
000079a3731dcd84  vmovaps [rsp+0x90], xmm9
000079a3731dcd8d  vmovaps [rsp+0xA0], xmm11
000079a3731dcd96  vmovaps [rsp+0xB0], xmm12
000079a3731dcd9f  vmovaps [rsp+0xC0], xmm13
000079a3731dcda8  vmovaps [rsp+0xD0], xmm14
000079a3731dcdb1  vmovaps [rsp+0xE0], xmm15
000079a3731dcdba  sub rsp, 0x30
000079a3731dcdbe  movaps [rsp], xmm10
000079a3731dcdc3  movaps [rsp+0x10], xmm12
000079a3731dcdc9  movaps [rsp+0x20], xmm11
000079a3731dcdcf  lea rdi, [rsp]
000079a3731dcdd3  mov esi, 0x00
000079a3731dcdd8  mov rax, 0x64F127B95530
000079a3731dcde2  call rax
000079a3731dcde4  movaps xmm10, [rsp]
000079a3731dcde9  add rsp, 0x30
000079a3731dcded  vmovaps xmm0, [rsp]
000079a3731dcdf2  vmovaps xmm1, [rsp+0x10]
000079a3731dcdf8  vmovaps xmm2, [rsp+0x20]
000079a3731dcdfe  vmovaps xmm3, [rsp+0x30]
000079a3731dce04  vmovaps xmm4, [rsp+0x40]
000079a3731dce0a  vmovaps xmm5, [rsp+0x50]
000079a3731dce10  vmovaps xmm6, [rsp+0x60]
000079a3731dce16  vmovaps xmm7, [rsp+0x70]
000079a3731dce1c  vmovaps xmm8, [rsp+0x80]
000079a3731dce25  vmovaps xmm9, [rsp+0x90]
000079a3731dce2e  vmovaps xmm11, [rsp+0xA0]
000079a3731dce37  vmovaps xmm12, [rsp+0xB0]
000079a3731dce40  vmovaps xmm13, [rsp+0xC0]
000079a3731dce49  vmovaps xmm14, [rsp+0xD0]
000079a3731dce52  vmovaps xmm15, [rsp+0xE0]
000079a3731dce5b  add rsp, 0xF0
000079a3731dce62  pop r11
000079a3731dce64  pop r10
000079a3731dce66  pop r9
000079a3731dce68  pop r8
000079a3731dce6a  pop rsi
000079a3731dce6b  pop rdi
000079a3731dce6c  pop rdx
000079a3731dce6d  pop rcx
000079a3731dce6e  pop rax
000079a3731dce6f  add rsp, 0x08
000079a3731dce73  jmp 0x000079A3731DBBB3
000079a3731dce78  sub rsp, 0x08
000079a3731dce7c  push rax
000079a3731dce7d  push rcx
000079a3731dce7e  push rdx
000079a3731dce7f  push rdi
000079a3731dce80  push rsi
000079a3731dce81  push r8
000079a3731dce83  push r9
000079a3731dce85  push r10
000079a3731dce87  push r11
000079a3731dce89  sub rsp, 0xF0
000079a3731dce90  vmovaps [rsp], xmm0
000079a3731dce95  vmovaps [rsp+0x10], xmm1
000079a3731dce9b  vmovaps [rsp+0x20], xmm2
000079a3731dcea1  vmovaps [rsp+0x30], xmm3
000079a3731dcea7  vmovaps [rsp+0x40], xmm4
000079a3731dcead  vmovaps [rsp+0x50], xmm5
000079a3731dceb3  vmovaps [rsp+0x60], xmm7
000079a3731dceb9  vmovaps [rsp+0x70], xmm8
000079a3731dcebf  vmovaps [rsp+0x80], xmm9
000079a3731dcec8  vmovaps [rsp+0x90], xmm10
000079a3731dced1  vmovaps [rsp+0xA0], xmm11
000079a3731dceda  vmovaps [rsp+0xB0], xmm12
000079a3731dcee3  vmovaps [rsp+0xC0], xmm13
000079a3731dceec  vmovaps [rsp+0xD0], xmm14
000079a3731dcef5  vmovaps [rsp+0xE0], xmm15
000079a3731dcefe  sub rsp, 0x30
000079a3731dcf02  movaps [rsp], xmm6
000079a3731dcf06  movaps [rsp+0x10], xmm12
000079a3731dcf0c  movaps [rsp+0x20], xmm11
000079a3731dcf12  lea rdi, [rsp]
000079a3731dcf16  mov esi, 0x00
000079a3731dcf1b  mov rax, 0x64F127B95530
000079a3731dcf25  call rax
000079a3731dcf27  movaps xmm6, [rsp]
000079a3731dcf2b  add rsp, 0x30
000079a3731dcf2f  vmovaps xmm0, [rsp]
000079a3731dcf34  vmovaps xmm1, [rsp+0x10]
000079a3731dcf3a  vmovaps xmm2, [rsp+0x20]
000079a3731dcf40  vmovaps xmm3, [rsp+0x30]
000079a3731dcf46  vmovaps xmm4, [rsp+0x40]
000079a3731dcf4c  vmovaps xmm5, [rsp+0x50]
000079a3731dcf52  vmovaps xmm7, [rsp+0x60]
000079a3731dcf58  vmovaps xmm8, [rsp+0x70]
000079a3731dcf5e  vmovaps xmm9, [rsp+0x80]
000079a3731dcf67  vmovaps xmm10, [rsp+0x90]
000079a3731dcf70  vmovaps xmm11, [rsp+0xA0]
000079a3731dcf79  vmovaps xmm12, [rsp+0xB0]
000079a3731dcf82  vmovaps xmm13, [rsp+0xC0]
000079a3731dcf8b  vmovaps xmm14, [rsp+0xD0]
000079a3731dcf94  vmovaps xmm15, [rsp+0xE0]
000079a3731dcf9d  add rsp, 0xF0
000079a3731dcfa4  pop r11
000079a3731dcfa6  pop r10
000079a3731dcfa8  pop r9
000079a3731dcfaa  pop r8
000079a3731dcfac  pop rsi
000079a3731dcfad  pop rdi
000079a3731dcfae  pop rdx
000079a3731dcfaf  pop rcx
000079a3731dcfb0  pop rax
000079a3731dcfb1  add rsp, 0x08
000079a3731dcfb5  jmp 0x000079A3731DBBD4
000079a3731dcfba  sub rsp, 0x08
000079a3731dcfbe  push rax
000079a3731dcfbf  push rcx
000079a3731dcfc0  push rdx
000079a3731dcfc1  push rdi
000079a3731dcfc2  push rsi
000079a3731dcfc3  push r8
000079a3731dcfc5  push r9
000079a3731dcfc7  push r10
000079a3731dcfc9  push r11
000079a3731dcfcb  sub rsp, 0xF0
000079a3731dcfd2  vmovaps [rsp], xmm0
000079a3731dcfd7  vmovaps [rsp+0x10], xmm1
000079a3731dcfdd  vmovaps [rsp+0x20], xmm2
000079a3731dcfe3  vmovaps [rsp+0x30], xmm4
000079a3731dcfe9  vmovaps [rsp+0x40], xmm5
000079a3731dcfef  vmovaps [rsp+0x50], xmm6
000079a3731dcff5  vmovaps [rsp+0x60], xmm7
000079a3731dcffb  vmovaps [rsp+0x70], xmm8
000079a3731dd001  vmovaps [rsp+0x80], xmm9
000079a3731dd00a  vmovaps [rsp+0x90], xmm10
000079a3731dd013  vmovaps [rsp+0xA0], xmm11
000079a3731dd01c  vmovaps [rsp+0xB0], xmm12
000079a3731dd025  vmovaps [rsp+0xC0], xmm13
000079a3731dd02e  vmovaps [rsp+0xD0], xmm14
000079a3731dd037  vmovaps [rsp+0xE0], xmm15
000079a3731dd040  sub rsp, 0x30
000079a3731dd044  movaps [rsp], xmm3
000079a3731dd048  movaps [rsp+0x10], xmm5
000079a3731dd04d  movaps [rsp+0x20], xmm4
000079a3731dd052  lea rdi, [rsp]
000079a3731dd056  mov esi, 0x00
000079a3731dd05b  mov rax, 0x64F127B95530
000079a3731dd065  call rax
000079a3731dd067  movaps xmm3, [rsp]
000079a3731dd06b  add rsp, 0x30
000079a3731dd06f  vmovaps xmm0, [rsp]
000079a3731dd074  vmovaps xmm1, [rsp+0x10]
000079a3731dd07a  vmovaps xmm2, [rsp+0x20]
000079a3731dd080  vmovaps xmm4, [rsp+0x30]
000079a3731dd086  vmovaps xmm5, [rsp+0x40]
000079a3731dd08c  vmovaps xmm6, [rsp+0x50]
000079a3731dd092  vmovaps xmm7, [rsp+0x60]
000079a3731dd098  vmovaps xmm8, [rsp+0x70]
000079a3731dd09e  vmovaps xmm9, [rsp+0x80]
000079a3731dd0a7  vmovaps xmm10, [rsp+0x90]
000079a3731dd0b0  vmovaps xmm11, [rsp+0xA0]
000079a3731dd0b9  vmovaps xmm12, [rsp+0xB0]
000079a3731dd0c2  vmovaps xmm13, [rsp+0xC0]
000079a3731dd0cb  vmovaps xmm14, [rsp+0xD0]
000079a3731dd0d4  vmovaps xmm15, [rsp+0xE0]
000079a3731dd0dd  add rsp, 0xF0
000079a3731dd0e4  pop r11
000079a3731dd0e6  pop r10
000079a3731dd0e8  pop r9
000079a3731dd0ea  pop r8
000079a3731dd0ec  pop rsi
000079a3731dd0ed  pop rdi
000079a3731dd0ee  pop rdx
000079a3731dd0ef  pop rcx
000079a3731dd0f0  pop rax
000079a3731dd0f1  add rsp, 0x08
000079a3731dd0f5  jmp 0x000079A3731DBC35
000079a3731dd0fa  sub rsp, 0x08
000079a3731dd0fe  push rax
000079a3731dd0ff  push rcx
000079a3731dd100  push rdx
000079a3731dd101  push rdi
000079a3731dd102  push rsi
000079a3731dd103  push r8
000079a3731dd105  push r9
000079a3731dd107  push r10
000079a3731dd109  push r11
000079a3731dd10b  sub rsp, 0xF0
000079a3731dd112  vmovaps [rsp], xmm0
000079a3731dd117  vmovaps [rsp+0x10], xmm1
000079a3731dd11d  vmovaps [rsp+0x20], xmm2
000079a3731dd123  vmovaps [rsp+0x30], xmm3
000079a3731dd129  vmovaps [rsp+0x40], xmm4
000079a3731dd12f  vmovaps [rsp+0x50], xmm6
000079a3731dd135  vmovaps [rsp+0x60], xmm7
000079a3731dd13b  vmovaps [rsp+0x70], xmm8
000079a3731dd141  vmovaps [rsp+0x80], xmm9
000079a3731dd14a  vmovaps [rsp+0x90], xmm10
000079a3731dd153  vmovaps [rsp+0xA0], xmm11
000079a3731dd15c  vmovaps [rsp+0xB0], xmm12
000079a3731dd165  vmovaps [rsp+0xC0], xmm13
000079a3731dd16e  vmovaps [rsp+0xD0], xmm14
000079a3731dd177  vmovaps [rsp+0xE0], xmm15
000079a3731dd180  sub rsp, 0x30
000079a3731dd184  movaps [rsp], xmm5
000079a3731dd188  movaps [rsp+0x10], xmm8
000079a3731dd18e  movaps [rsp+0x20], xmm15
000079a3731dd194  lea rdi, [rsp]
000079a3731dd198  mov esi, 0x00
000079a3731dd19d  mov rax, 0x64F127B95530
000079a3731dd1a7  call rax
000079a3731dd1a9  movaps xmm5, [rsp]
000079a3731dd1ad  add rsp, 0x30
000079a3731dd1b1  vmovaps xmm0, [rsp]
000079a3731dd1b6  vmovaps xmm1, [rsp+0x10]
000079a3731dd1bc  vmovaps xmm2, [rsp+0x20]
000079a3731dd1c2  vmovaps xmm3, [rsp+0x30]
000079a3731dd1c8  vmovaps xmm4, [rsp+0x40]
000079a3731dd1ce  vmovaps xmm6, [rsp+0x50]
000079a3731dd1d4  vmovaps xmm7, [rsp+0x60]
000079a3731dd1da  vmovaps xmm8, [rsp+0x70]
000079a3731dd1e0  vmovaps xmm9, [rsp+0x80]
000079a3731dd1e9  vmovaps xmm10, [rsp+0x90]
000079a3731dd1f2  vmovaps xmm11, [rsp+0xA0]
000079a3731dd1fb  vmovaps xmm12, [rsp+0xB0]
000079a3731dd204  vmovaps xmm13, [rsp+0xC0]
000079a3731dd20d  vmovaps xmm14, [rsp+0xD0]
000079a3731dd216  vmovaps xmm15, [rsp+0xE0]
000079a3731dd21f  add rsp, 0xF0
000079a3731dd226  pop r11
000079a3731dd228  pop r10
000079a3731dd22a  pop r9
000079a3731dd22c  pop r8
000079a3731dd22e  pop rsi
000079a3731dd22f  pop rdi
000079a3731dd230  pop rdx
000079a3731dd231  pop rcx
000079a3731dd232  pop rax
000079a3731dd233  add rsp, 0x08
000079a3731dd237  jmp 0x000079A3731DBC73
000079a3731dd23c  sub rsp, 0x08
000079a3731dd240  push rax
000079a3731dd241  push rcx
000079a3731dd242  push rdx
000079a3731dd243  push rdi
000079a3731dd244  push rsi
000079a3731dd245  push r8
000079a3731dd247  push r9
000079a3731dd249  push r10
000079a3731dd24b  push r11
000079a3731dd24d  sub rsp, 0xF0
000079a3731dd254  vmovaps [rsp], xmm0
000079a3731dd259  vmovaps [rsp+0x10], xmm1
000079a3731dd25f  vmovaps [rsp+0x20], xmm2
000079a3731dd265  vmovaps [rsp+0x30], xmm3
000079a3731dd26b  vmovaps [rsp+0x40], xmm5
000079a3731dd271  vmovaps [rsp+0x50], xmm6
000079a3731dd277  vmovaps [rsp+0x60], xmm7
000079a3731dd27d  vmovaps [rsp+0x70], xmm8
000079a3731dd283  vmovaps [rsp+0x80], xmm9
000079a3731dd28c  vmovaps [rsp+0x90], xmm10
000079a3731dd295  vmovaps [rsp+0xA0], xmm11
000079a3731dd29e  vmovaps [rsp+0xB0], xmm12
000079a3731dd2a7  vmovaps [rsp+0xC0], xmm13
000079a3731dd2b0  vmovaps [rsp+0xD0], xmm14
000079a3731dd2b9  vmovaps [rsp+0xE0], xmm15
000079a3731dd2c2  sub rsp, 0x30
000079a3731dd2c6  movaps [rsp], xmm4
000079a3731dd2ca  movaps [rsp+0x10], xmm9
000079a3731dd2d0  movaps [rsp+0x20], xmm8
000079a3731dd2d6  lea rdi, [rsp]
000079a3731dd2da  mov esi, 0x00
000079a3731dd2df  mov rax, 0x64F127B95530
000079a3731dd2e9  call rax
000079a3731dd2eb  movaps xmm4, [rsp]
000079a3731dd2ef  add rsp, 0x30
000079a3731dd2f3  vmovaps xmm0, [rsp]
000079a3731dd2f8  vmovaps xmm1, [rsp+0x10]
000079a3731dd2fe  vmovaps xmm2, [rsp+0x20]
000079a3731dd304  vmovaps xmm3, [rsp+0x30]
000079a3731dd30a  vmovaps xmm5, [rsp+0x40]
000079a3731dd310  vmovaps xmm6, [rsp+0x50]
000079a3731dd316  vmovaps xmm7, [rsp+0x60]
000079a3731dd31c  vmovaps xmm8, [rsp+0x70]
000079a3731dd322  vmovaps xmm9, [rsp+0x80]
000079a3731dd32b  vmovaps xmm10, [rsp+0x90]
000079a3731dd334  vmovaps xmm11, [rsp+0xA0]
000079a3731dd33d  vmovaps xmm12, [rsp+0xB0]
000079a3731dd346  vmovaps xmm13, [rsp+0xC0]
000079a3731dd34f  vmovaps xmm14, [rsp+0xD0]
000079a3731dd358  vmovaps xmm15, [rsp+0xE0]
000079a3731dd361  add rsp, 0xF0
000079a3731dd368  pop r11
000079a3731dd36a  pop r10
000079a3731dd36c  pop r9
000079a3731dd36e  pop r8
000079a3731dd370  pop rsi
000079a3731dd371  pop rdi
000079a3731dd372  pop rdx
000079a3731dd373  pop rcx
000079a3731dd374  pop rax
000079a3731dd375  add rsp, 0x08
000079a3731dd379  jmp 0x000079A3731DBC94
000079a3731dd37e  sub rsp, 0x08
000079a3731dd382  push rax
000079a3731dd383  push rcx
000079a3731dd384  push rdx
000079a3731dd385  push rdi
000079a3731dd386  push rsi
000079a3731dd387  push r8
000079a3731dd389  push r9
000079a3731dd38b  push r10
000079a3731dd38d  push r11
000079a3731dd38f  sub rsp, 0xF0
000079a3731dd396  vmovaps [rsp], xmm0
000079a3731dd39b  vmovaps [rsp+0x10], xmm1
000079a3731dd3a1  vmovaps [rsp+0x20], xmm2
000079a3731dd3a7  vmovaps [rsp+0x30], xmm3
000079a3731dd3ad  vmovaps [rsp+0x40], xmm4
000079a3731dd3b3  vmovaps [rsp+0x50], xmm5
000079a3731dd3b9  vmovaps [rsp+0x60], xmm6
000079a3731dd3bf  vmovaps [rsp+0x70], xmm7
000079a3731dd3c5  vmovaps [rsp+0x80], xmm8
000079a3731dd3ce  vmovaps [rsp+0x90], xmm10
000079a3731dd3d7  vmovaps [rsp+0xA0], xmm11
000079a3731dd3e0  vmovaps [rsp+0xB0], xmm12
000079a3731dd3e9  vmovaps [rsp+0xC0], xmm13
000079a3731dd3f2  vmovaps [rsp+0xD0], xmm14
000079a3731dd3fb  vmovaps [rsp+0xE0], xmm15
000079a3731dd404  sub rsp, 0x30
000079a3731dd408  movaps [rsp], xmm9
000079a3731dd40d  movaps [rsp+0x10], xmm10
000079a3731dd413  movaps [rsp+0x20], xmm8
000079a3731dd419  lea rdi, [rsp]
000079a3731dd41d  mov esi, 0x00
000079a3731dd422  mov rax, 0x64F127B95530
000079a3731dd42c  call rax
000079a3731dd42e  movaps xmm9, [rsp]
000079a3731dd433  add rsp, 0x30
000079a3731dd437  vmovaps xmm0, [rsp]
000079a3731dd43c  vmovaps xmm1, [rsp+0x10]
000079a3731dd442  vmovaps xmm2, [rsp+0x20]
000079a3731dd448  vmovaps xmm3, [rsp+0x30]
000079a3731dd44e  vmovaps xmm4, [rsp+0x40]
000079a3731dd454  vmovaps xmm5, [rsp+0x50]
000079a3731dd45a  vmovaps xmm6, [rsp+0x60]
000079a3731dd460  vmovaps xmm7, [rsp+0x70]
000079a3731dd466  vmovaps xmm8, [rsp+0x80]
000079a3731dd46f  vmovaps xmm10, [rsp+0x90]
000079a3731dd478  vmovaps xmm11, [rsp+0xA0]
000079a3731dd481  vmovaps xmm12, [rsp+0xB0]
000079a3731dd48a  vmovaps xmm13, [rsp+0xC0]
000079a3731dd493  vmovaps xmm14, [rsp+0xD0]
000079a3731dd49c  vmovaps xmm15, [rsp+0xE0]
000079a3731dd4a5  add rsp, 0xF0
000079a3731dd4ac  pop r11
000079a3731dd4ae  pop r10
000079a3731dd4b0  pop r9
000079a3731dd4b2  pop r8
000079a3731dd4b4  pop rsi
000079a3731dd4b5  pop rdi
000079a3731dd4b6  pop rdx
000079a3731dd4b7  pop rcx
000079a3731dd4b8  pop rax
000079a3731dd4b9  add rsp, 0x08
000079a3731dd4bd  jmp 0x000079A3731DBCAE
000079a3731dd4c2  call 0x000079A3730B52F0
000079a3731dd4c7  jmp 0x000079A3731DBDC8
000079a3731dd4cc  call 0x000079A3730B52F0
000079a3731dd4d1  jmp 0x000079A3731DBDDE
000079a3731dd4d6  sub rsp, 0x08
000079a3731dd4da  push rax
000079a3731dd4db  push rcx
000079a3731dd4dc  push rdx
000079a3731dd4dd  push rdi
000079a3731dd4de  push rsi
000079a3731dd4df  push r8
000079a3731dd4e1  push r9
000079a3731dd4e3  push r10
000079a3731dd4e5  push r11
000079a3731dd4e7  sub rsp, 0xF0
000079a3731dd4ee  vmovaps [rsp], xmm0
000079a3731dd4f3  vmovaps [rsp+0x10], xmm2
000079a3731dd4f9  vmovaps [rsp+0x20], xmm3
000079a3731dd4ff  vmovaps [rsp+0x30], xmm4
000079a3731dd505  vmovaps [rsp+0x40], xmm5
000079a3731dd50b  vmovaps [rsp+0x50], xmm6
000079a3731dd511  vmovaps [rsp+0x60], xmm7
000079a3731dd517  vmovaps [rsp+0x70], xmm8
000079a3731dd51d  vmovaps [rsp+0x80], xmm9
000079a3731dd526  vmovaps [rsp+0x90], xmm10
000079a3731dd52f  vmovaps [rsp+0xA0], xmm11
000079a3731dd538  vmovaps [rsp+0xB0], xmm12
000079a3731dd541  vmovaps [rsp+0xC0], xmm13
000079a3731dd54a  vmovaps [rsp+0xD0], xmm14
000079a3731dd553  vmovaps [rsp+0xE0], xmm15
000079a3731dd55c  sub rsp, 0x30
000079a3731dd560  movaps [rsp], xmm1
000079a3731dd564  movaps [rsp+0x10], xmm6
000079a3731dd569  movaps [rsp+0x20], xmm15
000079a3731dd56f  lea rdi, [rsp]
000079a3731dd573  mov esi, 0x00
000079a3731dd578  mov rax, 0x64F127B95530
000079a3731dd582  call rax
000079a3731dd584  movaps xmm1, [rsp]
000079a3731dd588  add rsp, 0x30
000079a3731dd58c  vmovaps xmm0, [rsp]
000079a3731dd591  vmovaps xmm2, [rsp+0x10]
000079a3731dd597  vmovaps xmm3, [rsp+0x20]
000079a3731dd59d  vmovaps xmm4, [rsp+0x30]
000079a3731dd5a3  vmovaps xmm5, [rsp+0x40]
000079a3731dd5a9  vmovaps xmm6, [rsp+0x50]
000079a3731dd5af  vmovaps xmm7, [rsp+0x60]
000079a3731dd5b5  vmovaps xmm8, [rsp+0x70]
000079a3731dd5bb  vmovaps xmm9, [rsp+0x80]
000079a3731dd5c4  vmovaps xmm10, [rsp+0x90]
000079a3731dd5cd  vmovaps xmm11, [rsp+0xA0]
000079a3731dd5d6  vmovaps xmm12, [rsp+0xB0]
000079a3731dd5df  vmovaps xmm13, [rsp+0xC0]
000079a3731dd5e8  vmovaps xmm14, [rsp+0xD0]
000079a3731dd5f1  vmovaps xmm15, [rsp+0xE0]
000079a3731dd5fa  add rsp, 0xF0
000079a3731dd601  pop r11
000079a3731dd603  pop r10
000079a3731dd605  pop r9
000079a3731dd607  pop r8
000079a3731dd609  pop rsi
000079a3731dd60a  pop rdi
000079a3731dd60b  pop rdx
000079a3731dd60c  pop rcx
000079a3731dd60d  pop rax
000079a3731dd60e  add rsp, 0x08
000079a3731dd612  jmp 0x000079A3731DBE1B
000079a3731dd617  call 0x000079A3730C4620
000079a3731dd61c  jmp 0x000079A3731DBE28
000079a3731dd621  sub rsp, 0x08
000079a3731dd625  push rax
000079a3731dd626  push rcx
000079a3731dd627  push rdx
000079a3731dd628  push rdi
000079a3731dd629  push rsi
000079a3731dd62a  push r8
000079a3731dd62c  push r9
000079a3731dd62e  push r10
000079a3731dd630  push r11
000079a3731dd632  sub rsp, 0xF0
000079a3731dd639  vmovaps [rsp], xmm0
000079a3731dd63e  vmovaps [rsp+0x10], xmm1
000079a3731dd644  vmovaps [rsp+0x20], xmm2
000079a3731dd64a  vmovaps [rsp+0x30], xmm3
000079a3731dd650  vmovaps [rsp+0x40], xmm4
000079a3731dd656  vmovaps [rsp+0x50], xmm5
000079a3731dd65c  vmovaps [rsp+0x60], xmm6
000079a3731dd662  vmovaps [rsp+0x70], xmm7
000079a3731dd668  vmovaps [rsp+0x80], xmm8
000079a3731dd671  vmovaps [rsp+0x90], xmm9
000079a3731dd67a  vmovaps [rsp+0xA0], xmm10
000079a3731dd683  vmovaps [rsp+0xB0], xmm11
000079a3731dd68c  vmovaps [rsp+0xC0], xmm12
000079a3731dd695  vmovaps [rsp+0xD0], xmm13
000079a3731dd69e  vmovaps [rsp+0xE0], xmm15
000079a3731dd6a7  sub rsp, 0x30
000079a3731dd6ab  movaps [rsp], xmm14
000079a3731dd6b0  movaps [rsp+0x10], xmm4
000079a3731dd6b5  movaps [rsp+0x20], xmm3
000079a3731dd6ba  lea rdi, [rsp]
000079a3731dd6be  mov esi, 0x00
000079a3731dd6c3  mov rax, 0x64F127B95530
000079a3731dd6cd  call rax
000079a3731dd6cf  movaps xmm14, [rsp]
000079a3731dd6d4  add rsp, 0x30
000079a3731dd6d8  vmovaps xmm0, [rsp]
000079a3731dd6dd  vmovaps xmm1, [rsp+0x10]
000079a3731dd6e3  vmovaps xmm2, [rsp+0x20]
000079a3731dd6e9  vmovaps xmm3, [rsp+0x30]
000079a3731dd6ef  vmovaps xmm4, [rsp+0x40]
000079a3731dd6f5  vmovaps xmm5, [rsp+0x50]
000079a3731dd6fb  vmovaps xmm6, [rsp+0x60]
000079a3731dd701  vmovaps xmm7, [rsp+0x70]
000079a3731dd707  vmovaps xmm8, [rsp+0x80]
000079a3731dd710  vmovaps xmm9, [rsp+0x90]
000079a3731dd719  vmovaps xmm10, [rsp+0xA0]
000079a3731dd722  vmovaps xmm11, [rsp+0xB0]
000079a3731dd72b  vmovaps xmm12, [rsp+0xC0]
000079a3731dd734  vmovaps xmm13, [rsp+0xD0]
000079a3731dd73d  vmovaps xmm15, [rsp+0xE0]
000079a3731dd746  add rsp, 0xF0
000079a3731dd74d  pop r11
000079a3731dd74f  pop r10
000079a3731dd751  pop r9
000079a3731dd753  pop r8
000079a3731dd755  pop rsi
000079a3731dd756  pop rdi
000079a3731dd757  pop rdx
000079a3731dd758  pop rcx
000079a3731dd759  pop rax
000079a3731dd75a  add rsp, 0x08
000079a3731dd75e  jmp 0x000079A3731DBE42
000079a3731dd763  sub rsp, 0x08
000079a3731dd767  push rax
000079a3731dd768  push rcx
000079a3731dd769  push rdx
000079a3731dd76a  push rdi
000079a3731dd76b  push rsi
000079a3731dd76c  push r8
000079a3731dd76e  push r9
000079a3731dd770  push r10
000079a3731dd772  push r11
000079a3731dd774  sub rsp, 0xF0
000079a3731dd77b  vmovaps [rsp], xmm0
000079a3731dd780  vmovaps [rsp+0x10], xmm1
000079a3731dd786  vmovaps [rsp+0x20], xmm2
000079a3731dd78c  vmovaps [rsp+0x30], xmm3
000079a3731dd792  vmovaps [rsp+0x40], xmm4
000079a3731dd798  vmovaps [rsp+0x50], xmm5
000079a3731dd79e  vmovaps [rsp+0x60], xmm7
000079a3731dd7a4  vmovaps [rsp+0x70], xmm8
000079a3731dd7aa  vmovaps [rsp+0x80], xmm9
000079a3731dd7b3  vmovaps [rsp+0x90], xmm10
000079a3731dd7bc  vmovaps [rsp+0xA0], xmm11
000079a3731dd7c5  vmovaps [rsp+0xB0], xmm12
000079a3731dd7ce  vmovaps [rsp+0xC0], xmm13
000079a3731dd7d7  vmovaps [rsp+0xD0], xmm14
000079a3731dd7e0  vmovaps [rsp+0xE0], xmm15
000079a3731dd7e9  sub rsp, 0x30
000079a3731dd7ed  movaps [rsp], xmm6
000079a3731dd7f1  movaps [rsp+0x10], xmm9
000079a3731dd7f7  movaps [rsp+0x20], xmm7
000079a3731dd7fc  lea rdi, [rsp]
000079a3731dd800  mov esi, 0x00
000079a3731dd805  mov rax, 0x64F127B95530
000079a3731dd80f  call rax
000079a3731dd811  movaps xmm6, [rsp]
000079a3731dd815  add rsp, 0x30
000079a3731dd819  vmovaps xmm0, [rsp]
000079a3731dd81e  vmovaps xmm1, [rsp+0x10]
000079a3731dd824  vmovaps xmm2, [rsp+0x20]
000079a3731dd82a  vmovaps xmm3, [rsp+0x30]
000079a3731dd830  vmovaps xmm4, [rsp+0x40]
000079a3731dd836  vmovaps xmm5, [rsp+0x50]
000079a3731dd83c  vmovaps xmm7, [rsp+0x60]
000079a3731dd842  vmovaps xmm8, [rsp+0x70]
000079a3731dd848  vmovaps xmm9, [rsp+0x80]
000079a3731dd851  vmovaps xmm10, [rsp+0x90]
000079a3731dd85a  vmovaps xmm11, [rsp+0xA0]
000079a3731dd863  vmovaps xmm12, [rsp+0xB0]
000079a3731dd86c  vmovaps xmm13, [rsp+0xC0]
000079a3731dd875  vmovaps xmm14, [rsp+0xD0]
000079a3731dd87e  vmovaps xmm15, [rsp+0xE0]
000079a3731dd887  add rsp, 0xF0
000079a3731dd88e  pop r11
000079a3731dd890  pop r10
000079a3731dd892  pop r9
000079a3731dd894  pop r8
000079a3731dd896  pop rsi
000079a3731dd897  pop rdi
000079a3731dd898  pop rdx
000079a3731dd899  pop rcx
000079a3731dd89a  pop rax
000079a3731dd89b  add rsp, 0x08
000079a3731dd89f  jmp 0x000079A3731DBE5A
000079a3731dd8a4  sub rsp, 0x08
000079a3731dd8a8  push rax
000079a3731dd8a9  push rcx
000079a3731dd8aa  push rdx
000079a3731dd8ab  push rdi
000079a3731dd8ac  push rsi
000079a3731dd8ad  push r8
000079a3731dd8af  push r9
000079a3731dd8b1  push r10
000079a3731dd8b3  push r11
000079a3731dd8b5  sub rsp, 0xF0
000079a3731dd8bc  vmovaps [rsp], xmm0
000079a3731dd8c1  vmovaps [rsp+0x10], xmm1
000079a3731dd8c7  vmovaps [rsp+0x20], xmm2
000079a3731dd8cd  vmovaps [rsp+0x30], xmm3
000079a3731dd8d3  vmovaps [rsp+0x40], xmm4
000079a3731dd8d9  vmovaps [rsp+0x50], xmm5
000079a3731dd8df  vmovaps [rsp+0x60], xmm6
000079a3731dd8e5  vmovaps [rsp+0x70], xmm8
000079a3731dd8eb  vmovaps [rsp+0x80], xmm9
000079a3731dd8f4  vmovaps [rsp+0x90], xmm10
000079a3731dd8fd  vmovaps [rsp+0xA0], xmm11
000079a3731dd906  vmovaps [rsp+0xB0], xmm12
000079a3731dd90f  vmovaps [rsp+0xC0], xmm13
000079a3731dd918  vmovaps [rsp+0xD0], xmm14
000079a3731dd921  vmovaps [rsp+0xE0], xmm15
000079a3731dd92a  sub rsp, 0x30
000079a3731dd92e  movaps [rsp], xmm7
000079a3731dd932  movaps [rsp+0x10], xmm4
000079a3731dd937  movaps [rsp+0x20], xmm9
000079a3731dd93d  lea rdi, [rsp]
000079a3731dd941  mov esi, 0x00
000079a3731dd946  mov rax, 0x64F127B95530
000079a3731dd950  call rax
000079a3731dd952  movaps xmm7, [rsp]
000079a3731dd956  add rsp, 0x30
000079a3731dd95a  vmovaps xmm0, [rsp]
000079a3731dd95f  vmovaps xmm1, [rsp+0x10]
000079a3731dd965  vmovaps xmm2, [rsp+0x20]
000079a3731dd96b  vmovaps xmm3, [rsp+0x30]
000079a3731dd971  vmovaps xmm4, [rsp+0x40]
000079a3731dd977  vmovaps xmm5, [rsp+0x50]
000079a3731dd97d  vmovaps xmm6, [rsp+0x60]
000079a3731dd983  vmovaps xmm8, [rsp+0x70]
000079a3731dd989  vmovaps xmm9, [rsp+0x80]
000079a3731dd992  vmovaps xmm10, [rsp+0x90]
000079a3731dd99b  vmovaps xmm11, [rsp+0xA0]
000079a3731dd9a4  vmovaps xmm12, [rsp+0xB0]
000079a3731dd9ad  vmovaps xmm13, [rsp+0xC0]
000079a3731dd9b6  vmovaps xmm14, [rsp+0xD0]
000079a3731dd9bf  vmovaps xmm15, [rsp+0xE0]
000079a3731dd9c8  add rsp, 0xF0
000079a3731dd9cf  pop r11
000079a3731dd9d1  pop r10
000079a3731dd9d3  pop r9
000079a3731dd9d5  pop r8
000079a3731dd9d7  pop rsi
000079a3731dd9d8  pop rdi
000079a3731dd9d9  pop rdx
000079a3731dd9da  pop rcx
000079a3731dd9db  pop rax
000079a3731dd9dc  add rsp, 0x08
000079a3731dd9e0  jmp 0x000079A3731DBE87
000079a3731dd9e5  sub rsp, 0x08
000079a3731dd9e9  push rax
000079a3731dd9ea  push rcx
000079a3731dd9eb  push rdx
000079a3731dd9ec  push rdi
000079a3731dd9ed  push rsi
000079a3731dd9ee  push r8
000079a3731dd9f0  push r9
000079a3731dd9f2  push r10
000079a3731dd9f4  push r11
000079a3731dd9f6  sub rsp, 0xF0
000079a3731dd9fd  vmovaps [rsp], xmm0
000079a3731dda02  vmovaps [rsp+0x10], xmm1
000079a3731dda08  vmovaps [rsp+0x20], xmm2
000079a3731dda0e  vmovaps [rsp+0x30], xmm3
000079a3731dda14  vmovaps [rsp+0x40], xmm5
000079a3731dda1a  vmovaps [rsp+0x50], xmm6
000079a3731dda20  vmovaps [rsp+0x60], xmm7
000079a3731dda26  vmovaps [rsp+0x70], xmm8
000079a3731dda2c  vmovaps [rsp+0x80], xmm9
000079a3731dda35  vmovaps [rsp+0x90], xmm10
000079a3731dda3e  vmovaps [rsp+0xA0], xmm11
000079a3731dda47  vmovaps [rsp+0xB0], xmm12
000079a3731dda50  vmovaps [rsp+0xC0], xmm13
000079a3731dda59  vmovaps [rsp+0xD0], xmm14
000079a3731dda62  vmovaps [rsp+0xE0], xmm15
000079a3731dda6b  sub rsp, 0x30
000079a3731dda6f  movaps [rsp], xmm4
000079a3731dda73  movaps [rsp+0x10], xmm15
000079a3731dda79  movaps [rsp+0x20], xmm9
000079a3731dda7f  lea rdi, [rsp]
000079a3731dda83  mov esi, 0x00
000079a3731dda88  mov rax, 0x64F127B95530
000079a3731dda92  call rax
000079a3731dda94  movaps xmm4, [rsp]
000079a3731dda98  add rsp, 0x30
000079a3731dda9c  vmovaps xmm0, [rsp]
000079a3731ddaa1  vmovaps xmm1, [rsp+0x10]
000079a3731ddaa7  vmovaps xmm2, [rsp+0x20]
000079a3731ddaad  vmovaps xmm3, [rsp+0x30]
000079a3731ddab3  vmovaps xmm5, [rsp+0x40]
000079a3731ddab9  vmovaps xmm6, [rsp+0x50]
000079a3731ddabf  vmovaps xmm7, [rsp+0x60]
000079a3731ddac5  vmovaps xmm8, [rsp+0x70]
000079a3731ddacb  vmovaps xmm9, [rsp+0x80]
000079a3731ddad4  vmovaps xmm10, [rsp+0x90]
000079a3731ddadd  vmovaps xmm11, [rsp+0xA0]
000079a3731ddae6  vmovaps xmm12, [rsp+0xB0]
000079a3731ddaef  vmovaps xmm13, [rsp+0xC0]
000079a3731ddaf8  vmovaps xmm14, [rsp+0xD0]
000079a3731ddb01  vmovaps xmm15, [rsp+0xE0]
000079a3731ddb0a  add rsp, 0xF0
000079a3731ddb11  pop r11
000079a3731ddb13  pop r10
000079a3731ddb15  pop r9
000079a3731ddb17  pop r8
000079a3731ddb19  pop rsi
000079a3731ddb1a  pop rdi
000079a3731ddb1b  pop rdx
000079a3731ddb1c  pop rcx
000079a3731ddb1d  pop rax
000079a3731ddb1e  add rsp, 0x08
000079a3731ddb22  jmp 0x000079A3731DBEAC
000079a3731ddb27  call 0x000079A3730C4620
000079a3731ddb2c  jmp 0x000079A3731DBEB9
000079a3731ddb31  sub rsp, 0x08
000079a3731ddb35  push rax
000079a3731ddb36  push rcx
000079a3731ddb37  push rdx
000079a3731ddb38  push rdi
000079a3731ddb39  push rsi
000079a3731ddb3a  push r8
000079a3731ddb3c  push r9
000079a3731ddb3e  push r10
000079a3731ddb40  push r11
000079a3731ddb42  sub rsp, 0xF0
000079a3731ddb49  vmovaps [rsp], xmm0
000079a3731ddb4e  vmovaps [rsp+0x10], xmm1
000079a3731ddb54  vmovaps [rsp+0x20], xmm2
000079a3731ddb5a  vmovaps [rsp+0x30], xmm4
000079a3731ddb60  vmovaps [rsp+0x40], xmm5
000079a3731ddb66  vmovaps [rsp+0x50], xmm6
000079a3731ddb6c  vmovaps [rsp+0x60], xmm7
000079a3731ddb72  vmovaps [rsp+0x70], xmm8
000079a3731ddb78  vmovaps [rsp+0x80], xmm9
000079a3731ddb81  vmovaps [rsp+0x90], xmm10
000079a3731ddb8a  vmovaps [rsp+0xA0], xmm11
000079a3731ddb93  vmovaps [rsp+0xB0], xmm12
000079a3731ddb9c  vmovaps [rsp+0xC0], xmm13
000079a3731ddba5  vmovaps [rsp+0xD0], xmm14
000079a3731ddbae  vmovaps [rsp+0xE0], xmm15
000079a3731ddbb7  sub rsp, 0x30
000079a3731ddbbb  movaps [rsp], xmm3
000079a3731ddbbf  movaps [rsp+0x10], xmm1
000079a3731ddbc4  movaps [rsp+0x20], xmm9
000079a3731ddbca  lea rdi, [rsp]
000079a3731ddbce  mov esi, 0x00
000079a3731ddbd3  mov rax, 0x64F127B95530
000079a3731ddbdd  call rax
000079a3731ddbdf  movaps xmm3, [rsp]
000079a3731ddbe3  add rsp, 0x30
000079a3731ddbe7  vmovaps xmm0, [rsp]
000079a3731ddbec  vmovaps xmm1, [rsp+0x10]
000079a3731ddbf2  vmovaps xmm2, [rsp+0x20]
000079a3731ddbf8  vmovaps xmm4, [rsp+0x30]
000079a3731ddbfe  vmovaps xmm5, [rsp+0x40]
000079a3731ddc04  vmovaps xmm6, [rsp+0x50]
000079a3731ddc0a  vmovaps xmm7, [rsp+0x60]
000079a3731ddc10  vmovaps xmm8, [rsp+0x70]
000079a3731ddc16  vmovaps xmm9, [rsp+0x80]
000079a3731ddc1f  vmovaps xmm10, [rsp+0x90]
000079a3731ddc28  vmovaps xmm11, [rsp+0xA0]
000079a3731ddc31  vmovaps xmm12, [rsp+0xB0]
000079a3731ddc3a  vmovaps xmm13, [rsp+0xC0]
000079a3731ddc43  vmovaps xmm14, [rsp+0xD0]
000079a3731ddc4c  vmovaps xmm15, [rsp+0xE0]
000079a3731ddc55  add rsp, 0xF0
000079a3731ddc5c  pop r11
000079a3731ddc5e  pop r10
000079a3731ddc60  pop r9
000079a3731ddc62  pop r8
000079a3731ddc64  pop rsi
000079a3731ddc65  pop rdi
000079a3731ddc66  pop rdx
000079a3731ddc67  pop rcx
000079a3731ddc68  pop rax
000079a3731ddc69  add rsp, 0x08
000079a3731ddc6d  jmp 0x000079A3731DBEF6
000079a3731ddc72  sub rsp, 0x08
000079a3731ddc76  push rax
000079a3731ddc77  push rcx
000079a3731ddc78  push rdx
000079a3731ddc79  push rdi
000079a3731ddc7a  push rsi
000079a3731ddc7b  push r8
000079a3731ddc7d  push r9
000079a3731ddc7f  push r10
000079a3731ddc81  push r11
000079a3731ddc83  sub rsp, 0xF0
000079a3731ddc8a  vmovaps [rsp], xmm0
000079a3731ddc8f  vmovaps [rsp+0x10], xmm2
000079a3731ddc95  vmovaps [rsp+0x20], xmm3
000079a3731ddc9b  vmovaps [rsp+0x30], xmm4
000079a3731ddca1  vmovaps [rsp+0x40], xmm5
000079a3731ddca7  vmovaps [rsp+0x50], xmm6
000079a3731ddcad  vmovaps [rsp+0x60], xmm7
000079a3731ddcb3  vmovaps [rsp+0x70], xmm8
000079a3731ddcb9  vmovaps [rsp+0x80], xmm9
000079a3731ddcc2  vmovaps [rsp+0x90], xmm10
000079a3731ddccb  vmovaps [rsp+0xA0], xmm11
000079a3731ddcd4  vmovaps [rsp+0xB0], xmm12
000079a3731ddcdd  vmovaps [rsp+0xC0], xmm13
000079a3731ddce6  vmovaps [rsp+0xD0], xmm14
000079a3731ddcef  vmovaps [rsp+0xE0], xmm15
000079a3731ddcf8  sub rsp, 0x30
000079a3731ddcfc  movaps [rsp], xmm1
000079a3731ddd00  movaps [rsp+0x10], xmm15
000079a3731ddd06  movaps [rsp+0x20], xmm9
000079a3731ddd0c  lea rdi, [rsp]
000079a3731ddd10  mov esi, 0x00
000079a3731ddd15  mov rax, 0x64F127B95530
000079a3731ddd1f  call rax
000079a3731ddd21  movaps xmm1, [rsp]
000079a3731ddd25  add rsp, 0x30
000079a3731ddd29  vmovaps xmm0, [rsp]
000079a3731ddd2e  vmovaps xmm2, [rsp+0x10]
000079a3731ddd34  vmovaps xmm3, [rsp+0x20]
000079a3731ddd3a  vmovaps xmm4, [rsp+0x30]
000079a3731ddd40  vmovaps xmm5, [rsp+0x40]
000079a3731ddd46  vmovaps xmm6, [rsp+0x50]
000079a3731ddd4c  vmovaps xmm7, [rsp+0x60]
000079a3731ddd52  vmovaps xmm8, [rsp+0x70]
000079a3731ddd58  vmovaps xmm9, [rsp+0x80]
000079a3731ddd61  vmovaps xmm10, [rsp+0x90]
000079a3731ddd6a  vmovaps xmm11, [rsp+0xA0]
000079a3731ddd73  vmovaps xmm12, [rsp+0xB0]
000079a3731ddd7c  vmovaps xmm13, [rsp+0xC0]
000079a3731ddd85  vmovaps xmm14, [rsp+0xD0]
000079a3731ddd8e  vmovaps xmm15, [rsp+0xE0]
000079a3731ddd97  add rsp, 0xF0
000079a3731ddd9e  pop r11
000079a3731ddda0  pop r10
000079a3731ddda2  pop r9
000079a3731ddda4  pop r8
000079a3731ddda6  pop rsi
000079a3731ddda7  pop rdi
000079a3731ddda8  pop rdx
000079a3731ddda9  pop rcx
000079a3731dddaa  pop rax
000079a3731dddab  add rsp, 0x08
000079a3731dddaf  jmp 0x000079A3731DBF7E
000079a3731dddb4  call 0x000079A3730C4620
000079a3731dddb9  jmp 0x000079A3731DBF8B
000079a3731dddbe  sub rsp, 0x08
000079a3731dddc2  push rax
000079a3731dddc3  push rcx
000079a3731dddc4  push rdx
000079a3731dddc5  push rdi
000079a3731dddc6  push rsi
000079a3731dddc7  push r8
000079a3731dddc9  push r9
000079a3731dddcb  push r10
000079a3731dddcd  push r11
000079a3731dddcf  sub rsp, 0xF0
000079a3731dddd6  vmovaps [rsp], xmm0
000079a3731ddddb  vmovaps [rsp+0x10], xmm2
000079a3731ddde1  vmovaps [rsp+0x20], xmm3
000079a3731ddde7  vmovaps [rsp+0x30], xmm4
000079a3731ddded  vmovaps [rsp+0x40], xmm5
000079a3731dddf3  vmovaps [rsp+0x50], xmm6
000079a3731dddf9  vmovaps [rsp+0x60], xmm7
000079a3731dddff  vmovaps [rsp+0x70], xmm8
000079a3731dde05  vmovaps [rsp+0x80], xmm9
000079a3731dde0e  vmovaps [rsp+0x90], xmm10
000079a3731dde17  vmovaps [rsp+0xA0], xmm11
000079a3731dde20  vmovaps [rsp+0xB0], xmm12
000079a3731dde29  vmovaps [rsp+0xC0], xmm13
000079a3731dde32  vmovaps [rsp+0xD0], xmm14
000079a3731dde3b  vmovaps [rsp+0xE0], xmm15
000079a3731dde44  sub rsp, 0x30
000079a3731dde48  movaps [rsp], xmm1
000079a3731dde4c  movaps [rsp+0x10], xmm5
000079a3731dde51  movaps [rsp+0x20], xmm7
000079a3731dde56  lea rdi, [rsp]
000079a3731dde5a  mov esi, 0x00
000079a3731dde5f  mov rax, 0x64F127B95530
000079a3731dde69  call rax
000079a3731dde6b  movaps xmm1, [rsp]
000079a3731dde6f  add rsp, 0x30
000079a3731dde73  vmovaps xmm0, [rsp]
000079a3731dde78  vmovaps xmm2, [rsp+0x10]
000079a3731dde7e  vmovaps xmm3, [rsp+0x20]
000079a3731dde84  vmovaps xmm4, [rsp+0x30]
000079a3731dde8a  vmovaps xmm5, [rsp+0x40]
000079a3731dde90  vmovaps xmm6, [rsp+0x50]
000079a3731dde96  vmovaps xmm7, [rsp+0x60]
000079a3731dde9c  vmovaps xmm8, [rsp+0x70]
000079a3731ddea2  vmovaps xmm9, [rsp+0x80]
000079a3731ddeab  vmovaps xmm10, [rsp+0x90]
000079a3731ddeb4  vmovaps xmm11, [rsp+0xA0]
000079a3731ddebd  vmovaps xmm12, [rsp+0xB0]
000079a3731ddec6  vmovaps xmm13, [rsp+0xC0]
000079a3731ddecf  vmovaps xmm14, [rsp+0xD0]
000079a3731dded8  vmovaps xmm15, [rsp+0xE0]
000079a3731ddee1  add rsp, 0xF0
000079a3731ddee8  pop r11
000079a3731ddeea  pop r10
000079a3731ddeec  pop r9
000079a3731ddeee  pop r8
000079a3731ddef0  pop rsi
000079a3731ddef1  pop rdi
000079a3731ddef2  pop rdx
000079a3731ddef3  pop rcx
000079a3731ddef4  pop rax
000079a3731ddef5  add rsp, 0x08
000079a3731ddef9  jmp 0x000079A3731DC030
000079a3731ddefe  sub rsp, 0x08
000079a3731ddf02  push rax
000079a3731ddf03  push rcx
000079a3731ddf04  push rdx
000079a3731ddf05  push rdi
000079a3731ddf06  push rsi
000079a3731ddf07  push r8
000079a3731ddf09  push r9
000079a3731ddf0b  push r10
000079a3731ddf0d  push r11
000079a3731ddf0f  sub rsp, 0xF0
000079a3731ddf16  vmovaps [rsp], xmm0
000079a3731ddf1b  vmovaps [rsp+0x10], xmm1
000079a3731ddf21  vmovaps [rsp+0x20], xmm2
000079a3731ddf27  vmovaps [rsp+0x30], xmm3
000079a3731ddf2d  vmovaps [rsp+0x40], xmm4
000079a3731ddf33  vmovaps [rsp+0x50], xmm5
000079a3731ddf39  vmovaps [rsp+0x60], xmm6
000079a3731ddf3f  vmovaps [rsp+0x70], xmm8
000079a3731ddf45  vmovaps [rsp+0x80], xmm9
000079a3731ddf4e  vmovaps [rsp+0x90], xmm10
000079a3731ddf57  vmovaps [rsp+0xA0], xmm11
000079a3731ddf60  vmovaps [rsp+0xB0], xmm12
000079a3731ddf69  vmovaps [rsp+0xC0], xmm13
000079a3731ddf72  vmovaps [rsp+0xD0], xmm14
000079a3731ddf7b  vmovaps [rsp+0xE0], xmm15
000079a3731ddf84  sub rsp, 0x30
000079a3731ddf88  movaps [rsp], xmm7
000079a3731ddf8c  movaps [rsp+0x10], xmm5
000079a3731ddf91  movaps [rsp+0x20], xmm15
000079a3731ddf97  lea rdi, [rsp]
000079a3731ddf9b  mov esi, 0x00
000079a3731ddfa0  mov rax, 0x64F127B95530
000079a3731ddfaa  call rax
000079a3731ddfac  movaps xmm7, [rsp]
000079a3731ddfb0  add rsp, 0x30
000079a3731ddfb4  vmovaps xmm0, [rsp]
000079a3731ddfb9  vmovaps xmm1, [rsp+0x10]
000079a3731ddfbf  vmovaps xmm2, [rsp+0x20]
000079a3731ddfc5  vmovaps xmm3, [rsp+0x30]
000079a3731ddfcb  vmovaps xmm4, [rsp+0x40]
000079a3731ddfd1  vmovaps xmm5, [rsp+0x50]
000079a3731ddfd7  vmovaps xmm6, [rsp+0x60]
000079a3731ddfdd  vmovaps xmm8, [rsp+0x70]
000079a3731ddfe3  vmovaps xmm9, [rsp+0x80]
000079a3731ddfec  vmovaps xmm10, [rsp+0x90]
000079a3731ddff5  vmovaps xmm11, [rsp+0xA0]
000079a3731ddffe  vmovaps xmm12, [rsp+0xB0]
000079a3731de007  vmovaps xmm13, [rsp+0xC0]
000079a3731de010  vmovaps xmm14, [rsp+0xD0]
000079a3731de019  vmovaps xmm15, [rsp+0xE0]
000079a3731de022  add rsp, 0xF0
000079a3731de029  pop r11
000079a3731de02b  pop r10
000079a3731de02d  pop r9
000079a3731de02f  pop r8
000079a3731de031  pop rsi
000079a3731de032  pop rdi
000079a3731de033  pop rdx
000079a3731de034  pop rcx
000079a3731de035  pop rax
000079a3731de036  add rsp, 0x08
000079a3731de03a  jmp 0x000079A3731DC066
000079a3731de03f  call 0x000079A3730B52F0
000079a3731de044  jmp 0x000079A3731DC073
000079a3731de049  sub rsp, 0x08
000079a3731de04d  push rax
000079a3731de04e  push rcx
000079a3731de04f  push rdx
000079a3731de050  push rdi
000079a3731de051  push rsi
000079a3731de052  push r8
000079a3731de054  push r9
000079a3731de056  push r10
000079a3731de058  push r11
000079a3731de05a  sub rsp, 0xF0
000079a3731de061  vmovaps [rsp], xmm0
000079a3731de066  vmovaps [rsp+0x10], xmm1
000079a3731de06c  vmovaps [rsp+0x20], xmm2
000079a3731de072  vmovaps [rsp+0x30], xmm3
000079a3731de078  vmovaps [rsp+0x40], xmm4
000079a3731de07e  vmovaps [rsp+0x50], xmm5
000079a3731de084  vmovaps [rsp+0x60], xmm6
000079a3731de08a  vmovaps [rsp+0x70], xmm7
000079a3731de090  vmovaps [rsp+0x80], xmm8
000079a3731de099  vmovaps [rsp+0x90], xmm9
000079a3731de0a2  vmovaps [rsp+0xA0], xmm10
000079a3731de0ab  vmovaps [rsp+0xB0], xmm11
000079a3731de0b4  vmovaps [rsp+0xC0], xmm12
000079a3731de0bd  vmovaps [rsp+0xD0], xmm13
000079a3731de0c6  vmovaps [rsp+0xE0], xmm14
000079a3731de0cf  sub rsp, 0x30
000079a3731de0d3  movaps [rsp], xmm15
000079a3731de0d8  movaps [rsp+0x10], xmm5
000079a3731de0dd  movaps [rsp+0x20], xmm3
000079a3731de0e2  lea rdi, [rsp]
000079a3731de0e6  mov esi, 0x00
000079a3731de0eb  mov rax, 0x64F127B95530
000079a3731de0f5  call rax
000079a3731de0f7  movaps xmm15, [rsp]
000079a3731de0fc  add rsp, 0x30
000079a3731de100  vmovaps xmm0, [rsp]
000079a3731de105  vmovaps xmm1, [rsp+0x10]
000079a3731de10b  vmovaps xmm2, [rsp+0x20]
000079a3731de111  vmovaps xmm3, [rsp+0x30]
000079a3731de117  vmovaps xmm4, [rsp+0x40]
000079a3731de11d  vmovaps xmm5, [rsp+0x50]
000079a3731de123  vmovaps xmm6, [rsp+0x60]
000079a3731de129  vmovaps xmm7, [rsp+0x70]
000079a3731de12f  vmovaps xmm8, [rsp+0x80]
000079a3731de138  vmovaps xmm9, [rsp+0x90]
000079a3731de141  vmovaps xmm10, [rsp+0xA0]
000079a3731de14a  vmovaps xmm11, [rsp+0xB0]
000079a3731de153  vmovaps xmm12, [rsp+0xC0]
000079a3731de15c  vmovaps xmm13, [rsp+0xD0]
000079a3731de165  vmovaps xmm14, [rsp+0xE0]
000079a3731de16e  add rsp, 0xF0
000079a3731de175  pop r11
000079a3731de177  pop r10
000079a3731de179  pop r9
000079a3731de17b  pop r8
000079a3731de17d  pop rsi
000079a3731de17e  pop rdi
000079a3731de17f  pop rdx
000079a3731de180  pop rcx
000079a3731de181  pop rax
000079a3731de182  add rsp, 0x08
000079a3731de186  jmp 0x000079A3731DC099
000079a3731de18b  sub rsp, 0x08
000079a3731de18f  push rax
000079a3731de190  push rcx
000079a3731de191  push rdx
000079a3731de192  push rdi
000079a3731de193  push rsi
000079a3731de194  push r8
000079a3731de196  push r9
000079a3731de198  push r10
000079a3731de19a  push r11
000079a3731de19c  sub rsp, 0xF0
000079a3731de1a3  vmovaps [rsp], xmm0
000079a3731de1a8  vmovaps [rsp+0x10], xmm2
000079a3731de1ae  vmovaps [rsp+0x20], xmm3
000079a3731de1b4  vmovaps [rsp+0x30], xmm4
000079a3731de1ba  vmovaps [rsp+0x40], xmm5
000079a3731de1c0  vmovaps [rsp+0x50], xmm6
000079a3731de1c6  vmovaps [rsp+0x60], xmm7
000079a3731de1cc  vmovaps [rsp+0x70], xmm8
000079a3731de1d2  vmovaps [rsp+0x80], xmm9
000079a3731de1db  vmovaps [rsp+0x90], xmm10
000079a3731de1e4  vmovaps [rsp+0xA0], xmm11
000079a3731de1ed  vmovaps [rsp+0xB0], xmm12
000079a3731de1f6  vmovaps [rsp+0xC0], xmm13
000079a3731de1ff  vmovaps [rsp+0xD0], xmm14
000079a3731de208  vmovaps [rsp+0xE0], xmm15
000079a3731de211  sub rsp, 0x30
000079a3731de215  movaps [rsp], xmm1
000079a3731de219  movaps [rsp+0x10], xmm5
000079a3731de21e  movaps [rsp+0x20], xmm4
000079a3731de223  lea rdi, [rsp]
000079a3731de227  mov esi, 0x00
000079a3731de22c  mov rax, 0x64F127B95530
000079a3731de236  call rax
000079a3731de238  movaps xmm1, [rsp]
000079a3731de23c  add rsp, 0x30
000079a3731de240  vmovaps xmm0, [rsp]
000079a3731de245  vmovaps xmm2, [rsp+0x10]
000079a3731de24b  vmovaps xmm3, [rsp+0x20]
000079a3731de251  vmovaps xmm4, [rsp+0x30]
000079a3731de257  vmovaps xmm5, [rsp+0x40]
000079a3731de25d  vmovaps xmm6, [rsp+0x50]
000079a3731de263  vmovaps xmm7, [rsp+0x60]
000079a3731de269  vmovaps xmm8, [rsp+0x70]
000079a3731de26f  vmovaps xmm9, [rsp+0x80]
000079a3731de278  vmovaps xmm10, [rsp+0x90]
000079a3731de281  vmovaps xmm11, [rsp+0xA0]
000079a3731de28a  vmovaps xmm12, [rsp+0xB0]
000079a3731de293  vmovaps xmm13, [rsp+0xC0]
000079a3731de29c  vmovaps xmm14, [rsp+0xD0]
000079a3731de2a5  vmovaps xmm15, [rsp+0xE0]
000079a3731de2ae  add rsp, 0xF0
000079a3731de2b5  pop r11
000079a3731de2b7  pop r10
000079a3731de2b9  pop r9
000079a3731de2bb  pop r8
000079a3731de2bd  pop rsi
000079a3731de2be  pop rdi
000079a3731de2bf  pop rdx
000079a3731de2c0  pop rcx
000079a3731de2c1  pop rax
000079a3731de2c2  add rsp, 0x08
000079a3731de2c6  jmp 0x000079A3731DC0B9
000079a3731de2cb  sub rsp, 0x08
000079a3731de2cf  push rax
000079a3731de2d0  push rcx
000079a3731de2d1  push rdx
000079a3731de2d2  push rdi
000079a3731de2d3  push rsi
000079a3731de2d4  push r8
000079a3731de2d6  push r9
000079a3731de2d8  push r10
000079a3731de2da  push r11
000079a3731de2dc  sub rsp, 0xF0
000079a3731de2e3  vmovaps [rsp], xmm0
000079a3731de2e8  vmovaps [rsp+0x10], xmm1
000079a3731de2ee  vmovaps [rsp+0x20], xmm2
000079a3731de2f4  vmovaps [rsp+0x30], xmm3
000079a3731de2fa  vmovaps [rsp+0x40], xmm5
000079a3731de300  vmovaps [rsp+0x50], xmm6
000079a3731de306  vmovaps [rsp+0x60], xmm7
000079a3731de30c  vmovaps [rsp+0x70], xmm8
000079a3731de312  vmovaps [rsp+0x80], xmm9
000079a3731de31b  vmovaps [rsp+0x90], xmm10
000079a3731de324  vmovaps [rsp+0xA0], xmm11
000079a3731de32d  vmovaps [rsp+0xB0], xmm12
000079a3731de336  vmovaps [rsp+0xC0], xmm13
000079a3731de33f  vmovaps [rsp+0xD0], xmm14
000079a3731de348  vmovaps [rsp+0xE0], xmm15
000079a3731de351  sub rsp, 0x30
000079a3731de355  movaps [rsp], xmm4
000079a3731de359  movaps [rsp+0x10], xmm3
000079a3731de35e  movaps [rsp+0x20], xmm5
000079a3731de363  lea rdi, [rsp]
000079a3731de367  mov esi, 0x00
000079a3731de36c  mov rax, 0x64F127B95530
000079a3731de376  call rax
000079a3731de378  movaps xmm4, [rsp]
000079a3731de37c  add rsp, 0x30
000079a3731de380  vmovaps xmm0, [rsp]
000079a3731de385  vmovaps xmm1, [rsp+0x10]
000079a3731de38b  vmovaps xmm2, [rsp+0x20]
000079a3731de391  vmovaps xmm3, [rsp+0x30]
000079a3731de397  vmovaps xmm5, [rsp+0x40]
000079a3731de39d  vmovaps xmm6, [rsp+0x50]
000079a3731de3a3  vmovaps xmm7, [rsp+0x60]
000079a3731de3a9  vmovaps xmm8, [rsp+0x70]
000079a3731de3af  vmovaps xmm9, [rsp+0x80]
000079a3731de3b8  vmovaps xmm10, [rsp+0x90]
000079a3731de3c1  vmovaps xmm11, [rsp+0xA0]
000079a3731de3ca  vmovaps xmm12, [rsp+0xB0]
000079a3731de3d3  vmovaps xmm13, [rsp+0xC0]
000079a3731de3dc  vmovaps xmm14, [rsp+0xD0]
000079a3731de3e5  vmovaps xmm15, [rsp+0xE0]
000079a3731de3ee  add rsp, 0xF0
000079a3731de3f5  pop r11
000079a3731de3f7  pop r10
000079a3731de3f9  pop r9
000079a3731de3fb  pop r8
000079a3731de3fd  pop rsi
000079a3731de3fe  pop rdi
000079a3731de3ff  pop rdx
000079a3731de400  pop rcx
000079a3731de401  pop rax
000079a3731de402  add rsp, 0x08
000079a3731de406  jmp 0x000079A3731DC107
000079a3731de40b  call 0x000079A3730B52F0
000079a3731de410  jmp 0x000079A3731DC114
000079a3731de415  sub rsp, 0x08
000079a3731de419  push rax
000079a3731de41a  push rcx
000079a3731de41b  push rdx
000079a3731de41c  push rdi
000079a3731de41d  push rsi
000079a3731de41e  push r8
000079a3731de420  push r9
000079a3731de422  push r10
000079a3731de424  push r11
000079a3731de426  sub rsp, 0xF0
000079a3731de42d  vmovaps [rsp], xmm0
000079a3731de432  vmovaps [rsp+0x10], xmm1
000079a3731de438  vmovaps [rsp+0x20], xmm2
000079a3731de43e  vmovaps [rsp+0x30], xmm3
000079a3731de444  vmovaps [rsp+0x40], xmm4
000079a3731de44a  vmovaps [rsp+0x50], xmm6
000079a3731de450  vmovaps [rsp+0x60], xmm7
000079a3731de456  vmovaps [rsp+0x70], xmm8
000079a3731de45c  vmovaps [rsp+0x80], xmm9
000079a3731de465  vmovaps [rsp+0x90], xmm10
000079a3731de46e  vmovaps [rsp+0xA0], xmm11
000079a3731de477  vmovaps [rsp+0xB0], xmm12
000079a3731de480  vmovaps [rsp+0xC0], xmm13
000079a3731de489  vmovaps [rsp+0xD0], xmm14
000079a3731de492  vmovaps [rsp+0xE0], xmm15
000079a3731de49b  sub rsp, 0x30
000079a3731de49f  movaps [rsp], xmm5
000079a3731de4a3  movaps [rsp+0x10], xmm6
000079a3731de4a8  movaps [rsp+0x20], xmm3
000079a3731de4ad  lea rdi, [rsp]
000079a3731de4b1  mov esi, 0x00
000079a3731de4b6  mov rax, 0x64F127B95530
000079a3731de4c0  call rax
000079a3731de4c2  movaps xmm5, [rsp]
000079a3731de4c6  add rsp, 0x30
000079a3731de4ca  vmovaps xmm0, [rsp]
000079a3731de4cf  vmovaps xmm1, [rsp+0x10]
000079a3731de4d5  vmovaps xmm2, [rsp+0x20]
000079a3731de4db  vmovaps xmm3, [rsp+0x30]
000079a3731de4e1  vmovaps xmm4, [rsp+0x40]
000079a3731de4e7  vmovaps xmm6, [rsp+0x50]
000079a3731de4ed  vmovaps xmm7, [rsp+0x60]
000079a3731de4f3  vmovaps xmm8, [rsp+0x70]
000079a3731de4f9  vmovaps xmm9, [rsp+0x80]
000079a3731de502  vmovaps xmm10, [rsp+0x90]
000079a3731de50b  vmovaps xmm11, [rsp+0xA0]
000079a3731de514  vmovaps xmm12, [rsp+0xB0]
000079a3731de51d  vmovaps xmm13, [rsp+0xC0]
000079a3731de526  vmovaps xmm14, [rsp+0xD0]
000079a3731de52f  vmovaps xmm15, [rsp+0xE0]
000079a3731de538  add rsp, 0xF0
000079a3731de53f  pop r11
000079a3731de541  pop r10
000079a3731de543  pop r9
000079a3731de545  pop r8
000079a3731de547  pop rsi
000079a3731de548  pop rdi
000079a3731de549  pop rdx
000079a3731de54a  pop rcx
000079a3731de54b  pop rax
000079a3731de54c  add rsp, 0x08
000079a3731de550  jmp 0x000079A3731DC13A
000079a3731de555  sub rsp, 0x08
000079a3731de559  push rax
000079a3731de55a  push rcx
000079a3731de55b  push rdx
000079a3731de55c  push rdi
000079a3731de55d  push rsi
000079a3731de55e  push r8
000079a3731de560  push r9
000079a3731de562  push r10
000079a3731de564  push r11
000079a3731de566  sub rsp, 0xF0
000079a3731de56d  vmovaps [rsp], xmm0
000079a3731de572  vmovaps [rsp+0x10], xmm1
000079a3731de578  vmovaps [rsp+0x20], xmm2
000079a3731de57e  vmovaps [rsp+0x30], xmm3
000079a3731de584  vmovaps [rsp+0x40], xmm4
000079a3731de58a  vmovaps [rsp+0x50], xmm5
000079a3731de590  vmovaps [rsp+0x60], xmm7
000079a3731de596  vmovaps [rsp+0x70], xmm8
000079a3731de59c  vmovaps [rsp+0x80], xmm9
000079a3731de5a5  vmovaps [rsp+0x90], xmm10
000079a3731de5ae  vmovaps [rsp+0xA0], xmm11
000079a3731de5b7  vmovaps [rsp+0xB0], xmm12
000079a3731de5c0  vmovaps [rsp+0xC0], xmm13
000079a3731de5c9  vmovaps [rsp+0xD0], xmm14
000079a3731de5d2  vmovaps [rsp+0xE0], xmm15
000079a3731de5db  sub rsp, 0x30
000079a3731de5df  movaps [rsp], xmm6
000079a3731de5e3  movaps [rsp+0x10], xmm9
000079a3731de5e9  movaps [rsp+0x20], xmm1
000079a3731de5ee  lea rdi, [rsp]
000079a3731de5f2  mov esi, 0x00
000079a3731de5f7  mov rax, 0x64F127B95530
000079a3731de601  call rax
000079a3731de603  movaps xmm6, [rsp]
000079a3731de607  add rsp, 0x30
000079a3731de60b  vmovaps xmm0, [rsp]
000079a3731de610  vmovaps xmm1, [rsp+0x10]
000079a3731de616  vmovaps xmm2, [rsp+0x20]
000079a3731de61c  vmovaps xmm3, [rsp+0x30]
000079a3731de622  vmovaps xmm4, [rsp+0x40]
000079a3731de628  vmovaps xmm5, [rsp+0x50]
000079a3731de62e  vmovaps xmm7, [rsp+0x60]
000079a3731de634  vmovaps xmm8, [rsp+0x70]
000079a3731de63a  vmovaps xmm9, [rsp+0x80]
000079a3731de643  vmovaps xmm10, [rsp+0x90]
000079a3731de64c  vmovaps xmm11, [rsp+0xA0]
000079a3731de655  vmovaps xmm12, [rsp+0xB0]
000079a3731de65e  vmovaps xmm13, [rsp+0xC0]
000079a3731de667  vmovaps xmm14, [rsp+0xD0]
000079a3731de670  vmovaps xmm15, [rsp+0xE0]
000079a3731de679  add rsp, 0xF0
000079a3731de680  pop r11
000079a3731de682  pop r10
000079a3731de684  pop r9
000079a3731de686  pop r8
000079a3731de688  pop rsi
000079a3731de689  pop rdi
000079a3731de68a  pop rdx
000079a3731de68b  pop rcx
000079a3731de68c  pop rax
000079a3731de68d  add rsp, 0x08
000079a3731de691  jmp 0x000079A3731DC15E
000079a3731de696  sub rsp, 0x08
000079a3731de69a  push rax
000079a3731de69b  push rcx
000079a3731de69c  push rdx
000079a3731de69d  push rdi
000079a3731de69e  push rsi
000079a3731de69f  push r8
000079a3731de6a1  push r9
000079a3731de6a3  push r10
000079a3731de6a5  push r11
000079a3731de6a7  sub rsp, 0xF0
000079a3731de6ae  vmovaps [rsp], xmm0
000079a3731de6b3  vmovaps [rsp+0x10], xmm1
000079a3731de6b9  vmovaps [rsp+0x20], xmm2
000079a3731de6bf  vmovaps [rsp+0x30], xmm3
000079a3731de6c5  vmovaps [rsp+0x40], xmm4
000079a3731de6cb  vmovaps [rsp+0x50], xmm5
000079a3731de6d1  vmovaps [rsp+0x60], xmm6
000079a3731de6d7  vmovaps [rsp+0x70], xmm7
000079a3731de6dd  vmovaps [rsp+0x80], xmm8
000079a3731de6e6  vmovaps [rsp+0x90], xmm10
000079a3731de6ef  vmovaps [rsp+0xA0], xmm11
000079a3731de6f8  vmovaps [rsp+0xB0], xmm12
000079a3731de701  vmovaps [rsp+0xC0], xmm13
000079a3731de70a  vmovaps [rsp+0xD0], xmm14
000079a3731de713  vmovaps [rsp+0xE0], xmm15
000079a3731de71c  sub rsp, 0x30
000079a3731de720  movaps [rsp], xmm9
000079a3731de725  movaps [rsp+0x10], xmm3
000079a3731de72a  movaps [rsp+0x20], xmm1
000079a3731de72f  lea rdi, [rsp]
000079a3731de733  mov esi, 0x00
000079a3731de738  mov rax, 0x64F127B95530
000079a3731de742  call rax
000079a3731de744  movaps xmm9, [rsp]
000079a3731de749  add rsp, 0x30
000079a3731de74d  vmovaps xmm0, [rsp]
000079a3731de752  vmovaps xmm1, [rsp+0x10]
000079a3731de758  vmovaps xmm2, [rsp+0x20]
000079a3731de75e  vmovaps xmm3, [rsp+0x30]
000079a3731de764  vmovaps xmm4, [rsp+0x40]
000079a3731de76a  vmovaps xmm5, [rsp+0x50]
000079a3731de770  vmovaps xmm6, [rsp+0x60]
000079a3731de776  vmovaps xmm7, [rsp+0x70]
000079a3731de77c  vmovaps xmm8, [rsp+0x80]
000079a3731de785  vmovaps xmm10, [rsp+0x90]
000079a3731de78e  vmovaps xmm11, [rsp+0xA0]
000079a3731de797  vmovaps xmm12, [rsp+0xB0]
000079a3731de7a0  vmovaps xmm13, [rsp+0xC0]
000079a3731de7a9  vmovaps xmm14, [rsp+0xD0]
000079a3731de7b2  vmovaps xmm15, [rsp+0xE0]
000079a3731de7bb  add rsp, 0xF0
000079a3731de7c2  pop r11
000079a3731de7c4  pop r10
000079a3731de7c6  pop r9
000079a3731de7c8  pop r8
000079a3731de7ca  pop rsi
000079a3731de7cb  pop rdi
000079a3731de7cc  pop rdx
000079a3731de7cd  pop rcx
000079a3731de7ce  pop rax
000079a3731de7cf  add rsp, 0x08
000079a3731de7d3  jmp 0x000079A3731DC1AA
000079a3731de7d8  call 0x000079A3730B52F0
000079a3731de7dd  jmp 0x000079A3731DC1B7
000079a3731de7e2  sub rsp, 0x08
000079a3731de7e6  push rax
000079a3731de7e7  push rcx
000079a3731de7e8  push rdx
000079a3731de7e9  push rdi
000079a3731de7ea  push rsi
000079a3731de7eb  push r8
000079a3731de7ed  push r9
000079a3731de7ef  push r10
000079a3731de7f1  push r11
000079a3731de7f3  sub rsp, 0xF0
000079a3731de7fa  vmovaps [rsp], xmm0
000079a3731de7ff  vmovaps [rsp+0x10], xmm1
000079a3731de805  vmovaps [rsp+0x20], xmm2
000079a3731de80b  vmovaps [rsp+0x30], xmm3
000079a3731de811  vmovaps [rsp+0x40], xmm4
000079a3731de817  vmovaps [rsp+0x50], xmm5
000079a3731de81d  vmovaps [rsp+0x60], xmm6
000079a3731de823  vmovaps [rsp+0x70], xmm7
000079a3731de829  vmovaps [rsp+0x80], xmm8
000079a3731de832  vmovaps [rsp+0x90], xmm9
000079a3731de83b  vmovaps [rsp+0xA0], xmm10
000079a3731de844  vmovaps [rsp+0xB0], xmm11
000079a3731de84d  vmovaps [rsp+0xC0], xmm12
000079a3731de856  vmovaps [rsp+0xD0], xmm13
000079a3731de85f  vmovaps [rsp+0xE0], xmm14
000079a3731de868  sub rsp, 0x30
000079a3731de86c  movaps [rsp], xmm15
000079a3731de871  movaps [rsp+0x10], xmm3
000079a3731de876  movaps [rsp+0x20], xmm7
000079a3731de87b  lea rdi, [rsp]
000079a3731de87f  mov esi, 0x00
000079a3731de884  mov rax, 0x64F127B95530
000079a3731de88e  call rax
000079a3731de890  movaps xmm15, [rsp]
000079a3731de895  add rsp, 0x30
000079a3731de899  vmovaps xmm0, [rsp]
000079a3731de89e  vmovaps xmm1, [rsp+0x10]
000079a3731de8a4  vmovaps xmm2, [rsp+0x20]
000079a3731de8aa  vmovaps xmm3, [rsp+0x30]
000079a3731de8b0  vmovaps xmm4, [rsp+0x40]
000079a3731de8b6  vmovaps xmm5, [rsp+0x50]
000079a3731de8bc  vmovaps xmm6, [rsp+0x60]
000079a3731de8c2  vmovaps xmm7, [rsp+0x70]
000079a3731de8c8  vmovaps xmm8, [rsp+0x80]
000079a3731de8d1  vmovaps xmm9, [rsp+0x90]
000079a3731de8da  vmovaps xmm10, [rsp+0xA0]
000079a3731de8e3  vmovaps xmm11, [rsp+0xB0]
000079a3731de8ec  vmovaps xmm12, [rsp+0xC0]
000079a3731de8f5  vmovaps xmm13, [rsp+0xD0]
000079a3731de8fe  vmovaps xmm14, [rsp+0xE0]
000079a3731de907  add rsp, 0xF0
000079a3731de90e  pop r11
000079a3731de910  pop r10
000079a3731de912  pop r9
000079a3731de914  pop r8
000079a3731de916  pop rsi
000079a3731de917  pop rdi
000079a3731de918  pop rdx
000079a3731de919  pop rcx
000079a3731de91a  pop rax
000079a3731de91b  add rsp, 0x08
000079a3731de91f  jmp 0x000079A3731DC1E3
000079a3731de924  sub rsp, 0x08
000079a3731de928  push rax
000079a3731de929  push rcx
000079a3731de92a  push rdx
000079a3731de92b  push rdi
000079a3731de92c  push rsi
000079a3731de92d  push r8
000079a3731de92f  push r9
000079a3731de931  push r10
000079a3731de933  push r11
000079a3731de935  sub rsp, 0xF0
000079a3731de93c  vmovaps [rsp], xmm0
000079a3731de941  vmovaps [rsp+0x10], xmm1
000079a3731de947  vmovaps [rsp+0x20], xmm2
000079a3731de94d  vmovaps [rsp+0x30], xmm4
000079a3731de953  vmovaps [rsp+0x40], xmm5
000079a3731de959  vmovaps [rsp+0x50], xmm6
000079a3731de95f  vmovaps [rsp+0x60], xmm7
000079a3731de965  vmovaps [rsp+0x70], xmm8
000079a3731de96b  vmovaps [rsp+0x80], xmm9
000079a3731de974  vmovaps [rsp+0x90], xmm10
000079a3731de97d  vmovaps [rsp+0xA0], xmm11
000079a3731de986  vmovaps [rsp+0xB0], xmm12
000079a3731de98f  vmovaps [rsp+0xC0], xmm13
000079a3731de998  vmovaps [rsp+0xD0], xmm14
000079a3731de9a1  vmovaps [rsp+0xE0], xmm15
000079a3731de9aa  sub rsp, 0x30
000079a3731de9ae  movaps [rsp], xmm3
000079a3731de9b2  movaps [rsp+0x10], xmm1
000079a3731de9b7  movaps [rsp+0x20], xmm15
000079a3731de9bd  lea rdi, [rsp]
000079a3731de9c1  mov esi, 0x00
000079a3731de9c6  mov rax, 0x64F127B95530
000079a3731de9d0  call rax
000079a3731de9d2  movaps xmm3, [rsp]
000079a3731de9d6  add rsp, 0x30
000079a3731de9da  vmovaps xmm0, [rsp]
000079a3731de9df  vmovaps xmm1, [rsp+0x10]
000079a3731de9e5  vmovaps xmm2, [rsp+0x20]
000079a3731de9eb  vmovaps xmm4, [rsp+0x30]
000079a3731de9f1  vmovaps xmm5, [rsp+0x40]
000079a3731de9f7  vmovaps xmm6, [rsp+0x50]
000079a3731de9fd  vmovaps xmm7, [rsp+0x60]
000079a3731dea03  vmovaps xmm8, [rsp+0x70]
000079a3731dea09  vmovaps xmm9, [rsp+0x80]
000079a3731dea12  vmovaps xmm10, [rsp+0x90]
000079a3731dea1b  vmovaps xmm11, [rsp+0xA0]
000079a3731dea24  vmovaps xmm12, [rsp+0xB0]
000079a3731dea2d  vmovaps xmm13, [rsp+0xC0]
000079a3731dea36  vmovaps xmm14, [rsp+0xD0]
000079a3731dea3f  vmovaps xmm15, [rsp+0xE0]
000079a3731dea48  add rsp, 0xF0
000079a3731dea4f  pop r11
000079a3731dea51  pop r10
000079a3731dea53  pop r9
000079a3731dea55  pop r8
000079a3731dea57  pop rsi
000079a3731dea58  pop rdi
000079a3731dea59  pop rdx
000079a3731dea5a  pop rcx
000079a3731dea5b  pop rax
000079a3731dea5c  add rsp, 0x08
000079a3731dea60  jmp 0x000079A3731DC272
000079a3731dea65  call 0x000079A3730B52F0
000079a3731dea6a  jmp 0x000079A3731DC27C
000079a3731dea6f  sub rsp, 0x08
000079a3731dea73  push rax
000079a3731dea74  push rcx
000079a3731dea75  push rdx
000079a3731dea76  push rdi
000079a3731dea77  push rsi
000079a3731dea78  push r8
000079a3731dea7a  push r9
000079a3731dea7c  push r10
000079a3731dea7e  push r11
000079a3731dea80  sub rsp, 0xF0
000079a3731dea87  vmovaps [rsp], xmm0
000079a3731dea8c  vmovaps [rsp+0x10], xmm1
000079a3731dea92  vmovaps [rsp+0x20], xmm2
000079a3731dea98  vmovaps [rsp+0x30], xmm3
000079a3731dea9e  vmovaps [rsp+0x40], xmm4
000079a3731deaa4  vmovaps [rsp+0x50], xmm5
000079a3731deaaa  vmovaps [rsp+0x60], xmm6
000079a3731deab0  vmovaps [rsp+0x70], xmm7
000079a3731deab6  vmovaps [rsp+0x80], xmm8
000079a3731deabf  vmovaps [rsp+0x90], xmm9
000079a3731deac8  vmovaps [rsp+0xA0], xmm10
000079a3731dead1  vmovaps [rsp+0xB0], xmm11
000079a3731deada  vmovaps [rsp+0xC0], xmm12
000079a3731deae3  vmovaps [rsp+0xD0], xmm13
000079a3731deaec  vmovaps [rsp+0xE0], xmm14
000079a3731deaf5  sub rsp, 0x30
000079a3731deaf9  movaps [rsp], xmm15
000079a3731deafe  movaps [rsp+0x10], xmm14
000079a3731deb04  movaps [rsp+0x20], xmm4
000079a3731deb09  lea rdi, [rsp]
000079a3731deb0d  mov esi, 0x00
000079a3731deb12  mov rax, 0x64F127B95530
000079a3731deb1c  call rax
000079a3731deb1e  movaps xmm15, [rsp]
000079a3731deb23  add rsp, 0x30
000079a3731deb27  vmovaps xmm0, [rsp]
000079a3731deb2c  vmovaps xmm1, [rsp+0x10]
000079a3731deb32  vmovaps xmm2, [rsp+0x20]
000079a3731deb38  vmovaps xmm3, [rsp+0x30]
000079a3731deb3e  vmovaps xmm4, [rsp+0x40]
000079a3731deb44  vmovaps xmm5, [rsp+0x50]
000079a3731deb4a  vmovaps xmm6, [rsp+0x60]
000079a3731deb50  vmovaps xmm7, [rsp+0x70]
000079a3731deb56  vmovaps xmm8, [rsp+0x80]
000079a3731deb5f  vmovaps xmm9, [rsp+0x90]
000079a3731deb68  vmovaps xmm10, [rsp+0xA0]
000079a3731deb71  vmovaps xmm11, [rsp+0xB0]
000079a3731deb7a  vmovaps xmm12, [rsp+0xC0]
000079a3731deb83  vmovaps xmm13, [rsp+0xD0]
000079a3731deb8c  vmovaps xmm14, [rsp+0xE0]
000079a3731deb95  add rsp, 0xF0
000079a3731deb9c  pop r11
000079a3731deb9e  pop r10
000079a3731deba0  pop r9
000079a3731deba2  pop r8
000079a3731deba4  pop rsi
000079a3731deba5  pop rdi
000079a3731deba6  pop rdx
000079a3731deba7  pop rcx
000079a3731deba8  pop rax
000079a3731deba9  add rsp, 0x08
000079a3731debad  jmp 0x000079A3731DC2AA
000079a3731debb2  sub rsp, 0x08
000079a3731debb6  push rax
000079a3731debb7  push rcx
000079a3731debb8  push rdx
000079a3731debb9  push rdi
000079a3731debba  push rsi
000079a3731debbb  push r8
000079a3731debbd  push r9
000079a3731debbf  push r10
000079a3731debc1  push r11
000079a3731debc3  sub rsp, 0xF0
000079a3731debca  vmovaps [rsp], xmm0
000079a3731debcf  vmovaps [rsp+0x10], xmm1
000079a3731debd5  vmovaps [rsp+0x20], xmm2
000079a3731debdb  vmovaps [rsp+0x30], xmm3
000079a3731debe1  vmovaps [rsp+0x40], xmm4
000079a3731debe7  vmovaps [rsp+0x50], xmm5
000079a3731debed  vmovaps [rsp+0x60], xmm6
000079a3731debf3  vmovaps [rsp+0x70], xmm7
000079a3731debf9  vmovaps [rsp+0x80], xmm8
000079a3731dec02  vmovaps [rsp+0x90], xmm9
000079a3731dec0b  vmovaps [rsp+0xA0], xmm10
000079a3731dec14  vmovaps [rsp+0xB0], xmm11
000079a3731dec1d  vmovaps [rsp+0xC0], xmm12
000079a3731dec26  vmovaps [rsp+0xD0], xmm13
000079a3731dec2f  vmovaps [rsp+0xE0], xmm15
000079a3731dec38  sub rsp, 0x30
000079a3731dec3c  movaps [rsp], xmm14
000079a3731dec41  movaps [rsp+0x10], xmm2
000079a3731dec46  movaps [rsp+0x20], xmm1
000079a3731dec4b  lea rdi, [rsp]
000079a3731dec4f  mov esi, 0x00
000079a3731dec54  mov rax, 0x64F127B95530
000079a3731dec5e  call rax
000079a3731dec60  movaps xmm14, [rsp]
000079a3731dec65  add rsp, 0x30
000079a3731dec69  vmovaps xmm0, [rsp]
000079a3731dec6e  vmovaps xmm1, [rsp+0x10]
000079a3731dec74  vmovaps xmm2, [rsp+0x20]
000079a3731dec7a  vmovaps xmm3, [rsp+0x30]
000079a3731dec80  vmovaps xmm4, [rsp+0x40]
000079a3731dec86  vmovaps xmm5, [rsp+0x50]
000079a3731dec8c  vmovaps xmm6, [rsp+0x60]
000079a3731dec92  vmovaps xmm7, [rsp+0x70]
000079a3731dec98  vmovaps xmm8, [rsp+0x80]
000079a3731deca1  vmovaps xmm9, [rsp+0x90]
000079a3731decaa  vmovaps xmm10, [rsp+0xA0]
000079a3731decb3  vmovaps xmm11, [rsp+0xB0]
000079a3731decbc  vmovaps xmm12, [rsp+0xC0]
000079a3731decc5  vmovaps xmm13, [rsp+0xD0]
000079a3731decce  vmovaps xmm15, [rsp+0xE0]
000079a3731decd7  add rsp, 0xF0
000079a3731decde  pop r11
000079a3731dece0  pop r10
000079a3731dece2  pop r9
000079a3731dece4  pop r8
000079a3731dece6  pop rsi
000079a3731dece7  pop rdi
000079a3731dece8  pop rdx
000079a3731dece9  pop rcx
000079a3731decea  pop rax
000079a3731deceb  add rsp, 0x08
000079a3731decef  jmp 0x000079A3731DC2D0
000079a3731decf4  sub rsp, 0x08
000079a3731decf8  push rax
000079a3731decf9  push rcx
000079a3731decfa  push rdx
000079a3731decfb  push rdi
000079a3731decfc  push rsi
000079a3731decfd  push r8
000079a3731decff  push r9
000079a3731ded01  push r10
000079a3731ded03  push r11
000079a3731ded05  sub rsp, 0xF0
000079a3731ded0c  vmovaps [rsp], xmm0
000079a3731ded11  vmovaps [rsp+0x10], xmm2
000079a3731ded17  vmovaps [rsp+0x20], xmm3
000079a3731ded1d  vmovaps [rsp+0x30], xmm4
000079a3731ded23  vmovaps [rsp+0x40], xmm5
000079a3731ded29  vmovaps [rsp+0x50], xmm6
000079a3731ded2f  vmovaps [rsp+0x60], xmm7
000079a3731ded35  vmovaps [rsp+0x70], xmm8
000079a3731ded3b  vmovaps [rsp+0x80], xmm9
000079a3731ded44  vmovaps [rsp+0x90], xmm10
000079a3731ded4d  vmovaps [rsp+0xA0], xmm11
000079a3731ded56  vmovaps [rsp+0xB0], xmm12
000079a3731ded5f  vmovaps [rsp+0xC0], xmm13
000079a3731ded68  vmovaps [rsp+0xD0], xmm14
000079a3731ded71  vmovaps [rsp+0xE0], xmm15
000079a3731ded7a  sub rsp, 0x30
000079a3731ded7e  movaps [rsp], xmm1
000079a3731ded82  movaps [rsp+0x10], xmm4
000079a3731ded87  movaps [rsp+0x20], xmm9
000079a3731ded8d  lea rdi, [rsp]
000079a3731ded91  mov esi, 0x00
000079a3731ded96  mov rax, 0x64F127B95530
000079a3731deda0  call rax
000079a3731deda2  movaps xmm1, [rsp]
000079a3731deda6  add rsp, 0x30
000079a3731dedaa  vmovaps xmm0, [rsp]
000079a3731dedaf  vmovaps xmm2, [rsp+0x10]
000079a3731dedb5  vmovaps xmm3, [rsp+0x20]
000079a3731dedbb  vmovaps xmm4, [rsp+0x30]
000079a3731dedc1  vmovaps xmm5, [rsp+0x40]
000079a3731dedc7  vmovaps xmm6, [rsp+0x50]
000079a3731dedcd  vmovaps xmm7, [rsp+0x60]
000079a3731dedd3  vmovaps xmm8, [rsp+0x70]
000079a3731dedd9  vmovaps xmm9, [rsp+0x80]
000079a3731dede2  vmovaps xmm10, [rsp+0x90]
000079a3731dedeb  vmovaps xmm11, [rsp+0xA0]
000079a3731dedf4  vmovaps xmm12, [rsp+0xB0]
000079a3731dedfd  vmovaps xmm13, [rsp+0xC0]
000079a3731dee06  vmovaps xmm14, [rsp+0xD0]
000079a3731dee0f  vmovaps xmm15, [rsp+0xE0]
000079a3731dee18  add rsp, 0xF0
000079a3731dee1f  pop r11
000079a3731dee21  pop r10
000079a3731dee23  pop r9
000079a3731dee25  pop r8
000079a3731dee27  pop rsi
000079a3731dee28  pop rdi
000079a3731dee29  pop rdx
000079a3731dee2a  pop rcx
000079a3731dee2b  pop rax
000079a3731dee2c  add rsp, 0x08
000079a3731dee30  jmp 0x000079A3731DC2EE
000079a3731dee35  sub rsp, 0x08
000079a3731dee39  push rax
000079a3731dee3a  push rcx
000079a3731dee3b  push rdx
000079a3731dee3c  push rdi
000079a3731dee3d  push rsi
000079a3731dee3e  push r8
000079a3731dee40  push r9
000079a3731dee42  push r10
000079a3731dee44  push r11
000079a3731dee46  sub rsp, 0xF0
000079a3731dee4d  vmovaps [rsp], xmm0
000079a3731dee52  vmovaps [rsp+0x10], xmm1
000079a3731dee58  vmovaps [rsp+0x20], xmm2
000079a3731dee5e  vmovaps [rsp+0x30], xmm3
000079a3731dee64  vmovaps [rsp+0x40], xmm5
000079a3731dee6a  vmovaps [rsp+0x50], xmm6
000079a3731dee70  vmovaps [rsp+0x60], xmm7
000079a3731dee76  vmovaps [rsp+0x70], xmm8
000079a3731dee7c  vmovaps [rsp+0x80], xmm9
000079a3731dee85  vmovaps [rsp+0x90], xmm10
000079a3731dee8e  vmovaps [rsp+0xA0], xmm11
000079a3731dee97  vmovaps [rsp+0xB0], xmm12
000079a3731deea0  vmovaps [rsp+0xC0], xmm13
000079a3731deea9  vmovaps [rsp+0xD0], xmm14
000079a3731deeb2  vmovaps [rsp+0xE0], xmm15
000079a3731deebb  sub rsp, 0x30
000079a3731deebf  movaps [rsp], xmm4
000079a3731deec3  movaps [rsp+0x10], xmm2
000079a3731deec8  movaps [rsp+0x20], xmm9
000079a3731deece  lea rdi, [rsp]
000079a3731deed2  mov esi, 0x00
000079a3731deed7  mov rax, 0x64F127B95530
000079a3731deee1  call rax
000079a3731deee3  movaps xmm4, [rsp]
000079a3731deee7  add rsp, 0x30
000079a3731deeeb  vmovaps xmm0, [rsp]
000079a3731deef0  vmovaps xmm1, [rsp+0x10]
000079a3731deef6  vmovaps xmm2, [rsp+0x20]
000079a3731deefc  vmovaps xmm3, [rsp+0x30]
000079a3731def02  vmovaps xmm5, [rsp+0x40]
000079a3731def08  vmovaps xmm6, [rsp+0x50]
000079a3731def0e  vmovaps xmm7, [rsp+0x60]
000079a3731def14  vmovaps xmm8, [rsp+0x70]
000079a3731def1a  vmovaps xmm9, [rsp+0x80]
000079a3731def23  vmovaps xmm10, [rsp+0x90]
000079a3731def2c  vmovaps xmm11, [rsp+0xA0]
000079a3731def35  vmovaps xmm12, [rsp+0xB0]
000079a3731def3e  vmovaps xmm13, [rsp+0xC0]
000079a3731def47  vmovaps xmm14, [rsp+0xD0]
000079a3731def50  vmovaps xmm15, [rsp+0xE0]
000079a3731def59  add rsp, 0xF0
000079a3731def60  pop r11
000079a3731def62  pop r10
000079a3731def64  pop r9
000079a3731def66  pop r8
000079a3731def68  pop rsi
000079a3731def69  pop rdi
000079a3731def6a  pop rdx
000079a3731def6b  pop rcx
000079a3731def6c  pop rax
000079a3731def6d  add rsp, 0x08
000079a3731def71  jmp 0x000079A3731DC31E
000079a3731def76  sub rsp, 0x08
000079a3731def7a  push rax
000079a3731def7b  push rcx
000079a3731def7c  push rdx
000079a3731def7d  push rdi
000079a3731def7e  push rsi
000079a3731def7f  push r8
000079a3731def81  push r9
000079a3731def83  push r10
000079a3731def85  push r11
000079a3731def87  sub rsp, 0xF0
000079a3731def8e  vmovaps [rsp], xmm0
000079a3731def93  vmovaps [rsp+0x10], xmm1
000079a3731def99  vmovaps [rsp+0x20], xmm2
000079a3731def9f  vmovaps [rsp+0x30], xmm3
000079a3731defa5  vmovaps [rsp+0x40], xmm4
000079a3731defab  vmovaps [rsp+0x50], xmm5
000079a3731defb1  vmovaps [rsp+0x60], xmm6
000079a3731defb7  vmovaps [rsp+0x70], xmm7
000079a3731defbd  vmovaps [rsp+0x80], xmm8
000079a3731defc6  vmovaps [rsp+0x90], xmm10
000079a3731defcf  vmovaps [rsp+0xA0], xmm11
000079a3731defd8  vmovaps [rsp+0xB0], xmm12
000079a3731defe1  vmovaps [rsp+0xC0], xmm13
000079a3731defea  vmovaps [rsp+0xD0], xmm14
000079a3731deff3  vmovaps [rsp+0xE0], xmm15
000079a3731deffc  sub rsp, 0x30
000079a3731df000  movaps [rsp], xmm9
000079a3731df005  movaps [rsp+0x10], xmm2
000079a3731df00a  movaps [rsp+0x20], xmm1
000079a3731df00f  lea rdi, [rsp]
000079a3731df013  mov esi, 0x00
000079a3731df018  mov rax, 0x64F127B95530
000079a3731df022  call rax
000079a3731df024  movaps xmm9, [rsp]
000079a3731df029  add rsp, 0x30
000079a3731df02d  vmovaps xmm0, [rsp]
000079a3731df032  vmovaps xmm1, [rsp+0x10]
000079a3731df038  vmovaps xmm2, [rsp+0x20]
000079a3731df03e  vmovaps xmm3, [rsp+0x30]
000079a3731df044  vmovaps xmm4, [rsp+0x40]
000079a3731df04a  vmovaps xmm5, [rsp+0x50]
000079a3731df050  vmovaps xmm6, [rsp+0x60]
000079a3731df056  vmovaps xmm7, [rsp+0x70]
000079a3731df05c  vmovaps xmm8, [rsp+0x80]
000079a3731df065  vmovaps xmm10, [rsp+0x90]
000079a3731df06e  vmovaps xmm11, [rsp+0xA0]
000079a3731df077  vmovaps xmm12, [rsp+0xB0]
000079a3731df080  vmovaps xmm13, [rsp+0xC0]
000079a3731df089  vmovaps xmm14, [rsp+0xD0]
000079a3731df092  vmovaps xmm15, [rsp+0xE0]
000079a3731df09b  add rsp, 0xF0
000079a3731df0a2  pop r11
000079a3731df0a4  pop r10
000079a3731df0a6  pop r9
000079a3731df0a8  pop r8
000079a3731df0aa  pop rsi
000079a3731df0ab  pop rdi
000079a3731df0ac  pop rdx
000079a3731df0ad  pop rcx
000079a3731df0ae  pop rax
000079a3731df0af  add rsp, 0x08
000079a3731df0b3  jmp 0x000079A3731DC354
000079a3731df0b8  sub rsp, 0x08
000079a3731df0bc  push rax
000079a3731df0bd  push rcx
000079a3731df0be  push rdx
000079a3731df0bf  push rdi
000079a3731df0c0  push rsi
000079a3731df0c1  push r8
000079a3731df0c3  push r9
000079a3731df0c5  push r10
000079a3731df0c7  push r11
000079a3731df0c9  sub rsp, 0xF0
000079a3731df0d0  vmovaps [rsp], xmm0
000079a3731df0d5  vmovaps [rsp+0x10], xmm2
000079a3731df0db  vmovaps [rsp+0x20], xmm3
000079a3731df0e1  vmovaps [rsp+0x30], xmm4
000079a3731df0e7  vmovaps [rsp+0x40], xmm5
000079a3731df0ed  vmovaps [rsp+0x50], xmm6
000079a3731df0f3  vmovaps [rsp+0x60], xmm7
000079a3731df0f9  vmovaps [rsp+0x70], xmm8
000079a3731df0ff  vmovaps [rsp+0x80], xmm9
000079a3731df108  vmovaps [rsp+0x90], xmm10
000079a3731df111  vmovaps [rsp+0xA0], xmm11
000079a3731df11a  vmovaps [rsp+0xB0], xmm12
000079a3731df123  vmovaps [rsp+0xC0], xmm13
000079a3731df12c  vmovaps [rsp+0xD0], xmm14
000079a3731df135  vmovaps [rsp+0xE0], xmm15
000079a3731df13e  sub rsp, 0x30
000079a3731df142  movaps [rsp], xmm1
000079a3731df146  movaps [rsp+0x10], xmm15
000079a3731df14c  movaps [rsp+0x20], xmm6
000079a3731df151  lea rdi, [rsp]
000079a3731df155  mov esi, 0x00
000079a3731df15a  mov rax, 0x64F127B95530
000079a3731df164  call rax
000079a3731df166  movaps xmm1, [rsp]
000079a3731df16a  add rsp, 0x30
000079a3731df16e  vmovaps xmm0, [rsp]
000079a3731df173  vmovaps xmm2, [rsp+0x10]
000079a3731df179  vmovaps xmm3, [rsp+0x20]
000079a3731df17f  vmovaps xmm4, [rsp+0x30]
000079a3731df185  vmovaps xmm5, [rsp+0x40]
000079a3731df18b  vmovaps xmm6, [rsp+0x50]
000079a3731df191  vmovaps xmm7, [rsp+0x60]
000079a3731df197  vmovaps xmm8, [rsp+0x70]
000079a3731df19d  vmovaps xmm9, [rsp+0x80]
000079a3731df1a6  vmovaps xmm10, [rsp+0x90]
000079a3731df1af  vmovaps xmm11, [rsp+0xA0]
000079a3731df1b8  vmovaps xmm12, [rsp+0xB0]
000079a3731df1c1  vmovaps xmm13, [rsp+0xC0]
000079a3731df1ca  vmovaps xmm14, [rsp+0xD0]
000079a3731df1d3  vmovaps xmm15, [rsp+0xE0]
000079a3731df1dc  add rsp, 0xF0
000079a3731df1e3  pop r11
000079a3731df1e5  pop r10
000079a3731df1e7  pop r9
000079a3731df1e9  pop r8
000079a3731df1eb  pop rsi
000079a3731df1ec  pop rdi
000079a3731df1ed  pop rdx
000079a3731df1ee  pop rcx
000079a3731df1ef  pop rax
000079a3731df1f0  add rsp, 0x08
000079a3731df1f4  jmp 0x000079A3731DC375
000079a3731df1f9  sub rsp, 0x08
000079a3731df1fd  push rax
000079a3731df1fe  push rcx
000079a3731df1ff  push rdx
000079a3731df200  push rdi
000079a3731df201  push rsi
000079a3731df202  push r8
000079a3731df204  push r9
000079a3731df206  push r10
000079a3731df208  push r11
000079a3731df20a  sub rsp, 0xF0
000079a3731df211  vmovaps [rsp], xmm0
000079a3731df216  vmovaps [rsp+0x10], xmm1
000079a3731df21c  vmovaps [rsp+0x20], xmm2
000079a3731df222  vmovaps [rsp+0x30], xmm3
000079a3731df228  vmovaps [rsp+0x40], xmm4
000079a3731df22e  vmovaps [rsp+0x50], xmm5
000079a3731df234  vmovaps [rsp+0x60], xmm6
000079a3731df23a  vmovaps [rsp+0x70], xmm7
000079a3731df240  vmovaps [rsp+0x80], xmm8
000079a3731df249  vmovaps [rsp+0x90], xmm9
000079a3731df252  vmovaps [rsp+0xA0], xmm10
000079a3731df25b  vmovaps [rsp+0xB0], xmm11
000079a3731df264  vmovaps [rsp+0xC0], xmm12
000079a3731df26d  vmovaps [rsp+0xD0], xmm13
000079a3731df276  vmovaps [rsp+0xE0], xmm14
000079a3731df27f  sub rsp, 0x30
000079a3731df283  movaps [rsp], xmm15
000079a3731df288  movaps [rsp+0x10], xmm5
000079a3731df28d  movaps [rsp+0x20], xmm3
000079a3731df292  lea rdi, [rsp]
000079a3731df296  mov esi, 0x00
000079a3731df29b  mov rax, 0x64F127B95530
000079a3731df2a5  call rax
000079a3731df2a7  movaps xmm15, [rsp]
000079a3731df2ac  add rsp, 0x30
000079a3731df2b0  vmovaps xmm0, [rsp]
000079a3731df2b5  vmovaps xmm1, [rsp+0x10]
000079a3731df2bb  vmovaps xmm2, [rsp+0x20]
000079a3731df2c1  vmovaps xmm3, [rsp+0x30]
000079a3731df2c7  vmovaps xmm4, [rsp+0x40]
000079a3731df2cd  vmovaps xmm5, [rsp+0x50]
000079a3731df2d3  vmovaps xmm6, [rsp+0x60]
000079a3731df2d9  vmovaps xmm7, [rsp+0x70]
000079a3731df2df  vmovaps xmm8, [rsp+0x80]
000079a3731df2e8  vmovaps xmm9, [rsp+0x90]
000079a3731df2f1  vmovaps xmm10, [rsp+0xA0]
000079a3731df2fa  vmovaps xmm11, [rsp+0xB0]
000079a3731df303  vmovaps xmm12, [rsp+0xC0]
000079a3731df30c  vmovaps xmm13, [rsp+0xD0]
000079a3731df315  vmovaps xmm14, [rsp+0xE0]
000079a3731df31e  add rsp, 0xF0
000079a3731df325  pop r11
000079a3731df327  pop r10
000079a3731df329  pop r9
000079a3731df32b  pop r8
000079a3731df32d  pop rsi
000079a3731df32e  pop rdi
000079a3731df32f  pop rdx
000079a3731df330  pop rcx
000079a3731df331  pop rax
000079a3731df332  add rsp, 0x08
000079a3731df336  jmp 0x000079A3731DC38F
000079a3731df33b  sub rsp, 0x08
000079a3731df33f  push rax
000079a3731df340  push rcx
000079a3731df341  push rdx
000079a3731df342  push rdi
000079a3731df343  push rsi
000079a3731df344  push r8
000079a3731df346  push r9
000079a3731df348  push r10
000079a3731df34a  push r11
000079a3731df34c  sub rsp, 0xF0
000079a3731df353  vmovaps [rsp], xmm0
000079a3731df358  vmovaps [rsp+0x10], xmm1
000079a3731df35e  vmovaps [rsp+0x20], xmm2
000079a3731df364  vmovaps [rsp+0x30], xmm3
000079a3731df36a  vmovaps [rsp+0x40], xmm4
000079a3731df370  vmovaps [rsp+0x50], xmm6
000079a3731df376  vmovaps [rsp+0x60], xmm7
000079a3731df37c  vmovaps [rsp+0x70], xmm8
000079a3731df382  vmovaps [rsp+0x80], xmm9
000079a3731df38b  vmovaps [rsp+0x90], xmm10
000079a3731df394  vmovaps [rsp+0xA0], xmm11
000079a3731df39d  vmovaps [rsp+0xB0], xmm12
000079a3731df3a6  vmovaps [rsp+0xC0], xmm13
000079a3731df3af  vmovaps [rsp+0xD0], xmm14
000079a3731df3b8  vmovaps [rsp+0xE0], xmm15
000079a3731df3c1  sub rsp, 0x30
000079a3731df3c5  movaps [rsp], xmm5
000079a3731df3c9  movaps [rsp+0x10], xmm8
000079a3731df3cf  movaps [rsp+0x20], xmm6
000079a3731df3d4  lea rdi, [rsp]
000079a3731df3d8  mov esi, 0x00
000079a3731df3dd  mov rax, 0x64F127B95530
000079a3731df3e7  call rax
000079a3731df3e9  movaps xmm5, [rsp]
000079a3731df3ed  add rsp, 0x30
000079a3731df3f1  vmovaps xmm0, [rsp]
000079a3731df3f6  vmovaps xmm1, [rsp+0x10]
000079a3731df3fc  vmovaps xmm2, [rsp+0x20]
000079a3731df402  vmovaps xmm3, [rsp+0x30]
000079a3731df408  vmovaps xmm4, [rsp+0x40]
000079a3731df40e  vmovaps xmm6, [rsp+0x50]
000079a3731df414  vmovaps xmm7, [rsp+0x60]
000079a3731df41a  vmovaps xmm8, [rsp+0x70]
000079a3731df420  vmovaps xmm9, [rsp+0x80]
000079a3731df429  vmovaps xmm10, [rsp+0x90]
000079a3731df432  vmovaps xmm11, [rsp+0xA0]
000079a3731df43b  vmovaps xmm12, [rsp+0xB0]
000079a3731df444  vmovaps xmm13, [rsp+0xC0]
000079a3731df44d  vmovaps xmm14, [rsp+0xD0]
000079a3731df456  vmovaps xmm15, [rsp+0xE0]
000079a3731df45f  add rsp, 0xF0
000079a3731df466  pop r11
000079a3731df468  pop r10
000079a3731df46a  pop r9
000079a3731df46c  pop r8
000079a3731df46e  pop rsi
000079a3731df46f  pop rdi
000079a3731df470  pop rdx
000079a3731df471  pop rcx
000079a3731df472  pop rax
000079a3731df473  add rsp, 0x08
000079a3731df477  jmp 0x000079A3731DC3B3
000079a3731df47c  sub rsp, 0x08
000079a3731df480  push rax
000079a3731df481  push rcx
000079a3731df482  push rdx
000079a3731df483  push rdi
000079a3731df484  push rsi
000079a3731df485  push r8
000079a3731df487  push r9
000079a3731df489  push r10
000079a3731df48b  push r11
000079a3731df48d  sub rsp, 0xF0
000079a3731df494  vmovaps [rsp], xmm0
000079a3731df499  vmovaps [rsp+0x10], xmm1
000079a3731df49f  vmovaps [rsp+0x20], xmm2
000079a3731df4a5  vmovaps [rsp+0x30], xmm3
000079a3731df4ab  vmovaps [rsp+0x40], xmm4
000079a3731df4b1  vmovaps [rsp+0x50], xmm5
000079a3731df4b7  vmovaps [rsp+0x60], xmm7
000079a3731df4bd  vmovaps [rsp+0x70], xmm8
000079a3731df4c3  vmovaps [rsp+0x80], xmm9
000079a3731df4cc  vmovaps [rsp+0x90], xmm10
000079a3731df4d5  vmovaps [rsp+0xA0], xmm11
000079a3731df4de  vmovaps [rsp+0xB0], xmm12
000079a3731df4e7  vmovaps [rsp+0xC0], xmm13
000079a3731df4f0  vmovaps [rsp+0xD0], xmm14
000079a3731df4f9  vmovaps [rsp+0xE0], xmm15
000079a3731df502  sub rsp, 0x30
000079a3731df506  movaps [rsp], xmm6
000079a3731df50a  movaps [rsp+0x10], xmm10
000079a3731df510  movaps [rsp+0x20], xmm8
000079a3731df516  lea rdi, [rsp]
000079a3731df51a  mov esi, 0x00
000079a3731df51f  mov rax, 0x64F127B95530
000079a3731df529  call rax
000079a3731df52b  movaps xmm6, [rsp]
000079a3731df52f  add rsp, 0x30
000079a3731df533  vmovaps xmm0, [rsp]
000079a3731df538  vmovaps xmm1, [rsp+0x10]
000079a3731df53e  vmovaps xmm2, [rsp+0x20]
000079a3731df544  vmovaps xmm3, [rsp+0x30]
000079a3731df54a  vmovaps xmm4, [rsp+0x40]
000079a3731df550  vmovaps xmm5, [rsp+0x50]
000079a3731df556  vmovaps xmm7, [rsp+0x60]
000079a3731df55c  vmovaps xmm8, [rsp+0x70]
000079a3731df562  vmovaps xmm9, [rsp+0x80]
000079a3731df56b  vmovaps xmm10, [rsp+0x90]
000079a3731df574  vmovaps xmm11, [rsp+0xA0]
000079a3731df57d  vmovaps xmm12, [rsp+0xB0]
000079a3731df586  vmovaps xmm13, [rsp+0xC0]
000079a3731df58f  vmovaps xmm14, [rsp+0xD0]
000079a3731df598  vmovaps xmm15, [rsp+0xE0]
000079a3731df5a1  add rsp, 0xF0
000079a3731df5a8  pop r11
000079a3731df5aa  pop r10
000079a3731df5ac  pop r9
000079a3731df5ae  pop r8
000079a3731df5b0  pop rsi
000079a3731df5b1  pop rdi
000079a3731df5b2  pop rdx
000079a3731df5b3  pop rcx
000079a3731df5b4  pop rax
000079a3731df5b5  add rsp, 0x08
000079a3731df5b9  jmp 0x000079A3731DC3D8
000079a3731df5be  sub rsp, 0x08
000079a3731df5c2  push rax
000079a3731df5c3  push rcx
000079a3731df5c4  push rdx
000079a3731df5c5  push rdi
000079a3731df5c6  push rsi
000079a3731df5c7  push r8
000079a3731df5c9  push r9
000079a3731df5cb  push r10
000079a3731df5cd  push r11
000079a3731df5cf  sub rsp, 0xF0
000079a3731df5d6  vmovaps [rsp], xmm0
000079a3731df5db  vmovaps [rsp+0x10], xmm1
000079a3731df5e1  vmovaps [rsp+0x20], xmm2
000079a3731df5e7  vmovaps [rsp+0x30], xmm3
000079a3731df5ed  vmovaps [rsp+0x40], xmm4
000079a3731df5f3  vmovaps [rsp+0x50], xmm5
000079a3731df5f9  vmovaps [rsp+0x60], xmm6
000079a3731df5ff  vmovaps [rsp+0x70], xmm7
000079a3731df605  vmovaps [rsp+0x80], xmm8
000079a3731df60e  vmovaps [rsp+0x90], xmm9
000079a3731df617  vmovaps [rsp+0xA0], xmm11
000079a3731df620  vmovaps [rsp+0xB0], xmm12
000079a3731df629  vmovaps [rsp+0xC0], xmm13
000079a3731df632  vmovaps [rsp+0xD0], xmm14
000079a3731df63b  vmovaps [rsp+0xE0], xmm15
000079a3731df644  sub rsp, 0x30
000079a3731df648  movaps [rsp], xmm10
000079a3731df64d  movaps [rsp+0x10], xmm8
000079a3731df653  movaps [rsp+0x20], xmm14
000079a3731df659  lea rdi, [rsp]
000079a3731df65d  mov esi, 0x00
000079a3731df662  mov rax, 0x64F127B95530
000079a3731df66c  call rax
000079a3731df66e  movaps xmm10, [rsp]
000079a3731df673  add rsp, 0x30
000079a3731df677  vmovaps xmm0, [rsp]
000079a3731df67c  vmovaps xmm1, [rsp+0x10]
000079a3731df682  vmovaps xmm2, [rsp+0x20]
000079a3731df688  vmovaps xmm3, [rsp+0x30]
000079a3731df68e  vmovaps xmm4, [rsp+0x40]
000079a3731df694  vmovaps xmm5, [rsp+0x50]
000079a3731df69a  vmovaps xmm6, [rsp+0x60]
000079a3731df6a0  vmovaps xmm7, [rsp+0x70]
000079a3731df6a6  vmovaps xmm8, [rsp+0x80]
000079a3731df6af  vmovaps xmm9, [rsp+0x90]
000079a3731df6b8  vmovaps xmm11, [rsp+0xA0]
000079a3731df6c1  vmovaps xmm12, [rsp+0xB0]
000079a3731df6ca  vmovaps xmm13, [rsp+0xC0]
000079a3731df6d3  vmovaps xmm14, [rsp+0xD0]
000079a3731df6dc  vmovaps xmm15, [rsp+0xE0]
000079a3731df6e5  add rsp, 0xF0
000079a3731df6ec  pop r11
000079a3731df6ee  pop r10
000079a3731df6f0  pop r9
000079a3731df6f2  pop r8
000079a3731df6f4  pop rsi
000079a3731df6f5  pop rdi
000079a3731df6f6  pop rdx
000079a3731df6f7  pop rcx
000079a3731df6f8  pop rax
000079a3731df6f9  add rsp, 0x08
000079a3731df6fd  jmp 0x000079A3731DC3F8
000079a3731df702  sub rsp, 0x08
000079a3731df706  push rax
000079a3731df707  push rcx
000079a3731df708  push rdx
000079a3731df709  push rdi
000079a3731df70a  push rsi
000079a3731df70b  push r8
000079a3731df70d  push r9
000079a3731df70f  push r10
000079a3731df711  push r11
000079a3731df713  sub rsp, 0xF0
000079a3731df71a  vmovaps [rsp], xmm0
000079a3731df71f  vmovaps [rsp+0x10], xmm1
000079a3731df725  vmovaps [rsp+0x20], xmm2
000079a3731df72b  vmovaps [rsp+0x30], xmm3
000079a3731df731  vmovaps [rsp+0x40], xmm4
000079a3731df737  vmovaps [rsp+0x50], xmm5
000079a3731df73d  vmovaps [rsp+0x60], xmm6
000079a3731df743  vmovaps [rsp+0x70], xmm7
000079a3731df749  vmovaps [rsp+0x80], xmm8
000079a3731df752  vmovaps [rsp+0x90], xmm9
000079a3731df75b  vmovaps [rsp+0xA0], xmm10
000079a3731df764  vmovaps [rsp+0xB0], xmm11
000079a3731df76d  vmovaps [rsp+0xC0], xmm12
000079a3731df776  vmovaps [rsp+0xD0], xmm13
000079a3731df77f  vmovaps [rsp+0xE0], xmm15
000079a3731df788  sub rsp, 0x30
000079a3731df78c  movaps [rsp], xmm14
000079a3731df791  movaps [rsp+0x10], xmm8
000079a3731df797  movaps [rsp+0x20], xmm4
000079a3731df79c  lea rdi, [rsp]
000079a3731df7a0  mov esi, 0x00
000079a3731df7a5  mov rax, 0x64F127B95530
000079a3731df7af  call rax
000079a3731df7b1  movaps xmm14, [rsp]
000079a3731df7b6  add rsp, 0x30
000079a3731df7ba  vmovaps xmm0, [rsp]
000079a3731df7bf  vmovaps xmm1, [rsp+0x10]
000079a3731df7c5  vmovaps xmm2, [rsp+0x20]
000079a3731df7cb  vmovaps xmm3, [rsp+0x30]
000079a3731df7d1  vmovaps xmm4, [rsp+0x40]
000079a3731df7d7  vmovaps xmm5, [rsp+0x50]
000079a3731df7dd  vmovaps xmm6, [rsp+0x60]
000079a3731df7e3  vmovaps xmm7, [rsp+0x70]
000079a3731df7e9  vmovaps xmm8, [rsp+0x80]
000079a3731df7f2  vmovaps xmm9, [rsp+0x90]
000079a3731df7fb  vmovaps xmm10, [rsp+0xA0]
000079a3731df804  vmovaps xmm11, [rsp+0xB0]
000079a3731df80d  vmovaps xmm12, [rsp+0xC0]
000079a3731df816  vmovaps xmm13, [rsp+0xD0]
000079a3731df81f  vmovaps xmm15, [rsp+0xE0]
000079a3731df828  add rsp, 0xF0
000079a3731df82f  pop r11
000079a3731df831  pop r10
000079a3731df833  pop r9
000079a3731df835  pop r8
000079a3731df837  pop rsi
000079a3731df838  pop rdi
000079a3731df839  pop rdx
000079a3731df83a  pop rcx
000079a3731df83b  pop rax
000079a3731df83c  add rsp, 0x08
000079a3731df840  jmp 0x000079A3731DC418
000079a3731df845  sub rsp, 0x08
000079a3731df849  push rax
000079a3731df84a  push rcx
000079a3731df84b  push rdx
000079a3731df84c  push rdi
000079a3731df84d  push rsi
000079a3731df84e  push r8
000079a3731df850  push r9
000079a3731df852  push r10
000079a3731df854  push r11
000079a3731df856  sub rsp, 0xF0
000079a3731df85d  vmovaps [rsp], xmm0
000079a3731df862  vmovaps [rsp+0x10], xmm1
000079a3731df868  vmovaps [rsp+0x20], xmm2
000079a3731df86e  vmovaps [rsp+0x30], xmm3
000079a3731df874  vmovaps [rsp+0x40], xmm5
000079a3731df87a  vmovaps [rsp+0x50], xmm6
000079a3731df880  vmovaps [rsp+0x60], xmm7
000079a3731df886  vmovaps [rsp+0x70], xmm8
000079a3731df88c  vmovaps [rsp+0x80], xmm9
000079a3731df895  vmovaps [rsp+0x90], xmm10
000079a3731df89e  vmovaps [rsp+0xA0], xmm11
000079a3731df8a7  vmovaps [rsp+0xB0], xmm12
000079a3731df8b0  vmovaps [rsp+0xC0], xmm13
000079a3731df8b9  vmovaps [rsp+0xD0], xmm14
000079a3731df8c2  vmovaps [rsp+0xE0], xmm15
000079a3731df8cb  sub rsp, 0x30
000079a3731df8cf  movaps [rsp], xmm4
000079a3731df8d3  movaps [rsp+0x10], xmm13
000079a3731df8d9  movaps [rsp+0x20], xmm8
000079a3731df8df  lea rdi, [rsp]
000079a3731df8e3  mov esi, 0x00
000079a3731df8e8  mov rax, 0x64F127B95530
000079a3731df8f2  call rax
000079a3731df8f4  movaps xmm4, [rsp]
000079a3731df8f8  add rsp, 0x30
000079a3731df8fc  vmovaps xmm0, [rsp]
000079a3731df901  vmovaps xmm1, [rsp+0x10]
000079a3731df907  vmovaps xmm2, [rsp+0x20]
000079a3731df90d  vmovaps xmm3, [rsp+0x30]
000079a3731df913  vmovaps xmm5, [rsp+0x40]
000079a3731df919  vmovaps xmm6, [rsp+0x50]
000079a3731df91f  vmovaps xmm7, [rsp+0x60]
000079a3731df925  vmovaps xmm8, [rsp+0x70]
000079a3731df92b  vmovaps xmm9, [rsp+0x80]
000079a3731df934  vmovaps xmm10, [rsp+0x90]
000079a3731df93d  vmovaps xmm11, [rsp+0xA0]
000079a3731df946  vmovaps xmm12, [rsp+0xB0]
000079a3731df94f  vmovaps xmm13, [rsp+0xC0]
000079a3731df958  vmovaps xmm14, [rsp+0xD0]
000079a3731df961  vmovaps xmm15, [rsp+0xE0]
000079a3731df96a  add rsp, 0xF0
000079a3731df971  pop r11
000079a3731df973  pop r10
000079a3731df975  pop r9
000079a3731df977  pop r8
000079a3731df979  pop rsi
000079a3731df97a  pop rdi
000079a3731df97b  pop rdx
000079a3731df97c  pop rcx
000079a3731df97d  pop rax
000079a3731df97e  add rsp, 0x08
000079a3731df982  jmp 0x000079A3731DC43D
000079a3731df987  sub rsp, 0x08
000079a3731df98b  push rax
000079a3731df98c  push rcx
000079a3731df98d  push rdx
000079a3731df98e  push rdi
000079a3731df98f  push rsi
000079a3731df990  push r8
000079a3731df992  push r9
000079a3731df994  push r10
000079a3731df996  push r11
000079a3731df998  sub rsp, 0xF0
000079a3731df99f  vmovaps [rsp], xmm0
000079a3731df9a4  vmovaps [rsp+0x10], xmm1
000079a3731df9aa  vmovaps [rsp+0x20], xmm2
000079a3731df9b0  vmovaps [rsp+0x30], xmm3
000079a3731df9b6  vmovaps [rsp+0x40], xmm4
000079a3731df9bc  vmovaps [rsp+0x50], xmm5
000079a3731df9c2  vmovaps [rsp+0x60], xmm6
000079a3731df9c8  vmovaps [rsp+0x70], xmm7
000079a3731df9ce  vmovaps [rsp+0x80], xmm8
000079a3731df9d7  vmovaps [rsp+0x90], xmm9
000079a3731df9e0  vmovaps [rsp+0xA0], xmm10
000079a3731df9e9  vmovaps [rsp+0xB0], xmm11
000079a3731df9f2  vmovaps [rsp+0xC0], xmm12
000079a3731df9fb  vmovaps [rsp+0xD0], xmm14
000079a3731dfa04  vmovaps [rsp+0xE0], xmm15
000079a3731dfa0d  sub rsp, 0x30
000079a3731dfa11  movaps [rsp], xmm13
000079a3731dfa16  movaps [rsp+0x10], xmm15
000079a3731dfa1c  movaps [rsp+0x20], xmm9
000079a3731dfa22  lea rdi, [rsp]
000079a3731dfa26  mov esi, 0x00
000079a3731dfa2b  mov rax, 0x64F127B95530
000079a3731dfa35  call rax
000079a3731dfa37  movaps xmm13, [rsp]
000079a3731dfa3c  add rsp, 0x30
000079a3731dfa40  vmovaps xmm0, [rsp]
000079a3731dfa45  vmovaps xmm1, [rsp+0x10]
000079a3731dfa4b  vmovaps xmm2, [rsp+0x20]
000079a3731dfa51  vmovaps xmm3, [rsp+0x30]
000079a3731dfa57  vmovaps xmm4, [rsp+0x40]
000079a3731dfa5d  vmovaps xmm5, [rsp+0x50]
000079a3731dfa63  vmovaps xmm6, [rsp+0x60]
000079a3731dfa69  vmovaps xmm7, [rsp+0x70]
000079a3731dfa6f  vmovaps xmm8, [rsp+0x80]
000079a3731dfa78  vmovaps xmm9, [rsp+0x90]
000079a3731dfa81  vmovaps xmm10, [rsp+0xA0]
000079a3731dfa8a  vmovaps xmm11, [rsp+0xB0]
000079a3731dfa93  vmovaps xmm12, [rsp+0xC0]
000079a3731dfa9c  vmovaps xmm14, [rsp+0xD0]
000079a3731dfaa5  vmovaps xmm15, [rsp+0xE0]
000079a3731dfaae  add rsp, 0xF0
000079a3731dfab5  pop r11
000079a3731dfab7  pop r10
000079a3731dfab9  pop r9
000079a3731dfabb  pop r8
000079a3731dfabd  pop rsi
000079a3731dfabe  pop rdi
000079a3731dfabf  pop rdx
000079a3731dfac0  pop rcx
000079a3731dfac1  pop rax
000079a3731dfac2  add rsp, 0x08
000079a3731dfac6  jmp 0x000079A3731DC458
000079a3731dfacb  sub rsp, 0x08
000079a3731dfacf  push rax
000079a3731dfad0  push rcx
000079a3731dfad1  push rdx
000079a3731dfad2  push rdi
000079a3731dfad3  push rsi
000079a3731dfad4  push r8
000079a3731dfad6  push r9
000079a3731dfad8  push r10
000079a3731dfada  push r11
000079a3731dfadc  sub rsp, 0xF0
000079a3731dfae3  vmovaps [rsp], xmm0
000079a3731dfae8  vmovaps [rsp+0x10], xmm1
000079a3731dfaee  vmovaps [rsp+0x20], xmm2
000079a3731dfaf4  vmovaps [rsp+0x30], xmm3
000079a3731dfafa  vmovaps [rsp+0x40], xmm4
000079a3731dfb00  vmovaps [rsp+0x50], xmm5
000079a3731dfb06  vmovaps [rsp+0x60], xmm6
000079a3731dfb0c  vmovaps [rsp+0x70], xmm7
000079a3731dfb12  vmovaps [rsp+0x80], xmm8
000079a3731dfb1b  vmovaps [rsp+0x90], xmm9
000079a3731dfb24  vmovaps [rsp+0xA0], xmm10
000079a3731dfb2d  vmovaps [rsp+0xB0], xmm11
000079a3731dfb36  vmovaps [rsp+0xC0], xmm12
000079a3731dfb3f  vmovaps [rsp+0xD0], xmm13
000079a3731dfb48  vmovaps [rsp+0xE0], xmm14
000079a3731dfb51  sub rsp, 0x30
000079a3731dfb55  movaps [rsp], xmm15
000079a3731dfb5a  movaps [rsp+0x10], xmm1
000079a3731dfb5f  movaps [rsp+0x20], xmm5
000079a3731dfb64  lea rdi, [rsp]
000079a3731dfb68  mov esi, 0x00
000079a3731dfb6d  mov rax, 0x64F127B95530
000079a3731dfb77  call rax
000079a3731dfb79  movaps xmm15, [rsp]
000079a3731dfb7e  add rsp, 0x30
000079a3731dfb82  vmovaps xmm0, [rsp]
000079a3731dfb87  vmovaps xmm1, [rsp+0x10]
000079a3731dfb8d  vmovaps xmm2, [rsp+0x20]
000079a3731dfb93  vmovaps xmm3, [rsp+0x30]
000079a3731dfb99  vmovaps xmm4, [rsp+0x40]
000079a3731dfb9f  vmovaps xmm5, [rsp+0x50]
000079a3731dfba5  vmovaps xmm6, [rsp+0x60]
000079a3731dfbab  vmovaps xmm7, [rsp+0x70]
000079a3731dfbb1  vmovaps xmm8, [rsp+0x80]
000079a3731dfbba  vmovaps xmm9, [rsp+0x90]
000079a3731dfbc3  vmovaps xmm10, [rsp+0xA0]
000079a3731dfbcc  vmovaps xmm11, [rsp+0xB0]
000079a3731dfbd5  vmovaps xmm12, [rsp+0xC0]
000079a3731dfbde  vmovaps xmm13, [rsp+0xD0]
000079a3731dfbe7  vmovaps xmm14, [rsp+0xE0]
000079a3731dfbf0  add rsp, 0xF0
000079a3731dfbf7  pop r11
000079a3731dfbf9  pop r10
000079a3731dfbfb  pop r9
000079a3731dfbfd  pop r8
000079a3731dfbff  pop rsi
000079a3731dfc00  pop rdi
000079a3731dfc01  pop rdx
000079a3731dfc02  pop rcx
000079a3731dfc03  pop rax
000079a3731dfc04  add rsp, 0x08
000079a3731dfc08  jmp 0x000079A3731DC473
000079a3731dfc0d  call 0x000079A3730B52F0
000079a3731dfc12  jmp 0x000079A3731DC4CE
000079a3731dfc17  sub rsp, 0x08
000079a3731dfc1b  push rax
000079a3731dfc1c  push rcx
000079a3731dfc1d  push rdx
000079a3731dfc1e  push rdi
000079a3731dfc1f  push rsi
000079a3731dfc20  push r8
000079a3731dfc22  push r9
000079a3731dfc24  push r10
000079a3731dfc26  push r11
000079a3731dfc28  sub rsp, 0xF0
000079a3731dfc2f  vmovaps [rsp], xmm0
000079a3731dfc34  vmovaps [rsp+0x10], xmm1
000079a3731dfc3a  vmovaps [rsp+0x20], xmm2
000079a3731dfc40  vmovaps [rsp+0x30], xmm3
000079a3731dfc46  vmovaps [rsp+0x40], xmm4
000079a3731dfc4c  vmovaps [rsp+0x50], xmm5
000079a3731dfc52  vmovaps [rsp+0x60], xmm6
000079a3731dfc58  vmovaps [rsp+0x70], xmm7
000079a3731dfc5e  vmovaps [rsp+0x80], xmm8
000079a3731dfc67  vmovaps [rsp+0x90], xmm10
000079a3731dfc70  vmovaps [rsp+0xA0], xmm11
000079a3731dfc79  vmovaps [rsp+0xB0], xmm12
000079a3731dfc82  vmovaps [rsp+0xC0], xmm13
000079a3731dfc8b  vmovaps [rsp+0xD0], xmm14
000079a3731dfc94  vmovaps [rsp+0xE0], xmm15
000079a3731dfc9d  sub rsp, 0x30
000079a3731dfca1  movaps [rsp], xmm9
000079a3731dfca6  movaps [rsp+0x10], xmm8
000079a3731dfcac  movaps [rsp+0x20], xmm11
000079a3731dfcb2  lea rdi, [rsp]
000079a3731dfcb6  mov esi, 0x00
000079a3731dfcbb  mov rax, 0x64F127B95530
000079a3731dfcc5  call rax
000079a3731dfcc7  movaps xmm9, [rsp]
000079a3731dfccc  add rsp, 0x30
000079a3731dfcd0  vmovaps xmm0, [rsp]
000079a3731dfcd5  vmovaps xmm1, [rsp+0x10]
000079a3731dfcdb  vmovaps xmm2, [rsp+0x20]
000079a3731dfce1  vmovaps xmm3, [rsp+0x30]
000079a3731dfce7  vmovaps xmm4, [rsp+0x40]
000079a3731dfced  vmovaps xmm5, [rsp+0x50]
000079a3731dfcf3  vmovaps xmm6, [rsp+0x60]
000079a3731dfcf9  vmovaps xmm7, [rsp+0x70]
000079a3731dfcff  vmovaps xmm8, [rsp+0x80]
000079a3731dfd08  vmovaps xmm10, [rsp+0x90]
000079a3731dfd11  vmovaps xmm11, [rsp+0xA0]
000079a3731dfd1a  vmovaps xmm12, [rsp+0xB0]
000079a3731dfd23  vmovaps xmm13, [rsp+0xC0]
000079a3731dfd2c  vmovaps xmm14, [rsp+0xD0]
000079a3731dfd35  vmovaps xmm15, [rsp+0xE0]
000079a3731dfd3e  add rsp, 0xF0
000079a3731dfd45  pop r11
000079a3731dfd47  pop r10
000079a3731dfd49  pop r9
000079a3731dfd4b  pop r8
000079a3731dfd4d  pop rsi
000079a3731dfd4e  pop rdi
000079a3731dfd4f  pop rdx
000079a3731dfd50  pop rcx
000079a3731dfd51  pop rax
000079a3731dfd52  add rsp, 0x08
000079a3731dfd56  jmp 0x000079A3731DC505
000079a3731dfd5b  sub rsp, 0x08
000079a3731dfd5f  push rax
000079a3731dfd60  push rcx
000079a3731dfd61  push rdx
000079a3731dfd62  push rdi
000079a3731dfd63  push rsi
000079a3731dfd64  push r8
000079a3731dfd66  push r9
000079a3731dfd68  push r10
000079a3731dfd6a  push r11
000079a3731dfd6c  sub rsp, 0xF0
000079a3731dfd73  vmovaps [rsp], xmm0
000079a3731dfd78  vmovaps [rsp+0x10], xmm1
000079a3731dfd7e  vmovaps [rsp+0x20], xmm2
000079a3731dfd84  vmovaps [rsp+0x30], xmm3
000079a3731dfd8a  vmovaps [rsp+0x40], xmm4
000079a3731dfd90  vmovaps [rsp+0x50], xmm5
000079a3731dfd96  vmovaps [rsp+0x60], xmm6
000079a3731dfd9c  vmovaps [rsp+0x70], xmm7
000079a3731dfda2  vmovaps [rsp+0x80], xmm8
000079a3731dfdab  vmovaps [rsp+0x90], xmm9
000079a3731dfdb4  vmovaps [rsp+0xA0], xmm10
000079a3731dfdbd  vmovaps [rsp+0xB0], xmm12
000079a3731dfdc6  vmovaps [rsp+0xC0], xmm13
000079a3731dfdcf  vmovaps [rsp+0xD0], xmm14
000079a3731dfdd8  vmovaps [rsp+0xE0], xmm15
000079a3731dfde1  sub rsp, 0x30
000079a3731dfde5  movaps [rsp], xmm11
000079a3731dfdea  movaps [rsp+0x10], xmm10
000079a3731dfdf0  movaps [rsp+0x20], xmm6
000079a3731dfdf5  lea rdi, [rsp]
000079a3731dfdf9  mov esi, 0x00
000079a3731dfdfe  mov rax, 0x64F127B95530
000079a3731dfe08  call rax
000079a3731dfe0a  movaps xmm11, [rsp]
000079a3731dfe0f  add rsp, 0x30
000079a3731dfe13  vmovaps xmm0, [rsp]
000079a3731dfe18  vmovaps xmm1, [rsp+0x10]
000079a3731dfe1e  vmovaps xmm2, [rsp+0x20]
000079a3731dfe24  vmovaps xmm3, [rsp+0x30]
000079a3731dfe2a  vmovaps xmm4, [rsp+0x40]
000079a3731dfe30  vmovaps xmm5, [rsp+0x50]
000079a3731dfe36  vmovaps xmm6, [rsp+0x60]
000079a3731dfe3c  vmovaps xmm7, [rsp+0x70]
000079a3731dfe42  vmovaps xmm8, [rsp+0x80]
000079a3731dfe4b  vmovaps xmm9, [rsp+0x90]
000079a3731dfe54  vmovaps xmm10, [rsp+0xA0]
000079a3731dfe5d  vmovaps xmm12, [rsp+0xB0]
000079a3731dfe66  vmovaps xmm13, [rsp+0xC0]
000079a3731dfe6f  vmovaps xmm14, [rsp+0xD0]
000079a3731dfe78  vmovaps xmm15, [rsp+0xE0]
000079a3731dfe81  add rsp, 0xF0
000079a3731dfe88  pop r11
000079a3731dfe8a  pop r10
000079a3731dfe8c  pop r9
000079a3731dfe8e  pop r8
000079a3731dfe90  pop rsi
000079a3731dfe91  pop rdi
000079a3731dfe92  pop rdx
000079a3731dfe93  pop rcx
000079a3731dfe94  pop rax
000079a3731dfe95  add rsp, 0x08
000079a3731dfe99  jmp 0x000079A3731DC520
000079a3731dfe9e  sub rsp, 0x08
000079a3731dfea2  push rax
000079a3731dfea3  push rcx
000079a3731dfea4  push rdx
000079a3731dfea5  push rdi
000079a3731dfea6  push rsi
000079a3731dfea7  push r8
000079a3731dfea9  push r9
000079a3731dfeab  push r10
000079a3731dfead  push r11
000079a3731dfeaf  sub rsp, 0xF0
000079a3731dfeb6  vmovaps [rsp], xmm0
000079a3731dfebb  vmovaps [rsp+0x10], xmm1
000079a3731dfec1  vmovaps [rsp+0x20], xmm2
000079a3731dfec7  vmovaps [rsp+0x30], xmm3
000079a3731dfecd  vmovaps [rsp+0x40], xmm4
000079a3731dfed3  vmovaps [rsp+0x50], xmm5
000079a3731dfed9  vmovaps [rsp+0x60], xmm6
000079a3731dfedf  vmovaps [rsp+0x70], xmm7
000079a3731dfee5  vmovaps [rsp+0x80], xmm8
000079a3731dfeee  vmovaps [rsp+0x90], xmm9
000079a3731dfef7  vmovaps [rsp+0xA0], xmm11
000079a3731dff00  vmovaps [rsp+0xB0], xmm12
000079a3731dff09  vmovaps [rsp+0xC0], xmm13
000079a3731dff12  vmovaps [rsp+0xD0], xmm14
000079a3731dff1b  vmovaps [rsp+0xE0], xmm15
000079a3731dff24  sub rsp, 0x30
000079a3731dff28  movaps [rsp], xmm10
000079a3731dff2d  movaps [rsp+0x10], xmm14
000079a3731dff33  movaps [rsp+0x20], xmm4
000079a3731dff38  lea rdi, [rsp]
000079a3731dff3c  mov esi, 0x00
000079a3731dff41  mov rax, 0x64F127B95530
000079a3731dff4b  call rax
000079a3731dff4d  movaps xmm10, [rsp]
000079a3731dff52  add rsp, 0x30
000079a3731dff56  vmovaps xmm0, [rsp]
000079a3731dff5b  vmovaps xmm1, [rsp+0x10]
000079a3731dff61  vmovaps xmm2, [rsp+0x20]
000079a3731dff67  vmovaps xmm3, [rsp+0x30]
000079a3731dff6d  vmovaps xmm4, [rsp+0x40]
000079a3731dff73  vmovaps xmm5, [rsp+0x50]
000079a3731dff79  vmovaps xmm6, [rsp+0x60]
000079a3731dff7f  vmovaps xmm7, [rsp+0x70]
000079a3731dff85  vmovaps xmm8, [rsp+0x80]
000079a3731dff8e  vmovaps xmm9, [rsp+0x90]
000079a3731dff97  vmovaps xmm11, [rsp+0xA0]
000079a3731dffa0  vmovaps xmm12, [rsp+0xB0]
000079a3731dffa9  vmovaps xmm13, [rsp+0xC0]
000079a3731dffb2  vmovaps xmm14, [rsp+0xD0]
000079a3731dffbb  vmovaps xmm15, [rsp+0xE0]
000079a3731dffc4  add rsp, 0xF0
000079a3731dffcb  pop r11
000079a3731dffcd  pop r10
000079a3731dffcf  pop r9
000079a3731dffd1  pop r8
000079a3731dffd3  pop rsi
000079a3731dffd4  pop rdi
000079a3731dffd5  pop rdx
000079a3731dffd6  pop rcx
000079a3731dffd7  pop rax
000079a3731dffd8  add rsp, 0x08
000079a3731dffdc  jmp 0x000079A3731DC53B
000079a3731dffe1  sub rsp, 0x08
000079a3731dffe5  push rax
000079a3731dffe6  push rcx
000079a3731dffe7  push rdx
000079a3731dffe8  push rdi
000079a3731dffe9  push rsi
000079a3731dffea  push r8
000079a3731dffec  push r9
000079a3731dffee  push r10
000079a3731dfff0  push r11
000079a3731dfff2  sub rsp, 0xF0
000079a3731dfff9  vmovaps [rsp], xmm0
000079a3731dfffe  vmovaps [rsp+0x10], xmm1
000079a3731e0004  vmovaps [rsp+0x20], xmm2
000079a3731e000a  vmovaps [rsp+0x30], xmm3
000079a3731e0010  vmovaps [rsp+0x40], xmm4
000079a3731e0016  vmovaps [rsp+0x50], xmm5
000079a3731e001c  vmovaps [rsp+0x60], xmm6
000079a3731e0022  vmovaps [rsp+0x70], xmm7
000079a3731e0028  vmovaps [rsp+0x80], xmm9
000079a3731e0031  vmovaps [rsp+0x90], xmm10
000079a3731e003a  vmovaps [rsp+0xA0], xmm11
000079a3731e0043  vmovaps [rsp+0xB0], xmm12
000079a3731e004c  vmovaps [rsp+0xC0], xmm13
000079a3731e0055  vmovaps [rsp+0xD0], xmm14
000079a3731e005e  vmovaps [rsp+0xE0], xmm15
000079a3731e0067  sub rsp, 0x30
000079a3731e006b  movaps [rsp], xmm8
000079a3731e0070  movaps [rsp+0x10], xmm1
000079a3731e0075  movaps [rsp+0x20], xmm14
000079a3731e007b  lea rdi, [rsp]
000079a3731e007f  mov esi, 0x00
000079a3731e0084  mov rax, 0x64F127B95530
000079a3731e008e  call rax
000079a3731e0090  movaps xmm8, [rsp]
000079a3731e0095  add rsp, 0x30
000079a3731e0099  vmovaps xmm0, [rsp]
000079a3731e009e  vmovaps xmm1, [rsp+0x10]
000079a3731e00a4  vmovaps xmm2, [rsp+0x20]
000079a3731e00aa  vmovaps xmm3, [rsp+0x30]
000079a3731e00b0  vmovaps xmm4, [rsp+0x40]
000079a3731e00b6  vmovaps xmm5, [rsp+0x50]
000079a3731e00bc  vmovaps xmm6, [rsp+0x60]
000079a3731e00c2  vmovaps xmm7, [rsp+0x70]
000079a3731e00c8  vmovaps xmm9, [rsp+0x80]
000079a3731e00d1  vmovaps xmm10, [rsp+0x90]
000079a3731e00da  vmovaps xmm11, [rsp+0xA0]
000079a3731e00e3  vmovaps xmm12, [rsp+0xB0]
000079a3731e00ec  vmovaps xmm13, [rsp+0xC0]
000079a3731e00f5  vmovaps xmm14, [rsp+0xD0]
000079a3731e00fe  vmovaps xmm15, [rsp+0xE0]
000079a3731e0107  add rsp, 0xF0
000079a3731e010e  pop r11
000079a3731e0110  pop r10
000079a3731e0112  pop r9
000079a3731e0114  pop r8
000079a3731e0116  pop rsi
000079a3731e0117  pop rdi
000079a3731e0118  pop rdx
000079a3731e0119  pop rcx
000079a3731e011a  pop rax
000079a3731e011b  add rsp, 0x08
000079a3731e011f  jmp 0x000079A3731DC561
000079a3731e0124  sub rsp, 0x08
000079a3731e0128  push rax
000079a3731e0129  push rcx
000079a3731e012a  push rdx
000079a3731e012b  push rdi
000079a3731e012c  push rsi
000079a3731e012d  push r8
000079a3731e012f  push r9
000079a3731e0131  push r10
000079a3731e0133  push r11
000079a3731e0135  sub rsp, 0xF0
000079a3731e013c  vmovaps [rsp], xmm0
000079a3731e0141  vmovaps [rsp+0x10], xmm1
000079a3731e0147  vmovaps [rsp+0x20], xmm2
000079a3731e014d  vmovaps [rsp+0x30], xmm3
000079a3731e0153  vmovaps [rsp+0x40], xmm4
000079a3731e0159  vmovaps [rsp+0x50], xmm5
000079a3731e015f  vmovaps [rsp+0x60], xmm7
000079a3731e0165  vmovaps [rsp+0x70], xmm8
000079a3731e016b  vmovaps [rsp+0x80], xmm9
000079a3731e0174  vmovaps [rsp+0x90], xmm10
000079a3731e017d  vmovaps [rsp+0xA0], xmm11
000079a3731e0186  vmovaps [rsp+0xB0], xmm12
000079a3731e018f  vmovaps [rsp+0xC0], xmm13
000079a3731e0198  vmovaps [rsp+0xD0], xmm14
000079a3731e01a1  vmovaps [rsp+0xE0], xmm15
000079a3731e01aa  sub rsp, 0x30
000079a3731e01ae  movaps [rsp], xmm6
000079a3731e01b2  movaps [rsp+0x10], xmm1
000079a3731e01b7  movaps [rsp+0x20], xmm14
000079a3731e01bd  lea rdi, [rsp]
000079a3731e01c1  mov esi, 0x00
000079a3731e01c6  mov rax, 0x64F127B95530
000079a3731e01d0  call rax
000079a3731e01d2  movaps xmm6, [rsp]
000079a3731e01d6  add rsp, 0x30
000079a3731e01da  vmovaps xmm0, [rsp]
000079a3731e01df  vmovaps xmm1, [rsp+0x10]
000079a3731e01e5  vmovaps xmm2, [rsp+0x20]
000079a3731e01eb  vmovaps xmm3, [rsp+0x30]
000079a3731e01f1  vmovaps xmm4, [rsp+0x40]
000079a3731e01f7  vmovaps xmm5, [rsp+0x50]
000079a3731e01fd  vmovaps xmm7, [rsp+0x60]
000079a3731e0203  vmovaps xmm8, [rsp+0x70]
000079a3731e0209  vmovaps xmm9, [rsp+0x80]
000079a3731e0212  vmovaps xmm10, [rsp+0x90]
000079a3731e021b  vmovaps xmm11, [rsp+0xA0]
000079a3731e0224  vmovaps xmm12, [rsp+0xB0]
000079a3731e022d  vmovaps xmm13, [rsp+0xC0]
000079a3731e0236  vmovaps xmm14, [rsp+0xD0]
000079a3731e023f  vmovaps xmm15, [rsp+0xE0]
000079a3731e0248  add rsp, 0xF0
000079a3731e024f  pop r11
000079a3731e0251  pop r10
000079a3731e0253  pop r9
000079a3731e0255  pop r8
000079a3731e0257  pop rsi
000079a3731e0258  pop rdi
000079a3731e0259  pop rdx
000079a3731e025a  pop rcx
000079a3731e025b  pop rax
000079a3731e025c  add rsp, 0x08
000079a3731e0260  jmp 0x000079A3731DC58D
000079a3731e0265  sub rsp, 0x08
000079a3731e0269  push rax
000079a3731e026a  push rcx
000079a3731e026b  push rdx
000079a3731e026c  push rdi
000079a3731e026d  push rsi
000079a3731e026e  push r8
000079a3731e0270  push r9
000079a3731e0272  push r10
000079a3731e0274  push r11
000079a3731e0276  sub rsp, 0xF0
000079a3731e027d  vmovaps [rsp], xmm0
000079a3731e0282  vmovaps [rsp+0x10], xmm1
000079a3731e0288  vmovaps [rsp+0x20], xmm2
000079a3731e028e  vmovaps [rsp+0x30], xmm3
000079a3731e0294  vmovaps [rsp+0x40], xmm4
000079a3731e029a  vmovaps [rsp+0x50], xmm5
000079a3731e02a0  vmovaps [rsp+0x60], xmm6
000079a3731e02a6  vmovaps [rsp+0x70], xmm7
000079a3731e02ac  vmovaps [rsp+0x80], xmm8
000079a3731e02b5  vmovaps [rsp+0x90], xmm9
000079a3731e02be  vmovaps [rsp+0xA0], xmm10
000079a3731e02c7  vmovaps [rsp+0xB0], xmm11
000079a3731e02d0  vmovaps [rsp+0xC0], xmm12
000079a3731e02d9  vmovaps [rsp+0xD0], xmm13
000079a3731e02e2  vmovaps [rsp+0xE0], xmm15
000079a3731e02eb  sub rsp, 0x30
000079a3731e02ef  movaps [rsp], xmm14
000079a3731e02f4  movaps [rsp+0x10], xmm12
000079a3731e02fa  movaps [rsp+0x20], xmm1
000079a3731e02ff  lea rdi, [rsp]
000079a3731e0303  mov esi, 0x00
000079a3731e0308  mov rax, 0x64F127B95530
000079a3731e0312  call rax
000079a3731e0314  movaps xmm14, [rsp]
000079a3731e0319  add rsp, 0x30
000079a3731e031d  vmovaps xmm0, [rsp]
000079a3731e0322  vmovaps xmm1, [rsp+0x10]
000079a3731e0328  vmovaps xmm2, [rsp+0x20]
000079a3731e032e  vmovaps xmm3, [rsp+0x30]
000079a3731e0334  vmovaps xmm4, [rsp+0x40]
000079a3731e033a  vmovaps xmm5, [rsp+0x50]
000079a3731e0340  vmovaps xmm6, [rsp+0x60]
000079a3731e0346  vmovaps xmm7, [rsp+0x70]
000079a3731e034c  vmovaps xmm8, [rsp+0x80]
000079a3731e0355  vmovaps xmm9, [rsp+0x90]
000079a3731e035e  vmovaps xmm10, [rsp+0xA0]
000079a3731e0367  vmovaps xmm11, [rsp+0xB0]
000079a3731e0370  vmovaps xmm12, [rsp+0xC0]
000079a3731e0379  vmovaps xmm13, [rsp+0xD0]
000079a3731e0382  vmovaps xmm15, [rsp+0xE0]
000079a3731e038b  add rsp, 0xF0
000079a3731e0392  pop r11
000079a3731e0394  pop r10
000079a3731e0396  pop r9
000079a3731e0398  pop r8
000079a3731e039a  pop rsi
000079a3731e039b  pop rdi
000079a3731e039c  pop rdx
000079a3731e039d  pop rcx
000079a3731e039e  pop rax
000079a3731e039f  add rsp, 0x08
000079a3731e03a3  jmp 0x000079A3731DC5B3
000079a3731e03a8  sub rsp, 0x08
000079a3731e03ac  push rax
000079a3731e03ad  push rcx
000079a3731e03ae  push rdx
000079a3731e03af  push rdi
000079a3731e03b0  push rsi
000079a3731e03b1  push r8
000079a3731e03b3  push r9
000079a3731e03b5  push r10
000079a3731e03b7  push r11
000079a3731e03b9  sub rsp, 0xF0
000079a3731e03c0  vmovaps [rsp], xmm0
000079a3731e03c5  vmovaps [rsp+0x10], xmm2
000079a3731e03cb  vmovaps [rsp+0x20], xmm3
000079a3731e03d1  vmovaps [rsp+0x30], xmm4
000079a3731e03d7  vmovaps [rsp+0x40], xmm5
000079a3731e03dd  vmovaps [rsp+0x50], xmm6
000079a3731e03e3  vmovaps [rsp+0x60], xmm7
000079a3731e03e9  vmovaps [rsp+0x70], xmm8
000079a3731e03ef  vmovaps [rsp+0x80], xmm9
000079a3731e03f8  vmovaps [rsp+0x90], xmm10
000079a3731e0401  vmovaps [rsp+0xA0], xmm11
000079a3731e040a  vmovaps [rsp+0xB0], xmm12
000079a3731e0413  vmovaps [rsp+0xC0], xmm13
000079a3731e041c  vmovaps [rsp+0xD0], xmm14
000079a3731e0425  vmovaps [rsp+0xE0], xmm15
000079a3731e042e  sub rsp, 0x30
000079a3731e0432  movaps [rsp], xmm1
000079a3731e0436  movaps [rsp+0x10], xmm13
000079a3731e043c  movaps [rsp+0x20], xmm9
000079a3731e0442  lea rdi, [rsp]
000079a3731e0446  mov esi, 0x00
000079a3731e044b  mov rax, 0x64F127B95530
000079a3731e0455  call rax
000079a3731e0457  movaps xmm1, [rsp]
000079a3731e045b  add rsp, 0x30
000079a3731e045f  vmovaps xmm0, [rsp]
000079a3731e0464  vmovaps xmm2, [rsp+0x10]
000079a3731e046a  vmovaps xmm3, [rsp+0x20]
000079a3731e0470  vmovaps xmm4, [rsp+0x30]
000079a3731e0476  vmovaps xmm5, [rsp+0x40]
000079a3731e047c  vmovaps xmm6, [rsp+0x50]
000079a3731e0482  vmovaps xmm7, [rsp+0x60]
000079a3731e0488  vmovaps xmm8, [rsp+0x70]
000079a3731e048e  vmovaps xmm9, [rsp+0x80]
000079a3731e0497  vmovaps xmm10, [rsp+0x90]
000079a3731e04a0  vmovaps xmm11, [rsp+0xA0]
000079a3731e04a9  vmovaps xmm12, [rsp+0xB0]
000079a3731e04b2  vmovaps xmm13, [rsp+0xC0]
000079a3731e04bb  vmovaps xmm14, [rsp+0xD0]
000079a3731e04c4  vmovaps xmm15, [rsp+0xE0]
000079a3731e04cd  add rsp, 0xF0
000079a3731e04d4  pop r11
000079a3731e04d6  pop r10
000079a3731e04d8  pop r9
000079a3731e04da  pop r8
000079a3731e04dc  pop rsi
000079a3731e04dd  pop rdi
000079a3731e04de  pop rdx
000079a3731e04df  pop rcx
000079a3731e04e0  pop rax
000079a3731e04e1  add rsp, 0x08
000079a3731e04e5  jmp 0x000079A3731DC5CD
000079a3731e04ea  sub rsp, 0x08
000079a3731e04ee  push rax
000079a3731e04ef  push rcx
000079a3731e04f0  push rdx
000079a3731e04f1  push rdi
000079a3731e04f2  push rsi
000079a3731e04f3  push r8
000079a3731e04f5  push r9
000079a3731e04f7  push r10
000079a3731e04f9  push r11
000079a3731e04fb  sub rsp, 0xF0
000079a3731e0502  vmovaps [rsp], xmm0
000079a3731e0507  vmovaps [rsp+0x10], xmm1
000079a3731e050d  vmovaps [rsp+0x20], xmm2
000079a3731e0513  vmovaps [rsp+0x30], xmm3
000079a3731e0519  vmovaps [rsp+0x40], xmm4
000079a3731e051f  vmovaps [rsp+0x50], xmm5
000079a3731e0525  vmovaps [rsp+0x60], xmm6
000079a3731e052b  vmovaps [rsp+0x70], xmm7
000079a3731e0531  vmovaps [rsp+0x80], xmm8
000079a3731e053a  vmovaps [rsp+0x90], xmm9
000079a3731e0543  vmovaps [rsp+0xA0], xmm10
000079a3731e054c  vmovaps [rsp+0xB0], xmm11
000079a3731e0555  vmovaps [rsp+0xC0], xmm13
000079a3731e055e  vmovaps [rsp+0xD0], xmm14
000079a3731e0567  vmovaps [rsp+0xE0], xmm15
000079a3731e0570  sub rsp, 0x30
000079a3731e0574  movaps [rsp], xmm12
000079a3731e0579  movaps [rsp+0x10], xmm7
000079a3731e057e  movaps [rsp+0x20], xmm13
000079a3731e0584  lea rdi, [rsp]
000079a3731e0588  mov esi, 0x00
000079a3731e058d  mov rax, 0x64F127B95530
000079a3731e0597  call rax
000079a3731e0599  movaps xmm12, [rsp]
000079a3731e059e  add rsp, 0x30
000079a3731e05a2  vmovaps xmm0, [rsp]
000079a3731e05a7  vmovaps xmm1, [rsp+0x10]
000079a3731e05ad  vmovaps xmm2, [rsp+0x20]
000079a3731e05b3  vmovaps xmm3, [rsp+0x30]
000079a3731e05b9  vmovaps xmm4, [rsp+0x40]
000079a3731e05bf  vmovaps xmm5, [rsp+0x50]
000079a3731e05c5  vmovaps xmm6, [rsp+0x60]
000079a3731e05cb  vmovaps xmm7, [rsp+0x70]
000079a3731e05d1  vmovaps xmm8, [rsp+0x80]
000079a3731e05da  vmovaps xmm9, [rsp+0x90]
000079a3731e05e3  vmovaps xmm10, [rsp+0xA0]
000079a3731e05ec  vmovaps xmm11, [rsp+0xB0]
000079a3731e05f5  vmovaps xmm13, [rsp+0xC0]
000079a3731e05fe  vmovaps xmm14, [rsp+0xD0]
000079a3731e0607  vmovaps xmm15, [rsp+0xE0]
000079a3731e0610  add rsp, 0xF0
000079a3731e0617  pop r11
000079a3731e0619  pop r10
000079a3731e061b  pop r9
000079a3731e061d  pop r8
000079a3731e061f  pop rsi
000079a3731e0620  pop rdi
000079a3731e0621  pop rdx
000079a3731e0622  pop rcx
000079a3731e0623  pop rax
000079a3731e0624  add rsp, 0x08
000079a3731e0628  jmp 0x000079A3731DC5F4
000079a3731e062d  sub rsp, 0x08
000079a3731e0631  push rax
000079a3731e0632  push rcx
000079a3731e0633  push rdx
000079a3731e0634  push rdi
000079a3731e0635  push rsi
000079a3731e0636  push r8
000079a3731e0638  push r9
000079a3731e063a  push r10
000079a3731e063c  push r11
000079a3731e063e  sub rsp, 0xF0
000079a3731e0645  vmovaps [rsp], xmm0
000079a3731e064a  vmovaps [rsp+0x10], xmm1
000079a3731e0650  vmovaps [rsp+0x20], xmm2
000079a3731e0656  vmovaps [rsp+0x30], xmm3
000079a3731e065c  vmovaps [rsp+0x40], xmm4
000079a3731e0662  vmovaps [rsp+0x50], xmm5
000079a3731e0668  vmovaps [rsp+0x60], xmm6
000079a3731e066e  vmovaps [rsp+0x70], xmm7
000079a3731e0674  vmovaps [rsp+0x80], xmm8
000079a3731e067d  vmovaps [rsp+0x90], xmm9
000079a3731e0686  vmovaps [rsp+0xA0], xmm10
000079a3731e068f  vmovaps [rsp+0xB0], xmm11
000079a3731e0698  vmovaps [rsp+0xC0], xmm12
000079a3731e06a1  vmovaps [rsp+0xD0], xmm14
000079a3731e06aa  vmovaps [rsp+0xE0], xmm15
000079a3731e06b3  sub rsp, 0x30
000079a3731e06b7  movaps [rsp], xmm13
000079a3731e06bc  movaps [rsp+0x10], xmm15
000079a3731e06c2  movaps [rsp+0x20], xmm8
000079a3731e06c8  lea rdi, [rsp]
000079a3731e06cc  mov esi, 0x00
000079a3731e06d1  mov rax, 0x64F127B95530
000079a3731e06db  call rax
000079a3731e06dd  movaps xmm13, [rsp]
000079a3731e06e2  add rsp, 0x30
000079a3731e06e6  vmovaps xmm0, [rsp]
000079a3731e06eb  vmovaps xmm1, [rsp+0x10]
000079a3731e06f1  vmovaps xmm2, [rsp+0x20]
000079a3731e06f7  vmovaps xmm3, [rsp+0x30]
000079a3731e06fd  vmovaps xmm4, [rsp+0x40]
000079a3731e0703  vmovaps xmm5, [rsp+0x50]
000079a3731e0709  vmovaps xmm6, [rsp+0x60]
000079a3731e070f  vmovaps xmm7, [rsp+0x70]
000079a3731e0715  vmovaps xmm8, [rsp+0x80]
000079a3731e071e  vmovaps xmm9, [rsp+0x90]
000079a3731e0727  vmovaps xmm10, [rsp+0xA0]
000079a3731e0730  vmovaps xmm11, [rsp+0xB0]
000079a3731e0739  vmovaps xmm12, [rsp+0xC0]
000079a3731e0742  vmovaps xmm14, [rsp+0xD0]
000079a3731e074b  vmovaps xmm15, [rsp+0xE0]
000079a3731e0754  add rsp, 0xF0
000079a3731e075b  pop r11
000079a3731e075d  pop r10
000079a3731e075f  pop r9
000079a3731e0761  pop r8
000079a3731e0763  pop rsi
000079a3731e0764  pop rdi
000079a3731e0765  pop rdx
000079a3731e0766  pop rcx
000079a3731e0767  pop rax
000079a3731e0768  add rsp, 0x08
000079a3731e076c  jmp 0x000079A3731DC60F
000079a3731e0771  sub rsp, 0x08
000079a3731e0775  push rax
000079a3731e0776  push rcx
000079a3731e0777  push rdx
000079a3731e0778  push rdi
000079a3731e0779  push rsi
000079a3731e077a  push r8
000079a3731e077c  push r9
000079a3731e077e  push r10
000079a3731e0780  push r11
000079a3731e0782  sub rsp, 0xF0
000079a3731e0789  vmovaps [rsp], xmm0
000079a3731e078e  vmovaps [rsp+0x10], xmm1
000079a3731e0794  vmovaps [rsp+0x20], xmm2
000079a3731e079a  vmovaps [rsp+0x30], xmm3
000079a3731e07a0  vmovaps [rsp+0x40], xmm4
000079a3731e07a6  vmovaps [rsp+0x50], xmm5
000079a3731e07ac  vmovaps [rsp+0x60], xmm6
000079a3731e07b2  vmovaps [rsp+0x70], xmm7
000079a3731e07b8  vmovaps [rsp+0x80], xmm9
000079a3731e07c1  vmovaps [rsp+0x90], xmm10
000079a3731e07ca  vmovaps [rsp+0xA0], xmm11
000079a3731e07d3  vmovaps [rsp+0xB0], xmm12
000079a3731e07dc  vmovaps [rsp+0xC0], xmm13
000079a3731e07e5  vmovaps [rsp+0xD0], xmm14
000079a3731e07ee  vmovaps [rsp+0xE0], xmm15
000079a3731e07f7  sub rsp, 0x30
000079a3731e07fb  movaps [rsp], xmm8
000079a3731e0800  movaps [rsp+0x10], xmm15
000079a3731e0806  movaps [rsp+0x20], xmm9
000079a3731e080c  lea rdi, [rsp]
000079a3731e0810  mov esi, 0x00
000079a3731e0815  mov rax, 0x64F127B95530
000079a3731e081f  call rax
000079a3731e0821  movaps xmm8, [rsp]
000079a3731e0826  add rsp, 0x30
000079a3731e082a  vmovaps xmm0, [rsp]
000079a3731e082f  vmovaps xmm1, [rsp+0x10]
000079a3731e0835  vmovaps xmm2, [rsp+0x20]
000079a3731e083b  vmovaps xmm3, [rsp+0x30]
000079a3731e0841  vmovaps xmm4, [rsp+0x40]
000079a3731e0847  vmovaps xmm5, [rsp+0x50]
000079a3731e084d  vmovaps xmm6, [rsp+0x60]
000079a3731e0853  vmovaps xmm7, [rsp+0x70]
000079a3731e0859  vmovaps xmm9, [rsp+0x80]
000079a3731e0862  vmovaps xmm10, [rsp+0x90]
000079a3731e086b  vmovaps xmm11, [rsp+0xA0]
000079a3731e0874  vmovaps xmm12, [rsp+0xB0]
000079a3731e087d  vmovaps xmm13, [rsp+0xC0]
000079a3731e0886  vmovaps xmm14, [rsp+0xD0]
000079a3731e088f  vmovaps xmm15, [rsp+0xE0]
000079a3731e0898  add rsp, 0xF0
000079a3731e089f  pop r11
000079a3731e08a1  pop r10
000079a3731e08a3  pop r9
000079a3731e08a5  pop r8
000079a3731e08a7  pop rsi
000079a3731e08a8  pop rdi
000079a3731e08a9  pop rdx
000079a3731e08aa  pop rcx
000079a3731e08ab  pop rax
000079a3731e08ac  add rsp, 0x08
000079a3731e08b0  jmp 0x000079A3731DC63D
000079a3731e08b5  sub rsp, 0x08
000079a3731e08b9  push rax
000079a3731e08ba  push rcx
000079a3731e08bb  push rdx
000079a3731e08bc  push rdi
000079a3731e08bd  push rsi
000079a3731e08be  push r8
000079a3731e08c0  push r9
000079a3731e08c2  push r10
000079a3731e08c4  push r11
000079a3731e08c6  sub rsp, 0xF0
000079a3731e08cd  vmovaps [rsp], xmm0
000079a3731e08d2  vmovaps [rsp+0x10], xmm1
000079a3731e08d8  vmovaps [rsp+0x20], xmm2
000079a3731e08de  vmovaps [rsp+0x30], xmm3
000079a3731e08e4  vmovaps [rsp+0x40], xmm4
000079a3731e08ea  vmovaps [rsp+0x50], xmm5
000079a3731e08f0  vmovaps [rsp+0x60], xmm6
000079a3731e08f6  vmovaps [rsp+0x70], xmm7
000079a3731e08fc  vmovaps [rsp+0x80], xmm8
000079a3731e0905  vmovaps [rsp+0x90], xmm9
000079a3731e090e  vmovaps [rsp+0xA0], xmm10
000079a3731e0917  vmovaps [rsp+0xB0], xmm11
000079a3731e0920  vmovaps [rsp+0xC0], xmm12
000079a3731e0929  vmovaps [rsp+0xD0], xmm13
000079a3731e0932  vmovaps [rsp+0xE0], xmm14
000079a3731e093b  sub rsp, 0x30
000079a3731e093f  movaps [rsp], xmm15
000079a3731e0944  movaps [rsp+0x10], xmm11
000079a3731e094a  movaps [rsp+0x20], xmm6
000079a3731e094f  lea rdi, [rsp]
000079a3731e0953  mov esi, 0x00
000079a3731e0958  mov rax, 0x64F127B95530
000079a3731e0962  call rax
000079a3731e0964  movaps xmm15, [rsp]
000079a3731e0969  add rsp, 0x30
000079a3731e096d  vmovaps xmm0, [rsp]
000079a3731e0972  vmovaps xmm1, [rsp+0x10]
000079a3731e0978  vmovaps xmm2, [rsp+0x20]
000079a3731e097e  vmovaps xmm3, [rsp+0x30]
000079a3731e0984  vmovaps xmm4, [rsp+0x40]
000079a3731e098a  vmovaps xmm5, [rsp+0x50]
000079a3731e0990  vmovaps xmm6, [rsp+0x60]
000079a3731e0996  vmovaps xmm7, [rsp+0x70]
000079a3731e099c  vmovaps xmm8, [rsp+0x80]
000079a3731e09a5  vmovaps xmm9, [rsp+0x90]
000079a3731e09ae  vmovaps xmm10, [rsp+0xA0]
000079a3731e09b7  vmovaps xmm11, [rsp+0xB0]
000079a3731e09c0  vmovaps xmm12, [rsp+0xC0]
000079a3731e09c9  vmovaps xmm13, [rsp+0xD0]
000079a3731e09d2  vmovaps xmm14, [rsp+0xE0]
000079a3731e09db  add rsp, 0xF0
000079a3731e09e2  pop r11
000079a3731e09e4  pop r10
000079a3731e09e6  pop r9
000079a3731e09e8  pop r8
000079a3731e09ea  pop rsi
000079a3731e09eb  pop rdi
000079a3731e09ec  pop rdx
000079a3731e09ed  pop rcx
000079a3731e09ee  pop rax
000079a3731e09ef  add rsp, 0x08
000079a3731e09f3  jmp 0x000079A3731DC658
000079a3731e09f8  sub rsp, 0x08
000079a3731e09fc  push rax
000079a3731e09fd  push rcx
000079a3731e09fe  push rdx
000079a3731e09ff  push rdi
000079a3731e0a00  push rsi
000079a3731e0a01  push r8
000079a3731e0a03  push r9
000079a3731e0a05  push r10
000079a3731e0a07  push r11
000079a3731e0a09  sub rsp, 0xF0
000079a3731e0a10  vmovaps [rsp], xmm0
000079a3731e0a15  vmovaps [rsp+0x10], xmm1
000079a3731e0a1b  vmovaps [rsp+0x20], xmm2
000079a3731e0a21  vmovaps [rsp+0x30], xmm3
000079a3731e0a27  vmovaps [rsp+0x40], xmm4
000079a3731e0a2d  vmovaps [rsp+0x50], xmm5
000079a3731e0a33  vmovaps [rsp+0x60], xmm6
000079a3731e0a39  vmovaps [rsp+0x70], xmm8
000079a3731e0a3f  vmovaps [rsp+0x80], xmm9
000079a3731e0a48  vmovaps [rsp+0x90], xmm10
000079a3731e0a51  vmovaps [rsp+0xA0], xmm11
000079a3731e0a5a  vmovaps [rsp+0xB0], xmm12
000079a3731e0a63  vmovaps [rsp+0xC0], xmm13
000079a3731e0a6c  vmovaps [rsp+0xD0], xmm14
000079a3731e0a75  vmovaps [rsp+0xE0], xmm15
000079a3731e0a7e  sub rsp, 0x30
000079a3731e0a82  movaps [rsp], xmm7
000079a3731e0a86  movaps [rsp+0x10], xmm11
000079a3731e0a8c  movaps [rsp+0x20], xmm9
000079a3731e0a92  lea rdi, [rsp]
000079a3731e0a96  mov esi, 0x00
000079a3731e0a9b  mov rax, 0x64F127B95530
000079a3731e0aa5  call rax
000079a3731e0aa7  movaps xmm7, [rsp]
000079a3731e0aab  add rsp, 0x30
000079a3731e0aaf  vmovaps xmm0, [rsp]
000079a3731e0ab4  vmovaps xmm1, [rsp+0x10]
000079a3731e0aba  vmovaps xmm2, [rsp+0x20]
000079a3731e0ac0  vmovaps xmm3, [rsp+0x30]
000079a3731e0ac6  vmovaps xmm4, [rsp+0x40]
000079a3731e0acc  vmovaps xmm5, [rsp+0x50]
000079a3731e0ad2  vmovaps xmm6, [rsp+0x60]
000079a3731e0ad8  vmovaps xmm8, [rsp+0x70]
000079a3731e0ade  vmovaps xmm9, [rsp+0x80]
000079a3731e0ae7  vmovaps xmm10, [rsp+0x90]
000079a3731e0af0  vmovaps xmm11, [rsp+0xA0]
000079a3731e0af9  vmovaps xmm12, [rsp+0xB0]
000079a3731e0b02  vmovaps xmm13, [rsp+0xC0]
000079a3731e0b0b  vmovaps xmm14, [rsp+0xD0]
000079a3731e0b14  vmovaps xmm15, [rsp+0xE0]
000079a3731e0b1d  add rsp, 0xF0
000079a3731e0b24  pop r11
000079a3731e0b26  pop r10
000079a3731e0b28  pop r9
000079a3731e0b2a  pop r8
000079a3731e0b2c  pop rsi
000079a3731e0b2d  pop rdi
000079a3731e0b2e  pop rdx
000079a3731e0b2f  pop rcx
000079a3731e0b30  pop rax
000079a3731e0b31  add rsp, 0x08
000079a3731e0b35  jmp 0x000079A3731DC685
000079a3731e0b3a  sub rsp, 0x08
000079a3731e0b3e  push rax
000079a3731e0b3f  push rcx
000079a3731e0b40  push rdx
000079a3731e0b41  push rdi
000079a3731e0b42  push rsi
000079a3731e0b43  push r8
000079a3731e0b45  push r9
000079a3731e0b47  push r10
000079a3731e0b49  push r11
000079a3731e0b4b  sub rsp, 0xF0
000079a3731e0b52  vmovaps [rsp], xmm0
000079a3731e0b57  vmovaps [rsp+0x10], xmm1
000079a3731e0b5d  vmovaps [rsp+0x20], xmm2
000079a3731e0b63  vmovaps [rsp+0x30], xmm3
000079a3731e0b69  vmovaps [rsp+0x40], xmm4
000079a3731e0b6f  vmovaps [rsp+0x50], xmm5
000079a3731e0b75  vmovaps [rsp+0x60], xmm6
000079a3731e0b7b  vmovaps [rsp+0x70], xmm7
000079a3731e0b81  vmovaps [rsp+0x80], xmm8
000079a3731e0b8a  vmovaps [rsp+0x90], xmm9
000079a3731e0b93  vmovaps [rsp+0xA0], xmm10
000079a3731e0b9c  vmovaps [rsp+0xB0], xmm12
000079a3731e0ba5  vmovaps [rsp+0xC0], xmm13
000079a3731e0bae  vmovaps [rsp+0xD0], xmm14
000079a3731e0bb7  vmovaps [rsp+0xE0], xmm15
000079a3731e0bc0  sub rsp, 0x30
000079a3731e0bc4  movaps [rsp], xmm11
000079a3731e0bc9  movaps [rsp+0x10], xmm10
000079a3731e0bcf  movaps [rsp+0x20], xmm14
000079a3731e0bd5  lea rdi, [rsp]
000079a3731e0bd9  mov esi, 0x00
000079a3731e0bde  mov rax, 0x64F127B95530
000079a3731e0be8  call rax
000079a3731e0bea  movaps xmm11, [rsp]
000079a3731e0bef  add rsp, 0x30
000079a3731e0bf3  vmovaps xmm0, [rsp]
000079a3731e0bf8  vmovaps xmm1, [rsp+0x10]
000079a3731e0bfe  vmovaps xmm2, [rsp+0x20]
000079a3731e0c04  vmovaps xmm3, [rsp+0x30]
000079a3731e0c0a  vmovaps xmm4, [rsp+0x40]
000079a3731e0c10  vmovaps xmm5, [rsp+0x50]
000079a3731e0c16  vmovaps xmm6, [rsp+0x60]
000079a3731e0c1c  vmovaps xmm7, [rsp+0x70]
000079a3731e0c22  vmovaps xmm8, [rsp+0x80]
000079a3731e0c2b  vmovaps xmm9, [rsp+0x90]
000079a3731e0c34  vmovaps xmm10, [rsp+0xA0]
000079a3731e0c3d  vmovaps xmm12, [rsp+0xB0]
000079a3731e0c46  vmovaps xmm13, [rsp+0xC0]
000079a3731e0c4f  vmovaps xmm14, [rsp+0xD0]
000079a3731e0c58  vmovaps xmm15, [rsp+0xE0]
000079a3731e0c61  add rsp, 0xF0
000079a3731e0c68  pop r11
000079a3731e0c6a  pop r10
000079a3731e0c6c  pop r9
000079a3731e0c6e  pop r8
000079a3731e0c70  pop rsi
000079a3731e0c71  pop rdi
000079a3731e0c72  pop rdx
000079a3731e0c73  pop rcx
000079a3731e0c74  pop rax
000079a3731e0c75  add rsp, 0x08
000079a3731e0c79  jmp 0x000079A3731DC6A0
000079a3731e0c7e  call 0x000079A3730C33A0
000079a3731e0c83  jmp 0x000079A3731DC6AA
000079a3731e0c88  sub rsp, 0x08
000079a3731e0c8c  push rax
000079a3731e0c8d  push rcx
000079a3731e0c8e  push rdx
000079a3731e0c8f  push rdi
000079a3731e0c90  push rsi
000079a3731e0c91  push r8
000079a3731e0c93  push r9
000079a3731e0c95  push r10
000079a3731e0c97  push r11
000079a3731e0c99  sub rsp, 0xF0
000079a3731e0ca0  vmovaps [rsp], xmm0
000079a3731e0ca5  vmovaps [rsp+0x10], xmm1
000079a3731e0cab  vmovaps [rsp+0x20], xmm2
000079a3731e0cb1  vmovaps [rsp+0x30], xmm3
000079a3731e0cb7  vmovaps [rsp+0x40], xmm4
000079a3731e0cbd  vmovaps [rsp+0x50], xmm5
000079a3731e0cc3  vmovaps [rsp+0x60], xmm6
000079a3731e0cc9  vmovaps [rsp+0x70], xmm7
000079a3731e0ccf  vmovaps [rsp+0x80], xmm8
000079a3731e0cd8  vmovaps [rsp+0x90], xmm9
000079a3731e0ce1  vmovaps [rsp+0xA0], xmm11
000079a3731e0cea  vmovaps [rsp+0xB0], xmm12
000079a3731e0cf3  vmovaps [rsp+0xC0], xmm13
000079a3731e0cfc  vmovaps [rsp+0xD0], xmm14
000079a3731e0d05  vmovaps [rsp+0xE0], xmm15
000079a3731e0d0e  sub rsp, 0x30
000079a3731e0d12  movaps [rsp], xmm10
000079a3731e0d17  movaps [rsp+0x10], xmm1
000079a3731e0d1c  movaps [rsp+0x20], xmm12
000079a3731e0d22  lea rdi, [rsp]
000079a3731e0d26  mov esi, 0x00
000079a3731e0d2b  mov rax, 0x64F127B95530
000079a3731e0d35  call rax
000079a3731e0d37  movaps xmm10, [rsp]
000079a3731e0d3c  add rsp, 0x30
000079a3731e0d40  vmovaps xmm0, [rsp]
000079a3731e0d45  vmovaps xmm1, [rsp+0x10]
000079a3731e0d4b  vmovaps xmm2, [rsp+0x20]
000079a3731e0d51  vmovaps xmm3, [rsp+0x30]
000079a3731e0d57  vmovaps xmm4, [rsp+0x40]
000079a3731e0d5d  vmovaps xmm5, [rsp+0x50]
000079a3731e0d63  vmovaps xmm6, [rsp+0x60]
000079a3731e0d69  vmovaps xmm7, [rsp+0x70]
000079a3731e0d6f  vmovaps xmm8, [rsp+0x80]
000079a3731e0d78  vmovaps xmm9, [rsp+0x90]
000079a3731e0d81  vmovaps xmm11, [rsp+0xA0]
000079a3731e0d8a  vmovaps xmm12, [rsp+0xB0]
000079a3731e0d93  vmovaps xmm13, [rsp+0xC0]
000079a3731e0d9c  vmovaps xmm14, [rsp+0xD0]
000079a3731e0da5  vmovaps xmm15, [rsp+0xE0]
000079a3731e0dae  add rsp, 0xF0
000079a3731e0db5  pop r11
000079a3731e0db7  pop r10
000079a3731e0db9  pop r9
000079a3731e0dbb  pop r8
000079a3731e0dbd  pop rsi
000079a3731e0dbe  pop rdi
000079a3731e0dbf  pop rdx
000079a3731e0dc0  pop rcx
000079a3731e0dc1  pop rax
000079a3731e0dc2  add rsp, 0x08
000079a3731e0dc6  jmp 0x000079A3731DC6CD
000079a3731e0dcb  sub rsp, 0x08
000079a3731e0dcf  push rax
000079a3731e0dd0  push rcx
000079a3731e0dd1  push rdx
000079a3731e0dd2  push rdi
000079a3731e0dd3  push rsi
000079a3731e0dd4  push r8
000079a3731e0dd6  push r9
000079a3731e0dd8  push r10
000079a3731e0dda  push r11
000079a3731e0ddc  sub rsp, 0xF0
000079a3731e0de3  vmovaps [rsp], xmm0
000079a3731e0de8  vmovaps [rsp+0x10], xmm1
000079a3731e0dee  vmovaps [rsp+0x20], xmm2
000079a3731e0df4  vmovaps [rsp+0x30], xmm3
000079a3731e0dfa  vmovaps [rsp+0x40], xmm4
000079a3731e0e00  vmovaps [rsp+0x50], xmm5
000079a3731e0e06  vmovaps [rsp+0x60], xmm6
000079a3731e0e0c  vmovaps [rsp+0x70], xmm7
000079a3731e0e12  vmovaps [rsp+0x80], xmm8
000079a3731e0e1b  vmovaps [rsp+0x90], xmm9
000079a3731e0e24  vmovaps [rsp+0xA0], xmm10
000079a3731e0e2d  vmovaps [rsp+0xB0], xmm11
000079a3731e0e36  vmovaps [rsp+0xC0], xmm13
000079a3731e0e3f  vmovaps [rsp+0xD0], xmm14
000079a3731e0e48  vmovaps [rsp+0xE0], xmm15
000079a3731e0e51  sub rsp, 0x30
000079a3731e0e55  movaps [rsp], xmm12
000079a3731e0e5a  movaps [rsp+0x10], xmm14
000079a3731e0e60  movaps [rsp+0x20], xmm1
000079a3731e0e65  lea rdi, [rsp]
000079a3731e0e69  mov esi, 0x00
000079a3731e0e6e  mov rax, 0x64F127B95530
000079a3731e0e78  call rax
000079a3731e0e7a  movaps xmm12, [rsp]
000079a3731e0e7f  add rsp, 0x30
000079a3731e0e83  vmovaps xmm0, [rsp]
000079a3731e0e88  vmovaps xmm1, [rsp+0x10]
000079a3731e0e8e  vmovaps xmm2, [rsp+0x20]
000079a3731e0e94  vmovaps xmm3, [rsp+0x30]
000079a3731e0e9a  vmovaps xmm4, [rsp+0x40]
000079a3731e0ea0  vmovaps xmm5, [rsp+0x50]
000079a3731e0ea6  vmovaps xmm6, [rsp+0x60]
000079a3731e0eac  vmovaps xmm7, [rsp+0x70]
000079a3731e0eb2  vmovaps xmm8, [rsp+0x80]
000079a3731e0ebb  vmovaps xmm9, [rsp+0x90]
000079a3731e0ec4  vmovaps xmm10, [rsp+0xA0]
000079a3731e0ecd  vmovaps xmm11, [rsp+0xB0]
000079a3731e0ed6  vmovaps xmm13, [rsp+0xC0]
000079a3731e0edf  vmovaps xmm14, [rsp+0xD0]
000079a3731e0ee8  vmovaps xmm15, [rsp+0xE0]
000079a3731e0ef1  add rsp, 0xF0
000079a3731e0ef8  pop r11
000079a3731e0efa  pop r10
000079a3731e0efc  pop r9
000079a3731e0efe  pop r8
000079a3731e0f00  pop rsi
000079a3731e0f01  pop rdi
000079a3731e0f02  pop rdx
000079a3731e0f03  pop rcx
000079a3731e0f04  pop rax
000079a3731e0f05  add rsp, 0x08
000079a3731e0f09  jmp 0x000079A3731DC6FC
000079a3731e0f0e  sub rsp, 0x08
000079a3731e0f12  push rax
000079a3731e0f13  push rcx
000079a3731e0f14  push rdx
000079a3731e0f15  push rdi
000079a3731e0f16  push rsi
000079a3731e0f17  push r8
000079a3731e0f19  push r9
000079a3731e0f1b  push r10
000079a3731e0f1d  push r11
000079a3731e0f1f  sub rsp, 0xF0
000079a3731e0f26  vmovaps [rsp], xmm0
000079a3731e0f2b  vmovaps [rsp+0x10], xmm1
000079a3731e0f31  vmovaps [rsp+0x20], xmm2
000079a3731e0f37  vmovaps [rsp+0x30], xmm3
000079a3731e0f3d  vmovaps [rsp+0x40], xmm4
000079a3731e0f43  vmovaps [rsp+0x50], xmm5
000079a3731e0f49  vmovaps [rsp+0x60], xmm6
000079a3731e0f4f  vmovaps [rsp+0x70], xmm7
000079a3731e0f55  vmovaps [rsp+0x80], xmm8
000079a3731e0f5e  vmovaps [rsp+0x90], xmm9
000079a3731e0f67  vmovaps [rsp+0xA0], xmm10
000079a3731e0f70  vmovaps [rsp+0xB0], xmm11
000079a3731e0f79  vmovaps [rsp+0xC0], xmm12
000079a3731e0f82  vmovaps [rsp+0xD0], xmm13
000079a3731e0f8b  vmovaps [rsp+0xE0], xmm15
000079a3731e0f94  sub rsp, 0x30
000079a3731e0f98  movaps [rsp], xmm14
000079a3731e0f9d  movaps [rsp+0x10], xmm9
000079a3731e0fa3  movaps [rsp+0x20], xmm1
000079a3731e0fa8  lea rdi, [rsp]
000079a3731e0fac  mov esi, 0x00
000079a3731e0fb1  mov rax, 0x64F127B95530
000079a3731e0fbb  call rax
000079a3731e0fbd  movaps xmm14, [rsp]
000079a3731e0fc2  add rsp, 0x30
000079a3731e0fc6  vmovaps xmm0, [rsp]
000079a3731e0fcb  vmovaps xmm1, [rsp+0x10]
000079a3731e0fd1  vmovaps xmm2, [rsp+0x20]
000079a3731e0fd7  vmovaps xmm3, [rsp+0x30]
000079a3731e0fdd  vmovaps xmm4, [rsp+0x40]
000079a3731e0fe3  vmovaps xmm5, [rsp+0x50]
000079a3731e0fe9  vmovaps xmm6, [rsp+0x60]
000079a3731e0fef  vmovaps xmm7, [rsp+0x70]
000079a3731e0ff5  vmovaps xmm8, [rsp+0x80]
000079a3731e0ffe  vmovaps xmm9, [rsp+0x90]
000079a3731e1007  vmovaps xmm10, [rsp+0xA0]
000079a3731e1010  vmovaps xmm11, [rsp+0xB0]
000079a3731e1019  vmovaps xmm12, [rsp+0xC0]
000079a3731e1022  vmovaps xmm13, [rsp+0xD0]
000079a3731e102b  vmovaps xmm15, [rsp+0xE0]
000079a3731e1034  add rsp, 0xF0
000079a3731e103b  pop r11
000079a3731e103d  pop r10
000079a3731e103f  pop r9
000079a3731e1041  pop r8
000079a3731e1043  pop rsi
000079a3731e1044  pop rdi
000079a3731e1045  pop rdx
000079a3731e1046  pop rcx
000079a3731e1047  pop rax
000079a3731e1048  add rsp, 0x08
000079a3731e104c  jmp 0x000079A3731DC72B
000079a3731e1051  sub rsp, 0x08
000079a3731e1055  push rax
000079a3731e1056  push rcx
000079a3731e1057  push rdx
000079a3731e1058  push rdi
000079a3731e1059  push rsi
000079a3731e105a  push r8
000079a3731e105c  push r9
000079a3731e105e  push r10
000079a3731e1060  push r11
000079a3731e1062  sub rsp, 0xF0
000079a3731e1069  vmovaps [rsp], xmm0
000079a3731e106e  vmovaps [rsp+0x10], xmm2
000079a3731e1074  vmovaps [rsp+0x20], xmm3
000079a3731e107a  vmovaps [rsp+0x30], xmm4
000079a3731e1080  vmovaps [rsp+0x40], xmm5
000079a3731e1086  vmovaps [rsp+0x50], xmm6
000079a3731e108c  vmovaps [rsp+0x60], xmm7
000079a3731e1092  vmovaps [rsp+0x70], xmm8
000079a3731e1098  vmovaps [rsp+0x80], xmm9
000079a3731e10a1  vmovaps [rsp+0x90], xmm10
000079a3731e10aa  vmovaps [rsp+0xA0], xmm11
000079a3731e10b3  vmovaps [rsp+0xB0], xmm12
000079a3731e10bc  vmovaps [rsp+0xC0], xmm13
000079a3731e10c5  vmovaps [rsp+0xD0], xmm14
000079a3731e10ce  vmovaps [rsp+0xE0], xmm15
000079a3731e10d7  sub rsp, 0x30
000079a3731e10db  movaps [rsp], xmm1
000079a3731e10df  movaps [rsp+0x10], xmm13
000079a3731e10e5  movaps [rsp+0x20], xmm8
000079a3731e10eb  lea rdi, [rsp]
000079a3731e10ef  mov esi, 0x00
000079a3731e10f4  mov rax, 0x64F127B95530
000079a3731e10fe  call rax
000079a3731e1100  movaps xmm1, [rsp]
000079a3731e1104  add rsp, 0x30
000079a3731e1108  vmovaps xmm0, [rsp]
000079a3731e110d  vmovaps xmm2, [rsp+0x10]
000079a3731e1113  vmovaps xmm3, [rsp+0x20]
000079a3731e1119  vmovaps xmm4, [rsp+0x30]
000079a3731e111f  vmovaps xmm5, [rsp+0x40]
000079a3731e1125  vmovaps xmm6, [rsp+0x50]
000079a3731e112b  vmovaps xmm7, [rsp+0x60]
000079a3731e1131  vmovaps xmm8, [rsp+0x70]
000079a3731e1137  vmovaps xmm9, [rsp+0x80]
000079a3731e1140  vmovaps xmm10, [rsp+0x90]
000079a3731e1149  vmovaps xmm11, [rsp+0xA0]
000079a3731e1152  vmovaps xmm12, [rsp+0xB0]
000079a3731e115b  vmovaps xmm13, [rsp+0xC0]
000079a3731e1164  vmovaps xmm14, [rsp+0xD0]
000079a3731e116d  vmovaps xmm15, [rsp+0xE0]
000079a3731e1176  add rsp, 0xF0
000079a3731e117d  pop r11
000079a3731e117f  pop r10
000079a3731e1181  pop r9
000079a3731e1183  pop r8
000079a3731e1185  pop rsi
000079a3731e1186  pop rdi
000079a3731e1187  pop rdx
000079a3731e1188  pop rcx
000079a3731e1189  pop rax
000079a3731e118a  add rsp, 0x08
000079a3731e118e  jmp 0x000079A3731DC74D
000079a3731e1193  call 0x000079A37300C260
000079a3731e1198  jmp 0x000079A3731DC75B
000079a3731e119d  call 0x000079A3730BD750
000079a3731e11a2  jmp 0x000079A3731DC765
000079a3731e11a7  sub rsp, 0x08
000079a3731e11ab  push rax
000079a3731e11ac  push rcx
000079a3731e11ad  push rdx
000079a3731e11ae  push rdi
000079a3731e11af  push rsi
000079a3731e11b0  push r8
000079a3731e11b2  push r9
000079a3731e11b4  push r10
000079a3731e11b6  push r11
000079a3731e11b8  sub rsp, 0xF0
000079a3731e11bf  vmovaps [rsp], xmm0
000079a3731e11c4  vmovaps [rsp+0x10], xmm1
000079a3731e11ca  vmovaps [rsp+0x20], xmm2
000079a3731e11d0  vmovaps [rsp+0x30], xmm3
000079a3731e11d6  vmovaps [rsp+0x40], xmm4
000079a3731e11dc  vmovaps [rsp+0x50], xmm5
000079a3731e11e2  vmovaps [rsp+0x60], xmm6
000079a3731e11e8  vmovaps [rsp+0x70], xmm7
000079a3731e11ee  vmovaps [rsp+0x80], xmm9
000079a3731e11f7  vmovaps [rsp+0x90], xmm10
000079a3731e1200  vmovaps [rsp+0xA0], xmm11
000079a3731e1209  vmovaps [rsp+0xB0], xmm12
000079a3731e1212  vmovaps [rsp+0xC0], xmm13
000079a3731e121b  vmovaps [rsp+0xD0], xmm14
000079a3731e1224  vmovaps [rsp+0xE0], xmm15
000079a3731e122d  sub rsp, 0x30
000079a3731e1231  movaps [rsp], xmm8
000079a3731e1236  movaps [rsp+0x10], xmm15
000079a3731e123c  movaps [rsp+0x20], xmm7
000079a3731e1241  lea rdi, [rsp]
000079a3731e1245  mov esi, 0x00
000079a3731e124a  mov rax, 0x64F127B95530
000079a3731e1254  call rax
000079a3731e1256  movaps xmm8, [rsp]
000079a3731e125b  add rsp, 0x30
000079a3731e125f  vmovaps xmm0, [rsp]
000079a3731e1264  vmovaps xmm1, [rsp+0x10]
000079a3731e126a  vmovaps xmm2, [rsp+0x20]
000079a3731e1270  vmovaps xmm3, [rsp+0x30]
000079a3731e1276  vmovaps xmm4, [rsp+0x40]
000079a3731e127c  vmovaps xmm5, [rsp+0x50]
000079a3731e1282  vmovaps xmm6, [rsp+0x60]
000079a3731e1288  vmovaps xmm7, [rsp+0x70]
000079a3731e128e  vmovaps xmm9, [rsp+0x80]
000079a3731e1297  vmovaps xmm10, [rsp+0x90]
000079a3731e12a0  vmovaps xmm11, [rsp+0xA0]
000079a3731e12a9  vmovaps xmm12, [rsp+0xB0]
000079a3731e12b2  vmovaps xmm13, [rsp+0xC0]
000079a3731e12bb  vmovaps xmm14, [rsp+0xD0]
000079a3731e12c4  vmovaps xmm15, [rsp+0xE0]
000079a3731e12cd  add rsp, 0xF0
000079a3731e12d4  pop r11
000079a3731e12d6  pop r10
000079a3731e12d8  pop r9
000079a3731e12da  pop r8
000079a3731e12dc  pop rsi
000079a3731e12dd  pop rdi
000079a3731e12de  pop rdx
000079a3731e12df  pop rcx
000079a3731e12e0  pop rax
000079a3731e12e1  add rsp, 0x08
000079a3731e12e5  jmp 0x000079A3731DC787
000079a3731e12ea  sub rsp, 0x08
000079a3731e12ee  push rax
000079a3731e12ef  push rcx
000079a3731e12f0  push rdx
000079a3731e12f1  push rdi
000079a3731e12f2  push rsi
000079a3731e12f3  push r8
000079a3731e12f5  push r9
000079a3731e12f7  push r10
000079a3731e12f9  push r11
000079a3731e12fb  sub rsp, 0xF0
000079a3731e1302  vmovaps [rsp], xmm0
000079a3731e1307  vmovaps [rsp+0x10], xmm1
000079a3731e130d  vmovaps [rsp+0x20], xmm2
000079a3731e1313  vmovaps [rsp+0x30], xmm3
000079a3731e1319  vmovaps [rsp+0x40], xmm4
000079a3731e131f  vmovaps [rsp+0x50], xmm5
000079a3731e1325  vmovaps [rsp+0x60], xmm6
000079a3731e132b  vmovaps [rsp+0x70], xmm8
000079a3731e1331  vmovaps [rsp+0x80], xmm9
000079a3731e133a  vmovaps [rsp+0x90], xmm10
000079a3731e1343  vmovaps [rsp+0xA0], xmm11
000079a3731e134c  vmovaps [rsp+0xB0], xmm12
000079a3731e1355  vmovaps [rsp+0xC0], xmm13
000079a3731e135e  vmovaps [rsp+0xD0], xmm14
000079a3731e1367  vmovaps [rsp+0xE0], xmm15
000079a3731e1370  sub rsp, 0x30
000079a3731e1374  movaps [rsp], xmm7
000079a3731e1378  movaps [rsp+0x10], xmm9
000079a3731e137e  movaps [rsp+0x20], xmm15
000079a3731e1384  lea rdi, [rsp]
000079a3731e1388  mov esi, 0x00
000079a3731e138d  mov rax, 0x64F127B95530
000079a3731e1397  call rax
000079a3731e1399  movaps xmm7, [rsp]
000079a3731e139d  add rsp, 0x30
000079a3731e13a1  vmovaps xmm0, [rsp]
000079a3731e13a6  vmovaps xmm1, [rsp+0x10]
000079a3731e13ac  vmovaps xmm2, [rsp+0x20]
000079a3731e13b2  vmovaps xmm3, [rsp+0x30]
000079a3731e13b8  vmovaps xmm4, [rsp+0x40]
000079a3731e13be  vmovaps xmm5, [rsp+0x50]
000079a3731e13c4  vmovaps xmm6, [rsp+0x60]
000079a3731e13ca  vmovaps xmm8, [rsp+0x70]
000079a3731e13d0  vmovaps xmm9, [rsp+0x80]
000079a3731e13d9  vmovaps xmm10, [rsp+0x90]
000079a3731e13e2  vmovaps xmm11, [rsp+0xA0]
000079a3731e13eb  vmovaps xmm12, [rsp+0xB0]
000079a3731e13f4  vmovaps xmm13, [rsp+0xC0]
000079a3731e13fd  vmovaps xmm14, [rsp+0xD0]
000079a3731e1406  vmovaps xmm15, [rsp+0xE0]
000079a3731e140f  add rsp, 0xF0
000079a3731e1416  pop r11
000079a3731e1418  pop r10
000079a3731e141a  pop r9
000079a3731e141c  pop r8
000079a3731e141e  pop rsi
000079a3731e141f  pop rdi
000079a3731e1420  pop rdx
000079a3731e1421  pop rcx
000079a3731e1422  pop rax
000079a3731e1423  add rsp, 0x08
000079a3731e1427  jmp 0x000079A3731DC7B4
000079a3731e142c  sub rsp, 0x08
000079a3731e1430  push rax
000079a3731e1431  push rcx
000079a3731e1432  push rdx
000079a3731e1433  push rdi
000079a3731e1434  push rsi
000079a3731e1435  push r8
000079a3731e1437  push r9
000079a3731e1439  push r10
000079a3731e143b  push r11
000079a3731e143d  sub rsp, 0xF0
000079a3731e1444  vmovaps [rsp], xmm0
000079a3731e1449  vmovaps [rsp+0x10], xmm1
000079a3731e144f  vmovaps [rsp+0x20], xmm2
000079a3731e1455  vmovaps [rsp+0x30], xmm3
000079a3731e145b  vmovaps [rsp+0x40], xmm4
000079a3731e1461  vmovaps [rsp+0x50], xmm5
000079a3731e1467  vmovaps [rsp+0x60], xmm6
000079a3731e146d  vmovaps [rsp+0x70], xmm7
000079a3731e1473  vmovaps [rsp+0x80], xmm8
000079a3731e147c  vmovaps [rsp+0x90], xmm10
000079a3731e1485  vmovaps [rsp+0xA0], xmm11
000079a3731e148e  vmovaps [rsp+0xB0], xmm12
000079a3731e1497  vmovaps [rsp+0xC0], xmm13
000079a3731e14a0  vmovaps [rsp+0xD0], xmm14
000079a3731e14a9  vmovaps [rsp+0xE0], xmm15
000079a3731e14b2  sub rsp, 0x30
000079a3731e14b6  movaps [rsp], xmm9
000079a3731e14bb  movaps [rsp+0x10], xmm13
000079a3731e14c1  movaps [rsp+0x20], xmm15
000079a3731e14c7  lea rdi, [rsp]
000079a3731e14cb  mov esi, 0x00
000079a3731e14d0  mov rax, 0x64F127B95530
000079a3731e14da  call rax
000079a3731e14dc  movaps xmm9, [rsp]
000079a3731e14e1  add rsp, 0x30
000079a3731e14e5  vmovaps xmm0, [rsp]
000079a3731e14ea  vmovaps xmm1, [rsp+0x10]
000079a3731e14f0  vmovaps xmm2, [rsp+0x20]
000079a3731e14f6  vmovaps xmm3, [rsp+0x30]
000079a3731e14fc  vmovaps xmm4, [rsp+0x40]
000079a3731e1502  vmovaps xmm5, [rsp+0x50]
000079a3731e1508  vmovaps xmm6, [rsp+0x60]
000079a3731e150e  vmovaps xmm7, [rsp+0x70]
000079a3731e1514  vmovaps xmm8, [rsp+0x80]
000079a3731e151d  vmovaps xmm10, [rsp+0x90]
000079a3731e1526  vmovaps xmm11, [rsp+0xA0]
000079a3731e152f  vmovaps xmm12, [rsp+0xB0]
000079a3731e1538  vmovaps xmm13, [rsp+0xC0]
000079a3731e1541  vmovaps xmm14, [rsp+0xD0]
000079a3731e154a  vmovaps xmm15, [rsp+0xE0]
000079a3731e1553  add rsp, 0xF0
000079a3731e155a  pop r11
000079a3731e155c  pop r10
000079a3731e155e  pop r9
000079a3731e1560  pop r8
000079a3731e1562  pop rsi
000079a3731e1563  pop rdi
000079a3731e1564  pop rdx
000079a3731e1565  pop rcx
000079a3731e1566  pop rax
000079a3731e1567  add rsp, 0x08
000079a3731e156b  jmp 0x000079A3731DC7E2
000079a3731e1570  sub rsp, 0x08
000079a3731e1574  push rax
000079a3731e1575  push rcx
000079a3731e1576  push rdx
000079a3731e1577  push rdi
000079a3731e1578  push rsi
000079a3731e1579  push r8
000079a3731e157b  push r9
000079a3731e157d  push r10
000079a3731e157f  push r11
000079a3731e1581  sub rsp, 0xF0
000079a3731e1588  vmovaps [rsp], xmm0
000079a3731e158d  vmovaps [rsp+0x10], xmm1
000079a3731e1593  vmovaps [rsp+0x20], xmm2
000079a3731e1599  vmovaps [rsp+0x30], xmm3
000079a3731e159f  vmovaps [rsp+0x40], xmm4
000079a3731e15a5  vmovaps [rsp+0x50], xmm5
000079a3731e15ab  vmovaps [rsp+0x60], xmm6
000079a3731e15b1  vmovaps [rsp+0x70], xmm7
000079a3731e15b7  vmovaps [rsp+0x80], xmm8
000079a3731e15c0  vmovaps [rsp+0x90], xmm9
000079a3731e15c9  vmovaps [rsp+0xA0], xmm10
000079a3731e15d2  vmovaps [rsp+0xB0], xmm11
000079a3731e15db  vmovaps [rsp+0xC0], xmm12
000079a3731e15e4  vmovaps [rsp+0xD0], xmm13
000079a3731e15ed  vmovaps [rsp+0xE0], xmm14
000079a3731e15f6  sub rsp, 0x30
000079a3731e15fa  movaps [rsp], xmm15
000079a3731e15ff  movaps [rsp+0x10], xmm11
000079a3731e1605  movaps [rsp+0x20], xmm12
000079a3731e160b  lea rdi, [rsp]
000079a3731e160f  mov esi, 0x00
000079a3731e1614  mov rax, 0x64F127B95530
000079a3731e161e  call rax
000079a3731e1620  movaps xmm15, [rsp]
000079a3731e1625  add rsp, 0x30
000079a3731e1629  vmovaps xmm0, [rsp]
000079a3731e162e  vmovaps xmm1, [rsp+0x10]
000079a3731e1634  vmovaps xmm2, [rsp+0x20]
000079a3731e163a  vmovaps xmm3, [rsp+0x30]
000079a3731e1640  vmovaps xmm4, [rsp+0x40]
000079a3731e1646  vmovaps xmm5, [rsp+0x50]
000079a3731e164c  vmovaps xmm6, [rsp+0x60]
000079a3731e1652  vmovaps xmm7, [rsp+0x70]
000079a3731e1658  vmovaps xmm8, [rsp+0x80]
000079a3731e1661  vmovaps xmm9, [rsp+0x90]
000079a3731e166a  vmovaps xmm10, [rsp+0xA0]
000079a3731e1673  vmovaps xmm11, [rsp+0xB0]
000079a3731e167c  vmovaps xmm12, [rsp+0xC0]
000079a3731e1685  vmovaps xmm13, [rsp+0xD0]
000079a3731e168e  vmovaps xmm14, [rsp+0xE0]
000079a3731e1697  add rsp, 0xF0
000079a3731e169e  pop r11
000079a3731e16a0  pop r10
000079a3731e16a2  pop r9
000079a3731e16a4  pop r8
000079a3731e16a6  pop rsi
000079a3731e16a7  pop rdi
000079a3731e16a8  pop rdx
000079a3731e16a9  pop rcx
000079a3731e16aa  pop rax
000079a3731e16ab  add rsp, 0x08
000079a3731e16af  jmp 0x000079A3731DC7FD
000079a3731e16b4  sub rsp, 0x08
000079a3731e16b8  push rax
000079a3731e16b9  push rcx
000079a3731e16ba  push rdx
000079a3731e16bb  push rdi
000079a3731e16bc  push rsi
000079a3731e16bd  push r8
000079a3731e16bf  push r9
000079a3731e16c1  push r10
000079a3731e16c3  push r11
000079a3731e16c5  sub rsp, 0xF0
000079a3731e16cc  vmovaps [rsp], xmm0
000079a3731e16d1  vmovaps [rsp+0x10], xmm1
000079a3731e16d7  vmovaps [rsp+0x20], xmm2
000079a3731e16dd  vmovaps [rsp+0x30], xmm3
000079a3731e16e3  vmovaps [rsp+0x40], xmm4
000079a3731e16e9  vmovaps [rsp+0x50], xmm5
000079a3731e16ef  vmovaps [rsp+0x60], xmm6
000079a3731e16f5  vmovaps [rsp+0x70], xmm7
000079a3731e16fb  vmovaps [rsp+0x80], xmm8
000079a3731e1704  vmovaps [rsp+0x90], xmm9
000079a3731e170d  vmovaps [rsp+0xA0], xmm10
000079a3731e1716  vmovaps [rsp+0xB0], xmm11
000079a3731e171f  vmovaps [rsp+0xC0], xmm12
000079a3731e1728  vmovaps [rsp+0xD0], xmm14
000079a3731e1731  vmovaps [rsp+0xE0], xmm15
000079a3731e173a  sub rsp, 0x30
000079a3731e173e  movaps [rsp], xmm13
000079a3731e1743  movaps [rsp+0x10], xmm10
000079a3731e1749  movaps [rsp+0x20], xmm14
000079a3731e174f  lea rdi, [rsp]
000079a3731e1753  mov esi, 0x00
000079a3731e1758  mov rax, 0x64F127B95530
000079a3731e1762  call rax
000079a3731e1764  movaps xmm13, [rsp]
000079a3731e1769  add rsp, 0x30
000079a3731e176d  vmovaps xmm0, [rsp]
000079a3731e1772  vmovaps xmm1, [rsp+0x10]
000079a3731e1778  vmovaps xmm2, [rsp+0x20]
000079a3731e177e  vmovaps xmm3, [rsp+0x30]
000079a3731e1784  vmovaps xmm4, [rsp+0x40]
000079a3731e178a  vmovaps xmm5, [rsp+0x50]
000079a3731e1790  vmovaps xmm6, [rsp+0x60]
000079a3731e1796  vmovaps xmm7, [rsp+0x70]
000079a3731e179c  vmovaps xmm8, [rsp+0x80]
000079a3731e17a5  vmovaps xmm9, [rsp+0x90]
000079a3731e17ae  vmovaps xmm10, [rsp+0xA0]
000079a3731e17b7  vmovaps xmm11, [rsp+0xB0]
000079a3731e17c0  vmovaps xmm12, [rsp+0xC0]
000079a3731e17c9  vmovaps xmm14, [rsp+0xD0]
000079a3731e17d2  vmovaps xmm15, [rsp+0xE0]
000079a3731e17db  add rsp, 0xF0
000079a3731e17e2  pop r11
000079a3731e17e4  pop r10
000079a3731e17e6  pop r9
000079a3731e17e8  pop r8
000079a3731e17ea  pop rsi
000079a3731e17eb  pop rdi
000079a3731e17ec  pop rdx
000079a3731e17ed  pop rcx
000079a3731e17ee  pop rax
000079a3731e17ef  add rsp, 0x08
000079a3731e17f3  jmp 0x000079A3731DC820
000079a3731e17f8  sub rsp, 0x08
000079a3731e17fc  push rax
000079a3731e17fd  push rcx
000079a3731e17fe  push rdx
000079a3731e17ff  push rdi
000079a3731e1800  push rsi
000079a3731e1801  push r8
000079a3731e1803  push r9
000079a3731e1805  push r10
000079a3731e1807  push r11
000079a3731e1809  sub rsp, 0xF0
000079a3731e1810  vmovaps [rsp], xmm0
000079a3731e1815  vmovaps [rsp+0x10], xmm1
000079a3731e181b  vmovaps [rsp+0x20], xmm2
000079a3731e1821  vmovaps [rsp+0x30], xmm3
000079a3731e1827  vmovaps [rsp+0x40], xmm4
000079a3731e182d  vmovaps [rsp+0x50], xmm5
000079a3731e1833  vmovaps [rsp+0x60], xmm6
000079a3731e1839  vmovaps [rsp+0x70], xmm7
000079a3731e183f  vmovaps [rsp+0x80], xmm8
000079a3731e1848  vmovaps [rsp+0x90], xmm9
000079a3731e1851  vmovaps [rsp+0xA0], xmm10
000079a3731e185a  vmovaps [rsp+0xB0], xmm11
000079a3731e1863  vmovaps [rsp+0xC0], xmm12
000079a3731e186c  vmovaps [rsp+0xD0], xmm13
000079a3731e1875  vmovaps [rsp+0xE0], xmm15
000079a3731e187e  sub rsp, 0x30
000079a3731e1882  movaps [rsp], xmm14
000079a3731e1887  movaps [rsp+0x10], xmm1
000079a3731e188c  movaps [rsp+0x20], xmm7
000079a3731e1891  lea rdi, [rsp]
000079a3731e1895  mov esi, 0x00
000079a3731e189a  mov rax, 0x64F127B95530
000079a3731e18a4  call rax
000079a3731e18a6  movaps xmm14, [rsp]
000079a3731e18ab  add rsp, 0x30
000079a3731e18af  vmovaps xmm0, [rsp]
000079a3731e18b4  vmovaps xmm1, [rsp+0x10]
000079a3731e18ba  vmovaps xmm2, [rsp+0x20]
000079a3731e18c0  vmovaps xmm3, [rsp+0x30]
000079a3731e18c6  vmovaps xmm4, [rsp+0x40]
000079a3731e18cc  vmovaps xmm5, [rsp+0x50]
000079a3731e18d2  vmovaps xmm6, [rsp+0x60]
000079a3731e18d8  vmovaps xmm7, [rsp+0x70]
000079a3731e18de  vmovaps xmm8, [rsp+0x80]
000079a3731e18e7  vmovaps xmm9, [rsp+0x90]
000079a3731e18f0  vmovaps xmm10, [rsp+0xA0]
000079a3731e18f9  vmovaps xmm11, [rsp+0xB0]
000079a3731e1902  vmovaps xmm12, [rsp+0xC0]
000079a3731e190b  vmovaps xmm13, [rsp+0xD0]
000079a3731e1914  vmovaps xmm15, [rsp+0xE0]
000079a3731e191d  add rsp, 0xF0
000079a3731e1924  pop r11
000079a3731e1926  pop r10
000079a3731e1928  pop r9
000079a3731e192a  pop r8
000079a3731e192c  pop rsi
000079a3731e192d  pop rdi
000079a3731e192e  pop rdx
000079a3731e192f  pop rcx
000079a3731e1930  pop rax
000079a3731e1931  add rsp, 0x08
000079a3731e1935  jmp 0x000079A3731DC843
000079a3731e193a  sub rsp, 0x08
000079a3731e193e  push rax
000079a3731e193f  push rcx
000079a3731e1940  push rdx
000079a3731e1941  push rdi
000079a3731e1942  push rsi
000079a3731e1943  push r8
000079a3731e1945  push r9
000079a3731e1947  push r10
000079a3731e1949  push r11
000079a3731e194b  sub rsp, 0xF0
000079a3731e1952  vmovaps [rsp], xmm0
000079a3731e1957  vmovaps [rsp+0x10], xmm2
000079a3731e195d  vmovaps [rsp+0x20], xmm3
000079a3731e1963  vmovaps [rsp+0x30], xmm4
000079a3731e1969  vmovaps [rsp+0x40], xmm5
000079a3731e196f  vmovaps [rsp+0x50], xmm6
000079a3731e1975  vmovaps [rsp+0x60], xmm7
000079a3731e197b  vmovaps [rsp+0x70], xmm8
000079a3731e1981  vmovaps [rsp+0x80], xmm9
000079a3731e198a  vmovaps [rsp+0x90], xmm10
000079a3731e1993  vmovaps [rsp+0xA0], xmm11
000079a3731e199c  vmovaps [rsp+0xB0], xmm12
000079a3731e19a5  vmovaps [rsp+0xC0], xmm13
000079a3731e19ae  vmovaps [rsp+0xD0], xmm14
000079a3731e19b7  vmovaps [rsp+0xE0], xmm15
000079a3731e19c0  sub rsp, 0x30
000079a3731e19c4  movaps [rsp], xmm1
000079a3731e19c8  movaps [rsp+0x10], xmm8
000079a3731e19ce  movaps [rsp+0x20], xmm9
000079a3731e19d4  lea rdi, [rsp]
000079a3731e19d8  mov esi, 0x00
000079a3731e19dd  mov rax, 0x64F127B95530
000079a3731e19e7  call rax
000079a3731e19e9  movaps xmm1, [rsp]
000079a3731e19ed  add rsp, 0x30
000079a3731e19f1  vmovaps xmm0, [rsp]
000079a3731e19f6  vmovaps xmm2, [rsp+0x10]
000079a3731e19fc  vmovaps xmm3, [rsp+0x20]
000079a3731e1a02  vmovaps xmm4, [rsp+0x30]
000079a3731e1a08  vmovaps xmm5, [rsp+0x40]
000079a3731e1a0e  vmovaps xmm6, [rsp+0x50]
000079a3731e1a14  vmovaps xmm7, [rsp+0x60]
000079a3731e1a1a  vmovaps xmm8, [rsp+0x70]
000079a3731e1a20  vmovaps xmm9, [rsp+0x80]
000079a3731e1a29  vmovaps xmm10, [rsp+0x90]
000079a3731e1a32  vmovaps xmm11, [rsp+0xA0]
000079a3731e1a3b  vmovaps xmm12, [rsp+0xB0]
000079a3731e1a44  vmovaps xmm13, [rsp+0xC0]
000079a3731e1a4d  vmovaps xmm14, [rsp+0xD0]
000079a3731e1a56  vmovaps xmm15, [rsp+0xE0]
000079a3731e1a5f  add rsp, 0xF0
000079a3731e1a66  pop r11
000079a3731e1a68  pop r10
000079a3731e1a6a  pop r9
000079a3731e1a6c  pop r8
000079a3731e1a6e  pop rsi
000079a3731e1a6f  pop rdi
000079a3731e1a70  pop rdx
000079a3731e1a71  pop rcx
000079a3731e1a72  pop rax
000079a3731e1a73  add rsp, 0x08
000079a3731e1a77  jmp 0x000079A3731DC865
000079a3731e1a7c  call 0x000079A3730E5940
000079a3731e1a81  jmp 0x000079A3731DC873
000079a3731e1a86  call 0x000079A37300C380
000079a3731e1a8b  jmp 0x000079A3731DC87D
000079a3731e1a90  call 0x000079A37300D600
000079a3731e1a95  jmp 0x000079A3731DC887
000079a3731e1a9a  call 0x000079A372FFF540
000079a3731e1a9f  jmp 0x000079A3731DC891
000079a3731e1aa4  int3
000079a3731e1aa5  nop [rax+rax*1], ax
000079a3731e1aae  nop
000079a3731e1ab0  mov rax, [r15+0xF8]
000079a3731e1ab7  lea r14, [rax+0x140]
000079a3731e1abe  mov r12, [r13+r14*1]
000079a3731e1ac3  mov [r15+0xE8], r12
000079a3731e1aca  lea r14, [rax+0x130]
000079a3731e1ad1  mov r12, [r13+r14*1]
000079a3731e1ad6  lea r14, [rax+0x138]
000079a3731e1add  mov r11, [r13+r14*1]
000079a3731e1ae2  movq xmm1, r12
000079a3731e1ae7  movq xmm15, r11
000079a3731e1aec  movq xmm1, xmm1
000079a3731e1af0  movq xmm1, xmm1
000079a3731e1af4  movaps [r15+0x1A0], xmm1
000079a3731e1afc  movq xmm15, xmm15
000079a3731e1b01  movq xmm15, xmm15
000079a3731e1b06  movaps [r15+0x190], xmm15
000079a3731e1b0e  lea r14, [rax+0x120]
000079a3731e1b15  mov r12, [r13+r14*1]
000079a3731e1b1a  lea r14, [rax+0x128]
000079a3731e1b21  mov r11, [r13+r14*1]
000079a3731e1b26  movq xmm1, r12
000079a3731e1b2b  movq xmm15, r11
000079a3731e1b30  movq xmm1, xmm1
000079a3731e1b34  movq xmm1, xmm1
000079a3731e1b38  movaps [r15+0x1C0], xmm1
000079a3731e1b40  movq xmm15, xmm15
000079a3731e1b45  movq xmm15, xmm15
000079a3731e1b4a  movaps [r15+0x1B0], xmm15
000079a3731e1b52  lea r14, [rax+0x110]
000079a3731e1b59  mov r12, [r13+r14*1]
000079a3731e1b5e  lea r14, [rax+0x118]
000079a3731e1b65  mov r11, [r13+r14*1]
000079a3731e1b6a  movq xmm1, r12
000079a3731e1b6f  movq xmm15, r11
000079a3731e1b74  movq xmm1, xmm1
000079a3731e1b78  movq xmm1, xmm1
000079a3731e1b7c  movaps [r15+0x1E0], xmm1
000079a3731e1b84  movq xmm15, xmm15
000079a3731e1b89  movq xmm15, xmm15
000079a3731e1b8e  movaps [r15+0x1D0], xmm15
000079a3731e1b96  lea r14, [rax+0x100]
000079a3731e1b9d  mov r12, [r13+r14*1]
000079a3731e1ba2  lea r14, [rax+0x108]
000079a3731e1ba9  mov r11, [r13+r14*1]
000079a3731e1bae  movq xmm1, r12
000079a3731e1bb3  movq xmm15, r11
000079a3731e1bb8  movq xmm1, xmm1
000079a3731e1bbc  movq xmm1, xmm1
000079a3731e1bc0  movaps [r15+0x200], xmm1
000079a3731e1bc8  movq xmm15, xmm15
000079a3731e1bcd  movq xmm15, xmm15
000079a3731e1bd2  movaps [r15+0x1F0], xmm15
000079a3731e1bda  mov qword ptr [r15+0x40], 0x430000
000079a3731e1be2  mov r14d, 0x430510
000079a3731e1be8  mov r12, [r13+r14*1]
000079a3731e1bed  movq xmm1, r12
000079a3731e1bf2  lea r14, [rax+0x150]
000079a3731e1bf9  mov [r15+0xF8], r14
000079a3731e1c00  mov rax, [r15+0x50]
000079a3731e1c04  movups xmm15, [r13+rax*1]
000079a3731e1c0a  movaps [r15+0x120], xmm15
000079a3731e1c12  mov qword ptr [r15+0x48], 0x10
000079a3731e1c1a  xor eax, eax
000079a3731e1c1c  mov r14d, 0x10
000079a3731e1c22  mov r12d, 0x200
000079a3731e1c28  cmp r14, r12
000079a3731e1c2b  cmc
000079a3731e1c2c  lahf
000079a3731e1c2d  seto al
000079a3731e1c30  mov [r15+0x108], eax
000079a3731e1c37  pextrq rax, xmm15, 0x01
000079a3731e1c3e  movq xmm14, rax
000079a3731e1c43  movaps [r15+0x130], xmm14
000079a3731e1c4b  movq rax, xmm1
000079a3731e1c50  movq r14, xmm15
000079a3731e1c55  vmovq xmm1, rax
000079a3731e1c5a  vmovq xmm15, r14
000079a3731e1c5f  movaps xmm13, xmm1
000079a3731e1c63  addsd xmm13, xmm15
000079a3731e1c68  ucomisd xmm13, xmm13
000079a3731e1c6d  jp 0x000079A3731E1D86
000079a3731e1c73  movq xmm13, xmm13
000079a3731e1c78  movq rax, xmm13
000079a3731e1c7d  movq r14, xmm14
000079a3731e1c82  vmovq xmm1, rax
000079a3731e1c87  vmovq xmm15, r14
000079a3731e1c8c  movaps xmm14, xmm1
000079a3731e1c90  addsd xmm14, xmm15
000079a3731e1c95  ucomisd xmm14, xmm14
000079a3731e1c9a  jp 0x000079A3731E1DCE
000079a3731e1ca0  movq xmm14, xmm14
000079a3731e1ca5  movaps [r15+0x110], xmm14
000079a3731e1cad  mov eax, [r15+0x108]
000079a3731e1cb4  sahf
000079a3731e1cb5  jnz 0x000079A3731E1CE7
000079a3731e1cb7  cmp dword ptr [r15+0x318], 0x00
000079a3731e1cbf  jz 0x000079A3731E1FE0
000079a3731e1cc5  nop [rax+rax*1], ax
000079a3731e1cce  nop [rax+rax*1], eax
000079a3731e1cd6  mov eax, 0x410490
000079a3731e1cdb  mov [r15+0x100], rax
000079a3731e1ce2  jmp 0x000079A372FFE110
000079a3731e1ce7  cmp dword ptr [r15+0x318], 0x00
000079a3731e1cef  jz 0x000079A3731E1E20
000079a3731e1cf5  nop [rax+rax*1], ax
000079a3731e1cfe  nop [rax+rax*1], eax
000079a3731e1d06  mov eax, 0x410474
000079a3731e1d0b  mov [r15+0x100], rax
000079a3731e1d12  jmp 0x000079A372FFE110
000079a3731e1d17  int3
000079a3731e1d18  call 0x000079A3730E27E0
000079a3731e1d1d  jmp 0x000079A3731E1AC3
000079a3731e1d22  call 0x000079A3730E27E0
000079a3731e1d27  jmp 0x000079A3731E1AD6
000079a3731e1d2c  call 0x000079A3730E1570
000079a3731e1d31  jmp 0x000079A3731E1AE2
000079a3731e1d36  call 0x000079A3730E27E0
000079a3731e1d3b  jmp 0x000079A3731E1B1A
000079a3731e1d40  call 0x000079A3730E1570
000079a3731e1d45  jmp 0x000079A3731E1B26
000079a3731e1d4a  call 0x000079A3730E27E0
000079a3731e1d4f  jmp 0x000079A3731E1B5E
000079a3731e1d54  call 0x000079A3730E1570
000079a3731e1d59  jmp 0x000079A3731E1B6A
000079a3731e1d5e  call 0x000079A3730E27E0
000079a3731e1d63  jmp 0x000079A3731E1BA2
000079a3731e1d68  call 0x000079A3730E1570
000079a3731e1d6d  jmp 0x000079A3731E1BAE
000079a3731e1d72  call 0x000079A3730E27E0
000079a3731e1d77  jmp 0x000079A3731E1BED
000079a3731e1d7c  call 0x000079A37300E760
000079a3731e1d81  jmp 0x000079A3731E1C0A
000079a3731e1d86  ucomisd xmm1, xmm15
000079a3731e1d8b  jp 0x000079A3731E1D9A
000079a3731e1d8d  movaps xmm13, [0x000079A372DFE060]
000079a3731e1d95  jmp 0x000079A3731E1C73
000079a3731e1d9a  vxorps xmm0, xmm1, xmm15
000079a3731e1d9f  pextrw eax, xmm0, 0x03
000079a3731e1da4  and eax, 0x7FF8
000079a3731e1da9  cmp eax, 0x08
000079a3731e1dac  jnz 0x000079A3731E1C73
000079a3731e1db2  movq rax, xmm15
000079a3731e1db7  shl rax, 0x0D
000079a3731e1dbb  jbe 0x000079A3731E1C73
000079a3731e1dc1  vorps xmm13, xmm15, [0x000079A372DFE070]
000079a3731e1dc9  jmp 0x000079A3731E1C73
000079a3731e1dce  ucomisd xmm1, xmm15
000079a3731e1dd3  jp 0x000079A3731E1DE2
000079a3731e1dd5  movaps xmm14, [0x000079A372DFE060]
000079a3731e1ddd  jmp 0x000079A3731E1CA0
000079a3731e1de2  vxorps xmm0, xmm1, xmm15
000079a3731e1de7  pextrw eax, xmm0, 0x03
000079a3731e1dec  and eax, 0x7FF8
000079a3731e1df1  cmp eax, 0x08
000079a3731e1df4  jnz 0x000079A3731E1CA0
000079a3731e1dfa  movq rax, xmm15
000079a3731e1dff  shl rax, 0x0D
000079a3731e1e03  jbe 0x000079A3731E1CA0
000079a3731e1e09  vorps xmm14, xmm15, [0x000079A372DFE070]
000079a3731e1e11  jmp 0x000079A3731E1CA0
000079a3731e1e16  int3
000079a3731e1e17  nop [rax+rax*1], ax
000079a3731e1e20  mov rax, [r15+0x48]
000079a3731e1e24  mov r14, [r15+0x50]
000079a3731e1e28  lea r12, [r14+rax*1]
000079a3731e1e2c  movups xmm1, [r13+r12*1]
000079a3731e1e32  movaps [r15+0x120], xmm1
000079a3731e1e3a  lea r14, [rax+0x10]
000079a3731e1e3e  mov [r15+0x48], r14
000079a3731e1e42  xor eax, eax
000079a3731e1e44  mov r12d, 0x200
000079a3731e1e4a  cmp r14, r12
000079a3731e1e4d  cmc
000079a3731e1e4e  lahf
000079a3731e1e4f  seto al
000079a3731e1e52  mov [r15+0x108], eax
000079a3731e1e59  pextrq rax, xmm1, 0x01
000079a3731e1e60  movq xmm15, rax
000079a3731e1e65  movaps [r15+0x130], xmm15
000079a3731e1e6d  movaps xmm14, [r15+0x110]
000079a3731e1e75  movq rax, xmm14
000079a3731e1e7a  movq r14, xmm1
000079a3731e1e7f  vmovq xmm1, rax
000079a3731e1e84  vmovq xmm14, r14
000079a3731e1e89  movaps xmm13, xmm1
000079a3731e1e8d  addsd xmm13, xmm14
000079a3731e1e92  ucomisd xmm13, xmm13
000079a3731e1e97  jp 0x000079A3731E1F4C
000079a3731e1e9d  movq xmm13, xmm13
000079a3731e1ea2  movq rax, xmm13
000079a3731e1ea7  movq r14, xmm15
000079a3731e1eac  vmovq xmm1, rax
000079a3731e1eb1  vmovq xmm15, r14
000079a3731e1eb6  movaps xmm14, xmm1
000079a3731e1eba  addsd xmm14, xmm15
000079a3731e1ebf  ucomisd xmm14, xmm14
000079a3731e1ec4  jp 0x000079A3731E1F94
000079a3731e1eca  movq xmm14, xmm14
000079a3731e1ecf  movaps [r15+0x110], xmm14
000079a3731e1ed7  mov eax, [r15+0x108]
000079a3731e1ede  sahf
000079a3731e1edf  jnz 0x000079A3731E1F11
000079a3731e1ee1  cmp dword ptr [r15+0x318], 0x00
000079a3731e1ee9  jz 0x000079A3731E1FE0
000079a3731e1eef  nop [rax+rax*1], ax
000079a3731e1ef8  nop [rax+rax*1], eax
000079a3731e1f00  mov eax, 0x410490
000079a3731e1f05  mov [r15+0x100], rax
000079a3731e1f0c  jmp 0x000079A372FFE110
000079a3731e1f11  cmp dword ptr [r15+0x318], 0x00
000079a3731e1f19  jz 0x000079A3731E1E20
000079a3731e1f1f  nop [rax+rax*1], ax
000079a3731e1f28  nop [rax+rax*1], eax
000079a3731e1f30  mov eax, 0x410474
000079a3731e1f35  mov [r15+0x100], rax
000079a3731e1f3c  jmp 0x000079A372FFE110
000079a3731e1f41  int3
000079a3731e1f42  call 0x000079A3730B52F0
000079a3731e1f47  jmp 0x000079A3731E1E32
000079a3731e1f4c  ucomisd xmm1, xmm14
000079a3731e1f51  jp 0x000079A3731E1F60
000079a3731e1f53  movaps xmm13, [0x000079A372DFE060]
000079a3731e1f5b  jmp 0x000079A3731E1E9D
000079a3731e1f60  vxorps xmm0, xmm1, xmm14
000079a3731e1f65  pextrw eax, xmm0, 0x03
000079a3731e1f6a  and eax, 0x7FF8
000079a3731e1f6f  cmp eax, 0x08
000079a3731e1f72  jnz 0x000079A3731E1E9D
000079a3731e1f78  movq rax, xmm14
000079a3731e1f7d  shl rax, 0x0D
000079a3731e1f81  jbe 0x000079A3731E1E9D
000079a3731e1f87  vorps xmm13, xmm14, [0x000079A372DFE070]
000079a3731e1f8f  jmp 0x000079A3731E1E9D
000079a3731e1f94  ucomisd xmm1, xmm15
000079a3731e1f99  jp 0x000079A3731E1FA8
000079a3731e1f9b  movaps xmm14, [0x000079A372DFE060]
000079a3731e1fa3  jmp 0x000079A3731E1ECA
000079a3731e1fa8  vxorps xmm0, xmm1, xmm15
000079a3731e1fad  pextrw eax, xmm0, 0x03
000079a3731e1fb2  and eax, 0x7FF8
000079a3731e1fb7  cmp eax, 0x08
000079a3731e1fba  jnz 0x000079A3731E1ECA
000079a3731e1fc0  movq rax, xmm15
000079a3731e1fc5  shl rax, 0x0D
000079a3731e1fc9  jbe 0x000079A3731E1ECA
000079a3731e1fcf  vorps xmm14, xmm15, [0x000079A372DFE070]
000079a3731e1fd7  jmp 0x000079A3731E1ECA
000079a3731e1fdc  int3
000079a3731e1fdd  nop [rax], eax
000079a3731e1fe0  mov rax, [r15+0x40]
000079a3731e1fe4  lea r14, [rax+0x510]
000079a3731e1feb  movaps xmm1, [r15+0x110]
000079a3731e1ff3  movq rax, xmm1
000079a3731e1ff8  mov [r13+r14*1], rax
000079a3731e1ffd  mov rax, [r15+0xF0]
000079a3731e2004  mov [r15+0x100], rax
000079a3731e200b  jmp 0x000079A3731CE5C0
000079a3731e2010  int3
000079a3731e2011  call 0x000079A3730D5EB0
000079a3731e2016  jmp 0x000079A3731E1FFD
000079a3731e201b  int3
000079a3731e201c  nop [rax], eax
000079a3731e2020  mov qword ptr [r15+0x100], 0x04
000079a3731e202b  mov esi, 0x00
000079a3731e2030  mov edx, 0x09
000079a3731e2035  mov rdi, 0x7FFEF41A81D0
000079a3731e203f  mov rax, 0x64F127A28970
000079a3731e2049  call rax
000079a3731e204b  cmp dword ptr [r15+0x318], 0x00
000079a3731e2053  jnz 0x000079A372FFE110
000079a3731e2059  jmp 0x000079A372FFE0A0
000079a3731e205e  int3
000079a3731e205f  int3
