00007f0254fce69b  nop [rax+rax*1], eax
00007f0254fce6a0  vmovaps xmm1, [0x00007F0254BFE010]
00007f0254fce6a8  movq xmm1, xmm1
00007f0254fce6ac  movaps [r15+0x110], xmm1
00007f0254fce6b4  vmovaps xmm1, [0x00007F0254BFE020]
00007f0254fce6bc  movq xmm1, xmm1
00007f0254fce6c0  movaps [r15+0x120], xmm1
00007f0254fce6c8  mov eax, 0x4204C0
00007f0254fce6cd  mov r14, [r13+rax*1]
00007f0254fce6d2  movq xmm1, r14
00007f0254fce6d7  movaps [r15+0x130], xmm1
00007f0254fce6df  vmovaps xmm1, [0x00007F0254BFE030]
00007f0254fce6e7  vpbroadcastq xmm1, xmm1
00007f0254fce6ec  movaps [r15+0x140], xmm1
00007f0254fce6f4  mov qword ptr [r15+0x40], 0x02
00007f0254fce6fc  vmovaps xmm15, [0x00007F0254BFE040]
00007f0254fce704  movq xmm15, xmm15
00007f0254fce709  movaps [r15+0x150], xmm15
00007f0254fce711  mov qword ptr [r15+0x58], 0x420000
00007f0254fce719  vmovaps xmm15, [0x00007F0254BFE050]
00007f0254fce721  vpbroadcastq xmm15, xmm15
00007f0254fce726  movaps [r15+0x160], xmm15
00007f0254fce72e  mov rax, [r15+0x40]
00007f0254fce732  vmovq xmm14, rax
00007f0254fce737  vpbroadcastq xmm14, xmm14
00007f0254fce73c  movaps [r15+0x170], xmm14
00007f0254fce744  mov eax, 0x4204D0
00007f0254fce749  movups xmm13, [r13+rax*1]
00007f0254fce74f  mov qword ptr [r15+0x40], 0x430518
00007f0254fce757  mov qword ptr [r15+0x50], 0x430720
00007f0254fce75f  vpmovqd xmm12, xmm13
00007f0254fce765  pxor xmm11, xmm11
00007f0254fce76a  punpcklqdq xmm12, xmm11
00007f0254fce76f  movaps [r15+0x210], xmm12
00007f0254fce777  movq xmm12, qword ptr [r15+0x120]
00007f0254fce780  movq xmm11, qword ptr [r15+0x130]
00007f0254fce789  psubd xmm12, xmm11
00007f0254fce78e  movq xmm12, xmm12
00007f0254fce793  paddq xmm13, xmm14
00007f0254fce798  movaps [r15+0x180], xmm13
00007f0254fce7a0  movq xmm14, qword ptr [r15+0x150]
00007f0254fce7a9  paddd xmm11, xmm14
00007f0254fce7ae  movq xmm11, xmm11
00007f0254fce7b3  movq xmm11, xmm11
00007f0254fce7b8  movaps [r15+0x130], xmm11
00007f0254fce7c0  pmovzxdq xmm12, xmm12
00007f0254fce7c6  psllq xmm12, 0x00
00007f0254fce7cc  movq xmm14, qword ptr [r15+0x210]
00007f0254fce7d5  movq xmm13, qword ptr [r15+0x110]
00007f0254fce7de  paddd xmm14, xmm13
00007f0254fce7e3  movq xmm14, xmm14
00007f0254fce7e8  vcvtuqq2pd xmm12, xmm12
00007f0254fce7ee  pmovzxdq xmm14, xmm14
00007f0254fce7f4  psllq xmm14, 0x00
00007f0254fce7fa  vcvtuqq2pd xmm14, xmm14
00007f0254fce800  movaps xmm13, xmm12
00007f0254fce804  mulpd xmm13, xmm1
00007f0254fce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007f0254fce80f  ptest xmm11, xmm11
00007f0254fce815  jnz 0x00007F0254FCE8FF
00007f0254fce81b  movaps [r15+0x220], xmm13
00007f0254fce823  mov eax, 0x430720
00007f0254fce828  movups [r13+rax*1], xmm13
00007f0254fce82e  movaps xmm1, xmm14
00007f0254fce832  mulpd xmm1, xmm15
00007f0254fce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007f0254fce83c  ptest xmm13, xmm13
00007f0254fce842  jnz 0x00007F0254FCEA4C
00007f0254fce848  movaps [r15+0x210], xmm1
00007f0254fce850  mov eax, 0x430518
00007f0254fce855  movups [r13+rax*1], xmm1
00007f0254fce85b  mov qword ptr [r15+0x48], 0x10
00007f0254fce863  xor eax, eax
00007f0254fce865  mov r14d, 0x10
00007f0254fce86b  mov r12d, 0x200
00007f0254fce871  cmp r14, r12
00007f0254fce874  cmc
00007f0254fce875  lahf
00007f0254fce876  seto al
00007f0254fce879  mov [r15+0x108], eax
00007f0254fce880  mov eax, [r15+0x108]
00007f0254fce887  sahf
00007f0254fce888  jnz 0x00007F0254FCE8BA
00007f0254fce88a  cmp dword ptr [r15+0x318], 0x00
00007f0254fce892  jz 0x00007F0254FCEFF0
00007f0254fce898  nop [rax+rax*1], ax
00007f0254fce8a1  nop [rax+rax*1], eax
00007f0254fce8a9  mov eax, 0x4101EC
00007f0254fce8ae  mov [r15+0x100], rax
00007f0254fce8b5  jmp 0x00007F0254DFE110
00007f0254fce8ba  cmp dword ptr [r15+0x318], 0x00
00007f0254fce8c2  jz 0x00007F0254FCEBA0
00007f0254fce8c8  nop [rax+rax*1], ax
00007f0254fce8d1  nop [rax+rax*1], eax
00007f0254fce8d9  mov eax, 0x4101AC
00007f0254fce8de  mov [r15+0x100], rax
00007f0254fce8e5  jmp 0x00007F0254DFE110
00007f0254fce8ea  int3
00007f0254fce8eb  call 0x00007F0254E0DC20
00007f0254fce8f0  jmp 0x00007F0254FCE6D2
00007f0254fce8f5  call 0x00007F0254E0C260
00007f0254fce8fa  jmp 0x00007F0254FCE74F
00007f0254fce8ff  sub rsp, 0x08
00007f0254fce903  push rax
00007f0254fce904  push rcx
00007f0254fce905  push rdx
00007f0254fce906  push rdi
00007f0254fce907  push rsi
00007f0254fce908  push r8
00007f0254fce90a  push r9
00007f0254fce90c  push r10
00007f0254fce90e  push r11
00007f0254fce910  sub rsp, 0xF0
00007f0254fce917  vmovaps [rsp], xmm0
00007f0254fce91c  vmovaps [rsp+0x10], xmm1
00007f0254fce922  vmovaps [rsp+0x20], xmm2
00007f0254fce928  vmovaps [rsp+0x30], xmm3
00007f0254fce92e  vmovaps [rsp+0x40], xmm4
00007f0254fce934  vmovaps [rsp+0x50], xmm5
00007f0254fce93a  vmovaps [rsp+0x60], xmm6
00007f0254fce940  vmovaps [rsp+0x70], xmm7
00007f0254fce946  vmovaps [rsp+0x80], xmm8
00007f0254fce94f  vmovaps [rsp+0x90], xmm9
00007f0254fce958  vmovaps [rsp+0xA0], xmm10
00007f0254fce961  vmovaps [rsp+0xB0], xmm11
00007f0254fce96a  vmovaps [rsp+0xC0], xmm12
00007f0254fce973  vmovaps [rsp+0xD0], xmm14
00007f0254fce97c  vmovaps [rsp+0xE0], xmm15
00007f0254fce985  sub rsp, 0x30
00007f0254fce989  movaps [rsp], xmm13
00007f0254fce98e  movaps [rsp+0x10], xmm12
00007f0254fce994  movaps [rsp+0x20], xmm1
00007f0254fce999  lea rdi, [rsp]
00007f0254fce99d  mov esi, 0x00
00007f0254fce9a2  mov rax, 0x55DD1360A530
00007f0254fce9ac  call rax
00007f0254fce9ae  movaps xmm13, [rsp]
00007f0254fce9b3  add rsp, 0x30
00007f0254fce9b7  vmovaps xmm0, [rsp]
00007f0254fce9bc  vmovaps xmm1, [rsp+0x10]
00007f0254fce9c2  vmovaps xmm2, [rsp+0x20]
00007f0254fce9c8  vmovaps xmm3, [rsp+0x30]
00007f0254fce9ce  vmovaps xmm4, [rsp+0x40]
00007f0254fce9d4  vmovaps xmm5, [rsp+0x50]
00007f0254fce9da  vmovaps xmm6, [rsp+0x60]
00007f0254fce9e0  vmovaps xmm7, [rsp+0x70]
00007f0254fce9e6  vmovaps xmm8, [rsp+0x80]
00007f0254fce9ef  vmovaps xmm9, [rsp+0x90]
00007f0254fce9f8  vmovaps xmm10, [rsp+0xA0]
00007f0254fcea01  vmovaps xmm11, [rsp+0xB0]
00007f0254fcea0a  vmovaps xmm12, [rsp+0xC0]
00007f0254fcea13  vmovaps xmm14, [rsp+0xD0]
00007f0254fcea1c  vmovaps xmm15, [rsp+0xE0]
00007f0254fcea25  add rsp, 0xF0
00007f0254fcea2c  pop r11
00007f0254fcea2e  pop r10
00007f0254fcea30  pop r9
00007f0254fcea32  pop r8
00007f0254fcea34  pop rsi
00007f0254fcea35  pop rdi
00007f0254fcea36  pop rdx
00007f0254fcea37  pop rcx
00007f0254fcea38  pop rax
00007f0254fcea39  add rsp, 0x08
00007f0254fcea3d  jmp 0x00007F0254FCE81B
00007f0254fcea42  call 0x00007F0254E0C380
00007f0254fcea47  jmp 0x00007F0254FCE82E
00007f0254fcea4c  sub rsp, 0x08
00007f0254fcea50  push rax
00007f0254fcea51  push rcx
00007f0254fcea52  push rdx
00007f0254fcea53  push rdi
00007f0254fcea54  push rsi
00007f0254fcea55  push r8
00007f0254fcea57  push r9
00007f0254fcea59  push r10
00007f0254fcea5b  push r11
00007f0254fcea5d  sub rsp, 0xF0
00007f0254fcea64  vmovaps [rsp], xmm0
00007f0254fcea69  vmovaps [rsp+0x10], xmm2
00007f0254fcea6f  vmovaps [rsp+0x20], xmm3
00007f0254fcea75  vmovaps [rsp+0x30], xmm4
00007f0254fcea7b  vmovaps [rsp+0x40], xmm5
00007f0254fcea81  vmovaps [rsp+0x50], xmm6
00007f0254fcea87  vmovaps [rsp+0x60], xmm7
00007f0254fcea8d  vmovaps [rsp+0x70], xmm8
00007f0254fcea93  vmovaps [rsp+0x80], xmm9
00007f0254fcea9c  vmovaps [rsp+0x90], xmm10
00007f0254fceaa5  vmovaps [rsp+0xA0], xmm11
00007f0254fceaae  vmovaps [rsp+0xB0], xmm12
00007f0254fceab7  vmovaps [rsp+0xC0], xmm13
00007f0254fceac0  vmovaps [rsp+0xD0], xmm14
00007f0254fceac9  vmovaps [rsp+0xE0], xmm15
00007f0254fcead2  sub rsp, 0x30
00007f0254fcead6  movaps [rsp], xmm1
00007f0254fceada  movaps [rsp+0x10], xmm14
00007f0254fceae0  movaps [rsp+0x20], xmm15
00007f0254fceae6  lea rdi, [rsp]
00007f0254fceaea  mov esi, 0x00
00007f0254fceaef  mov rax, 0x55DD1360A530
00007f0254fceaf9  call rax
00007f0254fceafb  movaps xmm1, [rsp]
00007f0254fceaff  add rsp, 0x30
00007f0254fceb03  vmovaps xmm0, [rsp]
00007f0254fceb08  vmovaps xmm2, [rsp+0x10]
00007f0254fceb0e  vmovaps xmm3, [rsp+0x20]
00007f0254fceb14  vmovaps xmm4, [rsp+0x30]
00007f0254fceb1a  vmovaps xmm5, [rsp+0x40]
00007f0254fceb20  vmovaps xmm6, [rsp+0x50]
00007f0254fceb26  vmovaps xmm7, [rsp+0x60]
00007f0254fceb2c  vmovaps xmm8, [rsp+0x70]
00007f0254fceb32  vmovaps xmm9, [rsp+0x80]
00007f0254fceb3b  vmovaps xmm10, [rsp+0x90]
00007f0254fceb44  vmovaps xmm11, [rsp+0xA0]
00007f0254fceb4d  vmovaps xmm12, [rsp+0xB0]
00007f0254fceb56  vmovaps xmm13, [rsp+0xC0]
00007f0254fceb5f  vmovaps xmm14, [rsp+0xD0]
00007f0254fceb68  vmovaps xmm15, [rsp+0xE0]
00007f0254fceb71  add rsp, 0xF0
00007f0254fceb78  pop r11
00007f0254fceb7a  pop r10
00007f0254fceb7c  pop r9
00007f0254fceb7e  pop r8
00007f0254fceb80  pop rsi
00007f0254fceb81  pop rdi
00007f0254fceb82  pop rdx
00007f0254fceb83  pop rcx
00007f0254fceb84  pop rax
00007f0254fceb85  add rsp, 0x08
00007f0254fceb89  jmp 0x00007F0254FCE848
00007f0254fceb8e  call 0x00007F0254DFF540
00007f0254fceb93  jmp 0x00007F0254FCE85B
00007f0254fceb98  int3
00007f0254fceb99  nop [rax], eax
00007f0254fceba0  movaps xmm1, [r15+0x180]
00007f0254fceba8  vpmovqd xmm15, xmm1
00007f0254fcebae  pxor xmm14, xmm14
00007f0254fcebb3  punpcklqdq xmm15, xmm14
00007f0254fcebb8  movaps [r15+0x210], xmm15
00007f0254fcebc0  movq xmm15, qword ptr [r15+0x120]
00007f0254fcebc9  movq xmm14, qword ptr [r15+0x130]
00007f0254fcebd2  psubd xmm15, xmm14
00007f0254fcebd7  movq xmm15, xmm15
00007f0254fcebdc  movaps xmm13, [r15+0x170]
00007f0254fcebe4  paddq xmm1, xmm13
00007f0254fcebe9  movaps [r15+0x180], xmm1
00007f0254fcebf1  movq xmm1, qword ptr [r15+0x150]
00007f0254fcebfa  paddd xmm14, xmm1
00007f0254fcebff  movq xmm14, xmm14
00007f0254fcec04  movq xmm14, xmm14
00007f0254fcec09  movaps [r15+0x130], xmm14
00007f0254fcec11  pmovzxdq xmm15, xmm15
00007f0254fcec17  psllq xmm15, 0x00
00007f0254fcec1d  movq xmm1, qword ptr [r15+0x210]
00007f0254fcec26  movq xmm14, qword ptr [r15+0x110]
00007f0254fcec2f  paddd xmm1, xmm14
00007f0254fcec34  movq xmm1, xmm1
00007f0254fcec38  vcvtuqq2pd xmm15, xmm15
00007f0254fcec3e  pmovzxdq xmm1, xmm1
00007f0254fcec43  psllq xmm1, 0x00
00007f0254fcec48  vcvtuqq2pd xmm1, xmm1
00007f0254fcec4e  movaps xmm14, [r15+0x140]
00007f0254fcec56  movaps xmm13, xmm15
00007f0254fcec5a  mulpd xmm13, xmm14
00007f0254fcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007f0254fcec65  ptest xmm12, xmm12
00007f0254fcec6b  jnz 0x00007F0254FCED4E
00007f0254fcec71  movaps [r15+0x220], xmm13
00007f0254fcec79  mov rax, [r15+0x48]
00007f0254fcec7d  mov r14, [r15+0x50]
00007f0254fcec81  lea r12, [r14+rax*1]
00007f0254fcec85  movups [r13+r12*1], xmm13
00007f0254fcec8b  movaps xmm15, [r15+0x160]
00007f0254fcec93  movaps xmm14, xmm1
00007f0254fcec97  mulpd xmm14, xmm15
00007f0254fcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007f0254fceca2  ptest xmm13, xmm13
00007f0254fceca8  jnz 0x00007F0254FCEE9C
00007f0254fcecae  movaps [r15+0x210], xmm14
00007f0254fcecb6  mov r14, [r15+0x40]
00007f0254fcecba  lea r12, [r14+rax*1]
00007f0254fcecbe  movups [r13+r12*1], xmm14
00007f0254fcecc4  lea r14, [rax+0x10]
00007f0254fcecc8  mov [r15+0x48], r14
00007f0254fceccc  xor eax, eax
00007f0254fcecce  mov r12d, 0x200
00007f0254fcecd4  cmp r14, r12
00007f0254fcecd7  cmc
00007f0254fcecd8  lahf
00007f0254fcecd9  seto al
00007f0254fcecdc  mov [r15+0x108], eax
00007f0254fcece3  mov eax, [r15+0x108]
00007f0254fcecea  sahf
00007f0254fceceb  jnz 0x00007F0254FCED1D
00007f0254fceced  cmp dword ptr [r15+0x318], 0x00
00007f0254fcecf5  jz 0x00007F0254FCEFF0
00007f0254fcecfb  nop [rax+rax*1], ax
00007f0254fced04  nop [rax+rax*1], eax
00007f0254fced0c  mov eax, 0x4101EC
00007f0254fced11  mov [r15+0x100], rax
00007f0254fced18  jmp 0x00007F0254DFE110
00007f0254fced1d  cmp dword ptr [r15+0x318], 0x00
00007f0254fced25  jz 0x00007F0254FCEBA0
00007f0254fced2b  nop [rax+rax*1], ax
00007f0254fced34  nop [rax+rax*1], eax
00007f0254fced3c  mov eax, 0x4101AC
00007f0254fced41  mov [r15+0x100], rax
00007f0254fced48  jmp 0x00007F0254DFE110
00007f0254fced4d  int3
00007f0254fced4e  sub rsp, 0x08
00007f0254fced52  push rax
00007f0254fced53  push rcx
00007f0254fced54  push rdx
00007f0254fced55  push rdi
00007f0254fced56  push rsi
00007f0254fced57  push r8
00007f0254fced59  push r9
00007f0254fced5b  push r10
00007f0254fced5d  push r11
00007f0254fced5f  sub rsp, 0xF0
00007f0254fced66  vmovaps [rsp], xmm0
00007f0254fced6b  vmovaps [rsp+0x10], xmm1
00007f0254fced71  vmovaps [rsp+0x20], xmm2
00007f0254fced77  vmovaps [rsp+0x30], xmm3
00007f0254fced7d  vmovaps [rsp+0x40], xmm4
00007f0254fced83  vmovaps [rsp+0x50], xmm5
00007f0254fced89  vmovaps [rsp+0x60], xmm6
00007f0254fced8f  vmovaps [rsp+0x70], xmm7
00007f0254fced95  vmovaps [rsp+0x80], xmm8
00007f0254fced9e  vmovaps [rsp+0x90], xmm9
00007f0254fceda7  vmovaps [rsp+0xA0], xmm10
00007f0254fcedb0  vmovaps [rsp+0xB0], xmm11
00007f0254fcedb9  vmovaps [rsp+0xC0], xmm12
00007f0254fcedc2  vmovaps [rsp+0xD0], xmm14
00007f0254fcedcb  vmovaps [rsp+0xE0], xmm15
00007f0254fcedd4  sub rsp, 0x30
00007f0254fcedd8  movaps [rsp], xmm13
00007f0254fceddd  movaps [rsp+0x10], xmm15
00007f0254fcede3  movaps [rsp+0x20], xmm14
00007f0254fcede9  lea rdi, [rsp]
00007f0254fceded  mov esi, 0x00
00007f0254fcedf2  mov rax, 0x55DD1360A530
00007f0254fcedfc  call rax
00007f0254fcedfe  movaps xmm13, [rsp]
00007f0254fcee03  add rsp, 0x30
00007f0254fcee07  vmovaps xmm0, [rsp]
00007f0254fcee0c  vmovaps xmm1, [rsp+0x10]
00007f0254fcee12  vmovaps xmm2, [rsp+0x20]
00007f0254fcee18  vmovaps xmm3, [rsp+0x30]
00007f0254fcee1e  vmovaps xmm4, [rsp+0x40]
00007f0254fcee24  vmovaps xmm5, [rsp+0x50]
00007f0254fcee2a  vmovaps xmm6, [rsp+0x60]
00007f0254fcee30  vmovaps xmm7, [rsp+0x70]
00007f0254fcee36  vmovaps xmm8, [rsp+0x80]
00007f0254fcee3f  vmovaps xmm9, [rsp+0x90]
00007f0254fcee48  vmovaps xmm10, [rsp+0xA0]
00007f0254fcee51  vmovaps xmm11, [rsp+0xB0]
00007f0254fcee5a  vmovaps xmm12, [rsp+0xC0]
00007f0254fcee63  vmovaps xmm14, [rsp+0xD0]
00007f0254fcee6c  vmovaps xmm15, [rsp+0xE0]
00007f0254fcee75  add rsp, 0xF0
00007f0254fcee7c  pop r11
00007f0254fcee7e  pop r10
00007f0254fcee80  pop r9
00007f0254fcee82  pop r8
00007f0254fcee84  pop rsi
00007f0254fcee85  pop rdi
00007f0254fcee86  pop rdx
00007f0254fcee87  pop rcx
00007f0254fcee88  pop rax
00007f0254fcee89  add rsp, 0x08
00007f0254fcee8d  jmp 0x00007F0254FCEC71
00007f0254fcee92  call 0x00007F0254EC2240
00007f0254fcee97  jmp 0x00007F0254FCEC8B
00007f0254fcee9c  sub rsp, 0x08
00007f0254fceea0  push rax
00007f0254fceea1  push rcx
00007f0254fceea2  push rdx
00007f0254fceea3  push rdi
00007f0254fceea4  push rsi
00007f0254fceea5  push r8
00007f0254fceea7  push r9
00007f0254fceea9  push r10
00007f0254fceeab  push r11
00007f0254fceead  sub rsp, 0xF0
00007f0254fceeb4  vmovaps [rsp], xmm0
00007f0254fceeb9  vmovaps [rsp+0x10], xmm1
00007f0254fceebf  vmovaps [rsp+0x20], xmm2
00007f0254fceec5  vmovaps [rsp+0x30], xmm3
00007f0254fceecb  vmovaps [rsp+0x40], xmm4
00007f0254fceed1  vmovaps [rsp+0x50], xmm5
00007f0254fceed7  vmovaps [rsp+0x60], xmm6
00007f0254fceedd  vmovaps [rsp+0x70], xmm7
00007f0254fceee3  vmovaps [rsp+0x80], xmm8
00007f0254fceeec  vmovaps [rsp+0x90], xmm9
00007f0254fceef5  vmovaps [rsp+0xA0], xmm10
00007f0254fceefe  vmovaps [rsp+0xB0], xmm11
00007f0254fcef07  vmovaps [rsp+0xC0], xmm12
00007f0254fcef10  vmovaps [rsp+0xD0], xmm13
00007f0254fcef19  vmovaps [rsp+0xE0], xmm15
00007f0254fcef22  sub rsp, 0x30
00007f0254fcef26  movaps [rsp], xmm14
00007f0254fcef2b  movaps [rsp+0x10], xmm1
00007f0254fcef30  movaps [rsp+0x20], xmm15
00007f0254fcef36  lea rdi, [rsp]
00007f0254fcef3a  mov esi, 0x00
00007f0254fcef3f  mov rax, 0x55DD1360A530
00007f0254fcef49  call rax
00007f0254fcef4b  movaps xmm14, [rsp]
00007f0254fcef50  add rsp, 0x30
00007f0254fcef54  vmovaps xmm0, [rsp]
00007f0254fcef59  vmovaps xmm1, [rsp+0x10]
00007f0254fcef5f  vmovaps xmm2, [rsp+0x20]
00007f0254fcef65  vmovaps xmm3, [rsp+0x30]
00007f0254fcef6b  vmovaps xmm4, [rsp+0x40]
00007f0254fcef71  vmovaps xmm5, [rsp+0x50]
00007f0254fcef77  vmovaps xmm6, [rsp+0x60]
00007f0254fcef7d  vmovaps xmm7, [rsp+0x70]
00007f0254fcef83  vmovaps xmm8, [rsp+0x80]
00007f0254fcef8c  vmovaps xmm9, [rsp+0x90]
00007f0254fcef95  vmovaps xmm10, [rsp+0xA0]
00007f0254fcef9e  vmovaps xmm11, [rsp+0xB0]
00007f0254fcefa7  vmovaps xmm12, [rsp+0xC0]
00007f0254fcefb0  vmovaps xmm13, [rsp+0xD0]
00007f0254fcefb9  vmovaps xmm15, [rsp+0xE0]
00007f0254fcefc2  add rsp, 0xF0
00007f0254fcefc9  pop r11
00007f0254fcefcb  pop r10
00007f0254fcefcd  pop r9
00007f0254fcefcf  pop r8
00007f0254fcefd1  pop rsi
00007f0254fcefd2  pop rdi
00007f0254fcefd3  pop rdx
00007f0254fcefd4  pop rcx
00007f0254fcefd5  pop rax
00007f0254fcefd6  add rsp, 0x08
00007f0254fcefda  jmp 0x00007F0254FCECAE
00007f0254fcefdf  call 0x00007F0254EC34C0
00007f0254fcefe4  jmp 0x00007F0254FCECC4
00007f0254fcefe9  int3
00007f0254fcefea  nop [rax+rax*1], ax
00007f0254fceff0  mov rax, [r15+0xF8]
00007f0254fceff7  lea r14, [rax-0x150]
00007f0254fceffe  mov [r15+0xF8], r14
00007f0254fcf005  mov rax, [r15+0x50]
00007f0254fcf009  lea r12, [rax+0x80]
00007f0254fcf010  movups xmm1, [r13+r12*1]
00007f0254fcf016  lea r12, [rax+0x90]
00007f0254fcf01d  movups xmm15, [r13+r12*1]
00007f0254fcf023  mov qword ptr [r15+0x48], 0x00
00007f0254fcf02b  lea r12, [rax+0x40]
00007f0254fcf02f  movups xmm14, [r13+r12*1]
00007f0254fcf035  lea r12, [rax+0x50]
00007f0254fcf039  movups xmm13, [r13+r12*1]
00007f0254fcf03f  lea r12, [r14+0x120]
00007f0254fcf046  movq xmm12, qword ptr [r15+0x1C0]
00007f0254fcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007f0254fcf058  movq r11, xmm12
00007f0254fcf05d  movq r10, xmm11
00007f0254fcf062  mov [r13+r12*1], r11
00007f0254fcf067  lea r12, [r14+0x128]
00007f0254fcf06e  mov [r13+r12*1], r10
00007f0254fcf073  vxorps xmm12, xmm12, xmm12
00007f0254fcf078  vpbroadcastq xmm12, xmm12
00007f0254fcf07d  lea r12, [r14+0x100]
00007f0254fcf084  movq xmm11, qword ptr [r15+0x200]
00007f0254fcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007f0254fcf096  movq r11, xmm11
00007f0254fcf09b  movq r10, xmm10
00007f0254fcf0a0  mov [r13+r12*1], r11
00007f0254fcf0a5  lea r12, [r14+0x108]
00007f0254fcf0ac  mov [r13+r12*1], r10
00007f0254fcf0b1  lea r12, [r14+0xE0]
00007f0254fcf0b8  movups [r13+r12*1], xmm15
00007f0254fcf0be  lea r12, [r14+0xF0]
00007f0254fcf0c5  movups [r13+r12*1], xmm1
00007f0254fcf0cb  lea r12, [rax+0xC0]
00007f0254fcf0d2  movups xmm1, [r13+r12*1]
00007f0254fcf0d8  lea r12, [rax+0xD0]
00007f0254fcf0df  movups xmm15, [r13+r12*1]
00007f0254fcf0e5  lea r12, [r14+0x110]
00007f0254fcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007f0254fcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007f0254fcf0fe  movq r11, xmm11
00007f0254fcf103  movq r10, xmm10
00007f0254fcf108  mov [r13+r12*1], r11
00007f0254fcf10d  lea r12, [r14+0x118]
00007f0254fcf114  mov [r13+r12*1], r10
00007f0254fcf119  movups xmm11, [r13+rax*1]
00007f0254fcf11f  lea r12, [rax+0x10]
00007f0254fcf123  movups xmm10, [r13+r12*1]
00007f0254fcf129  lea r12, [r14+0x130]
00007f0254fcf130  movq xmm9, qword ptr [r15+0x1A0]
00007f0254fcf139  movq xmm8, qword ptr [r15+0x190]
00007f0254fcf142  movq r11, xmm9
00007f0254fcf147  movq r10, xmm8
00007f0254fcf14c  mov [r13+r12*1], r11
00007f0254fcf151  lea r12, [r14+0x138]
00007f0254fcf158  mov [r13+r12*1], r10
00007f0254fcf15d  lea r12, [rax+0x140]
00007f0254fcf164  movups xmm9, [r13+r12*1]
00007f0254fcf16a  lea r12, [rax+0x150]
00007f0254fcf171  movups xmm8, [r13+r12*1]
00007f0254fcf177  lea r12, [r14+0xC0]
00007f0254fcf17e  movups [r13+r12*1], xmm15
00007f0254fcf184  lea r12, [r14+0xD0]
00007f0254fcf18b  movups [r13+r12*1], xmm1
00007f0254fcf191  lea r12, [rax+0x100]
00007f0254fcf198  movups xmm1, [r13+r12*1]
00007f0254fcf19e  lea r12, [rax+0x110]
00007f0254fcf1a5  movups xmm15, [r13+r12*1]
00007f0254fcf1ab  lea r12, [r14+0x140]
00007f0254fcf1b2  mov r11, [r15+0xE8]
00007f0254fcf1b9  mov [r13+r12*1], r11
00007f0254fcf1be  lea r12, [rax+0x180]
00007f0254fcf1c5  movups xmm7, [r13+r12*1]
00007f0254fcf1cb  lea r12, [rax+0x190]
00007f0254fcf1d2  movups xmm6, [r13+r12*1]
00007f0254fcf1d8  lea r12, [rax+0x1C0]
00007f0254fcf1df  movups xmm5, [r13+r12*1]
00007f0254fcf1e5  lea r12, [rax+0x1D0]
00007f0254fcf1ec  movups xmm4, [r13+r12*1]
00007f0254fcf1f2  lea r12, [r14+0x20]
00007f0254fcf1f6  movups [r13+r12*1], xmm1
00007f0254fcf1fc  lea r12, [r14+0x30]
00007f0254fcf200  movups [r13+r12*1], xmm13
00007f0254fcf206  lea r12, [rax+0x60]
00007f0254fcf20a  movups xmm1, [r13+r12*1]
00007f0254fcf210  lea r12, [rax+0x70]
00007f0254fcf214  movups xmm13, [r13+r12*1]
00007f0254fcf21a  lea r12, [rax+0x20]
00007f0254fcf21e  movups xmm3, [r13+r12*1]
00007f0254fcf224  lea r12, [rax+0x30]
00007f0254fcf228  movups xmm2, [r13+r12*1]
00007f0254fcf22e  movaps [r15+0x1F0], xmm2
00007f0254fcf236  lea r12, [r14+0x60]
00007f0254fcf23a  movups [r13+r12*1], xmm11
00007f0254fcf240  lea r12, [r14+0x70]
00007f0254fcf244  movups [r13+r12*1], xmm5
00007f0254fcf24a  lea r12, [rax+0xE0]
00007f0254fcf251  movups xmm11, [r13+r12*1]
00007f0254fcf257  lea r12, [rax+0xF0]
00007f0254fcf25e  movups xmm5, [r13+r12*1]
00007f0254fcf264  lea r12, [r14+0xA0]
00007f0254fcf26b  movups [r13+r12*1], xmm13
00007f0254fcf271  lea r12, [r14+0xB0]
00007f0254fcf278  movups [r13+r12*1], xmm1
00007f0254fcf27e  lea r12, [rax+0xA0]
00007f0254fcf285  movups xmm1, [r13+r12*1]
00007f0254fcf28b  lea r12, [rax+0xB0]
00007f0254fcf292  movups xmm13, [r13+r12*1]
00007f0254fcf298  lea r12, [rax+0x120]
00007f0254fcf29f  vmovaps [rsp+0x10], xmm1
00007f0254fcf2a5  movups xmm1, [r13+r12*1]
00007f0254fcf2ab  lea r12, [rax+0x130]
00007f0254fcf2b2  vmovaps [rsp+0x20], xmm1
00007f0254fcf2b8  movups xmm1, [r13+r12*1]
00007f0254fcf2be  lea r12, [rax+0x160]
00007f0254fcf2c5  vmovaps [rsp+0x30], xmm1
00007f0254fcf2cb  movups xmm1, [r13+r12*1]
00007f0254fcf2d1  lea r12, [rax+0x170]
00007f0254fcf2d8  vmovaps [rsp+0x40], xmm1
00007f0254fcf2de  movups xmm1, [r13+r12*1]
00007f0254fcf2e4  movaps [r15+0x2B0], xmm1
00007f0254fcf2ec  lea r12, [r14+0x80]
00007f0254fcf2f3  movups [r13+r12*1], xmm13
00007f0254fcf2f9  lea r12, [r14+0x90]
00007f0254fcf300  vmovaps xmm13, [rsp+0x10]
00007f0254fcf306  movups [r13+r12*1], xmm13
00007f0254fcf30c  lea r12, [rax+0x1A0]
00007f0254fcf313  movups xmm13, [r13+r12*1]
00007f0254fcf319  lea r12, [rax+0x1B0]
00007f0254fcf320  vmovaps [rsp+0x10], xmm1
00007f0254fcf326  movups xmm1, [r13+r12*1]
00007f0254fcf32c  movaps [r15+0x290], xmm13
00007f0254fcf334  movaps [r15+0x1E0], xmm1
00007f0254fcf33c  lea r12, [rax+0x1E0]
00007f0254fcf343  vmovaps [rsp+0x50], xmm1
00007f0254fcf349  movups xmm1, [r13+r12*1]
00007f0254fcf34f  lea r12, [rax+0x1F0]
00007f0254fcf356  vmovaps [rsp+0x60], xmm1
00007f0254fcf35c  movups xmm1, [r13+r12*1]
00007f0254fcf362  mov qword ptr [r15+0x50], 0x430920
00007f0254fcf36a  lea rax, [r14+0x40]
00007f0254fcf36e  vmovaps [rsp+0x70], xmm1
00007f0254fcf374  vmovaps xmm1, [rsp+0x40]
00007f0254fcf37a  movups [r13+rax*1], xmm1
00007f0254fcf380  lea rax, [r14+0x50]
00007f0254fcf384  movups [r13+rax*1], xmm10
00007f0254fcf38a  vmovaps xmm1, [rsp+0x70]
00007f0254fcf390  movups [r13+r14*1], xmm1
00007f0254fcf396  lea rax, [r14+0x10]
00007f0254fcf39a  vmovaps xmm1, [rsp+0x60]
00007f0254fcf3a0  movups [r13+rax*1], xmm1
00007f0254fcf3a6  mov rax, [r15+0x40]
00007f0254fcf3aa  vmovaps [rsp+0x40], xmm3
00007f0254fcf3b0  vmovaps xmm1, [rsp+0x40]
00007f0254fcf3b6  por xmm3, xmm1
00007f0254fcf3ba  vmovaps [rsp+0x40], xmm6
00007f0254fcf3c0  vmovaps xmm10, [rsp+0x40]
00007f0254fcf3c6  por xmm6, xmm10
00007f0254fcf3cb  lea r12, [rax+0x30]
00007f0254fcf3cf  mov r11, [r13+r12*1]
00007f0254fcf3d4  lea r12, [rax+0x38]
00007f0254fcf3d8  mov r10, [r13+r12*1]
00007f0254fcf3dd  movq xmm10, r11
00007f0254fcf3e2  vmovaps [rsp+0x40], xmm1
00007f0254fcf3e8  movq xmm1, r10
00007f0254fcf3ed  movq xmm10, xmm10
00007f0254fcf3f2  vmovaps [rsp+0x60], xmm10
00007f0254fcf3f8  movq xmm10, xmm10
00007f0254fcf3fd  movaps [r15+0x130], xmm10
00007f0254fcf405  movq xmm1, xmm1
00007f0254fcf409  vmovaps [rsp+0x70], xmm1
00007f0254fcf40f  movq xmm1, xmm1
00007f0254fcf413  movaps [r15+0x280], xmm1
00007f0254fcf41b  vmovaps [rsp+0x80], xmm9
00007f0254fcf424  vmovaps xmm1, [rsp+0x80]
00007f0254fcf42d  por xmm9, xmm1
00007f0254fcf432  lea r12, [rax+0x20]
00007f0254fcf436  mov r11, [r13+r12*1]
00007f0254fcf43b  lea r12, [rax+0x28]
00007f0254fcf43f  mov r10, [r13+r12*1]
00007f0254fcf444  movq xmm1, r11
00007f0254fcf449  movq xmm10, r10
00007f0254fcf44e  movq xmm1, xmm1
00007f0254fcf452  vmovaps [rsp+0x80], xmm1
00007f0254fcf45b  movq xmm1, xmm1
00007f0254fcf45f  movaps [r15+0x150], xmm1
00007f0254fcf467  movq xmm10, xmm10
00007f0254fcf46c  vmovaps [rsp+0x90], xmm10
00007f0254fcf475  movq xmm10, xmm10
00007f0254fcf47a  movaps [r15+0x140], xmm10
00007f0254fcf482  lea r12, [rax+0x10]
00007f0254fcf486  mov r11, [r13+r12*1]
00007f0254fcf48b  lea r12, [rax+0x18]
00007f0254fcf48f  mov r10, [r13+r12*1]
00007f0254fcf494  movq xmm1, r11
00007f0254fcf499  movq xmm10, r10
00007f0254fcf49e  movq xmm1, xmm1
00007f0254fcf4a2  vmovaps [rsp+0xA0], xmm1
00007f0254fcf4ab  movq xmm1, xmm1
00007f0254fcf4af  movaps [r15+0x170], xmm1
00007f0254fcf4b7  movq xmm10, xmm10
00007f0254fcf4bc  vmovaps [rsp+0xB0], xmm10
00007f0254fcf4c5  movq xmm10, xmm10
00007f0254fcf4ca  movaps [r15+0x160], xmm10
00007f0254fcf4d2  mov r12, [r13+rax*1]
00007f0254fcf4d7  vmovq xmm1, r12
00007f0254fcf4dc  vpbroadcastq xmm1, xmm1
00007f0254fcf4e1  lea r12, [rax+0x08]
00007f0254fcf4e5  mov rax, [r13+r12*1]
00007f0254fcf4ea  movq xmm10, rax
00007f0254fcf4ef  movaps [r15+0x230], xmm10
00007f0254fcf4f7  lea rax, [r14+0x50]
00007f0254fcf4fb  movups xmm10, [r13+rax*1]
00007f0254fcf501  lea rax, [r14+0x60]
00007f0254fcf505  vmovaps [rsp+0xC0], xmm1
00007f0254fcf50e  movups xmm1, [r13+rax*1]
00007f0254fcf514  lea rax, [r14+0x30]
00007f0254fcf518  vmovaps [rsp+0xD0], xmm1
00007f0254fcf521  movups xmm1, [r13+rax*1]
00007f0254fcf527  mov qword ptr [r15+0x60], 0x430920
00007f0254fcf52f  mov qword ptr [r15+0x58], 0x40
00007f0254fcf537  vmovaps [rsp+0xE0], xmm1
00007f0254fcf540  vmovaps [rsp+0xF0], xmm15
00007f0254fcf549  vmovaps xmm15, [rsp+0xC0]
00007f0254fcf552  vmovaps [rsp+0xC0], xmm14
00007f0254fcf55b  vmovaps xmm14, [rsp+0x40]
00007f0254fcf561  vmovaps [rsp+0x40], xmm13
00007f0254fcf567  movaps xmm1, xmm15
00007f0254fcf56b  mulpd xmm1, xmm14
00007f0254fcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007f0254fcf575  ptest xmm13, xmm13
00007f0254fcf57b  jnz 0x00007F0254FD0682
00007f0254fcf581  movq xmm14, qword ptr [r15+0x230]
00007f0254fcf58a  vmovaps [rsp+0x100], xmm14
00007f0254fcf593  vpermilpd xmm14, xmm14, 0x00
00007f0254fcf599  vmovaps [rsp+0x110], xmm1
00007f0254fcf5a2  vmovaps xmm1, [rsp+0xE0]
00007f0254fcf5ab  vmovaps [rsp+0xE0], xmm15
00007f0254fcf5b4  movaps xmm13, xmm1
00007f0254fcf5b8  mulpd xmm13, xmm14
00007f0254fcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007f0254fcf5c3  ptest xmm15, xmm15
00007f0254fcf5c9  jnz 0x00007F0254FD07C4
00007f0254fcf5cf  vxorps xmm1, xmm1, xmm1
00007f0254fcf5d3  vpbroadcastq xmm1, xmm1
00007f0254fcf5d8  vmovaps xmm14, [rsp+0xE0]
00007f0254fcf5e1  vmovaps [rsp+0xE0], xmm1
00007f0254fcf5ea  vmovaps xmm1, [rsp+0xD0]
00007f0254fcf5f3  vmovaps [rsp+0xD0], xmm13
00007f0254fcf5fc  movaps xmm15, xmm14
00007f0254fcf600  mulpd xmm15, xmm1
00007f0254fcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007f0254fcf60b  ptest xmm13, xmm13
00007f0254fcf611  jnz 0x00007F0254FD0907
00007f0254fcf617  movaps xmm1, xmm14
00007f0254fcf61b  mulpd xmm1, xmm10
00007f0254fcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007f0254fcf625  ptest xmm13, xmm13
00007f0254fcf62b  jnz 0x00007F0254FD0A4A
00007f0254fcf631  movaps xmm13, xmm14
00007f0254fcf635  mulpd xmm13, xmm2
00007f0254fcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007f0254fcf640  ptest xmm10, xmm10
00007f0254fcf646  jnz 0x00007F0254FD0B8C
00007f0254fcf64c  vmovaps [rsp+0x120], xmm7
00007f0254fcf655  vmovaps xmm14, [rsp+0x120]
00007f0254fcf65e  por xmm7, xmm14
00007f0254fcf663  vmovaps xmm14, [rsp+0xC0]
00007f0254fcf66c  vmovaps xmm10, [rsp+0xC0]
00007f0254fcf675  por xmm14, xmm10
00007f0254fcf67a  vmovaps xmm2, [rsp+0x100]
00007f0254fcf683  vpermilpd xmm2, xmm2, 0x00
00007f0254fcf689  vmovaps [rsp+0xC0], xmm1
00007f0254fcf692  vmovaps [rsp+0x120], xmm15
00007f0254fcf69b  movaps xmm1, xmm10
00007f0254fcf69f  mulpd xmm1, xmm2
00007f0254fcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007f0254fcf6a8  ptest xmm15, xmm15
00007f0254fcf6ae  jnz 0x00007F0254FD0CCF
00007f0254fcf6b4  xor eax, eax
00007f0254fcf6b6  mov r12d, 0x40
00007f0254fcf6bc  mov r11d, 0x200
00007f0254fcf6c2  cmp r12, r11
00007f0254fcf6c5  cmc
00007f0254fcf6c6  lahf
00007f0254fcf6c7  seto al
00007f0254fcf6ca  mov [r15+0x108], eax
00007f0254fcf6d1  vmovaps xmm10, [rsp+0x110]
00007f0254fcf6da  vmovaps xmm2, [rsp+0xE0]
00007f0254fcf6e3  vmovaps [rsp+0xE0], xmm1
00007f0254fcf6ec  movaps xmm15, xmm10
00007f0254fcf6f0  addpd xmm15, xmm2
00007f0254fcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0254fcf6fb  ptest xmm1, xmm1
00007f0254fcf700  jnz 0x00007F0254FD0E10
00007f0254fcf706  vmovaps xmm10, [rsp+0x120]
00007f0254fcf70f  vmovaps [rsp+0x110], xmm15
00007f0254fcf718  movaps xmm1, xmm10
00007f0254fcf71c  addpd xmm1, xmm12
00007f0254fcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007f0254fcf726  ptest xmm15, xmm15
00007f0254fcf72c  jnz 0x00007F0254FD0F53
00007f0254fcf732  vmovaps xmm10, [rsp+0xC0]
00007f0254fcf73b  vmovaps [rsp+0xC0], xmm1
00007f0254fcf744  movaps xmm15, xmm10
00007f0254fcf748  addpd xmm15, xmm12
00007f0254fcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0254fcf753  ptest xmm1, xmm1
00007f0254fcf758  jnz 0x00007F0254FD1095
00007f0254fcf75e  vmovaps xmm1, [rsp+0x30]
00007f0254fcf764  vmovaps xmm12, [rsp+0x30]
00007f0254fcf76a  por xmm1, xmm12
00007f0254fcf76f  vmovaps xmm12, [rsp+0x20]
00007f0254fcf775  vmovaps xmm10, [rsp+0x20]
00007f0254fcf77b  por xmm12, xmm10
00007f0254fcf780  vmovaps [rsp+0x20], xmm5
00007f0254fcf786  vmovaps xmm10, [rsp+0x20]
00007f0254fcf78c  por xmm5, xmm10
00007f0254fcf791  vmovaps [rsp+0x20], xmm11
00007f0254fcf797  vmovaps xmm10, [rsp+0x20]
00007f0254fcf79d  por xmm11, xmm10
00007f0254fcf7a2  vmovaps [rsp+0x20], xmm4
00007f0254fcf7a8  vmovaps xmm10, [rsp+0x20]
00007f0254fcf7ae  por xmm4, xmm10
00007f0254fcf7b3  vmovaps [rsp+0x20], xmm8
00007f0254fcf7b9  vmovaps xmm10, [rsp+0x20]
00007f0254fcf7bf  por xmm8, xmm10
00007f0254fcf7c4  vmovaps xmm10, [rsp+0xF0]
00007f0254fcf7cd  vmovaps [rsp+0x20], xmm1
00007f0254fcf7d3  vmovaps xmm1, [rsp+0xF0]
00007f0254fcf7dc  por xmm10, xmm1
00007f0254fcf7e1  lea rax, [r14+0xA0]
00007f0254fcf7e8  movups xmm1, [r13+rax*1]
00007f0254fcf7ee  lea rax, [r14+0xB0]
00007f0254fcf7f5  vmovaps [rsp+0x30], xmm1
00007f0254fcf7fb  movups xmm1, [r13+rax*1]
00007f0254fcf801  vmovaps [rsp+0xF0], xmm1
00007f0254fcf80a  vmovaps [rsp+0x120], xmm15
00007f0254fcf813  movaps xmm1, xmm13
00007f0254fcf817  addpd xmm1, xmm2
00007f0254fcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007f0254fcf820  ptest xmm15, xmm15
00007f0254fcf826  jnz 0x00007F0254FD11ED
00007f0254fcf82c  lea rax, [r14+0xF0]
00007f0254fcf833  movups xmm15, [r13+rax*1]
00007f0254fcf839  vmovaps xmm2, [rsp+0xC0]
00007f0254fcf842  vmovaps [rsp+0xC0], xmm1
00007f0254fcf84b  vmovaps xmm1, [rsp+0xE0]
00007f0254fcf854  vmovaps [rsp+0xE0], xmm15
00007f0254fcf85d  movaps xmm13, xmm2
00007f0254fcf861  addpd xmm13, xmm1
00007f0254fcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007f0254fcf86c  ptest xmm15, xmm15
00007f0254fcf872  jnz 0x00007F0254FD1338
00007f0254fcf878  vmovaps xmm15, [rsp+0x120]
00007f0254fcf881  vmovaps xmm2, [rsp+0xD0]
00007f0254fcf88a  vmovaps [rsp+0xD0], xmm14
00007f0254fcf893  movaps xmm1, xmm15
00007f0254fcf897  addpd xmm1, xmm2
00007f0254fcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007f0254fcf8a0  ptest xmm14, xmm14
00007f0254fcf8a6  jnz 0x00007F0254FD147A
00007f0254fcf8ac  vmovaps xmm15, [rsp+0x100]
00007f0254fcf8b5  vpermilpd xmm15, xmm15, 0x00
00007f0254fcf8bb  vmovaps xmm2, [rsp+0xF0]
00007f0254fcf8c4  vmovaps [rsp+0xF0], xmm1
00007f0254fcf8cd  movaps xmm14, xmm2
00007f0254fcf8d1  mulpd xmm14, xmm15
00007f0254fcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007f0254fcf8dc  ptest xmm1, xmm1
00007f0254fcf8e1  jnz 0x00007F0254FD15BB
00007f0254fcf8e7  vmovaps xmm1, [rsp+0xA0]
00007f0254fcf8f0  vpermilpd xmm1, xmm1, 0x00
00007f0254fcf8f6  vmovaps xmm2, [rsp+0xE0]
00007f0254fcf8ff  vmovaps [rsp+0xE0], xmm14
00007f0254fcf908  movaps xmm15, xmm2
00007f0254fcf90c  mulpd xmm15, xmm1
00007f0254fcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007f0254fcf917  ptest xmm14, xmm14
00007f0254fcf91d  jnz 0x00007F0254FD16FE
00007f0254fcf923  lea rax, [r14+0xE0]
00007f0254fcf92a  movups xmm1, [r13+rax*1]
00007f0254fcf930  vmovaps xmm14, [rsp+0x100]
00007f0254fcf939  vpermilpd xmm14, xmm14, 0x00
00007f0254fcf93f  vmovaps [rsp+0x100], xmm1
00007f0254fcf948  vmovaps xmm1, [rsp+0x30]
00007f0254fcf94e  vmovaps [rsp+0x30], xmm15
00007f0254fcf954  movaps xmm2, xmm1
00007f0254fcf957  mulpd xmm2, xmm14
00007f0254fcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007f0254fcf961  ptest xmm15, xmm15
00007f0254fcf967  jnz 0x00007F0254FD184A
00007f0254fcf96d  vmovaps [rsp+0x120], xmm10
00007f0254fcf976  vmovaps xmm1, [rsp+0x120]
00007f0254fcf97f  por xmm10, xmm1
00007f0254fcf984  movaps [r15+0x300], xmm10
00007f0254fcf98c  vmovaps [rsp+0x120], xmm8
00007f0254fcf995  vmovaps xmm1, [rsp+0x120]
00007f0254fcf99e  por xmm8, xmm1
00007f0254fcf9a3  movaps [r15+0x190], xmm8
00007f0254fcf9ab  vmovaps xmm1, [rsp+0xA0]
00007f0254fcf9b4  vpermilpd xmm1, xmm1, 0x00
00007f0254fcf9ba  vmovaps xmm14, [rsp+0x100]
00007f0254fcf9c3  vmovaps [rsp+0x100], xmm13
00007f0254fcf9cc  movaps xmm15, xmm14
00007f0254fcf9d0  mulpd xmm15, xmm1
00007f0254fcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007f0254fcf9db  ptest xmm13, xmm13
00007f0254fcf9e1  jnz 0x00007F0254FD198B
00007f0254fcf9e7  lea rax, [r14+0x90]
00007f0254fcf9ee  movups xmm1, [r13+rax*1]
00007f0254fcf9f4  vmovaps [rsp+0x120], xmm4
00007f0254fcf9fd  vmovaps xmm14, [rsp+0x120]
00007f0254fcfa06  por xmm4, xmm14
00007f0254fcfa0b  movaps [r15+0x1C0], xmm4
00007f0254fcfa13  vmovaps [rsp+0x120], xmm11
00007f0254fcfa1c  vmovaps xmm14, [rsp+0x120]
00007f0254fcfa25  por xmm11, xmm14
00007f0254fcfa2a  movaps [r15+0x200], xmm11
00007f0254fcfa32  vmovaps [rsp+0x120], xmm5
00007f0254fcfa3b  vmovaps xmm14, [rsp+0x120]
00007f0254fcfa44  por xmm5, xmm14
00007f0254fcfa49  movaps [r15+0x2D0], xmm5
00007f0254fcfa51  vmovaps [rsp+0x120], xmm12
00007f0254fcfa5a  vmovaps xmm14, [rsp+0x120]
00007f0254fcfa63  por xmm12, xmm14
00007f0254fcfa68  movaps [r15+0x2E0], xmm12
00007f0254fcfa70  vmovaps xmm13, [rsp+0x110]
00007f0254fcfa79  vmovaps [rsp+0x110], xmm1
00007f0254fcfa82  vmovaps xmm1, [rsp+0xE0]
00007f0254fcfa8b  vmovaps [rsp+0xE0], xmm15
00007f0254fcfa94  movaps xmm14, xmm13
00007f0254fcfa98  addpd xmm14, xmm1
00007f0254fcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007f0254fcfaa3  ptest xmm15, xmm15
00007f0254fcfaa9  jnz 0x00007F0254FD1AD8
00007f0254fcfaaf  vmovaps xmm1, [rsp+0xA0]
00007f0254fcfab8  vpermilpd xmm1, xmm1, 0x00
00007f0254fcfabe  vmovaps xmm13, [rsp+0x110]
00007f0254fcfac7  vmovaps [rsp+0x110], xmm14
00007f0254fcfad0  movaps xmm15, xmm13
00007f0254fcfad4  mulpd xmm15, xmm1
00007f0254fcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007f0254fcfadf  ptest xmm14, xmm14
00007f0254fcfae5  jnz 0x00007F0254FD1C1B
00007f0254fcfaeb  lea rax, [r14+0x80]
00007f0254fcfaf2  movups xmm1, [r13+rax*1]
00007f0254fcfaf8  vmovaps xmm13, [rsp+0xC0]
00007f0254fcfb01  vmovaps [rsp+0xC0], xmm1
00007f0254fcfb0a  movaps xmm14, xmm13
00007f0254fcfb0e  addpd xmm14, xmm2
00007f0254fcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007f0254fcfb19  ptest xmm1, xmm1
00007f0254fcfb1e  jnz 0x00007F0254FD1D68
00007f0254fcfb24  vmovaps xmm13, [rsp+0x100]
00007f0254fcfb2d  vmovaps xmm2, [rsp+0x30]
00007f0254fcfb33  vmovaps [rsp+0x30], xmm15
00007f0254fcfb39  movaps xmm1, xmm13
00007f0254fcfb3d  addpd xmm1, xmm2
00007f0254fcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007f0254fcfb46  ptest xmm15, xmm15
00007f0254fcfb4c  jnz 0x00007F0254FD1EAB
00007f0254fcfb52  vmovaps xmm15, [rsp+0x20]
00007f0254fcfb58  vmovaps xmm13, [rsp+0x20]
00007f0254fcfb5e  por xmm15, xmm13
00007f0254fcfb63  movaps [r15+0x2F0], xmm15
00007f0254fcfb6b  vmovaps xmm13, [rsp+0xA0]
00007f0254fcfb74  vpermilpd xmm13, xmm13, 0x00
00007f0254fcfb7a  vmovaps [rsp+0x20], xmm1
00007f0254fcfb80  vmovaps xmm1, [rsp+0xC0]
00007f0254fcfb89  vmovaps [rsp+0xA0], xmm15
00007f0254fcfb92  movaps xmm2, xmm1
00007f0254fcfb95  mulpd xmm2, xmm13
00007f0254fcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007f0254fcfb9f  ptest xmm15, xmm15
00007f0254fcfba5  jnz 0x00007F0254FD1FEC
00007f0254fcfbab  lea rax, [r14+0xD0]
00007f0254fcfbb2  movups xmm1, [r13+rax*1]
00007f0254fcfbb8  vmovaps xmm13, [rsp+0xF0]
00007f0254fcfbc1  vmovaps [rsp+0xC0], xmm1
00007f0254fcfbca  vmovaps xmm1, [rsp+0xE0]
00007f0254fcfbd3  vmovaps [rsp+0xE0], xmm14
00007f0254fcfbdc  movaps xmm15, xmm13
00007f0254fcfbe0  addpd xmm15, xmm1
00007f0254fcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007f0254fcfbeb  ptest xmm14, xmm14
00007f0254fcfbf1  jnz 0x00007F0254FD2137
00007f0254fcfbf7  vmovaps xmm1, [rsp+0xB0]
00007f0254fcfc00  vpermilpd xmm1, xmm1, 0x00
00007f0254fcfc06  movaps xmm14, xmm11
00007f0254fcfc0a  mulpd xmm14, xmm1
00007f0254fcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007f0254fcfc15  ptest xmm13, xmm13
00007f0254fcfc1b  jnz 0x00007F0254FD227A
00007f0254fcfc21  movaps [r15+0x260], xmm14
00007f0254fcfc29  vxorps xmm1, xmm1, xmm1
00007f0254fcfc2d  vpbroadcastq xmm1, xmm1
00007f0254fcfc32  movaps [r15+0x1B0], xmm1
00007f0254fcfc3a  vmovaps xmm1, [rsp+0xB0]
00007f0254fcfc43  vpermilpd xmm1, xmm1, 0x00
00007f0254fcfc49  vmovaps xmm11, [rsp+0xC0]
00007f0254fcfc52  vmovaps [rsp+0xC0], xmm15
00007f0254fcfc5b  movaps xmm13, xmm11
00007f0254fcfc5f  mulpd xmm13, xmm1
00007f0254fcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007f0254fcfc6a  ptest xmm15, xmm15
00007f0254fcfc70  jnz 0x00007F0254FD23BD
00007f0254fcfc76  lea rax, [r14+0xC0]
00007f0254fcfc7d  movups xmm1, [r13+rax*1]
00007f0254fcfc83  vmovaps xmm11, [rsp+0x110]
00007f0254fcfc8c  vmovaps [rsp+0xF0], xmm1
00007f0254fcfc95  vmovaps xmm1, [rsp+0x30]
00007f0254fcfc9b  vmovaps [rsp+0x30], xmm14
00007f0254fcfca1  movaps xmm15, xmm11
00007f0254fcfca5  addpd xmm15, xmm1
00007f0254fcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007f0254fcfcb0  ptest xmm14, xmm14
00007f0254fcfcb6  jnz 0x00007F0254FD250A
00007f0254fcfcbc  vmovaps [rsp+0x100], xmm9
00007f0254fcfcc5  vmovaps xmm1, [rsp+0x100]
00007f0254fcfcce  por xmm9, xmm1
00007f0254fcfcd3  movaps [r15+0x270], xmm9
00007f0254fcfcdb  vmovaps [rsp+0x100], xmm6
00007f0254fcfce4  vmovaps xmm1, [rsp+0x100]
00007f0254fcfced  por xmm6, xmm1
00007f0254fcfcf1  movaps [r15+0x1A0], xmm6
00007f0254fcfcf9  vmovaps xmm14, [rsp+0xB0]
00007f0254fcfd02  vpermilpd xmm14, xmm14, 0x00
00007f0254fcfd08  vmovaps xmm6, [rsp+0xF0]
00007f0254fcfd11  vmovaps [rsp+0xF0], xmm1
00007f0254fcfd1a  movaps xmm11, xmm6
00007f0254fcfd1e  mulpd xmm11, xmm14
00007f0254fcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007f0254fcfd29  ptest xmm1, xmm1
00007f0254fcfd2e  jnz 0x00007F0254FD264D
00007f0254fcfd34  lea rax, [r14+0x20]
00007f0254fcfd38  movups xmm1, [r13+rax*1]
00007f0254fcfd3e  movaps [r15+0x110], xmm1
00007f0254fcfd46  vmovaps xmm6, [rsp+0xE0]
00007f0254fcfd4f  vmovaps [rsp+0xE0], xmm1
00007f0254fcfd58  movaps xmm14, xmm6
00007f0254fcfd5c  addpd xmm14, xmm2
00007f0254fcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007f0254fcfd67  ptest xmm1, xmm1
00007f0254fcfd6c  jnz 0x00007F0254FD279A
00007f0254fcfd72  vmovaps xmm1, [rsp+0xB0]
00007f0254fcfd7b  vpermilpd xmm1, xmm1, 0x00
00007f0254fcfd81  movaps xmm6, xmm5
00007f0254fcfd84  mulpd xmm6, xmm1
00007f0254fcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007f0254fcfd8d  ptest xmm2, xmm2
00007f0254fcfd92  jnz 0x00007F0254FD28DC
00007f0254fcfd98  vmovaps xmm5, [rsp+0x20]
00007f0254fcfd9e  movaps xmm1, xmm5
00007f0254fcfda1  addpd xmm1, xmm13
00007f0254fcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007f0254fcfdab  ptest xmm2, xmm2
00007f0254fcfdb0  jnz 0x00007F0254FD2A1C
00007f0254fcfdb6  vmovaps xmm13, [rsp+0x80]
00007f0254fcfdbf  vpermilpd xmm13, xmm13, 0x00
00007f0254fcfdc5  vmovaps xmm2, [rsp+0xE0]
00007f0254fcfdce  vmovaps [rsp+0x20], xmm1
00007f0254fcfdd4  movaps xmm5, xmm2
00007f0254fcfdd7  mulpd xmm5, xmm13
00007f0254fcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007f0254fcfde1  ptest xmm1, xmm1
00007f0254fcfde6  jnz 0x00007F0254FD2B5D
00007f0254fcfdec  vmovaps xmm1, [rsp+0x80]
00007f0254fcfdf5  vpermilpd xmm1, xmm1, 0x00
00007f0254fcfdfb  movaps xmm13, xmm10
00007f0254fcfdff  mulpd xmm13, xmm1
00007f0254fcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007f0254fcfe0a  ptest xmm2, xmm2
00007f0254fcfe0f  jnz 0x00007F0254FD2C9E
00007f0254fcfe15  vmovaps xmm10, [rsp+0x30]
00007f0254fcfe1b  movaps xmm1, xmm15
00007f0254fcfe1f  addpd xmm1, xmm10
00007f0254fcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007f0254fcfe29  ptest xmm2, xmm2
00007f0254fcfe2e  jnz 0x00007F0254FD2DE1
00007f0254fcfe34  vmovaps xmm10, [rsp+0xC0]
00007f0254fcfe3d  movaps xmm15, xmm10
00007f0254fcfe41  addpd xmm15, xmm11
00007f0254fcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007f0254fcfe4c  ptest xmm2, xmm2
00007f0254fcfe51  jnz 0x00007F0254FD2F23
00007f0254fcfe57  vmovaps xmm11, [rsp+0x80]
00007f0254fcfe60  vpermilpd xmm11, xmm11, 0x00
00007f0254fcfe66  movaps xmm10, xmm12
00007f0254fcfe6a  mulpd xmm10, xmm11
00007f0254fcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007f0254fcfe75  ptest xmm2, xmm2
00007f0254fcfe7a  jnz 0x00007F0254FD3067
00007f0254fcfe80  vmovaps xmm12, [rsp+0x80]
00007f0254fcfe89  vpermilpd xmm12, xmm12, 0x00
00007f0254fcfe8f  vmovaps xmm2, [rsp+0xA0]
00007f0254fcfe98  vmovaps [rsp+0x30], xmm1
00007f0254fcfe9e  movaps xmm11, xmm2
00007f0254fcfea2  mulpd xmm11, xmm12
00007f0254fcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007f0254fcfead  ptest xmm1, xmm1
00007f0254fcfeb2  jnz 0x00007F0254FD31AB
00007f0254fcfeb8  movaps xmm1, xmm14
00007f0254fcfebc  addpd xmm1, xmm6
00007f0254fcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007f0254fcfec5  ptest xmm12, xmm12
00007f0254fcfecb  jnz 0x00007F0254FD32EE
00007f0254fcfed1  vmovaps xmm12, [rsp+0x20]
00007f0254fcfed7  movaps xmm14, xmm12
00007f0254fcfedb  addpd xmm14, xmm5
00007f0254fcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007f0254fcfee6  ptest xmm6, xmm6
00007f0254fcfeeb  jnz 0x00007F0254FD342F
00007f0254fcfef1  vmovaps xmm12, [rsp+0x90]
00007f0254fcfefa  vpermilpd xmm12, xmm12, 0x00
00007f0254fcff00  movaps xmm6, xmm9
00007f0254fcff04  mulpd xmm6, xmm12
00007f0254fcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007f0254fcff0e  ptest xmm5, xmm5
00007f0254fcff13  jnz 0x00007F0254FD3572
00007f0254fcff19  movaps xmm12, xmm15
00007f0254fcff1d  addpd xmm12, xmm13
00007f0254fcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007f0254fcff28  ptest xmm9, xmm9
00007f0254fcff2e  jnz 0x00007F0254FD36B4
00007f0254fcff34  vmovaps xmm13, [rsp+0x30]
00007f0254fcff3a  movaps xmm15, xmm13
00007f0254fcff3e  addpd xmm15, xmm10
00007f0254fcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007f0254fcff49  ptest xmm9, xmm9
00007f0254fcff4f  jnz 0x00007F0254FD37F8
00007f0254fcff55  vmovaps xmm13, [rsp+0xD0]
00007f0254fcff5e  vmovaps xmm10, [rsp+0xD0]
00007f0254fcff67  por xmm13, xmm10
00007f0254fcff6c  movaps [r15+0x250], xmm13
00007f0254fcff74  vmovaps [rsp+0x20], xmm7
00007f0254fcff7a  vmovaps xmm13, [rsp+0x20]
00007f0254fcff80  por xmm7, xmm13
00007f0254fcff85  movaps [r15+0x2A0], xmm7
00007f0254fcff8d  vmovaps [rsp+0x20], xmm3
00007f0254fcff93  vmovaps xmm13, [rsp+0x20]
00007f0254fcff99  por xmm3, xmm13
00007f0254fcff9e  movaps [r15+0x1D0], xmm3
00007f0254fcffa6  lea rax, [r14+0x40]
00007f0254fcffaa  movups xmm13, [r13+rax*1]
00007f0254fcffb0  movaps [r15+0x2C0], xmm13
00007f0254fcffb8  vmovaps xmm10, [rsp+0x90]
00007f0254fcffc1  vpermilpd xmm10, xmm10, 0x00
00007f0254fcffc7  movaps xmm9, xmm8
00007f0254fcffcb  mulpd xmm9, xmm10
00007f0254fcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007f0254fcffd6  ptest xmm5, xmm5
00007f0254fcffdb  jnz 0x00007F0254FD3946
00007f0254fcffe1  movaps xmm10, xmm1
00007f0254fcffe5  addpd xmm10, xmm11
00007f0254fcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007f0254fcfff0  ptest xmm8, xmm8
00007f0254fcfff6  jnz 0x00007F0254FD3A8A
00007f0254fcfffc  movaps xmm1, xmm14
00007f0254fd0000  addpd xmm1, xmm6
00007f0254fd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007f0254fd0009  ptest xmm11, xmm11
00007f0254fd000f  jnz 0x00007F0254FD3BCD
00007f0254fd0015  vmovaps xmm14, [rsp+0x90]
00007f0254fd001e  vpermilpd xmm14, xmm14, 0x00
00007f0254fd0024  movaps xmm11, xmm13
00007f0254fd0028  mulpd xmm11, xmm14
00007f0254fd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007f0254fd0033  ptest xmm8, xmm8
00007f0254fd0039  jnz 0x00007F0254FD3D0E
00007f0254fd003f  vmovaps xmm14, [rsp+0x90]
00007f0254fd0048  vpermilpd xmm14, xmm14, 0x00
00007f0254fd004e  vmovaps xmm8, [rsp+0x10]
00007f0254fd0054  movaps xmm13, xmm8
00007f0254fd0058  mulpd xmm13, xmm14
00007f0254fd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007f0254fd0063  ptest xmm6, xmm6
00007f0254fd0068  jnz 0x00007F0254FD3E52
00007f0254fd006e  vmovaps xmm14, [rsp+0x60]
00007f0254fd0074  vpermilpd xmm14, xmm14, 0x00
00007f0254fd007a  movaps xmm8, xmm7
00007f0254fd007e  mulpd xmm8, xmm14
00007f0254fd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007f0254fd0089  ptest xmm6, xmm6
00007f0254fd008e  jnz 0x00007F0254FD3F96
00007f0254fd0094  movaps xmm14, xmm12
00007f0254fd0098  addpd xmm14, xmm9
00007f0254fd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007f0254fd00a3  ptest xmm7, xmm7
00007f0254fd00a8  jnz 0x00007F0254FD40D9
00007f0254fd00ae  vmovaps xmm12, [rsp+0x60]
00007f0254fd00b4  vpermilpd xmm12, xmm12, 0x00
00007f0254fd00ba  vmovaps xmm7, [rsp+0xF0]
00007f0254fd00c3  movaps xmm9, xmm7
00007f0254fd00c7  mulpd xmm9, xmm12
00007f0254fd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007f0254fd00d2  ptest xmm6, xmm6
00007f0254fd00d7  jnz 0x00007F0254FD421D
00007f0254fd00dd  movaps xmm12, xmm15
00007f0254fd00e1  addpd xmm12, xmm11
00007f0254fd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007f0254fd00ec  ptest xmm7, xmm7
00007f0254fd00f1  jnz 0x00007F0254FD4360
00007f0254fd00f7  vmovaps xmm15, [rsp+0x60]
00007f0254fd00fd  vpermilpd xmm15, xmm15, 0x00
00007f0254fd0103  vmovaps xmm7, [rsp+0x40]
00007f0254fd0109  movaps xmm11, xmm7
00007f0254fd010d  mulpd xmm11, xmm15
00007f0254fd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007f0254fd0118  ptest xmm6, xmm6
00007f0254fd011d  jnz 0x00007F0254FD44A4
00007f0254fd0123  movaps xmm15, xmm10
00007f0254fd0127  addpd xmm15, xmm13
00007f0254fd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007f0254fd0132  ptest xmm7, xmm7
00007f0254fd0137  jnz 0x00007F0254FD45E7
00007f0254fd013d  vmovaps xmm13, [rsp+0x60]
00007f0254fd0143  vpermilpd xmm13, xmm13, 0x00
00007f0254fd0149  vmovaps xmm7, [rsp+0x50]
00007f0254fd014f  movaps xmm10, xmm7
00007f0254fd0153  mulpd xmm10, xmm13
00007f0254fd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007f0254fd015e  ptest xmm6, xmm6
00007f0254fd0163  jnz 0x00007F0254FD472B
00007f0254fd0169  movaps xmm13, xmm1
00007f0254fd016d  addpd xmm13, xmm8
00007f0254fd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007f0254fd0178  ptest xmm7, xmm7
00007f0254fd017d  jnz 0x00007F0254FD486E
00007f0254fd0183  lea rax, [r14+0x70]
00007f0254fd0187  movups xmm1, [r13+rax*1]
00007f0254fd018d  movaps [r15+0x240], xmm1
00007f0254fd0195  movaps xmm8, xmm14
00007f0254fd0199  addpd xmm8, xmm9
00007f0254fd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007f0254fd01a4  ptest xmm7, xmm7
00007f0254fd01a9  jnz 0x00007F0254FD49BB
00007f0254fd01af  movaps [r15+0x170], xmm8
00007f0254fd01b7  vmovaps xmm14, [rsp+0x70]
00007f0254fd01bd  vpermilpd xmm14, xmm14, 0x00
00007f0254fd01c3  movaps xmm9, xmm1
00007f0254fd01c7  mulpd xmm9, xmm14
00007f0254fd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007f0254fd01d2  ptest xmm7, xmm7
00007f0254fd01d7  jnz 0x00007F0254FD4AFF
00007f0254fd01dd  vmovaps xmm1, [rsp+0x70]
00007f0254fd01e3  vpermilpd xmm1, xmm1, 0x00
00007f0254fd01e9  movaps xmm14, xmm4
00007f0254fd01ed  mulpd xmm14, xmm1
00007f0254fd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007f0254fd01f8  ptest xmm7, xmm7
00007f0254fd01fd  jnz 0x00007F0254FD4C42
00007f0254fd0203  movaps [r15+0x180], xmm14
00007f0254fd020b  movaps xmm1, xmm12
00007f0254fd020f  addpd xmm1, xmm11
00007f0254fd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007f0254fd0219  ptest xmm7, xmm7
00007f0254fd021e  jnz 0x00007F0254FD4D84
00007f0254fd0224  movaps [r15+0x210], xmm1
00007f0254fd022c  movups xmm12, [r13+r14*1]
00007f0254fd0232  lea rax, [r14+0x10]
00007f0254fd0236  movups xmm11, [r13+rax*1]
00007f0254fd023c  movaps [r15+0x230], xmm11
00007f0254fd0244  movaps xmm7, xmm15
00007f0254fd0248  addpd xmm7, xmm10
00007f0254fd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0254fd0252  ptest xmm6, xmm6
00007f0254fd0257  jnz 0x00007F0254FD4EDA
00007f0254fd025d  movaps [r15+0x130], xmm7
00007f0254fd0265  vmovaps xmm15, [rsp+0x70]
00007f0254fd026b  vpermilpd xmm15, xmm15, 0x00
00007f0254fd0271  movaps xmm10, xmm11
00007f0254fd0275  mulpd xmm10, xmm15
00007f0254fd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007f0254fd0280  ptest xmm6, xmm6
00007f0254fd0285  jnz 0x00007F0254FD501C
00007f0254fd028b  movaps [r15+0x220], xmm10
00007f0254fd0293  vmovaps xmm15, [rsp+0x70]
00007f0254fd0299  vpermilpd xmm15, xmm15, 0x00
00007f0254fd029f  movaps xmm11, xmm12
00007f0254fd02a3  mulpd xmm11, xmm15
00007f0254fd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007f0254fd02ae  ptest xmm6, xmm6
00007f0254fd02b3  jnz 0x00007F0254FD5160
00007f0254fd02b9  movaps xmm15, xmm13
00007f0254fd02bd  addpd xmm15, xmm9
00007f0254fd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007f0254fd02c8  ptest xmm12, xmm12
00007f0254fd02ce  jnz 0x00007F0254FD52A4
00007f0254fd02d4  movaps [r15+0x140], xmm15
00007f0254fd02dc  movaps xmm13, xmm8
00007f0254fd02e0  addpd xmm13, xmm14
00007f0254fd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007f0254fd02eb  ptest xmm12, xmm12
00007f0254fd02f1  jnz 0x00007F0254FD53E8
00007f0254fd02f7  movaps [r15+0x150], xmm13
00007f0254fd02ff  movaps xmm14, xmm1
00007f0254fd0303  addpd xmm14, xmm10
00007f0254fd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007f0254fd030e  ptest xmm12, xmm12
00007f0254fd0314  jnz 0x00007F0254FD552C
00007f0254fd031a  movaps [r15+0x160], xmm14
00007f0254fd0322  movaps xmm1, xmm7
00007f0254fd0325  addpd xmm1, xmm11
00007f0254fd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007f0254fd032f  ptest xmm12, xmm12
00007f0254fd0335  jnz 0x00007F0254FD566F
00007f0254fd033b  movaps [r15+0x120], xmm1
00007f0254fd0343  mov eax, 0x430920
00007f0254fd0348  movups [r13+rax*1], xmm15
00007f0254fd034e  mov eax, 0x430930
00007f0254fd0353  movups [r13+rax*1], xmm13
00007f0254fd0359  mov eax, 0x430940
00007f0254fd035e  movups [r13+rax*1], xmm14
00007f0254fd0364  mov eax, 0x430950
00007f0254fd0369  movups [r13+rax*1], xmm1
00007f0254fd036f  mov eax, [r15+0x108]
00007f0254fd0376  sahf
00007f0254fd0377  jnz 0x00007F0254FD03A9
00007f0254fd0379  cmp dword ptr [r15+0x318], 0x00
00007f0254fd0381  jz 0x00007F0254FDB900
00007f0254fd0387  nop [rax+rax*1], ax
00007f0254fd0390  nop [rax+rax*1], eax
00007f0254fd0398  mov eax, 0x410444
00007f0254fd039d  mov [r15+0x100], rax
00007f0254fd03a4  jmp 0x00007F0254DFE110
00007f0254fd03a9  cmp dword ptr [r15+0x318], 0x00
00007f0254fd03b1  jz 0x00007F0254FD57E0
00007f0254fd03b7  nop [rax+rax*1], ax
00007f0254fd03c0  nop [rax+rax*1], eax
00007f0254fd03c8  mov eax, 0x410278
00007f0254fd03cd  mov [r15+0x100], rax
00007f0254fd03d4  jmp 0x00007F0254DFE110
00007f0254fd03d9  int3
00007f0254fd03da  call 0x00007F0254EB52F0
00007f0254fd03df  jmp 0x00007F0254FCF016
00007f0254fd03e4  call 0x00007F0254EC4620
00007f0254fd03e9  jmp 0x00007F0254FCF023
00007f0254fd03ee  call 0x00007F0254EC33A0
00007f0254fd03f3  jmp 0x00007F0254FCF035
00007f0254fd03f8  call 0x00007F0254EC2120
00007f0254fd03fd  jmp 0x00007F0254FCF03F
00007f0254fd0402  call 0x00007F0254EC0860
00007f0254fd0407  jmp 0x00007F0254FCF067
00007f0254fd040c  call 0x00007F0254EBF5F0
00007f0254fd0411  jmp 0x00007F0254FCF073
00007f0254fd0416  call 0x00007F0254EC0860
00007f0254fd041b  jmp 0x00007F0254FCF0A5
00007f0254fd0420  call 0x00007F0254EBF5F0
00007f0254fd0425  jmp 0x00007F0254FCF0B1
00007f0254fd042a  call 0x00007F0254EC4740
00007f0254fd042f  jmp 0x00007F0254FCF0BE
00007f0254fd0434  call 0x00007F0254EB5400
00007f0254fd0439  jmp 0x00007F0254FCF0CB
00007f0254fd043e  call 0x00007F0254EB52F0
00007f0254fd0443  jmp 0x00007F0254FCF0D8
00007f0254fd0448  call 0x00007F0254EC4620
00007f0254fd044d  jmp 0x00007F0254FCF0E5
00007f0254fd0452  call 0x00007F0254EC0860
00007f0254fd0457  jmp 0x00007F0254FCF10D
00007f0254fd045c  call 0x00007F0254EBF5F0
00007f0254fd0461  jmp 0x00007F0254FCF119
00007f0254fd0466  call 0x00007F0254E09D70
00007f0254fd046b  jmp 0x00007F0254FCF11F
00007f0254fd0470  call 0x00007F0254EBE9C0
00007f0254fd0475  jmp 0x00007F0254FCF129
00007f0254fd047a  call 0x00007F0254EC0860
00007f0254fd047f  jmp 0x00007F0254FCF151
00007f0254fd0484  call 0x00007F0254EBF5F0
00007f0254fd0489  jmp 0x00007F0254FCF15D
00007f0254fd048e  call 0x00007F0254EBD750
00007f0254fd0493  jmp 0x00007F0254FCF16A
00007f0254fd0498  call 0x00007F0254EBC4E0
00007f0254fd049d  jmp 0x00007F0254FCF177
00007f0254fd04a2  call 0x00007F0254EC4740
00007f0254fd04a7  jmp 0x00007F0254FCF184
00007f0254fd04ac  call 0x00007F0254EB5400
00007f0254fd04b1  jmp 0x00007F0254FCF191
00007f0254fd04b6  call 0x00007F0254EB52F0
00007f0254fd04bb  jmp 0x00007F0254FCF19E
00007f0254fd04c0  call 0x00007F0254EC4620
00007f0254fd04c5  jmp 0x00007F0254FCF1AB
00007f0254fd04ca  call 0x00007F0254EC0860
00007f0254fd04cf  jmp 0x00007F0254FCF1BE
00007f0254fd04d4  call 0x00007F0254EBB270
00007f0254fd04d9  jmp 0x00007F0254FCF1CB
00007f0254fd04de  call 0x00007F0254EBA000
00007f0254fd04e3  jmp 0x00007F0254FCF1D8
00007f0254fd04e8  call 0x00007F0254EB8D90
00007f0254fd04ed  jmp 0x00007F0254FCF1E5
00007f0254fd04f2  call 0x00007F0254EB8A20
00007f0254fd04f7  jmp 0x00007F0254FCF1F2
00007f0254fd04fc  call 0x00007F0254EB5400
00007f0254fd0501  jmp 0x00007F0254FCF1FC
00007f0254fd0506  call 0x00007F0254EC2240
00007f0254fd050b  jmp 0x00007F0254FCF206
00007f0254fd0510  call 0x00007F0254EB52F0
00007f0254fd0515  jmp 0x00007F0254FCF210
00007f0254fd051a  call 0x00007F0254EC2120
00007f0254fd051f  jmp 0x00007F0254FCF21A
00007f0254fd0524  call 0x00007F0254EB77B0
00007f0254fd0529  jmp 0x00007F0254FCF224
00007f0254fd052e  call 0x00007F0254EB6550
00007f0254fd0533  jmp 0x00007F0254FCF22E
00007f0254fd0538  call 0x00007F0254EBFD50
00007f0254fd053d  jmp 0x00007F0254FCF240
00007f0254fd0542  call 0x00007F0254EB8EA0
00007f0254fd0547  jmp 0x00007F0254FCF24A
00007f0254fd054c  call 0x00007F0254EBFC30
00007f0254fd0551  jmp 0x00007F0254FCF257
00007f0254fd0556  call 0x00007F0254EB8D90
00007f0254fd055b  jmp 0x00007F0254FCF264
00007f0254fd0560  call 0x00007F0254EC2240
00007f0254fd0565  jmp 0x00007F0254FCF271
00007f0254fd056a  call 0x00007F0254EB5400
00007f0254fd056f  jmp 0x00007F0254FCF27E
00007f0254fd0574  call 0x00007F0254EB52F0
00007f0254fd0579  jmp 0x00007F0254FCF28B
00007f0254fd057e  call 0x00007F0254EC2120
00007f0254fd0583  jmp 0x00007F0254FCF298
00007f0254fd0588  call 0x00007F0254EB52F0
00007f0254fd058d  jmp 0x00007F0254FCF2AB
00007f0254fd0592  call 0x00007F0254EB52F0
00007f0254fd0597  jmp 0x00007F0254FCF2BE
00007f0254fd059c  call 0x00007F0254EB52F0
00007f0254fd05a1  jmp 0x00007F0254FCF2D1
00007f0254fd05a6  call 0x00007F0254EB52F0
00007f0254fd05ab  jmp 0x00007F0254FCF2E4
00007f0254fd05b0  call 0x00007F0254EC2240
00007f0254fd05b5  jmp 0x00007F0254FCF2F9
00007f0254fd05ba  call 0x00007F0254EC2240
00007f0254fd05bf  jmp 0x00007F0254FCF30C
00007f0254fd05c4  call 0x00007F0254EC2120
00007f0254fd05c9  jmp 0x00007F0254FCF319
00007f0254fd05ce  call 0x00007F0254EB52F0
00007f0254fd05d3  jmp 0x00007F0254FCF32C
00007f0254fd05d8  call 0x00007F0254EB52F0
00007f0254fd05dd  jmp 0x00007F0254FCF34F
00007f0254fd05e2  call 0x00007F0254EB52F0
00007f0254fd05e7  jmp 0x00007F0254FCF362
00007f0254fd05ec  call 0x00007F0254DFF540
00007f0254fd05f1  jmp 0x00007F0254FCF380
00007f0254fd05f6  call 0x00007F0254E08C20
00007f0254fd05fb  jmp 0x00007F0254FCF38A
00007f0254fd0600  call 0x00007F0254ED6600
00007f0254fd0605  jmp 0x00007F0254FCF396
00007f0254fd060a  call 0x00007F0254DFF540
00007f0254fd060f  jmp 0x00007F0254FCF3A6
00007f0254fd0614  call 0x00007F0254EC0370
00007f0254fd0619  jmp 0x00007F0254FCF3D4
00007f0254fd061e  call 0x00007F0254EBF100
00007f0254fd0623  jmp 0x00007F0254FCF3DD
00007f0254fd0628  call 0x00007F0254EC0370
00007f0254fd062d  jmp 0x00007F0254FCF43B
00007f0254fd0632  call 0x00007F0254EBF100
00007f0254fd0637  jmp 0x00007F0254FCF444
00007f0254fd063c  call 0x00007F0254EC0370
00007f0254fd0641  jmp 0x00007F0254FCF48B
00007f0254fd0646  call 0x00007F0254EBF100
00007f0254fd064b  jmp 0x00007F0254FCF494
00007f0254fd0650  call 0x00007F0254E0B720
00007f0254fd0655  jmp 0x00007F0254FCF4D7
00007f0254fd065a  call 0x00007F0254EB47C0
00007f0254fd065f  jmp 0x00007F0254FCF4EA
00007f0254fd0664  call 0x00007F0254E08B00
00007f0254fd0669  jmp 0x00007F0254FCF501
00007f0254fd066e  call 0x00007F0254DFF430
00007f0254fd0673  jmp 0x00007F0254FCF514
00007f0254fd0678  call 0x00007F0254DFF430
00007f0254fd067d  jmp 0x00007F0254FCF527
00007f0254fd0682  sub rsp, 0x08
00007f0254fd0686  push rax
00007f0254fd0687  push rcx
00007f0254fd0688  push rdx
00007f0254fd0689  push rdi
00007f0254fd068a  push rsi
00007f0254fd068b  push r8
00007f0254fd068d  push r9
00007f0254fd068f  push r10
00007f0254fd0691  push r11
00007f0254fd0693  sub rsp, 0xF0
00007f0254fd069a  vmovaps [rsp], xmm0
00007f0254fd069f  vmovaps [rsp+0x10], xmm2
00007f0254fd06a5  vmovaps [rsp+0x20], xmm3
00007f0254fd06ab  vmovaps [rsp+0x30], xmm4
00007f0254fd06b1  vmovaps [rsp+0x40], xmm5
00007f0254fd06b7  vmovaps [rsp+0x50], xmm6
00007f0254fd06bd  vmovaps [rsp+0x60], xmm7
00007f0254fd06c3  vmovaps [rsp+0x70], xmm8
00007f0254fd06c9  vmovaps [rsp+0x80], xmm9
00007f0254fd06d2  vmovaps [rsp+0x90], xmm10
00007f0254fd06db  vmovaps [rsp+0xA0], xmm11
00007f0254fd06e4  vmovaps [rsp+0xB0], xmm12
00007f0254fd06ed  vmovaps [rsp+0xC0], xmm13
00007f0254fd06f6  vmovaps [rsp+0xD0], xmm14
00007f0254fd06ff  vmovaps [rsp+0xE0], xmm15
00007f0254fd0708  sub rsp, 0x30
00007f0254fd070c  movaps [rsp], xmm1
00007f0254fd0710  movaps [rsp+0x10], xmm15
00007f0254fd0716  movaps [rsp+0x20], xmm14
00007f0254fd071c  lea rdi, [rsp]
00007f0254fd0720  mov esi, 0x00
00007f0254fd0725  mov rax, 0x55DD1360A530
00007f0254fd072f  call rax
00007f0254fd0731  movaps xmm1, [rsp]
00007f0254fd0735  add rsp, 0x30
00007f0254fd0739  vmovaps xmm0, [rsp]
00007f0254fd073e  vmovaps xmm2, [rsp+0x10]
00007f0254fd0744  vmovaps xmm3, [rsp+0x20]
00007f0254fd074a  vmovaps xmm4, [rsp+0x30]
00007f0254fd0750  vmovaps xmm5, [rsp+0x40]
00007f0254fd0756  vmovaps xmm6, [rsp+0x50]
00007f0254fd075c  vmovaps xmm7, [rsp+0x60]
00007f0254fd0762  vmovaps xmm8, [rsp+0x70]
00007f0254fd0768  vmovaps xmm9, [rsp+0x80]
00007f0254fd0771  vmovaps xmm10, [rsp+0x90]
00007f0254fd077a  vmovaps xmm11, [rsp+0xA0]
00007f0254fd0783  vmovaps xmm12, [rsp+0xB0]
00007f0254fd078c  vmovaps xmm13, [rsp+0xC0]
00007f0254fd0795  vmovaps xmm14, [rsp+0xD0]
00007f0254fd079e  vmovaps xmm15, [rsp+0xE0]
00007f0254fd07a7  add rsp, 0xF0
00007f0254fd07ae  pop r11
00007f0254fd07b0  pop r10
00007f0254fd07b2  pop r9
00007f0254fd07b4  pop r8
00007f0254fd07b6  pop rsi
00007f0254fd07b7  pop rdi
00007f0254fd07b8  pop rdx
00007f0254fd07b9  pop rcx
00007f0254fd07ba  pop rax
00007f0254fd07bb  add rsp, 0x08
00007f0254fd07bf  jmp 0x00007F0254FCF581
00007f0254fd07c4  sub rsp, 0x08
00007f0254fd07c8  push rax
00007f0254fd07c9  push rcx
00007f0254fd07ca  push rdx
00007f0254fd07cb  push rdi
00007f0254fd07cc  push rsi
00007f0254fd07cd  push r8
00007f0254fd07cf  push r9
00007f0254fd07d1  push r10
00007f0254fd07d3  push r11
00007f0254fd07d5  sub rsp, 0xF0
00007f0254fd07dc  vmovaps [rsp], xmm0
00007f0254fd07e1  vmovaps [rsp+0x10], xmm1
00007f0254fd07e7  vmovaps [rsp+0x20], xmm2
00007f0254fd07ed  vmovaps [rsp+0x30], xmm3
00007f0254fd07f3  vmovaps [rsp+0x40], xmm4
00007f0254fd07f9  vmovaps [rsp+0x50], xmm5
00007f0254fd07ff  vmovaps [rsp+0x60], xmm6
00007f0254fd0805  vmovaps [rsp+0x70], xmm7
00007f0254fd080b  vmovaps [rsp+0x80], xmm8
00007f0254fd0814  vmovaps [rsp+0x90], xmm9
00007f0254fd081d  vmovaps [rsp+0xA0], xmm10
00007f0254fd0826  vmovaps [rsp+0xB0], xmm11
00007f0254fd082f  vmovaps [rsp+0xC0], xmm12
00007f0254fd0838  vmovaps [rsp+0xD0], xmm14
00007f0254fd0841  vmovaps [rsp+0xE0], xmm15
00007f0254fd084a  sub rsp, 0x30
00007f0254fd084e  movaps [rsp], xmm13
00007f0254fd0853  movaps [rsp+0x10], xmm1
00007f0254fd0858  movaps [rsp+0x20], xmm14
00007f0254fd085e  lea rdi, [rsp]
00007f0254fd0862  mov esi, 0x00
00007f0254fd0867  mov rax, 0x55DD1360A530
00007f0254fd0871  call rax
00007f0254fd0873  movaps xmm13, [rsp]
00007f0254fd0878  add rsp, 0x30
00007f0254fd087c  vmovaps xmm0, [rsp]
00007f0254fd0881  vmovaps xmm1, [rsp+0x10]
00007f0254fd0887  vmovaps xmm2, [rsp+0x20]
00007f0254fd088d  vmovaps xmm3, [rsp+0x30]
00007f0254fd0893  vmovaps xmm4, [rsp+0x40]
00007f0254fd0899  vmovaps xmm5, [rsp+0x50]
00007f0254fd089f  vmovaps xmm6, [rsp+0x60]
00007f0254fd08a5  vmovaps xmm7, [rsp+0x70]
00007f0254fd08ab  vmovaps xmm8, [rsp+0x80]
00007f0254fd08b4  vmovaps xmm9, [rsp+0x90]
00007f0254fd08bd  vmovaps xmm10, [rsp+0xA0]
00007f0254fd08c6  vmovaps xmm11, [rsp+0xB0]
00007f0254fd08cf  vmovaps xmm12, [rsp+0xC0]
00007f0254fd08d8  vmovaps xmm14, [rsp+0xD0]
00007f0254fd08e1  vmovaps xmm15, [rsp+0xE0]
00007f0254fd08ea  add rsp, 0xF0
00007f0254fd08f1  pop r11
00007f0254fd08f3  pop r10
00007f0254fd08f5  pop r9
00007f0254fd08f7  pop r8
00007f0254fd08f9  pop rsi
00007f0254fd08fa  pop rdi
00007f0254fd08fb  pop rdx
00007f0254fd08fc  pop rcx
00007f0254fd08fd  pop rax
00007f0254fd08fe  add rsp, 0x08
00007f0254fd0902  jmp 0x00007F0254FCF5CF
00007f0254fd0907  sub rsp, 0x08
00007f0254fd090b  push rax
00007f0254fd090c  push rcx
00007f0254fd090d  push rdx
00007f0254fd090e  push rdi
00007f0254fd090f  push rsi
00007f0254fd0910  push r8
00007f0254fd0912  push r9
00007f0254fd0914  push r10
00007f0254fd0916  push r11
00007f0254fd0918  sub rsp, 0xF0
00007f0254fd091f  vmovaps [rsp], xmm0
00007f0254fd0924  vmovaps [rsp+0x10], xmm1
00007f0254fd092a  vmovaps [rsp+0x20], xmm2
00007f0254fd0930  vmovaps [rsp+0x30], xmm3
00007f0254fd0936  vmovaps [rsp+0x40], xmm4
00007f0254fd093c  vmovaps [rsp+0x50], xmm5
00007f0254fd0942  vmovaps [rsp+0x60], xmm6
00007f0254fd0948  vmovaps [rsp+0x70], xmm7
00007f0254fd094e  vmovaps [rsp+0x80], xmm8
00007f0254fd0957  vmovaps [rsp+0x90], xmm9
00007f0254fd0960  vmovaps [rsp+0xA0], xmm10
00007f0254fd0969  vmovaps [rsp+0xB0], xmm11
00007f0254fd0972  vmovaps [rsp+0xC0], xmm12
00007f0254fd097b  vmovaps [rsp+0xD0], xmm13
00007f0254fd0984  vmovaps [rsp+0xE0], xmm14
00007f0254fd098d  sub rsp, 0x30
00007f0254fd0991  movaps [rsp], xmm15
00007f0254fd0996  movaps [rsp+0x10], xmm14
00007f0254fd099c  movaps [rsp+0x20], xmm1
00007f0254fd09a1  lea rdi, [rsp]
00007f0254fd09a5  mov esi, 0x00
00007f0254fd09aa  mov rax, 0x55DD1360A530
00007f0254fd09b4  call rax
00007f0254fd09b6  movaps xmm15, [rsp]
00007f0254fd09bb  add rsp, 0x30
00007f0254fd09bf  vmovaps xmm0, [rsp]
00007f0254fd09c4  vmovaps xmm1, [rsp+0x10]
00007f0254fd09ca  vmovaps xmm2, [rsp+0x20]
00007f0254fd09d0  vmovaps xmm3, [rsp+0x30]
00007f0254fd09d6  vmovaps xmm4, [rsp+0x40]
00007f0254fd09dc  vmovaps xmm5, [rsp+0x50]
00007f0254fd09e2  vmovaps xmm6, [rsp+0x60]
00007f0254fd09e8  vmovaps xmm7, [rsp+0x70]
00007f0254fd09ee  vmovaps xmm8, [rsp+0x80]
00007f0254fd09f7  vmovaps xmm9, [rsp+0x90]
00007f0254fd0a00  vmovaps xmm10, [rsp+0xA0]
00007f0254fd0a09  vmovaps xmm11, [rsp+0xB0]
00007f0254fd0a12  vmovaps xmm12, [rsp+0xC0]
00007f0254fd0a1b  vmovaps xmm13, [rsp+0xD0]
00007f0254fd0a24  vmovaps xmm14, [rsp+0xE0]
00007f0254fd0a2d  add rsp, 0xF0
00007f0254fd0a34  pop r11
00007f0254fd0a36  pop r10
00007f0254fd0a38  pop r9
00007f0254fd0a3a  pop r8
00007f0254fd0a3c  pop rsi
00007f0254fd0a3d  pop rdi
00007f0254fd0a3e  pop rdx
00007f0254fd0a3f  pop rcx
00007f0254fd0a40  pop rax
00007f0254fd0a41  add rsp, 0x08
00007f0254fd0a45  jmp 0x00007F0254FCF617
00007f0254fd0a4a  sub rsp, 0x08
00007f0254fd0a4e  push rax
00007f0254fd0a4f  push rcx
00007f0254fd0a50  push rdx
00007f0254fd0a51  push rdi
00007f0254fd0a52  push rsi
00007f0254fd0a53  push r8
00007f0254fd0a55  push r9
00007f0254fd0a57  push r10
00007f0254fd0a59  push r11
00007f0254fd0a5b  sub rsp, 0xF0
00007f0254fd0a62  vmovaps [rsp], xmm0
00007f0254fd0a67  vmovaps [rsp+0x10], xmm2
00007f0254fd0a6d  vmovaps [rsp+0x20], xmm3
00007f0254fd0a73  vmovaps [rsp+0x30], xmm4
00007f0254fd0a79  vmovaps [rsp+0x40], xmm5
00007f0254fd0a7f  vmovaps [rsp+0x50], xmm6
00007f0254fd0a85  vmovaps [rsp+0x60], xmm7
00007f0254fd0a8b  vmovaps [rsp+0x70], xmm8
00007f0254fd0a91  vmovaps [rsp+0x80], xmm9
00007f0254fd0a9a  vmovaps [rsp+0x90], xmm10
00007f0254fd0aa3  vmovaps [rsp+0xA0], xmm11
00007f0254fd0aac  vmovaps [rsp+0xB0], xmm12
00007f0254fd0ab5  vmovaps [rsp+0xC0], xmm13
00007f0254fd0abe  vmovaps [rsp+0xD0], xmm14
00007f0254fd0ac7  vmovaps [rsp+0xE0], xmm15
00007f0254fd0ad0  sub rsp, 0x30
00007f0254fd0ad4  movaps [rsp], xmm1
00007f0254fd0ad8  movaps [rsp+0x10], xmm14
00007f0254fd0ade  movaps [rsp+0x20], xmm10
00007f0254fd0ae4  lea rdi, [rsp]
00007f0254fd0ae8  mov esi, 0x00
00007f0254fd0aed  mov rax, 0x55DD1360A530
00007f0254fd0af7  call rax
00007f0254fd0af9  movaps xmm1, [rsp]
00007f0254fd0afd  add rsp, 0x30
00007f0254fd0b01  vmovaps xmm0, [rsp]
00007f0254fd0b06  vmovaps xmm2, [rsp+0x10]
00007f0254fd0b0c  vmovaps xmm3, [rsp+0x20]
00007f0254fd0b12  vmovaps xmm4, [rsp+0x30]
00007f0254fd0b18  vmovaps xmm5, [rsp+0x40]
00007f0254fd0b1e  vmovaps xmm6, [rsp+0x50]
00007f0254fd0b24  vmovaps xmm7, [rsp+0x60]
00007f0254fd0b2a  vmovaps xmm8, [rsp+0x70]
00007f0254fd0b30  vmovaps xmm9, [rsp+0x80]
00007f0254fd0b39  vmovaps xmm10, [rsp+0x90]
00007f0254fd0b42  vmovaps xmm11, [rsp+0xA0]
00007f0254fd0b4b  vmovaps xmm12, [rsp+0xB0]
00007f0254fd0b54  vmovaps xmm13, [rsp+0xC0]
00007f0254fd0b5d  vmovaps xmm14, [rsp+0xD0]
00007f0254fd0b66  vmovaps xmm15, [rsp+0xE0]
00007f0254fd0b6f  add rsp, 0xF0
00007f0254fd0b76  pop r11
00007f0254fd0b78  pop r10
00007f0254fd0b7a  pop r9
00007f0254fd0b7c  pop r8
00007f0254fd0b7e  pop rsi
00007f0254fd0b7f  pop rdi
00007f0254fd0b80  pop rdx
00007f0254fd0b81  pop rcx
00007f0254fd0b82  pop rax
00007f0254fd0b83  add rsp, 0x08
00007f0254fd0b87  jmp 0x00007F0254FCF631
00007f0254fd0b8c  sub rsp, 0x08
00007f0254fd0b90  push rax
00007f0254fd0b91  push rcx
00007f0254fd0b92  push rdx
00007f0254fd0b93  push rdi
00007f0254fd0b94  push rsi
00007f0254fd0b95  push r8
00007f0254fd0b97  push r9
00007f0254fd0b99  push r10
00007f0254fd0b9b  push r11
00007f0254fd0b9d  sub rsp, 0xF0
00007f0254fd0ba4  vmovaps [rsp], xmm0
00007f0254fd0ba9  vmovaps [rsp+0x10], xmm1
00007f0254fd0baf  vmovaps [rsp+0x20], xmm2
00007f0254fd0bb5  vmovaps [rsp+0x30], xmm3
00007f0254fd0bbb  vmovaps [rsp+0x40], xmm4
00007f0254fd0bc1  vmovaps [rsp+0x50], xmm5
00007f0254fd0bc7  vmovaps [rsp+0x60], xmm6
00007f0254fd0bcd  vmovaps [rsp+0x70], xmm7
00007f0254fd0bd3  vmovaps [rsp+0x80], xmm8
00007f0254fd0bdc  vmovaps [rsp+0x90], xmm9
00007f0254fd0be5  vmovaps [rsp+0xA0], xmm10
00007f0254fd0bee  vmovaps [rsp+0xB0], xmm11
00007f0254fd0bf7  vmovaps [rsp+0xC0], xmm12
00007f0254fd0c00  vmovaps [rsp+0xD0], xmm14
00007f0254fd0c09  vmovaps [rsp+0xE0], xmm15
00007f0254fd0c12  sub rsp, 0x30
00007f0254fd0c16  movaps [rsp], xmm13
00007f0254fd0c1b  movaps [rsp+0x10], xmm14
00007f0254fd0c21  movaps [rsp+0x20], xmm2
00007f0254fd0c26  lea rdi, [rsp]
00007f0254fd0c2a  mov esi, 0x00
00007f0254fd0c2f  mov rax, 0x55DD1360A530
00007f0254fd0c39  call rax
00007f0254fd0c3b  movaps xmm13, [rsp]
00007f0254fd0c40  add rsp, 0x30
00007f0254fd0c44  vmovaps xmm0, [rsp]
00007f0254fd0c49  vmovaps xmm1, [rsp+0x10]
00007f0254fd0c4f  vmovaps xmm2, [rsp+0x20]
00007f0254fd0c55  vmovaps xmm3, [rsp+0x30]
00007f0254fd0c5b  vmovaps xmm4, [rsp+0x40]
00007f0254fd0c61  vmovaps xmm5, [rsp+0x50]
00007f0254fd0c67  vmovaps xmm6, [rsp+0x60]
00007f0254fd0c6d  vmovaps xmm7, [rsp+0x70]
00007f0254fd0c73  vmovaps xmm8, [rsp+0x80]
00007f0254fd0c7c  vmovaps xmm9, [rsp+0x90]
00007f0254fd0c85  vmovaps xmm10, [rsp+0xA0]
00007f0254fd0c8e  vmovaps xmm11, [rsp+0xB0]
00007f0254fd0c97  vmovaps xmm12, [rsp+0xC0]
00007f0254fd0ca0  vmovaps xmm14, [rsp+0xD0]
00007f0254fd0ca9  vmovaps xmm15, [rsp+0xE0]
00007f0254fd0cb2  add rsp, 0xF0
00007f0254fd0cb9  pop r11
00007f0254fd0cbb  pop r10
00007f0254fd0cbd  pop r9
00007f0254fd0cbf  pop r8
00007f0254fd0cc1  pop rsi
00007f0254fd0cc2  pop rdi
00007f0254fd0cc3  pop rdx
00007f0254fd0cc4  pop rcx
00007f0254fd0cc5  pop rax
00007f0254fd0cc6  add rsp, 0x08
00007f0254fd0cca  jmp 0x00007F0254FCF64C
00007f0254fd0ccf  sub rsp, 0x08
00007f0254fd0cd3  push rax
00007f0254fd0cd4  push rcx
00007f0254fd0cd5  push rdx
00007f0254fd0cd6  push rdi
00007f0254fd0cd7  push rsi
00007f0254fd0cd8  push r8
00007f0254fd0cda  push r9
00007f0254fd0cdc  push r10
00007f0254fd0cde  push r11
00007f0254fd0ce0  sub rsp, 0xF0
00007f0254fd0ce7  vmovaps [rsp], xmm0
00007f0254fd0cec  vmovaps [rsp+0x10], xmm2
00007f0254fd0cf2  vmovaps [rsp+0x20], xmm3
00007f0254fd0cf8  vmovaps [rsp+0x30], xmm4
00007f0254fd0cfe  vmovaps [rsp+0x40], xmm5
00007f0254fd0d04  vmovaps [rsp+0x50], xmm6
00007f0254fd0d0a  vmovaps [rsp+0x60], xmm7
00007f0254fd0d10  vmovaps [rsp+0x70], xmm8
00007f0254fd0d16  vmovaps [rsp+0x80], xmm9
00007f0254fd0d1f  vmovaps [rsp+0x90], xmm10
00007f0254fd0d28  vmovaps [rsp+0xA0], xmm11
00007f0254fd0d31  vmovaps [rsp+0xB0], xmm12
00007f0254fd0d3a  vmovaps [rsp+0xC0], xmm13
00007f0254fd0d43  vmovaps [rsp+0xD0], xmm14
00007f0254fd0d4c  vmovaps [rsp+0xE0], xmm15
00007f0254fd0d55  sub rsp, 0x30
00007f0254fd0d59  movaps [rsp], xmm1
00007f0254fd0d5d  movaps [rsp+0x10], xmm10
00007f0254fd0d63  movaps [rsp+0x20], xmm2
00007f0254fd0d68  lea rdi, [rsp]
00007f0254fd0d6c  mov esi, 0x00
00007f0254fd0d71  mov rax, 0x55DD1360A530
00007f0254fd0d7b  call rax
00007f0254fd0d7d  movaps xmm1, [rsp]
00007f0254fd0d81  add rsp, 0x30
00007f0254fd0d85  vmovaps xmm0, [rsp]
00007f0254fd0d8a  vmovaps xmm2, [rsp+0x10]
00007f0254fd0d90  vmovaps xmm3, [rsp+0x20]
00007f0254fd0d96  vmovaps xmm4, [rsp+0x30]
00007f0254fd0d9c  vmovaps xmm5, [rsp+0x40]
00007f0254fd0da2  vmovaps xmm6, [rsp+0x50]
00007f0254fd0da8  vmovaps xmm7, [rsp+0x60]
00007f0254fd0dae  vmovaps xmm8, [rsp+0x70]
00007f0254fd0db4  vmovaps xmm9, [rsp+0x80]
00007f0254fd0dbd  vmovaps xmm10, [rsp+0x90]
00007f0254fd0dc6  vmovaps xmm11, [rsp+0xA0]
00007f0254fd0dcf  vmovaps xmm12, [rsp+0xB0]
00007f0254fd0dd8  vmovaps xmm13, [rsp+0xC0]
00007f0254fd0de1  vmovaps xmm14, [rsp+0xD0]
00007f0254fd0dea  vmovaps xmm15, [rsp+0xE0]
00007f0254fd0df3  add rsp, 0xF0
00007f0254fd0dfa  pop r11
00007f0254fd0dfc  pop r10
00007f0254fd0dfe  pop r9
00007f0254fd0e00  pop r8
00007f0254fd0e02  pop rsi
00007f0254fd0e03  pop rdi
00007f0254fd0e04  pop rdx
00007f0254fd0e05  pop rcx
00007f0254fd0e06  pop rax
00007f0254fd0e07  add rsp, 0x08
00007f0254fd0e0b  jmp 0x00007F0254FCF6B4
00007f0254fd0e10  sub rsp, 0x08
00007f0254fd0e14  push rax
00007f0254fd0e15  push rcx
00007f0254fd0e16  push rdx
00007f0254fd0e17  push rdi
00007f0254fd0e18  push rsi
00007f0254fd0e19  push r8
00007f0254fd0e1b  push r9
00007f0254fd0e1d  push r10
00007f0254fd0e1f  push r11
00007f0254fd0e21  sub rsp, 0xF0
00007f0254fd0e28  vmovaps [rsp], xmm0
00007f0254fd0e2d  vmovaps [rsp+0x10], xmm1
00007f0254fd0e33  vmovaps [rsp+0x20], xmm2
00007f0254fd0e39  vmovaps [rsp+0x30], xmm3
00007f0254fd0e3f  vmovaps [rsp+0x40], xmm4
00007f0254fd0e45  vmovaps [rsp+0x50], xmm5
00007f0254fd0e4b  vmovaps [rsp+0x60], xmm6
00007f0254fd0e51  vmovaps [rsp+0x70], xmm7
00007f0254fd0e57  vmovaps [rsp+0x80], xmm8
00007f0254fd0e60  vmovaps [rsp+0x90], xmm9
00007f0254fd0e69  vmovaps [rsp+0xA0], xmm10
00007f0254fd0e72  vmovaps [rsp+0xB0], xmm11
00007f0254fd0e7b  vmovaps [rsp+0xC0], xmm12
00007f0254fd0e84  vmovaps [rsp+0xD0], xmm13
00007f0254fd0e8d  vmovaps [rsp+0xE0], xmm14
00007f0254fd0e96  sub rsp, 0x30
00007f0254fd0e9a  movaps [rsp], xmm15
00007f0254fd0e9f  movaps [rsp+0x10], xmm10
00007f0254fd0ea5  movaps [rsp+0x20], xmm2
00007f0254fd0eaa  lea rdi, [rsp]
00007f0254fd0eae  mov esi, 0x00
00007f0254fd0eb3  mov rax, 0x55DD1360A530
00007f0254fd0ebd  call rax
00007f0254fd0ebf  movaps xmm15, [rsp]
00007f0254fd0ec4  add rsp, 0x30
00007f0254fd0ec8  vmovaps xmm0, [rsp]
00007f0254fd0ecd  vmovaps xmm1, [rsp+0x10]
00007f0254fd0ed3  vmovaps xmm2, [rsp+0x20]
00007f0254fd0ed9  vmovaps xmm3, [rsp+0x30]
00007f0254fd0edf  vmovaps xmm4, [rsp+0x40]
00007f0254fd0ee5  vmovaps xmm5, [rsp+0x50]
00007f0254fd0eeb  vmovaps xmm6, [rsp+0x60]
00007f0254fd0ef1  vmovaps xmm7, [rsp+0x70]
00007f0254fd0ef7  vmovaps xmm8, [rsp+0x80]
00007f0254fd0f00  vmovaps xmm9, [rsp+0x90]
00007f0254fd0f09  vmovaps xmm10, [rsp+0xA0]
00007f0254fd0f12  vmovaps xmm11, [rsp+0xB0]
00007f0254fd0f1b  vmovaps xmm12, [rsp+0xC0]
00007f0254fd0f24  vmovaps xmm13, [rsp+0xD0]
00007f0254fd0f2d  vmovaps xmm14, [rsp+0xE0]
00007f0254fd0f36  add rsp, 0xF0
00007f0254fd0f3d  pop r11
00007f0254fd0f3f  pop r10
00007f0254fd0f41  pop r9
00007f0254fd0f43  pop r8
00007f0254fd0f45  pop rsi
00007f0254fd0f46  pop rdi
00007f0254fd0f47  pop rdx
00007f0254fd0f48  pop rcx
00007f0254fd0f49  pop rax
00007f0254fd0f4a  add rsp, 0x08
00007f0254fd0f4e  jmp 0x00007F0254FCF706
00007f0254fd0f53  sub rsp, 0x08
00007f0254fd0f57  push rax
00007f0254fd0f58  push rcx
00007f0254fd0f59  push rdx
00007f0254fd0f5a  push rdi
00007f0254fd0f5b  push rsi
00007f0254fd0f5c  push r8
00007f0254fd0f5e  push r9
00007f0254fd0f60  push r10
00007f0254fd0f62  push r11
00007f0254fd0f64  sub rsp, 0xF0
00007f0254fd0f6b  vmovaps [rsp], xmm0
00007f0254fd0f70  vmovaps [rsp+0x10], xmm2
00007f0254fd0f76  vmovaps [rsp+0x20], xmm3
00007f0254fd0f7c  vmovaps [rsp+0x30], xmm4
00007f0254fd0f82  vmovaps [rsp+0x40], xmm5
00007f0254fd0f88  vmovaps [rsp+0x50], xmm6
00007f0254fd0f8e  vmovaps [rsp+0x60], xmm7
00007f0254fd0f94  vmovaps [rsp+0x70], xmm8
00007f0254fd0f9a  vmovaps [rsp+0x80], xmm9
00007f0254fd0fa3  vmovaps [rsp+0x90], xmm10
00007f0254fd0fac  vmovaps [rsp+0xA0], xmm11
00007f0254fd0fb5  vmovaps [rsp+0xB0], xmm12
00007f0254fd0fbe  vmovaps [rsp+0xC0], xmm13
00007f0254fd0fc7  vmovaps [rsp+0xD0], xmm14
00007f0254fd0fd0  vmovaps [rsp+0xE0], xmm15
00007f0254fd0fd9  sub rsp, 0x30
00007f0254fd0fdd  movaps [rsp], xmm1
00007f0254fd0fe1  movaps [rsp+0x10], xmm10
00007f0254fd0fe7  movaps [rsp+0x20], xmm12
00007f0254fd0fed  lea rdi, [rsp]
00007f0254fd0ff1  mov esi, 0x00
00007f0254fd0ff6  mov rax, 0x55DD1360A530
00007f0254fd1000  call rax
00007f0254fd1002  movaps xmm1, [rsp]
00007f0254fd1006  add rsp, 0x30
00007f0254fd100a  vmovaps xmm0, [rsp]
00007f0254fd100f  vmovaps xmm2, [rsp+0x10]
00007f0254fd1015  vmovaps xmm3, [rsp+0x20]
00007f0254fd101b  vmovaps xmm4, [rsp+0x30]
00007f0254fd1021  vmovaps xmm5, [rsp+0x40]
00007f0254fd1027  vmovaps xmm6, [rsp+0x50]
00007f0254fd102d  vmovaps xmm7, [rsp+0x60]
00007f0254fd1033  vmovaps xmm8, [rsp+0x70]
00007f0254fd1039  vmovaps xmm9, [rsp+0x80]
00007f0254fd1042  vmovaps xmm10, [rsp+0x90]
00007f0254fd104b  vmovaps xmm11, [rsp+0xA0]
00007f0254fd1054  vmovaps xmm12, [rsp+0xB0]
00007f0254fd105d  vmovaps xmm13, [rsp+0xC0]
00007f0254fd1066  vmovaps xmm14, [rsp+0xD0]
00007f0254fd106f  vmovaps xmm15, [rsp+0xE0]
00007f0254fd1078  add rsp, 0xF0
00007f0254fd107f  pop r11
00007f0254fd1081  pop r10
00007f0254fd1083  pop r9
00007f0254fd1085  pop r8
00007f0254fd1087  pop rsi
00007f0254fd1088  pop rdi
00007f0254fd1089  pop rdx
00007f0254fd108a  pop rcx
00007f0254fd108b  pop rax
00007f0254fd108c  add rsp, 0x08
00007f0254fd1090  jmp 0x00007F0254FCF732
00007f0254fd1095  sub rsp, 0x08
00007f0254fd1099  push rax
00007f0254fd109a  push rcx
00007f0254fd109b  push rdx
00007f0254fd109c  push rdi
00007f0254fd109d  push rsi
00007f0254fd109e  push r8
00007f0254fd10a0  push r9
00007f0254fd10a2  push r10
00007f0254fd10a4  push r11
00007f0254fd10a6  sub rsp, 0xF0
00007f0254fd10ad  vmovaps [rsp], xmm0
00007f0254fd10b2  vmovaps [rsp+0x10], xmm1
00007f0254fd10b8  vmovaps [rsp+0x20], xmm2
00007f0254fd10be  vmovaps [rsp+0x30], xmm3
00007f0254fd10c4  vmovaps [rsp+0x40], xmm4
00007f0254fd10ca  vmovaps [rsp+0x50], xmm5
00007f0254fd10d0  vmovaps [rsp+0x60], xmm6
00007f0254fd10d6  vmovaps [rsp+0x70], xmm7
00007f0254fd10dc  vmovaps [rsp+0x80], xmm8
00007f0254fd10e5  vmovaps [rsp+0x90], xmm9
00007f0254fd10ee  vmovaps [rsp+0xA0], xmm10
00007f0254fd10f7  vmovaps [rsp+0xB0], xmm11
00007f0254fd1100  vmovaps [rsp+0xC0], xmm12
00007f0254fd1109  vmovaps [rsp+0xD0], xmm13
00007f0254fd1112  vmovaps [rsp+0xE0], xmm14
00007f0254fd111b  sub rsp, 0x30
00007f0254fd111f  movaps [rsp], xmm15
00007f0254fd1124  movaps [rsp+0x10], xmm10
00007f0254fd112a  movaps [rsp+0x20], xmm12
00007f0254fd1130  lea rdi, [rsp]
00007f0254fd1134  mov esi, 0x00
00007f0254fd1139  mov rax, 0x55DD1360A530
00007f0254fd1143  call rax
00007f0254fd1145  movaps xmm15, [rsp]
00007f0254fd114a  add rsp, 0x30
00007f0254fd114e  vmovaps xmm0, [rsp]
00007f0254fd1153  vmovaps xmm1, [rsp+0x10]
00007f0254fd1159  vmovaps xmm2, [rsp+0x20]
00007f0254fd115f  vmovaps xmm3, [rsp+0x30]
00007f0254fd1165  vmovaps xmm4, [rsp+0x40]
00007f0254fd116b  vmovaps xmm5, [rsp+0x50]
00007f0254fd1171  vmovaps xmm6, [rsp+0x60]
00007f0254fd1177  vmovaps xmm7, [rsp+0x70]
00007f0254fd117d  vmovaps xmm8, [rsp+0x80]
00007f0254fd1186  vmovaps xmm9, [rsp+0x90]
00007f0254fd118f  vmovaps xmm10, [rsp+0xA0]
00007f0254fd1198  vmovaps xmm11, [rsp+0xB0]
00007f0254fd11a1  vmovaps xmm12, [rsp+0xC0]
00007f0254fd11aa  vmovaps xmm13, [rsp+0xD0]
00007f0254fd11b3  vmovaps xmm14, [rsp+0xE0]
00007f0254fd11bc  add rsp, 0xF0
00007f0254fd11c3  pop r11
00007f0254fd11c5  pop r10
00007f0254fd11c7  pop r9
00007f0254fd11c9  pop r8
00007f0254fd11cb  pop rsi
00007f0254fd11cc  pop rdi
00007f0254fd11cd  pop rdx
00007f0254fd11ce  pop rcx
00007f0254fd11cf  pop rax
00007f0254fd11d0  add rsp, 0x08
00007f0254fd11d4  jmp 0x00007F0254FCF75E
00007f0254fd11d9  call 0x00007F0254DFF430
00007f0254fd11de  jmp 0x00007F0254FCF7EE
00007f0254fd11e3  call 0x00007F0254DFF430
00007f0254fd11e8  jmp 0x00007F0254FCF801
00007f0254fd11ed  sub rsp, 0x08
00007f0254fd11f1  push rax
00007f0254fd11f2  push rcx
00007f0254fd11f3  push rdx
00007f0254fd11f4  push rdi
00007f0254fd11f5  push rsi
00007f0254fd11f6  push r8
00007f0254fd11f8  push r9
00007f0254fd11fa  push r10
00007f0254fd11fc  push r11
00007f0254fd11fe  sub rsp, 0xF0
00007f0254fd1205  vmovaps [rsp], xmm0
00007f0254fd120a  vmovaps [rsp+0x10], xmm2
00007f0254fd1210  vmovaps [rsp+0x20], xmm3
00007f0254fd1216  vmovaps [rsp+0x30], xmm4
00007f0254fd121c  vmovaps [rsp+0x40], xmm5
00007f0254fd1222  vmovaps [rsp+0x50], xmm6
00007f0254fd1228  vmovaps [rsp+0x60], xmm7
00007f0254fd122e  vmovaps [rsp+0x70], xmm8
00007f0254fd1234  vmovaps [rsp+0x80], xmm9
00007f0254fd123d  vmovaps [rsp+0x90], xmm10
00007f0254fd1246  vmovaps [rsp+0xA0], xmm11
00007f0254fd124f  vmovaps [rsp+0xB0], xmm12
00007f0254fd1258  vmovaps [rsp+0xC0], xmm13
00007f0254fd1261  vmovaps [rsp+0xD0], xmm14
00007f0254fd126a  vmovaps [rsp+0xE0], xmm15
00007f0254fd1273  sub rsp, 0x30
00007f0254fd1277  movaps [rsp], xmm1
00007f0254fd127b  movaps [rsp+0x10], xmm13
00007f0254fd1281  movaps [rsp+0x20], xmm2
00007f0254fd1286  lea rdi, [rsp]
00007f0254fd128a  mov esi, 0x00
00007f0254fd128f  mov rax, 0x55DD1360A530
00007f0254fd1299  call rax
00007f0254fd129b  movaps xmm1, [rsp]
00007f0254fd129f  add rsp, 0x30
00007f0254fd12a3  vmovaps xmm0, [rsp]
00007f0254fd12a8  vmovaps xmm2, [rsp+0x10]
00007f0254fd12ae  vmovaps xmm3, [rsp+0x20]
00007f0254fd12b4  vmovaps xmm4, [rsp+0x30]
00007f0254fd12ba  vmovaps xmm5, [rsp+0x40]
00007f0254fd12c0  vmovaps xmm6, [rsp+0x50]
00007f0254fd12c6  vmovaps xmm7, [rsp+0x60]
00007f0254fd12cc  vmovaps xmm8, [rsp+0x70]
00007f0254fd12d2  vmovaps xmm9, [rsp+0x80]
00007f0254fd12db  vmovaps xmm10, [rsp+0x90]
00007f0254fd12e4  vmovaps xmm11, [rsp+0xA0]
00007f0254fd12ed  vmovaps xmm12, [rsp+0xB0]
00007f0254fd12f6  vmovaps xmm13, [rsp+0xC0]
00007f0254fd12ff  vmovaps xmm14, [rsp+0xD0]
00007f0254fd1308  vmovaps xmm15, [rsp+0xE0]
00007f0254fd1311  add rsp, 0xF0
00007f0254fd1318  pop r11
00007f0254fd131a  pop r10
00007f0254fd131c  pop r9
00007f0254fd131e  pop r8
00007f0254fd1320  pop rsi
00007f0254fd1321  pop rdi
00007f0254fd1322  pop rdx
00007f0254fd1323  pop rcx
00007f0254fd1324  pop rax
00007f0254fd1325  add rsp, 0x08
00007f0254fd1329  jmp 0x00007F0254FCF82C
00007f0254fd132e  call 0x00007F0254E0E760
00007f0254fd1333  jmp 0x00007F0254FCF839
00007f0254fd1338  sub rsp, 0x08
00007f0254fd133c  push rax
00007f0254fd133d  push rcx
00007f0254fd133e  push rdx
00007f0254fd133f  push rdi
00007f0254fd1340  push rsi
00007f0254fd1341  push r8
00007f0254fd1343  push r9
00007f0254fd1345  push r10
00007f0254fd1347  push r11
00007f0254fd1349  sub rsp, 0xF0
00007f0254fd1350  vmovaps [rsp], xmm0
00007f0254fd1355  vmovaps [rsp+0x10], xmm1
00007f0254fd135b  vmovaps [rsp+0x20], xmm2
00007f0254fd1361  vmovaps [rsp+0x30], xmm3
00007f0254fd1367  vmovaps [rsp+0x40], xmm4
00007f0254fd136d  vmovaps [rsp+0x50], xmm5
00007f0254fd1373  vmovaps [rsp+0x60], xmm6
00007f0254fd1379  vmovaps [rsp+0x70], xmm7
00007f0254fd137f  vmovaps [rsp+0x80], xmm8
00007f0254fd1388  vmovaps [rsp+0x90], xmm9
00007f0254fd1391  vmovaps [rsp+0xA0], xmm10
00007f0254fd139a  vmovaps [rsp+0xB0], xmm11
00007f0254fd13a3  vmovaps [rsp+0xC0], xmm12
00007f0254fd13ac  vmovaps [rsp+0xD0], xmm14
00007f0254fd13b5  vmovaps [rsp+0xE0], xmm15
00007f0254fd13be  sub rsp, 0x30
00007f0254fd13c2  movaps [rsp], xmm13
00007f0254fd13c7  movaps [rsp+0x10], xmm2
00007f0254fd13cc  movaps [rsp+0x20], xmm1
00007f0254fd13d1  lea rdi, [rsp]
00007f0254fd13d5  mov esi, 0x00
00007f0254fd13da  mov rax, 0x55DD1360A530
00007f0254fd13e4  call rax
00007f0254fd13e6  movaps xmm13, [rsp]
00007f0254fd13eb  add rsp, 0x30
00007f0254fd13ef  vmovaps xmm0, [rsp]
00007f0254fd13f4  vmovaps xmm1, [rsp+0x10]
00007f0254fd13fa  vmovaps xmm2, [rsp+0x20]
00007f0254fd1400  vmovaps xmm3, [rsp+0x30]
00007f0254fd1406  vmovaps xmm4, [rsp+0x40]
00007f0254fd140c  vmovaps xmm5, [rsp+0x50]
00007f0254fd1412  vmovaps xmm6, [rsp+0x60]
00007f0254fd1418  vmovaps xmm7, [rsp+0x70]
00007f0254fd141e  vmovaps xmm8, [rsp+0x80]
00007f0254fd1427  vmovaps xmm9, [rsp+0x90]
00007f0254fd1430  vmovaps xmm10, [rsp+0xA0]
00007f0254fd1439  vmovaps xmm11, [rsp+0xB0]
00007f0254fd1442  vmovaps xmm12, [rsp+0xC0]
00007f0254fd144b  vmovaps xmm14, [rsp+0xD0]
00007f0254fd1454  vmovaps xmm15, [rsp+0xE0]
00007f0254fd145d  add rsp, 0xF0
00007f0254fd1464  pop r11
00007f0254fd1466  pop r10
00007f0254fd1468  pop r9
00007f0254fd146a  pop r8
00007f0254fd146c  pop rsi
00007f0254fd146d  pop rdi
00007f0254fd146e  pop rdx
00007f0254fd146f  pop rcx
00007f0254fd1470  pop rax
00007f0254fd1471  add rsp, 0x08
00007f0254fd1475  jmp 0x00007F0254FCF878
00007f0254fd147a  sub rsp, 0x08
00007f0254fd147e  push rax
00007f0254fd147f  push rcx
00007f0254fd1480  push rdx
00007f0254fd1481  push rdi
00007f0254fd1482  push rsi
00007f0254fd1483  push r8
00007f0254fd1485  push r9
00007f0254fd1487  push r10
00007f0254fd1489  push r11
00007f0254fd148b  sub rsp, 0xF0
00007f0254fd1492  vmovaps [rsp], xmm0
00007f0254fd1497  vmovaps [rsp+0x10], xmm2
00007f0254fd149d  vmovaps [rsp+0x20], xmm3
00007f0254fd14a3  vmovaps [rsp+0x30], xmm4
00007f0254fd14a9  vmovaps [rsp+0x40], xmm5
00007f0254fd14af  vmovaps [rsp+0x50], xmm6
00007f0254fd14b5  vmovaps [rsp+0x60], xmm7
00007f0254fd14bb  vmovaps [rsp+0x70], xmm8
00007f0254fd14c1  vmovaps [rsp+0x80], xmm9
00007f0254fd14ca  vmovaps [rsp+0x90], xmm10
00007f0254fd14d3  vmovaps [rsp+0xA0], xmm11
00007f0254fd14dc  vmovaps [rsp+0xB0], xmm12
00007f0254fd14e5  vmovaps [rsp+0xC0], xmm13
00007f0254fd14ee  vmovaps [rsp+0xD0], xmm14
00007f0254fd14f7  vmovaps [rsp+0xE0], xmm15
00007f0254fd1500  sub rsp, 0x30
00007f0254fd1504  movaps [rsp], xmm1
00007f0254fd1508  movaps [rsp+0x10], xmm15
00007f0254fd150e  movaps [rsp+0x20], xmm2
00007f0254fd1513  lea rdi, [rsp]
00007f0254fd1517  mov esi, 0x00
00007f0254fd151c  mov rax, 0x55DD1360A530
00007f0254fd1526  call rax
00007f0254fd1528  movaps xmm1, [rsp]
00007f0254fd152c  add rsp, 0x30
00007f0254fd1530  vmovaps xmm0, [rsp]
00007f0254fd1535  vmovaps xmm2, [rsp+0x10]
00007f0254fd153b  vmovaps xmm3, [rsp+0x20]
00007f0254fd1541  vmovaps xmm4, [rsp+0x30]
00007f0254fd1547  vmovaps xmm5, [rsp+0x40]
00007f0254fd154d  vmovaps xmm6, [rsp+0x50]
00007f0254fd1553  vmovaps xmm7, [rsp+0x60]
00007f0254fd1559  vmovaps xmm8, [rsp+0x70]
00007f0254fd155f  vmovaps xmm9, [rsp+0x80]
00007f0254fd1568  vmovaps xmm10, [rsp+0x90]
00007f0254fd1571  vmovaps xmm11, [rsp+0xA0]
00007f0254fd157a  vmovaps xmm12, [rsp+0xB0]
00007f0254fd1583  vmovaps xmm13, [rsp+0xC0]
00007f0254fd158c  vmovaps xmm14, [rsp+0xD0]
00007f0254fd1595  vmovaps xmm15, [rsp+0xE0]
00007f0254fd159e  add rsp, 0xF0
00007f0254fd15a5  pop r11
00007f0254fd15a7  pop r10
00007f0254fd15a9  pop r9
00007f0254fd15ab  pop r8
00007f0254fd15ad  pop rsi
00007f0254fd15ae  pop rdi
00007f0254fd15af  pop rdx
00007f0254fd15b0  pop rcx
00007f0254fd15b1  pop rax
00007f0254fd15b2  add rsp, 0x08
00007f0254fd15b6  jmp 0x00007F0254FCF8AC
00007f0254fd15bb  sub rsp, 0x08
00007f0254fd15bf  push rax
00007f0254fd15c0  push rcx
00007f0254fd15c1  push rdx
00007f0254fd15c2  push rdi
00007f0254fd15c3  push rsi
00007f0254fd15c4  push r8
00007f0254fd15c6  push r9
00007f0254fd15c8  push r10
00007f0254fd15ca  push r11
00007f0254fd15cc  sub rsp, 0xF0
00007f0254fd15d3  vmovaps [rsp], xmm0
00007f0254fd15d8  vmovaps [rsp+0x10], xmm1
00007f0254fd15de  vmovaps [rsp+0x20], xmm2
00007f0254fd15e4  vmovaps [rsp+0x30], xmm3
00007f0254fd15ea  vmovaps [rsp+0x40], xmm4
00007f0254fd15f0  vmovaps [rsp+0x50], xmm5
00007f0254fd15f6  vmovaps [rsp+0x60], xmm6
00007f0254fd15fc  vmovaps [rsp+0x70], xmm7
00007f0254fd1602  vmovaps [rsp+0x80], xmm8
00007f0254fd160b  vmovaps [rsp+0x90], xmm9
00007f0254fd1614  vmovaps [rsp+0xA0], xmm10
00007f0254fd161d  vmovaps [rsp+0xB0], xmm11
00007f0254fd1626  vmovaps [rsp+0xC0], xmm12
00007f0254fd162f  vmovaps [rsp+0xD0], xmm13
00007f0254fd1638  vmovaps [rsp+0xE0], xmm15
00007f0254fd1641  sub rsp, 0x30
00007f0254fd1645  movaps [rsp], xmm14
00007f0254fd164a  movaps [rsp+0x10], xmm2
00007f0254fd164f  movaps [rsp+0x20], xmm15
00007f0254fd1655  lea rdi, [rsp]
00007f0254fd1659  mov esi, 0x00
00007f0254fd165e  mov rax, 0x55DD1360A530
00007f0254fd1668  call rax
00007f0254fd166a  movaps xmm14, [rsp]
00007f0254fd166f  add rsp, 0x30
00007f0254fd1673  vmovaps xmm0, [rsp]
00007f0254fd1678  vmovaps xmm1, [rsp+0x10]
00007f0254fd167e  vmovaps xmm2, [rsp+0x20]
00007f0254fd1684  vmovaps xmm3, [rsp+0x30]
00007f0254fd168a  vmovaps xmm4, [rsp+0x40]
00007f0254fd1690  vmovaps xmm5, [rsp+0x50]
00007f0254fd1696  vmovaps xmm6, [rsp+0x60]
00007f0254fd169c  vmovaps xmm7, [rsp+0x70]
00007f0254fd16a2  vmovaps xmm8, [rsp+0x80]
00007f0254fd16ab  vmovaps xmm9, [rsp+0x90]
00007f0254fd16b4  vmovaps xmm10, [rsp+0xA0]
00007f0254fd16bd  vmovaps xmm11, [rsp+0xB0]
00007f0254fd16c6  vmovaps xmm12, [rsp+0xC0]
00007f0254fd16cf  vmovaps xmm13, [rsp+0xD0]
00007f0254fd16d8  vmovaps xmm15, [rsp+0xE0]
00007f0254fd16e1  add rsp, 0xF0
00007f0254fd16e8  pop r11
00007f0254fd16ea  pop r10
00007f0254fd16ec  pop r9
00007f0254fd16ee  pop r8
00007f0254fd16f0  pop rsi
00007f0254fd16f1  pop rdi
00007f0254fd16f2  pop rdx
00007f0254fd16f3  pop rcx
00007f0254fd16f4  pop rax
00007f0254fd16f5  add rsp, 0x08
00007f0254fd16f9  jmp 0x00007F0254FCF8E7
00007f0254fd16fe  sub rsp, 0x08
00007f0254fd1702  push rax
00007f0254fd1703  push rcx
00007f0254fd1704  push rdx
00007f0254fd1705  push rdi
00007f0254fd1706  push rsi
00007f0254fd1707  push r8
00007f0254fd1709  push r9
00007f0254fd170b  push r10
00007f0254fd170d  push r11
00007f0254fd170f  sub rsp, 0xF0
00007f0254fd1716  vmovaps [rsp], xmm0
00007f0254fd171b  vmovaps [rsp+0x10], xmm1
00007f0254fd1721  vmovaps [rsp+0x20], xmm2
00007f0254fd1727  vmovaps [rsp+0x30], xmm3
00007f0254fd172d  vmovaps [rsp+0x40], xmm4
00007f0254fd1733  vmovaps [rsp+0x50], xmm5
00007f0254fd1739  vmovaps [rsp+0x60], xmm6
00007f0254fd173f  vmovaps [rsp+0x70], xmm7
00007f0254fd1745  vmovaps [rsp+0x80], xmm8
00007f0254fd174e  vmovaps [rsp+0x90], xmm9
00007f0254fd1757  vmovaps [rsp+0xA0], xmm10
00007f0254fd1760  vmovaps [rsp+0xB0], xmm11
00007f0254fd1769  vmovaps [rsp+0xC0], xmm12
00007f0254fd1772  vmovaps [rsp+0xD0], xmm13
00007f0254fd177b  vmovaps [rsp+0xE0], xmm14
00007f0254fd1784  sub rsp, 0x30
00007f0254fd1788  movaps [rsp], xmm15
00007f0254fd178d  movaps [rsp+0x10], xmm2
00007f0254fd1792  movaps [rsp+0x20], xmm1
00007f0254fd1797  lea rdi, [rsp]
00007f0254fd179b  mov esi, 0x00
00007f0254fd17a0  mov rax, 0x55DD1360A530
00007f0254fd17aa  call rax
00007f0254fd17ac  movaps xmm15, [rsp]
00007f0254fd17b1  add rsp, 0x30
00007f0254fd17b5  vmovaps xmm0, [rsp]
00007f0254fd17ba  vmovaps xmm1, [rsp+0x10]
00007f0254fd17c0  vmovaps xmm2, [rsp+0x20]
00007f0254fd17c6  vmovaps xmm3, [rsp+0x30]
00007f0254fd17cc  vmovaps xmm4, [rsp+0x40]
00007f0254fd17d2  vmovaps xmm5, [rsp+0x50]
00007f0254fd17d8  vmovaps xmm6, [rsp+0x60]
00007f0254fd17de  vmovaps xmm7, [rsp+0x70]
00007f0254fd17e4  vmovaps xmm8, [rsp+0x80]
00007f0254fd17ed  vmovaps xmm9, [rsp+0x90]
00007f0254fd17f6  vmovaps xmm10, [rsp+0xA0]
00007f0254fd17ff  vmovaps xmm11, [rsp+0xB0]
00007f0254fd1808  vmovaps xmm12, [rsp+0xC0]
00007f0254fd1811  vmovaps xmm13, [rsp+0xD0]
00007f0254fd181a  vmovaps xmm14, [rsp+0xE0]
00007f0254fd1823  add rsp, 0xF0
00007f0254fd182a  pop r11
00007f0254fd182c  pop r10
00007f0254fd182e  pop r9
00007f0254fd1830  pop r8
00007f0254fd1832  pop rsi
00007f0254fd1833  pop rdi
00007f0254fd1834  pop rdx
00007f0254fd1835  pop rcx
00007f0254fd1836  pop rax
00007f0254fd1837  add rsp, 0x08
00007f0254fd183b  jmp 0x00007F0254FCF923
00007f0254fd1840  call 0x00007F0254DFF430
00007f0254fd1845  jmp 0x00007F0254FCF930
00007f0254fd184a  sub rsp, 0x08
00007f0254fd184e  push rax
00007f0254fd184f  push rcx
00007f0254fd1850  push rdx
00007f0254fd1851  push rdi
00007f0254fd1852  push rsi
00007f0254fd1853  push r8
00007f0254fd1855  push r9
00007f0254fd1857  push r10
00007f0254fd1859  push r11
00007f0254fd185b  sub rsp, 0xF0
00007f0254fd1862  vmovaps [rsp], xmm0
00007f0254fd1867  vmovaps [rsp+0x10], xmm1
00007f0254fd186d  vmovaps [rsp+0x20], xmm3
00007f0254fd1873  vmovaps [rsp+0x30], xmm4
00007f0254fd1879  vmovaps [rsp+0x40], xmm5
00007f0254fd187f  vmovaps [rsp+0x50], xmm6
00007f0254fd1885  vmovaps [rsp+0x60], xmm7
00007f0254fd188b  vmovaps [rsp+0x70], xmm8
00007f0254fd1891  vmovaps [rsp+0x80], xmm9
00007f0254fd189a  vmovaps [rsp+0x90], xmm10
00007f0254fd18a3  vmovaps [rsp+0xA0], xmm11
00007f0254fd18ac  vmovaps [rsp+0xB0], xmm12
00007f0254fd18b5  vmovaps [rsp+0xC0], xmm13
00007f0254fd18be  vmovaps [rsp+0xD0], xmm14
00007f0254fd18c7  vmovaps [rsp+0xE0], xmm15
00007f0254fd18d0  sub rsp, 0x30
00007f0254fd18d4  movaps [rsp], xmm2
00007f0254fd18d8  movaps [rsp+0x10], xmm1
00007f0254fd18dd  movaps [rsp+0x20], xmm14
00007f0254fd18e3  lea rdi, [rsp]
00007f0254fd18e7  mov esi, 0x00
00007f0254fd18ec  mov rax, 0x55DD1360A530
00007f0254fd18f6  call rax
00007f0254fd18f8  movaps xmm2, [rsp]
00007f0254fd18fc  add rsp, 0x30
00007f0254fd1900  vmovaps xmm0, [rsp]
00007f0254fd1905  vmovaps xmm1, [rsp+0x10]
00007f0254fd190b  vmovaps xmm3, [rsp+0x20]
00007f0254fd1911  vmovaps xmm4, [rsp+0x30]
00007f0254fd1917  vmovaps xmm5, [rsp+0x40]
00007f0254fd191d  vmovaps xmm6, [rsp+0x50]
00007f0254fd1923  vmovaps xmm7, [rsp+0x60]
00007f0254fd1929  vmovaps xmm8, [rsp+0x70]
00007f0254fd192f  vmovaps xmm9, [rsp+0x80]
00007f0254fd1938  vmovaps xmm10, [rsp+0x90]
00007f0254fd1941  vmovaps xmm11, [rsp+0xA0]
00007f0254fd194a  vmovaps xmm12, [rsp+0xB0]
00007f0254fd1953  vmovaps xmm13, [rsp+0xC0]
00007f0254fd195c  vmovaps xmm14, [rsp+0xD0]
00007f0254fd1965  vmovaps xmm15, [rsp+0xE0]
00007f0254fd196e  add rsp, 0xF0
00007f0254fd1975  pop r11
00007f0254fd1977  pop r10
00007f0254fd1979  pop r9
00007f0254fd197b  pop r8
00007f0254fd197d  pop rsi
00007f0254fd197e  pop rdi
00007f0254fd197f  pop rdx
00007f0254fd1980  pop rcx
00007f0254fd1981  pop rax
00007f0254fd1982  add rsp, 0x08
00007f0254fd1986  jmp 0x00007F0254FCF96D
00007f0254fd198b  sub rsp, 0x08
00007f0254fd198f  push rax
00007f0254fd1990  push rcx
00007f0254fd1991  push rdx
00007f0254fd1992  push rdi
00007f0254fd1993  push rsi
00007f0254fd1994  push r8
00007f0254fd1996  push r9
00007f0254fd1998  push r10
00007f0254fd199a  push r11
00007f0254fd199c  sub rsp, 0xF0
00007f0254fd19a3  vmovaps [rsp], xmm0
00007f0254fd19a8  vmovaps [rsp+0x10], xmm1
00007f0254fd19ae  vmovaps [rsp+0x20], xmm2
00007f0254fd19b4  vmovaps [rsp+0x30], xmm3
00007f0254fd19ba  vmovaps [rsp+0x40], xmm4
00007f0254fd19c0  vmovaps [rsp+0x50], xmm5
00007f0254fd19c6  vmovaps [rsp+0x60], xmm6
00007f0254fd19cc  vmovaps [rsp+0x70], xmm7
00007f0254fd19d2  vmovaps [rsp+0x80], xmm8
00007f0254fd19db  vmovaps [rsp+0x90], xmm9
00007f0254fd19e4  vmovaps [rsp+0xA0], xmm10
00007f0254fd19ed  vmovaps [rsp+0xB0], xmm11
00007f0254fd19f6  vmovaps [rsp+0xC0], xmm12
00007f0254fd19ff  vmovaps [rsp+0xD0], xmm13
00007f0254fd1a08  vmovaps [rsp+0xE0], xmm14
00007f0254fd1a11  sub rsp, 0x30
00007f0254fd1a15  movaps [rsp], xmm15
00007f0254fd1a1a  movaps [rsp+0x10], xmm14
00007f0254fd1a20  movaps [rsp+0x20], xmm1
00007f0254fd1a25  lea rdi, [rsp]
00007f0254fd1a29  mov esi, 0x00
00007f0254fd1a2e  mov rax, 0x55DD1360A530
00007f0254fd1a38  call rax
00007f0254fd1a3a  movaps xmm15, [rsp]
00007f0254fd1a3f  add rsp, 0x30
00007f0254fd1a43  vmovaps xmm0, [rsp]
00007f0254fd1a48  vmovaps xmm1, [rsp+0x10]
00007f0254fd1a4e  vmovaps xmm2, [rsp+0x20]
00007f0254fd1a54  vmovaps xmm3, [rsp+0x30]
00007f0254fd1a5a  vmovaps xmm4, [rsp+0x40]
00007f0254fd1a60  vmovaps xmm5, [rsp+0x50]
00007f0254fd1a66  vmovaps xmm6, [rsp+0x60]
00007f0254fd1a6c  vmovaps xmm7, [rsp+0x70]
00007f0254fd1a72  vmovaps xmm8, [rsp+0x80]
00007f0254fd1a7b  vmovaps xmm9, [rsp+0x90]
00007f0254fd1a84  vmovaps xmm10, [rsp+0xA0]
00007f0254fd1a8d  vmovaps xmm11, [rsp+0xB0]
00007f0254fd1a96  vmovaps xmm12, [rsp+0xC0]
00007f0254fd1a9f  vmovaps xmm13, [rsp+0xD0]
00007f0254fd1aa8  vmovaps xmm14, [rsp+0xE0]
00007f0254fd1ab1  add rsp, 0xF0
00007f0254fd1ab8  pop r11
00007f0254fd1aba  pop r10
00007f0254fd1abc  pop r9
00007f0254fd1abe  pop r8
00007f0254fd1ac0  pop rsi
00007f0254fd1ac1  pop rdi
00007f0254fd1ac2  pop rdx
00007f0254fd1ac3  pop rcx
00007f0254fd1ac4  pop rax
00007f0254fd1ac5  add rsp, 0x08
00007f0254fd1ac9  jmp 0x00007F0254FCF9E7
00007f0254fd1ace  call 0x00007F0254DFF430
00007f0254fd1ad3  jmp 0x00007F0254FCF9F4
00007f0254fd1ad8  sub rsp, 0x08
00007f0254fd1adc  push rax
00007f0254fd1add  push rcx
00007f0254fd1ade  push rdx
00007f0254fd1adf  push rdi
00007f0254fd1ae0  push rsi
00007f0254fd1ae1  push r8
00007f0254fd1ae3  push r9
00007f0254fd1ae5  push r10
00007f0254fd1ae7  push r11
00007f0254fd1ae9  sub rsp, 0xF0
00007f0254fd1af0  vmovaps [rsp], xmm0
00007f0254fd1af5  vmovaps [rsp+0x10], xmm1
00007f0254fd1afb  vmovaps [rsp+0x20], xmm2
00007f0254fd1b01  vmovaps [rsp+0x30], xmm3
00007f0254fd1b07  vmovaps [rsp+0x40], xmm4
00007f0254fd1b0d  vmovaps [rsp+0x50], xmm5
00007f0254fd1b13  vmovaps [rsp+0x60], xmm6
00007f0254fd1b19  vmovaps [rsp+0x70], xmm7
00007f0254fd1b1f  vmovaps [rsp+0x80], xmm8
00007f0254fd1b28  vmovaps [rsp+0x90], xmm9
00007f0254fd1b31  vmovaps [rsp+0xA0], xmm10
00007f0254fd1b3a  vmovaps [rsp+0xB0], xmm11
00007f0254fd1b43  vmovaps [rsp+0xC0], xmm12
00007f0254fd1b4c  vmovaps [rsp+0xD0], xmm13
00007f0254fd1b55  vmovaps [rsp+0xE0], xmm15
00007f0254fd1b5e  sub rsp, 0x30
00007f0254fd1b62  movaps [rsp], xmm14
00007f0254fd1b67  movaps [rsp+0x10], xmm13
00007f0254fd1b6d  movaps [rsp+0x20], xmm1
00007f0254fd1b72  lea rdi, [rsp]
00007f0254fd1b76  mov esi, 0x00
00007f0254fd1b7b  mov rax, 0x55DD1360A530
00007f0254fd1b85  call rax
00007f0254fd1b87  movaps xmm14, [rsp]
00007f0254fd1b8c  add rsp, 0x30
00007f0254fd1b90  vmovaps xmm0, [rsp]
00007f0254fd1b95  vmovaps xmm1, [rsp+0x10]
00007f0254fd1b9b  vmovaps xmm2, [rsp+0x20]
00007f0254fd1ba1  vmovaps xmm3, [rsp+0x30]
00007f0254fd1ba7  vmovaps xmm4, [rsp+0x40]
00007f0254fd1bad  vmovaps xmm5, [rsp+0x50]
00007f0254fd1bb3  vmovaps xmm6, [rsp+0x60]
00007f0254fd1bb9  vmovaps xmm7, [rsp+0x70]
00007f0254fd1bbf  vmovaps xmm8, [rsp+0x80]
00007f0254fd1bc8  vmovaps xmm9, [rsp+0x90]
00007f0254fd1bd1  vmovaps xmm10, [rsp+0xA0]
00007f0254fd1bda  vmovaps xmm11, [rsp+0xB0]
00007f0254fd1be3  vmovaps xmm12, [rsp+0xC0]
00007f0254fd1bec  vmovaps xmm13, [rsp+0xD0]
00007f0254fd1bf5  vmovaps xmm15, [rsp+0xE0]
00007f0254fd1bfe  add rsp, 0xF0
00007f0254fd1c05  pop r11
00007f0254fd1c07  pop r10
00007f0254fd1c09  pop r9
00007f0254fd1c0b  pop r8
00007f0254fd1c0d  pop rsi
00007f0254fd1c0e  pop rdi
00007f0254fd1c0f  pop rdx
00007f0254fd1c10  pop rcx
00007f0254fd1c11  pop rax
00007f0254fd1c12  add rsp, 0x08
00007f0254fd1c16  jmp 0x00007F0254FCFAAF
00007f0254fd1c1b  sub rsp, 0x08
00007f0254fd1c1f  push rax
00007f0254fd1c20  push rcx
00007f0254fd1c21  push rdx
00007f0254fd1c22  push rdi
00007f0254fd1c23  push rsi
00007f0254fd1c24  push r8
00007f0254fd1c26  push r9
00007f0254fd1c28  push r10
00007f0254fd1c2a  push r11
00007f0254fd1c2c  sub rsp, 0xF0
00007f0254fd1c33  vmovaps [rsp], xmm0
00007f0254fd1c38  vmovaps [rsp+0x10], xmm1
00007f0254fd1c3e  vmovaps [rsp+0x20], xmm2
00007f0254fd1c44  vmovaps [rsp+0x30], xmm3
00007f0254fd1c4a  vmovaps [rsp+0x40], xmm4
00007f0254fd1c50  vmovaps [rsp+0x50], xmm5
00007f0254fd1c56  vmovaps [rsp+0x60], xmm6
00007f0254fd1c5c  vmovaps [rsp+0x70], xmm7
00007f0254fd1c62  vmovaps [rsp+0x80], xmm8
00007f0254fd1c6b  vmovaps [rsp+0x90], xmm9
00007f0254fd1c74  vmovaps [rsp+0xA0], xmm10
00007f0254fd1c7d  vmovaps [rsp+0xB0], xmm11
00007f0254fd1c86  vmovaps [rsp+0xC0], xmm12
00007f0254fd1c8f  vmovaps [rsp+0xD0], xmm13
00007f0254fd1c98  vmovaps [rsp+0xE0], xmm14
00007f0254fd1ca1  sub rsp, 0x30
00007f0254fd1ca5  movaps [rsp], xmm15
00007f0254fd1caa  movaps [rsp+0x10], xmm13
00007f0254fd1cb0  movaps [rsp+0x20], xmm1
00007f0254fd1cb5  lea rdi, [rsp]
00007f0254fd1cb9  mov esi, 0x00
00007f0254fd1cbe  mov rax, 0x55DD1360A530
00007f0254fd1cc8  call rax
00007f0254fd1cca  movaps xmm15, [rsp]
00007f0254fd1ccf  add rsp, 0x30
00007f0254fd1cd3  vmovaps xmm0, [rsp]
00007f0254fd1cd8  vmovaps xmm1, [rsp+0x10]
00007f0254fd1cde  vmovaps xmm2, [rsp+0x20]
00007f0254fd1ce4  vmovaps xmm3, [rsp+0x30]
00007f0254fd1cea  vmovaps xmm4, [rsp+0x40]
00007f0254fd1cf0  vmovaps xmm5, [rsp+0x50]
00007f0254fd1cf6  vmovaps xmm6, [rsp+0x60]
00007f0254fd1cfc  vmovaps xmm7, [rsp+0x70]
00007f0254fd1d02  vmovaps xmm8, [rsp+0x80]
00007f0254fd1d0b  vmovaps xmm9, [rsp+0x90]
00007f0254fd1d14  vmovaps xmm10, [rsp+0xA0]
00007f0254fd1d1d  vmovaps xmm11, [rsp+0xB0]
00007f0254fd1d26  vmovaps xmm12, [rsp+0xC0]
00007f0254fd1d2f  vmovaps xmm13, [rsp+0xD0]
00007f0254fd1d38  vmovaps xmm14, [rsp+0xE0]
00007f0254fd1d41  add rsp, 0xF0
00007f0254fd1d48  pop r11
00007f0254fd1d4a  pop r10
00007f0254fd1d4c  pop r9
00007f0254fd1d4e  pop r8
00007f0254fd1d50  pop rsi
00007f0254fd1d51  pop rdi
00007f0254fd1d52  pop rdx
00007f0254fd1d53  pop rcx
00007f0254fd1d54  pop rax
00007f0254fd1d55  add rsp, 0x08
00007f0254fd1d59  jmp 0x00007F0254FCFAEB
00007f0254fd1d5e  call 0x00007F0254DFF430
00007f0254fd1d63  jmp 0x00007F0254FCFAF8
00007f0254fd1d68  sub rsp, 0x08
00007f0254fd1d6c  push rax
00007f0254fd1d6d  push rcx
00007f0254fd1d6e  push rdx
00007f0254fd1d6f  push rdi
00007f0254fd1d70  push rsi
00007f0254fd1d71  push r8
00007f0254fd1d73  push r9
00007f0254fd1d75  push r10
00007f0254fd1d77  push r11
00007f0254fd1d79  sub rsp, 0xF0
00007f0254fd1d80  vmovaps [rsp], xmm0
00007f0254fd1d85  vmovaps [rsp+0x10], xmm1
00007f0254fd1d8b  vmovaps [rsp+0x20], xmm2
00007f0254fd1d91  vmovaps [rsp+0x30], xmm3
00007f0254fd1d97  vmovaps [rsp+0x40], xmm4
00007f0254fd1d9d  vmovaps [rsp+0x50], xmm5
00007f0254fd1da3  vmovaps [rsp+0x60], xmm6
00007f0254fd1da9  vmovaps [rsp+0x70], xmm7
00007f0254fd1daf  vmovaps [rsp+0x80], xmm8
00007f0254fd1db8  vmovaps [rsp+0x90], xmm9
00007f0254fd1dc1  vmovaps [rsp+0xA0], xmm10
00007f0254fd1dca  vmovaps [rsp+0xB0], xmm11
00007f0254fd1dd3  vmovaps [rsp+0xC0], xmm12
00007f0254fd1ddc  vmovaps [rsp+0xD0], xmm13
00007f0254fd1de5  vmovaps [rsp+0xE0], xmm15
00007f0254fd1dee  sub rsp, 0x30
00007f0254fd1df2  movaps [rsp], xmm14
00007f0254fd1df7  movaps [rsp+0x10], xmm13
00007f0254fd1dfd  movaps [rsp+0x20], xmm2
00007f0254fd1e02  lea rdi, [rsp]
00007f0254fd1e06  mov esi, 0x00
00007f0254fd1e0b  mov rax, 0x55DD1360A530
00007f0254fd1e15  call rax
00007f0254fd1e17  movaps xmm14, [rsp]
00007f0254fd1e1c  add rsp, 0x30
00007f0254fd1e20  vmovaps xmm0, [rsp]
00007f0254fd1e25  vmovaps xmm1, [rsp+0x10]
00007f0254fd1e2b  vmovaps xmm2, [rsp+0x20]
00007f0254fd1e31  vmovaps xmm3, [rsp+0x30]
00007f0254fd1e37  vmovaps xmm4, [rsp+0x40]
00007f0254fd1e3d  vmovaps xmm5, [rsp+0x50]
00007f0254fd1e43  vmovaps xmm6, [rsp+0x60]
00007f0254fd1e49  vmovaps xmm7, [rsp+0x70]
00007f0254fd1e4f  vmovaps xmm8, [rsp+0x80]
00007f0254fd1e58  vmovaps xmm9, [rsp+0x90]
00007f0254fd1e61  vmovaps xmm10, [rsp+0xA0]
00007f0254fd1e6a  vmovaps xmm11, [rsp+0xB0]
00007f0254fd1e73  vmovaps xmm12, [rsp+0xC0]
00007f0254fd1e7c  vmovaps xmm13, [rsp+0xD0]
00007f0254fd1e85  vmovaps xmm15, [rsp+0xE0]
00007f0254fd1e8e  add rsp, 0xF0
00007f0254fd1e95  pop r11
00007f0254fd1e97  pop r10
00007f0254fd1e99  pop r9
00007f0254fd1e9b  pop r8
00007f0254fd1e9d  pop rsi
00007f0254fd1e9e  pop rdi
00007f0254fd1e9f  pop rdx
00007f0254fd1ea0  pop rcx
00007f0254fd1ea1  pop rax
00007f0254fd1ea2  add rsp, 0x08
00007f0254fd1ea6  jmp 0x00007F0254FCFB24
00007f0254fd1eab  sub rsp, 0x08
00007f0254fd1eaf  push rax
00007f0254fd1eb0  push rcx
00007f0254fd1eb1  push rdx
00007f0254fd1eb2  push rdi
00007f0254fd1eb3  push rsi
00007f0254fd1eb4  push r8
00007f0254fd1eb6  push r9
00007f0254fd1eb8  push r10
00007f0254fd1eba  push r11
00007f0254fd1ebc  sub rsp, 0xF0
00007f0254fd1ec3  vmovaps [rsp], xmm0
00007f0254fd1ec8  vmovaps [rsp+0x10], xmm2
00007f0254fd1ece  vmovaps [rsp+0x20], xmm3
00007f0254fd1ed4  vmovaps [rsp+0x30], xmm4
00007f0254fd1eda  vmovaps [rsp+0x40], xmm5
00007f0254fd1ee0  vmovaps [rsp+0x50], xmm6
00007f0254fd1ee6  vmovaps [rsp+0x60], xmm7
00007f0254fd1eec  vmovaps [rsp+0x70], xmm8
00007f0254fd1ef2  vmovaps [rsp+0x80], xmm9
00007f0254fd1efb  vmovaps [rsp+0x90], xmm10
00007f0254fd1f04  vmovaps [rsp+0xA0], xmm11
00007f0254fd1f0d  vmovaps [rsp+0xB0], xmm12
00007f0254fd1f16  vmovaps [rsp+0xC0], xmm13
00007f0254fd1f1f  vmovaps [rsp+0xD0], xmm14
00007f0254fd1f28  vmovaps [rsp+0xE0], xmm15
00007f0254fd1f31  sub rsp, 0x30
00007f0254fd1f35  movaps [rsp], xmm1
00007f0254fd1f39  movaps [rsp+0x10], xmm13
00007f0254fd1f3f  movaps [rsp+0x20], xmm2
00007f0254fd1f44  lea rdi, [rsp]
00007f0254fd1f48  mov esi, 0x00
00007f0254fd1f4d  mov rax, 0x55DD1360A530
00007f0254fd1f57  call rax
00007f0254fd1f59  movaps xmm1, [rsp]
00007f0254fd1f5d  add rsp, 0x30
00007f0254fd1f61  vmovaps xmm0, [rsp]
00007f0254fd1f66  vmovaps xmm2, [rsp+0x10]
00007f0254fd1f6c  vmovaps xmm3, [rsp+0x20]
00007f0254fd1f72  vmovaps xmm4, [rsp+0x30]
00007f0254fd1f78  vmovaps xmm5, [rsp+0x40]
00007f0254fd1f7e  vmovaps xmm6, [rsp+0x50]
00007f0254fd1f84  vmovaps xmm7, [rsp+0x60]
00007f0254fd1f8a  vmovaps xmm8, [rsp+0x70]
00007f0254fd1f90  vmovaps xmm9, [rsp+0x80]
00007f0254fd1f99  vmovaps xmm10, [rsp+0x90]
00007f0254fd1fa2  vmovaps xmm11, [rsp+0xA0]
00007f0254fd1fab  vmovaps xmm12, [rsp+0xB0]
00007f0254fd1fb4  vmovaps xmm13, [rsp+0xC0]
00007f0254fd1fbd  vmovaps xmm14, [rsp+0xD0]
00007f0254fd1fc6  vmovaps xmm15, [rsp+0xE0]
00007f0254fd1fcf  add rsp, 0xF0
00007f0254fd1fd6  pop r11
00007f0254fd1fd8  pop r10
00007f0254fd1fda  pop r9
00007f0254fd1fdc  pop r8
00007f0254fd1fde  pop rsi
00007f0254fd1fdf  pop rdi
00007f0254fd1fe0  pop rdx
00007f0254fd1fe1  pop rcx
00007f0254fd1fe2  pop rax
00007f0254fd1fe3  add rsp, 0x08
00007f0254fd1fe7  jmp 0x00007F0254FCFB52
00007f0254fd1fec  sub rsp, 0x08
00007f0254fd1ff0  push rax
00007f0254fd1ff1  push rcx
00007f0254fd1ff2  push rdx
00007f0254fd1ff3  push rdi
00007f0254fd1ff4  push rsi
00007f0254fd1ff5  push r8
00007f0254fd1ff7  push r9
00007f0254fd1ff9  push r10
00007f0254fd1ffb  push r11
00007f0254fd1ffd  sub rsp, 0xF0
00007f0254fd2004  vmovaps [rsp], xmm0
00007f0254fd2009  vmovaps [rsp+0x10], xmm1
00007f0254fd200f  vmovaps [rsp+0x20], xmm3
00007f0254fd2015  vmovaps [rsp+0x30], xmm4
00007f0254fd201b  vmovaps [rsp+0x40], xmm5
00007f0254fd2021  vmovaps [rsp+0x50], xmm6
00007f0254fd2027  vmovaps [rsp+0x60], xmm7
00007f0254fd202d  vmovaps [rsp+0x70], xmm8
00007f0254fd2033  vmovaps [rsp+0x80], xmm9
00007f0254fd203c  vmovaps [rsp+0x90], xmm10
00007f0254fd2045  vmovaps [rsp+0xA0], xmm11
00007f0254fd204e  vmovaps [rsp+0xB0], xmm12
00007f0254fd2057  vmovaps [rsp+0xC0], xmm13
00007f0254fd2060  vmovaps [rsp+0xD0], xmm14
00007f0254fd2069  vmovaps [rsp+0xE0], xmm15
00007f0254fd2072  sub rsp, 0x30
00007f0254fd2076  movaps [rsp], xmm2
00007f0254fd207a  movaps [rsp+0x10], xmm1
00007f0254fd207f  movaps [rsp+0x20], xmm13
00007f0254fd2085  lea rdi, [rsp]
00007f0254fd2089  mov esi, 0x00
00007f0254fd208e  mov rax, 0x55DD1360A530
00007f0254fd2098  call rax
00007f0254fd209a  movaps xmm2, [rsp]
00007f0254fd209e  add rsp, 0x30
00007f0254fd20a2  vmovaps xmm0, [rsp]
00007f0254fd20a7  vmovaps xmm1, [rsp+0x10]
00007f0254fd20ad  vmovaps xmm3, [rsp+0x20]
00007f0254fd20b3  vmovaps xmm4, [rsp+0x30]
00007f0254fd20b9  vmovaps xmm5, [rsp+0x40]
00007f0254fd20bf  vmovaps xmm6, [rsp+0x50]
00007f0254fd20c5  vmovaps xmm7, [rsp+0x60]
00007f0254fd20cb  vmovaps xmm8, [rsp+0x70]
00007f0254fd20d1  vmovaps xmm9, [rsp+0x80]
00007f0254fd20da  vmovaps xmm10, [rsp+0x90]
00007f0254fd20e3  vmovaps xmm11, [rsp+0xA0]
00007f0254fd20ec  vmovaps xmm12, [rsp+0xB0]
00007f0254fd20f5  vmovaps xmm13, [rsp+0xC0]
00007f0254fd20fe  vmovaps xmm14, [rsp+0xD0]
00007f0254fd2107  vmovaps xmm15, [rsp+0xE0]
00007f0254fd2110  add rsp, 0xF0
00007f0254fd2117  pop r11
00007f0254fd2119  pop r10
00007f0254fd211b  pop r9
00007f0254fd211d  pop r8
00007f0254fd211f  pop rsi
00007f0254fd2120  pop rdi
00007f0254fd2121  pop rdx
00007f0254fd2122  pop rcx
00007f0254fd2123  pop rax
00007f0254fd2124  add rsp, 0x08
00007f0254fd2128  jmp 0x00007F0254FCFBAB
00007f0254fd212d  call 0x00007F0254DFF430
00007f0254fd2132  jmp 0x00007F0254FCFBB8
00007f0254fd2137  sub rsp, 0x08
00007f0254fd213b  push rax
00007f0254fd213c  push rcx
00007f0254fd213d  push rdx
00007f0254fd213e  push rdi
00007f0254fd213f  push rsi
00007f0254fd2140  push r8
00007f0254fd2142  push r9
00007f0254fd2144  push r10
00007f0254fd2146  push r11
00007f0254fd2148  sub rsp, 0xF0
00007f0254fd214f  vmovaps [rsp], xmm0
00007f0254fd2154  vmovaps [rsp+0x10], xmm1
00007f0254fd215a  vmovaps [rsp+0x20], xmm2
00007f0254fd2160  vmovaps [rsp+0x30], xmm3
00007f0254fd2166  vmovaps [rsp+0x40], xmm4
00007f0254fd216c  vmovaps [rsp+0x50], xmm5
00007f0254fd2172  vmovaps [rsp+0x60], xmm6
00007f0254fd2178  vmovaps [rsp+0x70], xmm7
00007f0254fd217e  vmovaps [rsp+0x80], xmm8
00007f0254fd2187  vmovaps [rsp+0x90], xmm9
00007f0254fd2190  vmovaps [rsp+0xA0], xmm10
00007f0254fd2199  vmovaps [rsp+0xB0], xmm11
00007f0254fd21a2  vmovaps [rsp+0xC0], xmm12
00007f0254fd21ab  vmovaps [rsp+0xD0], xmm13
00007f0254fd21b4  vmovaps [rsp+0xE0], xmm14
00007f0254fd21bd  sub rsp, 0x30
00007f0254fd21c1  movaps [rsp], xmm15
00007f0254fd21c6  movaps [rsp+0x10], xmm13
00007f0254fd21cc  movaps [rsp+0x20], xmm1
00007f0254fd21d1  lea rdi, [rsp]
00007f0254fd21d5  mov esi, 0x00
00007f0254fd21da  mov rax, 0x55DD1360A530
00007f0254fd21e4  call rax
00007f0254fd21e6  movaps xmm15, [rsp]
00007f0254fd21eb  add rsp, 0x30
00007f0254fd21ef  vmovaps xmm0, [rsp]
00007f0254fd21f4  vmovaps xmm1, [rsp+0x10]
00007f0254fd21fa  vmovaps xmm2, [rsp+0x20]
00007f0254fd2200  vmovaps xmm3, [rsp+0x30]
00007f0254fd2206  vmovaps xmm4, [rsp+0x40]
00007f0254fd220c  vmovaps xmm5, [rsp+0x50]
00007f0254fd2212  vmovaps xmm6, [rsp+0x60]
00007f0254fd2218  vmovaps xmm7, [rsp+0x70]
00007f0254fd221e  vmovaps xmm8, [rsp+0x80]
00007f0254fd2227  vmovaps xmm9, [rsp+0x90]
00007f0254fd2230  vmovaps xmm10, [rsp+0xA0]
00007f0254fd2239  vmovaps xmm11, [rsp+0xB0]
00007f0254fd2242  vmovaps xmm12, [rsp+0xC0]
00007f0254fd224b  vmovaps xmm13, [rsp+0xD0]
00007f0254fd2254  vmovaps xmm14, [rsp+0xE0]
00007f0254fd225d  add rsp, 0xF0
00007f0254fd2264  pop r11
00007f0254fd2266  pop r10
00007f0254fd2268  pop r9
00007f0254fd226a  pop r8
00007f0254fd226c  pop rsi
00007f0254fd226d  pop rdi
00007f0254fd226e  pop rdx
00007f0254fd226f  pop rcx
00007f0254fd2270  pop rax
00007f0254fd2271  add rsp, 0x08
00007f0254fd2275  jmp 0x00007F0254FCFBF7
00007f0254fd227a  sub rsp, 0x08
00007f0254fd227e  push rax
00007f0254fd227f  push rcx
00007f0254fd2280  push rdx
00007f0254fd2281  push rdi
00007f0254fd2282  push rsi
00007f0254fd2283  push r8
00007f0254fd2285  push r9
00007f0254fd2287  push r10
00007f0254fd2289  push r11
00007f0254fd228b  sub rsp, 0xF0
00007f0254fd2292  vmovaps [rsp], xmm0
00007f0254fd2297  vmovaps [rsp+0x10], xmm1
00007f0254fd229d  vmovaps [rsp+0x20], xmm2
00007f0254fd22a3  vmovaps [rsp+0x30], xmm3
00007f0254fd22a9  vmovaps [rsp+0x40], xmm4
00007f0254fd22af  vmovaps [rsp+0x50], xmm5
00007f0254fd22b5  vmovaps [rsp+0x60], xmm6
00007f0254fd22bb  vmovaps [rsp+0x70], xmm7
00007f0254fd22c1  vmovaps [rsp+0x80], xmm8
00007f0254fd22ca  vmovaps [rsp+0x90], xmm9
00007f0254fd22d3  vmovaps [rsp+0xA0], xmm10
00007f0254fd22dc  vmovaps [rsp+0xB0], xmm11
00007f0254fd22e5  vmovaps [rsp+0xC0], xmm12
00007f0254fd22ee  vmovaps [rsp+0xD0], xmm13
00007f0254fd22f7  vmovaps [rsp+0xE0], xmm15
00007f0254fd2300  sub rsp, 0x30
00007f0254fd2304  movaps [rsp], xmm14
00007f0254fd2309  movaps [rsp+0x10], xmm11
00007f0254fd230f  movaps [rsp+0x20], xmm1
00007f0254fd2314  lea rdi, [rsp]
00007f0254fd2318  mov esi, 0x00
00007f0254fd231d  mov rax, 0x55DD1360A530
00007f0254fd2327  call rax
00007f0254fd2329  movaps xmm14, [rsp]
00007f0254fd232e  add rsp, 0x30
00007f0254fd2332  vmovaps xmm0, [rsp]
00007f0254fd2337  vmovaps xmm1, [rsp+0x10]
00007f0254fd233d  vmovaps xmm2, [rsp+0x20]
00007f0254fd2343  vmovaps xmm3, [rsp+0x30]
00007f0254fd2349  vmovaps xmm4, [rsp+0x40]
00007f0254fd234f  vmovaps xmm5, [rsp+0x50]
00007f0254fd2355  vmovaps xmm6, [rsp+0x60]
00007f0254fd235b  vmovaps xmm7, [rsp+0x70]
00007f0254fd2361  vmovaps xmm8, [rsp+0x80]
00007f0254fd236a  vmovaps xmm9, [rsp+0x90]
00007f0254fd2373  vmovaps xmm10, [rsp+0xA0]
00007f0254fd237c  vmovaps xmm11, [rsp+0xB0]
00007f0254fd2385  vmovaps xmm12, [rsp+0xC0]
00007f0254fd238e  vmovaps xmm13, [rsp+0xD0]
00007f0254fd2397  vmovaps xmm15, [rsp+0xE0]
00007f0254fd23a0  add rsp, 0xF0
00007f0254fd23a7  pop r11
00007f0254fd23a9  pop r10
00007f0254fd23ab  pop r9
00007f0254fd23ad  pop r8
00007f0254fd23af  pop rsi
00007f0254fd23b0  pop rdi
00007f0254fd23b1  pop rdx
00007f0254fd23b2  pop rcx
00007f0254fd23b3  pop rax
00007f0254fd23b4  add rsp, 0x08
00007f0254fd23b8  jmp 0x00007F0254FCFC21
00007f0254fd23bd  sub rsp, 0x08
00007f0254fd23c1  push rax
00007f0254fd23c2  push rcx
00007f0254fd23c3  push rdx
00007f0254fd23c4  push rdi
00007f0254fd23c5  push rsi
00007f0254fd23c6  push r8
00007f0254fd23c8  push r9
00007f0254fd23ca  push r10
00007f0254fd23cc  push r11
00007f0254fd23ce  sub rsp, 0xF0
00007f0254fd23d5  vmovaps [rsp], xmm0
00007f0254fd23da  vmovaps [rsp+0x10], xmm1
00007f0254fd23e0  vmovaps [rsp+0x20], xmm2
00007f0254fd23e6  vmovaps [rsp+0x30], xmm3
00007f0254fd23ec  vmovaps [rsp+0x40], xmm4
00007f0254fd23f2  vmovaps [rsp+0x50], xmm5
00007f0254fd23f8  vmovaps [rsp+0x60], xmm6
00007f0254fd23fe  vmovaps [rsp+0x70], xmm7
00007f0254fd2404  vmovaps [rsp+0x80], xmm8
00007f0254fd240d  vmovaps [rsp+0x90], xmm9
00007f0254fd2416  vmovaps [rsp+0xA0], xmm10
00007f0254fd241f  vmovaps [rsp+0xB0], xmm11
00007f0254fd2428  vmovaps [rsp+0xC0], xmm12
00007f0254fd2431  vmovaps [rsp+0xD0], xmm14
00007f0254fd243a  vmovaps [rsp+0xE0], xmm15
00007f0254fd2443  sub rsp, 0x30
00007f0254fd2447  movaps [rsp], xmm13
00007f0254fd244c  movaps [rsp+0x10], xmm11
00007f0254fd2452  movaps [rsp+0x20], xmm1
00007f0254fd2457  lea rdi, [rsp]
00007f0254fd245b  mov esi, 0x00
00007f0254fd2460  mov rax, 0x55DD1360A530
00007f0254fd246a  call rax
00007f0254fd246c  movaps xmm13, [rsp]
00007f0254fd2471  add rsp, 0x30
00007f0254fd2475  vmovaps xmm0, [rsp]
00007f0254fd247a  vmovaps xmm1, [rsp+0x10]
00007f0254fd2480  vmovaps xmm2, [rsp+0x20]
00007f0254fd2486  vmovaps xmm3, [rsp+0x30]
00007f0254fd248c  vmovaps xmm4, [rsp+0x40]
00007f0254fd2492  vmovaps xmm5, [rsp+0x50]
00007f0254fd2498  vmovaps xmm6, [rsp+0x60]
00007f0254fd249e  vmovaps xmm7, [rsp+0x70]
00007f0254fd24a4  vmovaps xmm8, [rsp+0x80]
00007f0254fd24ad  vmovaps xmm9, [rsp+0x90]
00007f0254fd24b6  vmovaps xmm10, [rsp+0xA0]
00007f0254fd24bf  vmovaps xmm11, [rsp+0xB0]
00007f0254fd24c8  vmovaps xmm12, [rsp+0xC0]
00007f0254fd24d1  vmovaps xmm14, [rsp+0xD0]
00007f0254fd24da  vmovaps xmm15, [rsp+0xE0]
00007f0254fd24e3  add rsp, 0xF0
00007f0254fd24ea  pop r11
00007f0254fd24ec  pop r10
00007f0254fd24ee  pop r9
00007f0254fd24f0  pop r8
00007f0254fd24f2  pop rsi
00007f0254fd24f3  pop rdi
00007f0254fd24f4  pop rdx
00007f0254fd24f5  pop rcx
00007f0254fd24f6  pop rax
00007f0254fd24f7  add rsp, 0x08
00007f0254fd24fb  jmp 0x00007F0254FCFC76
00007f0254fd2500  call 0x00007F0254DFF430
00007f0254fd2505  jmp 0x00007F0254FCFC83
00007f0254fd250a  sub rsp, 0x08
00007f0254fd250e  push rax
00007f0254fd250f  push rcx
00007f0254fd2510  push rdx
00007f0254fd2511  push rdi
00007f0254fd2512  push rsi
00007f0254fd2513  push r8
00007f0254fd2515  push r9
00007f0254fd2517  push r10
00007f0254fd2519  push r11
00007f0254fd251b  sub rsp, 0xF0
00007f0254fd2522  vmovaps [rsp], xmm0
00007f0254fd2527  vmovaps [rsp+0x10], xmm1
00007f0254fd252d  vmovaps [rsp+0x20], xmm2
00007f0254fd2533  vmovaps [rsp+0x30], xmm3
00007f0254fd2539  vmovaps [rsp+0x40], xmm4
00007f0254fd253f  vmovaps [rsp+0x50], xmm5
00007f0254fd2545  vmovaps [rsp+0x60], xmm6
00007f0254fd254b  vmovaps [rsp+0x70], xmm7
00007f0254fd2551  vmovaps [rsp+0x80], xmm8
00007f0254fd255a  vmovaps [rsp+0x90], xmm9
00007f0254fd2563  vmovaps [rsp+0xA0], xmm10
00007f0254fd256c  vmovaps [rsp+0xB0], xmm11
00007f0254fd2575  vmovaps [rsp+0xC0], xmm12
00007f0254fd257e  vmovaps [rsp+0xD0], xmm13
00007f0254fd2587  vmovaps [rsp+0xE0], xmm14
00007f0254fd2590  sub rsp, 0x30
00007f0254fd2594  movaps [rsp], xmm15
00007f0254fd2599  movaps [rsp+0x10], xmm11
00007f0254fd259f  movaps [rsp+0x20], xmm1
00007f0254fd25a4  lea rdi, [rsp]
00007f0254fd25a8  mov esi, 0x00
00007f0254fd25ad  mov rax, 0x55DD1360A530
00007f0254fd25b7  call rax
00007f0254fd25b9  movaps xmm15, [rsp]
00007f0254fd25be  add rsp, 0x30
00007f0254fd25c2  vmovaps xmm0, [rsp]
00007f0254fd25c7  vmovaps xmm1, [rsp+0x10]
00007f0254fd25cd  vmovaps xmm2, [rsp+0x20]
00007f0254fd25d3  vmovaps xmm3, [rsp+0x30]
00007f0254fd25d9  vmovaps xmm4, [rsp+0x40]
00007f0254fd25df  vmovaps xmm5, [rsp+0x50]
00007f0254fd25e5  vmovaps xmm6, [rsp+0x60]
00007f0254fd25eb  vmovaps xmm7, [rsp+0x70]
00007f0254fd25f1  vmovaps xmm8, [rsp+0x80]
00007f0254fd25fa  vmovaps xmm9, [rsp+0x90]
00007f0254fd2603  vmovaps xmm10, [rsp+0xA0]
00007f0254fd260c  vmovaps xmm11, [rsp+0xB0]
00007f0254fd2615  vmovaps xmm12, [rsp+0xC0]
00007f0254fd261e  vmovaps xmm13, [rsp+0xD0]
00007f0254fd2627  vmovaps xmm14, [rsp+0xE0]
00007f0254fd2630  add rsp, 0xF0
00007f0254fd2637  pop r11
00007f0254fd2639  pop r10
00007f0254fd263b  pop r9
00007f0254fd263d  pop r8
00007f0254fd263f  pop rsi
00007f0254fd2640  pop rdi
00007f0254fd2641  pop rdx
00007f0254fd2642  pop rcx
00007f0254fd2643  pop rax
00007f0254fd2644  add rsp, 0x08
00007f0254fd2648  jmp 0x00007F0254FCFCBC
00007f0254fd264d  sub rsp, 0x08
00007f0254fd2651  push rax
00007f0254fd2652  push rcx
00007f0254fd2653  push rdx
00007f0254fd2654  push rdi
00007f0254fd2655  push rsi
00007f0254fd2656  push r8
00007f0254fd2658  push r9
00007f0254fd265a  push r10
00007f0254fd265c  push r11
00007f0254fd265e  sub rsp, 0xF0
00007f0254fd2665  vmovaps [rsp], xmm0
00007f0254fd266a  vmovaps [rsp+0x10], xmm1
00007f0254fd2670  vmovaps [rsp+0x20], xmm2
00007f0254fd2676  vmovaps [rsp+0x30], xmm3
00007f0254fd267c  vmovaps [rsp+0x40], xmm4
00007f0254fd2682  vmovaps [rsp+0x50], xmm5
00007f0254fd2688  vmovaps [rsp+0x60], xmm6
00007f0254fd268e  vmovaps [rsp+0x70], xmm7
00007f0254fd2694  vmovaps [rsp+0x80], xmm8
00007f0254fd269d  vmovaps [rsp+0x90], xmm9
00007f0254fd26a6  vmovaps [rsp+0xA0], xmm10
00007f0254fd26af  vmovaps [rsp+0xB0], xmm12
00007f0254fd26b8  vmovaps [rsp+0xC0], xmm13
00007f0254fd26c1  vmovaps [rsp+0xD0], xmm14
00007f0254fd26ca  vmovaps [rsp+0xE0], xmm15
00007f0254fd26d3  sub rsp, 0x30
00007f0254fd26d7  movaps [rsp], xmm11
00007f0254fd26dc  movaps [rsp+0x10], xmm6
00007f0254fd26e1  movaps [rsp+0x20], xmm14
00007f0254fd26e7  lea rdi, [rsp]
00007f0254fd26eb  mov esi, 0x00
00007f0254fd26f0  mov rax, 0x55DD1360A530
00007f0254fd26fa  call rax
00007f0254fd26fc  movaps xmm11, [rsp]
00007f0254fd2701  add rsp, 0x30
00007f0254fd2705  vmovaps xmm0, [rsp]
00007f0254fd270a  vmovaps xmm1, [rsp+0x10]
00007f0254fd2710  vmovaps xmm2, [rsp+0x20]
00007f0254fd2716  vmovaps xmm3, [rsp+0x30]
00007f0254fd271c  vmovaps xmm4, [rsp+0x40]
00007f0254fd2722  vmovaps xmm5, [rsp+0x50]
00007f0254fd2728  vmovaps xmm6, [rsp+0x60]
00007f0254fd272e  vmovaps xmm7, [rsp+0x70]
00007f0254fd2734  vmovaps xmm8, [rsp+0x80]
00007f0254fd273d  vmovaps xmm9, [rsp+0x90]
00007f0254fd2746  vmovaps xmm10, [rsp+0xA0]
00007f0254fd274f  vmovaps xmm12, [rsp+0xB0]
00007f0254fd2758  vmovaps xmm13, [rsp+0xC0]
00007f0254fd2761  vmovaps xmm14, [rsp+0xD0]
00007f0254fd276a  vmovaps xmm15, [rsp+0xE0]
00007f0254fd2773  add rsp, 0xF0
00007f0254fd277a  pop r11
00007f0254fd277c  pop r10
00007f0254fd277e  pop r9
00007f0254fd2780  pop r8
00007f0254fd2782  pop rsi
00007f0254fd2783  pop rdi
00007f0254fd2784  pop rdx
00007f0254fd2785  pop rcx
00007f0254fd2786  pop rax
00007f0254fd2787  add rsp, 0x08
00007f0254fd278b  jmp 0x00007F0254FCFD34
00007f0254fd2790  call 0x00007F0254DFF430
00007f0254fd2795  jmp 0x00007F0254FCFD3E
00007f0254fd279a  sub rsp, 0x08
00007f0254fd279e  push rax
00007f0254fd279f  push rcx
00007f0254fd27a0  push rdx
00007f0254fd27a1  push rdi
00007f0254fd27a2  push rsi
00007f0254fd27a3  push r8
00007f0254fd27a5  push r9
00007f0254fd27a7  push r10
00007f0254fd27a9  push r11
00007f0254fd27ab  sub rsp, 0xF0
00007f0254fd27b2  vmovaps [rsp], xmm0
00007f0254fd27b7  vmovaps [rsp+0x10], xmm1
00007f0254fd27bd  vmovaps [rsp+0x20], xmm2
00007f0254fd27c3  vmovaps [rsp+0x30], xmm3
00007f0254fd27c9  vmovaps [rsp+0x40], xmm4
00007f0254fd27cf  vmovaps [rsp+0x50], xmm5
00007f0254fd27d5  vmovaps [rsp+0x60], xmm6
00007f0254fd27db  vmovaps [rsp+0x70], xmm7
00007f0254fd27e1  vmovaps [rsp+0x80], xmm8
00007f0254fd27ea  vmovaps [rsp+0x90], xmm9
00007f0254fd27f3  vmovaps [rsp+0xA0], xmm10
00007f0254fd27fc  vmovaps [rsp+0xB0], xmm11
00007f0254fd2805  vmovaps [rsp+0xC0], xmm12
00007f0254fd280e  vmovaps [rsp+0xD0], xmm13
00007f0254fd2817  vmovaps [rsp+0xE0], xmm15
00007f0254fd2820  sub rsp, 0x30
00007f0254fd2824  movaps [rsp], xmm14
00007f0254fd2829  movaps [rsp+0x10], xmm6
00007f0254fd282e  movaps [rsp+0x20], xmm2
00007f0254fd2833  lea rdi, [rsp]
00007f0254fd2837  mov esi, 0x00
00007f0254fd283c  mov rax, 0x55DD1360A530
00007f0254fd2846  call rax
00007f0254fd2848  movaps xmm14, [rsp]
00007f0254fd284d  add rsp, 0x30
00007f0254fd2851  vmovaps xmm0, [rsp]
00007f0254fd2856  vmovaps xmm1, [rsp+0x10]
00007f0254fd285c  vmovaps xmm2, [rsp+0x20]
00007f0254fd2862  vmovaps xmm3, [rsp+0x30]
00007f0254fd2868  vmovaps xmm4, [rsp+0x40]
00007f0254fd286e  vmovaps xmm5, [rsp+0x50]
00007f0254fd2874  vmovaps xmm6, [rsp+0x60]
00007f0254fd287a  vmovaps xmm7, [rsp+0x70]
00007f0254fd2880  vmovaps xmm8, [rsp+0x80]
00007f0254fd2889  vmovaps xmm9, [rsp+0x90]
00007f0254fd2892  vmovaps xmm10, [rsp+0xA0]
00007f0254fd289b  vmovaps xmm11, [rsp+0xB0]
00007f0254fd28a4  vmovaps xmm12, [rsp+0xC0]
00007f0254fd28ad  vmovaps xmm13, [rsp+0xD0]
00007f0254fd28b6  vmovaps xmm15, [rsp+0xE0]
00007f0254fd28bf  add rsp, 0xF0
00007f0254fd28c6  pop r11
00007f0254fd28c8  pop r10
00007f0254fd28ca  pop r9
00007f0254fd28cc  pop r8
00007f0254fd28ce  pop rsi
00007f0254fd28cf  pop rdi
00007f0254fd28d0  pop rdx
00007f0254fd28d1  pop rcx
00007f0254fd28d2  pop rax
00007f0254fd28d3  add rsp, 0x08
00007f0254fd28d7  jmp 0x00007F0254FCFD72
00007f0254fd28dc  sub rsp, 0x08
00007f0254fd28e0  push rax
00007f0254fd28e1  push rcx
00007f0254fd28e2  push rdx
00007f0254fd28e3  push rdi
00007f0254fd28e4  push rsi
00007f0254fd28e5  push r8
00007f0254fd28e7  push r9
00007f0254fd28e9  push r10
00007f0254fd28eb  push r11
00007f0254fd28ed  sub rsp, 0xF0
00007f0254fd28f4  vmovaps [rsp], xmm0
00007f0254fd28f9  vmovaps [rsp+0x10], xmm1
00007f0254fd28ff  vmovaps [rsp+0x20], xmm2
00007f0254fd2905  vmovaps [rsp+0x30], xmm3
00007f0254fd290b  vmovaps [rsp+0x40], xmm4
00007f0254fd2911  vmovaps [rsp+0x50], xmm5
00007f0254fd2917  vmovaps [rsp+0x60], xmm7
00007f0254fd291d  vmovaps [rsp+0x70], xmm8
00007f0254fd2923  vmovaps [rsp+0x80], xmm9
00007f0254fd292c  vmovaps [rsp+0x90], xmm10
00007f0254fd2935  vmovaps [rsp+0xA0], xmm11
00007f0254fd293e  vmovaps [rsp+0xB0], xmm12
00007f0254fd2947  vmovaps [rsp+0xC0], xmm13
00007f0254fd2950  vmovaps [rsp+0xD0], xmm14
00007f0254fd2959  vmovaps [rsp+0xE0], xmm15
00007f0254fd2962  sub rsp, 0x30
00007f0254fd2966  movaps [rsp], xmm6
00007f0254fd296a  movaps [rsp+0x10], xmm5
00007f0254fd296f  movaps [rsp+0x20], xmm1
00007f0254fd2974  lea rdi, [rsp]
00007f0254fd2978  mov esi, 0x00
00007f0254fd297d  mov rax, 0x55DD1360A530
00007f0254fd2987  call rax
00007f0254fd2989  movaps xmm6, [rsp]
00007f0254fd298d  add rsp, 0x30
00007f0254fd2991  vmovaps xmm0, [rsp]
00007f0254fd2996  vmovaps xmm1, [rsp+0x10]
00007f0254fd299c  vmovaps xmm2, [rsp+0x20]
00007f0254fd29a2  vmovaps xmm3, [rsp+0x30]
00007f0254fd29a8  vmovaps xmm4, [rsp+0x40]
00007f0254fd29ae  vmovaps xmm5, [rsp+0x50]
00007f0254fd29b4  vmovaps xmm7, [rsp+0x60]
00007f0254fd29ba  vmovaps xmm8, [rsp+0x70]
00007f0254fd29c0  vmovaps xmm9, [rsp+0x80]
00007f0254fd29c9  vmovaps xmm10, [rsp+0x90]
00007f0254fd29d2  vmovaps xmm11, [rsp+0xA0]
00007f0254fd29db  vmovaps xmm12, [rsp+0xB0]
00007f0254fd29e4  vmovaps xmm13, [rsp+0xC0]
00007f0254fd29ed  vmovaps xmm14, [rsp+0xD0]
00007f0254fd29f6  vmovaps xmm15, [rsp+0xE0]
00007f0254fd29ff  add rsp, 0xF0
00007f0254fd2a06  pop r11
00007f0254fd2a08  pop r10
00007f0254fd2a0a  pop r9
00007f0254fd2a0c  pop r8
00007f0254fd2a0e  pop rsi
00007f0254fd2a0f  pop rdi
00007f0254fd2a10  pop rdx
00007f0254fd2a11  pop rcx
00007f0254fd2a12  pop rax
00007f0254fd2a13  add rsp, 0x08
00007f0254fd2a17  jmp 0x00007F0254FCFD98
00007f0254fd2a1c  sub rsp, 0x08
00007f0254fd2a20  push rax
00007f0254fd2a21  push rcx
00007f0254fd2a22  push rdx
00007f0254fd2a23  push rdi
00007f0254fd2a24  push rsi
00007f0254fd2a25  push r8
00007f0254fd2a27  push r9
00007f0254fd2a29  push r10
00007f0254fd2a2b  push r11
00007f0254fd2a2d  sub rsp, 0xF0
00007f0254fd2a34  vmovaps [rsp], xmm0
00007f0254fd2a39  vmovaps [rsp+0x10], xmm2
00007f0254fd2a3f  vmovaps [rsp+0x20], xmm3
00007f0254fd2a45  vmovaps [rsp+0x30], xmm4
00007f0254fd2a4b  vmovaps [rsp+0x40], xmm5
00007f0254fd2a51  vmovaps [rsp+0x50], xmm6
00007f0254fd2a57  vmovaps [rsp+0x60], xmm7
00007f0254fd2a5d  vmovaps [rsp+0x70], xmm8
00007f0254fd2a63  vmovaps [rsp+0x80], xmm9
00007f0254fd2a6c  vmovaps [rsp+0x90], xmm10
00007f0254fd2a75  vmovaps [rsp+0xA0], xmm11
00007f0254fd2a7e  vmovaps [rsp+0xB0], xmm12
00007f0254fd2a87  vmovaps [rsp+0xC0], xmm13
00007f0254fd2a90  vmovaps [rsp+0xD0], xmm14
00007f0254fd2a99  vmovaps [rsp+0xE0], xmm15
00007f0254fd2aa2  sub rsp, 0x30
00007f0254fd2aa6  movaps [rsp], xmm1
00007f0254fd2aaa  movaps [rsp+0x10], xmm5
00007f0254fd2aaf  movaps [rsp+0x20], xmm13
00007f0254fd2ab5  lea rdi, [rsp]
00007f0254fd2ab9  mov esi, 0x00
00007f0254fd2abe  mov rax, 0x55DD1360A530
00007f0254fd2ac8  call rax
00007f0254fd2aca  movaps xmm1, [rsp]
00007f0254fd2ace  add rsp, 0x30
00007f0254fd2ad2  vmovaps xmm0, [rsp]
00007f0254fd2ad7  vmovaps xmm2, [rsp+0x10]
00007f0254fd2add  vmovaps xmm3, [rsp+0x20]
00007f0254fd2ae3  vmovaps xmm4, [rsp+0x30]
00007f0254fd2ae9  vmovaps xmm5, [rsp+0x40]
00007f0254fd2aef  vmovaps xmm6, [rsp+0x50]
00007f0254fd2af5  vmovaps xmm7, [rsp+0x60]
00007f0254fd2afb  vmovaps xmm8, [rsp+0x70]
00007f0254fd2b01  vmovaps xmm9, [rsp+0x80]
00007f0254fd2b0a  vmovaps xmm10, [rsp+0x90]
00007f0254fd2b13  vmovaps xmm11, [rsp+0xA0]
00007f0254fd2b1c  vmovaps xmm12, [rsp+0xB0]
00007f0254fd2b25  vmovaps xmm13, [rsp+0xC0]
00007f0254fd2b2e  vmovaps xmm14, [rsp+0xD0]
00007f0254fd2b37  vmovaps xmm15, [rsp+0xE0]
00007f0254fd2b40  add rsp, 0xF0
00007f0254fd2b47  pop r11
00007f0254fd2b49  pop r10
00007f0254fd2b4b  pop r9
00007f0254fd2b4d  pop r8
00007f0254fd2b4f  pop rsi
00007f0254fd2b50  pop rdi
00007f0254fd2b51  pop rdx
00007f0254fd2b52  pop rcx
00007f0254fd2b53  pop rax
00007f0254fd2b54  add rsp, 0x08
00007f0254fd2b58  jmp 0x00007F0254FCFDB6
00007f0254fd2b5d  sub rsp, 0x08
00007f0254fd2b61  push rax
00007f0254fd2b62  push rcx
00007f0254fd2b63  push rdx
00007f0254fd2b64  push rdi
00007f0254fd2b65  push rsi
00007f0254fd2b66  push r8
00007f0254fd2b68  push r9
00007f0254fd2b6a  push r10
00007f0254fd2b6c  push r11
00007f0254fd2b6e  sub rsp, 0xF0
00007f0254fd2b75  vmovaps [rsp], xmm0
00007f0254fd2b7a  vmovaps [rsp+0x10], xmm1
00007f0254fd2b80  vmovaps [rsp+0x20], xmm2
00007f0254fd2b86  vmovaps [rsp+0x30], xmm3
00007f0254fd2b8c  vmovaps [rsp+0x40], xmm4
00007f0254fd2b92  vmovaps [rsp+0x50], xmm6
00007f0254fd2b98  vmovaps [rsp+0x60], xmm7
00007f0254fd2b9e  vmovaps [rsp+0x70], xmm8
00007f0254fd2ba4  vmovaps [rsp+0x80], xmm9
00007f0254fd2bad  vmovaps [rsp+0x90], xmm10
00007f0254fd2bb6  vmovaps [rsp+0xA0], xmm11
00007f0254fd2bbf  vmovaps [rsp+0xB0], xmm12
00007f0254fd2bc8  vmovaps [rsp+0xC0], xmm13
00007f0254fd2bd1  vmovaps [rsp+0xD0], xmm14
00007f0254fd2bda  vmovaps [rsp+0xE0], xmm15
00007f0254fd2be3  sub rsp, 0x30
00007f0254fd2be7  movaps [rsp], xmm5
00007f0254fd2beb  movaps [rsp+0x10], xmm2
00007f0254fd2bf0  movaps [rsp+0x20], xmm13
00007f0254fd2bf6  lea rdi, [rsp]
00007f0254fd2bfa  mov esi, 0x00
00007f0254fd2bff  mov rax, 0x55DD1360A530
00007f0254fd2c09  call rax
00007f0254fd2c0b  movaps xmm5, [rsp]
00007f0254fd2c0f  add rsp, 0x30
00007f0254fd2c13  vmovaps xmm0, [rsp]
00007f0254fd2c18  vmovaps xmm1, [rsp+0x10]
00007f0254fd2c1e  vmovaps xmm2, [rsp+0x20]
00007f0254fd2c24  vmovaps xmm3, [rsp+0x30]
00007f0254fd2c2a  vmovaps xmm4, [rsp+0x40]
00007f0254fd2c30  vmovaps xmm6, [rsp+0x50]
00007f0254fd2c36  vmovaps xmm7, [rsp+0x60]
00007f0254fd2c3c  vmovaps xmm8, [rsp+0x70]
00007f0254fd2c42  vmovaps xmm9, [rsp+0x80]
00007f0254fd2c4b  vmovaps xmm10, [rsp+0x90]
00007f0254fd2c54  vmovaps xmm11, [rsp+0xA0]
00007f0254fd2c5d  vmovaps xmm12, [rsp+0xB0]
00007f0254fd2c66  vmovaps xmm13, [rsp+0xC0]
00007f0254fd2c6f  vmovaps xmm14, [rsp+0xD0]
00007f0254fd2c78  vmovaps xmm15, [rsp+0xE0]
00007f0254fd2c81  add rsp, 0xF0
00007f0254fd2c88  pop r11
00007f0254fd2c8a  pop r10
00007f0254fd2c8c  pop r9
00007f0254fd2c8e  pop r8
00007f0254fd2c90  pop rsi
00007f0254fd2c91  pop rdi
00007f0254fd2c92  pop rdx
00007f0254fd2c93  pop rcx
00007f0254fd2c94  pop rax
00007f0254fd2c95  add rsp, 0x08
00007f0254fd2c99  jmp 0x00007F0254FCFDEC
00007f0254fd2c9e  sub rsp, 0x08
00007f0254fd2ca2  push rax
00007f0254fd2ca3  push rcx
00007f0254fd2ca4  push rdx
00007f0254fd2ca5  push rdi
00007f0254fd2ca6  push rsi
00007f0254fd2ca7  push r8
00007f0254fd2ca9  push r9
00007f0254fd2cab  push r10
00007f0254fd2cad  push r11
00007f0254fd2caf  sub rsp, 0xF0
00007f0254fd2cb6  vmovaps [rsp], xmm0
00007f0254fd2cbb  vmovaps [rsp+0x10], xmm1
00007f0254fd2cc1  vmovaps [rsp+0x20], xmm2
00007f0254fd2cc7  vmovaps [rsp+0x30], xmm3
00007f0254fd2ccd  vmovaps [rsp+0x40], xmm4
00007f0254fd2cd3  vmovaps [rsp+0x50], xmm5
00007f0254fd2cd9  vmovaps [rsp+0x60], xmm6
00007f0254fd2cdf  vmovaps [rsp+0x70], xmm7
00007f0254fd2ce5  vmovaps [rsp+0x80], xmm8
00007f0254fd2cee  vmovaps [rsp+0x90], xmm9
00007f0254fd2cf7  vmovaps [rsp+0xA0], xmm10
00007f0254fd2d00  vmovaps [rsp+0xB0], xmm11
00007f0254fd2d09  vmovaps [rsp+0xC0], xmm12
00007f0254fd2d12  vmovaps [rsp+0xD0], xmm14
00007f0254fd2d1b  vmovaps [rsp+0xE0], xmm15
00007f0254fd2d24  sub rsp, 0x30
00007f0254fd2d28  movaps [rsp], xmm13
00007f0254fd2d2d  movaps [rsp+0x10], xmm10
00007f0254fd2d33  movaps [rsp+0x20], xmm1
00007f0254fd2d38  lea rdi, [rsp]
00007f0254fd2d3c  mov esi, 0x00
00007f0254fd2d41  mov rax, 0x55DD1360A530
00007f0254fd2d4b  call rax
00007f0254fd2d4d  movaps xmm13, [rsp]
00007f0254fd2d52  add rsp, 0x30
00007f0254fd2d56  vmovaps xmm0, [rsp]
00007f0254fd2d5b  vmovaps xmm1, [rsp+0x10]
00007f0254fd2d61  vmovaps xmm2, [rsp+0x20]
00007f0254fd2d67  vmovaps xmm3, [rsp+0x30]
00007f0254fd2d6d  vmovaps xmm4, [rsp+0x40]
00007f0254fd2d73  vmovaps xmm5, [rsp+0x50]
00007f0254fd2d79  vmovaps xmm6, [rsp+0x60]
00007f0254fd2d7f  vmovaps xmm7, [rsp+0x70]
00007f0254fd2d85  vmovaps xmm8, [rsp+0x80]
00007f0254fd2d8e  vmovaps xmm9, [rsp+0x90]
00007f0254fd2d97  vmovaps xmm10, [rsp+0xA0]
00007f0254fd2da0  vmovaps xmm11, [rsp+0xB0]
00007f0254fd2da9  vmovaps xmm12, [rsp+0xC0]
00007f0254fd2db2  vmovaps xmm14, [rsp+0xD0]
00007f0254fd2dbb  vmovaps xmm15, [rsp+0xE0]
00007f0254fd2dc4  add rsp, 0xF0
00007f0254fd2dcb  pop r11
00007f0254fd2dcd  pop r10
00007f0254fd2dcf  pop r9
00007f0254fd2dd1  pop r8
00007f0254fd2dd3  pop rsi
00007f0254fd2dd4  pop rdi
00007f0254fd2dd5  pop rdx
00007f0254fd2dd6  pop rcx
00007f0254fd2dd7  pop rax
00007f0254fd2dd8  add rsp, 0x08
00007f0254fd2ddc  jmp 0x00007F0254FCFE15
00007f0254fd2de1  sub rsp, 0x08
00007f0254fd2de5  push rax
00007f0254fd2de6  push rcx
00007f0254fd2de7  push rdx
00007f0254fd2de8  push rdi
00007f0254fd2de9  push rsi
00007f0254fd2dea  push r8
00007f0254fd2dec  push r9
00007f0254fd2dee  push r10
00007f0254fd2df0  push r11
00007f0254fd2df2  sub rsp, 0xF0
00007f0254fd2df9  vmovaps [rsp], xmm0
00007f0254fd2dfe  vmovaps [rsp+0x10], xmm2
00007f0254fd2e04  vmovaps [rsp+0x20], xmm3
00007f0254fd2e0a  vmovaps [rsp+0x30], xmm4
00007f0254fd2e10  vmovaps [rsp+0x40], xmm5
00007f0254fd2e16  vmovaps [rsp+0x50], xmm6
00007f0254fd2e1c  vmovaps [rsp+0x60], xmm7
00007f0254fd2e22  vmovaps [rsp+0x70], xmm8
00007f0254fd2e28  vmovaps [rsp+0x80], xmm9
00007f0254fd2e31  vmovaps [rsp+0x90], xmm10
00007f0254fd2e3a  vmovaps [rsp+0xA0], xmm11
00007f0254fd2e43  vmovaps [rsp+0xB0], xmm12
00007f0254fd2e4c  vmovaps [rsp+0xC0], xmm13
00007f0254fd2e55  vmovaps [rsp+0xD0], xmm14
00007f0254fd2e5e  vmovaps [rsp+0xE0], xmm15
00007f0254fd2e67  sub rsp, 0x30
00007f0254fd2e6b  movaps [rsp], xmm1
00007f0254fd2e6f  movaps [rsp+0x10], xmm15
00007f0254fd2e75  movaps [rsp+0x20], xmm10
00007f0254fd2e7b  lea rdi, [rsp]
00007f0254fd2e7f  mov esi, 0x00
00007f0254fd2e84  mov rax, 0x55DD1360A530
00007f0254fd2e8e  call rax
00007f0254fd2e90  movaps xmm1, [rsp]
00007f0254fd2e94  add rsp, 0x30
00007f0254fd2e98  vmovaps xmm0, [rsp]
00007f0254fd2e9d  vmovaps xmm2, [rsp+0x10]
00007f0254fd2ea3  vmovaps xmm3, [rsp+0x20]
00007f0254fd2ea9  vmovaps xmm4, [rsp+0x30]
00007f0254fd2eaf  vmovaps xmm5, [rsp+0x40]
00007f0254fd2eb5  vmovaps xmm6, [rsp+0x50]
00007f0254fd2ebb  vmovaps xmm7, [rsp+0x60]
00007f0254fd2ec1  vmovaps xmm8, [rsp+0x70]
00007f0254fd2ec7  vmovaps xmm9, [rsp+0x80]
00007f0254fd2ed0  vmovaps xmm10, [rsp+0x90]
00007f0254fd2ed9  vmovaps xmm11, [rsp+0xA0]
00007f0254fd2ee2  vmovaps xmm12, [rsp+0xB0]
00007f0254fd2eeb  vmovaps xmm13, [rsp+0xC0]
00007f0254fd2ef4  vmovaps xmm14, [rsp+0xD0]
00007f0254fd2efd  vmovaps xmm15, [rsp+0xE0]
00007f0254fd2f06  add rsp, 0xF0
00007f0254fd2f0d  pop r11
00007f0254fd2f0f  pop r10
00007f0254fd2f11  pop r9
00007f0254fd2f13  pop r8
00007f0254fd2f15  pop rsi
00007f0254fd2f16  pop rdi
00007f0254fd2f17  pop rdx
00007f0254fd2f18  pop rcx
00007f0254fd2f19  pop rax
00007f0254fd2f1a  add rsp, 0x08
00007f0254fd2f1e  jmp 0x00007F0254FCFE34
00007f0254fd2f23  sub rsp, 0x08
00007f0254fd2f27  push rax
00007f0254fd2f28  push rcx
00007f0254fd2f29  push rdx
00007f0254fd2f2a  push rdi
00007f0254fd2f2b  push rsi
00007f0254fd2f2c  push r8
00007f0254fd2f2e  push r9
00007f0254fd2f30  push r10
00007f0254fd2f32  push r11
00007f0254fd2f34  sub rsp, 0xF0
00007f0254fd2f3b  vmovaps [rsp], xmm0
00007f0254fd2f40  vmovaps [rsp+0x10], xmm1
00007f0254fd2f46  vmovaps [rsp+0x20], xmm2
00007f0254fd2f4c  vmovaps [rsp+0x30], xmm3
00007f0254fd2f52  vmovaps [rsp+0x40], xmm4
00007f0254fd2f58  vmovaps [rsp+0x50], xmm5
00007f0254fd2f5e  vmovaps [rsp+0x60], xmm6
00007f0254fd2f64  vmovaps [rsp+0x70], xmm7
00007f0254fd2f6a  vmovaps [rsp+0x80], xmm8
00007f0254fd2f73  vmovaps [rsp+0x90], xmm9
00007f0254fd2f7c  vmovaps [rsp+0xA0], xmm10
00007f0254fd2f85  vmovaps [rsp+0xB0], xmm11
00007f0254fd2f8e  vmovaps [rsp+0xC0], xmm12
00007f0254fd2f97  vmovaps [rsp+0xD0], xmm13
00007f0254fd2fa0  vmovaps [rsp+0xE0], xmm14
00007f0254fd2fa9  sub rsp, 0x30
00007f0254fd2fad  movaps [rsp], xmm15
00007f0254fd2fb2  movaps [rsp+0x10], xmm10
00007f0254fd2fb8  movaps [rsp+0x20], xmm11
00007f0254fd2fbe  lea rdi, [rsp]
00007f0254fd2fc2  mov esi, 0x00
00007f0254fd2fc7  mov rax, 0x55DD1360A530
00007f0254fd2fd1  call rax
00007f0254fd2fd3  movaps xmm15, [rsp]
00007f0254fd2fd8  add rsp, 0x30
00007f0254fd2fdc  vmovaps xmm0, [rsp]
00007f0254fd2fe1  vmovaps xmm1, [rsp+0x10]
00007f0254fd2fe7  vmovaps xmm2, [rsp+0x20]
00007f0254fd2fed  vmovaps xmm3, [rsp+0x30]
00007f0254fd2ff3  vmovaps xmm4, [rsp+0x40]
00007f0254fd2ff9  vmovaps xmm5, [rsp+0x50]
00007f0254fd2fff  vmovaps xmm6, [rsp+0x60]
00007f0254fd3005  vmovaps xmm7, [rsp+0x70]
00007f0254fd300b  vmovaps xmm8, [rsp+0x80]
00007f0254fd3014  vmovaps xmm9, [rsp+0x90]
00007f0254fd301d  vmovaps xmm10, [rsp+0xA0]
00007f0254fd3026  vmovaps xmm11, [rsp+0xB0]
00007f0254fd302f  vmovaps xmm12, [rsp+0xC0]
00007f0254fd3038  vmovaps xmm13, [rsp+0xD0]
00007f0254fd3041  vmovaps xmm14, [rsp+0xE0]
00007f0254fd304a  add rsp, 0xF0
00007f0254fd3051  pop r11
00007f0254fd3053  pop r10
00007f0254fd3055  pop r9
00007f0254fd3057  pop r8
00007f0254fd3059  pop rsi
00007f0254fd305a  pop rdi
00007f0254fd305b  pop rdx
00007f0254fd305c  pop rcx
00007f0254fd305d  pop rax
00007f0254fd305e  add rsp, 0x08
00007f0254fd3062  jmp 0x00007F0254FCFE57
00007f0254fd3067  sub rsp, 0x08
00007f0254fd306b  push rax
00007f0254fd306c  push rcx
00007f0254fd306d  push rdx
00007f0254fd306e  push rdi
00007f0254fd306f  push rsi
00007f0254fd3070  push r8
00007f0254fd3072  push r9
00007f0254fd3074  push r10
00007f0254fd3076  push r11
00007f0254fd3078  sub rsp, 0xF0
00007f0254fd307f  vmovaps [rsp], xmm0
00007f0254fd3084  vmovaps [rsp+0x10], xmm1
00007f0254fd308a  vmovaps [rsp+0x20], xmm2
00007f0254fd3090  vmovaps [rsp+0x30], xmm3
00007f0254fd3096  vmovaps [rsp+0x40], xmm4
00007f0254fd309c  vmovaps [rsp+0x50], xmm5
00007f0254fd30a2  vmovaps [rsp+0x60], xmm6
00007f0254fd30a8  vmovaps [rsp+0x70], xmm7
00007f0254fd30ae  vmovaps [rsp+0x80], xmm8
00007f0254fd30b7  vmovaps [rsp+0x90], xmm9
00007f0254fd30c0  vmovaps [rsp+0xA0], xmm11
00007f0254fd30c9  vmovaps [rsp+0xB0], xmm12
00007f0254fd30d2  vmovaps [rsp+0xC0], xmm13
00007f0254fd30db  vmovaps [rsp+0xD0], xmm14
00007f0254fd30e4  vmovaps [rsp+0xE0], xmm15
00007f0254fd30ed  sub rsp, 0x30
00007f0254fd30f1  movaps [rsp], xmm10
00007f0254fd30f6  movaps [rsp+0x10], xmm12
00007f0254fd30fc  movaps [rsp+0x20], xmm11
00007f0254fd3102  lea rdi, [rsp]
00007f0254fd3106  mov esi, 0x00
00007f0254fd310b  mov rax, 0x55DD1360A530
00007f0254fd3115  call rax
00007f0254fd3117  movaps xmm10, [rsp]
00007f0254fd311c  add rsp, 0x30
00007f0254fd3120  vmovaps xmm0, [rsp]
00007f0254fd3125  vmovaps xmm1, [rsp+0x10]
00007f0254fd312b  vmovaps xmm2, [rsp+0x20]
00007f0254fd3131  vmovaps xmm3, [rsp+0x30]
00007f0254fd3137  vmovaps xmm4, [rsp+0x40]
00007f0254fd313d  vmovaps xmm5, [rsp+0x50]
00007f0254fd3143  vmovaps xmm6, [rsp+0x60]
00007f0254fd3149  vmovaps xmm7, [rsp+0x70]
00007f0254fd314f  vmovaps xmm8, [rsp+0x80]
00007f0254fd3158  vmovaps xmm9, [rsp+0x90]
00007f0254fd3161  vmovaps xmm11, [rsp+0xA0]
00007f0254fd316a  vmovaps xmm12, [rsp+0xB0]
00007f0254fd3173  vmovaps xmm13, [rsp+0xC0]
00007f0254fd317c  vmovaps xmm14, [rsp+0xD0]
00007f0254fd3185  vmovaps xmm15, [rsp+0xE0]
00007f0254fd318e  add rsp, 0xF0
00007f0254fd3195  pop r11
00007f0254fd3197  pop r10
00007f0254fd3199  pop r9
00007f0254fd319b  pop r8
00007f0254fd319d  pop rsi
00007f0254fd319e  pop rdi
00007f0254fd319f  pop rdx
00007f0254fd31a0  pop rcx
00007f0254fd31a1  pop rax
00007f0254fd31a2  add rsp, 0x08
00007f0254fd31a6  jmp 0x00007F0254FCFE80
00007f0254fd31ab  sub rsp, 0x08
00007f0254fd31af  push rax
00007f0254fd31b0  push rcx
00007f0254fd31b1  push rdx
00007f0254fd31b2  push rdi
00007f0254fd31b3  push rsi
00007f0254fd31b4  push r8
00007f0254fd31b6  push r9
00007f0254fd31b8  push r10
00007f0254fd31ba  push r11
00007f0254fd31bc  sub rsp, 0xF0
00007f0254fd31c3  vmovaps [rsp], xmm0
00007f0254fd31c8  vmovaps [rsp+0x10], xmm1
00007f0254fd31ce  vmovaps [rsp+0x20], xmm2
00007f0254fd31d4  vmovaps [rsp+0x30], xmm3
00007f0254fd31da  vmovaps [rsp+0x40], xmm4
00007f0254fd31e0  vmovaps [rsp+0x50], xmm5
00007f0254fd31e6  vmovaps [rsp+0x60], xmm6
00007f0254fd31ec  vmovaps [rsp+0x70], xmm7
00007f0254fd31f2  vmovaps [rsp+0x80], xmm8
00007f0254fd31fb  vmovaps [rsp+0x90], xmm9
00007f0254fd3204  vmovaps [rsp+0xA0], xmm10
00007f0254fd320d  vmovaps [rsp+0xB0], xmm12
00007f0254fd3216  vmovaps [rsp+0xC0], xmm13
00007f0254fd321f  vmovaps [rsp+0xD0], xmm14
00007f0254fd3228  vmovaps [rsp+0xE0], xmm15
00007f0254fd3231  sub rsp, 0x30
00007f0254fd3235  movaps [rsp], xmm11
00007f0254fd323a  movaps [rsp+0x10], xmm2
00007f0254fd323f  movaps [rsp+0x20], xmm12
00007f0254fd3245  lea rdi, [rsp]
00007f0254fd3249  mov esi, 0x00
00007f0254fd324e  mov rax, 0x55DD1360A530
00007f0254fd3258  call rax
00007f0254fd325a  movaps xmm11, [rsp]
00007f0254fd325f  add rsp, 0x30
00007f0254fd3263  vmovaps xmm0, [rsp]
00007f0254fd3268  vmovaps xmm1, [rsp+0x10]
00007f0254fd326e  vmovaps xmm2, [rsp+0x20]
00007f0254fd3274  vmovaps xmm3, [rsp+0x30]
00007f0254fd327a  vmovaps xmm4, [rsp+0x40]
00007f0254fd3280  vmovaps xmm5, [rsp+0x50]
00007f0254fd3286  vmovaps xmm6, [rsp+0x60]
00007f0254fd328c  vmovaps xmm7, [rsp+0x70]
00007f0254fd3292  vmovaps xmm8, [rsp+0x80]
00007f0254fd329b  vmovaps xmm9, [rsp+0x90]
00007f0254fd32a4  vmovaps xmm10, [rsp+0xA0]
00007f0254fd32ad  vmovaps xmm12, [rsp+0xB0]
00007f0254fd32b6  vmovaps xmm13, [rsp+0xC0]
00007f0254fd32bf  vmovaps xmm14, [rsp+0xD0]
00007f0254fd32c8  vmovaps xmm15, [rsp+0xE0]
00007f0254fd32d1  add rsp, 0xF0
00007f0254fd32d8  pop r11
00007f0254fd32da  pop r10
00007f0254fd32dc  pop r9
00007f0254fd32de  pop r8
00007f0254fd32e0  pop rsi
00007f0254fd32e1  pop rdi
00007f0254fd32e2  pop rdx
00007f0254fd32e3  pop rcx
00007f0254fd32e4  pop rax
00007f0254fd32e5  add rsp, 0x08
00007f0254fd32e9  jmp 0x00007F0254FCFEB8
00007f0254fd32ee  sub rsp, 0x08
00007f0254fd32f2  push rax
00007f0254fd32f3  push rcx
00007f0254fd32f4  push rdx
00007f0254fd32f5  push rdi
00007f0254fd32f6  push rsi
00007f0254fd32f7  push r8
00007f0254fd32f9  push r9
00007f0254fd32fb  push r10
00007f0254fd32fd  push r11
00007f0254fd32ff  sub rsp, 0xF0
00007f0254fd3306  vmovaps [rsp], xmm0
00007f0254fd330b  vmovaps [rsp+0x10], xmm2
00007f0254fd3311  vmovaps [rsp+0x20], xmm3
00007f0254fd3317  vmovaps [rsp+0x30], xmm4
00007f0254fd331d  vmovaps [rsp+0x40], xmm5
00007f0254fd3323  vmovaps [rsp+0x50], xmm6
00007f0254fd3329  vmovaps [rsp+0x60], xmm7
00007f0254fd332f  vmovaps [rsp+0x70], xmm8
00007f0254fd3335  vmovaps [rsp+0x80], xmm9
00007f0254fd333e  vmovaps [rsp+0x90], xmm10
00007f0254fd3347  vmovaps [rsp+0xA0], xmm11
00007f0254fd3350  vmovaps [rsp+0xB0], xmm12
00007f0254fd3359  vmovaps [rsp+0xC0], xmm13
00007f0254fd3362  vmovaps [rsp+0xD0], xmm14
00007f0254fd336b  vmovaps [rsp+0xE0], xmm15
00007f0254fd3374  sub rsp, 0x30
00007f0254fd3378  movaps [rsp], xmm1
00007f0254fd337c  movaps [rsp+0x10], xmm14
00007f0254fd3382  movaps [rsp+0x20], xmm6
00007f0254fd3387  lea rdi, [rsp]
00007f0254fd338b  mov esi, 0x00
00007f0254fd3390  mov rax, 0x55DD1360A530
00007f0254fd339a  call rax
00007f0254fd339c  movaps xmm1, [rsp]
00007f0254fd33a0  add rsp, 0x30
00007f0254fd33a4  vmovaps xmm0, [rsp]
00007f0254fd33a9  vmovaps xmm2, [rsp+0x10]
00007f0254fd33af  vmovaps xmm3, [rsp+0x20]
00007f0254fd33b5  vmovaps xmm4, [rsp+0x30]
00007f0254fd33bb  vmovaps xmm5, [rsp+0x40]
00007f0254fd33c1  vmovaps xmm6, [rsp+0x50]
00007f0254fd33c7  vmovaps xmm7, [rsp+0x60]
00007f0254fd33cd  vmovaps xmm8, [rsp+0x70]
00007f0254fd33d3  vmovaps xmm9, [rsp+0x80]
00007f0254fd33dc  vmovaps xmm10, [rsp+0x90]
00007f0254fd33e5  vmovaps xmm11, [rsp+0xA0]
00007f0254fd33ee  vmovaps xmm12, [rsp+0xB0]
00007f0254fd33f7  vmovaps xmm13, [rsp+0xC0]
00007f0254fd3400  vmovaps xmm14, [rsp+0xD0]
00007f0254fd3409  vmovaps xmm15, [rsp+0xE0]
00007f0254fd3412  add rsp, 0xF0
00007f0254fd3419  pop r11
00007f0254fd341b  pop r10
00007f0254fd341d  pop r9
00007f0254fd341f  pop r8
00007f0254fd3421  pop rsi
00007f0254fd3422  pop rdi
00007f0254fd3423  pop rdx
00007f0254fd3424  pop rcx
00007f0254fd3425  pop rax
00007f0254fd3426  add rsp, 0x08
00007f0254fd342a  jmp 0x00007F0254FCFED1
00007f0254fd342f  sub rsp, 0x08
00007f0254fd3433  push rax
00007f0254fd3434  push rcx
00007f0254fd3435  push rdx
00007f0254fd3436  push rdi
00007f0254fd3437  push rsi
00007f0254fd3438  push r8
00007f0254fd343a  push r9
00007f0254fd343c  push r10
00007f0254fd343e  push r11
00007f0254fd3440  sub rsp, 0xF0
00007f0254fd3447  vmovaps [rsp], xmm0
00007f0254fd344c  vmovaps [rsp+0x10], xmm1
00007f0254fd3452  vmovaps [rsp+0x20], xmm2
00007f0254fd3458  vmovaps [rsp+0x30], xmm3
00007f0254fd345e  vmovaps [rsp+0x40], xmm4
00007f0254fd3464  vmovaps [rsp+0x50], xmm5
00007f0254fd346a  vmovaps [rsp+0x60], xmm6
00007f0254fd3470  vmovaps [rsp+0x70], xmm7
00007f0254fd3476  vmovaps [rsp+0x80], xmm8
00007f0254fd347f  vmovaps [rsp+0x90], xmm9
00007f0254fd3488  vmovaps [rsp+0xA0], xmm10
00007f0254fd3491  vmovaps [rsp+0xB0], xmm11
00007f0254fd349a  vmovaps [rsp+0xC0], xmm12
00007f0254fd34a3  vmovaps [rsp+0xD0], xmm13
00007f0254fd34ac  vmovaps [rsp+0xE0], xmm15
00007f0254fd34b5  sub rsp, 0x30
00007f0254fd34b9  movaps [rsp], xmm14
00007f0254fd34be  movaps [rsp+0x10], xmm12
00007f0254fd34c4  movaps [rsp+0x20], xmm5
00007f0254fd34c9  lea rdi, [rsp]
00007f0254fd34cd  mov esi, 0x00
00007f0254fd34d2  mov rax, 0x55DD1360A530
00007f0254fd34dc  call rax
00007f0254fd34de  movaps xmm14, [rsp]
00007f0254fd34e3  add rsp, 0x30
00007f0254fd34e7  vmovaps xmm0, [rsp]
00007f0254fd34ec  vmovaps xmm1, [rsp+0x10]
00007f0254fd34f2  vmovaps xmm2, [rsp+0x20]
00007f0254fd34f8  vmovaps xmm3, [rsp+0x30]
00007f0254fd34fe  vmovaps xmm4, [rsp+0x40]
00007f0254fd3504  vmovaps xmm5, [rsp+0x50]
00007f0254fd350a  vmovaps xmm6, [rsp+0x60]
00007f0254fd3510  vmovaps xmm7, [rsp+0x70]
00007f0254fd3516  vmovaps xmm8, [rsp+0x80]
00007f0254fd351f  vmovaps xmm9, [rsp+0x90]
00007f0254fd3528  vmovaps xmm10, [rsp+0xA0]
00007f0254fd3531  vmovaps xmm11, [rsp+0xB0]
00007f0254fd353a  vmovaps xmm12, [rsp+0xC0]
00007f0254fd3543  vmovaps xmm13, [rsp+0xD0]
00007f0254fd354c  vmovaps xmm15, [rsp+0xE0]
00007f0254fd3555  add rsp, 0xF0
00007f0254fd355c  pop r11
00007f0254fd355e  pop r10
00007f0254fd3560  pop r9
00007f0254fd3562  pop r8
00007f0254fd3564  pop rsi
00007f0254fd3565  pop rdi
00007f0254fd3566  pop rdx
00007f0254fd3567  pop rcx
00007f0254fd3568  pop rax
00007f0254fd3569  add rsp, 0x08
00007f0254fd356d  jmp 0x00007F0254FCFEF1
00007f0254fd3572  sub rsp, 0x08
00007f0254fd3576  push rax
00007f0254fd3577  push rcx
00007f0254fd3578  push rdx
00007f0254fd3579  push rdi
00007f0254fd357a  push rsi
00007f0254fd357b  push r8
00007f0254fd357d  push r9
00007f0254fd357f  push r10
00007f0254fd3581  push r11
00007f0254fd3583  sub rsp, 0xF0
00007f0254fd358a  vmovaps [rsp], xmm0
00007f0254fd358f  vmovaps [rsp+0x10], xmm1
00007f0254fd3595  vmovaps [rsp+0x20], xmm2
00007f0254fd359b  vmovaps [rsp+0x30], xmm3
00007f0254fd35a1  vmovaps [rsp+0x40], xmm4
00007f0254fd35a7  vmovaps [rsp+0x50], xmm5
00007f0254fd35ad  vmovaps [rsp+0x60], xmm7
00007f0254fd35b3  vmovaps [rsp+0x70], xmm8
00007f0254fd35b9  vmovaps [rsp+0x80], xmm9
00007f0254fd35c2  vmovaps [rsp+0x90], xmm10
00007f0254fd35cb  vmovaps [rsp+0xA0], xmm11
00007f0254fd35d4  vmovaps [rsp+0xB0], xmm12
00007f0254fd35dd  vmovaps [rsp+0xC0], xmm13
00007f0254fd35e6  vmovaps [rsp+0xD0], xmm14
00007f0254fd35ef  vmovaps [rsp+0xE0], xmm15
00007f0254fd35f8  sub rsp, 0x30
00007f0254fd35fc  movaps [rsp], xmm6
00007f0254fd3600  movaps [rsp+0x10], xmm9
00007f0254fd3606  movaps [rsp+0x20], xmm12
00007f0254fd360c  lea rdi, [rsp]
00007f0254fd3610  mov esi, 0x00
00007f0254fd3615  mov rax, 0x55DD1360A530
00007f0254fd361f  call rax
00007f0254fd3621  movaps xmm6, [rsp]
00007f0254fd3625  add rsp, 0x30
00007f0254fd3629  vmovaps xmm0, [rsp]
00007f0254fd362e  vmovaps xmm1, [rsp+0x10]
00007f0254fd3634  vmovaps xmm2, [rsp+0x20]
00007f0254fd363a  vmovaps xmm3, [rsp+0x30]
00007f0254fd3640  vmovaps xmm4, [rsp+0x40]
00007f0254fd3646  vmovaps xmm5, [rsp+0x50]
00007f0254fd364c  vmovaps xmm7, [rsp+0x60]
00007f0254fd3652  vmovaps xmm8, [rsp+0x70]
00007f0254fd3658  vmovaps xmm9, [rsp+0x80]
00007f0254fd3661  vmovaps xmm10, [rsp+0x90]
00007f0254fd366a  vmovaps xmm11, [rsp+0xA0]
00007f0254fd3673  vmovaps xmm12, [rsp+0xB0]
00007f0254fd367c  vmovaps xmm13, [rsp+0xC0]
00007f0254fd3685  vmovaps xmm14, [rsp+0xD0]
00007f0254fd368e  vmovaps xmm15, [rsp+0xE0]
00007f0254fd3697  add rsp, 0xF0
00007f0254fd369e  pop r11
00007f0254fd36a0  pop r10
00007f0254fd36a2  pop r9
00007f0254fd36a4  pop r8
00007f0254fd36a6  pop rsi
00007f0254fd36a7  pop rdi
00007f0254fd36a8  pop rdx
00007f0254fd36a9  pop rcx
00007f0254fd36aa  pop rax
00007f0254fd36ab  add rsp, 0x08
00007f0254fd36af  jmp 0x00007F0254FCFF19
00007f0254fd36b4  sub rsp, 0x08
00007f0254fd36b8  push rax
00007f0254fd36b9  push rcx
00007f0254fd36ba  push rdx
00007f0254fd36bb  push rdi
00007f0254fd36bc  push rsi
00007f0254fd36bd  push r8
00007f0254fd36bf  push r9
00007f0254fd36c1  push r10
00007f0254fd36c3  push r11
00007f0254fd36c5  sub rsp, 0xF0
00007f0254fd36cc  vmovaps [rsp], xmm0
00007f0254fd36d1  vmovaps [rsp+0x10], xmm1
00007f0254fd36d7  vmovaps [rsp+0x20], xmm2
00007f0254fd36dd  vmovaps [rsp+0x30], xmm3
00007f0254fd36e3  vmovaps [rsp+0x40], xmm4
00007f0254fd36e9  vmovaps [rsp+0x50], xmm5
00007f0254fd36ef  vmovaps [rsp+0x60], xmm6
00007f0254fd36f5  vmovaps [rsp+0x70], xmm7
00007f0254fd36fb  vmovaps [rsp+0x80], xmm8
00007f0254fd3704  vmovaps [rsp+0x90], xmm9
00007f0254fd370d  vmovaps [rsp+0xA0], xmm10
00007f0254fd3716  vmovaps [rsp+0xB0], xmm11
00007f0254fd371f  vmovaps [rsp+0xC0], xmm13
00007f0254fd3728  vmovaps [rsp+0xD0], xmm14
00007f0254fd3731  vmovaps [rsp+0xE0], xmm15
00007f0254fd373a  sub rsp, 0x30
00007f0254fd373e  movaps [rsp], xmm12
00007f0254fd3743  movaps [rsp+0x10], xmm15
00007f0254fd3749  movaps [rsp+0x20], xmm13
00007f0254fd374f  lea rdi, [rsp]
00007f0254fd3753  mov esi, 0x00
00007f0254fd3758  mov rax, 0x55DD1360A530
00007f0254fd3762  call rax
00007f0254fd3764  movaps xmm12, [rsp]
00007f0254fd3769  add rsp, 0x30
00007f0254fd376d  vmovaps xmm0, [rsp]
00007f0254fd3772  vmovaps xmm1, [rsp+0x10]
00007f0254fd3778  vmovaps xmm2, [rsp+0x20]
00007f0254fd377e  vmovaps xmm3, [rsp+0x30]
00007f0254fd3784  vmovaps xmm4, [rsp+0x40]
00007f0254fd378a  vmovaps xmm5, [rsp+0x50]
00007f0254fd3790  vmovaps xmm6, [rsp+0x60]
00007f0254fd3796  vmovaps xmm7, [rsp+0x70]
00007f0254fd379c  vmovaps xmm8, [rsp+0x80]
00007f0254fd37a5  vmovaps xmm9, [rsp+0x90]
00007f0254fd37ae  vmovaps xmm10, [rsp+0xA0]
00007f0254fd37b7  vmovaps xmm11, [rsp+0xB0]
00007f0254fd37c0  vmovaps xmm13, [rsp+0xC0]
00007f0254fd37c9  vmovaps xmm14, [rsp+0xD0]
00007f0254fd37d2  vmovaps xmm15, [rsp+0xE0]
00007f0254fd37db  add rsp, 0xF0
00007f0254fd37e2  pop r11
00007f0254fd37e4  pop r10
00007f0254fd37e6  pop r9
00007f0254fd37e8  pop r8
00007f0254fd37ea  pop rsi
00007f0254fd37eb  pop rdi
00007f0254fd37ec  pop rdx
00007f0254fd37ed  pop rcx
00007f0254fd37ee  pop rax
00007f0254fd37ef  add rsp, 0x08
00007f0254fd37f3  jmp 0x00007F0254FCFF34
00007f0254fd37f8  sub rsp, 0x08
00007f0254fd37fc  push rax
00007f0254fd37fd  push rcx
00007f0254fd37fe  push rdx
00007f0254fd37ff  push rdi
00007f0254fd3800  push rsi
00007f0254fd3801  push r8
00007f0254fd3803  push r9
00007f0254fd3805  push r10
00007f0254fd3807  push r11
00007f0254fd3809  sub rsp, 0xF0
00007f0254fd3810  vmovaps [rsp], xmm0
00007f0254fd3815  vmovaps [rsp+0x10], xmm1
00007f0254fd381b  vmovaps [rsp+0x20], xmm2
00007f0254fd3821  vmovaps [rsp+0x30], xmm3
00007f0254fd3827  vmovaps [rsp+0x40], xmm4
00007f0254fd382d  vmovaps [rsp+0x50], xmm5
00007f0254fd3833  vmovaps [rsp+0x60], xmm6
00007f0254fd3839  vmovaps [rsp+0x70], xmm7
00007f0254fd383f  vmovaps [rsp+0x80], xmm8
00007f0254fd3848  vmovaps [rsp+0x90], xmm9
00007f0254fd3851  vmovaps [rsp+0xA0], xmm10
00007f0254fd385a  vmovaps [rsp+0xB0], xmm11
00007f0254fd3863  vmovaps [rsp+0xC0], xmm12
00007f0254fd386c  vmovaps [rsp+0xD0], xmm13
00007f0254fd3875  vmovaps [rsp+0xE0], xmm14
00007f0254fd387e  sub rsp, 0x30
00007f0254fd3882  movaps [rsp], xmm15
00007f0254fd3887  movaps [rsp+0x10], xmm13
00007f0254fd388d  movaps [rsp+0x20], xmm10
00007f0254fd3893  lea rdi, [rsp]
00007f0254fd3897  mov esi, 0x00
00007f0254fd389c  mov rax, 0x55DD1360A530
00007f0254fd38a6  call rax
00007f0254fd38a8  movaps xmm15, [rsp]
00007f0254fd38ad  add rsp, 0x30
00007f0254fd38b1  vmovaps xmm0, [rsp]
00007f0254fd38b6  vmovaps xmm1, [rsp+0x10]
00007f0254fd38bc  vmovaps xmm2, [rsp+0x20]
00007f0254fd38c2  vmovaps xmm3, [rsp+0x30]
00007f0254fd38c8  vmovaps xmm4, [rsp+0x40]
00007f0254fd38ce  vmovaps xmm5, [rsp+0x50]
00007f0254fd38d4  vmovaps xmm6, [rsp+0x60]
00007f0254fd38da  vmovaps xmm7, [rsp+0x70]
00007f0254fd38e0  vmovaps xmm8, [rsp+0x80]
00007f0254fd38e9  vmovaps xmm9, [rsp+0x90]
00007f0254fd38f2  vmovaps xmm10, [rsp+0xA0]
00007f0254fd38fb  vmovaps xmm11, [rsp+0xB0]
00007f0254fd3904  vmovaps xmm12, [rsp+0xC0]
00007f0254fd390d  vmovaps xmm13, [rsp+0xD0]
00007f0254fd3916  vmovaps xmm14, [rsp+0xE0]
00007f0254fd391f  add rsp, 0xF0
00007f0254fd3926  pop r11
00007f0254fd3928  pop r10
00007f0254fd392a  pop r9
00007f0254fd392c  pop r8
00007f0254fd392e  pop rsi
00007f0254fd392f  pop rdi
00007f0254fd3930  pop rdx
00007f0254fd3931  pop rcx
00007f0254fd3932  pop rax
00007f0254fd3933  add rsp, 0x08
00007f0254fd3937  jmp 0x00007F0254FCFF55
00007f0254fd393c  call 0x00007F0254E0C260
00007f0254fd3941  jmp 0x00007F0254FCFFB0
00007f0254fd3946  sub rsp, 0x08
00007f0254fd394a  push rax
00007f0254fd394b  push rcx
00007f0254fd394c  push rdx
00007f0254fd394d  push rdi
00007f0254fd394e  push rsi
00007f0254fd394f  push r8
00007f0254fd3951  push r9
00007f0254fd3953  push r10
00007f0254fd3955  push r11
00007f0254fd3957  sub rsp, 0xF0
00007f0254fd395e  vmovaps [rsp], xmm0
00007f0254fd3963  vmovaps [rsp+0x10], xmm1
00007f0254fd3969  vmovaps [rsp+0x20], xmm2
00007f0254fd396f  vmovaps [rsp+0x30], xmm3
00007f0254fd3975  vmovaps [rsp+0x40], xmm4
00007f0254fd397b  vmovaps [rsp+0x50], xmm5
00007f0254fd3981  vmovaps [rsp+0x60], xmm6
00007f0254fd3987  vmovaps [rsp+0x70], xmm7
00007f0254fd398d  vmovaps [rsp+0x80], xmm8
00007f0254fd3996  vmovaps [rsp+0x90], xmm10
00007f0254fd399f  vmovaps [rsp+0xA0], xmm11
00007f0254fd39a8  vmovaps [rsp+0xB0], xmm12
00007f0254fd39b1  vmovaps [rsp+0xC0], xmm13
00007f0254fd39ba  vmovaps [rsp+0xD0], xmm14
00007f0254fd39c3  vmovaps [rsp+0xE0], xmm15
00007f0254fd39cc  sub rsp, 0x30
00007f0254fd39d0  movaps [rsp], xmm9
00007f0254fd39d5  movaps [rsp+0x10], xmm8
00007f0254fd39db  movaps [rsp+0x20], xmm10
00007f0254fd39e1  lea rdi, [rsp]
00007f0254fd39e5  mov esi, 0x00
00007f0254fd39ea  mov rax, 0x55DD1360A530
00007f0254fd39f4  call rax
00007f0254fd39f6  movaps xmm9, [rsp]
00007f0254fd39fb  add rsp, 0x30
00007f0254fd39ff  vmovaps xmm0, [rsp]
00007f0254fd3a04  vmovaps xmm1, [rsp+0x10]
00007f0254fd3a0a  vmovaps xmm2, [rsp+0x20]
00007f0254fd3a10  vmovaps xmm3, [rsp+0x30]
00007f0254fd3a16  vmovaps xmm4, [rsp+0x40]
00007f0254fd3a1c  vmovaps xmm5, [rsp+0x50]
00007f0254fd3a22  vmovaps xmm6, [rsp+0x60]
00007f0254fd3a28  vmovaps xmm7, [rsp+0x70]
00007f0254fd3a2e  vmovaps xmm8, [rsp+0x80]
00007f0254fd3a37  vmovaps xmm10, [rsp+0x90]
00007f0254fd3a40  vmovaps xmm11, [rsp+0xA0]
00007f0254fd3a49  vmovaps xmm12, [rsp+0xB0]
00007f0254fd3a52  vmovaps xmm13, [rsp+0xC0]
00007f0254fd3a5b  vmovaps xmm14, [rsp+0xD0]
00007f0254fd3a64  vmovaps xmm15, [rsp+0xE0]
00007f0254fd3a6d  add rsp, 0xF0
00007f0254fd3a74  pop r11
00007f0254fd3a76  pop r10
00007f0254fd3a78  pop r9
00007f0254fd3a7a  pop r8
00007f0254fd3a7c  pop rsi
00007f0254fd3a7d  pop rdi
00007f0254fd3a7e  pop rdx
00007f0254fd3a7f  pop rcx
00007f0254fd3a80  pop rax
00007f0254fd3a81  add rsp, 0x08
00007f0254fd3a85  jmp 0x00007F0254FCFFE1
00007f0254fd3a8a  sub rsp, 0x08
00007f0254fd3a8e  push rax
00007f0254fd3a8f  push rcx
00007f0254fd3a90  push rdx
00007f0254fd3a91  push rdi
00007f0254fd3a92  push rsi
00007f0254fd3a93  push r8
00007f0254fd3a95  push r9
00007f0254fd3a97  push r10
00007f0254fd3a99  push r11
00007f0254fd3a9b  sub rsp, 0xF0
00007f0254fd3aa2  vmovaps [rsp], xmm0
00007f0254fd3aa7  vmovaps [rsp+0x10], xmm1
00007f0254fd3aad  vmovaps [rsp+0x20], xmm2
00007f0254fd3ab3  vmovaps [rsp+0x30], xmm3
00007f0254fd3ab9  vmovaps [rsp+0x40], xmm4
00007f0254fd3abf  vmovaps [rsp+0x50], xmm5
00007f0254fd3ac5  vmovaps [rsp+0x60], xmm6
00007f0254fd3acb  vmovaps [rsp+0x70], xmm7
00007f0254fd3ad1  vmovaps [rsp+0x80], xmm8
00007f0254fd3ada  vmovaps [rsp+0x90], xmm9
00007f0254fd3ae3  vmovaps [rsp+0xA0], xmm11
00007f0254fd3aec  vmovaps [rsp+0xB0], xmm12
00007f0254fd3af5  vmovaps [rsp+0xC0], xmm13
00007f0254fd3afe  vmovaps [rsp+0xD0], xmm14
00007f0254fd3b07  vmovaps [rsp+0xE0], xmm15
00007f0254fd3b10  sub rsp, 0x30
00007f0254fd3b14  movaps [rsp], xmm10
00007f0254fd3b19  movaps [rsp+0x10], xmm1
00007f0254fd3b1e  movaps [rsp+0x20], xmm11
00007f0254fd3b24  lea rdi, [rsp]
00007f0254fd3b28  mov esi, 0x00
00007f0254fd3b2d  mov rax, 0x55DD1360A530
00007f0254fd3b37  call rax
00007f0254fd3b39  movaps xmm10, [rsp]
00007f0254fd3b3e  add rsp, 0x30
00007f0254fd3b42  vmovaps xmm0, [rsp]
00007f0254fd3b47  vmovaps xmm1, [rsp+0x10]
00007f0254fd3b4d  vmovaps xmm2, [rsp+0x20]
00007f0254fd3b53  vmovaps xmm3, [rsp+0x30]
00007f0254fd3b59  vmovaps xmm4, [rsp+0x40]
00007f0254fd3b5f  vmovaps xmm5, [rsp+0x50]
00007f0254fd3b65  vmovaps xmm6, [rsp+0x60]
00007f0254fd3b6b  vmovaps xmm7, [rsp+0x70]
00007f0254fd3b71  vmovaps xmm8, [rsp+0x80]
00007f0254fd3b7a  vmovaps xmm9, [rsp+0x90]
00007f0254fd3b83  vmovaps xmm11, [rsp+0xA0]
00007f0254fd3b8c  vmovaps xmm12, [rsp+0xB0]
00007f0254fd3b95  vmovaps xmm13, [rsp+0xC0]
00007f0254fd3b9e  vmovaps xmm14, [rsp+0xD0]
00007f0254fd3ba7  vmovaps xmm15, [rsp+0xE0]
00007f0254fd3bb0  add rsp, 0xF0
00007f0254fd3bb7  pop r11
00007f0254fd3bb9  pop r10
00007f0254fd3bbb  pop r9
00007f0254fd3bbd  pop r8
00007f0254fd3bbf  pop rsi
00007f0254fd3bc0  pop rdi
00007f0254fd3bc1  pop rdx
00007f0254fd3bc2  pop rcx
00007f0254fd3bc3  pop rax
00007f0254fd3bc4  add rsp, 0x08
00007f0254fd3bc8  jmp 0x00007F0254FCFFFC
00007f0254fd3bcd  sub rsp, 0x08
00007f0254fd3bd1  push rax
00007f0254fd3bd2  push rcx
00007f0254fd3bd3  push rdx
00007f0254fd3bd4  push rdi
00007f0254fd3bd5  push rsi
00007f0254fd3bd6  push r8
00007f0254fd3bd8  push r9
00007f0254fd3bda  push r10
00007f0254fd3bdc  push r11
00007f0254fd3bde  sub rsp, 0xF0
00007f0254fd3be5  vmovaps [rsp], xmm0
00007f0254fd3bea  vmovaps [rsp+0x10], xmm2
00007f0254fd3bf0  vmovaps [rsp+0x20], xmm3
00007f0254fd3bf6  vmovaps [rsp+0x30], xmm4
00007f0254fd3bfc  vmovaps [rsp+0x40], xmm5
00007f0254fd3c02  vmovaps [rsp+0x50], xmm6
00007f0254fd3c08  vmovaps [rsp+0x60], xmm7
00007f0254fd3c0e  vmovaps [rsp+0x70], xmm8
00007f0254fd3c14  vmovaps [rsp+0x80], xmm9
00007f0254fd3c1d  vmovaps [rsp+0x90], xmm10
00007f0254fd3c26  vmovaps [rsp+0xA0], xmm11
00007f0254fd3c2f  vmovaps [rsp+0xB0], xmm12
00007f0254fd3c38  vmovaps [rsp+0xC0], xmm13
00007f0254fd3c41  vmovaps [rsp+0xD0], xmm14
00007f0254fd3c4a  vmovaps [rsp+0xE0], xmm15
00007f0254fd3c53  sub rsp, 0x30
00007f0254fd3c57  movaps [rsp], xmm1
00007f0254fd3c5b  movaps [rsp+0x10], xmm14
00007f0254fd3c61  movaps [rsp+0x20], xmm6
00007f0254fd3c66  lea rdi, [rsp]
00007f0254fd3c6a  mov esi, 0x00
00007f0254fd3c6f  mov rax, 0x55DD1360A530
00007f0254fd3c79  call rax
00007f0254fd3c7b  movaps xmm1, [rsp]
00007f0254fd3c7f  add rsp, 0x30
00007f0254fd3c83  vmovaps xmm0, [rsp]
00007f0254fd3c88  vmovaps xmm2, [rsp+0x10]
00007f0254fd3c8e  vmovaps xmm3, [rsp+0x20]
00007f0254fd3c94  vmovaps xmm4, [rsp+0x30]
00007f0254fd3c9a  vmovaps xmm5, [rsp+0x40]
00007f0254fd3ca0  vmovaps xmm6, [rsp+0x50]
00007f0254fd3ca6  vmovaps xmm7, [rsp+0x60]
00007f0254fd3cac  vmovaps xmm8, [rsp+0x70]
00007f0254fd3cb2  vmovaps xmm9, [rsp+0x80]
00007f0254fd3cbb  vmovaps xmm10, [rsp+0x90]
00007f0254fd3cc4  vmovaps xmm11, [rsp+0xA0]
00007f0254fd3ccd  vmovaps xmm12, [rsp+0xB0]
00007f0254fd3cd6  vmovaps xmm13, [rsp+0xC0]
00007f0254fd3cdf  vmovaps xmm14, [rsp+0xD0]
00007f0254fd3ce8  vmovaps xmm15, [rsp+0xE0]
00007f0254fd3cf1  add rsp, 0xF0
00007f0254fd3cf8  pop r11
00007f0254fd3cfa  pop r10
00007f0254fd3cfc  pop r9
00007f0254fd3cfe  pop r8
00007f0254fd3d00  pop rsi
00007f0254fd3d01  pop rdi
00007f0254fd3d02  pop rdx
00007f0254fd3d03  pop rcx
00007f0254fd3d04  pop rax
00007f0254fd3d05  add rsp, 0x08
00007f0254fd3d09  jmp 0x00007F0254FD0015
00007f0254fd3d0e  sub rsp, 0x08
00007f0254fd3d12  push rax
00007f0254fd3d13  push rcx
00007f0254fd3d14  push rdx
00007f0254fd3d15  push rdi
00007f0254fd3d16  push rsi
00007f0254fd3d17  push r8
00007f0254fd3d19  push r9
00007f0254fd3d1b  push r10
00007f0254fd3d1d  push r11
00007f0254fd3d1f  sub rsp, 0xF0
00007f0254fd3d26  vmovaps [rsp], xmm0
00007f0254fd3d2b  vmovaps [rsp+0x10], xmm1
00007f0254fd3d31  vmovaps [rsp+0x20], xmm2
00007f0254fd3d37  vmovaps [rsp+0x30], xmm3
00007f0254fd3d3d  vmovaps [rsp+0x40], xmm4
00007f0254fd3d43  vmovaps [rsp+0x50], xmm5
00007f0254fd3d49  vmovaps [rsp+0x60], xmm6
00007f0254fd3d4f  vmovaps [rsp+0x70], xmm7
00007f0254fd3d55  vmovaps [rsp+0x80], xmm8
00007f0254fd3d5e  vmovaps [rsp+0x90], xmm9
00007f0254fd3d67  vmovaps [rsp+0xA0], xmm10
00007f0254fd3d70  vmovaps [rsp+0xB0], xmm12
00007f0254fd3d79  vmovaps [rsp+0xC0], xmm13
00007f0254fd3d82  vmovaps [rsp+0xD0], xmm14
00007f0254fd3d8b  vmovaps [rsp+0xE0], xmm15
00007f0254fd3d94  sub rsp, 0x30
00007f0254fd3d98  movaps [rsp], xmm11
00007f0254fd3d9d  movaps [rsp+0x10], xmm13
00007f0254fd3da3  movaps [rsp+0x20], xmm14
00007f0254fd3da9  lea rdi, [rsp]
00007f0254fd3dad  mov esi, 0x00
00007f0254fd3db2  mov rax, 0x55DD1360A530
00007f0254fd3dbc  call rax
00007f0254fd3dbe  movaps xmm11, [rsp]
00007f0254fd3dc3  add rsp, 0x30
00007f0254fd3dc7  vmovaps xmm0, [rsp]
00007f0254fd3dcc  vmovaps xmm1, [rsp+0x10]
00007f0254fd3dd2  vmovaps xmm2, [rsp+0x20]
00007f0254fd3dd8  vmovaps xmm3, [rsp+0x30]
00007f0254fd3dde  vmovaps xmm4, [rsp+0x40]
00007f0254fd3de4  vmovaps xmm5, [rsp+0x50]
00007f0254fd3dea  vmovaps xmm6, [rsp+0x60]
00007f0254fd3df0  vmovaps xmm7, [rsp+0x70]
00007f0254fd3df6  vmovaps xmm8, [rsp+0x80]
00007f0254fd3dff  vmovaps xmm9, [rsp+0x90]
00007f0254fd3e08  vmovaps xmm10, [rsp+0xA0]
00007f0254fd3e11  vmovaps xmm12, [rsp+0xB0]
00007f0254fd3e1a  vmovaps xmm13, [rsp+0xC0]
00007f0254fd3e23  vmovaps xmm14, [rsp+0xD0]
00007f0254fd3e2c  vmovaps xmm15, [rsp+0xE0]
00007f0254fd3e35  add rsp, 0xF0
00007f0254fd3e3c  pop r11
00007f0254fd3e3e  pop r10
00007f0254fd3e40  pop r9
00007f0254fd3e42  pop r8
00007f0254fd3e44  pop rsi
00007f0254fd3e45  pop rdi
00007f0254fd3e46  pop rdx
00007f0254fd3e47  pop rcx
00007f0254fd3e48  pop rax
00007f0254fd3e49  add rsp, 0x08
00007f0254fd3e4d  jmp 0x00007F0254FD003F
00007f0254fd3e52  sub rsp, 0x08
00007f0254fd3e56  push rax
00007f0254fd3e57  push rcx
00007f0254fd3e58  push rdx
00007f0254fd3e59  push rdi
00007f0254fd3e5a  push rsi
00007f0254fd3e5b  push r8
00007f0254fd3e5d  push r9
00007f0254fd3e5f  push r10
00007f0254fd3e61  push r11
00007f0254fd3e63  sub rsp, 0xF0
00007f0254fd3e6a  vmovaps [rsp], xmm0
00007f0254fd3e6f  vmovaps [rsp+0x10], xmm1
00007f0254fd3e75  vmovaps [rsp+0x20], xmm2
00007f0254fd3e7b  vmovaps [rsp+0x30], xmm3
00007f0254fd3e81  vmovaps [rsp+0x40], xmm4
00007f0254fd3e87  vmovaps [rsp+0x50], xmm5
00007f0254fd3e8d  vmovaps [rsp+0x60], xmm6
00007f0254fd3e93  vmovaps [rsp+0x70], xmm7
00007f0254fd3e99  vmovaps [rsp+0x80], xmm8
00007f0254fd3ea2  vmovaps [rsp+0x90], xmm9
00007f0254fd3eab  vmovaps [rsp+0xA0], xmm10
00007f0254fd3eb4  vmovaps [rsp+0xB0], xmm11
00007f0254fd3ebd  vmovaps [rsp+0xC0], xmm12
00007f0254fd3ec6  vmovaps [rsp+0xD0], xmm14
00007f0254fd3ecf  vmovaps [rsp+0xE0], xmm15
00007f0254fd3ed8  sub rsp, 0x30
00007f0254fd3edc  movaps [rsp], xmm13
00007f0254fd3ee1  movaps [rsp+0x10], xmm8
00007f0254fd3ee7  movaps [rsp+0x20], xmm14
00007f0254fd3eed  lea rdi, [rsp]
00007f0254fd3ef1  mov esi, 0x00
00007f0254fd3ef6  mov rax, 0x55DD1360A530
00007f0254fd3f00  call rax
00007f0254fd3f02  movaps xmm13, [rsp]
00007f0254fd3f07  add rsp, 0x30
00007f0254fd3f0b  vmovaps xmm0, [rsp]
00007f0254fd3f10  vmovaps xmm1, [rsp+0x10]
00007f0254fd3f16  vmovaps xmm2, [rsp+0x20]
00007f0254fd3f1c  vmovaps xmm3, [rsp+0x30]
00007f0254fd3f22  vmovaps xmm4, [rsp+0x40]
00007f0254fd3f28  vmovaps xmm5, [rsp+0x50]
00007f0254fd3f2e  vmovaps xmm6, [rsp+0x60]
00007f0254fd3f34  vmovaps xmm7, [rsp+0x70]
00007f0254fd3f3a  vmovaps xmm8, [rsp+0x80]
00007f0254fd3f43  vmovaps xmm9, [rsp+0x90]
00007f0254fd3f4c  vmovaps xmm10, [rsp+0xA0]
00007f0254fd3f55  vmovaps xmm11, [rsp+0xB0]
00007f0254fd3f5e  vmovaps xmm12, [rsp+0xC0]
00007f0254fd3f67  vmovaps xmm14, [rsp+0xD0]
00007f0254fd3f70  vmovaps xmm15, [rsp+0xE0]
00007f0254fd3f79  add rsp, 0xF0
00007f0254fd3f80  pop r11
00007f0254fd3f82  pop r10
00007f0254fd3f84  pop r9
00007f0254fd3f86  pop r8
00007f0254fd3f88  pop rsi
00007f0254fd3f89  pop rdi
00007f0254fd3f8a  pop rdx
00007f0254fd3f8b  pop rcx
00007f0254fd3f8c  pop rax
00007f0254fd3f8d  add rsp, 0x08
00007f0254fd3f91  jmp 0x00007F0254FD006E
00007f0254fd3f96  sub rsp, 0x08
00007f0254fd3f9a  push rax
00007f0254fd3f9b  push rcx
00007f0254fd3f9c  push rdx
00007f0254fd3f9d  push rdi
00007f0254fd3f9e  push rsi
00007f0254fd3f9f  push r8
00007f0254fd3fa1  push r9
00007f0254fd3fa3  push r10
00007f0254fd3fa5  push r11
00007f0254fd3fa7  sub rsp, 0xF0
00007f0254fd3fae  vmovaps [rsp], xmm0
00007f0254fd3fb3  vmovaps [rsp+0x10], xmm1
00007f0254fd3fb9  vmovaps [rsp+0x20], xmm2
00007f0254fd3fbf  vmovaps [rsp+0x30], xmm3
00007f0254fd3fc5  vmovaps [rsp+0x40], xmm4
00007f0254fd3fcb  vmovaps [rsp+0x50], xmm5
00007f0254fd3fd1  vmovaps [rsp+0x60], xmm6
00007f0254fd3fd7  vmovaps [rsp+0x70], xmm7
00007f0254fd3fdd  vmovaps [rsp+0x80], xmm9
00007f0254fd3fe6  vmovaps [rsp+0x90], xmm10
00007f0254fd3fef  vmovaps [rsp+0xA0], xmm11
00007f0254fd3ff8  vmovaps [rsp+0xB0], xmm12
00007f0254fd4001  vmovaps [rsp+0xC0], xmm13
00007f0254fd400a  vmovaps [rsp+0xD0], xmm14
00007f0254fd4013  vmovaps [rsp+0xE0], xmm15
00007f0254fd401c  sub rsp, 0x30
00007f0254fd4020  movaps [rsp], xmm8
00007f0254fd4025  movaps [rsp+0x10], xmm7
00007f0254fd402a  movaps [rsp+0x20], xmm14
00007f0254fd4030  lea rdi, [rsp]
00007f0254fd4034  mov esi, 0x00
00007f0254fd4039  mov rax, 0x55DD1360A530
00007f0254fd4043  call rax
00007f0254fd4045  movaps xmm8, [rsp]
00007f0254fd404a  add rsp, 0x30
00007f0254fd404e  vmovaps xmm0, [rsp]
00007f0254fd4053  vmovaps xmm1, [rsp+0x10]
00007f0254fd4059  vmovaps xmm2, [rsp+0x20]
00007f0254fd405f  vmovaps xmm3, [rsp+0x30]
00007f0254fd4065  vmovaps xmm4, [rsp+0x40]
00007f0254fd406b  vmovaps xmm5, [rsp+0x50]
00007f0254fd4071  vmovaps xmm6, [rsp+0x60]
00007f0254fd4077  vmovaps xmm7, [rsp+0x70]
00007f0254fd407d  vmovaps xmm9, [rsp+0x80]
00007f0254fd4086  vmovaps xmm10, [rsp+0x90]
00007f0254fd408f  vmovaps xmm11, [rsp+0xA0]
00007f0254fd4098  vmovaps xmm12, [rsp+0xB0]
00007f0254fd40a1  vmovaps xmm13, [rsp+0xC0]
00007f0254fd40aa  vmovaps xmm14, [rsp+0xD0]
00007f0254fd40b3  vmovaps xmm15, [rsp+0xE0]
00007f0254fd40bc  add rsp, 0xF0
00007f0254fd40c3  pop r11
00007f0254fd40c5  pop r10
00007f0254fd40c7  pop r9
00007f0254fd40c9  pop r8
00007f0254fd40cb  pop rsi
00007f0254fd40cc  pop rdi
00007f0254fd40cd  pop rdx
00007f0254fd40ce  pop rcx
00007f0254fd40cf  pop rax
00007f0254fd40d0  add rsp, 0x08
00007f0254fd40d4  jmp 0x00007F0254FD0094
00007f0254fd40d9  sub rsp, 0x08
00007f0254fd40dd  push rax
00007f0254fd40de  push rcx
00007f0254fd40df  push rdx
00007f0254fd40e0  push rdi
00007f0254fd40e1  push rsi
00007f0254fd40e2  push r8
00007f0254fd40e4  push r9
00007f0254fd40e6  push r10
00007f0254fd40e8  push r11
00007f0254fd40ea  sub rsp, 0xF0
00007f0254fd40f1  vmovaps [rsp], xmm0
00007f0254fd40f6  vmovaps [rsp+0x10], xmm1
00007f0254fd40fc  vmovaps [rsp+0x20], xmm2
00007f0254fd4102  vmovaps [rsp+0x30], xmm3
00007f0254fd4108  vmovaps [rsp+0x40], xmm4
00007f0254fd410e  vmovaps [rsp+0x50], xmm5
00007f0254fd4114  vmovaps [rsp+0x60], xmm6
00007f0254fd411a  vmovaps [rsp+0x70], xmm7
00007f0254fd4120  vmovaps [rsp+0x80], xmm8
00007f0254fd4129  vmovaps [rsp+0x90], xmm9
00007f0254fd4132  vmovaps [rsp+0xA0], xmm10
00007f0254fd413b  vmovaps [rsp+0xB0], xmm11
00007f0254fd4144  vmovaps [rsp+0xC0], xmm12
00007f0254fd414d  vmovaps [rsp+0xD0], xmm13
00007f0254fd4156  vmovaps [rsp+0xE0], xmm15
00007f0254fd415f  sub rsp, 0x30
00007f0254fd4163  movaps [rsp], xmm14
00007f0254fd4168  movaps [rsp+0x10], xmm12
00007f0254fd416e  movaps [rsp+0x20], xmm9
00007f0254fd4174  lea rdi, [rsp]
00007f0254fd4178  mov esi, 0x00
00007f0254fd417d  mov rax, 0x55DD1360A530
00007f0254fd4187  call rax
00007f0254fd4189  movaps xmm14, [rsp]
00007f0254fd418e  add rsp, 0x30
00007f0254fd4192  vmovaps xmm0, [rsp]
00007f0254fd4197  vmovaps xmm1, [rsp+0x10]
00007f0254fd419d  vmovaps xmm2, [rsp+0x20]
00007f0254fd41a3  vmovaps xmm3, [rsp+0x30]
00007f0254fd41a9  vmovaps xmm4, [rsp+0x40]
00007f0254fd41af  vmovaps xmm5, [rsp+0x50]
00007f0254fd41b5  vmovaps xmm6, [rsp+0x60]
00007f0254fd41bb  vmovaps xmm7, [rsp+0x70]
00007f0254fd41c1  vmovaps xmm8, [rsp+0x80]
00007f0254fd41ca  vmovaps xmm9, [rsp+0x90]
00007f0254fd41d3  vmovaps xmm10, [rsp+0xA0]
00007f0254fd41dc  vmovaps xmm11, [rsp+0xB0]
00007f0254fd41e5  vmovaps xmm12, [rsp+0xC0]
00007f0254fd41ee  vmovaps xmm13, [rsp+0xD0]
00007f0254fd41f7  vmovaps xmm15, [rsp+0xE0]
00007f0254fd4200  add rsp, 0xF0
00007f0254fd4207  pop r11
00007f0254fd4209  pop r10
00007f0254fd420b  pop r9
00007f0254fd420d  pop r8
00007f0254fd420f  pop rsi
00007f0254fd4210  pop rdi
00007f0254fd4211  pop rdx
00007f0254fd4212  pop rcx
00007f0254fd4213  pop rax
00007f0254fd4214  add rsp, 0x08
00007f0254fd4218  jmp 0x00007F0254FD00AE
00007f0254fd421d  sub rsp, 0x08
00007f0254fd4221  push rax
00007f0254fd4222  push rcx
00007f0254fd4223  push rdx
00007f0254fd4224  push rdi
00007f0254fd4225  push rsi
00007f0254fd4226  push r8
00007f0254fd4228  push r9
00007f0254fd422a  push r10
00007f0254fd422c  push r11
00007f0254fd422e  sub rsp, 0xF0
00007f0254fd4235  vmovaps [rsp], xmm0
00007f0254fd423a  vmovaps [rsp+0x10], xmm1
00007f0254fd4240  vmovaps [rsp+0x20], xmm2
00007f0254fd4246  vmovaps [rsp+0x30], xmm3
00007f0254fd424c  vmovaps [rsp+0x40], xmm4
00007f0254fd4252  vmovaps [rsp+0x50], xmm5
00007f0254fd4258  vmovaps [rsp+0x60], xmm6
00007f0254fd425e  vmovaps [rsp+0x70], xmm7
00007f0254fd4264  vmovaps [rsp+0x80], xmm8
00007f0254fd426d  vmovaps [rsp+0x90], xmm10
00007f0254fd4276  vmovaps [rsp+0xA0], xmm11
00007f0254fd427f  vmovaps [rsp+0xB0], xmm12
00007f0254fd4288  vmovaps [rsp+0xC0], xmm13
00007f0254fd4291  vmovaps [rsp+0xD0], xmm14
00007f0254fd429a  vmovaps [rsp+0xE0], xmm15
00007f0254fd42a3  sub rsp, 0x30
00007f0254fd42a7  movaps [rsp], xmm9
00007f0254fd42ac  movaps [rsp+0x10], xmm7
00007f0254fd42b1  movaps [rsp+0x20], xmm12
00007f0254fd42b7  lea rdi, [rsp]
00007f0254fd42bb  mov esi, 0x00
00007f0254fd42c0  mov rax, 0x55DD1360A530
00007f0254fd42ca  call rax
00007f0254fd42cc  movaps xmm9, [rsp]
00007f0254fd42d1  add rsp, 0x30
00007f0254fd42d5  vmovaps xmm0, [rsp]
00007f0254fd42da  vmovaps xmm1, [rsp+0x10]
00007f0254fd42e0  vmovaps xmm2, [rsp+0x20]
00007f0254fd42e6  vmovaps xmm3, [rsp+0x30]
00007f0254fd42ec  vmovaps xmm4, [rsp+0x40]
00007f0254fd42f2  vmovaps xmm5, [rsp+0x50]
00007f0254fd42f8  vmovaps xmm6, [rsp+0x60]
00007f0254fd42fe  vmovaps xmm7, [rsp+0x70]
00007f0254fd4304  vmovaps xmm8, [rsp+0x80]
00007f0254fd430d  vmovaps xmm10, [rsp+0x90]
00007f0254fd4316  vmovaps xmm11, [rsp+0xA0]
00007f0254fd431f  vmovaps xmm12, [rsp+0xB0]
00007f0254fd4328  vmovaps xmm13, [rsp+0xC0]
00007f0254fd4331  vmovaps xmm14, [rsp+0xD0]
00007f0254fd433a  vmovaps xmm15, [rsp+0xE0]
00007f0254fd4343  add rsp, 0xF0
00007f0254fd434a  pop r11
00007f0254fd434c  pop r10
00007f0254fd434e  pop r9
00007f0254fd4350  pop r8
00007f0254fd4352  pop rsi
00007f0254fd4353  pop rdi
00007f0254fd4354  pop rdx
00007f0254fd4355  pop rcx
00007f0254fd4356  pop rax
00007f0254fd4357  add rsp, 0x08
00007f0254fd435b  jmp 0x00007F0254FD00DD
00007f0254fd4360  sub rsp, 0x08
00007f0254fd4364  push rax
00007f0254fd4365  push rcx
00007f0254fd4366  push rdx
00007f0254fd4367  push rdi
00007f0254fd4368  push rsi
00007f0254fd4369  push r8
00007f0254fd436b  push r9
00007f0254fd436d  push r10
00007f0254fd436f  push r11
00007f0254fd4371  sub rsp, 0xF0
00007f0254fd4378  vmovaps [rsp], xmm0
00007f0254fd437d  vmovaps [rsp+0x10], xmm1
00007f0254fd4383  vmovaps [rsp+0x20], xmm2
00007f0254fd4389  vmovaps [rsp+0x30], xmm3
00007f0254fd438f  vmovaps [rsp+0x40], xmm4
00007f0254fd4395  vmovaps [rsp+0x50], xmm5
00007f0254fd439b  vmovaps [rsp+0x60], xmm6
00007f0254fd43a1  vmovaps [rsp+0x70], xmm7
00007f0254fd43a7  vmovaps [rsp+0x80], xmm8
00007f0254fd43b0  vmovaps [rsp+0x90], xmm9
00007f0254fd43b9  vmovaps [rsp+0xA0], xmm10
00007f0254fd43c2  vmovaps [rsp+0xB0], xmm11
00007f0254fd43cb  vmovaps [rsp+0xC0], xmm13
00007f0254fd43d4  vmovaps [rsp+0xD0], xmm14
00007f0254fd43dd  vmovaps [rsp+0xE0], xmm15
00007f0254fd43e6  sub rsp, 0x30
00007f0254fd43ea  movaps [rsp], xmm12
00007f0254fd43ef  movaps [rsp+0x10], xmm15
00007f0254fd43f5  movaps [rsp+0x20], xmm11
00007f0254fd43fb  lea rdi, [rsp]
00007f0254fd43ff  mov esi, 0x00
00007f0254fd4404  mov rax, 0x55DD1360A530
00007f0254fd440e  call rax
00007f0254fd4410  movaps xmm12, [rsp]
00007f0254fd4415  add rsp, 0x30
00007f0254fd4419  vmovaps xmm0, [rsp]
00007f0254fd441e  vmovaps xmm1, [rsp+0x10]
00007f0254fd4424  vmovaps xmm2, [rsp+0x20]
00007f0254fd442a  vmovaps xmm3, [rsp+0x30]
00007f0254fd4430  vmovaps xmm4, [rsp+0x40]
00007f0254fd4436  vmovaps xmm5, [rsp+0x50]
00007f0254fd443c  vmovaps xmm6, [rsp+0x60]
00007f0254fd4442  vmovaps xmm7, [rsp+0x70]
00007f0254fd4448  vmovaps xmm8, [rsp+0x80]
00007f0254fd4451  vmovaps xmm9, [rsp+0x90]
00007f0254fd445a  vmovaps xmm10, [rsp+0xA0]
00007f0254fd4463  vmovaps xmm11, [rsp+0xB0]
00007f0254fd446c  vmovaps xmm13, [rsp+0xC0]
00007f0254fd4475  vmovaps xmm14, [rsp+0xD0]
00007f0254fd447e  vmovaps xmm15, [rsp+0xE0]
00007f0254fd4487  add rsp, 0xF0
00007f0254fd448e  pop r11
00007f0254fd4490  pop r10
00007f0254fd4492  pop r9
00007f0254fd4494  pop r8
00007f0254fd4496  pop rsi
00007f0254fd4497  pop rdi
00007f0254fd4498  pop rdx
00007f0254fd4499  pop rcx
00007f0254fd449a  pop rax
00007f0254fd449b  add rsp, 0x08
00007f0254fd449f  jmp 0x00007F0254FD00F7
00007f0254fd44a4  sub rsp, 0x08
00007f0254fd44a8  push rax
00007f0254fd44a9  push rcx
00007f0254fd44aa  push rdx
00007f0254fd44ab  push rdi
00007f0254fd44ac  push rsi
00007f0254fd44ad  push r8
00007f0254fd44af  push r9
00007f0254fd44b1  push r10
00007f0254fd44b3  push r11
00007f0254fd44b5  sub rsp, 0xF0
00007f0254fd44bc  vmovaps [rsp], xmm0
00007f0254fd44c1  vmovaps [rsp+0x10], xmm1
00007f0254fd44c7  vmovaps [rsp+0x20], xmm2
00007f0254fd44cd  vmovaps [rsp+0x30], xmm3
00007f0254fd44d3  vmovaps [rsp+0x40], xmm4
00007f0254fd44d9  vmovaps [rsp+0x50], xmm5
00007f0254fd44df  vmovaps [rsp+0x60], xmm6
00007f0254fd44e5  vmovaps [rsp+0x70], xmm7
00007f0254fd44eb  vmovaps [rsp+0x80], xmm8
00007f0254fd44f4  vmovaps [rsp+0x90], xmm9
00007f0254fd44fd  vmovaps [rsp+0xA0], xmm10
00007f0254fd4506  vmovaps [rsp+0xB0], xmm12
00007f0254fd450f  vmovaps [rsp+0xC0], xmm13
00007f0254fd4518  vmovaps [rsp+0xD0], xmm14
00007f0254fd4521  vmovaps [rsp+0xE0], xmm15
00007f0254fd452a  sub rsp, 0x30
00007f0254fd452e  movaps [rsp], xmm11
00007f0254fd4533  movaps [rsp+0x10], xmm7
00007f0254fd4538  movaps [rsp+0x20], xmm15
00007f0254fd453e  lea rdi, [rsp]
00007f0254fd4542  mov esi, 0x00
00007f0254fd4547  mov rax, 0x55DD1360A530
00007f0254fd4551  call rax
00007f0254fd4553  movaps xmm11, [rsp]
00007f0254fd4558  add rsp, 0x30
00007f0254fd455c  vmovaps xmm0, [rsp]
00007f0254fd4561  vmovaps xmm1, [rsp+0x10]
00007f0254fd4567  vmovaps xmm2, [rsp+0x20]
00007f0254fd456d  vmovaps xmm3, [rsp+0x30]
00007f0254fd4573  vmovaps xmm4, [rsp+0x40]
00007f0254fd4579  vmovaps xmm5, [rsp+0x50]
00007f0254fd457f  vmovaps xmm6, [rsp+0x60]
00007f0254fd4585  vmovaps xmm7, [rsp+0x70]
00007f0254fd458b  vmovaps xmm8, [rsp+0x80]
00007f0254fd4594  vmovaps xmm9, [rsp+0x90]
00007f0254fd459d  vmovaps xmm10, [rsp+0xA0]
00007f0254fd45a6  vmovaps xmm12, [rsp+0xB0]
00007f0254fd45af  vmovaps xmm13, [rsp+0xC0]
00007f0254fd45b8  vmovaps xmm14, [rsp+0xD0]
00007f0254fd45c1  vmovaps xmm15, [rsp+0xE0]
00007f0254fd45ca  add rsp, 0xF0
00007f0254fd45d1  pop r11
00007f0254fd45d3  pop r10
00007f0254fd45d5  pop r9
00007f0254fd45d7  pop r8
00007f0254fd45d9  pop rsi
00007f0254fd45da  pop rdi
00007f0254fd45db  pop rdx
00007f0254fd45dc  pop rcx
00007f0254fd45dd  pop rax
00007f0254fd45de  add rsp, 0x08
00007f0254fd45e2  jmp 0x00007F0254FD0123
00007f0254fd45e7  sub rsp, 0x08
00007f0254fd45eb  push rax
00007f0254fd45ec  push rcx
00007f0254fd45ed  push rdx
00007f0254fd45ee  push rdi
00007f0254fd45ef  push rsi
00007f0254fd45f0  push r8
00007f0254fd45f2  push r9
00007f0254fd45f4  push r10
00007f0254fd45f6  push r11
00007f0254fd45f8  sub rsp, 0xF0
00007f0254fd45ff  vmovaps [rsp], xmm0
00007f0254fd4604  vmovaps [rsp+0x10], xmm1
00007f0254fd460a  vmovaps [rsp+0x20], xmm2
00007f0254fd4610  vmovaps [rsp+0x30], xmm3
00007f0254fd4616  vmovaps [rsp+0x40], xmm4
00007f0254fd461c  vmovaps [rsp+0x50], xmm5
00007f0254fd4622  vmovaps [rsp+0x60], xmm6
00007f0254fd4628  vmovaps [rsp+0x70], xmm7
00007f0254fd462e  vmovaps [rsp+0x80], xmm8
00007f0254fd4637  vmovaps [rsp+0x90], xmm9
00007f0254fd4640  vmovaps [rsp+0xA0], xmm10
00007f0254fd4649  vmovaps [rsp+0xB0], xmm11
00007f0254fd4652  vmovaps [rsp+0xC0], xmm12
00007f0254fd465b  vmovaps [rsp+0xD0], xmm13
00007f0254fd4664  vmovaps [rsp+0xE0], xmm14
00007f0254fd466d  sub rsp, 0x30
00007f0254fd4671  movaps [rsp], xmm15
00007f0254fd4676  movaps [rsp+0x10], xmm10
00007f0254fd467c  movaps [rsp+0x20], xmm13
00007f0254fd4682  lea rdi, [rsp]
00007f0254fd4686  mov esi, 0x00
00007f0254fd468b  mov rax, 0x55DD1360A530
00007f0254fd4695  call rax
00007f0254fd4697  movaps xmm15, [rsp]
00007f0254fd469c  add rsp, 0x30
00007f0254fd46a0  vmovaps xmm0, [rsp]
00007f0254fd46a5  vmovaps xmm1, [rsp+0x10]
00007f0254fd46ab  vmovaps xmm2, [rsp+0x20]
00007f0254fd46b1  vmovaps xmm3, [rsp+0x30]
00007f0254fd46b7  vmovaps xmm4, [rsp+0x40]
00007f0254fd46bd  vmovaps xmm5, [rsp+0x50]
00007f0254fd46c3  vmovaps xmm6, [rsp+0x60]
00007f0254fd46c9  vmovaps xmm7, [rsp+0x70]
00007f0254fd46cf  vmovaps xmm8, [rsp+0x80]
00007f0254fd46d8  vmovaps xmm9, [rsp+0x90]
00007f0254fd46e1  vmovaps xmm10, [rsp+0xA0]
00007f0254fd46ea  vmovaps xmm11, [rsp+0xB0]
00007f0254fd46f3  vmovaps xmm12, [rsp+0xC0]
00007f0254fd46fc  vmovaps xmm13, [rsp+0xD0]
00007f0254fd4705  vmovaps xmm14, [rsp+0xE0]
00007f0254fd470e  add rsp, 0xF0
00007f0254fd4715  pop r11
00007f0254fd4717  pop r10
00007f0254fd4719  pop r9
00007f0254fd471b  pop r8
00007f0254fd471d  pop rsi
00007f0254fd471e  pop rdi
00007f0254fd471f  pop rdx
00007f0254fd4720  pop rcx
00007f0254fd4721  pop rax
00007f0254fd4722  add rsp, 0x08
00007f0254fd4726  jmp 0x00007F0254FD013D
00007f0254fd472b  sub rsp, 0x08
00007f0254fd472f  push rax
00007f0254fd4730  push rcx
00007f0254fd4731  push rdx
00007f0254fd4732  push rdi
00007f0254fd4733  push rsi
00007f0254fd4734  push r8
00007f0254fd4736  push r9
00007f0254fd4738  push r10
00007f0254fd473a  push r11
00007f0254fd473c  sub rsp, 0xF0
00007f0254fd4743  vmovaps [rsp], xmm0
00007f0254fd4748  vmovaps [rsp+0x10], xmm1
00007f0254fd474e  vmovaps [rsp+0x20], xmm2
00007f0254fd4754  vmovaps [rsp+0x30], xmm3
00007f0254fd475a  vmovaps [rsp+0x40], xmm4
00007f0254fd4760  vmovaps [rsp+0x50], xmm5
00007f0254fd4766  vmovaps [rsp+0x60], xmm6
00007f0254fd476c  vmovaps [rsp+0x70], xmm7
00007f0254fd4772  vmovaps [rsp+0x80], xmm8
00007f0254fd477b  vmovaps [rsp+0x90], xmm9
00007f0254fd4784  vmovaps [rsp+0xA0], xmm11
00007f0254fd478d  vmovaps [rsp+0xB0], xmm12
00007f0254fd4796  vmovaps [rsp+0xC0], xmm13
00007f0254fd479f  vmovaps [rsp+0xD0], xmm14
00007f0254fd47a8  vmovaps [rsp+0xE0], xmm15
00007f0254fd47b1  sub rsp, 0x30
00007f0254fd47b5  movaps [rsp], xmm10
00007f0254fd47ba  movaps [rsp+0x10], xmm7
00007f0254fd47bf  movaps [rsp+0x20], xmm13
00007f0254fd47c5  lea rdi, [rsp]
00007f0254fd47c9  mov esi, 0x00
00007f0254fd47ce  mov rax, 0x55DD1360A530
00007f0254fd47d8  call rax
00007f0254fd47da  movaps xmm10, [rsp]
00007f0254fd47df  add rsp, 0x30
00007f0254fd47e3  vmovaps xmm0, [rsp]
00007f0254fd47e8  vmovaps xmm1, [rsp+0x10]
00007f0254fd47ee  vmovaps xmm2, [rsp+0x20]
00007f0254fd47f4  vmovaps xmm3, [rsp+0x30]
00007f0254fd47fa  vmovaps xmm4, [rsp+0x40]
00007f0254fd4800  vmovaps xmm5, [rsp+0x50]
00007f0254fd4806  vmovaps xmm6, [rsp+0x60]
00007f0254fd480c  vmovaps xmm7, [rsp+0x70]
00007f0254fd4812  vmovaps xmm8, [rsp+0x80]
00007f0254fd481b  vmovaps xmm9, [rsp+0x90]
00007f0254fd4824  vmovaps xmm11, [rsp+0xA0]
00007f0254fd482d  vmovaps xmm12, [rsp+0xB0]
00007f0254fd4836  vmovaps xmm13, [rsp+0xC0]
00007f0254fd483f  vmovaps xmm14, [rsp+0xD0]
00007f0254fd4848  vmovaps xmm15, [rsp+0xE0]
00007f0254fd4851  add rsp, 0xF0
00007f0254fd4858  pop r11
00007f0254fd485a  pop r10
00007f0254fd485c  pop r9
00007f0254fd485e  pop r8
00007f0254fd4860  pop rsi
00007f0254fd4861  pop rdi
00007f0254fd4862  pop rdx
00007f0254fd4863  pop rcx
00007f0254fd4864  pop rax
00007f0254fd4865  add rsp, 0x08
00007f0254fd4869  jmp 0x00007F0254FD0169
00007f0254fd486e  sub rsp, 0x08
00007f0254fd4872  push rax
00007f0254fd4873  push rcx
00007f0254fd4874  push rdx
00007f0254fd4875  push rdi
00007f0254fd4876  push rsi
00007f0254fd4877  push r8
00007f0254fd4879  push r9
00007f0254fd487b  push r10
00007f0254fd487d  push r11
00007f0254fd487f  sub rsp, 0xF0
00007f0254fd4886  vmovaps [rsp], xmm0
00007f0254fd488b  vmovaps [rsp+0x10], xmm1
00007f0254fd4891  vmovaps [rsp+0x20], xmm2
00007f0254fd4897  vmovaps [rsp+0x30], xmm3
00007f0254fd489d  vmovaps [rsp+0x40], xmm4
00007f0254fd48a3  vmovaps [rsp+0x50], xmm5
00007f0254fd48a9  vmovaps [rsp+0x60], xmm6
00007f0254fd48af  vmovaps [rsp+0x70], xmm7
00007f0254fd48b5  vmovaps [rsp+0x80], xmm8
00007f0254fd48be  vmovaps [rsp+0x90], xmm9
00007f0254fd48c7  vmovaps [rsp+0xA0], xmm10
00007f0254fd48d0  vmovaps [rsp+0xB0], xmm11
00007f0254fd48d9  vmovaps [rsp+0xC0], xmm12
00007f0254fd48e2  vmovaps [rsp+0xD0], xmm14
00007f0254fd48eb  vmovaps [rsp+0xE0], xmm15
00007f0254fd48f4  sub rsp, 0x30
00007f0254fd48f8  movaps [rsp], xmm13
00007f0254fd48fd  movaps [rsp+0x10], xmm1
00007f0254fd4902  movaps [rsp+0x20], xmm8
00007f0254fd4908  lea rdi, [rsp]
00007f0254fd490c  mov esi, 0x00
00007f0254fd4911  mov rax, 0x55DD1360A530
00007f0254fd491b  call rax
00007f0254fd491d  movaps xmm13, [rsp]
00007f0254fd4922  add rsp, 0x30
00007f0254fd4926  vmovaps xmm0, [rsp]
00007f0254fd492b  vmovaps xmm1, [rsp+0x10]
00007f0254fd4931  vmovaps xmm2, [rsp+0x20]
00007f0254fd4937  vmovaps xmm3, [rsp+0x30]
00007f0254fd493d  vmovaps xmm4, [rsp+0x40]
00007f0254fd4943  vmovaps xmm5, [rsp+0x50]
00007f0254fd4949  vmovaps xmm6, [rsp+0x60]
00007f0254fd494f  vmovaps xmm7, [rsp+0x70]
00007f0254fd4955  vmovaps xmm8, [rsp+0x80]
00007f0254fd495e  vmovaps xmm9, [rsp+0x90]
00007f0254fd4967  vmovaps xmm10, [rsp+0xA0]
00007f0254fd4970  vmovaps xmm11, [rsp+0xB0]
00007f0254fd4979  vmovaps xmm12, [rsp+0xC0]
00007f0254fd4982  vmovaps xmm14, [rsp+0xD0]
00007f0254fd498b  vmovaps xmm15, [rsp+0xE0]
00007f0254fd4994  add rsp, 0xF0
00007f0254fd499b  pop r11
00007f0254fd499d  pop r10
00007f0254fd499f  pop r9
00007f0254fd49a1  pop r8
00007f0254fd49a3  pop rsi
00007f0254fd49a4  pop rdi
00007f0254fd49a5  pop rdx
00007f0254fd49a6  pop rcx
00007f0254fd49a7  pop rax
00007f0254fd49a8  add rsp, 0x08
00007f0254fd49ac  jmp 0x00007F0254FD0183
00007f0254fd49b1  call 0x00007F0254DFF430
00007f0254fd49b6  jmp 0x00007F0254FD018D
00007f0254fd49bb  sub rsp, 0x08
00007f0254fd49bf  push rax
00007f0254fd49c0  push rcx
00007f0254fd49c1  push rdx
00007f0254fd49c2  push rdi
00007f0254fd49c3  push rsi
00007f0254fd49c4  push r8
00007f0254fd49c6  push r9
00007f0254fd49c8  push r10
00007f0254fd49ca  push r11
00007f0254fd49cc  sub rsp, 0xF0
00007f0254fd49d3  vmovaps [rsp], xmm0
00007f0254fd49d8  vmovaps [rsp+0x10], xmm1
00007f0254fd49de  vmovaps [rsp+0x20], xmm2
00007f0254fd49e4  vmovaps [rsp+0x30], xmm3
00007f0254fd49ea  vmovaps [rsp+0x40], xmm4
00007f0254fd49f0  vmovaps [rsp+0x50], xmm5
00007f0254fd49f6  vmovaps [rsp+0x60], xmm6
00007f0254fd49fc  vmovaps [rsp+0x70], xmm7
00007f0254fd4a02  vmovaps [rsp+0x80], xmm9
00007f0254fd4a0b  vmovaps [rsp+0x90], xmm10
00007f0254fd4a14  vmovaps [rsp+0xA0], xmm11
00007f0254fd4a1d  vmovaps [rsp+0xB0], xmm12
00007f0254fd4a26  vmovaps [rsp+0xC0], xmm13
00007f0254fd4a2f  vmovaps [rsp+0xD0], xmm14
00007f0254fd4a38  vmovaps [rsp+0xE0], xmm15
00007f0254fd4a41  sub rsp, 0x30
00007f0254fd4a45  movaps [rsp], xmm8
00007f0254fd4a4a  movaps [rsp+0x10], xmm14
00007f0254fd4a50  movaps [rsp+0x20], xmm9
00007f0254fd4a56  lea rdi, [rsp]
00007f0254fd4a5a  mov esi, 0x00
00007f0254fd4a5f  mov rax, 0x55DD1360A530
00007f0254fd4a69  call rax
00007f0254fd4a6b  movaps xmm8, [rsp]
00007f0254fd4a70  add rsp, 0x30
00007f0254fd4a74  vmovaps xmm0, [rsp]
00007f0254fd4a79  vmovaps xmm1, [rsp+0x10]
00007f0254fd4a7f  vmovaps xmm2, [rsp+0x20]
00007f0254fd4a85  vmovaps xmm3, [rsp+0x30]
00007f0254fd4a8b  vmovaps xmm4, [rsp+0x40]
00007f0254fd4a91  vmovaps xmm5, [rsp+0x50]
00007f0254fd4a97  vmovaps xmm6, [rsp+0x60]
00007f0254fd4a9d  vmovaps xmm7, [rsp+0x70]
00007f0254fd4aa3  vmovaps xmm9, [rsp+0x80]
00007f0254fd4aac  vmovaps xmm10, [rsp+0x90]
00007f0254fd4ab5  vmovaps xmm11, [rsp+0xA0]
00007f0254fd4abe  vmovaps xmm12, [rsp+0xB0]
00007f0254fd4ac7  vmovaps xmm13, [rsp+0xC0]
00007f0254fd4ad0  vmovaps xmm14, [rsp+0xD0]
00007f0254fd4ad9  vmovaps xmm15, [rsp+0xE0]
00007f0254fd4ae2  add rsp, 0xF0
00007f0254fd4ae9  pop r11
00007f0254fd4aeb  pop r10
00007f0254fd4aed  pop r9
00007f0254fd4aef  pop r8
00007f0254fd4af1  pop rsi
00007f0254fd4af2  pop rdi
00007f0254fd4af3  pop rdx
00007f0254fd4af4  pop rcx
00007f0254fd4af5  pop rax
00007f0254fd4af6  add rsp, 0x08
00007f0254fd4afa  jmp 0x00007F0254FD01AF
00007f0254fd4aff  sub rsp, 0x08
00007f0254fd4b03  push rax
00007f0254fd4b04  push rcx
00007f0254fd4b05  push rdx
00007f0254fd4b06  push rdi
00007f0254fd4b07  push rsi
00007f0254fd4b08  push r8
00007f0254fd4b0a  push r9
00007f0254fd4b0c  push r10
00007f0254fd4b0e  push r11
00007f0254fd4b10  sub rsp, 0xF0
00007f0254fd4b17  vmovaps [rsp], xmm0
00007f0254fd4b1c  vmovaps [rsp+0x10], xmm1
00007f0254fd4b22  vmovaps [rsp+0x20], xmm2
00007f0254fd4b28  vmovaps [rsp+0x30], xmm3
00007f0254fd4b2e  vmovaps [rsp+0x40], xmm4
00007f0254fd4b34  vmovaps [rsp+0x50], xmm5
00007f0254fd4b3a  vmovaps [rsp+0x60], xmm6
00007f0254fd4b40  vmovaps [rsp+0x70], xmm7
00007f0254fd4b46  vmovaps [rsp+0x80], xmm8
00007f0254fd4b4f  vmovaps [rsp+0x90], xmm10
00007f0254fd4b58  vmovaps [rsp+0xA0], xmm11
00007f0254fd4b61  vmovaps [rsp+0xB0], xmm12
00007f0254fd4b6a  vmovaps [rsp+0xC0], xmm13
00007f0254fd4b73  vmovaps [rsp+0xD0], xmm14
00007f0254fd4b7c  vmovaps [rsp+0xE0], xmm15
00007f0254fd4b85  sub rsp, 0x30
00007f0254fd4b89  movaps [rsp], xmm9
00007f0254fd4b8e  movaps [rsp+0x10], xmm1
00007f0254fd4b93  movaps [rsp+0x20], xmm14
00007f0254fd4b99  lea rdi, [rsp]
00007f0254fd4b9d  mov esi, 0x00
00007f0254fd4ba2  mov rax, 0x55DD1360A530
00007f0254fd4bac  call rax
00007f0254fd4bae  movaps xmm9, [rsp]
00007f0254fd4bb3  add rsp, 0x30
00007f0254fd4bb7  vmovaps xmm0, [rsp]
00007f0254fd4bbc  vmovaps xmm1, [rsp+0x10]
00007f0254fd4bc2  vmovaps xmm2, [rsp+0x20]
00007f0254fd4bc8  vmovaps xmm3, [rsp+0x30]
00007f0254fd4bce  vmovaps xmm4, [rsp+0x40]
00007f0254fd4bd4  vmovaps xmm5, [rsp+0x50]
00007f0254fd4bda  vmovaps xmm6, [rsp+0x60]
00007f0254fd4be0  vmovaps xmm7, [rsp+0x70]
00007f0254fd4be6  vmovaps xmm8, [rsp+0x80]
00007f0254fd4bef  vmovaps xmm10, [rsp+0x90]
00007f0254fd4bf8  vmovaps xmm11, [rsp+0xA0]
00007f0254fd4c01  vmovaps xmm12, [rsp+0xB0]
00007f0254fd4c0a  vmovaps xmm13, [rsp+0xC0]
00007f0254fd4c13  vmovaps xmm14, [rsp+0xD0]
00007f0254fd4c1c  vmovaps xmm15, [rsp+0xE0]
00007f0254fd4c25  add rsp, 0xF0
00007f0254fd4c2c  pop r11
00007f0254fd4c2e  pop r10
00007f0254fd4c30  pop r9
00007f0254fd4c32  pop r8
00007f0254fd4c34  pop rsi
00007f0254fd4c35  pop rdi
00007f0254fd4c36  pop rdx
00007f0254fd4c37  pop rcx
00007f0254fd4c38  pop rax
00007f0254fd4c39  add rsp, 0x08
00007f0254fd4c3d  jmp 0x00007F0254FD01DD
00007f0254fd4c42  sub rsp, 0x08
00007f0254fd4c46  push rax
00007f0254fd4c47  push rcx
00007f0254fd4c48  push rdx
00007f0254fd4c49  push rdi
00007f0254fd4c4a  push rsi
00007f0254fd4c4b  push r8
00007f0254fd4c4d  push r9
00007f0254fd4c4f  push r10
00007f0254fd4c51  push r11
00007f0254fd4c53  sub rsp, 0xF0
00007f0254fd4c5a  vmovaps [rsp], xmm0
00007f0254fd4c5f  vmovaps [rsp+0x10], xmm1
00007f0254fd4c65  vmovaps [rsp+0x20], xmm2
00007f0254fd4c6b  vmovaps [rsp+0x30], xmm3
00007f0254fd4c71  vmovaps [rsp+0x40], xmm4
00007f0254fd4c77  vmovaps [rsp+0x50], xmm5
00007f0254fd4c7d  vmovaps [rsp+0x60], xmm6
00007f0254fd4c83  vmovaps [rsp+0x70], xmm7
00007f0254fd4c89  vmovaps [rsp+0x80], xmm8
00007f0254fd4c92  vmovaps [rsp+0x90], xmm9
00007f0254fd4c9b  vmovaps [rsp+0xA0], xmm10
00007f0254fd4ca4  vmovaps [rsp+0xB0], xmm11
00007f0254fd4cad  vmovaps [rsp+0xC0], xmm12
00007f0254fd4cb6  vmovaps [rsp+0xD0], xmm13
00007f0254fd4cbf  vmovaps [rsp+0xE0], xmm15
00007f0254fd4cc8  sub rsp, 0x30
00007f0254fd4ccc  movaps [rsp], xmm14
00007f0254fd4cd1  movaps [rsp+0x10], xmm4
00007f0254fd4cd6  movaps [rsp+0x20], xmm1
00007f0254fd4cdb  lea rdi, [rsp]
00007f0254fd4cdf  mov esi, 0x00
00007f0254fd4ce4  mov rax, 0x55DD1360A530
00007f0254fd4cee  call rax
00007f0254fd4cf0  movaps xmm14, [rsp]
00007f0254fd4cf5  add rsp, 0x30
00007f0254fd4cf9  vmovaps xmm0, [rsp]
00007f0254fd4cfe  vmovaps xmm1, [rsp+0x10]
00007f0254fd4d04  vmovaps xmm2, [rsp+0x20]
00007f0254fd4d0a  vmovaps xmm3, [rsp+0x30]
00007f0254fd4d10  vmovaps xmm4, [rsp+0x40]
00007f0254fd4d16  vmovaps xmm5, [rsp+0x50]
00007f0254fd4d1c  vmovaps xmm6, [rsp+0x60]
00007f0254fd4d22  vmovaps xmm7, [rsp+0x70]
00007f0254fd4d28  vmovaps xmm8, [rsp+0x80]
00007f0254fd4d31  vmovaps xmm9, [rsp+0x90]
00007f0254fd4d3a  vmovaps xmm10, [rsp+0xA0]
00007f0254fd4d43  vmovaps xmm11, [rsp+0xB0]
00007f0254fd4d4c  vmovaps xmm12, [rsp+0xC0]
00007f0254fd4d55  vmovaps xmm13, [rsp+0xD0]
00007f0254fd4d5e  vmovaps xmm15, [rsp+0xE0]
00007f0254fd4d67  add rsp, 0xF0
00007f0254fd4d6e  pop r11
00007f0254fd4d70  pop r10
00007f0254fd4d72  pop r9
00007f0254fd4d74  pop r8
00007f0254fd4d76  pop rsi
00007f0254fd4d77  pop rdi
00007f0254fd4d78  pop rdx
00007f0254fd4d79  pop rcx
00007f0254fd4d7a  pop rax
00007f0254fd4d7b  add rsp, 0x08
00007f0254fd4d7f  jmp 0x00007F0254FD0203
00007f0254fd4d84  sub rsp, 0x08
00007f0254fd4d88  push rax
00007f0254fd4d89  push rcx
00007f0254fd4d8a  push rdx
00007f0254fd4d8b  push rdi
00007f0254fd4d8c  push rsi
00007f0254fd4d8d  push r8
00007f0254fd4d8f  push r9
00007f0254fd4d91  push r10
00007f0254fd4d93  push r11
00007f0254fd4d95  sub rsp, 0xF0
00007f0254fd4d9c  vmovaps [rsp], xmm0
00007f0254fd4da1  vmovaps [rsp+0x10], xmm2
00007f0254fd4da7  vmovaps [rsp+0x20], xmm3
00007f0254fd4dad  vmovaps [rsp+0x30], xmm4
00007f0254fd4db3  vmovaps [rsp+0x40], xmm5
00007f0254fd4db9  vmovaps [rsp+0x50], xmm6
00007f0254fd4dbf  vmovaps [rsp+0x60], xmm7
00007f0254fd4dc5  vmovaps [rsp+0x70], xmm8
00007f0254fd4dcb  vmovaps [rsp+0x80], xmm9
00007f0254fd4dd4  vmovaps [rsp+0x90], xmm10
00007f0254fd4ddd  vmovaps [rsp+0xA0], xmm11
00007f0254fd4de6  vmovaps [rsp+0xB0], xmm12
00007f0254fd4def  vmovaps [rsp+0xC0], xmm13
00007f0254fd4df8  vmovaps [rsp+0xD0], xmm14
00007f0254fd4e01  vmovaps [rsp+0xE0], xmm15
00007f0254fd4e0a  sub rsp, 0x30
00007f0254fd4e0e  movaps [rsp], xmm1
00007f0254fd4e12  movaps [rsp+0x10], xmm12
00007f0254fd4e18  movaps [rsp+0x20], xmm11
00007f0254fd4e1e  lea rdi, [rsp]
00007f0254fd4e22  mov esi, 0x00
00007f0254fd4e27  mov rax, 0x55DD1360A530
00007f0254fd4e31  call rax
00007f0254fd4e33  movaps xmm1, [rsp]
00007f0254fd4e37  add rsp, 0x30
00007f0254fd4e3b  vmovaps xmm0, [rsp]
00007f0254fd4e40  vmovaps xmm2, [rsp+0x10]
00007f0254fd4e46  vmovaps xmm3, [rsp+0x20]
00007f0254fd4e4c  vmovaps xmm4, [rsp+0x30]
00007f0254fd4e52  vmovaps xmm5, [rsp+0x40]
00007f0254fd4e58  vmovaps xmm6, [rsp+0x50]
00007f0254fd4e5e  vmovaps xmm7, [rsp+0x60]
00007f0254fd4e64  vmovaps xmm8, [rsp+0x70]
00007f0254fd4e6a  vmovaps xmm9, [rsp+0x80]
00007f0254fd4e73  vmovaps xmm10, [rsp+0x90]
00007f0254fd4e7c  vmovaps xmm11, [rsp+0xA0]
00007f0254fd4e85  vmovaps xmm12, [rsp+0xB0]
00007f0254fd4e8e  vmovaps xmm13, [rsp+0xC0]
00007f0254fd4e97  vmovaps xmm14, [rsp+0xD0]
00007f0254fd4ea0  vmovaps xmm15, [rsp+0xE0]
00007f0254fd4ea9  add rsp, 0xF0
00007f0254fd4eb0  pop r11
00007f0254fd4eb2  pop r10
00007f0254fd4eb4  pop r9
00007f0254fd4eb6  pop r8
00007f0254fd4eb8  pop rsi
00007f0254fd4eb9  pop rdi
00007f0254fd4eba  pop rdx
00007f0254fd4ebb  pop rcx
00007f0254fd4ebc  pop rax
00007f0254fd4ebd  add rsp, 0x08
00007f0254fd4ec1  jmp 0x00007F0254FD0224
00007f0254fd4ec6  call 0x00007F0254EE20A0
00007f0254fd4ecb  jmp 0x00007F0254FD0232
00007f0254fd4ed0  call 0x00007F0254E09D70
00007f0254fd4ed5  jmp 0x00007F0254FD023C
00007f0254fd4eda  sub rsp, 0x08
00007f0254fd4ede  push rax
00007f0254fd4edf  push rcx
00007f0254fd4ee0  push rdx
00007f0254fd4ee1  push rdi
00007f0254fd4ee2  push rsi
00007f0254fd4ee3  push r8
00007f0254fd4ee5  push r9
00007f0254fd4ee7  push r10
00007f0254fd4ee9  push r11
00007f0254fd4eeb  sub rsp, 0xF0
00007f0254fd4ef2  vmovaps [rsp], xmm0
00007f0254fd4ef7  vmovaps [rsp+0x10], xmm1
00007f0254fd4efd  vmovaps [rsp+0x20], xmm2
00007f0254fd4f03  vmovaps [rsp+0x30], xmm3
00007f0254fd4f09  vmovaps [rsp+0x40], xmm4
00007f0254fd4f0f  vmovaps [rsp+0x50], xmm5
00007f0254fd4f15  vmovaps [rsp+0x60], xmm6
00007f0254fd4f1b  vmovaps [rsp+0x70], xmm8
00007f0254fd4f21  vmovaps [rsp+0x80], xmm9
00007f0254fd4f2a  vmovaps [rsp+0x90], xmm10
00007f0254fd4f33  vmovaps [rsp+0xA0], xmm11
00007f0254fd4f3c  vmovaps [rsp+0xB0], xmm12
00007f0254fd4f45  vmovaps [rsp+0xC0], xmm13
00007f0254fd4f4e  vmovaps [rsp+0xD0], xmm14
00007f0254fd4f57  vmovaps [rsp+0xE0], xmm15
00007f0254fd4f60  sub rsp, 0x30
00007f0254fd4f64  movaps [rsp], xmm7
00007f0254fd4f68  movaps [rsp+0x10], xmm15
00007f0254fd4f6e  movaps [rsp+0x20], xmm10
00007f0254fd4f74  lea rdi, [rsp]
00007f0254fd4f78  mov esi, 0x00
00007f0254fd4f7d  mov rax, 0x55DD1360A530
00007f0254fd4f87  call rax
00007f0254fd4f89  movaps xmm7, [rsp]
00007f0254fd4f8d  add rsp, 0x30
00007f0254fd4f91  vmovaps xmm0, [rsp]
00007f0254fd4f96  vmovaps xmm1, [rsp+0x10]
00007f0254fd4f9c  vmovaps xmm2, [rsp+0x20]
00007f0254fd4fa2  vmovaps xmm3, [rsp+0x30]
00007f0254fd4fa8  vmovaps xmm4, [rsp+0x40]
00007f0254fd4fae  vmovaps xmm5, [rsp+0x50]
00007f0254fd4fb4  vmovaps xmm6, [rsp+0x60]
00007f0254fd4fba  vmovaps xmm8, [rsp+0x70]
00007f0254fd4fc0  vmovaps xmm9, [rsp+0x80]
00007f0254fd4fc9  vmovaps xmm10, [rsp+0x90]
00007f0254fd4fd2  vmovaps xmm11, [rsp+0xA0]
00007f0254fd4fdb  vmovaps xmm12, [rsp+0xB0]
00007f0254fd4fe4  vmovaps xmm13, [rsp+0xC0]
00007f0254fd4fed  vmovaps xmm14, [rsp+0xD0]
00007f0254fd4ff6  vmovaps xmm15, [rsp+0xE0]
00007f0254fd4fff  add rsp, 0xF0
00007f0254fd5006  pop r11
00007f0254fd5008  pop r10
00007f0254fd500a  pop r9
00007f0254fd500c  pop r8
00007f0254fd500e  pop rsi
00007f0254fd500f  pop rdi
00007f0254fd5010  pop rdx
00007f0254fd5011  pop rcx
00007f0254fd5012  pop rax
00007f0254fd5013  add rsp, 0x08
00007f0254fd5017  jmp 0x00007F0254FD025D
00007f0254fd501c  sub rsp, 0x08
00007f0254fd5020  push rax
00007f0254fd5021  push rcx
00007f0254fd5022  push rdx
00007f0254fd5023  push rdi
00007f0254fd5024  push rsi
00007f0254fd5025  push r8
00007f0254fd5027  push r9
00007f0254fd5029  push r10
00007f0254fd502b  push r11
00007f0254fd502d  sub rsp, 0xF0
00007f0254fd5034  vmovaps [rsp], xmm0
00007f0254fd5039  vmovaps [rsp+0x10], xmm1
00007f0254fd503f  vmovaps [rsp+0x20], xmm2
00007f0254fd5045  vmovaps [rsp+0x30], xmm3
00007f0254fd504b  vmovaps [rsp+0x40], xmm4
00007f0254fd5051  vmovaps [rsp+0x50], xmm5
00007f0254fd5057  vmovaps [rsp+0x60], xmm6
00007f0254fd505d  vmovaps [rsp+0x70], xmm7
00007f0254fd5063  vmovaps [rsp+0x80], xmm8
00007f0254fd506c  vmovaps [rsp+0x90], xmm9
00007f0254fd5075  vmovaps [rsp+0xA0], xmm11
00007f0254fd507e  vmovaps [rsp+0xB0], xmm12
00007f0254fd5087  vmovaps [rsp+0xC0], xmm13
00007f0254fd5090  vmovaps [rsp+0xD0], xmm14
00007f0254fd5099  vmovaps [rsp+0xE0], xmm15
00007f0254fd50a2  sub rsp, 0x30
00007f0254fd50a6  movaps [rsp], xmm10
00007f0254fd50ab  movaps [rsp+0x10], xmm11
00007f0254fd50b1  movaps [rsp+0x20], xmm15
00007f0254fd50b7  lea rdi, [rsp]
00007f0254fd50bb  mov esi, 0x00
00007f0254fd50c0  mov rax, 0x55DD1360A530
00007f0254fd50ca  call rax
00007f0254fd50cc  movaps xmm10, [rsp]
00007f0254fd50d1  add rsp, 0x30
00007f0254fd50d5  vmovaps xmm0, [rsp]
00007f0254fd50da  vmovaps xmm1, [rsp+0x10]
00007f0254fd50e0  vmovaps xmm2, [rsp+0x20]
00007f0254fd50e6  vmovaps xmm3, [rsp+0x30]
00007f0254fd50ec  vmovaps xmm4, [rsp+0x40]
00007f0254fd50f2  vmovaps xmm5, [rsp+0x50]
00007f0254fd50f8  vmovaps xmm6, [rsp+0x60]
00007f0254fd50fe  vmovaps xmm7, [rsp+0x70]
00007f0254fd5104  vmovaps xmm8, [rsp+0x80]
00007f0254fd510d  vmovaps xmm9, [rsp+0x90]
00007f0254fd5116  vmovaps xmm11, [rsp+0xA0]
00007f0254fd511f  vmovaps xmm12, [rsp+0xB0]
00007f0254fd5128  vmovaps xmm13, [rsp+0xC0]
00007f0254fd5131  vmovaps xmm14, [rsp+0xD0]
00007f0254fd513a  vmovaps xmm15, [rsp+0xE0]
00007f0254fd5143  add rsp, 0xF0
00007f0254fd514a  pop r11
00007f0254fd514c  pop r10
00007f0254fd514e  pop r9
00007f0254fd5150  pop r8
00007f0254fd5152  pop rsi
00007f0254fd5153  pop rdi
00007f0254fd5154  pop rdx
00007f0254fd5155  pop rcx
00007f0254fd5156  pop rax
00007f0254fd5157  add rsp, 0x08
00007f0254fd515b  jmp 0x00007F0254FD028B
00007f0254fd5160  sub rsp, 0x08
00007f0254fd5164  push rax
00007f0254fd5165  push rcx
00007f0254fd5166  push rdx
00007f0254fd5167  push rdi
00007f0254fd5168  push rsi
00007f0254fd5169  push r8
00007f0254fd516b  push r9
00007f0254fd516d  push r10
00007f0254fd516f  push r11
00007f0254fd5171  sub rsp, 0xF0
00007f0254fd5178  vmovaps [rsp], xmm0
00007f0254fd517d  vmovaps [rsp+0x10], xmm1
00007f0254fd5183  vmovaps [rsp+0x20], xmm2
00007f0254fd5189  vmovaps [rsp+0x30], xmm3
00007f0254fd518f  vmovaps [rsp+0x40], xmm4
00007f0254fd5195  vmovaps [rsp+0x50], xmm5
00007f0254fd519b  vmovaps [rsp+0x60], xmm6
00007f0254fd51a1  vmovaps [rsp+0x70], xmm7
00007f0254fd51a7  vmovaps [rsp+0x80], xmm8
00007f0254fd51b0  vmovaps [rsp+0x90], xmm9
00007f0254fd51b9  vmovaps [rsp+0xA0], xmm10
00007f0254fd51c2  vmovaps [rsp+0xB0], xmm12
00007f0254fd51cb  vmovaps [rsp+0xC0], xmm13
00007f0254fd51d4  vmovaps [rsp+0xD0], xmm14
00007f0254fd51dd  vmovaps [rsp+0xE0], xmm15
00007f0254fd51e6  sub rsp, 0x30
00007f0254fd51ea  movaps [rsp], xmm11
00007f0254fd51ef  movaps [rsp+0x10], xmm12
00007f0254fd51f5  movaps [rsp+0x20], xmm15
00007f0254fd51fb  lea rdi, [rsp]
00007f0254fd51ff  mov esi, 0x00
00007f0254fd5204  mov rax, 0x55DD1360A530
00007f0254fd520e  call rax
00007f0254fd5210  movaps xmm11, [rsp]
00007f0254fd5215  add rsp, 0x30
00007f0254fd5219  vmovaps xmm0, [rsp]
00007f0254fd521e  vmovaps xmm1, [rsp+0x10]
00007f0254fd5224  vmovaps xmm2, [rsp+0x20]
00007f0254fd522a  vmovaps xmm3, [rsp+0x30]
00007f0254fd5230  vmovaps xmm4, [rsp+0x40]
00007f0254fd5236  vmovaps xmm5, [rsp+0x50]
00007f0254fd523c  vmovaps xmm6, [rsp+0x60]
00007f0254fd5242  vmovaps xmm7, [rsp+0x70]
00007f0254fd5248  vmovaps xmm8, [rsp+0x80]
00007f0254fd5251  vmovaps xmm9, [rsp+0x90]
00007f0254fd525a  vmovaps xmm10, [rsp+0xA0]
00007f0254fd5263  vmovaps xmm12, [rsp+0xB0]
00007f0254fd526c  vmovaps xmm13, [rsp+0xC0]
00007f0254fd5275  vmovaps xmm14, [rsp+0xD0]
00007f0254fd527e  vmovaps xmm15, [rsp+0xE0]
00007f0254fd5287  add rsp, 0xF0
00007f0254fd528e  pop r11
00007f0254fd5290  pop r10
00007f0254fd5292  pop r9
00007f0254fd5294  pop r8
00007f0254fd5296  pop rsi
00007f0254fd5297  pop rdi
00007f0254fd5298  pop rdx
00007f0254fd5299  pop rcx
00007f0254fd529a  pop rax
00007f0254fd529b  add rsp, 0x08
00007f0254fd529f  jmp 0x00007F0254FD02B9
00007f0254fd52a4  sub rsp, 0x08
00007f0254fd52a8  push rax
00007f0254fd52a9  push rcx
00007f0254fd52aa  push rdx
00007f0254fd52ab  push rdi
00007f0254fd52ac  push rsi
00007f0254fd52ad  push r8
00007f0254fd52af  push r9
00007f0254fd52b1  push r10
00007f0254fd52b3  push r11
00007f0254fd52b5  sub rsp, 0xF0
00007f0254fd52bc  vmovaps [rsp], xmm0
00007f0254fd52c1  vmovaps [rsp+0x10], xmm1
00007f0254fd52c7  vmovaps [rsp+0x20], xmm2
00007f0254fd52cd  vmovaps [rsp+0x30], xmm3
00007f0254fd52d3  vmovaps [rsp+0x40], xmm4
00007f0254fd52d9  vmovaps [rsp+0x50], xmm5
00007f0254fd52df  vmovaps [rsp+0x60], xmm6
00007f0254fd52e5  vmovaps [rsp+0x70], xmm7
00007f0254fd52eb  vmovaps [rsp+0x80], xmm8
00007f0254fd52f4  vmovaps [rsp+0x90], xmm9
00007f0254fd52fd  vmovaps [rsp+0xA0], xmm10
00007f0254fd5306  vmovaps [rsp+0xB0], xmm11
00007f0254fd530f  vmovaps [rsp+0xC0], xmm12
00007f0254fd5318  vmovaps [rsp+0xD0], xmm13
00007f0254fd5321  vmovaps [rsp+0xE0], xmm14
00007f0254fd532a  sub rsp, 0x30
00007f0254fd532e  movaps [rsp], xmm15
00007f0254fd5333  movaps [rsp+0x10], xmm13
00007f0254fd5339  movaps [rsp+0x20], xmm9
00007f0254fd533f  lea rdi, [rsp]
00007f0254fd5343  mov esi, 0x00
00007f0254fd5348  mov rax, 0x55DD1360A530
00007f0254fd5352  call rax
00007f0254fd5354  movaps xmm15, [rsp]
00007f0254fd5359  add rsp, 0x30
00007f0254fd535d  vmovaps xmm0, [rsp]
00007f0254fd5362  vmovaps xmm1, [rsp+0x10]
00007f0254fd5368  vmovaps xmm2, [rsp+0x20]
00007f0254fd536e  vmovaps xmm3, [rsp+0x30]
00007f0254fd5374  vmovaps xmm4, [rsp+0x40]
00007f0254fd537a  vmovaps xmm5, [rsp+0x50]
00007f0254fd5380  vmovaps xmm6, [rsp+0x60]
00007f0254fd5386  vmovaps xmm7, [rsp+0x70]
00007f0254fd538c  vmovaps xmm8, [rsp+0x80]
00007f0254fd5395  vmovaps xmm9, [rsp+0x90]
00007f0254fd539e  vmovaps xmm10, [rsp+0xA0]
00007f0254fd53a7  vmovaps xmm11, [rsp+0xB0]
00007f0254fd53b0  vmovaps xmm12, [rsp+0xC0]
00007f0254fd53b9  vmovaps xmm13, [rsp+0xD0]
00007f0254fd53c2  vmovaps xmm14, [rsp+0xE0]
00007f0254fd53cb  add rsp, 0xF0
00007f0254fd53d2  pop r11
00007f0254fd53d4  pop r10
00007f0254fd53d6  pop r9
00007f0254fd53d8  pop r8
00007f0254fd53da  pop rsi
00007f0254fd53db  pop rdi
00007f0254fd53dc  pop rdx
00007f0254fd53dd  pop rcx
00007f0254fd53de  pop rax
00007f0254fd53df  add rsp, 0x08
00007f0254fd53e3  jmp 0x00007F0254FD02D4
00007f0254fd53e8  sub rsp, 0x08
00007f0254fd53ec  push rax
00007f0254fd53ed  push rcx
00007f0254fd53ee  push rdx
00007f0254fd53ef  push rdi
00007f0254fd53f0  push rsi
00007f0254fd53f1  push r8
00007f0254fd53f3  push r9
00007f0254fd53f5  push r10
00007f0254fd53f7  push r11
00007f0254fd53f9  sub rsp, 0xF0
00007f0254fd5400  vmovaps [rsp], xmm0
00007f0254fd5405  vmovaps [rsp+0x10], xmm1
00007f0254fd540b  vmovaps [rsp+0x20], xmm2
00007f0254fd5411  vmovaps [rsp+0x30], xmm3
00007f0254fd5417  vmovaps [rsp+0x40], xmm4
00007f0254fd541d  vmovaps [rsp+0x50], xmm5
00007f0254fd5423  vmovaps [rsp+0x60], xmm6
00007f0254fd5429  vmovaps [rsp+0x70], xmm7
00007f0254fd542f  vmovaps [rsp+0x80], xmm8
00007f0254fd5438  vmovaps [rsp+0x90], xmm9
00007f0254fd5441  vmovaps [rsp+0xA0], xmm10
00007f0254fd544a  vmovaps [rsp+0xB0], xmm11
00007f0254fd5453  vmovaps [rsp+0xC0], xmm12
00007f0254fd545c  vmovaps [rsp+0xD0], xmm14
00007f0254fd5465  vmovaps [rsp+0xE0], xmm15
00007f0254fd546e  sub rsp, 0x30
00007f0254fd5472  movaps [rsp], xmm13
00007f0254fd5477  movaps [rsp+0x10], xmm8
00007f0254fd547d  movaps [rsp+0x20], xmm14
00007f0254fd5483  lea rdi, [rsp]
00007f0254fd5487  mov esi, 0x00
00007f0254fd548c  mov rax, 0x55DD1360A530
00007f0254fd5496  call rax
00007f0254fd5498  movaps xmm13, [rsp]
00007f0254fd549d  add rsp, 0x30
00007f0254fd54a1  vmovaps xmm0, [rsp]
00007f0254fd54a6  vmovaps xmm1, [rsp+0x10]
00007f0254fd54ac  vmovaps xmm2, [rsp+0x20]
00007f0254fd54b2  vmovaps xmm3, [rsp+0x30]
00007f0254fd54b8  vmovaps xmm4, [rsp+0x40]
00007f0254fd54be  vmovaps xmm5, [rsp+0x50]
00007f0254fd54c4  vmovaps xmm6, [rsp+0x60]
00007f0254fd54ca  vmovaps xmm7, [rsp+0x70]
00007f0254fd54d0  vmovaps xmm8, [rsp+0x80]
00007f0254fd54d9  vmovaps xmm9, [rsp+0x90]
00007f0254fd54e2  vmovaps xmm10, [rsp+0xA0]
00007f0254fd54eb  vmovaps xmm11, [rsp+0xB0]
00007f0254fd54f4  vmovaps xmm12, [rsp+0xC0]
00007f0254fd54fd  vmovaps xmm14, [rsp+0xD0]
00007f0254fd5506  vmovaps xmm15, [rsp+0xE0]
00007f0254fd550f  add rsp, 0xF0
00007f0254fd5516  pop r11
00007f0254fd5518  pop r10
00007f0254fd551a  pop r9
00007f0254fd551c  pop r8
00007f0254fd551e  pop rsi
00007f0254fd551f  pop rdi
00007f0254fd5520  pop rdx
00007f0254fd5521  pop rcx
00007f0254fd5522  pop rax
00007f0254fd5523  add rsp, 0x08
00007f0254fd5527  jmp 0x00007F0254FD02F7
00007f0254fd552c  sub rsp, 0x08
00007f0254fd5530  push rax
00007f0254fd5531  push rcx
00007f0254fd5532  push rdx
00007f0254fd5533  push rdi
00007f0254fd5534  push rsi
00007f0254fd5535  push r8
00007f0254fd5537  push r9
00007f0254fd5539  push r10
00007f0254fd553b  push r11
00007f0254fd553d  sub rsp, 0xF0
00007f0254fd5544  vmovaps [rsp], xmm0
00007f0254fd5549  vmovaps [rsp+0x10], xmm1
00007f0254fd554f  vmovaps [rsp+0x20], xmm2
00007f0254fd5555  vmovaps [rsp+0x30], xmm3
00007f0254fd555b  vmovaps [rsp+0x40], xmm4
00007f0254fd5561  vmovaps [rsp+0x50], xmm5
00007f0254fd5567  vmovaps [rsp+0x60], xmm6
00007f0254fd556d  vmovaps [rsp+0x70], xmm7
00007f0254fd5573  vmovaps [rsp+0x80], xmm8
00007f0254fd557c  vmovaps [rsp+0x90], xmm9
00007f0254fd5585  vmovaps [rsp+0xA0], xmm10
00007f0254fd558e  vmovaps [rsp+0xB0], xmm11
00007f0254fd5597  vmovaps [rsp+0xC0], xmm12
00007f0254fd55a0  vmovaps [rsp+0xD0], xmm13
00007f0254fd55a9  vmovaps [rsp+0xE0], xmm15
00007f0254fd55b2  sub rsp, 0x30
00007f0254fd55b6  movaps [rsp], xmm14
00007f0254fd55bb  movaps [rsp+0x10], xmm1
00007f0254fd55c0  movaps [rsp+0x20], xmm10
00007f0254fd55c6  lea rdi, [rsp]
00007f0254fd55ca  mov esi, 0x00
00007f0254fd55cf  mov rax, 0x55DD1360A530
00007f0254fd55d9  call rax
00007f0254fd55db  movaps xmm14, [rsp]
00007f0254fd55e0  add rsp, 0x30
00007f0254fd55e4  vmovaps xmm0, [rsp]
00007f0254fd55e9  vmovaps xmm1, [rsp+0x10]
00007f0254fd55ef  vmovaps xmm2, [rsp+0x20]
00007f0254fd55f5  vmovaps xmm3, [rsp+0x30]
00007f0254fd55fb  vmovaps xmm4, [rsp+0x40]
00007f0254fd5601  vmovaps xmm5, [rsp+0x50]
00007f0254fd5607  vmovaps xmm6, [rsp+0x60]
00007f0254fd560d  vmovaps xmm7, [rsp+0x70]
00007f0254fd5613  vmovaps xmm8, [rsp+0x80]
00007f0254fd561c  vmovaps xmm9, [rsp+0x90]
00007f0254fd5625  vmovaps xmm10, [rsp+0xA0]
00007f0254fd562e  vmovaps xmm11, [rsp+0xB0]
00007f0254fd5637  vmovaps xmm12, [rsp+0xC0]
00007f0254fd5640  vmovaps xmm13, [rsp+0xD0]
00007f0254fd5649  vmovaps xmm15, [rsp+0xE0]
00007f0254fd5652  add rsp, 0xF0
00007f0254fd5659  pop r11
00007f0254fd565b  pop r10
00007f0254fd565d  pop r9
00007f0254fd565f  pop r8
00007f0254fd5661  pop rsi
00007f0254fd5662  pop rdi
00007f0254fd5663  pop rdx
00007f0254fd5664  pop rcx
00007f0254fd5665  pop rax
00007f0254fd5666  add rsp, 0x08
00007f0254fd566a  jmp 0x00007F0254FD031A
00007f0254fd566f  sub rsp, 0x08
00007f0254fd5673  push rax
00007f0254fd5674  push rcx
00007f0254fd5675  push rdx
00007f0254fd5676  push rdi
00007f0254fd5677  push rsi
00007f0254fd5678  push r8
00007f0254fd567a  push r9
00007f0254fd567c  push r10
00007f0254fd567e  push r11
00007f0254fd5680  sub rsp, 0xF0
00007f0254fd5687  vmovaps [rsp], xmm0
00007f0254fd568c  vmovaps [rsp+0x10], xmm2
00007f0254fd5692  vmovaps [rsp+0x20], xmm3
00007f0254fd5698  vmovaps [rsp+0x30], xmm4
00007f0254fd569e  vmovaps [rsp+0x40], xmm5
00007f0254fd56a4  vmovaps [rsp+0x50], xmm6
00007f0254fd56aa  vmovaps [rsp+0x60], xmm7
00007f0254fd56b0  vmovaps [rsp+0x70], xmm8
00007f0254fd56b6  vmovaps [rsp+0x80], xmm9
00007f0254fd56bf  vmovaps [rsp+0x90], xmm10
00007f0254fd56c8  vmovaps [rsp+0xA0], xmm11
00007f0254fd56d1  vmovaps [rsp+0xB0], xmm12
00007f0254fd56da  vmovaps [rsp+0xC0], xmm13
00007f0254fd56e3  vmovaps [rsp+0xD0], xmm14
00007f0254fd56ec  vmovaps [rsp+0xE0], xmm15
00007f0254fd56f5  sub rsp, 0x30
00007f0254fd56f9  movaps [rsp], xmm1
00007f0254fd56fd  movaps [rsp+0x10], xmm7
00007f0254fd5702  movaps [rsp+0x20], xmm11
00007f0254fd5708  lea rdi, [rsp]
00007f0254fd570c  mov esi, 0x00
00007f0254fd5711  mov rax, 0x55DD1360A530
00007f0254fd571b  call rax
00007f0254fd571d  movaps xmm1, [rsp]
00007f0254fd5721  add rsp, 0x30
00007f0254fd5725  vmovaps xmm0, [rsp]
00007f0254fd572a  vmovaps xmm2, [rsp+0x10]
00007f0254fd5730  vmovaps xmm3, [rsp+0x20]
00007f0254fd5736  vmovaps xmm4, [rsp+0x30]
00007f0254fd573c  vmovaps xmm5, [rsp+0x40]
00007f0254fd5742  vmovaps xmm6, [rsp+0x50]
00007f0254fd5748  vmovaps xmm7, [rsp+0x60]
00007f0254fd574e  vmovaps xmm8, [rsp+0x70]
00007f0254fd5754  vmovaps xmm9, [rsp+0x80]
00007f0254fd575d  vmovaps xmm10, [rsp+0x90]
00007f0254fd5766  vmovaps xmm11, [rsp+0xA0]
00007f0254fd576f  vmovaps xmm12, [rsp+0xB0]
00007f0254fd5778  vmovaps xmm13, [rsp+0xC0]
00007f0254fd5781  vmovaps xmm14, [rsp+0xD0]
00007f0254fd578a  vmovaps xmm15, [rsp+0xE0]
00007f0254fd5793  add rsp, 0xF0
00007f0254fd579a  pop r11
00007f0254fd579c  pop r10
00007f0254fd579e  pop r9
00007f0254fd57a0  pop r8
00007f0254fd57a2  pop rsi
00007f0254fd57a3  pop rdi
00007f0254fd57a4  pop rdx
00007f0254fd57a5  pop rcx
00007f0254fd57a6  pop rax
00007f0254fd57a7  add rsp, 0x08
00007f0254fd57ab  jmp 0x00007F0254FD033B
00007f0254fd57b0  call 0x00007F0254E0E880
00007f0254fd57b5  jmp 0x00007F0254FD034E
00007f0254fd57ba  call 0x00007F0254E0C380
00007f0254fd57bf  jmp 0x00007F0254FD0359
00007f0254fd57c4  call 0x00007F0254E0D600
00007f0254fd57c9  jmp 0x00007F0254FD0364
00007f0254fd57ce  call 0x00007F0254DFF540
00007f0254fd57d3  jmp 0x00007F0254FD036F
00007f0254fd57d8  int3
00007f0254fd57d9  nop [rax], eax
00007f0254fd57e0  mov rax, [r15+0x40]
00007f0254fd57e4  mov r14, [r15+0x58]
00007f0254fd57e8  lea r12, [rax+r14*1]
00007f0254fd57ec  movaps xmm1, [r15+0x1D0]
00007f0254fd57f4  vmovaps [rsp+0x10], xmm1
00007f0254fd57fa  vmovaps xmm15, [rsp+0x10]
00007f0254fd5800  por xmm1, xmm15
00007f0254fd5805  movaps xmm14, [r15+0x1A0]
00007f0254fd580d  vmovaps [rsp+0x10], xmm14
00007f0254fd5813  vmovaps xmm13, [rsp+0x10]
00007f0254fd5819  por xmm14, xmm13
00007f0254fd581e  lea rax, [r12+0x30]
00007f0254fd5823  mov r11, [r13+rax*1]
00007f0254fd5828  lea rax, [r12+0x38]
00007f0254fd582d  mov r10, [r13+rax*1]
00007f0254fd5832  movq xmm13, r11
00007f0254fd5837  movq xmm12, r10
00007f0254fd583c  movq xmm13, xmm13
00007f0254fd5841  vmovaps [rsp+0x10], xmm13
00007f0254fd5847  movq xmm13, xmm13
00007f0254fd584c  movaps [r15+0x130], xmm13
00007f0254fd5854  movq xmm12, xmm12
00007f0254fd5859  vmovaps [rsp+0x20], xmm12
00007f0254fd585f  movq xmm12, xmm12
00007f0254fd5864  movaps [r15+0x280], xmm12
00007f0254fd586c  movaps xmm13, [r15+0x270]
00007f0254fd5874  vmovaps [rsp+0x30], xmm13
00007f0254fd587a  vmovaps xmm12, [rsp+0x30]
00007f0254fd5880  por xmm13, xmm12
00007f0254fd5885  lea rax, [r12+0x20]
00007f0254fd588a  mov r11, [r13+rax*1]
00007f0254fd588f  lea rax, [r12+0x28]
00007f0254fd5894  mov r10, [r13+rax*1]
00007f0254fd5899  movq xmm12, r11
00007f0254fd589e  movq xmm11, r10
00007f0254fd58a3  movq xmm12, xmm12
00007f0254fd58a8  vmovaps [rsp+0x30], xmm12
00007f0254fd58ae  movq xmm12, xmm12
00007f0254fd58b3  movaps [r15+0x150], xmm12
00007f0254fd58bb  movq xmm11, xmm11
00007f0254fd58c0  vmovaps [rsp+0x40], xmm11
00007f0254fd58c6  movq xmm11, xmm11
00007f0254fd58cb  movaps [r15+0x140], xmm11
00007f0254fd58d3  lea rax, [r12+0x10]
00007f0254fd58d8  mov r11, [r13+rax*1]
00007f0254fd58dd  lea rax, [r12+0x18]
00007f0254fd58e2  mov r10, [r13+rax*1]
00007f0254fd58e7  movq xmm12, r11
00007f0254fd58ec  movq xmm11, r10
00007f0254fd58f1  movq xmm12, xmm12
00007f0254fd58f6  vmovaps [rsp+0x50], xmm12
00007f0254fd58fc  movq xmm12, xmm12
00007f0254fd5901  movaps [r15+0x170], xmm12
00007f0254fd5909  movq xmm11, xmm11
00007f0254fd590e  vmovaps [rsp+0x60], xmm11
00007f0254fd5914  movq xmm11, xmm11
00007f0254fd5919  movaps [r15+0x160], xmm11
00007f0254fd5921  mov rax, [r13+r12*1]
00007f0254fd5926  vmovq xmm12, rax
00007f0254fd592b  vpbroadcastq xmm12, xmm12
00007f0254fd5930  lea rax, [r12+0x08]
00007f0254fd5935  mov r12, [r13+rax*1]
00007f0254fd593a  movq xmm11, r12
00007f0254fd593f  movaps [r15+0x230], xmm11
00007f0254fd5947  mov rax, [r15+0xF8]
00007f0254fd594e  lea r12, [rax+0x50]
00007f0254fd5952  movups xmm11, [r13+r12*1]
00007f0254fd5958  lea r12, [rax+0x60]
00007f0254fd595c  movups xmm10, [r13+r12*1]
00007f0254fd5962  lea r12, [rax+0x30]
00007f0254fd5966  movups xmm9, [r13+r12*1]
00007f0254fd596c  mov r12, [r15+0x50]
00007f0254fd5970  lea r11, [r12+r14*1]
00007f0254fd5974  mov [r15+0x60], r11
00007f0254fd5978  lea r12, [r14+0x40]
00007f0254fd597c  mov [r15+0x58], r12
00007f0254fd5980  movaps xmm8, xmm12
00007f0254fd5984  mulpd xmm8, xmm15
00007f0254fd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007f0254fd598f  ptest xmm7, xmm7
00007f0254fd5994  jnz 0x00007F0254FD67B7
00007f0254fd599a  movq xmm15, qword ptr [r15+0x230]
00007f0254fd59a3  vmovaps [rsp+0x70], xmm15
00007f0254fd59a9  vpermilpd xmm15, xmm15, 0x00
00007f0254fd59af  movaps xmm7, xmm9
00007f0254fd59b3  mulpd xmm7, xmm15
00007f0254fd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0254fd59bd  ptest xmm6, xmm6
00007f0254fd59c2  jnz 0x00007F0254FD68FB
00007f0254fd59c8  vxorps xmm15, xmm15, xmm15
00007f0254fd59cd  vpbroadcastq xmm15, xmm15
00007f0254fd59d2  movaps xmm9, xmm12
00007f0254fd59d6  mulpd xmm9, xmm10
00007f0254fd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007f0254fd59e1  ptest xmm6, xmm6
00007f0254fd59e6  jnz 0x00007F0254FD6A3D
00007f0254fd59ec  movaps xmm10, xmm12
00007f0254fd59f0  mulpd xmm10, xmm11
00007f0254fd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007f0254fd59fb  ptest xmm6, xmm6
00007f0254fd5a00  jnz 0x00007F0254FD6B81
00007f0254fd5a06  movaps xmm11, [r15+0x1F0]
00007f0254fd5a0e  movaps xmm6, xmm12
00007f0254fd5a12  mulpd xmm6, xmm11
00007f0254fd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007f0254fd5a1c  ptest xmm5, xmm5
00007f0254fd5a21  jnz 0x00007F0254FD6CC5
00007f0254fd5a27  movaps xmm12, [r15+0x2A0]
00007f0254fd5a2f  vmovaps [rsp+0x80], xmm12
00007f0254fd5a38  vmovaps xmm11, [rsp+0x80]
00007f0254fd5a41  por xmm12, xmm11
00007f0254fd5a46  movaps xmm11, [r15+0x250]
00007f0254fd5a4e  vmovaps [rsp+0x80], xmm11
00007f0254fd5a57  vmovaps xmm5, [rsp+0x80]
00007f0254fd5a60  por xmm11, xmm5
00007f0254fd5a65  vmovaps xmm4, [rsp+0x70]
00007f0254fd5a6b  vpermilpd xmm4, xmm4, 0x00
00007f0254fd5a71  movaps xmm3, xmm5
00007f0254fd5a74  mulpd xmm3, xmm4
00007f0254fd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007f0254fd5a7d  ptest xmm2, xmm2
00007f0254fd5a82  jnz 0x00007F0254FD6E07
00007f0254fd5a88  mov [rsp+0x80], rax
00007f0254fd5a90  xor eax, eax
00007f0254fd5a92  mov r14d, 0x200
00007f0254fd5a98  cmp r12, r14
00007f0254fd5a9b  cmc
00007f0254fd5a9c  lahf
00007f0254fd5a9d  seto al
00007f0254fd5aa0  mov [r15+0x108], eax
00007f0254fd5aa7  movaps xmm5, xmm8
00007f0254fd5aab  addpd xmm5, xmm15
00007f0254fd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007f0254fd5ab5  ptest xmm4, xmm4
00007f0254fd5aba  jnz 0x00007F0254FD6F47
00007f0254fd5ac0  movaps xmm8, [r15+0x1B0]
00007f0254fd5ac8  movaps xmm4, xmm9
00007f0254fd5acc  addpd xmm4, xmm8
00007f0254fd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007f0254fd5ad6  ptest xmm2, xmm2
00007f0254fd5adb  jnz 0x00007F0254FD7089
00007f0254fd5ae1  movaps xmm9, xmm10
00007f0254fd5ae5  addpd xmm9, xmm8
00007f0254fd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007f0254fd5af0  ptest xmm2, xmm2
00007f0254fd5af5  jnz 0x00007F0254FD71CB
00007f0254fd5afb  movaps xmm10, [r15+0x2F0]
00007f0254fd5b03  vmovaps [rsp+0x90], xmm10
00007f0254fd5b0c  vmovaps xmm8, [rsp+0x90]
00007f0254fd5b15  por xmm10, xmm8
00007f0254fd5b1a  movaps xmm8, [r15+0x2E0]
00007f0254fd5b22  vmovaps [rsp+0x90], xmm8
00007f0254fd5b2b  vmovaps xmm2, [rsp+0x90]
00007f0254fd5b34  por xmm8, xmm2
00007f0254fd5b39  movaps xmm2, [r15+0x2D0]
00007f0254fd5b41  vmovaps [rsp+0x90], xmm2
00007f0254fd5b4a  vmovaps [rsp+0xA0], xmm1
00007f0254fd5b53  vmovaps xmm1, [rsp+0x90]
00007f0254fd5b5c  por xmm2, xmm1
00007f0254fd5b60  movaps xmm1, [r15+0x200]
00007f0254fd5b68  vmovaps [rsp+0x90], xmm1
00007f0254fd5b71  vmovaps [rsp+0xB0], xmm15
00007f0254fd5b7a  vmovaps xmm15, [rsp+0x90]
00007f0254fd5b83  por xmm1, xmm15
00007f0254fd5b88  movaps xmm15, [r15+0x1C0]
00007f0254fd5b90  vmovaps [rsp+0x90], xmm15
00007f0254fd5b99  vmovaps [rsp+0xC0], xmm1
00007f0254fd5ba2  vmovaps xmm1, [rsp+0x90]
00007f0254fd5bab  por xmm15, xmm1
00007f0254fd5bb0  movaps xmm1, [r15+0x190]
00007f0254fd5bb8  vmovaps [rsp+0x90], xmm1
00007f0254fd5bc1  vmovaps [rsp+0xD0], xmm15
00007f0254fd5bca  vmovaps xmm15, [rsp+0x90]
00007f0254fd5bd3  por xmm1, xmm15
00007f0254fd5bd8  movaps xmm15, [r15+0x300]
00007f0254fd5be0  vmovaps [rsp+0x90], xmm15
00007f0254fd5be9  vmovaps [rsp+0xE0], xmm1
00007f0254fd5bf2  vmovaps xmm1, [rsp+0x90]
00007f0254fd5bfb  por xmm15, xmm1
00007f0254fd5c00  mov rax, [rsp+0x80]
00007f0254fd5c08  lea r14, [rax+0xA0]
00007f0254fd5c0f  movups xmm1, [r13+r14*1]
00007f0254fd5c15  lea r14, [rax+0xB0]
00007f0254fd5c1c  vmovaps [rsp+0x80], xmm1
00007f0254fd5c25  movups xmm1, [r13+r14*1]
00007f0254fd5c2b  vmovaps [rsp+0x90], xmm1
00007f0254fd5c34  vmovaps [rsp+0xF0], xmm15
00007f0254fd5c3d  vmovaps xmm15, [rsp+0xB0]
00007f0254fd5c46  vmovaps [rsp+0xB0], xmm14
00007f0254fd5c4f  movaps xmm1, xmm6
00007f0254fd5c52  addpd xmm1, xmm15
00007f0254fd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007f0254fd5c5c  ptest xmm14, xmm14
00007f0254fd5c62  jnz 0x00007F0254FD7323
00007f0254fd5c68  lea r14, [rax+0xF0]
00007f0254fd5c6f  movups xmm15, [r13+r14*1]
00007f0254fd5c75  movaps xmm14, xmm4
00007f0254fd5c79  addpd xmm14, xmm3
00007f0254fd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007f0254fd5c84  ptest xmm6, xmm6
00007f0254fd5c89  jnz 0x00007F0254FD746E
00007f0254fd5c8f  movaps xmm6, xmm9
00007f0254fd5c93  addpd xmm6, xmm7
00007f0254fd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007f0254fd5c9c  ptest xmm4, xmm4
00007f0254fd5ca1  jnz 0x00007F0254FD75B0
00007f0254fd5ca7  vmovaps xmm9, [rsp+0x70]
00007f0254fd5cad  vpermilpd xmm9, xmm9, 0x00
00007f0254fd5cb3  vmovaps xmm4, [rsp+0x90]
00007f0254fd5cbc  movaps xmm7, xmm4
00007f0254fd5cbf  mulpd xmm7, xmm9
00007f0254fd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007f0254fd5cc9  ptest xmm3, xmm3
00007f0254fd5cce  jnz 0x00007F0254FD76F1
00007f0254fd5cd4  vmovaps xmm9, [rsp+0x50]
00007f0254fd5cda  vpermilpd xmm9, xmm9, 0x00
00007f0254fd5ce0  movaps xmm4, xmm15
00007f0254fd5ce4  mulpd xmm4, xmm9
00007f0254fd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007f0254fd5cee  ptest xmm3, xmm3
00007f0254fd5cf3  jnz 0x00007F0254FD7832
00007f0254fd5cf9  lea r14, [rax+0xE0]
00007f0254fd5d00  movups xmm15, [r13+r14*1]
00007f0254fd5d06  vmovaps xmm9, [rsp+0x70]
00007f0254fd5d0c  vpermilpd xmm9, xmm9, 0x00
00007f0254fd5d12  vmovaps [rsp+0x70], xmm1
00007f0254fd5d18  vmovaps xmm1, [rsp+0x80]
00007f0254fd5d21  vmovaps [rsp+0x80], xmm15
00007f0254fd5d2a  movaps xmm3, xmm1
00007f0254fd5d2d  mulpd xmm3, xmm9
00007f0254fd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007f0254fd5d37  ptest xmm15, xmm15
00007f0254fd5d3d  jnz 0x00007F0254FD797E
00007f0254fd5d43  vmovaps xmm1, [rsp+0xF0]
00007f0254fd5d4c  vmovaps xmm15, [rsp+0xF0]
00007f0254fd5d55  por xmm1, xmm15
00007f0254fd5d5a  movaps [r15+0x300], xmm1
00007f0254fd5d62  vmovaps xmm15, [rsp+0xE0]
00007f0254fd5d6b  vmovaps xmm9, [rsp+0xE0]
00007f0254fd5d74  por xmm15, xmm9
00007f0254fd5d79  movaps [r15+0x190], xmm15
00007f0254fd5d81  vmovaps xmm9, [rsp+0x50]
00007f0254fd5d87  vpermilpd xmm9, xmm9, 0x00
00007f0254fd5d8d  vmovaps [rsp+0x90], xmm1
00007f0254fd5d96  vmovaps [rsp+0xE0], xmm15
00007f0254fd5d9f  vmovaps xmm15, [rsp+0x80]
00007f0254fd5da8  vmovaps [rsp+0x80], xmm14
00007f0254fd5db1  movaps xmm1, xmm15
00007f0254fd5db5  mulpd xmm1, xmm9
00007f0254fd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007f0254fd5dbf  ptest xmm14, xmm14
00007f0254fd5dc5  jnz 0x00007F0254FD7ABF
00007f0254fd5dcb  lea r14, [rax+0x90]
00007f0254fd5dd2  movups xmm15, [r13+r14*1]
00007f0254fd5dd8  vmovaps xmm14, [rsp+0xD0]
00007f0254fd5de1  vmovaps xmm9, [rsp+0xD0]
00007f0254fd5dea  por xmm14, xmm9
00007f0254fd5def  movaps [r15+0x1C0], xmm14
00007f0254fd5df7  vmovaps xmm9, [rsp+0xC0]
00007f0254fd5e00  vmovaps [rsp+0xD0], xmm1
00007f0254fd5e09  vmovaps xmm1, [rsp+0xC0]
00007f0254fd5e12  por xmm9, xmm1
00007f0254fd5e17  movaps [r15+0x200], xmm9
00007f0254fd5e1f  vmovaps [rsp+0xC0], xmm2
00007f0254fd5e28  vmovaps xmm1, [rsp+0xC0]
00007f0254fd5e31  por xmm2, xmm1
00007f0254fd5e35  movaps [r15+0x2D0], xmm2
00007f0254fd5e3d  vmovaps [rsp+0xC0], xmm8
00007f0254fd5e46  vmovaps xmm1, [rsp+0xC0]
00007f0254fd5e4f  por xmm8, xmm1
00007f0254fd5e54  movaps [r15+0x2E0], xmm8
00007f0254fd5e5c  vmovaps [rsp+0xC0], xmm15
00007f0254fd5e65  movaps xmm1, xmm5
00007f0254fd5e68  addpd xmm1, xmm7
00007f0254fd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007f0254fd5e71  ptest xmm15, xmm15
00007f0254fd5e77  jnz 0x00007F0254FD7C0B
00007f0254fd5e7d  vmovaps xmm15, [rsp+0x50]
00007f0254fd5e83  vpermilpd xmm15, xmm15, 0x00
00007f0254fd5e89  vmovaps xmm5, [rsp+0xC0]
00007f0254fd5e92  vmovaps [rsp+0xC0], xmm1
00007f0254fd5e9b  movaps xmm7, xmm5
00007f0254fd5e9e  mulpd xmm7, xmm15
00007f0254fd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007f0254fd5ea8  ptest xmm1, xmm1
00007f0254fd5ead  jnz 0x00007F0254FD7D4B
00007f0254fd5eb3  lea r14, [rax+0x80]
00007f0254fd5eba  movups xmm1, [r13+r14*1]
00007f0254fd5ec0  vmovaps xmm5, [rsp+0x70]
00007f0254fd5ec6  vmovaps [rsp+0x70], xmm1
00007f0254fd5ecc  movaps xmm15, xmm5
00007f0254fd5ed0  addpd xmm15, xmm3
00007f0254fd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0254fd5edb  ptest xmm1, xmm1
00007f0254fd5ee0  jnz 0x00007F0254FD7E96
00007f0254fd5ee6  vmovaps xmm5, [rsp+0x80]
00007f0254fd5eef  movaps xmm1, xmm5
00007f0254fd5ef2  addpd xmm1, xmm4
00007f0254fd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007f0254fd5efb  ptest xmm3, xmm3
00007f0254fd5f00  jnz 0x00007F0254FD7FD8
00007f0254fd5f06  vmovaps [rsp+0x80], xmm10
00007f0254fd5f0f  vmovaps xmm5, [rsp+0x80]
00007f0254fd5f18  por xmm10, xmm5
00007f0254fd5f1d  movaps [r15+0x2F0], xmm10
00007f0254fd5f25  vmovaps xmm5, [rsp+0x50]
00007f0254fd5f2b  vpermilpd xmm5, xmm5, 0x00
00007f0254fd5f31  vmovaps xmm3, [rsp+0x70]
00007f0254fd5f37  vmovaps [rsp+0x50], xmm1
00007f0254fd5f3d  movaps xmm4, xmm3
00007f0254fd5f40  mulpd xmm4, xmm5
00007f0254fd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007f0254fd5f49  ptest xmm1, xmm1
00007f0254fd5f4e  jnz 0x00007F0254FD8118
00007f0254fd5f54  lea r14, [rax+0xD0]
00007f0254fd5f5b  movups xmm1, [r13+r14*1]
00007f0254fd5f61  vmovaps xmm3, [rsp+0xD0]
00007f0254fd5f6a  vmovaps [rsp+0x70], xmm1
00007f0254fd5f70  movaps xmm5, xmm6
00007f0254fd5f73  addpd xmm5, xmm3
00007f0254fd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007f0254fd5f7c  ptest xmm1, xmm1
00007f0254fd5f81  jnz 0x00007F0254FD8262
00007f0254fd5f87  vmovaps xmm1, [rsp+0x60]
00007f0254fd5f8d  vpermilpd xmm1, xmm1, 0x00
00007f0254fd5f93  movaps xmm6, xmm9
00007f0254fd5f97  mulpd xmm6, xmm1
00007f0254fd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007f0254fd5fa0  ptest xmm3, xmm3
00007f0254fd5fa5  jnz 0x00007F0254FD83A2
00007f0254fd5fab  movaps [r15+0x260], xmm6
00007f0254fd5fb3  vxorps xmm1, xmm1, xmm1
00007f0254fd5fb7  vpbroadcastq xmm1, xmm1
00007f0254fd5fbc  movaps [r15+0x1B0], xmm1
00007f0254fd5fc4  vmovaps xmm1, [rsp+0x60]
00007f0254fd5fca  vpermilpd xmm1, xmm1, 0x00
00007f0254fd5fd0  vmovaps xmm3, [rsp+0x70]
00007f0254fd5fd6  vmovaps [rsp+0x70], xmm15
00007f0254fd5fdc  movaps xmm9, xmm3
00007f0254fd5fe0  mulpd xmm9, xmm1
00007f0254fd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007f0254fd5feb  ptest xmm15, xmm15
00007f0254fd5ff1  jnz 0x00007F0254FD84E3
00007f0254fd5ff7  lea r14, [rax+0xC0]
00007f0254fd5ffe  movups xmm1, [r13+r14*1]
00007f0254fd6004  vmovaps xmm3, [rsp+0xC0]
00007f0254fd600d  vmovaps [rsp+0x80], xmm1
00007f0254fd6016  movaps xmm15, xmm3
00007f0254fd601a  addpd xmm15, xmm7
00007f0254fd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0254fd6025  ptest xmm1, xmm1
00007f0254fd602a  jnz 0x00007F0254FD862F
00007f0254fd6030  vmovaps [rsp+0xC0], xmm13
00007f0254fd6039  vmovaps xmm1, [rsp+0xC0]
00007f0254fd6042  por xmm13, xmm1
00007f0254fd6047  movaps [r15+0x270], xmm13
00007f0254fd604f  vmovaps xmm1, [rsp+0xB0]
00007f0254fd6058  vmovaps xmm7, [rsp+0xB0]
00007f0254fd6061  por xmm1, xmm7
00007f0254fd6065  movaps [r15+0x1A0], xmm1
00007f0254fd606d  vmovaps xmm1, [rsp+0x60]
00007f0254fd6073  vpermilpd xmm1, xmm1, 0x00
00007f0254fd6079  vmovaps [rsp+0xB0], xmm1
00007f0254fd6082  vmovaps xmm1, [rsp+0x80]
00007f0254fd608b  vmovaps [rsp+0x80], xmm15
00007f0254fd6094  vmovaps xmm15, [rsp+0xB0]
00007f0254fd609d  vmovaps [rsp+0xB0], xmm14
00007f0254fd60a6  movaps xmm3, xmm1
00007f0254fd60a9  mulpd xmm3, xmm15
00007f0254fd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007f0254fd60b3  ptest xmm14, xmm14
00007f0254fd60b9  jnz 0x00007F0254FD8771
00007f0254fd60bf  lea r14, [rax+0x20]
00007f0254fd60c3  movups xmm1, [r13+r14*1]
00007f0254fd60c9  movaps [r15+0x110], xmm1
00007f0254fd60d1  vmovaps xmm14, [rsp+0x70]
00007f0254fd60d7  vmovaps [rsp+0x70], xmm1
00007f0254fd60dd  movaps xmm15, xmm14
00007f0254fd60e1  addpd xmm15, xmm4
00007f0254fd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0254fd60ec  ptest xmm1, xmm1
00007f0254fd60f1  jnz 0x00007F0254FD88BC
00007f0254fd60f7  vmovaps xmm1, [rsp+0x60]
00007f0254fd60fd  vpermilpd xmm1, xmm1, 0x00
00007f0254fd6103  movaps xmm14, xmm2
00007f0254fd6107  mulpd xmm14, xmm1
00007f0254fd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007f0254fd6112  ptest xmm4, xmm4
00007f0254fd6117  jnz 0x00007F0254FD89FF
00007f0254fd611d  vmovaps xmm4, [rsp+0x50]
00007f0254fd6123  movaps xmm1, xmm4
00007f0254fd6126  addpd xmm1, xmm9
00007f0254fd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007f0254fd6130  ptest xmm2, xmm2
00007f0254fd6135  jnz 0x00007F0254FD8B41
00007f0254fd613b  vmovaps xmm9, [rsp+0x30]
00007f0254fd6141  vpermilpd xmm9, xmm9, 0x00
00007f0254fd6147  vmovaps xmm2, [rsp+0x70]
00007f0254fd614d  vmovaps [rsp+0x50], xmm1
00007f0254fd6153  movaps xmm4, xmm2
00007f0254fd6156  mulpd xmm4, xmm9
00007f0254fd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007f0254fd6160  ptest xmm1, xmm1
00007f0254fd6165  jnz 0x00007F0254FD8C82
00007f0254fd616b  vmovaps xmm1, [rsp+0x30]
00007f0254fd6171  vpermilpd xmm1, xmm1, 0x00
00007f0254fd6177  vmovaps xmm2, [rsp+0x90]
00007f0254fd6180  vmovaps [rsp+0x60], xmm15
00007f0254fd6186  movaps xmm9, xmm2
00007f0254fd618a  mulpd xmm9, xmm1
00007f0254fd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007f0254fd6195  ptest xmm15, xmm15
00007f0254fd619b  jnz 0x00007F0254FD8DC3
00007f0254fd61a1  vmovaps xmm15, [rsp+0x80]
00007f0254fd61aa  movaps xmm1, xmm15
00007f0254fd61ae  addpd xmm1, xmm6
00007f0254fd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007f0254fd61b7  ptest xmm2, xmm2
00007f0254fd61bc  jnz 0x00007F0254FD8F05
00007f0254fd61c2  movaps xmm15, xmm5
00007f0254fd61c6  addpd xmm15, xmm3
00007f0254fd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007f0254fd61d1  ptest xmm6, xmm6
00007f0254fd61d6  jnz 0x00007F0254FD9046
00007f0254fd61dc  vmovaps xmm6, [rsp+0x30]
00007f0254fd61e2  vpermilpd xmm6, xmm6, 0x00
00007f0254fd61e8  movaps xmm5, xmm8
00007f0254fd61ec  mulpd xmm5, xmm6
00007f0254fd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007f0254fd61f5  ptest xmm3, xmm3
00007f0254fd61fa  jnz 0x00007F0254FD9188
00007f0254fd6200  vmovaps xmm8, [rsp+0x30]
00007f0254fd6206  vpermilpd xmm8, xmm8, 0x00
00007f0254fd620c  movaps xmm6, xmm10
00007f0254fd6210  mulpd xmm6, xmm8
00007f0254fd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007f0254fd621a  ptest xmm3, xmm3
00007f0254fd621f  jnz 0x00007F0254FD92C9
00007f0254fd6225  vmovaps xmm8, [rsp+0x60]
00007f0254fd622b  movaps xmm10, xmm8
00007f0254fd622f  addpd xmm10, xmm14
00007f0254fd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007f0254fd623a  ptest xmm3, xmm3
00007f0254fd623f  jnz 0x00007F0254FD940B
00007f0254fd6245  vmovaps xmm8, [rsp+0x50]
00007f0254fd624b  movaps xmm14, xmm8
00007f0254fd624f  addpd xmm14, xmm4
00007f0254fd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007f0254fd625a  ptest xmm3, xmm3
00007f0254fd625f  jnz 0x00007F0254FD954F
00007f0254fd6265  vmovaps xmm8, [rsp+0x40]
00007f0254fd626b  vpermilpd xmm8, xmm8, 0x00
00007f0254fd6271  movaps xmm4, xmm13
00007f0254fd6275  mulpd xmm4, xmm8
00007f0254fd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007f0254fd627f  ptest xmm3, xmm3
00007f0254fd6284  jnz 0x00007F0254FD9692
00007f0254fd628a  movaps xmm13, xmm15
00007f0254fd628e  addpd xmm13, xmm9
00007f0254fd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007f0254fd6299  ptest xmm8, xmm8
00007f0254fd629f  jnz 0x00007F0254FD97D4
00007f0254fd62a5  movaps xmm15, xmm1
00007f0254fd62a9  addpd xmm15, xmm5
00007f0254fd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007f0254fd62b4  ptest xmm9, xmm9
00007f0254fd62ba  jnz 0x00007F0254FD9918
00007f0254fd62c0  vmovaps [rsp+0x30], xmm11
00007f0254fd62c6  vmovaps xmm1, [rsp+0x30]
00007f0254fd62cc  por xmm11, xmm1
00007f0254fd62d1  movaps [r15+0x250], xmm11
00007f0254fd62d9  vmovaps [rsp+0x30], xmm12
00007f0254fd62df  vmovaps xmm1, [rsp+0x30]
00007f0254fd62e5  por xmm12, xmm1
00007f0254fd62ea  movaps [r15+0x2A0], xmm12
00007f0254fd62f2  vmovaps xmm1, [rsp+0xA0]
00007f0254fd62fb  vmovaps xmm11, [rsp+0xA0]
00007f0254fd6304  por xmm1, xmm11
00007f0254fd6309  movaps [r15+0x1D0], xmm1
00007f0254fd6311  lea r14, [rax+0x40]
00007f0254fd6315  movups xmm1, [r13+r14*1]
00007f0254fd631b  movaps [r15+0x2C0], xmm1
00007f0254fd6323  vmovaps xmm11, [rsp+0x40]
00007f0254fd6329  vpermilpd xmm11, xmm11, 0x00
00007f0254fd632f  vmovaps xmm8, [rsp+0xE0]
00007f0254fd6338  movaps xmm9, xmm8
00007f0254fd633c  mulpd xmm9, xmm11
00007f0254fd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007f0254fd6347  ptest xmm5, xmm5
00007f0254fd634c  jnz 0x00007F0254FD9A64
00007f0254fd6352  movaps xmm11, xmm10
00007f0254fd6356  addpd xmm11, xmm6
00007f0254fd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007f0254fd6361  ptest xmm8, xmm8
00007f0254fd6367  jnz 0x00007F0254FD9BA8
00007f0254fd636d  movaps xmm10, xmm14
00007f0254fd6371  addpd xmm10, xmm4
00007f0254fd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007f0254fd637c  ptest xmm8, xmm8
00007f0254fd6382  jnz 0x00007F0254FD9CEB
00007f0254fd6388  vmovaps xmm14, [rsp+0x40]
00007f0254fd638e  vpermilpd xmm14, xmm14, 0x00
00007f0254fd6394  movaps xmm8, xmm1
00007f0254fd6398  mulpd xmm8, xmm14
00007f0254fd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007f0254fd63a3  ptest xmm6, xmm6
00007f0254fd63a8  jnz 0x00007F0254FD9E2E
00007f0254fd63ae  movaps xmm1, [r15+0x2B0]
00007f0254fd63b6  vmovaps xmm14, [rsp+0x40]
00007f0254fd63bc  vpermilpd xmm14, xmm14, 0x00
00007f0254fd63c2  movaps xmm6, xmm1
00007f0254fd63c5  mulpd xmm6, xmm14
00007f0254fd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007f0254fd63cf  ptest xmm5, xmm5
00007f0254fd63d4  jnz 0x00007F0254FD9F71
00007f0254fd63da  vmovaps xmm1, [rsp+0x10]
00007f0254fd63e0  vpermilpd xmm1, xmm1, 0x00
00007f0254fd63e6  movaps xmm14, xmm12
00007f0254fd63ea  mulpd xmm14, xmm1
00007f0254fd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007f0254fd63f5  ptest xmm5, xmm5
00007f0254fd63fa  jnz 0x00007F0254FDA0B2
00007f0254fd6400  movaps xmm1, xmm13
00007f0254fd6404  addpd xmm1, xmm9
00007f0254fd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007f0254fd640e  ptest xmm12, xmm12
00007f0254fd6414  jnz 0x00007F0254FDA1F5
00007f0254fd641a  vmovaps xmm13, [rsp+0x10]
00007f0254fd6420  vpermilpd xmm13, xmm13, 0x00
00007f0254fd6426  movaps xmm12, xmm7
00007f0254fd642a  mulpd xmm12, xmm13
00007f0254fd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007f0254fd6435  ptest xmm9, xmm9
00007f0254fd643b  jnz 0x00007F0254FDA337
00007f0254fd6441  movaps xmm13, xmm15
00007f0254fd6445  addpd xmm13, xmm8
00007f0254fd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007f0254fd6450  ptest xmm9, xmm9
00007f0254fd6456  jnz 0x00007F0254FDA47A
00007f0254fd645c  movaps xmm15, [r15+0x290]
00007f0254fd6464  vmovaps xmm9, [rsp+0x10]
00007f0254fd646a  vpermilpd xmm9, xmm9, 0x00
00007f0254fd6470  movaps xmm8, xmm15
00007f0254fd6474  mulpd xmm8, xmm9
00007f0254fd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007f0254fd647f  ptest xmm7, xmm7
00007f0254fd6484  jnz 0x00007F0254FDA5BE
00007f0254fd648a  movaps xmm15, xmm11
00007f0254fd648e  addpd xmm15, xmm6
00007f0254fd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007f0254fd6499  ptest xmm9, xmm9
00007f0254fd649f  jnz 0x00007F0254FDA702
00007f0254fd64a5  movaps xmm11, [r15+0x1E0]
00007f0254fd64ad  vmovaps xmm9, [rsp+0x10]
00007f0254fd64b3  vpermilpd xmm9, xmm9, 0x00
00007f0254fd64b9  movaps xmm7, xmm11
00007f0254fd64bd  mulpd xmm7, xmm9
00007f0254fd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0254fd64c7  ptest xmm6, xmm6
00007f0254fd64cc  jnz 0x00007F0254FDA845
00007f0254fd64d2  movaps xmm11, xmm10
00007f0254fd64d6  addpd xmm11, xmm14
00007f0254fd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007f0254fd64e1  ptest xmm9, xmm9
00007f0254fd64e7  jnz 0x00007F0254FDA987
00007f0254fd64ed  lea r14, [rax+0x70]
00007f0254fd64f1  movups xmm14, [r13+r14*1]
00007f0254fd64f7  movaps [r15+0x240], xmm14
00007f0254fd64ff  movaps xmm10, xmm1
00007f0254fd6503  addpd xmm10, xmm12
00007f0254fd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007f0254fd650e  ptest xmm9, xmm9
00007f0254fd6514  jnz 0x00007F0254FDAAD5
00007f0254fd651a  movaps [r15+0x170], xmm10
00007f0254fd6522  vmovaps xmm1, [rsp+0x20]
00007f0254fd6528  vpermilpd xmm1, xmm1, 0x00
00007f0254fd652e  movaps xmm12, xmm14
00007f0254fd6532  mulpd xmm12, xmm1
00007f0254fd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007f0254fd653d  ptest xmm9, xmm9
00007f0254fd6543  jnz 0x00007F0254FDAC18
00007f0254fd6549  vmovaps xmm1, [rsp+0x20]
00007f0254fd654f  vpermilpd xmm1, xmm1, 0x00
00007f0254fd6555  vmovaps xmm9, [rsp+0xB0]
00007f0254fd655e  movaps xmm14, xmm9
00007f0254fd6562  mulpd xmm14, xmm1
00007f0254fd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007f0254fd656d  ptest xmm6, xmm6
00007f0254fd6572  jnz 0x00007F0254FDAD5B
00007f0254fd6578  movaps [r15+0x180], xmm14
00007f0254fd6580  movaps xmm1, xmm13
00007f0254fd6584  addpd xmm1, xmm8
00007f0254fd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007f0254fd658e  ptest xmm9, xmm9
00007f0254fd6594  jnz 0x00007F0254FDAE9E
00007f0254fd659a  movaps [r15+0x210], xmm1
00007f0254fd65a2  movups xmm13, [r13+rax*1]
00007f0254fd65a8  lea r14, [rax+0x10]
00007f0254fd65ac  movups xmm9, [r13+r14*1]
00007f0254fd65b2  movaps [r15+0x230], xmm9
00007f0254fd65ba  movaps xmm8, xmm15
00007f0254fd65be  addpd xmm8, xmm7
00007f0254fd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007f0254fd65c9  ptest xmm6, xmm6
00007f0254fd65ce  jnz 0x00007F0254FDAFF4
00007f0254fd65d4  movaps [r15+0x130], xmm8
00007f0254fd65dc  vmovaps xmm15, [rsp+0x20]
00007f0254fd65e2  vpermilpd xmm15, xmm15, 0x00
00007f0254fd65e8  movaps xmm7, xmm9
00007f0254fd65ec  mulpd xmm7, xmm15
00007f0254fd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0254fd65f6  ptest xmm6, xmm6
00007f0254fd65fb  jnz 0x00007F0254FDB137
00007f0254fd6601  movaps [r15+0x220], xmm7
00007f0254fd6609  vmovaps xmm15, [rsp+0x20]
00007f0254fd660f  vpermilpd xmm15, xmm15, 0x00
00007f0254fd6615  movaps xmm9, xmm13
00007f0254fd6619  mulpd xmm9, xmm15
00007f0254fd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007f0254fd6624  ptest xmm6, xmm6
00007f0254fd6629  jnz 0x00007F0254FDB279
00007f0254fd662f  movaps xmm15, xmm11
00007f0254fd6633  addpd xmm15, xmm12
00007f0254fd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007f0254fd663e  ptest xmm13, xmm13
00007f0254fd6644  jnz 0x00007F0254FDB3BD
00007f0254fd664a  movaps [r15+0x140], xmm15
00007f0254fd6652  movaps xmm13, xmm10
00007f0254fd6656  addpd xmm13, xmm14
00007f0254fd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007f0254fd6661  ptest xmm12, xmm12
00007f0254fd6667  jnz 0x00007F0254FDB501
00007f0254fd666d  movaps [r15+0x150], xmm13
00007f0254fd6675  movaps xmm14, xmm1
00007f0254fd6679  addpd xmm14, xmm7
00007f0254fd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007f0254fd6684  ptest xmm12, xmm12
00007f0254fd668a  jnz 0x00007F0254FDB645
00007f0254fd6690  movaps [r15+0x160], xmm14
00007f0254fd6698  movaps xmm1, xmm8
00007f0254fd669c  addpd xmm1, xmm9
00007f0254fd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007f0254fd66a6  ptest xmm12, xmm12
00007f0254fd66ac  jnz 0x00007F0254FDB787
00007f0254fd66b2  movaps [r15+0x120], xmm1
00007f0254fd66ba  movups [r13+r11*1], xmm15
00007f0254fd66c0  lea rax, [r11+0x10]
00007f0254fd66c4  movups [r13+rax*1], xmm13
00007f0254fd66ca  lea rax, [r11+0x20]
00007f0254fd66ce  movups [r13+rax*1], xmm14
00007f0254fd66d4  lea rax, [r11+0x30]
00007f0254fd66d8  movups [r13+rax*1], xmm1
00007f0254fd66de  mov eax, [r15+0x108]
00007f0254fd66e5  sahf
00007f0254fd66e6  jnz 0x00007F0254FD6718
00007f0254fd66e8  cmp dword ptr [r15+0x318], 0x00
00007f0254fd66f0  jz 0x00007F0254FDB900
00007f0254fd66f6  nop [rax+rax*1], ax
00007f0254fd66ff  nop [rax+rax*1], eax
00007f0254fd6707  mov eax, 0x410444
00007f0254fd670c  mov [r15+0x100], rax
00007f0254fd6713  jmp 0x00007F0254DFE110
00007f0254fd6718  cmp dword ptr [r15+0x318], 0x00
00007f0254fd6720  jz 0x00007F0254FD57E0
00007f0254fd6726  nop [rax+rax*1], ax
00007f0254fd672f  nop [rax+rax*1], eax
00007f0254fd6737  mov eax, 0x410278
00007f0254fd673c  mov [r15+0x100], rax
00007f0254fd6743  jmp 0x00007F0254DFE110
00007f0254fd6748  int3
00007f0254fd6749  call 0x00007F0254E0A4B0
00007f0254fd674e  jmp 0x00007F0254FD5828
00007f0254fd6753  call 0x00007F0254E09240
00007f0254fd6758  jmp 0x00007F0254FD5832
00007f0254fd675d  call 0x00007F0254E0A4B0
00007f0254fd6762  jmp 0x00007F0254FD588F
00007f0254fd6767  call 0x00007F0254E09240
00007f0254fd676c  jmp 0x00007F0254FD5899
00007f0254fd6771  call 0x00007F0254E0A4B0
00007f0254fd6776  jmp 0x00007F0254FD58DD
00007f0254fd677b  call 0x00007F0254E09240
00007f0254fd6780  jmp 0x00007F0254FD58E7
00007f0254fd6785  call 0x00007F0254EB47C0
00007f0254fd678a  jmp 0x00007F0254FD5926
00007f0254fd678f  call 0x00007F0254E0B720
00007f0254fd6794  jmp 0x00007F0254FD593A
00007f0254fd6799  call 0x00007F0254EBFC30
00007f0254fd679e  jmp 0x00007F0254FD5958
00007f0254fd67a3  call 0x00007F0254EBE9C0
00007f0254fd67a8  jmp 0x00007F0254FD5962
00007f0254fd67ad  call 0x00007F0254EBD750
00007f0254fd67b2  jmp 0x00007F0254FD596C
00007f0254fd67b7  sub rsp, 0x08
00007f0254fd67bb  push rax
00007f0254fd67bc  push rcx
00007f0254fd67bd  push rdx
00007f0254fd67be  push rdi
00007f0254fd67bf  push rsi
00007f0254fd67c0  push r8
00007f0254fd67c2  push r9
00007f0254fd67c4  push r10
00007f0254fd67c6  push r11
00007f0254fd67c8  sub rsp, 0xF0
00007f0254fd67cf  vmovaps [rsp], xmm0
00007f0254fd67d4  vmovaps [rsp+0x10], xmm1
00007f0254fd67da  vmovaps [rsp+0x20], xmm2
00007f0254fd67e0  vmovaps [rsp+0x30], xmm3
00007f0254fd67e6  vmovaps [rsp+0x40], xmm4
00007f0254fd67ec  vmovaps [rsp+0x50], xmm5
00007f0254fd67f2  vmovaps [rsp+0x60], xmm6
00007f0254fd67f8  vmovaps [rsp+0x70], xmm7
00007f0254fd67fe  vmovaps [rsp+0x80], xmm9
00007f0254fd6807  vmovaps [rsp+0x90], xmm10
00007f0254fd6810  vmovaps [rsp+0xA0], xmm11
00007f0254fd6819  vmovaps [rsp+0xB0], xmm12
00007f0254fd6822  vmovaps [rsp+0xC0], xmm13
00007f0254fd682b  vmovaps [rsp+0xD0], xmm14
00007f0254fd6834  vmovaps [rsp+0xE0], xmm15
00007f0254fd683d  sub rsp, 0x30
00007f0254fd6841  movaps [rsp], xmm8
00007f0254fd6846  movaps [rsp+0x10], xmm12
00007f0254fd684c  movaps [rsp+0x20], xmm15
00007f0254fd6852  lea rdi, [rsp]
00007f0254fd6856  mov esi, 0x00
00007f0254fd685b  mov rax, 0x55DD1360A530
00007f0254fd6865  call rax
00007f0254fd6867  movaps xmm8, [rsp]
00007f0254fd686c  add rsp, 0x30
00007f0254fd6870  vmovaps xmm0, [rsp]
00007f0254fd6875  vmovaps xmm1, [rsp+0x10]
00007f0254fd687b  vmovaps xmm2, [rsp+0x20]
00007f0254fd6881  vmovaps xmm3, [rsp+0x30]
00007f0254fd6887  vmovaps xmm4, [rsp+0x40]
00007f0254fd688d  vmovaps xmm5, [rsp+0x50]
00007f0254fd6893  vmovaps xmm6, [rsp+0x60]
00007f0254fd6899  vmovaps xmm7, [rsp+0x70]
00007f0254fd689f  vmovaps xmm9, [rsp+0x80]
00007f0254fd68a8  vmovaps xmm10, [rsp+0x90]
00007f0254fd68b1  vmovaps xmm11, [rsp+0xA0]
00007f0254fd68ba  vmovaps xmm12, [rsp+0xB0]
00007f0254fd68c3  vmovaps xmm13, [rsp+0xC0]
00007f0254fd68cc  vmovaps xmm14, [rsp+0xD0]
00007f0254fd68d5  vmovaps xmm15, [rsp+0xE0]
00007f0254fd68de  add rsp, 0xF0
00007f0254fd68e5  pop r11
00007f0254fd68e7  pop r10
00007f0254fd68e9  pop r9
00007f0254fd68eb  pop r8
00007f0254fd68ed  pop rsi
00007f0254fd68ee  pop rdi
00007f0254fd68ef  pop rdx
00007f0254fd68f0  pop rcx
00007f0254fd68f1  pop rax
00007f0254fd68f2  add rsp, 0x08
00007f0254fd68f6  jmp 0x00007F0254FD599A
00007f0254fd68fb  sub rsp, 0x08
00007f0254fd68ff  push rax
00007f0254fd6900  push rcx
00007f0254fd6901  push rdx
00007f0254fd6902  push rdi
00007f0254fd6903  push rsi
00007f0254fd6904  push r8
00007f0254fd6906  push r9
00007f0254fd6908  push r10
00007f0254fd690a  push r11
00007f0254fd690c  sub rsp, 0xF0
00007f0254fd6913  vmovaps [rsp], xmm0
00007f0254fd6918  vmovaps [rsp+0x10], xmm1
00007f0254fd691e  vmovaps [rsp+0x20], xmm2
00007f0254fd6924  vmovaps [rsp+0x30], xmm3
00007f0254fd692a  vmovaps [rsp+0x40], xmm4
00007f0254fd6930  vmovaps [rsp+0x50], xmm5
00007f0254fd6936  vmovaps [rsp+0x60], xmm6
00007f0254fd693c  vmovaps [rsp+0x70], xmm8
00007f0254fd6942  vmovaps [rsp+0x80], xmm9
00007f0254fd694b  vmovaps [rsp+0x90], xmm10
00007f0254fd6954  vmovaps [rsp+0xA0], xmm11
00007f0254fd695d  vmovaps [rsp+0xB0], xmm12
00007f0254fd6966  vmovaps [rsp+0xC0], xmm13
00007f0254fd696f  vmovaps [rsp+0xD0], xmm14
00007f0254fd6978  vmovaps [rsp+0xE0], xmm15
00007f0254fd6981  sub rsp, 0x30
00007f0254fd6985  movaps [rsp], xmm7
00007f0254fd6989  movaps [rsp+0x10], xmm9
00007f0254fd698f  movaps [rsp+0x20], xmm15
00007f0254fd6995  lea rdi, [rsp]
00007f0254fd6999  mov esi, 0x00
00007f0254fd699e  mov rax, 0x55DD1360A530
00007f0254fd69a8  call rax
00007f0254fd69aa  movaps xmm7, [rsp]
00007f0254fd69ae  add rsp, 0x30
00007f0254fd69b2  vmovaps xmm0, [rsp]
00007f0254fd69b7  vmovaps xmm1, [rsp+0x10]
00007f0254fd69bd  vmovaps xmm2, [rsp+0x20]
00007f0254fd69c3  vmovaps xmm3, [rsp+0x30]
00007f0254fd69c9  vmovaps xmm4, [rsp+0x40]
00007f0254fd69cf  vmovaps xmm5, [rsp+0x50]
00007f0254fd69d5  vmovaps xmm6, [rsp+0x60]
00007f0254fd69db  vmovaps xmm8, [rsp+0x70]
00007f0254fd69e1  vmovaps xmm9, [rsp+0x80]
00007f0254fd69ea  vmovaps xmm10, [rsp+0x90]
00007f0254fd69f3  vmovaps xmm11, [rsp+0xA0]
00007f0254fd69fc  vmovaps xmm12, [rsp+0xB0]
00007f0254fd6a05  vmovaps xmm13, [rsp+0xC0]
00007f0254fd6a0e  vmovaps xmm14, [rsp+0xD0]
00007f0254fd6a17  vmovaps xmm15, [rsp+0xE0]
00007f0254fd6a20  add rsp, 0xF0
00007f0254fd6a27  pop r11
00007f0254fd6a29  pop r10
00007f0254fd6a2b  pop r9
00007f0254fd6a2d  pop r8
00007f0254fd6a2f  pop rsi
00007f0254fd6a30  pop rdi
00007f0254fd6a31  pop rdx
00007f0254fd6a32  pop rcx
00007f0254fd6a33  pop rax
00007f0254fd6a34  add rsp, 0x08
00007f0254fd6a38  jmp 0x00007F0254FD59C8
00007f0254fd6a3d  sub rsp, 0x08
00007f0254fd6a41  push rax
00007f0254fd6a42  push rcx
00007f0254fd6a43  push rdx
00007f0254fd6a44  push rdi
00007f0254fd6a45  push rsi
00007f0254fd6a46  push r8
00007f0254fd6a48  push r9
00007f0254fd6a4a  push r10
00007f0254fd6a4c  push r11
00007f0254fd6a4e  sub rsp, 0xF0
00007f0254fd6a55  vmovaps [rsp], xmm0
00007f0254fd6a5a  vmovaps [rsp+0x10], xmm1
00007f0254fd6a60  vmovaps [rsp+0x20], xmm2
00007f0254fd6a66  vmovaps [rsp+0x30], xmm3
00007f0254fd6a6c  vmovaps [rsp+0x40], xmm4
00007f0254fd6a72  vmovaps [rsp+0x50], xmm5
00007f0254fd6a78  vmovaps [rsp+0x60], xmm6
00007f0254fd6a7e  vmovaps [rsp+0x70], xmm7
00007f0254fd6a84  vmovaps [rsp+0x80], xmm8
00007f0254fd6a8d  vmovaps [rsp+0x90], xmm10
00007f0254fd6a96  vmovaps [rsp+0xA0], xmm11
00007f0254fd6a9f  vmovaps [rsp+0xB0], xmm12
00007f0254fd6aa8  vmovaps [rsp+0xC0], xmm13
00007f0254fd6ab1  vmovaps [rsp+0xD0], xmm14
00007f0254fd6aba  vmovaps [rsp+0xE0], xmm15
00007f0254fd6ac3  sub rsp, 0x30
00007f0254fd6ac7  movaps [rsp], xmm9
00007f0254fd6acc  movaps [rsp+0x10], xmm12
00007f0254fd6ad2  movaps [rsp+0x20], xmm10
00007f0254fd6ad8  lea rdi, [rsp]
00007f0254fd6adc  mov esi, 0x00
00007f0254fd6ae1  mov rax, 0x55DD1360A530
00007f0254fd6aeb  call rax
00007f0254fd6aed  movaps xmm9, [rsp]
00007f0254fd6af2  add rsp, 0x30
00007f0254fd6af6  vmovaps xmm0, [rsp]
00007f0254fd6afb  vmovaps xmm1, [rsp+0x10]
00007f0254fd6b01  vmovaps xmm2, [rsp+0x20]
00007f0254fd6b07  vmovaps xmm3, [rsp+0x30]
00007f0254fd6b0d  vmovaps xmm4, [rsp+0x40]
00007f0254fd6b13  vmovaps xmm5, [rsp+0x50]
00007f0254fd6b19  vmovaps xmm6, [rsp+0x60]
00007f0254fd6b1f  vmovaps xmm7, [rsp+0x70]
00007f0254fd6b25  vmovaps xmm8, [rsp+0x80]
00007f0254fd6b2e  vmovaps xmm10, [rsp+0x90]
00007f0254fd6b37  vmovaps xmm11, [rsp+0xA0]
00007f0254fd6b40  vmovaps xmm12, [rsp+0xB0]
00007f0254fd6b49  vmovaps xmm13, [rsp+0xC0]
00007f0254fd6b52  vmovaps xmm14, [rsp+0xD0]
00007f0254fd6b5b  vmovaps xmm15, [rsp+0xE0]
00007f0254fd6b64  add rsp, 0xF0
00007f0254fd6b6b  pop r11
00007f0254fd6b6d  pop r10
00007f0254fd6b6f  pop r9
00007f0254fd6b71  pop r8
00007f0254fd6b73  pop rsi
00007f0254fd6b74  pop rdi
00007f0254fd6b75  pop rdx
00007f0254fd6b76  pop rcx
00007f0254fd6b77  pop rax
00007f0254fd6b78  add rsp, 0x08
00007f0254fd6b7c  jmp 0x00007F0254FD59EC
00007f0254fd6b81  sub rsp, 0x08
00007f0254fd6b85  push rax
00007f0254fd6b86  push rcx
00007f0254fd6b87  push rdx
00007f0254fd6b88  push rdi
00007f0254fd6b89  push rsi
00007f0254fd6b8a  push r8
00007f0254fd6b8c  push r9
00007f0254fd6b8e  push r10
00007f0254fd6b90  push r11
00007f0254fd6b92  sub rsp, 0xF0
00007f0254fd6b99  vmovaps [rsp], xmm0
00007f0254fd6b9e  vmovaps [rsp+0x10], xmm1
00007f0254fd6ba4  vmovaps [rsp+0x20], xmm2
00007f0254fd6baa  vmovaps [rsp+0x30], xmm3
00007f0254fd6bb0  vmovaps [rsp+0x40], xmm4
00007f0254fd6bb6  vmovaps [rsp+0x50], xmm5
00007f0254fd6bbc  vmovaps [rsp+0x60], xmm6
00007f0254fd6bc2  vmovaps [rsp+0x70], xmm7
00007f0254fd6bc8  vmovaps [rsp+0x80], xmm8
00007f0254fd6bd1  vmovaps [rsp+0x90], xmm9
00007f0254fd6bda  vmovaps [rsp+0xA0], xmm11
00007f0254fd6be3  vmovaps [rsp+0xB0], xmm12
00007f0254fd6bec  vmovaps [rsp+0xC0], xmm13
00007f0254fd6bf5  vmovaps [rsp+0xD0], xmm14
00007f0254fd6bfe  vmovaps [rsp+0xE0], xmm15
00007f0254fd6c07  sub rsp, 0x30
00007f0254fd6c0b  movaps [rsp], xmm10
00007f0254fd6c10  movaps [rsp+0x10], xmm12
00007f0254fd6c16  movaps [rsp+0x20], xmm11
00007f0254fd6c1c  lea rdi, [rsp]
00007f0254fd6c20  mov esi, 0x00
00007f0254fd6c25  mov rax, 0x55DD1360A530
00007f0254fd6c2f  call rax
00007f0254fd6c31  movaps xmm10, [rsp]
00007f0254fd6c36  add rsp, 0x30
00007f0254fd6c3a  vmovaps xmm0, [rsp]
00007f0254fd6c3f  vmovaps xmm1, [rsp+0x10]
00007f0254fd6c45  vmovaps xmm2, [rsp+0x20]
00007f0254fd6c4b  vmovaps xmm3, [rsp+0x30]
00007f0254fd6c51  vmovaps xmm4, [rsp+0x40]
00007f0254fd6c57  vmovaps xmm5, [rsp+0x50]
00007f0254fd6c5d  vmovaps xmm6, [rsp+0x60]
00007f0254fd6c63  vmovaps xmm7, [rsp+0x70]
00007f0254fd6c69  vmovaps xmm8, [rsp+0x80]
00007f0254fd6c72  vmovaps xmm9, [rsp+0x90]
00007f0254fd6c7b  vmovaps xmm11, [rsp+0xA0]
00007f0254fd6c84  vmovaps xmm12, [rsp+0xB0]
00007f0254fd6c8d  vmovaps xmm13, [rsp+0xC0]
00007f0254fd6c96  vmovaps xmm14, [rsp+0xD0]
00007f0254fd6c9f  vmovaps xmm15, [rsp+0xE0]
00007f0254fd6ca8  add rsp, 0xF0
00007f0254fd6caf  pop r11
00007f0254fd6cb1  pop r10
00007f0254fd6cb3  pop r9
00007f0254fd6cb5  pop r8
00007f0254fd6cb7  pop rsi
00007f0254fd6cb8  pop rdi
00007f0254fd6cb9  pop rdx
00007f0254fd6cba  pop rcx
00007f0254fd6cbb  pop rax
00007f0254fd6cbc  add rsp, 0x08
00007f0254fd6cc0  jmp 0x00007F0254FD5A06
00007f0254fd6cc5  sub rsp, 0x08
00007f0254fd6cc9  push rax
00007f0254fd6cca  push rcx
00007f0254fd6ccb  push rdx
00007f0254fd6ccc  push rdi
00007f0254fd6ccd  push rsi
00007f0254fd6cce  push r8
00007f0254fd6cd0  push r9
00007f0254fd6cd2  push r10
00007f0254fd6cd4  push r11
00007f0254fd6cd6  sub rsp, 0xF0
00007f0254fd6cdd  vmovaps [rsp], xmm0
00007f0254fd6ce2  vmovaps [rsp+0x10], xmm1
00007f0254fd6ce8  vmovaps [rsp+0x20], xmm2
00007f0254fd6cee  vmovaps [rsp+0x30], xmm3
00007f0254fd6cf4  vmovaps [rsp+0x40], xmm4
00007f0254fd6cfa  vmovaps [rsp+0x50], xmm5
00007f0254fd6d00  vmovaps [rsp+0x60], xmm7
00007f0254fd6d06  vmovaps [rsp+0x70], xmm8
00007f0254fd6d0c  vmovaps [rsp+0x80], xmm9
00007f0254fd6d15  vmovaps [rsp+0x90], xmm10
00007f0254fd6d1e  vmovaps [rsp+0xA0], xmm11
00007f0254fd6d27  vmovaps [rsp+0xB0], xmm12
00007f0254fd6d30  vmovaps [rsp+0xC0], xmm13
00007f0254fd6d39  vmovaps [rsp+0xD0], xmm14
00007f0254fd6d42  vmovaps [rsp+0xE0], xmm15
00007f0254fd6d4b  sub rsp, 0x30
00007f0254fd6d4f  movaps [rsp], xmm6
00007f0254fd6d53  movaps [rsp+0x10], xmm12
00007f0254fd6d59  movaps [rsp+0x20], xmm11
00007f0254fd6d5f  lea rdi, [rsp]
00007f0254fd6d63  mov esi, 0x00
00007f0254fd6d68  mov rax, 0x55DD1360A530
00007f0254fd6d72  call rax
00007f0254fd6d74  movaps xmm6, [rsp]
00007f0254fd6d78  add rsp, 0x30
00007f0254fd6d7c  vmovaps xmm0, [rsp]
00007f0254fd6d81  vmovaps xmm1, [rsp+0x10]
00007f0254fd6d87  vmovaps xmm2, [rsp+0x20]
00007f0254fd6d8d  vmovaps xmm3, [rsp+0x30]
00007f0254fd6d93  vmovaps xmm4, [rsp+0x40]
00007f0254fd6d99  vmovaps xmm5, [rsp+0x50]
00007f0254fd6d9f  vmovaps xmm7, [rsp+0x60]
00007f0254fd6da5  vmovaps xmm8, [rsp+0x70]
00007f0254fd6dab  vmovaps xmm9, [rsp+0x80]
00007f0254fd6db4  vmovaps xmm10, [rsp+0x90]
00007f0254fd6dbd  vmovaps xmm11, [rsp+0xA0]
00007f0254fd6dc6  vmovaps xmm12, [rsp+0xB0]
00007f0254fd6dcf  vmovaps xmm13, [rsp+0xC0]
00007f0254fd6dd8  vmovaps xmm14, [rsp+0xD0]
00007f0254fd6de1  vmovaps xmm15, [rsp+0xE0]
00007f0254fd6dea  add rsp, 0xF0
00007f0254fd6df1  pop r11
00007f0254fd6df3  pop r10
00007f0254fd6df5  pop r9
00007f0254fd6df7  pop r8
00007f0254fd6df9  pop rsi
00007f0254fd6dfa  pop rdi
00007f0254fd6dfb  pop rdx
00007f0254fd6dfc  pop rcx
00007f0254fd6dfd  pop rax
00007f0254fd6dfe  add rsp, 0x08
00007f0254fd6e02  jmp 0x00007F0254FD5A27
00007f0254fd6e07  sub rsp, 0x08
00007f0254fd6e0b  push rax
00007f0254fd6e0c  push rcx
00007f0254fd6e0d  push rdx
00007f0254fd6e0e  push rdi
00007f0254fd6e0f  push rsi
00007f0254fd6e10  push r8
00007f0254fd6e12  push r9
00007f0254fd6e14  push r10
00007f0254fd6e16  push r11
00007f0254fd6e18  sub rsp, 0xF0
00007f0254fd6e1f  vmovaps [rsp], xmm0
00007f0254fd6e24  vmovaps [rsp+0x10], xmm1
00007f0254fd6e2a  vmovaps [rsp+0x20], xmm2
00007f0254fd6e30  vmovaps [rsp+0x30], xmm4
00007f0254fd6e36  vmovaps [rsp+0x40], xmm5
00007f0254fd6e3c  vmovaps [rsp+0x50], xmm6
00007f0254fd6e42  vmovaps [rsp+0x60], xmm7
00007f0254fd6e48  vmovaps [rsp+0x70], xmm8
00007f0254fd6e4e  vmovaps [rsp+0x80], xmm9
00007f0254fd6e57  vmovaps [rsp+0x90], xmm10
00007f0254fd6e60  vmovaps [rsp+0xA0], xmm11
00007f0254fd6e69  vmovaps [rsp+0xB0], xmm12
00007f0254fd6e72  vmovaps [rsp+0xC0], xmm13
00007f0254fd6e7b  vmovaps [rsp+0xD0], xmm14
00007f0254fd6e84  vmovaps [rsp+0xE0], xmm15
00007f0254fd6e8d  sub rsp, 0x30
00007f0254fd6e91  movaps [rsp], xmm3
00007f0254fd6e95  movaps [rsp+0x10], xmm5
00007f0254fd6e9a  movaps [rsp+0x20], xmm4
00007f0254fd6e9f  lea rdi, [rsp]
00007f0254fd6ea3  mov esi, 0x00
00007f0254fd6ea8  mov rax, 0x55DD1360A530
00007f0254fd6eb2  call rax
00007f0254fd6eb4  movaps xmm3, [rsp]
00007f0254fd6eb8  add rsp, 0x30
00007f0254fd6ebc  vmovaps xmm0, [rsp]
00007f0254fd6ec1  vmovaps xmm1, [rsp+0x10]
00007f0254fd6ec7  vmovaps xmm2, [rsp+0x20]
00007f0254fd6ecd  vmovaps xmm4, [rsp+0x30]
00007f0254fd6ed3  vmovaps xmm5, [rsp+0x40]
00007f0254fd6ed9  vmovaps xmm6, [rsp+0x50]
00007f0254fd6edf  vmovaps xmm7, [rsp+0x60]
00007f0254fd6ee5  vmovaps xmm8, [rsp+0x70]
00007f0254fd6eeb  vmovaps xmm9, [rsp+0x80]
00007f0254fd6ef4  vmovaps xmm10, [rsp+0x90]
00007f0254fd6efd  vmovaps xmm11, [rsp+0xA0]
00007f0254fd6f06  vmovaps xmm12, [rsp+0xB0]
00007f0254fd6f0f  vmovaps xmm13, [rsp+0xC0]
00007f0254fd6f18  vmovaps xmm14, [rsp+0xD0]
00007f0254fd6f21  vmovaps xmm15, [rsp+0xE0]
00007f0254fd6f2a  add rsp, 0xF0
00007f0254fd6f31  pop r11
00007f0254fd6f33  pop r10
00007f0254fd6f35  pop r9
00007f0254fd6f37  pop r8
00007f0254fd6f39  pop rsi
00007f0254fd6f3a  pop rdi
00007f0254fd6f3b  pop rdx
00007f0254fd6f3c  pop rcx
00007f0254fd6f3d  pop rax
00007f0254fd6f3e  add rsp, 0x08
00007f0254fd6f42  jmp 0x00007F0254FD5A88
00007f0254fd6f47  sub rsp, 0x08
00007f0254fd6f4b  push rax
00007f0254fd6f4c  push rcx
00007f0254fd6f4d  push rdx
00007f0254fd6f4e  push rdi
00007f0254fd6f4f  push rsi
00007f0254fd6f50  push r8
00007f0254fd6f52  push r9
00007f0254fd6f54  push r10
00007f0254fd6f56  push r11
00007f0254fd6f58  sub rsp, 0xF0
00007f0254fd6f5f  vmovaps [rsp], xmm0
00007f0254fd6f64  vmovaps [rsp+0x10], xmm1
00007f0254fd6f6a  vmovaps [rsp+0x20], xmm2
00007f0254fd6f70  vmovaps [rsp+0x30], xmm3
00007f0254fd6f76  vmovaps [rsp+0x40], xmm4
00007f0254fd6f7c  vmovaps [rsp+0x50], xmm6
00007f0254fd6f82  vmovaps [rsp+0x60], xmm7
00007f0254fd6f88  vmovaps [rsp+0x70], xmm8
00007f0254fd6f8e  vmovaps [rsp+0x80], xmm9
00007f0254fd6f97  vmovaps [rsp+0x90], xmm10
00007f0254fd6fa0  vmovaps [rsp+0xA0], xmm11
00007f0254fd6fa9  vmovaps [rsp+0xB0], xmm12
00007f0254fd6fb2  vmovaps [rsp+0xC0], xmm13
00007f0254fd6fbb  vmovaps [rsp+0xD0], xmm14
00007f0254fd6fc4  vmovaps [rsp+0xE0], xmm15
00007f0254fd6fcd  sub rsp, 0x30
00007f0254fd6fd1  movaps [rsp], xmm5
00007f0254fd6fd5  movaps [rsp+0x10], xmm8
00007f0254fd6fdb  movaps [rsp+0x20], xmm15
00007f0254fd6fe1  lea rdi, [rsp]
00007f0254fd6fe5  mov esi, 0x00
00007f0254fd6fea  mov rax, 0x55DD1360A530
00007f0254fd6ff4  call rax
00007f0254fd6ff6  movaps xmm5, [rsp]
00007f0254fd6ffa  add rsp, 0x30
00007f0254fd6ffe  vmovaps xmm0, [rsp]
00007f0254fd7003  vmovaps xmm1, [rsp+0x10]
00007f0254fd7009  vmovaps xmm2, [rsp+0x20]
00007f0254fd700f  vmovaps xmm3, [rsp+0x30]
00007f0254fd7015  vmovaps xmm4, [rsp+0x40]
00007f0254fd701b  vmovaps xmm6, [rsp+0x50]
00007f0254fd7021  vmovaps xmm7, [rsp+0x60]
00007f0254fd7027  vmovaps xmm8, [rsp+0x70]
00007f0254fd702d  vmovaps xmm9, [rsp+0x80]
00007f0254fd7036  vmovaps xmm10, [rsp+0x90]
00007f0254fd703f  vmovaps xmm11, [rsp+0xA0]
00007f0254fd7048  vmovaps xmm12, [rsp+0xB0]
00007f0254fd7051  vmovaps xmm13, [rsp+0xC0]
00007f0254fd705a  vmovaps xmm14, [rsp+0xD0]
00007f0254fd7063  vmovaps xmm15, [rsp+0xE0]
00007f0254fd706c  add rsp, 0xF0
00007f0254fd7073  pop r11
00007f0254fd7075  pop r10
00007f0254fd7077  pop r9
00007f0254fd7079  pop r8
00007f0254fd707b  pop rsi
00007f0254fd707c  pop rdi
00007f0254fd707d  pop rdx
00007f0254fd707e  pop rcx
00007f0254fd707f  pop rax
00007f0254fd7080  add rsp, 0x08
00007f0254fd7084  jmp 0x00007F0254FD5AC0
00007f0254fd7089  sub rsp, 0x08
00007f0254fd708d  push rax
00007f0254fd708e  push rcx
00007f0254fd708f  push rdx
00007f0254fd7090  push rdi
00007f0254fd7091  push rsi
00007f0254fd7092  push r8
00007f0254fd7094  push r9
00007f0254fd7096  push r10
00007f0254fd7098  push r11
00007f0254fd709a  sub rsp, 0xF0
00007f0254fd70a1  vmovaps [rsp], xmm0
00007f0254fd70a6  vmovaps [rsp+0x10], xmm1
00007f0254fd70ac  vmovaps [rsp+0x20], xmm2
00007f0254fd70b2  vmovaps [rsp+0x30], xmm3
00007f0254fd70b8  vmovaps [rsp+0x40], xmm5
00007f0254fd70be  vmovaps [rsp+0x50], xmm6
00007f0254fd70c4  vmovaps [rsp+0x60], xmm7
00007f0254fd70ca  vmovaps [rsp+0x70], xmm8
00007f0254fd70d0  vmovaps [rsp+0x80], xmm9
00007f0254fd70d9  vmovaps [rsp+0x90], xmm10
00007f0254fd70e2  vmovaps [rsp+0xA0], xmm11
00007f0254fd70eb  vmovaps [rsp+0xB0], xmm12
00007f0254fd70f4  vmovaps [rsp+0xC0], xmm13
00007f0254fd70fd  vmovaps [rsp+0xD0], xmm14
00007f0254fd7106  vmovaps [rsp+0xE0], xmm15
00007f0254fd710f  sub rsp, 0x30
00007f0254fd7113  movaps [rsp], xmm4
00007f0254fd7117  movaps [rsp+0x10], xmm9
00007f0254fd711d  movaps [rsp+0x20], xmm8
00007f0254fd7123  lea rdi, [rsp]
00007f0254fd7127  mov esi, 0x00
00007f0254fd712c  mov rax, 0x55DD1360A530
00007f0254fd7136  call rax
00007f0254fd7138  movaps xmm4, [rsp]
00007f0254fd713c  add rsp, 0x30
00007f0254fd7140  vmovaps xmm0, [rsp]
00007f0254fd7145  vmovaps xmm1, [rsp+0x10]
00007f0254fd714b  vmovaps xmm2, [rsp+0x20]
00007f0254fd7151  vmovaps xmm3, [rsp+0x30]
00007f0254fd7157  vmovaps xmm5, [rsp+0x40]
00007f0254fd715d  vmovaps xmm6, [rsp+0x50]
00007f0254fd7163  vmovaps xmm7, [rsp+0x60]
00007f0254fd7169  vmovaps xmm8, [rsp+0x70]
00007f0254fd716f  vmovaps xmm9, [rsp+0x80]
00007f0254fd7178  vmovaps xmm10, [rsp+0x90]
00007f0254fd7181  vmovaps xmm11, [rsp+0xA0]
00007f0254fd718a  vmovaps xmm12, [rsp+0xB0]
00007f0254fd7193  vmovaps xmm13, [rsp+0xC0]
00007f0254fd719c  vmovaps xmm14, [rsp+0xD0]
00007f0254fd71a5  vmovaps xmm15, [rsp+0xE0]
00007f0254fd71ae  add rsp, 0xF0
00007f0254fd71b5  pop r11
00007f0254fd71b7  pop r10
00007f0254fd71b9  pop r9
00007f0254fd71bb  pop r8
00007f0254fd71bd  pop rsi
00007f0254fd71be  pop rdi
00007f0254fd71bf  pop rdx
00007f0254fd71c0  pop rcx
00007f0254fd71c1  pop rax
00007f0254fd71c2  add rsp, 0x08
00007f0254fd71c6  jmp 0x00007F0254FD5AE1
00007f0254fd71cb  sub rsp, 0x08
00007f0254fd71cf  push rax
00007f0254fd71d0  push rcx
00007f0254fd71d1  push rdx
00007f0254fd71d2  push rdi
00007f0254fd71d3  push rsi
00007f0254fd71d4  push r8
00007f0254fd71d6  push r9
00007f0254fd71d8  push r10
00007f0254fd71da  push r11
00007f0254fd71dc  sub rsp, 0xF0
00007f0254fd71e3  vmovaps [rsp], xmm0
00007f0254fd71e8  vmovaps [rsp+0x10], xmm1
00007f0254fd71ee  vmovaps [rsp+0x20], xmm2
00007f0254fd71f4  vmovaps [rsp+0x30], xmm3
00007f0254fd71fa  vmovaps [rsp+0x40], xmm4
00007f0254fd7200  vmovaps [rsp+0x50], xmm5
00007f0254fd7206  vmovaps [rsp+0x60], xmm6
00007f0254fd720c  vmovaps [rsp+0x70], xmm7
00007f0254fd7212  vmovaps [rsp+0x80], xmm8
00007f0254fd721b  vmovaps [rsp+0x90], xmm10
00007f0254fd7224  vmovaps [rsp+0xA0], xmm11
00007f0254fd722d  vmovaps [rsp+0xB0], xmm12
00007f0254fd7236  vmovaps [rsp+0xC0], xmm13
00007f0254fd723f  vmovaps [rsp+0xD0], xmm14
00007f0254fd7248  vmovaps [rsp+0xE0], xmm15
00007f0254fd7251  sub rsp, 0x30
00007f0254fd7255  movaps [rsp], xmm9
00007f0254fd725a  movaps [rsp+0x10], xmm10
00007f0254fd7260  movaps [rsp+0x20], xmm8
00007f0254fd7266  lea rdi, [rsp]
00007f0254fd726a  mov esi, 0x00
00007f0254fd726f  mov rax, 0x55DD1360A530
00007f0254fd7279  call rax
00007f0254fd727b  movaps xmm9, [rsp]
00007f0254fd7280  add rsp, 0x30
00007f0254fd7284  vmovaps xmm0, [rsp]
00007f0254fd7289  vmovaps xmm1, [rsp+0x10]
00007f0254fd728f  vmovaps xmm2, [rsp+0x20]
00007f0254fd7295  vmovaps xmm3, [rsp+0x30]
00007f0254fd729b  vmovaps xmm4, [rsp+0x40]
00007f0254fd72a1  vmovaps xmm5, [rsp+0x50]
00007f0254fd72a7  vmovaps xmm6, [rsp+0x60]
00007f0254fd72ad  vmovaps xmm7, [rsp+0x70]
00007f0254fd72b3  vmovaps xmm8, [rsp+0x80]
00007f0254fd72bc  vmovaps xmm10, [rsp+0x90]
00007f0254fd72c5  vmovaps xmm11, [rsp+0xA0]
00007f0254fd72ce  vmovaps xmm12, [rsp+0xB0]
00007f0254fd72d7  vmovaps xmm13, [rsp+0xC0]
00007f0254fd72e0  vmovaps xmm14, [rsp+0xD0]
00007f0254fd72e9  vmovaps xmm15, [rsp+0xE0]
00007f0254fd72f2  add rsp, 0xF0
00007f0254fd72f9  pop r11
00007f0254fd72fb  pop r10
00007f0254fd72fd  pop r9
00007f0254fd72ff  pop r8
00007f0254fd7301  pop rsi
00007f0254fd7302  pop rdi
00007f0254fd7303  pop rdx
00007f0254fd7304  pop rcx
00007f0254fd7305  pop rax
00007f0254fd7306  add rsp, 0x08
00007f0254fd730a  jmp 0x00007F0254FD5AFB
00007f0254fd730f  call 0x00007F0254ED64F0
00007f0254fd7314  jmp 0x00007F0254FD5C15
00007f0254fd7319  call 0x00007F0254ED64F0
00007f0254fd731e  jmp 0x00007F0254FD5C2B
00007f0254fd7323  sub rsp, 0x08
00007f0254fd7327  push rax
00007f0254fd7328  push rcx
00007f0254fd7329  push rdx
00007f0254fd732a  push rdi
00007f0254fd732b  push rsi
00007f0254fd732c  push r8
00007f0254fd732e  push r9
00007f0254fd7330  push r10
00007f0254fd7332  push r11
00007f0254fd7334  sub rsp, 0xF0
00007f0254fd733b  vmovaps [rsp], xmm0
00007f0254fd7340  vmovaps [rsp+0x10], xmm2
00007f0254fd7346  vmovaps [rsp+0x20], xmm3
00007f0254fd734c  vmovaps [rsp+0x30], xmm4
00007f0254fd7352  vmovaps [rsp+0x40], xmm5
00007f0254fd7358  vmovaps [rsp+0x50], xmm6
00007f0254fd735e  vmovaps [rsp+0x60], xmm7
00007f0254fd7364  vmovaps [rsp+0x70], xmm8
00007f0254fd736a  vmovaps [rsp+0x80], xmm9
00007f0254fd7373  vmovaps [rsp+0x90], xmm10
00007f0254fd737c  vmovaps [rsp+0xA0], xmm11
00007f0254fd7385  vmovaps [rsp+0xB0], xmm12
00007f0254fd738e  vmovaps [rsp+0xC0], xmm13
00007f0254fd7397  vmovaps [rsp+0xD0], xmm14
00007f0254fd73a0  vmovaps [rsp+0xE0], xmm15
00007f0254fd73a9  sub rsp, 0x30
00007f0254fd73ad  movaps [rsp], xmm1
00007f0254fd73b1  movaps [rsp+0x10], xmm6
00007f0254fd73b6  movaps [rsp+0x20], xmm15
00007f0254fd73bc  lea rdi, [rsp]
00007f0254fd73c0  mov esi, 0x00
00007f0254fd73c5  mov rax, 0x55DD1360A530
00007f0254fd73cf  call rax
00007f0254fd73d1  movaps xmm1, [rsp]
00007f0254fd73d5  add rsp, 0x30
00007f0254fd73d9  vmovaps xmm0, [rsp]
00007f0254fd73de  vmovaps xmm2, [rsp+0x10]
00007f0254fd73e4  vmovaps xmm3, [rsp+0x20]
00007f0254fd73ea  vmovaps xmm4, [rsp+0x30]
00007f0254fd73f0  vmovaps xmm5, [rsp+0x40]
00007f0254fd73f6  vmovaps xmm6, [rsp+0x50]
00007f0254fd73fc  vmovaps xmm7, [rsp+0x60]
00007f0254fd7402  vmovaps xmm8, [rsp+0x70]
00007f0254fd7408  vmovaps xmm9, [rsp+0x80]
00007f0254fd7411  vmovaps xmm10, [rsp+0x90]
00007f0254fd741a  vmovaps xmm11, [rsp+0xA0]
00007f0254fd7423  vmovaps xmm12, [rsp+0xB0]
00007f0254fd742c  vmovaps xmm13, [rsp+0xC0]
00007f0254fd7435  vmovaps xmm14, [rsp+0xD0]
00007f0254fd743e  vmovaps xmm15, [rsp+0xE0]
00007f0254fd7447  add rsp, 0xF0
00007f0254fd744e  pop r11
00007f0254fd7450  pop r10
00007f0254fd7452  pop r9
00007f0254fd7454  pop r8
00007f0254fd7456  pop rsi
00007f0254fd7457  pop rdi
00007f0254fd7458  pop rdx
00007f0254fd7459  pop rcx
00007f0254fd745a  pop rax
00007f0254fd745b  add rsp, 0x08
00007f0254fd745f  jmp 0x00007F0254FD5C68
00007f0254fd7464  call 0x00007F0254EE5820
00007f0254fd7469  jmp 0x00007F0254FD5C75
00007f0254fd746e  sub rsp, 0x08
00007f0254fd7472  push rax
00007f0254fd7473  push rcx
00007f0254fd7474  push rdx
00007f0254fd7475  push rdi
00007f0254fd7476  push rsi
00007f0254fd7477  push r8
00007f0254fd7479  push r9
00007f0254fd747b  push r10
00007f0254fd747d  push r11
00007f0254fd747f  sub rsp, 0xF0
00007f0254fd7486  vmovaps [rsp], xmm0
00007f0254fd748b  vmovaps [rsp+0x10], xmm1
00007f0254fd7491  vmovaps [rsp+0x20], xmm2
00007f0254fd7497  vmovaps [rsp+0x30], xmm3
00007f0254fd749d  vmovaps [rsp+0x40], xmm4
00007f0254fd74a3  vmovaps [rsp+0x50], xmm5
00007f0254fd74a9  vmovaps [rsp+0x60], xmm6
00007f0254fd74af  vmovaps [rsp+0x70], xmm7
00007f0254fd74b5  vmovaps [rsp+0x80], xmm8
00007f0254fd74be  vmovaps [rsp+0x90], xmm9
00007f0254fd74c7  vmovaps [rsp+0xA0], xmm10
00007f0254fd74d0  vmovaps [rsp+0xB0], xmm11
00007f0254fd74d9  vmovaps [rsp+0xC0], xmm12
00007f0254fd74e2  vmovaps [rsp+0xD0], xmm13
00007f0254fd74eb  vmovaps [rsp+0xE0], xmm15
00007f0254fd74f4  sub rsp, 0x30
00007f0254fd74f8  movaps [rsp], xmm14
00007f0254fd74fd  movaps [rsp+0x10], xmm4
00007f0254fd7502  movaps [rsp+0x20], xmm3
00007f0254fd7507  lea rdi, [rsp]
00007f0254fd750b  mov esi, 0x00
00007f0254fd7510  mov rax, 0x55DD1360A530
00007f0254fd751a  call rax
00007f0254fd751c  movaps xmm14, [rsp]
00007f0254fd7521  add rsp, 0x30
00007f0254fd7525  vmovaps xmm0, [rsp]
00007f0254fd752a  vmovaps xmm1, [rsp+0x10]
00007f0254fd7530  vmovaps xmm2, [rsp+0x20]
00007f0254fd7536  vmovaps xmm3, [rsp+0x30]
00007f0254fd753c  vmovaps xmm4, [rsp+0x40]
00007f0254fd7542  vmovaps xmm5, [rsp+0x50]
00007f0254fd7548  vmovaps xmm6, [rsp+0x60]
00007f0254fd754e  vmovaps xmm7, [rsp+0x70]
00007f0254fd7554  vmovaps xmm8, [rsp+0x80]
00007f0254fd755d  vmovaps xmm9, [rsp+0x90]
00007f0254fd7566  vmovaps xmm10, [rsp+0xA0]
00007f0254fd756f  vmovaps xmm11, [rsp+0xB0]
00007f0254fd7578  vmovaps xmm12, [rsp+0xC0]
00007f0254fd7581  vmovaps xmm13, [rsp+0xD0]
00007f0254fd758a  vmovaps xmm15, [rsp+0xE0]
00007f0254fd7593  add rsp, 0xF0
00007f0254fd759a  pop r11
00007f0254fd759c  pop r10
00007f0254fd759e  pop r9
00007f0254fd75a0  pop r8
00007f0254fd75a2  pop rsi
00007f0254fd75a3  pop rdi
00007f0254fd75a4  pop rdx
00007f0254fd75a5  pop rcx
00007f0254fd75a6  pop rax
00007f0254fd75a7  add rsp, 0x08
00007f0254fd75ab  jmp 0x00007F0254FD5C8F
00007f0254fd75b0  sub rsp, 0x08
00007f0254fd75b4  push rax
00007f0254fd75b5  push rcx
00007f0254fd75b6  push rdx
00007f0254fd75b7  push rdi
00007f0254fd75b8  push rsi
00007f0254fd75b9  push r8
00007f0254fd75bb  push r9
00007f0254fd75bd  push r10
00007f0254fd75bf  push r11
00007f0254fd75c1  sub rsp, 0xF0
00007f0254fd75c8  vmovaps [rsp], xmm0
00007f0254fd75cd  vmovaps [rsp+0x10], xmm1
00007f0254fd75d3  vmovaps [rsp+0x20], xmm2
00007f0254fd75d9  vmovaps [rsp+0x30], xmm3
00007f0254fd75df  vmovaps [rsp+0x40], xmm4
00007f0254fd75e5  vmovaps [rsp+0x50], xmm5
00007f0254fd75eb  vmovaps [rsp+0x60], xmm7
00007f0254fd75f1  vmovaps [rsp+0x70], xmm8
00007f0254fd75f7  vmovaps [rsp+0x80], xmm9
00007f0254fd7600  vmovaps [rsp+0x90], xmm10
00007f0254fd7609  vmovaps [rsp+0xA0], xmm11
00007f0254fd7612  vmovaps [rsp+0xB0], xmm12
00007f0254fd761b  vmovaps [rsp+0xC0], xmm13
00007f0254fd7624  vmovaps [rsp+0xD0], xmm14
00007f0254fd762d  vmovaps [rsp+0xE0], xmm15
00007f0254fd7636  sub rsp, 0x30
00007f0254fd763a  movaps [rsp], xmm6
00007f0254fd763e  movaps [rsp+0x10], xmm9
00007f0254fd7644  movaps [rsp+0x20], xmm7
00007f0254fd7649  lea rdi, [rsp]
00007f0254fd764d  mov esi, 0x00
00007f0254fd7652  mov rax, 0x55DD1360A530
00007f0254fd765c  call rax
00007f0254fd765e  movaps xmm6, [rsp]
00007f0254fd7662  add rsp, 0x30
00007f0254fd7666  vmovaps xmm0, [rsp]
00007f0254fd766b  vmovaps xmm1, [rsp+0x10]
00007f0254fd7671  vmovaps xmm2, [rsp+0x20]
00007f0254fd7677  vmovaps xmm3, [rsp+0x30]
00007f0254fd767d  vmovaps xmm4, [rsp+0x40]
00007f0254fd7683  vmovaps xmm5, [rsp+0x50]
00007f0254fd7689  vmovaps xmm7, [rsp+0x60]
00007f0254fd768f  vmovaps xmm8, [rsp+0x70]
00007f0254fd7695  vmovaps xmm9, [rsp+0x80]
00007f0254fd769e  vmovaps xmm10, [rsp+0x90]
00007f0254fd76a7  vmovaps xmm11, [rsp+0xA0]
00007f0254fd76b0  vmovaps xmm12, [rsp+0xB0]
00007f0254fd76b9  vmovaps xmm13, [rsp+0xC0]
00007f0254fd76c2  vmovaps xmm14, [rsp+0xD0]
00007f0254fd76cb  vmovaps xmm15, [rsp+0xE0]
00007f0254fd76d4  add rsp, 0xF0
00007f0254fd76db  pop r11
00007f0254fd76dd  pop r10
00007f0254fd76df  pop r9
00007f0254fd76e1  pop r8
00007f0254fd76e3  pop rsi
00007f0254fd76e4  pop rdi
00007f0254fd76e5  pop rdx
00007f0254fd76e6  pop rcx
00007f0254fd76e7  pop rax
00007f0254fd76e8  add rsp, 0x08
00007f0254fd76ec  jmp 0x00007F0254FD5CA7
00007f0254fd76f1  sub rsp, 0x08
00007f0254fd76f5  push rax
00007f0254fd76f6  push rcx
00007f0254fd76f7  push rdx
00007f0254fd76f8  push rdi
00007f0254fd76f9  push rsi
00007f0254fd76fa  push r8
00007f0254fd76fc  push r9
00007f0254fd76fe  push r10
00007f0254fd7700  push r11
00007f0254fd7702  sub rsp, 0xF0
00007f0254fd7709  vmovaps [rsp], xmm0
00007f0254fd770e  vmovaps [rsp+0x10], xmm1
00007f0254fd7714  vmovaps [rsp+0x20], xmm2
00007f0254fd771a  vmovaps [rsp+0x30], xmm3
00007f0254fd7720  vmovaps [rsp+0x40], xmm4
00007f0254fd7726  vmovaps [rsp+0x50], xmm5
00007f0254fd772c  vmovaps [rsp+0x60], xmm6
00007f0254fd7732  vmovaps [rsp+0x70], xmm8
00007f0254fd7738  vmovaps [rsp+0x80], xmm9
00007f0254fd7741  vmovaps [rsp+0x90], xmm10
00007f0254fd774a  vmovaps [rsp+0xA0], xmm11
00007f0254fd7753  vmovaps [rsp+0xB0], xmm12
00007f0254fd775c  vmovaps [rsp+0xC0], xmm13
00007f0254fd7765  vmovaps [rsp+0xD0], xmm14
00007f0254fd776e  vmovaps [rsp+0xE0], xmm15
00007f0254fd7777  sub rsp, 0x30
00007f0254fd777b  movaps [rsp], xmm7
00007f0254fd777f  movaps [rsp+0x10], xmm4
00007f0254fd7784  movaps [rsp+0x20], xmm9
00007f0254fd778a  lea rdi, [rsp]
00007f0254fd778e  mov esi, 0x00
00007f0254fd7793  mov rax, 0x55DD1360A530
00007f0254fd779d  call rax
00007f0254fd779f  movaps xmm7, [rsp]
00007f0254fd77a3  add rsp, 0x30
00007f0254fd77a7  vmovaps xmm0, [rsp]
00007f0254fd77ac  vmovaps xmm1, [rsp+0x10]
00007f0254fd77b2  vmovaps xmm2, [rsp+0x20]
00007f0254fd77b8  vmovaps xmm3, [rsp+0x30]
00007f0254fd77be  vmovaps xmm4, [rsp+0x40]
00007f0254fd77c4  vmovaps xmm5, [rsp+0x50]
00007f0254fd77ca  vmovaps xmm6, [rsp+0x60]
00007f0254fd77d0  vmovaps xmm8, [rsp+0x70]
00007f0254fd77d6  vmovaps xmm9, [rsp+0x80]
00007f0254fd77df  vmovaps xmm10, [rsp+0x90]
00007f0254fd77e8  vmovaps xmm11, [rsp+0xA0]
00007f0254fd77f1  vmovaps xmm12, [rsp+0xB0]
00007f0254fd77fa  vmovaps xmm13, [rsp+0xC0]
00007f0254fd7803  vmovaps xmm14, [rsp+0xD0]
00007f0254fd780c  vmovaps xmm15, [rsp+0xE0]
00007f0254fd7815  add rsp, 0xF0
00007f0254fd781c  pop r11
00007f0254fd781e  pop r10
00007f0254fd7820  pop r9
00007f0254fd7822  pop r8
00007f0254fd7824  pop rsi
00007f0254fd7825  pop rdi
00007f0254fd7826  pop rdx
00007f0254fd7827  pop rcx
00007f0254fd7828  pop rax
00007f0254fd7829  add rsp, 0x08
00007f0254fd782d  jmp 0x00007F0254FD5CD4
00007f0254fd7832  sub rsp, 0x08
00007f0254fd7836  push rax
00007f0254fd7837  push rcx
00007f0254fd7838  push rdx
00007f0254fd7839  push rdi
00007f0254fd783a  push rsi
00007f0254fd783b  push r8
00007f0254fd783d  push r9
00007f0254fd783f  push r10
00007f0254fd7841  push r11
00007f0254fd7843  sub rsp, 0xF0
00007f0254fd784a  vmovaps [rsp], xmm0
00007f0254fd784f  vmovaps [rsp+0x10], xmm1
00007f0254fd7855  vmovaps [rsp+0x20], xmm2
00007f0254fd785b  vmovaps [rsp+0x30], xmm3
00007f0254fd7861  vmovaps [rsp+0x40], xmm5
00007f0254fd7867  vmovaps [rsp+0x50], xmm6
00007f0254fd786d  vmovaps [rsp+0x60], xmm7
00007f0254fd7873  vmovaps [rsp+0x70], xmm8
00007f0254fd7879  vmovaps [rsp+0x80], xmm9
00007f0254fd7882  vmovaps [rsp+0x90], xmm10
00007f0254fd788b  vmovaps [rsp+0xA0], xmm11
00007f0254fd7894  vmovaps [rsp+0xB0], xmm12
00007f0254fd789d  vmovaps [rsp+0xC0], xmm13
00007f0254fd78a6  vmovaps [rsp+0xD0], xmm14
00007f0254fd78af  vmovaps [rsp+0xE0], xmm15
00007f0254fd78b8  sub rsp, 0x30
00007f0254fd78bc  movaps [rsp], xmm4
00007f0254fd78c0  movaps [rsp+0x10], xmm15
00007f0254fd78c6  movaps [rsp+0x20], xmm9
00007f0254fd78cc  lea rdi, [rsp]
00007f0254fd78d0  mov esi, 0x00
00007f0254fd78d5  mov rax, 0x55DD1360A530
00007f0254fd78df  call rax
00007f0254fd78e1  movaps xmm4, [rsp]
00007f0254fd78e5  add rsp, 0x30
00007f0254fd78e9  vmovaps xmm0, [rsp]
00007f0254fd78ee  vmovaps xmm1, [rsp+0x10]
00007f0254fd78f4  vmovaps xmm2, [rsp+0x20]
00007f0254fd78fa  vmovaps xmm3, [rsp+0x30]
00007f0254fd7900  vmovaps xmm5, [rsp+0x40]
00007f0254fd7906  vmovaps xmm6, [rsp+0x50]
00007f0254fd790c  vmovaps xmm7, [rsp+0x60]
00007f0254fd7912  vmovaps xmm8, [rsp+0x70]
00007f0254fd7918  vmovaps xmm9, [rsp+0x80]
00007f0254fd7921  vmovaps xmm10, [rsp+0x90]
00007f0254fd792a  vmovaps xmm11, [rsp+0xA0]
00007f0254fd7933  vmovaps xmm12, [rsp+0xB0]
00007f0254fd793c  vmovaps xmm13, [rsp+0xC0]
00007f0254fd7945  vmovaps xmm14, [rsp+0xD0]
00007f0254fd794e  vmovaps xmm15, [rsp+0xE0]
00007f0254fd7957  add rsp, 0xF0
00007f0254fd795e  pop r11
00007f0254fd7960  pop r10
00007f0254fd7962  pop r9
00007f0254fd7964  pop r8
00007f0254fd7966  pop rsi
00007f0254fd7967  pop rdi
00007f0254fd7968  pop rdx
00007f0254fd7969  pop rcx
00007f0254fd796a  pop rax
00007f0254fd796b  add rsp, 0x08
00007f0254fd796f  jmp 0x00007F0254FD5CF9
00007f0254fd7974  call 0x00007F0254EE5820
00007f0254fd7979  jmp 0x00007F0254FD5D06
00007f0254fd797e  sub rsp, 0x08
00007f0254fd7982  push rax
00007f0254fd7983  push rcx
00007f0254fd7984  push rdx
00007f0254fd7985  push rdi
00007f0254fd7986  push rsi
00007f0254fd7987  push r8
00007f0254fd7989  push r9
00007f0254fd798b  push r10
00007f0254fd798d  push r11
00007f0254fd798f  sub rsp, 0xF0
00007f0254fd7996  vmovaps [rsp], xmm0
00007f0254fd799b  vmovaps [rsp+0x10], xmm1
00007f0254fd79a1  vmovaps [rsp+0x20], xmm2
00007f0254fd79a7  vmovaps [rsp+0x30], xmm4
00007f0254fd79ad  vmovaps [rsp+0x40], xmm5
00007f0254fd79b3  vmovaps [rsp+0x50], xmm6
00007f0254fd79b9  vmovaps [rsp+0x60], xmm7
00007f0254fd79bf  vmovaps [rsp+0x70], xmm8
00007f0254fd79c5  vmovaps [rsp+0x80], xmm9
00007f0254fd79ce  vmovaps [rsp+0x90], xmm10
00007f0254fd79d7  vmovaps [rsp+0xA0], xmm11
00007f0254fd79e0  vmovaps [rsp+0xB0], xmm12
00007f0254fd79e9  vmovaps [rsp+0xC0], xmm13
00007f0254fd79f2  vmovaps [rsp+0xD0], xmm14
00007f0254fd79fb  vmovaps [rsp+0xE0], xmm15
00007f0254fd7a04  sub rsp, 0x30
00007f0254fd7a08  movaps [rsp], xmm3
00007f0254fd7a0c  movaps [rsp+0x10], xmm1
00007f0254fd7a11  movaps [rsp+0x20], xmm9
00007f0254fd7a17  lea rdi, [rsp]
00007f0254fd7a1b  mov esi, 0x00
00007f0254fd7a20  mov rax, 0x55DD1360A530
00007f0254fd7a2a  call rax
00007f0254fd7a2c  movaps xmm3, [rsp]
00007f0254fd7a30  add rsp, 0x30
00007f0254fd7a34  vmovaps xmm0, [rsp]
00007f0254fd7a39  vmovaps xmm1, [rsp+0x10]
00007f0254fd7a3f  vmovaps xmm2, [rsp+0x20]
00007f0254fd7a45  vmovaps xmm4, [rsp+0x30]
00007f0254fd7a4b  vmovaps xmm5, [rsp+0x40]
00007f0254fd7a51  vmovaps xmm6, [rsp+0x50]
00007f0254fd7a57  vmovaps xmm7, [rsp+0x60]
00007f0254fd7a5d  vmovaps xmm8, [rsp+0x70]
00007f0254fd7a63  vmovaps xmm9, [rsp+0x80]
00007f0254fd7a6c  vmovaps xmm10, [rsp+0x90]
00007f0254fd7a75  vmovaps xmm11, [rsp+0xA0]
00007f0254fd7a7e  vmovaps xmm12, [rsp+0xB0]
00007f0254fd7a87  vmovaps xmm13, [rsp+0xC0]
00007f0254fd7a90  vmovaps xmm14, [rsp+0xD0]
00007f0254fd7a99  vmovaps xmm15, [rsp+0xE0]
00007f0254fd7aa2  add rsp, 0xF0
00007f0254fd7aa9  pop r11
00007f0254fd7aab  pop r10
00007f0254fd7aad  pop r9
00007f0254fd7aaf  pop r8
00007f0254fd7ab1  pop rsi
00007f0254fd7ab2  pop rdi
00007f0254fd7ab3  pop rdx
00007f0254fd7ab4  pop rcx
00007f0254fd7ab5  pop rax
00007f0254fd7ab6  add rsp, 0x08
00007f0254fd7aba  jmp 0x00007F0254FD5D43
00007f0254fd7abf  sub rsp, 0x08
00007f0254fd7ac3  push rax
00007f0254fd7ac4  push rcx
00007f0254fd7ac5  push rdx
00007f0254fd7ac6  push rdi
00007f0254fd7ac7  push rsi
00007f0254fd7ac8  push r8
00007f0254fd7aca  push r9
00007f0254fd7acc  push r10
00007f0254fd7ace  push r11
00007f0254fd7ad0  sub rsp, 0xF0
00007f0254fd7ad7  vmovaps [rsp], xmm0
00007f0254fd7adc  vmovaps [rsp+0x10], xmm2
00007f0254fd7ae2  vmovaps [rsp+0x20], xmm3
00007f0254fd7ae8  vmovaps [rsp+0x30], xmm4
00007f0254fd7aee  vmovaps [rsp+0x40], xmm5
00007f0254fd7af4  vmovaps [rsp+0x50], xmm6
00007f0254fd7afa  vmovaps [rsp+0x60], xmm7
00007f0254fd7b00  vmovaps [rsp+0x70], xmm8
00007f0254fd7b06  vmovaps [rsp+0x80], xmm9
00007f0254fd7b0f  vmovaps [rsp+0x90], xmm10
00007f0254fd7b18  vmovaps [rsp+0xA0], xmm11
00007f0254fd7b21  vmovaps [rsp+0xB0], xmm12
00007f0254fd7b2a  vmovaps [rsp+0xC0], xmm13
00007f0254fd7b33  vmovaps [rsp+0xD0], xmm14
00007f0254fd7b3c  vmovaps [rsp+0xE0], xmm15
00007f0254fd7b45  sub rsp, 0x30
00007f0254fd7b49  movaps [rsp], xmm1
00007f0254fd7b4d  movaps [rsp+0x10], xmm15
00007f0254fd7b53  movaps [rsp+0x20], xmm9
00007f0254fd7b59  lea rdi, [rsp]
00007f0254fd7b5d  mov esi, 0x00
00007f0254fd7b62  mov rax, 0x55DD1360A530
00007f0254fd7b6c  call rax
00007f0254fd7b6e  movaps xmm1, [rsp]
00007f0254fd7b72  add rsp, 0x30
00007f0254fd7b76  vmovaps xmm0, [rsp]
00007f0254fd7b7b  vmovaps xmm2, [rsp+0x10]
00007f0254fd7b81  vmovaps xmm3, [rsp+0x20]
00007f0254fd7b87  vmovaps xmm4, [rsp+0x30]
00007f0254fd7b8d  vmovaps xmm5, [rsp+0x40]
00007f0254fd7b93  vmovaps xmm6, [rsp+0x50]
00007f0254fd7b99  vmovaps xmm7, [rsp+0x60]
00007f0254fd7b9f  vmovaps xmm8, [rsp+0x70]
00007f0254fd7ba5  vmovaps xmm9, [rsp+0x80]
00007f0254fd7bae  vmovaps xmm10, [rsp+0x90]
00007f0254fd7bb7  vmovaps xmm11, [rsp+0xA0]
00007f0254fd7bc0  vmovaps xmm12, [rsp+0xB0]
00007f0254fd7bc9  vmovaps xmm13, [rsp+0xC0]
00007f0254fd7bd2  vmovaps xmm14, [rsp+0xD0]
00007f0254fd7bdb  vmovaps xmm15, [rsp+0xE0]
00007f0254fd7be4  add rsp, 0xF0
00007f0254fd7beb  pop r11
00007f0254fd7bed  pop r10
00007f0254fd7bef  pop r9
00007f0254fd7bf1  pop r8
00007f0254fd7bf3  pop rsi
00007f0254fd7bf4  pop rdi
00007f0254fd7bf5  pop rdx
00007f0254fd7bf6  pop rcx
00007f0254fd7bf7  pop rax
00007f0254fd7bf8  add rsp, 0x08
00007f0254fd7bfc  jmp 0x00007F0254FD5DCB
00007f0254fd7c01  call 0x00007F0254EE5820
00007f0254fd7c06  jmp 0x00007F0254FD5DD8
00007f0254fd7c0b  sub rsp, 0x08
00007f0254fd7c0f  push rax
00007f0254fd7c10  push rcx
00007f0254fd7c11  push rdx
00007f0254fd7c12  push rdi
00007f0254fd7c13  push rsi
00007f0254fd7c14  push r8
00007f0254fd7c16  push r9
00007f0254fd7c18  push r10
00007f0254fd7c1a  push r11
00007f0254fd7c1c  sub rsp, 0xF0
00007f0254fd7c23  vmovaps [rsp], xmm0
00007f0254fd7c28  vmovaps [rsp+0x10], xmm2
00007f0254fd7c2e  vmovaps [rsp+0x20], xmm3
00007f0254fd7c34  vmovaps [rsp+0x30], xmm4
00007f0254fd7c3a  vmovaps [rsp+0x40], xmm5
00007f0254fd7c40  vmovaps [rsp+0x50], xmm6
00007f0254fd7c46  vmovaps [rsp+0x60], xmm7
00007f0254fd7c4c  vmovaps [rsp+0x70], xmm8
00007f0254fd7c52  vmovaps [rsp+0x80], xmm9
00007f0254fd7c5b  vmovaps [rsp+0x90], xmm10
00007f0254fd7c64  vmovaps [rsp+0xA0], xmm11
00007f0254fd7c6d  vmovaps [rsp+0xB0], xmm12
00007f0254fd7c76  vmovaps [rsp+0xC0], xmm13
00007f0254fd7c7f  vmovaps [rsp+0xD0], xmm14
00007f0254fd7c88  vmovaps [rsp+0xE0], xmm15
00007f0254fd7c91  sub rsp, 0x30
00007f0254fd7c95  movaps [rsp], xmm1
00007f0254fd7c99  movaps [rsp+0x10], xmm5
00007f0254fd7c9e  movaps [rsp+0x20], xmm7
00007f0254fd7ca3  lea rdi, [rsp]
00007f0254fd7ca7  mov esi, 0x00
00007f0254fd7cac  mov rax, 0x55DD1360A530
00007f0254fd7cb6  call rax
00007f0254fd7cb8  movaps xmm1, [rsp]
00007f0254fd7cbc  add rsp, 0x30
00007f0254fd7cc0  vmovaps xmm0, [rsp]
00007f0254fd7cc5  vmovaps xmm2, [rsp+0x10]
00007f0254fd7ccb  vmovaps xmm3, [rsp+0x20]
00007f0254fd7cd1  vmovaps xmm4, [rsp+0x30]
00007f0254fd7cd7  vmovaps xmm5, [rsp+0x40]
00007f0254fd7cdd  vmovaps xmm6, [rsp+0x50]
00007f0254fd7ce3  vmovaps xmm7, [rsp+0x60]
00007f0254fd7ce9  vmovaps xmm8, [rsp+0x70]
00007f0254fd7cef  vmovaps xmm9, [rsp+0x80]
00007f0254fd7cf8  vmovaps xmm10, [rsp+0x90]
00007f0254fd7d01  vmovaps xmm11, [rsp+0xA0]
00007f0254fd7d0a  vmovaps xmm12, [rsp+0xB0]
00007f0254fd7d13  vmovaps xmm13, [rsp+0xC0]
00007f0254fd7d1c  vmovaps xmm14, [rsp+0xD0]
00007f0254fd7d25  vmovaps xmm15, [rsp+0xE0]
00007f0254fd7d2e  add rsp, 0xF0
00007f0254fd7d35  pop r11
00007f0254fd7d37  pop r10
00007f0254fd7d39  pop r9
00007f0254fd7d3b  pop r8
00007f0254fd7d3d  pop rsi
00007f0254fd7d3e  pop rdi
00007f0254fd7d3f  pop rdx
00007f0254fd7d40  pop rcx
00007f0254fd7d41  pop rax
00007f0254fd7d42  add rsp, 0x08
00007f0254fd7d46  jmp 0x00007F0254FD5E7D
00007f0254fd7d4b  sub rsp, 0x08
00007f0254fd7d4f  push rax
00007f0254fd7d50  push rcx
00007f0254fd7d51  push rdx
00007f0254fd7d52  push rdi
00007f0254fd7d53  push rsi
00007f0254fd7d54  push r8
00007f0254fd7d56  push r9
00007f0254fd7d58  push r10
00007f0254fd7d5a  push r11
00007f0254fd7d5c  sub rsp, 0xF0
00007f0254fd7d63  vmovaps [rsp], xmm0
00007f0254fd7d68  vmovaps [rsp+0x10], xmm1
00007f0254fd7d6e  vmovaps [rsp+0x20], xmm2
00007f0254fd7d74  vmovaps [rsp+0x30], xmm3
00007f0254fd7d7a  vmovaps [rsp+0x40], xmm4
00007f0254fd7d80  vmovaps [rsp+0x50], xmm5
00007f0254fd7d86  vmovaps [rsp+0x60], xmm6
00007f0254fd7d8c  vmovaps [rsp+0x70], xmm8
00007f0254fd7d92  vmovaps [rsp+0x80], xmm9
00007f0254fd7d9b  vmovaps [rsp+0x90], xmm10
00007f0254fd7da4  vmovaps [rsp+0xA0], xmm11
00007f0254fd7dad  vmovaps [rsp+0xB0], xmm12
00007f0254fd7db6  vmovaps [rsp+0xC0], xmm13
00007f0254fd7dbf  vmovaps [rsp+0xD0], xmm14
00007f0254fd7dc8  vmovaps [rsp+0xE0], xmm15
00007f0254fd7dd1  sub rsp, 0x30
00007f0254fd7dd5  movaps [rsp], xmm7
00007f0254fd7dd9  movaps [rsp+0x10], xmm5
00007f0254fd7dde  movaps [rsp+0x20], xmm15
00007f0254fd7de4  lea rdi, [rsp]
00007f0254fd7de8  mov esi, 0x00
00007f0254fd7ded  mov rax, 0x55DD1360A530
00007f0254fd7df7  call rax
00007f0254fd7df9  movaps xmm7, [rsp]
00007f0254fd7dfd  add rsp, 0x30
00007f0254fd7e01  vmovaps xmm0, [rsp]
00007f0254fd7e06  vmovaps xmm1, [rsp+0x10]
00007f0254fd7e0c  vmovaps xmm2, [rsp+0x20]
00007f0254fd7e12  vmovaps xmm3, [rsp+0x30]
00007f0254fd7e18  vmovaps xmm4, [rsp+0x40]
00007f0254fd7e1e  vmovaps xmm5, [rsp+0x50]
00007f0254fd7e24  vmovaps xmm6, [rsp+0x60]
00007f0254fd7e2a  vmovaps xmm8, [rsp+0x70]
00007f0254fd7e30  vmovaps xmm9, [rsp+0x80]
00007f0254fd7e39  vmovaps xmm10, [rsp+0x90]
00007f0254fd7e42  vmovaps xmm11, [rsp+0xA0]
00007f0254fd7e4b  vmovaps xmm12, [rsp+0xB0]
00007f0254fd7e54  vmovaps xmm13, [rsp+0xC0]
00007f0254fd7e5d  vmovaps xmm14, [rsp+0xD0]
00007f0254fd7e66  vmovaps xmm15, [rsp+0xE0]
00007f0254fd7e6f  add rsp, 0xF0
00007f0254fd7e76  pop r11
00007f0254fd7e78  pop r10
00007f0254fd7e7a  pop r9
00007f0254fd7e7c  pop r8
00007f0254fd7e7e  pop rsi
00007f0254fd7e7f  pop rdi
00007f0254fd7e80  pop rdx
00007f0254fd7e81  pop rcx
00007f0254fd7e82  pop rax
00007f0254fd7e83  add rsp, 0x08
00007f0254fd7e87  jmp 0x00007F0254FD5EB3
00007f0254fd7e8c  call 0x00007F0254ED64F0
00007f0254fd7e91  jmp 0x00007F0254FD5EC0
00007f0254fd7e96  sub rsp, 0x08
00007f0254fd7e9a  push rax
00007f0254fd7e9b  push rcx
00007f0254fd7e9c  push rdx
00007f0254fd7e9d  push rdi
00007f0254fd7e9e  push rsi
00007f0254fd7e9f  push r8
00007f0254fd7ea1  push r9
00007f0254fd7ea3  push r10
00007f0254fd7ea5  push r11
00007f0254fd7ea7  sub rsp, 0xF0
00007f0254fd7eae  vmovaps [rsp], xmm0
00007f0254fd7eb3  vmovaps [rsp+0x10], xmm1
00007f0254fd7eb9  vmovaps [rsp+0x20], xmm2
00007f0254fd7ebf  vmovaps [rsp+0x30], xmm3
00007f0254fd7ec5  vmovaps [rsp+0x40], xmm4
00007f0254fd7ecb  vmovaps [rsp+0x50], xmm5
00007f0254fd7ed1  vmovaps [rsp+0x60], xmm6
00007f0254fd7ed7  vmovaps [rsp+0x70], xmm7
00007f0254fd7edd  vmovaps [rsp+0x80], xmm8
00007f0254fd7ee6  vmovaps [rsp+0x90], xmm9
00007f0254fd7eef  vmovaps [rsp+0xA0], xmm10
00007f0254fd7ef8  vmovaps [rsp+0xB0], xmm11
00007f0254fd7f01  vmovaps [rsp+0xC0], xmm12
00007f0254fd7f0a  vmovaps [rsp+0xD0], xmm13
00007f0254fd7f13  vmovaps [rsp+0xE0], xmm14
00007f0254fd7f1c  sub rsp, 0x30
00007f0254fd7f20  movaps [rsp], xmm15
00007f0254fd7f25  movaps [rsp+0x10], xmm5
00007f0254fd7f2a  movaps [rsp+0x20], xmm3
00007f0254fd7f2f  lea rdi, [rsp]
00007f0254fd7f33  mov esi, 0x00
00007f0254fd7f38  mov rax, 0x55DD1360A530
00007f0254fd7f42  call rax
00007f0254fd7f44  movaps xmm15, [rsp]
00007f0254fd7f49  add rsp, 0x30
00007f0254fd7f4d  vmovaps xmm0, [rsp]
00007f0254fd7f52  vmovaps xmm1, [rsp+0x10]
00007f0254fd7f58  vmovaps xmm2, [rsp+0x20]
00007f0254fd7f5e  vmovaps xmm3, [rsp+0x30]
00007f0254fd7f64  vmovaps xmm4, [rsp+0x40]
00007f0254fd7f6a  vmovaps xmm5, [rsp+0x50]
00007f0254fd7f70  vmovaps xmm6, [rsp+0x60]
00007f0254fd7f76  vmovaps xmm7, [rsp+0x70]
00007f0254fd7f7c  vmovaps xmm8, [rsp+0x80]
00007f0254fd7f85  vmovaps xmm9, [rsp+0x90]
00007f0254fd7f8e  vmovaps xmm10, [rsp+0xA0]
00007f0254fd7f97  vmovaps xmm11, [rsp+0xB0]
00007f0254fd7fa0  vmovaps xmm12, [rsp+0xC0]
00007f0254fd7fa9  vmovaps xmm13, [rsp+0xD0]
00007f0254fd7fb2  vmovaps xmm14, [rsp+0xE0]
00007f0254fd7fbb  add rsp, 0xF0
00007f0254fd7fc2  pop r11
00007f0254fd7fc4  pop r10
00007f0254fd7fc6  pop r9
00007f0254fd7fc8  pop r8
00007f0254fd7fca  pop rsi
00007f0254fd7fcb  pop rdi
00007f0254fd7fcc  pop rdx
00007f0254fd7fcd  pop rcx
00007f0254fd7fce  pop rax
00007f0254fd7fcf  add rsp, 0x08
00007f0254fd7fd3  jmp 0x00007F0254FD5EE6
00007f0254fd7fd8  sub rsp, 0x08
00007f0254fd7fdc  push rax
00007f0254fd7fdd  push rcx
00007f0254fd7fde  push rdx
00007f0254fd7fdf  push rdi
00007f0254fd7fe0  push rsi
00007f0254fd7fe1  push r8
00007f0254fd7fe3  push r9
00007f0254fd7fe5  push r10
00007f0254fd7fe7  push r11
00007f0254fd7fe9  sub rsp, 0xF0
00007f0254fd7ff0  vmovaps [rsp], xmm0
00007f0254fd7ff5  vmovaps [rsp+0x10], xmm2
00007f0254fd7ffb  vmovaps [rsp+0x20], xmm3
00007f0254fd8001  vmovaps [rsp+0x30], xmm4
00007f0254fd8007  vmovaps [rsp+0x40], xmm5
00007f0254fd800d  vmovaps [rsp+0x50], xmm6
00007f0254fd8013  vmovaps [rsp+0x60], xmm7
00007f0254fd8019  vmovaps [rsp+0x70], xmm8
00007f0254fd801f  vmovaps [rsp+0x80], xmm9
00007f0254fd8028  vmovaps [rsp+0x90], xmm10
00007f0254fd8031  vmovaps [rsp+0xA0], xmm11
00007f0254fd803a  vmovaps [rsp+0xB0], xmm12
00007f0254fd8043  vmovaps [rsp+0xC0], xmm13
00007f0254fd804c  vmovaps [rsp+0xD0], xmm14
00007f0254fd8055  vmovaps [rsp+0xE0], xmm15
00007f0254fd805e  sub rsp, 0x30
00007f0254fd8062  movaps [rsp], xmm1
00007f0254fd8066  movaps [rsp+0x10], xmm5
00007f0254fd806b  movaps [rsp+0x20], xmm4
00007f0254fd8070  lea rdi, [rsp]
00007f0254fd8074  mov esi, 0x00
00007f0254fd8079  mov rax, 0x55DD1360A530
00007f0254fd8083  call rax
00007f0254fd8085  movaps xmm1, [rsp]
00007f0254fd8089  add rsp, 0x30
00007f0254fd808d  vmovaps xmm0, [rsp]
00007f0254fd8092  vmovaps xmm2, [rsp+0x10]
00007f0254fd8098  vmovaps xmm3, [rsp+0x20]
00007f0254fd809e  vmovaps xmm4, [rsp+0x30]
00007f0254fd80a4  vmovaps xmm5, [rsp+0x40]
00007f0254fd80aa  vmovaps xmm6, [rsp+0x50]
00007f0254fd80b0  vmovaps xmm7, [rsp+0x60]
00007f0254fd80b6  vmovaps xmm8, [rsp+0x70]
00007f0254fd80bc  vmovaps xmm9, [rsp+0x80]
00007f0254fd80c5  vmovaps xmm10, [rsp+0x90]
00007f0254fd80ce  vmovaps xmm11, [rsp+0xA0]
00007f0254fd80d7  vmovaps xmm12, [rsp+0xB0]
00007f0254fd80e0  vmovaps xmm13, [rsp+0xC0]
00007f0254fd80e9  vmovaps xmm14, [rsp+0xD0]
00007f0254fd80f2  vmovaps xmm15, [rsp+0xE0]
00007f0254fd80fb  add rsp, 0xF0
00007f0254fd8102  pop r11
00007f0254fd8104  pop r10
00007f0254fd8106  pop r9
00007f0254fd8108  pop r8
00007f0254fd810a  pop rsi
00007f0254fd810b  pop rdi
00007f0254fd810c  pop rdx
00007f0254fd810d  pop rcx
00007f0254fd810e  pop rax
00007f0254fd810f  add rsp, 0x08
00007f0254fd8113  jmp 0x00007F0254FD5F06
00007f0254fd8118  sub rsp, 0x08
00007f0254fd811c  push rax
00007f0254fd811d  push rcx
00007f0254fd811e  push rdx
00007f0254fd811f  push rdi
00007f0254fd8120  push rsi
00007f0254fd8121  push r8
00007f0254fd8123  push r9
00007f0254fd8125  push r10
00007f0254fd8127  push r11
00007f0254fd8129  sub rsp, 0xF0
00007f0254fd8130  vmovaps [rsp], xmm0
00007f0254fd8135  vmovaps [rsp+0x10], xmm1
00007f0254fd813b  vmovaps [rsp+0x20], xmm2
00007f0254fd8141  vmovaps [rsp+0x30], xmm3
00007f0254fd8147  vmovaps [rsp+0x40], xmm5
00007f0254fd814d  vmovaps [rsp+0x50], xmm6
00007f0254fd8153  vmovaps [rsp+0x60], xmm7
00007f0254fd8159  vmovaps [rsp+0x70], xmm8
00007f0254fd815f  vmovaps [rsp+0x80], xmm9
00007f0254fd8168  vmovaps [rsp+0x90], xmm10
00007f0254fd8171  vmovaps [rsp+0xA0], xmm11
00007f0254fd817a  vmovaps [rsp+0xB0], xmm12
00007f0254fd8183  vmovaps [rsp+0xC0], xmm13
00007f0254fd818c  vmovaps [rsp+0xD0], xmm14
00007f0254fd8195  vmovaps [rsp+0xE0], xmm15
00007f0254fd819e  sub rsp, 0x30
00007f0254fd81a2  movaps [rsp], xmm4
00007f0254fd81a6  movaps [rsp+0x10], xmm3
00007f0254fd81ab  movaps [rsp+0x20], xmm5
00007f0254fd81b0  lea rdi, [rsp]
00007f0254fd81b4  mov esi, 0x00
00007f0254fd81b9  mov rax, 0x55DD1360A530
00007f0254fd81c3  call rax
00007f0254fd81c5  movaps xmm4, [rsp]
00007f0254fd81c9  add rsp, 0x30
00007f0254fd81cd  vmovaps xmm0, [rsp]
00007f0254fd81d2  vmovaps xmm1, [rsp+0x10]
00007f0254fd81d8  vmovaps xmm2, [rsp+0x20]
00007f0254fd81de  vmovaps xmm3, [rsp+0x30]
00007f0254fd81e4  vmovaps xmm5, [rsp+0x40]
00007f0254fd81ea  vmovaps xmm6, [rsp+0x50]
00007f0254fd81f0  vmovaps xmm7, [rsp+0x60]
00007f0254fd81f6  vmovaps xmm8, [rsp+0x70]
00007f0254fd81fc  vmovaps xmm9, [rsp+0x80]
00007f0254fd8205  vmovaps xmm10, [rsp+0x90]
00007f0254fd820e  vmovaps xmm11, [rsp+0xA0]
00007f0254fd8217  vmovaps xmm12, [rsp+0xB0]
00007f0254fd8220  vmovaps xmm13, [rsp+0xC0]
00007f0254fd8229  vmovaps xmm14, [rsp+0xD0]
00007f0254fd8232  vmovaps xmm15, [rsp+0xE0]
00007f0254fd823b  add rsp, 0xF0
00007f0254fd8242  pop r11
00007f0254fd8244  pop r10
00007f0254fd8246  pop r9
00007f0254fd8248  pop r8
00007f0254fd824a  pop rsi
00007f0254fd824b  pop rdi
00007f0254fd824c  pop rdx
00007f0254fd824d  pop rcx
00007f0254fd824e  pop rax
00007f0254fd824f  add rsp, 0x08
00007f0254fd8253  jmp 0x00007F0254FD5F54
00007f0254fd8258  call 0x00007F0254ED64F0
00007f0254fd825d  jmp 0x00007F0254FD5F61
00007f0254fd8262  sub rsp, 0x08
00007f0254fd8266  push rax
00007f0254fd8267  push rcx
00007f0254fd8268  push rdx
00007f0254fd8269  push rdi
00007f0254fd826a  push rsi
00007f0254fd826b  push r8
00007f0254fd826d  push r9
00007f0254fd826f  push r10
00007f0254fd8271  push r11
00007f0254fd8273  sub rsp, 0xF0
00007f0254fd827a  vmovaps [rsp], xmm0
00007f0254fd827f  vmovaps [rsp+0x10], xmm1
00007f0254fd8285  vmovaps [rsp+0x20], xmm2
00007f0254fd828b  vmovaps [rsp+0x30], xmm3
00007f0254fd8291  vmovaps [rsp+0x40], xmm4
00007f0254fd8297  vmovaps [rsp+0x50], xmm6
00007f0254fd829d  vmovaps [rsp+0x60], xmm7
00007f0254fd82a3  vmovaps [rsp+0x70], xmm8
00007f0254fd82a9  vmovaps [rsp+0x80], xmm9
00007f0254fd82b2  vmovaps [rsp+0x90], xmm10
00007f0254fd82bb  vmovaps [rsp+0xA0], xmm11
00007f0254fd82c4  vmovaps [rsp+0xB0], xmm12
00007f0254fd82cd  vmovaps [rsp+0xC0], xmm13
00007f0254fd82d6  vmovaps [rsp+0xD0], xmm14
00007f0254fd82df  vmovaps [rsp+0xE0], xmm15
00007f0254fd82e8  sub rsp, 0x30
00007f0254fd82ec  movaps [rsp], xmm5
00007f0254fd82f0  movaps [rsp+0x10], xmm6
00007f0254fd82f5  movaps [rsp+0x20], xmm3
00007f0254fd82fa  lea rdi, [rsp]
00007f0254fd82fe  mov esi, 0x00
00007f0254fd8303  mov rax, 0x55DD1360A530
00007f0254fd830d  call rax
00007f0254fd830f  movaps xmm5, [rsp]
00007f0254fd8313  add rsp, 0x30
00007f0254fd8317  vmovaps xmm0, [rsp]
00007f0254fd831c  vmovaps xmm1, [rsp+0x10]
00007f0254fd8322  vmovaps xmm2, [rsp+0x20]
00007f0254fd8328  vmovaps xmm3, [rsp+0x30]
00007f0254fd832e  vmovaps xmm4, [rsp+0x40]
00007f0254fd8334  vmovaps xmm6, [rsp+0x50]
00007f0254fd833a  vmovaps xmm7, [rsp+0x60]
00007f0254fd8340  vmovaps xmm8, [rsp+0x70]
00007f0254fd8346  vmovaps xmm9, [rsp+0x80]
00007f0254fd834f  vmovaps xmm10, [rsp+0x90]
00007f0254fd8358  vmovaps xmm11, [rsp+0xA0]
00007f0254fd8361  vmovaps xmm12, [rsp+0xB0]
00007f0254fd836a  vmovaps xmm13, [rsp+0xC0]
00007f0254fd8373  vmovaps xmm14, [rsp+0xD0]
00007f0254fd837c  vmovaps xmm15, [rsp+0xE0]
00007f0254fd8385  add rsp, 0xF0
00007f0254fd838c  pop r11
00007f0254fd838e  pop r10
00007f0254fd8390  pop r9
00007f0254fd8392  pop r8
00007f0254fd8394  pop rsi
00007f0254fd8395  pop rdi
00007f0254fd8396  pop rdx
00007f0254fd8397  pop rcx
00007f0254fd8398  pop rax
00007f0254fd8399  add rsp, 0x08
00007f0254fd839d  jmp 0x00007F0254FD5F87
00007f0254fd83a2  sub rsp, 0x08
00007f0254fd83a6  push rax
00007f0254fd83a7  push rcx
00007f0254fd83a8  push rdx
00007f0254fd83a9  push rdi
00007f0254fd83aa  push rsi
00007f0254fd83ab  push r8
00007f0254fd83ad  push r9
00007f0254fd83af  push r10
00007f0254fd83b1  push r11
00007f0254fd83b3  sub rsp, 0xF0
00007f0254fd83ba  vmovaps [rsp], xmm0
00007f0254fd83bf  vmovaps [rsp+0x10], xmm1
00007f0254fd83c5  vmovaps [rsp+0x20], xmm2
00007f0254fd83cb  vmovaps [rsp+0x30], xmm3
00007f0254fd83d1  vmovaps [rsp+0x40], xmm4
00007f0254fd83d7  vmovaps [rsp+0x50], xmm5
00007f0254fd83dd  vmovaps [rsp+0x60], xmm7
00007f0254fd83e3  vmovaps [rsp+0x70], xmm8
00007f0254fd83e9  vmovaps [rsp+0x80], xmm9
00007f0254fd83f2  vmovaps [rsp+0x90], xmm10
00007f0254fd83fb  vmovaps [rsp+0xA0], xmm11
00007f0254fd8404  vmovaps [rsp+0xB0], xmm12
00007f0254fd840d  vmovaps [rsp+0xC0], xmm13
00007f0254fd8416  vmovaps [rsp+0xD0], xmm14
00007f0254fd841f  vmovaps [rsp+0xE0], xmm15
00007f0254fd8428  sub rsp, 0x30
00007f0254fd842c  movaps [rsp], xmm6
00007f0254fd8430  movaps [rsp+0x10], xmm9
00007f0254fd8436  movaps [rsp+0x20], xmm1
00007f0254fd843b  lea rdi, [rsp]
00007f0254fd843f  mov esi, 0x00
00007f0254fd8444  mov rax, 0x55DD1360A530
00007f0254fd844e  call rax
00007f0254fd8450  movaps xmm6, [rsp]
00007f0254fd8454  add rsp, 0x30
00007f0254fd8458  vmovaps xmm0, [rsp]
00007f0254fd845d  vmovaps xmm1, [rsp+0x10]
00007f0254fd8463  vmovaps xmm2, [rsp+0x20]
00007f0254fd8469  vmovaps xmm3, [rsp+0x30]
00007f0254fd846f  vmovaps xmm4, [rsp+0x40]
00007f0254fd8475  vmovaps xmm5, [rsp+0x50]
00007f0254fd847b  vmovaps xmm7, [rsp+0x60]
00007f0254fd8481  vmovaps xmm8, [rsp+0x70]
00007f0254fd8487  vmovaps xmm9, [rsp+0x80]
00007f0254fd8490  vmovaps xmm10, [rsp+0x90]
00007f0254fd8499  vmovaps xmm11, [rsp+0xA0]
00007f0254fd84a2  vmovaps xmm12, [rsp+0xB0]
00007f0254fd84ab  vmovaps xmm13, [rsp+0xC0]
00007f0254fd84b4  vmovaps xmm14, [rsp+0xD0]
00007f0254fd84bd  vmovaps xmm15, [rsp+0xE0]
00007f0254fd84c6  add rsp, 0xF0
00007f0254fd84cd  pop r11
00007f0254fd84cf  pop r10
00007f0254fd84d1  pop r9
00007f0254fd84d3  pop r8
00007f0254fd84d5  pop rsi
00007f0254fd84d6  pop rdi
00007f0254fd84d7  pop rdx
00007f0254fd84d8  pop rcx
00007f0254fd84d9  pop rax
00007f0254fd84da  add rsp, 0x08
00007f0254fd84de  jmp 0x00007F0254FD5FAB
00007f0254fd84e3  sub rsp, 0x08
00007f0254fd84e7  push rax
00007f0254fd84e8  push rcx
00007f0254fd84e9  push rdx
00007f0254fd84ea  push rdi
00007f0254fd84eb  push rsi
00007f0254fd84ec  push r8
00007f0254fd84ee  push r9
00007f0254fd84f0  push r10
00007f0254fd84f2  push r11
00007f0254fd84f4  sub rsp, 0xF0
00007f0254fd84fb  vmovaps [rsp], xmm0
00007f0254fd8500  vmovaps [rsp+0x10], xmm1
00007f0254fd8506  vmovaps [rsp+0x20], xmm2
00007f0254fd850c  vmovaps [rsp+0x30], xmm3
00007f0254fd8512  vmovaps [rsp+0x40], xmm4
00007f0254fd8518  vmovaps [rsp+0x50], xmm5
00007f0254fd851e  vmovaps [rsp+0x60], xmm6
00007f0254fd8524  vmovaps [rsp+0x70], xmm7
00007f0254fd852a  vmovaps [rsp+0x80], xmm8
00007f0254fd8533  vmovaps [rsp+0x90], xmm10
00007f0254fd853c  vmovaps [rsp+0xA0], xmm11
00007f0254fd8545  vmovaps [rsp+0xB0], xmm12
00007f0254fd854e  vmovaps [rsp+0xC0], xmm13
00007f0254fd8557  vmovaps [rsp+0xD0], xmm14
00007f0254fd8560  vmovaps [rsp+0xE0], xmm15
00007f0254fd8569  sub rsp, 0x30
00007f0254fd856d  movaps [rsp], xmm9
00007f0254fd8572  movaps [rsp+0x10], xmm3
00007f0254fd8577  movaps [rsp+0x20], xmm1
00007f0254fd857c  lea rdi, [rsp]
00007f0254fd8580  mov esi, 0x00
00007f0254fd8585  mov rax, 0x55DD1360A530
00007f0254fd858f  call rax
00007f0254fd8591  movaps xmm9, [rsp]
00007f0254fd8596  add rsp, 0x30
00007f0254fd859a  vmovaps xmm0, [rsp]
00007f0254fd859f  vmovaps xmm1, [rsp+0x10]
00007f0254fd85a5  vmovaps xmm2, [rsp+0x20]
00007f0254fd85ab  vmovaps xmm3, [rsp+0x30]
00007f0254fd85b1  vmovaps xmm4, [rsp+0x40]
00007f0254fd85b7  vmovaps xmm5, [rsp+0x50]
00007f0254fd85bd  vmovaps xmm6, [rsp+0x60]
00007f0254fd85c3  vmovaps xmm7, [rsp+0x70]
00007f0254fd85c9  vmovaps xmm8, [rsp+0x80]
00007f0254fd85d2  vmovaps xmm10, [rsp+0x90]
00007f0254fd85db  vmovaps xmm11, [rsp+0xA0]
00007f0254fd85e4  vmovaps xmm12, [rsp+0xB0]
00007f0254fd85ed  vmovaps xmm13, [rsp+0xC0]
00007f0254fd85f6  vmovaps xmm14, [rsp+0xD0]
00007f0254fd85ff  vmovaps xmm15, [rsp+0xE0]
00007f0254fd8608  add rsp, 0xF0
00007f0254fd860f  pop r11
00007f0254fd8611  pop r10
00007f0254fd8613  pop r9
00007f0254fd8615  pop r8
00007f0254fd8617  pop rsi
00007f0254fd8618  pop rdi
00007f0254fd8619  pop rdx
00007f0254fd861a  pop rcx
00007f0254fd861b  pop rax
00007f0254fd861c  add rsp, 0x08
00007f0254fd8620  jmp 0x00007F0254FD5FF7
00007f0254fd8625  call 0x00007F0254ED64F0
00007f0254fd862a  jmp 0x00007F0254FD6004
00007f0254fd862f  sub rsp, 0x08
00007f0254fd8633  push rax
00007f0254fd8634  push rcx
00007f0254fd8635  push rdx
00007f0254fd8636  push rdi
00007f0254fd8637  push rsi
00007f0254fd8638  push r8
00007f0254fd863a  push r9
00007f0254fd863c  push r10
00007f0254fd863e  push r11
00007f0254fd8640  sub rsp, 0xF0
00007f0254fd8647  vmovaps [rsp], xmm0
00007f0254fd864c  vmovaps [rsp+0x10], xmm1
00007f0254fd8652  vmovaps [rsp+0x20], xmm2
00007f0254fd8658  vmovaps [rsp+0x30], xmm3
00007f0254fd865e  vmovaps [rsp+0x40], xmm4
00007f0254fd8664  vmovaps [rsp+0x50], xmm5
00007f0254fd866a  vmovaps [rsp+0x60], xmm6
00007f0254fd8670  vmovaps [rsp+0x70], xmm7
00007f0254fd8676  vmovaps [rsp+0x80], xmm8
00007f0254fd867f  vmovaps [rsp+0x90], xmm9
00007f0254fd8688  vmovaps [rsp+0xA0], xmm10
00007f0254fd8691  vmovaps [rsp+0xB0], xmm11
00007f0254fd869a  vmovaps [rsp+0xC0], xmm12
00007f0254fd86a3  vmovaps [rsp+0xD0], xmm13
00007f0254fd86ac  vmovaps [rsp+0xE0], xmm14
00007f0254fd86b5  sub rsp, 0x30
00007f0254fd86b9  movaps [rsp], xmm15
00007f0254fd86be  movaps [rsp+0x10], xmm3
00007f0254fd86c3  movaps [rsp+0x20], xmm7
00007f0254fd86c8  lea rdi, [rsp]
00007f0254fd86cc  mov esi, 0x00
00007f0254fd86d1  mov rax, 0x55DD1360A530
00007f0254fd86db  call rax
00007f0254fd86dd  movaps xmm15, [rsp]
00007f0254fd86e2  add rsp, 0x30
00007f0254fd86e6  vmovaps xmm0, [rsp]
00007f0254fd86eb  vmovaps xmm1, [rsp+0x10]
00007f0254fd86f1  vmovaps xmm2, [rsp+0x20]
00007f0254fd86f7  vmovaps xmm3, [rsp+0x30]
00007f0254fd86fd  vmovaps xmm4, [rsp+0x40]
00007f0254fd8703  vmovaps xmm5, [rsp+0x50]
00007f0254fd8709  vmovaps xmm6, [rsp+0x60]
00007f0254fd870f  vmovaps xmm7, [rsp+0x70]
00007f0254fd8715  vmovaps xmm8, [rsp+0x80]
00007f0254fd871e  vmovaps xmm9, [rsp+0x90]
00007f0254fd8727  vmovaps xmm10, [rsp+0xA0]
00007f0254fd8730  vmovaps xmm11, [rsp+0xB0]
00007f0254fd8739  vmovaps xmm12, [rsp+0xC0]
00007f0254fd8742  vmovaps xmm13, [rsp+0xD0]
00007f0254fd874b  vmovaps xmm14, [rsp+0xE0]
00007f0254fd8754  add rsp, 0xF0
00007f0254fd875b  pop r11
00007f0254fd875d  pop r10
00007f0254fd875f  pop r9
00007f0254fd8761  pop r8
00007f0254fd8763  pop rsi
00007f0254fd8764  pop rdi
00007f0254fd8765  pop rdx
00007f0254fd8766  pop rcx
00007f0254fd8767  pop rax
00007f0254fd8768  add rsp, 0x08
00007f0254fd876c  jmp 0x00007F0254FD6030
00007f0254fd8771  sub rsp, 0x08
00007f0254fd8775  push rax
00007f0254fd8776  push rcx
00007f0254fd8777  push rdx
00007f0254fd8778  push rdi
00007f0254fd8779  push rsi
00007f0254fd877a  push r8
00007f0254fd877c  push r9
00007f0254fd877e  push r10
00007f0254fd8780  push r11
00007f0254fd8782  sub rsp, 0xF0
00007f0254fd8789  vmovaps [rsp], xmm0
00007f0254fd878e  vmovaps [rsp+0x10], xmm1
00007f0254fd8794  vmovaps [rsp+0x20], xmm2
00007f0254fd879a  vmovaps [rsp+0x30], xmm4
00007f0254fd87a0  vmovaps [rsp+0x40], xmm5
00007f0254fd87a6  vmovaps [rsp+0x50], xmm6
00007f0254fd87ac  vmovaps [rsp+0x60], xmm7
00007f0254fd87b2  vmovaps [rsp+0x70], xmm8
00007f0254fd87b8  vmovaps [rsp+0x80], xmm9
00007f0254fd87c1  vmovaps [rsp+0x90], xmm10
00007f0254fd87ca  vmovaps [rsp+0xA0], xmm11
00007f0254fd87d3  vmovaps [rsp+0xB0], xmm12
00007f0254fd87dc  vmovaps [rsp+0xC0], xmm13
00007f0254fd87e5  vmovaps [rsp+0xD0], xmm14
00007f0254fd87ee  vmovaps [rsp+0xE0], xmm15
00007f0254fd87f7  sub rsp, 0x30
00007f0254fd87fb  movaps [rsp], xmm3
00007f0254fd87ff  movaps [rsp+0x10], xmm1
00007f0254fd8804  movaps [rsp+0x20], xmm15
00007f0254fd880a  lea rdi, [rsp]
00007f0254fd880e  mov esi, 0x00
00007f0254fd8813  mov rax, 0x55DD1360A530
00007f0254fd881d  call rax
00007f0254fd881f  movaps xmm3, [rsp]
00007f0254fd8823  add rsp, 0x30
00007f0254fd8827  vmovaps xmm0, [rsp]
00007f0254fd882c  vmovaps xmm1, [rsp+0x10]
00007f0254fd8832  vmovaps xmm2, [rsp+0x20]
00007f0254fd8838  vmovaps xmm4, [rsp+0x30]
00007f0254fd883e  vmovaps xmm5, [rsp+0x40]
00007f0254fd8844  vmovaps xmm6, [rsp+0x50]
00007f0254fd884a  vmovaps xmm7, [rsp+0x60]
00007f0254fd8850  vmovaps xmm8, [rsp+0x70]
00007f0254fd8856  vmovaps xmm9, [rsp+0x80]
00007f0254fd885f  vmovaps xmm10, [rsp+0x90]
00007f0254fd8868  vmovaps xmm11, [rsp+0xA0]
00007f0254fd8871  vmovaps xmm12, [rsp+0xB0]
00007f0254fd887a  vmovaps xmm13, [rsp+0xC0]
00007f0254fd8883  vmovaps xmm14, [rsp+0xD0]
00007f0254fd888c  vmovaps xmm15, [rsp+0xE0]
00007f0254fd8895  add rsp, 0xF0
00007f0254fd889c  pop r11
00007f0254fd889e  pop r10
00007f0254fd88a0  pop r9
00007f0254fd88a2  pop r8
00007f0254fd88a4  pop rsi
00007f0254fd88a5  pop rdi
00007f0254fd88a6  pop rdx
00007f0254fd88a7  pop rcx
00007f0254fd88a8  pop rax
00007f0254fd88a9  add rsp, 0x08
00007f0254fd88ad  jmp 0x00007F0254FD60BF
00007f0254fd88b2  call 0x00007F0254ED64F0
00007f0254fd88b7  jmp 0x00007F0254FD60C9
00007f0254fd88bc  sub rsp, 0x08
00007f0254fd88c0  push rax
00007f0254fd88c1  push rcx
00007f0254fd88c2  push rdx
00007f0254fd88c3  push rdi
00007f0254fd88c4  push rsi
00007f0254fd88c5  push r8
00007f0254fd88c7  push r9
00007f0254fd88c9  push r10
00007f0254fd88cb  push r11
00007f0254fd88cd  sub rsp, 0xF0
00007f0254fd88d4  vmovaps [rsp], xmm0
00007f0254fd88d9  vmovaps [rsp+0x10], xmm1
00007f0254fd88df  vmovaps [rsp+0x20], xmm2
00007f0254fd88e5  vmovaps [rsp+0x30], xmm3
00007f0254fd88eb  vmovaps [rsp+0x40], xmm4
00007f0254fd88f1  vmovaps [rsp+0x50], xmm5
00007f0254fd88f7  vmovaps [rsp+0x60], xmm6
00007f0254fd88fd  vmovaps [rsp+0x70], xmm7
00007f0254fd8903  vmovaps [rsp+0x80], xmm8
00007f0254fd890c  vmovaps [rsp+0x90], xmm9
00007f0254fd8915  vmovaps [rsp+0xA0], xmm10
00007f0254fd891e  vmovaps [rsp+0xB0], xmm11
00007f0254fd8927  vmovaps [rsp+0xC0], xmm12
00007f0254fd8930  vmovaps [rsp+0xD0], xmm13
00007f0254fd8939  vmovaps [rsp+0xE0], xmm14
00007f0254fd8942  sub rsp, 0x30
00007f0254fd8946  movaps [rsp], xmm15
00007f0254fd894b  movaps [rsp+0x10], xmm14
00007f0254fd8951  movaps [rsp+0x20], xmm4
00007f0254fd8956  lea rdi, [rsp]
00007f0254fd895a  mov esi, 0x00
00007f0254fd895f  mov rax, 0x55DD1360A530
00007f0254fd8969  call rax
00007f0254fd896b  movaps xmm15, [rsp]
00007f0254fd8970  add rsp, 0x30
00007f0254fd8974  vmovaps xmm0, [rsp]
00007f0254fd8979  vmovaps xmm1, [rsp+0x10]
00007f0254fd897f  vmovaps xmm2, [rsp+0x20]
00007f0254fd8985  vmovaps xmm3, [rsp+0x30]
00007f0254fd898b  vmovaps xmm4, [rsp+0x40]
00007f0254fd8991  vmovaps xmm5, [rsp+0x50]
00007f0254fd8997  vmovaps xmm6, [rsp+0x60]
00007f0254fd899d  vmovaps xmm7, [rsp+0x70]
00007f0254fd89a3  vmovaps xmm8, [rsp+0x80]
00007f0254fd89ac  vmovaps xmm9, [rsp+0x90]
00007f0254fd89b5  vmovaps xmm10, [rsp+0xA0]
00007f0254fd89be  vmovaps xmm11, [rsp+0xB0]
00007f0254fd89c7  vmovaps xmm12, [rsp+0xC0]
00007f0254fd89d0  vmovaps xmm13, [rsp+0xD0]
00007f0254fd89d9  vmovaps xmm14, [rsp+0xE0]
00007f0254fd89e2  add rsp, 0xF0
00007f0254fd89e9  pop r11
00007f0254fd89eb  pop r10
00007f0254fd89ed  pop r9
00007f0254fd89ef  pop r8
00007f0254fd89f1  pop rsi
00007f0254fd89f2  pop rdi
00007f0254fd89f3  pop rdx
00007f0254fd89f4  pop rcx
00007f0254fd89f5  pop rax
00007f0254fd89f6  add rsp, 0x08
00007f0254fd89fa  jmp 0x00007F0254FD60F7
00007f0254fd89ff  sub rsp, 0x08
00007f0254fd8a03  push rax
00007f0254fd8a04  push rcx
00007f0254fd8a05  push rdx
00007f0254fd8a06  push rdi
00007f0254fd8a07  push rsi
00007f0254fd8a08  push r8
00007f0254fd8a0a  push r9
00007f0254fd8a0c  push r10
00007f0254fd8a0e  push r11
00007f0254fd8a10  sub rsp, 0xF0
00007f0254fd8a17  vmovaps [rsp], xmm0
00007f0254fd8a1c  vmovaps [rsp+0x10], xmm1
00007f0254fd8a22  vmovaps [rsp+0x20], xmm2
00007f0254fd8a28  vmovaps [rsp+0x30], xmm3
00007f0254fd8a2e  vmovaps [rsp+0x40], xmm4
00007f0254fd8a34  vmovaps [rsp+0x50], xmm5
00007f0254fd8a3a  vmovaps [rsp+0x60], xmm6
00007f0254fd8a40  vmovaps [rsp+0x70], xmm7
00007f0254fd8a46  vmovaps [rsp+0x80], xmm8
00007f0254fd8a4f  vmovaps [rsp+0x90], xmm9
00007f0254fd8a58  vmovaps [rsp+0xA0], xmm10
00007f0254fd8a61  vmovaps [rsp+0xB0], xmm11
00007f0254fd8a6a  vmovaps [rsp+0xC0], xmm12
00007f0254fd8a73  vmovaps [rsp+0xD0], xmm13
00007f0254fd8a7c  vmovaps [rsp+0xE0], xmm15
00007f0254fd8a85  sub rsp, 0x30
00007f0254fd8a89  movaps [rsp], xmm14
00007f0254fd8a8e  movaps [rsp+0x10], xmm2
00007f0254fd8a93  movaps [rsp+0x20], xmm1
00007f0254fd8a98  lea rdi, [rsp]
00007f0254fd8a9c  mov esi, 0x00
00007f0254fd8aa1  mov rax, 0x55DD1360A530
00007f0254fd8aab  call rax
00007f0254fd8aad  movaps xmm14, [rsp]
00007f0254fd8ab2  add rsp, 0x30
00007f0254fd8ab6  vmovaps xmm0, [rsp]
00007f0254fd8abb  vmovaps xmm1, [rsp+0x10]
00007f0254fd8ac1  vmovaps xmm2, [rsp+0x20]
00007f0254fd8ac7  vmovaps xmm3, [rsp+0x30]
00007f0254fd8acd  vmovaps xmm4, [rsp+0x40]
00007f0254fd8ad3  vmovaps xmm5, [rsp+0x50]
00007f0254fd8ad9  vmovaps xmm6, [rsp+0x60]
00007f0254fd8adf  vmovaps xmm7, [rsp+0x70]
00007f0254fd8ae5  vmovaps xmm8, [rsp+0x80]
00007f0254fd8aee  vmovaps xmm9, [rsp+0x90]
00007f0254fd8af7  vmovaps xmm10, [rsp+0xA0]
00007f0254fd8b00  vmovaps xmm11, [rsp+0xB0]
00007f0254fd8b09  vmovaps xmm12, [rsp+0xC0]
00007f0254fd8b12  vmovaps xmm13, [rsp+0xD0]
00007f0254fd8b1b  vmovaps xmm15, [rsp+0xE0]
00007f0254fd8b24  add rsp, 0xF0
00007f0254fd8b2b  pop r11
00007f0254fd8b2d  pop r10
00007f0254fd8b2f  pop r9
00007f0254fd8b31  pop r8
00007f0254fd8b33  pop rsi
00007f0254fd8b34  pop rdi
00007f0254fd8b35  pop rdx
00007f0254fd8b36  pop rcx
00007f0254fd8b37  pop rax
00007f0254fd8b38  add rsp, 0x08
00007f0254fd8b3c  jmp 0x00007F0254FD611D
00007f0254fd8b41  sub rsp, 0x08
00007f0254fd8b45  push rax
00007f0254fd8b46  push rcx
00007f0254fd8b47  push rdx
00007f0254fd8b48  push rdi
00007f0254fd8b49  push rsi
00007f0254fd8b4a  push r8
00007f0254fd8b4c  push r9
00007f0254fd8b4e  push r10
00007f0254fd8b50  push r11
00007f0254fd8b52  sub rsp, 0xF0
00007f0254fd8b59  vmovaps [rsp], xmm0
00007f0254fd8b5e  vmovaps [rsp+0x10], xmm2
00007f0254fd8b64  vmovaps [rsp+0x20], xmm3
00007f0254fd8b6a  vmovaps [rsp+0x30], xmm4
00007f0254fd8b70  vmovaps [rsp+0x40], xmm5
00007f0254fd8b76  vmovaps [rsp+0x50], xmm6
00007f0254fd8b7c  vmovaps [rsp+0x60], xmm7
00007f0254fd8b82  vmovaps [rsp+0x70], xmm8
00007f0254fd8b88  vmovaps [rsp+0x80], xmm9
00007f0254fd8b91  vmovaps [rsp+0x90], xmm10
00007f0254fd8b9a  vmovaps [rsp+0xA0], xmm11
00007f0254fd8ba3  vmovaps [rsp+0xB0], xmm12
00007f0254fd8bac  vmovaps [rsp+0xC0], xmm13
00007f0254fd8bb5  vmovaps [rsp+0xD0], xmm14
00007f0254fd8bbe  vmovaps [rsp+0xE0], xmm15
00007f0254fd8bc7  sub rsp, 0x30
00007f0254fd8bcb  movaps [rsp], xmm1
00007f0254fd8bcf  movaps [rsp+0x10], xmm4
00007f0254fd8bd4  movaps [rsp+0x20], xmm9
00007f0254fd8bda  lea rdi, [rsp]
00007f0254fd8bde  mov esi, 0x00
00007f0254fd8be3  mov rax, 0x55DD1360A530
00007f0254fd8bed  call rax
00007f0254fd8bef  movaps xmm1, [rsp]
00007f0254fd8bf3  add rsp, 0x30
00007f0254fd8bf7  vmovaps xmm0, [rsp]
00007f0254fd8bfc  vmovaps xmm2, [rsp+0x10]
00007f0254fd8c02  vmovaps xmm3, [rsp+0x20]
00007f0254fd8c08  vmovaps xmm4, [rsp+0x30]
00007f0254fd8c0e  vmovaps xmm5, [rsp+0x40]
00007f0254fd8c14  vmovaps xmm6, [rsp+0x50]
00007f0254fd8c1a  vmovaps xmm7, [rsp+0x60]
00007f0254fd8c20  vmovaps xmm8, [rsp+0x70]
00007f0254fd8c26  vmovaps xmm9, [rsp+0x80]
00007f0254fd8c2f  vmovaps xmm10, [rsp+0x90]
00007f0254fd8c38  vmovaps xmm11, [rsp+0xA0]
00007f0254fd8c41  vmovaps xmm12, [rsp+0xB0]
00007f0254fd8c4a  vmovaps xmm13, [rsp+0xC0]
00007f0254fd8c53  vmovaps xmm14, [rsp+0xD0]
00007f0254fd8c5c  vmovaps xmm15, [rsp+0xE0]
00007f0254fd8c65  add rsp, 0xF0
00007f0254fd8c6c  pop r11
00007f0254fd8c6e  pop r10
00007f0254fd8c70  pop r9
00007f0254fd8c72  pop r8
00007f0254fd8c74  pop rsi
00007f0254fd8c75  pop rdi
00007f0254fd8c76  pop rdx
00007f0254fd8c77  pop rcx
00007f0254fd8c78  pop rax
00007f0254fd8c79  add rsp, 0x08
00007f0254fd8c7d  jmp 0x00007F0254FD613B
00007f0254fd8c82  sub rsp, 0x08
00007f0254fd8c86  push rax
00007f0254fd8c87  push rcx
00007f0254fd8c88  push rdx
00007f0254fd8c89  push rdi
00007f0254fd8c8a  push rsi
00007f0254fd8c8b  push r8
00007f0254fd8c8d  push r9
00007f0254fd8c8f  push r10
00007f0254fd8c91  push r11
00007f0254fd8c93  sub rsp, 0xF0
00007f0254fd8c9a  vmovaps [rsp], xmm0
00007f0254fd8c9f  vmovaps [rsp+0x10], xmm1
00007f0254fd8ca5  vmovaps [rsp+0x20], xmm2
00007f0254fd8cab  vmovaps [rsp+0x30], xmm3
00007f0254fd8cb1  vmovaps [rsp+0x40], xmm5
00007f0254fd8cb7  vmovaps [rsp+0x50], xmm6
00007f0254fd8cbd  vmovaps [rsp+0x60], xmm7
00007f0254fd8cc3  vmovaps [rsp+0x70], xmm8
00007f0254fd8cc9  vmovaps [rsp+0x80], xmm9
00007f0254fd8cd2  vmovaps [rsp+0x90], xmm10
00007f0254fd8cdb  vmovaps [rsp+0xA0], xmm11
00007f0254fd8ce4  vmovaps [rsp+0xB0], xmm12
00007f0254fd8ced  vmovaps [rsp+0xC0], xmm13
00007f0254fd8cf6  vmovaps [rsp+0xD0], xmm14
00007f0254fd8cff  vmovaps [rsp+0xE0], xmm15
00007f0254fd8d08  sub rsp, 0x30
00007f0254fd8d0c  movaps [rsp], xmm4
00007f0254fd8d10  movaps [rsp+0x10], xmm2
00007f0254fd8d15  movaps [rsp+0x20], xmm9
00007f0254fd8d1b  lea rdi, [rsp]
00007f0254fd8d1f  mov esi, 0x00
00007f0254fd8d24  mov rax, 0x55DD1360A530
00007f0254fd8d2e  call rax
00007f0254fd8d30  movaps xmm4, [rsp]
00007f0254fd8d34  add rsp, 0x30
00007f0254fd8d38  vmovaps xmm0, [rsp]
00007f0254fd8d3d  vmovaps xmm1, [rsp+0x10]
00007f0254fd8d43  vmovaps xmm2, [rsp+0x20]
00007f0254fd8d49  vmovaps xmm3, [rsp+0x30]
00007f0254fd8d4f  vmovaps xmm5, [rsp+0x40]
00007f0254fd8d55  vmovaps xmm6, [rsp+0x50]
00007f0254fd8d5b  vmovaps xmm7, [rsp+0x60]
00007f0254fd8d61  vmovaps xmm8, [rsp+0x70]
00007f0254fd8d67  vmovaps xmm9, [rsp+0x80]
00007f0254fd8d70  vmovaps xmm10, [rsp+0x90]
00007f0254fd8d79  vmovaps xmm11, [rsp+0xA0]
00007f0254fd8d82  vmovaps xmm12, [rsp+0xB0]
00007f0254fd8d8b  vmovaps xmm13, [rsp+0xC0]
00007f0254fd8d94  vmovaps xmm14, [rsp+0xD0]
00007f0254fd8d9d  vmovaps xmm15, [rsp+0xE0]
00007f0254fd8da6  add rsp, 0xF0
00007f0254fd8dad  pop r11
00007f0254fd8daf  pop r10
00007f0254fd8db1  pop r9
00007f0254fd8db3  pop r8
00007f0254fd8db5  pop rsi
00007f0254fd8db6  pop rdi
00007f0254fd8db7  pop rdx
00007f0254fd8db8  pop rcx
00007f0254fd8db9  pop rax
00007f0254fd8dba  add rsp, 0x08
00007f0254fd8dbe  jmp 0x00007F0254FD616B
00007f0254fd8dc3  sub rsp, 0x08
00007f0254fd8dc7  push rax
00007f0254fd8dc8  push rcx
00007f0254fd8dc9  push rdx
00007f0254fd8dca  push rdi
00007f0254fd8dcb  push rsi
00007f0254fd8dcc  push r8
00007f0254fd8dce  push r9
00007f0254fd8dd0  push r10
00007f0254fd8dd2  push r11
00007f0254fd8dd4  sub rsp, 0xF0
00007f0254fd8ddb  vmovaps [rsp], xmm0
00007f0254fd8de0  vmovaps [rsp+0x10], xmm1
00007f0254fd8de6  vmovaps [rsp+0x20], xmm2
00007f0254fd8dec  vmovaps [rsp+0x30], xmm3
00007f0254fd8df2  vmovaps [rsp+0x40], xmm4
00007f0254fd8df8  vmovaps [rsp+0x50], xmm5
00007f0254fd8dfe  vmovaps [rsp+0x60], xmm6
00007f0254fd8e04  vmovaps [rsp+0x70], xmm7
00007f0254fd8e0a  vmovaps [rsp+0x80], xmm8
00007f0254fd8e13  vmovaps [rsp+0x90], xmm10
00007f0254fd8e1c  vmovaps [rsp+0xA0], xmm11
00007f0254fd8e25  vmovaps [rsp+0xB0], xmm12
00007f0254fd8e2e  vmovaps [rsp+0xC0], xmm13
00007f0254fd8e37  vmovaps [rsp+0xD0], xmm14
00007f0254fd8e40  vmovaps [rsp+0xE0], xmm15
00007f0254fd8e49  sub rsp, 0x30
00007f0254fd8e4d  movaps [rsp], xmm9
00007f0254fd8e52  movaps [rsp+0x10], xmm2
00007f0254fd8e57  movaps [rsp+0x20], xmm1
00007f0254fd8e5c  lea rdi, [rsp]
00007f0254fd8e60  mov esi, 0x00
00007f0254fd8e65  mov rax, 0x55DD1360A530
00007f0254fd8e6f  call rax
00007f0254fd8e71  movaps xmm9, [rsp]
00007f0254fd8e76  add rsp, 0x30
00007f0254fd8e7a  vmovaps xmm0, [rsp]
00007f0254fd8e7f  vmovaps xmm1, [rsp+0x10]
00007f0254fd8e85  vmovaps xmm2, [rsp+0x20]
00007f0254fd8e8b  vmovaps xmm3, [rsp+0x30]
00007f0254fd8e91  vmovaps xmm4, [rsp+0x40]
00007f0254fd8e97  vmovaps xmm5, [rsp+0x50]
00007f0254fd8e9d  vmovaps xmm6, [rsp+0x60]
00007f0254fd8ea3  vmovaps xmm7, [rsp+0x70]
00007f0254fd8ea9  vmovaps xmm8, [rsp+0x80]
00007f0254fd8eb2  vmovaps xmm10, [rsp+0x90]
00007f0254fd8ebb  vmovaps xmm11, [rsp+0xA0]
00007f0254fd8ec4  vmovaps xmm12, [rsp+0xB0]
00007f0254fd8ecd  vmovaps xmm13, [rsp+0xC0]
00007f0254fd8ed6  vmovaps xmm14, [rsp+0xD0]
00007f0254fd8edf  vmovaps xmm15, [rsp+0xE0]
00007f0254fd8ee8  add rsp, 0xF0
00007f0254fd8eef  pop r11
00007f0254fd8ef1  pop r10
00007f0254fd8ef3  pop r9
00007f0254fd8ef5  pop r8
00007f0254fd8ef7  pop rsi
00007f0254fd8ef8  pop rdi
00007f0254fd8ef9  pop rdx
00007f0254fd8efa  pop rcx
00007f0254fd8efb  pop rax
00007f0254fd8efc  add rsp, 0x08
00007f0254fd8f00  jmp 0x00007F0254FD61A1
00007f0254fd8f05  sub rsp, 0x08
00007f0254fd8f09  push rax
00007f0254fd8f0a  push rcx
00007f0254fd8f0b  push rdx
00007f0254fd8f0c  push rdi
00007f0254fd8f0d  push rsi
00007f0254fd8f0e  push r8
00007f0254fd8f10  push r9
00007f0254fd8f12  push r10
00007f0254fd8f14  push r11
00007f0254fd8f16  sub rsp, 0xF0
00007f0254fd8f1d  vmovaps [rsp], xmm0
00007f0254fd8f22  vmovaps [rsp+0x10], xmm2
00007f0254fd8f28  vmovaps [rsp+0x20], xmm3
00007f0254fd8f2e  vmovaps [rsp+0x30], xmm4
00007f0254fd8f34  vmovaps [rsp+0x40], xmm5
00007f0254fd8f3a  vmovaps [rsp+0x50], xmm6
00007f0254fd8f40  vmovaps [rsp+0x60], xmm7
00007f0254fd8f46  vmovaps [rsp+0x70], xmm8
00007f0254fd8f4c  vmovaps [rsp+0x80], xmm9
00007f0254fd8f55  vmovaps [rsp+0x90], xmm10
00007f0254fd8f5e  vmovaps [rsp+0xA0], xmm11
00007f0254fd8f67  vmovaps [rsp+0xB0], xmm12
00007f0254fd8f70  vmovaps [rsp+0xC0], xmm13
00007f0254fd8f79  vmovaps [rsp+0xD0], xmm14
00007f0254fd8f82  vmovaps [rsp+0xE0], xmm15
00007f0254fd8f8b  sub rsp, 0x30
00007f0254fd8f8f  movaps [rsp], xmm1
00007f0254fd8f93  movaps [rsp+0x10], xmm15
00007f0254fd8f99  movaps [rsp+0x20], xmm6
00007f0254fd8f9e  lea rdi, [rsp]
00007f0254fd8fa2  mov esi, 0x00
00007f0254fd8fa7  mov rax, 0x55DD1360A530
00007f0254fd8fb1  call rax
00007f0254fd8fb3  movaps xmm1, [rsp]
00007f0254fd8fb7  add rsp, 0x30
00007f0254fd8fbb  vmovaps xmm0, [rsp]
00007f0254fd8fc0  vmovaps xmm2, [rsp+0x10]
00007f0254fd8fc6  vmovaps xmm3, [rsp+0x20]
00007f0254fd8fcc  vmovaps xmm4, [rsp+0x30]
00007f0254fd8fd2  vmovaps xmm5, [rsp+0x40]
00007f0254fd8fd8  vmovaps xmm6, [rsp+0x50]
00007f0254fd8fde  vmovaps xmm7, [rsp+0x60]
00007f0254fd8fe4  vmovaps xmm8, [rsp+0x70]
00007f0254fd8fea  vmovaps xmm9, [rsp+0x80]
00007f0254fd8ff3  vmovaps xmm10, [rsp+0x90]
00007f0254fd8ffc  vmovaps xmm11, [rsp+0xA0]
00007f0254fd9005  vmovaps xmm12, [rsp+0xB0]
00007f0254fd900e  vmovaps xmm13, [rsp+0xC0]
00007f0254fd9017  vmovaps xmm14, [rsp+0xD0]
00007f0254fd9020  vmovaps xmm15, [rsp+0xE0]
00007f0254fd9029  add rsp, 0xF0
00007f0254fd9030  pop r11
00007f0254fd9032  pop r10
00007f0254fd9034  pop r9
00007f0254fd9036  pop r8
00007f0254fd9038  pop rsi
00007f0254fd9039  pop rdi
00007f0254fd903a  pop rdx
00007f0254fd903b  pop rcx
00007f0254fd903c  pop rax
00007f0254fd903d  add rsp, 0x08
00007f0254fd9041  jmp 0x00007F0254FD61C2
00007f0254fd9046  sub rsp, 0x08
00007f0254fd904a  push rax
00007f0254fd904b  push rcx
00007f0254fd904c  push rdx
00007f0254fd904d  push rdi
00007f0254fd904e  push rsi
00007f0254fd904f  push r8
00007f0254fd9051  push r9
00007f0254fd9053  push r10
00007f0254fd9055  push r11
00007f0254fd9057  sub rsp, 0xF0
00007f0254fd905e  vmovaps [rsp], xmm0
00007f0254fd9063  vmovaps [rsp+0x10], xmm1
00007f0254fd9069  vmovaps [rsp+0x20], xmm2
00007f0254fd906f  vmovaps [rsp+0x30], xmm3
00007f0254fd9075  vmovaps [rsp+0x40], xmm4
00007f0254fd907b  vmovaps [rsp+0x50], xmm5
00007f0254fd9081  vmovaps [rsp+0x60], xmm6
00007f0254fd9087  vmovaps [rsp+0x70], xmm7
00007f0254fd908d  vmovaps [rsp+0x80], xmm8
00007f0254fd9096  vmovaps [rsp+0x90], xmm9
00007f0254fd909f  vmovaps [rsp+0xA0], xmm10
00007f0254fd90a8  vmovaps [rsp+0xB0], xmm11
00007f0254fd90b1  vmovaps [rsp+0xC0], xmm12
00007f0254fd90ba  vmovaps [rsp+0xD0], xmm13
00007f0254fd90c3  vmovaps [rsp+0xE0], xmm14
00007f0254fd90cc  sub rsp, 0x30
00007f0254fd90d0  movaps [rsp], xmm15
00007f0254fd90d5  movaps [rsp+0x10], xmm5
00007f0254fd90da  movaps [rsp+0x20], xmm3
00007f0254fd90df  lea rdi, [rsp]
00007f0254fd90e3  mov esi, 0x00
00007f0254fd90e8  mov rax, 0x55DD1360A530
00007f0254fd90f2  call rax
00007f0254fd90f4  movaps xmm15, [rsp]
00007f0254fd90f9  add rsp, 0x30
00007f0254fd90fd  vmovaps xmm0, [rsp]
00007f0254fd9102  vmovaps xmm1, [rsp+0x10]
00007f0254fd9108  vmovaps xmm2, [rsp+0x20]
00007f0254fd910e  vmovaps xmm3, [rsp+0x30]
00007f0254fd9114  vmovaps xmm4, [rsp+0x40]
00007f0254fd911a  vmovaps xmm5, [rsp+0x50]
00007f0254fd9120  vmovaps xmm6, [rsp+0x60]
00007f0254fd9126  vmovaps xmm7, [rsp+0x70]
00007f0254fd912c  vmovaps xmm8, [rsp+0x80]
00007f0254fd9135  vmovaps xmm9, [rsp+0x90]
00007f0254fd913e  vmovaps xmm10, [rsp+0xA0]
00007f0254fd9147  vmovaps xmm11, [rsp+0xB0]
00007f0254fd9150  vmovaps xmm12, [rsp+0xC0]
00007f0254fd9159  vmovaps xmm13, [rsp+0xD0]
00007f0254fd9162  vmovaps xmm14, [rsp+0xE0]
00007f0254fd916b  add rsp, 0xF0
00007f0254fd9172  pop r11
00007f0254fd9174  pop r10
00007f0254fd9176  pop r9
00007f0254fd9178  pop r8
00007f0254fd917a  pop rsi
00007f0254fd917b  pop rdi
00007f0254fd917c  pop rdx
00007f0254fd917d  pop rcx
00007f0254fd917e  pop rax
00007f0254fd917f  add rsp, 0x08
00007f0254fd9183  jmp 0x00007F0254FD61DC
00007f0254fd9188  sub rsp, 0x08
00007f0254fd918c  push rax
00007f0254fd918d  push rcx
00007f0254fd918e  push rdx
00007f0254fd918f  push rdi
00007f0254fd9190  push rsi
00007f0254fd9191  push r8
00007f0254fd9193  push r9
00007f0254fd9195  push r10
00007f0254fd9197  push r11
00007f0254fd9199  sub rsp, 0xF0
00007f0254fd91a0  vmovaps [rsp], xmm0
00007f0254fd91a5  vmovaps [rsp+0x10], xmm1
00007f0254fd91ab  vmovaps [rsp+0x20], xmm2
00007f0254fd91b1  vmovaps [rsp+0x30], xmm3
00007f0254fd91b7  vmovaps [rsp+0x40], xmm4
00007f0254fd91bd  vmovaps [rsp+0x50], xmm6
00007f0254fd91c3  vmovaps [rsp+0x60], xmm7
00007f0254fd91c9  vmovaps [rsp+0x70], xmm8
00007f0254fd91cf  vmovaps [rsp+0x80], xmm9
00007f0254fd91d8  vmovaps [rsp+0x90], xmm10
00007f0254fd91e1  vmovaps [rsp+0xA0], xmm11
00007f0254fd91ea  vmovaps [rsp+0xB0], xmm12
00007f0254fd91f3  vmovaps [rsp+0xC0], xmm13
00007f0254fd91fc  vmovaps [rsp+0xD0], xmm14
00007f0254fd9205  vmovaps [rsp+0xE0], xmm15
00007f0254fd920e  sub rsp, 0x30
00007f0254fd9212  movaps [rsp], xmm5
00007f0254fd9216  movaps [rsp+0x10], xmm8
00007f0254fd921c  movaps [rsp+0x20], xmm6
00007f0254fd9221  lea rdi, [rsp]
00007f0254fd9225  mov esi, 0x00
00007f0254fd922a  mov rax, 0x55DD1360A530
00007f0254fd9234  call rax
00007f0254fd9236  movaps xmm5, [rsp]
00007f0254fd923a  add rsp, 0x30
00007f0254fd923e  vmovaps xmm0, [rsp]
00007f0254fd9243  vmovaps xmm1, [rsp+0x10]
00007f0254fd9249  vmovaps xmm2, [rsp+0x20]
00007f0254fd924f  vmovaps xmm3, [rsp+0x30]
00007f0254fd9255  vmovaps xmm4, [rsp+0x40]
00007f0254fd925b  vmovaps xmm6, [rsp+0x50]
00007f0254fd9261  vmovaps xmm7, [rsp+0x60]
00007f0254fd9267  vmovaps xmm8, [rsp+0x70]
00007f0254fd926d  vmovaps xmm9, [rsp+0x80]
00007f0254fd9276  vmovaps xmm10, [rsp+0x90]
00007f0254fd927f  vmovaps xmm11, [rsp+0xA0]
00007f0254fd9288  vmovaps xmm12, [rsp+0xB0]
00007f0254fd9291  vmovaps xmm13, [rsp+0xC0]
00007f0254fd929a  vmovaps xmm14, [rsp+0xD0]
00007f0254fd92a3  vmovaps xmm15, [rsp+0xE0]
00007f0254fd92ac  add rsp, 0xF0
00007f0254fd92b3  pop r11
00007f0254fd92b5  pop r10
00007f0254fd92b7  pop r9
00007f0254fd92b9  pop r8
00007f0254fd92bb  pop rsi
00007f0254fd92bc  pop rdi
00007f0254fd92bd  pop rdx
00007f0254fd92be  pop rcx
00007f0254fd92bf  pop rax
00007f0254fd92c0  add rsp, 0x08
00007f0254fd92c4  jmp 0x00007F0254FD6200
00007f0254fd92c9  sub rsp, 0x08
00007f0254fd92cd  push rax
00007f0254fd92ce  push rcx
00007f0254fd92cf  push rdx
00007f0254fd92d0  push rdi
00007f0254fd92d1  push rsi
00007f0254fd92d2  push r8
00007f0254fd92d4  push r9
00007f0254fd92d6  push r10
00007f0254fd92d8  push r11
00007f0254fd92da  sub rsp, 0xF0
00007f0254fd92e1  vmovaps [rsp], xmm0
00007f0254fd92e6  vmovaps [rsp+0x10], xmm1
00007f0254fd92ec  vmovaps [rsp+0x20], xmm2
00007f0254fd92f2  vmovaps [rsp+0x30], xmm3
00007f0254fd92f8  vmovaps [rsp+0x40], xmm4
00007f0254fd92fe  vmovaps [rsp+0x50], xmm5
00007f0254fd9304  vmovaps [rsp+0x60], xmm7
00007f0254fd930a  vmovaps [rsp+0x70], xmm8
00007f0254fd9310  vmovaps [rsp+0x80], xmm9
00007f0254fd9319  vmovaps [rsp+0x90], xmm10
00007f0254fd9322  vmovaps [rsp+0xA0], xmm11
00007f0254fd932b  vmovaps [rsp+0xB0], xmm12
00007f0254fd9334  vmovaps [rsp+0xC0], xmm13
00007f0254fd933d  vmovaps [rsp+0xD0], xmm14
00007f0254fd9346  vmovaps [rsp+0xE0], xmm15
00007f0254fd934f  sub rsp, 0x30
00007f0254fd9353  movaps [rsp], xmm6
00007f0254fd9357  movaps [rsp+0x10], xmm10
00007f0254fd935d  movaps [rsp+0x20], xmm8
00007f0254fd9363  lea rdi, [rsp]
00007f0254fd9367  mov esi, 0x00
00007f0254fd936c  mov rax, 0x55DD1360A530
00007f0254fd9376  call rax
00007f0254fd9378  movaps xmm6, [rsp]
00007f0254fd937c  add rsp, 0x30
00007f0254fd9380  vmovaps xmm0, [rsp]
00007f0254fd9385  vmovaps xmm1, [rsp+0x10]
00007f0254fd938b  vmovaps xmm2, [rsp+0x20]
00007f0254fd9391  vmovaps xmm3, [rsp+0x30]
00007f0254fd9397  vmovaps xmm4, [rsp+0x40]
00007f0254fd939d  vmovaps xmm5, [rsp+0x50]
00007f0254fd93a3  vmovaps xmm7, [rsp+0x60]
00007f0254fd93a9  vmovaps xmm8, [rsp+0x70]
00007f0254fd93af  vmovaps xmm9, [rsp+0x80]
00007f0254fd93b8  vmovaps xmm10, [rsp+0x90]
00007f0254fd93c1  vmovaps xmm11, [rsp+0xA0]
00007f0254fd93ca  vmovaps xmm12, [rsp+0xB0]
00007f0254fd93d3  vmovaps xmm13, [rsp+0xC0]
00007f0254fd93dc  vmovaps xmm14, [rsp+0xD0]
00007f0254fd93e5  vmovaps xmm15, [rsp+0xE0]
00007f0254fd93ee  add rsp, 0xF0
00007f0254fd93f5  pop r11
00007f0254fd93f7  pop r10
00007f0254fd93f9  pop r9
00007f0254fd93fb  pop r8
00007f0254fd93fd  pop rsi
00007f0254fd93fe  pop rdi
00007f0254fd93ff  pop rdx
00007f0254fd9400  pop rcx
00007f0254fd9401  pop rax
00007f0254fd9402  add rsp, 0x08
00007f0254fd9406  jmp 0x00007F0254FD6225
00007f0254fd940b  sub rsp, 0x08
00007f0254fd940f  push rax
00007f0254fd9410  push rcx
00007f0254fd9411  push rdx
00007f0254fd9412  push rdi
00007f0254fd9413  push rsi
00007f0254fd9414  push r8
00007f0254fd9416  push r9
00007f0254fd9418  push r10
00007f0254fd941a  push r11
00007f0254fd941c  sub rsp, 0xF0
00007f0254fd9423  vmovaps [rsp], xmm0
00007f0254fd9428  vmovaps [rsp+0x10], xmm1
00007f0254fd942e  vmovaps [rsp+0x20], xmm2
00007f0254fd9434  vmovaps [rsp+0x30], xmm3
00007f0254fd943a  vmovaps [rsp+0x40], xmm4
00007f0254fd9440  vmovaps [rsp+0x50], xmm5
00007f0254fd9446  vmovaps [rsp+0x60], xmm6
00007f0254fd944c  vmovaps [rsp+0x70], xmm7
00007f0254fd9452  vmovaps [rsp+0x80], xmm8
00007f0254fd945b  vmovaps [rsp+0x90], xmm9
00007f0254fd9464  vmovaps [rsp+0xA0], xmm11
00007f0254fd946d  vmovaps [rsp+0xB0], xmm12
00007f0254fd9476  vmovaps [rsp+0xC0], xmm13
00007f0254fd947f  vmovaps [rsp+0xD0], xmm14
00007f0254fd9488  vmovaps [rsp+0xE0], xmm15
00007f0254fd9491  sub rsp, 0x30
00007f0254fd9495  movaps [rsp], xmm10
00007f0254fd949a  movaps [rsp+0x10], xmm8
00007f0254fd94a0  movaps [rsp+0x20], xmm14
00007f0254fd94a6  lea rdi, [rsp]
00007f0254fd94aa  mov esi, 0x00
00007f0254fd94af  mov rax, 0x55DD1360A530
00007f0254fd94b9  call rax
00007f0254fd94bb  movaps xmm10, [rsp]
00007f0254fd94c0  add rsp, 0x30
00007f0254fd94c4  vmovaps xmm0, [rsp]
00007f0254fd94c9  vmovaps xmm1, [rsp+0x10]
00007f0254fd94cf  vmovaps xmm2, [rsp+0x20]
00007f0254fd94d5  vmovaps xmm3, [rsp+0x30]
00007f0254fd94db  vmovaps xmm4, [rsp+0x40]
00007f0254fd94e1  vmovaps xmm5, [rsp+0x50]
00007f0254fd94e7  vmovaps xmm6, [rsp+0x60]
00007f0254fd94ed  vmovaps xmm7, [rsp+0x70]
00007f0254fd94f3  vmovaps xmm8, [rsp+0x80]
00007f0254fd94fc  vmovaps xmm9, [rsp+0x90]
00007f0254fd9505  vmovaps xmm11, [rsp+0xA0]
00007f0254fd950e  vmovaps xmm12, [rsp+0xB0]
00007f0254fd9517  vmovaps xmm13, [rsp+0xC0]
00007f0254fd9520  vmovaps xmm14, [rsp+0xD0]
00007f0254fd9529  vmovaps xmm15, [rsp+0xE0]
00007f0254fd9532  add rsp, 0xF0
00007f0254fd9539  pop r11
00007f0254fd953b  pop r10
00007f0254fd953d  pop r9
00007f0254fd953f  pop r8
00007f0254fd9541  pop rsi
00007f0254fd9542  pop rdi
00007f0254fd9543  pop rdx
00007f0254fd9544  pop rcx
00007f0254fd9545  pop rax
00007f0254fd9546  add rsp, 0x08
00007f0254fd954a  jmp 0x00007F0254FD6245
00007f0254fd954f  sub rsp, 0x08
00007f0254fd9553  push rax
00007f0254fd9554  push rcx
00007f0254fd9555  push rdx
00007f0254fd9556  push rdi
00007f0254fd9557  push rsi
00007f0254fd9558  push r8
00007f0254fd955a  push r9
00007f0254fd955c  push r10
00007f0254fd955e  push r11
00007f0254fd9560  sub rsp, 0xF0
00007f0254fd9567  vmovaps [rsp], xmm0
00007f0254fd956c  vmovaps [rsp+0x10], xmm1
00007f0254fd9572  vmovaps [rsp+0x20], xmm2
00007f0254fd9578  vmovaps [rsp+0x30], xmm3
00007f0254fd957e  vmovaps [rsp+0x40], xmm4
00007f0254fd9584  vmovaps [rsp+0x50], xmm5
00007f0254fd958a  vmovaps [rsp+0x60], xmm6
00007f0254fd9590  vmovaps [rsp+0x70], xmm7
00007f0254fd9596  vmovaps [rsp+0x80], xmm8
00007f0254fd959f  vmovaps [rsp+0x90], xmm9
00007f0254fd95a8  vmovaps [rsp+0xA0], xmm10
00007f0254fd95b1  vmovaps [rsp+0xB0], xmm11
00007f0254fd95ba  vmovaps [rsp+0xC0], xmm12
00007f0254fd95c3  vmovaps [rsp+0xD0], xmm13
00007f0254fd95cc  vmovaps [rsp+0xE0], xmm15
00007f0254fd95d5  sub rsp, 0x30
00007f0254fd95d9  movaps [rsp], xmm14
00007f0254fd95de  movaps [rsp+0x10], xmm8
00007f0254fd95e4  movaps [rsp+0x20], xmm4
00007f0254fd95e9  lea rdi, [rsp]
00007f0254fd95ed  mov esi, 0x00
00007f0254fd95f2  mov rax, 0x55DD1360A530
00007f0254fd95fc  call rax
00007f0254fd95fe  movaps xmm14, [rsp]
00007f0254fd9603  add rsp, 0x30
00007f0254fd9607  vmovaps xmm0, [rsp]
00007f0254fd960c  vmovaps xmm1, [rsp+0x10]
00007f0254fd9612  vmovaps xmm2, [rsp+0x20]
00007f0254fd9618  vmovaps xmm3, [rsp+0x30]
00007f0254fd961e  vmovaps xmm4, [rsp+0x40]
00007f0254fd9624  vmovaps xmm5, [rsp+0x50]
00007f0254fd962a  vmovaps xmm6, [rsp+0x60]
00007f0254fd9630  vmovaps xmm7, [rsp+0x70]
00007f0254fd9636  vmovaps xmm8, [rsp+0x80]
00007f0254fd963f  vmovaps xmm9, [rsp+0x90]
00007f0254fd9648  vmovaps xmm10, [rsp+0xA0]
00007f0254fd9651  vmovaps xmm11, [rsp+0xB0]
00007f0254fd965a  vmovaps xmm12, [rsp+0xC0]
00007f0254fd9663  vmovaps xmm13, [rsp+0xD0]
00007f0254fd966c  vmovaps xmm15, [rsp+0xE0]
00007f0254fd9675  add rsp, 0xF0
00007f0254fd967c  pop r11
00007f0254fd967e  pop r10
00007f0254fd9680  pop r9
00007f0254fd9682  pop r8
00007f0254fd9684  pop rsi
00007f0254fd9685  pop rdi
00007f0254fd9686  pop rdx
00007f0254fd9687  pop rcx
00007f0254fd9688  pop rax
00007f0254fd9689  add rsp, 0x08
00007f0254fd968d  jmp 0x00007F0254FD6265
00007f0254fd9692  sub rsp, 0x08
00007f0254fd9696  push rax
00007f0254fd9697  push rcx
00007f0254fd9698  push rdx
00007f0254fd9699  push rdi
00007f0254fd969a  push rsi
00007f0254fd969b  push r8
00007f0254fd969d  push r9
00007f0254fd969f  push r10
00007f0254fd96a1  push r11
00007f0254fd96a3  sub rsp, 0xF0
00007f0254fd96aa  vmovaps [rsp], xmm0
00007f0254fd96af  vmovaps [rsp+0x10], xmm1
00007f0254fd96b5  vmovaps [rsp+0x20], xmm2
00007f0254fd96bb  vmovaps [rsp+0x30], xmm3
00007f0254fd96c1  vmovaps [rsp+0x40], xmm5
00007f0254fd96c7  vmovaps [rsp+0x50], xmm6
00007f0254fd96cd  vmovaps [rsp+0x60], xmm7
00007f0254fd96d3  vmovaps [rsp+0x70], xmm8
00007f0254fd96d9  vmovaps [rsp+0x80], xmm9
00007f0254fd96e2  vmovaps [rsp+0x90], xmm10
00007f0254fd96eb  vmovaps [rsp+0xA0], xmm11
00007f0254fd96f4  vmovaps [rsp+0xB0], xmm12
00007f0254fd96fd  vmovaps [rsp+0xC0], xmm13
00007f0254fd9706  vmovaps [rsp+0xD0], xmm14
00007f0254fd970f  vmovaps [rsp+0xE0], xmm15
00007f0254fd9718  sub rsp, 0x30
00007f0254fd971c  movaps [rsp], xmm4
00007f0254fd9720  movaps [rsp+0x10], xmm13
00007f0254fd9726  movaps [rsp+0x20], xmm8
00007f0254fd972c  lea rdi, [rsp]
00007f0254fd9730  mov esi, 0x00
00007f0254fd9735  mov rax, 0x55DD1360A530
00007f0254fd973f  call rax
00007f0254fd9741  movaps xmm4, [rsp]
00007f0254fd9745  add rsp, 0x30
00007f0254fd9749  vmovaps xmm0, [rsp]
00007f0254fd974e  vmovaps xmm1, [rsp+0x10]
00007f0254fd9754  vmovaps xmm2, [rsp+0x20]
00007f0254fd975a  vmovaps xmm3, [rsp+0x30]
00007f0254fd9760  vmovaps xmm5, [rsp+0x40]
00007f0254fd9766  vmovaps xmm6, [rsp+0x50]
00007f0254fd976c  vmovaps xmm7, [rsp+0x60]
00007f0254fd9772  vmovaps xmm8, [rsp+0x70]
00007f0254fd9778  vmovaps xmm9, [rsp+0x80]
00007f0254fd9781  vmovaps xmm10, [rsp+0x90]
00007f0254fd978a  vmovaps xmm11, [rsp+0xA0]
00007f0254fd9793  vmovaps xmm12, [rsp+0xB0]
00007f0254fd979c  vmovaps xmm13, [rsp+0xC0]
00007f0254fd97a5  vmovaps xmm14, [rsp+0xD0]
00007f0254fd97ae  vmovaps xmm15, [rsp+0xE0]
00007f0254fd97b7  add rsp, 0xF0
00007f0254fd97be  pop r11
00007f0254fd97c0  pop r10
00007f0254fd97c2  pop r9
00007f0254fd97c4  pop r8
00007f0254fd97c6  pop rsi
00007f0254fd97c7  pop rdi
00007f0254fd97c8  pop rdx
00007f0254fd97c9  pop rcx
00007f0254fd97ca  pop rax
00007f0254fd97cb  add rsp, 0x08
00007f0254fd97cf  jmp 0x00007F0254FD628A
00007f0254fd97d4  sub rsp, 0x08
00007f0254fd97d8  push rax
00007f0254fd97d9  push rcx
00007f0254fd97da  push rdx
00007f0254fd97db  push rdi
00007f0254fd97dc  push rsi
00007f0254fd97dd  push r8
00007f0254fd97df  push r9
00007f0254fd97e1  push r10
00007f0254fd97e3  push r11
00007f0254fd97e5  sub rsp, 0xF0
00007f0254fd97ec  vmovaps [rsp], xmm0
00007f0254fd97f1  vmovaps [rsp+0x10], xmm1
00007f0254fd97f7  vmovaps [rsp+0x20], xmm2
00007f0254fd97fd  vmovaps [rsp+0x30], xmm3
00007f0254fd9803  vmovaps [rsp+0x40], xmm4
00007f0254fd9809  vmovaps [rsp+0x50], xmm5
00007f0254fd980f  vmovaps [rsp+0x60], xmm6
00007f0254fd9815  vmovaps [rsp+0x70], xmm7
00007f0254fd981b  vmovaps [rsp+0x80], xmm8
00007f0254fd9824  vmovaps [rsp+0x90], xmm9
00007f0254fd982d  vmovaps [rsp+0xA0], xmm10
00007f0254fd9836  vmovaps [rsp+0xB0], xmm11
00007f0254fd983f  vmovaps [rsp+0xC0], xmm12
00007f0254fd9848  vmovaps [rsp+0xD0], xmm14
00007f0254fd9851  vmovaps [rsp+0xE0], xmm15
00007f0254fd985a  sub rsp, 0x30
00007f0254fd985e  movaps [rsp], xmm13
00007f0254fd9863  movaps [rsp+0x10], xmm15
00007f0254fd9869  movaps [rsp+0x20], xmm9
00007f0254fd986f  lea rdi, [rsp]
00007f0254fd9873  mov esi, 0x00
00007f0254fd9878  mov rax, 0x55DD1360A530
00007f0254fd9882  call rax
00007f0254fd9884  movaps xmm13, [rsp]
00007f0254fd9889  add rsp, 0x30
00007f0254fd988d  vmovaps xmm0, [rsp]
00007f0254fd9892  vmovaps xmm1, [rsp+0x10]
00007f0254fd9898  vmovaps xmm2, [rsp+0x20]
00007f0254fd989e  vmovaps xmm3, [rsp+0x30]
00007f0254fd98a4  vmovaps xmm4, [rsp+0x40]
00007f0254fd98aa  vmovaps xmm5, [rsp+0x50]
00007f0254fd98b0  vmovaps xmm6, [rsp+0x60]
00007f0254fd98b6  vmovaps xmm7, [rsp+0x70]
00007f0254fd98bc  vmovaps xmm8, [rsp+0x80]
00007f0254fd98c5  vmovaps xmm9, [rsp+0x90]
00007f0254fd98ce  vmovaps xmm10, [rsp+0xA0]
00007f0254fd98d7  vmovaps xmm11, [rsp+0xB0]
00007f0254fd98e0  vmovaps xmm12, [rsp+0xC0]
00007f0254fd98e9  vmovaps xmm14, [rsp+0xD0]
00007f0254fd98f2  vmovaps xmm15, [rsp+0xE0]
00007f0254fd98fb  add rsp, 0xF0
00007f0254fd9902  pop r11
00007f0254fd9904  pop r10
00007f0254fd9906  pop r9
00007f0254fd9908  pop r8
00007f0254fd990a  pop rsi
00007f0254fd990b  pop rdi
00007f0254fd990c  pop rdx
00007f0254fd990d  pop rcx
00007f0254fd990e  pop rax
00007f0254fd990f  add rsp, 0x08
00007f0254fd9913  jmp 0x00007F0254FD62A5
00007f0254fd9918  sub rsp, 0x08
00007f0254fd991c  push rax
00007f0254fd991d  push rcx
00007f0254fd991e  push rdx
00007f0254fd991f  push rdi
00007f0254fd9920  push rsi
00007f0254fd9921  push r8
00007f0254fd9923  push r9
00007f0254fd9925  push r10
00007f0254fd9927  push r11
00007f0254fd9929  sub rsp, 0xF0
00007f0254fd9930  vmovaps [rsp], xmm0
00007f0254fd9935  vmovaps [rsp+0x10], xmm1
00007f0254fd993b  vmovaps [rsp+0x20], xmm2
00007f0254fd9941  vmovaps [rsp+0x30], xmm3
00007f0254fd9947  vmovaps [rsp+0x40], xmm4
00007f0254fd994d  vmovaps [rsp+0x50], xmm5
00007f0254fd9953  vmovaps [rsp+0x60], xmm6
00007f0254fd9959  vmovaps [rsp+0x70], xmm7
00007f0254fd995f  vmovaps [rsp+0x80], xmm8
00007f0254fd9968  vmovaps [rsp+0x90], xmm9
00007f0254fd9971  vmovaps [rsp+0xA0], xmm10
00007f0254fd997a  vmovaps [rsp+0xB0], xmm11
00007f0254fd9983  vmovaps [rsp+0xC0], xmm12
00007f0254fd998c  vmovaps [rsp+0xD0], xmm13
00007f0254fd9995  vmovaps [rsp+0xE0], xmm14
00007f0254fd999e  sub rsp, 0x30
00007f0254fd99a2  movaps [rsp], xmm15
00007f0254fd99a7  movaps [rsp+0x10], xmm1
00007f0254fd99ac  movaps [rsp+0x20], xmm5
00007f0254fd99b1  lea rdi, [rsp]
00007f0254fd99b5  mov esi, 0x00
00007f0254fd99ba  mov rax, 0x55DD1360A530
00007f0254fd99c4  call rax
00007f0254fd99c6  movaps xmm15, [rsp]
00007f0254fd99cb  add rsp, 0x30
00007f0254fd99cf  vmovaps xmm0, [rsp]
00007f0254fd99d4  vmovaps xmm1, [rsp+0x10]
00007f0254fd99da  vmovaps xmm2, [rsp+0x20]
00007f0254fd99e0  vmovaps xmm3, [rsp+0x30]
00007f0254fd99e6  vmovaps xmm4, [rsp+0x40]
00007f0254fd99ec  vmovaps xmm5, [rsp+0x50]
00007f0254fd99f2  vmovaps xmm6, [rsp+0x60]
00007f0254fd99f8  vmovaps xmm7, [rsp+0x70]
00007f0254fd99fe  vmovaps xmm8, [rsp+0x80]
00007f0254fd9a07  vmovaps xmm9, [rsp+0x90]
00007f0254fd9a10  vmovaps xmm10, [rsp+0xA0]
00007f0254fd9a19  vmovaps xmm11, [rsp+0xB0]
00007f0254fd9a22  vmovaps xmm12, [rsp+0xC0]
00007f0254fd9a2b  vmovaps xmm13, [rsp+0xD0]
00007f0254fd9a34  vmovaps xmm14, [rsp+0xE0]
00007f0254fd9a3d  add rsp, 0xF0
00007f0254fd9a44  pop r11
00007f0254fd9a46  pop r10
00007f0254fd9a48  pop r9
00007f0254fd9a4a  pop r8
00007f0254fd9a4c  pop rsi
00007f0254fd9a4d  pop rdi
00007f0254fd9a4e  pop rdx
00007f0254fd9a4f  pop rcx
00007f0254fd9a50  pop rax
00007f0254fd9a51  add rsp, 0x08
00007f0254fd9a55  jmp 0x00007F0254FD62C0
00007f0254fd9a5a  call 0x00007F0254ED64F0
00007f0254fd9a5f  jmp 0x00007F0254FD631B
00007f0254fd9a64  sub rsp, 0x08
00007f0254fd9a68  push rax
00007f0254fd9a69  push rcx
00007f0254fd9a6a  push rdx
00007f0254fd9a6b  push rdi
00007f0254fd9a6c  push rsi
00007f0254fd9a6d  push r8
00007f0254fd9a6f  push r9
00007f0254fd9a71  push r10
00007f0254fd9a73  push r11
00007f0254fd9a75  sub rsp, 0xF0
00007f0254fd9a7c  vmovaps [rsp], xmm0
00007f0254fd9a81  vmovaps [rsp+0x10], xmm1
00007f0254fd9a87  vmovaps [rsp+0x20], xmm2
00007f0254fd9a8d  vmovaps [rsp+0x30], xmm3
00007f0254fd9a93  vmovaps [rsp+0x40], xmm4
00007f0254fd9a99  vmovaps [rsp+0x50], xmm5
00007f0254fd9a9f  vmovaps [rsp+0x60], xmm6
00007f0254fd9aa5  vmovaps [rsp+0x70], xmm7
00007f0254fd9aab  vmovaps [rsp+0x80], xmm8
00007f0254fd9ab4  vmovaps [rsp+0x90], xmm10
00007f0254fd9abd  vmovaps [rsp+0xA0], xmm11
00007f0254fd9ac6  vmovaps [rsp+0xB0], xmm12
00007f0254fd9acf  vmovaps [rsp+0xC0], xmm13
00007f0254fd9ad8  vmovaps [rsp+0xD0], xmm14
00007f0254fd9ae1  vmovaps [rsp+0xE0], xmm15
00007f0254fd9aea  sub rsp, 0x30
00007f0254fd9aee  movaps [rsp], xmm9
00007f0254fd9af3  movaps [rsp+0x10], xmm8
00007f0254fd9af9  movaps [rsp+0x20], xmm11
00007f0254fd9aff  lea rdi, [rsp]
00007f0254fd9b03  mov esi, 0x00
00007f0254fd9b08  mov rax, 0x55DD1360A530
00007f0254fd9b12  call rax
00007f0254fd9b14  movaps xmm9, [rsp]
00007f0254fd9b19  add rsp, 0x30
00007f0254fd9b1d  vmovaps xmm0, [rsp]
00007f0254fd9b22  vmovaps xmm1, [rsp+0x10]
00007f0254fd9b28  vmovaps xmm2, [rsp+0x20]
00007f0254fd9b2e  vmovaps xmm3, [rsp+0x30]
00007f0254fd9b34  vmovaps xmm4, [rsp+0x40]
00007f0254fd9b3a  vmovaps xmm5, [rsp+0x50]
00007f0254fd9b40  vmovaps xmm6, [rsp+0x60]
00007f0254fd9b46  vmovaps xmm7, [rsp+0x70]
00007f0254fd9b4c  vmovaps xmm8, [rsp+0x80]
00007f0254fd9b55  vmovaps xmm10, [rsp+0x90]
00007f0254fd9b5e  vmovaps xmm11, [rsp+0xA0]
00007f0254fd9b67  vmovaps xmm12, [rsp+0xB0]
00007f0254fd9b70  vmovaps xmm13, [rsp+0xC0]
00007f0254fd9b79  vmovaps xmm14, [rsp+0xD0]
00007f0254fd9b82  vmovaps xmm15, [rsp+0xE0]
00007f0254fd9b8b  add rsp, 0xF0
00007f0254fd9b92  pop r11
00007f0254fd9b94  pop r10
00007f0254fd9b96  pop r9
00007f0254fd9b98  pop r8
00007f0254fd9b9a  pop rsi
00007f0254fd9b9b  pop rdi
00007f0254fd9b9c  pop rdx
00007f0254fd9b9d  pop rcx
00007f0254fd9b9e  pop rax
00007f0254fd9b9f  add rsp, 0x08
00007f0254fd9ba3  jmp 0x00007F0254FD6352
00007f0254fd9ba8  sub rsp, 0x08
00007f0254fd9bac  push rax
00007f0254fd9bad  push rcx
00007f0254fd9bae  push rdx
00007f0254fd9baf  push rdi
00007f0254fd9bb0  push rsi
00007f0254fd9bb1  push r8
00007f0254fd9bb3  push r9
00007f0254fd9bb5  push r10
00007f0254fd9bb7  push r11
00007f0254fd9bb9  sub rsp, 0xF0
00007f0254fd9bc0  vmovaps [rsp], xmm0
00007f0254fd9bc5  vmovaps [rsp+0x10], xmm1
00007f0254fd9bcb  vmovaps [rsp+0x20], xmm2
00007f0254fd9bd1  vmovaps [rsp+0x30], xmm3
00007f0254fd9bd7  vmovaps [rsp+0x40], xmm4
00007f0254fd9bdd  vmovaps [rsp+0x50], xmm5
00007f0254fd9be3  vmovaps [rsp+0x60], xmm6
00007f0254fd9be9  vmovaps [rsp+0x70], xmm7
00007f0254fd9bef  vmovaps [rsp+0x80], xmm8
00007f0254fd9bf8  vmovaps [rsp+0x90], xmm9
00007f0254fd9c01  vmovaps [rsp+0xA0], xmm10
00007f0254fd9c0a  vmovaps [rsp+0xB0], xmm12
00007f0254fd9c13  vmovaps [rsp+0xC0], xmm13
00007f0254fd9c1c  vmovaps [rsp+0xD0], xmm14
00007f0254fd9c25  vmovaps [rsp+0xE0], xmm15
00007f0254fd9c2e  sub rsp, 0x30
00007f0254fd9c32  movaps [rsp], xmm11
00007f0254fd9c37  movaps [rsp+0x10], xmm10
00007f0254fd9c3d  movaps [rsp+0x20], xmm6
00007f0254fd9c42  lea rdi, [rsp]
00007f0254fd9c46  mov esi, 0x00
00007f0254fd9c4b  mov rax, 0x55DD1360A530
00007f0254fd9c55  call rax
00007f0254fd9c57  movaps xmm11, [rsp]
00007f0254fd9c5c  add rsp, 0x30
00007f0254fd9c60  vmovaps xmm0, [rsp]
00007f0254fd9c65  vmovaps xmm1, [rsp+0x10]
00007f0254fd9c6b  vmovaps xmm2, [rsp+0x20]
00007f0254fd9c71  vmovaps xmm3, [rsp+0x30]
00007f0254fd9c77  vmovaps xmm4, [rsp+0x40]
00007f0254fd9c7d  vmovaps xmm5, [rsp+0x50]
00007f0254fd9c83  vmovaps xmm6, [rsp+0x60]
00007f0254fd9c89  vmovaps xmm7, [rsp+0x70]
00007f0254fd9c8f  vmovaps xmm8, [rsp+0x80]
00007f0254fd9c98  vmovaps xmm9, [rsp+0x90]
00007f0254fd9ca1  vmovaps xmm10, [rsp+0xA0]
00007f0254fd9caa  vmovaps xmm12, [rsp+0xB0]
00007f0254fd9cb3  vmovaps xmm13, [rsp+0xC0]
00007f0254fd9cbc  vmovaps xmm14, [rsp+0xD0]
00007f0254fd9cc5  vmovaps xmm15, [rsp+0xE0]
00007f0254fd9cce  add rsp, 0xF0
00007f0254fd9cd5  pop r11
00007f0254fd9cd7  pop r10
00007f0254fd9cd9  pop r9
00007f0254fd9cdb  pop r8
00007f0254fd9cdd  pop rsi
00007f0254fd9cde  pop rdi
00007f0254fd9cdf  pop rdx
00007f0254fd9ce0  pop rcx
00007f0254fd9ce1  pop rax
00007f0254fd9ce2  add rsp, 0x08
00007f0254fd9ce6  jmp 0x00007F0254FD636D
00007f0254fd9ceb  sub rsp, 0x08
00007f0254fd9cef  push rax
00007f0254fd9cf0  push rcx
00007f0254fd9cf1  push rdx
00007f0254fd9cf2  push rdi
00007f0254fd9cf3  push rsi
00007f0254fd9cf4  push r8
00007f0254fd9cf6  push r9
00007f0254fd9cf8  push r10
00007f0254fd9cfa  push r11
00007f0254fd9cfc  sub rsp, 0xF0
00007f0254fd9d03  vmovaps [rsp], xmm0
00007f0254fd9d08  vmovaps [rsp+0x10], xmm1
00007f0254fd9d0e  vmovaps [rsp+0x20], xmm2
00007f0254fd9d14  vmovaps [rsp+0x30], xmm3
00007f0254fd9d1a  vmovaps [rsp+0x40], xmm4
00007f0254fd9d20  vmovaps [rsp+0x50], xmm5
00007f0254fd9d26  vmovaps [rsp+0x60], xmm6
00007f0254fd9d2c  vmovaps [rsp+0x70], xmm7
00007f0254fd9d32  vmovaps [rsp+0x80], xmm8
00007f0254fd9d3b  vmovaps [rsp+0x90], xmm9
00007f0254fd9d44  vmovaps [rsp+0xA0], xmm11
00007f0254fd9d4d  vmovaps [rsp+0xB0], xmm12
00007f0254fd9d56  vmovaps [rsp+0xC0], xmm13
00007f0254fd9d5f  vmovaps [rsp+0xD0], xmm14
00007f0254fd9d68  vmovaps [rsp+0xE0], xmm15
00007f0254fd9d71  sub rsp, 0x30
00007f0254fd9d75  movaps [rsp], xmm10
00007f0254fd9d7a  movaps [rsp+0x10], xmm14
00007f0254fd9d80  movaps [rsp+0x20], xmm4
00007f0254fd9d85  lea rdi, [rsp]
00007f0254fd9d89  mov esi, 0x00
00007f0254fd9d8e  mov rax, 0x55DD1360A530
00007f0254fd9d98  call rax
00007f0254fd9d9a  movaps xmm10, [rsp]
00007f0254fd9d9f  add rsp, 0x30
00007f0254fd9da3  vmovaps xmm0, [rsp]
00007f0254fd9da8  vmovaps xmm1, [rsp+0x10]
00007f0254fd9dae  vmovaps xmm2, [rsp+0x20]
00007f0254fd9db4  vmovaps xmm3, [rsp+0x30]
00007f0254fd9dba  vmovaps xmm4, [rsp+0x40]
00007f0254fd9dc0  vmovaps xmm5, [rsp+0x50]
00007f0254fd9dc6  vmovaps xmm6, [rsp+0x60]
00007f0254fd9dcc  vmovaps xmm7, [rsp+0x70]
00007f0254fd9dd2  vmovaps xmm8, [rsp+0x80]
00007f0254fd9ddb  vmovaps xmm9, [rsp+0x90]
00007f0254fd9de4  vmovaps xmm11, [rsp+0xA0]
00007f0254fd9ded  vmovaps xmm12, [rsp+0xB0]
00007f0254fd9df6  vmovaps xmm13, [rsp+0xC0]
00007f0254fd9dff  vmovaps xmm14, [rsp+0xD0]
00007f0254fd9e08  vmovaps xmm15, [rsp+0xE0]
00007f0254fd9e11  add rsp, 0xF0
00007f0254fd9e18  pop r11
00007f0254fd9e1a  pop r10
00007f0254fd9e1c  pop r9
00007f0254fd9e1e  pop r8
00007f0254fd9e20  pop rsi
00007f0254fd9e21  pop rdi
00007f0254fd9e22  pop rdx
00007f0254fd9e23  pop rcx
00007f0254fd9e24  pop rax
00007f0254fd9e25  add rsp, 0x08
00007f0254fd9e29  jmp 0x00007F0254FD6388
00007f0254fd9e2e  sub rsp, 0x08
00007f0254fd9e32  push rax
00007f0254fd9e33  push rcx
00007f0254fd9e34  push rdx
00007f0254fd9e35  push rdi
00007f0254fd9e36  push rsi
00007f0254fd9e37  push r8
00007f0254fd9e39  push r9
00007f0254fd9e3b  push r10
00007f0254fd9e3d  push r11
00007f0254fd9e3f  sub rsp, 0xF0
00007f0254fd9e46  vmovaps [rsp], xmm0
00007f0254fd9e4b  vmovaps [rsp+0x10], xmm1
00007f0254fd9e51  vmovaps [rsp+0x20], xmm2
00007f0254fd9e57  vmovaps [rsp+0x30], xmm3
00007f0254fd9e5d  vmovaps [rsp+0x40], xmm4
00007f0254fd9e63  vmovaps [rsp+0x50], xmm5
00007f0254fd9e69  vmovaps [rsp+0x60], xmm6
00007f0254fd9e6f  vmovaps [rsp+0x70], xmm7
00007f0254fd9e75  vmovaps [rsp+0x80], xmm9
00007f0254fd9e7e  vmovaps [rsp+0x90], xmm10
00007f0254fd9e87  vmovaps [rsp+0xA0], xmm11
00007f0254fd9e90  vmovaps [rsp+0xB0], xmm12
00007f0254fd9e99  vmovaps [rsp+0xC0], xmm13
00007f0254fd9ea2  vmovaps [rsp+0xD0], xmm14
00007f0254fd9eab  vmovaps [rsp+0xE0], xmm15
00007f0254fd9eb4  sub rsp, 0x30
00007f0254fd9eb8  movaps [rsp], xmm8
00007f0254fd9ebd  movaps [rsp+0x10], xmm1
00007f0254fd9ec2  movaps [rsp+0x20], xmm14
00007f0254fd9ec8  lea rdi, [rsp]
00007f0254fd9ecc  mov esi, 0x00
00007f0254fd9ed1  mov rax, 0x55DD1360A530
00007f0254fd9edb  call rax
00007f0254fd9edd  movaps xmm8, [rsp]
00007f0254fd9ee2  add rsp, 0x30
00007f0254fd9ee6  vmovaps xmm0, [rsp]
00007f0254fd9eeb  vmovaps xmm1, [rsp+0x10]
00007f0254fd9ef1  vmovaps xmm2, [rsp+0x20]
00007f0254fd9ef7  vmovaps xmm3, [rsp+0x30]
00007f0254fd9efd  vmovaps xmm4, [rsp+0x40]
00007f0254fd9f03  vmovaps xmm5, [rsp+0x50]
00007f0254fd9f09  vmovaps xmm6, [rsp+0x60]
00007f0254fd9f0f  vmovaps xmm7, [rsp+0x70]
00007f0254fd9f15  vmovaps xmm9, [rsp+0x80]
00007f0254fd9f1e  vmovaps xmm10, [rsp+0x90]
00007f0254fd9f27  vmovaps xmm11, [rsp+0xA0]
00007f0254fd9f30  vmovaps xmm12, [rsp+0xB0]
00007f0254fd9f39  vmovaps xmm13, [rsp+0xC0]
00007f0254fd9f42  vmovaps xmm14, [rsp+0xD0]
00007f0254fd9f4b  vmovaps xmm15, [rsp+0xE0]
00007f0254fd9f54  add rsp, 0xF0
00007f0254fd9f5b  pop r11
00007f0254fd9f5d  pop r10
00007f0254fd9f5f  pop r9
00007f0254fd9f61  pop r8
00007f0254fd9f63  pop rsi
00007f0254fd9f64  pop rdi
00007f0254fd9f65  pop rdx
00007f0254fd9f66  pop rcx
00007f0254fd9f67  pop rax
00007f0254fd9f68  add rsp, 0x08
00007f0254fd9f6c  jmp 0x00007F0254FD63AE
00007f0254fd9f71  sub rsp, 0x08
00007f0254fd9f75  push rax
00007f0254fd9f76  push rcx
00007f0254fd9f77  push rdx
00007f0254fd9f78  push rdi
00007f0254fd9f79  push rsi
00007f0254fd9f7a  push r8
00007f0254fd9f7c  push r9
00007f0254fd9f7e  push r10
00007f0254fd9f80  push r11
00007f0254fd9f82  sub rsp, 0xF0
00007f0254fd9f89  vmovaps [rsp], xmm0
00007f0254fd9f8e  vmovaps [rsp+0x10], xmm1
00007f0254fd9f94  vmovaps [rsp+0x20], xmm2
00007f0254fd9f9a  vmovaps [rsp+0x30], xmm3
00007f0254fd9fa0  vmovaps [rsp+0x40], xmm4
00007f0254fd9fa6  vmovaps [rsp+0x50], xmm5
00007f0254fd9fac  vmovaps [rsp+0x60], xmm7
00007f0254fd9fb2  vmovaps [rsp+0x70], xmm8
00007f0254fd9fb8  vmovaps [rsp+0x80], xmm9
00007f0254fd9fc1  vmovaps [rsp+0x90], xmm10
00007f0254fd9fca  vmovaps [rsp+0xA0], xmm11
00007f0254fd9fd3  vmovaps [rsp+0xB0], xmm12
00007f0254fd9fdc  vmovaps [rsp+0xC0], xmm13
00007f0254fd9fe5  vmovaps [rsp+0xD0], xmm14
00007f0254fd9fee  vmovaps [rsp+0xE0], xmm15
00007f0254fd9ff7  sub rsp, 0x30
00007f0254fd9ffb  movaps [rsp], xmm6
00007f0254fd9fff  movaps [rsp+0x10], xmm1
00007f0254fda004  movaps [rsp+0x20], xmm14
00007f0254fda00a  lea rdi, [rsp]
00007f0254fda00e  mov esi, 0x00
00007f0254fda013  mov rax, 0x55DD1360A530
00007f0254fda01d  call rax
00007f0254fda01f  movaps xmm6, [rsp]
00007f0254fda023  add rsp, 0x30
00007f0254fda027  vmovaps xmm0, [rsp]
00007f0254fda02c  vmovaps xmm1, [rsp+0x10]
00007f0254fda032  vmovaps xmm2, [rsp+0x20]
00007f0254fda038  vmovaps xmm3, [rsp+0x30]
00007f0254fda03e  vmovaps xmm4, [rsp+0x40]
00007f0254fda044  vmovaps xmm5, [rsp+0x50]
00007f0254fda04a  vmovaps xmm7, [rsp+0x60]
00007f0254fda050  vmovaps xmm8, [rsp+0x70]
00007f0254fda056  vmovaps xmm9, [rsp+0x80]
00007f0254fda05f  vmovaps xmm10, [rsp+0x90]
00007f0254fda068  vmovaps xmm11, [rsp+0xA0]
00007f0254fda071  vmovaps xmm12, [rsp+0xB0]
00007f0254fda07a  vmovaps xmm13, [rsp+0xC0]
00007f0254fda083  vmovaps xmm14, [rsp+0xD0]
00007f0254fda08c  vmovaps xmm15, [rsp+0xE0]
00007f0254fda095  add rsp, 0xF0
00007f0254fda09c  pop r11
00007f0254fda09e  pop r10
00007f0254fda0a0  pop r9
00007f0254fda0a2  pop r8
00007f0254fda0a4  pop rsi
00007f0254fda0a5  pop rdi
00007f0254fda0a6  pop rdx
00007f0254fda0a7  pop rcx
00007f0254fda0a8  pop rax
00007f0254fda0a9  add rsp, 0x08
00007f0254fda0ad  jmp 0x00007F0254FD63DA
00007f0254fda0b2  sub rsp, 0x08
00007f0254fda0b6  push rax
00007f0254fda0b7  push rcx
00007f0254fda0b8  push rdx
00007f0254fda0b9  push rdi
00007f0254fda0ba  push rsi
00007f0254fda0bb  push r8
00007f0254fda0bd  push r9
00007f0254fda0bf  push r10
00007f0254fda0c1  push r11
00007f0254fda0c3  sub rsp, 0xF0
00007f0254fda0ca  vmovaps [rsp], xmm0
00007f0254fda0cf  vmovaps [rsp+0x10], xmm1
00007f0254fda0d5  vmovaps [rsp+0x20], xmm2
00007f0254fda0db  vmovaps [rsp+0x30], xmm3
00007f0254fda0e1  vmovaps [rsp+0x40], xmm4
00007f0254fda0e7  vmovaps [rsp+0x50], xmm5
00007f0254fda0ed  vmovaps [rsp+0x60], xmm6
00007f0254fda0f3  vmovaps [rsp+0x70], xmm7
00007f0254fda0f9  vmovaps [rsp+0x80], xmm8
00007f0254fda102  vmovaps [rsp+0x90], xmm9
00007f0254fda10b  vmovaps [rsp+0xA0], xmm10
00007f0254fda114  vmovaps [rsp+0xB0], xmm11
00007f0254fda11d  vmovaps [rsp+0xC0], xmm12
00007f0254fda126  vmovaps [rsp+0xD0], xmm13
00007f0254fda12f  vmovaps [rsp+0xE0], xmm15
00007f0254fda138  sub rsp, 0x30
00007f0254fda13c  movaps [rsp], xmm14
00007f0254fda141  movaps [rsp+0x10], xmm12
00007f0254fda147  movaps [rsp+0x20], xmm1
00007f0254fda14c  lea rdi, [rsp]
00007f0254fda150  mov esi, 0x00
00007f0254fda155  mov rax, 0x55DD1360A530
00007f0254fda15f  call rax
00007f0254fda161  movaps xmm14, [rsp]
00007f0254fda166  add rsp, 0x30
00007f0254fda16a  vmovaps xmm0, [rsp]
00007f0254fda16f  vmovaps xmm1, [rsp+0x10]
00007f0254fda175  vmovaps xmm2, [rsp+0x20]
00007f0254fda17b  vmovaps xmm3, [rsp+0x30]
00007f0254fda181  vmovaps xmm4, [rsp+0x40]
00007f0254fda187  vmovaps xmm5, [rsp+0x50]
00007f0254fda18d  vmovaps xmm6, [rsp+0x60]
00007f0254fda193  vmovaps xmm7, [rsp+0x70]
00007f0254fda199  vmovaps xmm8, [rsp+0x80]
00007f0254fda1a2  vmovaps xmm9, [rsp+0x90]
00007f0254fda1ab  vmovaps xmm10, [rsp+0xA0]
00007f0254fda1b4  vmovaps xmm11, [rsp+0xB0]
00007f0254fda1bd  vmovaps xmm12, [rsp+0xC0]
00007f0254fda1c6  vmovaps xmm13, [rsp+0xD0]
00007f0254fda1cf  vmovaps xmm15, [rsp+0xE0]
00007f0254fda1d8  add rsp, 0xF0
00007f0254fda1df  pop r11
00007f0254fda1e1  pop r10
00007f0254fda1e3  pop r9
00007f0254fda1e5  pop r8
00007f0254fda1e7  pop rsi
00007f0254fda1e8  pop rdi
00007f0254fda1e9  pop rdx
00007f0254fda1ea  pop rcx
00007f0254fda1eb  pop rax
00007f0254fda1ec  add rsp, 0x08
00007f0254fda1f0  jmp 0x00007F0254FD6400
00007f0254fda1f5  sub rsp, 0x08
00007f0254fda1f9  push rax
00007f0254fda1fa  push rcx
00007f0254fda1fb  push rdx
00007f0254fda1fc  push rdi
00007f0254fda1fd  push rsi
00007f0254fda1fe  push r8
00007f0254fda200  push r9
00007f0254fda202  push r10
00007f0254fda204  push r11
00007f0254fda206  sub rsp, 0xF0
00007f0254fda20d  vmovaps [rsp], xmm0
00007f0254fda212  vmovaps [rsp+0x10], xmm2
00007f0254fda218  vmovaps [rsp+0x20], xmm3
00007f0254fda21e  vmovaps [rsp+0x30], xmm4
00007f0254fda224  vmovaps [rsp+0x40], xmm5
00007f0254fda22a  vmovaps [rsp+0x50], xmm6
00007f0254fda230  vmovaps [rsp+0x60], xmm7
00007f0254fda236  vmovaps [rsp+0x70], xmm8
00007f0254fda23c  vmovaps [rsp+0x80], xmm9
00007f0254fda245  vmovaps [rsp+0x90], xmm10
00007f0254fda24e  vmovaps [rsp+0xA0], xmm11
00007f0254fda257  vmovaps [rsp+0xB0], xmm12
00007f0254fda260  vmovaps [rsp+0xC0], xmm13
00007f0254fda269  vmovaps [rsp+0xD0], xmm14
00007f0254fda272  vmovaps [rsp+0xE0], xmm15
00007f0254fda27b  sub rsp, 0x30
00007f0254fda27f  movaps [rsp], xmm1
00007f0254fda283  movaps [rsp+0x10], xmm13
00007f0254fda289  movaps [rsp+0x20], xmm9
00007f0254fda28f  lea rdi, [rsp]
00007f0254fda293  mov esi, 0x00
00007f0254fda298  mov rax, 0x55DD1360A530
00007f0254fda2a2  call rax
00007f0254fda2a4  movaps xmm1, [rsp]
00007f0254fda2a8  add rsp, 0x30
00007f0254fda2ac  vmovaps xmm0, [rsp]
00007f0254fda2b1  vmovaps xmm2, [rsp+0x10]
00007f0254fda2b7  vmovaps xmm3, [rsp+0x20]
00007f0254fda2bd  vmovaps xmm4, [rsp+0x30]
00007f0254fda2c3  vmovaps xmm5, [rsp+0x40]
00007f0254fda2c9  vmovaps xmm6, [rsp+0x50]
00007f0254fda2cf  vmovaps xmm7, [rsp+0x60]
00007f0254fda2d5  vmovaps xmm8, [rsp+0x70]
00007f0254fda2db  vmovaps xmm9, [rsp+0x80]
00007f0254fda2e4  vmovaps xmm10, [rsp+0x90]
00007f0254fda2ed  vmovaps xmm11, [rsp+0xA0]
00007f0254fda2f6  vmovaps xmm12, [rsp+0xB0]
00007f0254fda2ff  vmovaps xmm13, [rsp+0xC0]
00007f0254fda308  vmovaps xmm14, [rsp+0xD0]
00007f0254fda311  vmovaps xmm15, [rsp+0xE0]
00007f0254fda31a  add rsp, 0xF0
00007f0254fda321  pop r11
00007f0254fda323  pop r10
00007f0254fda325  pop r9
00007f0254fda327  pop r8
00007f0254fda329  pop rsi
00007f0254fda32a  pop rdi
00007f0254fda32b  pop rdx
00007f0254fda32c  pop rcx
00007f0254fda32d  pop rax
00007f0254fda32e  add rsp, 0x08
00007f0254fda332  jmp 0x00007F0254FD641A
00007f0254fda337  sub rsp, 0x08
00007f0254fda33b  push rax
00007f0254fda33c  push rcx
00007f0254fda33d  push rdx
00007f0254fda33e  push rdi
00007f0254fda33f  push rsi
00007f0254fda340  push r8
00007f0254fda342  push r9
00007f0254fda344  push r10
00007f0254fda346  push r11
00007f0254fda348  sub rsp, 0xF0
00007f0254fda34f  vmovaps [rsp], xmm0
00007f0254fda354  vmovaps [rsp+0x10], xmm1
00007f0254fda35a  vmovaps [rsp+0x20], xmm2
00007f0254fda360  vmovaps [rsp+0x30], xmm3
00007f0254fda366  vmovaps [rsp+0x40], xmm4
00007f0254fda36c  vmovaps [rsp+0x50], xmm5
00007f0254fda372  vmovaps [rsp+0x60], xmm6
00007f0254fda378  vmovaps [rsp+0x70], xmm7
00007f0254fda37e  vmovaps [rsp+0x80], xmm8
00007f0254fda387  vmovaps [rsp+0x90], xmm9
00007f0254fda390  vmovaps [rsp+0xA0], xmm10
00007f0254fda399  vmovaps [rsp+0xB0], xmm11
00007f0254fda3a2  vmovaps [rsp+0xC0], xmm13
00007f0254fda3ab  vmovaps [rsp+0xD0], xmm14
00007f0254fda3b4  vmovaps [rsp+0xE0], xmm15
00007f0254fda3bd  sub rsp, 0x30
00007f0254fda3c1  movaps [rsp], xmm12
00007f0254fda3c6  movaps [rsp+0x10], xmm7
00007f0254fda3cb  movaps [rsp+0x20], xmm13
00007f0254fda3d1  lea rdi, [rsp]
00007f0254fda3d5  mov esi, 0x00
00007f0254fda3da  mov rax, 0x55DD1360A530
00007f0254fda3e4  call rax
00007f0254fda3e6  movaps xmm12, [rsp]
00007f0254fda3eb  add rsp, 0x30
00007f0254fda3ef  vmovaps xmm0, [rsp]
00007f0254fda3f4  vmovaps xmm1, [rsp+0x10]
00007f0254fda3fa  vmovaps xmm2, [rsp+0x20]
00007f0254fda400  vmovaps xmm3, [rsp+0x30]
00007f0254fda406  vmovaps xmm4, [rsp+0x40]
00007f0254fda40c  vmovaps xmm5, [rsp+0x50]
00007f0254fda412  vmovaps xmm6, [rsp+0x60]
00007f0254fda418  vmovaps xmm7, [rsp+0x70]
00007f0254fda41e  vmovaps xmm8, [rsp+0x80]
00007f0254fda427  vmovaps xmm9, [rsp+0x90]
00007f0254fda430  vmovaps xmm10, [rsp+0xA0]
00007f0254fda439  vmovaps xmm11, [rsp+0xB0]
00007f0254fda442  vmovaps xmm13, [rsp+0xC0]
00007f0254fda44b  vmovaps xmm14, [rsp+0xD0]
00007f0254fda454  vmovaps xmm15, [rsp+0xE0]
00007f0254fda45d  add rsp, 0xF0
00007f0254fda464  pop r11
00007f0254fda466  pop r10
00007f0254fda468  pop r9
00007f0254fda46a  pop r8
00007f0254fda46c  pop rsi
00007f0254fda46d  pop rdi
00007f0254fda46e  pop rdx
00007f0254fda46f  pop rcx
00007f0254fda470  pop rax
00007f0254fda471  add rsp, 0x08
00007f0254fda475  jmp 0x00007F0254FD6441
00007f0254fda47a  sub rsp, 0x08
00007f0254fda47e  push rax
00007f0254fda47f  push rcx
00007f0254fda480  push rdx
00007f0254fda481  push rdi
00007f0254fda482  push rsi
00007f0254fda483  push r8
00007f0254fda485  push r9
00007f0254fda487  push r10
00007f0254fda489  push r11
00007f0254fda48b  sub rsp, 0xF0
00007f0254fda492  vmovaps [rsp], xmm0
00007f0254fda497  vmovaps [rsp+0x10], xmm1
00007f0254fda49d  vmovaps [rsp+0x20], xmm2
00007f0254fda4a3  vmovaps [rsp+0x30], xmm3
00007f0254fda4a9  vmovaps [rsp+0x40], xmm4
00007f0254fda4af  vmovaps [rsp+0x50], xmm5
00007f0254fda4b5  vmovaps [rsp+0x60], xmm6
00007f0254fda4bb  vmovaps [rsp+0x70], xmm7
00007f0254fda4c1  vmovaps [rsp+0x80], xmm8
00007f0254fda4ca  vmovaps [rsp+0x90], xmm9
00007f0254fda4d3  vmovaps [rsp+0xA0], xmm10
00007f0254fda4dc  vmovaps [rsp+0xB0], xmm11
00007f0254fda4e5  vmovaps [rsp+0xC0], xmm12
00007f0254fda4ee  vmovaps [rsp+0xD0], xmm14
00007f0254fda4f7  vmovaps [rsp+0xE0], xmm15
00007f0254fda500  sub rsp, 0x30
00007f0254fda504  movaps [rsp], xmm13
00007f0254fda509  movaps [rsp+0x10], xmm15
00007f0254fda50f  movaps [rsp+0x20], xmm8
00007f0254fda515  lea rdi, [rsp]
00007f0254fda519  mov esi, 0x00
00007f0254fda51e  mov rax, 0x55DD1360A530
00007f0254fda528  call rax
00007f0254fda52a  movaps xmm13, [rsp]
00007f0254fda52f  add rsp, 0x30
00007f0254fda533  vmovaps xmm0, [rsp]
00007f0254fda538  vmovaps xmm1, [rsp+0x10]
00007f0254fda53e  vmovaps xmm2, [rsp+0x20]
00007f0254fda544  vmovaps xmm3, [rsp+0x30]
00007f0254fda54a  vmovaps xmm4, [rsp+0x40]
00007f0254fda550  vmovaps xmm5, [rsp+0x50]
00007f0254fda556  vmovaps xmm6, [rsp+0x60]
00007f0254fda55c  vmovaps xmm7, [rsp+0x70]
00007f0254fda562  vmovaps xmm8, [rsp+0x80]
00007f0254fda56b  vmovaps xmm9, [rsp+0x90]
00007f0254fda574  vmovaps xmm10, [rsp+0xA0]
00007f0254fda57d  vmovaps xmm11, [rsp+0xB0]
00007f0254fda586  vmovaps xmm12, [rsp+0xC0]
00007f0254fda58f  vmovaps xmm14, [rsp+0xD0]
00007f0254fda598  vmovaps xmm15, [rsp+0xE0]
00007f0254fda5a1  add rsp, 0xF0
00007f0254fda5a8  pop r11
00007f0254fda5aa  pop r10
00007f0254fda5ac  pop r9
00007f0254fda5ae  pop r8
00007f0254fda5b0  pop rsi
00007f0254fda5b1  pop rdi
00007f0254fda5b2  pop rdx
00007f0254fda5b3  pop rcx
00007f0254fda5b4  pop rax
00007f0254fda5b5  add rsp, 0x08
00007f0254fda5b9  jmp 0x00007F0254FD645C
00007f0254fda5be  sub rsp, 0x08
00007f0254fda5c2  push rax
00007f0254fda5c3  push rcx
00007f0254fda5c4  push rdx
00007f0254fda5c5  push rdi
00007f0254fda5c6  push rsi
00007f0254fda5c7  push r8
00007f0254fda5c9  push r9
00007f0254fda5cb  push r10
00007f0254fda5cd  push r11
00007f0254fda5cf  sub rsp, 0xF0
00007f0254fda5d6  vmovaps [rsp], xmm0
00007f0254fda5db  vmovaps [rsp+0x10], xmm1
00007f0254fda5e1  vmovaps [rsp+0x20], xmm2
00007f0254fda5e7  vmovaps [rsp+0x30], xmm3
00007f0254fda5ed  vmovaps [rsp+0x40], xmm4
00007f0254fda5f3  vmovaps [rsp+0x50], xmm5
00007f0254fda5f9  vmovaps [rsp+0x60], xmm6
00007f0254fda5ff  vmovaps [rsp+0x70], xmm7
00007f0254fda605  vmovaps [rsp+0x80], xmm9
00007f0254fda60e  vmovaps [rsp+0x90], xmm10
00007f0254fda617  vmovaps [rsp+0xA0], xmm11
00007f0254fda620  vmovaps [rsp+0xB0], xmm12
00007f0254fda629  vmovaps [rsp+0xC0], xmm13
00007f0254fda632  vmovaps [rsp+0xD0], xmm14
00007f0254fda63b  vmovaps [rsp+0xE0], xmm15
00007f0254fda644  sub rsp, 0x30
00007f0254fda648  movaps [rsp], xmm8
00007f0254fda64d  movaps [rsp+0x10], xmm15
00007f0254fda653  movaps [rsp+0x20], xmm9
00007f0254fda659  lea rdi, [rsp]
00007f0254fda65d  mov esi, 0x00
00007f0254fda662  mov rax, 0x55DD1360A530
00007f0254fda66c  call rax
00007f0254fda66e  movaps xmm8, [rsp]
00007f0254fda673  add rsp, 0x30
00007f0254fda677  vmovaps xmm0, [rsp]
00007f0254fda67c  vmovaps xmm1, [rsp+0x10]
00007f0254fda682  vmovaps xmm2, [rsp+0x20]
00007f0254fda688  vmovaps xmm3, [rsp+0x30]
00007f0254fda68e  vmovaps xmm4, [rsp+0x40]
00007f0254fda694  vmovaps xmm5, [rsp+0x50]
00007f0254fda69a  vmovaps xmm6, [rsp+0x60]
00007f0254fda6a0  vmovaps xmm7, [rsp+0x70]
00007f0254fda6a6  vmovaps xmm9, [rsp+0x80]
00007f0254fda6af  vmovaps xmm10, [rsp+0x90]
00007f0254fda6b8  vmovaps xmm11, [rsp+0xA0]
00007f0254fda6c1  vmovaps xmm12, [rsp+0xB0]
00007f0254fda6ca  vmovaps xmm13, [rsp+0xC0]
00007f0254fda6d3  vmovaps xmm14, [rsp+0xD0]
00007f0254fda6dc  vmovaps xmm15, [rsp+0xE0]
00007f0254fda6e5  add rsp, 0xF0
00007f0254fda6ec  pop r11
00007f0254fda6ee  pop r10
00007f0254fda6f0  pop r9
00007f0254fda6f2  pop r8
00007f0254fda6f4  pop rsi
00007f0254fda6f5  pop rdi
00007f0254fda6f6  pop rdx
00007f0254fda6f7  pop rcx
00007f0254fda6f8  pop rax
00007f0254fda6f9  add rsp, 0x08
00007f0254fda6fd  jmp 0x00007F0254FD648A
00007f0254fda702  sub rsp, 0x08
00007f0254fda706  push rax
00007f0254fda707  push rcx
00007f0254fda708  push rdx
00007f0254fda709  push rdi
00007f0254fda70a  push rsi
00007f0254fda70b  push r8
00007f0254fda70d  push r9
00007f0254fda70f  push r10
00007f0254fda711  push r11
00007f0254fda713  sub rsp, 0xF0
00007f0254fda71a  vmovaps [rsp], xmm0
00007f0254fda71f  vmovaps [rsp+0x10], xmm1
00007f0254fda725  vmovaps [rsp+0x20], xmm2
00007f0254fda72b  vmovaps [rsp+0x30], xmm3
00007f0254fda731  vmovaps [rsp+0x40], xmm4
00007f0254fda737  vmovaps [rsp+0x50], xmm5
00007f0254fda73d  vmovaps [rsp+0x60], xmm6
00007f0254fda743  vmovaps [rsp+0x70], xmm7
00007f0254fda749  vmovaps [rsp+0x80], xmm8
00007f0254fda752  vmovaps [rsp+0x90], xmm9
00007f0254fda75b  vmovaps [rsp+0xA0], xmm10
00007f0254fda764  vmovaps [rsp+0xB0], xmm11
00007f0254fda76d  vmovaps [rsp+0xC0], xmm12
00007f0254fda776  vmovaps [rsp+0xD0], xmm13
00007f0254fda77f  vmovaps [rsp+0xE0], xmm14
00007f0254fda788  sub rsp, 0x30
00007f0254fda78c  movaps [rsp], xmm15
00007f0254fda791  movaps [rsp+0x10], xmm11
00007f0254fda797  movaps [rsp+0x20], xmm6
00007f0254fda79c  lea rdi, [rsp]
00007f0254fda7a0  mov esi, 0x00
00007f0254fda7a5  mov rax, 0x55DD1360A530
00007f0254fda7af  call rax
00007f0254fda7b1  movaps xmm15, [rsp]
00007f0254fda7b6  add rsp, 0x30
00007f0254fda7ba  vmovaps xmm0, [rsp]
00007f0254fda7bf  vmovaps xmm1, [rsp+0x10]
00007f0254fda7c5  vmovaps xmm2, [rsp+0x20]
00007f0254fda7cb  vmovaps xmm3, [rsp+0x30]
00007f0254fda7d1  vmovaps xmm4, [rsp+0x40]
00007f0254fda7d7  vmovaps xmm5, [rsp+0x50]
00007f0254fda7dd  vmovaps xmm6, [rsp+0x60]
00007f0254fda7e3  vmovaps xmm7, [rsp+0x70]
00007f0254fda7e9  vmovaps xmm8, [rsp+0x80]
00007f0254fda7f2  vmovaps xmm9, [rsp+0x90]
00007f0254fda7fb  vmovaps xmm10, [rsp+0xA0]
00007f0254fda804  vmovaps xmm11, [rsp+0xB0]
00007f0254fda80d  vmovaps xmm12, [rsp+0xC0]
00007f0254fda816  vmovaps xmm13, [rsp+0xD0]
00007f0254fda81f  vmovaps xmm14, [rsp+0xE0]
00007f0254fda828  add rsp, 0xF0
00007f0254fda82f  pop r11
00007f0254fda831  pop r10
00007f0254fda833  pop r9
00007f0254fda835  pop r8
00007f0254fda837  pop rsi
00007f0254fda838  pop rdi
00007f0254fda839  pop rdx
00007f0254fda83a  pop rcx
00007f0254fda83b  pop rax
00007f0254fda83c  add rsp, 0x08
00007f0254fda840  jmp 0x00007F0254FD64A5
00007f0254fda845  sub rsp, 0x08
00007f0254fda849  push rax
00007f0254fda84a  push rcx
00007f0254fda84b  push rdx
00007f0254fda84c  push rdi
00007f0254fda84d  push rsi
00007f0254fda84e  push r8
00007f0254fda850  push r9
00007f0254fda852  push r10
00007f0254fda854  push r11
00007f0254fda856  sub rsp, 0xF0
00007f0254fda85d  vmovaps [rsp], xmm0
00007f0254fda862  vmovaps [rsp+0x10], xmm1
00007f0254fda868  vmovaps [rsp+0x20], xmm2
00007f0254fda86e  vmovaps [rsp+0x30], xmm3
00007f0254fda874  vmovaps [rsp+0x40], xmm4
00007f0254fda87a  vmovaps [rsp+0x50], xmm5
00007f0254fda880  vmovaps [rsp+0x60], xmm6
00007f0254fda886  vmovaps [rsp+0x70], xmm8
00007f0254fda88c  vmovaps [rsp+0x80], xmm9
00007f0254fda895  vmovaps [rsp+0x90], xmm10
00007f0254fda89e  vmovaps [rsp+0xA0], xmm11
00007f0254fda8a7  vmovaps [rsp+0xB0], xmm12
00007f0254fda8b0  vmovaps [rsp+0xC0], xmm13
00007f0254fda8b9  vmovaps [rsp+0xD0], xmm14
00007f0254fda8c2  vmovaps [rsp+0xE0], xmm15
00007f0254fda8cb  sub rsp, 0x30
00007f0254fda8cf  movaps [rsp], xmm7
00007f0254fda8d3  movaps [rsp+0x10], xmm11
00007f0254fda8d9  movaps [rsp+0x20], xmm9
00007f0254fda8df  lea rdi, [rsp]
00007f0254fda8e3  mov esi, 0x00
00007f0254fda8e8  mov rax, 0x55DD1360A530
00007f0254fda8f2  call rax
00007f0254fda8f4  movaps xmm7, [rsp]
00007f0254fda8f8  add rsp, 0x30
00007f0254fda8fc  vmovaps xmm0, [rsp]
00007f0254fda901  vmovaps xmm1, [rsp+0x10]
00007f0254fda907  vmovaps xmm2, [rsp+0x20]
00007f0254fda90d  vmovaps xmm3, [rsp+0x30]
00007f0254fda913  vmovaps xmm4, [rsp+0x40]
00007f0254fda919  vmovaps xmm5, [rsp+0x50]
00007f0254fda91f  vmovaps xmm6, [rsp+0x60]
00007f0254fda925  vmovaps xmm8, [rsp+0x70]
00007f0254fda92b  vmovaps xmm9, [rsp+0x80]
00007f0254fda934  vmovaps xmm10, [rsp+0x90]
00007f0254fda93d  vmovaps xmm11, [rsp+0xA0]
00007f0254fda946  vmovaps xmm12, [rsp+0xB0]
00007f0254fda94f  vmovaps xmm13, [rsp+0xC0]
00007f0254fda958  vmovaps xmm14, [rsp+0xD0]
00007f0254fda961  vmovaps xmm15, [rsp+0xE0]
00007f0254fda96a  add rsp, 0xF0
00007f0254fda971  pop r11
00007f0254fda973  pop r10
00007f0254fda975  pop r9
00007f0254fda977  pop r8
00007f0254fda979  pop rsi
00007f0254fda97a  pop rdi
00007f0254fda97b  pop rdx
00007f0254fda97c  pop rcx
00007f0254fda97d  pop rax
00007f0254fda97e  add rsp, 0x08
00007f0254fda982  jmp 0x00007F0254FD64D2
00007f0254fda987  sub rsp, 0x08
00007f0254fda98b  push rax
00007f0254fda98c  push rcx
00007f0254fda98d  push rdx
00007f0254fda98e  push rdi
00007f0254fda98f  push rsi
00007f0254fda990  push r8
00007f0254fda992  push r9
00007f0254fda994  push r10
00007f0254fda996  push r11
00007f0254fda998  sub rsp, 0xF0
00007f0254fda99f  vmovaps [rsp], xmm0
00007f0254fda9a4  vmovaps [rsp+0x10], xmm1
00007f0254fda9aa  vmovaps [rsp+0x20], xmm2
00007f0254fda9b0  vmovaps [rsp+0x30], xmm3
00007f0254fda9b6  vmovaps [rsp+0x40], xmm4
00007f0254fda9bc  vmovaps [rsp+0x50], xmm5
00007f0254fda9c2  vmovaps [rsp+0x60], xmm6
00007f0254fda9c8  vmovaps [rsp+0x70], xmm7
00007f0254fda9ce  vmovaps [rsp+0x80], xmm8
00007f0254fda9d7  vmovaps [rsp+0x90], xmm9
00007f0254fda9e0  vmovaps [rsp+0xA0], xmm10
00007f0254fda9e9  vmovaps [rsp+0xB0], xmm12
00007f0254fda9f2  vmovaps [rsp+0xC0], xmm13
00007f0254fda9fb  vmovaps [rsp+0xD0], xmm14
00007f0254fdaa04  vmovaps [rsp+0xE0], xmm15
00007f0254fdaa0d  sub rsp, 0x30
00007f0254fdaa11  movaps [rsp], xmm11
00007f0254fdaa16  movaps [rsp+0x10], xmm10
00007f0254fdaa1c  movaps [rsp+0x20], xmm14
00007f0254fdaa22  lea rdi, [rsp]
00007f0254fdaa26  mov esi, 0x00
00007f0254fdaa2b  mov rax, 0x55DD1360A530
00007f0254fdaa35  call rax
00007f0254fdaa37  movaps xmm11, [rsp]
00007f0254fdaa3c  add rsp, 0x30
00007f0254fdaa40  vmovaps xmm0, [rsp]
00007f0254fdaa45  vmovaps xmm1, [rsp+0x10]
00007f0254fdaa4b  vmovaps xmm2, [rsp+0x20]
00007f0254fdaa51  vmovaps xmm3, [rsp+0x30]
00007f0254fdaa57  vmovaps xmm4, [rsp+0x40]
00007f0254fdaa5d  vmovaps xmm5, [rsp+0x50]
00007f0254fdaa63  vmovaps xmm6, [rsp+0x60]
00007f0254fdaa69  vmovaps xmm7, [rsp+0x70]
00007f0254fdaa6f  vmovaps xmm8, [rsp+0x80]
00007f0254fdaa78  vmovaps xmm9, [rsp+0x90]
00007f0254fdaa81  vmovaps xmm10, [rsp+0xA0]
00007f0254fdaa8a  vmovaps xmm12, [rsp+0xB0]
00007f0254fdaa93  vmovaps xmm13, [rsp+0xC0]
00007f0254fdaa9c  vmovaps xmm14, [rsp+0xD0]
00007f0254fdaaa5  vmovaps xmm15, [rsp+0xE0]
00007f0254fdaaae  add rsp, 0xF0
00007f0254fdaab5  pop r11
00007f0254fdaab7  pop r10
00007f0254fdaab9  pop r9
00007f0254fdaabb  pop r8
00007f0254fdaabd  pop rsi
00007f0254fdaabe  pop rdi
00007f0254fdaabf  pop rdx
00007f0254fdaac0  pop rcx
00007f0254fdaac1  pop rax
00007f0254fdaac2  add rsp, 0x08
00007f0254fdaac6  jmp 0x00007F0254FD64ED
00007f0254fdaacb  call 0x00007F0254EE45A0
00007f0254fdaad0  jmp 0x00007F0254FD64F7
00007f0254fdaad5  sub rsp, 0x08
00007f0254fdaad9  push rax
00007f0254fdaada  push rcx
00007f0254fdaadb  push rdx
00007f0254fdaadc  push rdi
00007f0254fdaadd  push rsi
00007f0254fdaade  push r8
00007f0254fdaae0  push r9
00007f0254fdaae2  push r10
00007f0254fdaae4  push r11
00007f0254fdaae6  sub rsp, 0xF0
00007f0254fdaaed  vmovaps [rsp], xmm0
00007f0254fdaaf2  vmovaps [rsp+0x10], xmm1
00007f0254fdaaf8  vmovaps [rsp+0x20], xmm2
00007f0254fdaafe  vmovaps [rsp+0x30], xmm3
00007f0254fdab04  vmovaps [rsp+0x40], xmm4
00007f0254fdab0a  vmovaps [rsp+0x50], xmm5
00007f0254fdab10  vmovaps [rsp+0x60], xmm6
00007f0254fdab16  vmovaps [rsp+0x70], xmm7
00007f0254fdab1c  vmovaps [rsp+0x80], xmm8
00007f0254fdab25  vmovaps [rsp+0x90], xmm9
00007f0254fdab2e  vmovaps [rsp+0xA0], xmm11
00007f0254fdab37  vmovaps [rsp+0xB0], xmm12
00007f0254fdab40  vmovaps [rsp+0xC0], xmm13
00007f0254fdab49  vmovaps [rsp+0xD0], xmm14
00007f0254fdab52  vmovaps [rsp+0xE0], xmm15
00007f0254fdab5b  sub rsp, 0x30
00007f0254fdab5f  movaps [rsp], xmm10
00007f0254fdab64  movaps [rsp+0x10], xmm1
00007f0254fdab69  movaps [rsp+0x20], xmm12
00007f0254fdab6f  lea rdi, [rsp]
00007f0254fdab73  mov esi, 0x00
00007f0254fdab78  mov rax, 0x55DD1360A530
00007f0254fdab82  call rax
00007f0254fdab84  movaps xmm10, [rsp]
00007f0254fdab89  add rsp, 0x30
00007f0254fdab8d  vmovaps xmm0, [rsp]
00007f0254fdab92  vmovaps xmm1, [rsp+0x10]
00007f0254fdab98  vmovaps xmm2, [rsp+0x20]
00007f0254fdab9e  vmovaps xmm3, [rsp+0x30]
00007f0254fdaba4  vmovaps xmm4, [rsp+0x40]
00007f0254fdabaa  vmovaps xmm5, [rsp+0x50]
00007f0254fdabb0  vmovaps xmm6, [rsp+0x60]
00007f0254fdabb6  vmovaps xmm7, [rsp+0x70]
00007f0254fdabbc  vmovaps xmm8, [rsp+0x80]
00007f0254fdabc5  vmovaps xmm9, [rsp+0x90]
00007f0254fdabce  vmovaps xmm11, [rsp+0xA0]
00007f0254fdabd7  vmovaps xmm12, [rsp+0xB0]
00007f0254fdabe0  vmovaps xmm13, [rsp+0xC0]
00007f0254fdabe9  vmovaps xmm14, [rsp+0xD0]
00007f0254fdabf2  vmovaps xmm15, [rsp+0xE0]
00007f0254fdabfb  add rsp, 0xF0
00007f0254fdac02  pop r11
00007f0254fdac04  pop r10
00007f0254fdac06  pop r9
00007f0254fdac08  pop r8
00007f0254fdac0a  pop rsi
00007f0254fdac0b  pop rdi
00007f0254fdac0c  pop rdx
00007f0254fdac0d  pop rcx
00007f0254fdac0e  pop rax
00007f0254fdac0f  add rsp, 0x08
00007f0254fdac13  jmp 0x00007F0254FD651A
00007f0254fdac18  sub rsp, 0x08
00007f0254fdac1c  push rax
00007f0254fdac1d  push rcx
00007f0254fdac1e  push rdx
00007f0254fdac1f  push rdi
00007f0254fdac20  push rsi
00007f0254fdac21  push r8
00007f0254fdac23  push r9
00007f0254fdac25  push r10
00007f0254fdac27  push r11
00007f0254fdac29  sub rsp, 0xF0
00007f0254fdac30  vmovaps [rsp], xmm0
00007f0254fdac35  vmovaps [rsp+0x10], xmm1
00007f0254fdac3b  vmovaps [rsp+0x20], xmm2
00007f0254fdac41  vmovaps [rsp+0x30], xmm3
00007f0254fdac47  vmovaps [rsp+0x40], xmm4
00007f0254fdac4d  vmovaps [rsp+0x50], xmm5
00007f0254fdac53  vmovaps [rsp+0x60], xmm6
00007f0254fdac59  vmovaps [rsp+0x70], xmm7
00007f0254fdac5f  vmovaps [rsp+0x80], xmm8
00007f0254fdac68  vmovaps [rsp+0x90], xmm9
00007f0254fdac71  vmovaps [rsp+0xA0], xmm10
00007f0254fdac7a  vmovaps [rsp+0xB0], xmm11
00007f0254fdac83  vmovaps [rsp+0xC0], xmm13
00007f0254fdac8c  vmovaps [rsp+0xD0], xmm14
00007f0254fdac95  vmovaps [rsp+0xE0], xmm15
00007f0254fdac9e  sub rsp, 0x30
00007f0254fdaca2  movaps [rsp], xmm12
00007f0254fdaca7  movaps [rsp+0x10], xmm14
00007f0254fdacad  movaps [rsp+0x20], xmm1
00007f0254fdacb2  lea rdi, [rsp]
00007f0254fdacb6  mov esi, 0x00
00007f0254fdacbb  mov rax, 0x55DD1360A530
00007f0254fdacc5  call rax
00007f0254fdacc7  movaps xmm12, [rsp]
00007f0254fdaccc  add rsp, 0x30
00007f0254fdacd0  vmovaps xmm0, [rsp]
00007f0254fdacd5  vmovaps xmm1, [rsp+0x10]
00007f0254fdacdb  vmovaps xmm2, [rsp+0x20]
00007f0254fdace1  vmovaps xmm3, [rsp+0x30]
00007f0254fdace7  vmovaps xmm4, [rsp+0x40]
00007f0254fdaced  vmovaps xmm5, [rsp+0x50]
00007f0254fdacf3  vmovaps xmm6, [rsp+0x60]
00007f0254fdacf9  vmovaps xmm7, [rsp+0x70]
00007f0254fdacff  vmovaps xmm8, [rsp+0x80]
00007f0254fdad08  vmovaps xmm9, [rsp+0x90]
00007f0254fdad11  vmovaps xmm10, [rsp+0xA0]
00007f0254fdad1a  vmovaps xmm11, [rsp+0xB0]
00007f0254fdad23  vmovaps xmm13, [rsp+0xC0]
00007f0254fdad2c  vmovaps xmm14, [rsp+0xD0]
00007f0254fdad35  vmovaps xmm15, [rsp+0xE0]
00007f0254fdad3e  add rsp, 0xF0
00007f0254fdad45  pop r11
00007f0254fdad47  pop r10
00007f0254fdad49  pop r9
00007f0254fdad4b  pop r8
00007f0254fdad4d  pop rsi
00007f0254fdad4e  pop rdi
00007f0254fdad4f  pop rdx
00007f0254fdad50  pop rcx
00007f0254fdad51  pop rax
00007f0254fdad52  add rsp, 0x08
00007f0254fdad56  jmp 0x00007F0254FD6549
00007f0254fdad5b  sub rsp, 0x08
00007f0254fdad5f  push rax
00007f0254fdad60  push rcx
00007f0254fdad61  push rdx
00007f0254fdad62  push rdi
00007f0254fdad63  push rsi
00007f0254fdad64  push r8
00007f0254fdad66  push r9
00007f0254fdad68  push r10
00007f0254fdad6a  push r11
00007f0254fdad6c  sub rsp, 0xF0
00007f0254fdad73  vmovaps [rsp], xmm0
00007f0254fdad78  vmovaps [rsp+0x10], xmm1
00007f0254fdad7e  vmovaps [rsp+0x20], xmm2
00007f0254fdad84  vmovaps [rsp+0x30], xmm3
00007f0254fdad8a  vmovaps [rsp+0x40], xmm4
00007f0254fdad90  vmovaps [rsp+0x50], xmm5
00007f0254fdad96  vmovaps [rsp+0x60], xmm6
00007f0254fdad9c  vmovaps [rsp+0x70], xmm7
00007f0254fdada2  vmovaps [rsp+0x80], xmm8
00007f0254fdadab  vmovaps [rsp+0x90], xmm9
00007f0254fdadb4  vmovaps [rsp+0xA0], xmm10
00007f0254fdadbd  vmovaps [rsp+0xB0], xmm11
00007f0254fdadc6  vmovaps [rsp+0xC0], xmm12
00007f0254fdadcf  vmovaps [rsp+0xD0], xmm13
00007f0254fdadd8  vmovaps [rsp+0xE0], xmm15
00007f0254fdade1  sub rsp, 0x30
00007f0254fdade5  movaps [rsp], xmm14
00007f0254fdadea  movaps [rsp+0x10], xmm9
00007f0254fdadf0  movaps [rsp+0x20], xmm1
00007f0254fdadf5  lea rdi, [rsp]
00007f0254fdadf9  mov esi, 0x00
00007f0254fdadfe  mov rax, 0x55DD1360A530
00007f0254fdae08  call rax
00007f0254fdae0a  movaps xmm14, [rsp]
00007f0254fdae0f  add rsp, 0x30
00007f0254fdae13  vmovaps xmm0, [rsp]
00007f0254fdae18  vmovaps xmm1, [rsp+0x10]
00007f0254fdae1e  vmovaps xmm2, [rsp+0x20]
00007f0254fdae24  vmovaps xmm3, [rsp+0x30]
00007f0254fdae2a  vmovaps xmm4, [rsp+0x40]
00007f0254fdae30  vmovaps xmm5, [rsp+0x50]
00007f0254fdae36  vmovaps xmm6, [rsp+0x60]
00007f0254fdae3c  vmovaps xmm7, [rsp+0x70]
00007f0254fdae42  vmovaps xmm8, [rsp+0x80]
00007f0254fdae4b  vmovaps xmm9, [rsp+0x90]
00007f0254fdae54  vmovaps xmm10, [rsp+0xA0]
00007f0254fdae5d  vmovaps xmm11, [rsp+0xB0]
00007f0254fdae66  vmovaps xmm12, [rsp+0xC0]
00007f0254fdae6f  vmovaps xmm13, [rsp+0xD0]
00007f0254fdae78  vmovaps xmm15, [rsp+0xE0]
00007f0254fdae81  add rsp, 0xF0
00007f0254fdae88  pop r11
00007f0254fdae8a  pop r10
00007f0254fdae8c  pop r9
00007f0254fdae8e  pop r8
00007f0254fdae90  pop rsi
00007f0254fdae91  pop rdi
00007f0254fdae92  pop rdx
00007f0254fdae93  pop rcx
00007f0254fdae94  pop rax
00007f0254fdae95  add rsp, 0x08
00007f0254fdae99  jmp 0x00007F0254FD6578
00007f0254fdae9e  sub rsp, 0x08
00007f0254fdaea2  push rax
00007f0254fdaea3  push rcx
00007f0254fdaea4  push rdx
00007f0254fdaea5  push rdi
00007f0254fdaea6  push rsi
00007f0254fdaea7  push r8
00007f0254fdaea9  push r9
00007f0254fdaeab  push r10
00007f0254fdaead  push r11
00007f0254fdaeaf  sub rsp, 0xF0
00007f0254fdaeb6  vmovaps [rsp], xmm0
00007f0254fdaebb  vmovaps [rsp+0x10], xmm2
00007f0254fdaec1  vmovaps [rsp+0x20], xmm3
00007f0254fdaec7  vmovaps [rsp+0x30], xmm4
00007f0254fdaecd  vmovaps [rsp+0x40], xmm5
00007f0254fdaed3  vmovaps [rsp+0x50], xmm6
00007f0254fdaed9  vmovaps [rsp+0x60], xmm7
00007f0254fdaedf  vmovaps [rsp+0x70], xmm8
00007f0254fdaee5  vmovaps [rsp+0x80], xmm9
00007f0254fdaeee  vmovaps [rsp+0x90], xmm10
00007f0254fdaef7  vmovaps [rsp+0xA0], xmm11
00007f0254fdaf00  vmovaps [rsp+0xB0], xmm12
00007f0254fdaf09  vmovaps [rsp+0xC0], xmm13
00007f0254fdaf12  vmovaps [rsp+0xD0], xmm14
00007f0254fdaf1b  vmovaps [rsp+0xE0], xmm15
00007f0254fdaf24  sub rsp, 0x30
00007f0254fdaf28  movaps [rsp], xmm1
00007f0254fdaf2c  movaps [rsp+0x10], xmm13
00007f0254fdaf32  movaps [rsp+0x20], xmm8
00007f0254fdaf38  lea rdi, [rsp]
00007f0254fdaf3c  mov esi, 0x00
00007f0254fdaf41  mov rax, 0x55DD1360A530
00007f0254fdaf4b  call rax
00007f0254fdaf4d  movaps xmm1, [rsp]
00007f0254fdaf51  add rsp, 0x30
00007f0254fdaf55  vmovaps xmm0, [rsp]
00007f0254fdaf5a  vmovaps xmm2, [rsp+0x10]
00007f0254fdaf60  vmovaps xmm3, [rsp+0x20]
00007f0254fdaf66  vmovaps xmm4, [rsp+0x30]
00007f0254fdaf6c  vmovaps xmm5, [rsp+0x40]
00007f0254fdaf72  vmovaps xmm6, [rsp+0x50]
00007f0254fdaf78  vmovaps xmm7, [rsp+0x60]
00007f0254fdaf7e  vmovaps xmm8, [rsp+0x70]
00007f0254fdaf84  vmovaps xmm9, [rsp+0x80]
00007f0254fdaf8d  vmovaps xmm10, [rsp+0x90]
00007f0254fdaf96  vmovaps xmm11, [rsp+0xA0]
00007f0254fdaf9f  vmovaps xmm12, [rsp+0xB0]
00007f0254fdafa8  vmovaps xmm13, [rsp+0xC0]
00007f0254fdafb1  vmovaps xmm14, [rsp+0xD0]
00007f0254fdafba  vmovaps xmm15, [rsp+0xE0]
00007f0254fdafc3  add rsp, 0xF0
00007f0254fdafca  pop r11
00007f0254fdafcc  pop r10
00007f0254fdafce  pop r9
00007f0254fdafd0  pop r8
00007f0254fdafd2  pop rsi
00007f0254fdafd3  pop rdi
00007f0254fdafd4  pop rdx
00007f0254fdafd5  pop rcx
00007f0254fdafd6  pop rax
00007f0254fdafd7  add rsp, 0x08
00007f0254fdafdb  jmp 0x00007F0254FD659A
00007f0254fdafe0  call 0x00007F0254E0C260
00007f0254fdafe5  jmp 0x00007F0254FD65A8
00007f0254fdafea  call 0x00007F0254EDE950
00007f0254fdafef  jmp 0x00007F0254FD65B2
00007f0254fdaff4  sub rsp, 0x08
00007f0254fdaff8  push rax
00007f0254fdaff9  push rcx
00007f0254fdaffa  push rdx
00007f0254fdaffb  push rdi
00007f0254fdaffc  push rsi
00007f0254fdaffd  push r8
00007f0254fdafff  push r9
00007f0254fdb001  push r10
00007f0254fdb003  push r11
00007f0254fdb005  sub rsp, 0xF0
00007f0254fdb00c  vmovaps [rsp], xmm0
00007f0254fdb011  vmovaps [rsp+0x10], xmm1
00007f0254fdb017  vmovaps [rsp+0x20], xmm2
00007f0254fdb01d  vmovaps [rsp+0x30], xmm3
00007f0254fdb023  vmovaps [rsp+0x40], xmm4
00007f0254fdb029  vmovaps [rsp+0x50], xmm5
00007f0254fdb02f  vmovaps [rsp+0x60], xmm6
00007f0254fdb035  vmovaps [rsp+0x70], xmm7
00007f0254fdb03b  vmovaps [rsp+0x80], xmm9
00007f0254fdb044  vmovaps [rsp+0x90], xmm10
00007f0254fdb04d  vmovaps [rsp+0xA0], xmm11
00007f0254fdb056  vmovaps [rsp+0xB0], xmm12
00007f0254fdb05f  vmovaps [rsp+0xC0], xmm13
00007f0254fdb068  vmovaps [rsp+0xD0], xmm14
00007f0254fdb071  vmovaps [rsp+0xE0], xmm15
00007f0254fdb07a  sub rsp, 0x30
00007f0254fdb07e  movaps [rsp], xmm8
00007f0254fdb083  movaps [rsp+0x10], xmm15
00007f0254fdb089  movaps [rsp+0x20], xmm7
00007f0254fdb08e  lea rdi, [rsp]
00007f0254fdb092  mov esi, 0x00
00007f0254fdb097  mov rax, 0x55DD1360A530
00007f0254fdb0a1  call rax
00007f0254fdb0a3  movaps xmm8, [rsp]
00007f0254fdb0a8  add rsp, 0x30
00007f0254fdb0ac  vmovaps xmm0, [rsp]
00007f0254fdb0b1  vmovaps xmm1, [rsp+0x10]
00007f0254fdb0b7  vmovaps xmm2, [rsp+0x20]
00007f0254fdb0bd  vmovaps xmm3, [rsp+0x30]
00007f0254fdb0c3  vmovaps xmm4, [rsp+0x40]
00007f0254fdb0c9  vmovaps xmm5, [rsp+0x50]
00007f0254fdb0cf  vmovaps xmm6, [rsp+0x60]
00007f0254fdb0d5  vmovaps xmm7, [rsp+0x70]
00007f0254fdb0db  vmovaps xmm9, [rsp+0x80]
00007f0254fdb0e4  vmovaps xmm10, [rsp+0x90]
00007f0254fdb0ed  vmovaps xmm11, [rsp+0xA0]
00007f0254fdb0f6  vmovaps xmm12, [rsp+0xB0]
00007f0254fdb0ff  vmovaps xmm13, [rsp+0xC0]
00007f0254fdb108  vmovaps xmm14, [rsp+0xD0]
00007f0254fdb111  vmovaps xmm15, [rsp+0xE0]
00007f0254fdb11a  add rsp, 0xF0
00007f0254fdb121  pop r11
00007f0254fdb123  pop r10
00007f0254fdb125  pop r9
00007f0254fdb127  pop r8
00007f0254fdb129  pop rsi
00007f0254fdb12a  pop rdi
00007f0254fdb12b  pop rdx
00007f0254fdb12c  pop rcx
00007f0254fdb12d  pop rax
00007f0254fdb12e  add rsp, 0x08
00007f0254fdb132  jmp 0x00007F0254FD65D4
00007f0254fdb137  sub rsp, 0x08
00007f0254fdb13b  push rax
00007f0254fdb13c  push rcx
00007f0254fdb13d  push rdx
00007f0254fdb13e  push rdi
00007f0254fdb13f  push rsi
00007f0254fdb140  push r8
00007f0254fdb142  push r9
00007f0254fdb144  push r10
00007f0254fdb146  push r11
00007f0254fdb148  sub rsp, 0xF0
00007f0254fdb14f  vmovaps [rsp], xmm0
00007f0254fdb154  vmovaps [rsp+0x10], xmm1
00007f0254fdb15a  vmovaps [rsp+0x20], xmm2
00007f0254fdb160  vmovaps [rsp+0x30], xmm3
00007f0254fdb166  vmovaps [rsp+0x40], xmm4
00007f0254fdb16c  vmovaps [rsp+0x50], xmm5
00007f0254fdb172  vmovaps [rsp+0x60], xmm6
00007f0254fdb178  vmovaps [rsp+0x70], xmm8
00007f0254fdb17e  vmovaps [rsp+0x80], xmm9
00007f0254fdb187  vmovaps [rsp+0x90], xmm10
00007f0254fdb190  vmovaps [rsp+0xA0], xmm11
00007f0254fdb199  vmovaps [rsp+0xB0], xmm12
00007f0254fdb1a2  vmovaps [rsp+0xC0], xmm13
00007f0254fdb1ab  vmovaps [rsp+0xD0], xmm14
00007f0254fdb1b4  vmovaps [rsp+0xE0], xmm15
00007f0254fdb1bd  sub rsp, 0x30
00007f0254fdb1c1  movaps [rsp], xmm7
00007f0254fdb1c5  movaps [rsp+0x10], xmm9
00007f0254fdb1cb  movaps [rsp+0x20], xmm15
00007f0254fdb1d1  lea rdi, [rsp]
00007f0254fdb1d5  mov esi, 0x00
00007f0254fdb1da  mov rax, 0x55DD1360A530
00007f0254fdb1e4  call rax
00007f0254fdb1e6  movaps xmm7, [rsp]
00007f0254fdb1ea  add rsp, 0x30
00007f0254fdb1ee  vmovaps xmm0, [rsp]
00007f0254fdb1f3  vmovaps xmm1, [rsp+0x10]
00007f0254fdb1f9  vmovaps xmm2, [rsp+0x20]
00007f0254fdb1ff  vmovaps xmm3, [rsp+0x30]
00007f0254fdb205  vmovaps xmm4, [rsp+0x40]
00007f0254fdb20b  vmovaps xmm5, [rsp+0x50]
00007f0254fdb211  vmovaps xmm6, [rsp+0x60]
00007f0254fdb217  vmovaps xmm8, [rsp+0x70]
00007f0254fdb21d  vmovaps xmm9, [rsp+0x80]
00007f0254fdb226  vmovaps xmm10, [rsp+0x90]
00007f0254fdb22f  vmovaps xmm11, [rsp+0xA0]
00007f0254fdb238  vmovaps xmm12, [rsp+0xB0]
00007f0254fdb241  vmovaps xmm13, [rsp+0xC0]
00007f0254fdb24a  vmovaps xmm14, [rsp+0xD0]
00007f0254fdb253  vmovaps xmm15, [rsp+0xE0]
00007f0254fdb25c  add rsp, 0xF0
00007f0254fdb263  pop r11
00007f0254fdb265  pop r10
00007f0254fdb267  pop r9
00007f0254fdb269  pop r8
00007f0254fdb26b  pop rsi
00007f0254fdb26c  pop rdi
00007f0254fdb26d  pop rdx
00007f0254fdb26e  pop rcx
00007f0254fdb26f  pop rax
00007f0254fdb270  add rsp, 0x08
00007f0254fdb274  jmp 0x00007F0254FD6601
00007f0254fdb279  sub rsp, 0x08
00007f0254fdb27d  push rax
00007f0254fdb27e  push rcx
00007f0254fdb27f  push rdx
00007f0254fdb280  push rdi
00007f0254fdb281  push rsi
00007f0254fdb282  push r8
00007f0254fdb284  push r9
00007f0254fdb286  push r10
00007f0254fdb288  push r11
00007f0254fdb28a  sub rsp, 0xF0
00007f0254fdb291  vmovaps [rsp], xmm0
00007f0254fdb296  vmovaps [rsp+0x10], xmm1
00007f0254fdb29c  vmovaps [rsp+0x20], xmm2
00007f0254fdb2a2  vmovaps [rsp+0x30], xmm3
00007f0254fdb2a8  vmovaps [rsp+0x40], xmm4
00007f0254fdb2ae  vmovaps [rsp+0x50], xmm5
00007f0254fdb2b4  vmovaps [rsp+0x60], xmm6
00007f0254fdb2ba  vmovaps [rsp+0x70], xmm7
00007f0254fdb2c0  vmovaps [rsp+0x80], xmm8
00007f0254fdb2c9  vmovaps [rsp+0x90], xmm10
00007f0254fdb2d2  vmovaps [rsp+0xA0], xmm11
00007f0254fdb2db  vmovaps [rsp+0xB0], xmm12
00007f0254fdb2e4  vmovaps [rsp+0xC0], xmm13
00007f0254fdb2ed  vmovaps [rsp+0xD0], xmm14
00007f0254fdb2f6  vmovaps [rsp+0xE0], xmm15
00007f0254fdb2ff  sub rsp, 0x30
00007f0254fdb303  movaps [rsp], xmm9
00007f0254fdb308  movaps [rsp+0x10], xmm13
00007f0254fdb30e  movaps [rsp+0x20], xmm15
00007f0254fdb314  lea rdi, [rsp]
00007f0254fdb318  mov esi, 0x00
00007f0254fdb31d  mov rax, 0x55DD1360A530
00007f0254fdb327  call rax
00007f0254fdb329  movaps xmm9, [rsp]
00007f0254fdb32e  add rsp, 0x30
00007f0254fdb332  vmovaps xmm0, [rsp]
00007f0254fdb337  vmovaps xmm1, [rsp+0x10]
00007f0254fdb33d  vmovaps xmm2, [rsp+0x20]
00007f0254fdb343  vmovaps xmm3, [rsp+0x30]
00007f0254fdb349  vmovaps xmm4, [rsp+0x40]
00007f0254fdb34f  vmovaps xmm5, [rsp+0x50]
00007f0254fdb355  vmovaps xmm6, [rsp+0x60]
00007f0254fdb35b  vmovaps xmm7, [rsp+0x70]
00007f0254fdb361  vmovaps xmm8, [rsp+0x80]
00007f0254fdb36a  vmovaps xmm10, [rsp+0x90]
00007f0254fdb373  vmovaps xmm11, [rsp+0xA0]
00007f0254fdb37c  vmovaps xmm12, [rsp+0xB0]
00007f0254fdb385  vmovaps xmm13, [rsp+0xC0]
00007f0254fdb38e  vmovaps xmm14, [rsp+0xD0]
00007f0254fdb397  vmovaps xmm15, [rsp+0xE0]
00007f0254fdb3a0  add rsp, 0xF0
00007f0254fdb3a7  pop r11
00007f0254fdb3a9  pop r10
00007f0254fdb3ab  pop r9
00007f0254fdb3ad  pop r8
00007f0254fdb3af  pop rsi
00007f0254fdb3b0  pop rdi
00007f0254fdb3b1  pop rdx
00007f0254fdb3b2  pop rcx
00007f0254fdb3b3  pop rax
00007f0254fdb3b4  add rsp, 0x08
00007f0254fdb3b8  jmp 0x00007F0254FD662F
00007f0254fdb3bd  sub rsp, 0x08
00007f0254fdb3c1  push rax
00007f0254fdb3c2  push rcx
00007f0254fdb3c3  push rdx
00007f0254fdb3c4  push rdi
00007f0254fdb3c5  push rsi
00007f0254fdb3c6  push r8
00007f0254fdb3c8  push r9
00007f0254fdb3ca  push r10
00007f0254fdb3cc  push r11
00007f0254fdb3ce  sub rsp, 0xF0
00007f0254fdb3d5  vmovaps [rsp], xmm0
00007f0254fdb3da  vmovaps [rsp+0x10], xmm1
00007f0254fdb3e0  vmovaps [rsp+0x20], xmm2
00007f0254fdb3e6  vmovaps [rsp+0x30], xmm3
00007f0254fdb3ec  vmovaps [rsp+0x40], xmm4
00007f0254fdb3f2  vmovaps [rsp+0x50], xmm5
00007f0254fdb3f8  vmovaps [rsp+0x60], xmm6
00007f0254fdb3fe  vmovaps [rsp+0x70], xmm7
00007f0254fdb404  vmovaps [rsp+0x80], xmm8
00007f0254fdb40d  vmovaps [rsp+0x90], xmm9
00007f0254fdb416  vmovaps [rsp+0xA0], xmm10
00007f0254fdb41f  vmovaps [rsp+0xB0], xmm11
00007f0254fdb428  vmovaps [rsp+0xC0], xmm12
00007f0254fdb431  vmovaps [rsp+0xD0], xmm13
00007f0254fdb43a  vmovaps [rsp+0xE0], xmm14
00007f0254fdb443  sub rsp, 0x30
00007f0254fdb447  movaps [rsp], xmm15
00007f0254fdb44c  movaps [rsp+0x10], xmm11
00007f0254fdb452  movaps [rsp+0x20], xmm12
00007f0254fdb458  lea rdi, [rsp]
00007f0254fdb45c  mov esi, 0x00
00007f0254fdb461  mov rax, 0x55DD1360A530
00007f0254fdb46b  call rax
00007f0254fdb46d  movaps xmm15, [rsp]
00007f0254fdb472  add rsp, 0x30
00007f0254fdb476  vmovaps xmm0, [rsp]
00007f0254fdb47b  vmovaps xmm1, [rsp+0x10]
00007f0254fdb481  vmovaps xmm2, [rsp+0x20]
00007f0254fdb487  vmovaps xmm3, [rsp+0x30]
00007f0254fdb48d  vmovaps xmm4, [rsp+0x40]
00007f0254fdb493  vmovaps xmm5, [rsp+0x50]
00007f0254fdb499  vmovaps xmm6, [rsp+0x60]
00007f0254fdb49f  vmovaps xmm7, [rsp+0x70]
00007f0254fdb4a5  vmovaps xmm8, [rsp+0x80]
00007f0254fdb4ae  vmovaps xmm9, [rsp+0x90]
00007f0254fdb4b7  vmovaps xmm10, [rsp+0xA0]
00007f0254fdb4c0  vmovaps xmm11, [rsp+0xB0]
00007f0254fdb4c9  vmovaps xmm12, [rsp+0xC0]
00007f0254fdb4d2  vmovaps xmm13, [rsp+0xD0]
00007f0254fdb4db  vmovaps xmm14, [rsp+0xE0]
00007f0254fdb4e4  add rsp, 0xF0
00007f0254fdb4eb  pop r11
00007f0254fdb4ed  pop r10
00007f0254fdb4ef  pop r9
00007f0254fdb4f1  pop r8
00007f0254fdb4f3  pop rsi
00007f0254fdb4f4  pop rdi
00007f0254fdb4f5  pop rdx
00007f0254fdb4f6  pop rcx
00007f0254fdb4f7  pop rax
00007f0254fdb4f8  add rsp, 0x08
00007f0254fdb4fc  jmp 0x00007F0254FD664A
00007f0254fdb501  sub rsp, 0x08
00007f0254fdb505  push rax
00007f0254fdb506  push rcx
00007f0254fdb507  push rdx
00007f0254fdb508  push rdi
00007f0254fdb509  push rsi
00007f0254fdb50a  push r8
00007f0254fdb50c  push r9
00007f0254fdb50e  push r10
00007f0254fdb510  push r11
00007f0254fdb512  sub rsp, 0xF0
00007f0254fdb519  vmovaps [rsp], xmm0
00007f0254fdb51e  vmovaps [rsp+0x10], xmm1
00007f0254fdb524  vmovaps [rsp+0x20], xmm2
00007f0254fdb52a  vmovaps [rsp+0x30], xmm3
00007f0254fdb530  vmovaps [rsp+0x40], xmm4
00007f0254fdb536  vmovaps [rsp+0x50], xmm5
00007f0254fdb53c  vmovaps [rsp+0x60], xmm6
00007f0254fdb542  vmovaps [rsp+0x70], xmm7
00007f0254fdb548  vmovaps [rsp+0x80], xmm8
00007f0254fdb551  vmovaps [rsp+0x90], xmm9
00007f0254fdb55a  vmovaps [rsp+0xA0], xmm10
00007f0254fdb563  vmovaps [rsp+0xB0], xmm11
00007f0254fdb56c  vmovaps [rsp+0xC0], xmm12
00007f0254fdb575  vmovaps [rsp+0xD0], xmm14
00007f0254fdb57e  vmovaps [rsp+0xE0], xmm15
00007f0254fdb587  sub rsp, 0x30
00007f0254fdb58b  movaps [rsp], xmm13
00007f0254fdb590  movaps [rsp+0x10], xmm10
00007f0254fdb596  movaps [rsp+0x20], xmm14
00007f0254fdb59c  lea rdi, [rsp]
00007f0254fdb5a0  mov esi, 0x00
00007f0254fdb5a5  mov rax, 0x55DD1360A530
00007f0254fdb5af  call rax
00007f0254fdb5b1  movaps xmm13, [rsp]
00007f0254fdb5b6  add rsp, 0x30
00007f0254fdb5ba  vmovaps xmm0, [rsp]
00007f0254fdb5bf  vmovaps xmm1, [rsp+0x10]
00007f0254fdb5c5  vmovaps xmm2, [rsp+0x20]
00007f0254fdb5cb  vmovaps xmm3, [rsp+0x30]
00007f0254fdb5d1  vmovaps xmm4, [rsp+0x40]
00007f0254fdb5d7  vmovaps xmm5, [rsp+0x50]
00007f0254fdb5dd  vmovaps xmm6, [rsp+0x60]
00007f0254fdb5e3  vmovaps xmm7, [rsp+0x70]
00007f0254fdb5e9  vmovaps xmm8, [rsp+0x80]
00007f0254fdb5f2  vmovaps xmm9, [rsp+0x90]
00007f0254fdb5fb  vmovaps xmm10, [rsp+0xA0]
00007f0254fdb604  vmovaps xmm11, [rsp+0xB0]
00007f0254fdb60d  vmovaps xmm12, [rsp+0xC0]
00007f0254fdb616  vmovaps xmm14, [rsp+0xD0]
00007f0254fdb61f  vmovaps xmm15, [rsp+0xE0]
00007f0254fdb628  add rsp, 0xF0
00007f0254fdb62f  pop r11
00007f0254fdb631  pop r10
00007f0254fdb633  pop r9
00007f0254fdb635  pop r8
00007f0254fdb637  pop rsi
00007f0254fdb638  pop rdi
00007f0254fdb639  pop rdx
00007f0254fdb63a  pop rcx
00007f0254fdb63b  pop rax
00007f0254fdb63c  add rsp, 0x08
00007f0254fdb640  jmp 0x00007F0254FD666D
00007f0254fdb645  sub rsp, 0x08
00007f0254fdb649  push rax
00007f0254fdb64a  push rcx
00007f0254fdb64b  push rdx
00007f0254fdb64c  push rdi
00007f0254fdb64d  push rsi
00007f0254fdb64e  push r8
00007f0254fdb650  push r9
00007f0254fdb652  push r10
00007f0254fdb654  push r11
00007f0254fdb656  sub rsp, 0xF0
00007f0254fdb65d  vmovaps [rsp], xmm0
00007f0254fdb662  vmovaps [rsp+0x10], xmm1
00007f0254fdb668  vmovaps [rsp+0x20], xmm2
00007f0254fdb66e  vmovaps [rsp+0x30], xmm3
00007f0254fdb674  vmovaps [rsp+0x40], xmm4
00007f0254fdb67a  vmovaps [rsp+0x50], xmm5
00007f0254fdb680  vmovaps [rsp+0x60], xmm6
00007f0254fdb686  vmovaps [rsp+0x70], xmm7
00007f0254fdb68c  vmovaps [rsp+0x80], xmm8
00007f0254fdb695  vmovaps [rsp+0x90], xmm9
00007f0254fdb69e  vmovaps [rsp+0xA0], xmm10
00007f0254fdb6a7  vmovaps [rsp+0xB0], xmm11
00007f0254fdb6b0  vmovaps [rsp+0xC0], xmm12
00007f0254fdb6b9  vmovaps [rsp+0xD0], xmm13
00007f0254fdb6c2  vmovaps [rsp+0xE0], xmm15
00007f0254fdb6cb  sub rsp, 0x30
00007f0254fdb6cf  movaps [rsp], xmm14
00007f0254fdb6d4  movaps [rsp+0x10], xmm1
00007f0254fdb6d9  movaps [rsp+0x20], xmm7
00007f0254fdb6de  lea rdi, [rsp]
00007f0254fdb6e2  mov esi, 0x00
00007f0254fdb6e7  mov rax, 0x55DD1360A530
00007f0254fdb6f1  call rax
00007f0254fdb6f3  movaps xmm14, [rsp]
00007f0254fdb6f8  add rsp, 0x30
00007f0254fdb6fc  vmovaps xmm0, [rsp]
00007f0254fdb701  vmovaps xmm1, [rsp+0x10]
00007f0254fdb707  vmovaps xmm2, [rsp+0x20]
00007f0254fdb70d  vmovaps xmm3, [rsp+0x30]
00007f0254fdb713  vmovaps xmm4, [rsp+0x40]
00007f0254fdb719  vmovaps xmm5, [rsp+0x50]
00007f0254fdb71f  vmovaps xmm6, [rsp+0x60]
00007f0254fdb725  vmovaps xmm7, [rsp+0x70]
00007f0254fdb72b  vmovaps xmm8, [rsp+0x80]
00007f0254fdb734  vmovaps xmm9, [rsp+0x90]
00007f0254fdb73d  vmovaps xmm10, [rsp+0xA0]
00007f0254fdb746  vmovaps xmm11, [rsp+0xB0]
00007f0254fdb74f  vmovaps xmm12, [rsp+0xC0]
00007f0254fdb758  vmovaps xmm13, [rsp+0xD0]
00007f0254fdb761  vmovaps xmm15, [rsp+0xE0]
00007f0254fdb76a  add rsp, 0xF0
00007f0254fdb771  pop r11
00007f0254fdb773  pop r10
00007f0254fdb775  pop r9
00007f0254fdb777  pop r8
00007f0254fdb779  pop rsi
00007f0254fdb77a  pop rdi
00007f0254fdb77b  pop rdx
00007f0254fdb77c  pop rcx
00007f0254fdb77d  pop rax
00007f0254fdb77e  add rsp, 0x08
00007f0254fdb782  jmp 0x00007F0254FD6690
00007f0254fdb787  sub rsp, 0x08
00007f0254fdb78b  push rax
00007f0254fdb78c  push rcx
00007f0254fdb78d  push rdx
00007f0254fdb78e  push rdi
00007f0254fdb78f  push rsi
00007f0254fdb790  push r8
00007f0254fdb792  push r9
00007f0254fdb794  push r10
00007f0254fdb796  push r11
00007f0254fdb798  sub rsp, 0xF0
00007f0254fdb79f  vmovaps [rsp], xmm0
00007f0254fdb7a4  vmovaps [rsp+0x10], xmm2
00007f0254fdb7aa  vmovaps [rsp+0x20], xmm3
00007f0254fdb7b0  vmovaps [rsp+0x30], xmm4
00007f0254fdb7b6  vmovaps [rsp+0x40], xmm5
00007f0254fdb7bc  vmovaps [rsp+0x50], xmm6
00007f0254fdb7c2  vmovaps [rsp+0x60], xmm7
00007f0254fdb7c8  vmovaps [rsp+0x70], xmm8
00007f0254fdb7ce  vmovaps [rsp+0x80], xmm9
00007f0254fdb7d7  vmovaps [rsp+0x90], xmm10
00007f0254fdb7e0  vmovaps [rsp+0xA0], xmm11
00007f0254fdb7e9  vmovaps [rsp+0xB0], xmm12
00007f0254fdb7f2  vmovaps [rsp+0xC0], xmm13
00007f0254fdb7fb  vmovaps [rsp+0xD0], xmm14
00007f0254fdb804  vmovaps [rsp+0xE0], xmm15
00007f0254fdb80d  sub rsp, 0x30
00007f0254fdb811  movaps [rsp], xmm1
00007f0254fdb815  movaps [rsp+0x10], xmm8
00007f0254fdb81b  movaps [rsp+0x20], xmm9
00007f0254fdb821  lea rdi, [rsp]
00007f0254fdb825  mov esi, 0x00
00007f0254fdb82a  mov rax, 0x55DD1360A530
00007f0254fdb834  call rax
00007f0254fdb836  movaps xmm1, [rsp]
00007f0254fdb83a  add rsp, 0x30
00007f0254fdb83e  vmovaps xmm0, [rsp]
00007f0254fdb843  vmovaps xmm2, [rsp+0x10]
00007f0254fdb849  vmovaps xmm3, [rsp+0x20]
00007f0254fdb84f  vmovaps xmm4, [rsp+0x30]
00007f0254fdb855  vmovaps xmm5, [rsp+0x40]
00007f0254fdb85b  vmovaps xmm6, [rsp+0x50]
00007f0254fdb861  vmovaps xmm7, [rsp+0x60]
00007f0254fdb867  vmovaps xmm8, [rsp+0x70]
00007f0254fdb86d  vmovaps xmm9, [rsp+0x80]
00007f0254fdb876  vmovaps xmm10, [rsp+0x90]
00007f0254fdb87f  vmovaps xmm11, [rsp+0xA0]
00007f0254fdb888  vmovaps xmm12, [rsp+0xB0]
00007f0254fdb891  vmovaps xmm13, [rsp+0xC0]
00007f0254fdb89a  vmovaps xmm14, [rsp+0xD0]
00007f0254fdb8a3  vmovaps xmm15, [rsp+0xE0]
00007f0254fdb8ac  add rsp, 0xF0
00007f0254fdb8b3  pop r11
00007f0254fdb8b5  pop r10
00007f0254fdb8b7  pop r9
00007f0254fdb8b9  pop r8
00007f0254fdb8bb  pop rsi
00007f0254fdb8bc  pop rdi
00007f0254fdb8bd  pop rdx
00007f0254fdb8be  pop rcx
00007f0254fdb8bf  pop rax
00007f0254fdb8c0  add rsp, 0x08
00007f0254fdb8c4  jmp 0x00007F0254FD66B2
00007f0254fdb8c9  call 0x00007F0254EB3E40
00007f0254fdb8ce  jmp 0x00007F0254FD66C0
00007f0254fdb8d3  call 0x00007F0254E0C380
00007f0254fdb8d8  jmp 0x00007F0254FD66CA
00007f0254fdb8dd  call 0x00007F0254E0D600
00007f0254fdb8e2  jmp 0x00007F0254FD66D4
00007f0254fdb8e7  call 0x00007F0254DFF540
00007f0254fdb8ec  jmp 0x00007F0254FD66DE
00007f0254fdb8f1  int3
00007f0254fdb8f2  nop [rax+rax*1], ax
00007f0254fdb8fb  nop [rax+rax*1], eax
00007f0254fdb900  mov eax, [r15+0x48]
00007f0254fdb904  lea r14d, [eax+0x01]
00007f0254fdb909  mov [rsp+0x10], r14d
00007f0254fdb90e  mov r14d, r14d
00007f0254fdb911  mov [r15+0x48], r14
00007f0254fdb915  xor eax, eax
00007f0254fdb917  mov r14d, [rsp+0x10]
00007f0254fdb91c  cmp r14d, 0x1F4
00007f0254fdb923  cmc
00007f0254fdb924  lahf
00007f0254fdb925  seto al
00007f0254fdb928  mov [r15+0x108], eax
00007f0254fdb92f  mov eax, [r15+0x108]
00007f0254fdb936  sahf
00007f0254fdb937  jnz 0x00007F0254FDB969
00007f0254fdb939  cmp dword ptr [r15+0x318], 0x00
00007f0254fdb941  jz 0x00007F0254FE1AB0
00007f0254fdb947  nop [rax+rax*1], ax
00007f0254fdb950  nop [rax+rax*1], eax
00007f0254fdb958  mov eax, 0x410450
00007f0254fdb95d  mov [r15+0x100], rax
00007f0254fdb964  jmp 0x00007F0254DFE110
00007f0254fdb969  cmp dword ptr [r15+0x318], 0x00
00007f0254fdb971  jz 0x00007F0254FDB9A0
00007f0254fdb977  nop [rax+rax*1], ax
00007f0254fdb980  nop [rax+rax*1], eax
00007f0254fdb988  mov eax, 0x410274
00007f0254fdb98d  mov [r15+0x100], rax
00007f0254fdb994  jmp 0x00007F0254DFE110
00007f0254fdb999  int3
00007f0254fdb99a  int3
00007f0254fdb99b  nop [rax+rax*1], eax
00007f0254fdb9a0  mov rax, [r15+0x40]
00007f0254fdb9a4  movaps xmm1, [r15+0x1D0]
00007f0254fdb9ac  vmovaps [rsp+0x10], xmm1
00007f0254fdb9b2  vmovaps xmm15, [rsp+0x10]
00007f0254fdb9b8  por xmm1, xmm15
00007f0254fdb9bd  movaps xmm14, [r15+0x1A0]
00007f0254fdb9c5  vmovaps [rsp+0x10], xmm14
00007f0254fdb9cb  vmovaps xmm13, [rsp+0x10]
00007f0254fdb9d1  por xmm14, xmm13
00007f0254fdb9d6  lea r14, [rax+0x30]
00007f0254fdb9da  mov r12, [r13+r14*1]
00007f0254fdb9df  lea r14, [rax+0x38]
00007f0254fdb9e3  mov r11, [r13+r14*1]
00007f0254fdb9e8  movq xmm13, r12
00007f0254fdb9ed  movq xmm12, r11
00007f0254fdb9f2  movq xmm13, xmm13
00007f0254fdb9f7  vmovaps [rsp+0x10], xmm13
00007f0254fdb9fd  movq xmm13, xmm13
00007f0254fdba02  movaps [r15+0x130], xmm13
00007f0254fdba0a  movq xmm12, xmm12
00007f0254fdba0f  vmovaps [rsp+0x20], xmm12
00007f0254fdba15  movq xmm12, xmm12
00007f0254fdba1a  movaps [r15+0x280], xmm12
00007f0254fdba22  movaps xmm13, [r15+0x270]
00007f0254fdba2a  vmovaps [rsp+0x30], xmm13
00007f0254fdba30  vmovaps xmm12, [rsp+0x30]
00007f0254fdba36  por xmm13, xmm12
00007f0254fdba3b  lea r14, [rax+0x20]
00007f0254fdba3f  mov r12, [r13+r14*1]
00007f0254fdba44  lea r14, [rax+0x28]
00007f0254fdba48  mov r11, [r13+r14*1]
00007f0254fdba4d  movq xmm12, r12
00007f0254fdba52  movq xmm11, r11
00007f0254fdba57  movq xmm12, xmm12
00007f0254fdba5c  vmovaps [rsp+0x30], xmm12
00007f0254fdba62  movq xmm12, xmm12
00007f0254fdba67  movaps [r15+0x150], xmm12
00007f0254fdba6f  movq xmm11, xmm11
00007f0254fdba74  vmovaps [rsp+0x40], xmm11
00007f0254fdba7a  movq xmm11, xmm11
00007f0254fdba7f  movaps [r15+0x140], xmm11
00007f0254fdba87  lea r14, [rax+0x10]
00007f0254fdba8b  mov r12, [r13+r14*1]
00007f0254fdba90  lea r14, [rax+0x18]
00007f0254fdba94  mov r11, [r13+r14*1]
00007f0254fdba99  movq xmm12, r12
00007f0254fdba9e  movq xmm11, r11
00007f0254fdbaa3  movq xmm12, xmm12
00007f0254fdbaa8  vmovaps [rsp+0x50], xmm12
00007f0254fdbaae  movq xmm12, xmm12
00007f0254fdbab3  movaps [r15+0x170], xmm12
00007f0254fdbabb  movq xmm11, xmm11
00007f0254fdbac0  vmovaps [rsp+0x60], xmm11
00007f0254fdbac6  movq xmm11, xmm11
00007f0254fdbacb  movaps [r15+0x160], xmm11
00007f0254fdbad3  mov r14, [r13+rax*1]
00007f0254fdbad8  vmovq xmm12, r14
00007f0254fdbadd  vpbroadcastq xmm12, xmm12
00007f0254fdbae2  lea r14, [rax+0x08]
00007f0254fdbae6  mov rax, [r13+r14*1]
00007f0254fdbaeb  movq xmm11, rax
00007f0254fdbaf0  movaps [r15+0x230], xmm11
00007f0254fdbaf8  mov rax, [r15+0xF8]
00007f0254fdbaff  lea r14, [rax+0x50]
00007f0254fdbb03  movups xmm11, [r13+r14*1]
00007f0254fdbb09  lea r14, [rax+0x60]
00007f0254fdbb0d  movups xmm10, [r13+r14*1]
00007f0254fdbb13  lea r14, [rax+0x30]
00007f0254fdbb17  movups xmm9, [r13+r14*1]
00007f0254fdbb1d  mov r14, [r15+0x50]
00007f0254fdbb21  mov [r15+0x60], r14
00007f0254fdbb25  mov qword ptr [r15+0x58], 0x40
00007f0254fdbb2d  movaps xmm8, xmm12
00007f0254fdbb31  mulpd xmm8, xmm15
00007f0254fdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007f0254fdbb3c  ptest xmm7, xmm7
00007f0254fdbb41  jnz 0x00007F0254FDC96A
00007f0254fdbb47  movq xmm15, qword ptr [r15+0x230]
00007f0254fdbb50  vmovaps [rsp+0x70], xmm15
00007f0254fdbb56  vpermilpd xmm15, xmm15, 0x00
00007f0254fdbb5c  movaps xmm7, xmm9
00007f0254fdbb60  mulpd xmm7, xmm15
00007f0254fdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0254fdbb6a  ptest xmm6, xmm6
00007f0254fdbb6f  jnz 0x00007F0254FDCAAE
00007f0254fdbb75  vxorps xmm15, xmm15, xmm15
00007f0254fdbb7a  vpbroadcastq xmm15, xmm15
00007f0254fdbb7f  movaps xmm9, xmm12
00007f0254fdbb83  mulpd xmm9, xmm10
00007f0254fdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007f0254fdbb8e  ptest xmm6, xmm6
00007f0254fdbb93  jnz 0x00007F0254FDCBF0
00007f0254fdbb99  movaps xmm10, xmm12
00007f0254fdbb9d  mulpd xmm10, xmm11
00007f0254fdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007f0254fdbba8  ptest xmm6, xmm6
00007f0254fdbbad  jnz 0x00007F0254FDCD34
00007f0254fdbbb3  movaps xmm11, [r15+0x1F0]
00007f0254fdbbbb  movaps xmm6, xmm12
00007f0254fdbbbf  mulpd xmm6, xmm11
00007f0254fdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007f0254fdbbc9  ptest xmm5, xmm5
00007f0254fdbbce  jnz 0x00007F0254FDCE78
00007f0254fdbbd4  movaps xmm12, [r15+0x2A0]
00007f0254fdbbdc  vmovaps [rsp+0x80], xmm12
00007f0254fdbbe5  vmovaps xmm11, [rsp+0x80]
00007f0254fdbbee  por xmm12, xmm11
00007f0254fdbbf3  movaps xmm11, [r15+0x250]
00007f0254fdbbfb  vmovaps [rsp+0x80], xmm11
00007f0254fdbc04  vmovaps xmm5, [rsp+0x80]
00007f0254fdbc0d  por xmm11, xmm5
00007f0254fdbc12  vmovaps xmm4, [rsp+0x70]
00007f0254fdbc18  vpermilpd xmm4, xmm4, 0x00
00007f0254fdbc1e  movaps xmm3, xmm5
00007f0254fdbc21  mulpd xmm3, xmm4
00007f0254fdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007f0254fdbc2a  ptest xmm2, xmm2
00007f0254fdbc2f  jnz 0x00007F0254FDCFBA
00007f0254fdbc35  mov [rsp+0x80], rax
00007f0254fdbc3d  xor eax, eax
00007f0254fdbc3f  mov r12d, 0x40
00007f0254fdbc45  mov r11d, 0x200
00007f0254fdbc4b  cmp r12, r11
00007f0254fdbc4e  cmc
00007f0254fdbc4f  lahf
00007f0254fdbc50  seto al
00007f0254fdbc53  mov [r15+0x108], eax
00007f0254fdbc5a  movaps xmm5, xmm8
00007f0254fdbc5e  addpd xmm5, xmm15
00007f0254fdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007f0254fdbc68  ptest xmm4, xmm4
00007f0254fdbc6d  jnz 0x00007F0254FDD0FA
00007f0254fdbc73  movaps xmm8, [r15+0x1B0]
00007f0254fdbc7b  movaps xmm4, xmm9
00007f0254fdbc7f  addpd xmm4, xmm8
00007f0254fdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007f0254fdbc89  ptest xmm2, xmm2
00007f0254fdbc8e  jnz 0x00007F0254FDD23C
00007f0254fdbc94  movaps xmm9, xmm10
00007f0254fdbc98  addpd xmm9, xmm8
00007f0254fdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007f0254fdbca3  ptest xmm2, xmm2
00007f0254fdbca8  jnz 0x00007F0254FDD37E
00007f0254fdbcae  movaps xmm10, [r15+0x2F0]
00007f0254fdbcb6  vmovaps [rsp+0x90], xmm10
00007f0254fdbcbf  vmovaps xmm8, [rsp+0x90]
00007f0254fdbcc8  por xmm10, xmm8
00007f0254fdbccd  movaps xmm8, [r15+0x2E0]
00007f0254fdbcd5  vmovaps [rsp+0x90], xmm8
00007f0254fdbcde  vmovaps xmm2, [rsp+0x90]
00007f0254fdbce7  por xmm8, xmm2
00007f0254fdbcec  movaps xmm2, [r15+0x2D0]
00007f0254fdbcf4  vmovaps [rsp+0x90], xmm2
00007f0254fdbcfd  vmovaps [rsp+0xA0], xmm1
00007f0254fdbd06  vmovaps xmm1, [rsp+0x90]
00007f0254fdbd0f  por xmm2, xmm1
00007f0254fdbd13  movaps xmm1, [r15+0x200]
00007f0254fdbd1b  vmovaps [rsp+0x90], xmm1
00007f0254fdbd24  vmovaps [rsp+0xB0], xmm15
00007f0254fdbd2d  vmovaps xmm15, [rsp+0x90]
00007f0254fdbd36  por xmm1, xmm15
00007f0254fdbd3b  movaps xmm15, [r15+0x1C0]
00007f0254fdbd43  vmovaps [rsp+0x90], xmm15
00007f0254fdbd4c  vmovaps [rsp+0xC0], xmm1
00007f0254fdbd55  vmovaps xmm1, [rsp+0x90]
00007f0254fdbd5e  por xmm15, xmm1
00007f0254fdbd63  movaps xmm1, [r15+0x190]
00007f0254fdbd6b  vmovaps [rsp+0x90], xmm1
00007f0254fdbd74  vmovaps [rsp+0xD0], xmm15
00007f0254fdbd7d  vmovaps xmm15, [rsp+0x90]
00007f0254fdbd86  por xmm1, xmm15
00007f0254fdbd8b  movaps xmm15, [r15+0x300]
00007f0254fdbd93  vmovaps [rsp+0x90], xmm15
00007f0254fdbd9c  vmovaps [rsp+0xE0], xmm1
00007f0254fdbda5  vmovaps xmm1, [rsp+0x90]
00007f0254fdbdae  por xmm15, xmm1
00007f0254fdbdb3  mov rax, [rsp+0x80]
00007f0254fdbdbb  lea r12, [rax+0xA0]
00007f0254fdbdc2  movups xmm1, [r13+r12*1]
00007f0254fdbdc8  lea r12, [rax+0xB0]
00007f0254fdbdcf  vmovaps [rsp+0x80], xmm1
00007f0254fdbdd8  movups xmm1, [r13+r12*1]
00007f0254fdbdde  vmovaps [rsp+0x90], xmm1
00007f0254fdbde7  vmovaps [rsp+0xF0], xmm15
00007f0254fdbdf0  vmovaps xmm15, [rsp+0xB0]
00007f0254fdbdf9  vmovaps [rsp+0xB0], xmm14
00007f0254fdbe02  movaps xmm1, xmm6
00007f0254fdbe05  addpd xmm1, xmm15
00007f0254fdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007f0254fdbe0f  ptest xmm14, xmm14
00007f0254fdbe15  jnz 0x00007F0254FDD4D6
00007f0254fdbe1b  lea r12, [rax+0xF0]
00007f0254fdbe22  movups xmm15, [r13+r12*1]
00007f0254fdbe28  movaps xmm14, xmm4
00007f0254fdbe2c  addpd xmm14, xmm3
00007f0254fdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007f0254fdbe37  ptest xmm6, xmm6
00007f0254fdbe3c  jnz 0x00007F0254FDD621
00007f0254fdbe42  movaps xmm6, xmm9
00007f0254fdbe46  addpd xmm6, xmm7
00007f0254fdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007f0254fdbe4f  ptest xmm4, xmm4
00007f0254fdbe54  jnz 0x00007F0254FDD763
00007f0254fdbe5a  vmovaps xmm9, [rsp+0x70]
00007f0254fdbe60  vpermilpd xmm9, xmm9, 0x00
00007f0254fdbe66  vmovaps xmm4, [rsp+0x90]
00007f0254fdbe6f  movaps xmm7, xmm4
00007f0254fdbe72  mulpd xmm7, xmm9
00007f0254fdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007f0254fdbe7c  ptest xmm3, xmm3
00007f0254fdbe81  jnz 0x00007F0254FDD8A4
00007f0254fdbe87  vmovaps xmm9, [rsp+0x50]
00007f0254fdbe8d  vpermilpd xmm9, xmm9, 0x00
00007f0254fdbe93  movaps xmm4, xmm15
00007f0254fdbe97  mulpd xmm4, xmm9
00007f0254fdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007f0254fdbea1  ptest xmm3, xmm3
00007f0254fdbea6  jnz 0x00007F0254FDD9E5
00007f0254fdbeac  lea r12, [rax+0xE0]
00007f0254fdbeb3  movups xmm15, [r13+r12*1]
00007f0254fdbeb9  vmovaps xmm9, [rsp+0x70]
00007f0254fdbebf  vpermilpd xmm9, xmm9, 0x00
00007f0254fdbec5  vmovaps [rsp+0x70], xmm1
00007f0254fdbecb  vmovaps xmm1, [rsp+0x80]
00007f0254fdbed4  vmovaps [rsp+0x80], xmm15
00007f0254fdbedd  movaps xmm3, xmm1
00007f0254fdbee0  mulpd xmm3, xmm9
00007f0254fdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007f0254fdbeea  ptest xmm15, xmm15
00007f0254fdbef0  jnz 0x00007F0254FDDB31
00007f0254fdbef6  vmovaps xmm1, [rsp+0xF0]
00007f0254fdbeff  vmovaps xmm15, [rsp+0xF0]
00007f0254fdbf08  por xmm1, xmm15
00007f0254fdbf0d  movaps [r15+0x300], xmm1
00007f0254fdbf15  vmovaps xmm15, [rsp+0xE0]
00007f0254fdbf1e  vmovaps xmm9, [rsp+0xE0]
00007f0254fdbf27  por xmm15, xmm9
00007f0254fdbf2c  movaps [r15+0x190], xmm15
00007f0254fdbf34  vmovaps xmm9, [rsp+0x50]
00007f0254fdbf3a  vpermilpd xmm9, xmm9, 0x00
00007f0254fdbf40  vmovaps [rsp+0x90], xmm1
00007f0254fdbf49  vmovaps [rsp+0xE0], xmm15
00007f0254fdbf52  vmovaps xmm15, [rsp+0x80]
00007f0254fdbf5b  vmovaps [rsp+0x80], xmm14
00007f0254fdbf64  movaps xmm1, xmm15
00007f0254fdbf68  mulpd xmm1, xmm9
00007f0254fdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007f0254fdbf72  ptest xmm14, xmm14
00007f0254fdbf78  jnz 0x00007F0254FDDC72
00007f0254fdbf7e  lea r12, [rax+0x90]
00007f0254fdbf85  movups xmm15, [r13+r12*1]
00007f0254fdbf8b  vmovaps xmm14, [rsp+0xD0]
00007f0254fdbf94  vmovaps xmm9, [rsp+0xD0]
00007f0254fdbf9d  por xmm14, xmm9
00007f0254fdbfa2  movaps [r15+0x1C0], xmm14
00007f0254fdbfaa  vmovaps xmm9, [rsp+0xC0]
00007f0254fdbfb3  vmovaps [rsp+0xD0], xmm1
00007f0254fdbfbc  vmovaps xmm1, [rsp+0xC0]
00007f0254fdbfc5  por xmm9, xmm1
00007f0254fdbfca  movaps [r15+0x200], xmm9
00007f0254fdbfd2  vmovaps [rsp+0xC0], xmm2
00007f0254fdbfdb  vmovaps xmm1, [rsp+0xC0]
00007f0254fdbfe4  por xmm2, xmm1
00007f0254fdbfe8  movaps [r15+0x2D0], xmm2
00007f0254fdbff0  vmovaps [rsp+0xC0], xmm8
00007f0254fdbff9  vmovaps xmm1, [rsp+0xC0]
00007f0254fdc002  por xmm8, xmm1
00007f0254fdc007  movaps [r15+0x2E0], xmm8
00007f0254fdc00f  vmovaps [rsp+0xC0], xmm15
00007f0254fdc018  movaps xmm1, xmm5
00007f0254fdc01b  addpd xmm1, xmm7
00007f0254fdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007f0254fdc024  ptest xmm15, xmm15
00007f0254fdc02a  jnz 0x00007F0254FDDDBE
00007f0254fdc030  vmovaps xmm15, [rsp+0x50]
00007f0254fdc036  vpermilpd xmm15, xmm15, 0x00
00007f0254fdc03c  vmovaps xmm5, [rsp+0xC0]
00007f0254fdc045  vmovaps [rsp+0xC0], xmm1
00007f0254fdc04e  movaps xmm7, xmm5
00007f0254fdc051  mulpd xmm7, xmm15
00007f0254fdc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007f0254fdc05b  ptest xmm1, xmm1
00007f0254fdc060  jnz 0x00007F0254FDDEFE
00007f0254fdc066  lea r12, [rax+0x80]
00007f0254fdc06d  movups xmm1, [r13+r12*1]
00007f0254fdc073  vmovaps xmm5, [rsp+0x70]
00007f0254fdc079  vmovaps [rsp+0x70], xmm1
00007f0254fdc07f  movaps xmm15, xmm5
00007f0254fdc083  addpd xmm15, xmm3
00007f0254fdc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0254fdc08e  ptest xmm1, xmm1
00007f0254fdc093  jnz 0x00007F0254FDE049
00007f0254fdc099  vmovaps xmm5, [rsp+0x80]
00007f0254fdc0a2  movaps xmm1, xmm5
00007f0254fdc0a5  addpd xmm1, xmm4
00007f0254fdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007f0254fdc0ae  ptest xmm3, xmm3
00007f0254fdc0b3  jnz 0x00007F0254FDE18B
00007f0254fdc0b9  vmovaps [rsp+0x80], xmm10
00007f0254fdc0c2  vmovaps xmm5, [rsp+0x80]
00007f0254fdc0cb  por xmm10, xmm5
00007f0254fdc0d0  movaps [r15+0x2F0], xmm10
00007f0254fdc0d8  vmovaps xmm5, [rsp+0x50]
00007f0254fdc0de  vpermilpd xmm5, xmm5, 0x00
00007f0254fdc0e4  vmovaps xmm3, [rsp+0x70]
00007f0254fdc0ea  vmovaps [rsp+0x50], xmm1
00007f0254fdc0f0  movaps xmm4, xmm3
00007f0254fdc0f3  mulpd xmm4, xmm5
00007f0254fdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007f0254fdc0fc  ptest xmm1, xmm1
00007f0254fdc101  jnz 0x00007F0254FDE2CB
00007f0254fdc107  lea r12, [rax+0xD0]
00007f0254fdc10e  movups xmm1, [r13+r12*1]
00007f0254fdc114  vmovaps xmm3, [rsp+0xD0]
00007f0254fdc11d  vmovaps [rsp+0x70], xmm1
00007f0254fdc123  movaps xmm5, xmm6
00007f0254fdc126  addpd xmm5, xmm3
00007f0254fdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007f0254fdc12f  ptest xmm1, xmm1
00007f0254fdc134  jnz 0x00007F0254FDE415
00007f0254fdc13a  vmovaps xmm1, [rsp+0x60]
00007f0254fdc140  vpermilpd xmm1, xmm1, 0x00
00007f0254fdc146  movaps xmm6, xmm9
00007f0254fdc14a  mulpd xmm6, xmm1
00007f0254fdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007f0254fdc153  ptest xmm3, xmm3
00007f0254fdc158  jnz 0x00007F0254FDE555
00007f0254fdc15e  movaps [r15+0x260], xmm6
00007f0254fdc166  vxorps xmm1, xmm1, xmm1
00007f0254fdc16a  vpbroadcastq xmm1, xmm1
00007f0254fdc16f  movaps [r15+0x1B0], xmm1
00007f0254fdc177  vmovaps xmm1, [rsp+0x60]
00007f0254fdc17d  vpermilpd xmm1, xmm1, 0x00
00007f0254fdc183  vmovaps xmm3, [rsp+0x70]
00007f0254fdc189  vmovaps [rsp+0x70], xmm15
00007f0254fdc18f  movaps xmm9, xmm3
00007f0254fdc193  mulpd xmm9, xmm1
00007f0254fdc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007f0254fdc19e  ptest xmm15, xmm15
00007f0254fdc1a4  jnz 0x00007F0254FDE696
00007f0254fdc1aa  lea r12, [rax+0xC0]
00007f0254fdc1b1  movups xmm1, [r13+r12*1]
00007f0254fdc1b7  vmovaps xmm3, [rsp+0xC0]
00007f0254fdc1c0  vmovaps [rsp+0x80], xmm1
00007f0254fdc1c9  movaps xmm15, xmm3
00007f0254fdc1cd  addpd xmm15, xmm7
00007f0254fdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0254fdc1d8  ptest xmm1, xmm1
00007f0254fdc1dd  jnz 0x00007F0254FDE7E2
00007f0254fdc1e3  vmovaps [rsp+0xC0], xmm13
00007f0254fdc1ec  vmovaps xmm1, [rsp+0xC0]
00007f0254fdc1f5  por xmm13, xmm1
00007f0254fdc1fa  movaps [r15+0x270], xmm13
00007f0254fdc202  vmovaps xmm1, [rsp+0xB0]
00007f0254fdc20b  vmovaps xmm7, [rsp+0xB0]
00007f0254fdc214  por xmm1, xmm7
00007f0254fdc218  movaps [r15+0x1A0], xmm1
00007f0254fdc220  vmovaps xmm1, [rsp+0x60]
00007f0254fdc226  vpermilpd xmm1, xmm1, 0x00
00007f0254fdc22c  vmovaps [rsp+0xB0], xmm1
00007f0254fdc235  vmovaps xmm1, [rsp+0x80]
00007f0254fdc23e  vmovaps [rsp+0x80], xmm15
00007f0254fdc247  vmovaps xmm15, [rsp+0xB0]
00007f0254fdc250  vmovaps [rsp+0xB0], xmm14
00007f0254fdc259  movaps xmm3, xmm1
00007f0254fdc25c  mulpd xmm3, xmm15
00007f0254fdc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007f0254fdc266  ptest xmm14, xmm14
00007f0254fdc26c  jnz 0x00007F0254FDE924
00007f0254fdc272  lea r12, [rax+0x20]
00007f0254fdc276  movups xmm1, [r13+r12*1]
00007f0254fdc27c  movaps [r15+0x110], xmm1
00007f0254fdc284  vmovaps xmm14, [rsp+0x70]
00007f0254fdc28a  vmovaps [rsp+0x70], xmm1
00007f0254fdc290  movaps xmm15, xmm14
00007f0254fdc294  addpd xmm15, xmm4
00007f0254fdc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0254fdc29f  ptest xmm1, xmm1
00007f0254fdc2a4  jnz 0x00007F0254FDEA6F
00007f0254fdc2aa  vmovaps xmm1, [rsp+0x60]
00007f0254fdc2b0  vpermilpd xmm1, xmm1, 0x00
00007f0254fdc2b6  movaps xmm14, xmm2
00007f0254fdc2ba  mulpd xmm14, xmm1
00007f0254fdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007f0254fdc2c5  ptest xmm4, xmm4
00007f0254fdc2ca  jnz 0x00007F0254FDEBB2
00007f0254fdc2d0  vmovaps xmm4, [rsp+0x50]
00007f0254fdc2d6  movaps xmm1, xmm4
00007f0254fdc2d9  addpd xmm1, xmm9
00007f0254fdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007f0254fdc2e3  ptest xmm2, xmm2
00007f0254fdc2e8  jnz 0x00007F0254FDECF4
00007f0254fdc2ee  vmovaps xmm9, [rsp+0x30]
00007f0254fdc2f4  vpermilpd xmm9, xmm9, 0x00
00007f0254fdc2fa  vmovaps xmm2, [rsp+0x70]
00007f0254fdc300  vmovaps [rsp+0x50], xmm1
00007f0254fdc306  movaps xmm4, xmm2
00007f0254fdc309  mulpd xmm4, xmm9
00007f0254fdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007f0254fdc313  ptest xmm1, xmm1
00007f0254fdc318  jnz 0x00007F0254FDEE35
00007f0254fdc31e  vmovaps xmm1, [rsp+0x30]
00007f0254fdc324  vpermilpd xmm1, xmm1, 0x00
00007f0254fdc32a  vmovaps xmm2, [rsp+0x90]
00007f0254fdc333  vmovaps [rsp+0x60], xmm15
00007f0254fdc339  movaps xmm9, xmm2
00007f0254fdc33d  mulpd xmm9, xmm1
00007f0254fdc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007f0254fdc348  ptest xmm15, xmm15
00007f0254fdc34e  jnz 0x00007F0254FDEF76
00007f0254fdc354  vmovaps xmm15, [rsp+0x80]
00007f0254fdc35d  movaps xmm1, xmm15
00007f0254fdc361  addpd xmm1, xmm6
00007f0254fdc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007f0254fdc36a  ptest xmm2, xmm2
00007f0254fdc36f  jnz 0x00007F0254FDF0B8
00007f0254fdc375  movaps xmm15, xmm5
00007f0254fdc379  addpd xmm15, xmm3
00007f0254fdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007f0254fdc384  ptest xmm6, xmm6
00007f0254fdc389  jnz 0x00007F0254FDF1F9
00007f0254fdc38f  vmovaps xmm6, [rsp+0x30]
00007f0254fdc395  vpermilpd xmm6, xmm6, 0x00
00007f0254fdc39b  movaps xmm5, xmm8
00007f0254fdc39f  mulpd xmm5, xmm6
00007f0254fdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007f0254fdc3a8  ptest xmm3, xmm3
00007f0254fdc3ad  jnz 0x00007F0254FDF33B
00007f0254fdc3b3  vmovaps xmm8, [rsp+0x30]
00007f0254fdc3b9  vpermilpd xmm8, xmm8, 0x00
00007f0254fdc3bf  movaps xmm6, xmm10
00007f0254fdc3c3  mulpd xmm6, xmm8
00007f0254fdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007f0254fdc3cd  ptest xmm3, xmm3
00007f0254fdc3d2  jnz 0x00007F0254FDF47C
00007f0254fdc3d8  vmovaps xmm8, [rsp+0x60]
00007f0254fdc3de  movaps xmm10, xmm8
00007f0254fdc3e2  addpd xmm10, xmm14
00007f0254fdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007f0254fdc3ed  ptest xmm3, xmm3
00007f0254fdc3f2  jnz 0x00007F0254FDF5BE
00007f0254fdc3f8  vmovaps xmm8, [rsp+0x50]
00007f0254fdc3fe  movaps xmm14, xmm8
00007f0254fdc402  addpd xmm14, xmm4
00007f0254fdc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007f0254fdc40d  ptest xmm3, xmm3
00007f0254fdc412  jnz 0x00007F0254FDF702
00007f0254fdc418  vmovaps xmm8, [rsp+0x40]
00007f0254fdc41e  vpermilpd xmm8, xmm8, 0x00
00007f0254fdc424  movaps xmm4, xmm13
00007f0254fdc428  mulpd xmm4, xmm8
00007f0254fdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007f0254fdc432  ptest xmm3, xmm3
00007f0254fdc437  jnz 0x00007F0254FDF845
00007f0254fdc43d  movaps xmm13, xmm15
00007f0254fdc441  addpd xmm13, xmm9
00007f0254fdc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007f0254fdc44c  ptest xmm8, xmm8
00007f0254fdc452  jnz 0x00007F0254FDF987
00007f0254fdc458  movaps xmm15, xmm1
00007f0254fdc45c  addpd xmm15, xmm5
00007f0254fdc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007f0254fdc467  ptest xmm9, xmm9
00007f0254fdc46d  jnz 0x00007F0254FDFACB
00007f0254fdc473  vmovaps [rsp+0x30], xmm11
00007f0254fdc479  vmovaps xmm1, [rsp+0x30]
00007f0254fdc47f  por xmm11, xmm1
00007f0254fdc484  movaps [r15+0x250], xmm11
00007f0254fdc48c  vmovaps [rsp+0x30], xmm12
00007f0254fdc492  vmovaps xmm1, [rsp+0x30]
00007f0254fdc498  por xmm12, xmm1
00007f0254fdc49d  movaps [r15+0x2A0], xmm12
00007f0254fdc4a5  vmovaps xmm1, [rsp+0xA0]
00007f0254fdc4ae  vmovaps xmm11, [rsp+0xA0]
00007f0254fdc4b7  por xmm1, xmm11
00007f0254fdc4bc  movaps [r15+0x1D0], xmm1
00007f0254fdc4c4  lea r12, [rax+0x40]
00007f0254fdc4c8  movups xmm1, [r13+r12*1]
00007f0254fdc4ce  movaps [r15+0x2C0], xmm1
00007f0254fdc4d6  vmovaps xmm11, [rsp+0x40]
00007f0254fdc4dc  vpermilpd xmm11, xmm11, 0x00
00007f0254fdc4e2  vmovaps xmm8, [rsp+0xE0]
00007f0254fdc4eb  movaps xmm9, xmm8
00007f0254fdc4ef  mulpd xmm9, xmm11
00007f0254fdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007f0254fdc4fa  ptest xmm5, xmm5
00007f0254fdc4ff  jnz 0x00007F0254FDFC17
00007f0254fdc505  movaps xmm11, xmm10
00007f0254fdc509  addpd xmm11, xmm6
00007f0254fdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007f0254fdc514  ptest xmm8, xmm8
00007f0254fdc51a  jnz 0x00007F0254FDFD5B
00007f0254fdc520  movaps xmm10, xmm14
00007f0254fdc524  addpd xmm10, xmm4
00007f0254fdc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007f0254fdc52f  ptest xmm8, xmm8
00007f0254fdc535  jnz 0x00007F0254FDFE9E
00007f0254fdc53b  vmovaps xmm14, [rsp+0x40]
00007f0254fdc541  vpermilpd xmm14, xmm14, 0x00
00007f0254fdc547  movaps xmm8, xmm1
00007f0254fdc54b  mulpd xmm8, xmm14
00007f0254fdc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007f0254fdc556  ptest xmm6, xmm6
00007f0254fdc55b  jnz 0x00007F0254FDFFE1
00007f0254fdc561  movaps xmm1, [r15+0x2B0]
00007f0254fdc569  vmovaps xmm14, [rsp+0x40]
00007f0254fdc56f  vpermilpd xmm14, xmm14, 0x00
00007f0254fdc575  movaps xmm6, xmm1
00007f0254fdc578  mulpd xmm6, xmm14
00007f0254fdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007f0254fdc582  ptest xmm5, xmm5
00007f0254fdc587  jnz 0x00007F0254FE0124
00007f0254fdc58d  vmovaps xmm1, [rsp+0x10]
00007f0254fdc593  vpermilpd xmm1, xmm1, 0x00
00007f0254fdc599  movaps xmm14, xmm12
00007f0254fdc59d  mulpd xmm14, xmm1
00007f0254fdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007f0254fdc5a8  ptest xmm5, xmm5
00007f0254fdc5ad  jnz 0x00007F0254FE0265
00007f0254fdc5b3  movaps xmm1, xmm13
00007f0254fdc5b7  addpd xmm1, xmm9
00007f0254fdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007f0254fdc5c1  ptest xmm12, xmm12
00007f0254fdc5c7  jnz 0x00007F0254FE03A8
00007f0254fdc5cd  vmovaps xmm13, [rsp+0x10]
00007f0254fdc5d3  vpermilpd xmm13, xmm13, 0x00
00007f0254fdc5d9  movaps xmm12, xmm7
00007f0254fdc5dd  mulpd xmm12, xmm13
00007f0254fdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007f0254fdc5e8  ptest xmm9, xmm9
00007f0254fdc5ee  jnz 0x00007F0254FE04EA
00007f0254fdc5f4  movaps xmm13, xmm15
00007f0254fdc5f8  addpd xmm13, xmm8
00007f0254fdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007f0254fdc603  ptest xmm9, xmm9
00007f0254fdc609  jnz 0x00007F0254FE062D
00007f0254fdc60f  movaps xmm15, [r15+0x290]
00007f0254fdc617  vmovaps xmm9, [rsp+0x10]
00007f0254fdc61d  vpermilpd xmm9, xmm9, 0x00
00007f0254fdc623  movaps xmm8, xmm15
00007f0254fdc627  mulpd xmm8, xmm9
00007f0254fdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007f0254fdc632  ptest xmm7, xmm7
00007f0254fdc637  jnz 0x00007F0254FE0771
00007f0254fdc63d  movaps xmm15, xmm11
00007f0254fdc641  addpd xmm15, xmm6
00007f0254fdc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007f0254fdc64c  ptest xmm9, xmm9
00007f0254fdc652  jnz 0x00007F0254FE08B5
00007f0254fdc658  movaps xmm11, [r15+0x1E0]
00007f0254fdc660  vmovaps xmm9, [rsp+0x10]
00007f0254fdc666  vpermilpd xmm9, xmm9, 0x00
00007f0254fdc66c  movaps xmm7, xmm11
00007f0254fdc670  mulpd xmm7, xmm9
00007f0254fdc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0254fdc67a  ptest xmm6, xmm6
00007f0254fdc67f  jnz 0x00007F0254FE09F8
00007f0254fdc685  movaps xmm11, xmm10
00007f0254fdc689  addpd xmm11, xmm14
00007f0254fdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007f0254fdc694  ptest xmm9, xmm9
00007f0254fdc69a  jnz 0x00007F0254FE0B3A
00007f0254fdc6a0  lea r12, [rax+0x70]
00007f0254fdc6a4  movups xmm14, [r13+r12*1]
00007f0254fdc6aa  movaps [r15+0x240], xmm14
00007f0254fdc6b2  movaps xmm10, xmm1
00007f0254fdc6b6  addpd xmm10, xmm12
00007f0254fdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007f0254fdc6c1  ptest xmm9, xmm9
00007f0254fdc6c7  jnz 0x00007F0254FE0C88
00007f0254fdc6cd  movaps [r15+0x170], xmm10
00007f0254fdc6d5  vmovaps xmm1, [rsp+0x20]
00007f0254fdc6db  vpermilpd xmm1, xmm1, 0x00
00007f0254fdc6e1  movaps xmm12, xmm14
00007f0254fdc6e5  mulpd xmm12, xmm1
00007f0254fdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007f0254fdc6f0  ptest xmm9, xmm9
00007f0254fdc6f6  jnz 0x00007F0254FE0DCB
00007f0254fdc6fc  vmovaps xmm1, [rsp+0x20]
00007f0254fdc702  vpermilpd xmm1, xmm1, 0x00
00007f0254fdc708  vmovaps xmm9, [rsp+0xB0]
00007f0254fdc711  movaps xmm14, xmm9
00007f0254fdc715  mulpd xmm14, xmm1
00007f0254fdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007f0254fdc720  ptest xmm6, xmm6
00007f0254fdc725  jnz 0x00007F0254FE0F0E
00007f0254fdc72b  movaps [r15+0x180], xmm14
00007f0254fdc733  movaps xmm1, xmm13
00007f0254fdc737  addpd xmm1, xmm8
00007f0254fdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007f0254fdc741  ptest xmm9, xmm9
00007f0254fdc747  jnz 0x00007F0254FE1051
00007f0254fdc74d  movaps [r15+0x210], xmm1
00007f0254fdc755  movups xmm13, [r13+rax*1]
00007f0254fdc75b  lea r12, [rax+0x10]
00007f0254fdc75f  movups xmm9, [r13+r12*1]
00007f0254fdc765  movaps [r15+0x230], xmm9
00007f0254fdc76d  movaps xmm8, xmm15
00007f0254fdc771  addpd xmm8, xmm7
00007f0254fdc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007f0254fdc77c  ptest xmm6, xmm6
00007f0254fdc781  jnz 0x00007F0254FE11A7
00007f0254fdc787  movaps [r15+0x130], xmm8
00007f0254fdc78f  vmovaps xmm15, [rsp+0x20]
00007f0254fdc795  vpermilpd xmm15, xmm15, 0x00
00007f0254fdc79b  movaps xmm7, xmm9
00007f0254fdc79f  mulpd xmm7, xmm15
00007f0254fdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0254fdc7a9  ptest xmm6, xmm6
00007f0254fdc7ae  jnz 0x00007F0254FE12EA
00007f0254fdc7b4  movaps [r15+0x220], xmm7
00007f0254fdc7bc  vmovaps xmm15, [rsp+0x20]
00007f0254fdc7c2  vpermilpd xmm15, xmm15, 0x00
00007f0254fdc7c8  movaps xmm9, xmm13
00007f0254fdc7cc  mulpd xmm9, xmm15
00007f0254fdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007f0254fdc7d7  ptest xmm6, xmm6
00007f0254fdc7dc  jnz 0x00007F0254FE142C
00007f0254fdc7e2  movaps xmm15, xmm11
00007f0254fdc7e6  addpd xmm15, xmm12
00007f0254fdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007f0254fdc7f1  ptest xmm13, xmm13
00007f0254fdc7f7  jnz 0x00007F0254FE1570
00007f0254fdc7fd  movaps [r15+0x140], xmm15
00007f0254fdc805  movaps xmm13, xmm10
00007f0254fdc809  addpd xmm13, xmm14
00007f0254fdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007f0254fdc814  ptest xmm12, xmm12
00007f0254fdc81a  jnz 0x00007F0254FE16B4
00007f0254fdc820  movaps [r15+0x150], xmm13
00007f0254fdc828  movaps xmm14, xmm1
00007f0254fdc82c  addpd xmm14, xmm7
00007f0254fdc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007f0254fdc837  ptest xmm12, xmm12
00007f0254fdc83d  jnz 0x00007F0254FE17F8
00007f0254fdc843  movaps [r15+0x160], xmm14
00007f0254fdc84b  movaps xmm1, xmm8
00007f0254fdc84f  addpd xmm1, xmm9
00007f0254fdc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007f0254fdc859  ptest xmm12, xmm12
00007f0254fdc85f  jnz 0x00007F0254FE193A
00007f0254fdc865  movaps [r15+0x120], xmm1
00007f0254fdc86d  movups [r13+r14*1], xmm15
00007f0254fdc873  lea rax, [r14+0x10]
00007f0254fdc877  movups [r13+rax*1], xmm13
00007f0254fdc87d  lea rax, [r14+0x20]
00007f0254fdc881  movups [r13+rax*1], xmm14
00007f0254fdc887  lea rax, [r14+0x30]
00007f0254fdc88b  movups [r13+rax*1], xmm1
00007f0254fdc891  mov eax, [r15+0x108]
00007f0254fdc898  sahf
00007f0254fdc899  jnz 0x00007F0254FDC8CB
00007f0254fdc89b  cmp dword ptr [r15+0x318], 0x00
00007f0254fdc8a3  jz 0x00007F0254FDB900
00007f0254fdc8a9  nop [rax+rax*1], ax
00007f0254fdc8b2  nop [rax+rax*1], eax
00007f0254fdc8ba  mov eax, 0x410444
00007f0254fdc8bf  mov [r15+0x100], rax
00007f0254fdc8c6  jmp 0x00007F0254DFE110
00007f0254fdc8cb  cmp dword ptr [r15+0x318], 0x00
00007f0254fdc8d3  jz 0x00007F0254FD57E0
00007f0254fdc8d9  nop [rax+rax*1], ax
00007f0254fdc8e2  nop [rax+rax*1], eax
00007f0254fdc8ea  mov eax, 0x410278
00007f0254fdc8ef  mov [r15+0x100], rax
00007f0254fdc8f6  jmp 0x00007F0254DFE110
00007f0254fdc8fb  int3
00007f0254fdc8fc  call 0x00007F0254EE27E0
00007f0254fdc901  jmp 0x00007F0254FDB9DF
00007f0254fdc906  call 0x00007F0254EE1570
00007f0254fdc90b  jmp 0x00007F0254FDB9E8
00007f0254fdc910  call 0x00007F0254EE27E0
00007f0254fdc915  jmp 0x00007F0254FDBA44
00007f0254fdc91a  call 0x00007F0254EE1570
00007f0254fdc91f  jmp 0x00007F0254FDBA4D
00007f0254fdc924  call 0x00007F0254EE27E0
00007f0254fdc929  jmp 0x00007F0254FDBA90
00007f0254fdc92e  call 0x00007F0254EE1570
00007f0254fdc933  jmp 0x00007F0254FDBA99
00007f0254fdc938  call 0x00007F0254E0DC20
00007f0254fdc93d  jmp 0x00007F0254FDBAD8
00007f0254fdc942  call 0x00007F0254ED59C0
00007f0254fdc947  jmp 0x00007F0254FDBAEB
00007f0254fdc94c  call 0x00007F0254EE0E30
00007f0254fdc951  jmp 0x00007F0254FDBB09
00007f0254fdc956  call 0x00007F0254EDFBC0
00007f0254fdc95b  jmp 0x00007F0254FDBB13
00007f0254fdc960  call 0x00007F0254EDE950
00007f0254fdc965  jmp 0x00007F0254FDBB1D
00007f0254fdc96a  sub rsp, 0x08
00007f0254fdc96e  push rax
00007f0254fdc96f  push rcx
00007f0254fdc970  push rdx
00007f0254fdc971  push rdi
00007f0254fdc972  push rsi
00007f0254fdc973  push r8
00007f0254fdc975  push r9
00007f0254fdc977  push r10
00007f0254fdc979  push r11
00007f0254fdc97b  sub rsp, 0xF0
00007f0254fdc982  vmovaps [rsp], xmm0
00007f0254fdc987  vmovaps [rsp+0x10], xmm1
00007f0254fdc98d  vmovaps [rsp+0x20], xmm2
00007f0254fdc993  vmovaps [rsp+0x30], xmm3
00007f0254fdc999  vmovaps [rsp+0x40], xmm4
00007f0254fdc99f  vmovaps [rsp+0x50], xmm5
00007f0254fdc9a5  vmovaps [rsp+0x60], xmm6
00007f0254fdc9ab  vmovaps [rsp+0x70], xmm7
00007f0254fdc9b1  vmovaps [rsp+0x80], xmm9
00007f0254fdc9ba  vmovaps [rsp+0x90], xmm10
00007f0254fdc9c3  vmovaps [rsp+0xA0], xmm11
00007f0254fdc9cc  vmovaps [rsp+0xB0], xmm12
00007f0254fdc9d5  vmovaps [rsp+0xC0], xmm13
00007f0254fdc9de  vmovaps [rsp+0xD0], xmm14
00007f0254fdc9e7  vmovaps [rsp+0xE0], xmm15
00007f0254fdc9f0  sub rsp, 0x30
00007f0254fdc9f4  movaps [rsp], xmm8
00007f0254fdc9f9  movaps [rsp+0x10], xmm12
00007f0254fdc9ff  movaps [rsp+0x20], xmm15
00007f0254fdca05  lea rdi, [rsp]
00007f0254fdca09  mov esi, 0x00
00007f0254fdca0e  mov rax, 0x55DD1360A530
00007f0254fdca18  call rax
00007f0254fdca1a  movaps xmm8, [rsp]
00007f0254fdca1f  add rsp, 0x30
00007f0254fdca23  vmovaps xmm0, [rsp]
00007f0254fdca28  vmovaps xmm1, [rsp+0x10]
00007f0254fdca2e  vmovaps xmm2, [rsp+0x20]
00007f0254fdca34  vmovaps xmm3, [rsp+0x30]
00007f0254fdca3a  vmovaps xmm4, [rsp+0x40]
00007f0254fdca40  vmovaps xmm5, [rsp+0x50]
00007f0254fdca46  vmovaps xmm6, [rsp+0x60]
00007f0254fdca4c  vmovaps xmm7, [rsp+0x70]
00007f0254fdca52  vmovaps xmm9, [rsp+0x80]
00007f0254fdca5b  vmovaps xmm10, [rsp+0x90]
00007f0254fdca64  vmovaps xmm11, [rsp+0xA0]
00007f0254fdca6d  vmovaps xmm12, [rsp+0xB0]
00007f0254fdca76  vmovaps xmm13, [rsp+0xC0]
00007f0254fdca7f  vmovaps xmm14, [rsp+0xD0]
00007f0254fdca88  vmovaps xmm15, [rsp+0xE0]
00007f0254fdca91  add rsp, 0xF0
00007f0254fdca98  pop r11
00007f0254fdca9a  pop r10
00007f0254fdca9c  pop r9
00007f0254fdca9e  pop r8
00007f0254fdcaa0  pop rsi
00007f0254fdcaa1  pop rdi
00007f0254fdcaa2  pop rdx
00007f0254fdcaa3  pop rcx
00007f0254fdcaa4  pop rax
00007f0254fdcaa5  add rsp, 0x08
00007f0254fdcaa9  jmp 0x00007F0254FDBB47
00007f0254fdcaae  sub rsp, 0x08
00007f0254fdcab2  push rax
00007f0254fdcab3  push rcx
00007f0254fdcab4  push rdx
00007f0254fdcab5  push rdi
00007f0254fdcab6  push rsi
00007f0254fdcab7  push r8
00007f0254fdcab9  push r9
00007f0254fdcabb  push r10
00007f0254fdcabd  push r11
00007f0254fdcabf  sub rsp, 0xF0
00007f0254fdcac6  vmovaps [rsp], xmm0
00007f0254fdcacb  vmovaps [rsp+0x10], xmm1
00007f0254fdcad1  vmovaps [rsp+0x20], xmm2
00007f0254fdcad7  vmovaps [rsp+0x30], xmm3
00007f0254fdcadd  vmovaps [rsp+0x40], xmm4
00007f0254fdcae3  vmovaps [rsp+0x50], xmm5
00007f0254fdcae9  vmovaps [rsp+0x60], xmm6
00007f0254fdcaef  vmovaps [rsp+0x70], xmm8
00007f0254fdcaf5  vmovaps [rsp+0x80], xmm9
00007f0254fdcafe  vmovaps [rsp+0x90], xmm10
00007f0254fdcb07  vmovaps [rsp+0xA0], xmm11
00007f0254fdcb10  vmovaps [rsp+0xB0], xmm12
00007f0254fdcb19  vmovaps [rsp+0xC0], xmm13
00007f0254fdcb22  vmovaps [rsp+0xD0], xmm14
00007f0254fdcb2b  vmovaps [rsp+0xE0], xmm15
00007f0254fdcb34  sub rsp, 0x30
00007f0254fdcb38  movaps [rsp], xmm7
00007f0254fdcb3c  movaps [rsp+0x10], xmm9
00007f0254fdcb42  movaps [rsp+0x20], xmm15
00007f0254fdcb48  lea rdi, [rsp]
00007f0254fdcb4c  mov esi, 0x00
00007f0254fdcb51  mov rax, 0x55DD1360A530
00007f0254fdcb5b  call rax
00007f0254fdcb5d  movaps xmm7, [rsp]
00007f0254fdcb61  add rsp, 0x30
00007f0254fdcb65  vmovaps xmm0, [rsp]
00007f0254fdcb6a  vmovaps xmm1, [rsp+0x10]
00007f0254fdcb70  vmovaps xmm2, [rsp+0x20]
00007f0254fdcb76  vmovaps xmm3, [rsp+0x30]
00007f0254fdcb7c  vmovaps xmm4, [rsp+0x40]
00007f0254fdcb82  vmovaps xmm5, [rsp+0x50]
00007f0254fdcb88  vmovaps xmm6, [rsp+0x60]
00007f0254fdcb8e  vmovaps xmm8, [rsp+0x70]
00007f0254fdcb94  vmovaps xmm9, [rsp+0x80]
00007f0254fdcb9d  vmovaps xmm10, [rsp+0x90]
00007f0254fdcba6  vmovaps xmm11, [rsp+0xA0]
00007f0254fdcbaf  vmovaps xmm12, [rsp+0xB0]
00007f0254fdcbb8  vmovaps xmm13, [rsp+0xC0]
00007f0254fdcbc1  vmovaps xmm14, [rsp+0xD0]
00007f0254fdcbca  vmovaps xmm15, [rsp+0xE0]
00007f0254fdcbd3  add rsp, 0xF0
00007f0254fdcbda  pop r11
00007f0254fdcbdc  pop r10
00007f0254fdcbde  pop r9
00007f0254fdcbe0  pop r8
00007f0254fdcbe2  pop rsi
00007f0254fdcbe3  pop rdi
00007f0254fdcbe4  pop rdx
00007f0254fdcbe5  pop rcx
00007f0254fdcbe6  pop rax
00007f0254fdcbe7  add rsp, 0x08
00007f0254fdcbeb  jmp 0x00007F0254FDBB75
00007f0254fdcbf0  sub rsp, 0x08
00007f0254fdcbf4  push rax
00007f0254fdcbf5  push rcx
00007f0254fdcbf6  push rdx
00007f0254fdcbf7  push rdi
00007f0254fdcbf8  push rsi
00007f0254fdcbf9  push r8
00007f0254fdcbfb  push r9
00007f0254fdcbfd  push r10
00007f0254fdcbff  push r11
00007f0254fdcc01  sub rsp, 0xF0
00007f0254fdcc08  vmovaps [rsp], xmm0
00007f0254fdcc0d  vmovaps [rsp+0x10], xmm1
00007f0254fdcc13  vmovaps [rsp+0x20], xmm2
00007f0254fdcc19  vmovaps [rsp+0x30], xmm3
00007f0254fdcc1f  vmovaps [rsp+0x40], xmm4
00007f0254fdcc25  vmovaps [rsp+0x50], xmm5
00007f0254fdcc2b  vmovaps [rsp+0x60], xmm6
00007f0254fdcc31  vmovaps [rsp+0x70], xmm7
00007f0254fdcc37  vmovaps [rsp+0x80], xmm8
00007f0254fdcc40  vmovaps [rsp+0x90], xmm10
00007f0254fdcc49  vmovaps [rsp+0xA0], xmm11
00007f0254fdcc52  vmovaps [rsp+0xB0], xmm12
00007f0254fdcc5b  vmovaps [rsp+0xC0], xmm13
00007f0254fdcc64  vmovaps [rsp+0xD0], xmm14
00007f0254fdcc6d  vmovaps [rsp+0xE0], xmm15
00007f0254fdcc76  sub rsp, 0x30
00007f0254fdcc7a  movaps [rsp], xmm9
00007f0254fdcc7f  movaps [rsp+0x10], xmm12
00007f0254fdcc85  movaps [rsp+0x20], xmm10
00007f0254fdcc8b  lea rdi, [rsp]
00007f0254fdcc8f  mov esi, 0x00
00007f0254fdcc94  mov rax, 0x55DD1360A530
00007f0254fdcc9e  call rax
00007f0254fdcca0  movaps xmm9, [rsp]
00007f0254fdcca5  add rsp, 0x30
00007f0254fdcca9  vmovaps xmm0, [rsp]
00007f0254fdccae  vmovaps xmm1, [rsp+0x10]
00007f0254fdccb4  vmovaps xmm2, [rsp+0x20]
00007f0254fdccba  vmovaps xmm3, [rsp+0x30]
00007f0254fdccc0  vmovaps xmm4, [rsp+0x40]
00007f0254fdccc6  vmovaps xmm5, [rsp+0x50]
00007f0254fdcccc  vmovaps xmm6, [rsp+0x60]
00007f0254fdccd2  vmovaps xmm7, [rsp+0x70]
00007f0254fdccd8  vmovaps xmm8, [rsp+0x80]
00007f0254fdcce1  vmovaps xmm10, [rsp+0x90]
00007f0254fdccea  vmovaps xmm11, [rsp+0xA0]
00007f0254fdccf3  vmovaps xmm12, [rsp+0xB0]
00007f0254fdccfc  vmovaps xmm13, [rsp+0xC0]
00007f0254fdcd05  vmovaps xmm14, [rsp+0xD0]
00007f0254fdcd0e  vmovaps xmm15, [rsp+0xE0]
00007f0254fdcd17  add rsp, 0xF0
00007f0254fdcd1e  pop r11
00007f0254fdcd20  pop r10
00007f0254fdcd22  pop r9
00007f0254fdcd24  pop r8
00007f0254fdcd26  pop rsi
00007f0254fdcd27  pop rdi
00007f0254fdcd28  pop rdx
00007f0254fdcd29  pop rcx
00007f0254fdcd2a  pop rax
00007f0254fdcd2b  add rsp, 0x08
00007f0254fdcd2f  jmp 0x00007F0254FDBB99
00007f0254fdcd34  sub rsp, 0x08
00007f0254fdcd38  push rax
00007f0254fdcd39  push rcx
00007f0254fdcd3a  push rdx
00007f0254fdcd3b  push rdi
00007f0254fdcd3c  push rsi
00007f0254fdcd3d  push r8
00007f0254fdcd3f  push r9
00007f0254fdcd41  push r10
00007f0254fdcd43  push r11
00007f0254fdcd45  sub rsp, 0xF0
00007f0254fdcd4c  vmovaps [rsp], xmm0
00007f0254fdcd51  vmovaps [rsp+0x10], xmm1
00007f0254fdcd57  vmovaps [rsp+0x20], xmm2
00007f0254fdcd5d  vmovaps [rsp+0x30], xmm3
00007f0254fdcd63  vmovaps [rsp+0x40], xmm4
00007f0254fdcd69  vmovaps [rsp+0x50], xmm5
00007f0254fdcd6f  vmovaps [rsp+0x60], xmm6
00007f0254fdcd75  vmovaps [rsp+0x70], xmm7
00007f0254fdcd7b  vmovaps [rsp+0x80], xmm8
00007f0254fdcd84  vmovaps [rsp+0x90], xmm9
00007f0254fdcd8d  vmovaps [rsp+0xA0], xmm11
00007f0254fdcd96  vmovaps [rsp+0xB0], xmm12
00007f0254fdcd9f  vmovaps [rsp+0xC0], xmm13
00007f0254fdcda8  vmovaps [rsp+0xD0], xmm14
00007f0254fdcdb1  vmovaps [rsp+0xE0], xmm15
00007f0254fdcdba  sub rsp, 0x30
00007f0254fdcdbe  movaps [rsp], xmm10
00007f0254fdcdc3  movaps [rsp+0x10], xmm12
00007f0254fdcdc9  movaps [rsp+0x20], xmm11
00007f0254fdcdcf  lea rdi, [rsp]
00007f0254fdcdd3  mov esi, 0x00
00007f0254fdcdd8  mov rax, 0x55DD1360A530
00007f0254fdcde2  call rax
00007f0254fdcde4  movaps xmm10, [rsp]
00007f0254fdcde9  add rsp, 0x30
00007f0254fdcded  vmovaps xmm0, [rsp]
00007f0254fdcdf2  vmovaps xmm1, [rsp+0x10]
00007f0254fdcdf8  vmovaps xmm2, [rsp+0x20]
00007f0254fdcdfe  vmovaps xmm3, [rsp+0x30]
00007f0254fdce04  vmovaps xmm4, [rsp+0x40]
00007f0254fdce0a  vmovaps xmm5, [rsp+0x50]
00007f0254fdce10  vmovaps xmm6, [rsp+0x60]
00007f0254fdce16  vmovaps xmm7, [rsp+0x70]
00007f0254fdce1c  vmovaps xmm8, [rsp+0x80]
00007f0254fdce25  vmovaps xmm9, [rsp+0x90]
00007f0254fdce2e  vmovaps xmm11, [rsp+0xA0]
00007f0254fdce37  vmovaps xmm12, [rsp+0xB0]
00007f0254fdce40  vmovaps xmm13, [rsp+0xC0]
00007f0254fdce49  vmovaps xmm14, [rsp+0xD0]
00007f0254fdce52  vmovaps xmm15, [rsp+0xE0]
00007f0254fdce5b  add rsp, 0xF0
00007f0254fdce62  pop r11
00007f0254fdce64  pop r10
00007f0254fdce66  pop r9
00007f0254fdce68  pop r8
00007f0254fdce6a  pop rsi
00007f0254fdce6b  pop rdi
00007f0254fdce6c  pop rdx
00007f0254fdce6d  pop rcx
00007f0254fdce6e  pop rax
00007f0254fdce6f  add rsp, 0x08
00007f0254fdce73  jmp 0x00007F0254FDBBB3
00007f0254fdce78  sub rsp, 0x08
00007f0254fdce7c  push rax
00007f0254fdce7d  push rcx
00007f0254fdce7e  push rdx
00007f0254fdce7f  push rdi
00007f0254fdce80  push rsi
00007f0254fdce81  push r8
00007f0254fdce83  push r9
00007f0254fdce85  push r10
00007f0254fdce87  push r11
00007f0254fdce89  sub rsp, 0xF0
00007f0254fdce90  vmovaps [rsp], xmm0
00007f0254fdce95  vmovaps [rsp+0x10], xmm1
00007f0254fdce9b  vmovaps [rsp+0x20], xmm2
00007f0254fdcea1  vmovaps [rsp+0x30], xmm3
00007f0254fdcea7  vmovaps [rsp+0x40], xmm4
00007f0254fdcead  vmovaps [rsp+0x50], xmm5
00007f0254fdceb3  vmovaps [rsp+0x60], xmm7
00007f0254fdceb9  vmovaps [rsp+0x70], xmm8
00007f0254fdcebf  vmovaps [rsp+0x80], xmm9
00007f0254fdcec8  vmovaps [rsp+0x90], xmm10
00007f0254fdced1  vmovaps [rsp+0xA0], xmm11
00007f0254fdceda  vmovaps [rsp+0xB0], xmm12
00007f0254fdcee3  vmovaps [rsp+0xC0], xmm13
00007f0254fdceec  vmovaps [rsp+0xD0], xmm14
00007f0254fdcef5  vmovaps [rsp+0xE0], xmm15
00007f0254fdcefe  sub rsp, 0x30
00007f0254fdcf02  movaps [rsp], xmm6
00007f0254fdcf06  movaps [rsp+0x10], xmm12
00007f0254fdcf0c  movaps [rsp+0x20], xmm11
00007f0254fdcf12  lea rdi, [rsp]
00007f0254fdcf16  mov esi, 0x00
00007f0254fdcf1b  mov rax, 0x55DD1360A530
00007f0254fdcf25  call rax
00007f0254fdcf27  movaps xmm6, [rsp]
00007f0254fdcf2b  add rsp, 0x30
00007f0254fdcf2f  vmovaps xmm0, [rsp]
00007f0254fdcf34  vmovaps xmm1, [rsp+0x10]
00007f0254fdcf3a  vmovaps xmm2, [rsp+0x20]
00007f0254fdcf40  vmovaps xmm3, [rsp+0x30]
00007f0254fdcf46  vmovaps xmm4, [rsp+0x40]
00007f0254fdcf4c  vmovaps xmm5, [rsp+0x50]
00007f0254fdcf52  vmovaps xmm7, [rsp+0x60]
00007f0254fdcf58  vmovaps xmm8, [rsp+0x70]
00007f0254fdcf5e  vmovaps xmm9, [rsp+0x80]
00007f0254fdcf67  vmovaps xmm10, [rsp+0x90]
00007f0254fdcf70  vmovaps xmm11, [rsp+0xA0]
00007f0254fdcf79  vmovaps xmm12, [rsp+0xB0]
00007f0254fdcf82  vmovaps xmm13, [rsp+0xC0]
00007f0254fdcf8b  vmovaps xmm14, [rsp+0xD0]
00007f0254fdcf94  vmovaps xmm15, [rsp+0xE0]
00007f0254fdcf9d  add rsp, 0xF0
00007f0254fdcfa4  pop r11
00007f0254fdcfa6  pop r10
00007f0254fdcfa8  pop r9
00007f0254fdcfaa  pop r8
00007f0254fdcfac  pop rsi
00007f0254fdcfad  pop rdi
00007f0254fdcfae  pop rdx
00007f0254fdcfaf  pop rcx
00007f0254fdcfb0  pop rax
00007f0254fdcfb1  add rsp, 0x08
00007f0254fdcfb5  jmp 0x00007F0254FDBBD4
00007f0254fdcfba  sub rsp, 0x08
00007f0254fdcfbe  push rax
00007f0254fdcfbf  push rcx
00007f0254fdcfc0  push rdx
00007f0254fdcfc1  push rdi
00007f0254fdcfc2  push rsi
00007f0254fdcfc3  push r8
00007f0254fdcfc5  push r9
00007f0254fdcfc7  push r10
00007f0254fdcfc9  push r11
00007f0254fdcfcb  sub rsp, 0xF0
00007f0254fdcfd2  vmovaps [rsp], xmm0
00007f0254fdcfd7  vmovaps [rsp+0x10], xmm1
00007f0254fdcfdd  vmovaps [rsp+0x20], xmm2
00007f0254fdcfe3  vmovaps [rsp+0x30], xmm4
00007f0254fdcfe9  vmovaps [rsp+0x40], xmm5
00007f0254fdcfef  vmovaps [rsp+0x50], xmm6
00007f0254fdcff5  vmovaps [rsp+0x60], xmm7
00007f0254fdcffb  vmovaps [rsp+0x70], xmm8
00007f0254fdd001  vmovaps [rsp+0x80], xmm9
00007f0254fdd00a  vmovaps [rsp+0x90], xmm10
00007f0254fdd013  vmovaps [rsp+0xA0], xmm11
00007f0254fdd01c  vmovaps [rsp+0xB0], xmm12
00007f0254fdd025  vmovaps [rsp+0xC0], xmm13
00007f0254fdd02e  vmovaps [rsp+0xD0], xmm14
00007f0254fdd037  vmovaps [rsp+0xE0], xmm15
00007f0254fdd040  sub rsp, 0x30
00007f0254fdd044  movaps [rsp], xmm3
00007f0254fdd048  movaps [rsp+0x10], xmm5
00007f0254fdd04d  movaps [rsp+0x20], xmm4
00007f0254fdd052  lea rdi, [rsp]
00007f0254fdd056  mov esi, 0x00
00007f0254fdd05b  mov rax, 0x55DD1360A530
00007f0254fdd065  call rax
00007f0254fdd067  movaps xmm3, [rsp]
00007f0254fdd06b  add rsp, 0x30
00007f0254fdd06f  vmovaps xmm0, [rsp]
00007f0254fdd074  vmovaps xmm1, [rsp+0x10]
00007f0254fdd07a  vmovaps xmm2, [rsp+0x20]
00007f0254fdd080  vmovaps xmm4, [rsp+0x30]
00007f0254fdd086  vmovaps xmm5, [rsp+0x40]
00007f0254fdd08c  vmovaps xmm6, [rsp+0x50]
00007f0254fdd092  vmovaps xmm7, [rsp+0x60]
00007f0254fdd098  vmovaps xmm8, [rsp+0x70]
00007f0254fdd09e  vmovaps xmm9, [rsp+0x80]
00007f0254fdd0a7  vmovaps xmm10, [rsp+0x90]
00007f0254fdd0b0  vmovaps xmm11, [rsp+0xA0]
00007f0254fdd0b9  vmovaps xmm12, [rsp+0xB0]
00007f0254fdd0c2  vmovaps xmm13, [rsp+0xC0]
00007f0254fdd0cb  vmovaps xmm14, [rsp+0xD0]
00007f0254fdd0d4  vmovaps xmm15, [rsp+0xE0]
00007f0254fdd0dd  add rsp, 0xF0
00007f0254fdd0e4  pop r11
00007f0254fdd0e6  pop r10
00007f0254fdd0e8  pop r9
00007f0254fdd0ea  pop r8
00007f0254fdd0ec  pop rsi
00007f0254fdd0ed  pop rdi
00007f0254fdd0ee  pop rdx
00007f0254fdd0ef  pop rcx
00007f0254fdd0f0  pop rax
00007f0254fdd0f1  add rsp, 0x08
00007f0254fdd0f5  jmp 0x00007F0254FDBC35
00007f0254fdd0fa  sub rsp, 0x08
00007f0254fdd0fe  push rax
00007f0254fdd0ff  push rcx
00007f0254fdd100  push rdx
00007f0254fdd101  push rdi
00007f0254fdd102  push rsi
00007f0254fdd103  push r8
00007f0254fdd105  push r9
00007f0254fdd107  push r10
00007f0254fdd109  push r11
00007f0254fdd10b  sub rsp, 0xF0
00007f0254fdd112  vmovaps [rsp], xmm0
00007f0254fdd117  vmovaps [rsp+0x10], xmm1
00007f0254fdd11d  vmovaps [rsp+0x20], xmm2
00007f0254fdd123  vmovaps [rsp+0x30], xmm3
00007f0254fdd129  vmovaps [rsp+0x40], xmm4
00007f0254fdd12f  vmovaps [rsp+0x50], xmm6
00007f0254fdd135  vmovaps [rsp+0x60], xmm7
00007f0254fdd13b  vmovaps [rsp+0x70], xmm8
00007f0254fdd141  vmovaps [rsp+0x80], xmm9
00007f0254fdd14a  vmovaps [rsp+0x90], xmm10
00007f0254fdd153  vmovaps [rsp+0xA0], xmm11
00007f0254fdd15c  vmovaps [rsp+0xB0], xmm12
00007f0254fdd165  vmovaps [rsp+0xC0], xmm13
00007f0254fdd16e  vmovaps [rsp+0xD0], xmm14
00007f0254fdd177  vmovaps [rsp+0xE0], xmm15
00007f0254fdd180  sub rsp, 0x30
00007f0254fdd184  movaps [rsp], xmm5
00007f0254fdd188  movaps [rsp+0x10], xmm8
00007f0254fdd18e  movaps [rsp+0x20], xmm15
00007f0254fdd194  lea rdi, [rsp]
00007f0254fdd198  mov esi, 0x00
00007f0254fdd19d  mov rax, 0x55DD1360A530
00007f0254fdd1a7  call rax
00007f0254fdd1a9  movaps xmm5, [rsp]
00007f0254fdd1ad  add rsp, 0x30
00007f0254fdd1b1  vmovaps xmm0, [rsp]
00007f0254fdd1b6  vmovaps xmm1, [rsp+0x10]
00007f0254fdd1bc  vmovaps xmm2, [rsp+0x20]
00007f0254fdd1c2  vmovaps xmm3, [rsp+0x30]
00007f0254fdd1c8  vmovaps xmm4, [rsp+0x40]
00007f0254fdd1ce  vmovaps xmm6, [rsp+0x50]
00007f0254fdd1d4  vmovaps xmm7, [rsp+0x60]
00007f0254fdd1da  vmovaps xmm8, [rsp+0x70]
00007f0254fdd1e0  vmovaps xmm9, [rsp+0x80]
00007f0254fdd1e9  vmovaps xmm10, [rsp+0x90]
00007f0254fdd1f2  vmovaps xmm11, [rsp+0xA0]
00007f0254fdd1fb  vmovaps xmm12, [rsp+0xB0]
00007f0254fdd204  vmovaps xmm13, [rsp+0xC0]
00007f0254fdd20d  vmovaps xmm14, [rsp+0xD0]
00007f0254fdd216  vmovaps xmm15, [rsp+0xE0]
00007f0254fdd21f  add rsp, 0xF0
00007f0254fdd226  pop r11
00007f0254fdd228  pop r10
00007f0254fdd22a  pop r9
00007f0254fdd22c  pop r8
00007f0254fdd22e  pop rsi
00007f0254fdd22f  pop rdi
00007f0254fdd230  pop rdx
00007f0254fdd231  pop rcx
00007f0254fdd232  pop rax
00007f0254fdd233  add rsp, 0x08
00007f0254fdd237  jmp 0x00007F0254FDBC73
00007f0254fdd23c  sub rsp, 0x08
00007f0254fdd240  push rax
00007f0254fdd241  push rcx
00007f0254fdd242  push rdx
00007f0254fdd243  push rdi
00007f0254fdd244  push rsi
00007f0254fdd245  push r8
00007f0254fdd247  push r9
00007f0254fdd249  push r10
00007f0254fdd24b  push r11
00007f0254fdd24d  sub rsp, 0xF0
00007f0254fdd254  vmovaps [rsp], xmm0
00007f0254fdd259  vmovaps [rsp+0x10], xmm1
00007f0254fdd25f  vmovaps [rsp+0x20], xmm2
00007f0254fdd265  vmovaps [rsp+0x30], xmm3
00007f0254fdd26b  vmovaps [rsp+0x40], xmm5
00007f0254fdd271  vmovaps [rsp+0x50], xmm6
00007f0254fdd277  vmovaps [rsp+0x60], xmm7
00007f0254fdd27d  vmovaps [rsp+0x70], xmm8
00007f0254fdd283  vmovaps [rsp+0x80], xmm9
00007f0254fdd28c  vmovaps [rsp+0x90], xmm10
00007f0254fdd295  vmovaps [rsp+0xA0], xmm11
00007f0254fdd29e  vmovaps [rsp+0xB0], xmm12
00007f0254fdd2a7  vmovaps [rsp+0xC0], xmm13
00007f0254fdd2b0  vmovaps [rsp+0xD0], xmm14
00007f0254fdd2b9  vmovaps [rsp+0xE0], xmm15
00007f0254fdd2c2  sub rsp, 0x30
00007f0254fdd2c6  movaps [rsp], xmm4
00007f0254fdd2ca  movaps [rsp+0x10], xmm9
00007f0254fdd2d0  movaps [rsp+0x20], xmm8
00007f0254fdd2d6  lea rdi, [rsp]
00007f0254fdd2da  mov esi, 0x00
00007f0254fdd2df  mov rax, 0x55DD1360A530
00007f0254fdd2e9  call rax
00007f0254fdd2eb  movaps xmm4, [rsp]
00007f0254fdd2ef  add rsp, 0x30
00007f0254fdd2f3  vmovaps xmm0, [rsp]
00007f0254fdd2f8  vmovaps xmm1, [rsp+0x10]
00007f0254fdd2fe  vmovaps xmm2, [rsp+0x20]
00007f0254fdd304  vmovaps xmm3, [rsp+0x30]
00007f0254fdd30a  vmovaps xmm5, [rsp+0x40]
00007f0254fdd310  vmovaps xmm6, [rsp+0x50]
00007f0254fdd316  vmovaps xmm7, [rsp+0x60]
00007f0254fdd31c  vmovaps xmm8, [rsp+0x70]
00007f0254fdd322  vmovaps xmm9, [rsp+0x80]
00007f0254fdd32b  vmovaps xmm10, [rsp+0x90]
00007f0254fdd334  vmovaps xmm11, [rsp+0xA0]
00007f0254fdd33d  vmovaps xmm12, [rsp+0xB0]
00007f0254fdd346  vmovaps xmm13, [rsp+0xC0]
00007f0254fdd34f  vmovaps xmm14, [rsp+0xD0]
00007f0254fdd358  vmovaps xmm15, [rsp+0xE0]
00007f0254fdd361  add rsp, 0xF0
00007f0254fdd368  pop r11
00007f0254fdd36a  pop r10
00007f0254fdd36c  pop r9
00007f0254fdd36e  pop r8
00007f0254fdd370  pop rsi
00007f0254fdd371  pop rdi
00007f0254fdd372  pop rdx
00007f0254fdd373  pop rcx
00007f0254fdd374  pop rax
00007f0254fdd375  add rsp, 0x08
00007f0254fdd379  jmp 0x00007F0254FDBC94
00007f0254fdd37e  sub rsp, 0x08
00007f0254fdd382  push rax
00007f0254fdd383  push rcx
00007f0254fdd384  push rdx
00007f0254fdd385  push rdi
00007f0254fdd386  push rsi
00007f0254fdd387  push r8
00007f0254fdd389  push r9
00007f0254fdd38b  push r10
00007f0254fdd38d  push r11
00007f0254fdd38f  sub rsp, 0xF0
00007f0254fdd396  vmovaps [rsp], xmm0
00007f0254fdd39b  vmovaps [rsp+0x10], xmm1
00007f0254fdd3a1  vmovaps [rsp+0x20], xmm2
00007f0254fdd3a7  vmovaps [rsp+0x30], xmm3
00007f0254fdd3ad  vmovaps [rsp+0x40], xmm4
00007f0254fdd3b3  vmovaps [rsp+0x50], xmm5
00007f0254fdd3b9  vmovaps [rsp+0x60], xmm6
00007f0254fdd3bf  vmovaps [rsp+0x70], xmm7
00007f0254fdd3c5  vmovaps [rsp+0x80], xmm8
00007f0254fdd3ce  vmovaps [rsp+0x90], xmm10
00007f0254fdd3d7  vmovaps [rsp+0xA0], xmm11
00007f0254fdd3e0  vmovaps [rsp+0xB0], xmm12
00007f0254fdd3e9  vmovaps [rsp+0xC0], xmm13
00007f0254fdd3f2  vmovaps [rsp+0xD0], xmm14
00007f0254fdd3fb  vmovaps [rsp+0xE0], xmm15
00007f0254fdd404  sub rsp, 0x30
00007f0254fdd408  movaps [rsp], xmm9
00007f0254fdd40d  movaps [rsp+0x10], xmm10
00007f0254fdd413  movaps [rsp+0x20], xmm8
00007f0254fdd419  lea rdi, [rsp]
00007f0254fdd41d  mov esi, 0x00
00007f0254fdd422  mov rax, 0x55DD1360A530
00007f0254fdd42c  call rax
00007f0254fdd42e  movaps xmm9, [rsp]
00007f0254fdd433  add rsp, 0x30
00007f0254fdd437  vmovaps xmm0, [rsp]
00007f0254fdd43c  vmovaps xmm1, [rsp+0x10]
00007f0254fdd442  vmovaps xmm2, [rsp+0x20]
00007f0254fdd448  vmovaps xmm3, [rsp+0x30]
00007f0254fdd44e  vmovaps xmm4, [rsp+0x40]
00007f0254fdd454  vmovaps xmm5, [rsp+0x50]
00007f0254fdd45a  vmovaps xmm6, [rsp+0x60]
00007f0254fdd460  vmovaps xmm7, [rsp+0x70]
00007f0254fdd466  vmovaps xmm8, [rsp+0x80]
00007f0254fdd46f  vmovaps xmm10, [rsp+0x90]
00007f0254fdd478  vmovaps xmm11, [rsp+0xA0]
00007f0254fdd481  vmovaps xmm12, [rsp+0xB0]
00007f0254fdd48a  vmovaps xmm13, [rsp+0xC0]
00007f0254fdd493  vmovaps xmm14, [rsp+0xD0]
00007f0254fdd49c  vmovaps xmm15, [rsp+0xE0]
00007f0254fdd4a5  add rsp, 0xF0
00007f0254fdd4ac  pop r11
00007f0254fdd4ae  pop r10
00007f0254fdd4b0  pop r9
00007f0254fdd4b2  pop r8
00007f0254fdd4b4  pop rsi
00007f0254fdd4b5  pop rdi
00007f0254fdd4b6  pop rdx
00007f0254fdd4b7  pop rcx
00007f0254fdd4b8  pop rax
00007f0254fdd4b9  add rsp, 0x08
00007f0254fdd4bd  jmp 0x00007F0254FDBCAE
00007f0254fdd4c2  call 0x00007F0254EB52F0
00007f0254fdd4c7  jmp 0x00007F0254FDBDC8
00007f0254fdd4cc  call 0x00007F0254EB52F0
00007f0254fdd4d1  jmp 0x00007F0254FDBDDE
00007f0254fdd4d6  sub rsp, 0x08
00007f0254fdd4da  push rax
00007f0254fdd4db  push rcx
00007f0254fdd4dc  push rdx
00007f0254fdd4dd  push rdi
00007f0254fdd4de  push rsi
00007f0254fdd4df  push r8
00007f0254fdd4e1  push r9
00007f0254fdd4e3  push r10
00007f0254fdd4e5  push r11
00007f0254fdd4e7  sub rsp, 0xF0
00007f0254fdd4ee  vmovaps [rsp], xmm0
00007f0254fdd4f3  vmovaps [rsp+0x10], xmm2
00007f0254fdd4f9  vmovaps [rsp+0x20], xmm3
00007f0254fdd4ff  vmovaps [rsp+0x30], xmm4
00007f0254fdd505  vmovaps [rsp+0x40], xmm5
00007f0254fdd50b  vmovaps [rsp+0x50], xmm6
00007f0254fdd511  vmovaps [rsp+0x60], xmm7
00007f0254fdd517  vmovaps [rsp+0x70], xmm8
00007f0254fdd51d  vmovaps [rsp+0x80], xmm9
00007f0254fdd526  vmovaps [rsp+0x90], xmm10
00007f0254fdd52f  vmovaps [rsp+0xA0], xmm11
00007f0254fdd538  vmovaps [rsp+0xB0], xmm12
00007f0254fdd541  vmovaps [rsp+0xC0], xmm13
00007f0254fdd54a  vmovaps [rsp+0xD0], xmm14
00007f0254fdd553  vmovaps [rsp+0xE0], xmm15
00007f0254fdd55c  sub rsp, 0x30
00007f0254fdd560  movaps [rsp], xmm1
00007f0254fdd564  movaps [rsp+0x10], xmm6
00007f0254fdd569  movaps [rsp+0x20], xmm15
00007f0254fdd56f  lea rdi, [rsp]
00007f0254fdd573  mov esi, 0x00
00007f0254fdd578  mov rax, 0x55DD1360A530
00007f0254fdd582  call rax
00007f0254fdd584  movaps xmm1, [rsp]
00007f0254fdd588  add rsp, 0x30
00007f0254fdd58c  vmovaps xmm0, [rsp]
00007f0254fdd591  vmovaps xmm2, [rsp+0x10]
00007f0254fdd597  vmovaps xmm3, [rsp+0x20]
00007f0254fdd59d  vmovaps xmm4, [rsp+0x30]
00007f0254fdd5a3  vmovaps xmm5, [rsp+0x40]
00007f0254fdd5a9  vmovaps xmm6, [rsp+0x50]
00007f0254fdd5af  vmovaps xmm7, [rsp+0x60]
00007f0254fdd5b5  vmovaps xmm8, [rsp+0x70]
00007f0254fdd5bb  vmovaps xmm9, [rsp+0x80]
00007f0254fdd5c4  vmovaps xmm10, [rsp+0x90]
00007f0254fdd5cd  vmovaps xmm11, [rsp+0xA0]
00007f0254fdd5d6  vmovaps xmm12, [rsp+0xB0]
00007f0254fdd5df  vmovaps xmm13, [rsp+0xC0]
00007f0254fdd5e8  vmovaps xmm14, [rsp+0xD0]
00007f0254fdd5f1  vmovaps xmm15, [rsp+0xE0]
00007f0254fdd5fa  add rsp, 0xF0
00007f0254fdd601  pop r11
00007f0254fdd603  pop r10
00007f0254fdd605  pop r9
00007f0254fdd607  pop r8
00007f0254fdd609  pop rsi
00007f0254fdd60a  pop rdi
00007f0254fdd60b  pop rdx
00007f0254fdd60c  pop rcx
00007f0254fdd60d  pop rax
00007f0254fdd60e  add rsp, 0x08
00007f0254fdd612  jmp 0x00007F0254FDBE1B
00007f0254fdd617  call 0x00007F0254EC4620
00007f0254fdd61c  jmp 0x00007F0254FDBE28
00007f0254fdd621  sub rsp, 0x08
00007f0254fdd625  push rax
00007f0254fdd626  push rcx
00007f0254fdd627  push rdx
00007f0254fdd628  push rdi
00007f0254fdd629  push rsi
00007f0254fdd62a  push r8
00007f0254fdd62c  push r9
00007f0254fdd62e  push r10
00007f0254fdd630  push r11
00007f0254fdd632  sub rsp, 0xF0
00007f0254fdd639  vmovaps [rsp], xmm0
00007f0254fdd63e  vmovaps [rsp+0x10], xmm1
00007f0254fdd644  vmovaps [rsp+0x20], xmm2
00007f0254fdd64a  vmovaps [rsp+0x30], xmm3
00007f0254fdd650  vmovaps [rsp+0x40], xmm4
00007f0254fdd656  vmovaps [rsp+0x50], xmm5
00007f0254fdd65c  vmovaps [rsp+0x60], xmm6
00007f0254fdd662  vmovaps [rsp+0x70], xmm7
00007f0254fdd668  vmovaps [rsp+0x80], xmm8
00007f0254fdd671  vmovaps [rsp+0x90], xmm9
00007f0254fdd67a  vmovaps [rsp+0xA0], xmm10
00007f0254fdd683  vmovaps [rsp+0xB0], xmm11
00007f0254fdd68c  vmovaps [rsp+0xC0], xmm12
00007f0254fdd695  vmovaps [rsp+0xD0], xmm13
00007f0254fdd69e  vmovaps [rsp+0xE0], xmm15
00007f0254fdd6a7  sub rsp, 0x30
00007f0254fdd6ab  movaps [rsp], xmm14
00007f0254fdd6b0  movaps [rsp+0x10], xmm4
00007f0254fdd6b5  movaps [rsp+0x20], xmm3
00007f0254fdd6ba  lea rdi, [rsp]
00007f0254fdd6be  mov esi, 0x00
00007f0254fdd6c3  mov rax, 0x55DD1360A530
00007f0254fdd6cd  call rax
00007f0254fdd6cf  movaps xmm14, [rsp]
00007f0254fdd6d4  add rsp, 0x30
00007f0254fdd6d8  vmovaps xmm0, [rsp]
00007f0254fdd6dd  vmovaps xmm1, [rsp+0x10]
00007f0254fdd6e3  vmovaps xmm2, [rsp+0x20]
00007f0254fdd6e9  vmovaps xmm3, [rsp+0x30]
00007f0254fdd6ef  vmovaps xmm4, [rsp+0x40]
00007f0254fdd6f5  vmovaps xmm5, [rsp+0x50]
00007f0254fdd6fb  vmovaps xmm6, [rsp+0x60]
00007f0254fdd701  vmovaps xmm7, [rsp+0x70]
00007f0254fdd707  vmovaps xmm8, [rsp+0x80]
00007f0254fdd710  vmovaps xmm9, [rsp+0x90]
00007f0254fdd719  vmovaps xmm10, [rsp+0xA0]
00007f0254fdd722  vmovaps xmm11, [rsp+0xB0]
00007f0254fdd72b  vmovaps xmm12, [rsp+0xC0]
00007f0254fdd734  vmovaps xmm13, [rsp+0xD0]
00007f0254fdd73d  vmovaps xmm15, [rsp+0xE0]
00007f0254fdd746  add rsp, 0xF0
00007f0254fdd74d  pop r11
00007f0254fdd74f  pop r10
00007f0254fdd751  pop r9
00007f0254fdd753  pop r8
00007f0254fdd755  pop rsi
00007f0254fdd756  pop rdi
00007f0254fdd757  pop rdx
00007f0254fdd758  pop rcx
00007f0254fdd759  pop rax
00007f0254fdd75a  add rsp, 0x08
00007f0254fdd75e  jmp 0x00007F0254FDBE42
00007f0254fdd763  sub rsp, 0x08
00007f0254fdd767  push rax
00007f0254fdd768  push rcx
00007f0254fdd769  push rdx
00007f0254fdd76a  push rdi
00007f0254fdd76b  push rsi
00007f0254fdd76c  push r8
00007f0254fdd76e  push r9
00007f0254fdd770  push r10
00007f0254fdd772  push r11
00007f0254fdd774  sub rsp, 0xF0
00007f0254fdd77b  vmovaps [rsp], xmm0
00007f0254fdd780  vmovaps [rsp+0x10], xmm1
00007f0254fdd786  vmovaps [rsp+0x20], xmm2
00007f0254fdd78c  vmovaps [rsp+0x30], xmm3
00007f0254fdd792  vmovaps [rsp+0x40], xmm4
00007f0254fdd798  vmovaps [rsp+0x50], xmm5
00007f0254fdd79e  vmovaps [rsp+0x60], xmm7
00007f0254fdd7a4  vmovaps [rsp+0x70], xmm8
00007f0254fdd7aa  vmovaps [rsp+0x80], xmm9
00007f0254fdd7b3  vmovaps [rsp+0x90], xmm10
00007f0254fdd7bc  vmovaps [rsp+0xA0], xmm11
00007f0254fdd7c5  vmovaps [rsp+0xB0], xmm12
00007f0254fdd7ce  vmovaps [rsp+0xC0], xmm13
00007f0254fdd7d7  vmovaps [rsp+0xD0], xmm14
00007f0254fdd7e0  vmovaps [rsp+0xE0], xmm15
00007f0254fdd7e9  sub rsp, 0x30
00007f0254fdd7ed  movaps [rsp], xmm6
00007f0254fdd7f1  movaps [rsp+0x10], xmm9
00007f0254fdd7f7  movaps [rsp+0x20], xmm7
00007f0254fdd7fc  lea rdi, [rsp]
00007f0254fdd800  mov esi, 0x00
00007f0254fdd805  mov rax, 0x55DD1360A530
00007f0254fdd80f  call rax
00007f0254fdd811  movaps xmm6, [rsp]
00007f0254fdd815  add rsp, 0x30
00007f0254fdd819  vmovaps xmm0, [rsp]
00007f0254fdd81e  vmovaps xmm1, [rsp+0x10]
00007f0254fdd824  vmovaps xmm2, [rsp+0x20]
00007f0254fdd82a  vmovaps xmm3, [rsp+0x30]
00007f0254fdd830  vmovaps xmm4, [rsp+0x40]
00007f0254fdd836  vmovaps xmm5, [rsp+0x50]
00007f0254fdd83c  vmovaps xmm7, [rsp+0x60]
00007f0254fdd842  vmovaps xmm8, [rsp+0x70]
00007f0254fdd848  vmovaps xmm9, [rsp+0x80]
00007f0254fdd851  vmovaps xmm10, [rsp+0x90]
00007f0254fdd85a  vmovaps xmm11, [rsp+0xA0]
00007f0254fdd863  vmovaps xmm12, [rsp+0xB0]
00007f0254fdd86c  vmovaps xmm13, [rsp+0xC0]
00007f0254fdd875  vmovaps xmm14, [rsp+0xD0]
00007f0254fdd87e  vmovaps xmm15, [rsp+0xE0]
00007f0254fdd887  add rsp, 0xF0
00007f0254fdd88e  pop r11
00007f0254fdd890  pop r10
00007f0254fdd892  pop r9
00007f0254fdd894  pop r8
00007f0254fdd896  pop rsi
00007f0254fdd897  pop rdi
00007f0254fdd898  pop rdx
00007f0254fdd899  pop rcx
00007f0254fdd89a  pop rax
00007f0254fdd89b  add rsp, 0x08
00007f0254fdd89f  jmp 0x00007F0254FDBE5A
00007f0254fdd8a4  sub rsp, 0x08
00007f0254fdd8a8  push rax
00007f0254fdd8a9  push rcx
00007f0254fdd8aa  push rdx
00007f0254fdd8ab  push rdi
00007f0254fdd8ac  push rsi
00007f0254fdd8ad  push r8
00007f0254fdd8af  push r9
00007f0254fdd8b1  push r10
00007f0254fdd8b3  push r11
00007f0254fdd8b5  sub rsp, 0xF0
00007f0254fdd8bc  vmovaps [rsp], xmm0
00007f0254fdd8c1  vmovaps [rsp+0x10], xmm1
00007f0254fdd8c7  vmovaps [rsp+0x20], xmm2
00007f0254fdd8cd  vmovaps [rsp+0x30], xmm3
00007f0254fdd8d3  vmovaps [rsp+0x40], xmm4
00007f0254fdd8d9  vmovaps [rsp+0x50], xmm5
00007f0254fdd8df  vmovaps [rsp+0x60], xmm6
00007f0254fdd8e5  vmovaps [rsp+0x70], xmm8
00007f0254fdd8eb  vmovaps [rsp+0x80], xmm9
00007f0254fdd8f4  vmovaps [rsp+0x90], xmm10
00007f0254fdd8fd  vmovaps [rsp+0xA0], xmm11
00007f0254fdd906  vmovaps [rsp+0xB0], xmm12
00007f0254fdd90f  vmovaps [rsp+0xC0], xmm13
00007f0254fdd918  vmovaps [rsp+0xD0], xmm14
00007f0254fdd921  vmovaps [rsp+0xE0], xmm15
00007f0254fdd92a  sub rsp, 0x30
00007f0254fdd92e  movaps [rsp], xmm7
00007f0254fdd932  movaps [rsp+0x10], xmm4
00007f0254fdd937  movaps [rsp+0x20], xmm9
00007f0254fdd93d  lea rdi, [rsp]
00007f0254fdd941  mov esi, 0x00
00007f0254fdd946  mov rax, 0x55DD1360A530
00007f0254fdd950  call rax
00007f0254fdd952  movaps xmm7, [rsp]
00007f0254fdd956  add rsp, 0x30
00007f0254fdd95a  vmovaps xmm0, [rsp]
00007f0254fdd95f  vmovaps xmm1, [rsp+0x10]
00007f0254fdd965  vmovaps xmm2, [rsp+0x20]
00007f0254fdd96b  vmovaps xmm3, [rsp+0x30]
00007f0254fdd971  vmovaps xmm4, [rsp+0x40]
00007f0254fdd977  vmovaps xmm5, [rsp+0x50]
00007f0254fdd97d  vmovaps xmm6, [rsp+0x60]
00007f0254fdd983  vmovaps xmm8, [rsp+0x70]
00007f0254fdd989  vmovaps xmm9, [rsp+0x80]
00007f0254fdd992  vmovaps xmm10, [rsp+0x90]
00007f0254fdd99b  vmovaps xmm11, [rsp+0xA0]
00007f0254fdd9a4  vmovaps xmm12, [rsp+0xB0]
00007f0254fdd9ad  vmovaps xmm13, [rsp+0xC0]
00007f0254fdd9b6  vmovaps xmm14, [rsp+0xD0]
00007f0254fdd9bf  vmovaps xmm15, [rsp+0xE0]
00007f0254fdd9c8  add rsp, 0xF0
00007f0254fdd9cf  pop r11
00007f0254fdd9d1  pop r10
00007f0254fdd9d3  pop r9
00007f0254fdd9d5  pop r8
00007f0254fdd9d7  pop rsi
00007f0254fdd9d8  pop rdi
00007f0254fdd9d9  pop rdx
00007f0254fdd9da  pop rcx
00007f0254fdd9db  pop rax
00007f0254fdd9dc  add rsp, 0x08
00007f0254fdd9e0  jmp 0x00007F0254FDBE87
00007f0254fdd9e5  sub rsp, 0x08
00007f0254fdd9e9  push rax
00007f0254fdd9ea  push rcx
00007f0254fdd9eb  push rdx
00007f0254fdd9ec  push rdi
00007f0254fdd9ed  push rsi
00007f0254fdd9ee  push r8
00007f0254fdd9f0  push r9
00007f0254fdd9f2  push r10
00007f0254fdd9f4  push r11
00007f0254fdd9f6  sub rsp, 0xF0
00007f0254fdd9fd  vmovaps [rsp], xmm0
00007f0254fdda02  vmovaps [rsp+0x10], xmm1
00007f0254fdda08  vmovaps [rsp+0x20], xmm2
00007f0254fdda0e  vmovaps [rsp+0x30], xmm3
00007f0254fdda14  vmovaps [rsp+0x40], xmm5
00007f0254fdda1a  vmovaps [rsp+0x50], xmm6
00007f0254fdda20  vmovaps [rsp+0x60], xmm7
00007f0254fdda26  vmovaps [rsp+0x70], xmm8
00007f0254fdda2c  vmovaps [rsp+0x80], xmm9
00007f0254fdda35  vmovaps [rsp+0x90], xmm10
00007f0254fdda3e  vmovaps [rsp+0xA0], xmm11
00007f0254fdda47  vmovaps [rsp+0xB0], xmm12
00007f0254fdda50  vmovaps [rsp+0xC0], xmm13
00007f0254fdda59  vmovaps [rsp+0xD0], xmm14
00007f0254fdda62  vmovaps [rsp+0xE0], xmm15
00007f0254fdda6b  sub rsp, 0x30
00007f0254fdda6f  movaps [rsp], xmm4
00007f0254fdda73  movaps [rsp+0x10], xmm15
00007f0254fdda79  movaps [rsp+0x20], xmm9
00007f0254fdda7f  lea rdi, [rsp]
00007f0254fdda83  mov esi, 0x00
00007f0254fdda88  mov rax, 0x55DD1360A530
00007f0254fdda92  call rax
00007f0254fdda94  movaps xmm4, [rsp]
00007f0254fdda98  add rsp, 0x30
00007f0254fdda9c  vmovaps xmm0, [rsp]
00007f0254fddaa1  vmovaps xmm1, [rsp+0x10]
00007f0254fddaa7  vmovaps xmm2, [rsp+0x20]
00007f0254fddaad  vmovaps xmm3, [rsp+0x30]
00007f0254fddab3  vmovaps xmm5, [rsp+0x40]
00007f0254fddab9  vmovaps xmm6, [rsp+0x50]
00007f0254fddabf  vmovaps xmm7, [rsp+0x60]
00007f0254fddac5  vmovaps xmm8, [rsp+0x70]
00007f0254fddacb  vmovaps xmm9, [rsp+0x80]
00007f0254fddad4  vmovaps xmm10, [rsp+0x90]
00007f0254fddadd  vmovaps xmm11, [rsp+0xA0]
00007f0254fddae6  vmovaps xmm12, [rsp+0xB0]
00007f0254fddaef  vmovaps xmm13, [rsp+0xC0]
00007f0254fddaf8  vmovaps xmm14, [rsp+0xD0]
00007f0254fddb01  vmovaps xmm15, [rsp+0xE0]
00007f0254fddb0a  add rsp, 0xF0
00007f0254fddb11  pop r11
00007f0254fddb13  pop r10
00007f0254fddb15  pop r9
00007f0254fddb17  pop r8
00007f0254fddb19  pop rsi
00007f0254fddb1a  pop rdi
00007f0254fddb1b  pop rdx
00007f0254fddb1c  pop rcx
00007f0254fddb1d  pop rax
00007f0254fddb1e  add rsp, 0x08
00007f0254fddb22  jmp 0x00007F0254FDBEAC
00007f0254fddb27  call 0x00007F0254EC4620
00007f0254fddb2c  jmp 0x00007F0254FDBEB9
00007f0254fddb31  sub rsp, 0x08
00007f0254fddb35  push rax
00007f0254fddb36  push rcx
00007f0254fddb37  push rdx
00007f0254fddb38  push rdi
00007f0254fddb39  push rsi
00007f0254fddb3a  push r8
00007f0254fddb3c  push r9
00007f0254fddb3e  push r10
00007f0254fddb40  push r11
00007f0254fddb42  sub rsp, 0xF0
00007f0254fddb49  vmovaps [rsp], xmm0
00007f0254fddb4e  vmovaps [rsp+0x10], xmm1
00007f0254fddb54  vmovaps [rsp+0x20], xmm2
00007f0254fddb5a  vmovaps [rsp+0x30], xmm4
00007f0254fddb60  vmovaps [rsp+0x40], xmm5
00007f0254fddb66  vmovaps [rsp+0x50], xmm6
00007f0254fddb6c  vmovaps [rsp+0x60], xmm7
00007f0254fddb72  vmovaps [rsp+0x70], xmm8
00007f0254fddb78  vmovaps [rsp+0x80], xmm9
00007f0254fddb81  vmovaps [rsp+0x90], xmm10
00007f0254fddb8a  vmovaps [rsp+0xA0], xmm11
00007f0254fddb93  vmovaps [rsp+0xB0], xmm12
00007f0254fddb9c  vmovaps [rsp+0xC0], xmm13
00007f0254fddba5  vmovaps [rsp+0xD0], xmm14
00007f0254fddbae  vmovaps [rsp+0xE0], xmm15
00007f0254fddbb7  sub rsp, 0x30
00007f0254fddbbb  movaps [rsp], xmm3
00007f0254fddbbf  movaps [rsp+0x10], xmm1
00007f0254fddbc4  movaps [rsp+0x20], xmm9
00007f0254fddbca  lea rdi, [rsp]
00007f0254fddbce  mov esi, 0x00
00007f0254fddbd3  mov rax, 0x55DD1360A530
00007f0254fddbdd  call rax
00007f0254fddbdf  movaps xmm3, [rsp]
00007f0254fddbe3  add rsp, 0x30
00007f0254fddbe7  vmovaps xmm0, [rsp]
00007f0254fddbec  vmovaps xmm1, [rsp+0x10]
00007f0254fddbf2  vmovaps xmm2, [rsp+0x20]
00007f0254fddbf8  vmovaps xmm4, [rsp+0x30]
00007f0254fddbfe  vmovaps xmm5, [rsp+0x40]
00007f0254fddc04  vmovaps xmm6, [rsp+0x50]
00007f0254fddc0a  vmovaps xmm7, [rsp+0x60]
00007f0254fddc10  vmovaps xmm8, [rsp+0x70]
00007f0254fddc16  vmovaps xmm9, [rsp+0x80]
00007f0254fddc1f  vmovaps xmm10, [rsp+0x90]
00007f0254fddc28  vmovaps xmm11, [rsp+0xA0]
00007f0254fddc31  vmovaps xmm12, [rsp+0xB0]
00007f0254fddc3a  vmovaps xmm13, [rsp+0xC0]
00007f0254fddc43  vmovaps xmm14, [rsp+0xD0]
00007f0254fddc4c  vmovaps xmm15, [rsp+0xE0]
00007f0254fddc55  add rsp, 0xF0
00007f0254fddc5c  pop r11
00007f0254fddc5e  pop r10
00007f0254fddc60  pop r9
00007f0254fddc62  pop r8
00007f0254fddc64  pop rsi
00007f0254fddc65  pop rdi
00007f0254fddc66  pop rdx
00007f0254fddc67  pop rcx
00007f0254fddc68  pop rax
00007f0254fddc69  add rsp, 0x08
00007f0254fddc6d  jmp 0x00007F0254FDBEF6
00007f0254fddc72  sub rsp, 0x08
00007f0254fddc76  push rax
00007f0254fddc77  push rcx
00007f0254fddc78  push rdx
00007f0254fddc79  push rdi
00007f0254fddc7a  push rsi
00007f0254fddc7b  push r8
00007f0254fddc7d  push r9
00007f0254fddc7f  push r10
00007f0254fddc81  push r11
00007f0254fddc83  sub rsp, 0xF0
00007f0254fddc8a  vmovaps [rsp], xmm0
00007f0254fddc8f  vmovaps [rsp+0x10], xmm2
00007f0254fddc95  vmovaps [rsp+0x20], xmm3
00007f0254fddc9b  vmovaps [rsp+0x30], xmm4
00007f0254fddca1  vmovaps [rsp+0x40], xmm5
00007f0254fddca7  vmovaps [rsp+0x50], xmm6
00007f0254fddcad  vmovaps [rsp+0x60], xmm7
00007f0254fddcb3  vmovaps [rsp+0x70], xmm8
00007f0254fddcb9  vmovaps [rsp+0x80], xmm9
00007f0254fddcc2  vmovaps [rsp+0x90], xmm10
00007f0254fddccb  vmovaps [rsp+0xA0], xmm11
00007f0254fddcd4  vmovaps [rsp+0xB0], xmm12
00007f0254fddcdd  vmovaps [rsp+0xC0], xmm13
00007f0254fddce6  vmovaps [rsp+0xD0], xmm14
00007f0254fddcef  vmovaps [rsp+0xE0], xmm15
00007f0254fddcf8  sub rsp, 0x30
00007f0254fddcfc  movaps [rsp], xmm1
00007f0254fddd00  movaps [rsp+0x10], xmm15
00007f0254fddd06  movaps [rsp+0x20], xmm9
00007f0254fddd0c  lea rdi, [rsp]
00007f0254fddd10  mov esi, 0x00
00007f0254fddd15  mov rax, 0x55DD1360A530
00007f0254fddd1f  call rax
00007f0254fddd21  movaps xmm1, [rsp]
00007f0254fddd25  add rsp, 0x30
00007f0254fddd29  vmovaps xmm0, [rsp]
00007f0254fddd2e  vmovaps xmm2, [rsp+0x10]
00007f0254fddd34  vmovaps xmm3, [rsp+0x20]
00007f0254fddd3a  vmovaps xmm4, [rsp+0x30]
00007f0254fddd40  vmovaps xmm5, [rsp+0x40]
00007f0254fddd46  vmovaps xmm6, [rsp+0x50]
00007f0254fddd4c  vmovaps xmm7, [rsp+0x60]
00007f0254fddd52  vmovaps xmm8, [rsp+0x70]
00007f0254fddd58  vmovaps xmm9, [rsp+0x80]
00007f0254fddd61  vmovaps xmm10, [rsp+0x90]
00007f0254fddd6a  vmovaps xmm11, [rsp+0xA0]
00007f0254fddd73  vmovaps xmm12, [rsp+0xB0]
00007f0254fddd7c  vmovaps xmm13, [rsp+0xC0]
00007f0254fddd85  vmovaps xmm14, [rsp+0xD0]
00007f0254fddd8e  vmovaps xmm15, [rsp+0xE0]
00007f0254fddd97  add rsp, 0xF0
00007f0254fddd9e  pop r11
00007f0254fddda0  pop r10
00007f0254fddda2  pop r9
00007f0254fddda4  pop r8
00007f0254fddda6  pop rsi
00007f0254fddda7  pop rdi
00007f0254fddda8  pop rdx
00007f0254fddda9  pop rcx
00007f0254fdddaa  pop rax
00007f0254fdddab  add rsp, 0x08
00007f0254fdddaf  jmp 0x00007F0254FDBF7E
00007f0254fdddb4  call 0x00007F0254EC4620
00007f0254fdddb9  jmp 0x00007F0254FDBF8B
00007f0254fdddbe  sub rsp, 0x08
00007f0254fdddc2  push rax
00007f0254fdddc3  push rcx
00007f0254fdddc4  push rdx
00007f0254fdddc5  push rdi
00007f0254fdddc6  push rsi
00007f0254fdddc7  push r8
00007f0254fdddc9  push r9
00007f0254fdddcb  push r10
00007f0254fdddcd  push r11
00007f0254fdddcf  sub rsp, 0xF0
00007f0254fdddd6  vmovaps [rsp], xmm0
00007f0254fddddb  vmovaps [rsp+0x10], xmm2
00007f0254fddde1  vmovaps [rsp+0x20], xmm3
00007f0254fddde7  vmovaps [rsp+0x30], xmm4
00007f0254fddded  vmovaps [rsp+0x40], xmm5
00007f0254fdddf3  vmovaps [rsp+0x50], xmm6
00007f0254fdddf9  vmovaps [rsp+0x60], xmm7
00007f0254fdddff  vmovaps [rsp+0x70], xmm8
00007f0254fdde05  vmovaps [rsp+0x80], xmm9
00007f0254fdde0e  vmovaps [rsp+0x90], xmm10
00007f0254fdde17  vmovaps [rsp+0xA0], xmm11
00007f0254fdde20  vmovaps [rsp+0xB0], xmm12
00007f0254fdde29  vmovaps [rsp+0xC0], xmm13
00007f0254fdde32  vmovaps [rsp+0xD0], xmm14
00007f0254fdde3b  vmovaps [rsp+0xE0], xmm15
00007f0254fdde44  sub rsp, 0x30
00007f0254fdde48  movaps [rsp], xmm1
00007f0254fdde4c  movaps [rsp+0x10], xmm5
00007f0254fdde51  movaps [rsp+0x20], xmm7
00007f0254fdde56  lea rdi, [rsp]
00007f0254fdde5a  mov esi, 0x00
00007f0254fdde5f  mov rax, 0x55DD1360A530
00007f0254fdde69  call rax
00007f0254fdde6b  movaps xmm1, [rsp]
00007f0254fdde6f  add rsp, 0x30
00007f0254fdde73  vmovaps xmm0, [rsp]
00007f0254fdde78  vmovaps xmm2, [rsp+0x10]
00007f0254fdde7e  vmovaps xmm3, [rsp+0x20]
00007f0254fdde84  vmovaps xmm4, [rsp+0x30]
00007f0254fdde8a  vmovaps xmm5, [rsp+0x40]
00007f0254fdde90  vmovaps xmm6, [rsp+0x50]
00007f0254fdde96  vmovaps xmm7, [rsp+0x60]
00007f0254fdde9c  vmovaps xmm8, [rsp+0x70]
00007f0254fddea2  vmovaps xmm9, [rsp+0x80]
00007f0254fddeab  vmovaps xmm10, [rsp+0x90]
00007f0254fddeb4  vmovaps xmm11, [rsp+0xA0]
00007f0254fddebd  vmovaps xmm12, [rsp+0xB0]
00007f0254fddec6  vmovaps xmm13, [rsp+0xC0]
00007f0254fddecf  vmovaps xmm14, [rsp+0xD0]
00007f0254fdded8  vmovaps xmm15, [rsp+0xE0]
00007f0254fddee1  add rsp, 0xF0
00007f0254fddee8  pop r11
00007f0254fddeea  pop r10
00007f0254fddeec  pop r9
00007f0254fddeee  pop r8
00007f0254fddef0  pop rsi
00007f0254fddef1  pop rdi
00007f0254fddef2  pop rdx
00007f0254fddef3  pop rcx
00007f0254fddef4  pop rax
00007f0254fddef5  add rsp, 0x08
00007f0254fddef9  jmp 0x00007F0254FDC030
00007f0254fddefe  sub rsp, 0x08
00007f0254fddf02  push rax
00007f0254fddf03  push rcx
00007f0254fddf04  push rdx
00007f0254fddf05  push rdi
00007f0254fddf06  push rsi
00007f0254fddf07  push r8
00007f0254fddf09  push r9
00007f0254fddf0b  push r10
00007f0254fddf0d  push r11
00007f0254fddf0f  sub rsp, 0xF0
00007f0254fddf16  vmovaps [rsp], xmm0
00007f0254fddf1b  vmovaps [rsp+0x10], xmm1
00007f0254fddf21  vmovaps [rsp+0x20], xmm2
00007f0254fddf27  vmovaps [rsp+0x30], xmm3
00007f0254fddf2d  vmovaps [rsp+0x40], xmm4
00007f0254fddf33  vmovaps [rsp+0x50], xmm5
00007f0254fddf39  vmovaps [rsp+0x60], xmm6
00007f0254fddf3f  vmovaps [rsp+0x70], xmm8
00007f0254fddf45  vmovaps [rsp+0x80], xmm9
00007f0254fddf4e  vmovaps [rsp+0x90], xmm10
00007f0254fddf57  vmovaps [rsp+0xA0], xmm11
00007f0254fddf60  vmovaps [rsp+0xB0], xmm12
00007f0254fddf69  vmovaps [rsp+0xC0], xmm13
00007f0254fddf72  vmovaps [rsp+0xD0], xmm14
00007f0254fddf7b  vmovaps [rsp+0xE0], xmm15
00007f0254fddf84  sub rsp, 0x30
00007f0254fddf88  movaps [rsp], xmm7
00007f0254fddf8c  movaps [rsp+0x10], xmm5
00007f0254fddf91  movaps [rsp+0x20], xmm15
00007f0254fddf97  lea rdi, [rsp]
00007f0254fddf9b  mov esi, 0x00
00007f0254fddfa0  mov rax, 0x55DD1360A530
00007f0254fddfaa  call rax
00007f0254fddfac  movaps xmm7, [rsp]
00007f0254fddfb0  add rsp, 0x30
00007f0254fddfb4  vmovaps xmm0, [rsp]
00007f0254fddfb9  vmovaps xmm1, [rsp+0x10]
00007f0254fddfbf  vmovaps xmm2, [rsp+0x20]
00007f0254fddfc5  vmovaps xmm3, [rsp+0x30]
00007f0254fddfcb  vmovaps xmm4, [rsp+0x40]
00007f0254fddfd1  vmovaps xmm5, [rsp+0x50]
00007f0254fddfd7  vmovaps xmm6, [rsp+0x60]
00007f0254fddfdd  vmovaps xmm8, [rsp+0x70]
00007f0254fddfe3  vmovaps xmm9, [rsp+0x80]
00007f0254fddfec  vmovaps xmm10, [rsp+0x90]
00007f0254fddff5  vmovaps xmm11, [rsp+0xA0]
00007f0254fddffe  vmovaps xmm12, [rsp+0xB0]
00007f0254fde007  vmovaps xmm13, [rsp+0xC0]
00007f0254fde010  vmovaps xmm14, [rsp+0xD0]
00007f0254fde019  vmovaps xmm15, [rsp+0xE0]
00007f0254fde022  add rsp, 0xF0
00007f0254fde029  pop r11
00007f0254fde02b  pop r10
00007f0254fde02d  pop r9
00007f0254fde02f  pop r8
00007f0254fde031  pop rsi
00007f0254fde032  pop rdi
00007f0254fde033  pop rdx
00007f0254fde034  pop rcx
00007f0254fde035  pop rax
00007f0254fde036  add rsp, 0x08
00007f0254fde03a  jmp 0x00007F0254FDC066
00007f0254fde03f  call 0x00007F0254EB52F0
00007f0254fde044  jmp 0x00007F0254FDC073
00007f0254fde049  sub rsp, 0x08
00007f0254fde04d  push rax
00007f0254fde04e  push rcx
00007f0254fde04f  push rdx
00007f0254fde050  push rdi
00007f0254fde051  push rsi
00007f0254fde052  push r8
00007f0254fde054  push r9
00007f0254fde056  push r10
00007f0254fde058  push r11
00007f0254fde05a  sub rsp, 0xF0
00007f0254fde061  vmovaps [rsp], xmm0
00007f0254fde066  vmovaps [rsp+0x10], xmm1
00007f0254fde06c  vmovaps [rsp+0x20], xmm2
00007f0254fde072  vmovaps [rsp+0x30], xmm3
00007f0254fde078  vmovaps [rsp+0x40], xmm4
00007f0254fde07e  vmovaps [rsp+0x50], xmm5
00007f0254fde084  vmovaps [rsp+0x60], xmm6
00007f0254fde08a  vmovaps [rsp+0x70], xmm7
00007f0254fde090  vmovaps [rsp+0x80], xmm8
00007f0254fde099  vmovaps [rsp+0x90], xmm9
00007f0254fde0a2  vmovaps [rsp+0xA0], xmm10
00007f0254fde0ab  vmovaps [rsp+0xB0], xmm11
00007f0254fde0b4  vmovaps [rsp+0xC0], xmm12
00007f0254fde0bd  vmovaps [rsp+0xD0], xmm13
00007f0254fde0c6  vmovaps [rsp+0xE0], xmm14
00007f0254fde0cf  sub rsp, 0x30
00007f0254fde0d3  movaps [rsp], xmm15
00007f0254fde0d8  movaps [rsp+0x10], xmm5
00007f0254fde0dd  movaps [rsp+0x20], xmm3
00007f0254fde0e2  lea rdi, [rsp]
00007f0254fde0e6  mov esi, 0x00
00007f0254fde0eb  mov rax, 0x55DD1360A530
00007f0254fde0f5  call rax
00007f0254fde0f7  movaps xmm15, [rsp]
00007f0254fde0fc  add rsp, 0x30
00007f0254fde100  vmovaps xmm0, [rsp]
00007f0254fde105  vmovaps xmm1, [rsp+0x10]
00007f0254fde10b  vmovaps xmm2, [rsp+0x20]
00007f0254fde111  vmovaps xmm3, [rsp+0x30]
00007f0254fde117  vmovaps xmm4, [rsp+0x40]
00007f0254fde11d  vmovaps xmm5, [rsp+0x50]
00007f0254fde123  vmovaps xmm6, [rsp+0x60]
00007f0254fde129  vmovaps xmm7, [rsp+0x70]
00007f0254fde12f  vmovaps xmm8, [rsp+0x80]
00007f0254fde138  vmovaps xmm9, [rsp+0x90]
00007f0254fde141  vmovaps xmm10, [rsp+0xA0]
00007f0254fde14a  vmovaps xmm11, [rsp+0xB0]
00007f0254fde153  vmovaps xmm12, [rsp+0xC0]
00007f0254fde15c  vmovaps xmm13, [rsp+0xD0]
00007f0254fde165  vmovaps xmm14, [rsp+0xE0]
00007f0254fde16e  add rsp, 0xF0
00007f0254fde175  pop r11
00007f0254fde177  pop r10
00007f0254fde179  pop r9
00007f0254fde17b  pop r8
00007f0254fde17d  pop rsi
00007f0254fde17e  pop rdi
00007f0254fde17f  pop rdx
00007f0254fde180  pop rcx
00007f0254fde181  pop rax
00007f0254fde182  add rsp, 0x08
00007f0254fde186  jmp 0x00007F0254FDC099
00007f0254fde18b  sub rsp, 0x08
00007f0254fde18f  push rax
00007f0254fde190  push rcx
00007f0254fde191  push rdx
00007f0254fde192  push rdi
00007f0254fde193  push rsi
00007f0254fde194  push r8
00007f0254fde196  push r9
00007f0254fde198  push r10
00007f0254fde19a  push r11
00007f0254fde19c  sub rsp, 0xF0
00007f0254fde1a3  vmovaps [rsp], xmm0
00007f0254fde1a8  vmovaps [rsp+0x10], xmm2
00007f0254fde1ae  vmovaps [rsp+0x20], xmm3
00007f0254fde1b4  vmovaps [rsp+0x30], xmm4
00007f0254fde1ba  vmovaps [rsp+0x40], xmm5
00007f0254fde1c0  vmovaps [rsp+0x50], xmm6
00007f0254fde1c6  vmovaps [rsp+0x60], xmm7
00007f0254fde1cc  vmovaps [rsp+0x70], xmm8
00007f0254fde1d2  vmovaps [rsp+0x80], xmm9
00007f0254fde1db  vmovaps [rsp+0x90], xmm10
00007f0254fde1e4  vmovaps [rsp+0xA0], xmm11
00007f0254fde1ed  vmovaps [rsp+0xB0], xmm12
00007f0254fde1f6  vmovaps [rsp+0xC0], xmm13
00007f0254fde1ff  vmovaps [rsp+0xD0], xmm14
00007f0254fde208  vmovaps [rsp+0xE0], xmm15
00007f0254fde211  sub rsp, 0x30
00007f0254fde215  movaps [rsp], xmm1
00007f0254fde219  movaps [rsp+0x10], xmm5
00007f0254fde21e  movaps [rsp+0x20], xmm4
00007f0254fde223  lea rdi, [rsp]
00007f0254fde227  mov esi, 0x00
00007f0254fde22c  mov rax, 0x55DD1360A530
00007f0254fde236  call rax
00007f0254fde238  movaps xmm1, [rsp]
00007f0254fde23c  add rsp, 0x30
00007f0254fde240  vmovaps xmm0, [rsp]
00007f0254fde245  vmovaps xmm2, [rsp+0x10]
00007f0254fde24b  vmovaps xmm3, [rsp+0x20]
00007f0254fde251  vmovaps xmm4, [rsp+0x30]
00007f0254fde257  vmovaps xmm5, [rsp+0x40]
00007f0254fde25d  vmovaps xmm6, [rsp+0x50]
00007f0254fde263  vmovaps xmm7, [rsp+0x60]
00007f0254fde269  vmovaps xmm8, [rsp+0x70]
00007f0254fde26f  vmovaps xmm9, [rsp+0x80]
00007f0254fde278  vmovaps xmm10, [rsp+0x90]
00007f0254fde281  vmovaps xmm11, [rsp+0xA0]
00007f0254fde28a  vmovaps xmm12, [rsp+0xB0]
00007f0254fde293  vmovaps xmm13, [rsp+0xC0]
00007f0254fde29c  vmovaps xmm14, [rsp+0xD0]
00007f0254fde2a5  vmovaps xmm15, [rsp+0xE0]
00007f0254fde2ae  add rsp, 0xF0
00007f0254fde2b5  pop r11
00007f0254fde2b7  pop r10
00007f0254fde2b9  pop r9
00007f0254fde2bb  pop r8
00007f0254fde2bd  pop rsi
00007f0254fde2be  pop rdi
00007f0254fde2bf  pop rdx
00007f0254fde2c0  pop rcx
00007f0254fde2c1  pop rax
00007f0254fde2c2  add rsp, 0x08
00007f0254fde2c6  jmp 0x00007F0254FDC0B9
00007f0254fde2cb  sub rsp, 0x08
00007f0254fde2cf  push rax
00007f0254fde2d0  push rcx
00007f0254fde2d1  push rdx
00007f0254fde2d2  push rdi
00007f0254fde2d3  push rsi
00007f0254fde2d4  push r8
00007f0254fde2d6  push r9
00007f0254fde2d8  push r10
00007f0254fde2da  push r11
00007f0254fde2dc  sub rsp, 0xF0
00007f0254fde2e3  vmovaps [rsp], xmm0
00007f0254fde2e8  vmovaps [rsp+0x10], xmm1
00007f0254fde2ee  vmovaps [rsp+0x20], xmm2
00007f0254fde2f4  vmovaps [rsp+0x30], xmm3
00007f0254fde2fa  vmovaps [rsp+0x40], xmm5
00007f0254fde300  vmovaps [rsp+0x50], xmm6
00007f0254fde306  vmovaps [rsp+0x60], xmm7
00007f0254fde30c  vmovaps [rsp+0x70], xmm8
00007f0254fde312  vmovaps [rsp+0x80], xmm9
00007f0254fde31b  vmovaps [rsp+0x90], xmm10
00007f0254fde324  vmovaps [rsp+0xA0], xmm11
00007f0254fde32d  vmovaps [rsp+0xB0], xmm12
00007f0254fde336  vmovaps [rsp+0xC0], xmm13
00007f0254fde33f  vmovaps [rsp+0xD0], xmm14
00007f0254fde348  vmovaps [rsp+0xE0], xmm15
00007f0254fde351  sub rsp, 0x30
00007f0254fde355  movaps [rsp], xmm4
00007f0254fde359  movaps [rsp+0x10], xmm3
00007f0254fde35e  movaps [rsp+0x20], xmm5
00007f0254fde363  lea rdi, [rsp]
00007f0254fde367  mov esi, 0x00
00007f0254fde36c  mov rax, 0x55DD1360A530
00007f0254fde376  call rax
00007f0254fde378  movaps xmm4, [rsp]
00007f0254fde37c  add rsp, 0x30
00007f0254fde380  vmovaps xmm0, [rsp]
00007f0254fde385  vmovaps xmm1, [rsp+0x10]
00007f0254fde38b  vmovaps xmm2, [rsp+0x20]
00007f0254fde391  vmovaps xmm3, [rsp+0x30]
00007f0254fde397  vmovaps xmm5, [rsp+0x40]
00007f0254fde39d  vmovaps xmm6, [rsp+0x50]
00007f0254fde3a3  vmovaps xmm7, [rsp+0x60]
00007f0254fde3a9  vmovaps xmm8, [rsp+0x70]
00007f0254fde3af  vmovaps xmm9, [rsp+0x80]
00007f0254fde3b8  vmovaps xmm10, [rsp+0x90]
00007f0254fde3c1  vmovaps xmm11, [rsp+0xA0]
00007f0254fde3ca  vmovaps xmm12, [rsp+0xB0]
00007f0254fde3d3  vmovaps xmm13, [rsp+0xC0]
00007f0254fde3dc  vmovaps xmm14, [rsp+0xD0]
00007f0254fde3e5  vmovaps xmm15, [rsp+0xE0]
00007f0254fde3ee  add rsp, 0xF0
00007f0254fde3f5  pop r11
00007f0254fde3f7  pop r10
00007f0254fde3f9  pop r9
00007f0254fde3fb  pop r8
00007f0254fde3fd  pop rsi
00007f0254fde3fe  pop rdi
00007f0254fde3ff  pop rdx
00007f0254fde400  pop rcx
00007f0254fde401  pop rax
00007f0254fde402  add rsp, 0x08
00007f0254fde406  jmp 0x00007F0254FDC107
00007f0254fde40b  call 0x00007F0254EB52F0
00007f0254fde410  jmp 0x00007F0254FDC114
00007f0254fde415  sub rsp, 0x08
00007f0254fde419  push rax
00007f0254fde41a  push rcx
00007f0254fde41b  push rdx
00007f0254fde41c  push rdi
00007f0254fde41d  push rsi
00007f0254fde41e  push r8
00007f0254fde420  push r9
00007f0254fde422  push r10
00007f0254fde424  push r11
00007f0254fde426  sub rsp, 0xF0
00007f0254fde42d  vmovaps [rsp], xmm0
00007f0254fde432  vmovaps [rsp+0x10], xmm1
00007f0254fde438  vmovaps [rsp+0x20], xmm2
00007f0254fde43e  vmovaps [rsp+0x30], xmm3
00007f0254fde444  vmovaps [rsp+0x40], xmm4
00007f0254fde44a  vmovaps [rsp+0x50], xmm6
00007f0254fde450  vmovaps [rsp+0x60], xmm7
00007f0254fde456  vmovaps [rsp+0x70], xmm8
00007f0254fde45c  vmovaps [rsp+0x80], xmm9
00007f0254fde465  vmovaps [rsp+0x90], xmm10
00007f0254fde46e  vmovaps [rsp+0xA0], xmm11
00007f0254fde477  vmovaps [rsp+0xB0], xmm12
00007f0254fde480  vmovaps [rsp+0xC0], xmm13
00007f0254fde489  vmovaps [rsp+0xD0], xmm14
00007f0254fde492  vmovaps [rsp+0xE0], xmm15
00007f0254fde49b  sub rsp, 0x30
00007f0254fde49f  movaps [rsp], xmm5
00007f0254fde4a3  movaps [rsp+0x10], xmm6
00007f0254fde4a8  movaps [rsp+0x20], xmm3
00007f0254fde4ad  lea rdi, [rsp]
00007f0254fde4b1  mov esi, 0x00
00007f0254fde4b6  mov rax, 0x55DD1360A530
00007f0254fde4c0  call rax
00007f0254fde4c2  movaps xmm5, [rsp]
00007f0254fde4c6  add rsp, 0x30
00007f0254fde4ca  vmovaps xmm0, [rsp]
00007f0254fde4cf  vmovaps xmm1, [rsp+0x10]
00007f0254fde4d5  vmovaps xmm2, [rsp+0x20]
00007f0254fde4db  vmovaps xmm3, [rsp+0x30]
00007f0254fde4e1  vmovaps xmm4, [rsp+0x40]
00007f0254fde4e7  vmovaps xmm6, [rsp+0x50]
00007f0254fde4ed  vmovaps xmm7, [rsp+0x60]
00007f0254fde4f3  vmovaps xmm8, [rsp+0x70]
00007f0254fde4f9  vmovaps xmm9, [rsp+0x80]
00007f0254fde502  vmovaps xmm10, [rsp+0x90]
00007f0254fde50b  vmovaps xmm11, [rsp+0xA0]
00007f0254fde514  vmovaps xmm12, [rsp+0xB0]
00007f0254fde51d  vmovaps xmm13, [rsp+0xC0]
00007f0254fde526  vmovaps xmm14, [rsp+0xD0]
00007f0254fde52f  vmovaps xmm15, [rsp+0xE0]
00007f0254fde538  add rsp, 0xF0
00007f0254fde53f  pop r11
00007f0254fde541  pop r10
00007f0254fde543  pop r9
00007f0254fde545  pop r8
00007f0254fde547  pop rsi
00007f0254fde548  pop rdi
00007f0254fde549  pop rdx
00007f0254fde54a  pop rcx
00007f0254fde54b  pop rax
00007f0254fde54c  add rsp, 0x08
00007f0254fde550  jmp 0x00007F0254FDC13A
00007f0254fde555  sub rsp, 0x08
00007f0254fde559  push rax
00007f0254fde55a  push rcx
00007f0254fde55b  push rdx
00007f0254fde55c  push rdi
00007f0254fde55d  push rsi
00007f0254fde55e  push r8
00007f0254fde560  push r9
00007f0254fde562  push r10
00007f0254fde564  push r11
00007f0254fde566  sub rsp, 0xF0
00007f0254fde56d  vmovaps [rsp], xmm0
00007f0254fde572  vmovaps [rsp+0x10], xmm1
00007f0254fde578  vmovaps [rsp+0x20], xmm2
00007f0254fde57e  vmovaps [rsp+0x30], xmm3
00007f0254fde584  vmovaps [rsp+0x40], xmm4
00007f0254fde58a  vmovaps [rsp+0x50], xmm5
00007f0254fde590  vmovaps [rsp+0x60], xmm7
00007f0254fde596  vmovaps [rsp+0x70], xmm8
00007f0254fde59c  vmovaps [rsp+0x80], xmm9
00007f0254fde5a5  vmovaps [rsp+0x90], xmm10
00007f0254fde5ae  vmovaps [rsp+0xA0], xmm11
00007f0254fde5b7  vmovaps [rsp+0xB0], xmm12
00007f0254fde5c0  vmovaps [rsp+0xC0], xmm13
00007f0254fde5c9  vmovaps [rsp+0xD0], xmm14
00007f0254fde5d2  vmovaps [rsp+0xE0], xmm15
00007f0254fde5db  sub rsp, 0x30
00007f0254fde5df  movaps [rsp], xmm6
00007f0254fde5e3  movaps [rsp+0x10], xmm9
00007f0254fde5e9  movaps [rsp+0x20], xmm1
00007f0254fde5ee  lea rdi, [rsp]
00007f0254fde5f2  mov esi, 0x00
00007f0254fde5f7  mov rax, 0x55DD1360A530
00007f0254fde601  call rax
00007f0254fde603  movaps xmm6, [rsp]
00007f0254fde607  add rsp, 0x30
00007f0254fde60b  vmovaps xmm0, [rsp]
00007f0254fde610  vmovaps xmm1, [rsp+0x10]
00007f0254fde616  vmovaps xmm2, [rsp+0x20]
00007f0254fde61c  vmovaps xmm3, [rsp+0x30]
00007f0254fde622  vmovaps xmm4, [rsp+0x40]
00007f0254fde628  vmovaps xmm5, [rsp+0x50]
00007f0254fde62e  vmovaps xmm7, [rsp+0x60]
00007f0254fde634  vmovaps xmm8, [rsp+0x70]
00007f0254fde63a  vmovaps xmm9, [rsp+0x80]
00007f0254fde643  vmovaps xmm10, [rsp+0x90]
00007f0254fde64c  vmovaps xmm11, [rsp+0xA0]
00007f0254fde655  vmovaps xmm12, [rsp+0xB0]
00007f0254fde65e  vmovaps xmm13, [rsp+0xC0]
00007f0254fde667  vmovaps xmm14, [rsp+0xD0]
00007f0254fde670  vmovaps xmm15, [rsp+0xE0]
00007f0254fde679  add rsp, 0xF0
00007f0254fde680  pop r11
00007f0254fde682  pop r10
00007f0254fde684  pop r9
00007f0254fde686  pop r8
00007f0254fde688  pop rsi
00007f0254fde689  pop rdi
00007f0254fde68a  pop rdx
00007f0254fde68b  pop rcx
00007f0254fde68c  pop rax
00007f0254fde68d  add rsp, 0x08
00007f0254fde691  jmp 0x00007F0254FDC15E
00007f0254fde696  sub rsp, 0x08
00007f0254fde69a  push rax
00007f0254fde69b  push rcx
00007f0254fde69c  push rdx
00007f0254fde69d  push rdi
00007f0254fde69e  push rsi
00007f0254fde69f  push r8
00007f0254fde6a1  push r9
00007f0254fde6a3  push r10
00007f0254fde6a5  push r11
00007f0254fde6a7  sub rsp, 0xF0
00007f0254fde6ae  vmovaps [rsp], xmm0
00007f0254fde6b3  vmovaps [rsp+0x10], xmm1
00007f0254fde6b9  vmovaps [rsp+0x20], xmm2
00007f0254fde6bf  vmovaps [rsp+0x30], xmm3
00007f0254fde6c5  vmovaps [rsp+0x40], xmm4
00007f0254fde6cb  vmovaps [rsp+0x50], xmm5
00007f0254fde6d1  vmovaps [rsp+0x60], xmm6
00007f0254fde6d7  vmovaps [rsp+0x70], xmm7
00007f0254fde6dd  vmovaps [rsp+0x80], xmm8
00007f0254fde6e6  vmovaps [rsp+0x90], xmm10
00007f0254fde6ef  vmovaps [rsp+0xA0], xmm11
00007f0254fde6f8  vmovaps [rsp+0xB0], xmm12
00007f0254fde701  vmovaps [rsp+0xC0], xmm13
00007f0254fde70a  vmovaps [rsp+0xD0], xmm14
00007f0254fde713  vmovaps [rsp+0xE0], xmm15
00007f0254fde71c  sub rsp, 0x30
00007f0254fde720  movaps [rsp], xmm9
00007f0254fde725  movaps [rsp+0x10], xmm3
00007f0254fde72a  movaps [rsp+0x20], xmm1
00007f0254fde72f  lea rdi, [rsp]
00007f0254fde733  mov esi, 0x00
00007f0254fde738  mov rax, 0x55DD1360A530
00007f0254fde742  call rax
00007f0254fde744  movaps xmm9, [rsp]
00007f0254fde749  add rsp, 0x30
00007f0254fde74d  vmovaps xmm0, [rsp]
00007f0254fde752  vmovaps xmm1, [rsp+0x10]
00007f0254fde758  vmovaps xmm2, [rsp+0x20]
00007f0254fde75e  vmovaps xmm3, [rsp+0x30]
00007f0254fde764  vmovaps xmm4, [rsp+0x40]
00007f0254fde76a  vmovaps xmm5, [rsp+0x50]
00007f0254fde770  vmovaps xmm6, [rsp+0x60]
00007f0254fde776  vmovaps xmm7, [rsp+0x70]
00007f0254fde77c  vmovaps xmm8, [rsp+0x80]
00007f0254fde785  vmovaps xmm10, [rsp+0x90]
00007f0254fde78e  vmovaps xmm11, [rsp+0xA0]
00007f0254fde797  vmovaps xmm12, [rsp+0xB0]
00007f0254fde7a0  vmovaps xmm13, [rsp+0xC0]
00007f0254fde7a9  vmovaps xmm14, [rsp+0xD0]
00007f0254fde7b2  vmovaps xmm15, [rsp+0xE0]
00007f0254fde7bb  add rsp, 0xF0
00007f0254fde7c2  pop r11
00007f0254fde7c4  pop r10
00007f0254fde7c6  pop r9
00007f0254fde7c8  pop r8
00007f0254fde7ca  pop rsi
00007f0254fde7cb  pop rdi
00007f0254fde7cc  pop rdx
00007f0254fde7cd  pop rcx
00007f0254fde7ce  pop rax
00007f0254fde7cf  add rsp, 0x08
00007f0254fde7d3  jmp 0x00007F0254FDC1AA
00007f0254fde7d8  call 0x00007F0254EB52F0
00007f0254fde7dd  jmp 0x00007F0254FDC1B7
00007f0254fde7e2  sub rsp, 0x08
00007f0254fde7e6  push rax
00007f0254fde7e7  push rcx
00007f0254fde7e8  push rdx
00007f0254fde7e9  push rdi
00007f0254fde7ea  push rsi
00007f0254fde7eb  push r8
00007f0254fde7ed  push r9
00007f0254fde7ef  push r10
00007f0254fde7f1  push r11
00007f0254fde7f3  sub rsp, 0xF0
00007f0254fde7fa  vmovaps [rsp], xmm0
00007f0254fde7ff  vmovaps [rsp+0x10], xmm1
00007f0254fde805  vmovaps [rsp+0x20], xmm2
00007f0254fde80b  vmovaps [rsp+0x30], xmm3
00007f0254fde811  vmovaps [rsp+0x40], xmm4
00007f0254fde817  vmovaps [rsp+0x50], xmm5
00007f0254fde81d  vmovaps [rsp+0x60], xmm6
00007f0254fde823  vmovaps [rsp+0x70], xmm7
00007f0254fde829  vmovaps [rsp+0x80], xmm8
00007f0254fde832  vmovaps [rsp+0x90], xmm9
00007f0254fde83b  vmovaps [rsp+0xA0], xmm10
00007f0254fde844  vmovaps [rsp+0xB0], xmm11
00007f0254fde84d  vmovaps [rsp+0xC0], xmm12
00007f0254fde856  vmovaps [rsp+0xD0], xmm13
00007f0254fde85f  vmovaps [rsp+0xE0], xmm14
00007f0254fde868  sub rsp, 0x30
00007f0254fde86c  movaps [rsp], xmm15
00007f0254fde871  movaps [rsp+0x10], xmm3
00007f0254fde876  movaps [rsp+0x20], xmm7
00007f0254fde87b  lea rdi, [rsp]
00007f0254fde87f  mov esi, 0x00
00007f0254fde884  mov rax, 0x55DD1360A530
00007f0254fde88e  call rax
00007f0254fde890  movaps xmm15, [rsp]
00007f0254fde895  add rsp, 0x30
00007f0254fde899  vmovaps xmm0, [rsp]
00007f0254fde89e  vmovaps xmm1, [rsp+0x10]
00007f0254fde8a4  vmovaps xmm2, [rsp+0x20]
00007f0254fde8aa  vmovaps xmm3, [rsp+0x30]
00007f0254fde8b0  vmovaps xmm4, [rsp+0x40]
00007f0254fde8b6  vmovaps xmm5, [rsp+0x50]
00007f0254fde8bc  vmovaps xmm6, [rsp+0x60]
00007f0254fde8c2  vmovaps xmm7, [rsp+0x70]
00007f0254fde8c8  vmovaps xmm8, [rsp+0x80]
00007f0254fde8d1  vmovaps xmm9, [rsp+0x90]
00007f0254fde8da  vmovaps xmm10, [rsp+0xA0]
00007f0254fde8e3  vmovaps xmm11, [rsp+0xB0]
00007f0254fde8ec  vmovaps xmm12, [rsp+0xC0]
00007f0254fde8f5  vmovaps xmm13, [rsp+0xD0]
00007f0254fde8fe  vmovaps xmm14, [rsp+0xE0]
00007f0254fde907  add rsp, 0xF0
00007f0254fde90e  pop r11
00007f0254fde910  pop r10
00007f0254fde912  pop r9
00007f0254fde914  pop r8
00007f0254fde916  pop rsi
00007f0254fde917  pop rdi
00007f0254fde918  pop rdx
00007f0254fde919  pop rcx
00007f0254fde91a  pop rax
00007f0254fde91b  add rsp, 0x08
00007f0254fde91f  jmp 0x00007F0254FDC1E3
00007f0254fde924  sub rsp, 0x08
00007f0254fde928  push rax
00007f0254fde929  push rcx
00007f0254fde92a  push rdx
00007f0254fde92b  push rdi
00007f0254fde92c  push rsi
00007f0254fde92d  push r8
00007f0254fde92f  push r9
00007f0254fde931  push r10
00007f0254fde933  push r11
00007f0254fde935  sub rsp, 0xF0
00007f0254fde93c  vmovaps [rsp], xmm0
00007f0254fde941  vmovaps [rsp+0x10], xmm1
00007f0254fde947  vmovaps [rsp+0x20], xmm2
00007f0254fde94d  vmovaps [rsp+0x30], xmm4
00007f0254fde953  vmovaps [rsp+0x40], xmm5
00007f0254fde959  vmovaps [rsp+0x50], xmm6
00007f0254fde95f  vmovaps [rsp+0x60], xmm7
00007f0254fde965  vmovaps [rsp+0x70], xmm8
00007f0254fde96b  vmovaps [rsp+0x80], xmm9
00007f0254fde974  vmovaps [rsp+0x90], xmm10
00007f0254fde97d  vmovaps [rsp+0xA0], xmm11
00007f0254fde986  vmovaps [rsp+0xB0], xmm12
00007f0254fde98f  vmovaps [rsp+0xC0], xmm13
00007f0254fde998  vmovaps [rsp+0xD0], xmm14
00007f0254fde9a1  vmovaps [rsp+0xE0], xmm15
00007f0254fde9aa  sub rsp, 0x30
00007f0254fde9ae  movaps [rsp], xmm3
00007f0254fde9b2  movaps [rsp+0x10], xmm1
00007f0254fde9b7  movaps [rsp+0x20], xmm15
00007f0254fde9bd  lea rdi, [rsp]
00007f0254fde9c1  mov esi, 0x00
00007f0254fde9c6  mov rax, 0x55DD1360A530
00007f0254fde9d0  call rax
00007f0254fde9d2  movaps xmm3, [rsp]
00007f0254fde9d6  add rsp, 0x30
00007f0254fde9da  vmovaps xmm0, [rsp]
00007f0254fde9df  vmovaps xmm1, [rsp+0x10]
00007f0254fde9e5  vmovaps xmm2, [rsp+0x20]
00007f0254fde9eb  vmovaps xmm4, [rsp+0x30]
00007f0254fde9f1  vmovaps xmm5, [rsp+0x40]
00007f0254fde9f7  vmovaps xmm6, [rsp+0x50]
00007f0254fde9fd  vmovaps xmm7, [rsp+0x60]
00007f0254fdea03  vmovaps xmm8, [rsp+0x70]
00007f0254fdea09  vmovaps xmm9, [rsp+0x80]
00007f0254fdea12  vmovaps xmm10, [rsp+0x90]
00007f0254fdea1b  vmovaps xmm11, [rsp+0xA0]
00007f0254fdea24  vmovaps xmm12, [rsp+0xB0]
00007f0254fdea2d  vmovaps xmm13, [rsp+0xC0]
00007f0254fdea36  vmovaps xmm14, [rsp+0xD0]
00007f0254fdea3f  vmovaps xmm15, [rsp+0xE0]
00007f0254fdea48  add rsp, 0xF0
00007f0254fdea4f  pop r11
00007f0254fdea51  pop r10
00007f0254fdea53  pop r9
00007f0254fdea55  pop r8
00007f0254fdea57  pop rsi
00007f0254fdea58  pop rdi
00007f0254fdea59  pop rdx
00007f0254fdea5a  pop rcx
00007f0254fdea5b  pop rax
00007f0254fdea5c  add rsp, 0x08
00007f0254fdea60  jmp 0x00007F0254FDC272
00007f0254fdea65  call 0x00007F0254EB52F0
00007f0254fdea6a  jmp 0x00007F0254FDC27C
00007f0254fdea6f  sub rsp, 0x08
00007f0254fdea73  push rax
00007f0254fdea74  push rcx
00007f0254fdea75  push rdx
00007f0254fdea76  push rdi
00007f0254fdea77  push rsi
00007f0254fdea78  push r8
00007f0254fdea7a  push r9
00007f0254fdea7c  push r10
00007f0254fdea7e  push r11
00007f0254fdea80  sub rsp, 0xF0
00007f0254fdea87  vmovaps [rsp], xmm0
00007f0254fdea8c  vmovaps [rsp+0x10], xmm1
00007f0254fdea92  vmovaps [rsp+0x20], xmm2
00007f0254fdea98  vmovaps [rsp+0x30], xmm3
00007f0254fdea9e  vmovaps [rsp+0x40], xmm4
00007f0254fdeaa4  vmovaps [rsp+0x50], xmm5
00007f0254fdeaaa  vmovaps [rsp+0x60], xmm6
00007f0254fdeab0  vmovaps [rsp+0x70], xmm7
00007f0254fdeab6  vmovaps [rsp+0x80], xmm8
00007f0254fdeabf  vmovaps [rsp+0x90], xmm9
00007f0254fdeac8  vmovaps [rsp+0xA0], xmm10
00007f0254fdead1  vmovaps [rsp+0xB0], xmm11
00007f0254fdeada  vmovaps [rsp+0xC0], xmm12
00007f0254fdeae3  vmovaps [rsp+0xD0], xmm13
00007f0254fdeaec  vmovaps [rsp+0xE0], xmm14
00007f0254fdeaf5  sub rsp, 0x30
00007f0254fdeaf9  movaps [rsp], xmm15
00007f0254fdeafe  movaps [rsp+0x10], xmm14
00007f0254fdeb04  movaps [rsp+0x20], xmm4
00007f0254fdeb09  lea rdi, [rsp]
00007f0254fdeb0d  mov esi, 0x00
00007f0254fdeb12  mov rax, 0x55DD1360A530
00007f0254fdeb1c  call rax
00007f0254fdeb1e  movaps xmm15, [rsp]
00007f0254fdeb23  add rsp, 0x30
00007f0254fdeb27  vmovaps xmm0, [rsp]
00007f0254fdeb2c  vmovaps xmm1, [rsp+0x10]
00007f0254fdeb32  vmovaps xmm2, [rsp+0x20]
00007f0254fdeb38  vmovaps xmm3, [rsp+0x30]
00007f0254fdeb3e  vmovaps xmm4, [rsp+0x40]
00007f0254fdeb44  vmovaps xmm5, [rsp+0x50]
00007f0254fdeb4a  vmovaps xmm6, [rsp+0x60]
00007f0254fdeb50  vmovaps xmm7, [rsp+0x70]
00007f0254fdeb56  vmovaps xmm8, [rsp+0x80]
00007f0254fdeb5f  vmovaps xmm9, [rsp+0x90]
00007f0254fdeb68  vmovaps xmm10, [rsp+0xA0]
00007f0254fdeb71  vmovaps xmm11, [rsp+0xB0]
00007f0254fdeb7a  vmovaps xmm12, [rsp+0xC0]
00007f0254fdeb83  vmovaps xmm13, [rsp+0xD0]
00007f0254fdeb8c  vmovaps xmm14, [rsp+0xE0]
00007f0254fdeb95  add rsp, 0xF0
00007f0254fdeb9c  pop r11
00007f0254fdeb9e  pop r10
00007f0254fdeba0  pop r9
00007f0254fdeba2  pop r8
00007f0254fdeba4  pop rsi
00007f0254fdeba5  pop rdi
00007f0254fdeba6  pop rdx
00007f0254fdeba7  pop rcx
00007f0254fdeba8  pop rax
00007f0254fdeba9  add rsp, 0x08
00007f0254fdebad  jmp 0x00007F0254FDC2AA
00007f0254fdebb2  sub rsp, 0x08
00007f0254fdebb6  push rax
00007f0254fdebb7  push rcx
00007f0254fdebb8  push rdx
00007f0254fdebb9  push rdi
00007f0254fdebba  push rsi
00007f0254fdebbb  push r8
00007f0254fdebbd  push r9
00007f0254fdebbf  push r10
00007f0254fdebc1  push r11
00007f0254fdebc3  sub rsp, 0xF0
00007f0254fdebca  vmovaps [rsp], xmm0
00007f0254fdebcf  vmovaps [rsp+0x10], xmm1
00007f0254fdebd5  vmovaps [rsp+0x20], xmm2
00007f0254fdebdb  vmovaps [rsp+0x30], xmm3
00007f0254fdebe1  vmovaps [rsp+0x40], xmm4
00007f0254fdebe7  vmovaps [rsp+0x50], xmm5
00007f0254fdebed  vmovaps [rsp+0x60], xmm6
00007f0254fdebf3  vmovaps [rsp+0x70], xmm7
00007f0254fdebf9  vmovaps [rsp+0x80], xmm8
00007f0254fdec02  vmovaps [rsp+0x90], xmm9
00007f0254fdec0b  vmovaps [rsp+0xA0], xmm10
00007f0254fdec14  vmovaps [rsp+0xB0], xmm11
00007f0254fdec1d  vmovaps [rsp+0xC0], xmm12
00007f0254fdec26  vmovaps [rsp+0xD0], xmm13
00007f0254fdec2f  vmovaps [rsp+0xE0], xmm15
00007f0254fdec38  sub rsp, 0x30
00007f0254fdec3c  movaps [rsp], xmm14
00007f0254fdec41  movaps [rsp+0x10], xmm2
00007f0254fdec46  movaps [rsp+0x20], xmm1
00007f0254fdec4b  lea rdi, [rsp]
00007f0254fdec4f  mov esi, 0x00
00007f0254fdec54  mov rax, 0x55DD1360A530
00007f0254fdec5e  call rax
00007f0254fdec60  movaps xmm14, [rsp]
00007f0254fdec65  add rsp, 0x30
00007f0254fdec69  vmovaps xmm0, [rsp]
00007f0254fdec6e  vmovaps xmm1, [rsp+0x10]
00007f0254fdec74  vmovaps xmm2, [rsp+0x20]
00007f0254fdec7a  vmovaps xmm3, [rsp+0x30]
00007f0254fdec80  vmovaps xmm4, [rsp+0x40]
00007f0254fdec86  vmovaps xmm5, [rsp+0x50]
00007f0254fdec8c  vmovaps xmm6, [rsp+0x60]
00007f0254fdec92  vmovaps xmm7, [rsp+0x70]
00007f0254fdec98  vmovaps xmm8, [rsp+0x80]
00007f0254fdeca1  vmovaps xmm9, [rsp+0x90]
00007f0254fdecaa  vmovaps xmm10, [rsp+0xA0]
00007f0254fdecb3  vmovaps xmm11, [rsp+0xB0]
00007f0254fdecbc  vmovaps xmm12, [rsp+0xC0]
00007f0254fdecc5  vmovaps xmm13, [rsp+0xD0]
00007f0254fdecce  vmovaps xmm15, [rsp+0xE0]
00007f0254fdecd7  add rsp, 0xF0
00007f0254fdecde  pop r11
00007f0254fdece0  pop r10
00007f0254fdece2  pop r9
00007f0254fdece4  pop r8
00007f0254fdece6  pop rsi
00007f0254fdece7  pop rdi
00007f0254fdece8  pop rdx
00007f0254fdece9  pop rcx
00007f0254fdecea  pop rax
00007f0254fdeceb  add rsp, 0x08
00007f0254fdecef  jmp 0x00007F0254FDC2D0
00007f0254fdecf4  sub rsp, 0x08
00007f0254fdecf8  push rax
00007f0254fdecf9  push rcx
00007f0254fdecfa  push rdx
00007f0254fdecfb  push rdi
00007f0254fdecfc  push rsi
00007f0254fdecfd  push r8
00007f0254fdecff  push r9
00007f0254fded01  push r10
00007f0254fded03  push r11
00007f0254fded05  sub rsp, 0xF0
00007f0254fded0c  vmovaps [rsp], xmm0
00007f0254fded11  vmovaps [rsp+0x10], xmm2
00007f0254fded17  vmovaps [rsp+0x20], xmm3
00007f0254fded1d  vmovaps [rsp+0x30], xmm4
00007f0254fded23  vmovaps [rsp+0x40], xmm5
00007f0254fded29  vmovaps [rsp+0x50], xmm6
00007f0254fded2f  vmovaps [rsp+0x60], xmm7
00007f0254fded35  vmovaps [rsp+0x70], xmm8
00007f0254fded3b  vmovaps [rsp+0x80], xmm9
00007f0254fded44  vmovaps [rsp+0x90], xmm10
00007f0254fded4d  vmovaps [rsp+0xA0], xmm11
00007f0254fded56  vmovaps [rsp+0xB0], xmm12
00007f0254fded5f  vmovaps [rsp+0xC0], xmm13
00007f0254fded68  vmovaps [rsp+0xD0], xmm14
00007f0254fded71  vmovaps [rsp+0xE0], xmm15
00007f0254fded7a  sub rsp, 0x30
00007f0254fded7e  movaps [rsp], xmm1
00007f0254fded82  movaps [rsp+0x10], xmm4
00007f0254fded87  movaps [rsp+0x20], xmm9
00007f0254fded8d  lea rdi, [rsp]
00007f0254fded91  mov esi, 0x00
00007f0254fded96  mov rax, 0x55DD1360A530
00007f0254fdeda0  call rax
00007f0254fdeda2  movaps xmm1, [rsp]
00007f0254fdeda6  add rsp, 0x30
00007f0254fdedaa  vmovaps xmm0, [rsp]
00007f0254fdedaf  vmovaps xmm2, [rsp+0x10]
00007f0254fdedb5  vmovaps xmm3, [rsp+0x20]
00007f0254fdedbb  vmovaps xmm4, [rsp+0x30]
00007f0254fdedc1  vmovaps xmm5, [rsp+0x40]
00007f0254fdedc7  vmovaps xmm6, [rsp+0x50]
00007f0254fdedcd  vmovaps xmm7, [rsp+0x60]
00007f0254fdedd3  vmovaps xmm8, [rsp+0x70]
00007f0254fdedd9  vmovaps xmm9, [rsp+0x80]
00007f0254fdede2  vmovaps xmm10, [rsp+0x90]
00007f0254fdedeb  vmovaps xmm11, [rsp+0xA0]
00007f0254fdedf4  vmovaps xmm12, [rsp+0xB0]
00007f0254fdedfd  vmovaps xmm13, [rsp+0xC0]
00007f0254fdee06  vmovaps xmm14, [rsp+0xD0]
00007f0254fdee0f  vmovaps xmm15, [rsp+0xE0]
00007f0254fdee18  add rsp, 0xF0
00007f0254fdee1f  pop r11
00007f0254fdee21  pop r10
00007f0254fdee23  pop r9
00007f0254fdee25  pop r8
00007f0254fdee27  pop rsi
00007f0254fdee28  pop rdi
00007f0254fdee29  pop rdx
00007f0254fdee2a  pop rcx
00007f0254fdee2b  pop rax
00007f0254fdee2c  add rsp, 0x08
00007f0254fdee30  jmp 0x00007F0254FDC2EE
00007f0254fdee35  sub rsp, 0x08
00007f0254fdee39  push rax
00007f0254fdee3a  push rcx
00007f0254fdee3b  push rdx
00007f0254fdee3c  push rdi
00007f0254fdee3d  push rsi
00007f0254fdee3e  push r8
00007f0254fdee40  push r9
00007f0254fdee42  push r10
00007f0254fdee44  push r11
00007f0254fdee46  sub rsp, 0xF0
00007f0254fdee4d  vmovaps [rsp], xmm0
00007f0254fdee52  vmovaps [rsp+0x10], xmm1
00007f0254fdee58  vmovaps [rsp+0x20], xmm2
00007f0254fdee5e  vmovaps [rsp+0x30], xmm3
00007f0254fdee64  vmovaps [rsp+0x40], xmm5
00007f0254fdee6a  vmovaps [rsp+0x50], xmm6
00007f0254fdee70  vmovaps [rsp+0x60], xmm7
00007f0254fdee76  vmovaps [rsp+0x70], xmm8
00007f0254fdee7c  vmovaps [rsp+0x80], xmm9
00007f0254fdee85  vmovaps [rsp+0x90], xmm10
00007f0254fdee8e  vmovaps [rsp+0xA0], xmm11
00007f0254fdee97  vmovaps [rsp+0xB0], xmm12
00007f0254fdeea0  vmovaps [rsp+0xC0], xmm13
00007f0254fdeea9  vmovaps [rsp+0xD0], xmm14
00007f0254fdeeb2  vmovaps [rsp+0xE0], xmm15
00007f0254fdeebb  sub rsp, 0x30
00007f0254fdeebf  movaps [rsp], xmm4
00007f0254fdeec3  movaps [rsp+0x10], xmm2
00007f0254fdeec8  movaps [rsp+0x20], xmm9
00007f0254fdeece  lea rdi, [rsp]
00007f0254fdeed2  mov esi, 0x00
00007f0254fdeed7  mov rax, 0x55DD1360A530
00007f0254fdeee1  call rax
00007f0254fdeee3  movaps xmm4, [rsp]
00007f0254fdeee7  add rsp, 0x30
00007f0254fdeeeb  vmovaps xmm0, [rsp]
00007f0254fdeef0  vmovaps xmm1, [rsp+0x10]
00007f0254fdeef6  vmovaps xmm2, [rsp+0x20]
00007f0254fdeefc  vmovaps xmm3, [rsp+0x30]
00007f0254fdef02  vmovaps xmm5, [rsp+0x40]
00007f0254fdef08  vmovaps xmm6, [rsp+0x50]
00007f0254fdef0e  vmovaps xmm7, [rsp+0x60]
00007f0254fdef14  vmovaps xmm8, [rsp+0x70]
00007f0254fdef1a  vmovaps xmm9, [rsp+0x80]
00007f0254fdef23  vmovaps xmm10, [rsp+0x90]
00007f0254fdef2c  vmovaps xmm11, [rsp+0xA0]
00007f0254fdef35  vmovaps xmm12, [rsp+0xB0]
00007f0254fdef3e  vmovaps xmm13, [rsp+0xC0]
00007f0254fdef47  vmovaps xmm14, [rsp+0xD0]
00007f0254fdef50  vmovaps xmm15, [rsp+0xE0]
00007f0254fdef59  add rsp, 0xF0
00007f0254fdef60  pop r11
00007f0254fdef62  pop r10
00007f0254fdef64  pop r9
00007f0254fdef66  pop r8
00007f0254fdef68  pop rsi
00007f0254fdef69  pop rdi
00007f0254fdef6a  pop rdx
00007f0254fdef6b  pop rcx
00007f0254fdef6c  pop rax
00007f0254fdef6d  add rsp, 0x08
00007f0254fdef71  jmp 0x00007F0254FDC31E
00007f0254fdef76  sub rsp, 0x08
00007f0254fdef7a  push rax
00007f0254fdef7b  push rcx
00007f0254fdef7c  push rdx
00007f0254fdef7d  push rdi
00007f0254fdef7e  push rsi
00007f0254fdef7f  push r8
00007f0254fdef81  push r9
00007f0254fdef83  push r10
00007f0254fdef85  push r11
00007f0254fdef87  sub rsp, 0xF0
00007f0254fdef8e  vmovaps [rsp], xmm0
00007f0254fdef93  vmovaps [rsp+0x10], xmm1
00007f0254fdef99  vmovaps [rsp+0x20], xmm2
00007f0254fdef9f  vmovaps [rsp+0x30], xmm3
00007f0254fdefa5  vmovaps [rsp+0x40], xmm4
00007f0254fdefab  vmovaps [rsp+0x50], xmm5
00007f0254fdefb1  vmovaps [rsp+0x60], xmm6
00007f0254fdefb7  vmovaps [rsp+0x70], xmm7
00007f0254fdefbd  vmovaps [rsp+0x80], xmm8
00007f0254fdefc6  vmovaps [rsp+0x90], xmm10
00007f0254fdefcf  vmovaps [rsp+0xA0], xmm11
00007f0254fdefd8  vmovaps [rsp+0xB0], xmm12
00007f0254fdefe1  vmovaps [rsp+0xC0], xmm13
00007f0254fdefea  vmovaps [rsp+0xD0], xmm14
00007f0254fdeff3  vmovaps [rsp+0xE0], xmm15
00007f0254fdeffc  sub rsp, 0x30
00007f0254fdf000  movaps [rsp], xmm9
00007f0254fdf005  movaps [rsp+0x10], xmm2
00007f0254fdf00a  movaps [rsp+0x20], xmm1
00007f0254fdf00f  lea rdi, [rsp]
00007f0254fdf013  mov esi, 0x00
00007f0254fdf018  mov rax, 0x55DD1360A530
00007f0254fdf022  call rax
00007f0254fdf024  movaps xmm9, [rsp]
00007f0254fdf029  add rsp, 0x30
00007f0254fdf02d  vmovaps xmm0, [rsp]
00007f0254fdf032  vmovaps xmm1, [rsp+0x10]
00007f0254fdf038  vmovaps xmm2, [rsp+0x20]
00007f0254fdf03e  vmovaps xmm3, [rsp+0x30]
00007f0254fdf044  vmovaps xmm4, [rsp+0x40]
00007f0254fdf04a  vmovaps xmm5, [rsp+0x50]
00007f0254fdf050  vmovaps xmm6, [rsp+0x60]
00007f0254fdf056  vmovaps xmm7, [rsp+0x70]
00007f0254fdf05c  vmovaps xmm8, [rsp+0x80]
00007f0254fdf065  vmovaps xmm10, [rsp+0x90]
00007f0254fdf06e  vmovaps xmm11, [rsp+0xA0]
00007f0254fdf077  vmovaps xmm12, [rsp+0xB0]
00007f0254fdf080  vmovaps xmm13, [rsp+0xC0]
00007f0254fdf089  vmovaps xmm14, [rsp+0xD0]
00007f0254fdf092  vmovaps xmm15, [rsp+0xE0]
00007f0254fdf09b  add rsp, 0xF0
00007f0254fdf0a2  pop r11
00007f0254fdf0a4  pop r10
00007f0254fdf0a6  pop r9
00007f0254fdf0a8  pop r8
00007f0254fdf0aa  pop rsi
00007f0254fdf0ab  pop rdi
00007f0254fdf0ac  pop rdx
00007f0254fdf0ad  pop rcx
00007f0254fdf0ae  pop rax
00007f0254fdf0af  add rsp, 0x08
00007f0254fdf0b3  jmp 0x00007F0254FDC354
00007f0254fdf0b8  sub rsp, 0x08
00007f0254fdf0bc  push rax
00007f0254fdf0bd  push rcx
00007f0254fdf0be  push rdx
00007f0254fdf0bf  push rdi
00007f0254fdf0c0  push rsi
00007f0254fdf0c1  push r8
00007f0254fdf0c3  push r9
00007f0254fdf0c5  push r10
00007f0254fdf0c7  push r11
00007f0254fdf0c9  sub rsp, 0xF0
00007f0254fdf0d0  vmovaps [rsp], xmm0
00007f0254fdf0d5  vmovaps [rsp+0x10], xmm2
00007f0254fdf0db  vmovaps [rsp+0x20], xmm3
00007f0254fdf0e1  vmovaps [rsp+0x30], xmm4
00007f0254fdf0e7  vmovaps [rsp+0x40], xmm5
00007f0254fdf0ed  vmovaps [rsp+0x50], xmm6
00007f0254fdf0f3  vmovaps [rsp+0x60], xmm7
00007f0254fdf0f9  vmovaps [rsp+0x70], xmm8
00007f0254fdf0ff  vmovaps [rsp+0x80], xmm9
00007f0254fdf108  vmovaps [rsp+0x90], xmm10
00007f0254fdf111  vmovaps [rsp+0xA0], xmm11
00007f0254fdf11a  vmovaps [rsp+0xB0], xmm12
00007f0254fdf123  vmovaps [rsp+0xC0], xmm13
00007f0254fdf12c  vmovaps [rsp+0xD0], xmm14
00007f0254fdf135  vmovaps [rsp+0xE0], xmm15
00007f0254fdf13e  sub rsp, 0x30
00007f0254fdf142  movaps [rsp], xmm1
00007f0254fdf146  movaps [rsp+0x10], xmm15
00007f0254fdf14c  movaps [rsp+0x20], xmm6
00007f0254fdf151  lea rdi, [rsp]
00007f0254fdf155  mov esi, 0x00
00007f0254fdf15a  mov rax, 0x55DD1360A530
00007f0254fdf164  call rax
00007f0254fdf166  movaps xmm1, [rsp]
00007f0254fdf16a  add rsp, 0x30
00007f0254fdf16e  vmovaps xmm0, [rsp]
00007f0254fdf173  vmovaps xmm2, [rsp+0x10]
00007f0254fdf179  vmovaps xmm3, [rsp+0x20]
00007f0254fdf17f  vmovaps xmm4, [rsp+0x30]
00007f0254fdf185  vmovaps xmm5, [rsp+0x40]
00007f0254fdf18b  vmovaps xmm6, [rsp+0x50]
00007f0254fdf191  vmovaps xmm7, [rsp+0x60]
00007f0254fdf197  vmovaps xmm8, [rsp+0x70]
00007f0254fdf19d  vmovaps xmm9, [rsp+0x80]
00007f0254fdf1a6  vmovaps xmm10, [rsp+0x90]
00007f0254fdf1af  vmovaps xmm11, [rsp+0xA0]
00007f0254fdf1b8  vmovaps xmm12, [rsp+0xB0]
00007f0254fdf1c1  vmovaps xmm13, [rsp+0xC0]
00007f0254fdf1ca  vmovaps xmm14, [rsp+0xD0]
00007f0254fdf1d3  vmovaps xmm15, [rsp+0xE0]
00007f0254fdf1dc  add rsp, 0xF0
00007f0254fdf1e3  pop r11
00007f0254fdf1e5  pop r10
00007f0254fdf1e7  pop r9
00007f0254fdf1e9  pop r8
00007f0254fdf1eb  pop rsi
00007f0254fdf1ec  pop rdi
00007f0254fdf1ed  pop rdx
00007f0254fdf1ee  pop rcx
00007f0254fdf1ef  pop rax
00007f0254fdf1f0  add rsp, 0x08
00007f0254fdf1f4  jmp 0x00007F0254FDC375
00007f0254fdf1f9  sub rsp, 0x08
00007f0254fdf1fd  push rax
00007f0254fdf1fe  push rcx
00007f0254fdf1ff  push rdx
00007f0254fdf200  push rdi
00007f0254fdf201  push rsi
00007f0254fdf202  push r8
00007f0254fdf204  push r9
00007f0254fdf206  push r10
00007f0254fdf208  push r11
00007f0254fdf20a  sub rsp, 0xF0
00007f0254fdf211  vmovaps [rsp], xmm0
00007f0254fdf216  vmovaps [rsp+0x10], xmm1
00007f0254fdf21c  vmovaps [rsp+0x20], xmm2
00007f0254fdf222  vmovaps [rsp+0x30], xmm3
00007f0254fdf228  vmovaps [rsp+0x40], xmm4
00007f0254fdf22e  vmovaps [rsp+0x50], xmm5
00007f0254fdf234  vmovaps [rsp+0x60], xmm6
00007f0254fdf23a  vmovaps [rsp+0x70], xmm7
00007f0254fdf240  vmovaps [rsp+0x80], xmm8
00007f0254fdf249  vmovaps [rsp+0x90], xmm9
00007f0254fdf252  vmovaps [rsp+0xA0], xmm10
00007f0254fdf25b  vmovaps [rsp+0xB0], xmm11
00007f0254fdf264  vmovaps [rsp+0xC0], xmm12
00007f0254fdf26d  vmovaps [rsp+0xD0], xmm13
00007f0254fdf276  vmovaps [rsp+0xE0], xmm14
00007f0254fdf27f  sub rsp, 0x30
00007f0254fdf283  movaps [rsp], xmm15
00007f0254fdf288  movaps [rsp+0x10], xmm5
00007f0254fdf28d  movaps [rsp+0x20], xmm3
00007f0254fdf292  lea rdi, [rsp]
00007f0254fdf296  mov esi, 0x00
00007f0254fdf29b  mov rax, 0x55DD1360A530
00007f0254fdf2a5  call rax
00007f0254fdf2a7  movaps xmm15, [rsp]
00007f0254fdf2ac  add rsp, 0x30
00007f0254fdf2b0  vmovaps xmm0, [rsp]
00007f0254fdf2b5  vmovaps xmm1, [rsp+0x10]
00007f0254fdf2bb  vmovaps xmm2, [rsp+0x20]
00007f0254fdf2c1  vmovaps xmm3, [rsp+0x30]
00007f0254fdf2c7  vmovaps xmm4, [rsp+0x40]
00007f0254fdf2cd  vmovaps xmm5, [rsp+0x50]
00007f0254fdf2d3  vmovaps xmm6, [rsp+0x60]
00007f0254fdf2d9  vmovaps xmm7, [rsp+0x70]
00007f0254fdf2df  vmovaps xmm8, [rsp+0x80]
00007f0254fdf2e8  vmovaps xmm9, [rsp+0x90]
00007f0254fdf2f1  vmovaps xmm10, [rsp+0xA0]
00007f0254fdf2fa  vmovaps xmm11, [rsp+0xB0]
00007f0254fdf303  vmovaps xmm12, [rsp+0xC0]
00007f0254fdf30c  vmovaps xmm13, [rsp+0xD0]
00007f0254fdf315  vmovaps xmm14, [rsp+0xE0]
00007f0254fdf31e  add rsp, 0xF0
00007f0254fdf325  pop r11
00007f0254fdf327  pop r10
00007f0254fdf329  pop r9
00007f0254fdf32b  pop r8
00007f0254fdf32d  pop rsi
00007f0254fdf32e  pop rdi
00007f0254fdf32f  pop rdx
00007f0254fdf330  pop rcx
00007f0254fdf331  pop rax
00007f0254fdf332  add rsp, 0x08
00007f0254fdf336  jmp 0x00007F0254FDC38F
00007f0254fdf33b  sub rsp, 0x08
00007f0254fdf33f  push rax
00007f0254fdf340  push rcx
00007f0254fdf341  push rdx
00007f0254fdf342  push rdi
00007f0254fdf343  push rsi
00007f0254fdf344  push r8
00007f0254fdf346  push r9
00007f0254fdf348  push r10
00007f0254fdf34a  push r11
00007f0254fdf34c  sub rsp, 0xF0
00007f0254fdf353  vmovaps [rsp], xmm0
00007f0254fdf358  vmovaps [rsp+0x10], xmm1
00007f0254fdf35e  vmovaps [rsp+0x20], xmm2
00007f0254fdf364  vmovaps [rsp+0x30], xmm3
00007f0254fdf36a  vmovaps [rsp+0x40], xmm4
00007f0254fdf370  vmovaps [rsp+0x50], xmm6
00007f0254fdf376  vmovaps [rsp+0x60], xmm7
00007f0254fdf37c  vmovaps [rsp+0x70], xmm8
00007f0254fdf382  vmovaps [rsp+0x80], xmm9
00007f0254fdf38b  vmovaps [rsp+0x90], xmm10
00007f0254fdf394  vmovaps [rsp+0xA0], xmm11
00007f0254fdf39d  vmovaps [rsp+0xB0], xmm12
00007f0254fdf3a6  vmovaps [rsp+0xC0], xmm13
00007f0254fdf3af  vmovaps [rsp+0xD0], xmm14
00007f0254fdf3b8  vmovaps [rsp+0xE0], xmm15
00007f0254fdf3c1  sub rsp, 0x30
00007f0254fdf3c5  movaps [rsp], xmm5
00007f0254fdf3c9  movaps [rsp+0x10], xmm8
00007f0254fdf3cf  movaps [rsp+0x20], xmm6
00007f0254fdf3d4  lea rdi, [rsp]
00007f0254fdf3d8  mov esi, 0x00
00007f0254fdf3dd  mov rax, 0x55DD1360A530
00007f0254fdf3e7  call rax
00007f0254fdf3e9  movaps xmm5, [rsp]
00007f0254fdf3ed  add rsp, 0x30
00007f0254fdf3f1  vmovaps xmm0, [rsp]
00007f0254fdf3f6  vmovaps xmm1, [rsp+0x10]
00007f0254fdf3fc  vmovaps xmm2, [rsp+0x20]
00007f0254fdf402  vmovaps xmm3, [rsp+0x30]
00007f0254fdf408  vmovaps xmm4, [rsp+0x40]
00007f0254fdf40e  vmovaps xmm6, [rsp+0x50]
00007f0254fdf414  vmovaps xmm7, [rsp+0x60]
00007f0254fdf41a  vmovaps xmm8, [rsp+0x70]
00007f0254fdf420  vmovaps xmm9, [rsp+0x80]
00007f0254fdf429  vmovaps xmm10, [rsp+0x90]
00007f0254fdf432  vmovaps xmm11, [rsp+0xA0]
00007f0254fdf43b  vmovaps xmm12, [rsp+0xB0]
00007f0254fdf444  vmovaps xmm13, [rsp+0xC0]
00007f0254fdf44d  vmovaps xmm14, [rsp+0xD0]
00007f0254fdf456  vmovaps xmm15, [rsp+0xE0]
00007f0254fdf45f  add rsp, 0xF0
00007f0254fdf466  pop r11
00007f0254fdf468  pop r10
00007f0254fdf46a  pop r9
00007f0254fdf46c  pop r8
00007f0254fdf46e  pop rsi
00007f0254fdf46f  pop rdi
00007f0254fdf470  pop rdx
00007f0254fdf471  pop rcx
00007f0254fdf472  pop rax
00007f0254fdf473  add rsp, 0x08
00007f0254fdf477  jmp 0x00007F0254FDC3B3
00007f0254fdf47c  sub rsp, 0x08
00007f0254fdf480  push rax
00007f0254fdf481  push rcx
00007f0254fdf482  push rdx
00007f0254fdf483  push rdi
00007f0254fdf484  push rsi
00007f0254fdf485  push r8
00007f0254fdf487  push r9
00007f0254fdf489  push r10
00007f0254fdf48b  push r11
00007f0254fdf48d  sub rsp, 0xF0
00007f0254fdf494  vmovaps [rsp], xmm0
00007f0254fdf499  vmovaps [rsp+0x10], xmm1
00007f0254fdf49f  vmovaps [rsp+0x20], xmm2
00007f0254fdf4a5  vmovaps [rsp+0x30], xmm3
00007f0254fdf4ab  vmovaps [rsp+0x40], xmm4
00007f0254fdf4b1  vmovaps [rsp+0x50], xmm5
00007f0254fdf4b7  vmovaps [rsp+0x60], xmm7
00007f0254fdf4bd  vmovaps [rsp+0x70], xmm8
00007f0254fdf4c3  vmovaps [rsp+0x80], xmm9
00007f0254fdf4cc  vmovaps [rsp+0x90], xmm10
00007f0254fdf4d5  vmovaps [rsp+0xA0], xmm11
00007f0254fdf4de  vmovaps [rsp+0xB0], xmm12
00007f0254fdf4e7  vmovaps [rsp+0xC0], xmm13
00007f0254fdf4f0  vmovaps [rsp+0xD0], xmm14
00007f0254fdf4f9  vmovaps [rsp+0xE0], xmm15
00007f0254fdf502  sub rsp, 0x30
00007f0254fdf506  movaps [rsp], xmm6
00007f0254fdf50a  movaps [rsp+0x10], xmm10
00007f0254fdf510  movaps [rsp+0x20], xmm8
00007f0254fdf516  lea rdi, [rsp]
00007f0254fdf51a  mov esi, 0x00
00007f0254fdf51f  mov rax, 0x55DD1360A530
00007f0254fdf529  call rax
00007f0254fdf52b  movaps xmm6, [rsp]
00007f0254fdf52f  add rsp, 0x30
00007f0254fdf533  vmovaps xmm0, [rsp]
00007f0254fdf538  vmovaps xmm1, [rsp+0x10]
00007f0254fdf53e  vmovaps xmm2, [rsp+0x20]
00007f0254fdf544  vmovaps xmm3, [rsp+0x30]
00007f0254fdf54a  vmovaps xmm4, [rsp+0x40]
00007f0254fdf550  vmovaps xmm5, [rsp+0x50]
00007f0254fdf556  vmovaps xmm7, [rsp+0x60]
00007f0254fdf55c  vmovaps xmm8, [rsp+0x70]
00007f0254fdf562  vmovaps xmm9, [rsp+0x80]
00007f0254fdf56b  vmovaps xmm10, [rsp+0x90]
00007f0254fdf574  vmovaps xmm11, [rsp+0xA0]
00007f0254fdf57d  vmovaps xmm12, [rsp+0xB0]
00007f0254fdf586  vmovaps xmm13, [rsp+0xC0]
00007f0254fdf58f  vmovaps xmm14, [rsp+0xD0]
00007f0254fdf598  vmovaps xmm15, [rsp+0xE0]
00007f0254fdf5a1  add rsp, 0xF0
00007f0254fdf5a8  pop r11
00007f0254fdf5aa  pop r10
00007f0254fdf5ac  pop r9
00007f0254fdf5ae  pop r8
00007f0254fdf5b0  pop rsi
00007f0254fdf5b1  pop rdi
00007f0254fdf5b2  pop rdx
00007f0254fdf5b3  pop rcx
00007f0254fdf5b4  pop rax
00007f0254fdf5b5  add rsp, 0x08
00007f0254fdf5b9  jmp 0x00007F0254FDC3D8
00007f0254fdf5be  sub rsp, 0x08
00007f0254fdf5c2  push rax
00007f0254fdf5c3  push rcx
00007f0254fdf5c4  push rdx
00007f0254fdf5c5  push rdi
00007f0254fdf5c6  push rsi
00007f0254fdf5c7  push r8
00007f0254fdf5c9  push r9
00007f0254fdf5cb  push r10
00007f0254fdf5cd  push r11
00007f0254fdf5cf  sub rsp, 0xF0
00007f0254fdf5d6  vmovaps [rsp], xmm0
00007f0254fdf5db  vmovaps [rsp+0x10], xmm1
00007f0254fdf5e1  vmovaps [rsp+0x20], xmm2
00007f0254fdf5e7  vmovaps [rsp+0x30], xmm3
00007f0254fdf5ed  vmovaps [rsp+0x40], xmm4
00007f0254fdf5f3  vmovaps [rsp+0x50], xmm5
00007f0254fdf5f9  vmovaps [rsp+0x60], xmm6
00007f0254fdf5ff  vmovaps [rsp+0x70], xmm7
00007f0254fdf605  vmovaps [rsp+0x80], xmm8
00007f0254fdf60e  vmovaps [rsp+0x90], xmm9
00007f0254fdf617  vmovaps [rsp+0xA0], xmm11
00007f0254fdf620  vmovaps [rsp+0xB0], xmm12
00007f0254fdf629  vmovaps [rsp+0xC0], xmm13
00007f0254fdf632  vmovaps [rsp+0xD0], xmm14
00007f0254fdf63b  vmovaps [rsp+0xE0], xmm15
00007f0254fdf644  sub rsp, 0x30
00007f0254fdf648  movaps [rsp], xmm10
00007f0254fdf64d  movaps [rsp+0x10], xmm8
00007f0254fdf653  movaps [rsp+0x20], xmm14
00007f0254fdf659  lea rdi, [rsp]
00007f0254fdf65d  mov esi, 0x00
00007f0254fdf662  mov rax, 0x55DD1360A530
00007f0254fdf66c  call rax
00007f0254fdf66e  movaps xmm10, [rsp]
00007f0254fdf673  add rsp, 0x30
00007f0254fdf677  vmovaps xmm0, [rsp]
00007f0254fdf67c  vmovaps xmm1, [rsp+0x10]
00007f0254fdf682  vmovaps xmm2, [rsp+0x20]
00007f0254fdf688  vmovaps xmm3, [rsp+0x30]
00007f0254fdf68e  vmovaps xmm4, [rsp+0x40]
00007f0254fdf694  vmovaps xmm5, [rsp+0x50]
00007f0254fdf69a  vmovaps xmm6, [rsp+0x60]
00007f0254fdf6a0  vmovaps xmm7, [rsp+0x70]
00007f0254fdf6a6  vmovaps xmm8, [rsp+0x80]
00007f0254fdf6af  vmovaps xmm9, [rsp+0x90]
00007f0254fdf6b8  vmovaps xmm11, [rsp+0xA0]
00007f0254fdf6c1  vmovaps xmm12, [rsp+0xB0]
00007f0254fdf6ca  vmovaps xmm13, [rsp+0xC0]
00007f0254fdf6d3  vmovaps xmm14, [rsp+0xD0]
00007f0254fdf6dc  vmovaps xmm15, [rsp+0xE0]
00007f0254fdf6e5  add rsp, 0xF0
00007f0254fdf6ec  pop r11
00007f0254fdf6ee  pop r10
00007f0254fdf6f0  pop r9
00007f0254fdf6f2  pop r8
00007f0254fdf6f4  pop rsi
00007f0254fdf6f5  pop rdi
00007f0254fdf6f6  pop rdx
00007f0254fdf6f7  pop rcx
00007f0254fdf6f8  pop rax
00007f0254fdf6f9  add rsp, 0x08
00007f0254fdf6fd  jmp 0x00007F0254FDC3F8
00007f0254fdf702  sub rsp, 0x08
00007f0254fdf706  push rax
00007f0254fdf707  push rcx
00007f0254fdf708  push rdx
00007f0254fdf709  push rdi
00007f0254fdf70a  push rsi
00007f0254fdf70b  push r8
00007f0254fdf70d  push r9
00007f0254fdf70f  push r10
00007f0254fdf711  push r11
00007f0254fdf713  sub rsp, 0xF0
00007f0254fdf71a  vmovaps [rsp], xmm0
00007f0254fdf71f  vmovaps [rsp+0x10], xmm1
00007f0254fdf725  vmovaps [rsp+0x20], xmm2
00007f0254fdf72b  vmovaps [rsp+0x30], xmm3
00007f0254fdf731  vmovaps [rsp+0x40], xmm4
00007f0254fdf737  vmovaps [rsp+0x50], xmm5
00007f0254fdf73d  vmovaps [rsp+0x60], xmm6
00007f0254fdf743  vmovaps [rsp+0x70], xmm7
00007f0254fdf749  vmovaps [rsp+0x80], xmm8
00007f0254fdf752  vmovaps [rsp+0x90], xmm9
00007f0254fdf75b  vmovaps [rsp+0xA0], xmm10
00007f0254fdf764  vmovaps [rsp+0xB0], xmm11
00007f0254fdf76d  vmovaps [rsp+0xC0], xmm12
00007f0254fdf776  vmovaps [rsp+0xD0], xmm13
00007f0254fdf77f  vmovaps [rsp+0xE0], xmm15
00007f0254fdf788  sub rsp, 0x30
00007f0254fdf78c  movaps [rsp], xmm14
00007f0254fdf791  movaps [rsp+0x10], xmm8
00007f0254fdf797  movaps [rsp+0x20], xmm4
00007f0254fdf79c  lea rdi, [rsp]
00007f0254fdf7a0  mov esi, 0x00
00007f0254fdf7a5  mov rax, 0x55DD1360A530
00007f0254fdf7af  call rax
00007f0254fdf7b1  movaps xmm14, [rsp]
00007f0254fdf7b6  add rsp, 0x30
00007f0254fdf7ba  vmovaps xmm0, [rsp]
00007f0254fdf7bf  vmovaps xmm1, [rsp+0x10]
00007f0254fdf7c5  vmovaps xmm2, [rsp+0x20]
00007f0254fdf7cb  vmovaps xmm3, [rsp+0x30]
00007f0254fdf7d1  vmovaps xmm4, [rsp+0x40]
00007f0254fdf7d7  vmovaps xmm5, [rsp+0x50]
00007f0254fdf7dd  vmovaps xmm6, [rsp+0x60]
00007f0254fdf7e3  vmovaps xmm7, [rsp+0x70]
00007f0254fdf7e9  vmovaps xmm8, [rsp+0x80]
00007f0254fdf7f2  vmovaps xmm9, [rsp+0x90]
00007f0254fdf7fb  vmovaps xmm10, [rsp+0xA0]
00007f0254fdf804  vmovaps xmm11, [rsp+0xB0]
00007f0254fdf80d  vmovaps xmm12, [rsp+0xC0]
00007f0254fdf816  vmovaps xmm13, [rsp+0xD0]
00007f0254fdf81f  vmovaps xmm15, [rsp+0xE0]
00007f0254fdf828  add rsp, 0xF0
00007f0254fdf82f  pop r11
00007f0254fdf831  pop r10
00007f0254fdf833  pop r9
00007f0254fdf835  pop r8
00007f0254fdf837  pop rsi
00007f0254fdf838  pop rdi
00007f0254fdf839  pop rdx
00007f0254fdf83a  pop rcx
00007f0254fdf83b  pop rax
00007f0254fdf83c  add rsp, 0x08
00007f0254fdf840  jmp 0x00007F0254FDC418
00007f0254fdf845  sub rsp, 0x08
00007f0254fdf849  push rax
00007f0254fdf84a  push rcx
00007f0254fdf84b  push rdx
00007f0254fdf84c  push rdi
00007f0254fdf84d  push rsi
00007f0254fdf84e  push r8
00007f0254fdf850  push r9
00007f0254fdf852  push r10
00007f0254fdf854  push r11
00007f0254fdf856  sub rsp, 0xF0
00007f0254fdf85d  vmovaps [rsp], xmm0
00007f0254fdf862  vmovaps [rsp+0x10], xmm1
00007f0254fdf868  vmovaps [rsp+0x20], xmm2
00007f0254fdf86e  vmovaps [rsp+0x30], xmm3
00007f0254fdf874  vmovaps [rsp+0x40], xmm5
00007f0254fdf87a  vmovaps [rsp+0x50], xmm6
00007f0254fdf880  vmovaps [rsp+0x60], xmm7
00007f0254fdf886  vmovaps [rsp+0x70], xmm8
00007f0254fdf88c  vmovaps [rsp+0x80], xmm9
00007f0254fdf895  vmovaps [rsp+0x90], xmm10
00007f0254fdf89e  vmovaps [rsp+0xA0], xmm11
00007f0254fdf8a7  vmovaps [rsp+0xB0], xmm12
00007f0254fdf8b0  vmovaps [rsp+0xC0], xmm13
00007f0254fdf8b9  vmovaps [rsp+0xD0], xmm14
00007f0254fdf8c2  vmovaps [rsp+0xE0], xmm15
00007f0254fdf8cb  sub rsp, 0x30
00007f0254fdf8cf  movaps [rsp], xmm4
00007f0254fdf8d3  movaps [rsp+0x10], xmm13
00007f0254fdf8d9  movaps [rsp+0x20], xmm8
00007f0254fdf8df  lea rdi, [rsp]
00007f0254fdf8e3  mov esi, 0x00
00007f0254fdf8e8  mov rax, 0x55DD1360A530
00007f0254fdf8f2  call rax
00007f0254fdf8f4  movaps xmm4, [rsp]
00007f0254fdf8f8  add rsp, 0x30
00007f0254fdf8fc  vmovaps xmm0, [rsp]
00007f0254fdf901  vmovaps xmm1, [rsp+0x10]
00007f0254fdf907  vmovaps xmm2, [rsp+0x20]
00007f0254fdf90d  vmovaps xmm3, [rsp+0x30]
00007f0254fdf913  vmovaps xmm5, [rsp+0x40]
00007f0254fdf919  vmovaps xmm6, [rsp+0x50]
00007f0254fdf91f  vmovaps xmm7, [rsp+0x60]
00007f0254fdf925  vmovaps xmm8, [rsp+0x70]
00007f0254fdf92b  vmovaps xmm9, [rsp+0x80]
00007f0254fdf934  vmovaps xmm10, [rsp+0x90]
00007f0254fdf93d  vmovaps xmm11, [rsp+0xA0]
00007f0254fdf946  vmovaps xmm12, [rsp+0xB0]
00007f0254fdf94f  vmovaps xmm13, [rsp+0xC0]
00007f0254fdf958  vmovaps xmm14, [rsp+0xD0]
00007f0254fdf961  vmovaps xmm15, [rsp+0xE0]
00007f0254fdf96a  add rsp, 0xF0
00007f0254fdf971  pop r11
00007f0254fdf973  pop r10
00007f0254fdf975  pop r9
00007f0254fdf977  pop r8
00007f0254fdf979  pop rsi
00007f0254fdf97a  pop rdi
00007f0254fdf97b  pop rdx
00007f0254fdf97c  pop rcx
00007f0254fdf97d  pop rax
00007f0254fdf97e  add rsp, 0x08
00007f0254fdf982  jmp 0x00007F0254FDC43D
00007f0254fdf987  sub rsp, 0x08
00007f0254fdf98b  push rax
00007f0254fdf98c  push rcx
00007f0254fdf98d  push rdx
00007f0254fdf98e  push rdi
00007f0254fdf98f  push rsi
00007f0254fdf990  push r8
00007f0254fdf992  push r9
00007f0254fdf994  push r10
00007f0254fdf996  push r11
00007f0254fdf998  sub rsp, 0xF0
00007f0254fdf99f  vmovaps [rsp], xmm0
00007f0254fdf9a4  vmovaps [rsp+0x10], xmm1
00007f0254fdf9aa  vmovaps [rsp+0x20], xmm2
00007f0254fdf9b0  vmovaps [rsp+0x30], xmm3
00007f0254fdf9b6  vmovaps [rsp+0x40], xmm4
00007f0254fdf9bc  vmovaps [rsp+0x50], xmm5
00007f0254fdf9c2  vmovaps [rsp+0x60], xmm6
00007f0254fdf9c8  vmovaps [rsp+0x70], xmm7
00007f0254fdf9ce  vmovaps [rsp+0x80], xmm8
00007f0254fdf9d7  vmovaps [rsp+0x90], xmm9
00007f0254fdf9e0  vmovaps [rsp+0xA0], xmm10
00007f0254fdf9e9  vmovaps [rsp+0xB0], xmm11
00007f0254fdf9f2  vmovaps [rsp+0xC0], xmm12
00007f0254fdf9fb  vmovaps [rsp+0xD0], xmm14
00007f0254fdfa04  vmovaps [rsp+0xE0], xmm15
00007f0254fdfa0d  sub rsp, 0x30
00007f0254fdfa11  movaps [rsp], xmm13
00007f0254fdfa16  movaps [rsp+0x10], xmm15
00007f0254fdfa1c  movaps [rsp+0x20], xmm9
00007f0254fdfa22  lea rdi, [rsp]
00007f0254fdfa26  mov esi, 0x00
00007f0254fdfa2b  mov rax, 0x55DD1360A530
00007f0254fdfa35  call rax
00007f0254fdfa37  movaps xmm13, [rsp]
00007f0254fdfa3c  add rsp, 0x30
00007f0254fdfa40  vmovaps xmm0, [rsp]
00007f0254fdfa45  vmovaps xmm1, [rsp+0x10]
00007f0254fdfa4b  vmovaps xmm2, [rsp+0x20]
00007f0254fdfa51  vmovaps xmm3, [rsp+0x30]
00007f0254fdfa57  vmovaps xmm4, [rsp+0x40]
00007f0254fdfa5d  vmovaps xmm5, [rsp+0x50]
00007f0254fdfa63  vmovaps xmm6, [rsp+0x60]
00007f0254fdfa69  vmovaps xmm7, [rsp+0x70]
00007f0254fdfa6f  vmovaps xmm8, [rsp+0x80]
00007f0254fdfa78  vmovaps xmm9, [rsp+0x90]
00007f0254fdfa81  vmovaps xmm10, [rsp+0xA0]
00007f0254fdfa8a  vmovaps xmm11, [rsp+0xB0]
00007f0254fdfa93  vmovaps xmm12, [rsp+0xC0]
00007f0254fdfa9c  vmovaps xmm14, [rsp+0xD0]
00007f0254fdfaa5  vmovaps xmm15, [rsp+0xE0]
00007f0254fdfaae  add rsp, 0xF0
00007f0254fdfab5  pop r11
00007f0254fdfab7  pop r10
00007f0254fdfab9  pop r9
00007f0254fdfabb  pop r8
00007f0254fdfabd  pop rsi
00007f0254fdfabe  pop rdi
00007f0254fdfabf  pop rdx
00007f0254fdfac0  pop rcx
00007f0254fdfac1  pop rax
00007f0254fdfac2  add rsp, 0x08
00007f0254fdfac6  jmp 0x00007F0254FDC458
00007f0254fdfacb  sub rsp, 0x08
00007f0254fdfacf  push rax
00007f0254fdfad0  push rcx
00007f0254fdfad1  push rdx
00007f0254fdfad2  push rdi
00007f0254fdfad3  push rsi
00007f0254fdfad4  push r8
00007f0254fdfad6  push r9
00007f0254fdfad8  push r10
00007f0254fdfada  push r11
00007f0254fdfadc  sub rsp, 0xF0
00007f0254fdfae3  vmovaps [rsp], xmm0
00007f0254fdfae8  vmovaps [rsp+0x10], xmm1
00007f0254fdfaee  vmovaps [rsp+0x20], xmm2
00007f0254fdfaf4  vmovaps [rsp+0x30], xmm3
00007f0254fdfafa  vmovaps [rsp+0x40], xmm4
00007f0254fdfb00  vmovaps [rsp+0x50], xmm5
00007f0254fdfb06  vmovaps [rsp+0x60], xmm6
00007f0254fdfb0c  vmovaps [rsp+0x70], xmm7
00007f0254fdfb12  vmovaps [rsp+0x80], xmm8
00007f0254fdfb1b  vmovaps [rsp+0x90], xmm9
00007f0254fdfb24  vmovaps [rsp+0xA0], xmm10
00007f0254fdfb2d  vmovaps [rsp+0xB0], xmm11
00007f0254fdfb36  vmovaps [rsp+0xC0], xmm12
00007f0254fdfb3f  vmovaps [rsp+0xD0], xmm13
00007f0254fdfb48  vmovaps [rsp+0xE0], xmm14
00007f0254fdfb51  sub rsp, 0x30
00007f0254fdfb55  movaps [rsp], xmm15
00007f0254fdfb5a  movaps [rsp+0x10], xmm1
00007f0254fdfb5f  movaps [rsp+0x20], xmm5
00007f0254fdfb64  lea rdi, [rsp]
00007f0254fdfb68  mov esi, 0x00
00007f0254fdfb6d  mov rax, 0x55DD1360A530
00007f0254fdfb77  call rax
00007f0254fdfb79  movaps xmm15, [rsp]
00007f0254fdfb7e  add rsp, 0x30
00007f0254fdfb82  vmovaps xmm0, [rsp]
00007f0254fdfb87  vmovaps xmm1, [rsp+0x10]
00007f0254fdfb8d  vmovaps xmm2, [rsp+0x20]
00007f0254fdfb93  vmovaps xmm3, [rsp+0x30]
00007f0254fdfb99  vmovaps xmm4, [rsp+0x40]
00007f0254fdfb9f  vmovaps xmm5, [rsp+0x50]
00007f0254fdfba5  vmovaps xmm6, [rsp+0x60]
00007f0254fdfbab  vmovaps xmm7, [rsp+0x70]
00007f0254fdfbb1  vmovaps xmm8, [rsp+0x80]
00007f0254fdfbba  vmovaps xmm9, [rsp+0x90]
00007f0254fdfbc3  vmovaps xmm10, [rsp+0xA0]
00007f0254fdfbcc  vmovaps xmm11, [rsp+0xB0]
00007f0254fdfbd5  vmovaps xmm12, [rsp+0xC0]
00007f0254fdfbde  vmovaps xmm13, [rsp+0xD0]
00007f0254fdfbe7  vmovaps xmm14, [rsp+0xE0]
00007f0254fdfbf0  add rsp, 0xF0
00007f0254fdfbf7  pop r11
00007f0254fdfbf9  pop r10
00007f0254fdfbfb  pop r9
00007f0254fdfbfd  pop r8
00007f0254fdfbff  pop rsi
00007f0254fdfc00  pop rdi
00007f0254fdfc01  pop rdx
00007f0254fdfc02  pop rcx
00007f0254fdfc03  pop rax
00007f0254fdfc04  add rsp, 0x08
00007f0254fdfc08  jmp 0x00007F0254FDC473
00007f0254fdfc0d  call 0x00007F0254EB52F0
00007f0254fdfc12  jmp 0x00007F0254FDC4CE
00007f0254fdfc17  sub rsp, 0x08
00007f0254fdfc1b  push rax
00007f0254fdfc1c  push rcx
00007f0254fdfc1d  push rdx
00007f0254fdfc1e  push rdi
00007f0254fdfc1f  push rsi
00007f0254fdfc20  push r8
00007f0254fdfc22  push r9
00007f0254fdfc24  push r10
00007f0254fdfc26  push r11
00007f0254fdfc28  sub rsp, 0xF0
00007f0254fdfc2f  vmovaps [rsp], xmm0
00007f0254fdfc34  vmovaps [rsp+0x10], xmm1
00007f0254fdfc3a  vmovaps [rsp+0x20], xmm2
00007f0254fdfc40  vmovaps [rsp+0x30], xmm3
00007f0254fdfc46  vmovaps [rsp+0x40], xmm4
00007f0254fdfc4c  vmovaps [rsp+0x50], xmm5
00007f0254fdfc52  vmovaps [rsp+0x60], xmm6
00007f0254fdfc58  vmovaps [rsp+0x70], xmm7
00007f0254fdfc5e  vmovaps [rsp+0x80], xmm8
00007f0254fdfc67  vmovaps [rsp+0x90], xmm10
00007f0254fdfc70  vmovaps [rsp+0xA0], xmm11
00007f0254fdfc79  vmovaps [rsp+0xB0], xmm12
00007f0254fdfc82  vmovaps [rsp+0xC0], xmm13
00007f0254fdfc8b  vmovaps [rsp+0xD0], xmm14
00007f0254fdfc94  vmovaps [rsp+0xE0], xmm15
00007f0254fdfc9d  sub rsp, 0x30
00007f0254fdfca1  movaps [rsp], xmm9
00007f0254fdfca6  movaps [rsp+0x10], xmm8
00007f0254fdfcac  movaps [rsp+0x20], xmm11
00007f0254fdfcb2  lea rdi, [rsp]
00007f0254fdfcb6  mov esi, 0x00
00007f0254fdfcbb  mov rax, 0x55DD1360A530
00007f0254fdfcc5  call rax
00007f0254fdfcc7  movaps xmm9, [rsp]
00007f0254fdfccc  add rsp, 0x30
00007f0254fdfcd0  vmovaps xmm0, [rsp]
00007f0254fdfcd5  vmovaps xmm1, [rsp+0x10]
00007f0254fdfcdb  vmovaps xmm2, [rsp+0x20]
00007f0254fdfce1  vmovaps xmm3, [rsp+0x30]
00007f0254fdfce7  vmovaps xmm4, [rsp+0x40]
00007f0254fdfced  vmovaps xmm5, [rsp+0x50]
00007f0254fdfcf3  vmovaps xmm6, [rsp+0x60]
00007f0254fdfcf9  vmovaps xmm7, [rsp+0x70]
00007f0254fdfcff  vmovaps xmm8, [rsp+0x80]
00007f0254fdfd08  vmovaps xmm10, [rsp+0x90]
00007f0254fdfd11  vmovaps xmm11, [rsp+0xA0]
00007f0254fdfd1a  vmovaps xmm12, [rsp+0xB0]
00007f0254fdfd23  vmovaps xmm13, [rsp+0xC0]
00007f0254fdfd2c  vmovaps xmm14, [rsp+0xD0]
00007f0254fdfd35  vmovaps xmm15, [rsp+0xE0]
00007f0254fdfd3e  add rsp, 0xF0
00007f0254fdfd45  pop r11
00007f0254fdfd47  pop r10
00007f0254fdfd49  pop r9
00007f0254fdfd4b  pop r8
00007f0254fdfd4d  pop rsi
00007f0254fdfd4e  pop rdi
00007f0254fdfd4f  pop rdx
00007f0254fdfd50  pop rcx
00007f0254fdfd51  pop rax
00007f0254fdfd52  add rsp, 0x08
00007f0254fdfd56  jmp 0x00007F0254FDC505
00007f0254fdfd5b  sub rsp, 0x08
00007f0254fdfd5f  push rax
00007f0254fdfd60  push rcx
00007f0254fdfd61  push rdx
00007f0254fdfd62  push rdi
00007f0254fdfd63  push rsi
00007f0254fdfd64  push r8
00007f0254fdfd66  push r9
00007f0254fdfd68  push r10
00007f0254fdfd6a  push r11
00007f0254fdfd6c  sub rsp, 0xF0
00007f0254fdfd73  vmovaps [rsp], xmm0
00007f0254fdfd78  vmovaps [rsp+0x10], xmm1
00007f0254fdfd7e  vmovaps [rsp+0x20], xmm2
00007f0254fdfd84  vmovaps [rsp+0x30], xmm3
00007f0254fdfd8a  vmovaps [rsp+0x40], xmm4
00007f0254fdfd90  vmovaps [rsp+0x50], xmm5
00007f0254fdfd96  vmovaps [rsp+0x60], xmm6
00007f0254fdfd9c  vmovaps [rsp+0x70], xmm7
00007f0254fdfda2  vmovaps [rsp+0x80], xmm8
00007f0254fdfdab  vmovaps [rsp+0x90], xmm9
00007f0254fdfdb4  vmovaps [rsp+0xA0], xmm10
00007f0254fdfdbd  vmovaps [rsp+0xB0], xmm12
00007f0254fdfdc6  vmovaps [rsp+0xC0], xmm13
00007f0254fdfdcf  vmovaps [rsp+0xD0], xmm14
00007f0254fdfdd8  vmovaps [rsp+0xE0], xmm15
00007f0254fdfde1  sub rsp, 0x30
00007f0254fdfde5  movaps [rsp], xmm11
00007f0254fdfdea  movaps [rsp+0x10], xmm10
00007f0254fdfdf0  movaps [rsp+0x20], xmm6
00007f0254fdfdf5  lea rdi, [rsp]
00007f0254fdfdf9  mov esi, 0x00
00007f0254fdfdfe  mov rax, 0x55DD1360A530
00007f0254fdfe08  call rax
00007f0254fdfe0a  movaps xmm11, [rsp]
00007f0254fdfe0f  add rsp, 0x30
00007f0254fdfe13  vmovaps xmm0, [rsp]
00007f0254fdfe18  vmovaps xmm1, [rsp+0x10]
00007f0254fdfe1e  vmovaps xmm2, [rsp+0x20]
00007f0254fdfe24  vmovaps xmm3, [rsp+0x30]
00007f0254fdfe2a  vmovaps xmm4, [rsp+0x40]
00007f0254fdfe30  vmovaps xmm5, [rsp+0x50]
00007f0254fdfe36  vmovaps xmm6, [rsp+0x60]
00007f0254fdfe3c  vmovaps xmm7, [rsp+0x70]
00007f0254fdfe42  vmovaps xmm8, [rsp+0x80]
00007f0254fdfe4b  vmovaps xmm9, [rsp+0x90]
00007f0254fdfe54  vmovaps xmm10, [rsp+0xA0]
00007f0254fdfe5d  vmovaps xmm12, [rsp+0xB0]
00007f0254fdfe66  vmovaps xmm13, [rsp+0xC0]
00007f0254fdfe6f  vmovaps xmm14, [rsp+0xD0]
00007f0254fdfe78  vmovaps xmm15, [rsp+0xE0]
00007f0254fdfe81  add rsp, 0xF0
00007f0254fdfe88  pop r11
00007f0254fdfe8a  pop r10
00007f0254fdfe8c  pop r9
00007f0254fdfe8e  pop r8
00007f0254fdfe90  pop rsi
00007f0254fdfe91  pop rdi
00007f0254fdfe92  pop rdx
00007f0254fdfe93  pop rcx
00007f0254fdfe94  pop rax
00007f0254fdfe95  add rsp, 0x08
00007f0254fdfe99  jmp 0x00007F0254FDC520
00007f0254fdfe9e  sub rsp, 0x08
00007f0254fdfea2  push rax
00007f0254fdfea3  push rcx
00007f0254fdfea4  push rdx
00007f0254fdfea5  push rdi
00007f0254fdfea6  push rsi
00007f0254fdfea7  push r8
00007f0254fdfea9  push r9
00007f0254fdfeab  push r10
00007f0254fdfead  push r11
00007f0254fdfeaf  sub rsp, 0xF0
00007f0254fdfeb6  vmovaps [rsp], xmm0
00007f0254fdfebb  vmovaps [rsp+0x10], xmm1
00007f0254fdfec1  vmovaps [rsp+0x20], xmm2
00007f0254fdfec7  vmovaps [rsp+0x30], xmm3
00007f0254fdfecd  vmovaps [rsp+0x40], xmm4
00007f0254fdfed3  vmovaps [rsp+0x50], xmm5
00007f0254fdfed9  vmovaps [rsp+0x60], xmm6
00007f0254fdfedf  vmovaps [rsp+0x70], xmm7
00007f0254fdfee5  vmovaps [rsp+0x80], xmm8
00007f0254fdfeee  vmovaps [rsp+0x90], xmm9
00007f0254fdfef7  vmovaps [rsp+0xA0], xmm11
00007f0254fdff00  vmovaps [rsp+0xB0], xmm12
00007f0254fdff09  vmovaps [rsp+0xC0], xmm13
00007f0254fdff12  vmovaps [rsp+0xD0], xmm14
00007f0254fdff1b  vmovaps [rsp+0xE0], xmm15
00007f0254fdff24  sub rsp, 0x30
00007f0254fdff28  movaps [rsp], xmm10
00007f0254fdff2d  movaps [rsp+0x10], xmm14
00007f0254fdff33  movaps [rsp+0x20], xmm4
00007f0254fdff38  lea rdi, [rsp]
00007f0254fdff3c  mov esi, 0x00
00007f0254fdff41  mov rax, 0x55DD1360A530
00007f0254fdff4b  call rax
00007f0254fdff4d  movaps xmm10, [rsp]
00007f0254fdff52  add rsp, 0x30
00007f0254fdff56  vmovaps xmm0, [rsp]
00007f0254fdff5b  vmovaps xmm1, [rsp+0x10]
00007f0254fdff61  vmovaps xmm2, [rsp+0x20]
00007f0254fdff67  vmovaps xmm3, [rsp+0x30]
00007f0254fdff6d  vmovaps xmm4, [rsp+0x40]
00007f0254fdff73  vmovaps xmm5, [rsp+0x50]
00007f0254fdff79  vmovaps xmm6, [rsp+0x60]
00007f0254fdff7f  vmovaps xmm7, [rsp+0x70]
00007f0254fdff85  vmovaps xmm8, [rsp+0x80]
00007f0254fdff8e  vmovaps xmm9, [rsp+0x90]
00007f0254fdff97  vmovaps xmm11, [rsp+0xA0]
00007f0254fdffa0  vmovaps xmm12, [rsp+0xB0]
00007f0254fdffa9  vmovaps xmm13, [rsp+0xC0]
00007f0254fdffb2  vmovaps xmm14, [rsp+0xD0]
00007f0254fdffbb  vmovaps xmm15, [rsp+0xE0]
00007f0254fdffc4  add rsp, 0xF0
00007f0254fdffcb  pop r11
00007f0254fdffcd  pop r10
00007f0254fdffcf  pop r9
00007f0254fdffd1  pop r8
00007f0254fdffd3  pop rsi
00007f0254fdffd4  pop rdi
00007f0254fdffd5  pop rdx
00007f0254fdffd6  pop rcx
00007f0254fdffd7  pop rax
00007f0254fdffd8  add rsp, 0x08
00007f0254fdffdc  jmp 0x00007F0254FDC53B
00007f0254fdffe1  sub rsp, 0x08
00007f0254fdffe5  push rax
00007f0254fdffe6  push rcx
00007f0254fdffe7  push rdx
00007f0254fdffe8  push rdi
00007f0254fdffe9  push rsi
00007f0254fdffea  push r8
00007f0254fdffec  push r9
00007f0254fdffee  push r10
00007f0254fdfff0  push r11
00007f0254fdfff2  sub rsp, 0xF0
00007f0254fdfff9  vmovaps [rsp], xmm0
00007f0254fdfffe  vmovaps [rsp+0x10], xmm1
00007f0254fe0004  vmovaps [rsp+0x20], xmm2
00007f0254fe000a  vmovaps [rsp+0x30], xmm3
00007f0254fe0010  vmovaps [rsp+0x40], xmm4
00007f0254fe0016  vmovaps [rsp+0x50], xmm5
00007f0254fe001c  vmovaps [rsp+0x60], xmm6
00007f0254fe0022  vmovaps [rsp+0x70], xmm7
00007f0254fe0028  vmovaps [rsp+0x80], xmm9
00007f0254fe0031  vmovaps [rsp+0x90], xmm10
00007f0254fe003a  vmovaps [rsp+0xA0], xmm11
00007f0254fe0043  vmovaps [rsp+0xB0], xmm12
00007f0254fe004c  vmovaps [rsp+0xC0], xmm13
00007f0254fe0055  vmovaps [rsp+0xD0], xmm14
00007f0254fe005e  vmovaps [rsp+0xE0], xmm15
00007f0254fe0067  sub rsp, 0x30
00007f0254fe006b  movaps [rsp], xmm8
00007f0254fe0070  movaps [rsp+0x10], xmm1
00007f0254fe0075  movaps [rsp+0x20], xmm14
00007f0254fe007b  lea rdi, [rsp]
00007f0254fe007f  mov esi, 0x00
00007f0254fe0084  mov rax, 0x55DD1360A530
00007f0254fe008e  call rax
00007f0254fe0090  movaps xmm8, [rsp]
00007f0254fe0095  add rsp, 0x30
00007f0254fe0099  vmovaps xmm0, [rsp]
00007f0254fe009e  vmovaps xmm1, [rsp+0x10]
00007f0254fe00a4  vmovaps xmm2, [rsp+0x20]
00007f0254fe00aa  vmovaps xmm3, [rsp+0x30]
00007f0254fe00b0  vmovaps xmm4, [rsp+0x40]
00007f0254fe00b6  vmovaps xmm5, [rsp+0x50]
00007f0254fe00bc  vmovaps xmm6, [rsp+0x60]
00007f0254fe00c2  vmovaps xmm7, [rsp+0x70]
00007f0254fe00c8  vmovaps xmm9, [rsp+0x80]
00007f0254fe00d1  vmovaps xmm10, [rsp+0x90]
00007f0254fe00da  vmovaps xmm11, [rsp+0xA0]
00007f0254fe00e3  vmovaps xmm12, [rsp+0xB0]
00007f0254fe00ec  vmovaps xmm13, [rsp+0xC0]
00007f0254fe00f5  vmovaps xmm14, [rsp+0xD0]
00007f0254fe00fe  vmovaps xmm15, [rsp+0xE0]
00007f0254fe0107  add rsp, 0xF0
00007f0254fe010e  pop r11
00007f0254fe0110  pop r10
00007f0254fe0112  pop r9
00007f0254fe0114  pop r8
00007f0254fe0116  pop rsi
00007f0254fe0117  pop rdi
00007f0254fe0118  pop rdx
00007f0254fe0119  pop rcx
00007f0254fe011a  pop rax
00007f0254fe011b  add rsp, 0x08
00007f0254fe011f  jmp 0x00007F0254FDC561
00007f0254fe0124  sub rsp, 0x08
00007f0254fe0128  push rax
00007f0254fe0129  push rcx
00007f0254fe012a  push rdx
00007f0254fe012b  push rdi
00007f0254fe012c  push rsi
00007f0254fe012d  push r8
00007f0254fe012f  push r9
00007f0254fe0131  push r10
00007f0254fe0133  push r11
00007f0254fe0135  sub rsp, 0xF0
00007f0254fe013c  vmovaps [rsp], xmm0
00007f0254fe0141  vmovaps [rsp+0x10], xmm1
00007f0254fe0147  vmovaps [rsp+0x20], xmm2
00007f0254fe014d  vmovaps [rsp+0x30], xmm3
00007f0254fe0153  vmovaps [rsp+0x40], xmm4
00007f0254fe0159  vmovaps [rsp+0x50], xmm5
00007f0254fe015f  vmovaps [rsp+0x60], xmm7
00007f0254fe0165  vmovaps [rsp+0x70], xmm8
00007f0254fe016b  vmovaps [rsp+0x80], xmm9
00007f0254fe0174  vmovaps [rsp+0x90], xmm10
00007f0254fe017d  vmovaps [rsp+0xA0], xmm11
00007f0254fe0186  vmovaps [rsp+0xB0], xmm12
00007f0254fe018f  vmovaps [rsp+0xC0], xmm13
00007f0254fe0198  vmovaps [rsp+0xD0], xmm14
00007f0254fe01a1  vmovaps [rsp+0xE0], xmm15
00007f0254fe01aa  sub rsp, 0x30
00007f0254fe01ae  movaps [rsp], xmm6
00007f0254fe01b2  movaps [rsp+0x10], xmm1
00007f0254fe01b7  movaps [rsp+0x20], xmm14
00007f0254fe01bd  lea rdi, [rsp]
00007f0254fe01c1  mov esi, 0x00
00007f0254fe01c6  mov rax, 0x55DD1360A530
00007f0254fe01d0  call rax
00007f0254fe01d2  movaps xmm6, [rsp]
00007f0254fe01d6  add rsp, 0x30
00007f0254fe01da  vmovaps xmm0, [rsp]
00007f0254fe01df  vmovaps xmm1, [rsp+0x10]
00007f0254fe01e5  vmovaps xmm2, [rsp+0x20]
00007f0254fe01eb  vmovaps xmm3, [rsp+0x30]
00007f0254fe01f1  vmovaps xmm4, [rsp+0x40]
00007f0254fe01f7  vmovaps xmm5, [rsp+0x50]
00007f0254fe01fd  vmovaps xmm7, [rsp+0x60]
00007f0254fe0203  vmovaps xmm8, [rsp+0x70]
00007f0254fe0209  vmovaps xmm9, [rsp+0x80]
00007f0254fe0212  vmovaps xmm10, [rsp+0x90]
00007f0254fe021b  vmovaps xmm11, [rsp+0xA0]
00007f0254fe0224  vmovaps xmm12, [rsp+0xB0]
00007f0254fe022d  vmovaps xmm13, [rsp+0xC0]
00007f0254fe0236  vmovaps xmm14, [rsp+0xD0]
00007f0254fe023f  vmovaps xmm15, [rsp+0xE0]
00007f0254fe0248  add rsp, 0xF0
00007f0254fe024f  pop r11
00007f0254fe0251  pop r10
00007f0254fe0253  pop r9
00007f0254fe0255  pop r8
00007f0254fe0257  pop rsi
00007f0254fe0258  pop rdi
00007f0254fe0259  pop rdx
00007f0254fe025a  pop rcx
00007f0254fe025b  pop rax
00007f0254fe025c  add rsp, 0x08
00007f0254fe0260  jmp 0x00007F0254FDC58D
00007f0254fe0265  sub rsp, 0x08
00007f0254fe0269  push rax
00007f0254fe026a  push rcx
00007f0254fe026b  push rdx
00007f0254fe026c  push rdi
00007f0254fe026d  push rsi
00007f0254fe026e  push r8
00007f0254fe0270  push r9
00007f0254fe0272  push r10
00007f0254fe0274  push r11
00007f0254fe0276  sub rsp, 0xF0
00007f0254fe027d  vmovaps [rsp], xmm0
00007f0254fe0282  vmovaps [rsp+0x10], xmm1
00007f0254fe0288  vmovaps [rsp+0x20], xmm2
00007f0254fe028e  vmovaps [rsp+0x30], xmm3
00007f0254fe0294  vmovaps [rsp+0x40], xmm4
00007f0254fe029a  vmovaps [rsp+0x50], xmm5
00007f0254fe02a0  vmovaps [rsp+0x60], xmm6
00007f0254fe02a6  vmovaps [rsp+0x70], xmm7
00007f0254fe02ac  vmovaps [rsp+0x80], xmm8
00007f0254fe02b5  vmovaps [rsp+0x90], xmm9
00007f0254fe02be  vmovaps [rsp+0xA0], xmm10
00007f0254fe02c7  vmovaps [rsp+0xB0], xmm11
00007f0254fe02d0  vmovaps [rsp+0xC0], xmm12
00007f0254fe02d9  vmovaps [rsp+0xD0], xmm13
00007f0254fe02e2  vmovaps [rsp+0xE0], xmm15
00007f0254fe02eb  sub rsp, 0x30
00007f0254fe02ef  movaps [rsp], xmm14
00007f0254fe02f4  movaps [rsp+0x10], xmm12
00007f0254fe02fa  movaps [rsp+0x20], xmm1
00007f0254fe02ff  lea rdi, [rsp]
00007f0254fe0303  mov esi, 0x00
00007f0254fe0308  mov rax, 0x55DD1360A530
00007f0254fe0312  call rax
00007f0254fe0314  movaps xmm14, [rsp]
00007f0254fe0319  add rsp, 0x30
00007f0254fe031d  vmovaps xmm0, [rsp]
00007f0254fe0322  vmovaps xmm1, [rsp+0x10]
00007f0254fe0328  vmovaps xmm2, [rsp+0x20]
00007f0254fe032e  vmovaps xmm3, [rsp+0x30]
00007f0254fe0334  vmovaps xmm4, [rsp+0x40]
00007f0254fe033a  vmovaps xmm5, [rsp+0x50]
00007f0254fe0340  vmovaps xmm6, [rsp+0x60]
00007f0254fe0346  vmovaps xmm7, [rsp+0x70]
00007f0254fe034c  vmovaps xmm8, [rsp+0x80]
00007f0254fe0355  vmovaps xmm9, [rsp+0x90]
00007f0254fe035e  vmovaps xmm10, [rsp+0xA0]
00007f0254fe0367  vmovaps xmm11, [rsp+0xB0]
00007f0254fe0370  vmovaps xmm12, [rsp+0xC0]
00007f0254fe0379  vmovaps xmm13, [rsp+0xD0]
00007f0254fe0382  vmovaps xmm15, [rsp+0xE0]
00007f0254fe038b  add rsp, 0xF0
00007f0254fe0392  pop r11
00007f0254fe0394  pop r10
00007f0254fe0396  pop r9
00007f0254fe0398  pop r8
00007f0254fe039a  pop rsi
00007f0254fe039b  pop rdi
00007f0254fe039c  pop rdx
00007f0254fe039d  pop rcx
00007f0254fe039e  pop rax
00007f0254fe039f  add rsp, 0x08
00007f0254fe03a3  jmp 0x00007F0254FDC5B3
00007f0254fe03a8  sub rsp, 0x08
00007f0254fe03ac  push rax
00007f0254fe03ad  push rcx
00007f0254fe03ae  push rdx
00007f0254fe03af  push rdi
00007f0254fe03b0  push rsi
00007f0254fe03b1  push r8
00007f0254fe03b3  push r9
00007f0254fe03b5  push r10
00007f0254fe03b7  push r11
00007f0254fe03b9  sub rsp, 0xF0
00007f0254fe03c0  vmovaps [rsp], xmm0
00007f0254fe03c5  vmovaps [rsp+0x10], xmm2
00007f0254fe03cb  vmovaps [rsp+0x20], xmm3
00007f0254fe03d1  vmovaps [rsp+0x30], xmm4
00007f0254fe03d7  vmovaps [rsp+0x40], xmm5
00007f0254fe03dd  vmovaps [rsp+0x50], xmm6
00007f0254fe03e3  vmovaps [rsp+0x60], xmm7
00007f0254fe03e9  vmovaps [rsp+0x70], xmm8
00007f0254fe03ef  vmovaps [rsp+0x80], xmm9
00007f0254fe03f8  vmovaps [rsp+0x90], xmm10
00007f0254fe0401  vmovaps [rsp+0xA0], xmm11
00007f0254fe040a  vmovaps [rsp+0xB0], xmm12
00007f0254fe0413  vmovaps [rsp+0xC0], xmm13
00007f0254fe041c  vmovaps [rsp+0xD0], xmm14
00007f0254fe0425  vmovaps [rsp+0xE0], xmm15
00007f0254fe042e  sub rsp, 0x30
00007f0254fe0432  movaps [rsp], xmm1
00007f0254fe0436  movaps [rsp+0x10], xmm13
00007f0254fe043c  movaps [rsp+0x20], xmm9
00007f0254fe0442  lea rdi, [rsp]
00007f0254fe0446  mov esi, 0x00
00007f0254fe044b  mov rax, 0x55DD1360A530
00007f0254fe0455  call rax
00007f0254fe0457  movaps xmm1, [rsp]
00007f0254fe045b  add rsp, 0x30
00007f0254fe045f  vmovaps xmm0, [rsp]
00007f0254fe0464  vmovaps xmm2, [rsp+0x10]
00007f0254fe046a  vmovaps xmm3, [rsp+0x20]
00007f0254fe0470  vmovaps xmm4, [rsp+0x30]
00007f0254fe0476  vmovaps xmm5, [rsp+0x40]
00007f0254fe047c  vmovaps xmm6, [rsp+0x50]
00007f0254fe0482  vmovaps xmm7, [rsp+0x60]
00007f0254fe0488  vmovaps xmm8, [rsp+0x70]
00007f0254fe048e  vmovaps xmm9, [rsp+0x80]
00007f0254fe0497  vmovaps xmm10, [rsp+0x90]
00007f0254fe04a0  vmovaps xmm11, [rsp+0xA0]
00007f0254fe04a9  vmovaps xmm12, [rsp+0xB0]
00007f0254fe04b2  vmovaps xmm13, [rsp+0xC0]
00007f0254fe04bb  vmovaps xmm14, [rsp+0xD0]
00007f0254fe04c4  vmovaps xmm15, [rsp+0xE0]
00007f0254fe04cd  add rsp, 0xF0
00007f0254fe04d4  pop r11
00007f0254fe04d6  pop r10
00007f0254fe04d8  pop r9
00007f0254fe04da  pop r8
00007f0254fe04dc  pop rsi
00007f0254fe04dd  pop rdi
00007f0254fe04de  pop rdx
00007f0254fe04df  pop rcx
00007f0254fe04e0  pop rax
00007f0254fe04e1  add rsp, 0x08
00007f0254fe04e5  jmp 0x00007F0254FDC5CD
00007f0254fe04ea  sub rsp, 0x08
00007f0254fe04ee  push rax
00007f0254fe04ef  push rcx
00007f0254fe04f0  push rdx
00007f0254fe04f1  push rdi
00007f0254fe04f2  push rsi
00007f0254fe04f3  push r8
00007f0254fe04f5  push r9
00007f0254fe04f7  push r10
00007f0254fe04f9  push r11
00007f0254fe04fb  sub rsp, 0xF0
00007f0254fe0502  vmovaps [rsp], xmm0
00007f0254fe0507  vmovaps [rsp+0x10], xmm1
00007f0254fe050d  vmovaps [rsp+0x20], xmm2
00007f0254fe0513  vmovaps [rsp+0x30], xmm3
00007f0254fe0519  vmovaps [rsp+0x40], xmm4
00007f0254fe051f  vmovaps [rsp+0x50], xmm5
00007f0254fe0525  vmovaps [rsp+0x60], xmm6
00007f0254fe052b  vmovaps [rsp+0x70], xmm7
00007f0254fe0531  vmovaps [rsp+0x80], xmm8
00007f0254fe053a  vmovaps [rsp+0x90], xmm9
00007f0254fe0543  vmovaps [rsp+0xA0], xmm10
00007f0254fe054c  vmovaps [rsp+0xB0], xmm11
00007f0254fe0555  vmovaps [rsp+0xC0], xmm13
00007f0254fe055e  vmovaps [rsp+0xD0], xmm14
00007f0254fe0567  vmovaps [rsp+0xE0], xmm15
00007f0254fe0570  sub rsp, 0x30
00007f0254fe0574  movaps [rsp], xmm12
00007f0254fe0579  movaps [rsp+0x10], xmm7
00007f0254fe057e  movaps [rsp+0x20], xmm13
00007f0254fe0584  lea rdi, [rsp]
00007f0254fe0588  mov esi, 0x00
00007f0254fe058d  mov rax, 0x55DD1360A530
00007f0254fe0597  call rax
00007f0254fe0599  movaps xmm12, [rsp]
00007f0254fe059e  add rsp, 0x30
00007f0254fe05a2  vmovaps xmm0, [rsp]
00007f0254fe05a7  vmovaps xmm1, [rsp+0x10]
00007f0254fe05ad  vmovaps xmm2, [rsp+0x20]
00007f0254fe05b3  vmovaps xmm3, [rsp+0x30]
00007f0254fe05b9  vmovaps xmm4, [rsp+0x40]
00007f0254fe05bf  vmovaps xmm5, [rsp+0x50]
00007f0254fe05c5  vmovaps xmm6, [rsp+0x60]
00007f0254fe05cb  vmovaps xmm7, [rsp+0x70]
00007f0254fe05d1  vmovaps xmm8, [rsp+0x80]
00007f0254fe05da  vmovaps xmm9, [rsp+0x90]
00007f0254fe05e3  vmovaps xmm10, [rsp+0xA0]
00007f0254fe05ec  vmovaps xmm11, [rsp+0xB0]
00007f0254fe05f5  vmovaps xmm13, [rsp+0xC0]
00007f0254fe05fe  vmovaps xmm14, [rsp+0xD0]
00007f0254fe0607  vmovaps xmm15, [rsp+0xE0]
00007f0254fe0610  add rsp, 0xF0
00007f0254fe0617  pop r11
00007f0254fe0619  pop r10
00007f0254fe061b  pop r9
00007f0254fe061d  pop r8
00007f0254fe061f  pop rsi
00007f0254fe0620  pop rdi
00007f0254fe0621  pop rdx
00007f0254fe0622  pop rcx
00007f0254fe0623  pop rax
00007f0254fe0624  add rsp, 0x08
00007f0254fe0628  jmp 0x00007F0254FDC5F4
00007f0254fe062d  sub rsp, 0x08
00007f0254fe0631  push rax
00007f0254fe0632  push rcx
00007f0254fe0633  push rdx
00007f0254fe0634  push rdi
00007f0254fe0635  push rsi
00007f0254fe0636  push r8
00007f0254fe0638  push r9
00007f0254fe063a  push r10
00007f0254fe063c  push r11
00007f0254fe063e  sub rsp, 0xF0
00007f0254fe0645  vmovaps [rsp], xmm0
00007f0254fe064a  vmovaps [rsp+0x10], xmm1
00007f0254fe0650  vmovaps [rsp+0x20], xmm2
00007f0254fe0656  vmovaps [rsp+0x30], xmm3
00007f0254fe065c  vmovaps [rsp+0x40], xmm4
00007f0254fe0662  vmovaps [rsp+0x50], xmm5
00007f0254fe0668  vmovaps [rsp+0x60], xmm6
00007f0254fe066e  vmovaps [rsp+0x70], xmm7
00007f0254fe0674  vmovaps [rsp+0x80], xmm8
00007f0254fe067d  vmovaps [rsp+0x90], xmm9
00007f0254fe0686  vmovaps [rsp+0xA0], xmm10
00007f0254fe068f  vmovaps [rsp+0xB0], xmm11
00007f0254fe0698  vmovaps [rsp+0xC0], xmm12
00007f0254fe06a1  vmovaps [rsp+0xD0], xmm14
00007f0254fe06aa  vmovaps [rsp+0xE0], xmm15
00007f0254fe06b3  sub rsp, 0x30
00007f0254fe06b7  movaps [rsp], xmm13
00007f0254fe06bc  movaps [rsp+0x10], xmm15
00007f0254fe06c2  movaps [rsp+0x20], xmm8
00007f0254fe06c8  lea rdi, [rsp]
00007f0254fe06cc  mov esi, 0x00
00007f0254fe06d1  mov rax, 0x55DD1360A530
00007f0254fe06db  call rax
00007f0254fe06dd  movaps xmm13, [rsp]
00007f0254fe06e2  add rsp, 0x30
00007f0254fe06e6  vmovaps xmm0, [rsp]
00007f0254fe06eb  vmovaps xmm1, [rsp+0x10]
00007f0254fe06f1  vmovaps xmm2, [rsp+0x20]
00007f0254fe06f7  vmovaps xmm3, [rsp+0x30]
00007f0254fe06fd  vmovaps xmm4, [rsp+0x40]
00007f0254fe0703  vmovaps xmm5, [rsp+0x50]
00007f0254fe0709  vmovaps xmm6, [rsp+0x60]
00007f0254fe070f  vmovaps xmm7, [rsp+0x70]
00007f0254fe0715  vmovaps xmm8, [rsp+0x80]
00007f0254fe071e  vmovaps xmm9, [rsp+0x90]
00007f0254fe0727  vmovaps xmm10, [rsp+0xA0]
00007f0254fe0730  vmovaps xmm11, [rsp+0xB0]
00007f0254fe0739  vmovaps xmm12, [rsp+0xC0]
00007f0254fe0742  vmovaps xmm14, [rsp+0xD0]
00007f0254fe074b  vmovaps xmm15, [rsp+0xE0]
00007f0254fe0754  add rsp, 0xF0
00007f0254fe075b  pop r11
00007f0254fe075d  pop r10
00007f0254fe075f  pop r9
00007f0254fe0761  pop r8
00007f0254fe0763  pop rsi
00007f0254fe0764  pop rdi
00007f0254fe0765  pop rdx
00007f0254fe0766  pop rcx
00007f0254fe0767  pop rax
00007f0254fe0768  add rsp, 0x08
00007f0254fe076c  jmp 0x00007F0254FDC60F
00007f0254fe0771  sub rsp, 0x08
00007f0254fe0775  push rax
00007f0254fe0776  push rcx
00007f0254fe0777  push rdx
00007f0254fe0778  push rdi
00007f0254fe0779  push rsi
00007f0254fe077a  push r8
00007f0254fe077c  push r9
00007f0254fe077e  push r10
00007f0254fe0780  push r11
00007f0254fe0782  sub rsp, 0xF0
00007f0254fe0789  vmovaps [rsp], xmm0
00007f0254fe078e  vmovaps [rsp+0x10], xmm1
00007f0254fe0794  vmovaps [rsp+0x20], xmm2
00007f0254fe079a  vmovaps [rsp+0x30], xmm3
00007f0254fe07a0  vmovaps [rsp+0x40], xmm4
00007f0254fe07a6  vmovaps [rsp+0x50], xmm5
00007f0254fe07ac  vmovaps [rsp+0x60], xmm6
00007f0254fe07b2  vmovaps [rsp+0x70], xmm7
00007f0254fe07b8  vmovaps [rsp+0x80], xmm9
00007f0254fe07c1  vmovaps [rsp+0x90], xmm10
00007f0254fe07ca  vmovaps [rsp+0xA0], xmm11
00007f0254fe07d3  vmovaps [rsp+0xB0], xmm12
00007f0254fe07dc  vmovaps [rsp+0xC0], xmm13
00007f0254fe07e5  vmovaps [rsp+0xD0], xmm14
00007f0254fe07ee  vmovaps [rsp+0xE0], xmm15
00007f0254fe07f7  sub rsp, 0x30
00007f0254fe07fb  movaps [rsp], xmm8
00007f0254fe0800  movaps [rsp+0x10], xmm15
00007f0254fe0806  movaps [rsp+0x20], xmm9
00007f0254fe080c  lea rdi, [rsp]
00007f0254fe0810  mov esi, 0x00
00007f0254fe0815  mov rax, 0x55DD1360A530
00007f0254fe081f  call rax
00007f0254fe0821  movaps xmm8, [rsp]
00007f0254fe0826  add rsp, 0x30
00007f0254fe082a  vmovaps xmm0, [rsp]
00007f0254fe082f  vmovaps xmm1, [rsp+0x10]
00007f0254fe0835  vmovaps xmm2, [rsp+0x20]
00007f0254fe083b  vmovaps xmm3, [rsp+0x30]
00007f0254fe0841  vmovaps xmm4, [rsp+0x40]
00007f0254fe0847  vmovaps xmm5, [rsp+0x50]
00007f0254fe084d  vmovaps xmm6, [rsp+0x60]
00007f0254fe0853  vmovaps xmm7, [rsp+0x70]
00007f0254fe0859  vmovaps xmm9, [rsp+0x80]
00007f0254fe0862  vmovaps xmm10, [rsp+0x90]
00007f0254fe086b  vmovaps xmm11, [rsp+0xA0]
00007f0254fe0874  vmovaps xmm12, [rsp+0xB0]
00007f0254fe087d  vmovaps xmm13, [rsp+0xC0]
00007f0254fe0886  vmovaps xmm14, [rsp+0xD0]
00007f0254fe088f  vmovaps xmm15, [rsp+0xE0]
00007f0254fe0898  add rsp, 0xF0
00007f0254fe089f  pop r11
00007f0254fe08a1  pop r10
00007f0254fe08a3  pop r9
00007f0254fe08a5  pop r8
00007f0254fe08a7  pop rsi
00007f0254fe08a8  pop rdi
00007f0254fe08a9  pop rdx
00007f0254fe08aa  pop rcx
00007f0254fe08ab  pop rax
00007f0254fe08ac  add rsp, 0x08
00007f0254fe08b0  jmp 0x00007F0254FDC63D
00007f0254fe08b5  sub rsp, 0x08
00007f0254fe08b9  push rax
00007f0254fe08ba  push rcx
00007f0254fe08bb  push rdx
00007f0254fe08bc  push rdi
00007f0254fe08bd  push rsi
00007f0254fe08be  push r8
00007f0254fe08c0  push r9
00007f0254fe08c2  push r10
00007f0254fe08c4  push r11
00007f0254fe08c6  sub rsp, 0xF0
00007f0254fe08cd  vmovaps [rsp], xmm0
00007f0254fe08d2  vmovaps [rsp+0x10], xmm1
00007f0254fe08d8  vmovaps [rsp+0x20], xmm2
00007f0254fe08de  vmovaps [rsp+0x30], xmm3
00007f0254fe08e4  vmovaps [rsp+0x40], xmm4
00007f0254fe08ea  vmovaps [rsp+0x50], xmm5
00007f0254fe08f0  vmovaps [rsp+0x60], xmm6
00007f0254fe08f6  vmovaps [rsp+0x70], xmm7
00007f0254fe08fc  vmovaps [rsp+0x80], xmm8
00007f0254fe0905  vmovaps [rsp+0x90], xmm9
00007f0254fe090e  vmovaps [rsp+0xA0], xmm10
00007f0254fe0917  vmovaps [rsp+0xB0], xmm11
00007f0254fe0920  vmovaps [rsp+0xC0], xmm12
00007f0254fe0929  vmovaps [rsp+0xD0], xmm13
00007f0254fe0932  vmovaps [rsp+0xE0], xmm14
00007f0254fe093b  sub rsp, 0x30
00007f0254fe093f  movaps [rsp], xmm15
00007f0254fe0944  movaps [rsp+0x10], xmm11
00007f0254fe094a  movaps [rsp+0x20], xmm6
00007f0254fe094f  lea rdi, [rsp]
00007f0254fe0953  mov esi, 0x00
00007f0254fe0958  mov rax, 0x55DD1360A530
00007f0254fe0962  call rax
00007f0254fe0964  movaps xmm15, [rsp]
00007f0254fe0969  add rsp, 0x30
00007f0254fe096d  vmovaps xmm0, [rsp]
00007f0254fe0972  vmovaps xmm1, [rsp+0x10]
00007f0254fe0978  vmovaps xmm2, [rsp+0x20]
00007f0254fe097e  vmovaps xmm3, [rsp+0x30]
00007f0254fe0984  vmovaps xmm4, [rsp+0x40]
00007f0254fe098a  vmovaps xmm5, [rsp+0x50]
00007f0254fe0990  vmovaps xmm6, [rsp+0x60]
00007f0254fe0996  vmovaps xmm7, [rsp+0x70]
00007f0254fe099c  vmovaps xmm8, [rsp+0x80]
00007f0254fe09a5  vmovaps xmm9, [rsp+0x90]
00007f0254fe09ae  vmovaps xmm10, [rsp+0xA0]
00007f0254fe09b7  vmovaps xmm11, [rsp+0xB0]
00007f0254fe09c0  vmovaps xmm12, [rsp+0xC0]
00007f0254fe09c9  vmovaps xmm13, [rsp+0xD0]
00007f0254fe09d2  vmovaps xmm14, [rsp+0xE0]
00007f0254fe09db  add rsp, 0xF0
00007f0254fe09e2  pop r11
00007f0254fe09e4  pop r10
00007f0254fe09e6  pop r9
00007f0254fe09e8  pop r8
00007f0254fe09ea  pop rsi
00007f0254fe09eb  pop rdi
00007f0254fe09ec  pop rdx
00007f0254fe09ed  pop rcx
00007f0254fe09ee  pop rax
00007f0254fe09ef  add rsp, 0x08
00007f0254fe09f3  jmp 0x00007F0254FDC658
00007f0254fe09f8  sub rsp, 0x08
00007f0254fe09fc  push rax
00007f0254fe09fd  push rcx
00007f0254fe09fe  push rdx
00007f0254fe09ff  push rdi
00007f0254fe0a00  push rsi
00007f0254fe0a01  push r8
00007f0254fe0a03  push r9
00007f0254fe0a05  push r10
00007f0254fe0a07  push r11
00007f0254fe0a09  sub rsp, 0xF0
00007f0254fe0a10  vmovaps [rsp], xmm0
00007f0254fe0a15  vmovaps [rsp+0x10], xmm1
00007f0254fe0a1b  vmovaps [rsp+0x20], xmm2
00007f0254fe0a21  vmovaps [rsp+0x30], xmm3
00007f0254fe0a27  vmovaps [rsp+0x40], xmm4
00007f0254fe0a2d  vmovaps [rsp+0x50], xmm5
00007f0254fe0a33  vmovaps [rsp+0x60], xmm6
00007f0254fe0a39  vmovaps [rsp+0x70], xmm8
00007f0254fe0a3f  vmovaps [rsp+0x80], xmm9
00007f0254fe0a48  vmovaps [rsp+0x90], xmm10
00007f0254fe0a51  vmovaps [rsp+0xA0], xmm11
00007f0254fe0a5a  vmovaps [rsp+0xB0], xmm12
00007f0254fe0a63  vmovaps [rsp+0xC0], xmm13
00007f0254fe0a6c  vmovaps [rsp+0xD0], xmm14
00007f0254fe0a75  vmovaps [rsp+0xE0], xmm15
00007f0254fe0a7e  sub rsp, 0x30
00007f0254fe0a82  movaps [rsp], xmm7
00007f0254fe0a86  movaps [rsp+0x10], xmm11
00007f0254fe0a8c  movaps [rsp+0x20], xmm9
00007f0254fe0a92  lea rdi, [rsp]
00007f0254fe0a96  mov esi, 0x00
00007f0254fe0a9b  mov rax, 0x55DD1360A530
00007f0254fe0aa5  call rax
00007f0254fe0aa7  movaps xmm7, [rsp]
00007f0254fe0aab  add rsp, 0x30
00007f0254fe0aaf  vmovaps xmm0, [rsp]
00007f0254fe0ab4  vmovaps xmm1, [rsp+0x10]
00007f0254fe0aba  vmovaps xmm2, [rsp+0x20]
00007f0254fe0ac0  vmovaps xmm3, [rsp+0x30]
00007f0254fe0ac6  vmovaps xmm4, [rsp+0x40]
00007f0254fe0acc  vmovaps xmm5, [rsp+0x50]
00007f0254fe0ad2  vmovaps xmm6, [rsp+0x60]
00007f0254fe0ad8  vmovaps xmm8, [rsp+0x70]
00007f0254fe0ade  vmovaps xmm9, [rsp+0x80]
00007f0254fe0ae7  vmovaps xmm10, [rsp+0x90]
00007f0254fe0af0  vmovaps xmm11, [rsp+0xA0]
00007f0254fe0af9  vmovaps xmm12, [rsp+0xB0]
00007f0254fe0b02  vmovaps xmm13, [rsp+0xC0]
00007f0254fe0b0b  vmovaps xmm14, [rsp+0xD0]
00007f0254fe0b14  vmovaps xmm15, [rsp+0xE0]
00007f0254fe0b1d  add rsp, 0xF0
00007f0254fe0b24  pop r11
00007f0254fe0b26  pop r10
00007f0254fe0b28  pop r9
00007f0254fe0b2a  pop r8
00007f0254fe0b2c  pop rsi
00007f0254fe0b2d  pop rdi
00007f0254fe0b2e  pop rdx
00007f0254fe0b2f  pop rcx
00007f0254fe0b30  pop rax
00007f0254fe0b31  add rsp, 0x08
00007f0254fe0b35  jmp 0x00007F0254FDC685
00007f0254fe0b3a  sub rsp, 0x08
00007f0254fe0b3e  push rax
00007f0254fe0b3f  push rcx
00007f0254fe0b40  push rdx
00007f0254fe0b41  push rdi
00007f0254fe0b42  push rsi
00007f0254fe0b43  push r8
00007f0254fe0b45  push r9
00007f0254fe0b47  push r10
00007f0254fe0b49  push r11
00007f0254fe0b4b  sub rsp, 0xF0
00007f0254fe0b52  vmovaps [rsp], xmm0
00007f0254fe0b57  vmovaps [rsp+0x10], xmm1
00007f0254fe0b5d  vmovaps [rsp+0x20], xmm2
00007f0254fe0b63  vmovaps [rsp+0x30], xmm3
00007f0254fe0b69  vmovaps [rsp+0x40], xmm4
00007f0254fe0b6f  vmovaps [rsp+0x50], xmm5
00007f0254fe0b75  vmovaps [rsp+0x60], xmm6
00007f0254fe0b7b  vmovaps [rsp+0x70], xmm7
00007f0254fe0b81  vmovaps [rsp+0x80], xmm8
00007f0254fe0b8a  vmovaps [rsp+0x90], xmm9
00007f0254fe0b93  vmovaps [rsp+0xA0], xmm10
00007f0254fe0b9c  vmovaps [rsp+0xB0], xmm12
00007f0254fe0ba5  vmovaps [rsp+0xC0], xmm13
00007f0254fe0bae  vmovaps [rsp+0xD0], xmm14
00007f0254fe0bb7  vmovaps [rsp+0xE0], xmm15
00007f0254fe0bc0  sub rsp, 0x30
00007f0254fe0bc4  movaps [rsp], xmm11
00007f0254fe0bc9  movaps [rsp+0x10], xmm10
00007f0254fe0bcf  movaps [rsp+0x20], xmm14
00007f0254fe0bd5  lea rdi, [rsp]
00007f0254fe0bd9  mov esi, 0x00
00007f0254fe0bde  mov rax, 0x55DD1360A530
00007f0254fe0be8  call rax
00007f0254fe0bea  movaps xmm11, [rsp]
00007f0254fe0bef  add rsp, 0x30
00007f0254fe0bf3  vmovaps xmm0, [rsp]
00007f0254fe0bf8  vmovaps xmm1, [rsp+0x10]
00007f0254fe0bfe  vmovaps xmm2, [rsp+0x20]
00007f0254fe0c04  vmovaps xmm3, [rsp+0x30]
00007f0254fe0c0a  vmovaps xmm4, [rsp+0x40]
00007f0254fe0c10  vmovaps xmm5, [rsp+0x50]
00007f0254fe0c16  vmovaps xmm6, [rsp+0x60]
00007f0254fe0c1c  vmovaps xmm7, [rsp+0x70]
00007f0254fe0c22  vmovaps xmm8, [rsp+0x80]
00007f0254fe0c2b  vmovaps xmm9, [rsp+0x90]
00007f0254fe0c34  vmovaps xmm10, [rsp+0xA0]
00007f0254fe0c3d  vmovaps xmm12, [rsp+0xB0]
00007f0254fe0c46  vmovaps xmm13, [rsp+0xC0]
00007f0254fe0c4f  vmovaps xmm14, [rsp+0xD0]
00007f0254fe0c58  vmovaps xmm15, [rsp+0xE0]
00007f0254fe0c61  add rsp, 0xF0
00007f0254fe0c68  pop r11
00007f0254fe0c6a  pop r10
00007f0254fe0c6c  pop r9
00007f0254fe0c6e  pop r8
00007f0254fe0c70  pop rsi
00007f0254fe0c71  pop rdi
00007f0254fe0c72  pop rdx
00007f0254fe0c73  pop rcx
00007f0254fe0c74  pop rax
00007f0254fe0c75  add rsp, 0x08
00007f0254fe0c79  jmp 0x00007F0254FDC6A0
00007f0254fe0c7e  call 0x00007F0254EC33A0
00007f0254fe0c83  jmp 0x00007F0254FDC6AA
00007f0254fe0c88  sub rsp, 0x08
00007f0254fe0c8c  push rax
00007f0254fe0c8d  push rcx
00007f0254fe0c8e  push rdx
00007f0254fe0c8f  push rdi
00007f0254fe0c90  push rsi
00007f0254fe0c91  push r8
00007f0254fe0c93  push r9
00007f0254fe0c95  push r10
00007f0254fe0c97  push r11
00007f0254fe0c99  sub rsp, 0xF0
00007f0254fe0ca0  vmovaps [rsp], xmm0
00007f0254fe0ca5  vmovaps [rsp+0x10], xmm1
00007f0254fe0cab  vmovaps [rsp+0x20], xmm2
00007f0254fe0cb1  vmovaps [rsp+0x30], xmm3
00007f0254fe0cb7  vmovaps [rsp+0x40], xmm4
00007f0254fe0cbd  vmovaps [rsp+0x50], xmm5
00007f0254fe0cc3  vmovaps [rsp+0x60], xmm6
00007f0254fe0cc9  vmovaps [rsp+0x70], xmm7
00007f0254fe0ccf  vmovaps [rsp+0x80], xmm8
00007f0254fe0cd8  vmovaps [rsp+0x90], xmm9
00007f0254fe0ce1  vmovaps [rsp+0xA0], xmm11
00007f0254fe0cea  vmovaps [rsp+0xB0], xmm12
00007f0254fe0cf3  vmovaps [rsp+0xC0], xmm13
00007f0254fe0cfc  vmovaps [rsp+0xD0], xmm14
00007f0254fe0d05  vmovaps [rsp+0xE0], xmm15
00007f0254fe0d0e  sub rsp, 0x30
00007f0254fe0d12  movaps [rsp], xmm10
00007f0254fe0d17  movaps [rsp+0x10], xmm1
00007f0254fe0d1c  movaps [rsp+0x20], xmm12
00007f0254fe0d22  lea rdi, [rsp]
00007f0254fe0d26  mov esi, 0x00
00007f0254fe0d2b  mov rax, 0x55DD1360A530
00007f0254fe0d35  call rax
00007f0254fe0d37  movaps xmm10, [rsp]
00007f0254fe0d3c  add rsp, 0x30
00007f0254fe0d40  vmovaps xmm0, [rsp]
00007f0254fe0d45  vmovaps xmm1, [rsp+0x10]
00007f0254fe0d4b  vmovaps xmm2, [rsp+0x20]
00007f0254fe0d51  vmovaps xmm3, [rsp+0x30]
00007f0254fe0d57  vmovaps xmm4, [rsp+0x40]
00007f0254fe0d5d  vmovaps xmm5, [rsp+0x50]
00007f0254fe0d63  vmovaps xmm6, [rsp+0x60]
00007f0254fe0d69  vmovaps xmm7, [rsp+0x70]
00007f0254fe0d6f  vmovaps xmm8, [rsp+0x80]
00007f0254fe0d78  vmovaps xmm9, [rsp+0x90]
00007f0254fe0d81  vmovaps xmm11, [rsp+0xA0]
00007f0254fe0d8a  vmovaps xmm12, [rsp+0xB0]
00007f0254fe0d93  vmovaps xmm13, [rsp+0xC0]
00007f0254fe0d9c  vmovaps xmm14, [rsp+0xD0]
00007f0254fe0da5  vmovaps xmm15, [rsp+0xE0]
00007f0254fe0dae  add rsp, 0xF0
00007f0254fe0db5  pop r11
00007f0254fe0db7  pop r10
00007f0254fe0db9  pop r9
00007f0254fe0dbb  pop r8
00007f0254fe0dbd  pop rsi
00007f0254fe0dbe  pop rdi
00007f0254fe0dbf  pop rdx
00007f0254fe0dc0  pop rcx
00007f0254fe0dc1  pop rax
00007f0254fe0dc2  add rsp, 0x08
00007f0254fe0dc6  jmp 0x00007F0254FDC6CD
00007f0254fe0dcb  sub rsp, 0x08
00007f0254fe0dcf  push rax
00007f0254fe0dd0  push rcx
00007f0254fe0dd1  push rdx
00007f0254fe0dd2  push rdi
00007f0254fe0dd3  push rsi
00007f0254fe0dd4  push r8
00007f0254fe0dd6  push r9
00007f0254fe0dd8  push r10
00007f0254fe0dda  push r11
00007f0254fe0ddc  sub rsp, 0xF0
00007f0254fe0de3  vmovaps [rsp], xmm0
00007f0254fe0de8  vmovaps [rsp+0x10], xmm1
00007f0254fe0dee  vmovaps [rsp+0x20], xmm2
00007f0254fe0df4  vmovaps [rsp+0x30], xmm3
00007f0254fe0dfa  vmovaps [rsp+0x40], xmm4
00007f0254fe0e00  vmovaps [rsp+0x50], xmm5
00007f0254fe0e06  vmovaps [rsp+0x60], xmm6
00007f0254fe0e0c  vmovaps [rsp+0x70], xmm7
00007f0254fe0e12  vmovaps [rsp+0x80], xmm8
00007f0254fe0e1b  vmovaps [rsp+0x90], xmm9
00007f0254fe0e24  vmovaps [rsp+0xA0], xmm10
00007f0254fe0e2d  vmovaps [rsp+0xB0], xmm11
00007f0254fe0e36  vmovaps [rsp+0xC0], xmm13
00007f0254fe0e3f  vmovaps [rsp+0xD0], xmm14
00007f0254fe0e48  vmovaps [rsp+0xE0], xmm15
00007f0254fe0e51  sub rsp, 0x30
00007f0254fe0e55  movaps [rsp], xmm12
00007f0254fe0e5a  movaps [rsp+0x10], xmm14
00007f0254fe0e60  movaps [rsp+0x20], xmm1
00007f0254fe0e65  lea rdi, [rsp]
00007f0254fe0e69  mov esi, 0x00
00007f0254fe0e6e  mov rax, 0x55DD1360A530
00007f0254fe0e78  call rax
00007f0254fe0e7a  movaps xmm12, [rsp]
00007f0254fe0e7f  add rsp, 0x30
00007f0254fe0e83  vmovaps xmm0, [rsp]
00007f0254fe0e88  vmovaps xmm1, [rsp+0x10]
00007f0254fe0e8e  vmovaps xmm2, [rsp+0x20]
00007f0254fe0e94  vmovaps xmm3, [rsp+0x30]
00007f0254fe0e9a  vmovaps xmm4, [rsp+0x40]
00007f0254fe0ea0  vmovaps xmm5, [rsp+0x50]
00007f0254fe0ea6  vmovaps xmm6, [rsp+0x60]
00007f0254fe0eac  vmovaps xmm7, [rsp+0x70]
00007f0254fe0eb2  vmovaps xmm8, [rsp+0x80]
00007f0254fe0ebb  vmovaps xmm9, [rsp+0x90]
00007f0254fe0ec4  vmovaps xmm10, [rsp+0xA0]
00007f0254fe0ecd  vmovaps xmm11, [rsp+0xB0]
00007f0254fe0ed6  vmovaps xmm13, [rsp+0xC0]
00007f0254fe0edf  vmovaps xmm14, [rsp+0xD0]
00007f0254fe0ee8  vmovaps xmm15, [rsp+0xE0]
00007f0254fe0ef1  add rsp, 0xF0
00007f0254fe0ef8  pop r11
00007f0254fe0efa  pop r10
00007f0254fe0efc  pop r9
00007f0254fe0efe  pop r8
00007f0254fe0f00  pop rsi
00007f0254fe0f01  pop rdi
00007f0254fe0f02  pop rdx
00007f0254fe0f03  pop rcx
00007f0254fe0f04  pop rax
00007f0254fe0f05  add rsp, 0x08
00007f0254fe0f09  jmp 0x00007F0254FDC6FC
00007f0254fe0f0e  sub rsp, 0x08
00007f0254fe0f12  push rax
00007f0254fe0f13  push rcx
00007f0254fe0f14  push rdx
00007f0254fe0f15  push rdi
00007f0254fe0f16  push rsi
00007f0254fe0f17  push r8
00007f0254fe0f19  push r9
00007f0254fe0f1b  push r10
00007f0254fe0f1d  push r11
00007f0254fe0f1f  sub rsp, 0xF0
00007f0254fe0f26  vmovaps [rsp], xmm0
00007f0254fe0f2b  vmovaps [rsp+0x10], xmm1
00007f0254fe0f31  vmovaps [rsp+0x20], xmm2
00007f0254fe0f37  vmovaps [rsp+0x30], xmm3
00007f0254fe0f3d  vmovaps [rsp+0x40], xmm4
00007f0254fe0f43  vmovaps [rsp+0x50], xmm5
00007f0254fe0f49  vmovaps [rsp+0x60], xmm6
00007f0254fe0f4f  vmovaps [rsp+0x70], xmm7
00007f0254fe0f55  vmovaps [rsp+0x80], xmm8
00007f0254fe0f5e  vmovaps [rsp+0x90], xmm9
00007f0254fe0f67  vmovaps [rsp+0xA0], xmm10
00007f0254fe0f70  vmovaps [rsp+0xB0], xmm11
00007f0254fe0f79  vmovaps [rsp+0xC0], xmm12
00007f0254fe0f82  vmovaps [rsp+0xD0], xmm13
00007f0254fe0f8b  vmovaps [rsp+0xE0], xmm15
00007f0254fe0f94  sub rsp, 0x30
00007f0254fe0f98  movaps [rsp], xmm14
00007f0254fe0f9d  movaps [rsp+0x10], xmm9
00007f0254fe0fa3  movaps [rsp+0x20], xmm1
00007f0254fe0fa8  lea rdi, [rsp]
00007f0254fe0fac  mov esi, 0x00
00007f0254fe0fb1  mov rax, 0x55DD1360A530
00007f0254fe0fbb  call rax
00007f0254fe0fbd  movaps xmm14, [rsp]
00007f0254fe0fc2  add rsp, 0x30
00007f0254fe0fc6  vmovaps xmm0, [rsp]
00007f0254fe0fcb  vmovaps xmm1, [rsp+0x10]
00007f0254fe0fd1  vmovaps xmm2, [rsp+0x20]
00007f0254fe0fd7  vmovaps xmm3, [rsp+0x30]
00007f0254fe0fdd  vmovaps xmm4, [rsp+0x40]
00007f0254fe0fe3  vmovaps xmm5, [rsp+0x50]
00007f0254fe0fe9  vmovaps xmm6, [rsp+0x60]
00007f0254fe0fef  vmovaps xmm7, [rsp+0x70]
00007f0254fe0ff5  vmovaps xmm8, [rsp+0x80]
00007f0254fe0ffe  vmovaps xmm9, [rsp+0x90]
00007f0254fe1007  vmovaps xmm10, [rsp+0xA0]
00007f0254fe1010  vmovaps xmm11, [rsp+0xB0]
00007f0254fe1019  vmovaps xmm12, [rsp+0xC0]
00007f0254fe1022  vmovaps xmm13, [rsp+0xD0]
00007f0254fe102b  vmovaps xmm15, [rsp+0xE0]
00007f0254fe1034  add rsp, 0xF0
00007f0254fe103b  pop r11
00007f0254fe103d  pop r10
00007f0254fe103f  pop r9
00007f0254fe1041  pop r8
00007f0254fe1043  pop rsi
00007f0254fe1044  pop rdi
00007f0254fe1045  pop rdx
00007f0254fe1046  pop rcx
00007f0254fe1047  pop rax
00007f0254fe1048  add rsp, 0x08
00007f0254fe104c  jmp 0x00007F0254FDC72B
00007f0254fe1051  sub rsp, 0x08
00007f0254fe1055  push rax
00007f0254fe1056  push rcx
00007f0254fe1057  push rdx
00007f0254fe1058  push rdi
00007f0254fe1059  push rsi
00007f0254fe105a  push r8
00007f0254fe105c  push r9
00007f0254fe105e  push r10
00007f0254fe1060  push r11
00007f0254fe1062  sub rsp, 0xF0
00007f0254fe1069  vmovaps [rsp], xmm0
00007f0254fe106e  vmovaps [rsp+0x10], xmm2
00007f0254fe1074  vmovaps [rsp+0x20], xmm3
00007f0254fe107a  vmovaps [rsp+0x30], xmm4
00007f0254fe1080  vmovaps [rsp+0x40], xmm5
00007f0254fe1086  vmovaps [rsp+0x50], xmm6
00007f0254fe108c  vmovaps [rsp+0x60], xmm7
00007f0254fe1092  vmovaps [rsp+0x70], xmm8
00007f0254fe1098  vmovaps [rsp+0x80], xmm9
00007f0254fe10a1  vmovaps [rsp+0x90], xmm10
00007f0254fe10aa  vmovaps [rsp+0xA0], xmm11
00007f0254fe10b3  vmovaps [rsp+0xB0], xmm12
00007f0254fe10bc  vmovaps [rsp+0xC0], xmm13
00007f0254fe10c5  vmovaps [rsp+0xD0], xmm14
00007f0254fe10ce  vmovaps [rsp+0xE0], xmm15
00007f0254fe10d7  sub rsp, 0x30
00007f0254fe10db  movaps [rsp], xmm1
00007f0254fe10df  movaps [rsp+0x10], xmm13
00007f0254fe10e5  movaps [rsp+0x20], xmm8
00007f0254fe10eb  lea rdi, [rsp]
00007f0254fe10ef  mov esi, 0x00
00007f0254fe10f4  mov rax, 0x55DD1360A530
00007f0254fe10fe  call rax
00007f0254fe1100  movaps xmm1, [rsp]
00007f0254fe1104  add rsp, 0x30
00007f0254fe1108  vmovaps xmm0, [rsp]
00007f0254fe110d  vmovaps xmm2, [rsp+0x10]
00007f0254fe1113  vmovaps xmm3, [rsp+0x20]
00007f0254fe1119  vmovaps xmm4, [rsp+0x30]
00007f0254fe111f  vmovaps xmm5, [rsp+0x40]
00007f0254fe1125  vmovaps xmm6, [rsp+0x50]
00007f0254fe112b  vmovaps xmm7, [rsp+0x60]
00007f0254fe1131  vmovaps xmm8, [rsp+0x70]
00007f0254fe1137  vmovaps xmm9, [rsp+0x80]
00007f0254fe1140  vmovaps xmm10, [rsp+0x90]
00007f0254fe1149  vmovaps xmm11, [rsp+0xA0]
00007f0254fe1152  vmovaps xmm12, [rsp+0xB0]
00007f0254fe115b  vmovaps xmm13, [rsp+0xC0]
00007f0254fe1164  vmovaps xmm14, [rsp+0xD0]
00007f0254fe116d  vmovaps xmm15, [rsp+0xE0]
00007f0254fe1176  add rsp, 0xF0
00007f0254fe117d  pop r11
00007f0254fe117f  pop r10
00007f0254fe1181  pop r9
00007f0254fe1183  pop r8
00007f0254fe1185  pop rsi
00007f0254fe1186  pop rdi
00007f0254fe1187  pop rdx
00007f0254fe1188  pop rcx
00007f0254fe1189  pop rax
00007f0254fe118a  add rsp, 0x08
00007f0254fe118e  jmp 0x00007F0254FDC74D
00007f0254fe1193  call 0x00007F0254E0C260
00007f0254fe1198  jmp 0x00007F0254FDC75B
00007f0254fe119d  call 0x00007F0254EBD750
00007f0254fe11a2  jmp 0x00007F0254FDC765
00007f0254fe11a7  sub rsp, 0x08
00007f0254fe11ab  push rax
00007f0254fe11ac  push rcx
00007f0254fe11ad  push rdx
00007f0254fe11ae  push rdi
00007f0254fe11af  push rsi
00007f0254fe11b0  push r8
00007f0254fe11b2  push r9
00007f0254fe11b4  push r10
00007f0254fe11b6  push r11
00007f0254fe11b8  sub rsp, 0xF0
00007f0254fe11bf  vmovaps [rsp], xmm0
00007f0254fe11c4  vmovaps [rsp+0x10], xmm1
00007f0254fe11ca  vmovaps [rsp+0x20], xmm2
00007f0254fe11d0  vmovaps [rsp+0x30], xmm3
00007f0254fe11d6  vmovaps [rsp+0x40], xmm4
00007f0254fe11dc  vmovaps [rsp+0x50], xmm5
00007f0254fe11e2  vmovaps [rsp+0x60], xmm6
00007f0254fe11e8  vmovaps [rsp+0x70], xmm7
00007f0254fe11ee  vmovaps [rsp+0x80], xmm9
00007f0254fe11f7  vmovaps [rsp+0x90], xmm10
00007f0254fe1200  vmovaps [rsp+0xA0], xmm11
00007f0254fe1209  vmovaps [rsp+0xB0], xmm12
00007f0254fe1212  vmovaps [rsp+0xC0], xmm13
00007f0254fe121b  vmovaps [rsp+0xD0], xmm14
00007f0254fe1224  vmovaps [rsp+0xE0], xmm15
00007f0254fe122d  sub rsp, 0x30
00007f0254fe1231  movaps [rsp], xmm8
00007f0254fe1236  movaps [rsp+0x10], xmm15
00007f0254fe123c  movaps [rsp+0x20], xmm7
00007f0254fe1241  lea rdi, [rsp]
00007f0254fe1245  mov esi, 0x00
00007f0254fe124a  mov rax, 0x55DD1360A530
00007f0254fe1254  call rax
00007f0254fe1256  movaps xmm8, [rsp]
00007f0254fe125b  add rsp, 0x30
00007f0254fe125f  vmovaps xmm0, [rsp]
00007f0254fe1264  vmovaps xmm1, [rsp+0x10]
00007f0254fe126a  vmovaps xmm2, [rsp+0x20]
00007f0254fe1270  vmovaps xmm3, [rsp+0x30]
00007f0254fe1276  vmovaps xmm4, [rsp+0x40]
00007f0254fe127c  vmovaps xmm5, [rsp+0x50]
00007f0254fe1282  vmovaps xmm6, [rsp+0x60]
00007f0254fe1288  vmovaps xmm7, [rsp+0x70]
00007f0254fe128e  vmovaps xmm9, [rsp+0x80]
00007f0254fe1297  vmovaps xmm10, [rsp+0x90]
00007f0254fe12a0  vmovaps xmm11, [rsp+0xA0]
00007f0254fe12a9  vmovaps xmm12, [rsp+0xB0]
00007f0254fe12b2  vmovaps xmm13, [rsp+0xC0]
00007f0254fe12bb  vmovaps xmm14, [rsp+0xD0]
00007f0254fe12c4  vmovaps xmm15, [rsp+0xE0]
00007f0254fe12cd  add rsp, 0xF0
00007f0254fe12d4  pop r11
00007f0254fe12d6  pop r10
00007f0254fe12d8  pop r9
00007f0254fe12da  pop r8
00007f0254fe12dc  pop rsi
00007f0254fe12dd  pop rdi
00007f0254fe12de  pop rdx
00007f0254fe12df  pop rcx
00007f0254fe12e0  pop rax
00007f0254fe12e1  add rsp, 0x08
00007f0254fe12e5  jmp 0x00007F0254FDC787
00007f0254fe12ea  sub rsp, 0x08
00007f0254fe12ee  push rax
00007f0254fe12ef  push rcx
00007f0254fe12f0  push rdx
00007f0254fe12f1  push rdi
00007f0254fe12f2  push rsi
00007f0254fe12f3  push r8
00007f0254fe12f5  push r9
00007f0254fe12f7  push r10
00007f0254fe12f9  push r11
00007f0254fe12fb  sub rsp, 0xF0
00007f0254fe1302  vmovaps [rsp], xmm0
00007f0254fe1307  vmovaps [rsp+0x10], xmm1
00007f0254fe130d  vmovaps [rsp+0x20], xmm2
00007f0254fe1313  vmovaps [rsp+0x30], xmm3
00007f0254fe1319  vmovaps [rsp+0x40], xmm4
00007f0254fe131f  vmovaps [rsp+0x50], xmm5
00007f0254fe1325  vmovaps [rsp+0x60], xmm6
00007f0254fe132b  vmovaps [rsp+0x70], xmm8
00007f0254fe1331  vmovaps [rsp+0x80], xmm9
00007f0254fe133a  vmovaps [rsp+0x90], xmm10
00007f0254fe1343  vmovaps [rsp+0xA0], xmm11
00007f0254fe134c  vmovaps [rsp+0xB0], xmm12
00007f0254fe1355  vmovaps [rsp+0xC0], xmm13
00007f0254fe135e  vmovaps [rsp+0xD0], xmm14
00007f0254fe1367  vmovaps [rsp+0xE0], xmm15
00007f0254fe1370  sub rsp, 0x30
00007f0254fe1374  movaps [rsp], xmm7
00007f0254fe1378  movaps [rsp+0x10], xmm9
00007f0254fe137e  movaps [rsp+0x20], xmm15
00007f0254fe1384  lea rdi, [rsp]
00007f0254fe1388  mov esi, 0x00
00007f0254fe138d  mov rax, 0x55DD1360A530
00007f0254fe1397  call rax
00007f0254fe1399  movaps xmm7, [rsp]
00007f0254fe139d  add rsp, 0x30
00007f0254fe13a1  vmovaps xmm0, [rsp]
00007f0254fe13a6  vmovaps xmm1, [rsp+0x10]
00007f0254fe13ac  vmovaps xmm2, [rsp+0x20]
00007f0254fe13b2  vmovaps xmm3, [rsp+0x30]
00007f0254fe13b8  vmovaps xmm4, [rsp+0x40]
00007f0254fe13be  vmovaps xmm5, [rsp+0x50]
00007f0254fe13c4  vmovaps xmm6, [rsp+0x60]
00007f0254fe13ca  vmovaps xmm8, [rsp+0x70]
00007f0254fe13d0  vmovaps xmm9, [rsp+0x80]
00007f0254fe13d9  vmovaps xmm10, [rsp+0x90]
00007f0254fe13e2  vmovaps xmm11, [rsp+0xA0]
00007f0254fe13eb  vmovaps xmm12, [rsp+0xB0]
00007f0254fe13f4  vmovaps xmm13, [rsp+0xC0]
00007f0254fe13fd  vmovaps xmm14, [rsp+0xD0]
00007f0254fe1406  vmovaps xmm15, [rsp+0xE0]
00007f0254fe140f  add rsp, 0xF0
00007f0254fe1416  pop r11
00007f0254fe1418  pop r10
00007f0254fe141a  pop r9
00007f0254fe141c  pop r8
00007f0254fe141e  pop rsi
00007f0254fe141f  pop rdi
00007f0254fe1420  pop rdx
00007f0254fe1421  pop rcx
00007f0254fe1422  pop rax
00007f0254fe1423  add rsp, 0x08
00007f0254fe1427  jmp 0x00007F0254FDC7B4
00007f0254fe142c  sub rsp, 0x08
00007f0254fe1430  push rax
00007f0254fe1431  push rcx
00007f0254fe1432  push rdx
00007f0254fe1433  push rdi
00007f0254fe1434  push rsi
00007f0254fe1435  push r8
00007f0254fe1437  push r9
00007f0254fe1439  push r10
00007f0254fe143b  push r11
00007f0254fe143d  sub rsp, 0xF0
00007f0254fe1444  vmovaps [rsp], xmm0
00007f0254fe1449  vmovaps [rsp+0x10], xmm1
00007f0254fe144f  vmovaps [rsp+0x20], xmm2
00007f0254fe1455  vmovaps [rsp+0x30], xmm3
00007f0254fe145b  vmovaps [rsp+0x40], xmm4
00007f0254fe1461  vmovaps [rsp+0x50], xmm5
00007f0254fe1467  vmovaps [rsp+0x60], xmm6
00007f0254fe146d  vmovaps [rsp+0x70], xmm7
00007f0254fe1473  vmovaps [rsp+0x80], xmm8
00007f0254fe147c  vmovaps [rsp+0x90], xmm10
00007f0254fe1485  vmovaps [rsp+0xA0], xmm11
00007f0254fe148e  vmovaps [rsp+0xB0], xmm12
00007f0254fe1497  vmovaps [rsp+0xC0], xmm13
00007f0254fe14a0  vmovaps [rsp+0xD0], xmm14
00007f0254fe14a9  vmovaps [rsp+0xE0], xmm15
00007f0254fe14b2  sub rsp, 0x30
00007f0254fe14b6  movaps [rsp], xmm9
00007f0254fe14bb  movaps [rsp+0x10], xmm13
00007f0254fe14c1  movaps [rsp+0x20], xmm15
00007f0254fe14c7  lea rdi, [rsp]
00007f0254fe14cb  mov esi, 0x00
00007f0254fe14d0  mov rax, 0x55DD1360A530
00007f0254fe14da  call rax
00007f0254fe14dc  movaps xmm9, [rsp]
00007f0254fe14e1  add rsp, 0x30
00007f0254fe14e5  vmovaps xmm0, [rsp]
00007f0254fe14ea  vmovaps xmm1, [rsp+0x10]
00007f0254fe14f0  vmovaps xmm2, [rsp+0x20]
00007f0254fe14f6  vmovaps xmm3, [rsp+0x30]
00007f0254fe14fc  vmovaps xmm4, [rsp+0x40]
00007f0254fe1502  vmovaps xmm5, [rsp+0x50]
00007f0254fe1508  vmovaps xmm6, [rsp+0x60]
00007f0254fe150e  vmovaps xmm7, [rsp+0x70]
00007f0254fe1514  vmovaps xmm8, [rsp+0x80]
00007f0254fe151d  vmovaps xmm10, [rsp+0x90]
00007f0254fe1526  vmovaps xmm11, [rsp+0xA0]
00007f0254fe152f  vmovaps xmm12, [rsp+0xB0]
00007f0254fe1538  vmovaps xmm13, [rsp+0xC0]
00007f0254fe1541  vmovaps xmm14, [rsp+0xD0]
00007f0254fe154a  vmovaps xmm15, [rsp+0xE0]
00007f0254fe1553  add rsp, 0xF0
00007f0254fe155a  pop r11
00007f0254fe155c  pop r10
00007f0254fe155e  pop r9
00007f0254fe1560  pop r8
00007f0254fe1562  pop rsi
00007f0254fe1563  pop rdi
00007f0254fe1564  pop rdx
00007f0254fe1565  pop rcx
00007f0254fe1566  pop rax
00007f0254fe1567  add rsp, 0x08
00007f0254fe156b  jmp 0x00007F0254FDC7E2
00007f0254fe1570  sub rsp, 0x08
00007f0254fe1574  push rax
00007f0254fe1575  push rcx
00007f0254fe1576  push rdx
00007f0254fe1577  push rdi
00007f0254fe1578  push rsi
00007f0254fe1579  push r8
00007f0254fe157b  push r9
00007f0254fe157d  push r10
00007f0254fe157f  push r11
00007f0254fe1581  sub rsp, 0xF0
00007f0254fe1588  vmovaps [rsp], xmm0
00007f0254fe158d  vmovaps [rsp+0x10], xmm1
00007f0254fe1593  vmovaps [rsp+0x20], xmm2
00007f0254fe1599  vmovaps [rsp+0x30], xmm3
00007f0254fe159f  vmovaps [rsp+0x40], xmm4
00007f0254fe15a5  vmovaps [rsp+0x50], xmm5
00007f0254fe15ab  vmovaps [rsp+0x60], xmm6
00007f0254fe15b1  vmovaps [rsp+0x70], xmm7
00007f0254fe15b7  vmovaps [rsp+0x80], xmm8
00007f0254fe15c0  vmovaps [rsp+0x90], xmm9
00007f0254fe15c9  vmovaps [rsp+0xA0], xmm10
00007f0254fe15d2  vmovaps [rsp+0xB0], xmm11
00007f0254fe15db  vmovaps [rsp+0xC0], xmm12
00007f0254fe15e4  vmovaps [rsp+0xD0], xmm13
00007f0254fe15ed  vmovaps [rsp+0xE0], xmm14
00007f0254fe15f6  sub rsp, 0x30
00007f0254fe15fa  movaps [rsp], xmm15
00007f0254fe15ff  movaps [rsp+0x10], xmm11
00007f0254fe1605  movaps [rsp+0x20], xmm12
00007f0254fe160b  lea rdi, [rsp]
00007f0254fe160f  mov esi, 0x00
00007f0254fe1614  mov rax, 0x55DD1360A530
00007f0254fe161e  call rax
00007f0254fe1620  movaps xmm15, [rsp]
00007f0254fe1625  add rsp, 0x30
00007f0254fe1629  vmovaps xmm0, [rsp]
00007f0254fe162e  vmovaps xmm1, [rsp+0x10]
00007f0254fe1634  vmovaps xmm2, [rsp+0x20]
00007f0254fe163a  vmovaps xmm3, [rsp+0x30]
00007f0254fe1640  vmovaps xmm4, [rsp+0x40]
00007f0254fe1646  vmovaps xmm5, [rsp+0x50]
00007f0254fe164c  vmovaps xmm6, [rsp+0x60]
00007f0254fe1652  vmovaps xmm7, [rsp+0x70]
00007f0254fe1658  vmovaps xmm8, [rsp+0x80]
00007f0254fe1661  vmovaps xmm9, [rsp+0x90]
00007f0254fe166a  vmovaps xmm10, [rsp+0xA0]
00007f0254fe1673  vmovaps xmm11, [rsp+0xB0]
00007f0254fe167c  vmovaps xmm12, [rsp+0xC0]
00007f0254fe1685  vmovaps xmm13, [rsp+0xD0]
00007f0254fe168e  vmovaps xmm14, [rsp+0xE0]
00007f0254fe1697  add rsp, 0xF0
00007f0254fe169e  pop r11
00007f0254fe16a0  pop r10
00007f0254fe16a2  pop r9
00007f0254fe16a4  pop r8
00007f0254fe16a6  pop rsi
00007f0254fe16a7  pop rdi
00007f0254fe16a8  pop rdx
00007f0254fe16a9  pop rcx
00007f0254fe16aa  pop rax
00007f0254fe16ab  add rsp, 0x08
00007f0254fe16af  jmp 0x00007F0254FDC7FD
00007f0254fe16b4  sub rsp, 0x08
00007f0254fe16b8  push rax
00007f0254fe16b9  push rcx
00007f0254fe16ba  push rdx
00007f0254fe16bb  push rdi
00007f0254fe16bc  push rsi
00007f0254fe16bd  push r8
00007f0254fe16bf  push r9
00007f0254fe16c1  push r10
00007f0254fe16c3  push r11
00007f0254fe16c5  sub rsp, 0xF0
00007f0254fe16cc  vmovaps [rsp], xmm0
00007f0254fe16d1  vmovaps [rsp+0x10], xmm1
00007f0254fe16d7  vmovaps [rsp+0x20], xmm2
00007f0254fe16dd  vmovaps [rsp+0x30], xmm3
00007f0254fe16e3  vmovaps [rsp+0x40], xmm4
00007f0254fe16e9  vmovaps [rsp+0x50], xmm5
00007f0254fe16ef  vmovaps [rsp+0x60], xmm6
00007f0254fe16f5  vmovaps [rsp+0x70], xmm7
00007f0254fe16fb  vmovaps [rsp+0x80], xmm8
00007f0254fe1704  vmovaps [rsp+0x90], xmm9
00007f0254fe170d  vmovaps [rsp+0xA0], xmm10
00007f0254fe1716  vmovaps [rsp+0xB0], xmm11
00007f0254fe171f  vmovaps [rsp+0xC0], xmm12
00007f0254fe1728  vmovaps [rsp+0xD0], xmm14
00007f0254fe1731  vmovaps [rsp+0xE0], xmm15
00007f0254fe173a  sub rsp, 0x30
00007f0254fe173e  movaps [rsp], xmm13
00007f0254fe1743  movaps [rsp+0x10], xmm10
00007f0254fe1749  movaps [rsp+0x20], xmm14
00007f0254fe174f  lea rdi, [rsp]
00007f0254fe1753  mov esi, 0x00
00007f0254fe1758  mov rax, 0x55DD1360A530
00007f0254fe1762  call rax
00007f0254fe1764  movaps xmm13, [rsp]
00007f0254fe1769  add rsp, 0x30
00007f0254fe176d  vmovaps xmm0, [rsp]
00007f0254fe1772  vmovaps xmm1, [rsp+0x10]
00007f0254fe1778  vmovaps xmm2, [rsp+0x20]
00007f0254fe177e  vmovaps xmm3, [rsp+0x30]
00007f0254fe1784  vmovaps xmm4, [rsp+0x40]
00007f0254fe178a  vmovaps xmm5, [rsp+0x50]
00007f0254fe1790  vmovaps xmm6, [rsp+0x60]
00007f0254fe1796  vmovaps xmm7, [rsp+0x70]
00007f0254fe179c  vmovaps xmm8, [rsp+0x80]
00007f0254fe17a5  vmovaps xmm9, [rsp+0x90]
00007f0254fe17ae  vmovaps xmm10, [rsp+0xA0]
00007f0254fe17b7  vmovaps xmm11, [rsp+0xB0]
00007f0254fe17c0  vmovaps xmm12, [rsp+0xC0]
00007f0254fe17c9  vmovaps xmm14, [rsp+0xD0]
00007f0254fe17d2  vmovaps xmm15, [rsp+0xE0]
00007f0254fe17db  add rsp, 0xF0
00007f0254fe17e2  pop r11
00007f0254fe17e4  pop r10
00007f0254fe17e6  pop r9
00007f0254fe17e8  pop r8
00007f0254fe17ea  pop rsi
00007f0254fe17eb  pop rdi
00007f0254fe17ec  pop rdx
00007f0254fe17ed  pop rcx
00007f0254fe17ee  pop rax
00007f0254fe17ef  add rsp, 0x08
00007f0254fe17f3  jmp 0x00007F0254FDC820
00007f0254fe17f8  sub rsp, 0x08
00007f0254fe17fc  push rax
00007f0254fe17fd  push rcx
00007f0254fe17fe  push rdx
00007f0254fe17ff  push rdi
00007f0254fe1800  push rsi
00007f0254fe1801  push r8
00007f0254fe1803  push r9
00007f0254fe1805  push r10
00007f0254fe1807  push r11
00007f0254fe1809  sub rsp, 0xF0
00007f0254fe1810  vmovaps [rsp], xmm0
00007f0254fe1815  vmovaps [rsp+0x10], xmm1
00007f0254fe181b  vmovaps [rsp+0x20], xmm2
00007f0254fe1821  vmovaps [rsp+0x30], xmm3
00007f0254fe1827  vmovaps [rsp+0x40], xmm4
00007f0254fe182d  vmovaps [rsp+0x50], xmm5
00007f0254fe1833  vmovaps [rsp+0x60], xmm6
00007f0254fe1839  vmovaps [rsp+0x70], xmm7
00007f0254fe183f  vmovaps [rsp+0x80], xmm8
00007f0254fe1848  vmovaps [rsp+0x90], xmm9
00007f0254fe1851  vmovaps [rsp+0xA0], xmm10
00007f0254fe185a  vmovaps [rsp+0xB0], xmm11
00007f0254fe1863  vmovaps [rsp+0xC0], xmm12
00007f0254fe186c  vmovaps [rsp+0xD0], xmm13
00007f0254fe1875  vmovaps [rsp+0xE0], xmm15
00007f0254fe187e  sub rsp, 0x30
00007f0254fe1882  movaps [rsp], xmm14
00007f0254fe1887  movaps [rsp+0x10], xmm1
00007f0254fe188c  movaps [rsp+0x20], xmm7
00007f0254fe1891  lea rdi, [rsp]
00007f0254fe1895  mov esi, 0x00
00007f0254fe189a  mov rax, 0x55DD1360A530
00007f0254fe18a4  call rax
00007f0254fe18a6  movaps xmm14, [rsp]
00007f0254fe18ab  add rsp, 0x30
00007f0254fe18af  vmovaps xmm0, [rsp]
00007f0254fe18b4  vmovaps xmm1, [rsp+0x10]
00007f0254fe18ba  vmovaps xmm2, [rsp+0x20]
00007f0254fe18c0  vmovaps xmm3, [rsp+0x30]
00007f0254fe18c6  vmovaps xmm4, [rsp+0x40]
00007f0254fe18cc  vmovaps xmm5, [rsp+0x50]
00007f0254fe18d2  vmovaps xmm6, [rsp+0x60]
00007f0254fe18d8  vmovaps xmm7, [rsp+0x70]
00007f0254fe18de  vmovaps xmm8, [rsp+0x80]
00007f0254fe18e7  vmovaps xmm9, [rsp+0x90]
00007f0254fe18f0  vmovaps xmm10, [rsp+0xA0]
00007f0254fe18f9  vmovaps xmm11, [rsp+0xB0]
00007f0254fe1902  vmovaps xmm12, [rsp+0xC0]
00007f0254fe190b  vmovaps xmm13, [rsp+0xD0]
00007f0254fe1914  vmovaps xmm15, [rsp+0xE0]
00007f0254fe191d  add rsp, 0xF0
00007f0254fe1924  pop r11
00007f0254fe1926  pop r10
00007f0254fe1928  pop r9
00007f0254fe192a  pop r8
00007f0254fe192c  pop rsi
00007f0254fe192d  pop rdi
00007f0254fe192e  pop rdx
00007f0254fe192f  pop rcx
00007f0254fe1930  pop rax
00007f0254fe1931  add rsp, 0x08
00007f0254fe1935  jmp 0x00007F0254FDC843
00007f0254fe193a  sub rsp, 0x08
00007f0254fe193e  push rax
00007f0254fe193f  push rcx
00007f0254fe1940  push rdx
00007f0254fe1941  push rdi
00007f0254fe1942  push rsi
00007f0254fe1943  push r8
00007f0254fe1945  push r9
00007f0254fe1947  push r10
00007f0254fe1949  push r11
00007f0254fe194b  sub rsp, 0xF0
00007f0254fe1952  vmovaps [rsp], xmm0
00007f0254fe1957  vmovaps [rsp+0x10], xmm2
00007f0254fe195d  vmovaps [rsp+0x20], xmm3
00007f0254fe1963  vmovaps [rsp+0x30], xmm4
00007f0254fe1969  vmovaps [rsp+0x40], xmm5
00007f0254fe196f  vmovaps [rsp+0x50], xmm6
00007f0254fe1975  vmovaps [rsp+0x60], xmm7
00007f0254fe197b  vmovaps [rsp+0x70], xmm8
00007f0254fe1981  vmovaps [rsp+0x80], xmm9
00007f0254fe198a  vmovaps [rsp+0x90], xmm10
00007f0254fe1993  vmovaps [rsp+0xA0], xmm11
00007f0254fe199c  vmovaps [rsp+0xB0], xmm12
00007f0254fe19a5  vmovaps [rsp+0xC0], xmm13
00007f0254fe19ae  vmovaps [rsp+0xD0], xmm14
00007f0254fe19b7  vmovaps [rsp+0xE0], xmm15
00007f0254fe19c0  sub rsp, 0x30
00007f0254fe19c4  movaps [rsp], xmm1
00007f0254fe19c8  movaps [rsp+0x10], xmm8
00007f0254fe19ce  movaps [rsp+0x20], xmm9
00007f0254fe19d4  lea rdi, [rsp]
00007f0254fe19d8  mov esi, 0x00
00007f0254fe19dd  mov rax, 0x55DD1360A530
00007f0254fe19e7  call rax
00007f0254fe19e9  movaps xmm1, [rsp]
00007f0254fe19ed  add rsp, 0x30
00007f0254fe19f1  vmovaps xmm0, [rsp]
00007f0254fe19f6  vmovaps xmm2, [rsp+0x10]
00007f0254fe19fc  vmovaps xmm3, [rsp+0x20]
00007f0254fe1a02  vmovaps xmm4, [rsp+0x30]
00007f0254fe1a08  vmovaps xmm5, [rsp+0x40]
00007f0254fe1a0e  vmovaps xmm6, [rsp+0x50]
00007f0254fe1a14  vmovaps xmm7, [rsp+0x60]
00007f0254fe1a1a  vmovaps xmm8, [rsp+0x70]
00007f0254fe1a20  vmovaps xmm9, [rsp+0x80]
00007f0254fe1a29  vmovaps xmm10, [rsp+0x90]
00007f0254fe1a32  vmovaps xmm11, [rsp+0xA0]
00007f0254fe1a3b  vmovaps xmm12, [rsp+0xB0]
00007f0254fe1a44  vmovaps xmm13, [rsp+0xC0]
00007f0254fe1a4d  vmovaps xmm14, [rsp+0xD0]
00007f0254fe1a56  vmovaps xmm15, [rsp+0xE0]
00007f0254fe1a5f  add rsp, 0xF0
00007f0254fe1a66  pop r11
00007f0254fe1a68  pop r10
00007f0254fe1a6a  pop r9
00007f0254fe1a6c  pop r8
00007f0254fe1a6e  pop rsi
00007f0254fe1a6f  pop rdi
00007f0254fe1a70  pop rdx
00007f0254fe1a71  pop rcx
00007f0254fe1a72  pop rax
00007f0254fe1a73  add rsp, 0x08
00007f0254fe1a77  jmp 0x00007F0254FDC865
00007f0254fe1a7c  call 0x00007F0254EE5940
00007f0254fe1a81  jmp 0x00007F0254FDC873
00007f0254fe1a86  call 0x00007F0254E0C380
00007f0254fe1a8b  jmp 0x00007F0254FDC87D
00007f0254fe1a90  call 0x00007F0254E0D600
00007f0254fe1a95  jmp 0x00007F0254FDC887
00007f0254fe1a9a  call 0x00007F0254DFF540
00007f0254fe1a9f  jmp 0x00007F0254FDC891
00007f0254fe1aa4  int3
00007f0254fe1aa5  nop [rax+rax*1], ax
00007f0254fe1aae  nop
00007f0254fe1ab0  mov rax, [r15+0xF8]
00007f0254fe1ab7  lea r14, [rax+0x140]
00007f0254fe1abe  mov r12, [r13+r14*1]
00007f0254fe1ac3  mov [r15+0xE8], r12
00007f0254fe1aca  lea r14, [rax+0x130]
00007f0254fe1ad1  mov r12, [r13+r14*1]
00007f0254fe1ad6  lea r14, [rax+0x138]
00007f0254fe1add  mov r11, [r13+r14*1]
00007f0254fe1ae2  movq xmm1, r12
00007f0254fe1ae7  movq xmm15, r11
00007f0254fe1aec  movq xmm1, xmm1
00007f0254fe1af0  movq xmm1, xmm1
00007f0254fe1af4  movaps [r15+0x1A0], xmm1
00007f0254fe1afc  movq xmm15, xmm15
00007f0254fe1b01  movq xmm15, xmm15
00007f0254fe1b06  movaps [r15+0x190], xmm15
00007f0254fe1b0e  lea r14, [rax+0x120]
00007f0254fe1b15  mov r12, [r13+r14*1]
00007f0254fe1b1a  lea r14, [rax+0x128]
00007f0254fe1b21  mov r11, [r13+r14*1]
00007f0254fe1b26  movq xmm1, r12
00007f0254fe1b2b  movq xmm15, r11
00007f0254fe1b30  movq xmm1, xmm1
00007f0254fe1b34  movq xmm1, xmm1
00007f0254fe1b38  movaps [r15+0x1C0], xmm1
00007f0254fe1b40  movq xmm15, xmm15
00007f0254fe1b45  movq xmm15, xmm15
00007f0254fe1b4a  movaps [r15+0x1B0], xmm15
00007f0254fe1b52  lea r14, [rax+0x110]
00007f0254fe1b59  mov r12, [r13+r14*1]
00007f0254fe1b5e  lea r14, [rax+0x118]
00007f0254fe1b65  mov r11, [r13+r14*1]
00007f0254fe1b6a  movq xmm1, r12
00007f0254fe1b6f  movq xmm15, r11
00007f0254fe1b74  movq xmm1, xmm1
00007f0254fe1b78  movq xmm1, xmm1
00007f0254fe1b7c  movaps [r15+0x1E0], xmm1
00007f0254fe1b84  movq xmm15, xmm15
00007f0254fe1b89  movq xmm15, xmm15
00007f0254fe1b8e  movaps [r15+0x1D0], xmm15
00007f0254fe1b96  lea r14, [rax+0x100]
00007f0254fe1b9d  mov r12, [r13+r14*1]
00007f0254fe1ba2  lea r14, [rax+0x108]
00007f0254fe1ba9  mov r11, [r13+r14*1]
00007f0254fe1bae  movq xmm1, r12
00007f0254fe1bb3  movq xmm15, r11
00007f0254fe1bb8  movq xmm1, xmm1
00007f0254fe1bbc  movq xmm1, xmm1
00007f0254fe1bc0  movaps [r15+0x200], xmm1
00007f0254fe1bc8  movq xmm15, xmm15
00007f0254fe1bcd  movq xmm15, xmm15
00007f0254fe1bd2  movaps [r15+0x1F0], xmm15
00007f0254fe1bda  mov qword ptr [r15+0x40], 0x430000
00007f0254fe1be2  mov r14d, 0x430510
00007f0254fe1be8  mov r12, [r13+r14*1]
00007f0254fe1bed  movq xmm1, r12
00007f0254fe1bf2  lea r14, [rax+0x150]
00007f0254fe1bf9  mov [r15+0xF8], r14
00007f0254fe1c00  mov rax, [r15+0x50]
00007f0254fe1c04  movups xmm15, [r13+rax*1]
00007f0254fe1c0a  movaps [r15+0x120], xmm15
00007f0254fe1c12  mov qword ptr [r15+0x48], 0x10
00007f0254fe1c1a  xor eax, eax
00007f0254fe1c1c  mov r14d, 0x10
00007f0254fe1c22  mov r12d, 0x200
00007f0254fe1c28  cmp r14, r12
00007f0254fe1c2b  cmc
00007f0254fe1c2c  lahf
00007f0254fe1c2d  seto al
00007f0254fe1c30  mov [r15+0x108], eax
00007f0254fe1c37  pextrq rax, xmm15, 0x01
00007f0254fe1c3e  movq xmm14, rax
00007f0254fe1c43  movaps [r15+0x130], xmm14
00007f0254fe1c4b  movq rax, xmm1
00007f0254fe1c50  movq r14, xmm15
00007f0254fe1c55  vmovq xmm1, rax
00007f0254fe1c5a  vmovq xmm15, r14
00007f0254fe1c5f  movaps xmm13, xmm1
00007f0254fe1c63  addsd xmm13, xmm15
00007f0254fe1c68  ucomisd xmm13, xmm13
00007f0254fe1c6d  jp 0x00007F0254FE1D86
00007f0254fe1c73  movq xmm13, xmm13
00007f0254fe1c78  movq rax, xmm13
00007f0254fe1c7d  movq r14, xmm14
00007f0254fe1c82  vmovq xmm1, rax
00007f0254fe1c87  vmovq xmm15, r14
00007f0254fe1c8c  movaps xmm14, xmm1
00007f0254fe1c90  addsd xmm14, xmm15
00007f0254fe1c95  ucomisd xmm14, xmm14
00007f0254fe1c9a  jp 0x00007F0254FE1DCE
00007f0254fe1ca0  movq xmm14, xmm14
00007f0254fe1ca5  movaps [r15+0x110], xmm14
00007f0254fe1cad  mov eax, [r15+0x108]
00007f0254fe1cb4  sahf
00007f0254fe1cb5  jnz 0x00007F0254FE1CE7
00007f0254fe1cb7  cmp dword ptr [r15+0x318], 0x00
00007f0254fe1cbf  jz 0x00007F0254FE1FE0
00007f0254fe1cc5  nop [rax+rax*1], ax
00007f0254fe1cce  nop [rax+rax*1], eax
00007f0254fe1cd6  mov eax, 0x410490
00007f0254fe1cdb  mov [r15+0x100], rax
00007f0254fe1ce2  jmp 0x00007F0254DFE110
00007f0254fe1ce7  cmp dword ptr [r15+0x318], 0x00
00007f0254fe1cef  jz 0x00007F0254FE1E20
00007f0254fe1cf5  nop [rax+rax*1], ax
00007f0254fe1cfe  nop [rax+rax*1], eax
00007f0254fe1d06  mov eax, 0x410474
00007f0254fe1d0b  mov [r15+0x100], rax
00007f0254fe1d12  jmp 0x00007F0254DFE110
00007f0254fe1d17  int3
00007f0254fe1d18  call 0x00007F0254EE27E0
00007f0254fe1d1d  jmp 0x00007F0254FE1AC3
00007f0254fe1d22  call 0x00007F0254EE27E0
00007f0254fe1d27  jmp 0x00007F0254FE1AD6
00007f0254fe1d2c  call 0x00007F0254EE1570
00007f0254fe1d31  jmp 0x00007F0254FE1AE2
00007f0254fe1d36  call 0x00007F0254EE27E0
00007f0254fe1d3b  jmp 0x00007F0254FE1B1A
00007f0254fe1d40  call 0x00007F0254EE1570
00007f0254fe1d45  jmp 0x00007F0254FE1B26
00007f0254fe1d4a  call 0x00007F0254EE27E0
00007f0254fe1d4f  jmp 0x00007F0254FE1B5E
00007f0254fe1d54  call 0x00007F0254EE1570
00007f0254fe1d59  jmp 0x00007F0254FE1B6A
00007f0254fe1d5e  call 0x00007F0254EE27E0
00007f0254fe1d63  jmp 0x00007F0254FE1BA2
00007f0254fe1d68  call 0x00007F0254EE1570
00007f0254fe1d6d  jmp 0x00007F0254FE1BAE
00007f0254fe1d72  call 0x00007F0254EE27E0
00007f0254fe1d77  jmp 0x00007F0254FE1BED
00007f0254fe1d7c  call 0x00007F0254E0E760
00007f0254fe1d81  jmp 0x00007F0254FE1C0A
00007f0254fe1d86  ucomisd xmm1, xmm15
00007f0254fe1d8b  jp 0x00007F0254FE1D9A
00007f0254fe1d8d  movaps xmm13, [0x00007F0254BFE060]
00007f0254fe1d95  jmp 0x00007F0254FE1C73
00007f0254fe1d9a  vxorps xmm0, xmm1, xmm15
00007f0254fe1d9f  pextrw eax, xmm0, 0x03
00007f0254fe1da4  and eax, 0x7FF8
00007f0254fe1da9  cmp eax, 0x08
00007f0254fe1dac  jnz 0x00007F0254FE1C73
00007f0254fe1db2  movq rax, xmm15
00007f0254fe1db7  shl rax, 0x0D
00007f0254fe1dbb  jbe 0x00007F0254FE1C73
00007f0254fe1dc1  vorps xmm13, xmm15, [0x00007F0254BFE070]
00007f0254fe1dc9  jmp 0x00007F0254FE1C73
00007f0254fe1dce  ucomisd xmm1, xmm15
00007f0254fe1dd3  jp 0x00007F0254FE1DE2
00007f0254fe1dd5  movaps xmm14, [0x00007F0254BFE060]
00007f0254fe1ddd  jmp 0x00007F0254FE1CA0
00007f0254fe1de2  vxorps xmm0, xmm1, xmm15
00007f0254fe1de7  pextrw eax, xmm0, 0x03
00007f0254fe1dec  and eax, 0x7FF8
00007f0254fe1df1  cmp eax, 0x08
00007f0254fe1df4  jnz 0x00007F0254FE1CA0
00007f0254fe1dfa  movq rax, xmm15
00007f0254fe1dff  shl rax, 0x0D
00007f0254fe1e03  jbe 0x00007F0254FE1CA0
00007f0254fe1e09  vorps xmm14, xmm15, [0x00007F0254BFE070]
00007f0254fe1e11  jmp 0x00007F0254FE1CA0
00007f0254fe1e16  int3
00007f0254fe1e17  nop [rax+rax*1], ax
00007f0254fe1e20  mov rax, [r15+0x48]
00007f0254fe1e24  mov r14, [r15+0x50]
00007f0254fe1e28  lea r12, [r14+rax*1]
00007f0254fe1e2c  movups xmm1, [r13+r12*1]
00007f0254fe1e32  movaps [r15+0x120], xmm1
00007f0254fe1e3a  lea r14, [rax+0x10]
00007f0254fe1e3e  mov [r15+0x48], r14
00007f0254fe1e42  xor eax, eax
00007f0254fe1e44  mov r12d, 0x200
00007f0254fe1e4a  cmp r14, r12
00007f0254fe1e4d  cmc
00007f0254fe1e4e  lahf
00007f0254fe1e4f  seto al
00007f0254fe1e52  mov [r15+0x108], eax
00007f0254fe1e59  pextrq rax, xmm1, 0x01
00007f0254fe1e60  movq xmm15, rax
00007f0254fe1e65  movaps [r15+0x130], xmm15
00007f0254fe1e6d  movaps xmm14, [r15+0x110]
00007f0254fe1e75  movq rax, xmm14
00007f0254fe1e7a  movq r14, xmm1
00007f0254fe1e7f  vmovq xmm1, rax
00007f0254fe1e84  vmovq xmm14, r14
00007f0254fe1e89  movaps xmm13, xmm1
00007f0254fe1e8d  addsd xmm13, xmm14
00007f0254fe1e92  ucomisd xmm13, xmm13
00007f0254fe1e97  jp 0x00007F0254FE1F4C
00007f0254fe1e9d  movq xmm13, xmm13
00007f0254fe1ea2  movq rax, xmm13
00007f0254fe1ea7  movq r14, xmm15
00007f0254fe1eac  vmovq xmm1, rax
00007f0254fe1eb1  vmovq xmm15, r14
00007f0254fe1eb6  movaps xmm14, xmm1
00007f0254fe1eba  addsd xmm14, xmm15
00007f0254fe1ebf  ucomisd xmm14, xmm14
00007f0254fe1ec4  jp 0x00007F0254FE1F94
00007f0254fe1eca  movq xmm14, xmm14
00007f0254fe1ecf  movaps [r15+0x110], xmm14
00007f0254fe1ed7  mov eax, [r15+0x108]
00007f0254fe1ede  sahf
00007f0254fe1edf  jnz 0x00007F0254FE1F11
00007f0254fe1ee1  cmp dword ptr [r15+0x318], 0x00
00007f0254fe1ee9  jz 0x00007F0254FE1FE0
00007f0254fe1eef  nop [rax+rax*1], ax
00007f0254fe1ef8  nop [rax+rax*1], eax
00007f0254fe1f00  mov eax, 0x410490
00007f0254fe1f05  mov [r15+0x100], rax
00007f0254fe1f0c  jmp 0x00007F0254DFE110
00007f0254fe1f11  cmp dword ptr [r15+0x318], 0x00
00007f0254fe1f19  jz 0x00007F0254FE1E20
00007f0254fe1f1f  nop [rax+rax*1], ax
00007f0254fe1f28  nop [rax+rax*1], eax
00007f0254fe1f30  mov eax, 0x410474
00007f0254fe1f35  mov [r15+0x100], rax
00007f0254fe1f3c  jmp 0x00007F0254DFE110
00007f0254fe1f41  int3
00007f0254fe1f42  call 0x00007F0254EB52F0
00007f0254fe1f47  jmp 0x00007F0254FE1E32
00007f0254fe1f4c  ucomisd xmm1, xmm14
00007f0254fe1f51  jp 0x00007F0254FE1F60
00007f0254fe1f53  movaps xmm13, [0x00007F0254BFE060]
00007f0254fe1f5b  jmp 0x00007F0254FE1E9D
00007f0254fe1f60  vxorps xmm0, xmm1, xmm14
00007f0254fe1f65  pextrw eax, xmm0, 0x03
00007f0254fe1f6a  and eax, 0x7FF8
00007f0254fe1f6f  cmp eax, 0x08
00007f0254fe1f72  jnz 0x00007F0254FE1E9D
00007f0254fe1f78  movq rax, xmm14
00007f0254fe1f7d  shl rax, 0x0D
00007f0254fe1f81  jbe 0x00007F0254FE1E9D
00007f0254fe1f87  vorps xmm13, xmm14, [0x00007F0254BFE070]
00007f0254fe1f8f  jmp 0x00007F0254FE1E9D
00007f0254fe1f94  ucomisd xmm1, xmm15
00007f0254fe1f99  jp 0x00007F0254FE1FA8
00007f0254fe1f9b  movaps xmm14, [0x00007F0254BFE060]
00007f0254fe1fa3  jmp 0x00007F0254FE1ECA
00007f0254fe1fa8  vxorps xmm0, xmm1, xmm15
00007f0254fe1fad  pextrw eax, xmm0, 0x03
00007f0254fe1fb2  and eax, 0x7FF8
00007f0254fe1fb7  cmp eax, 0x08
00007f0254fe1fba  jnz 0x00007F0254FE1ECA
00007f0254fe1fc0  movq rax, xmm15
00007f0254fe1fc5  shl rax, 0x0D
00007f0254fe1fc9  jbe 0x00007F0254FE1ECA
00007f0254fe1fcf  vorps xmm14, xmm15, [0x00007F0254BFE070]
00007f0254fe1fd7  jmp 0x00007F0254FE1ECA
00007f0254fe1fdc  int3
00007f0254fe1fdd  nop [rax], eax
00007f0254fe1fe0  mov rax, [r15+0x40]
00007f0254fe1fe4  lea r14, [rax+0x510]
00007f0254fe1feb  movaps xmm1, [r15+0x110]
00007f0254fe1ff3  movq rax, xmm1
00007f0254fe1ff8  mov [r13+r14*1], rax
00007f0254fe1ffd  mov rax, [r15+0xF0]
00007f0254fe2004  mov [r15+0x100], rax
00007f0254fe200b  jmp 0x00007F0254FCE5C0
00007f0254fe2010  int3
00007f0254fe2011  call 0x00007F0254ED5EB0
00007f0254fe2016  jmp 0x00007F0254FE1FFD
00007f0254fe201b  int3
00007f0254fe201c  nop [rax], eax
00007f0254fe2020  mov qword ptr [r15+0x100], 0x04
00007f0254fe202b  mov esi, 0x00
00007f0254fe2030  mov edx, 0x09
00007f0254fe2035  mov rdi, 0x7FFF03273A40
00007f0254fe203f  mov rax, 0x55DD1349D970
00007f0254fe2049  call rax
00007f0254fe204b  cmp dword ptr [r15+0x318], 0x00
00007f0254fe2053  jnz 0x00007F0254DFE110
00007f0254fe2059  jmp 0x00007F0254DFE0A0
00007f0254fe205e  int3
00007f0254fe205f  int3
