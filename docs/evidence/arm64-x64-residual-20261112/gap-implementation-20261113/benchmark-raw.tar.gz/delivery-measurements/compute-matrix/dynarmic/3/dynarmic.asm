00007cf1741ce69b  nop [rax+rax*1], eax
00007cf1741ce6a0  vmovaps xmm1, [0x00007CF173DFE010]
00007cf1741ce6a8  movq xmm1, xmm1
00007cf1741ce6ac  movaps [r15+0x110], xmm1
00007cf1741ce6b4  vmovaps xmm1, [0x00007CF173DFE020]
00007cf1741ce6bc  movq xmm1, xmm1
00007cf1741ce6c0  movaps [r15+0x120], xmm1
00007cf1741ce6c8  mov eax, 0x4204C0
00007cf1741ce6cd  mov r14, [r13+rax*1]
00007cf1741ce6d2  movq xmm1, r14
00007cf1741ce6d7  movaps [r15+0x130], xmm1
00007cf1741ce6df  vmovaps xmm1, [0x00007CF173DFE030]
00007cf1741ce6e7  vpbroadcastq xmm1, xmm1
00007cf1741ce6ec  movaps [r15+0x140], xmm1
00007cf1741ce6f4  mov qword ptr [r15+0x40], 0x02
00007cf1741ce6fc  vmovaps xmm15, [0x00007CF173DFE040]
00007cf1741ce704  movq xmm15, xmm15
00007cf1741ce709  movaps [r15+0x150], xmm15
00007cf1741ce711  mov qword ptr [r15+0x58], 0x420000
00007cf1741ce719  vmovaps xmm15, [0x00007CF173DFE050]
00007cf1741ce721  vpbroadcastq xmm15, xmm15
00007cf1741ce726  movaps [r15+0x160], xmm15
00007cf1741ce72e  mov rax, [r15+0x40]
00007cf1741ce732  vmovq xmm14, rax
00007cf1741ce737  vpbroadcastq xmm14, xmm14
00007cf1741ce73c  movaps [r15+0x170], xmm14
00007cf1741ce744  mov eax, 0x4204D0
00007cf1741ce749  movups xmm13, [r13+rax*1]
00007cf1741ce74f  mov qword ptr [r15+0x40], 0x430518
00007cf1741ce757  mov qword ptr [r15+0x50], 0x430720
00007cf1741ce75f  vpmovqd xmm12, xmm13
00007cf1741ce765  pxor xmm11, xmm11
00007cf1741ce76a  punpcklqdq xmm12, xmm11
00007cf1741ce76f  movaps [r15+0x210], xmm12
00007cf1741ce777  movq xmm12, qword ptr [r15+0x120]
00007cf1741ce780  movq xmm11, qword ptr [r15+0x130]
00007cf1741ce789  psubd xmm12, xmm11
00007cf1741ce78e  movq xmm12, xmm12
00007cf1741ce793  paddq xmm13, xmm14
00007cf1741ce798  movaps [r15+0x180], xmm13
00007cf1741ce7a0  movq xmm14, qword ptr [r15+0x150]
00007cf1741ce7a9  paddd xmm11, xmm14
00007cf1741ce7ae  movq xmm11, xmm11
00007cf1741ce7b3  movq xmm11, xmm11
00007cf1741ce7b8  movaps [r15+0x130], xmm11
00007cf1741ce7c0  pmovzxdq xmm12, xmm12
00007cf1741ce7c6  psllq xmm12, 0x00
00007cf1741ce7cc  movq xmm14, qword ptr [r15+0x210]
00007cf1741ce7d5  movq xmm13, qword ptr [r15+0x110]
00007cf1741ce7de  paddd xmm14, xmm13
00007cf1741ce7e3  movq xmm14, xmm14
00007cf1741ce7e8  vcvtuqq2pd xmm12, xmm12
00007cf1741ce7ee  pmovzxdq xmm14, xmm14
00007cf1741ce7f4  psllq xmm14, 0x00
00007cf1741ce7fa  vcvtuqq2pd xmm14, xmm14
00007cf1741ce800  movaps xmm13, xmm12
00007cf1741ce804  mulpd xmm13, xmm1
00007cf1741ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007cf1741ce80f  ptest xmm11, xmm11
00007cf1741ce815  jnz 0x00007CF1741CE8FF
00007cf1741ce81b  movaps [r15+0x220], xmm13
00007cf1741ce823  mov eax, 0x430720
00007cf1741ce828  movups [r13+rax*1], xmm13
00007cf1741ce82e  movaps xmm1, xmm14
00007cf1741ce832  mulpd xmm1, xmm15
00007cf1741ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007cf1741ce83c  ptest xmm13, xmm13
00007cf1741ce842  jnz 0x00007CF1741CEA4C
00007cf1741ce848  movaps [r15+0x210], xmm1
00007cf1741ce850  mov eax, 0x430518
00007cf1741ce855  movups [r13+rax*1], xmm1
00007cf1741ce85b  mov qword ptr [r15+0x48], 0x10
00007cf1741ce863  xor eax, eax
00007cf1741ce865  mov r14d, 0x10
00007cf1741ce86b  mov r12d, 0x200
00007cf1741ce871  cmp r14, r12
00007cf1741ce874  cmc
00007cf1741ce875  lahf
00007cf1741ce876  seto al
00007cf1741ce879  mov [r15+0x108], eax
00007cf1741ce880  mov eax, [r15+0x108]
00007cf1741ce887  sahf
00007cf1741ce888  jnz 0x00007CF1741CE8BA
00007cf1741ce88a  cmp dword ptr [r15+0x318], 0x00
00007cf1741ce892  jz 0x00007CF1741CEFF0
00007cf1741ce898  nop [rax+rax*1], ax
00007cf1741ce8a1  nop [rax+rax*1], eax
00007cf1741ce8a9  mov eax, 0x4101EC
00007cf1741ce8ae  mov [r15+0x100], rax
00007cf1741ce8b5  jmp 0x00007CF173FFE110
00007cf1741ce8ba  cmp dword ptr [r15+0x318], 0x00
00007cf1741ce8c2  jz 0x00007CF1741CEBA0
00007cf1741ce8c8  nop [rax+rax*1], ax
00007cf1741ce8d1  nop [rax+rax*1], eax
00007cf1741ce8d9  mov eax, 0x4101AC
00007cf1741ce8de  mov [r15+0x100], rax
00007cf1741ce8e5  jmp 0x00007CF173FFE110
00007cf1741ce8ea  int3
00007cf1741ce8eb  call 0x00007CF17400DC20
00007cf1741ce8f0  jmp 0x00007CF1741CE6D2
00007cf1741ce8f5  call 0x00007CF17400C260
00007cf1741ce8fa  jmp 0x00007CF1741CE74F
00007cf1741ce8ff  sub rsp, 0x08
00007cf1741ce903  push rax
00007cf1741ce904  push rcx
00007cf1741ce905  push rdx
00007cf1741ce906  push rdi
00007cf1741ce907  push rsi
00007cf1741ce908  push r8
00007cf1741ce90a  push r9
00007cf1741ce90c  push r10
00007cf1741ce90e  push r11
00007cf1741ce910  sub rsp, 0xF0
00007cf1741ce917  vmovaps [rsp], xmm0
00007cf1741ce91c  vmovaps [rsp+0x10], xmm1
00007cf1741ce922  vmovaps [rsp+0x20], xmm2
00007cf1741ce928  vmovaps [rsp+0x30], xmm3
00007cf1741ce92e  vmovaps [rsp+0x40], xmm4
00007cf1741ce934  vmovaps [rsp+0x50], xmm5
00007cf1741ce93a  vmovaps [rsp+0x60], xmm6
00007cf1741ce940  vmovaps [rsp+0x70], xmm7
00007cf1741ce946  vmovaps [rsp+0x80], xmm8
00007cf1741ce94f  vmovaps [rsp+0x90], xmm9
00007cf1741ce958  vmovaps [rsp+0xA0], xmm10
00007cf1741ce961  vmovaps [rsp+0xB0], xmm11
00007cf1741ce96a  vmovaps [rsp+0xC0], xmm12
00007cf1741ce973  vmovaps [rsp+0xD0], xmm14
00007cf1741ce97c  vmovaps [rsp+0xE0], xmm15
00007cf1741ce985  sub rsp, 0x30
00007cf1741ce989  movaps [rsp], xmm13
00007cf1741ce98e  movaps [rsp+0x10], xmm12
00007cf1741ce994  movaps [rsp+0x20], xmm1
00007cf1741ce999  lea rdi, [rsp]
00007cf1741ce99d  mov esi, 0x00
00007cf1741ce9a2  mov rax, 0x611C8A33A530
00007cf1741ce9ac  call rax
00007cf1741ce9ae  movaps xmm13, [rsp]
00007cf1741ce9b3  add rsp, 0x30
00007cf1741ce9b7  vmovaps xmm0, [rsp]
00007cf1741ce9bc  vmovaps xmm1, [rsp+0x10]
00007cf1741ce9c2  vmovaps xmm2, [rsp+0x20]
00007cf1741ce9c8  vmovaps xmm3, [rsp+0x30]
00007cf1741ce9ce  vmovaps xmm4, [rsp+0x40]
00007cf1741ce9d4  vmovaps xmm5, [rsp+0x50]
00007cf1741ce9da  vmovaps xmm6, [rsp+0x60]
00007cf1741ce9e0  vmovaps xmm7, [rsp+0x70]
00007cf1741ce9e6  vmovaps xmm8, [rsp+0x80]
00007cf1741ce9ef  vmovaps xmm9, [rsp+0x90]
00007cf1741ce9f8  vmovaps xmm10, [rsp+0xA0]
00007cf1741cea01  vmovaps xmm11, [rsp+0xB0]
00007cf1741cea0a  vmovaps xmm12, [rsp+0xC0]
00007cf1741cea13  vmovaps xmm14, [rsp+0xD0]
00007cf1741cea1c  vmovaps xmm15, [rsp+0xE0]
00007cf1741cea25  add rsp, 0xF0
00007cf1741cea2c  pop r11
00007cf1741cea2e  pop r10
00007cf1741cea30  pop r9
00007cf1741cea32  pop r8
00007cf1741cea34  pop rsi
00007cf1741cea35  pop rdi
00007cf1741cea36  pop rdx
00007cf1741cea37  pop rcx
00007cf1741cea38  pop rax
00007cf1741cea39  add rsp, 0x08
00007cf1741cea3d  jmp 0x00007CF1741CE81B
00007cf1741cea42  call 0x00007CF17400C380
00007cf1741cea47  jmp 0x00007CF1741CE82E
00007cf1741cea4c  sub rsp, 0x08
00007cf1741cea50  push rax
00007cf1741cea51  push rcx
00007cf1741cea52  push rdx
00007cf1741cea53  push rdi
00007cf1741cea54  push rsi
00007cf1741cea55  push r8
00007cf1741cea57  push r9
00007cf1741cea59  push r10
00007cf1741cea5b  push r11
00007cf1741cea5d  sub rsp, 0xF0
00007cf1741cea64  vmovaps [rsp], xmm0
00007cf1741cea69  vmovaps [rsp+0x10], xmm2
00007cf1741cea6f  vmovaps [rsp+0x20], xmm3
00007cf1741cea75  vmovaps [rsp+0x30], xmm4
00007cf1741cea7b  vmovaps [rsp+0x40], xmm5
00007cf1741cea81  vmovaps [rsp+0x50], xmm6
00007cf1741cea87  vmovaps [rsp+0x60], xmm7
00007cf1741cea8d  vmovaps [rsp+0x70], xmm8
00007cf1741cea93  vmovaps [rsp+0x80], xmm9
00007cf1741cea9c  vmovaps [rsp+0x90], xmm10
00007cf1741ceaa5  vmovaps [rsp+0xA0], xmm11
00007cf1741ceaae  vmovaps [rsp+0xB0], xmm12
00007cf1741ceab7  vmovaps [rsp+0xC0], xmm13
00007cf1741ceac0  vmovaps [rsp+0xD0], xmm14
00007cf1741ceac9  vmovaps [rsp+0xE0], xmm15
00007cf1741cead2  sub rsp, 0x30
00007cf1741cead6  movaps [rsp], xmm1
00007cf1741ceada  movaps [rsp+0x10], xmm14
00007cf1741ceae0  movaps [rsp+0x20], xmm15
00007cf1741ceae6  lea rdi, [rsp]
00007cf1741ceaea  mov esi, 0x00
00007cf1741ceaef  mov rax, 0x611C8A33A530
00007cf1741ceaf9  call rax
00007cf1741ceafb  movaps xmm1, [rsp]
00007cf1741ceaff  add rsp, 0x30
00007cf1741ceb03  vmovaps xmm0, [rsp]
00007cf1741ceb08  vmovaps xmm2, [rsp+0x10]
00007cf1741ceb0e  vmovaps xmm3, [rsp+0x20]
00007cf1741ceb14  vmovaps xmm4, [rsp+0x30]
00007cf1741ceb1a  vmovaps xmm5, [rsp+0x40]
00007cf1741ceb20  vmovaps xmm6, [rsp+0x50]
00007cf1741ceb26  vmovaps xmm7, [rsp+0x60]
00007cf1741ceb2c  vmovaps xmm8, [rsp+0x70]
00007cf1741ceb32  vmovaps xmm9, [rsp+0x80]
00007cf1741ceb3b  vmovaps xmm10, [rsp+0x90]
00007cf1741ceb44  vmovaps xmm11, [rsp+0xA0]
00007cf1741ceb4d  vmovaps xmm12, [rsp+0xB0]
00007cf1741ceb56  vmovaps xmm13, [rsp+0xC0]
00007cf1741ceb5f  vmovaps xmm14, [rsp+0xD0]
00007cf1741ceb68  vmovaps xmm15, [rsp+0xE0]
00007cf1741ceb71  add rsp, 0xF0
00007cf1741ceb78  pop r11
00007cf1741ceb7a  pop r10
00007cf1741ceb7c  pop r9
00007cf1741ceb7e  pop r8
00007cf1741ceb80  pop rsi
00007cf1741ceb81  pop rdi
00007cf1741ceb82  pop rdx
00007cf1741ceb83  pop rcx
00007cf1741ceb84  pop rax
00007cf1741ceb85  add rsp, 0x08
00007cf1741ceb89  jmp 0x00007CF1741CE848
00007cf1741ceb8e  call 0x00007CF173FFF540
00007cf1741ceb93  jmp 0x00007CF1741CE85B
00007cf1741ceb98  int3
00007cf1741ceb99  nop [rax], eax
00007cf1741ceba0  movaps xmm1, [r15+0x180]
00007cf1741ceba8  vpmovqd xmm15, xmm1
00007cf1741cebae  pxor xmm14, xmm14
00007cf1741cebb3  punpcklqdq xmm15, xmm14
00007cf1741cebb8  movaps [r15+0x210], xmm15
00007cf1741cebc0  movq xmm15, qword ptr [r15+0x120]
00007cf1741cebc9  movq xmm14, qword ptr [r15+0x130]
00007cf1741cebd2  psubd xmm15, xmm14
00007cf1741cebd7  movq xmm15, xmm15
00007cf1741cebdc  movaps xmm13, [r15+0x170]
00007cf1741cebe4  paddq xmm1, xmm13
00007cf1741cebe9  movaps [r15+0x180], xmm1
00007cf1741cebf1  movq xmm1, qword ptr [r15+0x150]
00007cf1741cebfa  paddd xmm14, xmm1
00007cf1741cebff  movq xmm14, xmm14
00007cf1741cec04  movq xmm14, xmm14
00007cf1741cec09  movaps [r15+0x130], xmm14
00007cf1741cec11  pmovzxdq xmm15, xmm15
00007cf1741cec17  psllq xmm15, 0x00
00007cf1741cec1d  movq xmm1, qword ptr [r15+0x210]
00007cf1741cec26  movq xmm14, qword ptr [r15+0x110]
00007cf1741cec2f  paddd xmm1, xmm14
00007cf1741cec34  movq xmm1, xmm1
00007cf1741cec38  vcvtuqq2pd xmm15, xmm15
00007cf1741cec3e  pmovzxdq xmm1, xmm1
00007cf1741cec43  psllq xmm1, 0x00
00007cf1741cec48  vcvtuqq2pd xmm1, xmm1
00007cf1741cec4e  movaps xmm14, [r15+0x140]
00007cf1741cec56  movaps xmm13, xmm15
00007cf1741cec5a  mulpd xmm13, xmm14
00007cf1741cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007cf1741cec65  ptest xmm12, xmm12
00007cf1741cec6b  jnz 0x00007CF1741CED4E
00007cf1741cec71  movaps [r15+0x220], xmm13
00007cf1741cec79  mov rax, [r15+0x48]
00007cf1741cec7d  mov r14, [r15+0x50]
00007cf1741cec81  lea r12, [r14+rax*1]
00007cf1741cec85  movups [r13+r12*1], xmm13
00007cf1741cec8b  movaps xmm15, [r15+0x160]
00007cf1741cec93  movaps xmm14, xmm1
00007cf1741cec97  mulpd xmm14, xmm15
00007cf1741cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007cf1741ceca2  ptest xmm13, xmm13
00007cf1741ceca8  jnz 0x00007CF1741CEE9C
00007cf1741cecae  movaps [r15+0x210], xmm14
00007cf1741cecb6  mov r14, [r15+0x40]
00007cf1741cecba  lea r12, [r14+rax*1]
00007cf1741cecbe  movups [r13+r12*1], xmm14
00007cf1741cecc4  lea r14, [rax+0x10]
00007cf1741cecc8  mov [r15+0x48], r14
00007cf1741ceccc  xor eax, eax
00007cf1741cecce  mov r12d, 0x200
00007cf1741cecd4  cmp r14, r12
00007cf1741cecd7  cmc
00007cf1741cecd8  lahf
00007cf1741cecd9  seto al
00007cf1741cecdc  mov [r15+0x108], eax
00007cf1741cece3  mov eax, [r15+0x108]
00007cf1741cecea  sahf
00007cf1741ceceb  jnz 0x00007CF1741CED1D
00007cf1741ceced  cmp dword ptr [r15+0x318], 0x00
00007cf1741cecf5  jz 0x00007CF1741CEFF0
00007cf1741cecfb  nop [rax+rax*1], ax
00007cf1741ced04  nop [rax+rax*1], eax
00007cf1741ced0c  mov eax, 0x4101EC
00007cf1741ced11  mov [r15+0x100], rax
00007cf1741ced18  jmp 0x00007CF173FFE110
00007cf1741ced1d  cmp dword ptr [r15+0x318], 0x00
00007cf1741ced25  jz 0x00007CF1741CEBA0
00007cf1741ced2b  nop [rax+rax*1], ax
00007cf1741ced34  nop [rax+rax*1], eax
00007cf1741ced3c  mov eax, 0x4101AC
00007cf1741ced41  mov [r15+0x100], rax
00007cf1741ced48  jmp 0x00007CF173FFE110
00007cf1741ced4d  int3
00007cf1741ced4e  sub rsp, 0x08
00007cf1741ced52  push rax
00007cf1741ced53  push rcx
00007cf1741ced54  push rdx
00007cf1741ced55  push rdi
00007cf1741ced56  push rsi
00007cf1741ced57  push r8
00007cf1741ced59  push r9
00007cf1741ced5b  push r10
00007cf1741ced5d  push r11
00007cf1741ced5f  sub rsp, 0xF0
00007cf1741ced66  vmovaps [rsp], xmm0
00007cf1741ced6b  vmovaps [rsp+0x10], xmm1
00007cf1741ced71  vmovaps [rsp+0x20], xmm2
00007cf1741ced77  vmovaps [rsp+0x30], xmm3
00007cf1741ced7d  vmovaps [rsp+0x40], xmm4
00007cf1741ced83  vmovaps [rsp+0x50], xmm5
00007cf1741ced89  vmovaps [rsp+0x60], xmm6
00007cf1741ced8f  vmovaps [rsp+0x70], xmm7
00007cf1741ced95  vmovaps [rsp+0x80], xmm8
00007cf1741ced9e  vmovaps [rsp+0x90], xmm9
00007cf1741ceda7  vmovaps [rsp+0xA0], xmm10
00007cf1741cedb0  vmovaps [rsp+0xB0], xmm11
00007cf1741cedb9  vmovaps [rsp+0xC0], xmm12
00007cf1741cedc2  vmovaps [rsp+0xD0], xmm14
00007cf1741cedcb  vmovaps [rsp+0xE0], xmm15
00007cf1741cedd4  sub rsp, 0x30
00007cf1741cedd8  movaps [rsp], xmm13
00007cf1741ceddd  movaps [rsp+0x10], xmm15
00007cf1741cede3  movaps [rsp+0x20], xmm14
00007cf1741cede9  lea rdi, [rsp]
00007cf1741ceded  mov esi, 0x00
00007cf1741cedf2  mov rax, 0x611C8A33A530
00007cf1741cedfc  call rax
00007cf1741cedfe  movaps xmm13, [rsp]
00007cf1741cee03  add rsp, 0x30
00007cf1741cee07  vmovaps xmm0, [rsp]
00007cf1741cee0c  vmovaps xmm1, [rsp+0x10]
00007cf1741cee12  vmovaps xmm2, [rsp+0x20]
00007cf1741cee18  vmovaps xmm3, [rsp+0x30]
00007cf1741cee1e  vmovaps xmm4, [rsp+0x40]
00007cf1741cee24  vmovaps xmm5, [rsp+0x50]
00007cf1741cee2a  vmovaps xmm6, [rsp+0x60]
00007cf1741cee30  vmovaps xmm7, [rsp+0x70]
00007cf1741cee36  vmovaps xmm8, [rsp+0x80]
00007cf1741cee3f  vmovaps xmm9, [rsp+0x90]
00007cf1741cee48  vmovaps xmm10, [rsp+0xA0]
00007cf1741cee51  vmovaps xmm11, [rsp+0xB0]
00007cf1741cee5a  vmovaps xmm12, [rsp+0xC0]
00007cf1741cee63  vmovaps xmm14, [rsp+0xD0]
00007cf1741cee6c  vmovaps xmm15, [rsp+0xE0]
00007cf1741cee75  add rsp, 0xF0
00007cf1741cee7c  pop r11
00007cf1741cee7e  pop r10
00007cf1741cee80  pop r9
00007cf1741cee82  pop r8
00007cf1741cee84  pop rsi
00007cf1741cee85  pop rdi
00007cf1741cee86  pop rdx
00007cf1741cee87  pop rcx
00007cf1741cee88  pop rax
00007cf1741cee89  add rsp, 0x08
00007cf1741cee8d  jmp 0x00007CF1741CEC71
00007cf1741cee92  call 0x00007CF1740C2240
00007cf1741cee97  jmp 0x00007CF1741CEC8B
00007cf1741cee9c  sub rsp, 0x08
00007cf1741ceea0  push rax
00007cf1741ceea1  push rcx
00007cf1741ceea2  push rdx
00007cf1741ceea3  push rdi
00007cf1741ceea4  push rsi
00007cf1741ceea5  push r8
00007cf1741ceea7  push r9
00007cf1741ceea9  push r10
00007cf1741ceeab  push r11
00007cf1741ceead  sub rsp, 0xF0
00007cf1741ceeb4  vmovaps [rsp], xmm0
00007cf1741ceeb9  vmovaps [rsp+0x10], xmm1
00007cf1741ceebf  vmovaps [rsp+0x20], xmm2
00007cf1741ceec5  vmovaps [rsp+0x30], xmm3
00007cf1741ceecb  vmovaps [rsp+0x40], xmm4
00007cf1741ceed1  vmovaps [rsp+0x50], xmm5
00007cf1741ceed7  vmovaps [rsp+0x60], xmm6
00007cf1741ceedd  vmovaps [rsp+0x70], xmm7
00007cf1741ceee3  vmovaps [rsp+0x80], xmm8
00007cf1741ceeec  vmovaps [rsp+0x90], xmm9
00007cf1741ceef5  vmovaps [rsp+0xA0], xmm10
00007cf1741ceefe  vmovaps [rsp+0xB0], xmm11
00007cf1741cef07  vmovaps [rsp+0xC0], xmm12
00007cf1741cef10  vmovaps [rsp+0xD0], xmm13
00007cf1741cef19  vmovaps [rsp+0xE0], xmm15
00007cf1741cef22  sub rsp, 0x30
00007cf1741cef26  movaps [rsp], xmm14
00007cf1741cef2b  movaps [rsp+0x10], xmm1
00007cf1741cef30  movaps [rsp+0x20], xmm15
00007cf1741cef36  lea rdi, [rsp]
00007cf1741cef3a  mov esi, 0x00
00007cf1741cef3f  mov rax, 0x611C8A33A530
00007cf1741cef49  call rax
00007cf1741cef4b  movaps xmm14, [rsp]
00007cf1741cef50  add rsp, 0x30
00007cf1741cef54  vmovaps xmm0, [rsp]
00007cf1741cef59  vmovaps xmm1, [rsp+0x10]
00007cf1741cef5f  vmovaps xmm2, [rsp+0x20]
00007cf1741cef65  vmovaps xmm3, [rsp+0x30]
00007cf1741cef6b  vmovaps xmm4, [rsp+0x40]
00007cf1741cef71  vmovaps xmm5, [rsp+0x50]
00007cf1741cef77  vmovaps xmm6, [rsp+0x60]
00007cf1741cef7d  vmovaps xmm7, [rsp+0x70]
00007cf1741cef83  vmovaps xmm8, [rsp+0x80]
00007cf1741cef8c  vmovaps xmm9, [rsp+0x90]
00007cf1741cef95  vmovaps xmm10, [rsp+0xA0]
00007cf1741cef9e  vmovaps xmm11, [rsp+0xB0]
00007cf1741cefa7  vmovaps xmm12, [rsp+0xC0]
00007cf1741cefb0  vmovaps xmm13, [rsp+0xD0]
00007cf1741cefb9  vmovaps xmm15, [rsp+0xE0]
00007cf1741cefc2  add rsp, 0xF0
00007cf1741cefc9  pop r11
00007cf1741cefcb  pop r10
00007cf1741cefcd  pop r9
00007cf1741cefcf  pop r8
00007cf1741cefd1  pop rsi
00007cf1741cefd2  pop rdi
00007cf1741cefd3  pop rdx
00007cf1741cefd4  pop rcx
00007cf1741cefd5  pop rax
00007cf1741cefd6  add rsp, 0x08
00007cf1741cefda  jmp 0x00007CF1741CECAE
00007cf1741cefdf  call 0x00007CF1740C34C0
00007cf1741cefe4  jmp 0x00007CF1741CECC4
00007cf1741cefe9  int3
00007cf1741cefea  nop [rax+rax*1], ax
00007cf1741ceff0  mov rax, [r15+0xF8]
00007cf1741ceff7  lea r14, [rax-0x150]
00007cf1741ceffe  mov [r15+0xF8], r14
00007cf1741cf005  mov rax, [r15+0x50]
00007cf1741cf009  lea r12, [rax+0x80]
00007cf1741cf010  movups xmm1, [r13+r12*1]
00007cf1741cf016  lea r12, [rax+0x90]
00007cf1741cf01d  movups xmm15, [r13+r12*1]
00007cf1741cf023  mov qword ptr [r15+0x48], 0x00
00007cf1741cf02b  lea r12, [rax+0x40]
00007cf1741cf02f  movups xmm14, [r13+r12*1]
00007cf1741cf035  lea r12, [rax+0x50]
00007cf1741cf039  movups xmm13, [r13+r12*1]
00007cf1741cf03f  lea r12, [r14+0x120]
00007cf1741cf046  movq xmm12, qword ptr [r15+0x1C0]
00007cf1741cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007cf1741cf058  movq r11, xmm12
00007cf1741cf05d  movq r10, xmm11
00007cf1741cf062  mov [r13+r12*1], r11
00007cf1741cf067  lea r12, [r14+0x128]
00007cf1741cf06e  mov [r13+r12*1], r10
00007cf1741cf073  vxorps xmm12, xmm12, xmm12
00007cf1741cf078  vpbroadcastq xmm12, xmm12
00007cf1741cf07d  lea r12, [r14+0x100]
00007cf1741cf084  movq xmm11, qword ptr [r15+0x200]
00007cf1741cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007cf1741cf096  movq r11, xmm11
00007cf1741cf09b  movq r10, xmm10
00007cf1741cf0a0  mov [r13+r12*1], r11
00007cf1741cf0a5  lea r12, [r14+0x108]
00007cf1741cf0ac  mov [r13+r12*1], r10
00007cf1741cf0b1  lea r12, [r14+0xE0]
00007cf1741cf0b8  movups [r13+r12*1], xmm15
00007cf1741cf0be  lea r12, [r14+0xF0]
00007cf1741cf0c5  movups [r13+r12*1], xmm1
00007cf1741cf0cb  lea r12, [rax+0xC0]
00007cf1741cf0d2  movups xmm1, [r13+r12*1]
00007cf1741cf0d8  lea r12, [rax+0xD0]
00007cf1741cf0df  movups xmm15, [r13+r12*1]
00007cf1741cf0e5  lea r12, [r14+0x110]
00007cf1741cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007cf1741cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007cf1741cf0fe  movq r11, xmm11
00007cf1741cf103  movq r10, xmm10
00007cf1741cf108  mov [r13+r12*1], r11
00007cf1741cf10d  lea r12, [r14+0x118]
00007cf1741cf114  mov [r13+r12*1], r10
00007cf1741cf119  movups xmm11, [r13+rax*1]
00007cf1741cf11f  lea r12, [rax+0x10]
00007cf1741cf123  movups xmm10, [r13+r12*1]
00007cf1741cf129  lea r12, [r14+0x130]
00007cf1741cf130  movq xmm9, qword ptr [r15+0x1A0]
00007cf1741cf139  movq xmm8, qword ptr [r15+0x190]
00007cf1741cf142  movq r11, xmm9
00007cf1741cf147  movq r10, xmm8
00007cf1741cf14c  mov [r13+r12*1], r11
00007cf1741cf151  lea r12, [r14+0x138]
00007cf1741cf158  mov [r13+r12*1], r10
00007cf1741cf15d  lea r12, [rax+0x140]
00007cf1741cf164  movups xmm9, [r13+r12*1]
00007cf1741cf16a  lea r12, [rax+0x150]
00007cf1741cf171  movups xmm8, [r13+r12*1]
00007cf1741cf177  lea r12, [r14+0xC0]
00007cf1741cf17e  movups [r13+r12*1], xmm15
00007cf1741cf184  lea r12, [r14+0xD0]
00007cf1741cf18b  movups [r13+r12*1], xmm1
00007cf1741cf191  lea r12, [rax+0x100]
00007cf1741cf198  movups xmm1, [r13+r12*1]
00007cf1741cf19e  lea r12, [rax+0x110]
00007cf1741cf1a5  movups xmm15, [r13+r12*1]
00007cf1741cf1ab  lea r12, [r14+0x140]
00007cf1741cf1b2  mov r11, [r15+0xE8]
00007cf1741cf1b9  mov [r13+r12*1], r11
00007cf1741cf1be  lea r12, [rax+0x180]
00007cf1741cf1c5  movups xmm7, [r13+r12*1]
00007cf1741cf1cb  lea r12, [rax+0x190]
00007cf1741cf1d2  movups xmm6, [r13+r12*1]
00007cf1741cf1d8  lea r12, [rax+0x1C0]
00007cf1741cf1df  movups xmm5, [r13+r12*1]
00007cf1741cf1e5  lea r12, [rax+0x1D0]
00007cf1741cf1ec  movups xmm4, [r13+r12*1]
00007cf1741cf1f2  lea r12, [r14+0x20]
00007cf1741cf1f6  movups [r13+r12*1], xmm1
00007cf1741cf1fc  lea r12, [r14+0x30]
00007cf1741cf200  movups [r13+r12*1], xmm13
00007cf1741cf206  lea r12, [rax+0x60]
00007cf1741cf20a  movups xmm1, [r13+r12*1]
00007cf1741cf210  lea r12, [rax+0x70]
00007cf1741cf214  movups xmm13, [r13+r12*1]
00007cf1741cf21a  lea r12, [rax+0x20]
00007cf1741cf21e  movups xmm3, [r13+r12*1]
00007cf1741cf224  lea r12, [rax+0x30]
00007cf1741cf228  movups xmm2, [r13+r12*1]
00007cf1741cf22e  movaps [r15+0x1F0], xmm2
00007cf1741cf236  lea r12, [r14+0x60]
00007cf1741cf23a  movups [r13+r12*1], xmm11
00007cf1741cf240  lea r12, [r14+0x70]
00007cf1741cf244  movups [r13+r12*1], xmm5
00007cf1741cf24a  lea r12, [rax+0xE0]
00007cf1741cf251  movups xmm11, [r13+r12*1]
00007cf1741cf257  lea r12, [rax+0xF0]
00007cf1741cf25e  movups xmm5, [r13+r12*1]
00007cf1741cf264  lea r12, [r14+0xA0]
00007cf1741cf26b  movups [r13+r12*1], xmm13
00007cf1741cf271  lea r12, [r14+0xB0]
00007cf1741cf278  movups [r13+r12*1], xmm1
00007cf1741cf27e  lea r12, [rax+0xA0]
00007cf1741cf285  movups xmm1, [r13+r12*1]
00007cf1741cf28b  lea r12, [rax+0xB0]
00007cf1741cf292  movups xmm13, [r13+r12*1]
00007cf1741cf298  lea r12, [rax+0x120]
00007cf1741cf29f  vmovaps [rsp+0x10], xmm1
00007cf1741cf2a5  movups xmm1, [r13+r12*1]
00007cf1741cf2ab  lea r12, [rax+0x130]
00007cf1741cf2b2  vmovaps [rsp+0x20], xmm1
00007cf1741cf2b8  movups xmm1, [r13+r12*1]
00007cf1741cf2be  lea r12, [rax+0x160]
00007cf1741cf2c5  vmovaps [rsp+0x30], xmm1
00007cf1741cf2cb  movups xmm1, [r13+r12*1]
00007cf1741cf2d1  lea r12, [rax+0x170]
00007cf1741cf2d8  vmovaps [rsp+0x40], xmm1
00007cf1741cf2de  movups xmm1, [r13+r12*1]
00007cf1741cf2e4  movaps [r15+0x2B0], xmm1
00007cf1741cf2ec  lea r12, [r14+0x80]
00007cf1741cf2f3  movups [r13+r12*1], xmm13
00007cf1741cf2f9  lea r12, [r14+0x90]
00007cf1741cf300  vmovaps xmm13, [rsp+0x10]
00007cf1741cf306  movups [r13+r12*1], xmm13
00007cf1741cf30c  lea r12, [rax+0x1A0]
00007cf1741cf313  movups xmm13, [r13+r12*1]
00007cf1741cf319  lea r12, [rax+0x1B0]
00007cf1741cf320  vmovaps [rsp+0x10], xmm1
00007cf1741cf326  movups xmm1, [r13+r12*1]
00007cf1741cf32c  movaps [r15+0x290], xmm13
00007cf1741cf334  movaps [r15+0x1E0], xmm1
00007cf1741cf33c  lea r12, [rax+0x1E0]
00007cf1741cf343  vmovaps [rsp+0x50], xmm1
00007cf1741cf349  movups xmm1, [r13+r12*1]
00007cf1741cf34f  lea r12, [rax+0x1F0]
00007cf1741cf356  vmovaps [rsp+0x60], xmm1
00007cf1741cf35c  movups xmm1, [r13+r12*1]
00007cf1741cf362  mov qword ptr [r15+0x50], 0x430920
00007cf1741cf36a  lea rax, [r14+0x40]
00007cf1741cf36e  vmovaps [rsp+0x70], xmm1
00007cf1741cf374  vmovaps xmm1, [rsp+0x40]
00007cf1741cf37a  movups [r13+rax*1], xmm1
00007cf1741cf380  lea rax, [r14+0x50]
00007cf1741cf384  movups [r13+rax*1], xmm10
00007cf1741cf38a  vmovaps xmm1, [rsp+0x70]
00007cf1741cf390  movups [r13+r14*1], xmm1
00007cf1741cf396  lea rax, [r14+0x10]
00007cf1741cf39a  vmovaps xmm1, [rsp+0x60]
00007cf1741cf3a0  movups [r13+rax*1], xmm1
00007cf1741cf3a6  mov rax, [r15+0x40]
00007cf1741cf3aa  vmovaps [rsp+0x40], xmm3
00007cf1741cf3b0  vmovaps xmm1, [rsp+0x40]
00007cf1741cf3b6  por xmm3, xmm1
00007cf1741cf3ba  vmovaps [rsp+0x40], xmm6
00007cf1741cf3c0  vmovaps xmm10, [rsp+0x40]
00007cf1741cf3c6  por xmm6, xmm10
00007cf1741cf3cb  lea r12, [rax+0x30]
00007cf1741cf3cf  mov r11, [r13+r12*1]
00007cf1741cf3d4  lea r12, [rax+0x38]
00007cf1741cf3d8  mov r10, [r13+r12*1]
00007cf1741cf3dd  movq xmm10, r11
00007cf1741cf3e2  vmovaps [rsp+0x40], xmm1
00007cf1741cf3e8  movq xmm1, r10
00007cf1741cf3ed  movq xmm10, xmm10
00007cf1741cf3f2  vmovaps [rsp+0x60], xmm10
00007cf1741cf3f8  movq xmm10, xmm10
00007cf1741cf3fd  movaps [r15+0x130], xmm10
00007cf1741cf405  movq xmm1, xmm1
00007cf1741cf409  vmovaps [rsp+0x70], xmm1
00007cf1741cf40f  movq xmm1, xmm1
00007cf1741cf413  movaps [r15+0x280], xmm1
00007cf1741cf41b  vmovaps [rsp+0x80], xmm9
00007cf1741cf424  vmovaps xmm1, [rsp+0x80]
00007cf1741cf42d  por xmm9, xmm1
00007cf1741cf432  lea r12, [rax+0x20]
00007cf1741cf436  mov r11, [r13+r12*1]
00007cf1741cf43b  lea r12, [rax+0x28]
00007cf1741cf43f  mov r10, [r13+r12*1]
00007cf1741cf444  movq xmm1, r11
00007cf1741cf449  movq xmm10, r10
00007cf1741cf44e  movq xmm1, xmm1
00007cf1741cf452  vmovaps [rsp+0x80], xmm1
00007cf1741cf45b  movq xmm1, xmm1
00007cf1741cf45f  movaps [r15+0x150], xmm1
00007cf1741cf467  movq xmm10, xmm10
00007cf1741cf46c  vmovaps [rsp+0x90], xmm10
00007cf1741cf475  movq xmm10, xmm10
00007cf1741cf47a  movaps [r15+0x140], xmm10
00007cf1741cf482  lea r12, [rax+0x10]
00007cf1741cf486  mov r11, [r13+r12*1]
00007cf1741cf48b  lea r12, [rax+0x18]
00007cf1741cf48f  mov r10, [r13+r12*1]
00007cf1741cf494  movq xmm1, r11
00007cf1741cf499  movq xmm10, r10
00007cf1741cf49e  movq xmm1, xmm1
00007cf1741cf4a2  vmovaps [rsp+0xA0], xmm1
00007cf1741cf4ab  movq xmm1, xmm1
00007cf1741cf4af  movaps [r15+0x170], xmm1
00007cf1741cf4b7  movq xmm10, xmm10
00007cf1741cf4bc  vmovaps [rsp+0xB0], xmm10
00007cf1741cf4c5  movq xmm10, xmm10
00007cf1741cf4ca  movaps [r15+0x160], xmm10
00007cf1741cf4d2  mov r12, [r13+rax*1]
00007cf1741cf4d7  vmovq xmm1, r12
00007cf1741cf4dc  vpbroadcastq xmm1, xmm1
00007cf1741cf4e1  lea r12, [rax+0x08]
00007cf1741cf4e5  mov rax, [r13+r12*1]
00007cf1741cf4ea  movq xmm10, rax
00007cf1741cf4ef  movaps [r15+0x230], xmm10
00007cf1741cf4f7  lea rax, [r14+0x50]
00007cf1741cf4fb  movups xmm10, [r13+rax*1]
00007cf1741cf501  lea rax, [r14+0x60]
00007cf1741cf505  vmovaps [rsp+0xC0], xmm1
00007cf1741cf50e  movups xmm1, [r13+rax*1]
00007cf1741cf514  lea rax, [r14+0x30]
00007cf1741cf518  vmovaps [rsp+0xD0], xmm1
00007cf1741cf521  movups xmm1, [r13+rax*1]
00007cf1741cf527  mov qword ptr [r15+0x60], 0x430920
00007cf1741cf52f  mov qword ptr [r15+0x58], 0x40
00007cf1741cf537  vmovaps [rsp+0xE0], xmm1
00007cf1741cf540  vmovaps [rsp+0xF0], xmm15
00007cf1741cf549  vmovaps xmm15, [rsp+0xC0]
00007cf1741cf552  vmovaps [rsp+0xC0], xmm14
00007cf1741cf55b  vmovaps xmm14, [rsp+0x40]
00007cf1741cf561  vmovaps [rsp+0x40], xmm13
00007cf1741cf567  movaps xmm1, xmm15
00007cf1741cf56b  mulpd xmm1, xmm14
00007cf1741cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007cf1741cf575  ptest xmm13, xmm13
00007cf1741cf57b  jnz 0x00007CF1741D0682
00007cf1741cf581  movq xmm14, qword ptr [r15+0x230]
00007cf1741cf58a  vmovaps [rsp+0x100], xmm14
00007cf1741cf593  vpermilpd xmm14, xmm14, 0x00
00007cf1741cf599  vmovaps [rsp+0x110], xmm1
00007cf1741cf5a2  vmovaps xmm1, [rsp+0xE0]
00007cf1741cf5ab  vmovaps [rsp+0xE0], xmm15
00007cf1741cf5b4  movaps xmm13, xmm1
00007cf1741cf5b8  mulpd xmm13, xmm14
00007cf1741cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007cf1741cf5c3  ptest xmm15, xmm15
00007cf1741cf5c9  jnz 0x00007CF1741D07C4
00007cf1741cf5cf  vxorps xmm1, xmm1, xmm1
00007cf1741cf5d3  vpbroadcastq xmm1, xmm1
00007cf1741cf5d8  vmovaps xmm14, [rsp+0xE0]
00007cf1741cf5e1  vmovaps [rsp+0xE0], xmm1
00007cf1741cf5ea  vmovaps xmm1, [rsp+0xD0]
00007cf1741cf5f3  vmovaps [rsp+0xD0], xmm13
00007cf1741cf5fc  movaps xmm15, xmm14
00007cf1741cf600  mulpd xmm15, xmm1
00007cf1741cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007cf1741cf60b  ptest xmm13, xmm13
00007cf1741cf611  jnz 0x00007CF1741D0907
00007cf1741cf617  movaps xmm1, xmm14
00007cf1741cf61b  mulpd xmm1, xmm10
00007cf1741cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007cf1741cf625  ptest xmm13, xmm13
00007cf1741cf62b  jnz 0x00007CF1741D0A4A
00007cf1741cf631  movaps xmm13, xmm14
00007cf1741cf635  mulpd xmm13, xmm2
00007cf1741cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007cf1741cf640  ptest xmm10, xmm10
00007cf1741cf646  jnz 0x00007CF1741D0B8C
00007cf1741cf64c  vmovaps [rsp+0x120], xmm7
00007cf1741cf655  vmovaps xmm14, [rsp+0x120]
00007cf1741cf65e  por xmm7, xmm14
00007cf1741cf663  vmovaps xmm14, [rsp+0xC0]
00007cf1741cf66c  vmovaps xmm10, [rsp+0xC0]
00007cf1741cf675  por xmm14, xmm10
00007cf1741cf67a  vmovaps xmm2, [rsp+0x100]
00007cf1741cf683  vpermilpd xmm2, xmm2, 0x00
00007cf1741cf689  vmovaps [rsp+0xC0], xmm1
00007cf1741cf692  vmovaps [rsp+0x120], xmm15
00007cf1741cf69b  movaps xmm1, xmm10
00007cf1741cf69f  mulpd xmm1, xmm2
00007cf1741cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007cf1741cf6a8  ptest xmm15, xmm15
00007cf1741cf6ae  jnz 0x00007CF1741D0CCF
00007cf1741cf6b4  xor eax, eax
00007cf1741cf6b6  mov r12d, 0x40
00007cf1741cf6bc  mov r11d, 0x200
00007cf1741cf6c2  cmp r12, r11
00007cf1741cf6c5  cmc
00007cf1741cf6c6  lahf
00007cf1741cf6c7  seto al
00007cf1741cf6ca  mov [r15+0x108], eax
00007cf1741cf6d1  vmovaps xmm10, [rsp+0x110]
00007cf1741cf6da  vmovaps xmm2, [rsp+0xE0]
00007cf1741cf6e3  vmovaps [rsp+0xE0], xmm1
00007cf1741cf6ec  movaps xmm15, xmm10
00007cf1741cf6f0  addpd xmm15, xmm2
00007cf1741cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007cf1741cf6fb  ptest xmm1, xmm1
00007cf1741cf700  jnz 0x00007CF1741D0E10
00007cf1741cf706  vmovaps xmm10, [rsp+0x120]
00007cf1741cf70f  vmovaps [rsp+0x110], xmm15
00007cf1741cf718  movaps xmm1, xmm10
00007cf1741cf71c  addpd xmm1, xmm12
00007cf1741cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007cf1741cf726  ptest xmm15, xmm15
00007cf1741cf72c  jnz 0x00007CF1741D0F53
00007cf1741cf732  vmovaps xmm10, [rsp+0xC0]
00007cf1741cf73b  vmovaps [rsp+0xC0], xmm1
00007cf1741cf744  movaps xmm15, xmm10
00007cf1741cf748  addpd xmm15, xmm12
00007cf1741cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007cf1741cf753  ptest xmm1, xmm1
00007cf1741cf758  jnz 0x00007CF1741D1095
00007cf1741cf75e  vmovaps xmm1, [rsp+0x30]
00007cf1741cf764  vmovaps xmm12, [rsp+0x30]
00007cf1741cf76a  por xmm1, xmm12
00007cf1741cf76f  vmovaps xmm12, [rsp+0x20]
00007cf1741cf775  vmovaps xmm10, [rsp+0x20]
00007cf1741cf77b  por xmm12, xmm10
00007cf1741cf780  vmovaps [rsp+0x20], xmm5
00007cf1741cf786  vmovaps xmm10, [rsp+0x20]
00007cf1741cf78c  por xmm5, xmm10
00007cf1741cf791  vmovaps [rsp+0x20], xmm11
00007cf1741cf797  vmovaps xmm10, [rsp+0x20]
00007cf1741cf79d  por xmm11, xmm10
00007cf1741cf7a2  vmovaps [rsp+0x20], xmm4
00007cf1741cf7a8  vmovaps xmm10, [rsp+0x20]
00007cf1741cf7ae  por xmm4, xmm10
00007cf1741cf7b3  vmovaps [rsp+0x20], xmm8
00007cf1741cf7b9  vmovaps xmm10, [rsp+0x20]
00007cf1741cf7bf  por xmm8, xmm10
00007cf1741cf7c4  vmovaps xmm10, [rsp+0xF0]
00007cf1741cf7cd  vmovaps [rsp+0x20], xmm1
00007cf1741cf7d3  vmovaps xmm1, [rsp+0xF0]
00007cf1741cf7dc  por xmm10, xmm1
00007cf1741cf7e1  lea rax, [r14+0xA0]
00007cf1741cf7e8  movups xmm1, [r13+rax*1]
00007cf1741cf7ee  lea rax, [r14+0xB0]
00007cf1741cf7f5  vmovaps [rsp+0x30], xmm1
00007cf1741cf7fb  movups xmm1, [r13+rax*1]
00007cf1741cf801  vmovaps [rsp+0xF0], xmm1
00007cf1741cf80a  vmovaps [rsp+0x120], xmm15
00007cf1741cf813  movaps xmm1, xmm13
00007cf1741cf817  addpd xmm1, xmm2
00007cf1741cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007cf1741cf820  ptest xmm15, xmm15
00007cf1741cf826  jnz 0x00007CF1741D11ED
00007cf1741cf82c  lea rax, [r14+0xF0]
00007cf1741cf833  movups xmm15, [r13+rax*1]
00007cf1741cf839  vmovaps xmm2, [rsp+0xC0]
00007cf1741cf842  vmovaps [rsp+0xC0], xmm1
00007cf1741cf84b  vmovaps xmm1, [rsp+0xE0]
00007cf1741cf854  vmovaps [rsp+0xE0], xmm15
00007cf1741cf85d  movaps xmm13, xmm2
00007cf1741cf861  addpd xmm13, xmm1
00007cf1741cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007cf1741cf86c  ptest xmm15, xmm15
00007cf1741cf872  jnz 0x00007CF1741D1338
00007cf1741cf878  vmovaps xmm15, [rsp+0x120]
00007cf1741cf881  vmovaps xmm2, [rsp+0xD0]
00007cf1741cf88a  vmovaps [rsp+0xD0], xmm14
00007cf1741cf893  movaps xmm1, xmm15
00007cf1741cf897  addpd xmm1, xmm2
00007cf1741cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007cf1741cf8a0  ptest xmm14, xmm14
00007cf1741cf8a6  jnz 0x00007CF1741D147A
00007cf1741cf8ac  vmovaps xmm15, [rsp+0x100]
00007cf1741cf8b5  vpermilpd xmm15, xmm15, 0x00
00007cf1741cf8bb  vmovaps xmm2, [rsp+0xF0]
00007cf1741cf8c4  vmovaps [rsp+0xF0], xmm1
00007cf1741cf8cd  movaps xmm14, xmm2
00007cf1741cf8d1  mulpd xmm14, xmm15
00007cf1741cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007cf1741cf8dc  ptest xmm1, xmm1
00007cf1741cf8e1  jnz 0x00007CF1741D15BB
00007cf1741cf8e7  vmovaps xmm1, [rsp+0xA0]
00007cf1741cf8f0  vpermilpd xmm1, xmm1, 0x00
00007cf1741cf8f6  vmovaps xmm2, [rsp+0xE0]
00007cf1741cf8ff  vmovaps [rsp+0xE0], xmm14
00007cf1741cf908  movaps xmm15, xmm2
00007cf1741cf90c  mulpd xmm15, xmm1
00007cf1741cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007cf1741cf917  ptest xmm14, xmm14
00007cf1741cf91d  jnz 0x00007CF1741D16FE
00007cf1741cf923  lea rax, [r14+0xE0]
00007cf1741cf92a  movups xmm1, [r13+rax*1]
00007cf1741cf930  vmovaps xmm14, [rsp+0x100]
00007cf1741cf939  vpermilpd xmm14, xmm14, 0x00
00007cf1741cf93f  vmovaps [rsp+0x100], xmm1
00007cf1741cf948  vmovaps xmm1, [rsp+0x30]
00007cf1741cf94e  vmovaps [rsp+0x30], xmm15
00007cf1741cf954  movaps xmm2, xmm1
00007cf1741cf957  mulpd xmm2, xmm14
00007cf1741cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007cf1741cf961  ptest xmm15, xmm15
00007cf1741cf967  jnz 0x00007CF1741D184A
00007cf1741cf96d  vmovaps [rsp+0x120], xmm10
00007cf1741cf976  vmovaps xmm1, [rsp+0x120]
00007cf1741cf97f  por xmm10, xmm1
00007cf1741cf984  movaps [r15+0x300], xmm10
00007cf1741cf98c  vmovaps [rsp+0x120], xmm8
00007cf1741cf995  vmovaps xmm1, [rsp+0x120]
00007cf1741cf99e  por xmm8, xmm1
00007cf1741cf9a3  movaps [r15+0x190], xmm8
00007cf1741cf9ab  vmovaps xmm1, [rsp+0xA0]
00007cf1741cf9b4  vpermilpd xmm1, xmm1, 0x00
00007cf1741cf9ba  vmovaps xmm14, [rsp+0x100]
00007cf1741cf9c3  vmovaps [rsp+0x100], xmm13
00007cf1741cf9cc  movaps xmm15, xmm14
00007cf1741cf9d0  mulpd xmm15, xmm1
00007cf1741cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007cf1741cf9db  ptest xmm13, xmm13
00007cf1741cf9e1  jnz 0x00007CF1741D198B
00007cf1741cf9e7  lea rax, [r14+0x90]
00007cf1741cf9ee  movups xmm1, [r13+rax*1]
00007cf1741cf9f4  vmovaps [rsp+0x120], xmm4
00007cf1741cf9fd  vmovaps xmm14, [rsp+0x120]
00007cf1741cfa06  por xmm4, xmm14
00007cf1741cfa0b  movaps [r15+0x1C0], xmm4
00007cf1741cfa13  vmovaps [rsp+0x120], xmm11
00007cf1741cfa1c  vmovaps xmm14, [rsp+0x120]
00007cf1741cfa25  por xmm11, xmm14
00007cf1741cfa2a  movaps [r15+0x200], xmm11
00007cf1741cfa32  vmovaps [rsp+0x120], xmm5
00007cf1741cfa3b  vmovaps xmm14, [rsp+0x120]
00007cf1741cfa44  por xmm5, xmm14
00007cf1741cfa49  movaps [r15+0x2D0], xmm5
00007cf1741cfa51  vmovaps [rsp+0x120], xmm12
00007cf1741cfa5a  vmovaps xmm14, [rsp+0x120]
00007cf1741cfa63  por xmm12, xmm14
00007cf1741cfa68  movaps [r15+0x2E0], xmm12
00007cf1741cfa70  vmovaps xmm13, [rsp+0x110]
00007cf1741cfa79  vmovaps [rsp+0x110], xmm1
00007cf1741cfa82  vmovaps xmm1, [rsp+0xE0]
00007cf1741cfa8b  vmovaps [rsp+0xE0], xmm15
00007cf1741cfa94  movaps xmm14, xmm13
00007cf1741cfa98  addpd xmm14, xmm1
00007cf1741cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007cf1741cfaa3  ptest xmm15, xmm15
00007cf1741cfaa9  jnz 0x00007CF1741D1AD8
00007cf1741cfaaf  vmovaps xmm1, [rsp+0xA0]
00007cf1741cfab8  vpermilpd xmm1, xmm1, 0x00
00007cf1741cfabe  vmovaps xmm13, [rsp+0x110]
00007cf1741cfac7  vmovaps [rsp+0x110], xmm14
00007cf1741cfad0  movaps xmm15, xmm13
00007cf1741cfad4  mulpd xmm15, xmm1
00007cf1741cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007cf1741cfadf  ptest xmm14, xmm14
00007cf1741cfae5  jnz 0x00007CF1741D1C1B
00007cf1741cfaeb  lea rax, [r14+0x80]
00007cf1741cfaf2  movups xmm1, [r13+rax*1]
00007cf1741cfaf8  vmovaps xmm13, [rsp+0xC0]
00007cf1741cfb01  vmovaps [rsp+0xC0], xmm1
00007cf1741cfb0a  movaps xmm14, xmm13
00007cf1741cfb0e  addpd xmm14, xmm2
00007cf1741cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007cf1741cfb19  ptest xmm1, xmm1
00007cf1741cfb1e  jnz 0x00007CF1741D1D68
00007cf1741cfb24  vmovaps xmm13, [rsp+0x100]
00007cf1741cfb2d  vmovaps xmm2, [rsp+0x30]
00007cf1741cfb33  vmovaps [rsp+0x30], xmm15
00007cf1741cfb39  movaps xmm1, xmm13
00007cf1741cfb3d  addpd xmm1, xmm2
00007cf1741cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007cf1741cfb46  ptest xmm15, xmm15
00007cf1741cfb4c  jnz 0x00007CF1741D1EAB
00007cf1741cfb52  vmovaps xmm15, [rsp+0x20]
00007cf1741cfb58  vmovaps xmm13, [rsp+0x20]
00007cf1741cfb5e  por xmm15, xmm13
00007cf1741cfb63  movaps [r15+0x2F0], xmm15
00007cf1741cfb6b  vmovaps xmm13, [rsp+0xA0]
00007cf1741cfb74  vpermilpd xmm13, xmm13, 0x00
00007cf1741cfb7a  vmovaps [rsp+0x20], xmm1
00007cf1741cfb80  vmovaps xmm1, [rsp+0xC0]
00007cf1741cfb89  vmovaps [rsp+0xA0], xmm15
00007cf1741cfb92  movaps xmm2, xmm1
00007cf1741cfb95  mulpd xmm2, xmm13
00007cf1741cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007cf1741cfb9f  ptest xmm15, xmm15
00007cf1741cfba5  jnz 0x00007CF1741D1FEC
00007cf1741cfbab  lea rax, [r14+0xD0]
00007cf1741cfbb2  movups xmm1, [r13+rax*1]
00007cf1741cfbb8  vmovaps xmm13, [rsp+0xF0]
00007cf1741cfbc1  vmovaps [rsp+0xC0], xmm1
00007cf1741cfbca  vmovaps xmm1, [rsp+0xE0]
00007cf1741cfbd3  vmovaps [rsp+0xE0], xmm14
00007cf1741cfbdc  movaps xmm15, xmm13
00007cf1741cfbe0  addpd xmm15, xmm1
00007cf1741cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007cf1741cfbeb  ptest xmm14, xmm14
00007cf1741cfbf1  jnz 0x00007CF1741D2137
00007cf1741cfbf7  vmovaps xmm1, [rsp+0xB0]
00007cf1741cfc00  vpermilpd xmm1, xmm1, 0x00
00007cf1741cfc06  movaps xmm14, xmm11
00007cf1741cfc0a  mulpd xmm14, xmm1
00007cf1741cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007cf1741cfc15  ptest xmm13, xmm13
00007cf1741cfc1b  jnz 0x00007CF1741D227A
00007cf1741cfc21  movaps [r15+0x260], xmm14
00007cf1741cfc29  vxorps xmm1, xmm1, xmm1
00007cf1741cfc2d  vpbroadcastq xmm1, xmm1
00007cf1741cfc32  movaps [r15+0x1B0], xmm1
00007cf1741cfc3a  vmovaps xmm1, [rsp+0xB0]
00007cf1741cfc43  vpermilpd xmm1, xmm1, 0x00
00007cf1741cfc49  vmovaps xmm11, [rsp+0xC0]
00007cf1741cfc52  vmovaps [rsp+0xC0], xmm15
00007cf1741cfc5b  movaps xmm13, xmm11
00007cf1741cfc5f  mulpd xmm13, xmm1
00007cf1741cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007cf1741cfc6a  ptest xmm15, xmm15
00007cf1741cfc70  jnz 0x00007CF1741D23BD
00007cf1741cfc76  lea rax, [r14+0xC0]
00007cf1741cfc7d  movups xmm1, [r13+rax*1]
00007cf1741cfc83  vmovaps xmm11, [rsp+0x110]
00007cf1741cfc8c  vmovaps [rsp+0xF0], xmm1
00007cf1741cfc95  vmovaps xmm1, [rsp+0x30]
00007cf1741cfc9b  vmovaps [rsp+0x30], xmm14
00007cf1741cfca1  movaps xmm15, xmm11
00007cf1741cfca5  addpd xmm15, xmm1
00007cf1741cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007cf1741cfcb0  ptest xmm14, xmm14
00007cf1741cfcb6  jnz 0x00007CF1741D250A
00007cf1741cfcbc  vmovaps [rsp+0x100], xmm9
00007cf1741cfcc5  vmovaps xmm1, [rsp+0x100]
00007cf1741cfcce  por xmm9, xmm1
00007cf1741cfcd3  movaps [r15+0x270], xmm9
00007cf1741cfcdb  vmovaps [rsp+0x100], xmm6
00007cf1741cfce4  vmovaps xmm1, [rsp+0x100]
00007cf1741cfced  por xmm6, xmm1
00007cf1741cfcf1  movaps [r15+0x1A0], xmm6
00007cf1741cfcf9  vmovaps xmm14, [rsp+0xB0]
00007cf1741cfd02  vpermilpd xmm14, xmm14, 0x00
00007cf1741cfd08  vmovaps xmm6, [rsp+0xF0]
00007cf1741cfd11  vmovaps [rsp+0xF0], xmm1
00007cf1741cfd1a  movaps xmm11, xmm6
00007cf1741cfd1e  mulpd xmm11, xmm14
00007cf1741cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007cf1741cfd29  ptest xmm1, xmm1
00007cf1741cfd2e  jnz 0x00007CF1741D264D
00007cf1741cfd34  lea rax, [r14+0x20]
00007cf1741cfd38  movups xmm1, [r13+rax*1]
00007cf1741cfd3e  movaps [r15+0x110], xmm1
00007cf1741cfd46  vmovaps xmm6, [rsp+0xE0]
00007cf1741cfd4f  vmovaps [rsp+0xE0], xmm1
00007cf1741cfd58  movaps xmm14, xmm6
00007cf1741cfd5c  addpd xmm14, xmm2
00007cf1741cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007cf1741cfd67  ptest xmm1, xmm1
00007cf1741cfd6c  jnz 0x00007CF1741D279A
00007cf1741cfd72  vmovaps xmm1, [rsp+0xB0]
00007cf1741cfd7b  vpermilpd xmm1, xmm1, 0x00
00007cf1741cfd81  movaps xmm6, xmm5
00007cf1741cfd84  mulpd xmm6, xmm1
00007cf1741cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007cf1741cfd8d  ptest xmm2, xmm2
00007cf1741cfd92  jnz 0x00007CF1741D28DC
00007cf1741cfd98  vmovaps xmm5, [rsp+0x20]
00007cf1741cfd9e  movaps xmm1, xmm5
00007cf1741cfda1  addpd xmm1, xmm13
00007cf1741cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007cf1741cfdab  ptest xmm2, xmm2
00007cf1741cfdb0  jnz 0x00007CF1741D2A1C
00007cf1741cfdb6  vmovaps xmm13, [rsp+0x80]
00007cf1741cfdbf  vpermilpd xmm13, xmm13, 0x00
00007cf1741cfdc5  vmovaps xmm2, [rsp+0xE0]
00007cf1741cfdce  vmovaps [rsp+0x20], xmm1
00007cf1741cfdd4  movaps xmm5, xmm2
00007cf1741cfdd7  mulpd xmm5, xmm13
00007cf1741cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007cf1741cfde1  ptest xmm1, xmm1
00007cf1741cfde6  jnz 0x00007CF1741D2B5D
00007cf1741cfdec  vmovaps xmm1, [rsp+0x80]
00007cf1741cfdf5  vpermilpd xmm1, xmm1, 0x00
00007cf1741cfdfb  movaps xmm13, xmm10
00007cf1741cfdff  mulpd xmm13, xmm1
00007cf1741cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007cf1741cfe0a  ptest xmm2, xmm2
00007cf1741cfe0f  jnz 0x00007CF1741D2C9E
00007cf1741cfe15  vmovaps xmm10, [rsp+0x30]
00007cf1741cfe1b  movaps xmm1, xmm15
00007cf1741cfe1f  addpd xmm1, xmm10
00007cf1741cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007cf1741cfe29  ptest xmm2, xmm2
00007cf1741cfe2e  jnz 0x00007CF1741D2DE1
00007cf1741cfe34  vmovaps xmm10, [rsp+0xC0]
00007cf1741cfe3d  movaps xmm15, xmm10
00007cf1741cfe41  addpd xmm15, xmm11
00007cf1741cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007cf1741cfe4c  ptest xmm2, xmm2
00007cf1741cfe51  jnz 0x00007CF1741D2F23
00007cf1741cfe57  vmovaps xmm11, [rsp+0x80]
00007cf1741cfe60  vpermilpd xmm11, xmm11, 0x00
00007cf1741cfe66  movaps xmm10, xmm12
00007cf1741cfe6a  mulpd xmm10, xmm11
00007cf1741cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007cf1741cfe75  ptest xmm2, xmm2
00007cf1741cfe7a  jnz 0x00007CF1741D3067
00007cf1741cfe80  vmovaps xmm12, [rsp+0x80]
00007cf1741cfe89  vpermilpd xmm12, xmm12, 0x00
00007cf1741cfe8f  vmovaps xmm2, [rsp+0xA0]
00007cf1741cfe98  vmovaps [rsp+0x30], xmm1
00007cf1741cfe9e  movaps xmm11, xmm2
00007cf1741cfea2  mulpd xmm11, xmm12
00007cf1741cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007cf1741cfead  ptest xmm1, xmm1
00007cf1741cfeb2  jnz 0x00007CF1741D31AB
00007cf1741cfeb8  movaps xmm1, xmm14
00007cf1741cfebc  addpd xmm1, xmm6
00007cf1741cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007cf1741cfec5  ptest xmm12, xmm12
00007cf1741cfecb  jnz 0x00007CF1741D32EE
00007cf1741cfed1  vmovaps xmm12, [rsp+0x20]
00007cf1741cfed7  movaps xmm14, xmm12
00007cf1741cfedb  addpd xmm14, xmm5
00007cf1741cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007cf1741cfee6  ptest xmm6, xmm6
00007cf1741cfeeb  jnz 0x00007CF1741D342F
00007cf1741cfef1  vmovaps xmm12, [rsp+0x90]
00007cf1741cfefa  vpermilpd xmm12, xmm12, 0x00
00007cf1741cff00  movaps xmm6, xmm9
00007cf1741cff04  mulpd xmm6, xmm12
00007cf1741cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007cf1741cff0e  ptest xmm5, xmm5
00007cf1741cff13  jnz 0x00007CF1741D3572
00007cf1741cff19  movaps xmm12, xmm15
00007cf1741cff1d  addpd xmm12, xmm13
00007cf1741cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007cf1741cff28  ptest xmm9, xmm9
00007cf1741cff2e  jnz 0x00007CF1741D36B4
00007cf1741cff34  vmovaps xmm13, [rsp+0x30]
00007cf1741cff3a  movaps xmm15, xmm13
00007cf1741cff3e  addpd xmm15, xmm10
00007cf1741cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007cf1741cff49  ptest xmm9, xmm9
00007cf1741cff4f  jnz 0x00007CF1741D37F8
00007cf1741cff55  vmovaps xmm13, [rsp+0xD0]
00007cf1741cff5e  vmovaps xmm10, [rsp+0xD0]
00007cf1741cff67  por xmm13, xmm10
00007cf1741cff6c  movaps [r15+0x250], xmm13
00007cf1741cff74  vmovaps [rsp+0x20], xmm7
00007cf1741cff7a  vmovaps xmm13, [rsp+0x20]
00007cf1741cff80  por xmm7, xmm13
00007cf1741cff85  movaps [r15+0x2A0], xmm7
00007cf1741cff8d  vmovaps [rsp+0x20], xmm3
00007cf1741cff93  vmovaps xmm13, [rsp+0x20]
00007cf1741cff99  por xmm3, xmm13
00007cf1741cff9e  movaps [r15+0x1D0], xmm3
00007cf1741cffa6  lea rax, [r14+0x40]
00007cf1741cffaa  movups xmm13, [r13+rax*1]
00007cf1741cffb0  movaps [r15+0x2C0], xmm13
00007cf1741cffb8  vmovaps xmm10, [rsp+0x90]
00007cf1741cffc1  vpermilpd xmm10, xmm10, 0x00
00007cf1741cffc7  movaps xmm9, xmm8
00007cf1741cffcb  mulpd xmm9, xmm10
00007cf1741cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007cf1741cffd6  ptest xmm5, xmm5
00007cf1741cffdb  jnz 0x00007CF1741D3946
00007cf1741cffe1  movaps xmm10, xmm1
00007cf1741cffe5  addpd xmm10, xmm11
00007cf1741cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007cf1741cfff0  ptest xmm8, xmm8
00007cf1741cfff6  jnz 0x00007CF1741D3A8A
00007cf1741cfffc  movaps xmm1, xmm14
00007cf1741d0000  addpd xmm1, xmm6
00007cf1741d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007cf1741d0009  ptest xmm11, xmm11
00007cf1741d000f  jnz 0x00007CF1741D3BCD
00007cf1741d0015  vmovaps xmm14, [rsp+0x90]
00007cf1741d001e  vpermilpd xmm14, xmm14, 0x00
00007cf1741d0024  movaps xmm11, xmm13
00007cf1741d0028  mulpd xmm11, xmm14
00007cf1741d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007cf1741d0033  ptest xmm8, xmm8
00007cf1741d0039  jnz 0x00007CF1741D3D0E
00007cf1741d003f  vmovaps xmm14, [rsp+0x90]
00007cf1741d0048  vpermilpd xmm14, xmm14, 0x00
00007cf1741d004e  vmovaps xmm8, [rsp+0x10]
00007cf1741d0054  movaps xmm13, xmm8
00007cf1741d0058  mulpd xmm13, xmm14
00007cf1741d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007cf1741d0063  ptest xmm6, xmm6
00007cf1741d0068  jnz 0x00007CF1741D3E52
00007cf1741d006e  vmovaps xmm14, [rsp+0x60]
00007cf1741d0074  vpermilpd xmm14, xmm14, 0x00
00007cf1741d007a  movaps xmm8, xmm7
00007cf1741d007e  mulpd xmm8, xmm14
00007cf1741d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007cf1741d0089  ptest xmm6, xmm6
00007cf1741d008e  jnz 0x00007CF1741D3F96
00007cf1741d0094  movaps xmm14, xmm12
00007cf1741d0098  addpd xmm14, xmm9
00007cf1741d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007cf1741d00a3  ptest xmm7, xmm7
00007cf1741d00a8  jnz 0x00007CF1741D40D9
00007cf1741d00ae  vmovaps xmm12, [rsp+0x60]
00007cf1741d00b4  vpermilpd xmm12, xmm12, 0x00
00007cf1741d00ba  vmovaps xmm7, [rsp+0xF0]
00007cf1741d00c3  movaps xmm9, xmm7
00007cf1741d00c7  mulpd xmm9, xmm12
00007cf1741d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007cf1741d00d2  ptest xmm6, xmm6
00007cf1741d00d7  jnz 0x00007CF1741D421D
00007cf1741d00dd  movaps xmm12, xmm15
00007cf1741d00e1  addpd xmm12, xmm11
00007cf1741d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007cf1741d00ec  ptest xmm7, xmm7
00007cf1741d00f1  jnz 0x00007CF1741D4360
00007cf1741d00f7  vmovaps xmm15, [rsp+0x60]
00007cf1741d00fd  vpermilpd xmm15, xmm15, 0x00
00007cf1741d0103  vmovaps xmm7, [rsp+0x40]
00007cf1741d0109  movaps xmm11, xmm7
00007cf1741d010d  mulpd xmm11, xmm15
00007cf1741d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007cf1741d0118  ptest xmm6, xmm6
00007cf1741d011d  jnz 0x00007CF1741D44A4
00007cf1741d0123  movaps xmm15, xmm10
00007cf1741d0127  addpd xmm15, xmm13
00007cf1741d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007cf1741d0132  ptest xmm7, xmm7
00007cf1741d0137  jnz 0x00007CF1741D45E7
00007cf1741d013d  vmovaps xmm13, [rsp+0x60]
00007cf1741d0143  vpermilpd xmm13, xmm13, 0x00
00007cf1741d0149  vmovaps xmm7, [rsp+0x50]
00007cf1741d014f  movaps xmm10, xmm7
00007cf1741d0153  mulpd xmm10, xmm13
00007cf1741d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007cf1741d015e  ptest xmm6, xmm6
00007cf1741d0163  jnz 0x00007CF1741D472B
00007cf1741d0169  movaps xmm13, xmm1
00007cf1741d016d  addpd xmm13, xmm8
00007cf1741d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007cf1741d0178  ptest xmm7, xmm7
00007cf1741d017d  jnz 0x00007CF1741D486E
00007cf1741d0183  lea rax, [r14+0x70]
00007cf1741d0187  movups xmm1, [r13+rax*1]
00007cf1741d018d  movaps [r15+0x240], xmm1
00007cf1741d0195  movaps xmm8, xmm14
00007cf1741d0199  addpd xmm8, xmm9
00007cf1741d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007cf1741d01a4  ptest xmm7, xmm7
00007cf1741d01a9  jnz 0x00007CF1741D49BB
00007cf1741d01af  movaps [r15+0x170], xmm8
00007cf1741d01b7  vmovaps xmm14, [rsp+0x70]
00007cf1741d01bd  vpermilpd xmm14, xmm14, 0x00
00007cf1741d01c3  movaps xmm9, xmm1
00007cf1741d01c7  mulpd xmm9, xmm14
00007cf1741d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007cf1741d01d2  ptest xmm7, xmm7
00007cf1741d01d7  jnz 0x00007CF1741D4AFF
00007cf1741d01dd  vmovaps xmm1, [rsp+0x70]
00007cf1741d01e3  vpermilpd xmm1, xmm1, 0x00
00007cf1741d01e9  movaps xmm14, xmm4
00007cf1741d01ed  mulpd xmm14, xmm1
00007cf1741d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007cf1741d01f8  ptest xmm7, xmm7
00007cf1741d01fd  jnz 0x00007CF1741D4C42
00007cf1741d0203  movaps [r15+0x180], xmm14
00007cf1741d020b  movaps xmm1, xmm12
00007cf1741d020f  addpd xmm1, xmm11
00007cf1741d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007cf1741d0219  ptest xmm7, xmm7
00007cf1741d021e  jnz 0x00007CF1741D4D84
00007cf1741d0224  movaps [r15+0x210], xmm1
00007cf1741d022c  movups xmm12, [r13+r14*1]
00007cf1741d0232  lea rax, [r14+0x10]
00007cf1741d0236  movups xmm11, [r13+rax*1]
00007cf1741d023c  movaps [r15+0x230], xmm11
00007cf1741d0244  movaps xmm7, xmm15
00007cf1741d0248  addpd xmm7, xmm10
00007cf1741d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007cf1741d0252  ptest xmm6, xmm6
00007cf1741d0257  jnz 0x00007CF1741D4EDA
00007cf1741d025d  movaps [r15+0x130], xmm7
00007cf1741d0265  vmovaps xmm15, [rsp+0x70]
00007cf1741d026b  vpermilpd xmm15, xmm15, 0x00
00007cf1741d0271  movaps xmm10, xmm11
00007cf1741d0275  mulpd xmm10, xmm15
00007cf1741d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007cf1741d0280  ptest xmm6, xmm6
00007cf1741d0285  jnz 0x00007CF1741D501C
00007cf1741d028b  movaps [r15+0x220], xmm10
00007cf1741d0293  vmovaps xmm15, [rsp+0x70]
00007cf1741d0299  vpermilpd xmm15, xmm15, 0x00
00007cf1741d029f  movaps xmm11, xmm12
00007cf1741d02a3  mulpd xmm11, xmm15
00007cf1741d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007cf1741d02ae  ptest xmm6, xmm6
00007cf1741d02b3  jnz 0x00007CF1741D5160
00007cf1741d02b9  movaps xmm15, xmm13
00007cf1741d02bd  addpd xmm15, xmm9
00007cf1741d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007cf1741d02c8  ptest xmm12, xmm12
00007cf1741d02ce  jnz 0x00007CF1741D52A4
00007cf1741d02d4  movaps [r15+0x140], xmm15
00007cf1741d02dc  movaps xmm13, xmm8
00007cf1741d02e0  addpd xmm13, xmm14
00007cf1741d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007cf1741d02eb  ptest xmm12, xmm12
00007cf1741d02f1  jnz 0x00007CF1741D53E8
00007cf1741d02f7  movaps [r15+0x150], xmm13
00007cf1741d02ff  movaps xmm14, xmm1
00007cf1741d0303  addpd xmm14, xmm10
00007cf1741d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007cf1741d030e  ptest xmm12, xmm12
00007cf1741d0314  jnz 0x00007CF1741D552C
00007cf1741d031a  movaps [r15+0x160], xmm14
00007cf1741d0322  movaps xmm1, xmm7
00007cf1741d0325  addpd xmm1, xmm11
00007cf1741d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007cf1741d032f  ptest xmm12, xmm12
00007cf1741d0335  jnz 0x00007CF1741D566F
00007cf1741d033b  movaps [r15+0x120], xmm1
00007cf1741d0343  mov eax, 0x430920
00007cf1741d0348  movups [r13+rax*1], xmm15
00007cf1741d034e  mov eax, 0x430930
00007cf1741d0353  movups [r13+rax*1], xmm13
00007cf1741d0359  mov eax, 0x430940
00007cf1741d035e  movups [r13+rax*1], xmm14
00007cf1741d0364  mov eax, 0x430950
00007cf1741d0369  movups [r13+rax*1], xmm1
00007cf1741d036f  mov eax, [r15+0x108]
00007cf1741d0376  sahf
00007cf1741d0377  jnz 0x00007CF1741D03A9
00007cf1741d0379  cmp dword ptr [r15+0x318], 0x00
00007cf1741d0381  jz 0x00007CF1741DB900
00007cf1741d0387  nop [rax+rax*1], ax
00007cf1741d0390  nop [rax+rax*1], eax
00007cf1741d0398  mov eax, 0x410444
00007cf1741d039d  mov [r15+0x100], rax
00007cf1741d03a4  jmp 0x00007CF173FFE110
00007cf1741d03a9  cmp dword ptr [r15+0x318], 0x00
00007cf1741d03b1  jz 0x00007CF1741D57E0
00007cf1741d03b7  nop [rax+rax*1], ax
00007cf1741d03c0  nop [rax+rax*1], eax
00007cf1741d03c8  mov eax, 0x410278
00007cf1741d03cd  mov [r15+0x100], rax
00007cf1741d03d4  jmp 0x00007CF173FFE110
00007cf1741d03d9  int3
00007cf1741d03da  call 0x00007CF1740B52F0
00007cf1741d03df  jmp 0x00007CF1741CF016
00007cf1741d03e4  call 0x00007CF1740C4620
00007cf1741d03e9  jmp 0x00007CF1741CF023
00007cf1741d03ee  call 0x00007CF1740C33A0
00007cf1741d03f3  jmp 0x00007CF1741CF035
00007cf1741d03f8  call 0x00007CF1740C2120
00007cf1741d03fd  jmp 0x00007CF1741CF03F
00007cf1741d0402  call 0x00007CF1740C0860
00007cf1741d0407  jmp 0x00007CF1741CF067
00007cf1741d040c  call 0x00007CF1740BF5F0
00007cf1741d0411  jmp 0x00007CF1741CF073
00007cf1741d0416  call 0x00007CF1740C0860
00007cf1741d041b  jmp 0x00007CF1741CF0A5
00007cf1741d0420  call 0x00007CF1740BF5F0
00007cf1741d0425  jmp 0x00007CF1741CF0B1
00007cf1741d042a  call 0x00007CF1740C4740
00007cf1741d042f  jmp 0x00007CF1741CF0BE
00007cf1741d0434  call 0x00007CF1740B5400
00007cf1741d0439  jmp 0x00007CF1741CF0CB
00007cf1741d043e  call 0x00007CF1740B52F0
00007cf1741d0443  jmp 0x00007CF1741CF0D8
00007cf1741d0448  call 0x00007CF1740C4620
00007cf1741d044d  jmp 0x00007CF1741CF0E5
00007cf1741d0452  call 0x00007CF1740C0860
00007cf1741d0457  jmp 0x00007CF1741CF10D
00007cf1741d045c  call 0x00007CF1740BF5F0
00007cf1741d0461  jmp 0x00007CF1741CF119
00007cf1741d0466  call 0x00007CF174009D70
00007cf1741d046b  jmp 0x00007CF1741CF11F
00007cf1741d0470  call 0x00007CF1740BE9C0
00007cf1741d0475  jmp 0x00007CF1741CF129
00007cf1741d047a  call 0x00007CF1740C0860
00007cf1741d047f  jmp 0x00007CF1741CF151
00007cf1741d0484  call 0x00007CF1740BF5F0
00007cf1741d0489  jmp 0x00007CF1741CF15D
00007cf1741d048e  call 0x00007CF1740BD750
00007cf1741d0493  jmp 0x00007CF1741CF16A
00007cf1741d0498  call 0x00007CF1740BC4E0
00007cf1741d049d  jmp 0x00007CF1741CF177
00007cf1741d04a2  call 0x00007CF1740C4740
00007cf1741d04a7  jmp 0x00007CF1741CF184
00007cf1741d04ac  call 0x00007CF1740B5400
00007cf1741d04b1  jmp 0x00007CF1741CF191
00007cf1741d04b6  call 0x00007CF1740B52F0
00007cf1741d04bb  jmp 0x00007CF1741CF19E
00007cf1741d04c0  call 0x00007CF1740C4620
00007cf1741d04c5  jmp 0x00007CF1741CF1AB
00007cf1741d04ca  call 0x00007CF1740C0860
00007cf1741d04cf  jmp 0x00007CF1741CF1BE
00007cf1741d04d4  call 0x00007CF1740BB270
00007cf1741d04d9  jmp 0x00007CF1741CF1CB
00007cf1741d04de  call 0x00007CF1740BA000
00007cf1741d04e3  jmp 0x00007CF1741CF1D8
00007cf1741d04e8  call 0x00007CF1740B8D90
00007cf1741d04ed  jmp 0x00007CF1741CF1E5
00007cf1741d04f2  call 0x00007CF1740B8A20
00007cf1741d04f7  jmp 0x00007CF1741CF1F2
00007cf1741d04fc  call 0x00007CF1740B5400
00007cf1741d0501  jmp 0x00007CF1741CF1FC
00007cf1741d0506  call 0x00007CF1740C2240
00007cf1741d050b  jmp 0x00007CF1741CF206
00007cf1741d0510  call 0x00007CF1740B52F0
00007cf1741d0515  jmp 0x00007CF1741CF210
00007cf1741d051a  call 0x00007CF1740C2120
00007cf1741d051f  jmp 0x00007CF1741CF21A
00007cf1741d0524  call 0x00007CF1740B77B0
00007cf1741d0529  jmp 0x00007CF1741CF224
00007cf1741d052e  call 0x00007CF1740B6550
00007cf1741d0533  jmp 0x00007CF1741CF22E
00007cf1741d0538  call 0x00007CF1740BFD50
00007cf1741d053d  jmp 0x00007CF1741CF240
00007cf1741d0542  call 0x00007CF1740B8EA0
00007cf1741d0547  jmp 0x00007CF1741CF24A
00007cf1741d054c  call 0x00007CF1740BFC30
00007cf1741d0551  jmp 0x00007CF1741CF257
00007cf1741d0556  call 0x00007CF1740B8D90
00007cf1741d055b  jmp 0x00007CF1741CF264
00007cf1741d0560  call 0x00007CF1740C2240
00007cf1741d0565  jmp 0x00007CF1741CF271
00007cf1741d056a  call 0x00007CF1740B5400
00007cf1741d056f  jmp 0x00007CF1741CF27E
00007cf1741d0574  call 0x00007CF1740B52F0
00007cf1741d0579  jmp 0x00007CF1741CF28B
00007cf1741d057e  call 0x00007CF1740C2120
00007cf1741d0583  jmp 0x00007CF1741CF298
00007cf1741d0588  call 0x00007CF1740B52F0
00007cf1741d058d  jmp 0x00007CF1741CF2AB
00007cf1741d0592  call 0x00007CF1740B52F0
00007cf1741d0597  jmp 0x00007CF1741CF2BE
00007cf1741d059c  call 0x00007CF1740B52F0
00007cf1741d05a1  jmp 0x00007CF1741CF2D1
00007cf1741d05a6  call 0x00007CF1740B52F0
00007cf1741d05ab  jmp 0x00007CF1741CF2E4
00007cf1741d05b0  call 0x00007CF1740C2240
00007cf1741d05b5  jmp 0x00007CF1741CF2F9
00007cf1741d05ba  call 0x00007CF1740C2240
00007cf1741d05bf  jmp 0x00007CF1741CF30C
00007cf1741d05c4  call 0x00007CF1740C2120
00007cf1741d05c9  jmp 0x00007CF1741CF319
00007cf1741d05ce  call 0x00007CF1740B52F0
00007cf1741d05d3  jmp 0x00007CF1741CF32C
00007cf1741d05d8  call 0x00007CF1740B52F0
00007cf1741d05dd  jmp 0x00007CF1741CF34F
00007cf1741d05e2  call 0x00007CF1740B52F0
00007cf1741d05e7  jmp 0x00007CF1741CF362
00007cf1741d05ec  call 0x00007CF173FFF540
00007cf1741d05f1  jmp 0x00007CF1741CF380
00007cf1741d05f6  call 0x00007CF174008C20
00007cf1741d05fb  jmp 0x00007CF1741CF38A
00007cf1741d0600  call 0x00007CF1740D6600
00007cf1741d0605  jmp 0x00007CF1741CF396
00007cf1741d060a  call 0x00007CF173FFF540
00007cf1741d060f  jmp 0x00007CF1741CF3A6
00007cf1741d0614  call 0x00007CF1740C0370
00007cf1741d0619  jmp 0x00007CF1741CF3D4
00007cf1741d061e  call 0x00007CF1740BF100
00007cf1741d0623  jmp 0x00007CF1741CF3DD
00007cf1741d0628  call 0x00007CF1740C0370
00007cf1741d062d  jmp 0x00007CF1741CF43B
00007cf1741d0632  call 0x00007CF1740BF100
00007cf1741d0637  jmp 0x00007CF1741CF444
00007cf1741d063c  call 0x00007CF1740C0370
00007cf1741d0641  jmp 0x00007CF1741CF48B
00007cf1741d0646  call 0x00007CF1740BF100
00007cf1741d064b  jmp 0x00007CF1741CF494
00007cf1741d0650  call 0x00007CF17400B720
00007cf1741d0655  jmp 0x00007CF1741CF4D7
00007cf1741d065a  call 0x00007CF1740B47C0
00007cf1741d065f  jmp 0x00007CF1741CF4EA
00007cf1741d0664  call 0x00007CF174008B00
00007cf1741d0669  jmp 0x00007CF1741CF501
00007cf1741d066e  call 0x00007CF173FFF430
00007cf1741d0673  jmp 0x00007CF1741CF514
00007cf1741d0678  call 0x00007CF173FFF430
00007cf1741d067d  jmp 0x00007CF1741CF527
00007cf1741d0682  sub rsp, 0x08
00007cf1741d0686  push rax
00007cf1741d0687  push rcx
00007cf1741d0688  push rdx
00007cf1741d0689  push rdi
00007cf1741d068a  push rsi
00007cf1741d068b  push r8
00007cf1741d068d  push r9
00007cf1741d068f  push r10
00007cf1741d0691  push r11
00007cf1741d0693  sub rsp, 0xF0
00007cf1741d069a  vmovaps [rsp], xmm0
00007cf1741d069f  vmovaps [rsp+0x10], xmm2
00007cf1741d06a5  vmovaps [rsp+0x20], xmm3
00007cf1741d06ab  vmovaps [rsp+0x30], xmm4
00007cf1741d06b1  vmovaps [rsp+0x40], xmm5
00007cf1741d06b7  vmovaps [rsp+0x50], xmm6
00007cf1741d06bd  vmovaps [rsp+0x60], xmm7
00007cf1741d06c3  vmovaps [rsp+0x70], xmm8
00007cf1741d06c9  vmovaps [rsp+0x80], xmm9
00007cf1741d06d2  vmovaps [rsp+0x90], xmm10
00007cf1741d06db  vmovaps [rsp+0xA0], xmm11
00007cf1741d06e4  vmovaps [rsp+0xB0], xmm12
00007cf1741d06ed  vmovaps [rsp+0xC0], xmm13
00007cf1741d06f6  vmovaps [rsp+0xD0], xmm14
00007cf1741d06ff  vmovaps [rsp+0xE0], xmm15
00007cf1741d0708  sub rsp, 0x30
00007cf1741d070c  movaps [rsp], xmm1
00007cf1741d0710  movaps [rsp+0x10], xmm15
00007cf1741d0716  movaps [rsp+0x20], xmm14
00007cf1741d071c  lea rdi, [rsp]
00007cf1741d0720  mov esi, 0x00
00007cf1741d0725  mov rax, 0x611C8A33A530
00007cf1741d072f  call rax
00007cf1741d0731  movaps xmm1, [rsp]
00007cf1741d0735  add rsp, 0x30
00007cf1741d0739  vmovaps xmm0, [rsp]
00007cf1741d073e  vmovaps xmm2, [rsp+0x10]
00007cf1741d0744  vmovaps xmm3, [rsp+0x20]
00007cf1741d074a  vmovaps xmm4, [rsp+0x30]
00007cf1741d0750  vmovaps xmm5, [rsp+0x40]
00007cf1741d0756  vmovaps xmm6, [rsp+0x50]
00007cf1741d075c  vmovaps xmm7, [rsp+0x60]
00007cf1741d0762  vmovaps xmm8, [rsp+0x70]
00007cf1741d0768  vmovaps xmm9, [rsp+0x80]
00007cf1741d0771  vmovaps xmm10, [rsp+0x90]
00007cf1741d077a  vmovaps xmm11, [rsp+0xA0]
00007cf1741d0783  vmovaps xmm12, [rsp+0xB0]
00007cf1741d078c  vmovaps xmm13, [rsp+0xC0]
00007cf1741d0795  vmovaps xmm14, [rsp+0xD0]
00007cf1741d079e  vmovaps xmm15, [rsp+0xE0]
00007cf1741d07a7  add rsp, 0xF0
00007cf1741d07ae  pop r11
00007cf1741d07b0  pop r10
00007cf1741d07b2  pop r9
00007cf1741d07b4  pop r8
00007cf1741d07b6  pop rsi
00007cf1741d07b7  pop rdi
00007cf1741d07b8  pop rdx
00007cf1741d07b9  pop rcx
00007cf1741d07ba  pop rax
00007cf1741d07bb  add rsp, 0x08
00007cf1741d07bf  jmp 0x00007CF1741CF581
00007cf1741d07c4  sub rsp, 0x08
00007cf1741d07c8  push rax
00007cf1741d07c9  push rcx
00007cf1741d07ca  push rdx
00007cf1741d07cb  push rdi
00007cf1741d07cc  push rsi
00007cf1741d07cd  push r8
00007cf1741d07cf  push r9
00007cf1741d07d1  push r10
00007cf1741d07d3  push r11
00007cf1741d07d5  sub rsp, 0xF0
00007cf1741d07dc  vmovaps [rsp], xmm0
00007cf1741d07e1  vmovaps [rsp+0x10], xmm1
00007cf1741d07e7  vmovaps [rsp+0x20], xmm2
00007cf1741d07ed  vmovaps [rsp+0x30], xmm3
00007cf1741d07f3  vmovaps [rsp+0x40], xmm4
00007cf1741d07f9  vmovaps [rsp+0x50], xmm5
00007cf1741d07ff  vmovaps [rsp+0x60], xmm6
00007cf1741d0805  vmovaps [rsp+0x70], xmm7
00007cf1741d080b  vmovaps [rsp+0x80], xmm8
00007cf1741d0814  vmovaps [rsp+0x90], xmm9
00007cf1741d081d  vmovaps [rsp+0xA0], xmm10
00007cf1741d0826  vmovaps [rsp+0xB0], xmm11
00007cf1741d082f  vmovaps [rsp+0xC0], xmm12
00007cf1741d0838  vmovaps [rsp+0xD0], xmm14
00007cf1741d0841  vmovaps [rsp+0xE0], xmm15
00007cf1741d084a  sub rsp, 0x30
00007cf1741d084e  movaps [rsp], xmm13
00007cf1741d0853  movaps [rsp+0x10], xmm1
00007cf1741d0858  movaps [rsp+0x20], xmm14
00007cf1741d085e  lea rdi, [rsp]
00007cf1741d0862  mov esi, 0x00
00007cf1741d0867  mov rax, 0x611C8A33A530
00007cf1741d0871  call rax
00007cf1741d0873  movaps xmm13, [rsp]
00007cf1741d0878  add rsp, 0x30
00007cf1741d087c  vmovaps xmm0, [rsp]
00007cf1741d0881  vmovaps xmm1, [rsp+0x10]
00007cf1741d0887  vmovaps xmm2, [rsp+0x20]
00007cf1741d088d  vmovaps xmm3, [rsp+0x30]
00007cf1741d0893  vmovaps xmm4, [rsp+0x40]
00007cf1741d0899  vmovaps xmm5, [rsp+0x50]
00007cf1741d089f  vmovaps xmm6, [rsp+0x60]
00007cf1741d08a5  vmovaps xmm7, [rsp+0x70]
00007cf1741d08ab  vmovaps xmm8, [rsp+0x80]
00007cf1741d08b4  vmovaps xmm9, [rsp+0x90]
00007cf1741d08bd  vmovaps xmm10, [rsp+0xA0]
00007cf1741d08c6  vmovaps xmm11, [rsp+0xB0]
00007cf1741d08cf  vmovaps xmm12, [rsp+0xC0]
00007cf1741d08d8  vmovaps xmm14, [rsp+0xD0]
00007cf1741d08e1  vmovaps xmm15, [rsp+0xE0]
00007cf1741d08ea  add rsp, 0xF0
00007cf1741d08f1  pop r11
00007cf1741d08f3  pop r10
00007cf1741d08f5  pop r9
00007cf1741d08f7  pop r8
00007cf1741d08f9  pop rsi
00007cf1741d08fa  pop rdi
00007cf1741d08fb  pop rdx
00007cf1741d08fc  pop rcx
00007cf1741d08fd  pop rax
00007cf1741d08fe  add rsp, 0x08
00007cf1741d0902  jmp 0x00007CF1741CF5CF
00007cf1741d0907  sub rsp, 0x08
00007cf1741d090b  push rax
00007cf1741d090c  push rcx
00007cf1741d090d  push rdx
00007cf1741d090e  push rdi
00007cf1741d090f  push rsi
00007cf1741d0910  push r8
00007cf1741d0912  push r9
00007cf1741d0914  push r10
00007cf1741d0916  push r11
00007cf1741d0918  sub rsp, 0xF0
00007cf1741d091f  vmovaps [rsp], xmm0
00007cf1741d0924  vmovaps [rsp+0x10], xmm1
00007cf1741d092a  vmovaps [rsp+0x20], xmm2
00007cf1741d0930  vmovaps [rsp+0x30], xmm3
00007cf1741d0936  vmovaps [rsp+0x40], xmm4
00007cf1741d093c  vmovaps [rsp+0x50], xmm5
00007cf1741d0942  vmovaps [rsp+0x60], xmm6
00007cf1741d0948  vmovaps [rsp+0x70], xmm7
00007cf1741d094e  vmovaps [rsp+0x80], xmm8
00007cf1741d0957  vmovaps [rsp+0x90], xmm9
00007cf1741d0960  vmovaps [rsp+0xA0], xmm10
00007cf1741d0969  vmovaps [rsp+0xB0], xmm11
00007cf1741d0972  vmovaps [rsp+0xC0], xmm12
00007cf1741d097b  vmovaps [rsp+0xD0], xmm13
00007cf1741d0984  vmovaps [rsp+0xE0], xmm14
00007cf1741d098d  sub rsp, 0x30
00007cf1741d0991  movaps [rsp], xmm15
00007cf1741d0996  movaps [rsp+0x10], xmm14
00007cf1741d099c  movaps [rsp+0x20], xmm1
00007cf1741d09a1  lea rdi, [rsp]
00007cf1741d09a5  mov esi, 0x00
00007cf1741d09aa  mov rax, 0x611C8A33A530
00007cf1741d09b4  call rax
00007cf1741d09b6  movaps xmm15, [rsp]
00007cf1741d09bb  add rsp, 0x30
00007cf1741d09bf  vmovaps xmm0, [rsp]
00007cf1741d09c4  vmovaps xmm1, [rsp+0x10]
00007cf1741d09ca  vmovaps xmm2, [rsp+0x20]
00007cf1741d09d0  vmovaps xmm3, [rsp+0x30]
00007cf1741d09d6  vmovaps xmm4, [rsp+0x40]
00007cf1741d09dc  vmovaps xmm5, [rsp+0x50]
00007cf1741d09e2  vmovaps xmm6, [rsp+0x60]
00007cf1741d09e8  vmovaps xmm7, [rsp+0x70]
00007cf1741d09ee  vmovaps xmm8, [rsp+0x80]
00007cf1741d09f7  vmovaps xmm9, [rsp+0x90]
00007cf1741d0a00  vmovaps xmm10, [rsp+0xA0]
00007cf1741d0a09  vmovaps xmm11, [rsp+0xB0]
00007cf1741d0a12  vmovaps xmm12, [rsp+0xC0]
00007cf1741d0a1b  vmovaps xmm13, [rsp+0xD0]
00007cf1741d0a24  vmovaps xmm14, [rsp+0xE0]
00007cf1741d0a2d  add rsp, 0xF0
00007cf1741d0a34  pop r11
00007cf1741d0a36  pop r10
00007cf1741d0a38  pop r9
00007cf1741d0a3a  pop r8
00007cf1741d0a3c  pop rsi
00007cf1741d0a3d  pop rdi
00007cf1741d0a3e  pop rdx
00007cf1741d0a3f  pop rcx
00007cf1741d0a40  pop rax
00007cf1741d0a41  add rsp, 0x08
00007cf1741d0a45  jmp 0x00007CF1741CF617
00007cf1741d0a4a  sub rsp, 0x08
00007cf1741d0a4e  push rax
00007cf1741d0a4f  push rcx
00007cf1741d0a50  push rdx
00007cf1741d0a51  push rdi
00007cf1741d0a52  push rsi
00007cf1741d0a53  push r8
00007cf1741d0a55  push r9
00007cf1741d0a57  push r10
00007cf1741d0a59  push r11
00007cf1741d0a5b  sub rsp, 0xF0
00007cf1741d0a62  vmovaps [rsp], xmm0
00007cf1741d0a67  vmovaps [rsp+0x10], xmm2
00007cf1741d0a6d  vmovaps [rsp+0x20], xmm3
00007cf1741d0a73  vmovaps [rsp+0x30], xmm4
00007cf1741d0a79  vmovaps [rsp+0x40], xmm5
00007cf1741d0a7f  vmovaps [rsp+0x50], xmm6
00007cf1741d0a85  vmovaps [rsp+0x60], xmm7
00007cf1741d0a8b  vmovaps [rsp+0x70], xmm8
00007cf1741d0a91  vmovaps [rsp+0x80], xmm9
00007cf1741d0a9a  vmovaps [rsp+0x90], xmm10
00007cf1741d0aa3  vmovaps [rsp+0xA0], xmm11
00007cf1741d0aac  vmovaps [rsp+0xB0], xmm12
00007cf1741d0ab5  vmovaps [rsp+0xC0], xmm13
00007cf1741d0abe  vmovaps [rsp+0xD0], xmm14
00007cf1741d0ac7  vmovaps [rsp+0xE0], xmm15
00007cf1741d0ad0  sub rsp, 0x30
00007cf1741d0ad4  movaps [rsp], xmm1
00007cf1741d0ad8  movaps [rsp+0x10], xmm14
00007cf1741d0ade  movaps [rsp+0x20], xmm10
00007cf1741d0ae4  lea rdi, [rsp]
00007cf1741d0ae8  mov esi, 0x00
00007cf1741d0aed  mov rax, 0x611C8A33A530
00007cf1741d0af7  call rax
00007cf1741d0af9  movaps xmm1, [rsp]
00007cf1741d0afd  add rsp, 0x30
00007cf1741d0b01  vmovaps xmm0, [rsp]
00007cf1741d0b06  vmovaps xmm2, [rsp+0x10]
00007cf1741d0b0c  vmovaps xmm3, [rsp+0x20]
00007cf1741d0b12  vmovaps xmm4, [rsp+0x30]
00007cf1741d0b18  vmovaps xmm5, [rsp+0x40]
00007cf1741d0b1e  vmovaps xmm6, [rsp+0x50]
00007cf1741d0b24  vmovaps xmm7, [rsp+0x60]
00007cf1741d0b2a  vmovaps xmm8, [rsp+0x70]
00007cf1741d0b30  vmovaps xmm9, [rsp+0x80]
00007cf1741d0b39  vmovaps xmm10, [rsp+0x90]
00007cf1741d0b42  vmovaps xmm11, [rsp+0xA0]
00007cf1741d0b4b  vmovaps xmm12, [rsp+0xB0]
00007cf1741d0b54  vmovaps xmm13, [rsp+0xC0]
00007cf1741d0b5d  vmovaps xmm14, [rsp+0xD0]
00007cf1741d0b66  vmovaps xmm15, [rsp+0xE0]
00007cf1741d0b6f  add rsp, 0xF0
00007cf1741d0b76  pop r11
00007cf1741d0b78  pop r10
00007cf1741d0b7a  pop r9
00007cf1741d0b7c  pop r8
00007cf1741d0b7e  pop rsi
00007cf1741d0b7f  pop rdi
00007cf1741d0b80  pop rdx
00007cf1741d0b81  pop rcx
00007cf1741d0b82  pop rax
00007cf1741d0b83  add rsp, 0x08
00007cf1741d0b87  jmp 0x00007CF1741CF631
00007cf1741d0b8c  sub rsp, 0x08
00007cf1741d0b90  push rax
00007cf1741d0b91  push rcx
00007cf1741d0b92  push rdx
00007cf1741d0b93  push rdi
00007cf1741d0b94  push rsi
00007cf1741d0b95  push r8
00007cf1741d0b97  push r9
00007cf1741d0b99  push r10
00007cf1741d0b9b  push r11
00007cf1741d0b9d  sub rsp, 0xF0
00007cf1741d0ba4  vmovaps [rsp], xmm0
00007cf1741d0ba9  vmovaps [rsp+0x10], xmm1
00007cf1741d0baf  vmovaps [rsp+0x20], xmm2
00007cf1741d0bb5  vmovaps [rsp+0x30], xmm3
00007cf1741d0bbb  vmovaps [rsp+0x40], xmm4
00007cf1741d0bc1  vmovaps [rsp+0x50], xmm5
00007cf1741d0bc7  vmovaps [rsp+0x60], xmm6
00007cf1741d0bcd  vmovaps [rsp+0x70], xmm7
00007cf1741d0bd3  vmovaps [rsp+0x80], xmm8
00007cf1741d0bdc  vmovaps [rsp+0x90], xmm9
00007cf1741d0be5  vmovaps [rsp+0xA0], xmm10
00007cf1741d0bee  vmovaps [rsp+0xB0], xmm11
00007cf1741d0bf7  vmovaps [rsp+0xC0], xmm12
00007cf1741d0c00  vmovaps [rsp+0xD0], xmm14
00007cf1741d0c09  vmovaps [rsp+0xE0], xmm15
00007cf1741d0c12  sub rsp, 0x30
00007cf1741d0c16  movaps [rsp], xmm13
00007cf1741d0c1b  movaps [rsp+0x10], xmm14
00007cf1741d0c21  movaps [rsp+0x20], xmm2
00007cf1741d0c26  lea rdi, [rsp]
00007cf1741d0c2a  mov esi, 0x00
00007cf1741d0c2f  mov rax, 0x611C8A33A530
00007cf1741d0c39  call rax
00007cf1741d0c3b  movaps xmm13, [rsp]
00007cf1741d0c40  add rsp, 0x30
00007cf1741d0c44  vmovaps xmm0, [rsp]
00007cf1741d0c49  vmovaps xmm1, [rsp+0x10]
00007cf1741d0c4f  vmovaps xmm2, [rsp+0x20]
00007cf1741d0c55  vmovaps xmm3, [rsp+0x30]
00007cf1741d0c5b  vmovaps xmm4, [rsp+0x40]
00007cf1741d0c61  vmovaps xmm5, [rsp+0x50]
00007cf1741d0c67  vmovaps xmm6, [rsp+0x60]
00007cf1741d0c6d  vmovaps xmm7, [rsp+0x70]
00007cf1741d0c73  vmovaps xmm8, [rsp+0x80]
00007cf1741d0c7c  vmovaps xmm9, [rsp+0x90]
00007cf1741d0c85  vmovaps xmm10, [rsp+0xA0]
00007cf1741d0c8e  vmovaps xmm11, [rsp+0xB0]
00007cf1741d0c97  vmovaps xmm12, [rsp+0xC0]
00007cf1741d0ca0  vmovaps xmm14, [rsp+0xD0]
00007cf1741d0ca9  vmovaps xmm15, [rsp+0xE0]
00007cf1741d0cb2  add rsp, 0xF0
00007cf1741d0cb9  pop r11
00007cf1741d0cbb  pop r10
00007cf1741d0cbd  pop r9
00007cf1741d0cbf  pop r8
00007cf1741d0cc1  pop rsi
00007cf1741d0cc2  pop rdi
00007cf1741d0cc3  pop rdx
00007cf1741d0cc4  pop rcx
00007cf1741d0cc5  pop rax
00007cf1741d0cc6  add rsp, 0x08
00007cf1741d0cca  jmp 0x00007CF1741CF64C
00007cf1741d0ccf  sub rsp, 0x08
00007cf1741d0cd3  push rax
00007cf1741d0cd4  push rcx
00007cf1741d0cd5  push rdx
00007cf1741d0cd6  push rdi
00007cf1741d0cd7  push rsi
00007cf1741d0cd8  push r8
00007cf1741d0cda  push r9
00007cf1741d0cdc  push r10
00007cf1741d0cde  push r11
00007cf1741d0ce0  sub rsp, 0xF0
00007cf1741d0ce7  vmovaps [rsp], xmm0
00007cf1741d0cec  vmovaps [rsp+0x10], xmm2
00007cf1741d0cf2  vmovaps [rsp+0x20], xmm3
00007cf1741d0cf8  vmovaps [rsp+0x30], xmm4
00007cf1741d0cfe  vmovaps [rsp+0x40], xmm5
00007cf1741d0d04  vmovaps [rsp+0x50], xmm6
00007cf1741d0d0a  vmovaps [rsp+0x60], xmm7
00007cf1741d0d10  vmovaps [rsp+0x70], xmm8
00007cf1741d0d16  vmovaps [rsp+0x80], xmm9
00007cf1741d0d1f  vmovaps [rsp+0x90], xmm10
00007cf1741d0d28  vmovaps [rsp+0xA0], xmm11
00007cf1741d0d31  vmovaps [rsp+0xB0], xmm12
00007cf1741d0d3a  vmovaps [rsp+0xC0], xmm13
00007cf1741d0d43  vmovaps [rsp+0xD0], xmm14
00007cf1741d0d4c  vmovaps [rsp+0xE0], xmm15
00007cf1741d0d55  sub rsp, 0x30
00007cf1741d0d59  movaps [rsp], xmm1
00007cf1741d0d5d  movaps [rsp+0x10], xmm10
00007cf1741d0d63  movaps [rsp+0x20], xmm2
00007cf1741d0d68  lea rdi, [rsp]
00007cf1741d0d6c  mov esi, 0x00
00007cf1741d0d71  mov rax, 0x611C8A33A530
00007cf1741d0d7b  call rax
00007cf1741d0d7d  movaps xmm1, [rsp]
00007cf1741d0d81  add rsp, 0x30
00007cf1741d0d85  vmovaps xmm0, [rsp]
00007cf1741d0d8a  vmovaps xmm2, [rsp+0x10]
00007cf1741d0d90  vmovaps xmm3, [rsp+0x20]
00007cf1741d0d96  vmovaps xmm4, [rsp+0x30]
00007cf1741d0d9c  vmovaps xmm5, [rsp+0x40]
00007cf1741d0da2  vmovaps xmm6, [rsp+0x50]
00007cf1741d0da8  vmovaps xmm7, [rsp+0x60]
00007cf1741d0dae  vmovaps xmm8, [rsp+0x70]
00007cf1741d0db4  vmovaps xmm9, [rsp+0x80]
00007cf1741d0dbd  vmovaps xmm10, [rsp+0x90]
00007cf1741d0dc6  vmovaps xmm11, [rsp+0xA0]
00007cf1741d0dcf  vmovaps xmm12, [rsp+0xB0]
00007cf1741d0dd8  vmovaps xmm13, [rsp+0xC0]
00007cf1741d0de1  vmovaps xmm14, [rsp+0xD0]
00007cf1741d0dea  vmovaps xmm15, [rsp+0xE0]
00007cf1741d0df3  add rsp, 0xF0
00007cf1741d0dfa  pop r11
00007cf1741d0dfc  pop r10
00007cf1741d0dfe  pop r9
00007cf1741d0e00  pop r8
00007cf1741d0e02  pop rsi
00007cf1741d0e03  pop rdi
00007cf1741d0e04  pop rdx
00007cf1741d0e05  pop rcx
00007cf1741d0e06  pop rax
00007cf1741d0e07  add rsp, 0x08
00007cf1741d0e0b  jmp 0x00007CF1741CF6B4
00007cf1741d0e10  sub rsp, 0x08
00007cf1741d0e14  push rax
00007cf1741d0e15  push rcx
00007cf1741d0e16  push rdx
00007cf1741d0e17  push rdi
00007cf1741d0e18  push rsi
00007cf1741d0e19  push r8
00007cf1741d0e1b  push r9
00007cf1741d0e1d  push r10
00007cf1741d0e1f  push r11
00007cf1741d0e21  sub rsp, 0xF0
00007cf1741d0e28  vmovaps [rsp], xmm0
00007cf1741d0e2d  vmovaps [rsp+0x10], xmm1
00007cf1741d0e33  vmovaps [rsp+0x20], xmm2
00007cf1741d0e39  vmovaps [rsp+0x30], xmm3
00007cf1741d0e3f  vmovaps [rsp+0x40], xmm4
00007cf1741d0e45  vmovaps [rsp+0x50], xmm5
00007cf1741d0e4b  vmovaps [rsp+0x60], xmm6
00007cf1741d0e51  vmovaps [rsp+0x70], xmm7
00007cf1741d0e57  vmovaps [rsp+0x80], xmm8
00007cf1741d0e60  vmovaps [rsp+0x90], xmm9
00007cf1741d0e69  vmovaps [rsp+0xA0], xmm10
00007cf1741d0e72  vmovaps [rsp+0xB0], xmm11
00007cf1741d0e7b  vmovaps [rsp+0xC0], xmm12
00007cf1741d0e84  vmovaps [rsp+0xD0], xmm13
00007cf1741d0e8d  vmovaps [rsp+0xE0], xmm14
00007cf1741d0e96  sub rsp, 0x30
00007cf1741d0e9a  movaps [rsp], xmm15
00007cf1741d0e9f  movaps [rsp+0x10], xmm10
00007cf1741d0ea5  movaps [rsp+0x20], xmm2
00007cf1741d0eaa  lea rdi, [rsp]
00007cf1741d0eae  mov esi, 0x00
00007cf1741d0eb3  mov rax, 0x611C8A33A530
00007cf1741d0ebd  call rax
00007cf1741d0ebf  movaps xmm15, [rsp]
00007cf1741d0ec4  add rsp, 0x30
00007cf1741d0ec8  vmovaps xmm0, [rsp]
00007cf1741d0ecd  vmovaps xmm1, [rsp+0x10]
00007cf1741d0ed3  vmovaps xmm2, [rsp+0x20]
00007cf1741d0ed9  vmovaps xmm3, [rsp+0x30]
00007cf1741d0edf  vmovaps xmm4, [rsp+0x40]
00007cf1741d0ee5  vmovaps xmm5, [rsp+0x50]
00007cf1741d0eeb  vmovaps xmm6, [rsp+0x60]
00007cf1741d0ef1  vmovaps xmm7, [rsp+0x70]
00007cf1741d0ef7  vmovaps xmm8, [rsp+0x80]
00007cf1741d0f00  vmovaps xmm9, [rsp+0x90]
00007cf1741d0f09  vmovaps xmm10, [rsp+0xA0]
00007cf1741d0f12  vmovaps xmm11, [rsp+0xB0]
00007cf1741d0f1b  vmovaps xmm12, [rsp+0xC0]
00007cf1741d0f24  vmovaps xmm13, [rsp+0xD0]
00007cf1741d0f2d  vmovaps xmm14, [rsp+0xE0]
00007cf1741d0f36  add rsp, 0xF0
00007cf1741d0f3d  pop r11
00007cf1741d0f3f  pop r10
00007cf1741d0f41  pop r9
00007cf1741d0f43  pop r8
00007cf1741d0f45  pop rsi
00007cf1741d0f46  pop rdi
00007cf1741d0f47  pop rdx
00007cf1741d0f48  pop rcx
00007cf1741d0f49  pop rax
00007cf1741d0f4a  add rsp, 0x08
00007cf1741d0f4e  jmp 0x00007CF1741CF706
00007cf1741d0f53  sub rsp, 0x08
00007cf1741d0f57  push rax
00007cf1741d0f58  push rcx
00007cf1741d0f59  push rdx
00007cf1741d0f5a  push rdi
00007cf1741d0f5b  push rsi
00007cf1741d0f5c  push r8
00007cf1741d0f5e  push r9
00007cf1741d0f60  push r10
00007cf1741d0f62  push r11
00007cf1741d0f64  sub rsp, 0xF0
00007cf1741d0f6b  vmovaps [rsp], xmm0
00007cf1741d0f70  vmovaps [rsp+0x10], xmm2
00007cf1741d0f76  vmovaps [rsp+0x20], xmm3
00007cf1741d0f7c  vmovaps [rsp+0x30], xmm4
00007cf1741d0f82  vmovaps [rsp+0x40], xmm5
00007cf1741d0f88  vmovaps [rsp+0x50], xmm6
00007cf1741d0f8e  vmovaps [rsp+0x60], xmm7
00007cf1741d0f94  vmovaps [rsp+0x70], xmm8
00007cf1741d0f9a  vmovaps [rsp+0x80], xmm9
00007cf1741d0fa3  vmovaps [rsp+0x90], xmm10
00007cf1741d0fac  vmovaps [rsp+0xA0], xmm11
00007cf1741d0fb5  vmovaps [rsp+0xB0], xmm12
00007cf1741d0fbe  vmovaps [rsp+0xC0], xmm13
00007cf1741d0fc7  vmovaps [rsp+0xD0], xmm14
00007cf1741d0fd0  vmovaps [rsp+0xE0], xmm15
00007cf1741d0fd9  sub rsp, 0x30
00007cf1741d0fdd  movaps [rsp], xmm1
00007cf1741d0fe1  movaps [rsp+0x10], xmm10
00007cf1741d0fe7  movaps [rsp+0x20], xmm12
00007cf1741d0fed  lea rdi, [rsp]
00007cf1741d0ff1  mov esi, 0x00
00007cf1741d0ff6  mov rax, 0x611C8A33A530
00007cf1741d1000  call rax
00007cf1741d1002  movaps xmm1, [rsp]
00007cf1741d1006  add rsp, 0x30
00007cf1741d100a  vmovaps xmm0, [rsp]
00007cf1741d100f  vmovaps xmm2, [rsp+0x10]
00007cf1741d1015  vmovaps xmm3, [rsp+0x20]
00007cf1741d101b  vmovaps xmm4, [rsp+0x30]
00007cf1741d1021  vmovaps xmm5, [rsp+0x40]
00007cf1741d1027  vmovaps xmm6, [rsp+0x50]
00007cf1741d102d  vmovaps xmm7, [rsp+0x60]
00007cf1741d1033  vmovaps xmm8, [rsp+0x70]
00007cf1741d1039  vmovaps xmm9, [rsp+0x80]
00007cf1741d1042  vmovaps xmm10, [rsp+0x90]
00007cf1741d104b  vmovaps xmm11, [rsp+0xA0]
00007cf1741d1054  vmovaps xmm12, [rsp+0xB0]
00007cf1741d105d  vmovaps xmm13, [rsp+0xC0]
00007cf1741d1066  vmovaps xmm14, [rsp+0xD0]
00007cf1741d106f  vmovaps xmm15, [rsp+0xE0]
00007cf1741d1078  add rsp, 0xF0
00007cf1741d107f  pop r11
00007cf1741d1081  pop r10
00007cf1741d1083  pop r9
00007cf1741d1085  pop r8
00007cf1741d1087  pop rsi
00007cf1741d1088  pop rdi
00007cf1741d1089  pop rdx
00007cf1741d108a  pop rcx
00007cf1741d108b  pop rax
00007cf1741d108c  add rsp, 0x08
00007cf1741d1090  jmp 0x00007CF1741CF732
00007cf1741d1095  sub rsp, 0x08
00007cf1741d1099  push rax
00007cf1741d109a  push rcx
00007cf1741d109b  push rdx
00007cf1741d109c  push rdi
00007cf1741d109d  push rsi
00007cf1741d109e  push r8
00007cf1741d10a0  push r9
00007cf1741d10a2  push r10
00007cf1741d10a4  push r11
00007cf1741d10a6  sub rsp, 0xF0
00007cf1741d10ad  vmovaps [rsp], xmm0
00007cf1741d10b2  vmovaps [rsp+0x10], xmm1
00007cf1741d10b8  vmovaps [rsp+0x20], xmm2
00007cf1741d10be  vmovaps [rsp+0x30], xmm3
00007cf1741d10c4  vmovaps [rsp+0x40], xmm4
00007cf1741d10ca  vmovaps [rsp+0x50], xmm5
00007cf1741d10d0  vmovaps [rsp+0x60], xmm6
00007cf1741d10d6  vmovaps [rsp+0x70], xmm7
00007cf1741d10dc  vmovaps [rsp+0x80], xmm8
00007cf1741d10e5  vmovaps [rsp+0x90], xmm9
00007cf1741d10ee  vmovaps [rsp+0xA0], xmm10
00007cf1741d10f7  vmovaps [rsp+0xB0], xmm11
00007cf1741d1100  vmovaps [rsp+0xC0], xmm12
00007cf1741d1109  vmovaps [rsp+0xD0], xmm13
00007cf1741d1112  vmovaps [rsp+0xE0], xmm14
00007cf1741d111b  sub rsp, 0x30
00007cf1741d111f  movaps [rsp], xmm15
00007cf1741d1124  movaps [rsp+0x10], xmm10
00007cf1741d112a  movaps [rsp+0x20], xmm12
00007cf1741d1130  lea rdi, [rsp]
00007cf1741d1134  mov esi, 0x00
00007cf1741d1139  mov rax, 0x611C8A33A530
00007cf1741d1143  call rax
00007cf1741d1145  movaps xmm15, [rsp]
00007cf1741d114a  add rsp, 0x30
00007cf1741d114e  vmovaps xmm0, [rsp]
00007cf1741d1153  vmovaps xmm1, [rsp+0x10]
00007cf1741d1159  vmovaps xmm2, [rsp+0x20]
00007cf1741d115f  vmovaps xmm3, [rsp+0x30]
00007cf1741d1165  vmovaps xmm4, [rsp+0x40]
00007cf1741d116b  vmovaps xmm5, [rsp+0x50]
00007cf1741d1171  vmovaps xmm6, [rsp+0x60]
00007cf1741d1177  vmovaps xmm7, [rsp+0x70]
00007cf1741d117d  vmovaps xmm8, [rsp+0x80]
00007cf1741d1186  vmovaps xmm9, [rsp+0x90]
00007cf1741d118f  vmovaps xmm10, [rsp+0xA0]
00007cf1741d1198  vmovaps xmm11, [rsp+0xB0]
00007cf1741d11a1  vmovaps xmm12, [rsp+0xC0]
00007cf1741d11aa  vmovaps xmm13, [rsp+0xD0]
00007cf1741d11b3  vmovaps xmm14, [rsp+0xE0]
00007cf1741d11bc  add rsp, 0xF0
00007cf1741d11c3  pop r11
00007cf1741d11c5  pop r10
00007cf1741d11c7  pop r9
00007cf1741d11c9  pop r8
00007cf1741d11cb  pop rsi
00007cf1741d11cc  pop rdi
00007cf1741d11cd  pop rdx
00007cf1741d11ce  pop rcx
00007cf1741d11cf  pop rax
00007cf1741d11d0  add rsp, 0x08
00007cf1741d11d4  jmp 0x00007CF1741CF75E
00007cf1741d11d9  call 0x00007CF173FFF430
00007cf1741d11de  jmp 0x00007CF1741CF7EE
00007cf1741d11e3  call 0x00007CF173FFF430
00007cf1741d11e8  jmp 0x00007CF1741CF801
00007cf1741d11ed  sub rsp, 0x08
00007cf1741d11f1  push rax
00007cf1741d11f2  push rcx
00007cf1741d11f3  push rdx
00007cf1741d11f4  push rdi
00007cf1741d11f5  push rsi
00007cf1741d11f6  push r8
00007cf1741d11f8  push r9
00007cf1741d11fa  push r10
00007cf1741d11fc  push r11
00007cf1741d11fe  sub rsp, 0xF0
00007cf1741d1205  vmovaps [rsp], xmm0
00007cf1741d120a  vmovaps [rsp+0x10], xmm2
00007cf1741d1210  vmovaps [rsp+0x20], xmm3
00007cf1741d1216  vmovaps [rsp+0x30], xmm4
00007cf1741d121c  vmovaps [rsp+0x40], xmm5
00007cf1741d1222  vmovaps [rsp+0x50], xmm6
00007cf1741d1228  vmovaps [rsp+0x60], xmm7
00007cf1741d122e  vmovaps [rsp+0x70], xmm8
00007cf1741d1234  vmovaps [rsp+0x80], xmm9
00007cf1741d123d  vmovaps [rsp+0x90], xmm10
00007cf1741d1246  vmovaps [rsp+0xA0], xmm11
00007cf1741d124f  vmovaps [rsp+0xB0], xmm12
00007cf1741d1258  vmovaps [rsp+0xC0], xmm13
00007cf1741d1261  vmovaps [rsp+0xD0], xmm14
00007cf1741d126a  vmovaps [rsp+0xE0], xmm15
00007cf1741d1273  sub rsp, 0x30
00007cf1741d1277  movaps [rsp], xmm1
00007cf1741d127b  movaps [rsp+0x10], xmm13
00007cf1741d1281  movaps [rsp+0x20], xmm2
00007cf1741d1286  lea rdi, [rsp]
00007cf1741d128a  mov esi, 0x00
00007cf1741d128f  mov rax, 0x611C8A33A530
00007cf1741d1299  call rax
00007cf1741d129b  movaps xmm1, [rsp]
00007cf1741d129f  add rsp, 0x30
00007cf1741d12a3  vmovaps xmm0, [rsp]
00007cf1741d12a8  vmovaps xmm2, [rsp+0x10]
00007cf1741d12ae  vmovaps xmm3, [rsp+0x20]
00007cf1741d12b4  vmovaps xmm4, [rsp+0x30]
00007cf1741d12ba  vmovaps xmm5, [rsp+0x40]
00007cf1741d12c0  vmovaps xmm6, [rsp+0x50]
00007cf1741d12c6  vmovaps xmm7, [rsp+0x60]
00007cf1741d12cc  vmovaps xmm8, [rsp+0x70]
00007cf1741d12d2  vmovaps xmm9, [rsp+0x80]
00007cf1741d12db  vmovaps xmm10, [rsp+0x90]
00007cf1741d12e4  vmovaps xmm11, [rsp+0xA0]
00007cf1741d12ed  vmovaps xmm12, [rsp+0xB0]
00007cf1741d12f6  vmovaps xmm13, [rsp+0xC0]
00007cf1741d12ff  vmovaps xmm14, [rsp+0xD0]
00007cf1741d1308  vmovaps xmm15, [rsp+0xE0]
00007cf1741d1311  add rsp, 0xF0
00007cf1741d1318  pop r11
00007cf1741d131a  pop r10
00007cf1741d131c  pop r9
00007cf1741d131e  pop r8
00007cf1741d1320  pop rsi
00007cf1741d1321  pop rdi
00007cf1741d1322  pop rdx
00007cf1741d1323  pop rcx
00007cf1741d1324  pop rax
00007cf1741d1325  add rsp, 0x08
00007cf1741d1329  jmp 0x00007CF1741CF82C
00007cf1741d132e  call 0x00007CF17400E760
00007cf1741d1333  jmp 0x00007CF1741CF839
00007cf1741d1338  sub rsp, 0x08
00007cf1741d133c  push rax
00007cf1741d133d  push rcx
00007cf1741d133e  push rdx
00007cf1741d133f  push rdi
00007cf1741d1340  push rsi
00007cf1741d1341  push r8
00007cf1741d1343  push r9
00007cf1741d1345  push r10
00007cf1741d1347  push r11
00007cf1741d1349  sub rsp, 0xF0
00007cf1741d1350  vmovaps [rsp], xmm0
00007cf1741d1355  vmovaps [rsp+0x10], xmm1
00007cf1741d135b  vmovaps [rsp+0x20], xmm2
00007cf1741d1361  vmovaps [rsp+0x30], xmm3
00007cf1741d1367  vmovaps [rsp+0x40], xmm4
00007cf1741d136d  vmovaps [rsp+0x50], xmm5
00007cf1741d1373  vmovaps [rsp+0x60], xmm6
00007cf1741d1379  vmovaps [rsp+0x70], xmm7
00007cf1741d137f  vmovaps [rsp+0x80], xmm8
00007cf1741d1388  vmovaps [rsp+0x90], xmm9
00007cf1741d1391  vmovaps [rsp+0xA0], xmm10
00007cf1741d139a  vmovaps [rsp+0xB0], xmm11
00007cf1741d13a3  vmovaps [rsp+0xC0], xmm12
00007cf1741d13ac  vmovaps [rsp+0xD0], xmm14
00007cf1741d13b5  vmovaps [rsp+0xE0], xmm15
00007cf1741d13be  sub rsp, 0x30
00007cf1741d13c2  movaps [rsp], xmm13
00007cf1741d13c7  movaps [rsp+0x10], xmm2
00007cf1741d13cc  movaps [rsp+0x20], xmm1
00007cf1741d13d1  lea rdi, [rsp]
00007cf1741d13d5  mov esi, 0x00
00007cf1741d13da  mov rax, 0x611C8A33A530
00007cf1741d13e4  call rax
00007cf1741d13e6  movaps xmm13, [rsp]
00007cf1741d13eb  add rsp, 0x30
00007cf1741d13ef  vmovaps xmm0, [rsp]
00007cf1741d13f4  vmovaps xmm1, [rsp+0x10]
00007cf1741d13fa  vmovaps xmm2, [rsp+0x20]
00007cf1741d1400  vmovaps xmm3, [rsp+0x30]
00007cf1741d1406  vmovaps xmm4, [rsp+0x40]
00007cf1741d140c  vmovaps xmm5, [rsp+0x50]
00007cf1741d1412  vmovaps xmm6, [rsp+0x60]
00007cf1741d1418  vmovaps xmm7, [rsp+0x70]
00007cf1741d141e  vmovaps xmm8, [rsp+0x80]
00007cf1741d1427  vmovaps xmm9, [rsp+0x90]
00007cf1741d1430  vmovaps xmm10, [rsp+0xA0]
00007cf1741d1439  vmovaps xmm11, [rsp+0xB0]
00007cf1741d1442  vmovaps xmm12, [rsp+0xC0]
00007cf1741d144b  vmovaps xmm14, [rsp+0xD0]
00007cf1741d1454  vmovaps xmm15, [rsp+0xE0]
00007cf1741d145d  add rsp, 0xF0
00007cf1741d1464  pop r11
00007cf1741d1466  pop r10
00007cf1741d1468  pop r9
00007cf1741d146a  pop r8
00007cf1741d146c  pop rsi
00007cf1741d146d  pop rdi
00007cf1741d146e  pop rdx
00007cf1741d146f  pop rcx
00007cf1741d1470  pop rax
00007cf1741d1471  add rsp, 0x08
00007cf1741d1475  jmp 0x00007CF1741CF878
00007cf1741d147a  sub rsp, 0x08
00007cf1741d147e  push rax
00007cf1741d147f  push rcx
00007cf1741d1480  push rdx
00007cf1741d1481  push rdi
00007cf1741d1482  push rsi
00007cf1741d1483  push r8
00007cf1741d1485  push r9
00007cf1741d1487  push r10
00007cf1741d1489  push r11
00007cf1741d148b  sub rsp, 0xF0
00007cf1741d1492  vmovaps [rsp], xmm0
00007cf1741d1497  vmovaps [rsp+0x10], xmm2
00007cf1741d149d  vmovaps [rsp+0x20], xmm3
00007cf1741d14a3  vmovaps [rsp+0x30], xmm4
00007cf1741d14a9  vmovaps [rsp+0x40], xmm5
00007cf1741d14af  vmovaps [rsp+0x50], xmm6
00007cf1741d14b5  vmovaps [rsp+0x60], xmm7
00007cf1741d14bb  vmovaps [rsp+0x70], xmm8
00007cf1741d14c1  vmovaps [rsp+0x80], xmm9
00007cf1741d14ca  vmovaps [rsp+0x90], xmm10
00007cf1741d14d3  vmovaps [rsp+0xA0], xmm11
00007cf1741d14dc  vmovaps [rsp+0xB0], xmm12
00007cf1741d14e5  vmovaps [rsp+0xC0], xmm13
00007cf1741d14ee  vmovaps [rsp+0xD0], xmm14
00007cf1741d14f7  vmovaps [rsp+0xE0], xmm15
00007cf1741d1500  sub rsp, 0x30
00007cf1741d1504  movaps [rsp], xmm1
00007cf1741d1508  movaps [rsp+0x10], xmm15
00007cf1741d150e  movaps [rsp+0x20], xmm2
00007cf1741d1513  lea rdi, [rsp]
00007cf1741d1517  mov esi, 0x00
00007cf1741d151c  mov rax, 0x611C8A33A530
00007cf1741d1526  call rax
00007cf1741d1528  movaps xmm1, [rsp]
00007cf1741d152c  add rsp, 0x30
00007cf1741d1530  vmovaps xmm0, [rsp]
00007cf1741d1535  vmovaps xmm2, [rsp+0x10]
00007cf1741d153b  vmovaps xmm3, [rsp+0x20]
00007cf1741d1541  vmovaps xmm4, [rsp+0x30]
00007cf1741d1547  vmovaps xmm5, [rsp+0x40]
00007cf1741d154d  vmovaps xmm6, [rsp+0x50]
00007cf1741d1553  vmovaps xmm7, [rsp+0x60]
00007cf1741d1559  vmovaps xmm8, [rsp+0x70]
00007cf1741d155f  vmovaps xmm9, [rsp+0x80]
00007cf1741d1568  vmovaps xmm10, [rsp+0x90]
00007cf1741d1571  vmovaps xmm11, [rsp+0xA0]
00007cf1741d157a  vmovaps xmm12, [rsp+0xB0]
00007cf1741d1583  vmovaps xmm13, [rsp+0xC0]
00007cf1741d158c  vmovaps xmm14, [rsp+0xD0]
00007cf1741d1595  vmovaps xmm15, [rsp+0xE0]
00007cf1741d159e  add rsp, 0xF0
00007cf1741d15a5  pop r11
00007cf1741d15a7  pop r10
00007cf1741d15a9  pop r9
00007cf1741d15ab  pop r8
00007cf1741d15ad  pop rsi
00007cf1741d15ae  pop rdi
00007cf1741d15af  pop rdx
00007cf1741d15b0  pop rcx
00007cf1741d15b1  pop rax
00007cf1741d15b2  add rsp, 0x08
00007cf1741d15b6  jmp 0x00007CF1741CF8AC
00007cf1741d15bb  sub rsp, 0x08
00007cf1741d15bf  push rax
00007cf1741d15c0  push rcx
00007cf1741d15c1  push rdx
00007cf1741d15c2  push rdi
00007cf1741d15c3  push rsi
00007cf1741d15c4  push r8
00007cf1741d15c6  push r9
00007cf1741d15c8  push r10
00007cf1741d15ca  push r11
00007cf1741d15cc  sub rsp, 0xF0
00007cf1741d15d3  vmovaps [rsp], xmm0
00007cf1741d15d8  vmovaps [rsp+0x10], xmm1
00007cf1741d15de  vmovaps [rsp+0x20], xmm2
00007cf1741d15e4  vmovaps [rsp+0x30], xmm3
00007cf1741d15ea  vmovaps [rsp+0x40], xmm4
00007cf1741d15f0  vmovaps [rsp+0x50], xmm5
00007cf1741d15f6  vmovaps [rsp+0x60], xmm6
00007cf1741d15fc  vmovaps [rsp+0x70], xmm7
00007cf1741d1602  vmovaps [rsp+0x80], xmm8
00007cf1741d160b  vmovaps [rsp+0x90], xmm9
00007cf1741d1614  vmovaps [rsp+0xA0], xmm10
00007cf1741d161d  vmovaps [rsp+0xB0], xmm11
00007cf1741d1626  vmovaps [rsp+0xC0], xmm12
00007cf1741d162f  vmovaps [rsp+0xD0], xmm13
00007cf1741d1638  vmovaps [rsp+0xE0], xmm15
00007cf1741d1641  sub rsp, 0x30
00007cf1741d1645  movaps [rsp], xmm14
00007cf1741d164a  movaps [rsp+0x10], xmm2
00007cf1741d164f  movaps [rsp+0x20], xmm15
00007cf1741d1655  lea rdi, [rsp]
00007cf1741d1659  mov esi, 0x00
00007cf1741d165e  mov rax, 0x611C8A33A530
00007cf1741d1668  call rax
00007cf1741d166a  movaps xmm14, [rsp]
00007cf1741d166f  add rsp, 0x30
00007cf1741d1673  vmovaps xmm0, [rsp]
00007cf1741d1678  vmovaps xmm1, [rsp+0x10]
00007cf1741d167e  vmovaps xmm2, [rsp+0x20]
00007cf1741d1684  vmovaps xmm3, [rsp+0x30]
00007cf1741d168a  vmovaps xmm4, [rsp+0x40]
00007cf1741d1690  vmovaps xmm5, [rsp+0x50]
00007cf1741d1696  vmovaps xmm6, [rsp+0x60]
00007cf1741d169c  vmovaps xmm7, [rsp+0x70]
00007cf1741d16a2  vmovaps xmm8, [rsp+0x80]
00007cf1741d16ab  vmovaps xmm9, [rsp+0x90]
00007cf1741d16b4  vmovaps xmm10, [rsp+0xA0]
00007cf1741d16bd  vmovaps xmm11, [rsp+0xB0]
00007cf1741d16c6  vmovaps xmm12, [rsp+0xC0]
00007cf1741d16cf  vmovaps xmm13, [rsp+0xD0]
00007cf1741d16d8  vmovaps xmm15, [rsp+0xE0]
00007cf1741d16e1  add rsp, 0xF0
00007cf1741d16e8  pop r11
00007cf1741d16ea  pop r10
00007cf1741d16ec  pop r9
00007cf1741d16ee  pop r8
00007cf1741d16f0  pop rsi
00007cf1741d16f1  pop rdi
00007cf1741d16f2  pop rdx
00007cf1741d16f3  pop rcx
00007cf1741d16f4  pop rax
00007cf1741d16f5  add rsp, 0x08
00007cf1741d16f9  jmp 0x00007CF1741CF8E7
00007cf1741d16fe  sub rsp, 0x08
00007cf1741d1702  push rax
00007cf1741d1703  push rcx
00007cf1741d1704  push rdx
00007cf1741d1705  push rdi
00007cf1741d1706  push rsi
00007cf1741d1707  push r8
00007cf1741d1709  push r9
00007cf1741d170b  push r10
00007cf1741d170d  push r11
00007cf1741d170f  sub rsp, 0xF0
00007cf1741d1716  vmovaps [rsp], xmm0
00007cf1741d171b  vmovaps [rsp+0x10], xmm1
00007cf1741d1721  vmovaps [rsp+0x20], xmm2
00007cf1741d1727  vmovaps [rsp+0x30], xmm3
00007cf1741d172d  vmovaps [rsp+0x40], xmm4
00007cf1741d1733  vmovaps [rsp+0x50], xmm5
00007cf1741d1739  vmovaps [rsp+0x60], xmm6
00007cf1741d173f  vmovaps [rsp+0x70], xmm7
00007cf1741d1745  vmovaps [rsp+0x80], xmm8
00007cf1741d174e  vmovaps [rsp+0x90], xmm9
00007cf1741d1757  vmovaps [rsp+0xA0], xmm10
00007cf1741d1760  vmovaps [rsp+0xB0], xmm11
00007cf1741d1769  vmovaps [rsp+0xC0], xmm12
00007cf1741d1772  vmovaps [rsp+0xD0], xmm13
00007cf1741d177b  vmovaps [rsp+0xE0], xmm14
00007cf1741d1784  sub rsp, 0x30
00007cf1741d1788  movaps [rsp], xmm15
00007cf1741d178d  movaps [rsp+0x10], xmm2
00007cf1741d1792  movaps [rsp+0x20], xmm1
00007cf1741d1797  lea rdi, [rsp]
00007cf1741d179b  mov esi, 0x00
00007cf1741d17a0  mov rax, 0x611C8A33A530
00007cf1741d17aa  call rax
00007cf1741d17ac  movaps xmm15, [rsp]
00007cf1741d17b1  add rsp, 0x30
00007cf1741d17b5  vmovaps xmm0, [rsp]
00007cf1741d17ba  vmovaps xmm1, [rsp+0x10]
00007cf1741d17c0  vmovaps xmm2, [rsp+0x20]
00007cf1741d17c6  vmovaps xmm3, [rsp+0x30]
00007cf1741d17cc  vmovaps xmm4, [rsp+0x40]
00007cf1741d17d2  vmovaps xmm5, [rsp+0x50]
00007cf1741d17d8  vmovaps xmm6, [rsp+0x60]
00007cf1741d17de  vmovaps xmm7, [rsp+0x70]
00007cf1741d17e4  vmovaps xmm8, [rsp+0x80]
00007cf1741d17ed  vmovaps xmm9, [rsp+0x90]
00007cf1741d17f6  vmovaps xmm10, [rsp+0xA0]
00007cf1741d17ff  vmovaps xmm11, [rsp+0xB0]
00007cf1741d1808  vmovaps xmm12, [rsp+0xC0]
00007cf1741d1811  vmovaps xmm13, [rsp+0xD0]
00007cf1741d181a  vmovaps xmm14, [rsp+0xE0]
00007cf1741d1823  add rsp, 0xF0
00007cf1741d182a  pop r11
00007cf1741d182c  pop r10
00007cf1741d182e  pop r9
00007cf1741d1830  pop r8
00007cf1741d1832  pop rsi
00007cf1741d1833  pop rdi
00007cf1741d1834  pop rdx
00007cf1741d1835  pop rcx
00007cf1741d1836  pop rax
00007cf1741d1837  add rsp, 0x08
00007cf1741d183b  jmp 0x00007CF1741CF923
00007cf1741d1840  call 0x00007CF173FFF430
00007cf1741d1845  jmp 0x00007CF1741CF930
00007cf1741d184a  sub rsp, 0x08
00007cf1741d184e  push rax
00007cf1741d184f  push rcx
00007cf1741d1850  push rdx
00007cf1741d1851  push rdi
00007cf1741d1852  push rsi
00007cf1741d1853  push r8
00007cf1741d1855  push r9
00007cf1741d1857  push r10
00007cf1741d1859  push r11
00007cf1741d185b  sub rsp, 0xF0
00007cf1741d1862  vmovaps [rsp], xmm0
00007cf1741d1867  vmovaps [rsp+0x10], xmm1
00007cf1741d186d  vmovaps [rsp+0x20], xmm3
00007cf1741d1873  vmovaps [rsp+0x30], xmm4
00007cf1741d1879  vmovaps [rsp+0x40], xmm5
00007cf1741d187f  vmovaps [rsp+0x50], xmm6
00007cf1741d1885  vmovaps [rsp+0x60], xmm7
00007cf1741d188b  vmovaps [rsp+0x70], xmm8
00007cf1741d1891  vmovaps [rsp+0x80], xmm9
00007cf1741d189a  vmovaps [rsp+0x90], xmm10
00007cf1741d18a3  vmovaps [rsp+0xA0], xmm11
00007cf1741d18ac  vmovaps [rsp+0xB0], xmm12
00007cf1741d18b5  vmovaps [rsp+0xC0], xmm13
00007cf1741d18be  vmovaps [rsp+0xD0], xmm14
00007cf1741d18c7  vmovaps [rsp+0xE0], xmm15
00007cf1741d18d0  sub rsp, 0x30
00007cf1741d18d4  movaps [rsp], xmm2
00007cf1741d18d8  movaps [rsp+0x10], xmm1
00007cf1741d18dd  movaps [rsp+0x20], xmm14
00007cf1741d18e3  lea rdi, [rsp]
00007cf1741d18e7  mov esi, 0x00
00007cf1741d18ec  mov rax, 0x611C8A33A530
00007cf1741d18f6  call rax
00007cf1741d18f8  movaps xmm2, [rsp]
00007cf1741d18fc  add rsp, 0x30
00007cf1741d1900  vmovaps xmm0, [rsp]
00007cf1741d1905  vmovaps xmm1, [rsp+0x10]
00007cf1741d190b  vmovaps xmm3, [rsp+0x20]
00007cf1741d1911  vmovaps xmm4, [rsp+0x30]
00007cf1741d1917  vmovaps xmm5, [rsp+0x40]
00007cf1741d191d  vmovaps xmm6, [rsp+0x50]
00007cf1741d1923  vmovaps xmm7, [rsp+0x60]
00007cf1741d1929  vmovaps xmm8, [rsp+0x70]
00007cf1741d192f  vmovaps xmm9, [rsp+0x80]
00007cf1741d1938  vmovaps xmm10, [rsp+0x90]
00007cf1741d1941  vmovaps xmm11, [rsp+0xA0]
00007cf1741d194a  vmovaps xmm12, [rsp+0xB0]
00007cf1741d1953  vmovaps xmm13, [rsp+0xC0]
00007cf1741d195c  vmovaps xmm14, [rsp+0xD0]
00007cf1741d1965  vmovaps xmm15, [rsp+0xE0]
00007cf1741d196e  add rsp, 0xF0
00007cf1741d1975  pop r11
00007cf1741d1977  pop r10
00007cf1741d1979  pop r9
00007cf1741d197b  pop r8
00007cf1741d197d  pop rsi
00007cf1741d197e  pop rdi
00007cf1741d197f  pop rdx
00007cf1741d1980  pop rcx
00007cf1741d1981  pop rax
00007cf1741d1982  add rsp, 0x08
00007cf1741d1986  jmp 0x00007CF1741CF96D
00007cf1741d198b  sub rsp, 0x08
00007cf1741d198f  push rax
00007cf1741d1990  push rcx
00007cf1741d1991  push rdx
00007cf1741d1992  push rdi
00007cf1741d1993  push rsi
00007cf1741d1994  push r8
00007cf1741d1996  push r9
00007cf1741d1998  push r10
00007cf1741d199a  push r11
00007cf1741d199c  sub rsp, 0xF0
00007cf1741d19a3  vmovaps [rsp], xmm0
00007cf1741d19a8  vmovaps [rsp+0x10], xmm1
00007cf1741d19ae  vmovaps [rsp+0x20], xmm2
00007cf1741d19b4  vmovaps [rsp+0x30], xmm3
00007cf1741d19ba  vmovaps [rsp+0x40], xmm4
00007cf1741d19c0  vmovaps [rsp+0x50], xmm5
00007cf1741d19c6  vmovaps [rsp+0x60], xmm6
00007cf1741d19cc  vmovaps [rsp+0x70], xmm7
00007cf1741d19d2  vmovaps [rsp+0x80], xmm8
00007cf1741d19db  vmovaps [rsp+0x90], xmm9
00007cf1741d19e4  vmovaps [rsp+0xA0], xmm10
00007cf1741d19ed  vmovaps [rsp+0xB0], xmm11
00007cf1741d19f6  vmovaps [rsp+0xC0], xmm12
00007cf1741d19ff  vmovaps [rsp+0xD0], xmm13
00007cf1741d1a08  vmovaps [rsp+0xE0], xmm14
00007cf1741d1a11  sub rsp, 0x30
00007cf1741d1a15  movaps [rsp], xmm15
00007cf1741d1a1a  movaps [rsp+0x10], xmm14
00007cf1741d1a20  movaps [rsp+0x20], xmm1
00007cf1741d1a25  lea rdi, [rsp]
00007cf1741d1a29  mov esi, 0x00
00007cf1741d1a2e  mov rax, 0x611C8A33A530
00007cf1741d1a38  call rax
00007cf1741d1a3a  movaps xmm15, [rsp]
00007cf1741d1a3f  add rsp, 0x30
00007cf1741d1a43  vmovaps xmm0, [rsp]
00007cf1741d1a48  vmovaps xmm1, [rsp+0x10]
00007cf1741d1a4e  vmovaps xmm2, [rsp+0x20]
00007cf1741d1a54  vmovaps xmm3, [rsp+0x30]
00007cf1741d1a5a  vmovaps xmm4, [rsp+0x40]
00007cf1741d1a60  vmovaps xmm5, [rsp+0x50]
00007cf1741d1a66  vmovaps xmm6, [rsp+0x60]
00007cf1741d1a6c  vmovaps xmm7, [rsp+0x70]
00007cf1741d1a72  vmovaps xmm8, [rsp+0x80]
00007cf1741d1a7b  vmovaps xmm9, [rsp+0x90]
00007cf1741d1a84  vmovaps xmm10, [rsp+0xA0]
00007cf1741d1a8d  vmovaps xmm11, [rsp+0xB0]
00007cf1741d1a96  vmovaps xmm12, [rsp+0xC0]
00007cf1741d1a9f  vmovaps xmm13, [rsp+0xD0]
00007cf1741d1aa8  vmovaps xmm14, [rsp+0xE0]
00007cf1741d1ab1  add rsp, 0xF0
00007cf1741d1ab8  pop r11
00007cf1741d1aba  pop r10
00007cf1741d1abc  pop r9
00007cf1741d1abe  pop r8
00007cf1741d1ac0  pop rsi
00007cf1741d1ac1  pop rdi
00007cf1741d1ac2  pop rdx
00007cf1741d1ac3  pop rcx
00007cf1741d1ac4  pop rax
00007cf1741d1ac5  add rsp, 0x08
00007cf1741d1ac9  jmp 0x00007CF1741CF9E7
00007cf1741d1ace  call 0x00007CF173FFF430
00007cf1741d1ad3  jmp 0x00007CF1741CF9F4
00007cf1741d1ad8  sub rsp, 0x08
00007cf1741d1adc  push rax
00007cf1741d1add  push rcx
00007cf1741d1ade  push rdx
00007cf1741d1adf  push rdi
00007cf1741d1ae0  push rsi
00007cf1741d1ae1  push r8
00007cf1741d1ae3  push r9
00007cf1741d1ae5  push r10
00007cf1741d1ae7  push r11
00007cf1741d1ae9  sub rsp, 0xF0
00007cf1741d1af0  vmovaps [rsp], xmm0
00007cf1741d1af5  vmovaps [rsp+0x10], xmm1
00007cf1741d1afb  vmovaps [rsp+0x20], xmm2
00007cf1741d1b01  vmovaps [rsp+0x30], xmm3
00007cf1741d1b07  vmovaps [rsp+0x40], xmm4
00007cf1741d1b0d  vmovaps [rsp+0x50], xmm5
00007cf1741d1b13  vmovaps [rsp+0x60], xmm6
00007cf1741d1b19  vmovaps [rsp+0x70], xmm7
00007cf1741d1b1f  vmovaps [rsp+0x80], xmm8
00007cf1741d1b28  vmovaps [rsp+0x90], xmm9
00007cf1741d1b31  vmovaps [rsp+0xA0], xmm10
00007cf1741d1b3a  vmovaps [rsp+0xB0], xmm11
00007cf1741d1b43  vmovaps [rsp+0xC0], xmm12
00007cf1741d1b4c  vmovaps [rsp+0xD0], xmm13
00007cf1741d1b55  vmovaps [rsp+0xE0], xmm15
00007cf1741d1b5e  sub rsp, 0x30
00007cf1741d1b62  movaps [rsp], xmm14
00007cf1741d1b67  movaps [rsp+0x10], xmm13
00007cf1741d1b6d  movaps [rsp+0x20], xmm1
00007cf1741d1b72  lea rdi, [rsp]
00007cf1741d1b76  mov esi, 0x00
00007cf1741d1b7b  mov rax, 0x611C8A33A530
00007cf1741d1b85  call rax
00007cf1741d1b87  movaps xmm14, [rsp]
00007cf1741d1b8c  add rsp, 0x30
00007cf1741d1b90  vmovaps xmm0, [rsp]
00007cf1741d1b95  vmovaps xmm1, [rsp+0x10]
00007cf1741d1b9b  vmovaps xmm2, [rsp+0x20]
00007cf1741d1ba1  vmovaps xmm3, [rsp+0x30]
00007cf1741d1ba7  vmovaps xmm4, [rsp+0x40]
00007cf1741d1bad  vmovaps xmm5, [rsp+0x50]
00007cf1741d1bb3  vmovaps xmm6, [rsp+0x60]
00007cf1741d1bb9  vmovaps xmm7, [rsp+0x70]
00007cf1741d1bbf  vmovaps xmm8, [rsp+0x80]
00007cf1741d1bc8  vmovaps xmm9, [rsp+0x90]
00007cf1741d1bd1  vmovaps xmm10, [rsp+0xA0]
00007cf1741d1bda  vmovaps xmm11, [rsp+0xB0]
00007cf1741d1be3  vmovaps xmm12, [rsp+0xC0]
00007cf1741d1bec  vmovaps xmm13, [rsp+0xD0]
00007cf1741d1bf5  vmovaps xmm15, [rsp+0xE0]
00007cf1741d1bfe  add rsp, 0xF0
00007cf1741d1c05  pop r11
00007cf1741d1c07  pop r10
00007cf1741d1c09  pop r9
00007cf1741d1c0b  pop r8
00007cf1741d1c0d  pop rsi
00007cf1741d1c0e  pop rdi
00007cf1741d1c0f  pop rdx
00007cf1741d1c10  pop rcx
00007cf1741d1c11  pop rax
00007cf1741d1c12  add rsp, 0x08
00007cf1741d1c16  jmp 0x00007CF1741CFAAF
00007cf1741d1c1b  sub rsp, 0x08
00007cf1741d1c1f  push rax
00007cf1741d1c20  push rcx
00007cf1741d1c21  push rdx
00007cf1741d1c22  push rdi
00007cf1741d1c23  push rsi
00007cf1741d1c24  push r8
00007cf1741d1c26  push r9
00007cf1741d1c28  push r10
00007cf1741d1c2a  push r11
00007cf1741d1c2c  sub rsp, 0xF0
00007cf1741d1c33  vmovaps [rsp], xmm0
00007cf1741d1c38  vmovaps [rsp+0x10], xmm1
00007cf1741d1c3e  vmovaps [rsp+0x20], xmm2
00007cf1741d1c44  vmovaps [rsp+0x30], xmm3
00007cf1741d1c4a  vmovaps [rsp+0x40], xmm4
00007cf1741d1c50  vmovaps [rsp+0x50], xmm5
00007cf1741d1c56  vmovaps [rsp+0x60], xmm6
00007cf1741d1c5c  vmovaps [rsp+0x70], xmm7
00007cf1741d1c62  vmovaps [rsp+0x80], xmm8
00007cf1741d1c6b  vmovaps [rsp+0x90], xmm9
00007cf1741d1c74  vmovaps [rsp+0xA0], xmm10
00007cf1741d1c7d  vmovaps [rsp+0xB0], xmm11
00007cf1741d1c86  vmovaps [rsp+0xC0], xmm12
00007cf1741d1c8f  vmovaps [rsp+0xD0], xmm13
00007cf1741d1c98  vmovaps [rsp+0xE0], xmm14
00007cf1741d1ca1  sub rsp, 0x30
00007cf1741d1ca5  movaps [rsp], xmm15
00007cf1741d1caa  movaps [rsp+0x10], xmm13
00007cf1741d1cb0  movaps [rsp+0x20], xmm1
00007cf1741d1cb5  lea rdi, [rsp]
00007cf1741d1cb9  mov esi, 0x00
00007cf1741d1cbe  mov rax, 0x611C8A33A530
00007cf1741d1cc8  call rax
00007cf1741d1cca  movaps xmm15, [rsp]
00007cf1741d1ccf  add rsp, 0x30
00007cf1741d1cd3  vmovaps xmm0, [rsp]
00007cf1741d1cd8  vmovaps xmm1, [rsp+0x10]
00007cf1741d1cde  vmovaps xmm2, [rsp+0x20]
00007cf1741d1ce4  vmovaps xmm3, [rsp+0x30]
00007cf1741d1cea  vmovaps xmm4, [rsp+0x40]
00007cf1741d1cf0  vmovaps xmm5, [rsp+0x50]
00007cf1741d1cf6  vmovaps xmm6, [rsp+0x60]
00007cf1741d1cfc  vmovaps xmm7, [rsp+0x70]
00007cf1741d1d02  vmovaps xmm8, [rsp+0x80]
00007cf1741d1d0b  vmovaps xmm9, [rsp+0x90]
00007cf1741d1d14  vmovaps xmm10, [rsp+0xA0]
00007cf1741d1d1d  vmovaps xmm11, [rsp+0xB0]
00007cf1741d1d26  vmovaps xmm12, [rsp+0xC0]
00007cf1741d1d2f  vmovaps xmm13, [rsp+0xD0]
00007cf1741d1d38  vmovaps xmm14, [rsp+0xE0]
00007cf1741d1d41  add rsp, 0xF0
00007cf1741d1d48  pop r11
00007cf1741d1d4a  pop r10
00007cf1741d1d4c  pop r9
00007cf1741d1d4e  pop r8
00007cf1741d1d50  pop rsi
00007cf1741d1d51  pop rdi
00007cf1741d1d52  pop rdx
00007cf1741d1d53  pop rcx
00007cf1741d1d54  pop rax
00007cf1741d1d55  add rsp, 0x08
00007cf1741d1d59  jmp 0x00007CF1741CFAEB
00007cf1741d1d5e  call 0x00007CF173FFF430
00007cf1741d1d63  jmp 0x00007CF1741CFAF8
00007cf1741d1d68  sub rsp, 0x08
00007cf1741d1d6c  push rax
00007cf1741d1d6d  push rcx
00007cf1741d1d6e  push rdx
00007cf1741d1d6f  push rdi
00007cf1741d1d70  push rsi
00007cf1741d1d71  push r8
00007cf1741d1d73  push r9
00007cf1741d1d75  push r10
00007cf1741d1d77  push r11
00007cf1741d1d79  sub rsp, 0xF0
00007cf1741d1d80  vmovaps [rsp], xmm0
00007cf1741d1d85  vmovaps [rsp+0x10], xmm1
00007cf1741d1d8b  vmovaps [rsp+0x20], xmm2
00007cf1741d1d91  vmovaps [rsp+0x30], xmm3
00007cf1741d1d97  vmovaps [rsp+0x40], xmm4
00007cf1741d1d9d  vmovaps [rsp+0x50], xmm5
00007cf1741d1da3  vmovaps [rsp+0x60], xmm6
00007cf1741d1da9  vmovaps [rsp+0x70], xmm7
00007cf1741d1daf  vmovaps [rsp+0x80], xmm8
00007cf1741d1db8  vmovaps [rsp+0x90], xmm9
00007cf1741d1dc1  vmovaps [rsp+0xA0], xmm10
00007cf1741d1dca  vmovaps [rsp+0xB0], xmm11
00007cf1741d1dd3  vmovaps [rsp+0xC0], xmm12
00007cf1741d1ddc  vmovaps [rsp+0xD0], xmm13
00007cf1741d1de5  vmovaps [rsp+0xE0], xmm15
00007cf1741d1dee  sub rsp, 0x30
00007cf1741d1df2  movaps [rsp], xmm14
00007cf1741d1df7  movaps [rsp+0x10], xmm13
00007cf1741d1dfd  movaps [rsp+0x20], xmm2
00007cf1741d1e02  lea rdi, [rsp]
00007cf1741d1e06  mov esi, 0x00
00007cf1741d1e0b  mov rax, 0x611C8A33A530
00007cf1741d1e15  call rax
00007cf1741d1e17  movaps xmm14, [rsp]
00007cf1741d1e1c  add rsp, 0x30
00007cf1741d1e20  vmovaps xmm0, [rsp]
00007cf1741d1e25  vmovaps xmm1, [rsp+0x10]
00007cf1741d1e2b  vmovaps xmm2, [rsp+0x20]
00007cf1741d1e31  vmovaps xmm3, [rsp+0x30]
00007cf1741d1e37  vmovaps xmm4, [rsp+0x40]
00007cf1741d1e3d  vmovaps xmm5, [rsp+0x50]
00007cf1741d1e43  vmovaps xmm6, [rsp+0x60]
00007cf1741d1e49  vmovaps xmm7, [rsp+0x70]
00007cf1741d1e4f  vmovaps xmm8, [rsp+0x80]
00007cf1741d1e58  vmovaps xmm9, [rsp+0x90]
00007cf1741d1e61  vmovaps xmm10, [rsp+0xA0]
00007cf1741d1e6a  vmovaps xmm11, [rsp+0xB0]
00007cf1741d1e73  vmovaps xmm12, [rsp+0xC0]
00007cf1741d1e7c  vmovaps xmm13, [rsp+0xD0]
00007cf1741d1e85  vmovaps xmm15, [rsp+0xE0]
00007cf1741d1e8e  add rsp, 0xF0
00007cf1741d1e95  pop r11
00007cf1741d1e97  pop r10
00007cf1741d1e99  pop r9
00007cf1741d1e9b  pop r8
00007cf1741d1e9d  pop rsi
00007cf1741d1e9e  pop rdi
00007cf1741d1e9f  pop rdx
00007cf1741d1ea0  pop rcx
00007cf1741d1ea1  pop rax
00007cf1741d1ea2  add rsp, 0x08
00007cf1741d1ea6  jmp 0x00007CF1741CFB24
00007cf1741d1eab  sub rsp, 0x08
00007cf1741d1eaf  push rax
00007cf1741d1eb0  push rcx
00007cf1741d1eb1  push rdx
00007cf1741d1eb2  push rdi
00007cf1741d1eb3  push rsi
00007cf1741d1eb4  push r8
00007cf1741d1eb6  push r9
00007cf1741d1eb8  push r10
00007cf1741d1eba  push r11
00007cf1741d1ebc  sub rsp, 0xF0
00007cf1741d1ec3  vmovaps [rsp], xmm0
00007cf1741d1ec8  vmovaps [rsp+0x10], xmm2
00007cf1741d1ece  vmovaps [rsp+0x20], xmm3
00007cf1741d1ed4  vmovaps [rsp+0x30], xmm4
00007cf1741d1eda  vmovaps [rsp+0x40], xmm5
00007cf1741d1ee0  vmovaps [rsp+0x50], xmm6
00007cf1741d1ee6  vmovaps [rsp+0x60], xmm7
00007cf1741d1eec  vmovaps [rsp+0x70], xmm8
00007cf1741d1ef2  vmovaps [rsp+0x80], xmm9
00007cf1741d1efb  vmovaps [rsp+0x90], xmm10
00007cf1741d1f04  vmovaps [rsp+0xA0], xmm11
00007cf1741d1f0d  vmovaps [rsp+0xB0], xmm12
00007cf1741d1f16  vmovaps [rsp+0xC0], xmm13
00007cf1741d1f1f  vmovaps [rsp+0xD0], xmm14
00007cf1741d1f28  vmovaps [rsp+0xE0], xmm15
00007cf1741d1f31  sub rsp, 0x30
00007cf1741d1f35  movaps [rsp], xmm1
00007cf1741d1f39  movaps [rsp+0x10], xmm13
00007cf1741d1f3f  movaps [rsp+0x20], xmm2
00007cf1741d1f44  lea rdi, [rsp]
00007cf1741d1f48  mov esi, 0x00
00007cf1741d1f4d  mov rax, 0x611C8A33A530
00007cf1741d1f57  call rax
00007cf1741d1f59  movaps xmm1, [rsp]
00007cf1741d1f5d  add rsp, 0x30
00007cf1741d1f61  vmovaps xmm0, [rsp]
00007cf1741d1f66  vmovaps xmm2, [rsp+0x10]
00007cf1741d1f6c  vmovaps xmm3, [rsp+0x20]
00007cf1741d1f72  vmovaps xmm4, [rsp+0x30]
00007cf1741d1f78  vmovaps xmm5, [rsp+0x40]
00007cf1741d1f7e  vmovaps xmm6, [rsp+0x50]
00007cf1741d1f84  vmovaps xmm7, [rsp+0x60]
00007cf1741d1f8a  vmovaps xmm8, [rsp+0x70]
00007cf1741d1f90  vmovaps xmm9, [rsp+0x80]
00007cf1741d1f99  vmovaps xmm10, [rsp+0x90]
00007cf1741d1fa2  vmovaps xmm11, [rsp+0xA0]
00007cf1741d1fab  vmovaps xmm12, [rsp+0xB0]
00007cf1741d1fb4  vmovaps xmm13, [rsp+0xC0]
00007cf1741d1fbd  vmovaps xmm14, [rsp+0xD0]
00007cf1741d1fc6  vmovaps xmm15, [rsp+0xE0]
00007cf1741d1fcf  add rsp, 0xF0
00007cf1741d1fd6  pop r11
00007cf1741d1fd8  pop r10
00007cf1741d1fda  pop r9
00007cf1741d1fdc  pop r8
00007cf1741d1fde  pop rsi
00007cf1741d1fdf  pop rdi
00007cf1741d1fe0  pop rdx
00007cf1741d1fe1  pop rcx
00007cf1741d1fe2  pop rax
00007cf1741d1fe3  add rsp, 0x08
00007cf1741d1fe7  jmp 0x00007CF1741CFB52
00007cf1741d1fec  sub rsp, 0x08
00007cf1741d1ff0  push rax
00007cf1741d1ff1  push rcx
00007cf1741d1ff2  push rdx
00007cf1741d1ff3  push rdi
00007cf1741d1ff4  push rsi
00007cf1741d1ff5  push r8
00007cf1741d1ff7  push r9
00007cf1741d1ff9  push r10
00007cf1741d1ffb  push r11
00007cf1741d1ffd  sub rsp, 0xF0
00007cf1741d2004  vmovaps [rsp], xmm0
00007cf1741d2009  vmovaps [rsp+0x10], xmm1
00007cf1741d200f  vmovaps [rsp+0x20], xmm3
00007cf1741d2015  vmovaps [rsp+0x30], xmm4
00007cf1741d201b  vmovaps [rsp+0x40], xmm5
00007cf1741d2021  vmovaps [rsp+0x50], xmm6
00007cf1741d2027  vmovaps [rsp+0x60], xmm7
00007cf1741d202d  vmovaps [rsp+0x70], xmm8
00007cf1741d2033  vmovaps [rsp+0x80], xmm9
00007cf1741d203c  vmovaps [rsp+0x90], xmm10
00007cf1741d2045  vmovaps [rsp+0xA0], xmm11
00007cf1741d204e  vmovaps [rsp+0xB0], xmm12
00007cf1741d2057  vmovaps [rsp+0xC0], xmm13
00007cf1741d2060  vmovaps [rsp+0xD0], xmm14
00007cf1741d2069  vmovaps [rsp+0xE0], xmm15
00007cf1741d2072  sub rsp, 0x30
00007cf1741d2076  movaps [rsp], xmm2
00007cf1741d207a  movaps [rsp+0x10], xmm1
00007cf1741d207f  movaps [rsp+0x20], xmm13
00007cf1741d2085  lea rdi, [rsp]
00007cf1741d2089  mov esi, 0x00
00007cf1741d208e  mov rax, 0x611C8A33A530
00007cf1741d2098  call rax
00007cf1741d209a  movaps xmm2, [rsp]
00007cf1741d209e  add rsp, 0x30
00007cf1741d20a2  vmovaps xmm0, [rsp]
00007cf1741d20a7  vmovaps xmm1, [rsp+0x10]
00007cf1741d20ad  vmovaps xmm3, [rsp+0x20]
00007cf1741d20b3  vmovaps xmm4, [rsp+0x30]
00007cf1741d20b9  vmovaps xmm5, [rsp+0x40]
00007cf1741d20bf  vmovaps xmm6, [rsp+0x50]
00007cf1741d20c5  vmovaps xmm7, [rsp+0x60]
00007cf1741d20cb  vmovaps xmm8, [rsp+0x70]
00007cf1741d20d1  vmovaps xmm9, [rsp+0x80]
00007cf1741d20da  vmovaps xmm10, [rsp+0x90]
00007cf1741d20e3  vmovaps xmm11, [rsp+0xA0]
00007cf1741d20ec  vmovaps xmm12, [rsp+0xB0]
00007cf1741d20f5  vmovaps xmm13, [rsp+0xC0]
00007cf1741d20fe  vmovaps xmm14, [rsp+0xD0]
00007cf1741d2107  vmovaps xmm15, [rsp+0xE0]
00007cf1741d2110  add rsp, 0xF0
00007cf1741d2117  pop r11
00007cf1741d2119  pop r10
00007cf1741d211b  pop r9
00007cf1741d211d  pop r8
00007cf1741d211f  pop rsi
00007cf1741d2120  pop rdi
00007cf1741d2121  pop rdx
00007cf1741d2122  pop rcx
00007cf1741d2123  pop rax
00007cf1741d2124  add rsp, 0x08
00007cf1741d2128  jmp 0x00007CF1741CFBAB
00007cf1741d212d  call 0x00007CF173FFF430
00007cf1741d2132  jmp 0x00007CF1741CFBB8
00007cf1741d2137  sub rsp, 0x08
00007cf1741d213b  push rax
00007cf1741d213c  push rcx
00007cf1741d213d  push rdx
00007cf1741d213e  push rdi
00007cf1741d213f  push rsi
00007cf1741d2140  push r8
00007cf1741d2142  push r9
00007cf1741d2144  push r10
00007cf1741d2146  push r11
00007cf1741d2148  sub rsp, 0xF0
00007cf1741d214f  vmovaps [rsp], xmm0
00007cf1741d2154  vmovaps [rsp+0x10], xmm1
00007cf1741d215a  vmovaps [rsp+0x20], xmm2
00007cf1741d2160  vmovaps [rsp+0x30], xmm3
00007cf1741d2166  vmovaps [rsp+0x40], xmm4
00007cf1741d216c  vmovaps [rsp+0x50], xmm5
00007cf1741d2172  vmovaps [rsp+0x60], xmm6
00007cf1741d2178  vmovaps [rsp+0x70], xmm7
00007cf1741d217e  vmovaps [rsp+0x80], xmm8
00007cf1741d2187  vmovaps [rsp+0x90], xmm9
00007cf1741d2190  vmovaps [rsp+0xA0], xmm10
00007cf1741d2199  vmovaps [rsp+0xB0], xmm11
00007cf1741d21a2  vmovaps [rsp+0xC0], xmm12
00007cf1741d21ab  vmovaps [rsp+0xD0], xmm13
00007cf1741d21b4  vmovaps [rsp+0xE0], xmm14
00007cf1741d21bd  sub rsp, 0x30
00007cf1741d21c1  movaps [rsp], xmm15
00007cf1741d21c6  movaps [rsp+0x10], xmm13
00007cf1741d21cc  movaps [rsp+0x20], xmm1
00007cf1741d21d1  lea rdi, [rsp]
00007cf1741d21d5  mov esi, 0x00
00007cf1741d21da  mov rax, 0x611C8A33A530
00007cf1741d21e4  call rax
00007cf1741d21e6  movaps xmm15, [rsp]
00007cf1741d21eb  add rsp, 0x30
00007cf1741d21ef  vmovaps xmm0, [rsp]
00007cf1741d21f4  vmovaps xmm1, [rsp+0x10]
00007cf1741d21fa  vmovaps xmm2, [rsp+0x20]
00007cf1741d2200  vmovaps xmm3, [rsp+0x30]
00007cf1741d2206  vmovaps xmm4, [rsp+0x40]
00007cf1741d220c  vmovaps xmm5, [rsp+0x50]
00007cf1741d2212  vmovaps xmm6, [rsp+0x60]
00007cf1741d2218  vmovaps xmm7, [rsp+0x70]
00007cf1741d221e  vmovaps xmm8, [rsp+0x80]
00007cf1741d2227  vmovaps xmm9, [rsp+0x90]
00007cf1741d2230  vmovaps xmm10, [rsp+0xA0]
00007cf1741d2239  vmovaps xmm11, [rsp+0xB0]
00007cf1741d2242  vmovaps xmm12, [rsp+0xC0]
00007cf1741d224b  vmovaps xmm13, [rsp+0xD0]
00007cf1741d2254  vmovaps xmm14, [rsp+0xE0]
00007cf1741d225d  add rsp, 0xF0
00007cf1741d2264  pop r11
00007cf1741d2266  pop r10
00007cf1741d2268  pop r9
00007cf1741d226a  pop r8
00007cf1741d226c  pop rsi
00007cf1741d226d  pop rdi
00007cf1741d226e  pop rdx
00007cf1741d226f  pop rcx
00007cf1741d2270  pop rax
00007cf1741d2271  add rsp, 0x08
00007cf1741d2275  jmp 0x00007CF1741CFBF7
00007cf1741d227a  sub rsp, 0x08
00007cf1741d227e  push rax
00007cf1741d227f  push rcx
00007cf1741d2280  push rdx
00007cf1741d2281  push rdi
00007cf1741d2282  push rsi
00007cf1741d2283  push r8
00007cf1741d2285  push r9
00007cf1741d2287  push r10
00007cf1741d2289  push r11
00007cf1741d228b  sub rsp, 0xF0
00007cf1741d2292  vmovaps [rsp], xmm0
00007cf1741d2297  vmovaps [rsp+0x10], xmm1
00007cf1741d229d  vmovaps [rsp+0x20], xmm2
00007cf1741d22a3  vmovaps [rsp+0x30], xmm3
00007cf1741d22a9  vmovaps [rsp+0x40], xmm4
00007cf1741d22af  vmovaps [rsp+0x50], xmm5
00007cf1741d22b5  vmovaps [rsp+0x60], xmm6
00007cf1741d22bb  vmovaps [rsp+0x70], xmm7
00007cf1741d22c1  vmovaps [rsp+0x80], xmm8
00007cf1741d22ca  vmovaps [rsp+0x90], xmm9
00007cf1741d22d3  vmovaps [rsp+0xA0], xmm10
00007cf1741d22dc  vmovaps [rsp+0xB0], xmm11
00007cf1741d22e5  vmovaps [rsp+0xC0], xmm12
00007cf1741d22ee  vmovaps [rsp+0xD0], xmm13
00007cf1741d22f7  vmovaps [rsp+0xE0], xmm15
00007cf1741d2300  sub rsp, 0x30
00007cf1741d2304  movaps [rsp], xmm14
00007cf1741d2309  movaps [rsp+0x10], xmm11
00007cf1741d230f  movaps [rsp+0x20], xmm1
00007cf1741d2314  lea rdi, [rsp]
00007cf1741d2318  mov esi, 0x00
00007cf1741d231d  mov rax, 0x611C8A33A530
00007cf1741d2327  call rax
00007cf1741d2329  movaps xmm14, [rsp]
00007cf1741d232e  add rsp, 0x30
00007cf1741d2332  vmovaps xmm0, [rsp]
00007cf1741d2337  vmovaps xmm1, [rsp+0x10]
00007cf1741d233d  vmovaps xmm2, [rsp+0x20]
00007cf1741d2343  vmovaps xmm3, [rsp+0x30]
00007cf1741d2349  vmovaps xmm4, [rsp+0x40]
00007cf1741d234f  vmovaps xmm5, [rsp+0x50]
00007cf1741d2355  vmovaps xmm6, [rsp+0x60]
00007cf1741d235b  vmovaps xmm7, [rsp+0x70]
00007cf1741d2361  vmovaps xmm8, [rsp+0x80]
00007cf1741d236a  vmovaps xmm9, [rsp+0x90]
00007cf1741d2373  vmovaps xmm10, [rsp+0xA0]
00007cf1741d237c  vmovaps xmm11, [rsp+0xB0]
00007cf1741d2385  vmovaps xmm12, [rsp+0xC0]
00007cf1741d238e  vmovaps xmm13, [rsp+0xD0]
00007cf1741d2397  vmovaps xmm15, [rsp+0xE0]
00007cf1741d23a0  add rsp, 0xF0
00007cf1741d23a7  pop r11
00007cf1741d23a9  pop r10
00007cf1741d23ab  pop r9
00007cf1741d23ad  pop r8
00007cf1741d23af  pop rsi
00007cf1741d23b0  pop rdi
00007cf1741d23b1  pop rdx
00007cf1741d23b2  pop rcx
00007cf1741d23b3  pop rax
00007cf1741d23b4  add rsp, 0x08
00007cf1741d23b8  jmp 0x00007CF1741CFC21
00007cf1741d23bd  sub rsp, 0x08
00007cf1741d23c1  push rax
00007cf1741d23c2  push rcx
00007cf1741d23c3  push rdx
00007cf1741d23c4  push rdi
00007cf1741d23c5  push rsi
00007cf1741d23c6  push r8
00007cf1741d23c8  push r9
00007cf1741d23ca  push r10
00007cf1741d23cc  push r11
00007cf1741d23ce  sub rsp, 0xF0
00007cf1741d23d5  vmovaps [rsp], xmm0
00007cf1741d23da  vmovaps [rsp+0x10], xmm1
00007cf1741d23e0  vmovaps [rsp+0x20], xmm2
00007cf1741d23e6  vmovaps [rsp+0x30], xmm3
00007cf1741d23ec  vmovaps [rsp+0x40], xmm4
00007cf1741d23f2  vmovaps [rsp+0x50], xmm5
00007cf1741d23f8  vmovaps [rsp+0x60], xmm6
00007cf1741d23fe  vmovaps [rsp+0x70], xmm7
00007cf1741d2404  vmovaps [rsp+0x80], xmm8
00007cf1741d240d  vmovaps [rsp+0x90], xmm9
00007cf1741d2416  vmovaps [rsp+0xA0], xmm10
00007cf1741d241f  vmovaps [rsp+0xB0], xmm11
00007cf1741d2428  vmovaps [rsp+0xC0], xmm12
00007cf1741d2431  vmovaps [rsp+0xD0], xmm14
00007cf1741d243a  vmovaps [rsp+0xE0], xmm15
00007cf1741d2443  sub rsp, 0x30
00007cf1741d2447  movaps [rsp], xmm13
00007cf1741d244c  movaps [rsp+0x10], xmm11
00007cf1741d2452  movaps [rsp+0x20], xmm1
00007cf1741d2457  lea rdi, [rsp]
00007cf1741d245b  mov esi, 0x00
00007cf1741d2460  mov rax, 0x611C8A33A530
00007cf1741d246a  call rax
00007cf1741d246c  movaps xmm13, [rsp]
00007cf1741d2471  add rsp, 0x30
00007cf1741d2475  vmovaps xmm0, [rsp]
00007cf1741d247a  vmovaps xmm1, [rsp+0x10]
00007cf1741d2480  vmovaps xmm2, [rsp+0x20]
00007cf1741d2486  vmovaps xmm3, [rsp+0x30]
00007cf1741d248c  vmovaps xmm4, [rsp+0x40]
00007cf1741d2492  vmovaps xmm5, [rsp+0x50]
00007cf1741d2498  vmovaps xmm6, [rsp+0x60]
00007cf1741d249e  vmovaps xmm7, [rsp+0x70]
00007cf1741d24a4  vmovaps xmm8, [rsp+0x80]
00007cf1741d24ad  vmovaps xmm9, [rsp+0x90]
00007cf1741d24b6  vmovaps xmm10, [rsp+0xA0]
00007cf1741d24bf  vmovaps xmm11, [rsp+0xB0]
00007cf1741d24c8  vmovaps xmm12, [rsp+0xC0]
00007cf1741d24d1  vmovaps xmm14, [rsp+0xD0]
00007cf1741d24da  vmovaps xmm15, [rsp+0xE0]
00007cf1741d24e3  add rsp, 0xF0
00007cf1741d24ea  pop r11
00007cf1741d24ec  pop r10
00007cf1741d24ee  pop r9
00007cf1741d24f0  pop r8
00007cf1741d24f2  pop rsi
00007cf1741d24f3  pop rdi
00007cf1741d24f4  pop rdx
00007cf1741d24f5  pop rcx
00007cf1741d24f6  pop rax
00007cf1741d24f7  add rsp, 0x08
00007cf1741d24fb  jmp 0x00007CF1741CFC76
00007cf1741d2500  call 0x00007CF173FFF430
00007cf1741d2505  jmp 0x00007CF1741CFC83
00007cf1741d250a  sub rsp, 0x08
00007cf1741d250e  push rax
00007cf1741d250f  push rcx
00007cf1741d2510  push rdx
00007cf1741d2511  push rdi
00007cf1741d2512  push rsi
00007cf1741d2513  push r8
00007cf1741d2515  push r9
00007cf1741d2517  push r10
00007cf1741d2519  push r11
00007cf1741d251b  sub rsp, 0xF0
00007cf1741d2522  vmovaps [rsp], xmm0
00007cf1741d2527  vmovaps [rsp+0x10], xmm1
00007cf1741d252d  vmovaps [rsp+0x20], xmm2
00007cf1741d2533  vmovaps [rsp+0x30], xmm3
00007cf1741d2539  vmovaps [rsp+0x40], xmm4
00007cf1741d253f  vmovaps [rsp+0x50], xmm5
00007cf1741d2545  vmovaps [rsp+0x60], xmm6
00007cf1741d254b  vmovaps [rsp+0x70], xmm7
00007cf1741d2551  vmovaps [rsp+0x80], xmm8
00007cf1741d255a  vmovaps [rsp+0x90], xmm9
00007cf1741d2563  vmovaps [rsp+0xA0], xmm10
00007cf1741d256c  vmovaps [rsp+0xB0], xmm11
00007cf1741d2575  vmovaps [rsp+0xC0], xmm12
00007cf1741d257e  vmovaps [rsp+0xD0], xmm13
00007cf1741d2587  vmovaps [rsp+0xE0], xmm14
00007cf1741d2590  sub rsp, 0x30
00007cf1741d2594  movaps [rsp], xmm15
00007cf1741d2599  movaps [rsp+0x10], xmm11
00007cf1741d259f  movaps [rsp+0x20], xmm1
00007cf1741d25a4  lea rdi, [rsp]
00007cf1741d25a8  mov esi, 0x00
00007cf1741d25ad  mov rax, 0x611C8A33A530
00007cf1741d25b7  call rax
00007cf1741d25b9  movaps xmm15, [rsp]
00007cf1741d25be  add rsp, 0x30
00007cf1741d25c2  vmovaps xmm0, [rsp]
00007cf1741d25c7  vmovaps xmm1, [rsp+0x10]
00007cf1741d25cd  vmovaps xmm2, [rsp+0x20]
00007cf1741d25d3  vmovaps xmm3, [rsp+0x30]
00007cf1741d25d9  vmovaps xmm4, [rsp+0x40]
00007cf1741d25df  vmovaps xmm5, [rsp+0x50]
00007cf1741d25e5  vmovaps xmm6, [rsp+0x60]
00007cf1741d25eb  vmovaps xmm7, [rsp+0x70]
00007cf1741d25f1  vmovaps xmm8, [rsp+0x80]
00007cf1741d25fa  vmovaps xmm9, [rsp+0x90]
00007cf1741d2603  vmovaps xmm10, [rsp+0xA0]
00007cf1741d260c  vmovaps xmm11, [rsp+0xB0]
00007cf1741d2615  vmovaps xmm12, [rsp+0xC0]
00007cf1741d261e  vmovaps xmm13, [rsp+0xD0]
00007cf1741d2627  vmovaps xmm14, [rsp+0xE0]
00007cf1741d2630  add rsp, 0xF0
00007cf1741d2637  pop r11
00007cf1741d2639  pop r10
00007cf1741d263b  pop r9
00007cf1741d263d  pop r8
00007cf1741d263f  pop rsi
00007cf1741d2640  pop rdi
00007cf1741d2641  pop rdx
00007cf1741d2642  pop rcx
00007cf1741d2643  pop rax
00007cf1741d2644  add rsp, 0x08
00007cf1741d2648  jmp 0x00007CF1741CFCBC
00007cf1741d264d  sub rsp, 0x08
00007cf1741d2651  push rax
00007cf1741d2652  push rcx
00007cf1741d2653  push rdx
00007cf1741d2654  push rdi
00007cf1741d2655  push rsi
00007cf1741d2656  push r8
00007cf1741d2658  push r9
00007cf1741d265a  push r10
00007cf1741d265c  push r11
00007cf1741d265e  sub rsp, 0xF0
00007cf1741d2665  vmovaps [rsp], xmm0
00007cf1741d266a  vmovaps [rsp+0x10], xmm1
00007cf1741d2670  vmovaps [rsp+0x20], xmm2
00007cf1741d2676  vmovaps [rsp+0x30], xmm3
00007cf1741d267c  vmovaps [rsp+0x40], xmm4
00007cf1741d2682  vmovaps [rsp+0x50], xmm5
00007cf1741d2688  vmovaps [rsp+0x60], xmm6
00007cf1741d268e  vmovaps [rsp+0x70], xmm7
00007cf1741d2694  vmovaps [rsp+0x80], xmm8
00007cf1741d269d  vmovaps [rsp+0x90], xmm9
00007cf1741d26a6  vmovaps [rsp+0xA0], xmm10
00007cf1741d26af  vmovaps [rsp+0xB0], xmm12
00007cf1741d26b8  vmovaps [rsp+0xC0], xmm13
00007cf1741d26c1  vmovaps [rsp+0xD0], xmm14
00007cf1741d26ca  vmovaps [rsp+0xE0], xmm15
00007cf1741d26d3  sub rsp, 0x30
00007cf1741d26d7  movaps [rsp], xmm11
00007cf1741d26dc  movaps [rsp+0x10], xmm6
00007cf1741d26e1  movaps [rsp+0x20], xmm14
00007cf1741d26e7  lea rdi, [rsp]
00007cf1741d26eb  mov esi, 0x00
00007cf1741d26f0  mov rax, 0x611C8A33A530
00007cf1741d26fa  call rax
00007cf1741d26fc  movaps xmm11, [rsp]
00007cf1741d2701  add rsp, 0x30
00007cf1741d2705  vmovaps xmm0, [rsp]
00007cf1741d270a  vmovaps xmm1, [rsp+0x10]
00007cf1741d2710  vmovaps xmm2, [rsp+0x20]
00007cf1741d2716  vmovaps xmm3, [rsp+0x30]
00007cf1741d271c  vmovaps xmm4, [rsp+0x40]
00007cf1741d2722  vmovaps xmm5, [rsp+0x50]
00007cf1741d2728  vmovaps xmm6, [rsp+0x60]
00007cf1741d272e  vmovaps xmm7, [rsp+0x70]
00007cf1741d2734  vmovaps xmm8, [rsp+0x80]
00007cf1741d273d  vmovaps xmm9, [rsp+0x90]
00007cf1741d2746  vmovaps xmm10, [rsp+0xA0]
00007cf1741d274f  vmovaps xmm12, [rsp+0xB0]
00007cf1741d2758  vmovaps xmm13, [rsp+0xC0]
00007cf1741d2761  vmovaps xmm14, [rsp+0xD0]
00007cf1741d276a  vmovaps xmm15, [rsp+0xE0]
00007cf1741d2773  add rsp, 0xF0
00007cf1741d277a  pop r11
00007cf1741d277c  pop r10
00007cf1741d277e  pop r9
00007cf1741d2780  pop r8
00007cf1741d2782  pop rsi
00007cf1741d2783  pop rdi
00007cf1741d2784  pop rdx
00007cf1741d2785  pop rcx
00007cf1741d2786  pop rax
00007cf1741d2787  add rsp, 0x08
00007cf1741d278b  jmp 0x00007CF1741CFD34
00007cf1741d2790  call 0x00007CF173FFF430
00007cf1741d2795  jmp 0x00007CF1741CFD3E
00007cf1741d279a  sub rsp, 0x08
00007cf1741d279e  push rax
00007cf1741d279f  push rcx
00007cf1741d27a0  push rdx
00007cf1741d27a1  push rdi
00007cf1741d27a2  push rsi
00007cf1741d27a3  push r8
00007cf1741d27a5  push r9
00007cf1741d27a7  push r10
00007cf1741d27a9  push r11
00007cf1741d27ab  sub rsp, 0xF0
00007cf1741d27b2  vmovaps [rsp], xmm0
00007cf1741d27b7  vmovaps [rsp+0x10], xmm1
00007cf1741d27bd  vmovaps [rsp+0x20], xmm2
00007cf1741d27c3  vmovaps [rsp+0x30], xmm3
00007cf1741d27c9  vmovaps [rsp+0x40], xmm4
00007cf1741d27cf  vmovaps [rsp+0x50], xmm5
00007cf1741d27d5  vmovaps [rsp+0x60], xmm6
00007cf1741d27db  vmovaps [rsp+0x70], xmm7
00007cf1741d27e1  vmovaps [rsp+0x80], xmm8
00007cf1741d27ea  vmovaps [rsp+0x90], xmm9
00007cf1741d27f3  vmovaps [rsp+0xA0], xmm10
00007cf1741d27fc  vmovaps [rsp+0xB0], xmm11
00007cf1741d2805  vmovaps [rsp+0xC0], xmm12
00007cf1741d280e  vmovaps [rsp+0xD0], xmm13
00007cf1741d2817  vmovaps [rsp+0xE0], xmm15
00007cf1741d2820  sub rsp, 0x30
00007cf1741d2824  movaps [rsp], xmm14
00007cf1741d2829  movaps [rsp+0x10], xmm6
00007cf1741d282e  movaps [rsp+0x20], xmm2
00007cf1741d2833  lea rdi, [rsp]
00007cf1741d2837  mov esi, 0x00
00007cf1741d283c  mov rax, 0x611C8A33A530
00007cf1741d2846  call rax
00007cf1741d2848  movaps xmm14, [rsp]
00007cf1741d284d  add rsp, 0x30
00007cf1741d2851  vmovaps xmm0, [rsp]
00007cf1741d2856  vmovaps xmm1, [rsp+0x10]
00007cf1741d285c  vmovaps xmm2, [rsp+0x20]
00007cf1741d2862  vmovaps xmm3, [rsp+0x30]
00007cf1741d2868  vmovaps xmm4, [rsp+0x40]
00007cf1741d286e  vmovaps xmm5, [rsp+0x50]
00007cf1741d2874  vmovaps xmm6, [rsp+0x60]
00007cf1741d287a  vmovaps xmm7, [rsp+0x70]
00007cf1741d2880  vmovaps xmm8, [rsp+0x80]
00007cf1741d2889  vmovaps xmm9, [rsp+0x90]
00007cf1741d2892  vmovaps xmm10, [rsp+0xA0]
00007cf1741d289b  vmovaps xmm11, [rsp+0xB0]
00007cf1741d28a4  vmovaps xmm12, [rsp+0xC0]
00007cf1741d28ad  vmovaps xmm13, [rsp+0xD0]
00007cf1741d28b6  vmovaps xmm15, [rsp+0xE0]
00007cf1741d28bf  add rsp, 0xF0
00007cf1741d28c6  pop r11
00007cf1741d28c8  pop r10
00007cf1741d28ca  pop r9
00007cf1741d28cc  pop r8
00007cf1741d28ce  pop rsi
00007cf1741d28cf  pop rdi
00007cf1741d28d0  pop rdx
00007cf1741d28d1  pop rcx
00007cf1741d28d2  pop rax
00007cf1741d28d3  add rsp, 0x08
00007cf1741d28d7  jmp 0x00007CF1741CFD72
00007cf1741d28dc  sub rsp, 0x08
00007cf1741d28e0  push rax
00007cf1741d28e1  push rcx
00007cf1741d28e2  push rdx
00007cf1741d28e3  push rdi
00007cf1741d28e4  push rsi
00007cf1741d28e5  push r8
00007cf1741d28e7  push r9
00007cf1741d28e9  push r10
00007cf1741d28eb  push r11
00007cf1741d28ed  sub rsp, 0xF0
00007cf1741d28f4  vmovaps [rsp], xmm0
00007cf1741d28f9  vmovaps [rsp+0x10], xmm1
00007cf1741d28ff  vmovaps [rsp+0x20], xmm2
00007cf1741d2905  vmovaps [rsp+0x30], xmm3
00007cf1741d290b  vmovaps [rsp+0x40], xmm4
00007cf1741d2911  vmovaps [rsp+0x50], xmm5
00007cf1741d2917  vmovaps [rsp+0x60], xmm7
00007cf1741d291d  vmovaps [rsp+0x70], xmm8
00007cf1741d2923  vmovaps [rsp+0x80], xmm9
00007cf1741d292c  vmovaps [rsp+0x90], xmm10
00007cf1741d2935  vmovaps [rsp+0xA0], xmm11
00007cf1741d293e  vmovaps [rsp+0xB0], xmm12
00007cf1741d2947  vmovaps [rsp+0xC0], xmm13
00007cf1741d2950  vmovaps [rsp+0xD0], xmm14
00007cf1741d2959  vmovaps [rsp+0xE0], xmm15
00007cf1741d2962  sub rsp, 0x30
00007cf1741d2966  movaps [rsp], xmm6
00007cf1741d296a  movaps [rsp+0x10], xmm5
00007cf1741d296f  movaps [rsp+0x20], xmm1
00007cf1741d2974  lea rdi, [rsp]
00007cf1741d2978  mov esi, 0x00
00007cf1741d297d  mov rax, 0x611C8A33A530
00007cf1741d2987  call rax
00007cf1741d2989  movaps xmm6, [rsp]
00007cf1741d298d  add rsp, 0x30
00007cf1741d2991  vmovaps xmm0, [rsp]
00007cf1741d2996  vmovaps xmm1, [rsp+0x10]
00007cf1741d299c  vmovaps xmm2, [rsp+0x20]
00007cf1741d29a2  vmovaps xmm3, [rsp+0x30]
00007cf1741d29a8  vmovaps xmm4, [rsp+0x40]
00007cf1741d29ae  vmovaps xmm5, [rsp+0x50]
00007cf1741d29b4  vmovaps xmm7, [rsp+0x60]
00007cf1741d29ba  vmovaps xmm8, [rsp+0x70]
00007cf1741d29c0  vmovaps xmm9, [rsp+0x80]
00007cf1741d29c9  vmovaps xmm10, [rsp+0x90]
00007cf1741d29d2  vmovaps xmm11, [rsp+0xA0]
00007cf1741d29db  vmovaps xmm12, [rsp+0xB0]
00007cf1741d29e4  vmovaps xmm13, [rsp+0xC0]
00007cf1741d29ed  vmovaps xmm14, [rsp+0xD0]
00007cf1741d29f6  vmovaps xmm15, [rsp+0xE0]
00007cf1741d29ff  add rsp, 0xF0
00007cf1741d2a06  pop r11
00007cf1741d2a08  pop r10
00007cf1741d2a0a  pop r9
00007cf1741d2a0c  pop r8
00007cf1741d2a0e  pop rsi
00007cf1741d2a0f  pop rdi
00007cf1741d2a10  pop rdx
00007cf1741d2a11  pop rcx
00007cf1741d2a12  pop rax
00007cf1741d2a13  add rsp, 0x08
00007cf1741d2a17  jmp 0x00007CF1741CFD98
00007cf1741d2a1c  sub rsp, 0x08
00007cf1741d2a20  push rax
00007cf1741d2a21  push rcx
00007cf1741d2a22  push rdx
00007cf1741d2a23  push rdi
00007cf1741d2a24  push rsi
00007cf1741d2a25  push r8
00007cf1741d2a27  push r9
00007cf1741d2a29  push r10
00007cf1741d2a2b  push r11
00007cf1741d2a2d  sub rsp, 0xF0
00007cf1741d2a34  vmovaps [rsp], xmm0
00007cf1741d2a39  vmovaps [rsp+0x10], xmm2
00007cf1741d2a3f  vmovaps [rsp+0x20], xmm3
00007cf1741d2a45  vmovaps [rsp+0x30], xmm4
00007cf1741d2a4b  vmovaps [rsp+0x40], xmm5
00007cf1741d2a51  vmovaps [rsp+0x50], xmm6
00007cf1741d2a57  vmovaps [rsp+0x60], xmm7
00007cf1741d2a5d  vmovaps [rsp+0x70], xmm8
00007cf1741d2a63  vmovaps [rsp+0x80], xmm9
00007cf1741d2a6c  vmovaps [rsp+0x90], xmm10
00007cf1741d2a75  vmovaps [rsp+0xA0], xmm11
00007cf1741d2a7e  vmovaps [rsp+0xB0], xmm12
00007cf1741d2a87  vmovaps [rsp+0xC0], xmm13
00007cf1741d2a90  vmovaps [rsp+0xD0], xmm14
00007cf1741d2a99  vmovaps [rsp+0xE0], xmm15
00007cf1741d2aa2  sub rsp, 0x30
00007cf1741d2aa6  movaps [rsp], xmm1
00007cf1741d2aaa  movaps [rsp+0x10], xmm5
00007cf1741d2aaf  movaps [rsp+0x20], xmm13
00007cf1741d2ab5  lea rdi, [rsp]
00007cf1741d2ab9  mov esi, 0x00
00007cf1741d2abe  mov rax, 0x611C8A33A530
00007cf1741d2ac8  call rax
00007cf1741d2aca  movaps xmm1, [rsp]
00007cf1741d2ace  add rsp, 0x30
00007cf1741d2ad2  vmovaps xmm0, [rsp]
00007cf1741d2ad7  vmovaps xmm2, [rsp+0x10]
00007cf1741d2add  vmovaps xmm3, [rsp+0x20]
00007cf1741d2ae3  vmovaps xmm4, [rsp+0x30]
00007cf1741d2ae9  vmovaps xmm5, [rsp+0x40]
00007cf1741d2aef  vmovaps xmm6, [rsp+0x50]
00007cf1741d2af5  vmovaps xmm7, [rsp+0x60]
00007cf1741d2afb  vmovaps xmm8, [rsp+0x70]
00007cf1741d2b01  vmovaps xmm9, [rsp+0x80]
00007cf1741d2b0a  vmovaps xmm10, [rsp+0x90]
00007cf1741d2b13  vmovaps xmm11, [rsp+0xA0]
00007cf1741d2b1c  vmovaps xmm12, [rsp+0xB0]
00007cf1741d2b25  vmovaps xmm13, [rsp+0xC0]
00007cf1741d2b2e  vmovaps xmm14, [rsp+0xD0]
00007cf1741d2b37  vmovaps xmm15, [rsp+0xE0]
00007cf1741d2b40  add rsp, 0xF0
00007cf1741d2b47  pop r11
00007cf1741d2b49  pop r10
00007cf1741d2b4b  pop r9
00007cf1741d2b4d  pop r8
00007cf1741d2b4f  pop rsi
00007cf1741d2b50  pop rdi
00007cf1741d2b51  pop rdx
00007cf1741d2b52  pop rcx
00007cf1741d2b53  pop rax
00007cf1741d2b54  add rsp, 0x08
00007cf1741d2b58  jmp 0x00007CF1741CFDB6
00007cf1741d2b5d  sub rsp, 0x08
00007cf1741d2b61  push rax
00007cf1741d2b62  push rcx
00007cf1741d2b63  push rdx
00007cf1741d2b64  push rdi
00007cf1741d2b65  push rsi
00007cf1741d2b66  push r8
00007cf1741d2b68  push r9
00007cf1741d2b6a  push r10
00007cf1741d2b6c  push r11
00007cf1741d2b6e  sub rsp, 0xF0
00007cf1741d2b75  vmovaps [rsp], xmm0
00007cf1741d2b7a  vmovaps [rsp+0x10], xmm1
00007cf1741d2b80  vmovaps [rsp+0x20], xmm2
00007cf1741d2b86  vmovaps [rsp+0x30], xmm3
00007cf1741d2b8c  vmovaps [rsp+0x40], xmm4
00007cf1741d2b92  vmovaps [rsp+0x50], xmm6
00007cf1741d2b98  vmovaps [rsp+0x60], xmm7
00007cf1741d2b9e  vmovaps [rsp+0x70], xmm8
00007cf1741d2ba4  vmovaps [rsp+0x80], xmm9
00007cf1741d2bad  vmovaps [rsp+0x90], xmm10
00007cf1741d2bb6  vmovaps [rsp+0xA0], xmm11
00007cf1741d2bbf  vmovaps [rsp+0xB0], xmm12
00007cf1741d2bc8  vmovaps [rsp+0xC0], xmm13
00007cf1741d2bd1  vmovaps [rsp+0xD0], xmm14
00007cf1741d2bda  vmovaps [rsp+0xE0], xmm15
00007cf1741d2be3  sub rsp, 0x30
00007cf1741d2be7  movaps [rsp], xmm5
00007cf1741d2beb  movaps [rsp+0x10], xmm2
00007cf1741d2bf0  movaps [rsp+0x20], xmm13
00007cf1741d2bf6  lea rdi, [rsp]
00007cf1741d2bfa  mov esi, 0x00
00007cf1741d2bff  mov rax, 0x611C8A33A530
00007cf1741d2c09  call rax
00007cf1741d2c0b  movaps xmm5, [rsp]
00007cf1741d2c0f  add rsp, 0x30
00007cf1741d2c13  vmovaps xmm0, [rsp]
00007cf1741d2c18  vmovaps xmm1, [rsp+0x10]
00007cf1741d2c1e  vmovaps xmm2, [rsp+0x20]
00007cf1741d2c24  vmovaps xmm3, [rsp+0x30]
00007cf1741d2c2a  vmovaps xmm4, [rsp+0x40]
00007cf1741d2c30  vmovaps xmm6, [rsp+0x50]
00007cf1741d2c36  vmovaps xmm7, [rsp+0x60]
00007cf1741d2c3c  vmovaps xmm8, [rsp+0x70]
00007cf1741d2c42  vmovaps xmm9, [rsp+0x80]
00007cf1741d2c4b  vmovaps xmm10, [rsp+0x90]
00007cf1741d2c54  vmovaps xmm11, [rsp+0xA0]
00007cf1741d2c5d  vmovaps xmm12, [rsp+0xB0]
00007cf1741d2c66  vmovaps xmm13, [rsp+0xC0]
00007cf1741d2c6f  vmovaps xmm14, [rsp+0xD0]
00007cf1741d2c78  vmovaps xmm15, [rsp+0xE0]
00007cf1741d2c81  add rsp, 0xF0
00007cf1741d2c88  pop r11
00007cf1741d2c8a  pop r10
00007cf1741d2c8c  pop r9
00007cf1741d2c8e  pop r8
00007cf1741d2c90  pop rsi
00007cf1741d2c91  pop rdi
00007cf1741d2c92  pop rdx
00007cf1741d2c93  pop rcx
00007cf1741d2c94  pop rax
00007cf1741d2c95  add rsp, 0x08
00007cf1741d2c99  jmp 0x00007CF1741CFDEC
00007cf1741d2c9e  sub rsp, 0x08
00007cf1741d2ca2  push rax
00007cf1741d2ca3  push rcx
00007cf1741d2ca4  push rdx
00007cf1741d2ca5  push rdi
00007cf1741d2ca6  push rsi
00007cf1741d2ca7  push r8
00007cf1741d2ca9  push r9
00007cf1741d2cab  push r10
00007cf1741d2cad  push r11
00007cf1741d2caf  sub rsp, 0xF0
00007cf1741d2cb6  vmovaps [rsp], xmm0
00007cf1741d2cbb  vmovaps [rsp+0x10], xmm1
00007cf1741d2cc1  vmovaps [rsp+0x20], xmm2
00007cf1741d2cc7  vmovaps [rsp+0x30], xmm3
00007cf1741d2ccd  vmovaps [rsp+0x40], xmm4
00007cf1741d2cd3  vmovaps [rsp+0x50], xmm5
00007cf1741d2cd9  vmovaps [rsp+0x60], xmm6
00007cf1741d2cdf  vmovaps [rsp+0x70], xmm7
00007cf1741d2ce5  vmovaps [rsp+0x80], xmm8
00007cf1741d2cee  vmovaps [rsp+0x90], xmm9
00007cf1741d2cf7  vmovaps [rsp+0xA0], xmm10
00007cf1741d2d00  vmovaps [rsp+0xB0], xmm11
00007cf1741d2d09  vmovaps [rsp+0xC0], xmm12
00007cf1741d2d12  vmovaps [rsp+0xD0], xmm14
00007cf1741d2d1b  vmovaps [rsp+0xE0], xmm15
00007cf1741d2d24  sub rsp, 0x30
00007cf1741d2d28  movaps [rsp], xmm13
00007cf1741d2d2d  movaps [rsp+0x10], xmm10
00007cf1741d2d33  movaps [rsp+0x20], xmm1
00007cf1741d2d38  lea rdi, [rsp]
00007cf1741d2d3c  mov esi, 0x00
00007cf1741d2d41  mov rax, 0x611C8A33A530
00007cf1741d2d4b  call rax
00007cf1741d2d4d  movaps xmm13, [rsp]
00007cf1741d2d52  add rsp, 0x30
00007cf1741d2d56  vmovaps xmm0, [rsp]
00007cf1741d2d5b  vmovaps xmm1, [rsp+0x10]
00007cf1741d2d61  vmovaps xmm2, [rsp+0x20]
00007cf1741d2d67  vmovaps xmm3, [rsp+0x30]
00007cf1741d2d6d  vmovaps xmm4, [rsp+0x40]
00007cf1741d2d73  vmovaps xmm5, [rsp+0x50]
00007cf1741d2d79  vmovaps xmm6, [rsp+0x60]
00007cf1741d2d7f  vmovaps xmm7, [rsp+0x70]
00007cf1741d2d85  vmovaps xmm8, [rsp+0x80]
00007cf1741d2d8e  vmovaps xmm9, [rsp+0x90]
00007cf1741d2d97  vmovaps xmm10, [rsp+0xA0]
00007cf1741d2da0  vmovaps xmm11, [rsp+0xB0]
00007cf1741d2da9  vmovaps xmm12, [rsp+0xC0]
00007cf1741d2db2  vmovaps xmm14, [rsp+0xD0]
00007cf1741d2dbb  vmovaps xmm15, [rsp+0xE0]
00007cf1741d2dc4  add rsp, 0xF0
00007cf1741d2dcb  pop r11
00007cf1741d2dcd  pop r10
00007cf1741d2dcf  pop r9
00007cf1741d2dd1  pop r8
00007cf1741d2dd3  pop rsi
00007cf1741d2dd4  pop rdi
00007cf1741d2dd5  pop rdx
00007cf1741d2dd6  pop rcx
00007cf1741d2dd7  pop rax
00007cf1741d2dd8  add rsp, 0x08
00007cf1741d2ddc  jmp 0x00007CF1741CFE15
00007cf1741d2de1  sub rsp, 0x08
00007cf1741d2de5  push rax
00007cf1741d2de6  push rcx
00007cf1741d2de7  push rdx
00007cf1741d2de8  push rdi
00007cf1741d2de9  push rsi
00007cf1741d2dea  push r8
00007cf1741d2dec  push r9
00007cf1741d2dee  push r10
00007cf1741d2df0  push r11
00007cf1741d2df2  sub rsp, 0xF0
00007cf1741d2df9  vmovaps [rsp], xmm0
00007cf1741d2dfe  vmovaps [rsp+0x10], xmm2
00007cf1741d2e04  vmovaps [rsp+0x20], xmm3
00007cf1741d2e0a  vmovaps [rsp+0x30], xmm4
00007cf1741d2e10  vmovaps [rsp+0x40], xmm5
00007cf1741d2e16  vmovaps [rsp+0x50], xmm6
00007cf1741d2e1c  vmovaps [rsp+0x60], xmm7
00007cf1741d2e22  vmovaps [rsp+0x70], xmm8
00007cf1741d2e28  vmovaps [rsp+0x80], xmm9
00007cf1741d2e31  vmovaps [rsp+0x90], xmm10
00007cf1741d2e3a  vmovaps [rsp+0xA0], xmm11
00007cf1741d2e43  vmovaps [rsp+0xB0], xmm12
00007cf1741d2e4c  vmovaps [rsp+0xC0], xmm13
00007cf1741d2e55  vmovaps [rsp+0xD0], xmm14
00007cf1741d2e5e  vmovaps [rsp+0xE0], xmm15
00007cf1741d2e67  sub rsp, 0x30
00007cf1741d2e6b  movaps [rsp], xmm1
00007cf1741d2e6f  movaps [rsp+0x10], xmm15
00007cf1741d2e75  movaps [rsp+0x20], xmm10
00007cf1741d2e7b  lea rdi, [rsp]
00007cf1741d2e7f  mov esi, 0x00
00007cf1741d2e84  mov rax, 0x611C8A33A530
00007cf1741d2e8e  call rax
00007cf1741d2e90  movaps xmm1, [rsp]
00007cf1741d2e94  add rsp, 0x30
00007cf1741d2e98  vmovaps xmm0, [rsp]
00007cf1741d2e9d  vmovaps xmm2, [rsp+0x10]
00007cf1741d2ea3  vmovaps xmm3, [rsp+0x20]
00007cf1741d2ea9  vmovaps xmm4, [rsp+0x30]
00007cf1741d2eaf  vmovaps xmm5, [rsp+0x40]
00007cf1741d2eb5  vmovaps xmm6, [rsp+0x50]
00007cf1741d2ebb  vmovaps xmm7, [rsp+0x60]
00007cf1741d2ec1  vmovaps xmm8, [rsp+0x70]
00007cf1741d2ec7  vmovaps xmm9, [rsp+0x80]
00007cf1741d2ed0  vmovaps xmm10, [rsp+0x90]
00007cf1741d2ed9  vmovaps xmm11, [rsp+0xA0]
00007cf1741d2ee2  vmovaps xmm12, [rsp+0xB0]
00007cf1741d2eeb  vmovaps xmm13, [rsp+0xC0]
00007cf1741d2ef4  vmovaps xmm14, [rsp+0xD0]
00007cf1741d2efd  vmovaps xmm15, [rsp+0xE0]
00007cf1741d2f06  add rsp, 0xF0
00007cf1741d2f0d  pop r11
00007cf1741d2f0f  pop r10
00007cf1741d2f11  pop r9
00007cf1741d2f13  pop r8
00007cf1741d2f15  pop rsi
00007cf1741d2f16  pop rdi
00007cf1741d2f17  pop rdx
00007cf1741d2f18  pop rcx
00007cf1741d2f19  pop rax
00007cf1741d2f1a  add rsp, 0x08
00007cf1741d2f1e  jmp 0x00007CF1741CFE34
00007cf1741d2f23  sub rsp, 0x08
00007cf1741d2f27  push rax
00007cf1741d2f28  push rcx
00007cf1741d2f29  push rdx
00007cf1741d2f2a  push rdi
00007cf1741d2f2b  push rsi
00007cf1741d2f2c  push r8
00007cf1741d2f2e  push r9
00007cf1741d2f30  push r10
00007cf1741d2f32  push r11
00007cf1741d2f34  sub rsp, 0xF0
00007cf1741d2f3b  vmovaps [rsp], xmm0
00007cf1741d2f40  vmovaps [rsp+0x10], xmm1
00007cf1741d2f46  vmovaps [rsp+0x20], xmm2
00007cf1741d2f4c  vmovaps [rsp+0x30], xmm3
00007cf1741d2f52  vmovaps [rsp+0x40], xmm4
00007cf1741d2f58  vmovaps [rsp+0x50], xmm5
00007cf1741d2f5e  vmovaps [rsp+0x60], xmm6
00007cf1741d2f64  vmovaps [rsp+0x70], xmm7
00007cf1741d2f6a  vmovaps [rsp+0x80], xmm8
00007cf1741d2f73  vmovaps [rsp+0x90], xmm9
00007cf1741d2f7c  vmovaps [rsp+0xA0], xmm10
00007cf1741d2f85  vmovaps [rsp+0xB0], xmm11
00007cf1741d2f8e  vmovaps [rsp+0xC0], xmm12
00007cf1741d2f97  vmovaps [rsp+0xD0], xmm13
00007cf1741d2fa0  vmovaps [rsp+0xE0], xmm14
00007cf1741d2fa9  sub rsp, 0x30
00007cf1741d2fad  movaps [rsp], xmm15
00007cf1741d2fb2  movaps [rsp+0x10], xmm10
00007cf1741d2fb8  movaps [rsp+0x20], xmm11
00007cf1741d2fbe  lea rdi, [rsp]
00007cf1741d2fc2  mov esi, 0x00
00007cf1741d2fc7  mov rax, 0x611C8A33A530
00007cf1741d2fd1  call rax
00007cf1741d2fd3  movaps xmm15, [rsp]
00007cf1741d2fd8  add rsp, 0x30
00007cf1741d2fdc  vmovaps xmm0, [rsp]
00007cf1741d2fe1  vmovaps xmm1, [rsp+0x10]
00007cf1741d2fe7  vmovaps xmm2, [rsp+0x20]
00007cf1741d2fed  vmovaps xmm3, [rsp+0x30]
00007cf1741d2ff3  vmovaps xmm4, [rsp+0x40]
00007cf1741d2ff9  vmovaps xmm5, [rsp+0x50]
00007cf1741d2fff  vmovaps xmm6, [rsp+0x60]
00007cf1741d3005  vmovaps xmm7, [rsp+0x70]
00007cf1741d300b  vmovaps xmm8, [rsp+0x80]
00007cf1741d3014  vmovaps xmm9, [rsp+0x90]
00007cf1741d301d  vmovaps xmm10, [rsp+0xA0]
00007cf1741d3026  vmovaps xmm11, [rsp+0xB0]
00007cf1741d302f  vmovaps xmm12, [rsp+0xC0]
00007cf1741d3038  vmovaps xmm13, [rsp+0xD0]
00007cf1741d3041  vmovaps xmm14, [rsp+0xE0]
00007cf1741d304a  add rsp, 0xF0
00007cf1741d3051  pop r11
00007cf1741d3053  pop r10
00007cf1741d3055  pop r9
00007cf1741d3057  pop r8
00007cf1741d3059  pop rsi
00007cf1741d305a  pop rdi
00007cf1741d305b  pop rdx
00007cf1741d305c  pop rcx
00007cf1741d305d  pop rax
00007cf1741d305e  add rsp, 0x08
00007cf1741d3062  jmp 0x00007CF1741CFE57
00007cf1741d3067  sub rsp, 0x08
00007cf1741d306b  push rax
00007cf1741d306c  push rcx
00007cf1741d306d  push rdx
00007cf1741d306e  push rdi
00007cf1741d306f  push rsi
00007cf1741d3070  push r8
00007cf1741d3072  push r9
00007cf1741d3074  push r10
00007cf1741d3076  push r11
00007cf1741d3078  sub rsp, 0xF0
00007cf1741d307f  vmovaps [rsp], xmm0
00007cf1741d3084  vmovaps [rsp+0x10], xmm1
00007cf1741d308a  vmovaps [rsp+0x20], xmm2
00007cf1741d3090  vmovaps [rsp+0x30], xmm3
00007cf1741d3096  vmovaps [rsp+0x40], xmm4
00007cf1741d309c  vmovaps [rsp+0x50], xmm5
00007cf1741d30a2  vmovaps [rsp+0x60], xmm6
00007cf1741d30a8  vmovaps [rsp+0x70], xmm7
00007cf1741d30ae  vmovaps [rsp+0x80], xmm8
00007cf1741d30b7  vmovaps [rsp+0x90], xmm9
00007cf1741d30c0  vmovaps [rsp+0xA0], xmm11
00007cf1741d30c9  vmovaps [rsp+0xB0], xmm12
00007cf1741d30d2  vmovaps [rsp+0xC0], xmm13
00007cf1741d30db  vmovaps [rsp+0xD0], xmm14
00007cf1741d30e4  vmovaps [rsp+0xE0], xmm15
00007cf1741d30ed  sub rsp, 0x30
00007cf1741d30f1  movaps [rsp], xmm10
00007cf1741d30f6  movaps [rsp+0x10], xmm12
00007cf1741d30fc  movaps [rsp+0x20], xmm11
00007cf1741d3102  lea rdi, [rsp]
00007cf1741d3106  mov esi, 0x00
00007cf1741d310b  mov rax, 0x611C8A33A530
00007cf1741d3115  call rax
00007cf1741d3117  movaps xmm10, [rsp]
00007cf1741d311c  add rsp, 0x30
00007cf1741d3120  vmovaps xmm0, [rsp]
00007cf1741d3125  vmovaps xmm1, [rsp+0x10]
00007cf1741d312b  vmovaps xmm2, [rsp+0x20]
00007cf1741d3131  vmovaps xmm3, [rsp+0x30]
00007cf1741d3137  vmovaps xmm4, [rsp+0x40]
00007cf1741d313d  vmovaps xmm5, [rsp+0x50]
00007cf1741d3143  vmovaps xmm6, [rsp+0x60]
00007cf1741d3149  vmovaps xmm7, [rsp+0x70]
00007cf1741d314f  vmovaps xmm8, [rsp+0x80]
00007cf1741d3158  vmovaps xmm9, [rsp+0x90]
00007cf1741d3161  vmovaps xmm11, [rsp+0xA0]
00007cf1741d316a  vmovaps xmm12, [rsp+0xB0]
00007cf1741d3173  vmovaps xmm13, [rsp+0xC0]
00007cf1741d317c  vmovaps xmm14, [rsp+0xD0]
00007cf1741d3185  vmovaps xmm15, [rsp+0xE0]
00007cf1741d318e  add rsp, 0xF0
00007cf1741d3195  pop r11
00007cf1741d3197  pop r10
00007cf1741d3199  pop r9
00007cf1741d319b  pop r8
00007cf1741d319d  pop rsi
00007cf1741d319e  pop rdi
00007cf1741d319f  pop rdx
00007cf1741d31a0  pop rcx
00007cf1741d31a1  pop rax
00007cf1741d31a2  add rsp, 0x08
00007cf1741d31a6  jmp 0x00007CF1741CFE80
00007cf1741d31ab  sub rsp, 0x08
00007cf1741d31af  push rax
00007cf1741d31b0  push rcx
00007cf1741d31b1  push rdx
00007cf1741d31b2  push rdi
00007cf1741d31b3  push rsi
00007cf1741d31b4  push r8
00007cf1741d31b6  push r9
00007cf1741d31b8  push r10
00007cf1741d31ba  push r11
00007cf1741d31bc  sub rsp, 0xF0
00007cf1741d31c3  vmovaps [rsp], xmm0
00007cf1741d31c8  vmovaps [rsp+0x10], xmm1
00007cf1741d31ce  vmovaps [rsp+0x20], xmm2
00007cf1741d31d4  vmovaps [rsp+0x30], xmm3
00007cf1741d31da  vmovaps [rsp+0x40], xmm4
00007cf1741d31e0  vmovaps [rsp+0x50], xmm5
00007cf1741d31e6  vmovaps [rsp+0x60], xmm6
00007cf1741d31ec  vmovaps [rsp+0x70], xmm7
00007cf1741d31f2  vmovaps [rsp+0x80], xmm8
00007cf1741d31fb  vmovaps [rsp+0x90], xmm9
00007cf1741d3204  vmovaps [rsp+0xA0], xmm10
00007cf1741d320d  vmovaps [rsp+0xB0], xmm12
00007cf1741d3216  vmovaps [rsp+0xC0], xmm13
00007cf1741d321f  vmovaps [rsp+0xD0], xmm14
00007cf1741d3228  vmovaps [rsp+0xE0], xmm15
00007cf1741d3231  sub rsp, 0x30
00007cf1741d3235  movaps [rsp], xmm11
00007cf1741d323a  movaps [rsp+0x10], xmm2
00007cf1741d323f  movaps [rsp+0x20], xmm12
00007cf1741d3245  lea rdi, [rsp]
00007cf1741d3249  mov esi, 0x00
00007cf1741d324e  mov rax, 0x611C8A33A530
00007cf1741d3258  call rax
00007cf1741d325a  movaps xmm11, [rsp]
00007cf1741d325f  add rsp, 0x30
00007cf1741d3263  vmovaps xmm0, [rsp]
00007cf1741d3268  vmovaps xmm1, [rsp+0x10]
00007cf1741d326e  vmovaps xmm2, [rsp+0x20]
00007cf1741d3274  vmovaps xmm3, [rsp+0x30]
00007cf1741d327a  vmovaps xmm4, [rsp+0x40]
00007cf1741d3280  vmovaps xmm5, [rsp+0x50]
00007cf1741d3286  vmovaps xmm6, [rsp+0x60]
00007cf1741d328c  vmovaps xmm7, [rsp+0x70]
00007cf1741d3292  vmovaps xmm8, [rsp+0x80]
00007cf1741d329b  vmovaps xmm9, [rsp+0x90]
00007cf1741d32a4  vmovaps xmm10, [rsp+0xA0]
00007cf1741d32ad  vmovaps xmm12, [rsp+0xB0]
00007cf1741d32b6  vmovaps xmm13, [rsp+0xC0]
00007cf1741d32bf  vmovaps xmm14, [rsp+0xD0]
00007cf1741d32c8  vmovaps xmm15, [rsp+0xE0]
00007cf1741d32d1  add rsp, 0xF0
00007cf1741d32d8  pop r11
00007cf1741d32da  pop r10
00007cf1741d32dc  pop r9
00007cf1741d32de  pop r8
00007cf1741d32e0  pop rsi
00007cf1741d32e1  pop rdi
00007cf1741d32e2  pop rdx
00007cf1741d32e3  pop rcx
00007cf1741d32e4  pop rax
00007cf1741d32e5  add rsp, 0x08
00007cf1741d32e9  jmp 0x00007CF1741CFEB8
00007cf1741d32ee  sub rsp, 0x08
00007cf1741d32f2  push rax
00007cf1741d32f3  push rcx
00007cf1741d32f4  push rdx
00007cf1741d32f5  push rdi
00007cf1741d32f6  push rsi
00007cf1741d32f7  push r8
00007cf1741d32f9  push r9
00007cf1741d32fb  push r10
00007cf1741d32fd  push r11
00007cf1741d32ff  sub rsp, 0xF0
00007cf1741d3306  vmovaps [rsp], xmm0
00007cf1741d330b  vmovaps [rsp+0x10], xmm2
00007cf1741d3311  vmovaps [rsp+0x20], xmm3
00007cf1741d3317  vmovaps [rsp+0x30], xmm4
00007cf1741d331d  vmovaps [rsp+0x40], xmm5
00007cf1741d3323  vmovaps [rsp+0x50], xmm6
00007cf1741d3329  vmovaps [rsp+0x60], xmm7
00007cf1741d332f  vmovaps [rsp+0x70], xmm8
00007cf1741d3335  vmovaps [rsp+0x80], xmm9
00007cf1741d333e  vmovaps [rsp+0x90], xmm10
00007cf1741d3347  vmovaps [rsp+0xA0], xmm11
00007cf1741d3350  vmovaps [rsp+0xB0], xmm12
00007cf1741d3359  vmovaps [rsp+0xC0], xmm13
00007cf1741d3362  vmovaps [rsp+0xD0], xmm14
00007cf1741d336b  vmovaps [rsp+0xE0], xmm15
00007cf1741d3374  sub rsp, 0x30
00007cf1741d3378  movaps [rsp], xmm1
00007cf1741d337c  movaps [rsp+0x10], xmm14
00007cf1741d3382  movaps [rsp+0x20], xmm6
00007cf1741d3387  lea rdi, [rsp]
00007cf1741d338b  mov esi, 0x00
00007cf1741d3390  mov rax, 0x611C8A33A530
00007cf1741d339a  call rax
00007cf1741d339c  movaps xmm1, [rsp]
00007cf1741d33a0  add rsp, 0x30
00007cf1741d33a4  vmovaps xmm0, [rsp]
00007cf1741d33a9  vmovaps xmm2, [rsp+0x10]
00007cf1741d33af  vmovaps xmm3, [rsp+0x20]
00007cf1741d33b5  vmovaps xmm4, [rsp+0x30]
00007cf1741d33bb  vmovaps xmm5, [rsp+0x40]
00007cf1741d33c1  vmovaps xmm6, [rsp+0x50]
00007cf1741d33c7  vmovaps xmm7, [rsp+0x60]
00007cf1741d33cd  vmovaps xmm8, [rsp+0x70]
00007cf1741d33d3  vmovaps xmm9, [rsp+0x80]
00007cf1741d33dc  vmovaps xmm10, [rsp+0x90]
00007cf1741d33e5  vmovaps xmm11, [rsp+0xA0]
00007cf1741d33ee  vmovaps xmm12, [rsp+0xB0]
00007cf1741d33f7  vmovaps xmm13, [rsp+0xC0]
00007cf1741d3400  vmovaps xmm14, [rsp+0xD0]
00007cf1741d3409  vmovaps xmm15, [rsp+0xE0]
00007cf1741d3412  add rsp, 0xF0
00007cf1741d3419  pop r11
00007cf1741d341b  pop r10
00007cf1741d341d  pop r9
00007cf1741d341f  pop r8
00007cf1741d3421  pop rsi
00007cf1741d3422  pop rdi
00007cf1741d3423  pop rdx
00007cf1741d3424  pop rcx
00007cf1741d3425  pop rax
00007cf1741d3426  add rsp, 0x08
00007cf1741d342a  jmp 0x00007CF1741CFED1
00007cf1741d342f  sub rsp, 0x08
00007cf1741d3433  push rax
00007cf1741d3434  push rcx
00007cf1741d3435  push rdx
00007cf1741d3436  push rdi
00007cf1741d3437  push rsi
00007cf1741d3438  push r8
00007cf1741d343a  push r9
00007cf1741d343c  push r10
00007cf1741d343e  push r11
00007cf1741d3440  sub rsp, 0xF0
00007cf1741d3447  vmovaps [rsp], xmm0
00007cf1741d344c  vmovaps [rsp+0x10], xmm1
00007cf1741d3452  vmovaps [rsp+0x20], xmm2
00007cf1741d3458  vmovaps [rsp+0x30], xmm3
00007cf1741d345e  vmovaps [rsp+0x40], xmm4
00007cf1741d3464  vmovaps [rsp+0x50], xmm5
00007cf1741d346a  vmovaps [rsp+0x60], xmm6
00007cf1741d3470  vmovaps [rsp+0x70], xmm7
00007cf1741d3476  vmovaps [rsp+0x80], xmm8
00007cf1741d347f  vmovaps [rsp+0x90], xmm9
00007cf1741d3488  vmovaps [rsp+0xA0], xmm10
00007cf1741d3491  vmovaps [rsp+0xB0], xmm11
00007cf1741d349a  vmovaps [rsp+0xC0], xmm12
00007cf1741d34a3  vmovaps [rsp+0xD0], xmm13
00007cf1741d34ac  vmovaps [rsp+0xE0], xmm15
00007cf1741d34b5  sub rsp, 0x30
00007cf1741d34b9  movaps [rsp], xmm14
00007cf1741d34be  movaps [rsp+0x10], xmm12
00007cf1741d34c4  movaps [rsp+0x20], xmm5
00007cf1741d34c9  lea rdi, [rsp]
00007cf1741d34cd  mov esi, 0x00
00007cf1741d34d2  mov rax, 0x611C8A33A530
00007cf1741d34dc  call rax
00007cf1741d34de  movaps xmm14, [rsp]
00007cf1741d34e3  add rsp, 0x30
00007cf1741d34e7  vmovaps xmm0, [rsp]
00007cf1741d34ec  vmovaps xmm1, [rsp+0x10]
00007cf1741d34f2  vmovaps xmm2, [rsp+0x20]
00007cf1741d34f8  vmovaps xmm3, [rsp+0x30]
00007cf1741d34fe  vmovaps xmm4, [rsp+0x40]
00007cf1741d3504  vmovaps xmm5, [rsp+0x50]
00007cf1741d350a  vmovaps xmm6, [rsp+0x60]
00007cf1741d3510  vmovaps xmm7, [rsp+0x70]
00007cf1741d3516  vmovaps xmm8, [rsp+0x80]
00007cf1741d351f  vmovaps xmm9, [rsp+0x90]
00007cf1741d3528  vmovaps xmm10, [rsp+0xA0]
00007cf1741d3531  vmovaps xmm11, [rsp+0xB0]
00007cf1741d353a  vmovaps xmm12, [rsp+0xC0]
00007cf1741d3543  vmovaps xmm13, [rsp+0xD0]
00007cf1741d354c  vmovaps xmm15, [rsp+0xE0]
00007cf1741d3555  add rsp, 0xF0
00007cf1741d355c  pop r11
00007cf1741d355e  pop r10
00007cf1741d3560  pop r9
00007cf1741d3562  pop r8
00007cf1741d3564  pop rsi
00007cf1741d3565  pop rdi
00007cf1741d3566  pop rdx
00007cf1741d3567  pop rcx
00007cf1741d3568  pop rax
00007cf1741d3569  add rsp, 0x08
00007cf1741d356d  jmp 0x00007CF1741CFEF1
00007cf1741d3572  sub rsp, 0x08
00007cf1741d3576  push rax
00007cf1741d3577  push rcx
00007cf1741d3578  push rdx
00007cf1741d3579  push rdi
00007cf1741d357a  push rsi
00007cf1741d357b  push r8
00007cf1741d357d  push r9
00007cf1741d357f  push r10
00007cf1741d3581  push r11
00007cf1741d3583  sub rsp, 0xF0
00007cf1741d358a  vmovaps [rsp], xmm0
00007cf1741d358f  vmovaps [rsp+0x10], xmm1
00007cf1741d3595  vmovaps [rsp+0x20], xmm2
00007cf1741d359b  vmovaps [rsp+0x30], xmm3
00007cf1741d35a1  vmovaps [rsp+0x40], xmm4
00007cf1741d35a7  vmovaps [rsp+0x50], xmm5
00007cf1741d35ad  vmovaps [rsp+0x60], xmm7
00007cf1741d35b3  vmovaps [rsp+0x70], xmm8
00007cf1741d35b9  vmovaps [rsp+0x80], xmm9
00007cf1741d35c2  vmovaps [rsp+0x90], xmm10
00007cf1741d35cb  vmovaps [rsp+0xA0], xmm11
00007cf1741d35d4  vmovaps [rsp+0xB0], xmm12
00007cf1741d35dd  vmovaps [rsp+0xC0], xmm13
00007cf1741d35e6  vmovaps [rsp+0xD0], xmm14
00007cf1741d35ef  vmovaps [rsp+0xE0], xmm15
00007cf1741d35f8  sub rsp, 0x30
00007cf1741d35fc  movaps [rsp], xmm6
00007cf1741d3600  movaps [rsp+0x10], xmm9
00007cf1741d3606  movaps [rsp+0x20], xmm12
00007cf1741d360c  lea rdi, [rsp]
00007cf1741d3610  mov esi, 0x00
00007cf1741d3615  mov rax, 0x611C8A33A530
00007cf1741d361f  call rax
00007cf1741d3621  movaps xmm6, [rsp]
00007cf1741d3625  add rsp, 0x30
00007cf1741d3629  vmovaps xmm0, [rsp]
00007cf1741d362e  vmovaps xmm1, [rsp+0x10]
00007cf1741d3634  vmovaps xmm2, [rsp+0x20]
00007cf1741d363a  vmovaps xmm3, [rsp+0x30]
00007cf1741d3640  vmovaps xmm4, [rsp+0x40]
00007cf1741d3646  vmovaps xmm5, [rsp+0x50]
00007cf1741d364c  vmovaps xmm7, [rsp+0x60]
00007cf1741d3652  vmovaps xmm8, [rsp+0x70]
00007cf1741d3658  vmovaps xmm9, [rsp+0x80]
00007cf1741d3661  vmovaps xmm10, [rsp+0x90]
00007cf1741d366a  vmovaps xmm11, [rsp+0xA0]
00007cf1741d3673  vmovaps xmm12, [rsp+0xB0]
00007cf1741d367c  vmovaps xmm13, [rsp+0xC0]
00007cf1741d3685  vmovaps xmm14, [rsp+0xD0]
00007cf1741d368e  vmovaps xmm15, [rsp+0xE0]
00007cf1741d3697  add rsp, 0xF0
00007cf1741d369e  pop r11
00007cf1741d36a0  pop r10
00007cf1741d36a2  pop r9
00007cf1741d36a4  pop r8
00007cf1741d36a6  pop rsi
00007cf1741d36a7  pop rdi
00007cf1741d36a8  pop rdx
00007cf1741d36a9  pop rcx
00007cf1741d36aa  pop rax
00007cf1741d36ab  add rsp, 0x08
00007cf1741d36af  jmp 0x00007CF1741CFF19
00007cf1741d36b4  sub rsp, 0x08
00007cf1741d36b8  push rax
00007cf1741d36b9  push rcx
00007cf1741d36ba  push rdx
00007cf1741d36bb  push rdi
00007cf1741d36bc  push rsi
00007cf1741d36bd  push r8
00007cf1741d36bf  push r9
00007cf1741d36c1  push r10
00007cf1741d36c3  push r11
00007cf1741d36c5  sub rsp, 0xF0
00007cf1741d36cc  vmovaps [rsp], xmm0
00007cf1741d36d1  vmovaps [rsp+0x10], xmm1
00007cf1741d36d7  vmovaps [rsp+0x20], xmm2
00007cf1741d36dd  vmovaps [rsp+0x30], xmm3
00007cf1741d36e3  vmovaps [rsp+0x40], xmm4
00007cf1741d36e9  vmovaps [rsp+0x50], xmm5
00007cf1741d36ef  vmovaps [rsp+0x60], xmm6
00007cf1741d36f5  vmovaps [rsp+0x70], xmm7
00007cf1741d36fb  vmovaps [rsp+0x80], xmm8
00007cf1741d3704  vmovaps [rsp+0x90], xmm9
00007cf1741d370d  vmovaps [rsp+0xA0], xmm10
00007cf1741d3716  vmovaps [rsp+0xB0], xmm11
00007cf1741d371f  vmovaps [rsp+0xC0], xmm13
00007cf1741d3728  vmovaps [rsp+0xD0], xmm14
00007cf1741d3731  vmovaps [rsp+0xE0], xmm15
00007cf1741d373a  sub rsp, 0x30
00007cf1741d373e  movaps [rsp], xmm12
00007cf1741d3743  movaps [rsp+0x10], xmm15
00007cf1741d3749  movaps [rsp+0x20], xmm13
00007cf1741d374f  lea rdi, [rsp]
00007cf1741d3753  mov esi, 0x00
00007cf1741d3758  mov rax, 0x611C8A33A530
00007cf1741d3762  call rax
00007cf1741d3764  movaps xmm12, [rsp]
00007cf1741d3769  add rsp, 0x30
00007cf1741d376d  vmovaps xmm0, [rsp]
00007cf1741d3772  vmovaps xmm1, [rsp+0x10]
00007cf1741d3778  vmovaps xmm2, [rsp+0x20]
00007cf1741d377e  vmovaps xmm3, [rsp+0x30]
00007cf1741d3784  vmovaps xmm4, [rsp+0x40]
00007cf1741d378a  vmovaps xmm5, [rsp+0x50]
00007cf1741d3790  vmovaps xmm6, [rsp+0x60]
00007cf1741d3796  vmovaps xmm7, [rsp+0x70]
00007cf1741d379c  vmovaps xmm8, [rsp+0x80]
00007cf1741d37a5  vmovaps xmm9, [rsp+0x90]
00007cf1741d37ae  vmovaps xmm10, [rsp+0xA0]
00007cf1741d37b7  vmovaps xmm11, [rsp+0xB0]
00007cf1741d37c0  vmovaps xmm13, [rsp+0xC0]
00007cf1741d37c9  vmovaps xmm14, [rsp+0xD0]
00007cf1741d37d2  vmovaps xmm15, [rsp+0xE0]
00007cf1741d37db  add rsp, 0xF0
00007cf1741d37e2  pop r11
00007cf1741d37e4  pop r10
00007cf1741d37e6  pop r9
00007cf1741d37e8  pop r8
00007cf1741d37ea  pop rsi
00007cf1741d37eb  pop rdi
00007cf1741d37ec  pop rdx
00007cf1741d37ed  pop rcx
00007cf1741d37ee  pop rax
00007cf1741d37ef  add rsp, 0x08
00007cf1741d37f3  jmp 0x00007CF1741CFF34
00007cf1741d37f8  sub rsp, 0x08
00007cf1741d37fc  push rax
00007cf1741d37fd  push rcx
00007cf1741d37fe  push rdx
00007cf1741d37ff  push rdi
00007cf1741d3800  push rsi
00007cf1741d3801  push r8
00007cf1741d3803  push r9
00007cf1741d3805  push r10
00007cf1741d3807  push r11
00007cf1741d3809  sub rsp, 0xF0
00007cf1741d3810  vmovaps [rsp], xmm0
00007cf1741d3815  vmovaps [rsp+0x10], xmm1
00007cf1741d381b  vmovaps [rsp+0x20], xmm2
00007cf1741d3821  vmovaps [rsp+0x30], xmm3
00007cf1741d3827  vmovaps [rsp+0x40], xmm4
00007cf1741d382d  vmovaps [rsp+0x50], xmm5
00007cf1741d3833  vmovaps [rsp+0x60], xmm6
00007cf1741d3839  vmovaps [rsp+0x70], xmm7
00007cf1741d383f  vmovaps [rsp+0x80], xmm8
00007cf1741d3848  vmovaps [rsp+0x90], xmm9
00007cf1741d3851  vmovaps [rsp+0xA0], xmm10
00007cf1741d385a  vmovaps [rsp+0xB0], xmm11
00007cf1741d3863  vmovaps [rsp+0xC0], xmm12
00007cf1741d386c  vmovaps [rsp+0xD0], xmm13
00007cf1741d3875  vmovaps [rsp+0xE0], xmm14
00007cf1741d387e  sub rsp, 0x30
00007cf1741d3882  movaps [rsp], xmm15
00007cf1741d3887  movaps [rsp+0x10], xmm13
00007cf1741d388d  movaps [rsp+0x20], xmm10
00007cf1741d3893  lea rdi, [rsp]
00007cf1741d3897  mov esi, 0x00
00007cf1741d389c  mov rax, 0x611C8A33A530
00007cf1741d38a6  call rax
00007cf1741d38a8  movaps xmm15, [rsp]
00007cf1741d38ad  add rsp, 0x30
00007cf1741d38b1  vmovaps xmm0, [rsp]
00007cf1741d38b6  vmovaps xmm1, [rsp+0x10]
00007cf1741d38bc  vmovaps xmm2, [rsp+0x20]
00007cf1741d38c2  vmovaps xmm3, [rsp+0x30]
00007cf1741d38c8  vmovaps xmm4, [rsp+0x40]
00007cf1741d38ce  vmovaps xmm5, [rsp+0x50]
00007cf1741d38d4  vmovaps xmm6, [rsp+0x60]
00007cf1741d38da  vmovaps xmm7, [rsp+0x70]
00007cf1741d38e0  vmovaps xmm8, [rsp+0x80]
00007cf1741d38e9  vmovaps xmm9, [rsp+0x90]
00007cf1741d38f2  vmovaps xmm10, [rsp+0xA0]
00007cf1741d38fb  vmovaps xmm11, [rsp+0xB0]
00007cf1741d3904  vmovaps xmm12, [rsp+0xC0]
00007cf1741d390d  vmovaps xmm13, [rsp+0xD0]
00007cf1741d3916  vmovaps xmm14, [rsp+0xE0]
00007cf1741d391f  add rsp, 0xF0
00007cf1741d3926  pop r11
00007cf1741d3928  pop r10
00007cf1741d392a  pop r9
00007cf1741d392c  pop r8
00007cf1741d392e  pop rsi
00007cf1741d392f  pop rdi
00007cf1741d3930  pop rdx
00007cf1741d3931  pop rcx
00007cf1741d3932  pop rax
00007cf1741d3933  add rsp, 0x08
00007cf1741d3937  jmp 0x00007CF1741CFF55
00007cf1741d393c  call 0x00007CF17400C260
00007cf1741d3941  jmp 0x00007CF1741CFFB0
00007cf1741d3946  sub rsp, 0x08
00007cf1741d394a  push rax
00007cf1741d394b  push rcx
00007cf1741d394c  push rdx
00007cf1741d394d  push rdi
00007cf1741d394e  push rsi
00007cf1741d394f  push r8
00007cf1741d3951  push r9
00007cf1741d3953  push r10
00007cf1741d3955  push r11
00007cf1741d3957  sub rsp, 0xF0
00007cf1741d395e  vmovaps [rsp], xmm0
00007cf1741d3963  vmovaps [rsp+0x10], xmm1
00007cf1741d3969  vmovaps [rsp+0x20], xmm2
00007cf1741d396f  vmovaps [rsp+0x30], xmm3
00007cf1741d3975  vmovaps [rsp+0x40], xmm4
00007cf1741d397b  vmovaps [rsp+0x50], xmm5
00007cf1741d3981  vmovaps [rsp+0x60], xmm6
00007cf1741d3987  vmovaps [rsp+0x70], xmm7
00007cf1741d398d  vmovaps [rsp+0x80], xmm8
00007cf1741d3996  vmovaps [rsp+0x90], xmm10
00007cf1741d399f  vmovaps [rsp+0xA0], xmm11
00007cf1741d39a8  vmovaps [rsp+0xB0], xmm12
00007cf1741d39b1  vmovaps [rsp+0xC0], xmm13
00007cf1741d39ba  vmovaps [rsp+0xD0], xmm14
00007cf1741d39c3  vmovaps [rsp+0xE0], xmm15
00007cf1741d39cc  sub rsp, 0x30
00007cf1741d39d0  movaps [rsp], xmm9
00007cf1741d39d5  movaps [rsp+0x10], xmm8
00007cf1741d39db  movaps [rsp+0x20], xmm10
00007cf1741d39e1  lea rdi, [rsp]
00007cf1741d39e5  mov esi, 0x00
00007cf1741d39ea  mov rax, 0x611C8A33A530
00007cf1741d39f4  call rax
00007cf1741d39f6  movaps xmm9, [rsp]
00007cf1741d39fb  add rsp, 0x30
00007cf1741d39ff  vmovaps xmm0, [rsp]
00007cf1741d3a04  vmovaps xmm1, [rsp+0x10]
00007cf1741d3a0a  vmovaps xmm2, [rsp+0x20]
00007cf1741d3a10  vmovaps xmm3, [rsp+0x30]
00007cf1741d3a16  vmovaps xmm4, [rsp+0x40]
00007cf1741d3a1c  vmovaps xmm5, [rsp+0x50]
00007cf1741d3a22  vmovaps xmm6, [rsp+0x60]
00007cf1741d3a28  vmovaps xmm7, [rsp+0x70]
00007cf1741d3a2e  vmovaps xmm8, [rsp+0x80]
00007cf1741d3a37  vmovaps xmm10, [rsp+0x90]
00007cf1741d3a40  vmovaps xmm11, [rsp+0xA0]
00007cf1741d3a49  vmovaps xmm12, [rsp+0xB0]
00007cf1741d3a52  vmovaps xmm13, [rsp+0xC0]
00007cf1741d3a5b  vmovaps xmm14, [rsp+0xD0]
00007cf1741d3a64  vmovaps xmm15, [rsp+0xE0]
00007cf1741d3a6d  add rsp, 0xF0
00007cf1741d3a74  pop r11
00007cf1741d3a76  pop r10
00007cf1741d3a78  pop r9
00007cf1741d3a7a  pop r8
00007cf1741d3a7c  pop rsi
00007cf1741d3a7d  pop rdi
00007cf1741d3a7e  pop rdx
00007cf1741d3a7f  pop rcx
00007cf1741d3a80  pop rax
00007cf1741d3a81  add rsp, 0x08
00007cf1741d3a85  jmp 0x00007CF1741CFFE1
00007cf1741d3a8a  sub rsp, 0x08
00007cf1741d3a8e  push rax
00007cf1741d3a8f  push rcx
00007cf1741d3a90  push rdx
00007cf1741d3a91  push rdi
00007cf1741d3a92  push rsi
00007cf1741d3a93  push r8
00007cf1741d3a95  push r9
00007cf1741d3a97  push r10
00007cf1741d3a99  push r11
00007cf1741d3a9b  sub rsp, 0xF0
00007cf1741d3aa2  vmovaps [rsp], xmm0
00007cf1741d3aa7  vmovaps [rsp+0x10], xmm1
00007cf1741d3aad  vmovaps [rsp+0x20], xmm2
00007cf1741d3ab3  vmovaps [rsp+0x30], xmm3
00007cf1741d3ab9  vmovaps [rsp+0x40], xmm4
00007cf1741d3abf  vmovaps [rsp+0x50], xmm5
00007cf1741d3ac5  vmovaps [rsp+0x60], xmm6
00007cf1741d3acb  vmovaps [rsp+0x70], xmm7
00007cf1741d3ad1  vmovaps [rsp+0x80], xmm8
00007cf1741d3ada  vmovaps [rsp+0x90], xmm9
00007cf1741d3ae3  vmovaps [rsp+0xA0], xmm11
00007cf1741d3aec  vmovaps [rsp+0xB0], xmm12
00007cf1741d3af5  vmovaps [rsp+0xC0], xmm13
00007cf1741d3afe  vmovaps [rsp+0xD0], xmm14
00007cf1741d3b07  vmovaps [rsp+0xE0], xmm15
00007cf1741d3b10  sub rsp, 0x30
00007cf1741d3b14  movaps [rsp], xmm10
00007cf1741d3b19  movaps [rsp+0x10], xmm1
00007cf1741d3b1e  movaps [rsp+0x20], xmm11
00007cf1741d3b24  lea rdi, [rsp]
00007cf1741d3b28  mov esi, 0x00
00007cf1741d3b2d  mov rax, 0x611C8A33A530
00007cf1741d3b37  call rax
00007cf1741d3b39  movaps xmm10, [rsp]
00007cf1741d3b3e  add rsp, 0x30
00007cf1741d3b42  vmovaps xmm0, [rsp]
00007cf1741d3b47  vmovaps xmm1, [rsp+0x10]
00007cf1741d3b4d  vmovaps xmm2, [rsp+0x20]
00007cf1741d3b53  vmovaps xmm3, [rsp+0x30]
00007cf1741d3b59  vmovaps xmm4, [rsp+0x40]
00007cf1741d3b5f  vmovaps xmm5, [rsp+0x50]
00007cf1741d3b65  vmovaps xmm6, [rsp+0x60]
00007cf1741d3b6b  vmovaps xmm7, [rsp+0x70]
00007cf1741d3b71  vmovaps xmm8, [rsp+0x80]
00007cf1741d3b7a  vmovaps xmm9, [rsp+0x90]
00007cf1741d3b83  vmovaps xmm11, [rsp+0xA0]
00007cf1741d3b8c  vmovaps xmm12, [rsp+0xB0]
00007cf1741d3b95  vmovaps xmm13, [rsp+0xC0]
00007cf1741d3b9e  vmovaps xmm14, [rsp+0xD0]
00007cf1741d3ba7  vmovaps xmm15, [rsp+0xE0]
00007cf1741d3bb0  add rsp, 0xF0
00007cf1741d3bb7  pop r11
00007cf1741d3bb9  pop r10
00007cf1741d3bbb  pop r9
00007cf1741d3bbd  pop r8
00007cf1741d3bbf  pop rsi
00007cf1741d3bc0  pop rdi
00007cf1741d3bc1  pop rdx
00007cf1741d3bc2  pop rcx
00007cf1741d3bc3  pop rax
00007cf1741d3bc4  add rsp, 0x08
00007cf1741d3bc8  jmp 0x00007CF1741CFFFC
00007cf1741d3bcd  sub rsp, 0x08
00007cf1741d3bd1  push rax
00007cf1741d3bd2  push rcx
00007cf1741d3bd3  push rdx
00007cf1741d3bd4  push rdi
00007cf1741d3bd5  push rsi
00007cf1741d3bd6  push r8
00007cf1741d3bd8  push r9
00007cf1741d3bda  push r10
00007cf1741d3bdc  push r11
00007cf1741d3bde  sub rsp, 0xF0
00007cf1741d3be5  vmovaps [rsp], xmm0
00007cf1741d3bea  vmovaps [rsp+0x10], xmm2
00007cf1741d3bf0  vmovaps [rsp+0x20], xmm3
00007cf1741d3bf6  vmovaps [rsp+0x30], xmm4
00007cf1741d3bfc  vmovaps [rsp+0x40], xmm5
00007cf1741d3c02  vmovaps [rsp+0x50], xmm6
00007cf1741d3c08  vmovaps [rsp+0x60], xmm7
00007cf1741d3c0e  vmovaps [rsp+0x70], xmm8
00007cf1741d3c14  vmovaps [rsp+0x80], xmm9
00007cf1741d3c1d  vmovaps [rsp+0x90], xmm10
00007cf1741d3c26  vmovaps [rsp+0xA0], xmm11
00007cf1741d3c2f  vmovaps [rsp+0xB0], xmm12
00007cf1741d3c38  vmovaps [rsp+0xC0], xmm13
00007cf1741d3c41  vmovaps [rsp+0xD0], xmm14
00007cf1741d3c4a  vmovaps [rsp+0xE0], xmm15
00007cf1741d3c53  sub rsp, 0x30
00007cf1741d3c57  movaps [rsp], xmm1
00007cf1741d3c5b  movaps [rsp+0x10], xmm14
00007cf1741d3c61  movaps [rsp+0x20], xmm6
00007cf1741d3c66  lea rdi, [rsp]
00007cf1741d3c6a  mov esi, 0x00
00007cf1741d3c6f  mov rax, 0x611C8A33A530
00007cf1741d3c79  call rax
00007cf1741d3c7b  movaps xmm1, [rsp]
00007cf1741d3c7f  add rsp, 0x30
00007cf1741d3c83  vmovaps xmm0, [rsp]
00007cf1741d3c88  vmovaps xmm2, [rsp+0x10]
00007cf1741d3c8e  vmovaps xmm3, [rsp+0x20]
00007cf1741d3c94  vmovaps xmm4, [rsp+0x30]
00007cf1741d3c9a  vmovaps xmm5, [rsp+0x40]
00007cf1741d3ca0  vmovaps xmm6, [rsp+0x50]
00007cf1741d3ca6  vmovaps xmm7, [rsp+0x60]
00007cf1741d3cac  vmovaps xmm8, [rsp+0x70]
00007cf1741d3cb2  vmovaps xmm9, [rsp+0x80]
00007cf1741d3cbb  vmovaps xmm10, [rsp+0x90]
00007cf1741d3cc4  vmovaps xmm11, [rsp+0xA0]
00007cf1741d3ccd  vmovaps xmm12, [rsp+0xB0]
00007cf1741d3cd6  vmovaps xmm13, [rsp+0xC0]
00007cf1741d3cdf  vmovaps xmm14, [rsp+0xD0]
00007cf1741d3ce8  vmovaps xmm15, [rsp+0xE0]
00007cf1741d3cf1  add rsp, 0xF0
00007cf1741d3cf8  pop r11
00007cf1741d3cfa  pop r10
00007cf1741d3cfc  pop r9
00007cf1741d3cfe  pop r8
00007cf1741d3d00  pop rsi
00007cf1741d3d01  pop rdi
00007cf1741d3d02  pop rdx
00007cf1741d3d03  pop rcx
00007cf1741d3d04  pop rax
00007cf1741d3d05  add rsp, 0x08
00007cf1741d3d09  jmp 0x00007CF1741D0015
00007cf1741d3d0e  sub rsp, 0x08
00007cf1741d3d12  push rax
00007cf1741d3d13  push rcx
00007cf1741d3d14  push rdx
00007cf1741d3d15  push rdi
00007cf1741d3d16  push rsi
00007cf1741d3d17  push r8
00007cf1741d3d19  push r9
00007cf1741d3d1b  push r10
00007cf1741d3d1d  push r11
00007cf1741d3d1f  sub rsp, 0xF0
00007cf1741d3d26  vmovaps [rsp], xmm0
00007cf1741d3d2b  vmovaps [rsp+0x10], xmm1
00007cf1741d3d31  vmovaps [rsp+0x20], xmm2
00007cf1741d3d37  vmovaps [rsp+0x30], xmm3
00007cf1741d3d3d  vmovaps [rsp+0x40], xmm4
00007cf1741d3d43  vmovaps [rsp+0x50], xmm5
00007cf1741d3d49  vmovaps [rsp+0x60], xmm6
00007cf1741d3d4f  vmovaps [rsp+0x70], xmm7
00007cf1741d3d55  vmovaps [rsp+0x80], xmm8
00007cf1741d3d5e  vmovaps [rsp+0x90], xmm9
00007cf1741d3d67  vmovaps [rsp+0xA0], xmm10
00007cf1741d3d70  vmovaps [rsp+0xB0], xmm12
00007cf1741d3d79  vmovaps [rsp+0xC0], xmm13
00007cf1741d3d82  vmovaps [rsp+0xD0], xmm14
00007cf1741d3d8b  vmovaps [rsp+0xE0], xmm15
00007cf1741d3d94  sub rsp, 0x30
00007cf1741d3d98  movaps [rsp], xmm11
00007cf1741d3d9d  movaps [rsp+0x10], xmm13
00007cf1741d3da3  movaps [rsp+0x20], xmm14
00007cf1741d3da9  lea rdi, [rsp]
00007cf1741d3dad  mov esi, 0x00
00007cf1741d3db2  mov rax, 0x611C8A33A530
00007cf1741d3dbc  call rax
00007cf1741d3dbe  movaps xmm11, [rsp]
00007cf1741d3dc3  add rsp, 0x30
00007cf1741d3dc7  vmovaps xmm0, [rsp]
00007cf1741d3dcc  vmovaps xmm1, [rsp+0x10]
00007cf1741d3dd2  vmovaps xmm2, [rsp+0x20]
00007cf1741d3dd8  vmovaps xmm3, [rsp+0x30]
00007cf1741d3dde  vmovaps xmm4, [rsp+0x40]
00007cf1741d3de4  vmovaps xmm5, [rsp+0x50]
00007cf1741d3dea  vmovaps xmm6, [rsp+0x60]
00007cf1741d3df0  vmovaps xmm7, [rsp+0x70]
00007cf1741d3df6  vmovaps xmm8, [rsp+0x80]
00007cf1741d3dff  vmovaps xmm9, [rsp+0x90]
00007cf1741d3e08  vmovaps xmm10, [rsp+0xA0]
00007cf1741d3e11  vmovaps xmm12, [rsp+0xB0]
00007cf1741d3e1a  vmovaps xmm13, [rsp+0xC0]
00007cf1741d3e23  vmovaps xmm14, [rsp+0xD0]
00007cf1741d3e2c  vmovaps xmm15, [rsp+0xE0]
00007cf1741d3e35  add rsp, 0xF0
00007cf1741d3e3c  pop r11
00007cf1741d3e3e  pop r10
00007cf1741d3e40  pop r9
00007cf1741d3e42  pop r8
00007cf1741d3e44  pop rsi
00007cf1741d3e45  pop rdi
00007cf1741d3e46  pop rdx
00007cf1741d3e47  pop rcx
00007cf1741d3e48  pop rax
00007cf1741d3e49  add rsp, 0x08
00007cf1741d3e4d  jmp 0x00007CF1741D003F
00007cf1741d3e52  sub rsp, 0x08
00007cf1741d3e56  push rax
00007cf1741d3e57  push rcx
00007cf1741d3e58  push rdx
00007cf1741d3e59  push rdi
00007cf1741d3e5a  push rsi
00007cf1741d3e5b  push r8
00007cf1741d3e5d  push r9
00007cf1741d3e5f  push r10
00007cf1741d3e61  push r11
00007cf1741d3e63  sub rsp, 0xF0
00007cf1741d3e6a  vmovaps [rsp], xmm0
00007cf1741d3e6f  vmovaps [rsp+0x10], xmm1
00007cf1741d3e75  vmovaps [rsp+0x20], xmm2
00007cf1741d3e7b  vmovaps [rsp+0x30], xmm3
00007cf1741d3e81  vmovaps [rsp+0x40], xmm4
00007cf1741d3e87  vmovaps [rsp+0x50], xmm5
00007cf1741d3e8d  vmovaps [rsp+0x60], xmm6
00007cf1741d3e93  vmovaps [rsp+0x70], xmm7
00007cf1741d3e99  vmovaps [rsp+0x80], xmm8
00007cf1741d3ea2  vmovaps [rsp+0x90], xmm9
00007cf1741d3eab  vmovaps [rsp+0xA0], xmm10
00007cf1741d3eb4  vmovaps [rsp+0xB0], xmm11
00007cf1741d3ebd  vmovaps [rsp+0xC0], xmm12
00007cf1741d3ec6  vmovaps [rsp+0xD0], xmm14
00007cf1741d3ecf  vmovaps [rsp+0xE0], xmm15
00007cf1741d3ed8  sub rsp, 0x30
00007cf1741d3edc  movaps [rsp], xmm13
00007cf1741d3ee1  movaps [rsp+0x10], xmm8
00007cf1741d3ee7  movaps [rsp+0x20], xmm14
00007cf1741d3eed  lea rdi, [rsp]
00007cf1741d3ef1  mov esi, 0x00
00007cf1741d3ef6  mov rax, 0x611C8A33A530
00007cf1741d3f00  call rax
00007cf1741d3f02  movaps xmm13, [rsp]
00007cf1741d3f07  add rsp, 0x30
00007cf1741d3f0b  vmovaps xmm0, [rsp]
00007cf1741d3f10  vmovaps xmm1, [rsp+0x10]
00007cf1741d3f16  vmovaps xmm2, [rsp+0x20]
00007cf1741d3f1c  vmovaps xmm3, [rsp+0x30]
00007cf1741d3f22  vmovaps xmm4, [rsp+0x40]
00007cf1741d3f28  vmovaps xmm5, [rsp+0x50]
00007cf1741d3f2e  vmovaps xmm6, [rsp+0x60]
00007cf1741d3f34  vmovaps xmm7, [rsp+0x70]
00007cf1741d3f3a  vmovaps xmm8, [rsp+0x80]
00007cf1741d3f43  vmovaps xmm9, [rsp+0x90]
00007cf1741d3f4c  vmovaps xmm10, [rsp+0xA0]
00007cf1741d3f55  vmovaps xmm11, [rsp+0xB0]
00007cf1741d3f5e  vmovaps xmm12, [rsp+0xC0]
00007cf1741d3f67  vmovaps xmm14, [rsp+0xD0]
00007cf1741d3f70  vmovaps xmm15, [rsp+0xE0]
00007cf1741d3f79  add rsp, 0xF0
00007cf1741d3f80  pop r11
00007cf1741d3f82  pop r10
00007cf1741d3f84  pop r9
00007cf1741d3f86  pop r8
00007cf1741d3f88  pop rsi
00007cf1741d3f89  pop rdi
00007cf1741d3f8a  pop rdx
00007cf1741d3f8b  pop rcx
00007cf1741d3f8c  pop rax
00007cf1741d3f8d  add rsp, 0x08
00007cf1741d3f91  jmp 0x00007CF1741D006E
00007cf1741d3f96  sub rsp, 0x08
00007cf1741d3f9a  push rax
00007cf1741d3f9b  push rcx
00007cf1741d3f9c  push rdx
00007cf1741d3f9d  push rdi
00007cf1741d3f9e  push rsi
00007cf1741d3f9f  push r8
00007cf1741d3fa1  push r9
00007cf1741d3fa3  push r10
00007cf1741d3fa5  push r11
00007cf1741d3fa7  sub rsp, 0xF0
00007cf1741d3fae  vmovaps [rsp], xmm0
00007cf1741d3fb3  vmovaps [rsp+0x10], xmm1
00007cf1741d3fb9  vmovaps [rsp+0x20], xmm2
00007cf1741d3fbf  vmovaps [rsp+0x30], xmm3
00007cf1741d3fc5  vmovaps [rsp+0x40], xmm4
00007cf1741d3fcb  vmovaps [rsp+0x50], xmm5
00007cf1741d3fd1  vmovaps [rsp+0x60], xmm6
00007cf1741d3fd7  vmovaps [rsp+0x70], xmm7
00007cf1741d3fdd  vmovaps [rsp+0x80], xmm9
00007cf1741d3fe6  vmovaps [rsp+0x90], xmm10
00007cf1741d3fef  vmovaps [rsp+0xA0], xmm11
00007cf1741d3ff8  vmovaps [rsp+0xB0], xmm12
00007cf1741d4001  vmovaps [rsp+0xC0], xmm13
00007cf1741d400a  vmovaps [rsp+0xD0], xmm14
00007cf1741d4013  vmovaps [rsp+0xE0], xmm15
00007cf1741d401c  sub rsp, 0x30
00007cf1741d4020  movaps [rsp], xmm8
00007cf1741d4025  movaps [rsp+0x10], xmm7
00007cf1741d402a  movaps [rsp+0x20], xmm14
00007cf1741d4030  lea rdi, [rsp]
00007cf1741d4034  mov esi, 0x00
00007cf1741d4039  mov rax, 0x611C8A33A530
00007cf1741d4043  call rax
00007cf1741d4045  movaps xmm8, [rsp]
00007cf1741d404a  add rsp, 0x30
00007cf1741d404e  vmovaps xmm0, [rsp]
00007cf1741d4053  vmovaps xmm1, [rsp+0x10]
00007cf1741d4059  vmovaps xmm2, [rsp+0x20]
00007cf1741d405f  vmovaps xmm3, [rsp+0x30]
00007cf1741d4065  vmovaps xmm4, [rsp+0x40]
00007cf1741d406b  vmovaps xmm5, [rsp+0x50]
00007cf1741d4071  vmovaps xmm6, [rsp+0x60]
00007cf1741d4077  vmovaps xmm7, [rsp+0x70]
00007cf1741d407d  vmovaps xmm9, [rsp+0x80]
00007cf1741d4086  vmovaps xmm10, [rsp+0x90]
00007cf1741d408f  vmovaps xmm11, [rsp+0xA0]
00007cf1741d4098  vmovaps xmm12, [rsp+0xB0]
00007cf1741d40a1  vmovaps xmm13, [rsp+0xC0]
00007cf1741d40aa  vmovaps xmm14, [rsp+0xD0]
00007cf1741d40b3  vmovaps xmm15, [rsp+0xE0]
00007cf1741d40bc  add rsp, 0xF0
00007cf1741d40c3  pop r11
00007cf1741d40c5  pop r10
00007cf1741d40c7  pop r9
00007cf1741d40c9  pop r8
00007cf1741d40cb  pop rsi
00007cf1741d40cc  pop rdi
00007cf1741d40cd  pop rdx
00007cf1741d40ce  pop rcx
00007cf1741d40cf  pop rax
00007cf1741d40d0  add rsp, 0x08
00007cf1741d40d4  jmp 0x00007CF1741D0094
00007cf1741d40d9  sub rsp, 0x08
00007cf1741d40dd  push rax
00007cf1741d40de  push rcx
00007cf1741d40df  push rdx
00007cf1741d40e0  push rdi
00007cf1741d40e1  push rsi
00007cf1741d40e2  push r8
00007cf1741d40e4  push r9
00007cf1741d40e6  push r10
00007cf1741d40e8  push r11
00007cf1741d40ea  sub rsp, 0xF0
00007cf1741d40f1  vmovaps [rsp], xmm0
00007cf1741d40f6  vmovaps [rsp+0x10], xmm1
00007cf1741d40fc  vmovaps [rsp+0x20], xmm2
00007cf1741d4102  vmovaps [rsp+0x30], xmm3
00007cf1741d4108  vmovaps [rsp+0x40], xmm4
00007cf1741d410e  vmovaps [rsp+0x50], xmm5
00007cf1741d4114  vmovaps [rsp+0x60], xmm6
00007cf1741d411a  vmovaps [rsp+0x70], xmm7
00007cf1741d4120  vmovaps [rsp+0x80], xmm8
00007cf1741d4129  vmovaps [rsp+0x90], xmm9
00007cf1741d4132  vmovaps [rsp+0xA0], xmm10
00007cf1741d413b  vmovaps [rsp+0xB0], xmm11
00007cf1741d4144  vmovaps [rsp+0xC0], xmm12
00007cf1741d414d  vmovaps [rsp+0xD0], xmm13
00007cf1741d4156  vmovaps [rsp+0xE0], xmm15
00007cf1741d415f  sub rsp, 0x30
00007cf1741d4163  movaps [rsp], xmm14
00007cf1741d4168  movaps [rsp+0x10], xmm12
00007cf1741d416e  movaps [rsp+0x20], xmm9
00007cf1741d4174  lea rdi, [rsp]
00007cf1741d4178  mov esi, 0x00
00007cf1741d417d  mov rax, 0x611C8A33A530
00007cf1741d4187  call rax
00007cf1741d4189  movaps xmm14, [rsp]
00007cf1741d418e  add rsp, 0x30
00007cf1741d4192  vmovaps xmm0, [rsp]
00007cf1741d4197  vmovaps xmm1, [rsp+0x10]
00007cf1741d419d  vmovaps xmm2, [rsp+0x20]
00007cf1741d41a3  vmovaps xmm3, [rsp+0x30]
00007cf1741d41a9  vmovaps xmm4, [rsp+0x40]
00007cf1741d41af  vmovaps xmm5, [rsp+0x50]
00007cf1741d41b5  vmovaps xmm6, [rsp+0x60]
00007cf1741d41bb  vmovaps xmm7, [rsp+0x70]
00007cf1741d41c1  vmovaps xmm8, [rsp+0x80]
00007cf1741d41ca  vmovaps xmm9, [rsp+0x90]
00007cf1741d41d3  vmovaps xmm10, [rsp+0xA0]
00007cf1741d41dc  vmovaps xmm11, [rsp+0xB0]
00007cf1741d41e5  vmovaps xmm12, [rsp+0xC0]
00007cf1741d41ee  vmovaps xmm13, [rsp+0xD0]
00007cf1741d41f7  vmovaps xmm15, [rsp+0xE0]
00007cf1741d4200  add rsp, 0xF0
00007cf1741d4207  pop r11
00007cf1741d4209  pop r10
00007cf1741d420b  pop r9
00007cf1741d420d  pop r8
00007cf1741d420f  pop rsi
00007cf1741d4210  pop rdi
00007cf1741d4211  pop rdx
00007cf1741d4212  pop rcx
00007cf1741d4213  pop rax
00007cf1741d4214  add rsp, 0x08
00007cf1741d4218  jmp 0x00007CF1741D00AE
00007cf1741d421d  sub rsp, 0x08
00007cf1741d4221  push rax
00007cf1741d4222  push rcx
00007cf1741d4223  push rdx
00007cf1741d4224  push rdi
00007cf1741d4225  push rsi
00007cf1741d4226  push r8
00007cf1741d4228  push r9
00007cf1741d422a  push r10
00007cf1741d422c  push r11
00007cf1741d422e  sub rsp, 0xF0
00007cf1741d4235  vmovaps [rsp], xmm0
00007cf1741d423a  vmovaps [rsp+0x10], xmm1
00007cf1741d4240  vmovaps [rsp+0x20], xmm2
00007cf1741d4246  vmovaps [rsp+0x30], xmm3
00007cf1741d424c  vmovaps [rsp+0x40], xmm4
00007cf1741d4252  vmovaps [rsp+0x50], xmm5
00007cf1741d4258  vmovaps [rsp+0x60], xmm6
00007cf1741d425e  vmovaps [rsp+0x70], xmm7
00007cf1741d4264  vmovaps [rsp+0x80], xmm8
00007cf1741d426d  vmovaps [rsp+0x90], xmm10
00007cf1741d4276  vmovaps [rsp+0xA0], xmm11
00007cf1741d427f  vmovaps [rsp+0xB0], xmm12
00007cf1741d4288  vmovaps [rsp+0xC0], xmm13
00007cf1741d4291  vmovaps [rsp+0xD0], xmm14
00007cf1741d429a  vmovaps [rsp+0xE0], xmm15
00007cf1741d42a3  sub rsp, 0x30
00007cf1741d42a7  movaps [rsp], xmm9
00007cf1741d42ac  movaps [rsp+0x10], xmm7
00007cf1741d42b1  movaps [rsp+0x20], xmm12
00007cf1741d42b7  lea rdi, [rsp]
00007cf1741d42bb  mov esi, 0x00
00007cf1741d42c0  mov rax, 0x611C8A33A530
00007cf1741d42ca  call rax
00007cf1741d42cc  movaps xmm9, [rsp]
00007cf1741d42d1  add rsp, 0x30
00007cf1741d42d5  vmovaps xmm0, [rsp]
00007cf1741d42da  vmovaps xmm1, [rsp+0x10]
00007cf1741d42e0  vmovaps xmm2, [rsp+0x20]
00007cf1741d42e6  vmovaps xmm3, [rsp+0x30]
00007cf1741d42ec  vmovaps xmm4, [rsp+0x40]
00007cf1741d42f2  vmovaps xmm5, [rsp+0x50]
00007cf1741d42f8  vmovaps xmm6, [rsp+0x60]
00007cf1741d42fe  vmovaps xmm7, [rsp+0x70]
00007cf1741d4304  vmovaps xmm8, [rsp+0x80]
00007cf1741d430d  vmovaps xmm10, [rsp+0x90]
00007cf1741d4316  vmovaps xmm11, [rsp+0xA0]
00007cf1741d431f  vmovaps xmm12, [rsp+0xB0]
00007cf1741d4328  vmovaps xmm13, [rsp+0xC0]
00007cf1741d4331  vmovaps xmm14, [rsp+0xD0]
00007cf1741d433a  vmovaps xmm15, [rsp+0xE0]
00007cf1741d4343  add rsp, 0xF0
00007cf1741d434a  pop r11
00007cf1741d434c  pop r10
00007cf1741d434e  pop r9
00007cf1741d4350  pop r8
00007cf1741d4352  pop rsi
00007cf1741d4353  pop rdi
00007cf1741d4354  pop rdx
00007cf1741d4355  pop rcx
00007cf1741d4356  pop rax
00007cf1741d4357  add rsp, 0x08
00007cf1741d435b  jmp 0x00007CF1741D00DD
00007cf1741d4360  sub rsp, 0x08
00007cf1741d4364  push rax
00007cf1741d4365  push rcx
00007cf1741d4366  push rdx
00007cf1741d4367  push rdi
00007cf1741d4368  push rsi
00007cf1741d4369  push r8
00007cf1741d436b  push r9
00007cf1741d436d  push r10
00007cf1741d436f  push r11
00007cf1741d4371  sub rsp, 0xF0
00007cf1741d4378  vmovaps [rsp], xmm0
00007cf1741d437d  vmovaps [rsp+0x10], xmm1
00007cf1741d4383  vmovaps [rsp+0x20], xmm2
00007cf1741d4389  vmovaps [rsp+0x30], xmm3
00007cf1741d438f  vmovaps [rsp+0x40], xmm4
00007cf1741d4395  vmovaps [rsp+0x50], xmm5
00007cf1741d439b  vmovaps [rsp+0x60], xmm6
00007cf1741d43a1  vmovaps [rsp+0x70], xmm7
00007cf1741d43a7  vmovaps [rsp+0x80], xmm8
00007cf1741d43b0  vmovaps [rsp+0x90], xmm9
00007cf1741d43b9  vmovaps [rsp+0xA0], xmm10
00007cf1741d43c2  vmovaps [rsp+0xB0], xmm11
00007cf1741d43cb  vmovaps [rsp+0xC0], xmm13
00007cf1741d43d4  vmovaps [rsp+0xD0], xmm14
00007cf1741d43dd  vmovaps [rsp+0xE0], xmm15
00007cf1741d43e6  sub rsp, 0x30
00007cf1741d43ea  movaps [rsp], xmm12
00007cf1741d43ef  movaps [rsp+0x10], xmm15
00007cf1741d43f5  movaps [rsp+0x20], xmm11
00007cf1741d43fb  lea rdi, [rsp]
00007cf1741d43ff  mov esi, 0x00
00007cf1741d4404  mov rax, 0x611C8A33A530
00007cf1741d440e  call rax
00007cf1741d4410  movaps xmm12, [rsp]
00007cf1741d4415  add rsp, 0x30
00007cf1741d4419  vmovaps xmm0, [rsp]
00007cf1741d441e  vmovaps xmm1, [rsp+0x10]
00007cf1741d4424  vmovaps xmm2, [rsp+0x20]
00007cf1741d442a  vmovaps xmm3, [rsp+0x30]
00007cf1741d4430  vmovaps xmm4, [rsp+0x40]
00007cf1741d4436  vmovaps xmm5, [rsp+0x50]
00007cf1741d443c  vmovaps xmm6, [rsp+0x60]
00007cf1741d4442  vmovaps xmm7, [rsp+0x70]
00007cf1741d4448  vmovaps xmm8, [rsp+0x80]
00007cf1741d4451  vmovaps xmm9, [rsp+0x90]
00007cf1741d445a  vmovaps xmm10, [rsp+0xA0]
00007cf1741d4463  vmovaps xmm11, [rsp+0xB0]
00007cf1741d446c  vmovaps xmm13, [rsp+0xC0]
00007cf1741d4475  vmovaps xmm14, [rsp+0xD0]
00007cf1741d447e  vmovaps xmm15, [rsp+0xE0]
00007cf1741d4487  add rsp, 0xF0
00007cf1741d448e  pop r11
00007cf1741d4490  pop r10
00007cf1741d4492  pop r9
00007cf1741d4494  pop r8
00007cf1741d4496  pop rsi
00007cf1741d4497  pop rdi
00007cf1741d4498  pop rdx
00007cf1741d4499  pop rcx
00007cf1741d449a  pop rax
00007cf1741d449b  add rsp, 0x08
00007cf1741d449f  jmp 0x00007CF1741D00F7
00007cf1741d44a4  sub rsp, 0x08
00007cf1741d44a8  push rax
00007cf1741d44a9  push rcx
00007cf1741d44aa  push rdx
00007cf1741d44ab  push rdi
00007cf1741d44ac  push rsi
00007cf1741d44ad  push r8
00007cf1741d44af  push r9
00007cf1741d44b1  push r10
00007cf1741d44b3  push r11
00007cf1741d44b5  sub rsp, 0xF0
00007cf1741d44bc  vmovaps [rsp], xmm0
00007cf1741d44c1  vmovaps [rsp+0x10], xmm1
00007cf1741d44c7  vmovaps [rsp+0x20], xmm2
00007cf1741d44cd  vmovaps [rsp+0x30], xmm3
00007cf1741d44d3  vmovaps [rsp+0x40], xmm4
00007cf1741d44d9  vmovaps [rsp+0x50], xmm5
00007cf1741d44df  vmovaps [rsp+0x60], xmm6
00007cf1741d44e5  vmovaps [rsp+0x70], xmm7
00007cf1741d44eb  vmovaps [rsp+0x80], xmm8
00007cf1741d44f4  vmovaps [rsp+0x90], xmm9
00007cf1741d44fd  vmovaps [rsp+0xA0], xmm10
00007cf1741d4506  vmovaps [rsp+0xB0], xmm12
00007cf1741d450f  vmovaps [rsp+0xC0], xmm13
00007cf1741d4518  vmovaps [rsp+0xD0], xmm14
00007cf1741d4521  vmovaps [rsp+0xE0], xmm15
00007cf1741d452a  sub rsp, 0x30
00007cf1741d452e  movaps [rsp], xmm11
00007cf1741d4533  movaps [rsp+0x10], xmm7
00007cf1741d4538  movaps [rsp+0x20], xmm15
00007cf1741d453e  lea rdi, [rsp]
00007cf1741d4542  mov esi, 0x00
00007cf1741d4547  mov rax, 0x611C8A33A530
00007cf1741d4551  call rax
00007cf1741d4553  movaps xmm11, [rsp]
00007cf1741d4558  add rsp, 0x30
00007cf1741d455c  vmovaps xmm0, [rsp]
00007cf1741d4561  vmovaps xmm1, [rsp+0x10]
00007cf1741d4567  vmovaps xmm2, [rsp+0x20]
00007cf1741d456d  vmovaps xmm3, [rsp+0x30]
00007cf1741d4573  vmovaps xmm4, [rsp+0x40]
00007cf1741d4579  vmovaps xmm5, [rsp+0x50]
00007cf1741d457f  vmovaps xmm6, [rsp+0x60]
00007cf1741d4585  vmovaps xmm7, [rsp+0x70]
00007cf1741d458b  vmovaps xmm8, [rsp+0x80]
00007cf1741d4594  vmovaps xmm9, [rsp+0x90]
00007cf1741d459d  vmovaps xmm10, [rsp+0xA0]
00007cf1741d45a6  vmovaps xmm12, [rsp+0xB0]
00007cf1741d45af  vmovaps xmm13, [rsp+0xC0]
00007cf1741d45b8  vmovaps xmm14, [rsp+0xD0]
00007cf1741d45c1  vmovaps xmm15, [rsp+0xE0]
00007cf1741d45ca  add rsp, 0xF0
00007cf1741d45d1  pop r11
00007cf1741d45d3  pop r10
00007cf1741d45d5  pop r9
00007cf1741d45d7  pop r8
00007cf1741d45d9  pop rsi
00007cf1741d45da  pop rdi
00007cf1741d45db  pop rdx
00007cf1741d45dc  pop rcx
00007cf1741d45dd  pop rax
00007cf1741d45de  add rsp, 0x08
00007cf1741d45e2  jmp 0x00007CF1741D0123
00007cf1741d45e7  sub rsp, 0x08
00007cf1741d45eb  push rax
00007cf1741d45ec  push rcx
00007cf1741d45ed  push rdx
00007cf1741d45ee  push rdi
00007cf1741d45ef  push rsi
00007cf1741d45f0  push r8
00007cf1741d45f2  push r9
00007cf1741d45f4  push r10
00007cf1741d45f6  push r11
00007cf1741d45f8  sub rsp, 0xF0
00007cf1741d45ff  vmovaps [rsp], xmm0
00007cf1741d4604  vmovaps [rsp+0x10], xmm1
00007cf1741d460a  vmovaps [rsp+0x20], xmm2
00007cf1741d4610  vmovaps [rsp+0x30], xmm3
00007cf1741d4616  vmovaps [rsp+0x40], xmm4
00007cf1741d461c  vmovaps [rsp+0x50], xmm5
00007cf1741d4622  vmovaps [rsp+0x60], xmm6
00007cf1741d4628  vmovaps [rsp+0x70], xmm7
00007cf1741d462e  vmovaps [rsp+0x80], xmm8
00007cf1741d4637  vmovaps [rsp+0x90], xmm9
00007cf1741d4640  vmovaps [rsp+0xA0], xmm10
00007cf1741d4649  vmovaps [rsp+0xB0], xmm11
00007cf1741d4652  vmovaps [rsp+0xC0], xmm12
00007cf1741d465b  vmovaps [rsp+0xD0], xmm13
00007cf1741d4664  vmovaps [rsp+0xE0], xmm14
00007cf1741d466d  sub rsp, 0x30
00007cf1741d4671  movaps [rsp], xmm15
00007cf1741d4676  movaps [rsp+0x10], xmm10
00007cf1741d467c  movaps [rsp+0x20], xmm13
00007cf1741d4682  lea rdi, [rsp]
00007cf1741d4686  mov esi, 0x00
00007cf1741d468b  mov rax, 0x611C8A33A530
00007cf1741d4695  call rax
00007cf1741d4697  movaps xmm15, [rsp]
00007cf1741d469c  add rsp, 0x30
00007cf1741d46a0  vmovaps xmm0, [rsp]
00007cf1741d46a5  vmovaps xmm1, [rsp+0x10]
00007cf1741d46ab  vmovaps xmm2, [rsp+0x20]
00007cf1741d46b1  vmovaps xmm3, [rsp+0x30]
00007cf1741d46b7  vmovaps xmm4, [rsp+0x40]
00007cf1741d46bd  vmovaps xmm5, [rsp+0x50]
00007cf1741d46c3  vmovaps xmm6, [rsp+0x60]
00007cf1741d46c9  vmovaps xmm7, [rsp+0x70]
00007cf1741d46cf  vmovaps xmm8, [rsp+0x80]
00007cf1741d46d8  vmovaps xmm9, [rsp+0x90]
00007cf1741d46e1  vmovaps xmm10, [rsp+0xA0]
00007cf1741d46ea  vmovaps xmm11, [rsp+0xB0]
00007cf1741d46f3  vmovaps xmm12, [rsp+0xC0]
00007cf1741d46fc  vmovaps xmm13, [rsp+0xD0]
00007cf1741d4705  vmovaps xmm14, [rsp+0xE0]
00007cf1741d470e  add rsp, 0xF0
00007cf1741d4715  pop r11
00007cf1741d4717  pop r10
00007cf1741d4719  pop r9
00007cf1741d471b  pop r8
00007cf1741d471d  pop rsi
00007cf1741d471e  pop rdi
00007cf1741d471f  pop rdx
00007cf1741d4720  pop rcx
00007cf1741d4721  pop rax
00007cf1741d4722  add rsp, 0x08
00007cf1741d4726  jmp 0x00007CF1741D013D
00007cf1741d472b  sub rsp, 0x08
00007cf1741d472f  push rax
00007cf1741d4730  push rcx
00007cf1741d4731  push rdx
00007cf1741d4732  push rdi
00007cf1741d4733  push rsi
00007cf1741d4734  push r8
00007cf1741d4736  push r9
00007cf1741d4738  push r10
00007cf1741d473a  push r11
00007cf1741d473c  sub rsp, 0xF0
00007cf1741d4743  vmovaps [rsp], xmm0
00007cf1741d4748  vmovaps [rsp+0x10], xmm1
00007cf1741d474e  vmovaps [rsp+0x20], xmm2
00007cf1741d4754  vmovaps [rsp+0x30], xmm3
00007cf1741d475a  vmovaps [rsp+0x40], xmm4
00007cf1741d4760  vmovaps [rsp+0x50], xmm5
00007cf1741d4766  vmovaps [rsp+0x60], xmm6
00007cf1741d476c  vmovaps [rsp+0x70], xmm7
00007cf1741d4772  vmovaps [rsp+0x80], xmm8
00007cf1741d477b  vmovaps [rsp+0x90], xmm9
00007cf1741d4784  vmovaps [rsp+0xA0], xmm11
00007cf1741d478d  vmovaps [rsp+0xB0], xmm12
00007cf1741d4796  vmovaps [rsp+0xC0], xmm13
00007cf1741d479f  vmovaps [rsp+0xD0], xmm14
00007cf1741d47a8  vmovaps [rsp+0xE0], xmm15
00007cf1741d47b1  sub rsp, 0x30
00007cf1741d47b5  movaps [rsp], xmm10
00007cf1741d47ba  movaps [rsp+0x10], xmm7
00007cf1741d47bf  movaps [rsp+0x20], xmm13
00007cf1741d47c5  lea rdi, [rsp]
00007cf1741d47c9  mov esi, 0x00
00007cf1741d47ce  mov rax, 0x611C8A33A530
00007cf1741d47d8  call rax
00007cf1741d47da  movaps xmm10, [rsp]
00007cf1741d47df  add rsp, 0x30
00007cf1741d47e3  vmovaps xmm0, [rsp]
00007cf1741d47e8  vmovaps xmm1, [rsp+0x10]
00007cf1741d47ee  vmovaps xmm2, [rsp+0x20]
00007cf1741d47f4  vmovaps xmm3, [rsp+0x30]
00007cf1741d47fa  vmovaps xmm4, [rsp+0x40]
00007cf1741d4800  vmovaps xmm5, [rsp+0x50]
00007cf1741d4806  vmovaps xmm6, [rsp+0x60]
00007cf1741d480c  vmovaps xmm7, [rsp+0x70]
00007cf1741d4812  vmovaps xmm8, [rsp+0x80]
00007cf1741d481b  vmovaps xmm9, [rsp+0x90]
00007cf1741d4824  vmovaps xmm11, [rsp+0xA0]
00007cf1741d482d  vmovaps xmm12, [rsp+0xB0]
00007cf1741d4836  vmovaps xmm13, [rsp+0xC0]
00007cf1741d483f  vmovaps xmm14, [rsp+0xD0]
00007cf1741d4848  vmovaps xmm15, [rsp+0xE0]
00007cf1741d4851  add rsp, 0xF0
00007cf1741d4858  pop r11
00007cf1741d485a  pop r10
00007cf1741d485c  pop r9
00007cf1741d485e  pop r8
00007cf1741d4860  pop rsi
00007cf1741d4861  pop rdi
00007cf1741d4862  pop rdx
00007cf1741d4863  pop rcx
00007cf1741d4864  pop rax
00007cf1741d4865  add rsp, 0x08
00007cf1741d4869  jmp 0x00007CF1741D0169
00007cf1741d486e  sub rsp, 0x08
00007cf1741d4872  push rax
00007cf1741d4873  push rcx
00007cf1741d4874  push rdx
00007cf1741d4875  push rdi
00007cf1741d4876  push rsi
00007cf1741d4877  push r8
00007cf1741d4879  push r9
00007cf1741d487b  push r10
00007cf1741d487d  push r11
00007cf1741d487f  sub rsp, 0xF0
00007cf1741d4886  vmovaps [rsp], xmm0
00007cf1741d488b  vmovaps [rsp+0x10], xmm1
00007cf1741d4891  vmovaps [rsp+0x20], xmm2
00007cf1741d4897  vmovaps [rsp+0x30], xmm3
00007cf1741d489d  vmovaps [rsp+0x40], xmm4
00007cf1741d48a3  vmovaps [rsp+0x50], xmm5
00007cf1741d48a9  vmovaps [rsp+0x60], xmm6
00007cf1741d48af  vmovaps [rsp+0x70], xmm7
00007cf1741d48b5  vmovaps [rsp+0x80], xmm8
00007cf1741d48be  vmovaps [rsp+0x90], xmm9
00007cf1741d48c7  vmovaps [rsp+0xA0], xmm10
00007cf1741d48d0  vmovaps [rsp+0xB0], xmm11
00007cf1741d48d9  vmovaps [rsp+0xC0], xmm12
00007cf1741d48e2  vmovaps [rsp+0xD0], xmm14
00007cf1741d48eb  vmovaps [rsp+0xE0], xmm15
00007cf1741d48f4  sub rsp, 0x30
00007cf1741d48f8  movaps [rsp], xmm13
00007cf1741d48fd  movaps [rsp+0x10], xmm1
00007cf1741d4902  movaps [rsp+0x20], xmm8
00007cf1741d4908  lea rdi, [rsp]
00007cf1741d490c  mov esi, 0x00
00007cf1741d4911  mov rax, 0x611C8A33A530
00007cf1741d491b  call rax
00007cf1741d491d  movaps xmm13, [rsp]
00007cf1741d4922  add rsp, 0x30
00007cf1741d4926  vmovaps xmm0, [rsp]
00007cf1741d492b  vmovaps xmm1, [rsp+0x10]
00007cf1741d4931  vmovaps xmm2, [rsp+0x20]
00007cf1741d4937  vmovaps xmm3, [rsp+0x30]
00007cf1741d493d  vmovaps xmm4, [rsp+0x40]
00007cf1741d4943  vmovaps xmm5, [rsp+0x50]
00007cf1741d4949  vmovaps xmm6, [rsp+0x60]
00007cf1741d494f  vmovaps xmm7, [rsp+0x70]
00007cf1741d4955  vmovaps xmm8, [rsp+0x80]
00007cf1741d495e  vmovaps xmm9, [rsp+0x90]
00007cf1741d4967  vmovaps xmm10, [rsp+0xA0]
00007cf1741d4970  vmovaps xmm11, [rsp+0xB0]
00007cf1741d4979  vmovaps xmm12, [rsp+0xC0]
00007cf1741d4982  vmovaps xmm14, [rsp+0xD0]
00007cf1741d498b  vmovaps xmm15, [rsp+0xE0]
00007cf1741d4994  add rsp, 0xF0
00007cf1741d499b  pop r11
00007cf1741d499d  pop r10
00007cf1741d499f  pop r9
00007cf1741d49a1  pop r8
00007cf1741d49a3  pop rsi
00007cf1741d49a4  pop rdi
00007cf1741d49a5  pop rdx
00007cf1741d49a6  pop rcx
00007cf1741d49a7  pop rax
00007cf1741d49a8  add rsp, 0x08
00007cf1741d49ac  jmp 0x00007CF1741D0183
00007cf1741d49b1  call 0x00007CF173FFF430
00007cf1741d49b6  jmp 0x00007CF1741D018D
00007cf1741d49bb  sub rsp, 0x08
00007cf1741d49bf  push rax
00007cf1741d49c0  push rcx
00007cf1741d49c1  push rdx
00007cf1741d49c2  push rdi
00007cf1741d49c3  push rsi
00007cf1741d49c4  push r8
00007cf1741d49c6  push r9
00007cf1741d49c8  push r10
00007cf1741d49ca  push r11
00007cf1741d49cc  sub rsp, 0xF0
00007cf1741d49d3  vmovaps [rsp], xmm0
00007cf1741d49d8  vmovaps [rsp+0x10], xmm1
00007cf1741d49de  vmovaps [rsp+0x20], xmm2
00007cf1741d49e4  vmovaps [rsp+0x30], xmm3
00007cf1741d49ea  vmovaps [rsp+0x40], xmm4
00007cf1741d49f0  vmovaps [rsp+0x50], xmm5
00007cf1741d49f6  vmovaps [rsp+0x60], xmm6
00007cf1741d49fc  vmovaps [rsp+0x70], xmm7
00007cf1741d4a02  vmovaps [rsp+0x80], xmm9
00007cf1741d4a0b  vmovaps [rsp+0x90], xmm10
00007cf1741d4a14  vmovaps [rsp+0xA0], xmm11
00007cf1741d4a1d  vmovaps [rsp+0xB0], xmm12
00007cf1741d4a26  vmovaps [rsp+0xC0], xmm13
00007cf1741d4a2f  vmovaps [rsp+0xD0], xmm14
00007cf1741d4a38  vmovaps [rsp+0xE0], xmm15
00007cf1741d4a41  sub rsp, 0x30
00007cf1741d4a45  movaps [rsp], xmm8
00007cf1741d4a4a  movaps [rsp+0x10], xmm14
00007cf1741d4a50  movaps [rsp+0x20], xmm9
00007cf1741d4a56  lea rdi, [rsp]
00007cf1741d4a5a  mov esi, 0x00
00007cf1741d4a5f  mov rax, 0x611C8A33A530
00007cf1741d4a69  call rax
00007cf1741d4a6b  movaps xmm8, [rsp]
00007cf1741d4a70  add rsp, 0x30
00007cf1741d4a74  vmovaps xmm0, [rsp]
00007cf1741d4a79  vmovaps xmm1, [rsp+0x10]
00007cf1741d4a7f  vmovaps xmm2, [rsp+0x20]
00007cf1741d4a85  vmovaps xmm3, [rsp+0x30]
00007cf1741d4a8b  vmovaps xmm4, [rsp+0x40]
00007cf1741d4a91  vmovaps xmm5, [rsp+0x50]
00007cf1741d4a97  vmovaps xmm6, [rsp+0x60]
00007cf1741d4a9d  vmovaps xmm7, [rsp+0x70]
00007cf1741d4aa3  vmovaps xmm9, [rsp+0x80]
00007cf1741d4aac  vmovaps xmm10, [rsp+0x90]
00007cf1741d4ab5  vmovaps xmm11, [rsp+0xA0]
00007cf1741d4abe  vmovaps xmm12, [rsp+0xB0]
00007cf1741d4ac7  vmovaps xmm13, [rsp+0xC0]
00007cf1741d4ad0  vmovaps xmm14, [rsp+0xD0]
00007cf1741d4ad9  vmovaps xmm15, [rsp+0xE0]
00007cf1741d4ae2  add rsp, 0xF0
00007cf1741d4ae9  pop r11
00007cf1741d4aeb  pop r10
00007cf1741d4aed  pop r9
00007cf1741d4aef  pop r8
00007cf1741d4af1  pop rsi
00007cf1741d4af2  pop rdi
00007cf1741d4af3  pop rdx
00007cf1741d4af4  pop rcx
00007cf1741d4af5  pop rax
00007cf1741d4af6  add rsp, 0x08
00007cf1741d4afa  jmp 0x00007CF1741D01AF
00007cf1741d4aff  sub rsp, 0x08
00007cf1741d4b03  push rax
00007cf1741d4b04  push rcx
00007cf1741d4b05  push rdx
00007cf1741d4b06  push rdi
00007cf1741d4b07  push rsi
00007cf1741d4b08  push r8
00007cf1741d4b0a  push r9
00007cf1741d4b0c  push r10
00007cf1741d4b0e  push r11
00007cf1741d4b10  sub rsp, 0xF0
00007cf1741d4b17  vmovaps [rsp], xmm0
00007cf1741d4b1c  vmovaps [rsp+0x10], xmm1
00007cf1741d4b22  vmovaps [rsp+0x20], xmm2
00007cf1741d4b28  vmovaps [rsp+0x30], xmm3
00007cf1741d4b2e  vmovaps [rsp+0x40], xmm4
00007cf1741d4b34  vmovaps [rsp+0x50], xmm5
00007cf1741d4b3a  vmovaps [rsp+0x60], xmm6
00007cf1741d4b40  vmovaps [rsp+0x70], xmm7
00007cf1741d4b46  vmovaps [rsp+0x80], xmm8
00007cf1741d4b4f  vmovaps [rsp+0x90], xmm10
00007cf1741d4b58  vmovaps [rsp+0xA0], xmm11
00007cf1741d4b61  vmovaps [rsp+0xB0], xmm12
00007cf1741d4b6a  vmovaps [rsp+0xC0], xmm13
00007cf1741d4b73  vmovaps [rsp+0xD0], xmm14
00007cf1741d4b7c  vmovaps [rsp+0xE0], xmm15
00007cf1741d4b85  sub rsp, 0x30
00007cf1741d4b89  movaps [rsp], xmm9
00007cf1741d4b8e  movaps [rsp+0x10], xmm1
00007cf1741d4b93  movaps [rsp+0x20], xmm14
00007cf1741d4b99  lea rdi, [rsp]
00007cf1741d4b9d  mov esi, 0x00
00007cf1741d4ba2  mov rax, 0x611C8A33A530
00007cf1741d4bac  call rax
00007cf1741d4bae  movaps xmm9, [rsp]
00007cf1741d4bb3  add rsp, 0x30
00007cf1741d4bb7  vmovaps xmm0, [rsp]
00007cf1741d4bbc  vmovaps xmm1, [rsp+0x10]
00007cf1741d4bc2  vmovaps xmm2, [rsp+0x20]
00007cf1741d4bc8  vmovaps xmm3, [rsp+0x30]
00007cf1741d4bce  vmovaps xmm4, [rsp+0x40]
00007cf1741d4bd4  vmovaps xmm5, [rsp+0x50]
00007cf1741d4bda  vmovaps xmm6, [rsp+0x60]
00007cf1741d4be0  vmovaps xmm7, [rsp+0x70]
00007cf1741d4be6  vmovaps xmm8, [rsp+0x80]
00007cf1741d4bef  vmovaps xmm10, [rsp+0x90]
00007cf1741d4bf8  vmovaps xmm11, [rsp+0xA0]
00007cf1741d4c01  vmovaps xmm12, [rsp+0xB0]
00007cf1741d4c0a  vmovaps xmm13, [rsp+0xC0]
00007cf1741d4c13  vmovaps xmm14, [rsp+0xD0]
00007cf1741d4c1c  vmovaps xmm15, [rsp+0xE0]
00007cf1741d4c25  add rsp, 0xF0
00007cf1741d4c2c  pop r11
00007cf1741d4c2e  pop r10
00007cf1741d4c30  pop r9
00007cf1741d4c32  pop r8
00007cf1741d4c34  pop rsi
00007cf1741d4c35  pop rdi
00007cf1741d4c36  pop rdx
00007cf1741d4c37  pop rcx
00007cf1741d4c38  pop rax
00007cf1741d4c39  add rsp, 0x08
00007cf1741d4c3d  jmp 0x00007CF1741D01DD
00007cf1741d4c42  sub rsp, 0x08
00007cf1741d4c46  push rax
00007cf1741d4c47  push rcx
00007cf1741d4c48  push rdx
00007cf1741d4c49  push rdi
00007cf1741d4c4a  push rsi
00007cf1741d4c4b  push r8
00007cf1741d4c4d  push r9
00007cf1741d4c4f  push r10
00007cf1741d4c51  push r11
00007cf1741d4c53  sub rsp, 0xF0
00007cf1741d4c5a  vmovaps [rsp], xmm0
00007cf1741d4c5f  vmovaps [rsp+0x10], xmm1
00007cf1741d4c65  vmovaps [rsp+0x20], xmm2
00007cf1741d4c6b  vmovaps [rsp+0x30], xmm3
00007cf1741d4c71  vmovaps [rsp+0x40], xmm4
00007cf1741d4c77  vmovaps [rsp+0x50], xmm5
00007cf1741d4c7d  vmovaps [rsp+0x60], xmm6
00007cf1741d4c83  vmovaps [rsp+0x70], xmm7
00007cf1741d4c89  vmovaps [rsp+0x80], xmm8
00007cf1741d4c92  vmovaps [rsp+0x90], xmm9
00007cf1741d4c9b  vmovaps [rsp+0xA0], xmm10
00007cf1741d4ca4  vmovaps [rsp+0xB0], xmm11
00007cf1741d4cad  vmovaps [rsp+0xC0], xmm12
00007cf1741d4cb6  vmovaps [rsp+0xD0], xmm13
00007cf1741d4cbf  vmovaps [rsp+0xE0], xmm15
00007cf1741d4cc8  sub rsp, 0x30
00007cf1741d4ccc  movaps [rsp], xmm14
00007cf1741d4cd1  movaps [rsp+0x10], xmm4
00007cf1741d4cd6  movaps [rsp+0x20], xmm1
00007cf1741d4cdb  lea rdi, [rsp]
00007cf1741d4cdf  mov esi, 0x00
00007cf1741d4ce4  mov rax, 0x611C8A33A530
00007cf1741d4cee  call rax
00007cf1741d4cf0  movaps xmm14, [rsp]
00007cf1741d4cf5  add rsp, 0x30
00007cf1741d4cf9  vmovaps xmm0, [rsp]
00007cf1741d4cfe  vmovaps xmm1, [rsp+0x10]
00007cf1741d4d04  vmovaps xmm2, [rsp+0x20]
00007cf1741d4d0a  vmovaps xmm3, [rsp+0x30]
00007cf1741d4d10  vmovaps xmm4, [rsp+0x40]
00007cf1741d4d16  vmovaps xmm5, [rsp+0x50]
00007cf1741d4d1c  vmovaps xmm6, [rsp+0x60]
00007cf1741d4d22  vmovaps xmm7, [rsp+0x70]
00007cf1741d4d28  vmovaps xmm8, [rsp+0x80]
00007cf1741d4d31  vmovaps xmm9, [rsp+0x90]
00007cf1741d4d3a  vmovaps xmm10, [rsp+0xA0]
00007cf1741d4d43  vmovaps xmm11, [rsp+0xB0]
00007cf1741d4d4c  vmovaps xmm12, [rsp+0xC0]
00007cf1741d4d55  vmovaps xmm13, [rsp+0xD0]
00007cf1741d4d5e  vmovaps xmm15, [rsp+0xE0]
00007cf1741d4d67  add rsp, 0xF0
00007cf1741d4d6e  pop r11
00007cf1741d4d70  pop r10
00007cf1741d4d72  pop r9
00007cf1741d4d74  pop r8
00007cf1741d4d76  pop rsi
00007cf1741d4d77  pop rdi
00007cf1741d4d78  pop rdx
00007cf1741d4d79  pop rcx
00007cf1741d4d7a  pop rax
00007cf1741d4d7b  add rsp, 0x08
00007cf1741d4d7f  jmp 0x00007CF1741D0203
00007cf1741d4d84  sub rsp, 0x08
00007cf1741d4d88  push rax
00007cf1741d4d89  push rcx
00007cf1741d4d8a  push rdx
00007cf1741d4d8b  push rdi
00007cf1741d4d8c  push rsi
00007cf1741d4d8d  push r8
00007cf1741d4d8f  push r9
00007cf1741d4d91  push r10
00007cf1741d4d93  push r11
00007cf1741d4d95  sub rsp, 0xF0
00007cf1741d4d9c  vmovaps [rsp], xmm0
00007cf1741d4da1  vmovaps [rsp+0x10], xmm2
00007cf1741d4da7  vmovaps [rsp+0x20], xmm3
00007cf1741d4dad  vmovaps [rsp+0x30], xmm4
00007cf1741d4db3  vmovaps [rsp+0x40], xmm5
00007cf1741d4db9  vmovaps [rsp+0x50], xmm6
00007cf1741d4dbf  vmovaps [rsp+0x60], xmm7
00007cf1741d4dc5  vmovaps [rsp+0x70], xmm8
00007cf1741d4dcb  vmovaps [rsp+0x80], xmm9
00007cf1741d4dd4  vmovaps [rsp+0x90], xmm10
00007cf1741d4ddd  vmovaps [rsp+0xA0], xmm11
00007cf1741d4de6  vmovaps [rsp+0xB0], xmm12
00007cf1741d4def  vmovaps [rsp+0xC0], xmm13
00007cf1741d4df8  vmovaps [rsp+0xD0], xmm14
00007cf1741d4e01  vmovaps [rsp+0xE0], xmm15
00007cf1741d4e0a  sub rsp, 0x30
00007cf1741d4e0e  movaps [rsp], xmm1
00007cf1741d4e12  movaps [rsp+0x10], xmm12
00007cf1741d4e18  movaps [rsp+0x20], xmm11
00007cf1741d4e1e  lea rdi, [rsp]
00007cf1741d4e22  mov esi, 0x00
00007cf1741d4e27  mov rax, 0x611C8A33A530
00007cf1741d4e31  call rax
00007cf1741d4e33  movaps xmm1, [rsp]
00007cf1741d4e37  add rsp, 0x30
00007cf1741d4e3b  vmovaps xmm0, [rsp]
00007cf1741d4e40  vmovaps xmm2, [rsp+0x10]
00007cf1741d4e46  vmovaps xmm3, [rsp+0x20]
00007cf1741d4e4c  vmovaps xmm4, [rsp+0x30]
00007cf1741d4e52  vmovaps xmm5, [rsp+0x40]
00007cf1741d4e58  vmovaps xmm6, [rsp+0x50]
00007cf1741d4e5e  vmovaps xmm7, [rsp+0x60]
00007cf1741d4e64  vmovaps xmm8, [rsp+0x70]
00007cf1741d4e6a  vmovaps xmm9, [rsp+0x80]
00007cf1741d4e73  vmovaps xmm10, [rsp+0x90]
00007cf1741d4e7c  vmovaps xmm11, [rsp+0xA0]
00007cf1741d4e85  vmovaps xmm12, [rsp+0xB0]
00007cf1741d4e8e  vmovaps xmm13, [rsp+0xC0]
00007cf1741d4e97  vmovaps xmm14, [rsp+0xD0]
00007cf1741d4ea0  vmovaps xmm15, [rsp+0xE0]
00007cf1741d4ea9  add rsp, 0xF0
00007cf1741d4eb0  pop r11
00007cf1741d4eb2  pop r10
00007cf1741d4eb4  pop r9
00007cf1741d4eb6  pop r8
00007cf1741d4eb8  pop rsi
00007cf1741d4eb9  pop rdi
00007cf1741d4eba  pop rdx
00007cf1741d4ebb  pop rcx
00007cf1741d4ebc  pop rax
00007cf1741d4ebd  add rsp, 0x08
00007cf1741d4ec1  jmp 0x00007CF1741D0224
00007cf1741d4ec6  call 0x00007CF1740E20A0
00007cf1741d4ecb  jmp 0x00007CF1741D0232
00007cf1741d4ed0  call 0x00007CF174009D70
00007cf1741d4ed5  jmp 0x00007CF1741D023C
00007cf1741d4eda  sub rsp, 0x08
00007cf1741d4ede  push rax
00007cf1741d4edf  push rcx
00007cf1741d4ee0  push rdx
00007cf1741d4ee1  push rdi
00007cf1741d4ee2  push rsi
00007cf1741d4ee3  push r8
00007cf1741d4ee5  push r9
00007cf1741d4ee7  push r10
00007cf1741d4ee9  push r11
00007cf1741d4eeb  sub rsp, 0xF0
00007cf1741d4ef2  vmovaps [rsp], xmm0
00007cf1741d4ef7  vmovaps [rsp+0x10], xmm1
00007cf1741d4efd  vmovaps [rsp+0x20], xmm2
00007cf1741d4f03  vmovaps [rsp+0x30], xmm3
00007cf1741d4f09  vmovaps [rsp+0x40], xmm4
00007cf1741d4f0f  vmovaps [rsp+0x50], xmm5
00007cf1741d4f15  vmovaps [rsp+0x60], xmm6
00007cf1741d4f1b  vmovaps [rsp+0x70], xmm8
00007cf1741d4f21  vmovaps [rsp+0x80], xmm9
00007cf1741d4f2a  vmovaps [rsp+0x90], xmm10
00007cf1741d4f33  vmovaps [rsp+0xA0], xmm11
00007cf1741d4f3c  vmovaps [rsp+0xB0], xmm12
00007cf1741d4f45  vmovaps [rsp+0xC0], xmm13
00007cf1741d4f4e  vmovaps [rsp+0xD0], xmm14
00007cf1741d4f57  vmovaps [rsp+0xE0], xmm15
00007cf1741d4f60  sub rsp, 0x30
00007cf1741d4f64  movaps [rsp], xmm7
00007cf1741d4f68  movaps [rsp+0x10], xmm15
00007cf1741d4f6e  movaps [rsp+0x20], xmm10
00007cf1741d4f74  lea rdi, [rsp]
00007cf1741d4f78  mov esi, 0x00
00007cf1741d4f7d  mov rax, 0x611C8A33A530
00007cf1741d4f87  call rax
00007cf1741d4f89  movaps xmm7, [rsp]
00007cf1741d4f8d  add rsp, 0x30
00007cf1741d4f91  vmovaps xmm0, [rsp]
00007cf1741d4f96  vmovaps xmm1, [rsp+0x10]
00007cf1741d4f9c  vmovaps xmm2, [rsp+0x20]
00007cf1741d4fa2  vmovaps xmm3, [rsp+0x30]
00007cf1741d4fa8  vmovaps xmm4, [rsp+0x40]
00007cf1741d4fae  vmovaps xmm5, [rsp+0x50]
00007cf1741d4fb4  vmovaps xmm6, [rsp+0x60]
00007cf1741d4fba  vmovaps xmm8, [rsp+0x70]
00007cf1741d4fc0  vmovaps xmm9, [rsp+0x80]
00007cf1741d4fc9  vmovaps xmm10, [rsp+0x90]
00007cf1741d4fd2  vmovaps xmm11, [rsp+0xA0]
00007cf1741d4fdb  vmovaps xmm12, [rsp+0xB0]
00007cf1741d4fe4  vmovaps xmm13, [rsp+0xC0]
00007cf1741d4fed  vmovaps xmm14, [rsp+0xD0]
00007cf1741d4ff6  vmovaps xmm15, [rsp+0xE0]
00007cf1741d4fff  add rsp, 0xF0
00007cf1741d5006  pop r11
00007cf1741d5008  pop r10
00007cf1741d500a  pop r9
00007cf1741d500c  pop r8
00007cf1741d500e  pop rsi
00007cf1741d500f  pop rdi
00007cf1741d5010  pop rdx
00007cf1741d5011  pop rcx
00007cf1741d5012  pop rax
00007cf1741d5013  add rsp, 0x08
00007cf1741d5017  jmp 0x00007CF1741D025D
00007cf1741d501c  sub rsp, 0x08
00007cf1741d5020  push rax
00007cf1741d5021  push rcx
00007cf1741d5022  push rdx
00007cf1741d5023  push rdi
00007cf1741d5024  push rsi
00007cf1741d5025  push r8
00007cf1741d5027  push r9
00007cf1741d5029  push r10
00007cf1741d502b  push r11
00007cf1741d502d  sub rsp, 0xF0
00007cf1741d5034  vmovaps [rsp], xmm0
00007cf1741d5039  vmovaps [rsp+0x10], xmm1
00007cf1741d503f  vmovaps [rsp+0x20], xmm2
00007cf1741d5045  vmovaps [rsp+0x30], xmm3
00007cf1741d504b  vmovaps [rsp+0x40], xmm4
00007cf1741d5051  vmovaps [rsp+0x50], xmm5
00007cf1741d5057  vmovaps [rsp+0x60], xmm6
00007cf1741d505d  vmovaps [rsp+0x70], xmm7
00007cf1741d5063  vmovaps [rsp+0x80], xmm8
00007cf1741d506c  vmovaps [rsp+0x90], xmm9
00007cf1741d5075  vmovaps [rsp+0xA0], xmm11
00007cf1741d507e  vmovaps [rsp+0xB0], xmm12
00007cf1741d5087  vmovaps [rsp+0xC0], xmm13
00007cf1741d5090  vmovaps [rsp+0xD0], xmm14
00007cf1741d5099  vmovaps [rsp+0xE0], xmm15
00007cf1741d50a2  sub rsp, 0x30
00007cf1741d50a6  movaps [rsp], xmm10
00007cf1741d50ab  movaps [rsp+0x10], xmm11
00007cf1741d50b1  movaps [rsp+0x20], xmm15
00007cf1741d50b7  lea rdi, [rsp]
00007cf1741d50bb  mov esi, 0x00
00007cf1741d50c0  mov rax, 0x611C8A33A530
00007cf1741d50ca  call rax
00007cf1741d50cc  movaps xmm10, [rsp]
00007cf1741d50d1  add rsp, 0x30
00007cf1741d50d5  vmovaps xmm0, [rsp]
00007cf1741d50da  vmovaps xmm1, [rsp+0x10]
00007cf1741d50e0  vmovaps xmm2, [rsp+0x20]
00007cf1741d50e6  vmovaps xmm3, [rsp+0x30]
00007cf1741d50ec  vmovaps xmm4, [rsp+0x40]
00007cf1741d50f2  vmovaps xmm5, [rsp+0x50]
00007cf1741d50f8  vmovaps xmm6, [rsp+0x60]
00007cf1741d50fe  vmovaps xmm7, [rsp+0x70]
00007cf1741d5104  vmovaps xmm8, [rsp+0x80]
00007cf1741d510d  vmovaps xmm9, [rsp+0x90]
00007cf1741d5116  vmovaps xmm11, [rsp+0xA0]
00007cf1741d511f  vmovaps xmm12, [rsp+0xB0]
00007cf1741d5128  vmovaps xmm13, [rsp+0xC0]
00007cf1741d5131  vmovaps xmm14, [rsp+0xD0]
00007cf1741d513a  vmovaps xmm15, [rsp+0xE0]
00007cf1741d5143  add rsp, 0xF0
00007cf1741d514a  pop r11
00007cf1741d514c  pop r10
00007cf1741d514e  pop r9
00007cf1741d5150  pop r8
00007cf1741d5152  pop rsi
00007cf1741d5153  pop rdi
00007cf1741d5154  pop rdx
00007cf1741d5155  pop rcx
00007cf1741d5156  pop rax
00007cf1741d5157  add rsp, 0x08
00007cf1741d515b  jmp 0x00007CF1741D028B
00007cf1741d5160  sub rsp, 0x08
00007cf1741d5164  push rax
00007cf1741d5165  push rcx
00007cf1741d5166  push rdx
00007cf1741d5167  push rdi
00007cf1741d5168  push rsi
00007cf1741d5169  push r8
00007cf1741d516b  push r9
00007cf1741d516d  push r10
00007cf1741d516f  push r11
00007cf1741d5171  sub rsp, 0xF0
00007cf1741d5178  vmovaps [rsp], xmm0
00007cf1741d517d  vmovaps [rsp+0x10], xmm1
00007cf1741d5183  vmovaps [rsp+0x20], xmm2
00007cf1741d5189  vmovaps [rsp+0x30], xmm3
00007cf1741d518f  vmovaps [rsp+0x40], xmm4
00007cf1741d5195  vmovaps [rsp+0x50], xmm5
00007cf1741d519b  vmovaps [rsp+0x60], xmm6
00007cf1741d51a1  vmovaps [rsp+0x70], xmm7
00007cf1741d51a7  vmovaps [rsp+0x80], xmm8
00007cf1741d51b0  vmovaps [rsp+0x90], xmm9
00007cf1741d51b9  vmovaps [rsp+0xA0], xmm10
00007cf1741d51c2  vmovaps [rsp+0xB0], xmm12
00007cf1741d51cb  vmovaps [rsp+0xC0], xmm13
00007cf1741d51d4  vmovaps [rsp+0xD0], xmm14
00007cf1741d51dd  vmovaps [rsp+0xE0], xmm15
00007cf1741d51e6  sub rsp, 0x30
00007cf1741d51ea  movaps [rsp], xmm11
00007cf1741d51ef  movaps [rsp+0x10], xmm12
00007cf1741d51f5  movaps [rsp+0x20], xmm15
00007cf1741d51fb  lea rdi, [rsp]
00007cf1741d51ff  mov esi, 0x00
00007cf1741d5204  mov rax, 0x611C8A33A530
00007cf1741d520e  call rax
00007cf1741d5210  movaps xmm11, [rsp]
00007cf1741d5215  add rsp, 0x30
00007cf1741d5219  vmovaps xmm0, [rsp]
00007cf1741d521e  vmovaps xmm1, [rsp+0x10]
00007cf1741d5224  vmovaps xmm2, [rsp+0x20]
00007cf1741d522a  vmovaps xmm3, [rsp+0x30]
00007cf1741d5230  vmovaps xmm4, [rsp+0x40]
00007cf1741d5236  vmovaps xmm5, [rsp+0x50]
00007cf1741d523c  vmovaps xmm6, [rsp+0x60]
00007cf1741d5242  vmovaps xmm7, [rsp+0x70]
00007cf1741d5248  vmovaps xmm8, [rsp+0x80]
00007cf1741d5251  vmovaps xmm9, [rsp+0x90]
00007cf1741d525a  vmovaps xmm10, [rsp+0xA0]
00007cf1741d5263  vmovaps xmm12, [rsp+0xB0]
00007cf1741d526c  vmovaps xmm13, [rsp+0xC0]
00007cf1741d5275  vmovaps xmm14, [rsp+0xD0]
00007cf1741d527e  vmovaps xmm15, [rsp+0xE0]
00007cf1741d5287  add rsp, 0xF0
00007cf1741d528e  pop r11
00007cf1741d5290  pop r10
00007cf1741d5292  pop r9
00007cf1741d5294  pop r8
00007cf1741d5296  pop rsi
00007cf1741d5297  pop rdi
00007cf1741d5298  pop rdx
00007cf1741d5299  pop rcx
00007cf1741d529a  pop rax
00007cf1741d529b  add rsp, 0x08
00007cf1741d529f  jmp 0x00007CF1741D02B9
00007cf1741d52a4  sub rsp, 0x08
00007cf1741d52a8  push rax
00007cf1741d52a9  push rcx
00007cf1741d52aa  push rdx
00007cf1741d52ab  push rdi
00007cf1741d52ac  push rsi
00007cf1741d52ad  push r8
00007cf1741d52af  push r9
00007cf1741d52b1  push r10
00007cf1741d52b3  push r11
00007cf1741d52b5  sub rsp, 0xF0
00007cf1741d52bc  vmovaps [rsp], xmm0
00007cf1741d52c1  vmovaps [rsp+0x10], xmm1
00007cf1741d52c7  vmovaps [rsp+0x20], xmm2
00007cf1741d52cd  vmovaps [rsp+0x30], xmm3
00007cf1741d52d3  vmovaps [rsp+0x40], xmm4
00007cf1741d52d9  vmovaps [rsp+0x50], xmm5
00007cf1741d52df  vmovaps [rsp+0x60], xmm6
00007cf1741d52e5  vmovaps [rsp+0x70], xmm7
00007cf1741d52eb  vmovaps [rsp+0x80], xmm8
00007cf1741d52f4  vmovaps [rsp+0x90], xmm9
00007cf1741d52fd  vmovaps [rsp+0xA0], xmm10
00007cf1741d5306  vmovaps [rsp+0xB0], xmm11
00007cf1741d530f  vmovaps [rsp+0xC0], xmm12
00007cf1741d5318  vmovaps [rsp+0xD0], xmm13
00007cf1741d5321  vmovaps [rsp+0xE0], xmm14
00007cf1741d532a  sub rsp, 0x30
00007cf1741d532e  movaps [rsp], xmm15
00007cf1741d5333  movaps [rsp+0x10], xmm13
00007cf1741d5339  movaps [rsp+0x20], xmm9
00007cf1741d533f  lea rdi, [rsp]
00007cf1741d5343  mov esi, 0x00
00007cf1741d5348  mov rax, 0x611C8A33A530
00007cf1741d5352  call rax
00007cf1741d5354  movaps xmm15, [rsp]
00007cf1741d5359  add rsp, 0x30
00007cf1741d535d  vmovaps xmm0, [rsp]
00007cf1741d5362  vmovaps xmm1, [rsp+0x10]
00007cf1741d5368  vmovaps xmm2, [rsp+0x20]
00007cf1741d536e  vmovaps xmm3, [rsp+0x30]
00007cf1741d5374  vmovaps xmm4, [rsp+0x40]
00007cf1741d537a  vmovaps xmm5, [rsp+0x50]
00007cf1741d5380  vmovaps xmm6, [rsp+0x60]
00007cf1741d5386  vmovaps xmm7, [rsp+0x70]
00007cf1741d538c  vmovaps xmm8, [rsp+0x80]
00007cf1741d5395  vmovaps xmm9, [rsp+0x90]
00007cf1741d539e  vmovaps xmm10, [rsp+0xA0]
00007cf1741d53a7  vmovaps xmm11, [rsp+0xB0]
00007cf1741d53b0  vmovaps xmm12, [rsp+0xC0]
00007cf1741d53b9  vmovaps xmm13, [rsp+0xD0]
00007cf1741d53c2  vmovaps xmm14, [rsp+0xE0]
00007cf1741d53cb  add rsp, 0xF0
00007cf1741d53d2  pop r11
00007cf1741d53d4  pop r10
00007cf1741d53d6  pop r9
00007cf1741d53d8  pop r8
00007cf1741d53da  pop rsi
00007cf1741d53db  pop rdi
00007cf1741d53dc  pop rdx
00007cf1741d53dd  pop rcx
00007cf1741d53de  pop rax
00007cf1741d53df  add rsp, 0x08
00007cf1741d53e3  jmp 0x00007CF1741D02D4
00007cf1741d53e8  sub rsp, 0x08
00007cf1741d53ec  push rax
00007cf1741d53ed  push rcx
00007cf1741d53ee  push rdx
00007cf1741d53ef  push rdi
00007cf1741d53f0  push rsi
00007cf1741d53f1  push r8
00007cf1741d53f3  push r9
00007cf1741d53f5  push r10
00007cf1741d53f7  push r11
00007cf1741d53f9  sub rsp, 0xF0
00007cf1741d5400  vmovaps [rsp], xmm0
00007cf1741d5405  vmovaps [rsp+0x10], xmm1
00007cf1741d540b  vmovaps [rsp+0x20], xmm2
00007cf1741d5411  vmovaps [rsp+0x30], xmm3
00007cf1741d5417  vmovaps [rsp+0x40], xmm4
00007cf1741d541d  vmovaps [rsp+0x50], xmm5
00007cf1741d5423  vmovaps [rsp+0x60], xmm6
00007cf1741d5429  vmovaps [rsp+0x70], xmm7
00007cf1741d542f  vmovaps [rsp+0x80], xmm8
00007cf1741d5438  vmovaps [rsp+0x90], xmm9
00007cf1741d5441  vmovaps [rsp+0xA0], xmm10
00007cf1741d544a  vmovaps [rsp+0xB0], xmm11
00007cf1741d5453  vmovaps [rsp+0xC0], xmm12
00007cf1741d545c  vmovaps [rsp+0xD0], xmm14
00007cf1741d5465  vmovaps [rsp+0xE0], xmm15
00007cf1741d546e  sub rsp, 0x30
00007cf1741d5472  movaps [rsp], xmm13
00007cf1741d5477  movaps [rsp+0x10], xmm8
00007cf1741d547d  movaps [rsp+0x20], xmm14
00007cf1741d5483  lea rdi, [rsp]
00007cf1741d5487  mov esi, 0x00
00007cf1741d548c  mov rax, 0x611C8A33A530
00007cf1741d5496  call rax
00007cf1741d5498  movaps xmm13, [rsp]
00007cf1741d549d  add rsp, 0x30
00007cf1741d54a1  vmovaps xmm0, [rsp]
00007cf1741d54a6  vmovaps xmm1, [rsp+0x10]
00007cf1741d54ac  vmovaps xmm2, [rsp+0x20]
00007cf1741d54b2  vmovaps xmm3, [rsp+0x30]
00007cf1741d54b8  vmovaps xmm4, [rsp+0x40]
00007cf1741d54be  vmovaps xmm5, [rsp+0x50]
00007cf1741d54c4  vmovaps xmm6, [rsp+0x60]
00007cf1741d54ca  vmovaps xmm7, [rsp+0x70]
00007cf1741d54d0  vmovaps xmm8, [rsp+0x80]
00007cf1741d54d9  vmovaps xmm9, [rsp+0x90]
00007cf1741d54e2  vmovaps xmm10, [rsp+0xA0]
00007cf1741d54eb  vmovaps xmm11, [rsp+0xB0]
00007cf1741d54f4  vmovaps xmm12, [rsp+0xC0]
00007cf1741d54fd  vmovaps xmm14, [rsp+0xD0]
00007cf1741d5506  vmovaps xmm15, [rsp+0xE0]
00007cf1741d550f  add rsp, 0xF0
00007cf1741d5516  pop r11
00007cf1741d5518  pop r10
00007cf1741d551a  pop r9
00007cf1741d551c  pop r8
00007cf1741d551e  pop rsi
00007cf1741d551f  pop rdi
00007cf1741d5520  pop rdx
00007cf1741d5521  pop rcx
00007cf1741d5522  pop rax
00007cf1741d5523  add rsp, 0x08
00007cf1741d5527  jmp 0x00007CF1741D02F7
00007cf1741d552c  sub rsp, 0x08
00007cf1741d5530  push rax
00007cf1741d5531  push rcx
00007cf1741d5532  push rdx
00007cf1741d5533  push rdi
00007cf1741d5534  push rsi
00007cf1741d5535  push r8
00007cf1741d5537  push r9
00007cf1741d5539  push r10
00007cf1741d553b  push r11
00007cf1741d553d  sub rsp, 0xF0
00007cf1741d5544  vmovaps [rsp], xmm0
00007cf1741d5549  vmovaps [rsp+0x10], xmm1
00007cf1741d554f  vmovaps [rsp+0x20], xmm2
00007cf1741d5555  vmovaps [rsp+0x30], xmm3
00007cf1741d555b  vmovaps [rsp+0x40], xmm4
00007cf1741d5561  vmovaps [rsp+0x50], xmm5
00007cf1741d5567  vmovaps [rsp+0x60], xmm6
00007cf1741d556d  vmovaps [rsp+0x70], xmm7
00007cf1741d5573  vmovaps [rsp+0x80], xmm8
00007cf1741d557c  vmovaps [rsp+0x90], xmm9
00007cf1741d5585  vmovaps [rsp+0xA0], xmm10
00007cf1741d558e  vmovaps [rsp+0xB0], xmm11
00007cf1741d5597  vmovaps [rsp+0xC0], xmm12
00007cf1741d55a0  vmovaps [rsp+0xD0], xmm13
00007cf1741d55a9  vmovaps [rsp+0xE0], xmm15
00007cf1741d55b2  sub rsp, 0x30
00007cf1741d55b6  movaps [rsp], xmm14
00007cf1741d55bb  movaps [rsp+0x10], xmm1
00007cf1741d55c0  movaps [rsp+0x20], xmm10
00007cf1741d55c6  lea rdi, [rsp]
00007cf1741d55ca  mov esi, 0x00
00007cf1741d55cf  mov rax, 0x611C8A33A530
00007cf1741d55d9  call rax
00007cf1741d55db  movaps xmm14, [rsp]
00007cf1741d55e0  add rsp, 0x30
00007cf1741d55e4  vmovaps xmm0, [rsp]
00007cf1741d55e9  vmovaps xmm1, [rsp+0x10]
00007cf1741d55ef  vmovaps xmm2, [rsp+0x20]
00007cf1741d55f5  vmovaps xmm3, [rsp+0x30]
00007cf1741d55fb  vmovaps xmm4, [rsp+0x40]
00007cf1741d5601  vmovaps xmm5, [rsp+0x50]
00007cf1741d5607  vmovaps xmm6, [rsp+0x60]
00007cf1741d560d  vmovaps xmm7, [rsp+0x70]
00007cf1741d5613  vmovaps xmm8, [rsp+0x80]
00007cf1741d561c  vmovaps xmm9, [rsp+0x90]
00007cf1741d5625  vmovaps xmm10, [rsp+0xA0]
00007cf1741d562e  vmovaps xmm11, [rsp+0xB0]
00007cf1741d5637  vmovaps xmm12, [rsp+0xC0]
00007cf1741d5640  vmovaps xmm13, [rsp+0xD0]
00007cf1741d5649  vmovaps xmm15, [rsp+0xE0]
00007cf1741d5652  add rsp, 0xF0
00007cf1741d5659  pop r11
00007cf1741d565b  pop r10
00007cf1741d565d  pop r9
00007cf1741d565f  pop r8
00007cf1741d5661  pop rsi
00007cf1741d5662  pop rdi
00007cf1741d5663  pop rdx
00007cf1741d5664  pop rcx
00007cf1741d5665  pop rax
00007cf1741d5666  add rsp, 0x08
00007cf1741d566a  jmp 0x00007CF1741D031A
00007cf1741d566f  sub rsp, 0x08
00007cf1741d5673  push rax
00007cf1741d5674  push rcx
00007cf1741d5675  push rdx
00007cf1741d5676  push rdi
00007cf1741d5677  push rsi
00007cf1741d5678  push r8
00007cf1741d567a  push r9
00007cf1741d567c  push r10
00007cf1741d567e  push r11
00007cf1741d5680  sub rsp, 0xF0
00007cf1741d5687  vmovaps [rsp], xmm0
00007cf1741d568c  vmovaps [rsp+0x10], xmm2
00007cf1741d5692  vmovaps [rsp+0x20], xmm3
00007cf1741d5698  vmovaps [rsp+0x30], xmm4
00007cf1741d569e  vmovaps [rsp+0x40], xmm5
00007cf1741d56a4  vmovaps [rsp+0x50], xmm6
00007cf1741d56aa  vmovaps [rsp+0x60], xmm7
00007cf1741d56b0  vmovaps [rsp+0x70], xmm8
00007cf1741d56b6  vmovaps [rsp+0x80], xmm9
00007cf1741d56bf  vmovaps [rsp+0x90], xmm10
00007cf1741d56c8  vmovaps [rsp+0xA0], xmm11
00007cf1741d56d1  vmovaps [rsp+0xB0], xmm12
00007cf1741d56da  vmovaps [rsp+0xC0], xmm13
00007cf1741d56e3  vmovaps [rsp+0xD0], xmm14
00007cf1741d56ec  vmovaps [rsp+0xE0], xmm15
00007cf1741d56f5  sub rsp, 0x30
00007cf1741d56f9  movaps [rsp], xmm1
00007cf1741d56fd  movaps [rsp+0x10], xmm7
00007cf1741d5702  movaps [rsp+0x20], xmm11
00007cf1741d5708  lea rdi, [rsp]
00007cf1741d570c  mov esi, 0x00
00007cf1741d5711  mov rax, 0x611C8A33A530
00007cf1741d571b  call rax
00007cf1741d571d  movaps xmm1, [rsp]
00007cf1741d5721  add rsp, 0x30
00007cf1741d5725  vmovaps xmm0, [rsp]
00007cf1741d572a  vmovaps xmm2, [rsp+0x10]
00007cf1741d5730  vmovaps xmm3, [rsp+0x20]
00007cf1741d5736  vmovaps xmm4, [rsp+0x30]
00007cf1741d573c  vmovaps xmm5, [rsp+0x40]
00007cf1741d5742  vmovaps xmm6, [rsp+0x50]
00007cf1741d5748  vmovaps xmm7, [rsp+0x60]
00007cf1741d574e  vmovaps xmm8, [rsp+0x70]
00007cf1741d5754  vmovaps xmm9, [rsp+0x80]
00007cf1741d575d  vmovaps xmm10, [rsp+0x90]
00007cf1741d5766  vmovaps xmm11, [rsp+0xA0]
00007cf1741d576f  vmovaps xmm12, [rsp+0xB0]
00007cf1741d5778  vmovaps xmm13, [rsp+0xC0]
00007cf1741d5781  vmovaps xmm14, [rsp+0xD0]
00007cf1741d578a  vmovaps xmm15, [rsp+0xE0]
00007cf1741d5793  add rsp, 0xF0
00007cf1741d579a  pop r11
00007cf1741d579c  pop r10
00007cf1741d579e  pop r9
00007cf1741d57a0  pop r8
00007cf1741d57a2  pop rsi
00007cf1741d57a3  pop rdi
00007cf1741d57a4  pop rdx
00007cf1741d57a5  pop rcx
00007cf1741d57a6  pop rax
00007cf1741d57a7  add rsp, 0x08
00007cf1741d57ab  jmp 0x00007CF1741D033B
00007cf1741d57b0  call 0x00007CF17400E880
00007cf1741d57b5  jmp 0x00007CF1741D034E
00007cf1741d57ba  call 0x00007CF17400C380
00007cf1741d57bf  jmp 0x00007CF1741D0359
00007cf1741d57c4  call 0x00007CF17400D600
00007cf1741d57c9  jmp 0x00007CF1741D0364
00007cf1741d57ce  call 0x00007CF173FFF540
00007cf1741d57d3  jmp 0x00007CF1741D036F
00007cf1741d57d8  int3
00007cf1741d57d9  nop [rax], eax
00007cf1741d57e0  mov rax, [r15+0x40]
00007cf1741d57e4  mov r14, [r15+0x58]
00007cf1741d57e8  lea r12, [rax+r14*1]
00007cf1741d57ec  movaps xmm1, [r15+0x1D0]
00007cf1741d57f4  vmovaps [rsp+0x10], xmm1
00007cf1741d57fa  vmovaps xmm15, [rsp+0x10]
00007cf1741d5800  por xmm1, xmm15
00007cf1741d5805  movaps xmm14, [r15+0x1A0]
00007cf1741d580d  vmovaps [rsp+0x10], xmm14
00007cf1741d5813  vmovaps xmm13, [rsp+0x10]
00007cf1741d5819  por xmm14, xmm13
00007cf1741d581e  lea rax, [r12+0x30]
00007cf1741d5823  mov r11, [r13+rax*1]
00007cf1741d5828  lea rax, [r12+0x38]
00007cf1741d582d  mov r10, [r13+rax*1]
00007cf1741d5832  movq xmm13, r11
00007cf1741d5837  movq xmm12, r10
00007cf1741d583c  movq xmm13, xmm13
00007cf1741d5841  vmovaps [rsp+0x10], xmm13
00007cf1741d5847  movq xmm13, xmm13
00007cf1741d584c  movaps [r15+0x130], xmm13
00007cf1741d5854  movq xmm12, xmm12
00007cf1741d5859  vmovaps [rsp+0x20], xmm12
00007cf1741d585f  movq xmm12, xmm12
00007cf1741d5864  movaps [r15+0x280], xmm12
00007cf1741d586c  movaps xmm13, [r15+0x270]
00007cf1741d5874  vmovaps [rsp+0x30], xmm13
00007cf1741d587a  vmovaps xmm12, [rsp+0x30]
00007cf1741d5880  por xmm13, xmm12
00007cf1741d5885  lea rax, [r12+0x20]
00007cf1741d588a  mov r11, [r13+rax*1]
00007cf1741d588f  lea rax, [r12+0x28]
00007cf1741d5894  mov r10, [r13+rax*1]
00007cf1741d5899  movq xmm12, r11
00007cf1741d589e  movq xmm11, r10
00007cf1741d58a3  movq xmm12, xmm12
00007cf1741d58a8  vmovaps [rsp+0x30], xmm12
00007cf1741d58ae  movq xmm12, xmm12
00007cf1741d58b3  movaps [r15+0x150], xmm12
00007cf1741d58bb  movq xmm11, xmm11
00007cf1741d58c0  vmovaps [rsp+0x40], xmm11
00007cf1741d58c6  movq xmm11, xmm11
00007cf1741d58cb  movaps [r15+0x140], xmm11
00007cf1741d58d3  lea rax, [r12+0x10]
00007cf1741d58d8  mov r11, [r13+rax*1]
00007cf1741d58dd  lea rax, [r12+0x18]
00007cf1741d58e2  mov r10, [r13+rax*1]
00007cf1741d58e7  movq xmm12, r11
00007cf1741d58ec  movq xmm11, r10
00007cf1741d58f1  movq xmm12, xmm12
00007cf1741d58f6  vmovaps [rsp+0x50], xmm12
00007cf1741d58fc  movq xmm12, xmm12
00007cf1741d5901  movaps [r15+0x170], xmm12
00007cf1741d5909  movq xmm11, xmm11
00007cf1741d590e  vmovaps [rsp+0x60], xmm11
00007cf1741d5914  movq xmm11, xmm11
00007cf1741d5919  movaps [r15+0x160], xmm11
00007cf1741d5921  mov rax, [r13+r12*1]
00007cf1741d5926  vmovq xmm12, rax
00007cf1741d592b  vpbroadcastq xmm12, xmm12
00007cf1741d5930  lea rax, [r12+0x08]
00007cf1741d5935  mov r12, [r13+rax*1]
00007cf1741d593a  movq xmm11, r12
00007cf1741d593f  movaps [r15+0x230], xmm11
00007cf1741d5947  mov rax, [r15+0xF8]
00007cf1741d594e  lea r12, [rax+0x50]
00007cf1741d5952  movups xmm11, [r13+r12*1]
00007cf1741d5958  lea r12, [rax+0x60]
00007cf1741d595c  movups xmm10, [r13+r12*1]
00007cf1741d5962  lea r12, [rax+0x30]
00007cf1741d5966  movups xmm9, [r13+r12*1]
00007cf1741d596c  mov r12, [r15+0x50]
00007cf1741d5970  lea r11, [r12+r14*1]
00007cf1741d5974  mov [r15+0x60], r11
00007cf1741d5978  lea r12, [r14+0x40]
00007cf1741d597c  mov [r15+0x58], r12
00007cf1741d5980  movaps xmm8, xmm12
00007cf1741d5984  mulpd xmm8, xmm15
00007cf1741d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007cf1741d598f  ptest xmm7, xmm7
00007cf1741d5994  jnz 0x00007CF1741D67B7
00007cf1741d599a  movq xmm15, qword ptr [r15+0x230]
00007cf1741d59a3  vmovaps [rsp+0x70], xmm15
00007cf1741d59a9  vpermilpd xmm15, xmm15, 0x00
00007cf1741d59af  movaps xmm7, xmm9
00007cf1741d59b3  mulpd xmm7, xmm15
00007cf1741d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007cf1741d59bd  ptest xmm6, xmm6
00007cf1741d59c2  jnz 0x00007CF1741D68FB
00007cf1741d59c8  vxorps xmm15, xmm15, xmm15
00007cf1741d59cd  vpbroadcastq xmm15, xmm15
00007cf1741d59d2  movaps xmm9, xmm12
00007cf1741d59d6  mulpd xmm9, xmm10
00007cf1741d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007cf1741d59e1  ptest xmm6, xmm6
00007cf1741d59e6  jnz 0x00007CF1741D6A3D
00007cf1741d59ec  movaps xmm10, xmm12
00007cf1741d59f0  mulpd xmm10, xmm11
00007cf1741d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007cf1741d59fb  ptest xmm6, xmm6
00007cf1741d5a00  jnz 0x00007CF1741D6B81
00007cf1741d5a06  movaps xmm11, [r15+0x1F0]
00007cf1741d5a0e  movaps xmm6, xmm12
00007cf1741d5a12  mulpd xmm6, xmm11
00007cf1741d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007cf1741d5a1c  ptest xmm5, xmm5
00007cf1741d5a21  jnz 0x00007CF1741D6CC5
00007cf1741d5a27  movaps xmm12, [r15+0x2A0]
00007cf1741d5a2f  vmovaps [rsp+0x80], xmm12
00007cf1741d5a38  vmovaps xmm11, [rsp+0x80]
00007cf1741d5a41  por xmm12, xmm11
00007cf1741d5a46  movaps xmm11, [r15+0x250]
00007cf1741d5a4e  vmovaps [rsp+0x80], xmm11
00007cf1741d5a57  vmovaps xmm5, [rsp+0x80]
00007cf1741d5a60  por xmm11, xmm5
00007cf1741d5a65  vmovaps xmm4, [rsp+0x70]
00007cf1741d5a6b  vpermilpd xmm4, xmm4, 0x00
00007cf1741d5a71  movaps xmm3, xmm5
00007cf1741d5a74  mulpd xmm3, xmm4
00007cf1741d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007cf1741d5a7d  ptest xmm2, xmm2
00007cf1741d5a82  jnz 0x00007CF1741D6E07
00007cf1741d5a88  mov [rsp+0x80], rax
00007cf1741d5a90  xor eax, eax
00007cf1741d5a92  mov r14d, 0x200
00007cf1741d5a98  cmp r12, r14
00007cf1741d5a9b  cmc
00007cf1741d5a9c  lahf
00007cf1741d5a9d  seto al
00007cf1741d5aa0  mov [r15+0x108], eax
00007cf1741d5aa7  movaps xmm5, xmm8
00007cf1741d5aab  addpd xmm5, xmm15
00007cf1741d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007cf1741d5ab5  ptest xmm4, xmm4
00007cf1741d5aba  jnz 0x00007CF1741D6F47
00007cf1741d5ac0  movaps xmm8, [r15+0x1B0]
00007cf1741d5ac8  movaps xmm4, xmm9
00007cf1741d5acc  addpd xmm4, xmm8
00007cf1741d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007cf1741d5ad6  ptest xmm2, xmm2
00007cf1741d5adb  jnz 0x00007CF1741D7089
00007cf1741d5ae1  movaps xmm9, xmm10
00007cf1741d5ae5  addpd xmm9, xmm8
00007cf1741d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007cf1741d5af0  ptest xmm2, xmm2
00007cf1741d5af5  jnz 0x00007CF1741D71CB
00007cf1741d5afb  movaps xmm10, [r15+0x2F0]
00007cf1741d5b03  vmovaps [rsp+0x90], xmm10
00007cf1741d5b0c  vmovaps xmm8, [rsp+0x90]
00007cf1741d5b15  por xmm10, xmm8
00007cf1741d5b1a  movaps xmm8, [r15+0x2E0]
00007cf1741d5b22  vmovaps [rsp+0x90], xmm8
00007cf1741d5b2b  vmovaps xmm2, [rsp+0x90]
00007cf1741d5b34  por xmm8, xmm2
00007cf1741d5b39  movaps xmm2, [r15+0x2D0]
00007cf1741d5b41  vmovaps [rsp+0x90], xmm2
00007cf1741d5b4a  vmovaps [rsp+0xA0], xmm1
00007cf1741d5b53  vmovaps xmm1, [rsp+0x90]
00007cf1741d5b5c  por xmm2, xmm1
00007cf1741d5b60  movaps xmm1, [r15+0x200]
00007cf1741d5b68  vmovaps [rsp+0x90], xmm1
00007cf1741d5b71  vmovaps [rsp+0xB0], xmm15
00007cf1741d5b7a  vmovaps xmm15, [rsp+0x90]
00007cf1741d5b83  por xmm1, xmm15
00007cf1741d5b88  movaps xmm15, [r15+0x1C0]
00007cf1741d5b90  vmovaps [rsp+0x90], xmm15
00007cf1741d5b99  vmovaps [rsp+0xC0], xmm1
00007cf1741d5ba2  vmovaps xmm1, [rsp+0x90]
00007cf1741d5bab  por xmm15, xmm1
00007cf1741d5bb0  movaps xmm1, [r15+0x190]
00007cf1741d5bb8  vmovaps [rsp+0x90], xmm1
00007cf1741d5bc1  vmovaps [rsp+0xD0], xmm15
00007cf1741d5bca  vmovaps xmm15, [rsp+0x90]
00007cf1741d5bd3  por xmm1, xmm15
00007cf1741d5bd8  movaps xmm15, [r15+0x300]
00007cf1741d5be0  vmovaps [rsp+0x90], xmm15
00007cf1741d5be9  vmovaps [rsp+0xE0], xmm1
00007cf1741d5bf2  vmovaps xmm1, [rsp+0x90]
00007cf1741d5bfb  por xmm15, xmm1
00007cf1741d5c00  mov rax, [rsp+0x80]
00007cf1741d5c08  lea r14, [rax+0xA0]
00007cf1741d5c0f  movups xmm1, [r13+r14*1]
00007cf1741d5c15  lea r14, [rax+0xB0]
00007cf1741d5c1c  vmovaps [rsp+0x80], xmm1
00007cf1741d5c25  movups xmm1, [r13+r14*1]
00007cf1741d5c2b  vmovaps [rsp+0x90], xmm1
00007cf1741d5c34  vmovaps [rsp+0xF0], xmm15
00007cf1741d5c3d  vmovaps xmm15, [rsp+0xB0]
00007cf1741d5c46  vmovaps [rsp+0xB0], xmm14
00007cf1741d5c4f  movaps xmm1, xmm6
00007cf1741d5c52  addpd xmm1, xmm15
00007cf1741d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007cf1741d5c5c  ptest xmm14, xmm14
00007cf1741d5c62  jnz 0x00007CF1741D7323
00007cf1741d5c68  lea r14, [rax+0xF0]
00007cf1741d5c6f  movups xmm15, [r13+r14*1]
00007cf1741d5c75  movaps xmm14, xmm4
00007cf1741d5c79  addpd xmm14, xmm3
00007cf1741d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007cf1741d5c84  ptest xmm6, xmm6
00007cf1741d5c89  jnz 0x00007CF1741D746E
00007cf1741d5c8f  movaps xmm6, xmm9
00007cf1741d5c93  addpd xmm6, xmm7
00007cf1741d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007cf1741d5c9c  ptest xmm4, xmm4
00007cf1741d5ca1  jnz 0x00007CF1741D75B0
00007cf1741d5ca7  vmovaps xmm9, [rsp+0x70]
00007cf1741d5cad  vpermilpd xmm9, xmm9, 0x00
00007cf1741d5cb3  vmovaps xmm4, [rsp+0x90]
00007cf1741d5cbc  movaps xmm7, xmm4
00007cf1741d5cbf  mulpd xmm7, xmm9
00007cf1741d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007cf1741d5cc9  ptest xmm3, xmm3
00007cf1741d5cce  jnz 0x00007CF1741D76F1
00007cf1741d5cd4  vmovaps xmm9, [rsp+0x50]
00007cf1741d5cda  vpermilpd xmm9, xmm9, 0x00
00007cf1741d5ce0  movaps xmm4, xmm15
00007cf1741d5ce4  mulpd xmm4, xmm9
00007cf1741d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007cf1741d5cee  ptest xmm3, xmm3
00007cf1741d5cf3  jnz 0x00007CF1741D7832
00007cf1741d5cf9  lea r14, [rax+0xE0]
00007cf1741d5d00  movups xmm15, [r13+r14*1]
00007cf1741d5d06  vmovaps xmm9, [rsp+0x70]
00007cf1741d5d0c  vpermilpd xmm9, xmm9, 0x00
00007cf1741d5d12  vmovaps [rsp+0x70], xmm1
00007cf1741d5d18  vmovaps xmm1, [rsp+0x80]
00007cf1741d5d21  vmovaps [rsp+0x80], xmm15
00007cf1741d5d2a  movaps xmm3, xmm1
00007cf1741d5d2d  mulpd xmm3, xmm9
00007cf1741d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007cf1741d5d37  ptest xmm15, xmm15
00007cf1741d5d3d  jnz 0x00007CF1741D797E
00007cf1741d5d43  vmovaps xmm1, [rsp+0xF0]
00007cf1741d5d4c  vmovaps xmm15, [rsp+0xF0]
00007cf1741d5d55  por xmm1, xmm15
00007cf1741d5d5a  movaps [r15+0x300], xmm1
00007cf1741d5d62  vmovaps xmm15, [rsp+0xE0]
00007cf1741d5d6b  vmovaps xmm9, [rsp+0xE0]
00007cf1741d5d74  por xmm15, xmm9
00007cf1741d5d79  movaps [r15+0x190], xmm15
00007cf1741d5d81  vmovaps xmm9, [rsp+0x50]
00007cf1741d5d87  vpermilpd xmm9, xmm9, 0x00
00007cf1741d5d8d  vmovaps [rsp+0x90], xmm1
00007cf1741d5d96  vmovaps [rsp+0xE0], xmm15
00007cf1741d5d9f  vmovaps xmm15, [rsp+0x80]
00007cf1741d5da8  vmovaps [rsp+0x80], xmm14
00007cf1741d5db1  movaps xmm1, xmm15
00007cf1741d5db5  mulpd xmm1, xmm9
00007cf1741d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007cf1741d5dbf  ptest xmm14, xmm14
00007cf1741d5dc5  jnz 0x00007CF1741D7ABF
00007cf1741d5dcb  lea r14, [rax+0x90]
00007cf1741d5dd2  movups xmm15, [r13+r14*1]
00007cf1741d5dd8  vmovaps xmm14, [rsp+0xD0]
00007cf1741d5de1  vmovaps xmm9, [rsp+0xD0]
00007cf1741d5dea  por xmm14, xmm9
00007cf1741d5def  movaps [r15+0x1C0], xmm14
00007cf1741d5df7  vmovaps xmm9, [rsp+0xC0]
00007cf1741d5e00  vmovaps [rsp+0xD0], xmm1
00007cf1741d5e09  vmovaps xmm1, [rsp+0xC0]
00007cf1741d5e12  por xmm9, xmm1
00007cf1741d5e17  movaps [r15+0x200], xmm9
00007cf1741d5e1f  vmovaps [rsp+0xC0], xmm2
00007cf1741d5e28  vmovaps xmm1, [rsp+0xC0]
00007cf1741d5e31  por xmm2, xmm1
00007cf1741d5e35  movaps [r15+0x2D0], xmm2
00007cf1741d5e3d  vmovaps [rsp+0xC0], xmm8
00007cf1741d5e46  vmovaps xmm1, [rsp+0xC0]
00007cf1741d5e4f  por xmm8, xmm1
00007cf1741d5e54  movaps [r15+0x2E0], xmm8
00007cf1741d5e5c  vmovaps [rsp+0xC0], xmm15
00007cf1741d5e65  movaps xmm1, xmm5
00007cf1741d5e68  addpd xmm1, xmm7
00007cf1741d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007cf1741d5e71  ptest xmm15, xmm15
00007cf1741d5e77  jnz 0x00007CF1741D7C0B
00007cf1741d5e7d  vmovaps xmm15, [rsp+0x50]
00007cf1741d5e83  vpermilpd xmm15, xmm15, 0x00
00007cf1741d5e89  vmovaps xmm5, [rsp+0xC0]
00007cf1741d5e92  vmovaps [rsp+0xC0], xmm1
00007cf1741d5e9b  movaps xmm7, xmm5
00007cf1741d5e9e  mulpd xmm7, xmm15
00007cf1741d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007cf1741d5ea8  ptest xmm1, xmm1
00007cf1741d5ead  jnz 0x00007CF1741D7D4B
00007cf1741d5eb3  lea r14, [rax+0x80]
00007cf1741d5eba  movups xmm1, [r13+r14*1]
00007cf1741d5ec0  vmovaps xmm5, [rsp+0x70]
00007cf1741d5ec6  vmovaps [rsp+0x70], xmm1
00007cf1741d5ecc  movaps xmm15, xmm5
00007cf1741d5ed0  addpd xmm15, xmm3
00007cf1741d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007cf1741d5edb  ptest xmm1, xmm1
00007cf1741d5ee0  jnz 0x00007CF1741D7E96
00007cf1741d5ee6  vmovaps xmm5, [rsp+0x80]
00007cf1741d5eef  movaps xmm1, xmm5
00007cf1741d5ef2  addpd xmm1, xmm4
00007cf1741d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007cf1741d5efb  ptest xmm3, xmm3
00007cf1741d5f00  jnz 0x00007CF1741D7FD8
00007cf1741d5f06  vmovaps [rsp+0x80], xmm10
00007cf1741d5f0f  vmovaps xmm5, [rsp+0x80]
00007cf1741d5f18  por xmm10, xmm5
00007cf1741d5f1d  movaps [r15+0x2F0], xmm10
00007cf1741d5f25  vmovaps xmm5, [rsp+0x50]
00007cf1741d5f2b  vpermilpd xmm5, xmm5, 0x00
00007cf1741d5f31  vmovaps xmm3, [rsp+0x70]
00007cf1741d5f37  vmovaps [rsp+0x50], xmm1
00007cf1741d5f3d  movaps xmm4, xmm3
00007cf1741d5f40  mulpd xmm4, xmm5
00007cf1741d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007cf1741d5f49  ptest xmm1, xmm1
00007cf1741d5f4e  jnz 0x00007CF1741D8118
00007cf1741d5f54  lea r14, [rax+0xD0]
00007cf1741d5f5b  movups xmm1, [r13+r14*1]
00007cf1741d5f61  vmovaps xmm3, [rsp+0xD0]
00007cf1741d5f6a  vmovaps [rsp+0x70], xmm1
00007cf1741d5f70  movaps xmm5, xmm6
00007cf1741d5f73  addpd xmm5, xmm3
00007cf1741d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007cf1741d5f7c  ptest xmm1, xmm1
00007cf1741d5f81  jnz 0x00007CF1741D8262
00007cf1741d5f87  vmovaps xmm1, [rsp+0x60]
00007cf1741d5f8d  vpermilpd xmm1, xmm1, 0x00
00007cf1741d5f93  movaps xmm6, xmm9
00007cf1741d5f97  mulpd xmm6, xmm1
00007cf1741d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007cf1741d5fa0  ptest xmm3, xmm3
00007cf1741d5fa5  jnz 0x00007CF1741D83A2
00007cf1741d5fab  movaps [r15+0x260], xmm6
00007cf1741d5fb3  vxorps xmm1, xmm1, xmm1
00007cf1741d5fb7  vpbroadcastq xmm1, xmm1
00007cf1741d5fbc  movaps [r15+0x1B0], xmm1
00007cf1741d5fc4  vmovaps xmm1, [rsp+0x60]
00007cf1741d5fca  vpermilpd xmm1, xmm1, 0x00
00007cf1741d5fd0  vmovaps xmm3, [rsp+0x70]
00007cf1741d5fd6  vmovaps [rsp+0x70], xmm15
00007cf1741d5fdc  movaps xmm9, xmm3
00007cf1741d5fe0  mulpd xmm9, xmm1
00007cf1741d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007cf1741d5feb  ptest xmm15, xmm15
00007cf1741d5ff1  jnz 0x00007CF1741D84E3
00007cf1741d5ff7  lea r14, [rax+0xC0]
00007cf1741d5ffe  movups xmm1, [r13+r14*1]
00007cf1741d6004  vmovaps xmm3, [rsp+0xC0]
00007cf1741d600d  vmovaps [rsp+0x80], xmm1
00007cf1741d6016  movaps xmm15, xmm3
00007cf1741d601a  addpd xmm15, xmm7
00007cf1741d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007cf1741d6025  ptest xmm1, xmm1
00007cf1741d602a  jnz 0x00007CF1741D862F
00007cf1741d6030  vmovaps [rsp+0xC0], xmm13
00007cf1741d6039  vmovaps xmm1, [rsp+0xC0]
00007cf1741d6042  por xmm13, xmm1
00007cf1741d6047  movaps [r15+0x270], xmm13
00007cf1741d604f  vmovaps xmm1, [rsp+0xB0]
00007cf1741d6058  vmovaps xmm7, [rsp+0xB0]
00007cf1741d6061  por xmm1, xmm7
00007cf1741d6065  movaps [r15+0x1A0], xmm1
00007cf1741d606d  vmovaps xmm1, [rsp+0x60]
00007cf1741d6073  vpermilpd xmm1, xmm1, 0x00
00007cf1741d6079  vmovaps [rsp+0xB0], xmm1
00007cf1741d6082  vmovaps xmm1, [rsp+0x80]
00007cf1741d608b  vmovaps [rsp+0x80], xmm15
00007cf1741d6094  vmovaps xmm15, [rsp+0xB0]
00007cf1741d609d  vmovaps [rsp+0xB0], xmm14
00007cf1741d60a6  movaps xmm3, xmm1
00007cf1741d60a9  mulpd xmm3, xmm15
00007cf1741d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007cf1741d60b3  ptest xmm14, xmm14
00007cf1741d60b9  jnz 0x00007CF1741D8771
00007cf1741d60bf  lea r14, [rax+0x20]
00007cf1741d60c3  movups xmm1, [r13+r14*1]
00007cf1741d60c9  movaps [r15+0x110], xmm1
00007cf1741d60d1  vmovaps xmm14, [rsp+0x70]
00007cf1741d60d7  vmovaps [rsp+0x70], xmm1
00007cf1741d60dd  movaps xmm15, xmm14
00007cf1741d60e1  addpd xmm15, xmm4
00007cf1741d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007cf1741d60ec  ptest xmm1, xmm1
00007cf1741d60f1  jnz 0x00007CF1741D88BC
00007cf1741d60f7  vmovaps xmm1, [rsp+0x60]
00007cf1741d60fd  vpermilpd xmm1, xmm1, 0x00
00007cf1741d6103  movaps xmm14, xmm2
00007cf1741d6107  mulpd xmm14, xmm1
00007cf1741d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007cf1741d6112  ptest xmm4, xmm4
00007cf1741d6117  jnz 0x00007CF1741D89FF
00007cf1741d611d  vmovaps xmm4, [rsp+0x50]
00007cf1741d6123  movaps xmm1, xmm4
00007cf1741d6126  addpd xmm1, xmm9
00007cf1741d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007cf1741d6130  ptest xmm2, xmm2
00007cf1741d6135  jnz 0x00007CF1741D8B41
00007cf1741d613b  vmovaps xmm9, [rsp+0x30]
00007cf1741d6141  vpermilpd xmm9, xmm9, 0x00
00007cf1741d6147  vmovaps xmm2, [rsp+0x70]
00007cf1741d614d  vmovaps [rsp+0x50], xmm1
00007cf1741d6153  movaps xmm4, xmm2
00007cf1741d6156  mulpd xmm4, xmm9
00007cf1741d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007cf1741d6160  ptest xmm1, xmm1
00007cf1741d6165  jnz 0x00007CF1741D8C82
00007cf1741d616b  vmovaps xmm1, [rsp+0x30]
00007cf1741d6171  vpermilpd xmm1, xmm1, 0x00
00007cf1741d6177  vmovaps xmm2, [rsp+0x90]
00007cf1741d6180  vmovaps [rsp+0x60], xmm15
00007cf1741d6186  movaps xmm9, xmm2
00007cf1741d618a  mulpd xmm9, xmm1
00007cf1741d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007cf1741d6195  ptest xmm15, xmm15
00007cf1741d619b  jnz 0x00007CF1741D8DC3
00007cf1741d61a1  vmovaps xmm15, [rsp+0x80]
00007cf1741d61aa  movaps xmm1, xmm15
00007cf1741d61ae  addpd xmm1, xmm6
00007cf1741d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007cf1741d61b7  ptest xmm2, xmm2
00007cf1741d61bc  jnz 0x00007CF1741D8F05
00007cf1741d61c2  movaps xmm15, xmm5
00007cf1741d61c6  addpd xmm15, xmm3
00007cf1741d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007cf1741d61d1  ptest xmm6, xmm6
00007cf1741d61d6  jnz 0x00007CF1741D9046
00007cf1741d61dc  vmovaps xmm6, [rsp+0x30]
00007cf1741d61e2  vpermilpd xmm6, xmm6, 0x00
00007cf1741d61e8  movaps xmm5, xmm8
00007cf1741d61ec  mulpd xmm5, xmm6
00007cf1741d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007cf1741d61f5  ptest xmm3, xmm3
00007cf1741d61fa  jnz 0x00007CF1741D9188
00007cf1741d6200  vmovaps xmm8, [rsp+0x30]
00007cf1741d6206  vpermilpd xmm8, xmm8, 0x00
00007cf1741d620c  movaps xmm6, xmm10
00007cf1741d6210  mulpd xmm6, xmm8
00007cf1741d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007cf1741d621a  ptest xmm3, xmm3
00007cf1741d621f  jnz 0x00007CF1741D92C9
00007cf1741d6225  vmovaps xmm8, [rsp+0x60]
00007cf1741d622b  movaps xmm10, xmm8
00007cf1741d622f  addpd xmm10, xmm14
00007cf1741d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007cf1741d623a  ptest xmm3, xmm3
00007cf1741d623f  jnz 0x00007CF1741D940B
00007cf1741d6245  vmovaps xmm8, [rsp+0x50]
00007cf1741d624b  movaps xmm14, xmm8
00007cf1741d624f  addpd xmm14, xmm4
00007cf1741d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007cf1741d625a  ptest xmm3, xmm3
00007cf1741d625f  jnz 0x00007CF1741D954F
00007cf1741d6265  vmovaps xmm8, [rsp+0x40]
00007cf1741d626b  vpermilpd xmm8, xmm8, 0x00
00007cf1741d6271  movaps xmm4, xmm13
00007cf1741d6275  mulpd xmm4, xmm8
00007cf1741d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007cf1741d627f  ptest xmm3, xmm3
00007cf1741d6284  jnz 0x00007CF1741D9692
00007cf1741d628a  movaps xmm13, xmm15
00007cf1741d628e  addpd xmm13, xmm9
00007cf1741d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007cf1741d6299  ptest xmm8, xmm8
00007cf1741d629f  jnz 0x00007CF1741D97D4
00007cf1741d62a5  movaps xmm15, xmm1
00007cf1741d62a9  addpd xmm15, xmm5
00007cf1741d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007cf1741d62b4  ptest xmm9, xmm9
00007cf1741d62ba  jnz 0x00007CF1741D9918
00007cf1741d62c0  vmovaps [rsp+0x30], xmm11
00007cf1741d62c6  vmovaps xmm1, [rsp+0x30]
00007cf1741d62cc  por xmm11, xmm1
00007cf1741d62d1  movaps [r15+0x250], xmm11
00007cf1741d62d9  vmovaps [rsp+0x30], xmm12
00007cf1741d62df  vmovaps xmm1, [rsp+0x30]
00007cf1741d62e5  por xmm12, xmm1
00007cf1741d62ea  movaps [r15+0x2A0], xmm12
00007cf1741d62f2  vmovaps xmm1, [rsp+0xA0]
00007cf1741d62fb  vmovaps xmm11, [rsp+0xA0]
00007cf1741d6304  por xmm1, xmm11
00007cf1741d6309  movaps [r15+0x1D0], xmm1
00007cf1741d6311  lea r14, [rax+0x40]
00007cf1741d6315  movups xmm1, [r13+r14*1]
00007cf1741d631b  movaps [r15+0x2C0], xmm1
00007cf1741d6323  vmovaps xmm11, [rsp+0x40]
00007cf1741d6329  vpermilpd xmm11, xmm11, 0x00
00007cf1741d632f  vmovaps xmm8, [rsp+0xE0]
00007cf1741d6338  movaps xmm9, xmm8
00007cf1741d633c  mulpd xmm9, xmm11
00007cf1741d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007cf1741d6347  ptest xmm5, xmm5
00007cf1741d634c  jnz 0x00007CF1741D9A64
00007cf1741d6352  movaps xmm11, xmm10
00007cf1741d6356  addpd xmm11, xmm6
00007cf1741d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007cf1741d6361  ptest xmm8, xmm8
00007cf1741d6367  jnz 0x00007CF1741D9BA8
00007cf1741d636d  movaps xmm10, xmm14
00007cf1741d6371  addpd xmm10, xmm4
00007cf1741d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007cf1741d637c  ptest xmm8, xmm8
00007cf1741d6382  jnz 0x00007CF1741D9CEB
00007cf1741d6388  vmovaps xmm14, [rsp+0x40]
00007cf1741d638e  vpermilpd xmm14, xmm14, 0x00
00007cf1741d6394  movaps xmm8, xmm1
00007cf1741d6398  mulpd xmm8, xmm14
00007cf1741d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007cf1741d63a3  ptest xmm6, xmm6
00007cf1741d63a8  jnz 0x00007CF1741D9E2E
00007cf1741d63ae  movaps xmm1, [r15+0x2B0]
00007cf1741d63b6  vmovaps xmm14, [rsp+0x40]
00007cf1741d63bc  vpermilpd xmm14, xmm14, 0x00
00007cf1741d63c2  movaps xmm6, xmm1
00007cf1741d63c5  mulpd xmm6, xmm14
00007cf1741d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007cf1741d63cf  ptest xmm5, xmm5
00007cf1741d63d4  jnz 0x00007CF1741D9F71
00007cf1741d63da  vmovaps xmm1, [rsp+0x10]
00007cf1741d63e0  vpermilpd xmm1, xmm1, 0x00
00007cf1741d63e6  movaps xmm14, xmm12
00007cf1741d63ea  mulpd xmm14, xmm1
00007cf1741d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007cf1741d63f5  ptest xmm5, xmm5
00007cf1741d63fa  jnz 0x00007CF1741DA0B2
00007cf1741d6400  movaps xmm1, xmm13
00007cf1741d6404  addpd xmm1, xmm9
00007cf1741d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007cf1741d640e  ptest xmm12, xmm12
00007cf1741d6414  jnz 0x00007CF1741DA1F5
00007cf1741d641a  vmovaps xmm13, [rsp+0x10]
00007cf1741d6420  vpermilpd xmm13, xmm13, 0x00
00007cf1741d6426  movaps xmm12, xmm7
00007cf1741d642a  mulpd xmm12, xmm13
00007cf1741d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007cf1741d6435  ptest xmm9, xmm9
00007cf1741d643b  jnz 0x00007CF1741DA337
00007cf1741d6441  movaps xmm13, xmm15
00007cf1741d6445  addpd xmm13, xmm8
00007cf1741d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007cf1741d6450  ptest xmm9, xmm9
00007cf1741d6456  jnz 0x00007CF1741DA47A
00007cf1741d645c  movaps xmm15, [r15+0x290]
00007cf1741d6464  vmovaps xmm9, [rsp+0x10]
00007cf1741d646a  vpermilpd xmm9, xmm9, 0x00
00007cf1741d6470  movaps xmm8, xmm15
00007cf1741d6474  mulpd xmm8, xmm9
00007cf1741d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007cf1741d647f  ptest xmm7, xmm7
00007cf1741d6484  jnz 0x00007CF1741DA5BE
00007cf1741d648a  movaps xmm15, xmm11
00007cf1741d648e  addpd xmm15, xmm6
00007cf1741d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007cf1741d6499  ptest xmm9, xmm9
00007cf1741d649f  jnz 0x00007CF1741DA702
00007cf1741d64a5  movaps xmm11, [r15+0x1E0]
00007cf1741d64ad  vmovaps xmm9, [rsp+0x10]
00007cf1741d64b3  vpermilpd xmm9, xmm9, 0x00
00007cf1741d64b9  movaps xmm7, xmm11
00007cf1741d64bd  mulpd xmm7, xmm9
00007cf1741d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007cf1741d64c7  ptest xmm6, xmm6
00007cf1741d64cc  jnz 0x00007CF1741DA845
00007cf1741d64d2  movaps xmm11, xmm10
00007cf1741d64d6  addpd xmm11, xmm14
00007cf1741d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007cf1741d64e1  ptest xmm9, xmm9
00007cf1741d64e7  jnz 0x00007CF1741DA987
00007cf1741d64ed  lea r14, [rax+0x70]
00007cf1741d64f1  movups xmm14, [r13+r14*1]
00007cf1741d64f7  movaps [r15+0x240], xmm14
00007cf1741d64ff  movaps xmm10, xmm1
00007cf1741d6503  addpd xmm10, xmm12
00007cf1741d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007cf1741d650e  ptest xmm9, xmm9
00007cf1741d6514  jnz 0x00007CF1741DAAD5
00007cf1741d651a  movaps [r15+0x170], xmm10
00007cf1741d6522  vmovaps xmm1, [rsp+0x20]
00007cf1741d6528  vpermilpd xmm1, xmm1, 0x00
00007cf1741d652e  movaps xmm12, xmm14
00007cf1741d6532  mulpd xmm12, xmm1
00007cf1741d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007cf1741d653d  ptest xmm9, xmm9
00007cf1741d6543  jnz 0x00007CF1741DAC18
00007cf1741d6549  vmovaps xmm1, [rsp+0x20]
00007cf1741d654f  vpermilpd xmm1, xmm1, 0x00
00007cf1741d6555  vmovaps xmm9, [rsp+0xB0]
00007cf1741d655e  movaps xmm14, xmm9
00007cf1741d6562  mulpd xmm14, xmm1
00007cf1741d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007cf1741d656d  ptest xmm6, xmm6
00007cf1741d6572  jnz 0x00007CF1741DAD5B
00007cf1741d6578  movaps [r15+0x180], xmm14
00007cf1741d6580  movaps xmm1, xmm13
00007cf1741d6584  addpd xmm1, xmm8
00007cf1741d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007cf1741d658e  ptest xmm9, xmm9
00007cf1741d6594  jnz 0x00007CF1741DAE9E
00007cf1741d659a  movaps [r15+0x210], xmm1
00007cf1741d65a2  movups xmm13, [r13+rax*1]
00007cf1741d65a8  lea r14, [rax+0x10]
00007cf1741d65ac  movups xmm9, [r13+r14*1]
00007cf1741d65b2  movaps [r15+0x230], xmm9
00007cf1741d65ba  movaps xmm8, xmm15
00007cf1741d65be  addpd xmm8, xmm7
00007cf1741d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007cf1741d65c9  ptest xmm6, xmm6
00007cf1741d65ce  jnz 0x00007CF1741DAFF4
00007cf1741d65d4  movaps [r15+0x130], xmm8
00007cf1741d65dc  vmovaps xmm15, [rsp+0x20]
00007cf1741d65e2  vpermilpd xmm15, xmm15, 0x00
00007cf1741d65e8  movaps xmm7, xmm9
00007cf1741d65ec  mulpd xmm7, xmm15
00007cf1741d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007cf1741d65f6  ptest xmm6, xmm6
00007cf1741d65fb  jnz 0x00007CF1741DB137
00007cf1741d6601  movaps [r15+0x220], xmm7
00007cf1741d6609  vmovaps xmm15, [rsp+0x20]
00007cf1741d660f  vpermilpd xmm15, xmm15, 0x00
00007cf1741d6615  movaps xmm9, xmm13
00007cf1741d6619  mulpd xmm9, xmm15
00007cf1741d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007cf1741d6624  ptest xmm6, xmm6
00007cf1741d6629  jnz 0x00007CF1741DB279
00007cf1741d662f  movaps xmm15, xmm11
00007cf1741d6633  addpd xmm15, xmm12
00007cf1741d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007cf1741d663e  ptest xmm13, xmm13
00007cf1741d6644  jnz 0x00007CF1741DB3BD
00007cf1741d664a  movaps [r15+0x140], xmm15
00007cf1741d6652  movaps xmm13, xmm10
00007cf1741d6656  addpd xmm13, xmm14
00007cf1741d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007cf1741d6661  ptest xmm12, xmm12
00007cf1741d6667  jnz 0x00007CF1741DB501
00007cf1741d666d  movaps [r15+0x150], xmm13
00007cf1741d6675  movaps xmm14, xmm1
00007cf1741d6679  addpd xmm14, xmm7
00007cf1741d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007cf1741d6684  ptest xmm12, xmm12
00007cf1741d668a  jnz 0x00007CF1741DB645
00007cf1741d6690  movaps [r15+0x160], xmm14
00007cf1741d6698  movaps xmm1, xmm8
00007cf1741d669c  addpd xmm1, xmm9
00007cf1741d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007cf1741d66a6  ptest xmm12, xmm12
00007cf1741d66ac  jnz 0x00007CF1741DB787
00007cf1741d66b2  movaps [r15+0x120], xmm1
00007cf1741d66ba  movups [r13+r11*1], xmm15
00007cf1741d66c0  lea rax, [r11+0x10]
00007cf1741d66c4  movups [r13+rax*1], xmm13
00007cf1741d66ca  lea rax, [r11+0x20]
00007cf1741d66ce  movups [r13+rax*1], xmm14
00007cf1741d66d4  lea rax, [r11+0x30]
00007cf1741d66d8  movups [r13+rax*1], xmm1
00007cf1741d66de  mov eax, [r15+0x108]
00007cf1741d66e5  sahf
00007cf1741d66e6  jnz 0x00007CF1741D6718
00007cf1741d66e8  cmp dword ptr [r15+0x318], 0x00
00007cf1741d66f0  jz 0x00007CF1741DB900
00007cf1741d66f6  nop [rax+rax*1], ax
00007cf1741d66ff  nop [rax+rax*1], eax
00007cf1741d6707  mov eax, 0x410444
00007cf1741d670c  mov [r15+0x100], rax
00007cf1741d6713  jmp 0x00007CF173FFE110
00007cf1741d6718  cmp dword ptr [r15+0x318], 0x00
00007cf1741d6720  jz 0x00007CF1741D57E0
00007cf1741d6726  nop [rax+rax*1], ax
00007cf1741d672f  nop [rax+rax*1], eax
00007cf1741d6737  mov eax, 0x410278
00007cf1741d673c  mov [r15+0x100], rax
00007cf1741d6743  jmp 0x00007CF173FFE110
00007cf1741d6748  int3
00007cf1741d6749  call 0x00007CF17400A4B0
00007cf1741d674e  jmp 0x00007CF1741D5828
00007cf1741d6753  call 0x00007CF174009240
00007cf1741d6758  jmp 0x00007CF1741D5832
00007cf1741d675d  call 0x00007CF17400A4B0
00007cf1741d6762  jmp 0x00007CF1741D588F
00007cf1741d6767  call 0x00007CF174009240
00007cf1741d676c  jmp 0x00007CF1741D5899
00007cf1741d6771  call 0x00007CF17400A4B0
00007cf1741d6776  jmp 0x00007CF1741D58DD
00007cf1741d677b  call 0x00007CF174009240
00007cf1741d6780  jmp 0x00007CF1741D58E7
00007cf1741d6785  call 0x00007CF1740B47C0
00007cf1741d678a  jmp 0x00007CF1741D5926
00007cf1741d678f  call 0x00007CF17400B720
00007cf1741d6794  jmp 0x00007CF1741D593A
00007cf1741d6799  call 0x00007CF1740BFC30
00007cf1741d679e  jmp 0x00007CF1741D5958
00007cf1741d67a3  call 0x00007CF1740BE9C0
00007cf1741d67a8  jmp 0x00007CF1741D5962
00007cf1741d67ad  call 0x00007CF1740BD750
00007cf1741d67b2  jmp 0x00007CF1741D596C
00007cf1741d67b7  sub rsp, 0x08
00007cf1741d67bb  push rax
00007cf1741d67bc  push rcx
00007cf1741d67bd  push rdx
00007cf1741d67be  push rdi
00007cf1741d67bf  push rsi
00007cf1741d67c0  push r8
00007cf1741d67c2  push r9
00007cf1741d67c4  push r10
00007cf1741d67c6  push r11
00007cf1741d67c8  sub rsp, 0xF0
00007cf1741d67cf  vmovaps [rsp], xmm0
00007cf1741d67d4  vmovaps [rsp+0x10], xmm1
00007cf1741d67da  vmovaps [rsp+0x20], xmm2
00007cf1741d67e0  vmovaps [rsp+0x30], xmm3
00007cf1741d67e6  vmovaps [rsp+0x40], xmm4
00007cf1741d67ec  vmovaps [rsp+0x50], xmm5
00007cf1741d67f2  vmovaps [rsp+0x60], xmm6
00007cf1741d67f8  vmovaps [rsp+0x70], xmm7
00007cf1741d67fe  vmovaps [rsp+0x80], xmm9
00007cf1741d6807  vmovaps [rsp+0x90], xmm10
00007cf1741d6810  vmovaps [rsp+0xA0], xmm11
00007cf1741d6819  vmovaps [rsp+0xB0], xmm12
00007cf1741d6822  vmovaps [rsp+0xC0], xmm13
00007cf1741d682b  vmovaps [rsp+0xD0], xmm14
00007cf1741d6834  vmovaps [rsp+0xE0], xmm15
00007cf1741d683d  sub rsp, 0x30
00007cf1741d6841  movaps [rsp], xmm8
00007cf1741d6846  movaps [rsp+0x10], xmm12
00007cf1741d684c  movaps [rsp+0x20], xmm15
00007cf1741d6852  lea rdi, [rsp]
00007cf1741d6856  mov esi, 0x00
00007cf1741d685b  mov rax, 0x611C8A33A530
00007cf1741d6865  call rax
00007cf1741d6867  movaps xmm8, [rsp]
00007cf1741d686c  add rsp, 0x30
00007cf1741d6870  vmovaps xmm0, [rsp]
00007cf1741d6875  vmovaps xmm1, [rsp+0x10]
00007cf1741d687b  vmovaps xmm2, [rsp+0x20]
00007cf1741d6881  vmovaps xmm3, [rsp+0x30]
00007cf1741d6887  vmovaps xmm4, [rsp+0x40]
00007cf1741d688d  vmovaps xmm5, [rsp+0x50]
00007cf1741d6893  vmovaps xmm6, [rsp+0x60]
00007cf1741d6899  vmovaps xmm7, [rsp+0x70]
00007cf1741d689f  vmovaps xmm9, [rsp+0x80]
00007cf1741d68a8  vmovaps xmm10, [rsp+0x90]
00007cf1741d68b1  vmovaps xmm11, [rsp+0xA0]
00007cf1741d68ba  vmovaps xmm12, [rsp+0xB0]
00007cf1741d68c3  vmovaps xmm13, [rsp+0xC0]
00007cf1741d68cc  vmovaps xmm14, [rsp+0xD0]
00007cf1741d68d5  vmovaps xmm15, [rsp+0xE0]
00007cf1741d68de  add rsp, 0xF0
00007cf1741d68e5  pop r11
00007cf1741d68e7  pop r10
00007cf1741d68e9  pop r9
00007cf1741d68eb  pop r8
00007cf1741d68ed  pop rsi
00007cf1741d68ee  pop rdi
00007cf1741d68ef  pop rdx
00007cf1741d68f0  pop rcx
00007cf1741d68f1  pop rax
00007cf1741d68f2  add rsp, 0x08
00007cf1741d68f6  jmp 0x00007CF1741D599A
00007cf1741d68fb  sub rsp, 0x08
00007cf1741d68ff  push rax
00007cf1741d6900  push rcx
00007cf1741d6901  push rdx
00007cf1741d6902  push rdi
00007cf1741d6903  push rsi
00007cf1741d6904  push r8
00007cf1741d6906  push r9
00007cf1741d6908  push r10
00007cf1741d690a  push r11
00007cf1741d690c  sub rsp, 0xF0
00007cf1741d6913  vmovaps [rsp], xmm0
00007cf1741d6918  vmovaps [rsp+0x10], xmm1
00007cf1741d691e  vmovaps [rsp+0x20], xmm2
00007cf1741d6924  vmovaps [rsp+0x30], xmm3
00007cf1741d692a  vmovaps [rsp+0x40], xmm4
00007cf1741d6930  vmovaps [rsp+0x50], xmm5
00007cf1741d6936  vmovaps [rsp+0x60], xmm6
00007cf1741d693c  vmovaps [rsp+0x70], xmm8
00007cf1741d6942  vmovaps [rsp+0x80], xmm9
00007cf1741d694b  vmovaps [rsp+0x90], xmm10
00007cf1741d6954  vmovaps [rsp+0xA0], xmm11
00007cf1741d695d  vmovaps [rsp+0xB0], xmm12
00007cf1741d6966  vmovaps [rsp+0xC0], xmm13
00007cf1741d696f  vmovaps [rsp+0xD0], xmm14
00007cf1741d6978  vmovaps [rsp+0xE0], xmm15
00007cf1741d6981  sub rsp, 0x30
00007cf1741d6985  movaps [rsp], xmm7
00007cf1741d6989  movaps [rsp+0x10], xmm9
00007cf1741d698f  movaps [rsp+0x20], xmm15
00007cf1741d6995  lea rdi, [rsp]
00007cf1741d6999  mov esi, 0x00
00007cf1741d699e  mov rax, 0x611C8A33A530
00007cf1741d69a8  call rax
00007cf1741d69aa  movaps xmm7, [rsp]
00007cf1741d69ae  add rsp, 0x30
00007cf1741d69b2  vmovaps xmm0, [rsp]
00007cf1741d69b7  vmovaps xmm1, [rsp+0x10]
00007cf1741d69bd  vmovaps xmm2, [rsp+0x20]
00007cf1741d69c3  vmovaps xmm3, [rsp+0x30]
00007cf1741d69c9  vmovaps xmm4, [rsp+0x40]
00007cf1741d69cf  vmovaps xmm5, [rsp+0x50]
00007cf1741d69d5  vmovaps xmm6, [rsp+0x60]
00007cf1741d69db  vmovaps xmm8, [rsp+0x70]
00007cf1741d69e1  vmovaps xmm9, [rsp+0x80]
00007cf1741d69ea  vmovaps xmm10, [rsp+0x90]
00007cf1741d69f3  vmovaps xmm11, [rsp+0xA0]
00007cf1741d69fc  vmovaps xmm12, [rsp+0xB0]
00007cf1741d6a05  vmovaps xmm13, [rsp+0xC0]
00007cf1741d6a0e  vmovaps xmm14, [rsp+0xD0]
00007cf1741d6a17  vmovaps xmm15, [rsp+0xE0]
00007cf1741d6a20  add rsp, 0xF0
00007cf1741d6a27  pop r11
00007cf1741d6a29  pop r10
00007cf1741d6a2b  pop r9
00007cf1741d6a2d  pop r8
00007cf1741d6a2f  pop rsi
00007cf1741d6a30  pop rdi
00007cf1741d6a31  pop rdx
00007cf1741d6a32  pop rcx
00007cf1741d6a33  pop rax
00007cf1741d6a34  add rsp, 0x08
00007cf1741d6a38  jmp 0x00007CF1741D59C8
00007cf1741d6a3d  sub rsp, 0x08
00007cf1741d6a41  push rax
00007cf1741d6a42  push rcx
00007cf1741d6a43  push rdx
00007cf1741d6a44  push rdi
00007cf1741d6a45  push rsi
00007cf1741d6a46  push r8
00007cf1741d6a48  push r9
00007cf1741d6a4a  push r10
00007cf1741d6a4c  push r11
00007cf1741d6a4e  sub rsp, 0xF0
00007cf1741d6a55  vmovaps [rsp], xmm0
00007cf1741d6a5a  vmovaps [rsp+0x10], xmm1
00007cf1741d6a60  vmovaps [rsp+0x20], xmm2
00007cf1741d6a66  vmovaps [rsp+0x30], xmm3
00007cf1741d6a6c  vmovaps [rsp+0x40], xmm4
00007cf1741d6a72  vmovaps [rsp+0x50], xmm5
00007cf1741d6a78  vmovaps [rsp+0x60], xmm6
00007cf1741d6a7e  vmovaps [rsp+0x70], xmm7
00007cf1741d6a84  vmovaps [rsp+0x80], xmm8
00007cf1741d6a8d  vmovaps [rsp+0x90], xmm10
00007cf1741d6a96  vmovaps [rsp+0xA0], xmm11
00007cf1741d6a9f  vmovaps [rsp+0xB0], xmm12
00007cf1741d6aa8  vmovaps [rsp+0xC0], xmm13
00007cf1741d6ab1  vmovaps [rsp+0xD0], xmm14
00007cf1741d6aba  vmovaps [rsp+0xE0], xmm15
00007cf1741d6ac3  sub rsp, 0x30
00007cf1741d6ac7  movaps [rsp], xmm9
00007cf1741d6acc  movaps [rsp+0x10], xmm12
00007cf1741d6ad2  movaps [rsp+0x20], xmm10
00007cf1741d6ad8  lea rdi, [rsp]
00007cf1741d6adc  mov esi, 0x00
00007cf1741d6ae1  mov rax, 0x611C8A33A530
00007cf1741d6aeb  call rax
00007cf1741d6aed  movaps xmm9, [rsp]
00007cf1741d6af2  add rsp, 0x30
00007cf1741d6af6  vmovaps xmm0, [rsp]
00007cf1741d6afb  vmovaps xmm1, [rsp+0x10]
00007cf1741d6b01  vmovaps xmm2, [rsp+0x20]
00007cf1741d6b07  vmovaps xmm3, [rsp+0x30]
00007cf1741d6b0d  vmovaps xmm4, [rsp+0x40]
00007cf1741d6b13  vmovaps xmm5, [rsp+0x50]
00007cf1741d6b19  vmovaps xmm6, [rsp+0x60]
00007cf1741d6b1f  vmovaps xmm7, [rsp+0x70]
00007cf1741d6b25  vmovaps xmm8, [rsp+0x80]
00007cf1741d6b2e  vmovaps xmm10, [rsp+0x90]
00007cf1741d6b37  vmovaps xmm11, [rsp+0xA0]
00007cf1741d6b40  vmovaps xmm12, [rsp+0xB0]
00007cf1741d6b49  vmovaps xmm13, [rsp+0xC0]
00007cf1741d6b52  vmovaps xmm14, [rsp+0xD0]
00007cf1741d6b5b  vmovaps xmm15, [rsp+0xE0]
00007cf1741d6b64  add rsp, 0xF0
00007cf1741d6b6b  pop r11
00007cf1741d6b6d  pop r10
00007cf1741d6b6f  pop r9
00007cf1741d6b71  pop r8
00007cf1741d6b73  pop rsi
00007cf1741d6b74  pop rdi
00007cf1741d6b75  pop rdx
00007cf1741d6b76  pop rcx
00007cf1741d6b77  pop rax
00007cf1741d6b78  add rsp, 0x08
00007cf1741d6b7c  jmp 0x00007CF1741D59EC
00007cf1741d6b81  sub rsp, 0x08
00007cf1741d6b85  push rax
00007cf1741d6b86  push rcx
00007cf1741d6b87  push rdx
00007cf1741d6b88  push rdi
00007cf1741d6b89  push rsi
00007cf1741d6b8a  push r8
00007cf1741d6b8c  push r9
00007cf1741d6b8e  push r10
00007cf1741d6b90  push r11
00007cf1741d6b92  sub rsp, 0xF0
00007cf1741d6b99  vmovaps [rsp], xmm0
00007cf1741d6b9e  vmovaps [rsp+0x10], xmm1
00007cf1741d6ba4  vmovaps [rsp+0x20], xmm2
00007cf1741d6baa  vmovaps [rsp+0x30], xmm3
00007cf1741d6bb0  vmovaps [rsp+0x40], xmm4
00007cf1741d6bb6  vmovaps [rsp+0x50], xmm5
00007cf1741d6bbc  vmovaps [rsp+0x60], xmm6
00007cf1741d6bc2  vmovaps [rsp+0x70], xmm7
00007cf1741d6bc8  vmovaps [rsp+0x80], xmm8
00007cf1741d6bd1  vmovaps [rsp+0x90], xmm9
00007cf1741d6bda  vmovaps [rsp+0xA0], xmm11
00007cf1741d6be3  vmovaps [rsp+0xB0], xmm12
00007cf1741d6bec  vmovaps [rsp+0xC0], xmm13
00007cf1741d6bf5  vmovaps [rsp+0xD0], xmm14
00007cf1741d6bfe  vmovaps [rsp+0xE0], xmm15
00007cf1741d6c07  sub rsp, 0x30
00007cf1741d6c0b  movaps [rsp], xmm10
00007cf1741d6c10  movaps [rsp+0x10], xmm12
00007cf1741d6c16  movaps [rsp+0x20], xmm11
00007cf1741d6c1c  lea rdi, [rsp]
00007cf1741d6c20  mov esi, 0x00
00007cf1741d6c25  mov rax, 0x611C8A33A530
00007cf1741d6c2f  call rax
00007cf1741d6c31  movaps xmm10, [rsp]
00007cf1741d6c36  add rsp, 0x30
00007cf1741d6c3a  vmovaps xmm0, [rsp]
00007cf1741d6c3f  vmovaps xmm1, [rsp+0x10]
00007cf1741d6c45  vmovaps xmm2, [rsp+0x20]
00007cf1741d6c4b  vmovaps xmm3, [rsp+0x30]
00007cf1741d6c51  vmovaps xmm4, [rsp+0x40]
00007cf1741d6c57  vmovaps xmm5, [rsp+0x50]
00007cf1741d6c5d  vmovaps xmm6, [rsp+0x60]
00007cf1741d6c63  vmovaps xmm7, [rsp+0x70]
00007cf1741d6c69  vmovaps xmm8, [rsp+0x80]
00007cf1741d6c72  vmovaps xmm9, [rsp+0x90]
00007cf1741d6c7b  vmovaps xmm11, [rsp+0xA0]
00007cf1741d6c84  vmovaps xmm12, [rsp+0xB0]
00007cf1741d6c8d  vmovaps xmm13, [rsp+0xC0]
00007cf1741d6c96  vmovaps xmm14, [rsp+0xD0]
00007cf1741d6c9f  vmovaps xmm15, [rsp+0xE0]
00007cf1741d6ca8  add rsp, 0xF0
00007cf1741d6caf  pop r11
00007cf1741d6cb1  pop r10
00007cf1741d6cb3  pop r9
00007cf1741d6cb5  pop r8
00007cf1741d6cb7  pop rsi
00007cf1741d6cb8  pop rdi
00007cf1741d6cb9  pop rdx
00007cf1741d6cba  pop rcx
00007cf1741d6cbb  pop rax
00007cf1741d6cbc  add rsp, 0x08
00007cf1741d6cc0  jmp 0x00007CF1741D5A06
00007cf1741d6cc5  sub rsp, 0x08
00007cf1741d6cc9  push rax
00007cf1741d6cca  push rcx
00007cf1741d6ccb  push rdx
00007cf1741d6ccc  push rdi
00007cf1741d6ccd  push rsi
00007cf1741d6cce  push r8
00007cf1741d6cd0  push r9
00007cf1741d6cd2  push r10
00007cf1741d6cd4  push r11
00007cf1741d6cd6  sub rsp, 0xF0
00007cf1741d6cdd  vmovaps [rsp], xmm0
00007cf1741d6ce2  vmovaps [rsp+0x10], xmm1
00007cf1741d6ce8  vmovaps [rsp+0x20], xmm2
00007cf1741d6cee  vmovaps [rsp+0x30], xmm3
00007cf1741d6cf4  vmovaps [rsp+0x40], xmm4
00007cf1741d6cfa  vmovaps [rsp+0x50], xmm5
00007cf1741d6d00  vmovaps [rsp+0x60], xmm7
00007cf1741d6d06  vmovaps [rsp+0x70], xmm8
00007cf1741d6d0c  vmovaps [rsp+0x80], xmm9
00007cf1741d6d15  vmovaps [rsp+0x90], xmm10
00007cf1741d6d1e  vmovaps [rsp+0xA0], xmm11
00007cf1741d6d27  vmovaps [rsp+0xB0], xmm12
00007cf1741d6d30  vmovaps [rsp+0xC0], xmm13
00007cf1741d6d39  vmovaps [rsp+0xD0], xmm14
00007cf1741d6d42  vmovaps [rsp+0xE0], xmm15
00007cf1741d6d4b  sub rsp, 0x30
00007cf1741d6d4f  movaps [rsp], xmm6
00007cf1741d6d53  movaps [rsp+0x10], xmm12
00007cf1741d6d59  movaps [rsp+0x20], xmm11
00007cf1741d6d5f  lea rdi, [rsp]
00007cf1741d6d63  mov esi, 0x00
00007cf1741d6d68  mov rax, 0x611C8A33A530
00007cf1741d6d72  call rax
00007cf1741d6d74  movaps xmm6, [rsp]
00007cf1741d6d78  add rsp, 0x30
00007cf1741d6d7c  vmovaps xmm0, [rsp]
00007cf1741d6d81  vmovaps xmm1, [rsp+0x10]
00007cf1741d6d87  vmovaps xmm2, [rsp+0x20]
00007cf1741d6d8d  vmovaps xmm3, [rsp+0x30]
00007cf1741d6d93  vmovaps xmm4, [rsp+0x40]
00007cf1741d6d99  vmovaps xmm5, [rsp+0x50]
00007cf1741d6d9f  vmovaps xmm7, [rsp+0x60]
00007cf1741d6da5  vmovaps xmm8, [rsp+0x70]
00007cf1741d6dab  vmovaps xmm9, [rsp+0x80]
00007cf1741d6db4  vmovaps xmm10, [rsp+0x90]
00007cf1741d6dbd  vmovaps xmm11, [rsp+0xA0]
00007cf1741d6dc6  vmovaps xmm12, [rsp+0xB0]
00007cf1741d6dcf  vmovaps xmm13, [rsp+0xC0]
00007cf1741d6dd8  vmovaps xmm14, [rsp+0xD0]
00007cf1741d6de1  vmovaps xmm15, [rsp+0xE0]
00007cf1741d6dea  add rsp, 0xF0
00007cf1741d6df1  pop r11
00007cf1741d6df3  pop r10
00007cf1741d6df5  pop r9
00007cf1741d6df7  pop r8
00007cf1741d6df9  pop rsi
00007cf1741d6dfa  pop rdi
00007cf1741d6dfb  pop rdx
00007cf1741d6dfc  pop rcx
00007cf1741d6dfd  pop rax
00007cf1741d6dfe  add rsp, 0x08
00007cf1741d6e02  jmp 0x00007CF1741D5A27
00007cf1741d6e07  sub rsp, 0x08
00007cf1741d6e0b  push rax
00007cf1741d6e0c  push rcx
00007cf1741d6e0d  push rdx
00007cf1741d6e0e  push rdi
00007cf1741d6e0f  push rsi
00007cf1741d6e10  push r8
00007cf1741d6e12  push r9
00007cf1741d6e14  push r10
00007cf1741d6e16  push r11
00007cf1741d6e18  sub rsp, 0xF0
00007cf1741d6e1f  vmovaps [rsp], xmm0
00007cf1741d6e24  vmovaps [rsp+0x10], xmm1
00007cf1741d6e2a  vmovaps [rsp+0x20], xmm2
00007cf1741d6e30  vmovaps [rsp+0x30], xmm4
00007cf1741d6e36  vmovaps [rsp+0x40], xmm5
00007cf1741d6e3c  vmovaps [rsp+0x50], xmm6
00007cf1741d6e42  vmovaps [rsp+0x60], xmm7
00007cf1741d6e48  vmovaps [rsp+0x70], xmm8
00007cf1741d6e4e  vmovaps [rsp+0x80], xmm9
00007cf1741d6e57  vmovaps [rsp+0x90], xmm10
00007cf1741d6e60  vmovaps [rsp+0xA0], xmm11
00007cf1741d6e69  vmovaps [rsp+0xB0], xmm12
00007cf1741d6e72  vmovaps [rsp+0xC0], xmm13
00007cf1741d6e7b  vmovaps [rsp+0xD0], xmm14
00007cf1741d6e84  vmovaps [rsp+0xE0], xmm15
00007cf1741d6e8d  sub rsp, 0x30
00007cf1741d6e91  movaps [rsp], xmm3
00007cf1741d6e95  movaps [rsp+0x10], xmm5
00007cf1741d6e9a  movaps [rsp+0x20], xmm4
00007cf1741d6e9f  lea rdi, [rsp]
00007cf1741d6ea3  mov esi, 0x00
00007cf1741d6ea8  mov rax, 0x611C8A33A530
00007cf1741d6eb2  call rax
00007cf1741d6eb4  movaps xmm3, [rsp]
00007cf1741d6eb8  add rsp, 0x30
00007cf1741d6ebc  vmovaps xmm0, [rsp]
00007cf1741d6ec1  vmovaps xmm1, [rsp+0x10]
00007cf1741d6ec7  vmovaps xmm2, [rsp+0x20]
00007cf1741d6ecd  vmovaps xmm4, [rsp+0x30]
00007cf1741d6ed3  vmovaps xmm5, [rsp+0x40]
00007cf1741d6ed9  vmovaps xmm6, [rsp+0x50]
00007cf1741d6edf  vmovaps xmm7, [rsp+0x60]
00007cf1741d6ee5  vmovaps xmm8, [rsp+0x70]
00007cf1741d6eeb  vmovaps xmm9, [rsp+0x80]
00007cf1741d6ef4  vmovaps xmm10, [rsp+0x90]
00007cf1741d6efd  vmovaps xmm11, [rsp+0xA0]
00007cf1741d6f06  vmovaps xmm12, [rsp+0xB0]
00007cf1741d6f0f  vmovaps xmm13, [rsp+0xC0]
00007cf1741d6f18  vmovaps xmm14, [rsp+0xD0]
00007cf1741d6f21  vmovaps xmm15, [rsp+0xE0]
00007cf1741d6f2a  add rsp, 0xF0
00007cf1741d6f31  pop r11
00007cf1741d6f33  pop r10
00007cf1741d6f35  pop r9
00007cf1741d6f37  pop r8
00007cf1741d6f39  pop rsi
00007cf1741d6f3a  pop rdi
00007cf1741d6f3b  pop rdx
00007cf1741d6f3c  pop rcx
00007cf1741d6f3d  pop rax
00007cf1741d6f3e  add rsp, 0x08
00007cf1741d6f42  jmp 0x00007CF1741D5A88
00007cf1741d6f47  sub rsp, 0x08
00007cf1741d6f4b  push rax
00007cf1741d6f4c  push rcx
00007cf1741d6f4d  push rdx
00007cf1741d6f4e  push rdi
00007cf1741d6f4f  push rsi
00007cf1741d6f50  push r8
00007cf1741d6f52  push r9
00007cf1741d6f54  push r10
00007cf1741d6f56  push r11
00007cf1741d6f58  sub rsp, 0xF0
00007cf1741d6f5f  vmovaps [rsp], xmm0
00007cf1741d6f64  vmovaps [rsp+0x10], xmm1
00007cf1741d6f6a  vmovaps [rsp+0x20], xmm2
00007cf1741d6f70  vmovaps [rsp+0x30], xmm3
00007cf1741d6f76  vmovaps [rsp+0x40], xmm4
00007cf1741d6f7c  vmovaps [rsp+0x50], xmm6
00007cf1741d6f82  vmovaps [rsp+0x60], xmm7
00007cf1741d6f88  vmovaps [rsp+0x70], xmm8
00007cf1741d6f8e  vmovaps [rsp+0x80], xmm9
00007cf1741d6f97  vmovaps [rsp+0x90], xmm10
00007cf1741d6fa0  vmovaps [rsp+0xA0], xmm11
00007cf1741d6fa9  vmovaps [rsp+0xB0], xmm12
00007cf1741d6fb2  vmovaps [rsp+0xC0], xmm13
00007cf1741d6fbb  vmovaps [rsp+0xD0], xmm14
00007cf1741d6fc4  vmovaps [rsp+0xE0], xmm15
00007cf1741d6fcd  sub rsp, 0x30
00007cf1741d6fd1  movaps [rsp], xmm5
00007cf1741d6fd5  movaps [rsp+0x10], xmm8
00007cf1741d6fdb  movaps [rsp+0x20], xmm15
00007cf1741d6fe1  lea rdi, [rsp]
00007cf1741d6fe5  mov esi, 0x00
00007cf1741d6fea  mov rax, 0x611C8A33A530
00007cf1741d6ff4  call rax
00007cf1741d6ff6  movaps xmm5, [rsp]
00007cf1741d6ffa  add rsp, 0x30
00007cf1741d6ffe  vmovaps xmm0, [rsp]
00007cf1741d7003  vmovaps xmm1, [rsp+0x10]
00007cf1741d7009  vmovaps xmm2, [rsp+0x20]
00007cf1741d700f  vmovaps xmm3, [rsp+0x30]
00007cf1741d7015  vmovaps xmm4, [rsp+0x40]
00007cf1741d701b  vmovaps xmm6, [rsp+0x50]
00007cf1741d7021  vmovaps xmm7, [rsp+0x60]
00007cf1741d7027  vmovaps xmm8, [rsp+0x70]
00007cf1741d702d  vmovaps xmm9, [rsp+0x80]
00007cf1741d7036  vmovaps xmm10, [rsp+0x90]
00007cf1741d703f  vmovaps xmm11, [rsp+0xA0]
00007cf1741d7048  vmovaps xmm12, [rsp+0xB0]
00007cf1741d7051  vmovaps xmm13, [rsp+0xC0]
00007cf1741d705a  vmovaps xmm14, [rsp+0xD0]
00007cf1741d7063  vmovaps xmm15, [rsp+0xE0]
00007cf1741d706c  add rsp, 0xF0
00007cf1741d7073  pop r11
00007cf1741d7075  pop r10
00007cf1741d7077  pop r9
00007cf1741d7079  pop r8
00007cf1741d707b  pop rsi
00007cf1741d707c  pop rdi
00007cf1741d707d  pop rdx
00007cf1741d707e  pop rcx
00007cf1741d707f  pop rax
00007cf1741d7080  add rsp, 0x08
00007cf1741d7084  jmp 0x00007CF1741D5AC0
00007cf1741d7089  sub rsp, 0x08
00007cf1741d708d  push rax
00007cf1741d708e  push rcx
00007cf1741d708f  push rdx
00007cf1741d7090  push rdi
00007cf1741d7091  push rsi
00007cf1741d7092  push r8
00007cf1741d7094  push r9
00007cf1741d7096  push r10
00007cf1741d7098  push r11
00007cf1741d709a  sub rsp, 0xF0
00007cf1741d70a1  vmovaps [rsp], xmm0
00007cf1741d70a6  vmovaps [rsp+0x10], xmm1
00007cf1741d70ac  vmovaps [rsp+0x20], xmm2
00007cf1741d70b2  vmovaps [rsp+0x30], xmm3
00007cf1741d70b8  vmovaps [rsp+0x40], xmm5
00007cf1741d70be  vmovaps [rsp+0x50], xmm6
00007cf1741d70c4  vmovaps [rsp+0x60], xmm7
00007cf1741d70ca  vmovaps [rsp+0x70], xmm8
00007cf1741d70d0  vmovaps [rsp+0x80], xmm9
00007cf1741d70d9  vmovaps [rsp+0x90], xmm10
00007cf1741d70e2  vmovaps [rsp+0xA0], xmm11
00007cf1741d70eb  vmovaps [rsp+0xB0], xmm12
00007cf1741d70f4  vmovaps [rsp+0xC0], xmm13
00007cf1741d70fd  vmovaps [rsp+0xD0], xmm14
00007cf1741d7106  vmovaps [rsp+0xE0], xmm15
00007cf1741d710f  sub rsp, 0x30
00007cf1741d7113  movaps [rsp], xmm4
00007cf1741d7117  movaps [rsp+0x10], xmm9
00007cf1741d711d  movaps [rsp+0x20], xmm8
00007cf1741d7123  lea rdi, [rsp]
00007cf1741d7127  mov esi, 0x00
00007cf1741d712c  mov rax, 0x611C8A33A530
00007cf1741d7136  call rax
00007cf1741d7138  movaps xmm4, [rsp]
00007cf1741d713c  add rsp, 0x30
00007cf1741d7140  vmovaps xmm0, [rsp]
00007cf1741d7145  vmovaps xmm1, [rsp+0x10]
00007cf1741d714b  vmovaps xmm2, [rsp+0x20]
00007cf1741d7151  vmovaps xmm3, [rsp+0x30]
00007cf1741d7157  vmovaps xmm5, [rsp+0x40]
00007cf1741d715d  vmovaps xmm6, [rsp+0x50]
00007cf1741d7163  vmovaps xmm7, [rsp+0x60]
00007cf1741d7169  vmovaps xmm8, [rsp+0x70]
00007cf1741d716f  vmovaps xmm9, [rsp+0x80]
00007cf1741d7178  vmovaps xmm10, [rsp+0x90]
00007cf1741d7181  vmovaps xmm11, [rsp+0xA0]
00007cf1741d718a  vmovaps xmm12, [rsp+0xB0]
00007cf1741d7193  vmovaps xmm13, [rsp+0xC0]
00007cf1741d719c  vmovaps xmm14, [rsp+0xD0]
00007cf1741d71a5  vmovaps xmm15, [rsp+0xE0]
00007cf1741d71ae  add rsp, 0xF0
00007cf1741d71b5  pop r11
00007cf1741d71b7  pop r10
00007cf1741d71b9  pop r9
00007cf1741d71bb  pop r8
00007cf1741d71bd  pop rsi
00007cf1741d71be  pop rdi
00007cf1741d71bf  pop rdx
00007cf1741d71c0  pop rcx
00007cf1741d71c1  pop rax
00007cf1741d71c2  add rsp, 0x08
00007cf1741d71c6  jmp 0x00007CF1741D5AE1
00007cf1741d71cb  sub rsp, 0x08
00007cf1741d71cf  push rax
00007cf1741d71d0  push rcx
00007cf1741d71d1  push rdx
00007cf1741d71d2  push rdi
00007cf1741d71d3  push rsi
00007cf1741d71d4  push r8
00007cf1741d71d6  push r9
00007cf1741d71d8  push r10
00007cf1741d71da  push r11
00007cf1741d71dc  sub rsp, 0xF0
00007cf1741d71e3  vmovaps [rsp], xmm0
00007cf1741d71e8  vmovaps [rsp+0x10], xmm1
00007cf1741d71ee  vmovaps [rsp+0x20], xmm2
00007cf1741d71f4  vmovaps [rsp+0x30], xmm3
00007cf1741d71fa  vmovaps [rsp+0x40], xmm4
00007cf1741d7200  vmovaps [rsp+0x50], xmm5
00007cf1741d7206  vmovaps [rsp+0x60], xmm6
00007cf1741d720c  vmovaps [rsp+0x70], xmm7
00007cf1741d7212  vmovaps [rsp+0x80], xmm8
00007cf1741d721b  vmovaps [rsp+0x90], xmm10
00007cf1741d7224  vmovaps [rsp+0xA0], xmm11
00007cf1741d722d  vmovaps [rsp+0xB0], xmm12
00007cf1741d7236  vmovaps [rsp+0xC0], xmm13
00007cf1741d723f  vmovaps [rsp+0xD0], xmm14
00007cf1741d7248  vmovaps [rsp+0xE0], xmm15
00007cf1741d7251  sub rsp, 0x30
00007cf1741d7255  movaps [rsp], xmm9
00007cf1741d725a  movaps [rsp+0x10], xmm10
00007cf1741d7260  movaps [rsp+0x20], xmm8
00007cf1741d7266  lea rdi, [rsp]
00007cf1741d726a  mov esi, 0x00
00007cf1741d726f  mov rax, 0x611C8A33A530
00007cf1741d7279  call rax
00007cf1741d727b  movaps xmm9, [rsp]
00007cf1741d7280  add rsp, 0x30
00007cf1741d7284  vmovaps xmm0, [rsp]
00007cf1741d7289  vmovaps xmm1, [rsp+0x10]
00007cf1741d728f  vmovaps xmm2, [rsp+0x20]
00007cf1741d7295  vmovaps xmm3, [rsp+0x30]
00007cf1741d729b  vmovaps xmm4, [rsp+0x40]
00007cf1741d72a1  vmovaps xmm5, [rsp+0x50]
00007cf1741d72a7  vmovaps xmm6, [rsp+0x60]
00007cf1741d72ad  vmovaps xmm7, [rsp+0x70]
00007cf1741d72b3  vmovaps xmm8, [rsp+0x80]
00007cf1741d72bc  vmovaps xmm10, [rsp+0x90]
00007cf1741d72c5  vmovaps xmm11, [rsp+0xA0]
00007cf1741d72ce  vmovaps xmm12, [rsp+0xB0]
00007cf1741d72d7  vmovaps xmm13, [rsp+0xC0]
00007cf1741d72e0  vmovaps xmm14, [rsp+0xD0]
00007cf1741d72e9  vmovaps xmm15, [rsp+0xE0]
00007cf1741d72f2  add rsp, 0xF0
00007cf1741d72f9  pop r11
00007cf1741d72fb  pop r10
00007cf1741d72fd  pop r9
00007cf1741d72ff  pop r8
00007cf1741d7301  pop rsi
00007cf1741d7302  pop rdi
00007cf1741d7303  pop rdx
00007cf1741d7304  pop rcx
00007cf1741d7305  pop rax
00007cf1741d7306  add rsp, 0x08
00007cf1741d730a  jmp 0x00007CF1741D5AFB
00007cf1741d730f  call 0x00007CF1740D64F0
00007cf1741d7314  jmp 0x00007CF1741D5C15
00007cf1741d7319  call 0x00007CF1740D64F0
00007cf1741d731e  jmp 0x00007CF1741D5C2B
00007cf1741d7323  sub rsp, 0x08
00007cf1741d7327  push rax
00007cf1741d7328  push rcx
00007cf1741d7329  push rdx
00007cf1741d732a  push rdi
00007cf1741d732b  push rsi
00007cf1741d732c  push r8
00007cf1741d732e  push r9
00007cf1741d7330  push r10
00007cf1741d7332  push r11
00007cf1741d7334  sub rsp, 0xF0
00007cf1741d733b  vmovaps [rsp], xmm0
00007cf1741d7340  vmovaps [rsp+0x10], xmm2
00007cf1741d7346  vmovaps [rsp+0x20], xmm3
00007cf1741d734c  vmovaps [rsp+0x30], xmm4
00007cf1741d7352  vmovaps [rsp+0x40], xmm5
00007cf1741d7358  vmovaps [rsp+0x50], xmm6
00007cf1741d735e  vmovaps [rsp+0x60], xmm7
00007cf1741d7364  vmovaps [rsp+0x70], xmm8
00007cf1741d736a  vmovaps [rsp+0x80], xmm9
00007cf1741d7373  vmovaps [rsp+0x90], xmm10
00007cf1741d737c  vmovaps [rsp+0xA0], xmm11
00007cf1741d7385  vmovaps [rsp+0xB0], xmm12
00007cf1741d738e  vmovaps [rsp+0xC0], xmm13
00007cf1741d7397  vmovaps [rsp+0xD0], xmm14
00007cf1741d73a0  vmovaps [rsp+0xE0], xmm15
00007cf1741d73a9  sub rsp, 0x30
00007cf1741d73ad  movaps [rsp], xmm1
00007cf1741d73b1  movaps [rsp+0x10], xmm6
00007cf1741d73b6  movaps [rsp+0x20], xmm15
00007cf1741d73bc  lea rdi, [rsp]
00007cf1741d73c0  mov esi, 0x00
00007cf1741d73c5  mov rax, 0x611C8A33A530
00007cf1741d73cf  call rax
00007cf1741d73d1  movaps xmm1, [rsp]
00007cf1741d73d5  add rsp, 0x30
00007cf1741d73d9  vmovaps xmm0, [rsp]
00007cf1741d73de  vmovaps xmm2, [rsp+0x10]
00007cf1741d73e4  vmovaps xmm3, [rsp+0x20]
00007cf1741d73ea  vmovaps xmm4, [rsp+0x30]
00007cf1741d73f0  vmovaps xmm5, [rsp+0x40]
00007cf1741d73f6  vmovaps xmm6, [rsp+0x50]
00007cf1741d73fc  vmovaps xmm7, [rsp+0x60]
00007cf1741d7402  vmovaps xmm8, [rsp+0x70]
00007cf1741d7408  vmovaps xmm9, [rsp+0x80]
00007cf1741d7411  vmovaps xmm10, [rsp+0x90]
00007cf1741d741a  vmovaps xmm11, [rsp+0xA0]
00007cf1741d7423  vmovaps xmm12, [rsp+0xB0]
00007cf1741d742c  vmovaps xmm13, [rsp+0xC0]
00007cf1741d7435  vmovaps xmm14, [rsp+0xD0]
00007cf1741d743e  vmovaps xmm15, [rsp+0xE0]
00007cf1741d7447  add rsp, 0xF0
00007cf1741d744e  pop r11
00007cf1741d7450  pop r10
00007cf1741d7452  pop r9
00007cf1741d7454  pop r8
00007cf1741d7456  pop rsi
00007cf1741d7457  pop rdi
00007cf1741d7458  pop rdx
00007cf1741d7459  pop rcx
00007cf1741d745a  pop rax
00007cf1741d745b  add rsp, 0x08
00007cf1741d745f  jmp 0x00007CF1741D5C68
00007cf1741d7464  call 0x00007CF1740E5820
00007cf1741d7469  jmp 0x00007CF1741D5C75
00007cf1741d746e  sub rsp, 0x08
00007cf1741d7472  push rax
00007cf1741d7473  push rcx
00007cf1741d7474  push rdx
00007cf1741d7475  push rdi
00007cf1741d7476  push rsi
00007cf1741d7477  push r8
00007cf1741d7479  push r9
00007cf1741d747b  push r10
00007cf1741d747d  push r11
00007cf1741d747f  sub rsp, 0xF0
00007cf1741d7486  vmovaps [rsp], xmm0
00007cf1741d748b  vmovaps [rsp+0x10], xmm1
00007cf1741d7491  vmovaps [rsp+0x20], xmm2
00007cf1741d7497  vmovaps [rsp+0x30], xmm3
00007cf1741d749d  vmovaps [rsp+0x40], xmm4
00007cf1741d74a3  vmovaps [rsp+0x50], xmm5
00007cf1741d74a9  vmovaps [rsp+0x60], xmm6
00007cf1741d74af  vmovaps [rsp+0x70], xmm7
00007cf1741d74b5  vmovaps [rsp+0x80], xmm8
00007cf1741d74be  vmovaps [rsp+0x90], xmm9
00007cf1741d74c7  vmovaps [rsp+0xA0], xmm10
00007cf1741d74d0  vmovaps [rsp+0xB0], xmm11
00007cf1741d74d9  vmovaps [rsp+0xC0], xmm12
00007cf1741d74e2  vmovaps [rsp+0xD0], xmm13
00007cf1741d74eb  vmovaps [rsp+0xE0], xmm15
00007cf1741d74f4  sub rsp, 0x30
00007cf1741d74f8  movaps [rsp], xmm14
00007cf1741d74fd  movaps [rsp+0x10], xmm4
00007cf1741d7502  movaps [rsp+0x20], xmm3
00007cf1741d7507  lea rdi, [rsp]
00007cf1741d750b  mov esi, 0x00
00007cf1741d7510  mov rax, 0x611C8A33A530
00007cf1741d751a  call rax
00007cf1741d751c  movaps xmm14, [rsp]
00007cf1741d7521  add rsp, 0x30
00007cf1741d7525  vmovaps xmm0, [rsp]
00007cf1741d752a  vmovaps xmm1, [rsp+0x10]
00007cf1741d7530  vmovaps xmm2, [rsp+0x20]
00007cf1741d7536  vmovaps xmm3, [rsp+0x30]
00007cf1741d753c  vmovaps xmm4, [rsp+0x40]
00007cf1741d7542  vmovaps xmm5, [rsp+0x50]
00007cf1741d7548  vmovaps xmm6, [rsp+0x60]
00007cf1741d754e  vmovaps xmm7, [rsp+0x70]
00007cf1741d7554  vmovaps xmm8, [rsp+0x80]
00007cf1741d755d  vmovaps xmm9, [rsp+0x90]
00007cf1741d7566  vmovaps xmm10, [rsp+0xA0]
00007cf1741d756f  vmovaps xmm11, [rsp+0xB0]
00007cf1741d7578  vmovaps xmm12, [rsp+0xC0]
00007cf1741d7581  vmovaps xmm13, [rsp+0xD0]
00007cf1741d758a  vmovaps xmm15, [rsp+0xE0]
00007cf1741d7593  add rsp, 0xF0
00007cf1741d759a  pop r11
00007cf1741d759c  pop r10
00007cf1741d759e  pop r9
00007cf1741d75a0  pop r8
00007cf1741d75a2  pop rsi
00007cf1741d75a3  pop rdi
00007cf1741d75a4  pop rdx
00007cf1741d75a5  pop rcx
00007cf1741d75a6  pop rax
00007cf1741d75a7  add rsp, 0x08
00007cf1741d75ab  jmp 0x00007CF1741D5C8F
00007cf1741d75b0  sub rsp, 0x08
00007cf1741d75b4  push rax
00007cf1741d75b5  push rcx
00007cf1741d75b6  push rdx
00007cf1741d75b7  push rdi
00007cf1741d75b8  push rsi
00007cf1741d75b9  push r8
00007cf1741d75bb  push r9
00007cf1741d75bd  push r10
00007cf1741d75bf  push r11
00007cf1741d75c1  sub rsp, 0xF0
00007cf1741d75c8  vmovaps [rsp], xmm0
00007cf1741d75cd  vmovaps [rsp+0x10], xmm1
00007cf1741d75d3  vmovaps [rsp+0x20], xmm2
00007cf1741d75d9  vmovaps [rsp+0x30], xmm3
00007cf1741d75df  vmovaps [rsp+0x40], xmm4
00007cf1741d75e5  vmovaps [rsp+0x50], xmm5
00007cf1741d75eb  vmovaps [rsp+0x60], xmm7
00007cf1741d75f1  vmovaps [rsp+0x70], xmm8
00007cf1741d75f7  vmovaps [rsp+0x80], xmm9
00007cf1741d7600  vmovaps [rsp+0x90], xmm10
00007cf1741d7609  vmovaps [rsp+0xA0], xmm11
00007cf1741d7612  vmovaps [rsp+0xB0], xmm12
00007cf1741d761b  vmovaps [rsp+0xC0], xmm13
00007cf1741d7624  vmovaps [rsp+0xD0], xmm14
00007cf1741d762d  vmovaps [rsp+0xE0], xmm15
00007cf1741d7636  sub rsp, 0x30
00007cf1741d763a  movaps [rsp], xmm6
00007cf1741d763e  movaps [rsp+0x10], xmm9
00007cf1741d7644  movaps [rsp+0x20], xmm7
00007cf1741d7649  lea rdi, [rsp]
00007cf1741d764d  mov esi, 0x00
00007cf1741d7652  mov rax, 0x611C8A33A530
00007cf1741d765c  call rax
00007cf1741d765e  movaps xmm6, [rsp]
00007cf1741d7662  add rsp, 0x30
00007cf1741d7666  vmovaps xmm0, [rsp]
00007cf1741d766b  vmovaps xmm1, [rsp+0x10]
00007cf1741d7671  vmovaps xmm2, [rsp+0x20]
00007cf1741d7677  vmovaps xmm3, [rsp+0x30]
00007cf1741d767d  vmovaps xmm4, [rsp+0x40]
00007cf1741d7683  vmovaps xmm5, [rsp+0x50]
00007cf1741d7689  vmovaps xmm7, [rsp+0x60]
00007cf1741d768f  vmovaps xmm8, [rsp+0x70]
00007cf1741d7695  vmovaps xmm9, [rsp+0x80]
00007cf1741d769e  vmovaps xmm10, [rsp+0x90]
00007cf1741d76a7  vmovaps xmm11, [rsp+0xA0]
00007cf1741d76b0  vmovaps xmm12, [rsp+0xB0]
00007cf1741d76b9  vmovaps xmm13, [rsp+0xC0]
00007cf1741d76c2  vmovaps xmm14, [rsp+0xD0]
00007cf1741d76cb  vmovaps xmm15, [rsp+0xE0]
00007cf1741d76d4  add rsp, 0xF0
00007cf1741d76db  pop r11
00007cf1741d76dd  pop r10
00007cf1741d76df  pop r9
00007cf1741d76e1  pop r8
00007cf1741d76e3  pop rsi
00007cf1741d76e4  pop rdi
00007cf1741d76e5  pop rdx
00007cf1741d76e6  pop rcx
00007cf1741d76e7  pop rax
00007cf1741d76e8  add rsp, 0x08
00007cf1741d76ec  jmp 0x00007CF1741D5CA7
00007cf1741d76f1  sub rsp, 0x08
00007cf1741d76f5  push rax
00007cf1741d76f6  push rcx
00007cf1741d76f7  push rdx
00007cf1741d76f8  push rdi
00007cf1741d76f9  push rsi
00007cf1741d76fa  push r8
00007cf1741d76fc  push r9
00007cf1741d76fe  push r10
00007cf1741d7700  push r11
00007cf1741d7702  sub rsp, 0xF0
00007cf1741d7709  vmovaps [rsp], xmm0
00007cf1741d770e  vmovaps [rsp+0x10], xmm1
00007cf1741d7714  vmovaps [rsp+0x20], xmm2
00007cf1741d771a  vmovaps [rsp+0x30], xmm3
00007cf1741d7720  vmovaps [rsp+0x40], xmm4
00007cf1741d7726  vmovaps [rsp+0x50], xmm5
00007cf1741d772c  vmovaps [rsp+0x60], xmm6
00007cf1741d7732  vmovaps [rsp+0x70], xmm8
00007cf1741d7738  vmovaps [rsp+0x80], xmm9
00007cf1741d7741  vmovaps [rsp+0x90], xmm10
00007cf1741d774a  vmovaps [rsp+0xA0], xmm11
00007cf1741d7753  vmovaps [rsp+0xB0], xmm12
00007cf1741d775c  vmovaps [rsp+0xC0], xmm13
00007cf1741d7765  vmovaps [rsp+0xD0], xmm14
00007cf1741d776e  vmovaps [rsp+0xE0], xmm15
00007cf1741d7777  sub rsp, 0x30
00007cf1741d777b  movaps [rsp], xmm7
00007cf1741d777f  movaps [rsp+0x10], xmm4
00007cf1741d7784  movaps [rsp+0x20], xmm9
00007cf1741d778a  lea rdi, [rsp]
00007cf1741d778e  mov esi, 0x00
00007cf1741d7793  mov rax, 0x611C8A33A530
00007cf1741d779d  call rax
00007cf1741d779f  movaps xmm7, [rsp]
00007cf1741d77a3  add rsp, 0x30
00007cf1741d77a7  vmovaps xmm0, [rsp]
00007cf1741d77ac  vmovaps xmm1, [rsp+0x10]
00007cf1741d77b2  vmovaps xmm2, [rsp+0x20]
00007cf1741d77b8  vmovaps xmm3, [rsp+0x30]
00007cf1741d77be  vmovaps xmm4, [rsp+0x40]
00007cf1741d77c4  vmovaps xmm5, [rsp+0x50]
00007cf1741d77ca  vmovaps xmm6, [rsp+0x60]
00007cf1741d77d0  vmovaps xmm8, [rsp+0x70]
00007cf1741d77d6  vmovaps xmm9, [rsp+0x80]
00007cf1741d77df  vmovaps xmm10, [rsp+0x90]
00007cf1741d77e8  vmovaps xmm11, [rsp+0xA0]
00007cf1741d77f1  vmovaps xmm12, [rsp+0xB0]
00007cf1741d77fa  vmovaps xmm13, [rsp+0xC0]
00007cf1741d7803  vmovaps xmm14, [rsp+0xD0]
00007cf1741d780c  vmovaps xmm15, [rsp+0xE0]
00007cf1741d7815  add rsp, 0xF0
00007cf1741d781c  pop r11
00007cf1741d781e  pop r10
00007cf1741d7820  pop r9
00007cf1741d7822  pop r8
00007cf1741d7824  pop rsi
00007cf1741d7825  pop rdi
00007cf1741d7826  pop rdx
00007cf1741d7827  pop rcx
00007cf1741d7828  pop rax
00007cf1741d7829  add rsp, 0x08
00007cf1741d782d  jmp 0x00007CF1741D5CD4
00007cf1741d7832  sub rsp, 0x08
00007cf1741d7836  push rax
00007cf1741d7837  push rcx
00007cf1741d7838  push rdx
00007cf1741d7839  push rdi
00007cf1741d783a  push rsi
00007cf1741d783b  push r8
00007cf1741d783d  push r9
00007cf1741d783f  push r10
00007cf1741d7841  push r11
00007cf1741d7843  sub rsp, 0xF0
00007cf1741d784a  vmovaps [rsp], xmm0
00007cf1741d784f  vmovaps [rsp+0x10], xmm1
00007cf1741d7855  vmovaps [rsp+0x20], xmm2
00007cf1741d785b  vmovaps [rsp+0x30], xmm3
00007cf1741d7861  vmovaps [rsp+0x40], xmm5
00007cf1741d7867  vmovaps [rsp+0x50], xmm6
00007cf1741d786d  vmovaps [rsp+0x60], xmm7
00007cf1741d7873  vmovaps [rsp+0x70], xmm8
00007cf1741d7879  vmovaps [rsp+0x80], xmm9
00007cf1741d7882  vmovaps [rsp+0x90], xmm10
00007cf1741d788b  vmovaps [rsp+0xA0], xmm11
00007cf1741d7894  vmovaps [rsp+0xB0], xmm12
00007cf1741d789d  vmovaps [rsp+0xC0], xmm13
00007cf1741d78a6  vmovaps [rsp+0xD0], xmm14
00007cf1741d78af  vmovaps [rsp+0xE0], xmm15
00007cf1741d78b8  sub rsp, 0x30
00007cf1741d78bc  movaps [rsp], xmm4
00007cf1741d78c0  movaps [rsp+0x10], xmm15
00007cf1741d78c6  movaps [rsp+0x20], xmm9
00007cf1741d78cc  lea rdi, [rsp]
00007cf1741d78d0  mov esi, 0x00
00007cf1741d78d5  mov rax, 0x611C8A33A530
00007cf1741d78df  call rax
00007cf1741d78e1  movaps xmm4, [rsp]
00007cf1741d78e5  add rsp, 0x30
00007cf1741d78e9  vmovaps xmm0, [rsp]
00007cf1741d78ee  vmovaps xmm1, [rsp+0x10]
00007cf1741d78f4  vmovaps xmm2, [rsp+0x20]
00007cf1741d78fa  vmovaps xmm3, [rsp+0x30]
00007cf1741d7900  vmovaps xmm5, [rsp+0x40]
00007cf1741d7906  vmovaps xmm6, [rsp+0x50]
00007cf1741d790c  vmovaps xmm7, [rsp+0x60]
00007cf1741d7912  vmovaps xmm8, [rsp+0x70]
00007cf1741d7918  vmovaps xmm9, [rsp+0x80]
00007cf1741d7921  vmovaps xmm10, [rsp+0x90]
00007cf1741d792a  vmovaps xmm11, [rsp+0xA0]
00007cf1741d7933  vmovaps xmm12, [rsp+0xB0]
00007cf1741d793c  vmovaps xmm13, [rsp+0xC0]
00007cf1741d7945  vmovaps xmm14, [rsp+0xD0]
00007cf1741d794e  vmovaps xmm15, [rsp+0xE0]
00007cf1741d7957  add rsp, 0xF0
00007cf1741d795e  pop r11
00007cf1741d7960  pop r10
00007cf1741d7962  pop r9
00007cf1741d7964  pop r8
00007cf1741d7966  pop rsi
00007cf1741d7967  pop rdi
00007cf1741d7968  pop rdx
00007cf1741d7969  pop rcx
00007cf1741d796a  pop rax
00007cf1741d796b  add rsp, 0x08
00007cf1741d796f  jmp 0x00007CF1741D5CF9
00007cf1741d7974  call 0x00007CF1740E5820
00007cf1741d7979  jmp 0x00007CF1741D5D06
00007cf1741d797e  sub rsp, 0x08
00007cf1741d7982  push rax
00007cf1741d7983  push rcx
00007cf1741d7984  push rdx
00007cf1741d7985  push rdi
00007cf1741d7986  push rsi
00007cf1741d7987  push r8
00007cf1741d7989  push r9
00007cf1741d798b  push r10
00007cf1741d798d  push r11
00007cf1741d798f  sub rsp, 0xF0
00007cf1741d7996  vmovaps [rsp], xmm0
00007cf1741d799b  vmovaps [rsp+0x10], xmm1
00007cf1741d79a1  vmovaps [rsp+0x20], xmm2
00007cf1741d79a7  vmovaps [rsp+0x30], xmm4
00007cf1741d79ad  vmovaps [rsp+0x40], xmm5
00007cf1741d79b3  vmovaps [rsp+0x50], xmm6
00007cf1741d79b9  vmovaps [rsp+0x60], xmm7
00007cf1741d79bf  vmovaps [rsp+0x70], xmm8
00007cf1741d79c5  vmovaps [rsp+0x80], xmm9
00007cf1741d79ce  vmovaps [rsp+0x90], xmm10
00007cf1741d79d7  vmovaps [rsp+0xA0], xmm11
00007cf1741d79e0  vmovaps [rsp+0xB0], xmm12
00007cf1741d79e9  vmovaps [rsp+0xC0], xmm13
00007cf1741d79f2  vmovaps [rsp+0xD0], xmm14
00007cf1741d79fb  vmovaps [rsp+0xE0], xmm15
00007cf1741d7a04  sub rsp, 0x30
00007cf1741d7a08  movaps [rsp], xmm3
00007cf1741d7a0c  movaps [rsp+0x10], xmm1
00007cf1741d7a11  movaps [rsp+0x20], xmm9
00007cf1741d7a17  lea rdi, [rsp]
00007cf1741d7a1b  mov esi, 0x00
00007cf1741d7a20  mov rax, 0x611C8A33A530
00007cf1741d7a2a  call rax
00007cf1741d7a2c  movaps xmm3, [rsp]
00007cf1741d7a30  add rsp, 0x30
00007cf1741d7a34  vmovaps xmm0, [rsp]
00007cf1741d7a39  vmovaps xmm1, [rsp+0x10]
00007cf1741d7a3f  vmovaps xmm2, [rsp+0x20]
00007cf1741d7a45  vmovaps xmm4, [rsp+0x30]
00007cf1741d7a4b  vmovaps xmm5, [rsp+0x40]
00007cf1741d7a51  vmovaps xmm6, [rsp+0x50]
00007cf1741d7a57  vmovaps xmm7, [rsp+0x60]
00007cf1741d7a5d  vmovaps xmm8, [rsp+0x70]
00007cf1741d7a63  vmovaps xmm9, [rsp+0x80]
00007cf1741d7a6c  vmovaps xmm10, [rsp+0x90]
00007cf1741d7a75  vmovaps xmm11, [rsp+0xA0]
00007cf1741d7a7e  vmovaps xmm12, [rsp+0xB0]
00007cf1741d7a87  vmovaps xmm13, [rsp+0xC0]
00007cf1741d7a90  vmovaps xmm14, [rsp+0xD0]
00007cf1741d7a99  vmovaps xmm15, [rsp+0xE0]
00007cf1741d7aa2  add rsp, 0xF0
00007cf1741d7aa9  pop r11
00007cf1741d7aab  pop r10
00007cf1741d7aad  pop r9
00007cf1741d7aaf  pop r8
00007cf1741d7ab1  pop rsi
00007cf1741d7ab2  pop rdi
00007cf1741d7ab3  pop rdx
00007cf1741d7ab4  pop rcx
00007cf1741d7ab5  pop rax
00007cf1741d7ab6  add rsp, 0x08
00007cf1741d7aba  jmp 0x00007CF1741D5D43
00007cf1741d7abf  sub rsp, 0x08
00007cf1741d7ac3  push rax
00007cf1741d7ac4  push rcx
00007cf1741d7ac5  push rdx
00007cf1741d7ac6  push rdi
00007cf1741d7ac7  push rsi
00007cf1741d7ac8  push r8
00007cf1741d7aca  push r9
00007cf1741d7acc  push r10
00007cf1741d7ace  push r11
00007cf1741d7ad0  sub rsp, 0xF0
00007cf1741d7ad7  vmovaps [rsp], xmm0
00007cf1741d7adc  vmovaps [rsp+0x10], xmm2
00007cf1741d7ae2  vmovaps [rsp+0x20], xmm3
00007cf1741d7ae8  vmovaps [rsp+0x30], xmm4
00007cf1741d7aee  vmovaps [rsp+0x40], xmm5
00007cf1741d7af4  vmovaps [rsp+0x50], xmm6
00007cf1741d7afa  vmovaps [rsp+0x60], xmm7
00007cf1741d7b00  vmovaps [rsp+0x70], xmm8
00007cf1741d7b06  vmovaps [rsp+0x80], xmm9
00007cf1741d7b0f  vmovaps [rsp+0x90], xmm10
00007cf1741d7b18  vmovaps [rsp+0xA0], xmm11
00007cf1741d7b21  vmovaps [rsp+0xB0], xmm12
00007cf1741d7b2a  vmovaps [rsp+0xC0], xmm13
00007cf1741d7b33  vmovaps [rsp+0xD0], xmm14
00007cf1741d7b3c  vmovaps [rsp+0xE0], xmm15
00007cf1741d7b45  sub rsp, 0x30
00007cf1741d7b49  movaps [rsp], xmm1
00007cf1741d7b4d  movaps [rsp+0x10], xmm15
00007cf1741d7b53  movaps [rsp+0x20], xmm9
00007cf1741d7b59  lea rdi, [rsp]
00007cf1741d7b5d  mov esi, 0x00
00007cf1741d7b62  mov rax, 0x611C8A33A530
00007cf1741d7b6c  call rax
00007cf1741d7b6e  movaps xmm1, [rsp]
00007cf1741d7b72  add rsp, 0x30
00007cf1741d7b76  vmovaps xmm0, [rsp]
00007cf1741d7b7b  vmovaps xmm2, [rsp+0x10]
00007cf1741d7b81  vmovaps xmm3, [rsp+0x20]
00007cf1741d7b87  vmovaps xmm4, [rsp+0x30]
00007cf1741d7b8d  vmovaps xmm5, [rsp+0x40]
00007cf1741d7b93  vmovaps xmm6, [rsp+0x50]
00007cf1741d7b99  vmovaps xmm7, [rsp+0x60]
00007cf1741d7b9f  vmovaps xmm8, [rsp+0x70]
00007cf1741d7ba5  vmovaps xmm9, [rsp+0x80]
00007cf1741d7bae  vmovaps xmm10, [rsp+0x90]
00007cf1741d7bb7  vmovaps xmm11, [rsp+0xA0]
00007cf1741d7bc0  vmovaps xmm12, [rsp+0xB0]
00007cf1741d7bc9  vmovaps xmm13, [rsp+0xC0]
00007cf1741d7bd2  vmovaps xmm14, [rsp+0xD0]
00007cf1741d7bdb  vmovaps xmm15, [rsp+0xE0]
00007cf1741d7be4  add rsp, 0xF0
00007cf1741d7beb  pop r11
00007cf1741d7bed  pop r10
00007cf1741d7bef  pop r9
00007cf1741d7bf1  pop r8
00007cf1741d7bf3  pop rsi
00007cf1741d7bf4  pop rdi
00007cf1741d7bf5  pop rdx
00007cf1741d7bf6  pop rcx
00007cf1741d7bf7  pop rax
00007cf1741d7bf8  add rsp, 0x08
00007cf1741d7bfc  jmp 0x00007CF1741D5DCB
00007cf1741d7c01  call 0x00007CF1740E5820
00007cf1741d7c06  jmp 0x00007CF1741D5DD8
00007cf1741d7c0b  sub rsp, 0x08
00007cf1741d7c0f  push rax
00007cf1741d7c10  push rcx
00007cf1741d7c11  push rdx
00007cf1741d7c12  push rdi
00007cf1741d7c13  push rsi
00007cf1741d7c14  push r8
00007cf1741d7c16  push r9
00007cf1741d7c18  push r10
00007cf1741d7c1a  push r11
00007cf1741d7c1c  sub rsp, 0xF0
00007cf1741d7c23  vmovaps [rsp], xmm0
00007cf1741d7c28  vmovaps [rsp+0x10], xmm2
00007cf1741d7c2e  vmovaps [rsp+0x20], xmm3
00007cf1741d7c34  vmovaps [rsp+0x30], xmm4
00007cf1741d7c3a  vmovaps [rsp+0x40], xmm5
00007cf1741d7c40  vmovaps [rsp+0x50], xmm6
00007cf1741d7c46  vmovaps [rsp+0x60], xmm7
00007cf1741d7c4c  vmovaps [rsp+0x70], xmm8
00007cf1741d7c52  vmovaps [rsp+0x80], xmm9
00007cf1741d7c5b  vmovaps [rsp+0x90], xmm10
00007cf1741d7c64  vmovaps [rsp+0xA0], xmm11
00007cf1741d7c6d  vmovaps [rsp+0xB0], xmm12
00007cf1741d7c76  vmovaps [rsp+0xC0], xmm13
00007cf1741d7c7f  vmovaps [rsp+0xD0], xmm14
00007cf1741d7c88  vmovaps [rsp+0xE0], xmm15
00007cf1741d7c91  sub rsp, 0x30
00007cf1741d7c95  movaps [rsp], xmm1
00007cf1741d7c99  movaps [rsp+0x10], xmm5
00007cf1741d7c9e  movaps [rsp+0x20], xmm7
00007cf1741d7ca3  lea rdi, [rsp]
00007cf1741d7ca7  mov esi, 0x00
00007cf1741d7cac  mov rax, 0x611C8A33A530
00007cf1741d7cb6  call rax
00007cf1741d7cb8  movaps xmm1, [rsp]
00007cf1741d7cbc  add rsp, 0x30
00007cf1741d7cc0  vmovaps xmm0, [rsp]
00007cf1741d7cc5  vmovaps xmm2, [rsp+0x10]
00007cf1741d7ccb  vmovaps xmm3, [rsp+0x20]
00007cf1741d7cd1  vmovaps xmm4, [rsp+0x30]
00007cf1741d7cd7  vmovaps xmm5, [rsp+0x40]
00007cf1741d7cdd  vmovaps xmm6, [rsp+0x50]
00007cf1741d7ce3  vmovaps xmm7, [rsp+0x60]
00007cf1741d7ce9  vmovaps xmm8, [rsp+0x70]
00007cf1741d7cef  vmovaps xmm9, [rsp+0x80]
00007cf1741d7cf8  vmovaps xmm10, [rsp+0x90]
00007cf1741d7d01  vmovaps xmm11, [rsp+0xA0]
00007cf1741d7d0a  vmovaps xmm12, [rsp+0xB0]
00007cf1741d7d13  vmovaps xmm13, [rsp+0xC0]
00007cf1741d7d1c  vmovaps xmm14, [rsp+0xD0]
00007cf1741d7d25  vmovaps xmm15, [rsp+0xE0]
00007cf1741d7d2e  add rsp, 0xF0
00007cf1741d7d35  pop r11
00007cf1741d7d37  pop r10
00007cf1741d7d39  pop r9
00007cf1741d7d3b  pop r8
00007cf1741d7d3d  pop rsi
00007cf1741d7d3e  pop rdi
00007cf1741d7d3f  pop rdx
00007cf1741d7d40  pop rcx
00007cf1741d7d41  pop rax
00007cf1741d7d42  add rsp, 0x08
00007cf1741d7d46  jmp 0x00007CF1741D5E7D
00007cf1741d7d4b  sub rsp, 0x08
00007cf1741d7d4f  push rax
00007cf1741d7d50  push rcx
00007cf1741d7d51  push rdx
00007cf1741d7d52  push rdi
00007cf1741d7d53  push rsi
00007cf1741d7d54  push r8
00007cf1741d7d56  push r9
00007cf1741d7d58  push r10
00007cf1741d7d5a  push r11
00007cf1741d7d5c  sub rsp, 0xF0
00007cf1741d7d63  vmovaps [rsp], xmm0
00007cf1741d7d68  vmovaps [rsp+0x10], xmm1
00007cf1741d7d6e  vmovaps [rsp+0x20], xmm2
00007cf1741d7d74  vmovaps [rsp+0x30], xmm3
00007cf1741d7d7a  vmovaps [rsp+0x40], xmm4
00007cf1741d7d80  vmovaps [rsp+0x50], xmm5
00007cf1741d7d86  vmovaps [rsp+0x60], xmm6
00007cf1741d7d8c  vmovaps [rsp+0x70], xmm8
00007cf1741d7d92  vmovaps [rsp+0x80], xmm9
00007cf1741d7d9b  vmovaps [rsp+0x90], xmm10
00007cf1741d7da4  vmovaps [rsp+0xA0], xmm11
00007cf1741d7dad  vmovaps [rsp+0xB0], xmm12
00007cf1741d7db6  vmovaps [rsp+0xC0], xmm13
00007cf1741d7dbf  vmovaps [rsp+0xD0], xmm14
00007cf1741d7dc8  vmovaps [rsp+0xE0], xmm15
00007cf1741d7dd1  sub rsp, 0x30
00007cf1741d7dd5  movaps [rsp], xmm7
00007cf1741d7dd9  movaps [rsp+0x10], xmm5
00007cf1741d7dde  movaps [rsp+0x20], xmm15
00007cf1741d7de4  lea rdi, [rsp]
00007cf1741d7de8  mov esi, 0x00
00007cf1741d7ded  mov rax, 0x611C8A33A530
00007cf1741d7df7  call rax
00007cf1741d7df9  movaps xmm7, [rsp]
00007cf1741d7dfd  add rsp, 0x30
00007cf1741d7e01  vmovaps xmm0, [rsp]
00007cf1741d7e06  vmovaps xmm1, [rsp+0x10]
00007cf1741d7e0c  vmovaps xmm2, [rsp+0x20]
00007cf1741d7e12  vmovaps xmm3, [rsp+0x30]
00007cf1741d7e18  vmovaps xmm4, [rsp+0x40]
00007cf1741d7e1e  vmovaps xmm5, [rsp+0x50]
00007cf1741d7e24  vmovaps xmm6, [rsp+0x60]
00007cf1741d7e2a  vmovaps xmm8, [rsp+0x70]
00007cf1741d7e30  vmovaps xmm9, [rsp+0x80]
00007cf1741d7e39  vmovaps xmm10, [rsp+0x90]
00007cf1741d7e42  vmovaps xmm11, [rsp+0xA0]
00007cf1741d7e4b  vmovaps xmm12, [rsp+0xB0]
00007cf1741d7e54  vmovaps xmm13, [rsp+0xC0]
00007cf1741d7e5d  vmovaps xmm14, [rsp+0xD0]
00007cf1741d7e66  vmovaps xmm15, [rsp+0xE0]
00007cf1741d7e6f  add rsp, 0xF0
00007cf1741d7e76  pop r11
00007cf1741d7e78  pop r10
00007cf1741d7e7a  pop r9
00007cf1741d7e7c  pop r8
00007cf1741d7e7e  pop rsi
00007cf1741d7e7f  pop rdi
00007cf1741d7e80  pop rdx
00007cf1741d7e81  pop rcx
00007cf1741d7e82  pop rax
00007cf1741d7e83  add rsp, 0x08
00007cf1741d7e87  jmp 0x00007CF1741D5EB3
00007cf1741d7e8c  call 0x00007CF1740D64F0
00007cf1741d7e91  jmp 0x00007CF1741D5EC0
00007cf1741d7e96  sub rsp, 0x08
00007cf1741d7e9a  push rax
00007cf1741d7e9b  push rcx
00007cf1741d7e9c  push rdx
00007cf1741d7e9d  push rdi
00007cf1741d7e9e  push rsi
00007cf1741d7e9f  push r8
00007cf1741d7ea1  push r9
00007cf1741d7ea3  push r10
00007cf1741d7ea5  push r11
00007cf1741d7ea7  sub rsp, 0xF0
00007cf1741d7eae  vmovaps [rsp], xmm0
00007cf1741d7eb3  vmovaps [rsp+0x10], xmm1
00007cf1741d7eb9  vmovaps [rsp+0x20], xmm2
00007cf1741d7ebf  vmovaps [rsp+0x30], xmm3
00007cf1741d7ec5  vmovaps [rsp+0x40], xmm4
00007cf1741d7ecb  vmovaps [rsp+0x50], xmm5
00007cf1741d7ed1  vmovaps [rsp+0x60], xmm6
00007cf1741d7ed7  vmovaps [rsp+0x70], xmm7
00007cf1741d7edd  vmovaps [rsp+0x80], xmm8
00007cf1741d7ee6  vmovaps [rsp+0x90], xmm9
00007cf1741d7eef  vmovaps [rsp+0xA0], xmm10
00007cf1741d7ef8  vmovaps [rsp+0xB0], xmm11
00007cf1741d7f01  vmovaps [rsp+0xC0], xmm12
00007cf1741d7f0a  vmovaps [rsp+0xD0], xmm13
00007cf1741d7f13  vmovaps [rsp+0xE0], xmm14
00007cf1741d7f1c  sub rsp, 0x30
00007cf1741d7f20  movaps [rsp], xmm15
00007cf1741d7f25  movaps [rsp+0x10], xmm5
00007cf1741d7f2a  movaps [rsp+0x20], xmm3
00007cf1741d7f2f  lea rdi, [rsp]
00007cf1741d7f33  mov esi, 0x00
00007cf1741d7f38  mov rax, 0x611C8A33A530
00007cf1741d7f42  call rax
00007cf1741d7f44  movaps xmm15, [rsp]
00007cf1741d7f49  add rsp, 0x30
00007cf1741d7f4d  vmovaps xmm0, [rsp]
00007cf1741d7f52  vmovaps xmm1, [rsp+0x10]
00007cf1741d7f58  vmovaps xmm2, [rsp+0x20]
00007cf1741d7f5e  vmovaps xmm3, [rsp+0x30]
00007cf1741d7f64  vmovaps xmm4, [rsp+0x40]
00007cf1741d7f6a  vmovaps xmm5, [rsp+0x50]
00007cf1741d7f70  vmovaps xmm6, [rsp+0x60]
00007cf1741d7f76  vmovaps xmm7, [rsp+0x70]
00007cf1741d7f7c  vmovaps xmm8, [rsp+0x80]
00007cf1741d7f85  vmovaps xmm9, [rsp+0x90]
00007cf1741d7f8e  vmovaps xmm10, [rsp+0xA0]
00007cf1741d7f97  vmovaps xmm11, [rsp+0xB0]
00007cf1741d7fa0  vmovaps xmm12, [rsp+0xC0]
00007cf1741d7fa9  vmovaps xmm13, [rsp+0xD0]
00007cf1741d7fb2  vmovaps xmm14, [rsp+0xE0]
00007cf1741d7fbb  add rsp, 0xF0
00007cf1741d7fc2  pop r11
00007cf1741d7fc4  pop r10
00007cf1741d7fc6  pop r9
00007cf1741d7fc8  pop r8
00007cf1741d7fca  pop rsi
00007cf1741d7fcb  pop rdi
00007cf1741d7fcc  pop rdx
00007cf1741d7fcd  pop rcx
00007cf1741d7fce  pop rax
00007cf1741d7fcf  add rsp, 0x08
00007cf1741d7fd3  jmp 0x00007CF1741D5EE6
00007cf1741d7fd8  sub rsp, 0x08
00007cf1741d7fdc  push rax
00007cf1741d7fdd  push rcx
00007cf1741d7fde  push rdx
00007cf1741d7fdf  push rdi
00007cf1741d7fe0  push rsi
00007cf1741d7fe1  push r8
00007cf1741d7fe3  push r9
00007cf1741d7fe5  push r10
00007cf1741d7fe7  push r11
00007cf1741d7fe9  sub rsp, 0xF0
00007cf1741d7ff0  vmovaps [rsp], xmm0
00007cf1741d7ff5  vmovaps [rsp+0x10], xmm2
00007cf1741d7ffb  vmovaps [rsp+0x20], xmm3
00007cf1741d8001  vmovaps [rsp+0x30], xmm4
00007cf1741d8007  vmovaps [rsp+0x40], xmm5
00007cf1741d800d  vmovaps [rsp+0x50], xmm6
00007cf1741d8013  vmovaps [rsp+0x60], xmm7
00007cf1741d8019  vmovaps [rsp+0x70], xmm8
00007cf1741d801f  vmovaps [rsp+0x80], xmm9
00007cf1741d8028  vmovaps [rsp+0x90], xmm10
00007cf1741d8031  vmovaps [rsp+0xA0], xmm11
00007cf1741d803a  vmovaps [rsp+0xB0], xmm12
00007cf1741d8043  vmovaps [rsp+0xC0], xmm13
00007cf1741d804c  vmovaps [rsp+0xD0], xmm14
00007cf1741d8055  vmovaps [rsp+0xE0], xmm15
00007cf1741d805e  sub rsp, 0x30
00007cf1741d8062  movaps [rsp], xmm1
00007cf1741d8066  movaps [rsp+0x10], xmm5
00007cf1741d806b  movaps [rsp+0x20], xmm4
00007cf1741d8070  lea rdi, [rsp]
00007cf1741d8074  mov esi, 0x00
00007cf1741d8079  mov rax, 0x611C8A33A530
00007cf1741d8083  call rax
00007cf1741d8085  movaps xmm1, [rsp]
00007cf1741d8089  add rsp, 0x30
00007cf1741d808d  vmovaps xmm0, [rsp]
00007cf1741d8092  vmovaps xmm2, [rsp+0x10]
00007cf1741d8098  vmovaps xmm3, [rsp+0x20]
00007cf1741d809e  vmovaps xmm4, [rsp+0x30]
00007cf1741d80a4  vmovaps xmm5, [rsp+0x40]
00007cf1741d80aa  vmovaps xmm6, [rsp+0x50]
00007cf1741d80b0  vmovaps xmm7, [rsp+0x60]
00007cf1741d80b6  vmovaps xmm8, [rsp+0x70]
00007cf1741d80bc  vmovaps xmm9, [rsp+0x80]
00007cf1741d80c5  vmovaps xmm10, [rsp+0x90]
00007cf1741d80ce  vmovaps xmm11, [rsp+0xA0]
00007cf1741d80d7  vmovaps xmm12, [rsp+0xB0]
00007cf1741d80e0  vmovaps xmm13, [rsp+0xC0]
00007cf1741d80e9  vmovaps xmm14, [rsp+0xD0]
00007cf1741d80f2  vmovaps xmm15, [rsp+0xE0]
00007cf1741d80fb  add rsp, 0xF0
00007cf1741d8102  pop r11
00007cf1741d8104  pop r10
00007cf1741d8106  pop r9
00007cf1741d8108  pop r8
00007cf1741d810a  pop rsi
00007cf1741d810b  pop rdi
00007cf1741d810c  pop rdx
00007cf1741d810d  pop rcx
00007cf1741d810e  pop rax
00007cf1741d810f  add rsp, 0x08
00007cf1741d8113  jmp 0x00007CF1741D5F06
00007cf1741d8118  sub rsp, 0x08
00007cf1741d811c  push rax
00007cf1741d811d  push rcx
00007cf1741d811e  push rdx
00007cf1741d811f  push rdi
00007cf1741d8120  push rsi
00007cf1741d8121  push r8
00007cf1741d8123  push r9
00007cf1741d8125  push r10
00007cf1741d8127  push r11
00007cf1741d8129  sub rsp, 0xF0
00007cf1741d8130  vmovaps [rsp], xmm0
00007cf1741d8135  vmovaps [rsp+0x10], xmm1
00007cf1741d813b  vmovaps [rsp+0x20], xmm2
00007cf1741d8141  vmovaps [rsp+0x30], xmm3
00007cf1741d8147  vmovaps [rsp+0x40], xmm5
00007cf1741d814d  vmovaps [rsp+0x50], xmm6
00007cf1741d8153  vmovaps [rsp+0x60], xmm7
00007cf1741d8159  vmovaps [rsp+0x70], xmm8
00007cf1741d815f  vmovaps [rsp+0x80], xmm9
00007cf1741d8168  vmovaps [rsp+0x90], xmm10
00007cf1741d8171  vmovaps [rsp+0xA0], xmm11
00007cf1741d817a  vmovaps [rsp+0xB0], xmm12
00007cf1741d8183  vmovaps [rsp+0xC0], xmm13
00007cf1741d818c  vmovaps [rsp+0xD0], xmm14
00007cf1741d8195  vmovaps [rsp+0xE0], xmm15
00007cf1741d819e  sub rsp, 0x30
00007cf1741d81a2  movaps [rsp], xmm4
00007cf1741d81a6  movaps [rsp+0x10], xmm3
00007cf1741d81ab  movaps [rsp+0x20], xmm5
00007cf1741d81b0  lea rdi, [rsp]
00007cf1741d81b4  mov esi, 0x00
00007cf1741d81b9  mov rax, 0x611C8A33A530
00007cf1741d81c3  call rax
00007cf1741d81c5  movaps xmm4, [rsp]
00007cf1741d81c9  add rsp, 0x30
00007cf1741d81cd  vmovaps xmm0, [rsp]
00007cf1741d81d2  vmovaps xmm1, [rsp+0x10]
00007cf1741d81d8  vmovaps xmm2, [rsp+0x20]
00007cf1741d81de  vmovaps xmm3, [rsp+0x30]
00007cf1741d81e4  vmovaps xmm5, [rsp+0x40]
00007cf1741d81ea  vmovaps xmm6, [rsp+0x50]
00007cf1741d81f0  vmovaps xmm7, [rsp+0x60]
00007cf1741d81f6  vmovaps xmm8, [rsp+0x70]
00007cf1741d81fc  vmovaps xmm9, [rsp+0x80]
00007cf1741d8205  vmovaps xmm10, [rsp+0x90]
00007cf1741d820e  vmovaps xmm11, [rsp+0xA0]
00007cf1741d8217  vmovaps xmm12, [rsp+0xB0]
00007cf1741d8220  vmovaps xmm13, [rsp+0xC0]
00007cf1741d8229  vmovaps xmm14, [rsp+0xD0]
00007cf1741d8232  vmovaps xmm15, [rsp+0xE0]
00007cf1741d823b  add rsp, 0xF0
00007cf1741d8242  pop r11
00007cf1741d8244  pop r10
00007cf1741d8246  pop r9
00007cf1741d8248  pop r8
00007cf1741d824a  pop rsi
00007cf1741d824b  pop rdi
00007cf1741d824c  pop rdx
00007cf1741d824d  pop rcx
00007cf1741d824e  pop rax
00007cf1741d824f  add rsp, 0x08
00007cf1741d8253  jmp 0x00007CF1741D5F54
00007cf1741d8258  call 0x00007CF1740D64F0
00007cf1741d825d  jmp 0x00007CF1741D5F61
00007cf1741d8262  sub rsp, 0x08
00007cf1741d8266  push rax
00007cf1741d8267  push rcx
00007cf1741d8268  push rdx
00007cf1741d8269  push rdi
00007cf1741d826a  push rsi
00007cf1741d826b  push r8
00007cf1741d826d  push r9
00007cf1741d826f  push r10
00007cf1741d8271  push r11
00007cf1741d8273  sub rsp, 0xF0
00007cf1741d827a  vmovaps [rsp], xmm0
00007cf1741d827f  vmovaps [rsp+0x10], xmm1
00007cf1741d8285  vmovaps [rsp+0x20], xmm2
00007cf1741d828b  vmovaps [rsp+0x30], xmm3
00007cf1741d8291  vmovaps [rsp+0x40], xmm4
00007cf1741d8297  vmovaps [rsp+0x50], xmm6
00007cf1741d829d  vmovaps [rsp+0x60], xmm7
00007cf1741d82a3  vmovaps [rsp+0x70], xmm8
00007cf1741d82a9  vmovaps [rsp+0x80], xmm9
00007cf1741d82b2  vmovaps [rsp+0x90], xmm10
00007cf1741d82bb  vmovaps [rsp+0xA0], xmm11
00007cf1741d82c4  vmovaps [rsp+0xB0], xmm12
00007cf1741d82cd  vmovaps [rsp+0xC0], xmm13
00007cf1741d82d6  vmovaps [rsp+0xD0], xmm14
00007cf1741d82df  vmovaps [rsp+0xE0], xmm15
00007cf1741d82e8  sub rsp, 0x30
00007cf1741d82ec  movaps [rsp], xmm5
00007cf1741d82f0  movaps [rsp+0x10], xmm6
00007cf1741d82f5  movaps [rsp+0x20], xmm3
00007cf1741d82fa  lea rdi, [rsp]
00007cf1741d82fe  mov esi, 0x00
00007cf1741d8303  mov rax, 0x611C8A33A530
00007cf1741d830d  call rax
00007cf1741d830f  movaps xmm5, [rsp]
00007cf1741d8313  add rsp, 0x30
00007cf1741d8317  vmovaps xmm0, [rsp]
00007cf1741d831c  vmovaps xmm1, [rsp+0x10]
00007cf1741d8322  vmovaps xmm2, [rsp+0x20]
00007cf1741d8328  vmovaps xmm3, [rsp+0x30]
00007cf1741d832e  vmovaps xmm4, [rsp+0x40]
00007cf1741d8334  vmovaps xmm6, [rsp+0x50]
00007cf1741d833a  vmovaps xmm7, [rsp+0x60]
00007cf1741d8340  vmovaps xmm8, [rsp+0x70]
00007cf1741d8346  vmovaps xmm9, [rsp+0x80]
00007cf1741d834f  vmovaps xmm10, [rsp+0x90]
00007cf1741d8358  vmovaps xmm11, [rsp+0xA0]
00007cf1741d8361  vmovaps xmm12, [rsp+0xB0]
00007cf1741d836a  vmovaps xmm13, [rsp+0xC0]
00007cf1741d8373  vmovaps xmm14, [rsp+0xD0]
00007cf1741d837c  vmovaps xmm15, [rsp+0xE0]
00007cf1741d8385  add rsp, 0xF0
00007cf1741d838c  pop r11
00007cf1741d838e  pop r10
00007cf1741d8390  pop r9
00007cf1741d8392  pop r8
00007cf1741d8394  pop rsi
00007cf1741d8395  pop rdi
00007cf1741d8396  pop rdx
00007cf1741d8397  pop rcx
00007cf1741d8398  pop rax
00007cf1741d8399  add rsp, 0x08
00007cf1741d839d  jmp 0x00007CF1741D5F87
00007cf1741d83a2  sub rsp, 0x08
00007cf1741d83a6  push rax
00007cf1741d83a7  push rcx
00007cf1741d83a8  push rdx
00007cf1741d83a9  push rdi
00007cf1741d83aa  push rsi
00007cf1741d83ab  push r8
00007cf1741d83ad  push r9
00007cf1741d83af  push r10
00007cf1741d83b1  push r11
00007cf1741d83b3  sub rsp, 0xF0
00007cf1741d83ba  vmovaps [rsp], xmm0
00007cf1741d83bf  vmovaps [rsp+0x10], xmm1
00007cf1741d83c5  vmovaps [rsp+0x20], xmm2
00007cf1741d83cb  vmovaps [rsp+0x30], xmm3
00007cf1741d83d1  vmovaps [rsp+0x40], xmm4
00007cf1741d83d7  vmovaps [rsp+0x50], xmm5
00007cf1741d83dd  vmovaps [rsp+0x60], xmm7
00007cf1741d83e3  vmovaps [rsp+0x70], xmm8
00007cf1741d83e9  vmovaps [rsp+0x80], xmm9
00007cf1741d83f2  vmovaps [rsp+0x90], xmm10
00007cf1741d83fb  vmovaps [rsp+0xA0], xmm11
00007cf1741d8404  vmovaps [rsp+0xB0], xmm12
00007cf1741d840d  vmovaps [rsp+0xC0], xmm13
00007cf1741d8416  vmovaps [rsp+0xD0], xmm14
00007cf1741d841f  vmovaps [rsp+0xE0], xmm15
00007cf1741d8428  sub rsp, 0x30
00007cf1741d842c  movaps [rsp], xmm6
00007cf1741d8430  movaps [rsp+0x10], xmm9
00007cf1741d8436  movaps [rsp+0x20], xmm1
00007cf1741d843b  lea rdi, [rsp]
00007cf1741d843f  mov esi, 0x00
00007cf1741d8444  mov rax, 0x611C8A33A530
00007cf1741d844e  call rax
00007cf1741d8450  movaps xmm6, [rsp]
00007cf1741d8454  add rsp, 0x30
00007cf1741d8458  vmovaps xmm0, [rsp]
00007cf1741d845d  vmovaps xmm1, [rsp+0x10]
00007cf1741d8463  vmovaps xmm2, [rsp+0x20]
00007cf1741d8469  vmovaps xmm3, [rsp+0x30]
00007cf1741d846f  vmovaps xmm4, [rsp+0x40]
00007cf1741d8475  vmovaps xmm5, [rsp+0x50]
00007cf1741d847b  vmovaps xmm7, [rsp+0x60]
00007cf1741d8481  vmovaps xmm8, [rsp+0x70]
00007cf1741d8487  vmovaps xmm9, [rsp+0x80]
00007cf1741d8490  vmovaps xmm10, [rsp+0x90]
00007cf1741d8499  vmovaps xmm11, [rsp+0xA0]
00007cf1741d84a2  vmovaps xmm12, [rsp+0xB0]
00007cf1741d84ab  vmovaps xmm13, [rsp+0xC0]
00007cf1741d84b4  vmovaps xmm14, [rsp+0xD0]
00007cf1741d84bd  vmovaps xmm15, [rsp+0xE0]
00007cf1741d84c6  add rsp, 0xF0
00007cf1741d84cd  pop r11
00007cf1741d84cf  pop r10
00007cf1741d84d1  pop r9
00007cf1741d84d3  pop r8
00007cf1741d84d5  pop rsi
00007cf1741d84d6  pop rdi
00007cf1741d84d7  pop rdx
00007cf1741d84d8  pop rcx
00007cf1741d84d9  pop rax
00007cf1741d84da  add rsp, 0x08
00007cf1741d84de  jmp 0x00007CF1741D5FAB
00007cf1741d84e3  sub rsp, 0x08
00007cf1741d84e7  push rax
00007cf1741d84e8  push rcx
00007cf1741d84e9  push rdx
00007cf1741d84ea  push rdi
00007cf1741d84eb  push rsi
00007cf1741d84ec  push r8
00007cf1741d84ee  push r9
00007cf1741d84f0  push r10
00007cf1741d84f2  push r11
00007cf1741d84f4  sub rsp, 0xF0
00007cf1741d84fb  vmovaps [rsp], xmm0
00007cf1741d8500  vmovaps [rsp+0x10], xmm1
00007cf1741d8506  vmovaps [rsp+0x20], xmm2
00007cf1741d850c  vmovaps [rsp+0x30], xmm3
00007cf1741d8512  vmovaps [rsp+0x40], xmm4
00007cf1741d8518  vmovaps [rsp+0x50], xmm5
00007cf1741d851e  vmovaps [rsp+0x60], xmm6
00007cf1741d8524  vmovaps [rsp+0x70], xmm7
00007cf1741d852a  vmovaps [rsp+0x80], xmm8
00007cf1741d8533  vmovaps [rsp+0x90], xmm10
00007cf1741d853c  vmovaps [rsp+0xA0], xmm11
00007cf1741d8545  vmovaps [rsp+0xB0], xmm12
00007cf1741d854e  vmovaps [rsp+0xC0], xmm13
00007cf1741d8557  vmovaps [rsp+0xD0], xmm14
00007cf1741d8560  vmovaps [rsp+0xE0], xmm15
00007cf1741d8569  sub rsp, 0x30
00007cf1741d856d  movaps [rsp], xmm9
00007cf1741d8572  movaps [rsp+0x10], xmm3
00007cf1741d8577  movaps [rsp+0x20], xmm1
00007cf1741d857c  lea rdi, [rsp]
00007cf1741d8580  mov esi, 0x00
00007cf1741d8585  mov rax, 0x611C8A33A530
00007cf1741d858f  call rax
00007cf1741d8591  movaps xmm9, [rsp]
00007cf1741d8596  add rsp, 0x30
00007cf1741d859a  vmovaps xmm0, [rsp]
00007cf1741d859f  vmovaps xmm1, [rsp+0x10]
00007cf1741d85a5  vmovaps xmm2, [rsp+0x20]
00007cf1741d85ab  vmovaps xmm3, [rsp+0x30]
00007cf1741d85b1  vmovaps xmm4, [rsp+0x40]
00007cf1741d85b7  vmovaps xmm5, [rsp+0x50]
00007cf1741d85bd  vmovaps xmm6, [rsp+0x60]
00007cf1741d85c3  vmovaps xmm7, [rsp+0x70]
00007cf1741d85c9  vmovaps xmm8, [rsp+0x80]
00007cf1741d85d2  vmovaps xmm10, [rsp+0x90]
00007cf1741d85db  vmovaps xmm11, [rsp+0xA0]
00007cf1741d85e4  vmovaps xmm12, [rsp+0xB0]
00007cf1741d85ed  vmovaps xmm13, [rsp+0xC0]
00007cf1741d85f6  vmovaps xmm14, [rsp+0xD0]
00007cf1741d85ff  vmovaps xmm15, [rsp+0xE0]
00007cf1741d8608  add rsp, 0xF0
00007cf1741d860f  pop r11
00007cf1741d8611  pop r10
00007cf1741d8613  pop r9
00007cf1741d8615  pop r8
00007cf1741d8617  pop rsi
00007cf1741d8618  pop rdi
00007cf1741d8619  pop rdx
00007cf1741d861a  pop rcx
00007cf1741d861b  pop rax
00007cf1741d861c  add rsp, 0x08
00007cf1741d8620  jmp 0x00007CF1741D5FF7
00007cf1741d8625  call 0x00007CF1740D64F0
00007cf1741d862a  jmp 0x00007CF1741D6004
00007cf1741d862f  sub rsp, 0x08
00007cf1741d8633  push rax
00007cf1741d8634  push rcx
00007cf1741d8635  push rdx
00007cf1741d8636  push rdi
00007cf1741d8637  push rsi
00007cf1741d8638  push r8
00007cf1741d863a  push r9
00007cf1741d863c  push r10
00007cf1741d863e  push r11
00007cf1741d8640  sub rsp, 0xF0
00007cf1741d8647  vmovaps [rsp], xmm0
00007cf1741d864c  vmovaps [rsp+0x10], xmm1
00007cf1741d8652  vmovaps [rsp+0x20], xmm2
00007cf1741d8658  vmovaps [rsp+0x30], xmm3
00007cf1741d865e  vmovaps [rsp+0x40], xmm4
00007cf1741d8664  vmovaps [rsp+0x50], xmm5
00007cf1741d866a  vmovaps [rsp+0x60], xmm6
00007cf1741d8670  vmovaps [rsp+0x70], xmm7
00007cf1741d8676  vmovaps [rsp+0x80], xmm8
00007cf1741d867f  vmovaps [rsp+0x90], xmm9
00007cf1741d8688  vmovaps [rsp+0xA0], xmm10
00007cf1741d8691  vmovaps [rsp+0xB0], xmm11
00007cf1741d869a  vmovaps [rsp+0xC0], xmm12
00007cf1741d86a3  vmovaps [rsp+0xD0], xmm13
00007cf1741d86ac  vmovaps [rsp+0xE0], xmm14
00007cf1741d86b5  sub rsp, 0x30
00007cf1741d86b9  movaps [rsp], xmm15
00007cf1741d86be  movaps [rsp+0x10], xmm3
00007cf1741d86c3  movaps [rsp+0x20], xmm7
00007cf1741d86c8  lea rdi, [rsp]
00007cf1741d86cc  mov esi, 0x00
00007cf1741d86d1  mov rax, 0x611C8A33A530
00007cf1741d86db  call rax
00007cf1741d86dd  movaps xmm15, [rsp]
00007cf1741d86e2  add rsp, 0x30
00007cf1741d86e6  vmovaps xmm0, [rsp]
00007cf1741d86eb  vmovaps xmm1, [rsp+0x10]
00007cf1741d86f1  vmovaps xmm2, [rsp+0x20]
00007cf1741d86f7  vmovaps xmm3, [rsp+0x30]
00007cf1741d86fd  vmovaps xmm4, [rsp+0x40]
00007cf1741d8703  vmovaps xmm5, [rsp+0x50]
00007cf1741d8709  vmovaps xmm6, [rsp+0x60]
00007cf1741d870f  vmovaps xmm7, [rsp+0x70]
00007cf1741d8715  vmovaps xmm8, [rsp+0x80]
00007cf1741d871e  vmovaps xmm9, [rsp+0x90]
00007cf1741d8727  vmovaps xmm10, [rsp+0xA0]
00007cf1741d8730  vmovaps xmm11, [rsp+0xB0]
00007cf1741d8739  vmovaps xmm12, [rsp+0xC0]
00007cf1741d8742  vmovaps xmm13, [rsp+0xD0]
00007cf1741d874b  vmovaps xmm14, [rsp+0xE0]
00007cf1741d8754  add rsp, 0xF0
00007cf1741d875b  pop r11
00007cf1741d875d  pop r10
00007cf1741d875f  pop r9
00007cf1741d8761  pop r8
00007cf1741d8763  pop rsi
00007cf1741d8764  pop rdi
00007cf1741d8765  pop rdx
00007cf1741d8766  pop rcx
00007cf1741d8767  pop rax
00007cf1741d8768  add rsp, 0x08
00007cf1741d876c  jmp 0x00007CF1741D6030
00007cf1741d8771  sub rsp, 0x08
00007cf1741d8775  push rax
00007cf1741d8776  push rcx
00007cf1741d8777  push rdx
00007cf1741d8778  push rdi
00007cf1741d8779  push rsi
00007cf1741d877a  push r8
00007cf1741d877c  push r9
00007cf1741d877e  push r10
00007cf1741d8780  push r11
00007cf1741d8782  sub rsp, 0xF0
00007cf1741d8789  vmovaps [rsp], xmm0
00007cf1741d878e  vmovaps [rsp+0x10], xmm1
00007cf1741d8794  vmovaps [rsp+0x20], xmm2
00007cf1741d879a  vmovaps [rsp+0x30], xmm4
00007cf1741d87a0  vmovaps [rsp+0x40], xmm5
00007cf1741d87a6  vmovaps [rsp+0x50], xmm6
00007cf1741d87ac  vmovaps [rsp+0x60], xmm7
00007cf1741d87b2  vmovaps [rsp+0x70], xmm8
00007cf1741d87b8  vmovaps [rsp+0x80], xmm9
00007cf1741d87c1  vmovaps [rsp+0x90], xmm10
00007cf1741d87ca  vmovaps [rsp+0xA0], xmm11
00007cf1741d87d3  vmovaps [rsp+0xB0], xmm12
00007cf1741d87dc  vmovaps [rsp+0xC0], xmm13
00007cf1741d87e5  vmovaps [rsp+0xD0], xmm14
00007cf1741d87ee  vmovaps [rsp+0xE0], xmm15
00007cf1741d87f7  sub rsp, 0x30
00007cf1741d87fb  movaps [rsp], xmm3
00007cf1741d87ff  movaps [rsp+0x10], xmm1
00007cf1741d8804  movaps [rsp+0x20], xmm15
00007cf1741d880a  lea rdi, [rsp]
00007cf1741d880e  mov esi, 0x00
00007cf1741d8813  mov rax, 0x611C8A33A530
00007cf1741d881d  call rax
00007cf1741d881f  movaps xmm3, [rsp]
00007cf1741d8823  add rsp, 0x30
00007cf1741d8827  vmovaps xmm0, [rsp]
00007cf1741d882c  vmovaps xmm1, [rsp+0x10]
00007cf1741d8832  vmovaps xmm2, [rsp+0x20]
00007cf1741d8838  vmovaps xmm4, [rsp+0x30]
00007cf1741d883e  vmovaps xmm5, [rsp+0x40]
00007cf1741d8844  vmovaps xmm6, [rsp+0x50]
00007cf1741d884a  vmovaps xmm7, [rsp+0x60]
00007cf1741d8850  vmovaps xmm8, [rsp+0x70]
00007cf1741d8856  vmovaps xmm9, [rsp+0x80]
00007cf1741d885f  vmovaps xmm10, [rsp+0x90]
00007cf1741d8868  vmovaps xmm11, [rsp+0xA0]
00007cf1741d8871  vmovaps xmm12, [rsp+0xB0]
00007cf1741d887a  vmovaps xmm13, [rsp+0xC0]
00007cf1741d8883  vmovaps xmm14, [rsp+0xD0]
00007cf1741d888c  vmovaps xmm15, [rsp+0xE0]
00007cf1741d8895  add rsp, 0xF0
00007cf1741d889c  pop r11
00007cf1741d889e  pop r10
00007cf1741d88a0  pop r9
00007cf1741d88a2  pop r8
00007cf1741d88a4  pop rsi
00007cf1741d88a5  pop rdi
00007cf1741d88a6  pop rdx
00007cf1741d88a7  pop rcx
00007cf1741d88a8  pop rax
00007cf1741d88a9  add rsp, 0x08
00007cf1741d88ad  jmp 0x00007CF1741D60BF
00007cf1741d88b2  call 0x00007CF1740D64F0
00007cf1741d88b7  jmp 0x00007CF1741D60C9
00007cf1741d88bc  sub rsp, 0x08
00007cf1741d88c0  push rax
00007cf1741d88c1  push rcx
00007cf1741d88c2  push rdx
00007cf1741d88c3  push rdi
00007cf1741d88c4  push rsi
00007cf1741d88c5  push r8
00007cf1741d88c7  push r9
00007cf1741d88c9  push r10
00007cf1741d88cb  push r11
00007cf1741d88cd  sub rsp, 0xF0
00007cf1741d88d4  vmovaps [rsp], xmm0
00007cf1741d88d9  vmovaps [rsp+0x10], xmm1
00007cf1741d88df  vmovaps [rsp+0x20], xmm2
00007cf1741d88e5  vmovaps [rsp+0x30], xmm3
00007cf1741d88eb  vmovaps [rsp+0x40], xmm4
00007cf1741d88f1  vmovaps [rsp+0x50], xmm5
00007cf1741d88f7  vmovaps [rsp+0x60], xmm6
00007cf1741d88fd  vmovaps [rsp+0x70], xmm7
00007cf1741d8903  vmovaps [rsp+0x80], xmm8
00007cf1741d890c  vmovaps [rsp+0x90], xmm9
00007cf1741d8915  vmovaps [rsp+0xA0], xmm10
00007cf1741d891e  vmovaps [rsp+0xB0], xmm11
00007cf1741d8927  vmovaps [rsp+0xC0], xmm12
00007cf1741d8930  vmovaps [rsp+0xD0], xmm13
00007cf1741d8939  vmovaps [rsp+0xE0], xmm14
00007cf1741d8942  sub rsp, 0x30
00007cf1741d8946  movaps [rsp], xmm15
00007cf1741d894b  movaps [rsp+0x10], xmm14
00007cf1741d8951  movaps [rsp+0x20], xmm4
00007cf1741d8956  lea rdi, [rsp]
00007cf1741d895a  mov esi, 0x00
00007cf1741d895f  mov rax, 0x611C8A33A530
00007cf1741d8969  call rax
00007cf1741d896b  movaps xmm15, [rsp]
00007cf1741d8970  add rsp, 0x30
00007cf1741d8974  vmovaps xmm0, [rsp]
00007cf1741d8979  vmovaps xmm1, [rsp+0x10]
00007cf1741d897f  vmovaps xmm2, [rsp+0x20]
00007cf1741d8985  vmovaps xmm3, [rsp+0x30]
00007cf1741d898b  vmovaps xmm4, [rsp+0x40]
00007cf1741d8991  vmovaps xmm5, [rsp+0x50]
00007cf1741d8997  vmovaps xmm6, [rsp+0x60]
00007cf1741d899d  vmovaps xmm7, [rsp+0x70]
00007cf1741d89a3  vmovaps xmm8, [rsp+0x80]
00007cf1741d89ac  vmovaps xmm9, [rsp+0x90]
00007cf1741d89b5  vmovaps xmm10, [rsp+0xA0]
00007cf1741d89be  vmovaps xmm11, [rsp+0xB0]
00007cf1741d89c7  vmovaps xmm12, [rsp+0xC0]
00007cf1741d89d0  vmovaps xmm13, [rsp+0xD0]
00007cf1741d89d9  vmovaps xmm14, [rsp+0xE0]
00007cf1741d89e2  add rsp, 0xF0
00007cf1741d89e9  pop r11
00007cf1741d89eb  pop r10
00007cf1741d89ed  pop r9
00007cf1741d89ef  pop r8
00007cf1741d89f1  pop rsi
00007cf1741d89f2  pop rdi
00007cf1741d89f3  pop rdx
00007cf1741d89f4  pop rcx
00007cf1741d89f5  pop rax
00007cf1741d89f6  add rsp, 0x08
00007cf1741d89fa  jmp 0x00007CF1741D60F7
00007cf1741d89ff  sub rsp, 0x08
00007cf1741d8a03  push rax
00007cf1741d8a04  push rcx
00007cf1741d8a05  push rdx
00007cf1741d8a06  push rdi
00007cf1741d8a07  push rsi
00007cf1741d8a08  push r8
00007cf1741d8a0a  push r9
00007cf1741d8a0c  push r10
00007cf1741d8a0e  push r11
00007cf1741d8a10  sub rsp, 0xF0
00007cf1741d8a17  vmovaps [rsp], xmm0
00007cf1741d8a1c  vmovaps [rsp+0x10], xmm1
00007cf1741d8a22  vmovaps [rsp+0x20], xmm2
00007cf1741d8a28  vmovaps [rsp+0x30], xmm3
00007cf1741d8a2e  vmovaps [rsp+0x40], xmm4
00007cf1741d8a34  vmovaps [rsp+0x50], xmm5
00007cf1741d8a3a  vmovaps [rsp+0x60], xmm6
00007cf1741d8a40  vmovaps [rsp+0x70], xmm7
00007cf1741d8a46  vmovaps [rsp+0x80], xmm8
00007cf1741d8a4f  vmovaps [rsp+0x90], xmm9
00007cf1741d8a58  vmovaps [rsp+0xA0], xmm10
00007cf1741d8a61  vmovaps [rsp+0xB0], xmm11
00007cf1741d8a6a  vmovaps [rsp+0xC0], xmm12
00007cf1741d8a73  vmovaps [rsp+0xD0], xmm13
00007cf1741d8a7c  vmovaps [rsp+0xE0], xmm15
00007cf1741d8a85  sub rsp, 0x30
00007cf1741d8a89  movaps [rsp], xmm14
00007cf1741d8a8e  movaps [rsp+0x10], xmm2
00007cf1741d8a93  movaps [rsp+0x20], xmm1
00007cf1741d8a98  lea rdi, [rsp]
00007cf1741d8a9c  mov esi, 0x00
00007cf1741d8aa1  mov rax, 0x611C8A33A530
00007cf1741d8aab  call rax
00007cf1741d8aad  movaps xmm14, [rsp]
00007cf1741d8ab2  add rsp, 0x30
00007cf1741d8ab6  vmovaps xmm0, [rsp]
00007cf1741d8abb  vmovaps xmm1, [rsp+0x10]
00007cf1741d8ac1  vmovaps xmm2, [rsp+0x20]
00007cf1741d8ac7  vmovaps xmm3, [rsp+0x30]
00007cf1741d8acd  vmovaps xmm4, [rsp+0x40]
00007cf1741d8ad3  vmovaps xmm5, [rsp+0x50]
00007cf1741d8ad9  vmovaps xmm6, [rsp+0x60]
00007cf1741d8adf  vmovaps xmm7, [rsp+0x70]
00007cf1741d8ae5  vmovaps xmm8, [rsp+0x80]
00007cf1741d8aee  vmovaps xmm9, [rsp+0x90]
00007cf1741d8af7  vmovaps xmm10, [rsp+0xA0]
00007cf1741d8b00  vmovaps xmm11, [rsp+0xB0]
00007cf1741d8b09  vmovaps xmm12, [rsp+0xC0]
00007cf1741d8b12  vmovaps xmm13, [rsp+0xD0]
00007cf1741d8b1b  vmovaps xmm15, [rsp+0xE0]
00007cf1741d8b24  add rsp, 0xF0
00007cf1741d8b2b  pop r11
00007cf1741d8b2d  pop r10
00007cf1741d8b2f  pop r9
00007cf1741d8b31  pop r8
00007cf1741d8b33  pop rsi
00007cf1741d8b34  pop rdi
00007cf1741d8b35  pop rdx
00007cf1741d8b36  pop rcx
00007cf1741d8b37  pop rax
00007cf1741d8b38  add rsp, 0x08
00007cf1741d8b3c  jmp 0x00007CF1741D611D
00007cf1741d8b41  sub rsp, 0x08
00007cf1741d8b45  push rax
00007cf1741d8b46  push rcx
00007cf1741d8b47  push rdx
00007cf1741d8b48  push rdi
00007cf1741d8b49  push rsi
00007cf1741d8b4a  push r8
00007cf1741d8b4c  push r9
00007cf1741d8b4e  push r10
00007cf1741d8b50  push r11
00007cf1741d8b52  sub rsp, 0xF0
00007cf1741d8b59  vmovaps [rsp], xmm0
00007cf1741d8b5e  vmovaps [rsp+0x10], xmm2
00007cf1741d8b64  vmovaps [rsp+0x20], xmm3
00007cf1741d8b6a  vmovaps [rsp+0x30], xmm4
00007cf1741d8b70  vmovaps [rsp+0x40], xmm5
00007cf1741d8b76  vmovaps [rsp+0x50], xmm6
00007cf1741d8b7c  vmovaps [rsp+0x60], xmm7
00007cf1741d8b82  vmovaps [rsp+0x70], xmm8
00007cf1741d8b88  vmovaps [rsp+0x80], xmm9
00007cf1741d8b91  vmovaps [rsp+0x90], xmm10
00007cf1741d8b9a  vmovaps [rsp+0xA0], xmm11
00007cf1741d8ba3  vmovaps [rsp+0xB0], xmm12
00007cf1741d8bac  vmovaps [rsp+0xC0], xmm13
00007cf1741d8bb5  vmovaps [rsp+0xD0], xmm14
00007cf1741d8bbe  vmovaps [rsp+0xE0], xmm15
00007cf1741d8bc7  sub rsp, 0x30
00007cf1741d8bcb  movaps [rsp], xmm1
00007cf1741d8bcf  movaps [rsp+0x10], xmm4
00007cf1741d8bd4  movaps [rsp+0x20], xmm9
00007cf1741d8bda  lea rdi, [rsp]
00007cf1741d8bde  mov esi, 0x00
00007cf1741d8be3  mov rax, 0x611C8A33A530
00007cf1741d8bed  call rax
00007cf1741d8bef  movaps xmm1, [rsp]
00007cf1741d8bf3  add rsp, 0x30
00007cf1741d8bf7  vmovaps xmm0, [rsp]
00007cf1741d8bfc  vmovaps xmm2, [rsp+0x10]
00007cf1741d8c02  vmovaps xmm3, [rsp+0x20]
00007cf1741d8c08  vmovaps xmm4, [rsp+0x30]
00007cf1741d8c0e  vmovaps xmm5, [rsp+0x40]
00007cf1741d8c14  vmovaps xmm6, [rsp+0x50]
00007cf1741d8c1a  vmovaps xmm7, [rsp+0x60]
00007cf1741d8c20  vmovaps xmm8, [rsp+0x70]
00007cf1741d8c26  vmovaps xmm9, [rsp+0x80]
00007cf1741d8c2f  vmovaps xmm10, [rsp+0x90]
00007cf1741d8c38  vmovaps xmm11, [rsp+0xA0]
00007cf1741d8c41  vmovaps xmm12, [rsp+0xB0]
00007cf1741d8c4a  vmovaps xmm13, [rsp+0xC0]
00007cf1741d8c53  vmovaps xmm14, [rsp+0xD0]
00007cf1741d8c5c  vmovaps xmm15, [rsp+0xE0]
00007cf1741d8c65  add rsp, 0xF0
00007cf1741d8c6c  pop r11
00007cf1741d8c6e  pop r10
00007cf1741d8c70  pop r9
00007cf1741d8c72  pop r8
00007cf1741d8c74  pop rsi
00007cf1741d8c75  pop rdi
00007cf1741d8c76  pop rdx
00007cf1741d8c77  pop rcx
00007cf1741d8c78  pop rax
00007cf1741d8c79  add rsp, 0x08
00007cf1741d8c7d  jmp 0x00007CF1741D613B
00007cf1741d8c82  sub rsp, 0x08
00007cf1741d8c86  push rax
00007cf1741d8c87  push rcx
00007cf1741d8c88  push rdx
00007cf1741d8c89  push rdi
00007cf1741d8c8a  push rsi
00007cf1741d8c8b  push r8
00007cf1741d8c8d  push r9
00007cf1741d8c8f  push r10
00007cf1741d8c91  push r11
00007cf1741d8c93  sub rsp, 0xF0
00007cf1741d8c9a  vmovaps [rsp], xmm0
00007cf1741d8c9f  vmovaps [rsp+0x10], xmm1
00007cf1741d8ca5  vmovaps [rsp+0x20], xmm2
00007cf1741d8cab  vmovaps [rsp+0x30], xmm3
00007cf1741d8cb1  vmovaps [rsp+0x40], xmm5
00007cf1741d8cb7  vmovaps [rsp+0x50], xmm6
00007cf1741d8cbd  vmovaps [rsp+0x60], xmm7
00007cf1741d8cc3  vmovaps [rsp+0x70], xmm8
00007cf1741d8cc9  vmovaps [rsp+0x80], xmm9
00007cf1741d8cd2  vmovaps [rsp+0x90], xmm10
00007cf1741d8cdb  vmovaps [rsp+0xA0], xmm11
00007cf1741d8ce4  vmovaps [rsp+0xB0], xmm12
00007cf1741d8ced  vmovaps [rsp+0xC0], xmm13
00007cf1741d8cf6  vmovaps [rsp+0xD0], xmm14
00007cf1741d8cff  vmovaps [rsp+0xE0], xmm15
00007cf1741d8d08  sub rsp, 0x30
00007cf1741d8d0c  movaps [rsp], xmm4
00007cf1741d8d10  movaps [rsp+0x10], xmm2
00007cf1741d8d15  movaps [rsp+0x20], xmm9
00007cf1741d8d1b  lea rdi, [rsp]
00007cf1741d8d1f  mov esi, 0x00
00007cf1741d8d24  mov rax, 0x611C8A33A530
00007cf1741d8d2e  call rax
00007cf1741d8d30  movaps xmm4, [rsp]
00007cf1741d8d34  add rsp, 0x30
00007cf1741d8d38  vmovaps xmm0, [rsp]
00007cf1741d8d3d  vmovaps xmm1, [rsp+0x10]
00007cf1741d8d43  vmovaps xmm2, [rsp+0x20]
00007cf1741d8d49  vmovaps xmm3, [rsp+0x30]
00007cf1741d8d4f  vmovaps xmm5, [rsp+0x40]
00007cf1741d8d55  vmovaps xmm6, [rsp+0x50]
00007cf1741d8d5b  vmovaps xmm7, [rsp+0x60]
00007cf1741d8d61  vmovaps xmm8, [rsp+0x70]
00007cf1741d8d67  vmovaps xmm9, [rsp+0x80]
00007cf1741d8d70  vmovaps xmm10, [rsp+0x90]
00007cf1741d8d79  vmovaps xmm11, [rsp+0xA0]
00007cf1741d8d82  vmovaps xmm12, [rsp+0xB0]
00007cf1741d8d8b  vmovaps xmm13, [rsp+0xC0]
00007cf1741d8d94  vmovaps xmm14, [rsp+0xD0]
00007cf1741d8d9d  vmovaps xmm15, [rsp+0xE0]
00007cf1741d8da6  add rsp, 0xF0
00007cf1741d8dad  pop r11
00007cf1741d8daf  pop r10
00007cf1741d8db1  pop r9
00007cf1741d8db3  pop r8
00007cf1741d8db5  pop rsi
00007cf1741d8db6  pop rdi
00007cf1741d8db7  pop rdx
00007cf1741d8db8  pop rcx
00007cf1741d8db9  pop rax
00007cf1741d8dba  add rsp, 0x08
00007cf1741d8dbe  jmp 0x00007CF1741D616B
00007cf1741d8dc3  sub rsp, 0x08
00007cf1741d8dc7  push rax
00007cf1741d8dc8  push rcx
00007cf1741d8dc9  push rdx
00007cf1741d8dca  push rdi
00007cf1741d8dcb  push rsi
00007cf1741d8dcc  push r8
00007cf1741d8dce  push r9
00007cf1741d8dd0  push r10
00007cf1741d8dd2  push r11
00007cf1741d8dd4  sub rsp, 0xF0
00007cf1741d8ddb  vmovaps [rsp], xmm0
00007cf1741d8de0  vmovaps [rsp+0x10], xmm1
00007cf1741d8de6  vmovaps [rsp+0x20], xmm2
00007cf1741d8dec  vmovaps [rsp+0x30], xmm3
00007cf1741d8df2  vmovaps [rsp+0x40], xmm4
00007cf1741d8df8  vmovaps [rsp+0x50], xmm5
00007cf1741d8dfe  vmovaps [rsp+0x60], xmm6
00007cf1741d8e04  vmovaps [rsp+0x70], xmm7
00007cf1741d8e0a  vmovaps [rsp+0x80], xmm8
00007cf1741d8e13  vmovaps [rsp+0x90], xmm10
00007cf1741d8e1c  vmovaps [rsp+0xA0], xmm11
00007cf1741d8e25  vmovaps [rsp+0xB0], xmm12
00007cf1741d8e2e  vmovaps [rsp+0xC0], xmm13
00007cf1741d8e37  vmovaps [rsp+0xD0], xmm14
00007cf1741d8e40  vmovaps [rsp+0xE0], xmm15
00007cf1741d8e49  sub rsp, 0x30
00007cf1741d8e4d  movaps [rsp], xmm9
00007cf1741d8e52  movaps [rsp+0x10], xmm2
00007cf1741d8e57  movaps [rsp+0x20], xmm1
00007cf1741d8e5c  lea rdi, [rsp]
00007cf1741d8e60  mov esi, 0x00
00007cf1741d8e65  mov rax, 0x611C8A33A530
00007cf1741d8e6f  call rax
00007cf1741d8e71  movaps xmm9, [rsp]
00007cf1741d8e76  add rsp, 0x30
00007cf1741d8e7a  vmovaps xmm0, [rsp]
00007cf1741d8e7f  vmovaps xmm1, [rsp+0x10]
00007cf1741d8e85  vmovaps xmm2, [rsp+0x20]
00007cf1741d8e8b  vmovaps xmm3, [rsp+0x30]
00007cf1741d8e91  vmovaps xmm4, [rsp+0x40]
00007cf1741d8e97  vmovaps xmm5, [rsp+0x50]
00007cf1741d8e9d  vmovaps xmm6, [rsp+0x60]
00007cf1741d8ea3  vmovaps xmm7, [rsp+0x70]
00007cf1741d8ea9  vmovaps xmm8, [rsp+0x80]
00007cf1741d8eb2  vmovaps xmm10, [rsp+0x90]
00007cf1741d8ebb  vmovaps xmm11, [rsp+0xA0]
00007cf1741d8ec4  vmovaps xmm12, [rsp+0xB0]
00007cf1741d8ecd  vmovaps xmm13, [rsp+0xC0]
00007cf1741d8ed6  vmovaps xmm14, [rsp+0xD0]
00007cf1741d8edf  vmovaps xmm15, [rsp+0xE0]
00007cf1741d8ee8  add rsp, 0xF0
00007cf1741d8eef  pop r11
00007cf1741d8ef1  pop r10
00007cf1741d8ef3  pop r9
00007cf1741d8ef5  pop r8
00007cf1741d8ef7  pop rsi
00007cf1741d8ef8  pop rdi
00007cf1741d8ef9  pop rdx
00007cf1741d8efa  pop rcx
00007cf1741d8efb  pop rax
00007cf1741d8efc  add rsp, 0x08
00007cf1741d8f00  jmp 0x00007CF1741D61A1
00007cf1741d8f05  sub rsp, 0x08
00007cf1741d8f09  push rax
00007cf1741d8f0a  push rcx
00007cf1741d8f0b  push rdx
00007cf1741d8f0c  push rdi
00007cf1741d8f0d  push rsi
00007cf1741d8f0e  push r8
00007cf1741d8f10  push r9
00007cf1741d8f12  push r10
00007cf1741d8f14  push r11
00007cf1741d8f16  sub rsp, 0xF0
00007cf1741d8f1d  vmovaps [rsp], xmm0
00007cf1741d8f22  vmovaps [rsp+0x10], xmm2
00007cf1741d8f28  vmovaps [rsp+0x20], xmm3
00007cf1741d8f2e  vmovaps [rsp+0x30], xmm4
00007cf1741d8f34  vmovaps [rsp+0x40], xmm5
00007cf1741d8f3a  vmovaps [rsp+0x50], xmm6
00007cf1741d8f40  vmovaps [rsp+0x60], xmm7
00007cf1741d8f46  vmovaps [rsp+0x70], xmm8
00007cf1741d8f4c  vmovaps [rsp+0x80], xmm9
00007cf1741d8f55  vmovaps [rsp+0x90], xmm10
00007cf1741d8f5e  vmovaps [rsp+0xA0], xmm11
00007cf1741d8f67  vmovaps [rsp+0xB0], xmm12
00007cf1741d8f70  vmovaps [rsp+0xC0], xmm13
00007cf1741d8f79  vmovaps [rsp+0xD0], xmm14
00007cf1741d8f82  vmovaps [rsp+0xE0], xmm15
00007cf1741d8f8b  sub rsp, 0x30
00007cf1741d8f8f  movaps [rsp], xmm1
00007cf1741d8f93  movaps [rsp+0x10], xmm15
00007cf1741d8f99  movaps [rsp+0x20], xmm6
00007cf1741d8f9e  lea rdi, [rsp]
00007cf1741d8fa2  mov esi, 0x00
00007cf1741d8fa7  mov rax, 0x611C8A33A530
00007cf1741d8fb1  call rax
00007cf1741d8fb3  movaps xmm1, [rsp]
00007cf1741d8fb7  add rsp, 0x30
00007cf1741d8fbb  vmovaps xmm0, [rsp]
00007cf1741d8fc0  vmovaps xmm2, [rsp+0x10]
00007cf1741d8fc6  vmovaps xmm3, [rsp+0x20]
00007cf1741d8fcc  vmovaps xmm4, [rsp+0x30]
00007cf1741d8fd2  vmovaps xmm5, [rsp+0x40]
00007cf1741d8fd8  vmovaps xmm6, [rsp+0x50]
00007cf1741d8fde  vmovaps xmm7, [rsp+0x60]
00007cf1741d8fe4  vmovaps xmm8, [rsp+0x70]
00007cf1741d8fea  vmovaps xmm9, [rsp+0x80]
00007cf1741d8ff3  vmovaps xmm10, [rsp+0x90]
00007cf1741d8ffc  vmovaps xmm11, [rsp+0xA0]
00007cf1741d9005  vmovaps xmm12, [rsp+0xB0]
00007cf1741d900e  vmovaps xmm13, [rsp+0xC0]
00007cf1741d9017  vmovaps xmm14, [rsp+0xD0]
00007cf1741d9020  vmovaps xmm15, [rsp+0xE0]
00007cf1741d9029  add rsp, 0xF0
00007cf1741d9030  pop r11
00007cf1741d9032  pop r10
00007cf1741d9034  pop r9
00007cf1741d9036  pop r8
00007cf1741d9038  pop rsi
00007cf1741d9039  pop rdi
00007cf1741d903a  pop rdx
00007cf1741d903b  pop rcx
00007cf1741d903c  pop rax
00007cf1741d903d  add rsp, 0x08
00007cf1741d9041  jmp 0x00007CF1741D61C2
00007cf1741d9046  sub rsp, 0x08
00007cf1741d904a  push rax
00007cf1741d904b  push rcx
00007cf1741d904c  push rdx
00007cf1741d904d  push rdi
00007cf1741d904e  push rsi
00007cf1741d904f  push r8
00007cf1741d9051  push r9
00007cf1741d9053  push r10
00007cf1741d9055  push r11
00007cf1741d9057  sub rsp, 0xF0
00007cf1741d905e  vmovaps [rsp], xmm0
00007cf1741d9063  vmovaps [rsp+0x10], xmm1
00007cf1741d9069  vmovaps [rsp+0x20], xmm2
00007cf1741d906f  vmovaps [rsp+0x30], xmm3
00007cf1741d9075  vmovaps [rsp+0x40], xmm4
00007cf1741d907b  vmovaps [rsp+0x50], xmm5
00007cf1741d9081  vmovaps [rsp+0x60], xmm6
00007cf1741d9087  vmovaps [rsp+0x70], xmm7
00007cf1741d908d  vmovaps [rsp+0x80], xmm8
00007cf1741d9096  vmovaps [rsp+0x90], xmm9
00007cf1741d909f  vmovaps [rsp+0xA0], xmm10
00007cf1741d90a8  vmovaps [rsp+0xB0], xmm11
00007cf1741d90b1  vmovaps [rsp+0xC0], xmm12
00007cf1741d90ba  vmovaps [rsp+0xD0], xmm13
00007cf1741d90c3  vmovaps [rsp+0xE0], xmm14
00007cf1741d90cc  sub rsp, 0x30
00007cf1741d90d0  movaps [rsp], xmm15
00007cf1741d90d5  movaps [rsp+0x10], xmm5
00007cf1741d90da  movaps [rsp+0x20], xmm3
00007cf1741d90df  lea rdi, [rsp]
00007cf1741d90e3  mov esi, 0x00
00007cf1741d90e8  mov rax, 0x611C8A33A530
00007cf1741d90f2  call rax
00007cf1741d90f4  movaps xmm15, [rsp]
00007cf1741d90f9  add rsp, 0x30
00007cf1741d90fd  vmovaps xmm0, [rsp]
00007cf1741d9102  vmovaps xmm1, [rsp+0x10]
00007cf1741d9108  vmovaps xmm2, [rsp+0x20]
00007cf1741d910e  vmovaps xmm3, [rsp+0x30]
00007cf1741d9114  vmovaps xmm4, [rsp+0x40]
00007cf1741d911a  vmovaps xmm5, [rsp+0x50]
00007cf1741d9120  vmovaps xmm6, [rsp+0x60]
00007cf1741d9126  vmovaps xmm7, [rsp+0x70]
00007cf1741d912c  vmovaps xmm8, [rsp+0x80]
00007cf1741d9135  vmovaps xmm9, [rsp+0x90]
00007cf1741d913e  vmovaps xmm10, [rsp+0xA0]
00007cf1741d9147  vmovaps xmm11, [rsp+0xB0]
00007cf1741d9150  vmovaps xmm12, [rsp+0xC0]
00007cf1741d9159  vmovaps xmm13, [rsp+0xD0]
00007cf1741d9162  vmovaps xmm14, [rsp+0xE0]
00007cf1741d916b  add rsp, 0xF0
00007cf1741d9172  pop r11
00007cf1741d9174  pop r10
00007cf1741d9176  pop r9
00007cf1741d9178  pop r8
00007cf1741d917a  pop rsi
00007cf1741d917b  pop rdi
00007cf1741d917c  pop rdx
00007cf1741d917d  pop rcx
00007cf1741d917e  pop rax
00007cf1741d917f  add rsp, 0x08
00007cf1741d9183  jmp 0x00007CF1741D61DC
00007cf1741d9188  sub rsp, 0x08
00007cf1741d918c  push rax
00007cf1741d918d  push rcx
00007cf1741d918e  push rdx
00007cf1741d918f  push rdi
00007cf1741d9190  push rsi
00007cf1741d9191  push r8
00007cf1741d9193  push r9
00007cf1741d9195  push r10
00007cf1741d9197  push r11
00007cf1741d9199  sub rsp, 0xF0
00007cf1741d91a0  vmovaps [rsp], xmm0
00007cf1741d91a5  vmovaps [rsp+0x10], xmm1
00007cf1741d91ab  vmovaps [rsp+0x20], xmm2
00007cf1741d91b1  vmovaps [rsp+0x30], xmm3
00007cf1741d91b7  vmovaps [rsp+0x40], xmm4
00007cf1741d91bd  vmovaps [rsp+0x50], xmm6
00007cf1741d91c3  vmovaps [rsp+0x60], xmm7
00007cf1741d91c9  vmovaps [rsp+0x70], xmm8
00007cf1741d91cf  vmovaps [rsp+0x80], xmm9
00007cf1741d91d8  vmovaps [rsp+0x90], xmm10
00007cf1741d91e1  vmovaps [rsp+0xA0], xmm11
00007cf1741d91ea  vmovaps [rsp+0xB0], xmm12
00007cf1741d91f3  vmovaps [rsp+0xC0], xmm13
00007cf1741d91fc  vmovaps [rsp+0xD0], xmm14
00007cf1741d9205  vmovaps [rsp+0xE0], xmm15
00007cf1741d920e  sub rsp, 0x30
00007cf1741d9212  movaps [rsp], xmm5
00007cf1741d9216  movaps [rsp+0x10], xmm8
00007cf1741d921c  movaps [rsp+0x20], xmm6
00007cf1741d9221  lea rdi, [rsp]
00007cf1741d9225  mov esi, 0x00
00007cf1741d922a  mov rax, 0x611C8A33A530
00007cf1741d9234  call rax
00007cf1741d9236  movaps xmm5, [rsp]
00007cf1741d923a  add rsp, 0x30
00007cf1741d923e  vmovaps xmm0, [rsp]
00007cf1741d9243  vmovaps xmm1, [rsp+0x10]
00007cf1741d9249  vmovaps xmm2, [rsp+0x20]
00007cf1741d924f  vmovaps xmm3, [rsp+0x30]
00007cf1741d9255  vmovaps xmm4, [rsp+0x40]
00007cf1741d925b  vmovaps xmm6, [rsp+0x50]
00007cf1741d9261  vmovaps xmm7, [rsp+0x60]
00007cf1741d9267  vmovaps xmm8, [rsp+0x70]
00007cf1741d926d  vmovaps xmm9, [rsp+0x80]
00007cf1741d9276  vmovaps xmm10, [rsp+0x90]
00007cf1741d927f  vmovaps xmm11, [rsp+0xA0]
00007cf1741d9288  vmovaps xmm12, [rsp+0xB0]
00007cf1741d9291  vmovaps xmm13, [rsp+0xC0]
00007cf1741d929a  vmovaps xmm14, [rsp+0xD0]
00007cf1741d92a3  vmovaps xmm15, [rsp+0xE0]
00007cf1741d92ac  add rsp, 0xF0
00007cf1741d92b3  pop r11
00007cf1741d92b5  pop r10
00007cf1741d92b7  pop r9
00007cf1741d92b9  pop r8
00007cf1741d92bb  pop rsi
00007cf1741d92bc  pop rdi
00007cf1741d92bd  pop rdx
00007cf1741d92be  pop rcx
00007cf1741d92bf  pop rax
00007cf1741d92c0  add rsp, 0x08
00007cf1741d92c4  jmp 0x00007CF1741D6200
00007cf1741d92c9  sub rsp, 0x08
00007cf1741d92cd  push rax
00007cf1741d92ce  push rcx
00007cf1741d92cf  push rdx
00007cf1741d92d0  push rdi
00007cf1741d92d1  push rsi
00007cf1741d92d2  push r8
00007cf1741d92d4  push r9
00007cf1741d92d6  push r10
00007cf1741d92d8  push r11
00007cf1741d92da  sub rsp, 0xF0
00007cf1741d92e1  vmovaps [rsp], xmm0
00007cf1741d92e6  vmovaps [rsp+0x10], xmm1
00007cf1741d92ec  vmovaps [rsp+0x20], xmm2
00007cf1741d92f2  vmovaps [rsp+0x30], xmm3
00007cf1741d92f8  vmovaps [rsp+0x40], xmm4
00007cf1741d92fe  vmovaps [rsp+0x50], xmm5
00007cf1741d9304  vmovaps [rsp+0x60], xmm7
00007cf1741d930a  vmovaps [rsp+0x70], xmm8
00007cf1741d9310  vmovaps [rsp+0x80], xmm9
00007cf1741d9319  vmovaps [rsp+0x90], xmm10
00007cf1741d9322  vmovaps [rsp+0xA0], xmm11
00007cf1741d932b  vmovaps [rsp+0xB0], xmm12
00007cf1741d9334  vmovaps [rsp+0xC0], xmm13
00007cf1741d933d  vmovaps [rsp+0xD0], xmm14
00007cf1741d9346  vmovaps [rsp+0xE0], xmm15
00007cf1741d934f  sub rsp, 0x30
00007cf1741d9353  movaps [rsp], xmm6
00007cf1741d9357  movaps [rsp+0x10], xmm10
00007cf1741d935d  movaps [rsp+0x20], xmm8
00007cf1741d9363  lea rdi, [rsp]
00007cf1741d9367  mov esi, 0x00
00007cf1741d936c  mov rax, 0x611C8A33A530
00007cf1741d9376  call rax
00007cf1741d9378  movaps xmm6, [rsp]
00007cf1741d937c  add rsp, 0x30
00007cf1741d9380  vmovaps xmm0, [rsp]
00007cf1741d9385  vmovaps xmm1, [rsp+0x10]
00007cf1741d938b  vmovaps xmm2, [rsp+0x20]
00007cf1741d9391  vmovaps xmm3, [rsp+0x30]
00007cf1741d9397  vmovaps xmm4, [rsp+0x40]
00007cf1741d939d  vmovaps xmm5, [rsp+0x50]
00007cf1741d93a3  vmovaps xmm7, [rsp+0x60]
00007cf1741d93a9  vmovaps xmm8, [rsp+0x70]
00007cf1741d93af  vmovaps xmm9, [rsp+0x80]
00007cf1741d93b8  vmovaps xmm10, [rsp+0x90]
00007cf1741d93c1  vmovaps xmm11, [rsp+0xA0]
00007cf1741d93ca  vmovaps xmm12, [rsp+0xB0]
00007cf1741d93d3  vmovaps xmm13, [rsp+0xC0]
00007cf1741d93dc  vmovaps xmm14, [rsp+0xD0]
00007cf1741d93e5  vmovaps xmm15, [rsp+0xE0]
00007cf1741d93ee  add rsp, 0xF0
00007cf1741d93f5  pop r11
00007cf1741d93f7  pop r10
00007cf1741d93f9  pop r9
00007cf1741d93fb  pop r8
00007cf1741d93fd  pop rsi
00007cf1741d93fe  pop rdi
00007cf1741d93ff  pop rdx
00007cf1741d9400  pop rcx
00007cf1741d9401  pop rax
00007cf1741d9402  add rsp, 0x08
00007cf1741d9406  jmp 0x00007CF1741D6225
00007cf1741d940b  sub rsp, 0x08
00007cf1741d940f  push rax
00007cf1741d9410  push rcx
00007cf1741d9411  push rdx
00007cf1741d9412  push rdi
00007cf1741d9413  push rsi
00007cf1741d9414  push r8
00007cf1741d9416  push r9
00007cf1741d9418  push r10
00007cf1741d941a  push r11
00007cf1741d941c  sub rsp, 0xF0
00007cf1741d9423  vmovaps [rsp], xmm0
00007cf1741d9428  vmovaps [rsp+0x10], xmm1
00007cf1741d942e  vmovaps [rsp+0x20], xmm2
00007cf1741d9434  vmovaps [rsp+0x30], xmm3
00007cf1741d943a  vmovaps [rsp+0x40], xmm4
00007cf1741d9440  vmovaps [rsp+0x50], xmm5
00007cf1741d9446  vmovaps [rsp+0x60], xmm6
00007cf1741d944c  vmovaps [rsp+0x70], xmm7
00007cf1741d9452  vmovaps [rsp+0x80], xmm8
00007cf1741d945b  vmovaps [rsp+0x90], xmm9
00007cf1741d9464  vmovaps [rsp+0xA0], xmm11
00007cf1741d946d  vmovaps [rsp+0xB0], xmm12
00007cf1741d9476  vmovaps [rsp+0xC0], xmm13
00007cf1741d947f  vmovaps [rsp+0xD0], xmm14
00007cf1741d9488  vmovaps [rsp+0xE0], xmm15
00007cf1741d9491  sub rsp, 0x30
00007cf1741d9495  movaps [rsp], xmm10
00007cf1741d949a  movaps [rsp+0x10], xmm8
00007cf1741d94a0  movaps [rsp+0x20], xmm14
00007cf1741d94a6  lea rdi, [rsp]
00007cf1741d94aa  mov esi, 0x00
00007cf1741d94af  mov rax, 0x611C8A33A530
00007cf1741d94b9  call rax
00007cf1741d94bb  movaps xmm10, [rsp]
00007cf1741d94c0  add rsp, 0x30
00007cf1741d94c4  vmovaps xmm0, [rsp]
00007cf1741d94c9  vmovaps xmm1, [rsp+0x10]
00007cf1741d94cf  vmovaps xmm2, [rsp+0x20]
00007cf1741d94d5  vmovaps xmm3, [rsp+0x30]
00007cf1741d94db  vmovaps xmm4, [rsp+0x40]
00007cf1741d94e1  vmovaps xmm5, [rsp+0x50]
00007cf1741d94e7  vmovaps xmm6, [rsp+0x60]
00007cf1741d94ed  vmovaps xmm7, [rsp+0x70]
00007cf1741d94f3  vmovaps xmm8, [rsp+0x80]
00007cf1741d94fc  vmovaps xmm9, [rsp+0x90]
00007cf1741d9505  vmovaps xmm11, [rsp+0xA0]
00007cf1741d950e  vmovaps xmm12, [rsp+0xB0]
00007cf1741d9517  vmovaps xmm13, [rsp+0xC0]
00007cf1741d9520  vmovaps xmm14, [rsp+0xD0]
00007cf1741d9529  vmovaps xmm15, [rsp+0xE0]
00007cf1741d9532  add rsp, 0xF0
00007cf1741d9539  pop r11
00007cf1741d953b  pop r10
00007cf1741d953d  pop r9
00007cf1741d953f  pop r8
00007cf1741d9541  pop rsi
00007cf1741d9542  pop rdi
00007cf1741d9543  pop rdx
00007cf1741d9544  pop rcx
00007cf1741d9545  pop rax
00007cf1741d9546  add rsp, 0x08
00007cf1741d954a  jmp 0x00007CF1741D6245
00007cf1741d954f  sub rsp, 0x08
00007cf1741d9553  push rax
00007cf1741d9554  push rcx
00007cf1741d9555  push rdx
00007cf1741d9556  push rdi
00007cf1741d9557  push rsi
00007cf1741d9558  push r8
00007cf1741d955a  push r9
00007cf1741d955c  push r10
00007cf1741d955e  push r11
00007cf1741d9560  sub rsp, 0xF0
00007cf1741d9567  vmovaps [rsp], xmm0
00007cf1741d956c  vmovaps [rsp+0x10], xmm1
00007cf1741d9572  vmovaps [rsp+0x20], xmm2
00007cf1741d9578  vmovaps [rsp+0x30], xmm3
00007cf1741d957e  vmovaps [rsp+0x40], xmm4
00007cf1741d9584  vmovaps [rsp+0x50], xmm5
00007cf1741d958a  vmovaps [rsp+0x60], xmm6
00007cf1741d9590  vmovaps [rsp+0x70], xmm7
00007cf1741d9596  vmovaps [rsp+0x80], xmm8
00007cf1741d959f  vmovaps [rsp+0x90], xmm9
00007cf1741d95a8  vmovaps [rsp+0xA0], xmm10
00007cf1741d95b1  vmovaps [rsp+0xB0], xmm11
00007cf1741d95ba  vmovaps [rsp+0xC0], xmm12
00007cf1741d95c3  vmovaps [rsp+0xD0], xmm13
00007cf1741d95cc  vmovaps [rsp+0xE0], xmm15
00007cf1741d95d5  sub rsp, 0x30
00007cf1741d95d9  movaps [rsp], xmm14
00007cf1741d95de  movaps [rsp+0x10], xmm8
00007cf1741d95e4  movaps [rsp+0x20], xmm4
00007cf1741d95e9  lea rdi, [rsp]
00007cf1741d95ed  mov esi, 0x00
00007cf1741d95f2  mov rax, 0x611C8A33A530
00007cf1741d95fc  call rax
00007cf1741d95fe  movaps xmm14, [rsp]
00007cf1741d9603  add rsp, 0x30
00007cf1741d9607  vmovaps xmm0, [rsp]
00007cf1741d960c  vmovaps xmm1, [rsp+0x10]
00007cf1741d9612  vmovaps xmm2, [rsp+0x20]
00007cf1741d9618  vmovaps xmm3, [rsp+0x30]
00007cf1741d961e  vmovaps xmm4, [rsp+0x40]
00007cf1741d9624  vmovaps xmm5, [rsp+0x50]
00007cf1741d962a  vmovaps xmm6, [rsp+0x60]
00007cf1741d9630  vmovaps xmm7, [rsp+0x70]
00007cf1741d9636  vmovaps xmm8, [rsp+0x80]
00007cf1741d963f  vmovaps xmm9, [rsp+0x90]
00007cf1741d9648  vmovaps xmm10, [rsp+0xA0]
00007cf1741d9651  vmovaps xmm11, [rsp+0xB0]
00007cf1741d965a  vmovaps xmm12, [rsp+0xC0]
00007cf1741d9663  vmovaps xmm13, [rsp+0xD0]
00007cf1741d966c  vmovaps xmm15, [rsp+0xE0]
00007cf1741d9675  add rsp, 0xF0
00007cf1741d967c  pop r11
00007cf1741d967e  pop r10
00007cf1741d9680  pop r9
00007cf1741d9682  pop r8
00007cf1741d9684  pop rsi
00007cf1741d9685  pop rdi
00007cf1741d9686  pop rdx
00007cf1741d9687  pop rcx
00007cf1741d9688  pop rax
00007cf1741d9689  add rsp, 0x08
00007cf1741d968d  jmp 0x00007CF1741D6265
00007cf1741d9692  sub rsp, 0x08
00007cf1741d9696  push rax
00007cf1741d9697  push rcx
00007cf1741d9698  push rdx
00007cf1741d9699  push rdi
00007cf1741d969a  push rsi
00007cf1741d969b  push r8
00007cf1741d969d  push r9
00007cf1741d969f  push r10
00007cf1741d96a1  push r11
00007cf1741d96a3  sub rsp, 0xF0
00007cf1741d96aa  vmovaps [rsp], xmm0
00007cf1741d96af  vmovaps [rsp+0x10], xmm1
00007cf1741d96b5  vmovaps [rsp+0x20], xmm2
00007cf1741d96bb  vmovaps [rsp+0x30], xmm3
00007cf1741d96c1  vmovaps [rsp+0x40], xmm5
00007cf1741d96c7  vmovaps [rsp+0x50], xmm6
00007cf1741d96cd  vmovaps [rsp+0x60], xmm7
00007cf1741d96d3  vmovaps [rsp+0x70], xmm8
00007cf1741d96d9  vmovaps [rsp+0x80], xmm9
00007cf1741d96e2  vmovaps [rsp+0x90], xmm10
00007cf1741d96eb  vmovaps [rsp+0xA0], xmm11
00007cf1741d96f4  vmovaps [rsp+0xB0], xmm12
00007cf1741d96fd  vmovaps [rsp+0xC0], xmm13
00007cf1741d9706  vmovaps [rsp+0xD0], xmm14
00007cf1741d970f  vmovaps [rsp+0xE0], xmm15
00007cf1741d9718  sub rsp, 0x30
00007cf1741d971c  movaps [rsp], xmm4
00007cf1741d9720  movaps [rsp+0x10], xmm13
00007cf1741d9726  movaps [rsp+0x20], xmm8
00007cf1741d972c  lea rdi, [rsp]
00007cf1741d9730  mov esi, 0x00
00007cf1741d9735  mov rax, 0x611C8A33A530
00007cf1741d973f  call rax
00007cf1741d9741  movaps xmm4, [rsp]
00007cf1741d9745  add rsp, 0x30
00007cf1741d9749  vmovaps xmm0, [rsp]
00007cf1741d974e  vmovaps xmm1, [rsp+0x10]
00007cf1741d9754  vmovaps xmm2, [rsp+0x20]
00007cf1741d975a  vmovaps xmm3, [rsp+0x30]
00007cf1741d9760  vmovaps xmm5, [rsp+0x40]
00007cf1741d9766  vmovaps xmm6, [rsp+0x50]
00007cf1741d976c  vmovaps xmm7, [rsp+0x60]
00007cf1741d9772  vmovaps xmm8, [rsp+0x70]
00007cf1741d9778  vmovaps xmm9, [rsp+0x80]
00007cf1741d9781  vmovaps xmm10, [rsp+0x90]
00007cf1741d978a  vmovaps xmm11, [rsp+0xA0]
00007cf1741d9793  vmovaps xmm12, [rsp+0xB0]
00007cf1741d979c  vmovaps xmm13, [rsp+0xC0]
00007cf1741d97a5  vmovaps xmm14, [rsp+0xD0]
00007cf1741d97ae  vmovaps xmm15, [rsp+0xE0]
00007cf1741d97b7  add rsp, 0xF0
00007cf1741d97be  pop r11
00007cf1741d97c0  pop r10
00007cf1741d97c2  pop r9
00007cf1741d97c4  pop r8
00007cf1741d97c6  pop rsi
00007cf1741d97c7  pop rdi
00007cf1741d97c8  pop rdx
00007cf1741d97c9  pop rcx
00007cf1741d97ca  pop rax
00007cf1741d97cb  add rsp, 0x08
00007cf1741d97cf  jmp 0x00007CF1741D628A
00007cf1741d97d4  sub rsp, 0x08
00007cf1741d97d8  push rax
00007cf1741d97d9  push rcx
00007cf1741d97da  push rdx
00007cf1741d97db  push rdi
00007cf1741d97dc  push rsi
00007cf1741d97dd  push r8
00007cf1741d97df  push r9
00007cf1741d97e1  push r10
00007cf1741d97e3  push r11
00007cf1741d97e5  sub rsp, 0xF0
00007cf1741d97ec  vmovaps [rsp], xmm0
00007cf1741d97f1  vmovaps [rsp+0x10], xmm1
00007cf1741d97f7  vmovaps [rsp+0x20], xmm2
00007cf1741d97fd  vmovaps [rsp+0x30], xmm3
00007cf1741d9803  vmovaps [rsp+0x40], xmm4
00007cf1741d9809  vmovaps [rsp+0x50], xmm5
00007cf1741d980f  vmovaps [rsp+0x60], xmm6
00007cf1741d9815  vmovaps [rsp+0x70], xmm7
00007cf1741d981b  vmovaps [rsp+0x80], xmm8
00007cf1741d9824  vmovaps [rsp+0x90], xmm9
00007cf1741d982d  vmovaps [rsp+0xA0], xmm10
00007cf1741d9836  vmovaps [rsp+0xB0], xmm11
00007cf1741d983f  vmovaps [rsp+0xC0], xmm12
00007cf1741d9848  vmovaps [rsp+0xD0], xmm14
00007cf1741d9851  vmovaps [rsp+0xE0], xmm15
00007cf1741d985a  sub rsp, 0x30
00007cf1741d985e  movaps [rsp], xmm13
00007cf1741d9863  movaps [rsp+0x10], xmm15
00007cf1741d9869  movaps [rsp+0x20], xmm9
00007cf1741d986f  lea rdi, [rsp]
00007cf1741d9873  mov esi, 0x00
00007cf1741d9878  mov rax, 0x611C8A33A530
00007cf1741d9882  call rax
00007cf1741d9884  movaps xmm13, [rsp]
00007cf1741d9889  add rsp, 0x30
00007cf1741d988d  vmovaps xmm0, [rsp]
00007cf1741d9892  vmovaps xmm1, [rsp+0x10]
00007cf1741d9898  vmovaps xmm2, [rsp+0x20]
00007cf1741d989e  vmovaps xmm3, [rsp+0x30]
00007cf1741d98a4  vmovaps xmm4, [rsp+0x40]
00007cf1741d98aa  vmovaps xmm5, [rsp+0x50]
00007cf1741d98b0  vmovaps xmm6, [rsp+0x60]
00007cf1741d98b6  vmovaps xmm7, [rsp+0x70]
00007cf1741d98bc  vmovaps xmm8, [rsp+0x80]
00007cf1741d98c5  vmovaps xmm9, [rsp+0x90]
00007cf1741d98ce  vmovaps xmm10, [rsp+0xA0]
00007cf1741d98d7  vmovaps xmm11, [rsp+0xB0]
00007cf1741d98e0  vmovaps xmm12, [rsp+0xC0]
00007cf1741d98e9  vmovaps xmm14, [rsp+0xD0]
00007cf1741d98f2  vmovaps xmm15, [rsp+0xE0]
00007cf1741d98fb  add rsp, 0xF0
00007cf1741d9902  pop r11
00007cf1741d9904  pop r10
00007cf1741d9906  pop r9
00007cf1741d9908  pop r8
00007cf1741d990a  pop rsi
00007cf1741d990b  pop rdi
00007cf1741d990c  pop rdx
00007cf1741d990d  pop rcx
00007cf1741d990e  pop rax
00007cf1741d990f  add rsp, 0x08
00007cf1741d9913  jmp 0x00007CF1741D62A5
00007cf1741d9918  sub rsp, 0x08
00007cf1741d991c  push rax
00007cf1741d991d  push rcx
00007cf1741d991e  push rdx
00007cf1741d991f  push rdi
00007cf1741d9920  push rsi
00007cf1741d9921  push r8
00007cf1741d9923  push r9
00007cf1741d9925  push r10
00007cf1741d9927  push r11
00007cf1741d9929  sub rsp, 0xF0
00007cf1741d9930  vmovaps [rsp], xmm0
00007cf1741d9935  vmovaps [rsp+0x10], xmm1
00007cf1741d993b  vmovaps [rsp+0x20], xmm2
00007cf1741d9941  vmovaps [rsp+0x30], xmm3
00007cf1741d9947  vmovaps [rsp+0x40], xmm4
00007cf1741d994d  vmovaps [rsp+0x50], xmm5
00007cf1741d9953  vmovaps [rsp+0x60], xmm6
00007cf1741d9959  vmovaps [rsp+0x70], xmm7
00007cf1741d995f  vmovaps [rsp+0x80], xmm8
00007cf1741d9968  vmovaps [rsp+0x90], xmm9
00007cf1741d9971  vmovaps [rsp+0xA0], xmm10
00007cf1741d997a  vmovaps [rsp+0xB0], xmm11
00007cf1741d9983  vmovaps [rsp+0xC0], xmm12
00007cf1741d998c  vmovaps [rsp+0xD0], xmm13
00007cf1741d9995  vmovaps [rsp+0xE0], xmm14
00007cf1741d999e  sub rsp, 0x30
00007cf1741d99a2  movaps [rsp], xmm15
00007cf1741d99a7  movaps [rsp+0x10], xmm1
00007cf1741d99ac  movaps [rsp+0x20], xmm5
00007cf1741d99b1  lea rdi, [rsp]
00007cf1741d99b5  mov esi, 0x00
00007cf1741d99ba  mov rax, 0x611C8A33A530
00007cf1741d99c4  call rax
00007cf1741d99c6  movaps xmm15, [rsp]
00007cf1741d99cb  add rsp, 0x30
00007cf1741d99cf  vmovaps xmm0, [rsp]
00007cf1741d99d4  vmovaps xmm1, [rsp+0x10]
00007cf1741d99da  vmovaps xmm2, [rsp+0x20]
00007cf1741d99e0  vmovaps xmm3, [rsp+0x30]
00007cf1741d99e6  vmovaps xmm4, [rsp+0x40]
00007cf1741d99ec  vmovaps xmm5, [rsp+0x50]
00007cf1741d99f2  vmovaps xmm6, [rsp+0x60]
00007cf1741d99f8  vmovaps xmm7, [rsp+0x70]
00007cf1741d99fe  vmovaps xmm8, [rsp+0x80]
00007cf1741d9a07  vmovaps xmm9, [rsp+0x90]
00007cf1741d9a10  vmovaps xmm10, [rsp+0xA0]
00007cf1741d9a19  vmovaps xmm11, [rsp+0xB0]
00007cf1741d9a22  vmovaps xmm12, [rsp+0xC0]
00007cf1741d9a2b  vmovaps xmm13, [rsp+0xD0]
00007cf1741d9a34  vmovaps xmm14, [rsp+0xE0]
00007cf1741d9a3d  add rsp, 0xF0
00007cf1741d9a44  pop r11
00007cf1741d9a46  pop r10
00007cf1741d9a48  pop r9
00007cf1741d9a4a  pop r8
00007cf1741d9a4c  pop rsi
00007cf1741d9a4d  pop rdi
00007cf1741d9a4e  pop rdx
00007cf1741d9a4f  pop rcx
00007cf1741d9a50  pop rax
00007cf1741d9a51  add rsp, 0x08
00007cf1741d9a55  jmp 0x00007CF1741D62C0
00007cf1741d9a5a  call 0x00007CF1740D64F0
00007cf1741d9a5f  jmp 0x00007CF1741D631B
00007cf1741d9a64  sub rsp, 0x08
00007cf1741d9a68  push rax
00007cf1741d9a69  push rcx
00007cf1741d9a6a  push rdx
00007cf1741d9a6b  push rdi
00007cf1741d9a6c  push rsi
00007cf1741d9a6d  push r8
00007cf1741d9a6f  push r9
00007cf1741d9a71  push r10
00007cf1741d9a73  push r11
00007cf1741d9a75  sub rsp, 0xF0
00007cf1741d9a7c  vmovaps [rsp], xmm0
00007cf1741d9a81  vmovaps [rsp+0x10], xmm1
00007cf1741d9a87  vmovaps [rsp+0x20], xmm2
00007cf1741d9a8d  vmovaps [rsp+0x30], xmm3
00007cf1741d9a93  vmovaps [rsp+0x40], xmm4
00007cf1741d9a99  vmovaps [rsp+0x50], xmm5
00007cf1741d9a9f  vmovaps [rsp+0x60], xmm6
00007cf1741d9aa5  vmovaps [rsp+0x70], xmm7
00007cf1741d9aab  vmovaps [rsp+0x80], xmm8
00007cf1741d9ab4  vmovaps [rsp+0x90], xmm10
00007cf1741d9abd  vmovaps [rsp+0xA0], xmm11
00007cf1741d9ac6  vmovaps [rsp+0xB0], xmm12
00007cf1741d9acf  vmovaps [rsp+0xC0], xmm13
00007cf1741d9ad8  vmovaps [rsp+0xD0], xmm14
00007cf1741d9ae1  vmovaps [rsp+0xE0], xmm15
00007cf1741d9aea  sub rsp, 0x30
00007cf1741d9aee  movaps [rsp], xmm9
00007cf1741d9af3  movaps [rsp+0x10], xmm8
00007cf1741d9af9  movaps [rsp+0x20], xmm11
00007cf1741d9aff  lea rdi, [rsp]
00007cf1741d9b03  mov esi, 0x00
00007cf1741d9b08  mov rax, 0x611C8A33A530
00007cf1741d9b12  call rax
00007cf1741d9b14  movaps xmm9, [rsp]
00007cf1741d9b19  add rsp, 0x30
00007cf1741d9b1d  vmovaps xmm0, [rsp]
00007cf1741d9b22  vmovaps xmm1, [rsp+0x10]
00007cf1741d9b28  vmovaps xmm2, [rsp+0x20]
00007cf1741d9b2e  vmovaps xmm3, [rsp+0x30]
00007cf1741d9b34  vmovaps xmm4, [rsp+0x40]
00007cf1741d9b3a  vmovaps xmm5, [rsp+0x50]
00007cf1741d9b40  vmovaps xmm6, [rsp+0x60]
00007cf1741d9b46  vmovaps xmm7, [rsp+0x70]
00007cf1741d9b4c  vmovaps xmm8, [rsp+0x80]
00007cf1741d9b55  vmovaps xmm10, [rsp+0x90]
00007cf1741d9b5e  vmovaps xmm11, [rsp+0xA0]
00007cf1741d9b67  vmovaps xmm12, [rsp+0xB0]
00007cf1741d9b70  vmovaps xmm13, [rsp+0xC0]
00007cf1741d9b79  vmovaps xmm14, [rsp+0xD0]
00007cf1741d9b82  vmovaps xmm15, [rsp+0xE0]
00007cf1741d9b8b  add rsp, 0xF0
00007cf1741d9b92  pop r11
00007cf1741d9b94  pop r10
00007cf1741d9b96  pop r9
00007cf1741d9b98  pop r8
00007cf1741d9b9a  pop rsi
00007cf1741d9b9b  pop rdi
00007cf1741d9b9c  pop rdx
00007cf1741d9b9d  pop rcx
00007cf1741d9b9e  pop rax
00007cf1741d9b9f  add rsp, 0x08
00007cf1741d9ba3  jmp 0x00007CF1741D6352
00007cf1741d9ba8  sub rsp, 0x08
00007cf1741d9bac  push rax
00007cf1741d9bad  push rcx
00007cf1741d9bae  push rdx
00007cf1741d9baf  push rdi
00007cf1741d9bb0  push rsi
00007cf1741d9bb1  push r8
00007cf1741d9bb3  push r9
00007cf1741d9bb5  push r10
00007cf1741d9bb7  push r11
00007cf1741d9bb9  sub rsp, 0xF0
00007cf1741d9bc0  vmovaps [rsp], xmm0
00007cf1741d9bc5  vmovaps [rsp+0x10], xmm1
00007cf1741d9bcb  vmovaps [rsp+0x20], xmm2
00007cf1741d9bd1  vmovaps [rsp+0x30], xmm3
00007cf1741d9bd7  vmovaps [rsp+0x40], xmm4
00007cf1741d9bdd  vmovaps [rsp+0x50], xmm5
00007cf1741d9be3  vmovaps [rsp+0x60], xmm6
00007cf1741d9be9  vmovaps [rsp+0x70], xmm7
00007cf1741d9bef  vmovaps [rsp+0x80], xmm8
00007cf1741d9bf8  vmovaps [rsp+0x90], xmm9
00007cf1741d9c01  vmovaps [rsp+0xA0], xmm10
00007cf1741d9c0a  vmovaps [rsp+0xB0], xmm12
00007cf1741d9c13  vmovaps [rsp+0xC0], xmm13
00007cf1741d9c1c  vmovaps [rsp+0xD0], xmm14
00007cf1741d9c25  vmovaps [rsp+0xE0], xmm15
00007cf1741d9c2e  sub rsp, 0x30
00007cf1741d9c32  movaps [rsp], xmm11
00007cf1741d9c37  movaps [rsp+0x10], xmm10
00007cf1741d9c3d  movaps [rsp+0x20], xmm6
00007cf1741d9c42  lea rdi, [rsp]
00007cf1741d9c46  mov esi, 0x00
00007cf1741d9c4b  mov rax, 0x611C8A33A530
00007cf1741d9c55  call rax
00007cf1741d9c57  movaps xmm11, [rsp]
00007cf1741d9c5c  add rsp, 0x30
00007cf1741d9c60  vmovaps xmm0, [rsp]
00007cf1741d9c65  vmovaps xmm1, [rsp+0x10]
00007cf1741d9c6b  vmovaps xmm2, [rsp+0x20]
00007cf1741d9c71  vmovaps xmm3, [rsp+0x30]
00007cf1741d9c77  vmovaps xmm4, [rsp+0x40]
00007cf1741d9c7d  vmovaps xmm5, [rsp+0x50]
00007cf1741d9c83  vmovaps xmm6, [rsp+0x60]
00007cf1741d9c89  vmovaps xmm7, [rsp+0x70]
00007cf1741d9c8f  vmovaps xmm8, [rsp+0x80]
00007cf1741d9c98  vmovaps xmm9, [rsp+0x90]
00007cf1741d9ca1  vmovaps xmm10, [rsp+0xA0]
00007cf1741d9caa  vmovaps xmm12, [rsp+0xB0]
00007cf1741d9cb3  vmovaps xmm13, [rsp+0xC0]
00007cf1741d9cbc  vmovaps xmm14, [rsp+0xD0]
00007cf1741d9cc5  vmovaps xmm15, [rsp+0xE0]
00007cf1741d9cce  add rsp, 0xF0
00007cf1741d9cd5  pop r11
00007cf1741d9cd7  pop r10
00007cf1741d9cd9  pop r9
00007cf1741d9cdb  pop r8
00007cf1741d9cdd  pop rsi
00007cf1741d9cde  pop rdi
00007cf1741d9cdf  pop rdx
00007cf1741d9ce0  pop rcx
00007cf1741d9ce1  pop rax
00007cf1741d9ce2  add rsp, 0x08
00007cf1741d9ce6  jmp 0x00007CF1741D636D
00007cf1741d9ceb  sub rsp, 0x08
00007cf1741d9cef  push rax
00007cf1741d9cf0  push rcx
00007cf1741d9cf1  push rdx
00007cf1741d9cf2  push rdi
00007cf1741d9cf3  push rsi
00007cf1741d9cf4  push r8
00007cf1741d9cf6  push r9
00007cf1741d9cf8  push r10
00007cf1741d9cfa  push r11
00007cf1741d9cfc  sub rsp, 0xF0
00007cf1741d9d03  vmovaps [rsp], xmm0
00007cf1741d9d08  vmovaps [rsp+0x10], xmm1
00007cf1741d9d0e  vmovaps [rsp+0x20], xmm2
00007cf1741d9d14  vmovaps [rsp+0x30], xmm3
00007cf1741d9d1a  vmovaps [rsp+0x40], xmm4
00007cf1741d9d20  vmovaps [rsp+0x50], xmm5
00007cf1741d9d26  vmovaps [rsp+0x60], xmm6
00007cf1741d9d2c  vmovaps [rsp+0x70], xmm7
00007cf1741d9d32  vmovaps [rsp+0x80], xmm8
00007cf1741d9d3b  vmovaps [rsp+0x90], xmm9
00007cf1741d9d44  vmovaps [rsp+0xA0], xmm11
00007cf1741d9d4d  vmovaps [rsp+0xB0], xmm12
00007cf1741d9d56  vmovaps [rsp+0xC0], xmm13
00007cf1741d9d5f  vmovaps [rsp+0xD0], xmm14
00007cf1741d9d68  vmovaps [rsp+0xE0], xmm15
00007cf1741d9d71  sub rsp, 0x30
00007cf1741d9d75  movaps [rsp], xmm10
00007cf1741d9d7a  movaps [rsp+0x10], xmm14
00007cf1741d9d80  movaps [rsp+0x20], xmm4
00007cf1741d9d85  lea rdi, [rsp]
00007cf1741d9d89  mov esi, 0x00
00007cf1741d9d8e  mov rax, 0x611C8A33A530
00007cf1741d9d98  call rax
00007cf1741d9d9a  movaps xmm10, [rsp]
00007cf1741d9d9f  add rsp, 0x30
00007cf1741d9da3  vmovaps xmm0, [rsp]
00007cf1741d9da8  vmovaps xmm1, [rsp+0x10]
00007cf1741d9dae  vmovaps xmm2, [rsp+0x20]
00007cf1741d9db4  vmovaps xmm3, [rsp+0x30]
00007cf1741d9dba  vmovaps xmm4, [rsp+0x40]
00007cf1741d9dc0  vmovaps xmm5, [rsp+0x50]
00007cf1741d9dc6  vmovaps xmm6, [rsp+0x60]
00007cf1741d9dcc  vmovaps xmm7, [rsp+0x70]
00007cf1741d9dd2  vmovaps xmm8, [rsp+0x80]
00007cf1741d9ddb  vmovaps xmm9, [rsp+0x90]
00007cf1741d9de4  vmovaps xmm11, [rsp+0xA0]
00007cf1741d9ded  vmovaps xmm12, [rsp+0xB0]
00007cf1741d9df6  vmovaps xmm13, [rsp+0xC0]
00007cf1741d9dff  vmovaps xmm14, [rsp+0xD0]
00007cf1741d9e08  vmovaps xmm15, [rsp+0xE0]
00007cf1741d9e11  add rsp, 0xF0
00007cf1741d9e18  pop r11
00007cf1741d9e1a  pop r10
00007cf1741d9e1c  pop r9
00007cf1741d9e1e  pop r8
00007cf1741d9e20  pop rsi
00007cf1741d9e21  pop rdi
00007cf1741d9e22  pop rdx
00007cf1741d9e23  pop rcx
00007cf1741d9e24  pop rax
00007cf1741d9e25  add rsp, 0x08
00007cf1741d9e29  jmp 0x00007CF1741D6388
00007cf1741d9e2e  sub rsp, 0x08
00007cf1741d9e32  push rax
00007cf1741d9e33  push rcx
00007cf1741d9e34  push rdx
00007cf1741d9e35  push rdi
00007cf1741d9e36  push rsi
00007cf1741d9e37  push r8
00007cf1741d9e39  push r9
00007cf1741d9e3b  push r10
00007cf1741d9e3d  push r11
00007cf1741d9e3f  sub rsp, 0xF0
00007cf1741d9e46  vmovaps [rsp], xmm0
00007cf1741d9e4b  vmovaps [rsp+0x10], xmm1
00007cf1741d9e51  vmovaps [rsp+0x20], xmm2
00007cf1741d9e57  vmovaps [rsp+0x30], xmm3
00007cf1741d9e5d  vmovaps [rsp+0x40], xmm4
00007cf1741d9e63  vmovaps [rsp+0x50], xmm5
00007cf1741d9e69  vmovaps [rsp+0x60], xmm6
00007cf1741d9e6f  vmovaps [rsp+0x70], xmm7
00007cf1741d9e75  vmovaps [rsp+0x80], xmm9
00007cf1741d9e7e  vmovaps [rsp+0x90], xmm10
00007cf1741d9e87  vmovaps [rsp+0xA0], xmm11
00007cf1741d9e90  vmovaps [rsp+0xB0], xmm12
00007cf1741d9e99  vmovaps [rsp+0xC0], xmm13
00007cf1741d9ea2  vmovaps [rsp+0xD0], xmm14
00007cf1741d9eab  vmovaps [rsp+0xE0], xmm15
00007cf1741d9eb4  sub rsp, 0x30
00007cf1741d9eb8  movaps [rsp], xmm8
00007cf1741d9ebd  movaps [rsp+0x10], xmm1
00007cf1741d9ec2  movaps [rsp+0x20], xmm14
00007cf1741d9ec8  lea rdi, [rsp]
00007cf1741d9ecc  mov esi, 0x00
00007cf1741d9ed1  mov rax, 0x611C8A33A530
00007cf1741d9edb  call rax
00007cf1741d9edd  movaps xmm8, [rsp]
00007cf1741d9ee2  add rsp, 0x30
00007cf1741d9ee6  vmovaps xmm0, [rsp]
00007cf1741d9eeb  vmovaps xmm1, [rsp+0x10]
00007cf1741d9ef1  vmovaps xmm2, [rsp+0x20]
00007cf1741d9ef7  vmovaps xmm3, [rsp+0x30]
00007cf1741d9efd  vmovaps xmm4, [rsp+0x40]
00007cf1741d9f03  vmovaps xmm5, [rsp+0x50]
00007cf1741d9f09  vmovaps xmm6, [rsp+0x60]
00007cf1741d9f0f  vmovaps xmm7, [rsp+0x70]
00007cf1741d9f15  vmovaps xmm9, [rsp+0x80]
00007cf1741d9f1e  vmovaps xmm10, [rsp+0x90]
00007cf1741d9f27  vmovaps xmm11, [rsp+0xA0]
00007cf1741d9f30  vmovaps xmm12, [rsp+0xB0]
00007cf1741d9f39  vmovaps xmm13, [rsp+0xC0]
00007cf1741d9f42  vmovaps xmm14, [rsp+0xD0]
00007cf1741d9f4b  vmovaps xmm15, [rsp+0xE0]
00007cf1741d9f54  add rsp, 0xF0
00007cf1741d9f5b  pop r11
00007cf1741d9f5d  pop r10
00007cf1741d9f5f  pop r9
00007cf1741d9f61  pop r8
00007cf1741d9f63  pop rsi
00007cf1741d9f64  pop rdi
00007cf1741d9f65  pop rdx
00007cf1741d9f66  pop rcx
00007cf1741d9f67  pop rax
00007cf1741d9f68  add rsp, 0x08
00007cf1741d9f6c  jmp 0x00007CF1741D63AE
00007cf1741d9f71  sub rsp, 0x08
00007cf1741d9f75  push rax
00007cf1741d9f76  push rcx
00007cf1741d9f77  push rdx
00007cf1741d9f78  push rdi
00007cf1741d9f79  push rsi
00007cf1741d9f7a  push r8
00007cf1741d9f7c  push r9
00007cf1741d9f7e  push r10
00007cf1741d9f80  push r11
00007cf1741d9f82  sub rsp, 0xF0
00007cf1741d9f89  vmovaps [rsp], xmm0
00007cf1741d9f8e  vmovaps [rsp+0x10], xmm1
00007cf1741d9f94  vmovaps [rsp+0x20], xmm2
00007cf1741d9f9a  vmovaps [rsp+0x30], xmm3
00007cf1741d9fa0  vmovaps [rsp+0x40], xmm4
00007cf1741d9fa6  vmovaps [rsp+0x50], xmm5
00007cf1741d9fac  vmovaps [rsp+0x60], xmm7
00007cf1741d9fb2  vmovaps [rsp+0x70], xmm8
00007cf1741d9fb8  vmovaps [rsp+0x80], xmm9
00007cf1741d9fc1  vmovaps [rsp+0x90], xmm10
00007cf1741d9fca  vmovaps [rsp+0xA0], xmm11
00007cf1741d9fd3  vmovaps [rsp+0xB0], xmm12
00007cf1741d9fdc  vmovaps [rsp+0xC0], xmm13
00007cf1741d9fe5  vmovaps [rsp+0xD0], xmm14
00007cf1741d9fee  vmovaps [rsp+0xE0], xmm15
00007cf1741d9ff7  sub rsp, 0x30
00007cf1741d9ffb  movaps [rsp], xmm6
00007cf1741d9fff  movaps [rsp+0x10], xmm1
00007cf1741da004  movaps [rsp+0x20], xmm14
00007cf1741da00a  lea rdi, [rsp]
00007cf1741da00e  mov esi, 0x00
00007cf1741da013  mov rax, 0x611C8A33A530
00007cf1741da01d  call rax
00007cf1741da01f  movaps xmm6, [rsp]
00007cf1741da023  add rsp, 0x30
00007cf1741da027  vmovaps xmm0, [rsp]
00007cf1741da02c  vmovaps xmm1, [rsp+0x10]
00007cf1741da032  vmovaps xmm2, [rsp+0x20]
00007cf1741da038  vmovaps xmm3, [rsp+0x30]
00007cf1741da03e  vmovaps xmm4, [rsp+0x40]
00007cf1741da044  vmovaps xmm5, [rsp+0x50]
00007cf1741da04a  vmovaps xmm7, [rsp+0x60]
00007cf1741da050  vmovaps xmm8, [rsp+0x70]
00007cf1741da056  vmovaps xmm9, [rsp+0x80]
00007cf1741da05f  vmovaps xmm10, [rsp+0x90]
00007cf1741da068  vmovaps xmm11, [rsp+0xA0]
00007cf1741da071  vmovaps xmm12, [rsp+0xB0]
00007cf1741da07a  vmovaps xmm13, [rsp+0xC0]
00007cf1741da083  vmovaps xmm14, [rsp+0xD0]
00007cf1741da08c  vmovaps xmm15, [rsp+0xE0]
00007cf1741da095  add rsp, 0xF0
00007cf1741da09c  pop r11
00007cf1741da09e  pop r10
00007cf1741da0a0  pop r9
00007cf1741da0a2  pop r8
00007cf1741da0a4  pop rsi
00007cf1741da0a5  pop rdi
00007cf1741da0a6  pop rdx
00007cf1741da0a7  pop rcx
00007cf1741da0a8  pop rax
00007cf1741da0a9  add rsp, 0x08
00007cf1741da0ad  jmp 0x00007CF1741D63DA
00007cf1741da0b2  sub rsp, 0x08
00007cf1741da0b6  push rax
00007cf1741da0b7  push rcx
00007cf1741da0b8  push rdx
00007cf1741da0b9  push rdi
00007cf1741da0ba  push rsi
00007cf1741da0bb  push r8
00007cf1741da0bd  push r9
00007cf1741da0bf  push r10
00007cf1741da0c1  push r11
00007cf1741da0c3  sub rsp, 0xF0
00007cf1741da0ca  vmovaps [rsp], xmm0
00007cf1741da0cf  vmovaps [rsp+0x10], xmm1
00007cf1741da0d5  vmovaps [rsp+0x20], xmm2
00007cf1741da0db  vmovaps [rsp+0x30], xmm3
00007cf1741da0e1  vmovaps [rsp+0x40], xmm4
00007cf1741da0e7  vmovaps [rsp+0x50], xmm5
00007cf1741da0ed  vmovaps [rsp+0x60], xmm6
00007cf1741da0f3  vmovaps [rsp+0x70], xmm7
00007cf1741da0f9  vmovaps [rsp+0x80], xmm8
00007cf1741da102  vmovaps [rsp+0x90], xmm9
00007cf1741da10b  vmovaps [rsp+0xA0], xmm10
00007cf1741da114  vmovaps [rsp+0xB0], xmm11
00007cf1741da11d  vmovaps [rsp+0xC0], xmm12
00007cf1741da126  vmovaps [rsp+0xD0], xmm13
00007cf1741da12f  vmovaps [rsp+0xE0], xmm15
00007cf1741da138  sub rsp, 0x30
00007cf1741da13c  movaps [rsp], xmm14
00007cf1741da141  movaps [rsp+0x10], xmm12
00007cf1741da147  movaps [rsp+0x20], xmm1
00007cf1741da14c  lea rdi, [rsp]
00007cf1741da150  mov esi, 0x00
00007cf1741da155  mov rax, 0x611C8A33A530
00007cf1741da15f  call rax
00007cf1741da161  movaps xmm14, [rsp]
00007cf1741da166  add rsp, 0x30
00007cf1741da16a  vmovaps xmm0, [rsp]
00007cf1741da16f  vmovaps xmm1, [rsp+0x10]
00007cf1741da175  vmovaps xmm2, [rsp+0x20]
00007cf1741da17b  vmovaps xmm3, [rsp+0x30]
00007cf1741da181  vmovaps xmm4, [rsp+0x40]
00007cf1741da187  vmovaps xmm5, [rsp+0x50]
00007cf1741da18d  vmovaps xmm6, [rsp+0x60]
00007cf1741da193  vmovaps xmm7, [rsp+0x70]
00007cf1741da199  vmovaps xmm8, [rsp+0x80]
00007cf1741da1a2  vmovaps xmm9, [rsp+0x90]
00007cf1741da1ab  vmovaps xmm10, [rsp+0xA0]
00007cf1741da1b4  vmovaps xmm11, [rsp+0xB0]
00007cf1741da1bd  vmovaps xmm12, [rsp+0xC0]
00007cf1741da1c6  vmovaps xmm13, [rsp+0xD0]
00007cf1741da1cf  vmovaps xmm15, [rsp+0xE0]
00007cf1741da1d8  add rsp, 0xF0
00007cf1741da1df  pop r11
00007cf1741da1e1  pop r10
00007cf1741da1e3  pop r9
00007cf1741da1e5  pop r8
00007cf1741da1e7  pop rsi
00007cf1741da1e8  pop rdi
00007cf1741da1e9  pop rdx
00007cf1741da1ea  pop rcx
00007cf1741da1eb  pop rax
00007cf1741da1ec  add rsp, 0x08
00007cf1741da1f0  jmp 0x00007CF1741D6400
00007cf1741da1f5  sub rsp, 0x08
00007cf1741da1f9  push rax
00007cf1741da1fa  push rcx
00007cf1741da1fb  push rdx
00007cf1741da1fc  push rdi
00007cf1741da1fd  push rsi
00007cf1741da1fe  push r8
00007cf1741da200  push r9
00007cf1741da202  push r10
00007cf1741da204  push r11
00007cf1741da206  sub rsp, 0xF0
00007cf1741da20d  vmovaps [rsp], xmm0
00007cf1741da212  vmovaps [rsp+0x10], xmm2
00007cf1741da218  vmovaps [rsp+0x20], xmm3
00007cf1741da21e  vmovaps [rsp+0x30], xmm4
00007cf1741da224  vmovaps [rsp+0x40], xmm5
00007cf1741da22a  vmovaps [rsp+0x50], xmm6
00007cf1741da230  vmovaps [rsp+0x60], xmm7
00007cf1741da236  vmovaps [rsp+0x70], xmm8
00007cf1741da23c  vmovaps [rsp+0x80], xmm9
00007cf1741da245  vmovaps [rsp+0x90], xmm10
00007cf1741da24e  vmovaps [rsp+0xA0], xmm11
00007cf1741da257  vmovaps [rsp+0xB0], xmm12
00007cf1741da260  vmovaps [rsp+0xC0], xmm13
00007cf1741da269  vmovaps [rsp+0xD0], xmm14
00007cf1741da272  vmovaps [rsp+0xE0], xmm15
00007cf1741da27b  sub rsp, 0x30
00007cf1741da27f  movaps [rsp], xmm1
00007cf1741da283  movaps [rsp+0x10], xmm13
00007cf1741da289  movaps [rsp+0x20], xmm9
00007cf1741da28f  lea rdi, [rsp]
00007cf1741da293  mov esi, 0x00
00007cf1741da298  mov rax, 0x611C8A33A530
00007cf1741da2a2  call rax
00007cf1741da2a4  movaps xmm1, [rsp]
00007cf1741da2a8  add rsp, 0x30
00007cf1741da2ac  vmovaps xmm0, [rsp]
00007cf1741da2b1  vmovaps xmm2, [rsp+0x10]
00007cf1741da2b7  vmovaps xmm3, [rsp+0x20]
00007cf1741da2bd  vmovaps xmm4, [rsp+0x30]
00007cf1741da2c3  vmovaps xmm5, [rsp+0x40]
00007cf1741da2c9  vmovaps xmm6, [rsp+0x50]
00007cf1741da2cf  vmovaps xmm7, [rsp+0x60]
00007cf1741da2d5  vmovaps xmm8, [rsp+0x70]
00007cf1741da2db  vmovaps xmm9, [rsp+0x80]
00007cf1741da2e4  vmovaps xmm10, [rsp+0x90]
00007cf1741da2ed  vmovaps xmm11, [rsp+0xA0]
00007cf1741da2f6  vmovaps xmm12, [rsp+0xB0]
00007cf1741da2ff  vmovaps xmm13, [rsp+0xC0]
00007cf1741da308  vmovaps xmm14, [rsp+0xD0]
00007cf1741da311  vmovaps xmm15, [rsp+0xE0]
00007cf1741da31a  add rsp, 0xF0
00007cf1741da321  pop r11
00007cf1741da323  pop r10
00007cf1741da325  pop r9
00007cf1741da327  pop r8
00007cf1741da329  pop rsi
00007cf1741da32a  pop rdi
00007cf1741da32b  pop rdx
00007cf1741da32c  pop rcx
00007cf1741da32d  pop rax
00007cf1741da32e  add rsp, 0x08
00007cf1741da332  jmp 0x00007CF1741D641A
00007cf1741da337  sub rsp, 0x08
00007cf1741da33b  push rax
00007cf1741da33c  push rcx
00007cf1741da33d  push rdx
00007cf1741da33e  push rdi
00007cf1741da33f  push rsi
00007cf1741da340  push r8
00007cf1741da342  push r9
00007cf1741da344  push r10
00007cf1741da346  push r11
00007cf1741da348  sub rsp, 0xF0
00007cf1741da34f  vmovaps [rsp], xmm0
00007cf1741da354  vmovaps [rsp+0x10], xmm1
00007cf1741da35a  vmovaps [rsp+0x20], xmm2
00007cf1741da360  vmovaps [rsp+0x30], xmm3
00007cf1741da366  vmovaps [rsp+0x40], xmm4
00007cf1741da36c  vmovaps [rsp+0x50], xmm5
00007cf1741da372  vmovaps [rsp+0x60], xmm6
00007cf1741da378  vmovaps [rsp+0x70], xmm7
00007cf1741da37e  vmovaps [rsp+0x80], xmm8
00007cf1741da387  vmovaps [rsp+0x90], xmm9
00007cf1741da390  vmovaps [rsp+0xA0], xmm10
00007cf1741da399  vmovaps [rsp+0xB0], xmm11
00007cf1741da3a2  vmovaps [rsp+0xC0], xmm13
00007cf1741da3ab  vmovaps [rsp+0xD0], xmm14
00007cf1741da3b4  vmovaps [rsp+0xE0], xmm15
00007cf1741da3bd  sub rsp, 0x30
00007cf1741da3c1  movaps [rsp], xmm12
00007cf1741da3c6  movaps [rsp+0x10], xmm7
00007cf1741da3cb  movaps [rsp+0x20], xmm13
00007cf1741da3d1  lea rdi, [rsp]
00007cf1741da3d5  mov esi, 0x00
00007cf1741da3da  mov rax, 0x611C8A33A530
00007cf1741da3e4  call rax
00007cf1741da3e6  movaps xmm12, [rsp]
00007cf1741da3eb  add rsp, 0x30
00007cf1741da3ef  vmovaps xmm0, [rsp]
00007cf1741da3f4  vmovaps xmm1, [rsp+0x10]
00007cf1741da3fa  vmovaps xmm2, [rsp+0x20]
00007cf1741da400  vmovaps xmm3, [rsp+0x30]
00007cf1741da406  vmovaps xmm4, [rsp+0x40]
00007cf1741da40c  vmovaps xmm5, [rsp+0x50]
00007cf1741da412  vmovaps xmm6, [rsp+0x60]
00007cf1741da418  vmovaps xmm7, [rsp+0x70]
00007cf1741da41e  vmovaps xmm8, [rsp+0x80]
00007cf1741da427  vmovaps xmm9, [rsp+0x90]
00007cf1741da430  vmovaps xmm10, [rsp+0xA0]
00007cf1741da439  vmovaps xmm11, [rsp+0xB0]
00007cf1741da442  vmovaps xmm13, [rsp+0xC0]
00007cf1741da44b  vmovaps xmm14, [rsp+0xD0]
00007cf1741da454  vmovaps xmm15, [rsp+0xE0]
00007cf1741da45d  add rsp, 0xF0
00007cf1741da464  pop r11
00007cf1741da466  pop r10
00007cf1741da468  pop r9
00007cf1741da46a  pop r8
00007cf1741da46c  pop rsi
00007cf1741da46d  pop rdi
00007cf1741da46e  pop rdx
00007cf1741da46f  pop rcx
00007cf1741da470  pop rax
00007cf1741da471  add rsp, 0x08
00007cf1741da475  jmp 0x00007CF1741D6441
00007cf1741da47a  sub rsp, 0x08
00007cf1741da47e  push rax
00007cf1741da47f  push rcx
00007cf1741da480  push rdx
00007cf1741da481  push rdi
00007cf1741da482  push rsi
00007cf1741da483  push r8
00007cf1741da485  push r9
00007cf1741da487  push r10
00007cf1741da489  push r11
00007cf1741da48b  sub rsp, 0xF0
00007cf1741da492  vmovaps [rsp], xmm0
00007cf1741da497  vmovaps [rsp+0x10], xmm1
00007cf1741da49d  vmovaps [rsp+0x20], xmm2
00007cf1741da4a3  vmovaps [rsp+0x30], xmm3
00007cf1741da4a9  vmovaps [rsp+0x40], xmm4
00007cf1741da4af  vmovaps [rsp+0x50], xmm5
00007cf1741da4b5  vmovaps [rsp+0x60], xmm6
00007cf1741da4bb  vmovaps [rsp+0x70], xmm7
00007cf1741da4c1  vmovaps [rsp+0x80], xmm8
00007cf1741da4ca  vmovaps [rsp+0x90], xmm9
00007cf1741da4d3  vmovaps [rsp+0xA0], xmm10
00007cf1741da4dc  vmovaps [rsp+0xB0], xmm11
00007cf1741da4e5  vmovaps [rsp+0xC0], xmm12
00007cf1741da4ee  vmovaps [rsp+0xD0], xmm14
00007cf1741da4f7  vmovaps [rsp+0xE0], xmm15
00007cf1741da500  sub rsp, 0x30
00007cf1741da504  movaps [rsp], xmm13
00007cf1741da509  movaps [rsp+0x10], xmm15
00007cf1741da50f  movaps [rsp+0x20], xmm8
00007cf1741da515  lea rdi, [rsp]
00007cf1741da519  mov esi, 0x00
00007cf1741da51e  mov rax, 0x611C8A33A530
00007cf1741da528  call rax
00007cf1741da52a  movaps xmm13, [rsp]
00007cf1741da52f  add rsp, 0x30
00007cf1741da533  vmovaps xmm0, [rsp]
00007cf1741da538  vmovaps xmm1, [rsp+0x10]
00007cf1741da53e  vmovaps xmm2, [rsp+0x20]
00007cf1741da544  vmovaps xmm3, [rsp+0x30]
00007cf1741da54a  vmovaps xmm4, [rsp+0x40]
00007cf1741da550  vmovaps xmm5, [rsp+0x50]
00007cf1741da556  vmovaps xmm6, [rsp+0x60]
00007cf1741da55c  vmovaps xmm7, [rsp+0x70]
00007cf1741da562  vmovaps xmm8, [rsp+0x80]
00007cf1741da56b  vmovaps xmm9, [rsp+0x90]
00007cf1741da574  vmovaps xmm10, [rsp+0xA0]
00007cf1741da57d  vmovaps xmm11, [rsp+0xB0]
00007cf1741da586  vmovaps xmm12, [rsp+0xC0]
00007cf1741da58f  vmovaps xmm14, [rsp+0xD0]
00007cf1741da598  vmovaps xmm15, [rsp+0xE0]
00007cf1741da5a1  add rsp, 0xF0
00007cf1741da5a8  pop r11
00007cf1741da5aa  pop r10
00007cf1741da5ac  pop r9
00007cf1741da5ae  pop r8
00007cf1741da5b0  pop rsi
00007cf1741da5b1  pop rdi
00007cf1741da5b2  pop rdx
00007cf1741da5b3  pop rcx
00007cf1741da5b4  pop rax
00007cf1741da5b5  add rsp, 0x08
00007cf1741da5b9  jmp 0x00007CF1741D645C
00007cf1741da5be  sub rsp, 0x08
00007cf1741da5c2  push rax
00007cf1741da5c3  push rcx
00007cf1741da5c4  push rdx
00007cf1741da5c5  push rdi
00007cf1741da5c6  push rsi
00007cf1741da5c7  push r8
00007cf1741da5c9  push r9
00007cf1741da5cb  push r10
00007cf1741da5cd  push r11
00007cf1741da5cf  sub rsp, 0xF0
00007cf1741da5d6  vmovaps [rsp], xmm0
00007cf1741da5db  vmovaps [rsp+0x10], xmm1
00007cf1741da5e1  vmovaps [rsp+0x20], xmm2
00007cf1741da5e7  vmovaps [rsp+0x30], xmm3
00007cf1741da5ed  vmovaps [rsp+0x40], xmm4
00007cf1741da5f3  vmovaps [rsp+0x50], xmm5
00007cf1741da5f9  vmovaps [rsp+0x60], xmm6
00007cf1741da5ff  vmovaps [rsp+0x70], xmm7
00007cf1741da605  vmovaps [rsp+0x80], xmm9
00007cf1741da60e  vmovaps [rsp+0x90], xmm10
00007cf1741da617  vmovaps [rsp+0xA0], xmm11
00007cf1741da620  vmovaps [rsp+0xB0], xmm12
00007cf1741da629  vmovaps [rsp+0xC0], xmm13
00007cf1741da632  vmovaps [rsp+0xD0], xmm14
00007cf1741da63b  vmovaps [rsp+0xE0], xmm15
00007cf1741da644  sub rsp, 0x30
00007cf1741da648  movaps [rsp], xmm8
00007cf1741da64d  movaps [rsp+0x10], xmm15
00007cf1741da653  movaps [rsp+0x20], xmm9
00007cf1741da659  lea rdi, [rsp]
00007cf1741da65d  mov esi, 0x00
00007cf1741da662  mov rax, 0x611C8A33A530
00007cf1741da66c  call rax
00007cf1741da66e  movaps xmm8, [rsp]
00007cf1741da673  add rsp, 0x30
00007cf1741da677  vmovaps xmm0, [rsp]
00007cf1741da67c  vmovaps xmm1, [rsp+0x10]
00007cf1741da682  vmovaps xmm2, [rsp+0x20]
00007cf1741da688  vmovaps xmm3, [rsp+0x30]
00007cf1741da68e  vmovaps xmm4, [rsp+0x40]
00007cf1741da694  vmovaps xmm5, [rsp+0x50]
00007cf1741da69a  vmovaps xmm6, [rsp+0x60]
00007cf1741da6a0  vmovaps xmm7, [rsp+0x70]
00007cf1741da6a6  vmovaps xmm9, [rsp+0x80]
00007cf1741da6af  vmovaps xmm10, [rsp+0x90]
00007cf1741da6b8  vmovaps xmm11, [rsp+0xA0]
00007cf1741da6c1  vmovaps xmm12, [rsp+0xB0]
00007cf1741da6ca  vmovaps xmm13, [rsp+0xC0]
00007cf1741da6d3  vmovaps xmm14, [rsp+0xD0]
00007cf1741da6dc  vmovaps xmm15, [rsp+0xE0]
00007cf1741da6e5  add rsp, 0xF0
00007cf1741da6ec  pop r11
00007cf1741da6ee  pop r10
00007cf1741da6f0  pop r9
00007cf1741da6f2  pop r8
00007cf1741da6f4  pop rsi
00007cf1741da6f5  pop rdi
00007cf1741da6f6  pop rdx
00007cf1741da6f7  pop rcx
00007cf1741da6f8  pop rax
00007cf1741da6f9  add rsp, 0x08
00007cf1741da6fd  jmp 0x00007CF1741D648A
00007cf1741da702  sub rsp, 0x08
00007cf1741da706  push rax
00007cf1741da707  push rcx
00007cf1741da708  push rdx
00007cf1741da709  push rdi
00007cf1741da70a  push rsi
00007cf1741da70b  push r8
00007cf1741da70d  push r9
00007cf1741da70f  push r10
00007cf1741da711  push r11
00007cf1741da713  sub rsp, 0xF0
00007cf1741da71a  vmovaps [rsp], xmm0
00007cf1741da71f  vmovaps [rsp+0x10], xmm1
00007cf1741da725  vmovaps [rsp+0x20], xmm2
00007cf1741da72b  vmovaps [rsp+0x30], xmm3
00007cf1741da731  vmovaps [rsp+0x40], xmm4
00007cf1741da737  vmovaps [rsp+0x50], xmm5
00007cf1741da73d  vmovaps [rsp+0x60], xmm6
00007cf1741da743  vmovaps [rsp+0x70], xmm7
00007cf1741da749  vmovaps [rsp+0x80], xmm8
00007cf1741da752  vmovaps [rsp+0x90], xmm9
00007cf1741da75b  vmovaps [rsp+0xA0], xmm10
00007cf1741da764  vmovaps [rsp+0xB0], xmm11
00007cf1741da76d  vmovaps [rsp+0xC0], xmm12
00007cf1741da776  vmovaps [rsp+0xD0], xmm13
00007cf1741da77f  vmovaps [rsp+0xE0], xmm14
00007cf1741da788  sub rsp, 0x30
00007cf1741da78c  movaps [rsp], xmm15
00007cf1741da791  movaps [rsp+0x10], xmm11
00007cf1741da797  movaps [rsp+0x20], xmm6
00007cf1741da79c  lea rdi, [rsp]
00007cf1741da7a0  mov esi, 0x00
00007cf1741da7a5  mov rax, 0x611C8A33A530
00007cf1741da7af  call rax
00007cf1741da7b1  movaps xmm15, [rsp]
00007cf1741da7b6  add rsp, 0x30
00007cf1741da7ba  vmovaps xmm0, [rsp]
00007cf1741da7bf  vmovaps xmm1, [rsp+0x10]
00007cf1741da7c5  vmovaps xmm2, [rsp+0x20]
00007cf1741da7cb  vmovaps xmm3, [rsp+0x30]
00007cf1741da7d1  vmovaps xmm4, [rsp+0x40]
00007cf1741da7d7  vmovaps xmm5, [rsp+0x50]
00007cf1741da7dd  vmovaps xmm6, [rsp+0x60]
00007cf1741da7e3  vmovaps xmm7, [rsp+0x70]
00007cf1741da7e9  vmovaps xmm8, [rsp+0x80]
00007cf1741da7f2  vmovaps xmm9, [rsp+0x90]
00007cf1741da7fb  vmovaps xmm10, [rsp+0xA0]
00007cf1741da804  vmovaps xmm11, [rsp+0xB0]
00007cf1741da80d  vmovaps xmm12, [rsp+0xC0]
00007cf1741da816  vmovaps xmm13, [rsp+0xD0]
00007cf1741da81f  vmovaps xmm14, [rsp+0xE0]
00007cf1741da828  add rsp, 0xF0
00007cf1741da82f  pop r11
00007cf1741da831  pop r10
00007cf1741da833  pop r9
00007cf1741da835  pop r8
00007cf1741da837  pop rsi
00007cf1741da838  pop rdi
00007cf1741da839  pop rdx
00007cf1741da83a  pop rcx
00007cf1741da83b  pop rax
00007cf1741da83c  add rsp, 0x08
00007cf1741da840  jmp 0x00007CF1741D64A5
00007cf1741da845  sub rsp, 0x08
00007cf1741da849  push rax
00007cf1741da84a  push rcx
00007cf1741da84b  push rdx
00007cf1741da84c  push rdi
00007cf1741da84d  push rsi
00007cf1741da84e  push r8
00007cf1741da850  push r9
00007cf1741da852  push r10
00007cf1741da854  push r11
00007cf1741da856  sub rsp, 0xF0
00007cf1741da85d  vmovaps [rsp], xmm0
00007cf1741da862  vmovaps [rsp+0x10], xmm1
00007cf1741da868  vmovaps [rsp+0x20], xmm2
00007cf1741da86e  vmovaps [rsp+0x30], xmm3
00007cf1741da874  vmovaps [rsp+0x40], xmm4
00007cf1741da87a  vmovaps [rsp+0x50], xmm5
00007cf1741da880  vmovaps [rsp+0x60], xmm6
00007cf1741da886  vmovaps [rsp+0x70], xmm8
00007cf1741da88c  vmovaps [rsp+0x80], xmm9
00007cf1741da895  vmovaps [rsp+0x90], xmm10
00007cf1741da89e  vmovaps [rsp+0xA0], xmm11
00007cf1741da8a7  vmovaps [rsp+0xB0], xmm12
00007cf1741da8b0  vmovaps [rsp+0xC0], xmm13
00007cf1741da8b9  vmovaps [rsp+0xD0], xmm14
00007cf1741da8c2  vmovaps [rsp+0xE0], xmm15
00007cf1741da8cb  sub rsp, 0x30
00007cf1741da8cf  movaps [rsp], xmm7
00007cf1741da8d3  movaps [rsp+0x10], xmm11
00007cf1741da8d9  movaps [rsp+0x20], xmm9
00007cf1741da8df  lea rdi, [rsp]
00007cf1741da8e3  mov esi, 0x00
00007cf1741da8e8  mov rax, 0x611C8A33A530
00007cf1741da8f2  call rax
00007cf1741da8f4  movaps xmm7, [rsp]
00007cf1741da8f8  add rsp, 0x30
00007cf1741da8fc  vmovaps xmm0, [rsp]
00007cf1741da901  vmovaps xmm1, [rsp+0x10]
00007cf1741da907  vmovaps xmm2, [rsp+0x20]
00007cf1741da90d  vmovaps xmm3, [rsp+0x30]
00007cf1741da913  vmovaps xmm4, [rsp+0x40]
00007cf1741da919  vmovaps xmm5, [rsp+0x50]
00007cf1741da91f  vmovaps xmm6, [rsp+0x60]
00007cf1741da925  vmovaps xmm8, [rsp+0x70]
00007cf1741da92b  vmovaps xmm9, [rsp+0x80]
00007cf1741da934  vmovaps xmm10, [rsp+0x90]
00007cf1741da93d  vmovaps xmm11, [rsp+0xA0]
00007cf1741da946  vmovaps xmm12, [rsp+0xB0]
00007cf1741da94f  vmovaps xmm13, [rsp+0xC0]
00007cf1741da958  vmovaps xmm14, [rsp+0xD0]
00007cf1741da961  vmovaps xmm15, [rsp+0xE0]
00007cf1741da96a  add rsp, 0xF0
00007cf1741da971  pop r11
00007cf1741da973  pop r10
00007cf1741da975  pop r9
00007cf1741da977  pop r8
00007cf1741da979  pop rsi
00007cf1741da97a  pop rdi
00007cf1741da97b  pop rdx
00007cf1741da97c  pop rcx
00007cf1741da97d  pop rax
00007cf1741da97e  add rsp, 0x08
00007cf1741da982  jmp 0x00007CF1741D64D2
00007cf1741da987  sub rsp, 0x08
00007cf1741da98b  push rax
00007cf1741da98c  push rcx
00007cf1741da98d  push rdx
00007cf1741da98e  push rdi
00007cf1741da98f  push rsi
00007cf1741da990  push r8
00007cf1741da992  push r9
00007cf1741da994  push r10
00007cf1741da996  push r11
00007cf1741da998  sub rsp, 0xF0
00007cf1741da99f  vmovaps [rsp], xmm0
00007cf1741da9a4  vmovaps [rsp+0x10], xmm1
00007cf1741da9aa  vmovaps [rsp+0x20], xmm2
00007cf1741da9b0  vmovaps [rsp+0x30], xmm3
00007cf1741da9b6  vmovaps [rsp+0x40], xmm4
00007cf1741da9bc  vmovaps [rsp+0x50], xmm5
00007cf1741da9c2  vmovaps [rsp+0x60], xmm6
00007cf1741da9c8  vmovaps [rsp+0x70], xmm7
00007cf1741da9ce  vmovaps [rsp+0x80], xmm8
00007cf1741da9d7  vmovaps [rsp+0x90], xmm9
00007cf1741da9e0  vmovaps [rsp+0xA0], xmm10
00007cf1741da9e9  vmovaps [rsp+0xB0], xmm12
00007cf1741da9f2  vmovaps [rsp+0xC0], xmm13
00007cf1741da9fb  vmovaps [rsp+0xD0], xmm14
00007cf1741daa04  vmovaps [rsp+0xE0], xmm15
00007cf1741daa0d  sub rsp, 0x30
00007cf1741daa11  movaps [rsp], xmm11
00007cf1741daa16  movaps [rsp+0x10], xmm10
00007cf1741daa1c  movaps [rsp+0x20], xmm14
00007cf1741daa22  lea rdi, [rsp]
00007cf1741daa26  mov esi, 0x00
00007cf1741daa2b  mov rax, 0x611C8A33A530
00007cf1741daa35  call rax
00007cf1741daa37  movaps xmm11, [rsp]
00007cf1741daa3c  add rsp, 0x30
00007cf1741daa40  vmovaps xmm0, [rsp]
00007cf1741daa45  vmovaps xmm1, [rsp+0x10]
00007cf1741daa4b  vmovaps xmm2, [rsp+0x20]
00007cf1741daa51  vmovaps xmm3, [rsp+0x30]
00007cf1741daa57  vmovaps xmm4, [rsp+0x40]
00007cf1741daa5d  vmovaps xmm5, [rsp+0x50]
00007cf1741daa63  vmovaps xmm6, [rsp+0x60]
00007cf1741daa69  vmovaps xmm7, [rsp+0x70]
00007cf1741daa6f  vmovaps xmm8, [rsp+0x80]
00007cf1741daa78  vmovaps xmm9, [rsp+0x90]
00007cf1741daa81  vmovaps xmm10, [rsp+0xA0]
00007cf1741daa8a  vmovaps xmm12, [rsp+0xB0]
00007cf1741daa93  vmovaps xmm13, [rsp+0xC0]
00007cf1741daa9c  vmovaps xmm14, [rsp+0xD0]
00007cf1741daaa5  vmovaps xmm15, [rsp+0xE0]
00007cf1741daaae  add rsp, 0xF0
00007cf1741daab5  pop r11
00007cf1741daab7  pop r10
00007cf1741daab9  pop r9
00007cf1741daabb  pop r8
00007cf1741daabd  pop rsi
00007cf1741daabe  pop rdi
00007cf1741daabf  pop rdx
00007cf1741daac0  pop rcx
00007cf1741daac1  pop rax
00007cf1741daac2  add rsp, 0x08
00007cf1741daac6  jmp 0x00007CF1741D64ED
00007cf1741daacb  call 0x00007CF1740E45A0
00007cf1741daad0  jmp 0x00007CF1741D64F7
00007cf1741daad5  sub rsp, 0x08
00007cf1741daad9  push rax
00007cf1741daada  push rcx
00007cf1741daadb  push rdx
00007cf1741daadc  push rdi
00007cf1741daadd  push rsi
00007cf1741daade  push r8
00007cf1741daae0  push r9
00007cf1741daae2  push r10
00007cf1741daae4  push r11
00007cf1741daae6  sub rsp, 0xF0
00007cf1741daaed  vmovaps [rsp], xmm0
00007cf1741daaf2  vmovaps [rsp+0x10], xmm1
00007cf1741daaf8  vmovaps [rsp+0x20], xmm2
00007cf1741daafe  vmovaps [rsp+0x30], xmm3
00007cf1741dab04  vmovaps [rsp+0x40], xmm4
00007cf1741dab0a  vmovaps [rsp+0x50], xmm5
00007cf1741dab10  vmovaps [rsp+0x60], xmm6
00007cf1741dab16  vmovaps [rsp+0x70], xmm7
00007cf1741dab1c  vmovaps [rsp+0x80], xmm8
00007cf1741dab25  vmovaps [rsp+0x90], xmm9
00007cf1741dab2e  vmovaps [rsp+0xA0], xmm11
00007cf1741dab37  vmovaps [rsp+0xB0], xmm12
00007cf1741dab40  vmovaps [rsp+0xC0], xmm13
00007cf1741dab49  vmovaps [rsp+0xD0], xmm14
00007cf1741dab52  vmovaps [rsp+0xE0], xmm15
00007cf1741dab5b  sub rsp, 0x30
00007cf1741dab5f  movaps [rsp], xmm10
00007cf1741dab64  movaps [rsp+0x10], xmm1
00007cf1741dab69  movaps [rsp+0x20], xmm12
00007cf1741dab6f  lea rdi, [rsp]
00007cf1741dab73  mov esi, 0x00
00007cf1741dab78  mov rax, 0x611C8A33A530
00007cf1741dab82  call rax
00007cf1741dab84  movaps xmm10, [rsp]
00007cf1741dab89  add rsp, 0x30
00007cf1741dab8d  vmovaps xmm0, [rsp]
00007cf1741dab92  vmovaps xmm1, [rsp+0x10]
00007cf1741dab98  vmovaps xmm2, [rsp+0x20]
00007cf1741dab9e  vmovaps xmm3, [rsp+0x30]
00007cf1741daba4  vmovaps xmm4, [rsp+0x40]
00007cf1741dabaa  vmovaps xmm5, [rsp+0x50]
00007cf1741dabb0  vmovaps xmm6, [rsp+0x60]
00007cf1741dabb6  vmovaps xmm7, [rsp+0x70]
00007cf1741dabbc  vmovaps xmm8, [rsp+0x80]
00007cf1741dabc5  vmovaps xmm9, [rsp+0x90]
00007cf1741dabce  vmovaps xmm11, [rsp+0xA0]
00007cf1741dabd7  vmovaps xmm12, [rsp+0xB0]
00007cf1741dabe0  vmovaps xmm13, [rsp+0xC0]
00007cf1741dabe9  vmovaps xmm14, [rsp+0xD0]
00007cf1741dabf2  vmovaps xmm15, [rsp+0xE0]
00007cf1741dabfb  add rsp, 0xF0
00007cf1741dac02  pop r11
00007cf1741dac04  pop r10
00007cf1741dac06  pop r9
00007cf1741dac08  pop r8
00007cf1741dac0a  pop rsi
00007cf1741dac0b  pop rdi
00007cf1741dac0c  pop rdx
00007cf1741dac0d  pop rcx
00007cf1741dac0e  pop rax
00007cf1741dac0f  add rsp, 0x08
00007cf1741dac13  jmp 0x00007CF1741D651A
00007cf1741dac18  sub rsp, 0x08
00007cf1741dac1c  push rax
00007cf1741dac1d  push rcx
00007cf1741dac1e  push rdx
00007cf1741dac1f  push rdi
00007cf1741dac20  push rsi
00007cf1741dac21  push r8
00007cf1741dac23  push r9
00007cf1741dac25  push r10
00007cf1741dac27  push r11
00007cf1741dac29  sub rsp, 0xF0
00007cf1741dac30  vmovaps [rsp], xmm0
00007cf1741dac35  vmovaps [rsp+0x10], xmm1
00007cf1741dac3b  vmovaps [rsp+0x20], xmm2
00007cf1741dac41  vmovaps [rsp+0x30], xmm3
00007cf1741dac47  vmovaps [rsp+0x40], xmm4
00007cf1741dac4d  vmovaps [rsp+0x50], xmm5
00007cf1741dac53  vmovaps [rsp+0x60], xmm6
00007cf1741dac59  vmovaps [rsp+0x70], xmm7
00007cf1741dac5f  vmovaps [rsp+0x80], xmm8
00007cf1741dac68  vmovaps [rsp+0x90], xmm9
00007cf1741dac71  vmovaps [rsp+0xA0], xmm10
00007cf1741dac7a  vmovaps [rsp+0xB0], xmm11
00007cf1741dac83  vmovaps [rsp+0xC0], xmm13
00007cf1741dac8c  vmovaps [rsp+0xD0], xmm14
00007cf1741dac95  vmovaps [rsp+0xE0], xmm15
00007cf1741dac9e  sub rsp, 0x30
00007cf1741daca2  movaps [rsp], xmm12
00007cf1741daca7  movaps [rsp+0x10], xmm14
00007cf1741dacad  movaps [rsp+0x20], xmm1
00007cf1741dacb2  lea rdi, [rsp]
00007cf1741dacb6  mov esi, 0x00
00007cf1741dacbb  mov rax, 0x611C8A33A530
00007cf1741dacc5  call rax
00007cf1741dacc7  movaps xmm12, [rsp]
00007cf1741daccc  add rsp, 0x30
00007cf1741dacd0  vmovaps xmm0, [rsp]
00007cf1741dacd5  vmovaps xmm1, [rsp+0x10]
00007cf1741dacdb  vmovaps xmm2, [rsp+0x20]
00007cf1741dace1  vmovaps xmm3, [rsp+0x30]
00007cf1741dace7  vmovaps xmm4, [rsp+0x40]
00007cf1741daced  vmovaps xmm5, [rsp+0x50]
00007cf1741dacf3  vmovaps xmm6, [rsp+0x60]
00007cf1741dacf9  vmovaps xmm7, [rsp+0x70]
00007cf1741dacff  vmovaps xmm8, [rsp+0x80]
00007cf1741dad08  vmovaps xmm9, [rsp+0x90]
00007cf1741dad11  vmovaps xmm10, [rsp+0xA0]
00007cf1741dad1a  vmovaps xmm11, [rsp+0xB0]
00007cf1741dad23  vmovaps xmm13, [rsp+0xC0]
00007cf1741dad2c  vmovaps xmm14, [rsp+0xD0]
00007cf1741dad35  vmovaps xmm15, [rsp+0xE0]
00007cf1741dad3e  add rsp, 0xF0
00007cf1741dad45  pop r11
00007cf1741dad47  pop r10
00007cf1741dad49  pop r9
00007cf1741dad4b  pop r8
00007cf1741dad4d  pop rsi
00007cf1741dad4e  pop rdi
00007cf1741dad4f  pop rdx
00007cf1741dad50  pop rcx
00007cf1741dad51  pop rax
00007cf1741dad52  add rsp, 0x08
00007cf1741dad56  jmp 0x00007CF1741D6549
00007cf1741dad5b  sub rsp, 0x08
00007cf1741dad5f  push rax
00007cf1741dad60  push rcx
00007cf1741dad61  push rdx
00007cf1741dad62  push rdi
00007cf1741dad63  push rsi
00007cf1741dad64  push r8
00007cf1741dad66  push r9
00007cf1741dad68  push r10
00007cf1741dad6a  push r11
00007cf1741dad6c  sub rsp, 0xF0
00007cf1741dad73  vmovaps [rsp], xmm0
00007cf1741dad78  vmovaps [rsp+0x10], xmm1
00007cf1741dad7e  vmovaps [rsp+0x20], xmm2
00007cf1741dad84  vmovaps [rsp+0x30], xmm3
00007cf1741dad8a  vmovaps [rsp+0x40], xmm4
00007cf1741dad90  vmovaps [rsp+0x50], xmm5
00007cf1741dad96  vmovaps [rsp+0x60], xmm6
00007cf1741dad9c  vmovaps [rsp+0x70], xmm7
00007cf1741dada2  vmovaps [rsp+0x80], xmm8
00007cf1741dadab  vmovaps [rsp+0x90], xmm9
00007cf1741dadb4  vmovaps [rsp+0xA0], xmm10
00007cf1741dadbd  vmovaps [rsp+0xB0], xmm11
00007cf1741dadc6  vmovaps [rsp+0xC0], xmm12
00007cf1741dadcf  vmovaps [rsp+0xD0], xmm13
00007cf1741dadd8  vmovaps [rsp+0xE0], xmm15
00007cf1741dade1  sub rsp, 0x30
00007cf1741dade5  movaps [rsp], xmm14
00007cf1741dadea  movaps [rsp+0x10], xmm9
00007cf1741dadf0  movaps [rsp+0x20], xmm1
00007cf1741dadf5  lea rdi, [rsp]
00007cf1741dadf9  mov esi, 0x00
00007cf1741dadfe  mov rax, 0x611C8A33A530
00007cf1741dae08  call rax
00007cf1741dae0a  movaps xmm14, [rsp]
00007cf1741dae0f  add rsp, 0x30
00007cf1741dae13  vmovaps xmm0, [rsp]
00007cf1741dae18  vmovaps xmm1, [rsp+0x10]
00007cf1741dae1e  vmovaps xmm2, [rsp+0x20]
00007cf1741dae24  vmovaps xmm3, [rsp+0x30]
00007cf1741dae2a  vmovaps xmm4, [rsp+0x40]
00007cf1741dae30  vmovaps xmm5, [rsp+0x50]
00007cf1741dae36  vmovaps xmm6, [rsp+0x60]
00007cf1741dae3c  vmovaps xmm7, [rsp+0x70]
00007cf1741dae42  vmovaps xmm8, [rsp+0x80]
00007cf1741dae4b  vmovaps xmm9, [rsp+0x90]
00007cf1741dae54  vmovaps xmm10, [rsp+0xA0]
00007cf1741dae5d  vmovaps xmm11, [rsp+0xB0]
00007cf1741dae66  vmovaps xmm12, [rsp+0xC0]
00007cf1741dae6f  vmovaps xmm13, [rsp+0xD0]
00007cf1741dae78  vmovaps xmm15, [rsp+0xE0]
00007cf1741dae81  add rsp, 0xF0
00007cf1741dae88  pop r11
00007cf1741dae8a  pop r10
00007cf1741dae8c  pop r9
00007cf1741dae8e  pop r8
00007cf1741dae90  pop rsi
00007cf1741dae91  pop rdi
00007cf1741dae92  pop rdx
00007cf1741dae93  pop rcx
00007cf1741dae94  pop rax
00007cf1741dae95  add rsp, 0x08
00007cf1741dae99  jmp 0x00007CF1741D6578
00007cf1741dae9e  sub rsp, 0x08
00007cf1741daea2  push rax
00007cf1741daea3  push rcx
00007cf1741daea4  push rdx
00007cf1741daea5  push rdi
00007cf1741daea6  push rsi
00007cf1741daea7  push r8
00007cf1741daea9  push r9
00007cf1741daeab  push r10
00007cf1741daead  push r11
00007cf1741daeaf  sub rsp, 0xF0
00007cf1741daeb6  vmovaps [rsp], xmm0
00007cf1741daebb  vmovaps [rsp+0x10], xmm2
00007cf1741daec1  vmovaps [rsp+0x20], xmm3
00007cf1741daec7  vmovaps [rsp+0x30], xmm4
00007cf1741daecd  vmovaps [rsp+0x40], xmm5
00007cf1741daed3  vmovaps [rsp+0x50], xmm6
00007cf1741daed9  vmovaps [rsp+0x60], xmm7
00007cf1741daedf  vmovaps [rsp+0x70], xmm8
00007cf1741daee5  vmovaps [rsp+0x80], xmm9
00007cf1741daeee  vmovaps [rsp+0x90], xmm10
00007cf1741daef7  vmovaps [rsp+0xA0], xmm11
00007cf1741daf00  vmovaps [rsp+0xB0], xmm12
00007cf1741daf09  vmovaps [rsp+0xC0], xmm13
00007cf1741daf12  vmovaps [rsp+0xD0], xmm14
00007cf1741daf1b  vmovaps [rsp+0xE0], xmm15
00007cf1741daf24  sub rsp, 0x30
00007cf1741daf28  movaps [rsp], xmm1
00007cf1741daf2c  movaps [rsp+0x10], xmm13
00007cf1741daf32  movaps [rsp+0x20], xmm8
00007cf1741daf38  lea rdi, [rsp]
00007cf1741daf3c  mov esi, 0x00
00007cf1741daf41  mov rax, 0x611C8A33A530
00007cf1741daf4b  call rax
00007cf1741daf4d  movaps xmm1, [rsp]
00007cf1741daf51  add rsp, 0x30
00007cf1741daf55  vmovaps xmm0, [rsp]
00007cf1741daf5a  vmovaps xmm2, [rsp+0x10]
00007cf1741daf60  vmovaps xmm3, [rsp+0x20]
00007cf1741daf66  vmovaps xmm4, [rsp+0x30]
00007cf1741daf6c  vmovaps xmm5, [rsp+0x40]
00007cf1741daf72  vmovaps xmm6, [rsp+0x50]
00007cf1741daf78  vmovaps xmm7, [rsp+0x60]
00007cf1741daf7e  vmovaps xmm8, [rsp+0x70]
00007cf1741daf84  vmovaps xmm9, [rsp+0x80]
00007cf1741daf8d  vmovaps xmm10, [rsp+0x90]
00007cf1741daf96  vmovaps xmm11, [rsp+0xA0]
00007cf1741daf9f  vmovaps xmm12, [rsp+0xB0]
00007cf1741dafa8  vmovaps xmm13, [rsp+0xC0]
00007cf1741dafb1  vmovaps xmm14, [rsp+0xD0]
00007cf1741dafba  vmovaps xmm15, [rsp+0xE0]
00007cf1741dafc3  add rsp, 0xF0
00007cf1741dafca  pop r11
00007cf1741dafcc  pop r10
00007cf1741dafce  pop r9
00007cf1741dafd0  pop r8
00007cf1741dafd2  pop rsi
00007cf1741dafd3  pop rdi
00007cf1741dafd4  pop rdx
00007cf1741dafd5  pop rcx
00007cf1741dafd6  pop rax
00007cf1741dafd7  add rsp, 0x08
00007cf1741dafdb  jmp 0x00007CF1741D659A
00007cf1741dafe0  call 0x00007CF17400C260
00007cf1741dafe5  jmp 0x00007CF1741D65A8
00007cf1741dafea  call 0x00007CF1740DE950
00007cf1741dafef  jmp 0x00007CF1741D65B2
00007cf1741daff4  sub rsp, 0x08
00007cf1741daff8  push rax
00007cf1741daff9  push rcx
00007cf1741daffa  push rdx
00007cf1741daffb  push rdi
00007cf1741daffc  push rsi
00007cf1741daffd  push r8
00007cf1741dafff  push r9
00007cf1741db001  push r10
00007cf1741db003  push r11
00007cf1741db005  sub rsp, 0xF0
00007cf1741db00c  vmovaps [rsp], xmm0
00007cf1741db011  vmovaps [rsp+0x10], xmm1
00007cf1741db017  vmovaps [rsp+0x20], xmm2
00007cf1741db01d  vmovaps [rsp+0x30], xmm3
00007cf1741db023  vmovaps [rsp+0x40], xmm4
00007cf1741db029  vmovaps [rsp+0x50], xmm5
00007cf1741db02f  vmovaps [rsp+0x60], xmm6
00007cf1741db035  vmovaps [rsp+0x70], xmm7
00007cf1741db03b  vmovaps [rsp+0x80], xmm9
00007cf1741db044  vmovaps [rsp+0x90], xmm10
00007cf1741db04d  vmovaps [rsp+0xA0], xmm11
00007cf1741db056  vmovaps [rsp+0xB0], xmm12
00007cf1741db05f  vmovaps [rsp+0xC0], xmm13
00007cf1741db068  vmovaps [rsp+0xD0], xmm14
00007cf1741db071  vmovaps [rsp+0xE0], xmm15
00007cf1741db07a  sub rsp, 0x30
00007cf1741db07e  movaps [rsp], xmm8
00007cf1741db083  movaps [rsp+0x10], xmm15
00007cf1741db089  movaps [rsp+0x20], xmm7
00007cf1741db08e  lea rdi, [rsp]
00007cf1741db092  mov esi, 0x00
00007cf1741db097  mov rax, 0x611C8A33A530
00007cf1741db0a1  call rax
00007cf1741db0a3  movaps xmm8, [rsp]
00007cf1741db0a8  add rsp, 0x30
00007cf1741db0ac  vmovaps xmm0, [rsp]
00007cf1741db0b1  vmovaps xmm1, [rsp+0x10]
00007cf1741db0b7  vmovaps xmm2, [rsp+0x20]
00007cf1741db0bd  vmovaps xmm3, [rsp+0x30]
00007cf1741db0c3  vmovaps xmm4, [rsp+0x40]
00007cf1741db0c9  vmovaps xmm5, [rsp+0x50]
00007cf1741db0cf  vmovaps xmm6, [rsp+0x60]
00007cf1741db0d5  vmovaps xmm7, [rsp+0x70]
00007cf1741db0db  vmovaps xmm9, [rsp+0x80]
00007cf1741db0e4  vmovaps xmm10, [rsp+0x90]
00007cf1741db0ed  vmovaps xmm11, [rsp+0xA0]
00007cf1741db0f6  vmovaps xmm12, [rsp+0xB0]
00007cf1741db0ff  vmovaps xmm13, [rsp+0xC0]
00007cf1741db108  vmovaps xmm14, [rsp+0xD0]
00007cf1741db111  vmovaps xmm15, [rsp+0xE0]
00007cf1741db11a  add rsp, 0xF0
00007cf1741db121  pop r11
00007cf1741db123  pop r10
00007cf1741db125  pop r9
00007cf1741db127  pop r8
00007cf1741db129  pop rsi
00007cf1741db12a  pop rdi
00007cf1741db12b  pop rdx
00007cf1741db12c  pop rcx
00007cf1741db12d  pop rax
00007cf1741db12e  add rsp, 0x08
00007cf1741db132  jmp 0x00007CF1741D65D4
00007cf1741db137  sub rsp, 0x08
00007cf1741db13b  push rax
00007cf1741db13c  push rcx
00007cf1741db13d  push rdx
00007cf1741db13e  push rdi
00007cf1741db13f  push rsi
00007cf1741db140  push r8
00007cf1741db142  push r9
00007cf1741db144  push r10
00007cf1741db146  push r11
00007cf1741db148  sub rsp, 0xF0
00007cf1741db14f  vmovaps [rsp], xmm0
00007cf1741db154  vmovaps [rsp+0x10], xmm1
00007cf1741db15a  vmovaps [rsp+0x20], xmm2
00007cf1741db160  vmovaps [rsp+0x30], xmm3
00007cf1741db166  vmovaps [rsp+0x40], xmm4
00007cf1741db16c  vmovaps [rsp+0x50], xmm5
00007cf1741db172  vmovaps [rsp+0x60], xmm6
00007cf1741db178  vmovaps [rsp+0x70], xmm8
00007cf1741db17e  vmovaps [rsp+0x80], xmm9
00007cf1741db187  vmovaps [rsp+0x90], xmm10
00007cf1741db190  vmovaps [rsp+0xA0], xmm11
00007cf1741db199  vmovaps [rsp+0xB0], xmm12
00007cf1741db1a2  vmovaps [rsp+0xC0], xmm13
00007cf1741db1ab  vmovaps [rsp+0xD0], xmm14
00007cf1741db1b4  vmovaps [rsp+0xE0], xmm15
00007cf1741db1bd  sub rsp, 0x30
00007cf1741db1c1  movaps [rsp], xmm7
00007cf1741db1c5  movaps [rsp+0x10], xmm9
00007cf1741db1cb  movaps [rsp+0x20], xmm15
00007cf1741db1d1  lea rdi, [rsp]
00007cf1741db1d5  mov esi, 0x00
00007cf1741db1da  mov rax, 0x611C8A33A530
00007cf1741db1e4  call rax
00007cf1741db1e6  movaps xmm7, [rsp]
00007cf1741db1ea  add rsp, 0x30
00007cf1741db1ee  vmovaps xmm0, [rsp]
00007cf1741db1f3  vmovaps xmm1, [rsp+0x10]
00007cf1741db1f9  vmovaps xmm2, [rsp+0x20]
00007cf1741db1ff  vmovaps xmm3, [rsp+0x30]
00007cf1741db205  vmovaps xmm4, [rsp+0x40]
00007cf1741db20b  vmovaps xmm5, [rsp+0x50]
00007cf1741db211  vmovaps xmm6, [rsp+0x60]
00007cf1741db217  vmovaps xmm8, [rsp+0x70]
00007cf1741db21d  vmovaps xmm9, [rsp+0x80]
00007cf1741db226  vmovaps xmm10, [rsp+0x90]
00007cf1741db22f  vmovaps xmm11, [rsp+0xA0]
00007cf1741db238  vmovaps xmm12, [rsp+0xB0]
00007cf1741db241  vmovaps xmm13, [rsp+0xC0]
00007cf1741db24a  vmovaps xmm14, [rsp+0xD0]
00007cf1741db253  vmovaps xmm15, [rsp+0xE0]
00007cf1741db25c  add rsp, 0xF0
00007cf1741db263  pop r11
00007cf1741db265  pop r10
00007cf1741db267  pop r9
00007cf1741db269  pop r8
00007cf1741db26b  pop rsi
00007cf1741db26c  pop rdi
00007cf1741db26d  pop rdx
00007cf1741db26e  pop rcx
00007cf1741db26f  pop rax
00007cf1741db270  add rsp, 0x08
00007cf1741db274  jmp 0x00007CF1741D6601
00007cf1741db279  sub rsp, 0x08
00007cf1741db27d  push rax
00007cf1741db27e  push rcx
00007cf1741db27f  push rdx
00007cf1741db280  push rdi
00007cf1741db281  push rsi
00007cf1741db282  push r8
00007cf1741db284  push r9
00007cf1741db286  push r10
00007cf1741db288  push r11
00007cf1741db28a  sub rsp, 0xF0
00007cf1741db291  vmovaps [rsp], xmm0
00007cf1741db296  vmovaps [rsp+0x10], xmm1
00007cf1741db29c  vmovaps [rsp+0x20], xmm2
00007cf1741db2a2  vmovaps [rsp+0x30], xmm3
00007cf1741db2a8  vmovaps [rsp+0x40], xmm4
00007cf1741db2ae  vmovaps [rsp+0x50], xmm5
00007cf1741db2b4  vmovaps [rsp+0x60], xmm6
00007cf1741db2ba  vmovaps [rsp+0x70], xmm7
00007cf1741db2c0  vmovaps [rsp+0x80], xmm8
00007cf1741db2c9  vmovaps [rsp+0x90], xmm10
00007cf1741db2d2  vmovaps [rsp+0xA0], xmm11
00007cf1741db2db  vmovaps [rsp+0xB0], xmm12
00007cf1741db2e4  vmovaps [rsp+0xC0], xmm13
00007cf1741db2ed  vmovaps [rsp+0xD0], xmm14
00007cf1741db2f6  vmovaps [rsp+0xE0], xmm15
00007cf1741db2ff  sub rsp, 0x30
00007cf1741db303  movaps [rsp], xmm9
00007cf1741db308  movaps [rsp+0x10], xmm13
00007cf1741db30e  movaps [rsp+0x20], xmm15
00007cf1741db314  lea rdi, [rsp]
00007cf1741db318  mov esi, 0x00
00007cf1741db31d  mov rax, 0x611C8A33A530
00007cf1741db327  call rax
00007cf1741db329  movaps xmm9, [rsp]
00007cf1741db32e  add rsp, 0x30
00007cf1741db332  vmovaps xmm0, [rsp]
00007cf1741db337  vmovaps xmm1, [rsp+0x10]
00007cf1741db33d  vmovaps xmm2, [rsp+0x20]
00007cf1741db343  vmovaps xmm3, [rsp+0x30]
00007cf1741db349  vmovaps xmm4, [rsp+0x40]
00007cf1741db34f  vmovaps xmm5, [rsp+0x50]
00007cf1741db355  vmovaps xmm6, [rsp+0x60]
00007cf1741db35b  vmovaps xmm7, [rsp+0x70]
00007cf1741db361  vmovaps xmm8, [rsp+0x80]
00007cf1741db36a  vmovaps xmm10, [rsp+0x90]
00007cf1741db373  vmovaps xmm11, [rsp+0xA0]
00007cf1741db37c  vmovaps xmm12, [rsp+0xB0]
00007cf1741db385  vmovaps xmm13, [rsp+0xC0]
00007cf1741db38e  vmovaps xmm14, [rsp+0xD0]
00007cf1741db397  vmovaps xmm15, [rsp+0xE0]
00007cf1741db3a0  add rsp, 0xF0
00007cf1741db3a7  pop r11
00007cf1741db3a9  pop r10
00007cf1741db3ab  pop r9
00007cf1741db3ad  pop r8
00007cf1741db3af  pop rsi
00007cf1741db3b0  pop rdi
00007cf1741db3b1  pop rdx
00007cf1741db3b2  pop rcx
00007cf1741db3b3  pop rax
00007cf1741db3b4  add rsp, 0x08
00007cf1741db3b8  jmp 0x00007CF1741D662F
00007cf1741db3bd  sub rsp, 0x08
00007cf1741db3c1  push rax
00007cf1741db3c2  push rcx
00007cf1741db3c3  push rdx
00007cf1741db3c4  push rdi
00007cf1741db3c5  push rsi
00007cf1741db3c6  push r8
00007cf1741db3c8  push r9
00007cf1741db3ca  push r10
00007cf1741db3cc  push r11
00007cf1741db3ce  sub rsp, 0xF0
00007cf1741db3d5  vmovaps [rsp], xmm0
00007cf1741db3da  vmovaps [rsp+0x10], xmm1
00007cf1741db3e0  vmovaps [rsp+0x20], xmm2
00007cf1741db3e6  vmovaps [rsp+0x30], xmm3
00007cf1741db3ec  vmovaps [rsp+0x40], xmm4
00007cf1741db3f2  vmovaps [rsp+0x50], xmm5
00007cf1741db3f8  vmovaps [rsp+0x60], xmm6
00007cf1741db3fe  vmovaps [rsp+0x70], xmm7
00007cf1741db404  vmovaps [rsp+0x80], xmm8
00007cf1741db40d  vmovaps [rsp+0x90], xmm9
00007cf1741db416  vmovaps [rsp+0xA0], xmm10
00007cf1741db41f  vmovaps [rsp+0xB0], xmm11
00007cf1741db428  vmovaps [rsp+0xC0], xmm12
00007cf1741db431  vmovaps [rsp+0xD0], xmm13
00007cf1741db43a  vmovaps [rsp+0xE0], xmm14
00007cf1741db443  sub rsp, 0x30
00007cf1741db447  movaps [rsp], xmm15
00007cf1741db44c  movaps [rsp+0x10], xmm11
00007cf1741db452  movaps [rsp+0x20], xmm12
00007cf1741db458  lea rdi, [rsp]
00007cf1741db45c  mov esi, 0x00
00007cf1741db461  mov rax, 0x611C8A33A530
00007cf1741db46b  call rax
00007cf1741db46d  movaps xmm15, [rsp]
00007cf1741db472  add rsp, 0x30
00007cf1741db476  vmovaps xmm0, [rsp]
00007cf1741db47b  vmovaps xmm1, [rsp+0x10]
00007cf1741db481  vmovaps xmm2, [rsp+0x20]
00007cf1741db487  vmovaps xmm3, [rsp+0x30]
00007cf1741db48d  vmovaps xmm4, [rsp+0x40]
00007cf1741db493  vmovaps xmm5, [rsp+0x50]
00007cf1741db499  vmovaps xmm6, [rsp+0x60]
00007cf1741db49f  vmovaps xmm7, [rsp+0x70]
00007cf1741db4a5  vmovaps xmm8, [rsp+0x80]
00007cf1741db4ae  vmovaps xmm9, [rsp+0x90]
00007cf1741db4b7  vmovaps xmm10, [rsp+0xA0]
00007cf1741db4c0  vmovaps xmm11, [rsp+0xB0]
00007cf1741db4c9  vmovaps xmm12, [rsp+0xC0]
00007cf1741db4d2  vmovaps xmm13, [rsp+0xD0]
00007cf1741db4db  vmovaps xmm14, [rsp+0xE0]
00007cf1741db4e4  add rsp, 0xF0
00007cf1741db4eb  pop r11
00007cf1741db4ed  pop r10
00007cf1741db4ef  pop r9
00007cf1741db4f1  pop r8
00007cf1741db4f3  pop rsi
00007cf1741db4f4  pop rdi
00007cf1741db4f5  pop rdx
00007cf1741db4f6  pop rcx
00007cf1741db4f7  pop rax
00007cf1741db4f8  add rsp, 0x08
00007cf1741db4fc  jmp 0x00007CF1741D664A
00007cf1741db501  sub rsp, 0x08
00007cf1741db505  push rax
00007cf1741db506  push rcx
00007cf1741db507  push rdx
00007cf1741db508  push rdi
00007cf1741db509  push rsi
00007cf1741db50a  push r8
00007cf1741db50c  push r9
00007cf1741db50e  push r10
00007cf1741db510  push r11
00007cf1741db512  sub rsp, 0xF0
00007cf1741db519  vmovaps [rsp], xmm0
00007cf1741db51e  vmovaps [rsp+0x10], xmm1
00007cf1741db524  vmovaps [rsp+0x20], xmm2
00007cf1741db52a  vmovaps [rsp+0x30], xmm3
00007cf1741db530  vmovaps [rsp+0x40], xmm4
00007cf1741db536  vmovaps [rsp+0x50], xmm5
00007cf1741db53c  vmovaps [rsp+0x60], xmm6
00007cf1741db542  vmovaps [rsp+0x70], xmm7
00007cf1741db548  vmovaps [rsp+0x80], xmm8
00007cf1741db551  vmovaps [rsp+0x90], xmm9
00007cf1741db55a  vmovaps [rsp+0xA0], xmm10
00007cf1741db563  vmovaps [rsp+0xB0], xmm11
00007cf1741db56c  vmovaps [rsp+0xC0], xmm12
00007cf1741db575  vmovaps [rsp+0xD0], xmm14
00007cf1741db57e  vmovaps [rsp+0xE0], xmm15
00007cf1741db587  sub rsp, 0x30
00007cf1741db58b  movaps [rsp], xmm13
00007cf1741db590  movaps [rsp+0x10], xmm10
00007cf1741db596  movaps [rsp+0x20], xmm14
00007cf1741db59c  lea rdi, [rsp]
00007cf1741db5a0  mov esi, 0x00
00007cf1741db5a5  mov rax, 0x611C8A33A530
00007cf1741db5af  call rax
00007cf1741db5b1  movaps xmm13, [rsp]
00007cf1741db5b6  add rsp, 0x30
00007cf1741db5ba  vmovaps xmm0, [rsp]
00007cf1741db5bf  vmovaps xmm1, [rsp+0x10]
00007cf1741db5c5  vmovaps xmm2, [rsp+0x20]
00007cf1741db5cb  vmovaps xmm3, [rsp+0x30]
00007cf1741db5d1  vmovaps xmm4, [rsp+0x40]
00007cf1741db5d7  vmovaps xmm5, [rsp+0x50]
00007cf1741db5dd  vmovaps xmm6, [rsp+0x60]
00007cf1741db5e3  vmovaps xmm7, [rsp+0x70]
00007cf1741db5e9  vmovaps xmm8, [rsp+0x80]
00007cf1741db5f2  vmovaps xmm9, [rsp+0x90]
00007cf1741db5fb  vmovaps xmm10, [rsp+0xA0]
00007cf1741db604  vmovaps xmm11, [rsp+0xB0]
00007cf1741db60d  vmovaps xmm12, [rsp+0xC0]
00007cf1741db616  vmovaps xmm14, [rsp+0xD0]
00007cf1741db61f  vmovaps xmm15, [rsp+0xE0]
00007cf1741db628  add rsp, 0xF0
00007cf1741db62f  pop r11
00007cf1741db631  pop r10
00007cf1741db633  pop r9
00007cf1741db635  pop r8
00007cf1741db637  pop rsi
00007cf1741db638  pop rdi
00007cf1741db639  pop rdx
00007cf1741db63a  pop rcx
00007cf1741db63b  pop rax
00007cf1741db63c  add rsp, 0x08
00007cf1741db640  jmp 0x00007CF1741D666D
00007cf1741db645  sub rsp, 0x08
00007cf1741db649  push rax
00007cf1741db64a  push rcx
00007cf1741db64b  push rdx
00007cf1741db64c  push rdi
00007cf1741db64d  push rsi
00007cf1741db64e  push r8
00007cf1741db650  push r9
00007cf1741db652  push r10
00007cf1741db654  push r11
00007cf1741db656  sub rsp, 0xF0
00007cf1741db65d  vmovaps [rsp], xmm0
00007cf1741db662  vmovaps [rsp+0x10], xmm1
00007cf1741db668  vmovaps [rsp+0x20], xmm2
00007cf1741db66e  vmovaps [rsp+0x30], xmm3
00007cf1741db674  vmovaps [rsp+0x40], xmm4
00007cf1741db67a  vmovaps [rsp+0x50], xmm5
00007cf1741db680  vmovaps [rsp+0x60], xmm6
00007cf1741db686  vmovaps [rsp+0x70], xmm7
00007cf1741db68c  vmovaps [rsp+0x80], xmm8
00007cf1741db695  vmovaps [rsp+0x90], xmm9
00007cf1741db69e  vmovaps [rsp+0xA0], xmm10
00007cf1741db6a7  vmovaps [rsp+0xB0], xmm11
00007cf1741db6b0  vmovaps [rsp+0xC0], xmm12
00007cf1741db6b9  vmovaps [rsp+0xD0], xmm13
00007cf1741db6c2  vmovaps [rsp+0xE0], xmm15
00007cf1741db6cb  sub rsp, 0x30
00007cf1741db6cf  movaps [rsp], xmm14
00007cf1741db6d4  movaps [rsp+0x10], xmm1
00007cf1741db6d9  movaps [rsp+0x20], xmm7
00007cf1741db6de  lea rdi, [rsp]
00007cf1741db6e2  mov esi, 0x00
00007cf1741db6e7  mov rax, 0x611C8A33A530
00007cf1741db6f1  call rax
00007cf1741db6f3  movaps xmm14, [rsp]
00007cf1741db6f8  add rsp, 0x30
00007cf1741db6fc  vmovaps xmm0, [rsp]
00007cf1741db701  vmovaps xmm1, [rsp+0x10]
00007cf1741db707  vmovaps xmm2, [rsp+0x20]
00007cf1741db70d  vmovaps xmm3, [rsp+0x30]
00007cf1741db713  vmovaps xmm4, [rsp+0x40]
00007cf1741db719  vmovaps xmm5, [rsp+0x50]
00007cf1741db71f  vmovaps xmm6, [rsp+0x60]
00007cf1741db725  vmovaps xmm7, [rsp+0x70]
00007cf1741db72b  vmovaps xmm8, [rsp+0x80]
00007cf1741db734  vmovaps xmm9, [rsp+0x90]
00007cf1741db73d  vmovaps xmm10, [rsp+0xA0]
00007cf1741db746  vmovaps xmm11, [rsp+0xB0]
00007cf1741db74f  vmovaps xmm12, [rsp+0xC0]
00007cf1741db758  vmovaps xmm13, [rsp+0xD0]
00007cf1741db761  vmovaps xmm15, [rsp+0xE0]
00007cf1741db76a  add rsp, 0xF0
00007cf1741db771  pop r11
00007cf1741db773  pop r10
00007cf1741db775  pop r9
00007cf1741db777  pop r8
00007cf1741db779  pop rsi
00007cf1741db77a  pop rdi
00007cf1741db77b  pop rdx
00007cf1741db77c  pop rcx
00007cf1741db77d  pop rax
00007cf1741db77e  add rsp, 0x08
00007cf1741db782  jmp 0x00007CF1741D6690
00007cf1741db787  sub rsp, 0x08
00007cf1741db78b  push rax
00007cf1741db78c  push rcx
00007cf1741db78d  push rdx
00007cf1741db78e  push rdi
00007cf1741db78f  push rsi
00007cf1741db790  push r8
00007cf1741db792  push r9
00007cf1741db794  push r10
00007cf1741db796  push r11
00007cf1741db798  sub rsp, 0xF0
00007cf1741db79f  vmovaps [rsp], xmm0
00007cf1741db7a4  vmovaps [rsp+0x10], xmm2
00007cf1741db7aa  vmovaps [rsp+0x20], xmm3
00007cf1741db7b0  vmovaps [rsp+0x30], xmm4
00007cf1741db7b6  vmovaps [rsp+0x40], xmm5
00007cf1741db7bc  vmovaps [rsp+0x50], xmm6
00007cf1741db7c2  vmovaps [rsp+0x60], xmm7
00007cf1741db7c8  vmovaps [rsp+0x70], xmm8
00007cf1741db7ce  vmovaps [rsp+0x80], xmm9
00007cf1741db7d7  vmovaps [rsp+0x90], xmm10
00007cf1741db7e0  vmovaps [rsp+0xA0], xmm11
00007cf1741db7e9  vmovaps [rsp+0xB0], xmm12
00007cf1741db7f2  vmovaps [rsp+0xC0], xmm13
00007cf1741db7fb  vmovaps [rsp+0xD0], xmm14
00007cf1741db804  vmovaps [rsp+0xE0], xmm15
00007cf1741db80d  sub rsp, 0x30
00007cf1741db811  movaps [rsp], xmm1
00007cf1741db815  movaps [rsp+0x10], xmm8
00007cf1741db81b  movaps [rsp+0x20], xmm9
00007cf1741db821  lea rdi, [rsp]
00007cf1741db825  mov esi, 0x00
00007cf1741db82a  mov rax, 0x611C8A33A530
00007cf1741db834  call rax
00007cf1741db836  movaps xmm1, [rsp]
00007cf1741db83a  add rsp, 0x30
00007cf1741db83e  vmovaps xmm0, [rsp]
00007cf1741db843  vmovaps xmm2, [rsp+0x10]
00007cf1741db849  vmovaps xmm3, [rsp+0x20]
00007cf1741db84f  vmovaps xmm4, [rsp+0x30]
00007cf1741db855  vmovaps xmm5, [rsp+0x40]
00007cf1741db85b  vmovaps xmm6, [rsp+0x50]
00007cf1741db861  vmovaps xmm7, [rsp+0x60]
00007cf1741db867  vmovaps xmm8, [rsp+0x70]
00007cf1741db86d  vmovaps xmm9, [rsp+0x80]
00007cf1741db876  vmovaps xmm10, [rsp+0x90]
00007cf1741db87f  vmovaps xmm11, [rsp+0xA0]
00007cf1741db888  vmovaps xmm12, [rsp+0xB0]
00007cf1741db891  vmovaps xmm13, [rsp+0xC0]
00007cf1741db89a  vmovaps xmm14, [rsp+0xD0]
00007cf1741db8a3  vmovaps xmm15, [rsp+0xE0]
00007cf1741db8ac  add rsp, 0xF0
00007cf1741db8b3  pop r11
00007cf1741db8b5  pop r10
00007cf1741db8b7  pop r9
00007cf1741db8b9  pop r8
00007cf1741db8bb  pop rsi
00007cf1741db8bc  pop rdi
00007cf1741db8bd  pop rdx
00007cf1741db8be  pop rcx
00007cf1741db8bf  pop rax
00007cf1741db8c0  add rsp, 0x08
00007cf1741db8c4  jmp 0x00007CF1741D66B2
00007cf1741db8c9  call 0x00007CF1740B3E40
00007cf1741db8ce  jmp 0x00007CF1741D66C0
00007cf1741db8d3  call 0x00007CF17400C380
00007cf1741db8d8  jmp 0x00007CF1741D66CA
00007cf1741db8dd  call 0x00007CF17400D600
00007cf1741db8e2  jmp 0x00007CF1741D66D4
00007cf1741db8e7  call 0x00007CF173FFF540
00007cf1741db8ec  jmp 0x00007CF1741D66DE
00007cf1741db8f1  int3
00007cf1741db8f2  nop [rax+rax*1], ax
00007cf1741db8fb  nop [rax+rax*1], eax
00007cf1741db900  mov eax, [r15+0x48]
00007cf1741db904  lea r14d, [eax+0x01]
00007cf1741db909  mov [rsp+0x10], r14d
00007cf1741db90e  mov r14d, r14d
00007cf1741db911  mov [r15+0x48], r14
00007cf1741db915  xor eax, eax
00007cf1741db917  mov r14d, [rsp+0x10]
00007cf1741db91c  cmp r14d, 0x1F4
00007cf1741db923  cmc
00007cf1741db924  lahf
00007cf1741db925  seto al
00007cf1741db928  mov [r15+0x108], eax
00007cf1741db92f  mov eax, [r15+0x108]
00007cf1741db936  sahf
00007cf1741db937  jnz 0x00007CF1741DB969
00007cf1741db939  cmp dword ptr [r15+0x318], 0x00
00007cf1741db941  jz 0x00007CF1741E1AB0
00007cf1741db947  nop [rax+rax*1], ax
00007cf1741db950  nop [rax+rax*1], eax
00007cf1741db958  mov eax, 0x410450
00007cf1741db95d  mov [r15+0x100], rax
00007cf1741db964  jmp 0x00007CF173FFE110
00007cf1741db969  cmp dword ptr [r15+0x318], 0x00
00007cf1741db971  jz 0x00007CF1741DB9A0
00007cf1741db977  nop [rax+rax*1], ax
00007cf1741db980  nop [rax+rax*1], eax
00007cf1741db988  mov eax, 0x410274
00007cf1741db98d  mov [r15+0x100], rax
00007cf1741db994  jmp 0x00007CF173FFE110
00007cf1741db999  int3
00007cf1741db99a  int3
00007cf1741db99b  nop [rax+rax*1], eax
00007cf1741db9a0  mov rax, [r15+0x40]
00007cf1741db9a4  movaps xmm1, [r15+0x1D0]
00007cf1741db9ac  vmovaps [rsp+0x10], xmm1
00007cf1741db9b2  vmovaps xmm15, [rsp+0x10]
00007cf1741db9b8  por xmm1, xmm15
00007cf1741db9bd  movaps xmm14, [r15+0x1A0]
00007cf1741db9c5  vmovaps [rsp+0x10], xmm14
00007cf1741db9cb  vmovaps xmm13, [rsp+0x10]
00007cf1741db9d1  por xmm14, xmm13
00007cf1741db9d6  lea r14, [rax+0x30]
00007cf1741db9da  mov r12, [r13+r14*1]
00007cf1741db9df  lea r14, [rax+0x38]
00007cf1741db9e3  mov r11, [r13+r14*1]
00007cf1741db9e8  movq xmm13, r12
00007cf1741db9ed  movq xmm12, r11
00007cf1741db9f2  movq xmm13, xmm13
00007cf1741db9f7  vmovaps [rsp+0x10], xmm13
00007cf1741db9fd  movq xmm13, xmm13
00007cf1741dba02  movaps [r15+0x130], xmm13
00007cf1741dba0a  movq xmm12, xmm12
00007cf1741dba0f  vmovaps [rsp+0x20], xmm12
00007cf1741dba15  movq xmm12, xmm12
00007cf1741dba1a  movaps [r15+0x280], xmm12
00007cf1741dba22  movaps xmm13, [r15+0x270]
00007cf1741dba2a  vmovaps [rsp+0x30], xmm13
00007cf1741dba30  vmovaps xmm12, [rsp+0x30]
00007cf1741dba36  por xmm13, xmm12
00007cf1741dba3b  lea r14, [rax+0x20]
00007cf1741dba3f  mov r12, [r13+r14*1]
00007cf1741dba44  lea r14, [rax+0x28]
00007cf1741dba48  mov r11, [r13+r14*1]
00007cf1741dba4d  movq xmm12, r12
00007cf1741dba52  movq xmm11, r11
00007cf1741dba57  movq xmm12, xmm12
00007cf1741dba5c  vmovaps [rsp+0x30], xmm12
00007cf1741dba62  movq xmm12, xmm12
00007cf1741dba67  movaps [r15+0x150], xmm12
00007cf1741dba6f  movq xmm11, xmm11
00007cf1741dba74  vmovaps [rsp+0x40], xmm11
00007cf1741dba7a  movq xmm11, xmm11
00007cf1741dba7f  movaps [r15+0x140], xmm11
00007cf1741dba87  lea r14, [rax+0x10]
00007cf1741dba8b  mov r12, [r13+r14*1]
00007cf1741dba90  lea r14, [rax+0x18]
00007cf1741dba94  mov r11, [r13+r14*1]
00007cf1741dba99  movq xmm12, r12
00007cf1741dba9e  movq xmm11, r11
00007cf1741dbaa3  movq xmm12, xmm12
00007cf1741dbaa8  vmovaps [rsp+0x50], xmm12
00007cf1741dbaae  movq xmm12, xmm12
00007cf1741dbab3  movaps [r15+0x170], xmm12
00007cf1741dbabb  movq xmm11, xmm11
00007cf1741dbac0  vmovaps [rsp+0x60], xmm11
00007cf1741dbac6  movq xmm11, xmm11
00007cf1741dbacb  movaps [r15+0x160], xmm11
00007cf1741dbad3  mov r14, [r13+rax*1]
00007cf1741dbad8  vmovq xmm12, r14
00007cf1741dbadd  vpbroadcastq xmm12, xmm12
00007cf1741dbae2  lea r14, [rax+0x08]
00007cf1741dbae6  mov rax, [r13+r14*1]
00007cf1741dbaeb  movq xmm11, rax
00007cf1741dbaf0  movaps [r15+0x230], xmm11
00007cf1741dbaf8  mov rax, [r15+0xF8]
00007cf1741dbaff  lea r14, [rax+0x50]
00007cf1741dbb03  movups xmm11, [r13+r14*1]
00007cf1741dbb09  lea r14, [rax+0x60]
00007cf1741dbb0d  movups xmm10, [r13+r14*1]
00007cf1741dbb13  lea r14, [rax+0x30]
00007cf1741dbb17  movups xmm9, [r13+r14*1]
00007cf1741dbb1d  mov r14, [r15+0x50]
00007cf1741dbb21  mov [r15+0x60], r14
00007cf1741dbb25  mov qword ptr [r15+0x58], 0x40
00007cf1741dbb2d  movaps xmm8, xmm12
00007cf1741dbb31  mulpd xmm8, xmm15
00007cf1741dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007cf1741dbb3c  ptest xmm7, xmm7
00007cf1741dbb41  jnz 0x00007CF1741DC96A
00007cf1741dbb47  movq xmm15, qword ptr [r15+0x230]
00007cf1741dbb50  vmovaps [rsp+0x70], xmm15
00007cf1741dbb56  vpermilpd xmm15, xmm15, 0x00
00007cf1741dbb5c  movaps xmm7, xmm9
00007cf1741dbb60  mulpd xmm7, xmm15
00007cf1741dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007cf1741dbb6a  ptest xmm6, xmm6
00007cf1741dbb6f  jnz 0x00007CF1741DCAAE
00007cf1741dbb75  vxorps xmm15, xmm15, xmm15
00007cf1741dbb7a  vpbroadcastq xmm15, xmm15
00007cf1741dbb7f  movaps xmm9, xmm12
00007cf1741dbb83  mulpd xmm9, xmm10
00007cf1741dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007cf1741dbb8e  ptest xmm6, xmm6
00007cf1741dbb93  jnz 0x00007CF1741DCBF0
00007cf1741dbb99  movaps xmm10, xmm12
00007cf1741dbb9d  mulpd xmm10, xmm11
00007cf1741dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007cf1741dbba8  ptest xmm6, xmm6
00007cf1741dbbad  jnz 0x00007CF1741DCD34
00007cf1741dbbb3  movaps xmm11, [r15+0x1F0]
00007cf1741dbbbb  movaps xmm6, xmm12
00007cf1741dbbbf  mulpd xmm6, xmm11
00007cf1741dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007cf1741dbbc9  ptest xmm5, xmm5
00007cf1741dbbce  jnz 0x00007CF1741DCE78
00007cf1741dbbd4  movaps xmm12, [r15+0x2A0]
00007cf1741dbbdc  vmovaps [rsp+0x80], xmm12
00007cf1741dbbe5  vmovaps xmm11, [rsp+0x80]
00007cf1741dbbee  por xmm12, xmm11
00007cf1741dbbf3  movaps xmm11, [r15+0x250]
00007cf1741dbbfb  vmovaps [rsp+0x80], xmm11
00007cf1741dbc04  vmovaps xmm5, [rsp+0x80]
00007cf1741dbc0d  por xmm11, xmm5
00007cf1741dbc12  vmovaps xmm4, [rsp+0x70]
00007cf1741dbc18  vpermilpd xmm4, xmm4, 0x00
00007cf1741dbc1e  movaps xmm3, xmm5
00007cf1741dbc21  mulpd xmm3, xmm4
00007cf1741dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007cf1741dbc2a  ptest xmm2, xmm2
00007cf1741dbc2f  jnz 0x00007CF1741DCFBA
00007cf1741dbc35  mov [rsp+0x80], rax
00007cf1741dbc3d  xor eax, eax
00007cf1741dbc3f  mov r12d, 0x40
00007cf1741dbc45  mov r11d, 0x200
00007cf1741dbc4b  cmp r12, r11
00007cf1741dbc4e  cmc
00007cf1741dbc4f  lahf
00007cf1741dbc50  seto al
00007cf1741dbc53  mov [r15+0x108], eax
00007cf1741dbc5a  movaps xmm5, xmm8
00007cf1741dbc5e  addpd xmm5, xmm15
00007cf1741dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007cf1741dbc68  ptest xmm4, xmm4
00007cf1741dbc6d  jnz 0x00007CF1741DD0FA
00007cf1741dbc73  movaps xmm8, [r15+0x1B0]
00007cf1741dbc7b  movaps xmm4, xmm9
00007cf1741dbc7f  addpd xmm4, xmm8
00007cf1741dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007cf1741dbc89  ptest xmm2, xmm2
00007cf1741dbc8e  jnz 0x00007CF1741DD23C
00007cf1741dbc94  movaps xmm9, xmm10
00007cf1741dbc98  addpd xmm9, xmm8
00007cf1741dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007cf1741dbca3  ptest xmm2, xmm2
00007cf1741dbca8  jnz 0x00007CF1741DD37E
00007cf1741dbcae  movaps xmm10, [r15+0x2F0]
00007cf1741dbcb6  vmovaps [rsp+0x90], xmm10
00007cf1741dbcbf  vmovaps xmm8, [rsp+0x90]
00007cf1741dbcc8  por xmm10, xmm8
00007cf1741dbccd  movaps xmm8, [r15+0x2E0]
00007cf1741dbcd5  vmovaps [rsp+0x90], xmm8
00007cf1741dbcde  vmovaps xmm2, [rsp+0x90]
00007cf1741dbce7  por xmm8, xmm2
00007cf1741dbcec  movaps xmm2, [r15+0x2D0]
00007cf1741dbcf4  vmovaps [rsp+0x90], xmm2
00007cf1741dbcfd  vmovaps [rsp+0xA0], xmm1
00007cf1741dbd06  vmovaps xmm1, [rsp+0x90]
00007cf1741dbd0f  por xmm2, xmm1
00007cf1741dbd13  movaps xmm1, [r15+0x200]
00007cf1741dbd1b  vmovaps [rsp+0x90], xmm1
00007cf1741dbd24  vmovaps [rsp+0xB0], xmm15
00007cf1741dbd2d  vmovaps xmm15, [rsp+0x90]
00007cf1741dbd36  por xmm1, xmm15
00007cf1741dbd3b  movaps xmm15, [r15+0x1C0]
00007cf1741dbd43  vmovaps [rsp+0x90], xmm15
00007cf1741dbd4c  vmovaps [rsp+0xC0], xmm1
00007cf1741dbd55  vmovaps xmm1, [rsp+0x90]
00007cf1741dbd5e  por xmm15, xmm1
00007cf1741dbd63  movaps xmm1, [r15+0x190]
00007cf1741dbd6b  vmovaps [rsp+0x90], xmm1
00007cf1741dbd74  vmovaps [rsp+0xD0], xmm15
00007cf1741dbd7d  vmovaps xmm15, [rsp+0x90]
00007cf1741dbd86  por xmm1, xmm15
00007cf1741dbd8b  movaps xmm15, [r15+0x300]
00007cf1741dbd93  vmovaps [rsp+0x90], xmm15
00007cf1741dbd9c  vmovaps [rsp+0xE0], xmm1
00007cf1741dbda5  vmovaps xmm1, [rsp+0x90]
00007cf1741dbdae  por xmm15, xmm1
00007cf1741dbdb3  mov rax, [rsp+0x80]
00007cf1741dbdbb  lea r12, [rax+0xA0]
00007cf1741dbdc2  movups xmm1, [r13+r12*1]
00007cf1741dbdc8  lea r12, [rax+0xB0]
00007cf1741dbdcf  vmovaps [rsp+0x80], xmm1
00007cf1741dbdd8  movups xmm1, [r13+r12*1]
00007cf1741dbdde  vmovaps [rsp+0x90], xmm1
00007cf1741dbde7  vmovaps [rsp+0xF0], xmm15
00007cf1741dbdf0  vmovaps xmm15, [rsp+0xB0]
00007cf1741dbdf9  vmovaps [rsp+0xB0], xmm14
00007cf1741dbe02  movaps xmm1, xmm6
00007cf1741dbe05  addpd xmm1, xmm15
00007cf1741dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007cf1741dbe0f  ptest xmm14, xmm14
00007cf1741dbe15  jnz 0x00007CF1741DD4D6
00007cf1741dbe1b  lea r12, [rax+0xF0]
00007cf1741dbe22  movups xmm15, [r13+r12*1]
00007cf1741dbe28  movaps xmm14, xmm4
00007cf1741dbe2c  addpd xmm14, xmm3
00007cf1741dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007cf1741dbe37  ptest xmm6, xmm6
00007cf1741dbe3c  jnz 0x00007CF1741DD621
00007cf1741dbe42  movaps xmm6, xmm9
00007cf1741dbe46  addpd xmm6, xmm7
00007cf1741dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007cf1741dbe4f  ptest xmm4, xmm4
00007cf1741dbe54  jnz 0x00007CF1741DD763
00007cf1741dbe5a  vmovaps xmm9, [rsp+0x70]
00007cf1741dbe60  vpermilpd xmm9, xmm9, 0x00
00007cf1741dbe66  vmovaps xmm4, [rsp+0x90]
00007cf1741dbe6f  movaps xmm7, xmm4
00007cf1741dbe72  mulpd xmm7, xmm9
00007cf1741dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007cf1741dbe7c  ptest xmm3, xmm3
00007cf1741dbe81  jnz 0x00007CF1741DD8A4
00007cf1741dbe87  vmovaps xmm9, [rsp+0x50]
00007cf1741dbe8d  vpermilpd xmm9, xmm9, 0x00
00007cf1741dbe93  movaps xmm4, xmm15
00007cf1741dbe97  mulpd xmm4, xmm9
00007cf1741dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007cf1741dbea1  ptest xmm3, xmm3
00007cf1741dbea6  jnz 0x00007CF1741DD9E5
00007cf1741dbeac  lea r12, [rax+0xE0]
00007cf1741dbeb3  movups xmm15, [r13+r12*1]
00007cf1741dbeb9  vmovaps xmm9, [rsp+0x70]
00007cf1741dbebf  vpermilpd xmm9, xmm9, 0x00
00007cf1741dbec5  vmovaps [rsp+0x70], xmm1
00007cf1741dbecb  vmovaps xmm1, [rsp+0x80]
00007cf1741dbed4  vmovaps [rsp+0x80], xmm15
00007cf1741dbedd  movaps xmm3, xmm1
00007cf1741dbee0  mulpd xmm3, xmm9
00007cf1741dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007cf1741dbeea  ptest xmm15, xmm15
00007cf1741dbef0  jnz 0x00007CF1741DDB31
00007cf1741dbef6  vmovaps xmm1, [rsp+0xF0]
00007cf1741dbeff  vmovaps xmm15, [rsp+0xF0]
00007cf1741dbf08  por xmm1, xmm15
00007cf1741dbf0d  movaps [r15+0x300], xmm1
00007cf1741dbf15  vmovaps xmm15, [rsp+0xE0]
00007cf1741dbf1e  vmovaps xmm9, [rsp+0xE0]
00007cf1741dbf27  por xmm15, xmm9
00007cf1741dbf2c  movaps [r15+0x190], xmm15
00007cf1741dbf34  vmovaps xmm9, [rsp+0x50]
00007cf1741dbf3a  vpermilpd xmm9, xmm9, 0x00
00007cf1741dbf40  vmovaps [rsp+0x90], xmm1
00007cf1741dbf49  vmovaps [rsp+0xE0], xmm15
00007cf1741dbf52  vmovaps xmm15, [rsp+0x80]
00007cf1741dbf5b  vmovaps [rsp+0x80], xmm14
00007cf1741dbf64  movaps xmm1, xmm15
00007cf1741dbf68  mulpd xmm1, xmm9
00007cf1741dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007cf1741dbf72  ptest xmm14, xmm14
00007cf1741dbf78  jnz 0x00007CF1741DDC72
00007cf1741dbf7e  lea r12, [rax+0x90]
00007cf1741dbf85  movups xmm15, [r13+r12*1]
00007cf1741dbf8b  vmovaps xmm14, [rsp+0xD0]
00007cf1741dbf94  vmovaps xmm9, [rsp+0xD0]
00007cf1741dbf9d  por xmm14, xmm9
00007cf1741dbfa2  movaps [r15+0x1C0], xmm14
00007cf1741dbfaa  vmovaps xmm9, [rsp+0xC0]
00007cf1741dbfb3  vmovaps [rsp+0xD0], xmm1
00007cf1741dbfbc  vmovaps xmm1, [rsp+0xC0]
00007cf1741dbfc5  por xmm9, xmm1
00007cf1741dbfca  movaps [r15+0x200], xmm9
00007cf1741dbfd2  vmovaps [rsp+0xC0], xmm2
00007cf1741dbfdb  vmovaps xmm1, [rsp+0xC0]
00007cf1741dbfe4  por xmm2, xmm1
00007cf1741dbfe8  movaps [r15+0x2D0], xmm2
00007cf1741dbff0  vmovaps [rsp+0xC0], xmm8
00007cf1741dbff9  vmovaps xmm1, [rsp+0xC0]
00007cf1741dc002  por xmm8, xmm1
00007cf1741dc007  movaps [r15+0x2E0], xmm8
00007cf1741dc00f  vmovaps [rsp+0xC0], xmm15
00007cf1741dc018  movaps xmm1, xmm5
00007cf1741dc01b  addpd xmm1, xmm7
00007cf1741dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007cf1741dc024  ptest xmm15, xmm15
00007cf1741dc02a  jnz 0x00007CF1741DDDBE
00007cf1741dc030  vmovaps xmm15, [rsp+0x50]
00007cf1741dc036  vpermilpd xmm15, xmm15, 0x00
00007cf1741dc03c  vmovaps xmm5, [rsp+0xC0]
00007cf1741dc045  vmovaps [rsp+0xC0], xmm1
00007cf1741dc04e  movaps xmm7, xmm5
00007cf1741dc051  mulpd xmm7, xmm15
00007cf1741dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007cf1741dc05b  ptest xmm1, xmm1
00007cf1741dc060  jnz 0x00007CF1741DDEFE
00007cf1741dc066  lea r12, [rax+0x80]
00007cf1741dc06d  movups xmm1, [r13+r12*1]
00007cf1741dc073  vmovaps xmm5, [rsp+0x70]
00007cf1741dc079  vmovaps [rsp+0x70], xmm1
00007cf1741dc07f  movaps xmm15, xmm5
00007cf1741dc083  addpd xmm15, xmm3
00007cf1741dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007cf1741dc08e  ptest xmm1, xmm1
00007cf1741dc093  jnz 0x00007CF1741DE049
00007cf1741dc099  vmovaps xmm5, [rsp+0x80]
00007cf1741dc0a2  movaps xmm1, xmm5
00007cf1741dc0a5  addpd xmm1, xmm4
00007cf1741dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007cf1741dc0ae  ptest xmm3, xmm3
00007cf1741dc0b3  jnz 0x00007CF1741DE18B
00007cf1741dc0b9  vmovaps [rsp+0x80], xmm10
00007cf1741dc0c2  vmovaps xmm5, [rsp+0x80]
00007cf1741dc0cb  por xmm10, xmm5
00007cf1741dc0d0  movaps [r15+0x2F0], xmm10
00007cf1741dc0d8  vmovaps xmm5, [rsp+0x50]
00007cf1741dc0de  vpermilpd xmm5, xmm5, 0x00
00007cf1741dc0e4  vmovaps xmm3, [rsp+0x70]
00007cf1741dc0ea  vmovaps [rsp+0x50], xmm1
00007cf1741dc0f0  movaps xmm4, xmm3
00007cf1741dc0f3  mulpd xmm4, xmm5
00007cf1741dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007cf1741dc0fc  ptest xmm1, xmm1
00007cf1741dc101  jnz 0x00007CF1741DE2CB
00007cf1741dc107  lea r12, [rax+0xD0]
00007cf1741dc10e  movups xmm1, [r13+r12*1]
00007cf1741dc114  vmovaps xmm3, [rsp+0xD0]
00007cf1741dc11d  vmovaps [rsp+0x70], xmm1
00007cf1741dc123  movaps xmm5, xmm6
00007cf1741dc126  addpd xmm5, xmm3
00007cf1741dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007cf1741dc12f  ptest xmm1, xmm1
00007cf1741dc134  jnz 0x00007CF1741DE415
00007cf1741dc13a  vmovaps xmm1, [rsp+0x60]
00007cf1741dc140  vpermilpd xmm1, xmm1, 0x00
00007cf1741dc146  movaps xmm6, xmm9
00007cf1741dc14a  mulpd xmm6, xmm1
00007cf1741dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007cf1741dc153  ptest xmm3, xmm3
00007cf1741dc158  jnz 0x00007CF1741DE555
00007cf1741dc15e  movaps [r15+0x260], xmm6
00007cf1741dc166  vxorps xmm1, xmm1, xmm1
00007cf1741dc16a  vpbroadcastq xmm1, xmm1
00007cf1741dc16f  movaps [r15+0x1B0], xmm1
00007cf1741dc177  vmovaps xmm1, [rsp+0x60]
00007cf1741dc17d  vpermilpd xmm1, xmm1, 0x00
00007cf1741dc183  vmovaps xmm3, [rsp+0x70]
00007cf1741dc189  vmovaps [rsp+0x70], xmm15
00007cf1741dc18f  movaps xmm9, xmm3
00007cf1741dc193  mulpd xmm9, xmm1
00007cf1741dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007cf1741dc19e  ptest xmm15, xmm15
00007cf1741dc1a4  jnz 0x00007CF1741DE696
00007cf1741dc1aa  lea r12, [rax+0xC0]
00007cf1741dc1b1  movups xmm1, [r13+r12*1]
00007cf1741dc1b7  vmovaps xmm3, [rsp+0xC0]
00007cf1741dc1c0  vmovaps [rsp+0x80], xmm1
00007cf1741dc1c9  movaps xmm15, xmm3
00007cf1741dc1cd  addpd xmm15, xmm7
00007cf1741dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007cf1741dc1d8  ptest xmm1, xmm1
00007cf1741dc1dd  jnz 0x00007CF1741DE7E2
00007cf1741dc1e3  vmovaps [rsp+0xC0], xmm13
00007cf1741dc1ec  vmovaps xmm1, [rsp+0xC0]
00007cf1741dc1f5  por xmm13, xmm1
00007cf1741dc1fa  movaps [r15+0x270], xmm13
00007cf1741dc202  vmovaps xmm1, [rsp+0xB0]
00007cf1741dc20b  vmovaps xmm7, [rsp+0xB0]
00007cf1741dc214  por xmm1, xmm7
00007cf1741dc218  movaps [r15+0x1A0], xmm1
00007cf1741dc220  vmovaps xmm1, [rsp+0x60]
00007cf1741dc226  vpermilpd xmm1, xmm1, 0x00
00007cf1741dc22c  vmovaps [rsp+0xB0], xmm1
00007cf1741dc235  vmovaps xmm1, [rsp+0x80]
00007cf1741dc23e  vmovaps [rsp+0x80], xmm15
00007cf1741dc247  vmovaps xmm15, [rsp+0xB0]
00007cf1741dc250  vmovaps [rsp+0xB0], xmm14
00007cf1741dc259  movaps xmm3, xmm1
00007cf1741dc25c  mulpd xmm3, xmm15
00007cf1741dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007cf1741dc266  ptest xmm14, xmm14
00007cf1741dc26c  jnz 0x00007CF1741DE924
00007cf1741dc272  lea r12, [rax+0x20]
00007cf1741dc276  movups xmm1, [r13+r12*1]
00007cf1741dc27c  movaps [r15+0x110], xmm1
00007cf1741dc284  vmovaps xmm14, [rsp+0x70]
00007cf1741dc28a  vmovaps [rsp+0x70], xmm1
00007cf1741dc290  movaps xmm15, xmm14
00007cf1741dc294  addpd xmm15, xmm4
00007cf1741dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007cf1741dc29f  ptest xmm1, xmm1
00007cf1741dc2a4  jnz 0x00007CF1741DEA6F
00007cf1741dc2aa  vmovaps xmm1, [rsp+0x60]
00007cf1741dc2b0  vpermilpd xmm1, xmm1, 0x00
00007cf1741dc2b6  movaps xmm14, xmm2
00007cf1741dc2ba  mulpd xmm14, xmm1
00007cf1741dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007cf1741dc2c5  ptest xmm4, xmm4
00007cf1741dc2ca  jnz 0x00007CF1741DEBB2
00007cf1741dc2d0  vmovaps xmm4, [rsp+0x50]
00007cf1741dc2d6  movaps xmm1, xmm4
00007cf1741dc2d9  addpd xmm1, xmm9
00007cf1741dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007cf1741dc2e3  ptest xmm2, xmm2
00007cf1741dc2e8  jnz 0x00007CF1741DECF4
00007cf1741dc2ee  vmovaps xmm9, [rsp+0x30]
00007cf1741dc2f4  vpermilpd xmm9, xmm9, 0x00
00007cf1741dc2fa  vmovaps xmm2, [rsp+0x70]
00007cf1741dc300  vmovaps [rsp+0x50], xmm1
00007cf1741dc306  movaps xmm4, xmm2
00007cf1741dc309  mulpd xmm4, xmm9
00007cf1741dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007cf1741dc313  ptest xmm1, xmm1
00007cf1741dc318  jnz 0x00007CF1741DEE35
00007cf1741dc31e  vmovaps xmm1, [rsp+0x30]
00007cf1741dc324  vpermilpd xmm1, xmm1, 0x00
00007cf1741dc32a  vmovaps xmm2, [rsp+0x90]
00007cf1741dc333  vmovaps [rsp+0x60], xmm15
00007cf1741dc339  movaps xmm9, xmm2
00007cf1741dc33d  mulpd xmm9, xmm1
00007cf1741dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007cf1741dc348  ptest xmm15, xmm15
00007cf1741dc34e  jnz 0x00007CF1741DEF76
00007cf1741dc354  vmovaps xmm15, [rsp+0x80]
00007cf1741dc35d  movaps xmm1, xmm15
00007cf1741dc361  addpd xmm1, xmm6
00007cf1741dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007cf1741dc36a  ptest xmm2, xmm2
00007cf1741dc36f  jnz 0x00007CF1741DF0B8
00007cf1741dc375  movaps xmm15, xmm5
00007cf1741dc379  addpd xmm15, xmm3
00007cf1741dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007cf1741dc384  ptest xmm6, xmm6
00007cf1741dc389  jnz 0x00007CF1741DF1F9
00007cf1741dc38f  vmovaps xmm6, [rsp+0x30]
00007cf1741dc395  vpermilpd xmm6, xmm6, 0x00
00007cf1741dc39b  movaps xmm5, xmm8
00007cf1741dc39f  mulpd xmm5, xmm6
00007cf1741dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007cf1741dc3a8  ptest xmm3, xmm3
00007cf1741dc3ad  jnz 0x00007CF1741DF33B
00007cf1741dc3b3  vmovaps xmm8, [rsp+0x30]
00007cf1741dc3b9  vpermilpd xmm8, xmm8, 0x00
00007cf1741dc3bf  movaps xmm6, xmm10
00007cf1741dc3c3  mulpd xmm6, xmm8
00007cf1741dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007cf1741dc3cd  ptest xmm3, xmm3
00007cf1741dc3d2  jnz 0x00007CF1741DF47C
00007cf1741dc3d8  vmovaps xmm8, [rsp+0x60]
00007cf1741dc3de  movaps xmm10, xmm8
00007cf1741dc3e2  addpd xmm10, xmm14
00007cf1741dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007cf1741dc3ed  ptest xmm3, xmm3
00007cf1741dc3f2  jnz 0x00007CF1741DF5BE
00007cf1741dc3f8  vmovaps xmm8, [rsp+0x50]
00007cf1741dc3fe  movaps xmm14, xmm8
00007cf1741dc402  addpd xmm14, xmm4
00007cf1741dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007cf1741dc40d  ptest xmm3, xmm3
00007cf1741dc412  jnz 0x00007CF1741DF702
00007cf1741dc418  vmovaps xmm8, [rsp+0x40]
00007cf1741dc41e  vpermilpd xmm8, xmm8, 0x00
00007cf1741dc424  movaps xmm4, xmm13
00007cf1741dc428  mulpd xmm4, xmm8
00007cf1741dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007cf1741dc432  ptest xmm3, xmm3
00007cf1741dc437  jnz 0x00007CF1741DF845
00007cf1741dc43d  movaps xmm13, xmm15
00007cf1741dc441  addpd xmm13, xmm9
00007cf1741dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007cf1741dc44c  ptest xmm8, xmm8
00007cf1741dc452  jnz 0x00007CF1741DF987
00007cf1741dc458  movaps xmm15, xmm1
00007cf1741dc45c  addpd xmm15, xmm5
00007cf1741dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007cf1741dc467  ptest xmm9, xmm9
00007cf1741dc46d  jnz 0x00007CF1741DFACB
00007cf1741dc473  vmovaps [rsp+0x30], xmm11
00007cf1741dc479  vmovaps xmm1, [rsp+0x30]
00007cf1741dc47f  por xmm11, xmm1
00007cf1741dc484  movaps [r15+0x250], xmm11
00007cf1741dc48c  vmovaps [rsp+0x30], xmm12
00007cf1741dc492  vmovaps xmm1, [rsp+0x30]
00007cf1741dc498  por xmm12, xmm1
00007cf1741dc49d  movaps [r15+0x2A0], xmm12
00007cf1741dc4a5  vmovaps xmm1, [rsp+0xA0]
00007cf1741dc4ae  vmovaps xmm11, [rsp+0xA0]
00007cf1741dc4b7  por xmm1, xmm11
00007cf1741dc4bc  movaps [r15+0x1D0], xmm1
00007cf1741dc4c4  lea r12, [rax+0x40]
00007cf1741dc4c8  movups xmm1, [r13+r12*1]
00007cf1741dc4ce  movaps [r15+0x2C0], xmm1
00007cf1741dc4d6  vmovaps xmm11, [rsp+0x40]
00007cf1741dc4dc  vpermilpd xmm11, xmm11, 0x00
00007cf1741dc4e2  vmovaps xmm8, [rsp+0xE0]
00007cf1741dc4eb  movaps xmm9, xmm8
00007cf1741dc4ef  mulpd xmm9, xmm11
00007cf1741dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007cf1741dc4fa  ptest xmm5, xmm5
00007cf1741dc4ff  jnz 0x00007CF1741DFC17
00007cf1741dc505  movaps xmm11, xmm10
00007cf1741dc509  addpd xmm11, xmm6
00007cf1741dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007cf1741dc514  ptest xmm8, xmm8
00007cf1741dc51a  jnz 0x00007CF1741DFD5B
00007cf1741dc520  movaps xmm10, xmm14
00007cf1741dc524  addpd xmm10, xmm4
00007cf1741dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007cf1741dc52f  ptest xmm8, xmm8
00007cf1741dc535  jnz 0x00007CF1741DFE9E
00007cf1741dc53b  vmovaps xmm14, [rsp+0x40]
00007cf1741dc541  vpermilpd xmm14, xmm14, 0x00
00007cf1741dc547  movaps xmm8, xmm1
00007cf1741dc54b  mulpd xmm8, xmm14
00007cf1741dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007cf1741dc556  ptest xmm6, xmm6
00007cf1741dc55b  jnz 0x00007CF1741DFFE1
00007cf1741dc561  movaps xmm1, [r15+0x2B0]
00007cf1741dc569  vmovaps xmm14, [rsp+0x40]
00007cf1741dc56f  vpermilpd xmm14, xmm14, 0x00
00007cf1741dc575  movaps xmm6, xmm1
00007cf1741dc578  mulpd xmm6, xmm14
00007cf1741dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007cf1741dc582  ptest xmm5, xmm5
00007cf1741dc587  jnz 0x00007CF1741E0124
00007cf1741dc58d  vmovaps xmm1, [rsp+0x10]
00007cf1741dc593  vpermilpd xmm1, xmm1, 0x00
00007cf1741dc599  movaps xmm14, xmm12
00007cf1741dc59d  mulpd xmm14, xmm1
00007cf1741dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007cf1741dc5a8  ptest xmm5, xmm5
00007cf1741dc5ad  jnz 0x00007CF1741E0265
00007cf1741dc5b3  movaps xmm1, xmm13
00007cf1741dc5b7  addpd xmm1, xmm9
00007cf1741dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007cf1741dc5c1  ptest xmm12, xmm12
00007cf1741dc5c7  jnz 0x00007CF1741E03A8
00007cf1741dc5cd  vmovaps xmm13, [rsp+0x10]
00007cf1741dc5d3  vpermilpd xmm13, xmm13, 0x00
00007cf1741dc5d9  movaps xmm12, xmm7
00007cf1741dc5dd  mulpd xmm12, xmm13
00007cf1741dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007cf1741dc5e8  ptest xmm9, xmm9
00007cf1741dc5ee  jnz 0x00007CF1741E04EA
00007cf1741dc5f4  movaps xmm13, xmm15
00007cf1741dc5f8  addpd xmm13, xmm8
00007cf1741dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007cf1741dc603  ptest xmm9, xmm9
00007cf1741dc609  jnz 0x00007CF1741E062D
00007cf1741dc60f  movaps xmm15, [r15+0x290]
00007cf1741dc617  vmovaps xmm9, [rsp+0x10]
00007cf1741dc61d  vpermilpd xmm9, xmm9, 0x00
00007cf1741dc623  movaps xmm8, xmm15
00007cf1741dc627  mulpd xmm8, xmm9
00007cf1741dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007cf1741dc632  ptest xmm7, xmm7
00007cf1741dc637  jnz 0x00007CF1741E0771
00007cf1741dc63d  movaps xmm15, xmm11
00007cf1741dc641  addpd xmm15, xmm6
00007cf1741dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007cf1741dc64c  ptest xmm9, xmm9
00007cf1741dc652  jnz 0x00007CF1741E08B5
00007cf1741dc658  movaps xmm11, [r15+0x1E0]
00007cf1741dc660  vmovaps xmm9, [rsp+0x10]
00007cf1741dc666  vpermilpd xmm9, xmm9, 0x00
00007cf1741dc66c  movaps xmm7, xmm11
00007cf1741dc670  mulpd xmm7, xmm9
00007cf1741dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007cf1741dc67a  ptest xmm6, xmm6
00007cf1741dc67f  jnz 0x00007CF1741E09F8
00007cf1741dc685  movaps xmm11, xmm10
00007cf1741dc689  addpd xmm11, xmm14
00007cf1741dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007cf1741dc694  ptest xmm9, xmm9
00007cf1741dc69a  jnz 0x00007CF1741E0B3A
00007cf1741dc6a0  lea r12, [rax+0x70]
00007cf1741dc6a4  movups xmm14, [r13+r12*1]
00007cf1741dc6aa  movaps [r15+0x240], xmm14
00007cf1741dc6b2  movaps xmm10, xmm1
00007cf1741dc6b6  addpd xmm10, xmm12
00007cf1741dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007cf1741dc6c1  ptest xmm9, xmm9
00007cf1741dc6c7  jnz 0x00007CF1741E0C88
00007cf1741dc6cd  movaps [r15+0x170], xmm10
00007cf1741dc6d5  vmovaps xmm1, [rsp+0x20]
00007cf1741dc6db  vpermilpd xmm1, xmm1, 0x00
00007cf1741dc6e1  movaps xmm12, xmm14
00007cf1741dc6e5  mulpd xmm12, xmm1
00007cf1741dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007cf1741dc6f0  ptest xmm9, xmm9
00007cf1741dc6f6  jnz 0x00007CF1741E0DCB
00007cf1741dc6fc  vmovaps xmm1, [rsp+0x20]
00007cf1741dc702  vpermilpd xmm1, xmm1, 0x00
00007cf1741dc708  vmovaps xmm9, [rsp+0xB0]
00007cf1741dc711  movaps xmm14, xmm9
00007cf1741dc715  mulpd xmm14, xmm1
00007cf1741dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007cf1741dc720  ptest xmm6, xmm6
00007cf1741dc725  jnz 0x00007CF1741E0F0E
00007cf1741dc72b  movaps [r15+0x180], xmm14
00007cf1741dc733  movaps xmm1, xmm13
00007cf1741dc737  addpd xmm1, xmm8
00007cf1741dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007cf1741dc741  ptest xmm9, xmm9
00007cf1741dc747  jnz 0x00007CF1741E1051
00007cf1741dc74d  movaps [r15+0x210], xmm1
00007cf1741dc755  movups xmm13, [r13+rax*1]
00007cf1741dc75b  lea r12, [rax+0x10]
00007cf1741dc75f  movups xmm9, [r13+r12*1]
00007cf1741dc765  movaps [r15+0x230], xmm9
00007cf1741dc76d  movaps xmm8, xmm15
00007cf1741dc771  addpd xmm8, xmm7
00007cf1741dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007cf1741dc77c  ptest xmm6, xmm6
00007cf1741dc781  jnz 0x00007CF1741E11A7
00007cf1741dc787  movaps [r15+0x130], xmm8
00007cf1741dc78f  vmovaps xmm15, [rsp+0x20]
00007cf1741dc795  vpermilpd xmm15, xmm15, 0x00
00007cf1741dc79b  movaps xmm7, xmm9
00007cf1741dc79f  mulpd xmm7, xmm15
00007cf1741dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007cf1741dc7a9  ptest xmm6, xmm6
00007cf1741dc7ae  jnz 0x00007CF1741E12EA
00007cf1741dc7b4  movaps [r15+0x220], xmm7
00007cf1741dc7bc  vmovaps xmm15, [rsp+0x20]
00007cf1741dc7c2  vpermilpd xmm15, xmm15, 0x00
00007cf1741dc7c8  movaps xmm9, xmm13
00007cf1741dc7cc  mulpd xmm9, xmm15
00007cf1741dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007cf1741dc7d7  ptest xmm6, xmm6
00007cf1741dc7dc  jnz 0x00007CF1741E142C
00007cf1741dc7e2  movaps xmm15, xmm11
00007cf1741dc7e6  addpd xmm15, xmm12
00007cf1741dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007cf1741dc7f1  ptest xmm13, xmm13
00007cf1741dc7f7  jnz 0x00007CF1741E1570
00007cf1741dc7fd  movaps [r15+0x140], xmm15
00007cf1741dc805  movaps xmm13, xmm10
00007cf1741dc809  addpd xmm13, xmm14
00007cf1741dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007cf1741dc814  ptest xmm12, xmm12
00007cf1741dc81a  jnz 0x00007CF1741E16B4
00007cf1741dc820  movaps [r15+0x150], xmm13
00007cf1741dc828  movaps xmm14, xmm1
00007cf1741dc82c  addpd xmm14, xmm7
00007cf1741dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007cf1741dc837  ptest xmm12, xmm12
00007cf1741dc83d  jnz 0x00007CF1741E17F8
00007cf1741dc843  movaps [r15+0x160], xmm14
00007cf1741dc84b  movaps xmm1, xmm8
00007cf1741dc84f  addpd xmm1, xmm9
00007cf1741dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007cf1741dc859  ptest xmm12, xmm12
00007cf1741dc85f  jnz 0x00007CF1741E193A
00007cf1741dc865  movaps [r15+0x120], xmm1
00007cf1741dc86d  movups [r13+r14*1], xmm15
00007cf1741dc873  lea rax, [r14+0x10]
00007cf1741dc877  movups [r13+rax*1], xmm13
00007cf1741dc87d  lea rax, [r14+0x20]
00007cf1741dc881  movups [r13+rax*1], xmm14
00007cf1741dc887  lea rax, [r14+0x30]
00007cf1741dc88b  movups [r13+rax*1], xmm1
00007cf1741dc891  mov eax, [r15+0x108]
00007cf1741dc898  sahf
00007cf1741dc899  jnz 0x00007CF1741DC8CB
00007cf1741dc89b  cmp dword ptr [r15+0x318], 0x00
00007cf1741dc8a3  jz 0x00007CF1741DB900
00007cf1741dc8a9  nop [rax+rax*1], ax
00007cf1741dc8b2  nop [rax+rax*1], eax
00007cf1741dc8ba  mov eax, 0x410444
00007cf1741dc8bf  mov [r15+0x100], rax
00007cf1741dc8c6  jmp 0x00007CF173FFE110
00007cf1741dc8cb  cmp dword ptr [r15+0x318], 0x00
00007cf1741dc8d3  jz 0x00007CF1741D57E0
00007cf1741dc8d9  nop [rax+rax*1], ax
00007cf1741dc8e2  nop [rax+rax*1], eax
00007cf1741dc8ea  mov eax, 0x410278
00007cf1741dc8ef  mov [r15+0x100], rax
00007cf1741dc8f6  jmp 0x00007CF173FFE110
00007cf1741dc8fb  int3
00007cf1741dc8fc  call 0x00007CF1740E27E0
00007cf1741dc901  jmp 0x00007CF1741DB9DF
00007cf1741dc906  call 0x00007CF1740E1570
00007cf1741dc90b  jmp 0x00007CF1741DB9E8
00007cf1741dc910  call 0x00007CF1740E27E0
00007cf1741dc915  jmp 0x00007CF1741DBA44
00007cf1741dc91a  call 0x00007CF1740E1570
00007cf1741dc91f  jmp 0x00007CF1741DBA4D
00007cf1741dc924  call 0x00007CF1740E27E0
00007cf1741dc929  jmp 0x00007CF1741DBA90
00007cf1741dc92e  call 0x00007CF1740E1570
00007cf1741dc933  jmp 0x00007CF1741DBA99
00007cf1741dc938  call 0x00007CF17400DC20
00007cf1741dc93d  jmp 0x00007CF1741DBAD8
00007cf1741dc942  call 0x00007CF1740D59C0
00007cf1741dc947  jmp 0x00007CF1741DBAEB
00007cf1741dc94c  call 0x00007CF1740E0E30
00007cf1741dc951  jmp 0x00007CF1741DBB09
00007cf1741dc956  call 0x00007CF1740DFBC0
00007cf1741dc95b  jmp 0x00007CF1741DBB13
00007cf1741dc960  call 0x00007CF1740DE950
00007cf1741dc965  jmp 0x00007CF1741DBB1D
00007cf1741dc96a  sub rsp, 0x08
00007cf1741dc96e  push rax
00007cf1741dc96f  push rcx
00007cf1741dc970  push rdx
00007cf1741dc971  push rdi
00007cf1741dc972  push rsi
00007cf1741dc973  push r8
00007cf1741dc975  push r9
00007cf1741dc977  push r10
00007cf1741dc979  push r11
00007cf1741dc97b  sub rsp, 0xF0
00007cf1741dc982  vmovaps [rsp], xmm0
00007cf1741dc987  vmovaps [rsp+0x10], xmm1
00007cf1741dc98d  vmovaps [rsp+0x20], xmm2
00007cf1741dc993  vmovaps [rsp+0x30], xmm3
00007cf1741dc999  vmovaps [rsp+0x40], xmm4
00007cf1741dc99f  vmovaps [rsp+0x50], xmm5
00007cf1741dc9a5  vmovaps [rsp+0x60], xmm6
00007cf1741dc9ab  vmovaps [rsp+0x70], xmm7
00007cf1741dc9b1  vmovaps [rsp+0x80], xmm9
00007cf1741dc9ba  vmovaps [rsp+0x90], xmm10
00007cf1741dc9c3  vmovaps [rsp+0xA0], xmm11
00007cf1741dc9cc  vmovaps [rsp+0xB0], xmm12
00007cf1741dc9d5  vmovaps [rsp+0xC0], xmm13
00007cf1741dc9de  vmovaps [rsp+0xD0], xmm14
00007cf1741dc9e7  vmovaps [rsp+0xE0], xmm15
00007cf1741dc9f0  sub rsp, 0x30
00007cf1741dc9f4  movaps [rsp], xmm8
00007cf1741dc9f9  movaps [rsp+0x10], xmm12
00007cf1741dc9ff  movaps [rsp+0x20], xmm15
00007cf1741dca05  lea rdi, [rsp]
00007cf1741dca09  mov esi, 0x00
00007cf1741dca0e  mov rax, 0x611C8A33A530
00007cf1741dca18  call rax
00007cf1741dca1a  movaps xmm8, [rsp]
00007cf1741dca1f  add rsp, 0x30
00007cf1741dca23  vmovaps xmm0, [rsp]
00007cf1741dca28  vmovaps xmm1, [rsp+0x10]
00007cf1741dca2e  vmovaps xmm2, [rsp+0x20]
00007cf1741dca34  vmovaps xmm3, [rsp+0x30]
00007cf1741dca3a  vmovaps xmm4, [rsp+0x40]
00007cf1741dca40  vmovaps xmm5, [rsp+0x50]
00007cf1741dca46  vmovaps xmm6, [rsp+0x60]
00007cf1741dca4c  vmovaps xmm7, [rsp+0x70]
00007cf1741dca52  vmovaps xmm9, [rsp+0x80]
00007cf1741dca5b  vmovaps xmm10, [rsp+0x90]
00007cf1741dca64  vmovaps xmm11, [rsp+0xA0]
00007cf1741dca6d  vmovaps xmm12, [rsp+0xB0]
00007cf1741dca76  vmovaps xmm13, [rsp+0xC0]
00007cf1741dca7f  vmovaps xmm14, [rsp+0xD0]
00007cf1741dca88  vmovaps xmm15, [rsp+0xE0]
00007cf1741dca91  add rsp, 0xF0
00007cf1741dca98  pop r11
00007cf1741dca9a  pop r10
00007cf1741dca9c  pop r9
00007cf1741dca9e  pop r8
00007cf1741dcaa0  pop rsi
00007cf1741dcaa1  pop rdi
00007cf1741dcaa2  pop rdx
00007cf1741dcaa3  pop rcx
00007cf1741dcaa4  pop rax
00007cf1741dcaa5  add rsp, 0x08
00007cf1741dcaa9  jmp 0x00007CF1741DBB47
00007cf1741dcaae  sub rsp, 0x08
00007cf1741dcab2  push rax
00007cf1741dcab3  push rcx
00007cf1741dcab4  push rdx
00007cf1741dcab5  push rdi
00007cf1741dcab6  push rsi
00007cf1741dcab7  push r8
00007cf1741dcab9  push r9
00007cf1741dcabb  push r10
00007cf1741dcabd  push r11
00007cf1741dcabf  sub rsp, 0xF0
00007cf1741dcac6  vmovaps [rsp], xmm0
00007cf1741dcacb  vmovaps [rsp+0x10], xmm1
00007cf1741dcad1  vmovaps [rsp+0x20], xmm2
00007cf1741dcad7  vmovaps [rsp+0x30], xmm3
00007cf1741dcadd  vmovaps [rsp+0x40], xmm4
00007cf1741dcae3  vmovaps [rsp+0x50], xmm5
00007cf1741dcae9  vmovaps [rsp+0x60], xmm6
00007cf1741dcaef  vmovaps [rsp+0x70], xmm8
00007cf1741dcaf5  vmovaps [rsp+0x80], xmm9
00007cf1741dcafe  vmovaps [rsp+0x90], xmm10
00007cf1741dcb07  vmovaps [rsp+0xA0], xmm11
00007cf1741dcb10  vmovaps [rsp+0xB0], xmm12
00007cf1741dcb19  vmovaps [rsp+0xC0], xmm13
00007cf1741dcb22  vmovaps [rsp+0xD0], xmm14
00007cf1741dcb2b  vmovaps [rsp+0xE0], xmm15
00007cf1741dcb34  sub rsp, 0x30
00007cf1741dcb38  movaps [rsp], xmm7
00007cf1741dcb3c  movaps [rsp+0x10], xmm9
00007cf1741dcb42  movaps [rsp+0x20], xmm15
00007cf1741dcb48  lea rdi, [rsp]
00007cf1741dcb4c  mov esi, 0x00
00007cf1741dcb51  mov rax, 0x611C8A33A530
00007cf1741dcb5b  call rax
00007cf1741dcb5d  movaps xmm7, [rsp]
00007cf1741dcb61  add rsp, 0x30
00007cf1741dcb65  vmovaps xmm0, [rsp]
00007cf1741dcb6a  vmovaps xmm1, [rsp+0x10]
00007cf1741dcb70  vmovaps xmm2, [rsp+0x20]
00007cf1741dcb76  vmovaps xmm3, [rsp+0x30]
00007cf1741dcb7c  vmovaps xmm4, [rsp+0x40]
00007cf1741dcb82  vmovaps xmm5, [rsp+0x50]
00007cf1741dcb88  vmovaps xmm6, [rsp+0x60]
00007cf1741dcb8e  vmovaps xmm8, [rsp+0x70]
00007cf1741dcb94  vmovaps xmm9, [rsp+0x80]
00007cf1741dcb9d  vmovaps xmm10, [rsp+0x90]
00007cf1741dcba6  vmovaps xmm11, [rsp+0xA0]
00007cf1741dcbaf  vmovaps xmm12, [rsp+0xB0]
00007cf1741dcbb8  vmovaps xmm13, [rsp+0xC0]
00007cf1741dcbc1  vmovaps xmm14, [rsp+0xD0]
00007cf1741dcbca  vmovaps xmm15, [rsp+0xE0]
00007cf1741dcbd3  add rsp, 0xF0
00007cf1741dcbda  pop r11
00007cf1741dcbdc  pop r10
00007cf1741dcbde  pop r9
00007cf1741dcbe0  pop r8
00007cf1741dcbe2  pop rsi
00007cf1741dcbe3  pop rdi
00007cf1741dcbe4  pop rdx
00007cf1741dcbe5  pop rcx
00007cf1741dcbe6  pop rax
00007cf1741dcbe7  add rsp, 0x08
00007cf1741dcbeb  jmp 0x00007CF1741DBB75
00007cf1741dcbf0  sub rsp, 0x08
00007cf1741dcbf4  push rax
00007cf1741dcbf5  push rcx
00007cf1741dcbf6  push rdx
00007cf1741dcbf7  push rdi
00007cf1741dcbf8  push rsi
00007cf1741dcbf9  push r8
00007cf1741dcbfb  push r9
00007cf1741dcbfd  push r10
00007cf1741dcbff  push r11
00007cf1741dcc01  sub rsp, 0xF0
00007cf1741dcc08  vmovaps [rsp], xmm0
00007cf1741dcc0d  vmovaps [rsp+0x10], xmm1
00007cf1741dcc13  vmovaps [rsp+0x20], xmm2
00007cf1741dcc19  vmovaps [rsp+0x30], xmm3
00007cf1741dcc1f  vmovaps [rsp+0x40], xmm4
00007cf1741dcc25  vmovaps [rsp+0x50], xmm5
00007cf1741dcc2b  vmovaps [rsp+0x60], xmm6
00007cf1741dcc31  vmovaps [rsp+0x70], xmm7
00007cf1741dcc37  vmovaps [rsp+0x80], xmm8
00007cf1741dcc40  vmovaps [rsp+0x90], xmm10
00007cf1741dcc49  vmovaps [rsp+0xA0], xmm11
00007cf1741dcc52  vmovaps [rsp+0xB0], xmm12
00007cf1741dcc5b  vmovaps [rsp+0xC0], xmm13
00007cf1741dcc64  vmovaps [rsp+0xD0], xmm14
00007cf1741dcc6d  vmovaps [rsp+0xE0], xmm15
00007cf1741dcc76  sub rsp, 0x30
00007cf1741dcc7a  movaps [rsp], xmm9
00007cf1741dcc7f  movaps [rsp+0x10], xmm12
00007cf1741dcc85  movaps [rsp+0x20], xmm10
00007cf1741dcc8b  lea rdi, [rsp]
00007cf1741dcc8f  mov esi, 0x00
00007cf1741dcc94  mov rax, 0x611C8A33A530
00007cf1741dcc9e  call rax
00007cf1741dcca0  movaps xmm9, [rsp]
00007cf1741dcca5  add rsp, 0x30
00007cf1741dcca9  vmovaps xmm0, [rsp]
00007cf1741dccae  vmovaps xmm1, [rsp+0x10]
00007cf1741dccb4  vmovaps xmm2, [rsp+0x20]
00007cf1741dccba  vmovaps xmm3, [rsp+0x30]
00007cf1741dccc0  vmovaps xmm4, [rsp+0x40]
00007cf1741dccc6  vmovaps xmm5, [rsp+0x50]
00007cf1741dcccc  vmovaps xmm6, [rsp+0x60]
00007cf1741dccd2  vmovaps xmm7, [rsp+0x70]
00007cf1741dccd8  vmovaps xmm8, [rsp+0x80]
00007cf1741dcce1  vmovaps xmm10, [rsp+0x90]
00007cf1741dccea  vmovaps xmm11, [rsp+0xA0]
00007cf1741dccf3  vmovaps xmm12, [rsp+0xB0]
00007cf1741dccfc  vmovaps xmm13, [rsp+0xC0]
00007cf1741dcd05  vmovaps xmm14, [rsp+0xD0]
00007cf1741dcd0e  vmovaps xmm15, [rsp+0xE0]
00007cf1741dcd17  add rsp, 0xF0
00007cf1741dcd1e  pop r11
00007cf1741dcd20  pop r10
00007cf1741dcd22  pop r9
00007cf1741dcd24  pop r8
00007cf1741dcd26  pop rsi
00007cf1741dcd27  pop rdi
00007cf1741dcd28  pop rdx
00007cf1741dcd29  pop rcx
00007cf1741dcd2a  pop rax
00007cf1741dcd2b  add rsp, 0x08
00007cf1741dcd2f  jmp 0x00007CF1741DBB99
00007cf1741dcd34  sub rsp, 0x08
00007cf1741dcd38  push rax
00007cf1741dcd39  push rcx
00007cf1741dcd3a  push rdx
00007cf1741dcd3b  push rdi
00007cf1741dcd3c  push rsi
00007cf1741dcd3d  push r8
00007cf1741dcd3f  push r9
00007cf1741dcd41  push r10
00007cf1741dcd43  push r11
00007cf1741dcd45  sub rsp, 0xF0
00007cf1741dcd4c  vmovaps [rsp], xmm0
00007cf1741dcd51  vmovaps [rsp+0x10], xmm1
00007cf1741dcd57  vmovaps [rsp+0x20], xmm2
00007cf1741dcd5d  vmovaps [rsp+0x30], xmm3
00007cf1741dcd63  vmovaps [rsp+0x40], xmm4
00007cf1741dcd69  vmovaps [rsp+0x50], xmm5
00007cf1741dcd6f  vmovaps [rsp+0x60], xmm6
00007cf1741dcd75  vmovaps [rsp+0x70], xmm7
00007cf1741dcd7b  vmovaps [rsp+0x80], xmm8
00007cf1741dcd84  vmovaps [rsp+0x90], xmm9
00007cf1741dcd8d  vmovaps [rsp+0xA0], xmm11
00007cf1741dcd96  vmovaps [rsp+0xB0], xmm12
00007cf1741dcd9f  vmovaps [rsp+0xC0], xmm13
00007cf1741dcda8  vmovaps [rsp+0xD0], xmm14
00007cf1741dcdb1  vmovaps [rsp+0xE0], xmm15
00007cf1741dcdba  sub rsp, 0x30
00007cf1741dcdbe  movaps [rsp], xmm10
00007cf1741dcdc3  movaps [rsp+0x10], xmm12
00007cf1741dcdc9  movaps [rsp+0x20], xmm11
00007cf1741dcdcf  lea rdi, [rsp]
00007cf1741dcdd3  mov esi, 0x00
00007cf1741dcdd8  mov rax, 0x611C8A33A530
00007cf1741dcde2  call rax
00007cf1741dcde4  movaps xmm10, [rsp]
00007cf1741dcde9  add rsp, 0x30
00007cf1741dcded  vmovaps xmm0, [rsp]
00007cf1741dcdf2  vmovaps xmm1, [rsp+0x10]
00007cf1741dcdf8  vmovaps xmm2, [rsp+0x20]
00007cf1741dcdfe  vmovaps xmm3, [rsp+0x30]
00007cf1741dce04  vmovaps xmm4, [rsp+0x40]
00007cf1741dce0a  vmovaps xmm5, [rsp+0x50]
00007cf1741dce10  vmovaps xmm6, [rsp+0x60]
00007cf1741dce16  vmovaps xmm7, [rsp+0x70]
00007cf1741dce1c  vmovaps xmm8, [rsp+0x80]
00007cf1741dce25  vmovaps xmm9, [rsp+0x90]
00007cf1741dce2e  vmovaps xmm11, [rsp+0xA0]
00007cf1741dce37  vmovaps xmm12, [rsp+0xB0]
00007cf1741dce40  vmovaps xmm13, [rsp+0xC0]
00007cf1741dce49  vmovaps xmm14, [rsp+0xD0]
00007cf1741dce52  vmovaps xmm15, [rsp+0xE0]
00007cf1741dce5b  add rsp, 0xF0
00007cf1741dce62  pop r11
00007cf1741dce64  pop r10
00007cf1741dce66  pop r9
00007cf1741dce68  pop r8
00007cf1741dce6a  pop rsi
00007cf1741dce6b  pop rdi
00007cf1741dce6c  pop rdx
00007cf1741dce6d  pop rcx
00007cf1741dce6e  pop rax
00007cf1741dce6f  add rsp, 0x08
00007cf1741dce73  jmp 0x00007CF1741DBBB3
00007cf1741dce78  sub rsp, 0x08
00007cf1741dce7c  push rax
00007cf1741dce7d  push rcx
00007cf1741dce7e  push rdx
00007cf1741dce7f  push rdi
00007cf1741dce80  push rsi
00007cf1741dce81  push r8
00007cf1741dce83  push r9
00007cf1741dce85  push r10
00007cf1741dce87  push r11
00007cf1741dce89  sub rsp, 0xF0
00007cf1741dce90  vmovaps [rsp], xmm0
00007cf1741dce95  vmovaps [rsp+0x10], xmm1
00007cf1741dce9b  vmovaps [rsp+0x20], xmm2
00007cf1741dcea1  vmovaps [rsp+0x30], xmm3
00007cf1741dcea7  vmovaps [rsp+0x40], xmm4
00007cf1741dcead  vmovaps [rsp+0x50], xmm5
00007cf1741dceb3  vmovaps [rsp+0x60], xmm7
00007cf1741dceb9  vmovaps [rsp+0x70], xmm8
00007cf1741dcebf  vmovaps [rsp+0x80], xmm9
00007cf1741dcec8  vmovaps [rsp+0x90], xmm10
00007cf1741dced1  vmovaps [rsp+0xA0], xmm11
00007cf1741dceda  vmovaps [rsp+0xB0], xmm12
00007cf1741dcee3  vmovaps [rsp+0xC0], xmm13
00007cf1741dceec  vmovaps [rsp+0xD0], xmm14
00007cf1741dcef5  vmovaps [rsp+0xE0], xmm15
00007cf1741dcefe  sub rsp, 0x30
00007cf1741dcf02  movaps [rsp], xmm6
00007cf1741dcf06  movaps [rsp+0x10], xmm12
00007cf1741dcf0c  movaps [rsp+0x20], xmm11
00007cf1741dcf12  lea rdi, [rsp]
00007cf1741dcf16  mov esi, 0x00
00007cf1741dcf1b  mov rax, 0x611C8A33A530
00007cf1741dcf25  call rax
00007cf1741dcf27  movaps xmm6, [rsp]
00007cf1741dcf2b  add rsp, 0x30
00007cf1741dcf2f  vmovaps xmm0, [rsp]
00007cf1741dcf34  vmovaps xmm1, [rsp+0x10]
00007cf1741dcf3a  vmovaps xmm2, [rsp+0x20]
00007cf1741dcf40  vmovaps xmm3, [rsp+0x30]
00007cf1741dcf46  vmovaps xmm4, [rsp+0x40]
00007cf1741dcf4c  vmovaps xmm5, [rsp+0x50]
00007cf1741dcf52  vmovaps xmm7, [rsp+0x60]
00007cf1741dcf58  vmovaps xmm8, [rsp+0x70]
00007cf1741dcf5e  vmovaps xmm9, [rsp+0x80]
00007cf1741dcf67  vmovaps xmm10, [rsp+0x90]
00007cf1741dcf70  vmovaps xmm11, [rsp+0xA0]
00007cf1741dcf79  vmovaps xmm12, [rsp+0xB0]
00007cf1741dcf82  vmovaps xmm13, [rsp+0xC0]
00007cf1741dcf8b  vmovaps xmm14, [rsp+0xD0]
00007cf1741dcf94  vmovaps xmm15, [rsp+0xE0]
00007cf1741dcf9d  add rsp, 0xF0
00007cf1741dcfa4  pop r11
00007cf1741dcfa6  pop r10
00007cf1741dcfa8  pop r9
00007cf1741dcfaa  pop r8
00007cf1741dcfac  pop rsi
00007cf1741dcfad  pop rdi
00007cf1741dcfae  pop rdx
00007cf1741dcfaf  pop rcx
00007cf1741dcfb0  pop rax
00007cf1741dcfb1  add rsp, 0x08
00007cf1741dcfb5  jmp 0x00007CF1741DBBD4
00007cf1741dcfba  sub rsp, 0x08
00007cf1741dcfbe  push rax
00007cf1741dcfbf  push rcx
00007cf1741dcfc0  push rdx
00007cf1741dcfc1  push rdi
00007cf1741dcfc2  push rsi
00007cf1741dcfc3  push r8
00007cf1741dcfc5  push r9
00007cf1741dcfc7  push r10
00007cf1741dcfc9  push r11
00007cf1741dcfcb  sub rsp, 0xF0
00007cf1741dcfd2  vmovaps [rsp], xmm0
00007cf1741dcfd7  vmovaps [rsp+0x10], xmm1
00007cf1741dcfdd  vmovaps [rsp+0x20], xmm2
00007cf1741dcfe3  vmovaps [rsp+0x30], xmm4
00007cf1741dcfe9  vmovaps [rsp+0x40], xmm5
00007cf1741dcfef  vmovaps [rsp+0x50], xmm6
00007cf1741dcff5  vmovaps [rsp+0x60], xmm7
00007cf1741dcffb  vmovaps [rsp+0x70], xmm8
00007cf1741dd001  vmovaps [rsp+0x80], xmm9
00007cf1741dd00a  vmovaps [rsp+0x90], xmm10
00007cf1741dd013  vmovaps [rsp+0xA0], xmm11
00007cf1741dd01c  vmovaps [rsp+0xB0], xmm12
00007cf1741dd025  vmovaps [rsp+0xC0], xmm13
00007cf1741dd02e  vmovaps [rsp+0xD0], xmm14
00007cf1741dd037  vmovaps [rsp+0xE0], xmm15
00007cf1741dd040  sub rsp, 0x30
00007cf1741dd044  movaps [rsp], xmm3
00007cf1741dd048  movaps [rsp+0x10], xmm5
00007cf1741dd04d  movaps [rsp+0x20], xmm4
00007cf1741dd052  lea rdi, [rsp]
00007cf1741dd056  mov esi, 0x00
00007cf1741dd05b  mov rax, 0x611C8A33A530
00007cf1741dd065  call rax
00007cf1741dd067  movaps xmm3, [rsp]
00007cf1741dd06b  add rsp, 0x30
00007cf1741dd06f  vmovaps xmm0, [rsp]
00007cf1741dd074  vmovaps xmm1, [rsp+0x10]
00007cf1741dd07a  vmovaps xmm2, [rsp+0x20]
00007cf1741dd080  vmovaps xmm4, [rsp+0x30]
00007cf1741dd086  vmovaps xmm5, [rsp+0x40]
00007cf1741dd08c  vmovaps xmm6, [rsp+0x50]
00007cf1741dd092  vmovaps xmm7, [rsp+0x60]
00007cf1741dd098  vmovaps xmm8, [rsp+0x70]
00007cf1741dd09e  vmovaps xmm9, [rsp+0x80]
00007cf1741dd0a7  vmovaps xmm10, [rsp+0x90]
00007cf1741dd0b0  vmovaps xmm11, [rsp+0xA0]
00007cf1741dd0b9  vmovaps xmm12, [rsp+0xB0]
00007cf1741dd0c2  vmovaps xmm13, [rsp+0xC0]
00007cf1741dd0cb  vmovaps xmm14, [rsp+0xD0]
00007cf1741dd0d4  vmovaps xmm15, [rsp+0xE0]
00007cf1741dd0dd  add rsp, 0xF0
00007cf1741dd0e4  pop r11
00007cf1741dd0e6  pop r10
00007cf1741dd0e8  pop r9
00007cf1741dd0ea  pop r8
00007cf1741dd0ec  pop rsi
00007cf1741dd0ed  pop rdi
00007cf1741dd0ee  pop rdx
00007cf1741dd0ef  pop rcx
00007cf1741dd0f0  pop rax
00007cf1741dd0f1  add rsp, 0x08
00007cf1741dd0f5  jmp 0x00007CF1741DBC35
00007cf1741dd0fa  sub rsp, 0x08
00007cf1741dd0fe  push rax
00007cf1741dd0ff  push rcx
00007cf1741dd100  push rdx
00007cf1741dd101  push rdi
00007cf1741dd102  push rsi
00007cf1741dd103  push r8
00007cf1741dd105  push r9
00007cf1741dd107  push r10
00007cf1741dd109  push r11
00007cf1741dd10b  sub rsp, 0xF0
00007cf1741dd112  vmovaps [rsp], xmm0
00007cf1741dd117  vmovaps [rsp+0x10], xmm1
00007cf1741dd11d  vmovaps [rsp+0x20], xmm2
00007cf1741dd123  vmovaps [rsp+0x30], xmm3
00007cf1741dd129  vmovaps [rsp+0x40], xmm4
00007cf1741dd12f  vmovaps [rsp+0x50], xmm6
00007cf1741dd135  vmovaps [rsp+0x60], xmm7
00007cf1741dd13b  vmovaps [rsp+0x70], xmm8
00007cf1741dd141  vmovaps [rsp+0x80], xmm9
00007cf1741dd14a  vmovaps [rsp+0x90], xmm10
00007cf1741dd153  vmovaps [rsp+0xA0], xmm11
00007cf1741dd15c  vmovaps [rsp+0xB0], xmm12
00007cf1741dd165  vmovaps [rsp+0xC0], xmm13
00007cf1741dd16e  vmovaps [rsp+0xD0], xmm14
00007cf1741dd177  vmovaps [rsp+0xE0], xmm15
00007cf1741dd180  sub rsp, 0x30
00007cf1741dd184  movaps [rsp], xmm5
00007cf1741dd188  movaps [rsp+0x10], xmm8
00007cf1741dd18e  movaps [rsp+0x20], xmm15
00007cf1741dd194  lea rdi, [rsp]
00007cf1741dd198  mov esi, 0x00
00007cf1741dd19d  mov rax, 0x611C8A33A530
00007cf1741dd1a7  call rax
00007cf1741dd1a9  movaps xmm5, [rsp]
00007cf1741dd1ad  add rsp, 0x30
00007cf1741dd1b1  vmovaps xmm0, [rsp]
00007cf1741dd1b6  vmovaps xmm1, [rsp+0x10]
00007cf1741dd1bc  vmovaps xmm2, [rsp+0x20]
00007cf1741dd1c2  vmovaps xmm3, [rsp+0x30]
00007cf1741dd1c8  vmovaps xmm4, [rsp+0x40]
00007cf1741dd1ce  vmovaps xmm6, [rsp+0x50]
00007cf1741dd1d4  vmovaps xmm7, [rsp+0x60]
00007cf1741dd1da  vmovaps xmm8, [rsp+0x70]
00007cf1741dd1e0  vmovaps xmm9, [rsp+0x80]
00007cf1741dd1e9  vmovaps xmm10, [rsp+0x90]
00007cf1741dd1f2  vmovaps xmm11, [rsp+0xA0]
00007cf1741dd1fb  vmovaps xmm12, [rsp+0xB0]
00007cf1741dd204  vmovaps xmm13, [rsp+0xC0]
00007cf1741dd20d  vmovaps xmm14, [rsp+0xD0]
00007cf1741dd216  vmovaps xmm15, [rsp+0xE0]
00007cf1741dd21f  add rsp, 0xF0
00007cf1741dd226  pop r11
00007cf1741dd228  pop r10
00007cf1741dd22a  pop r9
00007cf1741dd22c  pop r8
00007cf1741dd22e  pop rsi
00007cf1741dd22f  pop rdi
00007cf1741dd230  pop rdx
00007cf1741dd231  pop rcx
00007cf1741dd232  pop rax
00007cf1741dd233  add rsp, 0x08
00007cf1741dd237  jmp 0x00007CF1741DBC73
00007cf1741dd23c  sub rsp, 0x08
00007cf1741dd240  push rax
00007cf1741dd241  push rcx
00007cf1741dd242  push rdx
00007cf1741dd243  push rdi
00007cf1741dd244  push rsi
00007cf1741dd245  push r8
00007cf1741dd247  push r9
00007cf1741dd249  push r10
00007cf1741dd24b  push r11
00007cf1741dd24d  sub rsp, 0xF0
00007cf1741dd254  vmovaps [rsp], xmm0
00007cf1741dd259  vmovaps [rsp+0x10], xmm1
00007cf1741dd25f  vmovaps [rsp+0x20], xmm2
00007cf1741dd265  vmovaps [rsp+0x30], xmm3
00007cf1741dd26b  vmovaps [rsp+0x40], xmm5
00007cf1741dd271  vmovaps [rsp+0x50], xmm6
00007cf1741dd277  vmovaps [rsp+0x60], xmm7
00007cf1741dd27d  vmovaps [rsp+0x70], xmm8
00007cf1741dd283  vmovaps [rsp+0x80], xmm9
00007cf1741dd28c  vmovaps [rsp+0x90], xmm10
00007cf1741dd295  vmovaps [rsp+0xA0], xmm11
00007cf1741dd29e  vmovaps [rsp+0xB0], xmm12
00007cf1741dd2a7  vmovaps [rsp+0xC0], xmm13
00007cf1741dd2b0  vmovaps [rsp+0xD0], xmm14
00007cf1741dd2b9  vmovaps [rsp+0xE0], xmm15
00007cf1741dd2c2  sub rsp, 0x30
00007cf1741dd2c6  movaps [rsp], xmm4
00007cf1741dd2ca  movaps [rsp+0x10], xmm9
00007cf1741dd2d0  movaps [rsp+0x20], xmm8
00007cf1741dd2d6  lea rdi, [rsp]
00007cf1741dd2da  mov esi, 0x00
00007cf1741dd2df  mov rax, 0x611C8A33A530
00007cf1741dd2e9  call rax
00007cf1741dd2eb  movaps xmm4, [rsp]
00007cf1741dd2ef  add rsp, 0x30
00007cf1741dd2f3  vmovaps xmm0, [rsp]
00007cf1741dd2f8  vmovaps xmm1, [rsp+0x10]
00007cf1741dd2fe  vmovaps xmm2, [rsp+0x20]
00007cf1741dd304  vmovaps xmm3, [rsp+0x30]
00007cf1741dd30a  vmovaps xmm5, [rsp+0x40]
00007cf1741dd310  vmovaps xmm6, [rsp+0x50]
00007cf1741dd316  vmovaps xmm7, [rsp+0x60]
00007cf1741dd31c  vmovaps xmm8, [rsp+0x70]
00007cf1741dd322  vmovaps xmm9, [rsp+0x80]
00007cf1741dd32b  vmovaps xmm10, [rsp+0x90]
00007cf1741dd334  vmovaps xmm11, [rsp+0xA0]
00007cf1741dd33d  vmovaps xmm12, [rsp+0xB0]
00007cf1741dd346  vmovaps xmm13, [rsp+0xC0]
00007cf1741dd34f  vmovaps xmm14, [rsp+0xD0]
00007cf1741dd358  vmovaps xmm15, [rsp+0xE0]
00007cf1741dd361  add rsp, 0xF0
00007cf1741dd368  pop r11
00007cf1741dd36a  pop r10
00007cf1741dd36c  pop r9
00007cf1741dd36e  pop r8
00007cf1741dd370  pop rsi
00007cf1741dd371  pop rdi
00007cf1741dd372  pop rdx
00007cf1741dd373  pop rcx
00007cf1741dd374  pop rax
00007cf1741dd375  add rsp, 0x08
00007cf1741dd379  jmp 0x00007CF1741DBC94
00007cf1741dd37e  sub rsp, 0x08
00007cf1741dd382  push rax
00007cf1741dd383  push rcx
00007cf1741dd384  push rdx
00007cf1741dd385  push rdi
00007cf1741dd386  push rsi
00007cf1741dd387  push r8
00007cf1741dd389  push r9
00007cf1741dd38b  push r10
00007cf1741dd38d  push r11
00007cf1741dd38f  sub rsp, 0xF0
00007cf1741dd396  vmovaps [rsp], xmm0
00007cf1741dd39b  vmovaps [rsp+0x10], xmm1
00007cf1741dd3a1  vmovaps [rsp+0x20], xmm2
00007cf1741dd3a7  vmovaps [rsp+0x30], xmm3
00007cf1741dd3ad  vmovaps [rsp+0x40], xmm4
00007cf1741dd3b3  vmovaps [rsp+0x50], xmm5
00007cf1741dd3b9  vmovaps [rsp+0x60], xmm6
00007cf1741dd3bf  vmovaps [rsp+0x70], xmm7
00007cf1741dd3c5  vmovaps [rsp+0x80], xmm8
00007cf1741dd3ce  vmovaps [rsp+0x90], xmm10
00007cf1741dd3d7  vmovaps [rsp+0xA0], xmm11
00007cf1741dd3e0  vmovaps [rsp+0xB0], xmm12
00007cf1741dd3e9  vmovaps [rsp+0xC0], xmm13
00007cf1741dd3f2  vmovaps [rsp+0xD0], xmm14
00007cf1741dd3fb  vmovaps [rsp+0xE0], xmm15
00007cf1741dd404  sub rsp, 0x30
00007cf1741dd408  movaps [rsp], xmm9
00007cf1741dd40d  movaps [rsp+0x10], xmm10
00007cf1741dd413  movaps [rsp+0x20], xmm8
00007cf1741dd419  lea rdi, [rsp]
00007cf1741dd41d  mov esi, 0x00
00007cf1741dd422  mov rax, 0x611C8A33A530
00007cf1741dd42c  call rax
00007cf1741dd42e  movaps xmm9, [rsp]
00007cf1741dd433  add rsp, 0x30
00007cf1741dd437  vmovaps xmm0, [rsp]
00007cf1741dd43c  vmovaps xmm1, [rsp+0x10]
00007cf1741dd442  vmovaps xmm2, [rsp+0x20]
00007cf1741dd448  vmovaps xmm3, [rsp+0x30]
00007cf1741dd44e  vmovaps xmm4, [rsp+0x40]
00007cf1741dd454  vmovaps xmm5, [rsp+0x50]
00007cf1741dd45a  vmovaps xmm6, [rsp+0x60]
00007cf1741dd460  vmovaps xmm7, [rsp+0x70]
00007cf1741dd466  vmovaps xmm8, [rsp+0x80]
00007cf1741dd46f  vmovaps xmm10, [rsp+0x90]
00007cf1741dd478  vmovaps xmm11, [rsp+0xA0]
00007cf1741dd481  vmovaps xmm12, [rsp+0xB0]
00007cf1741dd48a  vmovaps xmm13, [rsp+0xC0]
00007cf1741dd493  vmovaps xmm14, [rsp+0xD0]
00007cf1741dd49c  vmovaps xmm15, [rsp+0xE0]
00007cf1741dd4a5  add rsp, 0xF0
00007cf1741dd4ac  pop r11
00007cf1741dd4ae  pop r10
00007cf1741dd4b0  pop r9
00007cf1741dd4b2  pop r8
00007cf1741dd4b4  pop rsi
00007cf1741dd4b5  pop rdi
00007cf1741dd4b6  pop rdx
00007cf1741dd4b7  pop rcx
00007cf1741dd4b8  pop rax
00007cf1741dd4b9  add rsp, 0x08
00007cf1741dd4bd  jmp 0x00007CF1741DBCAE
00007cf1741dd4c2  call 0x00007CF1740B52F0
00007cf1741dd4c7  jmp 0x00007CF1741DBDC8
00007cf1741dd4cc  call 0x00007CF1740B52F0
00007cf1741dd4d1  jmp 0x00007CF1741DBDDE
00007cf1741dd4d6  sub rsp, 0x08
00007cf1741dd4da  push rax
00007cf1741dd4db  push rcx
00007cf1741dd4dc  push rdx
00007cf1741dd4dd  push rdi
00007cf1741dd4de  push rsi
00007cf1741dd4df  push r8
00007cf1741dd4e1  push r9
00007cf1741dd4e3  push r10
00007cf1741dd4e5  push r11
00007cf1741dd4e7  sub rsp, 0xF0
00007cf1741dd4ee  vmovaps [rsp], xmm0
00007cf1741dd4f3  vmovaps [rsp+0x10], xmm2
00007cf1741dd4f9  vmovaps [rsp+0x20], xmm3
00007cf1741dd4ff  vmovaps [rsp+0x30], xmm4
00007cf1741dd505  vmovaps [rsp+0x40], xmm5
00007cf1741dd50b  vmovaps [rsp+0x50], xmm6
00007cf1741dd511  vmovaps [rsp+0x60], xmm7
00007cf1741dd517  vmovaps [rsp+0x70], xmm8
00007cf1741dd51d  vmovaps [rsp+0x80], xmm9
00007cf1741dd526  vmovaps [rsp+0x90], xmm10
00007cf1741dd52f  vmovaps [rsp+0xA0], xmm11
00007cf1741dd538  vmovaps [rsp+0xB0], xmm12
00007cf1741dd541  vmovaps [rsp+0xC0], xmm13
00007cf1741dd54a  vmovaps [rsp+0xD0], xmm14
00007cf1741dd553  vmovaps [rsp+0xE0], xmm15
00007cf1741dd55c  sub rsp, 0x30
00007cf1741dd560  movaps [rsp], xmm1
00007cf1741dd564  movaps [rsp+0x10], xmm6
00007cf1741dd569  movaps [rsp+0x20], xmm15
00007cf1741dd56f  lea rdi, [rsp]
00007cf1741dd573  mov esi, 0x00
00007cf1741dd578  mov rax, 0x611C8A33A530
00007cf1741dd582  call rax
00007cf1741dd584  movaps xmm1, [rsp]
00007cf1741dd588  add rsp, 0x30
00007cf1741dd58c  vmovaps xmm0, [rsp]
00007cf1741dd591  vmovaps xmm2, [rsp+0x10]
00007cf1741dd597  vmovaps xmm3, [rsp+0x20]
00007cf1741dd59d  vmovaps xmm4, [rsp+0x30]
00007cf1741dd5a3  vmovaps xmm5, [rsp+0x40]
00007cf1741dd5a9  vmovaps xmm6, [rsp+0x50]
00007cf1741dd5af  vmovaps xmm7, [rsp+0x60]
00007cf1741dd5b5  vmovaps xmm8, [rsp+0x70]
00007cf1741dd5bb  vmovaps xmm9, [rsp+0x80]
00007cf1741dd5c4  vmovaps xmm10, [rsp+0x90]
00007cf1741dd5cd  vmovaps xmm11, [rsp+0xA0]
00007cf1741dd5d6  vmovaps xmm12, [rsp+0xB0]
00007cf1741dd5df  vmovaps xmm13, [rsp+0xC0]
00007cf1741dd5e8  vmovaps xmm14, [rsp+0xD0]
00007cf1741dd5f1  vmovaps xmm15, [rsp+0xE0]
00007cf1741dd5fa  add rsp, 0xF0
00007cf1741dd601  pop r11
00007cf1741dd603  pop r10
00007cf1741dd605  pop r9
00007cf1741dd607  pop r8
00007cf1741dd609  pop rsi
00007cf1741dd60a  pop rdi
00007cf1741dd60b  pop rdx
00007cf1741dd60c  pop rcx
00007cf1741dd60d  pop rax
00007cf1741dd60e  add rsp, 0x08
00007cf1741dd612  jmp 0x00007CF1741DBE1B
00007cf1741dd617  call 0x00007CF1740C4620
00007cf1741dd61c  jmp 0x00007CF1741DBE28
00007cf1741dd621  sub rsp, 0x08
00007cf1741dd625  push rax
00007cf1741dd626  push rcx
00007cf1741dd627  push rdx
00007cf1741dd628  push rdi
00007cf1741dd629  push rsi
00007cf1741dd62a  push r8
00007cf1741dd62c  push r9
00007cf1741dd62e  push r10
00007cf1741dd630  push r11
00007cf1741dd632  sub rsp, 0xF0
00007cf1741dd639  vmovaps [rsp], xmm0
00007cf1741dd63e  vmovaps [rsp+0x10], xmm1
00007cf1741dd644  vmovaps [rsp+0x20], xmm2
00007cf1741dd64a  vmovaps [rsp+0x30], xmm3
00007cf1741dd650  vmovaps [rsp+0x40], xmm4
00007cf1741dd656  vmovaps [rsp+0x50], xmm5
00007cf1741dd65c  vmovaps [rsp+0x60], xmm6
00007cf1741dd662  vmovaps [rsp+0x70], xmm7
00007cf1741dd668  vmovaps [rsp+0x80], xmm8
00007cf1741dd671  vmovaps [rsp+0x90], xmm9
00007cf1741dd67a  vmovaps [rsp+0xA0], xmm10
00007cf1741dd683  vmovaps [rsp+0xB0], xmm11
00007cf1741dd68c  vmovaps [rsp+0xC0], xmm12
00007cf1741dd695  vmovaps [rsp+0xD0], xmm13
00007cf1741dd69e  vmovaps [rsp+0xE0], xmm15
00007cf1741dd6a7  sub rsp, 0x30
00007cf1741dd6ab  movaps [rsp], xmm14
00007cf1741dd6b0  movaps [rsp+0x10], xmm4
00007cf1741dd6b5  movaps [rsp+0x20], xmm3
00007cf1741dd6ba  lea rdi, [rsp]
00007cf1741dd6be  mov esi, 0x00
00007cf1741dd6c3  mov rax, 0x611C8A33A530
00007cf1741dd6cd  call rax
00007cf1741dd6cf  movaps xmm14, [rsp]
00007cf1741dd6d4  add rsp, 0x30
00007cf1741dd6d8  vmovaps xmm0, [rsp]
00007cf1741dd6dd  vmovaps xmm1, [rsp+0x10]
00007cf1741dd6e3  vmovaps xmm2, [rsp+0x20]
00007cf1741dd6e9  vmovaps xmm3, [rsp+0x30]
00007cf1741dd6ef  vmovaps xmm4, [rsp+0x40]
00007cf1741dd6f5  vmovaps xmm5, [rsp+0x50]
00007cf1741dd6fb  vmovaps xmm6, [rsp+0x60]
00007cf1741dd701  vmovaps xmm7, [rsp+0x70]
00007cf1741dd707  vmovaps xmm8, [rsp+0x80]
00007cf1741dd710  vmovaps xmm9, [rsp+0x90]
00007cf1741dd719  vmovaps xmm10, [rsp+0xA0]
00007cf1741dd722  vmovaps xmm11, [rsp+0xB0]
00007cf1741dd72b  vmovaps xmm12, [rsp+0xC0]
00007cf1741dd734  vmovaps xmm13, [rsp+0xD0]
00007cf1741dd73d  vmovaps xmm15, [rsp+0xE0]
00007cf1741dd746  add rsp, 0xF0
00007cf1741dd74d  pop r11
00007cf1741dd74f  pop r10
00007cf1741dd751  pop r9
00007cf1741dd753  pop r8
00007cf1741dd755  pop rsi
00007cf1741dd756  pop rdi
00007cf1741dd757  pop rdx
00007cf1741dd758  pop rcx
00007cf1741dd759  pop rax
00007cf1741dd75a  add rsp, 0x08
00007cf1741dd75e  jmp 0x00007CF1741DBE42
00007cf1741dd763  sub rsp, 0x08
00007cf1741dd767  push rax
00007cf1741dd768  push rcx
00007cf1741dd769  push rdx
00007cf1741dd76a  push rdi
00007cf1741dd76b  push rsi
00007cf1741dd76c  push r8
00007cf1741dd76e  push r9
00007cf1741dd770  push r10
00007cf1741dd772  push r11
00007cf1741dd774  sub rsp, 0xF0
00007cf1741dd77b  vmovaps [rsp], xmm0
00007cf1741dd780  vmovaps [rsp+0x10], xmm1
00007cf1741dd786  vmovaps [rsp+0x20], xmm2
00007cf1741dd78c  vmovaps [rsp+0x30], xmm3
00007cf1741dd792  vmovaps [rsp+0x40], xmm4
00007cf1741dd798  vmovaps [rsp+0x50], xmm5
00007cf1741dd79e  vmovaps [rsp+0x60], xmm7
00007cf1741dd7a4  vmovaps [rsp+0x70], xmm8
00007cf1741dd7aa  vmovaps [rsp+0x80], xmm9
00007cf1741dd7b3  vmovaps [rsp+0x90], xmm10
00007cf1741dd7bc  vmovaps [rsp+0xA0], xmm11
00007cf1741dd7c5  vmovaps [rsp+0xB0], xmm12
00007cf1741dd7ce  vmovaps [rsp+0xC0], xmm13
00007cf1741dd7d7  vmovaps [rsp+0xD0], xmm14
00007cf1741dd7e0  vmovaps [rsp+0xE0], xmm15
00007cf1741dd7e9  sub rsp, 0x30
00007cf1741dd7ed  movaps [rsp], xmm6
00007cf1741dd7f1  movaps [rsp+0x10], xmm9
00007cf1741dd7f7  movaps [rsp+0x20], xmm7
00007cf1741dd7fc  lea rdi, [rsp]
00007cf1741dd800  mov esi, 0x00
00007cf1741dd805  mov rax, 0x611C8A33A530
00007cf1741dd80f  call rax
00007cf1741dd811  movaps xmm6, [rsp]
00007cf1741dd815  add rsp, 0x30
00007cf1741dd819  vmovaps xmm0, [rsp]
00007cf1741dd81e  vmovaps xmm1, [rsp+0x10]
00007cf1741dd824  vmovaps xmm2, [rsp+0x20]
00007cf1741dd82a  vmovaps xmm3, [rsp+0x30]
00007cf1741dd830  vmovaps xmm4, [rsp+0x40]
00007cf1741dd836  vmovaps xmm5, [rsp+0x50]
00007cf1741dd83c  vmovaps xmm7, [rsp+0x60]
00007cf1741dd842  vmovaps xmm8, [rsp+0x70]
00007cf1741dd848  vmovaps xmm9, [rsp+0x80]
00007cf1741dd851  vmovaps xmm10, [rsp+0x90]
00007cf1741dd85a  vmovaps xmm11, [rsp+0xA0]
00007cf1741dd863  vmovaps xmm12, [rsp+0xB0]
00007cf1741dd86c  vmovaps xmm13, [rsp+0xC0]
00007cf1741dd875  vmovaps xmm14, [rsp+0xD0]
00007cf1741dd87e  vmovaps xmm15, [rsp+0xE0]
00007cf1741dd887  add rsp, 0xF0
00007cf1741dd88e  pop r11
00007cf1741dd890  pop r10
00007cf1741dd892  pop r9
00007cf1741dd894  pop r8
00007cf1741dd896  pop rsi
00007cf1741dd897  pop rdi
00007cf1741dd898  pop rdx
00007cf1741dd899  pop rcx
00007cf1741dd89a  pop rax
00007cf1741dd89b  add rsp, 0x08
00007cf1741dd89f  jmp 0x00007CF1741DBE5A
00007cf1741dd8a4  sub rsp, 0x08
00007cf1741dd8a8  push rax
00007cf1741dd8a9  push rcx
00007cf1741dd8aa  push rdx
00007cf1741dd8ab  push rdi
00007cf1741dd8ac  push rsi
00007cf1741dd8ad  push r8
00007cf1741dd8af  push r9
00007cf1741dd8b1  push r10
00007cf1741dd8b3  push r11
00007cf1741dd8b5  sub rsp, 0xF0
00007cf1741dd8bc  vmovaps [rsp], xmm0
00007cf1741dd8c1  vmovaps [rsp+0x10], xmm1
00007cf1741dd8c7  vmovaps [rsp+0x20], xmm2
00007cf1741dd8cd  vmovaps [rsp+0x30], xmm3
00007cf1741dd8d3  vmovaps [rsp+0x40], xmm4
00007cf1741dd8d9  vmovaps [rsp+0x50], xmm5
00007cf1741dd8df  vmovaps [rsp+0x60], xmm6
00007cf1741dd8e5  vmovaps [rsp+0x70], xmm8
00007cf1741dd8eb  vmovaps [rsp+0x80], xmm9
00007cf1741dd8f4  vmovaps [rsp+0x90], xmm10
00007cf1741dd8fd  vmovaps [rsp+0xA0], xmm11
00007cf1741dd906  vmovaps [rsp+0xB0], xmm12
00007cf1741dd90f  vmovaps [rsp+0xC0], xmm13
00007cf1741dd918  vmovaps [rsp+0xD0], xmm14
00007cf1741dd921  vmovaps [rsp+0xE0], xmm15
00007cf1741dd92a  sub rsp, 0x30
00007cf1741dd92e  movaps [rsp], xmm7
00007cf1741dd932  movaps [rsp+0x10], xmm4
00007cf1741dd937  movaps [rsp+0x20], xmm9
00007cf1741dd93d  lea rdi, [rsp]
00007cf1741dd941  mov esi, 0x00
00007cf1741dd946  mov rax, 0x611C8A33A530
00007cf1741dd950  call rax
00007cf1741dd952  movaps xmm7, [rsp]
00007cf1741dd956  add rsp, 0x30
00007cf1741dd95a  vmovaps xmm0, [rsp]
00007cf1741dd95f  vmovaps xmm1, [rsp+0x10]
00007cf1741dd965  vmovaps xmm2, [rsp+0x20]
00007cf1741dd96b  vmovaps xmm3, [rsp+0x30]
00007cf1741dd971  vmovaps xmm4, [rsp+0x40]
00007cf1741dd977  vmovaps xmm5, [rsp+0x50]
00007cf1741dd97d  vmovaps xmm6, [rsp+0x60]
00007cf1741dd983  vmovaps xmm8, [rsp+0x70]
00007cf1741dd989  vmovaps xmm9, [rsp+0x80]
00007cf1741dd992  vmovaps xmm10, [rsp+0x90]
00007cf1741dd99b  vmovaps xmm11, [rsp+0xA0]
00007cf1741dd9a4  vmovaps xmm12, [rsp+0xB0]
00007cf1741dd9ad  vmovaps xmm13, [rsp+0xC0]
00007cf1741dd9b6  vmovaps xmm14, [rsp+0xD0]
00007cf1741dd9bf  vmovaps xmm15, [rsp+0xE0]
00007cf1741dd9c8  add rsp, 0xF0
00007cf1741dd9cf  pop r11
00007cf1741dd9d1  pop r10
00007cf1741dd9d3  pop r9
00007cf1741dd9d5  pop r8
00007cf1741dd9d7  pop rsi
00007cf1741dd9d8  pop rdi
00007cf1741dd9d9  pop rdx
00007cf1741dd9da  pop rcx
00007cf1741dd9db  pop rax
00007cf1741dd9dc  add rsp, 0x08
00007cf1741dd9e0  jmp 0x00007CF1741DBE87
00007cf1741dd9e5  sub rsp, 0x08
00007cf1741dd9e9  push rax
00007cf1741dd9ea  push rcx
00007cf1741dd9eb  push rdx
00007cf1741dd9ec  push rdi
00007cf1741dd9ed  push rsi
00007cf1741dd9ee  push r8
00007cf1741dd9f0  push r9
00007cf1741dd9f2  push r10
00007cf1741dd9f4  push r11
00007cf1741dd9f6  sub rsp, 0xF0
00007cf1741dd9fd  vmovaps [rsp], xmm0
00007cf1741dda02  vmovaps [rsp+0x10], xmm1
00007cf1741dda08  vmovaps [rsp+0x20], xmm2
00007cf1741dda0e  vmovaps [rsp+0x30], xmm3
00007cf1741dda14  vmovaps [rsp+0x40], xmm5
00007cf1741dda1a  vmovaps [rsp+0x50], xmm6
00007cf1741dda20  vmovaps [rsp+0x60], xmm7
00007cf1741dda26  vmovaps [rsp+0x70], xmm8
00007cf1741dda2c  vmovaps [rsp+0x80], xmm9
00007cf1741dda35  vmovaps [rsp+0x90], xmm10
00007cf1741dda3e  vmovaps [rsp+0xA0], xmm11
00007cf1741dda47  vmovaps [rsp+0xB0], xmm12
00007cf1741dda50  vmovaps [rsp+0xC0], xmm13
00007cf1741dda59  vmovaps [rsp+0xD0], xmm14
00007cf1741dda62  vmovaps [rsp+0xE0], xmm15
00007cf1741dda6b  sub rsp, 0x30
00007cf1741dda6f  movaps [rsp], xmm4
00007cf1741dda73  movaps [rsp+0x10], xmm15
00007cf1741dda79  movaps [rsp+0x20], xmm9
00007cf1741dda7f  lea rdi, [rsp]
00007cf1741dda83  mov esi, 0x00
00007cf1741dda88  mov rax, 0x611C8A33A530
00007cf1741dda92  call rax
00007cf1741dda94  movaps xmm4, [rsp]
00007cf1741dda98  add rsp, 0x30
00007cf1741dda9c  vmovaps xmm0, [rsp]
00007cf1741ddaa1  vmovaps xmm1, [rsp+0x10]
00007cf1741ddaa7  vmovaps xmm2, [rsp+0x20]
00007cf1741ddaad  vmovaps xmm3, [rsp+0x30]
00007cf1741ddab3  vmovaps xmm5, [rsp+0x40]
00007cf1741ddab9  vmovaps xmm6, [rsp+0x50]
00007cf1741ddabf  vmovaps xmm7, [rsp+0x60]
00007cf1741ddac5  vmovaps xmm8, [rsp+0x70]
00007cf1741ddacb  vmovaps xmm9, [rsp+0x80]
00007cf1741ddad4  vmovaps xmm10, [rsp+0x90]
00007cf1741ddadd  vmovaps xmm11, [rsp+0xA0]
00007cf1741ddae6  vmovaps xmm12, [rsp+0xB0]
00007cf1741ddaef  vmovaps xmm13, [rsp+0xC0]
00007cf1741ddaf8  vmovaps xmm14, [rsp+0xD0]
00007cf1741ddb01  vmovaps xmm15, [rsp+0xE0]
00007cf1741ddb0a  add rsp, 0xF0
00007cf1741ddb11  pop r11
00007cf1741ddb13  pop r10
00007cf1741ddb15  pop r9
00007cf1741ddb17  pop r8
00007cf1741ddb19  pop rsi
00007cf1741ddb1a  pop rdi
00007cf1741ddb1b  pop rdx
00007cf1741ddb1c  pop rcx
00007cf1741ddb1d  pop rax
00007cf1741ddb1e  add rsp, 0x08
00007cf1741ddb22  jmp 0x00007CF1741DBEAC
00007cf1741ddb27  call 0x00007CF1740C4620
00007cf1741ddb2c  jmp 0x00007CF1741DBEB9
00007cf1741ddb31  sub rsp, 0x08
00007cf1741ddb35  push rax
00007cf1741ddb36  push rcx
00007cf1741ddb37  push rdx
00007cf1741ddb38  push rdi
00007cf1741ddb39  push rsi
00007cf1741ddb3a  push r8
00007cf1741ddb3c  push r9
00007cf1741ddb3e  push r10
00007cf1741ddb40  push r11
00007cf1741ddb42  sub rsp, 0xF0
00007cf1741ddb49  vmovaps [rsp], xmm0
00007cf1741ddb4e  vmovaps [rsp+0x10], xmm1
00007cf1741ddb54  vmovaps [rsp+0x20], xmm2
00007cf1741ddb5a  vmovaps [rsp+0x30], xmm4
00007cf1741ddb60  vmovaps [rsp+0x40], xmm5
00007cf1741ddb66  vmovaps [rsp+0x50], xmm6
00007cf1741ddb6c  vmovaps [rsp+0x60], xmm7
00007cf1741ddb72  vmovaps [rsp+0x70], xmm8
00007cf1741ddb78  vmovaps [rsp+0x80], xmm9
00007cf1741ddb81  vmovaps [rsp+0x90], xmm10
00007cf1741ddb8a  vmovaps [rsp+0xA0], xmm11
00007cf1741ddb93  vmovaps [rsp+0xB0], xmm12
00007cf1741ddb9c  vmovaps [rsp+0xC0], xmm13
00007cf1741ddba5  vmovaps [rsp+0xD0], xmm14
00007cf1741ddbae  vmovaps [rsp+0xE0], xmm15
00007cf1741ddbb7  sub rsp, 0x30
00007cf1741ddbbb  movaps [rsp], xmm3
00007cf1741ddbbf  movaps [rsp+0x10], xmm1
00007cf1741ddbc4  movaps [rsp+0x20], xmm9
00007cf1741ddbca  lea rdi, [rsp]
00007cf1741ddbce  mov esi, 0x00
00007cf1741ddbd3  mov rax, 0x611C8A33A530
00007cf1741ddbdd  call rax
00007cf1741ddbdf  movaps xmm3, [rsp]
00007cf1741ddbe3  add rsp, 0x30
00007cf1741ddbe7  vmovaps xmm0, [rsp]
00007cf1741ddbec  vmovaps xmm1, [rsp+0x10]
00007cf1741ddbf2  vmovaps xmm2, [rsp+0x20]
00007cf1741ddbf8  vmovaps xmm4, [rsp+0x30]
00007cf1741ddbfe  vmovaps xmm5, [rsp+0x40]
00007cf1741ddc04  vmovaps xmm6, [rsp+0x50]
00007cf1741ddc0a  vmovaps xmm7, [rsp+0x60]
00007cf1741ddc10  vmovaps xmm8, [rsp+0x70]
00007cf1741ddc16  vmovaps xmm9, [rsp+0x80]
00007cf1741ddc1f  vmovaps xmm10, [rsp+0x90]
00007cf1741ddc28  vmovaps xmm11, [rsp+0xA0]
00007cf1741ddc31  vmovaps xmm12, [rsp+0xB0]
00007cf1741ddc3a  vmovaps xmm13, [rsp+0xC0]
00007cf1741ddc43  vmovaps xmm14, [rsp+0xD0]
00007cf1741ddc4c  vmovaps xmm15, [rsp+0xE0]
00007cf1741ddc55  add rsp, 0xF0
00007cf1741ddc5c  pop r11
00007cf1741ddc5e  pop r10
00007cf1741ddc60  pop r9
00007cf1741ddc62  pop r8
00007cf1741ddc64  pop rsi
00007cf1741ddc65  pop rdi
00007cf1741ddc66  pop rdx
00007cf1741ddc67  pop rcx
00007cf1741ddc68  pop rax
00007cf1741ddc69  add rsp, 0x08
00007cf1741ddc6d  jmp 0x00007CF1741DBEF6
00007cf1741ddc72  sub rsp, 0x08
00007cf1741ddc76  push rax
00007cf1741ddc77  push rcx
00007cf1741ddc78  push rdx
00007cf1741ddc79  push rdi
00007cf1741ddc7a  push rsi
00007cf1741ddc7b  push r8
00007cf1741ddc7d  push r9
00007cf1741ddc7f  push r10
00007cf1741ddc81  push r11
00007cf1741ddc83  sub rsp, 0xF0
00007cf1741ddc8a  vmovaps [rsp], xmm0
00007cf1741ddc8f  vmovaps [rsp+0x10], xmm2
00007cf1741ddc95  vmovaps [rsp+0x20], xmm3
00007cf1741ddc9b  vmovaps [rsp+0x30], xmm4
00007cf1741ddca1  vmovaps [rsp+0x40], xmm5
00007cf1741ddca7  vmovaps [rsp+0x50], xmm6
00007cf1741ddcad  vmovaps [rsp+0x60], xmm7
00007cf1741ddcb3  vmovaps [rsp+0x70], xmm8
00007cf1741ddcb9  vmovaps [rsp+0x80], xmm9
00007cf1741ddcc2  vmovaps [rsp+0x90], xmm10
00007cf1741ddccb  vmovaps [rsp+0xA0], xmm11
00007cf1741ddcd4  vmovaps [rsp+0xB0], xmm12
00007cf1741ddcdd  vmovaps [rsp+0xC0], xmm13
00007cf1741ddce6  vmovaps [rsp+0xD0], xmm14
00007cf1741ddcef  vmovaps [rsp+0xE0], xmm15
00007cf1741ddcf8  sub rsp, 0x30
00007cf1741ddcfc  movaps [rsp], xmm1
00007cf1741ddd00  movaps [rsp+0x10], xmm15
00007cf1741ddd06  movaps [rsp+0x20], xmm9
00007cf1741ddd0c  lea rdi, [rsp]
00007cf1741ddd10  mov esi, 0x00
00007cf1741ddd15  mov rax, 0x611C8A33A530
00007cf1741ddd1f  call rax
00007cf1741ddd21  movaps xmm1, [rsp]
00007cf1741ddd25  add rsp, 0x30
00007cf1741ddd29  vmovaps xmm0, [rsp]
00007cf1741ddd2e  vmovaps xmm2, [rsp+0x10]
00007cf1741ddd34  vmovaps xmm3, [rsp+0x20]
00007cf1741ddd3a  vmovaps xmm4, [rsp+0x30]
00007cf1741ddd40  vmovaps xmm5, [rsp+0x40]
00007cf1741ddd46  vmovaps xmm6, [rsp+0x50]
00007cf1741ddd4c  vmovaps xmm7, [rsp+0x60]
00007cf1741ddd52  vmovaps xmm8, [rsp+0x70]
00007cf1741ddd58  vmovaps xmm9, [rsp+0x80]
00007cf1741ddd61  vmovaps xmm10, [rsp+0x90]
00007cf1741ddd6a  vmovaps xmm11, [rsp+0xA0]
00007cf1741ddd73  vmovaps xmm12, [rsp+0xB0]
00007cf1741ddd7c  vmovaps xmm13, [rsp+0xC0]
00007cf1741ddd85  vmovaps xmm14, [rsp+0xD0]
00007cf1741ddd8e  vmovaps xmm15, [rsp+0xE0]
00007cf1741ddd97  add rsp, 0xF0
00007cf1741ddd9e  pop r11
00007cf1741ddda0  pop r10
00007cf1741ddda2  pop r9
00007cf1741ddda4  pop r8
00007cf1741ddda6  pop rsi
00007cf1741ddda7  pop rdi
00007cf1741ddda8  pop rdx
00007cf1741ddda9  pop rcx
00007cf1741dddaa  pop rax
00007cf1741dddab  add rsp, 0x08
00007cf1741dddaf  jmp 0x00007CF1741DBF7E
00007cf1741dddb4  call 0x00007CF1740C4620
00007cf1741dddb9  jmp 0x00007CF1741DBF8B
00007cf1741dddbe  sub rsp, 0x08
00007cf1741dddc2  push rax
00007cf1741dddc3  push rcx
00007cf1741dddc4  push rdx
00007cf1741dddc5  push rdi
00007cf1741dddc6  push rsi
00007cf1741dddc7  push r8
00007cf1741dddc9  push r9
00007cf1741dddcb  push r10
00007cf1741dddcd  push r11
00007cf1741dddcf  sub rsp, 0xF0
00007cf1741dddd6  vmovaps [rsp], xmm0
00007cf1741ddddb  vmovaps [rsp+0x10], xmm2
00007cf1741ddde1  vmovaps [rsp+0x20], xmm3
00007cf1741ddde7  vmovaps [rsp+0x30], xmm4
00007cf1741ddded  vmovaps [rsp+0x40], xmm5
00007cf1741dddf3  vmovaps [rsp+0x50], xmm6
00007cf1741dddf9  vmovaps [rsp+0x60], xmm7
00007cf1741dddff  vmovaps [rsp+0x70], xmm8
00007cf1741dde05  vmovaps [rsp+0x80], xmm9
00007cf1741dde0e  vmovaps [rsp+0x90], xmm10
00007cf1741dde17  vmovaps [rsp+0xA0], xmm11
00007cf1741dde20  vmovaps [rsp+0xB0], xmm12
00007cf1741dde29  vmovaps [rsp+0xC0], xmm13
00007cf1741dde32  vmovaps [rsp+0xD0], xmm14
00007cf1741dde3b  vmovaps [rsp+0xE0], xmm15
00007cf1741dde44  sub rsp, 0x30
00007cf1741dde48  movaps [rsp], xmm1
00007cf1741dde4c  movaps [rsp+0x10], xmm5
00007cf1741dde51  movaps [rsp+0x20], xmm7
00007cf1741dde56  lea rdi, [rsp]
00007cf1741dde5a  mov esi, 0x00
00007cf1741dde5f  mov rax, 0x611C8A33A530
00007cf1741dde69  call rax
00007cf1741dde6b  movaps xmm1, [rsp]
00007cf1741dde6f  add rsp, 0x30
00007cf1741dde73  vmovaps xmm0, [rsp]
00007cf1741dde78  vmovaps xmm2, [rsp+0x10]
00007cf1741dde7e  vmovaps xmm3, [rsp+0x20]
00007cf1741dde84  vmovaps xmm4, [rsp+0x30]
00007cf1741dde8a  vmovaps xmm5, [rsp+0x40]
00007cf1741dde90  vmovaps xmm6, [rsp+0x50]
00007cf1741dde96  vmovaps xmm7, [rsp+0x60]
00007cf1741dde9c  vmovaps xmm8, [rsp+0x70]
00007cf1741ddea2  vmovaps xmm9, [rsp+0x80]
00007cf1741ddeab  vmovaps xmm10, [rsp+0x90]
00007cf1741ddeb4  vmovaps xmm11, [rsp+0xA0]
00007cf1741ddebd  vmovaps xmm12, [rsp+0xB0]
00007cf1741ddec6  vmovaps xmm13, [rsp+0xC0]
00007cf1741ddecf  vmovaps xmm14, [rsp+0xD0]
00007cf1741dded8  vmovaps xmm15, [rsp+0xE0]
00007cf1741ddee1  add rsp, 0xF0
00007cf1741ddee8  pop r11
00007cf1741ddeea  pop r10
00007cf1741ddeec  pop r9
00007cf1741ddeee  pop r8
00007cf1741ddef0  pop rsi
00007cf1741ddef1  pop rdi
00007cf1741ddef2  pop rdx
00007cf1741ddef3  pop rcx
00007cf1741ddef4  pop rax
00007cf1741ddef5  add rsp, 0x08
00007cf1741ddef9  jmp 0x00007CF1741DC030
00007cf1741ddefe  sub rsp, 0x08
00007cf1741ddf02  push rax
00007cf1741ddf03  push rcx
00007cf1741ddf04  push rdx
00007cf1741ddf05  push rdi
00007cf1741ddf06  push rsi
00007cf1741ddf07  push r8
00007cf1741ddf09  push r9
00007cf1741ddf0b  push r10
00007cf1741ddf0d  push r11
00007cf1741ddf0f  sub rsp, 0xF0
00007cf1741ddf16  vmovaps [rsp], xmm0
00007cf1741ddf1b  vmovaps [rsp+0x10], xmm1
00007cf1741ddf21  vmovaps [rsp+0x20], xmm2
00007cf1741ddf27  vmovaps [rsp+0x30], xmm3
00007cf1741ddf2d  vmovaps [rsp+0x40], xmm4
00007cf1741ddf33  vmovaps [rsp+0x50], xmm5
00007cf1741ddf39  vmovaps [rsp+0x60], xmm6
00007cf1741ddf3f  vmovaps [rsp+0x70], xmm8
00007cf1741ddf45  vmovaps [rsp+0x80], xmm9
00007cf1741ddf4e  vmovaps [rsp+0x90], xmm10
00007cf1741ddf57  vmovaps [rsp+0xA0], xmm11
00007cf1741ddf60  vmovaps [rsp+0xB0], xmm12
00007cf1741ddf69  vmovaps [rsp+0xC0], xmm13
00007cf1741ddf72  vmovaps [rsp+0xD0], xmm14
00007cf1741ddf7b  vmovaps [rsp+0xE0], xmm15
00007cf1741ddf84  sub rsp, 0x30
00007cf1741ddf88  movaps [rsp], xmm7
00007cf1741ddf8c  movaps [rsp+0x10], xmm5
00007cf1741ddf91  movaps [rsp+0x20], xmm15
00007cf1741ddf97  lea rdi, [rsp]
00007cf1741ddf9b  mov esi, 0x00
00007cf1741ddfa0  mov rax, 0x611C8A33A530
00007cf1741ddfaa  call rax
00007cf1741ddfac  movaps xmm7, [rsp]
00007cf1741ddfb0  add rsp, 0x30
00007cf1741ddfb4  vmovaps xmm0, [rsp]
00007cf1741ddfb9  vmovaps xmm1, [rsp+0x10]
00007cf1741ddfbf  vmovaps xmm2, [rsp+0x20]
00007cf1741ddfc5  vmovaps xmm3, [rsp+0x30]
00007cf1741ddfcb  vmovaps xmm4, [rsp+0x40]
00007cf1741ddfd1  vmovaps xmm5, [rsp+0x50]
00007cf1741ddfd7  vmovaps xmm6, [rsp+0x60]
00007cf1741ddfdd  vmovaps xmm8, [rsp+0x70]
00007cf1741ddfe3  vmovaps xmm9, [rsp+0x80]
00007cf1741ddfec  vmovaps xmm10, [rsp+0x90]
00007cf1741ddff5  vmovaps xmm11, [rsp+0xA0]
00007cf1741ddffe  vmovaps xmm12, [rsp+0xB0]
00007cf1741de007  vmovaps xmm13, [rsp+0xC0]
00007cf1741de010  vmovaps xmm14, [rsp+0xD0]
00007cf1741de019  vmovaps xmm15, [rsp+0xE0]
00007cf1741de022  add rsp, 0xF0
00007cf1741de029  pop r11
00007cf1741de02b  pop r10
00007cf1741de02d  pop r9
00007cf1741de02f  pop r8
00007cf1741de031  pop rsi
00007cf1741de032  pop rdi
00007cf1741de033  pop rdx
00007cf1741de034  pop rcx
00007cf1741de035  pop rax
00007cf1741de036  add rsp, 0x08
00007cf1741de03a  jmp 0x00007CF1741DC066
00007cf1741de03f  call 0x00007CF1740B52F0
00007cf1741de044  jmp 0x00007CF1741DC073
00007cf1741de049  sub rsp, 0x08
00007cf1741de04d  push rax
00007cf1741de04e  push rcx
00007cf1741de04f  push rdx
00007cf1741de050  push rdi
00007cf1741de051  push rsi
00007cf1741de052  push r8
00007cf1741de054  push r9
00007cf1741de056  push r10
00007cf1741de058  push r11
00007cf1741de05a  sub rsp, 0xF0
00007cf1741de061  vmovaps [rsp], xmm0
00007cf1741de066  vmovaps [rsp+0x10], xmm1
00007cf1741de06c  vmovaps [rsp+0x20], xmm2
00007cf1741de072  vmovaps [rsp+0x30], xmm3
00007cf1741de078  vmovaps [rsp+0x40], xmm4
00007cf1741de07e  vmovaps [rsp+0x50], xmm5
00007cf1741de084  vmovaps [rsp+0x60], xmm6
00007cf1741de08a  vmovaps [rsp+0x70], xmm7
00007cf1741de090  vmovaps [rsp+0x80], xmm8
00007cf1741de099  vmovaps [rsp+0x90], xmm9
00007cf1741de0a2  vmovaps [rsp+0xA0], xmm10
00007cf1741de0ab  vmovaps [rsp+0xB0], xmm11
00007cf1741de0b4  vmovaps [rsp+0xC0], xmm12
00007cf1741de0bd  vmovaps [rsp+0xD0], xmm13
00007cf1741de0c6  vmovaps [rsp+0xE0], xmm14
00007cf1741de0cf  sub rsp, 0x30
00007cf1741de0d3  movaps [rsp], xmm15
00007cf1741de0d8  movaps [rsp+0x10], xmm5
00007cf1741de0dd  movaps [rsp+0x20], xmm3
00007cf1741de0e2  lea rdi, [rsp]
00007cf1741de0e6  mov esi, 0x00
00007cf1741de0eb  mov rax, 0x611C8A33A530
00007cf1741de0f5  call rax
00007cf1741de0f7  movaps xmm15, [rsp]
00007cf1741de0fc  add rsp, 0x30
00007cf1741de100  vmovaps xmm0, [rsp]
00007cf1741de105  vmovaps xmm1, [rsp+0x10]
00007cf1741de10b  vmovaps xmm2, [rsp+0x20]
00007cf1741de111  vmovaps xmm3, [rsp+0x30]
00007cf1741de117  vmovaps xmm4, [rsp+0x40]
00007cf1741de11d  vmovaps xmm5, [rsp+0x50]
00007cf1741de123  vmovaps xmm6, [rsp+0x60]
00007cf1741de129  vmovaps xmm7, [rsp+0x70]
00007cf1741de12f  vmovaps xmm8, [rsp+0x80]
00007cf1741de138  vmovaps xmm9, [rsp+0x90]
00007cf1741de141  vmovaps xmm10, [rsp+0xA0]
00007cf1741de14a  vmovaps xmm11, [rsp+0xB0]
00007cf1741de153  vmovaps xmm12, [rsp+0xC0]
00007cf1741de15c  vmovaps xmm13, [rsp+0xD0]
00007cf1741de165  vmovaps xmm14, [rsp+0xE0]
00007cf1741de16e  add rsp, 0xF0
00007cf1741de175  pop r11
00007cf1741de177  pop r10
00007cf1741de179  pop r9
00007cf1741de17b  pop r8
00007cf1741de17d  pop rsi
00007cf1741de17e  pop rdi
00007cf1741de17f  pop rdx
00007cf1741de180  pop rcx
00007cf1741de181  pop rax
00007cf1741de182  add rsp, 0x08
00007cf1741de186  jmp 0x00007CF1741DC099
00007cf1741de18b  sub rsp, 0x08
00007cf1741de18f  push rax
00007cf1741de190  push rcx
00007cf1741de191  push rdx
00007cf1741de192  push rdi
00007cf1741de193  push rsi
00007cf1741de194  push r8
00007cf1741de196  push r9
00007cf1741de198  push r10
00007cf1741de19a  push r11
00007cf1741de19c  sub rsp, 0xF0
00007cf1741de1a3  vmovaps [rsp], xmm0
00007cf1741de1a8  vmovaps [rsp+0x10], xmm2
00007cf1741de1ae  vmovaps [rsp+0x20], xmm3
00007cf1741de1b4  vmovaps [rsp+0x30], xmm4
00007cf1741de1ba  vmovaps [rsp+0x40], xmm5
00007cf1741de1c0  vmovaps [rsp+0x50], xmm6
00007cf1741de1c6  vmovaps [rsp+0x60], xmm7
00007cf1741de1cc  vmovaps [rsp+0x70], xmm8
00007cf1741de1d2  vmovaps [rsp+0x80], xmm9
00007cf1741de1db  vmovaps [rsp+0x90], xmm10
00007cf1741de1e4  vmovaps [rsp+0xA0], xmm11
00007cf1741de1ed  vmovaps [rsp+0xB0], xmm12
00007cf1741de1f6  vmovaps [rsp+0xC0], xmm13
00007cf1741de1ff  vmovaps [rsp+0xD0], xmm14
00007cf1741de208  vmovaps [rsp+0xE0], xmm15
00007cf1741de211  sub rsp, 0x30
00007cf1741de215  movaps [rsp], xmm1
00007cf1741de219  movaps [rsp+0x10], xmm5
00007cf1741de21e  movaps [rsp+0x20], xmm4
00007cf1741de223  lea rdi, [rsp]
00007cf1741de227  mov esi, 0x00
00007cf1741de22c  mov rax, 0x611C8A33A530
00007cf1741de236  call rax
00007cf1741de238  movaps xmm1, [rsp]
00007cf1741de23c  add rsp, 0x30
00007cf1741de240  vmovaps xmm0, [rsp]
00007cf1741de245  vmovaps xmm2, [rsp+0x10]
00007cf1741de24b  vmovaps xmm3, [rsp+0x20]
00007cf1741de251  vmovaps xmm4, [rsp+0x30]
00007cf1741de257  vmovaps xmm5, [rsp+0x40]
00007cf1741de25d  vmovaps xmm6, [rsp+0x50]
00007cf1741de263  vmovaps xmm7, [rsp+0x60]
00007cf1741de269  vmovaps xmm8, [rsp+0x70]
00007cf1741de26f  vmovaps xmm9, [rsp+0x80]
00007cf1741de278  vmovaps xmm10, [rsp+0x90]
00007cf1741de281  vmovaps xmm11, [rsp+0xA0]
00007cf1741de28a  vmovaps xmm12, [rsp+0xB0]
00007cf1741de293  vmovaps xmm13, [rsp+0xC0]
00007cf1741de29c  vmovaps xmm14, [rsp+0xD0]
00007cf1741de2a5  vmovaps xmm15, [rsp+0xE0]
00007cf1741de2ae  add rsp, 0xF0
00007cf1741de2b5  pop r11
00007cf1741de2b7  pop r10
00007cf1741de2b9  pop r9
00007cf1741de2bb  pop r8
00007cf1741de2bd  pop rsi
00007cf1741de2be  pop rdi
00007cf1741de2bf  pop rdx
00007cf1741de2c0  pop rcx
00007cf1741de2c1  pop rax
00007cf1741de2c2  add rsp, 0x08
00007cf1741de2c6  jmp 0x00007CF1741DC0B9
00007cf1741de2cb  sub rsp, 0x08
00007cf1741de2cf  push rax
00007cf1741de2d0  push rcx
00007cf1741de2d1  push rdx
00007cf1741de2d2  push rdi
00007cf1741de2d3  push rsi
00007cf1741de2d4  push r8
00007cf1741de2d6  push r9
00007cf1741de2d8  push r10
00007cf1741de2da  push r11
00007cf1741de2dc  sub rsp, 0xF0
00007cf1741de2e3  vmovaps [rsp], xmm0
00007cf1741de2e8  vmovaps [rsp+0x10], xmm1
00007cf1741de2ee  vmovaps [rsp+0x20], xmm2
00007cf1741de2f4  vmovaps [rsp+0x30], xmm3
00007cf1741de2fa  vmovaps [rsp+0x40], xmm5
00007cf1741de300  vmovaps [rsp+0x50], xmm6
00007cf1741de306  vmovaps [rsp+0x60], xmm7
00007cf1741de30c  vmovaps [rsp+0x70], xmm8
00007cf1741de312  vmovaps [rsp+0x80], xmm9
00007cf1741de31b  vmovaps [rsp+0x90], xmm10
00007cf1741de324  vmovaps [rsp+0xA0], xmm11
00007cf1741de32d  vmovaps [rsp+0xB0], xmm12
00007cf1741de336  vmovaps [rsp+0xC0], xmm13
00007cf1741de33f  vmovaps [rsp+0xD0], xmm14
00007cf1741de348  vmovaps [rsp+0xE0], xmm15
00007cf1741de351  sub rsp, 0x30
00007cf1741de355  movaps [rsp], xmm4
00007cf1741de359  movaps [rsp+0x10], xmm3
00007cf1741de35e  movaps [rsp+0x20], xmm5
00007cf1741de363  lea rdi, [rsp]
00007cf1741de367  mov esi, 0x00
00007cf1741de36c  mov rax, 0x611C8A33A530
00007cf1741de376  call rax
00007cf1741de378  movaps xmm4, [rsp]
00007cf1741de37c  add rsp, 0x30
00007cf1741de380  vmovaps xmm0, [rsp]
00007cf1741de385  vmovaps xmm1, [rsp+0x10]
00007cf1741de38b  vmovaps xmm2, [rsp+0x20]
00007cf1741de391  vmovaps xmm3, [rsp+0x30]
00007cf1741de397  vmovaps xmm5, [rsp+0x40]
00007cf1741de39d  vmovaps xmm6, [rsp+0x50]
00007cf1741de3a3  vmovaps xmm7, [rsp+0x60]
00007cf1741de3a9  vmovaps xmm8, [rsp+0x70]
00007cf1741de3af  vmovaps xmm9, [rsp+0x80]
00007cf1741de3b8  vmovaps xmm10, [rsp+0x90]
00007cf1741de3c1  vmovaps xmm11, [rsp+0xA0]
00007cf1741de3ca  vmovaps xmm12, [rsp+0xB0]
00007cf1741de3d3  vmovaps xmm13, [rsp+0xC0]
00007cf1741de3dc  vmovaps xmm14, [rsp+0xD0]
00007cf1741de3e5  vmovaps xmm15, [rsp+0xE0]
00007cf1741de3ee  add rsp, 0xF0
00007cf1741de3f5  pop r11
00007cf1741de3f7  pop r10
00007cf1741de3f9  pop r9
00007cf1741de3fb  pop r8
00007cf1741de3fd  pop rsi
00007cf1741de3fe  pop rdi
00007cf1741de3ff  pop rdx
00007cf1741de400  pop rcx
00007cf1741de401  pop rax
00007cf1741de402  add rsp, 0x08
00007cf1741de406  jmp 0x00007CF1741DC107
00007cf1741de40b  call 0x00007CF1740B52F0
00007cf1741de410  jmp 0x00007CF1741DC114
00007cf1741de415  sub rsp, 0x08
00007cf1741de419  push rax
00007cf1741de41a  push rcx
00007cf1741de41b  push rdx
00007cf1741de41c  push rdi
00007cf1741de41d  push rsi
00007cf1741de41e  push r8
00007cf1741de420  push r9
00007cf1741de422  push r10
00007cf1741de424  push r11
00007cf1741de426  sub rsp, 0xF0
00007cf1741de42d  vmovaps [rsp], xmm0
00007cf1741de432  vmovaps [rsp+0x10], xmm1
00007cf1741de438  vmovaps [rsp+0x20], xmm2
00007cf1741de43e  vmovaps [rsp+0x30], xmm3
00007cf1741de444  vmovaps [rsp+0x40], xmm4
00007cf1741de44a  vmovaps [rsp+0x50], xmm6
00007cf1741de450  vmovaps [rsp+0x60], xmm7
00007cf1741de456  vmovaps [rsp+0x70], xmm8
00007cf1741de45c  vmovaps [rsp+0x80], xmm9
00007cf1741de465  vmovaps [rsp+0x90], xmm10
00007cf1741de46e  vmovaps [rsp+0xA0], xmm11
00007cf1741de477  vmovaps [rsp+0xB0], xmm12
00007cf1741de480  vmovaps [rsp+0xC0], xmm13
00007cf1741de489  vmovaps [rsp+0xD0], xmm14
00007cf1741de492  vmovaps [rsp+0xE0], xmm15
00007cf1741de49b  sub rsp, 0x30
00007cf1741de49f  movaps [rsp], xmm5
00007cf1741de4a3  movaps [rsp+0x10], xmm6
00007cf1741de4a8  movaps [rsp+0x20], xmm3
00007cf1741de4ad  lea rdi, [rsp]
00007cf1741de4b1  mov esi, 0x00
00007cf1741de4b6  mov rax, 0x611C8A33A530
00007cf1741de4c0  call rax
00007cf1741de4c2  movaps xmm5, [rsp]
00007cf1741de4c6  add rsp, 0x30
00007cf1741de4ca  vmovaps xmm0, [rsp]
00007cf1741de4cf  vmovaps xmm1, [rsp+0x10]
00007cf1741de4d5  vmovaps xmm2, [rsp+0x20]
00007cf1741de4db  vmovaps xmm3, [rsp+0x30]
00007cf1741de4e1  vmovaps xmm4, [rsp+0x40]
00007cf1741de4e7  vmovaps xmm6, [rsp+0x50]
00007cf1741de4ed  vmovaps xmm7, [rsp+0x60]
00007cf1741de4f3  vmovaps xmm8, [rsp+0x70]
00007cf1741de4f9  vmovaps xmm9, [rsp+0x80]
00007cf1741de502  vmovaps xmm10, [rsp+0x90]
00007cf1741de50b  vmovaps xmm11, [rsp+0xA0]
00007cf1741de514  vmovaps xmm12, [rsp+0xB0]
00007cf1741de51d  vmovaps xmm13, [rsp+0xC0]
00007cf1741de526  vmovaps xmm14, [rsp+0xD0]
00007cf1741de52f  vmovaps xmm15, [rsp+0xE0]
00007cf1741de538  add rsp, 0xF0
00007cf1741de53f  pop r11
00007cf1741de541  pop r10
00007cf1741de543  pop r9
00007cf1741de545  pop r8
00007cf1741de547  pop rsi
00007cf1741de548  pop rdi
00007cf1741de549  pop rdx
00007cf1741de54a  pop rcx
00007cf1741de54b  pop rax
00007cf1741de54c  add rsp, 0x08
00007cf1741de550  jmp 0x00007CF1741DC13A
00007cf1741de555  sub rsp, 0x08
00007cf1741de559  push rax
00007cf1741de55a  push rcx
00007cf1741de55b  push rdx
00007cf1741de55c  push rdi
00007cf1741de55d  push rsi
00007cf1741de55e  push r8
00007cf1741de560  push r9
00007cf1741de562  push r10
00007cf1741de564  push r11
00007cf1741de566  sub rsp, 0xF0
00007cf1741de56d  vmovaps [rsp], xmm0
00007cf1741de572  vmovaps [rsp+0x10], xmm1
00007cf1741de578  vmovaps [rsp+0x20], xmm2
00007cf1741de57e  vmovaps [rsp+0x30], xmm3
00007cf1741de584  vmovaps [rsp+0x40], xmm4
00007cf1741de58a  vmovaps [rsp+0x50], xmm5
00007cf1741de590  vmovaps [rsp+0x60], xmm7
00007cf1741de596  vmovaps [rsp+0x70], xmm8
00007cf1741de59c  vmovaps [rsp+0x80], xmm9
00007cf1741de5a5  vmovaps [rsp+0x90], xmm10
00007cf1741de5ae  vmovaps [rsp+0xA0], xmm11
00007cf1741de5b7  vmovaps [rsp+0xB0], xmm12
00007cf1741de5c0  vmovaps [rsp+0xC0], xmm13
00007cf1741de5c9  vmovaps [rsp+0xD0], xmm14
00007cf1741de5d2  vmovaps [rsp+0xE0], xmm15
00007cf1741de5db  sub rsp, 0x30
00007cf1741de5df  movaps [rsp], xmm6
00007cf1741de5e3  movaps [rsp+0x10], xmm9
00007cf1741de5e9  movaps [rsp+0x20], xmm1
00007cf1741de5ee  lea rdi, [rsp]
00007cf1741de5f2  mov esi, 0x00
00007cf1741de5f7  mov rax, 0x611C8A33A530
00007cf1741de601  call rax
00007cf1741de603  movaps xmm6, [rsp]
00007cf1741de607  add rsp, 0x30
00007cf1741de60b  vmovaps xmm0, [rsp]
00007cf1741de610  vmovaps xmm1, [rsp+0x10]
00007cf1741de616  vmovaps xmm2, [rsp+0x20]
00007cf1741de61c  vmovaps xmm3, [rsp+0x30]
00007cf1741de622  vmovaps xmm4, [rsp+0x40]
00007cf1741de628  vmovaps xmm5, [rsp+0x50]
00007cf1741de62e  vmovaps xmm7, [rsp+0x60]
00007cf1741de634  vmovaps xmm8, [rsp+0x70]
00007cf1741de63a  vmovaps xmm9, [rsp+0x80]
00007cf1741de643  vmovaps xmm10, [rsp+0x90]
00007cf1741de64c  vmovaps xmm11, [rsp+0xA0]
00007cf1741de655  vmovaps xmm12, [rsp+0xB0]
00007cf1741de65e  vmovaps xmm13, [rsp+0xC0]
00007cf1741de667  vmovaps xmm14, [rsp+0xD0]
00007cf1741de670  vmovaps xmm15, [rsp+0xE0]
00007cf1741de679  add rsp, 0xF0
00007cf1741de680  pop r11
00007cf1741de682  pop r10
00007cf1741de684  pop r9
00007cf1741de686  pop r8
00007cf1741de688  pop rsi
00007cf1741de689  pop rdi
00007cf1741de68a  pop rdx
00007cf1741de68b  pop rcx
00007cf1741de68c  pop rax
00007cf1741de68d  add rsp, 0x08
00007cf1741de691  jmp 0x00007CF1741DC15E
00007cf1741de696  sub rsp, 0x08
00007cf1741de69a  push rax
00007cf1741de69b  push rcx
00007cf1741de69c  push rdx
00007cf1741de69d  push rdi
00007cf1741de69e  push rsi
00007cf1741de69f  push r8
00007cf1741de6a1  push r9
00007cf1741de6a3  push r10
00007cf1741de6a5  push r11
00007cf1741de6a7  sub rsp, 0xF0
00007cf1741de6ae  vmovaps [rsp], xmm0
00007cf1741de6b3  vmovaps [rsp+0x10], xmm1
00007cf1741de6b9  vmovaps [rsp+0x20], xmm2
00007cf1741de6bf  vmovaps [rsp+0x30], xmm3
00007cf1741de6c5  vmovaps [rsp+0x40], xmm4
00007cf1741de6cb  vmovaps [rsp+0x50], xmm5
00007cf1741de6d1  vmovaps [rsp+0x60], xmm6
00007cf1741de6d7  vmovaps [rsp+0x70], xmm7
00007cf1741de6dd  vmovaps [rsp+0x80], xmm8
00007cf1741de6e6  vmovaps [rsp+0x90], xmm10
00007cf1741de6ef  vmovaps [rsp+0xA0], xmm11
00007cf1741de6f8  vmovaps [rsp+0xB0], xmm12
00007cf1741de701  vmovaps [rsp+0xC0], xmm13
00007cf1741de70a  vmovaps [rsp+0xD0], xmm14
00007cf1741de713  vmovaps [rsp+0xE0], xmm15
00007cf1741de71c  sub rsp, 0x30
00007cf1741de720  movaps [rsp], xmm9
00007cf1741de725  movaps [rsp+0x10], xmm3
00007cf1741de72a  movaps [rsp+0x20], xmm1
00007cf1741de72f  lea rdi, [rsp]
00007cf1741de733  mov esi, 0x00
00007cf1741de738  mov rax, 0x611C8A33A530
00007cf1741de742  call rax
00007cf1741de744  movaps xmm9, [rsp]
00007cf1741de749  add rsp, 0x30
00007cf1741de74d  vmovaps xmm0, [rsp]
00007cf1741de752  vmovaps xmm1, [rsp+0x10]
00007cf1741de758  vmovaps xmm2, [rsp+0x20]
00007cf1741de75e  vmovaps xmm3, [rsp+0x30]
00007cf1741de764  vmovaps xmm4, [rsp+0x40]
00007cf1741de76a  vmovaps xmm5, [rsp+0x50]
00007cf1741de770  vmovaps xmm6, [rsp+0x60]
00007cf1741de776  vmovaps xmm7, [rsp+0x70]
00007cf1741de77c  vmovaps xmm8, [rsp+0x80]
00007cf1741de785  vmovaps xmm10, [rsp+0x90]
00007cf1741de78e  vmovaps xmm11, [rsp+0xA0]
00007cf1741de797  vmovaps xmm12, [rsp+0xB0]
00007cf1741de7a0  vmovaps xmm13, [rsp+0xC0]
00007cf1741de7a9  vmovaps xmm14, [rsp+0xD0]
00007cf1741de7b2  vmovaps xmm15, [rsp+0xE0]
00007cf1741de7bb  add rsp, 0xF0
00007cf1741de7c2  pop r11
00007cf1741de7c4  pop r10
00007cf1741de7c6  pop r9
00007cf1741de7c8  pop r8
00007cf1741de7ca  pop rsi
00007cf1741de7cb  pop rdi
00007cf1741de7cc  pop rdx
00007cf1741de7cd  pop rcx
00007cf1741de7ce  pop rax
00007cf1741de7cf  add rsp, 0x08
00007cf1741de7d3  jmp 0x00007CF1741DC1AA
00007cf1741de7d8  call 0x00007CF1740B52F0
00007cf1741de7dd  jmp 0x00007CF1741DC1B7
00007cf1741de7e2  sub rsp, 0x08
00007cf1741de7e6  push rax
00007cf1741de7e7  push rcx
00007cf1741de7e8  push rdx
00007cf1741de7e9  push rdi
00007cf1741de7ea  push rsi
00007cf1741de7eb  push r8
00007cf1741de7ed  push r9
00007cf1741de7ef  push r10
00007cf1741de7f1  push r11
00007cf1741de7f3  sub rsp, 0xF0
00007cf1741de7fa  vmovaps [rsp], xmm0
00007cf1741de7ff  vmovaps [rsp+0x10], xmm1
00007cf1741de805  vmovaps [rsp+0x20], xmm2
00007cf1741de80b  vmovaps [rsp+0x30], xmm3
00007cf1741de811  vmovaps [rsp+0x40], xmm4
00007cf1741de817  vmovaps [rsp+0x50], xmm5
00007cf1741de81d  vmovaps [rsp+0x60], xmm6
00007cf1741de823  vmovaps [rsp+0x70], xmm7
00007cf1741de829  vmovaps [rsp+0x80], xmm8
00007cf1741de832  vmovaps [rsp+0x90], xmm9
00007cf1741de83b  vmovaps [rsp+0xA0], xmm10
00007cf1741de844  vmovaps [rsp+0xB0], xmm11
00007cf1741de84d  vmovaps [rsp+0xC0], xmm12
00007cf1741de856  vmovaps [rsp+0xD0], xmm13
00007cf1741de85f  vmovaps [rsp+0xE0], xmm14
00007cf1741de868  sub rsp, 0x30
00007cf1741de86c  movaps [rsp], xmm15
00007cf1741de871  movaps [rsp+0x10], xmm3
00007cf1741de876  movaps [rsp+0x20], xmm7
00007cf1741de87b  lea rdi, [rsp]
00007cf1741de87f  mov esi, 0x00
00007cf1741de884  mov rax, 0x611C8A33A530
00007cf1741de88e  call rax
00007cf1741de890  movaps xmm15, [rsp]
00007cf1741de895  add rsp, 0x30
00007cf1741de899  vmovaps xmm0, [rsp]
00007cf1741de89e  vmovaps xmm1, [rsp+0x10]
00007cf1741de8a4  vmovaps xmm2, [rsp+0x20]
00007cf1741de8aa  vmovaps xmm3, [rsp+0x30]
00007cf1741de8b0  vmovaps xmm4, [rsp+0x40]
00007cf1741de8b6  vmovaps xmm5, [rsp+0x50]
00007cf1741de8bc  vmovaps xmm6, [rsp+0x60]
00007cf1741de8c2  vmovaps xmm7, [rsp+0x70]
00007cf1741de8c8  vmovaps xmm8, [rsp+0x80]
00007cf1741de8d1  vmovaps xmm9, [rsp+0x90]
00007cf1741de8da  vmovaps xmm10, [rsp+0xA0]
00007cf1741de8e3  vmovaps xmm11, [rsp+0xB0]
00007cf1741de8ec  vmovaps xmm12, [rsp+0xC0]
00007cf1741de8f5  vmovaps xmm13, [rsp+0xD0]
00007cf1741de8fe  vmovaps xmm14, [rsp+0xE0]
00007cf1741de907  add rsp, 0xF0
00007cf1741de90e  pop r11
00007cf1741de910  pop r10
00007cf1741de912  pop r9
00007cf1741de914  pop r8
00007cf1741de916  pop rsi
00007cf1741de917  pop rdi
00007cf1741de918  pop rdx
00007cf1741de919  pop rcx
00007cf1741de91a  pop rax
00007cf1741de91b  add rsp, 0x08
00007cf1741de91f  jmp 0x00007CF1741DC1E3
00007cf1741de924  sub rsp, 0x08
00007cf1741de928  push rax
00007cf1741de929  push rcx
00007cf1741de92a  push rdx
00007cf1741de92b  push rdi
00007cf1741de92c  push rsi
00007cf1741de92d  push r8
00007cf1741de92f  push r9
00007cf1741de931  push r10
00007cf1741de933  push r11
00007cf1741de935  sub rsp, 0xF0
00007cf1741de93c  vmovaps [rsp], xmm0
00007cf1741de941  vmovaps [rsp+0x10], xmm1
00007cf1741de947  vmovaps [rsp+0x20], xmm2
00007cf1741de94d  vmovaps [rsp+0x30], xmm4
00007cf1741de953  vmovaps [rsp+0x40], xmm5
00007cf1741de959  vmovaps [rsp+0x50], xmm6
00007cf1741de95f  vmovaps [rsp+0x60], xmm7
00007cf1741de965  vmovaps [rsp+0x70], xmm8
00007cf1741de96b  vmovaps [rsp+0x80], xmm9
00007cf1741de974  vmovaps [rsp+0x90], xmm10
00007cf1741de97d  vmovaps [rsp+0xA0], xmm11
00007cf1741de986  vmovaps [rsp+0xB0], xmm12
00007cf1741de98f  vmovaps [rsp+0xC0], xmm13
00007cf1741de998  vmovaps [rsp+0xD0], xmm14
00007cf1741de9a1  vmovaps [rsp+0xE0], xmm15
00007cf1741de9aa  sub rsp, 0x30
00007cf1741de9ae  movaps [rsp], xmm3
00007cf1741de9b2  movaps [rsp+0x10], xmm1
00007cf1741de9b7  movaps [rsp+0x20], xmm15
00007cf1741de9bd  lea rdi, [rsp]
00007cf1741de9c1  mov esi, 0x00
00007cf1741de9c6  mov rax, 0x611C8A33A530
00007cf1741de9d0  call rax
00007cf1741de9d2  movaps xmm3, [rsp]
00007cf1741de9d6  add rsp, 0x30
00007cf1741de9da  vmovaps xmm0, [rsp]
00007cf1741de9df  vmovaps xmm1, [rsp+0x10]
00007cf1741de9e5  vmovaps xmm2, [rsp+0x20]
00007cf1741de9eb  vmovaps xmm4, [rsp+0x30]
00007cf1741de9f1  vmovaps xmm5, [rsp+0x40]
00007cf1741de9f7  vmovaps xmm6, [rsp+0x50]
00007cf1741de9fd  vmovaps xmm7, [rsp+0x60]
00007cf1741dea03  vmovaps xmm8, [rsp+0x70]
00007cf1741dea09  vmovaps xmm9, [rsp+0x80]
00007cf1741dea12  vmovaps xmm10, [rsp+0x90]
00007cf1741dea1b  vmovaps xmm11, [rsp+0xA0]
00007cf1741dea24  vmovaps xmm12, [rsp+0xB0]
00007cf1741dea2d  vmovaps xmm13, [rsp+0xC0]
00007cf1741dea36  vmovaps xmm14, [rsp+0xD0]
00007cf1741dea3f  vmovaps xmm15, [rsp+0xE0]
00007cf1741dea48  add rsp, 0xF0
00007cf1741dea4f  pop r11
00007cf1741dea51  pop r10
00007cf1741dea53  pop r9
00007cf1741dea55  pop r8
00007cf1741dea57  pop rsi
00007cf1741dea58  pop rdi
00007cf1741dea59  pop rdx
00007cf1741dea5a  pop rcx
00007cf1741dea5b  pop rax
00007cf1741dea5c  add rsp, 0x08
00007cf1741dea60  jmp 0x00007CF1741DC272
00007cf1741dea65  call 0x00007CF1740B52F0
00007cf1741dea6a  jmp 0x00007CF1741DC27C
00007cf1741dea6f  sub rsp, 0x08
00007cf1741dea73  push rax
00007cf1741dea74  push rcx
00007cf1741dea75  push rdx
00007cf1741dea76  push rdi
00007cf1741dea77  push rsi
00007cf1741dea78  push r8
00007cf1741dea7a  push r9
00007cf1741dea7c  push r10
00007cf1741dea7e  push r11
00007cf1741dea80  sub rsp, 0xF0
00007cf1741dea87  vmovaps [rsp], xmm0
00007cf1741dea8c  vmovaps [rsp+0x10], xmm1
00007cf1741dea92  vmovaps [rsp+0x20], xmm2
00007cf1741dea98  vmovaps [rsp+0x30], xmm3
00007cf1741dea9e  vmovaps [rsp+0x40], xmm4
00007cf1741deaa4  vmovaps [rsp+0x50], xmm5
00007cf1741deaaa  vmovaps [rsp+0x60], xmm6
00007cf1741deab0  vmovaps [rsp+0x70], xmm7
00007cf1741deab6  vmovaps [rsp+0x80], xmm8
00007cf1741deabf  vmovaps [rsp+0x90], xmm9
00007cf1741deac8  vmovaps [rsp+0xA0], xmm10
00007cf1741dead1  vmovaps [rsp+0xB0], xmm11
00007cf1741deada  vmovaps [rsp+0xC0], xmm12
00007cf1741deae3  vmovaps [rsp+0xD0], xmm13
00007cf1741deaec  vmovaps [rsp+0xE0], xmm14
00007cf1741deaf5  sub rsp, 0x30
00007cf1741deaf9  movaps [rsp], xmm15
00007cf1741deafe  movaps [rsp+0x10], xmm14
00007cf1741deb04  movaps [rsp+0x20], xmm4
00007cf1741deb09  lea rdi, [rsp]
00007cf1741deb0d  mov esi, 0x00
00007cf1741deb12  mov rax, 0x611C8A33A530
00007cf1741deb1c  call rax
00007cf1741deb1e  movaps xmm15, [rsp]
00007cf1741deb23  add rsp, 0x30
00007cf1741deb27  vmovaps xmm0, [rsp]
00007cf1741deb2c  vmovaps xmm1, [rsp+0x10]
00007cf1741deb32  vmovaps xmm2, [rsp+0x20]
00007cf1741deb38  vmovaps xmm3, [rsp+0x30]
00007cf1741deb3e  vmovaps xmm4, [rsp+0x40]
00007cf1741deb44  vmovaps xmm5, [rsp+0x50]
00007cf1741deb4a  vmovaps xmm6, [rsp+0x60]
00007cf1741deb50  vmovaps xmm7, [rsp+0x70]
00007cf1741deb56  vmovaps xmm8, [rsp+0x80]
00007cf1741deb5f  vmovaps xmm9, [rsp+0x90]
00007cf1741deb68  vmovaps xmm10, [rsp+0xA0]
00007cf1741deb71  vmovaps xmm11, [rsp+0xB0]
00007cf1741deb7a  vmovaps xmm12, [rsp+0xC0]
00007cf1741deb83  vmovaps xmm13, [rsp+0xD0]
00007cf1741deb8c  vmovaps xmm14, [rsp+0xE0]
00007cf1741deb95  add rsp, 0xF0
00007cf1741deb9c  pop r11
00007cf1741deb9e  pop r10
00007cf1741deba0  pop r9
00007cf1741deba2  pop r8
00007cf1741deba4  pop rsi
00007cf1741deba5  pop rdi
00007cf1741deba6  pop rdx
00007cf1741deba7  pop rcx
00007cf1741deba8  pop rax
00007cf1741deba9  add rsp, 0x08
00007cf1741debad  jmp 0x00007CF1741DC2AA
00007cf1741debb2  sub rsp, 0x08
00007cf1741debb6  push rax
00007cf1741debb7  push rcx
00007cf1741debb8  push rdx
00007cf1741debb9  push rdi
00007cf1741debba  push rsi
00007cf1741debbb  push r8
00007cf1741debbd  push r9
00007cf1741debbf  push r10
00007cf1741debc1  push r11
00007cf1741debc3  sub rsp, 0xF0
00007cf1741debca  vmovaps [rsp], xmm0
00007cf1741debcf  vmovaps [rsp+0x10], xmm1
00007cf1741debd5  vmovaps [rsp+0x20], xmm2
00007cf1741debdb  vmovaps [rsp+0x30], xmm3
00007cf1741debe1  vmovaps [rsp+0x40], xmm4
00007cf1741debe7  vmovaps [rsp+0x50], xmm5
00007cf1741debed  vmovaps [rsp+0x60], xmm6
00007cf1741debf3  vmovaps [rsp+0x70], xmm7
00007cf1741debf9  vmovaps [rsp+0x80], xmm8
00007cf1741dec02  vmovaps [rsp+0x90], xmm9
00007cf1741dec0b  vmovaps [rsp+0xA0], xmm10
00007cf1741dec14  vmovaps [rsp+0xB0], xmm11
00007cf1741dec1d  vmovaps [rsp+0xC0], xmm12
00007cf1741dec26  vmovaps [rsp+0xD0], xmm13
00007cf1741dec2f  vmovaps [rsp+0xE0], xmm15
00007cf1741dec38  sub rsp, 0x30
00007cf1741dec3c  movaps [rsp], xmm14
00007cf1741dec41  movaps [rsp+0x10], xmm2
00007cf1741dec46  movaps [rsp+0x20], xmm1
00007cf1741dec4b  lea rdi, [rsp]
00007cf1741dec4f  mov esi, 0x00
00007cf1741dec54  mov rax, 0x611C8A33A530
00007cf1741dec5e  call rax
00007cf1741dec60  movaps xmm14, [rsp]
00007cf1741dec65  add rsp, 0x30
00007cf1741dec69  vmovaps xmm0, [rsp]
00007cf1741dec6e  vmovaps xmm1, [rsp+0x10]
00007cf1741dec74  vmovaps xmm2, [rsp+0x20]
00007cf1741dec7a  vmovaps xmm3, [rsp+0x30]
00007cf1741dec80  vmovaps xmm4, [rsp+0x40]
00007cf1741dec86  vmovaps xmm5, [rsp+0x50]
00007cf1741dec8c  vmovaps xmm6, [rsp+0x60]
00007cf1741dec92  vmovaps xmm7, [rsp+0x70]
00007cf1741dec98  vmovaps xmm8, [rsp+0x80]
00007cf1741deca1  vmovaps xmm9, [rsp+0x90]
00007cf1741decaa  vmovaps xmm10, [rsp+0xA0]
00007cf1741decb3  vmovaps xmm11, [rsp+0xB0]
00007cf1741decbc  vmovaps xmm12, [rsp+0xC0]
00007cf1741decc5  vmovaps xmm13, [rsp+0xD0]
00007cf1741decce  vmovaps xmm15, [rsp+0xE0]
00007cf1741decd7  add rsp, 0xF0
00007cf1741decde  pop r11
00007cf1741dece0  pop r10
00007cf1741dece2  pop r9
00007cf1741dece4  pop r8
00007cf1741dece6  pop rsi
00007cf1741dece7  pop rdi
00007cf1741dece8  pop rdx
00007cf1741dece9  pop rcx
00007cf1741decea  pop rax
00007cf1741deceb  add rsp, 0x08
00007cf1741decef  jmp 0x00007CF1741DC2D0
00007cf1741decf4  sub rsp, 0x08
00007cf1741decf8  push rax
00007cf1741decf9  push rcx
00007cf1741decfa  push rdx
00007cf1741decfb  push rdi
00007cf1741decfc  push rsi
00007cf1741decfd  push r8
00007cf1741decff  push r9
00007cf1741ded01  push r10
00007cf1741ded03  push r11
00007cf1741ded05  sub rsp, 0xF0
00007cf1741ded0c  vmovaps [rsp], xmm0
00007cf1741ded11  vmovaps [rsp+0x10], xmm2
00007cf1741ded17  vmovaps [rsp+0x20], xmm3
00007cf1741ded1d  vmovaps [rsp+0x30], xmm4
00007cf1741ded23  vmovaps [rsp+0x40], xmm5
00007cf1741ded29  vmovaps [rsp+0x50], xmm6
00007cf1741ded2f  vmovaps [rsp+0x60], xmm7
00007cf1741ded35  vmovaps [rsp+0x70], xmm8
00007cf1741ded3b  vmovaps [rsp+0x80], xmm9
00007cf1741ded44  vmovaps [rsp+0x90], xmm10
00007cf1741ded4d  vmovaps [rsp+0xA0], xmm11
00007cf1741ded56  vmovaps [rsp+0xB0], xmm12
00007cf1741ded5f  vmovaps [rsp+0xC0], xmm13
00007cf1741ded68  vmovaps [rsp+0xD0], xmm14
00007cf1741ded71  vmovaps [rsp+0xE0], xmm15
00007cf1741ded7a  sub rsp, 0x30
00007cf1741ded7e  movaps [rsp], xmm1
00007cf1741ded82  movaps [rsp+0x10], xmm4
00007cf1741ded87  movaps [rsp+0x20], xmm9
00007cf1741ded8d  lea rdi, [rsp]
00007cf1741ded91  mov esi, 0x00
00007cf1741ded96  mov rax, 0x611C8A33A530
00007cf1741deda0  call rax
00007cf1741deda2  movaps xmm1, [rsp]
00007cf1741deda6  add rsp, 0x30
00007cf1741dedaa  vmovaps xmm0, [rsp]
00007cf1741dedaf  vmovaps xmm2, [rsp+0x10]
00007cf1741dedb5  vmovaps xmm3, [rsp+0x20]
00007cf1741dedbb  vmovaps xmm4, [rsp+0x30]
00007cf1741dedc1  vmovaps xmm5, [rsp+0x40]
00007cf1741dedc7  vmovaps xmm6, [rsp+0x50]
00007cf1741dedcd  vmovaps xmm7, [rsp+0x60]
00007cf1741dedd3  vmovaps xmm8, [rsp+0x70]
00007cf1741dedd9  vmovaps xmm9, [rsp+0x80]
00007cf1741dede2  vmovaps xmm10, [rsp+0x90]
00007cf1741dedeb  vmovaps xmm11, [rsp+0xA0]
00007cf1741dedf4  vmovaps xmm12, [rsp+0xB0]
00007cf1741dedfd  vmovaps xmm13, [rsp+0xC0]
00007cf1741dee06  vmovaps xmm14, [rsp+0xD0]
00007cf1741dee0f  vmovaps xmm15, [rsp+0xE0]
00007cf1741dee18  add rsp, 0xF0
00007cf1741dee1f  pop r11
00007cf1741dee21  pop r10
00007cf1741dee23  pop r9
00007cf1741dee25  pop r8
00007cf1741dee27  pop rsi
00007cf1741dee28  pop rdi
00007cf1741dee29  pop rdx
00007cf1741dee2a  pop rcx
00007cf1741dee2b  pop rax
00007cf1741dee2c  add rsp, 0x08
00007cf1741dee30  jmp 0x00007CF1741DC2EE
00007cf1741dee35  sub rsp, 0x08
00007cf1741dee39  push rax
00007cf1741dee3a  push rcx
00007cf1741dee3b  push rdx
00007cf1741dee3c  push rdi
00007cf1741dee3d  push rsi
00007cf1741dee3e  push r8
00007cf1741dee40  push r9
00007cf1741dee42  push r10
00007cf1741dee44  push r11
00007cf1741dee46  sub rsp, 0xF0
00007cf1741dee4d  vmovaps [rsp], xmm0
00007cf1741dee52  vmovaps [rsp+0x10], xmm1
00007cf1741dee58  vmovaps [rsp+0x20], xmm2
00007cf1741dee5e  vmovaps [rsp+0x30], xmm3
00007cf1741dee64  vmovaps [rsp+0x40], xmm5
00007cf1741dee6a  vmovaps [rsp+0x50], xmm6
00007cf1741dee70  vmovaps [rsp+0x60], xmm7
00007cf1741dee76  vmovaps [rsp+0x70], xmm8
00007cf1741dee7c  vmovaps [rsp+0x80], xmm9
00007cf1741dee85  vmovaps [rsp+0x90], xmm10
00007cf1741dee8e  vmovaps [rsp+0xA0], xmm11
00007cf1741dee97  vmovaps [rsp+0xB0], xmm12
00007cf1741deea0  vmovaps [rsp+0xC0], xmm13
00007cf1741deea9  vmovaps [rsp+0xD0], xmm14
00007cf1741deeb2  vmovaps [rsp+0xE0], xmm15
00007cf1741deebb  sub rsp, 0x30
00007cf1741deebf  movaps [rsp], xmm4
00007cf1741deec3  movaps [rsp+0x10], xmm2
00007cf1741deec8  movaps [rsp+0x20], xmm9
00007cf1741deece  lea rdi, [rsp]
00007cf1741deed2  mov esi, 0x00
00007cf1741deed7  mov rax, 0x611C8A33A530
00007cf1741deee1  call rax
00007cf1741deee3  movaps xmm4, [rsp]
00007cf1741deee7  add rsp, 0x30
00007cf1741deeeb  vmovaps xmm0, [rsp]
00007cf1741deef0  vmovaps xmm1, [rsp+0x10]
00007cf1741deef6  vmovaps xmm2, [rsp+0x20]
00007cf1741deefc  vmovaps xmm3, [rsp+0x30]
00007cf1741def02  vmovaps xmm5, [rsp+0x40]
00007cf1741def08  vmovaps xmm6, [rsp+0x50]
00007cf1741def0e  vmovaps xmm7, [rsp+0x60]
00007cf1741def14  vmovaps xmm8, [rsp+0x70]
00007cf1741def1a  vmovaps xmm9, [rsp+0x80]
00007cf1741def23  vmovaps xmm10, [rsp+0x90]
00007cf1741def2c  vmovaps xmm11, [rsp+0xA0]
00007cf1741def35  vmovaps xmm12, [rsp+0xB0]
00007cf1741def3e  vmovaps xmm13, [rsp+0xC0]
00007cf1741def47  vmovaps xmm14, [rsp+0xD0]
00007cf1741def50  vmovaps xmm15, [rsp+0xE0]
00007cf1741def59  add rsp, 0xF0
00007cf1741def60  pop r11
00007cf1741def62  pop r10
00007cf1741def64  pop r9
00007cf1741def66  pop r8
00007cf1741def68  pop rsi
00007cf1741def69  pop rdi
00007cf1741def6a  pop rdx
00007cf1741def6b  pop rcx
00007cf1741def6c  pop rax
00007cf1741def6d  add rsp, 0x08
00007cf1741def71  jmp 0x00007CF1741DC31E
00007cf1741def76  sub rsp, 0x08
00007cf1741def7a  push rax
00007cf1741def7b  push rcx
00007cf1741def7c  push rdx
00007cf1741def7d  push rdi
00007cf1741def7e  push rsi
00007cf1741def7f  push r8
00007cf1741def81  push r9
00007cf1741def83  push r10
00007cf1741def85  push r11
00007cf1741def87  sub rsp, 0xF0
00007cf1741def8e  vmovaps [rsp], xmm0
00007cf1741def93  vmovaps [rsp+0x10], xmm1
00007cf1741def99  vmovaps [rsp+0x20], xmm2
00007cf1741def9f  vmovaps [rsp+0x30], xmm3
00007cf1741defa5  vmovaps [rsp+0x40], xmm4
00007cf1741defab  vmovaps [rsp+0x50], xmm5
00007cf1741defb1  vmovaps [rsp+0x60], xmm6
00007cf1741defb7  vmovaps [rsp+0x70], xmm7
00007cf1741defbd  vmovaps [rsp+0x80], xmm8
00007cf1741defc6  vmovaps [rsp+0x90], xmm10
00007cf1741defcf  vmovaps [rsp+0xA0], xmm11
00007cf1741defd8  vmovaps [rsp+0xB0], xmm12
00007cf1741defe1  vmovaps [rsp+0xC0], xmm13
00007cf1741defea  vmovaps [rsp+0xD0], xmm14
00007cf1741deff3  vmovaps [rsp+0xE0], xmm15
00007cf1741deffc  sub rsp, 0x30
00007cf1741df000  movaps [rsp], xmm9
00007cf1741df005  movaps [rsp+0x10], xmm2
00007cf1741df00a  movaps [rsp+0x20], xmm1
00007cf1741df00f  lea rdi, [rsp]
00007cf1741df013  mov esi, 0x00
00007cf1741df018  mov rax, 0x611C8A33A530
00007cf1741df022  call rax
00007cf1741df024  movaps xmm9, [rsp]
00007cf1741df029  add rsp, 0x30
00007cf1741df02d  vmovaps xmm0, [rsp]
00007cf1741df032  vmovaps xmm1, [rsp+0x10]
00007cf1741df038  vmovaps xmm2, [rsp+0x20]
00007cf1741df03e  vmovaps xmm3, [rsp+0x30]
00007cf1741df044  vmovaps xmm4, [rsp+0x40]
00007cf1741df04a  vmovaps xmm5, [rsp+0x50]
00007cf1741df050  vmovaps xmm6, [rsp+0x60]
00007cf1741df056  vmovaps xmm7, [rsp+0x70]
00007cf1741df05c  vmovaps xmm8, [rsp+0x80]
00007cf1741df065  vmovaps xmm10, [rsp+0x90]
00007cf1741df06e  vmovaps xmm11, [rsp+0xA0]
00007cf1741df077  vmovaps xmm12, [rsp+0xB0]
00007cf1741df080  vmovaps xmm13, [rsp+0xC0]
00007cf1741df089  vmovaps xmm14, [rsp+0xD0]
00007cf1741df092  vmovaps xmm15, [rsp+0xE0]
00007cf1741df09b  add rsp, 0xF0
00007cf1741df0a2  pop r11
00007cf1741df0a4  pop r10
00007cf1741df0a6  pop r9
00007cf1741df0a8  pop r8
00007cf1741df0aa  pop rsi
00007cf1741df0ab  pop rdi
00007cf1741df0ac  pop rdx
00007cf1741df0ad  pop rcx
00007cf1741df0ae  pop rax
00007cf1741df0af  add rsp, 0x08
00007cf1741df0b3  jmp 0x00007CF1741DC354
00007cf1741df0b8  sub rsp, 0x08
00007cf1741df0bc  push rax
00007cf1741df0bd  push rcx
00007cf1741df0be  push rdx
00007cf1741df0bf  push rdi
00007cf1741df0c0  push rsi
00007cf1741df0c1  push r8
00007cf1741df0c3  push r9
00007cf1741df0c5  push r10
00007cf1741df0c7  push r11
00007cf1741df0c9  sub rsp, 0xF0
00007cf1741df0d0  vmovaps [rsp], xmm0
00007cf1741df0d5  vmovaps [rsp+0x10], xmm2
00007cf1741df0db  vmovaps [rsp+0x20], xmm3
00007cf1741df0e1  vmovaps [rsp+0x30], xmm4
00007cf1741df0e7  vmovaps [rsp+0x40], xmm5
00007cf1741df0ed  vmovaps [rsp+0x50], xmm6
00007cf1741df0f3  vmovaps [rsp+0x60], xmm7
00007cf1741df0f9  vmovaps [rsp+0x70], xmm8
00007cf1741df0ff  vmovaps [rsp+0x80], xmm9
00007cf1741df108  vmovaps [rsp+0x90], xmm10
00007cf1741df111  vmovaps [rsp+0xA0], xmm11
00007cf1741df11a  vmovaps [rsp+0xB0], xmm12
00007cf1741df123  vmovaps [rsp+0xC0], xmm13
00007cf1741df12c  vmovaps [rsp+0xD0], xmm14
00007cf1741df135  vmovaps [rsp+0xE0], xmm15
00007cf1741df13e  sub rsp, 0x30
00007cf1741df142  movaps [rsp], xmm1
00007cf1741df146  movaps [rsp+0x10], xmm15
00007cf1741df14c  movaps [rsp+0x20], xmm6
00007cf1741df151  lea rdi, [rsp]
00007cf1741df155  mov esi, 0x00
00007cf1741df15a  mov rax, 0x611C8A33A530
00007cf1741df164  call rax
00007cf1741df166  movaps xmm1, [rsp]
00007cf1741df16a  add rsp, 0x30
00007cf1741df16e  vmovaps xmm0, [rsp]
00007cf1741df173  vmovaps xmm2, [rsp+0x10]
00007cf1741df179  vmovaps xmm3, [rsp+0x20]
00007cf1741df17f  vmovaps xmm4, [rsp+0x30]
00007cf1741df185  vmovaps xmm5, [rsp+0x40]
00007cf1741df18b  vmovaps xmm6, [rsp+0x50]
00007cf1741df191  vmovaps xmm7, [rsp+0x60]
00007cf1741df197  vmovaps xmm8, [rsp+0x70]
00007cf1741df19d  vmovaps xmm9, [rsp+0x80]
00007cf1741df1a6  vmovaps xmm10, [rsp+0x90]
00007cf1741df1af  vmovaps xmm11, [rsp+0xA0]
00007cf1741df1b8  vmovaps xmm12, [rsp+0xB0]
00007cf1741df1c1  vmovaps xmm13, [rsp+0xC0]
00007cf1741df1ca  vmovaps xmm14, [rsp+0xD0]
00007cf1741df1d3  vmovaps xmm15, [rsp+0xE0]
00007cf1741df1dc  add rsp, 0xF0
00007cf1741df1e3  pop r11
00007cf1741df1e5  pop r10
00007cf1741df1e7  pop r9
00007cf1741df1e9  pop r8
00007cf1741df1eb  pop rsi
00007cf1741df1ec  pop rdi
00007cf1741df1ed  pop rdx
00007cf1741df1ee  pop rcx
00007cf1741df1ef  pop rax
00007cf1741df1f0  add rsp, 0x08
00007cf1741df1f4  jmp 0x00007CF1741DC375
00007cf1741df1f9  sub rsp, 0x08
00007cf1741df1fd  push rax
00007cf1741df1fe  push rcx
00007cf1741df1ff  push rdx
00007cf1741df200  push rdi
00007cf1741df201  push rsi
00007cf1741df202  push r8
00007cf1741df204  push r9
00007cf1741df206  push r10
00007cf1741df208  push r11
00007cf1741df20a  sub rsp, 0xF0
00007cf1741df211  vmovaps [rsp], xmm0
00007cf1741df216  vmovaps [rsp+0x10], xmm1
00007cf1741df21c  vmovaps [rsp+0x20], xmm2
00007cf1741df222  vmovaps [rsp+0x30], xmm3
00007cf1741df228  vmovaps [rsp+0x40], xmm4
00007cf1741df22e  vmovaps [rsp+0x50], xmm5
00007cf1741df234  vmovaps [rsp+0x60], xmm6
00007cf1741df23a  vmovaps [rsp+0x70], xmm7
00007cf1741df240  vmovaps [rsp+0x80], xmm8
00007cf1741df249  vmovaps [rsp+0x90], xmm9
00007cf1741df252  vmovaps [rsp+0xA0], xmm10
00007cf1741df25b  vmovaps [rsp+0xB0], xmm11
00007cf1741df264  vmovaps [rsp+0xC0], xmm12
00007cf1741df26d  vmovaps [rsp+0xD0], xmm13
00007cf1741df276  vmovaps [rsp+0xE0], xmm14
00007cf1741df27f  sub rsp, 0x30
00007cf1741df283  movaps [rsp], xmm15
00007cf1741df288  movaps [rsp+0x10], xmm5
00007cf1741df28d  movaps [rsp+0x20], xmm3
00007cf1741df292  lea rdi, [rsp]
00007cf1741df296  mov esi, 0x00
00007cf1741df29b  mov rax, 0x611C8A33A530
00007cf1741df2a5  call rax
00007cf1741df2a7  movaps xmm15, [rsp]
00007cf1741df2ac  add rsp, 0x30
00007cf1741df2b0  vmovaps xmm0, [rsp]
00007cf1741df2b5  vmovaps xmm1, [rsp+0x10]
00007cf1741df2bb  vmovaps xmm2, [rsp+0x20]
00007cf1741df2c1  vmovaps xmm3, [rsp+0x30]
00007cf1741df2c7  vmovaps xmm4, [rsp+0x40]
00007cf1741df2cd  vmovaps xmm5, [rsp+0x50]
00007cf1741df2d3  vmovaps xmm6, [rsp+0x60]
00007cf1741df2d9  vmovaps xmm7, [rsp+0x70]
00007cf1741df2df  vmovaps xmm8, [rsp+0x80]
00007cf1741df2e8  vmovaps xmm9, [rsp+0x90]
00007cf1741df2f1  vmovaps xmm10, [rsp+0xA0]
00007cf1741df2fa  vmovaps xmm11, [rsp+0xB0]
00007cf1741df303  vmovaps xmm12, [rsp+0xC0]
00007cf1741df30c  vmovaps xmm13, [rsp+0xD0]
00007cf1741df315  vmovaps xmm14, [rsp+0xE0]
00007cf1741df31e  add rsp, 0xF0
00007cf1741df325  pop r11
00007cf1741df327  pop r10
00007cf1741df329  pop r9
00007cf1741df32b  pop r8
00007cf1741df32d  pop rsi
00007cf1741df32e  pop rdi
00007cf1741df32f  pop rdx
00007cf1741df330  pop rcx
00007cf1741df331  pop rax
00007cf1741df332  add rsp, 0x08
00007cf1741df336  jmp 0x00007CF1741DC38F
00007cf1741df33b  sub rsp, 0x08
00007cf1741df33f  push rax
00007cf1741df340  push rcx
00007cf1741df341  push rdx
00007cf1741df342  push rdi
00007cf1741df343  push rsi
00007cf1741df344  push r8
00007cf1741df346  push r9
00007cf1741df348  push r10
00007cf1741df34a  push r11
00007cf1741df34c  sub rsp, 0xF0
00007cf1741df353  vmovaps [rsp], xmm0
00007cf1741df358  vmovaps [rsp+0x10], xmm1
00007cf1741df35e  vmovaps [rsp+0x20], xmm2
00007cf1741df364  vmovaps [rsp+0x30], xmm3
00007cf1741df36a  vmovaps [rsp+0x40], xmm4
00007cf1741df370  vmovaps [rsp+0x50], xmm6
00007cf1741df376  vmovaps [rsp+0x60], xmm7
00007cf1741df37c  vmovaps [rsp+0x70], xmm8
00007cf1741df382  vmovaps [rsp+0x80], xmm9
00007cf1741df38b  vmovaps [rsp+0x90], xmm10
00007cf1741df394  vmovaps [rsp+0xA0], xmm11
00007cf1741df39d  vmovaps [rsp+0xB0], xmm12
00007cf1741df3a6  vmovaps [rsp+0xC0], xmm13
00007cf1741df3af  vmovaps [rsp+0xD0], xmm14
00007cf1741df3b8  vmovaps [rsp+0xE0], xmm15
00007cf1741df3c1  sub rsp, 0x30
00007cf1741df3c5  movaps [rsp], xmm5
00007cf1741df3c9  movaps [rsp+0x10], xmm8
00007cf1741df3cf  movaps [rsp+0x20], xmm6
00007cf1741df3d4  lea rdi, [rsp]
00007cf1741df3d8  mov esi, 0x00
00007cf1741df3dd  mov rax, 0x611C8A33A530
00007cf1741df3e7  call rax
00007cf1741df3e9  movaps xmm5, [rsp]
00007cf1741df3ed  add rsp, 0x30
00007cf1741df3f1  vmovaps xmm0, [rsp]
00007cf1741df3f6  vmovaps xmm1, [rsp+0x10]
00007cf1741df3fc  vmovaps xmm2, [rsp+0x20]
00007cf1741df402  vmovaps xmm3, [rsp+0x30]
00007cf1741df408  vmovaps xmm4, [rsp+0x40]
00007cf1741df40e  vmovaps xmm6, [rsp+0x50]
00007cf1741df414  vmovaps xmm7, [rsp+0x60]
00007cf1741df41a  vmovaps xmm8, [rsp+0x70]
00007cf1741df420  vmovaps xmm9, [rsp+0x80]
00007cf1741df429  vmovaps xmm10, [rsp+0x90]
00007cf1741df432  vmovaps xmm11, [rsp+0xA0]
00007cf1741df43b  vmovaps xmm12, [rsp+0xB0]
00007cf1741df444  vmovaps xmm13, [rsp+0xC0]
00007cf1741df44d  vmovaps xmm14, [rsp+0xD0]
00007cf1741df456  vmovaps xmm15, [rsp+0xE0]
00007cf1741df45f  add rsp, 0xF0
00007cf1741df466  pop r11
00007cf1741df468  pop r10
00007cf1741df46a  pop r9
00007cf1741df46c  pop r8
00007cf1741df46e  pop rsi
00007cf1741df46f  pop rdi
00007cf1741df470  pop rdx
00007cf1741df471  pop rcx
00007cf1741df472  pop rax
00007cf1741df473  add rsp, 0x08
00007cf1741df477  jmp 0x00007CF1741DC3B3
00007cf1741df47c  sub rsp, 0x08
00007cf1741df480  push rax
00007cf1741df481  push rcx
00007cf1741df482  push rdx
00007cf1741df483  push rdi
00007cf1741df484  push rsi
00007cf1741df485  push r8
00007cf1741df487  push r9
00007cf1741df489  push r10
00007cf1741df48b  push r11
00007cf1741df48d  sub rsp, 0xF0
00007cf1741df494  vmovaps [rsp], xmm0
00007cf1741df499  vmovaps [rsp+0x10], xmm1
00007cf1741df49f  vmovaps [rsp+0x20], xmm2
00007cf1741df4a5  vmovaps [rsp+0x30], xmm3
00007cf1741df4ab  vmovaps [rsp+0x40], xmm4
00007cf1741df4b1  vmovaps [rsp+0x50], xmm5
00007cf1741df4b7  vmovaps [rsp+0x60], xmm7
00007cf1741df4bd  vmovaps [rsp+0x70], xmm8
00007cf1741df4c3  vmovaps [rsp+0x80], xmm9
00007cf1741df4cc  vmovaps [rsp+0x90], xmm10
00007cf1741df4d5  vmovaps [rsp+0xA0], xmm11
00007cf1741df4de  vmovaps [rsp+0xB0], xmm12
00007cf1741df4e7  vmovaps [rsp+0xC0], xmm13
00007cf1741df4f0  vmovaps [rsp+0xD0], xmm14
00007cf1741df4f9  vmovaps [rsp+0xE0], xmm15
00007cf1741df502  sub rsp, 0x30
00007cf1741df506  movaps [rsp], xmm6
00007cf1741df50a  movaps [rsp+0x10], xmm10
00007cf1741df510  movaps [rsp+0x20], xmm8
00007cf1741df516  lea rdi, [rsp]
00007cf1741df51a  mov esi, 0x00
00007cf1741df51f  mov rax, 0x611C8A33A530
00007cf1741df529  call rax
00007cf1741df52b  movaps xmm6, [rsp]
00007cf1741df52f  add rsp, 0x30
00007cf1741df533  vmovaps xmm0, [rsp]
00007cf1741df538  vmovaps xmm1, [rsp+0x10]
00007cf1741df53e  vmovaps xmm2, [rsp+0x20]
00007cf1741df544  vmovaps xmm3, [rsp+0x30]
00007cf1741df54a  vmovaps xmm4, [rsp+0x40]
00007cf1741df550  vmovaps xmm5, [rsp+0x50]
00007cf1741df556  vmovaps xmm7, [rsp+0x60]
00007cf1741df55c  vmovaps xmm8, [rsp+0x70]
00007cf1741df562  vmovaps xmm9, [rsp+0x80]
00007cf1741df56b  vmovaps xmm10, [rsp+0x90]
00007cf1741df574  vmovaps xmm11, [rsp+0xA0]
00007cf1741df57d  vmovaps xmm12, [rsp+0xB0]
00007cf1741df586  vmovaps xmm13, [rsp+0xC0]
00007cf1741df58f  vmovaps xmm14, [rsp+0xD0]
00007cf1741df598  vmovaps xmm15, [rsp+0xE0]
00007cf1741df5a1  add rsp, 0xF0
00007cf1741df5a8  pop r11
00007cf1741df5aa  pop r10
00007cf1741df5ac  pop r9
00007cf1741df5ae  pop r8
00007cf1741df5b0  pop rsi
00007cf1741df5b1  pop rdi
00007cf1741df5b2  pop rdx
00007cf1741df5b3  pop rcx
00007cf1741df5b4  pop rax
00007cf1741df5b5  add rsp, 0x08
00007cf1741df5b9  jmp 0x00007CF1741DC3D8
00007cf1741df5be  sub rsp, 0x08
00007cf1741df5c2  push rax
00007cf1741df5c3  push rcx
00007cf1741df5c4  push rdx
00007cf1741df5c5  push rdi
00007cf1741df5c6  push rsi
00007cf1741df5c7  push r8
00007cf1741df5c9  push r9
00007cf1741df5cb  push r10
00007cf1741df5cd  push r11
00007cf1741df5cf  sub rsp, 0xF0
00007cf1741df5d6  vmovaps [rsp], xmm0
00007cf1741df5db  vmovaps [rsp+0x10], xmm1
00007cf1741df5e1  vmovaps [rsp+0x20], xmm2
00007cf1741df5e7  vmovaps [rsp+0x30], xmm3
00007cf1741df5ed  vmovaps [rsp+0x40], xmm4
00007cf1741df5f3  vmovaps [rsp+0x50], xmm5
00007cf1741df5f9  vmovaps [rsp+0x60], xmm6
00007cf1741df5ff  vmovaps [rsp+0x70], xmm7
00007cf1741df605  vmovaps [rsp+0x80], xmm8
00007cf1741df60e  vmovaps [rsp+0x90], xmm9
00007cf1741df617  vmovaps [rsp+0xA0], xmm11
00007cf1741df620  vmovaps [rsp+0xB0], xmm12
00007cf1741df629  vmovaps [rsp+0xC0], xmm13
00007cf1741df632  vmovaps [rsp+0xD0], xmm14
00007cf1741df63b  vmovaps [rsp+0xE0], xmm15
00007cf1741df644  sub rsp, 0x30
00007cf1741df648  movaps [rsp], xmm10
00007cf1741df64d  movaps [rsp+0x10], xmm8
00007cf1741df653  movaps [rsp+0x20], xmm14
00007cf1741df659  lea rdi, [rsp]
00007cf1741df65d  mov esi, 0x00
00007cf1741df662  mov rax, 0x611C8A33A530
00007cf1741df66c  call rax
00007cf1741df66e  movaps xmm10, [rsp]
00007cf1741df673  add rsp, 0x30
00007cf1741df677  vmovaps xmm0, [rsp]
00007cf1741df67c  vmovaps xmm1, [rsp+0x10]
00007cf1741df682  vmovaps xmm2, [rsp+0x20]
00007cf1741df688  vmovaps xmm3, [rsp+0x30]
00007cf1741df68e  vmovaps xmm4, [rsp+0x40]
00007cf1741df694  vmovaps xmm5, [rsp+0x50]
00007cf1741df69a  vmovaps xmm6, [rsp+0x60]
00007cf1741df6a0  vmovaps xmm7, [rsp+0x70]
00007cf1741df6a6  vmovaps xmm8, [rsp+0x80]
00007cf1741df6af  vmovaps xmm9, [rsp+0x90]
00007cf1741df6b8  vmovaps xmm11, [rsp+0xA0]
00007cf1741df6c1  vmovaps xmm12, [rsp+0xB0]
00007cf1741df6ca  vmovaps xmm13, [rsp+0xC0]
00007cf1741df6d3  vmovaps xmm14, [rsp+0xD0]
00007cf1741df6dc  vmovaps xmm15, [rsp+0xE0]
00007cf1741df6e5  add rsp, 0xF0
00007cf1741df6ec  pop r11
00007cf1741df6ee  pop r10
00007cf1741df6f0  pop r9
00007cf1741df6f2  pop r8
00007cf1741df6f4  pop rsi
00007cf1741df6f5  pop rdi
00007cf1741df6f6  pop rdx
00007cf1741df6f7  pop rcx
00007cf1741df6f8  pop rax
00007cf1741df6f9  add rsp, 0x08
00007cf1741df6fd  jmp 0x00007CF1741DC3F8
00007cf1741df702  sub rsp, 0x08
00007cf1741df706  push rax
00007cf1741df707  push rcx
00007cf1741df708  push rdx
00007cf1741df709  push rdi
00007cf1741df70a  push rsi
00007cf1741df70b  push r8
00007cf1741df70d  push r9
00007cf1741df70f  push r10
00007cf1741df711  push r11
00007cf1741df713  sub rsp, 0xF0
00007cf1741df71a  vmovaps [rsp], xmm0
00007cf1741df71f  vmovaps [rsp+0x10], xmm1
00007cf1741df725  vmovaps [rsp+0x20], xmm2
00007cf1741df72b  vmovaps [rsp+0x30], xmm3
00007cf1741df731  vmovaps [rsp+0x40], xmm4
00007cf1741df737  vmovaps [rsp+0x50], xmm5
00007cf1741df73d  vmovaps [rsp+0x60], xmm6
00007cf1741df743  vmovaps [rsp+0x70], xmm7
00007cf1741df749  vmovaps [rsp+0x80], xmm8
00007cf1741df752  vmovaps [rsp+0x90], xmm9
00007cf1741df75b  vmovaps [rsp+0xA0], xmm10
00007cf1741df764  vmovaps [rsp+0xB0], xmm11
00007cf1741df76d  vmovaps [rsp+0xC0], xmm12
00007cf1741df776  vmovaps [rsp+0xD0], xmm13
00007cf1741df77f  vmovaps [rsp+0xE0], xmm15
00007cf1741df788  sub rsp, 0x30
00007cf1741df78c  movaps [rsp], xmm14
00007cf1741df791  movaps [rsp+0x10], xmm8
00007cf1741df797  movaps [rsp+0x20], xmm4
00007cf1741df79c  lea rdi, [rsp]
00007cf1741df7a0  mov esi, 0x00
00007cf1741df7a5  mov rax, 0x611C8A33A530
00007cf1741df7af  call rax
00007cf1741df7b1  movaps xmm14, [rsp]
00007cf1741df7b6  add rsp, 0x30
00007cf1741df7ba  vmovaps xmm0, [rsp]
00007cf1741df7bf  vmovaps xmm1, [rsp+0x10]
00007cf1741df7c5  vmovaps xmm2, [rsp+0x20]
00007cf1741df7cb  vmovaps xmm3, [rsp+0x30]
00007cf1741df7d1  vmovaps xmm4, [rsp+0x40]
00007cf1741df7d7  vmovaps xmm5, [rsp+0x50]
00007cf1741df7dd  vmovaps xmm6, [rsp+0x60]
00007cf1741df7e3  vmovaps xmm7, [rsp+0x70]
00007cf1741df7e9  vmovaps xmm8, [rsp+0x80]
00007cf1741df7f2  vmovaps xmm9, [rsp+0x90]
00007cf1741df7fb  vmovaps xmm10, [rsp+0xA0]
00007cf1741df804  vmovaps xmm11, [rsp+0xB0]
00007cf1741df80d  vmovaps xmm12, [rsp+0xC0]
00007cf1741df816  vmovaps xmm13, [rsp+0xD0]
00007cf1741df81f  vmovaps xmm15, [rsp+0xE0]
00007cf1741df828  add rsp, 0xF0
00007cf1741df82f  pop r11
00007cf1741df831  pop r10
00007cf1741df833  pop r9
00007cf1741df835  pop r8
00007cf1741df837  pop rsi
00007cf1741df838  pop rdi
00007cf1741df839  pop rdx
00007cf1741df83a  pop rcx
00007cf1741df83b  pop rax
00007cf1741df83c  add rsp, 0x08
00007cf1741df840  jmp 0x00007CF1741DC418
00007cf1741df845  sub rsp, 0x08
00007cf1741df849  push rax
00007cf1741df84a  push rcx
00007cf1741df84b  push rdx
00007cf1741df84c  push rdi
00007cf1741df84d  push rsi
00007cf1741df84e  push r8
00007cf1741df850  push r9
00007cf1741df852  push r10
00007cf1741df854  push r11
00007cf1741df856  sub rsp, 0xF0
00007cf1741df85d  vmovaps [rsp], xmm0
00007cf1741df862  vmovaps [rsp+0x10], xmm1
00007cf1741df868  vmovaps [rsp+0x20], xmm2
00007cf1741df86e  vmovaps [rsp+0x30], xmm3
00007cf1741df874  vmovaps [rsp+0x40], xmm5
00007cf1741df87a  vmovaps [rsp+0x50], xmm6
00007cf1741df880  vmovaps [rsp+0x60], xmm7
00007cf1741df886  vmovaps [rsp+0x70], xmm8
00007cf1741df88c  vmovaps [rsp+0x80], xmm9
00007cf1741df895  vmovaps [rsp+0x90], xmm10
00007cf1741df89e  vmovaps [rsp+0xA0], xmm11
00007cf1741df8a7  vmovaps [rsp+0xB0], xmm12
00007cf1741df8b0  vmovaps [rsp+0xC0], xmm13
00007cf1741df8b9  vmovaps [rsp+0xD0], xmm14
00007cf1741df8c2  vmovaps [rsp+0xE0], xmm15
00007cf1741df8cb  sub rsp, 0x30
00007cf1741df8cf  movaps [rsp], xmm4
00007cf1741df8d3  movaps [rsp+0x10], xmm13
00007cf1741df8d9  movaps [rsp+0x20], xmm8
00007cf1741df8df  lea rdi, [rsp]
00007cf1741df8e3  mov esi, 0x00
00007cf1741df8e8  mov rax, 0x611C8A33A530
00007cf1741df8f2  call rax
00007cf1741df8f4  movaps xmm4, [rsp]
00007cf1741df8f8  add rsp, 0x30
00007cf1741df8fc  vmovaps xmm0, [rsp]
00007cf1741df901  vmovaps xmm1, [rsp+0x10]
00007cf1741df907  vmovaps xmm2, [rsp+0x20]
00007cf1741df90d  vmovaps xmm3, [rsp+0x30]
00007cf1741df913  vmovaps xmm5, [rsp+0x40]
00007cf1741df919  vmovaps xmm6, [rsp+0x50]
00007cf1741df91f  vmovaps xmm7, [rsp+0x60]
00007cf1741df925  vmovaps xmm8, [rsp+0x70]
00007cf1741df92b  vmovaps xmm9, [rsp+0x80]
00007cf1741df934  vmovaps xmm10, [rsp+0x90]
00007cf1741df93d  vmovaps xmm11, [rsp+0xA0]
00007cf1741df946  vmovaps xmm12, [rsp+0xB0]
00007cf1741df94f  vmovaps xmm13, [rsp+0xC0]
00007cf1741df958  vmovaps xmm14, [rsp+0xD0]
00007cf1741df961  vmovaps xmm15, [rsp+0xE0]
00007cf1741df96a  add rsp, 0xF0
00007cf1741df971  pop r11
00007cf1741df973  pop r10
00007cf1741df975  pop r9
00007cf1741df977  pop r8
00007cf1741df979  pop rsi
00007cf1741df97a  pop rdi
00007cf1741df97b  pop rdx
00007cf1741df97c  pop rcx
00007cf1741df97d  pop rax
00007cf1741df97e  add rsp, 0x08
00007cf1741df982  jmp 0x00007CF1741DC43D
00007cf1741df987  sub rsp, 0x08
00007cf1741df98b  push rax
00007cf1741df98c  push rcx
00007cf1741df98d  push rdx
00007cf1741df98e  push rdi
00007cf1741df98f  push rsi
00007cf1741df990  push r8
00007cf1741df992  push r9
00007cf1741df994  push r10
00007cf1741df996  push r11
00007cf1741df998  sub rsp, 0xF0
00007cf1741df99f  vmovaps [rsp], xmm0
00007cf1741df9a4  vmovaps [rsp+0x10], xmm1
00007cf1741df9aa  vmovaps [rsp+0x20], xmm2
00007cf1741df9b0  vmovaps [rsp+0x30], xmm3
00007cf1741df9b6  vmovaps [rsp+0x40], xmm4
00007cf1741df9bc  vmovaps [rsp+0x50], xmm5
00007cf1741df9c2  vmovaps [rsp+0x60], xmm6
00007cf1741df9c8  vmovaps [rsp+0x70], xmm7
00007cf1741df9ce  vmovaps [rsp+0x80], xmm8
00007cf1741df9d7  vmovaps [rsp+0x90], xmm9
00007cf1741df9e0  vmovaps [rsp+0xA0], xmm10
00007cf1741df9e9  vmovaps [rsp+0xB0], xmm11
00007cf1741df9f2  vmovaps [rsp+0xC0], xmm12
00007cf1741df9fb  vmovaps [rsp+0xD0], xmm14
00007cf1741dfa04  vmovaps [rsp+0xE0], xmm15
00007cf1741dfa0d  sub rsp, 0x30
00007cf1741dfa11  movaps [rsp], xmm13
00007cf1741dfa16  movaps [rsp+0x10], xmm15
00007cf1741dfa1c  movaps [rsp+0x20], xmm9
00007cf1741dfa22  lea rdi, [rsp]
00007cf1741dfa26  mov esi, 0x00
00007cf1741dfa2b  mov rax, 0x611C8A33A530
00007cf1741dfa35  call rax
00007cf1741dfa37  movaps xmm13, [rsp]
00007cf1741dfa3c  add rsp, 0x30
00007cf1741dfa40  vmovaps xmm0, [rsp]
00007cf1741dfa45  vmovaps xmm1, [rsp+0x10]
00007cf1741dfa4b  vmovaps xmm2, [rsp+0x20]
00007cf1741dfa51  vmovaps xmm3, [rsp+0x30]
00007cf1741dfa57  vmovaps xmm4, [rsp+0x40]
00007cf1741dfa5d  vmovaps xmm5, [rsp+0x50]
00007cf1741dfa63  vmovaps xmm6, [rsp+0x60]
00007cf1741dfa69  vmovaps xmm7, [rsp+0x70]
00007cf1741dfa6f  vmovaps xmm8, [rsp+0x80]
00007cf1741dfa78  vmovaps xmm9, [rsp+0x90]
00007cf1741dfa81  vmovaps xmm10, [rsp+0xA0]
00007cf1741dfa8a  vmovaps xmm11, [rsp+0xB0]
00007cf1741dfa93  vmovaps xmm12, [rsp+0xC0]
00007cf1741dfa9c  vmovaps xmm14, [rsp+0xD0]
00007cf1741dfaa5  vmovaps xmm15, [rsp+0xE0]
00007cf1741dfaae  add rsp, 0xF0
00007cf1741dfab5  pop r11
00007cf1741dfab7  pop r10
00007cf1741dfab9  pop r9
00007cf1741dfabb  pop r8
00007cf1741dfabd  pop rsi
00007cf1741dfabe  pop rdi
00007cf1741dfabf  pop rdx
00007cf1741dfac0  pop rcx
00007cf1741dfac1  pop rax
00007cf1741dfac2  add rsp, 0x08
00007cf1741dfac6  jmp 0x00007CF1741DC458
00007cf1741dfacb  sub rsp, 0x08
00007cf1741dfacf  push rax
00007cf1741dfad0  push rcx
00007cf1741dfad1  push rdx
00007cf1741dfad2  push rdi
00007cf1741dfad3  push rsi
00007cf1741dfad4  push r8
00007cf1741dfad6  push r9
00007cf1741dfad8  push r10
00007cf1741dfada  push r11
00007cf1741dfadc  sub rsp, 0xF0
00007cf1741dfae3  vmovaps [rsp], xmm0
00007cf1741dfae8  vmovaps [rsp+0x10], xmm1
00007cf1741dfaee  vmovaps [rsp+0x20], xmm2
00007cf1741dfaf4  vmovaps [rsp+0x30], xmm3
00007cf1741dfafa  vmovaps [rsp+0x40], xmm4
00007cf1741dfb00  vmovaps [rsp+0x50], xmm5
00007cf1741dfb06  vmovaps [rsp+0x60], xmm6
00007cf1741dfb0c  vmovaps [rsp+0x70], xmm7
00007cf1741dfb12  vmovaps [rsp+0x80], xmm8
00007cf1741dfb1b  vmovaps [rsp+0x90], xmm9
00007cf1741dfb24  vmovaps [rsp+0xA0], xmm10
00007cf1741dfb2d  vmovaps [rsp+0xB0], xmm11
00007cf1741dfb36  vmovaps [rsp+0xC0], xmm12
00007cf1741dfb3f  vmovaps [rsp+0xD0], xmm13
00007cf1741dfb48  vmovaps [rsp+0xE0], xmm14
00007cf1741dfb51  sub rsp, 0x30
00007cf1741dfb55  movaps [rsp], xmm15
00007cf1741dfb5a  movaps [rsp+0x10], xmm1
00007cf1741dfb5f  movaps [rsp+0x20], xmm5
00007cf1741dfb64  lea rdi, [rsp]
00007cf1741dfb68  mov esi, 0x00
00007cf1741dfb6d  mov rax, 0x611C8A33A530
00007cf1741dfb77  call rax
00007cf1741dfb79  movaps xmm15, [rsp]
00007cf1741dfb7e  add rsp, 0x30
00007cf1741dfb82  vmovaps xmm0, [rsp]
00007cf1741dfb87  vmovaps xmm1, [rsp+0x10]
00007cf1741dfb8d  vmovaps xmm2, [rsp+0x20]
00007cf1741dfb93  vmovaps xmm3, [rsp+0x30]
00007cf1741dfb99  vmovaps xmm4, [rsp+0x40]
00007cf1741dfb9f  vmovaps xmm5, [rsp+0x50]
00007cf1741dfba5  vmovaps xmm6, [rsp+0x60]
00007cf1741dfbab  vmovaps xmm7, [rsp+0x70]
00007cf1741dfbb1  vmovaps xmm8, [rsp+0x80]
00007cf1741dfbba  vmovaps xmm9, [rsp+0x90]
00007cf1741dfbc3  vmovaps xmm10, [rsp+0xA0]
00007cf1741dfbcc  vmovaps xmm11, [rsp+0xB0]
00007cf1741dfbd5  vmovaps xmm12, [rsp+0xC0]
00007cf1741dfbde  vmovaps xmm13, [rsp+0xD0]
00007cf1741dfbe7  vmovaps xmm14, [rsp+0xE0]
00007cf1741dfbf0  add rsp, 0xF0
00007cf1741dfbf7  pop r11
00007cf1741dfbf9  pop r10
00007cf1741dfbfb  pop r9
00007cf1741dfbfd  pop r8
00007cf1741dfbff  pop rsi
00007cf1741dfc00  pop rdi
00007cf1741dfc01  pop rdx
00007cf1741dfc02  pop rcx
00007cf1741dfc03  pop rax
00007cf1741dfc04  add rsp, 0x08
00007cf1741dfc08  jmp 0x00007CF1741DC473
00007cf1741dfc0d  call 0x00007CF1740B52F0
00007cf1741dfc12  jmp 0x00007CF1741DC4CE
00007cf1741dfc17  sub rsp, 0x08
00007cf1741dfc1b  push rax
00007cf1741dfc1c  push rcx
00007cf1741dfc1d  push rdx
00007cf1741dfc1e  push rdi
00007cf1741dfc1f  push rsi
00007cf1741dfc20  push r8
00007cf1741dfc22  push r9
00007cf1741dfc24  push r10
00007cf1741dfc26  push r11
00007cf1741dfc28  sub rsp, 0xF0
00007cf1741dfc2f  vmovaps [rsp], xmm0
00007cf1741dfc34  vmovaps [rsp+0x10], xmm1
00007cf1741dfc3a  vmovaps [rsp+0x20], xmm2
00007cf1741dfc40  vmovaps [rsp+0x30], xmm3
00007cf1741dfc46  vmovaps [rsp+0x40], xmm4
00007cf1741dfc4c  vmovaps [rsp+0x50], xmm5
00007cf1741dfc52  vmovaps [rsp+0x60], xmm6
00007cf1741dfc58  vmovaps [rsp+0x70], xmm7
00007cf1741dfc5e  vmovaps [rsp+0x80], xmm8
00007cf1741dfc67  vmovaps [rsp+0x90], xmm10
00007cf1741dfc70  vmovaps [rsp+0xA0], xmm11
00007cf1741dfc79  vmovaps [rsp+0xB0], xmm12
00007cf1741dfc82  vmovaps [rsp+0xC0], xmm13
00007cf1741dfc8b  vmovaps [rsp+0xD0], xmm14
00007cf1741dfc94  vmovaps [rsp+0xE0], xmm15
00007cf1741dfc9d  sub rsp, 0x30
00007cf1741dfca1  movaps [rsp], xmm9
00007cf1741dfca6  movaps [rsp+0x10], xmm8
00007cf1741dfcac  movaps [rsp+0x20], xmm11
00007cf1741dfcb2  lea rdi, [rsp]
00007cf1741dfcb6  mov esi, 0x00
00007cf1741dfcbb  mov rax, 0x611C8A33A530
00007cf1741dfcc5  call rax
00007cf1741dfcc7  movaps xmm9, [rsp]
00007cf1741dfccc  add rsp, 0x30
00007cf1741dfcd0  vmovaps xmm0, [rsp]
00007cf1741dfcd5  vmovaps xmm1, [rsp+0x10]
00007cf1741dfcdb  vmovaps xmm2, [rsp+0x20]
00007cf1741dfce1  vmovaps xmm3, [rsp+0x30]
00007cf1741dfce7  vmovaps xmm4, [rsp+0x40]
00007cf1741dfced  vmovaps xmm5, [rsp+0x50]
00007cf1741dfcf3  vmovaps xmm6, [rsp+0x60]
00007cf1741dfcf9  vmovaps xmm7, [rsp+0x70]
00007cf1741dfcff  vmovaps xmm8, [rsp+0x80]
00007cf1741dfd08  vmovaps xmm10, [rsp+0x90]
00007cf1741dfd11  vmovaps xmm11, [rsp+0xA0]
00007cf1741dfd1a  vmovaps xmm12, [rsp+0xB0]
00007cf1741dfd23  vmovaps xmm13, [rsp+0xC0]
00007cf1741dfd2c  vmovaps xmm14, [rsp+0xD0]
00007cf1741dfd35  vmovaps xmm15, [rsp+0xE0]
00007cf1741dfd3e  add rsp, 0xF0
00007cf1741dfd45  pop r11
00007cf1741dfd47  pop r10
00007cf1741dfd49  pop r9
00007cf1741dfd4b  pop r8
00007cf1741dfd4d  pop rsi
00007cf1741dfd4e  pop rdi
00007cf1741dfd4f  pop rdx
00007cf1741dfd50  pop rcx
00007cf1741dfd51  pop rax
00007cf1741dfd52  add rsp, 0x08
00007cf1741dfd56  jmp 0x00007CF1741DC505
00007cf1741dfd5b  sub rsp, 0x08
00007cf1741dfd5f  push rax
00007cf1741dfd60  push rcx
00007cf1741dfd61  push rdx
00007cf1741dfd62  push rdi
00007cf1741dfd63  push rsi
00007cf1741dfd64  push r8
00007cf1741dfd66  push r9
00007cf1741dfd68  push r10
00007cf1741dfd6a  push r11
00007cf1741dfd6c  sub rsp, 0xF0
00007cf1741dfd73  vmovaps [rsp], xmm0
00007cf1741dfd78  vmovaps [rsp+0x10], xmm1
00007cf1741dfd7e  vmovaps [rsp+0x20], xmm2
00007cf1741dfd84  vmovaps [rsp+0x30], xmm3
00007cf1741dfd8a  vmovaps [rsp+0x40], xmm4
00007cf1741dfd90  vmovaps [rsp+0x50], xmm5
00007cf1741dfd96  vmovaps [rsp+0x60], xmm6
00007cf1741dfd9c  vmovaps [rsp+0x70], xmm7
00007cf1741dfda2  vmovaps [rsp+0x80], xmm8
00007cf1741dfdab  vmovaps [rsp+0x90], xmm9
00007cf1741dfdb4  vmovaps [rsp+0xA0], xmm10
00007cf1741dfdbd  vmovaps [rsp+0xB0], xmm12
00007cf1741dfdc6  vmovaps [rsp+0xC0], xmm13
00007cf1741dfdcf  vmovaps [rsp+0xD0], xmm14
00007cf1741dfdd8  vmovaps [rsp+0xE0], xmm15
00007cf1741dfde1  sub rsp, 0x30
00007cf1741dfde5  movaps [rsp], xmm11
00007cf1741dfdea  movaps [rsp+0x10], xmm10
00007cf1741dfdf0  movaps [rsp+0x20], xmm6
00007cf1741dfdf5  lea rdi, [rsp]
00007cf1741dfdf9  mov esi, 0x00
00007cf1741dfdfe  mov rax, 0x611C8A33A530
00007cf1741dfe08  call rax
00007cf1741dfe0a  movaps xmm11, [rsp]
00007cf1741dfe0f  add rsp, 0x30
00007cf1741dfe13  vmovaps xmm0, [rsp]
00007cf1741dfe18  vmovaps xmm1, [rsp+0x10]
00007cf1741dfe1e  vmovaps xmm2, [rsp+0x20]
00007cf1741dfe24  vmovaps xmm3, [rsp+0x30]
00007cf1741dfe2a  vmovaps xmm4, [rsp+0x40]
00007cf1741dfe30  vmovaps xmm5, [rsp+0x50]
00007cf1741dfe36  vmovaps xmm6, [rsp+0x60]
00007cf1741dfe3c  vmovaps xmm7, [rsp+0x70]
00007cf1741dfe42  vmovaps xmm8, [rsp+0x80]
00007cf1741dfe4b  vmovaps xmm9, [rsp+0x90]
00007cf1741dfe54  vmovaps xmm10, [rsp+0xA0]
00007cf1741dfe5d  vmovaps xmm12, [rsp+0xB0]
00007cf1741dfe66  vmovaps xmm13, [rsp+0xC0]
00007cf1741dfe6f  vmovaps xmm14, [rsp+0xD0]
00007cf1741dfe78  vmovaps xmm15, [rsp+0xE0]
00007cf1741dfe81  add rsp, 0xF0
00007cf1741dfe88  pop r11
00007cf1741dfe8a  pop r10
00007cf1741dfe8c  pop r9
00007cf1741dfe8e  pop r8
00007cf1741dfe90  pop rsi
00007cf1741dfe91  pop rdi
00007cf1741dfe92  pop rdx
00007cf1741dfe93  pop rcx
00007cf1741dfe94  pop rax
00007cf1741dfe95  add rsp, 0x08
00007cf1741dfe99  jmp 0x00007CF1741DC520
00007cf1741dfe9e  sub rsp, 0x08
00007cf1741dfea2  push rax
00007cf1741dfea3  push rcx
00007cf1741dfea4  push rdx
00007cf1741dfea5  push rdi
00007cf1741dfea6  push rsi
00007cf1741dfea7  push r8
00007cf1741dfea9  push r9
00007cf1741dfeab  push r10
00007cf1741dfead  push r11
00007cf1741dfeaf  sub rsp, 0xF0
00007cf1741dfeb6  vmovaps [rsp], xmm0
00007cf1741dfebb  vmovaps [rsp+0x10], xmm1
00007cf1741dfec1  vmovaps [rsp+0x20], xmm2
00007cf1741dfec7  vmovaps [rsp+0x30], xmm3
00007cf1741dfecd  vmovaps [rsp+0x40], xmm4
00007cf1741dfed3  vmovaps [rsp+0x50], xmm5
00007cf1741dfed9  vmovaps [rsp+0x60], xmm6
00007cf1741dfedf  vmovaps [rsp+0x70], xmm7
00007cf1741dfee5  vmovaps [rsp+0x80], xmm8
00007cf1741dfeee  vmovaps [rsp+0x90], xmm9
00007cf1741dfef7  vmovaps [rsp+0xA0], xmm11
00007cf1741dff00  vmovaps [rsp+0xB0], xmm12
00007cf1741dff09  vmovaps [rsp+0xC0], xmm13
00007cf1741dff12  vmovaps [rsp+0xD0], xmm14
00007cf1741dff1b  vmovaps [rsp+0xE0], xmm15
00007cf1741dff24  sub rsp, 0x30
00007cf1741dff28  movaps [rsp], xmm10
00007cf1741dff2d  movaps [rsp+0x10], xmm14
00007cf1741dff33  movaps [rsp+0x20], xmm4
00007cf1741dff38  lea rdi, [rsp]
00007cf1741dff3c  mov esi, 0x00
00007cf1741dff41  mov rax, 0x611C8A33A530
00007cf1741dff4b  call rax
00007cf1741dff4d  movaps xmm10, [rsp]
00007cf1741dff52  add rsp, 0x30
00007cf1741dff56  vmovaps xmm0, [rsp]
00007cf1741dff5b  vmovaps xmm1, [rsp+0x10]
00007cf1741dff61  vmovaps xmm2, [rsp+0x20]
00007cf1741dff67  vmovaps xmm3, [rsp+0x30]
00007cf1741dff6d  vmovaps xmm4, [rsp+0x40]
00007cf1741dff73  vmovaps xmm5, [rsp+0x50]
00007cf1741dff79  vmovaps xmm6, [rsp+0x60]
00007cf1741dff7f  vmovaps xmm7, [rsp+0x70]
00007cf1741dff85  vmovaps xmm8, [rsp+0x80]
00007cf1741dff8e  vmovaps xmm9, [rsp+0x90]
00007cf1741dff97  vmovaps xmm11, [rsp+0xA0]
00007cf1741dffa0  vmovaps xmm12, [rsp+0xB0]
00007cf1741dffa9  vmovaps xmm13, [rsp+0xC0]
00007cf1741dffb2  vmovaps xmm14, [rsp+0xD0]
00007cf1741dffbb  vmovaps xmm15, [rsp+0xE0]
00007cf1741dffc4  add rsp, 0xF0
00007cf1741dffcb  pop r11
00007cf1741dffcd  pop r10
00007cf1741dffcf  pop r9
00007cf1741dffd1  pop r8
00007cf1741dffd3  pop rsi
00007cf1741dffd4  pop rdi
00007cf1741dffd5  pop rdx
00007cf1741dffd6  pop rcx
00007cf1741dffd7  pop rax
00007cf1741dffd8  add rsp, 0x08
00007cf1741dffdc  jmp 0x00007CF1741DC53B
00007cf1741dffe1  sub rsp, 0x08
00007cf1741dffe5  push rax
00007cf1741dffe6  push rcx
00007cf1741dffe7  push rdx
00007cf1741dffe8  push rdi
00007cf1741dffe9  push rsi
00007cf1741dffea  push r8
00007cf1741dffec  push r9
00007cf1741dffee  push r10
00007cf1741dfff0  push r11
00007cf1741dfff2  sub rsp, 0xF0
00007cf1741dfff9  vmovaps [rsp], xmm0
00007cf1741dfffe  vmovaps [rsp+0x10], xmm1
00007cf1741e0004  vmovaps [rsp+0x20], xmm2
00007cf1741e000a  vmovaps [rsp+0x30], xmm3
00007cf1741e0010  vmovaps [rsp+0x40], xmm4
00007cf1741e0016  vmovaps [rsp+0x50], xmm5
00007cf1741e001c  vmovaps [rsp+0x60], xmm6
00007cf1741e0022  vmovaps [rsp+0x70], xmm7
00007cf1741e0028  vmovaps [rsp+0x80], xmm9
00007cf1741e0031  vmovaps [rsp+0x90], xmm10
00007cf1741e003a  vmovaps [rsp+0xA0], xmm11
00007cf1741e0043  vmovaps [rsp+0xB0], xmm12
00007cf1741e004c  vmovaps [rsp+0xC0], xmm13
00007cf1741e0055  vmovaps [rsp+0xD0], xmm14
00007cf1741e005e  vmovaps [rsp+0xE0], xmm15
00007cf1741e0067  sub rsp, 0x30
00007cf1741e006b  movaps [rsp], xmm8
00007cf1741e0070  movaps [rsp+0x10], xmm1
00007cf1741e0075  movaps [rsp+0x20], xmm14
00007cf1741e007b  lea rdi, [rsp]
00007cf1741e007f  mov esi, 0x00
00007cf1741e0084  mov rax, 0x611C8A33A530
00007cf1741e008e  call rax
00007cf1741e0090  movaps xmm8, [rsp]
00007cf1741e0095  add rsp, 0x30
00007cf1741e0099  vmovaps xmm0, [rsp]
00007cf1741e009e  vmovaps xmm1, [rsp+0x10]
00007cf1741e00a4  vmovaps xmm2, [rsp+0x20]
00007cf1741e00aa  vmovaps xmm3, [rsp+0x30]
00007cf1741e00b0  vmovaps xmm4, [rsp+0x40]
00007cf1741e00b6  vmovaps xmm5, [rsp+0x50]
00007cf1741e00bc  vmovaps xmm6, [rsp+0x60]
00007cf1741e00c2  vmovaps xmm7, [rsp+0x70]
00007cf1741e00c8  vmovaps xmm9, [rsp+0x80]
00007cf1741e00d1  vmovaps xmm10, [rsp+0x90]
00007cf1741e00da  vmovaps xmm11, [rsp+0xA0]
00007cf1741e00e3  vmovaps xmm12, [rsp+0xB0]
00007cf1741e00ec  vmovaps xmm13, [rsp+0xC0]
00007cf1741e00f5  vmovaps xmm14, [rsp+0xD0]
00007cf1741e00fe  vmovaps xmm15, [rsp+0xE0]
00007cf1741e0107  add rsp, 0xF0
00007cf1741e010e  pop r11
00007cf1741e0110  pop r10
00007cf1741e0112  pop r9
00007cf1741e0114  pop r8
00007cf1741e0116  pop rsi
00007cf1741e0117  pop rdi
00007cf1741e0118  pop rdx
00007cf1741e0119  pop rcx
00007cf1741e011a  pop rax
00007cf1741e011b  add rsp, 0x08
00007cf1741e011f  jmp 0x00007CF1741DC561
00007cf1741e0124  sub rsp, 0x08
00007cf1741e0128  push rax
00007cf1741e0129  push rcx
00007cf1741e012a  push rdx
00007cf1741e012b  push rdi
00007cf1741e012c  push rsi
00007cf1741e012d  push r8
00007cf1741e012f  push r9
00007cf1741e0131  push r10
00007cf1741e0133  push r11
00007cf1741e0135  sub rsp, 0xF0
00007cf1741e013c  vmovaps [rsp], xmm0
00007cf1741e0141  vmovaps [rsp+0x10], xmm1
00007cf1741e0147  vmovaps [rsp+0x20], xmm2
00007cf1741e014d  vmovaps [rsp+0x30], xmm3
00007cf1741e0153  vmovaps [rsp+0x40], xmm4
00007cf1741e0159  vmovaps [rsp+0x50], xmm5
00007cf1741e015f  vmovaps [rsp+0x60], xmm7
00007cf1741e0165  vmovaps [rsp+0x70], xmm8
00007cf1741e016b  vmovaps [rsp+0x80], xmm9
00007cf1741e0174  vmovaps [rsp+0x90], xmm10
00007cf1741e017d  vmovaps [rsp+0xA0], xmm11
00007cf1741e0186  vmovaps [rsp+0xB0], xmm12
00007cf1741e018f  vmovaps [rsp+0xC0], xmm13
00007cf1741e0198  vmovaps [rsp+0xD0], xmm14
00007cf1741e01a1  vmovaps [rsp+0xE0], xmm15
00007cf1741e01aa  sub rsp, 0x30
00007cf1741e01ae  movaps [rsp], xmm6
00007cf1741e01b2  movaps [rsp+0x10], xmm1
00007cf1741e01b7  movaps [rsp+0x20], xmm14
00007cf1741e01bd  lea rdi, [rsp]
00007cf1741e01c1  mov esi, 0x00
00007cf1741e01c6  mov rax, 0x611C8A33A530
00007cf1741e01d0  call rax
00007cf1741e01d2  movaps xmm6, [rsp]
00007cf1741e01d6  add rsp, 0x30
00007cf1741e01da  vmovaps xmm0, [rsp]
00007cf1741e01df  vmovaps xmm1, [rsp+0x10]
00007cf1741e01e5  vmovaps xmm2, [rsp+0x20]
00007cf1741e01eb  vmovaps xmm3, [rsp+0x30]
00007cf1741e01f1  vmovaps xmm4, [rsp+0x40]
00007cf1741e01f7  vmovaps xmm5, [rsp+0x50]
00007cf1741e01fd  vmovaps xmm7, [rsp+0x60]
00007cf1741e0203  vmovaps xmm8, [rsp+0x70]
00007cf1741e0209  vmovaps xmm9, [rsp+0x80]
00007cf1741e0212  vmovaps xmm10, [rsp+0x90]
00007cf1741e021b  vmovaps xmm11, [rsp+0xA0]
00007cf1741e0224  vmovaps xmm12, [rsp+0xB0]
00007cf1741e022d  vmovaps xmm13, [rsp+0xC0]
00007cf1741e0236  vmovaps xmm14, [rsp+0xD0]
00007cf1741e023f  vmovaps xmm15, [rsp+0xE0]
00007cf1741e0248  add rsp, 0xF0
00007cf1741e024f  pop r11
00007cf1741e0251  pop r10
00007cf1741e0253  pop r9
00007cf1741e0255  pop r8
00007cf1741e0257  pop rsi
00007cf1741e0258  pop rdi
00007cf1741e0259  pop rdx
00007cf1741e025a  pop rcx
00007cf1741e025b  pop rax
00007cf1741e025c  add rsp, 0x08
00007cf1741e0260  jmp 0x00007CF1741DC58D
00007cf1741e0265  sub rsp, 0x08
00007cf1741e0269  push rax
00007cf1741e026a  push rcx
00007cf1741e026b  push rdx
00007cf1741e026c  push rdi
00007cf1741e026d  push rsi
00007cf1741e026e  push r8
00007cf1741e0270  push r9
00007cf1741e0272  push r10
00007cf1741e0274  push r11
00007cf1741e0276  sub rsp, 0xF0
00007cf1741e027d  vmovaps [rsp], xmm0
00007cf1741e0282  vmovaps [rsp+0x10], xmm1
00007cf1741e0288  vmovaps [rsp+0x20], xmm2
00007cf1741e028e  vmovaps [rsp+0x30], xmm3
00007cf1741e0294  vmovaps [rsp+0x40], xmm4
00007cf1741e029a  vmovaps [rsp+0x50], xmm5
00007cf1741e02a0  vmovaps [rsp+0x60], xmm6
00007cf1741e02a6  vmovaps [rsp+0x70], xmm7
00007cf1741e02ac  vmovaps [rsp+0x80], xmm8
00007cf1741e02b5  vmovaps [rsp+0x90], xmm9
00007cf1741e02be  vmovaps [rsp+0xA0], xmm10
00007cf1741e02c7  vmovaps [rsp+0xB0], xmm11
00007cf1741e02d0  vmovaps [rsp+0xC0], xmm12
00007cf1741e02d9  vmovaps [rsp+0xD0], xmm13
00007cf1741e02e2  vmovaps [rsp+0xE0], xmm15
00007cf1741e02eb  sub rsp, 0x30
00007cf1741e02ef  movaps [rsp], xmm14
00007cf1741e02f4  movaps [rsp+0x10], xmm12
00007cf1741e02fa  movaps [rsp+0x20], xmm1
00007cf1741e02ff  lea rdi, [rsp]
00007cf1741e0303  mov esi, 0x00
00007cf1741e0308  mov rax, 0x611C8A33A530
00007cf1741e0312  call rax
00007cf1741e0314  movaps xmm14, [rsp]
00007cf1741e0319  add rsp, 0x30
00007cf1741e031d  vmovaps xmm0, [rsp]
00007cf1741e0322  vmovaps xmm1, [rsp+0x10]
00007cf1741e0328  vmovaps xmm2, [rsp+0x20]
00007cf1741e032e  vmovaps xmm3, [rsp+0x30]
00007cf1741e0334  vmovaps xmm4, [rsp+0x40]
00007cf1741e033a  vmovaps xmm5, [rsp+0x50]
00007cf1741e0340  vmovaps xmm6, [rsp+0x60]
00007cf1741e0346  vmovaps xmm7, [rsp+0x70]
00007cf1741e034c  vmovaps xmm8, [rsp+0x80]
00007cf1741e0355  vmovaps xmm9, [rsp+0x90]
00007cf1741e035e  vmovaps xmm10, [rsp+0xA0]
00007cf1741e0367  vmovaps xmm11, [rsp+0xB0]
00007cf1741e0370  vmovaps xmm12, [rsp+0xC0]
00007cf1741e0379  vmovaps xmm13, [rsp+0xD0]
00007cf1741e0382  vmovaps xmm15, [rsp+0xE0]
00007cf1741e038b  add rsp, 0xF0
00007cf1741e0392  pop r11
00007cf1741e0394  pop r10
00007cf1741e0396  pop r9
00007cf1741e0398  pop r8
00007cf1741e039a  pop rsi
00007cf1741e039b  pop rdi
00007cf1741e039c  pop rdx
00007cf1741e039d  pop rcx
00007cf1741e039e  pop rax
00007cf1741e039f  add rsp, 0x08
00007cf1741e03a3  jmp 0x00007CF1741DC5B3
00007cf1741e03a8  sub rsp, 0x08
00007cf1741e03ac  push rax
00007cf1741e03ad  push rcx
00007cf1741e03ae  push rdx
00007cf1741e03af  push rdi
00007cf1741e03b0  push rsi
00007cf1741e03b1  push r8
00007cf1741e03b3  push r9
00007cf1741e03b5  push r10
00007cf1741e03b7  push r11
00007cf1741e03b9  sub rsp, 0xF0
00007cf1741e03c0  vmovaps [rsp], xmm0
00007cf1741e03c5  vmovaps [rsp+0x10], xmm2
00007cf1741e03cb  vmovaps [rsp+0x20], xmm3
00007cf1741e03d1  vmovaps [rsp+0x30], xmm4
00007cf1741e03d7  vmovaps [rsp+0x40], xmm5
00007cf1741e03dd  vmovaps [rsp+0x50], xmm6
00007cf1741e03e3  vmovaps [rsp+0x60], xmm7
00007cf1741e03e9  vmovaps [rsp+0x70], xmm8
00007cf1741e03ef  vmovaps [rsp+0x80], xmm9
00007cf1741e03f8  vmovaps [rsp+0x90], xmm10
00007cf1741e0401  vmovaps [rsp+0xA0], xmm11
00007cf1741e040a  vmovaps [rsp+0xB0], xmm12
00007cf1741e0413  vmovaps [rsp+0xC0], xmm13
00007cf1741e041c  vmovaps [rsp+0xD0], xmm14
00007cf1741e0425  vmovaps [rsp+0xE0], xmm15
00007cf1741e042e  sub rsp, 0x30
00007cf1741e0432  movaps [rsp], xmm1
00007cf1741e0436  movaps [rsp+0x10], xmm13
00007cf1741e043c  movaps [rsp+0x20], xmm9
00007cf1741e0442  lea rdi, [rsp]
00007cf1741e0446  mov esi, 0x00
00007cf1741e044b  mov rax, 0x611C8A33A530
00007cf1741e0455  call rax
00007cf1741e0457  movaps xmm1, [rsp]
00007cf1741e045b  add rsp, 0x30
00007cf1741e045f  vmovaps xmm0, [rsp]
00007cf1741e0464  vmovaps xmm2, [rsp+0x10]
00007cf1741e046a  vmovaps xmm3, [rsp+0x20]
00007cf1741e0470  vmovaps xmm4, [rsp+0x30]
00007cf1741e0476  vmovaps xmm5, [rsp+0x40]
00007cf1741e047c  vmovaps xmm6, [rsp+0x50]
00007cf1741e0482  vmovaps xmm7, [rsp+0x60]
00007cf1741e0488  vmovaps xmm8, [rsp+0x70]
00007cf1741e048e  vmovaps xmm9, [rsp+0x80]
00007cf1741e0497  vmovaps xmm10, [rsp+0x90]
00007cf1741e04a0  vmovaps xmm11, [rsp+0xA0]
00007cf1741e04a9  vmovaps xmm12, [rsp+0xB0]
00007cf1741e04b2  vmovaps xmm13, [rsp+0xC0]
00007cf1741e04bb  vmovaps xmm14, [rsp+0xD0]
00007cf1741e04c4  vmovaps xmm15, [rsp+0xE0]
00007cf1741e04cd  add rsp, 0xF0
00007cf1741e04d4  pop r11
00007cf1741e04d6  pop r10
00007cf1741e04d8  pop r9
00007cf1741e04da  pop r8
00007cf1741e04dc  pop rsi
00007cf1741e04dd  pop rdi
00007cf1741e04de  pop rdx
00007cf1741e04df  pop rcx
00007cf1741e04e0  pop rax
00007cf1741e04e1  add rsp, 0x08
00007cf1741e04e5  jmp 0x00007CF1741DC5CD
00007cf1741e04ea  sub rsp, 0x08
00007cf1741e04ee  push rax
00007cf1741e04ef  push rcx
00007cf1741e04f0  push rdx
00007cf1741e04f1  push rdi
00007cf1741e04f2  push rsi
00007cf1741e04f3  push r8
00007cf1741e04f5  push r9
00007cf1741e04f7  push r10
00007cf1741e04f9  push r11
00007cf1741e04fb  sub rsp, 0xF0
00007cf1741e0502  vmovaps [rsp], xmm0
00007cf1741e0507  vmovaps [rsp+0x10], xmm1
00007cf1741e050d  vmovaps [rsp+0x20], xmm2
00007cf1741e0513  vmovaps [rsp+0x30], xmm3
00007cf1741e0519  vmovaps [rsp+0x40], xmm4
00007cf1741e051f  vmovaps [rsp+0x50], xmm5
00007cf1741e0525  vmovaps [rsp+0x60], xmm6
00007cf1741e052b  vmovaps [rsp+0x70], xmm7
00007cf1741e0531  vmovaps [rsp+0x80], xmm8
00007cf1741e053a  vmovaps [rsp+0x90], xmm9
00007cf1741e0543  vmovaps [rsp+0xA0], xmm10
00007cf1741e054c  vmovaps [rsp+0xB0], xmm11
00007cf1741e0555  vmovaps [rsp+0xC0], xmm13
00007cf1741e055e  vmovaps [rsp+0xD0], xmm14
00007cf1741e0567  vmovaps [rsp+0xE0], xmm15
00007cf1741e0570  sub rsp, 0x30
00007cf1741e0574  movaps [rsp], xmm12
00007cf1741e0579  movaps [rsp+0x10], xmm7
00007cf1741e057e  movaps [rsp+0x20], xmm13
00007cf1741e0584  lea rdi, [rsp]
00007cf1741e0588  mov esi, 0x00
00007cf1741e058d  mov rax, 0x611C8A33A530
00007cf1741e0597  call rax
00007cf1741e0599  movaps xmm12, [rsp]
00007cf1741e059e  add rsp, 0x30
00007cf1741e05a2  vmovaps xmm0, [rsp]
00007cf1741e05a7  vmovaps xmm1, [rsp+0x10]
00007cf1741e05ad  vmovaps xmm2, [rsp+0x20]
00007cf1741e05b3  vmovaps xmm3, [rsp+0x30]
00007cf1741e05b9  vmovaps xmm4, [rsp+0x40]
00007cf1741e05bf  vmovaps xmm5, [rsp+0x50]
00007cf1741e05c5  vmovaps xmm6, [rsp+0x60]
00007cf1741e05cb  vmovaps xmm7, [rsp+0x70]
00007cf1741e05d1  vmovaps xmm8, [rsp+0x80]
00007cf1741e05da  vmovaps xmm9, [rsp+0x90]
00007cf1741e05e3  vmovaps xmm10, [rsp+0xA0]
00007cf1741e05ec  vmovaps xmm11, [rsp+0xB0]
00007cf1741e05f5  vmovaps xmm13, [rsp+0xC0]
00007cf1741e05fe  vmovaps xmm14, [rsp+0xD0]
00007cf1741e0607  vmovaps xmm15, [rsp+0xE0]
00007cf1741e0610  add rsp, 0xF0
00007cf1741e0617  pop r11
00007cf1741e0619  pop r10
00007cf1741e061b  pop r9
00007cf1741e061d  pop r8
00007cf1741e061f  pop rsi
00007cf1741e0620  pop rdi
00007cf1741e0621  pop rdx
00007cf1741e0622  pop rcx
00007cf1741e0623  pop rax
00007cf1741e0624  add rsp, 0x08
00007cf1741e0628  jmp 0x00007CF1741DC5F4
00007cf1741e062d  sub rsp, 0x08
00007cf1741e0631  push rax
00007cf1741e0632  push rcx
00007cf1741e0633  push rdx
00007cf1741e0634  push rdi
00007cf1741e0635  push rsi
00007cf1741e0636  push r8
00007cf1741e0638  push r9
00007cf1741e063a  push r10
00007cf1741e063c  push r11
00007cf1741e063e  sub rsp, 0xF0
00007cf1741e0645  vmovaps [rsp], xmm0
00007cf1741e064a  vmovaps [rsp+0x10], xmm1
00007cf1741e0650  vmovaps [rsp+0x20], xmm2
00007cf1741e0656  vmovaps [rsp+0x30], xmm3
00007cf1741e065c  vmovaps [rsp+0x40], xmm4
00007cf1741e0662  vmovaps [rsp+0x50], xmm5
00007cf1741e0668  vmovaps [rsp+0x60], xmm6
00007cf1741e066e  vmovaps [rsp+0x70], xmm7
00007cf1741e0674  vmovaps [rsp+0x80], xmm8
00007cf1741e067d  vmovaps [rsp+0x90], xmm9
00007cf1741e0686  vmovaps [rsp+0xA0], xmm10
00007cf1741e068f  vmovaps [rsp+0xB0], xmm11
00007cf1741e0698  vmovaps [rsp+0xC0], xmm12
00007cf1741e06a1  vmovaps [rsp+0xD0], xmm14
00007cf1741e06aa  vmovaps [rsp+0xE0], xmm15
00007cf1741e06b3  sub rsp, 0x30
00007cf1741e06b7  movaps [rsp], xmm13
00007cf1741e06bc  movaps [rsp+0x10], xmm15
00007cf1741e06c2  movaps [rsp+0x20], xmm8
00007cf1741e06c8  lea rdi, [rsp]
00007cf1741e06cc  mov esi, 0x00
00007cf1741e06d1  mov rax, 0x611C8A33A530
00007cf1741e06db  call rax
00007cf1741e06dd  movaps xmm13, [rsp]
00007cf1741e06e2  add rsp, 0x30
00007cf1741e06e6  vmovaps xmm0, [rsp]
00007cf1741e06eb  vmovaps xmm1, [rsp+0x10]
00007cf1741e06f1  vmovaps xmm2, [rsp+0x20]
00007cf1741e06f7  vmovaps xmm3, [rsp+0x30]
00007cf1741e06fd  vmovaps xmm4, [rsp+0x40]
00007cf1741e0703  vmovaps xmm5, [rsp+0x50]
00007cf1741e0709  vmovaps xmm6, [rsp+0x60]
00007cf1741e070f  vmovaps xmm7, [rsp+0x70]
00007cf1741e0715  vmovaps xmm8, [rsp+0x80]
00007cf1741e071e  vmovaps xmm9, [rsp+0x90]
00007cf1741e0727  vmovaps xmm10, [rsp+0xA0]
00007cf1741e0730  vmovaps xmm11, [rsp+0xB0]
00007cf1741e0739  vmovaps xmm12, [rsp+0xC0]
00007cf1741e0742  vmovaps xmm14, [rsp+0xD0]
00007cf1741e074b  vmovaps xmm15, [rsp+0xE0]
00007cf1741e0754  add rsp, 0xF0
00007cf1741e075b  pop r11
00007cf1741e075d  pop r10
00007cf1741e075f  pop r9
00007cf1741e0761  pop r8
00007cf1741e0763  pop rsi
00007cf1741e0764  pop rdi
00007cf1741e0765  pop rdx
00007cf1741e0766  pop rcx
00007cf1741e0767  pop rax
00007cf1741e0768  add rsp, 0x08
00007cf1741e076c  jmp 0x00007CF1741DC60F
00007cf1741e0771  sub rsp, 0x08
00007cf1741e0775  push rax
00007cf1741e0776  push rcx
00007cf1741e0777  push rdx
00007cf1741e0778  push rdi
00007cf1741e0779  push rsi
00007cf1741e077a  push r8
00007cf1741e077c  push r9
00007cf1741e077e  push r10
00007cf1741e0780  push r11
00007cf1741e0782  sub rsp, 0xF0
00007cf1741e0789  vmovaps [rsp], xmm0
00007cf1741e078e  vmovaps [rsp+0x10], xmm1
00007cf1741e0794  vmovaps [rsp+0x20], xmm2
00007cf1741e079a  vmovaps [rsp+0x30], xmm3
00007cf1741e07a0  vmovaps [rsp+0x40], xmm4
00007cf1741e07a6  vmovaps [rsp+0x50], xmm5
00007cf1741e07ac  vmovaps [rsp+0x60], xmm6
00007cf1741e07b2  vmovaps [rsp+0x70], xmm7
00007cf1741e07b8  vmovaps [rsp+0x80], xmm9
00007cf1741e07c1  vmovaps [rsp+0x90], xmm10
00007cf1741e07ca  vmovaps [rsp+0xA0], xmm11
00007cf1741e07d3  vmovaps [rsp+0xB0], xmm12
00007cf1741e07dc  vmovaps [rsp+0xC0], xmm13
00007cf1741e07e5  vmovaps [rsp+0xD0], xmm14
00007cf1741e07ee  vmovaps [rsp+0xE0], xmm15
00007cf1741e07f7  sub rsp, 0x30
00007cf1741e07fb  movaps [rsp], xmm8
00007cf1741e0800  movaps [rsp+0x10], xmm15
00007cf1741e0806  movaps [rsp+0x20], xmm9
00007cf1741e080c  lea rdi, [rsp]
00007cf1741e0810  mov esi, 0x00
00007cf1741e0815  mov rax, 0x611C8A33A530
00007cf1741e081f  call rax
00007cf1741e0821  movaps xmm8, [rsp]
00007cf1741e0826  add rsp, 0x30
00007cf1741e082a  vmovaps xmm0, [rsp]
00007cf1741e082f  vmovaps xmm1, [rsp+0x10]
00007cf1741e0835  vmovaps xmm2, [rsp+0x20]
00007cf1741e083b  vmovaps xmm3, [rsp+0x30]
00007cf1741e0841  vmovaps xmm4, [rsp+0x40]
00007cf1741e0847  vmovaps xmm5, [rsp+0x50]
00007cf1741e084d  vmovaps xmm6, [rsp+0x60]
00007cf1741e0853  vmovaps xmm7, [rsp+0x70]
00007cf1741e0859  vmovaps xmm9, [rsp+0x80]
00007cf1741e0862  vmovaps xmm10, [rsp+0x90]
00007cf1741e086b  vmovaps xmm11, [rsp+0xA0]
00007cf1741e0874  vmovaps xmm12, [rsp+0xB0]
00007cf1741e087d  vmovaps xmm13, [rsp+0xC0]
00007cf1741e0886  vmovaps xmm14, [rsp+0xD0]
00007cf1741e088f  vmovaps xmm15, [rsp+0xE0]
00007cf1741e0898  add rsp, 0xF0
00007cf1741e089f  pop r11
00007cf1741e08a1  pop r10
00007cf1741e08a3  pop r9
00007cf1741e08a5  pop r8
00007cf1741e08a7  pop rsi
00007cf1741e08a8  pop rdi
00007cf1741e08a9  pop rdx
00007cf1741e08aa  pop rcx
00007cf1741e08ab  pop rax
00007cf1741e08ac  add rsp, 0x08
00007cf1741e08b0  jmp 0x00007CF1741DC63D
00007cf1741e08b5  sub rsp, 0x08
00007cf1741e08b9  push rax
00007cf1741e08ba  push rcx
00007cf1741e08bb  push rdx
00007cf1741e08bc  push rdi
00007cf1741e08bd  push rsi
00007cf1741e08be  push r8
00007cf1741e08c0  push r9
00007cf1741e08c2  push r10
00007cf1741e08c4  push r11
00007cf1741e08c6  sub rsp, 0xF0
00007cf1741e08cd  vmovaps [rsp], xmm0
00007cf1741e08d2  vmovaps [rsp+0x10], xmm1
00007cf1741e08d8  vmovaps [rsp+0x20], xmm2
00007cf1741e08de  vmovaps [rsp+0x30], xmm3
00007cf1741e08e4  vmovaps [rsp+0x40], xmm4
00007cf1741e08ea  vmovaps [rsp+0x50], xmm5
00007cf1741e08f0  vmovaps [rsp+0x60], xmm6
00007cf1741e08f6  vmovaps [rsp+0x70], xmm7
00007cf1741e08fc  vmovaps [rsp+0x80], xmm8
00007cf1741e0905  vmovaps [rsp+0x90], xmm9
00007cf1741e090e  vmovaps [rsp+0xA0], xmm10
00007cf1741e0917  vmovaps [rsp+0xB0], xmm11
00007cf1741e0920  vmovaps [rsp+0xC0], xmm12
00007cf1741e0929  vmovaps [rsp+0xD0], xmm13
00007cf1741e0932  vmovaps [rsp+0xE0], xmm14
00007cf1741e093b  sub rsp, 0x30
00007cf1741e093f  movaps [rsp], xmm15
00007cf1741e0944  movaps [rsp+0x10], xmm11
00007cf1741e094a  movaps [rsp+0x20], xmm6
00007cf1741e094f  lea rdi, [rsp]
00007cf1741e0953  mov esi, 0x00
00007cf1741e0958  mov rax, 0x611C8A33A530
00007cf1741e0962  call rax
00007cf1741e0964  movaps xmm15, [rsp]
00007cf1741e0969  add rsp, 0x30
00007cf1741e096d  vmovaps xmm0, [rsp]
00007cf1741e0972  vmovaps xmm1, [rsp+0x10]
00007cf1741e0978  vmovaps xmm2, [rsp+0x20]
00007cf1741e097e  vmovaps xmm3, [rsp+0x30]
00007cf1741e0984  vmovaps xmm4, [rsp+0x40]
00007cf1741e098a  vmovaps xmm5, [rsp+0x50]
00007cf1741e0990  vmovaps xmm6, [rsp+0x60]
00007cf1741e0996  vmovaps xmm7, [rsp+0x70]
00007cf1741e099c  vmovaps xmm8, [rsp+0x80]
00007cf1741e09a5  vmovaps xmm9, [rsp+0x90]
00007cf1741e09ae  vmovaps xmm10, [rsp+0xA0]
00007cf1741e09b7  vmovaps xmm11, [rsp+0xB0]
00007cf1741e09c0  vmovaps xmm12, [rsp+0xC0]
00007cf1741e09c9  vmovaps xmm13, [rsp+0xD0]
00007cf1741e09d2  vmovaps xmm14, [rsp+0xE0]
00007cf1741e09db  add rsp, 0xF0
00007cf1741e09e2  pop r11
00007cf1741e09e4  pop r10
00007cf1741e09e6  pop r9
00007cf1741e09e8  pop r8
00007cf1741e09ea  pop rsi
00007cf1741e09eb  pop rdi
00007cf1741e09ec  pop rdx
00007cf1741e09ed  pop rcx
00007cf1741e09ee  pop rax
00007cf1741e09ef  add rsp, 0x08
00007cf1741e09f3  jmp 0x00007CF1741DC658
00007cf1741e09f8  sub rsp, 0x08
00007cf1741e09fc  push rax
00007cf1741e09fd  push rcx
00007cf1741e09fe  push rdx
00007cf1741e09ff  push rdi
00007cf1741e0a00  push rsi
00007cf1741e0a01  push r8
00007cf1741e0a03  push r9
00007cf1741e0a05  push r10
00007cf1741e0a07  push r11
00007cf1741e0a09  sub rsp, 0xF0
00007cf1741e0a10  vmovaps [rsp], xmm0
00007cf1741e0a15  vmovaps [rsp+0x10], xmm1
00007cf1741e0a1b  vmovaps [rsp+0x20], xmm2
00007cf1741e0a21  vmovaps [rsp+0x30], xmm3
00007cf1741e0a27  vmovaps [rsp+0x40], xmm4
00007cf1741e0a2d  vmovaps [rsp+0x50], xmm5
00007cf1741e0a33  vmovaps [rsp+0x60], xmm6
00007cf1741e0a39  vmovaps [rsp+0x70], xmm8
00007cf1741e0a3f  vmovaps [rsp+0x80], xmm9
00007cf1741e0a48  vmovaps [rsp+0x90], xmm10
00007cf1741e0a51  vmovaps [rsp+0xA0], xmm11
00007cf1741e0a5a  vmovaps [rsp+0xB0], xmm12
00007cf1741e0a63  vmovaps [rsp+0xC0], xmm13
00007cf1741e0a6c  vmovaps [rsp+0xD0], xmm14
00007cf1741e0a75  vmovaps [rsp+0xE0], xmm15
00007cf1741e0a7e  sub rsp, 0x30
00007cf1741e0a82  movaps [rsp], xmm7
00007cf1741e0a86  movaps [rsp+0x10], xmm11
00007cf1741e0a8c  movaps [rsp+0x20], xmm9
00007cf1741e0a92  lea rdi, [rsp]
00007cf1741e0a96  mov esi, 0x00
00007cf1741e0a9b  mov rax, 0x611C8A33A530
00007cf1741e0aa5  call rax
00007cf1741e0aa7  movaps xmm7, [rsp]
00007cf1741e0aab  add rsp, 0x30
00007cf1741e0aaf  vmovaps xmm0, [rsp]
00007cf1741e0ab4  vmovaps xmm1, [rsp+0x10]
00007cf1741e0aba  vmovaps xmm2, [rsp+0x20]
00007cf1741e0ac0  vmovaps xmm3, [rsp+0x30]
00007cf1741e0ac6  vmovaps xmm4, [rsp+0x40]
00007cf1741e0acc  vmovaps xmm5, [rsp+0x50]
00007cf1741e0ad2  vmovaps xmm6, [rsp+0x60]
00007cf1741e0ad8  vmovaps xmm8, [rsp+0x70]
00007cf1741e0ade  vmovaps xmm9, [rsp+0x80]
00007cf1741e0ae7  vmovaps xmm10, [rsp+0x90]
00007cf1741e0af0  vmovaps xmm11, [rsp+0xA0]
00007cf1741e0af9  vmovaps xmm12, [rsp+0xB0]
00007cf1741e0b02  vmovaps xmm13, [rsp+0xC0]
00007cf1741e0b0b  vmovaps xmm14, [rsp+0xD0]
00007cf1741e0b14  vmovaps xmm15, [rsp+0xE0]
00007cf1741e0b1d  add rsp, 0xF0
00007cf1741e0b24  pop r11
00007cf1741e0b26  pop r10
00007cf1741e0b28  pop r9
00007cf1741e0b2a  pop r8
00007cf1741e0b2c  pop rsi
00007cf1741e0b2d  pop rdi
00007cf1741e0b2e  pop rdx
00007cf1741e0b2f  pop rcx
00007cf1741e0b30  pop rax
00007cf1741e0b31  add rsp, 0x08
00007cf1741e0b35  jmp 0x00007CF1741DC685
00007cf1741e0b3a  sub rsp, 0x08
00007cf1741e0b3e  push rax
00007cf1741e0b3f  push rcx
00007cf1741e0b40  push rdx
00007cf1741e0b41  push rdi
00007cf1741e0b42  push rsi
00007cf1741e0b43  push r8
00007cf1741e0b45  push r9
00007cf1741e0b47  push r10
00007cf1741e0b49  push r11
00007cf1741e0b4b  sub rsp, 0xF0
00007cf1741e0b52  vmovaps [rsp], xmm0
00007cf1741e0b57  vmovaps [rsp+0x10], xmm1
00007cf1741e0b5d  vmovaps [rsp+0x20], xmm2
00007cf1741e0b63  vmovaps [rsp+0x30], xmm3
00007cf1741e0b69  vmovaps [rsp+0x40], xmm4
00007cf1741e0b6f  vmovaps [rsp+0x50], xmm5
00007cf1741e0b75  vmovaps [rsp+0x60], xmm6
00007cf1741e0b7b  vmovaps [rsp+0x70], xmm7
00007cf1741e0b81  vmovaps [rsp+0x80], xmm8
00007cf1741e0b8a  vmovaps [rsp+0x90], xmm9
00007cf1741e0b93  vmovaps [rsp+0xA0], xmm10
00007cf1741e0b9c  vmovaps [rsp+0xB0], xmm12
00007cf1741e0ba5  vmovaps [rsp+0xC0], xmm13
00007cf1741e0bae  vmovaps [rsp+0xD0], xmm14
00007cf1741e0bb7  vmovaps [rsp+0xE0], xmm15
00007cf1741e0bc0  sub rsp, 0x30
00007cf1741e0bc4  movaps [rsp], xmm11
00007cf1741e0bc9  movaps [rsp+0x10], xmm10
00007cf1741e0bcf  movaps [rsp+0x20], xmm14
00007cf1741e0bd5  lea rdi, [rsp]
00007cf1741e0bd9  mov esi, 0x00
00007cf1741e0bde  mov rax, 0x611C8A33A530
00007cf1741e0be8  call rax
00007cf1741e0bea  movaps xmm11, [rsp]
00007cf1741e0bef  add rsp, 0x30
00007cf1741e0bf3  vmovaps xmm0, [rsp]
00007cf1741e0bf8  vmovaps xmm1, [rsp+0x10]
00007cf1741e0bfe  vmovaps xmm2, [rsp+0x20]
00007cf1741e0c04  vmovaps xmm3, [rsp+0x30]
00007cf1741e0c0a  vmovaps xmm4, [rsp+0x40]
00007cf1741e0c10  vmovaps xmm5, [rsp+0x50]
00007cf1741e0c16  vmovaps xmm6, [rsp+0x60]
00007cf1741e0c1c  vmovaps xmm7, [rsp+0x70]
00007cf1741e0c22  vmovaps xmm8, [rsp+0x80]
00007cf1741e0c2b  vmovaps xmm9, [rsp+0x90]
00007cf1741e0c34  vmovaps xmm10, [rsp+0xA0]
00007cf1741e0c3d  vmovaps xmm12, [rsp+0xB0]
00007cf1741e0c46  vmovaps xmm13, [rsp+0xC0]
00007cf1741e0c4f  vmovaps xmm14, [rsp+0xD0]
00007cf1741e0c58  vmovaps xmm15, [rsp+0xE0]
00007cf1741e0c61  add rsp, 0xF0
00007cf1741e0c68  pop r11
00007cf1741e0c6a  pop r10
00007cf1741e0c6c  pop r9
00007cf1741e0c6e  pop r8
00007cf1741e0c70  pop rsi
00007cf1741e0c71  pop rdi
00007cf1741e0c72  pop rdx
00007cf1741e0c73  pop rcx
00007cf1741e0c74  pop rax
00007cf1741e0c75  add rsp, 0x08
00007cf1741e0c79  jmp 0x00007CF1741DC6A0
00007cf1741e0c7e  call 0x00007CF1740C33A0
00007cf1741e0c83  jmp 0x00007CF1741DC6AA
00007cf1741e0c88  sub rsp, 0x08
00007cf1741e0c8c  push rax
00007cf1741e0c8d  push rcx
00007cf1741e0c8e  push rdx
00007cf1741e0c8f  push rdi
00007cf1741e0c90  push rsi
00007cf1741e0c91  push r8
00007cf1741e0c93  push r9
00007cf1741e0c95  push r10
00007cf1741e0c97  push r11
00007cf1741e0c99  sub rsp, 0xF0
00007cf1741e0ca0  vmovaps [rsp], xmm0
00007cf1741e0ca5  vmovaps [rsp+0x10], xmm1
00007cf1741e0cab  vmovaps [rsp+0x20], xmm2
00007cf1741e0cb1  vmovaps [rsp+0x30], xmm3
00007cf1741e0cb7  vmovaps [rsp+0x40], xmm4
00007cf1741e0cbd  vmovaps [rsp+0x50], xmm5
00007cf1741e0cc3  vmovaps [rsp+0x60], xmm6
00007cf1741e0cc9  vmovaps [rsp+0x70], xmm7
00007cf1741e0ccf  vmovaps [rsp+0x80], xmm8
00007cf1741e0cd8  vmovaps [rsp+0x90], xmm9
00007cf1741e0ce1  vmovaps [rsp+0xA0], xmm11
00007cf1741e0cea  vmovaps [rsp+0xB0], xmm12
00007cf1741e0cf3  vmovaps [rsp+0xC0], xmm13
00007cf1741e0cfc  vmovaps [rsp+0xD0], xmm14
00007cf1741e0d05  vmovaps [rsp+0xE0], xmm15
00007cf1741e0d0e  sub rsp, 0x30
00007cf1741e0d12  movaps [rsp], xmm10
00007cf1741e0d17  movaps [rsp+0x10], xmm1
00007cf1741e0d1c  movaps [rsp+0x20], xmm12
00007cf1741e0d22  lea rdi, [rsp]
00007cf1741e0d26  mov esi, 0x00
00007cf1741e0d2b  mov rax, 0x611C8A33A530
00007cf1741e0d35  call rax
00007cf1741e0d37  movaps xmm10, [rsp]
00007cf1741e0d3c  add rsp, 0x30
00007cf1741e0d40  vmovaps xmm0, [rsp]
00007cf1741e0d45  vmovaps xmm1, [rsp+0x10]
00007cf1741e0d4b  vmovaps xmm2, [rsp+0x20]
00007cf1741e0d51  vmovaps xmm3, [rsp+0x30]
00007cf1741e0d57  vmovaps xmm4, [rsp+0x40]
00007cf1741e0d5d  vmovaps xmm5, [rsp+0x50]
00007cf1741e0d63  vmovaps xmm6, [rsp+0x60]
00007cf1741e0d69  vmovaps xmm7, [rsp+0x70]
00007cf1741e0d6f  vmovaps xmm8, [rsp+0x80]
00007cf1741e0d78  vmovaps xmm9, [rsp+0x90]
00007cf1741e0d81  vmovaps xmm11, [rsp+0xA0]
00007cf1741e0d8a  vmovaps xmm12, [rsp+0xB0]
00007cf1741e0d93  vmovaps xmm13, [rsp+0xC0]
00007cf1741e0d9c  vmovaps xmm14, [rsp+0xD0]
00007cf1741e0da5  vmovaps xmm15, [rsp+0xE0]
00007cf1741e0dae  add rsp, 0xF0
00007cf1741e0db5  pop r11
00007cf1741e0db7  pop r10
00007cf1741e0db9  pop r9
00007cf1741e0dbb  pop r8
00007cf1741e0dbd  pop rsi
00007cf1741e0dbe  pop rdi
00007cf1741e0dbf  pop rdx
00007cf1741e0dc0  pop rcx
00007cf1741e0dc1  pop rax
00007cf1741e0dc2  add rsp, 0x08
00007cf1741e0dc6  jmp 0x00007CF1741DC6CD
00007cf1741e0dcb  sub rsp, 0x08
00007cf1741e0dcf  push rax
00007cf1741e0dd0  push rcx
00007cf1741e0dd1  push rdx
00007cf1741e0dd2  push rdi
00007cf1741e0dd3  push rsi
00007cf1741e0dd4  push r8
00007cf1741e0dd6  push r9
00007cf1741e0dd8  push r10
00007cf1741e0dda  push r11
00007cf1741e0ddc  sub rsp, 0xF0
00007cf1741e0de3  vmovaps [rsp], xmm0
00007cf1741e0de8  vmovaps [rsp+0x10], xmm1
00007cf1741e0dee  vmovaps [rsp+0x20], xmm2
00007cf1741e0df4  vmovaps [rsp+0x30], xmm3
00007cf1741e0dfa  vmovaps [rsp+0x40], xmm4
00007cf1741e0e00  vmovaps [rsp+0x50], xmm5
00007cf1741e0e06  vmovaps [rsp+0x60], xmm6
00007cf1741e0e0c  vmovaps [rsp+0x70], xmm7
00007cf1741e0e12  vmovaps [rsp+0x80], xmm8
00007cf1741e0e1b  vmovaps [rsp+0x90], xmm9
00007cf1741e0e24  vmovaps [rsp+0xA0], xmm10
00007cf1741e0e2d  vmovaps [rsp+0xB0], xmm11
00007cf1741e0e36  vmovaps [rsp+0xC0], xmm13
00007cf1741e0e3f  vmovaps [rsp+0xD0], xmm14
00007cf1741e0e48  vmovaps [rsp+0xE0], xmm15
00007cf1741e0e51  sub rsp, 0x30
00007cf1741e0e55  movaps [rsp], xmm12
00007cf1741e0e5a  movaps [rsp+0x10], xmm14
00007cf1741e0e60  movaps [rsp+0x20], xmm1
00007cf1741e0e65  lea rdi, [rsp]
00007cf1741e0e69  mov esi, 0x00
00007cf1741e0e6e  mov rax, 0x611C8A33A530
00007cf1741e0e78  call rax
00007cf1741e0e7a  movaps xmm12, [rsp]
00007cf1741e0e7f  add rsp, 0x30
00007cf1741e0e83  vmovaps xmm0, [rsp]
00007cf1741e0e88  vmovaps xmm1, [rsp+0x10]
00007cf1741e0e8e  vmovaps xmm2, [rsp+0x20]
00007cf1741e0e94  vmovaps xmm3, [rsp+0x30]
00007cf1741e0e9a  vmovaps xmm4, [rsp+0x40]
00007cf1741e0ea0  vmovaps xmm5, [rsp+0x50]
00007cf1741e0ea6  vmovaps xmm6, [rsp+0x60]
00007cf1741e0eac  vmovaps xmm7, [rsp+0x70]
00007cf1741e0eb2  vmovaps xmm8, [rsp+0x80]
00007cf1741e0ebb  vmovaps xmm9, [rsp+0x90]
00007cf1741e0ec4  vmovaps xmm10, [rsp+0xA0]
00007cf1741e0ecd  vmovaps xmm11, [rsp+0xB0]
00007cf1741e0ed6  vmovaps xmm13, [rsp+0xC0]
00007cf1741e0edf  vmovaps xmm14, [rsp+0xD0]
00007cf1741e0ee8  vmovaps xmm15, [rsp+0xE0]
00007cf1741e0ef1  add rsp, 0xF0
00007cf1741e0ef8  pop r11
00007cf1741e0efa  pop r10
00007cf1741e0efc  pop r9
00007cf1741e0efe  pop r8
00007cf1741e0f00  pop rsi
00007cf1741e0f01  pop rdi
00007cf1741e0f02  pop rdx
00007cf1741e0f03  pop rcx
00007cf1741e0f04  pop rax
00007cf1741e0f05  add rsp, 0x08
00007cf1741e0f09  jmp 0x00007CF1741DC6FC
00007cf1741e0f0e  sub rsp, 0x08
00007cf1741e0f12  push rax
00007cf1741e0f13  push rcx
00007cf1741e0f14  push rdx
00007cf1741e0f15  push rdi
00007cf1741e0f16  push rsi
00007cf1741e0f17  push r8
00007cf1741e0f19  push r9
00007cf1741e0f1b  push r10
00007cf1741e0f1d  push r11
00007cf1741e0f1f  sub rsp, 0xF0
00007cf1741e0f26  vmovaps [rsp], xmm0
00007cf1741e0f2b  vmovaps [rsp+0x10], xmm1
00007cf1741e0f31  vmovaps [rsp+0x20], xmm2
00007cf1741e0f37  vmovaps [rsp+0x30], xmm3
00007cf1741e0f3d  vmovaps [rsp+0x40], xmm4
00007cf1741e0f43  vmovaps [rsp+0x50], xmm5
00007cf1741e0f49  vmovaps [rsp+0x60], xmm6
00007cf1741e0f4f  vmovaps [rsp+0x70], xmm7
00007cf1741e0f55  vmovaps [rsp+0x80], xmm8
00007cf1741e0f5e  vmovaps [rsp+0x90], xmm9
00007cf1741e0f67  vmovaps [rsp+0xA0], xmm10
00007cf1741e0f70  vmovaps [rsp+0xB0], xmm11
00007cf1741e0f79  vmovaps [rsp+0xC0], xmm12
00007cf1741e0f82  vmovaps [rsp+0xD0], xmm13
00007cf1741e0f8b  vmovaps [rsp+0xE0], xmm15
00007cf1741e0f94  sub rsp, 0x30
00007cf1741e0f98  movaps [rsp], xmm14
00007cf1741e0f9d  movaps [rsp+0x10], xmm9
00007cf1741e0fa3  movaps [rsp+0x20], xmm1
00007cf1741e0fa8  lea rdi, [rsp]
00007cf1741e0fac  mov esi, 0x00
00007cf1741e0fb1  mov rax, 0x611C8A33A530
00007cf1741e0fbb  call rax
00007cf1741e0fbd  movaps xmm14, [rsp]
00007cf1741e0fc2  add rsp, 0x30
00007cf1741e0fc6  vmovaps xmm0, [rsp]
00007cf1741e0fcb  vmovaps xmm1, [rsp+0x10]
00007cf1741e0fd1  vmovaps xmm2, [rsp+0x20]
00007cf1741e0fd7  vmovaps xmm3, [rsp+0x30]
00007cf1741e0fdd  vmovaps xmm4, [rsp+0x40]
00007cf1741e0fe3  vmovaps xmm5, [rsp+0x50]
00007cf1741e0fe9  vmovaps xmm6, [rsp+0x60]
00007cf1741e0fef  vmovaps xmm7, [rsp+0x70]
00007cf1741e0ff5  vmovaps xmm8, [rsp+0x80]
00007cf1741e0ffe  vmovaps xmm9, [rsp+0x90]
00007cf1741e1007  vmovaps xmm10, [rsp+0xA0]
00007cf1741e1010  vmovaps xmm11, [rsp+0xB0]
00007cf1741e1019  vmovaps xmm12, [rsp+0xC0]
00007cf1741e1022  vmovaps xmm13, [rsp+0xD0]
00007cf1741e102b  vmovaps xmm15, [rsp+0xE0]
00007cf1741e1034  add rsp, 0xF0
00007cf1741e103b  pop r11
00007cf1741e103d  pop r10
00007cf1741e103f  pop r9
00007cf1741e1041  pop r8
00007cf1741e1043  pop rsi
00007cf1741e1044  pop rdi
00007cf1741e1045  pop rdx
00007cf1741e1046  pop rcx
00007cf1741e1047  pop rax
00007cf1741e1048  add rsp, 0x08
00007cf1741e104c  jmp 0x00007CF1741DC72B
00007cf1741e1051  sub rsp, 0x08
00007cf1741e1055  push rax
00007cf1741e1056  push rcx
00007cf1741e1057  push rdx
00007cf1741e1058  push rdi
00007cf1741e1059  push rsi
00007cf1741e105a  push r8
00007cf1741e105c  push r9
00007cf1741e105e  push r10
00007cf1741e1060  push r11
00007cf1741e1062  sub rsp, 0xF0
00007cf1741e1069  vmovaps [rsp], xmm0
00007cf1741e106e  vmovaps [rsp+0x10], xmm2
00007cf1741e1074  vmovaps [rsp+0x20], xmm3
00007cf1741e107a  vmovaps [rsp+0x30], xmm4
00007cf1741e1080  vmovaps [rsp+0x40], xmm5
00007cf1741e1086  vmovaps [rsp+0x50], xmm6
00007cf1741e108c  vmovaps [rsp+0x60], xmm7
00007cf1741e1092  vmovaps [rsp+0x70], xmm8
00007cf1741e1098  vmovaps [rsp+0x80], xmm9
00007cf1741e10a1  vmovaps [rsp+0x90], xmm10
00007cf1741e10aa  vmovaps [rsp+0xA0], xmm11
00007cf1741e10b3  vmovaps [rsp+0xB0], xmm12
00007cf1741e10bc  vmovaps [rsp+0xC0], xmm13
00007cf1741e10c5  vmovaps [rsp+0xD0], xmm14
00007cf1741e10ce  vmovaps [rsp+0xE0], xmm15
00007cf1741e10d7  sub rsp, 0x30
00007cf1741e10db  movaps [rsp], xmm1
00007cf1741e10df  movaps [rsp+0x10], xmm13
00007cf1741e10e5  movaps [rsp+0x20], xmm8
00007cf1741e10eb  lea rdi, [rsp]
00007cf1741e10ef  mov esi, 0x00
00007cf1741e10f4  mov rax, 0x611C8A33A530
00007cf1741e10fe  call rax
00007cf1741e1100  movaps xmm1, [rsp]
00007cf1741e1104  add rsp, 0x30
00007cf1741e1108  vmovaps xmm0, [rsp]
00007cf1741e110d  vmovaps xmm2, [rsp+0x10]
00007cf1741e1113  vmovaps xmm3, [rsp+0x20]
00007cf1741e1119  vmovaps xmm4, [rsp+0x30]
00007cf1741e111f  vmovaps xmm5, [rsp+0x40]
00007cf1741e1125  vmovaps xmm6, [rsp+0x50]
00007cf1741e112b  vmovaps xmm7, [rsp+0x60]
00007cf1741e1131  vmovaps xmm8, [rsp+0x70]
00007cf1741e1137  vmovaps xmm9, [rsp+0x80]
00007cf1741e1140  vmovaps xmm10, [rsp+0x90]
00007cf1741e1149  vmovaps xmm11, [rsp+0xA0]
00007cf1741e1152  vmovaps xmm12, [rsp+0xB0]
00007cf1741e115b  vmovaps xmm13, [rsp+0xC0]
00007cf1741e1164  vmovaps xmm14, [rsp+0xD0]
00007cf1741e116d  vmovaps xmm15, [rsp+0xE0]
00007cf1741e1176  add rsp, 0xF0
00007cf1741e117d  pop r11
00007cf1741e117f  pop r10
00007cf1741e1181  pop r9
00007cf1741e1183  pop r8
00007cf1741e1185  pop rsi
00007cf1741e1186  pop rdi
00007cf1741e1187  pop rdx
00007cf1741e1188  pop rcx
00007cf1741e1189  pop rax
00007cf1741e118a  add rsp, 0x08
00007cf1741e118e  jmp 0x00007CF1741DC74D
00007cf1741e1193  call 0x00007CF17400C260
00007cf1741e1198  jmp 0x00007CF1741DC75B
00007cf1741e119d  call 0x00007CF1740BD750
00007cf1741e11a2  jmp 0x00007CF1741DC765
00007cf1741e11a7  sub rsp, 0x08
00007cf1741e11ab  push rax
00007cf1741e11ac  push rcx
00007cf1741e11ad  push rdx
00007cf1741e11ae  push rdi
00007cf1741e11af  push rsi
00007cf1741e11b0  push r8
00007cf1741e11b2  push r9
00007cf1741e11b4  push r10
00007cf1741e11b6  push r11
00007cf1741e11b8  sub rsp, 0xF0
00007cf1741e11bf  vmovaps [rsp], xmm0
00007cf1741e11c4  vmovaps [rsp+0x10], xmm1
00007cf1741e11ca  vmovaps [rsp+0x20], xmm2
00007cf1741e11d0  vmovaps [rsp+0x30], xmm3
00007cf1741e11d6  vmovaps [rsp+0x40], xmm4
00007cf1741e11dc  vmovaps [rsp+0x50], xmm5
00007cf1741e11e2  vmovaps [rsp+0x60], xmm6
00007cf1741e11e8  vmovaps [rsp+0x70], xmm7
00007cf1741e11ee  vmovaps [rsp+0x80], xmm9
00007cf1741e11f7  vmovaps [rsp+0x90], xmm10
00007cf1741e1200  vmovaps [rsp+0xA0], xmm11
00007cf1741e1209  vmovaps [rsp+0xB0], xmm12
00007cf1741e1212  vmovaps [rsp+0xC0], xmm13
00007cf1741e121b  vmovaps [rsp+0xD0], xmm14
00007cf1741e1224  vmovaps [rsp+0xE0], xmm15
00007cf1741e122d  sub rsp, 0x30
00007cf1741e1231  movaps [rsp], xmm8
00007cf1741e1236  movaps [rsp+0x10], xmm15
00007cf1741e123c  movaps [rsp+0x20], xmm7
00007cf1741e1241  lea rdi, [rsp]
00007cf1741e1245  mov esi, 0x00
00007cf1741e124a  mov rax, 0x611C8A33A530
00007cf1741e1254  call rax
00007cf1741e1256  movaps xmm8, [rsp]
00007cf1741e125b  add rsp, 0x30
00007cf1741e125f  vmovaps xmm0, [rsp]
00007cf1741e1264  vmovaps xmm1, [rsp+0x10]
00007cf1741e126a  vmovaps xmm2, [rsp+0x20]
00007cf1741e1270  vmovaps xmm3, [rsp+0x30]
00007cf1741e1276  vmovaps xmm4, [rsp+0x40]
00007cf1741e127c  vmovaps xmm5, [rsp+0x50]
00007cf1741e1282  vmovaps xmm6, [rsp+0x60]
00007cf1741e1288  vmovaps xmm7, [rsp+0x70]
00007cf1741e128e  vmovaps xmm9, [rsp+0x80]
00007cf1741e1297  vmovaps xmm10, [rsp+0x90]
00007cf1741e12a0  vmovaps xmm11, [rsp+0xA0]
00007cf1741e12a9  vmovaps xmm12, [rsp+0xB0]
00007cf1741e12b2  vmovaps xmm13, [rsp+0xC0]
00007cf1741e12bb  vmovaps xmm14, [rsp+0xD0]
00007cf1741e12c4  vmovaps xmm15, [rsp+0xE0]
00007cf1741e12cd  add rsp, 0xF0
00007cf1741e12d4  pop r11
00007cf1741e12d6  pop r10
00007cf1741e12d8  pop r9
00007cf1741e12da  pop r8
00007cf1741e12dc  pop rsi
00007cf1741e12dd  pop rdi
00007cf1741e12de  pop rdx
00007cf1741e12df  pop rcx
00007cf1741e12e0  pop rax
00007cf1741e12e1  add rsp, 0x08
00007cf1741e12e5  jmp 0x00007CF1741DC787
00007cf1741e12ea  sub rsp, 0x08
00007cf1741e12ee  push rax
00007cf1741e12ef  push rcx
00007cf1741e12f0  push rdx
00007cf1741e12f1  push rdi
00007cf1741e12f2  push rsi
00007cf1741e12f3  push r8
00007cf1741e12f5  push r9
00007cf1741e12f7  push r10
00007cf1741e12f9  push r11
00007cf1741e12fb  sub rsp, 0xF0
00007cf1741e1302  vmovaps [rsp], xmm0
00007cf1741e1307  vmovaps [rsp+0x10], xmm1
00007cf1741e130d  vmovaps [rsp+0x20], xmm2
00007cf1741e1313  vmovaps [rsp+0x30], xmm3
00007cf1741e1319  vmovaps [rsp+0x40], xmm4
00007cf1741e131f  vmovaps [rsp+0x50], xmm5
00007cf1741e1325  vmovaps [rsp+0x60], xmm6
00007cf1741e132b  vmovaps [rsp+0x70], xmm8
00007cf1741e1331  vmovaps [rsp+0x80], xmm9
00007cf1741e133a  vmovaps [rsp+0x90], xmm10
00007cf1741e1343  vmovaps [rsp+0xA0], xmm11
00007cf1741e134c  vmovaps [rsp+0xB0], xmm12
00007cf1741e1355  vmovaps [rsp+0xC0], xmm13
00007cf1741e135e  vmovaps [rsp+0xD0], xmm14
00007cf1741e1367  vmovaps [rsp+0xE0], xmm15
00007cf1741e1370  sub rsp, 0x30
00007cf1741e1374  movaps [rsp], xmm7
00007cf1741e1378  movaps [rsp+0x10], xmm9
00007cf1741e137e  movaps [rsp+0x20], xmm15
00007cf1741e1384  lea rdi, [rsp]
00007cf1741e1388  mov esi, 0x00
00007cf1741e138d  mov rax, 0x611C8A33A530
00007cf1741e1397  call rax
00007cf1741e1399  movaps xmm7, [rsp]
00007cf1741e139d  add rsp, 0x30
00007cf1741e13a1  vmovaps xmm0, [rsp]
00007cf1741e13a6  vmovaps xmm1, [rsp+0x10]
00007cf1741e13ac  vmovaps xmm2, [rsp+0x20]
00007cf1741e13b2  vmovaps xmm3, [rsp+0x30]
00007cf1741e13b8  vmovaps xmm4, [rsp+0x40]
00007cf1741e13be  vmovaps xmm5, [rsp+0x50]
00007cf1741e13c4  vmovaps xmm6, [rsp+0x60]
00007cf1741e13ca  vmovaps xmm8, [rsp+0x70]
00007cf1741e13d0  vmovaps xmm9, [rsp+0x80]
00007cf1741e13d9  vmovaps xmm10, [rsp+0x90]
00007cf1741e13e2  vmovaps xmm11, [rsp+0xA0]
00007cf1741e13eb  vmovaps xmm12, [rsp+0xB0]
00007cf1741e13f4  vmovaps xmm13, [rsp+0xC0]
00007cf1741e13fd  vmovaps xmm14, [rsp+0xD0]
00007cf1741e1406  vmovaps xmm15, [rsp+0xE0]
00007cf1741e140f  add rsp, 0xF0
00007cf1741e1416  pop r11
00007cf1741e1418  pop r10
00007cf1741e141a  pop r9
00007cf1741e141c  pop r8
00007cf1741e141e  pop rsi
00007cf1741e141f  pop rdi
00007cf1741e1420  pop rdx
00007cf1741e1421  pop rcx
00007cf1741e1422  pop rax
00007cf1741e1423  add rsp, 0x08
00007cf1741e1427  jmp 0x00007CF1741DC7B4
00007cf1741e142c  sub rsp, 0x08
00007cf1741e1430  push rax
00007cf1741e1431  push rcx
00007cf1741e1432  push rdx
00007cf1741e1433  push rdi
00007cf1741e1434  push rsi
00007cf1741e1435  push r8
00007cf1741e1437  push r9
00007cf1741e1439  push r10
00007cf1741e143b  push r11
00007cf1741e143d  sub rsp, 0xF0
00007cf1741e1444  vmovaps [rsp], xmm0
00007cf1741e1449  vmovaps [rsp+0x10], xmm1
00007cf1741e144f  vmovaps [rsp+0x20], xmm2
00007cf1741e1455  vmovaps [rsp+0x30], xmm3
00007cf1741e145b  vmovaps [rsp+0x40], xmm4
00007cf1741e1461  vmovaps [rsp+0x50], xmm5
00007cf1741e1467  vmovaps [rsp+0x60], xmm6
00007cf1741e146d  vmovaps [rsp+0x70], xmm7
00007cf1741e1473  vmovaps [rsp+0x80], xmm8
00007cf1741e147c  vmovaps [rsp+0x90], xmm10
00007cf1741e1485  vmovaps [rsp+0xA0], xmm11
00007cf1741e148e  vmovaps [rsp+0xB0], xmm12
00007cf1741e1497  vmovaps [rsp+0xC0], xmm13
00007cf1741e14a0  vmovaps [rsp+0xD0], xmm14
00007cf1741e14a9  vmovaps [rsp+0xE0], xmm15
00007cf1741e14b2  sub rsp, 0x30
00007cf1741e14b6  movaps [rsp], xmm9
00007cf1741e14bb  movaps [rsp+0x10], xmm13
00007cf1741e14c1  movaps [rsp+0x20], xmm15
00007cf1741e14c7  lea rdi, [rsp]
00007cf1741e14cb  mov esi, 0x00
00007cf1741e14d0  mov rax, 0x611C8A33A530
00007cf1741e14da  call rax
00007cf1741e14dc  movaps xmm9, [rsp]
00007cf1741e14e1  add rsp, 0x30
00007cf1741e14e5  vmovaps xmm0, [rsp]
00007cf1741e14ea  vmovaps xmm1, [rsp+0x10]
00007cf1741e14f0  vmovaps xmm2, [rsp+0x20]
00007cf1741e14f6  vmovaps xmm3, [rsp+0x30]
00007cf1741e14fc  vmovaps xmm4, [rsp+0x40]
00007cf1741e1502  vmovaps xmm5, [rsp+0x50]
00007cf1741e1508  vmovaps xmm6, [rsp+0x60]
00007cf1741e150e  vmovaps xmm7, [rsp+0x70]
00007cf1741e1514  vmovaps xmm8, [rsp+0x80]
00007cf1741e151d  vmovaps xmm10, [rsp+0x90]
00007cf1741e1526  vmovaps xmm11, [rsp+0xA0]
00007cf1741e152f  vmovaps xmm12, [rsp+0xB0]
00007cf1741e1538  vmovaps xmm13, [rsp+0xC0]
00007cf1741e1541  vmovaps xmm14, [rsp+0xD0]
00007cf1741e154a  vmovaps xmm15, [rsp+0xE0]
00007cf1741e1553  add rsp, 0xF0
00007cf1741e155a  pop r11
00007cf1741e155c  pop r10
00007cf1741e155e  pop r9
00007cf1741e1560  pop r8
00007cf1741e1562  pop rsi
00007cf1741e1563  pop rdi
00007cf1741e1564  pop rdx
00007cf1741e1565  pop rcx
00007cf1741e1566  pop rax
00007cf1741e1567  add rsp, 0x08
00007cf1741e156b  jmp 0x00007CF1741DC7E2
00007cf1741e1570  sub rsp, 0x08
00007cf1741e1574  push rax
00007cf1741e1575  push rcx
00007cf1741e1576  push rdx
00007cf1741e1577  push rdi
00007cf1741e1578  push rsi
00007cf1741e1579  push r8
00007cf1741e157b  push r9
00007cf1741e157d  push r10
00007cf1741e157f  push r11
00007cf1741e1581  sub rsp, 0xF0
00007cf1741e1588  vmovaps [rsp], xmm0
00007cf1741e158d  vmovaps [rsp+0x10], xmm1
00007cf1741e1593  vmovaps [rsp+0x20], xmm2
00007cf1741e1599  vmovaps [rsp+0x30], xmm3
00007cf1741e159f  vmovaps [rsp+0x40], xmm4
00007cf1741e15a5  vmovaps [rsp+0x50], xmm5
00007cf1741e15ab  vmovaps [rsp+0x60], xmm6
00007cf1741e15b1  vmovaps [rsp+0x70], xmm7
00007cf1741e15b7  vmovaps [rsp+0x80], xmm8
00007cf1741e15c0  vmovaps [rsp+0x90], xmm9
00007cf1741e15c9  vmovaps [rsp+0xA0], xmm10
00007cf1741e15d2  vmovaps [rsp+0xB0], xmm11
00007cf1741e15db  vmovaps [rsp+0xC0], xmm12
00007cf1741e15e4  vmovaps [rsp+0xD0], xmm13
00007cf1741e15ed  vmovaps [rsp+0xE0], xmm14
00007cf1741e15f6  sub rsp, 0x30
00007cf1741e15fa  movaps [rsp], xmm15
00007cf1741e15ff  movaps [rsp+0x10], xmm11
00007cf1741e1605  movaps [rsp+0x20], xmm12
00007cf1741e160b  lea rdi, [rsp]
00007cf1741e160f  mov esi, 0x00
00007cf1741e1614  mov rax, 0x611C8A33A530
00007cf1741e161e  call rax
00007cf1741e1620  movaps xmm15, [rsp]
00007cf1741e1625  add rsp, 0x30
00007cf1741e1629  vmovaps xmm0, [rsp]
00007cf1741e162e  vmovaps xmm1, [rsp+0x10]
00007cf1741e1634  vmovaps xmm2, [rsp+0x20]
00007cf1741e163a  vmovaps xmm3, [rsp+0x30]
00007cf1741e1640  vmovaps xmm4, [rsp+0x40]
00007cf1741e1646  vmovaps xmm5, [rsp+0x50]
00007cf1741e164c  vmovaps xmm6, [rsp+0x60]
00007cf1741e1652  vmovaps xmm7, [rsp+0x70]
00007cf1741e1658  vmovaps xmm8, [rsp+0x80]
00007cf1741e1661  vmovaps xmm9, [rsp+0x90]
00007cf1741e166a  vmovaps xmm10, [rsp+0xA0]
00007cf1741e1673  vmovaps xmm11, [rsp+0xB0]
00007cf1741e167c  vmovaps xmm12, [rsp+0xC0]
00007cf1741e1685  vmovaps xmm13, [rsp+0xD0]
00007cf1741e168e  vmovaps xmm14, [rsp+0xE0]
00007cf1741e1697  add rsp, 0xF0
00007cf1741e169e  pop r11
00007cf1741e16a0  pop r10
00007cf1741e16a2  pop r9
00007cf1741e16a4  pop r8
00007cf1741e16a6  pop rsi
00007cf1741e16a7  pop rdi
00007cf1741e16a8  pop rdx
00007cf1741e16a9  pop rcx
00007cf1741e16aa  pop rax
00007cf1741e16ab  add rsp, 0x08
00007cf1741e16af  jmp 0x00007CF1741DC7FD
00007cf1741e16b4  sub rsp, 0x08
00007cf1741e16b8  push rax
00007cf1741e16b9  push rcx
00007cf1741e16ba  push rdx
00007cf1741e16bb  push rdi
00007cf1741e16bc  push rsi
00007cf1741e16bd  push r8
00007cf1741e16bf  push r9
00007cf1741e16c1  push r10
00007cf1741e16c3  push r11
00007cf1741e16c5  sub rsp, 0xF0
00007cf1741e16cc  vmovaps [rsp], xmm0
00007cf1741e16d1  vmovaps [rsp+0x10], xmm1
00007cf1741e16d7  vmovaps [rsp+0x20], xmm2
00007cf1741e16dd  vmovaps [rsp+0x30], xmm3
00007cf1741e16e3  vmovaps [rsp+0x40], xmm4
00007cf1741e16e9  vmovaps [rsp+0x50], xmm5
00007cf1741e16ef  vmovaps [rsp+0x60], xmm6
00007cf1741e16f5  vmovaps [rsp+0x70], xmm7
00007cf1741e16fb  vmovaps [rsp+0x80], xmm8
00007cf1741e1704  vmovaps [rsp+0x90], xmm9
00007cf1741e170d  vmovaps [rsp+0xA0], xmm10
00007cf1741e1716  vmovaps [rsp+0xB0], xmm11
00007cf1741e171f  vmovaps [rsp+0xC0], xmm12
00007cf1741e1728  vmovaps [rsp+0xD0], xmm14
00007cf1741e1731  vmovaps [rsp+0xE0], xmm15
00007cf1741e173a  sub rsp, 0x30
00007cf1741e173e  movaps [rsp], xmm13
00007cf1741e1743  movaps [rsp+0x10], xmm10
00007cf1741e1749  movaps [rsp+0x20], xmm14
00007cf1741e174f  lea rdi, [rsp]
00007cf1741e1753  mov esi, 0x00
00007cf1741e1758  mov rax, 0x611C8A33A530
00007cf1741e1762  call rax
00007cf1741e1764  movaps xmm13, [rsp]
00007cf1741e1769  add rsp, 0x30
00007cf1741e176d  vmovaps xmm0, [rsp]
00007cf1741e1772  vmovaps xmm1, [rsp+0x10]
00007cf1741e1778  vmovaps xmm2, [rsp+0x20]
00007cf1741e177e  vmovaps xmm3, [rsp+0x30]
00007cf1741e1784  vmovaps xmm4, [rsp+0x40]
00007cf1741e178a  vmovaps xmm5, [rsp+0x50]
00007cf1741e1790  vmovaps xmm6, [rsp+0x60]
00007cf1741e1796  vmovaps xmm7, [rsp+0x70]
00007cf1741e179c  vmovaps xmm8, [rsp+0x80]
00007cf1741e17a5  vmovaps xmm9, [rsp+0x90]
00007cf1741e17ae  vmovaps xmm10, [rsp+0xA0]
00007cf1741e17b7  vmovaps xmm11, [rsp+0xB0]
00007cf1741e17c0  vmovaps xmm12, [rsp+0xC0]
00007cf1741e17c9  vmovaps xmm14, [rsp+0xD0]
00007cf1741e17d2  vmovaps xmm15, [rsp+0xE0]
00007cf1741e17db  add rsp, 0xF0
00007cf1741e17e2  pop r11
00007cf1741e17e4  pop r10
00007cf1741e17e6  pop r9
00007cf1741e17e8  pop r8
00007cf1741e17ea  pop rsi
00007cf1741e17eb  pop rdi
00007cf1741e17ec  pop rdx
00007cf1741e17ed  pop rcx
00007cf1741e17ee  pop rax
00007cf1741e17ef  add rsp, 0x08
00007cf1741e17f3  jmp 0x00007CF1741DC820
00007cf1741e17f8  sub rsp, 0x08
00007cf1741e17fc  push rax
00007cf1741e17fd  push rcx
00007cf1741e17fe  push rdx
00007cf1741e17ff  push rdi
00007cf1741e1800  push rsi
00007cf1741e1801  push r8
00007cf1741e1803  push r9
00007cf1741e1805  push r10
00007cf1741e1807  push r11
00007cf1741e1809  sub rsp, 0xF0
00007cf1741e1810  vmovaps [rsp], xmm0
00007cf1741e1815  vmovaps [rsp+0x10], xmm1
00007cf1741e181b  vmovaps [rsp+0x20], xmm2
00007cf1741e1821  vmovaps [rsp+0x30], xmm3
00007cf1741e1827  vmovaps [rsp+0x40], xmm4
00007cf1741e182d  vmovaps [rsp+0x50], xmm5
00007cf1741e1833  vmovaps [rsp+0x60], xmm6
00007cf1741e1839  vmovaps [rsp+0x70], xmm7
00007cf1741e183f  vmovaps [rsp+0x80], xmm8
00007cf1741e1848  vmovaps [rsp+0x90], xmm9
00007cf1741e1851  vmovaps [rsp+0xA0], xmm10
00007cf1741e185a  vmovaps [rsp+0xB0], xmm11
00007cf1741e1863  vmovaps [rsp+0xC0], xmm12
00007cf1741e186c  vmovaps [rsp+0xD0], xmm13
00007cf1741e1875  vmovaps [rsp+0xE0], xmm15
00007cf1741e187e  sub rsp, 0x30
00007cf1741e1882  movaps [rsp], xmm14
00007cf1741e1887  movaps [rsp+0x10], xmm1
00007cf1741e188c  movaps [rsp+0x20], xmm7
00007cf1741e1891  lea rdi, [rsp]
00007cf1741e1895  mov esi, 0x00
00007cf1741e189a  mov rax, 0x611C8A33A530
00007cf1741e18a4  call rax
00007cf1741e18a6  movaps xmm14, [rsp]
00007cf1741e18ab  add rsp, 0x30
00007cf1741e18af  vmovaps xmm0, [rsp]
00007cf1741e18b4  vmovaps xmm1, [rsp+0x10]
00007cf1741e18ba  vmovaps xmm2, [rsp+0x20]
00007cf1741e18c0  vmovaps xmm3, [rsp+0x30]
00007cf1741e18c6  vmovaps xmm4, [rsp+0x40]
00007cf1741e18cc  vmovaps xmm5, [rsp+0x50]
00007cf1741e18d2  vmovaps xmm6, [rsp+0x60]
00007cf1741e18d8  vmovaps xmm7, [rsp+0x70]
00007cf1741e18de  vmovaps xmm8, [rsp+0x80]
00007cf1741e18e7  vmovaps xmm9, [rsp+0x90]
00007cf1741e18f0  vmovaps xmm10, [rsp+0xA0]
00007cf1741e18f9  vmovaps xmm11, [rsp+0xB0]
00007cf1741e1902  vmovaps xmm12, [rsp+0xC0]
00007cf1741e190b  vmovaps xmm13, [rsp+0xD0]
00007cf1741e1914  vmovaps xmm15, [rsp+0xE0]
00007cf1741e191d  add rsp, 0xF0
00007cf1741e1924  pop r11
00007cf1741e1926  pop r10
00007cf1741e1928  pop r9
00007cf1741e192a  pop r8
00007cf1741e192c  pop rsi
00007cf1741e192d  pop rdi
00007cf1741e192e  pop rdx
00007cf1741e192f  pop rcx
00007cf1741e1930  pop rax
00007cf1741e1931  add rsp, 0x08
00007cf1741e1935  jmp 0x00007CF1741DC843
00007cf1741e193a  sub rsp, 0x08
00007cf1741e193e  push rax
00007cf1741e193f  push rcx
00007cf1741e1940  push rdx
00007cf1741e1941  push rdi
00007cf1741e1942  push rsi
00007cf1741e1943  push r8
00007cf1741e1945  push r9
00007cf1741e1947  push r10
00007cf1741e1949  push r11
00007cf1741e194b  sub rsp, 0xF0
00007cf1741e1952  vmovaps [rsp], xmm0
00007cf1741e1957  vmovaps [rsp+0x10], xmm2
00007cf1741e195d  vmovaps [rsp+0x20], xmm3
00007cf1741e1963  vmovaps [rsp+0x30], xmm4
00007cf1741e1969  vmovaps [rsp+0x40], xmm5
00007cf1741e196f  vmovaps [rsp+0x50], xmm6
00007cf1741e1975  vmovaps [rsp+0x60], xmm7
00007cf1741e197b  vmovaps [rsp+0x70], xmm8
00007cf1741e1981  vmovaps [rsp+0x80], xmm9
00007cf1741e198a  vmovaps [rsp+0x90], xmm10
00007cf1741e1993  vmovaps [rsp+0xA0], xmm11
00007cf1741e199c  vmovaps [rsp+0xB0], xmm12
00007cf1741e19a5  vmovaps [rsp+0xC0], xmm13
00007cf1741e19ae  vmovaps [rsp+0xD0], xmm14
00007cf1741e19b7  vmovaps [rsp+0xE0], xmm15
00007cf1741e19c0  sub rsp, 0x30
00007cf1741e19c4  movaps [rsp], xmm1
00007cf1741e19c8  movaps [rsp+0x10], xmm8
00007cf1741e19ce  movaps [rsp+0x20], xmm9
00007cf1741e19d4  lea rdi, [rsp]
00007cf1741e19d8  mov esi, 0x00
00007cf1741e19dd  mov rax, 0x611C8A33A530
00007cf1741e19e7  call rax
00007cf1741e19e9  movaps xmm1, [rsp]
00007cf1741e19ed  add rsp, 0x30
00007cf1741e19f1  vmovaps xmm0, [rsp]
00007cf1741e19f6  vmovaps xmm2, [rsp+0x10]
00007cf1741e19fc  vmovaps xmm3, [rsp+0x20]
00007cf1741e1a02  vmovaps xmm4, [rsp+0x30]
00007cf1741e1a08  vmovaps xmm5, [rsp+0x40]
00007cf1741e1a0e  vmovaps xmm6, [rsp+0x50]
00007cf1741e1a14  vmovaps xmm7, [rsp+0x60]
00007cf1741e1a1a  vmovaps xmm8, [rsp+0x70]
00007cf1741e1a20  vmovaps xmm9, [rsp+0x80]
00007cf1741e1a29  vmovaps xmm10, [rsp+0x90]
00007cf1741e1a32  vmovaps xmm11, [rsp+0xA0]
00007cf1741e1a3b  vmovaps xmm12, [rsp+0xB0]
00007cf1741e1a44  vmovaps xmm13, [rsp+0xC0]
00007cf1741e1a4d  vmovaps xmm14, [rsp+0xD0]
00007cf1741e1a56  vmovaps xmm15, [rsp+0xE0]
00007cf1741e1a5f  add rsp, 0xF0
00007cf1741e1a66  pop r11
00007cf1741e1a68  pop r10
00007cf1741e1a6a  pop r9
00007cf1741e1a6c  pop r8
00007cf1741e1a6e  pop rsi
00007cf1741e1a6f  pop rdi
00007cf1741e1a70  pop rdx
00007cf1741e1a71  pop rcx
00007cf1741e1a72  pop rax
00007cf1741e1a73  add rsp, 0x08
00007cf1741e1a77  jmp 0x00007CF1741DC865
00007cf1741e1a7c  call 0x00007CF1740E5940
00007cf1741e1a81  jmp 0x00007CF1741DC873
00007cf1741e1a86  call 0x00007CF17400C380
00007cf1741e1a8b  jmp 0x00007CF1741DC87D
00007cf1741e1a90  call 0x00007CF17400D600
00007cf1741e1a95  jmp 0x00007CF1741DC887
00007cf1741e1a9a  call 0x00007CF173FFF540
00007cf1741e1a9f  jmp 0x00007CF1741DC891
00007cf1741e1aa4  int3
00007cf1741e1aa5  nop [rax+rax*1], ax
00007cf1741e1aae  nop
00007cf1741e1ab0  mov rax, [r15+0xF8]
00007cf1741e1ab7  lea r14, [rax+0x140]
00007cf1741e1abe  mov r12, [r13+r14*1]
00007cf1741e1ac3  mov [r15+0xE8], r12
00007cf1741e1aca  lea r14, [rax+0x130]
00007cf1741e1ad1  mov r12, [r13+r14*1]
00007cf1741e1ad6  lea r14, [rax+0x138]
00007cf1741e1add  mov r11, [r13+r14*1]
00007cf1741e1ae2  movq xmm1, r12
00007cf1741e1ae7  movq xmm15, r11
00007cf1741e1aec  movq xmm1, xmm1
00007cf1741e1af0  movq xmm1, xmm1
00007cf1741e1af4  movaps [r15+0x1A0], xmm1
00007cf1741e1afc  movq xmm15, xmm15
00007cf1741e1b01  movq xmm15, xmm15
00007cf1741e1b06  movaps [r15+0x190], xmm15
00007cf1741e1b0e  lea r14, [rax+0x120]
00007cf1741e1b15  mov r12, [r13+r14*1]
00007cf1741e1b1a  lea r14, [rax+0x128]
00007cf1741e1b21  mov r11, [r13+r14*1]
00007cf1741e1b26  movq xmm1, r12
00007cf1741e1b2b  movq xmm15, r11
00007cf1741e1b30  movq xmm1, xmm1
00007cf1741e1b34  movq xmm1, xmm1
00007cf1741e1b38  movaps [r15+0x1C0], xmm1
00007cf1741e1b40  movq xmm15, xmm15
00007cf1741e1b45  movq xmm15, xmm15
00007cf1741e1b4a  movaps [r15+0x1B0], xmm15
00007cf1741e1b52  lea r14, [rax+0x110]
00007cf1741e1b59  mov r12, [r13+r14*1]
00007cf1741e1b5e  lea r14, [rax+0x118]
00007cf1741e1b65  mov r11, [r13+r14*1]
00007cf1741e1b6a  movq xmm1, r12
00007cf1741e1b6f  movq xmm15, r11
00007cf1741e1b74  movq xmm1, xmm1
00007cf1741e1b78  movq xmm1, xmm1
00007cf1741e1b7c  movaps [r15+0x1E0], xmm1
00007cf1741e1b84  movq xmm15, xmm15
00007cf1741e1b89  movq xmm15, xmm15
00007cf1741e1b8e  movaps [r15+0x1D0], xmm15
00007cf1741e1b96  lea r14, [rax+0x100]
00007cf1741e1b9d  mov r12, [r13+r14*1]
00007cf1741e1ba2  lea r14, [rax+0x108]
00007cf1741e1ba9  mov r11, [r13+r14*1]
00007cf1741e1bae  movq xmm1, r12
00007cf1741e1bb3  movq xmm15, r11
00007cf1741e1bb8  movq xmm1, xmm1
00007cf1741e1bbc  movq xmm1, xmm1
00007cf1741e1bc0  movaps [r15+0x200], xmm1
00007cf1741e1bc8  movq xmm15, xmm15
00007cf1741e1bcd  movq xmm15, xmm15
00007cf1741e1bd2  movaps [r15+0x1F0], xmm15
00007cf1741e1bda  mov qword ptr [r15+0x40], 0x430000
00007cf1741e1be2  mov r14d, 0x430510
00007cf1741e1be8  mov r12, [r13+r14*1]
00007cf1741e1bed  movq xmm1, r12
00007cf1741e1bf2  lea r14, [rax+0x150]
00007cf1741e1bf9  mov [r15+0xF8], r14
00007cf1741e1c00  mov rax, [r15+0x50]
00007cf1741e1c04  movups xmm15, [r13+rax*1]
00007cf1741e1c0a  movaps [r15+0x120], xmm15
00007cf1741e1c12  mov qword ptr [r15+0x48], 0x10
00007cf1741e1c1a  xor eax, eax
00007cf1741e1c1c  mov r14d, 0x10
00007cf1741e1c22  mov r12d, 0x200
00007cf1741e1c28  cmp r14, r12
00007cf1741e1c2b  cmc
00007cf1741e1c2c  lahf
00007cf1741e1c2d  seto al
00007cf1741e1c30  mov [r15+0x108], eax
00007cf1741e1c37  pextrq rax, xmm15, 0x01
00007cf1741e1c3e  movq xmm14, rax
00007cf1741e1c43  movaps [r15+0x130], xmm14
00007cf1741e1c4b  movq rax, xmm1
00007cf1741e1c50  movq r14, xmm15
00007cf1741e1c55  vmovq xmm1, rax
00007cf1741e1c5a  vmovq xmm15, r14
00007cf1741e1c5f  movaps xmm13, xmm1
00007cf1741e1c63  addsd xmm13, xmm15
00007cf1741e1c68  ucomisd xmm13, xmm13
00007cf1741e1c6d  jp 0x00007CF1741E1D86
00007cf1741e1c73  movq xmm13, xmm13
00007cf1741e1c78  movq rax, xmm13
00007cf1741e1c7d  movq r14, xmm14
00007cf1741e1c82  vmovq xmm1, rax
00007cf1741e1c87  vmovq xmm15, r14
00007cf1741e1c8c  movaps xmm14, xmm1
00007cf1741e1c90  addsd xmm14, xmm15
00007cf1741e1c95  ucomisd xmm14, xmm14
00007cf1741e1c9a  jp 0x00007CF1741E1DCE
00007cf1741e1ca0  movq xmm14, xmm14
00007cf1741e1ca5  movaps [r15+0x110], xmm14
00007cf1741e1cad  mov eax, [r15+0x108]
00007cf1741e1cb4  sahf
00007cf1741e1cb5  jnz 0x00007CF1741E1CE7
00007cf1741e1cb7  cmp dword ptr [r15+0x318], 0x00
00007cf1741e1cbf  jz 0x00007CF1741E1FE0
00007cf1741e1cc5  nop [rax+rax*1], ax
00007cf1741e1cce  nop [rax+rax*1], eax
00007cf1741e1cd6  mov eax, 0x410490
00007cf1741e1cdb  mov [r15+0x100], rax
00007cf1741e1ce2  jmp 0x00007CF173FFE110
00007cf1741e1ce7  cmp dword ptr [r15+0x318], 0x00
00007cf1741e1cef  jz 0x00007CF1741E1E20
00007cf1741e1cf5  nop [rax+rax*1], ax
00007cf1741e1cfe  nop [rax+rax*1], eax
00007cf1741e1d06  mov eax, 0x410474
00007cf1741e1d0b  mov [r15+0x100], rax
00007cf1741e1d12  jmp 0x00007CF173FFE110
00007cf1741e1d17  int3
00007cf1741e1d18  call 0x00007CF1740E27E0
00007cf1741e1d1d  jmp 0x00007CF1741E1AC3
00007cf1741e1d22  call 0x00007CF1740E27E0
00007cf1741e1d27  jmp 0x00007CF1741E1AD6
00007cf1741e1d2c  call 0x00007CF1740E1570
00007cf1741e1d31  jmp 0x00007CF1741E1AE2
00007cf1741e1d36  call 0x00007CF1740E27E0
00007cf1741e1d3b  jmp 0x00007CF1741E1B1A
00007cf1741e1d40  call 0x00007CF1740E1570
00007cf1741e1d45  jmp 0x00007CF1741E1B26
00007cf1741e1d4a  call 0x00007CF1740E27E0
00007cf1741e1d4f  jmp 0x00007CF1741E1B5E
00007cf1741e1d54  call 0x00007CF1740E1570
00007cf1741e1d59  jmp 0x00007CF1741E1B6A
00007cf1741e1d5e  call 0x00007CF1740E27E0
00007cf1741e1d63  jmp 0x00007CF1741E1BA2
00007cf1741e1d68  call 0x00007CF1740E1570
00007cf1741e1d6d  jmp 0x00007CF1741E1BAE
00007cf1741e1d72  call 0x00007CF1740E27E0
00007cf1741e1d77  jmp 0x00007CF1741E1BED
00007cf1741e1d7c  call 0x00007CF17400E760
00007cf1741e1d81  jmp 0x00007CF1741E1C0A
00007cf1741e1d86  ucomisd xmm1, xmm15
00007cf1741e1d8b  jp 0x00007CF1741E1D9A
00007cf1741e1d8d  movaps xmm13, [0x00007CF173DFE060]
00007cf1741e1d95  jmp 0x00007CF1741E1C73
00007cf1741e1d9a  vxorps xmm0, xmm1, xmm15
00007cf1741e1d9f  pextrw eax, xmm0, 0x03
00007cf1741e1da4  and eax, 0x7FF8
00007cf1741e1da9  cmp eax, 0x08
00007cf1741e1dac  jnz 0x00007CF1741E1C73
00007cf1741e1db2  movq rax, xmm15
00007cf1741e1db7  shl rax, 0x0D
00007cf1741e1dbb  jbe 0x00007CF1741E1C73
00007cf1741e1dc1  vorps xmm13, xmm15, [0x00007CF173DFE070]
00007cf1741e1dc9  jmp 0x00007CF1741E1C73
00007cf1741e1dce  ucomisd xmm1, xmm15
00007cf1741e1dd3  jp 0x00007CF1741E1DE2
00007cf1741e1dd5  movaps xmm14, [0x00007CF173DFE060]
00007cf1741e1ddd  jmp 0x00007CF1741E1CA0
00007cf1741e1de2  vxorps xmm0, xmm1, xmm15
00007cf1741e1de7  pextrw eax, xmm0, 0x03
00007cf1741e1dec  and eax, 0x7FF8
00007cf1741e1df1  cmp eax, 0x08
00007cf1741e1df4  jnz 0x00007CF1741E1CA0
00007cf1741e1dfa  movq rax, xmm15
00007cf1741e1dff  shl rax, 0x0D
00007cf1741e1e03  jbe 0x00007CF1741E1CA0
00007cf1741e1e09  vorps xmm14, xmm15, [0x00007CF173DFE070]
00007cf1741e1e11  jmp 0x00007CF1741E1CA0
00007cf1741e1e16  int3
00007cf1741e1e17  nop [rax+rax*1], ax
00007cf1741e1e20  mov rax, [r15+0x48]
00007cf1741e1e24  mov r14, [r15+0x50]
00007cf1741e1e28  lea r12, [r14+rax*1]
00007cf1741e1e2c  movups xmm1, [r13+r12*1]
00007cf1741e1e32  movaps [r15+0x120], xmm1
00007cf1741e1e3a  lea r14, [rax+0x10]
00007cf1741e1e3e  mov [r15+0x48], r14
00007cf1741e1e42  xor eax, eax
00007cf1741e1e44  mov r12d, 0x200
00007cf1741e1e4a  cmp r14, r12
00007cf1741e1e4d  cmc
00007cf1741e1e4e  lahf
00007cf1741e1e4f  seto al
00007cf1741e1e52  mov [r15+0x108], eax
00007cf1741e1e59  pextrq rax, xmm1, 0x01
00007cf1741e1e60  movq xmm15, rax
00007cf1741e1e65  movaps [r15+0x130], xmm15
00007cf1741e1e6d  movaps xmm14, [r15+0x110]
00007cf1741e1e75  movq rax, xmm14
00007cf1741e1e7a  movq r14, xmm1
00007cf1741e1e7f  vmovq xmm1, rax
00007cf1741e1e84  vmovq xmm14, r14
00007cf1741e1e89  movaps xmm13, xmm1
00007cf1741e1e8d  addsd xmm13, xmm14
00007cf1741e1e92  ucomisd xmm13, xmm13
00007cf1741e1e97  jp 0x00007CF1741E1F4C
00007cf1741e1e9d  movq xmm13, xmm13
00007cf1741e1ea2  movq rax, xmm13
00007cf1741e1ea7  movq r14, xmm15
00007cf1741e1eac  vmovq xmm1, rax
00007cf1741e1eb1  vmovq xmm15, r14
00007cf1741e1eb6  movaps xmm14, xmm1
00007cf1741e1eba  addsd xmm14, xmm15
00007cf1741e1ebf  ucomisd xmm14, xmm14
00007cf1741e1ec4  jp 0x00007CF1741E1F94
00007cf1741e1eca  movq xmm14, xmm14
00007cf1741e1ecf  movaps [r15+0x110], xmm14
00007cf1741e1ed7  mov eax, [r15+0x108]
00007cf1741e1ede  sahf
00007cf1741e1edf  jnz 0x00007CF1741E1F11
00007cf1741e1ee1  cmp dword ptr [r15+0x318], 0x00
00007cf1741e1ee9  jz 0x00007CF1741E1FE0
00007cf1741e1eef  nop [rax+rax*1], ax
00007cf1741e1ef8  nop [rax+rax*1], eax
00007cf1741e1f00  mov eax, 0x410490
00007cf1741e1f05  mov [r15+0x100], rax
00007cf1741e1f0c  jmp 0x00007CF173FFE110
00007cf1741e1f11  cmp dword ptr [r15+0x318], 0x00
00007cf1741e1f19  jz 0x00007CF1741E1E20
00007cf1741e1f1f  nop [rax+rax*1], ax
00007cf1741e1f28  nop [rax+rax*1], eax
00007cf1741e1f30  mov eax, 0x410474
00007cf1741e1f35  mov [r15+0x100], rax
00007cf1741e1f3c  jmp 0x00007CF173FFE110
00007cf1741e1f41  int3
00007cf1741e1f42  call 0x00007CF1740B52F0
00007cf1741e1f47  jmp 0x00007CF1741E1E32
00007cf1741e1f4c  ucomisd xmm1, xmm14
00007cf1741e1f51  jp 0x00007CF1741E1F60
00007cf1741e1f53  movaps xmm13, [0x00007CF173DFE060]
00007cf1741e1f5b  jmp 0x00007CF1741E1E9D
00007cf1741e1f60  vxorps xmm0, xmm1, xmm14
00007cf1741e1f65  pextrw eax, xmm0, 0x03
00007cf1741e1f6a  and eax, 0x7FF8
00007cf1741e1f6f  cmp eax, 0x08
00007cf1741e1f72  jnz 0x00007CF1741E1E9D
00007cf1741e1f78  movq rax, xmm14
00007cf1741e1f7d  shl rax, 0x0D
00007cf1741e1f81  jbe 0x00007CF1741E1E9D
00007cf1741e1f87  vorps xmm13, xmm14, [0x00007CF173DFE070]
00007cf1741e1f8f  jmp 0x00007CF1741E1E9D
00007cf1741e1f94  ucomisd xmm1, xmm15
00007cf1741e1f99  jp 0x00007CF1741E1FA8
00007cf1741e1f9b  movaps xmm14, [0x00007CF173DFE060]
00007cf1741e1fa3  jmp 0x00007CF1741E1ECA
00007cf1741e1fa8  vxorps xmm0, xmm1, xmm15
00007cf1741e1fad  pextrw eax, xmm0, 0x03
00007cf1741e1fb2  and eax, 0x7FF8
00007cf1741e1fb7  cmp eax, 0x08
00007cf1741e1fba  jnz 0x00007CF1741E1ECA
00007cf1741e1fc0  movq rax, xmm15
00007cf1741e1fc5  shl rax, 0x0D
00007cf1741e1fc9  jbe 0x00007CF1741E1ECA
00007cf1741e1fcf  vorps xmm14, xmm15, [0x00007CF173DFE070]
00007cf1741e1fd7  jmp 0x00007CF1741E1ECA
00007cf1741e1fdc  int3
00007cf1741e1fdd  nop [rax], eax
00007cf1741e1fe0  mov rax, [r15+0x40]
00007cf1741e1fe4  lea r14, [rax+0x510]
00007cf1741e1feb  movaps xmm1, [r15+0x110]
00007cf1741e1ff3  movq rax, xmm1
00007cf1741e1ff8  mov [r13+r14*1], rax
00007cf1741e1ffd  mov rax, [r15+0xF0]
00007cf1741e2004  mov [r15+0x100], rax
00007cf1741e200b  jmp 0x00007CF1741CE5C0
00007cf1741e2010  int3
00007cf1741e2011  call 0x00007CF1740D5EB0
00007cf1741e2016  jmp 0x00007CF1741E1FFD
00007cf1741e201b  int3
00007cf1741e201c  nop [rax], eax
00007cf1741e2020  mov qword ptr [r15+0x100], 0x04
00007cf1741e202b  mov esi, 0x00
00007cf1741e2030  mov edx, 0x09
00007cf1741e2035  mov rdi, 0x7FFCCCB1C430
00007cf1741e203f  mov rax, 0x611C8A1CD970
00007cf1741e2049  call rax
00007cf1741e204b  cmp dword ptr [r15+0x318], 0x00
00007cf1741e2053  jnz 0x00007CF173FFE110
00007cf1741e2059  jmp 0x00007CF173FFE0A0
00007cf1741e205e  int3
00007cf1741e205f  int3
