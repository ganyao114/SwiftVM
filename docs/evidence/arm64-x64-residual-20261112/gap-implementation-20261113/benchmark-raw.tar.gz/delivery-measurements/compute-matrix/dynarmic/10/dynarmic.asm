0000708296fce69b  nop [rax+rax*1], eax
0000708296fce6a0  vmovaps xmm1, [0x0000708296BFE010]
0000708296fce6a8  movq xmm1, xmm1
0000708296fce6ac  movaps [r15+0x110], xmm1
0000708296fce6b4  vmovaps xmm1, [0x0000708296BFE020]
0000708296fce6bc  movq xmm1, xmm1
0000708296fce6c0  movaps [r15+0x120], xmm1
0000708296fce6c8  mov eax, 0x4204C0
0000708296fce6cd  mov r14, [r13+rax*1]
0000708296fce6d2  movq xmm1, r14
0000708296fce6d7  movaps [r15+0x130], xmm1
0000708296fce6df  vmovaps xmm1, [0x0000708296BFE030]
0000708296fce6e7  vpbroadcastq xmm1, xmm1
0000708296fce6ec  movaps [r15+0x140], xmm1
0000708296fce6f4  mov qword ptr [r15+0x40], 0x02
0000708296fce6fc  vmovaps xmm15, [0x0000708296BFE040]
0000708296fce704  movq xmm15, xmm15
0000708296fce709  movaps [r15+0x150], xmm15
0000708296fce711  mov qword ptr [r15+0x58], 0x420000
0000708296fce719  vmovaps xmm15, [0x0000708296BFE050]
0000708296fce721  vpbroadcastq xmm15, xmm15
0000708296fce726  movaps [r15+0x160], xmm15
0000708296fce72e  mov rax, [r15+0x40]
0000708296fce732  vmovq xmm14, rax
0000708296fce737  vpbroadcastq xmm14, xmm14
0000708296fce73c  movaps [r15+0x170], xmm14
0000708296fce744  mov eax, 0x4204D0
0000708296fce749  movups xmm13, [r13+rax*1]
0000708296fce74f  mov qword ptr [r15+0x40], 0x430518
0000708296fce757  mov qword ptr [r15+0x50], 0x430720
0000708296fce75f  vpmovqd xmm12, xmm13
0000708296fce765  pxor xmm11, xmm11
0000708296fce76a  punpcklqdq xmm12, xmm11
0000708296fce76f  movaps [r15+0x210], xmm12
0000708296fce777  movq xmm12, qword ptr [r15+0x120]
0000708296fce780  movq xmm11, qword ptr [r15+0x130]
0000708296fce789  psubd xmm12, xmm11
0000708296fce78e  movq xmm12, xmm12
0000708296fce793  paddq xmm13, xmm14
0000708296fce798  movaps [r15+0x180], xmm13
0000708296fce7a0  movq xmm14, qword ptr [r15+0x150]
0000708296fce7a9  paddd xmm11, xmm14
0000708296fce7ae  movq xmm11, xmm11
0000708296fce7b3  movq xmm11, xmm11
0000708296fce7b8  movaps [r15+0x130], xmm11
0000708296fce7c0  pmovzxdq xmm12, xmm12
0000708296fce7c6  psllq xmm12, 0x00
0000708296fce7cc  movq xmm14, qword ptr [r15+0x210]
0000708296fce7d5  movq xmm13, qword ptr [r15+0x110]
0000708296fce7de  paddd xmm14, xmm13
0000708296fce7e3  movq xmm14, xmm14
0000708296fce7e8  vcvtuqq2pd xmm12, xmm12
0000708296fce7ee  pmovzxdq xmm14, xmm14
0000708296fce7f4  psllq xmm14, 0x00
0000708296fce7fa  vcvtuqq2pd xmm14, xmm14
0000708296fce800  movaps xmm13, xmm12
0000708296fce804  mulpd xmm13, xmm1
0000708296fce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000708296fce80f  ptest xmm11, xmm11
0000708296fce815  jnz 0x0000708296FCE8FF
0000708296fce81b  movaps [r15+0x220], xmm13
0000708296fce823  mov eax, 0x430720
0000708296fce828  movups [r13+rax*1], xmm13
0000708296fce82e  movaps xmm1, xmm14
0000708296fce832  mulpd xmm1, xmm15
0000708296fce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000708296fce83c  ptest xmm13, xmm13
0000708296fce842  jnz 0x0000708296FCEA4C
0000708296fce848  movaps [r15+0x210], xmm1
0000708296fce850  mov eax, 0x430518
0000708296fce855  movups [r13+rax*1], xmm1
0000708296fce85b  mov qword ptr [r15+0x48], 0x10
0000708296fce863  xor eax, eax
0000708296fce865  mov r14d, 0x10
0000708296fce86b  mov r12d, 0x200
0000708296fce871  cmp r14, r12
0000708296fce874  cmc
0000708296fce875  lahf
0000708296fce876  seto al
0000708296fce879  mov [r15+0x108], eax
0000708296fce880  mov eax, [r15+0x108]
0000708296fce887  sahf
0000708296fce888  jnz 0x0000708296FCE8BA
0000708296fce88a  cmp dword ptr [r15+0x318], 0x00
0000708296fce892  jz 0x0000708296FCEFF0
0000708296fce898  nop [rax+rax*1], ax
0000708296fce8a1  nop [rax+rax*1], eax
0000708296fce8a9  mov eax, 0x4101EC
0000708296fce8ae  mov [r15+0x100], rax
0000708296fce8b5  jmp 0x0000708296DFE110
0000708296fce8ba  cmp dword ptr [r15+0x318], 0x00
0000708296fce8c2  jz 0x0000708296FCEBA0
0000708296fce8c8  nop [rax+rax*1], ax
0000708296fce8d1  nop [rax+rax*1], eax
0000708296fce8d9  mov eax, 0x4101AC
0000708296fce8de  mov [r15+0x100], rax
0000708296fce8e5  jmp 0x0000708296DFE110
0000708296fce8ea  int3
0000708296fce8eb  call 0x0000708296E0DC20
0000708296fce8f0  jmp 0x0000708296FCE6D2
0000708296fce8f5  call 0x0000708296E0C260
0000708296fce8fa  jmp 0x0000708296FCE74F
0000708296fce8ff  sub rsp, 0x08
0000708296fce903  push rax
0000708296fce904  push rcx
0000708296fce905  push rdx
0000708296fce906  push rdi
0000708296fce907  push rsi
0000708296fce908  push r8
0000708296fce90a  push r9
0000708296fce90c  push r10
0000708296fce90e  push r11
0000708296fce910  sub rsp, 0xF0
0000708296fce917  vmovaps [rsp], xmm0
0000708296fce91c  vmovaps [rsp+0x10], xmm1
0000708296fce922  vmovaps [rsp+0x20], xmm2
0000708296fce928  vmovaps [rsp+0x30], xmm3
0000708296fce92e  vmovaps [rsp+0x40], xmm4
0000708296fce934  vmovaps [rsp+0x50], xmm5
0000708296fce93a  vmovaps [rsp+0x60], xmm6
0000708296fce940  vmovaps [rsp+0x70], xmm7
0000708296fce946  vmovaps [rsp+0x80], xmm8
0000708296fce94f  vmovaps [rsp+0x90], xmm9
0000708296fce958  vmovaps [rsp+0xA0], xmm10
0000708296fce961  vmovaps [rsp+0xB0], xmm11
0000708296fce96a  vmovaps [rsp+0xC0], xmm12
0000708296fce973  vmovaps [rsp+0xD0], xmm14
0000708296fce97c  vmovaps [rsp+0xE0], xmm15
0000708296fce985  sub rsp, 0x30
0000708296fce989  movaps [rsp], xmm13
0000708296fce98e  movaps [rsp+0x10], xmm12
0000708296fce994  movaps [rsp+0x20], xmm1
0000708296fce999  lea rdi, [rsp]
0000708296fce99d  mov esi, 0x00
0000708296fce9a2  mov rax, 0x64BBC686C530
0000708296fce9ac  call rax
0000708296fce9ae  movaps xmm13, [rsp]
0000708296fce9b3  add rsp, 0x30
0000708296fce9b7  vmovaps xmm0, [rsp]
0000708296fce9bc  vmovaps xmm1, [rsp+0x10]
0000708296fce9c2  vmovaps xmm2, [rsp+0x20]
0000708296fce9c8  vmovaps xmm3, [rsp+0x30]
0000708296fce9ce  vmovaps xmm4, [rsp+0x40]
0000708296fce9d4  vmovaps xmm5, [rsp+0x50]
0000708296fce9da  vmovaps xmm6, [rsp+0x60]
0000708296fce9e0  vmovaps xmm7, [rsp+0x70]
0000708296fce9e6  vmovaps xmm8, [rsp+0x80]
0000708296fce9ef  vmovaps xmm9, [rsp+0x90]
0000708296fce9f8  vmovaps xmm10, [rsp+0xA0]
0000708296fcea01  vmovaps xmm11, [rsp+0xB0]
0000708296fcea0a  vmovaps xmm12, [rsp+0xC0]
0000708296fcea13  vmovaps xmm14, [rsp+0xD0]
0000708296fcea1c  vmovaps xmm15, [rsp+0xE0]
0000708296fcea25  add rsp, 0xF0
0000708296fcea2c  pop r11
0000708296fcea2e  pop r10
0000708296fcea30  pop r9
0000708296fcea32  pop r8
0000708296fcea34  pop rsi
0000708296fcea35  pop rdi
0000708296fcea36  pop rdx
0000708296fcea37  pop rcx
0000708296fcea38  pop rax
0000708296fcea39  add rsp, 0x08
0000708296fcea3d  jmp 0x0000708296FCE81B
0000708296fcea42  call 0x0000708296E0C380
0000708296fcea47  jmp 0x0000708296FCE82E
0000708296fcea4c  sub rsp, 0x08
0000708296fcea50  push rax
0000708296fcea51  push rcx
0000708296fcea52  push rdx
0000708296fcea53  push rdi
0000708296fcea54  push rsi
0000708296fcea55  push r8
0000708296fcea57  push r9
0000708296fcea59  push r10
0000708296fcea5b  push r11
0000708296fcea5d  sub rsp, 0xF0
0000708296fcea64  vmovaps [rsp], xmm0
0000708296fcea69  vmovaps [rsp+0x10], xmm2
0000708296fcea6f  vmovaps [rsp+0x20], xmm3
0000708296fcea75  vmovaps [rsp+0x30], xmm4
0000708296fcea7b  vmovaps [rsp+0x40], xmm5
0000708296fcea81  vmovaps [rsp+0x50], xmm6
0000708296fcea87  vmovaps [rsp+0x60], xmm7
0000708296fcea8d  vmovaps [rsp+0x70], xmm8
0000708296fcea93  vmovaps [rsp+0x80], xmm9
0000708296fcea9c  vmovaps [rsp+0x90], xmm10
0000708296fceaa5  vmovaps [rsp+0xA0], xmm11
0000708296fceaae  vmovaps [rsp+0xB0], xmm12
0000708296fceab7  vmovaps [rsp+0xC0], xmm13
0000708296fceac0  vmovaps [rsp+0xD0], xmm14
0000708296fceac9  vmovaps [rsp+0xE0], xmm15
0000708296fcead2  sub rsp, 0x30
0000708296fcead6  movaps [rsp], xmm1
0000708296fceada  movaps [rsp+0x10], xmm14
0000708296fceae0  movaps [rsp+0x20], xmm15
0000708296fceae6  lea rdi, [rsp]
0000708296fceaea  mov esi, 0x00
0000708296fceaef  mov rax, 0x64BBC686C530
0000708296fceaf9  call rax
0000708296fceafb  movaps xmm1, [rsp]
0000708296fceaff  add rsp, 0x30
0000708296fceb03  vmovaps xmm0, [rsp]
0000708296fceb08  vmovaps xmm2, [rsp+0x10]
0000708296fceb0e  vmovaps xmm3, [rsp+0x20]
0000708296fceb14  vmovaps xmm4, [rsp+0x30]
0000708296fceb1a  vmovaps xmm5, [rsp+0x40]
0000708296fceb20  vmovaps xmm6, [rsp+0x50]
0000708296fceb26  vmovaps xmm7, [rsp+0x60]
0000708296fceb2c  vmovaps xmm8, [rsp+0x70]
0000708296fceb32  vmovaps xmm9, [rsp+0x80]
0000708296fceb3b  vmovaps xmm10, [rsp+0x90]
0000708296fceb44  vmovaps xmm11, [rsp+0xA0]
0000708296fceb4d  vmovaps xmm12, [rsp+0xB0]
0000708296fceb56  vmovaps xmm13, [rsp+0xC0]
0000708296fceb5f  vmovaps xmm14, [rsp+0xD0]
0000708296fceb68  vmovaps xmm15, [rsp+0xE0]
0000708296fceb71  add rsp, 0xF0
0000708296fceb78  pop r11
0000708296fceb7a  pop r10
0000708296fceb7c  pop r9
0000708296fceb7e  pop r8
0000708296fceb80  pop rsi
0000708296fceb81  pop rdi
0000708296fceb82  pop rdx
0000708296fceb83  pop rcx
0000708296fceb84  pop rax
0000708296fceb85  add rsp, 0x08
0000708296fceb89  jmp 0x0000708296FCE848
0000708296fceb8e  call 0x0000708296DFF540
0000708296fceb93  jmp 0x0000708296FCE85B
0000708296fceb98  int3
0000708296fceb99  nop [rax], eax
0000708296fceba0  movaps xmm1, [r15+0x180]
0000708296fceba8  vpmovqd xmm15, xmm1
0000708296fcebae  pxor xmm14, xmm14
0000708296fcebb3  punpcklqdq xmm15, xmm14
0000708296fcebb8  movaps [r15+0x210], xmm15
0000708296fcebc0  movq xmm15, qword ptr [r15+0x120]
0000708296fcebc9  movq xmm14, qword ptr [r15+0x130]
0000708296fcebd2  psubd xmm15, xmm14
0000708296fcebd7  movq xmm15, xmm15
0000708296fcebdc  movaps xmm13, [r15+0x170]
0000708296fcebe4  paddq xmm1, xmm13
0000708296fcebe9  movaps [r15+0x180], xmm1
0000708296fcebf1  movq xmm1, qword ptr [r15+0x150]
0000708296fcebfa  paddd xmm14, xmm1
0000708296fcebff  movq xmm14, xmm14
0000708296fcec04  movq xmm14, xmm14
0000708296fcec09  movaps [r15+0x130], xmm14
0000708296fcec11  pmovzxdq xmm15, xmm15
0000708296fcec17  psllq xmm15, 0x00
0000708296fcec1d  movq xmm1, qword ptr [r15+0x210]
0000708296fcec26  movq xmm14, qword ptr [r15+0x110]
0000708296fcec2f  paddd xmm1, xmm14
0000708296fcec34  movq xmm1, xmm1
0000708296fcec38  vcvtuqq2pd xmm15, xmm15
0000708296fcec3e  pmovzxdq xmm1, xmm1
0000708296fcec43  psllq xmm1, 0x00
0000708296fcec48  vcvtuqq2pd xmm1, xmm1
0000708296fcec4e  movaps xmm14, [r15+0x140]
0000708296fcec56  movaps xmm13, xmm15
0000708296fcec5a  mulpd xmm13, xmm14
0000708296fcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000708296fcec65  ptest xmm12, xmm12
0000708296fcec6b  jnz 0x0000708296FCED4E
0000708296fcec71  movaps [r15+0x220], xmm13
0000708296fcec79  mov rax, [r15+0x48]
0000708296fcec7d  mov r14, [r15+0x50]
0000708296fcec81  lea r12, [r14+rax*1]
0000708296fcec85  movups [r13+r12*1], xmm13
0000708296fcec8b  movaps xmm15, [r15+0x160]
0000708296fcec93  movaps xmm14, xmm1
0000708296fcec97  mulpd xmm14, xmm15
0000708296fcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000708296fceca2  ptest xmm13, xmm13
0000708296fceca8  jnz 0x0000708296FCEE9C
0000708296fcecae  movaps [r15+0x210], xmm14
0000708296fcecb6  mov r14, [r15+0x40]
0000708296fcecba  lea r12, [r14+rax*1]
0000708296fcecbe  movups [r13+r12*1], xmm14
0000708296fcecc4  lea r14, [rax+0x10]
0000708296fcecc8  mov [r15+0x48], r14
0000708296fceccc  xor eax, eax
0000708296fcecce  mov r12d, 0x200
0000708296fcecd4  cmp r14, r12
0000708296fcecd7  cmc
0000708296fcecd8  lahf
0000708296fcecd9  seto al
0000708296fcecdc  mov [r15+0x108], eax
0000708296fcece3  mov eax, [r15+0x108]
0000708296fcecea  sahf
0000708296fceceb  jnz 0x0000708296FCED1D
0000708296fceced  cmp dword ptr [r15+0x318], 0x00
0000708296fcecf5  jz 0x0000708296FCEFF0
0000708296fcecfb  nop [rax+rax*1], ax
0000708296fced04  nop [rax+rax*1], eax
0000708296fced0c  mov eax, 0x4101EC
0000708296fced11  mov [r15+0x100], rax
0000708296fced18  jmp 0x0000708296DFE110
0000708296fced1d  cmp dword ptr [r15+0x318], 0x00
0000708296fced25  jz 0x0000708296FCEBA0
0000708296fced2b  nop [rax+rax*1], ax
0000708296fced34  nop [rax+rax*1], eax
0000708296fced3c  mov eax, 0x4101AC
0000708296fced41  mov [r15+0x100], rax
0000708296fced48  jmp 0x0000708296DFE110
0000708296fced4d  int3
0000708296fced4e  sub rsp, 0x08
0000708296fced52  push rax
0000708296fced53  push rcx
0000708296fced54  push rdx
0000708296fced55  push rdi
0000708296fced56  push rsi
0000708296fced57  push r8
0000708296fced59  push r9
0000708296fced5b  push r10
0000708296fced5d  push r11
0000708296fced5f  sub rsp, 0xF0
0000708296fced66  vmovaps [rsp], xmm0
0000708296fced6b  vmovaps [rsp+0x10], xmm1
0000708296fced71  vmovaps [rsp+0x20], xmm2
0000708296fced77  vmovaps [rsp+0x30], xmm3
0000708296fced7d  vmovaps [rsp+0x40], xmm4
0000708296fced83  vmovaps [rsp+0x50], xmm5
0000708296fced89  vmovaps [rsp+0x60], xmm6
0000708296fced8f  vmovaps [rsp+0x70], xmm7
0000708296fced95  vmovaps [rsp+0x80], xmm8
0000708296fced9e  vmovaps [rsp+0x90], xmm9
0000708296fceda7  vmovaps [rsp+0xA0], xmm10
0000708296fcedb0  vmovaps [rsp+0xB0], xmm11
0000708296fcedb9  vmovaps [rsp+0xC0], xmm12
0000708296fcedc2  vmovaps [rsp+0xD0], xmm14
0000708296fcedcb  vmovaps [rsp+0xE0], xmm15
0000708296fcedd4  sub rsp, 0x30
0000708296fcedd8  movaps [rsp], xmm13
0000708296fceddd  movaps [rsp+0x10], xmm15
0000708296fcede3  movaps [rsp+0x20], xmm14
0000708296fcede9  lea rdi, [rsp]
0000708296fceded  mov esi, 0x00
0000708296fcedf2  mov rax, 0x64BBC686C530
0000708296fcedfc  call rax
0000708296fcedfe  movaps xmm13, [rsp]
0000708296fcee03  add rsp, 0x30
0000708296fcee07  vmovaps xmm0, [rsp]
0000708296fcee0c  vmovaps xmm1, [rsp+0x10]
0000708296fcee12  vmovaps xmm2, [rsp+0x20]
0000708296fcee18  vmovaps xmm3, [rsp+0x30]
0000708296fcee1e  vmovaps xmm4, [rsp+0x40]
0000708296fcee24  vmovaps xmm5, [rsp+0x50]
0000708296fcee2a  vmovaps xmm6, [rsp+0x60]
0000708296fcee30  vmovaps xmm7, [rsp+0x70]
0000708296fcee36  vmovaps xmm8, [rsp+0x80]
0000708296fcee3f  vmovaps xmm9, [rsp+0x90]
0000708296fcee48  vmovaps xmm10, [rsp+0xA0]
0000708296fcee51  vmovaps xmm11, [rsp+0xB0]
0000708296fcee5a  vmovaps xmm12, [rsp+0xC0]
0000708296fcee63  vmovaps xmm14, [rsp+0xD0]
0000708296fcee6c  vmovaps xmm15, [rsp+0xE0]
0000708296fcee75  add rsp, 0xF0
0000708296fcee7c  pop r11
0000708296fcee7e  pop r10
0000708296fcee80  pop r9
0000708296fcee82  pop r8
0000708296fcee84  pop rsi
0000708296fcee85  pop rdi
0000708296fcee86  pop rdx
0000708296fcee87  pop rcx
0000708296fcee88  pop rax
0000708296fcee89  add rsp, 0x08
0000708296fcee8d  jmp 0x0000708296FCEC71
0000708296fcee92  call 0x0000708296EC2240
0000708296fcee97  jmp 0x0000708296FCEC8B
0000708296fcee9c  sub rsp, 0x08
0000708296fceea0  push rax
0000708296fceea1  push rcx
0000708296fceea2  push rdx
0000708296fceea3  push rdi
0000708296fceea4  push rsi
0000708296fceea5  push r8
0000708296fceea7  push r9
0000708296fceea9  push r10
0000708296fceeab  push r11
0000708296fceead  sub rsp, 0xF0
0000708296fceeb4  vmovaps [rsp], xmm0
0000708296fceeb9  vmovaps [rsp+0x10], xmm1
0000708296fceebf  vmovaps [rsp+0x20], xmm2
0000708296fceec5  vmovaps [rsp+0x30], xmm3
0000708296fceecb  vmovaps [rsp+0x40], xmm4
0000708296fceed1  vmovaps [rsp+0x50], xmm5
0000708296fceed7  vmovaps [rsp+0x60], xmm6
0000708296fceedd  vmovaps [rsp+0x70], xmm7
0000708296fceee3  vmovaps [rsp+0x80], xmm8
0000708296fceeec  vmovaps [rsp+0x90], xmm9
0000708296fceef5  vmovaps [rsp+0xA0], xmm10
0000708296fceefe  vmovaps [rsp+0xB0], xmm11
0000708296fcef07  vmovaps [rsp+0xC0], xmm12
0000708296fcef10  vmovaps [rsp+0xD0], xmm13
0000708296fcef19  vmovaps [rsp+0xE0], xmm15
0000708296fcef22  sub rsp, 0x30
0000708296fcef26  movaps [rsp], xmm14
0000708296fcef2b  movaps [rsp+0x10], xmm1
0000708296fcef30  movaps [rsp+0x20], xmm15
0000708296fcef36  lea rdi, [rsp]
0000708296fcef3a  mov esi, 0x00
0000708296fcef3f  mov rax, 0x64BBC686C530
0000708296fcef49  call rax
0000708296fcef4b  movaps xmm14, [rsp]
0000708296fcef50  add rsp, 0x30
0000708296fcef54  vmovaps xmm0, [rsp]
0000708296fcef59  vmovaps xmm1, [rsp+0x10]
0000708296fcef5f  vmovaps xmm2, [rsp+0x20]
0000708296fcef65  vmovaps xmm3, [rsp+0x30]
0000708296fcef6b  vmovaps xmm4, [rsp+0x40]
0000708296fcef71  vmovaps xmm5, [rsp+0x50]
0000708296fcef77  vmovaps xmm6, [rsp+0x60]
0000708296fcef7d  vmovaps xmm7, [rsp+0x70]
0000708296fcef83  vmovaps xmm8, [rsp+0x80]
0000708296fcef8c  vmovaps xmm9, [rsp+0x90]
0000708296fcef95  vmovaps xmm10, [rsp+0xA0]
0000708296fcef9e  vmovaps xmm11, [rsp+0xB0]
0000708296fcefa7  vmovaps xmm12, [rsp+0xC0]
0000708296fcefb0  vmovaps xmm13, [rsp+0xD0]
0000708296fcefb9  vmovaps xmm15, [rsp+0xE0]
0000708296fcefc2  add rsp, 0xF0
0000708296fcefc9  pop r11
0000708296fcefcb  pop r10
0000708296fcefcd  pop r9
0000708296fcefcf  pop r8
0000708296fcefd1  pop rsi
0000708296fcefd2  pop rdi
0000708296fcefd3  pop rdx
0000708296fcefd4  pop rcx
0000708296fcefd5  pop rax
0000708296fcefd6  add rsp, 0x08
0000708296fcefda  jmp 0x0000708296FCECAE
0000708296fcefdf  call 0x0000708296EC34C0
0000708296fcefe4  jmp 0x0000708296FCECC4
0000708296fcefe9  int3
0000708296fcefea  nop [rax+rax*1], ax
0000708296fceff0  mov rax, [r15+0xF8]
0000708296fceff7  lea r14, [rax-0x150]
0000708296fceffe  mov [r15+0xF8], r14
0000708296fcf005  mov rax, [r15+0x50]
0000708296fcf009  lea r12, [rax+0x80]
0000708296fcf010  movups xmm1, [r13+r12*1]
0000708296fcf016  lea r12, [rax+0x90]
0000708296fcf01d  movups xmm15, [r13+r12*1]
0000708296fcf023  mov qword ptr [r15+0x48], 0x00
0000708296fcf02b  lea r12, [rax+0x40]
0000708296fcf02f  movups xmm14, [r13+r12*1]
0000708296fcf035  lea r12, [rax+0x50]
0000708296fcf039  movups xmm13, [r13+r12*1]
0000708296fcf03f  lea r12, [r14+0x120]
0000708296fcf046  movq xmm12, qword ptr [r15+0x1C0]
0000708296fcf04f  movq xmm11, qword ptr [r15+0x1B0]
0000708296fcf058  movq r11, xmm12
0000708296fcf05d  movq r10, xmm11
0000708296fcf062  mov [r13+r12*1], r11
0000708296fcf067  lea r12, [r14+0x128]
0000708296fcf06e  mov [r13+r12*1], r10
0000708296fcf073  vxorps xmm12, xmm12, xmm12
0000708296fcf078  vpbroadcastq xmm12, xmm12
0000708296fcf07d  lea r12, [r14+0x100]
0000708296fcf084  movq xmm11, qword ptr [r15+0x200]
0000708296fcf08d  movq xmm10, qword ptr [r15+0x1F0]
0000708296fcf096  movq r11, xmm11
0000708296fcf09b  movq r10, xmm10
0000708296fcf0a0  mov [r13+r12*1], r11
0000708296fcf0a5  lea r12, [r14+0x108]
0000708296fcf0ac  mov [r13+r12*1], r10
0000708296fcf0b1  lea r12, [r14+0xE0]
0000708296fcf0b8  movups [r13+r12*1], xmm15
0000708296fcf0be  lea r12, [r14+0xF0]
0000708296fcf0c5  movups [r13+r12*1], xmm1
0000708296fcf0cb  lea r12, [rax+0xC0]
0000708296fcf0d2  movups xmm1, [r13+r12*1]
0000708296fcf0d8  lea r12, [rax+0xD0]
0000708296fcf0df  movups xmm15, [r13+r12*1]
0000708296fcf0e5  lea r12, [r14+0x110]
0000708296fcf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000708296fcf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000708296fcf0fe  movq r11, xmm11
0000708296fcf103  movq r10, xmm10
0000708296fcf108  mov [r13+r12*1], r11
0000708296fcf10d  lea r12, [r14+0x118]
0000708296fcf114  mov [r13+r12*1], r10
0000708296fcf119  movups xmm11, [r13+rax*1]
0000708296fcf11f  lea r12, [rax+0x10]
0000708296fcf123  movups xmm10, [r13+r12*1]
0000708296fcf129  lea r12, [r14+0x130]
0000708296fcf130  movq xmm9, qword ptr [r15+0x1A0]
0000708296fcf139  movq xmm8, qword ptr [r15+0x190]
0000708296fcf142  movq r11, xmm9
0000708296fcf147  movq r10, xmm8
0000708296fcf14c  mov [r13+r12*1], r11
0000708296fcf151  lea r12, [r14+0x138]
0000708296fcf158  mov [r13+r12*1], r10
0000708296fcf15d  lea r12, [rax+0x140]
0000708296fcf164  movups xmm9, [r13+r12*1]
0000708296fcf16a  lea r12, [rax+0x150]
0000708296fcf171  movups xmm8, [r13+r12*1]
0000708296fcf177  lea r12, [r14+0xC0]
0000708296fcf17e  movups [r13+r12*1], xmm15
0000708296fcf184  lea r12, [r14+0xD0]
0000708296fcf18b  movups [r13+r12*1], xmm1
0000708296fcf191  lea r12, [rax+0x100]
0000708296fcf198  movups xmm1, [r13+r12*1]
0000708296fcf19e  lea r12, [rax+0x110]
0000708296fcf1a5  movups xmm15, [r13+r12*1]
0000708296fcf1ab  lea r12, [r14+0x140]
0000708296fcf1b2  mov r11, [r15+0xE8]
0000708296fcf1b9  mov [r13+r12*1], r11
0000708296fcf1be  lea r12, [rax+0x180]
0000708296fcf1c5  movups xmm7, [r13+r12*1]
0000708296fcf1cb  lea r12, [rax+0x190]
0000708296fcf1d2  movups xmm6, [r13+r12*1]
0000708296fcf1d8  lea r12, [rax+0x1C0]
0000708296fcf1df  movups xmm5, [r13+r12*1]
0000708296fcf1e5  lea r12, [rax+0x1D0]
0000708296fcf1ec  movups xmm4, [r13+r12*1]
0000708296fcf1f2  lea r12, [r14+0x20]
0000708296fcf1f6  movups [r13+r12*1], xmm1
0000708296fcf1fc  lea r12, [r14+0x30]
0000708296fcf200  movups [r13+r12*1], xmm13
0000708296fcf206  lea r12, [rax+0x60]
0000708296fcf20a  movups xmm1, [r13+r12*1]
0000708296fcf210  lea r12, [rax+0x70]
0000708296fcf214  movups xmm13, [r13+r12*1]
0000708296fcf21a  lea r12, [rax+0x20]
0000708296fcf21e  movups xmm3, [r13+r12*1]
0000708296fcf224  lea r12, [rax+0x30]
0000708296fcf228  movups xmm2, [r13+r12*1]
0000708296fcf22e  movaps [r15+0x1F0], xmm2
0000708296fcf236  lea r12, [r14+0x60]
0000708296fcf23a  movups [r13+r12*1], xmm11
0000708296fcf240  lea r12, [r14+0x70]
0000708296fcf244  movups [r13+r12*1], xmm5
0000708296fcf24a  lea r12, [rax+0xE0]
0000708296fcf251  movups xmm11, [r13+r12*1]
0000708296fcf257  lea r12, [rax+0xF0]
0000708296fcf25e  movups xmm5, [r13+r12*1]
0000708296fcf264  lea r12, [r14+0xA0]
0000708296fcf26b  movups [r13+r12*1], xmm13
0000708296fcf271  lea r12, [r14+0xB0]
0000708296fcf278  movups [r13+r12*1], xmm1
0000708296fcf27e  lea r12, [rax+0xA0]
0000708296fcf285  movups xmm1, [r13+r12*1]
0000708296fcf28b  lea r12, [rax+0xB0]
0000708296fcf292  movups xmm13, [r13+r12*1]
0000708296fcf298  lea r12, [rax+0x120]
0000708296fcf29f  vmovaps [rsp+0x10], xmm1
0000708296fcf2a5  movups xmm1, [r13+r12*1]
0000708296fcf2ab  lea r12, [rax+0x130]
0000708296fcf2b2  vmovaps [rsp+0x20], xmm1
0000708296fcf2b8  movups xmm1, [r13+r12*1]
0000708296fcf2be  lea r12, [rax+0x160]
0000708296fcf2c5  vmovaps [rsp+0x30], xmm1
0000708296fcf2cb  movups xmm1, [r13+r12*1]
0000708296fcf2d1  lea r12, [rax+0x170]
0000708296fcf2d8  vmovaps [rsp+0x40], xmm1
0000708296fcf2de  movups xmm1, [r13+r12*1]
0000708296fcf2e4  movaps [r15+0x2B0], xmm1
0000708296fcf2ec  lea r12, [r14+0x80]
0000708296fcf2f3  movups [r13+r12*1], xmm13
0000708296fcf2f9  lea r12, [r14+0x90]
0000708296fcf300  vmovaps xmm13, [rsp+0x10]
0000708296fcf306  movups [r13+r12*1], xmm13
0000708296fcf30c  lea r12, [rax+0x1A0]
0000708296fcf313  movups xmm13, [r13+r12*1]
0000708296fcf319  lea r12, [rax+0x1B0]
0000708296fcf320  vmovaps [rsp+0x10], xmm1
0000708296fcf326  movups xmm1, [r13+r12*1]
0000708296fcf32c  movaps [r15+0x290], xmm13
0000708296fcf334  movaps [r15+0x1E0], xmm1
0000708296fcf33c  lea r12, [rax+0x1E0]
0000708296fcf343  vmovaps [rsp+0x50], xmm1
0000708296fcf349  movups xmm1, [r13+r12*1]
0000708296fcf34f  lea r12, [rax+0x1F0]
0000708296fcf356  vmovaps [rsp+0x60], xmm1
0000708296fcf35c  movups xmm1, [r13+r12*1]
0000708296fcf362  mov qword ptr [r15+0x50], 0x430920
0000708296fcf36a  lea rax, [r14+0x40]
0000708296fcf36e  vmovaps [rsp+0x70], xmm1
0000708296fcf374  vmovaps xmm1, [rsp+0x40]
0000708296fcf37a  movups [r13+rax*1], xmm1
0000708296fcf380  lea rax, [r14+0x50]
0000708296fcf384  movups [r13+rax*1], xmm10
0000708296fcf38a  vmovaps xmm1, [rsp+0x70]
0000708296fcf390  movups [r13+r14*1], xmm1
0000708296fcf396  lea rax, [r14+0x10]
0000708296fcf39a  vmovaps xmm1, [rsp+0x60]
0000708296fcf3a0  movups [r13+rax*1], xmm1
0000708296fcf3a6  mov rax, [r15+0x40]
0000708296fcf3aa  vmovaps [rsp+0x40], xmm3
0000708296fcf3b0  vmovaps xmm1, [rsp+0x40]
0000708296fcf3b6  por xmm3, xmm1
0000708296fcf3ba  vmovaps [rsp+0x40], xmm6
0000708296fcf3c0  vmovaps xmm10, [rsp+0x40]
0000708296fcf3c6  por xmm6, xmm10
0000708296fcf3cb  lea r12, [rax+0x30]
0000708296fcf3cf  mov r11, [r13+r12*1]
0000708296fcf3d4  lea r12, [rax+0x38]
0000708296fcf3d8  mov r10, [r13+r12*1]
0000708296fcf3dd  movq xmm10, r11
0000708296fcf3e2  vmovaps [rsp+0x40], xmm1
0000708296fcf3e8  movq xmm1, r10
0000708296fcf3ed  movq xmm10, xmm10
0000708296fcf3f2  vmovaps [rsp+0x60], xmm10
0000708296fcf3f8  movq xmm10, xmm10
0000708296fcf3fd  movaps [r15+0x130], xmm10
0000708296fcf405  movq xmm1, xmm1
0000708296fcf409  vmovaps [rsp+0x70], xmm1
0000708296fcf40f  movq xmm1, xmm1
0000708296fcf413  movaps [r15+0x280], xmm1
0000708296fcf41b  vmovaps [rsp+0x80], xmm9
0000708296fcf424  vmovaps xmm1, [rsp+0x80]
0000708296fcf42d  por xmm9, xmm1
0000708296fcf432  lea r12, [rax+0x20]
0000708296fcf436  mov r11, [r13+r12*1]
0000708296fcf43b  lea r12, [rax+0x28]
0000708296fcf43f  mov r10, [r13+r12*1]
0000708296fcf444  movq xmm1, r11
0000708296fcf449  movq xmm10, r10
0000708296fcf44e  movq xmm1, xmm1
0000708296fcf452  vmovaps [rsp+0x80], xmm1
0000708296fcf45b  movq xmm1, xmm1
0000708296fcf45f  movaps [r15+0x150], xmm1
0000708296fcf467  movq xmm10, xmm10
0000708296fcf46c  vmovaps [rsp+0x90], xmm10
0000708296fcf475  movq xmm10, xmm10
0000708296fcf47a  movaps [r15+0x140], xmm10
0000708296fcf482  lea r12, [rax+0x10]
0000708296fcf486  mov r11, [r13+r12*1]
0000708296fcf48b  lea r12, [rax+0x18]
0000708296fcf48f  mov r10, [r13+r12*1]
0000708296fcf494  movq xmm1, r11
0000708296fcf499  movq xmm10, r10
0000708296fcf49e  movq xmm1, xmm1
0000708296fcf4a2  vmovaps [rsp+0xA0], xmm1
0000708296fcf4ab  movq xmm1, xmm1
0000708296fcf4af  movaps [r15+0x170], xmm1
0000708296fcf4b7  movq xmm10, xmm10
0000708296fcf4bc  vmovaps [rsp+0xB0], xmm10
0000708296fcf4c5  movq xmm10, xmm10
0000708296fcf4ca  movaps [r15+0x160], xmm10
0000708296fcf4d2  mov r12, [r13+rax*1]
0000708296fcf4d7  vmovq xmm1, r12
0000708296fcf4dc  vpbroadcastq xmm1, xmm1
0000708296fcf4e1  lea r12, [rax+0x08]
0000708296fcf4e5  mov rax, [r13+r12*1]
0000708296fcf4ea  movq xmm10, rax
0000708296fcf4ef  movaps [r15+0x230], xmm10
0000708296fcf4f7  lea rax, [r14+0x50]
0000708296fcf4fb  movups xmm10, [r13+rax*1]
0000708296fcf501  lea rax, [r14+0x60]
0000708296fcf505  vmovaps [rsp+0xC0], xmm1
0000708296fcf50e  movups xmm1, [r13+rax*1]
0000708296fcf514  lea rax, [r14+0x30]
0000708296fcf518  vmovaps [rsp+0xD0], xmm1
0000708296fcf521  movups xmm1, [r13+rax*1]
0000708296fcf527  mov qword ptr [r15+0x60], 0x430920
0000708296fcf52f  mov qword ptr [r15+0x58], 0x40
0000708296fcf537  vmovaps [rsp+0xE0], xmm1
0000708296fcf540  vmovaps [rsp+0xF0], xmm15
0000708296fcf549  vmovaps xmm15, [rsp+0xC0]
0000708296fcf552  vmovaps [rsp+0xC0], xmm14
0000708296fcf55b  vmovaps xmm14, [rsp+0x40]
0000708296fcf561  vmovaps [rsp+0x40], xmm13
0000708296fcf567  movaps xmm1, xmm15
0000708296fcf56b  mulpd xmm1, xmm14
0000708296fcf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000708296fcf575  ptest xmm13, xmm13
0000708296fcf57b  jnz 0x0000708296FD0682
0000708296fcf581  movq xmm14, qword ptr [r15+0x230]
0000708296fcf58a  vmovaps [rsp+0x100], xmm14
0000708296fcf593  vpermilpd xmm14, xmm14, 0x00
0000708296fcf599  vmovaps [rsp+0x110], xmm1
0000708296fcf5a2  vmovaps xmm1, [rsp+0xE0]
0000708296fcf5ab  vmovaps [rsp+0xE0], xmm15
0000708296fcf5b4  movaps xmm13, xmm1
0000708296fcf5b8  mulpd xmm13, xmm14
0000708296fcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000708296fcf5c3  ptest xmm15, xmm15
0000708296fcf5c9  jnz 0x0000708296FD07C4
0000708296fcf5cf  vxorps xmm1, xmm1, xmm1
0000708296fcf5d3  vpbroadcastq xmm1, xmm1
0000708296fcf5d8  vmovaps xmm14, [rsp+0xE0]
0000708296fcf5e1  vmovaps [rsp+0xE0], xmm1
0000708296fcf5ea  vmovaps xmm1, [rsp+0xD0]
0000708296fcf5f3  vmovaps [rsp+0xD0], xmm13
0000708296fcf5fc  movaps xmm15, xmm14
0000708296fcf600  mulpd xmm15, xmm1
0000708296fcf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000708296fcf60b  ptest xmm13, xmm13
0000708296fcf611  jnz 0x0000708296FD0907
0000708296fcf617  movaps xmm1, xmm14
0000708296fcf61b  mulpd xmm1, xmm10
0000708296fcf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000708296fcf625  ptest xmm13, xmm13
0000708296fcf62b  jnz 0x0000708296FD0A4A
0000708296fcf631  movaps xmm13, xmm14
0000708296fcf635  mulpd xmm13, xmm2
0000708296fcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000708296fcf640  ptest xmm10, xmm10
0000708296fcf646  jnz 0x0000708296FD0B8C
0000708296fcf64c  vmovaps [rsp+0x120], xmm7
0000708296fcf655  vmovaps xmm14, [rsp+0x120]
0000708296fcf65e  por xmm7, xmm14
0000708296fcf663  vmovaps xmm14, [rsp+0xC0]
0000708296fcf66c  vmovaps xmm10, [rsp+0xC0]
0000708296fcf675  por xmm14, xmm10
0000708296fcf67a  vmovaps xmm2, [rsp+0x100]
0000708296fcf683  vpermilpd xmm2, xmm2, 0x00
0000708296fcf689  vmovaps [rsp+0xC0], xmm1
0000708296fcf692  vmovaps [rsp+0x120], xmm15
0000708296fcf69b  movaps xmm1, xmm10
0000708296fcf69f  mulpd xmm1, xmm2
0000708296fcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000708296fcf6a8  ptest xmm15, xmm15
0000708296fcf6ae  jnz 0x0000708296FD0CCF
0000708296fcf6b4  xor eax, eax
0000708296fcf6b6  mov r12d, 0x40
0000708296fcf6bc  mov r11d, 0x200
0000708296fcf6c2  cmp r12, r11
0000708296fcf6c5  cmc
0000708296fcf6c6  lahf
0000708296fcf6c7  seto al
0000708296fcf6ca  mov [r15+0x108], eax
0000708296fcf6d1  vmovaps xmm10, [rsp+0x110]
0000708296fcf6da  vmovaps xmm2, [rsp+0xE0]
0000708296fcf6e3  vmovaps [rsp+0xE0], xmm1
0000708296fcf6ec  movaps xmm15, xmm10
0000708296fcf6f0  addpd xmm15, xmm2
0000708296fcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000708296fcf6fb  ptest xmm1, xmm1
0000708296fcf700  jnz 0x0000708296FD0E10
0000708296fcf706  vmovaps xmm10, [rsp+0x120]
0000708296fcf70f  vmovaps [rsp+0x110], xmm15
0000708296fcf718  movaps xmm1, xmm10
0000708296fcf71c  addpd xmm1, xmm12
0000708296fcf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000708296fcf726  ptest xmm15, xmm15
0000708296fcf72c  jnz 0x0000708296FD0F53
0000708296fcf732  vmovaps xmm10, [rsp+0xC0]
0000708296fcf73b  vmovaps [rsp+0xC0], xmm1
0000708296fcf744  movaps xmm15, xmm10
0000708296fcf748  addpd xmm15, xmm12
0000708296fcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000708296fcf753  ptest xmm1, xmm1
0000708296fcf758  jnz 0x0000708296FD1095
0000708296fcf75e  vmovaps xmm1, [rsp+0x30]
0000708296fcf764  vmovaps xmm12, [rsp+0x30]
0000708296fcf76a  por xmm1, xmm12
0000708296fcf76f  vmovaps xmm12, [rsp+0x20]
0000708296fcf775  vmovaps xmm10, [rsp+0x20]
0000708296fcf77b  por xmm12, xmm10
0000708296fcf780  vmovaps [rsp+0x20], xmm5
0000708296fcf786  vmovaps xmm10, [rsp+0x20]
0000708296fcf78c  por xmm5, xmm10
0000708296fcf791  vmovaps [rsp+0x20], xmm11
0000708296fcf797  vmovaps xmm10, [rsp+0x20]
0000708296fcf79d  por xmm11, xmm10
0000708296fcf7a2  vmovaps [rsp+0x20], xmm4
0000708296fcf7a8  vmovaps xmm10, [rsp+0x20]
0000708296fcf7ae  por xmm4, xmm10
0000708296fcf7b3  vmovaps [rsp+0x20], xmm8
0000708296fcf7b9  vmovaps xmm10, [rsp+0x20]
0000708296fcf7bf  por xmm8, xmm10
0000708296fcf7c4  vmovaps xmm10, [rsp+0xF0]
0000708296fcf7cd  vmovaps [rsp+0x20], xmm1
0000708296fcf7d3  vmovaps xmm1, [rsp+0xF0]
0000708296fcf7dc  por xmm10, xmm1
0000708296fcf7e1  lea rax, [r14+0xA0]
0000708296fcf7e8  movups xmm1, [r13+rax*1]
0000708296fcf7ee  lea rax, [r14+0xB0]
0000708296fcf7f5  vmovaps [rsp+0x30], xmm1
0000708296fcf7fb  movups xmm1, [r13+rax*1]
0000708296fcf801  vmovaps [rsp+0xF0], xmm1
0000708296fcf80a  vmovaps [rsp+0x120], xmm15
0000708296fcf813  movaps xmm1, xmm13
0000708296fcf817  addpd xmm1, xmm2
0000708296fcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000708296fcf820  ptest xmm15, xmm15
0000708296fcf826  jnz 0x0000708296FD11ED
0000708296fcf82c  lea rax, [r14+0xF0]
0000708296fcf833  movups xmm15, [r13+rax*1]
0000708296fcf839  vmovaps xmm2, [rsp+0xC0]
0000708296fcf842  vmovaps [rsp+0xC0], xmm1
0000708296fcf84b  vmovaps xmm1, [rsp+0xE0]
0000708296fcf854  vmovaps [rsp+0xE0], xmm15
0000708296fcf85d  movaps xmm13, xmm2
0000708296fcf861  addpd xmm13, xmm1
0000708296fcf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000708296fcf86c  ptest xmm15, xmm15
0000708296fcf872  jnz 0x0000708296FD1338
0000708296fcf878  vmovaps xmm15, [rsp+0x120]
0000708296fcf881  vmovaps xmm2, [rsp+0xD0]
0000708296fcf88a  vmovaps [rsp+0xD0], xmm14
0000708296fcf893  movaps xmm1, xmm15
0000708296fcf897  addpd xmm1, xmm2
0000708296fcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000708296fcf8a0  ptest xmm14, xmm14
0000708296fcf8a6  jnz 0x0000708296FD147A
0000708296fcf8ac  vmovaps xmm15, [rsp+0x100]
0000708296fcf8b5  vpermilpd xmm15, xmm15, 0x00
0000708296fcf8bb  vmovaps xmm2, [rsp+0xF0]
0000708296fcf8c4  vmovaps [rsp+0xF0], xmm1
0000708296fcf8cd  movaps xmm14, xmm2
0000708296fcf8d1  mulpd xmm14, xmm15
0000708296fcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000708296fcf8dc  ptest xmm1, xmm1
0000708296fcf8e1  jnz 0x0000708296FD15BB
0000708296fcf8e7  vmovaps xmm1, [rsp+0xA0]
0000708296fcf8f0  vpermilpd xmm1, xmm1, 0x00
0000708296fcf8f6  vmovaps xmm2, [rsp+0xE0]
0000708296fcf8ff  vmovaps [rsp+0xE0], xmm14
0000708296fcf908  movaps xmm15, xmm2
0000708296fcf90c  mulpd xmm15, xmm1
0000708296fcf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000708296fcf917  ptest xmm14, xmm14
0000708296fcf91d  jnz 0x0000708296FD16FE
0000708296fcf923  lea rax, [r14+0xE0]
0000708296fcf92a  movups xmm1, [r13+rax*1]
0000708296fcf930  vmovaps xmm14, [rsp+0x100]
0000708296fcf939  vpermilpd xmm14, xmm14, 0x00
0000708296fcf93f  vmovaps [rsp+0x100], xmm1
0000708296fcf948  vmovaps xmm1, [rsp+0x30]
0000708296fcf94e  vmovaps [rsp+0x30], xmm15
0000708296fcf954  movaps xmm2, xmm1
0000708296fcf957  mulpd xmm2, xmm14
0000708296fcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000708296fcf961  ptest xmm15, xmm15
0000708296fcf967  jnz 0x0000708296FD184A
0000708296fcf96d  vmovaps [rsp+0x120], xmm10
0000708296fcf976  vmovaps xmm1, [rsp+0x120]
0000708296fcf97f  por xmm10, xmm1
0000708296fcf984  movaps [r15+0x300], xmm10
0000708296fcf98c  vmovaps [rsp+0x120], xmm8
0000708296fcf995  vmovaps xmm1, [rsp+0x120]
0000708296fcf99e  por xmm8, xmm1
0000708296fcf9a3  movaps [r15+0x190], xmm8
0000708296fcf9ab  vmovaps xmm1, [rsp+0xA0]
0000708296fcf9b4  vpermilpd xmm1, xmm1, 0x00
0000708296fcf9ba  vmovaps xmm14, [rsp+0x100]
0000708296fcf9c3  vmovaps [rsp+0x100], xmm13
0000708296fcf9cc  movaps xmm15, xmm14
0000708296fcf9d0  mulpd xmm15, xmm1
0000708296fcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000708296fcf9db  ptest xmm13, xmm13
0000708296fcf9e1  jnz 0x0000708296FD198B
0000708296fcf9e7  lea rax, [r14+0x90]
0000708296fcf9ee  movups xmm1, [r13+rax*1]
0000708296fcf9f4  vmovaps [rsp+0x120], xmm4
0000708296fcf9fd  vmovaps xmm14, [rsp+0x120]
0000708296fcfa06  por xmm4, xmm14
0000708296fcfa0b  movaps [r15+0x1C0], xmm4
0000708296fcfa13  vmovaps [rsp+0x120], xmm11
0000708296fcfa1c  vmovaps xmm14, [rsp+0x120]
0000708296fcfa25  por xmm11, xmm14
0000708296fcfa2a  movaps [r15+0x200], xmm11
0000708296fcfa32  vmovaps [rsp+0x120], xmm5
0000708296fcfa3b  vmovaps xmm14, [rsp+0x120]
0000708296fcfa44  por xmm5, xmm14
0000708296fcfa49  movaps [r15+0x2D0], xmm5
0000708296fcfa51  vmovaps [rsp+0x120], xmm12
0000708296fcfa5a  vmovaps xmm14, [rsp+0x120]
0000708296fcfa63  por xmm12, xmm14
0000708296fcfa68  movaps [r15+0x2E0], xmm12
0000708296fcfa70  vmovaps xmm13, [rsp+0x110]
0000708296fcfa79  vmovaps [rsp+0x110], xmm1
0000708296fcfa82  vmovaps xmm1, [rsp+0xE0]
0000708296fcfa8b  vmovaps [rsp+0xE0], xmm15
0000708296fcfa94  movaps xmm14, xmm13
0000708296fcfa98  addpd xmm14, xmm1
0000708296fcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000708296fcfaa3  ptest xmm15, xmm15
0000708296fcfaa9  jnz 0x0000708296FD1AD8
0000708296fcfaaf  vmovaps xmm1, [rsp+0xA0]
0000708296fcfab8  vpermilpd xmm1, xmm1, 0x00
0000708296fcfabe  vmovaps xmm13, [rsp+0x110]
0000708296fcfac7  vmovaps [rsp+0x110], xmm14
0000708296fcfad0  movaps xmm15, xmm13
0000708296fcfad4  mulpd xmm15, xmm1
0000708296fcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000708296fcfadf  ptest xmm14, xmm14
0000708296fcfae5  jnz 0x0000708296FD1C1B
0000708296fcfaeb  lea rax, [r14+0x80]
0000708296fcfaf2  movups xmm1, [r13+rax*1]
0000708296fcfaf8  vmovaps xmm13, [rsp+0xC0]
0000708296fcfb01  vmovaps [rsp+0xC0], xmm1
0000708296fcfb0a  movaps xmm14, xmm13
0000708296fcfb0e  addpd xmm14, xmm2
0000708296fcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000708296fcfb19  ptest xmm1, xmm1
0000708296fcfb1e  jnz 0x0000708296FD1D68
0000708296fcfb24  vmovaps xmm13, [rsp+0x100]
0000708296fcfb2d  vmovaps xmm2, [rsp+0x30]
0000708296fcfb33  vmovaps [rsp+0x30], xmm15
0000708296fcfb39  movaps xmm1, xmm13
0000708296fcfb3d  addpd xmm1, xmm2
0000708296fcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000708296fcfb46  ptest xmm15, xmm15
0000708296fcfb4c  jnz 0x0000708296FD1EAB
0000708296fcfb52  vmovaps xmm15, [rsp+0x20]
0000708296fcfb58  vmovaps xmm13, [rsp+0x20]
0000708296fcfb5e  por xmm15, xmm13
0000708296fcfb63  movaps [r15+0x2F0], xmm15
0000708296fcfb6b  vmovaps xmm13, [rsp+0xA0]
0000708296fcfb74  vpermilpd xmm13, xmm13, 0x00
0000708296fcfb7a  vmovaps [rsp+0x20], xmm1
0000708296fcfb80  vmovaps xmm1, [rsp+0xC0]
0000708296fcfb89  vmovaps [rsp+0xA0], xmm15
0000708296fcfb92  movaps xmm2, xmm1
0000708296fcfb95  mulpd xmm2, xmm13
0000708296fcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000708296fcfb9f  ptest xmm15, xmm15
0000708296fcfba5  jnz 0x0000708296FD1FEC
0000708296fcfbab  lea rax, [r14+0xD0]
0000708296fcfbb2  movups xmm1, [r13+rax*1]
0000708296fcfbb8  vmovaps xmm13, [rsp+0xF0]
0000708296fcfbc1  vmovaps [rsp+0xC0], xmm1
0000708296fcfbca  vmovaps xmm1, [rsp+0xE0]
0000708296fcfbd3  vmovaps [rsp+0xE0], xmm14
0000708296fcfbdc  movaps xmm15, xmm13
0000708296fcfbe0  addpd xmm15, xmm1
0000708296fcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000708296fcfbeb  ptest xmm14, xmm14
0000708296fcfbf1  jnz 0x0000708296FD2137
0000708296fcfbf7  vmovaps xmm1, [rsp+0xB0]
0000708296fcfc00  vpermilpd xmm1, xmm1, 0x00
0000708296fcfc06  movaps xmm14, xmm11
0000708296fcfc0a  mulpd xmm14, xmm1
0000708296fcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000708296fcfc15  ptest xmm13, xmm13
0000708296fcfc1b  jnz 0x0000708296FD227A
0000708296fcfc21  movaps [r15+0x260], xmm14
0000708296fcfc29  vxorps xmm1, xmm1, xmm1
0000708296fcfc2d  vpbroadcastq xmm1, xmm1
0000708296fcfc32  movaps [r15+0x1B0], xmm1
0000708296fcfc3a  vmovaps xmm1, [rsp+0xB0]
0000708296fcfc43  vpermilpd xmm1, xmm1, 0x00
0000708296fcfc49  vmovaps xmm11, [rsp+0xC0]
0000708296fcfc52  vmovaps [rsp+0xC0], xmm15
0000708296fcfc5b  movaps xmm13, xmm11
0000708296fcfc5f  mulpd xmm13, xmm1
0000708296fcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000708296fcfc6a  ptest xmm15, xmm15
0000708296fcfc70  jnz 0x0000708296FD23BD
0000708296fcfc76  lea rax, [r14+0xC0]
0000708296fcfc7d  movups xmm1, [r13+rax*1]
0000708296fcfc83  vmovaps xmm11, [rsp+0x110]
0000708296fcfc8c  vmovaps [rsp+0xF0], xmm1
0000708296fcfc95  vmovaps xmm1, [rsp+0x30]
0000708296fcfc9b  vmovaps [rsp+0x30], xmm14
0000708296fcfca1  movaps xmm15, xmm11
0000708296fcfca5  addpd xmm15, xmm1
0000708296fcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000708296fcfcb0  ptest xmm14, xmm14
0000708296fcfcb6  jnz 0x0000708296FD250A
0000708296fcfcbc  vmovaps [rsp+0x100], xmm9
0000708296fcfcc5  vmovaps xmm1, [rsp+0x100]
0000708296fcfcce  por xmm9, xmm1
0000708296fcfcd3  movaps [r15+0x270], xmm9
0000708296fcfcdb  vmovaps [rsp+0x100], xmm6
0000708296fcfce4  vmovaps xmm1, [rsp+0x100]
0000708296fcfced  por xmm6, xmm1
0000708296fcfcf1  movaps [r15+0x1A0], xmm6
0000708296fcfcf9  vmovaps xmm14, [rsp+0xB0]
0000708296fcfd02  vpermilpd xmm14, xmm14, 0x00
0000708296fcfd08  vmovaps xmm6, [rsp+0xF0]
0000708296fcfd11  vmovaps [rsp+0xF0], xmm1
0000708296fcfd1a  movaps xmm11, xmm6
0000708296fcfd1e  mulpd xmm11, xmm14
0000708296fcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000708296fcfd29  ptest xmm1, xmm1
0000708296fcfd2e  jnz 0x0000708296FD264D
0000708296fcfd34  lea rax, [r14+0x20]
0000708296fcfd38  movups xmm1, [r13+rax*1]
0000708296fcfd3e  movaps [r15+0x110], xmm1
0000708296fcfd46  vmovaps xmm6, [rsp+0xE0]
0000708296fcfd4f  vmovaps [rsp+0xE0], xmm1
0000708296fcfd58  movaps xmm14, xmm6
0000708296fcfd5c  addpd xmm14, xmm2
0000708296fcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000708296fcfd67  ptest xmm1, xmm1
0000708296fcfd6c  jnz 0x0000708296FD279A
0000708296fcfd72  vmovaps xmm1, [rsp+0xB0]
0000708296fcfd7b  vpermilpd xmm1, xmm1, 0x00
0000708296fcfd81  movaps xmm6, xmm5
0000708296fcfd84  mulpd xmm6, xmm1
0000708296fcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000708296fcfd8d  ptest xmm2, xmm2
0000708296fcfd92  jnz 0x0000708296FD28DC
0000708296fcfd98  vmovaps xmm5, [rsp+0x20]
0000708296fcfd9e  movaps xmm1, xmm5
0000708296fcfda1  addpd xmm1, xmm13
0000708296fcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000708296fcfdab  ptest xmm2, xmm2
0000708296fcfdb0  jnz 0x0000708296FD2A1C
0000708296fcfdb6  vmovaps xmm13, [rsp+0x80]
0000708296fcfdbf  vpermilpd xmm13, xmm13, 0x00
0000708296fcfdc5  vmovaps xmm2, [rsp+0xE0]
0000708296fcfdce  vmovaps [rsp+0x20], xmm1
0000708296fcfdd4  movaps xmm5, xmm2
0000708296fcfdd7  mulpd xmm5, xmm13
0000708296fcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000708296fcfde1  ptest xmm1, xmm1
0000708296fcfde6  jnz 0x0000708296FD2B5D
0000708296fcfdec  vmovaps xmm1, [rsp+0x80]
0000708296fcfdf5  vpermilpd xmm1, xmm1, 0x00
0000708296fcfdfb  movaps xmm13, xmm10
0000708296fcfdff  mulpd xmm13, xmm1
0000708296fcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000708296fcfe0a  ptest xmm2, xmm2
0000708296fcfe0f  jnz 0x0000708296FD2C9E
0000708296fcfe15  vmovaps xmm10, [rsp+0x30]
0000708296fcfe1b  movaps xmm1, xmm15
0000708296fcfe1f  addpd xmm1, xmm10
0000708296fcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000708296fcfe29  ptest xmm2, xmm2
0000708296fcfe2e  jnz 0x0000708296FD2DE1
0000708296fcfe34  vmovaps xmm10, [rsp+0xC0]
0000708296fcfe3d  movaps xmm15, xmm10
0000708296fcfe41  addpd xmm15, xmm11
0000708296fcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000708296fcfe4c  ptest xmm2, xmm2
0000708296fcfe51  jnz 0x0000708296FD2F23
0000708296fcfe57  vmovaps xmm11, [rsp+0x80]
0000708296fcfe60  vpermilpd xmm11, xmm11, 0x00
0000708296fcfe66  movaps xmm10, xmm12
0000708296fcfe6a  mulpd xmm10, xmm11
0000708296fcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000708296fcfe75  ptest xmm2, xmm2
0000708296fcfe7a  jnz 0x0000708296FD3067
0000708296fcfe80  vmovaps xmm12, [rsp+0x80]
0000708296fcfe89  vpermilpd xmm12, xmm12, 0x00
0000708296fcfe8f  vmovaps xmm2, [rsp+0xA0]
0000708296fcfe98  vmovaps [rsp+0x30], xmm1
0000708296fcfe9e  movaps xmm11, xmm2
0000708296fcfea2  mulpd xmm11, xmm12
0000708296fcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000708296fcfead  ptest xmm1, xmm1
0000708296fcfeb2  jnz 0x0000708296FD31AB
0000708296fcfeb8  movaps xmm1, xmm14
0000708296fcfebc  addpd xmm1, xmm6
0000708296fcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000708296fcfec5  ptest xmm12, xmm12
0000708296fcfecb  jnz 0x0000708296FD32EE
0000708296fcfed1  vmovaps xmm12, [rsp+0x20]
0000708296fcfed7  movaps xmm14, xmm12
0000708296fcfedb  addpd xmm14, xmm5
0000708296fcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000708296fcfee6  ptest xmm6, xmm6
0000708296fcfeeb  jnz 0x0000708296FD342F
0000708296fcfef1  vmovaps xmm12, [rsp+0x90]
0000708296fcfefa  vpermilpd xmm12, xmm12, 0x00
0000708296fcff00  movaps xmm6, xmm9
0000708296fcff04  mulpd xmm6, xmm12
0000708296fcff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000708296fcff0e  ptest xmm5, xmm5
0000708296fcff13  jnz 0x0000708296FD3572
0000708296fcff19  movaps xmm12, xmm15
0000708296fcff1d  addpd xmm12, xmm13
0000708296fcff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000708296fcff28  ptest xmm9, xmm9
0000708296fcff2e  jnz 0x0000708296FD36B4
0000708296fcff34  vmovaps xmm13, [rsp+0x30]
0000708296fcff3a  movaps xmm15, xmm13
0000708296fcff3e  addpd xmm15, xmm10
0000708296fcff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000708296fcff49  ptest xmm9, xmm9
0000708296fcff4f  jnz 0x0000708296FD37F8
0000708296fcff55  vmovaps xmm13, [rsp+0xD0]
0000708296fcff5e  vmovaps xmm10, [rsp+0xD0]
0000708296fcff67  por xmm13, xmm10
0000708296fcff6c  movaps [r15+0x250], xmm13
0000708296fcff74  vmovaps [rsp+0x20], xmm7
0000708296fcff7a  vmovaps xmm13, [rsp+0x20]
0000708296fcff80  por xmm7, xmm13
0000708296fcff85  movaps [r15+0x2A0], xmm7
0000708296fcff8d  vmovaps [rsp+0x20], xmm3
0000708296fcff93  vmovaps xmm13, [rsp+0x20]
0000708296fcff99  por xmm3, xmm13
0000708296fcff9e  movaps [r15+0x1D0], xmm3
0000708296fcffa6  lea rax, [r14+0x40]
0000708296fcffaa  movups xmm13, [r13+rax*1]
0000708296fcffb0  movaps [r15+0x2C0], xmm13
0000708296fcffb8  vmovaps xmm10, [rsp+0x90]
0000708296fcffc1  vpermilpd xmm10, xmm10, 0x00
0000708296fcffc7  movaps xmm9, xmm8
0000708296fcffcb  mulpd xmm9, xmm10
0000708296fcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000708296fcffd6  ptest xmm5, xmm5
0000708296fcffdb  jnz 0x0000708296FD3946
0000708296fcffe1  movaps xmm10, xmm1
0000708296fcffe5  addpd xmm10, xmm11
0000708296fcffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000708296fcfff0  ptest xmm8, xmm8
0000708296fcfff6  jnz 0x0000708296FD3A8A
0000708296fcfffc  movaps xmm1, xmm14
0000708296fd0000  addpd xmm1, xmm6
0000708296fd0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000708296fd0009  ptest xmm11, xmm11
0000708296fd000f  jnz 0x0000708296FD3BCD
0000708296fd0015  vmovaps xmm14, [rsp+0x90]
0000708296fd001e  vpermilpd xmm14, xmm14, 0x00
0000708296fd0024  movaps xmm11, xmm13
0000708296fd0028  mulpd xmm11, xmm14
0000708296fd002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000708296fd0033  ptest xmm8, xmm8
0000708296fd0039  jnz 0x0000708296FD3D0E
0000708296fd003f  vmovaps xmm14, [rsp+0x90]
0000708296fd0048  vpermilpd xmm14, xmm14, 0x00
0000708296fd004e  vmovaps xmm8, [rsp+0x10]
0000708296fd0054  movaps xmm13, xmm8
0000708296fd0058  mulpd xmm13, xmm14
0000708296fd005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000708296fd0063  ptest xmm6, xmm6
0000708296fd0068  jnz 0x0000708296FD3E52
0000708296fd006e  vmovaps xmm14, [rsp+0x60]
0000708296fd0074  vpermilpd xmm14, xmm14, 0x00
0000708296fd007a  movaps xmm8, xmm7
0000708296fd007e  mulpd xmm8, xmm14
0000708296fd0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000708296fd0089  ptest xmm6, xmm6
0000708296fd008e  jnz 0x0000708296FD3F96
0000708296fd0094  movaps xmm14, xmm12
0000708296fd0098  addpd xmm14, xmm9
0000708296fd009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000708296fd00a3  ptest xmm7, xmm7
0000708296fd00a8  jnz 0x0000708296FD40D9
0000708296fd00ae  vmovaps xmm12, [rsp+0x60]
0000708296fd00b4  vpermilpd xmm12, xmm12, 0x00
0000708296fd00ba  vmovaps xmm7, [rsp+0xF0]
0000708296fd00c3  movaps xmm9, xmm7
0000708296fd00c7  mulpd xmm9, xmm12
0000708296fd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000708296fd00d2  ptest xmm6, xmm6
0000708296fd00d7  jnz 0x0000708296FD421D
0000708296fd00dd  movaps xmm12, xmm15
0000708296fd00e1  addpd xmm12, xmm11
0000708296fd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000708296fd00ec  ptest xmm7, xmm7
0000708296fd00f1  jnz 0x0000708296FD4360
0000708296fd00f7  vmovaps xmm15, [rsp+0x60]
0000708296fd00fd  vpermilpd xmm15, xmm15, 0x00
0000708296fd0103  vmovaps xmm7, [rsp+0x40]
0000708296fd0109  movaps xmm11, xmm7
0000708296fd010d  mulpd xmm11, xmm15
0000708296fd0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000708296fd0118  ptest xmm6, xmm6
0000708296fd011d  jnz 0x0000708296FD44A4
0000708296fd0123  movaps xmm15, xmm10
0000708296fd0127  addpd xmm15, xmm13
0000708296fd012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000708296fd0132  ptest xmm7, xmm7
0000708296fd0137  jnz 0x0000708296FD45E7
0000708296fd013d  vmovaps xmm13, [rsp+0x60]
0000708296fd0143  vpermilpd xmm13, xmm13, 0x00
0000708296fd0149  vmovaps xmm7, [rsp+0x50]
0000708296fd014f  movaps xmm10, xmm7
0000708296fd0153  mulpd xmm10, xmm13
0000708296fd0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000708296fd015e  ptest xmm6, xmm6
0000708296fd0163  jnz 0x0000708296FD472B
0000708296fd0169  movaps xmm13, xmm1
0000708296fd016d  addpd xmm13, xmm8
0000708296fd0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000708296fd0178  ptest xmm7, xmm7
0000708296fd017d  jnz 0x0000708296FD486E
0000708296fd0183  lea rax, [r14+0x70]
0000708296fd0187  movups xmm1, [r13+rax*1]
0000708296fd018d  movaps [r15+0x240], xmm1
0000708296fd0195  movaps xmm8, xmm14
0000708296fd0199  addpd xmm8, xmm9
0000708296fd019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000708296fd01a4  ptest xmm7, xmm7
0000708296fd01a9  jnz 0x0000708296FD49BB
0000708296fd01af  movaps [r15+0x170], xmm8
0000708296fd01b7  vmovaps xmm14, [rsp+0x70]
0000708296fd01bd  vpermilpd xmm14, xmm14, 0x00
0000708296fd01c3  movaps xmm9, xmm1
0000708296fd01c7  mulpd xmm9, xmm14
0000708296fd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000708296fd01d2  ptest xmm7, xmm7
0000708296fd01d7  jnz 0x0000708296FD4AFF
0000708296fd01dd  vmovaps xmm1, [rsp+0x70]
0000708296fd01e3  vpermilpd xmm1, xmm1, 0x00
0000708296fd01e9  movaps xmm14, xmm4
0000708296fd01ed  mulpd xmm14, xmm1
0000708296fd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000708296fd01f8  ptest xmm7, xmm7
0000708296fd01fd  jnz 0x0000708296FD4C42
0000708296fd0203  movaps [r15+0x180], xmm14
0000708296fd020b  movaps xmm1, xmm12
0000708296fd020f  addpd xmm1, xmm11
0000708296fd0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000708296fd0219  ptest xmm7, xmm7
0000708296fd021e  jnz 0x0000708296FD4D84
0000708296fd0224  movaps [r15+0x210], xmm1
0000708296fd022c  movups xmm12, [r13+r14*1]
0000708296fd0232  lea rax, [r14+0x10]
0000708296fd0236  movups xmm11, [r13+rax*1]
0000708296fd023c  movaps [r15+0x230], xmm11
0000708296fd0244  movaps xmm7, xmm15
0000708296fd0248  addpd xmm7, xmm10
0000708296fd024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000708296fd0252  ptest xmm6, xmm6
0000708296fd0257  jnz 0x0000708296FD4EDA
0000708296fd025d  movaps [r15+0x130], xmm7
0000708296fd0265  vmovaps xmm15, [rsp+0x70]
0000708296fd026b  vpermilpd xmm15, xmm15, 0x00
0000708296fd0271  movaps xmm10, xmm11
0000708296fd0275  mulpd xmm10, xmm15
0000708296fd027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000708296fd0280  ptest xmm6, xmm6
0000708296fd0285  jnz 0x0000708296FD501C
0000708296fd028b  movaps [r15+0x220], xmm10
0000708296fd0293  vmovaps xmm15, [rsp+0x70]
0000708296fd0299  vpermilpd xmm15, xmm15, 0x00
0000708296fd029f  movaps xmm11, xmm12
0000708296fd02a3  mulpd xmm11, xmm15
0000708296fd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000708296fd02ae  ptest xmm6, xmm6
0000708296fd02b3  jnz 0x0000708296FD5160
0000708296fd02b9  movaps xmm15, xmm13
0000708296fd02bd  addpd xmm15, xmm9
0000708296fd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000708296fd02c8  ptest xmm12, xmm12
0000708296fd02ce  jnz 0x0000708296FD52A4
0000708296fd02d4  movaps [r15+0x140], xmm15
0000708296fd02dc  movaps xmm13, xmm8
0000708296fd02e0  addpd xmm13, xmm14
0000708296fd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000708296fd02eb  ptest xmm12, xmm12
0000708296fd02f1  jnz 0x0000708296FD53E8
0000708296fd02f7  movaps [r15+0x150], xmm13
0000708296fd02ff  movaps xmm14, xmm1
0000708296fd0303  addpd xmm14, xmm10
0000708296fd0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000708296fd030e  ptest xmm12, xmm12
0000708296fd0314  jnz 0x0000708296FD552C
0000708296fd031a  movaps [r15+0x160], xmm14
0000708296fd0322  movaps xmm1, xmm7
0000708296fd0325  addpd xmm1, xmm11
0000708296fd032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000708296fd032f  ptest xmm12, xmm12
0000708296fd0335  jnz 0x0000708296FD566F
0000708296fd033b  movaps [r15+0x120], xmm1
0000708296fd0343  mov eax, 0x430920
0000708296fd0348  movups [r13+rax*1], xmm15
0000708296fd034e  mov eax, 0x430930
0000708296fd0353  movups [r13+rax*1], xmm13
0000708296fd0359  mov eax, 0x430940
0000708296fd035e  movups [r13+rax*1], xmm14
0000708296fd0364  mov eax, 0x430950
0000708296fd0369  movups [r13+rax*1], xmm1
0000708296fd036f  mov eax, [r15+0x108]
0000708296fd0376  sahf
0000708296fd0377  jnz 0x0000708296FD03A9
0000708296fd0379  cmp dword ptr [r15+0x318], 0x00
0000708296fd0381  jz 0x0000708296FDB900
0000708296fd0387  nop [rax+rax*1], ax
0000708296fd0390  nop [rax+rax*1], eax
0000708296fd0398  mov eax, 0x410444
0000708296fd039d  mov [r15+0x100], rax
0000708296fd03a4  jmp 0x0000708296DFE110
0000708296fd03a9  cmp dword ptr [r15+0x318], 0x00
0000708296fd03b1  jz 0x0000708296FD57E0
0000708296fd03b7  nop [rax+rax*1], ax
0000708296fd03c0  nop [rax+rax*1], eax
0000708296fd03c8  mov eax, 0x410278
0000708296fd03cd  mov [r15+0x100], rax
0000708296fd03d4  jmp 0x0000708296DFE110
0000708296fd03d9  int3
0000708296fd03da  call 0x0000708296EB52F0
0000708296fd03df  jmp 0x0000708296FCF016
0000708296fd03e4  call 0x0000708296EC4620
0000708296fd03e9  jmp 0x0000708296FCF023
0000708296fd03ee  call 0x0000708296EC33A0
0000708296fd03f3  jmp 0x0000708296FCF035
0000708296fd03f8  call 0x0000708296EC2120
0000708296fd03fd  jmp 0x0000708296FCF03F
0000708296fd0402  call 0x0000708296EC0860
0000708296fd0407  jmp 0x0000708296FCF067
0000708296fd040c  call 0x0000708296EBF5F0
0000708296fd0411  jmp 0x0000708296FCF073
0000708296fd0416  call 0x0000708296EC0860
0000708296fd041b  jmp 0x0000708296FCF0A5
0000708296fd0420  call 0x0000708296EBF5F0
0000708296fd0425  jmp 0x0000708296FCF0B1
0000708296fd042a  call 0x0000708296EC4740
0000708296fd042f  jmp 0x0000708296FCF0BE
0000708296fd0434  call 0x0000708296EB5400
0000708296fd0439  jmp 0x0000708296FCF0CB
0000708296fd043e  call 0x0000708296EB52F0
0000708296fd0443  jmp 0x0000708296FCF0D8
0000708296fd0448  call 0x0000708296EC4620
0000708296fd044d  jmp 0x0000708296FCF0E5
0000708296fd0452  call 0x0000708296EC0860
0000708296fd0457  jmp 0x0000708296FCF10D
0000708296fd045c  call 0x0000708296EBF5F0
0000708296fd0461  jmp 0x0000708296FCF119
0000708296fd0466  call 0x0000708296E09D70
0000708296fd046b  jmp 0x0000708296FCF11F
0000708296fd0470  call 0x0000708296EBE9C0
0000708296fd0475  jmp 0x0000708296FCF129
0000708296fd047a  call 0x0000708296EC0860
0000708296fd047f  jmp 0x0000708296FCF151
0000708296fd0484  call 0x0000708296EBF5F0
0000708296fd0489  jmp 0x0000708296FCF15D
0000708296fd048e  call 0x0000708296EBD750
0000708296fd0493  jmp 0x0000708296FCF16A
0000708296fd0498  call 0x0000708296EBC4E0
0000708296fd049d  jmp 0x0000708296FCF177
0000708296fd04a2  call 0x0000708296EC4740
0000708296fd04a7  jmp 0x0000708296FCF184
0000708296fd04ac  call 0x0000708296EB5400
0000708296fd04b1  jmp 0x0000708296FCF191
0000708296fd04b6  call 0x0000708296EB52F0
0000708296fd04bb  jmp 0x0000708296FCF19E
0000708296fd04c0  call 0x0000708296EC4620
0000708296fd04c5  jmp 0x0000708296FCF1AB
0000708296fd04ca  call 0x0000708296EC0860
0000708296fd04cf  jmp 0x0000708296FCF1BE
0000708296fd04d4  call 0x0000708296EBB270
0000708296fd04d9  jmp 0x0000708296FCF1CB
0000708296fd04de  call 0x0000708296EBA000
0000708296fd04e3  jmp 0x0000708296FCF1D8
0000708296fd04e8  call 0x0000708296EB8D90
0000708296fd04ed  jmp 0x0000708296FCF1E5
0000708296fd04f2  call 0x0000708296EB8A20
0000708296fd04f7  jmp 0x0000708296FCF1F2
0000708296fd04fc  call 0x0000708296EB5400
0000708296fd0501  jmp 0x0000708296FCF1FC
0000708296fd0506  call 0x0000708296EC2240
0000708296fd050b  jmp 0x0000708296FCF206
0000708296fd0510  call 0x0000708296EB52F0
0000708296fd0515  jmp 0x0000708296FCF210
0000708296fd051a  call 0x0000708296EC2120
0000708296fd051f  jmp 0x0000708296FCF21A
0000708296fd0524  call 0x0000708296EB77B0
0000708296fd0529  jmp 0x0000708296FCF224
0000708296fd052e  call 0x0000708296EB6550
0000708296fd0533  jmp 0x0000708296FCF22E
0000708296fd0538  call 0x0000708296EBFD50
0000708296fd053d  jmp 0x0000708296FCF240
0000708296fd0542  call 0x0000708296EB8EA0
0000708296fd0547  jmp 0x0000708296FCF24A
0000708296fd054c  call 0x0000708296EBFC30
0000708296fd0551  jmp 0x0000708296FCF257
0000708296fd0556  call 0x0000708296EB8D90
0000708296fd055b  jmp 0x0000708296FCF264
0000708296fd0560  call 0x0000708296EC2240
0000708296fd0565  jmp 0x0000708296FCF271
0000708296fd056a  call 0x0000708296EB5400
0000708296fd056f  jmp 0x0000708296FCF27E
0000708296fd0574  call 0x0000708296EB52F0
0000708296fd0579  jmp 0x0000708296FCF28B
0000708296fd057e  call 0x0000708296EC2120
0000708296fd0583  jmp 0x0000708296FCF298
0000708296fd0588  call 0x0000708296EB52F0
0000708296fd058d  jmp 0x0000708296FCF2AB
0000708296fd0592  call 0x0000708296EB52F0
0000708296fd0597  jmp 0x0000708296FCF2BE
0000708296fd059c  call 0x0000708296EB52F0
0000708296fd05a1  jmp 0x0000708296FCF2D1
0000708296fd05a6  call 0x0000708296EB52F0
0000708296fd05ab  jmp 0x0000708296FCF2E4
0000708296fd05b0  call 0x0000708296EC2240
0000708296fd05b5  jmp 0x0000708296FCF2F9
0000708296fd05ba  call 0x0000708296EC2240
0000708296fd05bf  jmp 0x0000708296FCF30C
0000708296fd05c4  call 0x0000708296EC2120
0000708296fd05c9  jmp 0x0000708296FCF319
0000708296fd05ce  call 0x0000708296EB52F0
0000708296fd05d3  jmp 0x0000708296FCF32C
0000708296fd05d8  call 0x0000708296EB52F0
0000708296fd05dd  jmp 0x0000708296FCF34F
0000708296fd05e2  call 0x0000708296EB52F0
0000708296fd05e7  jmp 0x0000708296FCF362
0000708296fd05ec  call 0x0000708296DFF540
0000708296fd05f1  jmp 0x0000708296FCF380
0000708296fd05f6  call 0x0000708296E08C20
0000708296fd05fb  jmp 0x0000708296FCF38A
0000708296fd0600  call 0x0000708296ED6600
0000708296fd0605  jmp 0x0000708296FCF396
0000708296fd060a  call 0x0000708296DFF540
0000708296fd060f  jmp 0x0000708296FCF3A6
0000708296fd0614  call 0x0000708296EC0370
0000708296fd0619  jmp 0x0000708296FCF3D4
0000708296fd061e  call 0x0000708296EBF100
0000708296fd0623  jmp 0x0000708296FCF3DD
0000708296fd0628  call 0x0000708296EC0370
0000708296fd062d  jmp 0x0000708296FCF43B
0000708296fd0632  call 0x0000708296EBF100
0000708296fd0637  jmp 0x0000708296FCF444
0000708296fd063c  call 0x0000708296EC0370
0000708296fd0641  jmp 0x0000708296FCF48B
0000708296fd0646  call 0x0000708296EBF100
0000708296fd064b  jmp 0x0000708296FCF494
0000708296fd0650  call 0x0000708296E0B720
0000708296fd0655  jmp 0x0000708296FCF4D7
0000708296fd065a  call 0x0000708296EB47C0
0000708296fd065f  jmp 0x0000708296FCF4EA
0000708296fd0664  call 0x0000708296E08B00
0000708296fd0669  jmp 0x0000708296FCF501
0000708296fd066e  call 0x0000708296DFF430
0000708296fd0673  jmp 0x0000708296FCF514
0000708296fd0678  call 0x0000708296DFF430
0000708296fd067d  jmp 0x0000708296FCF527
0000708296fd0682  sub rsp, 0x08
0000708296fd0686  push rax
0000708296fd0687  push rcx
0000708296fd0688  push rdx
0000708296fd0689  push rdi
0000708296fd068a  push rsi
0000708296fd068b  push r8
0000708296fd068d  push r9
0000708296fd068f  push r10
0000708296fd0691  push r11
0000708296fd0693  sub rsp, 0xF0
0000708296fd069a  vmovaps [rsp], xmm0
0000708296fd069f  vmovaps [rsp+0x10], xmm2
0000708296fd06a5  vmovaps [rsp+0x20], xmm3
0000708296fd06ab  vmovaps [rsp+0x30], xmm4
0000708296fd06b1  vmovaps [rsp+0x40], xmm5
0000708296fd06b7  vmovaps [rsp+0x50], xmm6
0000708296fd06bd  vmovaps [rsp+0x60], xmm7
0000708296fd06c3  vmovaps [rsp+0x70], xmm8
0000708296fd06c9  vmovaps [rsp+0x80], xmm9
0000708296fd06d2  vmovaps [rsp+0x90], xmm10
0000708296fd06db  vmovaps [rsp+0xA0], xmm11
0000708296fd06e4  vmovaps [rsp+0xB0], xmm12
0000708296fd06ed  vmovaps [rsp+0xC0], xmm13
0000708296fd06f6  vmovaps [rsp+0xD0], xmm14
0000708296fd06ff  vmovaps [rsp+0xE0], xmm15
0000708296fd0708  sub rsp, 0x30
0000708296fd070c  movaps [rsp], xmm1
0000708296fd0710  movaps [rsp+0x10], xmm15
0000708296fd0716  movaps [rsp+0x20], xmm14
0000708296fd071c  lea rdi, [rsp]
0000708296fd0720  mov esi, 0x00
0000708296fd0725  mov rax, 0x64BBC686C530
0000708296fd072f  call rax
0000708296fd0731  movaps xmm1, [rsp]
0000708296fd0735  add rsp, 0x30
0000708296fd0739  vmovaps xmm0, [rsp]
0000708296fd073e  vmovaps xmm2, [rsp+0x10]
0000708296fd0744  vmovaps xmm3, [rsp+0x20]
0000708296fd074a  vmovaps xmm4, [rsp+0x30]
0000708296fd0750  vmovaps xmm5, [rsp+0x40]
0000708296fd0756  vmovaps xmm6, [rsp+0x50]
0000708296fd075c  vmovaps xmm7, [rsp+0x60]
0000708296fd0762  vmovaps xmm8, [rsp+0x70]
0000708296fd0768  vmovaps xmm9, [rsp+0x80]
0000708296fd0771  vmovaps xmm10, [rsp+0x90]
0000708296fd077a  vmovaps xmm11, [rsp+0xA0]
0000708296fd0783  vmovaps xmm12, [rsp+0xB0]
0000708296fd078c  vmovaps xmm13, [rsp+0xC0]
0000708296fd0795  vmovaps xmm14, [rsp+0xD0]
0000708296fd079e  vmovaps xmm15, [rsp+0xE0]
0000708296fd07a7  add rsp, 0xF0
0000708296fd07ae  pop r11
0000708296fd07b0  pop r10
0000708296fd07b2  pop r9
0000708296fd07b4  pop r8
0000708296fd07b6  pop rsi
0000708296fd07b7  pop rdi
0000708296fd07b8  pop rdx
0000708296fd07b9  pop rcx
0000708296fd07ba  pop rax
0000708296fd07bb  add rsp, 0x08
0000708296fd07bf  jmp 0x0000708296FCF581
0000708296fd07c4  sub rsp, 0x08
0000708296fd07c8  push rax
0000708296fd07c9  push rcx
0000708296fd07ca  push rdx
0000708296fd07cb  push rdi
0000708296fd07cc  push rsi
0000708296fd07cd  push r8
0000708296fd07cf  push r9
0000708296fd07d1  push r10
0000708296fd07d3  push r11
0000708296fd07d5  sub rsp, 0xF0
0000708296fd07dc  vmovaps [rsp], xmm0
0000708296fd07e1  vmovaps [rsp+0x10], xmm1
0000708296fd07e7  vmovaps [rsp+0x20], xmm2
0000708296fd07ed  vmovaps [rsp+0x30], xmm3
0000708296fd07f3  vmovaps [rsp+0x40], xmm4
0000708296fd07f9  vmovaps [rsp+0x50], xmm5
0000708296fd07ff  vmovaps [rsp+0x60], xmm6
0000708296fd0805  vmovaps [rsp+0x70], xmm7
0000708296fd080b  vmovaps [rsp+0x80], xmm8
0000708296fd0814  vmovaps [rsp+0x90], xmm9
0000708296fd081d  vmovaps [rsp+0xA0], xmm10
0000708296fd0826  vmovaps [rsp+0xB0], xmm11
0000708296fd082f  vmovaps [rsp+0xC0], xmm12
0000708296fd0838  vmovaps [rsp+0xD0], xmm14
0000708296fd0841  vmovaps [rsp+0xE0], xmm15
0000708296fd084a  sub rsp, 0x30
0000708296fd084e  movaps [rsp], xmm13
0000708296fd0853  movaps [rsp+0x10], xmm1
0000708296fd0858  movaps [rsp+0x20], xmm14
0000708296fd085e  lea rdi, [rsp]
0000708296fd0862  mov esi, 0x00
0000708296fd0867  mov rax, 0x64BBC686C530
0000708296fd0871  call rax
0000708296fd0873  movaps xmm13, [rsp]
0000708296fd0878  add rsp, 0x30
0000708296fd087c  vmovaps xmm0, [rsp]
0000708296fd0881  vmovaps xmm1, [rsp+0x10]
0000708296fd0887  vmovaps xmm2, [rsp+0x20]
0000708296fd088d  vmovaps xmm3, [rsp+0x30]
0000708296fd0893  vmovaps xmm4, [rsp+0x40]
0000708296fd0899  vmovaps xmm5, [rsp+0x50]
0000708296fd089f  vmovaps xmm6, [rsp+0x60]
0000708296fd08a5  vmovaps xmm7, [rsp+0x70]
0000708296fd08ab  vmovaps xmm8, [rsp+0x80]
0000708296fd08b4  vmovaps xmm9, [rsp+0x90]
0000708296fd08bd  vmovaps xmm10, [rsp+0xA0]
0000708296fd08c6  vmovaps xmm11, [rsp+0xB0]
0000708296fd08cf  vmovaps xmm12, [rsp+0xC0]
0000708296fd08d8  vmovaps xmm14, [rsp+0xD0]
0000708296fd08e1  vmovaps xmm15, [rsp+0xE0]
0000708296fd08ea  add rsp, 0xF0
0000708296fd08f1  pop r11
0000708296fd08f3  pop r10
0000708296fd08f5  pop r9
0000708296fd08f7  pop r8
0000708296fd08f9  pop rsi
0000708296fd08fa  pop rdi
0000708296fd08fb  pop rdx
0000708296fd08fc  pop rcx
0000708296fd08fd  pop rax
0000708296fd08fe  add rsp, 0x08
0000708296fd0902  jmp 0x0000708296FCF5CF
0000708296fd0907  sub rsp, 0x08
0000708296fd090b  push rax
0000708296fd090c  push rcx
0000708296fd090d  push rdx
0000708296fd090e  push rdi
0000708296fd090f  push rsi
0000708296fd0910  push r8
0000708296fd0912  push r9
0000708296fd0914  push r10
0000708296fd0916  push r11
0000708296fd0918  sub rsp, 0xF0
0000708296fd091f  vmovaps [rsp], xmm0
0000708296fd0924  vmovaps [rsp+0x10], xmm1
0000708296fd092a  vmovaps [rsp+0x20], xmm2
0000708296fd0930  vmovaps [rsp+0x30], xmm3
0000708296fd0936  vmovaps [rsp+0x40], xmm4
0000708296fd093c  vmovaps [rsp+0x50], xmm5
0000708296fd0942  vmovaps [rsp+0x60], xmm6
0000708296fd0948  vmovaps [rsp+0x70], xmm7
0000708296fd094e  vmovaps [rsp+0x80], xmm8
0000708296fd0957  vmovaps [rsp+0x90], xmm9
0000708296fd0960  vmovaps [rsp+0xA0], xmm10
0000708296fd0969  vmovaps [rsp+0xB0], xmm11
0000708296fd0972  vmovaps [rsp+0xC0], xmm12
0000708296fd097b  vmovaps [rsp+0xD0], xmm13
0000708296fd0984  vmovaps [rsp+0xE0], xmm14
0000708296fd098d  sub rsp, 0x30
0000708296fd0991  movaps [rsp], xmm15
0000708296fd0996  movaps [rsp+0x10], xmm14
0000708296fd099c  movaps [rsp+0x20], xmm1
0000708296fd09a1  lea rdi, [rsp]
0000708296fd09a5  mov esi, 0x00
0000708296fd09aa  mov rax, 0x64BBC686C530
0000708296fd09b4  call rax
0000708296fd09b6  movaps xmm15, [rsp]
0000708296fd09bb  add rsp, 0x30
0000708296fd09bf  vmovaps xmm0, [rsp]
0000708296fd09c4  vmovaps xmm1, [rsp+0x10]
0000708296fd09ca  vmovaps xmm2, [rsp+0x20]
0000708296fd09d0  vmovaps xmm3, [rsp+0x30]
0000708296fd09d6  vmovaps xmm4, [rsp+0x40]
0000708296fd09dc  vmovaps xmm5, [rsp+0x50]
0000708296fd09e2  vmovaps xmm6, [rsp+0x60]
0000708296fd09e8  vmovaps xmm7, [rsp+0x70]
0000708296fd09ee  vmovaps xmm8, [rsp+0x80]
0000708296fd09f7  vmovaps xmm9, [rsp+0x90]
0000708296fd0a00  vmovaps xmm10, [rsp+0xA0]
0000708296fd0a09  vmovaps xmm11, [rsp+0xB0]
0000708296fd0a12  vmovaps xmm12, [rsp+0xC0]
0000708296fd0a1b  vmovaps xmm13, [rsp+0xD0]
0000708296fd0a24  vmovaps xmm14, [rsp+0xE0]
0000708296fd0a2d  add rsp, 0xF0
0000708296fd0a34  pop r11
0000708296fd0a36  pop r10
0000708296fd0a38  pop r9
0000708296fd0a3a  pop r8
0000708296fd0a3c  pop rsi
0000708296fd0a3d  pop rdi
0000708296fd0a3e  pop rdx
0000708296fd0a3f  pop rcx
0000708296fd0a40  pop rax
0000708296fd0a41  add rsp, 0x08
0000708296fd0a45  jmp 0x0000708296FCF617
0000708296fd0a4a  sub rsp, 0x08
0000708296fd0a4e  push rax
0000708296fd0a4f  push rcx
0000708296fd0a50  push rdx
0000708296fd0a51  push rdi
0000708296fd0a52  push rsi
0000708296fd0a53  push r8
0000708296fd0a55  push r9
0000708296fd0a57  push r10
0000708296fd0a59  push r11
0000708296fd0a5b  sub rsp, 0xF0
0000708296fd0a62  vmovaps [rsp], xmm0
0000708296fd0a67  vmovaps [rsp+0x10], xmm2
0000708296fd0a6d  vmovaps [rsp+0x20], xmm3
0000708296fd0a73  vmovaps [rsp+0x30], xmm4
0000708296fd0a79  vmovaps [rsp+0x40], xmm5
0000708296fd0a7f  vmovaps [rsp+0x50], xmm6
0000708296fd0a85  vmovaps [rsp+0x60], xmm7
0000708296fd0a8b  vmovaps [rsp+0x70], xmm8
0000708296fd0a91  vmovaps [rsp+0x80], xmm9
0000708296fd0a9a  vmovaps [rsp+0x90], xmm10
0000708296fd0aa3  vmovaps [rsp+0xA0], xmm11
0000708296fd0aac  vmovaps [rsp+0xB0], xmm12
0000708296fd0ab5  vmovaps [rsp+0xC0], xmm13
0000708296fd0abe  vmovaps [rsp+0xD0], xmm14
0000708296fd0ac7  vmovaps [rsp+0xE0], xmm15
0000708296fd0ad0  sub rsp, 0x30
0000708296fd0ad4  movaps [rsp], xmm1
0000708296fd0ad8  movaps [rsp+0x10], xmm14
0000708296fd0ade  movaps [rsp+0x20], xmm10
0000708296fd0ae4  lea rdi, [rsp]
0000708296fd0ae8  mov esi, 0x00
0000708296fd0aed  mov rax, 0x64BBC686C530
0000708296fd0af7  call rax
0000708296fd0af9  movaps xmm1, [rsp]
0000708296fd0afd  add rsp, 0x30
0000708296fd0b01  vmovaps xmm0, [rsp]
0000708296fd0b06  vmovaps xmm2, [rsp+0x10]
0000708296fd0b0c  vmovaps xmm3, [rsp+0x20]
0000708296fd0b12  vmovaps xmm4, [rsp+0x30]
0000708296fd0b18  vmovaps xmm5, [rsp+0x40]
0000708296fd0b1e  vmovaps xmm6, [rsp+0x50]
0000708296fd0b24  vmovaps xmm7, [rsp+0x60]
0000708296fd0b2a  vmovaps xmm8, [rsp+0x70]
0000708296fd0b30  vmovaps xmm9, [rsp+0x80]
0000708296fd0b39  vmovaps xmm10, [rsp+0x90]
0000708296fd0b42  vmovaps xmm11, [rsp+0xA0]
0000708296fd0b4b  vmovaps xmm12, [rsp+0xB0]
0000708296fd0b54  vmovaps xmm13, [rsp+0xC0]
0000708296fd0b5d  vmovaps xmm14, [rsp+0xD0]
0000708296fd0b66  vmovaps xmm15, [rsp+0xE0]
0000708296fd0b6f  add rsp, 0xF0
0000708296fd0b76  pop r11
0000708296fd0b78  pop r10
0000708296fd0b7a  pop r9
0000708296fd0b7c  pop r8
0000708296fd0b7e  pop rsi
0000708296fd0b7f  pop rdi
0000708296fd0b80  pop rdx
0000708296fd0b81  pop rcx
0000708296fd0b82  pop rax
0000708296fd0b83  add rsp, 0x08
0000708296fd0b87  jmp 0x0000708296FCF631
0000708296fd0b8c  sub rsp, 0x08
0000708296fd0b90  push rax
0000708296fd0b91  push rcx
0000708296fd0b92  push rdx
0000708296fd0b93  push rdi
0000708296fd0b94  push rsi
0000708296fd0b95  push r8
0000708296fd0b97  push r9
0000708296fd0b99  push r10
0000708296fd0b9b  push r11
0000708296fd0b9d  sub rsp, 0xF0
0000708296fd0ba4  vmovaps [rsp], xmm0
0000708296fd0ba9  vmovaps [rsp+0x10], xmm1
0000708296fd0baf  vmovaps [rsp+0x20], xmm2
0000708296fd0bb5  vmovaps [rsp+0x30], xmm3
0000708296fd0bbb  vmovaps [rsp+0x40], xmm4
0000708296fd0bc1  vmovaps [rsp+0x50], xmm5
0000708296fd0bc7  vmovaps [rsp+0x60], xmm6
0000708296fd0bcd  vmovaps [rsp+0x70], xmm7
0000708296fd0bd3  vmovaps [rsp+0x80], xmm8
0000708296fd0bdc  vmovaps [rsp+0x90], xmm9
0000708296fd0be5  vmovaps [rsp+0xA0], xmm10
0000708296fd0bee  vmovaps [rsp+0xB0], xmm11
0000708296fd0bf7  vmovaps [rsp+0xC0], xmm12
0000708296fd0c00  vmovaps [rsp+0xD0], xmm14
0000708296fd0c09  vmovaps [rsp+0xE0], xmm15
0000708296fd0c12  sub rsp, 0x30
0000708296fd0c16  movaps [rsp], xmm13
0000708296fd0c1b  movaps [rsp+0x10], xmm14
0000708296fd0c21  movaps [rsp+0x20], xmm2
0000708296fd0c26  lea rdi, [rsp]
0000708296fd0c2a  mov esi, 0x00
0000708296fd0c2f  mov rax, 0x64BBC686C530
0000708296fd0c39  call rax
0000708296fd0c3b  movaps xmm13, [rsp]
0000708296fd0c40  add rsp, 0x30
0000708296fd0c44  vmovaps xmm0, [rsp]
0000708296fd0c49  vmovaps xmm1, [rsp+0x10]
0000708296fd0c4f  vmovaps xmm2, [rsp+0x20]
0000708296fd0c55  vmovaps xmm3, [rsp+0x30]
0000708296fd0c5b  vmovaps xmm4, [rsp+0x40]
0000708296fd0c61  vmovaps xmm5, [rsp+0x50]
0000708296fd0c67  vmovaps xmm6, [rsp+0x60]
0000708296fd0c6d  vmovaps xmm7, [rsp+0x70]
0000708296fd0c73  vmovaps xmm8, [rsp+0x80]
0000708296fd0c7c  vmovaps xmm9, [rsp+0x90]
0000708296fd0c85  vmovaps xmm10, [rsp+0xA0]
0000708296fd0c8e  vmovaps xmm11, [rsp+0xB0]
0000708296fd0c97  vmovaps xmm12, [rsp+0xC0]
0000708296fd0ca0  vmovaps xmm14, [rsp+0xD0]
0000708296fd0ca9  vmovaps xmm15, [rsp+0xE0]
0000708296fd0cb2  add rsp, 0xF0
0000708296fd0cb9  pop r11
0000708296fd0cbb  pop r10
0000708296fd0cbd  pop r9
0000708296fd0cbf  pop r8
0000708296fd0cc1  pop rsi
0000708296fd0cc2  pop rdi
0000708296fd0cc3  pop rdx
0000708296fd0cc4  pop rcx
0000708296fd0cc5  pop rax
0000708296fd0cc6  add rsp, 0x08
0000708296fd0cca  jmp 0x0000708296FCF64C
0000708296fd0ccf  sub rsp, 0x08
0000708296fd0cd3  push rax
0000708296fd0cd4  push rcx
0000708296fd0cd5  push rdx
0000708296fd0cd6  push rdi
0000708296fd0cd7  push rsi
0000708296fd0cd8  push r8
0000708296fd0cda  push r9
0000708296fd0cdc  push r10
0000708296fd0cde  push r11
0000708296fd0ce0  sub rsp, 0xF0
0000708296fd0ce7  vmovaps [rsp], xmm0
0000708296fd0cec  vmovaps [rsp+0x10], xmm2
0000708296fd0cf2  vmovaps [rsp+0x20], xmm3
0000708296fd0cf8  vmovaps [rsp+0x30], xmm4
0000708296fd0cfe  vmovaps [rsp+0x40], xmm5
0000708296fd0d04  vmovaps [rsp+0x50], xmm6
0000708296fd0d0a  vmovaps [rsp+0x60], xmm7
0000708296fd0d10  vmovaps [rsp+0x70], xmm8
0000708296fd0d16  vmovaps [rsp+0x80], xmm9
0000708296fd0d1f  vmovaps [rsp+0x90], xmm10
0000708296fd0d28  vmovaps [rsp+0xA0], xmm11
0000708296fd0d31  vmovaps [rsp+0xB0], xmm12
0000708296fd0d3a  vmovaps [rsp+0xC0], xmm13
0000708296fd0d43  vmovaps [rsp+0xD0], xmm14
0000708296fd0d4c  vmovaps [rsp+0xE0], xmm15
0000708296fd0d55  sub rsp, 0x30
0000708296fd0d59  movaps [rsp], xmm1
0000708296fd0d5d  movaps [rsp+0x10], xmm10
0000708296fd0d63  movaps [rsp+0x20], xmm2
0000708296fd0d68  lea rdi, [rsp]
0000708296fd0d6c  mov esi, 0x00
0000708296fd0d71  mov rax, 0x64BBC686C530
0000708296fd0d7b  call rax
0000708296fd0d7d  movaps xmm1, [rsp]
0000708296fd0d81  add rsp, 0x30
0000708296fd0d85  vmovaps xmm0, [rsp]
0000708296fd0d8a  vmovaps xmm2, [rsp+0x10]
0000708296fd0d90  vmovaps xmm3, [rsp+0x20]
0000708296fd0d96  vmovaps xmm4, [rsp+0x30]
0000708296fd0d9c  vmovaps xmm5, [rsp+0x40]
0000708296fd0da2  vmovaps xmm6, [rsp+0x50]
0000708296fd0da8  vmovaps xmm7, [rsp+0x60]
0000708296fd0dae  vmovaps xmm8, [rsp+0x70]
0000708296fd0db4  vmovaps xmm9, [rsp+0x80]
0000708296fd0dbd  vmovaps xmm10, [rsp+0x90]
0000708296fd0dc6  vmovaps xmm11, [rsp+0xA0]
0000708296fd0dcf  vmovaps xmm12, [rsp+0xB0]
0000708296fd0dd8  vmovaps xmm13, [rsp+0xC0]
0000708296fd0de1  vmovaps xmm14, [rsp+0xD0]
0000708296fd0dea  vmovaps xmm15, [rsp+0xE0]
0000708296fd0df3  add rsp, 0xF0
0000708296fd0dfa  pop r11
0000708296fd0dfc  pop r10
0000708296fd0dfe  pop r9
0000708296fd0e00  pop r8
0000708296fd0e02  pop rsi
0000708296fd0e03  pop rdi
0000708296fd0e04  pop rdx
0000708296fd0e05  pop rcx
0000708296fd0e06  pop rax
0000708296fd0e07  add rsp, 0x08
0000708296fd0e0b  jmp 0x0000708296FCF6B4
0000708296fd0e10  sub rsp, 0x08
0000708296fd0e14  push rax
0000708296fd0e15  push rcx
0000708296fd0e16  push rdx
0000708296fd0e17  push rdi
0000708296fd0e18  push rsi
0000708296fd0e19  push r8
0000708296fd0e1b  push r9
0000708296fd0e1d  push r10
0000708296fd0e1f  push r11
0000708296fd0e21  sub rsp, 0xF0
0000708296fd0e28  vmovaps [rsp], xmm0
0000708296fd0e2d  vmovaps [rsp+0x10], xmm1
0000708296fd0e33  vmovaps [rsp+0x20], xmm2
0000708296fd0e39  vmovaps [rsp+0x30], xmm3
0000708296fd0e3f  vmovaps [rsp+0x40], xmm4
0000708296fd0e45  vmovaps [rsp+0x50], xmm5
0000708296fd0e4b  vmovaps [rsp+0x60], xmm6
0000708296fd0e51  vmovaps [rsp+0x70], xmm7
0000708296fd0e57  vmovaps [rsp+0x80], xmm8
0000708296fd0e60  vmovaps [rsp+0x90], xmm9
0000708296fd0e69  vmovaps [rsp+0xA0], xmm10
0000708296fd0e72  vmovaps [rsp+0xB0], xmm11
0000708296fd0e7b  vmovaps [rsp+0xC0], xmm12
0000708296fd0e84  vmovaps [rsp+0xD0], xmm13
0000708296fd0e8d  vmovaps [rsp+0xE0], xmm14
0000708296fd0e96  sub rsp, 0x30
0000708296fd0e9a  movaps [rsp], xmm15
0000708296fd0e9f  movaps [rsp+0x10], xmm10
0000708296fd0ea5  movaps [rsp+0x20], xmm2
0000708296fd0eaa  lea rdi, [rsp]
0000708296fd0eae  mov esi, 0x00
0000708296fd0eb3  mov rax, 0x64BBC686C530
0000708296fd0ebd  call rax
0000708296fd0ebf  movaps xmm15, [rsp]
0000708296fd0ec4  add rsp, 0x30
0000708296fd0ec8  vmovaps xmm0, [rsp]
0000708296fd0ecd  vmovaps xmm1, [rsp+0x10]
0000708296fd0ed3  vmovaps xmm2, [rsp+0x20]
0000708296fd0ed9  vmovaps xmm3, [rsp+0x30]
0000708296fd0edf  vmovaps xmm4, [rsp+0x40]
0000708296fd0ee5  vmovaps xmm5, [rsp+0x50]
0000708296fd0eeb  vmovaps xmm6, [rsp+0x60]
0000708296fd0ef1  vmovaps xmm7, [rsp+0x70]
0000708296fd0ef7  vmovaps xmm8, [rsp+0x80]
0000708296fd0f00  vmovaps xmm9, [rsp+0x90]
0000708296fd0f09  vmovaps xmm10, [rsp+0xA0]
0000708296fd0f12  vmovaps xmm11, [rsp+0xB0]
0000708296fd0f1b  vmovaps xmm12, [rsp+0xC0]
0000708296fd0f24  vmovaps xmm13, [rsp+0xD0]
0000708296fd0f2d  vmovaps xmm14, [rsp+0xE0]
0000708296fd0f36  add rsp, 0xF0
0000708296fd0f3d  pop r11
0000708296fd0f3f  pop r10
0000708296fd0f41  pop r9
0000708296fd0f43  pop r8
0000708296fd0f45  pop rsi
0000708296fd0f46  pop rdi
0000708296fd0f47  pop rdx
0000708296fd0f48  pop rcx
0000708296fd0f49  pop rax
0000708296fd0f4a  add rsp, 0x08
0000708296fd0f4e  jmp 0x0000708296FCF706
0000708296fd0f53  sub rsp, 0x08
0000708296fd0f57  push rax
0000708296fd0f58  push rcx
0000708296fd0f59  push rdx
0000708296fd0f5a  push rdi
0000708296fd0f5b  push rsi
0000708296fd0f5c  push r8
0000708296fd0f5e  push r9
0000708296fd0f60  push r10
0000708296fd0f62  push r11
0000708296fd0f64  sub rsp, 0xF0
0000708296fd0f6b  vmovaps [rsp], xmm0
0000708296fd0f70  vmovaps [rsp+0x10], xmm2
0000708296fd0f76  vmovaps [rsp+0x20], xmm3
0000708296fd0f7c  vmovaps [rsp+0x30], xmm4
0000708296fd0f82  vmovaps [rsp+0x40], xmm5
0000708296fd0f88  vmovaps [rsp+0x50], xmm6
0000708296fd0f8e  vmovaps [rsp+0x60], xmm7
0000708296fd0f94  vmovaps [rsp+0x70], xmm8
0000708296fd0f9a  vmovaps [rsp+0x80], xmm9
0000708296fd0fa3  vmovaps [rsp+0x90], xmm10
0000708296fd0fac  vmovaps [rsp+0xA0], xmm11
0000708296fd0fb5  vmovaps [rsp+0xB0], xmm12
0000708296fd0fbe  vmovaps [rsp+0xC0], xmm13
0000708296fd0fc7  vmovaps [rsp+0xD0], xmm14
0000708296fd0fd0  vmovaps [rsp+0xE0], xmm15
0000708296fd0fd9  sub rsp, 0x30
0000708296fd0fdd  movaps [rsp], xmm1
0000708296fd0fe1  movaps [rsp+0x10], xmm10
0000708296fd0fe7  movaps [rsp+0x20], xmm12
0000708296fd0fed  lea rdi, [rsp]
0000708296fd0ff1  mov esi, 0x00
0000708296fd0ff6  mov rax, 0x64BBC686C530
0000708296fd1000  call rax
0000708296fd1002  movaps xmm1, [rsp]
0000708296fd1006  add rsp, 0x30
0000708296fd100a  vmovaps xmm0, [rsp]
0000708296fd100f  vmovaps xmm2, [rsp+0x10]
0000708296fd1015  vmovaps xmm3, [rsp+0x20]
0000708296fd101b  vmovaps xmm4, [rsp+0x30]
0000708296fd1021  vmovaps xmm5, [rsp+0x40]
0000708296fd1027  vmovaps xmm6, [rsp+0x50]
0000708296fd102d  vmovaps xmm7, [rsp+0x60]
0000708296fd1033  vmovaps xmm8, [rsp+0x70]
0000708296fd1039  vmovaps xmm9, [rsp+0x80]
0000708296fd1042  vmovaps xmm10, [rsp+0x90]
0000708296fd104b  vmovaps xmm11, [rsp+0xA0]
0000708296fd1054  vmovaps xmm12, [rsp+0xB0]
0000708296fd105d  vmovaps xmm13, [rsp+0xC0]
0000708296fd1066  vmovaps xmm14, [rsp+0xD0]
0000708296fd106f  vmovaps xmm15, [rsp+0xE0]
0000708296fd1078  add rsp, 0xF0
0000708296fd107f  pop r11
0000708296fd1081  pop r10
0000708296fd1083  pop r9
0000708296fd1085  pop r8
0000708296fd1087  pop rsi
0000708296fd1088  pop rdi
0000708296fd1089  pop rdx
0000708296fd108a  pop rcx
0000708296fd108b  pop rax
0000708296fd108c  add rsp, 0x08
0000708296fd1090  jmp 0x0000708296FCF732
0000708296fd1095  sub rsp, 0x08
0000708296fd1099  push rax
0000708296fd109a  push rcx
0000708296fd109b  push rdx
0000708296fd109c  push rdi
0000708296fd109d  push rsi
0000708296fd109e  push r8
0000708296fd10a0  push r9
0000708296fd10a2  push r10
0000708296fd10a4  push r11
0000708296fd10a6  sub rsp, 0xF0
0000708296fd10ad  vmovaps [rsp], xmm0
0000708296fd10b2  vmovaps [rsp+0x10], xmm1
0000708296fd10b8  vmovaps [rsp+0x20], xmm2
0000708296fd10be  vmovaps [rsp+0x30], xmm3
0000708296fd10c4  vmovaps [rsp+0x40], xmm4
0000708296fd10ca  vmovaps [rsp+0x50], xmm5
0000708296fd10d0  vmovaps [rsp+0x60], xmm6
0000708296fd10d6  vmovaps [rsp+0x70], xmm7
0000708296fd10dc  vmovaps [rsp+0x80], xmm8
0000708296fd10e5  vmovaps [rsp+0x90], xmm9
0000708296fd10ee  vmovaps [rsp+0xA0], xmm10
0000708296fd10f7  vmovaps [rsp+0xB0], xmm11
0000708296fd1100  vmovaps [rsp+0xC0], xmm12
0000708296fd1109  vmovaps [rsp+0xD0], xmm13
0000708296fd1112  vmovaps [rsp+0xE0], xmm14
0000708296fd111b  sub rsp, 0x30
0000708296fd111f  movaps [rsp], xmm15
0000708296fd1124  movaps [rsp+0x10], xmm10
0000708296fd112a  movaps [rsp+0x20], xmm12
0000708296fd1130  lea rdi, [rsp]
0000708296fd1134  mov esi, 0x00
0000708296fd1139  mov rax, 0x64BBC686C530
0000708296fd1143  call rax
0000708296fd1145  movaps xmm15, [rsp]
0000708296fd114a  add rsp, 0x30
0000708296fd114e  vmovaps xmm0, [rsp]
0000708296fd1153  vmovaps xmm1, [rsp+0x10]
0000708296fd1159  vmovaps xmm2, [rsp+0x20]
0000708296fd115f  vmovaps xmm3, [rsp+0x30]
0000708296fd1165  vmovaps xmm4, [rsp+0x40]
0000708296fd116b  vmovaps xmm5, [rsp+0x50]
0000708296fd1171  vmovaps xmm6, [rsp+0x60]
0000708296fd1177  vmovaps xmm7, [rsp+0x70]
0000708296fd117d  vmovaps xmm8, [rsp+0x80]
0000708296fd1186  vmovaps xmm9, [rsp+0x90]
0000708296fd118f  vmovaps xmm10, [rsp+0xA0]
0000708296fd1198  vmovaps xmm11, [rsp+0xB0]
0000708296fd11a1  vmovaps xmm12, [rsp+0xC0]
0000708296fd11aa  vmovaps xmm13, [rsp+0xD0]
0000708296fd11b3  vmovaps xmm14, [rsp+0xE0]
0000708296fd11bc  add rsp, 0xF0
0000708296fd11c3  pop r11
0000708296fd11c5  pop r10
0000708296fd11c7  pop r9
0000708296fd11c9  pop r8
0000708296fd11cb  pop rsi
0000708296fd11cc  pop rdi
0000708296fd11cd  pop rdx
0000708296fd11ce  pop rcx
0000708296fd11cf  pop rax
0000708296fd11d0  add rsp, 0x08
0000708296fd11d4  jmp 0x0000708296FCF75E
0000708296fd11d9  call 0x0000708296DFF430
0000708296fd11de  jmp 0x0000708296FCF7EE
0000708296fd11e3  call 0x0000708296DFF430
0000708296fd11e8  jmp 0x0000708296FCF801
0000708296fd11ed  sub rsp, 0x08
0000708296fd11f1  push rax
0000708296fd11f2  push rcx
0000708296fd11f3  push rdx
0000708296fd11f4  push rdi
0000708296fd11f5  push rsi
0000708296fd11f6  push r8
0000708296fd11f8  push r9
0000708296fd11fa  push r10
0000708296fd11fc  push r11
0000708296fd11fe  sub rsp, 0xF0
0000708296fd1205  vmovaps [rsp], xmm0
0000708296fd120a  vmovaps [rsp+0x10], xmm2
0000708296fd1210  vmovaps [rsp+0x20], xmm3
0000708296fd1216  vmovaps [rsp+0x30], xmm4
0000708296fd121c  vmovaps [rsp+0x40], xmm5
0000708296fd1222  vmovaps [rsp+0x50], xmm6
0000708296fd1228  vmovaps [rsp+0x60], xmm7
0000708296fd122e  vmovaps [rsp+0x70], xmm8
0000708296fd1234  vmovaps [rsp+0x80], xmm9
0000708296fd123d  vmovaps [rsp+0x90], xmm10
0000708296fd1246  vmovaps [rsp+0xA0], xmm11
0000708296fd124f  vmovaps [rsp+0xB0], xmm12
0000708296fd1258  vmovaps [rsp+0xC0], xmm13
0000708296fd1261  vmovaps [rsp+0xD0], xmm14
0000708296fd126a  vmovaps [rsp+0xE0], xmm15
0000708296fd1273  sub rsp, 0x30
0000708296fd1277  movaps [rsp], xmm1
0000708296fd127b  movaps [rsp+0x10], xmm13
0000708296fd1281  movaps [rsp+0x20], xmm2
0000708296fd1286  lea rdi, [rsp]
0000708296fd128a  mov esi, 0x00
0000708296fd128f  mov rax, 0x64BBC686C530
0000708296fd1299  call rax
0000708296fd129b  movaps xmm1, [rsp]
0000708296fd129f  add rsp, 0x30
0000708296fd12a3  vmovaps xmm0, [rsp]
0000708296fd12a8  vmovaps xmm2, [rsp+0x10]
0000708296fd12ae  vmovaps xmm3, [rsp+0x20]
0000708296fd12b4  vmovaps xmm4, [rsp+0x30]
0000708296fd12ba  vmovaps xmm5, [rsp+0x40]
0000708296fd12c0  vmovaps xmm6, [rsp+0x50]
0000708296fd12c6  vmovaps xmm7, [rsp+0x60]
0000708296fd12cc  vmovaps xmm8, [rsp+0x70]
0000708296fd12d2  vmovaps xmm9, [rsp+0x80]
0000708296fd12db  vmovaps xmm10, [rsp+0x90]
0000708296fd12e4  vmovaps xmm11, [rsp+0xA0]
0000708296fd12ed  vmovaps xmm12, [rsp+0xB0]
0000708296fd12f6  vmovaps xmm13, [rsp+0xC0]
0000708296fd12ff  vmovaps xmm14, [rsp+0xD0]
0000708296fd1308  vmovaps xmm15, [rsp+0xE0]
0000708296fd1311  add rsp, 0xF0
0000708296fd1318  pop r11
0000708296fd131a  pop r10
0000708296fd131c  pop r9
0000708296fd131e  pop r8
0000708296fd1320  pop rsi
0000708296fd1321  pop rdi
0000708296fd1322  pop rdx
0000708296fd1323  pop rcx
0000708296fd1324  pop rax
0000708296fd1325  add rsp, 0x08
0000708296fd1329  jmp 0x0000708296FCF82C
0000708296fd132e  call 0x0000708296E0E760
0000708296fd1333  jmp 0x0000708296FCF839
0000708296fd1338  sub rsp, 0x08
0000708296fd133c  push rax
0000708296fd133d  push rcx
0000708296fd133e  push rdx
0000708296fd133f  push rdi
0000708296fd1340  push rsi
0000708296fd1341  push r8
0000708296fd1343  push r9
0000708296fd1345  push r10
0000708296fd1347  push r11
0000708296fd1349  sub rsp, 0xF0
0000708296fd1350  vmovaps [rsp], xmm0
0000708296fd1355  vmovaps [rsp+0x10], xmm1
0000708296fd135b  vmovaps [rsp+0x20], xmm2
0000708296fd1361  vmovaps [rsp+0x30], xmm3
0000708296fd1367  vmovaps [rsp+0x40], xmm4
0000708296fd136d  vmovaps [rsp+0x50], xmm5
0000708296fd1373  vmovaps [rsp+0x60], xmm6
0000708296fd1379  vmovaps [rsp+0x70], xmm7
0000708296fd137f  vmovaps [rsp+0x80], xmm8
0000708296fd1388  vmovaps [rsp+0x90], xmm9
0000708296fd1391  vmovaps [rsp+0xA0], xmm10
0000708296fd139a  vmovaps [rsp+0xB0], xmm11
0000708296fd13a3  vmovaps [rsp+0xC0], xmm12
0000708296fd13ac  vmovaps [rsp+0xD0], xmm14
0000708296fd13b5  vmovaps [rsp+0xE0], xmm15
0000708296fd13be  sub rsp, 0x30
0000708296fd13c2  movaps [rsp], xmm13
0000708296fd13c7  movaps [rsp+0x10], xmm2
0000708296fd13cc  movaps [rsp+0x20], xmm1
0000708296fd13d1  lea rdi, [rsp]
0000708296fd13d5  mov esi, 0x00
0000708296fd13da  mov rax, 0x64BBC686C530
0000708296fd13e4  call rax
0000708296fd13e6  movaps xmm13, [rsp]
0000708296fd13eb  add rsp, 0x30
0000708296fd13ef  vmovaps xmm0, [rsp]
0000708296fd13f4  vmovaps xmm1, [rsp+0x10]
0000708296fd13fa  vmovaps xmm2, [rsp+0x20]
0000708296fd1400  vmovaps xmm3, [rsp+0x30]
0000708296fd1406  vmovaps xmm4, [rsp+0x40]
0000708296fd140c  vmovaps xmm5, [rsp+0x50]
0000708296fd1412  vmovaps xmm6, [rsp+0x60]
0000708296fd1418  vmovaps xmm7, [rsp+0x70]
0000708296fd141e  vmovaps xmm8, [rsp+0x80]
0000708296fd1427  vmovaps xmm9, [rsp+0x90]
0000708296fd1430  vmovaps xmm10, [rsp+0xA0]
0000708296fd1439  vmovaps xmm11, [rsp+0xB0]
0000708296fd1442  vmovaps xmm12, [rsp+0xC0]
0000708296fd144b  vmovaps xmm14, [rsp+0xD0]
0000708296fd1454  vmovaps xmm15, [rsp+0xE0]
0000708296fd145d  add rsp, 0xF0
0000708296fd1464  pop r11
0000708296fd1466  pop r10
0000708296fd1468  pop r9
0000708296fd146a  pop r8
0000708296fd146c  pop rsi
0000708296fd146d  pop rdi
0000708296fd146e  pop rdx
0000708296fd146f  pop rcx
0000708296fd1470  pop rax
0000708296fd1471  add rsp, 0x08
0000708296fd1475  jmp 0x0000708296FCF878
0000708296fd147a  sub rsp, 0x08
0000708296fd147e  push rax
0000708296fd147f  push rcx
0000708296fd1480  push rdx
0000708296fd1481  push rdi
0000708296fd1482  push rsi
0000708296fd1483  push r8
0000708296fd1485  push r9
0000708296fd1487  push r10
0000708296fd1489  push r11
0000708296fd148b  sub rsp, 0xF0
0000708296fd1492  vmovaps [rsp], xmm0
0000708296fd1497  vmovaps [rsp+0x10], xmm2
0000708296fd149d  vmovaps [rsp+0x20], xmm3
0000708296fd14a3  vmovaps [rsp+0x30], xmm4
0000708296fd14a9  vmovaps [rsp+0x40], xmm5
0000708296fd14af  vmovaps [rsp+0x50], xmm6
0000708296fd14b5  vmovaps [rsp+0x60], xmm7
0000708296fd14bb  vmovaps [rsp+0x70], xmm8
0000708296fd14c1  vmovaps [rsp+0x80], xmm9
0000708296fd14ca  vmovaps [rsp+0x90], xmm10
0000708296fd14d3  vmovaps [rsp+0xA0], xmm11
0000708296fd14dc  vmovaps [rsp+0xB0], xmm12
0000708296fd14e5  vmovaps [rsp+0xC0], xmm13
0000708296fd14ee  vmovaps [rsp+0xD0], xmm14
0000708296fd14f7  vmovaps [rsp+0xE0], xmm15
0000708296fd1500  sub rsp, 0x30
0000708296fd1504  movaps [rsp], xmm1
0000708296fd1508  movaps [rsp+0x10], xmm15
0000708296fd150e  movaps [rsp+0x20], xmm2
0000708296fd1513  lea rdi, [rsp]
0000708296fd1517  mov esi, 0x00
0000708296fd151c  mov rax, 0x64BBC686C530
0000708296fd1526  call rax
0000708296fd1528  movaps xmm1, [rsp]
0000708296fd152c  add rsp, 0x30
0000708296fd1530  vmovaps xmm0, [rsp]
0000708296fd1535  vmovaps xmm2, [rsp+0x10]
0000708296fd153b  vmovaps xmm3, [rsp+0x20]
0000708296fd1541  vmovaps xmm4, [rsp+0x30]
0000708296fd1547  vmovaps xmm5, [rsp+0x40]
0000708296fd154d  vmovaps xmm6, [rsp+0x50]
0000708296fd1553  vmovaps xmm7, [rsp+0x60]
0000708296fd1559  vmovaps xmm8, [rsp+0x70]
0000708296fd155f  vmovaps xmm9, [rsp+0x80]
0000708296fd1568  vmovaps xmm10, [rsp+0x90]
0000708296fd1571  vmovaps xmm11, [rsp+0xA0]
0000708296fd157a  vmovaps xmm12, [rsp+0xB0]
0000708296fd1583  vmovaps xmm13, [rsp+0xC0]
0000708296fd158c  vmovaps xmm14, [rsp+0xD0]
0000708296fd1595  vmovaps xmm15, [rsp+0xE0]
0000708296fd159e  add rsp, 0xF0
0000708296fd15a5  pop r11
0000708296fd15a7  pop r10
0000708296fd15a9  pop r9
0000708296fd15ab  pop r8
0000708296fd15ad  pop rsi
0000708296fd15ae  pop rdi
0000708296fd15af  pop rdx
0000708296fd15b0  pop rcx
0000708296fd15b1  pop rax
0000708296fd15b2  add rsp, 0x08
0000708296fd15b6  jmp 0x0000708296FCF8AC
0000708296fd15bb  sub rsp, 0x08
0000708296fd15bf  push rax
0000708296fd15c0  push rcx
0000708296fd15c1  push rdx
0000708296fd15c2  push rdi
0000708296fd15c3  push rsi
0000708296fd15c4  push r8
0000708296fd15c6  push r9
0000708296fd15c8  push r10
0000708296fd15ca  push r11
0000708296fd15cc  sub rsp, 0xF0
0000708296fd15d3  vmovaps [rsp], xmm0
0000708296fd15d8  vmovaps [rsp+0x10], xmm1
0000708296fd15de  vmovaps [rsp+0x20], xmm2
0000708296fd15e4  vmovaps [rsp+0x30], xmm3
0000708296fd15ea  vmovaps [rsp+0x40], xmm4
0000708296fd15f0  vmovaps [rsp+0x50], xmm5
0000708296fd15f6  vmovaps [rsp+0x60], xmm6
0000708296fd15fc  vmovaps [rsp+0x70], xmm7
0000708296fd1602  vmovaps [rsp+0x80], xmm8
0000708296fd160b  vmovaps [rsp+0x90], xmm9
0000708296fd1614  vmovaps [rsp+0xA0], xmm10
0000708296fd161d  vmovaps [rsp+0xB0], xmm11
0000708296fd1626  vmovaps [rsp+0xC0], xmm12
0000708296fd162f  vmovaps [rsp+0xD0], xmm13
0000708296fd1638  vmovaps [rsp+0xE0], xmm15
0000708296fd1641  sub rsp, 0x30
0000708296fd1645  movaps [rsp], xmm14
0000708296fd164a  movaps [rsp+0x10], xmm2
0000708296fd164f  movaps [rsp+0x20], xmm15
0000708296fd1655  lea rdi, [rsp]
0000708296fd1659  mov esi, 0x00
0000708296fd165e  mov rax, 0x64BBC686C530
0000708296fd1668  call rax
0000708296fd166a  movaps xmm14, [rsp]
0000708296fd166f  add rsp, 0x30
0000708296fd1673  vmovaps xmm0, [rsp]
0000708296fd1678  vmovaps xmm1, [rsp+0x10]
0000708296fd167e  vmovaps xmm2, [rsp+0x20]
0000708296fd1684  vmovaps xmm3, [rsp+0x30]
0000708296fd168a  vmovaps xmm4, [rsp+0x40]
0000708296fd1690  vmovaps xmm5, [rsp+0x50]
0000708296fd1696  vmovaps xmm6, [rsp+0x60]
0000708296fd169c  vmovaps xmm7, [rsp+0x70]
0000708296fd16a2  vmovaps xmm8, [rsp+0x80]
0000708296fd16ab  vmovaps xmm9, [rsp+0x90]
0000708296fd16b4  vmovaps xmm10, [rsp+0xA0]
0000708296fd16bd  vmovaps xmm11, [rsp+0xB0]
0000708296fd16c6  vmovaps xmm12, [rsp+0xC0]
0000708296fd16cf  vmovaps xmm13, [rsp+0xD0]
0000708296fd16d8  vmovaps xmm15, [rsp+0xE0]
0000708296fd16e1  add rsp, 0xF0
0000708296fd16e8  pop r11
0000708296fd16ea  pop r10
0000708296fd16ec  pop r9
0000708296fd16ee  pop r8
0000708296fd16f0  pop rsi
0000708296fd16f1  pop rdi
0000708296fd16f2  pop rdx
0000708296fd16f3  pop rcx
0000708296fd16f4  pop rax
0000708296fd16f5  add rsp, 0x08
0000708296fd16f9  jmp 0x0000708296FCF8E7
0000708296fd16fe  sub rsp, 0x08
0000708296fd1702  push rax
0000708296fd1703  push rcx
0000708296fd1704  push rdx
0000708296fd1705  push rdi
0000708296fd1706  push rsi
0000708296fd1707  push r8
0000708296fd1709  push r9
0000708296fd170b  push r10
0000708296fd170d  push r11
0000708296fd170f  sub rsp, 0xF0
0000708296fd1716  vmovaps [rsp], xmm0
0000708296fd171b  vmovaps [rsp+0x10], xmm1
0000708296fd1721  vmovaps [rsp+0x20], xmm2
0000708296fd1727  vmovaps [rsp+0x30], xmm3
0000708296fd172d  vmovaps [rsp+0x40], xmm4
0000708296fd1733  vmovaps [rsp+0x50], xmm5
0000708296fd1739  vmovaps [rsp+0x60], xmm6
0000708296fd173f  vmovaps [rsp+0x70], xmm7
0000708296fd1745  vmovaps [rsp+0x80], xmm8
0000708296fd174e  vmovaps [rsp+0x90], xmm9
0000708296fd1757  vmovaps [rsp+0xA0], xmm10
0000708296fd1760  vmovaps [rsp+0xB0], xmm11
0000708296fd1769  vmovaps [rsp+0xC0], xmm12
0000708296fd1772  vmovaps [rsp+0xD0], xmm13
0000708296fd177b  vmovaps [rsp+0xE0], xmm14
0000708296fd1784  sub rsp, 0x30
0000708296fd1788  movaps [rsp], xmm15
0000708296fd178d  movaps [rsp+0x10], xmm2
0000708296fd1792  movaps [rsp+0x20], xmm1
0000708296fd1797  lea rdi, [rsp]
0000708296fd179b  mov esi, 0x00
0000708296fd17a0  mov rax, 0x64BBC686C530
0000708296fd17aa  call rax
0000708296fd17ac  movaps xmm15, [rsp]
0000708296fd17b1  add rsp, 0x30
0000708296fd17b5  vmovaps xmm0, [rsp]
0000708296fd17ba  vmovaps xmm1, [rsp+0x10]
0000708296fd17c0  vmovaps xmm2, [rsp+0x20]
0000708296fd17c6  vmovaps xmm3, [rsp+0x30]
0000708296fd17cc  vmovaps xmm4, [rsp+0x40]
0000708296fd17d2  vmovaps xmm5, [rsp+0x50]
0000708296fd17d8  vmovaps xmm6, [rsp+0x60]
0000708296fd17de  vmovaps xmm7, [rsp+0x70]
0000708296fd17e4  vmovaps xmm8, [rsp+0x80]
0000708296fd17ed  vmovaps xmm9, [rsp+0x90]
0000708296fd17f6  vmovaps xmm10, [rsp+0xA0]
0000708296fd17ff  vmovaps xmm11, [rsp+0xB0]
0000708296fd1808  vmovaps xmm12, [rsp+0xC0]
0000708296fd1811  vmovaps xmm13, [rsp+0xD0]
0000708296fd181a  vmovaps xmm14, [rsp+0xE0]
0000708296fd1823  add rsp, 0xF0
0000708296fd182a  pop r11
0000708296fd182c  pop r10
0000708296fd182e  pop r9
0000708296fd1830  pop r8
0000708296fd1832  pop rsi
0000708296fd1833  pop rdi
0000708296fd1834  pop rdx
0000708296fd1835  pop rcx
0000708296fd1836  pop rax
0000708296fd1837  add rsp, 0x08
0000708296fd183b  jmp 0x0000708296FCF923
0000708296fd1840  call 0x0000708296DFF430
0000708296fd1845  jmp 0x0000708296FCF930
0000708296fd184a  sub rsp, 0x08
0000708296fd184e  push rax
0000708296fd184f  push rcx
0000708296fd1850  push rdx
0000708296fd1851  push rdi
0000708296fd1852  push rsi
0000708296fd1853  push r8
0000708296fd1855  push r9
0000708296fd1857  push r10
0000708296fd1859  push r11
0000708296fd185b  sub rsp, 0xF0
0000708296fd1862  vmovaps [rsp], xmm0
0000708296fd1867  vmovaps [rsp+0x10], xmm1
0000708296fd186d  vmovaps [rsp+0x20], xmm3
0000708296fd1873  vmovaps [rsp+0x30], xmm4
0000708296fd1879  vmovaps [rsp+0x40], xmm5
0000708296fd187f  vmovaps [rsp+0x50], xmm6
0000708296fd1885  vmovaps [rsp+0x60], xmm7
0000708296fd188b  vmovaps [rsp+0x70], xmm8
0000708296fd1891  vmovaps [rsp+0x80], xmm9
0000708296fd189a  vmovaps [rsp+0x90], xmm10
0000708296fd18a3  vmovaps [rsp+0xA0], xmm11
0000708296fd18ac  vmovaps [rsp+0xB0], xmm12
0000708296fd18b5  vmovaps [rsp+0xC0], xmm13
0000708296fd18be  vmovaps [rsp+0xD0], xmm14
0000708296fd18c7  vmovaps [rsp+0xE0], xmm15
0000708296fd18d0  sub rsp, 0x30
0000708296fd18d4  movaps [rsp], xmm2
0000708296fd18d8  movaps [rsp+0x10], xmm1
0000708296fd18dd  movaps [rsp+0x20], xmm14
0000708296fd18e3  lea rdi, [rsp]
0000708296fd18e7  mov esi, 0x00
0000708296fd18ec  mov rax, 0x64BBC686C530
0000708296fd18f6  call rax
0000708296fd18f8  movaps xmm2, [rsp]
0000708296fd18fc  add rsp, 0x30
0000708296fd1900  vmovaps xmm0, [rsp]
0000708296fd1905  vmovaps xmm1, [rsp+0x10]
0000708296fd190b  vmovaps xmm3, [rsp+0x20]
0000708296fd1911  vmovaps xmm4, [rsp+0x30]
0000708296fd1917  vmovaps xmm5, [rsp+0x40]
0000708296fd191d  vmovaps xmm6, [rsp+0x50]
0000708296fd1923  vmovaps xmm7, [rsp+0x60]
0000708296fd1929  vmovaps xmm8, [rsp+0x70]
0000708296fd192f  vmovaps xmm9, [rsp+0x80]
0000708296fd1938  vmovaps xmm10, [rsp+0x90]
0000708296fd1941  vmovaps xmm11, [rsp+0xA0]
0000708296fd194a  vmovaps xmm12, [rsp+0xB0]
0000708296fd1953  vmovaps xmm13, [rsp+0xC0]
0000708296fd195c  vmovaps xmm14, [rsp+0xD0]
0000708296fd1965  vmovaps xmm15, [rsp+0xE0]
0000708296fd196e  add rsp, 0xF0
0000708296fd1975  pop r11
0000708296fd1977  pop r10
0000708296fd1979  pop r9
0000708296fd197b  pop r8
0000708296fd197d  pop rsi
0000708296fd197e  pop rdi
0000708296fd197f  pop rdx
0000708296fd1980  pop rcx
0000708296fd1981  pop rax
0000708296fd1982  add rsp, 0x08
0000708296fd1986  jmp 0x0000708296FCF96D
0000708296fd198b  sub rsp, 0x08
0000708296fd198f  push rax
0000708296fd1990  push rcx
0000708296fd1991  push rdx
0000708296fd1992  push rdi
0000708296fd1993  push rsi
0000708296fd1994  push r8
0000708296fd1996  push r9
0000708296fd1998  push r10
0000708296fd199a  push r11
0000708296fd199c  sub rsp, 0xF0
0000708296fd19a3  vmovaps [rsp], xmm0
0000708296fd19a8  vmovaps [rsp+0x10], xmm1
0000708296fd19ae  vmovaps [rsp+0x20], xmm2
0000708296fd19b4  vmovaps [rsp+0x30], xmm3
0000708296fd19ba  vmovaps [rsp+0x40], xmm4
0000708296fd19c0  vmovaps [rsp+0x50], xmm5
0000708296fd19c6  vmovaps [rsp+0x60], xmm6
0000708296fd19cc  vmovaps [rsp+0x70], xmm7
0000708296fd19d2  vmovaps [rsp+0x80], xmm8
0000708296fd19db  vmovaps [rsp+0x90], xmm9
0000708296fd19e4  vmovaps [rsp+0xA0], xmm10
0000708296fd19ed  vmovaps [rsp+0xB0], xmm11
0000708296fd19f6  vmovaps [rsp+0xC0], xmm12
0000708296fd19ff  vmovaps [rsp+0xD0], xmm13
0000708296fd1a08  vmovaps [rsp+0xE0], xmm14
0000708296fd1a11  sub rsp, 0x30
0000708296fd1a15  movaps [rsp], xmm15
0000708296fd1a1a  movaps [rsp+0x10], xmm14
0000708296fd1a20  movaps [rsp+0x20], xmm1
0000708296fd1a25  lea rdi, [rsp]
0000708296fd1a29  mov esi, 0x00
0000708296fd1a2e  mov rax, 0x64BBC686C530
0000708296fd1a38  call rax
0000708296fd1a3a  movaps xmm15, [rsp]
0000708296fd1a3f  add rsp, 0x30
0000708296fd1a43  vmovaps xmm0, [rsp]
0000708296fd1a48  vmovaps xmm1, [rsp+0x10]
0000708296fd1a4e  vmovaps xmm2, [rsp+0x20]
0000708296fd1a54  vmovaps xmm3, [rsp+0x30]
0000708296fd1a5a  vmovaps xmm4, [rsp+0x40]
0000708296fd1a60  vmovaps xmm5, [rsp+0x50]
0000708296fd1a66  vmovaps xmm6, [rsp+0x60]
0000708296fd1a6c  vmovaps xmm7, [rsp+0x70]
0000708296fd1a72  vmovaps xmm8, [rsp+0x80]
0000708296fd1a7b  vmovaps xmm9, [rsp+0x90]
0000708296fd1a84  vmovaps xmm10, [rsp+0xA0]
0000708296fd1a8d  vmovaps xmm11, [rsp+0xB0]
0000708296fd1a96  vmovaps xmm12, [rsp+0xC0]
0000708296fd1a9f  vmovaps xmm13, [rsp+0xD0]
0000708296fd1aa8  vmovaps xmm14, [rsp+0xE0]
0000708296fd1ab1  add rsp, 0xF0
0000708296fd1ab8  pop r11
0000708296fd1aba  pop r10
0000708296fd1abc  pop r9
0000708296fd1abe  pop r8
0000708296fd1ac0  pop rsi
0000708296fd1ac1  pop rdi
0000708296fd1ac2  pop rdx
0000708296fd1ac3  pop rcx
0000708296fd1ac4  pop rax
0000708296fd1ac5  add rsp, 0x08
0000708296fd1ac9  jmp 0x0000708296FCF9E7
0000708296fd1ace  call 0x0000708296DFF430
0000708296fd1ad3  jmp 0x0000708296FCF9F4
0000708296fd1ad8  sub rsp, 0x08
0000708296fd1adc  push rax
0000708296fd1add  push rcx
0000708296fd1ade  push rdx
0000708296fd1adf  push rdi
0000708296fd1ae0  push rsi
0000708296fd1ae1  push r8
0000708296fd1ae3  push r9
0000708296fd1ae5  push r10
0000708296fd1ae7  push r11
0000708296fd1ae9  sub rsp, 0xF0
0000708296fd1af0  vmovaps [rsp], xmm0
0000708296fd1af5  vmovaps [rsp+0x10], xmm1
0000708296fd1afb  vmovaps [rsp+0x20], xmm2
0000708296fd1b01  vmovaps [rsp+0x30], xmm3
0000708296fd1b07  vmovaps [rsp+0x40], xmm4
0000708296fd1b0d  vmovaps [rsp+0x50], xmm5
0000708296fd1b13  vmovaps [rsp+0x60], xmm6
0000708296fd1b19  vmovaps [rsp+0x70], xmm7
0000708296fd1b1f  vmovaps [rsp+0x80], xmm8
0000708296fd1b28  vmovaps [rsp+0x90], xmm9
0000708296fd1b31  vmovaps [rsp+0xA0], xmm10
0000708296fd1b3a  vmovaps [rsp+0xB0], xmm11
0000708296fd1b43  vmovaps [rsp+0xC0], xmm12
0000708296fd1b4c  vmovaps [rsp+0xD0], xmm13
0000708296fd1b55  vmovaps [rsp+0xE0], xmm15
0000708296fd1b5e  sub rsp, 0x30
0000708296fd1b62  movaps [rsp], xmm14
0000708296fd1b67  movaps [rsp+0x10], xmm13
0000708296fd1b6d  movaps [rsp+0x20], xmm1
0000708296fd1b72  lea rdi, [rsp]
0000708296fd1b76  mov esi, 0x00
0000708296fd1b7b  mov rax, 0x64BBC686C530
0000708296fd1b85  call rax
0000708296fd1b87  movaps xmm14, [rsp]
0000708296fd1b8c  add rsp, 0x30
0000708296fd1b90  vmovaps xmm0, [rsp]
0000708296fd1b95  vmovaps xmm1, [rsp+0x10]
0000708296fd1b9b  vmovaps xmm2, [rsp+0x20]
0000708296fd1ba1  vmovaps xmm3, [rsp+0x30]
0000708296fd1ba7  vmovaps xmm4, [rsp+0x40]
0000708296fd1bad  vmovaps xmm5, [rsp+0x50]
0000708296fd1bb3  vmovaps xmm6, [rsp+0x60]
0000708296fd1bb9  vmovaps xmm7, [rsp+0x70]
0000708296fd1bbf  vmovaps xmm8, [rsp+0x80]
0000708296fd1bc8  vmovaps xmm9, [rsp+0x90]
0000708296fd1bd1  vmovaps xmm10, [rsp+0xA0]
0000708296fd1bda  vmovaps xmm11, [rsp+0xB0]
0000708296fd1be3  vmovaps xmm12, [rsp+0xC0]
0000708296fd1bec  vmovaps xmm13, [rsp+0xD0]
0000708296fd1bf5  vmovaps xmm15, [rsp+0xE0]
0000708296fd1bfe  add rsp, 0xF0
0000708296fd1c05  pop r11
0000708296fd1c07  pop r10
0000708296fd1c09  pop r9
0000708296fd1c0b  pop r8
0000708296fd1c0d  pop rsi
0000708296fd1c0e  pop rdi
0000708296fd1c0f  pop rdx
0000708296fd1c10  pop rcx
0000708296fd1c11  pop rax
0000708296fd1c12  add rsp, 0x08
0000708296fd1c16  jmp 0x0000708296FCFAAF
0000708296fd1c1b  sub rsp, 0x08
0000708296fd1c1f  push rax
0000708296fd1c20  push rcx
0000708296fd1c21  push rdx
0000708296fd1c22  push rdi
0000708296fd1c23  push rsi
0000708296fd1c24  push r8
0000708296fd1c26  push r9
0000708296fd1c28  push r10
0000708296fd1c2a  push r11
0000708296fd1c2c  sub rsp, 0xF0
0000708296fd1c33  vmovaps [rsp], xmm0
0000708296fd1c38  vmovaps [rsp+0x10], xmm1
0000708296fd1c3e  vmovaps [rsp+0x20], xmm2
0000708296fd1c44  vmovaps [rsp+0x30], xmm3
0000708296fd1c4a  vmovaps [rsp+0x40], xmm4
0000708296fd1c50  vmovaps [rsp+0x50], xmm5
0000708296fd1c56  vmovaps [rsp+0x60], xmm6
0000708296fd1c5c  vmovaps [rsp+0x70], xmm7
0000708296fd1c62  vmovaps [rsp+0x80], xmm8
0000708296fd1c6b  vmovaps [rsp+0x90], xmm9
0000708296fd1c74  vmovaps [rsp+0xA0], xmm10
0000708296fd1c7d  vmovaps [rsp+0xB0], xmm11
0000708296fd1c86  vmovaps [rsp+0xC0], xmm12
0000708296fd1c8f  vmovaps [rsp+0xD0], xmm13
0000708296fd1c98  vmovaps [rsp+0xE0], xmm14
0000708296fd1ca1  sub rsp, 0x30
0000708296fd1ca5  movaps [rsp], xmm15
0000708296fd1caa  movaps [rsp+0x10], xmm13
0000708296fd1cb0  movaps [rsp+0x20], xmm1
0000708296fd1cb5  lea rdi, [rsp]
0000708296fd1cb9  mov esi, 0x00
0000708296fd1cbe  mov rax, 0x64BBC686C530
0000708296fd1cc8  call rax
0000708296fd1cca  movaps xmm15, [rsp]
0000708296fd1ccf  add rsp, 0x30
0000708296fd1cd3  vmovaps xmm0, [rsp]
0000708296fd1cd8  vmovaps xmm1, [rsp+0x10]
0000708296fd1cde  vmovaps xmm2, [rsp+0x20]
0000708296fd1ce4  vmovaps xmm3, [rsp+0x30]
0000708296fd1cea  vmovaps xmm4, [rsp+0x40]
0000708296fd1cf0  vmovaps xmm5, [rsp+0x50]
0000708296fd1cf6  vmovaps xmm6, [rsp+0x60]
0000708296fd1cfc  vmovaps xmm7, [rsp+0x70]
0000708296fd1d02  vmovaps xmm8, [rsp+0x80]
0000708296fd1d0b  vmovaps xmm9, [rsp+0x90]
0000708296fd1d14  vmovaps xmm10, [rsp+0xA0]
0000708296fd1d1d  vmovaps xmm11, [rsp+0xB0]
0000708296fd1d26  vmovaps xmm12, [rsp+0xC0]
0000708296fd1d2f  vmovaps xmm13, [rsp+0xD0]
0000708296fd1d38  vmovaps xmm14, [rsp+0xE0]
0000708296fd1d41  add rsp, 0xF0
0000708296fd1d48  pop r11
0000708296fd1d4a  pop r10
0000708296fd1d4c  pop r9
0000708296fd1d4e  pop r8
0000708296fd1d50  pop rsi
0000708296fd1d51  pop rdi
0000708296fd1d52  pop rdx
0000708296fd1d53  pop rcx
0000708296fd1d54  pop rax
0000708296fd1d55  add rsp, 0x08
0000708296fd1d59  jmp 0x0000708296FCFAEB
0000708296fd1d5e  call 0x0000708296DFF430
0000708296fd1d63  jmp 0x0000708296FCFAF8
0000708296fd1d68  sub rsp, 0x08
0000708296fd1d6c  push rax
0000708296fd1d6d  push rcx
0000708296fd1d6e  push rdx
0000708296fd1d6f  push rdi
0000708296fd1d70  push rsi
0000708296fd1d71  push r8
0000708296fd1d73  push r9
0000708296fd1d75  push r10
0000708296fd1d77  push r11
0000708296fd1d79  sub rsp, 0xF0
0000708296fd1d80  vmovaps [rsp], xmm0
0000708296fd1d85  vmovaps [rsp+0x10], xmm1
0000708296fd1d8b  vmovaps [rsp+0x20], xmm2
0000708296fd1d91  vmovaps [rsp+0x30], xmm3
0000708296fd1d97  vmovaps [rsp+0x40], xmm4
0000708296fd1d9d  vmovaps [rsp+0x50], xmm5
0000708296fd1da3  vmovaps [rsp+0x60], xmm6
0000708296fd1da9  vmovaps [rsp+0x70], xmm7
0000708296fd1daf  vmovaps [rsp+0x80], xmm8
0000708296fd1db8  vmovaps [rsp+0x90], xmm9
0000708296fd1dc1  vmovaps [rsp+0xA0], xmm10
0000708296fd1dca  vmovaps [rsp+0xB0], xmm11
0000708296fd1dd3  vmovaps [rsp+0xC0], xmm12
0000708296fd1ddc  vmovaps [rsp+0xD0], xmm13
0000708296fd1de5  vmovaps [rsp+0xE0], xmm15
0000708296fd1dee  sub rsp, 0x30
0000708296fd1df2  movaps [rsp], xmm14
0000708296fd1df7  movaps [rsp+0x10], xmm13
0000708296fd1dfd  movaps [rsp+0x20], xmm2
0000708296fd1e02  lea rdi, [rsp]
0000708296fd1e06  mov esi, 0x00
0000708296fd1e0b  mov rax, 0x64BBC686C530
0000708296fd1e15  call rax
0000708296fd1e17  movaps xmm14, [rsp]
0000708296fd1e1c  add rsp, 0x30
0000708296fd1e20  vmovaps xmm0, [rsp]
0000708296fd1e25  vmovaps xmm1, [rsp+0x10]
0000708296fd1e2b  vmovaps xmm2, [rsp+0x20]
0000708296fd1e31  vmovaps xmm3, [rsp+0x30]
0000708296fd1e37  vmovaps xmm4, [rsp+0x40]
0000708296fd1e3d  vmovaps xmm5, [rsp+0x50]
0000708296fd1e43  vmovaps xmm6, [rsp+0x60]
0000708296fd1e49  vmovaps xmm7, [rsp+0x70]
0000708296fd1e4f  vmovaps xmm8, [rsp+0x80]
0000708296fd1e58  vmovaps xmm9, [rsp+0x90]
0000708296fd1e61  vmovaps xmm10, [rsp+0xA0]
0000708296fd1e6a  vmovaps xmm11, [rsp+0xB0]
0000708296fd1e73  vmovaps xmm12, [rsp+0xC0]
0000708296fd1e7c  vmovaps xmm13, [rsp+0xD0]
0000708296fd1e85  vmovaps xmm15, [rsp+0xE0]
0000708296fd1e8e  add rsp, 0xF0
0000708296fd1e95  pop r11
0000708296fd1e97  pop r10
0000708296fd1e99  pop r9
0000708296fd1e9b  pop r8
0000708296fd1e9d  pop rsi
0000708296fd1e9e  pop rdi
0000708296fd1e9f  pop rdx
0000708296fd1ea0  pop rcx
0000708296fd1ea1  pop rax
0000708296fd1ea2  add rsp, 0x08
0000708296fd1ea6  jmp 0x0000708296FCFB24
0000708296fd1eab  sub rsp, 0x08
0000708296fd1eaf  push rax
0000708296fd1eb0  push rcx
0000708296fd1eb1  push rdx
0000708296fd1eb2  push rdi
0000708296fd1eb3  push rsi
0000708296fd1eb4  push r8
0000708296fd1eb6  push r9
0000708296fd1eb8  push r10
0000708296fd1eba  push r11
0000708296fd1ebc  sub rsp, 0xF0
0000708296fd1ec3  vmovaps [rsp], xmm0
0000708296fd1ec8  vmovaps [rsp+0x10], xmm2
0000708296fd1ece  vmovaps [rsp+0x20], xmm3
0000708296fd1ed4  vmovaps [rsp+0x30], xmm4
0000708296fd1eda  vmovaps [rsp+0x40], xmm5
0000708296fd1ee0  vmovaps [rsp+0x50], xmm6
0000708296fd1ee6  vmovaps [rsp+0x60], xmm7
0000708296fd1eec  vmovaps [rsp+0x70], xmm8
0000708296fd1ef2  vmovaps [rsp+0x80], xmm9
0000708296fd1efb  vmovaps [rsp+0x90], xmm10
0000708296fd1f04  vmovaps [rsp+0xA0], xmm11
0000708296fd1f0d  vmovaps [rsp+0xB0], xmm12
0000708296fd1f16  vmovaps [rsp+0xC0], xmm13
0000708296fd1f1f  vmovaps [rsp+0xD0], xmm14
0000708296fd1f28  vmovaps [rsp+0xE0], xmm15
0000708296fd1f31  sub rsp, 0x30
0000708296fd1f35  movaps [rsp], xmm1
0000708296fd1f39  movaps [rsp+0x10], xmm13
0000708296fd1f3f  movaps [rsp+0x20], xmm2
0000708296fd1f44  lea rdi, [rsp]
0000708296fd1f48  mov esi, 0x00
0000708296fd1f4d  mov rax, 0x64BBC686C530
0000708296fd1f57  call rax
0000708296fd1f59  movaps xmm1, [rsp]
0000708296fd1f5d  add rsp, 0x30
0000708296fd1f61  vmovaps xmm0, [rsp]
0000708296fd1f66  vmovaps xmm2, [rsp+0x10]
0000708296fd1f6c  vmovaps xmm3, [rsp+0x20]
0000708296fd1f72  vmovaps xmm4, [rsp+0x30]
0000708296fd1f78  vmovaps xmm5, [rsp+0x40]
0000708296fd1f7e  vmovaps xmm6, [rsp+0x50]
0000708296fd1f84  vmovaps xmm7, [rsp+0x60]
0000708296fd1f8a  vmovaps xmm8, [rsp+0x70]
0000708296fd1f90  vmovaps xmm9, [rsp+0x80]
0000708296fd1f99  vmovaps xmm10, [rsp+0x90]
0000708296fd1fa2  vmovaps xmm11, [rsp+0xA0]
0000708296fd1fab  vmovaps xmm12, [rsp+0xB0]
0000708296fd1fb4  vmovaps xmm13, [rsp+0xC0]
0000708296fd1fbd  vmovaps xmm14, [rsp+0xD0]
0000708296fd1fc6  vmovaps xmm15, [rsp+0xE0]
0000708296fd1fcf  add rsp, 0xF0
0000708296fd1fd6  pop r11
0000708296fd1fd8  pop r10
0000708296fd1fda  pop r9
0000708296fd1fdc  pop r8
0000708296fd1fde  pop rsi
0000708296fd1fdf  pop rdi
0000708296fd1fe0  pop rdx
0000708296fd1fe1  pop rcx
0000708296fd1fe2  pop rax
0000708296fd1fe3  add rsp, 0x08
0000708296fd1fe7  jmp 0x0000708296FCFB52
0000708296fd1fec  sub rsp, 0x08
0000708296fd1ff0  push rax
0000708296fd1ff1  push rcx
0000708296fd1ff2  push rdx
0000708296fd1ff3  push rdi
0000708296fd1ff4  push rsi
0000708296fd1ff5  push r8
0000708296fd1ff7  push r9
0000708296fd1ff9  push r10
0000708296fd1ffb  push r11
0000708296fd1ffd  sub rsp, 0xF0
0000708296fd2004  vmovaps [rsp], xmm0
0000708296fd2009  vmovaps [rsp+0x10], xmm1
0000708296fd200f  vmovaps [rsp+0x20], xmm3
0000708296fd2015  vmovaps [rsp+0x30], xmm4
0000708296fd201b  vmovaps [rsp+0x40], xmm5
0000708296fd2021  vmovaps [rsp+0x50], xmm6
0000708296fd2027  vmovaps [rsp+0x60], xmm7
0000708296fd202d  vmovaps [rsp+0x70], xmm8
0000708296fd2033  vmovaps [rsp+0x80], xmm9
0000708296fd203c  vmovaps [rsp+0x90], xmm10
0000708296fd2045  vmovaps [rsp+0xA0], xmm11
0000708296fd204e  vmovaps [rsp+0xB0], xmm12
0000708296fd2057  vmovaps [rsp+0xC0], xmm13
0000708296fd2060  vmovaps [rsp+0xD0], xmm14
0000708296fd2069  vmovaps [rsp+0xE0], xmm15
0000708296fd2072  sub rsp, 0x30
0000708296fd2076  movaps [rsp], xmm2
0000708296fd207a  movaps [rsp+0x10], xmm1
0000708296fd207f  movaps [rsp+0x20], xmm13
0000708296fd2085  lea rdi, [rsp]
0000708296fd2089  mov esi, 0x00
0000708296fd208e  mov rax, 0x64BBC686C530
0000708296fd2098  call rax
0000708296fd209a  movaps xmm2, [rsp]
0000708296fd209e  add rsp, 0x30
0000708296fd20a2  vmovaps xmm0, [rsp]
0000708296fd20a7  vmovaps xmm1, [rsp+0x10]
0000708296fd20ad  vmovaps xmm3, [rsp+0x20]
0000708296fd20b3  vmovaps xmm4, [rsp+0x30]
0000708296fd20b9  vmovaps xmm5, [rsp+0x40]
0000708296fd20bf  vmovaps xmm6, [rsp+0x50]
0000708296fd20c5  vmovaps xmm7, [rsp+0x60]
0000708296fd20cb  vmovaps xmm8, [rsp+0x70]
0000708296fd20d1  vmovaps xmm9, [rsp+0x80]
0000708296fd20da  vmovaps xmm10, [rsp+0x90]
0000708296fd20e3  vmovaps xmm11, [rsp+0xA0]
0000708296fd20ec  vmovaps xmm12, [rsp+0xB0]
0000708296fd20f5  vmovaps xmm13, [rsp+0xC0]
0000708296fd20fe  vmovaps xmm14, [rsp+0xD0]
0000708296fd2107  vmovaps xmm15, [rsp+0xE0]
0000708296fd2110  add rsp, 0xF0
0000708296fd2117  pop r11
0000708296fd2119  pop r10
0000708296fd211b  pop r9
0000708296fd211d  pop r8
0000708296fd211f  pop rsi
0000708296fd2120  pop rdi
0000708296fd2121  pop rdx
0000708296fd2122  pop rcx
0000708296fd2123  pop rax
0000708296fd2124  add rsp, 0x08
0000708296fd2128  jmp 0x0000708296FCFBAB
0000708296fd212d  call 0x0000708296DFF430
0000708296fd2132  jmp 0x0000708296FCFBB8
0000708296fd2137  sub rsp, 0x08
0000708296fd213b  push rax
0000708296fd213c  push rcx
0000708296fd213d  push rdx
0000708296fd213e  push rdi
0000708296fd213f  push rsi
0000708296fd2140  push r8
0000708296fd2142  push r9
0000708296fd2144  push r10
0000708296fd2146  push r11
0000708296fd2148  sub rsp, 0xF0
0000708296fd214f  vmovaps [rsp], xmm0
0000708296fd2154  vmovaps [rsp+0x10], xmm1
0000708296fd215a  vmovaps [rsp+0x20], xmm2
0000708296fd2160  vmovaps [rsp+0x30], xmm3
0000708296fd2166  vmovaps [rsp+0x40], xmm4
0000708296fd216c  vmovaps [rsp+0x50], xmm5
0000708296fd2172  vmovaps [rsp+0x60], xmm6
0000708296fd2178  vmovaps [rsp+0x70], xmm7
0000708296fd217e  vmovaps [rsp+0x80], xmm8
0000708296fd2187  vmovaps [rsp+0x90], xmm9
0000708296fd2190  vmovaps [rsp+0xA0], xmm10
0000708296fd2199  vmovaps [rsp+0xB0], xmm11
0000708296fd21a2  vmovaps [rsp+0xC0], xmm12
0000708296fd21ab  vmovaps [rsp+0xD0], xmm13
0000708296fd21b4  vmovaps [rsp+0xE0], xmm14
0000708296fd21bd  sub rsp, 0x30
0000708296fd21c1  movaps [rsp], xmm15
0000708296fd21c6  movaps [rsp+0x10], xmm13
0000708296fd21cc  movaps [rsp+0x20], xmm1
0000708296fd21d1  lea rdi, [rsp]
0000708296fd21d5  mov esi, 0x00
0000708296fd21da  mov rax, 0x64BBC686C530
0000708296fd21e4  call rax
0000708296fd21e6  movaps xmm15, [rsp]
0000708296fd21eb  add rsp, 0x30
0000708296fd21ef  vmovaps xmm0, [rsp]
0000708296fd21f4  vmovaps xmm1, [rsp+0x10]
0000708296fd21fa  vmovaps xmm2, [rsp+0x20]
0000708296fd2200  vmovaps xmm3, [rsp+0x30]
0000708296fd2206  vmovaps xmm4, [rsp+0x40]
0000708296fd220c  vmovaps xmm5, [rsp+0x50]
0000708296fd2212  vmovaps xmm6, [rsp+0x60]
0000708296fd2218  vmovaps xmm7, [rsp+0x70]
0000708296fd221e  vmovaps xmm8, [rsp+0x80]
0000708296fd2227  vmovaps xmm9, [rsp+0x90]
0000708296fd2230  vmovaps xmm10, [rsp+0xA0]
0000708296fd2239  vmovaps xmm11, [rsp+0xB0]
0000708296fd2242  vmovaps xmm12, [rsp+0xC0]
0000708296fd224b  vmovaps xmm13, [rsp+0xD0]
0000708296fd2254  vmovaps xmm14, [rsp+0xE0]
0000708296fd225d  add rsp, 0xF0
0000708296fd2264  pop r11
0000708296fd2266  pop r10
0000708296fd2268  pop r9
0000708296fd226a  pop r8
0000708296fd226c  pop rsi
0000708296fd226d  pop rdi
0000708296fd226e  pop rdx
0000708296fd226f  pop rcx
0000708296fd2270  pop rax
0000708296fd2271  add rsp, 0x08
0000708296fd2275  jmp 0x0000708296FCFBF7
0000708296fd227a  sub rsp, 0x08
0000708296fd227e  push rax
0000708296fd227f  push rcx
0000708296fd2280  push rdx
0000708296fd2281  push rdi
0000708296fd2282  push rsi
0000708296fd2283  push r8
0000708296fd2285  push r9
0000708296fd2287  push r10
0000708296fd2289  push r11
0000708296fd228b  sub rsp, 0xF0
0000708296fd2292  vmovaps [rsp], xmm0
0000708296fd2297  vmovaps [rsp+0x10], xmm1
0000708296fd229d  vmovaps [rsp+0x20], xmm2
0000708296fd22a3  vmovaps [rsp+0x30], xmm3
0000708296fd22a9  vmovaps [rsp+0x40], xmm4
0000708296fd22af  vmovaps [rsp+0x50], xmm5
0000708296fd22b5  vmovaps [rsp+0x60], xmm6
0000708296fd22bb  vmovaps [rsp+0x70], xmm7
0000708296fd22c1  vmovaps [rsp+0x80], xmm8
0000708296fd22ca  vmovaps [rsp+0x90], xmm9
0000708296fd22d3  vmovaps [rsp+0xA0], xmm10
0000708296fd22dc  vmovaps [rsp+0xB0], xmm11
0000708296fd22e5  vmovaps [rsp+0xC0], xmm12
0000708296fd22ee  vmovaps [rsp+0xD0], xmm13
0000708296fd22f7  vmovaps [rsp+0xE0], xmm15
0000708296fd2300  sub rsp, 0x30
0000708296fd2304  movaps [rsp], xmm14
0000708296fd2309  movaps [rsp+0x10], xmm11
0000708296fd230f  movaps [rsp+0x20], xmm1
0000708296fd2314  lea rdi, [rsp]
0000708296fd2318  mov esi, 0x00
0000708296fd231d  mov rax, 0x64BBC686C530
0000708296fd2327  call rax
0000708296fd2329  movaps xmm14, [rsp]
0000708296fd232e  add rsp, 0x30
0000708296fd2332  vmovaps xmm0, [rsp]
0000708296fd2337  vmovaps xmm1, [rsp+0x10]
0000708296fd233d  vmovaps xmm2, [rsp+0x20]
0000708296fd2343  vmovaps xmm3, [rsp+0x30]
0000708296fd2349  vmovaps xmm4, [rsp+0x40]
0000708296fd234f  vmovaps xmm5, [rsp+0x50]
0000708296fd2355  vmovaps xmm6, [rsp+0x60]
0000708296fd235b  vmovaps xmm7, [rsp+0x70]
0000708296fd2361  vmovaps xmm8, [rsp+0x80]
0000708296fd236a  vmovaps xmm9, [rsp+0x90]
0000708296fd2373  vmovaps xmm10, [rsp+0xA0]
0000708296fd237c  vmovaps xmm11, [rsp+0xB0]
0000708296fd2385  vmovaps xmm12, [rsp+0xC0]
0000708296fd238e  vmovaps xmm13, [rsp+0xD0]
0000708296fd2397  vmovaps xmm15, [rsp+0xE0]
0000708296fd23a0  add rsp, 0xF0
0000708296fd23a7  pop r11
0000708296fd23a9  pop r10
0000708296fd23ab  pop r9
0000708296fd23ad  pop r8
0000708296fd23af  pop rsi
0000708296fd23b0  pop rdi
0000708296fd23b1  pop rdx
0000708296fd23b2  pop rcx
0000708296fd23b3  pop rax
0000708296fd23b4  add rsp, 0x08
0000708296fd23b8  jmp 0x0000708296FCFC21
0000708296fd23bd  sub rsp, 0x08
0000708296fd23c1  push rax
0000708296fd23c2  push rcx
0000708296fd23c3  push rdx
0000708296fd23c4  push rdi
0000708296fd23c5  push rsi
0000708296fd23c6  push r8
0000708296fd23c8  push r9
0000708296fd23ca  push r10
0000708296fd23cc  push r11
0000708296fd23ce  sub rsp, 0xF0
0000708296fd23d5  vmovaps [rsp], xmm0
0000708296fd23da  vmovaps [rsp+0x10], xmm1
0000708296fd23e0  vmovaps [rsp+0x20], xmm2
0000708296fd23e6  vmovaps [rsp+0x30], xmm3
0000708296fd23ec  vmovaps [rsp+0x40], xmm4
0000708296fd23f2  vmovaps [rsp+0x50], xmm5
0000708296fd23f8  vmovaps [rsp+0x60], xmm6
0000708296fd23fe  vmovaps [rsp+0x70], xmm7
0000708296fd2404  vmovaps [rsp+0x80], xmm8
0000708296fd240d  vmovaps [rsp+0x90], xmm9
0000708296fd2416  vmovaps [rsp+0xA0], xmm10
0000708296fd241f  vmovaps [rsp+0xB0], xmm11
0000708296fd2428  vmovaps [rsp+0xC0], xmm12
0000708296fd2431  vmovaps [rsp+0xD0], xmm14
0000708296fd243a  vmovaps [rsp+0xE0], xmm15
0000708296fd2443  sub rsp, 0x30
0000708296fd2447  movaps [rsp], xmm13
0000708296fd244c  movaps [rsp+0x10], xmm11
0000708296fd2452  movaps [rsp+0x20], xmm1
0000708296fd2457  lea rdi, [rsp]
0000708296fd245b  mov esi, 0x00
0000708296fd2460  mov rax, 0x64BBC686C530
0000708296fd246a  call rax
0000708296fd246c  movaps xmm13, [rsp]
0000708296fd2471  add rsp, 0x30
0000708296fd2475  vmovaps xmm0, [rsp]
0000708296fd247a  vmovaps xmm1, [rsp+0x10]
0000708296fd2480  vmovaps xmm2, [rsp+0x20]
0000708296fd2486  vmovaps xmm3, [rsp+0x30]
0000708296fd248c  vmovaps xmm4, [rsp+0x40]
0000708296fd2492  vmovaps xmm5, [rsp+0x50]
0000708296fd2498  vmovaps xmm6, [rsp+0x60]
0000708296fd249e  vmovaps xmm7, [rsp+0x70]
0000708296fd24a4  vmovaps xmm8, [rsp+0x80]
0000708296fd24ad  vmovaps xmm9, [rsp+0x90]
0000708296fd24b6  vmovaps xmm10, [rsp+0xA0]
0000708296fd24bf  vmovaps xmm11, [rsp+0xB0]
0000708296fd24c8  vmovaps xmm12, [rsp+0xC0]
0000708296fd24d1  vmovaps xmm14, [rsp+0xD0]
0000708296fd24da  vmovaps xmm15, [rsp+0xE0]
0000708296fd24e3  add rsp, 0xF0
0000708296fd24ea  pop r11
0000708296fd24ec  pop r10
0000708296fd24ee  pop r9
0000708296fd24f0  pop r8
0000708296fd24f2  pop rsi
0000708296fd24f3  pop rdi
0000708296fd24f4  pop rdx
0000708296fd24f5  pop rcx
0000708296fd24f6  pop rax
0000708296fd24f7  add rsp, 0x08
0000708296fd24fb  jmp 0x0000708296FCFC76
0000708296fd2500  call 0x0000708296DFF430
0000708296fd2505  jmp 0x0000708296FCFC83
0000708296fd250a  sub rsp, 0x08
0000708296fd250e  push rax
0000708296fd250f  push rcx
0000708296fd2510  push rdx
0000708296fd2511  push rdi
0000708296fd2512  push rsi
0000708296fd2513  push r8
0000708296fd2515  push r9
0000708296fd2517  push r10
0000708296fd2519  push r11
0000708296fd251b  sub rsp, 0xF0
0000708296fd2522  vmovaps [rsp], xmm0
0000708296fd2527  vmovaps [rsp+0x10], xmm1
0000708296fd252d  vmovaps [rsp+0x20], xmm2
0000708296fd2533  vmovaps [rsp+0x30], xmm3
0000708296fd2539  vmovaps [rsp+0x40], xmm4
0000708296fd253f  vmovaps [rsp+0x50], xmm5
0000708296fd2545  vmovaps [rsp+0x60], xmm6
0000708296fd254b  vmovaps [rsp+0x70], xmm7
0000708296fd2551  vmovaps [rsp+0x80], xmm8
0000708296fd255a  vmovaps [rsp+0x90], xmm9
0000708296fd2563  vmovaps [rsp+0xA0], xmm10
0000708296fd256c  vmovaps [rsp+0xB0], xmm11
0000708296fd2575  vmovaps [rsp+0xC0], xmm12
0000708296fd257e  vmovaps [rsp+0xD0], xmm13
0000708296fd2587  vmovaps [rsp+0xE0], xmm14
0000708296fd2590  sub rsp, 0x30
0000708296fd2594  movaps [rsp], xmm15
0000708296fd2599  movaps [rsp+0x10], xmm11
0000708296fd259f  movaps [rsp+0x20], xmm1
0000708296fd25a4  lea rdi, [rsp]
0000708296fd25a8  mov esi, 0x00
0000708296fd25ad  mov rax, 0x64BBC686C530
0000708296fd25b7  call rax
0000708296fd25b9  movaps xmm15, [rsp]
0000708296fd25be  add rsp, 0x30
0000708296fd25c2  vmovaps xmm0, [rsp]
0000708296fd25c7  vmovaps xmm1, [rsp+0x10]
0000708296fd25cd  vmovaps xmm2, [rsp+0x20]
0000708296fd25d3  vmovaps xmm3, [rsp+0x30]
0000708296fd25d9  vmovaps xmm4, [rsp+0x40]
0000708296fd25df  vmovaps xmm5, [rsp+0x50]
0000708296fd25e5  vmovaps xmm6, [rsp+0x60]
0000708296fd25eb  vmovaps xmm7, [rsp+0x70]
0000708296fd25f1  vmovaps xmm8, [rsp+0x80]
0000708296fd25fa  vmovaps xmm9, [rsp+0x90]
0000708296fd2603  vmovaps xmm10, [rsp+0xA0]
0000708296fd260c  vmovaps xmm11, [rsp+0xB0]
0000708296fd2615  vmovaps xmm12, [rsp+0xC0]
0000708296fd261e  vmovaps xmm13, [rsp+0xD0]
0000708296fd2627  vmovaps xmm14, [rsp+0xE0]
0000708296fd2630  add rsp, 0xF0
0000708296fd2637  pop r11
0000708296fd2639  pop r10
0000708296fd263b  pop r9
0000708296fd263d  pop r8
0000708296fd263f  pop rsi
0000708296fd2640  pop rdi
0000708296fd2641  pop rdx
0000708296fd2642  pop rcx
0000708296fd2643  pop rax
0000708296fd2644  add rsp, 0x08
0000708296fd2648  jmp 0x0000708296FCFCBC
0000708296fd264d  sub rsp, 0x08
0000708296fd2651  push rax
0000708296fd2652  push rcx
0000708296fd2653  push rdx
0000708296fd2654  push rdi
0000708296fd2655  push rsi
0000708296fd2656  push r8
0000708296fd2658  push r9
0000708296fd265a  push r10
0000708296fd265c  push r11
0000708296fd265e  sub rsp, 0xF0
0000708296fd2665  vmovaps [rsp], xmm0
0000708296fd266a  vmovaps [rsp+0x10], xmm1
0000708296fd2670  vmovaps [rsp+0x20], xmm2
0000708296fd2676  vmovaps [rsp+0x30], xmm3
0000708296fd267c  vmovaps [rsp+0x40], xmm4
0000708296fd2682  vmovaps [rsp+0x50], xmm5
0000708296fd2688  vmovaps [rsp+0x60], xmm6
0000708296fd268e  vmovaps [rsp+0x70], xmm7
0000708296fd2694  vmovaps [rsp+0x80], xmm8
0000708296fd269d  vmovaps [rsp+0x90], xmm9
0000708296fd26a6  vmovaps [rsp+0xA0], xmm10
0000708296fd26af  vmovaps [rsp+0xB0], xmm12
0000708296fd26b8  vmovaps [rsp+0xC0], xmm13
0000708296fd26c1  vmovaps [rsp+0xD0], xmm14
0000708296fd26ca  vmovaps [rsp+0xE0], xmm15
0000708296fd26d3  sub rsp, 0x30
0000708296fd26d7  movaps [rsp], xmm11
0000708296fd26dc  movaps [rsp+0x10], xmm6
0000708296fd26e1  movaps [rsp+0x20], xmm14
0000708296fd26e7  lea rdi, [rsp]
0000708296fd26eb  mov esi, 0x00
0000708296fd26f0  mov rax, 0x64BBC686C530
0000708296fd26fa  call rax
0000708296fd26fc  movaps xmm11, [rsp]
0000708296fd2701  add rsp, 0x30
0000708296fd2705  vmovaps xmm0, [rsp]
0000708296fd270a  vmovaps xmm1, [rsp+0x10]
0000708296fd2710  vmovaps xmm2, [rsp+0x20]
0000708296fd2716  vmovaps xmm3, [rsp+0x30]
0000708296fd271c  vmovaps xmm4, [rsp+0x40]
0000708296fd2722  vmovaps xmm5, [rsp+0x50]
0000708296fd2728  vmovaps xmm6, [rsp+0x60]
0000708296fd272e  vmovaps xmm7, [rsp+0x70]
0000708296fd2734  vmovaps xmm8, [rsp+0x80]
0000708296fd273d  vmovaps xmm9, [rsp+0x90]
0000708296fd2746  vmovaps xmm10, [rsp+0xA0]
0000708296fd274f  vmovaps xmm12, [rsp+0xB0]
0000708296fd2758  vmovaps xmm13, [rsp+0xC0]
0000708296fd2761  vmovaps xmm14, [rsp+0xD0]
0000708296fd276a  vmovaps xmm15, [rsp+0xE0]
0000708296fd2773  add rsp, 0xF0
0000708296fd277a  pop r11
0000708296fd277c  pop r10
0000708296fd277e  pop r9
0000708296fd2780  pop r8
0000708296fd2782  pop rsi
0000708296fd2783  pop rdi
0000708296fd2784  pop rdx
0000708296fd2785  pop rcx
0000708296fd2786  pop rax
0000708296fd2787  add rsp, 0x08
0000708296fd278b  jmp 0x0000708296FCFD34
0000708296fd2790  call 0x0000708296DFF430
0000708296fd2795  jmp 0x0000708296FCFD3E
0000708296fd279a  sub rsp, 0x08
0000708296fd279e  push rax
0000708296fd279f  push rcx
0000708296fd27a0  push rdx
0000708296fd27a1  push rdi
0000708296fd27a2  push rsi
0000708296fd27a3  push r8
0000708296fd27a5  push r9
0000708296fd27a7  push r10
0000708296fd27a9  push r11
0000708296fd27ab  sub rsp, 0xF0
0000708296fd27b2  vmovaps [rsp], xmm0
0000708296fd27b7  vmovaps [rsp+0x10], xmm1
0000708296fd27bd  vmovaps [rsp+0x20], xmm2
0000708296fd27c3  vmovaps [rsp+0x30], xmm3
0000708296fd27c9  vmovaps [rsp+0x40], xmm4
0000708296fd27cf  vmovaps [rsp+0x50], xmm5
0000708296fd27d5  vmovaps [rsp+0x60], xmm6
0000708296fd27db  vmovaps [rsp+0x70], xmm7
0000708296fd27e1  vmovaps [rsp+0x80], xmm8
0000708296fd27ea  vmovaps [rsp+0x90], xmm9
0000708296fd27f3  vmovaps [rsp+0xA0], xmm10
0000708296fd27fc  vmovaps [rsp+0xB0], xmm11
0000708296fd2805  vmovaps [rsp+0xC0], xmm12
0000708296fd280e  vmovaps [rsp+0xD0], xmm13
0000708296fd2817  vmovaps [rsp+0xE0], xmm15
0000708296fd2820  sub rsp, 0x30
0000708296fd2824  movaps [rsp], xmm14
0000708296fd2829  movaps [rsp+0x10], xmm6
0000708296fd282e  movaps [rsp+0x20], xmm2
0000708296fd2833  lea rdi, [rsp]
0000708296fd2837  mov esi, 0x00
0000708296fd283c  mov rax, 0x64BBC686C530
0000708296fd2846  call rax
0000708296fd2848  movaps xmm14, [rsp]
0000708296fd284d  add rsp, 0x30
0000708296fd2851  vmovaps xmm0, [rsp]
0000708296fd2856  vmovaps xmm1, [rsp+0x10]
0000708296fd285c  vmovaps xmm2, [rsp+0x20]
0000708296fd2862  vmovaps xmm3, [rsp+0x30]
0000708296fd2868  vmovaps xmm4, [rsp+0x40]
0000708296fd286e  vmovaps xmm5, [rsp+0x50]
0000708296fd2874  vmovaps xmm6, [rsp+0x60]
0000708296fd287a  vmovaps xmm7, [rsp+0x70]
0000708296fd2880  vmovaps xmm8, [rsp+0x80]
0000708296fd2889  vmovaps xmm9, [rsp+0x90]
0000708296fd2892  vmovaps xmm10, [rsp+0xA0]
0000708296fd289b  vmovaps xmm11, [rsp+0xB0]
0000708296fd28a4  vmovaps xmm12, [rsp+0xC0]
0000708296fd28ad  vmovaps xmm13, [rsp+0xD0]
0000708296fd28b6  vmovaps xmm15, [rsp+0xE0]
0000708296fd28bf  add rsp, 0xF0
0000708296fd28c6  pop r11
0000708296fd28c8  pop r10
0000708296fd28ca  pop r9
0000708296fd28cc  pop r8
0000708296fd28ce  pop rsi
0000708296fd28cf  pop rdi
0000708296fd28d0  pop rdx
0000708296fd28d1  pop rcx
0000708296fd28d2  pop rax
0000708296fd28d3  add rsp, 0x08
0000708296fd28d7  jmp 0x0000708296FCFD72
0000708296fd28dc  sub rsp, 0x08
0000708296fd28e0  push rax
0000708296fd28e1  push rcx
0000708296fd28e2  push rdx
0000708296fd28e3  push rdi
0000708296fd28e4  push rsi
0000708296fd28e5  push r8
0000708296fd28e7  push r9
0000708296fd28e9  push r10
0000708296fd28eb  push r11
0000708296fd28ed  sub rsp, 0xF0
0000708296fd28f4  vmovaps [rsp], xmm0
0000708296fd28f9  vmovaps [rsp+0x10], xmm1
0000708296fd28ff  vmovaps [rsp+0x20], xmm2
0000708296fd2905  vmovaps [rsp+0x30], xmm3
0000708296fd290b  vmovaps [rsp+0x40], xmm4
0000708296fd2911  vmovaps [rsp+0x50], xmm5
0000708296fd2917  vmovaps [rsp+0x60], xmm7
0000708296fd291d  vmovaps [rsp+0x70], xmm8
0000708296fd2923  vmovaps [rsp+0x80], xmm9
0000708296fd292c  vmovaps [rsp+0x90], xmm10
0000708296fd2935  vmovaps [rsp+0xA0], xmm11
0000708296fd293e  vmovaps [rsp+0xB0], xmm12
0000708296fd2947  vmovaps [rsp+0xC0], xmm13
0000708296fd2950  vmovaps [rsp+0xD0], xmm14
0000708296fd2959  vmovaps [rsp+0xE0], xmm15
0000708296fd2962  sub rsp, 0x30
0000708296fd2966  movaps [rsp], xmm6
0000708296fd296a  movaps [rsp+0x10], xmm5
0000708296fd296f  movaps [rsp+0x20], xmm1
0000708296fd2974  lea rdi, [rsp]
0000708296fd2978  mov esi, 0x00
0000708296fd297d  mov rax, 0x64BBC686C530
0000708296fd2987  call rax
0000708296fd2989  movaps xmm6, [rsp]
0000708296fd298d  add rsp, 0x30
0000708296fd2991  vmovaps xmm0, [rsp]
0000708296fd2996  vmovaps xmm1, [rsp+0x10]
0000708296fd299c  vmovaps xmm2, [rsp+0x20]
0000708296fd29a2  vmovaps xmm3, [rsp+0x30]
0000708296fd29a8  vmovaps xmm4, [rsp+0x40]
0000708296fd29ae  vmovaps xmm5, [rsp+0x50]
0000708296fd29b4  vmovaps xmm7, [rsp+0x60]
0000708296fd29ba  vmovaps xmm8, [rsp+0x70]
0000708296fd29c0  vmovaps xmm9, [rsp+0x80]
0000708296fd29c9  vmovaps xmm10, [rsp+0x90]
0000708296fd29d2  vmovaps xmm11, [rsp+0xA0]
0000708296fd29db  vmovaps xmm12, [rsp+0xB0]
0000708296fd29e4  vmovaps xmm13, [rsp+0xC0]
0000708296fd29ed  vmovaps xmm14, [rsp+0xD0]
0000708296fd29f6  vmovaps xmm15, [rsp+0xE0]
0000708296fd29ff  add rsp, 0xF0
0000708296fd2a06  pop r11
0000708296fd2a08  pop r10
0000708296fd2a0a  pop r9
0000708296fd2a0c  pop r8
0000708296fd2a0e  pop rsi
0000708296fd2a0f  pop rdi
0000708296fd2a10  pop rdx
0000708296fd2a11  pop rcx
0000708296fd2a12  pop rax
0000708296fd2a13  add rsp, 0x08
0000708296fd2a17  jmp 0x0000708296FCFD98
0000708296fd2a1c  sub rsp, 0x08
0000708296fd2a20  push rax
0000708296fd2a21  push rcx
0000708296fd2a22  push rdx
0000708296fd2a23  push rdi
0000708296fd2a24  push rsi
0000708296fd2a25  push r8
0000708296fd2a27  push r9
0000708296fd2a29  push r10
0000708296fd2a2b  push r11
0000708296fd2a2d  sub rsp, 0xF0
0000708296fd2a34  vmovaps [rsp], xmm0
0000708296fd2a39  vmovaps [rsp+0x10], xmm2
0000708296fd2a3f  vmovaps [rsp+0x20], xmm3
0000708296fd2a45  vmovaps [rsp+0x30], xmm4
0000708296fd2a4b  vmovaps [rsp+0x40], xmm5
0000708296fd2a51  vmovaps [rsp+0x50], xmm6
0000708296fd2a57  vmovaps [rsp+0x60], xmm7
0000708296fd2a5d  vmovaps [rsp+0x70], xmm8
0000708296fd2a63  vmovaps [rsp+0x80], xmm9
0000708296fd2a6c  vmovaps [rsp+0x90], xmm10
0000708296fd2a75  vmovaps [rsp+0xA0], xmm11
0000708296fd2a7e  vmovaps [rsp+0xB0], xmm12
0000708296fd2a87  vmovaps [rsp+0xC0], xmm13
0000708296fd2a90  vmovaps [rsp+0xD0], xmm14
0000708296fd2a99  vmovaps [rsp+0xE0], xmm15
0000708296fd2aa2  sub rsp, 0x30
0000708296fd2aa6  movaps [rsp], xmm1
0000708296fd2aaa  movaps [rsp+0x10], xmm5
0000708296fd2aaf  movaps [rsp+0x20], xmm13
0000708296fd2ab5  lea rdi, [rsp]
0000708296fd2ab9  mov esi, 0x00
0000708296fd2abe  mov rax, 0x64BBC686C530
0000708296fd2ac8  call rax
0000708296fd2aca  movaps xmm1, [rsp]
0000708296fd2ace  add rsp, 0x30
0000708296fd2ad2  vmovaps xmm0, [rsp]
0000708296fd2ad7  vmovaps xmm2, [rsp+0x10]
0000708296fd2add  vmovaps xmm3, [rsp+0x20]
0000708296fd2ae3  vmovaps xmm4, [rsp+0x30]
0000708296fd2ae9  vmovaps xmm5, [rsp+0x40]
0000708296fd2aef  vmovaps xmm6, [rsp+0x50]
0000708296fd2af5  vmovaps xmm7, [rsp+0x60]
0000708296fd2afb  vmovaps xmm8, [rsp+0x70]
0000708296fd2b01  vmovaps xmm9, [rsp+0x80]
0000708296fd2b0a  vmovaps xmm10, [rsp+0x90]
0000708296fd2b13  vmovaps xmm11, [rsp+0xA0]
0000708296fd2b1c  vmovaps xmm12, [rsp+0xB0]
0000708296fd2b25  vmovaps xmm13, [rsp+0xC0]
0000708296fd2b2e  vmovaps xmm14, [rsp+0xD0]
0000708296fd2b37  vmovaps xmm15, [rsp+0xE0]
0000708296fd2b40  add rsp, 0xF0
0000708296fd2b47  pop r11
0000708296fd2b49  pop r10
0000708296fd2b4b  pop r9
0000708296fd2b4d  pop r8
0000708296fd2b4f  pop rsi
0000708296fd2b50  pop rdi
0000708296fd2b51  pop rdx
0000708296fd2b52  pop rcx
0000708296fd2b53  pop rax
0000708296fd2b54  add rsp, 0x08
0000708296fd2b58  jmp 0x0000708296FCFDB6
0000708296fd2b5d  sub rsp, 0x08
0000708296fd2b61  push rax
0000708296fd2b62  push rcx
0000708296fd2b63  push rdx
0000708296fd2b64  push rdi
0000708296fd2b65  push rsi
0000708296fd2b66  push r8
0000708296fd2b68  push r9
0000708296fd2b6a  push r10
0000708296fd2b6c  push r11
0000708296fd2b6e  sub rsp, 0xF0
0000708296fd2b75  vmovaps [rsp], xmm0
0000708296fd2b7a  vmovaps [rsp+0x10], xmm1
0000708296fd2b80  vmovaps [rsp+0x20], xmm2
0000708296fd2b86  vmovaps [rsp+0x30], xmm3
0000708296fd2b8c  vmovaps [rsp+0x40], xmm4
0000708296fd2b92  vmovaps [rsp+0x50], xmm6
0000708296fd2b98  vmovaps [rsp+0x60], xmm7
0000708296fd2b9e  vmovaps [rsp+0x70], xmm8
0000708296fd2ba4  vmovaps [rsp+0x80], xmm9
0000708296fd2bad  vmovaps [rsp+0x90], xmm10
0000708296fd2bb6  vmovaps [rsp+0xA0], xmm11
0000708296fd2bbf  vmovaps [rsp+0xB0], xmm12
0000708296fd2bc8  vmovaps [rsp+0xC0], xmm13
0000708296fd2bd1  vmovaps [rsp+0xD0], xmm14
0000708296fd2bda  vmovaps [rsp+0xE0], xmm15
0000708296fd2be3  sub rsp, 0x30
0000708296fd2be7  movaps [rsp], xmm5
0000708296fd2beb  movaps [rsp+0x10], xmm2
0000708296fd2bf0  movaps [rsp+0x20], xmm13
0000708296fd2bf6  lea rdi, [rsp]
0000708296fd2bfa  mov esi, 0x00
0000708296fd2bff  mov rax, 0x64BBC686C530
0000708296fd2c09  call rax
0000708296fd2c0b  movaps xmm5, [rsp]
0000708296fd2c0f  add rsp, 0x30
0000708296fd2c13  vmovaps xmm0, [rsp]
0000708296fd2c18  vmovaps xmm1, [rsp+0x10]
0000708296fd2c1e  vmovaps xmm2, [rsp+0x20]
0000708296fd2c24  vmovaps xmm3, [rsp+0x30]
0000708296fd2c2a  vmovaps xmm4, [rsp+0x40]
0000708296fd2c30  vmovaps xmm6, [rsp+0x50]
0000708296fd2c36  vmovaps xmm7, [rsp+0x60]
0000708296fd2c3c  vmovaps xmm8, [rsp+0x70]
0000708296fd2c42  vmovaps xmm9, [rsp+0x80]
0000708296fd2c4b  vmovaps xmm10, [rsp+0x90]
0000708296fd2c54  vmovaps xmm11, [rsp+0xA0]
0000708296fd2c5d  vmovaps xmm12, [rsp+0xB0]
0000708296fd2c66  vmovaps xmm13, [rsp+0xC0]
0000708296fd2c6f  vmovaps xmm14, [rsp+0xD0]
0000708296fd2c78  vmovaps xmm15, [rsp+0xE0]
0000708296fd2c81  add rsp, 0xF0
0000708296fd2c88  pop r11
0000708296fd2c8a  pop r10
0000708296fd2c8c  pop r9
0000708296fd2c8e  pop r8
0000708296fd2c90  pop rsi
0000708296fd2c91  pop rdi
0000708296fd2c92  pop rdx
0000708296fd2c93  pop rcx
0000708296fd2c94  pop rax
0000708296fd2c95  add rsp, 0x08
0000708296fd2c99  jmp 0x0000708296FCFDEC
0000708296fd2c9e  sub rsp, 0x08
0000708296fd2ca2  push rax
0000708296fd2ca3  push rcx
0000708296fd2ca4  push rdx
0000708296fd2ca5  push rdi
0000708296fd2ca6  push rsi
0000708296fd2ca7  push r8
0000708296fd2ca9  push r9
0000708296fd2cab  push r10
0000708296fd2cad  push r11
0000708296fd2caf  sub rsp, 0xF0
0000708296fd2cb6  vmovaps [rsp], xmm0
0000708296fd2cbb  vmovaps [rsp+0x10], xmm1
0000708296fd2cc1  vmovaps [rsp+0x20], xmm2
0000708296fd2cc7  vmovaps [rsp+0x30], xmm3
0000708296fd2ccd  vmovaps [rsp+0x40], xmm4
0000708296fd2cd3  vmovaps [rsp+0x50], xmm5
0000708296fd2cd9  vmovaps [rsp+0x60], xmm6
0000708296fd2cdf  vmovaps [rsp+0x70], xmm7
0000708296fd2ce5  vmovaps [rsp+0x80], xmm8
0000708296fd2cee  vmovaps [rsp+0x90], xmm9
0000708296fd2cf7  vmovaps [rsp+0xA0], xmm10
0000708296fd2d00  vmovaps [rsp+0xB0], xmm11
0000708296fd2d09  vmovaps [rsp+0xC0], xmm12
0000708296fd2d12  vmovaps [rsp+0xD0], xmm14
0000708296fd2d1b  vmovaps [rsp+0xE0], xmm15
0000708296fd2d24  sub rsp, 0x30
0000708296fd2d28  movaps [rsp], xmm13
0000708296fd2d2d  movaps [rsp+0x10], xmm10
0000708296fd2d33  movaps [rsp+0x20], xmm1
0000708296fd2d38  lea rdi, [rsp]
0000708296fd2d3c  mov esi, 0x00
0000708296fd2d41  mov rax, 0x64BBC686C530
0000708296fd2d4b  call rax
0000708296fd2d4d  movaps xmm13, [rsp]
0000708296fd2d52  add rsp, 0x30
0000708296fd2d56  vmovaps xmm0, [rsp]
0000708296fd2d5b  vmovaps xmm1, [rsp+0x10]
0000708296fd2d61  vmovaps xmm2, [rsp+0x20]
0000708296fd2d67  vmovaps xmm3, [rsp+0x30]
0000708296fd2d6d  vmovaps xmm4, [rsp+0x40]
0000708296fd2d73  vmovaps xmm5, [rsp+0x50]
0000708296fd2d79  vmovaps xmm6, [rsp+0x60]
0000708296fd2d7f  vmovaps xmm7, [rsp+0x70]
0000708296fd2d85  vmovaps xmm8, [rsp+0x80]
0000708296fd2d8e  vmovaps xmm9, [rsp+0x90]
0000708296fd2d97  vmovaps xmm10, [rsp+0xA0]
0000708296fd2da0  vmovaps xmm11, [rsp+0xB0]
0000708296fd2da9  vmovaps xmm12, [rsp+0xC0]
0000708296fd2db2  vmovaps xmm14, [rsp+0xD0]
0000708296fd2dbb  vmovaps xmm15, [rsp+0xE0]
0000708296fd2dc4  add rsp, 0xF0
0000708296fd2dcb  pop r11
0000708296fd2dcd  pop r10
0000708296fd2dcf  pop r9
0000708296fd2dd1  pop r8
0000708296fd2dd3  pop rsi
0000708296fd2dd4  pop rdi
0000708296fd2dd5  pop rdx
0000708296fd2dd6  pop rcx
0000708296fd2dd7  pop rax
0000708296fd2dd8  add rsp, 0x08
0000708296fd2ddc  jmp 0x0000708296FCFE15
0000708296fd2de1  sub rsp, 0x08
0000708296fd2de5  push rax
0000708296fd2de6  push rcx
0000708296fd2de7  push rdx
0000708296fd2de8  push rdi
0000708296fd2de9  push rsi
0000708296fd2dea  push r8
0000708296fd2dec  push r9
0000708296fd2dee  push r10
0000708296fd2df0  push r11
0000708296fd2df2  sub rsp, 0xF0
0000708296fd2df9  vmovaps [rsp], xmm0
0000708296fd2dfe  vmovaps [rsp+0x10], xmm2
0000708296fd2e04  vmovaps [rsp+0x20], xmm3
0000708296fd2e0a  vmovaps [rsp+0x30], xmm4
0000708296fd2e10  vmovaps [rsp+0x40], xmm5
0000708296fd2e16  vmovaps [rsp+0x50], xmm6
0000708296fd2e1c  vmovaps [rsp+0x60], xmm7
0000708296fd2e22  vmovaps [rsp+0x70], xmm8
0000708296fd2e28  vmovaps [rsp+0x80], xmm9
0000708296fd2e31  vmovaps [rsp+0x90], xmm10
0000708296fd2e3a  vmovaps [rsp+0xA0], xmm11
0000708296fd2e43  vmovaps [rsp+0xB0], xmm12
0000708296fd2e4c  vmovaps [rsp+0xC0], xmm13
0000708296fd2e55  vmovaps [rsp+0xD0], xmm14
0000708296fd2e5e  vmovaps [rsp+0xE0], xmm15
0000708296fd2e67  sub rsp, 0x30
0000708296fd2e6b  movaps [rsp], xmm1
0000708296fd2e6f  movaps [rsp+0x10], xmm15
0000708296fd2e75  movaps [rsp+0x20], xmm10
0000708296fd2e7b  lea rdi, [rsp]
0000708296fd2e7f  mov esi, 0x00
0000708296fd2e84  mov rax, 0x64BBC686C530
0000708296fd2e8e  call rax
0000708296fd2e90  movaps xmm1, [rsp]
0000708296fd2e94  add rsp, 0x30
0000708296fd2e98  vmovaps xmm0, [rsp]
0000708296fd2e9d  vmovaps xmm2, [rsp+0x10]
0000708296fd2ea3  vmovaps xmm3, [rsp+0x20]
0000708296fd2ea9  vmovaps xmm4, [rsp+0x30]
0000708296fd2eaf  vmovaps xmm5, [rsp+0x40]
0000708296fd2eb5  vmovaps xmm6, [rsp+0x50]
0000708296fd2ebb  vmovaps xmm7, [rsp+0x60]
0000708296fd2ec1  vmovaps xmm8, [rsp+0x70]
0000708296fd2ec7  vmovaps xmm9, [rsp+0x80]
0000708296fd2ed0  vmovaps xmm10, [rsp+0x90]
0000708296fd2ed9  vmovaps xmm11, [rsp+0xA0]
0000708296fd2ee2  vmovaps xmm12, [rsp+0xB0]
0000708296fd2eeb  vmovaps xmm13, [rsp+0xC0]
0000708296fd2ef4  vmovaps xmm14, [rsp+0xD0]
0000708296fd2efd  vmovaps xmm15, [rsp+0xE0]
0000708296fd2f06  add rsp, 0xF0
0000708296fd2f0d  pop r11
0000708296fd2f0f  pop r10
0000708296fd2f11  pop r9
0000708296fd2f13  pop r8
0000708296fd2f15  pop rsi
0000708296fd2f16  pop rdi
0000708296fd2f17  pop rdx
0000708296fd2f18  pop rcx
0000708296fd2f19  pop rax
0000708296fd2f1a  add rsp, 0x08
0000708296fd2f1e  jmp 0x0000708296FCFE34
0000708296fd2f23  sub rsp, 0x08
0000708296fd2f27  push rax
0000708296fd2f28  push rcx
0000708296fd2f29  push rdx
0000708296fd2f2a  push rdi
0000708296fd2f2b  push rsi
0000708296fd2f2c  push r8
0000708296fd2f2e  push r9
0000708296fd2f30  push r10
0000708296fd2f32  push r11
0000708296fd2f34  sub rsp, 0xF0
0000708296fd2f3b  vmovaps [rsp], xmm0
0000708296fd2f40  vmovaps [rsp+0x10], xmm1
0000708296fd2f46  vmovaps [rsp+0x20], xmm2
0000708296fd2f4c  vmovaps [rsp+0x30], xmm3
0000708296fd2f52  vmovaps [rsp+0x40], xmm4
0000708296fd2f58  vmovaps [rsp+0x50], xmm5
0000708296fd2f5e  vmovaps [rsp+0x60], xmm6
0000708296fd2f64  vmovaps [rsp+0x70], xmm7
0000708296fd2f6a  vmovaps [rsp+0x80], xmm8
0000708296fd2f73  vmovaps [rsp+0x90], xmm9
0000708296fd2f7c  vmovaps [rsp+0xA0], xmm10
0000708296fd2f85  vmovaps [rsp+0xB0], xmm11
0000708296fd2f8e  vmovaps [rsp+0xC0], xmm12
0000708296fd2f97  vmovaps [rsp+0xD0], xmm13
0000708296fd2fa0  vmovaps [rsp+0xE0], xmm14
0000708296fd2fa9  sub rsp, 0x30
0000708296fd2fad  movaps [rsp], xmm15
0000708296fd2fb2  movaps [rsp+0x10], xmm10
0000708296fd2fb8  movaps [rsp+0x20], xmm11
0000708296fd2fbe  lea rdi, [rsp]
0000708296fd2fc2  mov esi, 0x00
0000708296fd2fc7  mov rax, 0x64BBC686C530
0000708296fd2fd1  call rax
0000708296fd2fd3  movaps xmm15, [rsp]
0000708296fd2fd8  add rsp, 0x30
0000708296fd2fdc  vmovaps xmm0, [rsp]
0000708296fd2fe1  vmovaps xmm1, [rsp+0x10]
0000708296fd2fe7  vmovaps xmm2, [rsp+0x20]
0000708296fd2fed  vmovaps xmm3, [rsp+0x30]
0000708296fd2ff3  vmovaps xmm4, [rsp+0x40]
0000708296fd2ff9  vmovaps xmm5, [rsp+0x50]
0000708296fd2fff  vmovaps xmm6, [rsp+0x60]
0000708296fd3005  vmovaps xmm7, [rsp+0x70]
0000708296fd300b  vmovaps xmm8, [rsp+0x80]
0000708296fd3014  vmovaps xmm9, [rsp+0x90]
0000708296fd301d  vmovaps xmm10, [rsp+0xA0]
0000708296fd3026  vmovaps xmm11, [rsp+0xB0]
0000708296fd302f  vmovaps xmm12, [rsp+0xC0]
0000708296fd3038  vmovaps xmm13, [rsp+0xD0]
0000708296fd3041  vmovaps xmm14, [rsp+0xE0]
0000708296fd304a  add rsp, 0xF0
0000708296fd3051  pop r11
0000708296fd3053  pop r10
0000708296fd3055  pop r9
0000708296fd3057  pop r8
0000708296fd3059  pop rsi
0000708296fd305a  pop rdi
0000708296fd305b  pop rdx
0000708296fd305c  pop rcx
0000708296fd305d  pop rax
0000708296fd305e  add rsp, 0x08
0000708296fd3062  jmp 0x0000708296FCFE57
0000708296fd3067  sub rsp, 0x08
0000708296fd306b  push rax
0000708296fd306c  push rcx
0000708296fd306d  push rdx
0000708296fd306e  push rdi
0000708296fd306f  push rsi
0000708296fd3070  push r8
0000708296fd3072  push r9
0000708296fd3074  push r10
0000708296fd3076  push r11
0000708296fd3078  sub rsp, 0xF0
0000708296fd307f  vmovaps [rsp], xmm0
0000708296fd3084  vmovaps [rsp+0x10], xmm1
0000708296fd308a  vmovaps [rsp+0x20], xmm2
0000708296fd3090  vmovaps [rsp+0x30], xmm3
0000708296fd3096  vmovaps [rsp+0x40], xmm4
0000708296fd309c  vmovaps [rsp+0x50], xmm5
0000708296fd30a2  vmovaps [rsp+0x60], xmm6
0000708296fd30a8  vmovaps [rsp+0x70], xmm7
0000708296fd30ae  vmovaps [rsp+0x80], xmm8
0000708296fd30b7  vmovaps [rsp+0x90], xmm9
0000708296fd30c0  vmovaps [rsp+0xA0], xmm11
0000708296fd30c9  vmovaps [rsp+0xB0], xmm12
0000708296fd30d2  vmovaps [rsp+0xC0], xmm13
0000708296fd30db  vmovaps [rsp+0xD0], xmm14
0000708296fd30e4  vmovaps [rsp+0xE0], xmm15
0000708296fd30ed  sub rsp, 0x30
0000708296fd30f1  movaps [rsp], xmm10
0000708296fd30f6  movaps [rsp+0x10], xmm12
0000708296fd30fc  movaps [rsp+0x20], xmm11
0000708296fd3102  lea rdi, [rsp]
0000708296fd3106  mov esi, 0x00
0000708296fd310b  mov rax, 0x64BBC686C530
0000708296fd3115  call rax
0000708296fd3117  movaps xmm10, [rsp]
0000708296fd311c  add rsp, 0x30
0000708296fd3120  vmovaps xmm0, [rsp]
0000708296fd3125  vmovaps xmm1, [rsp+0x10]
0000708296fd312b  vmovaps xmm2, [rsp+0x20]
0000708296fd3131  vmovaps xmm3, [rsp+0x30]
0000708296fd3137  vmovaps xmm4, [rsp+0x40]
0000708296fd313d  vmovaps xmm5, [rsp+0x50]
0000708296fd3143  vmovaps xmm6, [rsp+0x60]
0000708296fd3149  vmovaps xmm7, [rsp+0x70]
0000708296fd314f  vmovaps xmm8, [rsp+0x80]
0000708296fd3158  vmovaps xmm9, [rsp+0x90]
0000708296fd3161  vmovaps xmm11, [rsp+0xA0]
0000708296fd316a  vmovaps xmm12, [rsp+0xB0]
0000708296fd3173  vmovaps xmm13, [rsp+0xC0]
0000708296fd317c  vmovaps xmm14, [rsp+0xD0]
0000708296fd3185  vmovaps xmm15, [rsp+0xE0]
0000708296fd318e  add rsp, 0xF0
0000708296fd3195  pop r11
0000708296fd3197  pop r10
0000708296fd3199  pop r9
0000708296fd319b  pop r8
0000708296fd319d  pop rsi
0000708296fd319e  pop rdi
0000708296fd319f  pop rdx
0000708296fd31a0  pop rcx
0000708296fd31a1  pop rax
0000708296fd31a2  add rsp, 0x08
0000708296fd31a6  jmp 0x0000708296FCFE80
0000708296fd31ab  sub rsp, 0x08
0000708296fd31af  push rax
0000708296fd31b0  push rcx
0000708296fd31b1  push rdx
0000708296fd31b2  push rdi
0000708296fd31b3  push rsi
0000708296fd31b4  push r8
0000708296fd31b6  push r9
0000708296fd31b8  push r10
0000708296fd31ba  push r11
0000708296fd31bc  sub rsp, 0xF0
0000708296fd31c3  vmovaps [rsp], xmm0
0000708296fd31c8  vmovaps [rsp+0x10], xmm1
0000708296fd31ce  vmovaps [rsp+0x20], xmm2
0000708296fd31d4  vmovaps [rsp+0x30], xmm3
0000708296fd31da  vmovaps [rsp+0x40], xmm4
0000708296fd31e0  vmovaps [rsp+0x50], xmm5
0000708296fd31e6  vmovaps [rsp+0x60], xmm6
0000708296fd31ec  vmovaps [rsp+0x70], xmm7
0000708296fd31f2  vmovaps [rsp+0x80], xmm8
0000708296fd31fb  vmovaps [rsp+0x90], xmm9
0000708296fd3204  vmovaps [rsp+0xA0], xmm10
0000708296fd320d  vmovaps [rsp+0xB0], xmm12
0000708296fd3216  vmovaps [rsp+0xC0], xmm13
0000708296fd321f  vmovaps [rsp+0xD0], xmm14
0000708296fd3228  vmovaps [rsp+0xE0], xmm15
0000708296fd3231  sub rsp, 0x30
0000708296fd3235  movaps [rsp], xmm11
0000708296fd323a  movaps [rsp+0x10], xmm2
0000708296fd323f  movaps [rsp+0x20], xmm12
0000708296fd3245  lea rdi, [rsp]
0000708296fd3249  mov esi, 0x00
0000708296fd324e  mov rax, 0x64BBC686C530
0000708296fd3258  call rax
0000708296fd325a  movaps xmm11, [rsp]
0000708296fd325f  add rsp, 0x30
0000708296fd3263  vmovaps xmm0, [rsp]
0000708296fd3268  vmovaps xmm1, [rsp+0x10]
0000708296fd326e  vmovaps xmm2, [rsp+0x20]
0000708296fd3274  vmovaps xmm3, [rsp+0x30]
0000708296fd327a  vmovaps xmm4, [rsp+0x40]
0000708296fd3280  vmovaps xmm5, [rsp+0x50]
0000708296fd3286  vmovaps xmm6, [rsp+0x60]
0000708296fd328c  vmovaps xmm7, [rsp+0x70]
0000708296fd3292  vmovaps xmm8, [rsp+0x80]
0000708296fd329b  vmovaps xmm9, [rsp+0x90]
0000708296fd32a4  vmovaps xmm10, [rsp+0xA0]
0000708296fd32ad  vmovaps xmm12, [rsp+0xB0]
0000708296fd32b6  vmovaps xmm13, [rsp+0xC0]
0000708296fd32bf  vmovaps xmm14, [rsp+0xD0]
0000708296fd32c8  vmovaps xmm15, [rsp+0xE0]
0000708296fd32d1  add rsp, 0xF0
0000708296fd32d8  pop r11
0000708296fd32da  pop r10
0000708296fd32dc  pop r9
0000708296fd32de  pop r8
0000708296fd32e0  pop rsi
0000708296fd32e1  pop rdi
0000708296fd32e2  pop rdx
0000708296fd32e3  pop rcx
0000708296fd32e4  pop rax
0000708296fd32e5  add rsp, 0x08
0000708296fd32e9  jmp 0x0000708296FCFEB8
0000708296fd32ee  sub rsp, 0x08
0000708296fd32f2  push rax
0000708296fd32f3  push rcx
0000708296fd32f4  push rdx
0000708296fd32f5  push rdi
0000708296fd32f6  push rsi
0000708296fd32f7  push r8
0000708296fd32f9  push r9
0000708296fd32fb  push r10
0000708296fd32fd  push r11
0000708296fd32ff  sub rsp, 0xF0
0000708296fd3306  vmovaps [rsp], xmm0
0000708296fd330b  vmovaps [rsp+0x10], xmm2
0000708296fd3311  vmovaps [rsp+0x20], xmm3
0000708296fd3317  vmovaps [rsp+0x30], xmm4
0000708296fd331d  vmovaps [rsp+0x40], xmm5
0000708296fd3323  vmovaps [rsp+0x50], xmm6
0000708296fd3329  vmovaps [rsp+0x60], xmm7
0000708296fd332f  vmovaps [rsp+0x70], xmm8
0000708296fd3335  vmovaps [rsp+0x80], xmm9
0000708296fd333e  vmovaps [rsp+0x90], xmm10
0000708296fd3347  vmovaps [rsp+0xA0], xmm11
0000708296fd3350  vmovaps [rsp+0xB0], xmm12
0000708296fd3359  vmovaps [rsp+0xC0], xmm13
0000708296fd3362  vmovaps [rsp+0xD0], xmm14
0000708296fd336b  vmovaps [rsp+0xE0], xmm15
0000708296fd3374  sub rsp, 0x30
0000708296fd3378  movaps [rsp], xmm1
0000708296fd337c  movaps [rsp+0x10], xmm14
0000708296fd3382  movaps [rsp+0x20], xmm6
0000708296fd3387  lea rdi, [rsp]
0000708296fd338b  mov esi, 0x00
0000708296fd3390  mov rax, 0x64BBC686C530
0000708296fd339a  call rax
0000708296fd339c  movaps xmm1, [rsp]
0000708296fd33a0  add rsp, 0x30
0000708296fd33a4  vmovaps xmm0, [rsp]
0000708296fd33a9  vmovaps xmm2, [rsp+0x10]
0000708296fd33af  vmovaps xmm3, [rsp+0x20]
0000708296fd33b5  vmovaps xmm4, [rsp+0x30]
0000708296fd33bb  vmovaps xmm5, [rsp+0x40]
0000708296fd33c1  vmovaps xmm6, [rsp+0x50]
0000708296fd33c7  vmovaps xmm7, [rsp+0x60]
0000708296fd33cd  vmovaps xmm8, [rsp+0x70]
0000708296fd33d3  vmovaps xmm9, [rsp+0x80]
0000708296fd33dc  vmovaps xmm10, [rsp+0x90]
0000708296fd33e5  vmovaps xmm11, [rsp+0xA0]
0000708296fd33ee  vmovaps xmm12, [rsp+0xB0]
0000708296fd33f7  vmovaps xmm13, [rsp+0xC0]
0000708296fd3400  vmovaps xmm14, [rsp+0xD0]
0000708296fd3409  vmovaps xmm15, [rsp+0xE0]
0000708296fd3412  add rsp, 0xF0
0000708296fd3419  pop r11
0000708296fd341b  pop r10
0000708296fd341d  pop r9
0000708296fd341f  pop r8
0000708296fd3421  pop rsi
0000708296fd3422  pop rdi
0000708296fd3423  pop rdx
0000708296fd3424  pop rcx
0000708296fd3425  pop rax
0000708296fd3426  add rsp, 0x08
0000708296fd342a  jmp 0x0000708296FCFED1
0000708296fd342f  sub rsp, 0x08
0000708296fd3433  push rax
0000708296fd3434  push rcx
0000708296fd3435  push rdx
0000708296fd3436  push rdi
0000708296fd3437  push rsi
0000708296fd3438  push r8
0000708296fd343a  push r9
0000708296fd343c  push r10
0000708296fd343e  push r11
0000708296fd3440  sub rsp, 0xF0
0000708296fd3447  vmovaps [rsp], xmm0
0000708296fd344c  vmovaps [rsp+0x10], xmm1
0000708296fd3452  vmovaps [rsp+0x20], xmm2
0000708296fd3458  vmovaps [rsp+0x30], xmm3
0000708296fd345e  vmovaps [rsp+0x40], xmm4
0000708296fd3464  vmovaps [rsp+0x50], xmm5
0000708296fd346a  vmovaps [rsp+0x60], xmm6
0000708296fd3470  vmovaps [rsp+0x70], xmm7
0000708296fd3476  vmovaps [rsp+0x80], xmm8
0000708296fd347f  vmovaps [rsp+0x90], xmm9
0000708296fd3488  vmovaps [rsp+0xA0], xmm10
0000708296fd3491  vmovaps [rsp+0xB0], xmm11
0000708296fd349a  vmovaps [rsp+0xC0], xmm12
0000708296fd34a3  vmovaps [rsp+0xD0], xmm13
0000708296fd34ac  vmovaps [rsp+0xE0], xmm15
0000708296fd34b5  sub rsp, 0x30
0000708296fd34b9  movaps [rsp], xmm14
0000708296fd34be  movaps [rsp+0x10], xmm12
0000708296fd34c4  movaps [rsp+0x20], xmm5
0000708296fd34c9  lea rdi, [rsp]
0000708296fd34cd  mov esi, 0x00
0000708296fd34d2  mov rax, 0x64BBC686C530
0000708296fd34dc  call rax
0000708296fd34de  movaps xmm14, [rsp]
0000708296fd34e3  add rsp, 0x30
0000708296fd34e7  vmovaps xmm0, [rsp]
0000708296fd34ec  vmovaps xmm1, [rsp+0x10]
0000708296fd34f2  vmovaps xmm2, [rsp+0x20]
0000708296fd34f8  vmovaps xmm3, [rsp+0x30]
0000708296fd34fe  vmovaps xmm4, [rsp+0x40]
0000708296fd3504  vmovaps xmm5, [rsp+0x50]
0000708296fd350a  vmovaps xmm6, [rsp+0x60]
0000708296fd3510  vmovaps xmm7, [rsp+0x70]
0000708296fd3516  vmovaps xmm8, [rsp+0x80]
0000708296fd351f  vmovaps xmm9, [rsp+0x90]
0000708296fd3528  vmovaps xmm10, [rsp+0xA0]
0000708296fd3531  vmovaps xmm11, [rsp+0xB0]
0000708296fd353a  vmovaps xmm12, [rsp+0xC0]
0000708296fd3543  vmovaps xmm13, [rsp+0xD0]
0000708296fd354c  vmovaps xmm15, [rsp+0xE0]
0000708296fd3555  add rsp, 0xF0
0000708296fd355c  pop r11
0000708296fd355e  pop r10
0000708296fd3560  pop r9
0000708296fd3562  pop r8
0000708296fd3564  pop rsi
0000708296fd3565  pop rdi
0000708296fd3566  pop rdx
0000708296fd3567  pop rcx
0000708296fd3568  pop rax
0000708296fd3569  add rsp, 0x08
0000708296fd356d  jmp 0x0000708296FCFEF1
0000708296fd3572  sub rsp, 0x08
0000708296fd3576  push rax
0000708296fd3577  push rcx
0000708296fd3578  push rdx
0000708296fd3579  push rdi
0000708296fd357a  push rsi
0000708296fd357b  push r8
0000708296fd357d  push r9
0000708296fd357f  push r10
0000708296fd3581  push r11
0000708296fd3583  sub rsp, 0xF0
0000708296fd358a  vmovaps [rsp], xmm0
0000708296fd358f  vmovaps [rsp+0x10], xmm1
0000708296fd3595  vmovaps [rsp+0x20], xmm2
0000708296fd359b  vmovaps [rsp+0x30], xmm3
0000708296fd35a1  vmovaps [rsp+0x40], xmm4
0000708296fd35a7  vmovaps [rsp+0x50], xmm5
0000708296fd35ad  vmovaps [rsp+0x60], xmm7
0000708296fd35b3  vmovaps [rsp+0x70], xmm8
0000708296fd35b9  vmovaps [rsp+0x80], xmm9
0000708296fd35c2  vmovaps [rsp+0x90], xmm10
0000708296fd35cb  vmovaps [rsp+0xA0], xmm11
0000708296fd35d4  vmovaps [rsp+0xB0], xmm12
0000708296fd35dd  vmovaps [rsp+0xC0], xmm13
0000708296fd35e6  vmovaps [rsp+0xD0], xmm14
0000708296fd35ef  vmovaps [rsp+0xE0], xmm15
0000708296fd35f8  sub rsp, 0x30
0000708296fd35fc  movaps [rsp], xmm6
0000708296fd3600  movaps [rsp+0x10], xmm9
0000708296fd3606  movaps [rsp+0x20], xmm12
0000708296fd360c  lea rdi, [rsp]
0000708296fd3610  mov esi, 0x00
0000708296fd3615  mov rax, 0x64BBC686C530
0000708296fd361f  call rax
0000708296fd3621  movaps xmm6, [rsp]
0000708296fd3625  add rsp, 0x30
0000708296fd3629  vmovaps xmm0, [rsp]
0000708296fd362e  vmovaps xmm1, [rsp+0x10]
0000708296fd3634  vmovaps xmm2, [rsp+0x20]
0000708296fd363a  vmovaps xmm3, [rsp+0x30]
0000708296fd3640  vmovaps xmm4, [rsp+0x40]
0000708296fd3646  vmovaps xmm5, [rsp+0x50]
0000708296fd364c  vmovaps xmm7, [rsp+0x60]
0000708296fd3652  vmovaps xmm8, [rsp+0x70]
0000708296fd3658  vmovaps xmm9, [rsp+0x80]
0000708296fd3661  vmovaps xmm10, [rsp+0x90]
0000708296fd366a  vmovaps xmm11, [rsp+0xA0]
0000708296fd3673  vmovaps xmm12, [rsp+0xB0]
0000708296fd367c  vmovaps xmm13, [rsp+0xC0]
0000708296fd3685  vmovaps xmm14, [rsp+0xD0]
0000708296fd368e  vmovaps xmm15, [rsp+0xE0]
0000708296fd3697  add rsp, 0xF0
0000708296fd369e  pop r11
0000708296fd36a0  pop r10
0000708296fd36a2  pop r9
0000708296fd36a4  pop r8
0000708296fd36a6  pop rsi
0000708296fd36a7  pop rdi
0000708296fd36a8  pop rdx
0000708296fd36a9  pop rcx
0000708296fd36aa  pop rax
0000708296fd36ab  add rsp, 0x08
0000708296fd36af  jmp 0x0000708296FCFF19
0000708296fd36b4  sub rsp, 0x08
0000708296fd36b8  push rax
0000708296fd36b9  push rcx
0000708296fd36ba  push rdx
0000708296fd36bb  push rdi
0000708296fd36bc  push rsi
0000708296fd36bd  push r8
0000708296fd36bf  push r9
0000708296fd36c1  push r10
0000708296fd36c3  push r11
0000708296fd36c5  sub rsp, 0xF0
0000708296fd36cc  vmovaps [rsp], xmm0
0000708296fd36d1  vmovaps [rsp+0x10], xmm1
0000708296fd36d7  vmovaps [rsp+0x20], xmm2
0000708296fd36dd  vmovaps [rsp+0x30], xmm3
0000708296fd36e3  vmovaps [rsp+0x40], xmm4
0000708296fd36e9  vmovaps [rsp+0x50], xmm5
0000708296fd36ef  vmovaps [rsp+0x60], xmm6
0000708296fd36f5  vmovaps [rsp+0x70], xmm7
0000708296fd36fb  vmovaps [rsp+0x80], xmm8
0000708296fd3704  vmovaps [rsp+0x90], xmm9
0000708296fd370d  vmovaps [rsp+0xA0], xmm10
0000708296fd3716  vmovaps [rsp+0xB0], xmm11
0000708296fd371f  vmovaps [rsp+0xC0], xmm13
0000708296fd3728  vmovaps [rsp+0xD0], xmm14
0000708296fd3731  vmovaps [rsp+0xE0], xmm15
0000708296fd373a  sub rsp, 0x30
0000708296fd373e  movaps [rsp], xmm12
0000708296fd3743  movaps [rsp+0x10], xmm15
0000708296fd3749  movaps [rsp+0x20], xmm13
0000708296fd374f  lea rdi, [rsp]
0000708296fd3753  mov esi, 0x00
0000708296fd3758  mov rax, 0x64BBC686C530
0000708296fd3762  call rax
0000708296fd3764  movaps xmm12, [rsp]
0000708296fd3769  add rsp, 0x30
0000708296fd376d  vmovaps xmm0, [rsp]
0000708296fd3772  vmovaps xmm1, [rsp+0x10]
0000708296fd3778  vmovaps xmm2, [rsp+0x20]
0000708296fd377e  vmovaps xmm3, [rsp+0x30]
0000708296fd3784  vmovaps xmm4, [rsp+0x40]
0000708296fd378a  vmovaps xmm5, [rsp+0x50]
0000708296fd3790  vmovaps xmm6, [rsp+0x60]
0000708296fd3796  vmovaps xmm7, [rsp+0x70]
0000708296fd379c  vmovaps xmm8, [rsp+0x80]
0000708296fd37a5  vmovaps xmm9, [rsp+0x90]
0000708296fd37ae  vmovaps xmm10, [rsp+0xA0]
0000708296fd37b7  vmovaps xmm11, [rsp+0xB0]
0000708296fd37c0  vmovaps xmm13, [rsp+0xC0]
0000708296fd37c9  vmovaps xmm14, [rsp+0xD0]
0000708296fd37d2  vmovaps xmm15, [rsp+0xE0]
0000708296fd37db  add rsp, 0xF0
0000708296fd37e2  pop r11
0000708296fd37e4  pop r10
0000708296fd37e6  pop r9
0000708296fd37e8  pop r8
0000708296fd37ea  pop rsi
0000708296fd37eb  pop rdi
0000708296fd37ec  pop rdx
0000708296fd37ed  pop rcx
0000708296fd37ee  pop rax
0000708296fd37ef  add rsp, 0x08
0000708296fd37f3  jmp 0x0000708296FCFF34
0000708296fd37f8  sub rsp, 0x08
0000708296fd37fc  push rax
0000708296fd37fd  push rcx
0000708296fd37fe  push rdx
0000708296fd37ff  push rdi
0000708296fd3800  push rsi
0000708296fd3801  push r8
0000708296fd3803  push r9
0000708296fd3805  push r10
0000708296fd3807  push r11
0000708296fd3809  sub rsp, 0xF0
0000708296fd3810  vmovaps [rsp], xmm0
0000708296fd3815  vmovaps [rsp+0x10], xmm1
0000708296fd381b  vmovaps [rsp+0x20], xmm2
0000708296fd3821  vmovaps [rsp+0x30], xmm3
0000708296fd3827  vmovaps [rsp+0x40], xmm4
0000708296fd382d  vmovaps [rsp+0x50], xmm5
0000708296fd3833  vmovaps [rsp+0x60], xmm6
0000708296fd3839  vmovaps [rsp+0x70], xmm7
0000708296fd383f  vmovaps [rsp+0x80], xmm8
0000708296fd3848  vmovaps [rsp+0x90], xmm9
0000708296fd3851  vmovaps [rsp+0xA0], xmm10
0000708296fd385a  vmovaps [rsp+0xB0], xmm11
0000708296fd3863  vmovaps [rsp+0xC0], xmm12
0000708296fd386c  vmovaps [rsp+0xD0], xmm13
0000708296fd3875  vmovaps [rsp+0xE0], xmm14
0000708296fd387e  sub rsp, 0x30
0000708296fd3882  movaps [rsp], xmm15
0000708296fd3887  movaps [rsp+0x10], xmm13
0000708296fd388d  movaps [rsp+0x20], xmm10
0000708296fd3893  lea rdi, [rsp]
0000708296fd3897  mov esi, 0x00
0000708296fd389c  mov rax, 0x64BBC686C530
0000708296fd38a6  call rax
0000708296fd38a8  movaps xmm15, [rsp]
0000708296fd38ad  add rsp, 0x30
0000708296fd38b1  vmovaps xmm0, [rsp]
0000708296fd38b6  vmovaps xmm1, [rsp+0x10]
0000708296fd38bc  vmovaps xmm2, [rsp+0x20]
0000708296fd38c2  vmovaps xmm3, [rsp+0x30]
0000708296fd38c8  vmovaps xmm4, [rsp+0x40]
0000708296fd38ce  vmovaps xmm5, [rsp+0x50]
0000708296fd38d4  vmovaps xmm6, [rsp+0x60]
0000708296fd38da  vmovaps xmm7, [rsp+0x70]
0000708296fd38e0  vmovaps xmm8, [rsp+0x80]
0000708296fd38e9  vmovaps xmm9, [rsp+0x90]
0000708296fd38f2  vmovaps xmm10, [rsp+0xA0]
0000708296fd38fb  vmovaps xmm11, [rsp+0xB0]
0000708296fd3904  vmovaps xmm12, [rsp+0xC0]
0000708296fd390d  vmovaps xmm13, [rsp+0xD0]
0000708296fd3916  vmovaps xmm14, [rsp+0xE0]
0000708296fd391f  add rsp, 0xF0
0000708296fd3926  pop r11
0000708296fd3928  pop r10
0000708296fd392a  pop r9
0000708296fd392c  pop r8
0000708296fd392e  pop rsi
0000708296fd392f  pop rdi
0000708296fd3930  pop rdx
0000708296fd3931  pop rcx
0000708296fd3932  pop rax
0000708296fd3933  add rsp, 0x08
0000708296fd3937  jmp 0x0000708296FCFF55
0000708296fd393c  call 0x0000708296E0C260
0000708296fd3941  jmp 0x0000708296FCFFB0
0000708296fd3946  sub rsp, 0x08
0000708296fd394a  push rax
0000708296fd394b  push rcx
0000708296fd394c  push rdx
0000708296fd394d  push rdi
0000708296fd394e  push rsi
0000708296fd394f  push r8
0000708296fd3951  push r9
0000708296fd3953  push r10
0000708296fd3955  push r11
0000708296fd3957  sub rsp, 0xF0
0000708296fd395e  vmovaps [rsp], xmm0
0000708296fd3963  vmovaps [rsp+0x10], xmm1
0000708296fd3969  vmovaps [rsp+0x20], xmm2
0000708296fd396f  vmovaps [rsp+0x30], xmm3
0000708296fd3975  vmovaps [rsp+0x40], xmm4
0000708296fd397b  vmovaps [rsp+0x50], xmm5
0000708296fd3981  vmovaps [rsp+0x60], xmm6
0000708296fd3987  vmovaps [rsp+0x70], xmm7
0000708296fd398d  vmovaps [rsp+0x80], xmm8
0000708296fd3996  vmovaps [rsp+0x90], xmm10
0000708296fd399f  vmovaps [rsp+0xA0], xmm11
0000708296fd39a8  vmovaps [rsp+0xB0], xmm12
0000708296fd39b1  vmovaps [rsp+0xC0], xmm13
0000708296fd39ba  vmovaps [rsp+0xD0], xmm14
0000708296fd39c3  vmovaps [rsp+0xE0], xmm15
0000708296fd39cc  sub rsp, 0x30
0000708296fd39d0  movaps [rsp], xmm9
0000708296fd39d5  movaps [rsp+0x10], xmm8
0000708296fd39db  movaps [rsp+0x20], xmm10
0000708296fd39e1  lea rdi, [rsp]
0000708296fd39e5  mov esi, 0x00
0000708296fd39ea  mov rax, 0x64BBC686C530
0000708296fd39f4  call rax
0000708296fd39f6  movaps xmm9, [rsp]
0000708296fd39fb  add rsp, 0x30
0000708296fd39ff  vmovaps xmm0, [rsp]
0000708296fd3a04  vmovaps xmm1, [rsp+0x10]
0000708296fd3a0a  vmovaps xmm2, [rsp+0x20]
0000708296fd3a10  vmovaps xmm3, [rsp+0x30]
0000708296fd3a16  vmovaps xmm4, [rsp+0x40]
0000708296fd3a1c  vmovaps xmm5, [rsp+0x50]
0000708296fd3a22  vmovaps xmm6, [rsp+0x60]
0000708296fd3a28  vmovaps xmm7, [rsp+0x70]
0000708296fd3a2e  vmovaps xmm8, [rsp+0x80]
0000708296fd3a37  vmovaps xmm10, [rsp+0x90]
0000708296fd3a40  vmovaps xmm11, [rsp+0xA0]
0000708296fd3a49  vmovaps xmm12, [rsp+0xB0]
0000708296fd3a52  vmovaps xmm13, [rsp+0xC0]
0000708296fd3a5b  vmovaps xmm14, [rsp+0xD0]
0000708296fd3a64  vmovaps xmm15, [rsp+0xE0]
0000708296fd3a6d  add rsp, 0xF0
0000708296fd3a74  pop r11
0000708296fd3a76  pop r10
0000708296fd3a78  pop r9
0000708296fd3a7a  pop r8
0000708296fd3a7c  pop rsi
0000708296fd3a7d  pop rdi
0000708296fd3a7e  pop rdx
0000708296fd3a7f  pop rcx
0000708296fd3a80  pop rax
0000708296fd3a81  add rsp, 0x08
0000708296fd3a85  jmp 0x0000708296FCFFE1
0000708296fd3a8a  sub rsp, 0x08
0000708296fd3a8e  push rax
0000708296fd3a8f  push rcx
0000708296fd3a90  push rdx
0000708296fd3a91  push rdi
0000708296fd3a92  push rsi
0000708296fd3a93  push r8
0000708296fd3a95  push r9
0000708296fd3a97  push r10
0000708296fd3a99  push r11
0000708296fd3a9b  sub rsp, 0xF0
0000708296fd3aa2  vmovaps [rsp], xmm0
0000708296fd3aa7  vmovaps [rsp+0x10], xmm1
0000708296fd3aad  vmovaps [rsp+0x20], xmm2
0000708296fd3ab3  vmovaps [rsp+0x30], xmm3
0000708296fd3ab9  vmovaps [rsp+0x40], xmm4
0000708296fd3abf  vmovaps [rsp+0x50], xmm5
0000708296fd3ac5  vmovaps [rsp+0x60], xmm6
0000708296fd3acb  vmovaps [rsp+0x70], xmm7
0000708296fd3ad1  vmovaps [rsp+0x80], xmm8
0000708296fd3ada  vmovaps [rsp+0x90], xmm9
0000708296fd3ae3  vmovaps [rsp+0xA0], xmm11
0000708296fd3aec  vmovaps [rsp+0xB0], xmm12
0000708296fd3af5  vmovaps [rsp+0xC0], xmm13
0000708296fd3afe  vmovaps [rsp+0xD0], xmm14
0000708296fd3b07  vmovaps [rsp+0xE0], xmm15
0000708296fd3b10  sub rsp, 0x30
0000708296fd3b14  movaps [rsp], xmm10
0000708296fd3b19  movaps [rsp+0x10], xmm1
0000708296fd3b1e  movaps [rsp+0x20], xmm11
0000708296fd3b24  lea rdi, [rsp]
0000708296fd3b28  mov esi, 0x00
0000708296fd3b2d  mov rax, 0x64BBC686C530
0000708296fd3b37  call rax
0000708296fd3b39  movaps xmm10, [rsp]
0000708296fd3b3e  add rsp, 0x30
0000708296fd3b42  vmovaps xmm0, [rsp]
0000708296fd3b47  vmovaps xmm1, [rsp+0x10]
0000708296fd3b4d  vmovaps xmm2, [rsp+0x20]
0000708296fd3b53  vmovaps xmm3, [rsp+0x30]
0000708296fd3b59  vmovaps xmm4, [rsp+0x40]
0000708296fd3b5f  vmovaps xmm5, [rsp+0x50]
0000708296fd3b65  vmovaps xmm6, [rsp+0x60]
0000708296fd3b6b  vmovaps xmm7, [rsp+0x70]
0000708296fd3b71  vmovaps xmm8, [rsp+0x80]
0000708296fd3b7a  vmovaps xmm9, [rsp+0x90]
0000708296fd3b83  vmovaps xmm11, [rsp+0xA0]
0000708296fd3b8c  vmovaps xmm12, [rsp+0xB0]
0000708296fd3b95  vmovaps xmm13, [rsp+0xC0]
0000708296fd3b9e  vmovaps xmm14, [rsp+0xD0]
0000708296fd3ba7  vmovaps xmm15, [rsp+0xE0]
0000708296fd3bb0  add rsp, 0xF0
0000708296fd3bb7  pop r11
0000708296fd3bb9  pop r10
0000708296fd3bbb  pop r9
0000708296fd3bbd  pop r8
0000708296fd3bbf  pop rsi
0000708296fd3bc0  pop rdi
0000708296fd3bc1  pop rdx
0000708296fd3bc2  pop rcx
0000708296fd3bc3  pop rax
0000708296fd3bc4  add rsp, 0x08
0000708296fd3bc8  jmp 0x0000708296FCFFFC
0000708296fd3bcd  sub rsp, 0x08
0000708296fd3bd1  push rax
0000708296fd3bd2  push rcx
0000708296fd3bd3  push rdx
0000708296fd3bd4  push rdi
0000708296fd3bd5  push rsi
0000708296fd3bd6  push r8
0000708296fd3bd8  push r9
0000708296fd3bda  push r10
0000708296fd3bdc  push r11
0000708296fd3bde  sub rsp, 0xF0
0000708296fd3be5  vmovaps [rsp], xmm0
0000708296fd3bea  vmovaps [rsp+0x10], xmm2
0000708296fd3bf0  vmovaps [rsp+0x20], xmm3
0000708296fd3bf6  vmovaps [rsp+0x30], xmm4
0000708296fd3bfc  vmovaps [rsp+0x40], xmm5
0000708296fd3c02  vmovaps [rsp+0x50], xmm6
0000708296fd3c08  vmovaps [rsp+0x60], xmm7
0000708296fd3c0e  vmovaps [rsp+0x70], xmm8
0000708296fd3c14  vmovaps [rsp+0x80], xmm9
0000708296fd3c1d  vmovaps [rsp+0x90], xmm10
0000708296fd3c26  vmovaps [rsp+0xA0], xmm11
0000708296fd3c2f  vmovaps [rsp+0xB0], xmm12
0000708296fd3c38  vmovaps [rsp+0xC0], xmm13
0000708296fd3c41  vmovaps [rsp+0xD0], xmm14
0000708296fd3c4a  vmovaps [rsp+0xE0], xmm15
0000708296fd3c53  sub rsp, 0x30
0000708296fd3c57  movaps [rsp], xmm1
0000708296fd3c5b  movaps [rsp+0x10], xmm14
0000708296fd3c61  movaps [rsp+0x20], xmm6
0000708296fd3c66  lea rdi, [rsp]
0000708296fd3c6a  mov esi, 0x00
0000708296fd3c6f  mov rax, 0x64BBC686C530
0000708296fd3c79  call rax
0000708296fd3c7b  movaps xmm1, [rsp]
0000708296fd3c7f  add rsp, 0x30
0000708296fd3c83  vmovaps xmm0, [rsp]
0000708296fd3c88  vmovaps xmm2, [rsp+0x10]
0000708296fd3c8e  vmovaps xmm3, [rsp+0x20]
0000708296fd3c94  vmovaps xmm4, [rsp+0x30]
0000708296fd3c9a  vmovaps xmm5, [rsp+0x40]
0000708296fd3ca0  vmovaps xmm6, [rsp+0x50]
0000708296fd3ca6  vmovaps xmm7, [rsp+0x60]
0000708296fd3cac  vmovaps xmm8, [rsp+0x70]
0000708296fd3cb2  vmovaps xmm9, [rsp+0x80]
0000708296fd3cbb  vmovaps xmm10, [rsp+0x90]
0000708296fd3cc4  vmovaps xmm11, [rsp+0xA0]
0000708296fd3ccd  vmovaps xmm12, [rsp+0xB0]
0000708296fd3cd6  vmovaps xmm13, [rsp+0xC0]
0000708296fd3cdf  vmovaps xmm14, [rsp+0xD0]
0000708296fd3ce8  vmovaps xmm15, [rsp+0xE0]
0000708296fd3cf1  add rsp, 0xF0
0000708296fd3cf8  pop r11
0000708296fd3cfa  pop r10
0000708296fd3cfc  pop r9
0000708296fd3cfe  pop r8
0000708296fd3d00  pop rsi
0000708296fd3d01  pop rdi
0000708296fd3d02  pop rdx
0000708296fd3d03  pop rcx
0000708296fd3d04  pop rax
0000708296fd3d05  add rsp, 0x08
0000708296fd3d09  jmp 0x0000708296FD0015
0000708296fd3d0e  sub rsp, 0x08
0000708296fd3d12  push rax
0000708296fd3d13  push rcx
0000708296fd3d14  push rdx
0000708296fd3d15  push rdi
0000708296fd3d16  push rsi
0000708296fd3d17  push r8
0000708296fd3d19  push r9
0000708296fd3d1b  push r10
0000708296fd3d1d  push r11
0000708296fd3d1f  sub rsp, 0xF0
0000708296fd3d26  vmovaps [rsp], xmm0
0000708296fd3d2b  vmovaps [rsp+0x10], xmm1
0000708296fd3d31  vmovaps [rsp+0x20], xmm2
0000708296fd3d37  vmovaps [rsp+0x30], xmm3
0000708296fd3d3d  vmovaps [rsp+0x40], xmm4
0000708296fd3d43  vmovaps [rsp+0x50], xmm5
0000708296fd3d49  vmovaps [rsp+0x60], xmm6
0000708296fd3d4f  vmovaps [rsp+0x70], xmm7
0000708296fd3d55  vmovaps [rsp+0x80], xmm8
0000708296fd3d5e  vmovaps [rsp+0x90], xmm9
0000708296fd3d67  vmovaps [rsp+0xA0], xmm10
0000708296fd3d70  vmovaps [rsp+0xB0], xmm12
0000708296fd3d79  vmovaps [rsp+0xC0], xmm13
0000708296fd3d82  vmovaps [rsp+0xD0], xmm14
0000708296fd3d8b  vmovaps [rsp+0xE0], xmm15
0000708296fd3d94  sub rsp, 0x30
0000708296fd3d98  movaps [rsp], xmm11
0000708296fd3d9d  movaps [rsp+0x10], xmm13
0000708296fd3da3  movaps [rsp+0x20], xmm14
0000708296fd3da9  lea rdi, [rsp]
0000708296fd3dad  mov esi, 0x00
0000708296fd3db2  mov rax, 0x64BBC686C530
0000708296fd3dbc  call rax
0000708296fd3dbe  movaps xmm11, [rsp]
0000708296fd3dc3  add rsp, 0x30
0000708296fd3dc7  vmovaps xmm0, [rsp]
0000708296fd3dcc  vmovaps xmm1, [rsp+0x10]
0000708296fd3dd2  vmovaps xmm2, [rsp+0x20]
0000708296fd3dd8  vmovaps xmm3, [rsp+0x30]
0000708296fd3dde  vmovaps xmm4, [rsp+0x40]
0000708296fd3de4  vmovaps xmm5, [rsp+0x50]
0000708296fd3dea  vmovaps xmm6, [rsp+0x60]
0000708296fd3df0  vmovaps xmm7, [rsp+0x70]
0000708296fd3df6  vmovaps xmm8, [rsp+0x80]
0000708296fd3dff  vmovaps xmm9, [rsp+0x90]
0000708296fd3e08  vmovaps xmm10, [rsp+0xA0]
0000708296fd3e11  vmovaps xmm12, [rsp+0xB0]
0000708296fd3e1a  vmovaps xmm13, [rsp+0xC0]
0000708296fd3e23  vmovaps xmm14, [rsp+0xD0]
0000708296fd3e2c  vmovaps xmm15, [rsp+0xE0]
0000708296fd3e35  add rsp, 0xF0
0000708296fd3e3c  pop r11
0000708296fd3e3e  pop r10
0000708296fd3e40  pop r9
0000708296fd3e42  pop r8
0000708296fd3e44  pop rsi
0000708296fd3e45  pop rdi
0000708296fd3e46  pop rdx
0000708296fd3e47  pop rcx
0000708296fd3e48  pop rax
0000708296fd3e49  add rsp, 0x08
0000708296fd3e4d  jmp 0x0000708296FD003F
0000708296fd3e52  sub rsp, 0x08
0000708296fd3e56  push rax
0000708296fd3e57  push rcx
0000708296fd3e58  push rdx
0000708296fd3e59  push rdi
0000708296fd3e5a  push rsi
0000708296fd3e5b  push r8
0000708296fd3e5d  push r9
0000708296fd3e5f  push r10
0000708296fd3e61  push r11
0000708296fd3e63  sub rsp, 0xF0
0000708296fd3e6a  vmovaps [rsp], xmm0
0000708296fd3e6f  vmovaps [rsp+0x10], xmm1
0000708296fd3e75  vmovaps [rsp+0x20], xmm2
0000708296fd3e7b  vmovaps [rsp+0x30], xmm3
0000708296fd3e81  vmovaps [rsp+0x40], xmm4
0000708296fd3e87  vmovaps [rsp+0x50], xmm5
0000708296fd3e8d  vmovaps [rsp+0x60], xmm6
0000708296fd3e93  vmovaps [rsp+0x70], xmm7
0000708296fd3e99  vmovaps [rsp+0x80], xmm8
0000708296fd3ea2  vmovaps [rsp+0x90], xmm9
0000708296fd3eab  vmovaps [rsp+0xA0], xmm10
0000708296fd3eb4  vmovaps [rsp+0xB0], xmm11
0000708296fd3ebd  vmovaps [rsp+0xC0], xmm12
0000708296fd3ec6  vmovaps [rsp+0xD0], xmm14
0000708296fd3ecf  vmovaps [rsp+0xE0], xmm15
0000708296fd3ed8  sub rsp, 0x30
0000708296fd3edc  movaps [rsp], xmm13
0000708296fd3ee1  movaps [rsp+0x10], xmm8
0000708296fd3ee7  movaps [rsp+0x20], xmm14
0000708296fd3eed  lea rdi, [rsp]
0000708296fd3ef1  mov esi, 0x00
0000708296fd3ef6  mov rax, 0x64BBC686C530
0000708296fd3f00  call rax
0000708296fd3f02  movaps xmm13, [rsp]
0000708296fd3f07  add rsp, 0x30
0000708296fd3f0b  vmovaps xmm0, [rsp]
0000708296fd3f10  vmovaps xmm1, [rsp+0x10]
0000708296fd3f16  vmovaps xmm2, [rsp+0x20]
0000708296fd3f1c  vmovaps xmm3, [rsp+0x30]
0000708296fd3f22  vmovaps xmm4, [rsp+0x40]
0000708296fd3f28  vmovaps xmm5, [rsp+0x50]
0000708296fd3f2e  vmovaps xmm6, [rsp+0x60]
0000708296fd3f34  vmovaps xmm7, [rsp+0x70]
0000708296fd3f3a  vmovaps xmm8, [rsp+0x80]
0000708296fd3f43  vmovaps xmm9, [rsp+0x90]
0000708296fd3f4c  vmovaps xmm10, [rsp+0xA0]
0000708296fd3f55  vmovaps xmm11, [rsp+0xB0]
0000708296fd3f5e  vmovaps xmm12, [rsp+0xC0]
0000708296fd3f67  vmovaps xmm14, [rsp+0xD0]
0000708296fd3f70  vmovaps xmm15, [rsp+0xE0]
0000708296fd3f79  add rsp, 0xF0
0000708296fd3f80  pop r11
0000708296fd3f82  pop r10
0000708296fd3f84  pop r9
0000708296fd3f86  pop r8
0000708296fd3f88  pop rsi
0000708296fd3f89  pop rdi
0000708296fd3f8a  pop rdx
0000708296fd3f8b  pop rcx
0000708296fd3f8c  pop rax
0000708296fd3f8d  add rsp, 0x08
0000708296fd3f91  jmp 0x0000708296FD006E
0000708296fd3f96  sub rsp, 0x08
0000708296fd3f9a  push rax
0000708296fd3f9b  push rcx
0000708296fd3f9c  push rdx
0000708296fd3f9d  push rdi
0000708296fd3f9e  push rsi
0000708296fd3f9f  push r8
0000708296fd3fa1  push r9
0000708296fd3fa3  push r10
0000708296fd3fa5  push r11
0000708296fd3fa7  sub rsp, 0xF0
0000708296fd3fae  vmovaps [rsp], xmm0
0000708296fd3fb3  vmovaps [rsp+0x10], xmm1
0000708296fd3fb9  vmovaps [rsp+0x20], xmm2
0000708296fd3fbf  vmovaps [rsp+0x30], xmm3
0000708296fd3fc5  vmovaps [rsp+0x40], xmm4
0000708296fd3fcb  vmovaps [rsp+0x50], xmm5
0000708296fd3fd1  vmovaps [rsp+0x60], xmm6
0000708296fd3fd7  vmovaps [rsp+0x70], xmm7
0000708296fd3fdd  vmovaps [rsp+0x80], xmm9
0000708296fd3fe6  vmovaps [rsp+0x90], xmm10
0000708296fd3fef  vmovaps [rsp+0xA0], xmm11
0000708296fd3ff8  vmovaps [rsp+0xB0], xmm12
0000708296fd4001  vmovaps [rsp+0xC0], xmm13
0000708296fd400a  vmovaps [rsp+0xD0], xmm14
0000708296fd4013  vmovaps [rsp+0xE0], xmm15
0000708296fd401c  sub rsp, 0x30
0000708296fd4020  movaps [rsp], xmm8
0000708296fd4025  movaps [rsp+0x10], xmm7
0000708296fd402a  movaps [rsp+0x20], xmm14
0000708296fd4030  lea rdi, [rsp]
0000708296fd4034  mov esi, 0x00
0000708296fd4039  mov rax, 0x64BBC686C530
0000708296fd4043  call rax
0000708296fd4045  movaps xmm8, [rsp]
0000708296fd404a  add rsp, 0x30
0000708296fd404e  vmovaps xmm0, [rsp]
0000708296fd4053  vmovaps xmm1, [rsp+0x10]
0000708296fd4059  vmovaps xmm2, [rsp+0x20]
0000708296fd405f  vmovaps xmm3, [rsp+0x30]
0000708296fd4065  vmovaps xmm4, [rsp+0x40]
0000708296fd406b  vmovaps xmm5, [rsp+0x50]
0000708296fd4071  vmovaps xmm6, [rsp+0x60]
0000708296fd4077  vmovaps xmm7, [rsp+0x70]
0000708296fd407d  vmovaps xmm9, [rsp+0x80]
0000708296fd4086  vmovaps xmm10, [rsp+0x90]
0000708296fd408f  vmovaps xmm11, [rsp+0xA0]
0000708296fd4098  vmovaps xmm12, [rsp+0xB0]
0000708296fd40a1  vmovaps xmm13, [rsp+0xC0]
0000708296fd40aa  vmovaps xmm14, [rsp+0xD0]
0000708296fd40b3  vmovaps xmm15, [rsp+0xE0]
0000708296fd40bc  add rsp, 0xF0
0000708296fd40c3  pop r11
0000708296fd40c5  pop r10
0000708296fd40c7  pop r9
0000708296fd40c9  pop r8
0000708296fd40cb  pop rsi
0000708296fd40cc  pop rdi
0000708296fd40cd  pop rdx
0000708296fd40ce  pop rcx
0000708296fd40cf  pop rax
0000708296fd40d0  add rsp, 0x08
0000708296fd40d4  jmp 0x0000708296FD0094
0000708296fd40d9  sub rsp, 0x08
0000708296fd40dd  push rax
0000708296fd40de  push rcx
0000708296fd40df  push rdx
0000708296fd40e0  push rdi
0000708296fd40e1  push rsi
0000708296fd40e2  push r8
0000708296fd40e4  push r9
0000708296fd40e6  push r10
0000708296fd40e8  push r11
0000708296fd40ea  sub rsp, 0xF0
0000708296fd40f1  vmovaps [rsp], xmm0
0000708296fd40f6  vmovaps [rsp+0x10], xmm1
0000708296fd40fc  vmovaps [rsp+0x20], xmm2
0000708296fd4102  vmovaps [rsp+0x30], xmm3
0000708296fd4108  vmovaps [rsp+0x40], xmm4
0000708296fd410e  vmovaps [rsp+0x50], xmm5
0000708296fd4114  vmovaps [rsp+0x60], xmm6
0000708296fd411a  vmovaps [rsp+0x70], xmm7
0000708296fd4120  vmovaps [rsp+0x80], xmm8
0000708296fd4129  vmovaps [rsp+0x90], xmm9
0000708296fd4132  vmovaps [rsp+0xA0], xmm10
0000708296fd413b  vmovaps [rsp+0xB0], xmm11
0000708296fd4144  vmovaps [rsp+0xC0], xmm12
0000708296fd414d  vmovaps [rsp+0xD0], xmm13
0000708296fd4156  vmovaps [rsp+0xE0], xmm15
0000708296fd415f  sub rsp, 0x30
0000708296fd4163  movaps [rsp], xmm14
0000708296fd4168  movaps [rsp+0x10], xmm12
0000708296fd416e  movaps [rsp+0x20], xmm9
0000708296fd4174  lea rdi, [rsp]
0000708296fd4178  mov esi, 0x00
0000708296fd417d  mov rax, 0x64BBC686C530
0000708296fd4187  call rax
0000708296fd4189  movaps xmm14, [rsp]
0000708296fd418e  add rsp, 0x30
0000708296fd4192  vmovaps xmm0, [rsp]
0000708296fd4197  vmovaps xmm1, [rsp+0x10]
0000708296fd419d  vmovaps xmm2, [rsp+0x20]
0000708296fd41a3  vmovaps xmm3, [rsp+0x30]
0000708296fd41a9  vmovaps xmm4, [rsp+0x40]
0000708296fd41af  vmovaps xmm5, [rsp+0x50]
0000708296fd41b5  vmovaps xmm6, [rsp+0x60]
0000708296fd41bb  vmovaps xmm7, [rsp+0x70]
0000708296fd41c1  vmovaps xmm8, [rsp+0x80]
0000708296fd41ca  vmovaps xmm9, [rsp+0x90]
0000708296fd41d3  vmovaps xmm10, [rsp+0xA0]
0000708296fd41dc  vmovaps xmm11, [rsp+0xB0]
0000708296fd41e5  vmovaps xmm12, [rsp+0xC0]
0000708296fd41ee  vmovaps xmm13, [rsp+0xD0]
0000708296fd41f7  vmovaps xmm15, [rsp+0xE0]
0000708296fd4200  add rsp, 0xF0
0000708296fd4207  pop r11
0000708296fd4209  pop r10
0000708296fd420b  pop r9
0000708296fd420d  pop r8
0000708296fd420f  pop rsi
0000708296fd4210  pop rdi
0000708296fd4211  pop rdx
0000708296fd4212  pop rcx
0000708296fd4213  pop rax
0000708296fd4214  add rsp, 0x08
0000708296fd4218  jmp 0x0000708296FD00AE
0000708296fd421d  sub rsp, 0x08
0000708296fd4221  push rax
0000708296fd4222  push rcx
0000708296fd4223  push rdx
0000708296fd4224  push rdi
0000708296fd4225  push rsi
0000708296fd4226  push r8
0000708296fd4228  push r9
0000708296fd422a  push r10
0000708296fd422c  push r11
0000708296fd422e  sub rsp, 0xF0
0000708296fd4235  vmovaps [rsp], xmm0
0000708296fd423a  vmovaps [rsp+0x10], xmm1
0000708296fd4240  vmovaps [rsp+0x20], xmm2
0000708296fd4246  vmovaps [rsp+0x30], xmm3
0000708296fd424c  vmovaps [rsp+0x40], xmm4
0000708296fd4252  vmovaps [rsp+0x50], xmm5
0000708296fd4258  vmovaps [rsp+0x60], xmm6
0000708296fd425e  vmovaps [rsp+0x70], xmm7
0000708296fd4264  vmovaps [rsp+0x80], xmm8
0000708296fd426d  vmovaps [rsp+0x90], xmm10
0000708296fd4276  vmovaps [rsp+0xA0], xmm11
0000708296fd427f  vmovaps [rsp+0xB0], xmm12
0000708296fd4288  vmovaps [rsp+0xC0], xmm13
0000708296fd4291  vmovaps [rsp+0xD0], xmm14
0000708296fd429a  vmovaps [rsp+0xE0], xmm15
0000708296fd42a3  sub rsp, 0x30
0000708296fd42a7  movaps [rsp], xmm9
0000708296fd42ac  movaps [rsp+0x10], xmm7
0000708296fd42b1  movaps [rsp+0x20], xmm12
0000708296fd42b7  lea rdi, [rsp]
0000708296fd42bb  mov esi, 0x00
0000708296fd42c0  mov rax, 0x64BBC686C530
0000708296fd42ca  call rax
0000708296fd42cc  movaps xmm9, [rsp]
0000708296fd42d1  add rsp, 0x30
0000708296fd42d5  vmovaps xmm0, [rsp]
0000708296fd42da  vmovaps xmm1, [rsp+0x10]
0000708296fd42e0  vmovaps xmm2, [rsp+0x20]
0000708296fd42e6  vmovaps xmm3, [rsp+0x30]
0000708296fd42ec  vmovaps xmm4, [rsp+0x40]
0000708296fd42f2  vmovaps xmm5, [rsp+0x50]
0000708296fd42f8  vmovaps xmm6, [rsp+0x60]
0000708296fd42fe  vmovaps xmm7, [rsp+0x70]
0000708296fd4304  vmovaps xmm8, [rsp+0x80]
0000708296fd430d  vmovaps xmm10, [rsp+0x90]
0000708296fd4316  vmovaps xmm11, [rsp+0xA0]
0000708296fd431f  vmovaps xmm12, [rsp+0xB0]
0000708296fd4328  vmovaps xmm13, [rsp+0xC0]
0000708296fd4331  vmovaps xmm14, [rsp+0xD0]
0000708296fd433a  vmovaps xmm15, [rsp+0xE0]
0000708296fd4343  add rsp, 0xF0
0000708296fd434a  pop r11
0000708296fd434c  pop r10
0000708296fd434e  pop r9
0000708296fd4350  pop r8
0000708296fd4352  pop rsi
0000708296fd4353  pop rdi
0000708296fd4354  pop rdx
0000708296fd4355  pop rcx
0000708296fd4356  pop rax
0000708296fd4357  add rsp, 0x08
0000708296fd435b  jmp 0x0000708296FD00DD
0000708296fd4360  sub rsp, 0x08
0000708296fd4364  push rax
0000708296fd4365  push rcx
0000708296fd4366  push rdx
0000708296fd4367  push rdi
0000708296fd4368  push rsi
0000708296fd4369  push r8
0000708296fd436b  push r9
0000708296fd436d  push r10
0000708296fd436f  push r11
0000708296fd4371  sub rsp, 0xF0
0000708296fd4378  vmovaps [rsp], xmm0
0000708296fd437d  vmovaps [rsp+0x10], xmm1
0000708296fd4383  vmovaps [rsp+0x20], xmm2
0000708296fd4389  vmovaps [rsp+0x30], xmm3
0000708296fd438f  vmovaps [rsp+0x40], xmm4
0000708296fd4395  vmovaps [rsp+0x50], xmm5
0000708296fd439b  vmovaps [rsp+0x60], xmm6
0000708296fd43a1  vmovaps [rsp+0x70], xmm7
0000708296fd43a7  vmovaps [rsp+0x80], xmm8
0000708296fd43b0  vmovaps [rsp+0x90], xmm9
0000708296fd43b9  vmovaps [rsp+0xA0], xmm10
0000708296fd43c2  vmovaps [rsp+0xB0], xmm11
0000708296fd43cb  vmovaps [rsp+0xC0], xmm13
0000708296fd43d4  vmovaps [rsp+0xD0], xmm14
0000708296fd43dd  vmovaps [rsp+0xE0], xmm15
0000708296fd43e6  sub rsp, 0x30
0000708296fd43ea  movaps [rsp], xmm12
0000708296fd43ef  movaps [rsp+0x10], xmm15
0000708296fd43f5  movaps [rsp+0x20], xmm11
0000708296fd43fb  lea rdi, [rsp]
0000708296fd43ff  mov esi, 0x00
0000708296fd4404  mov rax, 0x64BBC686C530
0000708296fd440e  call rax
0000708296fd4410  movaps xmm12, [rsp]
0000708296fd4415  add rsp, 0x30
0000708296fd4419  vmovaps xmm0, [rsp]
0000708296fd441e  vmovaps xmm1, [rsp+0x10]
0000708296fd4424  vmovaps xmm2, [rsp+0x20]
0000708296fd442a  vmovaps xmm3, [rsp+0x30]
0000708296fd4430  vmovaps xmm4, [rsp+0x40]
0000708296fd4436  vmovaps xmm5, [rsp+0x50]
0000708296fd443c  vmovaps xmm6, [rsp+0x60]
0000708296fd4442  vmovaps xmm7, [rsp+0x70]
0000708296fd4448  vmovaps xmm8, [rsp+0x80]
0000708296fd4451  vmovaps xmm9, [rsp+0x90]
0000708296fd445a  vmovaps xmm10, [rsp+0xA0]
0000708296fd4463  vmovaps xmm11, [rsp+0xB0]
0000708296fd446c  vmovaps xmm13, [rsp+0xC0]
0000708296fd4475  vmovaps xmm14, [rsp+0xD0]
0000708296fd447e  vmovaps xmm15, [rsp+0xE0]
0000708296fd4487  add rsp, 0xF0
0000708296fd448e  pop r11
0000708296fd4490  pop r10
0000708296fd4492  pop r9
0000708296fd4494  pop r8
0000708296fd4496  pop rsi
0000708296fd4497  pop rdi
0000708296fd4498  pop rdx
0000708296fd4499  pop rcx
0000708296fd449a  pop rax
0000708296fd449b  add rsp, 0x08
0000708296fd449f  jmp 0x0000708296FD00F7
0000708296fd44a4  sub rsp, 0x08
0000708296fd44a8  push rax
0000708296fd44a9  push rcx
0000708296fd44aa  push rdx
0000708296fd44ab  push rdi
0000708296fd44ac  push rsi
0000708296fd44ad  push r8
0000708296fd44af  push r9
0000708296fd44b1  push r10
0000708296fd44b3  push r11
0000708296fd44b5  sub rsp, 0xF0
0000708296fd44bc  vmovaps [rsp], xmm0
0000708296fd44c1  vmovaps [rsp+0x10], xmm1
0000708296fd44c7  vmovaps [rsp+0x20], xmm2
0000708296fd44cd  vmovaps [rsp+0x30], xmm3
0000708296fd44d3  vmovaps [rsp+0x40], xmm4
0000708296fd44d9  vmovaps [rsp+0x50], xmm5
0000708296fd44df  vmovaps [rsp+0x60], xmm6
0000708296fd44e5  vmovaps [rsp+0x70], xmm7
0000708296fd44eb  vmovaps [rsp+0x80], xmm8
0000708296fd44f4  vmovaps [rsp+0x90], xmm9
0000708296fd44fd  vmovaps [rsp+0xA0], xmm10
0000708296fd4506  vmovaps [rsp+0xB0], xmm12
0000708296fd450f  vmovaps [rsp+0xC0], xmm13
0000708296fd4518  vmovaps [rsp+0xD0], xmm14
0000708296fd4521  vmovaps [rsp+0xE0], xmm15
0000708296fd452a  sub rsp, 0x30
0000708296fd452e  movaps [rsp], xmm11
0000708296fd4533  movaps [rsp+0x10], xmm7
0000708296fd4538  movaps [rsp+0x20], xmm15
0000708296fd453e  lea rdi, [rsp]
0000708296fd4542  mov esi, 0x00
0000708296fd4547  mov rax, 0x64BBC686C530
0000708296fd4551  call rax
0000708296fd4553  movaps xmm11, [rsp]
0000708296fd4558  add rsp, 0x30
0000708296fd455c  vmovaps xmm0, [rsp]
0000708296fd4561  vmovaps xmm1, [rsp+0x10]
0000708296fd4567  vmovaps xmm2, [rsp+0x20]
0000708296fd456d  vmovaps xmm3, [rsp+0x30]
0000708296fd4573  vmovaps xmm4, [rsp+0x40]
0000708296fd4579  vmovaps xmm5, [rsp+0x50]
0000708296fd457f  vmovaps xmm6, [rsp+0x60]
0000708296fd4585  vmovaps xmm7, [rsp+0x70]
0000708296fd458b  vmovaps xmm8, [rsp+0x80]
0000708296fd4594  vmovaps xmm9, [rsp+0x90]
0000708296fd459d  vmovaps xmm10, [rsp+0xA0]
0000708296fd45a6  vmovaps xmm12, [rsp+0xB0]
0000708296fd45af  vmovaps xmm13, [rsp+0xC0]
0000708296fd45b8  vmovaps xmm14, [rsp+0xD0]
0000708296fd45c1  vmovaps xmm15, [rsp+0xE0]
0000708296fd45ca  add rsp, 0xF0
0000708296fd45d1  pop r11
0000708296fd45d3  pop r10
0000708296fd45d5  pop r9
0000708296fd45d7  pop r8
0000708296fd45d9  pop rsi
0000708296fd45da  pop rdi
0000708296fd45db  pop rdx
0000708296fd45dc  pop rcx
0000708296fd45dd  pop rax
0000708296fd45de  add rsp, 0x08
0000708296fd45e2  jmp 0x0000708296FD0123
0000708296fd45e7  sub rsp, 0x08
0000708296fd45eb  push rax
0000708296fd45ec  push rcx
0000708296fd45ed  push rdx
0000708296fd45ee  push rdi
0000708296fd45ef  push rsi
0000708296fd45f0  push r8
0000708296fd45f2  push r9
0000708296fd45f4  push r10
0000708296fd45f6  push r11
0000708296fd45f8  sub rsp, 0xF0
0000708296fd45ff  vmovaps [rsp], xmm0
0000708296fd4604  vmovaps [rsp+0x10], xmm1
0000708296fd460a  vmovaps [rsp+0x20], xmm2
0000708296fd4610  vmovaps [rsp+0x30], xmm3
0000708296fd4616  vmovaps [rsp+0x40], xmm4
0000708296fd461c  vmovaps [rsp+0x50], xmm5
0000708296fd4622  vmovaps [rsp+0x60], xmm6
0000708296fd4628  vmovaps [rsp+0x70], xmm7
0000708296fd462e  vmovaps [rsp+0x80], xmm8
0000708296fd4637  vmovaps [rsp+0x90], xmm9
0000708296fd4640  vmovaps [rsp+0xA0], xmm10
0000708296fd4649  vmovaps [rsp+0xB0], xmm11
0000708296fd4652  vmovaps [rsp+0xC0], xmm12
0000708296fd465b  vmovaps [rsp+0xD0], xmm13
0000708296fd4664  vmovaps [rsp+0xE0], xmm14
0000708296fd466d  sub rsp, 0x30
0000708296fd4671  movaps [rsp], xmm15
0000708296fd4676  movaps [rsp+0x10], xmm10
0000708296fd467c  movaps [rsp+0x20], xmm13
0000708296fd4682  lea rdi, [rsp]
0000708296fd4686  mov esi, 0x00
0000708296fd468b  mov rax, 0x64BBC686C530
0000708296fd4695  call rax
0000708296fd4697  movaps xmm15, [rsp]
0000708296fd469c  add rsp, 0x30
0000708296fd46a0  vmovaps xmm0, [rsp]
0000708296fd46a5  vmovaps xmm1, [rsp+0x10]
0000708296fd46ab  vmovaps xmm2, [rsp+0x20]
0000708296fd46b1  vmovaps xmm3, [rsp+0x30]
0000708296fd46b7  vmovaps xmm4, [rsp+0x40]
0000708296fd46bd  vmovaps xmm5, [rsp+0x50]
0000708296fd46c3  vmovaps xmm6, [rsp+0x60]
0000708296fd46c9  vmovaps xmm7, [rsp+0x70]
0000708296fd46cf  vmovaps xmm8, [rsp+0x80]
0000708296fd46d8  vmovaps xmm9, [rsp+0x90]
0000708296fd46e1  vmovaps xmm10, [rsp+0xA0]
0000708296fd46ea  vmovaps xmm11, [rsp+0xB0]
0000708296fd46f3  vmovaps xmm12, [rsp+0xC0]
0000708296fd46fc  vmovaps xmm13, [rsp+0xD0]
0000708296fd4705  vmovaps xmm14, [rsp+0xE0]
0000708296fd470e  add rsp, 0xF0
0000708296fd4715  pop r11
0000708296fd4717  pop r10
0000708296fd4719  pop r9
0000708296fd471b  pop r8
0000708296fd471d  pop rsi
0000708296fd471e  pop rdi
0000708296fd471f  pop rdx
0000708296fd4720  pop rcx
0000708296fd4721  pop rax
0000708296fd4722  add rsp, 0x08
0000708296fd4726  jmp 0x0000708296FD013D
0000708296fd472b  sub rsp, 0x08
0000708296fd472f  push rax
0000708296fd4730  push rcx
0000708296fd4731  push rdx
0000708296fd4732  push rdi
0000708296fd4733  push rsi
0000708296fd4734  push r8
0000708296fd4736  push r9
0000708296fd4738  push r10
0000708296fd473a  push r11
0000708296fd473c  sub rsp, 0xF0
0000708296fd4743  vmovaps [rsp], xmm0
0000708296fd4748  vmovaps [rsp+0x10], xmm1
0000708296fd474e  vmovaps [rsp+0x20], xmm2
0000708296fd4754  vmovaps [rsp+0x30], xmm3
0000708296fd475a  vmovaps [rsp+0x40], xmm4
0000708296fd4760  vmovaps [rsp+0x50], xmm5
0000708296fd4766  vmovaps [rsp+0x60], xmm6
0000708296fd476c  vmovaps [rsp+0x70], xmm7
0000708296fd4772  vmovaps [rsp+0x80], xmm8
0000708296fd477b  vmovaps [rsp+0x90], xmm9
0000708296fd4784  vmovaps [rsp+0xA0], xmm11
0000708296fd478d  vmovaps [rsp+0xB0], xmm12
0000708296fd4796  vmovaps [rsp+0xC0], xmm13
0000708296fd479f  vmovaps [rsp+0xD0], xmm14
0000708296fd47a8  vmovaps [rsp+0xE0], xmm15
0000708296fd47b1  sub rsp, 0x30
0000708296fd47b5  movaps [rsp], xmm10
0000708296fd47ba  movaps [rsp+0x10], xmm7
0000708296fd47bf  movaps [rsp+0x20], xmm13
0000708296fd47c5  lea rdi, [rsp]
0000708296fd47c9  mov esi, 0x00
0000708296fd47ce  mov rax, 0x64BBC686C530
0000708296fd47d8  call rax
0000708296fd47da  movaps xmm10, [rsp]
0000708296fd47df  add rsp, 0x30
0000708296fd47e3  vmovaps xmm0, [rsp]
0000708296fd47e8  vmovaps xmm1, [rsp+0x10]
0000708296fd47ee  vmovaps xmm2, [rsp+0x20]
0000708296fd47f4  vmovaps xmm3, [rsp+0x30]
0000708296fd47fa  vmovaps xmm4, [rsp+0x40]
0000708296fd4800  vmovaps xmm5, [rsp+0x50]
0000708296fd4806  vmovaps xmm6, [rsp+0x60]
0000708296fd480c  vmovaps xmm7, [rsp+0x70]
0000708296fd4812  vmovaps xmm8, [rsp+0x80]
0000708296fd481b  vmovaps xmm9, [rsp+0x90]
0000708296fd4824  vmovaps xmm11, [rsp+0xA0]
0000708296fd482d  vmovaps xmm12, [rsp+0xB0]
0000708296fd4836  vmovaps xmm13, [rsp+0xC0]
0000708296fd483f  vmovaps xmm14, [rsp+0xD0]
0000708296fd4848  vmovaps xmm15, [rsp+0xE0]
0000708296fd4851  add rsp, 0xF0
0000708296fd4858  pop r11
0000708296fd485a  pop r10
0000708296fd485c  pop r9
0000708296fd485e  pop r8
0000708296fd4860  pop rsi
0000708296fd4861  pop rdi
0000708296fd4862  pop rdx
0000708296fd4863  pop rcx
0000708296fd4864  pop rax
0000708296fd4865  add rsp, 0x08
0000708296fd4869  jmp 0x0000708296FD0169
0000708296fd486e  sub rsp, 0x08
0000708296fd4872  push rax
0000708296fd4873  push rcx
0000708296fd4874  push rdx
0000708296fd4875  push rdi
0000708296fd4876  push rsi
0000708296fd4877  push r8
0000708296fd4879  push r9
0000708296fd487b  push r10
0000708296fd487d  push r11
0000708296fd487f  sub rsp, 0xF0
0000708296fd4886  vmovaps [rsp], xmm0
0000708296fd488b  vmovaps [rsp+0x10], xmm1
0000708296fd4891  vmovaps [rsp+0x20], xmm2
0000708296fd4897  vmovaps [rsp+0x30], xmm3
0000708296fd489d  vmovaps [rsp+0x40], xmm4
0000708296fd48a3  vmovaps [rsp+0x50], xmm5
0000708296fd48a9  vmovaps [rsp+0x60], xmm6
0000708296fd48af  vmovaps [rsp+0x70], xmm7
0000708296fd48b5  vmovaps [rsp+0x80], xmm8
0000708296fd48be  vmovaps [rsp+0x90], xmm9
0000708296fd48c7  vmovaps [rsp+0xA0], xmm10
0000708296fd48d0  vmovaps [rsp+0xB0], xmm11
0000708296fd48d9  vmovaps [rsp+0xC0], xmm12
0000708296fd48e2  vmovaps [rsp+0xD0], xmm14
0000708296fd48eb  vmovaps [rsp+0xE0], xmm15
0000708296fd48f4  sub rsp, 0x30
0000708296fd48f8  movaps [rsp], xmm13
0000708296fd48fd  movaps [rsp+0x10], xmm1
0000708296fd4902  movaps [rsp+0x20], xmm8
0000708296fd4908  lea rdi, [rsp]
0000708296fd490c  mov esi, 0x00
0000708296fd4911  mov rax, 0x64BBC686C530
0000708296fd491b  call rax
0000708296fd491d  movaps xmm13, [rsp]
0000708296fd4922  add rsp, 0x30
0000708296fd4926  vmovaps xmm0, [rsp]
0000708296fd492b  vmovaps xmm1, [rsp+0x10]
0000708296fd4931  vmovaps xmm2, [rsp+0x20]
0000708296fd4937  vmovaps xmm3, [rsp+0x30]
0000708296fd493d  vmovaps xmm4, [rsp+0x40]
0000708296fd4943  vmovaps xmm5, [rsp+0x50]
0000708296fd4949  vmovaps xmm6, [rsp+0x60]
0000708296fd494f  vmovaps xmm7, [rsp+0x70]
0000708296fd4955  vmovaps xmm8, [rsp+0x80]
0000708296fd495e  vmovaps xmm9, [rsp+0x90]
0000708296fd4967  vmovaps xmm10, [rsp+0xA0]
0000708296fd4970  vmovaps xmm11, [rsp+0xB0]
0000708296fd4979  vmovaps xmm12, [rsp+0xC0]
0000708296fd4982  vmovaps xmm14, [rsp+0xD0]
0000708296fd498b  vmovaps xmm15, [rsp+0xE0]
0000708296fd4994  add rsp, 0xF0
0000708296fd499b  pop r11
0000708296fd499d  pop r10
0000708296fd499f  pop r9
0000708296fd49a1  pop r8
0000708296fd49a3  pop rsi
0000708296fd49a4  pop rdi
0000708296fd49a5  pop rdx
0000708296fd49a6  pop rcx
0000708296fd49a7  pop rax
0000708296fd49a8  add rsp, 0x08
0000708296fd49ac  jmp 0x0000708296FD0183
0000708296fd49b1  call 0x0000708296DFF430
0000708296fd49b6  jmp 0x0000708296FD018D
0000708296fd49bb  sub rsp, 0x08
0000708296fd49bf  push rax
0000708296fd49c0  push rcx
0000708296fd49c1  push rdx
0000708296fd49c2  push rdi
0000708296fd49c3  push rsi
0000708296fd49c4  push r8
0000708296fd49c6  push r9
0000708296fd49c8  push r10
0000708296fd49ca  push r11
0000708296fd49cc  sub rsp, 0xF0
0000708296fd49d3  vmovaps [rsp], xmm0
0000708296fd49d8  vmovaps [rsp+0x10], xmm1
0000708296fd49de  vmovaps [rsp+0x20], xmm2
0000708296fd49e4  vmovaps [rsp+0x30], xmm3
0000708296fd49ea  vmovaps [rsp+0x40], xmm4
0000708296fd49f0  vmovaps [rsp+0x50], xmm5
0000708296fd49f6  vmovaps [rsp+0x60], xmm6
0000708296fd49fc  vmovaps [rsp+0x70], xmm7
0000708296fd4a02  vmovaps [rsp+0x80], xmm9
0000708296fd4a0b  vmovaps [rsp+0x90], xmm10
0000708296fd4a14  vmovaps [rsp+0xA0], xmm11
0000708296fd4a1d  vmovaps [rsp+0xB0], xmm12
0000708296fd4a26  vmovaps [rsp+0xC0], xmm13
0000708296fd4a2f  vmovaps [rsp+0xD0], xmm14
0000708296fd4a38  vmovaps [rsp+0xE0], xmm15
0000708296fd4a41  sub rsp, 0x30
0000708296fd4a45  movaps [rsp], xmm8
0000708296fd4a4a  movaps [rsp+0x10], xmm14
0000708296fd4a50  movaps [rsp+0x20], xmm9
0000708296fd4a56  lea rdi, [rsp]
0000708296fd4a5a  mov esi, 0x00
0000708296fd4a5f  mov rax, 0x64BBC686C530
0000708296fd4a69  call rax
0000708296fd4a6b  movaps xmm8, [rsp]
0000708296fd4a70  add rsp, 0x30
0000708296fd4a74  vmovaps xmm0, [rsp]
0000708296fd4a79  vmovaps xmm1, [rsp+0x10]
0000708296fd4a7f  vmovaps xmm2, [rsp+0x20]
0000708296fd4a85  vmovaps xmm3, [rsp+0x30]
0000708296fd4a8b  vmovaps xmm4, [rsp+0x40]
0000708296fd4a91  vmovaps xmm5, [rsp+0x50]
0000708296fd4a97  vmovaps xmm6, [rsp+0x60]
0000708296fd4a9d  vmovaps xmm7, [rsp+0x70]
0000708296fd4aa3  vmovaps xmm9, [rsp+0x80]
0000708296fd4aac  vmovaps xmm10, [rsp+0x90]
0000708296fd4ab5  vmovaps xmm11, [rsp+0xA0]
0000708296fd4abe  vmovaps xmm12, [rsp+0xB0]
0000708296fd4ac7  vmovaps xmm13, [rsp+0xC0]
0000708296fd4ad0  vmovaps xmm14, [rsp+0xD0]
0000708296fd4ad9  vmovaps xmm15, [rsp+0xE0]
0000708296fd4ae2  add rsp, 0xF0
0000708296fd4ae9  pop r11
0000708296fd4aeb  pop r10
0000708296fd4aed  pop r9
0000708296fd4aef  pop r8
0000708296fd4af1  pop rsi
0000708296fd4af2  pop rdi
0000708296fd4af3  pop rdx
0000708296fd4af4  pop rcx
0000708296fd4af5  pop rax
0000708296fd4af6  add rsp, 0x08
0000708296fd4afa  jmp 0x0000708296FD01AF
0000708296fd4aff  sub rsp, 0x08
0000708296fd4b03  push rax
0000708296fd4b04  push rcx
0000708296fd4b05  push rdx
0000708296fd4b06  push rdi
0000708296fd4b07  push rsi
0000708296fd4b08  push r8
0000708296fd4b0a  push r9
0000708296fd4b0c  push r10
0000708296fd4b0e  push r11
0000708296fd4b10  sub rsp, 0xF0
0000708296fd4b17  vmovaps [rsp], xmm0
0000708296fd4b1c  vmovaps [rsp+0x10], xmm1
0000708296fd4b22  vmovaps [rsp+0x20], xmm2
0000708296fd4b28  vmovaps [rsp+0x30], xmm3
0000708296fd4b2e  vmovaps [rsp+0x40], xmm4
0000708296fd4b34  vmovaps [rsp+0x50], xmm5
0000708296fd4b3a  vmovaps [rsp+0x60], xmm6
0000708296fd4b40  vmovaps [rsp+0x70], xmm7
0000708296fd4b46  vmovaps [rsp+0x80], xmm8
0000708296fd4b4f  vmovaps [rsp+0x90], xmm10
0000708296fd4b58  vmovaps [rsp+0xA0], xmm11
0000708296fd4b61  vmovaps [rsp+0xB0], xmm12
0000708296fd4b6a  vmovaps [rsp+0xC0], xmm13
0000708296fd4b73  vmovaps [rsp+0xD0], xmm14
0000708296fd4b7c  vmovaps [rsp+0xE0], xmm15
0000708296fd4b85  sub rsp, 0x30
0000708296fd4b89  movaps [rsp], xmm9
0000708296fd4b8e  movaps [rsp+0x10], xmm1
0000708296fd4b93  movaps [rsp+0x20], xmm14
0000708296fd4b99  lea rdi, [rsp]
0000708296fd4b9d  mov esi, 0x00
0000708296fd4ba2  mov rax, 0x64BBC686C530
0000708296fd4bac  call rax
0000708296fd4bae  movaps xmm9, [rsp]
0000708296fd4bb3  add rsp, 0x30
0000708296fd4bb7  vmovaps xmm0, [rsp]
0000708296fd4bbc  vmovaps xmm1, [rsp+0x10]
0000708296fd4bc2  vmovaps xmm2, [rsp+0x20]
0000708296fd4bc8  vmovaps xmm3, [rsp+0x30]
0000708296fd4bce  vmovaps xmm4, [rsp+0x40]
0000708296fd4bd4  vmovaps xmm5, [rsp+0x50]
0000708296fd4bda  vmovaps xmm6, [rsp+0x60]
0000708296fd4be0  vmovaps xmm7, [rsp+0x70]
0000708296fd4be6  vmovaps xmm8, [rsp+0x80]
0000708296fd4bef  vmovaps xmm10, [rsp+0x90]
0000708296fd4bf8  vmovaps xmm11, [rsp+0xA0]
0000708296fd4c01  vmovaps xmm12, [rsp+0xB0]
0000708296fd4c0a  vmovaps xmm13, [rsp+0xC0]
0000708296fd4c13  vmovaps xmm14, [rsp+0xD0]
0000708296fd4c1c  vmovaps xmm15, [rsp+0xE0]
0000708296fd4c25  add rsp, 0xF0
0000708296fd4c2c  pop r11
0000708296fd4c2e  pop r10
0000708296fd4c30  pop r9
0000708296fd4c32  pop r8
0000708296fd4c34  pop rsi
0000708296fd4c35  pop rdi
0000708296fd4c36  pop rdx
0000708296fd4c37  pop rcx
0000708296fd4c38  pop rax
0000708296fd4c39  add rsp, 0x08
0000708296fd4c3d  jmp 0x0000708296FD01DD
0000708296fd4c42  sub rsp, 0x08
0000708296fd4c46  push rax
0000708296fd4c47  push rcx
0000708296fd4c48  push rdx
0000708296fd4c49  push rdi
0000708296fd4c4a  push rsi
0000708296fd4c4b  push r8
0000708296fd4c4d  push r9
0000708296fd4c4f  push r10
0000708296fd4c51  push r11
0000708296fd4c53  sub rsp, 0xF0
0000708296fd4c5a  vmovaps [rsp], xmm0
0000708296fd4c5f  vmovaps [rsp+0x10], xmm1
0000708296fd4c65  vmovaps [rsp+0x20], xmm2
0000708296fd4c6b  vmovaps [rsp+0x30], xmm3
0000708296fd4c71  vmovaps [rsp+0x40], xmm4
0000708296fd4c77  vmovaps [rsp+0x50], xmm5
0000708296fd4c7d  vmovaps [rsp+0x60], xmm6
0000708296fd4c83  vmovaps [rsp+0x70], xmm7
0000708296fd4c89  vmovaps [rsp+0x80], xmm8
0000708296fd4c92  vmovaps [rsp+0x90], xmm9
0000708296fd4c9b  vmovaps [rsp+0xA0], xmm10
0000708296fd4ca4  vmovaps [rsp+0xB0], xmm11
0000708296fd4cad  vmovaps [rsp+0xC0], xmm12
0000708296fd4cb6  vmovaps [rsp+0xD0], xmm13
0000708296fd4cbf  vmovaps [rsp+0xE0], xmm15
0000708296fd4cc8  sub rsp, 0x30
0000708296fd4ccc  movaps [rsp], xmm14
0000708296fd4cd1  movaps [rsp+0x10], xmm4
0000708296fd4cd6  movaps [rsp+0x20], xmm1
0000708296fd4cdb  lea rdi, [rsp]
0000708296fd4cdf  mov esi, 0x00
0000708296fd4ce4  mov rax, 0x64BBC686C530
0000708296fd4cee  call rax
0000708296fd4cf0  movaps xmm14, [rsp]
0000708296fd4cf5  add rsp, 0x30
0000708296fd4cf9  vmovaps xmm0, [rsp]
0000708296fd4cfe  vmovaps xmm1, [rsp+0x10]
0000708296fd4d04  vmovaps xmm2, [rsp+0x20]
0000708296fd4d0a  vmovaps xmm3, [rsp+0x30]
0000708296fd4d10  vmovaps xmm4, [rsp+0x40]
0000708296fd4d16  vmovaps xmm5, [rsp+0x50]
0000708296fd4d1c  vmovaps xmm6, [rsp+0x60]
0000708296fd4d22  vmovaps xmm7, [rsp+0x70]
0000708296fd4d28  vmovaps xmm8, [rsp+0x80]
0000708296fd4d31  vmovaps xmm9, [rsp+0x90]
0000708296fd4d3a  vmovaps xmm10, [rsp+0xA0]
0000708296fd4d43  vmovaps xmm11, [rsp+0xB0]
0000708296fd4d4c  vmovaps xmm12, [rsp+0xC0]
0000708296fd4d55  vmovaps xmm13, [rsp+0xD0]
0000708296fd4d5e  vmovaps xmm15, [rsp+0xE0]
0000708296fd4d67  add rsp, 0xF0
0000708296fd4d6e  pop r11
0000708296fd4d70  pop r10
0000708296fd4d72  pop r9
0000708296fd4d74  pop r8
0000708296fd4d76  pop rsi
0000708296fd4d77  pop rdi
0000708296fd4d78  pop rdx
0000708296fd4d79  pop rcx
0000708296fd4d7a  pop rax
0000708296fd4d7b  add rsp, 0x08
0000708296fd4d7f  jmp 0x0000708296FD0203
0000708296fd4d84  sub rsp, 0x08
0000708296fd4d88  push rax
0000708296fd4d89  push rcx
0000708296fd4d8a  push rdx
0000708296fd4d8b  push rdi
0000708296fd4d8c  push rsi
0000708296fd4d8d  push r8
0000708296fd4d8f  push r9
0000708296fd4d91  push r10
0000708296fd4d93  push r11
0000708296fd4d95  sub rsp, 0xF0
0000708296fd4d9c  vmovaps [rsp], xmm0
0000708296fd4da1  vmovaps [rsp+0x10], xmm2
0000708296fd4da7  vmovaps [rsp+0x20], xmm3
0000708296fd4dad  vmovaps [rsp+0x30], xmm4
0000708296fd4db3  vmovaps [rsp+0x40], xmm5
0000708296fd4db9  vmovaps [rsp+0x50], xmm6
0000708296fd4dbf  vmovaps [rsp+0x60], xmm7
0000708296fd4dc5  vmovaps [rsp+0x70], xmm8
0000708296fd4dcb  vmovaps [rsp+0x80], xmm9
0000708296fd4dd4  vmovaps [rsp+0x90], xmm10
0000708296fd4ddd  vmovaps [rsp+0xA0], xmm11
0000708296fd4de6  vmovaps [rsp+0xB0], xmm12
0000708296fd4def  vmovaps [rsp+0xC0], xmm13
0000708296fd4df8  vmovaps [rsp+0xD0], xmm14
0000708296fd4e01  vmovaps [rsp+0xE0], xmm15
0000708296fd4e0a  sub rsp, 0x30
0000708296fd4e0e  movaps [rsp], xmm1
0000708296fd4e12  movaps [rsp+0x10], xmm12
0000708296fd4e18  movaps [rsp+0x20], xmm11
0000708296fd4e1e  lea rdi, [rsp]
0000708296fd4e22  mov esi, 0x00
0000708296fd4e27  mov rax, 0x64BBC686C530
0000708296fd4e31  call rax
0000708296fd4e33  movaps xmm1, [rsp]
0000708296fd4e37  add rsp, 0x30
0000708296fd4e3b  vmovaps xmm0, [rsp]
0000708296fd4e40  vmovaps xmm2, [rsp+0x10]
0000708296fd4e46  vmovaps xmm3, [rsp+0x20]
0000708296fd4e4c  vmovaps xmm4, [rsp+0x30]
0000708296fd4e52  vmovaps xmm5, [rsp+0x40]
0000708296fd4e58  vmovaps xmm6, [rsp+0x50]
0000708296fd4e5e  vmovaps xmm7, [rsp+0x60]
0000708296fd4e64  vmovaps xmm8, [rsp+0x70]
0000708296fd4e6a  vmovaps xmm9, [rsp+0x80]
0000708296fd4e73  vmovaps xmm10, [rsp+0x90]
0000708296fd4e7c  vmovaps xmm11, [rsp+0xA0]
0000708296fd4e85  vmovaps xmm12, [rsp+0xB0]
0000708296fd4e8e  vmovaps xmm13, [rsp+0xC0]
0000708296fd4e97  vmovaps xmm14, [rsp+0xD0]
0000708296fd4ea0  vmovaps xmm15, [rsp+0xE0]
0000708296fd4ea9  add rsp, 0xF0
0000708296fd4eb0  pop r11
0000708296fd4eb2  pop r10
0000708296fd4eb4  pop r9
0000708296fd4eb6  pop r8
0000708296fd4eb8  pop rsi
0000708296fd4eb9  pop rdi
0000708296fd4eba  pop rdx
0000708296fd4ebb  pop rcx
0000708296fd4ebc  pop rax
0000708296fd4ebd  add rsp, 0x08
0000708296fd4ec1  jmp 0x0000708296FD0224
0000708296fd4ec6  call 0x0000708296EE20A0
0000708296fd4ecb  jmp 0x0000708296FD0232
0000708296fd4ed0  call 0x0000708296E09D70
0000708296fd4ed5  jmp 0x0000708296FD023C
0000708296fd4eda  sub rsp, 0x08
0000708296fd4ede  push rax
0000708296fd4edf  push rcx
0000708296fd4ee0  push rdx
0000708296fd4ee1  push rdi
0000708296fd4ee2  push rsi
0000708296fd4ee3  push r8
0000708296fd4ee5  push r9
0000708296fd4ee7  push r10
0000708296fd4ee9  push r11
0000708296fd4eeb  sub rsp, 0xF0
0000708296fd4ef2  vmovaps [rsp], xmm0
0000708296fd4ef7  vmovaps [rsp+0x10], xmm1
0000708296fd4efd  vmovaps [rsp+0x20], xmm2
0000708296fd4f03  vmovaps [rsp+0x30], xmm3
0000708296fd4f09  vmovaps [rsp+0x40], xmm4
0000708296fd4f0f  vmovaps [rsp+0x50], xmm5
0000708296fd4f15  vmovaps [rsp+0x60], xmm6
0000708296fd4f1b  vmovaps [rsp+0x70], xmm8
0000708296fd4f21  vmovaps [rsp+0x80], xmm9
0000708296fd4f2a  vmovaps [rsp+0x90], xmm10
0000708296fd4f33  vmovaps [rsp+0xA0], xmm11
0000708296fd4f3c  vmovaps [rsp+0xB0], xmm12
0000708296fd4f45  vmovaps [rsp+0xC0], xmm13
0000708296fd4f4e  vmovaps [rsp+0xD0], xmm14
0000708296fd4f57  vmovaps [rsp+0xE0], xmm15
0000708296fd4f60  sub rsp, 0x30
0000708296fd4f64  movaps [rsp], xmm7
0000708296fd4f68  movaps [rsp+0x10], xmm15
0000708296fd4f6e  movaps [rsp+0x20], xmm10
0000708296fd4f74  lea rdi, [rsp]
0000708296fd4f78  mov esi, 0x00
0000708296fd4f7d  mov rax, 0x64BBC686C530
0000708296fd4f87  call rax
0000708296fd4f89  movaps xmm7, [rsp]
0000708296fd4f8d  add rsp, 0x30
0000708296fd4f91  vmovaps xmm0, [rsp]
0000708296fd4f96  vmovaps xmm1, [rsp+0x10]
0000708296fd4f9c  vmovaps xmm2, [rsp+0x20]
0000708296fd4fa2  vmovaps xmm3, [rsp+0x30]
0000708296fd4fa8  vmovaps xmm4, [rsp+0x40]
0000708296fd4fae  vmovaps xmm5, [rsp+0x50]
0000708296fd4fb4  vmovaps xmm6, [rsp+0x60]
0000708296fd4fba  vmovaps xmm8, [rsp+0x70]
0000708296fd4fc0  vmovaps xmm9, [rsp+0x80]
0000708296fd4fc9  vmovaps xmm10, [rsp+0x90]
0000708296fd4fd2  vmovaps xmm11, [rsp+0xA0]
0000708296fd4fdb  vmovaps xmm12, [rsp+0xB0]
0000708296fd4fe4  vmovaps xmm13, [rsp+0xC0]
0000708296fd4fed  vmovaps xmm14, [rsp+0xD0]
0000708296fd4ff6  vmovaps xmm15, [rsp+0xE0]
0000708296fd4fff  add rsp, 0xF0
0000708296fd5006  pop r11
0000708296fd5008  pop r10
0000708296fd500a  pop r9
0000708296fd500c  pop r8
0000708296fd500e  pop rsi
0000708296fd500f  pop rdi
0000708296fd5010  pop rdx
0000708296fd5011  pop rcx
0000708296fd5012  pop rax
0000708296fd5013  add rsp, 0x08
0000708296fd5017  jmp 0x0000708296FD025D
0000708296fd501c  sub rsp, 0x08
0000708296fd5020  push rax
0000708296fd5021  push rcx
0000708296fd5022  push rdx
0000708296fd5023  push rdi
0000708296fd5024  push rsi
0000708296fd5025  push r8
0000708296fd5027  push r9
0000708296fd5029  push r10
0000708296fd502b  push r11
0000708296fd502d  sub rsp, 0xF0
0000708296fd5034  vmovaps [rsp], xmm0
0000708296fd5039  vmovaps [rsp+0x10], xmm1
0000708296fd503f  vmovaps [rsp+0x20], xmm2
0000708296fd5045  vmovaps [rsp+0x30], xmm3
0000708296fd504b  vmovaps [rsp+0x40], xmm4
0000708296fd5051  vmovaps [rsp+0x50], xmm5
0000708296fd5057  vmovaps [rsp+0x60], xmm6
0000708296fd505d  vmovaps [rsp+0x70], xmm7
0000708296fd5063  vmovaps [rsp+0x80], xmm8
0000708296fd506c  vmovaps [rsp+0x90], xmm9
0000708296fd5075  vmovaps [rsp+0xA0], xmm11
0000708296fd507e  vmovaps [rsp+0xB0], xmm12
0000708296fd5087  vmovaps [rsp+0xC0], xmm13
0000708296fd5090  vmovaps [rsp+0xD0], xmm14
0000708296fd5099  vmovaps [rsp+0xE0], xmm15
0000708296fd50a2  sub rsp, 0x30
0000708296fd50a6  movaps [rsp], xmm10
0000708296fd50ab  movaps [rsp+0x10], xmm11
0000708296fd50b1  movaps [rsp+0x20], xmm15
0000708296fd50b7  lea rdi, [rsp]
0000708296fd50bb  mov esi, 0x00
0000708296fd50c0  mov rax, 0x64BBC686C530
0000708296fd50ca  call rax
0000708296fd50cc  movaps xmm10, [rsp]
0000708296fd50d1  add rsp, 0x30
0000708296fd50d5  vmovaps xmm0, [rsp]
0000708296fd50da  vmovaps xmm1, [rsp+0x10]
0000708296fd50e0  vmovaps xmm2, [rsp+0x20]
0000708296fd50e6  vmovaps xmm3, [rsp+0x30]
0000708296fd50ec  vmovaps xmm4, [rsp+0x40]
0000708296fd50f2  vmovaps xmm5, [rsp+0x50]
0000708296fd50f8  vmovaps xmm6, [rsp+0x60]
0000708296fd50fe  vmovaps xmm7, [rsp+0x70]
0000708296fd5104  vmovaps xmm8, [rsp+0x80]
0000708296fd510d  vmovaps xmm9, [rsp+0x90]
0000708296fd5116  vmovaps xmm11, [rsp+0xA0]
0000708296fd511f  vmovaps xmm12, [rsp+0xB0]
0000708296fd5128  vmovaps xmm13, [rsp+0xC0]
0000708296fd5131  vmovaps xmm14, [rsp+0xD0]
0000708296fd513a  vmovaps xmm15, [rsp+0xE0]
0000708296fd5143  add rsp, 0xF0
0000708296fd514a  pop r11
0000708296fd514c  pop r10
0000708296fd514e  pop r9
0000708296fd5150  pop r8
0000708296fd5152  pop rsi
0000708296fd5153  pop rdi
0000708296fd5154  pop rdx
0000708296fd5155  pop rcx
0000708296fd5156  pop rax
0000708296fd5157  add rsp, 0x08
0000708296fd515b  jmp 0x0000708296FD028B
0000708296fd5160  sub rsp, 0x08
0000708296fd5164  push rax
0000708296fd5165  push rcx
0000708296fd5166  push rdx
0000708296fd5167  push rdi
0000708296fd5168  push rsi
0000708296fd5169  push r8
0000708296fd516b  push r9
0000708296fd516d  push r10
0000708296fd516f  push r11
0000708296fd5171  sub rsp, 0xF0
0000708296fd5178  vmovaps [rsp], xmm0
0000708296fd517d  vmovaps [rsp+0x10], xmm1
0000708296fd5183  vmovaps [rsp+0x20], xmm2
0000708296fd5189  vmovaps [rsp+0x30], xmm3
0000708296fd518f  vmovaps [rsp+0x40], xmm4
0000708296fd5195  vmovaps [rsp+0x50], xmm5
0000708296fd519b  vmovaps [rsp+0x60], xmm6
0000708296fd51a1  vmovaps [rsp+0x70], xmm7
0000708296fd51a7  vmovaps [rsp+0x80], xmm8
0000708296fd51b0  vmovaps [rsp+0x90], xmm9
0000708296fd51b9  vmovaps [rsp+0xA0], xmm10
0000708296fd51c2  vmovaps [rsp+0xB0], xmm12
0000708296fd51cb  vmovaps [rsp+0xC0], xmm13
0000708296fd51d4  vmovaps [rsp+0xD0], xmm14
0000708296fd51dd  vmovaps [rsp+0xE0], xmm15
0000708296fd51e6  sub rsp, 0x30
0000708296fd51ea  movaps [rsp], xmm11
0000708296fd51ef  movaps [rsp+0x10], xmm12
0000708296fd51f5  movaps [rsp+0x20], xmm15
0000708296fd51fb  lea rdi, [rsp]
0000708296fd51ff  mov esi, 0x00
0000708296fd5204  mov rax, 0x64BBC686C530
0000708296fd520e  call rax
0000708296fd5210  movaps xmm11, [rsp]
0000708296fd5215  add rsp, 0x30
0000708296fd5219  vmovaps xmm0, [rsp]
0000708296fd521e  vmovaps xmm1, [rsp+0x10]
0000708296fd5224  vmovaps xmm2, [rsp+0x20]
0000708296fd522a  vmovaps xmm3, [rsp+0x30]
0000708296fd5230  vmovaps xmm4, [rsp+0x40]
0000708296fd5236  vmovaps xmm5, [rsp+0x50]
0000708296fd523c  vmovaps xmm6, [rsp+0x60]
0000708296fd5242  vmovaps xmm7, [rsp+0x70]
0000708296fd5248  vmovaps xmm8, [rsp+0x80]
0000708296fd5251  vmovaps xmm9, [rsp+0x90]
0000708296fd525a  vmovaps xmm10, [rsp+0xA0]
0000708296fd5263  vmovaps xmm12, [rsp+0xB0]
0000708296fd526c  vmovaps xmm13, [rsp+0xC0]
0000708296fd5275  vmovaps xmm14, [rsp+0xD0]
0000708296fd527e  vmovaps xmm15, [rsp+0xE0]
0000708296fd5287  add rsp, 0xF0
0000708296fd528e  pop r11
0000708296fd5290  pop r10
0000708296fd5292  pop r9
0000708296fd5294  pop r8
0000708296fd5296  pop rsi
0000708296fd5297  pop rdi
0000708296fd5298  pop rdx
0000708296fd5299  pop rcx
0000708296fd529a  pop rax
0000708296fd529b  add rsp, 0x08
0000708296fd529f  jmp 0x0000708296FD02B9
0000708296fd52a4  sub rsp, 0x08
0000708296fd52a8  push rax
0000708296fd52a9  push rcx
0000708296fd52aa  push rdx
0000708296fd52ab  push rdi
0000708296fd52ac  push rsi
0000708296fd52ad  push r8
0000708296fd52af  push r9
0000708296fd52b1  push r10
0000708296fd52b3  push r11
0000708296fd52b5  sub rsp, 0xF0
0000708296fd52bc  vmovaps [rsp], xmm0
0000708296fd52c1  vmovaps [rsp+0x10], xmm1
0000708296fd52c7  vmovaps [rsp+0x20], xmm2
0000708296fd52cd  vmovaps [rsp+0x30], xmm3
0000708296fd52d3  vmovaps [rsp+0x40], xmm4
0000708296fd52d9  vmovaps [rsp+0x50], xmm5
0000708296fd52df  vmovaps [rsp+0x60], xmm6
0000708296fd52e5  vmovaps [rsp+0x70], xmm7
0000708296fd52eb  vmovaps [rsp+0x80], xmm8
0000708296fd52f4  vmovaps [rsp+0x90], xmm9
0000708296fd52fd  vmovaps [rsp+0xA0], xmm10
0000708296fd5306  vmovaps [rsp+0xB0], xmm11
0000708296fd530f  vmovaps [rsp+0xC0], xmm12
0000708296fd5318  vmovaps [rsp+0xD0], xmm13
0000708296fd5321  vmovaps [rsp+0xE0], xmm14
0000708296fd532a  sub rsp, 0x30
0000708296fd532e  movaps [rsp], xmm15
0000708296fd5333  movaps [rsp+0x10], xmm13
0000708296fd5339  movaps [rsp+0x20], xmm9
0000708296fd533f  lea rdi, [rsp]
0000708296fd5343  mov esi, 0x00
0000708296fd5348  mov rax, 0x64BBC686C530
0000708296fd5352  call rax
0000708296fd5354  movaps xmm15, [rsp]
0000708296fd5359  add rsp, 0x30
0000708296fd535d  vmovaps xmm0, [rsp]
0000708296fd5362  vmovaps xmm1, [rsp+0x10]
0000708296fd5368  vmovaps xmm2, [rsp+0x20]
0000708296fd536e  vmovaps xmm3, [rsp+0x30]
0000708296fd5374  vmovaps xmm4, [rsp+0x40]
0000708296fd537a  vmovaps xmm5, [rsp+0x50]
0000708296fd5380  vmovaps xmm6, [rsp+0x60]
0000708296fd5386  vmovaps xmm7, [rsp+0x70]
0000708296fd538c  vmovaps xmm8, [rsp+0x80]
0000708296fd5395  vmovaps xmm9, [rsp+0x90]
0000708296fd539e  vmovaps xmm10, [rsp+0xA0]
0000708296fd53a7  vmovaps xmm11, [rsp+0xB0]
0000708296fd53b0  vmovaps xmm12, [rsp+0xC0]
0000708296fd53b9  vmovaps xmm13, [rsp+0xD0]
0000708296fd53c2  vmovaps xmm14, [rsp+0xE0]
0000708296fd53cb  add rsp, 0xF0
0000708296fd53d2  pop r11
0000708296fd53d4  pop r10
0000708296fd53d6  pop r9
0000708296fd53d8  pop r8
0000708296fd53da  pop rsi
0000708296fd53db  pop rdi
0000708296fd53dc  pop rdx
0000708296fd53dd  pop rcx
0000708296fd53de  pop rax
0000708296fd53df  add rsp, 0x08
0000708296fd53e3  jmp 0x0000708296FD02D4
0000708296fd53e8  sub rsp, 0x08
0000708296fd53ec  push rax
0000708296fd53ed  push rcx
0000708296fd53ee  push rdx
0000708296fd53ef  push rdi
0000708296fd53f0  push rsi
0000708296fd53f1  push r8
0000708296fd53f3  push r9
0000708296fd53f5  push r10
0000708296fd53f7  push r11
0000708296fd53f9  sub rsp, 0xF0
0000708296fd5400  vmovaps [rsp], xmm0
0000708296fd5405  vmovaps [rsp+0x10], xmm1
0000708296fd540b  vmovaps [rsp+0x20], xmm2
0000708296fd5411  vmovaps [rsp+0x30], xmm3
0000708296fd5417  vmovaps [rsp+0x40], xmm4
0000708296fd541d  vmovaps [rsp+0x50], xmm5
0000708296fd5423  vmovaps [rsp+0x60], xmm6
0000708296fd5429  vmovaps [rsp+0x70], xmm7
0000708296fd542f  vmovaps [rsp+0x80], xmm8
0000708296fd5438  vmovaps [rsp+0x90], xmm9
0000708296fd5441  vmovaps [rsp+0xA0], xmm10
0000708296fd544a  vmovaps [rsp+0xB0], xmm11
0000708296fd5453  vmovaps [rsp+0xC0], xmm12
0000708296fd545c  vmovaps [rsp+0xD0], xmm14
0000708296fd5465  vmovaps [rsp+0xE0], xmm15
0000708296fd546e  sub rsp, 0x30
0000708296fd5472  movaps [rsp], xmm13
0000708296fd5477  movaps [rsp+0x10], xmm8
0000708296fd547d  movaps [rsp+0x20], xmm14
0000708296fd5483  lea rdi, [rsp]
0000708296fd5487  mov esi, 0x00
0000708296fd548c  mov rax, 0x64BBC686C530
0000708296fd5496  call rax
0000708296fd5498  movaps xmm13, [rsp]
0000708296fd549d  add rsp, 0x30
0000708296fd54a1  vmovaps xmm0, [rsp]
0000708296fd54a6  vmovaps xmm1, [rsp+0x10]
0000708296fd54ac  vmovaps xmm2, [rsp+0x20]
0000708296fd54b2  vmovaps xmm3, [rsp+0x30]
0000708296fd54b8  vmovaps xmm4, [rsp+0x40]
0000708296fd54be  vmovaps xmm5, [rsp+0x50]
0000708296fd54c4  vmovaps xmm6, [rsp+0x60]
0000708296fd54ca  vmovaps xmm7, [rsp+0x70]
0000708296fd54d0  vmovaps xmm8, [rsp+0x80]
0000708296fd54d9  vmovaps xmm9, [rsp+0x90]
0000708296fd54e2  vmovaps xmm10, [rsp+0xA0]
0000708296fd54eb  vmovaps xmm11, [rsp+0xB0]
0000708296fd54f4  vmovaps xmm12, [rsp+0xC0]
0000708296fd54fd  vmovaps xmm14, [rsp+0xD0]
0000708296fd5506  vmovaps xmm15, [rsp+0xE0]
0000708296fd550f  add rsp, 0xF0
0000708296fd5516  pop r11
0000708296fd5518  pop r10
0000708296fd551a  pop r9
0000708296fd551c  pop r8
0000708296fd551e  pop rsi
0000708296fd551f  pop rdi
0000708296fd5520  pop rdx
0000708296fd5521  pop rcx
0000708296fd5522  pop rax
0000708296fd5523  add rsp, 0x08
0000708296fd5527  jmp 0x0000708296FD02F7
0000708296fd552c  sub rsp, 0x08
0000708296fd5530  push rax
0000708296fd5531  push rcx
0000708296fd5532  push rdx
0000708296fd5533  push rdi
0000708296fd5534  push rsi
0000708296fd5535  push r8
0000708296fd5537  push r9
0000708296fd5539  push r10
0000708296fd553b  push r11
0000708296fd553d  sub rsp, 0xF0
0000708296fd5544  vmovaps [rsp], xmm0
0000708296fd5549  vmovaps [rsp+0x10], xmm1
0000708296fd554f  vmovaps [rsp+0x20], xmm2
0000708296fd5555  vmovaps [rsp+0x30], xmm3
0000708296fd555b  vmovaps [rsp+0x40], xmm4
0000708296fd5561  vmovaps [rsp+0x50], xmm5
0000708296fd5567  vmovaps [rsp+0x60], xmm6
0000708296fd556d  vmovaps [rsp+0x70], xmm7
0000708296fd5573  vmovaps [rsp+0x80], xmm8
0000708296fd557c  vmovaps [rsp+0x90], xmm9
0000708296fd5585  vmovaps [rsp+0xA0], xmm10
0000708296fd558e  vmovaps [rsp+0xB0], xmm11
0000708296fd5597  vmovaps [rsp+0xC0], xmm12
0000708296fd55a0  vmovaps [rsp+0xD0], xmm13
0000708296fd55a9  vmovaps [rsp+0xE0], xmm15
0000708296fd55b2  sub rsp, 0x30
0000708296fd55b6  movaps [rsp], xmm14
0000708296fd55bb  movaps [rsp+0x10], xmm1
0000708296fd55c0  movaps [rsp+0x20], xmm10
0000708296fd55c6  lea rdi, [rsp]
0000708296fd55ca  mov esi, 0x00
0000708296fd55cf  mov rax, 0x64BBC686C530
0000708296fd55d9  call rax
0000708296fd55db  movaps xmm14, [rsp]
0000708296fd55e0  add rsp, 0x30
0000708296fd55e4  vmovaps xmm0, [rsp]
0000708296fd55e9  vmovaps xmm1, [rsp+0x10]
0000708296fd55ef  vmovaps xmm2, [rsp+0x20]
0000708296fd55f5  vmovaps xmm3, [rsp+0x30]
0000708296fd55fb  vmovaps xmm4, [rsp+0x40]
0000708296fd5601  vmovaps xmm5, [rsp+0x50]
0000708296fd5607  vmovaps xmm6, [rsp+0x60]
0000708296fd560d  vmovaps xmm7, [rsp+0x70]
0000708296fd5613  vmovaps xmm8, [rsp+0x80]
0000708296fd561c  vmovaps xmm9, [rsp+0x90]
0000708296fd5625  vmovaps xmm10, [rsp+0xA0]
0000708296fd562e  vmovaps xmm11, [rsp+0xB0]
0000708296fd5637  vmovaps xmm12, [rsp+0xC0]
0000708296fd5640  vmovaps xmm13, [rsp+0xD0]
0000708296fd5649  vmovaps xmm15, [rsp+0xE0]
0000708296fd5652  add rsp, 0xF0
0000708296fd5659  pop r11
0000708296fd565b  pop r10
0000708296fd565d  pop r9
0000708296fd565f  pop r8
0000708296fd5661  pop rsi
0000708296fd5662  pop rdi
0000708296fd5663  pop rdx
0000708296fd5664  pop rcx
0000708296fd5665  pop rax
0000708296fd5666  add rsp, 0x08
0000708296fd566a  jmp 0x0000708296FD031A
0000708296fd566f  sub rsp, 0x08
0000708296fd5673  push rax
0000708296fd5674  push rcx
0000708296fd5675  push rdx
0000708296fd5676  push rdi
0000708296fd5677  push rsi
0000708296fd5678  push r8
0000708296fd567a  push r9
0000708296fd567c  push r10
0000708296fd567e  push r11
0000708296fd5680  sub rsp, 0xF0
0000708296fd5687  vmovaps [rsp], xmm0
0000708296fd568c  vmovaps [rsp+0x10], xmm2
0000708296fd5692  vmovaps [rsp+0x20], xmm3
0000708296fd5698  vmovaps [rsp+0x30], xmm4
0000708296fd569e  vmovaps [rsp+0x40], xmm5
0000708296fd56a4  vmovaps [rsp+0x50], xmm6
0000708296fd56aa  vmovaps [rsp+0x60], xmm7
0000708296fd56b0  vmovaps [rsp+0x70], xmm8
0000708296fd56b6  vmovaps [rsp+0x80], xmm9
0000708296fd56bf  vmovaps [rsp+0x90], xmm10
0000708296fd56c8  vmovaps [rsp+0xA0], xmm11
0000708296fd56d1  vmovaps [rsp+0xB0], xmm12
0000708296fd56da  vmovaps [rsp+0xC0], xmm13
0000708296fd56e3  vmovaps [rsp+0xD0], xmm14
0000708296fd56ec  vmovaps [rsp+0xE0], xmm15
0000708296fd56f5  sub rsp, 0x30
0000708296fd56f9  movaps [rsp], xmm1
0000708296fd56fd  movaps [rsp+0x10], xmm7
0000708296fd5702  movaps [rsp+0x20], xmm11
0000708296fd5708  lea rdi, [rsp]
0000708296fd570c  mov esi, 0x00
0000708296fd5711  mov rax, 0x64BBC686C530
0000708296fd571b  call rax
0000708296fd571d  movaps xmm1, [rsp]
0000708296fd5721  add rsp, 0x30
0000708296fd5725  vmovaps xmm0, [rsp]
0000708296fd572a  vmovaps xmm2, [rsp+0x10]
0000708296fd5730  vmovaps xmm3, [rsp+0x20]
0000708296fd5736  vmovaps xmm4, [rsp+0x30]
0000708296fd573c  vmovaps xmm5, [rsp+0x40]
0000708296fd5742  vmovaps xmm6, [rsp+0x50]
0000708296fd5748  vmovaps xmm7, [rsp+0x60]
0000708296fd574e  vmovaps xmm8, [rsp+0x70]
0000708296fd5754  vmovaps xmm9, [rsp+0x80]
0000708296fd575d  vmovaps xmm10, [rsp+0x90]
0000708296fd5766  vmovaps xmm11, [rsp+0xA0]
0000708296fd576f  vmovaps xmm12, [rsp+0xB0]
0000708296fd5778  vmovaps xmm13, [rsp+0xC0]
0000708296fd5781  vmovaps xmm14, [rsp+0xD0]
0000708296fd578a  vmovaps xmm15, [rsp+0xE0]
0000708296fd5793  add rsp, 0xF0
0000708296fd579a  pop r11
0000708296fd579c  pop r10
0000708296fd579e  pop r9
0000708296fd57a0  pop r8
0000708296fd57a2  pop rsi
0000708296fd57a3  pop rdi
0000708296fd57a4  pop rdx
0000708296fd57a5  pop rcx
0000708296fd57a6  pop rax
0000708296fd57a7  add rsp, 0x08
0000708296fd57ab  jmp 0x0000708296FD033B
0000708296fd57b0  call 0x0000708296E0E880
0000708296fd57b5  jmp 0x0000708296FD034E
0000708296fd57ba  call 0x0000708296E0C380
0000708296fd57bf  jmp 0x0000708296FD0359
0000708296fd57c4  call 0x0000708296E0D600
0000708296fd57c9  jmp 0x0000708296FD0364
0000708296fd57ce  call 0x0000708296DFF540
0000708296fd57d3  jmp 0x0000708296FD036F
0000708296fd57d8  int3
0000708296fd57d9  nop [rax], eax
0000708296fd57e0  mov rax, [r15+0x40]
0000708296fd57e4  mov r14, [r15+0x58]
0000708296fd57e8  lea r12, [rax+r14*1]
0000708296fd57ec  movaps xmm1, [r15+0x1D0]
0000708296fd57f4  vmovaps [rsp+0x10], xmm1
0000708296fd57fa  vmovaps xmm15, [rsp+0x10]
0000708296fd5800  por xmm1, xmm15
0000708296fd5805  movaps xmm14, [r15+0x1A0]
0000708296fd580d  vmovaps [rsp+0x10], xmm14
0000708296fd5813  vmovaps xmm13, [rsp+0x10]
0000708296fd5819  por xmm14, xmm13
0000708296fd581e  lea rax, [r12+0x30]
0000708296fd5823  mov r11, [r13+rax*1]
0000708296fd5828  lea rax, [r12+0x38]
0000708296fd582d  mov r10, [r13+rax*1]
0000708296fd5832  movq xmm13, r11
0000708296fd5837  movq xmm12, r10
0000708296fd583c  movq xmm13, xmm13
0000708296fd5841  vmovaps [rsp+0x10], xmm13
0000708296fd5847  movq xmm13, xmm13
0000708296fd584c  movaps [r15+0x130], xmm13
0000708296fd5854  movq xmm12, xmm12
0000708296fd5859  vmovaps [rsp+0x20], xmm12
0000708296fd585f  movq xmm12, xmm12
0000708296fd5864  movaps [r15+0x280], xmm12
0000708296fd586c  movaps xmm13, [r15+0x270]
0000708296fd5874  vmovaps [rsp+0x30], xmm13
0000708296fd587a  vmovaps xmm12, [rsp+0x30]
0000708296fd5880  por xmm13, xmm12
0000708296fd5885  lea rax, [r12+0x20]
0000708296fd588a  mov r11, [r13+rax*1]
0000708296fd588f  lea rax, [r12+0x28]
0000708296fd5894  mov r10, [r13+rax*1]
0000708296fd5899  movq xmm12, r11
0000708296fd589e  movq xmm11, r10
0000708296fd58a3  movq xmm12, xmm12
0000708296fd58a8  vmovaps [rsp+0x30], xmm12
0000708296fd58ae  movq xmm12, xmm12
0000708296fd58b3  movaps [r15+0x150], xmm12
0000708296fd58bb  movq xmm11, xmm11
0000708296fd58c0  vmovaps [rsp+0x40], xmm11
0000708296fd58c6  movq xmm11, xmm11
0000708296fd58cb  movaps [r15+0x140], xmm11
0000708296fd58d3  lea rax, [r12+0x10]
0000708296fd58d8  mov r11, [r13+rax*1]
0000708296fd58dd  lea rax, [r12+0x18]
0000708296fd58e2  mov r10, [r13+rax*1]
0000708296fd58e7  movq xmm12, r11
0000708296fd58ec  movq xmm11, r10
0000708296fd58f1  movq xmm12, xmm12
0000708296fd58f6  vmovaps [rsp+0x50], xmm12
0000708296fd58fc  movq xmm12, xmm12
0000708296fd5901  movaps [r15+0x170], xmm12
0000708296fd5909  movq xmm11, xmm11
0000708296fd590e  vmovaps [rsp+0x60], xmm11
0000708296fd5914  movq xmm11, xmm11
0000708296fd5919  movaps [r15+0x160], xmm11
0000708296fd5921  mov rax, [r13+r12*1]
0000708296fd5926  vmovq xmm12, rax
0000708296fd592b  vpbroadcastq xmm12, xmm12
0000708296fd5930  lea rax, [r12+0x08]
0000708296fd5935  mov r12, [r13+rax*1]
0000708296fd593a  movq xmm11, r12
0000708296fd593f  movaps [r15+0x230], xmm11
0000708296fd5947  mov rax, [r15+0xF8]
0000708296fd594e  lea r12, [rax+0x50]
0000708296fd5952  movups xmm11, [r13+r12*1]
0000708296fd5958  lea r12, [rax+0x60]
0000708296fd595c  movups xmm10, [r13+r12*1]
0000708296fd5962  lea r12, [rax+0x30]
0000708296fd5966  movups xmm9, [r13+r12*1]
0000708296fd596c  mov r12, [r15+0x50]
0000708296fd5970  lea r11, [r12+r14*1]
0000708296fd5974  mov [r15+0x60], r11
0000708296fd5978  lea r12, [r14+0x40]
0000708296fd597c  mov [r15+0x58], r12
0000708296fd5980  movaps xmm8, xmm12
0000708296fd5984  mulpd xmm8, xmm15
0000708296fd5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000708296fd598f  ptest xmm7, xmm7
0000708296fd5994  jnz 0x0000708296FD67B7
0000708296fd599a  movq xmm15, qword ptr [r15+0x230]
0000708296fd59a3  vmovaps [rsp+0x70], xmm15
0000708296fd59a9  vpermilpd xmm15, xmm15, 0x00
0000708296fd59af  movaps xmm7, xmm9
0000708296fd59b3  mulpd xmm7, xmm15
0000708296fd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000708296fd59bd  ptest xmm6, xmm6
0000708296fd59c2  jnz 0x0000708296FD68FB
0000708296fd59c8  vxorps xmm15, xmm15, xmm15
0000708296fd59cd  vpbroadcastq xmm15, xmm15
0000708296fd59d2  movaps xmm9, xmm12
0000708296fd59d6  mulpd xmm9, xmm10
0000708296fd59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000708296fd59e1  ptest xmm6, xmm6
0000708296fd59e6  jnz 0x0000708296FD6A3D
0000708296fd59ec  movaps xmm10, xmm12
0000708296fd59f0  mulpd xmm10, xmm11
0000708296fd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000708296fd59fb  ptest xmm6, xmm6
0000708296fd5a00  jnz 0x0000708296FD6B81
0000708296fd5a06  movaps xmm11, [r15+0x1F0]
0000708296fd5a0e  movaps xmm6, xmm12
0000708296fd5a12  mulpd xmm6, xmm11
0000708296fd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000708296fd5a1c  ptest xmm5, xmm5
0000708296fd5a21  jnz 0x0000708296FD6CC5
0000708296fd5a27  movaps xmm12, [r15+0x2A0]
0000708296fd5a2f  vmovaps [rsp+0x80], xmm12
0000708296fd5a38  vmovaps xmm11, [rsp+0x80]
0000708296fd5a41  por xmm12, xmm11
0000708296fd5a46  movaps xmm11, [r15+0x250]
0000708296fd5a4e  vmovaps [rsp+0x80], xmm11
0000708296fd5a57  vmovaps xmm5, [rsp+0x80]
0000708296fd5a60  por xmm11, xmm5
0000708296fd5a65  vmovaps xmm4, [rsp+0x70]
0000708296fd5a6b  vpermilpd xmm4, xmm4, 0x00
0000708296fd5a71  movaps xmm3, xmm5
0000708296fd5a74  mulpd xmm3, xmm4
0000708296fd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000708296fd5a7d  ptest xmm2, xmm2
0000708296fd5a82  jnz 0x0000708296FD6E07
0000708296fd5a88  mov [rsp+0x80], rax
0000708296fd5a90  xor eax, eax
0000708296fd5a92  mov r14d, 0x200
0000708296fd5a98  cmp r12, r14
0000708296fd5a9b  cmc
0000708296fd5a9c  lahf
0000708296fd5a9d  seto al
0000708296fd5aa0  mov [r15+0x108], eax
0000708296fd5aa7  movaps xmm5, xmm8
0000708296fd5aab  addpd xmm5, xmm15
0000708296fd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000708296fd5ab5  ptest xmm4, xmm4
0000708296fd5aba  jnz 0x0000708296FD6F47
0000708296fd5ac0  movaps xmm8, [r15+0x1B0]
0000708296fd5ac8  movaps xmm4, xmm9
0000708296fd5acc  addpd xmm4, xmm8
0000708296fd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000708296fd5ad6  ptest xmm2, xmm2
0000708296fd5adb  jnz 0x0000708296FD7089
0000708296fd5ae1  movaps xmm9, xmm10
0000708296fd5ae5  addpd xmm9, xmm8
0000708296fd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000708296fd5af0  ptest xmm2, xmm2
0000708296fd5af5  jnz 0x0000708296FD71CB
0000708296fd5afb  movaps xmm10, [r15+0x2F0]
0000708296fd5b03  vmovaps [rsp+0x90], xmm10
0000708296fd5b0c  vmovaps xmm8, [rsp+0x90]
0000708296fd5b15  por xmm10, xmm8
0000708296fd5b1a  movaps xmm8, [r15+0x2E0]
0000708296fd5b22  vmovaps [rsp+0x90], xmm8
0000708296fd5b2b  vmovaps xmm2, [rsp+0x90]
0000708296fd5b34  por xmm8, xmm2
0000708296fd5b39  movaps xmm2, [r15+0x2D0]
0000708296fd5b41  vmovaps [rsp+0x90], xmm2
0000708296fd5b4a  vmovaps [rsp+0xA0], xmm1
0000708296fd5b53  vmovaps xmm1, [rsp+0x90]
0000708296fd5b5c  por xmm2, xmm1
0000708296fd5b60  movaps xmm1, [r15+0x200]
0000708296fd5b68  vmovaps [rsp+0x90], xmm1
0000708296fd5b71  vmovaps [rsp+0xB0], xmm15
0000708296fd5b7a  vmovaps xmm15, [rsp+0x90]
0000708296fd5b83  por xmm1, xmm15
0000708296fd5b88  movaps xmm15, [r15+0x1C0]
0000708296fd5b90  vmovaps [rsp+0x90], xmm15
0000708296fd5b99  vmovaps [rsp+0xC0], xmm1
0000708296fd5ba2  vmovaps xmm1, [rsp+0x90]
0000708296fd5bab  por xmm15, xmm1
0000708296fd5bb0  movaps xmm1, [r15+0x190]
0000708296fd5bb8  vmovaps [rsp+0x90], xmm1
0000708296fd5bc1  vmovaps [rsp+0xD0], xmm15
0000708296fd5bca  vmovaps xmm15, [rsp+0x90]
0000708296fd5bd3  por xmm1, xmm15
0000708296fd5bd8  movaps xmm15, [r15+0x300]
0000708296fd5be0  vmovaps [rsp+0x90], xmm15
0000708296fd5be9  vmovaps [rsp+0xE0], xmm1
0000708296fd5bf2  vmovaps xmm1, [rsp+0x90]
0000708296fd5bfb  por xmm15, xmm1
0000708296fd5c00  mov rax, [rsp+0x80]
0000708296fd5c08  lea r14, [rax+0xA0]
0000708296fd5c0f  movups xmm1, [r13+r14*1]
0000708296fd5c15  lea r14, [rax+0xB0]
0000708296fd5c1c  vmovaps [rsp+0x80], xmm1
0000708296fd5c25  movups xmm1, [r13+r14*1]
0000708296fd5c2b  vmovaps [rsp+0x90], xmm1
0000708296fd5c34  vmovaps [rsp+0xF0], xmm15
0000708296fd5c3d  vmovaps xmm15, [rsp+0xB0]
0000708296fd5c46  vmovaps [rsp+0xB0], xmm14
0000708296fd5c4f  movaps xmm1, xmm6
0000708296fd5c52  addpd xmm1, xmm15
0000708296fd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000708296fd5c5c  ptest xmm14, xmm14
0000708296fd5c62  jnz 0x0000708296FD7323
0000708296fd5c68  lea r14, [rax+0xF0]
0000708296fd5c6f  movups xmm15, [r13+r14*1]
0000708296fd5c75  movaps xmm14, xmm4
0000708296fd5c79  addpd xmm14, xmm3
0000708296fd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000708296fd5c84  ptest xmm6, xmm6
0000708296fd5c89  jnz 0x0000708296FD746E
0000708296fd5c8f  movaps xmm6, xmm9
0000708296fd5c93  addpd xmm6, xmm7
0000708296fd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000708296fd5c9c  ptest xmm4, xmm4
0000708296fd5ca1  jnz 0x0000708296FD75B0
0000708296fd5ca7  vmovaps xmm9, [rsp+0x70]
0000708296fd5cad  vpermilpd xmm9, xmm9, 0x00
0000708296fd5cb3  vmovaps xmm4, [rsp+0x90]
0000708296fd5cbc  movaps xmm7, xmm4
0000708296fd5cbf  mulpd xmm7, xmm9
0000708296fd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000708296fd5cc9  ptest xmm3, xmm3
0000708296fd5cce  jnz 0x0000708296FD76F1
0000708296fd5cd4  vmovaps xmm9, [rsp+0x50]
0000708296fd5cda  vpermilpd xmm9, xmm9, 0x00
0000708296fd5ce0  movaps xmm4, xmm15
0000708296fd5ce4  mulpd xmm4, xmm9
0000708296fd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000708296fd5cee  ptest xmm3, xmm3
0000708296fd5cf3  jnz 0x0000708296FD7832
0000708296fd5cf9  lea r14, [rax+0xE0]
0000708296fd5d00  movups xmm15, [r13+r14*1]
0000708296fd5d06  vmovaps xmm9, [rsp+0x70]
0000708296fd5d0c  vpermilpd xmm9, xmm9, 0x00
0000708296fd5d12  vmovaps [rsp+0x70], xmm1
0000708296fd5d18  vmovaps xmm1, [rsp+0x80]
0000708296fd5d21  vmovaps [rsp+0x80], xmm15
0000708296fd5d2a  movaps xmm3, xmm1
0000708296fd5d2d  mulpd xmm3, xmm9
0000708296fd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000708296fd5d37  ptest xmm15, xmm15
0000708296fd5d3d  jnz 0x0000708296FD797E
0000708296fd5d43  vmovaps xmm1, [rsp+0xF0]
0000708296fd5d4c  vmovaps xmm15, [rsp+0xF0]
0000708296fd5d55  por xmm1, xmm15
0000708296fd5d5a  movaps [r15+0x300], xmm1
0000708296fd5d62  vmovaps xmm15, [rsp+0xE0]
0000708296fd5d6b  vmovaps xmm9, [rsp+0xE0]
0000708296fd5d74  por xmm15, xmm9
0000708296fd5d79  movaps [r15+0x190], xmm15
0000708296fd5d81  vmovaps xmm9, [rsp+0x50]
0000708296fd5d87  vpermilpd xmm9, xmm9, 0x00
0000708296fd5d8d  vmovaps [rsp+0x90], xmm1
0000708296fd5d96  vmovaps [rsp+0xE0], xmm15
0000708296fd5d9f  vmovaps xmm15, [rsp+0x80]
0000708296fd5da8  vmovaps [rsp+0x80], xmm14
0000708296fd5db1  movaps xmm1, xmm15
0000708296fd5db5  mulpd xmm1, xmm9
0000708296fd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000708296fd5dbf  ptest xmm14, xmm14
0000708296fd5dc5  jnz 0x0000708296FD7ABF
0000708296fd5dcb  lea r14, [rax+0x90]
0000708296fd5dd2  movups xmm15, [r13+r14*1]
0000708296fd5dd8  vmovaps xmm14, [rsp+0xD0]
0000708296fd5de1  vmovaps xmm9, [rsp+0xD0]
0000708296fd5dea  por xmm14, xmm9
0000708296fd5def  movaps [r15+0x1C0], xmm14
0000708296fd5df7  vmovaps xmm9, [rsp+0xC0]
0000708296fd5e00  vmovaps [rsp+0xD0], xmm1
0000708296fd5e09  vmovaps xmm1, [rsp+0xC0]
0000708296fd5e12  por xmm9, xmm1
0000708296fd5e17  movaps [r15+0x200], xmm9
0000708296fd5e1f  vmovaps [rsp+0xC0], xmm2
0000708296fd5e28  vmovaps xmm1, [rsp+0xC0]
0000708296fd5e31  por xmm2, xmm1
0000708296fd5e35  movaps [r15+0x2D0], xmm2
0000708296fd5e3d  vmovaps [rsp+0xC0], xmm8
0000708296fd5e46  vmovaps xmm1, [rsp+0xC0]
0000708296fd5e4f  por xmm8, xmm1
0000708296fd5e54  movaps [r15+0x2E0], xmm8
0000708296fd5e5c  vmovaps [rsp+0xC0], xmm15
0000708296fd5e65  movaps xmm1, xmm5
0000708296fd5e68  addpd xmm1, xmm7
0000708296fd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000708296fd5e71  ptest xmm15, xmm15
0000708296fd5e77  jnz 0x0000708296FD7C0B
0000708296fd5e7d  vmovaps xmm15, [rsp+0x50]
0000708296fd5e83  vpermilpd xmm15, xmm15, 0x00
0000708296fd5e89  vmovaps xmm5, [rsp+0xC0]
0000708296fd5e92  vmovaps [rsp+0xC0], xmm1
0000708296fd5e9b  movaps xmm7, xmm5
0000708296fd5e9e  mulpd xmm7, xmm15
0000708296fd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000708296fd5ea8  ptest xmm1, xmm1
0000708296fd5ead  jnz 0x0000708296FD7D4B
0000708296fd5eb3  lea r14, [rax+0x80]
0000708296fd5eba  movups xmm1, [r13+r14*1]
0000708296fd5ec0  vmovaps xmm5, [rsp+0x70]
0000708296fd5ec6  vmovaps [rsp+0x70], xmm1
0000708296fd5ecc  movaps xmm15, xmm5
0000708296fd5ed0  addpd xmm15, xmm3
0000708296fd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000708296fd5edb  ptest xmm1, xmm1
0000708296fd5ee0  jnz 0x0000708296FD7E96
0000708296fd5ee6  vmovaps xmm5, [rsp+0x80]
0000708296fd5eef  movaps xmm1, xmm5
0000708296fd5ef2  addpd xmm1, xmm4
0000708296fd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000708296fd5efb  ptest xmm3, xmm3
0000708296fd5f00  jnz 0x0000708296FD7FD8
0000708296fd5f06  vmovaps [rsp+0x80], xmm10
0000708296fd5f0f  vmovaps xmm5, [rsp+0x80]
0000708296fd5f18  por xmm10, xmm5
0000708296fd5f1d  movaps [r15+0x2F0], xmm10
0000708296fd5f25  vmovaps xmm5, [rsp+0x50]
0000708296fd5f2b  vpermilpd xmm5, xmm5, 0x00
0000708296fd5f31  vmovaps xmm3, [rsp+0x70]
0000708296fd5f37  vmovaps [rsp+0x50], xmm1
0000708296fd5f3d  movaps xmm4, xmm3
0000708296fd5f40  mulpd xmm4, xmm5
0000708296fd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000708296fd5f49  ptest xmm1, xmm1
0000708296fd5f4e  jnz 0x0000708296FD8118
0000708296fd5f54  lea r14, [rax+0xD0]
0000708296fd5f5b  movups xmm1, [r13+r14*1]
0000708296fd5f61  vmovaps xmm3, [rsp+0xD0]
0000708296fd5f6a  vmovaps [rsp+0x70], xmm1
0000708296fd5f70  movaps xmm5, xmm6
0000708296fd5f73  addpd xmm5, xmm3
0000708296fd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000708296fd5f7c  ptest xmm1, xmm1
0000708296fd5f81  jnz 0x0000708296FD8262
0000708296fd5f87  vmovaps xmm1, [rsp+0x60]
0000708296fd5f8d  vpermilpd xmm1, xmm1, 0x00
0000708296fd5f93  movaps xmm6, xmm9
0000708296fd5f97  mulpd xmm6, xmm1
0000708296fd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000708296fd5fa0  ptest xmm3, xmm3
0000708296fd5fa5  jnz 0x0000708296FD83A2
0000708296fd5fab  movaps [r15+0x260], xmm6
0000708296fd5fb3  vxorps xmm1, xmm1, xmm1
0000708296fd5fb7  vpbroadcastq xmm1, xmm1
0000708296fd5fbc  movaps [r15+0x1B0], xmm1
0000708296fd5fc4  vmovaps xmm1, [rsp+0x60]
0000708296fd5fca  vpermilpd xmm1, xmm1, 0x00
0000708296fd5fd0  vmovaps xmm3, [rsp+0x70]
0000708296fd5fd6  vmovaps [rsp+0x70], xmm15
0000708296fd5fdc  movaps xmm9, xmm3
0000708296fd5fe0  mulpd xmm9, xmm1
0000708296fd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000708296fd5feb  ptest xmm15, xmm15
0000708296fd5ff1  jnz 0x0000708296FD84E3
0000708296fd5ff7  lea r14, [rax+0xC0]
0000708296fd5ffe  movups xmm1, [r13+r14*1]
0000708296fd6004  vmovaps xmm3, [rsp+0xC0]
0000708296fd600d  vmovaps [rsp+0x80], xmm1
0000708296fd6016  movaps xmm15, xmm3
0000708296fd601a  addpd xmm15, xmm7
0000708296fd601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000708296fd6025  ptest xmm1, xmm1
0000708296fd602a  jnz 0x0000708296FD862F
0000708296fd6030  vmovaps [rsp+0xC0], xmm13
0000708296fd6039  vmovaps xmm1, [rsp+0xC0]
0000708296fd6042  por xmm13, xmm1
0000708296fd6047  movaps [r15+0x270], xmm13
0000708296fd604f  vmovaps xmm1, [rsp+0xB0]
0000708296fd6058  vmovaps xmm7, [rsp+0xB0]
0000708296fd6061  por xmm1, xmm7
0000708296fd6065  movaps [r15+0x1A0], xmm1
0000708296fd606d  vmovaps xmm1, [rsp+0x60]
0000708296fd6073  vpermilpd xmm1, xmm1, 0x00
0000708296fd6079  vmovaps [rsp+0xB0], xmm1
0000708296fd6082  vmovaps xmm1, [rsp+0x80]
0000708296fd608b  vmovaps [rsp+0x80], xmm15
0000708296fd6094  vmovaps xmm15, [rsp+0xB0]
0000708296fd609d  vmovaps [rsp+0xB0], xmm14
0000708296fd60a6  movaps xmm3, xmm1
0000708296fd60a9  mulpd xmm3, xmm15
0000708296fd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000708296fd60b3  ptest xmm14, xmm14
0000708296fd60b9  jnz 0x0000708296FD8771
0000708296fd60bf  lea r14, [rax+0x20]
0000708296fd60c3  movups xmm1, [r13+r14*1]
0000708296fd60c9  movaps [r15+0x110], xmm1
0000708296fd60d1  vmovaps xmm14, [rsp+0x70]
0000708296fd60d7  vmovaps [rsp+0x70], xmm1
0000708296fd60dd  movaps xmm15, xmm14
0000708296fd60e1  addpd xmm15, xmm4
0000708296fd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000708296fd60ec  ptest xmm1, xmm1
0000708296fd60f1  jnz 0x0000708296FD88BC
0000708296fd60f7  vmovaps xmm1, [rsp+0x60]
0000708296fd60fd  vpermilpd xmm1, xmm1, 0x00
0000708296fd6103  movaps xmm14, xmm2
0000708296fd6107  mulpd xmm14, xmm1
0000708296fd610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000708296fd6112  ptest xmm4, xmm4
0000708296fd6117  jnz 0x0000708296FD89FF
0000708296fd611d  vmovaps xmm4, [rsp+0x50]
0000708296fd6123  movaps xmm1, xmm4
0000708296fd6126  addpd xmm1, xmm9
0000708296fd612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000708296fd6130  ptest xmm2, xmm2
0000708296fd6135  jnz 0x0000708296FD8B41
0000708296fd613b  vmovaps xmm9, [rsp+0x30]
0000708296fd6141  vpermilpd xmm9, xmm9, 0x00
0000708296fd6147  vmovaps xmm2, [rsp+0x70]
0000708296fd614d  vmovaps [rsp+0x50], xmm1
0000708296fd6153  movaps xmm4, xmm2
0000708296fd6156  mulpd xmm4, xmm9
0000708296fd615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000708296fd6160  ptest xmm1, xmm1
0000708296fd6165  jnz 0x0000708296FD8C82
0000708296fd616b  vmovaps xmm1, [rsp+0x30]
0000708296fd6171  vpermilpd xmm1, xmm1, 0x00
0000708296fd6177  vmovaps xmm2, [rsp+0x90]
0000708296fd6180  vmovaps [rsp+0x60], xmm15
0000708296fd6186  movaps xmm9, xmm2
0000708296fd618a  mulpd xmm9, xmm1
0000708296fd618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000708296fd6195  ptest xmm15, xmm15
0000708296fd619b  jnz 0x0000708296FD8DC3
0000708296fd61a1  vmovaps xmm15, [rsp+0x80]
0000708296fd61aa  movaps xmm1, xmm15
0000708296fd61ae  addpd xmm1, xmm6
0000708296fd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000708296fd61b7  ptest xmm2, xmm2
0000708296fd61bc  jnz 0x0000708296FD8F05
0000708296fd61c2  movaps xmm15, xmm5
0000708296fd61c6  addpd xmm15, xmm3
0000708296fd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000708296fd61d1  ptest xmm6, xmm6
0000708296fd61d6  jnz 0x0000708296FD9046
0000708296fd61dc  vmovaps xmm6, [rsp+0x30]
0000708296fd61e2  vpermilpd xmm6, xmm6, 0x00
0000708296fd61e8  movaps xmm5, xmm8
0000708296fd61ec  mulpd xmm5, xmm6
0000708296fd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000708296fd61f5  ptest xmm3, xmm3
0000708296fd61fa  jnz 0x0000708296FD9188
0000708296fd6200  vmovaps xmm8, [rsp+0x30]
0000708296fd6206  vpermilpd xmm8, xmm8, 0x00
0000708296fd620c  movaps xmm6, xmm10
0000708296fd6210  mulpd xmm6, xmm8
0000708296fd6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000708296fd621a  ptest xmm3, xmm3
0000708296fd621f  jnz 0x0000708296FD92C9
0000708296fd6225  vmovaps xmm8, [rsp+0x60]
0000708296fd622b  movaps xmm10, xmm8
0000708296fd622f  addpd xmm10, xmm14
0000708296fd6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000708296fd623a  ptest xmm3, xmm3
0000708296fd623f  jnz 0x0000708296FD940B
0000708296fd6245  vmovaps xmm8, [rsp+0x50]
0000708296fd624b  movaps xmm14, xmm8
0000708296fd624f  addpd xmm14, xmm4
0000708296fd6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000708296fd625a  ptest xmm3, xmm3
0000708296fd625f  jnz 0x0000708296FD954F
0000708296fd6265  vmovaps xmm8, [rsp+0x40]
0000708296fd626b  vpermilpd xmm8, xmm8, 0x00
0000708296fd6271  movaps xmm4, xmm13
0000708296fd6275  mulpd xmm4, xmm8
0000708296fd627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000708296fd627f  ptest xmm3, xmm3
0000708296fd6284  jnz 0x0000708296FD9692
0000708296fd628a  movaps xmm13, xmm15
0000708296fd628e  addpd xmm13, xmm9
0000708296fd6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000708296fd6299  ptest xmm8, xmm8
0000708296fd629f  jnz 0x0000708296FD97D4
0000708296fd62a5  movaps xmm15, xmm1
0000708296fd62a9  addpd xmm15, xmm5
0000708296fd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000708296fd62b4  ptest xmm9, xmm9
0000708296fd62ba  jnz 0x0000708296FD9918
0000708296fd62c0  vmovaps [rsp+0x30], xmm11
0000708296fd62c6  vmovaps xmm1, [rsp+0x30]
0000708296fd62cc  por xmm11, xmm1
0000708296fd62d1  movaps [r15+0x250], xmm11
0000708296fd62d9  vmovaps [rsp+0x30], xmm12
0000708296fd62df  vmovaps xmm1, [rsp+0x30]
0000708296fd62e5  por xmm12, xmm1
0000708296fd62ea  movaps [r15+0x2A0], xmm12
0000708296fd62f2  vmovaps xmm1, [rsp+0xA0]
0000708296fd62fb  vmovaps xmm11, [rsp+0xA0]
0000708296fd6304  por xmm1, xmm11
0000708296fd6309  movaps [r15+0x1D0], xmm1
0000708296fd6311  lea r14, [rax+0x40]
0000708296fd6315  movups xmm1, [r13+r14*1]
0000708296fd631b  movaps [r15+0x2C0], xmm1
0000708296fd6323  vmovaps xmm11, [rsp+0x40]
0000708296fd6329  vpermilpd xmm11, xmm11, 0x00
0000708296fd632f  vmovaps xmm8, [rsp+0xE0]
0000708296fd6338  movaps xmm9, xmm8
0000708296fd633c  mulpd xmm9, xmm11
0000708296fd6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000708296fd6347  ptest xmm5, xmm5
0000708296fd634c  jnz 0x0000708296FD9A64
0000708296fd6352  movaps xmm11, xmm10
0000708296fd6356  addpd xmm11, xmm6
0000708296fd635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000708296fd6361  ptest xmm8, xmm8
0000708296fd6367  jnz 0x0000708296FD9BA8
0000708296fd636d  movaps xmm10, xmm14
0000708296fd6371  addpd xmm10, xmm4
0000708296fd6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000708296fd637c  ptest xmm8, xmm8
0000708296fd6382  jnz 0x0000708296FD9CEB
0000708296fd6388  vmovaps xmm14, [rsp+0x40]
0000708296fd638e  vpermilpd xmm14, xmm14, 0x00
0000708296fd6394  movaps xmm8, xmm1
0000708296fd6398  mulpd xmm8, xmm14
0000708296fd639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000708296fd63a3  ptest xmm6, xmm6
0000708296fd63a8  jnz 0x0000708296FD9E2E
0000708296fd63ae  movaps xmm1, [r15+0x2B0]
0000708296fd63b6  vmovaps xmm14, [rsp+0x40]
0000708296fd63bc  vpermilpd xmm14, xmm14, 0x00
0000708296fd63c2  movaps xmm6, xmm1
0000708296fd63c5  mulpd xmm6, xmm14
0000708296fd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000708296fd63cf  ptest xmm5, xmm5
0000708296fd63d4  jnz 0x0000708296FD9F71
0000708296fd63da  vmovaps xmm1, [rsp+0x10]
0000708296fd63e0  vpermilpd xmm1, xmm1, 0x00
0000708296fd63e6  movaps xmm14, xmm12
0000708296fd63ea  mulpd xmm14, xmm1
0000708296fd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000708296fd63f5  ptest xmm5, xmm5
0000708296fd63fa  jnz 0x0000708296FDA0B2
0000708296fd6400  movaps xmm1, xmm13
0000708296fd6404  addpd xmm1, xmm9
0000708296fd6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000708296fd640e  ptest xmm12, xmm12
0000708296fd6414  jnz 0x0000708296FDA1F5
0000708296fd641a  vmovaps xmm13, [rsp+0x10]
0000708296fd6420  vpermilpd xmm13, xmm13, 0x00
0000708296fd6426  movaps xmm12, xmm7
0000708296fd642a  mulpd xmm12, xmm13
0000708296fd642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000708296fd6435  ptest xmm9, xmm9
0000708296fd643b  jnz 0x0000708296FDA337
0000708296fd6441  movaps xmm13, xmm15
0000708296fd6445  addpd xmm13, xmm8
0000708296fd644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000708296fd6450  ptest xmm9, xmm9
0000708296fd6456  jnz 0x0000708296FDA47A
0000708296fd645c  movaps xmm15, [r15+0x290]
0000708296fd6464  vmovaps xmm9, [rsp+0x10]
0000708296fd646a  vpermilpd xmm9, xmm9, 0x00
0000708296fd6470  movaps xmm8, xmm15
0000708296fd6474  mulpd xmm8, xmm9
0000708296fd6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000708296fd647f  ptest xmm7, xmm7
0000708296fd6484  jnz 0x0000708296FDA5BE
0000708296fd648a  movaps xmm15, xmm11
0000708296fd648e  addpd xmm15, xmm6
0000708296fd6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000708296fd6499  ptest xmm9, xmm9
0000708296fd649f  jnz 0x0000708296FDA702
0000708296fd64a5  movaps xmm11, [r15+0x1E0]
0000708296fd64ad  vmovaps xmm9, [rsp+0x10]
0000708296fd64b3  vpermilpd xmm9, xmm9, 0x00
0000708296fd64b9  movaps xmm7, xmm11
0000708296fd64bd  mulpd xmm7, xmm9
0000708296fd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000708296fd64c7  ptest xmm6, xmm6
0000708296fd64cc  jnz 0x0000708296FDA845
0000708296fd64d2  movaps xmm11, xmm10
0000708296fd64d6  addpd xmm11, xmm14
0000708296fd64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000708296fd64e1  ptest xmm9, xmm9
0000708296fd64e7  jnz 0x0000708296FDA987
0000708296fd64ed  lea r14, [rax+0x70]
0000708296fd64f1  movups xmm14, [r13+r14*1]
0000708296fd64f7  movaps [r15+0x240], xmm14
0000708296fd64ff  movaps xmm10, xmm1
0000708296fd6503  addpd xmm10, xmm12
0000708296fd6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000708296fd650e  ptest xmm9, xmm9
0000708296fd6514  jnz 0x0000708296FDAAD5
0000708296fd651a  movaps [r15+0x170], xmm10
0000708296fd6522  vmovaps xmm1, [rsp+0x20]
0000708296fd6528  vpermilpd xmm1, xmm1, 0x00
0000708296fd652e  movaps xmm12, xmm14
0000708296fd6532  mulpd xmm12, xmm1
0000708296fd6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000708296fd653d  ptest xmm9, xmm9
0000708296fd6543  jnz 0x0000708296FDAC18
0000708296fd6549  vmovaps xmm1, [rsp+0x20]
0000708296fd654f  vpermilpd xmm1, xmm1, 0x00
0000708296fd6555  vmovaps xmm9, [rsp+0xB0]
0000708296fd655e  movaps xmm14, xmm9
0000708296fd6562  mulpd xmm14, xmm1
0000708296fd6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000708296fd656d  ptest xmm6, xmm6
0000708296fd6572  jnz 0x0000708296FDAD5B
0000708296fd6578  movaps [r15+0x180], xmm14
0000708296fd6580  movaps xmm1, xmm13
0000708296fd6584  addpd xmm1, xmm8
0000708296fd6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000708296fd658e  ptest xmm9, xmm9
0000708296fd6594  jnz 0x0000708296FDAE9E
0000708296fd659a  movaps [r15+0x210], xmm1
0000708296fd65a2  movups xmm13, [r13+rax*1]
0000708296fd65a8  lea r14, [rax+0x10]
0000708296fd65ac  movups xmm9, [r13+r14*1]
0000708296fd65b2  movaps [r15+0x230], xmm9
0000708296fd65ba  movaps xmm8, xmm15
0000708296fd65be  addpd xmm8, xmm7
0000708296fd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000708296fd65c9  ptest xmm6, xmm6
0000708296fd65ce  jnz 0x0000708296FDAFF4
0000708296fd65d4  movaps [r15+0x130], xmm8
0000708296fd65dc  vmovaps xmm15, [rsp+0x20]
0000708296fd65e2  vpermilpd xmm15, xmm15, 0x00
0000708296fd65e8  movaps xmm7, xmm9
0000708296fd65ec  mulpd xmm7, xmm15
0000708296fd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000708296fd65f6  ptest xmm6, xmm6
0000708296fd65fb  jnz 0x0000708296FDB137
0000708296fd6601  movaps [r15+0x220], xmm7
0000708296fd6609  vmovaps xmm15, [rsp+0x20]
0000708296fd660f  vpermilpd xmm15, xmm15, 0x00
0000708296fd6615  movaps xmm9, xmm13
0000708296fd6619  mulpd xmm9, xmm15
0000708296fd661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000708296fd6624  ptest xmm6, xmm6
0000708296fd6629  jnz 0x0000708296FDB279
0000708296fd662f  movaps xmm15, xmm11
0000708296fd6633  addpd xmm15, xmm12
0000708296fd6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000708296fd663e  ptest xmm13, xmm13
0000708296fd6644  jnz 0x0000708296FDB3BD
0000708296fd664a  movaps [r15+0x140], xmm15
0000708296fd6652  movaps xmm13, xmm10
0000708296fd6656  addpd xmm13, xmm14
0000708296fd665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000708296fd6661  ptest xmm12, xmm12
0000708296fd6667  jnz 0x0000708296FDB501
0000708296fd666d  movaps [r15+0x150], xmm13
0000708296fd6675  movaps xmm14, xmm1
0000708296fd6679  addpd xmm14, xmm7
0000708296fd667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000708296fd6684  ptest xmm12, xmm12
0000708296fd668a  jnz 0x0000708296FDB645
0000708296fd6690  movaps [r15+0x160], xmm14
0000708296fd6698  movaps xmm1, xmm8
0000708296fd669c  addpd xmm1, xmm9
0000708296fd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000708296fd66a6  ptest xmm12, xmm12
0000708296fd66ac  jnz 0x0000708296FDB787
0000708296fd66b2  movaps [r15+0x120], xmm1
0000708296fd66ba  movups [r13+r11*1], xmm15
0000708296fd66c0  lea rax, [r11+0x10]
0000708296fd66c4  movups [r13+rax*1], xmm13
0000708296fd66ca  lea rax, [r11+0x20]
0000708296fd66ce  movups [r13+rax*1], xmm14
0000708296fd66d4  lea rax, [r11+0x30]
0000708296fd66d8  movups [r13+rax*1], xmm1
0000708296fd66de  mov eax, [r15+0x108]
0000708296fd66e5  sahf
0000708296fd66e6  jnz 0x0000708296FD6718
0000708296fd66e8  cmp dword ptr [r15+0x318], 0x00
0000708296fd66f0  jz 0x0000708296FDB900
0000708296fd66f6  nop [rax+rax*1], ax
0000708296fd66ff  nop [rax+rax*1], eax
0000708296fd6707  mov eax, 0x410444
0000708296fd670c  mov [r15+0x100], rax
0000708296fd6713  jmp 0x0000708296DFE110
0000708296fd6718  cmp dword ptr [r15+0x318], 0x00
0000708296fd6720  jz 0x0000708296FD57E0
0000708296fd6726  nop [rax+rax*1], ax
0000708296fd672f  nop [rax+rax*1], eax
0000708296fd6737  mov eax, 0x410278
0000708296fd673c  mov [r15+0x100], rax
0000708296fd6743  jmp 0x0000708296DFE110
0000708296fd6748  int3
0000708296fd6749  call 0x0000708296E0A4B0
0000708296fd674e  jmp 0x0000708296FD5828
0000708296fd6753  call 0x0000708296E09240
0000708296fd6758  jmp 0x0000708296FD5832
0000708296fd675d  call 0x0000708296E0A4B0
0000708296fd6762  jmp 0x0000708296FD588F
0000708296fd6767  call 0x0000708296E09240
0000708296fd676c  jmp 0x0000708296FD5899
0000708296fd6771  call 0x0000708296E0A4B0
0000708296fd6776  jmp 0x0000708296FD58DD
0000708296fd677b  call 0x0000708296E09240
0000708296fd6780  jmp 0x0000708296FD58E7
0000708296fd6785  call 0x0000708296EB47C0
0000708296fd678a  jmp 0x0000708296FD5926
0000708296fd678f  call 0x0000708296E0B720
0000708296fd6794  jmp 0x0000708296FD593A
0000708296fd6799  call 0x0000708296EBFC30
0000708296fd679e  jmp 0x0000708296FD5958
0000708296fd67a3  call 0x0000708296EBE9C0
0000708296fd67a8  jmp 0x0000708296FD5962
0000708296fd67ad  call 0x0000708296EBD750
0000708296fd67b2  jmp 0x0000708296FD596C
0000708296fd67b7  sub rsp, 0x08
0000708296fd67bb  push rax
0000708296fd67bc  push rcx
0000708296fd67bd  push rdx
0000708296fd67be  push rdi
0000708296fd67bf  push rsi
0000708296fd67c0  push r8
0000708296fd67c2  push r9
0000708296fd67c4  push r10
0000708296fd67c6  push r11
0000708296fd67c8  sub rsp, 0xF0
0000708296fd67cf  vmovaps [rsp], xmm0
0000708296fd67d4  vmovaps [rsp+0x10], xmm1
0000708296fd67da  vmovaps [rsp+0x20], xmm2
0000708296fd67e0  vmovaps [rsp+0x30], xmm3
0000708296fd67e6  vmovaps [rsp+0x40], xmm4
0000708296fd67ec  vmovaps [rsp+0x50], xmm5
0000708296fd67f2  vmovaps [rsp+0x60], xmm6
0000708296fd67f8  vmovaps [rsp+0x70], xmm7
0000708296fd67fe  vmovaps [rsp+0x80], xmm9
0000708296fd6807  vmovaps [rsp+0x90], xmm10
0000708296fd6810  vmovaps [rsp+0xA0], xmm11
0000708296fd6819  vmovaps [rsp+0xB0], xmm12
0000708296fd6822  vmovaps [rsp+0xC0], xmm13
0000708296fd682b  vmovaps [rsp+0xD0], xmm14
0000708296fd6834  vmovaps [rsp+0xE0], xmm15
0000708296fd683d  sub rsp, 0x30
0000708296fd6841  movaps [rsp], xmm8
0000708296fd6846  movaps [rsp+0x10], xmm12
0000708296fd684c  movaps [rsp+0x20], xmm15
0000708296fd6852  lea rdi, [rsp]
0000708296fd6856  mov esi, 0x00
0000708296fd685b  mov rax, 0x64BBC686C530
0000708296fd6865  call rax
0000708296fd6867  movaps xmm8, [rsp]
0000708296fd686c  add rsp, 0x30
0000708296fd6870  vmovaps xmm0, [rsp]
0000708296fd6875  vmovaps xmm1, [rsp+0x10]
0000708296fd687b  vmovaps xmm2, [rsp+0x20]
0000708296fd6881  vmovaps xmm3, [rsp+0x30]
0000708296fd6887  vmovaps xmm4, [rsp+0x40]
0000708296fd688d  vmovaps xmm5, [rsp+0x50]
0000708296fd6893  vmovaps xmm6, [rsp+0x60]
0000708296fd6899  vmovaps xmm7, [rsp+0x70]
0000708296fd689f  vmovaps xmm9, [rsp+0x80]
0000708296fd68a8  vmovaps xmm10, [rsp+0x90]
0000708296fd68b1  vmovaps xmm11, [rsp+0xA0]
0000708296fd68ba  vmovaps xmm12, [rsp+0xB0]
0000708296fd68c3  vmovaps xmm13, [rsp+0xC0]
0000708296fd68cc  vmovaps xmm14, [rsp+0xD0]
0000708296fd68d5  vmovaps xmm15, [rsp+0xE0]
0000708296fd68de  add rsp, 0xF0
0000708296fd68e5  pop r11
0000708296fd68e7  pop r10
0000708296fd68e9  pop r9
0000708296fd68eb  pop r8
0000708296fd68ed  pop rsi
0000708296fd68ee  pop rdi
0000708296fd68ef  pop rdx
0000708296fd68f0  pop rcx
0000708296fd68f1  pop rax
0000708296fd68f2  add rsp, 0x08
0000708296fd68f6  jmp 0x0000708296FD599A
0000708296fd68fb  sub rsp, 0x08
0000708296fd68ff  push rax
0000708296fd6900  push rcx
0000708296fd6901  push rdx
0000708296fd6902  push rdi
0000708296fd6903  push rsi
0000708296fd6904  push r8
0000708296fd6906  push r9
0000708296fd6908  push r10
0000708296fd690a  push r11
0000708296fd690c  sub rsp, 0xF0
0000708296fd6913  vmovaps [rsp], xmm0
0000708296fd6918  vmovaps [rsp+0x10], xmm1
0000708296fd691e  vmovaps [rsp+0x20], xmm2
0000708296fd6924  vmovaps [rsp+0x30], xmm3
0000708296fd692a  vmovaps [rsp+0x40], xmm4
0000708296fd6930  vmovaps [rsp+0x50], xmm5
0000708296fd6936  vmovaps [rsp+0x60], xmm6
0000708296fd693c  vmovaps [rsp+0x70], xmm8
0000708296fd6942  vmovaps [rsp+0x80], xmm9
0000708296fd694b  vmovaps [rsp+0x90], xmm10
0000708296fd6954  vmovaps [rsp+0xA0], xmm11
0000708296fd695d  vmovaps [rsp+0xB0], xmm12
0000708296fd6966  vmovaps [rsp+0xC0], xmm13
0000708296fd696f  vmovaps [rsp+0xD0], xmm14
0000708296fd6978  vmovaps [rsp+0xE0], xmm15
0000708296fd6981  sub rsp, 0x30
0000708296fd6985  movaps [rsp], xmm7
0000708296fd6989  movaps [rsp+0x10], xmm9
0000708296fd698f  movaps [rsp+0x20], xmm15
0000708296fd6995  lea rdi, [rsp]
0000708296fd6999  mov esi, 0x00
0000708296fd699e  mov rax, 0x64BBC686C530
0000708296fd69a8  call rax
0000708296fd69aa  movaps xmm7, [rsp]
0000708296fd69ae  add rsp, 0x30
0000708296fd69b2  vmovaps xmm0, [rsp]
0000708296fd69b7  vmovaps xmm1, [rsp+0x10]
0000708296fd69bd  vmovaps xmm2, [rsp+0x20]
0000708296fd69c3  vmovaps xmm3, [rsp+0x30]
0000708296fd69c9  vmovaps xmm4, [rsp+0x40]
0000708296fd69cf  vmovaps xmm5, [rsp+0x50]
0000708296fd69d5  vmovaps xmm6, [rsp+0x60]
0000708296fd69db  vmovaps xmm8, [rsp+0x70]
0000708296fd69e1  vmovaps xmm9, [rsp+0x80]
0000708296fd69ea  vmovaps xmm10, [rsp+0x90]
0000708296fd69f3  vmovaps xmm11, [rsp+0xA0]
0000708296fd69fc  vmovaps xmm12, [rsp+0xB0]
0000708296fd6a05  vmovaps xmm13, [rsp+0xC0]
0000708296fd6a0e  vmovaps xmm14, [rsp+0xD0]
0000708296fd6a17  vmovaps xmm15, [rsp+0xE0]
0000708296fd6a20  add rsp, 0xF0
0000708296fd6a27  pop r11
0000708296fd6a29  pop r10
0000708296fd6a2b  pop r9
0000708296fd6a2d  pop r8
0000708296fd6a2f  pop rsi
0000708296fd6a30  pop rdi
0000708296fd6a31  pop rdx
0000708296fd6a32  pop rcx
0000708296fd6a33  pop rax
0000708296fd6a34  add rsp, 0x08
0000708296fd6a38  jmp 0x0000708296FD59C8
0000708296fd6a3d  sub rsp, 0x08
0000708296fd6a41  push rax
0000708296fd6a42  push rcx
0000708296fd6a43  push rdx
0000708296fd6a44  push rdi
0000708296fd6a45  push rsi
0000708296fd6a46  push r8
0000708296fd6a48  push r9
0000708296fd6a4a  push r10
0000708296fd6a4c  push r11
0000708296fd6a4e  sub rsp, 0xF0
0000708296fd6a55  vmovaps [rsp], xmm0
0000708296fd6a5a  vmovaps [rsp+0x10], xmm1
0000708296fd6a60  vmovaps [rsp+0x20], xmm2
0000708296fd6a66  vmovaps [rsp+0x30], xmm3
0000708296fd6a6c  vmovaps [rsp+0x40], xmm4
0000708296fd6a72  vmovaps [rsp+0x50], xmm5
0000708296fd6a78  vmovaps [rsp+0x60], xmm6
0000708296fd6a7e  vmovaps [rsp+0x70], xmm7
0000708296fd6a84  vmovaps [rsp+0x80], xmm8
0000708296fd6a8d  vmovaps [rsp+0x90], xmm10
0000708296fd6a96  vmovaps [rsp+0xA0], xmm11
0000708296fd6a9f  vmovaps [rsp+0xB0], xmm12
0000708296fd6aa8  vmovaps [rsp+0xC0], xmm13
0000708296fd6ab1  vmovaps [rsp+0xD0], xmm14
0000708296fd6aba  vmovaps [rsp+0xE0], xmm15
0000708296fd6ac3  sub rsp, 0x30
0000708296fd6ac7  movaps [rsp], xmm9
0000708296fd6acc  movaps [rsp+0x10], xmm12
0000708296fd6ad2  movaps [rsp+0x20], xmm10
0000708296fd6ad8  lea rdi, [rsp]
0000708296fd6adc  mov esi, 0x00
0000708296fd6ae1  mov rax, 0x64BBC686C530
0000708296fd6aeb  call rax
0000708296fd6aed  movaps xmm9, [rsp]
0000708296fd6af2  add rsp, 0x30
0000708296fd6af6  vmovaps xmm0, [rsp]
0000708296fd6afb  vmovaps xmm1, [rsp+0x10]
0000708296fd6b01  vmovaps xmm2, [rsp+0x20]
0000708296fd6b07  vmovaps xmm3, [rsp+0x30]
0000708296fd6b0d  vmovaps xmm4, [rsp+0x40]
0000708296fd6b13  vmovaps xmm5, [rsp+0x50]
0000708296fd6b19  vmovaps xmm6, [rsp+0x60]
0000708296fd6b1f  vmovaps xmm7, [rsp+0x70]
0000708296fd6b25  vmovaps xmm8, [rsp+0x80]
0000708296fd6b2e  vmovaps xmm10, [rsp+0x90]
0000708296fd6b37  vmovaps xmm11, [rsp+0xA0]
0000708296fd6b40  vmovaps xmm12, [rsp+0xB0]
0000708296fd6b49  vmovaps xmm13, [rsp+0xC0]
0000708296fd6b52  vmovaps xmm14, [rsp+0xD0]
0000708296fd6b5b  vmovaps xmm15, [rsp+0xE0]
0000708296fd6b64  add rsp, 0xF0
0000708296fd6b6b  pop r11
0000708296fd6b6d  pop r10
0000708296fd6b6f  pop r9
0000708296fd6b71  pop r8
0000708296fd6b73  pop rsi
0000708296fd6b74  pop rdi
0000708296fd6b75  pop rdx
0000708296fd6b76  pop rcx
0000708296fd6b77  pop rax
0000708296fd6b78  add rsp, 0x08
0000708296fd6b7c  jmp 0x0000708296FD59EC
0000708296fd6b81  sub rsp, 0x08
0000708296fd6b85  push rax
0000708296fd6b86  push rcx
0000708296fd6b87  push rdx
0000708296fd6b88  push rdi
0000708296fd6b89  push rsi
0000708296fd6b8a  push r8
0000708296fd6b8c  push r9
0000708296fd6b8e  push r10
0000708296fd6b90  push r11
0000708296fd6b92  sub rsp, 0xF0
0000708296fd6b99  vmovaps [rsp], xmm0
0000708296fd6b9e  vmovaps [rsp+0x10], xmm1
0000708296fd6ba4  vmovaps [rsp+0x20], xmm2
0000708296fd6baa  vmovaps [rsp+0x30], xmm3
0000708296fd6bb0  vmovaps [rsp+0x40], xmm4
0000708296fd6bb6  vmovaps [rsp+0x50], xmm5
0000708296fd6bbc  vmovaps [rsp+0x60], xmm6
0000708296fd6bc2  vmovaps [rsp+0x70], xmm7
0000708296fd6bc8  vmovaps [rsp+0x80], xmm8
0000708296fd6bd1  vmovaps [rsp+0x90], xmm9
0000708296fd6bda  vmovaps [rsp+0xA0], xmm11
0000708296fd6be3  vmovaps [rsp+0xB0], xmm12
0000708296fd6bec  vmovaps [rsp+0xC0], xmm13
0000708296fd6bf5  vmovaps [rsp+0xD0], xmm14
0000708296fd6bfe  vmovaps [rsp+0xE0], xmm15
0000708296fd6c07  sub rsp, 0x30
0000708296fd6c0b  movaps [rsp], xmm10
0000708296fd6c10  movaps [rsp+0x10], xmm12
0000708296fd6c16  movaps [rsp+0x20], xmm11
0000708296fd6c1c  lea rdi, [rsp]
0000708296fd6c20  mov esi, 0x00
0000708296fd6c25  mov rax, 0x64BBC686C530
0000708296fd6c2f  call rax
0000708296fd6c31  movaps xmm10, [rsp]
0000708296fd6c36  add rsp, 0x30
0000708296fd6c3a  vmovaps xmm0, [rsp]
0000708296fd6c3f  vmovaps xmm1, [rsp+0x10]
0000708296fd6c45  vmovaps xmm2, [rsp+0x20]
0000708296fd6c4b  vmovaps xmm3, [rsp+0x30]
0000708296fd6c51  vmovaps xmm4, [rsp+0x40]
0000708296fd6c57  vmovaps xmm5, [rsp+0x50]
0000708296fd6c5d  vmovaps xmm6, [rsp+0x60]
0000708296fd6c63  vmovaps xmm7, [rsp+0x70]
0000708296fd6c69  vmovaps xmm8, [rsp+0x80]
0000708296fd6c72  vmovaps xmm9, [rsp+0x90]
0000708296fd6c7b  vmovaps xmm11, [rsp+0xA0]
0000708296fd6c84  vmovaps xmm12, [rsp+0xB0]
0000708296fd6c8d  vmovaps xmm13, [rsp+0xC0]
0000708296fd6c96  vmovaps xmm14, [rsp+0xD0]
0000708296fd6c9f  vmovaps xmm15, [rsp+0xE0]
0000708296fd6ca8  add rsp, 0xF0
0000708296fd6caf  pop r11
0000708296fd6cb1  pop r10
0000708296fd6cb3  pop r9
0000708296fd6cb5  pop r8
0000708296fd6cb7  pop rsi
0000708296fd6cb8  pop rdi
0000708296fd6cb9  pop rdx
0000708296fd6cba  pop rcx
0000708296fd6cbb  pop rax
0000708296fd6cbc  add rsp, 0x08
0000708296fd6cc0  jmp 0x0000708296FD5A06
0000708296fd6cc5  sub rsp, 0x08
0000708296fd6cc9  push rax
0000708296fd6cca  push rcx
0000708296fd6ccb  push rdx
0000708296fd6ccc  push rdi
0000708296fd6ccd  push rsi
0000708296fd6cce  push r8
0000708296fd6cd0  push r9
0000708296fd6cd2  push r10
0000708296fd6cd4  push r11
0000708296fd6cd6  sub rsp, 0xF0
0000708296fd6cdd  vmovaps [rsp], xmm0
0000708296fd6ce2  vmovaps [rsp+0x10], xmm1
0000708296fd6ce8  vmovaps [rsp+0x20], xmm2
0000708296fd6cee  vmovaps [rsp+0x30], xmm3
0000708296fd6cf4  vmovaps [rsp+0x40], xmm4
0000708296fd6cfa  vmovaps [rsp+0x50], xmm5
0000708296fd6d00  vmovaps [rsp+0x60], xmm7
0000708296fd6d06  vmovaps [rsp+0x70], xmm8
0000708296fd6d0c  vmovaps [rsp+0x80], xmm9
0000708296fd6d15  vmovaps [rsp+0x90], xmm10
0000708296fd6d1e  vmovaps [rsp+0xA0], xmm11
0000708296fd6d27  vmovaps [rsp+0xB0], xmm12
0000708296fd6d30  vmovaps [rsp+0xC0], xmm13
0000708296fd6d39  vmovaps [rsp+0xD0], xmm14
0000708296fd6d42  vmovaps [rsp+0xE0], xmm15
0000708296fd6d4b  sub rsp, 0x30
0000708296fd6d4f  movaps [rsp], xmm6
0000708296fd6d53  movaps [rsp+0x10], xmm12
0000708296fd6d59  movaps [rsp+0x20], xmm11
0000708296fd6d5f  lea rdi, [rsp]
0000708296fd6d63  mov esi, 0x00
0000708296fd6d68  mov rax, 0x64BBC686C530
0000708296fd6d72  call rax
0000708296fd6d74  movaps xmm6, [rsp]
0000708296fd6d78  add rsp, 0x30
0000708296fd6d7c  vmovaps xmm0, [rsp]
0000708296fd6d81  vmovaps xmm1, [rsp+0x10]
0000708296fd6d87  vmovaps xmm2, [rsp+0x20]
0000708296fd6d8d  vmovaps xmm3, [rsp+0x30]
0000708296fd6d93  vmovaps xmm4, [rsp+0x40]
0000708296fd6d99  vmovaps xmm5, [rsp+0x50]
0000708296fd6d9f  vmovaps xmm7, [rsp+0x60]
0000708296fd6da5  vmovaps xmm8, [rsp+0x70]
0000708296fd6dab  vmovaps xmm9, [rsp+0x80]
0000708296fd6db4  vmovaps xmm10, [rsp+0x90]
0000708296fd6dbd  vmovaps xmm11, [rsp+0xA0]
0000708296fd6dc6  vmovaps xmm12, [rsp+0xB0]
0000708296fd6dcf  vmovaps xmm13, [rsp+0xC0]
0000708296fd6dd8  vmovaps xmm14, [rsp+0xD0]
0000708296fd6de1  vmovaps xmm15, [rsp+0xE0]
0000708296fd6dea  add rsp, 0xF0
0000708296fd6df1  pop r11
0000708296fd6df3  pop r10
0000708296fd6df5  pop r9
0000708296fd6df7  pop r8
0000708296fd6df9  pop rsi
0000708296fd6dfa  pop rdi
0000708296fd6dfb  pop rdx
0000708296fd6dfc  pop rcx
0000708296fd6dfd  pop rax
0000708296fd6dfe  add rsp, 0x08
0000708296fd6e02  jmp 0x0000708296FD5A27
0000708296fd6e07  sub rsp, 0x08
0000708296fd6e0b  push rax
0000708296fd6e0c  push rcx
0000708296fd6e0d  push rdx
0000708296fd6e0e  push rdi
0000708296fd6e0f  push rsi
0000708296fd6e10  push r8
0000708296fd6e12  push r9
0000708296fd6e14  push r10
0000708296fd6e16  push r11
0000708296fd6e18  sub rsp, 0xF0
0000708296fd6e1f  vmovaps [rsp], xmm0
0000708296fd6e24  vmovaps [rsp+0x10], xmm1
0000708296fd6e2a  vmovaps [rsp+0x20], xmm2
0000708296fd6e30  vmovaps [rsp+0x30], xmm4
0000708296fd6e36  vmovaps [rsp+0x40], xmm5
0000708296fd6e3c  vmovaps [rsp+0x50], xmm6
0000708296fd6e42  vmovaps [rsp+0x60], xmm7
0000708296fd6e48  vmovaps [rsp+0x70], xmm8
0000708296fd6e4e  vmovaps [rsp+0x80], xmm9
0000708296fd6e57  vmovaps [rsp+0x90], xmm10
0000708296fd6e60  vmovaps [rsp+0xA0], xmm11
0000708296fd6e69  vmovaps [rsp+0xB0], xmm12
0000708296fd6e72  vmovaps [rsp+0xC0], xmm13
0000708296fd6e7b  vmovaps [rsp+0xD0], xmm14
0000708296fd6e84  vmovaps [rsp+0xE0], xmm15
0000708296fd6e8d  sub rsp, 0x30
0000708296fd6e91  movaps [rsp], xmm3
0000708296fd6e95  movaps [rsp+0x10], xmm5
0000708296fd6e9a  movaps [rsp+0x20], xmm4
0000708296fd6e9f  lea rdi, [rsp]
0000708296fd6ea3  mov esi, 0x00
0000708296fd6ea8  mov rax, 0x64BBC686C530
0000708296fd6eb2  call rax
0000708296fd6eb4  movaps xmm3, [rsp]
0000708296fd6eb8  add rsp, 0x30
0000708296fd6ebc  vmovaps xmm0, [rsp]
0000708296fd6ec1  vmovaps xmm1, [rsp+0x10]
0000708296fd6ec7  vmovaps xmm2, [rsp+0x20]
0000708296fd6ecd  vmovaps xmm4, [rsp+0x30]
0000708296fd6ed3  vmovaps xmm5, [rsp+0x40]
0000708296fd6ed9  vmovaps xmm6, [rsp+0x50]
0000708296fd6edf  vmovaps xmm7, [rsp+0x60]
0000708296fd6ee5  vmovaps xmm8, [rsp+0x70]
0000708296fd6eeb  vmovaps xmm9, [rsp+0x80]
0000708296fd6ef4  vmovaps xmm10, [rsp+0x90]
0000708296fd6efd  vmovaps xmm11, [rsp+0xA0]
0000708296fd6f06  vmovaps xmm12, [rsp+0xB0]
0000708296fd6f0f  vmovaps xmm13, [rsp+0xC0]
0000708296fd6f18  vmovaps xmm14, [rsp+0xD0]
0000708296fd6f21  vmovaps xmm15, [rsp+0xE0]
0000708296fd6f2a  add rsp, 0xF0
0000708296fd6f31  pop r11
0000708296fd6f33  pop r10
0000708296fd6f35  pop r9
0000708296fd6f37  pop r8
0000708296fd6f39  pop rsi
0000708296fd6f3a  pop rdi
0000708296fd6f3b  pop rdx
0000708296fd6f3c  pop rcx
0000708296fd6f3d  pop rax
0000708296fd6f3e  add rsp, 0x08
0000708296fd6f42  jmp 0x0000708296FD5A88
0000708296fd6f47  sub rsp, 0x08
0000708296fd6f4b  push rax
0000708296fd6f4c  push rcx
0000708296fd6f4d  push rdx
0000708296fd6f4e  push rdi
0000708296fd6f4f  push rsi
0000708296fd6f50  push r8
0000708296fd6f52  push r9
0000708296fd6f54  push r10
0000708296fd6f56  push r11
0000708296fd6f58  sub rsp, 0xF0
0000708296fd6f5f  vmovaps [rsp], xmm0
0000708296fd6f64  vmovaps [rsp+0x10], xmm1
0000708296fd6f6a  vmovaps [rsp+0x20], xmm2
0000708296fd6f70  vmovaps [rsp+0x30], xmm3
0000708296fd6f76  vmovaps [rsp+0x40], xmm4
0000708296fd6f7c  vmovaps [rsp+0x50], xmm6
0000708296fd6f82  vmovaps [rsp+0x60], xmm7
0000708296fd6f88  vmovaps [rsp+0x70], xmm8
0000708296fd6f8e  vmovaps [rsp+0x80], xmm9
0000708296fd6f97  vmovaps [rsp+0x90], xmm10
0000708296fd6fa0  vmovaps [rsp+0xA0], xmm11
0000708296fd6fa9  vmovaps [rsp+0xB0], xmm12
0000708296fd6fb2  vmovaps [rsp+0xC0], xmm13
0000708296fd6fbb  vmovaps [rsp+0xD0], xmm14
0000708296fd6fc4  vmovaps [rsp+0xE0], xmm15
0000708296fd6fcd  sub rsp, 0x30
0000708296fd6fd1  movaps [rsp], xmm5
0000708296fd6fd5  movaps [rsp+0x10], xmm8
0000708296fd6fdb  movaps [rsp+0x20], xmm15
0000708296fd6fe1  lea rdi, [rsp]
0000708296fd6fe5  mov esi, 0x00
0000708296fd6fea  mov rax, 0x64BBC686C530
0000708296fd6ff4  call rax
0000708296fd6ff6  movaps xmm5, [rsp]
0000708296fd6ffa  add rsp, 0x30
0000708296fd6ffe  vmovaps xmm0, [rsp]
0000708296fd7003  vmovaps xmm1, [rsp+0x10]
0000708296fd7009  vmovaps xmm2, [rsp+0x20]
0000708296fd700f  vmovaps xmm3, [rsp+0x30]
0000708296fd7015  vmovaps xmm4, [rsp+0x40]
0000708296fd701b  vmovaps xmm6, [rsp+0x50]
0000708296fd7021  vmovaps xmm7, [rsp+0x60]
0000708296fd7027  vmovaps xmm8, [rsp+0x70]
0000708296fd702d  vmovaps xmm9, [rsp+0x80]
0000708296fd7036  vmovaps xmm10, [rsp+0x90]
0000708296fd703f  vmovaps xmm11, [rsp+0xA0]
0000708296fd7048  vmovaps xmm12, [rsp+0xB0]
0000708296fd7051  vmovaps xmm13, [rsp+0xC0]
0000708296fd705a  vmovaps xmm14, [rsp+0xD0]
0000708296fd7063  vmovaps xmm15, [rsp+0xE0]
0000708296fd706c  add rsp, 0xF0
0000708296fd7073  pop r11
0000708296fd7075  pop r10
0000708296fd7077  pop r9
0000708296fd7079  pop r8
0000708296fd707b  pop rsi
0000708296fd707c  pop rdi
0000708296fd707d  pop rdx
0000708296fd707e  pop rcx
0000708296fd707f  pop rax
0000708296fd7080  add rsp, 0x08
0000708296fd7084  jmp 0x0000708296FD5AC0
0000708296fd7089  sub rsp, 0x08
0000708296fd708d  push rax
0000708296fd708e  push rcx
0000708296fd708f  push rdx
0000708296fd7090  push rdi
0000708296fd7091  push rsi
0000708296fd7092  push r8
0000708296fd7094  push r9
0000708296fd7096  push r10
0000708296fd7098  push r11
0000708296fd709a  sub rsp, 0xF0
0000708296fd70a1  vmovaps [rsp], xmm0
0000708296fd70a6  vmovaps [rsp+0x10], xmm1
0000708296fd70ac  vmovaps [rsp+0x20], xmm2
0000708296fd70b2  vmovaps [rsp+0x30], xmm3
0000708296fd70b8  vmovaps [rsp+0x40], xmm5
0000708296fd70be  vmovaps [rsp+0x50], xmm6
0000708296fd70c4  vmovaps [rsp+0x60], xmm7
0000708296fd70ca  vmovaps [rsp+0x70], xmm8
0000708296fd70d0  vmovaps [rsp+0x80], xmm9
0000708296fd70d9  vmovaps [rsp+0x90], xmm10
0000708296fd70e2  vmovaps [rsp+0xA0], xmm11
0000708296fd70eb  vmovaps [rsp+0xB0], xmm12
0000708296fd70f4  vmovaps [rsp+0xC0], xmm13
0000708296fd70fd  vmovaps [rsp+0xD0], xmm14
0000708296fd7106  vmovaps [rsp+0xE0], xmm15
0000708296fd710f  sub rsp, 0x30
0000708296fd7113  movaps [rsp], xmm4
0000708296fd7117  movaps [rsp+0x10], xmm9
0000708296fd711d  movaps [rsp+0x20], xmm8
0000708296fd7123  lea rdi, [rsp]
0000708296fd7127  mov esi, 0x00
0000708296fd712c  mov rax, 0x64BBC686C530
0000708296fd7136  call rax
0000708296fd7138  movaps xmm4, [rsp]
0000708296fd713c  add rsp, 0x30
0000708296fd7140  vmovaps xmm0, [rsp]
0000708296fd7145  vmovaps xmm1, [rsp+0x10]
0000708296fd714b  vmovaps xmm2, [rsp+0x20]
0000708296fd7151  vmovaps xmm3, [rsp+0x30]
0000708296fd7157  vmovaps xmm5, [rsp+0x40]
0000708296fd715d  vmovaps xmm6, [rsp+0x50]
0000708296fd7163  vmovaps xmm7, [rsp+0x60]
0000708296fd7169  vmovaps xmm8, [rsp+0x70]
0000708296fd716f  vmovaps xmm9, [rsp+0x80]
0000708296fd7178  vmovaps xmm10, [rsp+0x90]
0000708296fd7181  vmovaps xmm11, [rsp+0xA0]
0000708296fd718a  vmovaps xmm12, [rsp+0xB0]
0000708296fd7193  vmovaps xmm13, [rsp+0xC0]
0000708296fd719c  vmovaps xmm14, [rsp+0xD0]
0000708296fd71a5  vmovaps xmm15, [rsp+0xE0]
0000708296fd71ae  add rsp, 0xF0
0000708296fd71b5  pop r11
0000708296fd71b7  pop r10
0000708296fd71b9  pop r9
0000708296fd71bb  pop r8
0000708296fd71bd  pop rsi
0000708296fd71be  pop rdi
0000708296fd71bf  pop rdx
0000708296fd71c0  pop rcx
0000708296fd71c1  pop rax
0000708296fd71c2  add rsp, 0x08
0000708296fd71c6  jmp 0x0000708296FD5AE1
0000708296fd71cb  sub rsp, 0x08
0000708296fd71cf  push rax
0000708296fd71d0  push rcx
0000708296fd71d1  push rdx
0000708296fd71d2  push rdi
0000708296fd71d3  push rsi
0000708296fd71d4  push r8
0000708296fd71d6  push r9
0000708296fd71d8  push r10
0000708296fd71da  push r11
0000708296fd71dc  sub rsp, 0xF0
0000708296fd71e3  vmovaps [rsp], xmm0
0000708296fd71e8  vmovaps [rsp+0x10], xmm1
0000708296fd71ee  vmovaps [rsp+0x20], xmm2
0000708296fd71f4  vmovaps [rsp+0x30], xmm3
0000708296fd71fa  vmovaps [rsp+0x40], xmm4
0000708296fd7200  vmovaps [rsp+0x50], xmm5
0000708296fd7206  vmovaps [rsp+0x60], xmm6
0000708296fd720c  vmovaps [rsp+0x70], xmm7
0000708296fd7212  vmovaps [rsp+0x80], xmm8
0000708296fd721b  vmovaps [rsp+0x90], xmm10
0000708296fd7224  vmovaps [rsp+0xA0], xmm11
0000708296fd722d  vmovaps [rsp+0xB0], xmm12
0000708296fd7236  vmovaps [rsp+0xC0], xmm13
0000708296fd723f  vmovaps [rsp+0xD0], xmm14
0000708296fd7248  vmovaps [rsp+0xE0], xmm15
0000708296fd7251  sub rsp, 0x30
0000708296fd7255  movaps [rsp], xmm9
0000708296fd725a  movaps [rsp+0x10], xmm10
0000708296fd7260  movaps [rsp+0x20], xmm8
0000708296fd7266  lea rdi, [rsp]
0000708296fd726a  mov esi, 0x00
0000708296fd726f  mov rax, 0x64BBC686C530
0000708296fd7279  call rax
0000708296fd727b  movaps xmm9, [rsp]
0000708296fd7280  add rsp, 0x30
0000708296fd7284  vmovaps xmm0, [rsp]
0000708296fd7289  vmovaps xmm1, [rsp+0x10]
0000708296fd728f  vmovaps xmm2, [rsp+0x20]
0000708296fd7295  vmovaps xmm3, [rsp+0x30]
0000708296fd729b  vmovaps xmm4, [rsp+0x40]
0000708296fd72a1  vmovaps xmm5, [rsp+0x50]
0000708296fd72a7  vmovaps xmm6, [rsp+0x60]
0000708296fd72ad  vmovaps xmm7, [rsp+0x70]
0000708296fd72b3  vmovaps xmm8, [rsp+0x80]
0000708296fd72bc  vmovaps xmm10, [rsp+0x90]
0000708296fd72c5  vmovaps xmm11, [rsp+0xA0]
0000708296fd72ce  vmovaps xmm12, [rsp+0xB0]
0000708296fd72d7  vmovaps xmm13, [rsp+0xC0]
0000708296fd72e0  vmovaps xmm14, [rsp+0xD0]
0000708296fd72e9  vmovaps xmm15, [rsp+0xE0]
0000708296fd72f2  add rsp, 0xF0
0000708296fd72f9  pop r11
0000708296fd72fb  pop r10
0000708296fd72fd  pop r9
0000708296fd72ff  pop r8
0000708296fd7301  pop rsi
0000708296fd7302  pop rdi
0000708296fd7303  pop rdx
0000708296fd7304  pop rcx
0000708296fd7305  pop rax
0000708296fd7306  add rsp, 0x08
0000708296fd730a  jmp 0x0000708296FD5AFB
0000708296fd730f  call 0x0000708296ED64F0
0000708296fd7314  jmp 0x0000708296FD5C15
0000708296fd7319  call 0x0000708296ED64F0
0000708296fd731e  jmp 0x0000708296FD5C2B
0000708296fd7323  sub rsp, 0x08
0000708296fd7327  push rax
0000708296fd7328  push rcx
0000708296fd7329  push rdx
0000708296fd732a  push rdi
0000708296fd732b  push rsi
0000708296fd732c  push r8
0000708296fd732e  push r9
0000708296fd7330  push r10
0000708296fd7332  push r11
0000708296fd7334  sub rsp, 0xF0
0000708296fd733b  vmovaps [rsp], xmm0
0000708296fd7340  vmovaps [rsp+0x10], xmm2
0000708296fd7346  vmovaps [rsp+0x20], xmm3
0000708296fd734c  vmovaps [rsp+0x30], xmm4
0000708296fd7352  vmovaps [rsp+0x40], xmm5
0000708296fd7358  vmovaps [rsp+0x50], xmm6
0000708296fd735e  vmovaps [rsp+0x60], xmm7
0000708296fd7364  vmovaps [rsp+0x70], xmm8
0000708296fd736a  vmovaps [rsp+0x80], xmm9
0000708296fd7373  vmovaps [rsp+0x90], xmm10
0000708296fd737c  vmovaps [rsp+0xA0], xmm11
0000708296fd7385  vmovaps [rsp+0xB0], xmm12
0000708296fd738e  vmovaps [rsp+0xC0], xmm13
0000708296fd7397  vmovaps [rsp+0xD0], xmm14
0000708296fd73a0  vmovaps [rsp+0xE0], xmm15
0000708296fd73a9  sub rsp, 0x30
0000708296fd73ad  movaps [rsp], xmm1
0000708296fd73b1  movaps [rsp+0x10], xmm6
0000708296fd73b6  movaps [rsp+0x20], xmm15
0000708296fd73bc  lea rdi, [rsp]
0000708296fd73c0  mov esi, 0x00
0000708296fd73c5  mov rax, 0x64BBC686C530
0000708296fd73cf  call rax
0000708296fd73d1  movaps xmm1, [rsp]
0000708296fd73d5  add rsp, 0x30
0000708296fd73d9  vmovaps xmm0, [rsp]
0000708296fd73de  vmovaps xmm2, [rsp+0x10]
0000708296fd73e4  vmovaps xmm3, [rsp+0x20]
0000708296fd73ea  vmovaps xmm4, [rsp+0x30]
0000708296fd73f0  vmovaps xmm5, [rsp+0x40]
0000708296fd73f6  vmovaps xmm6, [rsp+0x50]
0000708296fd73fc  vmovaps xmm7, [rsp+0x60]
0000708296fd7402  vmovaps xmm8, [rsp+0x70]
0000708296fd7408  vmovaps xmm9, [rsp+0x80]
0000708296fd7411  vmovaps xmm10, [rsp+0x90]
0000708296fd741a  vmovaps xmm11, [rsp+0xA0]
0000708296fd7423  vmovaps xmm12, [rsp+0xB0]
0000708296fd742c  vmovaps xmm13, [rsp+0xC0]
0000708296fd7435  vmovaps xmm14, [rsp+0xD0]
0000708296fd743e  vmovaps xmm15, [rsp+0xE0]
0000708296fd7447  add rsp, 0xF0
0000708296fd744e  pop r11
0000708296fd7450  pop r10
0000708296fd7452  pop r9
0000708296fd7454  pop r8
0000708296fd7456  pop rsi
0000708296fd7457  pop rdi
0000708296fd7458  pop rdx
0000708296fd7459  pop rcx
0000708296fd745a  pop rax
0000708296fd745b  add rsp, 0x08
0000708296fd745f  jmp 0x0000708296FD5C68
0000708296fd7464  call 0x0000708296EE5820
0000708296fd7469  jmp 0x0000708296FD5C75
0000708296fd746e  sub rsp, 0x08
0000708296fd7472  push rax
0000708296fd7473  push rcx
0000708296fd7474  push rdx
0000708296fd7475  push rdi
0000708296fd7476  push rsi
0000708296fd7477  push r8
0000708296fd7479  push r9
0000708296fd747b  push r10
0000708296fd747d  push r11
0000708296fd747f  sub rsp, 0xF0
0000708296fd7486  vmovaps [rsp], xmm0
0000708296fd748b  vmovaps [rsp+0x10], xmm1
0000708296fd7491  vmovaps [rsp+0x20], xmm2
0000708296fd7497  vmovaps [rsp+0x30], xmm3
0000708296fd749d  vmovaps [rsp+0x40], xmm4
0000708296fd74a3  vmovaps [rsp+0x50], xmm5
0000708296fd74a9  vmovaps [rsp+0x60], xmm6
0000708296fd74af  vmovaps [rsp+0x70], xmm7
0000708296fd74b5  vmovaps [rsp+0x80], xmm8
0000708296fd74be  vmovaps [rsp+0x90], xmm9
0000708296fd74c7  vmovaps [rsp+0xA0], xmm10
0000708296fd74d0  vmovaps [rsp+0xB0], xmm11
0000708296fd74d9  vmovaps [rsp+0xC0], xmm12
0000708296fd74e2  vmovaps [rsp+0xD0], xmm13
0000708296fd74eb  vmovaps [rsp+0xE0], xmm15
0000708296fd74f4  sub rsp, 0x30
0000708296fd74f8  movaps [rsp], xmm14
0000708296fd74fd  movaps [rsp+0x10], xmm4
0000708296fd7502  movaps [rsp+0x20], xmm3
0000708296fd7507  lea rdi, [rsp]
0000708296fd750b  mov esi, 0x00
0000708296fd7510  mov rax, 0x64BBC686C530
0000708296fd751a  call rax
0000708296fd751c  movaps xmm14, [rsp]
0000708296fd7521  add rsp, 0x30
0000708296fd7525  vmovaps xmm0, [rsp]
0000708296fd752a  vmovaps xmm1, [rsp+0x10]
0000708296fd7530  vmovaps xmm2, [rsp+0x20]
0000708296fd7536  vmovaps xmm3, [rsp+0x30]
0000708296fd753c  vmovaps xmm4, [rsp+0x40]
0000708296fd7542  vmovaps xmm5, [rsp+0x50]
0000708296fd7548  vmovaps xmm6, [rsp+0x60]
0000708296fd754e  vmovaps xmm7, [rsp+0x70]
0000708296fd7554  vmovaps xmm8, [rsp+0x80]
0000708296fd755d  vmovaps xmm9, [rsp+0x90]
0000708296fd7566  vmovaps xmm10, [rsp+0xA0]
0000708296fd756f  vmovaps xmm11, [rsp+0xB0]
0000708296fd7578  vmovaps xmm12, [rsp+0xC0]
0000708296fd7581  vmovaps xmm13, [rsp+0xD0]
0000708296fd758a  vmovaps xmm15, [rsp+0xE0]
0000708296fd7593  add rsp, 0xF0
0000708296fd759a  pop r11
0000708296fd759c  pop r10
0000708296fd759e  pop r9
0000708296fd75a0  pop r8
0000708296fd75a2  pop rsi
0000708296fd75a3  pop rdi
0000708296fd75a4  pop rdx
0000708296fd75a5  pop rcx
0000708296fd75a6  pop rax
0000708296fd75a7  add rsp, 0x08
0000708296fd75ab  jmp 0x0000708296FD5C8F
0000708296fd75b0  sub rsp, 0x08
0000708296fd75b4  push rax
0000708296fd75b5  push rcx
0000708296fd75b6  push rdx
0000708296fd75b7  push rdi
0000708296fd75b8  push rsi
0000708296fd75b9  push r8
0000708296fd75bb  push r9
0000708296fd75bd  push r10
0000708296fd75bf  push r11
0000708296fd75c1  sub rsp, 0xF0
0000708296fd75c8  vmovaps [rsp], xmm0
0000708296fd75cd  vmovaps [rsp+0x10], xmm1
0000708296fd75d3  vmovaps [rsp+0x20], xmm2
0000708296fd75d9  vmovaps [rsp+0x30], xmm3
0000708296fd75df  vmovaps [rsp+0x40], xmm4
0000708296fd75e5  vmovaps [rsp+0x50], xmm5
0000708296fd75eb  vmovaps [rsp+0x60], xmm7
0000708296fd75f1  vmovaps [rsp+0x70], xmm8
0000708296fd75f7  vmovaps [rsp+0x80], xmm9
0000708296fd7600  vmovaps [rsp+0x90], xmm10
0000708296fd7609  vmovaps [rsp+0xA0], xmm11
0000708296fd7612  vmovaps [rsp+0xB0], xmm12
0000708296fd761b  vmovaps [rsp+0xC0], xmm13
0000708296fd7624  vmovaps [rsp+0xD0], xmm14
0000708296fd762d  vmovaps [rsp+0xE0], xmm15
0000708296fd7636  sub rsp, 0x30
0000708296fd763a  movaps [rsp], xmm6
0000708296fd763e  movaps [rsp+0x10], xmm9
0000708296fd7644  movaps [rsp+0x20], xmm7
0000708296fd7649  lea rdi, [rsp]
0000708296fd764d  mov esi, 0x00
0000708296fd7652  mov rax, 0x64BBC686C530
0000708296fd765c  call rax
0000708296fd765e  movaps xmm6, [rsp]
0000708296fd7662  add rsp, 0x30
0000708296fd7666  vmovaps xmm0, [rsp]
0000708296fd766b  vmovaps xmm1, [rsp+0x10]
0000708296fd7671  vmovaps xmm2, [rsp+0x20]
0000708296fd7677  vmovaps xmm3, [rsp+0x30]
0000708296fd767d  vmovaps xmm4, [rsp+0x40]
0000708296fd7683  vmovaps xmm5, [rsp+0x50]
0000708296fd7689  vmovaps xmm7, [rsp+0x60]
0000708296fd768f  vmovaps xmm8, [rsp+0x70]
0000708296fd7695  vmovaps xmm9, [rsp+0x80]
0000708296fd769e  vmovaps xmm10, [rsp+0x90]
0000708296fd76a7  vmovaps xmm11, [rsp+0xA0]
0000708296fd76b0  vmovaps xmm12, [rsp+0xB0]
0000708296fd76b9  vmovaps xmm13, [rsp+0xC0]
0000708296fd76c2  vmovaps xmm14, [rsp+0xD0]
0000708296fd76cb  vmovaps xmm15, [rsp+0xE0]
0000708296fd76d4  add rsp, 0xF0
0000708296fd76db  pop r11
0000708296fd76dd  pop r10
0000708296fd76df  pop r9
0000708296fd76e1  pop r8
0000708296fd76e3  pop rsi
0000708296fd76e4  pop rdi
0000708296fd76e5  pop rdx
0000708296fd76e6  pop rcx
0000708296fd76e7  pop rax
0000708296fd76e8  add rsp, 0x08
0000708296fd76ec  jmp 0x0000708296FD5CA7
0000708296fd76f1  sub rsp, 0x08
0000708296fd76f5  push rax
0000708296fd76f6  push rcx
0000708296fd76f7  push rdx
0000708296fd76f8  push rdi
0000708296fd76f9  push rsi
0000708296fd76fa  push r8
0000708296fd76fc  push r9
0000708296fd76fe  push r10
0000708296fd7700  push r11
0000708296fd7702  sub rsp, 0xF0
0000708296fd7709  vmovaps [rsp], xmm0
0000708296fd770e  vmovaps [rsp+0x10], xmm1
0000708296fd7714  vmovaps [rsp+0x20], xmm2
0000708296fd771a  vmovaps [rsp+0x30], xmm3
0000708296fd7720  vmovaps [rsp+0x40], xmm4
0000708296fd7726  vmovaps [rsp+0x50], xmm5
0000708296fd772c  vmovaps [rsp+0x60], xmm6
0000708296fd7732  vmovaps [rsp+0x70], xmm8
0000708296fd7738  vmovaps [rsp+0x80], xmm9
0000708296fd7741  vmovaps [rsp+0x90], xmm10
0000708296fd774a  vmovaps [rsp+0xA0], xmm11
0000708296fd7753  vmovaps [rsp+0xB0], xmm12
0000708296fd775c  vmovaps [rsp+0xC0], xmm13
0000708296fd7765  vmovaps [rsp+0xD0], xmm14
0000708296fd776e  vmovaps [rsp+0xE0], xmm15
0000708296fd7777  sub rsp, 0x30
0000708296fd777b  movaps [rsp], xmm7
0000708296fd777f  movaps [rsp+0x10], xmm4
0000708296fd7784  movaps [rsp+0x20], xmm9
0000708296fd778a  lea rdi, [rsp]
0000708296fd778e  mov esi, 0x00
0000708296fd7793  mov rax, 0x64BBC686C530
0000708296fd779d  call rax
0000708296fd779f  movaps xmm7, [rsp]
0000708296fd77a3  add rsp, 0x30
0000708296fd77a7  vmovaps xmm0, [rsp]
0000708296fd77ac  vmovaps xmm1, [rsp+0x10]
0000708296fd77b2  vmovaps xmm2, [rsp+0x20]
0000708296fd77b8  vmovaps xmm3, [rsp+0x30]
0000708296fd77be  vmovaps xmm4, [rsp+0x40]
0000708296fd77c4  vmovaps xmm5, [rsp+0x50]
0000708296fd77ca  vmovaps xmm6, [rsp+0x60]
0000708296fd77d0  vmovaps xmm8, [rsp+0x70]
0000708296fd77d6  vmovaps xmm9, [rsp+0x80]
0000708296fd77df  vmovaps xmm10, [rsp+0x90]
0000708296fd77e8  vmovaps xmm11, [rsp+0xA0]
0000708296fd77f1  vmovaps xmm12, [rsp+0xB0]
0000708296fd77fa  vmovaps xmm13, [rsp+0xC0]
0000708296fd7803  vmovaps xmm14, [rsp+0xD0]
0000708296fd780c  vmovaps xmm15, [rsp+0xE0]
0000708296fd7815  add rsp, 0xF0
0000708296fd781c  pop r11
0000708296fd781e  pop r10
0000708296fd7820  pop r9
0000708296fd7822  pop r8
0000708296fd7824  pop rsi
0000708296fd7825  pop rdi
0000708296fd7826  pop rdx
0000708296fd7827  pop rcx
0000708296fd7828  pop rax
0000708296fd7829  add rsp, 0x08
0000708296fd782d  jmp 0x0000708296FD5CD4
0000708296fd7832  sub rsp, 0x08
0000708296fd7836  push rax
0000708296fd7837  push rcx
0000708296fd7838  push rdx
0000708296fd7839  push rdi
0000708296fd783a  push rsi
0000708296fd783b  push r8
0000708296fd783d  push r9
0000708296fd783f  push r10
0000708296fd7841  push r11
0000708296fd7843  sub rsp, 0xF0
0000708296fd784a  vmovaps [rsp], xmm0
0000708296fd784f  vmovaps [rsp+0x10], xmm1
0000708296fd7855  vmovaps [rsp+0x20], xmm2
0000708296fd785b  vmovaps [rsp+0x30], xmm3
0000708296fd7861  vmovaps [rsp+0x40], xmm5
0000708296fd7867  vmovaps [rsp+0x50], xmm6
0000708296fd786d  vmovaps [rsp+0x60], xmm7
0000708296fd7873  vmovaps [rsp+0x70], xmm8
0000708296fd7879  vmovaps [rsp+0x80], xmm9
0000708296fd7882  vmovaps [rsp+0x90], xmm10
0000708296fd788b  vmovaps [rsp+0xA0], xmm11
0000708296fd7894  vmovaps [rsp+0xB0], xmm12
0000708296fd789d  vmovaps [rsp+0xC0], xmm13
0000708296fd78a6  vmovaps [rsp+0xD0], xmm14
0000708296fd78af  vmovaps [rsp+0xE0], xmm15
0000708296fd78b8  sub rsp, 0x30
0000708296fd78bc  movaps [rsp], xmm4
0000708296fd78c0  movaps [rsp+0x10], xmm15
0000708296fd78c6  movaps [rsp+0x20], xmm9
0000708296fd78cc  lea rdi, [rsp]
0000708296fd78d0  mov esi, 0x00
0000708296fd78d5  mov rax, 0x64BBC686C530
0000708296fd78df  call rax
0000708296fd78e1  movaps xmm4, [rsp]
0000708296fd78e5  add rsp, 0x30
0000708296fd78e9  vmovaps xmm0, [rsp]
0000708296fd78ee  vmovaps xmm1, [rsp+0x10]
0000708296fd78f4  vmovaps xmm2, [rsp+0x20]
0000708296fd78fa  vmovaps xmm3, [rsp+0x30]
0000708296fd7900  vmovaps xmm5, [rsp+0x40]
0000708296fd7906  vmovaps xmm6, [rsp+0x50]
0000708296fd790c  vmovaps xmm7, [rsp+0x60]
0000708296fd7912  vmovaps xmm8, [rsp+0x70]
0000708296fd7918  vmovaps xmm9, [rsp+0x80]
0000708296fd7921  vmovaps xmm10, [rsp+0x90]
0000708296fd792a  vmovaps xmm11, [rsp+0xA0]
0000708296fd7933  vmovaps xmm12, [rsp+0xB0]
0000708296fd793c  vmovaps xmm13, [rsp+0xC0]
0000708296fd7945  vmovaps xmm14, [rsp+0xD0]
0000708296fd794e  vmovaps xmm15, [rsp+0xE0]
0000708296fd7957  add rsp, 0xF0
0000708296fd795e  pop r11
0000708296fd7960  pop r10
0000708296fd7962  pop r9
0000708296fd7964  pop r8
0000708296fd7966  pop rsi
0000708296fd7967  pop rdi
0000708296fd7968  pop rdx
0000708296fd7969  pop rcx
0000708296fd796a  pop rax
0000708296fd796b  add rsp, 0x08
0000708296fd796f  jmp 0x0000708296FD5CF9
0000708296fd7974  call 0x0000708296EE5820
0000708296fd7979  jmp 0x0000708296FD5D06
0000708296fd797e  sub rsp, 0x08
0000708296fd7982  push rax
0000708296fd7983  push rcx
0000708296fd7984  push rdx
0000708296fd7985  push rdi
0000708296fd7986  push rsi
0000708296fd7987  push r8
0000708296fd7989  push r9
0000708296fd798b  push r10
0000708296fd798d  push r11
0000708296fd798f  sub rsp, 0xF0
0000708296fd7996  vmovaps [rsp], xmm0
0000708296fd799b  vmovaps [rsp+0x10], xmm1
0000708296fd79a1  vmovaps [rsp+0x20], xmm2
0000708296fd79a7  vmovaps [rsp+0x30], xmm4
0000708296fd79ad  vmovaps [rsp+0x40], xmm5
0000708296fd79b3  vmovaps [rsp+0x50], xmm6
0000708296fd79b9  vmovaps [rsp+0x60], xmm7
0000708296fd79bf  vmovaps [rsp+0x70], xmm8
0000708296fd79c5  vmovaps [rsp+0x80], xmm9
0000708296fd79ce  vmovaps [rsp+0x90], xmm10
0000708296fd79d7  vmovaps [rsp+0xA0], xmm11
0000708296fd79e0  vmovaps [rsp+0xB0], xmm12
0000708296fd79e9  vmovaps [rsp+0xC0], xmm13
0000708296fd79f2  vmovaps [rsp+0xD0], xmm14
0000708296fd79fb  vmovaps [rsp+0xE0], xmm15
0000708296fd7a04  sub rsp, 0x30
0000708296fd7a08  movaps [rsp], xmm3
0000708296fd7a0c  movaps [rsp+0x10], xmm1
0000708296fd7a11  movaps [rsp+0x20], xmm9
0000708296fd7a17  lea rdi, [rsp]
0000708296fd7a1b  mov esi, 0x00
0000708296fd7a20  mov rax, 0x64BBC686C530
0000708296fd7a2a  call rax
0000708296fd7a2c  movaps xmm3, [rsp]
0000708296fd7a30  add rsp, 0x30
0000708296fd7a34  vmovaps xmm0, [rsp]
0000708296fd7a39  vmovaps xmm1, [rsp+0x10]
0000708296fd7a3f  vmovaps xmm2, [rsp+0x20]
0000708296fd7a45  vmovaps xmm4, [rsp+0x30]
0000708296fd7a4b  vmovaps xmm5, [rsp+0x40]
0000708296fd7a51  vmovaps xmm6, [rsp+0x50]
0000708296fd7a57  vmovaps xmm7, [rsp+0x60]
0000708296fd7a5d  vmovaps xmm8, [rsp+0x70]
0000708296fd7a63  vmovaps xmm9, [rsp+0x80]
0000708296fd7a6c  vmovaps xmm10, [rsp+0x90]
0000708296fd7a75  vmovaps xmm11, [rsp+0xA0]
0000708296fd7a7e  vmovaps xmm12, [rsp+0xB0]
0000708296fd7a87  vmovaps xmm13, [rsp+0xC0]
0000708296fd7a90  vmovaps xmm14, [rsp+0xD0]
0000708296fd7a99  vmovaps xmm15, [rsp+0xE0]
0000708296fd7aa2  add rsp, 0xF0
0000708296fd7aa9  pop r11
0000708296fd7aab  pop r10
0000708296fd7aad  pop r9
0000708296fd7aaf  pop r8
0000708296fd7ab1  pop rsi
0000708296fd7ab2  pop rdi
0000708296fd7ab3  pop rdx
0000708296fd7ab4  pop rcx
0000708296fd7ab5  pop rax
0000708296fd7ab6  add rsp, 0x08
0000708296fd7aba  jmp 0x0000708296FD5D43
0000708296fd7abf  sub rsp, 0x08
0000708296fd7ac3  push rax
0000708296fd7ac4  push rcx
0000708296fd7ac5  push rdx
0000708296fd7ac6  push rdi
0000708296fd7ac7  push rsi
0000708296fd7ac8  push r8
0000708296fd7aca  push r9
0000708296fd7acc  push r10
0000708296fd7ace  push r11
0000708296fd7ad0  sub rsp, 0xF0
0000708296fd7ad7  vmovaps [rsp], xmm0
0000708296fd7adc  vmovaps [rsp+0x10], xmm2
0000708296fd7ae2  vmovaps [rsp+0x20], xmm3
0000708296fd7ae8  vmovaps [rsp+0x30], xmm4
0000708296fd7aee  vmovaps [rsp+0x40], xmm5
0000708296fd7af4  vmovaps [rsp+0x50], xmm6
0000708296fd7afa  vmovaps [rsp+0x60], xmm7
0000708296fd7b00  vmovaps [rsp+0x70], xmm8
0000708296fd7b06  vmovaps [rsp+0x80], xmm9
0000708296fd7b0f  vmovaps [rsp+0x90], xmm10
0000708296fd7b18  vmovaps [rsp+0xA0], xmm11
0000708296fd7b21  vmovaps [rsp+0xB0], xmm12
0000708296fd7b2a  vmovaps [rsp+0xC0], xmm13
0000708296fd7b33  vmovaps [rsp+0xD0], xmm14
0000708296fd7b3c  vmovaps [rsp+0xE0], xmm15
0000708296fd7b45  sub rsp, 0x30
0000708296fd7b49  movaps [rsp], xmm1
0000708296fd7b4d  movaps [rsp+0x10], xmm15
0000708296fd7b53  movaps [rsp+0x20], xmm9
0000708296fd7b59  lea rdi, [rsp]
0000708296fd7b5d  mov esi, 0x00
0000708296fd7b62  mov rax, 0x64BBC686C530
0000708296fd7b6c  call rax
0000708296fd7b6e  movaps xmm1, [rsp]
0000708296fd7b72  add rsp, 0x30
0000708296fd7b76  vmovaps xmm0, [rsp]
0000708296fd7b7b  vmovaps xmm2, [rsp+0x10]
0000708296fd7b81  vmovaps xmm3, [rsp+0x20]
0000708296fd7b87  vmovaps xmm4, [rsp+0x30]
0000708296fd7b8d  vmovaps xmm5, [rsp+0x40]
0000708296fd7b93  vmovaps xmm6, [rsp+0x50]
0000708296fd7b99  vmovaps xmm7, [rsp+0x60]
0000708296fd7b9f  vmovaps xmm8, [rsp+0x70]
0000708296fd7ba5  vmovaps xmm9, [rsp+0x80]
0000708296fd7bae  vmovaps xmm10, [rsp+0x90]
0000708296fd7bb7  vmovaps xmm11, [rsp+0xA0]
0000708296fd7bc0  vmovaps xmm12, [rsp+0xB0]
0000708296fd7bc9  vmovaps xmm13, [rsp+0xC0]
0000708296fd7bd2  vmovaps xmm14, [rsp+0xD0]
0000708296fd7bdb  vmovaps xmm15, [rsp+0xE0]
0000708296fd7be4  add rsp, 0xF0
0000708296fd7beb  pop r11
0000708296fd7bed  pop r10
0000708296fd7bef  pop r9
0000708296fd7bf1  pop r8
0000708296fd7bf3  pop rsi
0000708296fd7bf4  pop rdi
0000708296fd7bf5  pop rdx
0000708296fd7bf6  pop rcx
0000708296fd7bf7  pop rax
0000708296fd7bf8  add rsp, 0x08
0000708296fd7bfc  jmp 0x0000708296FD5DCB
0000708296fd7c01  call 0x0000708296EE5820
0000708296fd7c06  jmp 0x0000708296FD5DD8
0000708296fd7c0b  sub rsp, 0x08
0000708296fd7c0f  push rax
0000708296fd7c10  push rcx
0000708296fd7c11  push rdx
0000708296fd7c12  push rdi
0000708296fd7c13  push rsi
0000708296fd7c14  push r8
0000708296fd7c16  push r9
0000708296fd7c18  push r10
0000708296fd7c1a  push r11
0000708296fd7c1c  sub rsp, 0xF0
0000708296fd7c23  vmovaps [rsp], xmm0
0000708296fd7c28  vmovaps [rsp+0x10], xmm2
0000708296fd7c2e  vmovaps [rsp+0x20], xmm3
0000708296fd7c34  vmovaps [rsp+0x30], xmm4
0000708296fd7c3a  vmovaps [rsp+0x40], xmm5
0000708296fd7c40  vmovaps [rsp+0x50], xmm6
0000708296fd7c46  vmovaps [rsp+0x60], xmm7
0000708296fd7c4c  vmovaps [rsp+0x70], xmm8
0000708296fd7c52  vmovaps [rsp+0x80], xmm9
0000708296fd7c5b  vmovaps [rsp+0x90], xmm10
0000708296fd7c64  vmovaps [rsp+0xA0], xmm11
0000708296fd7c6d  vmovaps [rsp+0xB0], xmm12
0000708296fd7c76  vmovaps [rsp+0xC0], xmm13
0000708296fd7c7f  vmovaps [rsp+0xD0], xmm14
0000708296fd7c88  vmovaps [rsp+0xE0], xmm15
0000708296fd7c91  sub rsp, 0x30
0000708296fd7c95  movaps [rsp], xmm1
0000708296fd7c99  movaps [rsp+0x10], xmm5
0000708296fd7c9e  movaps [rsp+0x20], xmm7
0000708296fd7ca3  lea rdi, [rsp]
0000708296fd7ca7  mov esi, 0x00
0000708296fd7cac  mov rax, 0x64BBC686C530
0000708296fd7cb6  call rax
0000708296fd7cb8  movaps xmm1, [rsp]
0000708296fd7cbc  add rsp, 0x30
0000708296fd7cc0  vmovaps xmm0, [rsp]
0000708296fd7cc5  vmovaps xmm2, [rsp+0x10]
0000708296fd7ccb  vmovaps xmm3, [rsp+0x20]
0000708296fd7cd1  vmovaps xmm4, [rsp+0x30]
0000708296fd7cd7  vmovaps xmm5, [rsp+0x40]
0000708296fd7cdd  vmovaps xmm6, [rsp+0x50]
0000708296fd7ce3  vmovaps xmm7, [rsp+0x60]
0000708296fd7ce9  vmovaps xmm8, [rsp+0x70]
0000708296fd7cef  vmovaps xmm9, [rsp+0x80]
0000708296fd7cf8  vmovaps xmm10, [rsp+0x90]
0000708296fd7d01  vmovaps xmm11, [rsp+0xA0]
0000708296fd7d0a  vmovaps xmm12, [rsp+0xB0]
0000708296fd7d13  vmovaps xmm13, [rsp+0xC0]
0000708296fd7d1c  vmovaps xmm14, [rsp+0xD0]
0000708296fd7d25  vmovaps xmm15, [rsp+0xE0]
0000708296fd7d2e  add rsp, 0xF0
0000708296fd7d35  pop r11
0000708296fd7d37  pop r10
0000708296fd7d39  pop r9
0000708296fd7d3b  pop r8
0000708296fd7d3d  pop rsi
0000708296fd7d3e  pop rdi
0000708296fd7d3f  pop rdx
0000708296fd7d40  pop rcx
0000708296fd7d41  pop rax
0000708296fd7d42  add rsp, 0x08
0000708296fd7d46  jmp 0x0000708296FD5E7D
0000708296fd7d4b  sub rsp, 0x08
0000708296fd7d4f  push rax
0000708296fd7d50  push rcx
0000708296fd7d51  push rdx
0000708296fd7d52  push rdi
0000708296fd7d53  push rsi
0000708296fd7d54  push r8
0000708296fd7d56  push r9
0000708296fd7d58  push r10
0000708296fd7d5a  push r11
0000708296fd7d5c  sub rsp, 0xF0
0000708296fd7d63  vmovaps [rsp], xmm0
0000708296fd7d68  vmovaps [rsp+0x10], xmm1
0000708296fd7d6e  vmovaps [rsp+0x20], xmm2
0000708296fd7d74  vmovaps [rsp+0x30], xmm3
0000708296fd7d7a  vmovaps [rsp+0x40], xmm4
0000708296fd7d80  vmovaps [rsp+0x50], xmm5
0000708296fd7d86  vmovaps [rsp+0x60], xmm6
0000708296fd7d8c  vmovaps [rsp+0x70], xmm8
0000708296fd7d92  vmovaps [rsp+0x80], xmm9
0000708296fd7d9b  vmovaps [rsp+0x90], xmm10
0000708296fd7da4  vmovaps [rsp+0xA0], xmm11
0000708296fd7dad  vmovaps [rsp+0xB0], xmm12
0000708296fd7db6  vmovaps [rsp+0xC0], xmm13
0000708296fd7dbf  vmovaps [rsp+0xD0], xmm14
0000708296fd7dc8  vmovaps [rsp+0xE0], xmm15
0000708296fd7dd1  sub rsp, 0x30
0000708296fd7dd5  movaps [rsp], xmm7
0000708296fd7dd9  movaps [rsp+0x10], xmm5
0000708296fd7dde  movaps [rsp+0x20], xmm15
0000708296fd7de4  lea rdi, [rsp]
0000708296fd7de8  mov esi, 0x00
0000708296fd7ded  mov rax, 0x64BBC686C530
0000708296fd7df7  call rax
0000708296fd7df9  movaps xmm7, [rsp]
0000708296fd7dfd  add rsp, 0x30
0000708296fd7e01  vmovaps xmm0, [rsp]
0000708296fd7e06  vmovaps xmm1, [rsp+0x10]
0000708296fd7e0c  vmovaps xmm2, [rsp+0x20]
0000708296fd7e12  vmovaps xmm3, [rsp+0x30]
0000708296fd7e18  vmovaps xmm4, [rsp+0x40]
0000708296fd7e1e  vmovaps xmm5, [rsp+0x50]
0000708296fd7e24  vmovaps xmm6, [rsp+0x60]
0000708296fd7e2a  vmovaps xmm8, [rsp+0x70]
0000708296fd7e30  vmovaps xmm9, [rsp+0x80]
0000708296fd7e39  vmovaps xmm10, [rsp+0x90]
0000708296fd7e42  vmovaps xmm11, [rsp+0xA0]
0000708296fd7e4b  vmovaps xmm12, [rsp+0xB0]
0000708296fd7e54  vmovaps xmm13, [rsp+0xC0]
0000708296fd7e5d  vmovaps xmm14, [rsp+0xD0]
0000708296fd7e66  vmovaps xmm15, [rsp+0xE0]
0000708296fd7e6f  add rsp, 0xF0
0000708296fd7e76  pop r11
0000708296fd7e78  pop r10
0000708296fd7e7a  pop r9
0000708296fd7e7c  pop r8
0000708296fd7e7e  pop rsi
0000708296fd7e7f  pop rdi
0000708296fd7e80  pop rdx
0000708296fd7e81  pop rcx
0000708296fd7e82  pop rax
0000708296fd7e83  add rsp, 0x08
0000708296fd7e87  jmp 0x0000708296FD5EB3
0000708296fd7e8c  call 0x0000708296ED64F0
0000708296fd7e91  jmp 0x0000708296FD5EC0
0000708296fd7e96  sub rsp, 0x08
0000708296fd7e9a  push rax
0000708296fd7e9b  push rcx
0000708296fd7e9c  push rdx
0000708296fd7e9d  push rdi
0000708296fd7e9e  push rsi
0000708296fd7e9f  push r8
0000708296fd7ea1  push r9
0000708296fd7ea3  push r10
0000708296fd7ea5  push r11
0000708296fd7ea7  sub rsp, 0xF0
0000708296fd7eae  vmovaps [rsp], xmm0
0000708296fd7eb3  vmovaps [rsp+0x10], xmm1
0000708296fd7eb9  vmovaps [rsp+0x20], xmm2
0000708296fd7ebf  vmovaps [rsp+0x30], xmm3
0000708296fd7ec5  vmovaps [rsp+0x40], xmm4
0000708296fd7ecb  vmovaps [rsp+0x50], xmm5
0000708296fd7ed1  vmovaps [rsp+0x60], xmm6
0000708296fd7ed7  vmovaps [rsp+0x70], xmm7
0000708296fd7edd  vmovaps [rsp+0x80], xmm8
0000708296fd7ee6  vmovaps [rsp+0x90], xmm9
0000708296fd7eef  vmovaps [rsp+0xA0], xmm10
0000708296fd7ef8  vmovaps [rsp+0xB0], xmm11
0000708296fd7f01  vmovaps [rsp+0xC0], xmm12
0000708296fd7f0a  vmovaps [rsp+0xD0], xmm13
0000708296fd7f13  vmovaps [rsp+0xE0], xmm14
0000708296fd7f1c  sub rsp, 0x30
0000708296fd7f20  movaps [rsp], xmm15
0000708296fd7f25  movaps [rsp+0x10], xmm5
0000708296fd7f2a  movaps [rsp+0x20], xmm3
0000708296fd7f2f  lea rdi, [rsp]
0000708296fd7f33  mov esi, 0x00
0000708296fd7f38  mov rax, 0x64BBC686C530
0000708296fd7f42  call rax
0000708296fd7f44  movaps xmm15, [rsp]
0000708296fd7f49  add rsp, 0x30
0000708296fd7f4d  vmovaps xmm0, [rsp]
0000708296fd7f52  vmovaps xmm1, [rsp+0x10]
0000708296fd7f58  vmovaps xmm2, [rsp+0x20]
0000708296fd7f5e  vmovaps xmm3, [rsp+0x30]
0000708296fd7f64  vmovaps xmm4, [rsp+0x40]
0000708296fd7f6a  vmovaps xmm5, [rsp+0x50]
0000708296fd7f70  vmovaps xmm6, [rsp+0x60]
0000708296fd7f76  vmovaps xmm7, [rsp+0x70]
0000708296fd7f7c  vmovaps xmm8, [rsp+0x80]
0000708296fd7f85  vmovaps xmm9, [rsp+0x90]
0000708296fd7f8e  vmovaps xmm10, [rsp+0xA0]
0000708296fd7f97  vmovaps xmm11, [rsp+0xB0]
0000708296fd7fa0  vmovaps xmm12, [rsp+0xC0]
0000708296fd7fa9  vmovaps xmm13, [rsp+0xD0]
0000708296fd7fb2  vmovaps xmm14, [rsp+0xE0]
0000708296fd7fbb  add rsp, 0xF0
0000708296fd7fc2  pop r11
0000708296fd7fc4  pop r10
0000708296fd7fc6  pop r9
0000708296fd7fc8  pop r8
0000708296fd7fca  pop rsi
0000708296fd7fcb  pop rdi
0000708296fd7fcc  pop rdx
0000708296fd7fcd  pop rcx
0000708296fd7fce  pop rax
0000708296fd7fcf  add rsp, 0x08
0000708296fd7fd3  jmp 0x0000708296FD5EE6
0000708296fd7fd8  sub rsp, 0x08
0000708296fd7fdc  push rax
0000708296fd7fdd  push rcx
0000708296fd7fde  push rdx
0000708296fd7fdf  push rdi
0000708296fd7fe0  push rsi
0000708296fd7fe1  push r8
0000708296fd7fe3  push r9
0000708296fd7fe5  push r10
0000708296fd7fe7  push r11
0000708296fd7fe9  sub rsp, 0xF0
0000708296fd7ff0  vmovaps [rsp], xmm0
0000708296fd7ff5  vmovaps [rsp+0x10], xmm2
0000708296fd7ffb  vmovaps [rsp+0x20], xmm3
0000708296fd8001  vmovaps [rsp+0x30], xmm4
0000708296fd8007  vmovaps [rsp+0x40], xmm5
0000708296fd800d  vmovaps [rsp+0x50], xmm6
0000708296fd8013  vmovaps [rsp+0x60], xmm7
0000708296fd8019  vmovaps [rsp+0x70], xmm8
0000708296fd801f  vmovaps [rsp+0x80], xmm9
0000708296fd8028  vmovaps [rsp+0x90], xmm10
0000708296fd8031  vmovaps [rsp+0xA0], xmm11
0000708296fd803a  vmovaps [rsp+0xB0], xmm12
0000708296fd8043  vmovaps [rsp+0xC0], xmm13
0000708296fd804c  vmovaps [rsp+0xD0], xmm14
0000708296fd8055  vmovaps [rsp+0xE0], xmm15
0000708296fd805e  sub rsp, 0x30
0000708296fd8062  movaps [rsp], xmm1
0000708296fd8066  movaps [rsp+0x10], xmm5
0000708296fd806b  movaps [rsp+0x20], xmm4
0000708296fd8070  lea rdi, [rsp]
0000708296fd8074  mov esi, 0x00
0000708296fd8079  mov rax, 0x64BBC686C530
0000708296fd8083  call rax
0000708296fd8085  movaps xmm1, [rsp]
0000708296fd8089  add rsp, 0x30
0000708296fd808d  vmovaps xmm0, [rsp]
0000708296fd8092  vmovaps xmm2, [rsp+0x10]
0000708296fd8098  vmovaps xmm3, [rsp+0x20]
0000708296fd809e  vmovaps xmm4, [rsp+0x30]
0000708296fd80a4  vmovaps xmm5, [rsp+0x40]
0000708296fd80aa  vmovaps xmm6, [rsp+0x50]
0000708296fd80b0  vmovaps xmm7, [rsp+0x60]
0000708296fd80b6  vmovaps xmm8, [rsp+0x70]
0000708296fd80bc  vmovaps xmm9, [rsp+0x80]
0000708296fd80c5  vmovaps xmm10, [rsp+0x90]
0000708296fd80ce  vmovaps xmm11, [rsp+0xA0]
0000708296fd80d7  vmovaps xmm12, [rsp+0xB0]
0000708296fd80e0  vmovaps xmm13, [rsp+0xC0]
0000708296fd80e9  vmovaps xmm14, [rsp+0xD0]
0000708296fd80f2  vmovaps xmm15, [rsp+0xE0]
0000708296fd80fb  add rsp, 0xF0
0000708296fd8102  pop r11
0000708296fd8104  pop r10
0000708296fd8106  pop r9
0000708296fd8108  pop r8
0000708296fd810a  pop rsi
0000708296fd810b  pop rdi
0000708296fd810c  pop rdx
0000708296fd810d  pop rcx
0000708296fd810e  pop rax
0000708296fd810f  add rsp, 0x08
0000708296fd8113  jmp 0x0000708296FD5F06
0000708296fd8118  sub rsp, 0x08
0000708296fd811c  push rax
0000708296fd811d  push rcx
0000708296fd811e  push rdx
0000708296fd811f  push rdi
0000708296fd8120  push rsi
0000708296fd8121  push r8
0000708296fd8123  push r9
0000708296fd8125  push r10
0000708296fd8127  push r11
0000708296fd8129  sub rsp, 0xF0
0000708296fd8130  vmovaps [rsp], xmm0
0000708296fd8135  vmovaps [rsp+0x10], xmm1
0000708296fd813b  vmovaps [rsp+0x20], xmm2
0000708296fd8141  vmovaps [rsp+0x30], xmm3
0000708296fd8147  vmovaps [rsp+0x40], xmm5
0000708296fd814d  vmovaps [rsp+0x50], xmm6
0000708296fd8153  vmovaps [rsp+0x60], xmm7
0000708296fd8159  vmovaps [rsp+0x70], xmm8
0000708296fd815f  vmovaps [rsp+0x80], xmm9
0000708296fd8168  vmovaps [rsp+0x90], xmm10
0000708296fd8171  vmovaps [rsp+0xA0], xmm11
0000708296fd817a  vmovaps [rsp+0xB0], xmm12
0000708296fd8183  vmovaps [rsp+0xC0], xmm13
0000708296fd818c  vmovaps [rsp+0xD0], xmm14
0000708296fd8195  vmovaps [rsp+0xE0], xmm15
0000708296fd819e  sub rsp, 0x30
0000708296fd81a2  movaps [rsp], xmm4
0000708296fd81a6  movaps [rsp+0x10], xmm3
0000708296fd81ab  movaps [rsp+0x20], xmm5
0000708296fd81b0  lea rdi, [rsp]
0000708296fd81b4  mov esi, 0x00
0000708296fd81b9  mov rax, 0x64BBC686C530
0000708296fd81c3  call rax
0000708296fd81c5  movaps xmm4, [rsp]
0000708296fd81c9  add rsp, 0x30
0000708296fd81cd  vmovaps xmm0, [rsp]
0000708296fd81d2  vmovaps xmm1, [rsp+0x10]
0000708296fd81d8  vmovaps xmm2, [rsp+0x20]
0000708296fd81de  vmovaps xmm3, [rsp+0x30]
0000708296fd81e4  vmovaps xmm5, [rsp+0x40]
0000708296fd81ea  vmovaps xmm6, [rsp+0x50]
0000708296fd81f0  vmovaps xmm7, [rsp+0x60]
0000708296fd81f6  vmovaps xmm8, [rsp+0x70]
0000708296fd81fc  vmovaps xmm9, [rsp+0x80]
0000708296fd8205  vmovaps xmm10, [rsp+0x90]
0000708296fd820e  vmovaps xmm11, [rsp+0xA0]
0000708296fd8217  vmovaps xmm12, [rsp+0xB0]
0000708296fd8220  vmovaps xmm13, [rsp+0xC0]
0000708296fd8229  vmovaps xmm14, [rsp+0xD0]
0000708296fd8232  vmovaps xmm15, [rsp+0xE0]
0000708296fd823b  add rsp, 0xF0
0000708296fd8242  pop r11
0000708296fd8244  pop r10
0000708296fd8246  pop r9
0000708296fd8248  pop r8
0000708296fd824a  pop rsi
0000708296fd824b  pop rdi
0000708296fd824c  pop rdx
0000708296fd824d  pop rcx
0000708296fd824e  pop rax
0000708296fd824f  add rsp, 0x08
0000708296fd8253  jmp 0x0000708296FD5F54
0000708296fd8258  call 0x0000708296ED64F0
0000708296fd825d  jmp 0x0000708296FD5F61
0000708296fd8262  sub rsp, 0x08
0000708296fd8266  push rax
0000708296fd8267  push rcx
0000708296fd8268  push rdx
0000708296fd8269  push rdi
0000708296fd826a  push rsi
0000708296fd826b  push r8
0000708296fd826d  push r9
0000708296fd826f  push r10
0000708296fd8271  push r11
0000708296fd8273  sub rsp, 0xF0
0000708296fd827a  vmovaps [rsp], xmm0
0000708296fd827f  vmovaps [rsp+0x10], xmm1
0000708296fd8285  vmovaps [rsp+0x20], xmm2
0000708296fd828b  vmovaps [rsp+0x30], xmm3
0000708296fd8291  vmovaps [rsp+0x40], xmm4
0000708296fd8297  vmovaps [rsp+0x50], xmm6
0000708296fd829d  vmovaps [rsp+0x60], xmm7
0000708296fd82a3  vmovaps [rsp+0x70], xmm8
0000708296fd82a9  vmovaps [rsp+0x80], xmm9
0000708296fd82b2  vmovaps [rsp+0x90], xmm10
0000708296fd82bb  vmovaps [rsp+0xA0], xmm11
0000708296fd82c4  vmovaps [rsp+0xB0], xmm12
0000708296fd82cd  vmovaps [rsp+0xC0], xmm13
0000708296fd82d6  vmovaps [rsp+0xD0], xmm14
0000708296fd82df  vmovaps [rsp+0xE0], xmm15
0000708296fd82e8  sub rsp, 0x30
0000708296fd82ec  movaps [rsp], xmm5
0000708296fd82f0  movaps [rsp+0x10], xmm6
0000708296fd82f5  movaps [rsp+0x20], xmm3
0000708296fd82fa  lea rdi, [rsp]
0000708296fd82fe  mov esi, 0x00
0000708296fd8303  mov rax, 0x64BBC686C530
0000708296fd830d  call rax
0000708296fd830f  movaps xmm5, [rsp]
0000708296fd8313  add rsp, 0x30
0000708296fd8317  vmovaps xmm0, [rsp]
0000708296fd831c  vmovaps xmm1, [rsp+0x10]
0000708296fd8322  vmovaps xmm2, [rsp+0x20]
0000708296fd8328  vmovaps xmm3, [rsp+0x30]
0000708296fd832e  vmovaps xmm4, [rsp+0x40]
0000708296fd8334  vmovaps xmm6, [rsp+0x50]
0000708296fd833a  vmovaps xmm7, [rsp+0x60]
0000708296fd8340  vmovaps xmm8, [rsp+0x70]
0000708296fd8346  vmovaps xmm9, [rsp+0x80]
0000708296fd834f  vmovaps xmm10, [rsp+0x90]
0000708296fd8358  vmovaps xmm11, [rsp+0xA0]
0000708296fd8361  vmovaps xmm12, [rsp+0xB0]
0000708296fd836a  vmovaps xmm13, [rsp+0xC0]
0000708296fd8373  vmovaps xmm14, [rsp+0xD0]
0000708296fd837c  vmovaps xmm15, [rsp+0xE0]
0000708296fd8385  add rsp, 0xF0
0000708296fd838c  pop r11
0000708296fd838e  pop r10
0000708296fd8390  pop r9
0000708296fd8392  pop r8
0000708296fd8394  pop rsi
0000708296fd8395  pop rdi
0000708296fd8396  pop rdx
0000708296fd8397  pop rcx
0000708296fd8398  pop rax
0000708296fd8399  add rsp, 0x08
0000708296fd839d  jmp 0x0000708296FD5F87
0000708296fd83a2  sub rsp, 0x08
0000708296fd83a6  push rax
0000708296fd83a7  push rcx
0000708296fd83a8  push rdx
0000708296fd83a9  push rdi
0000708296fd83aa  push rsi
0000708296fd83ab  push r8
0000708296fd83ad  push r9
0000708296fd83af  push r10
0000708296fd83b1  push r11
0000708296fd83b3  sub rsp, 0xF0
0000708296fd83ba  vmovaps [rsp], xmm0
0000708296fd83bf  vmovaps [rsp+0x10], xmm1
0000708296fd83c5  vmovaps [rsp+0x20], xmm2
0000708296fd83cb  vmovaps [rsp+0x30], xmm3
0000708296fd83d1  vmovaps [rsp+0x40], xmm4
0000708296fd83d7  vmovaps [rsp+0x50], xmm5
0000708296fd83dd  vmovaps [rsp+0x60], xmm7
0000708296fd83e3  vmovaps [rsp+0x70], xmm8
0000708296fd83e9  vmovaps [rsp+0x80], xmm9
0000708296fd83f2  vmovaps [rsp+0x90], xmm10
0000708296fd83fb  vmovaps [rsp+0xA0], xmm11
0000708296fd8404  vmovaps [rsp+0xB0], xmm12
0000708296fd840d  vmovaps [rsp+0xC0], xmm13
0000708296fd8416  vmovaps [rsp+0xD0], xmm14
0000708296fd841f  vmovaps [rsp+0xE0], xmm15
0000708296fd8428  sub rsp, 0x30
0000708296fd842c  movaps [rsp], xmm6
0000708296fd8430  movaps [rsp+0x10], xmm9
0000708296fd8436  movaps [rsp+0x20], xmm1
0000708296fd843b  lea rdi, [rsp]
0000708296fd843f  mov esi, 0x00
0000708296fd8444  mov rax, 0x64BBC686C530
0000708296fd844e  call rax
0000708296fd8450  movaps xmm6, [rsp]
0000708296fd8454  add rsp, 0x30
0000708296fd8458  vmovaps xmm0, [rsp]
0000708296fd845d  vmovaps xmm1, [rsp+0x10]
0000708296fd8463  vmovaps xmm2, [rsp+0x20]
0000708296fd8469  vmovaps xmm3, [rsp+0x30]
0000708296fd846f  vmovaps xmm4, [rsp+0x40]
0000708296fd8475  vmovaps xmm5, [rsp+0x50]
0000708296fd847b  vmovaps xmm7, [rsp+0x60]
0000708296fd8481  vmovaps xmm8, [rsp+0x70]
0000708296fd8487  vmovaps xmm9, [rsp+0x80]
0000708296fd8490  vmovaps xmm10, [rsp+0x90]
0000708296fd8499  vmovaps xmm11, [rsp+0xA0]
0000708296fd84a2  vmovaps xmm12, [rsp+0xB0]
0000708296fd84ab  vmovaps xmm13, [rsp+0xC0]
0000708296fd84b4  vmovaps xmm14, [rsp+0xD0]
0000708296fd84bd  vmovaps xmm15, [rsp+0xE0]
0000708296fd84c6  add rsp, 0xF0
0000708296fd84cd  pop r11
0000708296fd84cf  pop r10
0000708296fd84d1  pop r9
0000708296fd84d3  pop r8
0000708296fd84d5  pop rsi
0000708296fd84d6  pop rdi
0000708296fd84d7  pop rdx
0000708296fd84d8  pop rcx
0000708296fd84d9  pop rax
0000708296fd84da  add rsp, 0x08
0000708296fd84de  jmp 0x0000708296FD5FAB
0000708296fd84e3  sub rsp, 0x08
0000708296fd84e7  push rax
0000708296fd84e8  push rcx
0000708296fd84e9  push rdx
0000708296fd84ea  push rdi
0000708296fd84eb  push rsi
0000708296fd84ec  push r8
0000708296fd84ee  push r9
0000708296fd84f0  push r10
0000708296fd84f2  push r11
0000708296fd84f4  sub rsp, 0xF0
0000708296fd84fb  vmovaps [rsp], xmm0
0000708296fd8500  vmovaps [rsp+0x10], xmm1
0000708296fd8506  vmovaps [rsp+0x20], xmm2
0000708296fd850c  vmovaps [rsp+0x30], xmm3
0000708296fd8512  vmovaps [rsp+0x40], xmm4
0000708296fd8518  vmovaps [rsp+0x50], xmm5
0000708296fd851e  vmovaps [rsp+0x60], xmm6
0000708296fd8524  vmovaps [rsp+0x70], xmm7
0000708296fd852a  vmovaps [rsp+0x80], xmm8
0000708296fd8533  vmovaps [rsp+0x90], xmm10
0000708296fd853c  vmovaps [rsp+0xA0], xmm11
0000708296fd8545  vmovaps [rsp+0xB0], xmm12
0000708296fd854e  vmovaps [rsp+0xC0], xmm13
0000708296fd8557  vmovaps [rsp+0xD0], xmm14
0000708296fd8560  vmovaps [rsp+0xE0], xmm15
0000708296fd8569  sub rsp, 0x30
0000708296fd856d  movaps [rsp], xmm9
0000708296fd8572  movaps [rsp+0x10], xmm3
0000708296fd8577  movaps [rsp+0x20], xmm1
0000708296fd857c  lea rdi, [rsp]
0000708296fd8580  mov esi, 0x00
0000708296fd8585  mov rax, 0x64BBC686C530
0000708296fd858f  call rax
0000708296fd8591  movaps xmm9, [rsp]
0000708296fd8596  add rsp, 0x30
0000708296fd859a  vmovaps xmm0, [rsp]
0000708296fd859f  vmovaps xmm1, [rsp+0x10]
0000708296fd85a5  vmovaps xmm2, [rsp+0x20]
0000708296fd85ab  vmovaps xmm3, [rsp+0x30]
0000708296fd85b1  vmovaps xmm4, [rsp+0x40]
0000708296fd85b7  vmovaps xmm5, [rsp+0x50]
0000708296fd85bd  vmovaps xmm6, [rsp+0x60]
0000708296fd85c3  vmovaps xmm7, [rsp+0x70]
0000708296fd85c9  vmovaps xmm8, [rsp+0x80]
0000708296fd85d2  vmovaps xmm10, [rsp+0x90]
0000708296fd85db  vmovaps xmm11, [rsp+0xA0]
0000708296fd85e4  vmovaps xmm12, [rsp+0xB0]
0000708296fd85ed  vmovaps xmm13, [rsp+0xC0]
0000708296fd85f6  vmovaps xmm14, [rsp+0xD0]
0000708296fd85ff  vmovaps xmm15, [rsp+0xE0]
0000708296fd8608  add rsp, 0xF0
0000708296fd860f  pop r11
0000708296fd8611  pop r10
0000708296fd8613  pop r9
0000708296fd8615  pop r8
0000708296fd8617  pop rsi
0000708296fd8618  pop rdi
0000708296fd8619  pop rdx
0000708296fd861a  pop rcx
0000708296fd861b  pop rax
0000708296fd861c  add rsp, 0x08
0000708296fd8620  jmp 0x0000708296FD5FF7
0000708296fd8625  call 0x0000708296ED64F0
0000708296fd862a  jmp 0x0000708296FD6004
0000708296fd862f  sub rsp, 0x08
0000708296fd8633  push rax
0000708296fd8634  push rcx
0000708296fd8635  push rdx
0000708296fd8636  push rdi
0000708296fd8637  push rsi
0000708296fd8638  push r8
0000708296fd863a  push r9
0000708296fd863c  push r10
0000708296fd863e  push r11
0000708296fd8640  sub rsp, 0xF0
0000708296fd8647  vmovaps [rsp], xmm0
0000708296fd864c  vmovaps [rsp+0x10], xmm1
0000708296fd8652  vmovaps [rsp+0x20], xmm2
0000708296fd8658  vmovaps [rsp+0x30], xmm3
0000708296fd865e  vmovaps [rsp+0x40], xmm4
0000708296fd8664  vmovaps [rsp+0x50], xmm5
0000708296fd866a  vmovaps [rsp+0x60], xmm6
0000708296fd8670  vmovaps [rsp+0x70], xmm7
0000708296fd8676  vmovaps [rsp+0x80], xmm8
0000708296fd867f  vmovaps [rsp+0x90], xmm9
0000708296fd8688  vmovaps [rsp+0xA0], xmm10
0000708296fd8691  vmovaps [rsp+0xB0], xmm11
0000708296fd869a  vmovaps [rsp+0xC0], xmm12
0000708296fd86a3  vmovaps [rsp+0xD0], xmm13
0000708296fd86ac  vmovaps [rsp+0xE0], xmm14
0000708296fd86b5  sub rsp, 0x30
0000708296fd86b9  movaps [rsp], xmm15
0000708296fd86be  movaps [rsp+0x10], xmm3
0000708296fd86c3  movaps [rsp+0x20], xmm7
0000708296fd86c8  lea rdi, [rsp]
0000708296fd86cc  mov esi, 0x00
0000708296fd86d1  mov rax, 0x64BBC686C530
0000708296fd86db  call rax
0000708296fd86dd  movaps xmm15, [rsp]
0000708296fd86e2  add rsp, 0x30
0000708296fd86e6  vmovaps xmm0, [rsp]
0000708296fd86eb  vmovaps xmm1, [rsp+0x10]
0000708296fd86f1  vmovaps xmm2, [rsp+0x20]
0000708296fd86f7  vmovaps xmm3, [rsp+0x30]
0000708296fd86fd  vmovaps xmm4, [rsp+0x40]
0000708296fd8703  vmovaps xmm5, [rsp+0x50]
0000708296fd8709  vmovaps xmm6, [rsp+0x60]
0000708296fd870f  vmovaps xmm7, [rsp+0x70]
0000708296fd8715  vmovaps xmm8, [rsp+0x80]
0000708296fd871e  vmovaps xmm9, [rsp+0x90]
0000708296fd8727  vmovaps xmm10, [rsp+0xA0]
0000708296fd8730  vmovaps xmm11, [rsp+0xB0]
0000708296fd8739  vmovaps xmm12, [rsp+0xC0]
0000708296fd8742  vmovaps xmm13, [rsp+0xD0]
0000708296fd874b  vmovaps xmm14, [rsp+0xE0]
0000708296fd8754  add rsp, 0xF0
0000708296fd875b  pop r11
0000708296fd875d  pop r10
0000708296fd875f  pop r9
0000708296fd8761  pop r8
0000708296fd8763  pop rsi
0000708296fd8764  pop rdi
0000708296fd8765  pop rdx
0000708296fd8766  pop rcx
0000708296fd8767  pop rax
0000708296fd8768  add rsp, 0x08
0000708296fd876c  jmp 0x0000708296FD6030
0000708296fd8771  sub rsp, 0x08
0000708296fd8775  push rax
0000708296fd8776  push rcx
0000708296fd8777  push rdx
0000708296fd8778  push rdi
0000708296fd8779  push rsi
0000708296fd877a  push r8
0000708296fd877c  push r9
0000708296fd877e  push r10
0000708296fd8780  push r11
0000708296fd8782  sub rsp, 0xF0
0000708296fd8789  vmovaps [rsp], xmm0
0000708296fd878e  vmovaps [rsp+0x10], xmm1
0000708296fd8794  vmovaps [rsp+0x20], xmm2
0000708296fd879a  vmovaps [rsp+0x30], xmm4
0000708296fd87a0  vmovaps [rsp+0x40], xmm5
0000708296fd87a6  vmovaps [rsp+0x50], xmm6
0000708296fd87ac  vmovaps [rsp+0x60], xmm7
0000708296fd87b2  vmovaps [rsp+0x70], xmm8
0000708296fd87b8  vmovaps [rsp+0x80], xmm9
0000708296fd87c1  vmovaps [rsp+0x90], xmm10
0000708296fd87ca  vmovaps [rsp+0xA0], xmm11
0000708296fd87d3  vmovaps [rsp+0xB0], xmm12
0000708296fd87dc  vmovaps [rsp+0xC0], xmm13
0000708296fd87e5  vmovaps [rsp+0xD0], xmm14
0000708296fd87ee  vmovaps [rsp+0xE0], xmm15
0000708296fd87f7  sub rsp, 0x30
0000708296fd87fb  movaps [rsp], xmm3
0000708296fd87ff  movaps [rsp+0x10], xmm1
0000708296fd8804  movaps [rsp+0x20], xmm15
0000708296fd880a  lea rdi, [rsp]
0000708296fd880e  mov esi, 0x00
0000708296fd8813  mov rax, 0x64BBC686C530
0000708296fd881d  call rax
0000708296fd881f  movaps xmm3, [rsp]
0000708296fd8823  add rsp, 0x30
0000708296fd8827  vmovaps xmm0, [rsp]
0000708296fd882c  vmovaps xmm1, [rsp+0x10]
0000708296fd8832  vmovaps xmm2, [rsp+0x20]
0000708296fd8838  vmovaps xmm4, [rsp+0x30]
0000708296fd883e  vmovaps xmm5, [rsp+0x40]
0000708296fd8844  vmovaps xmm6, [rsp+0x50]
0000708296fd884a  vmovaps xmm7, [rsp+0x60]
0000708296fd8850  vmovaps xmm8, [rsp+0x70]
0000708296fd8856  vmovaps xmm9, [rsp+0x80]
0000708296fd885f  vmovaps xmm10, [rsp+0x90]
0000708296fd8868  vmovaps xmm11, [rsp+0xA0]
0000708296fd8871  vmovaps xmm12, [rsp+0xB0]
0000708296fd887a  vmovaps xmm13, [rsp+0xC0]
0000708296fd8883  vmovaps xmm14, [rsp+0xD0]
0000708296fd888c  vmovaps xmm15, [rsp+0xE0]
0000708296fd8895  add rsp, 0xF0
0000708296fd889c  pop r11
0000708296fd889e  pop r10
0000708296fd88a0  pop r9
0000708296fd88a2  pop r8
0000708296fd88a4  pop rsi
0000708296fd88a5  pop rdi
0000708296fd88a6  pop rdx
0000708296fd88a7  pop rcx
0000708296fd88a8  pop rax
0000708296fd88a9  add rsp, 0x08
0000708296fd88ad  jmp 0x0000708296FD60BF
0000708296fd88b2  call 0x0000708296ED64F0
0000708296fd88b7  jmp 0x0000708296FD60C9
0000708296fd88bc  sub rsp, 0x08
0000708296fd88c0  push rax
0000708296fd88c1  push rcx
0000708296fd88c2  push rdx
0000708296fd88c3  push rdi
0000708296fd88c4  push rsi
0000708296fd88c5  push r8
0000708296fd88c7  push r9
0000708296fd88c9  push r10
0000708296fd88cb  push r11
0000708296fd88cd  sub rsp, 0xF0
0000708296fd88d4  vmovaps [rsp], xmm0
0000708296fd88d9  vmovaps [rsp+0x10], xmm1
0000708296fd88df  vmovaps [rsp+0x20], xmm2
0000708296fd88e5  vmovaps [rsp+0x30], xmm3
0000708296fd88eb  vmovaps [rsp+0x40], xmm4
0000708296fd88f1  vmovaps [rsp+0x50], xmm5
0000708296fd88f7  vmovaps [rsp+0x60], xmm6
0000708296fd88fd  vmovaps [rsp+0x70], xmm7
0000708296fd8903  vmovaps [rsp+0x80], xmm8
0000708296fd890c  vmovaps [rsp+0x90], xmm9
0000708296fd8915  vmovaps [rsp+0xA0], xmm10
0000708296fd891e  vmovaps [rsp+0xB0], xmm11
0000708296fd8927  vmovaps [rsp+0xC0], xmm12
0000708296fd8930  vmovaps [rsp+0xD0], xmm13
0000708296fd8939  vmovaps [rsp+0xE0], xmm14
0000708296fd8942  sub rsp, 0x30
0000708296fd8946  movaps [rsp], xmm15
0000708296fd894b  movaps [rsp+0x10], xmm14
0000708296fd8951  movaps [rsp+0x20], xmm4
0000708296fd8956  lea rdi, [rsp]
0000708296fd895a  mov esi, 0x00
0000708296fd895f  mov rax, 0x64BBC686C530
0000708296fd8969  call rax
0000708296fd896b  movaps xmm15, [rsp]
0000708296fd8970  add rsp, 0x30
0000708296fd8974  vmovaps xmm0, [rsp]
0000708296fd8979  vmovaps xmm1, [rsp+0x10]
0000708296fd897f  vmovaps xmm2, [rsp+0x20]
0000708296fd8985  vmovaps xmm3, [rsp+0x30]
0000708296fd898b  vmovaps xmm4, [rsp+0x40]
0000708296fd8991  vmovaps xmm5, [rsp+0x50]
0000708296fd8997  vmovaps xmm6, [rsp+0x60]
0000708296fd899d  vmovaps xmm7, [rsp+0x70]
0000708296fd89a3  vmovaps xmm8, [rsp+0x80]
0000708296fd89ac  vmovaps xmm9, [rsp+0x90]
0000708296fd89b5  vmovaps xmm10, [rsp+0xA0]
0000708296fd89be  vmovaps xmm11, [rsp+0xB0]
0000708296fd89c7  vmovaps xmm12, [rsp+0xC0]
0000708296fd89d0  vmovaps xmm13, [rsp+0xD0]
0000708296fd89d9  vmovaps xmm14, [rsp+0xE0]
0000708296fd89e2  add rsp, 0xF0
0000708296fd89e9  pop r11
0000708296fd89eb  pop r10
0000708296fd89ed  pop r9
0000708296fd89ef  pop r8
0000708296fd89f1  pop rsi
0000708296fd89f2  pop rdi
0000708296fd89f3  pop rdx
0000708296fd89f4  pop rcx
0000708296fd89f5  pop rax
0000708296fd89f6  add rsp, 0x08
0000708296fd89fa  jmp 0x0000708296FD60F7
0000708296fd89ff  sub rsp, 0x08
0000708296fd8a03  push rax
0000708296fd8a04  push rcx
0000708296fd8a05  push rdx
0000708296fd8a06  push rdi
0000708296fd8a07  push rsi
0000708296fd8a08  push r8
0000708296fd8a0a  push r9
0000708296fd8a0c  push r10
0000708296fd8a0e  push r11
0000708296fd8a10  sub rsp, 0xF0
0000708296fd8a17  vmovaps [rsp], xmm0
0000708296fd8a1c  vmovaps [rsp+0x10], xmm1
0000708296fd8a22  vmovaps [rsp+0x20], xmm2
0000708296fd8a28  vmovaps [rsp+0x30], xmm3
0000708296fd8a2e  vmovaps [rsp+0x40], xmm4
0000708296fd8a34  vmovaps [rsp+0x50], xmm5
0000708296fd8a3a  vmovaps [rsp+0x60], xmm6
0000708296fd8a40  vmovaps [rsp+0x70], xmm7
0000708296fd8a46  vmovaps [rsp+0x80], xmm8
0000708296fd8a4f  vmovaps [rsp+0x90], xmm9
0000708296fd8a58  vmovaps [rsp+0xA0], xmm10
0000708296fd8a61  vmovaps [rsp+0xB0], xmm11
0000708296fd8a6a  vmovaps [rsp+0xC0], xmm12
0000708296fd8a73  vmovaps [rsp+0xD0], xmm13
0000708296fd8a7c  vmovaps [rsp+0xE0], xmm15
0000708296fd8a85  sub rsp, 0x30
0000708296fd8a89  movaps [rsp], xmm14
0000708296fd8a8e  movaps [rsp+0x10], xmm2
0000708296fd8a93  movaps [rsp+0x20], xmm1
0000708296fd8a98  lea rdi, [rsp]
0000708296fd8a9c  mov esi, 0x00
0000708296fd8aa1  mov rax, 0x64BBC686C530
0000708296fd8aab  call rax
0000708296fd8aad  movaps xmm14, [rsp]
0000708296fd8ab2  add rsp, 0x30
0000708296fd8ab6  vmovaps xmm0, [rsp]
0000708296fd8abb  vmovaps xmm1, [rsp+0x10]
0000708296fd8ac1  vmovaps xmm2, [rsp+0x20]
0000708296fd8ac7  vmovaps xmm3, [rsp+0x30]
0000708296fd8acd  vmovaps xmm4, [rsp+0x40]
0000708296fd8ad3  vmovaps xmm5, [rsp+0x50]
0000708296fd8ad9  vmovaps xmm6, [rsp+0x60]
0000708296fd8adf  vmovaps xmm7, [rsp+0x70]
0000708296fd8ae5  vmovaps xmm8, [rsp+0x80]
0000708296fd8aee  vmovaps xmm9, [rsp+0x90]
0000708296fd8af7  vmovaps xmm10, [rsp+0xA0]
0000708296fd8b00  vmovaps xmm11, [rsp+0xB0]
0000708296fd8b09  vmovaps xmm12, [rsp+0xC0]
0000708296fd8b12  vmovaps xmm13, [rsp+0xD0]
0000708296fd8b1b  vmovaps xmm15, [rsp+0xE0]
0000708296fd8b24  add rsp, 0xF0
0000708296fd8b2b  pop r11
0000708296fd8b2d  pop r10
0000708296fd8b2f  pop r9
0000708296fd8b31  pop r8
0000708296fd8b33  pop rsi
0000708296fd8b34  pop rdi
0000708296fd8b35  pop rdx
0000708296fd8b36  pop rcx
0000708296fd8b37  pop rax
0000708296fd8b38  add rsp, 0x08
0000708296fd8b3c  jmp 0x0000708296FD611D
0000708296fd8b41  sub rsp, 0x08
0000708296fd8b45  push rax
0000708296fd8b46  push rcx
0000708296fd8b47  push rdx
0000708296fd8b48  push rdi
0000708296fd8b49  push rsi
0000708296fd8b4a  push r8
0000708296fd8b4c  push r9
0000708296fd8b4e  push r10
0000708296fd8b50  push r11
0000708296fd8b52  sub rsp, 0xF0
0000708296fd8b59  vmovaps [rsp], xmm0
0000708296fd8b5e  vmovaps [rsp+0x10], xmm2
0000708296fd8b64  vmovaps [rsp+0x20], xmm3
0000708296fd8b6a  vmovaps [rsp+0x30], xmm4
0000708296fd8b70  vmovaps [rsp+0x40], xmm5
0000708296fd8b76  vmovaps [rsp+0x50], xmm6
0000708296fd8b7c  vmovaps [rsp+0x60], xmm7
0000708296fd8b82  vmovaps [rsp+0x70], xmm8
0000708296fd8b88  vmovaps [rsp+0x80], xmm9
0000708296fd8b91  vmovaps [rsp+0x90], xmm10
0000708296fd8b9a  vmovaps [rsp+0xA0], xmm11
0000708296fd8ba3  vmovaps [rsp+0xB0], xmm12
0000708296fd8bac  vmovaps [rsp+0xC0], xmm13
0000708296fd8bb5  vmovaps [rsp+0xD0], xmm14
0000708296fd8bbe  vmovaps [rsp+0xE0], xmm15
0000708296fd8bc7  sub rsp, 0x30
0000708296fd8bcb  movaps [rsp], xmm1
0000708296fd8bcf  movaps [rsp+0x10], xmm4
0000708296fd8bd4  movaps [rsp+0x20], xmm9
0000708296fd8bda  lea rdi, [rsp]
0000708296fd8bde  mov esi, 0x00
0000708296fd8be3  mov rax, 0x64BBC686C530
0000708296fd8bed  call rax
0000708296fd8bef  movaps xmm1, [rsp]
0000708296fd8bf3  add rsp, 0x30
0000708296fd8bf7  vmovaps xmm0, [rsp]
0000708296fd8bfc  vmovaps xmm2, [rsp+0x10]
0000708296fd8c02  vmovaps xmm3, [rsp+0x20]
0000708296fd8c08  vmovaps xmm4, [rsp+0x30]
0000708296fd8c0e  vmovaps xmm5, [rsp+0x40]
0000708296fd8c14  vmovaps xmm6, [rsp+0x50]
0000708296fd8c1a  vmovaps xmm7, [rsp+0x60]
0000708296fd8c20  vmovaps xmm8, [rsp+0x70]
0000708296fd8c26  vmovaps xmm9, [rsp+0x80]
0000708296fd8c2f  vmovaps xmm10, [rsp+0x90]
0000708296fd8c38  vmovaps xmm11, [rsp+0xA0]
0000708296fd8c41  vmovaps xmm12, [rsp+0xB0]
0000708296fd8c4a  vmovaps xmm13, [rsp+0xC0]
0000708296fd8c53  vmovaps xmm14, [rsp+0xD0]
0000708296fd8c5c  vmovaps xmm15, [rsp+0xE0]
0000708296fd8c65  add rsp, 0xF0
0000708296fd8c6c  pop r11
0000708296fd8c6e  pop r10
0000708296fd8c70  pop r9
0000708296fd8c72  pop r8
0000708296fd8c74  pop rsi
0000708296fd8c75  pop rdi
0000708296fd8c76  pop rdx
0000708296fd8c77  pop rcx
0000708296fd8c78  pop rax
0000708296fd8c79  add rsp, 0x08
0000708296fd8c7d  jmp 0x0000708296FD613B
0000708296fd8c82  sub rsp, 0x08
0000708296fd8c86  push rax
0000708296fd8c87  push rcx
0000708296fd8c88  push rdx
0000708296fd8c89  push rdi
0000708296fd8c8a  push rsi
0000708296fd8c8b  push r8
0000708296fd8c8d  push r9
0000708296fd8c8f  push r10
0000708296fd8c91  push r11
0000708296fd8c93  sub rsp, 0xF0
0000708296fd8c9a  vmovaps [rsp], xmm0
0000708296fd8c9f  vmovaps [rsp+0x10], xmm1
0000708296fd8ca5  vmovaps [rsp+0x20], xmm2
0000708296fd8cab  vmovaps [rsp+0x30], xmm3
0000708296fd8cb1  vmovaps [rsp+0x40], xmm5
0000708296fd8cb7  vmovaps [rsp+0x50], xmm6
0000708296fd8cbd  vmovaps [rsp+0x60], xmm7
0000708296fd8cc3  vmovaps [rsp+0x70], xmm8
0000708296fd8cc9  vmovaps [rsp+0x80], xmm9
0000708296fd8cd2  vmovaps [rsp+0x90], xmm10
0000708296fd8cdb  vmovaps [rsp+0xA0], xmm11
0000708296fd8ce4  vmovaps [rsp+0xB0], xmm12
0000708296fd8ced  vmovaps [rsp+0xC0], xmm13
0000708296fd8cf6  vmovaps [rsp+0xD0], xmm14
0000708296fd8cff  vmovaps [rsp+0xE0], xmm15
0000708296fd8d08  sub rsp, 0x30
0000708296fd8d0c  movaps [rsp], xmm4
0000708296fd8d10  movaps [rsp+0x10], xmm2
0000708296fd8d15  movaps [rsp+0x20], xmm9
0000708296fd8d1b  lea rdi, [rsp]
0000708296fd8d1f  mov esi, 0x00
0000708296fd8d24  mov rax, 0x64BBC686C530
0000708296fd8d2e  call rax
0000708296fd8d30  movaps xmm4, [rsp]
0000708296fd8d34  add rsp, 0x30
0000708296fd8d38  vmovaps xmm0, [rsp]
0000708296fd8d3d  vmovaps xmm1, [rsp+0x10]
0000708296fd8d43  vmovaps xmm2, [rsp+0x20]
0000708296fd8d49  vmovaps xmm3, [rsp+0x30]
0000708296fd8d4f  vmovaps xmm5, [rsp+0x40]
0000708296fd8d55  vmovaps xmm6, [rsp+0x50]
0000708296fd8d5b  vmovaps xmm7, [rsp+0x60]
0000708296fd8d61  vmovaps xmm8, [rsp+0x70]
0000708296fd8d67  vmovaps xmm9, [rsp+0x80]
0000708296fd8d70  vmovaps xmm10, [rsp+0x90]
0000708296fd8d79  vmovaps xmm11, [rsp+0xA0]
0000708296fd8d82  vmovaps xmm12, [rsp+0xB0]
0000708296fd8d8b  vmovaps xmm13, [rsp+0xC0]
0000708296fd8d94  vmovaps xmm14, [rsp+0xD0]
0000708296fd8d9d  vmovaps xmm15, [rsp+0xE0]
0000708296fd8da6  add rsp, 0xF0
0000708296fd8dad  pop r11
0000708296fd8daf  pop r10
0000708296fd8db1  pop r9
0000708296fd8db3  pop r8
0000708296fd8db5  pop rsi
0000708296fd8db6  pop rdi
0000708296fd8db7  pop rdx
0000708296fd8db8  pop rcx
0000708296fd8db9  pop rax
0000708296fd8dba  add rsp, 0x08
0000708296fd8dbe  jmp 0x0000708296FD616B
0000708296fd8dc3  sub rsp, 0x08
0000708296fd8dc7  push rax
0000708296fd8dc8  push rcx
0000708296fd8dc9  push rdx
0000708296fd8dca  push rdi
0000708296fd8dcb  push rsi
0000708296fd8dcc  push r8
0000708296fd8dce  push r9
0000708296fd8dd0  push r10
0000708296fd8dd2  push r11
0000708296fd8dd4  sub rsp, 0xF0
0000708296fd8ddb  vmovaps [rsp], xmm0
0000708296fd8de0  vmovaps [rsp+0x10], xmm1
0000708296fd8de6  vmovaps [rsp+0x20], xmm2
0000708296fd8dec  vmovaps [rsp+0x30], xmm3
0000708296fd8df2  vmovaps [rsp+0x40], xmm4
0000708296fd8df8  vmovaps [rsp+0x50], xmm5
0000708296fd8dfe  vmovaps [rsp+0x60], xmm6
0000708296fd8e04  vmovaps [rsp+0x70], xmm7
0000708296fd8e0a  vmovaps [rsp+0x80], xmm8
0000708296fd8e13  vmovaps [rsp+0x90], xmm10
0000708296fd8e1c  vmovaps [rsp+0xA0], xmm11
0000708296fd8e25  vmovaps [rsp+0xB0], xmm12
0000708296fd8e2e  vmovaps [rsp+0xC0], xmm13
0000708296fd8e37  vmovaps [rsp+0xD0], xmm14
0000708296fd8e40  vmovaps [rsp+0xE0], xmm15
0000708296fd8e49  sub rsp, 0x30
0000708296fd8e4d  movaps [rsp], xmm9
0000708296fd8e52  movaps [rsp+0x10], xmm2
0000708296fd8e57  movaps [rsp+0x20], xmm1
0000708296fd8e5c  lea rdi, [rsp]
0000708296fd8e60  mov esi, 0x00
0000708296fd8e65  mov rax, 0x64BBC686C530
0000708296fd8e6f  call rax
0000708296fd8e71  movaps xmm9, [rsp]
0000708296fd8e76  add rsp, 0x30
0000708296fd8e7a  vmovaps xmm0, [rsp]
0000708296fd8e7f  vmovaps xmm1, [rsp+0x10]
0000708296fd8e85  vmovaps xmm2, [rsp+0x20]
0000708296fd8e8b  vmovaps xmm3, [rsp+0x30]
0000708296fd8e91  vmovaps xmm4, [rsp+0x40]
0000708296fd8e97  vmovaps xmm5, [rsp+0x50]
0000708296fd8e9d  vmovaps xmm6, [rsp+0x60]
0000708296fd8ea3  vmovaps xmm7, [rsp+0x70]
0000708296fd8ea9  vmovaps xmm8, [rsp+0x80]
0000708296fd8eb2  vmovaps xmm10, [rsp+0x90]
0000708296fd8ebb  vmovaps xmm11, [rsp+0xA0]
0000708296fd8ec4  vmovaps xmm12, [rsp+0xB0]
0000708296fd8ecd  vmovaps xmm13, [rsp+0xC0]
0000708296fd8ed6  vmovaps xmm14, [rsp+0xD0]
0000708296fd8edf  vmovaps xmm15, [rsp+0xE0]
0000708296fd8ee8  add rsp, 0xF0
0000708296fd8eef  pop r11
0000708296fd8ef1  pop r10
0000708296fd8ef3  pop r9
0000708296fd8ef5  pop r8
0000708296fd8ef7  pop rsi
0000708296fd8ef8  pop rdi
0000708296fd8ef9  pop rdx
0000708296fd8efa  pop rcx
0000708296fd8efb  pop rax
0000708296fd8efc  add rsp, 0x08
0000708296fd8f00  jmp 0x0000708296FD61A1
0000708296fd8f05  sub rsp, 0x08
0000708296fd8f09  push rax
0000708296fd8f0a  push rcx
0000708296fd8f0b  push rdx
0000708296fd8f0c  push rdi
0000708296fd8f0d  push rsi
0000708296fd8f0e  push r8
0000708296fd8f10  push r9
0000708296fd8f12  push r10
0000708296fd8f14  push r11
0000708296fd8f16  sub rsp, 0xF0
0000708296fd8f1d  vmovaps [rsp], xmm0
0000708296fd8f22  vmovaps [rsp+0x10], xmm2
0000708296fd8f28  vmovaps [rsp+0x20], xmm3
0000708296fd8f2e  vmovaps [rsp+0x30], xmm4
0000708296fd8f34  vmovaps [rsp+0x40], xmm5
0000708296fd8f3a  vmovaps [rsp+0x50], xmm6
0000708296fd8f40  vmovaps [rsp+0x60], xmm7
0000708296fd8f46  vmovaps [rsp+0x70], xmm8
0000708296fd8f4c  vmovaps [rsp+0x80], xmm9
0000708296fd8f55  vmovaps [rsp+0x90], xmm10
0000708296fd8f5e  vmovaps [rsp+0xA0], xmm11
0000708296fd8f67  vmovaps [rsp+0xB0], xmm12
0000708296fd8f70  vmovaps [rsp+0xC0], xmm13
0000708296fd8f79  vmovaps [rsp+0xD0], xmm14
0000708296fd8f82  vmovaps [rsp+0xE0], xmm15
0000708296fd8f8b  sub rsp, 0x30
0000708296fd8f8f  movaps [rsp], xmm1
0000708296fd8f93  movaps [rsp+0x10], xmm15
0000708296fd8f99  movaps [rsp+0x20], xmm6
0000708296fd8f9e  lea rdi, [rsp]
0000708296fd8fa2  mov esi, 0x00
0000708296fd8fa7  mov rax, 0x64BBC686C530
0000708296fd8fb1  call rax
0000708296fd8fb3  movaps xmm1, [rsp]
0000708296fd8fb7  add rsp, 0x30
0000708296fd8fbb  vmovaps xmm0, [rsp]
0000708296fd8fc0  vmovaps xmm2, [rsp+0x10]
0000708296fd8fc6  vmovaps xmm3, [rsp+0x20]
0000708296fd8fcc  vmovaps xmm4, [rsp+0x30]
0000708296fd8fd2  vmovaps xmm5, [rsp+0x40]
0000708296fd8fd8  vmovaps xmm6, [rsp+0x50]
0000708296fd8fde  vmovaps xmm7, [rsp+0x60]
0000708296fd8fe4  vmovaps xmm8, [rsp+0x70]
0000708296fd8fea  vmovaps xmm9, [rsp+0x80]
0000708296fd8ff3  vmovaps xmm10, [rsp+0x90]
0000708296fd8ffc  vmovaps xmm11, [rsp+0xA0]
0000708296fd9005  vmovaps xmm12, [rsp+0xB0]
0000708296fd900e  vmovaps xmm13, [rsp+0xC0]
0000708296fd9017  vmovaps xmm14, [rsp+0xD0]
0000708296fd9020  vmovaps xmm15, [rsp+0xE0]
0000708296fd9029  add rsp, 0xF0
0000708296fd9030  pop r11
0000708296fd9032  pop r10
0000708296fd9034  pop r9
0000708296fd9036  pop r8
0000708296fd9038  pop rsi
0000708296fd9039  pop rdi
0000708296fd903a  pop rdx
0000708296fd903b  pop rcx
0000708296fd903c  pop rax
0000708296fd903d  add rsp, 0x08
0000708296fd9041  jmp 0x0000708296FD61C2
0000708296fd9046  sub rsp, 0x08
0000708296fd904a  push rax
0000708296fd904b  push rcx
0000708296fd904c  push rdx
0000708296fd904d  push rdi
0000708296fd904e  push rsi
0000708296fd904f  push r8
0000708296fd9051  push r9
0000708296fd9053  push r10
0000708296fd9055  push r11
0000708296fd9057  sub rsp, 0xF0
0000708296fd905e  vmovaps [rsp], xmm0
0000708296fd9063  vmovaps [rsp+0x10], xmm1
0000708296fd9069  vmovaps [rsp+0x20], xmm2
0000708296fd906f  vmovaps [rsp+0x30], xmm3
0000708296fd9075  vmovaps [rsp+0x40], xmm4
0000708296fd907b  vmovaps [rsp+0x50], xmm5
0000708296fd9081  vmovaps [rsp+0x60], xmm6
0000708296fd9087  vmovaps [rsp+0x70], xmm7
0000708296fd908d  vmovaps [rsp+0x80], xmm8
0000708296fd9096  vmovaps [rsp+0x90], xmm9
0000708296fd909f  vmovaps [rsp+0xA0], xmm10
0000708296fd90a8  vmovaps [rsp+0xB0], xmm11
0000708296fd90b1  vmovaps [rsp+0xC0], xmm12
0000708296fd90ba  vmovaps [rsp+0xD0], xmm13
0000708296fd90c3  vmovaps [rsp+0xE0], xmm14
0000708296fd90cc  sub rsp, 0x30
0000708296fd90d0  movaps [rsp], xmm15
0000708296fd90d5  movaps [rsp+0x10], xmm5
0000708296fd90da  movaps [rsp+0x20], xmm3
0000708296fd90df  lea rdi, [rsp]
0000708296fd90e3  mov esi, 0x00
0000708296fd90e8  mov rax, 0x64BBC686C530
0000708296fd90f2  call rax
0000708296fd90f4  movaps xmm15, [rsp]
0000708296fd90f9  add rsp, 0x30
0000708296fd90fd  vmovaps xmm0, [rsp]
0000708296fd9102  vmovaps xmm1, [rsp+0x10]
0000708296fd9108  vmovaps xmm2, [rsp+0x20]
0000708296fd910e  vmovaps xmm3, [rsp+0x30]
0000708296fd9114  vmovaps xmm4, [rsp+0x40]
0000708296fd911a  vmovaps xmm5, [rsp+0x50]
0000708296fd9120  vmovaps xmm6, [rsp+0x60]
0000708296fd9126  vmovaps xmm7, [rsp+0x70]
0000708296fd912c  vmovaps xmm8, [rsp+0x80]
0000708296fd9135  vmovaps xmm9, [rsp+0x90]
0000708296fd913e  vmovaps xmm10, [rsp+0xA0]
0000708296fd9147  vmovaps xmm11, [rsp+0xB0]
0000708296fd9150  vmovaps xmm12, [rsp+0xC0]
0000708296fd9159  vmovaps xmm13, [rsp+0xD0]
0000708296fd9162  vmovaps xmm14, [rsp+0xE0]
0000708296fd916b  add rsp, 0xF0
0000708296fd9172  pop r11
0000708296fd9174  pop r10
0000708296fd9176  pop r9
0000708296fd9178  pop r8
0000708296fd917a  pop rsi
0000708296fd917b  pop rdi
0000708296fd917c  pop rdx
0000708296fd917d  pop rcx
0000708296fd917e  pop rax
0000708296fd917f  add rsp, 0x08
0000708296fd9183  jmp 0x0000708296FD61DC
0000708296fd9188  sub rsp, 0x08
0000708296fd918c  push rax
0000708296fd918d  push rcx
0000708296fd918e  push rdx
0000708296fd918f  push rdi
0000708296fd9190  push rsi
0000708296fd9191  push r8
0000708296fd9193  push r9
0000708296fd9195  push r10
0000708296fd9197  push r11
0000708296fd9199  sub rsp, 0xF0
0000708296fd91a0  vmovaps [rsp], xmm0
0000708296fd91a5  vmovaps [rsp+0x10], xmm1
0000708296fd91ab  vmovaps [rsp+0x20], xmm2
0000708296fd91b1  vmovaps [rsp+0x30], xmm3
0000708296fd91b7  vmovaps [rsp+0x40], xmm4
0000708296fd91bd  vmovaps [rsp+0x50], xmm6
0000708296fd91c3  vmovaps [rsp+0x60], xmm7
0000708296fd91c9  vmovaps [rsp+0x70], xmm8
0000708296fd91cf  vmovaps [rsp+0x80], xmm9
0000708296fd91d8  vmovaps [rsp+0x90], xmm10
0000708296fd91e1  vmovaps [rsp+0xA0], xmm11
0000708296fd91ea  vmovaps [rsp+0xB0], xmm12
0000708296fd91f3  vmovaps [rsp+0xC0], xmm13
0000708296fd91fc  vmovaps [rsp+0xD0], xmm14
0000708296fd9205  vmovaps [rsp+0xE0], xmm15
0000708296fd920e  sub rsp, 0x30
0000708296fd9212  movaps [rsp], xmm5
0000708296fd9216  movaps [rsp+0x10], xmm8
0000708296fd921c  movaps [rsp+0x20], xmm6
0000708296fd9221  lea rdi, [rsp]
0000708296fd9225  mov esi, 0x00
0000708296fd922a  mov rax, 0x64BBC686C530
0000708296fd9234  call rax
0000708296fd9236  movaps xmm5, [rsp]
0000708296fd923a  add rsp, 0x30
0000708296fd923e  vmovaps xmm0, [rsp]
0000708296fd9243  vmovaps xmm1, [rsp+0x10]
0000708296fd9249  vmovaps xmm2, [rsp+0x20]
0000708296fd924f  vmovaps xmm3, [rsp+0x30]
0000708296fd9255  vmovaps xmm4, [rsp+0x40]
0000708296fd925b  vmovaps xmm6, [rsp+0x50]
0000708296fd9261  vmovaps xmm7, [rsp+0x60]
0000708296fd9267  vmovaps xmm8, [rsp+0x70]
0000708296fd926d  vmovaps xmm9, [rsp+0x80]
0000708296fd9276  vmovaps xmm10, [rsp+0x90]
0000708296fd927f  vmovaps xmm11, [rsp+0xA0]
0000708296fd9288  vmovaps xmm12, [rsp+0xB0]
0000708296fd9291  vmovaps xmm13, [rsp+0xC0]
0000708296fd929a  vmovaps xmm14, [rsp+0xD0]
0000708296fd92a3  vmovaps xmm15, [rsp+0xE0]
0000708296fd92ac  add rsp, 0xF0
0000708296fd92b3  pop r11
0000708296fd92b5  pop r10
0000708296fd92b7  pop r9
0000708296fd92b9  pop r8
0000708296fd92bb  pop rsi
0000708296fd92bc  pop rdi
0000708296fd92bd  pop rdx
0000708296fd92be  pop rcx
0000708296fd92bf  pop rax
0000708296fd92c0  add rsp, 0x08
0000708296fd92c4  jmp 0x0000708296FD6200
0000708296fd92c9  sub rsp, 0x08
0000708296fd92cd  push rax
0000708296fd92ce  push rcx
0000708296fd92cf  push rdx
0000708296fd92d0  push rdi
0000708296fd92d1  push rsi
0000708296fd92d2  push r8
0000708296fd92d4  push r9
0000708296fd92d6  push r10
0000708296fd92d8  push r11
0000708296fd92da  sub rsp, 0xF0
0000708296fd92e1  vmovaps [rsp], xmm0
0000708296fd92e6  vmovaps [rsp+0x10], xmm1
0000708296fd92ec  vmovaps [rsp+0x20], xmm2
0000708296fd92f2  vmovaps [rsp+0x30], xmm3
0000708296fd92f8  vmovaps [rsp+0x40], xmm4
0000708296fd92fe  vmovaps [rsp+0x50], xmm5
0000708296fd9304  vmovaps [rsp+0x60], xmm7
0000708296fd930a  vmovaps [rsp+0x70], xmm8
0000708296fd9310  vmovaps [rsp+0x80], xmm9
0000708296fd9319  vmovaps [rsp+0x90], xmm10
0000708296fd9322  vmovaps [rsp+0xA0], xmm11
0000708296fd932b  vmovaps [rsp+0xB0], xmm12
0000708296fd9334  vmovaps [rsp+0xC0], xmm13
0000708296fd933d  vmovaps [rsp+0xD0], xmm14
0000708296fd9346  vmovaps [rsp+0xE0], xmm15
0000708296fd934f  sub rsp, 0x30
0000708296fd9353  movaps [rsp], xmm6
0000708296fd9357  movaps [rsp+0x10], xmm10
0000708296fd935d  movaps [rsp+0x20], xmm8
0000708296fd9363  lea rdi, [rsp]
0000708296fd9367  mov esi, 0x00
0000708296fd936c  mov rax, 0x64BBC686C530
0000708296fd9376  call rax
0000708296fd9378  movaps xmm6, [rsp]
0000708296fd937c  add rsp, 0x30
0000708296fd9380  vmovaps xmm0, [rsp]
0000708296fd9385  vmovaps xmm1, [rsp+0x10]
0000708296fd938b  vmovaps xmm2, [rsp+0x20]
0000708296fd9391  vmovaps xmm3, [rsp+0x30]
0000708296fd9397  vmovaps xmm4, [rsp+0x40]
0000708296fd939d  vmovaps xmm5, [rsp+0x50]
0000708296fd93a3  vmovaps xmm7, [rsp+0x60]
0000708296fd93a9  vmovaps xmm8, [rsp+0x70]
0000708296fd93af  vmovaps xmm9, [rsp+0x80]
0000708296fd93b8  vmovaps xmm10, [rsp+0x90]
0000708296fd93c1  vmovaps xmm11, [rsp+0xA0]
0000708296fd93ca  vmovaps xmm12, [rsp+0xB0]
0000708296fd93d3  vmovaps xmm13, [rsp+0xC0]
0000708296fd93dc  vmovaps xmm14, [rsp+0xD0]
0000708296fd93e5  vmovaps xmm15, [rsp+0xE0]
0000708296fd93ee  add rsp, 0xF0
0000708296fd93f5  pop r11
0000708296fd93f7  pop r10
0000708296fd93f9  pop r9
0000708296fd93fb  pop r8
0000708296fd93fd  pop rsi
0000708296fd93fe  pop rdi
0000708296fd93ff  pop rdx
0000708296fd9400  pop rcx
0000708296fd9401  pop rax
0000708296fd9402  add rsp, 0x08
0000708296fd9406  jmp 0x0000708296FD6225
0000708296fd940b  sub rsp, 0x08
0000708296fd940f  push rax
0000708296fd9410  push rcx
0000708296fd9411  push rdx
0000708296fd9412  push rdi
0000708296fd9413  push rsi
0000708296fd9414  push r8
0000708296fd9416  push r9
0000708296fd9418  push r10
0000708296fd941a  push r11
0000708296fd941c  sub rsp, 0xF0
0000708296fd9423  vmovaps [rsp], xmm0
0000708296fd9428  vmovaps [rsp+0x10], xmm1
0000708296fd942e  vmovaps [rsp+0x20], xmm2
0000708296fd9434  vmovaps [rsp+0x30], xmm3
0000708296fd943a  vmovaps [rsp+0x40], xmm4
0000708296fd9440  vmovaps [rsp+0x50], xmm5
0000708296fd9446  vmovaps [rsp+0x60], xmm6
0000708296fd944c  vmovaps [rsp+0x70], xmm7
0000708296fd9452  vmovaps [rsp+0x80], xmm8
0000708296fd945b  vmovaps [rsp+0x90], xmm9
0000708296fd9464  vmovaps [rsp+0xA0], xmm11
0000708296fd946d  vmovaps [rsp+0xB0], xmm12
0000708296fd9476  vmovaps [rsp+0xC0], xmm13
0000708296fd947f  vmovaps [rsp+0xD0], xmm14
0000708296fd9488  vmovaps [rsp+0xE0], xmm15
0000708296fd9491  sub rsp, 0x30
0000708296fd9495  movaps [rsp], xmm10
0000708296fd949a  movaps [rsp+0x10], xmm8
0000708296fd94a0  movaps [rsp+0x20], xmm14
0000708296fd94a6  lea rdi, [rsp]
0000708296fd94aa  mov esi, 0x00
0000708296fd94af  mov rax, 0x64BBC686C530
0000708296fd94b9  call rax
0000708296fd94bb  movaps xmm10, [rsp]
0000708296fd94c0  add rsp, 0x30
0000708296fd94c4  vmovaps xmm0, [rsp]
0000708296fd94c9  vmovaps xmm1, [rsp+0x10]
0000708296fd94cf  vmovaps xmm2, [rsp+0x20]
0000708296fd94d5  vmovaps xmm3, [rsp+0x30]
0000708296fd94db  vmovaps xmm4, [rsp+0x40]
0000708296fd94e1  vmovaps xmm5, [rsp+0x50]
0000708296fd94e7  vmovaps xmm6, [rsp+0x60]
0000708296fd94ed  vmovaps xmm7, [rsp+0x70]
0000708296fd94f3  vmovaps xmm8, [rsp+0x80]
0000708296fd94fc  vmovaps xmm9, [rsp+0x90]
0000708296fd9505  vmovaps xmm11, [rsp+0xA0]
0000708296fd950e  vmovaps xmm12, [rsp+0xB0]
0000708296fd9517  vmovaps xmm13, [rsp+0xC0]
0000708296fd9520  vmovaps xmm14, [rsp+0xD0]
0000708296fd9529  vmovaps xmm15, [rsp+0xE0]
0000708296fd9532  add rsp, 0xF0
0000708296fd9539  pop r11
0000708296fd953b  pop r10
0000708296fd953d  pop r9
0000708296fd953f  pop r8
0000708296fd9541  pop rsi
0000708296fd9542  pop rdi
0000708296fd9543  pop rdx
0000708296fd9544  pop rcx
0000708296fd9545  pop rax
0000708296fd9546  add rsp, 0x08
0000708296fd954a  jmp 0x0000708296FD6245
0000708296fd954f  sub rsp, 0x08
0000708296fd9553  push rax
0000708296fd9554  push rcx
0000708296fd9555  push rdx
0000708296fd9556  push rdi
0000708296fd9557  push rsi
0000708296fd9558  push r8
0000708296fd955a  push r9
0000708296fd955c  push r10
0000708296fd955e  push r11
0000708296fd9560  sub rsp, 0xF0
0000708296fd9567  vmovaps [rsp], xmm0
0000708296fd956c  vmovaps [rsp+0x10], xmm1
0000708296fd9572  vmovaps [rsp+0x20], xmm2
0000708296fd9578  vmovaps [rsp+0x30], xmm3
0000708296fd957e  vmovaps [rsp+0x40], xmm4
0000708296fd9584  vmovaps [rsp+0x50], xmm5
0000708296fd958a  vmovaps [rsp+0x60], xmm6
0000708296fd9590  vmovaps [rsp+0x70], xmm7
0000708296fd9596  vmovaps [rsp+0x80], xmm8
0000708296fd959f  vmovaps [rsp+0x90], xmm9
0000708296fd95a8  vmovaps [rsp+0xA0], xmm10
0000708296fd95b1  vmovaps [rsp+0xB0], xmm11
0000708296fd95ba  vmovaps [rsp+0xC0], xmm12
0000708296fd95c3  vmovaps [rsp+0xD0], xmm13
0000708296fd95cc  vmovaps [rsp+0xE0], xmm15
0000708296fd95d5  sub rsp, 0x30
0000708296fd95d9  movaps [rsp], xmm14
0000708296fd95de  movaps [rsp+0x10], xmm8
0000708296fd95e4  movaps [rsp+0x20], xmm4
0000708296fd95e9  lea rdi, [rsp]
0000708296fd95ed  mov esi, 0x00
0000708296fd95f2  mov rax, 0x64BBC686C530
0000708296fd95fc  call rax
0000708296fd95fe  movaps xmm14, [rsp]
0000708296fd9603  add rsp, 0x30
0000708296fd9607  vmovaps xmm0, [rsp]
0000708296fd960c  vmovaps xmm1, [rsp+0x10]
0000708296fd9612  vmovaps xmm2, [rsp+0x20]
0000708296fd9618  vmovaps xmm3, [rsp+0x30]
0000708296fd961e  vmovaps xmm4, [rsp+0x40]
0000708296fd9624  vmovaps xmm5, [rsp+0x50]
0000708296fd962a  vmovaps xmm6, [rsp+0x60]
0000708296fd9630  vmovaps xmm7, [rsp+0x70]
0000708296fd9636  vmovaps xmm8, [rsp+0x80]
0000708296fd963f  vmovaps xmm9, [rsp+0x90]
0000708296fd9648  vmovaps xmm10, [rsp+0xA0]
0000708296fd9651  vmovaps xmm11, [rsp+0xB0]
0000708296fd965a  vmovaps xmm12, [rsp+0xC0]
0000708296fd9663  vmovaps xmm13, [rsp+0xD0]
0000708296fd966c  vmovaps xmm15, [rsp+0xE0]
0000708296fd9675  add rsp, 0xF0
0000708296fd967c  pop r11
0000708296fd967e  pop r10
0000708296fd9680  pop r9
0000708296fd9682  pop r8
0000708296fd9684  pop rsi
0000708296fd9685  pop rdi
0000708296fd9686  pop rdx
0000708296fd9687  pop rcx
0000708296fd9688  pop rax
0000708296fd9689  add rsp, 0x08
0000708296fd968d  jmp 0x0000708296FD6265
0000708296fd9692  sub rsp, 0x08
0000708296fd9696  push rax
0000708296fd9697  push rcx
0000708296fd9698  push rdx
0000708296fd9699  push rdi
0000708296fd969a  push rsi
0000708296fd969b  push r8
0000708296fd969d  push r9
0000708296fd969f  push r10
0000708296fd96a1  push r11
0000708296fd96a3  sub rsp, 0xF0
0000708296fd96aa  vmovaps [rsp], xmm0
0000708296fd96af  vmovaps [rsp+0x10], xmm1
0000708296fd96b5  vmovaps [rsp+0x20], xmm2
0000708296fd96bb  vmovaps [rsp+0x30], xmm3
0000708296fd96c1  vmovaps [rsp+0x40], xmm5
0000708296fd96c7  vmovaps [rsp+0x50], xmm6
0000708296fd96cd  vmovaps [rsp+0x60], xmm7
0000708296fd96d3  vmovaps [rsp+0x70], xmm8
0000708296fd96d9  vmovaps [rsp+0x80], xmm9
0000708296fd96e2  vmovaps [rsp+0x90], xmm10
0000708296fd96eb  vmovaps [rsp+0xA0], xmm11
0000708296fd96f4  vmovaps [rsp+0xB0], xmm12
0000708296fd96fd  vmovaps [rsp+0xC0], xmm13
0000708296fd9706  vmovaps [rsp+0xD0], xmm14
0000708296fd970f  vmovaps [rsp+0xE0], xmm15
0000708296fd9718  sub rsp, 0x30
0000708296fd971c  movaps [rsp], xmm4
0000708296fd9720  movaps [rsp+0x10], xmm13
0000708296fd9726  movaps [rsp+0x20], xmm8
0000708296fd972c  lea rdi, [rsp]
0000708296fd9730  mov esi, 0x00
0000708296fd9735  mov rax, 0x64BBC686C530
0000708296fd973f  call rax
0000708296fd9741  movaps xmm4, [rsp]
0000708296fd9745  add rsp, 0x30
0000708296fd9749  vmovaps xmm0, [rsp]
0000708296fd974e  vmovaps xmm1, [rsp+0x10]
0000708296fd9754  vmovaps xmm2, [rsp+0x20]
0000708296fd975a  vmovaps xmm3, [rsp+0x30]
0000708296fd9760  vmovaps xmm5, [rsp+0x40]
0000708296fd9766  vmovaps xmm6, [rsp+0x50]
0000708296fd976c  vmovaps xmm7, [rsp+0x60]
0000708296fd9772  vmovaps xmm8, [rsp+0x70]
0000708296fd9778  vmovaps xmm9, [rsp+0x80]
0000708296fd9781  vmovaps xmm10, [rsp+0x90]
0000708296fd978a  vmovaps xmm11, [rsp+0xA0]
0000708296fd9793  vmovaps xmm12, [rsp+0xB0]
0000708296fd979c  vmovaps xmm13, [rsp+0xC0]
0000708296fd97a5  vmovaps xmm14, [rsp+0xD0]
0000708296fd97ae  vmovaps xmm15, [rsp+0xE0]
0000708296fd97b7  add rsp, 0xF0
0000708296fd97be  pop r11
0000708296fd97c0  pop r10
0000708296fd97c2  pop r9
0000708296fd97c4  pop r8
0000708296fd97c6  pop rsi
0000708296fd97c7  pop rdi
0000708296fd97c8  pop rdx
0000708296fd97c9  pop rcx
0000708296fd97ca  pop rax
0000708296fd97cb  add rsp, 0x08
0000708296fd97cf  jmp 0x0000708296FD628A
0000708296fd97d4  sub rsp, 0x08
0000708296fd97d8  push rax
0000708296fd97d9  push rcx
0000708296fd97da  push rdx
0000708296fd97db  push rdi
0000708296fd97dc  push rsi
0000708296fd97dd  push r8
0000708296fd97df  push r9
0000708296fd97e1  push r10
0000708296fd97e3  push r11
0000708296fd97e5  sub rsp, 0xF0
0000708296fd97ec  vmovaps [rsp], xmm0
0000708296fd97f1  vmovaps [rsp+0x10], xmm1
0000708296fd97f7  vmovaps [rsp+0x20], xmm2
0000708296fd97fd  vmovaps [rsp+0x30], xmm3
0000708296fd9803  vmovaps [rsp+0x40], xmm4
0000708296fd9809  vmovaps [rsp+0x50], xmm5
0000708296fd980f  vmovaps [rsp+0x60], xmm6
0000708296fd9815  vmovaps [rsp+0x70], xmm7
0000708296fd981b  vmovaps [rsp+0x80], xmm8
0000708296fd9824  vmovaps [rsp+0x90], xmm9
0000708296fd982d  vmovaps [rsp+0xA0], xmm10
0000708296fd9836  vmovaps [rsp+0xB0], xmm11
0000708296fd983f  vmovaps [rsp+0xC0], xmm12
0000708296fd9848  vmovaps [rsp+0xD0], xmm14
0000708296fd9851  vmovaps [rsp+0xE0], xmm15
0000708296fd985a  sub rsp, 0x30
0000708296fd985e  movaps [rsp], xmm13
0000708296fd9863  movaps [rsp+0x10], xmm15
0000708296fd9869  movaps [rsp+0x20], xmm9
0000708296fd986f  lea rdi, [rsp]
0000708296fd9873  mov esi, 0x00
0000708296fd9878  mov rax, 0x64BBC686C530
0000708296fd9882  call rax
0000708296fd9884  movaps xmm13, [rsp]
0000708296fd9889  add rsp, 0x30
0000708296fd988d  vmovaps xmm0, [rsp]
0000708296fd9892  vmovaps xmm1, [rsp+0x10]
0000708296fd9898  vmovaps xmm2, [rsp+0x20]
0000708296fd989e  vmovaps xmm3, [rsp+0x30]
0000708296fd98a4  vmovaps xmm4, [rsp+0x40]
0000708296fd98aa  vmovaps xmm5, [rsp+0x50]
0000708296fd98b0  vmovaps xmm6, [rsp+0x60]
0000708296fd98b6  vmovaps xmm7, [rsp+0x70]
0000708296fd98bc  vmovaps xmm8, [rsp+0x80]
0000708296fd98c5  vmovaps xmm9, [rsp+0x90]
0000708296fd98ce  vmovaps xmm10, [rsp+0xA0]
0000708296fd98d7  vmovaps xmm11, [rsp+0xB0]
0000708296fd98e0  vmovaps xmm12, [rsp+0xC0]
0000708296fd98e9  vmovaps xmm14, [rsp+0xD0]
0000708296fd98f2  vmovaps xmm15, [rsp+0xE0]
0000708296fd98fb  add rsp, 0xF0
0000708296fd9902  pop r11
0000708296fd9904  pop r10
0000708296fd9906  pop r9
0000708296fd9908  pop r8
0000708296fd990a  pop rsi
0000708296fd990b  pop rdi
0000708296fd990c  pop rdx
0000708296fd990d  pop rcx
0000708296fd990e  pop rax
0000708296fd990f  add rsp, 0x08
0000708296fd9913  jmp 0x0000708296FD62A5
0000708296fd9918  sub rsp, 0x08
0000708296fd991c  push rax
0000708296fd991d  push rcx
0000708296fd991e  push rdx
0000708296fd991f  push rdi
0000708296fd9920  push rsi
0000708296fd9921  push r8
0000708296fd9923  push r9
0000708296fd9925  push r10
0000708296fd9927  push r11
0000708296fd9929  sub rsp, 0xF0
0000708296fd9930  vmovaps [rsp], xmm0
0000708296fd9935  vmovaps [rsp+0x10], xmm1
0000708296fd993b  vmovaps [rsp+0x20], xmm2
0000708296fd9941  vmovaps [rsp+0x30], xmm3
0000708296fd9947  vmovaps [rsp+0x40], xmm4
0000708296fd994d  vmovaps [rsp+0x50], xmm5
0000708296fd9953  vmovaps [rsp+0x60], xmm6
0000708296fd9959  vmovaps [rsp+0x70], xmm7
0000708296fd995f  vmovaps [rsp+0x80], xmm8
0000708296fd9968  vmovaps [rsp+0x90], xmm9
0000708296fd9971  vmovaps [rsp+0xA0], xmm10
0000708296fd997a  vmovaps [rsp+0xB0], xmm11
0000708296fd9983  vmovaps [rsp+0xC0], xmm12
0000708296fd998c  vmovaps [rsp+0xD0], xmm13
0000708296fd9995  vmovaps [rsp+0xE0], xmm14
0000708296fd999e  sub rsp, 0x30
0000708296fd99a2  movaps [rsp], xmm15
0000708296fd99a7  movaps [rsp+0x10], xmm1
0000708296fd99ac  movaps [rsp+0x20], xmm5
0000708296fd99b1  lea rdi, [rsp]
0000708296fd99b5  mov esi, 0x00
0000708296fd99ba  mov rax, 0x64BBC686C530
0000708296fd99c4  call rax
0000708296fd99c6  movaps xmm15, [rsp]
0000708296fd99cb  add rsp, 0x30
0000708296fd99cf  vmovaps xmm0, [rsp]
0000708296fd99d4  vmovaps xmm1, [rsp+0x10]
0000708296fd99da  vmovaps xmm2, [rsp+0x20]
0000708296fd99e0  vmovaps xmm3, [rsp+0x30]
0000708296fd99e6  vmovaps xmm4, [rsp+0x40]
0000708296fd99ec  vmovaps xmm5, [rsp+0x50]
0000708296fd99f2  vmovaps xmm6, [rsp+0x60]
0000708296fd99f8  vmovaps xmm7, [rsp+0x70]
0000708296fd99fe  vmovaps xmm8, [rsp+0x80]
0000708296fd9a07  vmovaps xmm9, [rsp+0x90]
0000708296fd9a10  vmovaps xmm10, [rsp+0xA0]
0000708296fd9a19  vmovaps xmm11, [rsp+0xB0]
0000708296fd9a22  vmovaps xmm12, [rsp+0xC0]
0000708296fd9a2b  vmovaps xmm13, [rsp+0xD0]
0000708296fd9a34  vmovaps xmm14, [rsp+0xE0]
0000708296fd9a3d  add rsp, 0xF0
0000708296fd9a44  pop r11
0000708296fd9a46  pop r10
0000708296fd9a48  pop r9
0000708296fd9a4a  pop r8
0000708296fd9a4c  pop rsi
0000708296fd9a4d  pop rdi
0000708296fd9a4e  pop rdx
0000708296fd9a4f  pop rcx
0000708296fd9a50  pop rax
0000708296fd9a51  add rsp, 0x08
0000708296fd9a55  jmp 0x0000708296FD62C0
0000708296fd9a5a  call 0x0000708296ED64F0
0000708296fd9a5f  jmp 0x0000708296FD631B
0000708296fd9a64  sub rsp, 0x08
0000708296fd9a68  push rax
0000708296fd9a69  push rcx
0000708296fd9a6a  push rdx
0000708296fd9a6b  push rdi
0000708296fd9a6c  push rsi
0000708296fd9a6d  push r8
0000708296fd9a6f  push r9
0000708296fd9a71  push r10
0000708296fd9a73  push r11
0000708296fd9a75  sub rsp, 0xF0
0000708296fd9a7c  vmovaps [rsp], xmm0
0000708296fd9a81  vmovaps [rsp+0x10], xmm1
0000708296fd9a87  vmovaps [rsp+0x20], xmm2
0000708296fd9a8d  vmovaps [rsp+0x30], xmm3
0000708296fd9a93  vmovaps [rsp+0x40], xmm4
0000708296fd9a99  vmovaps [rsp+0x50], xmm5
0000708296fd9a9f  vmovaps [rsp+0x60], xmm6
0000708296fd9aa5  vmovaps [rsp+0x70], xmm7
0000708296fd9aab  vmovaps [rsp+0x80], xmm8
0000708296fd9ab4  vmovaps [rsp+0x90], xmm10
0000708296fd9abd  vmovaps [rsp+0xA0], xmm11
0000708296fd9ac6  vmovaps [rsp+0xB0], xmm12
0000708296fd9acf  vmovaps [rsp+0xC0], xmm13
0000708296fd9ad8  vmovaps [rsp+0xD0], xmm14
0000708296fd9ae1  vmovaps [rsp+0xE0], xmm15
0000708296fd9aea  sub rsp, 0x30
0000708296fd9aee  movaps [rsp], xmm9
0000708296fd9af3  movaps [rsp+0x10], xmm8
0000708296fd9af9  movaps [rsp+0x20], xmm11
0000708296fd9aff  lea rdi, [rsp]
0000708296fd9b03  mov esi, 0x00
0000708296fd9b08  mov rax, 0x64BBC686C530
0000708296fd9b12  call rax
0000708296fd9b14  movaps xmm9, [rsp]
0000708296fd9b19  add rsp, 0x30
0000708296fd9b1d  vmovaps xmm0, [rsp]
0000708296fd9b22  vmovaps xmm1, [rsp+0x10]
0000708296fd9b28  vmovaps xmm2, [rsp+0x20]
0000708296fd9b2e  vmovaps xmm3, [rsp+0x30]
0000708296fd9b34  vmovaps xmm4, [rsp+0x40]
0000708296fd9b3a  vmovaps xmm5, [rsp+0x50]
0000708296fd9b40  vmovaps xmm6, [rsp+0x60]
0000708296fd9b46  vmovaps xmm7, [rsp+0x70]
0000708296fd9b4c  vmovaps xmm8, [rsp+0x80]
0000708296fd9b55  vmovaps xmm10, [rsp+0x90]
0000708296fd9b5e  vmovaps xmm11, [rsp+0xA0]
0000708296fd9b67  vmovaps xmm12, [rsp+0xB0]
0000708296fd9b70  vmovaps xmm13, [rsp+0xC0]
0000708296fd9b79  vmovaps xmm14, [rsp+0xD0]
0000708296fd9b82  vmovaps xmm15, [rsp+0xE0]
0000708296fd9b8b  add rsp, 0xF0
0000708296fd9b92  pop r11
0000708296fd9b94  pop r10
0000708296fd9b96  pop r9
0000708296fd9b98  pop r8
0000708296fd9b9a  pop rsi
0000708296fd9b9b  pop rdi
0000708296fd9b9c  pop rdx
0000708296fd9b9d  pop rcx
0000708296fd9b9e  pop rax
0000708296fd9b9f  add rsp, 0x08
0000708296fd9ba3  jmp 0x0000708296FD6352
0000708296fd9ba8  sub rsp, 0x08
0000708296fd9bac  push rax
0000708296fd9bad  push rcx
0000708296fd9bae  push rdx
0000708296fd9baf  push rdi
0000708296fd9bb0  push rsi
0000708296fd9bb1  push r8
0000708296fd9bb3  push r9
0000708296fd9bb5  push r10
0000708296fd9bb7  push r11
0000708296fd9bb9  sub rsp, 0xF0
0000708296fd9bc0  vmovaps [rsp], xmm0
0000708296fd9bc5  vmovaps [rsp+0x10], xmm1
0000708296fd9bcb  vmovaps [rsp+0x20], xmm2
0000708296fd9bd1  vmovaps [rsp+0x30], xmm3
0000708296fd9bd7  vmovaps [rsp+0x40], xmm4
0000708296fd9bdd  vmovaps [rsp+0x50], xmm5
0000708296fd9be3  vmovaps [rsp+0x60], xmm6
0000708296fd9be9  vmovaps [rsp+0x70], xmm7
0000708296fd9bef  vmovaps [rsp+0x80], xmm8
0000708296fd9bf8  vmovaps [rsp+0x90], xmm9
0000708296fd9c01  vmovaps [rsp+0xA0], xmm10
0000708296fd9c0a  vmovaps [rsp+0xB0], xmm12
0000708296fd9c13  vmovaps [rsp+0xC0], xmm13
0000708296fd9c1c  vmovaps [rsp+0xD0], xmm14
0000708296fd9c25  vmovaps [rsp+0xE0], xmm15
0000708296fd9c2e  sub rsp, 0x30
0000708296fd9c32  movaps [rsp], xmm11
0000708296fd9c37  movaps [rsp+0x10], xmm10
0000708296fd9c3d  movaps [rsp+0x20], xmm6
0000708296fd9c42  lea rdi, [rsp]
0000708296fd9c46  mov esi, 0x00
0000708296fd9c4b  mov rax, 0x64BBC686C530
0000708296fd9c55  call rax
0000708296fd9c57  movaps xmm11, [rsp]
0000708296fd9c5c  add rsp, 0x30
0000708296fd9c60  vmovaps xmm0, [rsp]
0000708296fd9c65  vmovaps xmm1, [rsp+0x10]
0000708296fd9c6b  vmovaps xmm2, [rsp+0x20]
0000708296fd9c71  vmovaps xmm3, [rsp+0x30]
0000708296fd9c77  vmovaps xmm4, [rsp+0x40]
0000708296fd9c7d  vmovaps xmm5, [rsp+0x50]
0000708296fd9c83  vmovaps xmm6, [rsp+0x60]
0000708296fd9c89  vmovaps xmm7, [rsp+0x70]
0000708296fd9c8f  vmovaps xmm8, [rsp+0x80]
0000708296fd9c98  vmovaps xmm9, [rsp+0x90]
0000708296fd9ca1  vmovaps xmm10, [rsp+0xA0]
0000708296fd9caa  vmovaps xmm12, [rsp+0xB0]
0000708296fd9cb3  vmovaps xmm13, [rsp+0xC0]
0000708296fd9cbc  vmovaps xmm14, [rsp+0xD0]
0000708296fd9cc5  vmovaps xmm15, [rsp+0xE0]
0000708296fd9cce  add rsp, 0xF0
0000708296fd9cd5  pop r11
0000708296fd9cd7  pop r10
0000708296fd9cd9  pop r9
0000708296fd9cdb  pop r8
0000708296fd9cdd  pop rsi
0000708296fd9cde  pop rdi
0000708296fd9cdf  pop rdx
0000708296fd9ce0  pop rcx
0000708296fd9ce1  pop rax
0000708296fd9ce2  add rsp, 0x08
0000708296fd9ce6  jmp 0x0000708296FD636D
0000708296fd9ceb  sub rsp, 0x08
0000708296fd9cef  push rax
0000708296fd9cf0  push rcx
0000708296fd9cf1  push rdx
0000708296fd9cf2  push rdi
0000708296fd9cf3  push rsi
0000708296fd9cf4  push r8
0000708296fd9cf6  push r9
0000708296fd9cf8  push r10
0000708296fd9cfa  push r11
0000708296fd9cfc  sub rsp, 0xF0
0000708296fd9d03  vmovaps [rsp], xmm0
0000708296fd9d08  vmovaps [rsp+0x10], xmm1
0000708296fd9d0e  vmovaps [rsp+0x20], xmm2
0000708296fd9d14  vmovaps [rsp+0x30], xmm3
0000708296fd9d1a  vmovaps [rsp+0x40], xmm4
0000708296fd9d20  vmovaps [rsp+0x50], xmm5
0000708296fd9d26  vmovaps [rsp+0x60], xmm6
0000708296fd9d2c  vmovaps [rsp+0x70], xmm7
0000708296fd9d32  vmovaps [rsp+0x80], xmm8
0000708296fd9d3b  vmovaps [rsp+0x90], xmm9
0000708296fd9d44  vmovaps [rsp+0xA0], xmm11
0000708296fd9d4d  vmovaps [rsp+0xB0], xmm12
0000708296fd9d56  vmovaps [rsp+0xC0], xmm13
0000708296fd9d5f  vmovaps [rsp+0xD0], xmm14
0000708296fd9d68  vmovaps [rsp+0xE0], xmm15
0000708296fd9d71  sub rsp, 0x30
0000708296fd9d75  movaps [rsp], xmm10
0000708296fd9d7a  movaps [rsp+0x10], xmm14
0000708296fd9d80  movaps [rsp+0x20], xmm4
0000708296fd9d85  lea rdi, [rsp]
0000708296fd9d89  mov esi, 0x00
0000708296fd9d8e  mov rax, 0x64BBC686C530
0000708296fd9d98  call rax
0000708296fd9d9a  movaps xmm10, [rsp]
0000708296fd9d9f  add rsp, 0x30
0000708296fd9da3  vmovaps xmm0, [rsp]
0000708296fd9da8  vmovaps xmm1, [rsp+0x10]
0000708296fd9dae  vmovaps xmm2, [rsp+0x20]
0000708296fd9db4  vmovaps xmm3, [rsp+0x30]
0000708296fd9dba  vmovaps xmm4, [rsp+0x40]
0000708296fd9dc0  vmovaps xmm5, [rsp+0x50]
0000708296fd9dc6  vmovaps xmm6, [rsp+0x60]
0000708296fd9dcc  vmovaps xmm7, [rsp+0x70]
0000708296fd9dd2  vmovaps xmm8, [rsp+0x80]
0000708296fd9ddb  vmovaps xmm9, [rsp+0x90]
0000708296fd9de4  vmovaps xmm11, [rsp+0xA0]
0000708296fd9ded  vmovaps xmm12, [rsp+0xB0]
0000708296fd9df6  vmovaps xmm13, [rsp+0xC0]
0000708296fd9dff  vmovaps xmm14, [rsp+0xD0]
0000708296fd9e08  vmovaps xmm15, [rsp+0xE0]
0000708296fd9e11  add rsp, 0xF0
0000708296fd9e18  pop r11
0000708296fd9e1a  pop r10
0000708296fd9e1c  pop r9
0000708296fd9e1e  pop r8
0000708296fd9e20  pop rsi
0000708296fd9e21  pop rdi
0000708296fd9e22  pop rdx
0000708296fd9e23  pop rcx
0000708296fd9e24  pop rax
0000708296fd9e25  add rsp, 0x08
0000708296fd9e29  jmp 0x0000708296FD6388
0000708296fd9e2e  sub rsp, 0x08
0000708296fd9e32  push rax
0000708296fd9e33  push rcx
0000708296fd9e34  push rdx
0000708296fd9e35  push rdi
0000708296fd9e36  push rsi
0000708296fd9e37  push r8
0000708296fd9e39  push r9
0000708296fd9e3b  push r10
0000708296fd9e3d  push r11
0000708296fd9e3f  sub rsp, 0xF0
0000708296fd9e46  vmovaps [rsp], xmm0
0000708296fd9e4b  vmovaps [rsp+0x10], xmm1
0000708296fd9e51  vmovaps [rsp+0x20], xmm2
0000708296fd9e57  vmovaps [rsp+0x30], xmm3
0000708296fd9e5d  vmovaps [rsp+0x40], xmm4
0000708296fd9e63  vmovaps [rsp+0x50], xmm5
0000708296fd9e69  vmovaps [rsp+0x60], xmm6
0000708296fd9e6f  vmovaps [rsp+0x70], xmm7
0000708296fd9e75  vmovaps [rsp+0x80], xmm9
0000708296fd9e7e  vmovaps [rsp+0x90], xmm10
0000708296fd9e87  vmovaps [rsp+0xA0], xmm11
0000708296fd9e90  vmovaps [rsp+0xB0], xmm12
0000708296fd9e99  vmovaps [rsp+0xC0], xmm13
0000708296fd9ea2  vmovaps [rsp+0xD0], xmm14
0000708296fd9eab  vmovaps [rsp+0xE0], xmm15
0000708296fd9eb4  sub rsp, 0x30
0000708296fd9eb8  movaps [rsp], xmm8
0000708296fd9ebd  movaps [rsp+0x10], xmm1
0000708296fd9ec2  movaps [rsp+0x20], xmm14
0000708296fd9ec8  lea rdi, [rsp]
0000708296fd9ecc  mov esi, 0x00
0000708296fd9ed1  mov rax, 0x64BBC686C530
0000708296fd9edb  call rax
0000708296fd9edd  movaps xmm8, [rsp]
0000708296fd9ee2  add rsp, 0x30
0000708296fd9ee6  vmovaps xmm0, [rsp]
0000708296fd9eeb  vmovaps xmm1, [rsp+0x10]
0000708296fd9ef1  vmovaps xmm2, [rsp+0x20]
0000708296fd9ef7  vmovaps xmm3, [rsp+0x30]
0000708296fd9efd  vmovaps xmm4, [rsp+0x40]
0000708296fd9f03  vmovaps xmm5, [rsp+0x50]
0000708296fd9f09  vmovaps xmm6, [rsp+0x60]
0000708296fd9f0f  vmovaps xmm7, [rsp+0x70]
0000708296fd9f15  vmovaps xmm9, [rsp+0x80]
0000708296fd9f1e  vmovaps xmm10, [rsp+0x90]
0000708296fd9f27  vmovaps xmm11, [rsp+0xA0]
0000708296fd9f30  vmovaps xmm12, [rsp+0xB0]
0000708296fd9f39  vmovaps xmm13, [rsp+0xC0]
0000708296fd9f42  vmovaps xmm14, [rsp+0xD0]
0000708296fd9f4b  vmovaps xmm15, [rsp+0xE0]
0000708296fd9f54  add rsp, 0xF0
0000708296fd9f5b  pop r11
0000708296fd9f5d  pop r10
0000708296fd9f5f  pop r9
0000708296fd9f61  pop r8
0000708296fd9f63  pop rsi
0000708296fd9f64  pop rdi
0000708296fd9f65  pop rdx
0000708296fd9f66  pop rcx
0000708296fd9f67  pop rax
0000708296fd9f68  add rsp, 0x08
0000708296fd9f6c  jmp 0x0000708296FD63AE
0000708296fd9f71  sub rsp, 0x08
0000708296fd9f75  push rax
0000708296fd9f76  push rcx
0000708296fd9f77  push rdx
0000708296fd9f78  push rdi
0000708296fd9f79  push rsi
0000708296fd9f7a  push r8
0000708296fd9f7c  push r9
0000708296fd9f7e  push r10
0000708296fd9f80  push r11
0000708296fd9f82  sub rsp, 0xF0
0000708296fd9f89  vmovaps [rsp], xmm0
0000708296fd9f8e  vmovaps [rsp+0x10], xmm1
0000708296fd9f94  vmovaps [rsp+0x20], xmm2
0000708296fd9f9a  vmovaps [rsp+0x30], xmm3
0000708296fd9fa0  vmovaps [rsp+0x40], xmm4
0000708296fd9fa6  vmovaps [rsp+0x50], xmm5
0000708296fd9fac  vmovaps [rsp+0x60], xmm7
0000708296fd9fb2  vmovaps [rsp+0x70], xmm8
0000708296fd9fb8  vmovaps [rsp+0x80], xmm9
0000708296fd9fc1  vmovaps [rsp+0x90], xmm10
0000708296fd9fca  vmovaps [rsp+0xA0], xmm11
0000708296fd9fd3  vmovaps [rsp+0xB0], xmm12
0000708296fd9fdc  vmovaps [rsp+0xC0], xmm13
0000708296fd9fe5  vmovaps [rsp+0xD0], xmm14
0000708296fd9fee  vmovaps [rsp+0xE0], xmm15
0000708296fd9ff7  sub rsp, 0x30
0000708296fd9ffb  movaps [rsp], xmm6
0000708296fd9fff  movaps [rsp+0x10], xmm1
0000708296fda004  movaps [rsp+0x20], xmm14
0000708296fda00a  lea rdi, [rsp]
0000708296fda00e  mov esi, 0x00
0000708296fda013  mov rax, 0x64BBC686C530
0000708296fda01d  call rax
0000708296fda01f  movaps xmm6, [rsp]
0000708296fda023  add rsp, 0x30
0000708296fda027  vmovaps xmm0, [rsp]
0000708296fda02c  vmovaps xmm1, [rsp+0x10]
0000708296fda032  vmovaps xmm2, [rsp+0x20]
0000708296fda038  vmovaps xmm3, [rsp+0x30]
0000708296fda03e  vmovaps xmm4, [rsp+0x40]
0000708296fda044  vmovaps xmm5, [rsp+0x50]
0000708296fda04a  vmovaps xmm7, [rsp+0x60]
0000708296fda050  vmovaps xmm8, [rsp+0x70]
0000708296fda056  vmovaps xmm9, [rsp+0x80]
0000708296fda05f  vmovaps xmm10, [rsp+0x90]
0000708296fda068  vmovaps xmm11, [rsp+0xA0]
0000708296fda071  vmovaps xmm12, [rsp+0xB0]
0000708296fda07a  vmovaps xmm13, [rsp+0xC0]
0000708296fda083  vmovaps xmm14, [rsp+0xD0]
0000708296fda08c  vmovaps xmm15, [rsp+0xE0]
0000708296fda095  add rsp, 0xF0
0000708296fda09c  pop r11
0000708296fda09e  pop r10
0000708296fda0a0  pop r9
0000708296fda0a2  pop r8
0000708296fda0a4  pop rsi
0000708296fda0a5  pop rdi
0000708296fda0a6  pop rdx
0000708296fda0a7  pop rcx
0000708296fda0a8  pop rax
0000708296fda0a9  add rsp, 0x08
0000708296fda0ad  jmp 0x0000708296FD63DA
0000708296fda0b2  sub rsp, 0x08
0000708296fda0b6  push rax
0000708296fda0b7  push rcx
0000708296fda0b8  push rdx
0000708296fda0b9  push rdi
0000708296fda0ba  push rsi
0000708296fda0bb  push r8
0000708296fda0bd  push r9
0000708296fda0bf  push r10
0000708296fda0c1  push r11
0000708296fda0c3  sub rsp, 0xF0
0000708296fda0ca  vmovaps [rsp], xmm0
0000708296fda0cf  vmovaps [rsp+0x10], xmm1
0000708296fda0d5  vmovaps [rsp+0x20], xmm2
0000708296fda0db  vmovaps [rsp+0x30], xmm3
0000708296fda0e1  vmovaps [rsp+0x40], xmm4
0000708296fda0e7  vmovaps [rsp+0x50], xmm5
0000708296fda0ed  vmovaps [rsp+0x60], xmm6
0000708296fda0f3  vmovaps [rsp+0x70], xmm7
0000708296fda0f9  vmovaps [rsp+0x80], xmm8
0000708296fda102  vmovaps [rsp+0x90], xmm9
0000708296fda10b  vmovaps [rsp+0xA0], xmm10
0000708296fda114  vmovaps [rsp+0xB0], xmm11
0000708296fda11d  vmovaps [rsp+0xC0], xmm12
0000708296fda126  vmovaps [rsp+0xD0], xmm13
0000708296fda12f  vmovaps [rsp+0xE0], xmm15
0000708296fda138  sub rsp, 0x30
0000708296fda13c  movaps [rsp], xmm14
0000708296fda141  movaps [rsp+0x10], xmm12
0000708296fda147  movaps [rsp+0x20], xmm1
0000708296fda14c  lea rdi, [rsp]
0000708296fda150  mov esi, 0x00
0000708296fda155  mov rax, 0x64BBC686C530
0000708296fda15f  call rax
0000708296fda161  movaps xmm14, [rsp]
0000708296fda166  add rsp, 0x30
0000708296fda16a  vmovaps xmm0, [rsp]
0000708296fda16f  vmovaps xmm1, [rsp+0x10]
0000708296fda175  vmovaps xmm2, [rsp+0x20]
0000708296fda17b  vmovaps xmm3, [rsp+0x30]
0000708296fda181  vmovaps xmm4, [rsp+0x40]
0000708296fda187  vmovaps xmm5, [rsp+0x50]
0000708296fda18d  vmovaps xmm6, [rsp+0x60]
0000708296fda193  vmovaps xmm7, [rsp+0x70]
0000708296fda199  vmovaps xmm8, [rsp+0x80]
0000708296fda1a2  vmovaps xmm9, [rsp+0x90]
0000708296fda1ab  vmovaps xmm10, [rsp+0xA0]
0000708296fda1b4  vmovaps xmm11, [rsp+0xB0]
0000708296fda1bd  vmovaps xmm12, [rsp+0xC0]
0000708296fda1c6  vmovaps xmm13, [rsp+0xD0]
0000708296fda1cf  vmovaps xmm15, [rsp+0xE0]
0000708296fda1d8  add rsp, 0xF0
0000708296fda1df  pop r11
0000708296fda1e1  pop r10
0000708296fda1e3  pop r9
0000708296fda1e5  pop r8
0000708296fda1e7  pop rsi
0000708296fda1e8  pop rdi
0000708296fda1e9  pop rdx
0000708296fda1ea  pop rcx
0000708296fda1eb  pop rax
0000708296fda1ec  add rsp, 0x08
0000708296fda1f0  jmp 0x0000708296FD6400
0000708296fda1f5  sub rsp, 0x08
0000708296fda1f9  push rax
0000708296fda1fa  push rcx
0000708296fda1fb  push rdx
0000708296fda1fc  push rdi
0000708296fda1fd  push rsi
0000708296fda1fe  push r8
0000708296fda200  push r9
0000708296fda202  push r10
0000708296fda204  push r11
0000708296fda206  sub rsp, 0xF0
0000708296fda20d  vmovaps [rsp], xmm0
0000708296fda212  vmovaps [rsp+0x10], xmm2
0000708296fda218  vmovaps [rsp+0x20], xmm3
0000708296fda21e  vmovaps [rsp+0x30], xmm4
0000708296fda224  vmovaps [rsp+0x40], xmm5
0000708296fda22a  vmovaps [rsp+0x50], xmm6
0000708296fda230  vmovaps [rsp+0x60], xmm7
0000708296fda236  vmovaps [rsp+0x70], xmm8
0000708296fda23c  vmovaps [rsp+0x80], xmm9
0000708296fda245  vmovaps [rsp+0x90], xmm10
0000708296fda24e  vmovaps [rsp+0xA0], xmm11
0000708296fda257  vmovaps [rsp+0xB0], xmm12
0000708296fda260  vmovaps [rsp+0xC0], xmm13
0000708296fda269  vmovaps [rsp+0xD0], xmm14
0000708296fda272  vmovaps [rsp+0xE0], xmm15
0000708296fda27b  sub rsp, 0x30
0000708296fda27f  movaps [rsp], xmm1
0000708296fda283  movaps [rsp+0x10], xmm13
0000708296fda289  movaps [rsp+0x20], xmm9
0000708296fda28f  lea rdi, [rsp]
0000708296fda293  mov esi, 0x00
0000708296fda298  mov rax, 0x64BBC686C530
0000708296fda2a2  call rax
0000708296fda2a4  movaps xmm1, [rsp]
0000708296fda2a8  add rsp, 0x30
0000708296fda2ac  vmovaps xmm0, [rsp]
0000708296fda2b1  vmovaps xmm2, [rsp+0x10]
0000708296fda2b7  vmovaps xmm3, [rsp+0x20]
0000708296fda2bd  vmovaps xmm4, [rsp+0x30]
0000708296fda2c3  vmovaps xmm5, [rsp+0x40]
0000708296fda2c9  vmovaps xmm6, [rsp+0x50]
0000708296fda2cf  vmovaps xmm7, [rsp+0x60]
0000708296fda2d5  vmovaps xmm8, [rsp+0x70]
0000708296fda2db  vmovaps xmm9, [rsp+0x80]
0000708296fda2e4  vmovaps xmm10, [rsp+0x90]
0000708296fda2ed  vmovaps xmm11, [rsp+0xA0]
0000708296fda2f6  vmovaps xmm12, [rsp+0xB0]
0000708296fda2ff  vmovaps xmm13, [rsp+0xC0]
0000708296fda308  vmovaps xmm14, [rsp+0xD0]
0000708296fda311  vmovaps xmm15, [rsp+0xE0]
0000708296fda31a  add rsp, 0xF0
0000708296fda321  pop r11
0000708296fda323  pop r10
0000708296fda325  pop r9
0000708296fda327  pop r8
0000708296fda329  pop rsi
0000708296fda32a  pop rdi
0000708296fda32b  pop rdx
0000708296fda32c  pop rcx
0000708296fda32d  pop rax
0000708296fda32e  add rsp, 0x08
0000708296fda332  jmp 0x0000708296FD641A
0000708296fda337  sub rsp, 0x08
0000708296fda33b  push rax
0000708296fda33c  push rcx
0000708296fda33d  push rdx
0000708296fda33e  push rdi
0000708296fda33f  push rsi
0000708296fda340  push r8
0000708296fda342  push r9
0000708296fda344  push r10
0000708296fda346  push r11
0000708296fda348  sub rsp, 0xF0
0000708296fda34f  vmovaps [rsp], xmm0
0000708296fda354  vmovaps [rsp+0x10], xmm1
0000708296fda35a  vmovaps [rsp+0x20], xmm2
0000708296fda360  vmovaps [rsp+0x30], xmm3
0000708296fda366  vmovaps [rsp+0x40], xmm4
0000708296fda36c  vmovaps [rsp+0x50], xmm5
0000708296fda372  vmovaps [rsp+0x60], xmm6
0000708296fda378  vmovaps [rsp+0x70], xmm7
0000708296fda37e  vmovaps [rsp+0x80], xmm8
0000708296fda387  vmovaps [rsp+0x90], xmm9
0000708296fda390  vmovaps [rsp+0xA0], xmm10
0000708296fda399  vmovaps [rsp+0xB0], xmm11
0000708296fda3a2  vmovaps [rsp+0xC0], xmm13
0000708296fda3ab  vmovaps [rsp+0xD0], xmm14
0000708296fda3b4  vmovaps [rsp+0xE0], xmm15
0000708296fda3bd  sub rsp, 0x30
0000708296fda3c1  movaps [rsp], xmm12
0000708296fda3c6  movaps [rsp+0x10], xmm7
0000708296fda3cb  movaps [rsp+0x20], xmm13
0000708296fda3d1  lea rdi, [rsp]
0000708296fda3d5  mov esi, 0x00
0000708296fda3da  mov rax, 0x64BBC686C530
0000708296fda3e4  call rax
0000708296fda3e6  movaps xmm12, [rsp]
0000708296fda3eb  add rsp, 0x30
0000708296fda3ef  vmovaps xmm0, [rsp]
0000708296fda3f4  vmovaps xmm1, [rsp+0x10]
0000708296fda3fa  vmovaps xmm2, [rsp+0x20]
0000708296fda400  vmovaps xmm3, [rsp+0x30]
0000708296fda406  vmovaps xmm4, [rsp+0x40]
0000708296fda40c  vmovaps xmm5, [rsp+0x50]
0000708296fda412  vmovaps xmm6, [rsp+0x60]
0000708296fda418  vmovaps xmm7, [rsp+0x70]
0000708296fda41e  vmovaps xmm8, [rsp+0x80]
0000708296fda427  vmovaps xmm9, [rsp+0x90]
0000708296fda430  vmovaps xmm10, [rsp+0xA0]
0000708296fda439  vmovaps xmm11, [rsp+0xB0]
0000708296fda442  vmovaps xmm13, [rsp+0xC0]
0000708296fda44b  vmovaps xmm14, [rsp+0xD0]
0000708296fda454  vmovaps xmm15, [rsp+0xE0]
0000708296fda45d  add rsp, 0xF0
0000708296fda464  pop r11
0000708296fda466  pop r10
0000708296fda468  pop r9
0000708296fda46a  pop r8
0000708296fda46c  pop rsi
0000708296fda46d  pop rdi
0000708296fda46e  pop rdx
0000708296fda46f  pop rcx
0000708296fda470  pop rax
0000708296fda471  add rsp, 0x08
0000708296fda475  jmp 0x0000708296FD6441
0000708296fda47a  sub rsp, 0x08
0000708296fda47e  push rax
0000708296fda47f  push rcx
0000708296fda480  push rdx
0000708296fda481  push rdi
0000708296fda482  push rsi
0000708296fda483  push r8
0000708296fda485  push r9
0000708296fda487  push r10
0000708296fda489  push r11
0000708296fda48b  sub rsp, 0xF0
0000708296fda492  vmovaps [rsp], xmm0
0000708296fda497  vmovaps [rsp+0x10], xmm1
0000708296fda49d  vmovaps [rsp+0x20], xmm2
0000708296fda4a3  vmovaps [rsp+0x30], xmm3
0000708296fda4a9  vmovaps [rsp+0x40], xmm4
0000708296fda4af  vmovaps [rsp+0x50], xmm5
0000708296fda4b5  vmovaps [rsp+0x60], xmm6
0000708296fda4bb  vmovaps [rsp+0x70], xmm7
0000708296fda4c1  vmovaps [rsp+0x80], xmm8
0000708296fda4ca  vmovaps [rsp+0x90], xmm9
0000708296fda4d3  vmovaps [rsp+0xA0], xmm10
0000708296fda4dc  vmovaps [rsp+0xB0], xmm11
0000708296fda4e5  vmovaps [rsp+0xC0], xmm12
0000708296fda4ee  vmovaps [rsp+0xD0], xmm14
0000708296fda4f7  vmovaps [rsp+0xE0], xmm15
0000708296fda500  sub rsp, 0x30
0000708296fda504  movaps [rsp], xmm13
0000708296fda509  movaps [rsp+0x10], xmm15
0000708296fda50f  movaps [rsp+0x20], xmm8
0000708296fda515  lea rdi, [rsp]
0000708296fda519  mov esi, 0x00
0000708296fda51e  mov rax, 0x64BBC686C530
0000708296fda528  call rax
0000708296fda52a  movaps xmm13, [rsp]
0000708296fda52f  add rsp, 0x30
0000708296fda533  vmovaps xmm0, [rsp]
0000708296fda538  vmovaps xmm1, [rsp+0x10]
0000708296fda53e  vmovaps xmm2, [rsp+0x20]
0000708296fda544  vmovaps xmm3, [rsp+0x30]
0000708296fda54a  vmovaps xmm4, [rsp+0x40]
0000708296fda550  vmovaps xmm5, [rsp+0x50]
0000708296fda556  vmovaps xmm6, [rsp+0x60]
0000708296fda55c  vmovaps xmm7, [rsp+0x70]
0000708296fda562  vmovaps xmm8, [rsp+0x80]
0000708296fda56b  vmovaps xmm9, [rsp+0x90]
0000708296fda574  vmovaps xmm10, [rsp+0xA0]
0000708296fda57d  vmovaps xmm11, [rsp+0xB0]
0000708296fda586  vmovaps xmm12, [rsp+0xC0]
0000708296fda58f  vmovaps xmm14, [rsp+0xD0]
0000708296fda598  vmovaps xmm15, [rsp+0xE0]
0000708296fda5a1  add rsp, 0xF0
0000708296fda5a8  pop r11
0000708296fda5aa  pop r10
0000708296fda5ac  pop r9
0000708296fda5ae  pop r8
0000708296fda5b0  pop rsi
0000708296fda5b1  pop rdi
0000708296fda5b2  pop rdx
0000708296fda5b3  pop rcx
0000708296fda5b4  pop rax
0000708296fda5b5  add rsp, 0x08
0000708296fda5b9  jmp 0x0000708296FD645C
0000708296fda5be  sub rsp, 0x08
0000708296fda5c2  push rax
0000708296fda5c3  push rcx
0000708296fda5c4  push rdx
0000708296fda5c5  push rdi
0000708296fda5c6  push rsi
0000708296fda5c7  push r8
0000708296fda5c9  push r9
0000708296fda5cb  push r10
0000708296fda5cd  push r11
0000708296fda5cf  sub rsp, 0xF0
0000708296fda5d6  vmovaps [rsp], xmm0
0000708296fda5db  vmovaps [rsp+0x10], xmm1
0000708296fda5e1  vmovaps [rsp+0x20], xmm2
0000708296fda5e7  vmovaps [rsp+0x30], xmm3
0000708296fda5ed  vmovaps [rsp+0x40], xmm4
0000708296fda5f3  vmovaps [rsp+0x50], xmm5
0000708296fda5f9  vmovaps [rsp+0x60], xmm6
0000708296fda5ff  vmovaps [rsp+0x70], xmm7
0000708296fda605  vmovaps [rsp+0x80], xmm9
0000708296fda60e  vmovaps [rsp+0x90], xmm10
0000708296fda617  vmovaps [rsp+0xA0], xmm11
0000708296fda620  vmovaps [rsp+0xB0], xmm12
0000708296fda629  vmovaps [rsp+0xC0], xmm13
0000708296fda632  vmovaps [rsp+0xD0], xmm14
0000708296fda63b  vmovaps [rsp+0xE0], xmm15
0000708296fda644  sub rsp, 0x30
0000708296fda648  movaps [rsp], xmm8
0000708296fda64d  movaps [rsp+0x10], xmm15
0000708296fda653  movaps [rsp+0x20], xmm9
0000708296fda659  lea rdi, [rsp]
0000708296fda65d  mov esi, 0x00
0000708296fda662  mov rax, 0x64BBC686C530
0000708296fda66c  call rax
0000708296fda66e  movaps xmm8, [rsp]
0000708296fda673  add rsp, 0x30
0000708296fda677  vmovaps xmm0, [rsp]
0000708296fda67c  vmovaps xmm1, [rsp+0x10]
0000708296fda682  vmovaps xmm2, [rsp+0x20]
0000708296fda688  vmovaps xmm3, [rsp+0x30]
0000708296fda68e  vmovaps xmm4, [rsp+0x40]
0000708296fda694  vmovaps xmm5, [rsp+0x50]
0000708296fda69a  vmovaps xmm6, [rsp+0x60]
0000708296fda6a0  vmovaps xmm7, [rsp+0x70]
0000708296fda6a6  vmovaps xmm9, [rsp+0x80]
0000708296fda6af  vmovaps xmm10, [rsp+0x90]
0000708296fda6b8  vmovaps xmm11, [rsp+0xA0]
0000708296fda6c1  vmovaps xmm12, [rsp+0xB0]
0000708296fda6ca  vmovaps xmm13, [rsp+0xC0]
0000708296fda6d3  vmovaps xmm14, [rsp+0xD0]
0000708296fda6dc  vmovaps xmm15, [rsp+0xE0]
0000708296fda6e5  add rsp, 0xF0
0000708296fda6ec  pop r11
0000708296fda6ee  pop r10
0000708296fda6f0  pop r9
0000708296fda6f2  pop r8
0000708296fda6f4  pop rsi
0000708296fda6f5  pop rdi
0000708296fda6f6  pop rdx
0000708296fda6f7  pop rcx
0000708296fda6f8  pop rax
0000708296fda6f9  add rsp, 0x08
0000708296fda6fd  jmp 0x0000708296FD648A
0000708296fda702  sub rsp, 0x08
0000708296fda706  push rax
0000708296fda707  push rcx
0000708296fda708  push rdx
0000708296fda709  push rdi
0000708296fda70a  push rsi
0000708296fda70b  push r8
0000708296fda70d  push r9
0000708296fda70f  push r10
0000708296fda711  push r11
0000708296fda713  sub rsp, 0xF0
0000708296fda71a  vmovaps [rsp], xmm0
0000708296fda71f  vmovaps [rsp+0x10], xmm1
0000708296fda725  vmovaps [rsp+0x20], xmm2
0000708296fda72b  vmovaps [rsp+0x30], xmm3
0000708296fda731  vmovaps [rsp+0x40], xmm4
0000708296fda737  vmovaps [rsp+0x50], xmm5
0000708296fda73d  vmovaps [rsp+0x60], xmm6
0000708296fda743  vmovaps [rsp+0x70], xmm7
0000708296fda749  vmovaps [rsp+0x80], xmm8
0000708296fda752  vmovaps [rsp+0x90], xmm9
0000708296fda75b  vmovaps [rsp+0xA0], xmm10
0000708296fda764  vmovaps [rsp+0xB0], xmm11
0000708296fda76d  vmovaps [rsp+0xC0], xmm12
0000708296fda776  vmovaps [rsp+0xD0], xmm13
0000708296fda77f  vmovaps [rsp+0xE0], xmm14
0000708296fda788  sub rsp, 0x30
0000708296fda78c  movaps [rsp], xmm15
0000708296fda791  movaps [rsp+0x10], xmm11
0000708296fda797  movaps [rsp+0x20], xmm6
0000708296fda79c  lea rdi, [rsp]
0000708296fda7a0  mov esi, 0x00
0000708296fda7a5  mov rax, 0x64BBC686C530
0000708296fda7af  call rax
0000708296fda7b1  movaps xmm15, [rsp]
0000708296fda7b6  add rsp, 0x30
0000708296fda7ba  vmovaps xmm0, [rsp]
0000708296fda7bf  vmovaps xmm1, [rsp+0x10]
0000708296fda7c5  vmovaps xmm2, [rsp+0x20]
0000708296fda7cb  vmovaps xmm3, [rsp+0x30]
0000708296fda7d1  vmovaps xmm4, [rsp+0x40]
0000708296fda7d7  vmovaps xmm5, [rsp+0x50]
0000708296fda7dd  vmovaps xmm6, [rsp+0x60]
0000708296fda7e3  vmovaps xmm7, [rsp+0x70]
0000708296fda7e9  vmovaps xmm8, [rsp+0x80]
0000708296fda7f2  vmovaps xmm9, [rsp+0x90]
0000708296fda7fb  vmovaps xmm10, [rsp+0xA0]
0000708296fda804  vmovaps xmm11, [rsp+0xB0]
0000708296fda80d  vmovaps xmm12, [rsp+0xC0]
0000708296fda816  vmovaps xmm13, [rsp+0xD0]
0000708296fda81f  vmovaps xmm14, [rsp+0xE0]
0000708296fda828  add rsp, 0xF0
0000708296fda82f  pop r11
0000708296fda831  pop r10
0000708296fda833  pop r9
0000708296fda835  pop r8
0000708296fda837  pop rsi
0000708296fda838  pop rdi
0000708296fda839  pop rdx
0000708296fda83a  pop rcx
0000708296fda83b  pop rax
0000708296fda83c  add rsp, 0x08
0000708296fda840  jmp 0x0000708296FD64A5
0000708296fda845  sub rsp, 0x08
0000708296fda849  push rax
0000708296fda84a  push rcx
0000708296fda84b  push rdx
0000708296fda84c  push rdi
0000708296fda84d  push rsi
0000708296fda84e  push r8
0000708296fda850  push r9
0000708296fda852  push r10
0000708296fda854  push r11
0000708296fda856  sub rsp, 0xF0
0000708296fda85d  vmovaps [rsp], xmm0
0000708296fda862  vmovaps [rsp+0x10], xmm1
0000708296fda868  vmovaps [rsp+0x20], xmm2
0000708296fda86e  vmovaps [rsp+0x30], xmm3
0000708296fda874  vmovaps [rsp+0x40], xmm4
0000708296fda87a  vmovaps [rsp+0x50], xmm5
0000708296fda880  vmovaps [rsp+0x60], xmm6
0000708296fda886  vmovaps [rsp+0x70], xmm8
0000708296fda88c  vmovaps [rsp+0x80], xmm9
0000708296fda895  vmovaps [rsp+0x90], xmm10
0000708296fda89e  vmovaps [rsp+0xA0], xmm11
0000708296fda8a7  vmovaps [rsp+0xB0], xmm12
0000708296fda8b0  vmovaps [rsp+0xC0], xmm13
0000708296fda8b9  vmovaps [rsp+0xD0], xmm14
0000708296fda8c2  vmovaps [rsp+0xE0], xmm15
0000708296fda8cb  sub rsp, 0x30
0000708296fda8cf  movaps [rsp], xmm7
0000708296fda8d3  movaps [rsp+0x10], xmm11
0000708296fda8d9  movaps [rsp+0x20], xmm9
0000708296fda8df  lea rdi, [rsp]
0000708296fda8e3  mov esi, 0x00
0000708296fda8e8  mov rax, 0x64BBC686C530
0000708296fda8f2  call rax
0000708296fda8f4  movaps xmm7, [rsp]
0000708296fda8f8  add rsp, 0x30
0000708296fda8fc  vmovaps xmm0, [rsp]
0000708296fda901  vmovaps xmm1, [rsp+0x10]
0000708296fda907  vmovaps xmm2, [rsp+0x20]
0000708296fda90d  vmovaps xmm3, [rsp+0x30]
0000708296fda913  vmovaps xmm4, [rsp+0x40]
0000708296fda919  vmovaps xmm5, [rsp+0x50]
0000708296fda91f  vmovaps xmm6, [rsp+0x60]
0000708296fda925  vmovaps xmm8, [rsp+0x70]
0000708296fda92b  vmovaps xmm9, [rsp+0x80]
0000708296fda934  vmovaps xmm10, [rsp+0x90]
0000708296fda93d  vmovaps xmm11, [rsp+0xA0]
0000708296fda946  vmovaps xmm12, [rsp+0xB0]
0000708296fda94f  vmovaps xmm13, [rsp+0xC0]
0000708296fda958  vmovaps xmm14, [rsp+0xD0]
0000708296fda961  vmovaps xmm15, [rsp+0xE0]
0000708296fda96a  add rsp, 0xF0
0000708296fda971  pop r11
0000708296fda973  pop r10
0000708296fda975  pop r9
0000708296fda977  pop r8
0000708296fda979  pop rsi
0000708296fda97a  pop rdi
0000708296fda97b  pop rdx
0000708296fda97c  pop rcx
0000708296fda97d  pop rax
0000708296fda97e  add rsp, 0x08
0000708296fda982  jmp 0x0000708296FD64D2
0000708296fda987  sub rsp, 0x08
0000708296fda98b  push rax
0000708296fda98c  push rcx
0000708296fda98d  push rdx
0000708296fda98e  push rdi
0000708296fda98f  push rsi
0000708296fda990  push r8
0000708296fda992  push r9
0000708296fda994  push r10
0000708296fda996  push r11
0000708296fda998  sub rsp, 0xF0
0000708296fda99f  vmovaps [rsp], xmm0
0000708296fda9a4  vmovaps [rsp+0x10], xmm1
0000708296fda9aa  vmovaps [rsp+0x20], xmm2
0000708296fda9b0  vmovaps [rsp+0x30], xmm3
0000708296fda9b6  vmovaps [rsp+0x40], xmm4
0000708296fda9bc  vmovaps [rsp+0x50], xmm5
0000708296fda9c2  vmovaps [rsp+0x60], xmm6
0000708296fda9c8  vmovaps [rsp+0x70], xmm7
0000708296fda9ce  vmovaps [rsp+0x80], xmm8
0000708296fda9d7  vmovaps [rsp+0x90], xmm9
0000708296fda9e0  vmovaps [rsp+0xA0], xmm10
0000708296fda9e9  vmovaps [rsp+0xB0], xmm12
0000708296fda9f2  vmovaps [rsp+0xC0], xmm13
0000708296fda9fb  vmovaps [rsp+0xD0], xmm14
0000708296fdaa04  vmovaps [rsp+0xE0], xmm15
0000708296fdaa0d  sub rsp, 0x30
0000708296fdaa11  movaps [rsp], xmm11
0000708296fdaa16  movaps [rsp+0x10], xmm10
0000708296fdaa1c  movaps [rsp+0x20], xmm14
0000708296fdaa22  lea rdi, [rsp]
0000708296fdaa26  mov esi, 0x00
0000708296fdaa2b  mov rax, 0x64BBC686C530
0000708296fdaa35  call rax
0000708296fdaa37  movaps xmm11, [rsp]
0000708296fdaa3c  add rsp, 0x30
0000708296fdaa40  vmovaps xmm0, [rsp]
0000708296fdaa45  vmovaps xmm1, [rsp+0x10]
0000708296fdaa4b  vmovaps xmm2, [rsp+0x20]
0000708296fdaa51  vmovaps xmm3, [rsp+0x30]
0000708296fdaa57  vmovaps xmm4, [rsp+0x40]
0000708296fdaa5d  vmovaps xmm5, [rsp+0x50]
0000708296fdaa63  vmovaps xmm6, [rsp+0x60]
0000708296fdaa69  vmovaps xmm7, [rsp+0x70]
0000708296fdaa6f  vmovaps xmm8, [rsp+0x80]
0000708296fdaa78  vmovaps xmm9, [rsp+0x90]
0000708296fdaa81  vmovaps xmm10, [rsp+0xA0]
0000708296fdaa8a  vmovaps xmm12, [rsp+0xB0]
0000708296fdaa93  vmovaps xmm13, [rsp+0xC0]
0000708296fdaa9c  vmovaps xmm14, [rsp+0xD0]
0000708296fdaaa5  vmovaps xmm15, [rsp+0xE0]
0000708296fdaaae  add rsp, 0xF0
0000708296fdaab5  pop r11
0000708296fdaab7  pop r10
0000708296fdaab9  pop r9
0000708296fdaabb  pop r8
0000708296fdaabd  pop rsi
0000708296fdaabe  pop rdi
0000708296fdaabf  pop rdx
0000708296fdaac0  pop rcx
0000708296fdaac1  pop rax
0000708296fdaac2  add rsp, 0x08
0000708296fdaac6  jmp 0x0000708296FD64ED
0000708296fdaacb  call 0x0000708296EE45A0
0000708296fdaad0  jmp 0x0000708296FD64F7
0000708296fdaad5  sub rsp, 0x08
0000708296fdaad9  push rax
0000708296fdaada  push rcx
0000708296fdaadb  push rdx
0000708296fdaadc  push rdi
0000708296fdaadd  push rsi
0000708296fdaade  push r8
0000708296fdaae0  push r9
0000708296fdaae2  push r10
0000708296fdaae4  push r11
0000708296fdaae6  sub rsp, 0xF0
0000708296fdaaed  vmovaps [rsp], xmm0
0000708296fdaaf2  vmovaps [rsp+0x10], xmm1
0000708296fdaaf8  vmovaps [rsp+0x20], xmm2
0000708296fdaafe  vmovaps [rsp+0x30], xmm3
0000708296fdab04  vmovaps [rsp+0x40], xmm4
0000708296fdab0a  vmovaps [rsp+0x50], xmm5
0000708296fdab10  vmovaps [rsp+0x60], xmm6
0000708296fdab16  vmovaps [rsp+0x70], xmm7
0000708296fdab1c  vmovaps [rsp+0x80], xmm8
0000708296fdab25  vmovaps [rsp+0x90], xmm9
0000708296fdab2e  vmovaps [rsp+0xA0], xmm11
0000708296fdab37  vmovaps [rsp+0xB0], xmm12
0000708296fdab40  vmovaps [rsp+0xC0], xmm13
0000708296fdab49  vmovaps [rsp+0xD0], xmm14
0000708296fdab52  vmovaps [rsp+0xE0], xmm15
0000708296fdab5b  sub rsp, 0x30
0000708296fdab5f  movaps [rsp], xmm10
0000708296fdab64  movaps [rsp+0x10], xmm1
0000708296fdab69  movaps [rsp+0x20], xmm12
0000708296fdab6f  lea rdi, [rsp]
0000708296fdab73  mov esi, 0x00
0000708296fdab78  mov rax, 0x64BBC686C530
0000708296fdab82  call rax
0000708296fdab84  movaps xmm10, [rsp]
0000708296fdab89  add rsp, 0x30
0000708296fdab8d  vmovaps xmm0, [rsp]
0000708296fdab92  vmovaps xmm1, [rsp+0x10]
0000708296fdab98  vmovaps xmm2, [rsp+0x20]
0000708296fdab9e  vmovaps xmm3, [rsp+0x30]
0000708296fdaba4  vmovaps xmm4, [rsp+0x40]
0000708296fdabaa  vmovaps xmm5, [rsp+0x50]
0000708296fdabb0  vmovaps xmm6, [rsp+0x60]
0000708296fdabb6  vmovaps xmm7, [rsp+0x70]
0000708296fdabbc  vmovaps xmm8, [rsp+0x80]
0000708296fdabc5  vmovaps xmm9, [rsp+0x90]
0000708296fdabce  vmovaps xmm11, [rsp+0xA0]
0000708296fdabd7  vmovaps xmm12, [rsp+0xB0]
0000708296fdabe0  vmovaps xmm13, [rsp+0xC0]
0000708296fdabe9  vmovaps xmm14, [rsp+0xD0]
0000708296fdabf2  vmovaps xmm15, [rsp+0xE0]
0000708296fdabfb  add rsp, 0xF0
0000708296fdac02  pop r11
0000708296fdac04  pop r10
0000708296fdac06  pop r9
0000708296fdac08  pop r8
0000708296fdac0a  pop rsi
0000708296fdac0b  pop rdi
0000708296fdac0c  pop rdx
0000708296fdac0d  pop rcx
0000708296fdac0e  pop rax
0000708296fdac0f  add rsp, 0x08
0000708296fdac13  jmp 0x0000708296FD651A
0000708296fdac18  sub rsp, 0x08
0000708296fdac1c  push rax
0000708296fdac1d  push rcx
0000708296fdac1e  push rdx
0000708296fdac1f  push rdi
0000708296fdac20  push rsi
0000708296fdac21  push r8
0000708296fdac23  push r9
0000708296fdac25  push r10
0000708296fdac27  push r11
0000708296fdac29  sub rsp, 0xF0
0000708296fdac30  vmovaps [rsp], xmm0
0000708296fdac35  vmovaps [rsp+0x10], xmm1
0000708296fdac3b  vmovaps [rsp+0x20], xmm2
0000708296fdac41  vmovaps [rsp+0x30], xmm3
0000708296fdac47  vmovaps [rsp+0x40], xmm4
0000708296fdac4d  vmovaps [rsp+0x50], xmm5
0000708296fdac53  vmovaps [rsp+0x60], xmm6
0000708296fdac59  vmovaps [rsp+0x70], xmm7
0000708296fdac5f  vmovaps [rsp+0x80], xmm8
0000708296fdac68  vmovaps [rsp+0x90], xmm9
0000708296fdac71  vmovaps [rsp+0xA0], xmm10
0000708296fdac7a  vmovaps [rsp+0xB0], xmm11
0000708296fdac83  vmovaps [rsp+0xC0], xmm13
0000708296fdac8c  vmovaps [rsp+0xD0], xmm14
0000708296fdac95  vmovaps [rsp+0xE0], xmm15
0000708296fdac9e  sub rsp, 0x30
0000708296fdaca2  movaps [rsp], xmm12
0000708296fdaca7  movaps [rsp+0x10], xmm14
0000708296fdacad  movaps [rsp+0x20], xmm1
0000708296fdacb2  lea rdi, [rsp]
0000708296fdacb6  mov esi, 0x00
0000708296fdacbb  mov rax, 0x64BBC686C530
0000708296fdacc5  call rax
0000708296fdacc7  movaps xmm12, [rsp]
0000708296fdaccc  add rsp, 0x30
0000708296fdacd0  vmovaps xmm0, [rsp]
0000708296fdacd5  vmovaps xmm1, [rsp+0x10]
0000708296fdacdb  vmovaps xmm2, [rsp+0x20]
0000708296fdace1  vmovaps xmm3, [rsp+0x30]
0000708296fdace7  vmovaps xmm4, [rsp+0x40]
0000708296fdaced  vmovaps xmm5, [rsp+0x50]
0000708296fdacf3  vmovaps xmm6, [rsp+0x60]
0000708296fdacf9  vmovaps xmm7, [rsp+0x70]
0000708296fdacff  vmovaps xmm8, [rsp+0x80]
0000708296fdad08  vmovaps xmm9, [rsp+0x90]
0000708296fdad11  vmovaps xmm10, [rsp+0xA0]
0000708296fdad1a  vmovaps xmm11, [rsp+0xB0]
0000708296fdad23  vmovaps xmm13, [rsp+0xC0]
0000708296fdad2c  vmovaps xmm14, [rsp+0xD0]
0000708296fdad35  vmovaps xmm15, [rsp+0xE0]
0000708296fdad3e  add rsp, 0xF0
0000708296fdad45  pop r11
0000708296fdad47  pop r10
0000708296fdad49  pop r9
0000708296fdad4b  pop r8
0000708296fdad4d  pop rsi
0000708296fdad4e  pop rdi
0000708296fdad4f  pop rdx
0000708296fdad50  pop rcx
0000708296fdad51  pop rax
0000708296fdad52  add rsp, 0x08
0000708296fdad56  jmp 0x0000708296FD6549
0000708296fdad5b  sub rsp, 0x08
0000708296fdad5f  push rax
0000708296fdad60  push rcx
0000708296fdad61  push rdx
0000708296fdad62  push rdi
0000708296fdad63  push rsi
0000708296fdad64  push r8
0000708296fdad66  push r9
0000708296fdad68  push r10
0000708296fdad6a  push r11
0000708296fdad6c  sub rsp, 0xF0
0000708296fdad73  vmovaps [rsp], xmm0
0000708296fdad78  vmovaps [rsp+0x10], xmm1
0000708296fdad7e  vmovaps [rsp+0x20], xmm2
0000708296fdad84  vmovaps [rsp+0x30], xmm3
0000708296fdad8a  vmovaps [rsp+0x40], xmm4
0000708296fdad90  vmovaps [rsp+0x50], xmm5
0000708296fdad96  vmovaps [rsp+0x60], xmm6
0000708296fdad9c  vmovaps [rsp+0x70], xmm7
0000708296fdada2  vmovaps [rsp+0x80], xmm8
0000708296fdadab  vmovaps [rsp+0x90], xmm9
0000708296fdadb4  vmovaps [rsp+0xA0], xmm10
0000708296fdadbd  vmovaps [rsp+0xB0], xmm11
0000708296fdadc6  vmovaps [rsp+0xC0], xmm12
0000708296fdadcf  vmovaps [rsp+0xD0], xmm13
0000708296fdadd8  vmovaps [rsp+0xE0], xmm15
0000708296fdade1  sub rsp, 0x30
0000708296fdade5  movaps [rsp], xmm14
0000708296fdadea  movaps [rsp+0x10], xmm9
0000708296fdadf0  movaps [rsp+0x20], xmm1
0000708296fdadf5  lea rdi, [rsp]
0000708296fdadf9  mov esi, 0x00
0000708296fdadfe  mov rax, 0x64BBC686C530
0000708296fdae08  call rax
0000708296fdae0a  movaps xmm14, [rsp]
0000708296fdae0f  add rsp, 0x30
0000708296fdae13  vmovaps xmm0, [rsp]
0000708296fdae18  vmovaps xmm1, [rsp+0x10]
0000708296fdae1e  vmovaps xmm2, [rsp+0x20]
0000708296fdae24  vmovaps xmm3, [rsp+0x30]
0000708296fdae2a  vmovaps xmm4, [rsp+0x40]
0000708296fdae30  vmovaps xmm5, [rsp+0x50]
0000708296fdae36  vmovaps xmm6, [rsp+0x60]
0000708296fdae3c  vmovaps xmm7, [rsp+0x70]
0000708296fdae42  vmovaps xmm8, [rsp+0x80]
0000708296fdae4b  vmovaps xmm9, [rsp+0x90]
0000708296fdae54  vmovaps xmm10, [rsp+0xA0]
0000708296fdae5d  vmovaps xmm11, [rsp+0xB0]
0000708296fdae66  vmovaps xmm12, [rsp+0xC0]
0000708296fdae6f  vmovaps xmm13, [rsp+0xD0]
0000708296fdae78  vmovaps xmm15, [rsp+0xE0]
0000708296fdae81  add rsp, 0xF0
0000708296fdae88  pop r11
0000708296fdae8a  pop r10
0000708296fdae8c  pop r9
0000708296fdae8e  pop r8
0000708296fdae90  pop rsi
0000708296fdae91  pop rdi
0000708296fdae92  pop rdx
0000708296fdae93  pop rcx
0000708296fdae94  pop rax
0000708296fdae95  add rsp, 0x08
0000708296fdae99  jmp 0x0000708296FD6578
0000708296fdae9e  sub rsp, 0x08
0000708296fdaea2  push rax
0000708296fdaea3  push rcx
0000708296fdaea4  push rdx
0000708296fdaea5  push rdi
0000708296fdaea6  push rsi
0000708296fdaea7  push r8
0000708296fdaea9  push r9
0000708296fdaeab  push r10
0000708296fdaead  push r11
0000708296fdaeaf  sub rsp, 0xF0
0000708296fdaeb6  vmovaps [rsp], xmm0
0000708296fdaebb  vmovaps [rsp+0x10], xmm2
0000708296fdaec1  vmovaps [rsp+0x20], xmm3
0000708296fdaec7  vmovaps [rsp+0x30], xmm4
0000708296fdaecd  vmovaps [rsp+0x40], xmm5
0000708296fdaed3  vmovaps [rsp+0x50], xmm6
0000708296fdaed9  vmovaps [rsp+0x60], xmm7
0000708296fdaedf  vmovaps [rsp+0x70], xmm8
0000708296fdaee5  vmovaps [rsp+0x80], xmm9
0000708296fdaeee  vmovaps [rsp+0x90], xmm10
0000708296fdaef7  vmovaps [rsp+0xA0], xmm11
0000708296fdaf00  vmovaps [rsp+0xB0], xmm12
0000708296fdaf09  vmovaps [rsp+0xC0], xmm13
0000708296fdaf12  vmovaps [rsp+0xD0], xmm14
0000708296fdaf1b  vmovaps [rsp+0xE0], xmm15
0000708296fdaf24  sub rsp, 0x30
0000708296fdaf28  movaps [rsp], xmm1
0000708296fdaf2c  movaps [rsp+0x10], xmm13
0000708296fdaf32  movaps [rsp+0x20], xmm8
0000708296fdaf38  lea rdi, [rsp]
0000708296fdaf3c  mov esi, 0x00
0000708296fdaf41  mov rax, 0x64BBC686C530
0000708296fdaf4b  call rax
0000708296fdaf4d  movaps xmm1, [rsp]
0000708296fdaf51  add rsp, 0x30
0000708296fdaf55  vmovaps xmm0, [rsp]
0000708296fdaf5a  vmovaps xmm2, [rsp+0x10]
0000708296fdaf60  vmovaps xmm3, [rsp+0x20]
0000708296fdaf66  vmovaps xmm4, [rsp+0x30]
0000708296fdaf6c  vmovaps xmm5, [rsp+0x40]
0000708296fdaf72  vmovaps xmm6, [rsp+0x50]
0000708296fdaf78  vmovaps xmm7, [rsp+0x60]
0000708296fdaf7e  vmovaps xmm8, [rsp+0x70]
0000708296fdaf84  vmovaps xmm9, [rsp+0x80]
0000708296fdaf8d  vmovaps xmm10, [rsp+0x90]
0000708296fdaf96  vmovaps xmm11, [rsp+0xA0]
0000708296fdaf9f  vmovaps xmm12, [rsp+0xB0]
0000708296fdafa8  vmovaps xmm13, [rsp+0xC0]
0000708296fdafb1  vmovaps xmm14, [rsp+0xD0]
0000708296fdafba  vmovaps xmm15, [rsp+0xE0]
0000708296fdafc3  add rsp, 0xF0
0000708296fdafca  pop r11
0000708296fdafcc  pop r10
0000708296fdafce  pop r9
0000708296fdafd0  pop r8
0000708296fdafd2  pop rsi
0000708296fdafd3  pop rdi
0000708296fdafd4  pop rdx
0000708296fdafd5  pop rcx
0000708296fdafd6  pop rax
0000708296fdafd7  add rsp, 0x08
0000708296fdafdb  jmp 0x0000708296FD659A
0000708296fdafe0  call 0x0000708296E0C260
0000708296fdafe5  jmp 0x0000708296FD65A8
0000708296fdafea  call 0x0000708296EDE950
0000708296fdafef  jmp 0x0000708296FD65B2
0000708296fdaff4  sub rsp, 0x08
0000708296fdaff8  push rax
0000708296fdaff9  push rcx
0000708296fdaffa  push rdx
0000708296fdaffb  push rdi
0000708296fdaffc  push rsi
0000708296fdaffd  push r8
0000708296fdafff  push r9
0000708296fdb001  push r10
0000708296fdb003  push r11
0000708296fdb005  sub rsp, 0xF0
0000708296fdb00c  vmovaps [rsp], xmm0
0000708296fdb011  vmovaps [rsp+0x10], xmm1
0000708296fdb017  vmovaps [rsp+0x20], xmm2
0000708296fdb01d  vmovaps [rsp+0x30], xmm3
0000708296fdb023  vmovaps [rsp+0x40], xmm4
0000708296fdb029  vmovaps [rsp+0x50], xmm5
0000708296fdb02f  vmovaps [rsp+0x60], xmm6
0000708296fdb035  vmovaps [rsp+0x70], xmm7
0000708296fdb03b  vmovaps [rsp+0x80], xmm9
0000708296fdb044  vmovaps [rsp+0x90], xmm10
0000708296fdb04d  vmovaps [rsp+0xA0], xmm11
0000708296fdb056  vmovaps [rsp+0xB0], xmm12
0000708296fdb05f  vmovaps [rsp+0xC0], xmm13
0000708296fdb068  vmovaps [rsp+0xD0], xmm14
0000708296fdb071  vmovaps [rsp+0xE0], xmm15
0000708296fdb07a  sub rsp, 0x30
0000708296fdb07e  movaps [rsp], xmm8
0000708296fdb083  movaps [rsp+0x10], xmm15
0000708296fdb089  movaps [rsp+0x20], xmm7
0000708296fdb08e  lea rdi, [rsp]
0000708296fdb092  mov esi, 0x00
0000708296fdb097  mov rax, 0x64BBC686C530
0000708296fdb0a1  call rax
0000708296fdb0a3  movaps xmm8, [rsp]
0000708296fdb0a8  add rsp, 0x30
0000708296fdb0ac  vmovaps xmm0, [rsp]
0000708296fdb0b1  vmovaps xmm1, [rsp+0x10]
0000708296fdb0b7  vmovaps xmm2, [rsp+0x20]
0000708296fdb0bd  vmovaps xmm3, [rsp+0x30]
0000708296fdb0c3  vmovaps xmm4, [rsp+0x40]
0000708296fdb0c9  vmovaps xmm5, [rsp+0x50]
0000708296fdb0cf  vmovaps xmm6, [rsp+0x60]
0000708296fdb0d5  vmovaps xmm7, [rsp+0x70]
0000708296fdb0db  vmovaps xmm9, [rsp+0x80]
0000708296fdb0e4  vmovaps xmm10, [rsp+0x90]
0000708296fdb0ed  vmovaps xmm11, [rsp+0xA0]
0000708296fdb0f6  vmovaps xmm12, [rsp+0xB0]
0000708296fdb0ff  vmovaps xmm13, [rsp+0xC0]
0000708296fdb108  vmovaps xmm14, [rsp+0xD0]
0000708296fdb111  vmovaps xmm15, [rsp+0xE0]
0000708296fdb11a  add rsp, 0xF0
0000708296fdb121  pop r11
0000708296fdb123  pop r10
0000708296fdb125  pop r9
0000708296fdb127  pop r8
0000708296fdb129  pop rsi
0000708296fdb12a  pop rdi
0000708296fdb12b  pop rdx
0000708296fdb12c  pop rcx
0000708296fdb12d  pop rax
0000708296fdb12e  add rsp, 0x08
0000708296fdb132  jmp 0x0000708296FD65D4
0000708296fdb137  sub rsp, 0x08
0000708296fdb13b  push rax
0000708296fdb13c  push rcx
0000708296fdb13d  push rdx
0000708296fdb13e  push rdi
0000708296fdb13f  push rsi
0000708296fdb140  push r8
0000708296fdb142  push r9
0000708296fdb144  push r10
0000708296fdb146  push r11
0000708296fdb148  sub rsp, 0xF0
0000708296fdb14f  vmovaps [rsp], xmm0
0000708296fdb154  vmovaps [rsp+0x10], xmm1
0000708296fdb15a  vmovaps [rsp+0x20], xmm2
0000708296fdb160  vmovaps [rsp+0x30], xmm3
0000708296fdb166  vmovaps [rsp+0x40], xmm4
0000708296fdb16c  vmovaps [rsp+0x50], xmm5
0000708296fdb172  vmovaps [rsp+0x60], xmm6
0000708296fdb178  vmovaps [rsp+0x70], xmm8
0000708296fdb17e  vmovaps [rsp+0x80], xmm9
0000708296fdb187  vmovaps [rsp+0x90], xmm10
0000708296fdb190  vmovaps [rsp+0xA0], xmm11
0000708296fdb199  vmovaps [rsp+0xB0], xmm12
0000708296fdb1a2  vmovaps [rsp+0xC0], xmm13
0000708296fdb1ab  vmovaps [rsp+0xD0], xmm14
0000708296fdb1b4  vmovaps [rsp+0xE0], xmm15
0000708296fdb1bd  sub rsp, 0x30
0000708296fdb1c1  movaps [rsp], xmm7
0000708296fdb1c5  movaps [rsp+0x10], xmm9
0000708296fdb1cb  movaps [rsp+0x20], xmm15
0000708296fdb1d1  lea rdi, [rsp]
0000708296fdb1d5  mov esi, 0x00
0000708296fdb1da  mov rax, 0x64BBC686C530
0000708296fdb1e4  call rax
0000708296fdb1e6  movaps xmm7, [rsp]
0000708296fdb1ea  add rsp, 0x30
0000708296fdb1ee  vmovaps xmm0, [rsp]
0000708296fdb1f3  vmovaps xmm1, [rsp+0x10]
0000708296fdb1f9  vmovaps xmm2, [rsp+0x20]
0000708296fdb1ff  vmovaps xmm3, [rsp+0x30]
0000708296fdb205  vmovaps xmm4, [rsp+0x40]
0000708296fdb20b  vmovaps xmm5, [rsp+0x50]
0000708296fdb211  vmovaps xmm6, [rsp+0x60]
0000708296fdb217  vmovaps xmm8, [rsp+0x70]
0000708296fdb21d  vmovaps xmm9, [rsp+0x80]
0000708296fdb226  vmovaps xmm10, [rsp+0x90]
0000708296fdb22f  vmovaps xmm11, [rsp+0xA0]
0000708296fdb238  vmovaps xmm12, [rsp+0xB0]
0000708296fdb241  vmovaps xmm13, [rsp+0xC0]
0000708296fdb24a  vmovaps xmm14, [rsp+0xD0]
0000708296fdb253  vmovaps xmm15, [rsp+0xE0]
0000708296fdb25c  add rsp, 0xF0
0000708296fdb263  pop r11
0000708296fdb265  pop r10
0000708296fdb267  pop r9
0000708296fdb269  pop r8
0000708296fdb26b  pop rsi
0000708296fdb26c  pop rdi
0000708296fdb26d  pop rdx
0000708296fdb26e  pop rcx
0000708296fdb26f  pop rax
0000708296fdb270  add rsp, 0x08
0000708296fdb274  jmp 0x0000708296FD6601
0000708296fdb279  sub rsp, 0x08
0000708296fdb27d  push rax
0000708296fdb27e  push rcx
0000708296fdb27f  push rdx
0000708296fdb280  push rdi
0000708296fdb281  push rsi
0000708296fdb282  push r8
0000708296fdb284  push r9
0000708296fdb286  push r10
0000708296fdb288  push r11
0000708296fdb28a  sub rsp, 0xF0
0000708296fdb291  vmovaps [rsp], xmm0
0000708296fdb296  vmovaps [rsp+0x10], xmm1
0000708296fdb29c  vmovaps [rsp+0x20], xmm2
0000708296fdb2a2  vmovaps [rsp+0x30], xmm3
0000708296fdb2a8  vmovaps [rsp+0x40], xmm4
0000708296fdb2ae  vmovaps [rsp+0x50], xmm5
0000708296fdb2b4  vmovaps [rsp+0x60], xmm6
0000708296fdb2ba  vmovaps [rsp+0x70], xmm7
0000708296fdb2c0  vmovaps [rsp+0x80], xmm8
0000708296fdb2c9  vmovaps [rsp+0x90], xmm10
0000708296fdb2d2  vmovaps [rsp+0xA0], xmm11
0000708296fdb2db  vmovaps [rsp+0xB0], xmm12
0000708296fdb2e4  vmovaps [rsp+0xC0], xmm13
0000708296fdb2ed  vmovaps [rsp+0xD0], xmm14
0000708296fdb2f6  vmovaps [rsp+0xE0], xmm15
0000708296fdb2ff  sub rsp, 0x30
0000708296fdb303  movaps [rsp], xmm9
0000708296fdb308  movaps [rsp+0x10], xmm13
0000708296fdb30e  movaps [rsp+0x20], xmm15
0000708296fdb314  lea rdi, [rsp]
0000708296fdb318  mov esi, 0x00
0000708296fdb31d  mov rax, 0x64BBC686C530
0000708296fdb327  call rax
0000708296fdb329  movaps xmm9, [rsp]
0000708296fdb32e  add rsp, 0x30
0000708296fdb332  vmovaps xmm0, [rsp]
0000708296fdb337  vmovaps xmm1, [rsp+0x10]
0000708296fdb33d  vmovaps xmm2, [rsp+0x20]
0000708296fdb343  vmovaps xmm3, [rsp+0x30]
0000708296fdb349  vmovaps xmm4, [rsp+0x40]
0000708296fdb34f  vmovaps xmm5, [rsp+0x50]
0000708296fdb355  vmovaps xmm6, [rsp+0x60]
0000708296fdb35b  vmovaps xmm7, [rsp+0x70]
0000708296fdb361  vmovaps xmm8, [rsp+0x80]
0000708296fdb36a  vmovaps xmm10, [rsp+0x90]
0000708296fdb373  vmovaps xmm11, [rsp+0xA0]
0000708296fdb37c  vmovaps xmm12, [rsp+0xB0]
0000708296fdb385  vmovaps xmm13, [rsp+0xC0]
0000708296fdb38e  vmovaps xmm14, [rsp+0xD0]
0000708296fdb397  vmovaps xmm15, [rsp+0xE0]
0000708296fdb3a0  add rsp, 0xF0
0000708296fdb3a7  pop r11
0000708296fdb3a9  pop r10
0000708296fdb3ab  pop r9
0000708296fdb3ad  pop r8
0000708296fdb3af  pop rsi
0000708296fdb3b0  pop rdi
0000708296fdb3b1  pop rdx
0000708296fdb3b2  pop rcx
0000708296fdb3b3  pop rax
0000708296fdb3b4  add rsp, 0x08
0000708296fdb3b8  jmp 0x0000708296FD662F
0000708296fdb3bd  sub rsp, 0x08
0000708296fdb3c1  push rax
0000708296fdb3c2  push rcx
0000708296fdb3c3  push rdx
0000708296fdb3c4  push rdi
0000708296fdb3c5  push rsi
0000708296fdb3c6  push r8
0000708296fdb3c8  push r9
0000708296fdb3ca  push r10
0000708296fdb3cc  push r11
0000708296fdb3ce  sub rsp, 0xF0
0000708296fdb3d5  vmovaps [rsp], xmm0
0000708296fdb3da  vmovaps [rsp+0x10], xmm1
0000708296fdb3e0  vmovaps [rsp+0x20], xmm2
0000708296fdb3e6  vmovaps [rsp+0x30], xmm3
0000708296fdb3ec  vmovaps [rsp+0x40], xmm4
0000708296fdb3f2  vmovaps [rsp+0x50], xmm5
0000708296fdb3f8  vmovaps [rsp+0x60], xmm6
0000708296fdb3fe  vmovaps [rsp+0x70], xmm7
0000708296fdb404  vmovaps [rsp+0x80], xmm8
0000708296fdb40d  vmovaps [rsp+0x90], xmm9
0000708296fdb416  vmovaps [rsp+0xA0], xmm10
0000708296fdb41f  vmovaps [rsp+0xB0], xmm11
0000708296fdb428  vmovaps [rsp+0xC0], xmm12
0000708296fdb431  vmovaps [rsp+0xD0], xmm13
0000708296fdb43a  vmovaps [rsp+0xE0], xmm14
0000708296fdb443  sub rsp, 0x30
0000708296fdb447  movaps [rsp], xmm15
0000708296fdb44c  movaps [rsp+0x10], xmm11
0000708296fdb452  movaps [rsp+0x20], xmm12
0000708296fdb458  lea rdi, [rsp]
0000708296fdb45c  mov esi, 0x00
0000708296fdb461  mov rax, 0x64BBC686C530
0000708296fdb46b  call rax
0000708296fdb46d  movaps xmm15, [rsp]
0000708296fdb472  add rsp, 0x30
0000708296fdb476  vmovaps xmm0, [rsp]
0000708296fdb47b  vmovaps xmm1, [rsp+0x10]
0000708296fdb481  vmovaps xmm2, [rsp+0x20]
0000708296fdb487  vmovaps xmm3, [rsp+0x30]
0000708296fdb48d  vmovaps xmm4, [rsp+0x40]
0000708296fdb493  vmovaps xmm5, [rsp+0x50]
0000708296fdb499  vmovaps xmm6, [rsp+0x60]
0000708296fdb49f  vmovaps xmm7, [rsp+0x70]
0000708296fdb4a5  vmovaps xmm8, [rsp+0x80]
0000708296fdb4ae  vmovaps xmm9, [rsp+0x90]
0000708296fdb4b7  vmovaps xmm10, [rsp+0xA0]
0000708296fdb4c0  vmovaps xmm11, [rsp+0xB0]
0000708296fdb4c9  vmovaps xmm12, [rsp+0xC0]
0000708296fdb4d2  vmovaps xmm13, [rsp+0xD0]
0000708296fdb4db  vmovaps xmm14, [rsp+0xE0]
0000708296fdb4e4  add rsp, 0xF0
0000708296fdb4eb  pop r11
0000708296fdb4ed  pop r10
0000708296fdb4ef  pop r9
0000708296fdb4f1  pop r8
0000708296fdb4f3  pop rsi
0000708296fdb4f4  pop rdi
0000708296fdb4f5  pop rdx
0000708296fdb4f6  pop rcx
0000708296fdb4f7  pop rax
0000708296fdb4f8  add rsp, 0x08
0000708296fdb4fc  jmp 0x0000708296FD664A
0000708296fdb501  sub rsp, 0x08
0000708296fdb505  push rax
0000708296fdb506  push rcx
0000708296fdb507  push rdx
0000708296fdb508  push rdi
0000708296fdb509  push rsi
0000708296fdb50a  push r8
0000708296fdb50c  push r9
0000708296fdb50e  push r10
0000708296fdb510  push r11
0000708296fdb512  sub rsp, 0xF0
0000708296fdb519  vmovaps [rsp], xmm0
0000708296fdb51e  vmovaps [rsp+0x10], xmm1
0000708296fdb524  vmovaps [rsp+0x20], xmm2
0000708296fdb52a  vmovaps [rsp+0x30], xmm3
0000708296fdb530  vmovaps [rsp+0x40], xmm4
0000708296fdb536  vmovaps [rsp+0x50], xmm5
0000708296fdb53c  vmovaps [rsp+0x60], xmm6
0000708296fdb542  vmovaps [rsp+0x70], xmm7
0000708296fdb548  vmovaps [rsp+0x80], xmm8
0000708296fdb551  vmovaps [rsp+0x90], xmm9
0000708296fdb55a  vmovaps [rsp+0xA0], xmm10
0000708296fdb563  vmovaps [rsp+0xB0], xmm11
0000708296fdb56c  vmovaps [rsp+0xC0], xmm12
0000708296fdb575  vmovaps [rsp+0xD0], xmm14
0000708296fdb57e  vmovaps [rsp+0xE0], xmm15
0000708296fdb587  sub rsp, 0x30
0000708296fdb58b  movaps [rsp], xmm13
0000708296fdb590  movaps [rsp+0x10], xmm10
0000708296fdb596  movaps [rsp+0x20], xmm14
0000708296fdb59c  lea rdi, [rsp]
0000708296fdb5a0  mov esi, 0x00
0000708296fdb5a5  mov rax, 0x64BBC686C530
0000708296fdb5af  call rax
0000708296fdb5b1  movaps xmm13, [rsp]
0000708296fdb5b6  add rsp, 0x30
0000708296fdb5ba  vmovaps xmm0, [rsp]
0000708296fdb5bf  vmovaps xmm1, [rsp+0x10]
0000708296fdb5c5  vmovaps xmm2, [rsp+0x20]
0000708296fdb5cb  vmovaps xmm3, [rsp+0x30]
0000708296fdb5d1  vmovaps xmm4, [rsp+0x40]
0000708296fdb5d7  vmovaps xmm5, [rsp+0x50]
0000708296fdb5dd  vmovaps xmm6, [rsp+0x60]
0000708296fdb5e3  vmovaps xmm7, [rsp+0x70]
0000708296fdb5e9  vmovaps xmm8, [rsp+0x80]
0000708296fdb5f2  vmovaps xmm9, [rsp+0x90]
0000708296fdb5fb  vmovaps xmm10, [rsp+0xA0]
0000708296fdb604  vmovaps xmm11, [rsp+0xB0]
0000708296fdb60d  vmovaps xmm12, [rsp+0xC0]
0000708296fdb616  vmovaps xmm14, [rsp+0xD0]
0000708296fdb61f  vmovaps xmm15, [rsp+0xE0]
0000708296fdb628  add rsp, 0xF0
0000708296fdb62f  pop r11
0000708296fdb631  pop r10
0000708296fdb633  pop r9
0000708296fdb635  pop r8
0000708296fdb637  pop rsi
0000708296fdb638  pop rdi
0000708296fdb639  pop rdx
0000708296fdb63a  pop rcx
0000708296fdb63b  pop rax
0000708296fdb63c  add rsp, 0x08
0000708296fdb640  jmp 0x0000708296FD666D
0000708296fdb645  sub rsp, 0x08
0000708296fdb649  push rax
0000708296fdb64a  push rcx
0000708296fdb64b  push rdx
0000708296fdb64c  push rdi
0000708296fdb64d  push rsi
0000708296fdb64e  push r8
0000708296fdb650  push r9
0000708296fdb652  push r10
0000708296fdb654  push r11
0000708296fdb656  sub rsp, 0xF0
0000708296fdb65d  vmovaps [rsp], xmm0
0000708296fdb662  vmovaps [rsp+0x10], xmm1
0000708296fdb668  vmovaps [rsp+0x20], xmm2
0000708296fdb66e  vmovaps [rsp+0x30], xmm3
0000708296fdb674  vmovaps [rsp+0x40], xmm4
0000708296fdb67a  vmovaps [rsp+0x50], xmm5
0000708296fdb680  vmovaps [rsp+0x60], xmm6
0000708296fdb686  vmovaps [rsp+0x70], xmm7
0000708296fdb68c  vmovaps [rsp+0x80], xmm8
0000708296fdb695  vmovaps [rsp+0x90], xmm9
0000708296fdb69e  vmovaps [rsp+0xA0], xmm10
0000708296fdb6a7  vmovaps [rsp+0xB0], xmm11
0000708296fdb6b0  vmovaps [rsp+0xC0], xmm12
0000708296fdb6b9  vmovaps [rsp+0xD0], xmm13
0000708296fdb6c2  vmovaps [rsp+0xE0], xmm15
0000708296fdb6cb  sub rsp, 0x30
0000708296fdb6cf  movaps [rsp], xmm14
0000708296fdb6d4  movaps [rsp+0x10], xmm1
0000708296fdb6d9  movaps [rsp+0x20], xmm7
0000708296fdb6de  lea rdi, [rsp]
0000708296fdb6e2  mov esi, 0x00
0000708296fdb6e7  mov rax, 0x64BBC686C530
0000708296fdb6f1  call rax
0000708296fdb6f3  movaps xmm14, [rsp]
0000708296fdb6f8  add rsp, 0x30
0000708296fdb6fc  vmovaps xmm0, [rsp]
0000708296fdb701  vmovaps xmm1, [rsp+0x10]
0000708296fdb707  vmovaps xmm2, [rsp+0x20]
0000708296fdb70d  vmovaps xmm3, [rsp+0x30]
0000708296fdb713  vmovaps xmm4, [rsp+0x40]
0000708296fdb719  vmovaps xmm5, [rsp+0x50]
0000708296fdb71f  vmovaps xmm6, [rsp+0x60]
0000708296fdb725  vmovaps xmm7, [rsp+0x70]
0000708296fdb72b  vmovaps xmm8, [rsp+0x80]
0000708296fdb734  vmovaps xmm9, [rsp+0x90]
0000708296fdb73d  vmovaps xmm10, [rsp+0xA0]
0000708296fdb746  vmovaps xmm11, [rsp+0xB0]
0000708296fdb74f  vmovaps xmm12, [rsp+0xC0]
0000708296fdb758  vmovaps xmm13, [rsp+0xD0]
0000708296fdb761  vmovaps xmm15, [rsp+0xE0]
0000708296fdb76a  add rsp, 0xF0
0000708296fdb771  pop r11
0000708296fdb773  pop r10
0000708296fdb775  pop r9
0000708296fdb777  pop r8
0000708296fdb779  pop rsi
0000708296fdb77a  pop rdi
0000708296fdb77b  pop rdx
0000708296fdb77c  pop rcx
0000708296fdb77d  pop rax
0000708296fdb77e  add rsp, 0x08
0000708296fdb782  jmp 0x0000708296FD6690
0000708296fdb787  sub rsp, 0x08
0000708296fdb78b  push rax
0000708296fdb78c  push rcx
0000708296fdb78d  push rdx
0000708296fdb78e  push rdi
0000708296fdb78f  push rsi
0000708296fdb790  push r8
0000708296fdb792  push r9
0000708296fdb794  push r10
0000708296fdb796  push r11
0000708296fdb798  sub rsp, 0xF0
0000708296fdb79f  vmovaps [rsp], xmm0
0000708296fdb7a4  vmovaps [rsp+0x10], xmm2
0000708296fdb7aa  vmovaps [rsp+0x20], xmm3
0000708296fdb7b0  vmovaps [rsp+0x30], xmm4
0000708296fdb7b6  vmovaps [rsp+0x40], xmm5
0000708296fdb7bc  vmovaps [rsp+0x50], xmm6
0000708296fdb7c2  vmovaps [rsp+0x60], xmm7
0000708296fdb7c8  vmovaps [rsp+0x70], xmm8
0000708296fdb7ce  vmovaps [rsp+0x80], xmm9
0000708296fdb7d7  vmovaps [rsp+0x90], xmm10
0000708296fdb7e0  vmovaps [rsp+0xA0], xmm11
0000708296fdb7e9  vmovaps [rsp+0xB0], xmm12
0000708296fdb7f2  vmovaps [rsp+0xC0], xmm13
0000708296fdb7fb  vmovaps [rsp+0xD0], xmm14
0000708296fdb804  vmovaps [rsp+0xE0], xmm15
0000708296fdb80d  sub rsp, 0x30
0000708296fdb811  movaps [rsp], xmm1
0000708296fdb815  movaps [rsp+0x10], xmm8
0000708296fdb81b  movaps [rsp+0x20], xmm9
0000708296fdb821  lea rdi, [rsp]
0000708296fdb825  mov esi, 0x00
0000708296fdb82a  mov rax, 0x64BBC686C530
0000708296fdb834  call rax
0000708296fdb836  movaps xmm1, [rsp]
0000708296fdb83a  add rsp, 0x30
0000708296fdb83e  vmovaps xmm0, [rsp]
0000708296fdb843  vmovaps xmm2, [rsp+0x10]
0000708296fdb849  vmovaps xmm3, [rsp+0x20]
0000708296fdb84f  vmovaps xmm4, [rsp+0x30]
0000708296fdb855  vmovaps xmm5, [rsp+0x40]
0000708296fdb85b  vmovaps xmm6, [rsp+0x50]
0000708296fdb861  vmovaps xmm7, [rsp+0x60]
0000708296fdb867  vmovaps xmm8, [rsp+0x70]
0000708296fdb86d  vmovaps xmm9, [rsp+0x80]
0000708296fdb876  vmovaps xmm10, [rsp+0x90]
0000708296fdb87f  vmovaps xmm11, [rsp+0xA0]
0000708296fdb888  vmovaps xmm12, [rsp+0xB0]
0000708296fdb891  vmovaps xmm13, [rsp+0xC0]
0000708296fdb89a  vmovaps xmm14, [rsp+0xD0]
0000708296fdb8a3  vmovaps xmm15, [rsp+0xE0]
0000708296fdb8ac  add rsp, 0xF0
0000708296fdb8b3  pop r11
0000708296fdb8b5  pop r10
0000708296fdb8b7  pop r9
0000708296fdb8b9  pop r8
0000708296fdb8bb  pop rsi
0000708296fdb8bc  pop rdi
0000708296fdb8bd  pop rdx
0000708296fdb8be  pop rcx
0000708296fdb8bf  pop rax
0000708296fdb8c0  add rsp, 0x08
0000708296fdb8c4  jmp 0x0000708296FD66B2
0000708296fdb8c9  call 0x0000708296EB3E40
0000708296fdb8ce  jmp 0x0000708296FD66C0
0000708296fdb8d3  call 0x0000708296E0C380
0000708296fdb8d8  jmp 0x0000708296FD66CA
0000708296fdb8dd  call 0x0000708296E0D600
0000708296fdb8e2  jmp 0x0000708296FD66D4
0000708296fdb8e7  call 0x0000708296DFF540
0000708296fdb8ec  jmp 0x0000708296FD66DE
0000708296fdb8f1  int3
0000708296fdb8f2  nop [rax+rax*1], ax
0000708296fdb8fb  nop [rax+rax*1], eax
0000708296fdb900  mov eax, [r15+0x48]
0000708296fdb904  lea r14d, [eax+0x01]
0000708296fdb909  mov [rsp+0x10], r14d
0000708296fdb90e  mov r14d, r14d
0000708296fdb911  mov [r15+0x48], r14
0000708296fdb915  xor eax, eax
0000708296fdb917  mov r14d, [rsp+0x10]
0000708296fdb91c  cmp r14d, 0x1F4
0000708296fdb923  cmc
0000708296fdb924  lahf
0000708296fdb925  seto al
0000708296fdb928  mov [r15+0x108], eax
0000708296fdb92f  mov eax, [r15+0x108]
0000708296fdb936  sahf
0000708296fdb937  jnz 0x0000708296FDB969
0000708296fdb939  cmp dword ptr [r15+0x318], 0x00
0000708296fdb941  jz 0x0000708296FE1AB0
0000708296fdb947  nop [rax+rax*1], ax
0000708296fdb950  nop [rax+rax*1], eax
0000708296fdb958  mov eax, 0x410450
0000708296fdb95d  mov [r15+0x100], rax
0000708296fdb964  jmp 0x0000708296DFE110
0000708296fdb969  cmp dword ptr [r15+0x318], 0x00
0000708296fdb971  jz 0x0000708296FDB9A0
0000708296fdb977  nop [rax+rax*1], ax
0000708296fdb980  nop [rax+rax*1], eax
0000708296fdb988  mov eax, 0x410274
0000708296fdb98d  mov [r15+0x100], rax
0000708296fdb994  jmp 0x0000708296DFE110
0000708296fdb999  int3
0000708296fdb99a  int3
0000708296fdb99b  nop [rax+rax*1], eax
0000708296fdb9a0  mov rax, [r15+0x40]
0000708296fdb9a4  movaps xmm1, [r15+0x1D0]
0000708296fdb9ac  vmovaps [rsp+0x10], xmm1
0000708296fdb9b2  vmovaps xmm15, [rsp+0x10]
0000708296fdb9b8  por xmm1, xmm15
0000708296fdb9bd  movaps xmm14, [r15+0x1A0]
0000708296fdb9c5  vmovaps [rsp+0x10], xmm14
0000708296fdb9cb  vmovaps xmm13, [rsp+0x10]
0000708296fdb9d1  por xmm14, xmm13
0000708296fdb9d6  lea r14, [rax+0x30]
0000708296fdb9da  mov r12, [r13+r14*1]
0000708296fdb9df  lea r14, [rax+0x38]
0000708296fdb9e3  mov r11, [r13+r14*1]
0000708296fdb9e8  movq xmm13, r12
0000708296fdb9ed  movq xmm12, r11
0000708296fdb9f2  movq xmm13, xmm13
0000708296fdb9f7  vmovaps [rsp+0x10], xmm13
0000708296fdb9fd  movq xmm13, xmm13
0000708296fdba02  movaps [r15+0x130], xmm13
0000708296fdba0a  movq xmm12, xmm12
0000708296fdba0f  vmovaps [rsp+0x20], xmm12
0000708296fdba15  movq xmm12, xmm12
0000708296fdba1a  movaps [r15+0x280], xmm12
0000708296fdba22  movaps xmm13, [r15+0x270]
0000708296fdba2a  vmovaps [rsp+0x30], xmm13
0000708296fdba30  vmovaps xmm12, [rsp+0x30]
0000708296fdba36  por xmm13, xmm12
0000708296fdba3b  lea r14, [rax+0x20]
0000708296fdba3f  mov r12, [r13+r14*1]
0000708296fdba44  lea r14, [rax+0x28]
0000708296fdba48  mov r11, [r13+r14*1]
0000708296fdba4d  movq xmm12, r12
0000708296fdba52  movq xmm11, r11
0000708296fdba57  movq xmm12, xmm12
0000708296fdba5c  vmovaps [rsp+0x30], xmm12
0000708296fdba62  movq xmm12, xmm12
0000708296fdba67  movaps [r15+0x150], xmm12
0000708296fdba6f  movq xmm11, xmm11
0000708296fdba74  vmovaps [rsp+0x40], xmm11
0000708296fdba7a  movq xmm11, xmm11
0000708296fdba7f  movaps [r15+0x140], xmm11
0000708296fdba87  lea r14, [rax+0x10]
0000708296fdba8b  mov r12, [r13+r14*1]
0000708296fdba90  lea r14, [rax+0x18]
0000708296fdba94  mov r11, [r13+r14*1]
0000708296fdba99  movq xmm12, r12
0000708296fdba9e  movq xmm11, r11
0000708296fdbaa3  movq xmm12, xmm12
0000708296fdbaa8  vmovaps [rsp+0x50], xmm12
0000708296fdbaae  movq xmm12, xmm12
0000708296fdbab3  movaps [r15+0x170], xmm12
0000708296fdbabb  movq xmm11, xmm11
0000708296fdbac0  vmovaps [rsp+0x60], xmm11
0000708296fdbac6  movq xmm11, xmm11
0000708296fdbacb  movaps [r15+0x160], xmm11
0000708296fdbad3  mov r14, [r13+rax*1]
0000708296fdbad8  vmovq xmm12, r14
0000708296fdbadd  vpbroadcastq xmm12, xmm12
0000708296fdbae2  lea r14, [rax+0x08]
0000708296fdbae6  mov rax, [r13+r14*1]
0000708296fdbaeb  movq xmm11, rax
0000708296fdbaf0  movaps [r15+0x230], xmm11
0000708296fdbaf8  mov rax, [r15+0xF8]
0000708296fdbaff  lea r14, [rax+0x50]
0000708296fdbb03  movups xmm11, [r13+r14*1]
0000708296fdbb09  lea r14, [rax+0x60]
0000708296fdbb0d  movups xmm10, [r13+r14*1]
0000708296fdbb13  lea r14, [rax+0x30]
0000708296fdbb17  movups xmm9, [r13+r14*1]
0000708296fdbb1d  mov r14, [r15+0x50]
0000708296fdbb21  mov [r15+0x60], r14
0000708296fdbb25  mov qword ptr [r15+0x58], 0x40
0000708296fdbb2d  movaps xmm8, xmm12
0000708296fdbb31  mulpd xmm8, xmm15
0000708296fdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000708296fdbb3c  ptest xmm7, xmm7
0000708296fdbb41  jnz 0x0000708296FDC96A
0000708296fdbb47  movq xmm15, qword ptr [r15+0x230]
0000708296fdbb50  vmovaps [rsp+0x70], xmm15
0000708296fdbb56  vpermilpd xmm15, xmm15, 0x00
0000708296fdbb5c  movaps xmm7, xmm9
0000708296fdbb60  mulpd xmm7, xmm15
0000708296fdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000708296fdbb6a  ptest xmm6, xmm6
0000708296fdbb6f  jnz 0x0000708296FDCAAE
0000708296fdbb75  vxorps xmm15, xmm15, xmm15
0000708296fdbb7a  vpbroadcastq xmm15, xmm15
0000708296fdbb7f  movaps xmm9, xmm12
0000708296fdbb83  mulpd xmm9, xmm10
0000708296fdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000708296fdbb8e  ptest xmm6, xmm6
0000708296fdbb93  jnz 0x0000708296FDCBF0
0000708296fdbb99  movaps xmm10, xmm12
0000708296fdbb9d  mulpd xmm10, xmm11
0000708296fdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000708296fdbba8  ptest xmm6, xmm6
0000708296fdbbad  jnz 0x0000708296FDCD34
0000708296fdbbb3  movaps xmm11, [r15+0x1F0]
0000708296fdbbbb  movaps xmm6, xmm12
0000708296fdbbbf  mulpd xmm6, xmm11
0000708296fdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000708296fdbbc9  ptest xmm5, xmm5
0000708296fdbbce  jnz 0x0000708296FDCE78
0000708296fdbbd4  movaps xmm12, [r15+0x2A0]
0000708296fdbbdc  vmovaps [rsp+0x80], xmm12
0000708296fdbbe5  vmovaps xmm11, [rsp+0x80]
0000708296fdbbee  por xmm12, xmm11
0000708296fdbbf3  movaps xmm11, [r15+0x250]
0000708296fdbbfb  vmovaps [rsp+0x80], xmm11
0000708296fdbc04  vmovaps xmm5, [rsp+0x80]
0000708296fdbc0d  por xmm11, xmm5
0000708296fdbc12  vmovaps xmm4, [rsp+0x70]
0000708296fdbc18  vpermilpd xmm4, xmm4, 0x00
0000708296fdbc1e  movaps xmm3, xmm5
0000708296fdbc21  mulpd xmm3, xmm4
0000708296fdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000708296fdbc2a  ptest xmm2, xmm2
0000708296fdbc2f  jnz 0x0000708296FDCFBA
0000708296fdbc35  mov [rsp+0x80], rax
0000708296fdbc3d  xor eax, eax
0000708296fdbc3f  mov r12d, 0x40
0000708296fdbc45  mov r11d, 0x200
0000708296fdbc4b  cmp r12, r11
0000708296fdbc4e  cmc
0000708296fdbc4f  lahf
0000708296fdbc50  seto al
0000708296fdbc53  mov [r15+0x108], eax
0000708296fdbc5a  movaps xmm5, xmm8
0000708296fdbc5e  addpd xmm5, xmm15
0000708296fdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000708296fdbc68  ptest xmm4, xmm4
0000708296fdbc6d  jnz 0x0000708296FDD0FA
0000708296fdbc73  movaps xmm8, [r15+0x1B0]
0000708296fdbc7b  movaps xmm4, xmm9
0000708296fdbc7f  addpd xmm4, xmm8
0000708296fdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000708296fdbc89  ptest xmm2, xmm2
0000708296fdbc8e  jnz 0x0000708296FDD23C
0000708296fdbc94  movaps xmm9, xmm10
0000708296fdbc98  addpd xmm9, xmm8
0000708296fdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000708296fdbca3  ptest xmm2, xmm2
0000708296fdbca8  jnz 0x0000708296FDD37E
0000708296fdbcae  movaps xmm10, [r15+0x2F0]
0000708296fdbcb6  vmovaps [rsp+0x90], xmm10
0000708296fdbcbf  vmovaps xmm8, [rsp+0x90]
0000708296fdbcc8  por xmm10, xmm8
0000708296fdbccd  movaps xmm8, [r15+0x2E0]
0000708296fdbcd5  vmovaps [rsp+0x90], xmm8
0000708296fdbcde  vmovaps xmm2, [rsp+0x90]
0000708296fdbce7  por xmm8, xmm2
0000708296fdbcec  movaps xmm2, [r15+0x2D0]
0000708296fdbcf4  vmovaps [rsp+0x90], xmm2
0000708296fdbcfd  vmovaps [rsp+0xA0], xmm1
0000708296fdbd06  vmovaps xmm1, [rsp+0x90]
0000708296fdbd0f  por xmm2, xmm1
0000708296fdbd13  movaps xmm1, [r15+0x200]
0000708296fdbd1b  vmovaps [rsp+0x90], xmm1
0000708296fdbd24  vmovaps [rsp+0xB0], xmm15
0000708296fdbd2d  vmovaps xmm15, [rsp+0x90]
0000708296fdbd36  por xmm1, xmm15
0000708296fdbd3b  movaps xmm15, [r15+0x1C0]
0000708296fdbd43  vmovaps [rsp+0x90], xmm15
0000708296fdbd4c  vmovaps [rsp+0xC0], xmm1
0000708296fdbd55  vmovaps xmm1, [rsp+0x90]
0000708296fdbd5e  por xmm15, xmm1
0000708296fdbd63  movaps xmm1, [r15+0x190]
0000708296fdbd6b  vmovaps [rsp+0x90], xmm1
0000708296fdbd74  vmovaps [rsp+0xD0], xmm15
0000708296fdbd7d  vmovaps xmm15, [rsp+0x90]
0000708296fdbd86  por xmm1, xmm15
0000708296fdbd8b  movaps xmm15, [r15+0x300]
0000708296fdbd93  vmovaps [rsp+0x90], xmm15
0000708296fdbd9c  vmovaps [rsp+0xE0], xmm1
0000708296fdbda5  vmovaps xmm1, [rsp+0x90]
0000708296fdbdae  por xmm15, xmm1
0000708296fdbdb3  mov rax, [rsp+0x80]
0000708296fdbdbb  lea r12, [rax+0xA0]
0000708296fdbdc2  movups xmm1, [r13+r12*1]
0000708296fdbdc8  lea r12, [rax+0xB0]
0000708296fdbdcf  vmovaps [rsp+0x80], xmm1
0000708296fdbdd8  movups xmm1, [r13+r12*1]
0000708296fdbdde  vmovaps [rsp+0x90], xmm1
0000708296fdbde7  vmovaps [rsp+0xF0], xmm15
0000708296fdbdf0  vmovaps xmm15, [rsp+0xB0]
0000708296fdbdf9  vmovaps [rsp+0xB0], xmm14
0000708296fdbe02  movaps xmm1, xmm6
0000708296fdbe05  addpd xmm1, xmm15
0000708296fdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000708296fdbe0f  ptest xmm14, xmm14
0000708296fdbe15  jnz 0x0000708296FDD4D6
0000708296fdbe1b  lea r12, [rax+0xF0]
0000708296fdbe22  movups xmm15, [r13+r12*1]
0000708296fdbe28  movaps xmm14, xmm4
0000708296fdbe2c  addpd xmm14, xmm3
0000708296fdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000708296fdbe37  ptest xmm6, xmm6
0000708296fdbe3c  jnz 0x0000708296FDD621
0000708296fdbe42  movaps xmm6, xmm9
0000708296fdbe46  addpd xmm6, xmm7
0000708296fdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000708296fdbe4f  ptest xmm4, xmm4
0000708296fdbe54  jnz 0x0000708296FDD763
0000708296fdbe5a  vmovaps xmm9, [rsp+0x70]
0000708296fdbe60  vpermilpd xmm9, xmm9, 0x00
0000708296fdbe66  vmovaps xmm4, [rsp+0x90]
0000708296fdbe6f  movaps xmm7, xmm4
0000708296fdbe72  mulpd xmm7, xmm9
0000708296fdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000708296fdbe7c  ptest xmm3, xmm3
0000708296fdbe81  jnz 0x0000708296FDD8A4
0000708296fdbe87  vmovaps xmm9, [rsp+0x50]
0000708296fdbe8d  vpermilpd xmm9, xmm9, 0x00
0000708296fdbe93  movaps xmm4, xmm15
0000708296fdbe97  mulpd xmm4, xmm9
0000708296fdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000708296fdbea1  ptest xmm3, xmm3
0000708296fdbea6  jnz 0x0000708296FDD9E5
0000708296fdbeac  lea r12, [rax+0xE0]
0000708296fdbeb3  movups xmm15, [r13+r12*1]
0000708296fdbeb9  vmovaps xmm9, [rsp+0x70]
0000708296fdbebf  vpermilpd xmm9, xmm9, 0x00
0000708296fdbec5  vmovaps [rsp+0x70], xmm1
0000708296fdbecb  vmovaps xmm1, [rsp+0x80]
0000708296fdbed4  vmovaps [rsp+0x80], xmm15
0000708296fdbedd  movaps xmm3, xmm1
0000708296fdbee0  mulpd xmm3, xmm9
0000708296fdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000708296fdbeea  ptest xmm15, xmm15
0000708296fdbef0  jnz 0x0000708296FDDB31
0000708296fdbef6  vmovaps xmm1, [rsp+0xF0]
0000708296fdbeff  vmovaps xmm15, [rsp+0xF0]
0000708296fdbf08  por xmm1, xmm15
0000708296fdbf0d  movaps [r15+0x300], xmm1
0000708296fdbf15  vmovaps xmm15, [rsp+0xE0]
0000708296fdbf1e  vmovaps xmm9, [rsp+0xE0]
0000708296fdbf27  por xmm15, xmm9
0000708296fdbf2c  movaps [r15+0x190], xmm15
0000708296fdbf34  vmovaps xmm9, [rsp+0x50]
0000708296fdbf3a  vpermilpd xmm9, xmm9, 0x00
0000708296fdbf40  vmovaps [rsp+0x90], xmm1
0000708296fdbf49  vmovaps [rsp+0xE0], xmm15
0000708296fdbf52  vmovaps xmm15, [rsp+0x80]
0000708296fdbf5b  vmovaps [rsp+0x80], xmm14
0000708296fdbf64  movaps xmm1, xmm15
0000708296fdbf68  mulpd xmm1, xmm9
0000708296fdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000708296fdbf72  ptest xmm14, xmm14
0000708296fdbf78  jnz 0x0000708296FDDC72
0000708296fdbf7e  lea r12, [rax+0x90]
0000708296fdbf85  movups xmm15, [r13+r12*1]
0000708296fdbf8b  vmovaps xmm14, [rsp+0xD0]
0000708296fdbf94  vmovaps xmm9, [rsp+0xD0]
0000708296fdbf9d  por xmm14, xmm9
0000708296fdbfa2  movaps [r15+0x1C0], xmm14
0000708296fdbfaa  vmovaps xmm9, [rsp+0xC0]
0000708296fdbfb3  vmovaps [rsp+0xD0], xmm1
0000708296fdbfbc  vmovaps xmm1, [rsp+0xC0]
0000708296fdbfc5  por xmm9, xmm1
0000708296fdbfca  movaps [r15+0x200], xmm9
0000708296fdbfd2  vmovaps [rsp+0xC0], xmm2
0000708296fdbfdb  vmovaps xmm1, [rsp+0xC0]
0000708296fdbfe4  por xmm2, xmm1
0000708296fdbfe8  movaps [r15+0x2D0], xmm2
0000708296fdbff0  vmovaps [rsp+0xC0], xmm8
0000708296fdbff9  vmovaps xmm1, [rsp+0xC0]
0000708296fdc002  por xmm8, xmm1
0000708296fdc007  movaps [r15+0x2E0], xmm8
0000708296fdc00f  vmovaps [rsp+0xC0], xmm15
0000708296fdc018  movaps xmm1, xmm5
0000708296fdc01b  addpd xmm1, xmm7
0000708296fdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000708296fdc024  ptest xmm15, xmm15
0000708296fdc02a  jnz 0x0000708296FDDDBE
0000708296fdc030  vmovaps xmm15, [rsp+0x50]
0000708296fdc036  vpermilpd xmm15, xmm15, 0x00
0000708296fdc03c  vmovaps xmm5, [rsp+0xC0]
0000708296fdc045  vmovaps [rsp+0xC0], xmm1
0000708296fdc04e  movaps xmm7, xmm5
0000708296fdc051  mulpd xmm7, xmm15
0000708296fdc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000708296fdc05b  ptest xmm1, xmm1
0000708296fdc060  jnz 0x0000708296FDDEFE
0000708296fdc066  lea r12, [rax+0x80]
0000708296fdc06d  movups xmm1, [r13+r12*1]
0000708296fdc073  vmovaps xmm5, [rsp+0x70]
0000708296fdc079  vmovaps [rsp+0x70], xmm1
0000708296fdc07f  movaps xmm15, xmm5
0000708296fdc083  addpd xmm15, xmm3
0000708296fdc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000708296fdc08e  ptest xmm1, xmm1
0000708296fdc093  jnz 0x0000708296FDE049
0000708296fdc099  vmovaps xmm5, [rsp+0x80]
0000708296fdc0a2  movaps xmm1, xmm5
0000708296fdc0a5  addpd xmm1, xmm4
0000708296fdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000708296fdc0ae  ptest xmm3, xmm3
0000708296fdc0b3  jnz 0x0000708296FDE18B
0000708296fdc0b9  vmovaps [rsp+0x80], xmm10
0000708296fdc0c2  vmovaps xmm5, [rsp+0x80]
0000708296fdc0cb  por xmm10, xmm5
0000708296fdc0d0  movaps [r15+0x2F0], xmm10
0000708296fdc0d8  vmovaps xmm5, [rsp+0x50]
0000708296fdc0de  vpermilpd xmm5, xmm5, 0x00
0000708296fdc0e4  vmovaps xmm3, [rsp+0x70]
0000708296fdc0ea  vmovaps [rsp+0x50], xmm1
0000708296fdc0f0  movaps xmm4, xmm3
0000708296fdc0f3  mulpd xmm4, xmm5
0000708296fdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000708296fdc0fc  ptest xmm1, xmm1
0000708296fdc101  jnz 0x0000708296FDE2CB
0000708296fdc107  lea r12, [rax+0xD0]
0000708296fdc10e  movups xmm1, [r13+r12*1]
0000708296fdc114  vmovaps xmm3, [rsp+0xD0]
0000708296fdc11d  vmovaps [rsp+0x70], xmm1
0000708296fdc123  movaps xmm5, xmm6
0000708296fdc126  addpd xmm5, xmm3
0000708296fdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000708296fdc12f  ptest xmm1, xmm1
0000708296fdc134  jnz 0x0000708296FDE415
0000708296fdc13a  vmovaps xmm1, [rsp+0x60]
0000708296fdc140  vpermilpd xmm1, xmm1, 0x00
0000708296fdc146  movaps xmm6, xmm9
0000708296fdc14a  mulpd xmm6, xmm1
0000708296fdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000708296fdc153  ptest xmm3, xmm3
0000708296fdc158  jnz 0x0000708296FDE555
0000708296fdc15e  movaps [r15+0x260], xmm6
0000708296fdc166  vxorps xmm1, xmm1, xmm1
0000708296fdc16a  vpbroadcastq xmm1, xmm1
0000708296fdc16f  movaps [r15+0x1B0], xmm1
0000708296fdc177  vmovaps xmm1, [rsp+0x60]
0000708296fdc17d  vpermilpd xmm1, xmm1, 0x00
0000708296fdc183  vmovaps xmm3, [rsp+0x70]
0000708296fdc189  vmovaps [rsp+0x70], xmm15
0000708296fdc18f  movaps xmm9, xmm3
0000708296fdc193  mulpd xmm9, xmm1
0000708296fdc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000708296fdc19e  ptest xmm15, xmm15
0000708296fdc1a4  jnz 0x0000708296FDE696
0000708296fdc1aa  lea r12, [rax+0xC0]
0000708296fdc1b1  movups xmm1, [r13+r12*1]
0000708296fdc1b7  vmovaps xmm3, [rsp+0xC0]
0000708296fdc1c0  vmovaps [rsp+0x80], xmm1
0000708296fdc1c9  movaps xmm15, xmm3
0000708296fdc1cd  addpd xmm15, xmm7
0000708296fdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000708296fdc1d8  ptest xmm1, xmm1
0000708296fdc1dd  jnz 0x0000708296FDE7E2
0000708296fdc1e3  vmovaps [rsp+0xC0], xmm13
0000708296fdc1ec  vmovaps xmm1, [rsp+0xC0]
0000708296fdc1f5  por xmm13, xmm1
0000708296fdc1fa  movaps [r15+0x270], xmm13
0000708296fdc202  vmovaps xmm1, [rsp+0xB0]
0000708296fdc20b  vmovaps xmm7, [rsp+0xB0]
0000708296fdc214  por xmm1, xmm7
0000708296fdc218  movaps [r15+0x1A0], xmm1
0000708296fdc220  vmovaps xmm1, [rsp+0x60]
0000708296fdc226  vpermilpd xmm1, xmm1, 0x00
0000708296fdc22c  vmovaps [rsp+0xB0], xmm1
0000708296fdc235  vmovaps xmm1, [rsp+0x80]
0000708296fdc23e  vmovaps [rsp+0x80], xmm15
0000708296fdc247  vmovaps xmm15, [rsp+0xB0]
0000708296fdc250  vmovaps [rsp+0xB0], xmm14
0000708296fdc259  movaps xmm3, xmm1
0000708296fdc25c  mulpd xmm3, xmm15
0000708296fdc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000708296fdc266  ptest xmm14, xmm14
0000708296fdc26c  jnz 0x0000708296FDE924
0000708296fdc272  lea r12, [rax+0x20]
0000708296fdc276  movups xmm1, [r13+r12*1]
0000708296fdc27c  movaps [r15+0x110], xmm1
0000708296fdc284  vmovaps xmm14, [rsp+0x70]
0000708296fdc28a  vmovaps [rsp+0x70], xmm1
0000708296fdc290  movaps xmm15, xmm14
0000708296fdc294  addpd xmm15, xmm4
0000708296fdc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000708296fdc29f  ptest xmm1, xmm1
0000708296fdc2a4  jnz 0x0000708296FDEA6F
0000708296fdc2aa  vmovaps xmm1, [rsp+0x60]
0000708296fdc2b0  vpermilpd xmm1, xmm1, 0x00
0000708296fdc2b6  movaps xmm14, xmm2
0000708296fdc2ba  mulpd xmm14, xmm1
0000708296fdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000708296fdc2c5  ptest xmm4, xmm4
0000708296fdc2ca  jnz 0x0000708296FDEBB2
0000708296fdc2d0  vmovaps xmm4, [rsp+0x50]
0000708296fdc2d6  movaps xmm1, xmm4
0000708296fdc2d9  addpd xmm1, xmm9
0000708296fdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000708296fdc2e3  ptest xmm2, xmm2
0000708296fdc2e8  jnz 0x0000708296FDECF4
0000708296fdc2ee  vmovaps xmm9, [rsp+0x30]
0000708296fdc2f4  vpermilpd xmm9, xmm9, 0x00
0000708296fdc2fa  vmovaps xmm2, [rsp+0x70]
0000708296fdc300  vmovaps [rsp+0x50], xmm1
0000708296fdc306  movaps xmm4, xmm2
0000708296fdc309  mulpd xmm4, xmm9
0000708296fdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000708296fdc313  ptest xmm1, xmm1
0000708296fdc318  jnz 0x0000708296FDEE35
0000708296fdc31e  vmovaps xmm1, [rsp+0x30]
0000708296fdc324  vpermilpd xmm1, xmm1, 0x00
0000708296fdc32a  vmovaps xmm2, [rsp+0x90]
0000708296fdc333  vmovaps [rsp+0x60], xmm15
0000708296fdc339  movaps xmm9, xmm2
0000708296fdc33d  mulpd xmm9, xmm1
0000708296fdc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000708296fdc348  ptest xmm15, xmm15
0000708296fdc34e  jnz 0x0000708296FDEF76
0000708296fdc354  vmovaps xmm15, [rsp+0x80]
0000708296fdc35d  movaps xmm1, xmm15
0000708296fdc361  addpd xmm1, xmm6
0000708296fdc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000708296fdc36a  ptest xmm2, xmm2
0000708296fdc36f  jnz 0x0000708296FDF0B8
0000708296fdc375  movaps xmm15, xmm5
0000708296fdc379  addpd xmm15, xmm3
0000708296fdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000708296fdc384  ptest xmm6, xmm6
0000708296fdc389  jnz 0x0000708296FDF1F9
0000708296fdc38f  vmovaps xmm6, [rsp+0x30]
0000708296fdc395  vpermilpd xmm6, xmm6, 0x00
0000708296fdc39b  movaps xmm5, xmm8
0000708296fdc39f  mulpd xmm5, xmm6
0000708296fdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000708296fdc3a8  ptest xmm3, xmm3
0000708296fdc3ad  jnz 0x0000708296FDF33B
0000708296fdc3b3  vmovaps xmm8, [rsp+0x30]
0000708296fdc3b9  vpermilpd xmm8, xmm8, 0x00
0000708296fdc3bf  movaps xmm6, xmm10
0000708296fdc3c3  mulpd xmm6, xmm8
0000708296fdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000708296fdc3cd  ptest xmm3, xmm3
0000708296fdc3d2  jnz 0x0000708296FDF47C
0000708296fdc3d8  vmovaps xmm8, [rsp+0x60]
0000708296fdc3de  movaps xmm10, xmm8
0000708296fdc3e2  addpd xmm10, xmm14
0000708296fdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000708296fdc3ed  ptest xmm3, xmm3
0000708296fdc3f2  jnz 0x0000708296FDF5BE
0000708296fdc3f8  vmovaps xmm8, [rsp+0x50]
0000708296fdc3fe  movaps xmm14, xmm8
0000708296fdc402  addpd xmm14, xmm4
0000708296fdc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000708296fdc40d  ptest xmm3, xmm3
0000708296fdc412  jnz 0x0000708296FDF702
0000708296fdc418  vmovaps xmm8, [rsp+0x40]
0000708296fdc41e  vpermilpd xmm8, xmm8, 0x00
0000708296fdc424  movaps xmm4, xmm13
0000708296fdc428  mulpd xmm4, xmm8
0000708296fdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000708296fdc432  ptest xmm3, xmm3
0000708296fdc437  jnz 0x0000708296FDF845
0000708296fdc43d  movaps xmm13, xmm15
0000708296fdc441  addpd xmm13, xmm9
0000708296fdc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000708296fdc44c  ptest xmm8, xmm8
0000708296fdc452  jnz 0x0000708296FDF987
0000708296fdc458  movaps xmm15, xmm1
0000708296fdc45c  addpd xmm15, xmm5
0000708296fdc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000708296fdc467  ptest xmm9, xmm9
0000708296fdc46d  jnz 0x0000708296FDFACB
0000708296fdc473  vmovaps [rsp+0x30], xmm11
0000708296fdc479  vmovaps xmm1, [rsp+0x30]
0000708296fdc47f  por xmm11, xmm1
0000708296fdc484  movaps [r15+0x250], xmm11
0000708296fdc48c  vmovaps [rsp+0x30], xmm12
0000708296fdc492  vmovaps xmm1, [rsp+0x30]
0000708296fdc498  por xmm12, xmm1
0000708296fdc49d  movaps [r15+0x2A0], xmm12
0000708296fdc4a5  vmovaps xmm1, [rsp+0xA0]
0000708296fdc4ae  vmovaps xmm11, [rsp+0xA0]
0000708296fdc4b7  por xmm1, xmm11
0000708296fdc4bc  movaps [r15+0x1D0], xmm1
0000708296fdc4c4  lea r12, [rax+0x40]
0000708296fdc4c8  movups xmm1, [r13+r12*1]
0000708296fdc4ce  movaps [r15+0x2C0], xmm1
0000708296fdc4d6  vmovaps xmm11, [rsp+0x40]
0000708296fdc4dc  vpermilpd xmm11, xmm11, 0x00
0000708296fdc4e2  vmovaps xmm8, [rsp+0xE0]
0000708296fdc4eb  movaps xmm9, xmm8
0000708296fdc4ef  mulpd xmm9, xmm11
0000708296fdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000708296fdc4fa  ptest xmm5, xmm5
0000708296fdc4ff  jnz 0x0000708296FDFC17
0000708296fdc505  movaps xmm11, xmm10
0000708296fdc509  addpd xmm11, xmm6
0000708296fdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000708296fdc514  ptest xmm8, xmm8
0000708296fdc51a  jnz 0x0000708296FDFD5B
0000708296fdc520  movaps xmm10, xmm14
0000708296fdc524  addpd xmm10, xmm4
0000708296fdc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000708296fdc52f  ptest xmm8, xmm8
0000708296fdc535  jnz 0x0000708296FDFE9E
0000708296fdc53b  vmovaps xmm14, [rsp+0x40]
0000708296fdc541  vpermilpd xmm14, xmm14, 0x00
0000708296fdc547  movaps xmm8, xmm1
0000708296fdc54b  mulpd xmm8, xmm14
0000708296fdc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000708296fdc556  ptest xmm6, xmm6
0000708296fdc55b  jnz 0x0000708296FDFFE1
0000708296fdc561  movaps xmm1, [r15+0x2B0]
0000708296fdc569  vmovaps xmm14, [rsp+0x40]
0000708296fdc56f  vpermilpd xmm14, xmm14, 0x00
0000708296fdc575  movaps xmm6, xmm1
0000708296fdc578  mulpd xmm6, xmm14
0000708296fdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000708296fdc582  ptest xmm5, xmm5
0000708296fdc587  jnz 0x0000708296FE0124
0000708296fdc58d  vmovaps xmm1, [rsp+0x10]
0000708296fdc593  vpermilpd xmm1, xmm1, 0x00
0000708296fdc599  movaps xmm14, xmm12
0000708296fdc59d  mulpd xmm14, xmm1
0000708296fdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000708296fdc5a8  ptest xmm5, xmm5
0000708296fdc5ad  jnz 0x0000708296FE0265
0000708296fdc5b3  movaps xmm1, xmm13
0000708296fdc5b7  addpd xmm1, xmm9
0000708296fdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000708296fdc5c1  ptest xmm12, xmm12
0000708296fdc5c7  jnz 0x0000708296FE03A8
0000708296fdc5cd  vmovaps xmm13, [rsp+0x10]
0000708296fdc5d3  vpermilpd xmm13, xmm13, 0x00
0000708296fdc5d9  movaps xmm12, xmm7
0000708296fdc5dd  mulpd xmm12, xmm13
0000708296fdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000708296fdc5e8  ptest xmm9, xmm9
0000708296fdc5ee  jnz 0x0000708296FE04EA
0000708296fdc5f4  movaps xmm13, xmm15
0000708296fdc5f8  addpd xmm13, xmm8
0000708296fdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000708296fdc603  ptest xmm9, xmm9
0000708296fdc609  jnz 0x0000708296FE062D
0000708296fdc60f  movaps xmm15, [r15+0x290]
0000708296fdc617  vmovaps xmm9, [rsp+0x10]
0000708296fdc61d  vpermilpd xmm9, xmm9, 0x00
0000708296fdc623  movaps xmm8, xmm15
0000708296fdc627  mulpd xmm8, xmm9
0000708296fdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000708296fdc632  ptest xmm7, xmm7
0000708296fdc637  jnz 0x0000708296FE0771
0000708296fdc63d  movaps xmm15, xmm11
0000708296fdc641  addpd xmm15, xmm6
0000708296fdc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000708296fdc64c  ptest xmm9, xmm9
0000708296fdc652  jnz 0x0000708296FE08B5
0000708296fdc658  movaps xmm11, [r15+0x1E0]
0000708296fdc660  vmovaps xmm9, [rsp+0x10]
0000708296fdc666  vpermilpd xmm9, xmm9, 0x00
0000708296fdc66c  movaps xmm7, xmm11
0000708296fdc670  mulpd xmm7, xmm9
0000708296fdc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000708296fdc67a  ptest xmm6, xmm6
0000708296fdc67f  jnz 0x0000708296FE09F8
0000708296fdc685  movaps xmm11, xmm10
0000708296fdc689  addpd xmm11, xmm14
0000708296fdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000708296fdc694  ptest xmm9, xmm9
0000708296fdc69a  jnz 0x0000708296FE0B3A
0000708296fdc6a0  lea r12, [rax+0x70]
0000708296fdc6a4  movups xmm14, [r13+r12*1]
0000708296fdc6aa  movaps [r15+0x240], xmm14
0000708296fdc6b2  movaps xmm10, xmm1
0000708296fdc6b6  addpd xmm10, xmm12
0000708296fdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000708296fdc6c1  ptest xmm9, xmm9
0000708296fdc6c7  jnz 0x0000708296FE0C88
0000708296fdc6cd  movaps [r15+0x170], xmm10
0000708296fdc6d5  vmovaps xmm1, [rsp+0x20]
0000708296fdc6db  vpermilpd xmm1, xmm1, 0x00
0000708296fdc6e1  movaps xmm12, xmm14
0000708296fdc6e5  mulpd xmm12, xmm1
0000708296fdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000708296fdc6f0  ptest xmm9, xmm9
0000708296fdc6f6  jnz 0x0000708296FE0DCB
0000708296fdc6fc  vmovaps xmm1, [rsp+0x20]
0000708296fdc702  vpermilpd xmm1, xmm1, 0x00
0000708296fdc708  vmovaps xmm9, [rsp+0xB0]
0000708296fdc711  movaps xmm14, xmm9
0000708296fdc715  mulpd xmm14, xmm1
0000708296fdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000708296fdc720  ptest xmm6, xmm6
0000708296fdc725  jnz 0x0000708296FE0F0E
0000708296fdc72b  movaps [r15+0x180], xmm14
0000708296fdc733  movaps xmm1, xmm13
0000708296fdc737  addpd xmm1, xmm8
0000708296fdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000708296fdc741  ptest xmm9, xmm9
0000708296fdc747  jnz 0x0000708296FE1051
0000708296fdc74d  movaps [r15+0x210], xmm1
0000708296fdc755  movups xmm13, [r13+rax*1]
0000708296fdc75b  lea r12, [rax+0x10]
0000708296fdc75f  movups xmm9, [r13+r12*1]
0000708296fdc765  movaps [r15+0x230], xmm9
0000708296fdc76d  movaps xmm8, xmm15
0000708296fdc771  addpd xmm8, xmm7
0000708296fdc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000708296fdc77c  ptest xmm6, xmm6
0000708296fdc781  jnz 0x0000708296FE11A7
0000708296fdc787  movaps [r15+0x130], xmm8
0000708296fdc78f  vmovaps xmm15, [rsp+0x20]
0000708296fdc795  vpermilpd xmm15, xmm15, 0x00
0000708296fdc79b  movaps xmm7, xmm9
0000708296fdc79f  mulpd xmm7, xmm15
0000708296fdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000708296fdc7a9  ptest xmm6, xmm6
0000708296fdc7ae  jnz 0x0000708296FE12EA
0000708296fdc7b4  movaps [r15+0x220], xmm7
0000708296fdc7bc  vmovaps xmm15, [rsp+0x20]
0000708296fdc7c2  vpermilpd xmm15, xmm15, 0x00
0000708296fdc7c8  movaps xmm9, xmm13
0000708296fdc7cc  mulpd xmm9, xmm15
0000708296fdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000708296fdc7d7  ptest xmm6, xmm6
0000708296fdc7dc  jnz 0x0000708296FE142C
0000708296fdc7e2  movaps xmm15, xmm11
0000708296fdc7e6  addpd xmm15, xmm12
0000708296fdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000708296fdc7f1  ptest xmm13, xmm13
0000708296fdc7f7  jnz 0x0000708296FE1570
0000708296fdc7fd  movaps [r15+0x140], xmm15
0000708296fdc805  movaps xmm13, xmm10
0000708296fdc809  addpd xmm13, xmm14
0000708296fdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000708296fdc814  ptest xmm12, xmm12
0000708296fdc81a  jnz 0x0000708296FE16B4
0000708296fdc820  movaps [r15+0x150], xmm13
0000708296fdc828  movaps xmm14, xmm1
0000708296fdc82c  addpd xmm14, xmm7
0000708296fdc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000708296fdc837  ptest xmm12, xmm12
0000708296fdc83d  jnz 0x0000708296FE17F8
0000708296fdc843  movaps [r15+0x160], xmm14
0000708296fdc84b  movaps xmm1, xmm8
0000708296fdc84f  addpd xmm1, xmm9
0000708296fdc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000708296fdc859  ptest xmm12, xmm12
0000708296fdc85f  jnz 0x0000708296FE193A
0000708296fdc865  movaps [r15+0x120], xmm1
0000708296fdc86d  movups [r13+r14*1], xmm15
0000708296fdc873  lea rax, [r14+0x10]
0000708296fdc877  movups [r13+rax*1], xmm13
0000708296fdc87d  lea rax, [r14+0x20]
0000708296fdc881  movups [r13+rax*1], xmm14
0000708296fdc887  lea rax, [r14+0x30]
0000708296fdc88b  movups [r13+rax*1], xmm1
0000708296fdc891  mov eax, [r15+0x108]
0000708296fdc898  sahf
0000708296fdc899  jnz 0x0000708296FDC8CB
0000708296fdc89b  cmp dword ptr [r15+0x318], 0x00
0000708296fdc8a3  jz 0x0000708296FDB900
0000708296fdc8a9  nop [rax+rax*1], ax
0000708296fdc8b2  nop [rax+rax*1], eax
0000708296fdc8ba  mov eax, 0x410444
0000708296fdc8bf  mov [r15+0x100], rax
0000708296fdc8c6  jmp 0x0000708296DFE110
0000708296fdc8cb  cmp dword ptr [r15+0x318], 0x00
0000708296fdc8d3  jz 0x0000708296FD57E0
0000708296fdc8d9  nop [rax+rax*1], ax
0000708296fdc8e2  nop [rax+rax*1], eax
0000708296fdc8ea  mov eax, 0x410278
0000708296fdc8ef  mov [r15+0x100], rax
0000708296fdc8f6  jmp 0x0000708296DFE110
0000708296fdc8fb  int3
0000708296fdc8fc  call 0x0000708296EE27E0
0000708296fdc901  jmp 0x0000708296FDB9DF
0000708296fdc906  call 0x0000708296EE1570
0000708296fdc90b  jmp 0x0000708296FDB9E8
0000708296fdc910  call 0x0000708296EE27E0
0000708296fdc915  jmp 0x0000708296FDBA44
0000708296fdc91a  call 0x0000708296EE1570
0000708296fdc91f  jmp 0x0000708296FDBA4D
0000708296fdc924  call 0x0000708296EE27E0
0000708296fdc929  jmp 0x0000708296FDBA90
0000708296fdc92e  call 0x0000708296EE1570
0000708296fdc933  jmp 0x0000708296FDBA99
0000708296fdc938  call 0x0000708296E0DC20
0000708296fdc93d  jmp 0x0000708296FDBAD8
0000708296fdc942  call 0x0000708296ED59C0
0000708296fdc947  jmp 0x0000708296FDBAEB
0000708296fdc94c  call 0x0000708296EE0E30
0000708296fdc951  jmp 0x0000708296FDBB09
0000708296fdc956  call 0x0000708296EDFBC0
0000708296fdc95b  jmp 0x0000708296FDBB13
0000708296fdc960  call 0x0000708296EDE950
0000708296fdc965  jmp 0x0000708296FDBB1D
0000708296fdc96a  sub rsp, 0x08
0000708296fdc96e  push rax
0000708296fdc96f  push rcx
0000708296fdc970  push rdx
0000708296fdc971  push rdi
0000708296fdc972  push rsi
0000708296fdc973  push r8
0000708296fdc975  push r9
0000708296fdc977  push r10
0000708296fdc979  push r11
0000708296fdc97b  sub rsp, 0xF0
0000708296fdc982  vmovaps [rsp], xmm0
0000708296fdc987  vmovaps [rsp+0x10], xmm1
0000708296fdc98d  vmovaps [rsp+0x20], xmm2
0000708296fdc993  vmovaps [rsp+0x30], xmm3
0000708296fdc999  vmovaps [rsp+0x40], xmm4
0000708296fdc99f  vmovaps [rsp+0x50], xmm5
0000708296fdc9a5  vmovaps [rsp+0x60], xmm6
0000708296fdc9ab  vmovaps [rsp+0x70], xmm7
0000708296fdc9b1  vmovaps [rsp+0x80], xmm9
0000708296fdc9ba  vmovaps [rsp+0x90], xmm10
0000708296fdc9c3  vmovaps [rsp+0xA0], xmm11
0000708296fdc9cc  vmovaps [rsp+0xB0], xmm12
0000708296fdc9d5  vmovaps [rsp+0xC0], xmm13
0000708296fdc9de  vmovaps [rsp+0xD0], xmm14
0000708296fdc9e7  vmovaps [rsp+0xE0], xmm15
0000708296fdc9f0  sub rsp, 0x30
0000708296fdc9f4  movaps [rsp], xmm8
0000708296fdc9f9  movaps [rsp+0x10], xmm12
0000708296fdc9ff  movaps [rsp+0x20], xmm15
0000708296fdca05  lea rdi, [rsp]
0000708296fdca09  mov esi, 0x00
0000708296fdca0e  mov rax, 0x64BBC686C530
0000708296fdca18  call rax
0000708296fdca1a  movaps xmm8, [rsp]
0000708296fdca1f  add rsp, 0x30
0000708296fdca23  vmovaps xmm0, [rsp]
0000708296fdca28  vmovaps xmm1, [rsp+0x10]
0000708296fdca2e  vmovaps xmm2, [rsp+0x20]
0000708296fdca34  vmovaps xmm3, [rsp+0x30]
0000708296fdca3a  vmovaps xmm4, [rsp+0x40]
0000708296fdca40  vmovaps xmm5, [rsp+0x50]
0000708296fdca46  vmovaps xmm6, [rsp+0x60]
0000708296fdca4c  vmovaps xmm7, [rsp+0x70]
0000708296fdca52  vmovaps xmm9, [rsp+0x80]
0000708296fdca5b  vmovaps xmm10, [rsp+0x90]
0000708296fdca64  vmovaps xmm11, [rsp+0xA0]
0000708296fdca6d  vmovaps xmm12, [rsp+0xB0]
0000708296fdca76  vmovaps xmm13, [rsp+0xC0]
0000708296fdca7f  vmovaps xmm14, [rsp+0xD0]
0000708296fdca88  vmovaps xmm15, [rsp+0xE0]
0000708296fdca91  add rsp, 0xF0
0000708296fdca98  pop r11
0000708296fdca9a  pop r10
0000708296fdca9c  pop r9
0000708296fdca9e  pop r8
0000708296fdcaa0  pop rsi
0000708296fdcaa1  pop rdi
0000708296fdcaa2  pop rdx
0000708296fdcaa3  pop rcx
0000708296fdcaa4  pop rax
0000708296fdcaa5  add rsp, 0x08
0000708296fdcaa9  jmp 0x0000708296FDBB47
0000708296fdcaae  sub rsp, 0x08
0000708296fdcab2  push rax
0000708296fdcab3  push rcx
0000708296fdcab4  push rdx
0000708296fdcab5  push rdi
0000708296fdcab6  push rsi
0000708296fdcab7  push r8
0000708296fdcab9  push r9
0000708296fdcabb  push r10
0000708296fdcabd  push r11
0000708296fdcabf  sub rsp, 0xF0
0000708296fdcac6  vmovaps [rsp], xmm0
0000708296fdcacb  vmovaps [rsp+0x10], xmm1
0000708296fdcad1  vmovaps [rsp+0x20], xmm2
0000708296fdcad7  vmovaps [rsp+0x30], xmm3
0000708296fdcadd  vmovaps [rsp+0x40], xmm4
0000708296fdcae3  vmovaps [rsp+0x50], xmm5
0000708296fdcae9  vmovaps [rsp+0x60], xmm6
0000708296fdcaef  vmovaps [rsp+0x70], xmm8
0000708296fdcaf5  vmovaps [rsp+0x80], xmm9
0000708296fdcafe  vmovaps [rsp+0x90], xmm10
0000708296fdcb07  vmovaps [rsp+0xA0], xmm11
0000708296fdcb10  vmovaps [rsp+0xB0], xmm12
0000708296fdcb19  vmovaps [rsp+0xC0], xmm13
0000708296fdcb22  vmovaps [rsp+0xD0], xmm14
0000708296fdcb2b  vmovaps [rsp+0xE0], xmm15
0000708296fdcb34  sub rsp, 0x30
0000708296fdcb38  movaps [rsp], xmm7
0000708296fdcb3c  movaps [rsp+0x10], xmm9
0000708296fdcb42  movaps [rsp+0x20], xmm15
0000708296fdcb48  lea rdi, [rsp]
0000708296fdcb4c  mov esi, 0x00
0000708296fdcb51  mov rax, 0x64BBC686C530
0000708296fdcb5b  call rax
0000708296fdcb5d  movaps xmm7, [rsp]
0000708296fdcb61  add rsp, 0x30
0000708296fdcb65  vmovaps xmm0, [rsp]
0000708296fdcb6a  vmovaps xmm1, [rsp+0x10]
0000708296fdcb70  vmovaps xmm2, [rsp+0x20]
0000708296fdcb76  vmovaps xmm3, [rsp+0x30]
0000708296fdcb7c  vmovaps xmm4, [rsp+0x40]
0000708296fdcb82  vmovaps xmm5, [rsp+0x50]
0000708296fdcb88  vmovaps xmm6, [rsp+0x60]
0000708296fdcb8e  vmovaps xmm8, [rsp+0x70]
0000708296fdcb94  vmovaps xmm9, [rsp+0x80]
0000708296fdcb9d  vmovaps xmm10, [rsp+0x90]
0000708296fdcba6  vmovaps xmm11, [rsp+0xA0]
0000708296fdcbaf  vmovaps xmm12, [rsp+0xB0]
0000708296fdcbb8  vmovaps xmm13, [rsp+0xC0]
0000708296fdcbc1  vmovaps xmm14, [rsp+0xD0]
0000708296fdcbca  vmovaps xmm15, [rsp+0xE0]
0000708296fdcbd3  add rsp, 0xF0
0000708296fdcbda  pop r11
0000708296fdcbdc  pop r10
0000708296fdcbde  pop r9
0000708296fdcbe0  pop r8
0000708296fdcbe2  pop rsi
0000708296fdcbe3  pop rdi
0000708296fdcbe4  pop rdx
0000708296fdcbe5  pop rcx
0000708296fdcbe6  pop rax
0000708296fdcbe7  add rsp, 0x08
0000708296fdcbeb  jmp 0x0000708296FDBB75
0000708296fdcbf0  sub rsp, 0x08
0000708296fdcbf4  push rax
0000708296fdcbf5  push rcx
0000708296fdcbf6  push rdx
0000708296fdcbf7  push rdi
0000708296fdcbf8  push rsi
0000708296fdcbf9  push r8
0000708296fdcbfb  push r9
0000708296fdcbfd  push r10
0000708296fdcbff  push r11
0000708296fdcc01  sub rsp, 0xF0
0000708296fdcc08  vmovaps [rsp], xmm0
0000708296fdcc0d  vmovaps [rsp+0x10], xmm1
0000708296fdcc13  vmovaps [rsp+0x20], xmm2
0000708296fdcc19  vmovaps [rsp+0x30], xmm3
0000708296fdcc1f  vmovaps [rsp+0x40], xmm4
0000708296fdcc25  vmovaps [rsp+0x50], xmm5
0000708296fdcc2b  vmovaps [rsp+0x60], xmm6
0000708296fdcc31  vmovaps [rsp+0x70], xmm7
0000708296fdcc37  vmovaps [rsp+0x80], xmm8
0000708296fdcc40  vmovaps [rsp+0x90], xmm10
0000708296fdcc49  vmovaps [rsp+0xA0], xmm11
0000708296fdcc52  vmovaps [rsp+0xB0], xmm12
0000708296fdcc5b  vmovaps [rsp+0xC0], xmm13
0000708296fdcc64  vmovaps [rsp+0xD0], xmm14
0000708296fdcc6d  vmovaps [rsp+0xE0], xmm15
0000708296fdcc76  sub rsp, 0x30
0000708296fdcc7a  movaps [rsp], xmm9
0000708296fdcc7f  movaps [rsp+0x10], xmm12
0000708296fdcc85  movaps [rsp+0x20], xmm10
0000708296fdcc8b  lea rdi, [rsp]
0000708296fdcc8f  mov esi, 0x00
0000708296fdcc94  mov rax, 0x64BBC686C530
0000708296fdcc9e  call rax
0000708296fdcca0  movaps xmm9, [rsp]
0000708296fdcca5  add rsp, 0x30
0000708296fdcca9  vmovaps xmm0, [rsp]
0000708296fdccae  vmovaps xmm1, [rsp+0x10]
0000708296fdccb4  vmovaps xmm2, [rsp+0x20]
0000708296fdccba  vmovaps xmm3, [rsp+0x30]
0000708296fdccc0  vmovaps xmm4, [rsp+0x40]
0000708296fdccc6  vmovaps xmm5, [rsp+0x50]
0000708296fdcccc  vmovaps xmm6, [rsp+0x60]
0000708296fdccd2  vmovaps xmm7, [rsp+0x70]
0000708296fdccd8  vmovaps xmm8, [rsp+0x80]
0000708296fdcce1  vmovaps xmm10, [rsp+0x90]
0000708296fdccea  vmovaps xmm11, [rsp+0xA0]
0000708296fdccf3  vmovaps xmm12, [rsp+0xB0]
0000708296fdccfc  vmovaps xmm13, [rsp+0xC0]
0000708296fdcd05  vmovaps xmm14, [rsp+0xD0]
0000708296fdcd0e  vmovaps xmm15, [rsp+0xE0]
0000708296fdcd17  add rsp, 0xF0
0000708296fdcd1e  pop r11
0000708296fdcd20  pop r10
0000708296fdcd22  pop r9
0000708296fdcd24  pop r8
0000708296fdcd26  pop rsi
0000708296fdcd27  pop rdi
0000708296fdcd28  pop rdx
0000708296fdcd29  pop rcx
0000708296fdcd2a  pop rax
0000708296fdcd2b  add rsp, 0x08
0000708296fdcd2f  jmp 0x0000708296FDBB99
0000708296fdcd34  sub rsp, 0x08
0000708296fdcd38  push rax
0000708296fdcd39  push rcx
0000708296fdcd3a  push rdx
0000708296fdcd3b  push rdi
0000708296fdcd3c  push rsi
0000708296fdcd3d  push r8
0000708296fdcd3f  push r9
0000708296fdcd41  push r10
0000708296fdcd43  push r11
0000708296fdcd45  sub rsp, 0xF0
0000708296fdcd4c  vmovaps [rsp], xmm0
0000708296fdcd51  vmovaps [rsp+0x10], xmm1
0000708296fdcd57  vmovaps [rsp+0x20], xmm2
0000708296fdcd5d  vmovaps [rsp+0x30], xmm3
0000708296fdcd63  vmovaps [rsp+0x40], xmm4
0000708296fdcd69  vmovaps [rsp+0x50], xmm5
0000708296fdcd6f  vmovaps [rsp+0x60], xmm6
0000708296fdcd75  vmovaps [rsp+0x70], xmm7
0000708296fdcd7b  vmovaps [rsp+0x80], xmm8
0000708296fdcd84  vmovaps [rsp+0x90], xmm9
0000708296fdcd8d  vmovaps [rsp+0xA0], xmm11
0000708296fdcd96  vmovaps [rsp+0xB0], xmm12
0000708296fdcd9f  vmovaps [rsp+0xC0], xmm13
0000708296fdcda8  vmovaps [rsp+0xD0], xmm14
0000708296fdcdb1  vmovaps [rsp+0xE0], xmm15
0000708296fdcdba  sub rsp, 0x30
0000708296fdcdbe  movaps [rsp], xmm10
0000708296fdcdc3  movaps [rsp+0x10], xmm12
0000708296fdcdc9  movaps [rsp+0x20], xmm11
0000708296fdcdcf  lea rdi, [rsp]
0000708296fdcdd3  mov esi, 0x00
0000708296fdcdd8  mov rax, 0x64BBC686C530
0000708296fdcde2  call rax
0000708296fdcde4  movaps xmm10, [rsp]
0000708296fdcde9  add rsp, 0x30
0000708296fdcded  vmovaps xmm0, [rsp]
0000708296fdcdf2  vmovaps xmm1, [rsp+0x10]
0000708296fdcdf8  vmovaps xmm2, [rsp+0x20]
0000708296fdcdfe  vmovaps xmm3, [rsp+0x30]
0000708296fdce04  vmovaps xmm4, [rsp+0x40]
0000708296fdce0a  vmovaps xmm5, [rsp+0x50]
0000708296fdce10  vmovaps xmm6, [rsp+0x60]
0000708296fdce16  vmovaps xmm7, [rsp+0x70]
0000708296fdce1c  vmovaps xmm8, [rsp+0x80]
0000708296fdce25  vmovaps xmm9, [rsp+0x90]
0000708296fdce2e  vmovaps xmm11, [rsp+0xA0]
0000708296fdce37  vmovaps xmm12, [rsp+0xB0]
0000708296fdce40  vmovaps xmm13, [rsp+0xC0]
0000708296fdce49  vmovaps xmm14, [rsp+0xD0]
0000708296fdce52  vmovaps xmm15, [rsp+0xE0]
0000708296fdce5b  add rsp, 0xF0
0000708296fdce62  pop r11
0000708296fdce64  pop r10
0000708296fdce66  pop r9
0000708296fdce68  pop r8
0000708296fdce6a  pop rsi
0000708296fdce6b  pop rdi
0000708296fdce6c  pop rdx
0000708296fdce6d  pop rcx
0000708296fdce6e  pop rax
0000708296fdce6f  add rsp, 0x08
0000708296fdce73  jmp 0x0000708296FDBBB3
0000708296fdce78  sub rsp, 0x08
0000708296fdce7c  push rax
0000708296fdce7d  push rcx
0000708296fdce7e  push rdx
0000708296fdce7f  push rdi
0000708296fdce80  push rsi
0000708296fdce81  push r8
0000708296fdce83  push r9
0000708296fdce85  push r10
0000708296fdce87  push r11
0000708296fdce89  sub rsp, 0xF0
0000708296fdce90  vmovaps [rsp], xmm0
0000708296fdce95  vmovaps [rsp+0x10], xmm1
0000708296fdce9b  vmovaps [rsp+0x20], xmm2
0000708296fdcea1  vmovaps [rsp+0x30], xmm3
0000708296fdcea7  vmovaps [rsp+0x40], xmm4
0000708296fdcead  vmovaps [rsp+0x50], xmm5
0000708296fdceb3  vmovaps [rsp+0x60], xmm7
0000708296fdceb9  vmovaps [rsp+0x70], xmm8
0000708296fdcebf  vmovaps [rsp+0x80], xmm9
0000708296fdcec8  vmovaps [rsp+0x90], xmm10
0000708296fdced1  vmovaps [rsp+0xA0], xmm11
0000708296fdceda  vmovaps [rsp+0xB0], xmm12
0000708296fdcee3  vmovaps [rsp+0xC0], xmm13
0000708296fdceec  vmovaps [rsp+0xD0], xmm14
0000708296fdcef5  vmovaps [rsp+0xE0], xmm15
0000708296fdcefe  sub rsp, 0x30
0000708296fdcf02  movaps [rsp], xmm6
0000708296fdcf06  movaps [rsp+0x10], xmm12
0000708296fdcf0c  movaps [rsp+0x20], xmm11
0000708296fdcf12  lea rdi, [rsp]
0000708296fdcf16  mov esi, 0x00
0000708296fdcf1b  mov rax, 0x64BBC686C530
0000708296fdcf25  call rax
0000708296fdcf27  movaps xmm6, [rsp]
0000708296fdcf2b  add rsp, 0x30
0000708296fdcf2f  vmovaps xmm0, [rsp]
0000708296fdcf34  vmovaps xmm1, [rsp+0x10]
0000708296fdcf3a  vmovaps xmm2, [rsp+0x20]
0000708296fdcf40  vmovaps xmm3, [rsp+0x30]
0000708296fdcf46  vmovaps xmm4, [rsp+0x40]
0000708296fdcf4c  vmovaps xmm5, [rsp+0x50]
0000708296fdcf52  vmovaps xmm7, [rsp+0x60]
0000708296fdcf58  vmovaps xmm8, [rsp+0x70]
0000708296fdcf5e  vmovaps xmm9, [rsp+0x80]
0000708296fdcf67  vmovaps xmm10, [rsp+0x90]
0000708296fdcf70  vmovaps xmm11, [rsp+0xA0]
0000708296fdcf79  vmovaps xmm12, [rsp+0xB0]
0000708296fdcf82  vmovaps xmm13, [rsp+0xC0]
0000708296fdcf8b  vmovaps xmm14, [rsp+0xD0]
0000708296fdcf94  vmovaps xmm15, [rsp+0xE0]
0000708296fdcf9d  add rsp, 0xF0
0000708296fdcfa4  pop r11
0000708296fdcfa6  pop r10
0000708296fdcfa8  pop r9
0000708296fdcfaa  pop r8
0000708296fdcfac  pop rsi
0000708296fdcfad  pop rdi
0000708296fdcfae  pop rdx
0000708296fdcfaf  pop rcx
0000708296fdcfb0  pop rax
0000708296fdcfb1  add rsp, 0x08
0000708296fdcfb5  jmp 0x0000708296FDBBD4
0000708296fdcfba  sub rsp, 0x08
0000708296fdcfbe  push rax
0000708296fdcfbf  push rcx
0000708296fdcfc0  push rdx
0000708296fdcfc1  push rdi
0000708296fdcfc2  push rsi
0000708296fdcfc3  push r8
0000708296fdcfc5  push r9
0000708296fdcfc7  push r10
0000708296fdcfc9  push r11
0000708296fdcfcb  sub rsp, 0xF0
0000708296fdcfd2  vmovaps [rsp], xmm0
0000708296fdcfd7  vmovaps [rsp+0x10], xmm1
0000708296fdcfdd  vmovaps [rsp+0x20], xmm2
0000708296fdcfe3  vmovaps [rsp+0x30], xmm4
0000708296fdcfe9  vmovaps [rsp+0x40], xmm5
0000708296fdcfef  vmovaps [rsp+0x50], xmm6
0000708296fdcff5  vmovaps [rsp+0x60], xmm7
0000708296fdcffb  vmovaps [rsp+0x70], xmm8
0000708296fdd001  vmovaps [rsp+0x80], xmm9
0000708296fdd00a  vmovaps [rsp+0x90], xmm10
0000708296fdd013  vmovaps [rsp+0xA0], xmm11
0000708296fdd01c  vmovaps [rsp+0xB0], xmm12
0000708296fdd025  vmovaps [rsp+0xC0], xmm13
0000708296fdd02e  vmovaps [rsp+0xD0], xmm14
0000708296fdd037  vmovaps [rsp+0xE0], xmm15
0000708296fdd040  sub rsp, 0x30
0000708296fdd044  movaps [rsp], xmm3
0000708296fdd048  movaps [rsp+0x10], xmm5
0000708296fdd04d  movaps [rsp+0x20], xmm4
0000708296fdd052  lea rdi, [rsp]
0000708296fdd056  mov esi, 0x00
0000708296fdd05b  mov rax, 0x64BBC686C530
0000708296fdd065  call rax
0000708296fdd067  movaps xmm3, [rsp]
0000708296fdd06b  add rsp, 0x30
0000708296fdd06f  vmovaps xmm0, [rsp]
0000708296fdd074  vmovaps xmm1, [rsp+0x10]
0000708296fdd07a  vmovaps xmm2, [rsp+0x20]
0000708296fdd080  vmovaps xmm4, [rsp+0x30]
0000708296fdd086  vmovaps xmm5, [rsp+0x40]
0000708296fdd08c  vmovaps xmm6, [rsp+0x50]
0000708296fdd092  vmovaps xmm7, [rsp+0x60]
0000708296fdd098  vmovaps xmm8, [rsp+0x70]
0000708296fdd09e  vmovaps xmm9, [rsp+0x80]
0000708296fdd0a7  vmovaps xmm10, [rsp+0x90]
0000708296fdd0b0  vmovaps xmm11, [rsp+0xA0]
0000708296fdd0b9  vmovaps xmm12, [rsp+0xB0]
0000708296fdd0c2  vmovaps xmm13, [rsp+0xC0]
0000708296fdd0cb  vmovaps xmm14, [rsp+0xD0]
0000708296fdd0d4  vmovaps xmm15, [rsp+0xE0]
0000708296fdd0dd  add rsp, 0xF0
0000708296fdd0e4  pop r11
0000708296fdd0e6  pop r10
0000708296fdd0e8  pop r9
0000708296fdd0ea  pop r8
0000708296fdd0ec  pop rsi
0000708296fdd0ed  pop rdi
0000708296fdd0ee  pop rdx
0000708296fdd0ef  pop rcx
0000708296fdd0f0  pop rax
0000708296fdd0f1  add rsp, 0x08
0000708296fdd0f5  jmp 0x0000708296FDBC35
0000708296fdd0fa  sub rsp, 0x08
0000708296fdd0fe  push rax
0000708296fdd0ff  push rcx
0000708296fdd100  push rdx
0000708296fdd101  push rdi
0000708296fdd102  push rsi
0000708296fdd103  push r8
0000708296fdd105  push r9
0000708296fdd107  push r10
0000708296fdd109  push r11
0000708296fdd10b  sub rsp, 0xF0
0000708296fdd112  vmovaps [rsp], xmm0
0000708296fdd117  vmovaps [rsp+0x10], xmm1
0000708296fdd11d  vmovaps [rsp+0x20], xmm2
0000708296fdd123  vmovaps [rsp+0x30], xmm3
0000708296fdd129  vmovaps [rsp+0x40], xmm4
0000708296fdd12f  vmovaps [rsp+0x50], xmm6
0000708296fdd135  vmovaps [rsp+0x60], xmm7
0000708296fdd13b  vmovaps [rsp+0x70], xmm8
0000708296fdd141  vmovaps [rsp+0x80], xmm9
0000708296fdd14a  vmovaps [rsp+0x90], xmm10
0000708296fdd153  vmovaps [rsp+0xA0], xmm11
0000708296fdd15c  vmovaps [rsp+0xB0], xmm12
0000708296fdd165  vmovaps [rsp+0xC0], xmm13
0000708296fdd16e  vmovaps [rsp+0xD0], xmm14
0000708296fdd177  vmovaps [rsp+0xE0], xmm15
0000708296fdd180  sub rsp, 0x30
0000708296fdd184  movaps [rsp], xmm5
0000708296fdd188  movaps [rsp+0x10], xmm8
0000708296fdd18e  movaps [rsp+0x20], xmm15
0000708296fdd194  lea rdi, [rsp]
0000708296fdd198  mov esi, 0x00
0000708296fdd19d  mov rax, 0x64BBC686C530
0000708296fdd1a7  call rax
0000708296fdd1a9  movaps xmm5, [rsp]
0000708296fdd1ad  add rsp, 0x30
0000708296fdd1b1  vmovaps xmm0, [rsp]
0000708296fdd1b6  vmovaps xmm1, [rsp+0x10]
0000708296fdd1bc  vmovaps xmm2, [rsp+0x20]
0000708296fdd1c2  vmovaps xmm3, [rsp+0x30]
0000708296fdd1c8  vmovaps xmm4, [rsp+0x40]
0000708296fdd1ce  vmovaps xmm6, [rsp+0x50]
0000708296fdd1d4  vmovaps xmm7, [rsp+0x60]
0000708296fdd1da  vmovaps xmm8, [rsp+0x70]
0000708296fdd1e0  vmovaps xmm9, [rsp+0x80]
0000708296fdd1e9  vmovaps xmm10, [rsp+0x90]
0000708296fdd1f2  vmovaps xmm11, [rsp+0xA0]
0000708296fdd1fb  vmovaps xmm12, [rsp+0xB0]
0000708296fdd204  vmovaps xmm13, [rsp+0xC0]
0000708296fdd20d  vmovaps xmm14, [rsp+0xD0]
0000708296fdd216  vmovaps xmm15, [rsp+0xE0]
0000708296fdd21f  add rsp, 0xF0
0000708296fdd226  pop r11
0000708296fdd228  pop r10
0000708296fdd22a  pop r9
0000708296fdd22c  pop r8
0000708296fdd22e  pop rsi
0000708296fdd22f  pop rdi
0000708296fdd230  pop rdx
0000708296fdd231  pop rcx
0000708296fdd232  pop rax
0000708296fdd233  add rsp, 0x08
0000708296fdd237  jmp 0x0000708296FDBC73
0000708296fdd23c  sub rsp, 0x08
0000708296fdd240  push rax
0000708296fdd241  push rcx
0000708296fdd242  push rdx
0000708296fdd243  push rdi
0000708296fdd244  push rsi
0000708296fdd245  push r8
0000708296fdd247  push r9
0000708296fdd249  push r10
0000708296fdd24b  push r11
0000708296fdd24d  sub rsp, 0xF0
0000708296fdd254  vmovaps [rsp], xmm0
0000708296fdd259  vmovaps [rsp+0x10], xmm1
0000708296fdd25f  vmovaps [rsp+0x20], xmm2
0000708296fdd265  vmovaps [rsp+0x30], xmm3
0000708296fdd26b  vmovaps [rsp+0x40], xmm5
0000708296fdd271  vmovaps [rsp+0x50], xmm6
0000708296fdd277  vmovaps [rsp+0x60], xmm7
0000708296fdd27d  vmovaps [rsp+0x70], xmm8
0000708296fdd283  vmovaps [rsp+0x80], xmm9
0000708296fdd28c  vmovaps [rsp+0x90], xmm10
0000708296fdd295  vmovaps [rsp+0xA0], xmm11
0000708296fdd29e  vmovaps [rsp+0xB0], xmm12
0000708296fdd2a7  vmovaps [rsp+0xC0], xmm13
0000708296fdd2b0  vmovaps [rsp+0xD0], xmm14
0000708296fdd2b9  vmovaps [rsp+0xE0], xmm15
0000708296fdd2c2  sub rsp, 0x30
0000708296fdd2c6  movaps [rsp], xmm4
0000708296fdd2ca  movaps [rsp+0x10], xmm9
0000708296fdd2d0  movaps [rsp+0x20], xmm8
0000708296fdd2d6  lea rdi, [rsp]
0000708296fdd2da  mov esi, 0x00
0000708296fdd2df  mov rax, 0x64BBC686C530
0000708296fdd2e9  call rax
0000708296fdd2eb  movaps xmm4, [rsp]
0000708296fdd2ef  add rsp, 0x30
0000708296fdd2f3  vmovaps xmm0, [rsp]
0000708296fdd2f8  vmovaps xmm1, [rsp+0x10]
0000708296fdd2fe  vmovaps xmm2, [rsp+0x20]
0000708296fdd304  vmovaps xmm3, [rsp+0x30]
0000708296fdd30a  vmovaps xmm5, [rsp+0x40]
0000708296fdd310  vmovaps xmm6, [rsp+0x50]
0000708296fdd316  vmovaps xmm7, [rsp+0x60]
0000708296fdd31c  vmovaps xmm8, [rsp+0x70]
0000708296fdd322  vmovaps xmm9, [rsp+0x80]
0000708296fdd32b  vmovaps xmm10, [rsp+0x90]
0000708296fdd334  vmovaps xmm11, [rsp+0xA0]
0000708296fdd33d  vmovaps xmm12, [rsp+0xB0]
0000708296fdd346  vmovaps xmm13, [rsp+0xC0]
0000708296fdd34f  vmovaps xmm14, [rsp+0xD0]
0000708296fdd358  vmovaps xmm15, [rsp+0xE0]
0000708296fdd361  add rsp, 0xF0
0000708296fdd368  pop r11
0000708296fdd36a  pop r10
0000708296fdd36c  pop r9
0000708296fdd36e  pop r8
0000708296fdd370  pop rsi
0000708296fdd371  pop rdi
0000708296fdd372  pop rdx
0000708296fdd373  pop rcx
0000708296fdd374  pop rax
0000708296fdd375  add rsp, 0x08
0000708296fdd379  jmp 0x0000708296FDBC94
0000708296fdd37e  sub rsp, 0x08
0000708296fdd382  push rax
0000708296fdd383  push rcx
0000708296fdd384  push rdx
0000708296fdd385  push rdi
0000708296fdd386  push rsi
0000708296fdd387  push r8
0000708296fdd389  push r9
0000708296fdd38b  push r10
0000708296fdd38d  push r11
0000708296fdd38f  sub rsp, 0xF0
0000708296fdd396  vmovaps [rsp], xmm0
0000708296fdd39b  vmovaps [rsp+0x10], xmm1
0000708296fdd3a1  vmovaps [rsp+0x20], xmm2
0000708296fdd3a7  vmovaps [rsp+0x30], xmm3
0000708296fdd3ad  vmovaps [rsp+0x40], xmm4
0000708296fdd3b3  vmovaps [rsp+0x50], xmm5
0000708296fdd3b9  vmovaps [rsp+0x60], xmm6
0000708296fdd3bf  vmovaps [rsp+0x70], xmm7
0000708296fdd3c5  vmovaps [rsp+0x80], xmm8
0000708296fdd3ce  vmovaps [rsp+0x90], xmm10
0000708296fdd3d7  vmovaps [rsp+0xA0], xmm11
0000708296fdd3e0  vmovaps [rsp+0xB0], xmm12
0000708296fdd3e9  vmovaps [rsp+0xC0], xmm13
0000708296fdd3f2  vmovaps [rsp+0xD0], xmm14
0000708296fdd3fb  vmovaps [rsp+0xE0], xmm15
0000708296fdd404  sub rsp, 0x30
0000708296fdd408  movaps [rsp], xmm9
0000708296fdd40d  movaps [rsp+0x10], xmm10
0000708296fdd413  movaps [rsp+0x20], xmm8
0000708296fdd419  lea rdi, [rsp]
0000708296fdd41d  mov esi, 0x00
0000708296fdd422  mov rax, 0x64BBC686C530
0000708296fdd42c  call rax
0000708296fdd42e  movaps xmm9, [rsp]
0000708296fdd433  add rsp, 0x30
0000708296fdd437  vmovaps xmm0, [rsp]
0000708296fdd43c  vmovaps xmm1, [rsp+0x10]
0000708296fdd442  vmovaps xmm2, [rsp+0x20]
0000708296fdd448  vmovaps xmm3, [rsp+0x30]
0000708296fdd44e  vmovaps xmm4, [rsp+0x40]
0000708296fdd454  vmovaps xmm5, [rsp+0x50]
0000708296fdd45a  vmovaps xmm6, [rsp+0x60]
0000708296fdd460  vmovaps xmm7, [rsp+0x70]
0000708296fdd466  vmovaps xmm8, [rsp+0x80]
0000708296fdd46f  vmovaps xmm10, [rsp+0x90]
0000708296fdd478  vmovaps xmm11, [rsp+0xA0]
0000708296fdd481  vmovaps xmm12, [rsp+0xB0]
0000708296fdd48a  vmovaps xmm13, [rsp+0xC0]
0000708296fdd493  vmovaps xmm14, [rsp+0xD0]
0000708296fdd49c  vmovaps xmm15, [rsp+0xE0]
0000708296fdd4a5  add rsp, 0xF0
0000708296fdd4ac  pop r11
0000708296fdd4ae  pop r10
0000708296fdd4b0  pop r9
0000708296fdd4b2  pop r8
0000708296fdd4b4  pop rsi
0000708296fdd4b5  pop rdi
0000708296fdd4b6  pop rdx
0000708296fdd4b7  pop rcx
0000708296fdd4b8  pop rax
0000708296fdd4b9  add rsp, 0x08
0000708296fdd4bd  jmp 0x0000708296FDBCAE
0000708296fdd4c2  call 0x0000708296EB52F0
0000708296fdd4c7  jmp 0x0000708296FDBDC8
0000708296fdd4cc  call 0x0000708296EB52F0
0000708296fdd4d1  jmp 0x0000708296FDBDDE
0000708296fdd4d6  sub rsp, 0x08
0000708296fdd4da  push rax
0000708296fdd4db  push rcx
0000708296fdd4dc  push rdx
0000708296fdd4dd  push rdi
0000708296fdd4de  push rsi
0000708296fdd4df  push r8
0000708296fdd4e1  push r9
0000708296fdd4e3  push r10
0000708296fdd4e5  push r11
0000708296fdd4e7  sub rsp, 0xF0
0000708296fdd4ee  vmovaps [rsp], xmm0
0000708296fdd4f3  vmovaps [rsp+0x10], xmm2
0000708296fdd4f9  vmovaps [rsp+0x20], xmm3
0000708296fdd4ff  vmovaps [rsp+0x30], xmm4
0000708296fdd505  vmovaps [rsp+0x40], xmm5
0000708296fdd50b  vmovaps [rsp+0x50], xmm6
0000708296fdd511  vmovaps [rsp+0x60], xmm7
0000708296fdd517  vmovaps [rsp+0x70], xmm8
0000708296fdd51d  vmovaps [rsp+0x80], xmm9
0000708296fdd526  vmovaps [rsp+0x90], xmm10
0000708296fdd52f  vmovaps [rsp+0xA0], xmm11
0000708296fdd538  vmovaps [rsp+0xB0], xmm12
0000708296fdd541  vmovaps [rsp+0xC0], xmm13
0000708296fdd54a  vmovaps [rsp+0xD0], xmm14
0000708296fdd553  vmovaps [rsp+0xE0], xmm15
0000708296fdd55c  sub rsp, 0x30
0000708296fdd560  movaps [rsp], xmm1
0000708296fdd564  movaps [rsp+0x10], xmm6
0000708296fdd569  movaps [rsp+0x20], xmm15
0000708296fdd56f  lea rdi, [rsp]
0000708296fdd573  mov esi, 0x00
0000708296fdd578  mov rax, 0x64BBC686C530
0000708296fdd582  call rax
0000708296fdd584  movaps xmm1, [rsp]
0000708296fdd588  add rsp, 0x30
0000708296fdd58c  vmovaps xmm0, [rsp]
0000708296fdd591  vmovaps xmm2, [rsp+0x10]
0000708296fdd597  vmovaps xmm3, [rsp+0x20]
0000708296fdd59d  vmovaps xmm4, [rsp+0x30]
0000708296fdd5a3  vmovaps xmm5, [rsp+0x40]
0000708296fdd5a9  vmovaps xmm6, [rsp+0x50]
0000708296fdd5af  vmovaps xmm7, [rsp+0x60]
0000708296fdd5b5  vmovaps xmm8, [rsp+0x70]
0000708296fdd5bb  vmovaps xmm9, [rsp+0x80]
0000708296fdd5c4  vmovaps xmm10, [rsp+0x90]
0000708296fdd5cd  vmovaps xmm11, [rsp+0xA0]
0000708296fdd5d6  vmovaps xmm12, [rsp+0xB0]
0000708296fdd5df  vmovaps xmm13, [rsp+0xC0]
0000708296fdd5e8  vmovaps xmm14, [rsp+0xD0]
0000708296fdd5f1  vmovaps xmm15, [rsp+0xE0]
0000708296fdd5fa  add rsp, 0xF0
0000708296fdd601  pop r11
0000708296fdd603  pop r10
0000708296fdd605  pop r9
0000708296fdd607  pop r8
0000708296fdd609  pop rsi
0000708296fdd60a  pop rdi
0000708296fdd60b  pop rdx
0000708296fdd60c  pop rcx
0000708296fdd60d  pop rax
0000708296fdd60e  add rsp, 0x08
0000708296fdd612  jmp 0x0000708296FDBE1B
0000708296fdd617  call 0x0000708296EC4620
0000708296fdd61c  jmp 0x0000708296FDBE28
0000708296fdd621  sub rsp, 0x08
0000708296fdd625  push rax
0000708296fdd626  push rcx
0000708296fdd627  push rdx
0000708296fdd628  push rdi
0000708296fdd629  push rsi
0000708296fdd62a  push r8
0000708296fdd62c  push r9
0000708296fdd62e  push r10
0000708296fdd630  push r11
0000708296fdd632  sub rsp, 0xF0
0000708296fdd639  vmovaps [rsp], xmm0
0000708296fdd63e  vmovaps [rsp+0x10], xmm1
0000708296fdd644  vmovaps [rsp+0x20], xmm2
0000708296fdd64a  vmovaps [rsp+0x30], xmm3
0000708296fdd650  vmovaps [rsp+0x40], xmm4
0000708296fdd656  vmovaps [rsp+0x50], xmm5
0000708296fdd65c  vmovaps [rsp+0x60], xmm6
0000708296fdd662  vmovaps [rsp+0x70], xmm7
0000708296fdd668  vmovaps [rsp+0x80], xmm8
0000708296fdd671  vmovaps [rsp+0x90], xmm9
0000708296fdd67a  vmovaps [rsp+0xA0], xmm10
0000708296fdd683  vmovaps [rsp+0xB0], xmm11
0000708296fdd68c  vmovaps [rsp+0xC0], xmm12
0000708296fdd695  vmovaps [rsp+0xD0], xmm13
0000708296fdd69e  vmovaps [rsp+0xE0], xmm15
0000708296fdd6a7  sub rsp, 0x30
0000708296fdd6ab  movaps [rsp], xmm14
0000708296fdd6b0  movaps [rsp+0x10], xmm4
0000708296fdd6b5  movaps [rsp+0x20], xmm3
0000708296fdd6ba  lea rdi, [rsp]
0000708296fdd6be  mov esi, 0x00
0000708296fdd6c3  mov rax, 0x64BBC686C530
0000708296fdd6cd  call rax
0000708296fdd6cf  movaps xmm14, [rsp]
0000708296fdd6d4  add rsp, 0x30
0000708296fdd6d8  vmovaps xmm0, [rsp]
0000708296fdd6dd  vmovaps xmm1, [rsp+0x10]
0000708296fdd6e3  vmovaps xmm2, [rsp+0x20]
0000708296fdd6e9  vmovaps xmm3, [rsp+0x30]
0000708296fdd6ef  vmovaps xmm4, [rsp+0x40]
0000708296fdd6f5  vmovaps xmm5, [rsp+0x50]
0000708296fdd6fb  vmovaps xmm6, [rsp+0x60]
0000708296fdd701  vmovaps xmm7, [rsp+0x70]
0000708296fdd707  vmovaps xmm8, [rsp+0x80]
0000708296fdd710  vmovaps xmm9, [rsp+0x90]
0000708296fdd719  vmovaps xmm10, [rsp+0xA0]
0000708296fdd722  vmovaps xmm11, [rsp+0xB0]
0000708296fdd72b  vmovaps xmm12, [rsp+0xC0]
0000708296fdd734  vmovaps xmm13, [rsp+0xD0]
0000708296fdd73d  vmovaps xmm15, [rsp+0xE0]
0000708296fdd746  add rsp, 0xF0
0000708296fdd74d  pop r11
0000708296fdd74f  pop r10
0000708296fdd751  pop r9
0000708296fdd753  pop r8
0000708296fdd755  pop rsi
0000708296fdd756  pop rdi
0000708296fdd757  pop rdx
0000708296fdd758  pop rcx
0000708296fdd759  pop rax
0000708296fdd75a  add rsp, 0x08
0000708296fdd75e  jmp 0x0000708296FDBE42
0000708296fdd763  sub rsp, 0x08
0000708296fdd767  push rax
0000708296fdd768  push rcx
0000708296fdd769  push rdx
0000708296fdd76a  push rdi
0000708296fdd76b  push rsi
0000708296fdd76c  push r8
0000708296fdd76e  push r9
0000708296fdd770  push r10
0000708296fdd772  push r11
0000708296fdd774  sub rsp, 0xF0
0000708296fdd77b  vmovaps [rsp], xmm0
0000708296fdd780  vmovaps [rsp+0x10], xmm1
0000708296fdd786  vmovaps [rsp+0x20], xmm2
0000708296fdd78c  vmovaps [rsp+0x30], xmm3
0000708296fdd792  vmovaps [rsp+0x40], xmm4
0000708296fdd798  vmovaps [rsp+0x50], xmm5
0000708296fdd79e  vmovaps [rsp+0x60], xmm7
0000708296fdd7a4  vmovaps [rsp+0x70], xmm8
0000708296fdd7aa  vmovaps [rsp+0x80], xmm9
0000708296fdd7b3  vmovaps [rsp+0x90], xmm10
0000708296fdd7bc  vmovaps [rsp+0xA0], xmm11
0000708296fdd7c5  vmovaps [rsp+0xB0], xmm12
0000708296fdd7ce  vmovaps [rsp+0xC0], xmm13
0000708296fdd7d7  vmovaps [rsp+0xD0], xmm14
0000708296fdd7e0  vmovaps [rsp+0xE0], xmm15
0000708296fdd7e9  sub rsp, 0x30
0000708296fdd7ed  movaps [rsp], xmm6
0000708296fdd7f1  movaps [rsp+0x10], xmm9
0000708296fdd7f7  movaps [rsp+0x20], xmm7
0000708296fdd7fc  lea rdi, [rsp]
0000708296fdd800  mov esi, 0x00
0000708296fdd805  mov rax, 0x64BBC686C530
0000708296fdd80f  call rax
0000708296fdd811  movaps xmm6, [rsp]
0000708296fdd815  add rsp, 0x30
0000708296fdd819  vmovaps xmm0, [rsp]
0000708296fdd81e  vmovaps xmm1, [rsp+0x10]
0000708296fdd824  vmovaps xmm2, [rsp+0x20]
0000708296fdd82a  vmovaps xmm3, [rsp+0x30]
0000708296fdd830  vmovaps xmm4, [rsp+0x40]
0000708296fdd836  vmovaps xmm5, [rsp+0x50]
0000708296fdd83c  vmovaps xmm7, [rsp+0x60]
0000708296fdd842  vmovaps xmm8, [rsp+0x70]
0000708296fdd848  vmovaps xmm9, [rsp+0x80]
0000708296fdd851  vmovaps xmm10, [rsp+0x90]
0000708296fdd85a  vmovaps xmm11, [rsp+0xA0]
0000708296fdd863  vmovaps xmm12, [rsp+0xB0]
0000708296fdd86c  vmovaps xmm13, [rsp+0xC0]
0000708296fdd875  vmovaps xmm14, [rsp+0xD0]
0000708296fdd87e  vmovaps xmm15, [rsp+0xE0]
0000708296fdd887  add rsp, 0xF0
0000708296fdd88e  pop r11
0000708296fdd890  pop r10
0000708296fdd892  pop r9
0000708296fdd894  pop r8
0000708296fdd896  pop rsi
0000708296fdd897  pop rdi
0000708296fdd898  pop rdx
0000708296fdd899  pop rcx
0000708296fdd89a  pop rax
0000708296fdd89b  add rsp, 0x08
0000708296fdd89f  jmp 0x0000708296FDBE5A
0000708296fdd8a4  sub rsp, 0x08
0000708296fdd8a8  push rax
0000708296fdd8a9  push rcx
0000708296fdd8aa  push rdx
0000708296fdd8ab  push rdi
0000708296fdd8ac  push rsi
0000708296fdd8ad  push r8
0000708296fdd8af  push r9
0000708296fdd8b1  push r10
0000708296fdd8b3  push r11
0000708296fdd8b5  sub rsp, 0xF0
0000708296fdd8bc  vmovaps [rsp], xmm0
0000708296fdd8c1  vmovaps [rsp+0x10], xmm1
0000708296fdd8c7  vmovaps [rsp+0x20], xmm2
0000708296fdd8cd  vmovaps [rsp+0x30], xmm3
0000708296fdd8d3  vmovaps [rsp+0x40], xmm4
0000708296fdd8d9  vmovaps [rsp+0x50], xmm5
0000708296fdd8df  vmovaps [rsp+0x60], xmm6
0000708296fdd8e5  vmovaps [rsp+0x70], xmm8
0000708296fdd8eb  vmovaps [rsp+0x80], xmm9
0000708296fdd8f4  vmovaps [rsp+0x90], xmm10
0000708296fdd8fd  vmovaps [rsp+0xA0], xmm11
0000708296fdd906  vmovaps [rsp+0xB0], xmm12
0000708296fdd90f  vmovaps [rsp+0xC0], xmm13
0000708296fdd918  vmovaps [rsp+0xD0], xmm14
0000708296fdd921  vmovaps [rsp+0xE0], xmm15
0000708296fdd92a  sub rsp, 0x30
0000708296fdd92e  movaps [rsp], xmm7
0000708296fdd932  movaps [rsp+0x10], xmm4
0000708296fdd937  movaps [rsp+0x20], xmm9
0000708296fdd93d  lea rdi, [rsp]
0000708296fdd941  mov esi, 0x00
0000708296fdd946  mov rax, 0x64BBC686C530
0000708296fdd950  call rax
0000708296fdd952  movaps xmm7, [rsp]
0000708296fdd956  add rsp, 0x30
0000708296fdd95a  vmovaps xmm0, [rsp]
0000708296fdd95f  vmovaps xmm1, [rsp+0x10]
0000708296fdd965  vmovaps xmm2, [rsp+0x20]
0000708296fdd96b  vmovaps xmm3, [rsp+0x30]
0000708296fdd971  vmovaps xmm4, [rsp+0x40]
0000708296fdd977  vmovaps xmm5, [rsp+0x50]
0000708296fdd97d  vmovaps xmm6, [rsp+0x60]
0000708296fdd983  vmovaps xmm8, [rsp+0x70]
0000708296fdd989  vmovaps xmm9, [rsp+0x80]
0000708296fdd992  vmovaps xmm10, [rsp+0x90]
0000708296fdd99b  vmovaps xmm11, [rsp+0xA0]
0000708296fdd9a4  vmovaps xmm12, [rsp+0xB0]
0000708296fdd9ad  vmovaps xmm13, [rsp+0xC0]
0000708296fdd9b6  vmovaps xmm14, [rsp+0xD0]
0000708296fdd9bf  vmovaps xmm15, [rsp+0xE0]
0000708296fdd9c8  add rsp, 0xF0
0000708296fdd9cf  pop r11
0000708296fdd9d1  pop r10
0000708296fdd9d3  pop r9
0000708296fdd9d5  pop r8
0000708296fdd9d7  pop rsi
0000708296fdd9d8  pop rdi
0000708296fdd9d9  pop rdx
0000708296fdd9da  pop rcx
0000708296fdd9db  pop rax
0000708296fdd9dc  add rsp, 0x08
0000708296fdd9e0  jmp 0x0000708296FDBE87
0000708296fdd9e5  sub rsp, 0x08
0000708296fdd9e9  push rax
0000708296fdd9ea  push rcx
0000708296fdd9eb  push rdx
0000708296fdd9ec  push rdi
0000708296fdd9ed  push rsi
0000708296fdd9ee  push r8
0000708296fdd9f0  push r9
0000708296fdd9f2  push r10
0000708296fdd9f4  push r11
0000708296fdd9f6  sub rsp, 0xF0
0000708296fdd9fd  vmovaps [rsp], xmm0
0000708296fdda02  vmovaps [rsp+0x10], xmm1
0000708296fdda08  vmovaps [rsp+0x20], xmm2
0000708296fdda0e  vmovaps [rsp+0x30], xmm3
0000708296fdda14  vmovaps [rsp+0x40], xmm5
0000708296fdda1a  vmovaps [rsp+0x50], xmm6
0000708296fdda20  vmovaps [rsp+0x60], xmm7
0000708296fdda26  vmovaps [rsp+0x70], xmm8
0000708296fdda2c  vmovaps [rsp+0x80], xmm9
0000708296fdda35  vmovaps [rsp+0x90], xmm10
0000708296fdda3e  vmovaps [rsp+0xA0], xmm11
0000708296fdda47  vmovaps [rsp+0xB0], xmm12
0000708296fdda50  vmovaps [rsp+0xC0], xmm13
0000708296fdda59  vmovaps [rsp+0xD0], xmm14
0000708296fdda62  vmovaps [rsp+0xE0], xmm15
0000708296fdda6b  sub rsp, 0x30
0000708296fdda6f  movaps [rsp], xmm4
0000708296fdda73  movaps [rsp+0x10], xmm15
0000708296fdda79  movaps [rsp+0x20], xmm9
0000708296fdda7f  lea rdi, [rsp]
0000708296fdda83  mov esi, 0x00
0000708296fdda88  mov rax, 0x64BBC686C530
0000708296fdda92  call rax
0000708296fdda94  movaps xmm4, [rsp]
0000708296fdda98  add rsp, 0x30
0000708296fdda9c  vmovaps xmm0, [rsp]
0000708296fddaa1  vmovaps xmm1, [rsp+0x10]
0000708296fddaa7  vmovaps xmm2, [rsp+0x20]
0000708296fddaad  vmovaps xmm3, [rsp+0x30]
0000708296fddab3  vmovaps xmm5, [rsp+0x40]
0000708296fddab9  vmovaps xmm6, [rsp+0x50]
0000708296fddabf  vmovaps xmm7, [rsp+0x60]
0000708296fddac5  vmovaps xmm8, [rsp+0x70]
0000708296fddacb  vmovaps xmm9, [rsp+0x80]
0000708296fddad4  vmovaps xmm10, [rsp+0x90]
0000708296fddadd  vmovaps xmm11, [rsp+0xA0]
0000708296fddae6  vmovaps xmm12, [rsp+0xB0]
0000708296fddaef  vmovaps xmm13, [rsp+0xC0]
0000708296fddaf8  vmovaps xmm14, [rsp+0xD0]
0000708296fddb01  vmovaps xmm15, [rsp+0xE0]
0000708296fddb0a  add rsp, 0xF0
0000708296fddb11  pop r11
0000708296fddb13  pop r10
0000708296fddb15  pop r9
0000708296fddb17  pop r8
0000708296fddb19  pop rsi
0000708296fddb1a  pop rdi
0000708296fddb1b  pop rdx
0000708296fddb1c  pop rcx
0000708296fddb1d  pop rax
0000708296fddb1e  add rsp, 0x08
0000708296fddb22  jmp 0x0000708296FDBEAC
0000708296fddb27  call 0x0000708296EC4620
0000708296fddb2c  jmp 0x0000708296FDBEB9
0000708296fddb31  sub rsp, 0x08
0000708296fddb35  push rax
0000708296fddb36  push rcx
0000708296fddb37  push rdx
0000708296fddb38  push rdi
0000708296fddb39  push rsi
0000708296fddb3a  push r8
0000708296fddb3c  push r9
0000708296fddb3e  push r10
0000708296fddb40  push r11
0000708296fddb42  sub rsp, 0xF0
0000708296fddb49  vmovaps [rsp], xmm0
0000708296fddb4e  vmovaps [rsp+0x10], xmm1
0000708296fddb54  vmovaps [rsp+0x20], xmm2
0000708296fddb5a  vmovaps [rsp+0x30], xmm4
0000708296fddb60  vmovaps [rsp+0x40], xmm5
0000708296fddb66  vmovaps [rsp+0x50], xmm6
0000708296fddb6c  vmovaps [rsp+0x60], xmm7
0000708296fddb72  vmovaps [rsp+0x70], xmm8
0000708296fddb78  vmovaps [rsp+0x80], xmm9
0000708296fddb81  vmovaps [rsp+0x90], xmm10
0000708296fddb8a  vmovaps [rsp+0xA0], xmm11
0000708296fddb93  vmovaps [rsp+0xB0], xmm12
0000708296fddb9c  vmovaps [rsp+0xC0], xmm13
0000708296fddba5  vmovaps [rsp+0xD0], xmm14
0000708296fddbae  vmovaps [rsp+0xE0], xmm15
0000708296fddbb7  sub rsp, 0x30
0000708296fddbbb  movaps [rsp], xmm3
0000708296fddbbf  movaps [rsp+0x10], xmm1
0000708296fddbc4  movaps [rsp+0x20], xmm9
0000708296fddbca  lea rdi, [rsp]
0000708296fddbce  mov esi, 0x00
0000708296fddbd3  mov rax, 0x64BBC686C530
0000708296fddbdd  call rax
0000708296fddbdf  movaps xmm3, [rsp]
0000708296fddbe3  add rsp, 0x30
0000708296fddbe7  vmovaps xmm0, [rsp]
0000708296fddbec  vmovaps xmm1, [rsp+0x10]
0000708296fddbf2  vmovaps xmm2, [rsp+0x20]
0000708296fddbf8  vmovaps xmm4, [rsp+0x30]
0000708296fddbfe  vmovaps xmm5, [rsp+0x40]
0000708296fddc04  vmovaps xmm6, [rsp+0x50]
0000708296fddc0a  vmovaps xmm7, [rsp+0x60]
0000708296fddc10  vmovaps xmm8, [rsp+0x70]
0000708296fddc16  vmovaps xmm9, [rsp+0x80]
0000708296fddc1f  vmovaps xmm10, [rsp+0x90]
0000708296fddc28  vmovaps xmm11, [rsp+0xA0]
0000708296fddc31  vmovaps xmm12, [rsp+0xB0]
0000708296fddc3a  vmovaps xmm13, [rsp+0xC0]
0000708296fddc43  vmovaps xmm14, [rsp+0xD0]
0000708296fddc4c  vmovaps xmm15, [rsp+0xE0]
0000708296fddc55  add rsp, 0xF0
0000708296fddc5c  pop r11
0000708296fddc5e  pop r10
0000708296fddc60  pop r9
0000708296fddc62  pop r8
0000708296fddc64  pop rsi
0000708296fddc65  pop rdi
0000708296fddc66  pop rdx
0000708296fddc67  pop rcx
0000708296fddc68  pop rax
0000708296fddc69  add rsp, 0x08
0000708296fddc6d  jmp 0x0000708296FDBEF6
0000708296fddc72  sub rsp, 0x08
0000708296fddc76  push rax
0000708296fddc77  push rcx
0000708296fddc78  push rdx
0000708296fddc79  push rdi
0000708296fddc7a  push rsi
0000708296fddc7b  push r8
0000708296fddc7d  push r9
0000708296fddc7f  push r10
0000708296fddc81  push r11
0000708296fddc83  sub rsp, 0xF0
0000708296fddc8a  vmovaps [rsp], xmm0
0000708296fddc8f  vmovaps [rsp+0x10], xmm2
0000708296fddc95  vmovaps [rsp+0x20], xmm3
0000708296fddc9b  vmovaps [rsp+0x30], xmm4
0000708296fddca1  vmovaps [rsp+0x40], xmm5
0000708296fddca7  vmovaps [rsp+0x50], xmm6
0000708296fddcad  vmovaps [rsp+0x60], xmm7
0000708296fddcb3  vmovaps [rsp+0x70], xmm8
0000708296fddcb9  vmovaps [rsp+0x80], xmm9
0000708296fddcc2  vmovaps [rsp+0x90], xmm10
0000708296fddccb  vmovaps [rsp+0xA0], xmm11
0000708296fddcd4  vmovaps [rsp+0xB0], xmm12
0000708296fddcdd  vmovaps [rsp+0xC0], xmm13
0000708296fddce6  vmovaps [rsp+0xD0], xmm14
0000708296fddcef  vmovaps [rsp+0xE0], xmm15
0000708296fddcf8  sub rsp, 0x30
0000708296fddcfc  movaps [rsp], xmm1
0000708296fddd00  movaps [rsp+0x10], xmm15
0000708296fddd06  movaps [rsp+0x20], xmm9
0000708296fddd0c  lea rdi, [rsp]
0000708296fddd10  mov esi, 0x00
0000708296fddd15  mov rax, 0x64BBC686C530
0000708296fddd1f  call rax
0000708296fddd21  movaps xmm1, [rsp]
0000708296fddd25  add rsp, 0x30
0000708296fddd29  vmovaps xmm0, [rsp]
0000708296fddd2e  vmovaps xmm2, [rsp+0x10]
0000708296fddd34  vmovaps xmm3, [rsp+0x20]
0000708296fddd3a  vmovaps xmm4, [rsp+0x30]
0000708296fddd40  vmovaps xmm5, [rsp+0x40]
0000708296fddd46  vmovaps xmm6, [rsp+0x50]
0000708296fddd4c  vmovaps xmm7, [rsp+0x60]
0000708296fddd52  vmovaps xmm8, [rsp+0x70]
0000708296fddd58  vmovaps xmm9, [rsp+0x80]
0000708296fddd61  vmovaps xmm10, [rsp+0x90]
0000708296fddd6a  vmovaps xmm11, [rsp+0xA0]
0000708296fddd73  vmovaps xmm12, [rsp+0xB0]
0000708296fddd7c  vmovaps xmm13, [rsp+0xC0]
0000708296fddd85  vmovaps xmm14, [rsp+0xD0]
0000708296fddd8e  vmovaps xmm15, [rsp+0xE0]
0000708296fddd97  add rsp, 0xF0
0000708296fddd9e  pop r11
0000708296fddda0  pop r10
0000708296fddda2  pop r9
0000708296fddda4  pop r8
0000708296fddda6  pop rsi
0000708296fddda7  pop rdi
0000708296fddda8  pop rdx
0000708296fddda9  pop rcx
0000708296fdddaa  pop rax
0000708296fdddab  add rsp, 0x08
0000708296fdddaf  jmp 0x0000708296FDBF7E
0000708296fdddb4  call 0x0000708296EC4620
0000708296fdddb9  jmp 0x0000708296FDBF8B
0000708296fdddbe  sub rsp, 0x08
0000708296fdddc2  push rax
0000708296fdddc3  push rcx
0000708296fdddc4  push rdx
0000708296fdddc5  push rdi
0000708296fdddc6  push rsi
0000708296fdddc7  push r8
0000708296fdddc9  push r9
0000708296fdddcb  push r10
0000708296fdddcd  push r11
0000708296fdddcf  sub rsp, 0xF0
0000708296fdddd6  vmovaps [rsp], xmm0
0000708296fddddb  vmovaps [rsp+0x10], xmm2
0000708296fddde1  vmovaps [rsp+0x20], xmm3
0000708296fddde7  vmovaps [rsp+0x30], xmm4
0000708296fddded  vmovaps [rsp+0x40], xmm5
0000708296fdddf3  vmovaps [rsp+0x50], xmm6
0000708296fdddf9  vmovaps [rsp+0x60], xmm7
0000708296fdddff  vmovaps [rsp+0x70], xmm8
0000708296fdde05  vmovaps [rsp+0x80], xmm9
0000708296fdde0e  vmovaps [rsp+0x90], xmm10
0000708296fdde17  vmovaps [rsp+0xA0], xmm11
0000708296fdde20  vmovaps [rsp+0xB0], xmm12
0000708296fdde29  vmovaps [rsp+0xC0], xmm13
0000708296fdde32  vmovaps [rsp+0xD0], xmm14
0000708296fdde3b  vmovaps [rsp+0xE0], xmm15
0000708296fdde44  sub rsp, 0x30
0000708296fdde48  movaps [rsp], xmm1
0000708296fdde4c  movaps [rsp+0x10], xmm5
0000708296fdde51  movaps [rsp+0x20], xmm7
0000708296fdde56  lea rdi, [rsp]
0000708296fdde5a  mov esi, 0x00
0000708296fdde5f  mov rax, 0x64BBC686C530
0000708296fdde69  call rax
0000708296fdde6b  movaps xmm1, [rsp]
0000708296fdde6f  add rsp, 0x30
0000708296fdde73  vmovaps xmm0, [rsp]
0000708296fdde78  vmovaps xmm2, [rsp+0x10]
0000708296fdde7e  vmovaps xmm3, [rsp+0x20]
0000708296fdde84  vmovaps xmm4, [rsp+0x30]
0000708296fdde8a  vmovaps xmm5, [rsp+0x40]
0000708296fdde90  vmovaps xmm6, [rsp+0x50]
0000708296fdde96  vmovaps xmm7, [rsp+0x60]
0000708296fdde9c  vmovaps xmm8, [rsp+0x70]
0000708296fddea2  vmovaps xmm9, [rsp+0x80]
0000708296fddeab  vmovaps xmm10, [rsp+0x90]
0000708296fddeb4  vmovaps xmm11, [rsp+0xA0]
0000708296fddebd  vmovaps xmm12, [rsp+0xB0]
0000708296fddec6  vmovaps xmm13, [rsp+0xC0]
0000708296fddecf  vmovaps xmm14, [rsp+0xD0]
0000708296fdded8  vmovaps xmm15, [rsp+0xE0]
0000708296fddee1  add rsp, 0xF0
0000708296fddee8  pop r11
0000708296fddeea  pop r10
0000708296fddeec  pop r9
0000708296fddeee  pop r8
0000708296fddef0  pop rsi
0000708296fddef1  pop rdi
0000708296fddef2  pop rdx
0000708296fddef3  pop rcx
0000708296fddef4  pop rax
0000708296fddef5  add rsp, 0x08
0000708296fddef9  jmp 0x0000708296FDC030
0000708296fddefe  sub rsp, 0x08
0000708296fddf02  push rax
0000708296fddf03  push rcx
0000708296fddf04  push rdx
0000708296fddf05  push rdi
0000708296fddf06  push rsi
0000708296fddf07  push r8
0000708296fddf09  push r9
0000708296fddf0b  push r10
0000708296fddf0d  push r11
0000708296fddf0f  sub rsp, 0xF0
0000708296fddf16  vmovaps [rsp], xmm0
0000708296fddf1b  vmovaps [rsp+0x10], xmm1
0000708296fddf21  vmovaps [rsp+0x20], xmm2
0000708296fddf27  vmovaps [rsp+0x30], xmm3
0000708296fddf2d  vmovaps [rsp+0x40], xmm4
0000708296fddf33  vmovaps [rsp+0x50], xmm5
0000708296fddf39  vmovaps [rsp+0x60], xmm6
0000708296fddf3f  vmovaps [rsp+0x70], xmm8
0000708296fddf45  vmovaps [rsp+0x80], xmm9
0000708296fddf4e  vmovaps [rsp+0x90], xmm10
0000708296fddf57  vmovaps [rsp+0xA0], xmm11
0000708296fddf60  vmovaps [rsp+0xB0], xmm12
0000708296fddf69  vmovaps [rsp+0xC0], xmm13
0000708296fddf72  vmovaps [rsp+0xD0], xmm14
0000708296fddf7b  vmovaps [rsp+0xE0], xmm15
0000708296fddf84  sub rsp, 0x30
0000708296fddf88  movaps [rsp], xmm7
0000708296fddf8c  movaps [rsp+0x10], xmm5
0000708296fddf91  movaps [rsp+0x20], xmm15
0000708296fddf97  lea rdi, [rsp]
0000708296fddf9b  mov esi, 0x00
0000708296fddfa0  mov rax, 0x64BBC686C530
0000708296fddfaa  call rax
0000708296fddfac  movaps xmm7, [rsp]
0000708296fddfb0  add rsp, 0x30
0000708296fddfb4  vmovaps xmm0, [rsp]
0000708296fddfb9  vmovaps xmm1, [rsp+0x10]
0000708296fddfbf  vmovaps xmm2, [rsp+0x20]
0000708296fddfc5  vmovaps xmm3, [rsp+0x30]
0000708296fddfcb  vmovaps xmm4, [rsp+0x40]
0000708296fddfd1  vmovaps xmm5, [rsp+0x50]
0000708296fddfd7  vmovaps xmm6, [rsp+0x60]
0000708296fddfdd  vmovaps xmm8, [rsp+0x70]
0000708296fddfe3  vmovaps xmm9, [rsp+0x80]
0000708296fddfec  vmovaps xmm10, [rsp+0x90]
0000708296fddff5  vmovaps xmm11, [rsp+0xA0]
0000708296fddffe  vmovaps xmm12, [rsp+0xB0]
0000708296fde007  vmovaps xmm13, [rsp+0xC0]
0000708296fde010  vmovaps xmm14, [rsp+0xD0]
0000708296fde019  vmovaps xmm15, [rsp+0xE0]
0000708296fde022  add rsp, 0xF0
0000708296fde029  pop r11
0000708296fde02b  pop r10
0000708296fde02d  pop r9
0000708296fde02f  pop r8
0000708296fde031  pop rsi
0000708296fde032  pop rdi
0000708296fde033  pop rdx
0000708296fde034  pop rcx
0000708296fde035  pop rax
0000708296fde036  add rsp, 0x08
0000708296fde03a  jmp 0x0000708296FDC066
0000708296fde03f  call 0x0000708296EB52F0
0000708296fde044  jmp 0x0000708296FDC073
0000708296fde049  sub rsp, 0x08
0000708296fde04d  push rax
0000708296fde04e  push rcx
0000708296fde04f  push rdx
0000708296fde050  push rdi
0000708296fde051  push rsi
0000708296fde052  push r8
0000708296fde054  push r9
0000708296fde056  push r10
0000708296fde058  push r11
0000708296fde05a  sub rsp, 0xF0
0000708296fde061  vmovaps [rsp], xmm0
0000708296fde066  vmovaps [rsp+0x10], xmm1
0000708296fde06c  vmovaps [rsp+0x20], xmm2
0000708296fde072  vmovaps [rsp+0x30], xmm3
0000708296fde078  vmovaps [rsp+0x40], xmm4
0000708296fde07e  vmovaps [rsp+0x50], xmm5
0000708296fde084  vmovaps [rsp+0x60], xmm6
0000708296fde08a  vmovaps [rsp+0x70], xmm7
0000708296fde090  vmovaps [rsp+0x80], xmm8
0000708296fde099  vmovaps [rsp+0x90], xmm9
0000708296fde0a2  vmovaps [rsp+0xA0], xmm10
0000708296fde0ab  vmovaps [rsp+0xB0], xmm11
0000708296fde0b4  vmovaps [rsp+0xC0], xmm12
0000708296fde0bd  vmovaps [rsp+0xD0], xmm13
0000708296fde0c6  vmovaps [rsp+0xE0], xmm14
0000708296fde0cf  sub rsp, 0x30
0000708296fde0d3  movaps [rsp], xmm15
0000708296fde0d8  movaps [rsp+0x10], xmm5
0000708296fde0dd  movaps [rsp+0x20], xmm3
0000708296fde0e2  lea rdi, [rsp]
0000708296fde0e6  mov esi, 0x00
0000708296fde0eb  mov rax, 0x64BBC686C530
0000708296fde0f5  call rax
0000708296fde0f7  movaps xmm15, [rsp]
0000708296fde0fc  add rsp, 0x30
0000708296fde100  vmovaps xmm0, [rsp]
0000708296fde105  vmovaps xmm1, [rsp+0x10]
0000708296fde10b  vmovaps xmm2, [rsp+0x20]
0000708296fde111  vmovaps xmm3, [rsp+0x30]
0000708296fde117  vmovaps xmm4, [rsp+0x40]
0000708296fde11d  vmovaps xmm5, [rsp+0x50]
0000708296fde123  vmovaps xmm6, [rsp+0x60]
0000708296fde129  vmovaps xmm7, [rsp+0x70]
0000708296fde12f  vmovaps xmm8, [rsp+0x80]
0000708296fde138  vmovaps xmm9, [rsp+0x90]
0000708296fde141  vmovaps xmm10, [rsp+0xA0]
0000708296fde14a  vmovaps xmm11, [rsp+0xB0]
0000708296fde153  vmovaps xmm12, [rsp+0xC0]
0000708296fde15c  vmovaps xmm13, [rsp+0xD0]
0000708296fde165  vmovaps xmm14, [rsp+0xE0]
0000708296fde16e  add rsp, 0xF0
0000708296fde175  pop r11
0000708296fde177  pop r10
0000708296fde179  pop r9
0000708296fde17b  pop r8
0000708296fde17d  pop rsi
0000708296fde17e  pop rdi
0000708296fde17f  pop rdx
0000708296fde180  pop rcx
0000708296fde181  pop rax
0000708296fde182  add rsp, 0x08
0000708296fde186  jmp 0x0000708296FDC099
0000708296fde18b  sub rsp, 0x08
0000708296fde18f  push rax
0000708296fde190  push rcx
0000708296fde191  push rdx
0000708296fde192  push rdi
0000708296fde193  push rsi
0000708296fde194  push r8
0000708296fde196  push r9
0000708296fde198  push r10
0000708296fde19a  push r11
0000708296fde19c  sub rsp, 0xF0
0000708296fde1a3  vmovaps [rsp], xmm0
0000708296fde1a8  vmovaps [rsp+0x10], xmm2
0000708296fde1ae  vmovaps [rsp+0x20], xmm3
0000708296fde1b4  vmovaps [rsp+0x30], xmm4
0000708296fde1ba  vmovaps [rsp+0x40], xmm5
0000708296fde1c0  vmovaps [rsp+0x50], xmm6
0000708296fde1c6  vmovaps [rsp+0x60], xmm7
0000708296fde1cc  vmovaps [rsp+0x70], xmm8
0000708296fde1d2  vmovaps [rsp+0x80], xmm9
0000708296fde1db  vmovaps [rsp+0x90], xmm10
0000708296fde1e4  vmovaps [rsp+0xA0], xmm11
0000708296fde1ed  vmovaps [rsp+0xB0], xmm12
0000708296fde1f6  vmovaps [rsp+0xC0], xmm13
0000708296fde1ff  vmovaps [rsp+0xD0], xmm14
0000708296fde208  vmovaps [rsp+0xE0], xmm15
0000708296fde211  sub rsp, 0x30
0000708296fde215  movaps [rsp], xmm1
0000708296fde219  movaps [rsp+0x10], xmm5
0000708296fde21e  movaps [rsp+0x20], xmm4
0000708296fde223  lea rdi, [rsp]
0000708296fde227  mov esi, 0x00
0000708296fde22c  mov rax, 0x64BBC686C530
0000708296fde236  call rax
0000708296fde238  movaps xmm1, [rsp]
0000708296fde23c  add rsp, 0x30
0000708296fde240  vmovaps xmm0, [rsp]
0000708296fde245  vmovaps xmm2, [rsp+0x10]
0000708296fde24b  vmovaps xmm3, [rsp+0x20]
0000708296fde251  vmovaps xmm4, [rsp+0x30]
0000708296fde257  vmovaps xmm5, [rsp+0x40]
0000708296fde25d  vmovaps xmm6, [rsp+0x50]
0000708296fde263  vmovaps xmm7, [rsp+0x60]
0000708296fde269  vmovaps xmm8, [rsp+0x70]
0000708296fde26f  vmovaps xmm9, [rsp+0x80]
0000708296fde278  vmovaps xmm10, [rsp+0x90]
0000708296fde281  vmovaps xmm11, [rsp+0xA0]
0000708296fde28a  vmovaps xmm12, [rsp+0xB0]
0000708296fde293  vmovaps xmm13, [rsp+0xC0]
0000708296fde29c  vmovaps xmm14, [rsp+0xD0]
0000708296fde2a5  vmovaps xmm15, [rsp+0xE0]
0000708296fde2ae  add rsp, 0xF0
0000708296fde2b5  pop r11
0000708296fde2b7  pop r10
0000708296fde2b9  pop r9
0000708296fde2bb  pop r8
0000708296fde2bd  pop rsi
0000708296fde2be  pop rdi
0000708296fde2bf  pop rdx
0000708296fde2c0  pop rcx
0000708296fde2c1  pop rax
0000708296fde2c2  add rsp, 0x08
0000708296fde2c6  jmp 0x0000708296FDC0B9
0000708296fde2cb  sub rsp, 0x08
0000708296fde2cf  push rax
0000708296fde2d0  push rcx
0000708296fde2d1  push rdx
0000708296fde2d2  push rdi
0000708296fde2d3  push rsi
0000708296fde2d4  push r8
0000708296fde2d6  push r9
0000708296fde2d8  push r10
0000708296fde2da  push r11
0000708296fde2dc  sub rsp, 0xF0
0000708296fde2e3  vmovaps [rsp], xmm0
0000708296fde2e8  vmovaps [rsp+0x10], xmm1
0000708296fde2ee  vmovaps [rsp+0x20], xmm2
0000708296fde2f4  vmovaps [rsp+0x30], xmm3
0000708296fde2fa  vmovaps [rsp+0x40], xmm5
0000708296fde300  vmovaps [rsp+0x50], xmm6
0000708296fde306  vmovaps [rsp+0x60], xmm7
0000708296fde30c  vmovaps [rsp+0x70], xmm8
0000708296fde312  vmovaps [rsp+0x80], xmm9
0000708296fde31b  vmovaps [rsp+0x90], xmm10
0000708296fde324  vmovaps [rsp+0xA0], xmm11
0000708296fde32d  vmovaps [rsp+0xB0], xmm12
0000708296fde336  vmovaps [rsp+0xC0], xmm13
0000708296fde33f  vmovaps [rsp+0xD0], xmm14
0000708296fde348  vmovaps [rsp+0xE0], xmm15
0000708296fde351  sub rsp, 0x30
0000708296fde355  movaps [rsp], xmm4
0000708296fde359  movaps [rsp+0x10], xmm3
0000708296fde35e  movaps [rsp+0x20], xmm5
0000708296fde363  lea rdi, [rsp]
0000708296fde367  mov esi, 0x00
0000708296fde36c  mov rax, 0x64BBC686C530
0000708296fde376  call rax
0000708296fde378  movaps xmm4, [rsp]
0000708296fde37c  add rsp, 0x30
0000708296fde380  vmovaps xmm0, [rsp]
0000708296fde385  vmovaps xmm1, [rsp+0x10]
0000708296fde38b  vmovaps xmm2, [rsp+0x20]
0000708296fde391  vmovaps xmm3, [rsp+0x30]
0000708296fde397  vmovaps xmm5, [rsp+0x40]
0000708296fde39d  vmovaps xmm6, [rsp+0x50]
0000708296fde3a3  vmovaps xmm7, [rsp+0x60]
0000708296fde3a9  vmovaps xmm8, [rsp+0x70]
0000708296fde3af  vmovaps xmm9, [rsp+0x80]
0000708296fde3b8  vmovaps xmm10, [rsp+0x90]
0000708296fde3c1  vmovaps xmm11, [rsp+0xA0]
0000708296fde3ca  vmovaps xmm12, [rsp+0xB0]
0000708296fde3d3  vmovaps xmm13, [rsp+0xC0]
0000708296fde3dc  vmovaps xmm14, [rsp+0xD0]
0000708296fde3e5  vmovaps xmm15, [rsp+0xE0]
0000708296fde3ee  add rsp, 0xF0
0000708296fde3f5  pop r11
0000708296fde3f7  pop r10
0000708296fde3f9  pop r9
0000708296fde3fb  pop r8
0000708296fde3fd  pop rsi
0000708296fde3fe  pop rdi
0000708296fde3ff  pop rdx
0000708296fde400  pop rcx
0000708296fde401  pop rax
0000708296fde402  add rsp, 0x08
0000708296fde406  jmp 0x0000708296FDC107
0000708296fde40b  call 0x0000708296EB52F0
0000708296fde410  jmp 0x0000708296FDC114
0000708296fde415  sub rsp, 0x08
0000708296fde419  push rax
0000708296fde41a  push rcx
0000708296fde41b  push rdx
0000708296fde41c  push rdi
0000708296fde41d  push rsi
0000708296fde41e  push r8
0000708296fde420  push r9
0000708296fde422  push r10
0000708296fde424  push r11
0000708296fde426  sub rsp, 0xF0
0000708296fde42d  vmovaps [rsp], xmm0
0000708296fde432  vmovaps [rsp+0x10], xmm1
0000708296fde438  vmovaps [rsp+0x20], xmm2
0000708296fde43e  vmovaps [rsp+0x30], xmm3
0000708296fde444  vmovaps [rsp+0x40], xmm4
0000708296fde44a  vmovaps [rsp+0x50], xmm6
0000708296fde450  vmovaps [rsp+0x60], xmm7
0000708296fde456  vmovaps [rsp+0x70], xmm8
0000708296fde45c  vmovaps [rsp+0x80], xmm9
0000708296fde465  vmovaps [rsp+0x90], xmm10
0000708296fde46e  vmovaps [rsp+0xA0], xmm11
0000708296fde477  vmovaps [rsp+0xB0], xmm12
0000708296fde480  vmovaps [rsp+0xC0], xmm13
0000708296fde489  vmovaps [rsp+0xD0], xmm14
0000708296fde492  vmovaps [rsp+0xE0], xmm15
0000708296fde49b  sub rsp, 0x30
0000708296fde49f  movaps [rsp], xmm5
0000708296fde4a3  movaps [rsp+0x10], xmm6
0000708296fde4a8  movaps [rsp+0x20], xmm3
0000708296fde4ad  lea rdi, [rsp]
0000708296fde4b1  mov esi, 0x00
0000708296fde4b6  mov rax, 0x64BBC686C530
0000708296fde4c0  call rax
0000708296fde4c2  movaps xmm5, [rsp]
0000708296fde4c6  add rsp, 0x30
0000708296fde4ca  vmovaps xmm0, [rsp]
0000708296fde4cf  vmovaps xmm1, [rsp+0x10]
0000708296fde4d5  vmovaps xmm2, [rsp+0x20]
0000708296fde4db  vmovaps xmm3, [rsp+0x30]
0000708296fde4e1  vmovaps xmm4, [rsp+0x40]
0000708296fde4e7  vmovaps xmm6, [rsp+0x50]
0000708296fde4ed  vmovaps xmm7, [rsp+0x60]
0000708296fde4f3  vmovaps xmm8, [rsp+0x70]
0000708296fde4f9  vmovaps xmm9, [rsp+0x80]
0000708296fde502  vmovaps xmm10, [rsp+0x90]
0000708296fde50b  vmovaps xmm11, [rsp+0xA0]
0000708296fde514  vmovaps xmm12, [rsp+0xB0]
0000708296fde51d  vmovaps xmm13, [rsp+0xC0]
0000708296fde526  vmovaps xmm14, [rsp+0xD0]
0000708296fde52f  vmovaps xmm15, [rsp+0xE0]
0000708296fde538  add rsp, 0xF0
0000708296fde53f  pop r11
0000708296fde541  pop r10
0000708296fde543  pop r9
0000708296fde545  pop r8
0000708296fde547  pop rsi
0000708296fde548  pop rdi
0000708296fde549  pop rdx
0000708296fde54a  pop rcx
0000708296fde54b  pop rax
0000708296fde54c  add rsp, 0x08
0000708296fde550  jmp 0x0000708296FDC13A
0000708296fde555  sub rsp, 0x08
0000708296fde559  push rax
0000708296fde55a  push rcx
0000708296fde55b  push rdx
0000708296fde55c  push rdi
0000708296fde55d  push rsi
0000708296fde55e  push r8
0000708296fde560  push r9
0000708296fde562  push r10
0000708296fde564  push r11
0000708296fde566  sub rsp, 0xF0
0000708296fde56d  vmovaps [rsp], xmm0
0000708296fde572  vmovaps [rsp+0x10], xmm1
0000708296fde578  vmovaps [rsp+0x20], xmm2
0000708296fde57e  vmovaps [rsp+0x30], xmm3
0000708296fde584  vmovaps [rsp+0x40], xmm4
0000708296fde58a  vmovaps [rsp+0x50], xmm5
0000708296fde590  vmovaps [rsp+0x60], xmm7
0000708296fde596  vmovaps [rsp+0x70], xmm8
0000708296fde59c  vmovaps [rsp+0x80], xmm9
0000708296fde5a5  vmovaps [rsp+0x90], xmm10
0000708296fde5ae  vmovaps [rsp+0xA0], xmm11
0000708296fde5b7  vmovaps [rsp+0xB0], xmm12
0000708296fde5c0  vmovaps [rsp+0xC0], xmm13
0000708296fde5c9  vmovaps [rsp+0xD0], xmm14
0000708296fde5d2  vmovaps [rsp+0xE0], xmm15
0000708296fde5db  sub rsp, 0x30
0000708296fde5df  movaps [rsp], xmm6
0000708296fde5e3  movaps [rsp+0x10], xmm9
0000708296fde5e9  movaps [rsp+0x20], xmm1
0000708296fde5ee  lea rdi, [rsp]
0000708296fde5f2  mov esi, 0x00
0000708296fde5f7  mov rax, 0x64BBC686C530
0000708296fde601  call rax
0000708296fde603  movaps xmm6, [rsp]
0000708296fde607  add rsp, 0x30
0000708296fde60b  vmovaps xmm0, [rsp]
0000708296fde610  vmovaps xmm1, [rsp+0x10]
0000708296fde616  vmovaps xmm2, [rsp+0x20]
0000708296fde61c  vmovaps xmm3, [rsp+0x30]
0000708296fde622  vmovaps xmm4, [rsp+0x40]
0000708296fde628  vmovaps xmm5, [rsp+0x50]
0000708296fde62e  vmovaps xmm7, [rsp+0x60]
0000708296fde634  vmovaps xmm8, [rsp+0x70]
0000708296fde63a  vmovaps xmm9, [rsp+0x80]
0000708296fde643  vmovaps xmm10, [rsp+0x90]
0000708296fde64c  vmovaps xmm11, [rsp+0xA0]
0000708296fde655  vmovaps xmm12, [rsp+0xB0]
0000708296fde65e  vmovaps xmm13, [rsp+0xC0]
0000708296fde667  vmovaps xmm14, [rsp+0xD0]
0000708296fde670  vmovaps xmm15, [rsp+0xE0]
0000708296fde679  add rsp, 0xF0
0000708296fde680  pop r11
0000708296fde682  pop r10
0000708296fde684  pop r9
0000708296fde686  pop r8
0000708296fde688  pop rsi
0000708296fde689  pop rdi
0000708296fde68a  pop rdx
0000708296fde68b  pop rcx
0000708296fde68c  pop rax
0000708296fde68d  add rsp, 0x08
0000708296fde691  jmp 0x0000708296FDC15E
0000708296fde696  sub rsp, 0x08
0000708296fde69a  push rax
0000708296fde69b  push rcx
0000708296fde69c  push rdx
0000708296fde69d  push rdi
0000708296fde69e  push rsi
0000708296fde69f  push r8
0000708296fde6a1  push r9
0000708296fde6a3  push r10
0000708296fde6a5  push r11
0000708296fde6a7  sub rsp, 0xF0
0000708296fde6ae  vmovaps [rsp], xmm0
0000708296fde6b3  vmovaps [rsp+0x10], xmm1
0000708296fde6b9  vmovaps [rsp+0x20], xmm2
0000708296fde6bf  vmovaps [rsp+0x30], xmm3
0000708296fde6c5  vmovaps [rsp+0x40], xmm4
0000708296fde6cb  vmovaps [rsp+0x50], xmm5
0000708296fde6d1  vmovaps [rsp+0x60], xmm6
0000708296fde6d7  vmovaps [rsp+0x70], xmm7
0000708296fde6dd  vmovaps [rsp+0x80], xmm8
0000708296fde6e6  vmovaps [rsp+0x90], xmm10
0000708296fde6ef  vmovaps [rsp+0xA0], xmm11
0000708296fde6f8  vmovaps [rsp+0xB0], xmm12
0000708296fde701  vmovaps [rsp+0xC0], xmm13
0000708296fde70a  vmovaps [rsp+0xD0], xmm14
0000708296fde713  vmovaps [rsp+0xE0], xmm15
0000708296fde71c  sub rsp, 0x30
0000708296fde720  movaps [rsp], xmm9
0000708296fde725  movaps [rsp+0x10], xmm3
0000708296fde72a  movaps [rsp+0x20], xmm1
0000708296fde72f  lea rdi, [rsp]
0000708296fde733  mov esi, 0x00
0000708296fde738  mov rax, 0x64BBC686C530
0000708296fde742  call rax
0000708296fde744  movaps xmm9, [rsp]
0000708296fde749  add rsp, 0x30
0000708296fde74d  vmovaps xmm0, [rsp]
0000708296fde752  vmovaps xmm1, [rsp+0x10]
0000708296fde758  vmovaps xmm2, [rsp+0x20]
0000708296fde75e  vmovaps xmm3, [rsp+0x30]
0000708296fde764  vmovaps xmm4, [rsp+0x40]
0000708296fde76a  vmovaps xmm5, [rsp+0x50]
0000708296fde770  vmovaps xmm6, [rsp+0x60]
0000708296fde776  vmovaps xmm7, [rsp+0x70]
0000708296fde77c  vmovaps xmm8, [rsp+0x80]
0000708296fde785  vmovaps xmm10, [rsp+0x90]
0000708296fde78e  vmovaps xmm11, [rsp+0xA0]
0000708296fde797  vmovaps xmm12, [rsp+0xB0]
0000708296fde7a0  vmovaps xmm13, [rsp+0xC0]
0000708296fde7a9  vmovaps xmm14, [rsp+0xD0]
0000708296fde7b2  vmovaps xmm15, [rsp+0xE0]
0000708296fde7bb  add rsp, 0xF0
0000708296fde7c2  pop r11
0000708296fde7c4  pop r10
0000708296fde7c6  pop r9
0000708296fde7c8  pop r8
0000708296fde7ca  pop rsi
0000708296fde7cb  pop rdi
0000708296fde7cc  pop rdx
0000708296fde7cd  pop rcx
0000708296fde7ce  pop rax
0000708296fde7cf  add rsp, 0x08
0000708296fde7d3  jmp 0x0000708296FDC1AA
0000708296fde7d8  call 0x0000708296EB52F0
0000708296fde7dd  jmp 0x0000708296FDC1B7
0000708296fde7e2  sub rsp, 0x08
0000708296fde7e6  push rax
0000708296fde7e7  push rcx
0000708296fde7e8  push rdx
0000708296fde7e9  push rdi
0000708296fde7ea  push rsi
0000708296fde7eb  push r8
0000708296fde7ed  push r9
0000708296fde7ef  push r10
0000708296fde7f1  push r11
0000708296fde7f3  sub rsp, 0xF0
0000708296fde7fa  vmovaps [rsp], xmm0
0000708296fde7ff  vmovaps [rsp+0x10], xmm1
0000708296fde805  vmovaps [rsp+0x20], xmm2
0000708296fde80b  vmovaps [rsp+0x30], xmm3
0000708296fde811  vmovaps [rsp+0x40], xmm4
0000708296fde817  vmovaps [rsp+0x50], xmm5
0000708296fde81d  vmovaps [rsp+0x60], xmm6
0000708296fde823  vmovaps [rsp+0x70], xmm7
0000708296fde829  vmovaps [rsp+0x80], xmm8
0000708296fde832  vmovaps [rsp+0x90], xmm9
0000708296fde83b  vmovaps [rsp+0xA0], xmm10
0000708296fde844  vmovaps [rsp+0xB0], xmm11
0000708296fde84d  vmovaps [rsp+0xC0], xmm12
0000708296fde856  vmovaps [rsp+0xD0], xmm13
0000708296fde85f  vmovaps [rsp+0xE0], xmm14
0000708296fde868  sub rsp, 0x30
0000708296fde86c  movaps [rsp], xmm15
0000708296fde871  movaps [rsp+0x10], xmm3
0000708296fde876  movaps [rsp+0x20], xmm7
0000708296fde87b  lea rdi, [rsp]
0000708296fde87f  mov esi, 0x00
0000708296fde884  mov rax, 0x64BBC686C530
0000708296fde88e  call rax
0000708296fde890  movaps xmm15, [rsp]
0000708296fde895  add rsp, 0x30
0000708296fde899  vmovaps xmm0, [rsp]
0000708296fde89e  vmovaps xmm1, [rsp+0x10]
0000708296fde8a4  vmovaps xmm2, [rsp+0x20]
0000708296fde8aa  vmovaps xmm3, [rsp+0x30]
0000708296fde8b0  vmovaps xmm4, [rsp+0x40]
0000708296fde8b6  vmovaps xmm5, [rsp+0x50]
0000708296fde8bc  vmovaps xmm6, [rsp+0x60]
0000708296fde8c2  vmovaps xmm7, [rsp+0x70]
0000708296fde8c8  vmovaps xmm8, [rsp+0x80]
0000708296fde8d1  vmovaps xmm9, [rsp+0x90]
0000708296fde8da  vmovaps xmm10, [rsp+0xA0]
0000708296fde8e3  vmovaps xmm11, [rsp+0xB0]
0000708296fde8ec  vmovaps xmm12, [rsp+0xC0]
0000708296fde8f5  vmovaps xmm13, [rsp+0xD0]
0000708296fde8fe  vmovaps xmm14, [rsp+0xE0]
0000708296fde907  add rsp, 0xF0
0000708296fde90e  pop r11
0000708296fde910  pop r10
0000708296fde912  pop r9
0000708296fde914  pop r8
0000708296fde916  pop rsi
0000708296fde917  pop rdi
0000708296fde918  pop rdx
0000708296fde919  pop rcx
0000708296fde91a  pop rax
0000708296fde91b  add rsp, 0x08
0000708296fde91f  jmp 0x0000708296FDC1E3
0000708296fde924  sub rsp, 0x08
0000708296fde928  push rax
0000708296fde929  push rcx
0000708296fde92a  push rdx
0000708296fde92b  push rdi
0000708296fde92c  push rsi
0000708296fde92d  push r8
0000708296fde92f  push r9
0000708296fde931  push r10
0000708296fde933  push r11
0000708296fde935  sub rsp, 0xF0
0000708296fde93c  vmovaps [rsp], xmm0
0000708296fde941  vmovaps [rsp+0x10], xmm1
0000708296fde947  vmovaps [rsp+0x20], xmm2
0000708296fde94d  vmovaps [rsp+0x30], xmm4
0000708296fde953  vmovaps [rsp+0x40], xmm5
0000708296fde959  vmovaps [rsp+0x50], xmm6
0000708296fde95f  vmovaps [rsp+0x60], xmm7
0000708296fde965  vmovaps [rsp+0x70], xmm8
0000708296fde96b  vmovaps [rsp+0x80], xmm9
0000708296fde974  vmovaps [rsp+0x90], xmm10
0000708296fde97d  vmovaps [rsp+0xA0], xmm11
0000708296fde986  vmovaps [rsp+0xB0], xmm12
0000708296fde98f  vmovaps [rsp+0xC0], xmm13
0000708296fde998  vmovaps [rsp+0xD0], xmm14
0000708296fde9a1  vmovaps [rsp+0xE0], xmm15
0000708296fde9aa  sub rsp, 0x30
0000708296fde9ae  movaps [rsp], xmm3
0000708296fde9b2  movaps [rsp+0x10], xmm1
0000708296fde9b7  movaps [rsp+0x20], xmm15
0000708296fde9bd  lea rdi, [rsp]
0000708296fde9c1  mov esi, 0x00
0000708296fde9c6  mov rax, 0x64BBC686C530
0000708296fde9d0  call rax
0000708296fde9d2  movaps xmm3, [rsp]
0000708296fde9d6  add rsp, 0x30
0000708296fde9da  vmovaps xmm0, [rsp]
0000708296fde9df  vmovaps xmm1, [rsp+0x10]
0000708296fde9e5  vmovaps xmm2, [rsp+0x20]
0000708296fde9eb  vmovaps xmm4, [rsp+0x30]
0000708296fde9f1  vmovaps xmm5, [rsp+0x40]
0000708296fde9f7  vmovaps xmm6, [rsp+0x50]
0000708296fde9fd  vmovaps xmm7, [rsp+0x60]
0000708296fdea03  vmovaps xmm8, [rsp+0x70]
0000708296fdea09  vmovaps xmm9, [rsp+0x80]
0000708296fdea12  vmovaps xmm10, [rsp+0x90]
0000708296fdea1b  vmovaps xmm11, [rsp+0xA0]
0000708296fdea24  vmovaps xmm12, [rsp+0xB0]
0000708296fdea2d  vmovaps xmm13, [rsp+0xC0]
0000708296fdea36  vmovaps xmm14, [rsp+0xD0]
0000708296fdea3f  vmovaps xmm15, [rsp+0xE0]
0000708296fdea48  add rsp, 0xF0
0000708296fdea4f  pop r11
0000708296fdea51  pop r10
0000708296fdea53  pop r9
0000708296fdea55  pop r8
0000708296fdea57  pop rsi
0000708296fdea58  pop rdi
0000708296fdea59  pop rdx
0000708296fdea5a  pop rcx
0000708296fdea5b  pop rax
0000708296fdea5c  add rsp, 0x08
0000708296fdea60  jmp 0x0000708296FDC272
0000708296fdea65  call 0x0000708296EB52F0
0000708296fdea6a  jmp 0x0000708296FDC27C
0000708296fdea6f  sub rsp, 0x08
0000708296fdea73  push rax
0000708296fdea74  push rcx
0000708296fdea75  push rdx
0000708296fdea76  push rdi
0000708296fdea77  push rsi
0000708296fdea78  push r8
0000708296fdea7a  push r9
0000708296fdea7c  push r10
0000708296fdea7e  push r11
0000708296fdea80  sub rsp, 0xF0
0000708296fdea87  vmovaps [rsp], xmm0
0000708296fdea8c  vmovaps [rsp+0x10], xmm1
0000708296fdea92  vmovaps [rsp+0x20], xmm2
0000708296fdea98  vmovaps [rsp+0x30], xmm3
0000708296fdea9e  vmovaps [rsp+0x40], xmm4
0000708296fdeaa4  vmovaps [rsp+0x50], xmm5
0000708296fdeaaa  vmovaps [rsp+0x60], xmm6
0000708296fdeab0  vmovaps [rsp+0x70], xmm7
0000708296fdeab6  vmovaps [rsp+0x80], xmm8
0000708296fdeabf  vmovaps [rsp+0x90], xmm9
0000708296fdeac8  vmovaps [rsp+0xA0], xmm10
0000708296fdead1  vmovaps [rsp+0xB0], xmm11
0000708296fdeada  vmovaps [rsp+0xC0], xmm12
0000708296fdeae3  vmovaps [rsp+0xD0], xmm13
0000708296fdeaec  vmovaps [rsp+0xE0], xmm14
0000708296fdeaf5  sub rsp, 0x30
0000708296fdeaf9  movaps [rsp], xmm15
0000708296fdeafe  movaps [rsp+0x10], xmm14
0000708296fdeb04  movaps [rsp+0x20], xmm4
0000708296fdeb09  lea rdi, [rsp]
0000708296fdeb0d  mov esi, 0x00
0000708296fdeb12  mov rax, 0x64BBC686C530
0000708296fdeb1c  call rax
0000708296fdeb1e  movaps xmm15, [rsp]
0000708296fdeb23  add rsp, 0x30
0000708296fdeb27  vmovaps xmm0, [rsp]
0000708296fdeb2c  vmovaps xmm1, [rsp+0x10]
0000708296fdeb32  vmovaps xmm2, [rsp+0x20]
0000708296fdeb38  vmovaps xmm3, [rsp+0x30]
0000708296fdeb3e  vmovaps xmm4, [rsp+0x40]
0000708296fdeb44  vmovaps xmm5, [rsp+0x50]
0000708296fdeb4a  vmovaps xmm6, [rsp+0x60]
0000708296fdeb50  vmovaps xmm7, [rsp+0x70]
0000708296fdeb56  vmovaps xmm8, [rsp+0x80]
0000708296fdeb5f  vmovaps xmm9, [rsp+0x90]
0000708296fdeb68  vmovaps xmm10, [rsp+0xA0]
0000708296fdeb71  vmovaps xmm11, [rsp+0xB0]
0000708296fdeb7a  vmovaps xmm12, [rsp+0xC0]
0000708296fdeb83  vmovaps xmm13, [rsp+0xD0]
0000708296fdeb8c  vmovaps xmm14, [rsp+0xE0]
0000708296fdeb95  add rsp, 0xF0
0000708296fdeb9c  pop r11
0000708296fdeb9e  pop r10
0000708296fdeba0  pop r9
0000708296fdeba2  pop r8
0000708296fdeba4  pop rsi
0000708296fdeba5  pop rdi
0000708296fdeba6  pop rdx
0000708296fdeba7  pop rcx
0000708296fdeba8  pop rax
0000708296fdeba9  add rsp, 0x08
0000708296fdebad  jmp 0x0000708296FDC2AA
0000708296fdebb2  sub rsp, 0x08
0000708296fdebb6  push rax
0000708296fdebb7  push rcx
0000708296fdebb8  push rdx
0000708296fdebb9  push rdi
0000708296fdebba  push rsi
0000708296fdebbb  push r8
0000708296fdebbd  push r9
0000708296fdebbf  push r10
0000708296fdebc1  push r11
0000708296fdebc3  sub rsp, 0xF0
0000708296fdebca  vmovaps [rsp], xmm0
0000708296fdebcf  vmovaps [rsp+0x10], xmm1
0000708296fdebd5  vmovaps [rsp+0x20], xmm2
0000708296fdebdb  vmovaps [rsp+0x30], xmm3
0000708296fdebe1  vmovaps [rsp+0x40], xmm4
0000708296fdebe7  vmovaps [rsp+0x50], xmm5
0000708296fdebed  vmovaps [rsp+0x60], xmm6
0000708296fdebf3  vmovaps [rsp+0x70], xmm7
0000708296fdebf9  vmovaps [rsp+0x80], xmm8
0000708296fdec02  vmovaps [rsp+0x90], xmm9
0000708296fdec0b  vmovaps [rsp+0xA0], xmm10
0000708296fdec14  vmovaps [rsp+0xB0], xmm11
0000708296fdec1d  vmovaps [rsp+0xC0], xmm12
0000708296fdec26  vmovaps [rsp+0xD0], xmm13
0000708296fdec2f  vmovaps [rsp+0xE0], xmm15
0000708296fdec38  sub rsp, 0x30
0000708296fdec3c  movaps [rsp], xmm14
0000708296fdec41  movaps [rsp+0x10], xmm2
0000708296fdec46  movaps [rsp+0x20], xmm1
0000708296fdec4b  lea rdi, [rsp]
0000708296fdec4f  mov esi, 0x00
0000708296fdec54  mov rax, 0x64BBC686C530
0000708296fdec5e  call rax
0000708296fdec60  movaps xmm14, [rsp]
0000708296fdec65  add rsp, 0x30
0000708296fdec69  vmovaps xmm0, [rsp]
0000708296fdec6e  vmovaps xmm1, [rsp+0x10]
0000708296fdec74  vmovaps xmm2, [rsp+0x20]
0000708296fdec7a  vmovaps xmm3, [rsp+0x30]
0000708296fdec80  vmovaps xmm4, [rsp+0x40]
0000708296fdec86  vmovaps xmm5, [rsp+0x50]
0000708296fdec8c  vmovaps xmm6, [rsp+0x60]
0000708296fdec92  vmovaps xmm7, [rsp+0x70]
0000708296fdec98  vmovaps xmm8, [rsp+0x80]
0000708296fdeca1  vmovaps xmm9, [rsp+0x90]
0000708296fdecaa  vmovaps xmm10, [rsp+0xA0]
0000708296fdecb3  vmovaps xmm11, [rsp+0xB0]
0000708296fdecbc  vmovaps xmm12, [rsp+0xC0]
0000708296fdecc5  vmovaps xmm13, [rsp+0xD0]
0000708296fdecce  vmovaps xmm15, [rsp+0xE0]
0000708296fdecd7  add rsp, 0xF0
0000708296fdecde  pop r11
0000708296fdece0  pop r10
0000708296fdece2  pop r9
0000708296fdece4  pop r8
0000708296fdece6  pop rsi
0000708296fdece7  pop rdi
0000708296fdece8  pop rdx
0000708296fdece9  pop rcx
0000708296fdecea  pop rax
0000708296fdeceb  add rsp, 0x08
0000708296fdecef  jmp 0x0000708296FDC2D0
0000708296fdecf4  sub rsp, 0x08
0000708296fdecf8  push rax
0000708296fdecf9  push rcx
0000708296fdecfa  push rdx
0000708296fdecfb  push rdi
0000708296fdecfc  push rsi
0000708296fdecfd  push r8
0000708296fdecff  push r9
0000708296fded01  push r10
0000708296fded03  push r11
0000708296fded05  sub rsp, 0xF0
0000708296fded0c  vmovaps [rsp], xmm0
0000708296fded11  vmovaps [rsp+0x10], xmm2
0000708296fded17  vmovaps [rsp+0x20], xmm3
0000708296fded1d  vmovaps [rsp+0x30], xmm4
0000708296fded23  vmovaps [rsp+0x40], xmm5
0000708296fded29  vmovaps [rsp+0x50], xmm6
0000708296fded2f  vmovaps [rsp+0x60], xmm7
0000708296fded35  vmovaps [rsp+0x70], xmm8
0000708296fded3b  vmovaps [rsp+0x80], xmm9
0000708296fded44  vmovaps [rsp+0x90], xmm10
0000708296fded4d  vmovaps [rsp+0xA0], xmm11
0000708296fded56  vmovaps [rsp+0xB0], xmm12
0000708296fded5f  vmovaps [rsp+0xC0], xmm13
0000708296fded68  vmovaps [rsp+0xD0], xmm14
0000708296fded71  vmovaps [rsp+0xE0], xmm15
0000708296fded7a  sub rsp, 0x30
0000708296fded7e  movaps [rsp], xmm1
0000708296fded82  movaps [rsp+0x10], xmm4
0000708296fded87  movaps [rsp+0x20], xmm9
0000708296fded8d  lea rdi, [rsp]
0000708296fded91  mov esi, 0x00
0000708296fded96  mov rax, 0x64BBC686C530
0000708296fdeda0  call rax
0000708296fdeda2  movaps xmm1, [rsp]
0000708296fdeda6  add rsp, 0x30
0000708296fdedaa  vmovaps xmm0, [rsp]
0000708296fdedaf  vmovaps xmm2, [rsp+0x10]
0000708296fdedb5  vmovaps xmm3, [rsp+0x20]
0000708296fdedbb  vmovaps xmm4, [rsp+0x30]
0000708296fdedc1  vmovaps xmm5, [rsp+0x40]
0000708296fdedc7  vmovaps xmm6, [rsp+0x50]
0000708296fdedcd  vmovaps xmm7, [rsp+0x60]
0000708296fdedd3  vmovaps xmm8, [rsp+0x70]
0000708296fdedd9  vmovaps xmm9, [rsp+0x80]
0000708296fdede2  vmovaps xmm10, [rsp+0x90]
0000708296fdedeb  vmovaps xmm11, [rsp+0xA0]
0000708296fdedf4  vmovaps xmm12, [rsp+0xB0]
0000708296fdedfd  vmovaps xmm13, [rsp+0xC0]
0000708296fdee06  vmovaps xmm14, [rsp+0xD0]
0000708296fdee0f  vmovaps xmm15, [rsp+0xE0]
0000708296fdee18  add rsp, 0xF0
0000708296fdee1f  pop r11
0000708296fdee21  pop r10
0000708296fdee23  pop r9
0000708296fdee25  pop r8
0000708296fdee27  pop rsi
0000708296fdee28  pop rdi
0000708296fdee29  pop rdx
0000708296fdee2a  pop rcx
0000708296fdee2b  pop rax
0000708296fdee2c  add rsp, 0x08
0000708296fdee30  jmp 0x0000708296FDC2EE
0000708296fdee35  sub rsp, 0x08
0000708296fdee39  push rax
0000708296fdee3a  push rcx
0000708296fdee3b  push rdx
0000708296fdee3c  push rdi
0000708296fdee3d  push rsi
0000708296fdee3e  push r8
0000708296fdee40  push r9
0000708296fdee42  push r10
0000708296fdee44  push r11
0000708296fdee46  sub rsp, 0xF0
0000708296fdee4d  vmovaps [rsp], xmm0
0000708296fdee52  vmovaps [rsp+0x10], xmm1
0000708296fdee58  vmovaps [rsp+0x20], xmm2
0000708296fdee5e  vmovaps [rsp+0x30], xmm3
0000708296fdee64  vmovaps [rsp+0x40], xmm5
0000708296fdee6a  vmovaps [rsp+0x50], xmm6
0000708296fdee70  vmovaps [rsp+0x60], xmm7
0000708296fdee76  vmovaps [rsp+0x70], xmm8
0000708296fdee7c  vmovaps [rsp+0x80], xmm9
0000708296fdee85  vmovaps [rsp+0x90], xmm10
0000708296fdee8e  vmovaps [rsp+0xA0], xmm11
0000708296fdee97  vmovaps [rsp+0xB0], xmm12
0000708296fdeea0  vmovaps [rsp+0xC0], xmm13
0000708296fdeea9  vmovaps [rsp+0xD0], xmm14
0000708296fdeeb2  vmovaps [rsp+0xE0], xmm15
0000708296fdeebb  sub rsp, 0x30
0000708296fdeebf  movaps [rsp], xmm4
0000708296fdeec3  movaps [rsp+0x10], xmm2
0000708296fdeec8  movaps [rsp+0x20], xmm9
0000708296fdeece  lea rdi, [rsp]
0000708296fdeed2  mov esi, 0x00
0000708296fdeed7  mov rax, 0x64BBC686C530
0000708296fdeee1  call rax
0000708296fdeee3  movaps xmm4, [rsp]
0000708296fdeee7  add rsp, 0x30
0000708296fdeeeb  vmovaps xmm0, [rsp]
0000708296fdeef0  vmovaps xmm1, [rsp+0x10]
0000708296fdeef6  vmovaps xmm2, [rsp+0x20]
0000708296fdeefc  vmovaps xmm3, [rsp+0x30]
0000708296fdef02  vmovaps xmm5, [rsp+0x40]
0000708296fdef08  vmovaps xmm6, [rsp+0x50]
0000708296fdef0e  vmovaps xmm7, [rsp+0x60]
0000708296fdef14  vmovaps xmm8, [rsp+0x70]
0000708296fdef1a  vmovaps xmm9, [rsp+0x80]
0000708296fdef23  vmovaps xmm10, [rsp+0x90]
0000708296fdef2c  vmovaps xmm11, [rsp+0xA0]
0000708296fdef35  vmovaps xmm12, [rsp+0xB0]
0000708296fdef3e  vmovaps xmm13, [rsp+0xC0]
0000708296fdef47  vmovaps xmm14, [rsp+0xD0]
0000708296fdef50  vmovaps xmm15, [rsp+0xE0]
0000708296fdef59  add rsp, 0xF0
0000708296fdef60  pop r11
0000708296fdef62  pop r10
0000708296fdef64  pop r9
0000708296fdef66  pop r8
0000708296fdef68  pop rsi
0000708296fdef69  pop rdi
0000708296fdef6a  pop rdx
0000708296fdef6b  pop rcx
0000708296fdef6c  pop rax
0000708296fdef6d  add rsp, 0x08
0000708296fdef71  jmp 0x0000708296FDC31E
0000708296fdef76  sub rsp, 0x08
0000708296fdef7a  push rax
0000708296fdef7b  push rcx
0000708296fdef7c  push rdx
0000708296fdef7d  push rdi
0000708296fdef7e  push rsi
0000708296fdef7f  push r8
0000708296fdef81  push r9
0000708296fdef83  push r10
0000708296fdef85  push r11
0000708296fdef87  sub rsp, 0xF0
0000708296fdef8e  vmovaps [rsp], xmm0
0000708296fdef93  vmovaps [rsp+0x10], xmm1
0000708296fdef99  vmovaps [rsp+0x20], xmm2
0000708296fdef9f  vmovaps [rsp+0x30], xmm3
0000708296fdefa5  vmovaps [rsp+0x40], xmm4
0000708296fdefab  vmovaps [rsp+0x50], xmm5
0000708296fdefb1  vmovaps [rsp+0x60], xmm6
0000708296fdefb7  vmovaps [rsp+0x70], xmm7
0000708296fdefbd  vmovaps [rsp+0x80], xmm8
0000708296fdefc6  vmovaps [rsp+0x90], xmm10
0000708296fdefcf  vmovaps [rsp+0xA0], xmm11
0000708296fdefd8  vmovaps [rsp+0xB0], xmm12
0000708296fdefe1  vmovaps [rsp+0xC0], xmm13
0000708296fdefea  vmovaps [rsp+0xD0], xmm14
0000708296fdeff3  vmovaps [rsp+0xE0], xmm15
0000708296fdeffc  sub rsp, 0x30
0000708296fdf000  movaps [rsp], xmm9
0000708296fdf005  movaps [rsp+0x10], xmm2
0000708296fdf00a  movaps [rsp+0x20], xmm1
0000708296fdf00f  lea rdi, [rsp]
0000708296fdf013  mov esi, 0x00
0000708296fdf018  mov rax, 0x64BBC686C530
0000708296fdf022  call rax
0000708296fdf024  movaps xmm9, [rsp]
0000708296fdf029  add rsp, 0x30
0000708296fdf02d  vmovaps xmm0, [rsp]
0000708296fdf032  vmovaps xmm1, [rsp+0x10]
0000708296fdf038  vmovaps xmm2, [rsp+0x20]
0000708296fdf03e  vmovaps xmm3, [rsp+0x30]
0000708296fdf044  vmovaps xmm4, [rsp+0x40]
0000708296fdf04a  vmovaps xmm5, [rsp+0x50]
0000708296fdf050  vmovaps xmm6, [rsp+0x60]
0000708296fdf056  vmovaps xmm7, [rsp+0x70]
0000708296fdf05c  vmovaps xmm8, [rsp+0x80]
0000708296fdf065  vmovaps xmm10, [rsp+0x90]
0000708296fdf06e  vmovaps xmm11, [rsp+0xA0]
0000708296fdf077  vmovaps xmm12, [rsp+0xB0]
0000708296fdf080  vmovaps xmm13, [rsp+0xC0]
0000708296fdf089  vmovaps xmm14, [rsp+0xD0]
0000708296fdf092  vmovaps xmm15, [rsp+0xE0]
0000708296fdf09b  add rsp, 0xF0
0000708296fdf0a2  pop r11
0000708296fdf0a4  pop r10
0000708296fdf0a6  pop r9
0000708296fdf0a8  pop r8
0000708296fdf0aa  pop rsi
0000708296fdf0ab  pop rdi
0000708296fdf0ac  pop rdx
0000708296fdf0ad  pop rcx
0000708296fdf0ae  pop rax
0000708296fdf0af  add rsp, 0x08
0000708296fdf0b3  jmp 0x0000708296FDC354
0000708296fdf0b8  sub rsp, 0x08
0000708296fdf0bc  push rax
0000708296fdf0bd  push rcx
0000708296fdf0be  push rdx
0000708296fdf0bf  push rdi
0000708296fdf0c0  push rsi
0000708296fdf0c1  push r8
0000708296fdf0c3  push r9
0000708296fdf0c5  push r10
0000708296fdf0c7  push r11
0000708296fdf0c9  sub rsp, 0xF0
0000708296fdf0d0  vmovaps [rsp], xmm0
0000708296fdf0d5  vmovaps [rsp+0x10], xmm2
0000708296fdf0db  vmovaps [rsp+0x20], xmm3
0000708296fdf0e1  vmovaps [rsp+0x30], xmm4
0000708296fdf0e7  vmovaps [rsp+0x40], xmm5
0000708296fdf0ed  vmovaps [rsp+0x50], xmm6
0000708296fdf0f3  vmovaps [rsp+0x60], xmm7
0000708296fdf0f9  vmovaps [rsp+0x70], xmm8
0000708296fdf0ff  vmovaps [rsp+0x80], xmm9
0000708296fdf108  vmovaps [rsp+0x90], xmm10
0000708296fdf111  vmovaps [rsp+0xA0], xmm11
0000708296fdf11a  vmovaps [rsp+0xB0], xmm12
0000708296fdf123  vmovaps [rsp+0xC0], xmm13
0000708296fdf12c  vmovaps [rsp+0xD0], xmm14
0000708296fdf135  vmovaps [rsp+0xE0], xmm15
0000708296fdf13e  sub rsp, 0x30
0000708296fdf142  movaps [rsp], xmm1
0000708296fdf146  movaps [rsp+0x10], xmm15
0000708296fdf14c  movaps [rsp+0x20], xmm6
0000708296fdf151  lea rdi, [rsp]
0000708296fdf155  mov esi, 0x00
0000708296fdf15a  mov rax, 0x64BBC686C530
0000708296fdf164  call rax
0000708296fdf166  movaps xmm1, [rsp]
0000708296fdf16a  add rsp, 0x30
0000708296fdf16e  vmovaps xmm0, [rsp]
0000708296fdf173  vmovaps xmm2, [rsp+0x10]
0000708296fdf179  vmovaps xmm3, [rsp+0x20]
0000708296fdf17f  vmovaps xmm4, [rsp+0x30]
0000708296fdf185  vmovaps xmm5, [rsp+0x40]
0000708296fdf18b  vmovaps xmm6, [rsp+0x50]
0000708296fdf191  vmovaps xmm7, [rsp+0x60]
0000708296fdf197  vmovaps xmm8, [rsp+0x70]
0000708296fdf19d  vmovaps xmm9, [rsp+0x80]
0000708296fdf1a6  vmovaps xmm10, [rsp+0x90]
0000708296fdf1af  vmovaps xmm11, [rsp+0xA0]
0000708296fdf1b8  vmovaps xmm12, [rsp+0xB0]
0000708296fdf1c1  vmovaps xmm13, [rsp+0xC0]
0000708296fdf1ca  vmovaps xmm14, [rsp+0xD0]
0000708296fdf1d3  vmovaps xmm15, [rsp+0xE0]
0000708296fdf1dc  add rsp, 0xF0
0000708296fdf1e3  pop r11
0000708296fdf1e5  pop r10
0000708296fdf1e7  pop r9
0000708296fdf1e9  pop r8
0000708296fdf1eb  pop rsi
0000708296fdf1ec  pop rdi
0000708296fdf1ed  pop rdx
0000708296fdf1ee  pop rcx
0000708296fdf1ef  pop rax
0000708296fdf1f0  add rsp, 0x08
0000708296fdf1f4  jmp 0x0000708296FDC375
0000708296fdf1f9  sub rsp, 0x08
0000708296fdf1fd  push rax
0000708296fdf1fe  push rcx
0000708296fdf1ff  push rdx
0000708296fdf200  push rdi
0000708296fdf201  push rsi
0000708296fdf202  push r8
0000708296fdf204  push r9
0000708296fdf206  push r10
0000708296fdf208  push r11
0000708296fdf20a  sub rsp, 0xF0
0000708296fdf211  vmovaps [rsp], xmm0
0000708296fdf216  vmovaps [rsp+0x10], xmm1
0000708296fdf21c  vmovaps [rsp+0x20], xmm2
0000708296fdf222  vmovaps [rsp+0x30], xmm3
0000708296fdf228  vmovaps [rsp+0x40], xmm4
0000708296fdf22e  vmovaps [rsp+0x50], xmm5
0000708296fdf234  vmovaps [rsp+0x60], xmm6
0000708296fdf23a  vmovaps [rsp+0x70], xmm7
0000708296fdf240  vmovaps [rsp+0x80], xmm8
0000708296fdf249  vmovaps [rsp+0x90], xmm9
0000708296fdf252  vmovaps [rsp+0xA0], xmm10
0000708296fdf25b  vmovaps [rsp+0xB0], xmm11
0000708296fdf264  vmovaps [rsp+0xC0], xmm12
0000708296fdf26d  vmovaps [rsp+0xD0], xmm13
0000708296fdf276  vmovaps [rsp+0xE0], xmm14
0000708296fdf27f  sub rsp, 0x30
0000708296fdf283  movaps [rsp], xmm15
0000708296fdf288  movaps [rsp+0x10], xmm5
0000708296fdf28d  movaps [rsp+0x20], xmm3
0000708296fdf292  lea rdi, [rsp]
0000708296fdf296  mov esi, 0x00
0000708296fdf29b  mov rax, 0x64BBC686C530
0000708296fdf2a5  call rax
0000708296fdf2a7  movaps xmm15, [rsp]
0000708296fdf2ac  add rsp, 0x30
0000708296fdf2b0  vmovaps xmm0, [rsp]
0000708296fdf2b5  vmovaps xmm1, [rsp+0x10]
0000708296fdf2bb  vmovaps xmm2, [rsp+0x20]
0000708296fdf2c1  vmovaps xmm3, [rsp+0x30]
0000708296fdf2c7  vmovaps xmm4, [rsp+0x40]
0000708296fdf2cd  vmovaps xmm5, [rsp+0x50]
0000708296fdf2d3  vmovaps xmm6, [rsp+0x60]
0000708296fdf2d9  vmovaps xmm7, [rsp+0x70]
0000708296fdf2df  vmovaps xmm8, [rsp+0x80]
0000708296fdf2e8  vmovaps xmm9, [rsp+0x90]
0000708296fdf2f1  vmovaps xmm10, [rsp+0xA0]
0000708296fdf2fa  vmovaps xmm11, [rsp+0xB0]
0000708296fdf303  vmovaps xmm12, [rsp+0xC0]
0000708296fdf30c  vmovaps xmm13, [rsp+0xD0]
0000708296fdf315  vmovaps xmm14, [rsp+0xE0]
0000708296fdf31e  add rsp, 0xF0
0000708296fdf325  pop r11
0000708296fdf327  pop r10
0000708296fdf329  pop r9
0000708296fdf32b  pop r8
0000708296fdf32d  pop rsi
0000708296fdf32e  pop rdi
0000708296fdf32f  pop rdx
0000708296fdf330  pop rcx
0000708296fdf331  pop rax
0000708296fdf332  add rsp, 0x08
0000708296fdf336  jmp 0x0000708296FDC38F
0000708296fdf33b  sub rsp, 0x08
0000708296fdf33f  push rax
0000708296fdf340  push rcx
0000708296fdf341  push rdx
0000708296fdf342  push rdi
0000708296fdf343  push rsi
0000708296fdf344  push r8
0000708296fdf346  push r9
0000708296fdf348  push r10
0000708296fdf34a  push r11
0000708296fdf34c  sub rsp, 0xF0
0000708296fdf353  vmovaps [rsp], xmm0
0000708296fdf358  vmovaps [rsp+0x10], xmm1
0000708296fdf35e  vmovaps [rsp+0x20], xmm2
0000708296fdf364  vmovaps [rsp+0x30], xmm3
0000708296fdf36a  vmovaps [rsp+0x40], xmm4
0000708296fdf370  vmovaps [rsp+0x50], xmm6
0000708296fdf376  vmovaps [rsp+0x60], xmm7
0000708296fdf37c  vmovaps [rsp+0x70], xmm8
0000708296fdf382  vmovaps [rsp+0x80], xmm9
0000708296fdf38b  vmovaps [rsp+0x90], xmm10
0000708296fdf394  vmovaps [rsp+0xA0], xmm11
0000708296fdf39d  vmovaps [rsp+0xB0], xmm12
0000708296fdf3a6  vmovaps [rsp+0xC0], xmm13
0000708296fdf3af  vmovaps [rsp+0xD0], xmm14
0000708296fdf3b8  vmovaps [rsp+0xE0], xmm15
0000708296fdf3c1  sub rsp, 0x30
0000708296fdf3c5  movaps [rsp], xmm5
0000708296fdf3c9  movaps [rsp+0x10], xmm8
0000708296fdf3cf  movaps [rsp+0x20], xmm6
0000708296fdf3d4  lea rdi, [rsp]
0000708296fdf3d8  mov esi, 0x00
0000708296fdf3dd  mov rax, 0x64BBC686C530
0000708296fdf3e7  call rax
0000708296fdf3e9  movaps xmm5, [rsp]
0000708296fdf3ed  add rsp, 0x30
0000708296fdf3f1  vmovaps xmm0, [rsp]
0000708296fdf3f6  vmovaps xmm1, [rsp+0x10]
0000708296fdf3fc  vmovaps xmm2, [rsp+0x20]
0000708296fdf402  vmovaps xmm3, [rsp+0x30]
0000708296fdf408  vmovaps xmm4, [rsp+0x40]
0000708296fdf40e  vmovaps xmm6, [rsp+0x50]
0000708296fdf414  vmovaps xmm7, [rsp+0x60]
0000708296fdf41a  vmovaps xmm8, [rsp+0x70]
0000708296fdf420  vmovaps xmm9, [rsp+0x80]
0000708296fdf429  vmovaps xmm10, [rsp+0x90]
0000708296fdf432  vmovaps xmm11, [rsp+0xA0]
0000708296fdf43b  vmovaps xmm12, [rsp+0xB0]
0000708296fdf444  vmovaps xmm13, [rsp+0xC0]
0000708296fdf44d  vmovaps xmm14, [rsp+0xD0]
0000708296fdf456  vmovaps xmm15, [rsp+0xE0]
0000708296fdf45f  add rsp, 0xF0
0000708296fdf466  pop r11
0000708296fdf468  pop r10
0000708296fdf46a  pop r9
0000708296fdf46c  pop r8
0000708296fdf46e  pop rsi
0000708296fdf46f  pop rdi
0000708296fdf470  pop rdx
0000708296fdf471  pop rcx
0000708296fdf472  pop rax
0000708296fdf473  add rsp, 0x08
0000708296fdf477  jmp 0x0000708296FDC3B3
0000708296fdf47c  sub rsp, 0x08
0000708296fdf480  push rax
0000708296fdf481  push rcx
0000708296fdf482  push rdx
0000708296fdf483  push rdi
0000708296fdf484  push rsi
0000708296fdf485  push r8
0000708296fdf487  push r9
0000708296fdf489  push r10
0000708296fdf48b  push r11
0000708296fdf48d  sub rsp, 0xF0
0000708296fdf494  vmovaps [rsp], xmm0
0000708296fdf499  vmovaps [rsp+0x10], xmm1
0000708296fdf49f  vmovaps [rsp+0x20], xmm2
0000708296fdf4a5  vmovaps [rsp+0x30], xmm3
0000708296fdf4ab  vmovaps [rsp+0x40], xmm4
0000708296fdf4b1  vmovaps [rsp+0x50], xmm5
0000708296fdf4b7  vmovaps [rsp+0x60], xmm7
0000708296fdf4bd  vmovaps [rsp+0x70], xmm8
0000708296fdf4c3  vmovaps [rsp+0x80], xmm9
0000708296fdf4cc  vmovaps [rsp+0x90], xmm10
0000708296fdf4d5  vmovaps [rsp+0xA0], xmm11
0000708296fdf4de  vmovaps [rsp+0xB0], xmm12
0000708296fdf4e7  vmovaps [rsp+0xC0], xmm13
0000708296fdf4f0  vmovaps [rsp+0xD0], xmm14
0000708296fdf4f9  vmovaps [rsp+0xE0], xmm15
0000708296fdf502  sub rsp, 0x30
0000708296fdf506  movaps [rsp], xmm6
0000708296fdf50a  movaps [rsp+0x10], xmm10
0000708296fdf510  movaps [rsp+0x20], xmm8
0000708296fdf516  lea rdi, [rsp]
0000708296fdf51a  mov esi, 0x00
0000708296fdf51f  mov rax, 0x64BBC686C530
0000708296fdf529  call rax
0000708296fdf52b  movaps xmm6, [rsp]
0000708296fdf52f  add rsp, 0x30
0000708296fdf533  vmovaps xmm0, [rsp]
0000708296fdf538  vmovaps xmm1, [rsp+0x10]
0000708296fdf53e  vmovaps xmm2, [rsp+0x20]
0000708296fdf544  vmovaps xmm3, [rsp+0x30]
0000708296fdf54a  vmovaps xmm4, [rsp+0x40]
0000708296fdf550  vmovaps xmm5, [rsp+0x50]
0000708296fdf556  vmovaps xmm7, [rsp+0x60]
0000708296fdf55c  vmovaps xmm8, [rsp+0x70]
0000708296fdf562  vmovaps xmm9, [rsp+0x80]
0000708296fdf56b  vmovaps xmm10, [rsp+0x90]
0000708296fdf574  vmovaps xmm11, [rsp+0xA0]
0000708296fdf57d  vmovaps xmm12, [rsp+0xB0]
0000708296fdf586  vmovaps xmm13, [rsp+0xC0]
0000708296fdf58f  vmovaps xmm14, [rsp+0xD0]
0000708296fdf598  vmovaps xmm15, [rsp+0xE0]
0000708296fdf5a1  add rsp, 0xF0
0000708296fdf5a8  pop r11
0000708296fdf5aa  pop r10
0000708296fdf5ac  pop r9
0000708296fdf5ae  pop r8
0000708296fdf5b0  pop rsi
0000708296fdf5b1  pop rdi
0000708296fdf5b2  pop rdx
0000708296fdf5b3  pop rcx
0000708296fdf5b4  pop rax
0000708296fdf5b5  add rsp, 0x08
0000708296fdf5b9  jmp 0x0000708296FDC3D8
0000708296fdf5be  sub rsp, 0x08
0000708296fdf5c2  push rax
0000708296fdf5c3  push rcx
0000708296fdf5c4  push rdx
0000708296fdf5c5  push rdi
0000708296fdf5c6  push rsi
0000708296fdf5c7  push r8
0000708296fdf5c9  push r9
0000708296fdf5cb  push r10
0000708296fdf5cd  push r11
0000708296fdf5cf  sub rsp, 0xF0
0000708296fdf5d6  vmovaps [rsp], xmm0
0000708296fdf5db  vmovaps [rsp+0x10], xmm1
0000708296fdf5e1  vmovaps [rsp+0x20], xmm2
0000708296fdf5e7  vmovaps [rsp+0x30], xmm3
0000708296fdf5ed  vmovaps [rsp+0x40], xmm4
0000708296fdf5f3  vmovaps [rsp+0x50], xmm5
0000708296fdf5f9  vmovaps [rsp+0x60], xmm6
0000708296fdf5ff  vmovaps [rsp+0x70], xmm7
0000708296fdf605  vmovaps [rsp+0x80], xmm8
0000708296fdf60e  vmovaps [rsp+0x90], xmm9
0000708296fdf617  vmovaps [rsp+0xA0], xmm11
0000708296fdf620  vmovaps [rsp+0xB0], xmm12
0000708296fdf629  vmovaps [rsp+0xC0], xmm13
0000708296fdf632  vmovaps [rsp+0xD0], xmm14
0000708296fdf63b  vmovaps [rsp+0xE0], xmm15
0000708296fdf644  sub rsp, 0x30
0000708296fdf648  movaps [rsp], xmm10
0000708296fdf64d  movaps [rsp+0x10], xmm8
0000708296fdf653  movaps [rsp+0x20], xmm14
0000708296fdf659  lea rdi, [rsp]
0000708296fdf65d  mov esi, 0x00
0000708296fdf662  mov rax, 0x64BBC686C530
0000708296fdf66c  call rax
0000708296fdf66e  movaps xmm10, [rsp]
0000708296fdf673  add rsp, 0x30
0000708296fdf677  vmovaps xmm0, [rsp]
0000708296fdf67c  vmovaps xmm1, [rsp+0x10]
0000708296fdf682  vmovaps xmm2, [rsp+0x20]
0000708296fdf688  vmovaps xmm3, [rsp+0x30]
0000708296fdf68e  vmovaps xmm4, [rsp+0x40]
0000708296fdf694  vmovaps xmm5, [rsp+0x50]
0000708296fdf69a  vmovaps xmm6, [rsp+0x60]
0000708296fdf6a0  vmovaps xmm7, [rsp+0x70]
0000708296fdf6a6  vmovaps xmm8, [rsp+0x80]
0000708296fdf6af  vmovaps xmm9, [rsp+0x90]
0000708296fdf6b8  vmovaps xmm11, [rsp+0xA0]
0000708296fdf6c1  vmovaps xmm12, [rsp+0xB0]
0000708296fdf6ca  vmovaps xmm13, [rsp+0xC0]
0000708296fdf6d3  vmovaps xmm14, [rsp+0xD0]
0000708296fdf6dc  vmovaps xmm15, [rsp+0xE0]
0000708296fdf6e5  add rsp, 0xF0
0000708296fdf6ec  pop r11
0000708296fdf6ee  pop r10
0000708296fdf6f0  pop r9
0000708296fdf6f2  pop r8
0000708296fdf6f4  pop rsi
0000708296fdf6f5  pop rdi
0000708296fdf6f6  pop rdx
0000708296fdf6f7  pop rcx
0000708296fdf6f8  pop rax
0000708296fdf6f9  add rsp, 0x08
0000708296fdf6fd  jmp 0x0000708296FDC3F8
0000708296fdf702  sub rsp, 0x08
0000708296fdf706  push rax
0000708296fdf707  push rcx
0000708296fdf708  push rdx
0000708296fdf709  push rdi
0000708296fdf70a  push rsi
0000708296fdf70b  push r8
0000708296fdf70d  push r9
0000708296fdf70f  push r10
0000708296fdf711  push r11
0000708296fdf713  sub rsp, 0xF0
0000708296fdf71a  vmovaps [rsp], xmm0
0000708296fdf71f  vmovaps [rsp+0x10], xmm1
0000708296fdf725  vmovaps [rsp+0x20], xmm2
0000708296fdf72b  vmovaps [rsp+0x30], xmm3
0000708296fdf731  vmovaps [rsp+0x40], xmm4
0000708296fdf737  vmovaps [rsp+0x50], xmm5
0000708296fdf73d  vmovaps [rsp+0x60], xmm6
0000708296fdf743  vmovaps [rsp+0x70], xmm7
0000708296fdf749  vmovaps [rsp+0x80], xmm8
0000708296fdf752  vmovaps [rsp+0x90], xmm9
0000708296fdf75b  vmovaps [rsp+0xA0], xmm10
0000708296fdf764  vmovaps [rsp+0xB0], xmm11
0000708296fdf76d  vmovaps [rsp+0xC0], xmm12
0000708296fdf776  vmovaps [rsp+0xD0], xmm13
0000708296fdf77f  vmovaps [rsp+0xE0], xmm15
0000708296fdf788  sub rsp, 0x30
0000708296fdf78c  movaps [rsp], xmm14
0000708296fdf791  movaps [rsp+0x10], xmm8
0000708296fdf797  movaps [rsp+0x20], xmm4
0000708296fdf79c  lea rdi, [rsp]
0000708296fdf7a0  mov esi, 0x00
0000708296fdf7a5  mov rax, 0x64BBC686C530
0000708296fdf7af  call rax
0000708296fdf7b1  movaps xmm14, [rsp]
0000708296fdf7b6  add rsp, 0x30
0000708296fdf7ba  vmovaps xmm0, [rsp]
0000708296fdf7bf  vmovaps xmm1, [rsp+0x10]
0000708296fdf7c5  vmovaps xmm2, [rsp+0x20]
0000708296fdf7cb  vmovaps xmm3, [rsp+0x30]
0000708296fdf7d1  vmovaps xmm4, [rsp+0x40]
0000708296fdf7d7  vmovaps xmm5, [rsp+0x50]
0000708296fdf7dd  vmovaps xmm6, [rsp+0x60]
0000708296fdf7e3  vmovaps xmm7, [rsp+0x70]
0000708296fdf7e9  vmovaps xmm8, [rsp+0x80]
0000708296fdf7f2  vmovaps xmm9, [rsp+0x90]
0000708296fdf7fb  vmovaps xmm10, [rsp+0xA0]
0000708296fdf804  vmovaps xmm11, [rsp+0xB0]
0000708296fdf80d  vmovaps xmm12, [rsp+0xC0]
0000708296fdf816  vmovaps xmm13, [rsp+0xD0]
0000708296fdf81f  vmovaps xmm15, [rsp+0xE0]
0000708296fdf828  add rsp, 0xF0
0000708296fdf82f  pop r11
0000708296fdf831  pop r10
0000708296fdf833  pop r9
0000708296fdf835  pop r8
0000708296fdf837  pop rsi
0000708296fdf838  pop rdi
0000708296fdf839  pop rdx
0000708296fdf83a  pop rcx
0000708296fdf83b  pop rax
0000708296fdf83c  add rsp, 0x08
0000708296fdf840  jmp 0x0000708296FDC418
0000708296fdf845  sub rsp, 0x08
0000708296fdf849  push rax
0000708296fdf84a  push rcx
0000708296fdf84b  push rdx
0000708296fdf84c  push rdi
0000708296fdf84d  push rsi
0000708296fdf84e  push r8
0000708296fdf850  push r9
0000708296fdf852  push r10
0000708296fdf854  push r11
0000708296fdf856  sub rsp, 0xF0
0000708296fdf85d  vmovaps [rsp], xmm0
0000708296fdf862  vmovaps [rsp+0x10], xmm1
0000708296fdf868  vmovaps [rsp+0x20], xmm2
0000708296fdf86e  vmovaps [rsp+0x30], xmm3
0000708296fdf874  vmovaps [rsp+0x40], xmm5
0000708296fdf87a  vmovaps [rsp+0x50], xmm6
0000708296fdf880  vmovaps [rsp+0x60], xmm7
0000708296fdf886  vmovaps [rsp+0x70], xmm8
0000708296fdf88c  vmovaps [rsp+0x80], xmm9
0000708296fdf895  vmovaps [rsp+0x90], xmm10
0000708296fdf89e  vmovaps [rsp+0xA0], xmm11
0000708296fdf8a7  vmovaps [rsp+0xB0], xmm12
0000708296fdf8b0  vmovaps [rsp+0xC0], xmm13
0000708296fdf8b9  vmovaps [rsp+0xD0], xmm14
0000708296fdf8c2  vmovaps [rsp+0xE0], xmm15
0000708296fdf8cb  sub rsp, 0x30
0000708296fdf8cf  movaps [rsp], xmm4
0000708296fdf8d3  movaps [rsp+0x10], xmm13
0000708296fdf8d9  movaps [rsp+0x20], xmm8
0000708296fdf8df  lea rdi, [rsp]
0000708296fdf8e3  mov esi, 0x00
0000708296fdf8e8  mov rax, 0x64BBC686C530
0000708296fdf8f2  call rax
0000708296fdf8f4  movaps xmm4, [rsp]
0000708296fdf8f8  add rsp, 0x30
0000708296fdf8fc  vmovaps xmm0, [rsp]
0000708296fdf901  vmovaps xmm1, [rsp+0x10]
0000708296fdf907  vmovaps xmm2, [rsp+0x20]
0000708296fdf90d  vmovaps xmm3, [rsp+0x30]
0000708296fdf913  vmovaps xmm5, [rsp+0x40]
0000708296fdf919  vmovaps xmm6, [rsp+0x50]
0000708296fdf91f  vmovaps xmm7, [rsp+0x60]
0000708296fdf925  vmovaps xmm8, [rsp+0x70]
0000708296fdf92b  vmovaps xmm9, [rsp+0x80]
0000708296fdf934  vmovaps xmm10, [rsp+0x90]
0000708296fdf93d  vmovaps xmm11, [rsp+0xA0]
0000708296fdf946  vmovaps xmm12, [rsp+0xB0]
0000708296fdf94f  vmovaps xmm13, [rsp+0xC0]
0000708296fdf958  vmovaps xmm14, [rsp+0xD0]
0000708296fdf961  vmovaps xmm15, [rsp+0xE0]
0000708296fdf96a  add rsp, 0xF0
0000708296fdf971  pop r11
0000708296fdf973  pop r10
0000708296fdf975  pop r9
0000708296fdf977  pop r8
0000708296fdf979  pop rsi
0000708296fdf97a  pop rdi
0000708296fdf97b  pop rdx
0000708296fdf97c  pop rcx
0000708296fdf97d  pop rax
0000708296fdf97e  add rsp, 0x08
0000708296fdf982  jmp 0x0000708296FDC43D
0000708296fdf987  sub rsp, 0x08
0000708296fdf98b  push rax
0000708296fdf98c  push rcx
0000708296fdf98d  push rdx
0000708296fdf98e  push rdi
0000708296fdf98f  push rsi
0000708296fdf990  push r8
0000708296fdf992  push r9
0000708296fdf994  push r10
0000708296fdf996  push r11
0000708296fdf998  sub rsp, 0xF0
0000708296fdf99f  vmovaps [rsp], xmm0
0000708296fdf9a4  vmovaps [rsp+0x10], xmm1
0000708296fdf9aa  vmovaps [rsp+0x20], xmm2
0000708296fdf9b0  vmovaps [rsp+0x30], xmm3
0000708296fdf9b6  vmovaps [rsp+0x40], xmm4
0000708296fdf9bc  vmovaps [rsp+0x50], xmm5
0000708296fdf9c2  vmovaps [rsp+0x60], xmm6
0000708296fdf9c8  vmovaps [rsp+0x70], xmm7
0000708296fdf9ce  vmovaps [rsp+0x80], xmm8
0000708296fdf9d7  vmovaps [rsp+0x90], xmm9
0000708296fdf9e0  vmovaps [rsp+0xA0], xmm10
0000708296fdf9e9  vmovaps [rsp+0xB0], xmm11
0000708296fdf9f2  vmovaps [rsp+0xC0], xmm12
0000708296fdf9fb  vmovaps [rsp+0xD0], xmm14
0000708296fdfa04  vmovaps [rsp+0xE0], xmm15
0000708296fdfa0d  sub rsp, 0x30
0000708296fdfa11  movaps [rsp], xmm13
0000708296fdfa16  movaps [rsp+0x10], xmm15
0000708296fdfa1c  movaps [rsp+0x20], xmm9
0000708296fdfa22  lea rdi, [rsp]
0000708296fdfa26  mov esi, 0x00
0000708296fdfa2b  mov rax, 0x64BBC686C530
0000708296fdfa35  call rax
0000708296fdfa37  movaps xmm13, [rsp]
0000708296fdfa3c  add rsp, 0x30
0000708296fdfa40  vmovaps xmm0, [rsp]
0000708296fdfa45  vmovaps xmm1, [rsp+0x10]
0000708296fdfa4b  vmovaps xmm2, [rsp+0x20]
0000708296fdfa51  vmovaps xmm3, [rsp+0x30]
0000708296fdfa57  vmovaps xmm4, [rsp+0x40]
0000708296fdfa5d  vmovaps xmm5, [rsp+0x50]
0000708296fdfa63  vmovaps xmm6, [rsp+0x60]
0000708296fdfa69  vmovaps xmm7, [rsp+0x70]
0000708296fdfa6f  vmovaps xmm8, [rsp+0x80]
0000708296fdfa78  vmovaps xmm9, [rsp+0x90]
0000708296fdfa81  vmovaps xmm10, [rsp+0xA0]
0000708296fdfa8a  vmovaps xmm11, [rsp+0xB0]
0000708296fdfa93  vmovaps xmm12, [rsp+0xC0]
0000708296fdfa9c  vmovaps xmm14, [rsp+0xD0]
0000708296fdfaa5  vmovaps xmm15, [rsp+0xE0]
0000708296fdfaae  add rsp, 0xF0
0000708296fdfab5  pop r11
0000708296fdfab7  pop r10
0000708296fdfab9  pop r9
0000708296fdfabb  pop r8
0000708296fdfabd  pop rsi
0000708296fdfabe  pop rdi
0000708296fdfabf  pop rdx
0000708296fdfac0  pop rcx
0000708296fdfac1  pop rax
0000708296fdfac2  add rsp, 0x08
0000708296fdfac6  jmp 0x0000708296FDC458
0000708296fdfacb  sub rsp, 0x08
0000708296fdfacf  push rax
0000708296fdfad0  push rcx
0000708296fdfad1  push rdx
0000708296fdfad2  push rdi
0000708296fdfad3  push rsi
0000708296fdfad4  push r8
0000708296fdfad6  push r9
0000708296fdfad8  push r10
0000708296fdfada  push r11
0000708296fdfadc  sub rsp, 0xF0
0000708296fdfae3  vmovaps [rsp], xmm0
0000708296fdfae8  vmovaps [rsp+0x10], xmm1
0000708296fdfaee  vmovaps [rsp+0x20], xmm2
0000708296fdfaf4  vmovaps [rsp+0x30], xmm3
0000708296fdfafa  vmovaps [rsp+0x40], xmm4
0000708296fdfb00  vmovaps [rsp+0x50], xmm5
0000708296fdfb06  vmovaps [rsp+0x60], xmm6
0000708296fdfb0c  vmovaps [rsp+0x70], xmm7
0000708296fdfb12  vmovaps [rsp+0x80], xmm8
0000708296fdfb1b  vmovaps [rsp+0x90], xmm9
0000708296fdfb24  vmovaps [rsp+0xA0], xmm10
0000708296fdfb2d  vmovaps [rsp+0xB0], xmm11
0000708296fdfb36  vmovaps [rsp+0xC0], xmm12
0000708296fdfb3f  vmovaps [rsp+0xD0], xmm13
0000708296fdfb48  vmovaps [rsp+0xE0], xmm14
0000708296fdfb51  sub rsp, 0x30
0000708296fdfb55  movaps [rsp], xmm15
0000708296fdfb5a  movaps [rsp+0x10], xmm1
0000708296fdfb5f  movaps [rsp+0x20], xmm5
0000708296fdfb64  lea rdi, [rsp]
0000708296fdfb68  mov esi, 0x00
0000708296fdfb6d  mov rax, 0x64BBC686C530
0000708296fdfb77  call rax
0000708296fdfb79  movaps xmm15, [rsp]
0000708296fdfb7e  add rsp, 0x30
0000708296fdfb82  vmovaps xmm0, [rsp]
0000708296fdfb87  vmovaps xmm1, [rsp+0x10]
0000708296fdfb8d  vmovaps xmm2, [rsp+0x20]
0000708296fdfb93  vmovaps xmm3, [rsp+0x30]
0000708296fdfb99  vmovaps xmm4, [rsp+0x40]
0000708296fdfb9f  vmovaps xmm5, [rsp+0x50]
0000708296fdfba5  vmovaps xmm6, [rsp+0x60]
0000708296fdfbab  vmovaps xmm7, [rsp+0x70]
0000708296fdfbb1  vmovaps xmm8, [rsp+0x80]
0000708296fdfbba  vmovaps xmm9, [rsp+0x90]
0000708296fdfbc3  vmovaps xmm10, [rsp+0xA0]
0000708296fdfbcc  vmovaps xmm11, [rsp+0xB0]
0000708296fdfbd5  vmovaps xmm12, [rsp+0xC0]
0000708296fdfbde  vmovaps xmm13, [rsp+0xD0]
0000708296fdfbe7  vmovaps xmm14, [rsp+0xE0]
0000708296fdfbf0  add rsp, 0xF0
0000708296fdfbf7  pop r11
0000708296fdfbf9  pop r10
0000708296fdfbfb  pop r9
0000708296fdfbfd  pop r8
0000708296fdfbff  pop rsi
0000708296fdfc00  pop rdi
0000708296fdfc01  pop rdx
0000708296fdfc02  pop rcx
0000708296fdfc03  pop rax
0000708296fdfc04  add rsp, 0x08
0000708296fdfc08  jmp 0x0000708296FDC473
0000708296fdfc0d  call 0x0000708296EB52F0
0000708296fdfc12  jmp 0x0000708296FDC4CE
0000708296fdfc17  sub rsp, 0x08
0000708296fdfc1b  push rax
0000708296fdfc1c  push rcx
0000708296fdfc1d  push rdx
0000708296fdfc1e  push rdi
0000708296fdfc1f  push rsi
0000708296fdfc20  push r8
0000708296fdfc22  push r9
0000708296fdfc24  push r10
0000708296fdfc26  push r11
0000708296fdfc28  sub rsp, 0xF0
0000708296fdfc2f  vmovaps [rsp], xmm0
0000708296fdfc34  vmovaps [rsp+0x10], xmm1
0000708296fdfc3a  vmovaps [rsp+0x20], xmm2
0000708296fdfc40  vmovaps [rsp+0x30], xmm3
0000708296fdfc46  vmovaps [rsp+0x40], xmm4
0000708296fdfc4c  vmovaps [rsp+0x50], xmm5
0000708296fdfc52  vmovaps [rsp+0x60], xmm6
0000708296fdfc58  vmovaps [rsp+0x70], xmm7
0000708296fdfc5e  vmovaps [rsp+0x80], xmm8
0000708296fdfc67  vmovaps [rsp+0x90], xmm10
0000708296fdfc70  vmovaps [rsp+0xA0], xmm11
0000708296fdfc79  vmovaps [rsp+0xB0], xmm12
0000708296fdfc82  vmovaps [rsp+0xC0], xmm13
0000708296fdfc8b  vmovaps [rsp+0xD0], xmm14
0000708296fdfc94  vmovaps [rsp+0xE0], xmm15
0000708296fdfc9d  sub rsp, 0x30
0000708296fdfca1  movaps [rsp], xmm9
0000708296fdfca6  movaps [rsp+0x10], xmm8
0000708296fdfcac  movaps [rsp+0x20], xmm11
0000708296fdfcb2  lea rdi, [rsp]
0000708296fdfcb6  mov esi, 0x00
0000708296fdfcbb  mov rax, 0x64BBC686C530
0000708296fdfcc5  call rax
0000708296fdfcc7  movaps xmm9, [rsp]
0000708296fdfccc  add rsp, 0x30
0000708296fdfcd0  vmovaps xmm0, [rsp]
0000708296fdfcd5  vmovaps xmm1, [rsp+0x10]
0000708296fdfcdb  vmovaps xmm2, [rsp+0x20]
0000708296fdfce1  vmovaps xmm3, [rsp+0x30]
0000708296fdfce7  vmovaps xmm4, [rsp+0x40]
0000708296fdfced  vmovaps xmm5, [rsp+0x50]
0000708296fdfcf3  vmovaps xmm6, [rsp+0x60]
0000708296fdfcf9  vmovaps xmm7, [rsp+0x70]
0000708296fdfcff  vmovaps xmm8, [rsp+0x80]
0000708296fdfd08  vmovaps xmm10, [rsp+0x90]
0000708296fdfd11  vmovaps xmm11, [rsp+0xA0]
0000708296fdfd1a  vmovaps xmm12, [rsp+0xB0]
0000708296fdfd23  vmovaps xmm13, [rsp+0xC0]
0000708296fdfd2c  vmovaps xmm14, [rsp+0xD0]
0000708296fdfd35  vmovaps xmm15, [rsp+0xE0]
0000708296fdfd3e  add rsp, 0xF0
0000708296fdfd45  pop r11
0000708296fdfd47  pop r10
0000708296fdfd49  pop r9
0000708296fdfd4b  pop r8
0000708296fdfd4d  pop rsi
0000708296fdfd4e  pop rdi
0000708296fdfd4f  pop rdx
0000708296fdfd50  pop rcx
0000708296fdfd51  pop rax
0000708296fdfd52  add rsp, 0x08
0000708296fdfd56  jmp 0x0000708296FDC505
0000708296fdfd5b  sub rsp, 0x08
0000708296fdfd5f  push rax
0000708296fdfd60  push rcx
0000708296fdfd61  push rdx
0000708296fdfd62  push rdi
0000708296fdfd63  push rsi
0000708296fdfd64  push r8
0000708296fdfd66  push r9
0000708296fdfd68  push r10
0000708296fdfd6a  push r11
0000708296fdfd6c  sub rsp, 0xF0
0000708296fdfd73  vmovaps [rsp], xmm0
0000708296fdfd78  vmovaps [rsp+0x10], xmm1
0000708296fdfd7e  vmovaps [rsp+0x20], xmm2
0000708296fdfd84  vmovaps [rsp+0x30], xmm3
0000708296fdfd8a  vmovaps [rsp+0x40], xmm4
0000708296fdfd90  vmovaps [rsp+0x50], xmm5
0000708296fdfd96  vmovaps [rsp+0x60], xmm6
0000708296fdfd9c  vmovaps [rsp+0x70], xmm7
0000708296fdfda2  vmovaps [rsp+0x80], xmm8
0000708296fdfdab  vmovaps [rsp+0x90], xmm9
0000708296fdfdb4  vmovaps [rsp+0xA0], xmm10
0000708296fdfdbd  vmovaps [rsp+0xB0], xmm12
0000708296fdfdc6  vmovaps [rsp+0xC0], xmm13
0000708296fdfdcf  vmovaps [rsp+0xD0], xmm14
0000708296fdfdd8  vmovaps [rsp+0xE0], xmm15
0000708296fdfde1  sub rsp, 0x30
0000708296fdfde5  movaps [rsp], xmm11
0000708296fdfdea  movaps [rsp+0x10], xmm10
0000708296fdfdf0  movaps [rsp+0x20], xmm6
0000708296fdfdf5  lea rdi, [rsp]
0000708296fdfdf9  mov esi, 0x00
0000708296fdfdfe  mov rax, 0x64BBC686C530
0000708296fdfe08  call rax
0000708296fdfe0a  movaps xmm11, [rsp]
0000708296fdfe0f  add rsp, 0x30
0000708296fdfe13  vmovaps xmm0, [rsp]
0000708296fdfe18  vmovaps xmm1, [rsp+0x10]
0000708296fdfe1e  vmovaps xmm2, [rsp+0x20]
0000708296fdfe24  vmovaps xmm3, [rsp+0x30]
0000708296fdfe2a  vmovaps xmm4, [rsp+0x40]
0000708296fdfe30  vmovaps xmm5, [rsp+0x50]
0000708296fdfe36  vmovaps xmm6, [rsp+0x60]
0000708296fdfe3c  vmovaps xmm7, [rsp+0x70]
0000708296fdfe42  vmovaps xmm8, [rsp+0x80]
0000708296fdfe4b  vmovaps xmm9, [rsp+0x90]
0000708296fdfe54  vmovaps xmm10, [rsp+0xA0]
0000708296fdfe5d  vmovaps xmm12, [rsp+0xB0]
0000708296fdfe66  vmovaps xmm13, [rsp+0xC0]
0000708296fdfe6f  vmovaps xmm14, [rsp+0xD0]
0000708296fdfe78  vmovaps xmm15, [rsp+0xE0]
0000708296fdfe81  add rsp, 0xF0
0000708296fdfe88  pop r11
0000708296fdfe8a  pop r10
0000708296fdfe8c  pop r9
0000708296fdfe8e  pop r8
0000708296fdfe90  pop rsi
0000708296fdfe91  pop rdi
0000708296fdfe92  pop rdx
0000708296fdfe93  pop rcx
0000708296fdfe94  pop rax
0000708296fdfe95  add rsp, 0x08
0000708296fdfe99  jmp 0x0000708296FDC520
0000708296fdfe9e  sub rsp, 0x08
0000708296fdfea2  push rax
0000708296fdfea3  push rcx
0000708296fdfea4  push rdx
0000708296fdfea5  push rdi
0000708296fdfea6  push rsi
0000708296fdfea7  push r8
0000708296fdfea9  push r9
0000708296fdfeab  push r10
0000708296fdfead  push r11
0000708296fdfeaf  sub rsp, 0xF0
0000708296fdfeb6  vmovaps [rsp], xmm0
0000708296fdfebb  vmovaps [rsp+0x10], xmm1
0000708296fdfec1  vmovaps [rsp+0x20], xmm2
0000708296fdfec7  vmovaps [rsp+0x30], xmm3
0000708296fdfecd  vmovaps [rsp+0x40], xmm4
0000708296fdfed3  vmovaps [rsp+0x50], xmm5
0000708296fdfed9  vmovaps [rsp+0x60], xmm6
0000708296fdfedf  vmovaps [rsp+0x70], xmm7
0000708296fdfee5  vmovaps [rsp+0x80], xmm8
0000708296fdfeee  vmovaps [rsp+0x90], xmm9
0000708296fdfef7  vmovaps [rsp+0xA0], xmm11
0000708296fdff00  vmovaps [rsp+0xB0], xmm12
0000708296fdff09  vmovaps [rsp+0xC0], xmm13
0000708296fdff12  vmovaps [rsp+0xD0], xmm14
0000708296fdff1b  vmovaps [rsp+0xE0], xmm15
0000708296fdff24  sub rsp, 0x30
0000708296fdff28  movaps [rsp], xmm10
0000708296fdff2d  movaps [rsp+0x10], xmm14
0000708296fdff33  movaps [rsp+0x20], xmm4
0000708296fdff38  lea rdi, [rsp]
0000708296fdff3c  mov esi, 0x00
0000708296fdff41  mov rax, 0x64BBC686C530
0000708296fdff4b  call rax
0000708296fdff4d  movaps xmm10, [rsp]
0000708296fdff52  add rsp, 0x30
0000708296fdff56  vmovaps xmm0, [rsp]
0000708296fdff5b  vmovaps xmm1, [rsp+0x10]
0000708296fdff61  vmovaps xmm2, [rsp+0x20]
0000708296fdff67  vmovaps xmm3, [rsp+0x30]
0000708296fdff6d  vmovaps xmm4, [rsp+0x40]
0000708296fdff73  vmovaps xmm5, [rsp+0x50]
0000708296fdff79  vmovaps xmm6, [rsp+0x60]
0000708296fdff7f  vmovaps xmm7, [rsp+0x70]
0000708296fdff85  vmovaps xmm8, [rsp+0x80]
0000708296fdff8e  vmovaps xmm9, [rsp+0x90]
0000708296fdff97  vmovaps xmm11, [rsp+0xA0]
0000708296fdffa0  vmovaps xmm12, [rsp+0xB0]
0000708296fdffa9  vmovaps xmm13, [rsp+0xC0]
0000708296fdffb2  vmovaps xmm14, [rsp+0xD0]
0000708296fdffbb  vmovaps xmm15, [rsp+0xE0]
0000708296fdffc4  add rsp, 0xF0
0000708296fdffcb  pop r11
0000708296fdffcd  pop r10
0000708296fdffcf  pop r9
0000708296fdffd1  pop r8
0000708296fdffd3  pop rsi
0000708296fdffd4  pop rdi
0000708296fdffd5  pop rdx
0000708296fdffd6  pop rcx
0000708296fdffd7  pop rax
0000708296fdffd8  add rsp, 0x08
0000708296fdffdc  jmp 0x0000708296FDC53B
0000708296fdffe1  sub rsp, 0x08
0000708296fdffe5  push rax
0000708296fdffe6  push rcx
0000708296fdffe7  push rdx
0000708296fdffe8  push rdi
0000708296fdffe9  push rsi
0000708296fdffea  push r8
0000708296fdffec  push r9
0000708296fdffee  push r10
0000708296fdfff0  push r11
0000708296fdfff2  sub rsp, 0xF0
0000708296fdfff9  vmovaps [rsp], xmm0
0000708296fdfffe  vmovaps [rsp+0x10], xmm1
0000708296fe0004  vmovaps [rsp+0x20], xmm2
0000708296fe000a  vmovaps [rsp+0x30], xmm3
0000708296fe0010  vmovaps [rsp+0x40], xmm4
0000708296fe0016  vmovaps [rsp+0x50], xmm5
0000708296fe001c  vmovaps [rsp+0x60], xmm6
0000708296fe0022  vmovaps [rsp+0x70], xmm7
0000708296fe0028  vmovaps [rsp+0x80], xmm9
0000708296fe0031  vmovaps [rsp+0x90], xmm10
0000708296fe003a  vmovaps [rsp+0xA0], xmm11
0000708296fe0043  vmovaps [rsp+0xB0], xmm12
0000708296fe004c  vmovaps [rsp+0xC0], xmm13
0000708296fe0055  vmovaps [rsp+0xD0], xmm14
0000708296fe005e  vmovaps [rsp+0xE0], xmm15
0000708296fe0067  sub rsp, 0x30
0000708296fe006b  movaps [rsp], xmm8
0000708296fe0070  movaps [rsp+0x10], xmm1
0000708296fe0075  movaps [rsp+0x20], xmm14
0000708296fe007b  lea rdi, [rsp]
0000708296fe007f  mov esi, 0x00
0000708296fe0084  mov rax, 0x64BBC686C530
0000708296fe008e  call rax
0000708296fe0090  movaps xmm8, [rsp]
0000708296fe0095  add rsp, 0x30
0000708296fe0099  vmovaps xmm0, [rsp]
0000708296fe009e  vmovaps xmm1, [rsp+0x10]
0000708296fe00a4  vmovaps xmm2, [rsp+0x20]
0000708296fe00aa  vmovaps xmm3, [rsp+0x30]
0000708296fe00b0  vmovaps xmm4, [rsp+0x40]
0000708296fe00b6  vmovaps xmm5, [rsp+0x50]
0000708296fe00bc  vmovaps xmm6, [rsp+0x60]
0000708296fe00c2  vmovaps xmm7, [rsp+0x70]
0000708296fe00c8  vmovaps xmm9, [rsp+0x80]
0000708296fe00d1  vmovaps xmm10, [rsp+0x90]
0000708296fe00da  vmovaps xmm11, [rsp+0xA0]
0000708296fe00e3  vmovaps xmm12, [rsp+0xB0]
0000708296fe00ec  vmovaps xmm13, [rsp+0xC0]
0000708296fe00f5  vmovaps xmm14, [rsp+0xD0]
0000708296fe00fe  vmovaps xmm15, [rsp+0xE0]
0000708296fe0107  add rsp, 0xF0
0000708296fe010e  pop r11
0000708296fe0110  pop r10
0000708296fe0112  pop r9
0000708296fe0114  pop r8
0000708296fe0116  pop rsi
0000708296fe0117  pop rdi
0000708296fe0118  pop rdx
0000708296fe0119  pop rcx
0000708296fe011a  pop rax
0000708296fe011b  add rsp, 0x08
0000708296fe011f  jmp 0x0000708296FDC561
0000708296fe0124  sub rsp, 0x08
0000708296fe0128  push rax
0000708296fe0129  push rcx
0000708296fe012a  push rdx
0000708296fe012b  push rdi
0000708296fe012c  push rsi
0000708296fe012d  push r8
0000708296fe012f  push r9
0000708296fe0131  push r10
0000708296fe0133  push r11
0000708296fe0135  sub rsp, 0xF0
0000708296fe013c  vmovaps [rsp], xmm0
0000708296fe0141  vmovaps [rsp+0x10], xmm1
0000708296fe0147  vmovaps [rsp+0x20], xmm2
0000708296fe014d  vmovaps [rsp+0x30], xmm3
0000708296fe0153  vmovaps [rsp+0x40], xmm4
0000708296fe0159  vmovaps [rsp+0x50], xmm5
0000708296fe015f  vmovaps [rsp+0x60], xmm7
0000708296fe0165  vmovaps [rsp+0x70], xmm8
0000708296fe016b  vmovaps [rsp+0x80], xmm9
0000708296fe0174  vmovaps [rsp+0x90], xmm10
0000708296fe017d  vmovaps [rsp+0xA0], xmm11
0000708296fe0186  vmovaps [rsp+0xB0], xmm12
0000708296fe018f  vmovaps [rsp+0xC0], xmm13
0000708296fe0198  vmovaps [rsp+0xD0], xmm14
0000708296fe01a1  vmovaps [rsp+0xE0], xmm15
0000708296fe01aa  sub rsp, 0x30
0000708296fe01ae  movaps [rsp], xmm6
0000708296fe01b2  movaps [rsp+0x10], xmm1
0000708296fe01b7  movaps [rsp+0x20], xmm14
0000708296fe01bd  lea rdi, [rsp]
0000708296fe01c1  mov esi, 0x00
0000708296fe01c6  mov rax, 0x64BBC686C530
0000708296fe01d0  call rax
0000708296fe01d2  movaps xmm6, [rsp]
0000708296fe01d6  add rsp, 0x30
0000708296fe01da  vmovaps xmm0, [rsp]
0000708296fe01df  vmovaps xmm1, [rsp+0x10]
0000708296fe01e5  vmovaps xmm2, [rsp+0x20]
0000708296fe01eb  vmovaps xmm3, [rsp+0x30]
0000708296fe01f1  vmovaps xmm4, [rsp+0x40]
0000708296fe01f7  vmovaps xmm5, [rsp+0x50]
0000708296fe01fd  vmovaps xmm7, [rsp+0x60]
0000708296fe0203  vmovaps xmm8, [rsp+0x70]
0000708296fe0209  vmovaps xmm9, [rsp+0x80]
0000708296fe0212  vmovaps xmm10, [rsp+0x90]
0000708296fe021b  vmovaps xmm11, [rsp+0xA0]
0000708296fe0224  vmovaps xmm12, [rsp+0xB0]
0000708296fe022d  vmovaps xmm13, [rsp+0xC0]
0000708296fe0236  vmovaps xmm14, [rsp+0xD0]
0000708296fe023f  vmovaps xmm15, [rsp+0xE0]
0000708296fe0248  add rsp, 0xF0
0000708296fe024f  pop r11
0000708296fe0251  pop r10
0000708296fe0253  pop r9
0000708296fe0255  pop r8
0000708296fe0257  pop rsi
0000708296fe0258  pop rdi
0000708296fe0259  pop rdx
0000708296fe025a  pop rcx
0000708296fe025b  pop rax
0000708296fe025c  add rsp, 0x08
0000708296fe0260  jmp 0x0000708296FDC58D
0000708296fe0265  sub rsp, 0x08
0000708296fe0269  push rax
0000708296fe026a  push rcx
0000708296fe026b  push rdx
0000708296fe026c  push rdi
0000708296fe026d  push rsi
0000708296fe026e  push r8
0000708296fe0270  push r9
0000708296fe0272  push r10
0000708296fe0274  push r11
0000708296fe0276  sub rsp, 0xF0
0000708296fe027d  vmovaps [rsp], xmm0
0000708296fe0282  vmovaps [rsp+0x10], xmm1
0000708296fe0288  vmovaps [rsp+0x20], xmm2
0000708296fe028e  vmovaps [rsp+0x30], xmm3
0000708296fe0294  vmovaps [rsp+0x40], xmm4
0000708296fe029a  vmovaps [rsp+0x50], xmm5
0000708296fe02a0  vmovaps [rsp+0x60], xmm6
0000708296fe02a6  vmovaps [rsp+0x70], xmm7
0000708296fe02ac  vmovaps [rsp+0x80], xmm8
0000708296fe02b5  vmovaps [rsp+0x90], xmm9
0000708296fe02be  vmovaps [rsp+0xA0], xmm10
0000708296fe02c7  vmovaps [rsp+0xB0], xmm11
0000708296fe02d0  vmovaps [rsp+0xC0], xmm12
0000708296fe02d9  vmovaps [rsp+0xD0], xmm13
0000708296fe02e2  vmovaps [rsp+0xE0], xmm15
0000708296fe02eb  sub rsp, 0x30
0000708296fe02ef  movaps [rsp], xmm14
0000708296fe02f4  movaps [rsp+0x10], xmm12
0000708296fe02fa  movaps [rsp+0x20], xmm1
0000708296fe02ff  lea rdi, [rsp]
0000708296fe0303  mov esi, 0x00
0000708296fe0308  mov rax, 0x64BBC686C530
0000708296fe0312  call rax
0000708296fe0314  movaps xmm14, [rsp]
0000708296fe0319  add rsp, 0x30
0000708296fe031d  vmovaps xmm0, [rsp]
0000708296fe0322  vmovaps xmm1, [rsp+0x10]
0000708296fe0328  vmovaps xmm2, [rsp+0x20]
0000708296fe032e  vmovaps xmm3, [rsp+0x30]
0000708296fe0334  vmovaps xmm4, [rsp+0x40]
0000708296fe033a  vmovaps xmm5, [rsp+0x50]
0000708296fe0340  vmovaps xmm6, [rsp+0x60]
0000708296fe0346  vmovaps xmm7, [rsp+0x70]
0000708296fe034c  vmovaps xmm8, [rsp+0x80]
0000708296fe0355  vmovaps xmm9, [rsp+0x90]
0000708296fe035e  vmovaps xmm10, [rsp+0xA0]
0000708296fe0367  vmovaps xmm11, [rsp+0xB0]
0000708296fe0370  vmovaps xmm12, [rsp+0xC0]
0000708296fe0379  vmovaps xmm13, [rsp+0xD0]
0000708296fe0382  vmovaps xmm15, [rsp+0xE0]
0000708296fe038b  add rsp, 0xF0
0000708296fe0392  pop r11
0000708296fe0394  pop r10
0000708296fe0396  pop r9
0000708296fe0398  pop r8
0000708296fe039a  pop rsi
0000708296fe039b  pop rdi
0000708296fe039c  pop rdx
0000708296fe039d  pop rcx
0000708296fe039e  pop rax
0000708296fe039f  add rsp, 0x08
0000708296fe03a3  jmp 0x0000708296FDC5B3
0000708296fe03a8  sub rsp, 0x08
0000708296fe03ac  push rax
0000708296fe03ad  push rcx
0000708296fe03ae  push rdx
0000708296fe03af  push rdi
0000708296fe03b0  push rsi
0000708296fe03b1  push r8
0000708296fe03b3  push r9
0000708296fe03b5  push r10
0000708296fe03b7  push r11
0000708296fe03b9  sub rsp, 0xF0
0000708296fe03c0  vmovaps [rsp], xmm0
0000708296fe03c5  vmovaps [rsp+0x10], xmm2
0000708296fe03cb  vmovaps [rsp+0x20], xmm3
0000708296fe03d1  vmovaps [rsp+0x30], xmm4
0000708296fe03d7  vmovaps [rsp+0x40], xmm5
0000708296fe03dd  vmovaps [rsp+0x50], xmm6
0000708296fe03e3  vmovaps [rsp+0x60], xmm7
0000708296fe03e9  vmovaps [rsp+0x70], xmm8
0000708296fe03ef  vmovaps [rsp+0x80], xmm9
0000708296fe03f8  vmovaps [rsp+0x90], xmm10
0000708296fe0401  vmovaps [rsp+0xA0], xmm11
0000708296fe040a  vmovaps [rsp+0xB0], xmm12
0000708296fe0413  vmovaps [rsp+0xC0], xmm13
0000708296fe041c  vmovaps [rsp+0xD0], xmm14
0000708296fe0425  vmovaps [rsp+0xE0], xmm15
0000708296fe042e  sub rsp, 0x30
0000708296fe0432  movaps [rsp], xmm1
0000708296fe0436  movaps [rsp+0x10], xmm13
0000708296fe043c  movaps [rsp+0x20], xmm9
0000708296fe0442  lea rdi, [rsp]
0000708296fe0446  mov esi, 0x00
0000708296fe044b  mov rax, 0x64BBC686C530
0000708296fe0455  call rax
0000708296fe0457  movaps xmm1, [rsp]
0000708296fe045b  add rsp, 0x30
0000708296fe045f  vmovaps xmm0, [rsp]
0000708296fe0464  vmovaps xmm2, [rsp+0x10]
0000708296fe046a  vmovaps xmm3, [rsp+0x20]
0000708296fe0470  vmovaps xmm4, [rsp+0x30]
0000708296fe0476  vmovaps xmm5, [rsp+0x40]
0000708296fe047c  vmovaps xmm6, [rsp+0x50]
0000708296fe0482  vmovaps xmm7, [rsp+0x60]
0000708296fe0488  vmovaps xmm8, [rsp+0x70]
0000708296fe048e  vmovaps xmm9, [rsp+0x80]
0000708296fe0497  vmovaps xmm10, [rsp+0x90]
0000708296fe04a0  vmovaps xmm11, [rsp+0xA0]
0000708296fe04a9  vmovaps xmm12, [rsp+0xB0]
0000708296fe04b2  vmovaps xmm13, [rsp+0xC0]
0000708296fe04bb  vmovaps xmm14, [rsp+0xD0]
0000708296fe04c4  vmovaps xmm15, [rsp+0xE0]
0000708296fe04cd  add rsp, 0xF0
0000708296fe04d4  pop r11
0000708296fe04d6  pop r10
0000708296fe04d8  pop r9
0000708296fe04da  pop r8
0000708296fe04dc  pop rsi
0000708296fe04dd  pop rdi
0000708296fe04de  pop rdx
0000708296fe04df  pop rcx
0000708296fe04e0  pop rax
0000708296fe04e1  add rsp, 0x08
0000708296fe04e5  jmp 0x0000708296FDC5CD
0000708296fe04ea  sub rsp, 0x08
0000708296fe04ee  push rax
0000708296fe04ef  push rcx
0000708296fe04f0  push rdx
0000708296fe04f1  push rdi
0000708296fe04f2  push rsi
0000708296fe04f3  push r8
0000708296fe04f5  push r9
0000708296fe04f7  push r10
0000708296fe04f9  push r11
0000708296fe04fb  sub rsp, 0xF0
0000708296fe0502  vmovaps [rsp], xmm0
0000708296fe0507  vmovaps [rsp+0x10], xmm1
0000708296fe050d  vmovaps [rsp+0x20], xmm2
0000708296fe0513  vmovaps [rsp+0x30], xmm3
0000708296fe0519  vmovaps [rsp+0x40], xmm4
0000708296fe051f  vmovaps [rsp+0x50], xmm5
0000708296fe0525  vmovaps [rsp+0x60], xmm6
0000708296fe052b  vmovaps [rsp+0x70], xmm7
0000708296fe0531  vmovaps [rsp+0x80], xmm8
0000708296fe053a  vmovaps [rsp+0x90], xmm9
0000708296fe0543  vmovaps [rsp+0xA0], xmm10
0000708296fe054c  vmovaps [rsp+0xB0], xmm11
0000708296fe0555  vmovaps [rsp+0xC0], xmm13
0000708296fe055e  vmovaps [rsp+0xD0], xmm14
0000708296fe0567  vmovaps [rsp+0xE0], xmm15
0000708296fe0570  sub rsp, 0x30
0000708296fe0574  movaps [rsp], xmm12
0000708296fe0579  movaps [rsp+0x10], xmm7
0000708296fe057e  movaps [rsp+0x20], xmm13
0000708296fe0584  lea rdi, [rsp]
0000708296fe0588  mov esi, 0x00
0000708296fe058d  mov rax, 0x64BBC686C530
0000708296fe0597  call rax
0000708296fe0599  movaps xmm12, [rsp]
0000708296fe059e  add rsp, 0x30
0000708296fe05a2  vmovaps xmm0, [rsp]
0000708296fe05a7  vmovaps xmm1, [rsp+0x10]
0000708296fe05ad  vmovaps xmm2, [rsp+0x20]
0000708296fe05b3  vmovaps xmm3, [rsp+0x30]
0000708296fe05b9  vmovaps xmm4, [rsp+0x40]
0000708296fe05bf  vmovaps xmm5, [rsp+0x50]
0000708296fe05c5  vmovaps xmm6, [rsp+0x60]
0000708296fe05cb  vmovaps xmm7, [rsp+0x70]
0000708296fe05d1  vmovaps xmm8, [rsp+0x80]
0000708296fe05da  vmovaps xmm9, [rsp+0x90]
0000708296fe05e3  vmovaps xmm10, [rsp+0xA0]
0000708296fe05ec  vmovaps xmm11, [rsp+0xB0]
0000708296fe05f5  vmovaps xmm13, [rsp+0xC0]
0000708296fe05fe  vmovaps xmm14, [rsp+0xD0]
0000708296fe0607  vmovaps xmm15, [rsp+0xE0]
0000708296fe0610  add rsp, 0xF0
0000708296fe0617  pop r11
0000708296fe0619  pop r10
0000708296fe061b  pop r9
0000708296fe061d  pop r8
0000708296fe061f  pop rsi
0000708296fe0620  pop rdi
0000708296fe0621  pop rdx
0000708296fe0622  pop rcx
0000708296fe0623  pop rax
0000708296fe0624  add rsp, 0x08
0000708296fe0628  jmp 0x0000708296FDC5F4
0000708296fe062d  sub rsp, 0x08
0000708296fe0631  push rax
0000708296fe0632  push rcx
0000708296fe0633  push rdx
0000708296fe0634  push rdi
0000708296fe0635  push rsi
0000708296fe0636  push r8
0000708296fe0638  push r9
0000708296fe063a  push r10
0000708296fe063c  push r11
0000708296fe063e  sub rsp, 0xF0
0000708296fe0645  vmovaps [rsp], xmm0
0000708296fe064a  vmovaps [rsp+0x10], xmm1
0000708296fe0650  vmovaps [rsp+0x20], xmm2
0000708296fe0656  vmovaps [rsp+0x30], xmm3
0000708296fe065c  vmovaps [rsp+0x40], xmm4
0000708296fe0662  vmovaps [rsp+0x50], xmm5
0000708296fe0668  vmovaps [rsp+0x60], xmm6
0000708296fe066e  vmovaps [rsp+0x70], xmm7
0000708296fe0674  vmovaps [rsp+0x80], xmm8
0000708296fe067d  vmovaps [rsp+0x90], xmm9
0000708296fe0686  vmovaps [rsp+0xA0], xmm10
0000708296fe068f  vmovaps [rsp+0xB0], xmm11
0000708296fe0698  vmovaps [rsp+0xC0], xmm12
0000708296fe06a1  vmovaps [rsp+0xD0], xmm14
0000708296fe06aa  vmovaps [rsp+0xE0], xmm15
0000708296fe06b3  sub rsp, 0x30
0000708296fe06b7  movaps [rsp], xmm13
0000708296fe06bc  movaps [rsp+0x10], xmm15
0000708296fe06c2  movaps [rsp+0x20], xmm8
0000708296fe06c8  lea rdi, [rsp]
0000708296fe06cc  mov esi, 0x00
0000708296fe06d1  mov rax, 0x64BBC686C530
0000708296fe06db  call rax
0000708296fe06dd  movaps xmm13, [rsp]
0000708296fe06e2  add rsp, 0x30
0000708296fe06e6  vmovaps xmm0, [rsp]
0000708296fe06eb  vmovaps xmm1, [rsp+0x10]
0000708296fe06f1  vmovaps xmm2, [rsp+0x20]
0000708296fe06f7  vmovaps xmm3, [rsp+0x30]
0000708296fe06fd  vmovaps xmm4, [rsp+0x40]
0000708296fe0703  vmovaps xmm5, [rsp+0x50]
0000708296fe0709  vmovaps xmm6, [rsp+0x60]
0000708296fe070f  vmovaps xmm7, [rsp+0x70]
0000708296fe0715  vmovaps xmm8, [rsp+0x80]
0000708296fe071e  vmovaps xmm9, [rsp+0x90]
0000708296fe0727  vmovaps xmm10, [rsp+0xA0]
0000708296fe0730  vmovaps xmm11, [rsp+0xB0]
0000708296fe0739  vmovaps xmm12, [rsp+0xC0]
0000708296fe0742  vmovaps xmm14, [rsp+0xD0]
0000708296fe074b  vmovaps xmm15, [rsp+0xE0]
0000708296fe0754  add rsp, 0xF0
0000708296fe075b  pop r11
0000708296fe075d  pop r10
0000708296fe075f  pop r9
0000708296fe0761  pop r8
0000708296fe0763  pop rsi
0000708296fe0764  pop rdi
0000708296fe0765  pop rdx
0000708296fe0766  pop rcx
0000708296fe0767  pop rax
0000708296fe0768  add rsp, 0x08
0000708296fe076c  jmp 0x0000708296FDC60F
0000708296fe0771  sub rsp, 0x08
0000708296fe0775  push rax
0000708296fe0776  push rcx
0000708296fe0777  push rdx
0000708296fe0778  push rdi
0000708296fe0779  push rsi
0000708296fe077a  push r8
0000708296fe077c  push r9
0000708296fe077e  push r10
0000708296fe0780  push r11
0000708296fe0782  sub rsp, 0xF0
0000708296fe0789  vmovaps [rsp], xmm0
0000708296fe078e  vmovaps [rsp+0x10], xmm1
0000708296fe0794  vmovaps [rsp+0x20], xmm2
0000708296fe079a  vmovaps [rsp+0x30], xmm3
0000708296fe07a0  vmovaps [rsp+0x40], xmm4
0000708296fe07a6  vmovaps [rsp+0x50], xmm5
0000708296fe07ac  vmovaps [rsp+0x60], xmm6
0000708296fe07b2  vmovaps [rsp+0x70], xmm7
0000708296fe07b8  vmovaps [rsp+0x80], xmm9
0000708296fe07c1  vmovaps [rsp+0x90], xmm10
0000708296fe07ca  vmovaps [rsp+0xA0], xmm11
0000708296fe07d3  vmovaps [rsp+0xB0], xmm12
0000708296fe07dc  vmovaps [rsp+0xC0], xmm13
0000708296fe07e5  vmovaps [rsp+0xD0], xmm14
0000708296fe07ee  vmovaps [rsp+0xE0], xmm15
0000708296fe07f7  sub rsp, 0x30
0000708296fe07fb  movaps [rsp], xmm8
0000708296fe0800  movaps [rsp+0x10], xmm15
0000708296fe0806  movaps [rsp+0x20], xmm9
0000708296fe080c  lea rdi, [rsp]
0000708296fe0810  mov esi, 0x00
0000708296fe0815  mov rax, 0x64BBC686C530
0000708296fe081f  call rax
0000708296fe0821  movaps xmm8, [rsp]
0000708296fe0826  add rsp, 0x30
0000708296fe082a  vmovaps xmm0, [rsp]
0000708296fe082f  vmovaps xmm1, [rsp+0x10]
0000708296fe0835  vmovaps xmm2, [rsp+0x20]
0000708296fe083b  vmovaps xmm3, [rsp+0x30]
0000708296fe0841  vmovaps xmm4, [rsp+0x40]
0000708296fe0847  vmovaps xmm5, [rsp+0x50]
0000708296fe084d  vmovaps xmm6, [rsp+0x60]
0000708296fe0853  vmovaps xmm7, [rsp+0x70]
0000708296fe0859  vmovaps xmm9, [rsp+0x80]
0000708296fe0862  vmovaps xmm10, [rsp+0x90]
0000708296fe086b  vmovaps xmm11, [rsp+0xA0]
0000708296fe0874  vmovaps xmm12, [rsp+0xB0]
0000708296fe087d  vmovaps xmm13, [rsp+0xC0]
0000708296fe0886  vmovaps xmm14, [rsp+0xD0]
0000708296fe088f  vmovaps xmm15, [rsp+0xE0]
0000708296fe0898  add rsp, 0xF0
0000708296fe089f  pop r11
0000708296fe08a1  pop r10
0000708296fe08a3  pop r9
0000708296fe08a5  pop r8
0000708296fe08a7  pop rsi
0000708296fe08a8  pop rdi
0000708296fe08a9  pop rdx
0000708296fe08aa  pop rcx
0000708296fe08ab  pop rax
0000708296fe08ac  add rsp, 0x08
0000708296fe08b0  jmp 0x0000708296FDC63D
0000708296fe08b5  sub rsp, 0x08
0000708296fe08b9  push rax
0000708296fe08ba  push rcx
0000708296fe08bb  push rdx
0000708296fe08bc  push rdi
0000708296fe08bd  push rsi
0000708296fe08be  push r8
0000708296fe08c0  push r9
0000708296fe08c2  push r10
0000708296fe08c4  push r11
0000708296fe08c6  sub rsp, 0xF0
0000708296fe08cd  vmovaps [rsp], xmm0
0000708296fe08d2  vmovaps [rsp+0x10], xmm1
0000708296fe08d8  vmovaps [rsp+0x20], xmm2
0000708296fe08de  vmovaps [rsp+0x30], xmm3
0000708296fe08e4  vmovaps [rsp+0x40], xmm4
0000708296fe08ea  vmovaps [rsp+0x50], xmm5
0000708296fe08f0  vmovaps [rsp+0x60], xmm6
0000708296fe08f6  vmovaps [rsp+0x70], xmm7
0000708296fe08fc  vmovaps [rsp+0x80], xmm8
0000708296fe0905  vmovaps [rsp+0x90], xmm9
0000708296fe090e  vmovaps [rsp+0xA0], xmm10
0000708296fe0917  vmovaps [rsp+0xB0], xmm11
0000708296fe0920  vmovaps [rsp+0xC0], xmm12
0000708296fe0929  vmovaps [rsp+0xD0], xmm13
0000708296fe0932  vmovaps [rsp+0xE0], xmm14
0000708296fe093b  sub rsp, 0x30
0000708296fe093f  movaps [rsp], xmm15
0000708296fe0944  movaps [rsp+0x10], xmm11
0000708296fe094a  movaps [rsp+0x20], xmm6
0000708296fe094f  lea rdi, [rsp]
0000708296fe0953  mov esi, 0x00
0000708296fe0958  mov rax, 0x64BBC686C530
0000708296fe0962  call rax
0000708296fe0964  movaps xmm15, [rsp]
0000708296fe0969  add rsp, 0x30
0000708296fe096d  vmovaps xmm0, [rsp]
0000708296fe0972  vmovaps xmm1, [rsp+0x10]
0000708296fe0978  vmovaps xmm2, [rsp+0x20]
0000708296fe097e  vmovaps xmm3, [rsp+0x30]
0000708296fe0984  vmovaps xmm4, [rsp+0x40]
0000708296fe098a  vmovaps xmm5, [rsp+0x50]
0000708296fe0990  vmovaps xmm6, [rsp+0x60]
0000708296fe0996  vmovaps xmm7, [rsp+0x70]
0000708296fe099c  vmovaps xmm8, [rsp+0x80]
0000708296fe09a5  vmovaps xmm9, [rsp+0x90]
0000708296fe09ae  vmovaps xmm10, [rsp+0xA0]
0000708296fe09b7  vmovaps xmm11, [rsp+0xB0]
0000708296fe09c0  vmovaps xmm12, [rsp+0xC0]
0000708296fe09c9  vmovaps xmm13, [rsp+0xD0]
0000708296fe09d2  vmovaps xmm14, [rsp+0xE0]
0000708296fe09db  add rsp, 0xF0
0000708296fe09e2  pop r11
0000708296fe09e4  pop r10
0000708296fe09e6  pop r9
0000708296fe09e8  pop r8
0000708296fe09ea  pop rsi
0000708296fe09eb  pop rdi
0000708296fe09ec  pop rdx
0000708296fe09ed  pop rcx
0000708296fe09ee  pop rax
0000708296fe09ef  add rsp, 0x08
0000708296fe09f3  jmp 0x0000708296FDC658
0000708296fe09f8  sub rsp, 0x08
0000708296fe09fc  push rax
0000708296fe09fd  push rcx
0000708296fe09fe  push rdx
0000708296fe09ff  push rdi
0000708296fe0a00  push rsi
0000708296fe0a01  push r8
0000708296fe0a03  push r9
0000708296fe0a05  push r10
0000708296fe0a07  push r11
0000708296fe0a09  sub rsp, 0xF0
0000708296fe0a10  vmovaps [rsp], xmm0
0000708296fe0a15  vmovaps [rsp+0x10], xmm1
0000708296fe0a1b  vmovaps [rsp+0x20], xmm2
0000708296fe0a21  vmovaps [rsp+0x30], xmm3
0000708296fe0a27  vmovaps [rsp+0x40], xmm4
0000708296fe0a2d  vmovaps [rsp+0x50], xmm5
0000708296fe0a33  vmovaps [rsp+0x60], xmm6
0000708296fe0a39  vmovaps [rsp+0x70], xmm8
0000708296fe0a3f  vmovaps [rsp+0x80], xmm9
0000708296fe0a48  vmovaps [rsp+0x90], xmm10
0000708296fe0a51  vmovaps [rsp+0xA0], xmm11
0000708296fe0a5a  vmovaps [rsp+0xB0], xmm12
0000708296fe0a63  vmovaps [rsp+0xC0], xmm13
0000708296fe0a6c  vmovaps [rsp+0xD0], xmm14
0000708296fe0a75  vmovaps [rsp+0xE0], xmm15
0000708296fe0a7e  sub rsp, 0x30
0000708296fe0a82  movaps [rsp], xmm7
0000708296fe0a86  movaps [rsp+0x10], xmm11
0000708296fe0a8c  movaps [rsp+0x20], xmm9
0000708296fe0a92  lea rdi, [rsp]
0000708296fe0a96  mov esi, 0x00
0000708296fe0a9b  mov rax, 0x64BBC686C530
0000708296fe0aa5  call rax
0000708296fe0aa7  movaps xmm7, [rsp]
0000708296fe0aab  add rsp, 0x30
0000708296fe0aaf  vmovaps xmm0, [rsp]
0000708296fe0ab4  vmovaps xmm1, [rsp+0x10]
0000708296fe0aba  vmovaps xmm2, [rsp+0x20]
0000708296fe0ac0  vmovaps xmm3, [rsp+0x30]
0000708296fe0ac6  vmovaps xmm4, [rsp+0x40]
0000708296fe0acc  vmovaps xmm5, [rsp+0x50]
0000708296fe0ad2  vmovaps xmm6, [rsp+0x60]
0000708296fe0ad8  vmovaps xmm8, [rsp+0x70]
0000708296fe0ade  vmovaps xmm9, [rsp+0x80]
0000708296fe0ae7  vmovaps xmm10, [rsp+0x90]
0000708296fe0af0  vmovaps xmm11, [rsp+0xA0]
0000708296fe0af9  vmovaps xmm12, [rsp+0xB0]
0000708296fe0b02  vmovaps xmm13, [rsp+0xC0]
0000708296fe0b0b  vmovaps xmm14, [rsp+0xD0]
0000708296fe0b14  vmovaps xmm15, [rsp+0xE0]
0000708296fe0b1d  add rsp, 0xF0
0000708296fe0b24  pop r11
0000708296fe0b26  pop r10
0000708296fe0b28  pop r9
0000708296fe0b2a  pop r8
0000708296fe0b2c  pop rsi
0000708296fe0b2d  pop rdi
0000708296fe0b2e  pop rdx
0000708296fe0b2f  pop rcx
0000708296fe0b30  pop rax
0000708296fe0b31  add rsp, 0x08
0000708296fe0b35  jmp 0x0000708296FDC685
0000708296fe0b3a  sub rsp, 0x08
0000708296fe0b3e  push rax
0000708296fe0b3f  push rcx
0000708296fe0b40  push rdx
0000708296fe0b41  push rdi
0000708296fe0b42  push rsi
0000708296fe0b43  push r8
0000708296fe0b45  push r9
0000708296fe0b47  push r10
0000708296fe0b49  push r11
0000708296fe0b4b  sub rsp, 0xF0
0000708296fe0b52  vmovaps [rsp], xmm0
0000708296fe0b57  vmovaps [rsp+0x10], xmm1
0000708296fe0b5d  vmovaps [rsp+0x20], xmm2
0000708296fe0b63  vmovaps [rsp+0x30], xmm3
0000708296fe0b69  vmovaps [rsp+0x40], xmm4
0000708296fe0b6f  vmovaps [rsp+0x50], xmm5
0000708296fe0b75  vmovaps [rsp+0x60], xmm6
0000708296fe0b7b  vmovaps [rsp+0x70], xmm7
0000708296fe0b81  vmovaps [rsp+0x80], xmm8
0000708296fe0b8a  vmovaps [rsp+0x90], xmm9
0000708296fe0b93  vmovaps [rsp+0xA0], xmm10
0000708296fe0b9c  vmovaps [rsp+0xB0], xmm12
0000708296fe0ba5  vmovaps [rsp+0xC0], xmm13
0000708296fe0bae  vmovaps [rsp+0xD0], xmm14
0000708296fe0bb7  vmovaps [rsp+0xE0], xmm15
0000708296fe0bc0  sub rsp, 0x30
0000708296fe0bc4  movaps [rsp], xmm11
0000708296fe0bc9  movaps [rsp+0x10], xmm10
0000708296fe0bcf  movaps [rsp+0x20], xmm14
0000708296fe0bd5  lea rdi, [rsp]
0000708296fe0bd9  mov esi, 0x00
0000708296fe0bde  mov rax, 0x64BBC686C530
0000708296fe0be8  call rax
0000708296fe0bea  movaps xmm11, [rsp]
0000708296fe0bef  add rsp, 0x30
0000708296fe0bf3  vmovaps xmm0, [rsp]
0000708296fe0bf8  vmovaps xmm1, [rsp+0x10]
0000708296fe0bfe  vmovaps xmm2, [rsp+0x20]
0000708296fe0c04  vmovaps xmm3, [rsp+0x30]
0000708296fe0c0a  vmovaps xmm4, [rsp+0x40]
0000708296fe0c10  vmovaps xmm5, [rsp+0x50]
0000708296fe0c16  vmovaps xmm6, [rsp+0x60]
0000708296fe0c1c  vmovaps xmm7, [rsp+0x70]
0000708296fe0c22  vmovaps xmm8, [rsp+0x80]
0000708296fe0c2b  vmovaps xmm9, [rsp+0x90]
0000708296fe0c34  vmovaps xmm10, [rsp+0xA0]
0000708296fe0c3d  vmovaps xmm12, [rsp+0xB0]
0000708296fe0c46  vmovaps xmm13, [rsp+0xC0]
0000708296fe0c4f  vmovaps xmm14, [rsp+0xD0]
0000708296fe0c58  vmovaps xmm15, [rsp+0xE0]
0000708296fe0c61  add rsp, 0xF0
0000708296fe0c68  pop r11
0000708296fe0c6a  pop r10
0000708296fe0c6c  pop r9
0000708296fe0c6e  pop r8
0000708296fe0c70  pop rsi
0000708296fe0c71  pop rdi
0000708296fe0c72  pop rdx
0000708296fe0c73  pop rcx
0000708296fe0c74  pop rax
0000708296fe0c75  add rsp, 0x08
0000708296fe0c79  jmp 0x0000708296FDC6A0
0000708296fe0c7e  call 0x0000708296EC33A0
0000708296fe0c83  jmp 0x0000708296FDC6AA
0000708296fe0c88  sub rsp, 0x08
0000708296fe0c8c  push rax
0000708296fe0c8d  push rcx
0000708296fe0c8e  push rdx
0000708296fe0c8f  push rdi
0000708296fe0c90  push rsi
0000708296fe0c91  push r8
0000708296fe0c93  push r9
0000708296fe0c95  push r10
0000708296fe0c97  push r11
0000708296fe0c99  sub rsp, 0xF0
0000708296fe0ca0  vmovaps [rsp], xmm0
0000708296fe0ca5  vmovaps [rsp+0x10], xmm1
0000708296fe0cab  vmovaps [rsp+0x20], xmm2
0000708296fe0cb1  vmovaps [rsp+0x30], xmm3
0000708296fe0cb7  vmovaps [rsp+0x40], xmm4
0000708296fe0cbd  vmovaps [rsp+0x50], xmm5
0000708296fe0cc3  vmovaps [rsp+0x60], xmm6
0000708296fe0cc9  vmovaps [rsp+0x70], xmm7
0000708296fe0ccf  vmovaps [rsp+0x80], xmm8
0000708296fe0cd8  vmovaps [rsp+0x90], xmm9
0000708296fe0ce1  vmovaps [rsp+0xA0], xmm11
0000708296fe0cea  vmovaps [rsp+0xB0], xmm12
0000708296fe0cf3  vmovaps [rsp+0xC0], xmm13
0000708296fe0cfc  vmovaps [rsp+0xD0], xmm14
0000708296fe0d05  vmovaps [rsp+0xE0], xmm15
0000708296fe0d0e  sub rsp, 0x30
0000708296fe0d12  movaps [rsp], xmm10
0000708296fe0d17  movaps [rsp+0x10], xmm1
0000708296fe0d1c  movaps [rsp+0x20], xmm12
0000708296fe0d22  lea rdi, [rsp]
0000708296fe0d26  mov esi, 0x00
0000708296fe0d2b  mov rax, 0x64BBC686C530
0000708296fe0d35  call rax
0000708296fe0d37  movaps xmm10, [rsp]
0000708296fe0d3c  add rsp, 0x30
0000708296fe0d40  vmovaps xmm0, [rsp]
0000708296fe0d45  vmovaps xmm1, [rsp+0x10]
0000708296fe0d4b  vmovaps xmm2, [rsp+0x20]
0000708296fe0d51  vmovaps xmm3, [rsp+0x30]
0000708296fe0d57  vmovaps xmm4, [rsp+0x40]
0000708296fe0d5d  vmovaps xmm5, [rsp+0x50]
0000708296fe0d63  vmovaps xmm6, [rsp+0x60]
0000708296fe0d69  vmovaps xmm7, [rsp+0x70]
0000708296fe0d6f  vmovaps xmm8, [rsp+0x80]
0000708296fe0d78  vmovaps xmm9, [rsp+0x90]
0000708296fe0d81  vmovaps xmm11, [rsp+0xA0]
0000708296fe0d8a  vmovaps xmm12, [rsp+0xB0]
0000708296fe0d93  vmovaps xmm13, [rsp+0xC0]
0000708296fe0d9c  vmovaps xmm14, [rsp+0xD0]
0000708296fe0da5  vmovaps xmm15, [rsp+0xE0]
0000708296fe0dae  add rsp, 0xF0
0000708296fe0db5  pop r11
0000708296fe0db7  pop r10
0000708296fe0db9  pop r9
0000708296fe0dbb  pop r8
0000708296fe0dbd  pop rsi
0000708296fe0dbe  pop rdi
0000708296fe0dbf  pop rdx
0000708296fe0dc0  pop rcx
0000708296fe0dc1  pop rax
0000708296fe0dc2  add rsp, 0x08
0000708296fe0dc6  jmp 0x0000708296FDC6CD
0000708296fe0dcb  sub rsp, 0x08
0000708296fe0dcf  push rax
0000708296fe0dd0  push rcx
0000708296fe0dd1  push rdx
0000708296fe0dd2  push rdi
0000708296fe0dd3  push rsi
0000708296fe0dd4  push r8
0000708296fe0dd6  push r9
0000708296fe0dd8  push r10
0000708296fe0dda  push r11
0000708296fe0ddc  sub rsp, 0xF0
0000708296fe0de3  vmovaps [rsp], xmm0
0000708296fe0de8  vmovaps [rsp+0x10], xmm1
0000708296fe0dee  vmovaps [rsp+0x20], xmm2
0000708296fe0df4  vmovaps [rsp+0x30], xmm3
0000708296fe0dfa  vmovaps [rsp+0x40], xmm4
0000708296fe0e00  vmovaps [rsp+0x50], xmm5
0000708296fe0e06  vmovaps [rsp+0x60], xmm6
0000708296fe0e0c  vmovaps [rsp+0x70], xmm7
0000708296fe0e12  vmovaps [rsp+0x80], xmm8
0000708296fe0e1b  vmovaps [rsp+0x90], xmm9
0000708296fe0e24  vmovaps [rsp+0xA0], xmm10
0000708296fe0e2d  vmovaps [rsp+0xB0], xmm11
0000708296fe0e36  vmovaps [rsp+0xC0], xmm13
0000708296fe0e3f  vmovaps [rsp+0xD0], xmm14
0000708296fe0e48  vmovaps [rsp+0xE0], xmm15
0000708296fe0e51  sub rsp, 0x30
0000708296fe0e55  movaps [rsp], xmm12
0000708296fe0e5a  movaps [rsp+0x10], xmm14
0000708296fe0e60  movaps [rsp+0x20], xmm1
0000708296fe0e65  lea rdi, [rsp]
0000708296fe0e69  mov esi, 0x00
0000708296fe0e6e  mov rax, 0x64BBC686C530
0000708296fe0e78  call rax
0000708296fe0e7a  movaps xmm12, [rsp]
0000708296fe0e7f  add rsp, 0x30
0000708296fe0e83  vmovaps xmm0, [rsp]
0000708296fe0e88  vmovaps xmm1, [rsp+0x10]
0000708296fe0e8e  vmovaps xmm2, [rsp+0x20]
0000708296fe0e94  vmovaps xmm3, [rsp+0x30]
0000708296fe0e9a  vmovaps xmm4, [rsp+0x40]
0000708296fe0ea0  vmovaps xmm5, [rsp+0x50]
0000708296fe0ea6  vmovaps xmm6, [rsp+0x60]
0000708296fe0eac  vmovaps xmm7, [rsp+0x70]
0000708296fe0eb2  vmovaps xmm8, [rsp+0x80]
0000708296fe0ebb  vmovaps xmm9, [rsp+0x90]
0000708296fe0ec4  vmovaps xmm10, [rsp+0xA0]
0000708296fe0ecd  vmovaps xmm11, [rsp+0xB0]
0000708296fe0ed6  vmovaps xmm13, [rsp+0xC0]
0000708296fe0edf  vmovaps xmm14, [rsp+0xD0]
0000708296fe0ee8  vmovaps xmm15, [rsp+0xE0]
0000708296fe0ef1  add rsp, 0xF0
0000708296fe0ef8  pop r11
0000708296fe0efa  pop r10
0000708296fe0efc  pop r9
0000708296fe0efe  pop r8
0000708296fe0f00  pop rsi
0000708296fe0f01  pop rdi
0000708296fe0f02  pop rdx
0000708296fe0f03  pop rcx
0000708296fe0f04  pop rax
0000708296fe0f05  add rsp, 0x08
0000708296fe0f09  jmp 0x0000708296FDC6FC
0000708296fe0f0e  sub rsp, 0x08
0000708296fe0f12  push rax
0000708296fe0f13  push rcx
0000708296fe0f14  push rdx
0000708296fe0f15  push rdi
0000708296fe0f16  push rsi
0000708296fe0f17  push r8
0000708296fe0f19  push r9
0000708296fe0f1b  push r10
0000708296fe0f1d  push r11
0000708296fe0f1f  sub rsp, 0xF0
0000708296fe0f26  vmovaps [rsp], xmm0
0000708296fe0f2b  vmovaps [rsp+0x10], xmm1
0000708296fe0f31  vmovaps [rsp+0x20], xmm2
0000708296fe0f37  vmovaps [rsp+0x30], xmm3
0000708296fe0f3d  vmovaps [rsp+0x40], xmm4
0000708296fe0f43  vmovaps [rsp+0x50], xmm5
0000708296fe0f49  vmovaps [rsp+0x60], xmm6
0000708296fe0f4f  vmovaps [rsp+0x70], xmm7
0000708296fe0f55  vmovaps [rsp+0x80], xmm8
0000708296fe0f5e  vmovaps [rsp+0x90], xmm9
0000708296fe0f67  vmovaps [rsp+0xA0], xmm10
0000708296fe0f70  vmovaps [rsp+0xB0], xmm11
0000708296fe0f79  vmovaps [rsp+0xC0], xmm12
0000708296fe0f82  vmovaps [rsp+0xD0], xmm13
0000708296fe0f8b  vmovaps [rsp+0xE0], xmm15
0000708296fe0f94  sub rsp, 0x30
0000708296fe0f98  movaps [rsp], xmm14
0000708296fe0f9d  movaps [rsp+0x10], xmm9
0000708296fe0fa3  movaps [rsp+0x20], xmm1
0000708296fe0fa8  lea rdi, [rsp]
0000708296fe0fac  mov esi, 0x00
0000708296fe0fb1  mov rax, 0x64BBC686C530
0000708296fe0fbb  call rax
0000708296fe0fbd  movaps xmm14, [rsp]
0000708296fe0fc2  add rsp, 0x30
0000708296fe0fc6  vmovaps xmm0, [rsp]
0000708296fe0fcb  vmovaps xmm1, [rsp+0x10]
0000708296fe0fd1  vmovaps xmm2, [rsp+0x20]
0000708296fe0fd7  vmovaps xmm3, [rsp+0x30]
0000708296fe0fdd  vmovaps xmm4, [rsp+0x40]
0000708296fe0fe3  vmovaps xmm5, [rsp+0x50]
0000708296fe0fe9  vmovaps xmm6, [rsp+0x60]
0000708296fe0fef  vmovaps xmm7, [rsp+0x70]
0000708296fe0ff5  vmovaps xmm8, [rsp+0x80]
0000708296fe0ffe  vmovaps xmm9, [rsp+0x90]
0000708296fe1007  vmovaps xmm10, [rsp+0xA0]
0000708296fe1010  vmovaps xmm11, [rsp+0xB0]
0000708296fe1019  vmovaps xmm12, [rsp+0xC0]
0000708296fe1022  vmovaps xmm13, [rsp+0xD0]
0000708296fe102b  vmovaps xmm15, [rsp+0xE0]
0000708296fe1034  add rsp, 0xF0
0000708296fe103b  pop r11
0000708296fe103d  pop r10
0000708296fe103f  pop r9
0000708296fe1041  pop r8
0000708296fe1043  pop rsi
0000708296fe1044  pop rdi
0000708296fe1045  pop rdx
0000708296fe1046  pop rcx
0000708296fe1047  pop rax
0000708296fe1048  add rsp, 0x08
0000708296fe104c  jmp 0x0000708296FDC72B
0000708296fe1051  sub rsp, 0x08
0000708296fe1055  push rax
0000708296fe1056  push rcx
0000708296fe1057  push rdx
0000708296fe1058  push rdi
0000708296fe1059  push rsi
0000708296fe105a  push r8
0000708296fe105c  push r9
0000708296fe105e  push r10
0000708296fe1060  push r11
0000708296fe1062  sub rsp, 0xF0
0000708296fe1069  vmovaps [rsp], xmm0
0000708296fe106e  vmovaps [rsp+0x10], xmm2
0000708296fe1074  vmovaps [rsp+0x20], xmm3
0000708296fe107a  vmovaps [rsp+0x30], xmm4
0000708296fe1080  vmovaps [rsp+0x40], xmm5
0000708296fe1086  vmovaps [rsp+0x50], xmm6
0000708296fe108c  vmovaps [rsp+0x60], xmm7
0000708296fe1092  vmovaps [rsp+0x70], xmm8
0000708296fe1098  vmovaps [rsp+0x80], xmm9
0000708296fe10a1  vmovaps [rsp+0x90], xmm10
0000708296fe10aa  vmovaps [rsp+0xA0], xmm11
0000708296fe10b3  vmovaps [rsp+0xB0], xmm12
0000708296fe10bc  vmovaps [rsp+0xC0], xmm13
0000708296fe10c5  vmovaps [rsp+0xD0], xmm14
0000708296fe10ce  vmovaps [rsp+0xE0], xmm15
0000708296fe10d7  sub rsp, 0x30
0000708296fe10db  movaps [rsp], xmm1
0000708296fe10df  movaps [rsp+0x10], xmm13
0000708296fe10e5  movaps [rsp+0x20], xmm8
0000708296fe10eb  lea rdi, [rsp]
0000708296fe10ef  mov esi, 0x00
0000708296fe10f4  mov rax, 0x64BBC686C530
0000708296fe10fe  call rax
0000708296fe1100  movaps xmm1, [rsp]
0000708296fe1104  add rsp, 0x30
0000708296fe1108  vmovaps xmm0, [rsp]
0000708296fe110d  vmovaps xmm2, [rsp+0x10]
0000708296fe1113  vmovaps xmm3, [rsp+0x20]
0000708296fe1119  vmovaps xmm4, [rsp+0x30]
0000708296fe111f  vmovaps xmm5, [rsp+0x40]
0000708296fe1125  vmovaps xmm6, [rsp+0x50]
0000708296fe112b  vmovaps xmm7, [rsp+0x60]
0000708296fe1131  vmovaps xmm8, [rsp+0x70]
0000708296fe1137  vmovaps xmm9, [rsp+0x80]
0000708296fe1140  vmovaps xmm10, [rsp+0x90]
0000708296fe1149  vmovaps xmm11, [rsp+0xA0]
0000708296fe1152  vmovaps xmm12, [rsp+0xB0]
0000708296fe115b  vmovaps xmm13, [rsp+0xC0]
0000708296fe1164  vmovaps xmm14, [rsp+0xD0]
0000708296fe116d  vmovaps xmm15, [rsp+0xE0]
0000708296fe1176  add rsp, 0xF0
0000708296fe117d  pop r11
0000708296fe117f  pop r10
0000708296fe1181  pop r9
0000708296fe1183  pop r8
0000708296fe1185  pop rsi
0000708296fe1186  pop rdi
0000708296fe1187  pop rdx
0000708296fe1188  pop rcx
0000708296fe1189  pop rax
0000708296fe118a  add rsp, 0x08
0000708296fe118e  jmp 0x0000708296FDC74D
0000708296fe1193  call 0x0000708296E0C260
0000708296fe1198  jmp 0x0000708296FDC75B
0000708296fe119d  call 0x0000708296EBD750
0000708296fe11a2  jmp 0x0000708296FDC765
0000708296fe11a7  sub rsp, 0x08
0000708296fe11ab  push rax
0000708296fe11ac  push rcx
0000708296fe11ad  push rdx
0000708296fe11ae  push rdi
0000708296fe11af  push rsi
0000708296fe11b0  push r8
0000708296fe11b2  push r9
0000708296fe11b4  push r10
0000708296fe11b6  push r11
0000708296fe11b8  sub rsp, 0xF0
0000708296fe11bf  vmovaps [rsp], xmm0
0000708296fe11c4  vmovaps [rsp+0x10], xmm1
0000708296fe11ca  vmovaps [rsp+0x20], xmm2
0000708296fe11d0  vmovaps [rsp+0x30], xmm3
0000708296fe11d6  vmovaps [rsp+0x40], xmm4
0000708296fe11dc  vmovaps [rsp+0x50], xmm5
0000708296fe11e2  vmovaps [rsp+0x60], xmm6
0000708296fe11e8  vmovaps [rsp+0x70], xmm7
0000708296fe11ee  vmovaps [rsp+0x80], xmm9
0000708296fe11f7  vmovaps [rsp+0x90], xmm10
0000708296fe1200  vmovaps [rsp+0xA0], xmm11
0000708296fe1209  vmovaps [rsp+0xB0], xmm12
0000708296fe1212  vmovaps [rsp+0xC0], xmm13
0000708296fe121b  vmovaps [rsp+0xD0], xmm14
0000708296fe1224  vmovaps [rsp+0xE0], xmm15
0000708296fe122d  sub rsp, 0x30
0000708296fe1231  movaps [rsp], xmm8
0000708296fe1236  movaps [rsp+0x10], xmm15
0000708296fe123c  movaps [rsp+0x20], xmm7
0000708296fe1241  lea rdi, [rsp]
0000708296fe1245  mov esi, 0x00
0000708296fe124a  mov rax, 0x64BBC686C530
0000708296fe1254  call rax
0000708296fe1256  movaps xmm8, [rsp]
0000708296fe125b  add rsp, 0x30
0000708296fe125f  vmovaps xmm0, [rsp]
0000708296fe1264  vmovaps xmm1, [rsp+0x10]
0000708296fe126a  vmovaps xmm2, [rsp+0x20]
0000708296fe1270  vmovaps xmm3, [rsp+0x30]
0000708296fe1276  vmovaps xmm4, [rsp+0x40]
0000708296fe127c  vmovaps xmm5, [rsp+0x50]
0000708296fe1282  vmovaps xmm6, [rsp+0x60]
0000708296fe1288  vmovaps xmm7, [rsp+0x70]
0000708296fe128e  vmovaps xmm9, [rsp+0x80]
0000708296fe1297  vmovaps xmm10, [rsp+0x90]
0000708296fe12a0  vmovaps xmm11, [rsp+0xA0]
0000708296fe12a9  vmovaps xmm12, [rsp+0xB0]
0000708296fe12b2  vmovaps xmm13, [rsp+0xC0]
0000708296fe12bb  vmovaps xmm14, [rsp+0xD0]
0000708296fe12c4  vmovaps xmm15, [rsp+0xE0]
0000708296fe12cd  add rsp, 0xF0
0000708296fe12d4  pop r11
0000708296fe12d6  pop r10
0000708296fe12d8  pop r9
0000708296fe12da  pop r8
0000708296fe12dc  pop rsi
0000708296fe12dd  pop rdi
0000708296fe12de  pop rdx
0000708296fe12df  pop rcx
0000708296fe12e0  pop rax
0000708296fe12e1  add rsp, 0x08
0000708296fe12e5  jmp 0x0000708296FDC787
0000708296fe12ea  sub rsp, 0x08
0000708296fe12ee  push rax
0000708296fe12ef  push rcx
0000708296fe12f0  push rdx
0000708296fe12f1  push rdi
0000708296fe12f2  push rsi
0000708296fe12f3  push r8
0000708296fe12f5  push r9
0000708296fe12f7  push r10
0000708296fe12f9  push r11
0000708296fe12fb  sub rsp, 0xF0
0000708296fe1302  vmovaps [rsp], xmm0
0000708296fe1307  vmovaps [rsp+0x10], xmm1
0000708296fe130d  vmovaps [rsp+0x20], xmm2
0000708296fe1313  vmovaps [rsp+0x30], xmm3
0000708296fe1319  vmovaps [rsp+0x40], xmm4
0000708296fe131f  vmovaps [rsp+0x50], xmm5
0000708296fe1325  vmovaps [rsp+0x60], xmm6
0000708296fe132b  vmovaps [rsp+0x70], xmm8
0000708296fe1331  vmovaps [rsp+0x80], xmm9
0000708296fe133a  vmovaps [rsp+0x90], xmm10
0000708296fe1343  vmovaps [rsp+0xA0], xmm11
0000708296fe134c  vmovaps [rsp+0xB0], xmm12
0000708296fe1355  vmovaps [rsp+0xC0], xmm13
0000708296fe135e  vmovaps [rsp+0xD0], xmm14
0000708296fe1367  vmovaps [rsp+0xE0], xmm15
0000708296fe1370  sub rsp, 0x30
0000708296fe1374  movaps [rsp], xmm7
0000708296fe1378  movaps [rsp+0x10], xmm9
0000708296fe137e  movaps [rsp+0x20], xmm15
0000708296fe1384  lea rdi, [rsp]
0000708296fe1388  mov esi, 0x00
0000708296fe138d  mov rax, 0x64BBC686C530
0000708296fe1397  call rax
0000708296fe1399  movaps xmm7, [rsp]
0000708296fe139d  add rsp, 0x30
0000708296fe13a1  vmovaps xmm0, [rsp]
0000708296fe13a6  vmovaps xmm1, [rsp+0x10]
0000708296fe13ac  vmovaps xmm2, [rsp+0x20]
0000708296fe13b2  vmovaps xmm3, [rsp+0x30]
0000708296fe13b8  vmovaps xmm4, [rsp+0x40]
0000708296fe13be  vmovaps xmm5, [rsp+0x50]
0000708296fe13c4  vmovaps xmm6, [rsp+0x60]
0000708296fe13ca  vmovaps xmm8, [rsp+0x70]
0000708296fe13d0  vmovaps xmm9, [rsp+0x80]
0000708296fe13d9  vmovaps xmm10, [rsp+0x90]
0000708296fe13e2  vmovaps xmm11, [rsp+0xA0]
0000708296fe13eb  vmovaps xmm12, [rsp+0xB0]
0000708296fe13f4  vmovaps xmm13, [rsp+0xC0]
0000708296fe13fd  vmovaps xmm14, [rsp+0xD0]
0000708296fe1406  vmovaps xmm15, [rsp+0xE0]
0000708296fe140f  add rsp, 0xF0
0000708296fe1416  pop r11
0000708296fe1418  pop r10
0000708296fe141a  pop r9
0000708296fe141c  pop r8
0000708296fe141e  pop rsi
0000708296fe141f  pop rdi
0000708296fe1420  pop rdx
0000708296fe1421  pop rcx
0000708296fe1422  pop rax
0000708296fe1423  add rsp, 0x08
0000708296fe1427  jmp 0x0000708296FDC7B4
0000708296fe142c  sub rsp, 0x08
0000708296fe1430  push rax
0000708296fe1431  push rcx
0000708296fe1432  push rdx
0000708296fe1433  push rdi
0000708296fe1434  push rsi
0000708296fe1435  push r8
0000708296fe1437  push r9
0000708296fe1439  push r10
0000708296fe143b  push r11
0000708296fe143d  sub rsp, 0xF0
0000708296fe1444  vmovaps [rsp], xmm0
0000708296fe1449  vmovaps [rsp+0x10], xmm1
0000708296fe144f  vmovaps [rsp+0x20], xmm2
0000708296fe1455  vmovaps [rsp+0x30], xmm3
0000708296fe145b  vmovaps [rsp+0x40], xmm4
0000708296fe1461  vmovaps [rsp+0x50], xmm5
0000708296fe1467  vmovaps [rsp+0x60], xmm6
0000708296fe146d  vmovaps [rsp+0x70], xmm7
0000708296fe1473  vmovaps [rsp+0x80], xmm8
0000708296fe147c  vmovaps [rsp+0x90], xmm10
0000708296fe1485  vmovaps [rsp+0xA0], xmm11
0000708296fe148e  vmovaps [rsp+0xB0], xmm12
0000708296fe1497  vmovaps [rsp+0xC0], xmm13
0000708296fe14a0  vmovaps [rsp+0xD0], xmm14
0000708296fe14a9  vmovaps [rsp+0xE0], xmm15
0000708296fe14b2  sub rsp, 0x30
0000708296fe14b6  movaps [rsp], xmm9
0000708296fe14bb  movaps [rsp+0x10], xmm13
0000708296fe14c1  movaps [rsp+0x20], xmm15
0000708296fe14c7  lea rdi, [rsp]
0000708296fe14cb  mov esi, 0x00
0000708296fe14d0  mov rax, 0x64BBC686C530
0000708296fe14da  call rax
0000708296fe14dc  movaps xmm9, [rsp]
0000708296fe14e1  add rsp, 0x30
0000708296fe14e5  vmovaps xmm0, [rsp]
0000708296fe14ea  vmovaps xmm1, [rsp+0x10]
0000708296fe14f0  vmovaps xmm2, [rsp+0x20]
0000708296fe14f6  vmovaps xmm3, [rsp+0x30]
0000708296fe14fc  vmovaps xmm4, [rsp+0x40]
0000708296fe1502  vmovaps xmm5, [rsp+0x50]
0000708296fe1508  vmovaps xmm6, [rsp+0x60]
0000708296fe150e  vmovaps xmm7, [rsp+0x70]
0000708296fe1514  vmovaps xmm8, [rsp+0x80]
0000708296fe151d  vmovaps xmm10, [rsp+0x90]
0000708296fe1526  vmovaps xmm11, [rsp+0xA0]
0000708296fe152f  vmovaps xmm12, [rsp+0xB0]
0000708296fe1538  vmovaps xmm13, [rsp+0xC0]
0000708296fe1541  vmovaps xmm14, [rsp+0xD0]
0000708296fe154a  vmovaps xmm15, [rsp+0xE0]
0000708296fe1553  add rsp, 0xF0
0000708296fe155a  pop r11
0000708296fe155c  pop r10
0000708296fe155e  pop r9
0000708296fe1560  pop r8
0000708296fe1562  pop rsi
0000708296fe1563  pop rdi
0000708296fe1564  pop rdx
0000708296fe1565  pop rcx
0000708296fe1566  pop rax
0000708296fe1567  add rsp, 0x08
0000708296fe156b  jmp 0x0000708296FDC7E2
0000708296fe1570  sub rsp, 0x08
0000708296fe1574  push rax
0000708296fe1575  push rcx
0000708296fe1576  push rdx
0000708296fe1577  push rdi
0000708296fe1578  push rsi
0000708296fe1579  push r8
0000708296fe157b  push r9
0000708296fe157d  push r10
0000708296fe157f  push r11
0000708296fe1581  sub rsp, 0xF0
0000708296fe1588  vmovaps [rsp], xmm0
0000708296fe158d  vmovaps [rsp+0x10], xmm1
0000708296fe1593  vmovaps [rsp+0x20], xmm2
0000708296fe1599  vmovaps [rsp+0x30], xmm3
0000708296fe159f  vmovaps [rsp+0x40], xmm4
0000708296fe15a5  vmovaps [rsp+0x50], xmm5
0000708296fe15ab  vmovaps [rsp+0x60], xmm6
0000708296fe15b1  vmovaps [rsp+0x70], xmm7
0000708296fe15b7  vmovaps [rsp+0x80], xmm8
0000708296fe15c0  vmovaps [rsp+0x90], xmm9
0000708296fe15c9  vmovaps [rsp+0xA0], xmm10
0000708296fe15d2  vmovaps [rsp+0xB0], xmm11
0000708296fe15db  vmovaps [rsp+0xC0], xmm12
0000708296fe15e4  vmovaps [rsp+0xD0], xmm13
0000708296fe15ed  vmovaps [rsp+0xE0], xmm14
0000708296fe15f6  sub rsp, 0x30
0000708296fe15fa  movaps [rsp], xmm15
0000708296fe15ff  movaps [rsp+0x10], xmm11
0000708296fe1605  movaps [rsp+0x20], xmm12
0000708296fe160b  lea rdi, [rsp]
0000708296fe160f  mov esi, 0x00
0000708296fe1614  mov rax, 0x64BBC686C530
0000708296fe161e  call rax
0000708296fe1620  movaps xmm15, [rsp]
0000708296fe1625  add rsp, 0x30
0000708296fe1629  vmovaps xmm0, [rsp]
0000708296fe162e  vmovaps xmm1, [rsp+0x10]
0000708296fe1634  vmovaps xmm2, [rsp+0x20]
0000708296fe163a  vmovaps xmm3, [rsp+0x30]
0000708296fe1640  vmovaps xmm4, [rsp+0x40]
0000708296fe1646  vmovaps xmm5, [rsp+0x50]
0000708296fe164c  vmovaps xmm6, [rsp+0x60]
0000708296fe1652  vmovaps xmm7, [rsp+0x70]
0000708296fe1658  vmovaps xmm8, [rsp+0x80]
0000708296fe1661  vmovaps xmm9, [rsp+0x90]
0000708296fe166a  vmovaps xmm10, [rsp+0xA0]
0000708296fe1673  vmovaps xmm11, [rsp+0xB0]
0000708296fe167c  vmovaps xmm12, [rsp+0xC0]
0000708296fe1685  vmovaps xmm13, [rsp+0xD0]
0000708296fe168e  vmovaps xmm14, [rsp+0xE0]
0000708296fe1697  add rsp, 0xF0
0000708296fe169e  pop r11
0000708296fe16a0  pop r10
0000708296fe16a2  pop r9
0000708296fe16a4  pop r8
0000708296fe16a6  pop rsi
0000708296fe16a7  pop rdi
0000708296fe16a8  pop rdx
0000708296fe16a9  pop rcx
0000708296fe16aa  pop rax
0000708296fe16ab  add rsp, 0x08
0000708296fe16af  jmp 0x0000708296FDC7FD
0000708296fe16b4  sub rsp, 0x08
0000708296fe16b8  push rax
0000708296fe16b9  push rcx
0000708296fe16ba  push rdx
0000708296fe16bb  push rdi
0000708296fe16bc  push rsi
0000708296fe16bd  push r8
0000708296fe16bf  push r9
0000708296fe16c1  push r10
0000708296fe16c3  push r11
0000708296fe16c5  sub rsp, 0xF0
0000708296fe16cc  vmovaps [rsp], xmm0
0000708296fe16d1  vmovaps [rsp+0x10], xmm1
0000708296fe16d7  vmovaps [rsp+0x20], xmm2
0000708296fe16dd  vmovaps [rsp+0x30], xmm3
0000708296fe16e3  vmovaps [rsp+0x40], xmm4
0000708296fe16e9  vmovaps [rsp+0x50], xmm5
0000708296fe16ef  vmovaps [rsp+0x60], xmm6
0000708296fe16f5  vmovaps [rsp+0x70], xmm7
0000708296fe16fb  vmovaps [rsp+0x80], xmm8
0000708296fe1704  vmovaps [rsp+0x90], xmm9
0000708296fe170d  vmovaps [rsp+0xA0], xmm10
0000708296fe1716  vmovaps [rsp+0xB0], xmm11
0000708296fe171f  vmovaps [rsp+0xC0], xmm12
0000708296fe1728  vmovaps [rsp+0xD0], xmm14
0000708296fe1731  vmovaps [rsp+0xE0], xmm15
0000708296fe173a  sub rsp, 0x30
0000708296fe173e  movaps [rsp], xmm13
0000708296fe1743  movaps [rsp+0x10], xmm10
0000708296fe1749  movaps [rsp+0x20], xmm14
0000708296fe174f  lea rdi, [rsp]
0000708296fe1753  mov esi, 0x00
0000708296fe1758  mov rax, 0x64BBC686C530
0000708296fe1762  call rax
0000708296fe1764  movaps xmm13, [rsp]
0000708296fe1769  add rsp, 0x30
0000708296fe176d  vmovaps xmm0, [rsp]
0000708296fe1772  vmovaps xmm1, [rsp+0x10]
0000708296fe1778  vmovaps xmm2, [rsp+0x20]
0000708296fe177e  vmovaps xmm3, [rsp+0x30]
0000708296fe1784  vmovaps xmm4, [rsp+0x40]
0000708296fe178a  vmovaps xmm5, [rsp+0x50]
0000708296fe1790  vmovaps xmm6, [rsp+0x60]
0000708296fe1796  vmovaps xmm7, [rsp+0x70]
0000708296fe179c  vmovaps xmm8, [rsp+0x80]
0000708296fe17a5  vmovaps xmm9, [rsp+0x90]
0000708296fe17ae  vmovaps xmm10, [rsp+0xA0]
0000708296fe17b7  vmovaps xmm11, [rsp+0xB0]
0000708296fe17c0  vmovaps xmm12, [rsp+0xC0]
0000708296fe17c9  vmovaps xmm14, [rsp+0xD0]
0000708296fe17d2  vmovaps xmm15, [rsp+0xE0]
0000708296fe17db  add rsp, 0xF0
0000708296fe17e2  pop r11
0000708296fe17e4  pop r10
0000708296fe17e6  pop r9
0000708296fe17e8  pop r8
0000708296fe17ea  pop rsi
0000708296fe17eb  pop rdi
0000708296fe17ec  pop rdx
0000708296fe17ed  pop rcx
0000708296fe17ee  pop rax
0000708296fe17ef  add rsp, 0x08
0000708296fe17f3  jmp 0x0000708296FDC820
0000708296fe17f8  sub rsp, 0x08
0000708296fe17fc  push rax
0000708296fe17fd  push rcx
0000708296fe17fe  push rdx
0000708296fe17ff  push rdi
0000708296fe1800  push rsi
0000708296fe1801  push r8
0000708296fe1803  push r9
0000708296fe1805  push r10
0000708296fe1807  push r11
0000708296fe1809  sub rsp, 0xF0
0000708296fe1810  vmovaps [rsp], xmm0
0000708296fe1815  vmovaps [rsp+0x10], xmm1
0000708296fe181b  vmovaps [rsp+0x20], xmm2
0000708296fe1821  vmovaps [rsp+0x30], xmm3
0000708296fe1827  vmovaps [rsp+0x40], xmm4
0000708296fe182d  vmovaps [rsp+0x50], xmm5
0000708296fe1833  vmovaps [rsp+0x60], xmm6
0000708296fe1839  vmovaps [rsp+0x70], xmm7
0000708296fe183f  vmovaps [rsp+0x80], xmm8
0000708296fe1848  vmovaps [rsp+0x90], xmm9
0000708296fe1851  vmovaps [rsp+0xA0], xmm10
0000708296fe185a  vmovaps [rsp+0xB0], xmm11
0000708296fe1863  vmovaps [rsp+0xC0], xmm12
0000708296fe186c  vmovaps [rsp+0xD0], xmm13
0000708296fe1875  vmovaps [rsp+0xE0], xmm15
0000708296fe187e  sub rsp, 0x30
0000708296fe1882  movaps [rsp], xmm14
0000708296fe1887  movaps [rsp+0x10], xmm1
0000708296fe188c  movaps [rsp+0x20], xmm7
0000708296fe1891  lea rdi, [rsp]
0000708296fe1895  mov esi, 0x00
0000708296fe189a  mov rax, 0x64BBC686C530
0000708296fe18a4  call rax
0000708296fe18a6  movaps xmm14, [rsp]
0000708296fe18ab  add rsp, 0x30
0000708296fe18af  vmovaps xmm0, [rsp]
0000708296fe18b4  vmovaps xmm1, [rsp+0x10]
0000708296fe18ba  vmovaps xmm2, [rsp+0x20]
0000708296fe18c0  vmovaps xmm3, [rsp+0x30]
0000708296fe18c6  vmovaps xmm4, [rsp+0x40]
0000708296fe18cc  vmovaps xmm5, [rsp+0x50]
0000708296fe18d2  vmovaps xmm6, [rsp+0x60]
0000708296fe18d8  vmovaps xmm7, [rsp+0x70]
0000708296fe18de  vmovaps xmm8, [rsp+0x80]
0000708296fe18e7  vmovaps xmm9, [rsp+0x90]
0000708296fe18f0  vmovaps xmm10, [rsp+0xA0]
0000708296fe18f9  vmovaps xmm11, [rsp+0xB0]
0000708296fe1902  vmovaps xmm12, [rsp+0xC0]
0000708296fe190b  vmovaps xmm13, [rsp+0xD0]
0000708296fe1914  vmovaps xmm15, [rsp+0xE0]
0000708296fe191d  add rsp, 0xF0
0000708296fe1924  pop r11
0000708296fe1926  pop r10
0000708296fe1928  pop r9
0000708296fe192a  pop r8
0000708296fe192c  pop rsi
0000708296fe192d  pop rdi
0000708296fe192e  pop rdx
0000708296fe192f  pop rcx
0000708296fe1930  pop rax
0000708296fe1931  add rsp, 0x08
0000708296fe1935  jmp 0x0000708296FDC843
0000708296fe193a  sub rsp, 0x08
0000708296fe193e  push rax
0000708296fe193f  push rcx
0000708296fe1940  push rdx
0000708296fe1941  push rdi
0000708296fe1942  push rsi
0000708296fe1943  push r8
0000708296fe1945  push r9
0000708296fe1947  push r10
0000708296fe1949  push r11
0000708296fe194b  sub rsp, 0xF0
0000708296fe1952  vmovaps [rsp], xmm0
0000708296fe1957  vmovaps [rsp+0x10], xmm2
0000708296fe195d  vmovaps [rsp+0x20], xmm3
0000708296fe1963  vmovaps [rsp+0x30], xmm4
0000708296fe1969  vmovaps [rsp+0x40], xmm5
0000708296fe196f  vmovaps [rsp+0x50], xmm6
0000708296fe1975  vmovaps [rsp+0x60], xmm7
0000708296fe197b  vmovaps [rsp+0x70], xmm8
0000708296fe1981  vmovaps [rsp+0x80], xmm9
0000708296fe198a  vmovaps [rsp+0x90], xmm10
0000708296fe1993  vmovaps [rsp+0xA0], xmm11
0000708296fe199c  vmovaps [rsp+0xB0], xmm12
0000708296fe19a5  vmovaps [rsp+0xC0], xmm13
0000708296fe19ae  vmovaps [rsp+0xD0], xmm14
0000708296fe19b7  vmovaps [rsp+0xE0], xmm15
0000708296fe19c0  sub rsp, 0x30
0000708296fe19c4  movaps [rsp], xmm1
0000708296fe19c8  movaps [rsp+0x10], xmm8
0000708296fe19ce  movaps [rsp+0x20], xmm9
0000708296fe19d4  lea rdi, [rsp]
0000708296fe19d8  mov esi, 0x00
0000708296fe19dd  mov rax, 0x64BBC686C530
0000708296fe19e7  call rax
0000708296fe19e9  movaps xmm1, [rsp]
0000708296fe19ed  add rsp, 0x30
0000708296fe19f1  vmovaps xmm0, [rsp]
0000708296fe19f6  vmovaps xmm2, [rsp+0x10]
0000708296fe19fc  vmovaps xmm3, [rsp+0x20]
0000708296fe1a02  vmovaps xmm4, [rsp+0x30]
0000708296fe1a08  vmovaps xmm5, [rsp+0x40]
0000708296fe1a0e  vmovaps xmm6, [rsp+0x50]
0000708296fe1a14  vmovaps xmm7, [rsp+0x60]
0000708296fe1a1a  vmovaps xmm8, [rsp+0x70]
0000708296fe1a20  vmovaps xmm9, [rsp+0x80]
0000708296fe1a29  vmovaps xmm10, [rsp+0x90]
0000708296fe1a32  vmovaps xmm11, [rsp+0xA0]
0000708296fe1a3b  vmovaps xmm12, [rsp+0xB0]
0000708296fe1a44  vmovaps xmm13, [rsp+0xC0]
0000708296fe1a4d  vmovaps xmm14, [rsp+0xD0]
0000708296fe1a56  vmovaps xmm15, [rsp+0xE0]
0000708296fe1a5f  add rsp, 0xF0
0000708296fe1a66  pop r11
0000708296fe1a68  pop r10
0000708296fe1a6a  pop r9
0000708296fe1a6c  pop r8
0000708296fe1a6e  pop rsi
0000708296fe1a6f  pop rdi
0000708296fe1a70  pop rdx
0000708296fe1a71  pop rcx
0000708296fe1a72  pop rax
0000708296fe1a73  add rsp, 0x08
0000708296fe1a77  jmp 0x0000708296FDC865
0000708296fe1a7c  call 0x0000708296EE5940
0000708296fe1a81  jmp 0x0000708296FDC873
0000708296fe1a86  call 0x0000708296E0C380
0000708296fe1a8b  jmp 0x0000708296FDC87D
0000708296fe1a90  call 0x0000708296E0D600
0000708296fe1a95  jmp 0x0000708296FDC887
0000708296fe1a9a  call 0x0000708296DFF540
0000708296fe1a9f  jmp 0x0000708296FDC891
0000708296fe1aa4  int3
0000708296fe1aa5  nop [rax+rax*1], ax
0000708296fe1aae  nop
0000708296fe1ab0  mov rax, [r15+0xF8]
0000708296fe1ab7  lea r14, [rax+0x140]
0000708296fe1abe  mov r12, [r13+r14*1]
0000708296fe1ac3  mov [r15+0xE8], r12
0000708296fe1aca  lea r14, [rax+0x130]
0000708296fe1ad1  mov r12, [r13+r14*1]
0000708296fe1ad6  lea r14, [rax+0x138]
0000708296fe1add  mov r11, [r13+r14*1]
0000708296fe1ae2  movq xmm1, r12
0000708296fe1ae7  movq xmm15, r11
0000708296fe1aec  movq xmm1, xmm1
0000708296fe1af0  movq xmm1, xmm1
0000708296fe1af4  movaps [r15+0x1A0], xmm1
0000708296fe1afc  movq xmm15, xmm15
0000708296fe1b01  movq xmm15, xmm15
0000708296fe1b06  movaps [r15+0x190], xmm15
0000708296fe1b0e  lea r14, [rax+0x120]
0000708296fe1b15  mov r12, [r13+r14*1]
0000708296fe1b1a  lea r14, [rax+0x128]
0000708296fe1b21  mov r11, [r13+r14*1]
0000708296fe1b26  movq xmm1, r12
0000708296fe1b2b  movq xmm15, r11
0000708296fe1b30  movq xmm1, xmm1
0000708296fe1b34  movq xmm1, xmm1
0000708296fe1b38  movaps [r15+0x1C0], xmm1
0000708296fe1b40  movq xmm15, xmm15
0000708296fe1b45  movq xmm15, xmm15
0000708296fe1b4a  movaps [r15+0x1B0], xmm15
0000708296fe1b52  lea r14, [rax+0x110]
0000708296fe1b59  mov r12, [r13+r14*1]
0000708296fe1b5e  lea r14, [rax+0x118]
0000708296fe1b65  mov r11, [r13+r14*1]
0000708296fe1b6a  movq xmm1, r12
0000708296fe1b6f  movq xmm15, r11
0000708296fe1b74  movq xmm1, xmm1
0000708296fe1b78  movq xmm1, xmm1
0000708296fe1b7c  movaps [r15+0x1E0], xmm1
0000708296fe1b84  movq xmm15, xmm15
0000708296fe1b89  movq xmm15, xmm15
0000708296fe1b8e  movaps [r15+0x1D0], xmm15
0000708296fe1b96  lea r14, [rax+0x100]
0000708296fe1b9d  mov r12, [r13+r14*1]
0000708296fe1ba2  lea r14, [rax+0x108]
0000708296fe1ba9  mov r11, [r13+r14*1]
0000708296fe1bae  movq xmm1, r12
0000708296fe1bb3  movq xmm15, r11
0000708296fe1bb8  movq xmm1, xmm1
0000708296fe1bbc  movq xmm1, xmm1
0000708296fe1bc0  movaps [r15+0x200], xmm1
0000708296fe1bc8  movq xmm15, xmm15
0000708296fe1bcd  movq xmm15, xmm15
0000708296fe1bd2  movaps [r15+0x1F0], xmm15
0000708296fe1bda  mov qword ptr [r15+0x40], 0x430000
0000708296fe1be2  mov r14d, 0x430510
0000708296fe1be8  mov r12, [r13+r14*1]
0000708296fe1bed  movq xmm1, r12
0000708296fe1bf2  lea r14, [rax+0x150]
0000708296fe1bf9  mov [r15+0xF8], r14
0000708296fe1c00  mov rax, [r15+0x50]
0000708296fe1c04  movups xmm15, [r13+rax*1]
0000708296fe1c0a  movaps [r15+0x120], xmm15
0000708296fe1c12  mov qword ptr [r15+0x48], 0x10
0000708296fe1c1a  xor eax, eax
0000708296fe1c1c  mov r14d, 0x10
0000708296fe1c22  mov r12d, 0x200
0000708296fe1c28  cmp r14, r12
0000708296fe1c2b  cmc
0000708296fe1c2c  lahf
0000708296fe1c2d  seto al
0000708296fe1c30  mov [r15+0x108], eax
0000708296fe1c37  pextrq rax, xmm15, 0x01
0000708296fe1c3e  movq xmm14, rax
0000708296fe1c43  movaps [r15+0x130], xmm14
0000708296fe1c4b  movq rax, xmm1
0000708296fe1c50  movq r14, xmm15
0000708296fe1c55  vmovq xmm1, rax
0000708296fe1c5a  vmovq xmm15, r14
0000708296fe1c5f  movaps xmm13, xmm1
0000708296fe1c63  addsd xmm13, xmm15
0000708296fe1c68  ucomisd xmm13, xmm13
0000708296fe1c6d  jp 0x0000708296FE1D86
0000708296fe1c73  movq xmm13, xmm13
0000708296fe1c78  movq rax, xmm13
0000708296fe1c7d  movq r14, xmm14
0000708296fe1c82  vmovq xmm1, rax
0000708296fe1c87  vmovq xmm15, r14
0000708296fe1c8c  movaps xmm14, xmm1
0000708296fe1c90  addsd xmm14, xmm15
0000708296fe1c95  ucomisd xmm14, xmm14
0000708296fe1c9a  jp 0x0000708296FE1DCE
0000708296fe1ca0  movq xmm14, xmm14
0000708296fe1ca5  movaps [r15+0x110], xmm14
0000708296fe1cad  mov eax, [r15+0x108]
0000708296fe1cb4  sahf
0000708296fe1cb5  jnz 0x0000708296FE1CE7
0000708296fe1cb7  cmp dword ptr [r15+0x318], 0x00
0000708296fe1cbf  jz 0x0000708296FE1FE0
0000708296fe1cc5  nop [rax+rax*1], ax
0000708296fe1cce  nop [rax+rax*1], eax
0000708296fe1cd6  mov eax, 0x410490
0000708296fe1cdb  mov [r15+0x100], rax
0000708296fe1ce2  jmp 0x0000708296DFE110
0000708296fe1ce7  cmp dword ptr [r15+0x318], 0x00
0000708296fe1cef  jz 0x0000708296FE1E20
0000708296fe1cf5  nop [rax+rax*1], ax
0000708296fe1cfe  nop [rax+rax*1], eax
0000708296fe1d06  mov eax, 0x410474
0000708296fe1d0b  mov [r15+0x100], rax
0000708296fe1d12  jmp 0x0000708296DFE110
0000708296fe1d17  int3
0000708296fe1d18  call 0x0000708296EE27E0
0000708296fe1d1d  jmp 0x0000708296FE1AC3
0000708296fe1d22  call 0x0000708296EE27E0
0000708296fe1d27  jmp 0x0000708296FE1AD6
0000708296fe1d2c  call 0x0000708296EE1570
0000708296fe1d31  jmp 0x0000708296FE1AE2
0000708296fe1d36  call 0x0000708296EE27E0
0000708296fe1d3b  jmp 0x0000708296FE1B1A
0000708296fe1d40  call 0x0000708296EE1570
0000708296fe1d45  jmp 0x0000708296FE1B26
0000708296fe1d4a  call 0x0000708296EE27E0
0000708296fe1d4f  jmp 0x0000708296FE1B5E
0000708296fe1d54  call 0x0000708296EE1570
0000708296fe1d59  jmp 0x0000708296FE1B6A
0000708296fe1d5e  call 0x0000708296EE27E0
0000708296fe1d63  jmp 0x0000708296FE1BA2
0000708296fe1d68  call 0x0000708296EE1570
0000708296fe1d6d  jmp 0x0000708296FE1BAE
0000708296fe1d72  call 0x0000708296EE27E0
0000708296fe1d77  jmp 0x0000708296FE1BED
0000708296fe1d7c  call 0x0000708296E0E760
0000708296fe1d81  jmp 0x0000708296FE1C0A
0000708296fe1d86  ucomisd xmm1, xmm15
0000708296fe1d8b  jp 0x0000708296FE1D9A
0000708296fe1d8d  movaps xmm13, [0x0000708296BFE060]
0000708296fe1d95  jmp 0x0000708296FE1C73
0000708296fe1d9a  vxorps xmm0, xmm1, xmm15
0000708296fe1d9f  pextrw eax, xmm0, 0x03
0000708296fe1da4  and eax, 0x7FF8
0000708296fe1da9  cmp eax, 0x08
0000708296fe1dac  jnz 0x0000708296FE1C73
0000708296fe1db2  movq rax, xmm15
0000708296fe1db7  shl rax, 0x0D
0000708296fe1dbb  jbe 0x0000708296FE1C73
0000708296fe1dc1  vorps xmm13, xmm15, [0x0000708296BFE070]
0000708296fe1dc9  jmp 0x0000708296FE1C73
0000708296fe1dce  ucomisd xmm1, xmm15
0000708296fe1dd3  jp 0x0000708296FE1DE2
0000708296fe1dd5  movaps xmm14, [0x0000708296BFE060]
0000708296fe1ddd  jmp 0x0000708296FE1CA0
0000708296fe1de2  vxorps xmm0, xmm1, xmm15
0000708296fe1de7  pextrw eax, xmm0, 0x03
0000708296fe1dec  and eax, 0x7FF8
0000708296fe1df1  cmp eax, 0x08
0000708296fe1df4  jnz 0x0000708296FE1CA0
0000708296fe1dfa  movq rax, xmm15
0000708296fe1dff  shl rax, 0x0D
0000708296fe1e03  jbe 0x0000708296FE1CA0
0000708296fe1e09  vorps xmm14, xmm15, [0x0000708296BFE070]
0000708296fe1e11  jmp 0x0000708296FE1CA0
0000708296fe1e16  int3
0000708296fe1e17  nop [rax+rax*1], ax
0000708296fe1e20  mov rax, [r15+0x48]
0000708296fe1e24  mov r14, [r15+0x50]
0000708296fe1e28  lea r12, [r14+rax*1]
0000708296fe1e2c  movups xmm1, [r13+r12*1]
0000708296fe1e32  movaps [r15+0x120], xmm1
0000708296fe1e3a  lea r14, [rax+0x10]
0000708296fe1e3e  mov [r15+0x48], r14
0000708296fe1e42  xor eax, eax
0000708296fe1e44  mov r12d, 0x200
0000708296fe1e4a  cmp r14, r12
0000708296fe1e4d  cmc
0000708296fe1e4e  lahf
0000708296fe1e4f  seto al
0000708296fe1e52  mov [r15+0x108], eax
0000708296fe1e59  pextrq rax, xmm1, 0x01
0000708296fe1e60  movq xmm15, rax
0000708296fe1e65  movaps [r15+0x130], xmm15
0000708296fe1e6d  movaps xmm14, [r15+0x110]
0000708296fe1e75  movq rax, xmm14
0000708296fe1e7a  movq r14, xmm1
0000708296fe1e7f  vmovq xmm1, rax
0000708296fe1e84  vmovq xmm14, r14
0000708296fe1e89  movaps xmm13, xmm1
0000708296fe1e8d  addsd xmm13, xmm14
0000708296fe1e92  ucomisd xmm13, xmm13
0000708296fe1e97  jp 0x0000708296FE1F4C
0000708296fe1e9d  movq xmm13, xmm13
0000708296fe1ea2  movq rax, xmm13
0000708296fe1ea7  movq r14, xmm15
0000708296fe1eac  vmovq xmm1, rax
0000708296fe1eb1  vmovq xmm15, r14
0000708296fe1eb6  movaps xmm14, xmm1
0000708296fe1eba  addsd xmm14, xmm15
0000708296fe1ebf  ucomisd xmm14, xmm14
0000708296fe1ec4  jp 0x0000708296FE1F94
0000708296fe1eca  movq xmm14, xmm14
0000708296fe1ecf  movaps [r15+0x110], xmm14
0000708296fe1ed7  mov eax, [r15+0x108]
0000708296fe1ede  sahf
0000708296fe1edf  jnz 0x0000708296FE1F11
0000708296fe1ee1  cmp dword ptr [r15+0x318], 0x00
0000708296fe1ee9  jz 0x0000708296FE1FE0
0000708296fe1eef  nop [rax+rax*1], ax
0000708296fe1ef8  nop [rax+rax*1], eax
0000708296fe1f00  mov eax, 0x410490
0000708296fe1f05  mov [r15+0x100], rax
0000708296fe1f0c  jmp 0x0000708296DFE110
0000708296fe1f11  cmp dword ptr [r15+0x318], 0x00
0000708296fe1f19  jz 0x0000708296FE1E20
0000708296fe1f1f  nop [rax+rax*1], ax
0000708296fe1f28  nop [rax+rax*1], eax
0000708296fe1f30  mov eax, 0x410474
0000708296fe1f35  mov [r15+0x100], rax
0000708296fe1f3c  jmp 0x0000708296DFE110
0000708296fe1f41  int3
0000708296fe1f42  call 0x0000708296EB52F0
0000708296fe1f47  jmp 0x0000708296FE1E32
0000708296fe1f4c  ucomisd xmm1, xmm14
0000708296fe1f51  jp 0x0000708296FE1F60
0000708296fe1f53  movaps xmm13, [0x0000708296BFE060]
0000708296fe1f5b  jmp 0x0000708296FE1E9D
0000708296fe1f60  vxorps xmm0, xmm1, xmm14
0000708296fe1f65  pextrw eax, xmm0, 0x03
0000708296fe1f6a  and eax, 0x7FF8
0000708296fe1f6f  cmp eax, 0x08
0000708296fe1f72  jnz 0x0000708296FE1E9D
0000708296fe1f78  movq rax, xmm14
0000708296fe1f7d  shl rax, 0x0D
0000708296fe1f81  jbe 0x0000708296FE1E9D
0000708296fe1f87  vorps xmm13, xmm14, [0x0000708296BFE070]
0000708296fe1f8f  jmp 0x0000708296FE1E9D
0000708296fe1f94  ucomisd xmm1, xmm15
0000708296fe1f99  jp 0x0000708296FE1FA8
0000708296fe1f9b  movaps xmm14, [0x0000708296BFE060]
0000708296fe1fa3  jmp 0x0000708296FE1ECA
0000708296fe1fa8  vxorps xmm0, xmm1, xmm15
0000708296fe1fad  pextrw eax, xmm0, 0x03
0000708296fe1fb2  and eax, 0x7FF8
0000708296fe1fb7  cmp eax, 0x08
0000708296fe1fba  jnz 0x0000708296FE1ECA
0000708296fe1fc0  movq rax, xmm15
0000708296fe1fc5  shl rax, 0x0D
0000708296fe1fc9  jbe 0x0000708296FE1ECA
0000708296fe1fcf  vorps xmm14, xmm15, [0x0000708296BFE070]
0000708296fe1fd7  jmp 0x0000708296FE1ECA
0000708296fe1fdc  int3
0000708296fe1fdd  nop [rax], eax
0000708296fe1fe0  mov rax, [r15+0x40]
0000708296fe1fe4  lea r14, [rax+0x510]
0000708296fe1feb  movaps xmm1, [r15+0x110]
0000708296fe1ff3  movq rax, xmm1
0000708296fe1ff8  mov [r13+r14*1], rax
0000708296fe1ffd  mov rax, [r15+0xF0]
0000708296fe2004  mov [r15+0x100], rax
0000708296fe200b  jmp 0x0000708296FCE5C0
0000708296fe2010  int3
0000708296fe2011  call 0x0000708296ED5EB0
0000708296fe2016  jmp 0x0000708296FE1FFD
0000708296fe201b  int3
0000708296fe201c  nop [rax], eax
0000708296fe2020  mov qword ptr [r15+0x100], 0x04
0000708296fe202b  mov esi, 0x00
0000708296fe2030  mov edx, 0x09
0000708296fe2035  mov rdi, 0x7FFF0C7D3CA0
0000708296fe203f  mov rax, 0x64BBC66FF970
0000708296fe2049  call rax
0000708296fe204b  cmp dword ptr [r15+0x318], 0x00
0000708296fe2053  jnz 0x0000708296DFE110
0000708296fe2059  jmp 0x0000708296DFE0A0
0000708296fe205e  int3
0000708296fe205f  int3
