000076b67a9ce69b  nop [rax+rax*1], eax
000076b67a9ce6a0  vmovaps xmm1, [0x000076B67A5FE010]
000076b67a9ce6a8  movq xmm1, xmm1
000076b67a9ce6ac  movaps [r15+0x110], xmm1
000076b67a9ce6b4  vmovaps xmm1, [0x000076B67A5FE020]
000076b67a9ce6bc  movq xmm1, xmm1
000076b67a9ce6c0  movaps [r15+0x120], xmm1
000076b67a9ce6c8  mov eax, 0x4204C0
000076b67a9ce6cd  mov r14, [r13+rax*1]
000076b67a9ce6d2  movq xmm1, r14
000076b67a9ce6d7  movaps [r15+0x130], xmm1
000076b67a9ce6df  vmovaps xmm1, [0x000076B67A5FE030]
000076b67a9ce6e7  vpbroadcastq xmm1, xmm1
000076b67a9ce6ec  movaps [r15+0x140], xmm1
000076b67a9ce6f4  mov qword ptr [r15+0x40], 0x02
000076b67a9ce6fc  vmovaps xmm15, [0x000076B67A5FE040]
000076b67a9ce704  movq xmm15, xmm15
000076b67a9ce709  movaps [r15+0x150], xmm15
000076b67a9ce711  mov qword ptr [r15+0x58], 0x420000
000076b67a9ce719  vmovaps xmm15, [0x000076B67A5FE050]
000076b67a9ce721  vpbroadcastq xmm15, xmm15
000076b67a9ce726  movaps [r15+0x160], xmm15
000076b67a9ce72e  mov rax, [r15+0x40]
000076b67a9ce732  vmovq xmm14, rax
000076b67a9ce737  vpbroadcastq xmm14, xmm14
000076b67a9ce73c  movaps [r15+0x170], xmm14
000076b67a9ce744  mov eax, 0x4204D0
000076b67a9ce749  movups xmm13, [r13+rax*1]
000076b67a9ce74f  mov qword ptr [r15+0x40], 0x430518
000076b67a9ce757  mov qword ptr [r15+0x50], 0x430720
000076b67a9ce75f  vpmovqd xmm12, xmm13
000076b67a9ce765  pxor xmm11, xmm11
000076b67a9ce76a  punpcklqdq xmm12, xmm11
000076b67a9ce76f  movaps [r15+0x210], xmm12
000076b67a9ce777  movq xmm12, qword ptr [r15+0x120]
000076b67a9ce780  movq xmm11, qword ptr [r15+0x130]
000076b67a9ce789  psubd xmm12, xmm11
000076b67a9ce78e  movq xmm12, xmm12
000076b67a9ce793  paddq xmm13, xmm14
000076b67a9ce798  movaps [r15+0x180], xmm13
000076b67a9ce7a0  movq xmm14, qword ptr [r15+0x150]
000076b67a9ce7a9  paddd xmm11, xmm14
000076b67a9ce7ae  movq xmm11, xmm11
000076b67a9ce7b3  movq xmm11, xmm11
000076b67a9ce7b8  movaps [r15+0x130], xmm11
000076b67a9ce7c0  pmovzxdq xmm12, xmm12
000076b67a9ce7c6  psllq xmm12, 0x00
000076b67a9ce7cc  movq xmm14, qword ptr [r15+0x210]
000076b67a9ce7d5  movq xmm13, qword ptr [r15+0x110]
000076b67a9ce7de  paddd xmm14, xmm13
000076b67a9ce7e3  movq xmm14, xmm14
000076b67a9ce7e8  vcvtuqq2pd xmm12, xmm12
000076b67a9ce7ee  pmovzxdq xmm14, xmm14
000076b67a9ce7f4  psllq xmm14, 0x00
000076b67a9ce7fa  vcvtuqq2pd xmm14, xmm14
000076b67a9ce800  movaps xmm13, xmm12
000076b67a9ce804  mulpd xmm13, xmm1
000076b67a9ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000076b67a9ce80f  ptest xmm11, xmm11
000076b67a9ce815  jnz 0x000076B67A9CE8FF
000076b67a9ce81b  movaps [r15+0x220], xmm13
000076b67a9ce823  mov eax, 0x430720
000076b67a9ce828  movups [r13+rax*1], xmm13
000076b67a9ce82e  movaps xmm1, xmm14
000076b67a9ce832  mulpd xmm1, xmm15
000076b67a9ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000076b67a9ce83c  ptest xmm13, xmm13
000076b67a9ce842  jnz 0x000076B67A9CEA4C
000076b67a9ce848  movaps [r15+0x210], xmm1
000076b67a9ce850  mov eax, 0x430518
000076b67a9ce855  movups [r13+rax*1], xmm1
000076b67a9ce85b  mov qword ptr [r15+0x48], 0x10
000076b67a9ce863  xor eax, eax
000076b67a9ce865  mov r14d, 0x10
000076b67a9ce86b  mov r12d, 0x200
000076b67a9ce871  cmp r14, r12
000076b67a9ce874  cmc
000076b67a9ce875  lahf
000076b67a9ce876  seto al
000076b67a9ce879  mov [r15+0x108], eax
000076b67a9ce880  mov eax, [r15+0x108]
000076b67a9ce887  sahf
000076b67a9ce888  jnz 0x000076B67A9CE8BA
000076b67a9ce88a  cmp dword ptr [r15+0x318], 0x00
000076b67a9ce892  jz 0x000076B67A9CEFF0
000076b67a9ce898  nop [rax+rax*1], ax
000076b67a9ce8a1  nop [rax+rax*1], eax
000076b67a9ce8a9  mov eax, 0x4101EC
000076b67a9ce8ae  mov [r15+0x100], rax
000076b67a9ce8b5  jmp 0x000076B67A7FE110
000076b67a9ce8ba  cmp dword ptr [r15+0x318], 0x00
000076b67a9ce8c2  jz 0x000076B67A9CEBA0
000076b67a9ce8c8  nop [rax+rax*1], ax
000076b67a9ce8d1  nop [rax+rax*1], eax
000076b67a9ce8d9  mov eax, 0x4101AC
000076b67a9ce8de  mov [r15+0x100], rax
000076b67a9ce8e5  jmp 0x000076B67A7FE110
000076b67a9ce8ea  int3
000076b67a9ce8eb  call 0x000076B67A80DC20
000076b67a9ce8f0  jmp 0x000076B67A9CE6D2
000076b67a9ce8f5  call 0x000076B67A80C260
000076b67a9ce8fa  jmp 0x000076B67A9CE74F
000076b67a9ce8ff  sub rsp, 0x08
000076b67a9ce903  push rax
000076b67a9ce904  push rcx
000076b67a9ce905  push rdx
000076b67a9ce906  push rdi
000076b67a9ce907  push rsi
000076b67a9ce908  push r8
000076b67a9ce90a  push r9
000076b67a9ce90c  push r10
000076b67a9ce90e  push r11
000076b67a9ce910  sub rsp, 0xF0
000076b67a9ce917  vmovaps [rsp], xmm0
000076b67a9ce91c  vmovaps [rsp+0x10], xmm1
000076b67a9ce922  vmovaps [rsp+0x20], xmm2
000076b67a9ce928  vmovaps [rsp+0x30], xmm3
000076b67a9ce92e  vmovaps [rsp+0x40], xmm4
000076b67a9ce934  vmovaps [rsp+0x50], xmm5
000076b67a9ce93a  vmovaps [rsp+0x60], xmm6
000076b67a9ce940  vmovaps [rsp+0x70], xmm7
000076b67a9ce946  vmovaps [rsp+0x80], xmm8
000076b67a9ce94f  vmovaps [rsp+0x90], xmm9
000076b67a9ce958  vmovaps [rsp+0xA0], xmm10
000076b67a9ce961  vmovaps [rsp+0xB0], xmm11
000076b67a9ce96a  vmovaps [rsp+0xC0], xmm12
000076b67a9ce973  vmovaps [rsp+0xD0], xmm14
000076b67a9ce97c  vmovaps [rsp+0xE0], xmm15
000076b67a9ce985  sub rsp, 0x30
000076b67a9ce989  movaps [rsp], xmm13
000076b67a9ce98e  movaps [rsp+0x10], xmm12
000076b67a9ce994  movaps [rsp+0x20], xmm1
000076b67a9ce999  lea rdi, [rsp]
000076b67a9ce99d  mov esi, 0x00
000076b67a9ce9a2  mov rax, 0x63C5EF2DF530
000076b67a9ce9ac  call rax
000076b67a9ce9ae  movaps xmm13, [rsp]
000076b67a9ce9b3  add rsp, 0x30
000076b67a9ce9b7  vmovaps xmm0, [rsp]
000076b67a9ce9bc  vmovaps xmm1, [rsp+0x10]
000076b67a9ce9c2  vmovaps xmm2, [rsp+0x20]
000076b67a9ce9c8  vmovaps xmm3, [rsp+0x30]
000076b67a9ce9ce  vmovaps xmm4, [rsp+0x40]
000076b67a9ce9d4  vmovaps xmm5, [rsp+0x50]
000076b67a9ce9da  vmovaps xmm6, [rsp+0x60]
000076b67a9ce9e0  vmovaps xmm7, [rsp+0x70]
000076b67a9ce9e6  vmovaps xmm8, [rsp+0x80]
000076b67a9ce9ef  vmovaps xmm9, [rsp+0x90]
000076b67a9ce9f8  vmovaps xmm10, [rsp+0xA0]
000076b67a9cea01  vmovaps xmm11, [rsp+0xB0]
000076b67a9cea0a  vmovaps xmm12, [rsp+0xC0]
000076b67a9cea13  vmovaps xmm14, [rsp+0xD0]
000076b67a9cea1c  vmovaps xmm15, [rsp+0xE0]
000076b67a9cea25  add rsp, 0xF0
000076b67a9cea2c  pop r11
000076b67a9cea2e  pop r10
000076b67a9cea30  pop r9
000076b67a9cea32  pop r8
000076b67a9cea34  pop rsi
000076b67a9cea35  pop rdi
000076b67a9cea36  pop rdx
000076b67a9cea37  pop rcx
000076b67a9cea38  pop rax
000076b67a9cea39  add rsp, 0x08
000076b67a9cea3d  jmp 0x000076B67A9CE81B
000076b67a9cea42  call 0x000076B67A80C380
000076b67a9cea47  jmp 0x000076B67A9CE82E
000076b67a9cea4c  sub rsp, 0x08
000076b67a9cea50  push rax
000076b67a9cea51  push rcx
000076b67a9cea52  push rdx
000076b67a9cea53  push rdi
000076b67a9cea54  push rsi
000076b67a9cea55  push r8
000076b67a9cea57  push r9
000076b67a9cea59  push r10
000076b67a9cea5b  push r11
000076b67a9cea5d  sub rsp, 0xF0
000076b67a9cea64  vmovaps [rsp], xmm0
000076b67a9cea69  vmovaps [rsp+0x10], xmm2
000076b67a9cea6f  vmovaps [rsp+0x20], xmm3
000076b67a9cea75  vmovaps [rsp+0x30], xmm4
000076b67a9cea7b  vmovaps [rsp+0x40], xmm5
000076b67a9cea81  vmovaps [rsp+0x50], xmm6
000076b67a9cea87  vmovaps [rsp+0x60], xmm7
000076b67a9cea8d  vmovaps [rsp+0x70], xmm8
000076b67a9cea93  vmovaps [rsp+0x80], xmm9
000076b67a9cea9c  vmovaps [rsp+0x90], xmm10
000076b67a9ceaa5  vmovaps [rsp+0xA0], xmm11
000076b67a9ceaae  vmovaps [rsp+0xB0], xmm12
000076b67a9ceab7  vmovaps [rsp+0xC0], xmm13
000076b67a9ceac0  vmovaps [rsp+0xD0], xmm14
000076b67a9ceac9  vmovaps [rsp+0xE0], xmm15
000076b67a9cead2  sub rsp, 0x30
000076b67a9cead6  movaps [rsp], xmm1
000076b67a9ceada  movaps [rsp+0x10], xmm14
000076b67a9ceae0  movaps [rsp+0x20], xmm15
000076b67a9ceae6  lea rdi, [rsp]
000076b67a9ceaea  mov esi, 0x00
000076b67a9ceaef  mov rax, 0x63C5EF2DF530
000076b67a9ceaf9  call rax
000076b67a9ceafb  movaps xmm1, [rsp]
000076b67a9ceaff  add rsp, 0x30
000076b67a9ceb03  vmovaps xmm0, [rsp]
000076b67a9ceb08  vmovaps xmm2, [rsp+0x10]
000076b67a9ceb0e  vmovaps xmm3, [rsp+0x20]
000076b67a9ceb14  vmovaps xmm4, [rsp+0x30]
000076b67a9ceb1a  vmovaps xmm5, [rsp+0x40]
000076b67a9ceb20  vmovaps xmm6, [rsp+0x50]
000076b67a9ceb26  vmovaps xmm7, [rsp+0x60]
000076b67a9ceb2c  vmovaps xmm8, [rsp+0x70]
000076b67a9ceb32  vmovaps xmm9, [rsp+0x80]
000076b67a9ceb3b  vmovaps xmm10, [rsp+0x90]
000076b67a9ceb44  vmovaps xmm11, [rsp+0xA0]
000076b67a9ceb4d  vmovaps xmm12, [rsp+0xB0]
000076b67a9ceb56  vmovaps xmm13, [rsp+0xC0]
000076b67a9ceb5f  vmovaps xmm14, [rsp+0xD0]
000076b67a9ceb68  vmovaps xmm15, [rsp+0xE0]
000076b67a9ceb71  add rsp, 0xF0
000076b67a9ceb78  pop r11
000076b67a9ceb7a  pop r10
000076b67a9ceb7c  pop r9
000076b67a9ceb7e  pop r8
000076b67a9ceb80  pop rsi
000076b67a9ceb81  pop rdi
000076b67a9ceb82  pop rdx
000076b67a9ceb83  pop rcx
000076b67a9ceb84  pop rax
000076b67a9ceb85  add rsp, 0x08
000076b67a9ceb89  jmp 0x000076B67A9CE848
000076b67a9ceb8e  call 0x000076B67A7FF540
000076b67a9ceb93  jmp 0x000076B67A9CE85B
000076b67a9ceb98  int3
000076b67a9ceb99  nop [rax], eax
000076b67a9ceba0  movaps xmm1, [r15+0x180]
000076b67a9ceba8  vpmovqd xmm15, xmm1
000076b67a9cebae  pxor xmm14, xmm14
000076b67a9cebb3  punpcklqdq xmm15, xmm14
000076b67a9cebb8  movaps [r15+0x210], xmm15
000076b67a9cebc0  movq xmm15, qword ptr [r15+0x120]
000076b67a9cebc9  movq xmm14, qword ptr [r15+0x130]
000076b67a9cebd2  psubd xmm15, xmm14
000076b67a9cebd7  movq xmm15, xmm15
000076b67a9cebdc  movaps xmm13, [r15+0x170]
000076b67a9cebe4  paddq xmm1, xmm13
000076b67a9cebe9  movaps [r15+0x180], xmm1
000076b67a9cebf1  movq xmm1, qword ptr [r15+0x150]
000076b67a9cebfa  paddd xmm14, xmm1
000076b67a9cebff  movq xmm14, xmm14
000076b67a9cec04  movq xmm14, xmm14
000076b67a9cec09  movaps [r15+0x130], xmm14
000076b67a9cec11  pmovzxdq xmm15, xmm15
000076b67a9cec17  psllq xmm15, 0x00
000076b67a9cec1d  movq xmm1, qword ptr [r15+0x210]
000076b67a9cec26  movq xmm14, qword ptr [r15+0x110]
000076b67a9cec2f  paddd xmm1, xmm14
000076b67a9cec34  movq xmm1, xmm1
000076b67a9cec38  vcvtuqq2pd xmm15, xmm15
000076b67a9cec3e  pmovzxdq xmm1, xmm1
000076b67a9cec43  psllq xmm1, 0x00
000076b67a9cec48  vcvtuqq2pd xmm1, xmm1
000076b67a9cec4e  movaps xmm14, [r15+0x140]
000076b67a9cec56  movaps xmm13, xmm15
000076b67a9cec5a  mulpd xmm13, xmm14
000076b67a9cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000076b67a9cec65  ptest xmm12, xmm12
000076b67a9cec6b  jnz 0x000076B67A9CED4E
000076b67a9cec71  movaps [r15+0x220], xmm13
000076b67a9cec79  mov rax, [r15+0x48]
000076b67a9cec7d  mov r14, [r15+0x50]
000076b67a9cec81  lea r12, [r14+rax*1]
000076b67a9cec85  movups [r13+r12*1], xmm13
000076b67a9cec8b  movaps xmm15, [r15+0x160]
000076b67a9cec93  movaps xmm14, xmm1
000076b67a9cec97  mulpd xmm14, xmm15
000076b67a9cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000076b67a9ceca2  ptest xmm13, xmm13
000076b67a9ceca8  jnz 0x000076B67A9CEE9C
000076b67a9cecae  movaps [r15+0x210], xmm14
000076b67a9cecb6  mov r14, [r15+0x40]
000076b67a9cecba  lea r12, [r14+rax*1]
000076b67a9cecbe  movups [r13+r12*1], xmm14
000076b67a9cecc4  lea r14, [rax+0x10]
000076b67a9cecc8  mov [r15+0x48], r14
000076b67a9ceccc  xor eax, eax
000076b67a9cecce  mov r12d, 0x200
000076b67a9cecd4  cmp r14, r12
000076b67a9cecd7  cmc
000076b67a9cecd8  lahf
000076b67a9cecd9  seto al
000076b67a9cecdc  mov [r15+0x108], eax
000076b67a9cece3  mov eax, [r15+0x108]
000076b67a9cecea  sahf
000076b67a9ceceb  jnz 0x000076B67A9CED1D
000076b67a9ceced  cmp dword ptr [r15+0x318], 0x00
000076b67a9cecf5  jz 0x000076B67A9CEFF0
000076b67a9cecfb  nop [rax+rax*1], ax
000076b67a9ced04  nop [rax+rax*1], eax
000076b67a9ced0c  mov eax, 0x4101EC
000076b67a9ced11  mov [r15+0x100], rax
000076b67a9ced18  jmp 0x000076B67A7FE110
000076b67a9ced1d  cmp dword ptr [r15+0x318], 0x00
000076b67a9ced25  jz 0x000076B67A9CEBA0
000076b67a9ced2b  nop [rax+rax*1], ax
000076b67a9ced34  nop [rax+rax*1], eax
000076b67a9ced3c  mov eax, 0x4101AC
000076b67a9ced41  mov [r15+0x100], rax
000076b67a9ced48  jmp 0x000076B67A7FE110
000076b67a9ced4d  int3
000076b67a9ced4e  sub rsp, 0x08
000076b67a9ced52  push rax
000076b67a9ced53  push rcx
000076b67a9ced54  push rdx
000076b67a9ced55  push rdi
000076b67a9ced56  push rsi
000076b67a9ced57  push r8
000076b67a9ced59  push r9
000076b67a9ced5b  push r10
000076b67a9ced5d  push r11
000076b67a9ced5f  sub rsp, 0xF0
000076b67a9ced66  vmovaps [rsp], xmm0
000076b67a9ced6b  vmovaps [rsp+0x10], xmm1
000076b67a9ced71  vmovaps [rsp+0x20], xmm2
000076b67a9ced77  vmovaps [rsp+0x30], xmm3
000076b67a9ced7d  vmovaps [rsp+0x40], xmm4
000076b67a9ced83  vmovaps [rsp+0x50], xmm5
000076b67a9ced89  vmovaps [rsp+0x60], xmm6
000076b67a9ced8f  vmovaps [rsp+0x70], xmm7
000076b67a9ced95  vmovaps [rsp+0x80], xmm8
000076b67a9ced9e  vmovaps [rsp+0x90], xmm9
000076b67a9ceda7  vmovaps [rsp+0xA0], xmm10
000076b67a9cedb0  vmovaps [rsp+0xB0], xmm11
000076b67a9cedb9  vmovaps [rsp+0xC0], xmm12
000076b67a9cedc2  vmovaps [rsp+0xD0], xmm14
000076b67a9cedcb  vmovaps [rsp+0xE0], xmm15
000076b67a9cedd4  sub rsp, 0x30
000076b67a9cedd8  movaps [rsp], xmm13
000076b67a9ceddd  movaps [rsp+0x10], xmm15
000076b67a9cede3  movaps [rsp+0x20], xmm14
000076b67a9cede9  lea rdi, [rsp]
000076b67a9ceded  mov esi, 0x00
000076b67a9cedf2  mov rax, 0x63C5EF2DF530
000076b67a9cedfc  call rax
000076b67a9cedfe  movaps xmm13, [rsp]
000076b67a9cee03  add rsp, 0x30
000076b67a9cee07  vmovaps xmm0, [rsp]
000076b67a9cee0c  vmovaps xmm1, [rsp+0x10]
000076b67a9cee12  vmovaps xmm2, [rsp+0x20]
000076b67a9cee18  vmovaps xmm3, [rsp+0x30]
000076b67a9cee1e  vmovaps xmm4, [rsp+0x40]
000076b67a9cee24  vmovaps xmm5, [rsp+0x50]
000076b67a9cee2a  vmovaps xmm6, [rsp+0x60]
000076b67a9cee30  vmovaps xmm7, [rsp+0x70]
000076b67a9cee36  vmovaps xmm8, [rsp+0x80]
000076b67a9cee3f  vmovaps xmm9, [rsp+0x90]
000076b67a9cee48  vmovaps xmm10, [rsp+0xA0]
000076b67a9cee51  vmovaps xmm11, [rsp+0xB0]
000076b67a9cee5a  vmovaps xmm12, [rsp+0xC0]
000076b67a9cee63  vmovaps xmm14, [rsp+0xD0]
000076b67a9cee6c  vmovaps xmm15, [rsp+0xE0]
000076b67a9cee75  add rsp, 0xF0
000076b67a9cee7c  pop r11
000076b67a9cee7e  pop r10
000076b67a9cee80  pop r9
000076b67a9cee82  pop r8
000076b67a9cee84  pop rsi
000076b67a9cee85  pop rdi
000076b67a9cee86  pop rdx
000076b67a9cee87  pop rcx
000076b67a9cee88  pop rax
000076b67a9cee89  add rsp, 0x08
000076b67a9cee8d  jmp 0x000076B67A9CEC71
000076b67a9cee92  call 0x000076B67A8C2240
000076b67a9cee97  jmp 0x000076B67A9CEC8B
000076b67a9cee9c  sub rsp, 0x08
000076b67a9ceea0  push rax
000076b67a9ceea1  push rcx
000076b67a9ceea2  push rdx
000076b67a9ceea3  push rdi
000076b67a9ceea4  push rsi
000076b67a9ceea5  push r8
000076b67a9ceea7  push r9
000076b67a9ceea9  push r10
000076b67a9ceeab  push r11
000076b67a9ceead  sub rsp, 0xF0
000076b67a9ceeb4  vmovaps [rsp], xmm0
000076b67a9ceeb9  vmovaps [rsp+0x10], xmm1
000076b67a9ceebf  vmovaps [rsp+0x20], xmm2
000076b67a9ceec5  vmovaps [rsp+0x30], xmm3
000076b67a9ceecb  vmovaps [rsp+0x40], xmm4
000076b67a9ceed1  vmovaps [rsp+0x50], xmm5
000076b67a9ceed7  vmovaps [rsp+0x60], xmm6
000076b67a9ceedd  vmovaps [rsp+0x70], xmm7
000076b67a9ceee3  vmovaps [rsp+0x80], xmm8
000076b67a9ceeec  vmovaps [rsp+0x90], xmm9
000076b67a9ceef5  vmovaps [rsp+0xA0], xmm10
000076b67a9ceefe  vmovaps [rsp+0xB0], xmm11
000076b67a9cef07  vmovaps [rsp+0xC0], xmm12
000076b67a9cef10  vmovaps [rsp+0xD0], xmm13
000076b67a9cef19  vmovaps [rsp+0xE0], xmm15
000076b67a9cef22  sub rsp, 0x30
000076b67a9cef26  movaps [rsp], xmm14
000076b67a9cef2b  movaps [rsp+0x10], xmm1
000076b67a9cef30  movaps [rsp+0x20], xmm15
000076b67a9cef36  lea rdi, [rsp]
000076b67a9cef3a  mov esi, 0x00
000076b67a9cef3f  mov rax, 0x63C5EF2DF530
000076b67a9cef49  call rax
000076b67a9cef4b  movaps xmm14, [rsp]
000076b67a9cef50  add rsp, 0x30
000076b67a9cef54  vmovaps xmm0, [rsp]
000076b67a9cef59  vmovaps xmm1, [rsp+0x10]
000076b67a9cef5f  vmovaps xmm2, [rsp+0x20]
000076b67a9cef65  vmovaps xmm3, [rsp+0x30]
000076b67a9cef6b  vmovaps xmm4, [rsp+0x40]
000076b67a9cef71  vmovaps xmm5, [rsp+0x50]
000076b67a9cef77  vmovaps xmm6, [rsp+0x60]
000076b67a9cef7d  vmovaps xmm7, [rsp+0x70]
000076b67a9cef83  vmovaps xmm8, [rsp+0x80]
000076b67a9cef8c  vmovaps xmm9, [rsp+0x90]
000076b67a9cef95  vmovaps xmm10, [rsp+0xA0]
000076b67a9cef9e  vmovaps xmm11, [rsp+0xB0]
000076b67a9cefa7  vmovaps xmm12, [rsp+0xC0]
000076b67a9cefb0  vmovaps xmm13, [rsp+0xD0]
000076b67a9cefb9  vmovaps xmm15, [rsp+0xE0]
000076b67a9cefc2  add rsp, 0xF0
000076b67a9cefc9  pop r11
000076b67a9cefcb  pop r10
000076b67a9cefcd  pop r9
000076b67a9cefcf  pop r8
000076b67a9cefd1  pop rsi
000076b67a9cefd2  pop rdi
000076b67a9cefd3  pop rdx
000076b67a9cefd4  pop rcx
000076b67a9cefd5  pop rax
000076b67a9cefd6  add rsp, 0x08
000076b67a9cefda  jmp 0x000076B67A9CECAE
000076b67a9cefdf  call 0x000076B67A8C34C0
000076b67a9cefe4  jmp 0x000076B67A9CECC4
000076b67a9cefe9  int3
000076b67a9cefea  nop [rax+rax*1], ax
000076b67a9ceff0  mov rax, [r15+0xF8]
000076b67a9ceff7  lea r14, [rax-0x150]
000076b67a9ceffe  mov [r15+0xF8], r14
000076b67a9cf005  mov rax, [r15+0x50]
000076b67a9cf009  lea r12, [rax+0x80]
000076b67a9cf010  movups xmm1, [r13+r12*1]
000076b67a9cf016  lea r12, [rax+0x90]
000076b67a9cf01d  movups xmm15, [r13+r12*1]
000076b67a9cf023  mov qword ptr [r15+0x48], 0x00
000076b67a9cf02b  lea r12, [rax+0x40]
000076b67a9cf02f  movups xmm14, [r13+r12*1]
000076b67a9cf035  lea r12, [rax+0x50]
000076b67a9cf039  movups xmm13, [r13+r12*1]
000076b67a9cf03f  lea r12, [r14+0x120]
000076b67a9cf046  movq xmm12, qword ptr [r15+0x1C0]
000076b67a9cf04f  movq xmm11, qword ptr [r15+0x1B0]
000076b67a9cf058  movq r11, xmm12
000076b67a9cf05d  movq r10, xmm11
000076b67a9cf062  mov [r13+r12*1], r11
000076b67a9cf067  lea r12, [r14+0x128]
000076b67a9cf06e  mov [r13+r12*1], r10
000076b67a9cf073  vxorps xmm12, xmm12, xmm12
000076b67a9cf078  vpbroadcastq xmm12, xmm12
000076b67a9cf07d  lea r12, [r14+0x100]
000076b67a9cf084  movq xmm11, qword ptr [r15+0x200]
000076b67a9cf08d  movq xmm10, qword ptr [r15+0x1F0]
000076b67a9cf096  movq r11, xmm11
000076b67a9cf09b  movq r10, xmm10
000076b67a9cf0a0  mov [r13+r12*1], r11
000076b67a9cf0a5  lea r12, [r14+0x108]
000076b67a9cf0ac  mov [r13+r12*1], r10
000076b67a9cf0b1  lea r12, [r14+0xE0]
000076b67a9cf0b8  movups [r13+r12*1], xmm15
000076b67a9cf0be  lea r12, [r14+0xF0]
000076b67a9cf0c5  movups [r13+r12*1], xmm1
000076b67a9cf0cb  lea r12, [rax+0xC0]
000076b67a9cf0d2  movups xmm1, [r13+r12*1]
000076b67a9cf0d8  lea r12, [rax+0xD0]
000076b67a9cf0df  movups xmm15, [r13+r12*1]
000076b67a9cf0e5  lea r12, [r14+0x110]
000076b67a9cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000076b67a9cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000076b67a9cf0fe  movq r11, xmm11
000076b67a9cf103  movq r10, xmm10
000076b67a9cf108  mov [r13+r12*1], r11
000076b67a9cf10d  lea r12, [r14+0x118]
000076b67a9cf114  mov [r13+r12*1], r10
000076b67a9cf119  movups xmm11, [r13+rax*1]
000076b67a9cf11f  lea r12, [rax+0x10]
000076b67a9cf123  movups xmm10, [r13+r12*1]
000076b67a9cf129  lea r12, [r14+0x130]
000076b67a9cf130  movq xmm9, qword ptr [r15+0x1A0]
000076b67a9cf139  movq xmm8, qword ptr [r15+0x190]
000076b67a9cf142  movq r11, xmm9
000076b67a9cf147  movq r10, xmm8
000076b67a9cf14c  mov [r13+r12*1], r11
000076b67a9cf151  lea r12, [r14+0x138]
000076b67a9cf158  mov [r13+r12*1], r10
000076b67a9cf15d  lea r12, [rax+0x140]
000076b67a9cf164  movups xmm9, [r13+r12*1]
000076b67a9cf16a  lea r12, [rax+0x150]
000076b67a9cf171  movups xmm8, [r13+r12*1]
000076b67a9cf177  lea r12, [r14+0xC0]
000076b67a9cf17e  movups [r13+r12*1], xmm15
000076b67a9cf184  lea r12, [r14+0xD0]
000076b67a9cf18b  movups [r13+r12*1], xmm1
000076b67a9cf191  lea r12, [rax+0x100]
000076b67a9cf198  movups xmm1, [r13+r12*1]
000076b67a9cf19e  lea r12, [rax+0x110]
000076b67a9cf1a5  movups xmm15, [r13+r12*1]
000076b67a9cf1ab  lea r12, [r14+0x140]
000076b67a9cf1b2  mov r11, [r15+0xE8]
000076b67a9cf1b9  mov [r13+r12*1], r11
000076b67a9cf1be  lea r12, [rax+0x180]
000076b67a9cf1c5  movups xmm7, [r13+r12*1]
000076b67a9cf1cb  lea r12, [rax+0x190]
000076b67a9cf1d2  movups xmm6, [r13+r12*1]
000076b67a9cf1d8  lea r12, [rax+0x1C0]
000076b67a9cf1df  movups xmm5, [r13+r12*1]
000076b67a9cf1e5  lea r12, [rax+0x1D0]
000076b67a9cf1ec  movups xmm4, [r13+r12*1]
000076b67a9cf1f2  lea r12, [r14+0x20]
000076b67a9cf1f6  movups [r13+r12*1], xmm1
000076b67a9cf1fc  lea r12, [r14+0x30]
000076b67a9cf200  movups [r13+r12*1], xmm13
000076b67a9cf206  lea r12, [rax+0x60]
000076b67a9cf20a  movups xmm1, [r13+r12*1]
000076b67a9cf210  lea r12, [rax+0x70]
000076b67a9cf214  movups xmm13, [r13+r12*1]
000076b67a9cf21a  lea r12, [rax+0x20]
000076b67a9cf21e  movups xmm3, [r13+r12*1]
000076b67a9cf224  lea r12, [rax+0x30]
000076b67a9cf228  movups xmm2, [r13+r12*1]
000076b67a9cf22e  movaps [r15+0x1F0], xmm2
000076b67a9cf236  lea r12, [r14+0x60]
000076b67a9cf23a  movups [r13+r12*1], xmm11
000076b67a9cf240  lea r12, [r14+0x70]
000076b67a9cf244  movups [r13+r12*1], xmm5
000076b67a9cf24a  lea r12, [rax+0xE0]
000076b67a9cf251  movups xmm11, [r13+r12*1]
000076b67a9cf257  lea r12, [rax+0xF0]
000076b67a9cf25e  movups xmm5, [r13+r12*1]
000076b67a9cf264  lea r12, [r14+0xA0]
000076b67a9cf26b  movups [r13+r12*1], xmm13
000076b67a9cf271  lea r12, [r14+0xB0]
000076b67a9cf278  movups [r13+r12*1], xmm1
000076b67a9cf27e  lea r12, [rax+0xA0]
000076b67a9cf285  movups xmm1, [r13+r12*1]
000076b67a9cf28b  lea r12, [rax+0xB0]
000076b67a9cf292  movups xmm13, [r13+r12*1]
000076b67a9cf298  lea r12, [rax+0x120]
000076b67a9cf29f  vmovaps [rsp+0x10], xmm1
000076b67a9cf2a5  movups xmm1, [r13+r12*1]
000076b67a9cf2ab  lea r12, [rax+0x130]
000076b67a9cf2b2  vmovaps [rsp+0x20], xmm1
000076b67a9cf2b8  movups xmm1, [r13+r12*1]
000076b67a9cf2be  lea r12, [rax+0x160]
000076b67a9cf2c5  vmovaps [rsp+0x30], xmm1
000076b67a9cf2cb  movups xmm1, [r13+r12*1]
000076b67a9cf2d1  lea r12, [rax+0x170]
000076b67a9cf2d8  vmovaps [rsp+0x40], xmm1
000076b67a9cf2de  movups xmm1, [r13+r12*1]
000076b67a9cf2e4  movaps [r15+0x2B0], xmm1
000076b67a9cf2ec  lea r12, [r14+0x80]
000076b67a9cf2f3  movups [r13+r12*1], xmm13
000076b67a9cf2f9  lea r12, [r14+0x90]
000076b67a9cf300  vmovaps xmm13, [rsp+0x10]
000076b67a9cf306  movups [r13+r12*1], xmm13
000076b67a9cf30c  lea r12, [rax+0x1A0]
000076b67a9cf313  movups xmm13, [r13+r12*1]
000076b67a9cf319  lea r12, [rax+0x1B0]
000076b67a9cf320  vmovaps [rsp+0x10], xmm1
000076b67a9cf326  movups xmm1, [r13+r12*1]
000076b67a9cf32c  movaps [r15+0x290], xmm13
000076b67a9cf334  movaps [r15+0x1E0], xmm1
000076b67a9cf33c  lea r12, [rax+0x1E0]
000076b67a9cf343  vmovaps [rsp+0x50], xmm1
000076b67a9cf349  movups xmm1, [r13+r12*1]
000076b67a9cf34f  lea r12, [rax+0x1F0]
000076b67a9cf356  vmovaps [rsp+0x60], xmm1
000076b67a9cf35c  movups xmm1, [r13+r12*1]
000076b67a9cf362  mov qword ptr [r15+0x50], 0x430920
000076b67a9cf36a  lea rax, [r14+0x40]
000076b67a9cf36e  vmovaps [rsp+0x70], xmm1
000076b67a9cf374  vmovaps xmm1, [rsp+0x40]
000076b67a9cf37a  movups [r13+rax*1], xmm1
000076b67a9cf380  lea rax, [r14+0x50]
000076b67a9cf384  movups [r13+rax*1], xmm10
000076b67a9cf38a  vmovaps xmm1, [rsp+0x70]
000076b67a9cf390  movups [r13+r14*1], xmm1
000076b67a9cf396  lea rax, [r14+0x10]
000076b67a9cf39a  vmovaps xmm1, [rsp+0x60]
000076b67a9cf3a0  movups [r13+rax*1], xmm1
000076b67a9cf3a6  mov rax, [r15+0x40]
000076b67a9cf3aa  vmovaps [rsp+0x40], xmm3
000076b67a9cf3b0  vmovaps xmm1, [rsp+0x40]
000076b67a9cf3b6  por xmm3, xmm1
000076b67a9cf3ba  vmovaps [rsp+0x40], xmm6
000076b67a9cf3c0  vmovaps xmm10, [rsp+0x40]
000076b67a9cf3c6  por xmm6, xmm10
000076b67a9cf3cb  lea r12, [rax+0x30]
000076b67a9cf3cf  mov r11, [r13+r12*1]
000076b67a9cf3d4  lea r12, [rax+0x38]
000076b67a9cf3d8  mov r10, [r13+r12*1]
000076b67a9cf3dd  movq xmm10, r11
000076b67a9cf3e2  vmovaps [rsp+0x40], xmm1
000076b67a9cf3e8  movq xmm1, r10
000076b67a9cf3ed  movq xmm10, xmm10
000076b67a9cf3f2  vmovaps [rsp+0x60], xmm10
000076b67a9cf3f8  movq xmm10, xmm10
000076b67a9cf3fd  movaps [r15+0x130], xmm10
000076b67a9cf405  movq xmm1, xmm1
000076b67a9cf409  vmovaps [rsp+0x70], xmm1
000076b67a9cf40f  movq xmm1, xmm1
000076b67a9cf413  movaps [r15+0x280], xmm1
000076b67a9cf41b  vmovaps [rsp+0x80], xmm9
000076b67a9cf424  vmovaps xmm1, [rsp+0x80]
000076b67a9cf42d  por xmm9, xmm1
000076b67a9cf432  lea r12, [rax+0x20]
000076b67a9cf436  mov r11, [r13+r12*1]
000076b67a9cf43b  lea r12, [rax+0x28]
000076b67a9cf43f  mov r10, [r13+r12*1]
000076b67a9cf444  movq xmm1, r11
000076b67a9cf449  movq xmm10, r10
000076b67a9cf44e  movq xmm1, xmm1
000076b67a9cf452  vmovaps [rsp+0x80], xmm1
000076b67a9cf45b  movq xmm1, xmm1
000076b67a9cf45f  movaps [r15+0x150], xmm1
000076b67a9cf467  movq xmm10, xmm10
000076b67a9cf46c  vmovaps [rsp+0x90], xmm10
000076b67a9cf475  movq xmm10, xmm10
000076b67a9cf47a  movaps [r15+0x140], xmm10
000076b67a9cf482  lea r12, [rax+0x10]
000076b67a9cf486  mov r11, [r13+r12*1]
000076b67a9cf48b  lea r12, [rax+0x18]
000076b67a9cf48f  mov r10, [r13+r12*1]
000076b67a9cf494  movq xmm1, r11
000076b67a9cf499  movq xmm10, r10
000076b67a9cf49e  movq xmm1, xmm1
000076b67a9cf4a2  vmovaps [rsp+0xA0], xmm1
000076b67a9cf4ab  movq xmm1, xmm1
000076b67a9cf4af  movaps [r15+0x170], xmm1
000076b67a9cf4b7  movq xmm10, xmm10
000076b67a9cf4bc  vmovaps [rsp+0xB0], xmm10
000076b67a9cf4c5  movq xmm10, xmm10
000076b67a9cf4ca  movaps [r15+0x160], xmm10
000076b67a9cf4d2  mov r12, [r13+rax*1]
000076b67a9cf4d7  vmovq xmm1, r12
000076b67a9cf4dc  vpbroadcastq xmm1, xmm1
000076b67a9cf4e1  lea r12, [rax+0x08]
000076b67a9cf4e5  mov rax, [r13+r12*1]
000076b67a9cf4ea  movq xmm10, rax
000076b67a9cf4ef  movaps [r15+0x230], xmm10
000076b67a9cf4f7  lea rax, [r14+0x50]
000076b67a9cf4fb  movups xmm10, [r13+rax*1]
000076b67a9cf501  lea rax, [r14+0x60]
000076b67a9cf505  vmovaps [rsp+0xC0], xmm1
000076b67a9cf50e  movups xmm1, [r13+rax*1]
000076b67a9cf514  lea rax, [r14+0x30]
000076b67a9cf518  vmovaps [rsp+0xD0], xmm1
000076b67a9cf521  movups xmm1, [r13+rax*1]
000076b67a9cf527  mov qword ptr [r15+0x60], 0x430920
000076b67a9cf52f  mov qword ptr [r15+0x58], 0x40
000076b67a9cf537  vmovaps [rsp+0xE0], xmm1
000076b67a9cf540  vmovaps [rsp+0xF0], xmm15
000076b67a9cf549  vmovaps xmm15, [rsp+0xC0]
000076b67a9cf552  vmovaps [rsp+0xC0], xmm14
000076b67a9cf55b  vmovaps xmm14, [rsp+0x40]
000076b67a9cf561  vmovaps [rsp+0x40], xmm13
000076b67a9cf567  movaps xmm1, xmm15
000076b67a9cf56b  mulpd xmm1, xmm14
000076b67a9cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000076b67a9cf575  ptest xmm13, xmm13
000076b67a9cf57b  jnz 0x000076B67A9D0682
000076b67a9cf581  movq xmm14, qword ptr [r15+0x230]
000076b67a9cf58a  vmovaps [rsp+0x100], xmm14
000076b67a9cf593  vpermilpd xmm14, xmm14, 0x00
000076b67a9cf599  vmovaps [rsp+0x110], xmm1
000076b67a9cf5a2  vmovaps xmm1, [rsp+0xE0]
000076b67a9cf5ab  vmovaps [rsp+0xE0], xmm15
000076b67a9cf5b4  movaps xmm13, xmm1
000076b67a9cf5b8  mulpd xmm13, xmm14
000076b67a9cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000076b67a9cf5c3  ptest xmm15, xmm15
000076b67a9cf5c9  jnz 0x000076B67A9D07C4
000076b67a9cf5cf  vxorps xmm1, xmm1, xmm1
000076b67a9cf5d3  vpbroadcastq xmm1, xmm1
000076b67a9cf5d8  vmovaps xmm14, [rsp+0xE0]
000076b67a9cf5e1  vmovaps [rsp+0xE0], xmm1
000076b67a9cf5ea  vmovaps xmm1, [rsp+0xD0]
000076b67a9cf5f3  vmovaps [rsp+0xD0], xmm13
000076b67a9cf5fc  movaps xmm15, xmm14
000076b67a9cf600  mulpd xmm15, xmm1
000076b67a9cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000076b67a9cf60b  ptest xmm13, xmm13
000076b67a9cf611  jnz 0x000076B67A9D0907
000076b67a9cf617  movaps xmm1, xmm14
000076b67a9cf61b  mulpd xmm1, xmm10
000076b67a9cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000076b67a9cf625  ptest xmm13, xmm13
000076b67a9cf62b  jnz 0x000076B67A9D0A4A
000076b67a9cf631  movaps xmm13, xmm14
000076b67a9cf635  mulpd xmm13, xmm2
000076b67a9cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000076b67a9cf640  ptest xmm10, xmm10
000076b67a9cf646  jnz 0x000076B67A9D0B8C
000076b67a9cf64c  vmovaps [rsp+0x120], xmm7
000076b67a9cf655  vmovaps xmm14, [rsp+0x120]
000076b67a9cf65e  por xmm7, xmm14
000076b67a9cf663  vmovaps xmm14, [rsp+0xC0]
000076b67a9cf66c  vmovaps xmm10, [rsp+0xC0]
000076b67a9cf675  por xmm14, xmm10
000076b67a9cf67a  vmovaps xmm2, [rsp+0x100]
000076b67a9cf683  vpermilpd xmm2, xmm2, 0x00
000076b67a9cf689  vmovaps [rsp+0xC0], xmm1
000076b67a9cf692  vmovaps [rsp+0x120], xmm15
000076b67a9cf69b  movaps xmm1, xmm10
000076b67a9cf69f  mulpd xmm1, xmm2
000076b67a9cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000076b67a9cf6a8  ptest xmm15, xmm15
000076b67a9cf6ae  jnz 0x000076B67A9D0CCF
000076b67a9cf6b4  xor eax, eax
000076b67a9cf6b6  mov r12d, 0x40
000076b67a9cf6bc  mov r11d, 0x200
000076b67a9cf6c2  cmp r12, r11
000076b67a9cf6c5  cmc
000076b67a9cf6c6  lahf
000076b67a9cf6c7  seto al
000076b67a9cf6ca  mov [r15+0x108], eax
000076b67a9cf6d1  vmovaps xmm10, [rsp+0x110]
000076b67a9cf6da  vmovaps xmm2, [rsp+0xE0]
000076b67a9cf6e3  vmovaps [rsp+0xE0], xmm1
000076b67a9cf6ec  movaps xmm15, xmm10
000076b67a9cf6f0  addpd xmm15, xmm2
000076b67a9cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000076b67a9cf6fb  ptest xmm1, xmm1
000076b67a9cf700  jnz 0x000076B67A9D0E10
000076b67a9cf706  vmovaps xmm10, [rsp+0x120]
000076b67a9cf70f  vmovaps [rsp+0x110], xmm15
000076b67a9cf718  movaps xmm1, xmm10
000076b67a9cf71c  addpd xmm1, xmm12
000076b67a9cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000076b67a9cf726  ptest xmm15, xmm15
000076b67a9cf72c  jnz 0x000076B67A9D0F53
000076b67a9cf732  vmovaps xmm10, [rsp+0xC0]
000076b67a9cf73b  vmovaps [rsp+0xC0], xmm1
000076b67a9cf744  movaps xmm15, xmm10
000076b67a9cf748  addpd xmm15, xmm12
000076b67a9cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000076b67a9cf753  ptest xmm1, xmm1
000076b67a9cf758  jnz 0x000076B67A9D1095
000076b67a9cf75e  vmovaps xmm1, [rsp+0x30]
000076b67a9cf764  vmovaps xmm12, [rsp+0x30]
000076b67a9cf76a  por xmm1, xmm12
000076b67a9cf76f  vmovaps xmm12, [rsp+0x20]
000076b67a9cf775  vmovaps xmm10, [rsp+0x20]
000076b67a9cf77b  por xmm12, xmm10
000076b67a9cf780  vmovaps [rsp+0x20], xmm5
000076b67a9cf786  vmovaps xmm10, [rsp+0x20]
000076b67a9cf78c  por xmm5, xmm10
000076b67a9cf791  vmovaps [rsp+0x20], xmm11
000076b67a9cf797  vmovaps xmm10, [rsp+0x20]
000076b67a9cf79d  por xmm11, xmm10
000076b67a9cf7a2  vmovaps [rsp+0x20], xmm4
000076b67a9cf7a8  vmovaps xmm10, [rsp+0x20]
000076b67a9cf7ae  por xmm4, xmm10
000076b67a9cf7b3  vmovaps [rsp+0x20], xmm8
000076b67a9cf7b9  vmovaps xmm10, [rsp+0x20]
000076b67a9cf7bf  por xmm8, xmm10
000076b67a9cf7c4  vmovaps xmm10, [rsp+0xF0]
000076b67a9cf7cd  vmovaps [rsp+0x20], xmm1
000076b67a9cf7d3  vmovaps xmm1, [rsp+0xF0]
000076b67a9cf7dc  por xmm10, xmm1
000076b67a9cf7e1  lea rax, [r14+0xA0]
000076b67a9cf7e8  movups xmm1, [r13+rax*1]
000076b67a9cf7ee  lea rax, [r14+0xB0]
000076b67a9cf7f5  vmovaps [rsp+0x30], xmm1
000076b67a9cf7fb  movups xmm1, [r13+rax*1]
000076b67a9cf801  vmovaps [rsp+0xF0], xmm1
000076b67a9cf80a  vmovaps [rsp+0x120], xmm15
000076b67a9cf813  movaps xmm1, xmm13
000076b67a9cf817  addpd xmm1, xmm2
000076b67a9cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000076b67a9cf820  ptest xmm15, xmm15
000076b67a9cf826  jnz 0x000076B67A9D11ED
000076b67a9cf82c  lea rax, [r14+0xF0]
000076b67a9cf833  movups xmm15, [r13+rax*1]
000076b67a9cf839  vmovaps xmm2, [rsp+0xC0]
000076b67a9cf842  vmovaps [rsp+0xC0], xmm1
000076b67a9cf84b  vmovaps xmm1, [rsp+0xE0]
000076b67a9cf854  vmovaps [rsp+0xE0], xmm15
000076b67a9cf85d  movaps xmm13, xmm2
000076b67a9cf861  addpd xmm13, xmm1
000076b67a9cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000076b67a9cf86c  ptest xmm15, xmm15
000076b67a9cf872  jnz 0x000076B67A9D1338
000076b67a9cf878  vmovaps xmm15, [rsp+0x120]
000076b67a9cf881  vmovaps xmm2, [rsp+0xD0]
000076b67a9cf88a  vmovaps [rsp+0xD0], xmm14
000076b67a9cf893  movaps xmm1, xmm15
000076b67a9cf897  addpd xmm1, xmm2
000076b67a9cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000076b67a9cf8a0  ptest xmm14, xmm14
000076b67a9cf8a6  jnz 0x000076B67A9D147A
000076b67a9cf8ac  vmovaps xmm15, [rsp+0x100]
000076b67a9cf8b5  vpermilpd xmm15, xmm15, 0x00
000076b67a9cf8bb  vmovaps xmm2, [rsp+0xF0]
000076b67a9cf8c4  vmovaps [rsp+0xF0], xmm1
000076b67a9cf8cd  movaps xmm14, xmm2
000076b67a9cf8d1  mulpd xmm14, xmm15
000076b67a9cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000076b67a9cf8dc  ptest xmm1, xmm1
000076b67a9cf8e1  jnz 0x000076B67A9D15BB
000076b67a9cf8e7  vmovaps xmm1, [rsp+0xA0]
000076b67a9cf8f0  vpermilpd xmm1, xmm1, 0x00
000076b67a9cf8f6  vmovaps xmm2, [rsp+0xE0]
000076b67a9cf8ff  vmovaps [rsp+0xE0], xmm14
000076b67a9cf908  movaps xmm15, xmm2
000076b67a9cf90c  mulpd xmm15, xmm1
000076b67a9cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000076b67a9cf917  ptest xmm14, xmm14
000076b67a9cf91d  jnz 0x000076B67A9D16FE
000076b67a9cf923  lea rax, [r14+0xE0]
000076b67a9cf92a  movups xmm1, [r13+rax*1]
000076b67a9cf930  vmovaps xmm14, [rsp+0x100]
000076b67a9cf939  vpermilpd xmm14, xmm14, 0x00
000076b67a9cf93f  vmovaps [rsp+0x100], xmm1
000076b67a9cf948  vmovaps xmm1, [rsp+0x30]
000076b67a9cf94e  vmovaps [rsp+0x30], xmm15
000076b67a9cf954  movaps xmm2, xmm1
000076b67a9cf957  mulpd xmm2, xmm14
000076b67a9cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000076b67a9cf961  ptest xmm15, xmm15
000076b67a9cf967  jnz 0x000076B67A9D184A
000076b67a9cf96d  vmovaps [rsp+0x120], xmm10
000076b67a9cf976  vmovaps xmm1, [rsp+0x120]
000076b67a9cf97f  por xmm10, xmm1
000076b67a9cf984  movaps [r15+0x300], xmm10
000076b67a9cf98c  vmovaps [rsp+0x120], xmm8
000076b67a9cf995  vmovaps xmm1, [rsp+0x120]
000076b67a9cf99e  por xmm8, xmm1
000076b67a9cf9a3  movaps [r15+0x190], xmm8
000076b67a9cf9ab  vmovaps xmm1, [rsp+0xA0]
000076b67a9cf9b4  vpermilpd xmm1, xmm1, 0x00
000076b67a9cf9ba  vmovaps xmm14, [rsp+0x100]
000076b67a9cf9c3  vmovaps [rsp+0x100], xmm13
000076b67a9cf9cc  movaps xmm15, xmm14
000076b67a9cf9d0  mulpd xmm15, xmm1
000076b67a9cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000076b67a9cf9db  ptest xmm13, xmm13
000076b67a9cf9e1  jnz 0x000076B67A9D198B
000076b67a9cf9e7  lea rax, [r14+0x90]
000076b67a9cf9ee  movups xmm1, [r13+rax*1]
000076b67a9cf9f4  vmovaps [rsp+0x120], xmm4
000076b67a9cf9fd  vmovaps xmm14, [rsp+0x120]
000076b67a9cfa06  por xmm4, xmm14
000076b67a9cfa0b  movaps [r15+0x1C0], xmm4
000076b67a9cfa13  vmovaps [rsp+0x120], xmm11
000076b67a9cfa1c  vmovaps xmm14, [rsp+0x120]
000076b67a9cfa25  por xmm11, xmm14
000076b67a9cfa2a  movaps [r15+0x200], xmm11
000076b67a9cfa32  vmovaps [rsp+0x120], xmm5
000076b67a9cfa3b  vmovaps xmm14, [rsp+0x120]
000076b67a9cfa44  por xmm5, xmm14
000076b67a9cfa49  movaps [r15+0x2D0], xmm5
000076b67a9cfa51  vmovaps [rsp+0x120], xmm12
000076b67a9cfa5a  vmovaps xmm14, [rsp+0x120]
000076b67a9cfa63  por xmm12, xmm14
000076b67a9cfa68  movaps [r15+0x2E0], xmm12
000076b67a9cfa70  vmovaps xmm13, [rsp+0x110]
000076b67a9cfa79  vmovaps [rsp+0x110], xmm1
000076b67a9cfa82  vmovaps xmm1, [rsp+0xE0]
000076b67a9cfa8b  vmovaps [rsp+0xE0], xmm15
000076b67a9cfa94  movaps xmm14, xmm13
000076b67a9cfa98  addpd xmm14, xmm1
000076b67a9cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000076b67a9cfaa3  ptest xmm15, xmm15
000076b67a9cfaa9  jnz 0x000076B67A9D1AD8
000076b67a9cfaaf  vmovaps xmm1, [rsp+0xA0]
000076b67a9cfab8  vpermilpd xmm1, xmm1, 0x00
000076b67a9cfabe  vmovaps xmm13, [rsp+0x110]
000076b67a9cfac7  vmovaps [rsp+0x110], xmm14
000076b67a9cfad0  movaps xmm15, xmm13
000076b67a9cfad4  mulpd xmm15, xmm1
000076b67a9cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000076b67a9cfadf  ptest xmm14, xmm14
000076b67a9cfae5  jnz 0x000076B67A9D1C1B
000076b67a9cfaeb  lea rax, [r14+0x80]
000076b67a9cfaf2  movups xmm1, [r13+rax*1]
000076b67a9cfaf8  vmovaps xmm13, [rsp+0xC0]
000076b67a9cfb01  vmovaps [rsp+0xC0], xmm1
000076b67a9cfb0a  movaps xmm14, xmm13
000076b67a9cfb0e  addpd xmm14, xmm2
000076b67a9cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000076b67a9cfb19  ptest xmm1, xmm1
000076b67a9cfb1e  jnz 0x000076B67A9D1D68
000076b67a9cfb24  vmovaps xmm13, [rsp+0x100]
000076b67a9cfb2d  vmovaps xmm2, [rsp+0x30]
000076b67a9cfb33  vmovaps [rsp+0x30], xmm15
000076b67a9cfb39  movaps xmm1, xmm13
000076b67a9cfb3d  addpd xmm1, xmm2
000076b67a9cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000076b67a9cfb46  ptest xmm15, xmm15
000076b67a9cfb4c  jnz 0x000076B67A9D1EAB
000076b67a9cfb52  vmovaps xmm15, [rsp+0x20]
000076b67a9cfb58  vmovaps xmm13, [rsp+0x20]
000076b67a9cfb5e  por xmm15, xmm13
000076b67a9cfb63  movaps [r15+0x2F0], xmm15
000076b67a9cfb6b  vmovaps xmm13, [rsp+0xA0]
000076b67a9cfb74  vpermilpd xmm13, xmm13, 0x00
000076b67a9cfb7a  vmovaps [rsp+0x20], xmm1
000076b67a9cfb80  vmovaps xmm1, [rsp+0xC0]
000076b67a9cfb89  vmovaps [rsp+0xA0], xmm15
000076b67a9cfb92  movaps xmm2, xmm1
000076b67a9cfb95  mulpd xmm2, xmm13
000076b67a9cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000076b67a9cfb9f  ptest xmm15, xmm15
000076b67a9cfba5  jnz 0x000076B67A9D1FEC
000076b67a9cfbab  lea rax, [r14+0xD0]
000076b67a9cfbb2  movups xmm1, [r13+rax*1]
000076b67a9cfbb8  vmovaps xmm13, [rsp+0xF0]
000076b67a9cfbc1  vmovaps [rsp+0xC0], xmm1
000076b67a9cfbca  vmovaps xmm1, [rsp+0xE0]
000076b67a9cfbd3  vmovaps [rsp+0xE0], xmm14
000076b67a9cfbdc  movaps xmm15, xmm13
000076b67a9cfbe0  addpd xmm15, xmm1
000076b67a9cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000076b67a9cfbeb  ptest xmm14, xmm14
000076b67a9cfbf1  jnz 0x000076B67A9D2137
000076b67a9cfbf7  vmovaps xmm1, [rsp+0xB0]
000076b67a9cfc00  vpermilpd xmm1, xmm1, 0x00
000076b67a9cfc06  movaps xmm14, xmm11
000076b67a9cfc0a  mulpd xmm14, xmm1
000076b67a9cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000076b67a9cfc15  ptest xmm13, xmm13
000076b67a9cfc1b  jnz 0x000076B67A9D227A
000076b67a9cfc21  movaps [r15+0x260], xmm14
000076b67a9cfc29  vxorps xmm1, xmm1, xmm1
000076b67a9cfc2d  vpbroadcastq xmm1, xmm1
000076b67a9cfc32  movaps [r15+0x1B0], xmm1
000076b67a9cfc3a  vmovaps xmm1, [rsp+0xB0]
000076b67a9cfc43  vpermilpd xmm1, xmm1, 0x00
000076b67a9cfc49  vmovaps xmm11, [rsp+0xC0]
000076b67a9cfc52  vmovaps [rsp+0xC0], xmm15
000076b67a9cfc5b  movaps xmm13, xmm11
000076b67a9cfc5f  mulpd xmm13, xmm1
000076b67a9cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000076b67a9cfc6a  ptest xmm15, xmm15
000076b67a9cfc70  jnz 0x000076B67A9D23BD
000076b67a9cfc76  lea rax, [r14+0xC0]
000076b67a9cfc7d  movups xmm1, [r13+rax*1]
000076b67a9cfc83  vmovaps xmm11, [rsp+0x110]
000076b67a9cfc8c  vmovaps [rsp+0xF0], xmm1
000076b67a9cfc95  vmovaps xmm1, [rsp+0x30]
000076b67a9cfc9b  vmovaps [rsp+0x30], xmm14
000076b67a9cfca1  movaps xmm15, xmm11
000076b67a9cfca5  addpd xmm15, xmm1
000076b67a9cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000076b67a9cfcb0  ptest xmm14, xmm14
000076b67a9cfcb6  jnz 0x000076B67A9D250A
000076b67a9cfcbc  vmovaps [rsp+0x100], xmm9
000076b67a9cfcc5  vmovaps xmm1, [rsp+0x100]
000076b67a9cfcce  por xmm9, xmm1
000076b67a9cfcd3  movaps [r15+0x270], xmm9
000076b67a9cfcdb  vmovaps [rsp+0x100], xmm6
000076b67a9cfce4  vmovaps xmm1, [rsp+0x100]
000076b67a9cfced  por xmm6, xmm1
000076b67a9cfcf1  movaps [r15+0x1A0], xmm6
000076b67a9cfcf9  vmovaps xmm14, [rsp+0xB0]
000076b67a9cfd02  vpermilpd xmm14, xmm14, 0x00
000076b67a9cfd08  vmovaps xmm6, [rsp+0xF0]
000076b67a9cfd11  vmovaps [rsp+0xF0], xmm1
000076b67a9cfd1a  movaps xmm11, xmm6
000076b67a9cfd1e  mulpd xmm11, xmm14
000076b67a9cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000076b67a9cfd29  ptest xmm1, xmm1
000076b67a9cfd2e  jnz 0x000076B67A9D264D
000076b67a9cfd34  lea rax, [r14+0x20]
000076b67a9cfd38  movups xmm1, [r13+rax*1]
000076b67a9cfd3e  movaps [r15+0x110], xmm1
000076b67a9cfd46  vmovaps xmm6, [rsp+0xE0]
000076b67a9cfd4f  vmovaps [rsp+0xE0], xmm1
000076b67a9cfd58  movaps xmm14, xmm6
000076b67a9cfd5c  addpd xmm14, xmm2
000076b67a9cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000076b67a9cfd67  ptest xmm1, xmm1
000076b67a9cfd6c  jnz 0x000076B67A9D279A
000076b67a9cfd72  vmovaps xmm1, [rsp+0xB0]
000076b67a9cfd7b  vpermilpd xmm1, xmm1, 0x00
000076b67a9cfd81  movaps xmm6, xmm5
000076b67a9cfd84  mulpd xmm6, xmm1
000076b67a9cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000076b67a9cfd8d  ptest xmm2, xmm2
000076b67a9cfd92  jnz 0x000076B67A9D28DC
000076b67a9cfd98  vmovaps xmm5, [rsp+0x20]
000076b67a9cfd9e  movaps xmm1, xmm5
000076b67a9cfda1  addpd xmm1, xmm13
000076b67a9cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000076b67a9cfdab  ptest xmm2, xmm2
000076b67a9cfdb0  jnz 0x000076B67A9D2A1C
000076b67a9cfdb6  vmovaps xmm13, [rsp+0x80]
000076b67a9cfdbf  vpermilpd xmm13, xmm13, 0x00
000076b67a9cfdc5  vmovaps xmm2, [rsp+0xE0]
000076b67a9cfdce  vmovaps [rsp+0x20], xmm1
000076b67a9cfdd4  movaps xmm5, xmm2
000076b67a9cfdd7  mulpd xmm5, xmm13
000076b67a9cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000076b67a9cfde1  ptest xmm1, xmm1
000076b67a9cfde6  jnz 0x000076B67A9D2B5D
000076b67a9cfdec  vmovaps xmm1, [rsp+0x80]
000076b67a9cfdf5  vpermilpd xmm1, xmm1, 0x00
000076b67a9cfdfb  movaps xmm13, xmm10
000076b67a9cfdff  mulpd xmm13, xmm1
000076b67a9cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000076b67a9cfe0a  ptest xmm2, xmm2
000076b67a9cfe0f  jnz 0x000076B67A9D2C9E
000076b67a9cfe15  vmovaps xmm10, [rsp+0x30]
000076b67a9cfe1b  movaps xmm1, xmm15
000076b67a9cfe1f  addpd xmm1, xmm10
000076b67a9cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000076b67a9cfe29  ptest xmm2, xmm2
000076b67a9cfe2e  jnz 0x000076B67A9D2DE1
000076b67a9cfe34  vmovaps xmm10, [rsp+0xC0]
000076b67a9cfe3d  movaps xmm15, xmm10
000076b67a9cfe41  addpd xmm15, xmm11
000076b67a9cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000076b67a9cfe4c  ptest xmm2, xmm2
000076b67a9cfe51  jnz 0x000076B67A9D2F23
000076b67a9cfe57  vmovaps xmm11, [rsp+0x80]
000076b67a9cfe60  vpermilpd xmm11, xmm11, 0x00
000076b67a9cfe66  movaps xmm10, xmm12
000076b67a9cfe6a  mulpd xmm10, xmm11
000076b67a9cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000076b67a9cfe75  ptest xmm2, xmm2
000076b67a9cfe7a  jnz 0x000076B67A9D3067
000076b67a9cfe80  vmovaps xmm12, [rsp+0x80]
000076b67a9cfe89  vpermilpd xmm12, xmm12, 0x00
000076b67a9cfe8f  vmovaps xmm2, [rsp+0xA0]
000076b67a9cfe98  vmovaps [rsp+0x30], xmm1
000076b67a9cfe9e  movaps xmm11, xmm2
000076b67a9cfea2  mulpd xmm11, xmm12
000076b67a9cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000076b67a9cfead  ptest xmm1, xmm1
000076b67a9cfeb2  jnz 0x000076B67A9D31AB
000076b67a9cfeb8  movaps xmm1, xmm14
000076b67a9cfebc  addpd xmm1, xmm6
000076b67a9cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000076b67a9cfec5  ptest xmm12, xmm12
000076b67a9cfecb  jnz 0x000076B67A9D32EE
000076b67a9cfed1  vmovaps xmm12, [rsp+0x20]
000076b67a9cfed7  movaps xmm14, xmm12
000076b67a9cfedb  addpd xmm14, xmm5
000076b67a9cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000076b67a9cfee6  ptest xmm6, xmm6
000076b67a9cfeeb  jnz 0x000076B67A9D342F
000076b67a9cfef1  vmovaps xmm12, [rsp+0x90]
000076b67a9cfefa  vpermilpd xmm12, xmm12, 0x00
000076b67a9cff00  movaps xmm6, xmm9
000076b67a9cff04  mulpd xmm6, xmm12
000076b67a9cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000076b67a9cff0e  ptest xmm5, xmm5
000076b67a9cff13  jnz 0x000076B67A9D3572
000076b67a9cff19  movaps xmm12, xmm15
000076b67a9cff1d  addpd xmm12, xmm13
000076b67a9cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000076b67a9cff28  ptest xmm9, xmm9
000076b67a9cff2e  jnz 0x000076B67A9D36B4
000076b67a9cff34  vmovaps xmm13, [rsp+0x30]
000076b67a9cff3a  movaps xmm15, xmm13
000076b67a9cff3e  addpd xmm15, xmm10
000076b67a9cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000076b67a9cff49  ptest xmm9, xmm9
000076b67a9cff4f  jnz 0x000076B67A9D37F8
000076b67a9cff55  vmovaps xmm13, [rsp+0xD0]
000076b67a9cff5e  vmovaps xmm10, [rsp+0xD0]
000076b67a9cff67  por xmm13, xmm10
000076b67a9cff6c  movaps [r15+0x250], xmm13
000076b67a9cff74  vmovaps [rsp+0x20], xmm7
000076b67a9cff7a  vmovaps xmm13, [rsp+0x20]
000076b67a9cff80  por xmm7, xmm13
000076b67a9cff85  movaps [r15+0x2A0], xmm7
000076b67a9cff8d  vmovaps [rsp+0x20], xmm3
000076b67a9cff93  vmovaps xmm13, [rsp+0x20]
000076b67a9cff99  por xmm3, xmm13
000076b67a9cff9e  movaps [r15+0x1D0], xmm3
000076b67a9cffa6  lea rax, [r14+0x40]
000076b67a9cffaa  movups xmm13, [r13+rax*1]
000076b67a9cffb0  movaps [r15+0x2C0], xmm13
000076b67a9cffb8  vmovaps xmm10, [rsp+0x90]
000076b67a9cffc1  vpermilpd xmm10, xmm10, 0x00
000076b67a9cffc7  movaps xmm9, xmm8
000076b67a9cffcb  mulpd xmm9, xmm10
000076b67a9cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000076b67a9cffd6  ptest xmm5, xmm5
000076b67a9cffdb  jnz 0x000076B67A9D3946
000076b67a9cffe1  movaps xmm10, xmm1
000076b67a9cffe5  addpd xmm10, xmm11
000076b67a9cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000076b67a9cfff0  ptest xmm8, xmm8
000076b67a9cfff6  jnz 0x000076B67A9D3A8A
000076b67a9cfffc  movaps xmm1, xmm14
000076b67a9d0000  addpd xmm1, xmm6
000076b67a9d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000076b67a9d0009  ptest xmm11, xmm11
000076b67a9d000f  jnz 0x000076B67A9D3BCD
000076b67a9d0015  vmovaps xmm14, [rsp+0x90]
000076b67a9d001e  vpermilpd xmm14, xmm14, 0x00
000076b67a9d0024  movaps xmm11, xmm13
000076b67a9d0028  mulpd xmm11, xmm14
000076b67a9d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000076b67a9d0033  ptest xmm8, xmm8
000076b67a9d0039  jnz 0x000076B67A9D3D0E
000076b67a9d003f  vmovaps xmm14, [rsp+0x90]
000076b67a9d0048  vpermilpd xmm14, xmm14, 0x00
000076b67a9d004e  vmovaps xmm8, [rsp+0x10]
000076b67a9d0054  movaps xmm13, xmm8
000076b67a9d0058  mulpd xmm13, xmm14
000076b67a9d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000076b67a9d0063  ptest xmm6, xmm6
000076b67a9d0068  jnz 0x000076B67A9D3E52
000076b67a9d006e  vmovaps xmm14, [rsp+0x60]
000076b67a9d0074  vpermilpd xmm14, xmm14, 0x00
000076b67a9d007a  movaps xmm8, xmm7
000076b67a9d007e  mulpd xmm8, xmm14
000076b67a9d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000076b67a9d0089  ptest xmm6, xmm6
000076b67a9d008e  jnz 0x000076B67A9D3F96
000076b67a9d0094  movaps xmm14, xmm12
000076b67a9d0098  addpd xmm14, xmm9
000076b67a9d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000076b67a9d00a3  ptest xmm7, xmm7
000076b67a9d00a8  jnz 0x000076B67A9D40D9
000076b67a9d00ae  vmovaps xmm12, [rsp+0x60]
000076b67a9d00b4  vpermilpd xmm12, xmm12, 0x00
000076b67a9d00ba  vmovaps xmm7, [rsp+0xF0]
000076b67a9d00c3  movaps xmm9, xmm7
000076b67a9d00c7  mulpd xmm9, xmm12
000076b67a9d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000076b67a9d00d2  ptest xmm6, xmm6
000076b67a9d00d7  jnz 0x000076B67A9D421D
000076b67a9d00dd  movaps xmm12, xmm15
000076b67a9d00e1  addpd xmm12, xmm11
000076b67a9d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000076b67a9d00ec  ptest xmm7, xmm7
000076b67a9d00f1  jnz 0x000076B67A9D4360
000076b67a9d00f7  vmovaps xmm15, [rsp+0x60]
000076b67a9d00fd  vpermilpd xmm15, xmm15, 0x00
000076b67a9d0103  vmovaps xmm7, [rsp+0x40]
000076b67a9d0109  movaps xmm11, xmm7
000076b67a9d010d  mulpd xmm11, xmm15
000076b67a9d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000076b67a9d0118  ptest xmm6, xmm6
000076b67a9d011d  jnz 0x000076B67A9D44A4
000076b67a9d0123  movaps xmm15, xmm10
000076b67a9d0127  addpd xmm15, xmm13
000076b67a9d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000076b67a9d0132  ptest xmm7, xmm7
000076b67a9d0137  jnz 0x000076B67A9D45E7
000076b67a9d013d  vmovaps xmm13, [rsp+0x60]
000076b67a9d0143  vpermilpd xmm13, xmm13, 0x00
000076b67a9d0149  vmovaps xmm7, [rsp+0x50]
000076b67a9d014f  movaps xmm10, xmm7
000076b67a9d0153  mulpd xmm10, xmm13
000076b67a9d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000076b67a9d015e  ptest xmm6, xmm6
000076b67a9d0163  jnz 0x000076B67A9D472B
000076b67a9d0169  movaps xmm13, xmm1
000076b67a9d016d  addpd xmm13, xmm8
000076b67a9d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000076b67a9d0178  ptest xmm7, xmm7
000076b67a9d017d  jnz 0x000076B67A9D486E
000076b67a9d0183  lea rax, [r14+0x70]
000076b67a9d0187  movups xmm1, [r13+rax*1]
000076b67a9d018d  movaps [r15+0x240], xmm1
000076b67a9d0195  movaps xmm8, xmm14
000076b67a9d0199  addpd xmm8, xmm9
000076b67a9d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000076b67a9d01a4  ptest xmm7, xmm7
000076b67a9d01a9  jnz 0x000076B67A9D49BB
000076b67a9d01af  movaps [r15+0x170], xmm8
000076b67a9d01b7  vmovaps xmm14, [rsp+0x70]
000076b67a9d01bd  vpermilpd xmm14, xmm14, 0x00
000076b67a9d01c3  movaps xmm9, xmm1
000076b67a9d01c7  mulpd xmm9, xmm14
000076b67a9d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000076b67a9d01d2  ptest xmm7, xmm7
000076b67a9d01d7  jnz 0x000076B67A9D4AFF
000076b67a9d01dd  vmovaps xmm1, [rsp+0x70]
000076b67a9d01e3  vpermilpd xmm1, xmm1, 0x00
000076b67a9d01e9  movaps xmm14, xmm4
000076b67a9d01ed  mulpd xmm14, xmm1
000076b67a9d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000076b67a9d01f8  ptest xmm7, xmm7
000076b67a9d01fd  jnz 0x000076B67A9D4C42
000076b67a9d0203  movaps [r15+0x180], xmm14
000076b67a9d020b  movaps xmm1, xmm12
000076b67a9d020f  addpd xmm1, xmm11
000076b67a9d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000076b67a9d0219  ptest xmm7, xmm7
000076b67a9d021e  jnz 0x000076B67A9D4D84
000076b67a9d0224  movaps [r15+0x210], xmm1
000076b67a9d022c  movups xmm12, [r13+r14*1]
000076b67a9d0232  lea rax, [r14+0x10]
000076b67a9d0236  movups xmm11, [r13+rax*1]
000076b67a9d023c  movaps [r15+0x230], xmm11
000076b67a9d0244  movaps xmm7, xmm15
000076b67a9d0248  addpd xmm7, xmm10
000076b67a9d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000076b67a9d0252  ptest xmm6, xmm6
000076b67a9d0257  jnz 0x000076B67A9D4EDA
000076b67a9d025d  movaps [r15+0x130], xmm7
000076b67a9d0265  vmovaps xmm15, [rsp+0x70]
000076b67a9d026b  vpermilpd xmm15, xmm15, 0x00
000076b67a9d0271  movaps xmm10, xmm11
000076b67a9d0275  mulpd xmm10, xmm15
000076b67a9d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000076b67a9d0280  ptest xmm6, xmm6
000076b67a9d0285  jnz 0x000076B67A9D501C
000076b67a9d028b  movaps [r15+0x220], xmm10
000076b67a9d0293  vmovaps xmm15, [rsp+0x70]
000076b67a9d0299  vpermilpd xmm15, xmm15, 0x00
000076b67a9d029f  movaps xmm11, xmm12
000076b67a9d02a3  mulpd xmm11, xmm15
000076b67a9d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000076b67a9d02ae  ptest xmm6, xmm6
000076b67a9d02b3  jnz 0x000076B67A9D5160
000076b67a9d02b9  movaps xmm15, xmm13
000076b67a9d02bd  addpd xmm15, xmm9
000076b67a9d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000076b67a9d02c8  ptest xmm12, xmm12
000076b67a9d02ce  jnz 0x000076B67A9D52A4
000076b67a9d02d4  movaps [r15+0x140], xmm15
000076b67a9d02dc  movaps xmm13, xmm8
000076b67a9d02e0  addpd xmm13, xmm14
000076b67a9d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000076b67a9d02eb  ptest xmm12, xmm12
000076b67a9d02f1  jnz 0x000076B67A9D53E8
000076b67a9d02f7  movaps [r15+0x150], xmm13
000076b67a9d02ff  movaps xmm14, xmm1
000076b67a9d0303  addpd xmm14, xmm10
000076b67a9d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000076b67a9d030e  ptest xmm12, xmm12
000076b67a9d0314  jnz 0x000076B67A9D552C
000076b67a9d031a  movaps [r15+0x160], xmm14
000076b67a9d0322  movaps xmm1, xmm7
000076b67a9d0325  addpd xmm1, xmm11
000076b67a9d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000076b67a9d032f  ptest xmm12, xmm12
000076b67a9d0335  jnz 0x000076B67A9D566F
000076b67a9d033b  movaps [r15+0x120], xmm1
000076b67a9d0343  mov eax, 0x430920
000076b67a9d0348  movups [r13+rax*1], xmm15
000076b67a9d034e  mov eax, 0x430930
000076b67a9d0353  movups [r13+rax*1], xmm13
000076b67a9d0359  mov eax, 0x430940
000076b67a9d035e  movups [r13+rax*1], xmm14
000076b67a9d0364  mov eax, 0x430950
000076b67a9d0369  movups [r13+rax*1], xmm1
000076b67a9d036f  mov eax, [r15+0x108]
000076b67a9d0376  sahf
000076b67a9d0377  jnz 0x000076B67A9D03A9
000076b67a9d0379  cmp dword ptr [r15+0x318], 0x00
000076b67a9d0381  jz 0x000076B67A9DB900
000076b67a9d0387  nop [rax+rax*1], ax
000076b67a9d0390  nop [rax+rax*1], eax
000076b67a9d0398  mov eax, 0x410444
000076b67a9d039d  mov [r15+0x100], rax
000076b67a9d03a4  jmp 0x000076B67A7FE110
000076b67a9d03a9  cmp dword ptr [r15+0x318], 0x00
000076b67a9d03b1  jz 0x000076B67A9D57E0
000076b67a9d03b7  nop [rax+rax*1], ax
000076b67a9d03c0  nop [rax+rax*1], eax
000076b67a9d03c8  mov eax, 0x410278
000076b67a9d03cd  mov [r15+0x100], rax
000076b67a9d03d4  jmp 0x000076B67A7FE110
000076b67a9d03d9  int3
000076b67a9d03da  call 0x000076B67A8B52F0
000076b67a9d03df  jmp 0x000076B67A9CF016
000076b67a9d03e4  call 0x000076B67A8C4620
000076b67a9d03e9  jmp 0x000076B67A9CF023
000076b67a9d03ee  call 0x000076B67A8C33A0
000076b67a9d03f3  jmp 0x000076B67A9CF035
000076b67a9d03f8  call 0x000076B67A8C2120
000076b67a9d03fd  jmp 0x000076B67A9CF03F
000076b67a9d0402  call 0x000076B67A8C0860
000076b67a9d0407  jmp 0x000076B67A9CF067
000076b67a9d040c  call 0x000076B67A8BF5F0
000076b67a9d0411  jmp 0x000076B67A9CF073
000076b67a9d0416  call 0x000076B67A8C0860
000076b67a9d041b  jmp 0x000076B67A9CF0A5
000076b67a9d0420  call 0x000076B67A8BF5F0
000076b67a9d0425  jmp 0x000076B67A9CF0B1
000076b67a9d042a  call 0x000076B67A8C4740
000076b67a9d042f  jmp 0x000076B67A9CF0BE
000076b67a9d0434  call 0x000076B67A8B5400
000076b67a9d0439  jmp 0x000076B67A9CF0CB
000076b67a9d043e  call 0x000076B67A8B52F0
000076b67a9d0443  jmp 0x000076B67A9CF0D8
000076b67a9d0448  call 0x000076B67A8C4620
000076b67a9d044d  jmp 0x000076B67A9CF0E5
000076b67a9d0452  call 0x000076B67A8C0860
000076b67a9d0457  jmp 0x000076B67A9CF10D
000076b67a9d045c  call 0x000076B67A8BF5F0
000076b67a9d0461  jmp 0x000076B67A9CF119
000076b67a9d0466  call 0x000076B67A809D70
000076b67a9d046b  jmp 0x000076B67A9CF11F
000076b67a9d0470  call 0x000076B67A8BE9C0
000076b67a9d0475  jmp 0x000076B67A9CF129
000076b67a9d047a  call 0x000076B67A8C0860
000076b67a9d047f  jmp 0x000076B67A9CF151
000076b67a9d0484  call 0x000076B67A8BF5F0
000076b67a9d0489  jmp 0x000076B67A9CF15D
000076b67a9d048e  call 0x000076B67A8BD750
000076b67a9d0493  jmp 0x000076B67A9CF16A
000076b67a9d0498  call 0x000076B67A8BC4E0
000076b67a9d049d  jmp 0x000076B67A9CF177
000076b67a9d04a2  call 0x000076B67A8C4740
000076b67a9d04a7  jmp 0x000076B67A9CF184
000076b67a9d04ac  call 0x000076B67A8B5400
000076b67a9d04b1  jmp 0x000076B67A9CF191
000076b67a9d04b6  call 0x000076B67A8B52F0
000076b67a9d04bb  jmp 0x000076B67A9CF19E
000076b67a9d04c0  call 0x000076B67A8C4620
000076b67a9d04c5  jmp 0x000076B67A9CF1AB
000076b67a9d04ca  call 0x000076B67A8C0860
000076b67a9d04cf  jmp 0x000076B67A9CF1BE
000076b67a9d04d4  call 0x000076B67A8BB270
000076b67a9d04d9  jmp 0x000076B67A9CF1CB
000076b67a9d04de  call 0x000076B67A8BA000
000076b67a9d04e3  jmp 0x000076B67A9CF1D8
000076b67a9d04e8  call 0x000076B67A8B8D90
000076b67a9d04ed  jmp 0x000076B67A9CF1E5
000076b67a9d04f2  call 0x000076B67A8B8A20
000076b67a9d04f7  jmp 0x000076B67A9CF1F2
000076b67a9d04fc  call 0x000076B67A8B5400
000076b67a9d0501  jmp 0x000076B67A9CF1FC
000076b67a9d0506  call 0x000076B67A8C2240
000076b67a9d050b  jmp 0x000076B67A9CF206
000076b67a9d0510  call 0x000076B67A8B52F0
000076b67a9d0515  jmp 0x000076B67A9CF210
000076b67a9d051a  call 0x000076B67A8C2120
000076b67a9d051f  jmp 0x000076B67A9CF21A
000076b67a9d0524  call 0x000076B67A8B77B0
000076b67a9d0529  jmp 0x000076B67A9CF224
000076b67a9d052e  call 0x000076B67A8B6550
000076b67a9d0533  jmp 0x000076B67A9CF22E
000076b67a9d0538  call 0x000076B67A8BFD50
000076b67a9d053d  jmp 0x000076B67A9CF240
000076b67a9d0542  call 0x000076B67A8B8EA0
000076b67a9d0547  jmp 0x000076B67A9CF24A
000076b67a9d054c  call 0x000076B67A8BFC30
000076b67a9d0551  jmp 0x000076B67A9CF257
000076b67a9d0556  call 0x000076B67A8B8D90
000076b67a9d055b  jmp 0x000076B67A9CF264
000076b67a9d0560  call 0x000076B67A8C2240
000076b67a9d0565  jmp 0x000076B67A9CF271
000076b67a9d056a  call 0x000076B67A8B5400
000076b67a9d056f  jmp 0x000076B67A9CF27E
000076b67a9d0574  call 0x000076B67A8B52F0
000076b67a9d0579  jmp 0x000076B67A9CF28B
000076b67a9d057e  call 0x000076B67A8C2120
000076b67a9d0583  jmp 0x000076B67A9CF298
000076b67a9d0588  call 0x000076B67A8B52F0
000076b67a9d058d  jmp 0x000076B67A9CF2AB
000076b67a9d0592  call 0x000076B67A8B52F0
000076b67a9d0597  jmp 0x000076B67A9CF2BE
000076b67a9d059c  call 0x000076B67A8B52F0
000076b67a9d05a1  jmp 0x000076B67A9CF2D1
000076b67a9d05a6  call 0x000076B67A8B52F0
000076b67a9d05ab  jmp 0x000076B67A9CF2E4
000076b67a9d05b0  call 0x000076B67A8C2240
000076b67a9d05b5  jmp 0x000076B67A9CF2F9
000076b67a9d05ba  call 0x000076B67A8C2240
000076b67a9d05bf  jmp 0x000076B67A9CF30C
000076b67a9d05c4  call 0x000076B67A8C2120
000076b67a9d05c9  jmp 0x000076B67A9CF319
000076b67a9d05ce  call 0x000076B67A8B52F0
000076b67a9d05d3  jmp 0x000076B67A9CF32C
000076b67a9d05d8  call 0x000076B67A8B52F0
000076b67a9d05dd  jmp 0x000076B67A9CF34F
000076b67a9d05e2  call 0x000076B67A8B52F0
000076b67a9d05e7  jmp 0x000076B67A9CF362
000076b67a9d05ec  call 0x000076B67A7FF540
000076b67a9d05f1  jmp 0x000076B67A9CF380
000076b67a9d05f6  call 0x000076B67A808C20
000076b67a9d05fb  jmp 0x000076B67A9CF38A
000076b67a9d0600  call 0x000076B67A8D6600
000076b67a9d0605  jmp 0x000076B67A9CF396
000076b67a9d060a  call 0x000076B67A7FF540
000076b67a9d060f  jmp 0x000076B67A9CF3A6
000076b67a9d0614  call 0x000076B67A8C0370
000076b67a9d0619  jmp 0x000076B67A9CF3D4
000076b67a9d061e  call 0x000076B67A8BF100
000076b67a9d0623  jmp 0x000076B67A9CF3DD
000076b67a9d0628  call 0x000076B67A8C0370
000076b67a9d062d  jmp 0x000076B67A9CF43B
000076b67a9d0632  call 0x000076B67A8BF100
000076b67a9d0637  jmp 0x000076B67A9CF444
000076b67a9d063c  call 0x000076B67A8C0370
000076b67a9d0641  jmp 0x000076B67A9CF48B
000076b67a9d0646  call 0x000076B67A8BF100
000076b67a9d064b  jmp 0x000076B67A9CF494
000076b67a9d0650  call 0x000076B67A80B720
000076b67a9d0655  jmp 0x000076B67A9CF4D7
000076b67a9d065a  call 0x000076B67A8B47C0
000076b67a9d065f  jmp 0x000076B67A9CF4EA
000076b67a9d0664  call 0x000076B67A808B00
000076b67a9d0669  jmp 0x000076B67A9CF501
000076b67a9d066e  call 0x000076B67A7FF430
000076b67a9d0673  jmp 0x000076B67A9CF514
000076b67a9d0678  call 0x000076B67A7FF430
000076b67a9d067d  jmp 0x000076B67A9CF527
000076b67a9d0682  sub rsp, 0x08
000076b67a9d0686  push rax
000076b67a9d0687  push rcx
000076b67a9d0688  push rdx
000076b67a9d0689  push rdi
000076b67a9d068a  push rsi
000076b67a9d068b  push r8
000076b67a9d068d  push r9
000076b67a9d068f  push r10
000076b67a9d0691  push r11
000076b67a9d0693  sub rsp, 0xF0
000076b67a9d069a  vmovaps [rsp], xmm0
000076b67a9d069f  vmovaps [rsp+0x10], xmm2
000076b67a9d06a5  vmovaps [rsp+0x20], xmm3
000076b67a9d06ab  vmovaps [rsp+0x30], xmm4
000076b67a9d06b1  vmovaps [rsp+0x40], xmm5
000076b67a9d06b7  vmovaps [rsp+0x50], xmm6
000076b67a9d06bd  vmovaps [rsp+0x60], xmm7
000076b67a9d06c3  vmovaps [rsp+0x70], xmm8
000076b67a9d06c9  vmovaps [rsp+0x80], xmm9
000076b67a9d06d2  vmovaps [rsp+0x90], xmm10
000076b67a9d06db  vmovaps [rsp+0xA0], xmm11
000076b67a9d06e4  vmovaps [rsp+0xB0], xmm12
000076b67a9d06ed  vmovaps [rsp+0xC0], xmm13
000076b67a9d06f6  vmovaps [rsp+0xD0], xmm14
000076b67a9d06ff  vmovaps [rsp+0xE0], xmm15
000076b67a9d0708  sub rsp, 0x30
000076b67a9d070c  movaps [rsp], xmm1
000076b67a9d0710  movaps [rsp+0x10], xmm15
000076b67a9d0716  movaps [rsp+0x20], xmm14
000076b67a9d071c  lea rdi, [rsp]
000076b67a9d0720  mov esi, 0x00
000076b67a9d0725  mov rax, 0x63C5EF2DF530
000076b67a9d072f  call rax
000076b67a9d0731  movaps xmm1, [rsp]
000076b67a9d0735  add rsp, 0x30
000076b67a9d0739  vmovaps xmm0, [rsp]
000076b67a9d073e  vmovaps xmm2, [rsp+0x10]
000076b67a9d0744  vmovaps xmm3, [rsp+0x20]
000076b67a9d074a  vmovaps xmm4, [rsp+0x30]
000076b67a9d0750  vmovaps xmm5, [rsp+0x40]
000076b67a9d0756  vmovaps xmm6, [rsp+0x50]
000076b67a9d075c  vmovaps xmm7, [rsp+0x60]
000076b67a9d0762  vmovaps xmm8, [rsp+0x70]
000076b67a9d0768  vmovaps xmm9, [rsp+0x80]
000076b67a9d0771  vmovaps xmm10, [rsp+0x90]
000076b67a9d077a  vmovaps xmm11, [rsp+0xA0]
000076b67a9d0783  vmovaps xmm12, [rsp+0xB0]
000076b67a9d078c  vmovaps xmm13, [rsp+0xC0]
000076b67a9d0795  vmovaps xmm14, [rsp+0xD0]
000076b67a9d079e  vmovaps xmm15, [rsp+0xE0]
000076b67a9d07a7  add rsp, 0xF0
000076b67a9d07ae  pop r11
000076b67a9d07b0  pop r10
000076b67a9d07b2  pop r9
000076b67a9d07b4  pop r8
000076b67a9d07b6  pop rsi
000076b67a9d07b7  pop rdi
000076b67a9d07b8  pop rdx
000076b67a9d07b9  pop rcx
000076b67a9d07ba  pop rax
000076b67a9d07bb  add rsp, 0x08
000076b67a9d07bf  jmp 0x000076B67A9CF581
000076b67a9d07c4  sub rsp, 0x08
000076b67a9d07c8  push rax
000076b67a9d07c9  push rcx
000076b67a9d07ca  push rdx
000076b67a9d07cb  push rdi
000076b67a9d07cc  push rsi
000076b67a9d07cd  push r8
000076b67a9d07cf  push r9
000076b67a9d07d1  push r10
000076b67a9d07d3  push r11
000076b67a9d07d5  sub rsp, 0xF0
000076b67a9d07dc  vmovaps [rsp], xmm0
000076b67a9d07e1  vmovaps [rsp+0x10], xmm1
000076b67a9d07e7  vmovaps [rsp+0x20], xmm2
000076b67a9d07ed  vmovaps [rsp+0x30], xmm3
000076b67a9d07f3  vmovaps [rsp+0x40], xmm4
000076b67a9d07f9  vmovaps [rsp+0x50], xmm5
000076b67a9d07ff  vmovaps [rsp+0x60], xmm6
000076b67a9d0805  vmovaps [rsp+0x70], xmm7
000076b67a9d080b  vmovaps [rsp+0x80], xmm8
000076b67a9d0814  vmovaps [rsp+0x90], xmm9
000076b67a9d081d  vmovaps [rsp+0xA0], xmm10
000076b67a9d0826  vmovaps [rsp+0xB0], xmm11
000076b67a9d082f  vmovaps [rsp+0xC0], xmm12
000076b67a9d0838  vmovaps [rsp+0xD0], xmm14
000076b67a9d0841  vmovaps [rsp+0xE0], xmm15
000076b67a9d084a  sub rsp, 0x30
000076b67a9d084e  movaps [rsp], xmm13
000076b67a9d0853  movaps [rsp+0x10], xmm1
000076b67a9d0858  movaps [rsp+0x20], xmm14
000076b67a9d085e  lea rdi, [rsp]
000076b67a9d0862  mov esi, 0x00
000076b67a9d0867  mov rax, 0x63C5EF2DF530
000076b67a9d0871  call rax
000076b67a9d0873  movaps xmm13, [rsp]
000076b67a9d0878  add rsp, 0x30
000076b67a9d087c  vmovaps xmm0, [rsp]
000076b67a9d0881  vmovaps xmm1, [rsp+0x10]
000076b67a9d0887  vmovaps xmm2, [rsp+0x20]
000076b67a9d088d  vmovaps xmm3, [rsp+0x30]
000076b67a9d0893  vmovaps xmm4, [rsp+0x40]
000076b67a9d0899  vmovaps xmm5, [rsp+0x50]
000076b67a9d089f  vmovaps xmm6, [rsp+0x60]
000076b67a9d08a5  vmovaps xmm7, [rsp+0x70]
000076b67a9d08ab  vmovaps xmm8, [rsp+0x80]
000076b67a9d08b4  vmovaps xmm9, [rsp+0x90]
000076b67a9d08bd  vmovaps xmm10, [rsp+0xA0]
000076b67a9d08c6  vmovaps xmm11, [rsp+0xB0]
000076b67a9d08cf  vmovaps xmm12, [rsp+0xC0]
000076b67a9d08d8  vmovaps xmm14, [rsp+0xD0]
000076b67a9d08e1  vmovaps xmm15, [rsp+0xE0]
000076b67a9d08ea  add rsp, 0xF0
000076b67a9d08f1  pop r11
000076b67a9d08f3  pop r10
000076b67a9d08f5  pop r9
000076b67a9d08f7  pop r8
000076b67a9d08f9  pop rsi
000076b67a9d08fa  pop rdi
000076b67a9d08fb  pop rdx
000076b67a9d08fc  pop rcx
000076b67a9d08fd  pop rax
000076b67a9d08fe  add rsp, 0x08
000076b67a9d0902  jmp 0x000076B67A9CF5CF
000076b67a9d0907  sub rsp, 0x08
000076b67a9d090b  push rax
000076b67a9d090c  push rcx
000076b67a9d090d  push rdx
000076b67a9d090e  push rdi
000076b67a9d090f  push rsi
000076b67a9d0910  push r8
000076b67a9d0912  push r9
000076b67a9d0914  push r10
000076b67a9d0916  push r11
000076b67a9d0918  sub rsp, 0xF0
000076b67a9d091f  vmovaps [rsp], xmm0
000076b67a9d0924  vmovaps [rsp+0x10], xmm1
000076b67a9d092a  vmovaps [rsp+0x20], xmm2
000076b67a9d0930  vmovaps [rsp+0x30], xmm3
000076b67a9d0936  vmovaps [rsp+0x40], xmm4
000076b67a9d093c  vmovaps [rsp+0x50], xmm5
000076b67a9d0942  vmovaps [rsp+0x60], xmm6
000076b67a9d0948  vmovaps [rsp+0x70], xmm7
000076b67a9d094e  vmovaps [rsp+0x80], xmm8
000076b67a9d0957  vmovaps [rsp+0x90], xmm9
000076b67a9d0960  vmovaps [rsp+0xA0], xmm10
000076b67a9d0969  vmovaps [rsp+0xB0], xmm11
000076b67a9d0972  vmovaps [rsp+0xC0], xmm12
000076b67a9d097b  vmovaps [rsp+0xD0], xmm13
000076b67a9d0984  vmovaps [rsp+0xE0], xmm14
000076b67a9d098d  sub rsp, 0x30
000076b67a9d0991  movaps [rsp], xmm15
000076b67a9d0996  movaps [rsp+0x10], xmm14
000076b67a9d099c  movaps [rsp+0x20], xmm1
000076b67a9d09a1  lea rdi, [rsp]
000076b67a9d09a5  mov esi, 0x00
000076b67a9d09aa  mov rax, 0x63C5EF2DF530
000076b67a9d09b4  call rax
000076b67a9d09b6  movaps xmm15, [rsp]
000076b67a9d09bb  add rsp, 0x30
000076b67a9d09bf  vmovaps xmm0, [rsp]
000076b67a9d09c4  vmovaps xmm1, [rsp+0x10]
000076b67a9d09ca  vmovaps xmm2, [rsp+0x20]
000076b67a9d09d0  vmovaps xmm3, [rsp+0x30]
000076b67a9d09d6  vmovaps xmm4, [rsp+0x40]
000076b67a9d09dc  vmovaps xmm5, [rsp+0x50]
000076b67a9d09e2  vmovaps xmm6, [rsp+0x60]
000076b67a9d09e8  vmovaps xmm7, [rsp+0x70]
000076b67a9d09ee  vmovaps xmm8, [rsp+0x80]
000076b67a9d09f7  vmovaps xmm9, [rsp+0x90]
000076b67a9d0a00  vmovaps xmm10, [rsp+0xA0]
000076b67a9d0a09  vmovaps xmm11, [rsp+0xB0]
000076b67a9d0a12  vmovaps xmm12, [rsp+0xC0]
000076b67a9d0a1b  vmovaps xmm13, [rsp+0xD0]
000076b67a9d0a24  vmovaps xmm14, [rsp+0xE0]
000076b67a9d0a2d  add rsp, 0xF0
000076b67a9d0a34  pop r11
000076b67a9d0a36  pop r10
000076b67a9d0a38  pop r9
000076b67a9d0a3a  pop r8
000076b67a9d0a3c  pop rsi
000076b67a9d0a3d  pop rdi
000076b67a9d0a3e  pop rdx
000076b67a9d0a3f  pop rcx
000076b67a9d0a40  pop rax
000076b67a9d0a41  add rsp, 0x08
000076b67a9d0a45  jmp 0x000076B67A9CF617
000076b67a9d0a4a  sub rsp, 0x08
000076b67a9d0a4e  push rax
000076b67a9d0a4f  push rcx
000076b67a9d0a50  push rdx
000076b67a9d0a51  push rdi
000076b67a9d0a52  push rsi
000076b67a9d0a53  push r8
000076b67a9d0a55  push r9
000076b67a9d0a57  push r10
000076b67a9d0a59  push r11
000076b67a9d0a5b  sub rsp, 0xF0
000076b67a9d0a62  vmovaps [rsp], xmm0
000076b67a9d0a67  vmovaps [rsp+0x10], xmm2
000076b67a9d0a6d  vmovaps [rsp+0x20], xmm3
000076b67a9d0a73  vmovaps [rsp+0x30], xmm4
000076b67a9d0a79  vmovaps [rsp+0x40], xmm5
000076b67a9d0a7f  vmovaps [rsp+0x50], xmm6
000076b67a9d0a85  vmovaps [rsp+0x60], xmm7
000076b67a9d0a8b  vmovaps [rsp+0x70], xmm8
000076b67a9d0a91  vmovaps [rsp+0x80], xmm9
000076b67a9d0a9a  vmovaps [rsp+0x90], xmm10
000076b67a9d0aa3  vmovaps [rsp+0xA0], xmm11
000076b67a9d0aac  vmovaps [rsp+0xB0], xmm12
000076b67a9d0ab5  vmovaps [rsp+0xC0], xmm13
000076b67a9d0abe  vmovaps [rsp+0xD0], xmm14
000076b67a9d0ac7  vmovaps [rsp+0xE0], xmm15
000076b67a9d0ad0  sub rsp, 0x30
000076b67a9d0ad4  movaps [rsp], xmm1
000076b67a9d0ad8  movaps [rsp+0x10], xmm14
000076b67a9d0ade  movaps [rsp+0x20], xmm10
000076b67a9d0ae4  lea rdi, [rsp]
000076b67a9d0ae8  mov esi, 0x00
000076b67a9d0aed  mov rax, 0x63C5EF2DF530
000076b67a9d0af7  call rax
000076b67a9d0af9  movaps xmm1, [rsp]
000076b67a9d0afd  add rsp, 0x30
000076b67a9d0b01  vmovaps xmm0, [rsp]
000076b67a9d0b06  vmovaps xmm2, [rsp+0x10]
000076b67a9d0b0c  vmovaps xmm3, [rsp+0x20]
000076b67a9d0b12  vmovaps xmm4, [rsp+0x30]
000076b67a9d0b18  vmovaps xmm5, [rsp+0x40]
000076b67a9d0b1e  vmovaps xmm6, [rsp+0x50]
000076b67a9d0b24  vmovaps xmm7, [rsp+0x60]
000076b67a9d0b2a  vmovaps xmm8, [rsp+0x70]
000076b67a9d0b30  vmovaps xmm9, [rsp+0x80]
000076b67a9d0b39  vmovaps xmm10, [rsp+0x90]
000076b67a9d0b42  vmovaps xmm11, [rsp+0xA0]
000076b67a9d0b4b  vmovaps xmm12, [rsp+0xB0]
000076b67a9d0b54  vmovaps xmm13, [rsp+0xC0]
000076b67a9d0b5d  vmovaps xmm14, [rsp+0xD0]
000076b67a9d0b66  vmovaps xmm15, [rsp+0xE0]
000076b67a9d0b6f  add rsp, 0xF0
000076b67a9d0b76  pop r11
000076b67a9d0b78  pop r10
000076b67a9d0b7a  pop r9
000076b67a9d0b7c  pop r8
000076b67a9d0b7e  pop rsi
000076b67a9d0b7f  pop rdi
000076b67a9d0b80  pop rdx
000076b67a9d0b81  pop rcx
000076b67a9d0b82  pop rax
000076b67a9d0b83  add rsp, 0x08
000076b67a9d0b87  jmp 0x000076B67A9CF631
000076b67a9d0b8c  sub rsp, 0x08
000076b67a9d0b90  push rax
000076b67a9d0b91  push rcx
000076b67a9d0b92  push rdx
000076b67a9d0b93  push rdi
000076b67a9d0b94  push rsi
000076b67a9d0b95  push r8
000076b67a9d0b97  push r9
000076b67a9d0b99  push r10
000076b67a9d0b9b  push r11
000076b67a9d0b9d  sub rsp, 0xF0
000076b67a9d0ba4  vmovaps [rsp], xmm0
000076b67a9d0ba9  vmovaps [rsp+0x10], xmm1
000076b67a9d0baf  vmovaps [rsp+0x20], xmm2
000076b67a9d0bb5  vmovaps [rsp+0x30], xmm3
000076b67a9d0bbb  vmovaps [rsp+0x40], xmm4
000076b67a9d0bc1  vmovaps [rsp+0x50], xmm5
000076b67a9d0bc7  vmovaps [rsp+0x60], xmm6
000076b67a9d0bcd  vmovaps [rsp+0x70], xmm7
000076b67a9d0bd3  vmovaps [rsp+0x80], xmm8
000076b67a9d0bdc  vmovaps [rsp+0x90], xmm9
000076b67a9d0be5  vmovaps [rsp+0xA0], xmm10
000076b67a9d0bee  vmovaps [rsp+0xB0], xmm11
000076b67a9d0bf7  vmovaps [rsp+0xC0], xmm12
000076b67a9d0c00  vmovaps [rsp+0xD0], xmm14
000076b67a9d0c09  vmovaps [rsp+0xE0], xmm15
000076b67a9d0c12  sub rsp, 0x30
000076b67a9d0c16  movaps [rsp], xmm13
000076b67a9d0c1b  movaps [rsp+0x10], xmm14
000076b67a9d0c21  movaps [rsp+0x20], xmm2
000076b67a9d0c26  lea rdi, [rsp]
000076b67a9d0c2a  mov esi, 0x00
000076b67a9d0c2f  mov rax, 0x63C5EF2DF530
000076b67a9d0c39  call rax
000076b67a9d0c3b  movaps xmm13, [rsp]
000076b67a9d0c40  add rsp, 0x30
000076b67a9d0c44  vmovaps xmm0, [rsp]
000076b67a9d0c49  vmovaps xmm1, [rsp+0x10]
000076b67a9d0c4f  vmovaps xmm2, [rsp+0x20]
000076b67a9d0c55  vmovaps xmm3, [rsp+0x30]
000076b67a9d0c5b  vmovaps xmm4, [rsp+0x40]
000076b67a9d0c61  vmovaps xmm5, [rsp+0x50]
000076b67a9d0c67  vmovaps xmm6, [rsp+0x60]
000076b67a9d0c6d  vmovaps xmm7, [rsp+0x70]
000076b67a9d0c73  vmovaps xmm8, [rsp+0x80]
000076b67a9d0c7c  vmovaps xmm9, [rsp+0x90]
000076b67a9d0c85  vmovaps xmm10, [rsp+0xA0]
000076b67a9d0c8e  vmovaps xmm11, [rsp+0xB0]
000076b67a9d0c97  vmovaps xmm12, [rsp+0xC0]
000076b67a9d0ca0  vmovaps xmm14, [rsp+0xD0]
000076b67a9d0ca9  vmovaps xmm15, [rsp+0xE0]
000076b67a9d0cb2  add rsp, 0xF0
000076b67a9d0cb9  pop r11
000076b67a9d0cbb  pop r10
000076b67a9d0cbd  pop r9
000076b67a9d0cbf  pop r8
000076b67a9d0cc1  pop rsi
000076b67a9d0cc2  pop rdi
000076b67a9d0cc3  pop rdx
000076b67a9d0cc4  pop rcx
000076b67a9d0cc5  pop rax
000076b67a9d0cc6  add rsp, 0x08
000076b67a9d0cca  jmp 0x000076B67A9CF64C
000076b67a9d0ccf  sub rsp, 0x08
000076b67a9d0cd3  push rax
000076b67a9d0cd4  push rcx
000076b67a9d0cd5  push rdx
000076b67a9d0cd6  push rdi
000076b67a9d0cd7  push rsi
000076b67a9d0cd8  push r8
000076b67a9d0cda  push r9
000076b67a9d0cdc  push r10
000076b67a9d0cde  push r11
000076b67a9d0ce0  sub rsp, 0xF0
000076b67a9d0ce7  vmovaps [rsp], xmm0
000076b67a9d0cec  vmovaps [rsp+0x10], xmm2
000076b67a9d0cf2  vmovaps [rsp+0x20], xmm3
000076b67a9d0cf8  vmovaps [rsp+0x30], xmm4
000076b67a9d0cfe  vmovaps [rsp+0x40], xmm5
000076b67a9d0d04  vmovaps [rsp+0x50], xmm6
000076b67a9d0d0a  vmovaps [rsp+0x60], xmm7
000076b67a9d0d10  vmovaps [rsp+0x70], xmm8
000076b67a9d0d16  vmovaps [rsp+0x80], xmm9
000076b67a9d0d1f  vmovaps [rsp+0x90], xmm10
000076b67a9d0d28  vmovaps [rsp+0xA0], xmm11
000076b67a9d0d31  vmovaps [rsp+0xB0], xmm12
000076b67a9d0d3a  vmovaps [rsp+0xC0], xmm13
000076b67a9d0d43  vmovaps [rsp+0xD0], xmm14
000076b67a9d0d4c  vmovaps [rsp+0xE0], xmm15
000076b67a9d0d55  sub rsp, 0x30
000076b67a9d0d59  movaps [rsp], xmm1
000076b67a9d0d5d  movaps [rsp+0x10], xmm10
000076b67a9d0d63  movaps [rsp+0x20], xmm2
000076b67a9d0d68  lea rdi, [rsp]
000076b67a9d0d6c  mov esi, 0x00
000076b67a9d0d71  mov rax, 0x63C5EF2DF530
000076b67a9d0d7b  call rax
000076b67a9d0d7d  movaps xmm1, [rsp]
000076b67a9d0d81  add rsp, 0x30
000076b67a9d0d85  vmovaps xmm0, [rsp]
000076b67a9d0d8a  vmovaps xmm2, [rsp+0x10]
000076b67a9d0d90  vmovaps xmm3, [rsp+0x20]
000076b67a9d0d96  vmovaps xmm4, [rsp+0x30]
000076b67a9d0d9c  vmovaps xmm5, [rsp+0x40]
000076b67a9d0da2  vmovaps xmm6, [rsp+0x50]
000076b67a9d0da8  vmovaps xmm7, [rsp+0x60]
000076b67a9d0dae  vmovaps xmm8, [rsp+0x70]
000076b67a9d0db4  vmovaps xmm9, [rsp+0x80]
000076b67a9d0dbd  vmovaps xmm10, [rsp+0x90]
000076b67a9d0dc6  vmovaps xmm11, [rsp+0xA0]
000076b67a9d0dcf  vmovaps xmm12, [rsp+0xB0]
000076b67a9d0dd8  vmovaps xmm13, [rsp+0xC0]
000076b67a9d0de1  vmovaps xmm14, [rsp+0xD0]
000076b67a9d0dea  vmovaps xmm15, [rsp+0xE0]
000076b67a9d0df3  add rsp, 0xF0
000076b67a9d0dfa  pop r11
000076b67a9d0dfc  pop r10
000076b67a9d0dfe  pop r9
000076b67a9d0e00  pop r8
000076b67a9d0e02  pop rsi
000076b67a9d0e03  pop rdi
000076b67a9d0e04  pop rdx
000076b67a9d0e05  pop rcx
000076b67a9d0e06  pop rax
000076b67a9d0e07  add rsp, 0x08
000076b67a9d0e0b  jmp 0x000076B67A9CF6B4
000076b67a9d0e10  sub rsp, 0x08
000076b67a9d0e14  push rax
000076b67a9d0e15  push rcx
000076b67a9d0e16  push rdx
000076b67a9d0e17  push rdi
000076b67a9d0e18  push rsi
000076b67a9d0e19  push r8
000076b67a9d0e1b  push r9
000076b67a9d0e1d  push r10
000076b67a9d0e1f  push r11
000076b67a9d0e21  sub rsp, 0xF0
000076b67a9d0e28  vmovaps [rsp], xmm0
000076b67a9d0e2d  vmovaps [rsp+0x10], xmm1
000076b67a9d0e33  vmovaps [rsp+0x20], xmm2
000076b67a9d0e39  vmovaps [rsp+0x30], xmm3
000076b67a9d0e3f  vmovaps [rsp+0x40], xmm4
000076b67a9d0e45  vmovaps [rsp+0x50], xmm5
000076b67a9d0e4b  vmovaps [rsp+0x60], xmm6
000076b67a9d0e51  vmovaps [rsp+0x70], xmm7
000076b67a9d0e57  vmovaps [rsp+0x80], xmm8
000076b67a9d0e60  vmovaps [rsp+0x90], xmm9
000076b67a9d0e69  vmovaps [rsp+0xA0], xmm10
000076b67a9d0e72  vmovaps [rsp+0xB0], xmm11
000076b67a9d0e7b  vmovaps [rsp+0xC0], xmm12
000076b67a9d0e84  vmovaps [rsp+0xD0], xmm13
000076b67a9d0e8d  vmovaps [rsp+0xE0], xmm14
000076b67a9d0e96  sub rsp, 0x30
000076b67a9d0e9a  movaps [rsp], xmm15
000076b67a9d0e9f  movaps [rsp+0x10], xmm10
000076b67a9d0ea5  movaps [rsp+0x20], xmm2
000076b67a9d0eaa  lea rdi, [rsp]
000076b67a9d0eae  mov esi, 0x00
000076b67a9d0eb3  mov rax, 0x63C5EF2DF530
000076b67a9d0ebd  call rax
000076b67a9d0ebf  movaps xmm15, [rsp]
000076b67a9d0ec4  add rsp, 0x30
000076b67a9d0ec8  vmovaps xmm0, [rsp]
000076b67a9d0ecd  vmovaps xmm1, [rsp+0x10]
000076b67a9d0ed3  vmovaps xmm2, [rsp+0x20]
000076b67a9d0ed9  vmovaps xmm3, [rsp+0x30]
000076b67a9d0edf  vmovaps xmm4, [rsp+0x40]
000076b67a9d0ee5  vmovaps xmm5, [rsp+0x50]
000076b67a9d0eeb  vmovaps xmm6, [rsp+0x60]
000076b67a9d0ef1  vmovaps xmm7, [rsp+0x70]
000076b67a9d0ef7  vmovaps xmm8, [rsp+0x80]
000076b67a9d0f00  vmovaps xmm9, [rsp+0x90]
000076b67a9d0f09  vmovaps xmm10, [rsp+0xA0]
000076b67a9d0f12  vmovaps xmm11, [rsp+0xB0]
000076b67a9d0f1b  vmovaps xmm12, [rsp+0xC0]
000076b67a9d0f24  vmovaps xmm13, [rsp+0xD0]
000076b67a9d0f2d  vmovaps xmm14, [rsp+0xE0]
000076b67a9d0f36  add rsp, 0xF0
000076b67a9d0f3d  pop r11
000076b67a9d0f3f  pop r10
000076b67a9d0f41  pop r9
000076b67a9d0f43  pop r8
000076b67a9d0f45  pop rsi
000076b67a9d0f46  pop rdi
000076b67a9d0f47  pop rdx
000076b67a9d0f48  pop rcx
000076b67a9d0f49  pop rax
000076b67a9d0f4a  add rsp, 0x08
000076b67a9d0f4e  jmp 0x000076B67A9CF706
000076b67a9d0f53  sub rsp, 0x08
000076b67a9d0f57  push rax
000076b67a9d0f58  push rcx
000076b67a9d0f59  push rdx
000076b67a9d0f5a  push rdi
000076b67a9d0f5b  push rsi
000076b67a9d0f5c  push r8
000076b67a9d0f5e  push r9
000076b67a9d0f60  push r10
000076b67a9d0f62  push r11
000076b67a9d0f64  sub rsp, 0xF0
000076b67a9d0f6b  vmovaps [rsp], xmm0
000076b67a9d0f70  vmovaps [rsp+0x10], xmm2
000076b67a9d0f76  vmovaps [rsp+0x20], xmm3
000076b67a9d0f7c  vmovaps [rsp+0x30], xmm4
000076b67a9d0f82  vmovaps [rsp+0x40], xmm5
000076b67a9d0f88  vmovaps [rsp+0x50], xmm6
000076b67a9d0f8e  vmovaps [rsp+0x60], xmm7
000076b67a9d0f94  vmovaps [rsp+0x70], xmm8
000076b67a9d0f9a  vmovaps [rsp+0x80], xmm9
000076b67a9d0fa3  vmovaps [rsp+0x90], xmm10
000076b67a9d0fac  vmovaps [rsp+0xA0], xmm11
000076b67a9d0fb5  vmovaps [rsp+0xB0], xmm12
000076b67a9d0fbe  vmovaps [rsp+0xC0], xmm13
000076b67a9d0fc7  vmovaps [rsp+0xD0], xmm14
000076b67a9d0fd0  vmovaps [rsp+0xE0], xmm15
000076b67a9d0fd9  sub rsp, 0x30
000076b67a9d0fdd  movaps [rsp], xmm1
000076b67a9d0fe1  movaps [rsp+0x10], xmm10
000076b67a9d0fe7  movaps [rsp+0x20], xmm12
000076b67a9d0fed  lea rdi, [rsp]
000076b67a9d0ff1  mov esi, 0x00
000076b67a9d0ff6  mov rax, 0x63C5EF2DF530
000076b67a9d1000  call rax
000076b67a9d1002  movaps xmm1, [rsp]
000076b67a9d1006  add rsp, 0x30
000076b67a9d100a  vmovaps xmm0, [rsp]
000076b67a9d100f  vmovaps xmm2, [rsp+0x10]
000076b67a9d1015  vmovaps xmm3, [rsp+0x20]
000076b67a9d101b  vmovaps xmm4, [rsp+0x30]
000076b67a9d1021  vmovaps xmm5, [rsp+0x40]
000076b67a9d1027  vmovaps xmm6, [rsp+0x50]
000076b67a9d102d  vmovaps xmm7, [rsp+0x60]
000076b67a9d1033  vmovaps xmm8, [rsp+0x70]
000076b67a9d1039  vmovaps xmm9, [rsp+0x80]
000076b67a9d1042  vmovaps xmm10, [rsp+0x90]
000076b67a9d104b  vmovaps xmm11, [rsp+0xA0]
000076b67a9d1054  vmovaps xmm12, [rsp+0xB0]
000076b67a9d105d  vmovaps xmm13, [rsp+0xC0]
000076b67a9d1066  vmovaps xmm14, [rsp+0xD0]
000076b67a9d106f  vmovaps xmm15, [rsp+0xE0]
000076b67a9d1078  add rsp, 0xF0
000076b67a9d107f  pop r11
000076b67a9d1081  pop r10
000076b67a9d1083  pop r9
000076b67a9d1085  pop r8
000076b67a9d1087  pop rsi
000076b67a9d1088  pop rdi
000076b67a9d1089  pop rdx
000076b67a9d108a  pop rcx
000076b67a9d108b  pop rax
000076b67a9d108c  add rsp, 0x08
000076b67a9d1090  jmp 0x000076B67A9CF732
000076b67a9d1095  sub rsp, 0x08
000076b67a9d1099  push rax
000076b67a9d109a  push rcx
000076b67a9d109b  push rdx
000076b67a9d109c  push rdi
000076b67a9d109d  push rsi
000076b67a9d109e  push r8
000076b67a9d10a0  push r9
000076b67a9d10a2  push r10
000076b67a9d10a4  push r11
000076b67a9d10a6  sub rsp, 0xF0
000076b67a9d10ad  vmovaps [rsp], xmm0
000076b67a9d10b2  vmovaps [rsp+0x10], xmm1
000076b67a9d10b8  vmovaps [rsp+0x20], xmm2
000076b67a9d10be  vmovaps [rsp+0x30], xmm3
000076b67a9d10c4  vmovaps [rsp+0x40], xmm4
000076b67a9d10ca  vmovaps [rsp+0x50], xmm5
000076b67a9d10d0  vmovaps [rsp+0x60], xmm6
000076b67a9d10d6  vmovaps [rsp+0x70], xmm7
000076b67a9d10dc  vmovaps [rsp+0x80], xmm8
000076b67a9d10e5  vmovaps [rsp+0x90], xmm9
000076b67a9d10ee  vmovaps [rsp+0xA0], xmm10
000076b67a9d10f7  vmovaps [rsp+0xB0], xmm11
000076b67a9d1100  vmovaps [rsp+0xC0], xmm12
000076b67a9d1109  vmovaps [rsp+0xD0], xmm13
000076b67a9d1112  vmovaps [rsp+0xE0], xmm14
000076b67a9d111b  sub rsp, 0x30
000076b67a9d111f  movaps [rsp], xmm15
000076b67a9d1124  movaps [rsp+0x10], xmm10
000076b67a9d112a  movaps [rsp+0x20], xmm12
000076b67a9d1130  lea rdi, [rsp]
000076b67a9d1134  mov esi, 0x00
000076b67a9d1139  mov rax, 0x63C5EF2DF530
000076b67a9d1143  call rax
000076b67a9d1145  movaps xmm15, [rsp]
000076b67a9d114a  add rsp, 0x30
000076b67a9d114e  vmovaps xmm0, [rsp]
000076b67a9d1153  vmovaps xmm1, [rsp+0x10]
000076b67a9d1159  vmovaps xmm2, [rsp+0x20]
000076b67a9d115f  vmovaps xmm3, [rsp+0x30]
000076b67a9d1165  vmovaps xmm4, [rsp+0x40]
000076b67a9d116b  vmovaps xmm5, [rsp+0x50]
000076b67a9d1171  vmovaps xmm6, [rsp+0x60]
000076b67a9d1177  vmovaps xmm7, [rsp+0x70]
000076b67a9d117d  vmovaps xmm8, [rsp+0x80]
000076b67a9d1186  vmovaps xmm9, [rsp+0x90]
000076b67a9d118f  vmovaps xmm10, [rsp+0xA0]
000076b67a9d1198  vmovaps xmm11, [rsp+0xB0]
000076b67a9d11a1  vmovaps xmm12, [rsp+0xC0]
000076b67a9d11aa  vmovaps xmm13, [rsp+0xD0]
000076b67a9d11b3  vmovaps xmm14, [rsp+0xE0]
000076b67a9d11bc  add rsp, 0xF0
000076b67a9d11c3  pop r11
000076b67a9d11c5  pop r10
000076b67a9d11c7  pop r9
000076b67a9d11c9  pop r8
000076b67a9d11cb  pop rsi
000076b67a9d11cc  pop rdi
000076b67a9d11cd  pop rdx
000076b67a9d11ce  pop rcx
000076b67a9d11cf  pop rax
000076b67a9d11d0  add rsp, 0x08
000076b67a9d11d4  jmp 0x000076B67A9CF75E
000076b67a9d11d9  call 0x000076B67A7FF430
000076b67a9d11de  jmp 0x000076B67A9CF7EE
000076b67a9d11e3  call 0x000076B67A7FF430
000076b67a9d11e8  jmp 0x000076B67A9CF801
000076b67a9d11ed  sub rsp, 0x08
000076b67a9d11f1  push rax
000076b67a9d11f2  push rcx
000076b67a9d11f3  push rdx
000076b67a9d11f4  push rdi
000076b67a9d11f5  push rsi
000076b67a9d11f6  push r8
000076b67a9d11f8  push r9
000076b67a9d11fa  push r10
000076b67a9d11fc  push r11
000076b67a9d11fe  sub rsp, 0xF0
000076b67a9d1205  vmovaps [rsp], xmm0
000076b67a9d120a  vmovaps [rsp+0x10], xmm2
000076b67a9d1210  vmovaps [rsp+0x20], xmm3
000076b67a9d1216  vmovaps [rsp+0x30], xmm4
000076b67a9d121c  vmovaps [rsp+0x40], xmm5
000076b67a9d1222  vmovaps [rsp+0x50], xmm6
000076b67a9d1228  vmovaps [rsp+0x60], xmm7
000076b67a9d122e  vmovaps [rsp+0x70], xmm8
000076b67a9d1234  vmovaps [rsp+0x80], xmm9
000076b67a9d123d  vmovaps [rsp+0x90], xmm10
000076b67a9d1246  vmovaps [rsp+0xA0], xmm11
000076b67a9d124f  vmovaps [rsp+0xB0], xmm12
000076b67a9d1258  vmovaps [rsp+0xC0], xmm13
000076b67a9d1261  vmovaps [rsp+0xD0], xmm14
000076b67a9d126a  vmovaps [rsp+0xE0], xmm15
000076b67a9d1273  sub rsp, 0x30
000076b67a9d1277  movaps [rsp], xmm1
000076b67a9d127b  movaps [rsp+0x10], xmm13
000076b67a9d1281  movaps [rsp+0x20], xmm2
000076b67a9d1286  lea rdi, [rsp]
000076b67a9d128a  mov esi, 0x00
000076b67a9d128f  mov rax, 0x63C5EF2DF530
000076b67a9d1299  call rax
000076b67a9d129b  movaps xmm1, [rsp]
000076b67a9d129f  add rsp, 0x30
000076b67a9d12a3  vmovaps xmm0, [rsp]
000076b67a9d12a8  vmovaps xmm2, [rsp+0x10]
000076b67a9d12ae  vmovaps xmm3, [rsp+0x20]
000076b67a9d12b4  vmovaps xmm4, [rsp+0x30]
000076b67a9d12ba  vmovaps xmm5, [rsp+0x40]
000076b67a9d12c0  vmovaps xmm6, [rsp+0x50]
000076b67a9d12c6  vmovaps xmm7, [rsp+0x60]
000076b67a9d12cc  vmovaps xmm8, [rsp+0x70]
000076b67a9d12d2  vmovaps xmm9, [rsp+0x80]
000076b67a9d12db  vmovaps xmm10, [rsp+0x90]
000076b67a9d12e4  vmovaps xmm11, [rsp+0xA0]
000076b67a9d12ed  vmovaps xmm12, [rsp+0xB0]
000076b67a9d12f6  vmovaps xmm13, [rsp+0xC0]
000076b67a9d12ff  vmovaps xmm14, [rsp+0xD0]
000076b67a9d1308  vmovaps xmm15, [rsp+0xE0]
000076b67a9d1311  add rsp, 0xF0
000076b67a9d1318  pop r11
000076b67a9d131a  pop r10
000076b67a9d131c  pop r9
000076b67a9d131e  pop r8
000076b67a9d1320  pop rsi
000076b67a9d1321  pop rdi
000076b67a9d1322  pop rdx
000076b67a9d1323  pop rcx
000076b67a9d1324  pop rax
000076b67a9d1325  add rsp, 0x08
000076b67a9d1329  jmp 0x000076B67A9CF82C
000076b67a9d132e  call 0x000076B67A80E760
000076b67a9d1333  jmp 0x000076B67A9CF839
000076b67a9d1338  sub rsp, 0x08
000076b67a9d133c  push rax
000076b67a9d133d  push rcx
000076b67a9d133e  push rdx
000076b67a9d133f  push rdi
000076b67a9d1340  push rsi
000076b67a9d1341  push r8
000076b67a9d1343  push r9
000076b67a9d1345  push r10
000076b67a9d1347  push r11
000076b67a9d1349  sub rsp, 0xF0
000076b67a9d1350  vmovaps [rsp], xmm0
000076b67a9d1355  vmovaps [rsp+0x10], xmm1
000076b67a9d135b  vmovaps [rsp+0x20], xmm2
000076b67a9d1361  vmovaps [rsp+0x30], xmm3
000076b67a9d1367  vmovaps [rsp+0x40], xmm4
000076b67a9d136d  vmovaps [rsp+0x50], xmm5
000076b67a9d1373  vmovaps [rsp+0x60], xmm6
000076b67a9d1379  vmovaps [rsp+0x70], xmm7
000076b67a9d137f  vmovaps [rsp+0x80], xmm8
000076b67a9d1388  vmovaps [rsp+0x90], xmm9
000076b67a9d1391  vmovaps [rsp+0xA0], xmm10
000076b67a9d139a  vmovaps [rsp+0xB0], xmm11
000076b67a9d13a3  vmovaps [rsp+0xC0], xmm12
000076b67a9d13ac  vmovaps [rsp+0xD0], xmm14
000076b67a9d13b5  vmovaps [rsp+0xE0], xmm15
000076b67a9d13be  sub rsp, 0x30
000076b67a9d13c2  movaps [rsp], xmm13
000076b67a9d13c7  movaps [rsp+0x10], xmm2
000076b67a9d13cc  movaps [rsp+0x20], xmm1
000076b67a9d13d1  lea rdi, [rsp]
000076b67a9d13d5  mov esi, 0x00
000076b67a9d13da  mov rax, 0x63C5EF2DF530
000076b67a9d13e4  call rax
000076b67a9d13e6  movaps xmm13, [rsp]
000076b67a9d13eb  add rsp, 0x30
000076b67a9d13ef  vmovaps xmm0, [rsp]
000076b67a9d13f4  vmovaps xmm1, [rsp+0x10]
000076b67a9d13fa  vmovaps xmm2, [rsp+0x20]
000076b67a9d1400  vmovaps xmm3, [rsp+0x30]
000076b67a9d1406  vmovaps xmm4, [rsp+0x40]
000076b67a9d140c  vmovaps xmm5, [rsp+0x50]
000076b67a9d1412  vmovaps xmm6, [rsp+0x60]
000076b67a9d1418  vmovaps xmm7, [rsp+0x70]
000076b67a9d141e  vmovaps xmm8, [rsp+0x80]
000076b67a9d1427  vmovaps xmm9, [rsp+0x90]
000076b67a9d1430  vmovaps xmm10, [rsp+0xA0]
000076b67a9d1439  vmovaps xmm11, [rsp+0xB0]
000076b67a9d1442  vmovaps xmm12, [rsp+0xC0]
000076b67a9d144b  vmovaps xmm14, [rsp+0xD0]
000076b67a9d1454  vmovaps xmm15, [rsp+0xE0]
000076b67a9d145d  add rsp, 0xF0
000076b67a9d1464  pop r11
000076b67a9d1466  pop r10
000076b67a9d1468  pop r9
000076b67a9d146a  pop r8
000076b67a9d146c  pop rsi
000076b67a9d146d  pop rdi
000076b67a9d146e  pop rdx
000076b67a9d146f  pop rcx
000076b67a9d1470  pop rax
000076b67a9d1471  add rsp, 0x08
000076b67a9d1475  jmp 0x000076B67A9CF878
000076b67a9d147a  sub rsp, 0x08
000076b67a9d147e  push rax
000076b67a9d147f  push rcx
000076b67a9d1480  push rdx
000076b67a9d1481  push rdi
000076b67a9d1482  push rsi
000076b67a9d1483  push r8
000076b67a9d1485  push r9
000076b67a9d1487  push r10
000076b67a9d1489  push r11
000076b67a9d148b  sub rsp, 0xF0
000076b67a9d1492  vmovaps [rsp], xmm0
000076b67a9d1497  vmovaps [rsp+0x10], xmm2
000076b67a9d149d  vmovaps [rsp+0x20], xmm3
000076b67a9d14a3  vmovaps [rsp+0x30], xmm4
000076b67a9d14a9  vmovaps [rsp+0x40], xmm5
000076b67a9d14af  vmovaps [rsp+0x50], xmm6
000076b67a9d14b5  vmovaps [rsp+0x60], xmm7
000076b67a9d14bb  vmovaps [rsp+0x70], xmm8
000076b67a9d14c1  vmovaps [rsp+0x80], xmm9
000076b67a9d14ca  vmovaps [rsp+0x90], xmm10
000076b67a9d14d3  vmovaps [rsp+0xA0], xmm11
000076b67a9d14dc  vmovaps [rsp+0xB0], xmm12
000076b67a9d14e5  vmovaps [rsp+0xC0], xmm13
000076b67a9d14ee  vmovaps [rsp+0xD0], xmm14
000076b67a9d14f7  vmovaps [rsp+0xE0], xmm15
000076b67a9d1500  sub rsp, 0x30
000076b67a9d1504  movaps [rsp], xmm1
000076b67a9d1508  movaps [rsp+0x10], xmm15
000076b67a9d150e  movaps [rsp+0x20], xmm2
000076b67a9d1513  lea rdi, [rsp]
000076b67a9d1517  mov esi, 0x00
000076b67a9d151c  mov rax, 0x63C5EF2DF530
000076b67a9d1526  call rax
000076b67a9d1528  movaps xmm1, [rsp]
000076b67a9d152c  add rsp, 0x30
000076b67a9d1530  vmovaps xmm0, [rsp]
000076b67a9d1535  vmovaps xmm2, [rsp+0x10]
000076b67a9d153b  vmovaps xmm3, [rsp+0x20]
000076b67a9d1541  vmovaps xmm4, [rsp+0x30]
000076b67a9d1547  vmovaps xmm5, [rsp+0x40]
000076b67a9d154d  vmovaps xmm6, [rsp+0x50]
000076b67a9d1553  vmovaps xmm7, [rsp+0x60]
000076b67a9d1559  vmovaps xmm8, [rsp+0x70]
000076b67a9d155f  vmovaps xmm9, [rsp+0x80]
000076b67a9d1568  vmovaps xmm10, [rsp+0x90]
000076b67a9d1571  vmovaps xmm11, [rsp+0xA0]
000076b67a9d157a  vmovaps xmm12, [rsp+0xB0]
000076b67a9d1583  vmovaps xmm13, [rsp+0xC0]
000076b67a9d158c  vmovaps xmm14, [rsp+0xD0]
000076b67a9d1595  vmovaps xmm15, [rsp+0xE0]
000076b67a9d159e  add rsp, 0xF0
000076b67a9d15a5  pop r11
000076b67a9d15a7  pop r10
000076b67a9d15a9  pop r9
000076b67a9d15ab  pop r8
000076b67a9d15ad  pop rsi
000076b67a9d15ae  pop rdi
000076b67a9d15af  pop rdx
000076b67a9d15b0  pop rcx
000076b67a9d15b1  pop rax
000076b67a9d15b2  add rsp, 0x08
000076b67a9d15b6  jmp 0x000076B67A9CF8AC
000076b67a9d15bb  sub rsp, 0x08
000076b67a9d15bf  push rax
000076b67a9d15c0  push rcx
000076b67a9d15c1  push rdx
000076b67a9d15c2  push rdi
000076b67a9d15c3  push rsi
000076b67a9d15c4  push r8
000076b67a9d15c6  push r9
000076b67a9d15c8  push r10
000076b67a9d15ca  push r11
000076b67a9d15cc  sub rsp, 0xF0
000076b67a9d15d3  vmovaps [rsp], xmm0
000076b67a9d15d8  vmovaps [rsp+0x10], xmm1
000076b67a9d15de  vmovaps [rsp+0x20], xmm2
000076b67a9d15e4  vmovaps [rsp+0x30], xmm3
000076b67a9d15ea  vmovaps [rsp+0x40], xmm4
000076b67a9d15f0  vmovaps [rsp+0x50], xmm5
000076b67a9d15f6  vmovaps [rsp+0x60], xmm6
000076b67a9d15fc  vmovaps [rsp+0x70], xmm7
000076b67a9d1602  vmovaps [rsp+0x80], xmm8
000076b67a9d160b  vmovaps [rsp+0x90], xmm9
000076b67a9d1614  vmovaps [rsp+0xA0], xmm10
000076b67a9d161d  vmovaps [rsp+0xB0], xmm11
000076b67a9d1626  vmovaps [rsp+0xC0], xmm12
000076b67a9d162f  vmovaps [rsp+0xD0], xmm13
000076b67a9d1638  vmovaps [rsp+0xE0], xmm15
000076b67a9d1641  sub rsp, 0x30
000076b67a9d1645  movaps [rsp], xmm14
000076b67a9d164a  movaps [rsp+0x10], xmm2
000076b67a9d164f  movaps [rsp+0x20], xmm15
000076b67a9d1655  lea rdi, [rsp]
000076b67a9d1659  mov esi, 0x00
000076b67a9d165e  mov rax, 0x63C5EF2DF530
000076b67a9d1668  call rax
000076b67a9d166a  movaps xmm14, [rsp]
000076b67a9d166f  add rsp, 0x30
000076b67a9d1673  vmovaps xmm0, [rsp]
000076b67a9d1678  vmovaps xmm1, [rsp+0x10]
000076b67a9d167e  vmovaps xmm2, [rsp+0x20]
000076b67a9d1684  vmovaps xmm3, [rsp+0x30]
000076b67a9d168a  vmovaps xmm4, [rsp+0x40]
000076b67a9d1690  vmovaps xmm5, [rsp+0x50]
000076b67a9d1696  vmovaps xmm6, [rsp+0x60]
000076b67a9d169c  vmovaps xmm7, [rsp+0x70]
000076b67a9d16a2  vmovaps xmm8, [rsp+0x80]
000076b67a9d16ab  vmovaps xmm9, [rsp+0x90]
000076b67a9d16b4  vmovaps xmm10, [rsp+0xA0]
000076b67a9d16bd  vmovaps xmm11, [rsp+0xB0]
000076b67a9d16c6  vmovaps xmm12, [rsp+0xC0]
000076b67a9d16cf  vmovaps xmm13, [rsp+0xD0]
000076b67a9d16d8  vmovaps xmm15, [rsp+0xE0]
000076b67a9d16e1  add rsp, 0xF0
000076b67a9d16e8  pop r11
000076b67a9d16ea  pop r10
000076b67a9d16ec  pop r9
000076b67a9d16ee  pop r8
000076b67a9d16f0  pop rsi
000076b67a9d16f1  pop rdi
000076b67a9d16f2  pop rdx
000076b67a9d16f3  pop rcx
000076b67a9d16f4  pop rax
000076b67a9d16f5  add rsp, 0x08
000076b67a9d16f9  jmp 0x000076B67A9CF8E7
000076b67a9d16fe  sub rsp, 0x08
000076b67a9d1702  push rax
000076b67a9d1703  push rcx
000076b67a9d1704  push rdx
000076b67a9d1705  push rdi
000076b67a9d1706  push rsi
000076b67a9d1707  push r8
000076b67a9d1709  push r9
000076b67a9d170b  push r10
000076b67a9d170d  push r11
000076b67a9d170f  sub rsp, 0xF0
000076b67a9d1716  vmovaps [rsp], xmm0
000076b67a9d171b  vmovaps [rsp+0x10], xmm1
000076b67a9d1721  vmovaps [rsp+0x20], xmm2
000076b67a9d1727  vmovaps [rsp+0x30], xmm3
000076b67a9d172d  vmovaps [rsp+0x40], xmm4
000076b67a9d1733  vmovaps [rsp+0x50], xmm5
000076b67a9d1739  vmovaps [rsp+0x60], xmm6
000076b67a9d173f  vmovaps [rsp+0x70], xmm7
000076b67a9d1745  vmovaps [rsp+0x80], xmm8
000076b67a9d174e  vmovaps [rsp+0x90], xmm9
000076b67a9d1757  vmovaps [rsp+0xA0], xmm10
000076b67a9d1760  vmovaps [rsp+0xB0], xmm11
000076b67a9d1769  vmovaps [rsp+0xC0], xmm12
000076b67a9d1772  vmovaps [rsp+0xD0], xmm13
000076b67a9d177b  vmovaps [rsp+0xE0], xmm14
000076b67a9d1784  sub rsp, 0x30
000076b67a9d1788  movaps [rsp], xmm15
000076b67a9d178d  movaps [rsp+0x10], xmm2
000076b67a9d1792  movaps [rsp+0x20], xmm1
000076b67a9d1797  lea rdi, [rsp]
000076b67a9d179b  mov esi, 0x00
000076b67a9d17a0  mov rax, 0x63C5EF2DF530
000076b67a9d17aa  call rax
000076b67a9d17ac  movaps xmm15, [rsp]
000076b67a9d17b1  add rsp, 0x30
000076b67a9d17b5  vmovaps xmm0, [rsp]
000076b67a9d17ba  vmovaps xmm1, [rsp+0x10]
000076b67a9d17c0  vmovaps xmm2, [rsp+0x20]
000076b67a9d17c6  vmovaps xmm3, [rsp+0x30]
000076b67a9d17cc  vmovaps xmm4, [rsp+0x40]
000076b67a9d17d2  vmovaps xmm5, [rsp+0x50]
000076b67a9d17d8  vmovaps xmm6, [rsp+0x60]
000076b67a9d17de  vmovaps xmm7, [rsp+0x70]
000076b67a9d17e4  vmovaps xmm8, [rsp+0x80]
000076b67a9d17ed  vmovaps xmm9, [rsp+0x90]
000076b67a9d17f6  vmovaps xmm10, [rsp+0xA0]
000076b67a9d17ff  vmovaps xmm11, [rsp+0xB0]
000076b67a9d1808  vmovaps xmm12, [rsp+0xC0]
000076b67a9d1811  vmovaps xmm13, [rsp+0xD0]
000076b67a9d181a  vmovaps xmm14, [rsp+0xE0]
000076b67a9d1823  add rsp, 0xF0
000076b67a9d182a  pop r11
000076b67a9d182c  pop r10
000076b67a9d182e  pop r9
000076b67a9d1830  pop r8
000076b67a9d1832  pop rsi
000076b67a9d1833  pop rdi
000076b67a9d1834  pop rdx
000076b67a9d1835  pop rcx
000076b67a9d1836  pop rax
000076b67a9d1837  add rsp, 0x08
000076b67a9d183b  jmp 0x000076B67A9CF923
000076b67a9d1840  call 0x000076B67A7FF430
000076b67a9d1845  jmp 0x000076B67A9CF930
000076b67a9d184a  sub rsp, 0x08
000076b67a9d184e  push rax
000076b67a9d184f  push rcx
000076b67a9d1850  push rdx
000076b67a9d1851  push rdi
000076b67a9d1852  push rsi
000076b67a9d1853  push r8
000076b67a9d1855  push r9
000076b67a9d1857  push r10
000076b67a9d1859  push r11
000076b67a9d185b  sub rsp, 0xF0
000076b67a9d1862  vmovaps [rsp], xmm0
000076b67a9d1867  vmovaps [rsp+0x10], xmm1
000076b67a9d186d  vmovaps [rsp+0x20], xmm3
000076b67a9d1873  vmovaps [rsp+0x30], xmm4
000076b67a9d1879  vmovaps [rsp+0x40], xmm5
000076b67a9d187f  vmovaps [rsp+0x50], xmm6
000076b67a9d1885  vmovaps [rsp+0x60], xmm7
000076b67a9d188b  vmovaps [rsp+0x70], xmm8
000076b67a9d1891  vmovaps [rsp+0x80], xmm9
000076b67a9d189a  vmovaps [rsp+0x90], xmm10
000076b67a9d18a3  vmovaps [rsp+0xA0], xmm11
000076b67a9d18ac  vmovaps [rsp+0xB0], xmm12
000076b67a9d18b5  vmovaps [rsp+0xC0], xmm13
000076b67a9d18be  vmovaps [rsp+0xD0], xmm14
000076b67a9d18c7  vmovaps [rsp+0xE0], xmm15
000076b67a9d18d0  sub rsp, 0x30
000076b67a9d18d4  movaps [rsp], xmm2
000076b67a9d18d8  movaps [rsp+0x10], xmm1
000076b67a9d18dd  movaps [rsp+0x20], xmm14
000076b67a9d18e3  lea rdi, [rsp]
000076b67a9d18e7  mov esi, 0x00
000076b67a9d18ec  mov rax, 0x63C5EF2DF530
000076b67a9d18f6  call rax
000076b67a9d18f8  movaps xmm2, [rsp]
000076b67a9d18fc  add rsp, 0x30
000076b67a9d1900  vmovaps xmm0, [rsp]
000076b67a9d1905  vmovaps xmm1, [rsp+0x10]
000076b67a9d190b  vmovaps xmm3, [rsp+0x20]
000076b67a9d1911  vmovaps xmm4, [rsp+0x30]
000076b67a9d1917  vmovaps xmm5, [rsp+0x40]
000076b67a9d191d  vmovaps xmm6, [rsp+0x50]
000076b67a9d1923  vmovaps xmm7, [rsp+0x60]
000076b67a9d1929  vmovaps xmm8, [rsp+0x70]
000076b67a9d192f  vmovaps xmm9, [rsp+0x80]
000076b67a9d1938  vmovaps xmm10, [rsp+0x90]
000076b67a9d1941  vmovaps xmm11, [rsp+0xA0]
000076b67a9d194a  vmovaps xmm12, [rsp+0xB0]
000076b67a9d1953  vmovaps xmm13, [rsp+0xC0]
000076b67a9d195c  vmovaps xmm14, [rsp+0xD0]
000076b67a9d1965  vmovaps xmm15, [rsp+0xE0]
000076b67a9d196e  add rsp, 0xF0
000076b67a9d1975  pop r11
000076b67a9d1977  pop r10
000076b67a9d1979  pop r9
000076b67a9d197b  pop r8
000076b67a9d197d  pop rsi
000076b67a9d197e  pop rdi
000076b67a9d197f  pop rdx
000076b67a9d1980  pop rcx
000076b67a9d1981  pop rax
000076b67a9d1982  add rsp, 0x08
000076b67a9d1986  jmp 0x000076B67A9CF96D
000076b67a9d198b  sub rsp, 0x08
000076b67a9d198f  push rax
000076b67a9d1990  push rcx
000076b67a9d1991  push rdx
000076b67a9d1992  push rdi
000076b67a9d1993  push rsi
000076b67a9d1994  push r8
000076b67a9d1996  push r9
000076b67a9d1998  push r10
000076b67a9d199a  push r11
000076b67a9d199c  sub rsp, 0xF0
000076b67a9d19a3  vmovaps [rsp], xmm0
000076b67a9d19a8  vmovaps [rsp+0x10], xmm1
000076b67a9d19ae  vmovaps [rsp+0x20], xmm2
000076b67a9d19b4  vmovaps [rsp+0x30], xmm3
000076b67a9d19ba  vmovaps [rsp+0x40], xmm4
000076b67a9d19c0  vmovaps [rsp+0x50], xmm5
000076b67a9d19c6  vmovaps [rsp+0x60], xmm6
000076b67a9d19cc  vmovaps [rsp+0x70], xmm7
000076b67a9d19d2  vmovaps [rsp+0x80], xmm8
000076b67a9d19db  vmovaps [rsp+0x90], xmm9
000076b67a9d19e4  vmovaps [rsp+0xA0], xmm10
000076b67a9d19ed  vmovaps [rsp+0xB0], xmm11
000076b67a9d19f6  vmovaps [rsp+0xC0], xmm12
000076b67a9d19ff  vmovaps [rsp+0xD0], xmm13
000076b67a9d1a08  vmovaps [rsp+0xE0], xmm14
000076b67a9d1a11  sub rsp, 0x30
000076b67a9d1a15  movaps [rsp], xmm15
000076b67a9d1a1a  movaps [rsp+0x10], xmm14
000076b67a9d1a20  movaps [rsp+0x20], xmm1
000076b67a9d1a25  lea rdi, [rsp]
000076b67a9d1a29  mov esi, 0x00
000076b67a9d1a2e  mov rax, 0x63C5EF2DF530
000076b67a9d1a38  call rax
000076b67a9d1a3a  movaps xmm15, [rsp]
000076b67a9d1a3f  add rsp, 0x30
000076b67a9d1a43  vmovaps xmm0, [rsp]
000076b67a9d1a48  vmovaps xmm1, [rsp+0x10]
000076b67a9d1a4e  vmovaps xmm2, [rsp+0x20]
000076b67a9d1a54  vmovaps xmm3, [rsp+0x30]
000076b67a9d1a5a  vmovaps xmm4, [rsp+0x40]
000076b67a9d1a60  vmovaps xmm5, [rsp+0x50]
000076b67a9d1a66  vmovaps xmm6, [rsp+0x60]
000076b67a9d1a6c  vmovaps xmm7, [rsp+0x70]
000076b67a9d1a72  vmovaps xmm8, [rsp+0x80]
000076b67a9d1a7b  vmovaps xmm9, [rsp+0x90]
000076b67a9d1a84  vmovaps xmm10, [rsp+0xA0]
000076b67a9d1a8d  vmovaps xmm11, [rsp+0xB0]
000076b67a9d1a96  vmovaps xmm12, [rsp+0xC0]
000076b67a9d1a9f  vmovaps xmm13, [rsp+0xD0]
000076b67a9d1aa8  vmovaps xmm14, [rsp+0xE0]
000076b67a9d1ab1  add rsp, 0xF0
000076b67a9d1ab8  pop r11
000076b67a9d1aba  pop r10
000076b67a9d1abc  pop r9
000076b67a9d1abe  pop r8
000076b67a9d1ac0  pop rsi
000076b67a9d1ac1  pop rdi
000076b67a9d1ac2  pop rdx
000076b67a9d1ac3  pop rcx
000076b67a9d1ac4  pop rax
000076b67a9d1ac5  add rsp, 0x08
000076b67a9d1ac9  jmp 0x000076B67A9CF9E7
000076b67a9d1ace  call 0x000076B67A7FF430
000076b67a9d1ad3  jmp 0x000076B67A9CF9F4
000076b67a9d1ad8  sub rsp, 0x08
000076b67a9d1adc  push rax
000076b67a9d1add  push rcx
000076b67a9d1ade  push rdx
000076b67a9d1adf  push rdi
000076b67a9d1ae0  push rsi
000076b67a9d1ae1  push r8
000076b67a9d1ae3  push r9
000076b67a9d1ae5  push r10
000076b67a9d1ae7  push r11
000076b67a9d1ae9  sub rsp, 0xF0
000076b67a9d1af0  vmovaps [rsp], xmm0
000076b67a9d1af5  vmovaps [rsp+0x10], xmm1
000076b67a9d1afb  vmovaps [rsp+0x20], xmm2
000076b67a9d1b01  vmovaps [rsp+0x30], xmm3
000076b67a9d1b07  vmovaps [rsp+0x40], xmm4
000076b67a9d1b0d  vmovaps [rsp+0x50], xmm5
000076b67a9d1b13  vmovaps [rsp+0x60], xmm6
000076b67a9d1b19  vmovaps [rsp+0x70], xmm7
000076b67a9d1b1f  vmovaps [rsp+0x80], xmm8
000076b67a9d1b28  vmovaps [rsp+0x90], xmm9
000076b67a9d1b31  vmovaps [rsp+0xA0], xmm10
000076b67a9d1b3a  vmovaps [rsp+0xB0], xmm11
000076b67a9d1b43  vmovaps [rsp+0xC0], xmm12
000076b67a9d1b4c  vmovaps [rsp+0xD0], xmm13
000076b67a9d1b55  vmovaps [rsp+0xE0], xmm15
000076b67a9d1b5e  sub rsp, 0x30
000076b67a9d1b62  movaps [rsp], xmm14
000076b67a9d1b67  movaps [rsp+0x10], xmm13
000076b67a9d1b6d  movaps [rsp+0x20], xmm1
000076b67a9d1b72  lea rdi, [rsp]
000076b67a9d1b76  mov esi, 0x00
000076b67a9d1b7b  mov rax, 0x63C5EF2DF530
000076b67a9d1b85  call rax
000076b67a9d1b87  movaps xmm14, [rsp]
000076b67a9d1b8c  add rsp, 0x30
000076b67a9d1b90  vmovaps xmm0, [rsp]
000076b67a9d1b95  vmovaps xmm1, [rsp+0x10]
000076b67a9d1b9b  vmovaps xmm2, [rsp+0x20]
000076b67a9d1ba1  vmovaps xmm3, [rsp+0x30]
000076b67a9d1ba7  vmovaps xmm4, [rsp+0x40]
000076b67a9d1bad  vmovaps xmm5, [rsp+0x50]
000076b67a9d1bb3  vmovaps xmm6, [rsp+0x60]
000076b67a9d1bb9  vmovaps xmm7, [rsp+0x70]
000076b67a9d1bbf  vmovaps xmm8, [rsp+0x80]
000076b67a9d1bc8  vmovaps xmm9, [rsp+0x90]
000076b67a9d1bd1  vmovaps xmm10, [rsp+0xA0]
000076b67a9d1bda  vmovaps xmm11, [rsp+0xB0]
000076b67a9d1be3  vmovaps xmm12, [rsp+0xC0]
000076b67a9d1bec  vmovaps xmm13, [rsp+0xD0]
000076b67a9d1bf5  vmovaps xmm15, [rsp+0xE0]
000076b67a9d1bfe  add rsp, 0xF0
000076b67a9d1c05  pop r11
000076b67a9d1c07  pop r10
000076b67a9d1c09  pop r9
000076b67a9d1c0b  pop r8
000076b67a9d1c0d  pop rsi
000076b67a9d1c0e  pop rdi
000076b67a9d1c0f  pop rdx
000076b67a9d1c10  pop rcx
000076b67a9d1c11  pop rax
000076b67a9d1c12  add rsp, 0x08
000076b67a9d1c16  jmp 0x000076B67A9CFAAF
000076b67a9d1c1b  sub rsp, 0x08
000076b67a9d1c1f  push rax
000076b67a9d1c20  push rcx
000076b67a9d1c21  push rdx
000076b67a9d1c22  push rdi
000076b67a9d1c23  push rsi
000076b67a9d1c24  push r8
000076b67a9d1c26  push r9
000076b67a9d1c28  push r10
000076b67a9d1c2a  push r11
000076b67a9d1c2c  sub rsp, 0xF0
000076b67a9d1c33  vmovaps [rsp], xmm0
000076b67a9d1c38  vmovaps [rsp+0x10], xmm1
000076b67a9d1c3e  vmovaps [rsp+0x20], xmm2
000076b67a9d1c44  vmovaps [rsp+0x30], xmm3
000076b67a9d1c4a  vmovaps [rsp+0x40], xmm4
000076b67a9d1c50  vmovaps [rsp+0x50], xmm5
000076b67a9d1c56  vmovaps [rsp+0x60], xmm6
000076b67a9d1c5c  vmovaps [rsp+0x70], xmm7
000076b67a9d1c62  vmovaps [rsp+0x80], xmm8
000076b67a9d1c6b  vmovaps [rsp+0x90], xmm9
000076b67a9d1c74  vmovaps [rsp+0xA0], xmm10
000076b67a9d1c7d  vmovaps [rsp+0xB0], xmm11
000076b67a9d1c86  vmovaps [rsp+0xC0], xmm12
000076b67a9d1c8f  vmovaps [rsp+0xD0], xmm13
000076b67a9d1c98  vmovaps [rsp+0xE0], xmm14
000076b67a9d1ca1  sub rsp, 0x30
000076b67a9d1ca5  movaps [rsp], xmm15
000076b67a9d1caa  movaps [rsp+0x10], xmm13
000076b67a9d1cb0  movaps [rsp+0x20], xmm1
000076b67a9d1cb5  lea rdi, [rsp]
000076b67a9d1cb9  mov esi, 0x00
000076b67a9d1cbe  mov rax, 0x63C5EF2DF530
000076b67a9d1cc8  call rax
000076b67a9d1cca  movaps xmm15, [rsp]
000076b67a9d1ccf  add rsp, 0x30
000076b67a9d1cd3  vmovaps xmm0, [rsp]
000076b67a9d1cd8  vmovaps xmm1, [rsp+0x10]
000076b67a9d1cde  vmovaps xmm2, [rsp+0x20]
000076b67a9d1ce4  vmovaps xmm3, [rsp+0x30]
000076b67a9d1cea  vmovaps xmm4, [rsp+0x40]
000076b67a9d1cf0  vmovaps xmm5, [rsp+0x50]
000076b67a9d1cf6  vmovaps xmm6, [rsp+0x60]
000076b67a9d1cfc  vmovaps xmm7, [rsp+0x70]
000076b67a9d1d02  vmovaps xmm8, [rsp+0x80]
000076b67a9d1d0b  vmovaps xmm9, [rsp+0x90]
000076b67a9d1d14  vmovaps xmm10, [rsp+0xA0]
000076b67a9d1d1d  vmovaps xmm11, [rsp+0xB0]
000076b67a9d1d26  vmovaps xmm12, [rsp+0xC0]
000076b67a9d1d2f  vmovaps xmm13, [rsp+0xD0]
000076b67a9d1d38  vmovaps xmm14, [rsp+0xE0]
000076b67a9d1d41  add rsp, 0xF0
000076b67a9d1d48  pop r11
000076b67a9d1d4a  pop r10
000076b67a9d1d4c  pop r9
000076b67a9d1d4e  pop r8
000076b67a9d1d50  pop rsi
000076b67a9d1d51  pop rdi
000076b67a9d1d52  pop rdx
000076b67a9d1d53  pop rcx
000076b67a9d1d54  pop rax
000076b67a9d1d55  add rsp, 0x08
000076b67a9d1d59  jmp 0x000076B67A9CFAEB
000076b67a9d1d5e  call 0x000076B67A7FF430
000076b67a9d1d63  jmp 0x000076B67A9CFAF8
000076b67a9d1d68  sub rsp, 0x08
000076b67a9d1d6c  push rax
000076b67a9d1d6d  push rcx
000076b67a9d1d6e  push rdx
000076b67a9d1d6f  push rdi
000076b67a9d1d70  push rsi
000076b67a9d1d71  push r8
000076b67a9d1d73  push r9
000076b67a9d1d75  push r10
000076b67a9d1d77  push r11
000076b67a9d1d79  sub rsp, 0xF0
000076b67a9d1d80  vmovaps [rsp], xmm0
000076b67a9d1d85  vmovaps [rsp+0x10], xmm1
000076b67a9d1d8b  vmovaps [rsp+0x20], xmm2
000076b67a9d1d91  vmovaps [rsp+0x30], xmm3
000076b67a9d1d97  vmovaps [rsp+0x40], xmm4
000076b67a9d1d9d  vmovaps [rsp+0x50], xmm5
000076b67a9d1da3  vmovaps [rsp+0x60], xmm6
000076b67a9d1da9  vmovaps [rsp+0x70], xmm7
000076b67a9d1daf  vmovaps [rsp+0x80], xmm8
000076b67a9d1db8  vmovaps [rsp+0x90], xmm9
000076b67a9d1dc1  vmovaps [rsp+0xA0], xmm10
000076b67a9d1dca  vmovaps [rsp+0xB0], xmm11
000076b67a9d1dd3  vmovaps [rsp+0xC0], xmm12
000076b67a9d1ddc  vmovaps [rsp+0xD0], xmm13
000076b67a9d1de5  vmovaps [rsp+0xE0], xmm15
000076b67a9d1dee  sub rsp, 0x30
000076b67a9d1df2  movaps [rsp], xmm14
000076b67a9d1df7  movaps [rsp+0x10], xmm13
000076b67a9d1dfd  movaps [rsp+0x20], xmm2
000076b67a9d1e02  lea rdi, [rsp]
000076b67a9d1e06  mov esi, 0x00
000076b67a9d1e0b  mov rax, 0x63C5EF2DF530
000076b67a9d1e15  call rax
000076b67a9d1e17  movaps xmm14, [rsp]
000076b67a9d1e1c  add rsp, 0x30
000076b67a9d1e20  vmovaps xmm0, [rsp]
000076b67a9d1e25  vmovaps xmm1, [rsp+0x10]
000076b67a9d1e2b  vmovaps xmm2, [rsp+0x20]
000076b67a9d1e31  vmovaps xmm3, [rsp+0x30]
000076b67a9d1e37  vmovaps xmm4, [rsp+0x40]
000076b67a9d1e3d  vmovaps xmm5, [rsp+0x50]
000076b67a9d1e43  vmovaps xmm6, [rsp+0x60]
000076b67a9d1e49  vmovaps xmm7, [rsp+0x70]
000076b67a9d1e4f  vmovaps xmm8, [rsp+0x80]
000076b67a9d1e58  vmovaps xmm9, [rsp+0x90]
000076b67a9d1e61  vmovaps xmm10, [rsp+0xA0]
000076b67a9d1e6a  vmovaps xmm11, [rsp+0xB0]
000076b67a9d1e73  vmovaps xmm12, [rsp+0xC0]
000076b67a9d1e7c  vmovaps xmm13, [rsp+0xD0]
000076b67a9d1e85  vmovaps xmm15, [rsp+0xE0]
000076b67a9d1e8e  add rsp, 0xF0
000076b67a9d1e95  pop r11
000076b67a9d1e97  pop r10
000076b67a9d1e99  pop r9
000076b67a9d1e9b  pop r8
000076b67a9d1e9d  pop rsi
000076b67a9d1e9e  pop rdi
000076b67a9d1e9f  pop rdx
000076b67a9d1ea0  pop rcx
000076b67a9d1ea1  pop rax
000076b67a9d1ea2  add rsp, 0x08
000076b67a9d1ea6  jmp 0x000076B67A9CFB24
000076b67a9d1eab  sub rsp, 0x08
000076b67a9d1eaf  push rax
000076b67a9d1eb0  push rcx
000076b67a9d1eb1  push rdx
000076b67a9d1eb2  push rdi
000076b67a9d1eb3  push rsi
000076b67a9d1eb4  push r8
000076b67a9d1eb6  push r9
000076b67a9d1eb8  push r10
000076b67a9d1eba  push r11
000076b67a9d1ebc  sub rsp, 0xF0
000076b67a9d1ec3  vmovaps [rsp], xmm0
000076b67a9d1ec8  vmovaps [rsp+0x10], xmm2
000076b67a9d1ece  vmovaps [rsp+0x20], xmm3
000076b67a9d1ed4  vmovaps [rsp+0x30], xmm4
000076b67a9d1eda  vmovaps [rsp+0x40], xmm5
000076b67a9d1ee0  vmovaps [rsp+0x50], xmm6
000076b67a9d1ee6  vmovaps [rsp+0x60], xmm7
000076b67a9d1eec  vmovaps [rsp+0x70], xmm8
000076b67a9d1ef2  vmovaps [rsp+0x80], xmm9
000076b67a9d1efb  vmovaps [rsp+0x90], xmm10
000076b67a9d1f04  vmovaps [rsp+0xA0], xmm11
000076b67a9d1f0d  vmovaps [rsp+0xB0], xmm12
000076b67a9d1f16  vmovaps [rsp+0xC0], xmm13
000076b67a9d1f1f  vmovaps [rsp+0xD0], xmm14
000076b67a9d1f28  vmovaps [rsp+0xE0], xmm15
000076b67a9d1f31  sub rsp, 0x30
000076b67a9d1f35  movaps [rsp], xmm1
000076b67a9d1f39  movaps [rsp+0x10], xmm13
000076b67a9d1f3f  movaps [rsp+0x20], xmm2
000076b67a9d1f44  lea rdi, [rsp]
000076b67a9d1f48  mov esi, 0x00
000076b67a9d1f4d  mov rax, 0x63C5EF2DF530
000076b67a9d1f57  call rax
000076b67a9d1f59  movaps xmm1, [rsp]
000076b67a9d1f5d  add rsp, 0x30
000076b67a9d1f61  vmovaps xmm0, [rsp]
000076b67a9d1f66  vmovaps xmm2, [rsp+0x10]
000076b67a9d1f6c  vmovaps xmm3, [rsp+0x20]
000076b67a9d1f72  vmovaps xmm4, [rsp+0x30]
000076b67a9d1f78  vmovaps xmm5, [rsp+0x40]
000076b67a9d1f7e  vmovaps xmm6, [rsp+0x50]
000076b67a9d1f84  vmovaps xmm7, [rsp+0x60]
000076b67a9d1f8a  vmovaps xmm8, [rsp+0x70]
000076b67a9d1f90  vmovaps xmm9, [rsp+0x80]
000076b67a9d1f99  vmovaps xmm10, [rsp+0x90]
000076b67a9d1fa2  vmovaps xmm11, [rsp+0xA0]
000076b67a9d1fab  vmovaps xmm12, [rsp+0xB0]
000076b67a9d1fb4  vmovaps xmm13, [rsp+0xC0]
000076b67a9d1fbd  vmovaps xmm14, [rsp+0xD0]
000076b67a9d1fc6  vmovaps xmm15, [rsp+0xE0]
000076b67a9d1fcf  add rsp, 0xF0
000076b67a9d1fd6  pop r11
000076b67a9d1fd8  pop r10
000076b67a9d1fda  pop r9
000076b67a9d1fdc  pop r8
000076b67a9d1fde  pop rsi
000076b67a9d1fdf  pop rdi
000076b67a9d1fe0  pop rdx
000076b67a9d1fe1  pop rcx
000076b67a9d1fe2  pop rax
000076b67a9d1fe3  add rsp, 0x08
000076b67a9d1fe7  jmp 0x000076B67A9CFB52
000076b67a9d1fec  sub rsp, 0x08
000076b67a9d1ff0  push rax
000076b67a9d1ff1  push rcx
000076b67a9d1ff2  push rdx
000076b67a9d1ff3  push rdi
000076b67a9d1ff4  push rsi
000076b67a9d1ff5  push r8
000076b67a9d1ff7  push r9
000076b67a9d1ff9  push r10
000076b67a9d1ffb  push r11
000076b67a9d1ffd  sub rsp, 0xF0
000076b67a9d2004  vmovaps [rsp], xmm0
000076b67a9d2009  vmovaps [rsp+0x10], xmm1
000076b67a9d200f  vmovaps [rsp+0x20], xmm3
000076b67a9d2015  vmovaps [rsp+0x30], xmm4
000076b67a9d201b  vmovaps [rsp+0x40], xmm5
000076b67a9d2021  vmovaps [rsp+0x50], xmm6
000076b67a9d2027  vmovaps [rsp+0x60], xmm7
000076b67a9d202d  vmovaps [rsp+0x70], xmm8
000076b67a9d2033  vmovaps [rsp+0x80], xmm9
000076b67a9d203c  vmovaps [rsp+0x90], xmm10
000076b67a9d2045  vmovaps [rsp+0xA0], xmm11
000076b67a9d204e  vmovaps [rsp+0xB0], xmm12
000076b67a9d2057  vmovaps [rsp+0xC0], xmm13
000076b67a9d2060  vmovaps [rsp+0xD0], xmm14
000076b67a9d2069  vmovaps [rsp+0xE0], xmm15
000076b67a9d2072  sub rsp, 0x30
000076b67a9d2076  movaps [rsp], xmm2
000076b67a9d207a  movaps [rsp+0x10], xmm1
000076b67a9d207f  movaps [rsp+0x20], xmm13
000076b67a9d2085  lea rdi, [rsp]
000076b67a9d2089  mov esi, 0x00
000076b67a9d208e  mov rax, 0x63C5EF2DF530
000076b67a9d2098  call rax
000076b67a9d209a  movaps xmm2, [rsp]
000076b67a9d209e  add rsp, 0x30
000076b67a9d20a2  vmovaps xmm0, [rsp]
000076b67a9d20a7  vmovaps xmm1, [rsp+0x10]
000076b67a9d20ad  vmovaps xmm3, [rsp+0x20]
000076b67a9d20b3  vmovaps xmm4, [rsp+0x30]
000076b67a9d20b9  vmovaps xmm5, [rsp+0x40]
000076b67a9d20bf  vmovaps xmm6, [rsp+0x50]
000076b67a9d20c5  vmovaps xmm7, [rsp+0x60]
000076b67a9d20cb  vmovaps xmm8, [rsp+0x70]
000076b67a9d20d1  vmovaps xmm9, [rsp+0x80]
000076b67a9d20da  vmovaps xmm10, [rsp+0x90]
000076b67a9d20e3  vmovaps xmm11, [rsp+0xA0]
000076b67a9d20ec  vmovaps xmm12, [rsp+0xB0]
000076b67a9d20f5  vmovaps xmm13, [rsp+0xC0]
000076b67a9d20fe  vmovaps xmm14, [rsp+0xD0]
000076b67a9d2107  vmovaps xmm15, [rsp+0xE0]
000076b67a9d2110  add rsp, 0xF0
000076b67a9d2117  pop r11
000076b67a9d2119  pop r10
000076b67a9d211b  pop r9
000076b67a9d211d  pop r8
000076b67a9d211f  pop rsi
000076b67a9d2120  pop rdi
000076b67a9d2121  pop rdx
000076b67a9d2122  pop rcx
000076b67a9d2123  pop rax
000076b67a9d2124  add rsp, 0x08
000076b67a9d2128  jmp 0x000076B67A9CFBAB
000076b67a9d212d  call 0x000076B67A7FF430
000076b67a9d2132  jmp 0x000076B67A9CFBB8
000076b67a9d2137  sub rsp, 0x08
000076b67a9d213b  push rax
000076b67a9d213c  push rcx
000076b67a9d213d  push rdx
000076b67a9d213e  push rdi
000076b67a9d213f  push rsi
000076b67a9d2140  push r8
000076b67a9d2142  push r9
000076b67a9d2144  push r10
000076b67a9d2146  push r11
000076b67a9d2148  sub rsp, 0xF0
000076b67a9d214f  vmovaps [rsp], xmm0
000076b67a9d2154  vmovaps [rsp+0x10], xmm1
000076b67a9d215a  vmovaps [rsp+0x20], xmm2
000076b67a9d2160  vmovaps [rsp+0x30], xmm3
000076b67a9d2166  vmovaps [rsp+0x40], xmm4
000076b67a9d216c  vmovaps [rsp+0x50], xmm5
000076b67a9d2172  vmovaps [rsp+0x60], xmm6
000076b67a9d2178  vmovaps [rsp+0x70], xmm7
000076b67a9d217e  vmovaps [rsp+0x80], xmm8
000076b67a9d2187  vmovaps [rsp+0x90], xmm9
000076b67a9d2190  vmovaps [rsp+0xA0], xmm10
000076b67a9d2199  vmovaps [rsp+0xB0], xmm11
000076b67a9d21a2  vmovaps [rsp+0xC0], xmm12
000076b67a9d21ab  vmovaps [rsp+0xD0], xmm13
000076b67a9d21b4  vmovaps [rsp+0xE0], xmm14
000076b67a9d21bd  sub rsp, 0x30
000076b67a9d21c1  movaps [rsp], xmm15
000076b67a9d21c6  movaps [rsp+0x10], xmm13
000076b67a9d21cc  movaps [rsp+0x20], xmm1
000076b67a9d21d1  lea rdi, [rsp]
000076b67a9d21d5  mov esi, 0x00
000076b67a9d21da  mov rax, 0x63C5EF2DF530
000076b67a9d21e4  call rax
000076b67a9d21e6  movaps xmm15, [rsp]
000076b67a9d21eb  add rsp, 0x30
000076b67a9d21ef  vmovaps xmm0, [rsp]
000076b67a9d21f4  vmovaps xmm1, [rsp+0x10]
000076b67a9d21fa  vmovaps xmm2, [rsp+0x20]
000076b67a9d2200  vmovaps xmm3, [rsp+0x30]
000076b67a9d2206  vmovaps xmm4, [rsp+0x40]
000076b67a9d220c  vmovaps xmm5, [rsp+0x50]
000076b67a9d2212  vmovaps xmm6, [rsp+0x60]
000076b67a9d2218  vmovaps xmm7, [rsp+0x70]
000076b67a9d221e  vmovaps xmm8, [rsp+0x80]
000076b67a9d2227  vmovaps xmm9, [rsp+0x90]
000076b67a9d2230  vmovaps xmm10, [rsp+0xA0]
000076b67a9d2239  vmovaps xmm11, [rsp+0xB0]
000076b67a9d2242  vmovaps xmm12, [rsp+0xC0]
000076b67a9d224b  vmovaps xmm13, [rsp+0xD0]
000076b67a9d2254  vmovaps xmm14, [rsp+0xE0]
000076b67a9d225d  add rsp, 0xF0
000076b67a9d2264  pop r11
000076b67a9d2266  pop r10
000076b67a9d2268  pop r9
000076b67a9d226a  pop r8
000076b67a9d226c  pop rsi
000076b67a9d226d  pop rdi
000076b67a9d226e  pop rdx
000076b67a9d226f  pop rcx
000076b67a9d2270  pop rax
000076b67a9d2271  add rsp, 0x08
000076b67a9d2275  jmp 0x000076B67A9CFBF7
000076b67a9d227a  sub rsp, 0x08
000076b67a9d227e  push rax
000076b67a9d227f  push rcx
000076b67a9d2280  push rdx
000076b67a9d2281  push rdi
000076b67a9d2282  push rsi
000076b67a9d2283  push r8
000076b67a9d2285  push r9
000076b67a9d2287  push r10
000076b67a9d2289  push r11
000076b67a9d228b  sub rsp, 0xF0
000076b67a9d2292  vmovaps [rsp], xmm0
000076b67a9d2297  vmovaps [rsp+0x10], xmm1
000076b67a9d229d  vmovaps [rsp+0x20], xmm2
000076b67a9d22a3  vmovaps [rsp+0x30], xmm3
000076b67a9d22a9  vmovaps [rsp+0x40], xmm4
000076b67a9d22af  vmovaps [rsp+0x50], xmm5
000076b67a9d22b5  vmovaps [rsp+0x60], xmm6
000076b67a9d22bb  vmovaps [rsp+0x70], xmm7
000076b67a9d22c1  vmovaps [rsp+0x80], xmm8
000076b67a9d22ca  vmovaps [rsp+0x90], xmm9
000076b67a9d22d3  vmovaps [rsp+0xA0], xmm10
000076b67a9d22dc  vmovaps [rsp+0xB0], xmm11
000076b67a9d22e5  vmovaps [rsp+0xC0], xmm12
000076b67a9d22ee  vmovaps [rsp+0xD0], xmm13
000076b67a9d22f7  vmovaps [rsp+0xE0], xmm15
000076b67a9d2300  sub rsp, 0x30
000076b67a9d2304  movaps [rsp], xmm14
000076b67a9d2309  movaps [rsp+0x10], xmm11
000076b67a9d230f  movaps [rsp+0x20], xmm1
000076b67a9d2314  lea rdi, [rsp]
000076b67a9d2318  mov esi, 0x00
000076b67a9d231d  mov rax, 0x63C5EF2DF530
000076b67a9d2327  call rax
000076b67a9d2329  movaps xmm14, [rsp]
000076b67a9d232e  add rsp, 0x30
000076b67a9d2332  vmovaps xmm0, [rsp]
000076b67a9d2337  vmovaps xmm1, [rsp+0x10]
000076b67a9d233d  vmovaps xmm2, [rsp+0x20]
000076b67a9d2343  vmovaps xmm3, [rsp+0x30]
000076b67a9d2349  vmovaps xmm4, [rsp+0x40]
000076b67a9d234f  vmovaps xmm5, [rsp+0x50]
000076b67a9d2355  vmovaps xmm6, [rsp+0x60]
000076b67a9d235b  vmovaps xmm7, [rsp+0x70]
000076b67a9d2361  vmovaps xmm8, [rsp+0x80]
000076b67a9d236a  vmovaps xmm9, [rsp+0x90]
000076b67a9d2373  vmovaps xmm10, [rsp+0xA0]
000076b67a9d237c  vmovaps xmm11, [rsp+0xB0]
000076b67a9d2385  vmovaps xmm12, [rsp+0xC0]
000076b67a9d238e  vmovaps xmm13, [rsp+0xD0]
000076b67a9d2397  vmovaps xmm15, [rsp+0xE0]
000076b67a9d23a0  add rsp, 0xF0
000076b67a9d23a7  pop r11
000076b67a9d23a9  pop r10
000076b67a9d23ab  pop r9
000076b67a9d23ad  pop r8
000076b67a9d23af  pop rsi
000076b67a9d23b0  pop rdi
000076b67a9d23b1  pop rdx
000076b67a9d23b2  pop rcx
000076b67a9d23b3  pop rax
000076b67a9d23b4  add rsp, 0x08
000076b67a9d23b8  jmp 0x000076B67A9CFC21
000076b67a9d23bd  sub rsp, 0x08
000076b67a9d23c1  push rax
000076b67a9d23c2  push rcx
000076b67a9d23c3  push rdx
000076b67a9d23c4  push rdi
000076b67a9d23c5  push rsi
000076b67a9d23c6  push r8
000076b67a9d23c8  push r9
000076b67a9d23ca  push r10
000076b67a9d23cc  push r11
000076b67a9d23ce  sub rsp, 0xF0
000076b67a9d23d5  vmovaps [rsp], xmm0
000076b67a9d23da  vmovaps [rsp+0x10], xmm1
000076b67a9d23e0  vmovaps [rsp+0x20], xmm2
000076b67a9d23e6  vmovaps [rsp+0x30], xmm3
000076b67a9d23ec  vmovaps [rsp+0x40], xmm4
000076b67a9d23f2  vmovaps [rsp+0x50], xmm5
000076b67a9d23f8  vmovaps [rsp+0x60], xmm6
000076b67a9d23fe  vmovaps [rsp+0x70], xmm7
000076b67a9d2404  vmovaps [rsp+0x80], xmm8
000076b67a9d240d  vmovaps [rsp+0x90], xmm9
000076b67a9d2416  vmovaps [rsp+0xA0], xmm10
000076b67a9d241f  vmovaps [rsp+0xB0], xmm11
000076b67a9d2428  vmovaps [rsp+0xC0], xmm12
000076b67a9d2431  vmovaps [rsp+0xD0], xmm14
000076b67a9d243a  vmovaps [rsp+0xE0], xmm15
000076b67a9d2443  sub rsp, 0x30
000076b67a9d2447  movaps [rsp], xmm13
000076b67a9d244c  movaps [rsp+0x10], xmm11
000076b67a9d2452  movaps [rsp+0x20], xmm1
000076b67a9d2457  lea rdi, [rsp]
000076b67a9d245b  mov esi, 0x00
000076b67a9d2460  mov rax, 0x63C5EF2DF530
000076b67a9d246a  call rax
000076b67a9d246c  movaps xmm13, [rsp]
000076b67a9d2471  add rsp, 0x30
000076b67a9d2475  vmovaps xmm0, [rsp]
000076b67a9d247a  vmovaps xmm1, [rsp+0x10]
000076b67a9d2480  vmovaps xmm2, [rsp+0x20]
000076b67a9d2486  vmovaps xmm3, [rsp+0x30]
000076b67a9d248c  vmovaps xmm4, [rsp+0x40]
000076b67a9d2492  vmovaps xmm5, [rsp+0x50]
000076b67a9d2498  vmovaps xmm6, [rsp+0x60]
000076b67a9d249e  vmovaps xmm7, [rsp+0x70]
000076b67a9d24a4  vmovaps xmm8, [rsp+0x80]
000076b67a9d24ad  vmovaps xmm9, [rsp+0x90]
000076b67a9d24b6  vmovaps xmm10, [rsp+0xA0]
000076b67a9d24bf  vmovaps xmm11, [rsp+0xB0]
000076b67a9d24c8  vmovaps xmm12, [rsp+0xC0]
000076b67a9d24d1  vmovaps xmm14, [rsp+0xD0]
000076b67a9d24da  vmovaps xmm15, [rsp+0xE0]
000076b67a9d24e3  add rsp, 0xF0
000076b67a9d24ea  pop r11
000076b67a9d24ec  pop r10
000076b67a9d24ee  pop r9
000076b67a9d24f0  pop r8
000076b67a9d24f2  pop rsi
000076b67a9d24f3  pop rdi
000076b67a9d24f4  pop rdx
000076b67a9d24f5  pop rcx
000076b67a9d24f6  pop rax
000076b67a9d24f7  add rsp, 0x08
000076b67a9d24fb  jmp 0x000076B67A9CFC76
000076b67a9d2500  call 0x000076B67A7FF430
000076b67a9d2505  jmp 0x000076B67A9CFC83
000076b67a9d250a  sub rsp, 0x08
000076b67a9d250e  push rax
000076b67a9d250f  push rcx
000076b67a9d2510  push rdx
000076b67a9d2511  push rdi
000076b67a9d2512  push rsi
000076b67a9d2513  push r8
000076b67a9d2515  push r9
000076b67a9d2517  push r10
000076b67a9d2519  push r11
000076b67a9d251b  sub rsp, 0xF0
000076b67a9d2522  vmovaps [rsp], xmm0
000076b67a9d2527  vmovaps [rsp+0x10], xmm1
000076b67a9d252d  vmovaps [rsp+0x20], xmm2
000076b67a9d2533  vmovaps [rsp+0x30], xmm3
000076b67a9d2539  vmovaps [rsp+0x40], xmm4
000076b67a9d253f  vmovaps [rsp+0x50], xmm5
000076b67a9d2545  vmovaps [rsp+0x60], xmm6
000076b67a9d254b  vmovaps [rsp+0x70], xmm7
000076b67a9d2551  vmovaps [rsp+0x80], xmm8
000076b67a9d255a  vmovaps [rsp+0x90], xmm9
000076b67a9d2563  vmovaps [rsp+0xA0], xmm10
000076b67a9d256c  vmovaps [rsp+0xB0], xmm11
000076b67a9d2575  vmovaps [rsp+0xC0], xmm12
000076b67a9d257e  vmovaps [rsp+0xD0], xmm13
000076b67a9d2587  vmovaps [rsp+0xE0], xmm14
000076b67a9d2590  sub rsp, 0x30
000076b67a9d2594  movaps [rsp], xmm15
000076b67a9d2599  movaps [rsp+0x10], xmm11
000076b67a9d259f  movaps [rsp+0x20], xmm1
000076b67a9d25a4  lea rdi, [rsp]
000076b67a9d25a8  mov esi, 0x00
000076b67a9d25ad  mov rax, 0x63C5EF2DF530
000076b67a9d25b7  call rax
000076b67a9d25b9  movaps xmm15, [rsp]
000076b67a9d25be  add rsp, 0x30
000076b67a9d25c2  vmovaps xmm0, [rsp]
000076b67a9d25c7  vmovaps xmm1, [rsp+0x10]
000076b67a9d25cd  vmovaps xmm2, [rsp+0x20]
000076b67a9d25d3  vmovaps xmm3, [rsp+0x30]
000076b67a9d25d9  vmovaps xmm4, [rsp+0x40]
000076b67a9d25df  vmovaps xmm5, [rsp+0x50]
000076b67a9d25e5  vmovaps xmm6, [rsp+0x60]
000076b67a9d25eb  vmovaps xmm7, [rsp+0x70]
000076b67a9d25f1  vmovaps xmm8, [rsp+0x80]
000076b67a9d25fa  vmovaps xmm9, [rsp+0x90]
000076b67a9d2603  vmovaps xmm10, [rsp+0xA0]
000076b67a9d260c  vmovaps xmm11, [rsp+0xB0]
000076b67a9d2615  vmovaps xmm12, [rsp+0xC0]
000076b67a9d261e  vmovaps xmm13, [rsp+0xD0]
000076b67a9d2627  vmovaps xmm14, [rsp+0xE0]
000076b67a9d2630  add rsp, 0xF0
000076b67a9d2637  pop r11
000076b67a9d2639  pop r10
000076b67a9d263b  pop r9
000076b67a9d263d  pop r8
000076b67a9d263f  pop rsi
000076b67a9d2640  pop rdi
000076b67a9d2641  pop rdx
000076b67a9d2642  pop rcx
000076b67a9d2643  pop rax
000076b67a9d2644  add rsp, 0x08
000076b67a9d2648  jmp 0x000076B67A9CFCBC
000076b67a9d264d  sub rsp, 0x08
000076b67a9d2651  push rax
000076b67a9d2652  push rcx
000076b67a9d2653  push rdx
000076b67a9d2654  push rdi
000076b67a9d2655  push rsi
000076b67a9d2656  push r8
000076b67a9d2658  push r9
000076b67a9d265a  push r10
000076b67a9d265c  push r11
000076b67a9d265e  sub rsp, 0xF0
000076b67a9d2665  vmovaps [rsp], xmm0
000076b67a9d266a  vmovaps [rsp+0x10], xmm1
000076b67a9d2670  vmovaps [rsp+0x20], xmm2
000076b67a9d2676  vmovaps [rsp+0x30], xmm3
000076b67a9d267c  vmovaps [rsp+0x40], xmm4
000076b67a9d2682  vmovaps [rsp+0x50], xmm5
000076b67a9d2688  vmovaps [rsp+0x60], xmm6
000076b67a9d268e  vmovaps [rsp+0x70], xmm7
000076b67a9d2694  vmovaps [rsp+0x80], xmm8
000076b67a9d269d  vmovaps [rsp+0x90], xmm9
000076b67a9d26a6  vmovaps [rsp+0xA0], xmm10
000076b67a9d26af  vmovaps [rsp+0xB0], xmm12
000076b67a9d26b8  vmovaps [rsp+0xC0], xmm13
000076b67a9d26c1  vmovaps [rsp+0xD0], xmm14
000076b67a9d26ca  vmovaps [rsp+0xE0], xmm15
000076b67a9d26d3  sub rsp, 0x30
000076b67a9d26d7  movaps [rsp], xmm11
000076b67a9d26dc  movaps [rsp+0x10], xmm6
000076b67a9d26e1  movaps [rsp+0x20], xmm14
000076b67a9d26e7  lea rdi, [rsp]
000076b67a9d26eb  mov esi, 0x00
000076b67a9d26f0  mov rax, 0x63C5EF2DF530
000076b67a9d26fa  call rax
000076b67a9d26fc  movaps xmm11, [rsp]
000076b67a9d2701  add rsp, 0x30
000076b67a9d2705  vmovaps xmm0, [rsp]
000076b67a9d270a  vmovaps xmm1, [rsp+0x10]
000076b67a9d2710  vmovaps xmm2, [rsp+0x20]
000076b67a9d2716  vmovaps xmm3, [rsp+0x30]
000076b67a9d271c  vmovaps xmm4, [rsp+0x40]
000076b67a9d2722  vmovaps xmm5, [rsp+0x50]
000076b67a9d2728  vmovaps xmm6, [rsp+0x60]
000076b67a9d272e  vmovaps xmm7, [rsp+0x70]
000076b67a9d2734  vmovaps xmm8, [rsp+0x80]
000076b67a9d273d  vmovaps xmm9, [rsp+0x90]
000076b67a9d2746  vmovaps xmm10, [rsp+0xA0]
000076b67a9d274f  vmovaps xmm12, [rsp+0xB0]
000076b67a9d2758  vmovaps xmm13, [rsp+0xC0]
000076b67a9d2761  vmovaps xmm14, [rsp+0xD0]
000076b67a9d276a  vmovaps xmm15, [rsp+0xE0]
000076b67a9d2773  add rsp, 0xF0
000076b67a9d277a  pop r11
000076b67a9d277c  pop r10
000076b67a9d277e  pop r9
000076b67a9d2780  pop r8
000076b67a9d2782  pop rsi
000076b67a9d2783  pop rdi
000076b67a9d2784  pop rdx
000076b67a9d2785  pop rcx
000076b67a9d2786  pop rax
000076b67a9d2787  add rsp, 0x08
000076b67a9d278b  jmp 0x000076B67A9CFD34
000076b67a9d2790  call 0x000076B67A7FF430
000076b67a9d2795  jmp 0x000076B67A9CFD3E
000076b67a9d279a  sub rsp, 0x08
000076b67a9d279e  push rax
000076b67a9d279f  push rcx
000076b67a9d27a0  push rdx
000076b67a9d27a1  push rdi
000076b67a9d27a2  push rsi
000076b67a9d27a3  push r8
000076b67a9d27a5  push r9
000076b67a9d27a7  push r10
000076b67a9d27a9  push r11
000076b67a9d27ab  sub rsp, 0xF0
000076b67a9d27b2  vmovaps [rsp], xmm0
000076b67a9d27b7  vmovaps [rsp+0x10], xmm1
000076b67a9d27bd  vmovaps [rsp+0x20], xmm2
000076b67a9d27c3  vmovaps [rsp+0x30], xmm3
000076b67a9d27c9  vmovaps [rsp+0x40], xmm4
000076b67a9d27cf  vmovaps [rsp+0x50], xmm5
000076b67a9d27d5  vmovaps [rsp+0x60], xmm6
000076b67a9d27db  vmovaps [rsp+0x70], xmm7
000076b67a9d27e1  vmovaps [rsp+0x80], xmm8
000076b67a9d27ea  vmovaps [rsp+0x90], xmm9
000076b67a9d27f3  vmovaps [rsp+0xA0], xmm10
000076b67a9d27fc  vmovaps [rsp+0xB0], xmm11
000076b67a9d2805  vmovaps [rsp+0xC0], xmm12
000076b67a9d280e  vmovaps [rsp+0xD0], xmm13
000076b67a9d2817  vmovaps [rsp+0xE0], xmm15
000076b67a9d2820  sub rsp, 0x30
000076b67a9d2824  movaps [rsp], xmm14
000076b67a9d2829  movaps [rsp+0x10], xmm6
000076b67a9d282e  movaps [rsp+0x20], xmm2
000076b67a9d2833  lea rdi, [rsp]
000076b67a9d2837  mov esi, 0x00
000076b67a9d283c  mov rax, 0x63C5EF2DF530
000076b67a9d2846  call rax
000076b67a9d2848  movaps xmm14, [rsp]
000076b67a9d284d  add rsp, 0x30
000076b67a9d2851  vmovaps xmm0, [rsp]
000076b67a9d2856  vmovaps xmm1, [rsp+0x10]
000076b67a9d285c  vmovaps xmm2, [rsp+0x20]
000076b67a9d2862  vmovaps xmm3, [rsp+0x30]
000076b67a9d2868  vmovaps xmm4, [rsp+0x40]
000076b67a9d286e  vmovaps xmm5, [rsp+0x50]
000076b67a9d2874  vmovaps xmm6, [rsp+0x60]
000076b67a9d287a  vmovaps xmm7, [rsp+0x70]
000076b67a9d2880  vmovaps xmm8, [rsp+0x80]
000076b67a9d2889  vmovaps xmm9, [rsp+0x90]
000076b67a9d2892  vmovaps xmm10, [rsp+0xA0]
000076b67a9d289b  vmovaps xmm11, [rsp+0xB0]
000076b67a9d28a4  vmovaps xmm12, [rsp+0xC0]
000076b67a9d28ad  vmovaps xmm13, [rsp+0xD0]
000076b67a9d28b6  vmovaps xmm15, [rsp+0xE0]
000076b67a9d28bf  add rsp, 0xF0
000076b67a9d28c6  pop r11
000076b67a9d28c8  pop r10
000076b67a9d28ca  pop r9
000076b67a9d28cc  pop r8
000076b67a9d28ce  pop rsi
000076b67a9d28cf  pop rdi
000076b67a9d28d0  pop rdx
000076b67a9d28d1  pop rcx
000076b67a9d28d2  pop rax
000076b67a9d28d3  add rsp, 0x08
000076b67a9d28d7  jmp 0x000076B67A9CFD72
000076b67a9d28dc  sub rsp, 0x08
000076b67a9d28e0  push rax
000076b67a9d28e1  push rcx
000076b67a9d28e2  push rdx
000076b67a9d28e3  push rdi
000076b67a9d28e4  push rsi
000076b67a9d28e5  push r8
000076b67a9d28e7  push r9
000076b67a9d28e9  push r10
000076b67a9d28eb  push r11
000076b67a9d28ed  sub rsp, 0xF0
000076b67a9d28f4  vmovaps [rsp], xmm0
000076b67a9d28f9  vmovaps [rsp+0x10], xmm1
000076b67a9d28ff  vmovaps [rsp+0x20], xmm2
000076b67a9d2905  vmovaps [rsp+0x30], xmm3
000076b67a9d290b  vmovaps [rsp+0x40], xmm4
000076b67a9d2911  vmovaps [rsp+0x50], xmm5
000076b67a9d2917  vmovaps [rsp+0x60], xmm7
000076b67a9d291d  vmovaps [rsp+0x70], xmm8
000076b67a9d2923  vmovaps [rsp+0x80], xmm9
000076b67a9d292c  vmovaps [rsp+0x90], xmm10
000076b67a9d2935  vmovaps [rsp+0xA0], xmm11
000076b67a9d293e  vmovaps [rsp+0xB0], xmm12
000076b67a9d2947  vmovaps [rsp+0xC0], xmm13
000076b67a9d2950  vmovaps [rsp+0xD0], xmm14
000076b67a9d2959  vmovaps [rsp+0xE0], xmm15
000076b67a9d2962  sub rsp, 0x30
000076b67a9d2966  movaps [rsp], xmm6
000076b67a9d296a  movaps [rsp+0x10], xmm5
000076b67a9d296f  movaps [rsp+0x20], xmm1
000076b67a9d2974  lea rdi, [rsp]
000076b67a9d2978  mov esi, 0x00
000076b67a9d297d  mov rax, 0x63C5EF2DF530
000076b67a9d2987  call rax
000076b67a9d2989  movaps xmm6, [rsp]
000076b67a9d298d  add rsp, 0x30
000076b67a9d2991  vmovaps xmm0, [rsp]
000076b67a9d2996  vmovaps xmm1, [rsp+0x10]
000076b67a9d299c  vmovaps xmm2, [rsp+0x20]
000076b67a9d29a2  vmovaps xmm3, [rsp+0x30]
000076b67a9d29a8  vmovaps xmm4, [rsp+0x40]
000076b67a9d29ae  vmovaps xmm5, [rsp+0x50]
000076b67a9d29b4  vmovaps xmm7, [rsp+0x60]
000076b67a9d29ba  vmovaps xmm8, [rsp+0x70]
000076b67a9d29c0  vmovaps xmm9, [rsp+0x80]
000076b67a9d29c9  vmovaps xmm10, [rsp+0x90]
000076b67a9d29d2  vmovaps xmm11, [rsp+0xA0]
000076b67a9d29db  vmovaps xmm12, [rsp+0xB0]
000076b67a9d29e4  vmovaps xmm13, [rsp+0xC0]
000076b67a9d29ed  vmovaps xmm14, [rsp+0xD0]
000076b67a9d29f6  vmovaps xmm15, [rsp+0xE0]
000076b67a9d29ff  add rsp, 0xF0
000076b67a9d2a06  pop r11
000076b67a9d2a08  pop r10
000076b67a9d2a0a  pop r9
000076b67a9d2a0c  pop r8
000076b67a9d2a0e  pop rsi
000076b67a9d2a0f  pop rdi
000076b67a9d2a10  pop rdx
000076b67a9d2a11  pop rcx
000076b67a9d2a12  pop rax
000076b67a9d2a13  add rsp, 0x08
000076b67a9d2a17  jmp 0x000076B67A9CFD98
000076b67a9d2a1c  sub rsp, 0x08
000076b67a9d2a20  push rax
000076b67a9d2a21  push rcx
000076b67a9d2a22  push rdx
000076b67a9d2a23  push rdi
000076b67a9d2a24  push rsi
000076b67a9d2a25  push r8
000076b67a9d2a27  push r9
000076b67a9d2a29  push r10
000076b67a9d2a2b  push r11
000076b67a9d2a2d  sub rsp, 0xF0
000076b67a9d2a34  vmovaps [rsp], xmm0
000076b67a9d2a39  vmovaps [rsp+0x10], xmm2
000076b67a9d2a3f  vmovaps [rsp+0x20], xmm3
000076b67a9d2a45  vmovaps [rsp+0x30], xmm4
000076b67a9d2a4b  vmovaps [rsp+0x40], xmm5
000076b67a9d2a51  vmovaps [rsp+0x50], xmm6
000076b67a9d2a57  vmovaps [rsp+0x60], xmm7
000076b67a9d2a5d  vmovaps [rsp+0x70], xmm8
000076b67a9d2a63  vmovaps [rsp+0x80], xmm9
000076b67a9d2a6c  vmovaps [rsp+0x90], xmm10
000076b67a9d2a75  vmovaps [rsp+0xA0], xmm11
000076b67a9d2a7e  vmovaps [rsp+0xB0], xmm12
000076b67a9d2a87  vmovaps [rsp+0xC0], xmm13
000076b67a9d2a90  vmovaps [rsp+0xD0], xmm14
000076b67a9d2a99  vmovaps [rsp+0xE0], xmm15
000076b67a9d2aa2  sub rsp, 0x30
000076b67a9d2aa6  movaps [rsp], xmm1
000076b67a9d2aaa  movaps [rsp+0x10], xmm5
000076b67a9d2aaf  movaps [rsp+0x20], xmm13
000076b67a9d2ab5  lea rdi, [rsp]
000076b67a9d2ab9  mov esi, 0x00
000076b67a9d2abe  mov rax, 0x63C5EF2DF530
000076b67a9d2ac8  call rax
000076b67a9d2aca  movaps xmm1, [rsp]
000076b67a9d2ace  add rsp, 0x30
000076b67a9d2ad2  vmovaps xmm0, [rsp]
000076b67a9d2ad7  vmovaps xmm2, [rsp+0x10]
000076b67a9d2add  vmovaps xmm3, [rsp+0x20]
000076b67a9d2ae3  vmovaps xmm4, [rsp+0x30]
000076b67a9d2ae9  vmovaps xmm5, [rsp+0x40]
000076b67a9d2aef  vmovaps xmm6, [rsp+0x50]
000076b67a9d2af5  vmovaps xmm7, [rsp+0x60]
000076b67a9d2afb  vmovaps xmm8, [rsp+0x70]
000076b67a9d2b01  vmovaps xmm9, [rsp+0x80]
000076b67a9d2b0a  vmovaps xmm10, [rsp+0x90]
000076b67a9d2b13  vmovaps xmm11, [rsp+0xA0]
000076b67a9d2b1c  vmovaps xmm12, [rsp+0xB0]
000076b67a9d2b25  vmovaps xmm13, [rsp+0xC0]
000076b67a9d2b2e  vmovaps xmm14, [rsp+0xD0]
000076b67a9d2b37  vmovaps xmm15, [rsp+0xE0]
000076b67a9d2b40  add rsp, 0xF0
000076b67a9d2b47  pop r11
000076b67a9d2b49  pop r10
000076b67a9d2b4b  pop r9
000076b67a9d2b4d  pop r8
000076b67a9d2b4f  pop rsi
000076b67a9d2b50  pop rdi
000076b67a9d2b51  pop rdx
000076b67a9d2b52  pop rcx
000076b67a9d2b53  pop rax
000076b67a9d2b54  add rsp, 0x08
000076b67a9d2b58  jmp 0x000076B67A9CFDB6
000076b67a9d2b5d  sub rsp, 0x08
000076b67a9d2b61  push rax
000076b67a9d2b62  push rcx
000076b67a9d2b63  push rdx
000076b67a9d2b64  push rdi
000076b67a9d2b65  push rsi
000076b67a9d2b66  push r8
000076b67a9d2b68  push r9
000076b67a9d2b6a  push r10
000076b67a9d2b6c  push r11
000076b67a9d2b6e  sub rsp, 0xF0
000076b67a9d2b75  vmovaps [rsp], xmm0
000076b67a9d2b7a  vmovaps [rsp+0x10], xmm1
000076b67a9d2b80  vmovaps [rsp+0x20], xmm2
000076b67a9d2b86  vmovaps [rsp+0x30], xmm3
000076b67a9d2b8c  vmovaps [rsp+0x40], xmm4
000076b67a9d2b92  vmovaps [rsp+0x50], xmm6
000076b67a9d2b98  vmovaps [rsp+0x60], xmm7
000076b67a9d2b9e  vmovaps [rsp+0x70], xmm8
000076b67a9d2ba4  vmovaps [rsp+0x80], xmm9
000076b67a9d2bad  vmovaps [rsp+0x90], xmm10
000076b67a9d2bb6  vmovaps [rsp+0xA0], xmm11
000076b67a9d2bbf  vmovaps [rsp+0xB0], xmm12
000076b67a9d2bc8  vmovaps [rsp+0xC0], xmm13
000076b67a9d2bd1  vmovaps [rsp+0xD0], xmm14
000076b67a9d2bda  vmovaps [rsp+0xE0], xmm15
000076b67a9d2be3  sub rsp, 0x30
000076b67a9d2be7  movaps [rsp], xmm5
000076b67a9d2beb  movaps [rsp+0x10], xmm2
000076b67a9d2bf0  movaps [rsp+0x20], xmm13
000076b67a9d2bf6  lea rdi, [rsp]
000076b67a9d2bfa  mov esi, 0x00
000076b67a9d2bff  mov rax, 0x63C5EF2DF530
000076b67a9d2c09  call rax
000076b67a9d2c0b  movaps xmm5, [rsp]
000076b67a9d2c0f  add rsp, 0x30
000076b67a9d2c13  vmovaps xmm0, [rsp]
000076b67a9d2c18  vmovaps xmm1, [rsp+0x10]
000076b67a9d2c1e  vmovaps xmm2, [rsp+0x20]
000076b67a9d2c24  vmovaps xmm3, [rsp+0x30]
000076b67a9d2c2a  vmovaps xmm4, [rsp+0x40]
000076b67a9d2c30  vmovaps xmm6, [rsp+0x50]
000076b67a9d2c36  vmovaps xmm7, [rsp+0x60]
000076b67a9d2c3c  vmovaps xmm8, [rsp+0x70]
000076b67a9d2c42  vmovaps xmm9, [rsp+0x80]
000076b67a9d2c4b  vmovaps xmm10, [rsp+0x90]
000076b67a9d2c54  vmovaps xmm11, [rsp+0xA0]
000076b67a9d2c5d  vmovaps xmm12, [rsp+0xB0]
000076b67a9d2c66  vmovaps xmm13, [rsp+0xC0]
000076b67a9d2c6f  vmovaps xmm14, [rsp+0xD0]
000076b67a9d2c78  vmovaps xmm15, [rsp+0xE0]
000076b67a9d2c81  add rsp, 0xF0
000076b67a9d2c88  pop r11
000076b67a9d2c8a  pop r10
000076b67a9d2c8c  pop r9
000076b67a9d2c8e  pop r8
000076b67a9d2c90  pop rsi
000076b67a9d2c91  pop rdi
000076b67a9d2c92  pop rdx
000076b67a9d2c93  pop rcx
000076b67a9d2c94  pop rax
000076b67a9d2c95  add rsp, 0x08
000076b67a9d2c99  jmp 0x000076B67A9CFDEC
000076b67a9d2c9e  sub rsp, 0x08
000076b67a9d2ca2  push rax
000076b67a9d2ca3  push rcx
000076b67a9d2ca4  push rdx
000076b67a9d2ca5  push rdi
000076b67a9d2ca6  push rsi
000076b67a9d2ca7  push r8
000076b67a9d2ca9  push r9
000076b67a9d2cab  push r10
000076b67a9d2cad  push r11
000076b67a9d2caf  sub rsp, 0xF0
000076b67a9d2cb6  vmovaps [rsp], xmm0
000076b67a9d2cbb  vmovaps [rsp+0x10], xmm1
000076b67a9d2cc1  vmovaps [rsp+0x20], xmm2
000076b67a9d2cc7  vmovaps [rsp+0x30], xmm3
000076b67a9d2ccd  vmovaps [rsp+0x40], xmm4
000076b67a9d2cd3  vmovaps [rsp+0x50], xmm5
000076b67a9d2cd9  vmovaps [rsp+0x60], xmm6
000076b67a9d2cdf  vmovaps [rsp+0x70], xmm7
000076b67a9d2ce5  vmovaps [rsp+0x80], xmm8
000076b67a9d2cee  vmovaps [rsp+0x90], xmm9
000076b67a9d2cf7  vmovaps [rsp+0xA0], xmm10
000076b67a9d2d00  vmovaps [rsp+0xB0], xmm11
000076b67a9d2d09  vmovaps [rsp+0xC0], xmm12
000076b67a9d2d12  vmovaps [rsp+0xD0], xmm14
000076b67a9d2d1b  vmovaps [rsp+0xE0], xmm15
000076b67a9d2d24  sub rsp, 0x30
000076b67a9d2d28  movaps [rsp], xmm13
000076b67a9d2d2d  movaps [rsp+0x10], xmm10
000076b67a9d2d33  movaps [rsp+0x20], xmm1
000076b67a9d2d38  lea rdi, [rsp]
000076b67a9d2d3c  mov esi, 0x00
000076b67a9d2d41  mov rax, 0x63C5EF2DF530
000076b67a9d2d4b  call rax
000076b67a9d2d4d  movaps xmm13, [rsp]
000076b67a9d2d52  add rsp, 0x30
000076b67a9d2d56  vmovaps xmm0, [rsp]
000076b67a9d2d5b  vmovaps xmm1, [rsp+0x10]
000076b67a9d2d61  vmovaps xmm2, [rsp+0x20]
000076b67a9d2d67  vmovaps xmm3, [rsp+0x30]
000076b67a9d2d6d  vmovaps xmm4, [rsp+0x40]
000076b67a9d2d73  vmovaps xmm5, [rsp+0x50]
000076b67a9d2d79  vmovaps xmm6, [rsp+0x60]
000076b67a9d2d7f  vmovaps xmm7, [rsp+0x70]
000076b67a9d2d85  vmovaps xmm8, [rsp+0x80]
000076b67a9d2d8e  vmovaps xmm9, [rsp+0x90]
000076b67a9d2d97  vmovaps xmm10, [rsp+0xA0]
000076b67a9d2da0  vmovaps xmm11, [rsp+0xB0]
000076b67a9d2da9  vmovaps xmm12, [rsp+0xC0]
000076b67a9d2db2  vmovaps xmm14, [rsp+0xD0]
000076b67a9d2dbb  vmovaps xmm15, [rsp+0xE0]
000076b67a9d2dc4  add rsp, 0xF0
000076b67a9d2dcb  pop r11
000076b67a9d2dcd  pop r10
000076b67a9d2dcf  pop r9
000076b67a9d2dd1  pop r8
000076b67a9d2dd3  pop rsi
000076b67a9d2dd4  pop rdi
000076b67a9d2dd5  pop rdx
000076b67a9d2dd6  pop rcx
000076b67a9d2dd7  pop rax
000076b67a9d2dd8  add rsp, 0x08
000076b67a9d2ddc  jmp 0x000076B67A9CFE15
000076b67a9d2de1  sub rsp, 0x08
000076b67a9d2de5  push rax
000076b67a9d2de6  push rcx
000076b67a9d2de7  push rdx
000076b67a9d2de8  push rdi
000076b67a9d2de9  push rsi
000076b67a9d2dea  push r8
000076b67a9d2dec  push r9
000076b67a9d2dee  push r10
000076b67a9d2df0  push r11
000076b67a9d2df2  sub rsp, 0xF0
000076b67a9d2df9  vmovaps [rsp], xmm0
000076b67a9d2dfe  vmovaps [rsp+0x10], xmm2
000076b67a9d2e04  vmovaps [rsp+0x20], xmm3
000076b67a9d2e0a  vmovaps [rsp+0x30], xmm4
000076b67a9d2e10  vmovaps [rsp+0x40], xmm5
000076b67a9d2e16  vmovaps [rsp+0x50], xmm6
000076b67a9d2e1c  vmovaps [rsp+0x60], xmm7
000076b67a9d2e22  vmovaps [rsp+0x70], xmm8
000076b67a9d2e28  vmovaps [rsp+0x80], xmm9
000076b67a9d2e31  vmovaps [rsp+0x90], xmm10
000076b67a9d2e3a  vmovaps [rsp+0xA0], xmm11
000076b67a9d2e43  vmovaps [rsp+0xB0], xmm12
000076b67a9d2e4c  vmovaps [rsp+0xC0], xmm13
000076b67a9d2e55  vmovaps [rsp+0xD0], xmm14
000076b67a9d2e5e  vmovaps [rsp+0xE0], xmm15
000076b67a9d2e67  sub rsp, 0x30
000076b67a9d2e6b  movaps [rsp], xmm1
000076b67a9d2e6f  movaps [rsp+0x10], xmm15
000076b67a9d2e75  movaps [rsp+0x20], xmm10
000076b67a9d2e7b  lea rdi, [rsp]
000076b67a9d2e7f  mov esi, 0x00
000076b67a9d2e84  mov rax, 0x63C5EF2DF530
000076b67a9d2e8e  call rax
000076b67a9d2e90  movaps xmm1, [rsp]
000076b67a9d2e94  add rsp, 0x30
000076b67a9d2e98  vmovaps xmm0, [rsp]
000076b67a9d2e9d  vmovaps xmm2, [rsp+0x10]
000076b67a9d2ea3  vmovaps xmm3, [rsp+0x20]
000076b67a9d2ea9  vmovaps xmm4, [rsp+0x30]
000076b67a9d2eaf  vmovaps xmm5, [rsp+0x40]
000076b67a9d2eb5  vmovaps xmm6, [rsp+0x50]
000076b67a9d2ebb  vmovaps xmm7, [rsp+0x60]
000076b67a9d2ec1  vmovaps xmm8, [rsp+0x70]
000076b67a9d2ec7  vmovaps xmm9, [rsp+0x80]
000076b67a9d2ed0  vmovaps xmm10, [rsp+0x90]
000076b67a9d2ed9  vmovaps xmm11, [rsp+0xA0]
000076b67a9d2ee2  vmovaps xmm12, [rsp+0xB0]
000076b67a9d2eeb  vmovaps xmm13, [rsp+0xC0]
000076b67a9d2ef4  vmovaps xmm14, [rsp+0xD0]
000076b67a9d2efd  vmovaps xmm15, [rsp+0xE0]
000076b67a9d2f06  add rsp, 0xF0
000076b67a9d2f0d  pop r11
000076b67a9d2f0f  pop r10
000076b67a9d2f11  pop r9
000076b67a9d2f13  pop r8
000076b67a9d2f15  pop rsi
000076b67a9d2f16  pop rdi
000076b67a9d2f17  pop rdx
000076b67a9d2f18  pop rcx
000076b67a9d2f19  pop rax
000076b67a9d2f1a  add rsp, 0x08
000076b67a9d2f1e  jmp 0x000076B67A9CFE34
000076b67a9d2f23  sub rsp, 0x08
000076b67a9d2f27  push rax
000076b67a9d2f28  push rcx
000076b67a9d2f29  push rdx
000076b67a9d2f2a  push rdi
000076b67a9d2f2b  push rsi
000076b67a9d2f2c  push r8
000076b67a9d2f2e  push r9
000076b67a9d2f30  push r10
000076b67a9d2f32  push r11
000076b67a9d2f34  sub rsp, 0xF0
000076b67a9d2f3b  vmovaps [rsp], xmm0
000076b67a9d2f40  vmovaps [rsp+0x10], xmm1
000076b67a9d2f46  vmovaps [rsp+0x20], xmm2
000076b67a9d2f4c  vmovaps [rsp+0x30], xmm3
000076b67a9d2f52  vmovaps [rsp+0x40], xmm4
000076b67a9d2f58  vmovaps [rsp+0x50], xmm5
000076b67a9d2f5e  vmovaps [rsp+0x60], xmm6
000076b67a9d2f64  vmovaps [rsp+0x70], xmm7
000076b67a9d2f6a  vmovaps [rsp+0x80], xmm8
000076b67a9d2f73  vmovaps [rsp+0x90], xmm9
000076b67a9d2f7c  vmovaps [rsp+0xA0], xmm10
000076b67a9d2f85  vmovaps [rsp+0xB0], xmm11
000076b67a9d2f8e  vmovaps [rsp+0xC0], xmm12
000076b67a9d2f97  vmovaps [rsp+0xD0], xmm13
000076b67a9d2fa0  vmovaps [rsp+0xE0], xmm14
000076b67a9d2fa9  sub rsp, 0x30
000076b67a9d2fad  movaps [rsp], xmm15
000076b67a9d2fb2  movaps [rsp+0x10], xmm10
000076b67a9d2fb8  movaps [rsp+0x20], xmm11
000076b67a9d2fbe  lea rdi, [rsp]
000076b67a9d2fc2  mov esi, 0x00
000076b67a9d2fc7  mov rax, 0x63C5EF2DF530
000076b67a9d2fd1  call rax
000076b67a9d2fd3  movaps xmm15, [rsp]
000076b67a9d2fd8  add rsp, 0x30
000076b67a9d2fdc  vmovaps xmm0, [rsp]
000076b67a9d2fe1  vmovaps xmm1, [rsp+0x10]
000076b67a9d2fe7  vmovaps xmm2, [rsp+0x20]
000076b67a9d2fed  vmovaps xmm3, [rsp+0x30]
000076b67a9d2ff3  vmovaps xmm4, [rsp+0x40]
000076b67a9d2ff9  vmovaps xmm5, [rsp+0x50]
000076b67a9d2fff  vmovaps xmm6, [rsp+0x60]
000076b67a9d3005  vmovaps xmm7, [rsp+0x70]
000076b67a9d300b  vmovaps xmm8, [rsp+0x80]
000076b67a9d3014  vmovaps xmm9, [rsp+0x90]
000076b67a9d301d  vmovaps xmm10, [rsp+0xA0]
000076b67a9d3026  vmovaps xmm11, [rsp+0xB0]
000076b67a9d302f  vmovaps xmm12, [rsp+0xC0]
000076b67a9d3038  vmovaps xmm13, [rsp+0xD0]
000076b67a9d3041  vmovaps xmm14, [rsp+0xE0]
000076b67a9d304a  add rsp, 0xF0
000076b67a9d3051  pop r11
000076b67a9d3053  pop r10
000076b67a9d3055  pop r9
000076b67a9d3057  pop r8
000076b67a9d3059  pop rsi
000076b67a9d305a  pop rdi
000076b67a9d305b  pop rdx
000076b67a9d305c  pop rcx
000076b67a9d305d  pop rax
000076b67a9d305e  add rsp, 0x08
000076b67a9d3062  jmp 0x000076B67A9CFE57
000076b67a9d3067  sub rsp, 0x08
000076b67a9d306b  push rax
000076b67a9d306c  push rcx
000076b67a9d306d  push rdx
000076b67a9d306e  push rdi
000076b67a9d306f  push rsi
000076b67a9d3070  push r8
000076b67a9d3072  push r9
000076b67a9d3074  push r10
000076b67a9d3076  push r11
000076b67a9d3078  sub rsp, 0xF0
000076b67a9d307f  vmovaps [rsp], xmm0
000076b67a9d3084  vmovaps [rsp+0x10], xmm1
000076b67a9d308a  vmovaps [rsp+0x20], xmm2
000076b67a9d3090  vmovaps [rsp+0x30], xmm3
000076b67a9d3096  vmovaps [rsp+0x40], xmm4
000076b67a9d309c  vmovaps [rsp+0x50], xmm5
000076b67a9d30a2  vmovaps [rsp+0x60], xmm6
000076b67a9d30a8  vmovaps [rsp+0x70], xmm7
000076b67a9d30ae  vmovaps [rsp+0x80], xmm8
000076b67a9d30b7  vmovaps [rsp+0x90], xmm9
000076b67a9d30c0  vmovaps [rsp+0xA0], xmm11
000076b67a9d30c9  vmovaps [rsp+0xB0], xmm12
000076b67a9d30d2  vmovaps [rsp+0xC0], xmm13
000076b67a9d30db  vmovaps [rsp+0xD0], xmm14
000076b67a9d30e4  vmovaps [rsp+0xE0], xmm15
000076b67a9d30ed  sub rsp, 0x30
000076b67a9d30f1  movaps [rsp], xmm10
000076b67a9d30f6  movaps [rsp+0x10], xmm12
000076b67a9d30fc  movaps [rsp+0x20], xmm11
000076b67a9d3102  lea rdi, [rsp]
000076b67a9d3106  mov esi, 0x00
000076b67a9d310b  mov rax, 0x63C5EF2DF530
000076b67a9d3115  call rax
000076b67a9d3117  movaps xmm10, [rsp]
000076b67a9d311c  add rsp, 0x30
000076b67a9d3120  vmovaps xmm0, [rsp]
000076b67a9d3125  vmovaps xmm1, [rsp+0x10]
000076b67a9d312b  vmovaps xmm2, [rsp+0x20]
000076b67a9d3131  vmovaps xmm3, [rsp+0x30]
000076b67a9d3137  vmovaps xmm4, [rsp+0x40]
000076b67a9d313d  vmovaps xmm5, [rsp+0x50]
000076b67a9d3143  vmovaps xmm6, [rsp+0x60]
000076b67a9d3149  vmovaps xmm7, [rsp+0x70]
000076b67a9d314f  vmovaps xmm8, [rsp+0x80]
000076b67a9d3158  vmovaps xmm9, [rsp+0x90]
000076b67a9d3161  vmovaps xmm11, [rsp+0xA0]
000076b67a9d316a  vmovaps xmm12, [rsp+0xB0]
000076b67a9d3173  vmovaps xmm13, [rsp+0xC0]
000076b67a9d317c  vmovaps xmm14, [rsp+0xD0]
000076b67a9d3185  vmovaps xmm15, [rsp+0xE0]
000076b67a9d318e  add rsp, 0xF0
000076b67a9d3195  pop r11
000076b67a9d3197  pop r10
000076b67a9d3199  pop r9
000076b67a9d319b  pop r8
000076b67a9d319d  pop rsi
000076b67a9d319e  pop rdi
000076b67a9d319f  pop rdx
000076b67a9d31a0  pop rcx
000076b67a9d31a1  pop rax
000076b67a9d31a2  add rsp, 0x08
000076b67a9d31a6  jmp 0x000076B67A9CFE80
000076b67a9d31ab  sub rsp, 0x08
000076b67a9d31af  push rax
000076b67a9d31b0  push rcx
000076b67a9d31b1  push rdx
000076b67a9d31b2  push rdi
000076b67a9d31b3  push rsi
000076b67a9d31b4  push r8
000076b67a9d31b6  push r9
000076b67a9d31b8  push r10
000076b67a9d31ba  push r11
000076b67a9d31bc  sub rsp, 0xF0
000076b67a9d31c3  vmovaps [rsp], xmm0
000076b67a9d31c8  vmovaps [rsp+0x10], xmm1
000076b67a9d31ce  vmovaps [rsp+0x20], xmm2
000076b67a9d31d4  vmovaps [rsp+0x30], xmm3
000076b67a9d31da  vmovaps [rsp+0x40], xmm4
000076b67a9d31e0  vmovaps [rsp+0x50], xmm5
000076b67a9d31e6  vmovaps [rsp+0x60], xmm6
000076b67a9d31ec  vmovaps [rsp+0x70], xmm7
000076b67a9d31f2  vmovaps [rsp+0x80], xmm8
000076b67a9d31fb  vmovaps [rsp+0x90], xmm9
000076b67a9d3204  vmovaps [rsp+0xA0], xmm10
000076b67a9d320d  vmovaps [rsp+0xB0], xmm12
000076b67a9d3216  vmovaps [rsp+0xC0], xmm13
000076b67a9d321f  vmovaps [rsp+0xD0], xmm14
000076b67a9d3228  vmovaps [rsp+0xE0], xmm15
000076b67a9d3231  sub rsp, 0x30
000076b67a9d3235  movaps [rsp], xmm11
000076b67a9d323a  movaps [rsp+0x10], xmm2
000076b67a9d323f  movaps [rsp+0x20], xmm12
000076b67a9d3245  lea rdi, [rsp]
000076b67a9d3249  mov esi, 0x00
000076b67a9d324e  mov rax, 0x63C5EF2DF530
000076b67a9d3258  call rax
000076b67a9d325a  movaps xmm11, [rsp]
000076b67a9d325f  add rsp, 0x30
000076b67a9d3263  vmovaps xmm0, [rsp]
000076b67a9d3268  vmovaps xmm1, [rsp+0x10]
000076b67a9d326e  vmovaps xmm2, [rsp+0x20]
000076b67a9d3274  vmovaps xmm3, [rsp+0x30]
000076b67a9d327a  vmovaps xmm4, [rsp+0x40]
000076b67a9d3280  vmovaps xmm5, [rsp+0x50]
000076b67a9d3286  vmovaps xmm6, [rsp+0x60]
000076b67a9d328c  vmovaps xmm7, [rsp+0x70]
000076b67a9d3292  vmovaps xmm8, [rsp+0x80]
000076b67a9d329b  vmovaps xmm9, [rsp+0x90]
000076b67a9d32a4  vmovaps xmm10, [rsp+0xA0]
000076b67a9d32ad  vmovaps xmm12, [rsp+0xB0]
000076b67a9d32b6  vmovaps xmm13, [rsp+0xC0]
000076b67a9d32bf  vmovaps xmm14, [rsp+0xD0]
000076b67a9d32c8  vmovaps xmm15, [rsp+0xE0]
000076b67a9d32d1  add rsp, 0xF0
000076b67a9d32d8  pop r11
000076b67a9d32da  pop r10
000076b67a9d32dc  pop r9
000076b67a9d32de  pop r8
000076b67a9d32e0  pop rsi
000076b67a9d32e1  pop rdi
000076b67a9d32e2  pop rdx
000076b67a9d32e3  pop rcx
000076b67a9d32e4  pop rax
000076b67a9d32e5  add rsp, 0x08
000076b67a9d32e9  jmp 0x000076B67A9CFEB8
000076b67a9d32ee  sub rsp, 0x08
000076b67a9d32f2  push rax
000076b67a9d32f3  push rcx
000076b67a9d32f4  push rdx
000076b67a9d32f5  push rdi
000076b67a9d32f6  push rsi
000076b67a9d32f7  push r8
000076b67a9d32f9  push r9
000076b67a9d32fb  push r10
000076b67a9d32fd  push r11
000076b67a9d32ff  sub rsp, 0xF0
000076b67a9d3306  vmovaps [rsp], xmm0
000076b67a9d330b  vmovaps [rsp+0x10], xmm2
000076b67a9d3311  vmovaps [rsp+0x20], xmm3
000076b67a9d3317  vmovaps [rsp+0x30], xmm4
000076b67a9d331d  vmovaps [rsp+0x40], xmm5
000076b67a9d3323  vmovaps [rsp+0x50], xmm6
000076b67a9d3329  vmovaps [rsp+0x60], xmm7
000076b67a9d332f  vmovaps [rsp+0x70], xmm8
000076b67a9d3335  vmovaps [rsp+0x80], xmm9
000076b67a9d333e  vmovaps [rsp+0x90], xmm10
000076b67a9d3347  vmovaps [rsp+0xA0], xmm11
000076b67a9d3350  vmovaps [rsp+0xB0], xmm12
000076b67a9d3359  vmovaps [rsp+0xC0], xmm13
000076b67a9d3362  vmovaps [rsp+0xD0], xmm14
000076b67a9d336b  vmovaps [rsp+0xE0], xmm15
000076b67a9d3374  sub rsp, 0x30
000076b67a9d3378  movaps [rsp], xmm1
000076b67a9d337c  movaps [rsp+0x10], xmm14
000076b67a9d3382  movaps [rsp+0x20], xmm6
000076b67a9d3387  lea rdi, [rsp]
000076b67a9d338b  mov esi, 0x00
000076b67a9d3390  mov rax, 0x63C5EF2DF530
000076b67a9d339a  call rax
000076b67a9d339c  movaps xmm1, [rsp]
000076b67a9d33a0  add rsp, 0x30
000076b67a9d33a4  vmovaps xmm0, [rsp]
000076b67a9d33a9  vmovaps xmm2, [rsp+0x10]
000076b67a9d33af  vmovaps xmm3, [rsp+0x20]
000076b67a9d33b5  vmovaps xmm4, [rsp+0x30]
000076b67a9d33bb  vmovaps xmm5, [rsp+0x40]
000076b67a9d33c1  vmovaps xmm6, [rsp+0x50]
000076b67a9d33c7  vmovaps xmm7, [rsp+0x60]
000076b67a9d33cd  vmovaps xmm8, [rsp+0x70]
000076b67a9d33d3  vmovaps xmm9, [rsp+0x80]
000076b67a9d33dc  vmovaps xmm10, [rsp+0x90]
000076b67a9d33e5  vmovaps xmm11, [rsp+0xA0]
000076b67a9d33ee  vmovaps xmm12, [rsp+0xB0]
000076b67a9d33f7  vmovaps xmm13, [rsp+0xC0]
000076b67a9d3400  vmovaps xmm14, [rsp+0xD0]
000076b67a9d3409  vmovaps xmm15, [rsp+0xE0]
000076b67a9d3412  add rsp, 0xF0
000076b67a9d3419  pop r11
000076b67a9d341b  pop r10
000076b67a9d341d  pop r9
000076b67a9d341f  pop r8
000076b67a9d3421  pop rsi
000076b67a9d3422  pop rdi
000076b67a9d3423  pop rdx
000076b67a9d3424  pop rcx
000076b67a9d3425  pop rax
000076b67a9d3426  add rsp, 0x08
000076b67a9d342a  jmp 0x000076B67A9CFED1
000076b67a9d342f  sub rsp, 0x08
000076b67a9d3433  push rax
000076b67a9d3434  push rcx
000076b67a9d3435  push rdx
000076b67a9d3436  push rdi
000076b67a9d3437  push rsi
000076b67a9d3438  push r8
000076b67a9d343a  push r9
000076b67a9d343c  push r10
000076b67a9d343e  push r11
000076b67a9d3440  sub rsp, 0xF0
000076b67a9d3447  vmovaps [rsp], xmm0
000076b67a9d344c  vmovaps [rsp+0x10], xmm1
000076b67a9d3452  vmovaps [rsp+0x20], xmm2
000076b67a9d3458  vmovaps [rsp+0x30], xmm3
000076b67a9d345e  vmovaps [rsp+0x40], xmm4
000076b67a9d3464  vmovaps [rsp+0x50], xmm5
000076b67a9d346a  vmovaps [rsp+0x60], xmm6
000076b67a9d3470  vmovaps [rsp+0x70], xmm7
000076b67a9d3476  vmovaps [rsp+0x80], xmm8
000076b67a9d347f  vmovaps [rsp+0x90], xmm9
000076b67a9d3488  vmovaps [rsp+0xA0], xmm10
000076b67a9d3491  vmovaps [rsp+0xB0], xmm11
000076b67a9d349a  vmovaps [rsp+0xC0], xmm12
000076b67a9d34a3  vmovaps [rsp+0xD0], xmm13
000076b67a9d34ac  vmovaps [rsp+0xE0], xmm15
000076b67a9d34b5  sub rsp, 0x30
000076b67a9d34b9  movaps [rsp], xmm14
000076b67a9d34be  movaps [rsp+0x10], xmm12
000076b67a9d34c4  movaps [rsp+0x20], xmm5
000076b67a9d34c9  lea rdi, [rsp]
000076b67a9d34cd  mov esi, 0x00
000076b67a9d34d2  mov rax, 0x63C5EF2DF530
000076b67a9d34dc  call rax
000076b67a9d34de  movaps xmm14, [rsp]
000076b67a9d34e3  add rsp, 0x30
000076b67a9d34e7  vmovaps xmm0, [rsp]
000076b67a9d34ec  vmovaps xmm1, [rsp+0x10]
000076b67a9d34f2  vmovaps xmm2, [rsp+0x20]
000076b67a9d34f8  vmovaps xmm3, [rsp+0x30]
000076b67a9d34fe  vmovaps xmm4, [rsp+0x40]
000076b67a9d3504  vmovaps xmm5, [rsp+0x50]
000076b67a9d350a  vmovaps xmm6, [rsp+0x60]
000076b67a9d3510  vmovaps xmm7, [rsp+0x70]
000076b67a9d3516  vmovaps xmm8, [rsp+0x80]
000076b67a9d351f  vmovaps xmm9, [rsp+0x90]
000076b67a9d3528  vmovaps xmm10, [rsp+0xA0]
000076b67a9d3531  vmovaps xmm11, [rsp+0xB0]
000076b67a9d353a  vmovaps xmm12, [rsp+0xC0]
000076b67a9d3543  vmovaps xmm13, [rsp+0xD0]
000076b67a9d354c  vmovaps xmm15, [rsp+0xE0]
000076b67a9d3555  add rsp, 0xF0
000076b67a9d355c  pop r11
000076b67a9d355e  pop r10
000076b67a9d3560  pop r9
000076b67a9d3562  pop r8
000076b67a9d3564  pop rsi
000076b67a9d3565  pop rdi
000076b67a9d3566  pop rdx
000076b67a9d3567  pop rcx
000076b67a9d3568  pop rax
000076b67a9d3569  add rsp, 0x08
000076b67a9d356d  jmp 0x000076B67A9CFEF1
000076b67a9d3572  sub rsp, 0x08
000076b67a9d3576  push rax
000076b67a9d3577  push rcx
000076b67a9d3578  push rdx
000076b67a9d3579  push rdi
000076b67a9d357a  push rsi
000076b67a9d357b  push r8
000076b67a9d357d  push r9
000076b67a9d357f  push r10
000076b67a9d3581  push r11
000076b67a9d3583  sub rsp, 0xF0
000076b67a9d358a  vmovaps [rsp], xmm0
000076b67a9d358f  vmovaps [rsp+0x10], xmm1
000076b67a9d3595  vmovaps [rsp+0x20], xmm2
000076b67a9d359b  vmovaps [rsp+0x30], xmm3
000076b67a9d35a1  vmovaps [rsp+0x40], xmm4
000076b67a9d35a7  vmovaps [rsp+0x50], xmm5
000076b67a9d35ad  vmovaps [rsp+0x60], xmm7
000076b67a9d35b3  vmovaps [rsp+0x70], xmm8
000076b67a9d35b9  vmovaps [rsp+0x80], xmm9
000076b67a9d35c2  vmovaps [rsp+0x90], xmm10
000076b67a9d35cb  vmovaps [rsp+0xA0], xmm11
000076b67a9d35d4  vmovaps [rsp+0xB0], xmm12
000076b67a9d35dd  vmovaps [rsp+0xC0], xmm13
000076b67a9d35e6  vmovaps [rsp+0xD0], xmm14
000076b67a9d35ef  vmovaps [rsp+0xE0], xmm15
000076b67a9d35f8  sub rsp, 0x30
000076b67a9d35fc  movaps [rsp], xmm6
000076b67a9d3600  movaps [rsp+0x10], xmm9
000076b67a9d3606  movaps [rsp+0x20], xmm12
000076b67a9d360c  lea rdi, [rsp]
000076b67a9d3610  mov esi, 0x00
000076b67a9d3615  mov rax, 0x63C5EF2DF530
000076b67a9d361f  call rax
000076b67a9d3621  movaps xmm6, [rsp]
000076b67a9d3625  add rsp, 0x30
000076b67a9d3629  vmovaps xmm0, [rsp]
000076b67a9d362e  vmovaps xmm1, [rsp+0x10]
000076b67a9d3634  vmovaps xmm2, [rsp+0x20]
000076b67a9d363a  vmovaps xmm3, [rsp+0x30]
000076b67a9d3640  vmovaps xmm4, [rsp+0x40]
000076b67a9d3646  vmovaps xmm5, [rsp+0x50]
000076b67a9d364c  vmovaps xmm7, [rsp+0x60]
000076b67a9d3652  vmovaps xmm8, [rsp+0x70]
000076b67a9d3658  vmovaps xmm9, [rsp+0x80]
000076b67a9d3661  vmovaps xmm10, [rsp+0x90]
000076b67a9d366a  vmovaps xmm11, [rsp+0xA0]
000076b67a9d3673  vmovaps xmm12, [rsp+0xB0]
000076b67a9d367c  vmovaps xmm13, [rsp+0xC0]
000076b67a9d3685  vmovaps xmm14, [rsp+0xD0]
000076b67a9d368e  vmovaps xmm15, [rsp+0xE0]
000076b67a9d3697  add rsp, 0xF0
000076b67a9d369e  pop r11
000076b67a9d36a0  pop r10
000076b67a9d36a2  pop r9
000076b67a9d36a4  pop r8
000076b67a9d36a6  pop rsi
000076b67a9d36a7  pop rdi
000076b67a9d36a8  pop rdx
000076b67a9d36a9  pop rcx
000076b67a9d36aa  pop rax
000076b67a9d36ab  add rsp, 0x08
000076b67a9d36af  jmp 0x000076B67A9CFF19
000076b67a9d36b4  sub rsp, 0x08
000076b67a9d36b8  push rax
000076b67a9d36b9  push rcx
000076b67a9d36ba  push rdx
000076b67a9d36bb  push rdi
000076b67a9d36bc  push rsi
000076b67a9d36bd  push r8
000076b67a9d36bf  push r9
000076b67a9d36c1  push r10
000076b67a9d36c3  push r11
000076b67a9d36c5  sub rsp, 0xF0
000076b67a9d36cc  vmovaps [rsp], xmm0
000076b67a9d36d1  vmovaps [rsp+0x10], xmm1
000076b67a9d36d7  vmovaps [rsp+0x20], xmm2
000076b67a9d36dd  vmovaps [rsp+0x30], xmm3
000076b67a9d36e3  vmovaps [rsp+0x40], xmm4
000076b67a9d36e9  vmovaps [rsp+0x50], xmm5
000076b67a9d36ef  vmovaps [rsp+0x60], xmm6
000076b67a9d36f5  vmovaps [rsp+0x70], xmm7
000076b67a9d36fb  vmovaps [rsp+0x80], xmm8
000076b67a9d3704  vmovaps [rsp+0x90], xmm9
000076b67a9d370d  vmovaps [rsp+0xA0], xmm10
000076b67a9d3716  vmovaps [rsp+0xB0], xmm11
000076b67a9d371f  vmovaps [rsp+0xC0], xmm13
000076b67a9d3728  vmovaps [rsp+0xD0], xmm14
000076b67a9d3731  vmovaps [rsp+0xE0], xmm15
000076b67a9d373a  sub rsp, 0x30
000076b67a9d373e  movaps [rsp], xmm12
000076b67a9d3743  movaps [rsp+0x10], xmm15
000076b67a9d3749  movaps [rsp+0x20], xmm13
000076b67a9d374f  lea rdi, [rsp]
000076b67a9d3753  mov esi, 0x00
000076b67a9d3758  mov rax, 0x63C5EF2DF530
000076b67a9d3762  call rax
000076b67a9d3764  movaps xmm12, [rsp]
000076b67a9d3769  add rsp, 0x30
000076b67a9d376d  vmovaps xmm0, [rsp]
000076b67a9d3772  vmovaps xmm1, [rsp+0x10]
000076b67a9d3778  vmovaps xmm2, [rsp+0x20]
000076b67a9d377e  vmovaps xmm3, [rsp+0x30]
000076b67a9d3784  vmovaps xmm4, [rsp+0x40]
000076b67a9d378a  vmovaps xmm5, [rsp+0x50]
000076b67a9d3790  vmovaps xmm6, [rsp+0x60]
000076b67a9d3796  vmovaps xmm7, [rsp+0x70]
000076b67a9d379c  vmovaps xmm8, [rsp+0x80]
000076b67a9d37a5  vmovaps xmm9, [rsp+0x90]
000076b67a9d37ae  vmovaps xmm10, [rsp+0xA0]
000076b67a9d37b7  vmovaps xmm11, [rsp+0xB0]
000076b67a9d37c0  vmovaps xmm13, [rsp+0xC0]
000076b67a9d37c9  vmovaps xmm14, [rsp+0xD0]
000076b67a9d37d2  vmovaps xmm15, [rsp+0xE0]
000076b67a9d37db  add rsp, 0xF0
000076b67a9d37e2  pop r11
000076b67a9d37e4  pop r10
000076b67a9d37e6  pop r9
000076b67a9d37e8  pop r8
000076b67a9d37ea  pop rsi
000076b67a9d37eb  pop rdi
000076b67a9d37ec  pop rdx
000076b67a9d37ed  pop rcx
000076b67a9d37ee  pop rax
000076b67a9d37ef  add rsp, 0x08
000076b67a9d37f3  jmp 0x000076B67A9CFF34
000076b67a9d37f8  sub rsp, 0x08
000076b67a9d37fc  push rax
000076b67a9d37fd  push rcx
000076b67a9d37fe  push rdx
000076b67a9d37ff  push rdi
000076b67a9d3800  push rsi
000076b67a9d3801  push r8
000076b67a9d3803  push r9
000076b67a9d3805  push r10
000076b67a9d3807  push r11
000076b67a9d3809  sub rsp, 0xF0
000076b67a9d3810  vmovaps [rsp], xmm0
000076b67a9d3815  vmovaps [rsp+0x10], xmm1
000076b67a9d381b  vmovaps [rsp+0x20], xmm2
000076b67a9d3821  vmovaps [rsp+0x30], xmm3
000076b67a9d3827  vmovaps [rsp+0x40], xmm4
000076b67a9d382d  vmovaps [rsp+0x50], xmm5
000076b67a9d3833  vmovaps [rsp+0x60], xmm6
000076b67a9d3839  vmovaps [rsp+0x70], xmm7
000076b67a9d383f  vmovaps [rsp+0x80], xmm8
000076b67a9d3848  vmovaps [rsp+0x90], xmm9
000076b67a9d3851  vmovaps [rsp+0xA0], xmm10
000076b67a9d385a  vmovaps [rsp+0xB0], xmm11
000076b67a9d3863  vmovaps [rsp+0xC0], xmm12
000076b67a9d386c  vmovaps [rsp+0xD0], xmm13
000076b67a9d3875  vmovaps [rsp+0xE0], xmm14
000076b67a9d387e  sub rsp, 0x30
000076b67a9d3882  movaps [rsp], xmm15
000076b67a9d3887  movaps [rsp+0x10], xmm13
000076b67a9d388d  movaps [rsp+0x20], xmm10
000076b67a9d3893  lea rdi, [rsp]
000076b67a9d3897  mov esi, 0x00
000076b67a9d389c  mov rax, 0x63C5EF2DF530
000076b67a9d38a6  call rax
000076b67a9d38a8  movaps xmm15, [rsp]
000076b67a9d38ad  add rsp, 0x30
000076b67a9d38b1  vmovaps xmm0, [rsp]
000076b67a9d38b6  vmovaps xmm1, [rsp+0x10]
000076b67a9d38bc  vmovaps xmm2, [rsp+0x20]
000076b67a9d38c2  vmovaps xmm3, [rsp+0x30]
000076b67a9d38c8  vmovaps xmm4, [rsp+0x40]
000076b67a9d38ce  vmovaps xmm5, [rsp+0x50]
000076b67a9d38d4  vmovaps xmm6, [rsp+0x60]
000076b67a9d38da  vmovaps xmm7, [rsp+0x70]
000076b67a9d38e0  vmovaps xmm8, [rsp+0x80]
000076b67a9d38e9  vmovaps xmm9, [rsp+0x90]
000076b67a9d38f2  vmovaps xmm10, [rsp+0xA0]
000076b67a9d38fb  vmovaps xmm11, [rsp+0xB0]
000076b67a9d3904  vmovaps xmm12, [rsp+0xC0]
000076b67a9d390d  vmovaps xmm13, [rsp+0xD0]
000076b67a9d3916  vmovaps xmm14, [rsp+0xE0]
000076b67a9d391f  add rsp, 0xF0
000076b67a9d3926  pop r11
000076b67a9d3928  pop r10
000076b67a9d392a  pop r9
000076b67a9d392c  pop r8
000076b67a9d392e  pop rsi
000076b67a9d392f  pop rdi
000076b67a9d3930  pop rdx
000076b67a9d3931  pop rcx
000076b67a9d3932  pop rax
000076b67a9d3933  add rsp, 0x08
000076b67a9d3937  jmp 0x000076B67A9CFF55
000076b67a9d393c  call 0x000076B67A80C260
000076b67a9d3941  jmp 0x000076B67A9CFFB0
000076b67a9d3946  sub rsp, 0x08
000076b67a9d394a  push rax
000076b67a9d394b  push rcx
000076b67a9d394c  push rdx
000076b67a9d394d  push rdi
000076b67a9d394e  push rsi
000076b67a9d394f  push r8
000076b67a9d3951  push r9
000076b67a9d3953  push r10
000076b67a9d3955  push r11
000076b67a9d3957  sub rsp, 0xF0
000076b67a9d395e  vmovaps [rsp], xmm0
000076b67a9d3963  vmovaps [rsp+0x10], xmm1
000076b67a9d3969  vmovaps [rsp+0x20], xmm2
000076b67a9d396f  vmovaps [rsp+0x30], xmm3
000076b67a9d3975  vmovaps [rsp+0x40], xmm4
000076b67a9d397b  vmovaps [rsp+0x50], xmm5
000076b67a9d3981  vmovaps [rsp+0x60], xmm6
000076b67a9d3987  vmovaps [rsp+0x70], xmm7
000076b67a9d398d  vmovaps [rsp+0x80], xmm8
000076b67a9d3996  vmovaps [rsp+0x90], xmm10
000076b67a9d399f  vmovaps [rsp+0xA0], xmm11
000076b67a9d39a8  vmovaps [rsp+0xB0], xmm12
000076b67a9d39b1  vmovaps [rsp+0xC0], xmm13
000076b67a9d39ba  vmovaps [rsp+0xD0], xmm14
000076b67a9d39c3  vmovaps [rsp+0xE0], xmm15
000076b67a9d39cc  sub rsp, 0x30
000076b67a9d39d0  movaps [rsp], xmm9
000076b67a9d39d5  movaps [rsp+0x10], xmm8
000076b67a9d39db  movaps [rsp+0x20], xmm10
000076b67a9d39e1  lea rdi, [rsp]
000076b67a9d39e5  mov esi, 0x00
000076b67a9d39ea  mov rax, 0x63C5EF2DF530
000076b67a9d39f4  call rax
000076b67a9d39f6  movaps xmm9, [rsp]
000076b67a9d39fb  add rsp, 0x30
000076b67a9d39ff  vmovaps xmm0, [rsp]
000076b67a9d3a04  vmovaps xmm1, [rsp+0x10]
000076b67a9d3a0a  vmovaps xmm2, [rsp+0x20]
000076b67a9d3a10  vmovaps xmm3, [rsp+0x30]
000076b67a9d3a16  vmovaps xmm4, [rsp+0x40]
000076b67a9d3a1c  vmovaps xmm5, [rsp+0x50]
000076b67a9d3a22  vmovaps xmm6, [rsp+0x60]
000076b67a9d3a28  vmovaps xmm7, [rsp+0x70]
000076b67a9d3a2e  vmovaps xmm8, [rsp+0x80]
000076b67a9d3a37  vmovaps xmm10, [rsp+0x90]
000076b67a9d3a40  vmovaps xmm11, [rsp+0xA0]
000076b67a9d3a49  vmovaps xmm12, [rsp+0xB0]
000076b67a9d3a52  vmovaps xmm13, [rsp+0xC0]
000076b67a9d3a5b  vmovaps xmm14, [rsp+0xD0]
000076b67a9d3a64  vmovaps xmm15, [rsp+0xE0]
000076b67a9d3a6d  add rsp, 0xF0
000076b67a9d3a74  pop r11
000076b67a9d3a76  pop r10
000076b67a9d3a78  pop r9
000076b67a9d3a7a  pop r8
000076b67a9d3a7c  pop rsi
000076b67a9d3a7d  pop rdi
000076b67a9d3a7e  pop rdx
000076b67a9d3a7f  pop rcx
000076b67a9d3a80  pop rax
000076b67a9d3a81  add rsp, 0x08
000076b67a9d3a85  jmp 0x000076B67A9CFFE1
000076b67a9d3a8a  sub rsp, 0x08
000076b67a9d3a8e  push rax
000076b67a9d3a8f  push rcx
000076b67a9d3a90  push rdx
000076b67a9d3a91  push rdi
000076b67a9d3a92  push rsi
000076b67a9d3a93  push r8
000076b67a9d3a95  push r9
000076b67a9d3a97  push r10
000076b67a9d3a99  push r11
000076b67a9d3a9b  sub rsp, 0xF0
000076b67a9d3aa2  vmovaps [rsp], xmm0
000076b67a9d3aa7  vmovaps [rsp+0x10], xmm1
000076b67a9d3aad  vmovaps [rsp+0x20], xmm2
000076b67a9d3ab3  vmovaps [rsp+0x30], xmm3
000076b67a9d3ab9  vmovaps [rsp+0x40], xmm4
000076b67a9d3abf  vmovaps [rsp+0x50], xmm5
000076b67a9d3ac5  vmovaps [rsp+0x60], xmm6
000076b67a9d3acb  vmovaps [rsp+0x70], xmm7
000076b67a9d3ad1  vmovaps [rsp+0x80], xmm8
000076b67a9d3ada  vmovaps [rsp+0x90], xmm9
000076b67a9d3ae3  vmovaps [rsp+0xA0], xmm11
000076b67a9d3aec  vmovaps [rsp+0xB0], xmm12
000076b67a9d3af5  vmovaps [rsp+0xC0], xmm13
000076b67a9d3afe  vmovaps [rsp+0xD0], xmm14
000076b67a9d3b07  vmovaps [rsp+0xE0], xmm15
000076b67a9d3b10  sub rsp, 0x30
000076b67a9d3b14  movaps [rsp], xmm10
000076b67a9d3b19  movaps [rsp+0x10], xmm1
000076b67a9d3b1e  movaps [rsp+0x20], xmm11
000076b67a9d3b24  lea rdi, [rsp]
000076b67a9d3b28  mov esi, 0x00
000076b67a9d3b2d  mov rax, 0x63C5EF2DF530
000076b67a9d3b37  call rax
000076b67a9d3b39  movaps xmm10, [rsp]
000076b67a9d3b3e  add rsp, 0x30
000076b67a9d3b42  vmovaps xmm0, [rsp]
000076b67a9d3b47  vmovaps xmm1, [rsp+0x10]
000076b67a9d3b4d  vmovaps xmm2, [rsp+0x20]
000076b67a9d3b53  vmovaps xmm3, [rsp+0x30]
000076b67a9d3b59  vmovaps xmm4, [rsp+0x40]
000076b67a9d3b5f  vmovaps xmm5, [rsp+0x50]
000076b67a9d3b65  vmovaps xmm6, [rsp+0x60]
000076b67a9d3b6b  vmovaps xmm7, [rsp+0x70]
000076b67a9d3b71  vmovaps xmm8, [rsp+0x80]
000076b67a9d3b7a  vmovaps xmm9, [rsp+0x90]
000076b67a9d3b83  vmovaps xmm11, [rsp+0xA0]
000076b67a9d3b8c  vmovaps xmm12, [rsp+0xB0]
000076b67a9d3b95  vmovaps xmm13, [rsp+0xC0]
000076b67a9d3b9e  vmovaps xmm14, [rsp+0xD0]
000076b67a9d3ba7  vmovaps xmm15, [rsp+0xE0]
000076b67a9d3bb0  add rsp, 0xF0
000076b67a9d3bb7  pop r11
000076b67a9d3bb9  pop r10
000076b67a9d3bbb  pop r9
000076b67a9d3bbd  pop r8
000076b67a9d3bbf  pop rsi
000076b67a9d3bc0  pop rdi
000076b67a9d3bc1  pop rdx
000076b67a9d3bc2  pop rcx
000076b67a9d3bc3  pop rax
000076b67a9d3bc4  add rsp, 0x08
000076b67a9d3bc8  jmp 0x000076B67A9CFFFC
000076b67a9d3bcd  sub rsp, 0x08
000076b67a9d3bd1  push rax
000076b67a9d3bd2  push rcx
000076b67a9d3bd3  push rdx
000076b67a9d3bd4  push rdi
000076b67a9d3bd5  push rsi
000076b67a9d3bd6  push r8
000076b67a9d3bd8  push r9
000076b67a9d3bda  push r10
000076b67a9d3bdc  push r11
000076b67a9d3bde  sub rsp, 0xF0
000076b67a9d3be5  vmovaps [rsp], xmm0
000076b67a9d3bea  vmovaps [rsp+0x10], xmm2
000076b67a9d3bf0  vmovaps [rsp+0x20], xmm3
000076b67a9d3bf6  vmovaps [rsp+0x30], xmm4
000076b67a9d3bfc  vmovaps [rsp+0x40], xmm5
000076b67a9d3c02  vmovaps [rsp+0x50], xmm6
000076b67a9d3c08  vmovaps [rsp+0x60], xmm7
000076b67a9d3c0e  vmovaps [rsp+0x70], xmm8
000076b67a9d3c14  vmovaps [rsp+0x80], xmm9
000076b67a9d3c1d  vmovaps [rsp+0x90], xmm10
000076b67a9d3c26  vmovaps [rsp+0xA0], xmm11
000076b67a9d3c2f  vmovaps [rsp+0xB0], xmm12
000076b67a9d3c38  vmovaps [rsp+0xC0], xmm13
000076b67a9d3c41  vmovaps [rsp+0xD0], xmm14
000076b67a9d3c4a  vmovaps [rsp+0xE0], xmm15
000076b67a9d3c53  sub rsp, 0x30
000076b67a9d3c57  movaps [rsp], xmm1
000076b67a9d3c5b  movaps [rsp+0x10], xmm14
000076b67a9d3c61  movaps [rsp+0x20], xmm6
000076b67a9d3c66  lea rdi, [rsp]
000076b67a9d3c6a  mov esi, 0x00
000076b67a9d3c6f  mov rax, 0x63C5EF2DF530
000076b67a9d3c79  call rax
000076b67a9d3c7b  movaps xmm1, [rsp]
000076b67a9d3c7f  add rsp, 0x30
000076b67a9d3c83  vmovaps xmm0, [rsp]
000076b67a9d3c88  vmovaps xmm2, [rsp+0x10]
000076b67a9d3c8e  vmovaps xmm3, [rsp+0x20]
000076b67a9d3c94  vmovaps xmm4, [rsp+0x30]
000076b67a9d3c9a  vmovaps xmm5, [rsp+0x40]
000076b67a9d3ca0  vmovaps xmm6, [rsp+0x50]
000076b67a9d3ca6  vmovaps xmm7, [rsp+0x60]
000076b67a9d3cac  vmovaps xmm8, [rsp+0x70]
000076b67a9d3cb2  vmovaps xmm9, [rsp+0x80]
000076b67a9d3cbb  vmovaps xmm10, [rsp+0x90]
000076b67a9d3cc4  vmovaps xmm11, [rsp+0xA0]
000076b67a9d3ccd  vmovaps xmm12, [rsp+0xB0]
000076b67a9d3cd6  vmovaps xmm13, [rsp+0xC0]
000076b67a9d3cdf  vmovaps xmm14, [rsp+0xD0]
000076b67a9d3ce8  vmovaps xmm15, [rsp+0xE0]
000076b67a9d3cf1  add rsp, 0xF0
000076b67a9d3cf8  pop r11
000076b67a9d3cfa  pop r10
000076b67a9d3cfc  pop r9
000076b67a9d3cfe  pop r8
000076b67a9d3d00  pop rsi
000076b67a9d3d01  pop rdi
000076b67a9d3d02  pop rdx
000076b67a9d3d03  pop rcx
000076b67a9d3d04  pop rax
000076b67a9d3d05  add rsp, 0x08
000076b67a9d3d09  jmp 0x000076B67A9D0015
000076b67a9d3d0e  sub rsp, 0x08
000076b67a9d3d12  push rax
000076b67a9d3d13  push rcx
000076b67a9d3d14  push rdx
000076b67a9d3d15  push rdi
000076b67a9d3d16  push rsi
000076b67a9d3d17  push r8
000076b67a9d3d19  push r9
000076b67a9d3d1b  push r10
000076b67a9d3d1d  push r11
000076b67a9d3d1f  sub rsp, 0xF0
000076b67a9d3d26  vmovaps [rsp], xmm0
000076b67a9d3d2b  vmovaps [rsp+0x10], xmm1
000076b67a9d3d31  vmovaps [rsp+0x20], xmm2
000076b67a9d3d37  vmovaps [rsp+0x30], xmm3
000076b67a9d3d3d  vmovaps [rsp+0x40], xmm4
000076b67a9d3d43  vmovaps [rsp+0x50], xmm5
000076b67a9d3d49  vmovaps [rsp+0x60], xmm6
000076b67a9d3d4f  vmovaps [rsp+0x70], xmm7
000076b67a9d3d55  vmovaps [rsp+0x80], xmm8
000076b67a9d3d5e  vmovaps [rsp+0x90], xmm9
000076b67a9d3d67  vmovaps [rsp+0xA0], xmm10
000076b67a9d3d70  vmovaps [rsp+0xB0], xmm12
000076b67a9d3d79  vmovaps [rsp+0xC0], xmm13
000076b67a9d3d82  vmovaps [rsp+0xD0], xmm14
000076b67a9d3d8b  vmovaps [rsp+0xE0], xmm15
000076b67a9d3d94  sub rsp, 0x30
000076b67a9d3d98  movaps [rsp], xmm11
000076b67a9d3d9d  movaps [rsp+0x10], xmm13
000076b67a9d3da3  movaps [rsp+0x20], xmm14
000076b67a9d3da9  lea rdi, [rsp]
000076b67a9d3dad  mov esi, 0x00
000076b67a9d3db2  mov rax, 0x63C5EF2DF530
000076b67a9d3dbc  call rax
000076b67a9d3dbe  movaps xmm11, [rsp]
000076b67a9d3dc3  add rsp, 0x30
000076b67a9d3dc7  vmovaps xmm0, [rsp]
000076b67a9d3dcc  vmovaps xmm1, [rsp+0x10]
000076b67a9d3dd2  vmovaps xmm2, [rsp+0x20]
000076b67a9d3dd8  vmovaps xmm3, [rsp+0x30]
000076b67a9d3dde  vmovaps xmm4, [rsp+0x40]
000076b67a9d3de4  vmovaps xmm5, [rsp+0x50]
000076b67a9d3dea  vmovaps xmm6, [rsp+0x60]
000076b67a9d3df0  vmovaps xmm7, [rsp+0x70]
000076b67a9d3df6  vmovaps xmm8, [rsp+0x80]
000076b67a9d3dff  vmovaps xmm9, [rsp+0x90]
000076b67a9d3e08  vmovaps xmm10, [rsp+0xA0]
000076b67a9d3e11  vmovaps xmm12, [rsp+0xB0]
000076b67a9d3e1a  vmovaps xmm13, [rsp+0xC0]
000076b67a9d3e23  vmovaps xmm14, [rsp+0xD0]
000076b67a9d3e2c  vmovaps xmm15, [rsp+0xE0]
000076b67a9d3e35  add rsp, 0xF0
000076b67a9d3e3c  pop r11
000076b67a9d3e3e  pop r10
000076b67a9d3e40  pop r9
000076b67a9d3e42  pop r8
000076b67a9d3e44  pop rsi
000076b67a9d3e45  pop rdi
000076b67a9d3e46  pop rdx
000076b67a9d3e47  pop rcx
000076b67a9d3e48  pop rax
000076b67a9d3e49  add rsp, 0x08
000076b67a9d3e4d  jmp 0x000076B67A9D003F
000076b67a9d3e52  sub rsp, 0x08
000076b67a9d3e56  push rax
000076b67a9d3e57  push rcx
000076b67a9d3e58  push rdx
000076b67a9d3e59  push rdi
000076b67a9d3e5a  push rsi
000076b67a9d3e5b  push r8
000076b67a9d3e5d  push r9
000076b67a9d3e5f  push r10
000076b67a9d3e61  push r11
000076b67a9d3e63  sub rsp, 0xF0
000076b67a9d3e6a  vmovaps [rsp], xmm0
000076b67a9d3e6f  vmovaps [rsp+0x10], xmm1
000076b67a9d3e75  vmovaps [rsp+0x20], xmm2
000076b67a9d3e7b  vmovaps [rsp+0x30], xmm3
000076b67a9d3e81  vmovaps [rsp+0x40], xmm4
000076b67a9d3e87  vmovaps [rsp+0x50], xmm5
000076b67a9d3e8d  vmovaps [rsp+0x60], xmm6
000076b67a9d3e93  vmovaps [rsp+0x70], xmm7
000076b67a9d3e99  vmovaps [rsp+0x80], xmm8
000076b67a9d3ea2  vmovaps [rsp+0x90], xmm9
000076b67a9d3eab  vmovaps [rsp+0xA0], xmm10
000076b67a9d3eb4  vmovaps [rsp+0xB0], xmm11
000076b67a9d3ebd  vmovaps [rsp+0xC0], xmm12
000076b67a9d3ec6  vmovaps [rsp+0xD0], xmm14
000076b67a9d3ecf  vmovaps [rsp+0xE0], xmm15
000076b67a9d3ed8  sub rsp, 0x30
000076b67a9d3edc  movaps [rsp], xmm13
000076b67a9d3ee1  movaps [rsp+0x10], xmm8
000076b67a9d3ee7  movaps [rsp+0x20], xmm14
000076b67a9d3eed  lea rdi, [rsp]
000076b67a9d3ef1  mov esi, 0x00
000076b67a9d3ef6  mov rax, 0x63C5EF2DF530
000076b67a9d3f00  call rax
000076b67a9d3f02  movaps xmm13, [rsp]
000076b67a9d3f07  add rsp, 0x30
000076b67a9d3f0b  vmovaps xmm0, [rsp]
000076b67a9d3f10  vmovaps xmm1, [rsp+0x10]
000076b67a9d3f16  vmovaps xmm2, [rsp+0x20]
000076b67a9d3f1c  vmovaps xmm3, [rsp+0x30]
000076b67a9d3f22  vmovaps xmm4, [rsp+0x40]
000076b67a9d3f28  vmovaps xmm5, [rsp+0x50]
000076b67a9d3f2e  vmovaps xmm6, [rsp+0x60]
000076b67a9d3f34  vmovaps xmm7, [rsp+0x70]
000076b67a9d3f3a  vmovaps xmm8, [rsp+0x80]
000076b67a9d3f43  vmovaps xmm9, [rsp+0x90]
000076b67a9d3f4c  vmovaps xmm10, [rsp+0xA0]
000076b67a9d3f55  vmovaps xmm11, [rsp+0xB0]
000076b67a9d3f5e  vmovaps xmm12, [rsp+0xC0]
000076b67a9d3f67  vmovaps xmm14, [rsp+0xD0]
000076b67a9d3f70  vmovaps xmm15, [rsp+0xE0]
000076b67a9d3f79  add rsp, 0xF0
000076b67a9d3f80  pop r11
000076b67a9d3f82  pop r10
000076b67a9d3f84  pop r9
000076b67a9d3f86  pop r8
000076b67a9d3f88  pop rsi
000076b67a9d3f89  pop rdi
000076b67a9d3f8a  pop rdx
000076b67a9d3f8b  pop rcx
000076b67a9d3f8c  pop rax
000076b67a9d3f8d  add rsp, 0x08
000076b67a9d3f91  jmp 0x000076B67A9D006E
000076b67a9d3f96  sub rsp, 0x08
000076b67a9d3f9a  push rax
000076b67a9d3f9b  push rcx
000076b67a9d3f9c  push rdx
000076b67a9d3f9d  push rdi
000076b67a9d3f9e  push rsi
000076b67a9d3f9f  push r8
000076b67a9d3fa1  push r9
000076b67a9d3fa3  push r10
000076b67a9d3fa5  push r11
000076b67a9d3fa7  sub rsp, 0xF0
000076b67a9d3fae  vmovaps [rsp], xmm0
000076b67a9d3fb3  vmovaps [rsp+0x10], xmm1
000076b67a9d3fb9  vmovaps [rsp+0x20], xmm2
000076b67a9d3fbf  vmovaps [rsp+0x30], xmm3
000076b67a9d3fc5  vmovaps [rsp+0x40], xmm4
000076b67a9d3fcb  vmovaps [rsp+0x50], xmm5
000076b67a9d3fd1  vmovaps [rsp+0x60], xmm6
000076b67a9d3fd7  vmovaps [rsp+0x70], xmm7
000076b67a9d3fdd  vmovaps [rsp+0x80], xmm9
000076b67a9d3fe6  vmovaps [rsp+0x90], xmm10
000076b67a9d3fef  vmovaps [rsp+0xA0], xmm11
000076b67a9d3ff8  vmovaps [rsp+0xB0], xmm12
000076b67a9d4001  vmovaps [rsp+0xC0], xmm13
000076b67a9d400a  vmovaps [rsp+0xD0], xmm14
000076b67a9d4013  vmovaps [rsp+0xE0], xmm15
000076b67a9d401c  sub rsp, 0x30
000076b67a9d4020  movaps [rsp], xmm8
000076b67a9d4025  movaps [rsp+0x10], xmm7
000076b67a9d402a  movaps [rsp+0x20], xmm14
000076b67a9d4030  lea rdi, [rsp]
000076b67a9d4034  mov esi, 0x00
000076b67a9d4039  mov rax, 0x63C5EF2DF530
000076b67a9d4043  call rax
000076b67a9d4045  movaps xmm8, [rsp]
000076b67a9d404a  add rsp, 0x30
000076b67a9d404e  vmovaps xmm0, [rsp]
000076b67a9d4053  vmovaps xmm1, [rsp+0x10]
000076b67a9d4059  vmovaps xmm2, [rsp+0x20]
000076b67a9d405f  vmovaps xmm3, [rsp+0x30]
000076b67a9d4065  vmovaps xmm4, [rsp+0x40]
000076b67a9d406b  vmovaps xmm5, [rsp+0x50]
000076b67a9d4071  vmovaps xmm6, [rsp+0x60]
000076b67a9d4077  vmovaps xmm7, [rsp+0x70]
000076b67a9d407d  vmovaps xmm9, [rsp+0x80]
000076b67a9d4086  vmovaps xmm10, [rsp+0x90]
000076b67a9d408f  vmovaps xmm11, [rsp+0xA0]
000076b67a9d4098  vmovaps xmm12, [rsp+0xB0]
000076b67a9d40a1  vmovaps xmm13, [rsp+0xC0]
000076b67a9d40aa  vmovaps xmm14, [rsp+0xD0]
000076b67a9d40b3  vmovaps xmm15, [rsp+0xE0]
000076b67a9d40bc  add rsp, 0xF0
000076b67a9d40c3  pop r11
000076b67a9d40c5  pop r10
000076b67a9d40c7  pop r9
000076b67a9d40c9  pop r8
000076b67a9d40cb  pop rsi
000076b67a9d40cc  pop rdi
000076b67a9d40cd  pop rdx
000076b67a9d40ce  pop rcx
000076b67a9d40cf  pop rax
000076b67a9d40d0  add rsp, 0x08
000076b67a9d40d4  jmp 0x000076B67A9D0094
000076b67a9d40d9  sub rsp, 0x08
000076b67a9d40dd  push rax
000076b67a9d40de  push rcx
000076b67a9d40df  push rdx
000076b67a9d40e0  push rdi
000076b67a9d40e1  push rsi
000076b67a9d40e2  push r8
000076b67a9d40e4  push r9
000076b67a9d40e6  push r10
000076b67a9d40e8  push r11
000076b67a9d40ea  sub rsp, 0xF0
000076b67a9d40f1  vmovaps [rsp], xmm0
000076b67a9d40f6  vmovaps [rsp+0x10], xmm1
000076b67a9d40fc  vmovaps [rsp+0x20], xmm2
000076b67a9d4102  vmovaps [rsp+0x30], xmm3
000076b67a9d4108  vmovaps [rsp+0x40], xmm4
000076b67a9d410e  vmovaps [rsp+0x50], xmm5
000076b67a9d4114  vmovaps [rsp+0x60], xmm6
000076b67a9d411a  vmovaps [rsp+0x70], xmm7
000076b67a9d4120  vmovaps [rsp+0x80], xmm8
000076b67a9d4129  vmovaps [rsp+0x90], xmm9
000076b67a9d4132  vmovaps [rsp+0xA0], xmm10
000076b67a9d413b  vmovaps [rsp+0xB0], xmm11
000076b67a9d4144  vmovaps [rsp+0xC0], xmm12
000076b67a9d414d  vmovaps [rsp+0xD0], xmm13
000076b67a9d4156  vmovaps [rsp+0xE0], xmm15
000076b67a9d415f  sub rsp, 0x30
000076b67a9d4163  movaps [rsp], xmm14
000076b67a9d4168  movaps [rsp+0x10], xmm12
000076b67a9d416e  movaps [rsp+0x20], xmm9
000076b67a9d4174  lea rdi, [rsp]
000076b67a9d4178  mov esi, 0x00
000076b67a9d417d  mov rax, 0x63C5EF2DF530
000076b67a9d4187  call rax
000076b67a9d4189  movaps xmm14, [rsp]
000076b67a9d418e  add rsp, 0x30
000076b67a9d4192  vmovaps xmm0, [rsp]
000076b67a9d4197  vmovaps xmm1, [rsp+0x10]
000076b67a9d419d  vmovaps xmm2, [rsp+0x20]
000076b67a9d41a3  vmovaps xmm3, [rsp+0x30]
000076b67a9d41a9  vmovaps xmm4, [rsp+0x40]
000076b67a9d41af  vmovaps xmm5, [rsp+0x50]
000076b67a9d41b5  vmovaps xmm6, [rsp+0x60]
000076b67a9d41bb  vmovaps xmm7, [rsp+0x70]
000076b67a9d41c1  vmovaps xmm8, [rsp+0x80]
000076b67a9d41ca  vmovaps xmm9, [rsp+0x90]
000076b67a9d41d3  vmovaps xmm10, [rsp+0xA0]
000076b67a9d41dc  vmovaps xmm11, [rsp+0xB0]
000076b67a9d41e5  vmovaps xmm12, [rsp+0xC0]
000076b67a9d41ee  vmovaps xmm13, [rsp+0xD0]
000076b67a9d41f7  vmovaps xmm15, [rsp+0xE0]
000076b67a9d4200  add rsp, 0xF0
000076b67a9d4207  pop r11
000076b67a9d4209  pop r10
000076b67a9d420b  pop r9
000076b67a9d420d  pop r8
000076b67a9d420f  pop rsi
000076b67a9d4210  pop rdi
000076b67a9d4211  pop rdx
000076b67a9d4212  pop rcx
000076b67a9d4213  pop rax
000076b67a9d4214  add rsp, 0x08
000076b67a9d4218  jmp 0x000076B67A9D00AE
000076b67a9d421d  sub rsp, 0x08
000076b67a9d4221  push rax
000076b67a9d4222  push rcx
000076b67a9d4223  push rdx
000076b67a9d4224  push rdi
000076b67a9d4225  push rsi
000076b67a9d4226  push r8
000076b67a9d4228  push r9
000076b67a9d422a  push r10
000076b67a9d422c  push r11
000076b67a9d422e  sub rsp, 0xF0
000076b67a9d4235  vmovaps [rsp], xmm0
000076b67a9d423a  vmovaps [rsp+0x10], xmm1
000076b67a9d4240  vmovaps [rsp+0x20], xmm2
000076b67a9d4246  vmovaps [rsp+0x30], xmm3
000076b67a9d424c  vmovaps [rsp+0x40], xmm4
000076b67a9d4252  vmovaps [rsp+0x50], xmm5
000076b67a9d4258  vmovaps [rsp+0x60], xmm6
000076b67a9d425e  vmovaps [rsp+0x70], xmm7
000076b67a9d4264  vmovaps [rsp+0x80], xmm8
000076b67a9d426d  vmovaps [rsp+0x90], xmm10
000076b67a9d4276  vmovaps [rsp+0xA0], xmm11
000076b67a9d427f  vmovaps [rsp+0xB0], xmm12
000076b67a9d4288  vmovaps [rsp+0xC0], xmm13
000076b67a9d4291  vmovaps [rsp+0xD0], xmm14
000076b67a9d429a  vmovaps [rsp+0xE0], xmm15
000076b67a9d42a3  sub rsp, 0x30
000076b67a9d42a7  movaps [rsp], xmm9
000076b67a9d42ac  movaps [rsp+0x10], xmm7
000076b67a9d42b1  movaps [rsp+0x20], xmm12
000076b67a9d42b7  lea rdi, [rsp]
000076b67a9d42bb  mov esi, 0x00
000076b67a9d42c0  mov rax, 0x63C5EF2DF530
000076b67a9d42ca  call rax
000076b67a9d42cc  movaps xmm9, [rsp]
000076b67a9d42d1  add rsp, 0x30
000076b67a9d42d5  vmovaps xmm0, [rsp]
000076b67a9d42da  vmovaps xmm1, [rsp+0x10]
000076b67a9d42e0  vmovaps xmm2, [rsp+0x20]
000076b67a9d42e6  vmovaps xmm3, [rsp+0x30]
000076b67a9d42ec  vmovaps xmm4, [rsp+0x40]
000076b67a9d42f2  vmovaps xmm5, [rsp+0x50]
000076b67a9d42f8  vmovaps xmm6, [rsp+0x60]
000076b67a9d42fe  vmovaps xmm7, [rsp+0x70]
000076b67a9d4304  vmovaps xmm8, [rsp+0x80]
000076b67a9d430d  vmovaps xmm10, [rsp+0x90]
000076b67a9d4316  vmovaps xmm11, [rsp+0xA0]
000076b67a9d431f  vmovaps xmm12, [rsp+0xB0]
000076b67a9d4328  vmovaps xmm13, [rsp+0xC0]
000076b67a9d4331  vmovaps xmm14, [rsp+0xD0]
000076b67a9d433a  vmovaps xmm15, [rsp+0xE0]
000076b67a9d4343  add rsp, 0xF0
000076b67a9d434a  pop r11
000076b67a9d434c  pop r10
000076b67a9d434e  pop r9
000076b67a9d4350  pop r8
000076b67a9d4352  pop rsi
000076b67a9d4353  pop rdi
000076b67a9d4354  pop rdx
000076b67a9d4355  pop rcx
000076b67a9d4356  pop rax
000076b67a9d4357  add rsp, 0x08
000076b67a9d435b  jmp 0x000076B67A9D00DD
000076b67a9d4360  sub rsp, 0x08
000076b67a9d4364  push rax
000076b67a9d4365  push rcx
000076b67a9d4366  push rdx
000076b67a9d4367  push rdi
000076b67a9d4368  push rsi
000076b67a9d4369  push r8
000076b67a9d436b  push r9
000076b67a9d436d  push r10
000076b67a9d436f  push r11
000076b67a9d4371  sub rsp, 0xF0
000076b67a9d4378  vmovaps [rsp], xmm0
000076b67a9d437d  vmovaps [rsp+0x10], xmm1
000076b67a9d4383  vmovaps [rsp+0x20], xmm2
000076b67a9d4389  vmovaps [rsp+0x30], xmm3
000076b67a9d438f  vmovaps [rsp+0x40], xmm4
000076b67a9d4395  vmovaps [rsp+0x50], xmm5
000076b67a9d439b  vmovaps [rsp+0x60], xmm6
000076b67a9d43a1  vmovaps [rsp+0x70], xmm7
000076b67a9d43a7  vmovaps [rsp+0x80], xmm8
000076b67a9d43b0  vmovaps [rsp+0x90], xmm9
000076b67a9d43b9  vmovaps [rsp+0xA0], xmm10
000076b67a9d43c2  vmovaps [rsp+0xB0], xmm11
000076b67a9d43cb  vmovaps [rsp+0xC0], xmm13
000076b67a9d43d4  vmovaps [rsp+0xD0], xmm14
000076b67a9d43dd  vmovaps [rsp+0xE0], xmm15
000076b67a9d43e6  sub rsp, 0x30
000076b67a9d43ea  movaps [rsp], xmm12
000076b67a9d43ef  movaps [rsp+0x10], xmm15
000076b67a9d43f5  movaps [rsp+0x20], xmm11
000076b67a9d43fb  lea rdi, [rsp]
000076b67a9d43ff  mov esi, 0x00
000076b67a9d4404  mov rax, 0x63C5EF2DF530
000076b67a9d440e  call rax
000076b67a9d4410  movaps xmm12, [rsp]
000076b67a9d4415  add rsp, 0x30
000076b67a9d4419  vmovaps xmm0, [rsp]
000076b67a9d441e  vmovaps xmm1, [rsp+0x10]
000076b67a9d4424  vmovaps xmm2, [rsp+0x20]
000076b67a9d442a  vmovaps xmm3, [rsp+0x30]
000076b67a9d4430  vmovaps xmm4, [rsp+0x40]
000076b67a9d4436  vmovaps xmm5, [rsp+0x50]
000076b67a9d443c  vmovaps xmm6, [rsp+0x60]
000076b67a9d4442  vmovaps xmm7, [rsp+0x70]
000076b67a9d4448  vmovaps xmm8, [rsp+0x80]
000076b67a9d4451  vmovaps xmm9, [rsp+0x90]
000076b67a9d445a  vmovaps xmm10, [rsp+0xA0]
000076b67a9d4463  vmovaps xmm11, [rsp+0xB0]
000076b67a9d446c  vmovaps xmm13, [rsp+0xC0]
000076b67a9d4475  vmovaps xmm14, [rsp+0xD0]
000076b67a9d447e  vmovaps xmm15, [rsp+0xE0]
000076b67a9d4487  add rsp, 0xF0
000076b67a9d448e  pop r11
000076b67a9d4490  pop r10
000076b67a9d4492  pop r9
000076b67a9d4494  pop r8
000076b67a9d4496  pop rsi
000076b67a9d4497  pop rdi
000076b67a9d4498  pop rdx
000076b67a9d4499  pop rcx
000076b67a9d449a  pop rax
000076b67a9d449b  add rsp, 0x08
000076b67a9d449f  jmp 0x000076B67A9D00F7
000076b67a9d44a4  sub rsp, 0x08
000076b67a9d44a8  push rax
000076b67a9d44a9  push rcx
000076b67a9d44aa  push rdx
000076b67a9d44ab  push rdi
000076b67a9d44ac  push rsi
000076b67a9d44ad  push r8
000076b67a9d44af  push r9
000076b67a9d44b1  push r10
000076b67a9d44b3  push r11
000076b67a9d44b5  sub rsp, 0xF0
000076b67a9d44bc  vmovaps [rsp], xmm0
000076b67a9d44c1  vmovaps [rsp+0x10], xmm1
000076b67a9d44c7  vmovaps [rsp+0x20], xmm2
000076b67a9d44cd  vmovaps [rsp+0x30], xmm3
000076b67a9d44d3  vmovaps [rsp+0x40], xmm4
000076b67a9d44d9  vmovaps [rsp+0x50], xmm5
000076b67a9d44df  vmovaps [rsp+0x60], xmm6
000076b67a9d44e5  vmovaps [rsp+0x70], xmm7
000076b67a9d44eb  vmovaps [rsp+0x80], xmm8
000076b67a9d44f4  vmovaps [rsp+0x90], xmm9
000076b67a9d44fd  vmovaps [rsp+0xA0], xmm10
000076b67a9d4506  vmovaps [rsp+0xB0], xmm12
000076b67a9d450f  vmovaps [rsp+0xC0], xmm13
000076b67a9d4518  vmovaps [rsp+0xD0], xmm14
000076b67a9d4521  vmovaps [rsp+0xE0], xmm15
000076b67a9d452a  sub rsp, 0x30
000076b67a9d452e  movaps [rsp], xmm11
000076b67a9d4533  movaps [rsp+0x10], xmm7
000076b67a9d4538  movaps [rsp+0x20], xmm15
000076b67a9d453e  lea rdi, [rsp]
000076b67a9d4542  mov esi, 0x00
000076b67a9d4547  mov rax, 0x63C5EF2DF530
000076b67a9d4551  call rax
000076b67a9d4553  movaps xmm11, [rsp]
000076b67a9d4558  add rsp, 0x30
000076b67a9d455c  vmovaps xmm0, [rsp]
000076b67a9d4561  vmovaps xmm1, [rsp+0x10]
000076b67a9d4567  vmovaps xmm2, [rsp+0x20]
000076b67a9d456d  vmovaps xmm3, [rsp+0x30]
000076b67a9d4573  vmovaps xmm4, [rsp+0x40]
000076b67a9d4579  vmovaps xmm5, [rsp+0x50]
000076b67a9d457f  vmovaps xmm6, [rsp+0x60]
000076b67a9d4585  vmovaps xmm7, [rsp+0x70]
000076b67a9d458b  vmovaps xmm8, [rsp+0x80]
000076b67a9d4594  vmovaps xmm9, [rsp+0x90]
000076b67a9d459d  vmovaps xmm10, [rsp+0xA0]
000076b67a9d45a6  vmovaps xmm12, [rsp+0xB0]
000076b67a9d45af  vmovaps xmm13, [rsp+0xC0]
000076b67a9d45b8  vmovaps xmm14, [rsp+0xD0]
000076b67a9d45c1  vmovaps xmm15, [rsp+0xE0]
000076b67a9d45ca  add rsp, 0xF0
000076b67a9d45d1  pop r11
000076b67a9d45d3  pop r10
000076b67a9d45d5  pop r9
000076b67a9d45d7  pop r8
000076b67a9d45d9  pop rsi
000076b67a9d45da  pop rdi
000076b67a9d45db  pop rdx
000076b67a9d45dc  pop rcx
000076b67a9d45dd  pop rax
000076b67a9d45de  add rsp, 0x08
000076b67a9d45e2  jmp 0x000076B67A9D0123
000076b67a9d45e7  sub rsp, 0x08
000076b67a9d45eb  push rax
000076b67a9d45ec  push rcx
000076b67a9d45ed  push rdx
000076b67a9d45ee  push rdi
000076b67a9d45ef  push rsi
000076b67a9d45f0  push r8
000076b67a9d45f2  push r9
000076b67a9d45f4  push r10
000076b67a9d45f6  push r11
000076b67a9d45f8  sub rsp, 0xF0
000076b67a9d45ff  vmovaps [rsp], xmm0
000076b67a9d4604  vmovaps [rsp+0x10], xmm1
000076b67a9d460a  vmovaps [rsp+0x20], xmm2
000076b67a9d4610  vmovaps [rsp+0x30], xmm3
000076b67a9d4616  vmovaps [rsp+0x40], xmm4
000076b67a9d461c  vmovaps [rsp+0x50], xmm5
000076b67a9d4622  vmovaps [rsp+0x60], xmm6
000076b67a9d4628  vmovaps [rsp+0x70], xmm7
000076b67a9d462e  vmovaps [rsp+0x80], xmm8
000076b67a9d4637  vmovaps [rsp+0x90], xmm9
000076b67a9d4640  vmovaps [rsp+0xA0], xmm10
000076b67a9d4649  vmovaps [rsp+0xB0], xmm11
000076b67a9d4652  vmovaps [rsp+0xC0], xmm12
000076b67a9d465b  vmovaps [rsp+0xD0], xmm13
000076b67a9d4664  vmovaps [rsp+0xE0], xmm14
000076b67a9d466d  sub rsp, 0x30
000076b67a9d4671  movaps [rsp], xmm15
000076b67a9d4676  movaps [rsp+0x10], xmm10
000076b67a9d467c  movaps [rsp+0x20], xmm13
000076b67a9d4682  lea rdi, [rsp]
000076b67a9d4686  mov esi, 0x00
000076b67a9d468b  mov rax, 0x63C5EF2DF530
000076b67a9d4695  call rax
000076b67a9d4697  movaps xmm15, [rsp]
000076b67a9d469c  add rsp, 0x30
000076b67a9d46a0  vmovaps xmm0, [rsp]
000076b67a9d46a5  vmovaps xmm1, [rsp+0x10]
000076b67a9d46ab  vmovaps xmm2, [rsp+0x20]
000076b67a9d46b1  vmovaps xmm3, [rsp+0x30]
000076b67a9d46b7  vmovaps xmm4, [rsp+0x40]
000076b67a9d46bd  vmovaps xmm5, [rsp+0x50]
000076b67a9d46c3  vmovaps xmm6, [rsp+0x60]
000076b67a9d46c9  vmovaps xmm7, [rsp+0x70]
000076b67a9d46cf  vmovaps xmm8, [rsp+0x80]
000076b67a9d46d8  vmovaps xmm9, [rsp+0x90]
000076b67a9d46e1  vmovaps xmm10, [rsp+0xA0]
000076b67a9d46ea  vmovaps xmm11, [rsp+0xB0]
000076b67a9d46f3  vmovaps xmm12, [rsp+0xC0]
000076b67a9d46fc  vmovaps xmm13, [rsp+0xD0]
000076b67a9d4705  vmovaps xmm14, [rsp+0xE0]
000076b67a9d470e  add rsp, 0xF0
000076b67a9d4715  pop r11
000076b67a9d4717  pop r10
000076b67a9d4719  pop r9
000076b67a9d471b  pop r8
000076b67a9d471d  pop rsi
000076b67a9d471e  pop rdi
000076b67a9d471f  pop rdx
000076b67a9d4720  pop rcx
000076b67a9d4721  pop rax
000076b67a9d4722  add rsp, 0x08
000076b67a9d4726  jmp 0x000076B67A9D013D
000076b67a9d472b  sub rsp, 0x08
000076b67a9d472f  push rax
000076b67a9d4730  push rcx
000076b67a9d4731  push rdx
000076b67a9d4732  push rdi
000076b67a9d4733  push rsi
000076b67a9d4734  push r8
000076b67a9d4736  push r9
000076b67a9d4738  push r10
000076b67a9d473a  push r11
000076b67a9d473c  sub rsp, 0xF0
000076b67a9d4743  vmovaps [rsp], xmm0
000076b67a9d4748  vmovaps [rsp+0x10], xmm1
000076b67a9d474e  vmovaps [rsp+0x20], xmm2
000076b67a9d4754  vmovaps [rsp+0x30], xmm3
000076b67a9d475a  vmovaps [rsp+0x40], xmm4
000076b67a9d4760  vmovaps [rsp+0x50], xmm5
000076b67a9d4766  vmovaps [rsp+0x60], xmm6
000076b67a9d476c  vmovaps [rsp+0x70], xmm7
000076b67a9d4772  vmovaps [rsp+0x80], xmm8
000076b67a9d477b  vmovaps [rsp+0x90], xmm9
000076b67a9d4784  vmovaps [rsp+0xA0], xmm11
000076b67a9d478d  vmovaps [rsp+0xB0], xmm12
000076b67a9d4796  vmovaps [rsp+0xC0], xmm13
000076b67a9d479f  vmovaps [rsp+0xD0], xmm14
000076b67a9d47a8  vmovaps [rsp+0xE0], xmm15
000076b67a9d47b1  sub rsp, 0x30
000076b67a9d47b5  movaps [rsp], xmm10
000076b67a9d47ba  movaps [rsp+0x10], xmm7
000076b67a9d47bf  movaps [rsp+0x20], xmm13
000076b67a9d47c5  lea rdi, [rsp]
000076b67a9d47c9  mov esi, 0x00
000076b67a9d47ce  mov rax, 0x63C5EF2DF530
000076b67a9d47d8  call rax
000076b67a9d47da  movaps xmm10, [rsp]
000076b67a9d47df  add rsp, 0x30
000076b67a9d47e3  vmovaps xmm0, [rsp]
000076b67a9d47e8  vmovaps xmm1, [rsp+0x10]
000076b67a9d47ee  vmovaps xmm2, [rsp+0x20]
000076b67a9d47f4  vmovaps xmm3, [rsp+0x30]
000076b67a9d47fa  vmovaps xmm4, [rsp+0x40]
000076b67a9d4800  vmovaps xmm5, [rsp+0x50]
000076b67a9d4806  vmovaps xmm6, [rsp+0x60]
000076b67a9d480c  vmovaps xmm7, [rsp+0x70]
000076b67a9d4812  vmovaps xmm8, [rsp+0x80]
000076b67a9d481b  vmovaps xmm9, [rsp+0x90]
000076b67a9d4824  vmovaps xmm11, [rsp+0xA0]
000076b67a9d482d  vmovaps xmm12, [rsp+0xB0]
000076b67a9d4836  vmovaps xmm13, [rsp+0xC0]
000076b67a9d483f  vmovaps xmm14, [rsp+0xD0]
000076b67a9d4848  vmovaps xmm15, [rsp+0xE0]
000076b67a9d4851  add rsp, 0xF0
000076b67a9d4858  pop r11
000076b67a9d485a  pop r10
000076b67a9d485c  pop r9
000076b67a9d485e  pop r8
000076b67a9d4860  pop rsi
000076b67a9d4861  pop rdi
000076b67a9d4862  pop rdx
000076b67a9d4863  pop rcx
000076b67a9d4864  pop rax
000076b67a9d4865  add rsp, 0x08
000076b67a9d4869  jmp 0x000076B67A9D0169
000076b67a9d486e  sub rsp, 0x08
000076b67a9d4872  push rax
000076b67a9d4873  push rcx
000076b67a9d4874  push rdx
000076b67a9d4875  push rdi
000076b67a9d4876  push rsi
000076b67a9d4877  push r8
000076b67a9d4879  push r9
000076b67a9d487b  push r10
000076b67a9d487d  push r11
000076b67a9d487f  sub rsp, 0xF0
000076b67a9d4886  vmovaps [rsp], xmm0
000076b67a9d488b  vmovaps [rsp+0x10], xmm1
000076b67a9d4891  vmovaps [rsp+0x20], xmm2
000076b67a9d4897  vmovaps [rsp+0x30], xmm3
000076b67a9d489d  vmovaps [rsp+0x40], xmm4
000076b67a9d48a3  vmovaps [rsp+0x50], xmm5
000076b67a9d48a9  vmovaps [rsp+0x60], xmm6
000076b67a9d48af  vmovaps [rsp+0x70], xmm7
000076b67a9d48b5  vmovaps [rsp+0x80], xmm8
000076b67a9d48be  vmovaps [rsp+0x90], xmm9
000076b67a9d48c7  vmovaps [rsp+0xA0], xmm10
000076b67a9d48d0  vmovaps [rsp+0xB0], xmm11
000076b67a9d48d9  vmovaps [rsp+0xC0], xmm12
000076b67a9d48e2  vmovaps [rsp+0xD0], xmm14
000076b67a9d48eb  vmovaps [rsp+0xE0], xmm15
000076b67a9d48f4  sub rsp, 0x30
000076b67a9d48f8  movaps [rsp], xmm13
000076b67a9d48fd  movaps [rsp+0x10], xmm1
000076b67a9d4902  movaps [rsp+0x20], xmm8
000076b67a9d4908  lea rdi, [rsp]
000076b67a9d490c  mov esi, 0x00
000076b67a9d4911  mov rax, 0x63C5EF2DF530
000076b67a9d491b  call rax
000076b67a9d491d  movaps xmm13, [rsp]
000076b67a9d4922  add rsp, 0x30
000076b67a9d4926  vmovaps xmm0, [rsp]
000076b67a9d492b  vmovaps xmm1, [rsp+0x10]
000076b67a9d4931  vmovaps xmm2, [rsp+0x20]
000076b67a9d4937  vmovaps xmm3, [rsp+0x30]
000076b67a9d493d  vmovaps xmm4, [rsp+0x40]
000076b67a9d4943  vmovaps xmm5, [rsp+0x50]
000076b67a9d4949  vmovaps xmm6, [rsp+0x60]
000076b67a9d494f  vmovaps xmm7, [rsp+0x70]
000076b67a9d4955  vmovaps xmm8, [rsp+0x80]
000076b67a9d495e  vmovaps xmm9, [rsp+0x90]
000076b67a9d4967  vmovaps xmm10, [rsp+0xA0]
000076b67a9d4970  vmovaps xmm11, [rsp+0xB0]
000076b67a9d4979  vmovaps xmm12, [rsp+0xC0]
000076b67a9d4982  vmovaps xmm14, [rsp+0xD0]
000076b67a9d498b  vmovaps xmm15, [rsp+0xE0]
000076b67a9d4994  add rsp, 0xF0
000076b67a9d499b  pop r11
000076b67a9d499d  pop r10
000076b67a9d499f  pop r9
000076b67a9d49a1  pop r8
000076b67a9d49a3  pop rsi
000076b67a9d49a4  pop rdi
000076b67a9d49a5  pop rdx
000076b67a9d49a6  pop rcx
000076b67a9d49a7  pop rax
000076b67a9d49a8  add rsp, 0x08
000076b67a9d49ac  jmp 0x000076B67A9D0183
000076b67a9d49b1  call 0x000076B67A7FF430
000076b67a9d49b6  jmp 0x000076B67A9D018D
000076b67a9d49bb  sub rsp, 0x08
000076b67a9d49bf  push rax
000076b67a9d49c0  push rcx
000076b67a9d49c1  push rdx
000076b67a9d49c2  push rdi
000076b67a9d49c3  push rsi
000076b67a9d49c4  push r8
000076b67a9d49c6  push r9
000076b67a9d49c8  push r10
000076b67a9d49ca  push r11
000076b67a9d49cc  sub rsp, 0xF0
000076b67a9d49d3  vmovaps [rsp], xmm0
000076b67a9d49d8  vmovaps [rsp+0x10], xmm1
000076b67a9d49de  vmovaps [rsp+0x20], xmm2
000076b67a9d49e4  vmovaps [rsp+0x30], xmm3
000076b67a9d49ea  vmovaps [rsp+0x40], xmm4
000076b67a9d49f0  vmovaps [rsp+0x50], xmm5
000076b67a9d49f6  vmovaps [rsp+0x60], xmm6
000076b67a9d49fc  vmovaps [rsp+0x70], xmm7
000076b67a9d4a02  vmovaps [rsp+0x80], xmm9
000076b67a9d4a0b  vmovaps [rsp+0x90], xmm10
000076b67a9d4a14  vmovaps [rsp+0xA0], xmm11
000076b67a9d4a1d  vmovaps [rsp+0xB0], xmm12
000076b67a9d4a26  vmovaps [rsp+0xC0], xmm13
000076b67a9d4a2f  vmovaps [rsp+0xD0], xmm14
000076b67a9d4a38  vmovaps [rsp+0xE0], xmm15
000076b67a9d4a41  sub rsp, 0x30
000076b67a9d4a45  movaps [rsp], xmm8
000076b67a9d4a4a  movaps [rsp+0x10], xmm14
000076b67a9d4a50  movaps [rsp+0x20], xmm9
000076b67a9d4a56  lea rdi, [rsp]
000076b67a9d4a5a  mov esi, 0x00
000076b67a9d4a5f  mov rax, 0x63C5EF2DF530
000076b67a9d4a69  call rax
000076b67a9d4a6b  movaps xmm8, [rsp]
000076b67a9d4a70  add rsp, 0x30
000076b67a9d4a74  vmovaps xmm0, [rsp]
000076b67a9d4a79  vmovaps xmm1, [rsp+0x10]
000076b67a9d4a7f  vmovaps xmm2, [rsp+0x20]
000076b67a9d4a85  vmovaps xmm3, [rsp+0x30]
000076b67a9d4a8b  vmovaps xmm4, [rsp+0x40]
000076b67a9d4a91  vmovaps xmm5, [rsp+0x50]
000076b67a9d4a97  vmovaps xmm6, [rsp+0x60]
000076b67a9d4a9d  vmovaps xmm7, [rsp+0x70]
000076b67a9d4aa3  vmovaps xmm9, [rsp+0x80]
000076b67a9d4aac  vmovaps xmm10, [rsp+0x90]
000076b67a9d4ab5  vmovaps xmm11, [rsp+0xA0]
000076b67a9d4abe  vmovaps xmm12, [rsp+0xB0]
000076b67a9d4ac7  vmovaps xmm13, [rsp+0xC0]
000076b67a9d4ad0  vmovaps xmm14, [rsp+0xD0]
000076b67a9d4ad9  vmovaps xmm15, [rsp+0xE0]
000076b67a9d4ae2  add rsp, 0xF0
000076b67a9d4ae9  pop r11
000076b67a9d4aeb  pop r10
000076b67a9d4aed  pop r9
000076b67a9d4aef  pop r8
000076b67a9d4af1  pop rsi
000076b67a9d4af2  pop rdi
000076b67a9d4af3  pop rdx
000076b67a9d4af4  pop rcx
000076b67a9d4af5  pop rax
000076b67a9d4af6  add rsp, 0x08
000076b67a9d4afa  jmp 0x000076B67A9D01AF
000076b67a9d4aff  sub rsp, 0x08
000076b67a9d4b03  push rax
000076b67a9d4b04  push rcx
000076b67a9d4b05  push rdx
000076b67a9d4b06  push rdi
000076b67a9d4b07  push rsi
000076b67a9d4b08  push r8
000076b67a9d4b0a  push r9
000076b67a9d4b0c  push r10
000076b67a9d4b0e  push r11
000076b67a9d4b10  sub rsp, 0xF0
000076b67a9d4b17  vmovaps [rsp], xmm0
000076b67a9d4b1c  vmovaps [rsp+0x10], xmm1
000076b67a9d4b22  vmovaps [rsp+0x20], xmm2
000076b67a9d4b28  vmovaps [rsp+0x30], xmm3
000076b67a9d4b2e  vmovaps [rsp+0x40], xmm4
000076b67a9d4b34  vmovaps [rsp+0x50], xmm5
000076b67a9d4b3a  vmovaps [rsp+0x60], xmm6
000076b67a9d4b40  vmovaps [rsp+0x70], xmm7
000076b67a9d4b46  vmovaps [rsp+0x80], xmm8
000076b67a9d4b4f  vmovaps [rsp+0x90], xmm10
000076b67a9d4b58  vmovaps [rsp+0xA0], xmm11
000076b67a9d4b61  vmovaps [rsp+0xB0], xmm12
000076b67a9d4b6a  vmovaps [rsp+0xC0], xmm13
000076b67a9d4b73  vmovaps [rsp+0xD0], xmm14
000076b67a9d4b7c  vmovaps [rsp+0xE0], xmm15
000076b67a9d4b85  sub rsp, 0x30
000076b67a9d4b89  movaps [rsp], xmm9
000076b67a9d4b8e  movaps [rsp+0x10], xmm1
000076b67a9d4b93  movaps [rsp+0x20], xmm14
000076b67a9d4b99  lea rdi, [rsp]
000076b67a9d4b9d  mov esi, 0x00
000076b67a9d4ba2  mov rax, 0x63C5EF2DF530
000076b67a9d4bac  call rax
000076b67a9d4bae  movaps xmm9, [rsp]
000076b67a9d4bb3  add rsp, 0x30
000076b67a9d4bb7  vmovaps xmm0, [rsp]
000076b67a9d4bbc  vmovaps xmm1, [rsp+0x10]
000076b67a9d4bc2  vmovaps xmm2, [rsp+0x20]
000076b67a9d4bc8  vmovaps xmm3, [rsp+0x30]
000076b67a9d4bce  vmovaps xmm4, [rsp+0x40]
000076b67a9d4bd4  vmovaps xmm5, [rsp+0x50]
000076b67a9d4bda  vmovaps xmm6, [rsp+0x60]
000076b67a9d4be0  vmovaps xmm7, [rsp+0x70]
000076b67a9d4be6  vmovaps xmm8, [rsp+0x80]
000076b67a9d4bef  vmovaps xmm10, [rsp+0x90]
000076b67a9d4bf8  vmovaps xmm11, [rsp+0xA0]
000076b67a9d4c01  vmovaps xmm12, [rsp+0xB0]
000076b67a9d4c0a  vmovaps xmm13, [rsp+0xC0]
000076b67a9d4c13  vmovaps xmm14, [rsp+0xD0]
000076b67a9d4c1c  vmovaps xmm15, [rsp+0xE0]
000076b67a9d4c25  add rsp, 0xF0
000076b67a9d4c2c  pop r11
000076b67a9d4c2e  pop r10
000076b67a9d4c30  pop r9
000076b67a9d4c32  pop r8
000076b67a9d4c34  pop rsi
000076b67a9d4c35  pop rdi
000076b67a9d4c36  pop rdx
000076b67a9d4c37  pop rcx
000076b67a9d4c38  pop rax
000076b67a9d4c39  add rsp, 0x08
000076b67a9d4c3d  jmp 0x000076B67A9D01DD
000076b67a9d4c42  sub rsp, 0x08
000076b67a9d4c46  push rax
000076b67a9d4c47  push rcx
000076b67a9d4c48  push rdx
000076b67a9d4c49  push rdi
000076b67a9d4c4a  push rsi
000076b67a9d4c4b  push r8
000076b67a9d4c4d  push r9
000076b67a9d4c4f  push r10
000076b67a9d4c51  push r11
000076b67a9d4c53  sub rsp, 0xF0
000076b67a9d4c5a  vmovaps [rsp], xmm0
000076b67a9d4c5f  vmovaps [rsp+0x10], xmm1
000076b67a9d4c65  vmovaps [rsp+0x20], xmm2
000076b67a9d4c6b  vmovaps [rsp+0x30], xmm3
000076b67a9d4c71  vmovaps [rsp+0x40], xmm4
000076b67a9d4c77  vmovaps [rsp+0x50], xmm5
000076b67a9d4c7d  vmovaps [rsp+0x60], xmm6
000076b67a9d4c83  vmovaps [rsp+0x70], xmm7
000076b67a9d4c89  vmovaps [rsp+0x80], xmm8
000076b67a9d4c92  vmovaps [rsp+0x90], xmm9
000076b67a9d4c9b  vmovaps [rsp+0xA0], xmm10
000076b67a9d4ca4  vmovaps [rsp+0xB0], xmm11
000076b67a9d4cad  vmovaps [rsp+0xC0], xmm12
000076b67a9d4cb6  vmovaps [rsp+0xD0], xmm13
000076b67a9d4cbf  vmovaps [rsp+0xE0], xmm15
000076b67a9d4cc8  sub rsp, 0x30
000076b67a9d4ccc  movaps [rsp], xmm14
000076b67a9d4cd1  movaps [rsp+0x10], xmm4
000076b67a9d4cd6  movaps [rsp+0x20], xmm1
000076b67a9d4cdb  lea rdi, [rsp]
000076b67a9d4cdf  mov esi, 0x00
000076b67a9d4ce4  mov rax, 0x63C5EF2DF530
000076b67a9d4cee  call rax
000076b67a9d4cf0  movaps xmm14, [rsp]
000076b67a9d4cf5  add rsp, 0x30
000076b67a9d4cf9  vmovaps xmm0, [rsp]
000076b67a9d4cfe  vmovaps xmm1, [rsp+0x10]
000076b67a9d4d04  vmovaps xmm2, [rsp+0x20]
000076b67a9d4d0a  vmovaps xmm3, [rsp+0x30]
000076b67a9d4d10  vmovaps xmm4, [rsp+0x40]
000076b67a9d4d16  vmovaps xmm5, [rsp+0x50]
000076b67a9d4d1c  vmovaps xmm6, [rsp+0x60]
000076b67a9d4d22  vmovaps xmm7, [rsp+0x70]
000076b67a9d4d28  vmovaps xmm8, [rsp+0x80]
000076b67a9d4d31  vmovaps xmm9, [rsp+0x90]
000076b67a9d4d3a  vmovaps xmm10, [rsp+0xA0]
000076b67a9d4d43  vmovaps xmm11, [rsp+0xB0]
000076b67a9d4d4c  vmovaps xmm12, [rsp+0xC0]
000076b67a9d4d55  vmovaps xmm13, [rsp+0xD0]
000076b67a9d4d5e  vmovaps xmm15, [rsp+0xE0]
000076b67a9d4d67  add rsp, 0xF0
000076b67a9d4d6e  pop r11
000076b67a9d4d70  pop r10
000076b67a9d4d72  pop r9
000076b67a9d4d74  pop r8
000076b67a9d4d76  pop rsi
000076b67a9d4d77  pop rdi
000076b67a9d4d78  pop rdx
000076b67a9d4d79  pop rcx
000076b67a9d4d7a  pop rax
000076b67a9d4d7b  add rsp, 0x08
000076b67a9d4d7f  jmp 0x000076B67A9D0203
000076b67a9d4d84  sub rsp, 0x08
000076b67a9d4d88  push rax
000076b67a9d4d89  push rcx
000076b67a9d4d8a  push rdx
000076b67a9d4d8b  push rdi
000076b67a9d4d8c  push rsi
000076b67a9d4d8d  push r8
000076b67a9d4d8f  push r9
000076b67a9d4d91  push r10
000076b67a9d4d93  push r11
000076b67a9d4d95  sub rsp, 0xF0
000076b67a9d4d9c  vmovaps [rsp], xmm0
000076b67a9d4da1  vmovaps [rsp+0x10], xmm2
000076b67a9d4da7  vmovaps [rsp+0x20], xmm3
000076b67a9d4dad  vmovaps [rsp+0x30], xmm4
000076b67a9d4db3  vmovaps [rsp+0x40], xmm5
000076b67a9d4db9  vmovaps [rsp+0x50], xmm6
000076b67a9d4dbf  vmovaps [rsp+0x60], xmm7
000076b67a9d4dc5  vmovaps [rsp+0x70], xmm8
000076b67a9d4dcb  vmovaps [rsp+0x80], xmm9
000076b67a9d4dd4  vmovaps [rsp+0x90], xmm10
000076b67a9d4ddd  vmovaps [rsp+0xA0], xmm11
000076b67a9d4de6  vmovaps [rsp+0xB0], xmm12
000076b67a9d4def  vmovaps [rsp+0xC0], xmm13
000076b67a9d4df8  vmovaps [rsp+0xD0], xmm14
000076b67a9d4e01  vmovaps [rsp+0xE0], xmm15
000076b67a9d4e0a  sub rsp, 0x30
000076b67a9d4e0e  movaps [rsp], xmm1
000076b67a9d4e12  movaps [rsp+0x10], xmm12
000076b67a9d4e18  movaps [rsp+0x20], xmm11
000076b67a9d4e1e  lea rdi, [rsp]
000076b67a9d4e22  mov esi, 0x00
000076b67a9d4e27  mov rax, 0x63C5EF2DF530
000076b67a9d4e31  call rax
000076b67a9d4e33  movaps xmm1, [rsp]
000076b67a9d4e37  add rsp, 0x30
000076b67a9d4e3b  vmovaps xmm0, [rsp]
000076b67a9d4e40  vmovaps xmm2, [rsp+0x10]
000076b67a9d4e46  vmovaps xmm3, [rsp+0x20]
000076b67a9d4e4c  vmovaps xmm4, [rsp+0x30]
000076b67a9d4e52  vmovaps xmm5, [rsp+0x40]
000076b67a9d4e58  vmovaps xmm6, [rsp+0x50]
000076b67a9d4e5e  vmovaps xmm7, [rsp+0x60]
000076b67a9d4e64  vmovaps xmm8, [rsp+0x70]
000076b67a9d4e6a  vmovaps xmm9, [rsp+0x80]
000076b67a9d4e73  vmovaps xmm10, [rsp+0x90]
000076b67a9d4e7c  vmovaps xmm11, [rsp+0xA0]
000076b67a9d4e85  vmovaps xmm12, [rsp+0xB0]
000076b67a9d4e8e  vmovaps xmm13, [rsp+0xC0]
000076b67a9d4e97  vmovaps xmm14, [rsp+0xD0]
000076b67a9d4ea0  vmovaps xmm15, [rsp+0xE0]
000076b67a9d4ea9  add rsp, 0xF0
000076b67a9d4eb0  pop r11
000076b67a9d4eb2  pop r10
000076b67a9d4eb4  pop r9
000076b67a9d4eb6  pop r8
000076b67a9d4eb8  pop rsi
000076b67a9d4eb9  pop rdi
000076b67a9d4eba  pop rdx
000076b67a9d4ebb  pop rcx
000076b67a9d4ebc  pop rax
000076b67a9d4ebd  add rsp, 0x08
000076b67a9d4ec1  jmp 0x000076B67A9D0224
000076b67a9d4ec6  call 0x000076B67A8E20A0
000076b67a9d4ecb  jmp 0x000076B67A9D0232
000076b67a9d4ed0  call 0x000076B67A809D70
000076b67a9d4ed5  jmp 0x000076B67A9D023C
000076b67a9d4eda  sub rsp, 0x08
000076b67a9d4ede  push rax
000076b67a9d4edf  push rcx
000076b67a9d4ee0  push rdx
000076b67a9d4ee1  push rdi
000076b67a9d4ee2  push rsi
000076b67a9d4ee3  push r8
000076b67a9d4ee5  push r9
000076b67a9d4ee7  push r10
000076b67a9d4ee9  push r11
000076b67a9d4eeb  sub rsp, 0xF0
000076b67a9d4ef2  vmovaps [rsp], xmm0
000076b67a9d4ef7  vmovaps [rsp+0x10], xmm1
000076b67a9d4efd  vmovaps [rsp+0x20], xmm2
000076b67a9d4f03  vmovaps [rsp+0x30], xmm3
000076b67a9d4f09  vmovaps [rsp+0x40], xmm4
000076b67a9d4f0f  vmovaps [rsp+0x50], xmm5
000076b67a9d4f15  vmovaps [rsp+0x60], xmm6
000076b67a9d4f1b  vmovaps [rsp+0x70], xmm8
000076b67a9d4f21  vmovaps [rsp+0x80], xmm9
000076b67a9d4f2a  vmovaps [rsp+0x90], xmm10
000076b67a9d4f33  vmovaps [rsp+0xA0], xmm11
000076b67a9d4f3c  vmovaps [rsp+0xB0], xmm12
000076b67a9d4f45  vmovaps [rsp+0xC0], xmm13
000076b67a9d4f4e  vmovaps [rsp+0xD0], xmm14
000076b67a9d4f57  vmovaps [rsp+0xE0], xmm15
000076b67a9d4f60  sub rsp, 0x30
000076b67a9d4f64  movaps [rsp], xmm7
000076b67a9d4f68  movaps [rsp+0x10], xmm15
000076b67a9d4f6e  movaps [rsp+0x20], xmm10
000076b67a9d4f74  lea rdi, [rsp]
000076b67a9d4f78  mov esi, 0x00
000076b67a9d4f7d  mov rax, 0x63C5EF2DF530
000076b67a9d4f87  call rax
000076b67a9d4f89  movaps xmm7, [rsp]
000076b67a9d4f8d  add rsp, 0x30
000076b67a9d4f91  vmovaps xmm0, [rsp]
000076b67a9d4f96  vmovaps xmm1, [rsp+0x10]
000076b67a9d4f9c  vmovaps xmm2, [rsp+0x20]
000076b67a9d4fa2  vmovaps xmm3, [rsp+0x30]
000076b67a9d4fa8  vmovaps xmm4, [rsp+0x40]
000076b67a9d4fae  vmovaps xmm5, [rsp+0x50]
000076b67a9d4fb4  vmovaps xmm6, [rsp+0x60]
000076b67a9d4fba  vmovaps xmm8, [rsp+0x70]
000076b67a9d4fc0  vmovaps xmm9, [rsp+0x80]
000076b67a9d4fc9  vmovaps xmm10, [rsp+0x90]
000076b67a9d4fd2  vmovaps xmm11, [rsp+0xA0]
000076b67a9d4fdb  vmovaps xmm12, [rsp+0xB0]
000076b67a9d4fe4  vmovaps xmm13, [rsp+0xC0]
000076b67a9d4fed  vmovaps xmm14, [rsp+0xD0]
000076b67a9d4ff6  vmovaps xmm15, [rsp+0xE0]
000076b67a9d4fff  add rsp, 0xF0
000076b67a9d5006  pop r11
000076b67a9d5008  pop r10
000076b67a9d500a  pop r9
000076b67a9d500c  pop r8
000076b67a9d500e  pop rsi
000076b67a9d500f  pop rdi
000076b67a9d5010  pop rdx
000076b67a9d5011  pop rcx
000076b67a9d5012  pop rax
000076b67a9d5013  add rsp, 0x08
000076b67a9d5017  jmp 0x000076B67A9D025D
000076b67a9d501c  sub rsp, 0x08
000076b67a9d5020  push rax
000076b67a9d5021  push rcx
000076b67a9d5022  push rdx
000076b67a9d5023  push rdi
000076b67a9d5024  push rsi
000076b67a9d5025  push r8
000076b67a9d5027  push r9
000076b67a9d5029  push r10
000076b67a9d502b  push r11
000076b67a9d502d  sub rsp, 0xF0
000076b67a9d5034  vmovaps [rsp], xmm0
000076b67a9d5039  vmovaps [rsp+0x10], xmm1
000076b67a9d503f  vmovaps [rsp+0x20], xmm2
000076b67a9d5045  vmovaps [rsp+0x30], xmm3
000076b67a9d504b  vmovaps [rsp+0x40], xmm4
000076b67a9d5051  vmovaps [rsp+0x50], xmm5
000076b67a9d5057  vmovaps [rsp+0x60], xmm6
000076b67a9d505d  vmovaps [rsp+0x70], xmm7
000076b67a9d5063  vmovaps [rsp+0x80], xmm8
000076b67a9d506c  vmovaps [rsp+0x90], xmm9
000076b67a9d5075  vmovaps [rsp+0xA0], xmm11
000076b67a9d507e  vmovaps [rsp+0xB0], xmm12
000076b67a9d5087  vmovaps [rsp+0xC0], xmm13
000076b67a9d5090  vmovaps [rsp+0xD0], xmm14
000076b67a9d5099  vmovaps [rsp+0xE0], xmm15
000076b67a9d50a2  sub rsp, 0x30
000076b67a9d50a6  movaps [rsp], xmm10
000076b67a9d50ab  movaps [rsp+0x10], xmm11
000076b67a9d50b1  movaps [rsp+0x20], xmm15
000076b67a9d50b7  lea rdi, [rsp]
000076b67a9d50bb  mov esi, 0x00
000076b67a9d50c0  mov rax, 0x63C5EF2DF530
000076b67a9d50ca  call rax
000076b67a9d50cc  movaps xmm10, [rsp]
000076b67a9d50d1  add rsp, 0x30
000076b67a9d50d5  vmovaps xmm0, [rsp]
000076b67a9d50da  vmovaps xmm1, [rsp+0x10]
000076b67a9d50e0  vmovaps xmm2, [rsp+0x20]
000076b67a9d50e6  vmovaps xmm3, [rsp+0x30]
000076b67a9d50ec  vmovaps xmm4, [rsp+0x40]
000076b67a9d50f2  vmovaps xmm5, [rsp+0x50]
000076b67a9d50f8  vmovaps xmm6, [rsp+0x60]
000076b67a9d50fe  vmovaps xmm7, [rsp+0x70]
000076b67a9d5104  vmovaps xmm8, [rsp+0x80]
000076b67a9d510d  vmovaps xmm9, [rsp+0x90]
000076b67a9d5116  vmovaps xmm11, [rsp+0xA0]
000076b67a9d511f  vmovaps xmm12, [rsp+0xB0]
000076b67a9d5128  vmovaps xmm13, [rsp+0xC0]
000076b67a9d5131  vmovaps xmm14, [rsp+0xD0]
000076b67a9d513a  vmovaps xmm15, [rsp+0xE0]
000076b67a9d5143  add rsp, 0xF0
000076b67a9d514a  pop r11
000076b67a9d514c  pop r10
000076b67a9d514e  pop r9
000076b67a9d5150  pop r8
000076b67a9d5152  pop rsi
000076b67a9d5153  pop rdi
000076b67a9d5154  pop rdx
000076b67a9d5155  pop rcx
000076b67a9d5156  pop rax
000076b67a9d5157  add rsp, 0x08
000076b67a9d515b  jmp 0x000076B67A9D028B
000076b67a9d5160  sub rsp, 0x08
000076b67a9d5164  push rax
000076b67a9d5165  push rcx
000076b67a9d5166  push rdx
000076b67a9d5167  push rdi
000076b67a9d5168  push rsi
000076b67a9d5169  push r8
000076b67a9d516b  push r9
000076b67a9d516d  push r10
000076b67a9d516f  push r11
000076b67a9d5171  sub rsp, 0xF0
000076b67a9d5178  vmovaps [rsp], xmm0
000076b67a9d517d  vmovaps [rsp+0x10], xmm1
000076b67a9d5183  vmovaps [rsp+0x20], xmm2
000076b67a9d5189  vmovaps [rsp+0x30], xmm3
000076b67a9d518f  vmovaps [rsp+0x40], xmm4
000076b67a9d5195  vmovaps [rsp+0x50], xmm5
000076b67a9d519b  vmovaps [rsp+0x60], xmm6
000076b67a9d51a1  vmovaps [rsp+0x70], xmm7
000076b67a9d51a7  vmovaps [rsp+0x80], xmm8
000076b67a9d51b0  vmovaps [rsp+0x90], xmm9
000076b67a9d51b9  vmovaps [rsp+0xA0], xmm10
000076b67a9d51c2  vmovaps [rsp+0xB0], xmm12
000076b67a9d51cb  vmovaps [rsp+0xC0], xmm13
000076b67a9d51d4  vmovaps [rsp+0xD0], xmm14
000076b67a9d51dd  vmovaps [rsp+0xE0], xmm15
000076b67a9d51e6  sub rsp, 0x30
000076b67a9d51ea  movaps [rsp], xmm11
000076b67a9d51ef  movaps [rsp+0x10], xmm12
000076b67a9d51f5  movaps [rsp+0x20], xmm15
000076b67a9d51fb  lea rdi, [rsp]
000076b67a9d51ff  mov esi, 0x00
000076b67a9d5204  mov rax, 0x63C5EF2DF530
000076b67a9d520e  call rax
000076b67a9d5210  movaps xmm11, [rsp]
000076b67a9d5215  add rsp, 0x30
000076b67a9d5219  vmovaps xmm0, [rsp]
000076b67a9d521e  vmovaps xmm1, [rsp+0x10]
000076b67a9d5224  vmovaps xmm2, [rsp+0x20]
000076b67a9d522a  vmovaps xmm3, [rsp+0x30]
000076b67a9d5230  vmovaps xmm4, [rsp+0x40]
000076b67a9d5236  vmovaps xmm5, [rsp+0x50]
000076b67a9d523c  vmovaps xmm6, [rsp+0x60]
000076b67a9d5242  vmovaps xmm7, [rsp+0x70]
000076b67a9d5248  vmovaps xmm8, [rsp+0x80]
000076b67a9d5251  vmovaps xmm9, [rsp+0x90]
000076b67a9d525a  vmovaps xmm10, [rsp+0xA0]
000076b67a9d5263  vmovaps xmm12, [rsp+0xB0]
000076b67a9d526c  vmovaps xmm13, [rsp+0xC0]
000076b67a9d5275  vmovaps xmm14, [rsp+0xD0]
000076b67a9d527e  vmovaps xmm15, [rsp+0xE0]
000076b67a9d5287  add rsp, 0xF0
000076b67a9d528e  pop r11
000076b67a9d5290  pop r10
000076b67a9d5292  pop r9
000076b67a9d5294  pop r8
000076b67a9d5296  pop rsi
000076b67a9d5297  pop rdi
000076b67a9d5298  pop rdx
000076b67a9d5299  pop rcx
000076b67a9d529a  pop rax
000076b67a9d529b  add rsp, 0x08
000076b67a9d529f  jmp 0x000076B67A9D02B9
000076b67a9d52a4  sub rsp, 0x08
000076b67a9d52a8  push rax
000076b67a9d52a9  push rcx
000076b67a9d52aa  push rdx
000076b67a9d52ab  push rdi
000076b67a9d52ac  push rsi
000076b67a9d52ad  push r8
000076b67a9d52af  push r9
000076b67a9d52b1  push r10
000076b67a9d52b3  push r11
000076b67a9d52b5  sub rsp, 0xF0
000076b67a9d52bc  vmovaps [rsp], xmm0
000076b67a9d52c1  vmovaps [rsp+0x10], xmm1
000076b67a9d52c7  vmovaps [rsp+0x20], xmm2
000076b67a9d52cd  vmovaps [rsp+0x30], xmm3
000076b67a9d52d3  vmovaps [rsp+0x40], xmm4
000076b67a9d52d9  vmovaps [rsp+0x50], xmm5
000076b67a9d52df  vmovaps [rsp+0x60], xmm6
000076b67a9d52e5  vmovaps [rsp+0x70], xmm7
000076b67a9d52eb  vmovaps [rsp+0x80], xmm8
000076b67a9d52f4  vmovaps [rsp+0x90], xmm9
000076b67a9d52fd  vmovaps [rsp+0xA0], xmm10
000076b67a9d5306  vmovaps [rsp+0xB0], xmm11
000076b67a9d530f  vmovaps [rsp+0xC0], xmm12
000076b67a9d5318  vmovaps [rsp+0xD0], xmm13
000076b67a9d5321  vmovaps [rsp+0xE0], xmm14
000076b67a9d532a  sub rsp, 0x30
000076b67a9d532e  movaps [rsp], xmm15
000076b67a9d5333  movaps [rsp+0x10], xmm13
000076b67a9d5339  movaps [rsp+0x20], xmm9
000076b67a9d533f  lea rdi, [rsp]
000076b67a9d5343  mov esi, 0x00
000076b67a9d5348  mov rax, 0x63C5EF2DF530
000076b67a9d5352  call rax
000076b67a9d5354  movaps xmm15, [rsp]
000076b67a9d5359  add rsp, 0x30
000076b67a9d535d  vmovaps xmm0, [rsp]
000076b67a9d5362  vmovaps xmm1, [rsp+0x10]
000076b67a9d5368  vmovaps xmm2, [rsp+0x20]
000076b67a9d536e  vmovaps xmm3, [rsp+0x30]
000076b67a9d5374  vmovaps xmm4, [rsp+0x40]
000076b67a9d537a  vmovaps xmm5, [rsp+0x50]
000076b67a9d5380  vmovaps xmm6, [rsp+0x60]
000076b67a9d5386  vmovaps xmm7, [rsp+0x70]
000076b67a9d538c  vmovaps xmm8, [rsp+0x80]
000076b67a9d5395  vmovaps xmm9, [rsp+0x90]
000076b67a9d539e  vmovaps xmm10, [rsp+0xA0]
000076b67a9d53a7  vmovaps xmm11, [rsp+0xB0]
000076b67a9d53b0  vmovaps xmm12, [rsp+0xC0]
000076b67a9d53b9  vmovaps xmm13, [rsp+0xD0]
000076b67a9d53c2  vmovaps xmm14, [rsp+0xE0]
000076b67a9d53cb  add rsp, 0xF0
000076b67a9d53d2  pop r11
000076b67a9d53d4  pop r10
000076b67a9d53d6  pop r9
000076b67a9d53d8  pop r8
000076b67a9d53da  pop rsi
000076b67a9d53db  pop rdi
000076b67a9d53dc  pop rdx
000076b67a9d53dd  pop rcx
000076b67a9d53de  pop rax
000076b67a9d53df  add rsp, 0x08
000076b67a9d53e3  jmp 0x000076B67A9D02D4
000076b67a9d53e8  sub rsp, 0x08
000076b67a9d53ec  push rax
000076b67a9d53ed  push rcx
000076b67a9d53ee  push rdx
000076b67a9d53ef  push rdi
000076b67a9d53f0  push rsi
000076b67a9d53f1  push r8
000076b67a9d53f3  push r9
000076b67a9d53f5  push r10
000076b67a9d53f7  push r11
000076b67a9d53f9  sub rsp, 0xF0
000076b67a9d5400  vmovaps [rsp], xmm0
000076b67a9d5405  vmovaps [rsp+0x10], xmm1
000076b67a9d540b  vmovaps [rsp+0x20], xmm2
000076b67a9d5411  vmovaps [rsp+0x30], xmm3
000076b67a9d5417  vmovaps [rsp+0x40], xmm4
000076b67a9d541d  vmovaps [rsp+0x50], xmm5
000076b67a9d5423  vmovaps [rsp+0x60], xmm6
000076b67a9d5429  vmovaps [rsp+0x70], xmm7
000076b67a9d542f  vmovaps [rsp+0x80], xmm8
000076b67a9d5438  vmovaps [rsp+0x90], xmm9
000076b67a9d5441  vmovaps [rsp+0xA0], xmm10
000076b67a9d544a  vmovaps [rsp+0xB0], xmm11
000076b67a9d5453  vmovaps [rsp+0xC0], xmm12
000076b67a9d545c  vmovaps [rsp+0xD0], xmm14
000076b67a9d5465  vmovaps [rsp+0xE0], xmm15
000076b67a9d546e  sub rsp, 0x30
000076b67a9d5472  movaps [rsp], xmm13
000076b67a9d5477  movaps [rsp+0x10], xmm8
000076b67a9d547d  movaps [rsp+0x20], xmm14
000076b67a9d5483  lea rdi, [rsp]
000076b67a9d5487  mov esi, 0x00
000076b67a9d548c  mov rax, 0x63C5EF2DF530
000076b67a9d5496  call rax
000076b67a9d5498  movaps xmm13, [rsp]
000076b67a9d549d  add rsp, 0x30
000076b67a9d54a1  vmovaps xmm0, [rsp]
000076b67a9d54a6  vmovaps xmm1, [rsp+0x10]
000076b67a9d54ac  vmovaps xmm2, [rsp+0x20]
000076b67a9d54b2  vmovaps xmm3, [rsp+0x30]
000076b67a9d54b8  vmovaps xmm4, [rsp+0x40]
000076b67a9d54be  vmovaps xmm5, [rsp+0x50]
000076b67a9d54c4  vmovaps xmm6, [rsp+0x60]
000076b67a9d54ca  vmovaps xmm7, [rsp+0x70]
000076b67a9d54d0  vmovaps xmm8, [rsp+0x80]
000076b67a9d54d9  vmovaps xmm9, [rsp+0x90]
000076b67a9d54e2  vmovaps xmm10, [rsp+0xA0]
000076b67a9d54eb  vmovaps xmm11, [rsp+0xB0]
000076b67a9d54f4  vmovaps xmm12, [rsp+0xC0]
000076b67a9d54fd  vmovaps xmm14, [rsp+0xD0]
000076b67a9d5506  vmovaps xmm15, [rsp+0xE0]
000076b67a9d550f  add rsp, 0xF0
000076b67a9d5516  pop r11
000076b67a9d5518  pop r10
000076b67a9d551a  pop r9
000076b67a9d551c  pop r8
000076b67a9d551e  pop rsi
000076b67a9d551f  pop rdi
000076b67a9d5520  pop rdx
000076b67a9d5521  pop rcx
000076b67a9d5522  pop rax
000076b67a9d5523  add rsp, 0x08
000076b67a9d5527  jmp 0x000076B67A9D02F7
000076b67a9d552c  sub rsp, 0x08
000076b67a9d5530  push rax
000076b67a9d5531  push rcx
000076b67a9d5532  push rdx
000076b67a9d5533  push rdi
000076b67a9d5534  push rsi
000076b67a9d5535  push r8
000076b67a9d5537  push r9
000076b67a9d5539  push r10
000076b67a9d553b  push r11
000076b67a9d553d  sub rsp, 0xF0
000076b67a9d5544  vmovaps [rsp], xmm0
000076b67a9d5549  vmovaps [rsp+0x10], xmm1
000076b67a9d554f  vmovaps [rsp+0x20], xmm2
000076b67a9d5555  vmovaps [rsp+0x30], xmm3
000076b67a9d555b  vmovaps [rsp+0x40], xmm4
000076b67a9d5561  vmovaps [rsp+0x50], xmm5
000076b67a9d5567  vmovaps [rsp+0x60], xmm6
000076b67a9d556d  vmovaps [rsp+0x70], xmm7
000076b67a9d5573  vmovaps [rsp+0x80], xmm8
000076b67a9d557c  vmovaps [rsp+0x90], xmm9
000076b67a9d5585  vmovaps [rsp+0xA0], xmm10
000076b67a9d558e  vmovaps [rsp+0xB0], xmm11
000076b67a9d5597  vmovaps [rsp+0xC0], xmm12
000076b67a9d55a0  vmovaps [rsp+0xD0], xmm13
000076b67a9d55a9  vmovaps [rsp+0xE0], xmm15
000076b67a9d55b2  sub rsp, 0x30
000076b67a9d55b6  movaps [rsp], xmm14
000076b67a9d55bb  movaps [rsp+0x10], xmm1
000076b67a9d55c0  movaps [rsp+0x20], xmm10
000076b67a9d55c6  lea rdi, [rsp]
000076b67a9d55ca  mov esi, 0x00
000076b67a9d55cf  mov rax, 0x63C5EF2DF530
000076b67a9d55d9  call rax
000076b67a9d55db  movaps xmm14, [rsp]
000076b67a9d55e0  add rsp, 0x30
000076b67a9d55e4  vmovaps xmm0, [rsp]
000076b67a9d55e9  vmovaps xmm1, [rsp+0x10]
000076b67a9d55ef  vmovaps xmm2, [rsp+0x20]
000076b67a9d55f5  vmovaps xmm3, [rsp+0x30]
000076b67a9d55fb  vmovaps xmm4, [rsp+0x40]
000076b67a9d5601  vmovaps xmm5, [rsp+0x50]
000076b67a9d5607  vmovaps xmm6, [rsp+0x60]
000076b67a9d560d  vmovaps xmm7, [rsp+0x70]
000076b67a9d5613  vmovaps xmm8, [rsp+0x80]
000076b67a9d561c  vmovaps xmm9, [rsp+0x90]
000076b67a9d5625  vmovaps xmm10, [rsp+0xA0]
000076b67a9d562e  vmovaps xmm11, [rsp+0xB0]
000076b67a9d5637  vmovaps xmm12, [rsp+0xC0]
000076b67a9d5640  vmovaps xmm13, [rsp+0xD0]
000076b67a9d5649  vmovaps xmm15, [rsp+0xE0]
000076b67a9d5652  add rsp, 0xF0
000076b67a9d5659  pop r11
000076b67a9d565b  pop r10
000076b67a9d565d  pop r9
000076b67a9d565f  pop r8
000076b67a9d5661  pop rsi
000076b67a9d5662  pop rdi
000076b67a9d5663  pop rdx
000076b67a9d5664  pop rcx
000076b67a9d5665  pop rax
000076b67a9d5666  add rsp, 0x08
000076b67a9d566a  jmp 0x000076B67A9D031A
000076b67a9d566f  sub rsp, 0x08
000076b67a9d5673  push rax
000076b67a9d5674  push rcx
000076b67a9d5675  push rdx
000076b67a9d5676  push rdi
000076b67a9d5677  push rsi
000076b67a9d5678  push r8
000076b67a9d567a  push r9
000076b67a9d567c  push r10
000076b67a9d567e  push r11
000076b67a9d5680  sub rsp, 0xF0
000076b67a9d5687  vmovaps [rsp], xmm0
000076b67a9d568c  vmovaps [rsp+0x10], xmm2
000076b67a9d5692  vmovaps [rsp+0x20], xmm3
000076b67a9d5698  vmovaps [rsp+0x30], xmm4
000076b67a9d569e  vmovaps [rsp+0x40], xmm5
000076b67a9d56a4  vmovaps [rsp+0x50], xmm6
000076b67a9d56aa  vmovaps [rsp+0x60], xmm7
000076b67a9d56b0  vmovaps [rsp+0x70], xmm8
000076b67a9d56b6  vmovaps [rsp+0x80], xmm9
000076b67a9d56bf  vmovaps [rsp+0x90], xmm10
000076b67a9d56c8  vmovaps [rsp+0xA0], xmm11
000076b67a9d56d1  vmovaps [rsp+0xB0], xmm12
000076b67a9d56da  vmovaps [rsp+0xC0], xmm13
000076b67a9d56e3  vmovaps [rsp+0xD0], xmm14
000076b67a9d56ec  vmovaps [rsp+0xE0], xmm15
000076b67a9d56f5  sub rsp, 0x30
000076b67a9d56f9  movaps [rsp], xmm1
000076b67a9d56fd  movaps [rsp+0x10], xmm7
000076b67a9d5702  movaps [rsp+0x20], xmm11
000076b67a9d5708  lea rdi, [rsp]
000076b67a9d570c  mov esi, 0x00
000076b67a9d5711  mov rax, 0x63C5EF2DF530
000076b67a9d571b  call rax
000076b67a9d571d  movaps xmm1, [rsp]
000076b67a9d5721  add rsp, 0x30
000076b67a9d5725  vmovaps xmm0, [rsp]
000076b67a9d572a  vmovaps xmm2, [rsp+0x10]
000076b67a9d5730  vmovaps xmm3, [rsp+0x20]
000076b67a9d5736  vmovaps xmm4, [rsp+0x30]
000076b67a9d573c  vmovaps xmm5, [rsp+0x40]
000076b67a9d5742  vmovaps xmm6, [rsp+0x50]
000076b67a9d5748  vmovaps xmm7, [rsp+0x60]
000076b67a9d574e  vmovaps xmm8, [rsp+0x70]
000076b67a9d5754  vmovaps xmm9, [rsp+0x80]
000076b67a9d575d  vmovaps xmm10, [rsp+0x90]
000076b67a9d5766  vmovaps xmm11, [rsp+0xA0]
000076b67a9d576f  vmovaps xmm12, [rsp+0xB0]
000076b67a9d5778  vmovaps xmm13, [rsp+0xC0]
000076b67a9d5781  vmovaps xmm14, [rsp+0xD0]
000076b67a9d578a  vmovaps xmm15, [rsp+0xE0]
000076b67a9d5793  add rsp, 0xF0
000076b67a9d579a  pop r11
000076b67a9d579c  pop r10
000076b67a9d579e  pop r9
000076b67a9d57a0  pop r8
000076b67a9d57a2  pop rsi
000076b67a9d57a3  pop rdi
000076b67a9d57a4  pop rdx
000076b67a9d57a5  pop rcx
000076b67a9d57a6  pop rax
000076b67a9d57a7  add rsp, 0x08
000076b67a9d57ab  jmp 0x000076B67A9D033B
000076b67a9d57b0  call 0x000076B67A80E880
000076b67a9d57b5  jmp 0x000076B67A9D034E
000076b67a9d57ba  call 0x000076B67A80C380
000076b67a9d57bf  jmp 0x000076B67A9D0359
000076b67a9d57c4  call 0x000076B67A80D600
000076b67a9d57c9  jmp 0x000076B67A9D0364
000076b67a9d57ce  call 0x000076B67A7FF540
000076b67a9d57d3  jmp 0x000076B67A9D036F
000076b67a9d57d8  int3
000076b67a9d57d9  nop [rax], eax
000076b67a9d57e0  mov rax, [r15+0x40]
000076b67a9d57e4  mov r14, [r15+0x58]
000076b67a9d57e8  lea r12, [rax+r14*1]
000076b67a9d57ec  movaps xmm1, [r15+0x1D0]
000076b67a9d57f4  vmovaps [rsp+0x10], xmm1
000076b67a9d57fa  vmovaps xmm15, [rsp+0x10]
000076b67a9d5800  por xmm1, xmm15
000076b67a9d5805  movaps xmm14, [r15+0x1A0]
000076b67a9d580d  vmovaps [rsp+0x10], xmm14
000076b67a9d5813  vmovaps xmm13, [rsp+0x10]
000076b67a9d5819  por xmm14, xmm13
000076b67a9d581e  lea rax, [r12+0x30]
000076b67a9d5823  mov r11, [r13+rax*1]
000076b67a9d5828  lea rax, [r12+0x38]
000076b67a9d582d  mov r10, [r13+rax*1]
000076b67a9d5832  movq xmm13, r11
000076b67a9d5837  movq xmm12, r10
000076b67a9d583c  movq xmm13, xmm13
000076b67a9d5841  vmovaps [rsp+0x10], xmm13
000076b67a9d5847  movq xmm13, xmm13
000076b67a9d584c  movaps [r15+0x130], xmm13
000076b67a9d5854  movq xmm12, xmm12
000076b67a9d5859  vmovaps [rsp+0x20], xmm12
000076b67a9d585f  movq xmm12, xmm12
000076b67a9d5864  movaps [r15+0x280], xmm12
000076b67a9d586c  movaps xmm13, [r15+0x270]
000076b67a9d5874  vmovaps [rsp+0x30], xmm13
000076b67a9d587a  vmovaps xmm12, [rsp+0x30]
000076b67a9d5880  por xmm13, xmm12
000076b67a9d5885  lea rax, [r12+0x20]
000076b67a9d588a  mov r11, [r13+rax*1]
000076b67a9d588f  lea rax, [r12+0x28]
000076b67a9d5894  mov r10, [r13+rax*1]
000076b67a9d5899  movq xmm12, r11
000076b67a9d589e  movq xmm11, r10
000076b67a9d58a3  movq xmm12, xmm12
000076b67a9d58a8  vmovaps [rsp+0x30], xmm12
000076b67a9d58ae  movq xmm12, xmm12
000076b67a9d58b3  movaps [r15+0x150], xmm12
000076b67a9d58bb  movq xmm11, xmm11
000076b67a9d58c0  vmovaps [rsp+0x40], xmm11
000076b67a9d58c6  movq xmm11, xmm11
000076b67a9d58cb  movaps [r15+0x140], xmm11
000076b67a9d58d3  lea rax, [r12+0x10]
000076b67a9d58d8  mov r11, [r13+rax*1]
000076b67a9d58dd  lea rax, [r12+0x18]
000076b67a9d58e2  mov r10, [r13+rax*1]
000076b67a9d58e7  movq xmm12, r11
000076b67a9d58ec  movq xmm11, r10
000076b67a9d58f1  movq xmm12, xmm12
000076b67a9d58f6  vmovaps [rsp+0x50], xmm12
000076b67a9d58fc  movq xmm12, xmm12
000076b67a9d5901  movaps [r15+0x170], xmm12
000076b67a9d5909  movq xmm11, xmm11
000076b67a9d590e  vmovaps [rsp+0x60], xmm11
000076b67a9d5914  movq xmm11, xmm11
000076b67a9d5919  movaps [r15+0x160], xmm11
000076b67a9d5921  mov rax, [r13+r12*1]
000076b67a9d5926  vmovq xmm12, rax
000076b67a9d592b  vpbroadcastq xmm12, xmm12
000076b67a9d5930  lea rax, [r12+0x08]
000076b67a9d5935  mov r12, [r13+rax*1]
000076b67a9d593a  movq xmm11, r12
000076b67a9d593f  movaps [r15+0x230], xmm11
000076b67a9d5947  mov rax, [r15+0xF8]
000076b67a9d594e  lea r12, [rax+0x50]
000076b67a9d5952  movups xmm11, [r13+r12*1]
000076b67a9d5958  lea r12, [rax+0x60]
000076b67a9d595c  movups xmm10, [r13+r12*1]
000076b67a9d5962  lea r12, [rax+0x30]
000076b67a9d5966  movups xmm9, [r13+r12*1]
000076b67a9d596c  mov r12, [r15+0x50]
000076b67a9d5970  lea r11, [r12+r14*1]
000076b67a9d5974  mov [r15+0x60], r11
000076b67a9d5978  lea r12, [r14+0x40]
000076b67a9d597c  mov [r15+0x58], r12
000076b67a9d5980  movaps xmm8, xmm12
000076b67a9d5984  mulpd xmm8, xmm15
000076b67a9d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000076b67a9d598f  ptest xmm7, xmm7
000076b67a9d5994  jnz 0x000076B67A9D67B7
000076b67a9d599a  movq xmm15, qword ptr [r15+0x230]
000076b67a9d59a3  vmovaps [rsp+0x70], xmm15
000076b67a9d59a9  vpermilpd xmm15, xmm15, 0x00
000076b67a9d59af  movaps xmm7, xmm9
000076b67a9d59b3  mulpd xmm7, xmm15
000076b67a9d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000076b67a9d59bd  ptest xmm6, xmm6
000076b67a9d59c2  jnz 0x000076B67A9D68FB
000076b67a9d59c8  vxorps xmm15, xmm15, xmm15
000076b67a9d59cd  vpbroadcastq xmm15, xmm15
000076b67a9d59d2  movaps xmm9, xmm12
000076b67a9d59d6  mulpd xmm9, xmm10
000076b67a9d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000076b67a9d59e1  ptest xmm6, xmm6
000076b67a9d59e6  jnz 0x000076B67A9D6A3D
000076b67a9d59ec  movaps xmm10, xmm12
000076b67a9d59f0  mulpd xmm10, xmm11
000076b67a9d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000076b67a9d59fb  ptest xmm6, xmm6
000076b67a9d5a00  jnz 0x000076B67A9D6B81
000076b67a9d5a06  movaps xmm11, [r15+0x1F0]
000076b67a9d5a0e  movaps xmm6, xmm12
000076b67a9d5a12  mulpd xmm6, xmm11
000076b67a9d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000076b67a9d5a1c  ptest xmm5, xmm5
000076b67a9d5a21  jnz 0x000076B67A9D6CC5
000076b67a9d5a27  movaps xmm12, [r15+0x2A0]
000076b67a9d5a2f  vmovaps [rsp+0x80], xmm12
000076b67a9d5a38  vmovaps xmm11, [rsp+0x80]
000076b67a9d5a41  por xmm12, xmm11
000076b67a9d5a46  movaps xmm11, [r15+0x250]
000076b67a9d5a4e  vmovaps [rsp+0x80], xmm11
000076b67a9d5a57  vmovaps xmm5, [rsp+0x80]
000076b67a9d5a60  por xmm11, xmm5
000076b67a9d5a65  vmovaps xmm4, [rsp+0x70]
000076b67a9d5a6b  vpermilpd xmm4, xmm4, 0x00
000076b67a9d5a71  movaps xmm3, xmm5
000076b67a9d5a74  mulpd xmm3, xmm4
000076b67a9d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000076b67a9d5a7d  ptest xmm2, xmm2
000076b67a9d5a82  jnz 0x000076B67A9D6E07
000076b67a9d5a88  mov [rsp+0x80], rax
000076b67a9d5a90  xor eax, eax
000076b67a9d5a92  mov r14d, 0x200
000076b67a9d5a98  cmp r12, r14
000076b67a9d5a9b  cmc
000076b67a9d5a9c  lahf
000076b67a9d5a9d  seto al
000076b67a9d5aa0  mov [r15+0x108], eax
000076b67a9d5aa7  movaps xmm5, xmm8
000076b67a9d5aab  addpd xmm5, xmm15
000076b67a9d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000076b67a9d5ab5  ptest xmm4, xmm4
000076b67a9d5aba  jnz 0x000076B67A9D6F47
000076b67a9d5ac0  movaps xmm8, [r15+0x1B0]
000076b67a9d5ac8  movaps xmm4, xmm9
000076b67a9d5acc  addpd xmm4, xmm8
000076b67a9d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000076b67a9d5ad6  ptest xmm2, xmm2
000076b67a9d5adb  jnz 0x000076B67A9D7089
000076b67a9d5ae1  movaps xmm9, xmm10
000076b67a9d5ae5  addpd xmm9, xmm8
000076b67a9d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000076b67a9d5af0  ptest xmm2, xmm2
000076b67a9d5af5  jnz 0x000076B67A9D71CB
000076b67a9d5afb  movaps xmm10, [r15+0x2F0]
000076b67a9d5b03  vmovaps [rsp+0x90], xmm10
000076b67a9d5b0c  vmovaps xmm8, [rsp+0x90]
000076b67a9d5b15  por xmm10, xmm8
000076b67a9d5b1a  movaps xmm8, [r15+0x2E0]
000076b67a9d5b22  vmovaps [rsp+0x90], xmm8
000076b67a9d5b2b  vmovaps xmm2, [rsp+0x90]
000076b67a9d5b34  por xmm8, xmm2
000076b67a9d5b39  movaps xmm2, [r15+0x2D0]
000076b67a9d5b41  vmovaps [rsp+0x90], xmm2
000076b67a9d5b4a  vmovaps [rsp+0xA0], xmm1
000076b67a9d5b53  vmovaps xmm1, [rsp+0x90]
000076b67a9d5b5c  por xmm2, xmm1
000076b67a9d5b60  movaps xmm1, [r15+0x200]
000076b67a9d5b68  vmovaps [rsp+0x90], xmm1
000076b67a9d5b71  vmovaps [rsp+0xB0], xmm15
000076b67a9d5b7a  vmovaps xmm15, [rsp+0x90]
000076b67a9d5b83  por xmm1, xmm15
000076b67a9d5b88  movaps xmm15, [r15+0x1C0]
000076b67a9d5b90  vmovaps [rsp+0x90], xmm15
000076b67a9d5b99  vmovaps [rsp+0xC0], xmm1
000076b67a9d5ba2  vmovaps xmm1, [rsp+0x90]
000076b67a9d5bab  por xmm15, xmm1
000076b67a9d5bb0  movaps xmm1, [r15+0x190]
000076b67a9d5bb8  vmovaps [rsp+0x90], xmm1
000076b67a9d5bc1  vmovaps [rsp+0xD0], xmm15
000076b67a9d5bca  vmovaps xmm15, [rsp+0x90]
000076b67a9d5bd3  por xmm1, xmm15
000076b67a9d5bd8  movaps xmm15, [r15+0x300]
000076b67a9d5be0  vmovaps [rsp+0x90], xmm15
000076b67a9d5be9  vmovaps [rsp+0xE0], xmm1
000076b67a9d5bf2  vmovaps xmm1, [rsp+0x90]
000076b67a9d5bfb  por xmm15, xmm1
000076b67a9d5c00  mov rax, [rsp+0x80]
000076b67a9d5c08  lea r14, [rax+0xA0]
000076b67a9d5c0f  movups xmm1, [r13+r14*1]
000076b67a9d5c15  lea r14, [rax+0xB0]
000076b67a9d5c1c  vmovaps [rsp+0x80], xmm1
000076b67a9d5c25  movups xmm1, [r13+r14*1]
000076b67a9d5c2b  vmovaps [rsp+0x90], xmm1
000076b67a9d5c34  vmovaps [rsp+0xF0], xmm15
000076b67a9d5c3d  vmovaps xmm15, [rsp+0xB0]
000076b67a9d5c46  vmovaps [rsp+0xB0], xmm14
000076b67a9d5c4f  movaps xmm1, xmm6
000076b67a9d5c52  addpd xmm1, xmm15
000076b67a9d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000076b67a9d5c5c  ptest xmm14, xmm14
000076b67a9d5c62  jnz 0x000076B67A9D7323
000076b67a9d5c68  lea r14, [rax+0xF0]
000076b67a9d5c6f  movups xmm15, [r13+r14*1]
000076b67a9d5c75  movaps xmm14, xmm4
000076b67a9d5c79  addpd xmm14, xmm3
000076b67a9d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000076b67a9d5c84  ptest xmm6, xmm6
000076b67a9d5c89  jnz 0x000076B67A9D746E
000076b67a9d5c8f  movaps xmm6, xmm9
000076b67a9d5c93  addpd xmm6, xmm7
000076b67a9d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000076b67a9d5c9c  ptest xmm4, xmm4
000076b67a9d5ca1  jnz 0x000076B67A9D75B0
000076b67a9d5ca7  vmovaps xmm9, [rsp+0x70]
000076b67a9d5cad  vpermilpd xmm9, xmm9, 0x00
000076b67a9d5cb3  vmovaps xmm4, [rsp+0x90]
000076b67a9d5cbc  movaps xmm7, xmm4
000076b67a9d5cbf  mulpd xmm7, xmm9
000076b67a9d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000076b67a9d5cc9  ptest xmm3, xmm3
000076b67a9d5cce  jnz 0x000076B67A9D76F1
000076b67a9d5cd4  vmovaps xmm9, [rsp+0x50]
000076b67a9d5cda  vpermilpd xmm9, xmm9, 0x00
000076b67a9d5ce0  movaps xmm4, xmm15
000076b67a9d5ce4  mulpd xmm4, xmm9
000076b67a9d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000076b67a9d5cee  ptest xmm3, xmm3
000076b67a9d5cf3  jnz 0x000076B67A9D7832
000076b67a9d5cf9  lea r14, [rax+0xE0]
000076b67a9d5d00  movups xmm15, [r13+r14*1]
000076b67a9d5d06  vmovaps xmm9, [rsp+0x70]
000076b67a9d5d0c  vpermilpd xmm9, xmm9, 0x00
000076b67a9d5d12  vmovaps [rsp+0x70], xmm1
000076b67a9d5d18  vmovaps xmm1, [rsp+0x80]
000076b67a9d5d21  vmovaps [rsp+0x80], xmm15
000076b67a9d5d2a  movaps xmm3, xmm1
000076b67a9d5d2d  mulpd xmm3, xmm9
000076b67a9d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000076b67a9d5d37  ptest xmm15, xmm15
000076b67a9d5d3d  jnz 0x000076B67A9D797E
000076b67a9d5d43  vmovaps xmm1, [rsp+0xF0]
000076b67a9d5d4c  vmovaps xmm15, [rsp+0xF0]
000076b67a9d5d55  por xmm1, xmm15
000076b67a9d5d5a  movaps [r15+0x300], xmm1
000076b67a9d5d62  vmovaps xmm15, [rsp+0xE0]
000076b67a9d5d6b  vmovaps xmm9, [rsp+0xE0]
000076b67a9d5d74  por xmm15, xmm9
000076b67a9d5d79  movaps [r15+0x190], xmm15
000076b67a9d5d81  vmovaps xmm9, [rsp+0x50]
000076b67a9d5d87  vpermilpd xmm9, xmm9, 0x00
000076b67a9d5d8d  vmovaps [rsp+0x90], xmm1
000076b67a9d5d96  vmovaps [rsp+0xE0], xmm15
000076b67a9d5d9f  vmovaps xmm15, [rsp+0x80]
000076b67a9d5da8  vmovaps [rsp+0x80], xmm14
000076b67a9d5db1  movaps xmm1, xmm15
000076b67a9d5db5  mulpd xmm1, xmm9
000076b67a9d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000076b67a9d5dbf  ptest xmm14, xmm14
000076b67a9d5dc5  jnz 0x000076B67A9D7ABF
000076b67a9d5dcb  lea r14, [rax+0x90]
000076b67a9d5dd2  movups xmm15, [r13+r14*1]
000076b67a9d5dd8  vmovaps xmm14, [rsp+0xD0]
000076b67a9d5de1  vmovaps xmm9, [rsp+0xD0]
000076b67a9d5dea  por xmm14, xmm9
000076b67a9d5def  movaps [r15+0x1C0], xmm14
000076b67a9d5df7  vmovaps xmm9, [rsp+0xC0]
000076b67a9d5e00  vmovaps [rsp+0xD0], xmm1
000076b67a9d5e09  vmovaps xmm1, [rsp+0xC0]
000076b67a9d5e12  por xmm9, xmm1
000076b67a9d5e17  movaps [r15+0x200], xmm9
000076b67a9d5e1f  vmovaps [rsp+0xC0], xmm2
000076b67a9d5e28  vmovaps xmm1, [rsp+0xC0]
000076b67a9d5e31  por xmm2, xmm1
000076b67a9d5e35  movaps [r15+0x2D0], xmm2
000076b67a9d5e3d  vmovaps [rsp+0xC0], xmm8
000076b67a9d5e46  vmovaps xmm1, [rsp+0xC0]
000076b67a9d5e4f  por xmm8, xmm1
000076b67a9d5e54  movaps [r15+0x2E0], xmm8
000076b67a9d5e5c  vmovaps [rsp+0xC0], xmm15
000076b67a9d5e65  movaps xmm1, xmm5
000076b67a9d5e68  addpd xmm1, xmm7
000076b67a9d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000076b67a9d5e71  ptest xmm15, xmm15
000076b67a9d5e77  jnz 0x000076B67A9D7C0B
000076b67a9d5e7d  vmovaps xmm15, [rsp+0x50]
000076b67a9d5e83  vpermilpd xmm15, xmm15, 0x00
000076b67a9d5e89  vmovaps xmm5, [rsp+0xC0]
000076b67a9d5e92  vmovaps [rsp+0xC0], xmm1
000076b67a9d5e9b  movaps xmm7, xmm5
000076b67a9d5e9e  mulpd xmm7, xmm15
000076b67a9d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000076b67a9d5ea8  ptest xmm1, xmm1
000076b67a9d5ead  jnz 0x000076B67A9D7D4B
000076b67a9d5eb3  lea r14, [rax+0x80]
000076b67a9d5eba  movups xmm1, [r13+r14*1]
000076b67a9d5ec0  vmovaps xmm5, [rsp+0x70]
000076b67a9d5ec6  vmovaps [rsp+0x70], xmm1
000076b67a9d5ecc  movaps xmm15, xmm5
000076b67a9d5ed0  addpd xmm15, xmm3
000076b67a9d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000076b67a9d5edb  ptest xmm1, xmm1
000076b67a9d5ee0  jnz 0x000076B67A9D7E96
000076b67a9d5ee6  vmovaps xmm5, [rsp+0x80]
000076b67a9d5eef  movaps xmm1, xmm5
000076b67a9d5ef2  addpd xmm1, xmm4
000076b67a9d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000076b67a9d5efb  ptest xmm3, xmm3
000076b67a9d5f00  jnz 0x000076B67A9D7FD8
000076b67a9d5f06  vmovaps [rsp+0x80], xmm10
000076b67a9d5f0f  vmovaps xmm5, [rsp+0x80]
000076b67a9d5f18  por xmm10, xmm5
000076b67a9d5f1d  movaps [r15+0x2F0], xmm10
000076b67a9d5f25  vmovaps xmm5, [rsp+0x50]
000076b67a9d5f2b  vpermilpd xmm5, xmm5, 0x00
000076b67a9d5f31  vmovaps xmm3, [rsp+0x70]
000076b67a9d5f37  vmovaps [rsp+0x50], xmm1
000076b67a9d5f3d  movaps xmm4, xmm3
000076b67a9d5f40  mulpd xmm4, xmm5
000076b67a9d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000076b67a9d5f49  ptest xmm1, xmm1
000076b67a9d5f4e  jnz 0x000076B67A9D8118
000076b67a9d5f54  lea r14, [rax+0xD0]
000076b67a9d5f5b  movups xmm1, [r13+r14*1]
000076b67a9d5f61  vmovaps xmm3, [rsp+0xD0]
000076b67a9d5f6a  vmovaps [rsp+0x70], xmm1
000076b67a9d5f70  movaps xmm5, xmm6
000076b67a9d5f73  addpd xmm5, xmm3
000076b67a9d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000076b67a9d5f7c  ptest xmm1, xmm1
000076b67a9d5f81  jnz 0x000076B67A9D8262
000076b67a9d5f87  vmovaps xmm1, [rsp+0x60]
000076b67a9d5f8d  vpermilpd xmm1, xmm1, 0x00
000076b67a9d5f93  movaps xmm6, xmm9
000076b67a9d5f97  mulpd xmm6, xmm1
000076b67a9d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000076b67a9d5fa0  ptest xmm3, xmm3
000076b67a9d5fa5  jnz 0x000076B67A9D83A2
000076b67a9d5fab  movaps [r15+0x260], xmm6
000076b67a9d5fb3  vxorps xmm1, xmm1, xmm1
000076b67a9d5fb7  vpbroadcastq xmm1, xmm1
000076b67a9d5fbc  movaps [r15+0x1B0], xmm1
000076b67a9d5fc4  vmovaps xmm1, [rsp+0x60]
000076b67a9d5fca  vpermilpd xmm1, xmm1, 0x00
000076b67a9d5fd0  vmovaps xmm3, [rsp+0x70]
000076b67a9d5fd6  vmovaps [rsp+0x70], xmm15
000076b67a9d5fdc  movaps xmm9, xmm3
000076b67a9d5fe0  mulpd xmm9, xmm1
000076b67a9d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000076b67a9d5feb  ptest xmm15, xmm15
000076b67a9d5ff1  jnz 0x000076B67A9D84E3
000076b67a9d5ff7  lea r14, [rax+0xC0]
000076b67a9d5ffe  movups xmm1, [r13+r14*1]
000076b67a9d6004  vmovaps xmm3, [rsp+0xC0]
000076b67a9d600d  vmovaps [rsp+0x80], xmm1
000076b67a9d6016  movaps xmm15, xmm3
000076b67a9d601a  addpd xmm15, xmm7
000076b67a9d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000076b67a9d6025  ptest xmm1, xmm1
000076b67a9d602a  jnz 0x000076B67A9D862F
000076b67a9d6030  vmovaps [rsp+0xC0], xmm13
000076b67a9d6039  vmovaps xmm1, [rsp+0xC0]
000076b67a9d6042  por xmm13, xmm1
000076b67a9d6047  movaps [r15+0x270], xmm13
000076b67a9d604f  vmovaps xmm1, [rsp+0xB0]
000076b67a9d6058  vmovaps xmm7, [rsp+0xB0]
000076b67a9d6061  por xmm1, xmm7
000076b67a9d6065  movaps [r15+0x1A0], xmm1
000076b67a9d606d  vmovaps xmm1, [rsp+0x60]
000076b67a9d6073  vpermilpd xmm1, xmm1, 0x00
000076b67a9d6079  vmovaps [rsp+0xB0], xmm1
000076b67a9d6082  vmovaps xmm1, [rsp+0x80]
000076b67a9d608b  vmovaps [rsp+0x80], xmm15
000076b67a9d6094  vmovaps xmm15, [rsp+0xB0]
000076b67a9d609d  vmovaps [rsp+0xB0], xmm14
000076b67a9d60a6  movaps xmm3, xmm1
000076b67a9d60a9  mulpd xmm3, xmm15
000076b67a9d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000076b67a9d60b3  ptest xmm14, xmm14
000076b67a9d60b9  jnz 0x000076B67A9D8771
000076b67a9d60bf  lea r14, [rax+0x20]
000076b67a9d60c3  movups xmm1, [r13+r14*1]
000076b67a9d60c9  movaps [r15+0x110], xmm1
000076b67a9d60d1  vmovaps xmm14, [rsp+0x70]
000076b67a9d60d7  vmovaps [rsp+0x70], xmm1
000076b67a9d60dd  movaps xmm15, xmm14
000076b67a9d60e1  addpd xmm15, xmm4
000076b67a9d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000076b67a9d60ec  ptest xmm1, xmm1
000076b67a9d60f1  jnz 0x000076B67A9D88BC
000076b67a9d60f7  vmovaps xmm1, [rsp+0x60]
000076b67a9d60fd  vpermilpd xmm1, xmm1, 0x00
000076b67a9d6103  movaps xmm14, xmm2
000076b67a9d6107  mulpd xmm14, xmm1
000076b67a9d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000076b67a9d6112  ptest xmm4, xmm4
000076b67a9d6117  jnz 0x000076B67A9D89FF
000076b67a9d611d  vmovaps xmm4, [rsp+0x50]
000076b67a9d6123  movaps xmm1, xmm4
000076b67a9d6126  addpd xmm1, xmm9
000076b67a9d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000076b67a9d6130  ptest xmm2, xmm2
000076b67a9d6135  jnz 0x000076B67A9D8B41
000076b67a9d613b  vmovaps xmm9, [rsp+0x30]
000076b67a9d6141  vpermilpd xmm9, xmm9, 0x00
000076b67a9d6147  vmovaps xmm2, [rsp+0x70]
000076b67a9d614d  vmovaps [rsp+0x50], xmm1
000076b67a9d6153  movaps xmm4, xmm2
000076b67a9d6156  mulpd xmm4, xmm9
000076b67a9d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000076b67a9d6160  ptest xmm1, xmm1
000076b67a9d6165  jnz 0x000076B67A9D8C82
000076b67a9d616b  vmovaps xmm1, [rsp+0x30]
000076b67a9d6171  vpermilpd xmm1, xmm1, 0x00
000076b67a9d6177  vmovaps xmm2, [rsp+0x90]
000076b67a9d6180  vmovaps [rsp+0x60], xmm15
000076b67a9d6186  movaps xmm9, xmm2
000076b67a9d618a  mulpd xmm9, xmm1
000076b67a9d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000076b67a9d6195  ptest xmm15, xmm15
000076b67a9d619b  jnz 0x000076B67A9D8DC3
000076b67a9d61a1  vmovaps xmm15, [rsp+0x80]
000076b67a9d61aa  movaps xmm1, xmm15
000076b67a9d61ae  addpd xmm1, xmm6
000076b67a9d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000076b67a9d61b7  ptest xmm2, xmm2
000076b67a9d61bc  jnz 0x000076B67A9D8F05
000076b67a9d61c2  movaps xmm15, xmm5
000076b67a9d61c6  addpd xmm15, xmm3
000076b67a9d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000076b67a9d61d1  ptest xmm6, xmm6
000076b67a9d61d6  jnz 0x000076B67A9D9046
000076b67a9d61dc  vmovaps xmm6, [rsp+0x30]
000076b67a9d61e2  vpermilpd xmm6, xmm6, 0x00
000076b67a9d61e8  movaps xmm5, xmm8
000076b67a9d61ec  mulpd xmm5, xmm6
000076b67a9d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000076b67a9d61f5  ptest xmm3, xmm3
000076b67a9d61fa  jnz 0x000076B67A9D9188
000076b67a9d6200  vmovaps xmm8, [rsp+0x30]
000076b67a9d6206  vpermilpd xmm8, xmm8, 0x00
000076b67a9d620c  movaps xmm6, xmm10
000076b67a9d6210  mulpd xmm6, xmm8
000076b67a9d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000076b67a9d621a  ptest xmm3, xmm3
000076b67a9d621f  jnz 0x000076B67A9D92C9
000076b67a9d6225  vmovaps xmm8, [rsp+0x60]
000076b67a9d622b  movaps xmm10, xmm8
000076b67a9d622f  addpd xmm10, xmm14
000076b67a9d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000076b67a9d623a  ptest xmm3, xmm3
000076b67a9d623f  jnz 0x000076B67A9D940B
000076b67a9d6245  vmovaps xmm8, [rsp+0x50]
000076b67a9d624b  movaps xmm14, xmm8
000076b67a9d624f  addpd xmm14, xmm4
000076b67a9d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000076b67a9d625a  ptest xmm3, xmm3
000076b67a9d625f  jnz 0x000076B67A9D954F
000076b67a9d6265  vmovaps xmm8, [rsp+0x40]
000076b67a9d626b  vpermilpd xmm8, xmm8, 0x00
000076b67a9d6271  movaps xmm4, xmm13
000076b67a9d6275  mulpd xmm4, xmm8
000076b67a9d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000076b67a9d627f  ptest xmm3, xmm3
000076b67a9d6284  jnz 0x000076B67A9D9692
000076b67a9d628a  movaps xmm13, xmm15
000076b67a9d628e  addpd xmm13, xmm9
000076b67a9d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000076b67a9d6299  ptest xmm8, xmm8
000076b67a9d629f  jnz 0x000076B67A9D97D4
000076b67a9d62a5  movaps xmm15, xmm1
000076b67a9d62a9  addpd xmm15, xmm5
000076b67a9d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000076b67a9d62b4  ptest xmm9, xmm9
000076b67a9d62ba  jnz 0x000076B67A9D9918
000076b67a9d62c0  vmovaps [rsp+0x30], xmm11
000076b67a9d62c6  vmovaps xmm1, [rsp+0x30]
000076b67a9d62cc  por xmm11, xmm1
000076b67a9d62d1  movaps [r15+0x250], xmm11
000076b67a9d62d9  vmovaps [rsp+0x30], xmm12
000076b67a9d62df  vmovaps xmm1, [rsp+0x30]
000076b67a9d62e5  por xmm12, xmm1
000076b67a9d62ea  movaps [r15+0x2A0], xmm12
000076b67a9d62f2  vmovaps xmm1, [rsp+0xA0]
000076b67a9d62fb  vmovaps xmm11, [rsp+0xA0]
000076b67a9d6304  por xmm1, xmm11
000076b67a9d6309  movaps [r15+0x1D0], xmm1
000076b67a9d6311  lea r14, [rax+0x40]
000076b67a9d6315  movups xmm1, [r13+r14*1]
000076b67a9d631b  movaps [r15+0x2C0], xmm1
000076b67a9d6323  vmovaps xmm11, [rsp+0x40]
000076b67a9d6329  vpermilpd xmm11, xmm11, 0x00
000076b67a9d632f  vmovaps xmm8, [rsp+0xE0]
000076b67a9d6338  movaps xmm9, xmm8
000076b67a9d633c  mulpd xmm9, xmm11
000076b67a9d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000076b67a9d6347  ptest xmm5, xmm5
000076b67a9d634c  jnz 0x000076B67A9D9A64
000076b67a9d6352  movaps xmm11, xmm10
000076b67a9d6356  addpd xmm11, xmm6
000076b67a9d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000076b67a9d6361  ptest xmm8, xmm8
000076b67a9d6367  jnz 0x000076B67A9D9BA8
000076b67a9d636d  movaps xmm10, xmm14
000076b67a9d6371  addpd xmm10, xmm4
000076b67a9d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000076b67a9d637c  ptest xmm8, xmm8
000076b67a9d6382  jnz 0x000076B67A9D9CEB
000076b67a9d6388  vmovaps xmm14, [rsp+0x40]
000076b67a9d638e  vpermilpd xmm14, xmm14, 0x00
000076b67a9d6394  movaps xmm8, xmm1
000076b67a9d6398  mulpd xmm8, xmm14
000076b67a9d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000076b67a9d63a3  ptest xmm6, xmm6
000076b67a9d63a8  jnz 0x000076B67A9D9E2E
000076b67a9d63ae  movaps xmm1, [r15+0x2B0]
000076b67a9d63b6  vmovaps xmm14, [rsp+0x40]
000076b67a9d63bc  vpermilpd xmm14, xmm14, 0x00
000076b67a9d63c2  movaps xmm6, xmm1
000076b67a9d63c5  mulpd xmm6, xmm14
000076b67a9d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000076b67a9d63cf  ptest xmm5, xmm5
000076b67a9d63d4  jnz 0x000076B67A9D9F71
000076b67a9d63da  vmovaps xmm1, [rsp+0x10]
000076b67a9d63e0  vpermilpd xmm1, xmm1, 0x00
000076b67a9d63e6  movaps xmm14, xmm12
000076b67a9d63ea  mulpd xmm14, xmm1
000076b67a9d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000076b67a9d63f5  ptest xmm5, xmm5
000076b67a9d63fa  jnz 0x000076B67A9DA0B2
000076b67a9d6400  movaps xmm1, xmm13
000076b67a9d6404  addpd xmm1, xmm9
000076b67a9d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000076b67a9d640e  ptest xmm12, xmm12
000076b67a9d6414  jnz 0x000076B67A9DA1F5
000076b67a9d641a  vmovaps xmm13, [rsp+0x10]
000076b67a9d6420  vpermilpd xmm13, xmm13, 0x00
000076b67a9d6426  movaps xmm12, xmm7
000076b67a9d642a  mulpd xmm12, xmm13
000076b67a9d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000076b67a9d6435  ptest xmm9, xmm9
000076b67a9d643b  jnz 0x000076B67A9DA337
000076b67a9d6441  movaps xmm13, xmm15
000076b67a9d6445  addpd xmm13, xmm8
000076b67a9d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000076b67a9d6450  ptest xmm9, xmm9
000076b67a9d6456  jnz 0x000076B67A9DA47A
000076b67a9d645c  movaps xmm15, [r15+0x290]
000076b67a9d6464  vmovaps xmm9, [rsp+0x10]
000076b67a9d646a  vpermilpd xmm9, xmm9, 0x00
000076b67a9d6470  movaps xmm8, xmm15
000076b67a9d6474  mulpd xmm8, xmm9
000076b67a9d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000076b67a9d647f  ptest xmm7, xmm7
000076b67a9d6484  jnz 0x000076B67A9DA5BE
000076b67a9d648a  movaps xmm15, xmm11
000076b67a9d648e  addpd xmm15, xmm6
000076b67a9d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000076b67a9d6499  ptest xmm9, xmm9
000076b67a9d649f  jnz 0x000076B67A9DA702
000076b67a9d64a5  movaps xmm11, [r15+0x1E0]
000076b67a9d64ad  vmovaps xmm9, [rsp+0x10]
000076b67a9d64b3  vpermilpd xmm9, xmm9, 0x00
000076b67a9d64b9  movaps xmm7, xmm11
000076b67a9d64bd  mulpd xmm7, xmm9
000076b67a9d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000076b67a9d64c7  ptest xmm6, xmm6
000076b67a9d64cc  jnz 0x000076B67A9DA845
000076b67a9d64d2  movaps xmm11, xmm10
000076b67a9d64d6  addpd xmm11, xmm14
000076b67a9d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000076b67a9d64e1  ptest xmm9, xmm9
000076b67a9d64e7  jnz 0x000076B67A9DA987
000076b67a9d64ed  lea r14, [rax+0x70]
000076b67a9d64f1  movups xmm14, [r13+r14*1]
000076b67a9d64f7  movaps [r15+0x240], xmm14
000076b67a9d64ff  movaps xmm10, xmm1
000076b67a9d6503  addpd xmm10, xmm12
000076b67a9d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000076b67a9d650e  ptest xmm9, xmm9
000076b67a9d6514  jnz 0x000076B67A9DAAD5
000076b67a9d651a  movaps [r15+0x170], xmm10
000076b67a9d6522  vmovaps xmm1, [rsp+0x20]
000076b67a9d6528  vpermilpd xmm1, xmm1, 0x00
000076b67a9d652e  movaps xmm12, xmm14
000076b67a9d6532  mulpd xmm12, xmm1
000076b67a9d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000076b67a9d653d  ptest xmm9, xmm9
000076b67a9d6543  jnz 0x000076B67A9DAC18
000076b67a9d6549  vmovaps xmm1, [rsp+0x20]
000076b67a9d654f  vpermilpd xmm1, xmm1, 0x00
000076b67a9d6555  vmovaps xmm9, [rsp+0xB0]
000076b67a9d655e  movaps xmm14, xmm9
000076b67a9d6562  mulpd xmm14, xmm1
000076b67a9d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000076b67a9d656d  ptest xmm6, xmm6
000076b67a9d6572  jnz 0x000076B67A9DAD5B
000076b67a9d6578  movaps [r15+0x180], xmm14
000076b67a9d6580  movaps xmm1, xmm13
000076b67a9d6584  addpd xmm1, xmm8
000076b67a9d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000076b67a9d658e  ptest xmm9, xmm9
000076b67a9d6594  jnz 0x000076B67A9DAE9E
000076b67a9d659a  movaps [r15+0x210], xmm1
000076b67a9d65a2  movups xmm13, [r13+rax*1]
000076b67a9d65a8  lea r14, [rax+0x10]
000076b67a9d65ac  movups xmm9, [r13+r14*1]
000076b67a9d65b2  movaps [r15+0x230], xmm9
000076b67a9d65ba  movaps xmm8, xmm15
000076b67a9d65be  addpd xmm8, xmm7
000076b67a9d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000076b67a9d65c9  ptest xmm6, xmm6
000076b67a9d65ce  jnz 0x000076B67A9DAFF4
000076b67a9d65d4  movaps [r15+0x130], xmm8
000076b67a9d65dc  vmovaps xmm15, [rsp+0x20]
000076b67a9d65e2  vpermilpd xmm15, xmm15, 0x00
000076b67a9d65e8  movaps xmm7, xmm9
000076b67a9d65ec  mulpd xmm7, xmm15
000076b67a9d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000076b67a9d65f6  ptest xmm6, xmm6
000076b67a9d65fb  jnz 0x000076B67A9DB137
000076b67a9d6601  movaps [r15+0x220], xmm7
000076b67a9d6609  vmovaps xmm15, [rsp+0x20]
000076b67a9d660f  vpermilpd xmm15, xmm15, 0x00
000076b67a9d6615  movaps xmm9, xmm13
000076b67a9d6619  mulpd xmm9, xmm15
000076b67a9d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000076b67a9d6624  ptest xmm6, xmm6
000076b67a9d6629  jnz 0x000076B67A9DB279
000076b67a9d662f  movaps xmm15, xmm11
000076b67a9d6633  addpd xmm15, xmm12
000076b67a9d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000076b67a9d663e  ptest xmm13, xmm13
000076b67a9d6644  jnz 0x000076B67A9DB3BD
000076b67a9d664a  movaps [r15+0x140], xmm15
000076b67a9d6652  movaps xmm13, xmm10
000076b67a9d6656  addpd xmm13, xmm14
000076b67a9d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000076b67a9d6661  ptest xmm12, xmm12
000076b67a9d6667  jnz 0x000076B67A9DB501
000076b67a9d666d  movaps [r15+0x150], xmm13
000076b67a9d6675  movaps xmm14, xmm1
000076b67a9d6679  addpd xmm14, xmm7
000076b67a9d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000076b67a9d6684  ptest xmm12, xmm12
000076b67a9d668a  jnz 0x000076B67A9DB645
000076b67a9d6690  movaps [r15+0x160], xmm14
000076b67a9d6698  movaps xmm1, xmm8
000076b67a9d669c  addpd xmm1, xmm9
000076b67a9d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000076b67a9d66a6  ptest xmm12, xmm12
000076b67a9d66ac  jnz 0x000076B67A9DB787
000076b67a9d66b2  movaps [r15+0x120], xmm1
000076b67a9d66ba  movups [r13+r11*1], xmm15
000076b67a9d66c0  lea rax, [r11+0x10]
000076b67a9d66c4  movups [r13+rax*1], xmm13
000076b67a9d66ca  lea rax, [r11+0x20]
000076b67a9d66ce  movups [r13+rax*1], xmm14
000076b67a9d66d4  lea rax, [r11+0x30]
000076b67a9d66d8  movups [r13+rax*1], xmm1
000076b67a9d66de  mov eax, [r15+0x108]
000076b67a9d66e5  sahf
000076b67a9d66e6  jnz 0x000076B67A9D6718
000076b67a9d66e8  cmp dword ptr [r15+0x318], 0x00
000076b67a9d66f0  jz 0x000076B67A9DB900
000076b67a9d66f6  nop [rax+rax*1], ax
000076b67a9d66ff  nop [rax+rax*1], eax
000076b67a9d6707  mov eax, 0x410444
000076b67a9d670c  mov [r15+0x100], rax
000076b67a9d6713  jmp 0x000076B67A7FE110
000076b67a9d6718  cmp dword ptr [r15+0x318], 0x00
000076b67a9d6720  jz 0x000076B67A9D57E0
000076b67a9d6726  nop [rax+rax*1], ax
000076b67a9d672f  nop [rax+rax*1], eax
000076b67a9d6737  mov eax, 0x410278
000076b67a9d673c  mov [r15+0x100], rax
000076b67a9d6743  jmp 0x000076B67A7FE110
000076b67a9d6748  int3
000076b67a9d6749  call 0x000076B67A80A4B0
000076b67a9d674e  jmp 0x000076B67A9D5828
000076b67a9d6753  call 0x000076B67A809240
000076b67a9d6758  jmp 0x000076B67A9D5832
000076b67a9d675d  call 0x000076B67A80A4B0
000076b67a9d6762  jmp 0x000076B67A9D588F
000076b67a9d6767  call 0x000076B67A809240
000076b67a9d676c  jmp 0x000076B67A9D5899
000076b67a9d6771  call 0x000076B67A80A4B0
000076b67a9d6776  jmp 0x000076B67A9D58DD
000076b67a9d677b  call 0x000076B67A809240
000076b67a9d6780  jmp 0x000076B67A9D58E7
000076b67a9d6785  call 0x000076B67A8B47C0
000076b67a9d678a  jmp 0x000076B67A9D5926
000076b67a9d678f  call 0x000076B67A80B720
000076b67a9d6794  jmp 0x000076B67A9D593A
000076b67a9d6799  call 0x000076B67A8BFC30
000076b67a9d679e  jmp 0x000076B67A9D5958
000076b67a9d67a3  call 0x000076B67A8BE9C0
000076b67a9d67a8  jmp 0x000076B67A9D5962
000076b67a9d67ad  call 0x000076B67A8BD750
000076b67a9d67b2  jmp 0x000076B67A9D596C
000076b67a9d67b7  sub rsp, 0x08
000076b67a9d67bb  push rax
000076b67a9d67bc  push rcx
000076b67a9d67bd  push rdx
000076b67a9d67be  push rdi
000076b67a9d67bf  push rsi
000076b67a9d67c0  push r8
000076b67a9d67c2  push r9
000076b67a9d67c4  push r10
000076b67a9d67c6  push r11
000076b67a9d67c8  sub rsp, 0xF0
000076b67a9d67cf  vmovaps [rsp], xmm0
000076b67a9d67d4  vmovaps [rsp+0x10], xmm1
000076b67a9d67da  vmovaps [rsp+0x20], xmm2
000076b67a9d67e0  vmovaps [rsp+0x30], xmm3
000076b67a9d67e6  vmovaps [rsp+0x40], xmm4
000076b67a9d67ec  vmovaps [rsp+0x50], xmm5
000076b67a9d67f2  vmovaps [rsp+0x60], xmm6
000076b67a9d67f8  vmovaps [rsp+0x70], xmm7
000076b67a9d67fe  vmovaps [rsp+0x80], xmm9
000076b67a9d6807  vmovaps [rsp+0x90], xmm10
000076b67a9d6810  vmovaps [rsp+0xA0], xmm11
000076b67a9d6819  vmovaps [rsp+0xB0], xmm12
000076b67a9d6822  vmovaps [rsp+0xC0], xmm13
000076b67a9d682b  vmovaps [rsp+0xD0], xmm14
000076b67a9d6834  vmovaps [rsp+0xE0], xmm15
000076b67a9d683d  sub rsp, 0x30
000076b67a9d6841  movaps [rsp], xmm8
000076b67a9d6846  movaps [rsp+0x10], xmm12
000076b67a9d684c  movaps [rsp+0x20], xmm15
000076b67a9d6852  lea rdi, [rsp]
000076b67a9d6856  mov esi, 0x00
000076b67a9d685b  mov rax, 0x63C5EF2DF530
000076b67a9d6865  call rax
000076b67a9d6867  movaps xmm8, [rsp]
000076b67a9d686c  add rsp, 0x30
000076b67a9d6870  vmovaps xmm0, [rsp]
000076b67a9d6875  vmovaps xmm1, [rsp+0x10]
000076b67a9d687b  vmovaps xmm2, [rsp+0x20]
000076b67a9d6881  vmovaps xmm3, [rsp+0x30]
000076b67a9d6887  vmovaps xmm4, [rsp+0x40]
000076b67a9d688d  vmovaps xmm5, [rsp+0x50]
000076b67a9d6893  vmovaps xmm6, [rsp+0x60]
000076b67a9d6899  vmovaps xmm7, [rsp+0x70]
000076b67a9d689f  vmovaps xmm9, [rsp+0x80]
000076b67a9d68a8  vmovaps xmm10, [rsp+0x90]
000076b67a9d68b1  vmovaps xmm11, [rsp+0xA0]
000076b67a9d68ba  vmovaps xmm12, [rsp+0xB0]
000076b67a9d68c3  vmovaps xmm13, [rsp+0xC0]
000076b67a9d68cc  vmovaps xmm14, [rsp+0xD0]
000076b67a9d68d5  vmovaps xmm15, [rsp+0xE0]
000076b67a9d68de  add rsp, 0xF0
000076b67a9d68e5  pop r11
000076b67a9d68e7  pop r10
000076b67a9d68e9  pop r9
000076b67a9d68eb  pop r8
000076b67a9d68ed  pop rsi
000076b67a9d68ee  pop rdi
000076b67a9d68ef  pop rdx
000076b67a9d68f0  pop rcx
000076b67a9d68f1  pop rax
000076b67a9d68f2  add rsp, 0x08
000076b67a9d68f6  jmp 0x000076B67A9D599A
000076b67a9d68fb  sub rsp, 0x08
000076b67a9d68ff  push rax
000076b67a9d6900  push rcx
000076b67a9d6901  push rdx
000076b67a9d6902  push rdi
000076b67a9d6903  push rsi
000076b67a9d6904  push r8
000076b67a9d6906  push r9
000076b67a9d6908  push r10
000076b67a9d690a  push r11
000076b67a9d690c  sub rsp, 0xF0
000076b67a9d6913  vmovaps [rsp], xmm0
000076b67a9d6918  vmovaps [rsp+0x10], xmm1
000076b67a9d691e  vmovaps [rsp+0x20], xmm2
000076b67a9d6924  vmovaps [rsp+0x30], xmm3
000076b67a9d692a  vmovaps [rsp+0x40], xmm4
000076b67a9d6930  vmovaps [rsp+0x50], xmm5
000076b67a9d6936  vmovaps [rsp+0x60], xmm6
000076b67a9d693c  vmovaps [rsp+0x70], xmm8
000076b67a9d6942  vmovaps [rsp+0x80], xmm9
000076b67a9d694b  vmovaps [rsp+0x90], xmm10
000076b67a9d6954  vmovaps [rsp+0xA0], xmm11
000076b67a9d695d  vmovaps [rsp+0xB0], xmm12
000076b67a9d6966  vmovaps [rsp+0xC0], xmm13
000076b67a9d696f  vmovaps [rsp+0xD0], xmm14
000076b67a9d6978  vmovaps [rsp+0xE0], xmm15
000076b67a9d6981  sub rsp, 0x30
000076b67a9d6985  movaps [rsp], xmm7
000076b67a9d6989  movaps [rsp+0x10], xmm9
000076b67a9d698f  movaps [rsp+0x20], xmm15
000076b67a9d6995  lea rdi, [rsp]
000076b67a9d6999  mov esi, 0x00
000076b67a9d699e  mov rax, 0x63C5EF2DF530
000076b67a9d69a8  call rax
000076b67a9d69aa  movaps xmm7, [rsp]
000076b67a9d69ae  add rsp, 0x30
000076b67a9d69b2  vmovaps xmm0, [rsp]
000076b67a9d69b7  vmovaps xmm1, [rsp+0x10]
000076b67a9d69bd  vmovaps xmm2, [rsp+0x20]
000076b67a9d69c3  vmovaps xmm3, [rsp+0x30]
000076b67a9d69c9  vmovaps xmm4, [rsp+0x40]
000076b67a9d69cf  vmovaps xmm5, [rsp+0x50]
000076b67a9d69d5  vmovaps xmm6, [rsp+0x60]
000076b67a9d69db  vmovaps xmm8, [rsp+0x70]
000076b67a9d69e1  vmovaps xmm9, [rsp+0x80]
000076b67a9d69ea  vmovaps xmm10, [rsp+0x90]
000076b67a9d69f3  vmovaps xmm11, [rsp+0xA0]
000076b67a9d69fc  vmovaps xmm12, [rsp+0xB0]
000076b67a9d6a05  vmovaps xmm13, [rsp+0xC0]
000076b67a9d6a0e  vmovaps xmm14, [rsp+0xD0]
000076b67a9d6a17  vmovaps xmm15, [rsp+0xE0]
000076b67a9d6a20  add rsp, 0xF0
000076b67a9d6a27  pop r11
000076b67a9d6a29  pop r10
000076b67a9d6a2b  pop r9
000076b67a9d6a2d  pop r8
000076b67a9d6a2f  pop rsi
000076b67a9d6a30  pop rdi
000076b67a9d6a31  pop rdx
000076b67a9d6a32  pop rcx
000076b67a9d6a33  pop rax
000076b67a9d6a34  add rsp, 0x08
000076b67a9d6a38  jmp 0x000076B67A9D59C8
000076b67a9d6a3d  sub rsp, 0x08
000076b67a9d6a41  push rax
000076b67a9d6a42  push rcx
000076b67a9d6a43  push rdx
000076b67a9d6a44  push rdi
000076b67a9d6a45  push rsi
000076b67a9d6a46  push r8
000076b67a9d6a48  push r9
000076b67a9d6a4a  push r10
000076b67a9d6a4c  push r11
000076b67a9d6a4e  sub rsp, 0xF0
000076b67a9d6a55  vmovaps [rsp], xmm0
000076b67a9d6a5a  vmovaps [rsp+0x10], xmm1
000076b67a9d6a60  vmovaps [rsp+0x20], xmm2
000076b67a9d6a66  vmovaps [rsp+0x30], xmm3
000076b67a9d6a6c  vmovaps [rsp+0x40], xmm4
000076b67a9d6a72  vmovaps [rsp+0x50], xmm5
000076b67a9d6a78  vmovaps [rsp+0x60], xmm6
000076b67a9d6a7e  vmovaps [rsp+0x70], xmm7
000076b67a9d6a84  vmovaps [rsp+0x80], xmm8
000076b67a9d6a8d  vmovaps [rsp+0x90], xmm10
000076b67a9d6a96  vmovaps [rsp+0xA0], xmm11
000076b67a9d6a9f  vmovaps [rsp+0xB0], xmm12
000076b67a9d6aa8  vmovaps [rsp+0xC0], xmm13
000076b67a9d6ab1  vmovaps [rsp+0xD0], xmm14
000076b67a9d6aba  vmovaps [rsp+0xE0], xmm15
000076b67a9d6ac3  sub rsp, 0x30
000076b67a9d6ac7  movaps [rsp], xmm9
000076b67a9d6acc  movaps [rsp+0x10], xmm12
000076b67a9d6ad2  movaps [rsp+0x20], xmm10
000076b67a9d6ad8  lea rdi, [rsp]
000076b67a9d6adc  mov esi, 0x00
000076b67a9d6ae1  mov rax, 0x63C5EF2DF530
000076b67a9d6aeb  call rax
000076b67a9d6aed  movaps xmm9, [rsp]
000076b67a9d6af2  add rsp, 0x30
000076b67a9d6af6  vmovaps xmm0, [rsp]
000076b67a9d6afb  vmovaps xmm1, [rsp+0x10]
000076b67a9d6b01  vmovaps xmm2, [rsp+0x20]
000076b67a9d6b07  vmovaps xmm3, [rsp+0x30]
000076b67a9d6b0d  vmovaps xmm4, [rsp+0x40]
000076b67a9d6b13  vmovaps xmm5, [rsp+0x50]
000076b67a9d6b19  vmovaps xmm6, [rsp+0x60]
000076b67a9d6b1f  vmovaps xmm7, [rsp+0x70]
000076b67a9d6b25  vmovaps xmm8, [rsp+0x80]
000076b67a9d6b2e  vmovaps xmm10, [rsp+0x90]
000076b67a9d6b37  vmovaps xmm11, [rsp+0xA0]
000076b67a9d6b40  vmovaps xmm12, [rsp+0xB0]
000076b67a9d6b49  vmovaps xmm13, [rsp+0xC0]
000076b67a9d6b52  vmovaps xmm14, [rsp+0xD0]
000076b67a9d6b5b  vmovaps xmm15, [rsp+0xE0]
000076b67a9d6b64  add rsp, 0xF0
000076b67a9d6b6b  pop r11
000076b67a9d6b6d  pop r10
000076b67a9d6b6f  pop r9
000076b67a9d6b71  pop r8
000076b67a9d6b73  pop rsi
000076b67a9d6b74  pop rdi
000076b67a9d6b75  pop rdx
000076b67a9d6b76  pop rcx
000076b67a9d6b77  pop rax
000076b67a9d6b78  add rsp, 0x08
000076b67a9d6b7c  jmp 0x000076B67A9D59EC
000076b67a9d6b81  sub rsp, 0x08
000076b67a9d6b85  push rax
000076b67a9d6b86  push rcx
000076b67a9d6b87  push rdx
000076b67a9d6b88  push rdi
000076b67a9d6b89  push rsi
000076b67a9d6b8a  push r8
000076b67a9d6b8c  push r9
000076b67a9d6b8e  push r10
000076b67a9d6b90  push r11
000076b67a9d6b92  sub rsp, 0xF0
000076b67a9d6b99  vmovaps [rsp], xmm0
000076b67a9d6b9e  vmovaps [rsp+0x10], xmm1
000076b67a9d6ba4  vmovaps [rsp+0x20], xmm2
000076b67a9d6baa  vmovaps [rsp+0x30], xmm3
000076b67a9d6bb0  vmovaps [rsp+0x40], xmm4
000076b67a9d6bb6  vmovaps [rsp+0x50], xmm5
000076b67a9d6bbc  vmovaps [rsp+0x60], xmm6
000076b67a9d6bc2  vmovaps [rsp+0x70], xmm7
000076b67a9d6bc8  vmovaps [rsp+0x80], xmm8
000076b67a9d6bd1  vmovaps [rsp+0x90], xmm9
000076b67a9d6bda  vmovaps [rsp+0xA0], xmm11
000076b67a9d6be3  vmovaps [rsp+0xB0], xmm12
000076b67a9d6bec  vmovaps [rsp+0xC0], xmm13
000076b67a9d6bf5  vmovaps [rsp+0xD0], xmm14
000076b67a9d6bfe  vmovaps [rsp+0xE0], xmm15
000076b67a9d6c07  sub rsp, 0x30
000076b67a9d6c0b  movaps [rsp], xmm10
000076b67a9d6c10  movaps [rsp+0x10], xmm12
000076b67a9d6c16  movaps [rsp+0x20], xmm11
000076b67a9d6c1c  lea rdi, [rsp]
000076b67a9d6c20  mov esi, 0x00
000076b67a9d6c25  mov rax, 0x63C5EF2DF530
000076b67a9d6c2f  call rax
000076b67a9d6c31  movaps xmm10, [rsp]
000076b67a9d6c36  add rsp, 0x30
000076b67a9d6c3a  vmovaps xmm0, [rsp]
000076b67a9d6c3f  vmovaps xmm1, [rsp+0x10]
000076b67a9d6c45  vmovaps xmm2, [rsp+0x20]
000076b67a9d6c4b  vmovaps xmm3, [rsp+0x30]
000076b67a9d6c51  vmovaps xmm4, [rsp+0x40]
000076b67a9d6c57  vmovaps xmm5, [rsp+0x50]
000076b67a9d6c5d  vmovaps xmm6, [rsp+0x60]
000076b67a9d6c63  vmovaps xmm7, [rsp+0x70]
000076b67a9d6c69  vmovaps xmm8, [rsp+0x80]
000076b67a9d6c72  vmovaps xmm9, [rsp+0x90]
000076b67a9d6c7b  vmovaps xmm11, [rsp+0xA0]
000076b67a9d6c84  vmovaps xmm12, [rsp+0xB0]
000076b67a9d6c8d  vmovaps xmm13, [rsp+0xC0]
000076b67a9d6c96  vmovaps xmm14, [rsp+0xD0]
000076b67a9d6c9f  vmovaps xmm15, [rsp+0xE0]
000076b67a9d6ca8  add rsp, 0xF0
000076b67a9d6caf  pop r11
000076b67a9d6cb1  pop r10
000076b67a9d6cb3  pop r9
000076b67a9d6cb5  pop r8
000076b67a9d6cb7  pop rsi
000076b67a9d6cb8  pop rdi
000076b67a9d6cb9  pop rdx
000076b67a9d6cba  pop rcx
000076b67a9d6cbb  pop rax
000076b67a9d6cbc  add rsp, 0x08
000076b67a9d6cc0  jmp 0x000076B67A9D5A06
000076b67a9d6cc5  sub rsp, 0x08
000076b67a9d6cc9  push rax
000076b67a9d6cca  push rcx
000076b67a9d6ccb  push rdx
000076b67a9d6ccc  push rdi
000076b67a9d6ccd  push rsi
000076b67a9d6cce  push r8
000076b67a9d6cd0  push r9
000076b67a9d6cd2  push r10
000076b67a9d6cd4  push r11
000076b67a9d6cd6  sub rsp, 0xF0
000076b67a9d6cdd  vmovaps [rsp], xmm0
000076b67a9d6ce2  vmovaps [rsp+0x10], xmm1
000076b67a9d6ce8  vmovaps [rsp+0x20], xmm2
000076b67a9d6cee  vmovaps [rsp+0x30], xmm3
000076b67a9d6cf4  vmovaps [rsp+0x40], xmm4
000076b67a9d6cfa  vmovaps [rsp+0x50], xmm5
000076b67a9d6d00  vmovaps [rsp+0x60], xmm7
000076b67a9d6d06  vmovaps [rsp+0x70], xmm8
000076b67a9d6d0c  vmovaps [rsp+0x80], xmm9
000076b67a9d6d15  vmovaps [rsp+0x90], xmm10
000076b67a9d6d1e  vmovaps [rsp+0xA0], xmm11
000076b67a9d6d27  vmovaps [rsp+0xB0], xmm12
000076b67a9d6d30  vmovaps [rsp+0xC0], xmm13
000076b67a9d6d39  vmovaps [rsp+0xD0], xmm14
000076b67a9d6d42  vmovaps [rsp+0xE0], xmm15
000076b67a9d6d4b  sub rsp, 0x30
000076b67a9d6d4f  movaps [rsp], xmm6
000076b67a9d6d53  movaps [rsp+0x10], xmm12
000076b67a9d6d59  movaps [rsp+0x20], xmm11
000076b67a9d6d5f  lea rdi, [rsp]
000076b67a9d6d63  mov esi, 0x00
000076b67a9d6d68  mov rax, 0x63C5EF2DF530
000076b67a9d6d72  call rax
000076b67a9d6d74  movaps xmm6, [rsp]
000076b67a9d6d78  add rsp, 0x30
000076b67a9d6d7c  vmovaps xmm0, [rsp]
000076b67a9d6d81  vmovaps xmm1, [rsp+0x10]
000076b67a9d6d87  vmovaps xmm2, [rsp+0x20]
000076b67a9d6d8d  vmovaps xmm3, [rsp+0x30]
000076b67a9d6d93  vmovaps xmm4, [rsp+0x40]
000076b67a9d6d99  vmovaps xmm5, [rsp+0x50]
000076b67a9d6d9f  vmovaps xmm7, [rsp+0x60]
000076b67a9d6da5  vmovaps xmm8, [rsp+0x70]
000076b67a9d6dab  vmovaps xmm9, [rsp+0x80]
000076b67a9d6db4  vmovaps xmm10, [rsp+0x90]
000076b67a9d6dbd  vmovaps xmm11, [rsp+0xA0]
000076b67a9d6dc6  vmovaps xmm12, [rsp+0xB0]
000076b67a9d6dcf  vmovaps xmm13, [rsp+0xC0]
000076b67a9d6dd8  vmovaps xmm14, [rsp+0xD0]
000076b67a9d6de1  vmovaps xmm15, [rsp+0xE0]
000076b67a9d6dea  add rsp, 0xF0
000076b67a9d6df1  pop r11
000076b67a9d6df3  pop r10
000076b67a9d6df5  pop r9
000076b67a9d6df7  pop r8
000076b67a9d6df9  pop rsi
000076b67a9d6dfa  pop rdi
000076b67a9d6dfb  pop rdx
000076b67a9d6dfc  pop rcx
000076b67a9d6dfd  pop rax
000076b67a9d6dfe  add rsp, 0x08
000076b67a9d6e02  jmp 0x000076B67A9D5A27
000076b67a9d6e07  sub rsp, 0x08
000076b67a9d6e0b  push rax
000076b67a9d6e0c  push rcx
000076b67a9d6e0d  push rdx
000076b67a9d6e0e  push rdi
000076b67a9d6e0f  push rsi
000076b67a9d6e10  push r8
000076b67a9d6e12  push r9
000076b67a9d6e14  push r10
000076b67a9d6e16  push r11
000076b67a9d6e18  sub rsp, 0xF0
000076b67a9d6e1f  vmovaps [rsp], xmm0
000076b67a9d6e24  vmovaps [rsp+0x10], xmm1
000076b67a9d6e2a  vmovaps [rsp+0x20], xmm2
000076b67a9d6e30  vmovaps [rsp+0x30], xmm4
000076b67a9d6e36  vmovaps [rsp+0x40], xmm5
000076b67a9d6e3c  vmovaps [rsp+0x50], xmm6
000076b67a9d6e42  vmovaps [rsp+0x60], xmm7
000076b67a9d6e48  vmovaps [rsp+0x70], xmm8
000076b67a9d6e4e  vmovaps [rsp+0x80], xmm9
000076b67a9d6e57  vmovaps [rsp+0x90], xmm10
000076b67a9d6e60  vmovaps [rsp+0xA0], xmm11
000076b67a9d6e69  vmovaps [rsp+0xB0], xmm12
000076b67a9d6e72  vmovaps [rsp+0xC0], xmm13
000076b67a9d6e7b  vmovaps [rsp+0xD0], xmm14
000076b67a9d6e84  vmovaps [rsp+0xE0], xmm15
000076b67a9d6e8d  sub rsp, 0x30
000076b67a9d6e91  movaps [rsp], xmm3
000076b67a9d6e95  movaps [rsp+0x10], xmm5
000076b67a9d6e9a  movaps [rsp+0x20], xmm4
000076b67a9d6e9f  lea rdi, [rsp]
000076b67a9d6ea3  mov esi, 0x00
000076b67a9d6ea8  mov rax, 0x63C5EF2DF530
000076b67a9d6eb2  call rax
000076b67a9d6eb4  movaps xmm3, [rsp]
000076b67a9d6eb8  add rsp, 0x30
000076b67a9d6ebc  vmovaps xmm0, [rsp]
000076b67a9d6ec1  vmovaps xmm1, [rsp+0x10]
000076b67a9d6ec7  vmovaps xmm2, [rsp+0x20]
000076b67a9d6ecd  vmovaps xmm4, [rsp+0x30]
000076b67a9d6ed3  vmovaps xmm5, [rsp+0x40]
000076b67a9d6ed9  vmovaps xmm6, [rsp+0x50]
000076b67a9d6edf  vmovaps xmm7, [rsp+0x60]
000076b67a9d6ee5  vmovaps xmm8, [rsp+0x70]
000076b67a9d6eeb  vmovaps xmm9, [rsp+0x80]
000076b67a9d6ef4  vmovaps xmm10, [rsp+0x90]
000076b67a9d6efd  vmovaps xmm11, [rsp+0xA0]
000076b67a9d6f06  vmovaps xmm12, [rsp+0xB0]
000076b67a9d6f0f  vmovaps xmm13, [rsp+0xC0]
000076b67a9d6f18  vmovaps xmm14, [rsp+0xD0]
000076b67a9d6f21  vmovaps xmm15, [rsp+0xE0]
000076b67a9d6f2a  add rsp, 0xF0
000076b67a9d6f31  pop r11
000076b67a9d6f33  pop r10
000076b67a9d6f35  pop r9
000076b67a9d6f37  pop r8
000076b67a9d6f39  pop rsi
000076b67a9d6f3a  pop rdi
000076b67a9d6f3b  pop rdx
000076b67a9d6f3c  pop rcx
000076b67a9d6f3d  pop rax
000076b67a9d6f3e  add rsp, 0x08
000076b67a9d6f42  jmp 0x000076B67A9D5A88
000076b67a9d6f47  sub rsp, 0x08
000076b67a9d6f4b  push rax
000076b67a9d6f4c  push rcx
000076b67a9d6f4d  push rdx
000076b67a9d6f4e  push rdi
000076b67a9d6f4f  push rsi
000076b67a9d6f50  push r8
000076b67a9d6f52  push r9
000076b67a9d6f54  push r10
000076b67a9d6f56  push r11
000076b67a9d6f58  sub rsp, 0xF0
000076b67a9d6f5f  vmovaps [rsp], xmm0
000076b67a9d6f64  vmovaps [rsp+0x10], xmm1
000076b67a9d6f6a  vmovaps [rsp+0x20], xmm2
000076b67a9d6f70  vmovaps [rsp+0x30], xmm3
000076b67a9d6f76  vmovaps [rsp+0x40], xmm4
000076b67a9d6f7c  vmovaps [rsp+0x50], xmm6
000076b67a9d6f82  vmovaps [rsp+0x60], xmm7
000076b67a9d6f88  vmovaps [rsp+0x70], xmm8
000076b67a9d6f8e  vmovaps [rsp+0x80], xmm9
000076b67a9d6f97  vmovaps [rsp+0x90], xmm10
000076b67a9d6fa0  vmovaps [rsp+0xA0], xmm11
000076b67a9d6fa9  vmovaps [rsp+0xB0], xmm12
000076b67a9d6fb2  vmovaps [rsp+0xC0], xmm13
000076b67a9d6fbb  vmovaps [rsp+0xD0], xmm14
000076b67a9d6fc4  vmovaps [rsp+0xE0], xmm15
000076b67a9d6fcd  sub rsp, 0x30
000076b67a9d6fd1  movaps [rsp], xmm5
000076b67a9d6fd5  movaps [rsp+0x10], xmm8
000076b67a9d6fdb  movaps [rsp+0x20], xmm15
000076b67a9d6fe1  lea rdi, [rsp]
000076b67a9d6fe5  mov esi, 0x00
000076b67a9d6fea  mov rax, 0x63C5EF2DF530
000076b67a9d6ff4  call rax
000076b67a9d6ff6  movaps xmm5, [rsp]
000076b67a9d6ffa  add rsp, 0x30
000076b67a9d6ffe  vmovaps xmm0, [rsp]
000076b67a9d7003  vmovaps xmm1, [rsp+0x10]
000076b67a9d7009  vmovaps xmm2, [rsp+0x20]
000076b67a9d700f  vmovaps xmm3, [rsp+0x30]
000076b67a9d7015  vmovaps xmm4, [rsp+0x40]
000076b67a9d701b  vmovaps xmm6, [rsp+0x50]
000076b67a9d7021  vmovaps xmm7, [rsp+0x60]
000076b67a9d7027  vmovaps xmm8, [rsp+0x70]
000076b67a9d702d  vmovaps xmm9, [rsp+0x80]
000076b67a9d7036  vmovaps xmm10, [rsp+0x90]
000076b67a9d703f  vmovaps xmm11, [rsp+0xA0]
000076b67a9d7048  vmovaps xmm12, [rsp+0xB0]
000076b67a9d7051  vmovaps xmm13, [rsp+0xC0]
000076b67a9d705a  vmovaps xmm14, [rsp+0xD0]
000076b67a9d7063  vmovaps xmm15, [rsp+0xE0]
000076b67a9d706c  add rsp, 0xF0
000076b67a9d7073  pop r11
000076b67a9d7075  pop r10
000076b67a9d7077  pop r9
000076b67a9d7079  pop r8
000076b67a9d707b  pop rsi
000076b67a9d707c  pop rdi
000076b67a9d707d  pop rdx
000076b67a9d707e  pop rcx
000076b67a9d707f  pop rax
000076b67a9d7080  add rsp, 0x08
000076b67a9d7084  jmp 0x000076B67A9D5AC0
000076b67a9d7089  sub rsp, 0x08
000076b67a9d708d  push rax
000076b67a9d708e  push rcx
000076b67a9d708f  push rdx
000076b67a9d7090  push rdi
000076b67a9d7091  push rsi
000076b67a9d7092  push r8
000076b67a9d7094  push r9
000076b67a9d7096  push r10
000076b67a9d7098  push r11
000076b67a9d709a  sub rsp, 0xF0
000076b67a9d70a1  vmovaps [rsp], xmm0
000076b67a9d70a6  vmovaps [rsp+0x10], xmm1
000076b67a9d70ac  vmovaps [rsp+0x20], xmm2
000076b67a9d70b2  vmovaps [rsp+0x30], xmm3
000076b67a9d70b8  vmovaps [rsp+0x40], xmm5
000076b67a9d70be  vmovaps [rsp+0x50], xmm6
000076b67a9d70c4  vmovaps [rsp+0x60], xmm7
000076b67a9d70ca  vmovaps [rsp+0x70], xmm8
000076b67a9d70d0  vmovaps [rsp+0x80], xmm9
000076b67a9d70d9  vmovaps [rsp+0x90], xmm10
000076b67a9d70e2  vmovaps [rsp+0xA0], xmm11
000076b67a9d70eb  vmovaps [rsp+0xB0], xmm12
000076b67a9d70f4  vmovaps [rsp+0xC0], xmm13
000076b67a9d70fd  vmovaps [rsp+0xD0], xmm14
000076b67a9d7106  vmovaps [rsp+0xE0], xmm15
000076b67a9d710f  sub rsp, 0x30
000076b67a9d7113  movaps [rsp], xmm4
000076b67a9d7117  movaps [rsp+0x10], xmm9
000076b67a9d711d  movaps [rsp+0x20], xmm8
000076b67a9d7123  lea rdi, [rsp]
000076b67a9d7127  mov esi, 0x00
000076b67a9d712c  mov rax, 0x63C5EF2DF530
000076b67a9d7136  call rax
000076b67a9d7138  movaps xmm4, [rsp]
000076b67a9d713c  add rsp, 0x30
000076b67a9d7140  vmovaps xmm0, [rsp]
000076b67a9d7145  vmovaps xmm1, [rsp+0x10]
000076b67a9d714b  vmovaps xmm2, [rsp+0x20]
000076b67a9d7151  vmovaps xmm3, [rsp+0x30]
000076b67a9d7157  vmovaps xmm5, [rsp+0x40]
000076b67a9d715d  vmovaps xmm6, [rsp+0x50]
000076b67a9d7163  vmovaps xmm7, [rsp+0x60]
000076b67a9d7169  vmovaps xmm8, [rsp+0x70]
000076b67a9d716f  vmovaps xmm9, [rsp+0x80]
000076b67a9d7178  vmovaps xmm10, [rsp+0x90]
000076b67a9d7181  vmovaps xmm11, [rsp+0xA0]
000076b67a9d718a  vmovaps xmm12, [rsp+0xB0]
000076b67a9d7193  vmovaps xmm13, [rsp+0xC0]
000076b67a9d719c  vmovaps xmm14, [rsp+0xD0]
000076b67a9d71a5  vmovaps xmm15, [rsp+0xE0]
000076b67a9d71ae  add rsp, 0xF0
000076b67a9d71b5  pop r11
000076b67a9d71b7  pop r10
000076b67a9d71b9  pop r9
000076b67a9d71bb  pop r8
000076b67a9d71bd  pop rsi
000076b67a9d71be  pop rdi
000076b67a9d71bf  pop rdx
000076b67a9d71c0  pop rcx
000076b67a9d71c1  pop rax
000076b67a9d71c2  add rsp, 0x08
000076b67a9d71c6  jmp 0x000076B67A9D5AE1
000076b67a9d71cb  sub rsp, 0x08
000076b67a9d71cf  push rax
000076b67a9d71d0  push rcx
000076b67a9d71d1  push rdx
000076b67a9d71d2  push rdi
000076b67a9d71d3  push rsi
000076b67a9d71d4  push r8
000076b67a9d71d6  push r9
000076b67a9d71d8  push r10
000076b67a9d71da  push r11
000076b67a9d71dc  sub rsp, 0xF0
000076b67a9d71e3  vmovaps [rsp], xmm0
000076b67a9d71e8  vmovaps [rsp+0x10], xmm1
000076b67a9d71ee  vmovaps [rsp+0x20], xmm2
000076b67a9d71f4  vmovaps [rsp+0x30], xmm3
000076b67a9d71fa  vmovaps [rsp+0x40], xmm4
000076b67a9d7200  vmovaps [rsp+0x50], xmm5
000076b67a9d7206  vmovaps [rsp+0x60], xmm6
000076b67a9d720c  vmovaps [rsp+0x70], xmm7
000076b67a9d7212  vmovaps [rsp+0x80], xmm8
000076b67a9d721b  vmovaps [rsp+0x90], xmm10
000076b67a9d7224  vmovaps [rsp+0xA0], xmm11
000076b67a9d722d  vmovaps [rsp+0xB0], xmm12
000076b67a9d7236  vmovaps [rsp+0xC0], xmm13
000076b67a9d723f  vmovaps [rsp+0xD0], xmm14
000076b67a9d7248  vmovaps [rsp+0xE0], xmm15
000076b67a9d7251  sub rsp, 0x30
000076b67a9d7255  movaps [rsp], xmm9
000076b67a9d725a  movaps [rsp+0x10], xmm10
000076b67a9d7260  movaps [rsp+0x20], xmm8
000076b67a9d7266  lea rdi, [rsp]
000076b67a9d726a  mov esi, 0x00
000076b67a9d726f  mov rax, 0x63C5EF2DF530
000076b67a9d7279  call rax
000076b67a9d727b  movaps xmm9, [rsp]
000076b67a9d7280  add rsp, 0x30
000076b67a9d7284  vmovaps xmm0, [rsp]
000076b67a9d7289  vmovaps xmm1, [rsp+0x10]
000076b67a9d728f  vmovaps xmm2, [rsp+0x20]
000076b67a9d7295  vmovaps xmm3, [rsp+0x30]
000076b67a9d729b  vmovaps xmm4, [rsp+0x40]
000076b67a9d72a1  vmovaps xmm5, [rsp+0x50]
000076b67a9d72a7  vmovaps xmm6, [rsp+0x60]
000076b67a9d72ad  vmovaps xmm7, [rsp+0x70]
000076b67a9d72b3  vmovaps xmm8, [rsp+0x80]
000076b67a9d72bc  vmovaps xmm10, [rsp+0x90]
000076b67a9d72c5  vmovaps xmm11, [rsp+0xA0]
000076b67a9d72ce  vmovaps xmm12, [rsp+0xB0]
000076b67a9d72d7  vmovaps xmm13, [rsp+0xC0]
000076b67a9d72e0  vmovaps xmm14, [rsp+0xD0]
000076b67a9d72e9  vmovaps xmm15, [rsp+0xE0]
000076b67a9d72f2  add rsp, 0xF0
000076b67a9d72f9  pop r11
000076b67a9d72fb  pop r10
000076b67a9d72fd  pop r9
000076b67a9d72ff  pop r8
000076b67a9d7301  pop rsi
000076b67a9d7302  pop rdi
000076b67a9d7303  pop rdx
000076b67a9d7304  pop rcx
000076b67a9d7305  pop rax
000076b67a9d7306  add rsp, 0x08
000076b67a9d730a  jmp 0x000076B67A9D5AFB
000076b67a9d730f  call 0x000076B67A8D64F0
000076b67a9d7314  jmp 0x000076B67A9D5C15
000076b67a9d7319  call 0x000076B67A8D64F0
000076b67a9d731e  jmp 0x000076B67A9D5C2B
000076b67a9d7323  sub rsp, 0x08
000076b67a9d7327  push rax
000076b67a9d7328  push rcx
000076b67a9d7329  push rdx
000076b67a9d732a  push rdi
000076b67a9d732b  push rsi
000076b67a9d732c  push r8
000076b67a9d732e  push r9
000076b67a9d7330  push r10
000076b67a9d7332  push r11
000076b67a9d7334  sub rsp, 0xF0
000076b67a9d733b  vmovaps [rsp], xmm0
000076b67a9d7340  vmovaps [rsp+0x10], xmm2
000076b67a9d7346  vmovaps [rsp+0x20], xmm3
000076b67a9d734c  vmovaps [rsp+0x30], xmm4
000076b67a9d7352  vmovaps [rsp+0x40], xmm5
000076b67a9d7358  vmovaps [rsp+0x50], xmm6
000076b67a9d735e  vmovaps [rsp+0x60], xmm7
000076b67a9d7364  vmovaps [rsp+0x70], xmm8
000076b67a9d736a  vmovaps [rsp+0x80], xmm9
000076b67a9d7373  vmovaps [rsp+0x90], xmm10
000076b67a9d737c  vmovaps [rsp+0xA0], xmm11
000076b67a9d7385  vmovaps [rsp+0xB0], xmm12
000076b67a9d738e  vmovaps [rsp+0xC0], xmm13
000076b67a9d7397  vmovaps [rsp+0xD0], xmm14
000076b67a9d73a0  vmovaps [rsp+0xE0], xmm15
000076b67a9d73a9  sub rsp, 0x30
000076b67a9d73ad  movaps [rsp], xmm1
000076b67a9d73b1  movaps [rsp+0x10], xmm6
000076b67a9d73b6  movaps [rsp+0x20], xmm15
000076b67a9d73bc  lea rdi, [rsp]
000076b67a9d73c0  mov esi, 0x00
000076b67a9d73c5  mov rax, 0x63C5EF2DF530
000076b67a9d73cf  call rax
000076b67a9d73d1  movaps xmm1, [rsp]
000076b67a9d73d5  add rsp, 0x30
000076b67a9d73d9  vmovaps xmm0, [rsp]
000076b67a9d73de  vmovaps xmm2, [rsp+0x10]
000076b67a9d73e4  vmovaps xmm3, [rsp+0x20]
000076b67a9d73ea  vmovaps xmm4, [rsp+0x30]
000076b67a9d73f0  vmovaps xmm5, [rsp+0x40]
000076b67a9d73f6  vmovaps xmm6, [rsp+0x50]
000076b67a9d73fc  vmovaps xmm7, [rsp+0x60]
000076b67a9d7402  vmovaps xmm8, [rsp+0x70]
000076b67a9d7408  vmovaps xmm9, [rsp+0x80]
000076b67a9d7411  vmovaps xmm10, [rsp+0x90]
000076b67a9d741a  vmovaps xmm11, [rsp+0xA0]
000076b67a9d7423  vmovaps xmm12, [rsp+0xB0]
000076b67a9d742c  vmovaps xmm13, [rsp+0xC0]
000076b67a9d7435  vmovaps xmm14, [rsp+0xD0]
000076b67a9d743e  vmovaps xmm15, [rsp+0xE0]
000076b67a9d7447  add rsp, 0xF0
000076b67a9d744e  pop r11
000076b67a9d7450  pop r10
000076b67a9d7452  pop r9
000076b67a9d7454  pop r8
000076b67a9d7456  pop rsi
000076b67a9d7457  pop rdi
000076b67a9d7458  pop rdx
000076b67a9d7459  pop rcx
000076b67a9d745a  pop rax
000076b67a9d745b  add rsp, 0x08
000076b67a9d745f  jmp 0x000076B67A9D5C68
000076b67a9d7464  call 0x000076B67A8E5820
000076b67a9d7469  jmp 0x000076B67A9D5C75
000076b67a9d746e  sub rsp, 0x08
000076b67a9d7472  push rax
000076b67a9d7473  push rcx
000076b67a9d7474  push rdx
000076b67a9d7475  push rdi
000076b67a9d7476  push rsi
000076b67a9d7477  push r8
000076b67a9d7479  push r9
000076b67a9d747b  push r10
000076b67a9d747d  push r11
000076b67a9d747f  sub rsp, 0xF0
000076b67a9d7486  vmovaps [rsp], xmm0
000076b67a9d748b  vmovaps [rsp+0x10], xmm1
000076b67a9d7491  vmovaps [rsp+0x20], xmm2
000076b67a9d7497  vmovaps [rsp+0x30], xmm3
000076b67a9d749d  vmovaps [rsp+0x40], xmm4
000076b67a9d74a3  vmovaps [rsp+0x50], xmm5
000076b67a9d74a9  vmovaps [rsp+0x60], xmm6
000076b67a9d74af  vmovaps [rsp+0x70], xmm7
000076b67a9d74b5  vmovaps [rsp+0x80], xmm8
000076b67a9d74be  vmovaps [rsp+0x90], xmm9
000076b67a9d74c7  vmovaps [rsp+0xA0], xmm10
000076b67a9d74d0  vmovaps [rsp+0xB0], xmm11
000076b67a9d74d9  vmovaps [rsp+0xC0], xmm12
000076b67a9d74e2  vmovaps [rsp+0xD0], xmm13
000076b67a9d74eb  vmovaps [rsp+0xE0], xmm15
000076b67a9d74f4  sub rsp, 0x30
000076b67a9d74f8  movaps [rsp], xmm14
000076b67a9d74fd  movaps [rsp+0x10], xmm4
000076b67a9d7502  movaps [rsp+0x20], xmm3
000076b67a9d7507  lea rdi, [rsp]
000076b67a9d750b  mov esi, 0x00
000076b67a9d7510  mov rax, 0x63C5EF2DF530
000076b67a9d751a  call rax
000076b67a9d751c  movaps xmm14, [rsp]
000076b67a9d7521  add rsp, 0x30
000076b67a9d7525  vmovaps xmm0, [rsp]
000076b67a9d752a  vmovaps xmm1, [rsp+0x10]
000076b67a9d7530  vmovaps xmm2, [rsp+0x20]
000076b67a9d7536  vmovaps xmm3, [rsp+0x30]
000076b67a9d753c  vmovaps xmm4, [rsp+0x40]
000076b67a9d7542  vmovaps xmm5, [rsp+0x50]
000076b67a9d7548  vmovaps xmm6, [rsp+0x60]
000076b67a9d754e  vmovaps xmm7, [rsp+0x70]
000076b67a9d7554  vmovaps xmm8, [rsp+0x80]
000076b67a9d755d  vmovaps xmm9, [rsp+0x90]
000076b67a9d7566  vmovaps xmm10, [rsp+0xA0]
000076b67a9d756f  vmovaps xmm11, [rsp+0xB0]
000076b67a9d7578  vmovaps xmm12, [rsp+0xC0]
000076b67a9d7581  vmovaps xmm13, [rsp+0xD0]
000076b67a9d758a  vmovaps xmm15, [rsp+0xE0]
000076b67a9d7593  add rsp, 0xF0
000076b67a9d759a  pop r11
000076b67a9d759c  pop r10
000076b67a9d759e  pop r9
000076b67a9d75a0  pop r8
000076b67a9d75a2  pop rsi
000076b67a9d75a3  pop rdi
000076b67a9d75a4  pop rdx
000076b67a9d75a5  pop rcx
000076b67a9d75a6  pop rax
000076b67a9d75a7  add rsp, 0x08
000076b67a9d75ab  jmp 0x000076B67A9D5C8F
000076b67a9d75b0  sub rsp, 0x08
000076b67a9d75b4  push rax
000076b67a9d75b5  push rcx
000076b67a9d75b6  push rdx
000076b67a9d75b7  push rdi
000076b67a9d75b8  push rsi
000076b67a9d75b9  push r8
000076b67a9d75bb  push r9
000076b67a9d75bd  push r10
000076b67a9d75bf  push r11
000076b67a9d75c1  sub rsp, 0xF0
000076b67a9d75c8  vmovaps [rsp], xmm0
000076b67a9d75cd  vmovaps [rsp+0x10], xmm1
000076b67a9d75d3  vmovaps [rsp+0x20], xmm2
000076b67a9d75d9  vmovaps [rsp+0x30], xmm3
000076b67a9d75df  vmovaps [rsp+0x40], xmm4
000076b67a9d75e5  vmovaps [rsp+0x50], xmm5
000076b67a9d75eb  vmovaps [rsp+0x60], xmm7
000076b67a9d75f1  vmovaps [rsp+0x70], xmm8
000076b67a9d75f7  vmovaps [rsp+0x80], xmm9
000076b67a9d7600  vmovaps [rsp+0x90], xmm10
000076b67a9d7609  vmovaps [rsp+0xA0], xmm11
000076b67a9d7612  vmovaps [rsp+0xB0], xmm12
000076b67a9d761b  vmovaps [rsp+0xC0], xmm13
000076b67a9d7624  vmovaps [rsp+0xD0], xmm14
000076b67a9d762d  vmovaps [rsp+0xE0], xmm15
000076b67a9d7636  sub rsp, 0x30
000076b67a9d763a  movaps [rsp], xmm6
000076b67a9d763e  movaps [rsp+0x10], xmm9
000076b67a9d7644  movaps [rsp+0x20], xmm7
000076b67a9d7649  lea rdi, [rsp]
000076b67a9d764d  mov esi, 0x00
000076b67a9d7652  mov rax, 0x63C5EF2DF530
000076b67a9d765c  call rax
000076b67a9d765e  movaps xmm6, [rsp]
000076b67a9d7662  add rsp, 0x30
000076b67a9d7666  vmovaps xmm0, [rsp]
000076b67a9d766b  vmovaps xmm1, [rsp+0x10]
000076b67a9d7671  vmovaps xmm2, [rsp+0x20]
000076b67a9d7677  vmovaps xmm3, [rsp+0x30]
000076b67a9d767d  vmovaps xmm4, [rsp+0x40]
000076b67a9d7683  vmovaps xmm5, [rsp+0x50]
000076b67a9d7689  vmovaps xmm7, [rsp+0x60]
000076b67a9d768f  vmovaps xmm8, [rsp+0x70]
000076b67a9d7695  vmovaps xmm9, [rsp+0x80]
000076b67a9d769e  vmovaps xmm10, [rsp+0x90]
000076b67a9d76a7  vmovaps xmm11, [rsp+0xA0]
000076b67a9d76b0  vmovaps xmm12, [rsp+0xB0]
000076b67a9d76b9  vmovaps xmm13, [rsp+0xC0]
000076b67a9d76c2  vmovaps xmm14, [rsp+0xD0]
000076b67a9d76cb  vmovaps xmm15, [rsp+0xE0]
000076b67a9d76d4  add rsp, 0xF0
000076b67a9d76db  pop r11
000076b67a9d76dd  pop r10
000076b67a9d76df  pop r9
000076b67a9d76e1  pop r8
000076b67a9d76e3  pop rsi
000076b67a9d76e4  pop rdi
000076b67a9d76e5  pop rdx
000076b67a9d76e6  pop rcx
000076b67a9d76e7  pop rax
000076b67a9d76e8  add rsp, 0x08
000076b67a9d76ec  jmp 0x000076B67A9D5CA7
000076b67a9d76f1  sub rsp, 0x08
000076b67a9d76f5  push rax
000076b67a9d76f6  push rcx
000076b67a9d76f7  push rdx
000076b67a9d76f8  push rdi
000076b67a9d76f9  push rsi
000076b67a9d76fa  push r8
000076b67a9d76fc  push r9
000076b67a9d76fe  push r10
000076b67a9d7700  push r11
000076b67a9d7702  sub rsp, 0xF0
000076b67a9d7709  vmovaps [rsp], xmm0
000076b67a9d770e  vmovaps [rsp+0x10], xmm1
000076b67a9d7714  vmovaps [rsp+0x20], xmm2
000076b67a9d771a  vmovaps [rsp+0x30], xmm3
000076b67a9d7720  vmovaps [rsp+0x40], xmm4
000076b67a9d7726  vmovaps [rsp+0x50], xmm5
000076b67a9d772c  vmovaps [rsp+0x60], xmm6
000076b67a9d7732  vmovaps [rsp+0x70], xmm8
000076b67a9d7738  vmovaps [rsp+0x80], xmm9
000076b67a9d7741  vmovaps [rsp+0x90], xmm10
000076b67a9d774a  vmovaps [rsp+0xA0], xmm11
000076b67a9d7753  vmovaps [rsp+0xB0], xmm12
000076b67a9d775c  vmovaps [rsp+0xC0], xmm13
000076b67a9d7765  vmovaps [rsp+0xD0], xmm14
000076b67a9d776e  vmovaps [rsp+0xE0], xmm15
000076b67a9d7777  sub rsp, 0x30
000076b67a9d777b  movaps [rsp], xmm7
000076b67a9d777f  movaps [rsp+0x10], xmm4
000076b67a9d7784  movaps [rsp+0x20], xmm9
000076b67a9d778a  lea rdi, [rsp]
000076b67a9d778e  mov esi, 0x00
000076b67a9d7793  mov rax, 0x63C5EF2DF530
000076b67a9d779d  call rax
000076b67a9d779f  movaps xmm7, [rsp]
000076b67a9d77a3  add rsp, 0x30
000076b67a9d77a7  vmovaps xmm0, [rsp]
000076b67a9d77ac  vmovaps xmm1, [rsp+0x10]
000076b67a9d77b2  vmovaps xmm2, [rsp+0x20]
000076b67a9d77b8  vmovaps xmm3, [rsp+0x30]
000076b67a9d77be  vmovaps xmm4, [rsp+0x40]
000076b67a9d77c4  vmovaps xmm5, [rsp+0x50]
000076b67a9d77ca  vmovaps xmm6, [rsp+0x60]
000076b67a9d77d0  vmovaps xmm8, [rsp+0x70]
000076b67a9d77d6  vmovaps xmm9, [rsp+0x80]
000076b67a9d77df  vmovaps xmm10, [rsp+0x90]
000076b67a9d77e8  vmovaps xmm11, [rsp+0xA0]
000076b67a9d77f1  vmovaps xmm12, [rsp+0xB0]
000076b67a9d77fa  vmovaps xmm13, [rsp+0xC0]
000076b67a9d7803  vmovaps xmm14, [rsp+0xD0]
000076b67a9d780c  vmovaps xmm15, [rsp+0xE0]
000076b67a9d7815  add rsp, 0xF0
000076b67a9d781c  pop r11
000076b67a9d781e  pop r10
000076b67a9d7820  pop r9
000076b67a9d7822  pop r8
000076b67a9d7824  pop rsi
000076b67a9d7825  pop rdi
000076b67a9d7826  pop rdx
000076b67a9d7827  pop rcx
000076b67a9d7828  pop rax
000076b67a9d7829  add rsp, 0x08
000076b67a9d782d  jmp 0x000076B67A9D5CD4
000076b67a9d7832  sub rsp, 0x08
000076b67a9d7836  push rax
000076b67a9d7837  push rcx
000076b67a9d7838  push rdx
000076b67a9d7839  push rdi
000076b67a9d783a  push rsi
000076b67a9d783b  push r8
000076b67a9d783d  push r9
000076b67a9d783f  push r10
000076b67a9d7841  push r11
000076b67a9d7843  sub rsp, 0xF0
000076b67a9d784a  vmovaps [rsp], xmm0
000076b67a9d784f  vmovaps [rsp+0x10], xmm1
000076b67a9d7855  vmovaps [rsp+0x20], xmm2
000076b67a9d785b  vmovaps [rsp+0x30], xmm3
000076b67a9d7861  vmovaps [rsp+0x40], xmm5
000076b67a9d7867  vmovaps [rsp+0x50], xmm6
000076b67a9d786d  vmovaps [rsp+0x60], xmm7
000076b67a9d7873  vmovaps [rsp+0x70], xmm8
000076b67a9d7879  vmovaps [rsp+0x80], xmm9
000076b67a9d7882  vmovaps [rsp+0x90], xmm10
000076b67a9d788b  vmovaps [rsp+0xA0], xmm11
000076b67a9d7894  vmovaps [rsp+0xB0], xmm12
000076b67a9d789d  vmovaps [rsp+0xC0], xmm13
000076b67a9d78a6  vmovaps [rsp+0xD0], xmm14
000076b67a9d78af  vmovaps [rsp+0xE0], xmm15
000076b67a9d78b8  sub rsp, 0x30
000076b67a9d78bc  movaps [rsp], xmm4
000076b67a9d78c0  movaps [rsp+0x10], xmm15
000076b67a9d78c6  movaps [rsp+0x20], xmm9
000076b67a9d78cc  lea rdi, [rsp]
000076b67a9d78d0  mov esi, 0x00
000076b67a9d78d5  mov rax, 0x63C5EF2DF530
000076b67a9d78df  call rax
000076b67a9d78e1  movaps xmm4, [rsp]
000076b67a9d78e5  add rsp, 0x30
000076b67a9d78e9  vmovaps xmm0, [rsp]
000076b67a9d78ee  vmovaps xmm1, [rsp+0x10]
000076b67a9d78f4  vmovaps xmm2, [rsp+0x20]
000076b67a9d78fa  vmovaps xmm3, [rsp+0x30]
000076b67a9d7900  vmovaps xmm5, [rsp+0x40]
000076b67a9d7906  vmovaps xmm6, [rsp+0x50]
000076b67a9d790c  vmovaps xmm7, [rsp+0x60]
000076b67a9d7912  vmovaps xmm8, [rsp+0x70]
000076b67a9d7918  vmovaps xmm9, [rsp+0x80]
000076b67a9d7921  vmovaps xmm10, [rsp+0x90]
000076b67a9d792a  vmovaps xmm11, [rsp+0xA0]
000076b67a9d7933  vmovaps xmm12, [rsp+0xB0]
000076b67a9d793c  vmovaps xmm13, [rsp+0xC0]
000076b67a9d7945  vmovaps xmm14, [rsp+0xD0]
000076b67a9d794e  vmovaps xmm15, [rsp+0xE0]
000076b67a9d7957  add rsp, 0xF0
000076b67a9d795e  pop r11
000076b67a9d7960  pop r10
000076b67a9d7962  pop r9
000076b67a9d7964  pop r8
000076b67a9d7966  pop rsi
000076b67a9d7967  pop rdi
000076b67a9d7968  pop rdx
000076b67a9d7969  pop rcx
000076b67a9d796a  pop rax
000076b67a9d796b  add rsp, 0x08
000076b67a9d796f  jmp 0x000076B67A9D5CF9
000076b67a9d7974  call 0x000076B67A8E5820
000076b67a9d7979  jmp 0x000076B67A9D5D06
000076b67a9d797e  sub rsp, 0x08
000076b67a9d7982  push rax
000076b67a9d7983  push rcx
000076b67a9d7984  push rdx
000076b67a9d7985  push rdi
000076b67a9d7986  push rsi
000076b67a9d7987  push r8
000076b67a9d7989  push r9
000076b67a9d798b  push r10
000076b67a9d798d  push r11
000076b67a9d798f  sub rsp, 0xF0
000076b67a9d7996  vmovaps [rsp], xmm0
000076b67a9d799b  vmovaps [rsp+0x10], xmm1
000076b67a9d79a1  vmovaps [rsp+0x20], xmm2
000076b67a9d79a7  vmovaps [rsp+0x30], xmm4
000076b67a9d79ad  vmovaps [rsp+0x40], xmm5
000076b67a9d79b3  vmovaps [rsp+0x50], xmm6
000076b67a9d79b9  vmovaps [rsp+0x60], xmm7
000076b67a9d79bf  vmovaps [rsp+0x70], xmm8
000076b67a9d79c5  vmovaps [rsp+0x80], xmm9
000076b67a9d79ce  vmovaps [rsp+0x90], xmm10
000076b67a9d79d7  vmovaps [rsp+0xA0], xmm11
000076b67a9d79e0  vmovaps [rsp+0xB0], xmm12
000076b67a9d79e9  vmovaps [rsp+0xC0], xmm13
000076b67a9d79f2  vmovaps [rsp+0xD0], xmm14
000076b67a9d79fb  vmovaps [rsp+0xE0], xmm15
000076b67a9d7a04  sub rsp, 0x30
000076b67a9d7a08  movaps [rsp], xmm3
000076b67a9d7a0c  movaps [rsp+0x10], xmm1
000076b67a9d7a11  movaps [rsp+0x20], xmm9
000076b67a9d7a17  lea rdi, [rsp]
000076b67a9d7a1b  mov esi, 0x00
000076b67a9d7a20  mov rax, 0x63C5EF2DF530
000076b67a9d7a2a  call rax
000076b67a9d7a2c  movaps xmm3, [rsp]
000076b67a9d7a30  add rsp, 0x30
000076b67a9d7a34  vmovaps xmm0, [rsp]
000076b67a9d7a39  vmovaps xmm1, [rsp+0x10]
000076b67a9d7a3f  vmovaps xmm2, [rsp+0x20]
000076b67a9d7a45  vmovaps xmm4, [rsp+0x30]
000076b67a9d7a4b  vmovaps xmm5, [rsp+0x40]
000076b67a9d7a51  vmovaps xmm6, [rsp+0x50]
000076b67a9d7a57  vmovaps xmm7, [rsp+0x60]
000076b67a9d7a5d  vmovaps xmm8, [rsp+0x70]
000076b67a9d7a63  vmovaps xmm9, [rsp+0x80]
000076b67a9d7a6c  vmovaps xmm10, [rsp+0x90]
000076b67a9d7a75  vmovaps xmm11, [rsp+0xA0]
000076b67a9d7a7e  vmovaps xmm12, [rsp+0xB0]
000076b67a9d7a87  vmovaps xmm13, [rsp+0xC0]
000076b67a9d7a90  vmovaps xmm14, [rsp+0xD0]
000076b67a9d7a99  vmovaps xmm15, [rsp+0xE0]
000076b67a9d7aa2  add rsp, 0xF0
000076b67a9d7aa9  pop r11
000076b67a9d7aab  pop r10
000076b67a9d7aad  pop r9
000076b67a9d7aaf  pop r8
000076b67a9d7ab1  pop rsi
000076b67a9d7ab2  pop rdi
000076b67a9d7ab3  pop rdx
000076b67a9d7ab4  pop rcx
000076b67a9d7ab5  pop rax
000076b67a9d7ab6  add rsp, 0x08
000076b67a9d7aba  jmp 0x000076B67A9D5D43
000076b67a9d7abf  sub rsp, 0x08
000076b67a9d7ac3  push rax
000076b67a9d7ac4  push rcx
000076b67a9d7ac5  push rdx
000076b67a9d7ac6  push rdi
000076b67a9d7ac7  push rsi
000076b67a9d7ac8  push r8
000076b67a9d7aca  push r9
000076b67a9d7acc  push r10
000076b67a9d7ace  push r11
000076b67a9d7ad0  sub rsp, 0xF0
000076b67a9d7ad7  vmovaps [rsp], xmm0
000076b67a9d7adc  vmovaps [rsp+0x10], xmm2
000076b67a9d7ae2  vmovaps [rsp+0x20], xmm3
000076b67a9d7ae8  vmovaps [rsp+0x30], xmm4
000076b67a9d7aee  vmovaps [rsp+0x40], xmm5
000076b67a9d7af4  vmovaps [rsp+0x50], xmm6
000076b67a9d7afa  vmovaps [rsp+0x60], xmm7
000076b67a9d7b00  vmovaps [rsp+0x70], xmm8
000076b67a9d7b06  vmovaps [rsp+0x80], xmm9
000076b67a9d7b0f  vmovaps [rsp+0x90], xmm10
000076b67a9d7b18  vmovaps [rsp+0xA0], xmm11
000076b67a9d7b21  vmovaps [rsp+0xB0], xmm12
000076b67a9d7b2a  vmovaps [rsp+0xC0], xmm13
000076b67a9d7b33  vmovaps [rsp+0xD0], xmm14
000076b67a9d7b3c  vmovaps [rsp+0xE0], xmm15
000076b67a9d7b45  sub rsp, 0x30
000076b67a9d7b49  movaps [rsp], xmm1
000076b67a9d7b4d  movaps [rsp+0x10], xmm15
000076b67a9d7b53  movaps [rsp+0x20], xmm9
000076b67a9d7b59  lea rdi, [rsp]
000076b67a9d7b5d  mov esi, 0x00
000076b67a9d7b62  mov rax, 0x63C5EF2DF530
000076b67a9d7b6c  call rax
000076b67a9d7b6e  movaps xmm1, [rsp]
000076b67a9d7b72  add rsp, 0x30
000076b67a9d7b76  vmovaps xmm0, [rsp]
000076b67a9d7b7b  vmovaps xmm2, [rsp+0x10]
000076b67a9d7b81  vmovaps xmm3, [rsp+0x20]
000076b67a9d7b87  vmovaps xmm4, [rsp+0x30]
000076b67a9d7b8d  vmovaps xmm5, [rsp+0x40]
000076b67a9d7b93  vmovaps xmm6, [rsp+0x50]
000076b67a9d7b99  vmovaps xmm7, [rsp+0x60]
000076b67a9d7b9f  vmovaps xmm8, [rsp+0x70]
000076b67a9d7ba5  vmovaps xmm9, [rsp+0x80]
000076b67a9d7bae  vmovaps xmm10, [rsp+0x90]
000076b67a9d7bb7  vmovaps xmm11, [rsp+0xA0]
000076b67a9d7bc0  vmovaps xmm12, [rsp+0xB0]
000076b67a9d7bc9  vmovaps xmm13, [rsp+0xC0]
000076b67a9d7bd2  vmovaps xmm14, [rsp+0xD0]
000076b67a9d7bdb  vmovaps xmm15, [rsp+0xE0]
000076b67a9d7be4  add rsp, 0xF0
000076b67a9d7beb  pop r11
000076b67a9d7bed  pop r10
000076b67a9d7bef  pop r9
000076b67a9d7bf1  pop r8
000076b67a9d7bf3  pop rsi
000076b67a9d7bf4  pop rdi
000076b67a9d7bf5  pop rdx
000076b67a9d7bf6  pop rcx
000076b67a9d7bf7  pop rax
000076b67a9d7bf8  add rsp, 0x08
000076b67a9d7bfc  jmp 0x000076B67A9D5DCB
000076b67a9d7c01  call 0x000076B67A8E5820
000076b67a9d7c06  jmp 0x000076B67A9D5DD8
000076b67a9d7c0b  sub rsp, 0x08
000076b67a9d7c0f  push rax
000076b67a9d7c10  push rcx
000076b67a9d7c11  push rdx
000076b67a9d7c12  push rdi
000076b67a9d7c13  push rsi
000076b67a9d7c14  push r8
000076b67a9d7c16  push r9
000076b67a9d7c18  push r10
000076b67a9d7c1a  push r11
000076b67a9d7c1c  sub rsp, 0xF0
000076b67a9d7c23  vmovaps [rsp], xmm0
000076b67a9d7c28  vmovaps [rsp+0x10], xmm2
000076b67a9d7c2e  vmovaps [rsp+0x20], xmm3
000076b67a9d7c34  vmovaps [rsp+0x30], xmm4
000076b67a9d7c3a  vmovaps [rsp+0x40], xmm5
000076b67a9d7c40  vmovaps [rsp+0x50], xmm6
000076b67a9d7c46  vmovaps [rsp+0x60], xmm7
000076b67a9d7c4c  vmovaps [rsp+0x70], xmm8
000076b67a9d7c52  vmovaps [rsp+0x80], xmm9
000076b67a9d7c5b  vmovaps [rsp+0x90], xmm10
000076b67a9d7c64  vmovaps [rsp+0xA0], xmm11
000076b67a9d7c6d  vmovaps [rsp+0xB0], xmm12
000076b67a9d7c76  vmovaps [rsp+0xC0], xmm13
000076b67a9d7c7f  vmovaps [rsp+0xD0], xmm14
000076b67a9d7c88  vmovaps [rsp+0xE0], xmm15
000076b67a9d7c91  sub rsp, 0x30
000076b67a9d7c95  movaps [rsp], xmm1
000076b67a9d7c99  movaps [rsp+0x10], xmm5
000076b67a9d7c9e  movaps [rsp+0x20], xmm7
000076b67a9d7ca3  lea rdi, [rsp]
000076b67a9d7ca7  mov esi, 0x00
000076b67a9d7cac  mov rax, 0x63C5EF2DF530
000076b67a9d7cb6  call rax
000076b67a9d7cb8  movaps xmm1, [rsp]
000076b67a9d7cbc  add rsp, 0x30
000076b67a9d7cc0  vmovaps xmm0, [rsp]
000076b67a9d7cc5  vmovaps xmm2, [rsp+0x10]
000076b67a9d7ccb  vmovaps xmm3, [rsp+0x20]
000076b67a9d7cd1  vmovaps xmm4, [rsp+0x30]
000076b67a9d7cd7  vmovaps xmm5, [rsp+0x40]
000076b67a9d7cdd  vmovaps xmm6, [rsp+0x50]
000076b67a9d7ce3  vmovaps xmm7, [rsp+0x60]
000076b67a9d7ce9  vmovaps xmm8, [rsp+0x70]
000076b67a9d7cef  vmovaps xmm9, [rsp+0x80]
000076b67a9d7cf8  vmovaps xmm10, [rsp+0x90]
000076b67a9d7d01  vmovaps xmm11, [rsp+0xA0]
000076b67a9d7d0a  vmovaps xmm12, [rsp+0xB0]
000076b67a9d7d13  vmovaps xmm13, [rsp+0xC0]
000076b67a9d7d1c  vmovaps xmm14, [rsp+0xD0]
000076b67a9d7d25  vmovaps xmm15, [rsp+0xE0]
000076b67a9d7d2e  add rsp, 0xF0
000076b67a9d7d35  pop r11
000076b67a9d7d37  pop r10
000076b67a9d7d39  pop r9
000076b67a9d7d3b  pop r8
000076b67a9d7d3d  pop rsi
000076b67a9d7d3e  pop rdi
000076b67a9d7d3f  pop rdx
000076b67a9d7d40  pop rcx
000076b67a9d7d41  pop rax
000076b67a9d7d42  add rsp, 0x08
000076b67a9d7d46  jmp 0x000076B67A9D5E7D
000076b67a9d7d4b  sub rsp, 0x08
000076b67a9d7d4f  push rax
000076b67a9d7d50  push rcx
000076b67a9d7d51  push rdx
000076b67a9d7d52  push rdi
000076b67a9d7d53  push rsi
000076b67a9d7d54  push r8
000076b67a9d7d56  push r9
000076b67a9d7d58  push r10
000076b67a9d7d5a  push r11
000076b67a9d7d5c  sub rsp, 0xF0
000076b67a9d7d63  vmovaps [rsp], xmm0
000076b67a9d7d68  vmovaps [rsp+0x10], xmm1
000076b67a9d7d6e  vmovaps [rsp+0x20], xmm2
000076b67a9d7d74  vmovaps [rsp+0x30], xmm3
000076b67a9d7d7a  vmovaps [rsp+0x40], xmm4
000076b67a9d7d80  vmovaps [rsp+0x50], xmm5
000076b67a9d7d86  vmovaps [rsp+0x60], xmm6
000076b67a9d7d8c  vmovaps [rsp+0x70], xmm8
000076b67a9d7d92  vmovaps [rsp+0x80], xmm9
000076b67a9d7d9b  vmovaps [rsp+0x90], xmm10
000076b67a9d7da4  vmovaps [rsp+0xA0], xmm11
000076b67a9d7dad  vmovaps [rsp+0xB0], xmm12
000076b67a9d7db6  vmovaps [rsp+0xC0], xmm13
000076b67a9d7dbf  vmovaps [rsp+0xD0], xmm14
000076b67a9d7dc8  vmovaps [rsp+0xE0], xmm15
000076b67a9d7dd1  sub rsp, 0x30
000076b67a9d7dd5  movaps [rsp], xmm7
000076b67a9d7dd9  movaps [rsp+0x10], xmm5
000076b67a9d7dde  movaps [rsp+0x20], xmm15
000076b67a9d7de4  lea rdi, [rsp]
000076b67a9d7de8  mov esi, 0x00
000076b67a9d7ded  mov rax, 0x63C5EF2DF530
000076b67a9d7df7  call rax
000076b67a9d7df9  movaps xmm7, [rsp]
000076b67a9d7dfd  add rsp, 0x30
000076b67a9d7e01  vmovaps xmm0, [rsp]
000076b67a9d7e06  vmovaps xmm1, [rsp+0x10]
000076b67a9d7e0c  vmovaps xmm2, [rsp+0x20]
000076b67a9d7e12  vmovaps xmm3, [rsp+0x30]
000076b67a9d7e18  vmovaps xmm4, [rsp+0x40]
000076b67a9d7e1e  vmovaps xmm5, [rsp+0x50]
000076b67a9d7e24  vmovaps xmm6, [rsp+0x60]
000076b67a9d7e2a  vmovaps xmm8, [rsp+0x70]
000076b67a9d7e30  vmovaps xmm9, [rsp+0x80]
000076b67a9d7e39  vmovaps xmm10, [rsp+0x90]
000076b67a9d7e42  vmovaps xmm11, [rsp+0xA0]
000076b67a9d7e4b  vmovaps xmm12, [rsp+0xB0]
000076b67a9d7e54  vmovaps xmm13, [rsp+0xC0]
000076b67a9d7e5d  vmovaps xmm14, [rsp+0xD0]
000076b67a9d7e66  vmovaps xmm15, [rsp+0xE0]
000076b67a9d7e6f  add rsp, 0xF0
000076b67a9d7e76  pop r11
000076b67a9d7e78  pop r10
000076b67a9d7e7a  pop r9
000076b67a9d7e7c  pop r8
000076b67a9d7e7e  pop rsi
000076b67a9d7e7f  pop rdi
000076b67a9d7e80  pop rdx
000076b67a9d7e81  pop rcx
000076b67a9d7e82  pop rax
000076b67a9d7e83  add rsp, 0x08
000076b67a9d7e87  jmp 0x000076B67A9D5EB3
000076b67a9d7e8c  call 0x000076B67A8D64F0
000076b67a9d7e91  jmp 0x000076B67A9D5EC0
000076b67a9d7e96  sub rsp, 0x08
000076b67a9d7e9a  push rax
000076b67a9d7e9b  push rcx
000076b67a9d7e9c  push rdx
000076b67a9d7e9d  push rdi
000076b67a9d7e9e  push rsi
000076b67a9d7e9f  push r8
000076b67a9d7ea1  push r9
000076b67a9d7ea3  push r10
000076b67a9d7ea5  push r11
000076b67a9d7ea7  sub rsp, 0xF0
000076b67a9d7eae  vmovaps [rsp], xmm0
000076b67a9d7eb3  vmovaps [rsp+0x10], xmm1
000076b67a9d7eb9  vmovaps [rsp+0x20], xmm2
000076b67a9d7ebf  vmovaps [rsp+0x30], xmm3
000076b67a9d7ec5  vmovaps [rsp+0x40], xmm4
000076b67a9d7ecb  vmovaps [rsp+0x50], xmm5
000076b67a9d7ed1  vmovaps [rsp+0x60], xmm6
000076b67a9d7ed7  vmovaps [rsp+0x70], xmm7
000076b67a9d7edd  vmovaps [rsp+0x80], xmm8
000076b67a9d7ee6  vmovaps [rsp+0x90], xmm9
000076b67a9d7eef  vmovaps [rsp+0xA0], xmm10
000076b67a9d7ef8  vmovaps [rsp+0xB0], xmm11
000076b67a9d7f01  vmovaps [rsp+0xC0], xmm12
000076b67a9d7f0a  vmovaps [rsp+0xD0], xmm13
000076b67a9d7f13  vmovaps [rsp+0xE0], xmm14
000076b67a9d7f1c  sub rsp, 0x30
000076b67a9d7f20  movaps [rsp], xmm15
000076b67a9d7f25  movaps [rsp+0x10], xmm5
000076b67a9d7f2a  movaps [rsp+0x20], xmm3
000076b67a9d7f2f  lea rdi, [rsp]
000076b67a9d7f33  mov esi, 0x00
000076b67a9d7f38  mov rax, 0x63C5EF2DF530
000076b67a9d7f42  call rax
000076b67a9d7f44  movaps xmm15, [rsp]
000076b67a9d7f49  add rsp, 0x30
000076b67a9d7f4d  vmovaps xmm0, [rsp]
000076b67a9d7f52  vmovaps xmm1, [rsp+0x10]
000076b67a9d7f58  vmovaps xmm2, [rsp+0x20]
000076b67a9d7f5e  vmovaps xmm3, [rsp+0x30]
000076b67a9d7f64  vmovaps xmm4, [rsp+0x40]
000076b67a9d7f6a  vmovaps xmm5, [rsp+0x50]
000076b67a9d7f70  vmovaps xmm6, [rsp+0x60]
000076b67a9d7f76  vmovaps xmm7, [rsp+0x70]
000076b67a9d7f7c  vmovaps xmm8, [rsp+0x80]
000076b67a9d7f85  vmovaps xmm9, [rsp+0x90]
000076b67a9d7f8e  vmovaps xmm10, [rsp+0xA0]
000076b67a9d7f97  vmovaps xmm11, [rsp+0xB0]
000076b67a9d7fa0  vmovaps xmm12, [rsp+0xC0]
000076b67a9d7fa9  vmovaps xmm13, [rsp+0xD0]
000076b67a9d7fb2  vmovaps xmm14, [rsp+0xE0]
000076b67a9d7fbb  add rsp, 0xF0
000076b67a9d7fc2  pop r11
000076b67a9d7fc4  pop r10
000076b67a9d7fc6  pop r9
000076b67a9d7fc8  pop r8
000076b67a9d7fca  pop rsi
000076b67a9d7fcb  pop rdi
000076b67a9d7fcc  pop rdx
000076b67a9d7fcd  pop rcx
000076b67a9d7fce  pop rax
000076b67a9d7fcf  add rsp, 0x08
000076b67a9d7fd3  jmp 0x000076B67A9D5EE6
000076b67a9d7fd8  sub rsp, 0x08
000076b67a9d7fdc  push rax
000076b67a9d7fdd  push rcx
000076b67a9d7fde  push rdx
000076b67a9d7fdf  push rdi
000076b67a9d7fe0  push rsi
000076b67a9d7fe1  push r8
000076b67a9d7fe3  push r9
000076b67a9d7fe5  push r10
000076b67a9d7fe7  push r11
000076b67a9d7fe9  sub rsp, 0xF0
000076b67a9d7ff0  vmovaps [rsp], xmm0
000076b67a9d7ff5  vmovaps [rsp+0x10], xmm2
000076b67a9d7ffb  vmovaps [rsp+0x20], xmm3
000076b67a9d8001  vmovaps [rsp+0x30], xmm4
000076b67a9d8007  vmovaps [rsp+0x40], xmm5
000076b67a9d800d  vmovaps [rsp+0x50], xmm6
000076b67a9d8013  vmovaps [rsp+0x60], xmm7
000076b67a9d8019  vmovaps [rsp+0x70], xmm8
000076b67a9d801f  vmovaps [rsp+0x80], xmm9
000076b67a9d8028  vmovaps [rsp+0x90], xmm10
000076b67a9d8031  vmovaps [rsp+0xA0], xmm11
000076b67a9d803a  vmovaps [rsp+0xB0], xmm12
000076b67a9d8043  vmovaps [rsp+0xC0], xmm13
000076b67a9d804c  vmovaps [rsp+0xD0], xmm14
000076b67a9d8055  vmovaps [rsp+0xE0], xmm15
000076b67a9d805e  sub rsp, 0x30
000076b67a9d8062  movaps [rsp], xmm1
000076b67a9d8066  movaps [rsp+0x10], xmm5
000076b67a9d806b  movaps [rsp+0x20], xmm4
000076b67a9d8070  lea rdi, [rsp]
000076b67a9d8074  mov esi, 0x00
000076b67a9d8079  mov rax, 0x63C5EF2DF530
000076b67a9d8083  call rax
000076b67a9d8085  movaps xmm1, [rsp]
000076b67a9d8089  add rsp, 0x30
000076b67a9d808d  vmovaps xmm0, [rsp]
000076b67a9d8092  vmovaps xmm2, [rsp+0x10]
000076b67a9d8098  vmovaps xmm3, [rsp+0x20]
000076b67a9d809e  vmovaps xmm4, [rsp+0x30]
000076b67a9d80a4  vmovaps xmm5, [rsp+0x40]
000076b67a9d80aa  vmovaps xmm6, [rsp+0x50]
000076b67a9d80b0  vmovaps xmm7, [rsp+0x60]
000076b67a9d80b6  vmovaps xmm8, [rsp+0x70]
000076b67a9d80bc  vmovaps xmm9, [rsp+0x80]
000076b67a9d80c5  vmovaps xmm10, [rsp+0x90]
000076b67a9d80ce  vmovaps xmm11, [rsp+0xA0]
000076b67a9d80d7  vmovaps xmm12, [rsp+0xB0]
000076b67a9d80e0  vmovaps xmm13, [rsp+0xC0]
000076b67a9d80e9  vmovaps xmm14, [rsp+0xD0]
000076b67a9d80f2  vmovaps xmm15, [rsp+0xE0]
000076b67a9d80fb  add rsp, 0xF0
000076b67a9d8102  pop r11
000076b67a9d8104  pop r10
000076b67a9d8106  pop r9
000076b67a9d8108  pop r8
000076b67a9d810a  pop rsi
000076b67a9d810b  pop rdi
000076b67a9d810c  pop rdx
000076b67a9d810d  pop rcx
000076b67a9d810e  pop rax
000076b67a9d810f  add rsp, 0x08
000076b67a9d8113  jmp 0x000076B67A9D5F06
000076b67a9d8118  sub rsp, 0x08
000076b67a9d811c  push rax
000076b67a9d811d  push rcx
000076b67a9d811e  push rdx
000076b67a9d811f  push rdi
000076b67a9d8120  push rsi
000076b67a9d8121  push r8
000076b67a9d8123  push r9
000076b67a9d8125  push r10
000076b67a9d8127  push r11
000076b67a9d8129  sub rsp, 0xF0
000076b67a9d8130  vmovaps [rsp], xmm0
000076b67a9d8135  vmovaps [rsp+0x10], xmm1
000076b67a9d813b  vmovaps [rsp+0x20], xmm2
000076b67a9d8141  vmovaps [rsp+0x30], xmm3
000076b67a9d8147  vmovaps [rsp+0x40], xmm5
000076b67a9d814d  vmovaps [rsp+0x50], xmm6
000076b67a9d8153  vmovaps [rsp+0x60], xmm7
000076b67a9d8159  vmovaps [rsp+0x70], xmm8
000076b67a9d815f  vmovaps [rsp+0x80], xmm9
000076b67a9d8168  vmovaps [rsp+0x90], xmm10
000076b67a9d8171  vmovaps [rsp+0xA0], xmm11
000076b67a9d817a  vmovaps [rsp+0xB0], xmm12
000076b67a9d8183  vmovaps [rsp+0xC0], xmm13
000076b67a9d818c  vmovaps [rsp+0xD0], xmm14
000076b67a9d8195  vmovaps [rsp+0xE0], xmm15
000076b67a9d819e  sub rsp, 0x30
000076b67a9d81a2  movaps [rsp], xmm4
000076b67a9d81a6  movaps [rsp+0x10], xmm3
000076b67a9d81ab  movaps [rsp+0x20], xmm5
000076b67a9d81b0  lea rdi, [rsp]
000076b67a9d81b4  mov esi, 0x00
000076b67a9d81b9  mov rax, 0x63C5EF2DF530
000076b67a9d81c3  call rax
000076b67a9d81c5  movaps xmm4, [rsp]
000076b67a9d81c9  add rsp, 0x30
000076b67a9d81cd  vmovaps xmm0, [rsp]
000076b67a9d81d2  vmovaps xmm1, [rsp+0x10]
000076b67a9d81d8  vmovaps xmm2, [rsp+0x20]
000076b67a9d81de  vmovaps xmm3, [rsp+0x30]
000076b67a9d81e4  vmovaps xmm5, [rsp+0x40]
000076b67a9d81ea  vmovaps xmm6, [rsp+0x50]
000076b67a9d81f0  vmovaps xmm7, [rsp+0x60]
000076b67a9d81f6  vmovaps xmm8, [rsp+0x70]
000076b67a9d81fc  vmovaps xmm9, [rsp+0x80]
000076b67a9d8205  vmovaps xmm10, [rsp+0x90]
000076b67a9d820e  vmovaps xmm11, [rsp+0xA0]
000076b67a9d8217  vmovaps xmm12, [rsp+0xB0]
000076b67a9d8220  vmovaps xmm13, [rsp+0xC0]
000076b67a9d8229  vmovaps xmm14, [rsp+0xD0]
000076b67a9d8232  vmovaps xmm15, [rsp+0xE0]
000076b67a9d823b  add rsp, 0xF0
000076b67a9d8242  pop r11
000076b67a9d8244  pop r10
000076b67a9d8246  pop r9
000076b67a9d8248  pop r8
000076b67a9d824a  pop rsi
000076b67a9d824b  pop rdi
000076b67a9d824c  pop rdx
000076b67a9d824d  pop rcx
000076b67a9d824e  pop rax
000076b67a9d824f  add rsp, 0x08
000076b67a9d8253  jmp 0x000076B67A9D5F54
000076b67a9d8258  call 0x000076B67A8D64F0
000076b67a9d825d  jmp 0x000076B67A9D5F61
000076b67a9d8262  sub rsp, 0x08
000076b67a9d8266  push rax
000076b67a9d8267  push rcx
000076b67a9d8268  push rdx
000076b67a9d8269  push rdi
000076b67a9d826a  push rsi
000076b67a9d826b  push r8
000076b67a9d826d  push r9
000076b67a9d826f  push r10
000076b67a9d8271  push r11
000076b67a9d8273  sub rsp, 0xF0
000076b67a9d827a  vmovaps [rsp], xmm0
000076b67a9d827f  vmovaps [rsp+0x10], xmm1
000076b67a9d8285  vmovaps [rsp+0x20], xmm2
000076b67a9d828b  vmovaps [rsp+0x30], xmm3
000076b67a9d8291  vmovaps [rsp+0x40], xmm4
000076b67a9d8297  vmovaps [rsp+0x50], xmm6
000076b67a9d829d  vmovaps [rsp+0x60], xmm7
000076b67a9d82a3  vmovaps [rsp+0x70], xmm8
000076b67a9d82a9  vmovaps [rsp+0x80], xmm9
000076b67a9d82b2  vmovaps [rsp+0x90], xmm10
000076b67a9d82bb  vmovaps [rsp+0xA0], xmm11
000076b67a9d82c4  vmovaps [rsp+0xB0], xmm12
000076b67a9d82cd  vmovaps [rsp+0xC0], xmm13
000076b67a9d82d6  vmovaps [rsp+0xD0], xmm14
000076b67a9d82df  vmovaps [rsp+0xE0], xmm15
000076b67a9d82e8  sub rsp, 0x30
000076b67a9d82ec  movaps [rsp], xmm5
000076b67a9d82f0  movaps [rsp+0x10], xmm6
000076b67a9d82f5  movaps [rsp+0x20], xmm3
000076b67a9d82fa  lea rdi, [rsp]
000076b67a9d82fe  mov esi, 0x00
000076b67a9d8303  mov rax, 0x63C5EF2DF530
000076b67a9d830d  call rax
000076b67a9d830f  movaps xmm5, [rsp]
000076b67a9d8313  add rsp, 0x30
000076b67a9d8317  vmovaps xmm0, [rsp]
000076b67a9d831c  vmovaps xmm1, [rsp+0x10]
000076b67a9d8322  vmovaps xmm2, [rsp+0x20]
000076b67a9d8328  vmovaps xmm3, [rsp+0x30]
000076b67a9d832e  vmovaps xmm4, [rsp+0x40]
000076b67a9d8334  vmovaps xmm6, [rsp+0x50]
000076b67a9d833a  vmovaps xmm7, [rsp+0x60]
000076b67a9d8340  vmovaps xmm8, [rsp+0x70]
000076b67a9d8346  vmovaps xmm9, [rsp+0x80]
000076b67a9d834f  vmovaps xmm10, [rsp+0x90]
000076b67a9d8358  vmovaps xmm11, [rsp+0xA0]
000076b67a9d8361  vmovaps xmm12, [rsp+0xB0]
000076b67a9d836a  vmovaps xmm13, [rsp+0xC0]
000076b67a9d8373  vmovaps xmm14, [rsp+0xD0]
000076b67a9d837c  vmovaps xmm15, [rsp+0xE0]
000076b67a9d8385  add rsp, 0xF0
000076b67a9d838c  pop r11
000076b67a9d838e  pop r10
000076b67a9d8390  pop r9
000076b67a9d8392  pop r8
000076b67a9d8394  pop rsi
000076b67a9d8395  pop rdi
000076b67a9d8396  pop rdx
000076b67a9d8397  pop rcx
000076b67a9d8398  pop rax
000076b67a9d8399  add rsp, 0x08
000076b67a9d839d  jmp 0x000076B67A9D5F87
000076b67a9d83a2  sub rsp, 0x08
000076b67a9d83a6  push rax
000076b67a9d83a7  push rcx
000076b67a9d83a8  push rdx
000076b67a9d83a9  push rdi
000076b67a9d83aa  push rsi
000076b67a9d83ab  push r8
000076b67a9d83ad  push r9
000076b67a9d83af  push r10
000076b67a9d83b1  push r11
000076b67a9d83b3  sub rsp, 0xF0
000076b67a9d83ba  vmovaps [rsp], xmm0
000076b67a9d83bf  vmovaps [rsp+0x10], xmm1
000076b67a9d83c5  vmovaps [rsp+0x20], xmm2
000076b67a9d83cb  vmovaps [rsp+0x30], xmm3
000076b67a9d83d1  vmovaps [rsp+0x40], xmm4
000076b67a9d83d7  vmovaps [rsp+0x50], xmm5
000076b67a9d83dd  vmovaps [rsp+0x60], xmm7
000076b67a9d83e3  vmovaps [rsp+0x70], xmm8
000076b67a9d83e9  vmovaps [rsp+0x80], xmm9
000076b67a9d83f2  vmovaps [rsp+0x90], xmm10
000076b67a9d83fb  vmovaps [rsp+0xA0], xmm11
000076b67a9d8404  vmovaps [rsp+0xB0], xmm12
000076b67a9d840d  vmovaps [rsp+0xC0], xmm13
000076b67a9d8416  vmovaps [rsp+0xD0], xmm14
000076b67a9d841f  vmovaps [rsp+0xE0], xmm15
000076b67a9d8428  sub rsp, 0x30
000076b67a9d842c  movaps [rsp], xmm6
000076b67a9d8430  movaps [rsp+0x10], xmm9
000076b67a9d8436  movaps [rsp+0x20], xmm1
000076b67a9d843b  lea rdi, [rsp]
000076b67a9d843f  mov esi, 0x00
000076b67a9d8444  mov rax, 0x63C5EF2DF530
000076b67a9d844e  call rax
000076b67a9d8450  movaps xmm6, [rsp]
000076b67a9d8454  add rsp, 0x30
000076b67a9d8458  vmovaps xmm0, [rsp]
000076b67a9d845d  vmovaps xmm1, [rsp+0x10]
000076b67a9d8463  vmovaps xmm2, [rsp+0x20]
000076b67a9d8469  vmovaps xmm3, [rsp+0x30]
000076b67a9d846f  vmovaps xmm4, [rsp+0x40]
000076b67a9d8475  vmovaps xmm5, [rsp+0x50]
000076b67a9d847b  vmovaps xmm7, [rsp+0x60]
000076b67a9d8481  vmovaps xmm8, [rsp+0x70]
000076b67a9d8487  vmovaps xmm9, [rsp+0x80]
000076b67a9d8490  vmovaps xmm10, [rsp+0x90]
000076b67a9d8499  vmovaps xmm11, [rsp+0xA0]
000076b67a9d84a2  vmovaps xmm12, [rsp+0xB0]
000076b67a9d84ab  vmovaps xmm13, [rsp+0xC0]
000076b67a9d84b4  vmovaps xmm14, [rsp+0xD0]
000076b67a9d84bd  vmovaps xmm15, [rsp+0xE0]
000076b67a9d84c6  add rsp, 0xF0
000076b67a9d84cd  pop r11
000076b67a9d84cf  pop r10
000076b67a9d84d1  pop r9
000076b67a9d84d3  pop r8
000076b67a9d84d5  pop rsi
000076b67a9d84d6  pop rdi
000076b67a9d84d7  pop rdx
000076b67a9d84d8  pop rcx
000076b67a9d84d9  pop rax
000076b67a9d84da  add rsp, 0x08
000076b67a9d84de  jmp 0x000076B67A9D5FAB
000076b67a9d84e3  sub rsp, 0x08
000076b67a9d84e7  push rax
000076b67a9d84e8  push rcx
000076b67a9d84e9  push rdx
000076b67a9d84ea  push rdi
000076b67a9d84eb  push rsi
000076b67a9d84ec  push r8
000076b67a9d84ee  push r9
000076b67a9d84f0  push r10
000076b67a9d84f2  push r11
000076b67a9d84f4  sub rsp, 0xF0
000076b67a9d84fb  vmovaps [rsp], xmm0
000076b67a9d8500  vmovaps [rsp+0x10], xmm1
000076b67a9d8506  vmovaps [rsp+0x20], xmm2
000076b67a9d850c  vmovaps [rsp+0x30], xmm3
000076b67a9d8512  vmovaps [rsp+0x40], xmm4
000076b67a9d8518  vmovaps [rsp+0x50], xmm5
000076b67a9d851e  vmovaps [rsp+0x60], xmm6
000076b67a9d8524  vmovaps [rsp+0x70], xmm7
000076b67a9d852a  vmovaps [rsp+0x80], xmm8
000076b67a9d8533  vmovaps [rsp+0x90], xmm10
000076b67a9d853c  vmovaps [rsp+0xA0], xmm11
000076b67a9d8545  vmovaps [rsp+0xB0], xmm12
000076b67a9d854e  vmovaps [rsp+0xC0], xmm13
000076b67a9d8557  vmovaps [rsp+0xD0], xmm14
000076b67a9d8560  vmovaps [rsp+0xE0], xmm15
000076b67a9d8569  sub rsp, 0x30
000076b67a9d856d  movaps [rsp], xmm9
000076b67a9d8572  movaps [rsp+0x10], xmm3
000076b67a9d8577  movaps [rsp+0x20], xmm1
000076b67a9d857c  lea rdi, [rsp]
000076b67a9d8580  mov esi, 0x00
000076b67a9d8585  mov rax, 0x63C5EF2DF530
000076b67a9d858f  call rax
000076b67a9d8591  movaps xmm9, [rsp]
000076b67a9d8596  add rsp, 0x30
000076b67a9d859a  vmovaps xmm0, [rsp]
000076b67a9d859f  vmovaps xmm1, [rsp+0x10]
000076b67a9d85a5  vmovaps xmm2, [rsp+0x20]
000076b67a9d85ab  vmovaps xmm3, [rsp+0x30]
000076b67a9d85b1  vmovaps xmm4, [rsp+0x40]
000076b67a9d85b7  vmovaps xmm5, [rsp+0x50]
000076b67a9d85bd  vmovaps xmm6, [rsp+0x60]
000076b67a9d85c3  vmovaps xmm7, [rsp+0x70]
000076b67a9d85c9  vmovaps xmm8, [rsp+0x80]
000076b67a9d85d2  vmovaps xmm10, [rsp+0x90]
000076b67a9d85db  vmovaps xmm11, [rsp+0xA0]
000076b67a9d85e4  vmovaps xmm12, [rsp+0xB0]
000076b67a9d85ed  vmovaps xmm13, [rsp+0xC0]
000076b67a9d85f6  vmovaps xmm14, [rsp+0xD0]
000076b67a9d85ff  vmovaps xmm15, [rsp+0xE0]
000076b67a9d8608  add rsp, 0xF0
000076b67a9d860f  pop r11
000076b67a9d8611  pop r10
000076b67a9d8613  pop r9
000076b67a9d8615  pop r8
000076b67a9d8617  pop rsi
000076b67a9d8618  pop rdi
000076b67a9d8619  pop rdx
000076b67a9d861a  pop rcx
000076b67a9d861b  pop rax
000076b67a9d861c  add rsp, 0x08
000076b67a9d8620  jmp 0x000076B67A9D5FF7
000076b67a9d8625  call 0x000076B67A8D64F0
000076b67a9d862a  jmp 0x000076B67A9D6004
000076b67a9d862f  sub rsp, 0x08
000076b67a9d8633  push rax
000076b67a9d8634  push rcx
000076b67a9d8635  push rdx
000076b67a9d8636  push rdi
000076b67a9d8637  push rsi
000076b67a9d8638  push r8
000076b67a9d863a  push r9
000076b67a9d863c  push r10
000076b67a9d863e  push r11
000076b67a9d8640  sub rsp, 0xF0
000076b67a9d8647  vmovaps [rsp], xmm0
000076b67a9d864c  vmovaps [rsp+0x10], xmm1
000076b67a9d8652  vmovaps [rsp+0x20], xmm2
000076b67a9d8658  vmovaps [rsp+0x30], xmm3
000076b67a9d865e  vmovaps [rsp+0x40], xmm4
000076b67a9d8664  vmovaps [rsp+0x50], xmm5
000076b67a9d866a  vmovaps [rsp+0x60], xmm6
000076b67a9d8670  vmovaps [rsp+0x70], xmm7
000076b67a9d8676  vmovaps [rsp+0x80], xmm8
000076b67a9d867f  vmovaps [rsp+0x90], xmm9
000076b67a9d8688  vmovaps [rsp+0xA0], xmm10
000076b67a9d8691  vmovaps [rsp+0xB0], xmm11
000076b67a9d869a  vmovaps [rsp+0xC0], xmm12
000076b67a9d86a3  vmovaps [rsp+0xD0], xmm13
000076b67a9d86ac  vmovaps [rsp+0xE0], xmm14
000076b67a9d86b5  sub rsp, 0x30
000076b67a9d86b9  movaps [rsp], xmm15
000076b67a9d86be  movaps [rsp+0x10], xmm3
000076b67a9d86c3  movaps [rsp+0x20], xmm7
000076b67a9d86c8  lea rdi, [rsp]
000076b67a9d86cc  mov esi, 0x00
000076b67a9d86d1  mov rax, 0x63C5EF2DF530
000076b67a9d86db  call rax
000076b67a9d86dd  movaps xmm15, [rsp]
000076b67a9d86e2  add rsp, 0x30
000076b67a9d86e6  vmovaps xmm0, [rsp]
000076b67a9d86eb  vmovaps xmm1, [rsp+0x10]
000076b67a9d86f1  vmovaps xmm2, [rsp+0x20]
000076b67a9d86f7  vmovaps xmm3, [rsp+0x30]
000076b67a9d86fd  vmovaps xmm4, [rsp+0x40]
000076b67a9d8703  vmovaps xmm5, [rsp+0x50]
000076b67a9d8709  vmovaps xmm6, [rsp+0x60]
000076b67a9d870f  vmovaps xmm7, [rsp+0x70]
000076b67a9d8715  vmovaps xmm8, [rsp+0x80]
000076b67a9d871e  vmovaps xmm9, [rsp+0x90]
000076b67a9d8727  vmovaps xmm10, [rsp+0xA0]
000076b67a9d8730  vmovaps xmm11, [rsp+0xB0]
000076b67a9d8739  vmovaps xmm12, [rsp+0xC0]
000076b67a9d8742  vmovaps xmm13, [rsp+0xD0]
000076b67a9d874b  vmovaps xmm14, [rsp+0xE0]
000076b67a9d8754  add rsp, 0xF0
000076b67a9d875b  pop r11
000076b67a9d875d  pop r10
000076b67a9d875f  pop r9
000076b67a9d8761  pop r8
000076b67a9d8763  pop rsi
000076b67a9d8764  pop rdi
000076b67a9d8765  pop rdx
000076b67a9d8766  pop rcx
000076b67a9d8767  pop rax
000076b67a9d8768  add rsp, 0x08
000076b67a9d876c  jmp 0x000076B67A9D6030
000076b67a9d8771  sub rsp, 0x08
000076b67a9d8775  push rax
000076b67a9d8776  push rcx
000076b67a9d8777  push rdx
000076b67a9d8778  push rdi
000076b67a9d8779  push rsi
000076b67a9d877a  push r8
000076b67a9d877c  push r9
000076b67a9d877e  push r10
000076b67a9d8780  push r11
000076b67a9d8782  sub rsp, 0xF0
000076b67a9d8789  vmovaps [rsp], xmm0
000076b67a9d878e  vmovaps [rsp+0x10], xmm1
000076b67a9d8794  vmovaps [rsp+0x20], xmm2
000076b67a9d879a  vmovaps [rsp+0x30], xmm4
000076b67a9d87a0  vmovaps [rsp+0x40], xmm5
000076b67a9d87a6  vmovaps [rsp+0x50], xmm6
000076b67a9d87ac  vmovaps [rsp+0x60], xmm7
000076b67a9d87b2  vmovaps [rsp+0x70], xmm8
000076b67a9d87b8  vmovaps [rsp+0x80], xmm9
000076b67a9d87c1  vmovaps [rsp+0x90], xmm10
000076b67a9d87ca  vmovaps [rsp+0xA0], xmm11
000076b67a9d87d3  vmovaps [rsp+0xB0], xmm12
000076b67a9d87dc  vmovaps [rsp+0xC0], xmm13
000076b67a9d87e5  vmovaps [rsp+0xD0], xmm14
000076b67a9d87ee  vmovaps [rsp+0xE0], xmm15
000076b67a9d87f7  sub rsp, 0x30
000076b67a9d87fb  movaps [rsp], xmm3
000076b67a9d87ff  movaps [rsp+0x10], xmm1
000076b67a9d8804  movaps [rsp+0x20], xmm15
000076b67a9d880a  lea rdi, [rsp]
000076b67a9d880e  mov esi, 0x00
000076b67a9d8813  mov rax, 0x63C5EF2DF530
000076b67a9d881d  call rax
000076b67a9d881f  movaps xmm3, [rsp]
000076b67a9d8823  add rsp, 0x30
000076b67a9d8827  vmovaps xmm0, [rsp]
000076b67a9d882c  vmovaps xmm1, [rsp+0x10]
000076b67a9d8832  vmovaps xmm2, [rsp+0x20]
000076b67a9d8838  vmovaps xmm4, [rsp+0x30]
000076b67a9d883e  vmovaps xmm5, [rsp+0x40]
000076b67a9d8844  vmovaps xmm6, [rsp+0x50]
000076b67a9d884a  vmovaps xmm7, [rsp+0x60]
000076b67a9d8850  vmovaps xmm8, [rsp+0x70]
000076b67a9d8856  vmovaps xmm9, [rsp+0x80]
000076b67a9d885f  vmovaps xmm10, [rsp+0x90]
000076b67a9d8868  vmovaps xmm11, [rsp+0xA0]
000076b67a9d8871  vmovaps xmm12, [rsp+0xB0]
000076b67a9d887a  vmovaps xmm13, [rsp+0xC0]
000076b67a9d8883  vmovaps xmm14, [rsp+0xD0]
000076b67a9d888c  vmovaps xmm15, [rsp+0xE0]
000076b67a9d8895  add rsp, 0xF0
000076b67a9d889c  pop r11
000076b67a9d889e  pop r10
000076b67a9d88a0  pop r9
000076b67a9d88a2  pop r8
000076b67a9d88a4  pop rsi
000076b67a9d88a5  pop rdi
000076b67a9d88a6  pop rdx
000076b67a9d88a7  pop rcx
000076b67a9d88a8  pop rax
000076b67a9d88a9  add rsp, 0x08
000076b67a9d88ad  jmp 0x000076B67A9D60BF
000076b67a9d88b2  call 0x000076B67A8D64F0
000076b67a9d88b7  jmp 0x000076B67A9D60C9
000076b67a9d88bc  sub rsp, 0x08
000076b67a9d88c0  push rax
000076b67a9d88c1  push rcx
000076b67a9d88c2  push rdx
000076b67a9d88c3  push rdi
000076b67a9d88c4  push rsi
000076b67a9d88c5  push r8
000076b67a9d88c7  push r9
000076b67a9d88c9  push r10
000076b67a9d88cb  push r11
000076b67a9d88cd  sub rsp, 0xF0
000076b67a9d88d4  vmovaps [rsp], xmm0
000076b67a9d88d9  vmovaps [rsp+0x10], xmm1
000076b67a9d88df  vmovaps [rsp+0x20], xmm2
000076b67a9d88e5  vmovaps [rsp+0x30], xmm3
000076b67a9d88eb  vmovaps [rsp+0x40], xmm4
000076b67a9d88f1  vmovaps [rsp+0x50], xmm5
000076b67a9d88f7  vmovaps [rsp+0x60], xmm6
000076b67a9d88fd  vmovaps [rsp+0x70], xmm7
000076b67a9d8903  vmovaps [rsp+0x80], xmm8
000076b67a9d890c  vmovaps [rsp+0x90], xmm9
000076b67a9d8915  vmovaps [rsp+0xA0], xmm10
000076b67a9d891e  vmovaps [rsp+0xB0], xmm11
000076b67a9d8927  vmovaps [rsp+0xC0], xmm12
000076b67a9d8930  vmovaps [rsp+0xD0], xmm13
000076b67a9d8939  vmovaps [rsp+0xE0], xmm14
000076b67a9d8942  sub rsp, 0x30
000076b67a9d8946  movaps [rsp], xmm15
000076b67a9d894b  movaps [rsp+0x10], xmm14
000076b67a9d8951  movaps [rsp+0x20], xmm4
000076b67a9d8956  lea rdi, [rsp]
000076b67a9d895a  mov esi, 0x00
000076b67a9d895f  mov rax, 0x63C5EF2DF530
000076b67a9d8969  call rax
000076b67a9d896b  movaps xmm15, [rsp]
000076b67a9d8970  add rsp, 0x30
000076b67a9d8974  vmovaps xmm0, [rsp]
000076b67a9d8979  vmovaps xmm1, [rsp+0x10]
000076b67a9d897f  vmovaps xmm2, [rsp+0x20]
000076b67a9d8985  vmovaps xmm3, [rsp+0x30]
000076b67a9d898b  vmovaps xmm4, [rsp+0x40]
000076b67a9d8991  vmovaps xmm5, [rsp+0x50]
000076b67a9d8997  vmovaps xmm6, [rsp+0x60]
000076b67a9d899d  vmovaps xmm7, [rsp+0x70]
000076b67a9d89a3  vmovaps xmm8, [rsp+0x80]
000076b67a9d89ac  vmovaps xmm9, [rsp+0x90]
000076b67a9d89b5  vmovaps xmm10, [rsp+0xA0]
000076b67a9d89be  vmovaps xmm11, [rsp+0xB0]
000076b67a9d89c7  vmovaps xmm12, [rsp+0xC0]
000076b67a9d89d0  vmovaps xmm13, [rsp+0xD0]
000076b67a9d89d9  vmovaps xmm14, [rsp+0xE0]
000076b67a9d89e2  add rsp, 0xF0
000076b67a9d89e9  pop r11
000076b67a9d89eb  pop r10
000076b67a9d89ed  pop r9
000076b67a9d89ef  pop r8
000076b67a9d89f1  pop rsi
000076b67a9d89f2  pop rdi
000076b67a9d89f3  pop rdx
000076b67a9d89f4  pop rcx
000076b67a9d89f5  pop rax
000076b67a9d89f6  add rsp, 0x08
000076b67a9d89fa  jmp 0x000076B67A9D60F7
000076b67a9d89ff  sub rsp, 0x08
000076b67a9d8a03  push rax
000076b67a9d8a04  push rcx
000076b67a9d8a05  push rdx
000076b67a9d8a06  push rdi
000076b67a9d8a07  push rsi
000076b67a9d8a08  push r8
000076b67a9d8a0a  push r9
000076b67a9d8a0c  push r10
000076b67a9d8a0e  push r11
000076b67a9d8a10  sub rsp, 0xF0
000076b67a9d8a17  vmovaps [rsp], xmm0
000076b67a9d8a1c  vmovaps [rsp+0x10], xmm1
000076b67a9d8a22  vmovaps [rsp+0x20], xmm2
000076b67a9d8a28  vmovaps [rsp+0x30], xmm3
000076b67a9d8a2e  vmovaps [rsp+0x40], xmm4
000076b67a9d8a34  vmovaps [rsp+0x50], xmm5
000076b67a9d8a3a  vmovaps [rsp+0x60], xmm6
000076b67a9d8a40  vmovaps [rsp+0x70], xmm7
000076b67a9d8a46  vmovaps [rsp+0x80], xmm8
000076b67a9d8a4f  vmovaps [rsp+0x90], xmm9
000076b67a9d8a58  vmovaps [rsp+0xA0], xmm10
000076b67a9d8a61  vmovaps [rsp+0xB0], xmm11
000076b67a9d8a6a  vmovaps [rsp+0xC0], xmm12
000076b67a9d8a73  vmovaps [rsp+0xD0], xmm13
000076b67a9d8a7c  vmovaps [rsp+0xE0], xmm15
000076b67a9d8a85  sub rsp, 0x30
000076b67a9d8a89  movaps [rsp], xmm14
000076b67a9d8a8e  movaps [rsp+0x10], xmm2
000076b67a9d8a93  movaps [rsp+0x20], xmm1
000076b67a9d8a98  lea rdi, [rsp]
000076b67a9d8a9c  mov esi, 0x00
000076b67a9d8aa1  mov rax, 0x63C5EF2DF530
000076b67a9d8aab  call rax
000076b67a9d8aad  movaps xmm14, [rsp]
000076b67a9d8ab2  add rsp, 0x30
000076b67a9d8ab6  vmovaps xmm0, [rsp]
000076b67a9d8abb  vmovaps xmm1, [rsp+0x10]
000076b67a9d8ac1  vmovaps xmm2, [rsp+0x20]
000076b67a9d8ac7  vmovaps xmm3, [rsp+0x30]
000076b67a9d8acd  vmovaps xmm4, [rsp+0x40]
000076b67a9d8ad3  vmovaps xmm5, [rsp+0x50]
000076b67a9d8ad9  vmovaps xmm6, [rsp+0x60]
000076b67a9d8adf  vmovaps xmm7, [rsp+0x70]
000076b67a9d8ae5  vmovaps xmm8, [rsp+0x80]
000076b67a9d8aee  vmovaps xmm9, [rsp+0x90]
000076b67a9d8af7  vmovaps xmm10, [rsp+0xA0]
000076b67a9d8b00  vmovaps xmm11, [rsp+0xB0]
000076b67a9d8b09  vmovaps xmm12, [rsp+0xC0]
000076b67a9d8b12  vmovaps xmm13, [rsp+0xD0]
000076b67a9d8b1b  vmovaps xmm15, [rsp+0xE0]
000076b67a9d8b24  add rsp, 0xF0
000076b67a9d8b2b  pop r11
000076b67a9d8b2d  pop r10
000076b67a9d8b2f  pop r9
000076b67a9d8b31  pop r8
000076b67a9d8b33  pop rsi
000076b67a9d8b34  pop rdi
000076b67a9d8b35  pop rdx
000076b67a9d8b36  pop rcx
000076b67a9d8b37  pop rax
000076b67a9d8b38  add rsp, 0x08
000076b67a9d8b3c  jmp 0x000076B67A9D611D
000076b67a9d8b41  sub rsp, 0x08
000076b67a9d8b45  push rax
000076b67a9d8b46  push rcx
000076b67a9d8b47  push rdx
000076b67a9d8b48  push rdi
000076b67a9d8b49  push rsi
000076b67a9d8b4a  push r8
000076b67a9d8b4c  push r9
000076b67a9d8b4e  push r10
000076b67a9d8b50  push r11
000076b67a9d8b52  sub rsp, 0xF0
000076b67a9d8b59  vmovaps [rsp], xmm0
000076b67a9d8b5e  vmovaps [rsp+0x10], xmm2
000076b67a9d8b64  vmovaps [rsp+0x20], xmm3
000076b67a9d8b6a  vmovaps [rsp+0x30], xmm4
000076b67a9d8b70  vmovaps [rsp+0x40], xmm5
000076b67a9d8b76  vmovaps [rsp+0x50], xmm6
000076b67a9d8b7c  vmovaps [rsp+0x60], xmm7
000076b67a9d8b82  vmovaps [rsp+0x70], xmm8
000076b67a9d8b88  vmovaps [rsp+0x80], xmm9
000076b67a9d8b91  vmovaps [rsp+0x90], xmm10
000076b67a9d8b9a  vmovaps [rsp+0xA0], xmm11
000076b67a9d8ba3  vmovaps [rsp+0xB0], xmm12
000076b67a9d8bac  vmovaps [rsp+0xC0], xmm13
000076b67a9d8bb5  vmovaps [rsp+0xD0], xmm14
000076b67a9d8bbe  vmovaps [rsp+0xE0], xmm15
000076b67a9d8bc7  sub rsp, 0x30
000076b67a9d8bcb  movaps [rsp], xmm1
000076b67a9d8bcf  movaps [rsp+0x10], xmm4
000076b67a9d8bd4  movaps [rsp+0x20], xmm9
000076b67a9d8bda  lea rdi, [rsp]
000076b67a9d8bde  mov esi, 0x00
000076b67a9d8be3  mov rax, 0x63C5EF2DF530
000076b67a9d8bed  call rax
000076b67a9d8bef  movaps xmm1, [rsp]
000076b67a9d8bf3  add rsp, 0x30
000076b67a9d8bf7  vmovaps xmm0, [rsp]
000076b67a9d8bfc  vmovaps xmm2, [rsp+0x10]
000076b67a9d8c02  vmovaps xmm3, [rsp+0x20]
000076b67a9d8c08  vmovaps xmm4, [rsp+0x30]
000076b67a9d8c0e  vmovaps xmm5, [rsp+0x40]
000076b67a9d8c14  vmovaps xmm6, [rsp+0x50]
000076b67a9d8c1a  vmovaps xmm7, [rsp+0x60]
000076b67a9d8c20  vmovaps xmm8, [rsp+0x70]
000076b67a9d8c26  vmovaps xmm9, [rsp+0x80]
000076b67a9d8c2f  vmovaps xmm10, [rsp+0x90]
000076b67a9d8c38  vmovaps xmm11, [rsp+0xA0]
000076b67a9d8c41  vmovaps xmm12, [rsp+0xB0]
000076b67a9d8c4a  vmovaps xmm13, [rsp+0xC0]
000076b67a9d8c53  vmovaps xmm14, [rsp+0xD0]
000076b67a9d8c5c  vmovaps xmm15, [rsp+0xE0]
000076b67a9d8c65  add rsp, 0xF0
000076b67a9d8c6c  pop r11
000076b67a9d8c6e  pop r10
000076b67a9d8c70  pop r9
000076b67a9d8c72  pop r8
000076b67a9d8c74  pop rsi
000076b67a9d8c75  pop rdi
000076b67a9d8c76  pop rdx
000076b67a9d8c77  pop rcx
000076b67a9d8c78  pop rax
000076b67a9d8c79  add rsp, 0x08
000076b67a9d8c7d  jmp 0x000076B67A9D613B
000076b67a9d8c82  sub rsp, 0x08
000076b67a9d8c86  push rax
000076b67a9d8c87  push rcx
000076b67a9d8c88  push rdx
000076b67a9d8c89  push rdi
000076b67a9d8c8a  push rsi
000076b67a9d8c8b  push r8
000076b67a9d8c8d  push r9
000076b67a9d8c8f  push r10
000076b67a9d8c91  push r11
000076b67a9d8c93  sub rsp, 0xF0
000076b67a9d8c9a  vmovaps [rsp], xmm0
000076b67a9d8c9f  vmovaps [rsp+0x10], xmm1
000076b67a9d8ca5  vmovaps [rsp+0x20], xmm2
000076b67a9d8cab  vmovaps [rsp+0x30], xmm3
000076b67a9d8cb1  vmovaps [rsp+0x40], xmm5
000076b67a9d8cb7  vmovaps [rsp+0x50], xmm6
000076b67a9d8cbd  vmovaps [rsp+0x60], xmm7
000076b67a9d8cc3  vmovaps [rsp+0x70], xmm8
000076b67a9d8cc9  vmovaps [rsp+0x80], xmm9
000076b67a9d8cd2  vmovaps [rsp+0x90], xmm10
000076b67a9d8cdb  vmovaps [rsp+0xA0], xmm11
000076b67a9d8ce4  vmovaps [rsp+0xB0], xmm12
000076b67a9d8ced  vmovaps [rsp+0xC0], xmm13
000076b67a9d8cf6  vmovaps [rsp+0xD0], xmm14
000076b67a9d8cff  vmovaps [rsp+0xE0], xmm15
000076b67a9d8d08  sub rsp, 0x30
000076b67a9d8d0c  movaps [rsp], xmm4
000076b67a9d8d10  movaps [rsp+0x10], xmm2
000076b67a9d8d15  movaps [rsp+0x20], xmm9
000076b67a9d8d1b  lea rdi, [rsp]
000076b67a9d8d1f  mov esi, 0x00
000076b67a9d8d24  mov rax, 0x63C5EF2DF530
000076b67a9d8d2e  call rax
000076b67a9d8d30  movaps xmm4, [rsp]
000076b67a9d8d34  add rsp, 0x30
000076b67a9d8d38  vmovaps xmm0, [rsp]
000076b67a9d8d3d  vmovaps xmm1, [rsp+0x10]
000076b67a9d8d43  vmovaps xmm2, [rsp+0x20]
000076b67a9d8d49  vmovaps xmm3, [rsp+0x30]
000076b67a9d8d4f  vmovaps xmm5, [rsp+0x40]
000076b67a9d8d55  vmovaps xmm6, [rsp+0x50]
000076b67a9d8d5b  vmovaps xmm7, [rsp+0x60]
000076b67a9d8d61  vmovaps xmm8, [rsp+0x70]
000076b67a9d8d67  vmovaps xmm9, [rsp+0x80]
000076b67a9d8d70  vmovaps xmm10, [rsp+0x90]
000076b67a9d8d79  vmovaps xmm11, [rsp+0xA0]
000076b67a9d8d82  vmovaps xmm12, [rsp+0xB0]
000076b67a9d8d8b  vmovaps xmm13, [rsp+0xC0]
000076b67a9d8d94  vmovaps xmm14, [rsp+0xD0]
000076b67a9d8d9d  vmovaps xmm15, [rsp+0xE0]
000076b67a9d8da6  add rsp, 0xF0
000076b67a9d8dad  pop r11
000076b67a9d8daf  pop r10
000076b67a9d8db1  pop r9
000076b67a9d8db3  pop r8
000076b67a9d8db5  pop rsi
000076b67a9d8db6  pop rdi
000076b67a9d8db7  pop rdx
000076b67a9d8db8  pop rcx
000076b67a9d8db9  pop rax
000076b67a9d8dba  add rsp, 0x08
000076b67a9d8dbe  jmp 0x000076B67A9D616B
000076b67a9d8dc3  sub rsp, 0x08
000076b67a9d8dc7  push rax
000076b67a9d8dc8  push rcx
000076b67a9d8dc9  push rdx
000076b67a9d8dca  push rdi
000076b67a9d8dcb  push rsi
000076b67a9d8dcc  push r8
000076b67a9d8dce  push r9
000076b67a9d8dd0  push r10
000076b67a9d8dd2  push r11
000076b67a9d8dd4  sub rsp, 0xF0
000076b67a9d8ddb  vmovaps [rsp], xmm0
000076b67a9d8de0  vmovaps [rsp+0x10], xmm1
000076b67a9d8de6  vmovaps [rsp+0x20], xmm2
000076b67a9d8dec  vmovaps [rsp+0x30], xmm3
000076b67a9d8df2  vmovaps [rsp+0x40], xmm4
000076b67a9d8df8  vmovaps [rsp+0x50], xmm5
000076b67a9d8dfe  vmovaps [rsp+0x60], xmm6
000076b67a9d8e04  vmovaps [rsp+0x70], xmm7
000076b67a9d8e0a  vmovaps [rsp+0x80], xmm8
000076b67a9d8e13  vmovaps [rsp+0x90], xmm10
000076b67a9d8e1c  vmovaps [rsp+0xA0], xmm11
000076b67a9d8e25  vmovaps [rsp+0xB0], xmm12
000076b67a9d8e2e  vmovaps [rsp+0xC0], xmm13
000076b67a9d8e37  vmovaps [rsp+0xD0], xmm14
000076b67a9d8e40  vmovaps [rsp+0xE0], xmm15
000076b67a9d8e49  sub rsp, 0x30
000076b67a9d8e4d  movaps [rsp], xmm9
000076b67a9d8e52  movaps [rsp+0x10], xmm2
000076b67a9d8e57  movaps [rsp+0x20], xmm1
000076b67a9d8e5c  lea rdi, [rsp]
000076b67a9d8e60  mov esi, 0x00
000076b67a9d8e65  mov rax, 0x63C5EF2DF530
000076b67a9d8e6f  call rax
000076b67a9d8e71  movaps xmm9, [rsp]
000076b67a9d8e76  add rsp, 0x30
000076b67a9d8e7a  vmovaps xmm0, [rsp]
000076b67a9d8e7f  vmovaps xmm1, [rsp+0x10]
000076b67a9d8e85  vmovaps xmm2, [rsp+0x20]
000076b67a9d8e8b  vmovaps xmm3, [rsp+0x30]
000076b67a9d8e91  vmovaps xmm4, [rsp+0x40]
000076b67a9d8e97  vmovaps xmm5, [rsp+0x50]
000076b67a9d8e9d  vmovaps xmm6, [rsp+0x60]
000076b67a9d8ea3  vmovaps xmm7, [rsp+0x70]
000076b67a9d8ea9  vmovaps xmm8, [rsp+0x80]
000076b67a9d8eb2  vmovaps xmm10, [rsp+0x90]
000076b67a9d8ebb  vmovaps xmm11, [rsp+0xA0]
000076b67a9d8ec4  vmovaps xmm12, [rsp+0xB0]
000076b67a9d8ecd  vmovaps xmm13, [rsp+0xC0]
000076b67a9d8ed6  vmovaps xmm14, [rsp+0xD0]
000076b67a9d8edf  vmovaps xmm15, [rsp+0xE0]
000076b67a9d8ee8  add rsp, 0xF0
000076b67a9d8eef  pop r11
000076b67a9d8ef1  pop r10
000076b67a9d8ef3  pop r9
000076b67a9d8ef5  pop r8
000076b67a9d8ef7  pop rsi
000076b67a9d8ef8  pop rdi
000076b67a9d8ef9  pop rdx
000076b67a9d8efa  pop rcx
000076b67a9d8efb  pop rax
000076b67a9d8efc  add rsp, 0x08
000076b67a9d8f00  jmp 0x000076B67A9D61A1
000076b67a9d8f05  sub rsp, 0x08
000076b67a9d8f09  push rax
000076b67a9d8f0a  push rcx
000076b67a9d8f0b  push rdx
000076b67a9d8f0c  push rdi
000076b67a9d8f0d  push rsi
000076b67a9d8f0e  push r8
000076b67a9d8f10  push r9
000076b67a9d8f12  push r10
000076b67a9d8f14  push r11
000076b67a9d8f16  sub rsp, 0xF0
000076b67a9d8f1d  vmovaps [rsp], xmm0
000076b67a9d8f22  vmovaps [rsp+0x10], xmm2
000076b67a9d8f28  vmovaps [rsp+0x20], xmm3
000076b67a9d8f2e  vmovaps [rsp+0x30], xmm4
000076b67a9d8f34  vmovaps [rsp+0x40], xmm5
000076b67a9d8f3a  vmovaps [rsp+0x50], xmm6
000076b67a9d8f40  vmovaps [rsp+0x60], xmm7
000076b67a9d8f46  vmovaps [rsp+0x70], xmm8
000076b67a9d8f4c  vmovaps [rsp+0x80], xmm9
000076b67a9d8f55  vmovaps [rsp+0x90], xmm10
000076b67a9d8f5e  vmovaps [rsp+0xA0], xmm11
000076b67a9d8f67  vmovaps [rsp+0xB0], xmm12
000076b67a9d8f70  vmovaps [rsp+0xC0], xmm13
000076b67a9d8f79  vmovaps [rsp+0xD0], xmm14
000076b67a9d8f82  vmovaps [rsp+0xE0], xmm15
000076b67a9d8f8b  sub rsp, 0x30
000076b67a9d8f8f  movaps [rsp], xmm1
000076b67a9d8f93  movaps [rsp+0x10], xmm15
000076b67a9d8f99  movaps [rsp+0x20], xmm6
000076b67a9d8f9e  lea rdi, [rsp]
000076b67a9d8fa2  mov esi, 0x00
000076b67a9d8fa7  mov rax, 0x63C5EF2DF530
000076b67a9d8fb1  call rax
000076b67a9d8fb3  movaps xmm1, [rsp]
000076b67a9d8fb7  add rsp, 0x30
000076b67a9d8fbb  vmovaps xmm0, [rsp]
000076b67a9d8fc0  vmovaps xmm2, [rsp+0x10]
000076b67a9d8fc6  vmovaps xmm3, [rsp+0x20]
000076b67a9d8fcc  vmovaps xmm4, [rsp+0x30]
000076b67a9d8fd2  vmovaps xmm5, [rsp+0x40]
000076b67a9d8fd8  vmovaps xmm6, [rsp+0x50]
000076b67a9d8fde  vmovaps xmm7, [rsp+0x60]
000076b67a9d8fe4  vmovaps xmm8, [rsp+0x70]
000076b67a9d8fea  vmovaps xmm9, [rsp+0x80]
000076b67a9d8ff3  vmovaps xmm10, [rsp+0x90]
000076b67a9d8ffc  vmovaps xmm11, [rsp+0xA0]
000076b67a9d9005  vmovaps xmm12, [rsp+0xB0]
000076b67a9d900e  vmovaps xmm13, [rsp+0xC0]
000076b67a9d9017  vmovaps xmm14, [rsp+0xD0]
000076b67a9d9020  vmovaps xmm15, [rsp+0xE0]
000076b67a9d9029  add rsp, 0xF0
000076b67a9d9030  pop r11
000076b67a9d9032  pop r10
000076b67a9d9034  pop r9
000076b67a9d9036  pop r8
000076b67a9d9038  pop rsi
000076b67a9d9039  pop rdi
000076b67a9d903a  pop rdx
000076b67a9d903b  pop rcx
000076b67a9d903c  pop rax
000076b67a9d903d  add rsp, 0x08
000076b67a9d9041  jmp 0x000076B67A9D61C2
000076b67a9d9046  sub rsp, 0x08
000076b67a9d904a  push rax
000076b67a9d904b  push rcx
000076b67a9d904c  push rdx
000076b67a9d904d  push rdi
000076b67a9d904e  push rsi
000076b67a9d904f  push r8
000076b67a9d9051  push r9
000076b67a9d9053  push r10
000076b67a9d9055  push r11
000076b67a9d9057  sub rsp, 0xF0
000076b67a9d905e  vmovaps [rsp], xmm0
000076b67a9d9063  vmovaps [rsp+0x10], xmm1
000076b67a9d9069  vmovaps [rsp+0x20], xmm2
000076b67a9d906f  vmovaps [rsp+0x30], xmm3
000076b67a9d9075  vmovaps [rsp+0x40], xmm4
000076b67a9d907b  vmovaps [rsp+0x50], xmm5
000076b67a9d9081  vmovaps [rsp+0x60], xmm6
000076b67a9d9087  vmovaps [rsp+0x70], xmm7
000076b67a9d908d  vmovaps [rsp+0x80], xmm8
000076b67a9d9096  vmovaps [rsp+0x90], xmm9
000076b67a9d909f  vmovaps [rsp+0xA0], xmm10
000076b67a9d90a8  vmovaps [rsp+0xB0], xmm11
000076b67a9d90b1  vmovaps [rsp+0xC0], xmm12
000076b67a9d90ba  vmovaps [rsp+0xD0], xmm13
000076b67a9d90c3  vmovaps [rsp+0xE0], xmm14
000076b67a9d90cc  sub rsp, 0x30
000076b67a9d90d0  movaps [rsp], xmm15
000076b67a9d90d5  movaps [rsp+0x10], xmm5
000076b67a9d90da  movaps [rsp+0x20], xmm3
000076b67a9d90df  lea rdi, [rsp]
000076b67a9d90e3  mov esi, 0x00
000076b67a9d90e8  mov rax, 0x63C5EF2DF530
000076b67a9d90f2  call rax
000076b67a9d90f4  movaps xmm15, [rsp]
000076b67a9d90f9  add rsp, 0x30
000076b67a9d90fd  vmovaps xmm0, [rsp]
000076b67a9d9102  vmovaps xmm1, [rsp+0x10]
000076b67a9d9108  vmovaps xmm2, [rsp+0x20]
000076b67a9d910e  vmovaps xmm3, [rsp+0x30]
000076b67a9d9114  vmovaps xmm4, [rsp+0x40]
000076b67a9d911a  vmovaps xmm5, [rsp+0x50]
000076b67a9d9120  vmovaps xmm6, [rsp+0x60]
000076b67a9d9126  vmovaps xmm7, [rsp+0x70]
000076b67a9d912c  vmovaps xmm8, [rsp+0x80]
000076b67a9d9135  vmovaps xmm9, [rsp+0x90]
000076b67a9d913e  vmovaps xmm10, [rsp+0xA0]
000076b67a9d9147  vmovaps xmm11, [rsp+0xB0]
000076b67a9d9150  vmovaps xmm12, [rsp+0xC0]
000076b67a9d9159  vmovaps xmm13, [rsp+0xD0]
000076b67a9d9162  vmovaps xmm14, [rsp+0xE0]
000076b67a9d916b  add rsp, 0xF0
000076b67a9d9172  pop r11
000076b67a9d9174  pop r10
000076b67a9d9176  pop r9
000076b67a9d9178  pop r8
000076b67a9d917a  pop rsi
000076b67a9d917b  pop rdi
000076b67a9d917c  pop rdx
000076b67a9d917d  pop rcx
000076b67a9d917e  pop rax
000076b67a9d917f  add rsp, 0x08
000076b67a9d9183  jmp 0x000076B67A9D61DC
000076b67a9d9188  sub rsp, 0x08
000076b67a9d918c  push rax
000076b67a9d918d  push rcx
000076b67a9d918e  push rdx
000076b67a9d918f  push rdi
000076b67a9d9190  push rsi
000076b67a9d9191  push r8
000076b67a9d9193  push r9
000076b67a9d9195  push r10
000076b67a9d9197  push r11
000076b67a9d9199  sub rsp, 0xF0
000076b67a9d91a0  vmovaps [rsp], xmm0
000076b67a9d91a5  vmovaps [rsp+0x10], xmm1
000076b67a9d91ab  vmovaps [rsp+0x20], xmm2
000076b67a9d91b1  vmovaps [rsp+0x30], xmm3
000076b67a9d91b7  vmovaps [rsp+0x40], xmm4
000076b67a9d91bd  vmovaps [rsp+0x50], xmm6
000076b67a9d91c3  vmovaps [rsp+0x60], xmm7
000076b67a9d91c9  vmovaps [rsp+0x70], xmm8
000076b67a9d91cf  vmovaps [rsp+0x80], xmm9
000076b67a9d91d8  vmovaps [rsp+0x90], xmm10
000076b67a9d91e1  vmovaps [rsp+0xA0], xmm11
000076b67a9d91ea  vmovaps [rsp+0xB0], xmm12
000076b67a9d91f3  vmovaps [rsp+0xC0], xmm13
000076b67a9d91fc  vmovaps [rsp+0xD0], xmm14
000076b67a9d9205  vmovaps [rsp+0xE0], xmm15
000076b67a9d920e  sub rsp, 0x30
000076b67a9d9212  movaps [rsp], xmm5
000076b67a9d9216  movaps [rsp+0x10], xmm8
000076b67a9d921c  movaps [rsp+0x20], xmm6
000076b67a9d9221  lea rdi, [rsp]
000076b67a9d9225  mov esi, 0x00
000076b67a9d922a  mov rax, 0x63C5EF2DF530
000076b67a9d9234  call rax
000076b67a9d9236  movaps xmm5, [rsp]
000076b67a9d923a  add rsp, 0x30
000076b67a9d923e  vmovaps xmm0, [rsp]
000076b67a9d9243  vmovaps xmm1, [rsp+0x10]
000076b67a9d9249  vmovaps xmm2, [rsp+0x20]
000076b67a9d924f  vmovaps xmm3, [rsp+0x30]
000076b67a9d9255  vmovaps xmm4, [rsp+0x40]
000076b67a9d925b  vmovaps xmm6, [rsp+0x50]
000076b67a9d9261  vmovaps xmm7, [rsp+0x60]
000076b67a9d9267  vmovaps xmm8, [rsp+0x70]
000076b67a9d926d  vmovaps xmm9, [rsp+0x80]
000076b67a9d9276  vmovaps xmm10, [rsp+0x90]
000076b67a9d927f  vmovaps xmm11, [rsp+0xA0]
000076b67a9d9288  vmovaps xmm12, [rsp+0xB0]
000076b67a9d9291  vmovaps xmm13, [rsp+0xC0]
000076b67a9d929a  vmovaps xmm14, [rsp+0xD0]
000076b67a9d92a3  vmovaps xmm15, [rsp+0xE0]
000076b67a9d92ac  add rsp, 0xF0
000076b67a9d92b3  pop r11
000076b67a9d92b5  pop r10
000076b67a9d92b7  pop r9
000076b67a9d92b9  pop r8
000076b67a9d92bb  pop rsi
000076b67a9d92bc  pop rdi
000076b67a9d92bd  pop rdx
000076b67a9d92be  pop rcx
000076b67a9d92bf  pop rax
000076b67a9d92c0  add rsp, 0x08
000076b67a9d92c4  jmp 0x000076B67A9D6200
000076b67a9d92c9  sub rsp, 0x08
000076b67a9d92cd  push rax
000076b67a9d92ce  push rcx
000076b67a9d92cf  push rdx
000076b67a9d92d0  push rdi
000076b67a9d92d1  push rsi
000076b67a9d92d2  push r8
000076b67a9d92d4  push r9
000076b67a9d92d6  push r10
000076b67a9d92d8  push r11
000076b67a9d92da  sub rsp, 0xF0
000076b67a9d92e1  vmovaps [rsp], xmm0
000076b67a9d92e6  vmovaps [rsp+0x10], xmm1
000076b67a9d92ec  vmovaps [rsp+0x20], xmm2
000076b67a9d92f2  vmovaps [rsp+0x30], xmm3
000076b67a9d92f8  vmovaps [rsp+0x40], xmm4
000076b67a9d92fe  vmovaps [rsp+0x50], xmm5
000076b67a9d9304  vmovaps [rsp+0x60], xmm7
000076b67a9d930a  vmovaps [rsp+0x70], xmm8
000076b67a9d9310  vmovaps [rsp+0x80], xmm9
000076b67a9d9319  vmovaps [rsp+0x90], xmm10
000076b67a9d9322  vmovaps [rsp+0xA0], xmm11
000076b67a9d932b  vmovaps [rsp+0xB0], xmm12
000076b67a9d9334  vmovaps [rsp+0xC0], xmm13
000076b67a9d933d  vmovaps [rsp+0xD0], xmm14
000076b67a9d9346  vmovaps [rsp+0xE0], xmm15
000076b67a9d934f  sub rsp, 0x30
000076b67a9d9353  movaps [rsp], xmm6
000076b67a9d9357  movaps [rsp+0x10], xmm10
000076b67a9d935d  movaps [rsp+0x20], xmm8
000076b67a9d9363  lea rdi, [rsp]
000076b67a9d9367  mov esi, 0x00
000076b67a9d936c  mov rax, 0x63C5EF2DF530
000076b67a9d9376  call rax
000076b67a9d9378  movaps xmm6, [rsp]
000076b67a9d937c  add rsp, 0x30
000076b67a9d9380  vmovaps xmm0, [rsp]
000076b67a9d9385  vmovaps xmm1, [rsp+0x10]
000076b67a9d938b  vmovaps xmm2, [rsp+0x20]
000076b67a9d9391  vmovaps xmm3, [rsp+0x30]
000076b67a9d9397  vmovaps xmm4, [rsp+0x40]
000076b67a9d939d  vmovaps xmm5, [rsp+0x50]
000076b67a9d93a3  vmovaps xmm7, [rsp+0x60]
000076b67a9d93a9  vmovaps xmm8, [rsp+0x70]
000076b67a9d93af  vmovaps xmm9, [rsp+0x80]
000076b67a9d93b8  vmovaps xmm10, [rsp+0x90]
000076b67a9d93c1  vmovaps xmm11, [rsp+0xA0]
000076b67a9d93ca  vmovaps xmm12, [rsp+0xB0]
000076b67a9d93d3  vmovaps xmm13, [rsp+0xC0]
000076b67a9d93dc  vmovaps xmm14, [rsp+0xD0]
000076b67a9d93e5  vmovaps xmm15, [rsp+0xE0]
000076b67a9d93ee  add rsp, 0xF0
000076b67a9d93f5  pop r11
000076b67a9d93f7  pop r10
000076b67a9d93f9  pop r9
000076b67a9d93fb  pop r8
000076b67a9d93fd  pop rsi
000076b67a9d93fe  pop rdi
000076b67a9d93ff  pop rdx
000076b67a9d9400  pop rcx
000076b67a9d9401  pop rax
000076b67a9d9402  add rsp, 0x08
000076b67a9d9406  jmp 0x000076B67A9D6225
000076b67a9d940b  sub rsp, 0x08
000076b67a9d940f  push rax
000076b67a9d9410  push rcx
000076b67a9d9411  push rdx
000076b67a9d9412  push rdi
000076b67a9d9413  push rsi
000076b67a9d9414  push r8
000076b67a9d9416  push r9
000076b67a9d9418  push r10
000076b67a9d941a  push r11
000076b67a9d941c  sub rsp, 0xF0
000076b67a9d9423  vmovaps [rsp], xmm0
000076b67a9d9428  vmovaps [rsp+0x10], xmm1
000076b67a9d942e  vmovaps [rsp+0x20], xmm2
000076b67a9d9434  vmovaps [rsp+0x30], xmm3
000076b67a9d943a  vmovaps [rsp+0x40], xmm4
000076b67a9d9440  vmovaps [rsp+0x50], xmm5
000076b67a9d9446  vmovaps [rsp+0x60], xmm6
000076b67a9d944c  vmovaps [rsp+0x70], xmm7
000076b67a9d9452  vmovaps [rsp+0x80], xmm8
000076b67a9d945b  vmovaps [rsp+0x90], xmm9
000076b67a9d9464  vmovaps [rsp+0xA0], xmm11
000076b67a9d946d  vmovaps [rsp+0xB0], xmm12
000076b67a9d9476  vmovaps [rsp+0xC0], xmm13
000076b67a9d947f  vmovaps [rsp+0xD0], xmm14
000076b67a9d9488  vmovaps [rsp+0xE0], xmm15
000076b67a9d9491  sub rsp, 0x30
000076b67a9d9495  movaps [rsp], xmm10
000076b67a9d949a  movaps [rsp+0x10], xmm8
000076b67a9d94a0  movaps [rsp+0x20], xmm14
000076b67a9d94a6  lea rdi, [rsp]
000076b67a9d94aa  mov esi, 0x00
000076b67a9d94af  mov rax, 0x63C5EF2DF530
000076b67a9d94b9  call rax
000076b67a9d94bb  movaps xmm10, [rsp]
000076b67a9d94c0  add rsp, 0x30
000076b67a9d94c4  vmovaps xmm0, [rsp]
000076b67a9d94c9  vmovaps xmm1, [rsp+0x10]
000076b67a9d94cf  vmovaps xmm2, [rsp+0x20]
000076b67a9d94d5  vmovaps xmm3, [rsp+0x30]
000076b67a9d94db  vmovaps xmm4, [rsp+0x40]
000076b67a9d94e1  vmovaps xmm5, [rsp+0x50]
000076b67a9d94e7  vmovaps xmm6, [rsp+0x60]
000076b67a9d94ed  vmovaps xmm7, [rsp+0x70]
000076b67a9d94f3  vmovaps xmm8, [rsp+0x80]
000076b67a9d94fc  vmovaps xmm9, [rsp+0x90]
000076b67a9d9505  vmovaps xmm11, [rsp+0xA0]
000076b67a9d950e  vmovaps xmm12, [rsp+0xB0]
000076b67a9d9517  vmovaps xmm13, [rsp+0xC0]
000076b67a9d9520  vmovaps xmm14, [rsp+0xD0]
000076b67a9d9529  vmovaps xmm15, [rsp+0xE0]
000076b67a9d9532  add rsp, 0xF0
000076b67a9d9539  pop r11
000076b67a9d953b  pop r10
000076b67a9d953d  pop r9
000076b67a9d953f  pop r8
000076b67a9d9541  pop rsi
000076b67a9d9542  pop rdi
000076b67a9d9543  pop rdx
000076b67a9d9544  pop rcx
000076b67a9d9545  pop rax
000076b67a9d9546  add rsp, 0x08
000076b67a9d954a  jmp 0x000076B67A9D6245
000076b67a9d954f  sub rsp, 0x08
000076b67a9d9553  push rax
000076b67a9d9554  push rcx
000076b67a9d9555  push rdx
000076b67a9d9556  push rdi
000076b67a9d9557  push rsi
000076b67a9d9558  push r8
000076b67a9d955a  push r9
000076b67a9d955c  push r10
000076b67a9d955e  push r11
000076b67a9d9560  sub rsp, 0xF0
000076b67a9d9567  vmovaps [rsp], xmm0
000076b67a9d956c  vmovaps [rsp+0x10], xmm1
000076b67a9d9572  vmovaps [rsp+0x20], xmm2
000076b67a9d9578  vmovaps [rsp+0x30], xmm3
000076b67a9d957e  vmovaps [rsp+0x40], xmm4
000076b67a9d9584  vmovaps [rsp+0x50], xmm5
000076b67a9d958a  vmovaps [rsp+0x60], xmm6
000076b67a9d9590  vmovaps [rsp+0x70], xmm7
000076b67a9d9596  vmovaps [rsp+0x80], xmm8
000076b67a9d959f  vmovaps [rsp+0x90], xmm9
000076b67a9d95a8  vmovaps [rsp+0xA0], xmm10
000076b67a9d95b1  vmovaps [rsp+0xB0], xmm11
000076b67a9d95ba  vmovaps [rsp+0xC0], xmm12
000076b67a9d95c3  vmovaps [rsp+0xD0], xmm13
000076b67a9d95cc  vmovaps [rsp+0xE0], xmm15
000076b67a9d95d5  sub rsp, 0x30
000076b67a9d95d9  movaps [rsp], xmm14
000076b67a9d95de  movaps [rsp+0x10], xmm8
000076b67a9d95e4  movaps [rsp+0x20], xmm4
000076b67a9d95e9  lea rdi, [rsp]
000076b67a9d95ed  mov esi, 0x00
000076b67a9d95f2  mov rax, 0x63C5EF2DF530
000076b67a9d95fc  call rax
000076b67a9d95fe  movaps xmm14, [rsp]
000076b67a9d9603  add rsp, 0x30
000076b67a9d9607  vmovaps xmm0, [rsp]
000076b67a9d960c  vmovaps xmm1, [rsp+0x10]
000076b67a9d9612  vmovaps xmm2, [rsp+0x20]
000076b67a9d9618  vmovaps xmm3, [rsp+0x30]
000076b67a9d961e  vmovaps xmm4, [rsp+0x40]
000076b67a9d9624  vmovaps xmm5, [rsp+0x50]
000076b67a9d962a  vmovaps xmm6, [rsp+0x60]
000076b67a9d9630  vmovaps xmm7, [rsp+0x70]
000076b67a9d9636  vmovaps xmm8, [rsp+0x80]
000076b67a9d963f  vmovaps xmm9, [rsp+0x90]
000076b67a9d9648  vmovaps xmm10, [rsp+0xA0]
000076b67a9d9651  vmovaps xmm11, [rsp+0xB0]
000076b67a9d965a  vmovaps xmm12, [rsp+0xC0]
000076b67a9d9663  vmovaps xmm13, [rsp+0xD0]
000076b67a9d966c  vmovaps xmm15, [rsp+0xE0]
000076b67a9d9675  add rsp, 0xF0
000076b67a9d967c  pop r11
000076b67a9d967e  pop r10
000076b67a9d9680  pop r9
000076b67a9d9682  pop r8
000076b67a9d9684  pop rsi
000076b67a9d9685  pop rdi
000076b67a9d9686  pop rdx
000076b67a9d9687  pop rcx
000076b67a9d9688  pop rax
000076b67a9d9689  add rsp, 0x08
000076b67a9d968d  jmp 0x000076B67A9D6265
000076b67a9d9692  sub rsp, 0x08
000076b67a9d9696  push rax
000076b67a9d9697  push rcx
000076b67a9d9698  push rdx
000076b67a9d9699  push rdi
000076b67a9d969a  push rsi
000076b67a9d969b  push r8
000076b67a9d969d  push r9
000076b67a9d969f  push r10
000076b67a9d96a1  push r11
000076b67a9d96a3  sub rsp, 0xF0
000076b67a9d96aa  vmovaps [rsp], xmm0
000076b67a9d96af  vmovaps [rsp+0x10], xmm1
000076b67a9d96b5  vmovaps [rsp+0x20], xmm2
000076b67a9d96bb  vmovaps [rsp+0x30], xmm3
000076b67a9d96c1  vmovaps [rsp+0x40], xmm5
000076b67a9d96c7  vmovaps [rsp+0x50], xmm6
000076b67a9d96cd  vmovaps [rsp+0x60], xmm7
000076b67a9d96d3  vmovaps [rsp+0x70], xmm8
000076b67a9d96d9  vmovaps [rsp+0x80], xmm9
000076b67a9d96e2  vmovaps [rsp+0x90], xmm10
000076b67a9d96eb  vmovaps [rsp+0xA0], xmm11
000076b67a9d96f4  vmovaps [rsp+0xB0], xmm12
000076b67a9d96fd  vmovaps [rsp+0xC0], xmm13
000076b67a9d9706  vmovaps [rsp+0xD0], xmm14
000076b67a9d970f  vmovaps [rsp+0xE0], xmm15
000076b67a9d9718  sub rsp, 0x30
000076b67a9d971c  movaps [rsp], xmm4
000076b67a9d9720  movaps [rsp+0x10], xmm13
000076b67a9d9726  movaps [rsp+0x20], xmm8
000076b67a9d972c  lea rdi, [rsp]
000076b67a9d9730  mov esi, 0x00
000076b67a9d9735  mov rax, 0x63C5EF2DF530
000076b67a9d973f  call rax
000076b67a9d9741  movaps xmm4, [rsp]
000076b67a9d9745  add rsp, 0x30
000076b67a9d9749  vmovaps xmm0, [rsp]
000076b67a9d974e  vmovaps xmm1, [rsp+0x10]
000076b67a9d9754  vmovaps xmm2, [rsp+0x20]
000076b67a9d975a  vmovaps xmm3, [rsp+0x30]
000076b67a9d9760  vmovaps xmm5, [rsp+0x40]
000076b67a9d9766  vmovaps xmm6, [rsp+0x50]
000076b67a9d976c  vmovaps xmm7, [rsp+0x60]
000076b67a9d9772  vmovaps xmm8, [rsp+0x70]
000076b67a9d9778  vmovaps xmm9, [rsp+0x80]
000076b67a9d9781  vmovaps xmm10, [rsp+0x90]
000076b67a9d978a  vmovaps xmm11, [rsp+0xA0]
000076b67a9d9793  vmovaps xmm12, [rsp+0xB0]
000076b67a9d979c  vmovaps xmm13, [rsp+0xC0]
000076b67a9d97a5  vmovaps xmm14, [rsp+0xD0]
000076b67a9d97ae  vmovaps xmm15, [rsp+0xE0]
000076b67a9d97b7  add rsp, 0xF0
000076b67a9d97be  pop r11
000076b67a9d97c0  pop r10
000076b67a9d97c2  pop r9
000076b67a9d97c4  pop r8
000076b67a9d97c6  pop rsi
000076b67a9d97c7  pop rdi
000076b67a9d97c8  pop rdx
000076b67a9d97c9  pop rcx
000076b67a9d97ca  pop rax
000076b67a9d97cb  add rsp, 0x08
000076b67a9d97cf  jmp 0x000076B67A9D628A
000076b67a9d97d4  sub rsp, 0x08
000076b67a9d97d8  push rax
000076b67a9d97d9  push rcx
000076b67a9d97da  push rdx
000076b67a9d97db  push rdi
000076b67a9d97dc  push rsi
000076b67a9d97dd  push r8
000076b67a9d97df  push r9
000076b67a9d97e1  push r10
000076b67a9d97e3  push r11
000076b67a9d97e5  sub rsp, 0xF0
000076b67a9d97ec  vmovaps [rsp], xmm0
000076b67a9d97f1  vmovaps [rsp+0x10], xmm1
000076b67a9d97f7  vmovaps [rsp+0x20], xmm2
000076b67a9d97fd  vmovaps [rsp+0x30], xmm3
000076b67a9d9803  vmovaps [rsp+0x40], xmm4
000076b67a9d9809  vmovaps [rsp+0x50], xmm5
000076b67a9d980f  vmovaps [rsp+0x60], xmm6
000076b67a9d9815  vmovaps [rsp+0x70], xmm7
000076b67a9d981b  vmovaps [rsp+0x80], xmm8
000076b67a9d9824  vmovaps [rsp+0x90], xmm9
000076b67a9d982d  vmovaps [rsp+0xA0], xmm10
000076b67a9d9836  vmovaps [rsp+0xB0], xmm11
000076b67a9d983f  vmovaps [rsp+0xC0], xmm12
000076b67a9d9848  vmovaps [rsp+0xD0], xmm14
000076b67a9d9851  vmovaps [rsp+0xE0], xmm15
000076b67a9d985a  sub rsp, 0x30
000076b67a9d985e  movaps [rsp], xmm13
000076b67a9d9863  movaps [rsp+0x10], xmm15
000076b67a9d9869  movaps [rsp+0x20], xmm9
000076b67a9d986f  lea rdi, [rsp]
000076b67a9d9873  mov esi, 0x00
000076b67a9d9878  mov rax, 0x63C5EF2DF530
000076b67a9d9882  call rax
000076b67a9d9884  movaps xmm13, [rsp]
000076b67a9d9889  add rsp, 0x30
000076b67a9d988d  vmovaps xmm0, [rsp]
000076b67a9d9892  vmovaps xmm1, [rsp+0x10]
000076b67a9d9898  vmovaps xmm2, [rsp+0x20]
000076b67a9d989e  vmovaps xmm3, [rsp+0x30]
000076b67a9d98a4  vmovaps xmm4, [rsp+0x40]
000076b67a9d98aa  vmovaps xmm5, [rsp+0x50]
000076b67a9d98b0  vmovaps xmm6, [rsp+0x60]
000076b67a9d98b6  vmovaps xmm7, [rsp+0x70]
000076b67a9d98bc  vmovaps xmm8, [rsp+0x80]
000076b67a9d98c5  vmovaps xmm9, [rsp+0x90]
000076b67a9d98ce  vmovaps xmm10, [rsp+0xA0]
000076b67a9d98d7  vmovaps xmm11, [rsp+0xB0]
000076b67a9d98e0  vmovaps xmm12, [rsp+0xC0]
000076b67a9d98e9  vmovaps xmm14, [rsp+0xD0]
000076b67a9d98f2  vmovaps xmm15, [rsp+0xE0]
000076b67a9d98fb  add rsp, 0xF0
000076b67a9d9902  pop r11
000076b67a9d9904  pop r10
000076b67a9d9906  pop r9
000076b67a9d9908  pop r8
000076b67a9d990a  pop rsi
000076b67a9d990b  pop rdi
000076b67a9d990c  pop rdx
000076b67a9d990d  pop rcx
000076b67a9d990e  pop rax
000076b67a9d990f  add rsp, 0x08
000076b67a9d9913  jmp 0x000076B67A9D62A5
000076b67a9d9918  sub rsp, 0x08
000076b67a9d991c  push rax
000076b67a9d991d  push rcx
000076b67a9d991e  push rdx
000076b67a9d991f  push rdi
000076b67a9d9920  push rsi
000076b67a9d9921  push r8
000076b67a9d9923  push r9
000076b67a9d9925  push r10
000076b67a9d9927  push r11
000076b67a9d9929  sub rsp, 0xF0
000076b67a9d9930  vmovaps [rsp], xmm0
000076b67a9d9935  vmovaps [rsp+0x10], xmm1
000076b67a9d993b  vmovaps [rsp+0x20], xmm2
000076b67a9d9941  vmovaps [rsp+0x30], xmm3
000076b67a9d9947  vmovaps [rsp+0x40], xmm4
000076b67a9d994d  vmovaps [rsp+0x50], xmm5
000076b67a9d9953  vmovaps [rsp+0x60], xmm6
000076b67a9d9959  vmovaps [rsp+0x70], xmm7
000076b67a9d995f  vmovaps [rsp+0x80], xmm8
000076b67a9d9968  vmovaps [rsp+0x90], xmm9
000076b67a9d9971  vmovaps [rsp+0xA0], xmm10
000076b67a9d997a  vmovaps [rsp+0xB0], xmm11
000076b67a9d9983  vmovaps [rsp+0xC0], xmm12
000076b67a9d998c  vmovaps [rsp+0xD0], xmm13
000076b67a9d9995  vmovaps [rsp+0xE0], xmm14
000076b67a9d999e  sub rsp, 0x30
000076b67a9d99a2  movaps [rsp], xmm15
000076b67a9d99a7  movaps [rsp+0x10], xmm1
000076b67a9d99ac  movaps [rsp+0x20], xmm5
000076b67a9d99b1  lea rdi, [rsp]
000076b67a9d99b5  mov esi, 0x00
000076b67a9d99ba  mov rax, 0x63C5EF2DF530
000076b67a9d99c4  call rax
000076b67a9d99c6  movaps xmm15, [rsp]
000076b67a9d99cb  add rsp, 0x30
000076b67a9d99cf  vmovaps xmm0, [rsp]
000076b67a9d99d4  vmovaps xmm1, [rsp+0x10]
000076b67a9d99da  vmovaps xmm2, [rsp+0x20]
000076b67a9d99e0  vmovaps xmm3, [rsp+0x30]
000076b67a9d99e6  vmovaps xmm4, [rsp+0x40]
000076b67a9d99ec  vmovaps xmm5, [rsp+0x50]
000076b67a9d99f2  vmovaps xmm6, [rsp+0x60]
000076b67a9d99f8  vmovaps xmm7, [rsp+0x70]
000076b67a9d99fe  vmovaps xmm8, [rsp+0x80]
000076b67a9d9a07  vmovaps xmm9, [rsp+0x90]
000076b67a9d9a10  vmovaps xmm10, [rsp+0xA0]
000076b67a9d9a19  vmovaps xmm11, [rsp+0xB0]
000076b67a9d9a22  vmovaps xmm12, [rsp+0xC0]
000076b67a9d9a2b  vmovaps xmm13, [rsp+0xD0]
000076b67a9d9a34  vmovaps xmm14, [rsp+0xE0]
000076b67a9d9a3d  add rsp, 0xF0
000076b67a9d9a44  pop r11
000076b67a9d9a46  pop r10
000076b67a9d9a48  pop r9
000076b67a9d9a4a  pop r8
000076b67a9d9a4c  pop rsi
000076b67a9d9a4d  pop rdi
000076b67a9d9a4e  pop rdx
000076b67a9d9a4f  pop rcx
000076b67a9d9a50  pop rax
000076b67a9d9a51  add rsp, 0x08
000076b67a9d9a55  jmp 0x000076B67A9D62C0
000076b67a9d9a5a  call 0x000076B67A8D64F0
000076b67a9d9a5f  jmp 0x000076B67A9D631B
000076b67a9d9a64  sub rsp, 0x08
000076b67a9d9a68  push rax
000076b67a9d9a69  push rcx
000076b67a9d9a6a  push rdx
000076b67a9d9a6b  push rdi
000076b67a9d9a6c  push rsi
000076b67a9d9a6d  push r8
000076b67a9d9a6f  push r9
000076b67a9d9a71  push r10
000076b67a9d9a73  push r11
000076b67a9d9a75  sub rsp, 0xF0
000076b67a9d9a7c  vmovaps [rsp], xmm0
000076b67a9d9a81  vmovaps [rsp+0x10], xmm1
000076b67a9d9a87  vmovaps [rsp+0x20], xmm2
000076b67a9d9a8d  vmovaps [rsp+0x30], xmm3
000076b67a9d9a93  vmovaps [rsp+0x40], xmm4
000076b67a9d9a99  vmovaps [rsp+0x50], xmm5
000076b67a9d9a9f  vmovaps [rsp+0x60], xmm6
000076b67a9d9aa5  vmovaps [rsp+0x70], xmm7
000076b67a9d9aab  vmovaps [rsp+0x80], xmm8
000076b67a9d9ab4  vmovaps [rsp+0x90], xmm10
000076b67a9d9abd  vmovaps [rsp+0xA0], xmm11
000076b67a9d9ac6  vmovaps [rsp+0xB0], xmm12
000076b67a9d9acf  vmovaps [rsp+0xC0], xmm13
000076b67a9d9ad8  vmovaps [rsp+0xD0], xmm14
000076b67a9d9ae1  vmovaps [rsp+0xE0], xmm15
000076b67a9d9aea  sub rsp, 0x30
000076b67a9d9aee  movaps [rsp], xmm9
000076b67a9d9af3  movaps [rsp+0x10], xmm8
000076b67a9d9af9  movaps [rsp+0x20], xmm11
000076b67a9d9aff  lea rdi, [rsp]
000076b67a9d9b03  mov esi, 0x00
000076b67a9d9b08  mov rax, 0x63C5EF2DF530
000076b67a9d9b12  call rax
000076b67a9d9b14  movaps xmm9, [rsp]
000076b67a9d9b19  add rsp, 0x30
000076b67a9d9b1d  vmovaps xmm0, [rsp]
000076b67a9d9b22  vmovaps xmm1, [rsp+0x10]
000076b67a9d9b28  vmovaps xmm2, [rsp+0x20]
000076b67a9d9b2e  vmovaps xmm3, [rsp+0x30]
000076b67a9d9b34  vmovaps xmm4, [rsp+0x40]
000076b67a9d9b3a  vmovaps xmm5, [rsp+0x50]
000076b67a9d9b40  vmovaps xmm6, [rsp+0x60]
000076b67a9d9b46  vmovaps xmm7, [rsp+0x70]
000076b67a9d9b4c  vmovaps xmm8, [rsp+0x80]
000076b67a9d9b55  vmovaps xmm10, [rsp+0x90]
000076b67a9d9b5e  vmovaps xmm11, [rsp+0xA0]
000076b67a9d9b67  vmovaps xmm12, [rsp+0xB0]
000076b67a9d9b70  vmovaps xmm13, [rsp+0xC0]
000076b67a9d9b79  vmovaps xmm14, [rsp+0xD0]
000076b67a9d9b82  vmovaps xmm15, [rsp+0xE0]
000076b67a9d9b8b  add rsp, 0xF0
000076b67a9d9b92  pop r11
000076b67a9d9b94  pop r10
000076b67a9d9b96  pop r9
000076b67a9d9b98  pop r8
000076b67a9d9b9a  pop rsi
000076b67a9d9b9b  pop rdi
000076b67a9d9b9c  pop rdx
000076b67a9d9b9d  pop rcx
000076b67a9d9b9e  pop rax
000076b67a9d9b9f  add rsp, 0x08
000076b67a9d9ba3  jmp 0x000076B67A9D6352
000076b67a9d9ba8  sub rsp, 0x08
000076b67a9d9bac  push rax
000076b67a9d9bad  push rcx
000076b67a9d9bae  push rdx
000076b67a9d9baf  push rdi
000076b67a9d9bb0  push rsi
000076b67a9d9bb1  push r8
000076b67a9d9bb3  push r9
000076b67a9d9bb5  push r10
000076b67a9d9bb7  push r11
000076b67a9d9bb9  sub rsp, 0xF0
000076b67a9d9bc0  vmovaps [rsp], xmm0
000076b67a9d9bc5  vmovaps [rsp+0x10], xmm1
000076b67a9d9bcb  vmovaps [rsp+0x20], xmm2
000076b67a9d9bd1  vmovaps [rsp+0x30], xmm3
000076b67a9d9bd7  vmovaps [rsp+0x40], xmm4
000076b67a9d9bdd  vmovaps [rsp+0x50], xmm5
000076b67a9d9be3  vmovaps [rsp+0x60], xmm6
000076b67a9d9be9  vmovaps [rsp+0x70], xmm7
000076b67a9d9bef  vmovaps [rsp+0x80], xmm8
000076b67a9d9bf8  vmovaps [rsp+0x90], xmm9
000076b67a9d9c01  vmovaps [rsp+0xA0], xmm10
000076b67a9d9c0a  vmovaps [rsp+0xB0], xmm12
000076b67a9d9c13  vmovaps [rsp+0xC0], xmm13
000076b67a9d9c1c  vmovaps [rsp+0xD0], xmm14
000076b67a9d9c25  vmovaps [rsp+0xE0], xmm15
000076b67a9d9c2e  sub rsp, 0x30
000076b67a9d9c32  movaps [rsp], xmm11
000076b67a9d9c37  movaps [rsp+0x10], xmm10
000076b67a9d9c3d  movaps [rsp+0x20], xmm6
000076b67a9d9c42  lea rdi, [rsp]
000076b67a9d9c46  mov esi, 0x00
000076b67a9d9c4b  mov rax, 0x63C5EF2DF530
000076b67a9d9c55  call rax
000076b67a9d9c57  movaps xmm11, [rsp]
000076b67a9d9c5c  add rsp, 0x30
000076b67a9d9c60  vmovaps xmm0, [rsp]
000076b67a9d9c65  vmovaps xmm1, [rsp+0x10]
000076b67a9d9c6b  vmovaps xmm2, [rsp+0x20]
000076b67a9d9c71  vmovaps xmm3, [rsp+0x30]
000076b67a9d9c77  vmovaps xmm4, [rsp+0x40]
000076b67a9d9c7d  vmovaps xmm5, [rsp+0x50]
000076b67a9d9c83  vmovaps xmm6, [rsp+0x60]
000076b67a9d9c89  vmovaps xmm7, [rsp+0x70]
000076b67a9d9c8f  vmovaps xmm8, [rsp+0x80]
000076b67a9d9c98  vmovaps xmm9, [rsp+0x90]
000076b67a9d9ca1  vmovaps xmm10, [rsp+0xA0]
000076b67a9d9caa  vmovaps xmm12, [rsp+0xB0]
000076b67a9d9cb3  vmovaps xmm13, [rsp+0xC0]
000076b67a9d9cbc  vmovaps xmm14, [rsp+0xD0]
000076b67a9d9cc5  vmovaps xmm15, [rsp+0xE0]
000076b67a9d9cce  add rsp, 0xF0
000076b67a9d9cd5  pop r11
000076b67a9d9cd7  pop r10
000076b67a9d9cd9  pop r9
000076b67a9d9cdb  pop r8
000076b67a9d9cdd  pop rsi
000076b67a9d9cde  pop rdi
000076b67a9d9cdf  pop rdx
000076b67a9d9ce0  pop rcx
000076b67a9d9ce1  pop rax
000076b67a9d9ce2  add rsp, 0x08
000076b67a9d9ce6  jmp 0x000076B67A9D636D
000076b67a9d9ceb  sub rsp, 0x08
000076b67a9d9cef  push rax
000076b67a9d9cf0  push rcx
000076b67a9d9cf1  push rdx
000076b67a9d9cf2  push rdi
000076b67a9d9cf3  push rsi
000076b67a9d9cf4  push r8
000076b67a9d9cf6  push r9
000076b67a9d9cf8  push r10
000076b67a9d9cfa  push r11
000076b67a9d9cfc  sub rsp, 0xF0
000076b67a9d9d03  vmovaps [rsp], xmm0
000076b67a9d9d08  vmovaps [rsp+0x10], xmm1
000076b67a9d9d0e  vmovaps [rsp+0x20], xmm2
000076b67a9d9d14  vmovaps [rsp+0x30], xmm3
000076b67a9d9d1a  vmovaps [rsp+0x40], xmm4
000076b67a9d9d20  vmovaps [rsp+0x50], xmm5
000076b67a9d9d26  vmovaps [rsp+0x60], xmm6
000076b67a9d9d2c  vmovaps [rsp+0x70], xmm7
000076b67a9d9d32  vmovaps [rsp+0x80], xmm8
000076b67a9d9d3b  vmovaps [rsp+0x90], xmm9
000076b67a9d9d44  vmovaps [rsp+0xA0], xmm11
000076b67a9d9d4d  vmovaps [rsp+0xB0], xmm12
000076b67a9d9d56  vmovaps [rsp+0xC0], xmm13
000076b67a9d9d5f  vmovaps [rsp+0xD0], xmm14
000076b67a9d9d68  vmovaps [rsp+0xE0], xmm15
000076b67a9d9d71  sub rsp, 0x30
000076b67a9d9d75  movaps [rsp], xmm10
000076b67a9d9d7a  movaps [rsp+0x10], xmm14
000076b67a9d9d80  movaps [rsp+0x20], xmm4
000076b67a9d9d85  lea rdi, [rsp]
000076b67a9d9d89  mov esi, 0x00
000076b67a9d9d8e  mov rax, 0x63C5EF2DF530
000076b67a9d9d98  call rax
000076b67a9d9d9a  movaps xmm10, [rsp]
000076b67a9d9d9f  add rsp, 0x30
000076b67a9d9da3  vmovaps xmm0, [rsp]
000076b67a9d9da8  vmovaps xmm1, [rsp+0x10]
000076b67a9d9dae  vmovaps xmm2, [rsp+0x20]
000076b67a9d9db4  vmovaps xmm3, [rsp+0x30]
000076b67a9d9dba  vmovaps xmm4, [rsp+0x40]
000076b67a9d9dc0  vmovaps xmm5, [rsp+0x50]
000076b67a9d9dc6  vmovaps xmm6, [rsp+0x60]
000076b67a9d9dcc  vmovaps xmm7, [rsp+0x70]
000076b67a9d9dd2  vmovaps xmm8, [rsp+0x80]
000076b67a9d9ddb  vmovaps xmm9, [rsp+0x90]
000076b67a9d9de4  vmovaps xmm11, [rsp+0xA0]
000076b67a9d9ded  vmovaps xmm12, [rsp+0xB0]
000076b67a9d9df6  vmovaps xmm13, [rsp+0xC0]
000076b67a9d9dff  vmovaps xmm14, [rsp+0xD0]
000076b67a9d9e08  vmovaps xmm15, [rsp+0xE0]
000076b67a9d9e11  add rsp, 0xF0
000076b67a9d9e18  pop r11
000076b67a9d9e1a  pop r10
000076b67a9d9e1c  pop r9
000076b67a9d9e1e  pop r8
000076b67a9d9e20  pop rsi
000076b67a9d9e21  pop rdi
000076b67a9d9e22  pop rdx
000076b67a9d9e23  pop rcx
000076b67a9d9e24  pop rax
000076b67a9d9e25  add rsp, 0x08
000076b67a9d9e29  jmp 0x000076B67A9D6388
000076b67a9d9e2e  sub rsp, 0x08
000076b67a9d9e32  push rax
000076b67a9d9e33  push rcx
000076b67a9d9e34  push rdx
000076b67a9d9e35  push rdi
000076b67a9d9e36  push rsi
000076b67a9d9e37  push r8
000076b67a9d9e39  push r9
000076b67a9d9e3b  push r10
000076b67a9d9e3d  push r11
000076b67a9d9e3f  sub rsp, 0xF0
000076b67a9d9e46  vmovaps [rsp], xmm0
000076b67a9d9e4b  vmovaps [rsp+0x10], xmm1
000076b67a9d9e51  vmovaps [rsp+0x20], xmm2
000076b67a9d9e57  vmovaps [rsp+0x30], xmm3
000076b67a9d9e5d  vmovaps [rsp+0x40], xmm4
000076b67a9d9e63  vmovaps [rsp+0x50], xmm5
000076b67a9d9e69  vmovaps [rsp+0x60], xmm6
000076b67a9d9e6f  vmovaps [rsp+0x70], xmm7
000076b67a9d9e75  vmovaps [rsp+0x80], xmm9
000076b67a9d9e7e  vmovaps [rsp+0x90], xmm10
000076b67a9d9e87  vmovaps [rsp+0xA0], xmm11
000076b67a9d9e90  vmovaps [rsp+0xB0], xmm12
000076b67a9d9e99  vmovaps [rsp+0xC0], xmm13
000076b67a9d9ea2  vmovaps [rsp+0xD0], xmm14
000076b67a9d9eab  vmovaps [rsp+0xE0], xmm15
000076b67a9d9eb4  sub rsp, 0x30
000076b67a9d9eb8  movaps [rsp], xmm8
000076b67a9d9ebd  movaps [rsp+0x10], xmm1
000076b67a9d9ec2  movaps [rsp+0x20], xmm14
000076b67a9d9ec8  lea rdi, [rsp]
000076b67a9d9ecc  mov esi, 0x00
000076b67a9d9ed1  mov rax, 0x63C5EF2DF530
000076b67a9d9edb  call rax
000076b67a9d9edd  movaps xmm8, [rsp]
000076b67a9d9ee2  add rsp, 0x30
000076b67a9d9ee6  vmovaps xmm0, [rsp]
000076b67a9d9eeb  vmovaps xmm1, [rsp+0x10]
000076b67a9d9ef1  vmovaps xmm2, [rsp+0x20]
000076b67a9d9ef7  vmovaps xmm3, [rsp+0x30]
000076b67a9d9efd  vmovaps xmm4, [rsp+0x40]
000076b67a9d9f03  vmovaps xmm5, [rsp+0x50]
000076b67a9d9f09  vmovaps xmm6, [rsp+0x60]
000076b67a9d9f0f  vmovaps xmm7, [rsp+0x70]
000076b67a9d9f15  vmovaps xmm9, [rsp+0x80]
000076b67a9d9f1e  vmovaps xmm10, [rsp+0x90]
000076b67a9d9f27  vmovaps xmm11, [rsp+0xA0]
000076b67a9d9f30  vmovaps xmm12, [rsp+0xB0]
000076b67a9d9f39  vmovaps xmm13, [rsp+0xC0]
000076b67a9d9f42  vmovaps xmm14, [rsp+0xD0]
000076b67a9d9f4b  vmovaps xmm15, [rsp+0xE0]
000076b67a9d9f54  add rsp, 0xF0
000076b67a9d9f5b  pop r11
000076b67a9d9f5d  pop r10
000076b67a9d9f5f  pop r9
000076b67a9d9f61  pop r8
000076b67a9d9f63  pop rsi
000076b67a9d9f64  pop rdi
000076b67a9d9f65  pop rdx
000076b67a9d9f66  pop rcx
000076b67a9d9f67  pop rax
000076b67a9d9f68  add rsp, 0x08
000076b67a9d9f6c  jmp 0x000076B67A9D63AE
000076b67a9d9f71  sub rsp, 0x08
000076b67a9d9f75  push rax
000076b67a9d9f76  push rcx
000076b67a9d9f77  push rdx
000076b67a9d9f78  push rdi
000076b67a9d9f79  push rsi
000076b67a9d9f7a  push r8
000076b67a9d9f7c  push r9
000076b67a9d9f7e  push r10
000076b67a9d9f80  push r11
000076b67a9d9f82  sub rsp, 0xF0
000076b67a9d9f89  vmovaps [rsp], xmm0
000076b67a9d9f8e  vmovaps [rsp+0x10], xmm1
000076b67a9d9f94  vmovaps [rsp+0x20], xmm2
000076b67a9d9f9a  vmovaps [rsp+0x30], xmm3
000076b67a9d9fa0  vmovaps [rsp+0x40], xmm4
000076b67a9d9fa6  vmovaps [rsp+0x50], xmm5
000076b67a9d9fac  vmovaps [rsp+0x60], xmm7
000076b67a9d9fb2  vmovaps [rsp+0x70], xmm8
000076b67a9d9fb8  vmovaps [rsp+0x80], xmm9
000076b67a9d9fc1  vmovaps [rsp+0x90], xmm10
000076b67a9d9fca  vmovaps [rsp+0xA0], xmm11
000076b67a9d9fd3  vmovaps [rsp+0xB0], xmm12
000076b67a9d9fdc  vmovaps [rsp+0xC0], xmm13
000076b67a9d9fe5  vmovaps [rsp+0xD0], xmm14
000076b67a9d9fee  vmovaps [rsp+0xE0], xmm15
000076b67a9d9ff7  sub rsp, 0x30
000076b67a9d9ffb  movaps [rsp], xmm6
000076b67a9d9fff  movaps [rsp+0x10], xmm1
000076b67a9da004  movaps [rsp+0x20], xmm14
000076b67a9da00a  lea rdi, [rsp]
000076b67a9da00e  mov esi, 0x00
000076b67a9da013  mov rax, 0x63C5EF2DF530
000076b67a9da01d  call rax
000076b67a9da01f  movaps xmm6, [rsp]
000076b67a9da023  add rsp, 0x30
000076b67a9da027  vmovaps xmm0, [rsp]
000076b67a9da02c  vmovaps xmm1, [rsp+0x10]
000076b67a9da032  vmovaps xmm2, [rsp+0x20]
000076b67a9da038  vmovaps xmm3, [rsp+0x30]
000076b67a9da03e  vmovaps xmm4, [rsp+0x40]
000076b67a9da044  vmovaps xmm5, [rsp+0x50]
000076b67a9da04a  vmovaps xmm7, [rsp+0x60]
000076b67a9da050  vmovaps xmm8, [rsp+0x70]
000076b67a9da056  vmovaps xmm9, [rsp+0x80]
000076b67a9da05f  vmovaps xmm10, [rsp+0x90]
000076b67a9da068  vmovaps xmm11, [rsp+0xA0]
000076b67a9da071  vmovaps xmm12, [rsp+0xB0]
000076b67a9da07a  vmovaps xmm13, [rsp+0xC0]
000076b67a9da083  vmovaps xmm14, [rsp+0xD0]
000076b67a9da08c  vmovaps xmm15, [rsp+0xE0]
000076b67a9da095  add rsp, 0xF0
000076b67a9da09c  pop r11
000076b67a9da09e  pop r10
000076b67a9da0a0  pop r9
000076b67a9da0a2  pop r8
000076b67a9da0a4  pop rsi
000076b67a9da0a5  pop rdi
000076b67a9da0a6  pop rdx
000076b67a9da0a7  pop rcx
000076b67a9da0a8  pop rax
000076b67a9da0a9  add rsp, 0x08
000076b67a9da0ad  jmp 0x000076B67A9D63DA
000076b67a9da0b2  sub rsp, 0x08
000076b67a9da0b6  push rax
000076b67a9da0b7  push rcx
000076b67a9da0b8  push rdx
000076b67a9da0b9  push rdi
000076b67a9da0ba  push rsi
000076b67a9da0bb  push r8
000076b67a9da0bd  push r9
000076b67a9da0bf  push r10
000076b67a9da0c1  push r11
000076b67a9da0c3  sub rsp, 0xF0
000076b67a9da0ca  vmovaps [rsp], xmm0
000076b67a9da0cf  vmovaps [rsp+0x10], xmm1
000076b67a9da0d5  vmovaps [rsp+0x20], xmm2
000076b67a9da0db  vmovaps [rsp+0x30], xmm3
000076b67a9da0e1  vmovaps [rsp+0x40], xmm4
000076b67a9da0e7  vmovaps [rsp+0x50], xmm5
000076b67a9da0ed  vmovaps [rsp+0x60], xmm6
000076b67a9da0f3  vmovaps [rsp+0x70], xmm7
000076b67a9da0f9  vmovaps [rsp+0x80], xmm8
000076b67a9da102  vmovaps [rsp+0x90], xmm9
000076b67a9da10b  vmovaps [rsp+0xA0], xmm10
000076b67a9da114  vmovaps [rsp+0xB0], xmm11
000076b67a9da11d  vmovaps [rsp+0xC0], xmm12
000076b67a9da126  vmovaps [rsp+0xD0], xmm13
000076b67a9da12f  vmovaps [rsp+0xE0], xmm15
000076b67a9da138  sub rsp, 0x30
000076b67a9da13c  movaps [rsp], xmm14
000076b67a9da141  movaps [rsp+0x10], xmm12
000076b67a9da147  movaps [rsp+0x20], xmm1
000076b67a9da14c  lea rdi, [rsp]
000076b67a9da150  mov esi, 0x00
000076b67a9da155  mov rax, 0x63C5EF2DF530
000076b67a9da15f  call rax
000076b67a9da161  movaps xmm14, [rsp]
000076b67a9da166  add rsp, 0x30
000076b67a9da16a  vmovaps xmm0, [rsp]
000076b67a9da16f  vmovaps xmm1, [rsp+0x10]
000076b67a9da175  vmovaps xmm2, [rsp+0x20]
000076b67a9da17b  vmovaps xmm3, [rsp+0x30]
000076b67a9da181  vmovaps xmm4, [rsp+0x40]
000076b67a9da187  vmovaps xmm5, [rsp+0x50]
000076b67a9da18d  vmovaps xmm6, [rsp+0x60]
000076b67a9da193  vmovaps xmm7, [rsp+0x70]
000076b67a9da199  vmovaps xmm8, [rsp+0x80]
000076b67a9da1a2  vmovaps xmm9, [rsp+0x90]
000076b67a9da1ab  vmovaps xmm10, [rsp+0xA0]
000076b67a9da1b4  vmovaps xmm11, [rsp+0xB0]
000076b67a9da1bd  vmovaps xmm12, [rsp+0xC0]
000076b67a9da1c6  vmovaps xmm13, [rsp+0xD0]
000076b67a9da1cf  vmovaps xmm15, [rsp+0xE0]
000076b67a9da1d8  add rsp, 0xF0
000076b67a9da1df  pop r11
000076b67a9da1e1  pop r10
000076b67a9da1e3  pop r9
000076b67a9da1e5  pop r8
000076b67a9da1e7  pop rsi
000076b67a9da1e8  pop rdi
000076b67a9da1e9  pop rdx
000076b67a9da1ea  pop rcx
000076b67a9da1eb  pop rax
000076b67a9da1ec  add rsp, 0x08
000076b67a9da1f0  jmp 0x000076B67A9D6400
000076b67a9da1f5  sub rsp, 0x08
000076b67a9da1f9  push rax
000076b67a9da1fa  push rcx
000076b67a9da1fb  push rdx
000076b67a9da1fc  push rdi
000076b67a9da1fd  push rsi
000076b67a9da1fe  push r8
000076b67a9da200  push r9
000076b67a9da202  push r10
000076b67a9da204  push r11
000076b67a9da206  sub rsp, 0xF0
000076b67a9da20d  vmovaps [rsp], xmm0
000076b67a9da212  vmovaps [rsp+0x10], xmm2
000076b67a9da218  vmovaps [rsp+0x20], xmm3
000076b67a9da21e  vmovaps [rsp+0x30], xmm4
000076b67a9da224  vmovaps [rsp+0x40], xmm5
000076b67a9da22a  vmovaps [rsp+0x50], xmm6
000076b67a9da230  vmovaps [rsp+0x60], xmm7
000076b67a9da236  vmovaps [rsp+0x70], xmm8
000076b67a9da23c  vmovaps [rsp+0x80], xmm9
000076b67a9da245  vmovaps [rsp+0x90], xmm10
000076b67a9da24e  vmovaps [rsp+0xA0], xmm11
000076b67a9da257  vmovaps [rsp+0xB0], xmm12
000076b67a9da260  vmovaps [rsp+0xC0], xmm13
000076b67a9da269  vmovaps [rsp+0xD0], xmm14
000076b67a9da272  vmovaps [rsp+0xE0], xmm15
000076b67a9da27b  sub rsp, 0x30
000076b67a9da27f  movaps [rsp], xmm1
000076b67a9da283  movaps [rsp+0x10], xmm13
000076b67a9da289  movaps [rsp+0x20], xmm9
000076b67a9da28f  lea rdi, [rsp]
000076b67a9da293  mov esi, 0x00
000076b67a9da298  mov rax, 0x63C5EF2DF530
000076b67a9da2a2  call rax
000076b67a9da2a4  movaps xmm1, [rsp]
000076b67a9da2a8  add rsp, 0x30
000076b67a9da2ac  vmovaps xmm0, [rsp]
000076b67a9da2b1  vmovaps xmm2, [rsp+0x10]
000076b67a9da2b7  vmovaps xmm3, [rsp+0x20]
000076b67a9da2bd  vmovaps xmm4, [rsp+0x30]
000076b67a9da2c3  vmovaps xmm5, [rsp+0x40]
000076b67a9da2c9  vmovaps xmm6, [rsp+0x50]
000076b67a9da2cf  vmovaps xmm7, [rsp+0x60]
000076b67a9da2d5  vmovaps xmm8, [rsp+0x70]
000076b67a9da2db  vmovaps xmm9, [rsp+0x80]
000076b67a9da2e4  vmovaps xmm10, [rsp+0x90]
000076b67a9da2ed  vmovaps xmm11, [rsp+0xA0]
000076b67a9da2f6  vmovaps xmm12, [rsp+0xB0]
000076b67a9da2ff  vmovaps xmm13, [rsp+0xC0]
000076b67a9da308  vmovaps xmm14, [rsp+0xD0]
000076b67a9da311  vmovaps xmm15, [rsp+0xE0]
000076b67a9da31a  add rsp, 0xF0
000076b67a9da321  pop r11
000076b67a9da323  pop r10
000076b67a9da325  pop r9
000076b67a9da327  pop r8
000076b67a9da329  pop rsi
000076b67a9da32a  pop rdi
000076b67a9da32b  pop rdx
000076b67a9da32c  pop rcx
000076b67a9da32d  pop rax
000076b67a9da32e  add rsp, 0x08
000076b67a9da332  jmp 0x000076B67A9D641A
000076b67a9da337  sub rsp, 0x08
000076b67a9da33b  push rax
000076b67a9da33c  push rcx
000076b67a9da33d  push rdx
000076b67a9da33e  push rdi
000076b67a9da33f  push rsi
000076b67a9da340  push r8
000076b67a9da342  push r9
000076b67a9da344  push r10
000076b67a9da346  push r11
000076b67a9da348  sub rsp, 0xF0
000076b67a9da34f  vmovaps [rsp], xmm0
000076b67a9da354  vmovaps [rsp+0x10], xmm1
000076b67a9da35a  vmovaps [rsp+0x20], xmm2
000076b67a9da360  vmovaps [rsp+0x30], xmm3
000076b67a9da366  vmovaps [rsp+0x40], xmm4
000076b67a9da36c  vmovaps [rsp+0x50], xmm5
000076b67a9da372  vmovaps [rsp+0x60], xmm6
000076b67a9da378  vmovaps [rsp+0x70], xmm7
000076b67a9da37e  vmovaps [rsp+0x80], xmm8
000076b67a9da387  vmovaps [rsp+0x90], xmm9
000076b67a9da390  vmovaps [rsp+0xA0], xmm10
000076b67a9da399  vmovaps [rsp+0xB0], xmm11
000076b67a9da3a2  vmovaps [rsp+0xC0], xmm13
000076b67a9da3ab  vmovaps [rsp+0xD0], xmm14
000076b67a9da3b4  vmovaps [rsp+0xE0], xmm15
000076b67a9da3bd  sub rsp, 0x30
000076b67a9da3c1  movaps [rsp], xmm12
000076b67a9da3c6  movaps [rsp+0x10], xmm7
000076b67a9da3cb  movaps [rsp+0x20], xmm13
000076b67a9da3d1  lea rdi, [rsp]
000076b67a9da3d5  mov esi, 0x00
000076b67a9da3da  mov rax, 0x63C5EF2DF530
000076b67a9da3e4  call rax
000076b67a9da3e6  movaps xmm12, [rsp]
000076b67a9da3eb  add rsp, 0x30
000076b67a9da3ef  vmovaps xmm0, [rsp]
000076b67a9da3f4  vmovaps xmm1, [rsp+0x10]
000076b67a9da3fa  vmovaps xmm2, [rsp+0x20]
000076b67a9da400  vmovaps xmm3, [rsp+0x30]
000076b67a9da406  vmovaps xmm4, [rsp+0x40]
000076b67a9da40c  vmovaps xmm5, [rsp+0x50]
000076b67a9da412  vmovaps xmm6, [rsp+0x60]
000076b67a9da418  vmovaps xmm7, [rsp+0x70]
000076b67a9da41e  vmovaps xmm8, [rsp+0x80]
000076b67a9da427  vmovaps xmm9, [rsp+0x90]
000076b67a9da430  vmovaps xmm10, [rsp+0xA0]
000076b67a9da439  vmovaps xmm11, [rsp+0xB0]
000076b67a9da442  vmovaps xmm13, [rsp+0xC0]
000076b67a9da44b  vmovaps xmm14, [rsp+0xD0]
000076b67a9da454  vmovaps xmm15, [rsp+0xE0]
000076b67a9da45d  add rsp, 0xF0
000076b67a9da464  pop r11
000076b67a9da466  pop r10
000076b67a9da468  pop r9
000076b67a9da46a  pop r8
000076b67a9da46c  pop rsi
000076b67a9da46d  pop rdi
000076b67a9da46e  pop rdx
000076b67a9da46f  pop rcx
000076b67a9da470  pop rax
000076b67a9da471  add rsp, 0x08
000076b67a9da475  jmp 0x000076B67A9D6441
000076b67a9da47a  sub rsp, 0x08
000076b67a9da47e  push rax
000076b67a9da47f  push rcx
000076b67a9da480  push rdx
000076b67a9da481  push rdi
000076b67a9da482  push rsi
000076b67a9da483  push r8
000076b67a9da485  push r9
000076b67a9da487  push r10
000076b67a9da489  push r11
000076b67a9da48b  sub rsp, 0xF0
000076b67a9da492  vmovaps [rsp], xmm0
000076b67a9da497  vmovaps [rsp+0x10], xmm1
000076b67a9da49d  vmovaps [rsp+0x20], xmm2
000076b67a9da4a3  vmovaps [rsp+0x30], xmm3
000076b67a9da4a9  vmovaps [rsp+0x40], xmm4
000076b67a9da4af  vmovaps [rsp+0x50], xmm5
000076b67a9da4b5  vmovaps [rsp+0x60], xmm6
000076b67a9da4bb  vmovaps [rsp+0x70], xmm7
000076b67a9da4c1  vmovaps [rsp+0x80], xmm8
000076b67a9da4ca  vmovaps [rsp+0x90], xmm9
000076b67a9da4d3  vmovaps [rsp+0xA0], xmm10
000076b67a9da4dc  vmovaps [rsp+0xB0], xmm11
000076b67a9da4e5  vmovaps [rsp+0xC0], xmm12
000076b67a9da4ee  vmovaps [rsp+0xD0], xmm14
000076b67a9da4f7  vmovaps [rsp+0xE0], xmm15
000076b67a9da500  sub rsp, 0x30
000076b67a9da504  movaps [rsp], xmm13
000076b67a9da509  movaps [rsp+0x10], xmm15
000076b67a9da50f  movaps [rsp+0x20], xmm8
000076b67a9da515  lea rdi, [rsp]
000076b67a9da519  mov esi, 0x00
000076b67a9da51e  mov rax, 0x63C5EF2DF530
000076b67a9da528  call rax
000076b67a9da52a  movaps xmm13, [rsp]
000076b67a9da52f  add rsp, 0x30
000076b67a9da533  vmovaps xmm0, [rsp]
000076b67a9da538  vmovaps xmm1, [rsp+0x10]
000076b67a9da53e  vmovaps xmm2, [rsp+0x20]
000076b67a9da544  vmovaps xmm3, [rsp+0x30]
000076b67a9da54a  vmovaps xmm4, [rsp+0x40]
000076b67a9da550  vmovaps xmm5, [rsp+0x50]
000076b67a9da556  vmovaps xmm6, [rsp+0x60]
000076b67a9da55c  vmovaps xmm7, [rsp+0x70]
000076b67a9da562  vmovaps xmm8, [rsp+0x80]
000076b67a9da56b  vmovaps xmm9, [rsp+0x90]
000076b67a9da574  vmovaps xmm10, [rsp+0xA0]
000076b67a9da57d  vmovaps xmm11, [rsp+0xB0]
000076b67a9da586  vmovaps xmm12, [rsp+0xC0]
000076b67a9da58f  vmovaps xmm14, [rsp+0xD0]
000076b67a9da598  vmovaps xmm15, [rsp+0xE0]
000076b67a9da5a1  add rsp, 0xF0
000076b67a9da5a8  pop r11
000076b67a9da5aa  pop r10
000076b67a9da5ac  pop r9
000076b67a9da5ae  pop r8
000076b67a9da5b0  pop rsi
000076b67a9da5b1  pop rdi
000076b67a9da5b2  pop rdx
000076b67a9da5b3  pop rcx
000076b67a9da5b4  pop rax
000076b67a9da5b5  add rsp, 0x08
000076b67a9da5b9  jmp 0x000076B67A9D645C
000076b67a9da5be  sub rsp, 0x08
000076b67a9da5c2  push rax
000076b67a9da5c3  push rcx
000076b67a9da5c4  push rdx
000076b67a9da5c5  push rdi
000076b67a9da5c6  push rsi
000076b67a9da5c7  push r8
000076b67a9da5c9  push r9
000076b67a9da5cb  push r10
000076b67a9da5cd  push r11
000076b67a9da5cf  sub rsp, 0xF0
000076b67a9da5d6  vmovaps [rsp], xmm0
000076b67a9da5db  vmovaps [rsp+0x10], xmm1
000076b67a9da5e1  vmovaps [rsp+0x20], xmm2
000076b67a9da5e7  vmovaps [rsp+0x30], xmm3
000076b67a9da5ed  vmovaps [rsp+0x40], xmm4
000076b67a9da5f3  vmovaps [rsp+0x50], xmm5
000076b67a9da5f9  vmovaps [rsp+0x60], xmm6
000076b67a9da5ff  vmovaps [rsp+0x70], xmm7
000076b67a9da605  vmovaps [rsp+0x80], xmm9
000076b67a9da60e  vmovaps [rsp+0x90], xmm10
000076b67a9da617  vmovaps [rsp+0xA0], xmm11
000076b67a9da620  vmovaps [rsp+0xB0], xmm12
000076b67a9da629  vmovaps [rsp+0xC0], xmm13
000076b67a9da632  vmovaps [rsp+0xD0], xmm14
000076b67a9da63b  vmovaps [rsp+0xE0], xmm15
000076b67a9da644  sub rsp, 0x30
000076b67a9da648  movaps [rsp], xmm8
000076b67a9da64d  movaps [rsp+0x10], xmm15
000076b67a9da653  movaps [rsp+0x20], xmm9
000076b67a9da659  lea rdi, [rsp]
000076b67a9da65d  mov esi, 0x00
000076b67a9da662  mov rax, 0x63C5EF2DF530
000076b67a9da66c  call rax
000076b67a9da66e  movaps xmm8, [rsp]
000076b67a9da673  add rsp, 0x30
000076b67a9da677  vmovaps xmm0, [rsp]
000076b67a9da67c  vmovaps xmm1, [rsp+0x10]
000076b67a9da682  vmovaps xmm2, [rsp+0x20]
000076b67a9da688  vmovaps xmm3, [rsp+0x30]
000076b67a9da68e  vmovaps xmm4, [rsp+0x40]
000076b67a9da694  vmovaps xmm5, [rsp+0x50]
000076b67a9da69a  vmovaps xmm6, [rsp+0x60]
000076b67a9da6a0  vmovaps xmm7, [rsp+0x70]
000076b67a9da6a6  vmovaps xmm9, [rsp+0x80]
000076b67a9da6af  vmovaps xmm10, [rsp+0x90]
000076b67a9da6b8  vmovaps xmm11, [rsp+0xA0]
000076b67a9da6c1  vmovaps xmm12, [rsp+0xB0]
000076b67a9da6ca  vmovaps xmm13, [rsp+0xC0]
000076b67a9da6d3  vmovaps xmm14, [rsp+0xD0]
000076b67a9da6dc  vmovaps xmm15, [rsp+0xE0]
000076b67a9da6e5  add rsp, 0xF0
000076b67a9da6ec  pop r11
000076b67a9da6ee  pop r10
000076b67a9da6f0  pop r9
000076b67a9da6f2  pop r8
000076b67a9da6f4  pop rsi
000076b67a9da6f5  pop rdi
000076b67a9da6f6  pop rdx
000076b67a9da6f7  pop rcx
000076b67a9da6f8  pop rax
000076b67a9da6f9  add rsp, 0x08
000076b67a9da6fd  jmp 0x000076B67A9D648A
000076b67a9da702  sub rsp, 0x08
000076b67a9da706  push rax
000076b67a9da707  push rcx
000076b67a9da708  push rdx
000076b67a9da709  push rdi
000076b67a9da70a  push rsi
000076b67a9da70b  push r8
000076b67a9da70d  push r9
000076b67a9da70f  push r10
000076b67a9da711  push r11
000076b67a9da713  sub rsp, 0xF0
000076b67a9da71a  vmovaps [rsp], xmm0
000076b67a9da71f  vmovaps [rsp+0x10], xmm1
000076b67a9da725  vmovaps [rsp+0x20], xmm2
000076b67a9da72b  vmovaps [rsp+0x30], xmm3
000076b67a9da731  vmovaps [rsp+0x40], xmm4
000076b67a9da737  vmovaps [rsp+0x50], xmm5
000076b67a9da73d  vmovaps [rsp+0x60], xmm6
000076b67a9da743  vmovaps [rsp+0x70], xmm7
000076b67a9da749  vmovaps [rsp+0x80], xmm8
000076b67a9da752  vmovaps [rsp+0x90], xmm9
000076b67a9da75b  vmovaps [rsp+0xA0], xmm10
000076b67a9da764  vmovaps [rsp+0xB0], xmm11
000076b67a9da76d  vmovaps [rsp+0xC0], xmm12
000076b67a9da776  vmovaps [rsp+0xD0], xmm13
000076b67a9da77f  vmovaps [rsp+0xE0], xmm14
000076b67a9da788  sub rsp, 0x30
000076b67a9da78c  movaps [rsp], xmm15
000076b67a9da791  movaps [rsp+0x10], xmm11
000076b67a9da797  movaps [rsp+0x20], xmm6
000076b67a9da79c  lea rdi, [rsp]
000076b67a9da7a0  mov esi, 0x00
000076b67a9da7a5  mov rax, 0x63C5EF2DF530
000076b67a9da7af  call rax
000076b67a9da7b1  movaps xmm15, [rsp]
000076b67a9da7b6  add rsp, 0x30
000076b67a9da7ba  vmovaps xmm0, [rsp]
000076b67a9da7bf  vmovaps xmm1, [rsp+0x10]
000076b67a9da7c5  vmovaps xmm2, [rsp+0x20]
000076b67a9da7cb  vmovaps xmm3, [rsp+0x30]
000076b67a9da7d1  vmovaps xmm4, [rsp+0x40]
000076b67a9da7d7  vmovaps xmm5, [rsp+0x50]
000076b67a9da7dd  vmovaps xmm6, [rsp+0x60]
000076b67a9da7e3  vmovaps xmm7, [rsp+0x70]
000076b67a9da7e9  vmovaps xmm8, [rsp+0x80]
000076b67a9da7f2  vmovaps xmm9, [rsp+0x90]
000076b67a9da7fb  vmovaps xmm10, [rsp+0xA0]
000076b67a9da804  vmovaps xmm11, [rsp+0xB0]
000076b67a9da80d  vmovaps xmm12, [rsp+0xC0]
000076b67a9da816  vmovaps xmm13, [rsp+0xD0]
000076b67a9da81f  vmovaps xmm14, [rsp+0xE0]
000076b67a9da828  add rsp, 0xF0
000076b67a9da82f  pop r11
000076b67a9da831  pop r10
000076b67a9da833  pop r9
000076b67a9da835  pop r8
000076b67a9da837  pop rsi
000076b67a9da838  pop rdi
000076b67a9da839  pop rdx
000076b67a9da83a  pop rcx
000076b67a9da83b  pop rax
000076b67a9da83c  add rsp, 0x08
000076b67a9da840  jmp 0x000076B67A9D64A5
000076b67a9da845  sub rsp, 0x08
000076b67a9da849  push rax
000076b67a9da84a  push rcx
000076b67a9da84b  push rdx
000076b67a9da84c  push rdi
000076b67a9da84d  push rsi
000076b67a9da84e  push r8
000076b67a9da850  push r9
000076b67a9da852  push r10
000076b67a9da854  push r11
000076b67a9da856  sub rsp, 0xF0
000076b67a9da85d  vmovaps [rsp], xmm0
000076b67a9da862  vmovaps [rsp+0x10], xmm1
000076b67a9da868  vmovaps [rsp+0x20], xmm2
000076b67a9da86e  vmovaps [rsp+0x30], xmm3
000076b67a9da874  vmovaps [rsp+0x40], xmm4
000076b67a9da87a  vmovaps [rsp+0x50], xmm5
000076b67a9da880  vmovaps [rsp+0x60], xmm6
000076b67a9da886  vmovaps [rsp+0x70], xmm8
000076b67a9da88c  vmovaps [rsp+0x80], xmm9
000076b67a9da895  vmovaps [rsp+0x90], xmm10
000076b67a9da89e  vmovaps [rsp+0xA0], xmm11
000076b67a9da8a7  vmovaps [rsp+0xB0], xmm12
000076b67a9da8b0  vmovaps [rsp+0xC0], xmm13
000076b67a9da8b9  vmovaps [rsp+0xD0], xmm14
000076b67a9da8c2  vmovaps [rsp+0xE0], xmm15
000076b67a9da8cb  sub rsp, 0x30
000076b67a9da8cf  movaps [rsp], xmm7
000076b67a9da8d3  movaps [rsp+0x10], xmm11
000076b67a9da8d9  movaps [rsp+0x20], xmm9
000076b67a9da8df  lea rdi, [rsp]
000076b67a9da8e3  mov esi, 0x00
000076b67a9da8e8  mov rax, 0x63C5EF2DF530
000076b67a9da8f2  call rax
000076b67a9da8f4  movaps xmm7, [rsp]
000076b67a9da8f8  add rsp, 0x30
000076b67a9da8fc  vmovaps xmm0, [rsp]
000076b67a9da901  vmovaps xmm1, [rsp+0x10]
000076b67a9da907  vmovaps xmm2, [rsp+0x20]
000076b67a9da90d  vmovaps xmm3, [rsp+0x30]
000076b67a9da913  vmovaps xmm4, [rsp+0x40]
000076b67a9da919  vmovaps xmm5, [rsp+0x50]
000076b67a9da91f  vmovaps xmm6, [rsp+0x60]
000076b67a9da925  vmovaps xmm8, [rsp+0x70]
000076b67a9da92b  vmovaps xmm9, [rsp+0x80]
000076b67a9da934  vmovaps xmm10, [rsp+0x90]
000076b67a9da93d  vmovaps xmm11, [rsp+0xA0]
000076b67a9da946  vmovaps xmm12, [rsp+0xB0]
000076b67a9da94f  vmovaps xmm13, [rsp+0xC0]
000076b67a9da958  vmovaps xmm14, [rsp+0xD0]
000076b67a9da961  vmovaps xmm15, [rsp+0xE0]
000076b67a9da96a  add rsp, 0xF0
000076b67a9da971  pop r11
000076b67a9da973  pop r10
000076b67a9da975  pop r9
000076b67a9da977  pop r8
000076b67a9da979  pop rsi
000076b67a9da97a  pop rdi
000076b67a9da97b  pop rdx
000076b67a9da97c  pop rcx
000076b67a9da97d  pop rax
000076b67a9da97e  add rsp, 0x08
000076b67a9da982  jmp 0x000076B67A9D64D2
000076b67a9da987  sub rsp, 0x08
000076b67a9da98b  push rax
000076b67a9da98c  push rcx
000076b67a9da98d  push rdx
000076b67a9da98e  push rdi
000076b67a9da98f  push rsi
000076b67a9da990  push r8
000076b67a9da992  push r9
000076b67a9da994  push r10
000076b67a9da996  push r11
000076b67a9da998  sub rsp, 0xF0
000076b67a9da99f  vmovaps [rsp], xmm0
000076b67a9da9a4  vmovaps [rsp+0x10], xmm1
000076b67a9da9aa  vmovaps [rsp+0x20], xmm2
000076b67a9da9b0  vmovaps [rsp+0x30], xmm3
000076b67a9da9b6  vmovaps [rsp+0x40], xmm4
000076b67a9da9bc  vmovaps [rsp+0x50], xmm5
000076b67a9da9c2  vmovaps [rsp+0x60], xmm6
000076b67a9da9c8  vmovaps [rsp+0x70], xmm7
000076b67a9da9ce  vmovaps [rsp+0x80], xmm8
000076b67a9da9d7  vmovaps [rsp+0x90], xmm9
000076b67a9da9e0  vmovaps [rsp+0xA0], xmm10
000076b67a9da9e9  vmovaps [rsp+0xB0], xmm12
000076b67a9da9f2  vmovaps [rsp+0xC0], xmm13
000076b67a9da9fb  vmovaps [rsp+0xD0], xmm14
000076b67a9daa04  vmovaps [rsp+0xE0], xmm15
000076b67a9daa0d  sub rsp, 0x30
000076b67a9daa11  movaps [rsp], xmm11
000076b67a9daa16  movaps [rsp+0x10], xmm10
000076b67a9daa1c  movaps [rsp+0x20], xmm14
000076b67a9daa22  lea rdi, [rsp]
000076b67a9daa26  mov esi, 0x00
000076b67a9daa2b  mov rax, 0x63C5EF2DF530
000076b67a9daa35  call rax
000076b67a9daa37  movaps xmm11, [rsp]
000076b67a9daa3c  add rsp, 0x30
000076b67a9daa40  vmovaps xmm0, [rsp]
000076b67a9daa45  vmovaps xmm1, [rsp+0x10]
000076b67a9daa4b  vmovaps xmm2, [rsp+0x20]
000076b67a9daa51  vmovaps xmm3, [rsp+0x30]
000076b67a9daa57  vmovaps xmm4, [rsp+0x40]
000076b67a9daa5d  vmovaps xmm5, [rsp+0x50]
000076b67a9daa63  vmovaps xmm6, [rsp+0x60]
000076b67a9daa69  vmovaps xmm7, [rsp+0x70]
000076b67a9daa6f  vmovaps xmm8, [rsp+0x80]
000076b67a9daa78  vmovaps xmm9, [rsp+0x90]
000076b67a9daa81  vmovaps xmm10, [rsp+0xA0]
000076b67a9daa8a  vmovaps xmm12, [rsp+0xB0]
000076b67a9daa93  vmovaps xmm13, [rsp+0xC0]
000076b67a9daa9c  vmovaps xmm14, [rsp+0xD0]
000076b67a9daaa5  vmovaps xmm15, [rsp+0xE0]
000076b67a9daaae  add rsp, 0xF0
000076b67a9daab5  pop r11
000076b67a9daab7  pop r10
000076b67a9daab9  pop r9
000076b67a9daabb  pop r8
000076b67a9daabd  pop rsi
000076b67a9daabe  pop rdi
000076b67a9daabf  pop rdx
000076b67a9daac0  pop rcx
000076b67a9daac1  pop rax
000076b67a9daac2  add rsp, 0x08
000076b67a9daac6  jmp 0x000076B67A9D64ED
000076b67a9daacb  call 0x000076B67A8E45A0
000076b67a9daad0  jmp 0x000076B67A9D64F7
000076b67a9daad5  sub rsp, 0x08
000076b67a9daad9  push rax
000076b67a9daada  push rcx
000076b67a9daadb  push rdx
000076b67a9daadc  push rdi
000076b67a9daadd  push rsi
000076b67a9daade  push r8
000076b67a9daae0  push r9
000076b67a9daae2  push r10
000076b67a9daae4  push r11
000076b67a9daae6  sub rsp, 0xF0
000076b67a9daaed  vmovaps [rsp], xmm0
000076b67a9daaf2  vmovaps [rsp+0x10], xmm1
000076b67a9daaf8  vmovaps [rsp+0x20], xmm2
000076b67a9daafe  vmovaps [rsp+0x30], xmm3
000076b67a9dab04  vmovaps [rsp+0x40], xmm4
000076b67a9dab0a  vmovaps [rsp+0x50], xmm5
000076b67a9dab10  vmovaps [rsp+0x60], xmm6
000076b67a9dab16  vmovaps [rsp+0x70], xmm7
000076b67a9dab1c  vmovaps [rsp+0x80], xmm8
000076b67a9dab25  vmovaps [rsp+0x90], xmm9
000076b67a9dab2e  vmovaps [rsp+0xA0], xmm11
000076b67a9dab37  vmovaps [rsp+0xB0], xmm12
000076b67a9dab40  vmovaps [rsp+0xC0], xmm13
000076b67a9dab49  vmovaps [rsp+0xD0], xmm14
000076b67a9dab52  vmovaps [rsp+0xE0], xmm15
000076b67a9dab5b  sub rsp, 0x30
000076b67a9dab5f  movaps [rsp], xmm10
000076b67a9dab64  movaps [rsp+0x10], xmm1
000076b67a9dab69  movaps [rsp+0x20], xmm12
000076b67a9dab6f  lea rdi, [rsp]
000076b67a9dab73  mov esi, 0x00
000076b67a9dab78  mov rax, 0x63C5EF2DF530
000076b67a9dab82  call rax
000076b67a9dab84  movaps xmm10, [rsp]
000076b67a9dab89  add rsp, 0x30
000076b67a9dab8d  vmovaps xmm0, [rsp]
000076b67a9dab92  vmovaps xmm1, [rsp+0x10]
000076b67a9dab98  vmovaps xmm2, [rsp+0x20]
000076b67a9dab9e  vmovaps xmm3, [rsp+0x30]
000076b67a9daba4  vmovaps xmm4, [rsp+0x40]
000076b67a9dabaa  vmovaps xmm5, [rsp+0x50]
000076b67a9dabb0  vmovaps xmm6, [rsp+0x60]
000076b67a9dabb6  vmovaps xmm7, [rsp+0x70]
000076b67a9dabbc  vmovaps xmm8, [rsp+0x80]
000076b67a9dabc5  vmovaps xmm9, [rsp+0x90]
000076b67a9dabce  vmovaps xmm11, [rsp+0xA0]
000076b67a9dabd7  vmovaps xmm12, [rsp+0xB0]
000076b67a9dabe0  vmovaps xmm13, [rsp+0xC0]
000076b67a9dabe9  vmovaps xmm14, [rsp+0xD0]
000076b67a9dabf2  vmovaps xmm15, [rsp+0xE0]
000076b67a9dabfb  add rsp, 0xF0
000076b67a9dac02  pop r11
000076b67a9dac04  pop r10
000076b67a9dac06  pop r9
000076b67a9dac08  pop r8
000076b67a9dac0a  pop rsi
000076b67a9dac0b  pop rdi
000076b67a9dac0c  pop rdx
000076b67a9dac0d  pop rcx
000076b67a9dac0e  pop rax
000076b67a9dac0f  add rsp, 0x08
000076b67a9dac13  jmp 0x000076B67A9D651A
000076b67a9dac18  sub rsp, 0x08
000076b67a9dac1c  push rax
000076b67a9dac1d  push rcx
000076b67a9dac1e  push rdx
000076b67a9dac1f  push rdi
000076b67a9dac20  push rsi
000076b67a9dac21  push r8
000076b67a9dac23  push r9
000076b67a9dac25  push r10
000076b67a9dac27  push r11
000076b67a9dac29  sub rsp, 0xF0
000076b67a9dac30  vmovaps [rsp], xmm0
000076b67a9dac35  vmovaps [rsp+0x10], xmm1
000076b67a9dac3b  vmovaps [rsp+0x20], xmm2
000076b67a9dac41  vmovaps [rsp+0x30], xmm3
000076b67a9dac47  vmovaps [rsp+0x40], xmm4
000076b67a9dac4d  vmovaps [rsp+0x50], xmm5
000076b67a9dac53  vmovaps [rsp+0x60], xmm6
000076b67a9dac59  vmovaps [rsp+0x70], xmm7
000076b67a9dac5f  vmovaps [rsp+0x80], xmm8
000076b67a9dac68  vmovaps [rsp+0x90], xmm9
000076b67a9dac71  vmovaps [rsp+0xA0], xmm10
000076b67a9dac7a  vmovaps [rsp+0xB0], xmm11
000076b67a9dac83  vmovaps [rsp+0xC0], xmm13
000076b67a9dac8c  vmovaps [rsp+0xD0], xmm14
000076b67a9dac95  vmovaps [rsp+0xE0], xmm15
000076b67a9dac9e  sub rsp, 0x30
000076b67a9daca2  movaps [rsp], xmm12
000076b67a9daca7  movaps [rsp+0x10], xmm14
000076b67a9dacad  movaps [rsp+0x20], xmm1
000076b67a9dacb2  lea rdi, [rsp]
000076b67a9dacb6  mov esi, 0x00
000076b67a9dacbb  mov rax, 0x63C5EF2DF530
000076b67a9dacc5  call rax
000076b67a9dacc7  movaps xmm12, [rsp]
000076b67a9daccc  add rsp, 0x30
000076b67a9dacd0  vmovaps xmm0, [rsp]
000076b67a9dacd5  vmovaps xmm1, [rsp+0x10]
000076b67a9dacdb  vmovaps xmm2, [rsp+0x20]
000076b67a9dace1  vmovaps xmm3, [rsp+0x30]
000076b67a9dace7  vmovaps xmm4, [rsp+0x40]
000076b67a9daced  vmovaps xmm5, [rsp+0x50]
000076b67a9dacf3  vmovaps xmm6, [rsp+0x60]
000076b67a9dacf9  vmovaps xmm7, [rsp+0x70]
000076b67a9dacff  vmovaps xmm8, [rsp+0x80]
000076b67a9dad08  vmovaps xmm9, [rsp+0x90]
000076b67a9dad11  vmovaps xmm10, [rsp+0xA0]
000076b67a9dad1a  vmovaps xmm11, [rsp+0xB0]
000076b67a9dad23  vmovaps xmm13, [rsp+0xC0]
000076b67a9dad2c  vmovaps xmm14, [rsp+0xD0]
000076b67a9dad35  vmovaps xmm15, [rsp+0xE0]
000076b67a9dad3e  add rsp, 0xF0
000076b67a9dad45  pop r11
000076b67a9dad47  pop r10
000076b67a9dad49  pop r9
000076b67a9dad4b  pop r8
000076b67a9dad4d  pop rsi
000076b67a9dad4e  pop rdi
000076b67a9dad4f  pop rdx
000076b67a9dad50  pop rcx
000076b67a9dad51  pop rax
000076b67a9dad52  add rsp, 0x08
000076b67a9dad56  jmp 0x000076B67A9D6549
000076b67a9dad5b  sub rsp, 0x08
000076b67a9dad5f  push rax
000076b67a9dad60  push rcx
000076b67a9dad61  push rdx
000076b67a9dad62  push rdi
000076b67a9dad63  push rsi
000076b67a9dad64  push r8
000076b67a9dad66  push r9
000076b67a9dad68  push r10
000076b67a9dad6a  push r11
000076b67a9dad6c  sub rsp, 0xF0
000076b67a9dad73  vmovaps [rsp], xmm0
000076b67a9dad78  vmovaps [rsp+0x10], xmm1
000076b67a9dad7e  vmovaps [rsp+0x20], xmm2
000076b67a9dad84  vmovaps [rsp+0x30], xmm3
000076b67a9dad8a  vmovaps [rsp+0x40], xmm4
000076b67a9dad90  vmovaps [rsp+0x50], xmm5
000076b67a9dad96  vmovaps [rsp+0x60], xmm6
000076b67a9dad9c  vmovaps [rsp+0x70], xmm7
000076b67a9dada2  vmovaps [rsp+0x80], xmm8
000076b67a9dadab  vmovaps [rsp+0x90], xmm9
000076b67a9dadb4  vmovaps [rsp+0xA0], xmm10
000076b67a9dadbd  vmovaps [rsp+0xB0], xmm11
000076b67a9dadc6  vmovaps [rsp+0xC0], xmm12
000076b67a9dadcf  vmovaps [rsp+0xD0], xmm13
000076b67a9dadd8  vmovaps [rsp+0xE0], xmm15
000076b67a9dade1  sub rsp, 0x30
000076b67a9dade5  movaps [rsp], xmm14
000076b67a9dadea  movaps [rsp+0x10], xmm9
000076b67a9dadf0  movaps [rsp+0x20], xmm1
000076b67a9dadf5  lea rdi, [rsp]
000076b67a9dadf9  mov esi, 0x00
000076b67a9dadfe  mov rax, 0x63C5EF2DF530
000076b67a9dae08  call rax
000076b67a9dae0a  movaps xmm14, [rsp]
000076b67a9dae0f  add rsp, 0x30
000076b67a9dae13  vmovaps xmm0, [rsp]
000076b67a9dae18  vmovaps xmm1, [rsp+0x10]
000076b67a9dae1e  vmovaps xmm2, [rsp+0x20]
000076b67a9dae24  vmovaps xmm3, [rsp+0x30]
000076b67a9dae2a  vmovaps xmm4, [rsp+0x40]
000076b67a9dae30  vmovaps xmm5, [rsp+0x50]
000076b67a9dae36  vmovaps xmm6, [rsp+0x60]
000076b67a9dae3c  vmovaps xmm7, [rsp+0x70]
000076b67a9dae42  vmovaps xmm8, [rsp+0x80]
000076b67a9dae4b  vmovaps xmm9, [rsp+0x90]
000076b67a9dae54  vmovaps xmm10, [rsp+0xA0]
000076b67a9dae5d  vmovaps xmm11, [rsp+0xB0]
000076b67a9dae66  vmovaps xmm12, [rsp+0xC0]
000076b67a9dae6f  vmovaps xmm13, [rsp+0xD0]
000076b67a9dae78  vmovaps xmm15, [rsp+0xE0]
000076b67a9dae81  add rsp, 0xF0
000076b67a9dae88  pop r11
000076b67a9dae8a  pop r10
000076b67a9dae8c  pop r9
000076b67a9dae8e  pop r8
000076b67a9dae90  pop rsi
000076b67a9dae91  pop rdi
000076b67a9dae92  pop rdx
000076b67a9dae93  pop rcx
000076b67a9dae94  pop rax
000076b67a9dae95  add rsp, 0x08
000076b67a9dae99  jmp 0x000076B67A9D6578
000076b67a9dae9e  sub rsp, 0x08
000076b67a9daea2  push rax
000076b67a9daea3  push rcx
000076b67a9daea4  push rdx
000076b67a9daea5  push rdi
000076b67a9daea6  push rsi
000076b67a9daea7  push r8
000076b67a9daea9  push r9
000076b67a9daeab  push r10
000076b67a9daead  push r11
000076b67a9daeaf  sub rsp, 0xF0
000076b67a9daeb6  vmovaps [rsp], xmm0
000076b67a9daebb  vmovaps [rsp+0x10], xmm2
000076b67a9daec1  vmovaps [rsp+0x20], xmm3
000076b67a9daec7  vmovaps [rsp+0x30], xmm4
000076b67a9daecd  vmovaps [rsp+0x40], xmm5
000076b67a9daed3  vmovaps [rsp+0x50], xmm6
000076b67a9daed9  vmovaps [rsp+0x60], xmm7
000076b67a9daedf  vmovaps [rsp+0x70], xmm8
000076b67a9daee5  vmovaps [rsp+0x80], xmm9
000076b67a9daeee  vmovaps [rsp+0x90], xmm10
000076b67a9daef7  vmovaps [rsp+0xA0], xmm11
000076b67a9daf00  vmovaps [rsp+0xB0], xmm12
000076b67a9daf09  vmovaps [rsp+0xC0], xmm13
000076b67a9daf12  vmovaps [rsp+0xD0], xmm14
000076b67a9daf1b  vmovaps [rsp+0xE0], xmm15
000076b67a9daf24  sub rsp, 0x30
000076b67a9daf28  movaps [rsp], xmm1
000076b67a9daf2c  movaps [rsp+0x10], xmm13
000076b67a9daf32  movaps [rsp+0x20], xmm8
000076b67a9daf38  lea rdi, [rsp]
000076b67a9daf3c  mov esi, 0x00
000076b67a9daf41  mov rax, 0x63C5EF2DF530
000076b67a9daf4b  call rax
000076b67a9daf4d  movaps xmm1, [rsp]
000076b67a9daf51  add rsp, 0x30
000076b67a9daf55  vmovaps xmm0, [rsp]
000076b67a9daf5a  vmovaps xmm2, [rsp+0x10]
000076b67a9daf60  vmovaps xmm3, [rsp+0x20]
000076b67a9daf66  vmovaps xmm4, [rsp+0x30]
000076b67a9daf6c  vmovaps xmm5, [rsp+0x40]
000076b67a9daf72  vmovaps xmm6, [rsp+0x50]
000076b67a9daf78  vmovaps xmm7, [rsp+0x60]
000076b67a9daf7e  vmovaps xmm8, [rsp+0x70]
000076b67a9daf84  vmovaps xmm9, [rsp+0x80]
000076b67a9daf8d  vmovaps xmm10, [rsp+0x90]
000076b67a9daf96  vmovaps xmm11, [rsp+0xA0]
000076b67a9daf9f  vmovaps xmm12, [rsp+0xB0]
000076b67a9dafa8  vmovaps xmm13, [rsp+0xC0]
000076b67a9dafb1  vmovaps xmm14, [rsp+0xD0]
000076b67a9dafba  vmovaps xmm15, [rsp+0xE0]
000076b67a9dafc3  add rsp, 0xF0
000076b67a9dafca  pop r11
000076b67a9dafcc  pop r10
000076b67a9dafce  pop r9
000076b67a9dafd0  pop r8
000076b67a9dafd2  pop rsi
000076b67a9dafd3  pop rdi
000076b67a9dafd4  pop rdx
000076b67a9dafd5  pop rcx
000076b67a9dafd6  pop rax
000076b67a9dafd7  add rsp, 0x08
000076b67a9dafdb  jmp 0x000076B67A9D659A
000076b67a9dafe0  call 0x000076B67A80C260
000076b67a9dafe5  jmp 0x000076B67A9D65A8
000076b67a9dafea  call 0x000076B67A8DE950
000076b67a9dafef  jmp 0x000076B67A9D65B2
000076b67a9daff4  sub rsp, 0x08
000076b67a9daff8  push rax
000076b67a9daff9  push rcx
000076b67a9daffa  push rdx
000076b67a9daffb  push rdi
000076b67a9daffc  push rsi
000076b67a9daffd  push r8
000076b67a9dafff  push r9
000076b67a9db001  push r10
000076b67a9db003  push r11
000076b67a9db005  sub rsp, 0xF0
000076b67a9db00c  vmovaps [rsp], xmm0
000076b67a9db011  vmovaps [rsp+0x10], xmm1
000076b67a9db017  vmovaps [rsp+0x20], xmm2
000076b67a9db01d  vmovaps [rsp+0x30], xmm3
000076b67a9db023  vmovaps [rsp+0x40], xmm4
000076b67a9db029  vmovaps [rsp+0x50], xmm5
000076b67a9db02f  vmovaps [rsp+0x60], xmm6
000076b67a9db035  vmovaps [rsp+0x70], xmm7
000076b67a9db03b  vmovaps [rsp+0x80], xmm9
000076b67a9db044  vmovaps [rsp+0x90], xmm10
000076b67a9db04d  vmovaps [rsp+0xA0], xmm11
000076b67a9db056  vmovaps [rsp+0xB0], xmm12
000076b67a9db05f  vmovaps [rsp+0xC0], xmm13
000076b67a9db068  vmovaps [rsp+0xD0], xmm14
000076b67a9db071  vmovaps [rsp+0xE0], xmm15
000076b67a9db07a  sub rsp, 0x30
000076b67a9db07e  movaps [rsp], xmm8
000076b67a9db083  movaps [rsp+0x10], xmm15
000076b67a9db089  movaps [rsp+0x20], xmm7
000076b67a9db08e  lea rdi, [rsp]
000076b67a9db092  mov esi, 0x00
000076b67a9db097  mov rax, 0x63C5EF2DF530
000076b67a9db0a1  call rax
000076b67a9db0a3  movaps xmm8, [rsp]
000076b67a9db0a8  add rsp, 0x30
000076b67a9db0ac  vmovaps xmm0, [rsp]
000076b67a9db0b1  vmovaps xmm1, [rsp+0x10]
000076b67a9db0b7  vmovaps xmm2, [rsp+0x20]
000076b67a9db0bd  vmovaps xmm3, [rsp+0x30]
000076b67a9db0c3  vmovaps xmm4, [rsp+0x40]
000076b67a9db0c9  vmovaps xmm5, [rsp+0x50]
000076b67a9db0cf  vmovaps xmm6, [rsp+0x60]
000076b67a9db0d5  vmovaps xmm7, [rsp+0x70]
000076b67a9db0db  vmovaps xmm9, [rsp+0x80]
000076b67a9db0e4  vmovaps xmm10, [rsp+0x90]
000076b67a9db0ed  vmovaps xmm11, [rsp+0xA0]
000076b67a9db0f6  vmovaps xmm12, [rsp+0xB0]
000076b67a9db0ff  vmovaps xmm13, [rsp+0xC0]
000076b67a9db108  vmovaps xmm14, [rsp+0xD0]
000076b67a9db111  vmovaps xmm15, [rsp+0xE0]
000076b67a9db11a  add rsp, 0xF0
000076b67a9db121  pop r11
000076b67a9db123  pop r10
000076b67a9db125  pop r9
000076b67a9db127  pop r8
000076b67a9db129  pop rsi
000076b67a9db12a  pop rdi
000076b67a9db12b  pop rdx
000076b67a9db12c  pop rcx
000076b67a9db12d  pop rax
000076b67a9db12e  add rsp, 0x08
000076b67a9db132  jmp 0x000076B67A9D65D4
000076b67a9db137  sub rsp, 0x08
000076b67a9db13b  push rax
000076b67a9db13c  push rcx
000076b67a9db13d  push rdx
000076b67a9db13e  push rdi
000076b67a9db13f  push rsi
000076b67a9db140  push r8
000076b67a9db142  push r9
000076b67a9db144  push r10
000076b67a9db146  push r11
000076b67a9db148  sub rsp, 0xF0
000076b67a9db14f  vmovaps [rsp], xmm0
000076b67a9db154  vmovaps [rsp+0x10], xmm1
000076b67a9db15a  vmovaps [rsp+0x20], xmm2
000076b67a9db160  vmovaps [rsp+0x30], xmm3
000076b67a9db166  vmovaps [rsp+0x40], xmm4
000076b67a9db16c  vmovaps [rsp+0x50], xmm5
000076b67a9db172  vmovaps [rsp+0x60], xmm6
000076b67a9db178  vmovaps [rsp+0x70], xmm8
000076b67a9db17e  vmovaps [rsp+0x80], xmm9
000076b67a9db187  vmovaps [rsp+0x90], xmm10
000076b67a9db190  vmovaps [rsp+0xA0], xmm11
000076b67a9db199  vmovaps [rsp+0xB0], xmm12
000076b67a9db1a2  vmovaps [rsp+0xC0], xmm13
000076b67a9db1ab  vmovaps [rsp+0xD0], xmm14
000076b67a9db1b4  vmovaps [rsp+0xE0], xmm15
000076b67a9db1bd  sub rsp, 0x30
000076b67a9db1c1  movaps [rsp], xmm7
000076b67a9db1c5  movaps [rsp+0x10], xmm9
000076b67a9db1cb  movaps [rsp+0x20], xmm15
000076b67a9db1d1  lea rdi, [rsp]
000076b67a9db1d5  mov esi, 0x00
000076b67a9db1da  mov rax, 0x63C5EF2DF530
000076b67a9db1e4  call rax
000076b67a9db1e6  movaps xmm7, [rsp]
000076b67a9db1ea  add rsp, 0x30
000076b67a9db1ee  vmovaps xmm0, [rsp]
000076b67a9db1f3  vmovaps xmm1, [rsp+0x10]
000076b67a9db1f9  vmovaps xmm2, [rsp+0x20]
000076b67a9db1ff  vmovaps xmm3, [rsp+0x30]
000076b67a9db205  vmovaps xmm4, [rsp+0x40]
000076b67a9db20b  vmovaps xmm5, [rsp+0x50]
000076b67a9db211  vmovaps xmm6, [rsp+0x60]
000076b67a9db217  vmovaps xmm8, [rsp+0x70]
000076b67a9db21d  vmovaps xmm9, [rsp+0x80]
000076b67a9db226  vmovaps xmm10, [rsp+0x90]
000076b67a9db22f  vmovaps xmm11, [rsp+0xA0]
000076b67a9db238  vmovaps xmm12, [rsp+0xB0]
000076b67a9db241  vmovaps xmm13, [rsp+0xC0]
000076b67a9db24a  vmovaps xmm14, [rsp+0xD0]
000076b67a9db253  vmovaps xmm15, [rsp+0xE0]
000076b67a9db25c  add rsp, 0xF0
000076b67a9db263  pop r11
000076b67a9db265  pop r10
000076b67a9db267  pop r9
000076b67a9db269  pop r8
000076b67a9db26b  pop rsi
000076b67a9db26c  pop rdi
000076b67a9db26d  pop rdx
000076b67a9db26e  pop rcx
000076b67a9db26f  pop rax
000076b67a9db270  add rsp, 0x08
000076b67a9db274  jmp 0x000076B67A9D6601
000076b67a9db279  sub rsp, 0x08
000076b67a9db27d  push rax
000076b67a9db27e  push rcx
000076b67a9db27f  push rdx
000076b67a9db280  push rdi
000076b67a9db281  push rsi
000076b67a9db282  push r8
000076b67a9db284  push r9
000076b67a9db286  push r10
000076b67a9db288  push r11
000076b67a9db28a  sub rsp, 0xF0
000076b67a9db291  vmovaps [rsp], xmm0
000076b67a9db296  vmovaps [rsp+0x10], xmm1
000076b67a9db29c  vmovaps [rsp+0x20], xmm2
000076b67a9db2a2  vmovaps [rsp+0x30], xmm3
000076b67a9db2a8  vmovaps [rsp+0x40], xmm4
000076b67a9db2ae  vmovaps [rsp+0x50], xmm5
000076b67a9db2b4  vmovaps [rsp+0x60], xmm6
000076b67a9db2ba  vmovaps [rsp+0x70], xmm7
000076b67a9db2c0  vmovaps [rsp+0x80], xmm8
000076b67a9db2c9  vmovaps [rsp+0x90], xmm10
000076b67a9db2d2  vmovaps [rsp+0xA0], xmm11
000076b67a9db2db  vmovaps [rsp+0xB0], xmm12
000076b67a9db2e4  vmovaps [rsp+0xC0], xmm13
000076b67a9db2ed  vmovaps [rsp+0xD0], xmm14
000076b67a9db2f6  vmovaps [rsp+0xE0], xmm15
000076b67a9db2ff  sub rsp, 0x30
000076b67a9db303  movaps [rsp], xmm9
000076b67a9db308  movaps [rsp+0x10], xmm13
000076b67a9db30e  movaps [rsp+0x20], xmm15
000076b67a9db314  lea rdi, [rsp]
000076b67a9db318  mov esi, 0x00
000076b67a9db31d  mov rax, 0x63C5EF2DF530
000076b67a9db327  call rax
000076b67a9db329  movaps xmm9, [rsp]
000076b67a9db32e  add rsp, 0x30
000076b67a9db332  vmovaps xmm0, [rsp]
000076b67a9db337  vmovaps xmm1, [rsp+0x10]
000076b67a9db33d  vmovaps xmm2, [rsp+0x20]
000076b67a9db343  vmovaps xmm3, [rsp+0x30]
000076b67a9db349  vmovaps xmm4, [rsp+0x40]
000076b67a9db34f  vmovaps xmm5, [rsp+0x50]
000076b67a9db355  vmovaps xmm6, [rsp+0x60]
000076b67a9db35b  vmovaps xmm7, [rsp+0x70]
000076b67a9db361  vmovaps xmm8, [rsp+0x80]
000076b67a9db36a  vmovaps xmm10, [rsp+0x90]
000076b67a9db373  vmovaps xmm11, [rsp+0xA0]
000076b67a9db37c  vmovaps xmm12, [rsp+0xB0]
000076b67a9db385  vmovaps xmm13, [rsp+0xC0]
000076b67a9db38e  vmovaps xmm14, [rsp+0xD0]
000076b67a9db397  vmovaps xmm15, [rsp+0xE0]
000076b67a9db3a0  add rsp, 0xF0
000076b67a9db3a7  pop r11
000076b67a9db3a9  pop r10
000076b67a9db3ab  pop r9
000076b67a9db3ad  pop r8
000076b67a9db3af  pop rsi
000076b67a9db3b0  pop rdi
000076b67a9db3b1  pop rdx
000076b67a9db3b2  pop rcx
000076b67a9db3b3  pop rax
000076b67a9db3b4  add rsp, 0x08
000076b67a9db3b8  jmp 0x000076B67A9D662F
000076b67a9db3bd  sub rsp, 0x08
000076b67a9db3c1  push rax
000076b67a9db3c2  push rcx
000076b67a9db3c3  push rdx
000076b67a9db3c4  push rdi
000076b67a9db3c5  push rsi
000076b67a9db3c6  push r8
000076b67a9db3c8  push r9
000076b67a9db3ca  push r10
000076b67a9db3cc  push r11
000076b67a9db3ce  sub rsp, 0xF0
000076b67a9db3d5  vmovaps [rsp], xmm0
000076b67a9db3da  vmovaps [rsp+0x10], xmm1
000076b67a9db3e0  vmovaps [rsp+0x20], xmm2
000076b67a9db3e6  vmovaps [rsp+0x30], xmm3
000076b67a9db3ec  vmovaps [rsp+0x40], xmm4
000076b67a9db3f2  vmovaps [rsp+0x50], xmm5
000076b67a9db3f8  vmovaps [rsp+0x60], xmm6
000076b67a9db3fe  vmovaps [rsp+0x70], xmm7
000076b67a9db404  vmovaps [rsp+0x80], xmm8
000076b67a9db40d  vmovaps [rsp+0x90], xmm9
000076b67a9db416  vmovaps [rsp+0xA0], xmm10
000076b67a9db41f  vmovaps [rsp+0xB0], xmm11
000076b67a9db428  vmovaps [rsp+0xC0], xmm12
000076b67a9db431  vmovaps [rsp+0xD0], xmm13
000076b67a9db43a  vmovaps [rsp+0xE0], xmm14
000076b67a9db443  sub rsp, 0x30
000076b67a9db447  movaps [rsp], xmm15
000076b67a9db44c  movaps [rsp+0x10], xmm11
000076b67a9db452  movaps [rsp+0x20], xmm12
000076b67a9db458  lea rdi, [rsp]
000076b67a9db45c  mov esi, 0x00
000076b67a9db461  mov rax, 0x63C5EF2DF530
000076b67a9db46b  call rax
000076b67a9db46d  movaps xmm15, [rsp]
000076b67a9db472  add rsp, 0x30
000076b67a9db476  vmovaps xmm0, [rsp]
000076b67a9db47b  vmovaps xmm1, [rsp+0x10]
000076b67a9db481  vmovaps xmm2, [rsp+0x20]
000076b67a9db487  vmovaps xmm3, [rsp+0x30]
000076b67a9db48d  vmovaps xmm4, [rsp+0x40]
000076b67a9db493  vmovaps xmm5, [rsp+0x50]
000076b67a9db499  vmovaps xmm6, [rsp+0x60]
000076b67a9db49f  vmovaps xmm7, [rsp+0x70]
000076b67a9db4a5  vmovaps xmm8, [rsp+0x80]
000076b67a9db4ae  vmovaps xmm9, [rsp+0x90]
000076b67a9db4b7  vmovaps xmm10, [rsp+0xA0]
000076b67a9db4c0  vmovaps xmm11, [rsp+0xB0]
000076b67a9db4c9  vmovaps xmm12, [rsp+0xC0]
000076b67a9db4d2  vmovaps xmm13, [rsp+0xD0]
000076b67a9db4db  vmovaps xmm14, [rsp+0xE0]
000076b67a9db4e4  add rsp, 0xF0
000076b67a9db4eb  pop r11
000076b67a9db4ed  pop r10
000076b67a9db4ef  pop r9
000076b67a9db4f1  pop r8
000076b67a9db4f3  pop rsi
000076b67a9db4f4  pop rdi
000076b67a9db4f5  pop rdx
000076b67a9db4f6  pop rcx
000076b67a9db4f7  pop rax
000076b67a9db4f8  add rsp, 0x08
000076b67a9db4fc  jmp 0x000076B67A9D664A
000076b67a9db501  sub rsp, 0x08
000076b67a9db505  push rax
000076b67a9db506  push rcx
000076b67a9db507  push rdx
000076b67a9db508  push rdi
000076b67a9db509  push rsi
000076b67a9db50a  push r8
000076b67a9db50c  push r9
000076b67a9db50e  push r10
000076b67a9db510  push r11
000076b67a9db512  sub rsp, 0xF0
000076b67a9db519  vmovaps [rsp], xmm0
000076b67a9db51e  vmovaps [rsp+0x10], xmm1
000076b67a9db524  vmovaps [rsp+0x20], xmm2
000076b67a9db52a  vmovaps [rsp+0x30], xmm3
000076b67a9db530  vmovaps [rsp+0x40], xmm4
000076b67a9db536  vmovaps [rsp+0x50], xmm5
000076b67a9db53c  vmovaps [rsp+0x60], xmm6
000076b67a9db542  vmovaps [rsp+0x70], xmm7
000076b67a9db548  vmovaps [rsp+0x80], xmm8
000076b67a9db551  vmovaps [rsp+0x90], xmm9
000076b67a9db55a  vmovaps [rsp+0xA0], xmm10
000076b67a9db563  vmovaps [rsp+0xB0], xmm11
000076b67a9db56c  vmovaps [rsp+0xC0], xmm12
000076b67a9db575  vmovaps [rsp+0xD0], xmm14
000076b67a9db57e  vmovaps [rsp+0xE0], xmm15
000076b67a9db587  sub rsp, 0x30
000076b67a9db58b  movaps [rsp], xmm13
000076b67a9db590  movaps [rsp+0x10], xmm10
000076b67a9db596  movaps [rsp+0x20], xmm14
000076b67a9db59c  lea rdi, [rsp]
000076b67a9db5a0  mov esi, 0x00
000076b67a9db5a5  mov rax, 0x63C5EF2DF530
000076b67a9db5af  call rax
000076b67a9db5b1  movaps xmm13, [rsp]
000076b67a9db5b6  add rsp, 0x30
000076b67a9db5ba  vmovaps xmm0, [rsp]
000076b67a9db5bf  vmovaps xmm1, [rsp+0x10]
000076b67a9db5c5  vmovaps xmm2, [rsp+0x20]
000076b67a9db5cb  vmovaps xmm3, [rsp+0x30]
000076b67a9db5d1  vmovaps xmm4, [rsp+0x40]
000076b67a9db5d7  vmovaps xmm5, [rsp+0x50]
000076b67a9db5dd  vmovaps xmm6, [rsp+0x60]
000076b67a9db5e3  vmovaps xmm7, [rsp+0x70]
000076b67a9db5e9  vmovaps xmm8, [rsp+0x80]
000076b67a9db5f2  vmovaps xmm9, [rsp+0x90]
000076b67a9db5fb  vmovaps xmm10, [rsp+0xA0]
000076b67a9db604  vmovaps xmm11, [rsp+0xB0]
000076b67a9db60d  vmovaps xmm12, [rsp+0xC0]
000076b67a9db616  vmovaps xmm14, [rsp+0xD0]
000076b67a9db61f  vmovaps xmm15, [rsp+0xE0]
000076b67a9db628  add rsp, 0xF0
000076b67a9db62f  pop r11
000076b67a9db631  pop r10
000076b67a9db633  pop r9
000076b67a9db635  pop r8
000076b67a9db637  pop rsi
000076b67a9db638  pop rdi
000076b67a9db639  pop rdx
000076b67a9db63a  pop rcx
000076b67a9db63b  pop rax
000076b67a9db63c  add rsp, 0x08
000076b67a9db640  jmp 0x000076B67A9D666D
000076b67a9db645  sub rsp, 0x08
000076b67a9db649  push rax
000076b67a9db64a  push rcx
000076b67a9db64b  push rdx
000076b67a9db64c  push rdi
000076b67a9db64d  push rsi
000076b67a9db64e  push r8
000076b67a9db650  push r9
000076b67a9db652  push r10
000076b67a9db654  push r11
000076b67a9db656  sub rsp, 0xF0
000076b67a9db65d  vmovaps [rsp], xmm0
000076b67a9db662  vmovaps [rsp+0x10], xmm1
000076b67a9db668  vmovaps [rsp+0x20], xmm2
000076b67a9db66e  vmovaps [rsp+0x30], xmm3
000076b67a9db674  vmovaps [rsp+0x40], xmm4
000076b67a9db67a  vmovaps [rsp+0x50], xmm5
000076b67a9db680  vmovaps [rsp+0x60], xmm6
000076b67a9db686  vmovaps [rsp+0x70], xmm7
000076b67a9db68c  vmovaps [rsp+0x80], xmm8
000076b67a9db695  vmovaps [rsp+0x90], xmm9
000076b67a9db69e  vmovaps [rsp+0xA0], xmm10
000076b67a9db6a7  vmovaps [rsp+0xB0], xmm11
000076b67a9db6b0  vmovaps [rsp+0xC0], xmm12
000076b67a9db6b9  vmovaps [rsp+0xD0], xmm13
000076b67a9db6c2  vmovaps [rsp+0xE0], xmm15
000076b67a9db6cb  sub rsp, 0x30
000076b67a9db6cf  movaps [rsp], xmm14
000076b67a9db6d4  movaps [rsp+0x10], xmm1
000076b67a9db6d9  movaps [rsp+0x20], xmm7
000076b67a9db6de  lea rdi, [rsp]
000076b67a9db6e2  mov esi, 0x00
000076b67a9db6e7  mov rax, 0x63C5EF2DF530
000076b67a9db6f1  call rax
000076b67a9db6f3  movaps xmm14, [rsp]
000076b67a9db6f8  add rsp, 0x30
000076b67a9db6fc  vmovaps xmm0, [rsp]
000076b67a9db701  vmovaps xmm1, [rsp+0x10]
000076b67a9db707  vmovaps xmm2, [rsp+0x20]
000076b67a9db70d  vmovaps xmm3, [rsp+0x30]
000076b67a9db713  vmovaps xmm4, [rsp+0x40]
000076b67a9db719  vmovaps xmm5, [rsp+0x50]
000076b67a9db71f  vmovaps xmm6, [rsp+0x60]
000076b67a9db725  vmovaps xmm7, [rsp+0x70]
000076b67a9db72b  vmovaps xmm8, [rsp+0x80]
000076b67a9db734  vmovaps xmm9, [rsp+0x90]
000076b67a9db73d  vmovaps xmm10, [rsp+0xA0]
000076b67a9db746  vmovaps xmm11, [rsp+0xB0]
000076b67a9db74f  vmovaps xmm12, [rsp+0xC0]
000076b67a9db758  vmovaps xmm13, [rsp+0xD0]
000076b67a9db761  vmovaps xmm15, [rsp+0xE0]
000076b67a9db76a  add rsp, 0xF0
000076b67a9db771  pop r11
000076b67a9db773  pop r10
000076b67a9db775  pop r9
000076b67a9db777  pop r8
000076b67a9db779  pop rsi
000076b67a9db77a  pop rdi
000076b67a9db77b  pop rdx
000076b67a9db77c  pop rcx
000076b67a9db77d  pop rax
000076b67a9db77e  add rsp, 0x08
000076b67a9db782  jmp 0x000076B67A9D6690
000076b67a9db787  sub rsp, 0x08
000076b67a9db78b  push rax
000076b67a9db78c  push rcx
000076b67a9db78d  push rdx
000076b67a9db78e  push rdi
000076b67a9db78f  push rsi
000076b67a9db790  push r8
000076b67a9db792  push r9
000076b67a9db794  push r10
000076b67a9db796  push r11
000076b67a9db798  sub rsp, 0xF0
000076b67a9db79f  vmovaps [rsp], xmm0
000076b67a9db7a4  vmovaps [rsp+0x10], xmm2
000076b67a9db7aa  vmovaps [rsp+0x20], xmm3
000076b67a9db7b0  vmovaps [rsp+0x30], xmm4
000076b67a9db7b6  vmovaps [rsp+0x40], xmm5
000076b67a9db7bc  vmovaps [rsp+0x50], xmm6
000076b67a9db7c2  vmovaps [rsp+0x60], xmm7
000076b67a9db7c8  vmovaps [rsp+0x70], xmm8
000076b67a9db7ce  vmovaps [rsp+0x80], xmm9
000076b67a9db7d7  vmovaps [rsp+0x90], xmm10
000076b67a9db7e0  vmovaps [rsp+0xA0], xmm11
000076b67a9db7e9  vmovaps [rsp+0xB0], xmm12
000076b67a9db7f2  vmovaps [rsp+0xC0], xmm13
000076b67a9db7fb  vmovaps [rsp+0xD0], xmm14
000076b67a9db804  vmovaps [rsp+0xE0], xmm15
000076b67a9db80d  sub rsp, 0x30
000076b67a9db811  movaps [rsp], xmm1
000076b67a9db815  movaps [rsp+0x10], xmm8
000076b67a9db81b  movaps [rsp+0x20], xmm9
000076b67a9db821  lea rdi, [rsp]
000076b67a9db825  mov esi, 0x00
000076b67a9db82a  mov rax, 0x63C5EF2DF530
000076b67a9db834  call rax
000076b67a9db836  movaps xmm1, [rsp]
000076b67a9db83a  add rsp, 0x30
000076b67a9db83e  vmovaps xmm0, [rsp]
000076b67a9db843  vmovaps xmm2, [rsp+0x10]
000076b67a9db849  vmovaps xmm3, [rsp+0x20]
000076b67a9db84f  vmovaps xmm4, [rsp+0x30]
000076b67a9db855  vmovaps xmm5, [rsp+0x40]
000076b67a9db85b  vmovaps xmm6, [rsp+0x50]
000076b67a9db861  vmovaps xmm7, [rsp+0x60]
000076b67a9db867  vmovaps xmm8, [rsp+0x70]
000076b67a9db86d  vmovaps xmm9, [rsp+0x80]
000076b67a9db876  vmovaps xmm10, [rsp+0x90]
000076b67a9db87f  vmovaps xmm11, [rsp+0xA0]
000076b67a9db888  vmovaps xmm12, [rsp+0xB0]
000076b67a9db891  vmovaps xmm13, [rsp+0xC0]
000076b67a9db89a  vmovaps xmm14, [rsp+0xD0]
000076b67a9db8a3  vmovaps xmm15, [rsp+0xE0]
000076b67a9db8ac  add rsp, 0xF0
000076b67a9db8b3  pop r11
000076b67a9db8b5  pop r10
000076b67a9db8b7  pop r9
000076b67a9db8b9  pop r8
000076b67a9db8bb  pop rsi
000076b67a9db8bc  pop rdi
000076b67a9db8bd  pop rdx
000076b67a9db8be  pop rcx
000076b67a9db8bf  pop rax
000076b67a9db8c0  add rsp, 0x08
000076b67a9db8c4  jmp 0x000076B67A9D66B2
000076b67a9db8c9  call 0x000076B67A8B3E40
000076b67a9db8ce  jmp 0x000076B67A9D66C0
000076b67a9db8d3  call 0x000076B67A80C380
000076b67a9db8d8  jmp 0x000076B67A9D66CA
000076b67a9db8dd  call 0x000076B67A80D600
000076b67a9db8e2  jmp 0x000076B67A9D66D4
000076b67a9db8e7  call 0x000076B67A7FF540
000076b67a9db8ec  jmp 0x000076B67A9D66DE
000076b67a9db8f1  int3
000076b67a9db8f2  nop [rax+rax*1], ax
000076b67a9db8fb  nop [rax+rax*1], eax
000076b67a9db900  mov eax, [r15+0x48]
000076b67a9db904  lea r14d, [eax+0x01]
000076b67a9db909  mov [rsp+0x10], r14d
000076b67a9db90e  mov r14d, r14d
000076b67a9db911  mov [r15+0x48], r14
000076b67a9db915  xor eax, eax
000076b67a9db917  mov r14d, [rsp+0x10]
000076b67a9db91c  cmp r14d, 0x1F4
000076b67a9db923  cmc
000076b67a9db924  lahf
000076b67a9db925  seto al
000076b67a9db928  mov [r15+0x108], eax
000076b67a9db92f  mov eax, [r15+0x108]
000076b67a9db936  sahf
000076b67a9db937  jnz 0x000076B67A9DB969
000076b67a9db939  cmp dword ptr [r15+0x318], 0x00
000076b67a9db941  jz 0x000076B67A9E1AB0
000076b67a9db947  nop [rax+rax*1], ax
000076b67a9db950  nop [rax+rax*1], eax
000076b67a9db958  mov eax, 0x410450
000076b67a9db95d  mov [r15+0x100], rax
000076b67a9db964  jmp 0x000076B67A7FE110
000076b67a9db969  cmp dword ptr [r15+0x318], 0x00
000076b67a9db971  jz 0x000076B67A9DB9A0
000076b67a9db977  nop [rax+rax*1], ax
000076b67a9db980  nop [rax+rax*1], eax
000076b67a9db988  mov eax, 0x410274
000076b67a9db98d  mov [r15+0x100], rax
000076b67a9db994  jmp 0x000076B67A7FE110
000076b67a9db999  int3
000076b67a9db99a  int3
000076b67a9db99b  nop [rax+rax*1], eax
000076b67a9db9a0  mov rax, [r15+0x40]
000076b67a9db9a4  movaps xmm1, [r15+0x1D0]
000076b67a9db9ac  vmovaps [rsp+0x10], xmm1
000076b67a9db9b2  vmovaps xmm15, [rsp+0x10]
000076b67a9db9b8  por xmm1, xmm15
000076b67a9db9bd  movaps xmm14, [r15+0x1A0]
000076b67a9db9c5  vmovaps [rsp+0x10], xmm14
000076b67a9db9cb  vmovaps xmm13, [rsp+0x10]
000076b67a9db9d1  por xmm14, xmm13
000076b67a9db9d6  lea r14, [rax+0x30]
000076b67a9db9da  mov r12, [r13+r14*1]
000076b67a9db9df  lea r14, [rax+0x38]
000076b67a9db9e3  mov r11, [r13+r14*1]
000076b67a9db9e8  movq xmm13, r12
000076b67a9db9ed  movq xmm12, r11
000076b67a9db9f2  movq xmm13, xmm13
000076b67a9db9f7  vmovaps [rsp+0x10], xmm13
000076b67a9db9fd  movq xmm13, xmm13
000076b67a9dba02  movaps [r15+0x130], xmm13
000076b67a9dba0a  movq xmm12, xmm12
000076b67a9dba0f  vmovaps [rsp+0x20], xmm12
000076b67a9dba15  movq xmm12, xmm12
000076b67a9dba1a  movaps [r15+0x280], xmm12
000076b67a9dba22  movaps xmm13, [r15+0x270]
000076b67a9dba2a  vmovaps [rsp+0x30], xmm13
000076b67a9dba30  vmovaps xmm12, [rsp+0x30]
000076b67a9dba36  por xmm13, xmm12
000076b67a9dba3b  lea r14, [rax+0x20]
000076b67a9dba3f  mov r12, [r13+r14*1]
000076b67a9dba44  lea r14, [rax+0x28]
000076b67a9dba48  mov r11, [r13+r14*1]
000076b67a9dba4d  movq xmm12, r12
000076b67a9dba52  movq xmm11, r11
000076b67a9dba57  movq xmm12, xmm12
000076b67a9dba5c  vmovaps [rsp+0x30], xmm12
000076b67a9dba62  movq xmm12, xmm12
000076b67a9dba67  movaps [r15+0x150], xmm12
000076b67a9dba6f  movq xmm11, xmm11
000076b67a9dba74  vmovaps [rsp+0x40], xmm11
000076b67a9dba7a  movq xmm11, xmm11
000076b67a9dba7f  movaps [r15+0x140], xmm11
000076b67a9dba87  lea r14, [rax+0x10]
000076b67a9dba8b  mov r12, [r13+r14*1]
000076b67a9dba90  lea r14, [rax+0x18]
000076b67a9dba94  mov r11, [r13+r14*1]
000076b67a9dba99  movq xmm12, r12
000076b67a9dba9e  movq xmm11, r11
000076b67a9dbaa3  movq xmm12, xmm12
000076b67a9dbaa8  vmovaps [rsp+0x50], xmm12
000076b67a9dbaae  movq xmm12, xmm12
000076b67a9dbab3  movaps [r15+0x170], xmm12
000076b67a9dbabb  movq xmm11, xmm11
000076b67a9dbac0  vmovaps [rsp+0x60], xmm11
000076b67a9dbac6  movq xmm11, xmm11
000076b67a9dbacb  movaps [r15+0x160], xmm11
000076b67a9dbad3  mov r14, [r13+rax*1]
000076b67a9dbad8  vmovq xmm12, r14
000076b67a9dbadd  vpbroadcastq xmm12, xmm12
000076b67a9dbae2  lea r14, [rax+0x08]
000076b67a9dbae6  mov rax, [r13+r14*1]
000076b67a9dbaeb  movq xmm11, rax
000076b67a9dbaf0  movaps [r15+0x230], xmm11
000076b67a9dbaf8  mov rax, [r15+0xF8]
000076b67a9dbaff  lea r14, [rax+0x50]
000076b67a9dbb03  movups xmm11, [r13+r14*1]
000076b67a9dbb09  lea r14, [rax+0x60]
000076b67a9dbb0d  movups xmm10, [r13+r14*1]
000076b67a9dbb13  lea r14, [rax+0x30]
000076b67a9dbb17  movups xmm9, [r13+r14*1]
000076b67a9dbb1d  mov r14, [r15+0x50]
000076b67a9dbb21  mov [r15+0x60], r14
000076b67a9dbb25  mov qword ptr [r15+0x58], 0x40
000076b67a9dbb2d  movaps xmm8, xmm12
000076b67a9dbb31  mulpd xmm8, xmm15
000076b67a9dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000076b67a9dbb3c  ptest xmm7, xmm7
000076b67a9dbb41  jnz 0x000076B67A9DC96A
000076b67a9dbb47  movq xmm15, qword ptr [r15+0x230]
000076b67a9dbb50  vmovaps [rsp+0x70], xmm15
000076b67a9dbb56  vpermilpd xmm15, xmm15, 0x00
000076b67a9dbb5c  movaps xmm7, xmm9
000076b67a9dbb60  mulpd xmm7, xmm15
000076b67a9dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000076b67a9dbb6a  ptest xmm6, xmm6
000076b67a9dbb6f  jnz 0x000076B67A9DCAAE
000076b67a9dbb75  vxorps xmm15, xmm15, xmm15
000076b67a9dbb7a  vpbroadcastq xmm15, xmm15
000076b67a9dbb7f  movaps xmm9, xmm12
000076b67a9dbb83  mulpd xmm9, xmm10
000076b67a9dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000076b67a9dbb8e  ptest xmm6, xmm6
000076b67a9dbb93  jnz 0x000076B67A9DCBF0
000076b67a9dbb99  movaps xmm10, xmm12
000076b67a9dbb9d  mulpd xmm10, xmm11
000076b67a9dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000076b67a9dbba8  ptest xmm6, xmm6
000076b67a9dbbad  jnz 0x000076B67A9DCD34
000076b67a9dbbb3  movaps xmm11, [r15+0x1F0]
000076b67a9dbbbb  movaps xmm6, xmm12
000076b67a9dbbbf  mulpd xmm6, xmm11
000076b67a9dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000076b67a9dbbc9  ptest xmm5, xmm5
000076b67a9dbbce  jnz 0x000076B67A9DCE78
000076b67a9dbbd4  movaps xmm12, [r15+0x2A0]
000076b67a9dbbdc  vmovaps [rsp+0x80], xmm12
000076b67a9dbbe5  vmovaps xmm11, [rsp+0x80]
000076b67a9dbbee  por xmm12, xmm11
000076b67a9dbbf3  movaps xmm11, [r15+0x250]
000076b67a9dbbfb  vmovaps [rsp+0x80], xmm11
000076b67a9dbc04  vmovaps xmm5, [rsp+0x80]
000076b67a9dbc0d  por xmm11, xmm5
000076b67a9dbc12  vmovaps xmm4, [rsp+0x70]
000076b67a9dbc18  vpermilpd xmm4, xmm4, 0x00
000076b67a9dbc1e  movaps xmm3, xmm5
000076b67a9dbc21  mulpd xmm3, xmm4
000076b67a9dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000076b67a9dbc2a  ptest xmm2, xmm2
000076b67a9dbc2f  jnz 0x000076B67A9DCFBA
000076b67a9dbc35  mov [rsp+0x80], rax
000076b67a9dbc3d  xor eax, eax
000076b67a9dbc3f  mov r12d, 0x40
000076b67a9dbc45  mov r11d, 0x200
000076b67a9dbc4b  cmp r12, r11
000076b67a9dbc4e  cmc
000076b67a9dbc4f  lahf
000076b67a9dbc50  seto al
000076b67a9dbc53  mov [r15+0x108], eax
000076b67a9dbc5a  movaps xmm5, xmm8
000076b67a9dbc5e  addpd xmm5, xmm15
000076b67a9dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000076b67a9dbc68  ptest xmm4, xmm4
000076b67a9dbc6d  jnz 0x000076B67A9DD0FA
000076b67a9dbc73  movaps xmm8, [r15+0x1B0]
000076b67a9dbc7b  movaps xmm4, xmm9
000076b67a9dbc7f  addpd xmm4, xmm8
000076b67a9dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000076b67a9dbc89  ptest xmm2, xmm2
000076b67a9dbc8e  jnz 0x000076B67A9DD23C
000076b67a9dbc94  movaps xmm9, xmm10
000076b67a9dbc98  addpd xmm9, xmm8
000076b67a9dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000076b67a9dbca3  ptest xmm2, xmm2
000076b67a9dbca8  jnz 0x000076B67A9DD37E
000076b67a9dbcae  movaps xmm10, [r15+0x2F0]
000076b67a9dbcb6  vmovaps [rsp+0x90], xmm10
000076b67a9dbcbf  vmovaps xmm8, [rsp+0x90]
000076b67a9dbcc8  por xmm10, xmm8
000076b67a9dbccd  movaps xmm8, [r15+0x2E0]
000076b67a9dbcd5  vmovaps [rsp+0x90], xmm8
000076b67a9dbcde  vmovaps xmm2, [rsp+0x90]
000076b67a9dbce7  por xmm8, xmm2
000076b67a9dbcec  movaps xmm2, [r15+0x2D0]
000076b67a9dbcf4  vmovaps [rsp+0x90], xmm2
000076b67a9dbcfd  vmovaps [rsp+0xA0], xmm1
000076b67a9dbd06  vmovaps xmm1, [rsp+0x90]
000076b67a9dbd0f  por xmm2, xmm1
000076b67a9dbd13  movaps xmm1, [r15+0x200]
000076b67a9dbd1b  vmovaps [rsp+0x90], xmm1
000076b67a9dbd24  vmovaps [rsp+0xB0], xmm15
000076b67a9dbd2d  vmovaps xmm15, [rsp+0x90]
000076b67a9dbd36  por xmm1, xmm15
000076b67a9dbd3b  movaps xmm15, [r15+0x1C0]
000076b67a9dbd43  vmovaps [rsp+0x90], xmm15
000076b67a9dbd4c  vmovaps [rsp+0xC0], xmm1
000076b67a9dbd55  vmovaps xmm1, [rsp+0x90]
000076b67a9dbd5e  por xmm15, xmm1
000076b67a9dbd63  movaps xmm1, [r15+0x190]
000076b67a9dbd6b  vmovaps [rsp+0x90], xmm1
000076b67a9dbd74  vmovaps [rsp+0xD0], xmm15
000076b67a9dbd7d  vmovaps xmm15, [rsp+0x90]
000076b67a9dbd86  por xmm1, xmm15
000076b67a9dbd8b  movaps xmm15, [r15+0x300]
000076b67a9dbd93  vmovaps [rsp+0x90], xmm15
000076b67a9dbd9c  vmovaps [rsp+0xE0], xmm1
000076b67a9dbda5  vmovaps xmm1, [rsp+0x90]
000076b67a9dbdae  por xmm15, xmm1
000076b67a9dbdb3  mov rax, [rsp+0x80]
000076b67a9dbdbb  lea r12, [rax+0xA0]
000076b67a9dbdc2  movups xmm1, [r13+r12*1]
000076b67a9dbdc8  lea r12, [rax+0xB0]
000076b67a9dbdcf  vmovaps [rsp+0x80], xmm1
000076b67a9dbdd8  movups xmm1, [r13+r12*1]
000076b67a9dbdde  vmovaps [rsp+0x90], xmm1
000076b67a9dbde7  vmovaps [rsp+0xF0], xmm15
000076b67a9dbdf0  vmovaps xmm15, [rsp+0xB0]
000076b67a9dbdf9  vmovaps [rsp+0xB0], xmm14
000076b67a9dbe02  movaps xmm1, xmm6
000076b67a9dbe05  addpd xmm1, xmm15
000076b67a9dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000076b67a9dbe0f  ptest xmm14, xmm14
000076b67a9dbe15  jnz 0x000076B67A9DD4D6
000076b67a9dbe1b  lea r12, [rax+0xF0]
000076b67a9dbe22  movups xmm15, [r13+r12*1]
000076b67a9dbe28  movaps xmm14, xmm4
000076b67a9dbe2c  addpd xmm14, xmm3
000076b67a9dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000076b67a9dbe37  ptest xmm6, xmm6
000076b67a9dbe3c  jnz 0x000076B67A9DD621
000076b67a9dbe42  movaps xmm6, xmm9
000076b67a9dbe46  addpd xmm6, xmm7
000076b67a9dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000076b67a9dbe4f  ptest xmm4, xmm4
000076b67a9dbe54  jnz 0x000076B67A9DD763
000076b67a9dbe5a  vmovaps xmm9, [rsp+0x70]
000076b67a9dbe60  vpermilpd xmm9, xmm9, 0x00
000076b67a9dbe66  vmovaps xmm4, [rsp+0x90]
000076b67a9dbe6f  movaps xmm7, xmm4
000076b67a9dbe72  mulpd xmm7, xmm9
000076b67a9dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000076b67a9dbe7c  ptest xmm3, xmm3
000076b67a9dbe81  jnz 0x000076B67A9DD8A4
000076b67a9dbe87  vmovaps xmm9, [rsp+0x50]
000076b67a9dbe8d  vpermilpd xmm9, xmm9, 0x00
000076b67a9dbe93  movaps xmm4, xmm15
000076b67a9dbe97  mulpd xmm4, xmm9
000076b67a9dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000076b67a9dbea1  ptest xmm3, xmm3
000076b67a9dbea6  jnz 0x000076B67A9DD9E5
000076b67a9dbeac  lea r12, [rax+0xE0]
000076b67a9dbeb3  movups xmm15, [r13+r12*1]
000076b67a9dbeb9  vmovaps xmm9, [rsp+0x70]
000076b67a9dbebf  vpermilpd xmm9, xmm9, 0x00
000076b67a9dbec5  vmovaps [rsp+0x70], xmm1
000076b67a9dbecb  vmovaps xmm1, [rsp+0x80]
000076b67a9dbed4  vmovaps [rsp+0x80], xmm15
000076b67a9dbedd  movaps xmm3, xmm1
000076b67a9dbee0  mulpd xmm3, xmm9
000076b67a9dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000076b67a9dbeea  ptest xmm15, xmm15
000076b67a9dbef0  jnz 0x000076B67A9DDB31
000076b67a9dbef6  vmovaps xmm1, [rsp+0xF0]
000076b67a9dbeff  vmovaps xmm15, [rsp+0xF0]
000076b67a9dbf08  por xmm1, xmm15
000076b67a9dbf0d  movaps [r15+0x300], xmm1
000076b67a9dbf15  vmovaps xmm15, [rsp+0xE0]
000076b67a9dbf1e  vmovaps xmm9, [rsp+0xE0]
000076b67a9dbf27  por xmm15, xmm9
000076b67a9dbf2c  movaps [r15+0x190], xmm15
000076b67a9dbf34  vmovaps xmm9, [rsp+0x50]
000076b67a9dbf3a  vpermilpd xmm9, xmm9, 0x00
000076b67a9dbf40  vmovaps [rsp+0x90], xmm1
000076b67a9dbf49  vmovaps [rsp+0xE0], xmm15
000076b67a9dbf52  vmovaps xmm15, [rsp+0x80]
000076b67a9dbf5b  vmovaps [rsp+0x80], xmm14
000076b67a9dbf64  movaps xmm1, xmm15
000076b67a9dbf68  mulpd xmm1, xmm9
000076b67a9dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000076b67a9dbf72  ptest xmm14, xmm14
000076b67a9dbf78  jnz 0x000076B67A9DDC72
000076b67a9dbf7e  lea r12, [rax+0x90]
000076b67a9dbf85  movups xmm15, [r13+r12*1]
000076b67a9dbf8b  vmovaps xmm14, [rsp+0xD0]
000076b67a9dbf94  vmovaps xmm9, [rsp+0xD0]
000076b67a9dbf9d  por xmm14, xmm9
000076b67a9dbfa2  movaps [r15+0x1C0], xmm14
000076b67a9dbfaa  vmovaps xmm9, [rsp+0xC0]
000076b67a9dbfb3  vmovaps [rsp+0xD0], xmm1
000076b67a9dbfbc  vmovaps xmm1, [rsp+0xC0]
000076b67a9dbfc5  por xmm9, xmm1
000076b67a9dbfca  movaps [r15+0x200], xmm9
000076b67a9dbfd2  vmovaps [rsp+0xC0], xmm2
000076b67a9dbfdb  vmovaps xmm1, [rsp+0xC0]
000076b67a9dbfe4  por xmm2, xmm1
000076b67a9dbfe8  movaps [r15+0x2D0], xmm2
000076b67a9dbff0  vmovaps [rsp+0xC0], xmm8
000076b67a9dbff9  vmovaps xmm1, [rsp+0xC0]
000076b67a9dc002  por xmm8, xmm1
000076b67a9dc007  movaps [r15+0x2E0], xmm8
000076b67a9dc00f  vmovaps [rsp+0xC0], xmm15
000076b67a9dc018  movaps xmm1, xmm5
000076b67a9dc01b  addpd xmm1, xmm7
000076b67a9dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000076b67a9dc024  ptest xmm15, xmm15
000076b67a9dc02a  jnz 0x000076B67A9DDDBE
000076b67a9dc030  vmovaps xmm15, [rsp+0x50]
000076b67a9dc036  vpermilpd xmm15, xmm15, 0x00
000076b67a9dc03c  vmovaps xmm5, [rsp+0xC0]
000076b67a9dc045  vmovaps [rsp+0xC0], xmm1
000076b67a9dc04e  movaps xmm7, xmm5
000076b67a9dc051  mulpd xmm7, xmm15
000076b67a9dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000076b67a9dc05b  ptest xmm1, xmm1
000076b67a9dc060  jnz 0x000076B67A9DDEFE
000076b67a9dc066  lea r12, [rax+0x80]
000076b67a9dc06d  movups xmm1, [r13+r12*1]
000076b67a9dc073  vmovaps xmm5, [rsp+0x70]
000076b67a9dc079  vmovaps [rsp+0x70], xmm1
000076b67a9dc07f  movaps xmm15, xmm5
000076b67a9dc083  addpd xmm15, xmm3
000076b67a9dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000076b67a9dc08e  ptest xmm1, xmm1
000076b67a9dc093  jnz 0x000076B67A9DE049
000076b67a9dc099  vmovaps xmm5, [rsp+0x80]
000076b67a9dc0a2  movaps xmm1, xmm5
000076b67a9dc0a5  addpd xmm1, xmm4
000076b67a9dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000076b67a9dc0ae  ptest xmm3, xmm3
000076b67a9dc0b3  jnz 0x000076B67A9DE18B
000076b67a9dc0b9  vmovaps [rsp+0x80], xmm10
000076b67a9dc0c2  vmovaps xmm5, [rsp+0x80]
000076b67a9dc0cb  por xmm10, xmm5
000076b67a9dc0d0  movaps [r15+0x2F0], xmm10
000076b67a9dc0d8  vmovaps xmm5, [rsp+0x50]
000076b67a9dc0de  vpermilpd xmm5, xmm5, 0x00
000076b67a9dc0e4  vmovaps xmm3, [rsp+0x70]
000076b67a9dc0ea  vmovaps [rsp+0x50], xmm1
000076b67a9dc0f0  movaps xmm4, xmm3
000076b67a9dc0f3  mulpd xmm4, xmm5
000076b67a9dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000076b67a9dc0fc  ptest xmm1, xmm1
000076b67a9dc101  jnz 0x000076B67A9DE2CB
000076b67a9dc107  lea r12, [rax+0xD0]
000076b67a9dc10e  movups xmm1, [r13+r12*1]
000076b67a9dc114  vmovaps xmm3, [rsp+0xD0]
000076b67a9dc11d  vmovaps [rsp+0x70], xmm1
000076b67a9dc123  movaps xmm5, xmm6
000076b67a9dc126  addpd xmm5, xmm3
000076b67a9dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000076b67a9dc12f  ptest xmm1, xmm1
000076b67a9dc134  jnz 0x000076B67A9DE415
000076b67a9dc13a  vmovaps xmm1, [rsp+0x60]
000076b67a9dc140  vpermilpd xmm1, xmm1, 0x00
000076b67a9dc146  movaps xmm6, xmm9
000076b67a9dc14a  mulpd xmm6, xmm1
000076b67a9dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000076b67a9dc153  ptest xmm3, xmm3
000076b67a9dc158  jnz 0x000076B67A9DE555
000076b67a9dc15e  movaps [r15+0x260], xmm6
000076b67a9dc166  vxorps xmm1, xmm1, xmm1
000076b67a9dc16a  vpbroadcastq xmm1, xmm1
000076b67a9dc16f  movaps [r15+0x1B0], xmm1
000076b67a9dc177  vmovaps xmm1, [rsp+0x60]
000076b67a9dc17d  vpermilpd xmm1, xmm1, 0x00
000076b67a9dc183  vmovaps xmm3, [rsp+0x70]
000076b67a9dc189  vmovaps [rsp+0x70], xmm15
000076b67a9dc18f  movaps xmm9, xmm3
000076b67a9dc193  mulpd xmm9, xmm1
000076b67a9dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000076b67a9dc19e  ptest xmm15, xmm15
000076b67a9dc1a4  jnz 0x000076B67A9DE696
000076b67a9dc1aa  lea r12, [rax+0xC0]
000076b67a9dc1b1  movups xmm1, [r13+r12*1]
000076b67a9dc1b7  vmovaps xmm3, [rsp+0xC0]
000076b67a9dc1c0  vmovaps [rsp+0x80], xmm1
000076b67a9dc1c9  movaps xmm15, xmm3
000076b67a9dc1cd  addpd xmm15, xmm7
000076b67a9dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000076b67a9dc1d8  ptest xmm1, xmm1
000076b67a9dc1dd  jnz 0x000076B67A9DE7E2
000076b67a9dc1e3  vmovaps [rsp+0xC0], xmm13
000076b67a9dc1ec  vmovaps xmm1, [rsp+0xC0]
000076b67a9dc1f5  por xmm13, xmm1
000076b67a9dc1fa  movaps [r15+0x270], xmm13
000076b67a9dc202  vmovaps xmm1, [rsp+0xB0]
000076b67a9dc20b  vmovaps xmm7, [rsp+0xB0]
000076b67a9dc214  por xmm1, xmm7
000076b67a9dc218  movaps [r15+0x1A0], xmm1
000076b67a9dc220  vmovaps xmm1, [rsp+0x60]
000076b67a9dc226  vpermilpd xmm1, xmm1, 0x00
000076b67a9dc22c  vmovaps [rsp+0xB0], xmm1
000076b67a9dc235  vmovaps xmm1, [rsp+0x80]
000076b67a9dc23e  vmovaps [rsp+0x80], xmm15
000076b67a9dc247  vmovaps xmm15, [rsp+0xB0]
000076b67a9dc250  vmovaps [rsp+0xB0], xmm14
000076b67a9dc259  movaps xmm3, xmm1
000076b67a9dc25c  mulpd xmm3, xmm15
000076b67a9dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000076b67a9dc266  ptest xmm14, xmm14
000076b67a9dc26c  jnz 0x000076B67A9DE924
000076b67a9dc272  lea r12, [rax+0x20]
000076b67a9dc276  movups xmm1, [r13+r12*1]
000076b67a9dc27c  movaps [r15+0x110], xmm1
000076b67a9dc284  vmovaps xmm14, [rsp+0x70]
000076b67a9dc28a  vmovaps [rsp+0x70], xmm1
000076b67a9dc290  movaps xmm15, xmm14
000076b67a9dc294  addpd xmm15, xmm4
000076b67a9dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000076b67a9dc29f  ptest xmm1, xmm1
000076b67a9dc2a4  jnz 0x000076B67A9DEA6F
000076b67a9dc2aa  vmovaps xmm1, [rsp+0x60]
000076b67a9dc2b0  vpermilpd xmm1, xmm1, 0x00
000076b67a9dc2b6  movaps xmm14, xmm2
000076b67a9dc2ba  mulpd xmm14, xmm1
000076b67a9dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000076b67a9dc2c5  ptest xmm4, xmm4
000076b67a9dc2ca  jnz 0x000076B67A9DEBB2
000076b67a9dc2d0  vmovaps xmm4, [rsp+0x50]
000076b67a9dc2d6  movaps xmm1, xmm4
000076b67a9dc2d9  addpd xmm1, xmm9
000076b67a9dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000076b67a9dc2e3  ptest xmm2, xmm2
000076b67a9dc2e8  jnz 0x000076B67A9DECF4
000076b67a9dc2ee  vmovaps xmm9, [rsp+0x30]
000076b67a9dc2f4  vpermilpd xmm9, xmm9, 0x00
000076b67a9dc2fa  vmovaps xmm2, [rsp+0x70]
000076b67a9dc300  vmovaps [rsp+0x50], xmm1
000076b67a9dc306  movaps xmm4, xmm2
000076b67a9dc309  mulpd xmm4, xmm9
000076b67a9dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000076b67a9dc313  ptest xmm1, xmm1
000076b67a9dc318  jnz 0x000076B67A9DEE35
000076b67a9dc31e  vmovaps xmm1, [rsp+0x30]
000076b67a9dc324  vpermilpd xmm1, xmm1, 0x00
000076b67a9dc32a  vmovaps xmm2, [rsp+0x90]
000076b67a9dc333  vmovaps [rsp+0x60], xmm15
000076b67a9dc339  movaps xmm9, xmm2
000076b67a9dc33d  mulpd xmm9, xmm1
000076b67a9dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000076b67a9dc348  ptest xmm15, xmm15
000076b67a9dc34e  jnz 0x000076B67A9DEF76
000076b67a9dc354  vmovaps xmm15, [rsp+0x80]
000076b67a9dc35d  movaps xmm1, xmm15
000076b67a9dc361  addpd xmm1, xmm6
000076b67a9dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000076b67a9dc36a  ptest xmm2, xmm2
000076b67a9dc36f  jnz 0x000076B67A9DF0B8
000076b67a9dc375  movaps xmm15, xmm5
000076b67a9dc379  addpd xmm15, xmm3
000076b67a9dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000076b67a9dc384  ptest xmm6, xmm6
000076b67a9dc389  jnz 0x000076B67A9DF1F9
000076b67a9dc38f  vmovaps xmm6, [rsp+0x30]
000076b67a9dc395  vpermilpd xmm6, xmm6, 0x00
000076b67a9dc39b  movaps xmm5, xmm8
000076b67a9dc39f  mulpd xmm5, xmm6
000076b67a9dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000076b67a9dc3a8  ptest xmm3, xmm3
000076b67a9dc3ad  jnz 0x000076B67A9DF33B
000076b67a9dc3b3  vmovaps xmm8, [rsp+0x30]
000076b67a9dc3b9  vpermilpd xmm8, xmm8, 0x00
000076b67a9dc3bf  movaps xmm6, xmm10
000076b67a9dc3c3  mulpd xmm6, xmm8
000076b67a9dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000076b67a9dc3cd  ptest xmm3, xmm3
000076b67a9dc3d2  jnz 0x000076B67A9DF47C
000076b67a9dc3d8  vmovaps xmm8, [rsp+0x60]
000076b67a9dc3de  movaps xmm10, xmm8
000076b67a9dc3e2  addpd xmm10, xmm14
000076b67a9dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000076b67a9dc3ed  ptest xmm3, xmm3
000076b67a9dc3f2  jnz 0x000076B67A9DF5BE
000076b67a9dc3f8  vmovaps xmm8, [rsp+0x50]
000076b67a9dc3fe  movaps xmm14, xmm8
000076b67a9dc402  addpd xmm14, xmm4
000076b67a9dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000076b67a9dc40d  ptest xmm3, xmm3
000076b67a9dc412  jnz 0x000076B67A9DF702
000076b67a9dc418  vmovaps xmm8, [rsp+0x40]
000076b67a9dc41e  vpermilpd xmm8, xmm8, 0x00
000076b67a9dc424  movaps xmm4, xmm13
000076b67a9dc428  mulpd xmm4, xmm8
000076b67a9dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000076b67a9dc432  ptest xmm3, xmm3
000076b67a9dc437  jnz 0x000076B67A9DF845
000076b67a9dc43d  movaps xmm13, xmm15
000076b67a9dc441  addpd xmm13, xmm9
000076b67a9dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000076b67a9dc44c  ptest xmm8, xmm8
000076b67a9dc452  jnz 0x000076B67A9DF987
000076b67a9dc458  movaps xmm15, xmm1
000076b67a9dc45c  addpd xmm15, xmm5
000076b67a9dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000076b67a9dc467  ptest xmm9, xmm9
000076b67a9dc46d  jnz 0x000076B67A9DFACB
000076b67a9dc473  vmovaps [rsp+0x30], xmm11
000076b67a9dc479  vmovaps xmm1, [rsp+0x30]
000076b67a9dc47f  por xmm11, xmm1
000076b67a9dc484  movaps [r15+0x250], xmm11
000076b67a9dc48c  vmovaps [rsp+0x30], xmm12
000076b67a9dc492  vmovaps xmm1, [rsp+0x30]
000076b67a9dc498  por xmm12, xmm1
000076b67a9dc49d  movaps [r15+0x2A0], xmm12
000076b67a9dc4a5  vmovaps xmm1, [rsp+0xA0]
000076b67a9dc4ae  vmovaps xmm11, [rsp+0xA0]
000076b67a9dc4b7  por xmm1, xmm11
000076b67a9dc4bc  movaps [r15+0x1D0], xmm1
000076b67a9dc4c4  lea r12, [rax+0x40]
000076b67a9dc4c8  movups xmm1, [r13+r12*1]
000076b67a9dc4ce  movaps [r15+0x2C0], xmm1
000076b67a9dc4d6  vmovaps xmm11, [rsp+0x40]
000076b67a9dc4dc  vpermilpd xmm11, xmm11, 0x00
000076b67a9dc4e2  vmovaps xmm8, [rsp+0xE0]
000076b67a9dc4eb  movaps xmm9, xmm8
000076b67a9dc4ef  mulpd xmm9, xmm11
000076b67a9dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000076b67a9dc4fa  ptest xmm5, xmm5
000076b67a9dc4ff  jnz 0x000076B67A9DFC17
000076b67a9dc505  movaps xmm11, xmm10
000076b67a9dc509  addpd xmm11, xmm6
000076b67a9dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000076b67a9dc514  ptest xmm8, xmm8
000076b67a9dc51a  jnz 0x000076B67A9DFD5B
000076b67a9dc520  movaps xmm10, xmm14
000076b67a9dc524  addpd xmm10, xmm4
000076b67a9dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000076b67a9dc52f  ptest xmm8, xmm8
000076b67a9dc535  jnz 0x000076B67A9DFE9E
000076b67a9dc53b  vmovaps xmm14, [rsp+0x40]
000076b67a9dc541  vpermilpd xmm14, xmm14, 0x00
000076b67a9dc547  movaps xmm8, xmm1
000076b67a9dc54b  mulpd xmm8, xmm14
000076b67a9dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000076b67a9dc556  ptest xmm6, xmm6
000076b67a9dc55b  jnz 0x000076B67A9DFFE1
000076b67a9dc561  movaps xmm1, [r15+0x2B0]
000076b67a9dc569  vmovaps xmm14, [rsp+0x40]
000076b67a9dc56f  vpermilpd xmm14, xmm14, 0x00
000076b67a9dc575  movaps xmm6, xmm1
000076b67a9dc578  mulpd xmm6, xmm14
000076b67a9dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000076b67a9dc582  ptest xmm5, xmm5
000076b67a9dc587  jnz 0x000076B67A9E0124
000076b67a9dc58d  vmovaps xmm1, [rsp+0x10]
000076b67a9dc593  vpermilpd xmm1, xmm1, 0x00
000076b67a9dc599  movaps xmm14, xmm12
000076b67a9dc59d  mulpd xmm14, xmm1
000076b67a9dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000076b67a9dc5a8  ptest xmm5, xmm5
000076b67a9dc5ad  jnz 0x000076B67A9E0265
000076b67a9dc5b3  movaps xmm1, xmm13
000076b67a9dc5b7  addpd xmm1, xmm9
000076b67a9dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000076b67a9dc5c1  ptest xmm12, xmm12
000076b67a9dc5c7  jnz 0x000076B67A9E03A8
000076b67a9dc5cd  vmovaps xmm13, [rsp+0x10]
000076b67a9dc5d3  vpermilpd xmm13, xmm13, 0x00
000076b67a9dc5d9  movaps xmm12, xmm7
000076b67a9dc5dd  mulpd xmm12, xmm13
000076b67a9dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000076b67a9dc5e8  ptest xmm9, xmm9
000076b67a9dc5ee  jnz 0x000076B67A9E04EA
000076b67a9dc5f4  movaps xmm13, xmm15
000076b67a9dc5f8  addpd xmm13, xmm8
000076b67a9dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000076b67a9dc603  ptest xmm9, xmm9
000076b67a9dc609  jnz 0x000076B67A9E062D
000076b67a9dc60f  movaps xmm15, [r15+0x290]
000076b67a9dc617  vmovaps xmm9, [rsp+0x10]
000076b67a9dc61d  vpermilpd xmm9, xmm9, 0x00
000076b67a9dc623  movaps xmm8, xmm15
000076b67a9dc627  mulpd xmm8, xmm9
000076b67a9dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000076b67a9dc632  ptest xmm7, xmm7
000076b67a9dc637  jnz 0x000076B67A9E0771
000076b67a9dc63d  movaps xmm15, xmm11
000076b67a9dc641  addpd xmm15, xmm6
000076b67a9dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000076b67a9dc64c  ptest xmm9, xmm9
000076b67a9dc652  jnz 0x000076B67A9E08B5
000076b67a9dc658  movaps xmm11, [r15+0x1E0]
000076b67a9dc660  vmovaps xmm9, [rsp+0x10]
000076b67a9dc666  vpermilpd xmm9, xmm9, 0x00
000076b67a9dc66c  movaps xmm7, xmm11
000076b67a9dc670  mulpd xmm7, xmm9
000076b67a9dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000076b67a9dc67a  ptest xmm6, xmm6
000076b67a9dc67f  jnz 0x000076B67A9E09F8
000076b67a9dc685  movaps xmm11, xmm10
000076b67a9dc689  addpd xmm11, xmm14
000076b67a9dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000076b67a9dc694  ptest xmm9, xmm9
000076b67a9dc69a  jnz 0x000076B67A9E0B3A
000076b67a9dc6a0  lea r12, [rax+0x70]
000076b67a9dc6a4  movups xmm14, [r13+r12*1]
000076b67a9dc6aa  movaps [r15+0x240], xmm14
000076b67a9dc6b2  movaps xmm10, xmm1
000076b67a9dc6b6  addpd xmm10, xmm12
000076b67a9dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000076b67a9dc6c1  ptest xmm9, xmm9
000076b67a9dc6c7  jnz 0x000076B67A9E0C88
000076b67a9dc6cd  movaps [r15+0x170], xmm10
000076b67a9dc6d5  vmovaps xmm1, [rsp+0x20]
000076b67a9dc6db  vpermilpd xmm1, xmm1, 0x00
000076b67a9dc6e1  movaps xmm12, xmm14
000076b67a9dc6e5  mulpd xmm12, xmm1
000076b67a9dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000076b67a9dc6f0  ptest xmm9, xmm9
000076b67a9dc6f6  jnz 0x000076B67A9E0DCB
000076b67a9dc6fc  vmovaps xmm1, [rsp+0x20]
000076b67a9dc702  vpermilpd xmm1, xmm1, 0x00
000076b67a9dc708  vmovaps xmm9, [rsp+0xB0]
000076b67a9dc711  movaps xmm14, xmm9
000076b67a9dc715  mulpd xmm14, xmm1
000076b67a9dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000076b67a9dc720  ptest xmm6, xmm6
000076b67a9dc725  jnz 0x000076B67A9E0F0E
000076b67a9dc72b  movaps [r15+0x180], xmm14
000076b67a9dc733  movaps xmm1, xmm13
000076b67a9dc737  addpd xmm1, xmm8
000076b67a9dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000076b67a9dc741  ptest xmm9, xmm9
000076b67a9dc747  jnz 0x000076B67A9E1051
000076b67a9dc74d  movaps [r15+0x210], xmm1
000076b67a9dc755  movups xmm13, [r13+rax*1]
000076b67a9dc75b  lea r12, [rax+0x10]
000076b67a9dc75f  movups xmm9, [r13+r12*1]
000076b67a9dc765  movaps [r15+0x230], xmm9
000076b67a9dc76d  movaps xmm8, xmm15
000076b67a9dc771  addpd xmm8, xmm7
000076b67a9dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000076b67a9dc77c  ptest xmm6, xmm6
000076b67a9dc781  jnz 0x000076B67A9E11A7
000076b67a9dc787  movaps [r15+0x130], xmm8
000076b67a9dc78f  vmovaps xmm15, [rsp+0x20]
000076b67a9dc795  vpermilpd xmm15, xmm15, 0x00
000076b67a9dc79b  movaps xmm7, xmm9
000076b67a9dc79f  mulpd xmm7, xmm15
000076b67a9dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000076b67a9dc7a9  ptest xmm6, xmm6
000076b67a9dc7ae  jnz 0x000076B67A9E12EA
000076b67a9dc7b4  movaps [r15+0x220], xmm7
000076b67a9dc7bc  vmovaps xmm15, [rsp+0x20]
000076b67a9dc7c2  vpermilpd xmm15, xmm15, 0x00
000076b67a9dc7c8  movaps xmm9, xmm13
000076b67a9dc7cc  mulpd xmm9, xmm15
000076b67a9dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000076b67a9dc7d7  ptest xmm6, xmm6
000076b67a9dc7dc  jnz 0x000076B67A9E142C
000076b67a9dc7e2  movaps xmm15, xmm11
000076b67a9dc7e6  addpd xmm15, xmm12
000076b67a9dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000076b67a9dc7f1  ptest xmm13, xmm13
000076b67a9dc7f7  jnz 0x000076B67A9E1570
000076b67a9dc7fd  movaps [r15+0x140], xmm15
000076b67a9dc805  movaps xmm13, xmm10
000076b67a9dc809  addpd xmm13, xmm14
000076b67a9dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000076b67a9dc814  ptest xmm12, xmm12
000076b67a9dc81a  jnz 0x000076B67A9E16B4
000076b67a9dc820  movaps [r15+0x150], xmm13
000076b67a9dc828  movaps xmm14, xmm1
000076b67a9dc82c  addpd xmm14, xmm7
000076b67a9dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000076b67a9dc837  ptest xmm12, xmm12
000076b67a9dc83d  jnz 0x000076B67A9E17F8
000076b67a9dc843  movaps [r15+0x160], xmm14
000076b67a9dc84b  movaps xmm1, xmm8
000076b67a9dc84f  addpd xmm1, xmm9
000076b67a9dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000076b67a9dc859  ptest xmm12, xmm12
000076b67a9dc85f  jnz 0x000076B67A9E193A
000076b67a9dc865  movaps [r15+0x120], xmm1
000076b67a9dc86d  movups [r13+r14*1], xmm15
000076b67a9dc873  lea rax, [r14+0x10]
000076b67a9dc877  movups [r13+rax*1], xmm13
000076b67a9dc87d  lea rax, [r14+0x20]
000076b67a9dc881  movups [r13+rax*1], xmm14
000076b67a9dc887  lea rax, [r14+0x30]
000076b67a9dc88b  movups [r13+rax*1], xmm1
000076b67a9dc891  mov eax, [r15+0x108]
000076b67a9dc898  sahf
000076b67a9dc899  jnz 0x000076B67A9DC8CB
000076b67a9dc89b  cmp dword ptr [r15+0x318], 0x00
000076b67a9dc8a3  jz 0x000076B67A9DB900
000076b67a9dc8a9  nop [rax+rax*1], ax
000076b67a9dc8b2  nop [rax+rax*1], eax
000076b67a9dc8ba  mov eax, 0x410444
000076b67a9dc8bf  mov [r15+0x100], rax
000076b67a9dc8c6  jmp 0x000076B67A7FE110
000076b67a9dc8cb  cmp dword ptr [r15+0x318], 0x00
000076b67a9dc8d3  jz 0x000076B67A9D57E0
000076b67a9dc8d9  nop [rax+rax*1], ax
000076b67a9dc8e2  nop [rax+rax*1], eax
000076b67a9dc8ea  mov eax, 0x410278
000076b67a9dc8ef  mov [r15+0x100], rax
000076b67a9dc8f6  jmp 0x000076B67A7FE110
000076b67a9dc8fb  int3
000076b67a9dc8fc  call 0x000076B67A8E27E0
000076b67a9dc901  jmp 0x000076B67A9DB9DF
000076b67a9dc906  call 0x000076B67A8E1570
000076b67a9dc90b  jmp 0x000076B67A9DB9E8
000076b67a9dc910  call 0x000076B67A8E27E0
000076b67a9dc915  jmp 0x000076B67A9DBA44
000076b67a9dc91a  call 0x000076B67A8E1570
000076b67a9dc91f  jmp 0x000076B67A9DBA4D
000076b67a9dc924  call 0x000076B67A8E27E0
000076b67a9dc929  jmp 0x000076B67A9DBA90
000076b67a9dc92e  call 0x000076B67A8E1570
000076b67a9dc933  jmp 0x000076B67A9DBA99
000076b67a9dc938  call 0x000076B67A80DC20
000076b67a9dc93d  jmp 0x000076B67A9DBAD8
000076b67a9dc942  call 0x000076B67A8D59C0
000076b67a9dc947  jmp 0x000076B67A9DBAEB
000076b67a9dc94c  call 0x000076B67A8E0E30
000076b67a9dc951  jmp 0x000076B67A9DBB09
000076b67a9dc956  call 0x000076B67A8DFBC0
000076b67a9dc95b  jmp 0x000076B67A9DBB13
000076b67a9dc960  call 0x000076B67A8DE950
000076b67a9dc965  jmp 0x000076B67A9DBB1D
000076b67a9dc96a  sub rsp, 0x08
000076b67a9dc96e  push rax
000076b67a9dc96f  push rcx
000076b67a9dc970  push rdx
000076b67a9dc971  push rdi
000076b67a9dc972  push rsi
000076b67a9dc973  push r8
000076b67a9dc975  push r9
000076b67a9dc977  push r10
000076b67a9dc979  push r11
000076b67a9dc97b  sub rsp, 0xF0
000076b67a9dc982  vmovaps [rsp], xmm0
000076b67a9dc987  vmovaps [rsp+0x10], xmm1
000076b67a9dc98d  vmovaps [rsp+0x20], xmm2
000076b67a9dc993  vmovaps [rsp+0x30], xmm3
000076b67a9dc999  vmovaps [rsp+0x40], xmm4
000076b67a9dc99f  vmovaps [rsp+0x50], xmm5
000076b67a9dc9a5  vmovaps [rsp+0x60], xmm6
000076b67a9dc9ab  vmovaps [rsp+0x70], xmm7
000076b67a9dc9b1  vmovaps [rsp+0x80], xmm9
000076b67a9dc9ba  vmovaps [rsp+0x90], xmm10
000076b67a9dc9c3  vmovaps [rsp+0xA0], xmm11
000076b67a9dc9cc  vmovaps [rsp+0xB0], xmm12
000076b67a9dc9d5  vmovaps [rsp+0xC0], xmm13
000076b67a9dc9de  vmovaps [rsp+0xD0], xmm14
000076b67a9dc9e7  vmovaps [rsp+0xE0], xmm15
000076b67a9dc9f0  sub rsp, 0x30
000076b67a9dc9f4  movaps [rsp], xmm8
000076b67a9dc9f9  movaps [rsp+0x10], xmm12
000076b67a9dc9ff  movaps [rsp+0x20], xmm15
000076b67a9dca05  lea rdi, [rsp]
000076b67a9dca09  mov esi, 0x00
000076b67a9dca0e  mov rax, 0x63C5EF2DF530
000076b67a9dca18  call rax
000076b67a9dca1a  movaps xmm8, [rsp]
000076b67a9dca1f  add rsp, 0x30
000076b67a9dca23  vmovaps xmm0, [rsp]
000076b67a9dca28  vmovaps xmm1, [rsp+0x10]
000076b67a9dca2e  vmovaps xmm2, [rsp+0x20]
000076b67a9dca34  vmovaps xmm3, [rsp+0x30]
000076b67a9dca3a  vmovaps xmm4, [rsp+0x40]
000076b67a9dca40  vmovaps xmm5, [rsp+0x50]
000076b67a9dca46  vmovaps xmm6, [rsp+0x60]
000076b67a9dca4c  vmovaps xmm7, [rsp+0x70]
000076b67a9dca52  vmovaps xmm9, [rsp+0x80]
000076b67a9dca5b  vmovaps xmm10, [rsp+0x90]
000076b67a9dca64  vmovaps xmm11, [rsp+0xA0]
000076b67a9dca6d  vmovaps xmm12, [rsp+0xB0]
000076b67a9dca76  vmovaps xmm13, [rsp+0xC0]
000076b67a9dca7f  vmovaps xmm14, [rsp+0xD0]
000076b67a9dca88  vmovaps xmm15, [rsp+0xE0]
000076b67a9dca91  add rsp, 0xF0
000076b67a9dca98  pop r11
000076b67a9dca9a  pop r10
000076b67a9dca9c  pop r9
000076b67a9dca9e  pop r8
000076b67a9dcaa0  pop rsi
000076b67a9dcaa1  pop rdi
000076b67a9dcaa2  pop rdx
000076b67a9dcaa3  pop rcx
000076b67a9dcaa4  pop rax
000076b67a9dcaa5  add rsp, 0x08
000076b67a9dcaa9  jmp 0x000076B67A9DBB47
000076b67a9dcaae  sub rsp, 0x08
000076b67a9dcab2  push rax
000076b67a9dcab3  push rcx
000076b67a9dcab4  push rdx
000076b67a9dcab5  push rdi
000076b67a9dcab6  push rsi
000076b67a9dcab7  push r8
000076b67a9dcab9  push r9
000076b67a9dcabb  push r10
000076b67a9dcabd  push r11
000076b67a9dcabf  sub rsp, 0xF0
000076b67a9dcac6  vmovaps [rsp], xmm0
000076b67a9dcacb  vmovaps [rsp+0x10], xmm1
000076b67a9dcad1  vmovaps [rsp+0x20], xmm2
000076b67a9dcad7  vmovaps [rsp+0x30], xmm3
000076b67a9dcadd  vmovaps [rsp+0x40], xmm4
000076b67a9dcae3  vmovaps [rsp+0x50], xmm5
000076b67a9dcae9  vmovaps [rsp+0x60], xmm6
000076b67a9dcaef  vmovaps [rsp+0x70], xmm8
000076b67a9dcaf5  vmovaps [rsp+0x80], xmm9
000076b67a9dcafe  vmovaps [rsp+0x90], xmm10
000076b67a9dcb07  vmovaps [rsp+0xA0], xmm11
000076b67a9dcb10  vmovaps [rsp+0xB0], xmm12
000076b67a9dcb19  vmovaps [rsp+0xC0], xmm13
000076b67a9dcb22  vmovaps [rsp+0xD0], xmm14
000076b67a9dcb2b  vmovaps [rsp+0xE0], xmm15
000076b67a9dcb34  sub rsp, 0x30
000076b67a9dcb38  movaps [rsp], xmm7
000076b67a9dcb3c  movaps [rsp+0x10], xmm9
000076b67a9dcb42  movaps [rsp+0x20], xmm15
000076b67a9dcb48  lea rdi, [rsp]
000076b67a9dcb4c  mov esi, 0x00
000076b67a9dcb51  mov rax, 0x63C5EF2DF530
000076b67a9dcb5b  call rax
000076b67a9dcb5d  movaps xmm7, [rsp]
000076b67a9dcb61  add rsp, 0x30
000076b67a9dcb65  vmovaps xmm0, [rsp]
000076b67a9dcb6a  vmovaps xmm1, [rsp+0x10]
000076b67a9dcb70  vmovaps xmm2, [rsp+0x20]
000076b67a9dcb76  vmovaps xmm3, [rsp+0x30]
000076b67a9dcb7c  vmovaps xmm4, [rsp+0x40]
000076b67a9dcb82  vmovaps xmm5, [rsp+0x50]
000076b67a9dcb88  vmovaps xmm6, [rsp+0x60]
000076b67a9dcb8e  vmovaps xmm8, [rsp+0x70]
000076b67a9dcb94  vmovaps xmm9, [rsp+0x80]
000076b67a9dcb9d  vmovaps xmm10, [rsp+0x90]
000076b67a9dcba6  vmovaps xmm11, [rsp+0xA0]
000076b67a9dcbaf  vmovaps xmm12, [rsp+0xB0]
000076b67a9dcbb8  vmovaps xmm13, [rsp+0xC0]
000076b67a9dcbc1  vmovaps xmm14, [rsp+0xD0]
000076b67a9dcbca  vmovaps xmm15, [rsp+0xE0]
000076b67a9dcbd3  add rsp, 0xF0
000076b67a9dcbda  pop r11
000076b67a9dcbdc  pop r10
000076b67a9dcbde  pop r9
000076b67a9dcbe0  pop r8
000076b67a9dcbe2  pop rsi
000076b67a9dcbe3  pop rdi
000076b67a9dcbe4  pop rdx
000076b67a9dcbe5  pop rcx
000076b67a9dcbe6  pop rax
000076b67a9dcbe7  add rsp, 0x08
000076b67a9dcbeb  jmp 0x000076B67A9DBB75
000076b67a9dcbf0  sub rsp, 0x08
000076b67a9dcbf4  push rax
000076b67a9dcbf5  push rcx
000076b67a9dcbf6  push rdx
000076b67a9dcbf7  push rdi
000076b67a9dcbf8  push rsi
000076b67a9dcbf9  push r8
000076b67a9dcbfb  push r9
000076b67a9dcbfd  push r10
000076b67a9dcbff  push r11
000076b67a9dcc01  sub rsp, 0xF0
000076b67a9dcc08  vmovaps [rsp], xmm0
000076b67a9dcc0d  vmovaps [rsp+0x10], xmm1
000076b67a9dcc13  vmovaps [rsp+0x20], xmm2
000076b67a9dcc19  vmovaps [rsp+0x30], xmm3
000076b67a9dcc1f  vmovaps [rsp+0x40], xmm4
000076b67a9dcc25  vmovaps [rsp+0x50], xmm5
000076b67a9dcc2b  vmovaps [rsp+0x60], xmm6
000076b67a9dcc31  vmovaps [rsp+0x70], xmm7
000076b67a9dcc37  vmovaps [rsp+0x80], xmm8
000076b67a9dcc40  vmovaps [rsp+0x90], xmm10
000076b67a9dcc49  vmovaps [rsp+0xA0], xmm11
000076b67a9dcc52  vmovaps [rsp+0xB0], xmm12
000076b67a9dcc5b  vmovaps [rsp+0xC0], xmm13
000076b67a9dcc64  vmovaps [rsp+0xD0], xmm14
000076b67a9dcc6d  vmovaps [rsp+0xE0], xmm15
000076b67a9dcc76  sub rsp, 0x30
000076b67a9dcc7a  movaps [rsp], xmm9
000076b67a9dcc7f  movaps [rsp+0x10], xmm12
000076b67a9dcc85  movaps [rsp+0x20], xmm10
000076b67a9dcc8b  lea rdi, [rsp]
000076b67a9dcc8f  mov esi, 0x00
000076b67a9dcc94  mov rax, 0x63C5EF2DF530
000076b67a9dcc9e  call rax
000076b67a9dcca0  movaps xmm9, [rsp]
000076b67a9dcca5  add rsp, 0x30
000076b67a9dcca9  vmovaps xmm0, [rsp]
000076b67a9dccae  vmovaps xmm1, [rsp+0x10]
000076b67a9dccb4  vmovaps xmm2, [rsp+0x20]
000076b67a9dccba  vmovaps xmm3, [rsp+0x30]
000076b67a9dccc0  vmovaps xmm4, [rsp+0x40]
000076b67a9dccc6  vmovaps xmm5, [rsp+0x50]
000076b67a9dcccc  vmovaps xmm6, [rsp+0x60]
000076b67a9dccd2  vmovaps xmm7, [rsp+0x70]
000076b67a9dccd8  vmovaps xmm8, [rsp+0x80]
000076b67a9dcce1  vmovaps xmm10, [rsp+0x90]
000076b67a9dccea  vmovaps xmm11, [rsp+0xA0]
000076b67a9dccf3  vmovaps xmm12, [rsp+0xB0]
000076b67a9dccfc  vmovaps xmm13, [rsp+0xC0]
000076b67a9dcd05  vmovaps xmm14, [rsp+0xD0]
000076b67a9dcd0e  vmovaps xmm15, [rsp+0xE0]
000076b67a9dcd17  add rsp, 0xF0
000076b67a9dcd1e  pop r11
000076b67a9dcd20  pop r10
000076b67a9dcd22  pop r9
000076b67a9dcd24  pop r8
000076b67a9dcd26  pop rsi
000076b67a9dcd27  pop rdi
000076b67a9dcd28  pop rdx
000076b67a9dcd29  pop rcx
000076b67a9dcd2a  pop rax
000076b67a9dcd2b  add rsp, 0x08
000076b67a9dcd2f  jmp 0x000076B67A9DBB99
000076b67a9dcd34  sub rsp, 0x08
000076b67a9dcd38  push rax
000076b67a9dcd39  push rcx
000076b67a9dcd3a  push rdx
000076b67a9dcd3b  push rdi
000076b67a9dcd3c  push rsi
000076b67a9dcd3d  push r8
000076b67a9dcd3f  push r9
000076b67a9dcd41  push r10
000076b67a9dcd43  push r11
000076b67a9dcd45  sub rsp, 0xF0
000076b67a9dcd4c  vmovaps [rsp], xmm0
000076b67a9dcd51  vmovaps [rsp+0x10], xmm1
000076b67a9dcd57  vmovaps [rsp+0x20], xmm2
000076b67a9dcd5d  vmovaps [rsp+0x30], xmm3
000076b67a9dcd63  vmovaps [rsp+0x40], xmm4
000076b67a9dcd69  vmovaps [rsp+0x50], xmm5
000076b67a9dcd6f  vmovaps [rsp+0x60], xmm6
000076b67a9dcd75  vmovaps [rsp+0x70], xmm7
000076b67a9dcd7b  vmovaps [rsp+0x80], xmm8
000076b67a9dcd84  vmovaps [rsp+0x90], xmm9
000076b67a9dcd8d  vmovaps [rsp+0xA0], xmm11
000076b67a9dcd96  vmovaps [rsp+0xB0], xmm12
000076b67a9dcd9f  vmovaps [rsp+0xC0], xmm13
000076b67a9dcda8  vmovaps [rsp+0xD0], xmm14
000076b67a9dcdb1  vmovaps [rsp+0xE0], xmm15
000076b67a9dcdba  sub rsp, 0x30
000076b67a9dcdbe  movaps [rsp], xmm10
000076b67a9dcdc3  movaps [rsp+0x10], xmm12
000076b67a9dcdc9  movaps [rsp+0x20], xmm11
000076b67a9dcdcf  lea rdi, [rsp]
000076b67a9dcdd3  mov esi, 0x00
000076b67a9dcdd8  mov rax, 0x63C5EF2DF530
000076b67a9dcde2  call rax
000076b67a9dcde4  movaps xmm10, [rsp]
000076b67a9dcde9  add rsp, 0x30
000076b67a9dcded  vmovaps xmm0, [rsp]
000076b67a9dcdf2  vmovaps xmm1, [rsp+0x10]
000076b67a9dcdf8  vmovaps xmm2, [rsp+0x20]
000076b67a9dcdfe  vmovaps xmm3, [rsp+0x30]
000076b67a9dce04  vmovaps xmm4, [rsp+0x40]
000076b67a9dce0a  vmovaps xmm5, [rsp+0x50]
000076b67a9dce10  vmovaps xmm6, [rsp+0x60]
000076b67a9dce16  vmovaps xmm7, [rsp+0x70]
000076b67a9dce1c  vmovaps xmm8, [rsp+0x80]
000076b67a9dce25  vmovaps xmm9, [rsp+0x90]
000076b67a9dce2e  vmovaps xmm11, [rsp+0xA0]
000076b67a9dce37  vmovaps xmm12, [rsp+0xB0]
000076b67a9dce40  vmovaps xmm13, [rsp+0xC0]
000076b67a9dce49  vmovaps xmm14, [rsp+0xD0]
000076b67a9dce52  vmovaps xmm15, [rsp+0xE0]
000076b67a9dce5b  add rsp, 0xF0
000076b67a9dce62  pop r11
000076b67a9dce64  pop r10
000076b67a9dce66  pop r9
000076b67a9dce68  pop r8
000076b67a9dce6a  pop rsi
000076b67a9dce6b  pop rdi
000076b67a9dce6c  pop rdx
000076b67a9dce6d  pop rcx
000076b67a9dce6e  pop rax
000076b67a9dce6f  add rsp, 0x08
000076b67a9dce73  jmp 0x000076B67A9DBBB3
000076b67a9dce78  sub rsp, 0x08
000076b67a9dce7c  push rax
000076b67a9dce7d  push rcx
000076b67a9dce7e  push rdx
000076b67a9dce7f  push rdi
000076b67a9dce80  push rsi
000076b67a9dce81  push r8
000076b67a9dce83  push r9
000076b67a9dce85  push r10
000076b67a9dce87  push r11
000076b67a9dce89  sub rsp, 0xF0
000076b67a9dce90  vmovaps [rsp], xmm0
000076b67a9dce95  vmovaps [rsp+0x10], xmm1
000076b67a9dce9b  vmovaps [rsp+0x20], xmm2
000076b67a9dcea1  vmovaps [rsp+0x30], xmm3
000076b67a9dcea7  vmovaps [rsp+0x40], xmm4
000076b67a9dcead  vmovaps [rsp+0x50], xmm5
000076b67a9dceb3  vmovaps [rsp+0x60], xmm7
000076b67a9dceb9  vmovaps [rsp+0x70], xmm8
000076b67a9dcebf  vmovaps [rsp+0x80], xmm9
000076b67a9dcec8  vmovaps [rsp+0x90], xmm10
000076b67a9dced1  vmovaps [rsp+0xA0], xmm11
000076b67a9dceda  vmovaps [rsp+0xB0], xmm12
000076b67a9dcee3  vmovaps [rsp+0xC0], xmm13
000076b67a9dceec  vmovaps [rsp+0xD0], xmm14
000076b67a9dcef5  vmovaps [rsp+0xE0], xmm15
000076b67a9dcefe  sub rsp, 0x30
000076b67a9dcf02  movaps [rsp], xmm6
000076b67a9dcf06  movaps [rsp+0x10], xmm12
000076b67a9dcf0c  movaps [rsp+0x20], xmm11
000076b67a9dcf12  lea rdi, [rsp]
000076b67a9dcf16  mov esi, 0x00
000076b67a9dcf1b  mov rax, 0x63C5EF2DF530
000076b67a9dcf25  call rax
000076b67a9dcf27  movaps xmm6, [rsp]
000076b67a9dcf2b  add rsp, 0x30
000076b67a9dcf2f  vmovaps xmm0, [rsp]
000076b67a9dcf34  vmovaps xmm1, [rsp+0x10]
000076b67a9dcf3a  vmovaps xmm2, [rsp+0x20]
000076b67a9dcf40  vmovaps xmm3, [rsp+0x30]
000076b67a9dcf46  vmovaps xmm4, [rsp+0x40]
000076b67a9dcf4c  vmovaps xmm5, [rsp+0x50]
000076b67a9dcf52  vmovaps xmm7, [rsp+0x60]
000076b67a9dcf58  vmovaps xmm8, [rsp+0x70]
000076b67a9dcf5e  vmovaps xmm9, [rsp+0x80]
000076b67a9dcf67  vmovaps xmm10, [rsp+0x90]
000076b67a9dcf70  vmovaps xmm11, [rsp+0xA0]
000076b67a9dcf79  vmovaps xmm12, [rsp+0xB0]
000076b67a9dcf82  vmovaps xmm13, [rsp+0xC0]
000076b67a9dcf8b  vmovaps xmm14, [rsp+0xD0]
000076b67a9dcf94  vmovaps xmm15, [rsp+0xE0]
000076b67a9dcf9d  add rsp, 0xF0
000076b67a9dcfa4  pop r11
000076b67a9dcfa6  pop r10
000076b67a9dcfa8  pop r9
000076b67a9dcfaa  pop r8
000076b67a9dcfac  pop rsi
000076b67a9dcfad  pop rdi
000076b67a9dcfae  pop rdx
000076b67a9dcfaf  pop rcx
000076b67a9dcfb0  pop rax
000076b67a9dcfb1  add rsp, 0x08
000076b67a9dcfb5  jmp 0x000076B67A9DBBD4
000076b67a9dcfba  sub rsp, 0x08
000076b67a9dcfbe  push rax
000076b67a9dcfbf  push rcx
000076b67a9dcfc0  push rdx
000076b67a9dcfc1  push rdi
000076b67a9dcfc2  push rsi
000076b67a9dcfc3  push r8
000076b67a9dcfc5  push r9
000076b67a9dcfc7  push r10
000076b67a9dcfc9  push r11
000076b67a9dcfcb  sub rsp, 0xF0
000076b67a9dcfd2  vmovaps [rsp], xmm0
000076b67a9dcfd7  vmovaps [rsp+0x10], xmm1
000076b67a9dcfdd  vmovaps [rsp+0x20], xmm2
000076b67a9dcfe3  vmovaps [rsp+0x30], xmm4
000076b67a9dcfe9  vmovaps [rsp+0x40], xmm5
000076b67a9dcfef  vmovaps [rsp+0x50], xmm6
000076b67a9dcff5  vmovaps [rsp+0x60], xmm7
000076b67a9dcffb  vmovaps [rsp+0x70], xmm8
000076b67a9dd001  vmovaps [rsp+0x80], xmm9
000076b67a9dd00a  vmovaps [rsp+0x90], xmm10
000076b67a9dd013  vmovaps [rsp+0xA0], xmm11
000076b67a9dd01c  vmovaps [rsp+0xB0], xmm12
000076b67a9dd025  vmovaps [rsp+0xC0], xmm13
000076b67a9dd02e  vmovaps [rsp+0xD0], xmm14
000076b67a9dd037  vmovaps [rsp+0xE0], xmm15
000076b67a9dd040  sub rsp, 0x30
000076b67a9dd044  movaps [rsp], xmm3
000076b67a9dd048  movaps [rsp+0x10], xmm5
000076b67a9dd04d  movaps [rsp+0x20], xmm4
000076b67a9dd052  lea rdi, [rsp]
000076b67a9dd056  mov esi, 0x00
000076b67a9dd05b  mov rax, 0x63C5EF2DF530
000076b67a9dd065  call rax
000076b67a9dd067  movaps xmm3, [rsp]
000076b67a9dd06b  add rsp, 0x30
000076b67a9dd06f  vmovaps xmm0, [rsp]
000076b67a9dd074  vmovaps xmm1, [rsp+0x10]
000076b67a9dd07a  vmovaps xmm2, [rsp+0x20]
000076b67a9dd080  vmovaps xmm4, [rsp+0x30]
000076b67a9dd086  vmovaps xmm5, [rsp+0x40]
000076b67a9dd08c  vmovaps xmm6, [rsp+0x50]
000076b67a9dd092  vmovaps xmm7, [rsp+0x60]
000076b67a9dd098  vmovaps xmm8, [rsp+0x70]
000076b67a9dd09e  vmovaps xmm9, [rsp+0x80]
000076b67a9dd0a7  vmovaps xmm10, [rsp+0x90]
000076b67a9dd0b0  vmovaps xmm11, [rsp+0xA0]
000076b67a9dd0b9  vmovaps xmm12, [rsp+0xB0]
000076b67a9dd0c2  vmovaps xmm13, [rsp+0xC0]
000076b67a9dd0cb  vmovaps xmm14, [rsp+0xD0]
000076b67a9dd0d4  vmovaps xmm15, [rsp+0xE0]
000076b67a9dd0dd  add rsp, 0xF0
000076b67a9dd0e4  pop r11
000076b67a9dd0e6  pop r10
000076b67a9dd0e8  pop r9
000076b67a9dd0ea  pop r8
000076b67a9dd0ec  pop rsi
000076b67a9dd0ed  pop rdi
000076b67a9dd0ee  pop rdx
000076b67a9dd0ef  pop rcx
000076b67a9dd0f0  pop rax
000076b67a9dd0f1  add rsp, 0x08
000076b67a9dd0f5  jmp 0x000076B67A9DBC35
000076b67a9dd0fa  sub rsp, 0x08
000076b67a9dd0fe  push rax
000076b67a9dd0ff  push rcx
000076b67a9dd100  push rdx
000076b67a9dd101  push rdi
000076b67a9dd102  push rsi
000076b67a9dd103  push r8
000076b67a9dd105  push r9
000076b67a9dd107  push r10
000076b67a9dd109  push r11
000076b67a9dd10b  sub rsp, 0xF0
000076b67a9dd112  vmovaps [rsp], xmm0
000076b67a9dd117  vmovaps [rsp+0x10], xmm1
000076b67a9dd11d  vmovaps [rsp+0x20], xmm2
000076b67a9dd123  vmovaps [rsp+0x30], xmm3
000076b67a9dd129  vmovaps [rsp+0x40], xmm4
000076b67a9dd12f  vmovaps [rsp+0x50], xmm6
000076b67a9dd135  vmovaps [rsp+0x60], xmm7
000076b67a9dd13b  vmovaps [rsp+0x70], xmm8
000076b67a9dd141  vmovaps [rsp+0x80], xmm9
000076b67a9dd14a  vmovaps [rsp+0x90], xmm10
000076b67a9dd153  vmovaps [rsp+0xA0], xmm11
000076b67a9dd15c  vmovaps [rsp+0xB0], xmm12
000076b67a9dd165  vmovaps [rsp+0xC0], xmm13
000076b67a9dd16e  vmovaps [rsp+0xD0], xmm14
000076b67a9dd177  vmovaps [rsp+0xE0], xmm15
000076b67a9dd180  sub rsp, 0x30
000076b67a9dd184  movaps [rsp], xmm5
000076b67a9dd188  movaps [rsp+0x10], xmm8
000076b67a9dd18e  movaps [rsp+0x20], xmm15
000076b67a9dd194  lea rdi, [rsp]
000076b67a9dd198  mov esi, 0x00
000076b67a9dd19d  mov rax, 0x63C5EF2DF530
000076b67a9dd1a7  call rax
000076b67a9dd1a9  movaps xmm5, [rsp]
000076b67a9dd1ad  add rsp, 0x30
000076b67a9dd1b1  vmovaps xmm0, [rsp]
000076b67a9dd1b6  vmovaps xmm1, [rsp+0x10]
000076b67a9dd1bc  vmovaps xmm2, [rsp+0x20]
000076b67a9dd1c2  vmovaps xmm3, [rsp+0x30]
000076b67a9dd1c8  vmovaps xmm4, [rsp+0x40]
000076b67a9dd1ce  vmovaps xmm6, [rsp+0x50]
000076b67a9dd1d4  vmovaps xmm7, [rsp+0x60]
000076b67a9dd1da  vmovaps xmm8, [rsp+0x70]
000076b67a9dd1e0  vmovaps xmm9, [rsp+0x80]
000076b67a9dd1e9  vmovaps xmm10, [rsp+0x90]
000076b67a9dd1f2  vmovaps xmm11, [rsp+0xA0]
000076b67a9dd1fb  vmovaps xmm12, [rsp+0xB0]
000076b67a9dd204  vmovaps xmm13, [rsp+0xC0]
000076b67a9dd20d  vmovaps xmm14, [rsp+0xD0]
000076b67a9dd216  vmovaps xmm15, [rsp+0xE0]
000076b67a9dd21f  add rsp, 0xF0
000076b67a9dd226  pop r11
000076b67a9dd228  pop r10
000076b67a9dd22a  pop r9
000076b67a9dd22c  pop r8
000076b67a9dd22e  pop rsi
000076b67a9dd22f  pop rdi
000076b67a9dd230  pop rdx
000076b67a9dd231  pop rcx
000076b67a9dd232  pop rax
000076b67a9dd233  add rsp, 0x08
000076b67a9dd237  jmp 0x000076B67A9DBC73
000076b67a9dd23c  sub rsp, 0x08
000076b67a9dd240  push rax
000076b67a9dd241  push rcx
000076b67a9dd242  push rdx
000076b67a9dd243  push rdi
000076b67a9dd244  push rsi
000076b67a9dd245  push r8
000076b67a9dd247  push r9
000076b67a9dd249  push r10
000076b67a9dd24b  push r11
000076b67a9dd24d  sub rsp, 0xF0
000076b67a9dd254  vmovaps [rsp], xmm0
000076b67a9dd259  vmovaps [rsp+0x10], xmm1
000076b67a9dd25f  vmovaps [rsp+0x20], xmm2
000076b67a9dd265  vmovaps [rsp+0x30], xmm3
000076b67a9dd26b  vmovaps [rsp+0x40], xmm5
000076b67a9dd271  vmovaps [rsp+0x50], xmm6
000076b67a9dd277  vmovaps [rsp+0x60], xmm7
000076b67a9dd27d  vmovaps [rsp+0x70], xmm8
000076b67a9dd283  vmovaps [rsp+0x80], xmm9
000076b67a9dd28c  vmovaps [rsp+0x90], xmm10
000076b67a9dd295  vmovaps [rsp+0xA0], xmm11
000076b67a9dd29e  vmovaps [rsp+0xB0], xmm12
000076b67a9dd2a7  vmovaps [rsp+0xC0], xmm13
000076b67a9dd2b0  vmovaps [rsp+0xD0], xmm14
000076b67a9dd2b9  vmovaps [rsp+0xE0], xmm15
000076b67a9dd2c2  sub rsp, 0x30
000076b67a9dd2c6  movaps [rsp], xmm4
000076b67a9dd2ca  movaps [rsp+0x10], xmm9
000076b67a9dd2d0  movaps [rsp+0x20], xmm8
000076b67a9dd2d6  lea rdi, [rsp]
000076b67a9dd2da  mov esi, 0x00
000076b67a9dd2df  mov rax, 0x63C5EF2DF530
000076b67a9dd2e9  call rax
000076b67a9dd2eb  movaps xmm4, [rsp]
000076b67a9dd2ef  add rsp, 0x30
000076b67a9dd2f3  vmovaps xmm0, [rsp]
000076b67a9dd2f8  vmovaps xmm1, [rsp+0x10]
000076b67a9dd2fe  vmovaps xmm2, [rsp+0x20]
000076b67a9dd304  vmovaps xmm3, [rsp+0x30]
000076b67a9dd30a  vmovaps xmm5, [rsp+0x40]
000076b67a9dd310  vmovaps xmm6, [rsp+0x50]
000076b67a9dd316  vmovaps xmm7, [rsp+0x60]
000076b67a9dd31c  vmovaps xmm8, [rsp+0x70]
000076b67a9dd322  vmovaps xmm9, [rsp+0x80]
000076b67a9dd32b  vmovaps xmm10, [rsp+0x90]
000076b67a9dd334  vmovaps xmm11, [rsp+0xA0]
000076b67a9dd33d  vmovaps xmm12, [rsp+0xB0]
000076b67a9dd346  vmovaps xmm13, [rsp+0xC0]
000076b67a9dd34f  vmovaps xmm14, [rsp+0xD0]
000076b67a9dd358  vmovaps xmm15, [rsp+0xE0]
000076b67a9dd361  add rsp, 0xF0
000076b67a9dd368  pop r11
000076b67a9dd36a  pop r10
000076b67a9dd36c  pop r9
000076b67a9dd36e  pop r8
000076b67a9dd370  pop rsi
000076b67a9dd371  pop rdi
000076b67a9dd372  pop rdx
000076b67a9dd373  pop rcx
000076b67a9dd374  pop rax
000076b67a9dd375  add rsp, 0x08
000076b67a9dd379  jmp 0x000076B67A9DBC94
000076b67a9dd37e  sub rsp, 0x08
000076b67a9dd382  push rax
000076b67a9dd383  push rcx
000076b67a9dd384  push rdx
000076b67a9dd385  push rdi
000076b67a9dd386  push rsi
000076b67a9dd387  push r8
000076b67a9dd389  push r9
000076b67a9dd38b  push r10
000076b67a9dd38d  push r11
000076b67a9dd38f  sub rsp, 0xF0
000076b67a9dd396  vmovaps [rsp], xmm0
000076b67a9dd39b  vmovaps [rsp+0x10], xmm1
000076b67a9dd3a1  vmovaps [rsp+0x20], xmm2
000076b67a9dd3a7  vmovaps [rsp+0x30], xmm3
000076b67a9dd3ad  vmovaps [rsp+0x40], xmm4
000076b67a9dd3b3  vmovaps [rsp+0x50], xmm5
000076b67a9dd3b9  vmovaps [rsp+0x60], xmm6
000076b67a9dd3bf  vmovaps [rsp+0x70], xmm7
000076b67a9dd3c5  vmovaps [rsp+0x80], xmm8
000076b67a9dd3ce  vmovaps [rsp+0x90], xmm10
000076b67a9dd3d7  vmovaps [rsp+0xA0], xmm11
000076b67a9dd3e0  vmovaps [rsp+0xB0], xmm12
000076b67a9dd3e9  vmovaps [rsp+0xC0], xmm13
000076b67a9dd3f2  vmovaps [rsp+0xD0], xmm14
000076b67a9dd3fb  vmovaps [rsp+0xE0], xmm15
000076b67a9dd404  sub rsp, 0x30
000076b67a9dd408  movaps [rsp], xmm9
000076b67a9dd40d  movaps [rsp+0x10], xmm10
000076b67a9dd413  movaps [rsp+0x20], xmm8
000076b67a9dd419  lea rdi, [rsp]
000076b67a9dd41d  mov esi, 0x00
000076b67a9dd422  mov rax, 0x63C5EF2DF530
000076b67a9dd42c  call rax
000076b67a9dd42e  movaps xmm9, [rsp]
000076b67a9dd433  add rsp, 0x30
000076b67a9dd437  vmovaps xmm0, [rsp]
000076b67a9dd43c  vmovaps xmm1, [rsp+0x10]
000076b67a9dd442  vmovaps xmm2, [rsp+0x20]
000076b67a9dd448  vmovaps xmm3, [rsp+0x30]
000076b67a9dd44e  vmovaps xmm4, [rsp+0x40]
000076b67a9dd454  vmovaps xmm5, [rsp+0x50]
000076b67a9dd45a  vmovaps xmm6, [rsp+0x60]
000076b67a9dd460  vmovaps xmm7, [rsp+0x70]
000076b67a9dd466  vmovaps xmm8, [rsp+0x80]
000076b67a9dd46f  vmovaps xmm10, [rsp+0x90]
000076b67a9dd478  vmovaps xmm11, [rsp+0xA0]
000076b67a9dd481  vmovaps xmm12, [rsp+0xB0]
000076b67a9dd48a  vmovaps xmm13, [rsp+0xC0]
000076b67a9dd493  vmovaps xmm14, [rsp+0xD0]
000076b67a9dd49c  vmovaps xmm15, [rsp+0xE0]
000076b67a9dd4a5  add rsp, 0xF0
000076b67a9dd4ac  pop r11
000076b67a9dd4ae  pop r10
000076b67a9dd4b0  pop r9
000076b67a9dd4b2  pop r8
000076b67a9dd4b4  pop rsi
000076b67a9dd4b5  pop rdi
000076b67a9dd4b6  pop rdx
000076b67a9dd4b7  pop rcx
000076b67a9dd4b8  pop rax
000076b67a9dd4b9  add rsp, 0x08
000076b67a9dd4bd  jmp 0x000076B67A9DBCAE
000076b67a9dd4c2  call 0x000076B67A8B52F0
000076b67a9dd4c7  jmp 0x000076B67A9DBDC8
000076b67a9dd4cc  call 0x000076B67A8B52F0
000076b67a9dd4d1  jmp 0x000076B67A9DBDDE
000076b67a9dd4d6  sub rsp, 0x08
000076b67a9dd4da  push rax
000076b67a9dd4db  push rcx
000076b67a9dd4dc  push rdx
000076b67a9dd4dd  push rdi
000076b67a9dd4de  push rsi
000076b67a9dd4df  push r8
000076b67a9dd4e1  push r9
000076b67a9dd4e3  push r10
000076b67a9dd4e5  push r11
000076b67a9dd4e7  sub rsp, 0xF0
000076b67a9dd4ee  vmovaps [rsp], xmm0
000076b67a9dd4f3  vmovaps [rsp+0x10], xmm2
000076b67a9dd4f9  vmovaps [rsp+0x20], xmm3
000076b67a9dd4ff  vmovaps [rsp+0x30], xmm4
000076b67a9dd505  vmovaps [rsp+0x40], xmm5
000076b67a9dd50b  vmovaps [rsp+0x50], xmm6
000076b67a9dd511  vmovaps [rsp+0x60], xmm7
000076b67a9dd517  vmovaps [rsp+0x70], xmm8
000076b67a9dd51d  vmovaps [rsp+0x80], xmm9
000076b67a9dd526  vmovaps [rsp+0x90], xmm10
000076b67a9dd52f  vmovaps [rsp+0xA0], xmm11
000076b67a9dd538  vmovaps [rsp+0xB0], xmm12
000076b67a9dd541  vmovaps [rsp+0xC0], xmm13
000076b67a9dd54a  vmovaps [rsp+0xD0], xmm14
000076b67a9dd553  vmovaps [rsp+0xE0], xmm15
000076b67a9dd55c  sub rsp, 0x30
000076b67a9dd560  movaps [rsp], xmm1
000076b67a9dd564  movaps [rsp+0x10], xmm6
000076b67a9dd569  movaps [rsp+0x20], xmm15
000076b67a9dd56f  lea rdi, [rsp]
000076b67a9dd573  mov esi, 0x00
000076b67a9dd578  mov rax, 0x63C5EF2DF530
000076b67a9dd582  call rax
000076b67a9dd584  movaps xmm1, [rsp]
000076b67a9dd588  add rsp, 0x30
000076b67a9dd58c  vmovaps xmm0, [rsp]
000076b67a9dd591  vmovaps xmm2, [rsp+0x10]
000076b67a9dd597  vmovaps xmm3, [rsp+0x20]
000076b67a9dd59d  vmovaps xmm4, [rsp+0x30]
000076b67a9dd5a3  vmovaps xmm5, [rsp+0x40]
000076b67a9dd5a9  vmovaps xmm6, [rsp+0x50]
000076b67a9dd5af  vmovaps xmm7, [rsp+0x60]
000076b67a9dd5b5  vmovaps xmm8, [rsp+0x70]
000076b67a9dd5bb  vmovaps xmm9, [rsp+0x80]
000076b67a9dd5c4  vmovaps xmm10, [rsp+0x90]
000076b67a9dd5cd  vmovaps xmm11, [rsp+0xA0]
000076b67a9dd5d6  vmovaps xmm12, [rsp+0xB0]
000076b67a9dd5df  vmovaps xmm13, [rsp+0xC0]
000076b67a9dd5e8  vmovaps xmm14, [rsp+0xD0]
000076b67a9dd5f1  vmovaps xmm15, [rsp+0xE0]
000076b67a9dd5fa  add rsp, 0xF0
000076b67a9dd601  pop r11
000076b67a9dd603  pop r10
000076b67a9dd605  pop r9
000076b67a9dd607  pop r8
000076b67a9dd609  pop rsi
000076b67a9dd60a  pop rdi
000076b67a9dd60b  pop rdx
000076b67a9dd60c  pop rcx
000076b67a9dd60d  pop rax
000076b67a9dd60e  add rsp, 0x08
000076b67a9dd612  jmp 0x000076B67A9DBE1B
000076b67a9dd617  call 0x000076B67A8C4620
000076b67a9dd61c  jmp 0x000076B67A9DBE28
000076b67a9dd621  sub rsp, 0x08
000076b67a9dd625  push rax
000076b67a9dd626  push rcx
000076b67a9dd627  push rdx
000076b67a9dd628  push rdi
000076b67a9dd629  push rsi
000076b67a9dd62a  push r8
000076b67a9dd62c  push r9
000076b67a9dd62e  push r10
000076b67a9dd630  push r11
000076b67a9dd632  sub rsp, 0xF0
000076b67a9dd639  vmovaps [rsp], xmm0
000076b67a9dd63e  vmovaps [rsp+0x10], xmm1
000076b67a9dd644  vmovaps [rsp+0x20], xmm2
000076b67a9dd64a  vmovaps [rsp+0x30], xmm3
000076b67a9dd650  vmovaps [rsp+0x40], xmm4
000076b67a9dd656  vmovaps [rsp+0x50], xmm5
000076b67a9dd65c  vmovaps [rsp+0x60], xmm6
000076b67a9dd662  vmovaps [rsp+0x70], xmm7
000076b67a9dd668  vmovaps [rsp+0x80], xmm8
000076b67a9dd671  vmovaps [rsp+0x90], xmm9
000076b67a9dd67a  vmovaps [rsp+0xA0], xmm10
000076b67a9dd683  vmovaps [rsp+0xB0], xmm11
000076b67a9dd68c  vmovaps [rsp+0xC0], xmm12
000076b67a9dd695  vmovaps [rsp+0xD0], xmm13
000076b67a9dd69e  vmovaps [rsp+0xE0], xmm15
000076b67a9dd6a7  sub rsp, 0x30
000076b67a9dd6ab  movaps [rsp], xmm14
000076b67a9dd6b0  movaps [rsp+0x10], xmm4
000076b67a9dd6b5  movaps [rsp+0x20], xmm3
000076b67a9dd6ba  lea rdi, [rsp]
000076b67a9dd6be  mov esi, 0x00
000076b67a9dd6c3  mov rax, 0x63C5EF2DF530
000076b67a9dd6cd  call rax
000076b67a9dd6cf  movaps xmm14, [rsp]
000076b67a9dd6d4  add rsp, 0x30
000076b67a9dd6d8  vmovaps xmm0, [rsp]
000076b67a9dd6dd  vmovaps xmm1, [rsp+0x10]
000076b67a9dd6e3  vmovaps xmm2, [rsp+0x20]
000076b67a9dd6e9  vmovaps xmm3, [rsp+0x30]
000076b67a9dd6ef  vmovaps xmm4, [rsp+0x40]
000076b67a9dd6f5  vmovaps xmm5, [rsp+0x50]
000076b67a9dd6fb  vmovaps xmm6, [rsp+0x60]
000076b67a9dd701  vmovaps xmm7, [rsp+0x70]
000076b67a9dd707  vmovaps xmm8, [rsp+0x80]
000076b67a9dd710  vmovaps xmm9, [rsp+0x90]
000076b67a9dd719  vmovaps xmm10, [rsp+0xA0]
000076b67a9dd722  vmovaps xmm11, [rsp+0xB0]
000076b67a9dd72b  vmovaps xmm12, [rsp+0xC0]
000076b67a9dd734  vmovaps xmm13, [rsp+0xD0]
000076b67a9dd73d  vmovaps xmm15, [rsp+0xE0]
000076b67a9dd746  add rsp, 0xF0
000076b67a9dd74d  pop r11
000076b67a9dd74f  pop r10
000076b67a9dd751  pop r9
000076b67a9dd753  pop r8
000076b67a9dd755  pop rsi
000076b67a9dd756  pop rdi
000076b67a9dd757  pop rdx
000076b67a9dd758  pop rcx
000076b67a9dd759  pop rax
000076b67a9dd75a  add rsp, 0x08
000076b67a9dd75e  jmp 0x000076B67A9DBE42
000076b67a9dd763  sub rsp, 0x08
000076b67a9dd767  push rax
000076b67a9dd768  push rcx
000076b67a9dd769  push rdx
000076b67a9dd76a  push rdi
000076b67a9dd76b  push rsi
000076b67a9dd76c  push r8
000076b67a9dd76e  push r9
000076b67a9dd770  push r10
000076b67a9dd772  push r11
000076b67a9dd774  sub rsp, 0xF0
000076b67a9dd77b  vmovaps [rsp], xmm0
000076b67a9dd780  vmovaps [rsp+0x10], xmm1
000076b67a9dd786  vmovaps [rsp+0x20], xmm2
000076b67a9dd78c  vmovaps [rsp+0x30], xmm3
000076b67a9dd792  vmovaps [rsp+0x40], xmm4
000076b67a9dd798  vmovaps [rsp+0x50], xmm5
000076b67a9dd79e  vmovaps [rsp+0x60], xmm7
000076b67a9dd7a4  vmovaps [rsp+0x70], xmm8
000076b67a9dd7aa  vmovaps [rsp+0x80], xmm9
000076b67a9dd7b3  vmovaps [rsp+0x90], xmm10
000076b67a9dd7bc  vmovaps [rsp+0xA0], xmm11
000076b67a9dd7c5  vmovaps [rsp+0xB0], xmm12
000076b67a9dd7ce  vmovaps [rsp+0xC0], xmm13
000076b67a9dd7d7  vmovaps [rsp+0xD0], xmm14
000076b67a9dd7e0  vmovaps [rsp+0xE0], xmm15
000076b67a9dd7e9  sub rsp, 0x30
000076b67a9dd7ed  movaps [rsp], xmm6
000076b67a9dd7f1  movaps [rsp+0x10], xmm9
000076b67a9dd7f7  movaps [rsp+0x20], xmm7
000076b67a9dd7fc  lea rdi, [rsp]
000076b67a9dd800  mov esi, 0x00
000076b67a9dd805  mov rax, 0x63C5EF2DF530
000076b67a9dd80f  call rax
000076b67a9dd811  movaps xmm6, [rsp]
000076b67a9dd815  add rsp, 0x30
000076b67a9dd819  vmovaps xmm0, [rsp]
000076b67a9dd81e  vmovaps xmm1, [rsp+0x10]
000076b67a9dd824  vmovaps xmm2, [rsp+0x20]
000076b67a9dd82a  vmovaps xmm3, [rsp+0x30]
000076b67a9dd830  vmovaps xmm4, [rsp+0x40]
000076b67a9dd836  vmovaps xmm5, [rsp+0x50]
000076b67a9dd83c  vmovaps xmm7, [rsp+0x60]
000076b67a9dd842  vmovaps xmm8, [rsp+0x70]
000076b67a9dd848  vmovaps xmm9, [rsp+0x80]
000076b67a9dd851  vmovaps xmm10, [rsp+0x90]
000076b67a9dd85a  vmovaps xmm11, [rsp+0xA0]
000076b67a9dd863  vmovaps xmm12, [rsp+0xB0]
000076b67a9dd86c  vmovaps xmm13, [rsp+0xC0]
000076b67a9dd875  vmovaps xmm14, [rsp+0xD0]
000076b67a9dd87e  vmovaps xmm15, [rsp+0xE0]
000076b67a9dd887  add rsp, 0xF0
000076b67a9dd88e  pop r11
000076b67a9dd890  pop r10
000076b67a9dd892  pop r9
000076b67a9dd894  pop r8
000076b67a9dd896  pop rsi
000076b67a9dd897  pop rdi
000076b67a9dd898  pop rdx
000076b67a9dd899  pop rcx
000076b67a9dd89a  pop rax
000076b67a9dd89b  add rsp, 0x08
000076b67a9dd89f  jmp 0x000076B67A9DBE5A
000076b67a9dd8a4  sub rsp, 0x08
000076b67a9dd8a8  push rax
000076b67a9dd8a9  push rcx
000076b67a9dd8aa  push rdx
000076b67a9dd8ab  push rdi
000076b67a9dd8ac  push rsi
000076b67a9dd8ad  push r8
000076b67a9dd8af  push r9
000076b67a9dd8b1  push r10
000076b67a9dd8b3  push r11
000076b67a9dd8b5  sub rsp, 0xF0
000076b67a9dd8bc  vmovaps [rsp], xmm0
000076b67a9dd8c1  vmovaps [rsp+0x10], xmm1
000076b67a9dd8c7  vmovaps [rsp+0x20], xmm2
000076b67a9dd8cd  vmovaps [rsp+0x30], xmm3
000076b67a9dd8d3  vmovaps [rsp+0x40], xmm4
000076b67a9dd8d9  vmovaps [rsp+0x50], xmm5
000076b67a9dd8df  vmovaps [rsp+0x60], xmm6
000076b67a9dd8e5  vmovaps [rsp+0x70], xmm8
000076b67a9dd8eb  vmovaps [rsp+0x80], xmm9
000076b67a9dd8f4  vmovaps [rsp+0x90], xmm10
000076b67a9dd8fd  vmovaps [rsp+0xA0], xmm11
000076b67a9dd906  vmovaps [rsp+0xB0], xmm12
000076b67a9dd90f  vmovaps [rsp+0xC0], xmm13
000076b67a9dd918  vmovaps [rsp+0xD0], xmm14
000076b67a9dd921  vmovaps [rsp+0xE0], xmm15
000076b67a9dd92a  sub rsp, 0x30
000076b67a9dd92e  movaps [rsp], xmm7
000076b67a9dd932  movaps [rsp+0x10], xmm4
000076b67a9dd937  movaps [rsp+0x20], xmm9
000076b67a9dd93d  lea rdi, [rsp]
000076b67a9dd941  mov esi, 0x00
000076b67a9dd946  mov rax, 0x63C5EF2DF530
000076b67a9dd950  call rax
000076b67a9dd952  movaps xmm7, [rsp]
000076b67a9dd956  add rsp, 0x30
000076b67a9dd95a  vmovaps xmm0, [rsp]
000076b67a9dd95f  vmovaps xmm1, [rsp+0x10]
000076b67a9dd965  vmovaps xmm2, [rsp+0x20]
000076b67a9dd96b  vmovaps xmm3, [rsp+0x30]
000076b67a9dd971  vmovaps xmm4, [rsp+0x40]
000076b67a9dd977  vmovaps xmm5, [rsp+0x50]
000076b67a9dd97d  vmovaps xmm6, [rsp+0x60]
000076b67a9dd983  vmovaps xmm8, [rsp+0x70]
000076b67a9dd989  vmovaps xmm9, [rsp+0x80]
000076b67a9dd992  vmovaps xmm10, [rsp+0x90]
000076b67a9dd99b  vmovaps xmm11, [rsp+0xA0]
000076b67a9dd9a4  vmovaps xmm12, [rsp+0xB0]
000076b67a9dd9ad  vmovaps xmm13, [rsp+0xC0]
000076b67a9dd9b6  vmovaps xmm14, [rsp+0xD0]
000076b67a9dd9bf  vmovaps xmm15, [rsp+0xE0]
000076b67a9dd9c8  add rsp, 0xF0
000076b67a9dd9cf  pop r11
000076b67a9dd9d1  pop r10
000076b67a9dd9d3  pop r9
000076b67a9dd9d5  pop r8
000076b67a9dd9d7  pop rsi
000076b67a9dd9d8  pop rdi
000076b67a9dd9d9  pop rdx
000076b67a9dd9da  pop rcx
000076b67a9dd9db  pop rax
000076b67a9dd9dc  add rsp, 0x08
000076b67a9dd9e0  jmp 0x000076B67A9DBE87
000076b67a9dd9e5  sub rsp, 0x08
000076b67a9dd9e9  push rax
000076b67a9dd9ea  push rcx
000076b67a9dd9eb  push rdx
000076b67a9dd9ec  push rdi
000076b67a9dd9ed  push rsi
000076b67a9dd9ee  push r8
000076b67a9dd9f0  push r9
000076b67a9dd9f2  push r10
000076b67a9dd9f4  push r11
000076b67a9dd9f6  sub rsp, 0xF0
000076b67a9dd9fd  vmovaps [rsp], xmm0
000076b67a9dda02  vmovaps [rsp+0x10], xmm1
000076b67a9dda08  vmovaps [rsp+0x20], xmm2
000076b67a9dda0e  vmovaps [rsp+0x30], xmm3
000076b67a9dda14  vmovaps [rsp+0x40], xmm5
000076b67a9dda1a  vmovaps [rsp+0x50], xmm6
000076b67a9dda20  vmovaps [rsp+0x60], xmm7
000076b67a9dda26  vmovaps [rsp+0x70], xmm8
000076b67a9dda2c  vmovaps [rsp+0x80], xmm9
000076b67a9dda35  vmovaps [rsp+0x90], xmm10
000076b67a9dda3e  vmovaps [rsp+0xA0], xmm11
000076b67a9dda47  vmovaps [rsp+0xB0], xmm12
000076b67a9dda50  vmovaps [rsp+0xC0], xmm13
000076b67a9dda59  vmovaps [rsp+0xD0], xmm14
000076b67a9dda62  vmovaps [rsp+0xE0], xmm15
000076b67a9dda6b  sub rsp, 0x30
000076b67a9dda6f  movaps [rsp], xmm4
000076b67a9dda73  movaps [rsp+0x10], xmm15
000076b67a9dda79  movaps [rsp+0x20], xmm9
000076b67a9dda7f  lea rdi, [rsp]
000076b67a9dda83  mov esi, 0x00
000076b67a9dda88  mov rax, 0x63C5EF2DF530
000076b67a9dda92  call rax
000076b67a9dda94  movaps xmm4, [rsp]
000076b67a9dda98  add rsp, 0x30
000076b67a9dda9c  vmovaps xmm0, [rsp]
000076b67a9ddaa1  vmovaps xmm1, [rsp+0x10]
000076b67a9ddaa7  vmovaps xmm2, [rsp+0x20]
000076b67a9ddaad  vmovaps xmm3, [rsp+0x30]
000076b67a9ddab3  vmovaps xmm5, [rsp+0x40]
000076b67a9ddab9  vmovaps xmm6, [rsp+0x50]
000076b67a9ddabf  vmovaps xmm7, [rsp+0x60]
000076b67a9ddac5  vmovaps xmm8, [rsp+0x70]
000076b67a9ddacb  vmovaps xmm9, [rsp+0x80]
000076b67a9ddad4  vmovaps xmm10, [rsp+0x90]
000076b67a9ddadd  vmovaps xmm11, [rsp+0xA0]
000076b67a9ddae6  vmovaps xmm12, [rsp+0xB0]
000076b67a9ddaef  vmovaps xmm13, [rsp+0xC0]
000076b67a9ddaf8  vmovaps xmm14, [rsp+0xD0]
000076b67a9ddb01  vmovaps xmm15, [rsp+0xE0]
000076b67a9ddb0a  add rsp, 0xF0
000076b67a9ddb11  pop r11
000076b67a9ddb13  pop r10
000076b67a9ddb15  pop r9
000076b67a9ddb17  pop r8
000076b67a9ddb19  pop rsi
000076b67a9ddb1a  pop rdi
000076b67a9ddb1b  pop rdx
000076b67a9ddb1c  pop rcx
000076b67a9ddb1d  pop rax
000076b67a9ddb1e  add rsp, 0x08
000076b67a9ddb22  jmp 0x000076B67A9DBEAC
000076b67a9ddb27  call 0x000076B67A8C4620
000076b67a9ddb2c  jmp 0x000076B67A9DBEB9
000076b67a9ddb31  sub rsp, 0x08
000076b67a9ddb35  push rax
000076b67a9ddb36  push rcx
000076b67a9ddb37  push rdx
000076b67a9ddb38  push rdi
000076b67a9ddb39  push rsi
000076b67a9ddb3a  push r8
000076b67a9ddb3c  push r9
000076b67a9ddb3e  push r10
000076b67a9ddb40  push r11
000076b67a9ddb42  sub rsp, 0xF0
000076b67a9ddb49  vmovaps [rsp], xmm0
000076b67a9ddb4e  vmovaps [rsp+0x10], xmm1
000076b67a9ddb54  vmovaps [rsp+0x20], xmm2
000076b67a9ddb5a  vmovaps [rsp+0x30], xmm4
000076b67a9ddb60  vmovaps [rsp+0x40], xmm5
000076b67a9ddb66  vmovaps [rsp+0x50], xmm6
000076b67a9ddb6c  vmovaps [rsp+0x60], xmm7
000076b67a9ddb72  vmovaps [rsp+0x70], xmm8
000076b67a9ddb78  vmovaps [rsp+0x80], xmm9
000076b67a9ddb81  vmovaps [rsp+0x90], xmm10
000076b67a9ddb8a  vmovaps [rsp+0xA0], xmm11
000076b67a9ddb93  vmovaps [rsp+0xB0], xmm12
000076b67a9ddb9c  vmovaps [rsp+0xC0], xmm13
000076b67a9ddba5  vmovaps [rsp+0xD0], xmm14
000076b67a9ddbae  vmovaps [rsp+0xE0], xmm15
000076b67a9ddbb7  sub rsp, 0x30
000076b67a9ddbbb  movaps [rsp], xmm3
000076b67a9ddbbf  movaps [rsp+0x10], xmm1
000076b67a9ddbc4  movaps [rsp+0x20], xmm9
000076b67a9ddbca  lea rdi, [rsp]
000076b67a9ddbce  mov esi, 0x00
000076b67a9ddbd3  mov rax, 0x63C5EF2DF530
000076b67a9ddbdd  call rax
000076b67a9ddbdf  movaps xmm3, [rsp]
000076b67a9ddbe3  add rsp, 0x30
000076b67a9ddbe7  vmovaps xmm0, [rsp]
000076b67a9ddbec  vmovaps xmm1, [rsp+0x10]
000076b67a9ddbf2  vmovaps xmm2, [rsp+0x20]
000076b67a9ddbf8  vmovaps xmm4, [rsp+0x30]
000076b67a9ddbfe  vmovaps xmm5, [rsp+0x40]
000076b67a9ddc04  vmovaps xmm6, [rsp+0x50]
000076b67a9ddc0a  vmovaps xmm7, [rsp+0x60]
000076b67a9ddc10  vmovaps xmm8, [rsp+0x70]
000076b67a9ddc16  vmovaps xmm9, [rsp+0x80]
000076b67a9ddc1f  vmovaps xmm10, [rsp+0x90]
000076b67a9ddc28  vmovaps xmm11, [rsp+0xA0]
000076b67a9ddc31  vmovaps xmm12, [rsp+0xB0]
000076b67a9ddc3a  vmovaps xmm13, [rsp+0xC0]
000076b67a9ddc43  vmovaps xmm14, [rsp+0xD0]
000076b67a9ddc4c  vmovaps xmm15, [rsp+0xE0]
000076b67a9ddc55  add rsp, 0xF0
000076b67a9ddc5c  pop r11
000076b67a9ddc5e  pop r10
000076b67a9ddc60  pop r9
000076b67a9ddc62  pop r8
000076b67a9ddc64  pop rsi
000076b67a9ddc65  pop rdi
000076b67a9ddc66  pop rdx
000076b67a9ddc67  pop rcx
000076b67a9ddc68  pop rax
000076b67a9ddc69  add rsp, 0x08
000076b67a9ddc6d  jmp 0x000076B67A9DBEF6
000076b67a9ddc72  sub rsp, 0x08
000076b67a9ddc76  push rax
000076b67a9ddc77  push rcx
000076b67a9ddc78  push rdx
000076b67a9ddc79  push rdi
000076b67a9ddc7a  push rsi
000076b67a9ddc7b  push r8
000076b67a9ddc7d  push r9
000076b67a9ddc7f  push r10
000076b67a9ddc81  push r11
000076b67a9ddc83  sub rsp, 0xF0
000076b67a9ddc8a  vmovaps [rsp], xmm0
000076b67a9ddc8f  vmovaps [rsp+0x10], xmm2
000076b67a9ddc95  vmovaps [rsp+0x20], xmm3
000076b67a9ddc9b  vmovaps [rsp+0x30], xmm4
000076b67a9ddca1  vmovaps [rsp+0x40], xmm5
000076b67a9ddca7  vmovaps [rsp+0x50], xmm6
000076b67a9ddcad  vmovaps [rsp+0x60], xmm7
000076b67a9ddcb3  vmovaps [rsp+0x70], xmm8
000076b67a9ddcb9  vmovaps [rsp+0x80], xmm9
000076b67a9ddcc2  vmovaps [rsp+0x90], xmm10
000076b67a9ddccb  vmovaps [rsp+0xA0], xmm11
000076b67a9ddcd4  vmovaps [rsp+0xB0], xmm12
000076b67a9ddcdd  vmovaps [rsp+0xC0], xmm13
000076b67a9ddce6  vmovaps [rsp+0xD0], xmm14
000076b67a9ddcef  vmovaps [rsp+0xE0], xmm15
000076b67a9ddcf8  sub rsp, 0x30
000076b67a9ddcfc  movaps [rsp], xmm1
000076b67a9ddd00  movaps [rsp+0x10], xmm15
000076b67a9ddd06  movaps [rsp+0x20], xmm9
000076b67a9ddd0c  lea rdi, [rsp]
000076b67a9ddd10  mov esi, 0x00
000076b67a9ddd15  mov rax, 0x63C5EF2DF530
000076b67a9ddd1f  call rax
000076b67a9ddd21  movaps xmm1, [rsp]
000076b67a9ddd25  add rsp, 0x30
000076b67a9ddd29  vmovaps xmm0, [rsp]
000076b67a9ddd2e  vmovaps xmm2, [rsp+0x10]
000076b67a9ddd34  vmovaps xmm3, [rsp+0x20]
000076b67a9ddd3a  vmovaps xmm4, [rsp+0x30]
000076b67a9ddd40  vmovaps xmm5, [rsp+0x40]
000076b67a9ddd46  vmovaps xmm6, [rsp+0x50]
000076b67a9ddd4c  vmovaps xmm7, [rsp+0x60]
000076b67a9ddd52  vmovaps xmm8, [rsp+0x70]
000076b67a9ddd58  vmovaps xmm9, [rsp+0x80]
000076b67a9ddd61  vmovaps xmm10, [rsp+0x90]
000076b67a9ddd6a  vmovaps xmm11, [rsp+0xA0]
000076b67a9ddd73  vmovaps xmm12, [rsp+0xB0]
000076b67a9ddd7c  vmovaps xmm13, [rsp+0xC0]
000076b67a9ddd85  vmovaps xmm14, [rsp+0xD0]
000076b67a9ddd8e  vmovaps xmm15, [rsp+0xE0]
000076b67a9ddd97  add rsp, 0xF0
000076b67a9ddd9e  pop r11
000076b67a9ddda0  pop r10
000076b67a9ddda2  pop r9
000076b67a9ddda4  pop r8
000076b67a9ddda6  pop rsi
000076b67a9ddda7  pop rdi
000076b67a9ddda8  pop rdx
000076b67a9ddda9  pop rcx
000076b67a9dddaa  pop rax
000076b67a9dddab  add rsp, 0x08
000076b67a9dddaf  jmp 0x000076B67A9DBF7E
000076b67a9dddb4  call 0x000076B67A8C4620
000076b67a9dddb9  jmp 0x000076B67A9DBF8B
000076b67a9dddbe  sub rsp, 0x08
000076b67a9dddc2  push rax
000076b67a9dddc3  push rcx
000076b67a9dddc4  push rdx
000076b67a9dddc5  push rdi
000076b67a9dddc6  push rsi
000076b67a9dddc7  push r8
000076b67a9dddc9  push r9
000076b67a9dddcb  push r10
000076b67a9dddcd  push r11
000076b67a9dddcf  sub rsp, 0xF0
000076b67a9dddd6  vmovaps [rsp], xmm0
000076b67a9ddddb  vmovaps [rsp+0x10], xmm2
000076b67a9ddde1  vmovaps [rsp+0x20], xmm3
000076b67a9ddde7  vmovaps [rsp+0x30], xmm4
000076b67a9ddded  vmovaps [rsp+0x40], xmm5
000076b67a9dddf3  vmovaps [rsp+0x50], xmm6
000076b67a9dddf9  vmovaps [rsp+0x60], xmm7
000076b67a9dddff  vmovaps [rsp+0x70], xmm8
000076b67a9dde05  vmovaps [rsp+0x80], xmm9
000076b67a9dde0e  vmovaps [rsp+0x90], xmm10
000076b67a9dde17  vmovaps [rsp+0xA0], xmm11
000076b67a9dde20  vmovaps [rsp+0xB0], xmm12
000076b67a9dde29  vmovaps [rsp+0xC0], xmm13
000076b67a9dde32  vmovaps [rsp+0xD0], xmm14
000076b67a9dde3b  vmovaps [rsp+0xE0], xmm15
000076b67a9dde44  sub rsp, 0x30
000076b67a9dde48  movaps [rsp], xmm1
000076b67a9dde4c  movaps [rsp+0x10], xmm5
000076b67a9dde51  movaps [rsp+0x20], xmm7
000076b67a9dde56  lea rdi, [rsp]
000076b67a9dde5a  mov esi, 0x00
000076b67a9dde5f  mov rax, 0x63C5EF2DF530
000076b67a9dde69  call rax
000076b67a9dde6b  movaps xmm1, [rsp]
000076b67a9dde6f  add rsp, 0x30
000076b67a9dde73  vmovaps xmm0, [rsp]
000076b67a9dde78  vmovaps xmm2, [rsp+0x10]
000076b67a9dde7e  vmovaps xmm3, [rsp+0x20]
000076b67a9dde84  vmovaps xmm4, [rsp+0x30]
000076b67a9dde8a  vmovaps xmm5, [rsp+0x40]
000076b67a9dde90  vmovaps xmm6, [rsp+0x50]
000076b67a9dde96  vmovaps xmm7, [rsp+0x60]
000076b67a9dde9c  vmovaps xmm8, [rsp+0x70]
000076b67a9ddea2  vmovaps xmm9, [rsp+0x80]
000076b67a9ddeab  vmovaps xmm10, [rsp+0x90]
000076b67a9ddeb4  vmovaps xmm11, [rsp+0xA0]
000076b67a9ddebd  vmovaps xmm12, [rsp+0xB0]
000076b67a9ddec6  vmovaps xmm13, [rsp+0xC0]
000076b67a9ddecf  vmovaps xmm14, [rsp+0xD0]
000076b67a9dded8  vmovaps xmm15, [rsp+0xE0]
000076b67a9ddee1  add rsp, 0xF0
000076b67a9ddee8  pop r11
000076b67a9ddeea  pop r10
000076b67a9ddeec  pop r9
000076b67a9ddeee  pop r8
000076b67a9ddef0  pop rsi
000076b67a9ddef1  pop rdi
000076b67a9ddef2  pop rdx
000076b67a9ddef3  pop rcx
000076b67a9ddef4  pop rax
000076b67a9ddef5  add rsp, 0x08
000076b67a9ddef9  jmp 0x000076B67A9DC030
000076b67a9ddefe  sub rsp, 0x08
000076b67a9ddf02  push rax
000076b67a9ddf03  push rcx
000076b67a9ddf04  push rdx
000076b67a9ddf05  push rdi
000076b67a9ddf06  push rsi
000076b67a9ddf07  push r8
000076b67a9ddf09  push r9
000076b67a9ddf0b  push r10
000076b67a9ddf0d  push r11
000076b67a9ddf0f  sub rsp, 0xF0
000076b67a9ddf16  vmovaps [rsp], xmm0
000076b67a9ddf1b  vmovaps [rsp+0x10], xmm1
000076b67a9ddf21  vmovaps [rsp+0x20], xmm2
000076b67a9ddf27  vmovaps [rsp+0x30], xmm3
000076b67a9ddf2d  vmovaps [rsp+0x40], xmm4
000076b67a9ddf33  vmovaps [rsp+0x50], xmm5
000076b67a9ddf39  vmovaps [rsp+0x60], xmm6
000076b67a9ddf3f  vmovaps [rsp+0x70], xmm8
000076b67a9ddf45  vmovaps [rsp+0x80], xmm9
000076b67a9ddf4e  vmovaps [rsp+0x90], xmm10
000076b67a9ddf57  vmovaps [rsp+0xA0], xmm11
000076b67a9ddf60  vmovaps [rsp+0xB0], xmm12
000076b67a9ddf69  vmovaps [rsp+0xC0], xmm13
000076b67a9ddf72  vmovaps [rsp+0xD0], xmm14
000076b67a9ddf7b  vmovaps [rsp+0xE0], xmm15
000076b67a9ddf84  sub rsp, 0x30
000076b67a9ddf88  movaps [rsp], xmm7
000076b67a9ddf8c  movaps [rsp+0x10], xmm5
000076b67a9ddf91  movaps [rsp+0x20], xmm15
000076b67a9ddf97  lea rdi, [rsp]
000076b67a9ddf9b  mov esi, 0x00
000076b67a9ddfa0  mov rax, 0x63C5EF2DF530
000076b67a9ddfaa  call rax
000076b67a9ddfac  movaps xmm7, [rsp]
000076b67a9ddfb0  add rsp, 0x30
000076b67a9ddfb4  vmovaps xmm0, [rsp]
000076b67a9ddfb9  vmovaps xmm1, [rsp+0x10]
000076b67a9ddfbf  vmovaps xmm2, [rsp+0x20]
000076b67a9ddfc5  vmovaps xmm3, [rsp+0x30]
000076b67a9ddfcb  vmovaps xmm4, [rsp+0x40]
000076b67a9ddfd1  vmovaps xmm5, [rsp+0x50]
000076b67a9ddfd7  vmovaps xmm6, [rsp+0x60]
000076b67a9ddfdd  vmovaps xmm8, [rsp+0x70]
000076b67a9ddfe3  vmovaps xmm9, [rsp+0x80]
000076b67a9ddfec  vmovaps xmm10, [rsp+0x90]
000076b67a9ddff5  vmovaps xmm11, [rsp+0xA0]
000076b67a9ddffe  vmovaps xmm12, [rsp+0xB0]
000076b67a9de007  vmovaps xmm13, [rsp+0xC0]
000076b67a9de010  vmovaps xmm14, [rsp+0xD0]
000076b67a9de019  vmovaps xmm15, [rsp+0xE0]
000076b67a9de022  add rsp, 0xF0
000076b67a9de029  pop r11
000076b67a9de02b  pop r10
000076b67a9de02d  pop r9
000076b67a9de02f  pop r8
000076b67a9de031  pop rsi
000076b67a9de032  pop rdi
000076b67a9de033  pop rdx
000076b67a9de034  pop rcx
000076b67a9de035  pop rax
000076b67a9de036  add rsp, 0x08
000076b67a9de03a  jmp 0x000076B67A9DC066
000076b67a9de03f  call 0x000076B67A8B52F0
000076b67a9de044  jmp 0x000076B67A9DC073
000076b67a9de049  sub rsp, 0x08
000076b67a9de04d  push rax
000076b67a9de04e  push rcx
000076b67a9de04f  push rdx
000076b67a9de050  push rdi
000076b67a9de051  push rsi
000076b67a9de052  push r8
000076b67a9de054  push r9
000076b67a9de056  push r10
000076b67a9de058  push r11
000076b67a9de05a  sub rsp, 0xF0
000076b67a9de061  vmovaps [rsp], xmm0
000076b67a9de066  vmovaps [rsp+0x10], xmm1
000076b67a9de06c  vmovaps [rsp+0x20], xmm2
000076b67a9de072  vmovaps [rsp+0x30], xmm3
000076b67a9de078  vmovaps [rsp+0x40], xmm4
000076b67a9de07e  vmovaps [rsp+0x50], xmm5
000076b67a9de084  vmovaps [rsp+0x60], xmm6
000076b67a9de08a  vmovaps [rsp+0x70], xmm7
000076b67a9de090  vmovaps [rsp+0x80], xmm8
000076b67a9de099  vmovaps [rsp+0x90], xmm9
000076b67a9de0a2  vmovaps [rsp+0xA0], xmm10
000076b67a9de0ab  vmovaps [rsp+0xB0], xmm11
000076b67a9de0b4  vmovaps [rsp+0xC0], xmm12
000076b67a9de0bd  vmovaps [rsp+0xD0], xmm13
000076b67a9de0c6  vmovaps [rsp+0xE0], xmm14
000076b67a9de0cf  sub rsp, 0x30
000076b67a9de0d3  movaps [rsp], xmm15
000076b67a9de0d8  movaps [rsp+0x10], xmm5
000076b67a9de0dd  movaps [rsp+0x20], xmm3
000076b67a9de0e2  lea rdi, [rsp]
000076b67a9de0e6  mov esi, 0x00
000076b67a9de0eb  mov rax, 0x63C5EF2DF530
000076b67a9de0f5  call rax
000076b67a9de0f7  movaps xmm15, [rsp]
000076b67a9de0fc  add rsp, 0x30
000076b67a9de100  vmovaps xmm0, [rsp]
000076b67a9de105  vmovaps xmm1, [rsp+0x10]
000076b67a9de10b  vmovaps xmm2, [rsp+0x20]
000076b67a9de111  vmovaps xmm3, [rsp+0x30]
000076b67a9de117  vmovaps xmm4, [rsp+0x40]
000076b67a9de11d  vmovaps xmm5, [rsp+0x50]
000076b67a9de123  vmovaps xmm6, [rsp+0x60]
000076b67a9de129  vmovaps xmm7, [rsp+0x70]
000076b67a9de12f  vmovaps xmm8, [rsp+0x80]
000076b67a9de138  vmovaps xmm9, [rsp+0x90]
000076b67a9de141  vmovaps xmm10, [rsp+0xA0]
000076b67a9de14a  vmovaps xmm11, [rsp+0xB0]
000076b67a9de153  vmovaps xmm12, [rsp+0xC0]
000076b67a9de15c  vmovaps xmm13, [rsp+0xD0]
000076b67a9de165  vmovaps xmm14, [rsp+0xE0]
000076b67a9de16e  add rsp, 0xF0
000076b67a9de175  pop r11
000076b67a9de177  pop r10
000076b67a9de179  pop r9
000076b67a9de17b  pop r8
000076b67a9de17d  pop rsi
000076b67a9de17e  pop rdi
000076b67a9de17f  pop rdx
000076b67a9de180  pop rcx
000076b67a9de181  pop rax
000076b67a9de182  add rsp, 0x08
000076b67a9de186  jmp 0x000076B67A9DC099
000076b67a9de18b  sub rsp, 0x08
000076b67a9de18f  push rax
000076b67a9de190  push rcx
000076b67a9de191  push rdx
000076b67a9de192  push rdi
000076b67a9de193  push rsi
000076b67a9de194  push r8
000076b67a9de196  push r9
000076b67a9de198  push r10
000076b67a9de19a  push r11
000076b67a9de19c  sub rsp, 0xF0
000076b67a9de1a3  vmovaps [rsp], xmm0
000076b67a9de1a8  vmovaps [rsp+0x10], xmm2
000076b67a9de1ae  vmovaps [rsp+0x20], xmm3
000076b67a9de1b4  vmovaps [rsp+0x30], xmm4
000076b67a9de1ba  vmovaps [rsp+0x40], xmm5
000076b67a9de1c0  vmovaps [rsp+0x50], xmm6
000076b67a9de1c6  vmovaps [rsp+0x60], xmm7
000076b67a9de1cc  vmovaps [rsp+0x70], xmm8
000076b67a9de1d2  vmovaps [rsp+0x80], xmm9
000076b67a9de1db  vmovaps [rsp+0x90], xmm10
000076b67a9de1e4  vmovaps [rsp+0xA0], xmm11
000076b67a9de1ed  vmovaps [rsp+0xB0], xmm12
000076b67a9de1f6  vmovaps [rsp+0xC0], xmm13
000076b67a9de1ff  vmovaps [rsp+0xD0], xmm14
000076b67a9de208  vmovaps [rsp+0xE0], xmm15
000076b67a9de211  sub rsp, 0x30
000076b67a9de215  movaps [rsp], xmm1
000076b67a9de219  movaps [rsp+0x10], xmm5
000076b67a9de21e  movaps [rsp+0x20], xmm4
000076b67a9de223  lea rdi, [rsp]
000076b67a9de227  mov esi, 0x00
000076b67a9de22c  mov rax, 0x63C5EF2DF530
000076b67a9de236  call rax
000076b67a9de238  movaps xmm1, [rsp]
000076b67a9de23c  add rsp, 0x30
000076b67a9de240  vmovaps xmm0, [rsp]
000076b67a9de245  vmovaps xmm2, [rsp+0x10]
000076b67a9de24b  vmovaps xmm3, [rsp+0x20]
000076b67a9de251  vmovaps xmm4, [rsp+0x30]
000076b67a9de257  vmovaps xmm5, [rsp+0x40]
000076b67a9de25d  vmovaps xmm6, [rsp+0x50]
000076b67a9de263  vmovaps xmm7, [rsp+0x60]
000076b67a9de269  vmovaps xmm8, [rsp+0x70]
000076b67a9de26f  vmovaps xmm9, [rsp+0x80]
000076b67a9de278  vmovaps xmm10, [rsp+0x90]
000076b67a9de281  vmovaps xmm11, [rsp+0xA0]
000076b67a9de28a  vmovaps xmm12, [rsp+0xB0]
000076b67a9de293  vmovaps xmm13, [rsp+0xC0]
000076b67a9de29c  vmovaps xmm14, [rsp+0xD0]
000076b67a9de2a5  vmovaps xmm15, [rsp+0xE0]
000076b67a9de2ae  add rsp, 0xF0
000076b67a9de2b5  pop r11
000076b67a9de2b7  pop r10
000076b67a9de2b9  pop r9
000076b67a9de2bb  pop r8
000076b67a9de2bd  pop rsi
000076b67a9de2be  pop rdi
000076b67a9de2bf  pop rdx
000076b67a9de2c0  pop rcx
000076b67a9de2c1  pop rax
000076b67a9de2c2  add rsp, 0x08
000076b67a9de2c6  jmp 0x000076B67A9DC0B9
000076b67a9de2cb  sub rsp, 0x08
000076b67a9de2cf  push rax
000076b67a9de2d0  push rcx
000076b67a9de2d1  push rdx
000076b67a9de2d2  push rdi
000076b67a9de2d3  push rsi
000076b67a9de2d4  push r8
000076b67a9de2d6  push r9
000076b67a9de2d8  push r10
000076b67a9de2da  push r11
000076b67a9de2dc  sub rsp, 0xF0
000076b67a9de2e3  vmovaps [rsp], xmm0
000076b67a9de2e8  vmovaps [rsp+0x10], xmm1
000076b67a9de2ee  vmovaps [rsp+0x20], xmm2
000076b67a9de2f4  vmovaps [rsp+0x30], xmm3
000076b67a9de2fa  vmovaps [rsp+0x40], xmm5
000076b67a9de300  vmovaps [rsp+0x50], xmm6
000076b67a9de306  vmovaps [rsp+0x60], xmm7
000076b67a9de30c  vmovaps [rsp+0x70], xmm8
000076b67a9de312  vmovaps [rsp+0x80], xmm9
000076b67a9de31b  vmovaps [rsp+0x90], xmm10
000076b67a9de324  vmovaps [rsp+0xA0], xmm11
000076b67a9de32d  vmovaps [rsp+0xB0], xmm12
000076b67a9de336  vmovaps [rsp+0xC0], xmm13
000076b67a9de33f  vmovaps [rsp+0xD0], xmm14
000076b67a9de348  vmovaps [rsp+0xE0], xmm15
000076b67a9de351  sub rsp, 0x30
000076b67a9de355  movaps [rsp], xmm4
000076b67a9de359  movaps [rsp+0x10], xmm3
000076b67a9de35e  movaps [rsp+0x20], xmm5
000076b67a9de363  lea rdi, [rsp]
000076b67a9de367  mov esi, 0x00
000076b67a9de36c  mov rax, 0x63C5EF2DF530
000076b67a9de376  call rax
000076b67a9de378  movaps xmm4, [rsp]
000076b67a9de37c  add rsp, 0x30
000076b67a9de380  vmovaps xmm0, [rsp]
000076b67a9de385  vmovaps xmm1, [rsp+0x10]
000076b67a9de38b  vmovaps xmm2, [rsp+0x20]
000076b67a9de391  vmovaps xmm3, [rsp+0x30]
000076b67a9de397  vmovaps xmm5, [rsp+0x40]
000076b67a9de39d  vmovaps xmm6, [rsp+0x50]
000076b67a9de3a3  vmovaps xmm7, [rsp+0x60]
000076b67a9de3a9  vmovaps xmm8, [rsp+0x70]
000076b67a9de3af  vmovaps xmm9, [rsp+0x80]
000076b67a9de3b8  vmovaps xmm10, [rsp+0x90]
000076b67a9de3c1  vmovaps xmm11, [rsp+0xA0]
000076b67a9de3ca  vmovaps xmm12, [rsp+0xB0]
000076b67a9de3d3  vmovaps xmm13, [rsp+0xC0]
000076b67a9de3dc  vmovaps xmm14, [rsp+0xD0]
000076b67a9de3e5  vmovaps xmm15, [rsp+0xE0]
000076b67a9de3ee  add rsp, 0xF0
000076b67a9de3f5  pop r11
000076b67a9de3f7  pop r10
000076b67a9de3f9  pop r9
000076b67a9de3fb  pop r8
000076b67a9de3fd  pop rsi
000076b67a9de3fe  pop rdi
000076b67a9de3ff  pop rdx
000076b67a9de400  pop rcx
000076b67a9de401  pop rax
000076b67a9de402  add rsp, 0x08
000076b67a9de406  jmp 0x000076B67A9DC107
000076b67a9de40b  call 0x000076B67A8B52F0
000076b67a9de410  jmp 0x000076B67A9DC114
000076b67a9de415  sub rsp, 0x08
000076b67a9de419  push rax
000076b67a9de41a  push rcx
000076b67a9de41b  push rdx
000076b67a9de41c  push rdi
000076b67a9de41d  push rsi
000076b67a9de41e  push r8
000076b67a9de420  push r9
000076b67a9de422  push r10
000076b67a9de424  push r11
000076b67a9de426  sub rsp, 0xF0
000076b67a9de42d  vmovaps [rsp], xmm0
000076b67a9de432  vmovaps [rsp+0x10], xmm1
000076b67a9de438  vmovaps [rsp+0x20], xmm2
000076b67a9de43e  vmovaps [rsp+0x30], xmm3
000076b67a9de444  vmovaps [rsp+0x40], xmm4
000076b67a9de44a  vmovaps [rsp+0x50], xmm6
000076b67a9de450  vmovaps [rsp+0x60], xmm7
000076b67a9de456  vmovaps [rsp+0x70], xmm8
000076b67a9de45c  vmovaps [rsp+0x80], xmm9
000076b67a9de465  vmovaps [rsp+0x90], xmm10
000076b67a9de46e  vmovaps [rsp+0xA0], xmm11
000076b67a9de477  vmovaps [rsp+0xB0], xmm12
000076b67a9de480  vmovaps [rsp+0xC0], xmm13
000076b67a9de489  vmovaps [rsp+0xD0], xmm14
000076b67a9de492  vmovaps [rsp+0xE0], xmm15
000076b67a9de49b  sub rsp, 0x30
000076b67a9de49f  movaps [rsp], xmm5
000076b67a9de4a3  movaps [rsp+0x10], xmm6
000076b67a9de4a8  movaps [rsp+0x20], xmm3
000076b67a9de4ad  lea rdi, [rsp]
000076b67a9de4b1  mov esi, 0x00
000076b67a9de4b6  mov rax, 0x63C5EF2DF530
000076b67a9de4c0  call rax
000076b67a9de4c2  movaps xmm5, [rsp]
000076b67a9de4c6  add rsp, 0x30
000076b67a9de4ca  vmovaps xmm0, [rsp]
000076b67a9de4cf  vmovaps xmm1, [rsp+0x10]
000076b67a9de4d5  vmovaps xmm2, [rsp+0x20]
000076b67a9de4db  vmovaps xmm3, [rsp+0x30]
000076b67a9de4e1  vmovaps xmm4, [rsp+0x40]
000076b67a9de4e7  vmovaps xmm6, [rsp+0x50]
000076b67a9de4ed  vmovaps xmm7, [rsp+0x60]
000076b67a9de4f3  vmovaps xmm8, [rsp+0x70]
000076b67a9de4f9  vmovaps xmm9, [rsp+0x80]
000076b67a9de502  vmovaps xmm10, [rsp+0x90]
000076b67a9de50b  vmovaps xmm11, [rsp+0xA0]
000076b67a9de514  vmovaps xmm12, [rsp+0xB0]
000076b67a9de51d  vmovaps xmm13, [rsp+0xC0]
000076b67a9de526  vmovaps xmm14, [rsp+0xD0]
000076b67a9de52f  vmovaps xmm15, [rsp+0xE0]
000076b67a9de538  add rsp, 0xF0
000076b67a9de53f  pop r11
000076b67a9de541  pop r10
000076b67a9de543  pop r9
000076b67a9de545  pop r8
000076b67a9de547  pop rsi
000076b67a9de548  pop rdi
000076b67a9de549  pop rdx
000076b67a9de54a  pop rcx
000076b67a9de54b  pop rax
000076b67a9de54c  add rsp, 0x08
000076b67a9de550  jmp 0x000076B67A9DC13A
000076b67a9de555  sub rsp, 0x08
000076b67a9de559  push rax
000076b67a9de55a  push rcx
000076b67a9de55b  push rdx
000076b67a9de55c  push rdi
000076b67a9de55d  push rsi
000076b67a9de55e  push r8
000076b67a9de560  push r9
000076b67a9de562  push r10
000076b67a9de564  push r11
000076b67a9de566  sub rsp, 0xF0
000076b67a9de56d  vmovaps [rsp], xmm0
000076b67a9de572  vmovaps [rsp+0x10], xmm1
000076b67a9de578  vmovaps [rsp+0x20], xmm2
000076b67a9de57e  vmovaps [rsp+0x30], xmm3
000076b67a9de584  vmovaps [rsp+0x40], xmm4
000076b67a9de58a  vmovaps [rsp+0x50], xmm5
000076b67a9de590  vmovaps [rsp+0x60], xmm7
000076b67a9de596  vmovaps [rsp+0x70], xmm8
000076b67a9de59c  vmovaps [rsp+0x80], xmm9
000076b67a9de5a5  vmovaps [rsp+0x90], xmm10
000076b67a9de5ae  vmovaps [rsp+0xA0], xmm11
000076b67a9de5b7  vmovaps [rsp+0xB0], xmm12
000076b67a9de5c0  vmovaps [rsp+0xC0], xmm13
000076b67a9de5c9  vmovaps [rsp+0xD0], xmm14
000076b67a9de5d2  vmovaps [rsp+0xE0], xmm15
000076b67a9de5db  sub rsp, 0x30
000076b67a9de5df  movaps [rsp], xmm6
000076b67a9de5e3  movaps [rsp+0x10], xmm9
000076b67a9de5e9  movaps [rsp+0x20], xmm1
000076b67a9de5ee  lea rdi, [rsp]
000076b67a9de5f2  mov esi, 0x00
000076b67a9de5f7  mov rax, 0x63C5EF2DF530
000076b67a9de601  call rax
000076b67a9de603  movaps xmm6, [rsp]
000076b67a9de607  add rsp, 0x30
000076b67a9de60b  vmovaps xmm0, [rsp]
000076b67a9de610  vmovaps xmm1, [rsp+0x10]
000076b67a9de616  vmovaps xmm2, [rsp+0x20]
000076b67a9de61c  vmovaps xmm3, [rsp+0x30]
000076b67a9de622  vmovaps xmm4, [rsp+0x40]
000076b67a9de628  vmovaps xmm5, [rsp+0x50]
000076b67a9de62e  vmovaps xmm7, [rsp+0x60]
000076b67a9de634  vmovaps xmm8, [rsp+0x70]
000076b67a9de63a  vmovaps xmm9, [rsp+0x80]
000076b67a9de643  vmovaps xmm10, [rsp+0x90]
000076b67a9de64c  vmovaps xmm11, [rsp+0xA0]
000076b67a9de655  vmovaps xmm12, [rsp+0xB0]
000076b67a9de65e  vmovaps xmm13, [rsp+0xC0]
000076b67a9de667  vmovaps xmm14, [rsp+0xD0]
000076b67a9de670  vmovaps xmm15, [rsp+0xE0]
000076b67a9de679  add rsp, 0xF0
000076b67a9de680  pop r11
000076b67a9de682  pop r10
000076b67a9de684  pop r9
000076b67a9de686  pop r8
000076b67a9de688  pop rsi
000076b67a9de689  pop rdi
000076b67a9de68a  pop rdx
000076b67a9de68b  pop rcx
000076b67a9de68c  pop rax
000076b67a9de68d  add rsp, 0x08
000076b67a9de691  jmp 0x000076B67A9DC15E
000076b67a9de696  sub rsp, 0x08
000076b67a9de69a  push rax
000076b67a9de69b  push rcx
000076b67a9de69c  push rdx
000076b67a9de69d  push rdi
000076b67a9de69e  push rsi
000076b67a9de69f  push r8
000076b67a9de6a1  push r9
000076b67a9de6a3  push r10
000076b67a9de6a5  push r11
000076b67a9de6a7  sub rsp, 0xF0
000076b67a9de6ae  vmovaps [rsp], xmm0
000076b67a9de6b3  vmovaps [rsp+0x10], xmm1
000076b67a9de6b9  vmovaps [rsp+0x20], xmm2
000076b67a9de6bf  vmovaps [rsp+0x30], xmm3
000076b67a9de6c5  vmovaps [rsp+0x40], xmm4
000076b67a9de6cb  vmovaps [rsp+0x50], xmm5
000076b67a9de6d1  vmovaps [rsp+0x60], xmm6
000076b67a9de6d7  vmovaps [rsp+0x70], xmm7
000076b67a9de6dd  vmovaps [rsp+0x80], xmm8
000076b67a9de6e6  vmovaps [rsp+0x90], xmm10
000076b67a9de6ef  vmovaps [rsp+0xA0], xmm11
000076b67a9de6f8  vmovaps [rsp+0xB0], xmm12
000076b67a9de701  vmovaps [rsp+0xC0], xmm13
000076b67a9de70a  vmovaps [rsp+0xD0], xmm14
000076b67a9de713  vmovaps [rsp+0xE0], xmm15
000076b67a9de71c  sub rsp, 0x30
000076b67a9de720  movaps [rsp], xmm9
000076b67a9de725  movaps [rsp+0x10], xmm3
000076b67a9de72a  movaps [rsp+0x20], xmm1
000076b67a9de72f  lea rdi, [rsp]
000076b67a9de733  mov esi, 0x00
000076b67a9de738  mov rax, 0x63C5EF2DF530
000076b67a9de742  call rax
000076b67a9de744  movaps xmm9, [rsp]
000076b67a9de749  add rsp, 0x30
000076b67a9de74d  vmovaps xmm0, [rsp]
000076b67a9de752  vmovaps xmm1, [rsp+0x10]
000076b67a9de758  vmovaps xmm2, [rsp+0x20]
000076b67a9de75e  vmovaps xmm3, [rsp+0x30]
000076b67a9de764  vmovaps xmm4, [rsp+0x40]
000076b67a9de76a  vmovaps xmm5, [rsp+0x50]
000076b67a9de770  vmovaps xmm6, [rsp+0x60]
000076b67a9de776  vmovaps xmm7, [rsp+0x70]
000076b67a9de77c  vmovaps xmm8, [rsp+0x80]
000076b67a9de785  vmovaps xmm10, [rsp+0x90]
000076b67a9de78e  vmovaps xmm11, [rsp+0xA0]
000076b67a9de797  vmovaps xmm12, [rsp+0xB0]
000076b67a9de7a0  vmovaps xmm13, [rsp+0xC0]
000076b67a9de7a9  vmovaps xmm14, [rsp+0xD0]
000076b67a9de7b2  vmovaps xmm15, [rsp+0xE0]
000076b67a9de7bb  add rsp, 0xF0
000076b67a9de7c2  pop r11
000076b67a9de7c4  pop r10
000076b67a9de7c6  pop r9
000076b67a9de7c8  pop r8
000076b67a9de7ca  pop rsi
000076b67a9de7cb  pop rdi
000076b67a9de7cc  pop rdx
000076b67a9de7cd  pop rcx
000076b67a9de7ce  pop rax
000076b67a9de7cf  add rsp, 0x08
000076b67a9de7d3  jmp 0x000076B67A9DC1AA
000076b67a9de7d8  call 0x000076B67A8B52F0
000076b67a9de7dd  jmp 0x000076B67A9DC1B7
000076b67a9de7e2  sub rsp, 0x08
000076b67a9de7e6  push rax
000076b67a9de7e7  push rcx
000076b67a9de7e8  push rdx
000076b67a9de7e9  push rdi
000076b67a9de7ea  push rsi
000076b67a9de7eb  push r8
000076b67a9de7ed  push r9
000076b67a9de7ef  push r10
000076b67a9de7f1  push r11
000076b67a9de7f3  sub rsp, 0xF0
000076b67a9de7fa  vmovaps [rsp], xmm0
000076b67a9de7ff  vmovaps [rsp+0x10], xmm1
000076b67a9de805  vmovaps [rsp+0x20], xmm2
000076b67a9de80b  vmovaps [rsp+0x30], xmm3
000076b67a9de811  vmovaps [rsp+0x40], xmm4
000076b67a9de817  vmovaps [rsp+0x50], xmm5
000076b67a9de81d  vmovaps [rsp+0x60], xmm6
000076b67a9de823  vmovaps [rsp+0x70], xmm7
000076b67a9de829  vmovaps [rsp+0x80], xmm8
000076b67a9de832  vmovaps [rsp+0x90], xmm9
000076b67a9de83b  vmovaps [rsp+0xA0], xmm10
000076b67a9de844  vmovaps [rsp+0xB0], xmm11
000076b67a9de84d  vmovaps [rsp+0xC0], xmm12
000076b67a9de856  vmovaps [rsp+0xD0], xmm13
000076b67a9de85f  vmovaps [rsp+0xE0], xmm14
000076b67a9de868  sub rsp, 0x30
000076b67a9de86c  movaps [rsp], xmm15
000076b67a9de871  movaps [rsp+0x10], xmm3
000076b67a9de876  movaps [rsp+0x20], xmm7
000076b67a9de87b  lea rdi, [rsp]
000076b67a9de87f  mov esi, 0x00
000076b67a9de884  mov rax, 0x63C5EF2DF530
000076b67a9de88e  call rax
000076b67a9de890  movaps xmm15, [rsp]
000076b67a9de895  add rsp, 0x30
000076b67a9de899  vmovaps xmm0, [rsp]
000076b67a9de89e  vmovaps xmm1, [rsp+0x10]
000076b67a9de8a4  vmovaps xmm2, [rsp+0x20]
000076b67a9de8aa  vmovaps xmm3, [rsp+0x30]
000076b67a9de8b0  vmovaps xmm4, [rsp+0x40]
000076b67a9de8b6  vmovaps xmm5, [rsp+0x50]
000076b67a9de8bc  vmovaps xmm6, [rsp+0x60]
000076b67a9de8c2  vmovaps xmm7, [rsp+0x70]
000076b67a9de8c8  vmovaps xmm8, [rsp+0x80]
000076b67a9de8d1  vmovaps xmm9, [rsp+0x90]
000076b67a9de8da  vmovaps xmm10, [rsp+0xA0]
000076b67a9de8e3  vmovaps xmm11, [rsp+0xB0]
000076b67a9de8ec  vmovaps xmm12, [rsp+0xC0]
000076b67a9de8f5  vmovaps xmm13, [rsp+0xD0]
000076b67a9de8fe  vmovaps xmm14, [rsp+0xE0]
000076b67a9de907  add rsp, 0xF0
000076b67a9de90e  pop r11
000076b67a9de910  pop r10
000076b67a9de912  pop r9
000076b67a9de914  pop r8
000076b67a9de916  pop rsi
000076b67a9de917  pop rdi
000076b67a9de918  pop rdx
000076b67a9de919  pop rcx
000076b67a9de91a  pop rax
000076b67a9de91b  add rsp, 0x08
000076b67a9de91f  jmp 0x000076B67A9DC1E3
000076b67a9de924  sub rsp, 0x08
000076b67a9de928  push rax
000076b67a9de929  push rcx
000076b67a9de92a  push rdx
000076b67a9de92b  push rdi
000076b67a9de92c  push rsi
000076b67a9de92d  push r8
000076b67a9de92f  push r9
000076b67a9de931  push r10
000076b67a9de933  push r11
000076b67a9de935  sub rsp, 0xF0
000076b67a9de93c  vmovaps [rsp], xmm0
000076b67a9de941  vmovaps [rsp+0x10], xmm1
000076b67a9de947  vmovaps [rsp+0x20], xmm2
000076b67a9de94d  vmovaps [rsp+0x30], xmm4
000076b67a9de953  vmovaps [rsp+0x40], xmm5
000076b67a9de959  vmovaps [rsp+0x50], xmm6
000076b67a9de95f  vmovaps [rsp+0x60], xmm7
000076b67a9de965  vmovaps [rsp+0x70], xmm8
000076b67a9de96b  vmovaps [rsp+0x80], xmm9
000076b67a9de974  vmovaps [rsp+0x90], xmm10
000076b67a9de97d  vmovaps [rsp+0xA0], xmm11
000076b67a9de986  vmovaps [rsp+0xB0], xmm12
000076b67a9de98f  vmovaps [rsp+0xC0], xmm13
000076b67a9de998  vmovaps [rsp+0xD0], xmm14
000076b67a9de9a1  vmovaps [rsp+0xE0], xmm15
000076b67a9de9aa  sub rsp, 0x30
000076b67a9de9ae  movaps [rsp], xmm3
000076b67a9de9b2  movaps [rsp+0x10], xmm1
000076b67a9de9b7  movaps [rsp+0x20], xmm15
000076b67a9de9bd  lea rdi, [rsp]
000076b67a9de9c1  mov esi, 0x00
000076b67a9de9c6  mov rax, 0x63C5EF2DF530
000076b67a9de9d0  call rax
000076b67a9de9d2  movaps xmm3, [rsp]
000076b67a9de9d6  add rsp, 0x30
000076b67a9de9da  vmovaps xmm0, [rsp]
000076b67a9de9df  vmovaps xmm1, [rsp+0x10]
000076b67a9de9e5  vmovaps xmm2, [rsp+0x20]
000076b67a9de9eb  vmovaps xmm4, [rsp+0x30]
000076b67a9de9f1  vmovaps xmm5, [rsp+0x40]
000076b67a9de9f7  vmovaps xmm6, [rsp+0x50]
000076b67a9de9fd  vmovaps xmm7, [rsp+0x60]
000076b67a9dea03  vmovaps xmm8, [rsp+0x70]
000076b67a9dea09  vmovaps xmm9, [rsp+0x80]
000076b67a9dea12  vmovaps xmm10, [rsp+0x90]
000076b67a9dea1b  vmovaps xmm11, [rsp+0xA0]
000076b67a9dea24  vmovaps xmm12, [rsp+0xB0]
000076b67a9dea2d  vmovaps xmm13, [rsp+0xC0]
000076b67a9dea36  vmovaps xmm14, [rsp+0xD0]
000076b67a9dea3f  vmovaps xmm15, [rsp+0xE0]
000076b67a9dea48  add rsp, 0xF0
000076b67a9dea4f  pop r11
000076b67a9dea51  pop r10
000076b67a9dea53  pop r9
000076b67a9dea55  pop r8
000076b67a9dea57  pop rsi
000076b67a9dea58  pop rdi
000076b67a9dea59  pop rdx
000076b67a9dea5a  pop rcx
000076b67a9dea5b  pop rax
000076b67a9dea5c  add rsp, 0x08
000076b67a9dea60  jmp 0x000076B67A9DC272
000076b67a9dea65  call 0x000076B67A8B52F0
000076b67a9dea6a  jmp 0x000076B67A9DC27C
000076b67a9dea6f  sub rsp, 0x08
000076b67a9dea73  push rax
000076b67a9dea74  push rcx
000076b67a9dea75  push rdx
000076b67a9dea76  push rdi
000076b67a9dea77  push rsi
000076b67a9dea78  push r8
000076b67a9dea7a  push r9
000076b67a9dea7c  push r10
000076b67a9dea7e  push r11
000076b67a9dea80  sub rsp, 0xF0
000076b67a9dea87  vmovaps [rsp], xmm0
000076b67a9dea8c  vmovaps [rsp+0x10], xmm1
000076b67a9dea92  vmovaps [rsp+0x20], xmm2
000076b67a9dea98  vmovaps [rsp+0x30], xmm3
000076b67a9dea9e  vmovaps [rsp+0x40], xmm4
000076b67a9deaa4  vmovaps [rsp+0x50], xmm5
000076b67a9deaaa  vmovaps [rsp+0x60], xmm6
000076b67a9deab0  vmovaps [rsp+0x70], xmm7
000076b67a9deab6  vmovaps [rsp+0x80], xmm8
000076b67a9deabf  vmovaps [rsp+0x90], xmm9
000076b67a9deac8  vmovaps [rsp+0xA0], xmm10
000076b67a9dead1  vmovaps [rsp+0xB0], xmm11
000076b67a9deada  vmovaps [rsp+0xC0], xmm12
000076b67a9deae3  vmovaps [rsp+0xD0], xmm13
000076b67a9deaec  vmovaps [rsp+0xE0], xmm14
000076b67a9deaf5  sub rsp, 0x30
000076b67a9deaf9  movaps [rsp], xmm15
000076b67a9deafe  movaps [rsp+0x10], xmm14
000076b67a9deb04  movaps [rsp+0x20], xmm4
000076b67a9deb09  lea rdi, [rsp]
000076b67a9deb0d  mov esi, 0x00
000076b67a9deb12  mov rax, 0x63C5EF2DF530
000076b67a9deb1c  call rax
000076b67a9deb1e  movaps xmm15, [rsp]
000076b67a9deb23  add rsp, 0x30
000076b67a9deb27  vmovaps xmm0, [rsp]
000076b67a9deb2c  vmovaps xmm1, [rsp+0x10]
000076b67a9deb32  vmovaps xmm2, [rsp+0x20]
000076b67a9deb38  vmovaps xmm3, [rsp+0x30]
000076b67a9deb3e  vmovaps xmm4, [rsp+0x40]
000076b67a9deb44  vmovaps xmm5, [rsp+0x50]
000076b67a9deb4a  vmovaps xmm6, [rsp+0x60]
000076b67a9deb50  vmovaps xmm7, [rsp+0x70]
000076b67a9deb56  vmovaps xmm8, [rsp+0x80]
000076b67a9deb5f  vmovaps xmm9, [rsp+0x90]
000076b67a9deb68  vmovaps xmm10, [rsp+0xA0]
000076b67a9deb71  vmovaps xmm11, [rsp+0xB0]
000076b67a9deb7a  vmovaps xmm12, [rsp+0xC0]
000076b67a9deb83  vmovaps xmm13, [rsp+0xD0]
000076b67a9deb8c  vmovaps xmm14, [rsp+0xE0]
000076b67a9deb95  add rsp, 0xF0
000076b67a9deb9c  pop r11
000076b67a9deb9e  pop r10
000076b67a9deba0  pop r9
000076b67a9deba2  pop r8
000076b67a9deba4  pop rsi
000076b67a9deba5  pop rdi
000076b67a9deba6  pop rdx
000076b67a9deba7  pop rcx
000076b67a9deba8  pop rax
000076b67a9deba9  add rsp, 0x08
000076b67a9debad  jmp 0x000076B67A9DC2AA
000076b67a9debb2  sub rsp, 0x08
000076b67a9debb6  push rax
000076b67a9debb7  push rcx
000076b67a9debb8  push rdx
000076b67a9debb9  push rdi
000076b67a9debba  push rsi
000076b67a9debbb  push r8
000076b67a9debbd  push r9
000076b67a9debbf  push r10
000076b67a9debc1  push r11
000076b67a9debc3  sub rsp, 0xF0
000076b67a9debca  vmovaps [rsp], xmm0
000076b67a9debcf  vmovaps [rsp+0x10], xmm1
000076b67a9debd5  vmovaps [rsp+0x20], xmm2
000076b67a9debdb  vmovaps [rsp+0x30], xmm3
000076b67a9debe1  vmovaps [rsp+0x40], xmm4
000076b67a9debe7  vmovaps [rsp+0x50], xmm5
000076b67a9debed  vmovaps [rsp+0x60], xmm6
000076b67a9debf3  vmovaps [rsp+0x70], xmm7
000076b67a9debf9  vmovaps [rsp+0x80], xmm8
000076b67a9dec02  vmovaps [rsp+0x90], xmm9
000076b67a9dec0b  vmovaps [rsp+0xA0], xmm10
000076b67a9dec14  vmovaps [rsp+0xB0], xmm11
000076b67a9dec1d  vmovaps [rsp+0xC0], xmm12
000076b67a9dec26  vmovaps [rsp+0xD0], xmm13
000076b67a9dec2f  vmovaps [rsp+0xE0], xmm15
000076b67a9dec38  sub rsp, 0x30
000076b67a9dec3c  movaps [rsp], xmm14
000076b67a9dec41  movaps [rsp+0x10], xmm2
000076b67a9dec46  movaps [rsp+0x20], xmm1
000076b67a9dec4b  lea rdi, [rsp]
000076b67a9dec4f  mov esi, 0x00
000076b67a9dec54  mov rax, 0x63C5EF2DF530
000076b67a9dec5e  call rax
000076b67a9dec60  movaps xmm14, [rsp]
000076b67a9dec65  add rsp, 0x30
000076b67a9dec69  vmovaps xmm0, [rsp]
000076b67a9dec6e  vmovaps xmm1, [rsp+0x10]
000076b67a9dec74  vmovaps xmm2, [rsp+0x20]
000076b67a9dec7a  vmovaps xmm3, [rsp+0x30]
000076b67a9dec80  vmovaps xmm4, [rsp+0x40]
000076b67a9dec86  vmovaps xmm5, [rsp+0x50]
000076b67a9dec8c  vmovaps xmm6, [rsp+0x60]
000076b67a9dec92  vmovaps xmm7, [rsp+0x70]
000076b67a9dec98  vmovaps xmm8, [rsp+0x80]
000076b67a9deca1  vmovaps xmm9, [rsp+0x90]
000076b67a9decaa  vmovaps xmm10, [rsp+0xA0]
000076b67a9decb3  vmovaps xmm11, [rsp+0xB0]
000076b67a9decbc  vmovaps xmm12, [rsp+0xC0]
000076b67a9decc5  vmovaps xmm13, [rsp+0xD0]
000076b67a9decce  vmovaps xmm15, [rsp+0xE0]
000076b67a9decd7  add rsp, 0xF0
000076b67a9decde  pop r11
000076b67a9dece0  pop r10
000076b67a9dece2  pop r9
000076b67a9dece4  pop r8
000076b67a9dece6  pop rsi
000076b67a9dece7  pop rdi
000076b67a9dece8  pop rdx
000076b67a9dece9  pop rcx
000076b67a9decea  pop rax
000076b67a9deceb  add rsp, 0x08
000076b67a9decef  jmp 0x000076B67A9DC2D0
000076b67a9decf4  sub rsp, 0x08
000076b67a9decf8  push rax
000076b67a9decf9  push rcx
000076b67a9decfa  push rdx
000076b67a9decfb  push rdi
000076b67a9decfc  push rsi
000076b67a9decfd  push r8
000076b67a9decff  push r9
000076b67a9ded01  push r10
000076b67a9ded03  push r11
000076b67a9ded05  sub rsp, 0xF0
000076b67a9ded0c  vmovaps [rsp], xmm0
000076b67a9ded11  vmovaps [rsp+0x10], xmm2
000076b67a9ded17  vmovaps [rsp+0x20], xmm3
000076b67a9ded1d  vmovaps [rsp+0x30], xmm4
000076b67a9ded23  vmovaps [rsp+0x40], xmm5
000076b67a9ded29  vmovaps [rsp+0x50], xmm6
000076b67a9ded2f  vmovaps [rsp+0x60], xmm7
000076b67a9ded35  vmovaps [rsp+0x70], xmm8
000076b67a9ded3b  vmovaps [rsp+0x80], xmm9
000076b67a9ded44  vmovaps [rsp+0x90], xmm10
000076b67a9ded4d  vmovaps [rsp+0xA0], xmm11
000076b67a9ded56  vmovaps [rsp+0xB0], xmm12
000076b67a9ded5f  vmovaps [rsp+0xC0], xmm13
000076b67a9ded68  vmovaps [rsp+0xD0], xmm14
000076b67a9ded71  vmovaps [rsp+0xE0], xmm15
000076b67a9ded7a  sub rsp, 0x30
000076b67a9ded7e  movaps [rsp], xmm1
000076b67a9ded82  movaps [rsp+0x10], xmm4
000076b67a9ded87  movaps [rsp+0x20], xmm9
000076b67a9ded8d  lea rdi, [rsp]
000076b67a9ded91  mov esi, 0x00
000076b67a9ded96  mov rax, 0x63C5EF2DF530
000076b67a9deda0  call rax
000076b67a9deda2  movaps xmm1, [rsp]
000076b67a9deda6  add rsp, 0x30
000076b67a9dedaa  vmovaps xmm0, [rsp]
000076b67a9dedaf  vmovaps xmm2, [rsp+0x10]
000076b67a9dedb5  vmovaps xmm3, [rsp+0x20]
000076b67a9dedbb  vmovaps xmm4, [rsp+0x30]
000076b67a9dedc1  vmovaps xmm5, [rsp+0x40]
000076b67a9dedc7  vmovaps xmm6, [rsp+0x50]
000076b67a9dedcd  vmovaps xmm7, [rsp+0x60]
000076b67a9dedd3  vmovaps xmm8, [rsp+0x70]
000076b67a9dedd9  vmovaps xmm9, [rsp+0x80]
000076b67a9dede2  vmovaps xmm10, [rsp+0x90]
000076b67a9dedeb  vmovaps xmm11, [rsp+0xA0]
000076b67a9dedf4  vmovaps xmm12, [rsp+0xB0]
000076b67a9dedfd  vmovaps xmm13, [rsp+0xC0]
000076b67a9dee06  vmovaps xmm14, [rsp+0xD0]
000076b67a9dee0f  vmovaps xmm15, [rsp+0xE0]
000076b67a9dee18  add rsp, 0xF0
000076b67a9dee1f  pop r11
000076b67a9dee21  pop r10
000076b67a9dee23  pop r9
000076b67a9dee25  pop r8
000076b67a9dee27  pop rsi
000076b67a9dee28  pop rdi
000076b67a9dee29  pop rdx
000076b67a9dee2a  pop rcx
000076b67a9dee2b  pop rax
000076b67a9dee2c  add rsp, 0x08
000076b67a9dee30  jmp 0x000076B67A9DC2EE
000076b67a9dee35  sub rsp, 0x08
000076b67a9dee39  push rax
000076b67a9dee3a  push rcx
000076b67a9dee3b  push rdx
000076b67a9dee3c  push rdi
000076b67a9dee3d  push rsi
000076b67a9dee3e  push r8
000076b67a9dee40  push r9
000076b67a9dee42  push r10
000076b67a9dee44  push r11
000076b67a9dee46  sub rsp, 0xF0
000076b67a9dee4d  vmovaps [rsp], xmm0
000076b67a9dee52  vmovaps [rsp+0x10], xmm1
000076b67a9dee58  vmovaps [rsp+0x20], xmm2
000076b67a9dee5e  vmovaps [rsp+0x30], xmm3
000076b67a9dee64  vmovaps [rsp+0x40], xmm5
000076b67a9dee6a  vmovaps [rsp+0x50], xmm6
000076b67a9dee70  vmovaps [rsp+0x60], xmm7
000076b67a9dee76  vmovaps [rsp+0x70], xmm8
000076b67a9dee7c  vmovaps [rsp+0x80], xmm9
000076b67a9dee85  vmovaps [rsp+0x90], xmm10
000076b67a9dee8e  vmovaps [rsp+0xA0], xmm11
000076b67a9dee97  vmovaps [rsp+0xB0], xmm12
000076b67a9deea0  vmovaps [rsp+0xC0], xmm13
000076b67a9deea9  vmovaps [rsp+0xD0], xmm14
000076b67a9deeb2  vmovaps [rsp+0xE0], xmm15
000076b67a9deebb  sub rsp, 0x30
000076b67a9deebf  movaps [rsp], xmm4
000076b67a9deec3  movaps [rsp+0x10], xmm2
000076b67a9deec8  movaps [rsp+0x20], xmm9
000076b67a9deece  lea rdi, [rsp]
000076b67a9deed2  mov esi, 0x00
000076b67a9deed7  mov rax, 0x63C5EF2DF530
000076b67a9deee1  call rax
000076b67a9deee3  movaps xmm4, [rsp]
000076b67a9deee7  add rsp, 0x30
000076b67a9deeeb  vmovaps xmm0, [rsp]
000076b67a9deef0  vmovaps xmm1, [rsp+0x10]
000076b67a9deef6  vmovaps xmm2, [rsp+0x20]
000076b67a9deefc  vmovaps xmm3, [rsp+0x30]
000076b67a9def02  vmovaps xmm5, [rsp+0x40]
000076b67a9def08  vmovaps xmm6, [rsp+0x50]
000076b67a9def0e  vmovaps xmm7, [rsp+0x60]
000076b67a9def14  vmovaps xmm8, [rsp+0x70]
000076b67a9def1a  vmovaps xmm9, [rsp+0x80]
000076b67a9def23  vmovaps xmm10, [rsp+0x90]
000076b67a9def2c  vmovaps xmm11, [rsp+0xA0]
000076b67a9def35  vmovaps xmm12, [rsp+0xB0]
000076b67a9def3e  vmovaps xmm13, [rsp+0xC0]
000076b67a9def47  vmovaps xmm14, [rsp+0xD0]
000076b67a9def50  vmovaps xmm15, [rsp+0xE0]
000076b67a9def59  add rsp, 0xF0
000076b67a9def60  pop r11
000076b67a9def62  pop r10
000076b67a9def64  pop r9
000076b67a9def66  pop r8
000076b67a9def68  pop rsi
000076b67a9def69  pop rdi
000076b67a9def6a  pop rdx
000076b67a9def6b  pop rcx
000076b67a9def6c  pop rax
000076b67a9def6d  add rsp, 0x08
000076b67a9def71  jmp 0x000076B67A9DC31E
000076b67a9def76  sub rsp, 0x08
000076b67a9def7a  push rax
000076b67a9def7b  push rcx
000076b67a9def7c  push rdx
000076b67a9def7d  push rdi
000076b67a9def7e  push rsi
000076b67a9def7f  push r8
000076b67a9def81  push r9
000076b67a9def83  push r10
000076b67a9def85  push r11
000076b67a9def87  sub rsp, 0xF0
000076b67a9def8e  vmovaps [rsp], xmm0
000076b67a9def93  vmovaps [rsp+0x10], xmm1
000076b67a9def99  vmovaps [rsp+0x20], xmm2
000076b67a9def9f  vmovaps [rsp+0x30], xmm3
000076b67a9defa5  vmovaps [rsp+0x40], xmm4
000076b67a9defab  vmovaps [rsp+0x50], xmm5
000076b67a9defb1  vmovaps [rsp+0x60], xmm6
000076b67a9defb7  vmovaps [rsp+0x70], xmm7
000076b67a9defbd  vmovaps [rsp+0x80], xmm8
000076b67a9defc6  vmovaps [rsp+0x90], xmm10
000076b67a9defcf  vmovaps [rsp+0xA0], xmm11
000076b67a9defd8  vmovaps [rsp+0xB0], xmm12
000076b67a9defe1  vmovaps [rsp+0xC0], xmm13
000076b67a9defea  vmovaps [rsp+0xD0], xmm14
000076b67a9deff3  vmovaps [rsp+0xE0], xmm15
000076b67a9deffc  sub rsp, 0x30
000076b67a9df000  movaps [rsp], xmm9
000076b67a9df005  movaps [rsp+0x10], xmm2
000076b67a9df00a  movaps [rsp+0x20], xmm1
000076b67a9df00f  lea rdi, [rsp]
000076b67a9df013  mov esi, 0x00
000076b67a9df018  mov rax, 0x63C5EF2DF530
000076b67a9df022  call rax
000076b67a9df024  movaps xmm9, [rsp]
000076b67a9df029  add rsp, 0x30
000076b67a9df02d  vmovaps xmm0, [rsp]
000076b67a9df032  vmovaps xmm1, [rsp+0x10]
000076b67a9df038  vmovaps xmm2, [rsp+0x20]
000076b67a9df03e  vmovaps xmm3, [rsp+0x30]
000076b67a9df044  vmovaps xmm4, [rsp+0x40]
000076b67a9df04a  vmovaps xmm5, [rsp+0x50]
000076b67a9df050  vmovaps xmm6, [rsp+0x60]
000076b67a9df056  vmovaps xmm7, [rsp+0x70]
000076b67a9df05c  vmovaps xmm8, [rsp+0x80]
000076b67a9df065  vmovaps xmm10, [rsp+0x90]
000076b67a9df06e  vmovaps xmm11, [rsp+0xA0]
000076b67a9df077  vmovaps xmm12, [rsp+0xB0]
000076b67a9df080  vmovaps xmm13, [rsp+0xC0]
000076b67a9df089  vmovaps xmm14, [rsp+0xD0]
000076b67a9df092  vmovaps xmm15, [rsp+0xE0]
000076b67a9df09b  add rsp, 0xF0
000076b67a9df0a2  pop r11
000076b67a9df0a4  pop r10
000076b67a9df0a6  pop r9
000076b67a9df0a8  pop r8
000076b67a9df0aa  pop rsi
000076b67a9df0ab  pop rdi
000076b67a9df0ac  pop rdx
000076b67a9df0ad  pop rcx
000076b67a9df0ae  pop rax
000076b67a9df0af  add rsp, 0x08
000076b67a9df0b3  jmp 0x000076B67A9DC354
000076b67a9df0b8  sub rsp, 0x08
000076b67a9df0bc  push rax
000076b67a9df0bd  push rcx
000076b67a9df0be  push rdx
000076b67a9df0bf  push rdi
000076b67a9df0c0  push rsi
000076b67a9df0c1  push r8
000076b67a9df0c3  push r9
000076b67a9df0c5  push r10
000076b67a9df0c7  push r11
000076b67a9df0c9  sub rsp, 0xF0
000076b67a9df0d0  vmovaps [rsp], xmm0
000076b67a9df0d5  vmovaps [rsp+0x10], xmm2
000076b67a9df0db  vmovaps [rsp+0x20], xmm3
000076b67a9df0e1  vmovaps [rsp+0x30], xmm4
000076b67a9df0e7  vmovaps [rsp+0x40], xmm5
000076b67a9df0ed  vmovaps [rsp+0x50], xmm6
000076b67a9df0f3  vmovaps [rsp+0x60], xmm7
000076b67a9df0f9  vmovaps [rsp+0x70], xmm8
000076b67a9df0ff  vmovaps [rsp+0x80], xmm9
000076b67a9df108  vmovaps [rsp+0x90], xmm10
000076b67a9df111  vmovaps [rsp+0xA0], xmm11
000076b67a9df11a  vmovaps [rsp+0xB0], xmm12
000076b67a9df123  vmovaps [rsp+0xC0], xmm13
000076b67a9df12c  vmovaps [rsp+0xD0], xmm14
000076b67a9df135  vmovaps [rsp+0xE0], xmm15
000076b67a9df13e  sub rsp, 0x30
000076b67a9df142  movaps [rsp], xmm1
000076b67a9df146  movaps [rsp+0x10], xmm15
000076b67a9df14c  movaps [rsp+0x20], xmm6
000076b67a9df151  lea rdi, [rsp]
000076b67a9df155  mov esi, 0x00
000076b67a9df15a  mov rax, 0x63C5EF2DF530
000076b67a9df164  call rax
000076b67a9df166  movaps xmm1, [rsp]
000076b67a9df16a  add rsp, 0x30
000076b67a9df16e  vmovaps xmm0, [rsp]
000076b67a9df173  vmovaps xmm2, [rsp+0x10]
000076b67a9df179  vmovaps xmm3, [rsp+0x20]
000076b67a9df17f  vmovaps xmm4, [rsp+0x30]
000076b67a9df185  vmovaps xmm5, [rsp+0x40]
000076b67a9df18b  vmovaps xmm6, [rsp+0x50]
000076b67a9df191  vmovaps xmm7, [rsp+0x60]
000076b67a9df197  vmovaps xmm8, [rsp+0x70]
000076b67a9df19d  vmovaps xmm9, [rsp+0x80]
000076b67a9df1a6  vmovaps xmm10, [rsp+0x90]
000076b67a9df1af  vmovaps xmm11, [rsp+0xA0]
000076b67a9df1b8  vmovaps xmm12, [rsp+0xB0]
000076b67a9df1c1  vmovaps xmm13, [rsp+0xC0]
000076b67a9df1ca  vmovaps xmm14, [rsp+0xD0]
000076b67a9df1d3  vmovaps xmm15, [rsp+0xE0]
000076b67a9df1dc  add rsp, 0xF0
000076b67a9df1e3  pop r11
000076b67a9df1e5  pop r10
000076b67a9df1e7  pop r9
000076b67a9df1e9  pop r8
000076b67a9df1eb  pop rsi
000076b67a9df1ec  pop rdi
000076b67a9df1ed  pop rdx
000076b67a9df1ee  pop rcx
000076b67a9df1ef  pop rax
000076b67a9df1f0  add rsp, 0x08
000076b67a9df1f4  jmp 0x000076B67A9DC375
000076b67a9df1f9  sub rsp, 0x08
000076b67a9df1fd  push rax
000076b67a9df1fe  push rcx
000076b67a9df1ff  push rdx
000076b67a9df200  push rdi
000076b67a9df201  push rsi
000076b67a9df202  push r8
000076b67a9df204  push r9
000076b67a9df206  push r10
000076b67a9df208  push r11
000076b67a9df20a  sub rsp, 0xF0
000076b67a9df211  vmovaps [rsp], xmm0
000076b67a9df216  vmovaps [rsp+0x10], xmm1
000076b67a9df21c  vmovaps [rsp+0x20], xmm2
000076b67a9df222  vmovaps [rsp+0x30], xmm3
000076b67a9df228  vmovaps [rsp+0x40], xmm4
000076b67a9df22e  vmovaps [rsp+0x50], xmm5
000076b67a9df234  vmovaps [rsp+0x60], xmm6
000076b67a9df23a  vmovaps [rsp+0x70], xmm7
000076b67a9df240  vmovaps [rsp+0x80], xmm8
000076b67a9df249  vmovaps [rsp+0x90], xmm9
000076b67a9df252  vmovaps [rsp+0xA0], xmm10
000076b67a9df25b  vmovaps [rsp+0xB0], xmm11
000076b67a9df264  vmovaps [rsp+0xC0], xmm12
000076b67a9df26d  vmovaps [rsp+0xD0], xmm13
000076b67a9df276  vmovaps [rsp+0xE0], xmm14
000076b67a9df27f  sub rsp, 0x30
000076b67a9df283  movaps [rsp], xmm15
000076b67a9df288  movaps [rsp+0x10], xmm5
000076b67a9df28d  movaps [rsp+0x20], xmm3
000076b67a9df292  lea rdi, [rsp]
000076b67a9df296  mov esi, 0x00
000076b67a9df29b  mov rax, 0x63C5EF2DF530
000076b67a9df2a5  call rax
000076b67a9df2a7  movaps xmm15, [rsp]
000076b67a9df2ac  add rsp, 0x30
000076b67a9df2b0  vmovaps xmm0, [rsp]
000076b67a9df2b5  vmovaps xmm1, [rsp+0x10]
000076b67a9df2bb  vmovaps xmm2, [rsp+0x20]
000076b67a9df2c1  vmovaps xmm3, [rsp+0x30]
000076b67a9df2c7  vmovaps xmm4, [rsp+0x40]
000076b67a9df2cd  vmovaps xmm5, [rsp+0x50]
000076b67a9df2d3  vmovaps xmm6, [rsp+0x60]
000076b67a9df2d9  vmovaps xmm7, [rsp+0x70]
000076b67a9df2df  vmovaps xmm8, [rsp+0x80]
000076b67a9df2e8  vmovaps xmm9, [rsp+0x90]
000076b67a9df2f1  vmovaps xmm10, [rsp+0xA0]
000076b67a9df2fa  vmovaps xmm11, [rsp+0xB0]
000076b67a9df303  vmovaps xmm12, [rsp+0xC0]
000076b67a9df30c  vmovaps xmm13, [rsp+0xD0]
000076b67a9df315  vmovaps xmm14, [rsp+0xE0]
000076b67a9df31e  add rsp, 0xF0
000076b67a9df325  pop r11
000076b67a9df327  pop r10
000076b67a9df329  pop r9
000076b67a9df32b  pop r8
000076b67a9df32d  pop rsi
000076b67a9df32e  pop rdi
000076b67a9df32f  pop rdx
000076b67a9df330  pop rcx
000076b67a9df331  pop rax
000076b67a9df332  add rsp, 0x08
000076b67a9df336  jmp 0x000076B67A9DC38F
000076b67a9df33b  sub rsp, 0x08
000076b67a9df33f  push rax
000076b67a9df340  push rcx
000076b67a9df341  push rdx
000076b67a9df342  push rdi
000076b67a9df343  push rsi
000076b67a9df344  push r8
000076b67a9df346  push r9
000076b67a9df348  push r10
000076b67a9df34a  push r11
000076b67a9df34c  sub rsp, 0xF0
000076b67a9df353  vmovaps [rsp], xmm0
000076b67a9df358  vmovaps [rsp+0x10], xmm1
000076b67a9df35e  vmovaps [rsp+0x20], xmm2
000076b67a9df364  vmovaps [rsp+0x30], xmm3
000076b67a9df36a  vmovaps [rsp+0x40], xmm4
000076b67a9df370  vmovaps [rsp+0x50], xmm6
000076b67a9df376  vmovaps [rsp+0x60], xmm7
000076b67a9df37c  vmovaps [rsp+0x70], xmm8
000076b67a9df382  vmovaps [rsp+0x80], xmm9
000076b67a9df38b  vmovaps [rsp+0x90], xmm10
000076b67a9df394  vmovaps [rsp+0xA0], xmm11
000076b67a9df39d  vmovaps [rsp+0xB0], xmm12
000076b67a9df3a6  vmovaps [rsp+0xC0], xmm13
000076b67a9df3af  vmovaps [rsp+0xD0], xmm14
000076b67a9df3b8  vmovaps [rsp+0xE0], xmm15
000076b67a9df3c1  sub rsp, 0x30
000076b67a9df3c5  movaps [rsp], xmm5
000076b67a9df3c9  movaps [rsp+0x10], xmm8
000076b67a9df3cf  movaps [rsp+0x20], xmm6
000076b67a9df3d4  lea rdi, [rsp]
000076b67a9df3d8  mov esi, 0x00
000076b67a9df3dd  mov rax, 0x63C5EF2DF530
000076b67a9df3e7  call rax
000076b67a9df3e9  movaps xmm5, [rsp]
000076b67a9df3ed  add rsp, 0x30
000076b67a9df3f1  vmovaps xmm0, [rsp]
000076b67a9df3f6  vmovaps xmm1, [rsp+0x10]
000076b67a9df3fc  vmovaps xmm2, [rsp+0x20]
000076b67a9df402  vmovaps xmm3, [rsp+0x30]
000076b67a9df408  vmovaps xmm4, [rsp+0x40]
000076b67a9df40e  vmovaps xmm6, [rsp+0x50]
000076b67a9df414  vmovaps xmm7, [rsp+0x60]
000076b67a9df41a  vmovaps xmm8, [rsp+0x70]
000076b67a9df420  vmovaps xmm9, [rsp+0x80]
000076b67a9df429  vmovaps xmm10, [rsp+0x90]
000076b67a9df432  vmovaps xmm11, [rsp+0xA0]
000076b67a9df43b  vmovaps xmm12, [rsp+0xB0]
000076b67a9df444  vmovaps xmm13, [rsp+0xC0]
000076b67a9df44d  vmovaps xmm14, [rsp+0xD0]
000076b67a9df456  vmovaps xmm15, [rsp+0xE0]
000076b67a9df45f  add rsp, 0xF0
000076b67a9df466  pop r11
000076b67a9df468  pop r10
000076b67a9df46a  pop r9
000076b67a9df46c  pop r8
000076b67a9df46e  pop rsi
000076b67a9df46f  pop rdi
000076b67a9df470  pop rdx
000076b67a9df471  pop rcx
000076b67a9df472  pop rax
000076b67a9df473  add rsp, 0x08
000076b67a9df477  jmp 0x000076B67A9DC3B3
000076b67a9df47c  sub rsp, 0x08
000076b67a9df480  push rax
000076b67a9df481  push rcx
000076b67a9df482  push rdx
000076b67a9df483  push rdi
000076b67a9df484  push rsi
000076b67a9df485  push r8
000076b67a9df487  push r9
000076b67a9df489  push r10
000076b67a9df48b  push r11
000076b67a9df48d  sub rsp, 0xF0
000076b67a9df494  vmovaps [rsp], xmm0
000076b67a9df499  vmovaps [rsp+0x10], xmm1
000076b67a9df49f  vmovaps [rsp+0x20], xmm2
000076b67a9df4a5  vmovaps [rsp+0x30], xmm3
000076b67a9df4ab  vmovaps [rsp+0x40], xmm4
000076b67a9df4b1  vmovaps [rsp+0x50], xmm5
000076b67a9df4b7  vmovaps [rsp+0x60], xmm7
000076b67a9df4bd  vmovaps [rsp+0x70], xmm8
000076b67a9df4c3  vmovaps [rsp+0x80], xmm9
000076b67a9df4cc  vmovaps [rsp+0x90], xmm10
000076b67a9df4d5  vmovaps [rsp+0xA0], xmm11
000076b67a9df4de  vmovaps [rsp+0xB0], xmm12
000076b67a9df4e7  vmovaps [rsp+0xC0], xmm13
000076b67a9df4f0  vmovaps [rsp+0xD0], xmm14
000076b67a9df4f9  vmovaps [rsp+0xE0], xmm15
000076b67a9df502  sub rsp, 0x30
000076b67a9df506  movaps [rsp], xmm6
000076b67a9df50a  movaps [rsp+0x10], xmm10
000076b67a9df510  movaps [rsp+0x20], xmm8
000076b67a9df516  lea rdi, [rsp]
000076b67a9df51a  mov esi, 0x00
000076b67a9df51f  mov rax, 0x63C5EF2DF530
000076b67a9df529  call rax
000076b67a9df52b  movaps xmm6, [rsp]
000076b67a9df52f  add rsp, 0x30
000076b67a9df533  vmovaps xmm0, [rsp]
000076b67a9df538  vmovaps xmm1, [rsp+0x10]
000076b67a9df53e  vmovaps xmm2, [rsp+0x20]
000076b67a9df544  vmovaps xmm3, [rsp+0x30]
000076b67a9df54a  vmovaps xmm4, [rsp+0x40]
000076b67a9df550  vmovaps xmm5, [rsp+0x50]
000076b67a9df556  vmovaps xmm7, [rsp+0x60]
000076b67a9df55c  vmovaps xmm8, [rsp+0x70]
000076b67a9df562  vmovaps xmm9, [rsp+0x80]
000076b67a9df56b  vmovaps xmm10, [rsp+0x90]
000076b67a9df574  vmovaps xmm11, [rsp+0xA0]
000076b67a9df57d  vmovaps xmm12, [rsp+0xB0]
000076b67a9df586  vmovaps xmm13, [rsp+0xC0]
000076b67a9df58f  vmovaps xmm14, [rsp+0xD0]
000076b67a9df598  vmovaps xmm15, [rsp+0xE0]
000076b67a9df5a1  add rsp, 0xF0
000076b67a9df5a8  pop r11
000076b67a9df5aa  pop r10
000076b67a9df5ac  pop r9
000076b67a9df5ae  pop r8
000076b67a9df5b0  pop rsi
000076b67a9df5b1  pop rdi
000076b67a9df5b2  pop rdx
000076b67a9df5b3  pop rcx
000076b67a9df5b4  pop rax
000076b67a9df5b5  add rsp, 0x08
000076b67a9df5b9  jmp 0x000076B67A9DC3D8
000076b67a9df5be  sub rsp, 0x08
000076b67a9df5c2  push rax
000076b67a9df5c3  push rcx
000076b67a9df5c4  push rdx
000076b67a9df5c5  push rdi
000076b67a9df5c6  push rsi
000076b67a9df5c7  push r8
000076b67a9df5c9  push r9
000076b67a9df5cb  push r10
000076b67a9df5cd  push r11
000076b67a9df5cf  sub rsp, 0xF0
000076b67a9df5d6  vmovaps [rsp], xmm0
000076b67a9df5db  vmovaps [rsp+0x10], xmm1
000076b67a9df5e1  vmovaps [rsp+0x20], xmm2
000076b67a9df5e7  vmovaps [rsp+0x30], xmm3
000076b67a9df5ed  vmovaps [rsp+0x40], xmm4
000076b67a9df5f3  vmovaps [rsp+0x50], xmm5
000076b67a9df5f9  vmovaps [rsp+0x60], xmm6
000076b67a9df5ff  vmovaps [rsp+0x70], xmm7
000076b67a9df605  vmovaps [rsp+0x80], xmm8
000076b67a9df60e  vmovaps [rsp+0x90], xmm9
000076b67a9df617  vmovaps [rsp+0xA0], xmm11
000076b67a9df620  vmovaps [rsp+0xB0], xmm12
000076b67a9df629  vmovaps [rsp+0xC0], xmm13
000076b67a9df632  vmovaps [rsp+0xD0], xmm14
000076b67a9df63b  vmovaps [rsp+0xE0], xmm15
000076b67a9df644  sub rsp, 0x30
000076b67a9df648  movaps [rsp], xmm10
000076b67a9df64d  movaps [rsp+0x10], xmm8
000076b67a9df653  movaps [rsp+0x20], xmm14
000076b67a9df659  lea rdi, [rsp]
000076b67a9df65d  mov esi, 0x00
000076b67a9df662  mov rax, 0x63C5EF2DF530
000076b67a9df66c  call rax
000076b67a9df66e  movaps xmm10, [rsp]
000076b67a9df673  add rsp, 0x30
000076b67a9df677  vmovaps xmm0, [rsp]
000076b67a9df67c  vmovaps xmm1, [rsp+0x10]
000076b67a9df682  vmovaps xmm2, [rsp+0x20]
000076b67a9df688  vmovaps xmm3, [rsp+0x30]
000076b67a9df68e  vmovaps xmm4, [rsp+0x40]
000076b67a9df694  vmovaps xmm5, [rsp+0x50]
000076b67a9df69a  vmovaps xmm6, [rsp+0x60]
000076b67a9df6a0  vmovaps xmm7, [rsp+0x70]
000076b67a9df6a6  vmovaps xmm8, [rsp+0x80]
000076b67a9df6af  vmovaps xmm9, [rsp+0x90]
000076b67a9df6b8  vmovaps xmm11, [rsp+0xA0]
000076b67a9df6c1  vmovaps xmm12, [rsp+0xB0]
000076b67a9df6ca  vmovaps xmm13, [rsp+0xC0]
000076b67a9df6d3  vmovaps xmm14, [rsp+0xD0]
000076b67a9df6dc  vmovaps xmm15, [rsp+0xE0]
000076b67a9df6e5  add rsp, 0xF0
000076b67a9df6ec  pop r11
000076b67a9df6ee  pop r10
000076b67a9df6f0  pop r9
000076b67a9df6f2  pop r8
000076b67a9df6f4  pop rsi
000076b67a9df6f5  pop rdi
000076b67a9df6f6  pop rdx
000076b67a9df6f7  pop rcx
000076b67a9df6f8  pop rax
000076b67a9df6f9  add rsp, 0x08
000076b67a9df6fd  jmp 0x000076B67A9DC3F8
000076b67a9df702  sub rsp, 0x08
000076b67a9df706  push rax
000076b67a9df707  push rcx
000076b67a9df708  push rdx
000076b67a9df709  push rdi
000076b67a9df70a  push rsi
000076b67a9df70b  push r8
000076b67a9df70d  push r9
000076b67a9df70f  push r10
000076b67a9df711  push r11
000076b67a9df713  sub rsp, 0xF0
000076b67a9df71a  vmovaps [rsp], xmm0
000076b67a9df71f  vmovaps [rsp+0x10], xmm1
000076b67a9df725  vmovaps [rsp+0x20], xmm2
000076b67a9df72b  vmovaps [rsp+0x30], xmm3
000076b67a9df731  vmovaps [rsp+0x40], xmm4
000076b67a9df737  vmovaps [rsp+0x50], xmm5
000076b67a9df73d  vmovaps [rsp+0x60], xmm6
000076b67a9df743  vmovaps [rsp+0x70], xmm7
000076b67a9df749  vmovaps [rsp+0x80], xmm8
000076b67a9df752  vmovaps [rsp+0x90], xmm9
000076b67a9df75b  vmovaps [rsp+0xA0], xmm10
000076b67a9df764  vmovaps [rsp+0xB0], xmm11
000076b67a9df76d  vmovaps [rsp+0xC0], xmm12
000076b67a9df776  vmovaps [rsp+0xD0], xmm13
000076b67a9df77f  vmovaps [rsp+0xE0], xmm15
000076b67a9df788  sub rsp, 0x30
000076b67a9df78c  movaps [rsp], xmm14
000076b67a9df791  movaps [rsp+0x10], xmm8
000076b67a9df797  movaps [rsp+0x20], xmm4
000076b67a9df79c  lea rdi, [rsp]
000076b67a9df7a0  mov esi, 0x00
000076b67a9df7a5  mov rax, 0x63C5EF2DF530
000076b67a9df7af  call rax
000076b67a9df7b1  movaps xmm14, [rsp]
000076b67a9df7b6  add rsp, 0x30
000076b67a9df7ba  vmovaps xmm0, [rsp]
000076b67a9df7bf  vmovaps xmm1, [rsp+0x10]
000076b67a9df7c5  vmovaps xmm2, [rsp+0x20]
000076b67a9df7cb  vmovaps xmm3, [rsp+0x30]
000076b67a9df7d1  vmovaps xmm4, [rsp+0x40]
000076b67a9df7d7  vmovaps xmm5, [rsp+0x50]
000076b67a9df7dd  vmovaps xmm6, [rsp+0x60]
000076b67a9df7e3  vmovaps xmm7, [rsp+0x70]
000076b67a9df7e9  vmovaps xmm8, [rsp+0x80]
000076b67a9df7f2  vmovaps xmm9, [rsp+0x90]
000076b67a9df7fb  vmovaps xmm10, [rsp+0xA0]
000076b67a9df804  vmovaps xmm11, [rsp+0xB0]
000076b67a9df80d  vmovaps xmm12, [rsp+0xC0]
000076b67a9df816  vmovaps xmm13, [rsp+0xD0]
000076b67a9df81f  vmovaps xmm15, [rsp+0xE0]
000076b67a9df828  add rsp, 0xF0
000076b67a9df82f  pop r11
000076b67a9df831  pop r10
000076b67a9df833  pop r9
000076b67a9df835  pop r8
000076b67a9df837  pop rsi
000076b67a9df838  pop rdi
000076b67a9df839  pop rdx
000076b67a9df83a  pop rcx
000076b67a9df83b  pop rax
000076b67a9df83c  add rsp, 0x08
000076b67a9df840  jmp 0x000076B67A9DC418
000076b67a9df845  sub rsp, 0x08
000076b67a9df849  push rax
000076b67a9df84a  push rcx
000076b67a9df84b  push rdx
000076b67a9df84c  push rdi
000076b67a9df84d  push rsi
000076b67a9df84e  push r8
000076b67a9df850  push r9
000076b67a9df852  push r10
000076b67a9df854  push r11
000076b67a9df856  sub rsp, 0xF0
000076b67a9df85d  vmovaps [rsp], xmm0
000076b67a9df862  vmovaps [rsp+0x10], xmm1
000076b67a9df868  vmovaps [rsp+0x20], xmm2
000076b67a9df86e  vmovaps [rsp+0x30], xmm3
000076b67a9df874  vmovaps [rsp+0x40], xmm5
000076b67a9df87a  vmovaps [rsp+0x50], xmm6
000076b67a9df880  vmovaps [rsp+0x60], xmm7
000076b67a9df886  vmovaps [rsp+0x70], xmm8
000076b67a9df88c  vmovaps [rsp+0x80], xmm9
000076b67a9df895  vmovaps [rsp+0x90], xmm10
000076b67a9df89e  vmovaps [rsp+0xA0], xmm11
000076b67a9df8a7  vmovaps [rsp+0xB0], xmm12
000076b67a9df8b0  vmovaps [rsp+0xC0], xmm13
000076b67a9df8b9  vmovaps [rsp+0xD0], xmm14
000076b67a9df8c2  vmovaps [rsp+0xE0], xmm15
000076b67a9df8cb  sub rsp, 0x30
000076b67a9df8cf  movaps [rsp], xmm4
000076b67a9df8d3  movaps [rsp+0x10], xmm13
000076b67a9df8d9  movaps [rsp+0x20], xmm8
000076b67a9df8df  lea rdi, [rsp]
000076b67a9df8e3  mov esi, 0x00
000076b67a9df8e8  mov rax, 0x63C5EF2DF530
000076b67a9df8f2  call rax
000076b67a9df8f4  movaps xmm4, [rsp]
000076b67a9df8f8  add rsp, 0x30
000076b67a9df8fc  vmovaps xmm0, [rsp]
000076b67a9df901  vmovaps xmm1, [rsp+0x10]
000076b67a9df907  vmovaps xmm2, [rsp+0x20]
000076b67a9df90d  vmovaps xmm3, [rsp+0x30]
000076b67a9df913  vmovaps xmm5, [rsp+0x40]
000076b67a9df919  vmovaps xmm6, [rsp+0x50]
000076b67a9df91f  vmovaps xmm7, [rsp+0x60]
000076b67a9df925  vmovaps xmm8, [rsp+0x70]
000076b67a9df92b  vmovaps xmm9, [rsp+0x80]
000076b67a9df934  vmovaps xmm10, [rsp+0x90]
000076b67a9df93d  vmovaps xmm11, [rsp+0xA0]
000076b67a9df946  vmovaps xmm12, [rsp+0xB0]
000076b67a9df94f  vmovaps xmm13, [rsp+0xC0]
000076b67a9df958  vmovaps xmm14, [rsp+0xD0]
000076b67a9df961  vmovaps xmm15, [rsp+0xE0]
000076b67a9df96a  add rsp, 0xF0
000076b67a9df971  pop r11
000076b67a9df973  pop r10
000076b67a9df975  pop r9
000076b67a9df977  pop r8
000076b67a9df979  pop rsi
000076b67a9df97a  pop rdi
000076b67a9df97b  pop rdx
000076b67a9df97c  pop rcx
000076b67a9df97d  pop rax
000076b67a9df97e  add rsp, 0x08
000076b67a9df982  jmp 0x000076B67A9DC43D
000076b67a9df987  sub rsp, 0x08
000076b67a9df98b  push rax
000076b67a9df98c  push rcx
000076b67a9df98d  push rdx
000076b67a9df98e  push rdi
000076b67a9df98f  push rsi
000076b67a9df990  push r8
000076b67a9df992  push r9
000076b67a9df994  push r10
000076b67a9df996  push r11
000076b67a9df998  sub rsp, 0xF0
000076b67a9df99f  vmovaps [rsp], xmm0
000076b67a9df9a4  vmovaps [rsp+0x10], xmm1
000076b67a9df9aa  vmovaps [rsp+0x20], xmm2
000076b67a9df9b0  vmovaps [rsp+0x30], xmm3
000076b67a9df9b6  vmovaps [rsp+0x40], xmm4
000076b67a9df9bc  vmovaps [rsp+0x50], xmm5
000076b67a9df9c2  vmovaps [rsp+0x60], xmm6
000076b67a9df9c8  vmovaps [rsp+0x70], xmm7
000076b67a9df9ce  vmovaps [rsp+0x80], xmm8
000076b67a9df9d7  vmovaps [rsp+0x90], xmm9
000076b67a9df9e0  vmovaps [rsp+0xA0], xmm10
000076b67a9df9e9  vmovaps [rsp+0xB0], xmm11
000076b67a9df9f2  vmovaps [rsp+0xC0], xmm12
000076b67a9df9fb  vmovaps [rsp+0xD0], xmm14
000076b67a9dfa04  vmovaps [rsp+0xE0], xmm15
000076b67a9dfa0d  sub rsp, 0x30
000076b67a9dfa11  movaps [rsp], xmm13
000076b67a9dfa16  movaps [rsp+0x10], xmm15
000076b67a9dfa1c  movaps [rsp+0x20], xmm9
000076b67a9dfa22  lea rdi, [rsp]
000076b67a9dfa26  mov esi, 0x00
000076b67a9dfa2b  mov rax, 0x63C5EF2DF530
000076b67a9dfa35  call rax
000076b67a9dfa37  movaps xmm13, [rsp]
000076b67a9dfa3c  add rsp, 0x30
000076b67a9dfa40  vmovaps xmm0, [rsp]
000076b67a9dfa45  vmovaps xmm1, [rsp+0x10]
000076b67a9dfa4b  vmovaps xmm2, [rsp+0x20]
000076b67a9dfa51  vmovaps xmm3, [rsp+0x30]
000076b67a9dfa57  vmovaps xmm4, [rsp+0x40]
000076b67a9dfa5d  vmovaps xmm5, [rsp+0x50]
000076b67a9dfa63  vmovaps xmm6, [rsp+0x60]
000076b67a9dfa69  vmovaps xmm7, [rsp+0x70]
000076b67a9dfa6f  vmovaps xmm8, [rsp+0x80]
000076b67a9dfa78  vmovaps xmm9, [rsp+0x90]
000076b67a9dfa81  vmovaps xmm10, [rsp+0xA0]
000076b67a9dfa8a  vmovaps xmm11, [rsp+0xB0]
000076b67a9dfa93  vmovaps xmm12, [rsp+0xC0]
000076b67a9dfa9c  vmovaps xmm14, [rsp+0xD0]
000076b67a9dfaa5  vmovaps xmm15, [rsp+0xE0]
000076b67a9dfaae  add rsp, 0xF0
000076b67a9dfab5  pop r11
000076b67a9dfab7  pop r10
000076b67a9dfab9  pop r9
000076b67a9dfabb  pop r8
000076b67a9dfabd  pop rsi
000076b67a9dfabe  pop rdi
000076b67a9dfabf  pop rdx
000076b67a9dfac0  pop rcx
000076b67a9dfac1  pop rax
000076b67a9dfac2  add rsp, 0x08
000076b67a9dfac6  jmp 0x000076B67A9DC458
000076b67a9dfacb  sub rsp, 0x08
000076b67a9dfacf  push rax
000076b67a9dfad0  push rcx
000076b67a9dfad1  push rdx
000076b67a9dfad2  push rdi
000076b67a9dfad3  push rsi
000076b67a9dfad4  push r8
000076b67a9dfad6  push r9
000076b67a9dfad8  push r10
000076b67a9dfada  push r11
000076b67a9dfadc  sub rsp, 0xF0
000076b67a9dfae3  vmovaps [rsp], xmm0
000076b67a9dfae8  vmovaps [rsp+0x10], xmm1
000076b67a9dfaee  vmovaps [rsp+0x20], xmm2
000076b67a9dfaf4  vmovaps [rsp+0x30], xmm3
000076b67a9dfafa  vmovaps [rsp+0x40], xmm4
000076b67a9dfb00  vmovaps [rsp+0x50], xmm5
000076b67a9dfb06  vmovaps [rsp+0x60], xmm6
000076b67a9dfb0c  vmovaps [rsp+0x70], xmm7
000076b67a9dfb12  vmovaps [rsp+0x80], xmm8
000076b67a9dfb1b  vmovaps [rsp+0x90], xmm9
000076b67a9dfb24  vmovaps [rsp+0xA0], xmm10
000076b67a9dfb2d  vmovaps [rsp+0xB0], xmm11
000076b67a9dfb36  vmovaps [rsp+0xC0], xmm12
000076b67a9dfb3f  vmovaps [rsp+0xD0], xmm13
000076b67a9dfb48  vmovaps [rsp+0xE0], xmm14
000076b67a9dfb51  sub rsp, 0x30
000076b67a9dfb55  movaps [rsp], xmm15
000076b67a9dfb5a  movaps [rsp+0x10], xmm1
000076b67a9dfb5f  movaps [rsp+0x20], xmm5
000076b67a9dfb64  lea rdi, [rsp]
000076b67a9dfb68  mov esi, 0x00
000076b67a9dfb6d  mov rax, 0x63C5EF2DF530
000076b67a9dfb77  call rax
000076b67a9dfb79  movaps xmm15, [rsp]
000076b67a9dfb7e  add rsp, 0x30
000076b67a9dfb82  vmovaps xmm0, [rsp]
000076b67a9dfb87  vmovaps xmm1, [rsp+0x10]
000076b67a9dfb8d  vmovaps xmm2, [rsp+0x20]
000076b67a9dfb93  vmovaps xmm3, [rsp+0x30]
000076b67a9dfb99  vmovaps xmm4, [rsp+0x40]
000076b67a9dfb9f  vmovaps xmm5, [rsp+0x50]
000076b67a9dfba5  vmovaps xmm6, [rsp+0x60]
000076b67a9dfbab  vmovaps xmm7, [rsp+0x70]
000076b67a9dfbb1  vmovaps xmm8, [rsp+0x80]
000076b67a9dfbba  vmovaps xmm9, [rsp+0x90]
000076b67a9dfbc3  vmovaps xmm10, [rsp+0xA0]
000076b67a9dfbcc  vmovaps xmm11, [rsp+0xB0]
000076b67a9dfbd5  vmovaps xmm12, [rsp+0xC0]
000076b67a9dfbde  vmovaps xmm13, [rsp+0xD0]
000076b67a9dfbe7  vmovaps xmm14, [rsp+0xE0]
000076b67a9dfbf0  add rsp, 0xF0
000076b67a9dfbf7  pop r11
000076b67a9dfbf9  pop r10
000076b67a9dfbfb  pop r9
000076b67a9dfbfd  pop r8
000076b67a9dfbff  pop rsi
000076b67a9dfc00  pop rdi
000076b67a9dfc01  pop rdx
000076b67a9dfc02  pop rcx
000076b67a9dfc03  pop rax
000076b67a9dfc04  add rsp, 0x08
000076b67a9dfc08  jmp 0x000076B67A9DC473
000076b67a9dfc0d  call 0x000076B67A8B52F0
000076b67a9dfc12  jmp 0x000076B67A9DC4CE
000076b67a9dfc17  sub rsp, 0x08
000076b67a9dfc1b  push rax
000076b67a9dfc1c  push rcx
000076b67a9dfc1d  push rdx
000076b67a9dfc1e  push rdi
000076b67a9dfc1f  push rsi
000076b67a9dfc20  push r8
000076b67a9dfc22  push r9
000076b67a9dfc24  push r10
000076b67a9dfc26  push r11
000076b67a9dfc28  sub rsp, 0xF0
000076b67a9dfc2f  vmovaps [rsp], xmm0
000076b67a9dfc34  vmovaps [rsp+0x10], xmm1
000076b67a9dfc3a  vmovaps [rsp+0x20], xmm2
000076b67a9dfc40  vmovaps [rsp+0x30], xmm3
000076b67a9dfc46  vmovaps [rsp+0x40], xmm4
000076b67a9dfc4c  vmovaps [rsp+0x50], xmm5
000076b67a9dfc52  vmovaps [rsp+0x60], xmm6
000076b67a9dfc58  vmovaps [rsp+0x70], xmm7
000076b67a9dfc5e  vmovaps [rsp+0x80], xmm8
000076b67a9dfc67  vmovaps [rsp+0x90], xmm10
000076b67a9dfc70  vmovaps [rsp+0xA0], xmm11
000076b67a9dfc79  vmovaps [rsp+0xB0], xmm12
000076b67a9dfc82  vmovaps [rsp+0xC0], xmm13
000076b67a9dfc8b  vmovaps [rsp+0xD0], xmm14
000076b67a9dfc94  vmovaps [rsp+0xE0], xmm15
000076b67a9dfc9d  sub rsp, 0x30
000076b67a9dfca1  movaps [rsp], xmm9
000076b67a9dfca6  movaps [rsp+0x10], xmm8
000076b67a9dfcac  movaps [rsp+0x20], xmm11
000076b67a9dfcb2  lea rdi, [rsp]
000076b67a9dfcb6  mov esi, 0x00
000076b67a9dfcbb  mov rax, 0x63C5EF2DF530
000076b67a9dfcc5  call rax
000076b67a9dfcc7  movaps xmm9, [rsp]
000076b67a9dfccc  add rsp, 0x30
000076b67a9dfcd0  vmovaps xmm0, [rsp]
000076b67a9dfcd5  vmovaps xmm1, [rsp+0x10]
000076b67a9dfcdb  vmovaps xmm2, [rsp+0x20]
000076b67a9dfce1  vmovaps xmm3, [rsp+0x30]
000076b67a9dfce7  vmovaps xmm4, [rsp+0x40]
000076b67a9dfced  vmovaps xmm5, [rsp+0x50]
000076b67a9dfcf3  vmovaps xmm6, [rsp+0x60]
000076b67a9dfcf9  vmovaps xmm7, [rsp+0x70]
000076b67a9dfcff  vmovaps xmm8, [rsp+0x80]
000076b67a9dfd08  vmovaps xmm10, [rsp+0x90]
000076b67a9dfd11  vmovaps xmm11, [rsp+0xA0]
000076b67a9dfd1a  vmovaps xmm12, [rsp+0xB0]
000076b67a9dfd23  vmovaps xmm13, [rsp+0xC0]
000076b67a9dfd2c  vmovaps xmm14, [rsp+0xD0]
000076b67a9dfd35  vmovaps xmm15, [rsp+0xE0]
000076b67a9dfd3e  add rsp, 0xF0
000076b67a9dfd45  pop r11
000076b67a9dfd47  pop r10
000076b67a9dfd49  pop r9
000076b67a9dfd4b  pop r8
000076b67a9dfd4d  pop rsi
000076b67a9dfd4e  pop rdi
000076b67a9dfd4f  pop rdx
000076b67a9dfd50  pop rcx
000076b67a9dfd51  pop rax
000076b67a9dfd52  add rsp, 0x08
000076b67a9dfd56  jmp 0x000076B67A9DC505
000076b67a9dfd5b  sub rsp, 0x08
000076b67a9dfd5f  push rax
000076b67a9dfd60  push rcx
000076b67a9dfd61  push rdx
000076b67a9dfd62  push rdi
000076b67a9dfd63  push rsi
000076b67a9dfd64  push r8
000076b67a9dfd66  push r9
000076b67a9dfd68  push r10
000076b67a9dfd6a  push r11
000076b67a9dfd6c  sub rsp, 0xF0
000076b67a9dfd73  vmovaps [rsp], xmm0
000076b67a9dfd78  vmovaps [rsp+0x10], xmm1
000076b67a9dfd7e  vmovaps [rsp+0x20], xmm2
000076b67a9dfd84  vmovaps [rsp+0x30], xmm3
000076b67a9dfd8a  vmovaps [rsp+0x40], xmm4
000076b67a9dfd90  vmovaps [rsp+0x50], xmm5
000076b67a9dfd96  vmovaps [rsp+0x60], xmm6
000076b67a9dfd9c  vmovaps [rsp+0x70], xmm7
000076b67a9dfda2  vmovaps [rsp+0x80], xmm8
000076b67a9dfdab  vmovaps [rsp+0x90], xmm9
000076b67a9dfdb4  vmovaps [rsp+0xA0], xmm10
000076b67a9dfdbd  vmovaps [rsp+0xB0], xmm12
000076b67a9dfdc6  vmovaps [rsp+0xC0], xmm13
000076b67a9dfdcf  vmovaps [rsp+0xD0], xmm14
000076b67a9dfdd8  vmovaps [rsp+0xE0], xmm15
000076b67a9dfde1  sub rsp, 0x30
000076b67a9dfde5  movaps [rsp], xmm11
000076b67a9dfdea  movaps [rsp+0x10], xmm10
000076b67a9dfdf0  movaps [rsp+0x20], xmm6
000076b67a9dfdf5  lea rdi, [rsp]
000076b67a9dfdf9  mov esi, 0x00
000076b67a9dfdfe  mov rax, 0x63C5EF2DF530
000076b67a9dfe08  call rax
000076b67a9dfe0a  movaps xmm11, [rsp]
000076b67a9dfe0f  add rsp, 0x30
000076b67a9dfe13  vmovaps xmm0, [rsp]
000076b67a9dfe18  vmovaps xmm1, [rsp+0x10]
000076b67a9dfe1e  vmovaps xmm2, [rsp+0x20]
000076b67a9dfe24  vmovaps xmm3, [rsp+0x30]
000076b67a9dfe2a  vmovaps xmm4, [rsp+0x40]
000076b67a9dfe30  vmovaps xmm5, [rsp+0x50]
000076b67a9dfe36  vmovaps xmm6, [rsp+0x60]
000076b67a9dfe3c  vmovaps xmm7, [rsp+0x70]
000076b67a9dfe42  vmovaps xmm8, [rsp+0x80]
000076b67a9dfe4b  vmovaps xmm9, [rsp+0x90]
000076b67a9dfe54  vmovaps xmm10, [rsp+0xA0]
000076b67a9dfe5d  vmovaps xmm12, [rsp+0xB0]
000076b67a9dfe66  vmovaps xmm13, [rsp+0xC0]
000076b67a9dfe6f  vmovaps xmm14, [rsp+0xD0]
000076b67a9dfe78  vmovaps xmm15, [rsp+0xE0]
000076b67a9dfe81  add rsp, 0xF0
000076b67a9dfe88  pop r11
000076b67a9dfe8a  pop r10
000076b67a9dfe8c  pop r9
000076b67a9dfe8e  pop r8
000076b67a9dfe90  pop rsi
000076b67a9dfe91  pop rdi
000076b67a9dfe92  pop rdx
000076b67a9dfe93  pop rcx
000076b67a9dfe94  pop rax
000076b67a9dfe95  add rsp, 0x08
000076b67a9dfe99  jmp 0x000076B67A9DC520
000076b67a9dfe9e  sub rsp, 0x08
000076b67a9dfea2  push rax
000076b67a9dfea3  push rcx
000076b67a9dfea4  push rdx
000076b67a9dfea5  push rdi
000076b67a9dfea6  push rsi
000076b67a9dfea7  push r8
000076b67a9dfea9  push r9
000076b67a9dfeab  push r10
000076b67a9dfead  push r11
000076b67a9dfeaf  sub rsp, 0xF0
000076b67a9dfeb6  vmovaps [rsp], xmm0
000076b67a9dfebb  vmovaps [rsp+0x10], xmm1
000076b67a9dfec1  vmovaps [rsp+0x20], xmm2
000076b67a9dfec7  vmovaps [rsp+0x30], xmm3
000076b67a9dfecd  vmovaps [rsp+0x40], xmm4
000076b67a9dfed3  vmovaps [rsp+0x50], xmm5
000076b67a9dfed9  vmovaps [rsp+0x60], xmm6
000076b67a9dfedf  vmovaps [rsp+0x70], xmm7
000076b67a9dfee5  vmovaps [rsp+0x80], xmm8
000076b67a9dfeee  vmovaps [rsp+0x90], xmm9
000076b67a9dfef7  vmovaps [rsp+0xA0], xmm11
000076b67a9dff00  vmovaps [rsp+0xB0], xmm12
000076b67a9dff09  vmovaps [rsp+0xC0], xmm13
000076b67a9dff12  vmovaps [rsp+0xD0], xmm14
000076b67a9dff1b  vmovaps [rsp+0xE0], xmm15
000076b67a9dff24  sub rsp, 0x30
000076b67a9dff28  movaps [rsp], xmm10
000076b67a9dff2d  movaps [rsp+0x10], xmm14
000076b67a9dff33  movaps [rsp+0x20], xmm4
000076b67a9dff38  lea rdi, [rsp]
000076b67a9dff3c  mov esi, 0x00
000076b67a9dff41  mov rax, 0x63C5EF2DF530
000076b67a9dff4b  call rax
000076b67a9dff4d  movaps xmm10, [rsp]
000076b67a9dff52  add rsp, 0x30
000076b67a9dff56  vmovaps xmm0, [rsp]
000076b67a9dff5b  vmovaps xmm1, [rsp+0x10]
000076b67a9dff61  vmovaps xmm2, [rsp+0x20]
000076b67a9dff67  vmovaps xmm3, [rsp+0x30]
000076b67a9dff6d  vmovaps xmm4, [rsp+0x40]
000076b67a9dff73  vmovaps xmm5, [rsp+0x50]
000076b67a9dff79  vmovaps xmm6, [rsp+0x60]
000076b67a9dff7f  vmovaps xmm7, [rsp+0x70]
000076b67a9dff85  vmovaps xmm8, [rsp+0x80]
000076b67a9dff8e  vmovaps xmm9, [rsp+0x90]
000076b67a9dff97  vmovaps xmm11, [rsp+0xA0]
000076b67a9dffa0  vmovaps xmm12, [rsp+0xB0]
000076b67a9dffa9  vmovaps xmm13, [rsp+0xC0]
000076b67a9dffb2  vmovaps xmm14, [rsp+0xD0]
000076b67a9dffbb  vmovaps xmm15, [rsp+0xE0]
000076b67a9dffc4  add rsp, 0xF0
000076b67a9dffcb  pop r11
000076b67a9dffcd  pop r10
000076b67a9dffcf  pop r9
000076b67a9dffd1  pop r8
000076b67a9dffd3  pop rsi
000076b67a9dffd4  pop rdi
000076b67a9dffd5  pop rdx
000076b67a9dffd6  pop rcx
000076b67a9dffd7  pop rax
000076b67a9dffd8  add rsp, 0x08
000076b67a9dffdc  jmp 0x000076B67A9DC53B
000076b67a9dffe1  sub rsp, 0x08
000076b67a9dffe5  push rax
000076b67a9dffe6  push rcx
000076b67a9dffe7  push rdx
000076b67a9dffe8  push rdi
000076b67a9dffe9  push rsi
000076b67a9dffea  push r8
000076b67a9dffec  push r9
000076b67a9dffee  push r10
000076b67a9dfff0  push r11
000076b67a9dfff2  sub rsp, 0xF0
000076b67a9dfff9  vmovaps [rsp], xmm0
000076b67a9dfffe  vmovaps [rsp+0x10], xmm1
000076b67a9e0004  vmovaps [rsp+0x20], xmm2
000076b67a9e000a  vmovaps [rsp+0x30], xmm3
000076b67a9e0010  vmovaps [rsp+0x40], xmm4
000076b67a9e0016  vmovaps [rsp+0x50], xmm5
000076b67a9e001c  vmovaps [rsp+0x60], xmm6
000076b67a9e0022  vmovaps [rsp+0x70], xmm7
000076b67a9e0028  vmovaps [rsp+0x80], xmm9
000076b67a9e0031  vmovaps [rsp+0x90], xmm10
000076b67a9e003a  vmovaps [rsp+0xA0], xmm11
000076b67a9e0043  vmovaps [rsp+0xB0], xmm12
000076b67a9e004c  vmovaps [rsp+0xC0], xmm13
000076b67a9e0055  vmovaps [rsp+0xD0], xmm14
000076b67a9e005e  vmovaps [rsp+0xE0], xmm15
000076b67a9e0067  sub rsp, 0x30
000076b67a9e006b  movaps [rsp], xmm8
000076b67a9e0070  movaps [rsp+0x10], xmm1
000076b67a9e0075  movaps [rsp+0x20], xmm14
000076b67a9e007b  lea rdi, [rsp]
000076b67a9e007f  mov esi, 0x00
000076b67a9e0084  mov rax, 0x63C5EF2DF530
000076b67a9e008e  call rax
000076b67a9e0090  movaps xmm8, [rsp]
000076b67a9e0095  add rsp, 0x30
000076b67a9e0099  vmovaps xmm0, [rsp]
000076b67a9e009e  vmovaps xmm1, [rsp+0x10]
000076b67a9e00a4  vmovaps xmm2, [rsp+0x20]
000076b67a9e00aa  vmovaps xmm3, [rsp+0x30]
000076b67a9e00b0  vmovaps xmm4, [rsp+0x40]
000076b67a9e00b6  vmovaps xmm5, [rsp+0x50]
000076b67a9e00bc  vmovaps xmm6, [rsp+0x60]
000076b67a9e00c2  vmovaps xmm7, [rsp+0x70]
000076b67a9e00c8  vmovaps xmm9, [rsp+0x80]
000076b67a9e00d1  vmovaps xmm10, [rsp+0x90]
000076b67a9e00da  vmovaps xmm11, [rsp+0xA0]
000076b67a9e00e3  vmovaps xmm12, [rsp+0xB0]
000076b67a9e00ec  vmovaps xmm13, [rsp+0xC0]
000076b67a9e00f5  vmovaps xmm14, [rsp+0xD0]
000076b67a9e00fe  vmovaps xmm15, [rsp+0xE0]
000076b67a9e0107  add rsp, 0xF0
000076b67a9e010e  pop r11
000076b67a9e0110  pop r10
000076b67a9e0112  pop r9
000076b67a9e0114  pop r8
000076b67a9e0116  pop rsi
000076b67a9e0117  pop rdi
000076b67a9e0118  pop rdx
000076b67a9e0119  pop rcx
000076b67a9e011a  pop rax
000076b67a9e011b  add rsp, 0x08
000076b67a9e011f  jmp 0x000076B67A9DC561
000076b67a9e0124  sub rsp, 0x08
000076b67a9e0128  push rax
000076b67a9e0129  push rcx
000076b67a9e012a  push rdx
000076b67a9e012b  push rdi
000076b67a9e012c  push rsi
000076b67a9e012d  push r8
000076b67a9e012f  push r9
000076b67a9e0131  push r10
000076b67a9e0133  push r11
000076b67a9e0135  sub rsp, 0xF0
000076b67a9e013c  vmovaps [rsp], xmm0
000076b67a9e0141  vmovaps [rsp+0x10], xmm1
000076b67a9e0147  vmovaps [rsp+0x20], xmm2
000076b67a9e014d  vmovaps [rsp+0x30], xmm3
000076b67a9e0153  vmovaps [rsp+0x40], xmm4
000076b67a9e0159  vmovaps [rsp+0x50], xmm5
000076b67a9e015f  vmovaps [rsp+0x60], xmm7
000076b67a9e0165  vmovaps [rsp+0x70], xmm8
000076b67a9e016b  vmovaps [rsp+0x80], xmm9
000076b67a9e0174  vmovaps [rsp+0x90], xmm10
000076b67a9e017d  vmovaps [rsp+0xA0], xmm11
000076b67a9e0186  vmovaps [rsp+0xB0], xmm12
000076b67a9e018f  vmovaps [rsp+0xC0], xmm13
000076b67a9e0198  vmovaps [rsp+0xD0], xmm14
000076b67a9e01a1  vmovaps [rsp+0xE0], xmm15
000076b67a9e01aa  sub rsp, 0x30
000076b67a9e01ae  movaps [rsp], xmm6
000076b67a9e01b2  movaps [rsp+0x10], xmm1
000076b67a9e01b7  movaps [rsp+0x20], xmm14
000076b67a9e01bd  lea rdi, [rsp]
000076b67a9e01c1  mov esi, 0x00
000076b67a9e01c6  mov rax, 0x63C5EF2DF530
000076b67a9e01d0  call rax
000076b67a9e01d2  movaps xmm6, [rsp]
000076b67a9e01d6  add rsp, 0x30
000076b67a9e01da  vmovaps xmm0, [rsp]
000076b67a9e01df  vmovaps xmm1, [rsp+0x10]
000076b67a9e01e5  vmovaps xmm2, [rsp+0x20]
000076b67a9e01eb  vmovaps xmm3, [rsp+0x30]
000076b67a9e01f1  vmovaps xmm4, [rsp+0x40]
000076b67a9e01f7  vmovaps xmm5, [rsp+0x50]
000076b67a9e01fd  vmovaps xmm7, [rsp+0x60]
000076b67a9e0203  vmovaps xmm8, [rsp+0x70]
000076b67a9e0209  vmovaps xmm9, [rsp+0x80]
000076b67a9e0212  vmovaps xmm10, [rsp+0x90]
000076b67a9e021b  vmovaps xmm11, [rsp+0xA0]
000076b67a9e0224  vmovaps xmm12, [rsp+0xB0]
000076b67a9e022d  vmovaps xmm13, [rsp+0xC0]
000076b67a9e0236  vmovaps xmm14, [rsp+0xD0]
000076b67a9e023f  vmovaps xmm15, [rsp+0xE0]
000076b67a9e0248  add rsp, 0xF0
000076b67a9e024f  pop r11
000076b67a9e0251  pop r10
000076b67a9e0253  pop r9
000076b67a9e0255  pop r8
000076b67a9e0257  pop rsi
000076b67a9e0258  pop rdi
000076b67a9e0259  pop rdx
000076b67a9e025a  pop rcx
000076b67a9e025b  pop rax
000076b67a9e025c  add rsp, 0x08
000076b67a9e0260  jmp 0x000076B67A9DC58D
000076b67a9e0265  sub rsp, 0x08
000076b67a9e0269  push rax
000076b67a9e026a  push rcx
000076b67a9e026b  push rdx
000076b67a9e026c  push rdi
000076b67a9e026d  push rsi
000076b67a9e026e  push r8
000076b67a9e0270  push r9
000076b67a9e0272  push r10
000076b67a9e0274  push r11
000076b67a9e0276  sub rsp, 0xF0
000076b67a9e027d  vmovaps [rsp], xmm0
000076b67a9e0282  vmovaps [rsp+0x10], xmm1
000076b67a9e0288  vmovaps [rsp+0x20], xmm2
000076b67a9e028e  vmovaps [rsp+0x30], xmm3
000076b67a9e0294  vmovaps [rsp+0x40], xmm4
000076b67a9e029a  vmovaps [rsp+0x50], xmm5
000076b67a9e02a0  vmovaps [rsp+0x60], xmm6
000076b67a9e02a6  vmovaps [rsp+0x70], xmm7
000076b67a9e02ac  vmovaps [rsp+0x80], xmm8
000076b67a9e02b5  vmovaps [rsp+0x90], xmm9
000076b67a9e02be  vmovaps [rsp+0xA0], xmm10
000076b67a9e02c7  vmovaps [rsp+0xB0], xmm11
000076b67a9e02d0  vmovaps [rsp+0xC0], xmm12
000076b67a9e02d9  vmovaps [rsp+0xD0], xmm13
000076b67a9e02e2  vmovaps [rsp+0xE0], xmm15
000076b67a9e02eb  sub rsp, 0x30
000076b67a9e02ef  movaps [rsp], xmm14
000076b67a9e02f4  movaps [rsp+0x10], xmm12
000076b67a9e02fa  movaps [rsp+0x20], xmm1
000076b67a9e02ff  lea rdi, [rsp]
000076b67a9e0303  mov esi, 0x00
000076b67a9e0308  mov rax, 0x63C5EF2DF530
000076b67a9e0312  call rax
000076b67a9e0314  movaps xmm14, [rsp]
000076b67a9e0319  add rsp, 0x30
000076b67a9e031d  vmovaps xmm0, [rsp]
000076b67a9e0322  vmovaps xmm1, [rsp+0x10]
000076b67a9e0328  vmovaps xmm2, [rsp+0x20]
000076b67a9e032e  vmovaps xmm3, [rsp+0x30]
000076b67a9e0334  vmovaps xmm4, [rsp+0x40]
000076b67a9e033a  vmovaps xmm5, [rsp+0x50]
000076b67a9e0340  vmovaps xmm6, [rsp+0x60]
000076b67a9e0346  vmovaps xmm7, [rsp+0x70]
000076b67a9e034c  vmovaps xmm8, [rsp+0x80]
000076b67a9e0355  vmovaps xmm9, [rsp+0x90]
000076b67a9e035e  vmovaps xmm10, [rsp+0xA0]
000076b67a9e0367  vmovaps xmm11, [rsp+0xB0]
000076b67a9e0370  vmovaps xmm12, [rsp+0xC0]
000076b67a9e0379  vmovaps xmm13, [rsp+0xD0]
000076b67a9e0382  vmovaps xmm15, [rsp+0xE0]
000076b67a9e038b  add rsp, 0xF0
000076b67a9e0392  pop r11
000076b67a9e0394  pop r10
000076b67a9e0396  pop r9
000076b67a9e0398  pop r8
000076b67a9e039a  pop rsi
000076b67a9e039b  pop rdi
000076b67a9e039c  pop rdx
000076b67a9e039d  pop rcx
000076b67a9e039e  pop rax
000076b67a9e039f  add rsp, 0x08
000076b67a9e03a3  jmp 0x000076B67A9DC5B3
000076b67a9e03a8  sub rsp, 0x08
000076b67a9e03ac  push rax
000076b67a9e03ad  push rcx
000076b67a9e03ae  push rdx
000076b67a9e03af  push rdi
000076b67a9e03b0  push rsi
000076b67a9e03b1  push r8
000076b67a9e03b3  push r9
000076b67a9e03b5  push r10
000076b67a9e03b7  push r11
000076b67a9e03b9  sub rsp, 0xF0
000076b67a9e03c0  vmovaps [rsp], xmm0
000076b67a9e03c5  vmovaps [rsp+0x10], xmm2
000076b67a9e03cb  vmovaps [rsp+0x20], xmm3
000076b67a9e03d1  vmovaps [rsp+0x30], xmm4
000076b67a9e03d7  vmovaps [rsp+0x40], xmm5
000076b67a9e03dd  vmovaps [rsp+0x50], xmm6
000076b67a9e03e3  vmovaps [rsp+0x60], xmm7
000076b67a9e03e9  vmovaps [rsp+0x70], xmm8
000076b67a9e03ef  vmovaps [rsp+0x80], xmm9
000076b67a9e03f8  vmovaps [rsp+0x90], xmm10
000076b67a9e0401  vmovaps [rsp+0xA0], xmm11
000076b67a9e040a  vmovaps [rsp+0xB0], xmm12
000076b67a9e0413  vmovaps [rsp+0xC0], xmm13
000076b67a9e041c  vmovaps [rsp+0xD0], xmm14
000076b67a9e0425  vmovaps [rsp+0xE0], xmm15
000076b67a9e042e  sub rsp, 0x30
000076b67a9e0432  movaps [rsp], xmm1
000076b67a9e0436  movaps [rsp+0x10], xmm13
000076b67a9e043c  movaps [rsp+0x20], xmm9
000076b67a9e0442  lea rdi, [rsp]
000076b67a9e0446  mov esi, 0x00
000076b67a9e044b  mov rax, 0x63C5EF2DF530
000076b67a9e0455  call rax
000076b67a9e0457  movaps xmm1, [rsp]
000076b67a9e045b  add rsp, 0x30
000076b67a9e045f  vmovaps xmm0, [rsp]
000076b67a9e0464  vmovaps xmm2, [rsp+0x10]
000076b67a9e046a  vmovaps xmm3, [rsp+0x20]
000076b67a9e0470  vmovaps xmm4, [rsp+0x30]
000076b67a9e0476  vmovaps xmm5, [rsp+0x40]
000076b67a9e047c  vmovaps xmm6, [rsp+0x50]
000076b67a9e0482  vmovaps xmm7, [rsp+0x60]
000076b67a9e0488  vmovaps xmm8, [rsp+0x70]
000076b67a9e048e  vmovaps xmm9, [rsp+0x80]
000076b67a9e0497  vmovaps xmm10, [rsp+0x90]
000076b67a9e04a0  vmovaps xmm11, [rsp+0xA0]
000076b67a9e04a9  vmovaps xmm12, [rsp+0xB0]
000076b67a9e04b2  vmovaps xmm13, [rsp+0xC0]
000076b67a9e04bb  vmovaps xmm14, [rsp+0xD0]
000076b67a9e04c4  vmovaps xmm15, [rsp+0xE0]
000076b67a9e04cd  add rsp, 0xF0
000076b67a9e04d4  pop r11
000076b67a9e04d6  pop r10
000076b67a9e04d8  pop r9
000076b67a9e04da  pop r8
000076b67a9e04dc  pop rsi
000076b67a9e04dd  pop rdi
000076b67a9e04de  pop rdx
000076b67a9e04df  pop rcx
000076b67a9e04e0  pop rax
000076b67a9e04e1  add rsp, 0x08
000076b67a9e04e5  jmp 0x000076B67A9DC5CD
000076b67a9e04ea  sub rsp, 0x08
000076b67a9e04ee  push rax
000076b67a9e04ef  push rcx
000076b67a9e04f0  push rdx
000076b67a9e04f1  push rdi
000076b67a9e04f2  push rsi
000076b67a9e04f3  push r8
000076b67a9e04f5  push r9
000076b67a9e04f7  push r10
000076b67a9e04f9  push r11
000076b67a9e04fb  sub rsp, 0xF0
000076b67a9e0502  vmovaps [rsp], xmm0
000076b67a9e0507  vmovaps [rsp+0x10], xmm1
000076b67a9e050d  vmovaps [rsp+0x20], xmm2
000076b67a9e0513  vmovaps [rsp+0x30], xmm3
000076b67a9e0519  vmovaps [rsp+0x40], xmm4
000076b67a9e051f  vmovaps [rsp+0x50], xmm5
000076b67a9e0525  vmovaps [rsp+0x60], xmm6
000076b67a9e052b  vmovaps [rsp+0x70], xmm7
000076b67a9e0531  vmovaps [rsp+0x80], xmm8
000076b67a9e053a  vmovaps [rsp+0x90], xmm9
000076b67a9e0543  vmovaps [rsp+0xA0], xmm10
000076b67a9e054c  vmovaps [rsp+0xB0], xmm11
000076b67a9e0555  vmovaps [rsp+0xC0], xmm13
000076b67a9e055e  vmovaps [rsp+0xD0], xmm14
000076b67a9e0567  vmovaps [rsp+0xE0], xmm15
000076b67a9e0570  sub rsp, 0x30
000076b67a9e0574  movaps [rsp], xmm12
000076b67a9e0579  movaps [rsp+0x10], xmm7
000076b67a9e057e  movaps [rsp+0x20], xmm13
000076b67a9e0584  lea rdi, [rsp]
000076b67a9e0588  mov esi, 0x00
000076b67a9e058d  mov rax, 0x63C5EF2DF530
000076b67a9e0597  call rax
000076b67a9e0599  movaps xmm12, [rsp]
000076b67a9e059e  add rsp, 0x30
000076b67a9e05a2  vmovaps xmm0, [rsp]
000076b67a9e05a7  vmovaps xmm1, [rsp+0x10]
000076b67a9e05ad  vmovaps xmm2, [rsp+0x20]
000076b67a9e05b3  vmovaps xmm3, [rsp+0x30]
000076b67a9e05b9  vmovaps xmm4, [rsp+0x40]
000076b67a9e05bf  vmovaps xmm5, [rsp+0x50]
000076b67a9e05c5  vmovaps xmm6, [rsp+0x60]
000076b67a9e05cb  vmovaps xmm7, [rsp+0x70]
000076b67a9e05d1  vmovaps xmm8, [rsp+0x80]
000076b67a9e05da  vmovaps xmm9, [rsp+0x90]
000076b67a9e05e3  vmovaps xmm10, [rsp+0xA0]
000076b67a9e05ec  vmovaps xmm11, [rsp+0xB0]
000076b67a9e05f5  vmovaps xmm13, [rsp+0xC0]
000076b67a9e05fe  vmovaps xmm14, [rsp+0xD0]
000076b67a9e0607  vmovaps xmm15, [rsp+0xE0]
000076b67a9e0610  add rsp, 0xF0
000076b67a9e0617  pop r11
000076b67a9e0619  pop r10
000076b67a9e061b  pop r9
000076b67a9e061d  pop r8
000076b67a9e061f  pop rsi
000076b67a9e0620  pop rdi
000076b67a9e0621  pop rdx
000076b67a9e0622  pop rcx
000076b67a9e0623  pop rax
000076b67a9e0624  add rsp, 0x08
000076b67a9e0628  jmp 0x000076B67A9DC5F4
000076b67a9e062d  sub rsp, 0x08
000076b67a9e0631  push rax
000076b67a9e0632  push rcx
000076b67a9e0633  push rdx
000076b67a9e0634  push rdi
000076b67a9e0635  push rsi
000076b67a9e0636  push r8
000076b67a9e0638  push r9
000076b67a9e063a  push r10
000076b67a9e063c  push r11
000076b67a9e063e  sub rsp, 0xF0
000076b67a9e0645  vmovaps [rsp], xmm0
000076b67a9e064a  vmovaps [rsp+0x10], xmm1
000076b67a9e0650  vmovaps [rsp+0x20], xmm2
000076b67a9e0656  vmovaps [rsp+0x30], xmm3
000076b67a9e065c  vmovaps [rsp+0x40], xmm4
000076b67a9e0662  vmovaps [rsp+0x50], xmm5
000076b67a9e0668  vmovaps [rsp+0x60], xmm6
000076b67a9e066e  vmovaps [rsp+0x70], xmm7
000076b67a9e0674  vmovaps [rsp+0x80], xmm8
000076b67a9e067d  vmovaps [rsp+0x90], xmm9
000076b67a9e0686  vmovaps [rsp+0xA0], xmm10
000076b67a9e068f  vmovaps [rsp+0xB0], xmm11
000076b67a9e0698  vmovaps [rsp+0xC0], xmm12
000076b67a9e06a1  vmovaps [rsp+0xD0], xmm14
000076b67a9e06aa  vmovaps [rsp+0xE0], xmm15
000076b67a9e06b3  sub rsp, 0x30
000076b67a9e06b7  movaps [rsp], xmm13
000076b67a9e06bc  movaps [rsp+0x10], xmm15
000076b67a9e06c2  movaps [rsp+0x20], xmm8
000076b67a9e06c8  lea rdi, [rsp]
000076b67a9e06cc  mov esi, 0x00
000076b67a9e06d1  mov rax, 0x63C5EF2DF530
000076b67a9e06db  call rax
000076b67a9e06dd  movaps xmm13, [rsp]
000076b67a9e06e2  add rsp, 0x30
000076b67a9e06e6  vmovaps xmm0, [rsp]
000076b67a9e06eb  vmovaps xmm1, [rsp+0x10]
000076b67a9e06f1  vmovaps xmm2, [rsp+0x20]
000076b67a9e06f7  vmovaps xmm3, [rsp+0x30]
000076b67a9e06fd  vmovaps xmm4, [rsp+0x40]
000076b67a9e0703  vmovaps xmm5, [rsp+0x50]
000076b67a9e0709  vmovaps xmm6, [rsp+0x60]
000076b67a9e070f  vmovaps xmm7, [rsp+0x70]
000076b67a9e0715  vmovaps xmm8, [rsp+0x80]
000076b67a9e071e  vmovaps xmm9, [rsp+0x90]
000076b67a9e0727  vmovaps xmm10, [rsp+0xA0]
000076b67a9e0730  vmovaps xmm11, [rsp+0xB0]
000076b67a9e0739  vmovaps xmm12, [rsp+0xC0]
000076b67a9e0742  vmovaps xmm14, [rsp+0xD0]
000076b67a9e074b  vmovaps xmm15, [rsp+0xE0]
000076b67a9e0754  add rsp, 0xF0
000076b67a9e075b  pop r11
000076b67a9e075d  pop r10
000076b67a9e075f  pop r9
000076b67a9e0761  pop r8
000076b67a9e0763  pop rsi
000076b67a9e0764  pop rdi
000076b67a9e0765  pop rdx
000076b67a9e0766  pop rcx
000076b67a9e0767  pop rax
000076b67a9e0768  add rsp, 0x08
000076b67a9e076c  jmp 0x000076B67A9DC60F
000076b67a9e0771  sub rsp, 0x08
000076b67a9e0775  push rax
000076b67a9e0776  push rcx
000076b67a9e0777  push rdx
000076b67a9e0778  push rdi
000076b67a9e0779  push rsi
000076b67a9e077a  push r8
000076b67a9e077c  push r9
000076b67a9e077e  push r10
000076b67a9e0780  push r11
000076b67a9e0782  sub rsp, 0xF0
000076b67a9e0789  vmovaps [rsp], xmm0
000076b67a9e078e  vmovaps [rsp+0x10], xmm1
000076b67a9e0794  vmovaps [rsp+0x20], xmm2
000076b67a9e079a  vmovaps [rsp+0x30], xmm3
000076b67a9e07a0  vmovaps [rsp+0x40], xmm4
000076b67a9e07a6  vmovaps [rsp+0x50], xmm5
000076b67a9e07ac  vmovaps [rsp+0x60], xmm6
000076b67a9e07b2  vmovaps [rsp+0x70], xmm7
000076b67a9e07b8  vmovaps [rsp+0x80], xmm9
000076b67a9e07c1  vmovaps [rsp+0x90], xmm10
000076b67a9e07ca  vmovaps [rsp+0xA0], xmm11
000076b67a9e07d3  vmovaps [rsp+0xB0], xmm12
000076b67a9e07dc  vmovaps [rsp+0xC0], xmm13
000076b67a9e07e5  vmovaps [rsp+0xD0], xmm14
000076b67a9e07ee  vmovaps [rsp+0xE0], xmm15
000076b67a9e07f7  sub rsp, 0x30
000076b67a9e07fb  movaps [rsp], xmm8
000076b67a9e0800  movaps [rsp+0x10], xmm15
000076b67a9e0806  movaps [rsp+0x20], xmm9
000076b67a9e080c  lea rdi, [rsp]
000076b67a9e0810  mov esi, 0x00
000076b67a9e0815  mov rax, 0x63C5EF2DF530
000076b67a9e081f  call rax
000076b67a9e0821  movaps xmm8, [rsp]
000076b67a9e0826  add rsp, 0x30
000076b67a9e082a  vmovaps xmm0, [rsp]
000076b67a9e082f  vmovaps xmm1, [rsp+0x10]
000076b67a9e0835  vmovaps xmm2, [rsp+0x20]
000076b67a9e083b  vmovaps xmm3, [rsp+0x30]
000076b67a9e0841  vmovaps xmm4, [rsp+0x40]
000076b67a9e0847  vmovaps xmm5, [rsp+0x50]
000076b67a9e084d  vmovaps xmm6, [rsp+0x60]
000076b67a9e0853  vmovaps xmm7, [rsp+0x70]
000076b67a9e0859  vmovaps xmm9, [rsp+0x80]
000076b67a9e0862  vmovaps xmm10, [rsp+0x90]
000076b67a9e086b  vmovaps xmm11, [rsp+0xA0]
000076b67a9e0874  vmovaps xmm12, [rsp+0xB0]
000076b67a9e087d  vmovaps xmm13, [rsp+0xC0]
000076b67a9e0886  vmovaps xmm14, [rsp+0xD0]
000076b67a9e088f  vmovaps xmm15, [rsp+0xE0]
000076b67a9e0898  add rsp, 0xF0
000076b67a9e089f  pop r11
000076b67a9e08a1  pop r10
000076b67a9e08a3  pop r9
000076b67a9e08a5  pop r8
000076b67a9e08a7  pop rsi
000076b67a9e08a8  pop rdi
000076b67a9e08a9  pop rdx
000076b67a9e08aa  pop rcx
000076b67a9e08ab  pop rax
000076b67a9e08ac  add rsp, 0x08
000076b67a9e08b0  jmp 0x000076B67A9DC63D
000076b67a9e08b5  sub rsp, 0x08
000076b67a9e08b9  push rax
000076b67a9e08ba  push rcx
000076b67a9e08bb  push rdx
000076b67a9e08bc  push rdi
000076b67a9e08bd  push rsi
000076b67a9e08be  push r8
000076b67a9e08c0  push r9
000076b67a9e08c2  push r10
000076b67a9e08c4  push r11
000076b67a9e08c6  sub rsp, 0xF0
000076b67a9e08cd  vmovaps [rsp], xmm0
000076b67a9e08d2  vmovaps [rsp+0x10], xmm1
000076b67a9e08d8  vmovaps [rsp+0x20], xmm2
000076b67a9e08de  vmovaps [rsp+0x30], xmm3
000076b67a9e08e4  vmovaps [rsp+0x40], xmm4
000076b67a9e08ea  vmovaps [rsp+0x50], xmm5
000076b67a9e08f0  vmovaps [rsp+0x60], xmm6
000076b67a9e08f6  vmovaps [rsp+0x70], xmm7
000076b67a9e08fc  vmovaps [rsp+0x80], xmm8
000076b67a9e0905  vmovaps [rsp+0x90], xmm9
000076b67a9e090e  vmovaps [rsp+0xA0], xmm10
000076b67a9e0917  vmovaps [rsp+0xB0], xmm11
000076b67a9e0920  vmovaps [rsp+0xC0], xmm12
000076b67a9e0929  vmovaps [rsp+0xD0], xmm13
000076b67a9e0932  vmovaps [rsp+0xE0], xmm14
000076b67a9e093b  sub rsp, 0x30
000076b67a9e093f  movaps [rsp], xmm15
000076b67a9e0944  movaps [rsp+0x10], xmm11
000076b67a9e094a  movaps [rsp+0x20], xmm6
000076b67a9e094f  lea rdi, [rsp]
000076b67a9e0953  mov esi, 0x00
000076b67a9e0958  mov rax, 0x63C5EF2DF530
000076b67a9e0962  call rax
000076b67a9e0964  movaps xmm15, [rsp]
000076b67a9e0969  add rsp, 0x30
000076b67a9e096d  vmovaps xmm0, [rsp]
000076b67a9e0972  vmovaps xmm1, [rsp+0x10]
000076b67a9e0978  vmovaps xmm2, [rsp+0x20]
000076b67a9e097e  vmovaps xmm3, [rsp+0x30]
000076b67a9e0984  vmovaps xmm4, [rsp+0x40]
000076b67a9e098a  vmovaps xmm5, [rsp+0x50]
000076b67a9e0990  vmovaps xmm6, [rsp+0x60]
000076b67a9e0996  vmovaps xmm7, [rsp+0x70]
000076b67a9e099c  vmovaps xmm8, [rsp+0x80]
000076b67a9e09a5  vmovaps xmm9, [rsp+0x90]
000076b67a9e09ae  vmovaps xmm10, [rsp+0xA0]
000076b67a9e09b7  vmovaps xmm11, [rsp+0xB0]
000076b67a9e09c0  vmovaps xmm12, [rsp+0xC0]
000076b67a9e09c9  vmovaps xmm13, [rsp+0xD0]
000076b67a9e09d2  vmovaps xmm14, [rsp+0xE0]
000076b67a9e09db  add rsp, 0xF0
000076b67a9e09e2  pop r11
000076b67a9e09e4  pop r10
000076b67a9e09e6  pop r9
000076b67a9e09e8  pop r8
000076b67a9e09ea  pop rsi
000076b67a9e09eb  pop rdi
000076b67a9e09ec  pop rdx
000076b67a9e09ed  pop rcx
000076b67a9e09ee  pop rax
000076b67a9e09ef  add rsp, 0x08
000076b67a9e09f3  jmp 0x000076B67A9DC658
000076b67a9e09f8  sub rsp, 0x08
000076b67a9e09fc  push rax
000076b67a9e09fd  push rcx
000076b67a9e09fe  push rdx
000076b67a9e09ff  push rdi
000076b67a9e0a00  push rsi
000076b67a9e0a01  push r8
000076b67a9e0a03  push r9
000076b67a9e0a05  push r10
000076b67a9e0a07  push r11
000076b67a9e0a09  sub rsp, 0xF0
000076b67a9e0a10  vmovaps [rsp], xmm0
000076b67a9e0a15  vmovaps [rsp+0x10], xmm1
000076b67a9e0a1b  vmovaps [rsp+0x20], xmm2
000076b67a9e0a21  vmovaps [rsp+0x30], xmm3
000076b67a9e0a27  vmovaps [rsp+0x40], xmm4
000076b67a9e0a2d  vmovaps [rsp+0x50], xmm5
000076b67a9e0a33  vmovaps [rsp+0x60], xmm6
000076b67a9e0a39  vmovaps [rsp+0x70], xmm8
000076b67a9e0a3f  vmovaps [rsp+0x80], xmm9
000076b67a9e0a48  vmovaps [rsp+0x90], xmm10
000076b67a9e0a51  vmovaps [rsp+0xA0], xmm11
000076b67a9e0a5a  vmovaps [rsp+0xB0], xmm12
000076b67a9e0a63  vmovaps [rsp+0xC0], xmm13
000076b67a9e0a6c  vmovaps [rsp+0xD0], xmm14
000076b67a9e0a75  vmovaps [rsp+0xE0], xmm15
000076b67a9e0a7e  sub rsp, 0x30
000076b67a9e0a82  movaps [rsp], xmm7
000076b67a9e0a86  movaps [rsp+0x10], xmm11
000076b67a9e0a8c  movaps [rsp+0x20], xmm9
000076b67a9e0a92  lea rdi, [rsp]
000076b67a9e0a96  mov esi, 0x00
000076b67a9e0a9b  mov rax, 0x63C5EF2DF530
000076b67a9e0aa5  call rax
000076b67a9e0aa7  movaps xmm7, [rsp]
000076b67a9e0aab  add rsp, 0x30
000076b67a9e0aaf  vmovaps xmm0, [rsp]
000076b67a9e0ab4  vmovaps xmm1, [rsp+0x10]
000076b67a9e0aba  vmovaps xmm2, [rsp+0x20]
000076b67a9e0ac0  vmovaps xmm3, [rsp+0x30]
000076b67a9e0ac6  vmovaps xmm4, [rsp+0x40]
000076b67a9e0acc  vmovaps xmm5, [rsp+0x50]
000076b67a9e0ad2  vmovaps xmm6, [rsp+0x60]
000076b67a9e0ad8  vmovaps xmm8, [rsp+0x70]
000076b67a9e0ade  vmovaps xmm9, [rsp+0x80]
000076b67a9e0ae7  vmovaps xmm10, [rsp+0x90]
000076b67a9e0af0  vmovaps xmm11, [rsp+0xA0]
000076b67a9e0af9  vmovaps xmm12, [rsp+0xB0]
000076b67a9e0b02  vmovaps xmm13, [rsp+0xC0]
000076b67a9e0b0b  vmovaps xmm14, [rsp+0xD0]
000076b67a9e0b14  vmovaps xmm15, [rsp+0xE0]
000076b67a9e0b1d  add rsp, 0xF0
000076b67a9e0b24  pop r11
000076b67a9e0b26  pop r10
000076b67a9e0b28  pop r9
000076b67a9e0b2a  pop r8
000076b67a9e0b2c  pop rsi
000076b67a9e0b2d  pop rdi
000076b67a9e0b2e  pop rdx
000076b67a9e0b2f  pop rcx
000076b67a9e0b30  pop rax
000076b67a9e0b31  add rsp, 0x08
000076b67a9e0b35  jmp 0x000076B67A9DC685
000076b67a9e0b3a  sub rsp, 0x08
000076b67a9e0b3e  push rax
000076b67a9e0b3f  push rcx
000076b67a9e0b40  push rdx
000076b67a9e0b41  push rdi
000076b67a9e0b42  push rsi
000076b67a9e0b43  push r8
000076b67a9e0b45  push r9
000076b67a9e0b47  push r10
000076b67a9e0b49  push r11
000076b67a9e0b4b  sub rsp, 0xF0
000076b67a9e0b52  vmovaps [rsp], xmm0
000076b67a9e0b57  vmovaps [rsp+0x10], xmm1
000076b67a9e0b5d  vmovaps [rsp+0x20], xmm2
000076b67a9e0b63  vmovaps [rsp+0x30], xmm3
000076b67a9e0b69  vmovaps [rsp+0x40], xmm4
000076b67a9e0b6f  vmovaps [rsp+0x50], xmm5
000076b67a9e0b75  vmovaps [rsp+0x60], xmm6
000076b67a9e0b7b  vmovaps [rsp+0x70], xmm7
000076b67a9e0b81  vmovaps [rsp+0x80], xmm8
000076b67a9e0b8a  vmovaps [rsp+0x90], xmm9
000076b67a9e0b93  vmovaps [rsp+0xA0], xmm10
000076b67a9e0b9c  vmovaps [rsp+0xB0], xmm12
000076b67a9e0ba5  vmovaps [rsp+0xC0], xmm13
000076b67a9e0bae  vmovaps [rsp+0xD0], xmm14
000076b67a9e0bb7  vmovaps [rsp+0xE0], xmm15
000076b67a9e0bc0  sub rsp, 0x30
000076b67a9e0bc4  movaps [rsp], xmm11
000076b67a9e0bc9  movaps [rsp+0x10], xmm10
000076b67a9e0bcf  movaps [rsp+0x20], xmm14
000076b67a9e0bd5  lea rdi, [rsp]
000076b67a9e0bd9  mov esi, 0x00
000076b67a9e0bde  mov rax, 0x63C5EF2DF530
000076b67a9e0be8  call rax
000076b67a9e0bea  movaps xmm11, [rsp]
000076b67a9e0bef  add rsp, 0x30
000076b67a9e0bf3  vmovaps xmm0, [rsp]
000076b67a9e0bf8  vmovaps xmm1, [rsp+0x10]
000076b67a9e0bfe  vmovaps xmm2, [rsp+0x20]
000076b67a9e0c04  vmovaps xmm3, [rsp+0x30]
000076b67a9e0c0a  vmovaps xmm4, [rsp+0x40]
000076b67a9e0c10  vmovaps xmm5, [rsp+0x50]
000076b67a9e0c16  vmovaps xmm6, [rsp+0x60]
000076b67a9e0c1c  vmovaps xmm7, [rsp+0x70]
000076b67a9e0c22  vmovaps xmm8, [rsp+0x80]
000076b67a9e0c2b  vmovaps xmm9, [rsp+0x90]
000076b67a9e0c34  vmovaps xmm10, [rsp+0xA0]
000076b67a9e0c3d  vmovaps xmm12, [rsp+0xB0]
000076b67a9e0c46  vmovaps xmm13, [rsp+0xC0]
000076b67a9e0c4f  vmovaps xmm14, [rsp+0xD0]
000076b67a9e0c58  vmovaps xmm15, [rsp+0xE0]
000076b67a9e0c61  add rsp, 0xF0
000076b67a9e0c68  pop r11
000076b67a9e0c6a  pop r10
000076b67a9e0c6c  pop r9
000076b67a9e0c6e  pop r8
000076b67a9e0c70  pop rsi
000076b67a9e0c71  pop rdi
000076b67a9e0c72  pop rdx
000076b67a9e0c73  pop rcx
000076b67a9e0c74  pop rax
000076b67a9e0c75  add rsp, 0x08
000076b67a9e0c79  jmp 0x000076B67A9DC6A0
000076b67a9e0c7e  call 0x000076B67A8C33A0
000076b67a9e0c83  jmp 0x000076B67A9DC6AA
000076b67a9e0c88  sub rsp, 0x08
000076b67a9e0c8c  push rax
000076b67a9e0c8d  push rcx
000076b67a9e0c8e  push rdx
000076b67a9e0c8f  push rdi
000076b67a9e0c90  push rsi
000076b67a9e0c91  push r8
000076b67a9e0c93  push r9
000076b67a9e0c95  push r10
000076b67a9e0c97  push r11
000076b67a9e0c99  sub rsp, 0xF0
000076b67a9e0ca0  vmovaps [rsp], xmm0
000076b67a9e0ca5  vmovaps [rsp+0x10], xmm1
000076b67a9e0cab  vmovaps [rsp+0x20], xmm2
000076b67a9e0cb1  vmovaps [rsp+0x30], xmm3
000076b67a9e0cb7  vmovaps [rsp+0x40], xmm4
000076b67a9e0cbd  vmovaps [rsp+0x50], xmm5
000076b67a9e0cc3  vmovaps [rsp+0x60], xmm6
000076b67a9e0cc9  vmovaps [rsp+0x70], xmm7
000076b67a9e0ccf  vmovaps [rsp+0x80], xmm8
000076b67a9e0cd8  vmovaps [rsp+0x90], xmm9
000076b67a9e0ce1  vmovaps [rsp+0xA0], xmm11
000076b67a9e0cea  vmovaps [rsp+0xB0], xmm12
000076b67a9e0cf3  vmovaps [rsp+0xC0], xmm13
000076b67a9e0cfc  vmovaps [rsp+0xD0], xmm14
000076b67a9e0d05  vmovaps [rsp+0xE0], xmm15
000076b67a9e0d0e  sub rsp, 0x30
000076b67a9e0d12  movaps [rsp], xmm10
000076b67a9e0d17  movaps [rsp+0x10], xmm1
000076b67a9e0d1c  movaps [rsp+0x20], xmm12
000076b67a9e0d22  lea rdi, [rsp]
000076b67a9e0d26  mov esi, 0x00
000076b67a9e0d2b  mov rax, 0x63C5EF2DF530
000076b67a9e0d35  call rax
000076b67a9e0d37  movaps xmm10, [rsp]
000076b67a9e0d3c  add rsp, 0x30
000076b67a9e0d40  vmovaps xmm0, [rsp]
000076b67a9e0d45  vmovaps xmm1, [rsp+0x10]
000076b67a9e0d4b  vmovaps xmm2, [rsp+0x20]
000076b67a9e0d51  vmovaps xmm3, [rsp+0x30]
000076b67a9e0d57  vmovaps xmm4, [rsp+0x40]
000076b67a9e0d5d  vmovaps xmm5, [rsp+0x50]
000076b67a9e0d63  vmovaps xmm6, [rsp+0x60]
000076b67a9e0d69  vmovaps xmm7, [rsp+0x70]
000076b67a9e0d6f  vmovaps xmm8, [rsp+0x80]
000076b67a9e0d78  vmovaps xmm9, [rsp+0x90]
000076b67a9e0d81  vmovaps xmm11, [rsp+0xA0]
000076b67a9e0d8a  vmovaps xmm12, [rsp+0xB0]
000076b67a9e0d93  vmovaps xmm13, [rsp+0xC0]
000076b67a9e0d9c  vmovaps xmm14, [rsp+0xD0]
000076b67a9e0da5  vmovaps xmm15, [rsp+0xE0]
000076b67a9e0dae  add rsp, 0xF0
000076b67a9e0db5  pop r11
000076b67a9e0db7  pop r10
000076b67a9e0db9  pop r9
000076b67a9e0dbb  pop r8
000076b67a9e0dbd  pop rsi
000076b67a9e0dbe  pop rdi
000076b67a9e0dbf  pop rdx
000076b67a9e0dc0  pop rcx
000076b67a9e0dc1  pop rax
000076b67a9e0dc2  add rsp, 0x08
000076b67a9e0dc6  jmp 0x000076B67A9DC6CD
000076b67a9e0dcb  sub rsp, 0x08
000076b67a9e0dcf  push rax
000076b67a9e0dd0  push rcx
000076b67a9e0dd1  push rdx
000076b67a9e0dd2  push rdi
000076b67a9e0dd3  push rsi
000076b67a9e0dd4  push r8
000076b67a9e0dd6  push r9
000076b67a9e0dd8  push r10
000076b67a9e0dda  push r11
000076b67a9e0ddc  sub rsp, 0xF0
000076b67a9e0de3  vmovaps [rsp], xmm0
000076b67a9e0de8  vmovaps [rsp+0x10], xmm1
000076b67a9e0dee  vmovaps [rsp+0x20], xmm2
000076b67a9e0df4  vmovaps [rsp+0x30], xmm3
000076b67a9e0dfa  vmovaps [rsp+0x40], xmm4
000076b67a9e0e00  vmovaps [rsp+0x50], xmm5
000076b67a9e0e06  vmovaps [rsp+0x60], xmm6
000076b67a9e0e0c  vmovaps [rsp+0x70], xmm7
000076b67a9e0e12  vmovaps [rsp+0x80], xmm8
000076b67a9e0e1b  vmovaps [rsp+0x90], xmm9
000076b67a9e0e24  vmovaps [rsp+0xA0], xmm10
000076b67a9e0e2d  vmovaps [rsp+0xB0], xmm11
000076b67a9e0e36  vmovaps [rsp+0xC0], xmm13
000076b67a9e0e3f  vmovaps [rsp+0xD0], xmm14
000076b67a9e0e48  vmovaps [rsp+0xE0], xmm15
000076b67a9e0e51  sub rsp, 0x30
000076b67a9e0e55  movaps [rsp], xmm12
000076b67a9e0e5a  movaps [rsp+0x10], xmm14
000076b67a9e0e60  movaps [rsp+0x20], xmm1
000076b67a9e0e65  lea rdi, [rsp]
000076b67a9e0e69  mov esi, 0x00
000076b67a9e0e6e  mov rax, 0x63C5EF2DF530
000076b67a9e0e78  call rax
000076b67a9e0e7a  movaps xmm12, [rsp]
000076b67a9e0e7f  add rsp, 0x30
000076b67a9e0e83  vmovaps xmm0, [rsp]
000076b67a9e0e88  vmovaps xmm1, [rsp+0x10]
000076b67a9e0e8e  vmovaps xmm2, [rsp+0x20]
000076b67a9e0e94  vmovaps xmm3, [rsp+0x30]
000076b67a9e0e9a  vmovaps xmm4, [rsp+0x40]
000076b67a9e0ea0  vmovaps xmm5, [rsp+0x50]
000076b67a9e0ea6  vmovaps xmm6, [rsp+0x60]
000076b67a9e0eac  vmovaps xmm7, [rsp+0x70]
000076b67a9e0eb2  vmovaps xmm8, [rsp+0x80]
000076b67a9e0ebb  vmovaps xmm9, [rsp+0x90]
000076b67a9e0ec4  vmovaps xmm10, [rsp+0xA0]
000076b67a9e0ecd  vmovaps xmm11, [rsp+0xB0]
000076b67a9e0ed6  vmovaps xmm13, [rsp+0xC0]
000076b67a9e0edf  vmovaps xmm14, [rsp+0xD0]
000076b67a9e0ee8  vmovaps xmm15, [rsp+0xE0]
000076b67a9e0ef1  add rsp, 0xF0
000076b67a9e0ef8  pop r11
000076b67a9e0efa  pop r10
000076b67a9e0efc  pop r9
000076b67a9e0efe  pop r8
000076b67a9e0f00  pop rsi
000076b67a9e0f01  pop rdi
000076b67a9e0f02  pop rdx
000076b67a9e0f03  pop rcx
000076b67a9e0f04  pop rax
000076b67a9e0f05  add rsp, 0x08
000076b67a9e0f09  jmp 0x000076B67A9DC6FC
000076b67a9e0f0e  sub rsp, 0x08
000076b67a9e0f12  push rax
000076b67a9e0f13  push rcx
000076b67a9e0f14  push rdx
000076b67a9e0f15  push rdi
000076b67a9e0f16  push rsi
000076b67a9e0f17  push r8
000076b67a9e0f19  push r9
000076b67a9e0f1b  push r10
000076b67a9e0f1d  push r11
000076b67a9e0f1f  sub rsp, 0xF0
000076b67a9e0f26  vmovaps [rsp], xmm0
000076b67a9e0f2b  vmovaps [rsp+0x10], xmm1
000076b67a9e0f31  vmovaps [rsp+0x20], xmm2
000076b67a9e0f37  vmovaps [rsp+0x30], xmm3
000076b67a9e0f3d  vmovaps [rsp+0x40], xmm4
000076b67a9e0f43  vmovaps [rsp+0x50], xmm5
000076b67a9e0f49  vmovaps [rsp+0x60], xmm6
000076b67a9e0f4f  vmovaps [rsp+0x70], xmm7
000076b67a9e0f55  vmovaps [rsp+0x80], xmm8
000076b67a9e0f5e  vmovaps [rsp+0x90], xmm9
000076b67a9e0f67  vmovaps [rsp+0xA0], xmm10
000076b67a9e0f70  vmovaps [rsp+0xB0], xmm11
000076b67a9e0f79  vmovaps [rsp+0xC0], xmm12
000076b67a9e0f82  vmovaps [rsp+0xD0], xmm13
000076b67a9e0f8b  vmovaps [rsp+0xE0], xmm15
000076b67a9e0f94  sub rsp, 0x30
000076b67a9e0f98  movaps [rsp], xmm14
000076b67a9e0f9d  movaps [rsp+0x10], xmm9
000076b67a9e0fa3  movaps [rsp+0x20], xmm1
000076b67a9e0fa8  lea rdi, [rsp]
000076b67a9e0fac  mov esi, 0x00
000076b67a9e0fb1  mov rax, 0x63C5EF2DF530
000076b67a9e0fbb  call rax
000076b67a9e0fbd  movaps xmm14, [rsp]
000076b67a9e0fc2  add rsp, 0x30
000076b67a9e0fc6  vmovaps xmm0, [rsp]
000076b67a9e0fcb  vmovaps xmm1, [rsp+0x10]
000076b67a9e0fd1  vmovaps xmm2, [rsp+0x20]
000076b67a9e0fd7  vmovaps xmm3, [rsp+0x30]
000076b67a9e0fdd  vmovaps xmm4, [rsp+0x40]
000076b67a9e0fe3  vmovaps xmm5, [rsp+0x50]
000076b67a9e0fe9  vmovaps xmm6, [rsp+0x60]
000076b67a9e0fef  vmovaps xmm7, [rsp+0x70]
000076b67a9e0ff5  vmovaps xmm8, [rsp+0x80]
000076b67a9e0ffe  vmovaps xmm9, [rsp+0x90]
000076b67a9e1007  vmovaps xmm10, [rsp+0xA0]
000076b67a9e1010  vmovaps xmm11, [rsp+0xB0]
000076b67a9e1019  vmovaps xmm12, [rsp+0xC0]
000076b67a9e1022  vmovaps xmm13, [rsp+0xD0]
000076b67a9e102b  vmovaps xmm15, [rsp+0xE0]
000076b67a9e1034  add rsp, 0xF0
000076b67a9e103b  pop r11
000076b67a9e103d  pop r10
000076b67a9e103f  pop r9
000076b67a9e1041  pop r8
000076b67a9e1043  pop rsi
000076b67a9e1044  pop rdi
000076b67a9e1045  pop rdx
000076b67a9e1046  pop rcx
000076b67a9e1047  pop rax
000076b67a9e1048  add rsp, 0x08
000076b67a9e104c  jmp 0x000076B67A9DC72B
000076b67a9e1051  sub rsp, 0x08
000076b67a9e1055  push rax
000076b67a9e1056  push rcx
000076b67a9e1057  push rdx
000076b67a9e1058  push rdi
000076b67a9e1059  push rsi
000076b67a9e105a  push r8
000076b67a9e105c  push r9
000076b67a9e105e  push r10
000076b67a9e1060  push r11
000076b67a9e1062  sub rsp, 0xF0
000076b67a9e1069  vmovaps [rsp], xmm0
000076b67a9e106e  vmovaps [rsp+0x10], xmm2
000076b67a9e1074  vmovaps [rsp+0x20], xmm3
000076b67a9e107a  vmovaps [rsp+0x30], xmm4
000076b67a9e1080  vmovaps [rsp+0x40], xmm5
000076b67a9e1086  vmovaps [rsp+0x50], xmm6
000076b67a9e108c  vmovaps [rsp+0x60], xmm7
000076b67a9e1092  vmovaps [rsp+0x70], xmm8
000076b67a9e1098  vmovaps [rsp+0x80], xmm9
000076b67a9e10a1  vmovaps [rsp+0x90], xmm10
000076b67a9e10aa  vmovaps [rsp+0xA0], xmm11
000076b67a9e10b3  vmovaps [rsp+0xB0], xmm12
000076b67a9e10bc  vmovaps [rsp+0xC0], xmm13
000076b67a9e10c5  vmovaps [rsp+0xD0], xmm14
000076b67a9e10ce  vmovaps [rsp+0xE0], xmm15
000076b67a9e10d7  sub rsp, 0x30
000076b67a9e10db  movaps [rsp], xmm1
000076b67a9e10df  movaps [rsp+0x10], xmm13
000076b67a9e10e5  movaps [rsp+0x20], xmm8
000076b67a9e10eb  lea rdi, [rsp]
000076b67a9e10ef  mov esi, 0x00
000076b67a9e10f4  mov rax, 0x63C5EF2DF530
000076b67a9e10fe  call rax
000076b67a9e1100  movaps xmm1, [rsp]
000076b67a9e1104  add rsp, 0x30
000076b67a9e1108  vmovaps xmm0, [rsp]
000076b67a9e110d  vmovaps xmm2, [rsp+0x10]
000076b67a9e1113  vmovaps xmm3, [rsp+0x20]
000076b67a9e1119  vmovaps xmm4, [rsp+0x30]
000076b67a9e111f  vmovaps xmm5, [rsp+0x40]
000076b67a9e1125  vmovaps xmm6, [rsp+0x50]
000076b67a9e112b  vmovaps xmm7, [rsp+0x60]
000076b67a9e1131  vmovaps xmm8, [rsp+0x70]
000076b67a9e1137  vmovaps xmm9, [rsp+0x80]
000076b67a9e1140  vmovaps xmm10, [rsp+0x90]
000076b67a9e1149  vmovaps xmm11, [rsp+0xA0]
000076b67a9e1152  vmovaps xmm12, [rsp+0xB0]
000076b67a9e115b  vmovaps xmm13, [rsp+0xC0]
000076b67a9e1164  vmovaps xmm14, [rsp+0xD0]
000076b67a9e116d  vmovaps xmm15, [rsp+0xE0]
000076b67a9e1176  add rsp, 0xF0
000076b67a9e117d  pop r11
000076b67a9e117f  pop r10
000076b67a9e1181  pop r9
000076b67a9e1183  pop r8
000076b67a9e1185  pop rsi
000076b67a9e1186  pop rdi
000076b67a9e1187  pop rdx
000076b67a9e1188  pop rcx
000076b67a9e1189  pop rax
000076b67a9e118a  add rsp, 0x08
000076b67a9e118e  jmp 0x000076B67A9DC74D
000076b67a9e1193  call 0x000076B67A80C260
000076b67a9e1198  jmp 0x000076B67A9DC75B
000076b67a9e119d  call 0x000076B67A8BD750
000076b67a9e11a2  jmp 0x000076B67A9DC765
000076b67a9e11a7  sub rsp, 0x08
000076b67a9e11ab  push rax
000076b67a9e11ac  push rcx
000076b67a9e11ad  push rdx
000076b67a9e11ae  push rdi
000076b67a9e11af  push rsi
000076b67a9e11b0  push r8
000076b67a9e11b2  push r9
000076b67a9e11b4  push r10
000076b67a9e11b6  push r11
000076b67a9e11b8  sub rsp, 0xF0
000076b67a9e11bf  vmovaps [rsp], xmm0
000076b67a9e11c4  vmovaps [rsp+0x10], xmm1
000076b67a9e11ca  vmovaps [rsp+0x20], xmm2
000076b67a9e11d0  vmovaps [rsp+0x30], xmm3
000076b67a9e11d6  vmovaps [rsp+0x40], xmm4
000076b67a9e11dc  vmovaps [rsp+0x50], xmm5
000076b67a9e11e2  vmovaps [rsp+0x60], xmm6
000076b67a9e11e8  vmovaps [rsp+0x70], xmm7
000076b67a9e11ee  vmovaps [rsp+0x80], xmm9
000076b67a9e11f7  vmovaps [rsp+0x90], xmm10
000076b67a9e1200  vmovaps [rsp+0xA0], xmm11
000076b67a9e1209  vmovaps [rsp+0xB0], xmm12
000076b67a9e1212  vmovaps [rsp+0xC0], xmm13
000076b67a9e121b  vmovaps [rsp+0xD0], xmm14
000076b67a9e1224  vmovaps [rsp+0xE0], xmm15
000076b67a9e122d  sub rsp, 0x30
000076b67a9e1231  movaps [rsp], xmm8
000076b67a9e1236  movaps [rsp+0x10], xmm15
000076b67a9e123c  movaps [rsp+0x20], xmm7
000076b67a9e1241  lea rdi, [rsp]
000076b67a9e1245  mov esi, 0x00
000076b67a9e124a  mov rax, 0x63C5EF2DF530
000076b67a9e1254  call rax
000076b67a9e1256  movaps xmm8, [rsp]
000076b67a9e125b  add rsp, 0x30
000076b67a9e125f  vmovaps xmm0, [rsp]
000076b67a9e1264  vmovaps xmm1, [rsp+0x10]
000076b67a9e126a  vmovaps xmm2, [rsp+0x20]
000076b67a9e1270  vmovaps xmm3, [rsp+0x30]
000076b67a9e1276  vmovaps xmm4, [rsp+0x40]
000076b67a9e127c  vmovaps xmm5, [rsp+0x50]
000076b67a9e1282  vmovaps xmm6, [rsp+0x60]
000076b67a9e1288  vmovaps xmm7, [rsp+0x70]
000076b67a9e128e  vmovaps xmm9, [rsp+0x80]
000076b67a9e1297  vmovaps xmm10, [rsp+0x90]
000076b67a9e12a0  vmovaps xmm11, [rsp+0xA0]
000076b67a9e12a9  vmovaps xmm12, [rsp+0xB0]
000076b67a9e12b2  vmovaps xmm13, [rsp+0xC0]
000076b67a9e12bb  vmovaps xmm14, [rsp+0xD0]
000076b67a9e12c4  vmovaps xmm15, [rsp+0xE0]
000076b67a9e12cd  add rsp, 0xF0
000076b67a9e12d4  pop r11
000076b67a9e12d6  pop r10
000076b67a9e12d8  pop r9
000076b67a9e12da  pop r8
000076b67a9e12dc  pop rsi
000076b67a9e12dd  pop rdi
000076b67a9e12de  pop rdx
000076b67a9e12df  pop rcx
000076b67a9e12e0  pop rax
000076b67a9e12e1  add rsp, 0x08
000076b67a9e12e5  jmp 0x000076B67A9DC787
000076b67a9e12ea  sub rsp, 0x08
000076b67a9e12ee  push rax
000076b67a9e12ef  push rcx
000076b67a9e12f0  push rdx
000076b67a9e12f1  push rdi
000076b67a9e12f2  push rsi
000076b67a9e12f3  push r8
000076b67a9e12f5  push r9
000076b67a9e12f7  push r10
000076b67a9e12f9  push r11
000076b67a9e12fb  sub rsp, 0xF0
000076b67a9e1302  vmovaps [rsp], xmm0
000076b67a9e1307  vmovaps [rsp+0x10], xmm1
000076b67a9e130d  vmovaps [rsp+0x20], xmm2
000076b67a9e1313  vmovaps [rsp+0x30], xmm3
000076b67a9e1319  vmovaps [rsp+0x40], xmm4
000076b67a9e131f  vmovaps [rsp+0x50], xmm5
000076b67a9e1325  vmovaps [rsp+0x60], xmm6
000076b67a9e132b  vmovaps [rsp+0x70], xmm8
000076b67a9e1331  vmovaps [rsp+0x80], xmm9
000076b67a9e133a  vmovaps [rsp+0x90], xmm10
000076b67a9e1343  vmovaps [rsp+0xA0], xmm11
000076b67a9e134c  vmovaps [rsp+0xB0], xmm12
000076b67a9e1355  vmovaps [rsp+0xC0], xmm13
000076b67a9e135e  vmovaps [rsp+0xD0], xmm14
000076b67a9e1367  vmovaps [rsp+0xE0], xmm15
000076b67a9e1370  sub rsp, 0x30
000076b67a9e1374  movaps [rsp], xmm7
000076b67a9e1378  movaps [rsp+0x10], xmm9
000076b67a9e137e  movaps [rsp+0x20], xmm15
000076b67a9e1384  lea rdi, [rsp]
000076b67a9e1388  mov esi, 0x00
000076b67a9e138d  mov rax, 0x63C5EF2DF530
000076b67a9e1397  call rax
000076b67a9e1399  movaps xmm7, [rsp]
000076b67a9e139d  add rsp, 0x30
000076b67a9e13a1  vmovaps xmm0, [rsp]
000076b67a9e13a6  vmovaps xmm1, [rsp+0x10]
000076b67a9e13ac  vmovaps xmm2, [rsp+0x20]
000076b67a9e13b2  vmovaps xmm3, [rsp+0x30]
000076b67a9e13b8  vmovaps xmm4, [rsp+0x40]
000076b67a9e13be  vmovaps xmm5, [rsp+0x50]
000076b67a9e13c4  vmovaps xmm6, [rsp+0x60]
000076b67a9e13ca  vmovaps xmm8, [rsp+0x70]
000076b67a9e13d0  vmovaps xmm9, [rsp+0x80]
000076b67a9e13d9  vmovaps xmm10, [rsp+0x90]
000076b67a9e13e2  vmovaps xmm11, [rsp+0xA0]
000076b67a9e13eb  vmovaps xmm12, [rsp+0xB0]
000076b67a9e13f4  vmovaps xmm13, [rsp+0xC0]
000076b67a9e13fd  vmovaps xmm14, [rsp+0xD0]
000076b67a9e1406  vmovaps xmm15, [rsp+0xE0]
000076b67a9e140f  add rsp, 0xF0
000076b67a9e1416  pop r11
000076b67a9e1418  pop r10
000076b67a9e141a  pop r9
000076b67a9e141c  pop r8
000076b67a9e141e  pop rsi
000076b67a9e141f  pop rdi
000076b67a9e1420  pop rdx
000076b67a9e1421  pop rcx
000076b67a9e1422  pop rax
000076b67a9e1423  add rsp, 0x08
000076b67a9e1427  jmp 0x000076B67A9DC7B4
000076b67a9e142c  sub rsp, 0x08
000076b67a9e1430  push rax
000076b67a9e1431  push rcx
000076b67a9e1432  push rdx
000076b67a9e1433  push rdi
000076b67a9e1434  push rsi
000076b67a9e1435  push r8
000076b67a9e1437  push r9
000076b67a9e1439  push r10
000076b67a9e143b  push r11
000076b67a9e143d  sub rsp, 0xF0
000076b67a9e1444  vmovaps [rsp], xmm0
000076b67a9e1449  vmovaps [rsp+0x10], xmm1
000076b67a9e144f  vmovaps [rsp+0x20], xmm2
000076b67a9e1455  vmovaps [rsp+0x30], xmm3
000076b67a9e145b  vmovaps [rsp+0x40], xmm4
000076b67a9e1461  vmovaps [rsp+0x50], xmm5
000076b67a9e1467  vmovaps [rsp+0x60], xmm6
000076b67a9e146d  vmovaps [rsp+0x70], xmm7
000076b67a9e1473  vmovaps [rsp+0x80], xmm8
000076b67a9e147c  vmovaps [rsp+0x90], xmm10
000076b67a9e1485  vmovaps [rsp+0xA0], xmm11
000076b67a9e148e  vmovaps [rsp+0xB0], xmm12
000076b67a9e1497  vmovaps [rsp+0xC0], xmm13
000076b67a9e14a0  vmovaps [rsp+0xD0], xmm14
000076b67a9e14a9  vmovaps [rsp+0xE0], xmm15
000076b67a9e14b2  sub rsp, 0x30
000076b67a9e14b6  movaps [rsp], xmm9
000076b67a9e14bb  movaps [rsp+0x10], xmm13
000076b67a9e14c1  movaps [rsp+0x20], xmm15
000076b67a9e14c7  lea rdi, [rsp]
000076b67a9e14cb  mov esi, 0x00
000076b67a9e14d0  mov rax, 0x63C5EF2DF530
000076b67a9e14da  call rax
000076b67a9e14dc  movaps xmm9, [rsp]
000076b67a9e14e1  add rsp, 0x30
000076b67a9e14e5  vmovaps xmm0, [rsp]
000076b67a9e14ea  vmovaps xmm1, [rsp+0x10]
000076b67a9e14f0  vmovaps xmm2, [rsp+0x20]
000076b67a9e14f6  vmovaps xmm3, [rsp+0x30]
000076b67a9e14fc  vmovaps xmm4, [rsp+0x40]
000076b67a9e1502  vmovaps xmm5, [rsp+0x50]
000076b67a9e1508  vmovaps xmm6, [rsp+0x60]
000076b67a9e150e  vmovaps xmm7, [rsp+0x70]
000076b67a9e1514  vmovaps xmm8, [rsp+0x80]
000076b67a9e151d  vmovaps xmm10, [rsp+0x90]
000076b67a9e1526  vmovaps xmm11, [rsp+0xA0]
000076b67a9e152f  vmovaps xmm12, [rsp+0xB0]
000076b67a9e1538  vmovaps xmm13, [rsp+0xC0]
000076b67a9e1541  vmovaps xmm14, [rsp+0xD0]
000076b67a9e154a  vmovaps xmm15, [rsp+0xE0]
000076b67a9e1553  add rsp, 0xF0
000076b67a9e155a  pop r11
000076b67a9e155c  pop r10
000076b67a9e155e  pop r9
000076b67a9e1560  pop r8
000076b67a9e1562  pop rsi
000076b67a9e1563  pop rdi
000076b67a9e1564  pop rdx
000076b67a9e1565  pop rcx
000076b67a9e1566  pop rax
000076b67a9e1567  add rsp, 0x08
000076b67a9e156b  jmp 0x000076B67A9DC7E2
000076b67a9e1570  sub rsp, 0x08
000076b67a9e1574  push rax
000076b67a9e1575  push rcx
000076b67a9e1576  push rdx
000076b67a9e1577  push rdi
000076b67a9e1578  push rsi
000076b67a9e1579  push r8
000076b67a9e157b  push r9
000076b67a9e157d  push r10
000076b67a9e157f  push r11
000076b67a9e1581  sub rsp, 0xF0
000076b67a9e1588  vmovaps [rsp], xmm0
000076b67a9e158d  vmovaps [rsp+0x10], xmm1
000076b67a9e1593  vmovaps [rsp+0x20], xmm2
000076b67a9e1599  vmovaps [rsp+0x30], xmm3
000076b67a9e159f  vmovaps [rsp+0x40], xmm4
000076b67a9e15a5  vmovaps [rsp+0x50], xmm5
000076b67a9e15ab  vmovaps [rsp+0x60], xmm6
000076b67a9e15b1  vmovaps [rsp+0x70], xmm7
000076b67a9e15b7  vmovaps [rsp+0x80], xmm8
000076b67a9e15c0  vmovaps [rsp+0x90], xmm9
000076b67a9e15c9  vmovaps [rsp+0xA0], xmm10
000076b67a9e15d2  vmovaps [rsp+0xB0], xmm11
000076b67a9e15db  vmovaps [rsp+0xC0], xmm12
000076b67a9e15e4  vmovaps [rsp+0xD0], xmm13
000076b67a9e15ed  vmovaps [rsp+0xE0], xmm14
000076b67a9e15f6  sub rsp, 0x30
000076b67a9e15fa  movaps [rsp], xmm15
000076b67a9e15ff  movaps [rsp+0x10], xmm11
000076b67a9e1605  movaps [rsp+0x20], xmm12
000076b67a9e160b  lea rdi, [rsp]
000076b67a9e160f  mov esi, 0x00
000076b67a9e1614  mov rax, 0x63C5EF2DF530
000076b67a9e161e  call rax
000076b67a9e1620  movaps xmm15, [rsp]
000076b67a9e1625  add rsp, 0x30
000076b67a9e1629  vmovaps xmm0, [rsp]
000076b67a9e162e  vmovaps xmm1, [rsp+0x10]
000076b67a9e1634  vmovaps xmm2, [rsp+0x20]
000076b67a9e163a  vmovaps xmm3, [rsp+0x30]
000076b67a9e1640  vmovaps xmm4, [rsp+0x40]
000076b67a9e1646  vmovaps xmm5, [rsp+0x50]
000076b67a9e164c  vmovaps xmm6, [rsp+0x60]
000076b67a9e1652  vmovaps xmm7, [rsp+0x70]
000076b67a9e1658  vmovaps xmm8, [rsp+0x80]
000076b67a9e1661  vmovaps xmm9, [rsp+0x90]
000076b67a9e166a  vmovaps xmm10, [rsp+0xA0]
000076b67a9e1673  vmovaps xmm11, [rsp+0xB0]
000076b67a9e167c  vmovaps xmm12, [rsp+0xC0]
000076b67a9e1685  vmovaps xmm13, [rsp+0xD0]
000076b67a9e168e  vmovaps xmm14, [rsp+0xE0]
000076b67a9e1697  add rsp, 0xF0
000076b67a9e169e  pop r11
000076b67a9e16a0  pop r10
000076b67a9e16a2  pop r9
000076b67a9e16a4  pop r8
000076b67a9e16a6  pop rsi
000076b67a9e16a7  pop rdi
000076b67a9e16a8  pop rdx
000076b67a9e16a9  pop rcx
000076b67a9e16aa  pop rax
000076b67a9e16ab  add rsp, 0x08
000076b67a9e16af  jmp 0x000076B67A9DC7FD
000076b67a9e16b4  sub rsp, 0x08
000076b67a9e16b8  push rax
000076b67a9e16b9  push rcx
000076b67a9e16ba  push rdx
000076b67a9e16bb  push rdi
000076b67a9e16bc  push rsi
000076b67a9e16bd  push r8
000076b67a9e16bf  push r9
000076b67a9e16c1  push r10
000076b67a9e16c3  push r11
000076b67a9e16c5  sub rsp, 0xF0
000076b67a9e16cc  vmovaps [rsp], xmm0
000076b67a9e16d1  vmovaps [rsp+0x10], xmm1
000076b67a9e16d7  vmovaps [rsp+0x20], xmm2
000076b67a9e16dd  vmovaps [rsp+0x30], xmm3
000076b67a9e16e3  vmovaps [rsp+0x40], xmm4
000076b67a9e16e9  vmovaps [rsp+0x50], xmm5
000076b67a9e16ef  vmovaps [rsp+0x60], xmm6
000076b67a9e16f5  vmovaps [rsp+0x70], xmm7
000076b67a9e16fb  vmovaps [rsp+0x80], xmm8
000076b67a9e1704  vmovaps [rsp+0x90], xmm9
000076b67a9e170d  vmovaps [rsp+0xA0], xmm10
000076b67a9e1716  vmovaps [rsp+0xB0], xmm11
000076b67a9e171f  vmovaps [rsp+0xC0], xmm12
000076b67a9e1728  vmovaps [rsp+0xD0], xmm14
000076b67a9e1731  vmovaps [rsp+0xE0], xmm15
000076b67a9e173a  sub rsp, 0x30
000076b67a9e173e  movaps [rsp], xmm13
000076b67a9e1743  movaps [rsp+0x10], xmm10
000076b67a9e1749  movaps [rsp+0x20], xmm14
000076b67a9e174f  lea rdi, [rsp]
000076b67a9e1753  mov esi, 0x00
000076b67a9e1758  mov rax, 0x63C5EF2DF530
000076b67a9e1762  call rax
000076b67a9e1764  movaps xmm13, [rsp]
000076b67a9e1769  add rsp, 0x30
000076b67a9e176d  vmovaps xmm0, [rsp]
000076b67a9e1772  vmovaps xmm1, [rsp+0x10]
000076b67a9e1778  vmovaps xmm2, [rsp+0x20]
000076b67a9e177e  vmovaps xmm3, [rsp+0x30]
000076b67a9e1784  vmovaps xmm4, [rsp+0x40]
000076b67a9e178a  vmovaps xmm5, [rsp+0x50]
000076b67a9e1790  vmovaps xmm6, [rsp+0x60]
000076b67a9e1796  vmovaps xmm7, [rsp+0x70]
000076b67a9e179c  vmovaps xmm8, [rsp+0x80]
000076b67a9e17a5  vmovaps xmm9, [rsp+0x90]
000076b67a9e17ae  vmovaps xmm10, [rsp+0xA0]
000076b67a9e17b7  vmovaps xmm11, [rsp+0xB0]
000076b67a9e17c0  vmovaps xmm12, [rsp+0xC0]
000076b67a9e17c9  vmovaps xmm14, [rsp+0xD0]
000076b67a9e17d2  vmovaps xmm15, [rsp+0xE0]
000076b67a9e17db  add rsp, 0xF0
000076b67a9e17e2  pop r11
000076b67a9e17e4  pop r10
000076b67a9e17e6  pop r9
000076b67a9e17e8  pop r8
000076b67a9e17ea  pop rsi
000076b67a9e17eb  pop rdi
000076b67a9e17ec  pop rdx
000076b67a9e17ed  pop rcx
000076b67a9e17ee  pop rax
000076b67a9e17ef  add rsp, 0x08
000076b67a9e17f3  jmp 0x000076B67A9DC820
000076b67a9e17f8  sub rsp, 0x08
000076b67a9e17fc  push rax
000076b67a9e17fd  push rcx
000076b67a9e17fe  push rdx
000076b67a9e17ff  push rdi
000076b67a9e1800  push rsi
000076b67a9e1801  push r8
000076b67a9e1803  push r9
000076b67a9e1805  push r10
000076b67a9e1807  push r11
000076b67a9e1809  sub rsp, 0xF0
000076b67a9e1810  vmovaps [rsp], xmm0
000076b67a9e1815  vmovaps [rsp+0x10], xmm1
000076b67a9e181b  vmovaps [rsp+0x20], xmm2
000076b67a9e1821  vmovaps [rsp+0x30], xmm3
000076b67a9e1827  vmovaps [rsp+0x40], xmm4
000076b67a9e182d  vmovaps [rsp+0x50], xmm5
000076b67a9e1833  vmovaps [rsp+0x60], xmm6
000076b67a9e1839  vmovaps [rsp+0x70], xmm7
000076b67a9e183f  vmovaps [rsp+0x80], xmm8
000076b67a9e1848  vmovaps [rsp+0x90], xmm9
000076b67a9e1851  vmovaps [rsp+0xA0], xmm10
000076b67a9e185a  vmovaps [rsp+0xB0], xmm11
000076b67a9e1863  vmovaps [rsp+0xC0], xmm12
000076b67a9e186c  vmovaps [rsp+0xD0], xmm13
000076b67a9e1875  vmovaps [rsp+0xE0], xmm15
000076b67a9e187e  sub rsp, 0x30
000076b67a9e1882  movaps [rsp], xmm14
000076b67a9e1887  movaps [rsp+0x10], xmm1
000076b67a9e188c  movaps [rsp+0x20], xmm7
000076b67a9e1891  lea rdi, [rsp]
000076b67a9e1895  mov esi, 0x00
000076b67a9e189a  mov rax, 0x63C5EF2DF530
000076b67a9e18a4  call rax
000076b67a9e18a6  movaps xmm14, [rsp]
000076b67a9e18ab  add rsp, 0x30
000076b67a9e18af  vmovaps xmm0, [rsp]
000076b67a9e18b4  vmovaps xmm1, [rsp+0x10]
000076b67a9e18ba  vmovaps xmm2, [rsp+0x20]
000076b67a9e18c0  vmovaps xmm3, [rsp+0x30]
000076b67a9e18c6  vmovaps xmm4, [rsp+0x40]
000076b67a9e18cc  vmovaps xmm5, [rsp+0x50]
000076b67a9e18d2  vmovaps xmm6, [rsp+0x60]
000076b67a9e18d8  vmovaps xmm7, [rsp+0x70]
000076b67a9e18de  vmovaps xmm8, [rsp+0x80]
000076b67a9e18e7  vmovaps xmm9, [rsp+0x90]
000076b67a9e18f0  vmovaps xmm10, [rsp+0xA0]
000076b67a9e18f9  vmovaps xmm11, [rsp+0xB0]
000076b67a9e1902  vmovaps xmm12, [rsp+0xC0]
000076b67a9e190b  vmovaps xmm13, [rsp+0xD0]
000076b67a9e1914  vmovaps xmm15, [rsp+0xE0]
000076b67a9e191d  add rsp, 0xF0
000076b67a9e1924  pop r11
000076b67a9e1926  pop r10
000076b67a9e1928  pop r9
000076b67a9e192a  pop r8
000076b67a9e192c  pop rsi
000076b67a9e192d  pop rdi
000076b67a9e192e  pop rdx
000076b67a9e192f  pop rcx
000076b67a9e1930  pop rax
000076b67a9e1931  add rsp, 0x08
000076b67a9e1935  jmp 0x000076B67A9DC843
000076b67a9e193a  sub rsp, 0x08
000076b67a9e193e  push rax
000076b67a9e193f  push rcx
000076b67a9e1940  push rdx
000076b67a9e1941  push rdi
000076b67a9e1942  push rsi
000076b67a9e1943  push r8
000076b67a9e1945  push r9
000076b67a9e1947  push r10
000076b67a9e1949  push r11
000076b67a9e194b  sub rsp, 0xF0
000076b67a9e1952  vmovaps [rsp], xmm0
000076b67a9e1957  vmovaps [rsp+0x10], xmm2
000076b67a9e195d  vmovaps [rsp+0x20], xmm3
000076b67a9e1963  vmovaps [rsp+0x30], xmm4
000076b67a9e1969  vmovaps [rsp+0x40], xmm5
000076b67a9e196f  vmovaps [rsp+0x50], xmm6
000076b67a9e1975  vmovaps [rsp+0x60], xmm7
000076b67a9e197b  vmovaps [rsp+0x70], xmm8
000076b67a9e1981  vmovaps [rsp+0x80], xmm9
000076b67a9e198a  vmovaps [rsp+0x90], xmm10
000076b67a9e1993  vmovaps [rsp+0xA0], xmm11
000076b67a9e199c  vmovaps [rsp+0xB0], xmm12
000076b67a9e19a5  vmovaps [rsp+0xC0], xmm13
000076b67a9e19ae  vmovaps [rsp+0xD0], xmm14
000076b67a9e19b7  vmovaps [rsp+0xE0], xmm15
000076b67a9e19c0  sub rsp, 0x30
000076b67a9e19c4  movaps [rsp], xmm1
000076b67a9e19c8  movaps [rsp+0x10], xmm8
000076b67a9e19ce  movaps [rsp+0x20], xmm9
000076b67a9e19d4  lea rdi, [rsp]
000076b67a9e19d8  mov esi, 0x00
000076b67a9e19dd  mov rax, 0x63C5EF2DF530
000076b67a9e19e7  call rax
000076b67a9e19e9  movaps xmm1, [rsp]
000076b67a9e19ed  add rsp, 0x30
000076b67a9e19f1  vmovaps xmm0, [rsp]
000076b67a9e19f6  vmovaps xmm2, [rsp+0x10]
000076b67a9e19fc  vmovaps xmm3, [rsp+0x20]
000076b67a9e1a02  vmovaps xmm4, [rsp+0x30]
000076b67a9e1a08  vmovaps xmm5, [rsp+0x40]
000076b67a9e1a0e  vmovaps xmm6, [rsp+0x50]
000076b67a9e1a14  vmovaps xmm7, [rsp+0x60]
000076b67a9e1a1a  vmovaps xmm8, [rsp+0x70]
000076b67a9e1a20  vmovaps xmm9, [rsp+0x80]
000076b67a9e1a29  vmovaps xmm10, [rsp+0x90]
000076b67a9e1a32  vmovaps xmm11, [rsp+0xA0]
000076b67a9e1a3b  vmovaps xmm12, [rsp+0xB0]
000076b67a9e1a44  vmovaps xmm13, [rsp+0xC0]
000076b67a9e1a4d  vmovaps xmm14, [rsp+0xD0]
000076b67a9e1a56  vmovaps xmm15, [rsp+0xE0]
000076b67a9e1a5f  add rsp, 0xF0
000076b67a9e1a66  pop r11
000076b67a9e1a68  pop r10
000076b67a9e1a6a  pop r9
000076b67a9e1a6c  pop r8
000076b67a9e1a6e  pop rsi
000076b67a9e1a6f  pop rdi
000076b67a9e1a70  pop rdx
000076b67a9e1a71  pop rcx
000076b67a9e1a72  pop rax
000076b67a9e1a73  add rsp, 0x08
000076b67a9e1a77  jmp 0x000076B67A9DC865
000076b67a9e1a7c  call 0x000076B67A8E5940
000076b67a9e1a81  jmp 0x000076B67A9DC873
000076b67a9e1a86  call 0x000076B67A80C380
000076b67a9e1a8b  jmp 0x000076B67A9DC87D
000076b67a9e1a90  call 0x000076B67A80D600
000076b67a9e1a95  jmp 0x000076B67A9DC887
000076b67a9e1a9a  call 0x000076B67A7FF540
000076b67a9e1a9f  jmp 0x000076B67A9DC891
000076b67a9e1aa4  int3
000076b67a9e1aa5  nop [rax+rax*1], ax
000076b67a9e1aae  nop
000076b67a9e1ab0  mov rax, [r15+0xF8]
000076b67a9e1ab7  lea r14, [rax+0x140]
000076b67a9e1abe  mov r12, [r13+r14*1]
000076b67a9e1ac3  mov [r15+0xE8], r12
000076b67a9e1aca  lea r14, [rax+0x130]
000076b67a9e1ad1  mov r12, [r13+r14*1]
000076b67a9e1ad6  lea r14, [rax+0x138]
000076b67a9e1add  mov r11, [r13+r14*1]
000076b67a9e1ae2  movq xmm1, r12
000076b67a9e1ae7  movq xmm15, r11
000076b67a9e1aec  movq xmm1, xmm1
000076b67a9e1af0  movq xmm1, xmm1
000076b67a9e1af4  movaps [r15+0x1A0], xmm1
000076b67a9e1afc  movq xmm15, xmm15
000076b67a9e1b01  movq xmm15, xmm15
000076b67a9e1b06  movaps [r15+0x190], xmm15
000076b67a9e1b0e  lea r14, [rax+0x120]
000076b67a9e1b15  mov r12, [r13+r14*1]
000076b67a9e1b1a  lea r14, [rax+0x128]
000076b67a9e1b21  mov r11, [r13+r14*1]
000076b67a9e1b26  movq xmm1, r12
000076b67a9e1b2b  movq xmm15, r11
000076b67a9e1b30  movq xmm1, xmm1
000076b67a9e1b34  movq xmm1, xmm1
000076b67a9e1b38  movaps [r15+0x1C0], xmm1
000076b67a9e1b40  movq xmm15, xmm15
000076b67a9e1b45  movq xmm15, xmm15
000076b67a9e1b4a  movaps [r15+0x1B0], xmm15
000076b67a9e1b52  lea r14, [rax+0x110]
000076b67a9e1b59  mov r12, [r13+r14*1]
000076b67a9e1b5e  lea r14, [rax+0x118]
000076b67a9e1b65  mov r11, [r13+r14*1]
000076b67a9e1b6a  movq xmm1, r12
000076b67a9e1b6f  movq xmm15, r11
000076b67a9e1b74  movq xmm1, xmm1
000076b67a9e1b78  movq xmm1, xmm1
000076b67a9e1b7c  movaps [r15+0x1E0], xmm1
000076b67a9e1b84  movq xmm15, xmm15
000076b67a9e1b89  movq xmm15, xmm15
000076b67a9e1b8e  movaps [r15+0x1D0], xmm15
000076b67a9e1b96  lea r14, [rax+0x100]
000076b67a9e1b9d  mov r12, [r13+r14*1]
000076b67a9e1ba2  lea r14, [rax+0x108]
000076b67a9e1ba9  mov r11, [r13+r14*1]
000076b67a9e1bae  movq xmm1, r12
000076b67a9e1bb3  movq xmm15, r11
000076b67a9e1bb8  movq xmm1, xmm1
000076b67a9e1bbc  movq xmm1, xmm1
000076b67a9e1bc0  movaps [r15+0x200], xmm1
000076b67a9e1bc8  movq xmm15, xmm15
000076b67a9e1bcd  movq xmm15, xmm15
000076b67a9e1bd2  movaps [r15+0x1F0], xmm15
000076b67a9e1bda  mov qword ptr [r15+0x40], 0x430000
000076b67a9e1be2  mov r14d, 0x430510
000076b67a9e1be8  mov r12, [r13+r14*1]
000076b67a9e1bed  movq xmm1, r12
000076b67a9e1bf2  lea r14, [rax+0x150]
000076b67a9e1bf9  mov [r15+0xF8], r14
000076b67a9e1c00  mov rax, [r15+0x50]
000076b67a9e1c04  movups xmm15, [r13+rax*1]
000076b67a9e1c0a  movaps [r15+0x120], xmm15
000076b67a9e1c12  mov qword ptr [r15+0x48], 0x10
000076b67a9e1c1a  xor eax, eax
000076b67a9e1c1c  mov r14d, 0x10
000076b67a9e1c22  mov r12d, 0x200
000076b67a9e1c28  cmp r14, r12
000076b67a9e1c2b  cmc
000076b67a9e1c2c  lahf
000076b67a9e1c2d  seto al
000076b67a9e1c30  mov [r15+0x108], eax
000076b67a9e1c37  pextrq rax, xmm15, 0x01
000076b67a9e1c3e  movq xmm14, rax
000076b67a9e1c43  movaps [r15+0x130], xmm14
000076b67a9e1c4b  movq rax, xmm1
000076b67a9e1c50  movq r14, xmm15
000076b67a9e1c55  vmovq xmm1, rax
000076b67a9e1c5a  vmovq xmm15, r14
000076b67a9e1c5f  movaps xmm13, xmm1
000076b67a9e1c63  addsd xmm13, xmm15
000076b67a9e1c68  ucomisd xmm13, xmm13
000076b67a9e1c6d  jp 0x000076B67A9E1D86
000076b67a9e1c73  movq xmm13, xmm13
000076b67a9e1c78  movq rax, xmm13
000076b67a9e1c7d  movq r14, xmm14
000076b67a9e1c82  vmovq xmm1, rax
000076b67a9e1c87  vmovq xmm15, r14
000076b67a9e1c8c  movaps xmm14, xmm1
000076b67a9e1c90  addsd xmm14, xmm15
000076b67a9e1c95  ucomisd xmm14, xmm14
000076b67a9e1c9a  jp 0x000076B67A9E1DCE
000076b67a9e1ca0  movq xmm14, xmm14
000076b67a9e1ca5  movaps [r15+0x110], xmm14
000076b67a9e1cad  mov eax, [r15+0x108]
000076b67a9e1cb4  sahf
000076b67a9e1cb5  jnz 0x000076B67A9E1CE7
000076b67a9e1cb7  cmp dword ptr [r15+0x318], 0x00
000076b67a9e1cbf  jz 0x000076B67A9E1FE0
000076b67a9e1cc5  nop [rax+rax*1], ax
000076b67a9e1cce  nop [rax+rax*1], eax
000076b67a9e1cd6  mov eax, 0x410490
000076b67a9e1cdb  mov [r15+0x100], rax
000076b67a9e1ce2  jmp 0x000076B67A7FE110
000076b67a9e1ce7  cmp dword ptr [r15+0x318], 0x00
000076b67a9e1cef  jz 0x000076B67A9E1E20
000076b67a9e1cf5  nop [rax+rax*1], ax
000076b67a9e1cfe  nop [rax+rax*1], eax
000076b67a9e1d06  mov eax, 0x410474
000076b67a9e1d0b  mov [r15+0x100], rax
000076b67a9e1d12  jmp 0x000076B67A7FE110
000076b67a9e1d17  int3
000076b67a9e1d18  call 0x000076B67A8E27E0
000076b67a9e1d1d  jmp 0x000076B67A9E1AC3
000076b67a9e1d22  call 0x000076B67A8E27E0
000076b67a9e1d27  jmp 0x000076B67A9E1AD6
000076b67a9e1d2c  call 0x000076B67A8E1570
000076b67a9e1d31  jmp 0x000076B67A9E1AE2
000076b67a9e1d36  call 0x000076B67A8E27E0
000076b67a9e1d3b  jmp 0x000076B67A9E1B1A
000076b67a9e1d40  call 0x000076B67A8E1570
000076b67a9e1d45  jmp 0x000076B67A9E1B26
000076b67a9e1d4a  call 0x000076B67A8E27E0
000076b67a9e1d4f  jmp 0x000076B67A9E1B5E
000076b67a9e1d54  call 0x000076B67A8E1570
000076b67a9e1d59  jmp 0x000076B67A9E1B6A
000076b67a9e1d5e  call 0x000076B67A8E27E0
000076b67a9e1d63  jmp 0x000076B67A9E1BA2
000076b67a9e1d68  call 0x000076B67A8E1570
000076b67a9e1d6d  jmp 0x000076B67A9E1BAE
000076b67a9e1d72  call 0x000076B67A8E27E0
000076b67a9e1d77  jmp 0x000076B67A9E1BED
000076b67a9e1d7c  call 0x000076B67A80E760
000076b67a9e1d81  jmp 0x000076B67A9E1C0A
000076b67a9e1d86  ucomisd xmm1, xmm15
000076b67a9e1d8b  jp 0x000076B67A9E1D9A
000076b67a9e1d8d  movaps xmm13, [0x000076B67A5FE060]
000076b67a9e1d95  jmp 0x000076B67A9E1C73
000076b67a9e1d9a  vxorps xmm0, xmm1, xmm15
000076b67a9e1d9f  pextrw eax, xmm0, 0x03
000076b67a9e1da4  and eax, 0x7FF8
000076b67a9e1da9  cmp eax, 0x08
000076b67a9e1dac  jnz 0x000076B67A9E1C73
000076b67a9e1db2  movq rax, xmm15
000076b67a9e1db7  shl rax, 0x0D
000076b67a9e1dbb  jbe 0x000076B67A9E1C73
000076b67a9e1dc1  vorps xmm13, xmm15, [0x000076B67A5FE070]
000076b67a9e1dc9  jmp 0x000076B67A9E1C73
000076b67a9e1dce  ucomisd xmm1, xmm15
000076b67a9e1dd3  jp 0x000076B67A9E1DE2
000076b67a9e1dd5  movaps xmm14, [0x000076B67A5FE060]
000076b67a9e1ddd  jmp 0x000076B67A9E1CA0
000076b67a9e1de2  vxorps xmm0, xmm1, xmm15
000076b67a9e1de7  pextrw eax, xmm0, 0x03
000076b67a9e1dec  and eax, 0x7FF8
000076b67a9e1df1  cmp eax, 0x08
000076b67a9e1df4  jnz 0x000076B67A9E1CA0
000076b67a9e1dfa  movq rax, xmm15
000076b67a9e1dff  shl rax, 0x0D
000076b67a9e1e03  jbe 0x000076B67A9E1CA0
000076b67a9e1e09  vorps xmm14, xmm15, [0x000076B67A5FE070]
000076b67a9e1e11  jmp 0x000076B67A9E1CA0
000076b67a9e1e16  int3
000076b67a9e1e17  nop [rax+rax*1], ax
000076b67a9e1e20  mov rax, [r15+0x48]
000076b67a9e1e24  mov r14, [r15+0x50]
000076b67a9e1e28  lea r12, [r14+rax*1]
000076b67a9e1e2c  movups xmm1, [r13+r12*1]
000076b67a9e1e32  movaps [r15+0x120], xmm1
000076b67a9e1e3a  lea r14, [rax+0x10]
000076b67a9e1e3e  mov [r15+0x48], r14
000076b67a9e1e42  xor eax, eax
000076b67a9e1e44  mov r12d, 0x200
000076b67a9e1e4a  cmp r14, r12
000076b67a9e1e4d  cmc
000076b67a9e1e4e  lahf
000076b67a9e1e4f  seto al
000076b67a9e1e52  mov [r15+0x108], eax
000076b67a9e1e59  pextrq rax, xmm1, 0x01
000076b67a9e1e60  movq xmm15, rax
000076b67a9e1e65  movaps [r15+0x130], xmm15
000076b67a9e1e6d  movaps xmm14, [r15+0x110]
000076b67a9e1e75  movq rax, xmm14
000076b67a9e1e7a  movq r14, xmm1
000076b67a9e1e7f  vmovq xmm1, rax
000076b67a9e1e84  vmovq xmm14, r14
000076b67a9e1e89  movaps xmm13, xmm1
000076b67a9e1e8d  addsd xmm13, xmm14
000076b67a9e1e92  ucomisd xmm13, xmm13
000076b67a9e1e97  jp 0x000076B67A9E1F4C
000076b67a9e1e9d  movq xmm13, xmm13
000076b67a9e1ea2  movq rax, xmm13
000076b67a9e1ea7  movq r14, xmm15
000076b67a9e1eac  vmovq xmm1, rax
000076b67a9e1eb1  vmovq xmm15, r14
000076b67a9e1eb6  movaps xmm14, xmm1
000076b67a9e1eba  addsd xmm14, xmm15
000076b67a9e1ebf  ucomisd xmm14, xmm14
000076b67a9e1ec4  jp 0x000076B67A9E1F94
000076b67a9e1eca  movq xmm14, xmm14
000076b67a9e1ecf  movaps [r15+0x110], xmm14
000076b67a9e1ed7  mov eax, [r15+0x108]
000076b67a9e1ede  sahf
000076b67a9e1edf  jnz 0x000076B67A9E1F11
000076b67a9e1ee1  cmp dword ptr [r15+0x318], 0x00
000076b67a9e1ee9  jz 0x000076B67A9E1FE0
000076b67a9e1eef  nop [rax+rax*1], ax
000076b67a9e1ef8  nop [rax+rax*1], eax
000076b67a9e1f00  mov eax, 0x410490
000076b67a9e1f05  mov [r15+0x100], rax
000076b67a9e1f0c  jmp 0x000076B67A7FE110
000076b67a9e1f11  cmp dword ptr [r15+0x318], 0x00
000076b67a9e1f19  jz 0x000076B67A9E1E20
000076b67a9e1f1f  nop [rax+rax*1], ax
000076b67a9e1f28  nop [rax+rax*1], eax
000076b67a9e1f30  mov eax, 0x410474
000076b67a9e1f35  mov [r15+0x100], rax
000076b67a9e1f3c  jmp 0x000076B67A7FE110
000076b67a9e1f41  int3
000076b67a9e1f42  call 0x000076B67A8B52F0
000076b67a9e1f47  jmp 0x000076B67A9E1E32
000076b67a9e1f4c  ucomisd xmm1, xmm14
000076b67a9e1f51  jp 0x000076B67A9E1F60
000076b67a9e1f53  movaps xmm13, [0x000076B67A5FE060]
000076b67a9e1f5b  jmp 0x000076B67A9E1E9D
000076b67a9e1f60  vxorps xmm0, xmm1, xmm14
000076b67a9e1f65  pextrw eax, xmm0, 0x03
000076b67a9e1f6a  and eax, 0x7FF8
000076b67a9e1f6f  cmp eax, 0x08
000076b67a9e1f72  jnz 0x000076B67A9E1E9D
000076b67a9e1f78  movq rax, xmm14
000076b67a9e1f7d  shl rax, 0x0D
000076b67a9e1f81  jbe 0x000076B67A9E1E9D
000076b67a9e1f87  vorps xmm13, xmm14, [0x000076B67A5FE070]
000076b67a9e1f8f  jmp 0x000076B67A9E1E9D
000076b67a9e1f94  ucomisd xmm1, xmm15
000076b67a9e1f99  jp 0x000076B67A9E1FA8
000076b67a9e1f9b  movaps xmm14, [0x000076B67A5FE060]
000076b67a9e1fa3  jmp 0x000076B67A9E1ECA
000076b67a9e1fa8  vxorps xmm0, xmm1, xmm15
000076b67a9e1fad  pextrw eax, xmm0, 0x03
000076b67a9e1fb2  and eax, 0x7FF8
000076b67a9e1fb7  cmp eax, 0x08
000076b67a9e1fba  jnz 0x000076B67A9E1ECA
000076b67a9e1fc0  movq rax, xmm15
000076b67a9e1fc5  shl rax, 0x0D
000076b67a9e1fc9  jbe 0x000076B67A9E1ECA
000076b67a9e1fcf  vorps xmm14, xmm15, [0x000076B67A5FE070]
000076b67a9e1fd7  jmp 0x000076B67A9E1ECA
000076b67a9e1fdc  int3
000076b67a9e1fdd  nop [rax], eax
000076b67a9e1fe0  mov rax, [r15+0x40]
000076b67a9e1fe4  lea r14, [rax+0x510]
000076b67a9e1feb  movaps xmm1, [r15+0x110]
000076b67a9e1ff3  movq rax, xmm1
000076b67a9e1ff8  mov [r13+r14*1], rax
000076b67a9e1ffd  mov rax, [r15+0xF0]
000076b67a9e2004  mov [r15+0x100], rax
000076b67a9e200b  jmp 0x000076B67A9CE5C0
000076b67a9e2010  int3
000076b67a9e2011  call 0x000076B67A8D5EB0
000076b67a9e2016  jmp 0x000076B67A9E1FFD
000076b67a9e201b  int3
000076b67a9e201c  nop [rax], eax
000076b67a9e2020  mov qword ptr [r15+0x100], 0x04
000076b67a9e202b  mov esi, 0x00
000076b67a9e2030  mov edx, 0x09
000076b67a9e2035  mov rdi, 0x7FFF7DE2CAB0
000076b67a9e203f  mov rax, 0x63C5EF172970
000076b67a9e2049  call rax
000076b67a9e204b  cmp dword ptr [r15+0x318], 0x00
000076b67a9e2053  jnz 0x000076B67A7FE110
000076b67a9e2059  jmp 0x000076B67A7FE0A0
000076b67a9e205e  int3
000076b67a9e205f  int3
