0000798fc6fce69b  nop [rax+rax*1], eax
0000798fc6fce6a0  vmovaps xmm1, [0x0000798FC6BFE010]
0000798fc6fce6a8  movq xmm1, xmm1
0000798fc6fce6ac  movaps [r15+0x110], xmm1
0000798fc6fce6b4  vmovaps xmm1, [0x0000798FC6BFE020]
0000798fc6fce6bc  movq xmm1, xmm1
0000798fc6fce6c0  movaps [r15+0x120], xmm1
0000798fc6fce6c8  mov eax, 0x4204C0
0000798fc6fce6cd  mov r14, [r13+rax*1]
0000798fc6fce6d2  movq xmm1, r14
0000798fc6fce6d7  movaps [r15+0x130], xmm1
0000798fc6fce6df  vmovaps xmm1, [0x0000798FC6BFE030]
0000798fc6fce6e7  vpbroadcastq xmm1, xmm1
0000798fc6fce6ec  movaps [r15+0x140], xmm1
0000798fc6fce6f4  mov qword ptr [r15+0x40], 0x02
0000798fc6fce6fc  vmovaps xmm15, [0x0000798FC6BFE040]
0000798fc6fce704  movq xmm15, xmm15
0000798fc6fce709  movaps [r15+0x150], xmm15
0000798fc6fce711  mov qword ptr [r15+0x58], 0x420000
0000798fc6fce719  vmovaps xmm15, [0x0000798FC6BFE050]
0000798fc6fce721  vpbroadcastq xmm15, xmm15
0000798fc6fce726  movaps [r15+0x160], xmm15
0000798fc6fce72e  mov rax, [r15+0x40]
0000798fc6fce732  vmovq xmm14, rax
0000798fc6fce737  vpbroadcastq xmm14, xmm14
0000798fc6fce73c  movaps [r15+0x170], xmm14
0000798fc6fce744  mov eax, 0x4204D0
0000798fc6fce749  movups xmm13, [r13+rax*1]
0000798fc6fce74f  mov qword ptr [r15+0x40], 0x430518
0000798fc6fce757  mov qword ptr [r15+0x50], 0x430720
0000798fc6fce75f  vpmovqd xmm12, xmm13
0000798fc6fce765  pxor xmm11, xmm11
0000798fc6fce76a  punpcklqdq xmm12, xmm11
0000798fc6fce76f  movaps [r15+0x210], xmm12
0000798fc6fce777  movq xmm12, qword ptr [r15+0x120]
0000798fc6fce780  movq xmm11, qword ptr [r15+0x130]
0000798fc6fce789  psubd xmm12, xmm11
0000798fc6fce78e  movq xmm12, xmm12
0000798fc6fce793  paddq xmm13, xmm14
0000798fc6fce798  movaps [r15+0x180], xmm13
0000798fc6fce7a0  movq xmm14, qword ptr [r15+0x150]
0000798fc6fce7a9  paddd xmm11, xmm14
0000798fc6fce7ae  movq xmm11, xmm11
0000798fc6fce7b3  movq xmm11, xmm11
0000798fc6fce7b8  movaps [r15+0x130], xmm11
0000798fc6fce7c0  pmovzxdq xmm12, xmm12
0000798fc6fce7c6  psllq xmm12, 0x00
0000798fc6fce7cc  movq xmm14, qword ptr [r15+0x210]
0000798fc6fce7d5  movq xmm13, qword ptr [r15+0x110]
0000798fc6fce7de  paddd xmm14, xmm13
0000798fc6fce7e3  movq xmm14, xmm14
0000798fc6fce7e8  vcvtuqq2pd xmm12, xmm12
0000798fc6fce7ee  pmovzxdq xmm14, xmm14
0000798fc6fce7f4  psllq xmm14, 0x00
0000798fc6fce7fa  vcvtuqq2pd xmm14, xmm14
0000798fc6fce800  movaps xmm13, xmm12
0000798fc6fce804  mulpd xmm13, xmm1
0000798fc6fce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000798fc6fce80f  ptest xmm11, xmm11
0000798fc6fce815  jnz 0x0000798FC6FCE8FF
0000798fc6fce81b  movaps [r15+0x220], xmm13
0000798fc6fce823  mov eax, 0x430720
0000798fc6fce828  movups [r13+rax*1], xmm13
0000798fc6fce82e  movaps xmm1, xmm14
0000798fc6fce832  mulpd xmm1, xmm15
0000798fc6fce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000798fc6fce83c  ptest xmm13, xmm13
0000798fc6fce842  jnz 0x0000798FC6FCEA4C
0000798fc6fce848  movaps [r15+0x210], xmm1
0000798fc6fce850  mov eax, 0x430518
0000798fc6fce855  movups [r13+rax*1], xmm1
0000798fc6fce85b  mov qword ptr [r15+0x48], 0x10
0000798fc6fce863  xor eax, eax
0000798fc6fce865  mov r14d, 0x10
0000798fc6fce86b  mov r12d, 0x200
0000798fc6fce871  cmp r14, r12
0000798fc6fce874  cmc
0000798fc6fce875  lahf
0000798fc6fce876  seto al
0000798fc6fce879  mov [r15+0x108], eax
0000798fc6fce880  mov eax, [r15+0x108]
0000798fc6fce887  sahf
0000798fc6fce888  jnz 0x0000798FC6FCE8BA
0000798fc6fce88a  cmp dword ptr [r15+0x318], 0x00
0000798fc6fce892  jz 0x0000798FC6FCEFF0
0000798fc6fce898  nop [rax+rax*1], ax
0000798fc6fce8a1  nop [rax+rax*1], eax
0000798fc6fce8a9  mov eax, 0x4101EC
0000798fc6fce8ae  mov [r15+0x100], rax
0000798fc6fce8b5  jmp 0x0000798FC6DFE110
0000798fc6fce8ba  cmp dword ptr [r15+0x318], 0x00
0000798fc6fce8c2  jz 0x0000798FC6FCEBA0
0000798fc6fce8c8  nop [rax+rax*1], ax
0000798fc6fce8d1  nop [rax+rax*1], eax
0000798fc6fce8d9  mov eax, 0x4101AC
0000798fc6fce8de  mov [r15+0x100], rax
0000798fc6fce8e5  jmp 0x0000798FC6DFE110
0000798fc6fce8ea  int3
0000798fc6fce8eb  call 0x0000798FC6E0DC20
0000798fc6fce8f0  jmp 0x0000798FC6FCE6D2
0000798fc6fce8f5  call 0x0000798FC6E0C260
0000798fc6fce8fa  jmp 0x0000798FC6FCE74F
0000798fc6fce8ff  sub rsp, 0x08
0000798fc6fce903  push rax
0000798fc6fce904  push rcx
0000798fc6fce905  push rdx
0000798fc6fce906  push rdi
0000798fc6fce907  push rsi
0000798fc6fce908  push r8
0000798fc6fce90a  push r9
0000798fc6fce90c  push r10
0000798fc6fce90e  push r11
0000798fc6fce910  sub rsp, 0xF0
0000798fc6fce917  vmovaps [rsp], xmm0
0000798fc6fce91c  vmovaps [rsp+0x10], xmm1
0000798fc6fce922  vmovaps [rsp+0x20], xmm2
0000798fc6fce928  vmovaps [rsp+0x30], xmm3
0000798fc6fce92e  vmovaps [rsp+0x40], xmm4
0000798fc6fce934  vmovaps [rsp+0x50], xmm5
0000798fc6fce93a  vmovaps [rsp+0x60], xmm6
0000798fc6fce940  vmovaps [rsp+0x70], xmm7
0000798fc6fce946  vmovaps [rsp+0x80], xmm8
0000798fc6fce94f  vmovaps [rsp+0x90], xmm9
0000798fc6fce958  vmovaps [rsp+0xA0], xmm10
0000798fc6fce961  vmovaps [rsp+0xB0], xmm11
0000798fc6fce96a  vmovaps [rsp+0xC0], xmm12
0000798fc6fce973  vmovaps [rsp+0xD0], xmm14
0000798fc6fce97c  vmovaps [rsp+0xE0], xmm15
0000798fc6fce985  sub rsp, 0x30
0000798fc6fce989  movaps [rsp], xmm13
0000798fc6fce98e  movaps [rsp+0x10], xmm12
0000798fc6fce994  movaps [rsp+0x20], xmm1
0000798fc6fce999  lea rdi, [rsp]
0000798fc6fce99d  mov esi, 0x00
0000798fc6fce9a2  mov rax, 0x63E558B23530
0000798fc6fce9ac  call rax
0000798fc6fce9ae  movaps xmm13, [rsp]
0000798fc6fce9b3  add rsp, 0x30
0000798fc6fce9b7  vmovaps xmm0, [rsp]
0000798fc6fce9bc  vmovaps xmm1, [rsp+0x10]
0000798fc6fce9c2  vmovaps xmm2, [rsp+0x20]
0000798fc6fce9c8  vmovaps xmm3, [rsp+0x30]
0000798fc6fce9ce  vmovaps xmm4, [rsp+0x40]
0000798fc6fce9d4  vmovaps xmm5, [rsp+0x50]
0000798fc6fce9da  vmovaps xmm6, [rsp+0x60]
0000798fc6fce9e0  vmovaps xmm7, [rsp+0x70]
0000798fc6fce9e6  vmovaps xmm8, [rsp+0x80]
0000798fc6fce9ef  vmovaps xmm9, [rsp+0x90]
0000798fc6fce9f8  vmovaps xmm10, [rsp+0xA0]
0000798fc6fcea01  vmovaps xmm11, [rsp+0xB0]
0000798fc6fcea0a  vmovaps xmm12, [rsp+0xC0]
0000798fc6fcea13  vmovaps xmm14, [rsp+0xD0]
0000798fc6fcea1c  vmovaps xmm15, [rsp+0xE0]
0000798fc6fcea25  add rsp, 0xF0
0000798fc6fcea2c  pop r11
0000798fc6fcea2e  pop r10
0000798fc6fcea30  pop r9
0000798fc6fcea32  pop r8
0000798fc6fcea34  pop rsi
0000798fc6fcea35  pop rdi
0000798fc6fcea36  pop rdx
0000798fc6fcea37  pop rcx
0000798fc6fcea38  pop rax
0000798fc6fcea39  add rsp, 0x08
0000798fc6fcea3d  jmp 0x0000798FC6FCE81B
0000798fc6fcea42  call 0x0000798FC6E0C380
0000798fc6fcea47  jmp 0x0000798FC6FCE82E
0000798fc6fcea4c  sub rsp, 0x08
0000798fc6fcea50  push rax
0000798fc6fcea51  push rcx
0000798fc6fcea52  push rdx
0000798fc6fcea53  push rdi
0000798fc6fcea54  push rsi
0000798fc6fcea55  push r8
0000798fc6fcea57  push r9
0000798fc6fcea59  push r10
0000798fc6fcea5b  push r11
0000798fc6fcea5d  sub rsp, 0xF0
0000798fc6fcea64  vmovaps [rsp], xmm0
0000798fc6fcea69  vmovaps [rsp+0x10], xmm2
0000798fc6fcea6f  vmovaps [rsp+0x20], xmm3
0000798fc6fcea75  vmovaps [rsp+0x30], xmm4
0000798fc6fcea7b  vmovaps [rsp+0x40], xmm5
0000798fc6fcea81  vmovaps [rsp+0x50], xmm6
0000798fc6fcea87  vmovaps [rsp+0x60], xmm7
0000798fc6fcea8d  vmovaps [rsp+0x70], xmm8
0000798fc6fcea93  vmovaps [rsp+0x80], xmm9
0000798fc6fcea9c  vmovaps [rsp+0x90], xmm10
0000798fc6fceaa5  vmovaps [rsp+0xA0], xmm11
0000798fc6fceaae  vmovaps [rsp+0xB0], xmm12
0000798fc6fceab7  vmovaps [rsp+0xC0], xmm13
0000798fc6fceac0  vmovaps [rsp+0xD0], xmm14
0000798fc6fceac9  vmovaps [rsp+0xE0], xmm15
0000798fc6fcead2  sub rsp, 0x30
0000798fc6fcead6  movaps [rsp], xmm1
0000798fc6fceada  movaps [rsp+0x10], xmm14
0000798fc6fceae0  movaps [rsp+0x20], xmm15
0000798fc6fceae6  lea rdi, [rsp]
0000798fc6fceaea  mov esi, 0x00
0000798fc6fceaef  mov rax, 0x63E558B23530
0000798fc6fceaf9  call rax
0000798fc6fceafb  movaps xmm1, [rsp]
0000798fc6fceaff  add rsp, 0x30
0000798fc6fceb03  vmovaps xmm0, [rsp]
0000798fc6fceb08  vmovaps xmm2, [rsp+0x10]
0000798fc6fceb0e  vmovaps xmm3, [rsp+0x20]
0000798fc6fceb14  vmovaps xmm4, [rsp+0x30]
0000798fc6fceb1a  vmovaps xmm5, [rsp+0x40]
0000798fc6fceb20  vmovaps xmm6, [rsp+0x50]
0000798fc6fceb26  vmovaps xmm7, [rsp+0x60]
0000798fc6fceb2c  vmovaps xmm8, [rsp+0x70]
0000798fc6fceb32  vmovaps xmm9, [rsp+0x80]
0000798fc6fceb3b  vmovaps xmm10, [rsp+0x90]
0000798fc6fceb44  vmovaps xmm11, [rsp+0xA0]
0000798fc6fceb4d  vmovaps xmm12, [rsp+0xB0]
0000798fc6fceb56  vmovaps xmm13, [rsp+0xC0]
0000798fc6fceb5f  vmovaps xmm14, [rsp+0xD0]
0000798fc6fceb68  vmovaps xmm15, [rsp+0xE0]
0000798fc6fceb71  add rsp, 0xF0
0000798fc6fceb78  pop r11
0000798fc6fceb7a  pop r10
0000798fc6fceb7c  pop r9
0000798fc6fceb7e  pop r8
0000798fc6fceb80  pop rsi
0000798fc6fceb81  pop rdi
0000798fc6fceb82  pop rdx
0000798fc6fceb83  pop rcx
0000798fc6fceb84  pop rax
0000798fc6fceb85  add rsp, 0x08
0000798fc6fceb89  jmp 0x0000798FC6FCE848
0000798fc6fceb8e  call 0x0000798FC6DFF540
0000798fc6fceb93  jmp 0x0000798FC6FCE85B
0000798fc6fceb98  int3
0000798fc6fceb99  nop [rax], eax
0000798fc6fceba0  movaps xmm1, [r15+0x180]
0000798fc6fceba8  vpmovqd xmm15, xmm1
0000798fc6fcebae  pxor xmm14, xmm14
0000798fc6fcebb3  punpcklqdq xmm15, xmm14
0000798fc6fcebb8  movaps [r15+0x210], xmm15
0000798fc6fcebc0  movq xmm15, qword ptr [r15+0x120]
0000798fc6fcebc9  movq xmm14, qword ptr [r15+0x130]
0000798fc6fcebd2  psubd xmm15, xmm14
0000798fc6fcebd7  movq xmm15, xmm15
0000798fc6fcebdc  movaps xmm13, [r15+0x170]
0000798fc6fcebe4  paddq xmm1, xmm13
0000798fc6fcebe9  movaps [r15+0x180], xmm1
0000798fc6fcebf1  movq xmm1, qword ptr [r15+0x150]
0000798fc6fcebfa  paddd xmm14, xmm1
0000798fc6fcebff  movq xmm14, xmm14
0000798fc6fcec04  movq xmm14, xmm14
0000798fc6fcec09  movaps [r15+0x130], xmm14
0000798fc6fcec11  pmovzxdq xmm15, xmm15
0000798fc6fcec17  psllq xmm15, 0x00
0000798fc6fcec1d  movq xmm1, qword ptr [r15+0x210]
0000798fc6fcec26  movq xmm14, qword ptr [r15+0x110]
0000798fc6fcec2f  paddd xmm1, xmm14
0000798fc6fcec34  movq xmm1, xmm1
0000798fc6fcec38  vcvtuqq2pd xmm15, xmm15
0000798fc6fcec3e  pmovzxdq xmm1, xmm1
0000798fc6fcec43  psllq xmm1, 0x00
0000798fc6fcec48  vcvtuqq2pd xmm1, xmm1
0000798fc6fcec4e  movaps xmm14, [r15+0x140]
0000798fc6fcec56  movaps xmm13, xmm15
0000798fc6fcec5a  mulpd xmm13, xmm14
0000798fc6fcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000798fc6fcec65  ptest xmm12, xmm12
0000798fc6fcec6b  jnz 0x0000798FC6FCED4E
0000798fc6fcec71  movaps [r15+0x220], xmm13
0000798fc6fcec79  mov rax, [r15+0x48]
0000798fc6fcec7d  mov r14, [r15+0x50]
0000798fc6fcec81  lea r12, [r14+rax*1]
0000798fc6fcec85  movups [r13+r12*1], xmm13
0000798fc6fcec8b  movaps xmm15, [r15+0x160]
0000798fc6fcec93  movaps xmm14, xmm1
0000798fc6fcec97  mulpd xmm14, xmm15
0000798fc6fcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000798fc6fceca2  ptest xmm13, xmm13
0000798fc6fceca8  jnz 0x0000798FC6FCEE9C
0000798fc6fcecae  movaps [r15+0x210], xmm14
0000798fc6fcecb6  mov r14, [r15+0x40]
0000798fc6fcecba  lea r12, [r14+rax*1]
0000798fc6fcecbe  movups [r13+r12*1], xmm14
0000798fc6fcecc4  lea r14, [rax+0x10]
0000798fc6fcecc8  mov [r15+0x48], r14
0000798fc6fceccc  xor eax, eax
0000798fc6fcecce  mov r12d, 0x200
0000798fc6fcecd4  cmp r14, r12
0000798fc6fcecd7  cmc
0000798fc6fcecd8  lahf
0000798fc6fcecd9  seto al
0000798fc6fcecdc  mov [r15+0x108], eax
0000798fc6fcece3  mov eax, [r15+0x108]
0000798fc6fcecea  sahf
0000798fc6fceceb  jnz 0x0000798FC6FCED1D
0000798fc6fceced  cmp dword ptr [r15+0x318], 0x00
0000798fc6fcecf5  jz 0x0000798FC6FCEFF0
0000798fc6fcecfb  nop [rax+rax*1], ax
0000798fc6fced04  nop [rax+rax*1], eax
0000798fc6fced0c  mov eax, 0x4101EC
0000798fc6fced11  mov [r15+0x100], rax
0000798fc6fced18  jmp 0x0000798FC6DFE110
0000798fc6fced1d  cmp dword ptr [r15+0x318], 0x00
0000798fc6fced25  jz 0x0000798FC6FCEBA0
0000798fc6fced2b  nop [rax+rax*1], ax
0000798fc6fced34  nop [rax+rax*1], eax
0000798fc6fced3c  mov eax, 0x4101AC
0000798fc6fced41  mov [r15+0x100], rax
0000798fc6fced48  jmp 0x0000798FC6DFE110
0000798fc6fced4d  int3
0000798fc6fced4e  sub rsp, 0x08
0000798fc6fced52  push rax
0000798fc6fced53  push rcx
0000798fc6fced54  push rdx
0000798fc6fced55  push rdi
0000798fc6fced56  push rsi
0000798fc6fced57  push r8
0000798fc6fced59  push r9
0000798fc6fced5b  push r10
0000798fc6fced5d  push r11
0000798fc6fced5f  sub rsp, 0xF0
0000798fc6fced66  vmovaps [rsp], xmm0
0000798fc6fced6b  vmovaps [rsp+0x10], xmm1
0000798fc6fced71  vmovaps [rsp+0x20], xmm2
0000798fc6fced77  vmovaps [rsp+0x30], xmm3
0000798fc6fced7d  vmovaps [rsp+0x40], xmm4
0000798fc6fced83  vmovaps [rsp+0x50], xmm5
0000798fc6fced89  vmovaps [rsp+0x60], xmm6
0000798fc6fced8f  vmovaps [rsp+0x70], xmm7
0000798fc6fced95  vmovaps [rsp+0x80], xmm8
0000798fc6fced9e  vmovaps [rsp+0x90], xmm9
0000798fc6fceda7  vmovaps [rsp+0xA0], xmm10
0000798fc6fcedb0  vmovaps [rsp+0xB0], xmm11
0000798fc6fcedb9  vmovaps [rsp+0xC0], xmm12
0000798fc6fcedc2  vmovaps [rsp+0xD0], xmm14
0000798fc6fcedcb  vmovaps [rsp+0xE0], xmm15
0000798fc6fcedd4  sub rsp, 0x30
0000798fc6fcedd8  movaps [rsp], xmm13
0000798fc6fceddd  movaps [rsp+0x10], xmm15
0000798fc6fcede3  movaps [rsp+0x20], xmm14
0000798fc6fcede9  lea rdi, [rsp]
0000798fc6fceded  mov esi, 0x00
0000798fc6fcedf2  mov rax, 0x63E558B23530
0000798fc6fcedfc  call rax
0000798fc6fcedfe  movaps xmm13, [rsp]
0000798fc6fcee03  add rsp, 0x30
0000798fc6fcee07  vmovaps xmm0, [rsp]
0000798fc6fcee0c  vmovaps xmm1, [rsp+0x10]
0000798fc6fcee12  vmovaps xmm2, [rsp+0x20]
0000798fc6fcee18  vmovaps xmm3, [rsp+0x30]
0000798fc6fcee1e  vmovaps xmm4, [rsp+0x40]
0000798fc6fcee24  vmovaps xmm5, [rsp+0x50]
0000798fc6fcee2a  vmovaps xmm6, [rsp+0x60]
0000798fc6fcee30  vmovaps xmm7, [rsp+0x70]
0000798fc6fcee36  vmovaps xmm8, [rsp+0x80]
0000798fc6fcee3f  vmovaps xmm9, [rsp+0x90]
0000798fc6fcee48  vmovaps xmm10, [rsp+0xA0]
0000798fc6fcee51  vmovaps xmm11, [rsp+0xB0]
0000798fc6fcee5a  vmovaps xmm12, [rsp+0xC0]
0000798fc6fcee63  vmovaps xmm14, [rsp+0xD0]
0000798fc6fcee6c  vmovaps xmm15, [rsp+0xE0]
0000798fc6fcee75  add rsp, 0xF0
0000798fc6fcee7c  pop r11
0000798fc6fcee7e  pop r10
0000798fc6fcee80  pop r9
0000798fc6fcee82  pop r8
0000798fc6fcee84  pop rsi
0000798fc6fcee85  pop rdi
0000798fc6fcee86  pop rdx
0000798fc6fcee87  pop rcx
0000798fc6fcee88  pop rax
0000798fc6fcee89  add rsp, 0x08
0000798fc6fcee8d  jmp 0x0000798FC6FCEC71
0000798fc6fcee92  call 0x0000798FC6EC2240
0000798fc6fcee97  jmp 0x0000798FC6FCEC8B
0000798fc6fcee9c  sub rsp, 0x08
0000798fc6fceea0  push rax
0000798fc6fceea1  push rcx
0000798fc6fceea2  push rdx
0000798fc6fceea3  push rdi
0000798fc6fceea4  push rsi
0000798fc6fceea5  push r8
0000798fc6fceea7  push r9
0000798fc6fceea9  push r10
0000798fc6fceeab  push r11
0000798fc6fceead  sub rsp, 0xF0
0000798fc6fceeb4  vmovaps [rsp], xmm0
0000798fc6fceeb9  vmovaps [rsp+0x10], xmm1
0000798fc6fceebf  vmovaps [rsp+0x20], xmm2
0000798fc6fceec5  vmovaps [rsp+0x30], xmm3
0000798fc6fceecb  vmovaps [rsp+0x40], xmm4
0000798fc6fceed1  vmovaps [rsp+0x50], xmm5
0000798fc6fceed7  vmovaps [rsp+0x60], xmm6
0000798fc6fceedd  vmovaps [rsp+0x70], xmm7
0000798fc6fceee3  vmovaps [rsp+0x80], xmm8
0000798fc6fceeec  vmovaps [rsp+0x90], xmm9
0000798fc6fceef5  vmovaps [rsp+0xA0], xmm10
0000798fc6fceefe  vmovaps [rsp+0xB0], xmm11
0000798fc6fcef07  vmovaps [rsp+0xC0], xmm12
0000798fc6fcef10  vmovaps [rsp+0xD0], xmm13
0000798fc6fcef19  vmovaps [rsp+0xE0], xmm15
0000798fc6fcef22  sub rsp, 0x30
0000798fc6fcef26  movaps [rsp], xmm14
0000798fc6fcef2b  movaps [rsp+0x10], xmm1
0000798fc6fcef30  movaps [rsp+0x20], xmm15
0000798fc6fcef36  lea rdi, [rsp]
0000798fc6fcef3a  mov esi, 0x00
0000798fc6fcef3f  mov rax, 0x63E558B23530
0000798fc6fcef49  call rax
0000798fc6fcef4b  movaps xmm14, [rsp]
0000798fc6fcef50  add rsp, 0x30
0000798fc6fcef54  vmovaps xmm0, [rsp]
0000798fc6fcef59  vmovaps xmm1, [rsp+0x10]
0000798fc6fcef5f  vmovaps xmm2, [rsp+0x20]
0000798fc6fcef65  vmovaps xmm3, [rsp+0x30]
0000798fc6fcef6b  vmovaps xmm4, [rsp+0x40]
0000798fc6fcef71  vmovaps xmm5, [rsp+0x50]
0000798fc6fcef77  vmovaps xmm6, [rsp+0x60]
0000798fc6fcef7d  vmovaps xmm7, [rsp+0x70]
0000798fc6fcef83  vmovaps xmm8, [rsp+0x80]
0000798fc6fcef8c  vmovaps xmm9, [rsp+0x90]
0000798fc6fcef95  vmovaps xmm10, [rsp+0xA0]
0000798fc6fcef9e  vmovaps xmm11, [rsp+0xB0]
0000798fc6fcefa7  vmovaps xmm12, [rsp+0xC0]
0000798fc6fcefb0  vmovaps xmm13, [rsp+0xD0]
0000798fc6fcefb9  vmovaps xmm15, [rsp+0xE0]
0000798fc6fcefc2  add rsp, 0xF0
0000798fc6fcefc9  pop r11
0000798fc6fcefcb  pop r10
0000798fc6fcefcd  pop r9
0000798fc6fcefcf  pop r8
0000798fc6fcefd1  pop rsi
0000798fc6fcefd2  pop rdi
0000798fc6fcefd3  pop rdx
0000798fc6fcefd4  pop rcx
0000798fc6fcefd5  pop rax
0000798fc6fcefd6  add rsp, 0x08
0000798fc6fcefda  jmp 0x0000798FC6FCECAE
0000798fc6fcefdf  call 0x0000798FC6EC34C0
0000798fc6fcefe4  jmp 0x0000798FC6FCECC4
0000798fc6fcefe9  int3
0000798fc6fcefea  nop [rax+rax*1], ax
0000798fc6fceff0  mov rax, [r15+0xF8]
0000798fc6fceff7  lea r14, [rax-0x150]
0000798fc6fceffe  mov [r15+0xF8], r14
0000798fc6fcf005  mov rax, [r15+0x50]
0000798fc6fcf009  lea r12, [rax+0x80]
0000798fc6fcf010  movups xmm1, [r13+r12*1]
0000798fc6fcf016  lea r12, [rax+0x90]
0000798fc6fcf01d  movups xmm15, [r13+r12*1]
0000798fc6fcf023  mov qword ptr [r15+0x48], 0x00
0000798fc6fcf02b  lea r12, [rax+0x40]
0000798fc6fcf02f  movups xmm14, [r13+r12*1]
0000798fc6fcf035  lea r12, [rax+0x50]
0000798fc6fcf039  movups xmm13, [r13+r12*1]
0000798fc6fcf03f  lea r12, [r14+0x120]
0000798fc6fcf046  movq xmm12, qword ptr [r15+0x1C0]
0000798fc6fcf04f  movq xmm11, qword ptr [r15+0x1B0]
0000798fc6fcf058  movq r11, xmm12
0000798fc6fcf05d  movq r10, xmm11
0000798fc6fcf062  mov [r13+r12*1], r11
0000798fc6fcf067  lea r12, [r14+0x128]
0000798fc6fcf06e  mov [r13+r12*1], r10
0000798fc6fcf073  vxorps xmm12, xmm12, xmm12
0000798fc6fcf078  vpbroadcastq xmm12, xmm12
0000798fc6fcf07d  lea r12, [r14+0x100]
0000798fc6fcf084  movq xmm11, qword ptr [r15+0x200]
0000798fc6fcf08d  movq xmm10, qword ptr [r15+0x1F0]
0000798fc6fcf096  movq r11, xmm11
0000798fc6fcf09b  movq r10, xmm10
0000798fc6fcf0a0  mov [r13+r12*1], r11
0000798fc6fcf0a5  lea r12, [r14+0x108]
0000798fc6fcf0ac  mov [r13+r12*1], r10
0000798fc6fcf0b1  lea r12, [r14+0xE0]
0000798fc6fcf0b8  movups [r13+r12*1], xmm15
0000798fc6fcf0be  lea r12, [r14+0xF0]
0000798fc6fcf0c5  movups [r13+r12*1], xmm1
0000798fc6fcf0cb  lea r12, [rax+0xC0]
0000798fc6fcf0d2  movups xmm1, [r13+r12*1]
0000798fc6fcf0d8  lea r12, [rax+0xD0]
0000798fc6fcf0df  movups xmm15, [r13+r12*1]
0000798fc6fcf0e5  lea r12, [r14+0x110]
0000798fc6fcf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000798fc6fcf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000798fc6fcf0fe  movq r11, xmm11
0000798fc6fcf103  movq r10, xmm10
0000798fc6fcf108  mov [r13+r12*1], r11
0000798fc6fcf10d  lea r12, [r14+0x118]
0000798fc6fcf114  mov [r13+r12*1], r10
0000798fc6fcf119  movups xmm11, [r13+rax*1]
0000798fc6fcf11f  lea r12, [rax+0x10]
0000798fc6fcf123  movups xmm10, [r13+r12*1]
0000798fc6fcf129  lea r12, [r14+0x130]
0000798fc6fcf130  movq xmm9, qword ptr [r15+0x1A0]
0000798fc6fcf139  movq xmm8, qword ptr [r15+0x190]
0000798fc6fcf142  movq r11, xmm9
0000798fc6fcf147  movq r10, xmm8
0000798fc6fcf14c  mov [r13+r12*1], r11
0000798fc6fcf151  lea r12, [r14+0x138]
0000798fc6fcf158  mov [r13+r12*1], r10
0000798fc6fcf15d  lea r12, [rax+0x140]
0000798fc6fcf164  movups xmm9, [r13+r12*1]
0000798fc6fcf16a  lea r12, [rax+0x150]
0000798fc6fcf171  movups xmm8, [r13+r12*1]
0000798fc6fcf177  lea r12, [r14+0xC0]
0000798fc6fcf17e  movups [r13+r12*1], xmm15
0000798fc6fcf184  lea r12, [r14+0xD0]
0000798fc6fcf18b  movups [r13+r12*1], xmm1
0000798fc6fcf191  lea r12, [rax+0x100]
0000798fc6fcf198  movups xmm1, [r13+r12*1]
0000798fc6fcf19e  lea r12, [rax+0x110]
0000798fc6fcf1a5  movups xmm15, [r13+r12*1]
0000798fc6fcf1ab  lea r12, [r14+0x140]
0000798fc6fcf1b2  mov r11, [r15+0xE8]
0000798fc6fcf1b9  mov [r13+r12*1], r11
0000798fc6fcf1be  lea r12, [rax+0x180]
0000798fc6fcf1c5  movups xmm7, [r13+r12*1]
0000798fc6fcf1cb  lea r12, [rax+0x190]
0000798fc6fcf1d2  movups xmm6, [r13+r12*1]
0000798fc6fcf1d8  lea r12, [rax+0x1C0]
0000798fc6fcf1df  movups xmm5, [r13+r12*1]
0000798fc6fcf1e5  lea r12, [rax+0x1D0]
0000798fc6fcf1ec  movups xmm4, [r13+r12*1]
0000798fc6fcf1f2  lea r12, [r14+0x20]
0000798fc6fcf1f6  movups [r13+r12*1], xmm1
0000798fc6fcf1fc  lea r12, [r14+0x30]
0000798fc6fcf200  movups [r13+r12*1], xmm13
0000798fc6fcf206  lea r12, [rax+0x60]
0000798fc6fcf20a  movups xmm1, [r13+r12*1]
0000798fc6fcf210  lea r12, [rax+0x70]
0000798fc6fcf214  movups xmm13, [r13+r12*1]
0000798fc6fcf21a  lea r12, [rax+0x20]
0000798fc6fcf21e  movups xmm3, [r13+r12*1]
0000798fc6fcf224  lea r12, [rax+0x30]
0000798fc6fcf228  movups xmm2, [r13+r12*1]
0000798fc6fcf22e  movaps [r15+0x1F0], xmm2
0000798fc6fcf236  lea r12, [r14+0x60]
0000798fc6fcf23a  movups [r13+r12*1], xmm11
0000798fc6fcf240  lea r12, [r14+0x70]
0000798fc6fcf244  movups [r13+r12*1], xmm5
0000798fc6fcf24a  lea r12, [rax+0xE0]
0000798fc6fcf251  movups xmm11, [r13+r12*1]
0000798fc6fcf257  lea r12, [rax+0xF0]
0000798fc6fcf25e  movups xmm5, [r13+r12*1]
0000798fc6fcf264  lea r12, [r14+0xA0]
0000798fc6fcf26b  movups [r13+r12*1], xmm13
0000798fc6fcf271  lea r12, [r14+0xB0]
0000798fc6fcf278  movups [r13+r12*1], xmm1
0000798fc6fcf27e  lea r12, [rax+0xA0]
0000798fc6fcf285  movups xmm1, [r13+r12*1]
0000798fc6fcf28b  lea r12, [rax+0xB0]
0000798fc6fcf292  movups xmm13, [r13+r12*1]
0000798fc6fcf298  lea r12, [rax+0x120]
0000798fc6fcf29f  vmovaps [rsp+0x10], xmm1
0000798fc6fcf2a5  movups xmm1, [r13+r12*1]
0000798fc6fcf2ab  lea r12, [rax+0x130]
0000798fc6fcf2b2  vmovaps [rsp+0x20], xmm1
0000798fc6fcf2b8  movups xmm1, [r13+r12*1]
0000798fc6fcf2be  lea r12, [rax+0x160]
0000798fc6fcf2c5  vmovaps [rsp+0x30], xmm1
0000798fc6fcf2cb  movups xmm1, [r13+r12*1]
0000798fc6fcf2d1  lea r12, [rax+0x170]
0000798fc6fcf2d8  vmovaps [rsp+0x40], xmm1
0000798fc6fcf2de  movups xmm1, [r13+r12*1]
0000798fc6fcf2e4  movaps [r15+0x2B0], xmm1
0000798fc6fcf2ec  lea r12, [r14+0x80]
0000798fc6fcf2f3  movups [r13+r12*1], xmm13
0000798fc6fcf2f9  lea r12, [r14+0x90]
0000798fc6fcf300  vmovaps xmm13, [rsp+0x10]
0000798fc6fcf306  movups [r13+r12*1], xmm13
0000798fc6fcf30c  lea r12, [rax+0x1A0]
0000798fc6fcf313  movups xmm13, [r13+r12*1]
0000798fc6fcf319  lea r12, [rax+0x1B0]
0000798fc6fcf320  vmovaps [rsp+0x10], xmm1
0000798fc6fcf326  movups xmm1, [r13+r12*1]
0000798fc6fcf32c  movaps [r15+0x290], xmm13
0000798fc6fcf334  movaps [r15+0x1E0], xmm1
0000798fc6fcf33c  lea r12, [rax+0x1E0]
0000798fc6fcf343  vmovaps [rsp+0x50], xmm1
0000798fc6fcf349  movups xmm1, [r13+r12*1]
0000798fc6fcf34f  lea r12, [rax+0x1F0]
0000798fc6fcf356  vmovaps [rsp+0x60], xmm1
0000798fc6fcf35c  movups xmm1, [r13+r12*1]
0000798fc6fcf362  mov qword ptr [r15+0x50], 0x430920
0000798fc6fcf36a  lea rax, [r14+0x40]
0000798fc6fcf36e  vmovaps [rsp+0x70], xmm1
0000798fc6fcf374  vmovaps xmm1, [rsp+0x40]
0000798fc6fcf37a  movups [r13+rax*1], xmm1
0000798fc6fcf380  lea rax, [r14+0x50]
0000798fc6fcf384  movups [r13+rax*1], xmm10
0000798fc6fcf38a  vmovaps xmm1, [rsp+0x70]
0000798fc6fcf390  movups [r13+r14*1], xmm1
0000798fc6fcf396  lea rax, [r14+0x10]
0000798fc6fcf39a  vmovaps xmm1, [rsp+0x60]
0000798fc6fcf3a0  movups [r13+rax*1], xmm1
0000798fc6fcf3a6  mov rax, [r15+0x40]
0000798fc6fcf3aa  vmovaps [rsp+0x40], xmm3
0000798fc6fcf3b0  vmovaps xmm1, [rsp+0x40]
0000798fc6fcf3b6  por xmm3, xmm1
0000798fc6fcf3ba  vmovaps [rsp+0x40], xmm6
0000798fc6fcf3c0  vmovaps xmm10, [rsp+0x40]
0000798fc6fcf3c6  por xmm6, xmm10
0000798fc6fcf3cb  lea r12, [rax+0x30]
0000798fc6fcf3cf  mov r11, [r13+r12*1]
0000798fc6fcf3d4  lea r12, [rax+0x38]
0000798fc6fcf3d8  mov r10, [r13+r12*1]
0000798fc6fcf3dd  movq xmm10, r11
0000798fc6fcf3e2  vmovaps [rsp+0x40], xmm1
0000798fc6fcf3e8  movq xmm1, r10
0000798fc6fcf3ed  movq xmm10, xmm10
0000798fc6fcf3f2  vmovaps [rsp+0x60], xmm10
0000798fc6fcf3f8  movq xmm10, xmm10
0000798fc6fcf3fd  movaps [r15+0x130], xmm10
0000798fc6fcf405  movq xmm1, xmm1
0000798fc6fcf409  vmovaps [rsp+0x70], xmm1
0000798fc6fcf40f  movq xmm1, xmm1
0000798fc6fcf413  movaps [r15+0x280], xmm1
0000798fc6fcf41b  vmovaps [rsp+0x80], xmm9
0000798fc6fcf424  vmovaps xmm1, [rsp+0x80]
0000798fc6fcf42d  por xmm9, xmm1
0000798fc6fcf432  lea r12, [rax+0x20]
0000798fc6fcf436  mov r11, [r13+r12*1]
0000798fc6fcf43b  lea r12, [rax+0x28]
0000798fc6fcf43f  mov r10, [r13+r12*1]
0000798fc6fcf444  movq xmm1, r11
0000798fc6fcf449  movq xmm10, r10
0000798fc6fcf44e  movq xmm1, xmm1
0000798fc6fcf452  vmovaps [rsp+0x80], xmm1
0000798fc6fcf45b  movq xmm1, xmm1
0000798fc6fcf45f  movaps [r15+0x150], xmm1
0000798fc6fcf467  movq xmm10, xmm10
0000798fc6fcf46c  vmovaps [rsp+0x90], xmm10
0000798fc6fcf475  movq xmm10, xmm10
0000798fc6fcf47a  movaps [r15+0x140], xmm10
0000798fc6fcf482  lea r12, [rax+0x10]
0000798fc6fcf486  mov r11, [r13+r12*1]
0000798fc6fcf48b  lea r12, [rax+0x18]
0000798fc6fcf48f  mov r10, [r13+r12*1]
0000798fc6fcf494  movq xmm1, r11
0000798fc6fcf499  movq xmm10, r10
0000798fc6fcf49e  movq xmm1, xmm1
0000798fc6fcf4a2  vmovaps [rsp+0xA0], xmm1
0000798fc6fcf4ab  movq xmm1, xmm1
0000798fc6fcf4af  movaps [r15+0x170], xmm1
0000798fc6fcf4b7  movq xmm10, xmm10
0000798fc6fcf4bc  vmovaps [rsp+0xB0], xmm10
0000798fc6fcf4c5  movq xmm10, xmm10
0000798fc6fcf4ca  movaps [r15+0x160], xmm10
0000798fc6fcf4d2  mov r12, [r13+rax*1]
0000798fc6fcf4d7  vmovq xmm1, r12
0000798fc6fcf4dc  vpbroadcastq xmm1, xmm1
0000798fc6fcf4e1  lea r12, [rax+0x08]
0000798fc6fcf4e5  mov rax, [r13+r12*1]
0000798fc6fcf4ea  movq xmm10, rax
0000798fc6fcf4ef  movaps [r15+0x230], xmm10
0000798fc6fcf4f7  lea rax, [r14+0x50]
0000798fc6fcf4fb  movups xmm10, [r13+rax*1]
0000798fc6fcf501  lea rax, [r14+0x60]
0000798fc6fcf505  vmovaps [rsp+0xC0], xmm1
0000798fc6fcf50e  movups xmm1, [r13+rax*1]
0000798fc6fcf514  lea rax, [r14+0x30]
0000798fc6fcf518  vmovaps [rsp+0xD0], xmm1
0000798fc6fcf521  movups xmm1, [r13+rax*1]
0000798fc6fcf527  mov qword ptr [r15+0x60], 0x430920
0000798fc6fcf52f  mov qword ptr [r15+0x58], 0x40
0000798fc6fcf537  vmovaps [rsp+0xE0], xmm1
0000798fc6fcf540  vmovaps [rsp+0xF0], xmm15
0000798fc6fcf549  vmovaps xmm15, [rsp+0xC0]
0000798fc6fcf552  vmovaps [rsp+0xC0], xmm14
0000798fc6fcf55b  vmovaps xmm14, [rsp+0x40]
0000798fc6fcf561  vmovaps [rsp+0x40], xmm13
0000798fc6fcf567  movaps xmm1, xmm15
0000798fc6fcf56b  mulpd xmm1, xmm14
0000798fc6fcf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000798fc6fcf575  ptest xmm13, xmm13
0000798fc6fcf57b  jnz 0x0000798FC6FD0682
0000798fc6fcf581  movq xmm14, qword ptr [r15+0x230]
0000798fc6fcf58a  vmovaps [rsp+0x100], xmm14
0000798fc6fcf593  vpermilpd xmm14, xmm14, 0x00
0000798fc6fcf599  vmovaps [rsp+0x110], xmm1
0000798fc6fcf5a2  vmovaps xmm1, [rsp+0xE0]
0000798fc6fcf5ab  vmovaps [rsp+0xE0], xmm15
0000798fc6fcf5b4  movaps xmm13, xmm1
0000798fc6fcf5b8  mulpd xmm13, xmm14
0000798fc6fcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000798fc6fcf5c3  ptest xmm15, xmm15
0000798fc6fcf5c9  jnz 0x0000798FC6FD07C4
0000798fc6fcf5cf  vxorps xmm1, xmm1, xmm1
0000798fc6fcf5d3  vpbroadcastq xmm1, xmm1
0000798fc6fcf5d8  vmovaps xmm14, [rsp+0xE0]
0000798fc6fcf5e1  vmovaps [rsp+0xE0], xmm1
0000798fc6fcf5ea  vmovaps xmm1, [rsp+0xD0]
0000798fc6fcf5f3  vmovaps [rsp+0xD0], xmm13
0000798fc6fcf5fc  movaps xmm15, xmm14
0000798fc6fcf600  mulpd xmm15, xmm1
0000798fc6fcf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000798fc6fcf60b  ptest xmm13, xmm13
0000798fc6fcf611  jnz 0x0000798FC6FD0907
0000798fc6fcf617  movaps xmm1, xmm14
0000798fc6fcf61b  mulpd xmm1, xmm10
0000798fc6fcf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000798fc6fcf625  ptest xmm13, xmm13
0000798fc6fcf62b  jnz 0x0000798FC6FD0A4A
0000798fc6fcf631  movaps xmm13, xmm14
0000798fc6fcf635  mulpd xmm13, xmm2
0000798fc6fcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000798fc6fcf640  ptest xmm10, xmm10
0000798fc6fcf646  jnz 0x0000798FC6FD0B8C
0000798fc6fcf64c  vmovaps [rsp+0x120], xmm7
0000798fc6fcf655  vmovaps xmm14, [rsp+0x120]
0000798fc6fcf65e  por xmm7, xmm14
0000798fc6fcf663  vmovaps xmm14, [rsp+0xC0]
0000798fc6fcf66c  vmovaps xmm10, [rsp+0xC0]
0000798fc6fcf675  por xmm14, xmm10
0000798fc6fcf67a  vmovaps xmm2, [rsp+0x100]
0000798fc6fcf683  vpermilpd xmm2, xmm2, 0x00
0000798fc6fcf689  vmovaps [rsp+0xC0], xmm1
0000798fc6fcf692  vmovaps [rsp+0x120], xmm15
0000798fc6fcf69b  movaps xmm1, xmm10
0000798fc6fcf69f  mulpd xmm1, xmm2
0000798fc6fcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000798fc6fcf6a8  ptest xmm15, xmm15
0000798fc6fcf6ae  jnz 0x0000798FC6FD0CCF
0000798fc6fcf6b4  xor eax, eax
0000798fc6fcf6b6  mov r12d, 0x40
0000798fc6fcf6bc  mov r11d, 0x200
0000798fc6fcf6c2  cmp r12, r11
0000798fc6fcf6c5  cmc
0000798fc6fcf6c6  lahf
0000798fc6fcf6c7  seto al
0000798fc6fcf6ca  mov [r15+0x108], eax
0000798fc6fcf6d1  vmovaps xmm10, [rsp+0x110]
0000798fc6fcf6da  vmovaps xmm2, [rsp+0xE0]
0000798fc6fcf6e3  vmovaps [rsp+0xE0], xmm1
0000798fc6fcf6ec  movaps xmm15, xmm10
0000798fc6fcf6f0  addpd xmm15, xmm2
0000798fc6fcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000798fc6fcf6fb  ptest xmm1, xmm1
0000798fc6fcf700  jnz 0x0000798FC6FD0E10
0000798fc6fcf706  vmovaps xmm10, [rsp+0x120]
0000798fc6fcf70f  vmovaps [rsp+0x110], xmm15
0000798fc6fcf718  movaps xmm1, xmm10
0000798fc6fcf71c  addpd xmm1, xmm12
0000798fc6fcf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000798fc6fcf726  ptest xmm15, xmm15
0000798fc6fcf72c  jnz 0x0000798FC6FD0F53
0000798fc6fcf732  vmovaps xmm10, [rsp+0xC0]
0000798fc6fcf73b  vmovaps [rsp+0xC0], xmm1
0000798fc6fcf744  movaps xmm15, xmm10
0000798fc6fcf748  addpd xmm15, xmm12
0000798fc6fcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000798fc6fcf753  ptest xmm1, xmm1
0000798fc6fcf758  jnz 0x0000798FC6FD1095
0000798fc6fcf75e  vmovaps xmm1, [rsp+0x30]
0000798fc6fcf764  vmovaps xmm12, [rsp+0x30]
0000798fc6fcf76a  por xmm1, xmm12
0000798fc6fcf76f  vmovaps xmm12, [rsp+0x20]
0000798fc6fcf775  vmovaps xmm10, [rsp+0x20]
0000798fc6fcf77b  por xmm12, xmm10
0000798fc6fcf780  vmovaps [rsp+0x20], xmm5
0000798fc6fcf786  vmovaps xmm10, [rsp+0x20]
0000798fc6fcf78c  por xmm5, xmm10
0000798fc6fcf791  vmovaps [rsp+0x20], xmm11
0000798fc6fcf797  vmovaps xmm10, [rsp+0x20]
0000798fc6fcf79d  por xmm11, xmm10
0000798fc6fcf7a2  vmovaps [rsp+0x20], xmm4
0000798fc6fcf7a8  vmovaps xmm10, [rsp+0x20]
0000798fc6fcf7ae  por xmm4, xmm10
0000798fc6fcf7b3  vmovaps [rsp+0x20], xmm8
0000798fc6fcf7b9  vmovaps xmm10, [rsp+0x20]
0000798fc6fcf7bf  por xmm8, xmm10
0000798fc6fcf7c4  vmovaps xmm10, [rsp+0xF0]
0000798fc6fcf7cd  vmovaps [rsp+0x20], xmm1
0000798fc6fcf7d3  vmovaps xmm1, [rsp+0xF0]
0000798fc6fcf7dc  por xmm10, xmm1
0000798fc6fcf7e1  lea rax, [r14+0xA0]
0000798fc6fcf7e8  movups xmm1, [r13+rax*1]
0000798fc6fcf7ee  lea rax, [r14+0xB0]
0000798fc6fcf7f5  vmovaps [rsp+0x30], xmm1
0000798fc6fcf7fb  movups xmm1, [r13+rax*1]
0000798fc6fcf801  vmovaps [rsp+0xF0], xmm1
0000798fc6fcf80a  vmovaps [rsp+0x120], xmm15
0000798fc6fcf813  movaps xmm1, xmm13
0000798fc6fcf817  addpd xmm1, xmm2
0000798fc6fcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000798fc6fcf820  ptest xmm15, xmm15
0000798fc6fcf826  jnz 0x0000798FC6FD11ED
0000798fc6fcf82c  lea rax, [r14+0xF0]
0000798fc6fcf833  movups xmm15, [r13+rax*1]
0000798fc6fcf839  vmovaps xmm2, [rsp+0xC0]
0000798fc6fcf842  vmovaps [rsp+0xC0], xmm1
0000798fc6fcf84b  vmovaps xmm1, [rsp+0xE0]
0000798fc6fcf854  vmovaps [rsp+0xE0], xmm15
0000798fc6fcf85d  movaps xmm13, xmm2
0000798fc6fcf861  addpd xmm13, xmm1
0000798fc6fcf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000798fc6fcf86c  ptest xmm15, xmm15
0000798fc6fcf872  jnz 0x0000798FC6FD1338
0000798fc6fcf878  vmovaps xmm15, [rsp+0x120]
0000798fc6fcf881  vmovaps xmm2, [rsp+0xD0]
0000798fc6fcf88a  vmovaps [rsp+0xD0], xmm14
0000798fc6fcf893  movaps xmm1, xmm15
0000798fc6fcf897  addpd xmm1, xmm2
0000798fc6fcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000798fc6fcf8a0  ptest xmm14, xmm14
0000798fc6fcf8a6  jnz 0x0000798FC6FD147A
0000798fc6fcf8ac  vmovaps xmm15, [rsp+0x100]
0000798fc6fcf8b5  vpermilpd xmm15, xmm15, 0x00
0000798fc6fcf8bb  vmovaps xmm2, [rsp+0xF0]
0000798fc6fcf8c4  vmovaps [rsp+0xF0], xmm1
0000798fc6fcf8cd  movaps xmm14, xmm2
0000798fc6fcf8d1  mulpd xmm14, xmm15
0000798fc6fcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000798fc6fcf8dc  ptest xmm1, xmm1
0000798fc6fcf8e1  jnz 0x0000798FC6FD15BB
0000798fc6fcf8e7  vmovaps xmm1, [rsp+0xA0]
0000798fc6fcf8f0  vpermilpd xmm1, xmm1, 0x00
0000798fc6fcf8f6  vmovaps xmm2, [rsp+0xE0]
0000798fc6fcf8ff  vmovaps [rsp+0xE0], xmm14
0000798fc6fcf908  movaps xmm15, xmm2
0000798fc6fcf90c  mulpd xmm15, xmm1
0000798fc6fcf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000798fc6fcf917  ptest xmm14, xmm14
0000798fc6fcf91d  jnz 0x0000798FC6FD16FE
0000798fc6fcf923  lea rax, [r14+0xE0]
0000798fc6fcf92a  movups xmm1, [r13+rax*1]
0000798fc6fcf930  vmovaps xmm14, [rsp+0x100]
0000798fc6fcf939  vpermilpd xmm14, xmm14, 0x00
0000798fc6fcf93f  vmovaps [rsp+0x100], xmm1
0000798fc6fcf948  vmovaps xmm1, [rsp+0x30]
0000798fc6fcf94e  vmovaps [rsp+0x30], xmm15
0000798fc6fcf954  movaps xmm2, xmm1
0000798fc6fcf957  mulpd xmm2, xmm14
0000798fc6fcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000798fc6fcf961  ptest xmm15, xmm15
0000798fc6fcf967  jnz 0x0000798FC6FD184A
0000798fc6fcf96d  vmovaps [rsp+0x120], xmm10
0000798fc6fcf976  vmovaps xmm1, [rsp+0x120]
0000798fc6fcf97f  por xmm10, xmm1
0000798fc6fcf984  movaps [r15+0x300], xmm10
0000798fc6fcf98c  vmovaps [rsp+0x120], xmm8
0000798fc6fcf995  vmovaps xmm1, [rsp+0x120]
0000798fc6fcf99e  por xmm8, xmm1
0000798fc6fcf9a3  movaps [r15+0x190], xmm8
0000798fc6fcf9ab  vmovaps xmm1, [rsp+0xA0]
0000798fc6fcf9b4  vpermilpd xmm1, xmm1, 0x00
0000798fc6fcf9ba  vmovaps xmm14, [rsp+0x100]
0000798fc6fcf9c3  vmovaps [rsp+0x100], xmm13
0000798fc6fcf9cc  movaps xmm15, xmm14
0000798fc6fcf9d0  mulpd xmm15, xmm1
0000798fc6fcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000798fc6fcf9db  ptest xmm13, xmm13
0000798fc6fcf9e1  jnz 0x0000798FC6FD198B
0000798fc6fcf9e7  lea rax, [r14+0x90]
0000798fc6fcf9ee  movups xmm1, [r13+rax*1]
0000798fc6fcf9f4  vmovaps [rsp+0x120], xmm4
0000798fc6fcf9fd  vmovaps xmm14, [rsp+0x120]
0000798fc6fcfa06  por xmm4, xmm14
0000798fc6fcfa0b  movaps [r15+0x1C0], xmm4
0000798fc6fcfa13  vmovaps [rsp+0x120], xmm11
0000798fc6fcfa1c  vmovaps xmm14, [rsp+0x120]
0000798fc6fcfa25  por xmm11, xmm14
0000798fc6fcfa2a  movaps [r15+0x200], xmm11
0000798fc6fcfa32  vmovaps [rsp+0x120], xmm5
0000798fc6fcfa3b  vmovaps xmm14, [rsp+0x120]
0000798fc6fcfa44  por xmm5, xmm14
0000798fc6fcfa49  movaps [r15+0x2D0], xmm5
0000798fc6fcfa51  vmovaps [rsp+0x120], xmm12
0000798fc6fcfa5a  vmovaps xmm14, [rsp+0x120]
0000798fc6fcfa63  por xmm12, xmm14
0000798fc6fcfa68  movaps [r15+0x2E0], xmm12
0000798fc6fcfa70  vmovaps xmm13, [rsp+0x110]
0000798fc6fcfa79  vmovaps [rsp+0x110], xmm1
0000798fc6fcfa82  vmovaps xmm1, [rsp+0xE0]
0000798fc6fcfa8b  vmovaps [rsp+0xE0], xmm15
0000798fc6fcfa94  movaps xmm14, xmm13
0000798fc6fcfa98  addpd xmm14, xmm1
0000798fc6fcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000798fc6fcfaa3  ptest xmm15, xmm15
0000798fc6fcfaa9  jnz 0x0000798FC6FD1AD8
0000798fc6fcfaaf  vmovaps xmm1, [rsp+0xA0]
0000798fc6fcfab8  vpermilpd xmm1, xmm1, 0x00
0000798fc6fcfabe  vmovaps xmm13, [rsp+0x110]
0000798fc6fcfac7  vmovaps [rsp+0x110], xmm14
0000798fc6fcfad0  movaps xmm15, xmm13
0000798fc6fcfad4  mulpd xmm15, xmm1
0000798fc6fcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000798fc6fcfadf  ptest xmm14, xmm14
0000798fc6fcfae5  jnz 0x0000798FC6FD1C1B
0000798fc6fcfaeb  lea rax, [r14+0x80]
0000798fc6fcfaf2  movups xmm1, [r13+rax*1]
0000798fc6fcfaf8  vmovaps xmm13, [rsp+0xC0]
0000798fc6fcfb01  vmovaps [rsp+0xC0], xmm1
0000798fc6fcfb0a  movaps xmm14, xmm13
0000798fc6fcfb0e  addpd xmm14, xmm2
0000798fc6fcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000798fc6fcfb19  ptest xmm1, xmm1
0000798fc6fcfb1e  jnz 0x0000798FC6FD1D68
0000798fc6fcfb24  vmovaps xmm13, [rsp+0x100]
0000798fc6fcfb2d  vmovaps xmm2, [rsp+0x30]
0000798fc6fcfb33  vmovaps [rsp+0x30], xmm15
0000798fc6fcfb39  movaps xmm1, xmm13
0000798fc6fcfb3d  addpd xmm1, xmm2
0000798fc6fcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000798fc6fcfb46  ptest xmm15, xmm15
0000798fc6fcfb4c  jnz 0x0000798FC6FD1EAB
0000798fc6fcfb52  vmovaps xmm15, [rsp+0x20]
0000798fc6fcfb58  vmovaps xmm13, [rsp+0x20]
0000798fc6fcfb5e  por xmm15, xmm13
0000798fc6fcfb63  movaps [r15+0x2F0], xmm15
0000798fc6fcfb6b  vmovaps xmm13, [rsp+0xA0]
0000798fc6fcfb74  vpermilpd xmm13, xmm13, 0x00
0000798fc6fcfb7a  vmovaps [rsp+0x20], xmm1
0000798fc6fcfb80  vmovaps xmm1, [rsp+0xC0]
0000798fc6fcfb89  vmovaps [rsp+0xA0], xmm15
0000798fc6fcfb92  movaps xmm2, xmm1
0000798fc6fcfb95  mulpd xmm2, xmm13
0000798fc6fcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000798fc6fcfb9f  ptest xmm15, xmm15
0000798fc6fcfba5  jnz 0x0000798FC6FD1FEC
0000798fc6fcfbab  lea rax, [r14+0xD0]
0000798fc6fcfbb2  movups xmm1, [r13+rax*1]
0000798fc6fcfbb8  vmovaps xmm13, [rsp+0xF0]
0000798fc6fcfbc1  vmovaps [rsp+0xC0], xmm1
0000798fc6fcfbca  vmovaps xmm1, [rsp+0xE0]
0000798fc6fcfbd3  vmovaps [rsp+0xE0], xmm14
0000798fc6fcfbdc  movaps xmm15, xmm13
0000798fc6fcfbe0  addpd xmm15, xmm1
0000798fc6fcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000798fc6fcfbeb  ptest xmm14, xmm14
0000798fc6fcfbf1  jnz 0x0000798FC6FD2137
0000798fc6fcfbf7  vmovaps xmm1, [rsp+0xB0]
0000798fc6fcfc00  vpermilpd xmm1, xmm1, 0x00
0000798fc6fcfc06  movaps xmm14, xmm11
0000798fc6fcfc0a  mulpd xmm14, xmm1
0000798fc6fcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000798fc6fcfc15  ptest xmm13, xmm13
0000798fc6fcfc1b  jnz 0x0000798FC6FD227A
0000798fc6fcfc21  movaps [r15+0x260], xmm14
0000798fc6fcfc29  vxorps xmm1, xmm1, xmm1
0000798fc6fcfc2d  vpbroadcastq xmm1, xmm1
0000798fc6fcfc32  movaps [r15+0x1B0], xmm1
0000798fc6fcfc3a  vmovaps xmm1, [rsp+0xB0]
0000798fc6fcfc43  vpermilpd xmm1, xmm1, 0x00
0000798fc6fcfc49  vmovaps xmm11, [rsp+0xC0]
0000798fc6fcfc52  vmovaps [rsp+0xC0], xmm15
0000798fc6fcfc5b  movaps xmm13, xmm11
0000798fc6fcfc5f  mulpd xmm13, xmm1
0000798fc6fcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000798fc6fcfc6a  ptest xmm15, xmm15
0000798fc6fcfc70  jnz 0x0000798FC6FD23BD
0000798fc6fcfc76  lea rax, [r14+0xC0]
0000798fc6fcfc7d  movups xmm1, [r13+rax*1]
0000798fc6fcfc83  vmovaps xmm11, [rsp+0x110]
0000798fc6fcfc8c  vmovaps [rsp+0xF0], xmm1
0000798fc6fcfc95  vmovaps xmm1, [rsp+0x30]
0000798fc6fcfc9b  vmovaps [rsp+0x30], xmm14
0000798fc6fcfca1  movaps xmm15, xmm11
0000798fc6fcfca5  addpd xmm15, xmm1
0000798fc6fcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000798fc6fcfcb0  ptest xmm14, xmm14
0000798fc6fcfcb6  jnz 0x0000798FC6FD250A
0000798fc6fcfcbc  vmovaps [rsp+0x100], xmm9
0000798fc6fcfcc5  vmovaps xmm1, [rsp+0x100]
0000798fc6fcfcce  por xmm9, xmm1
0000798fc6fcfcd3  movaps [r15+0x270], xmm9
0000798fc6fcfcdb  vmovaps [rsp+0x100], xmm6
0000798fc6fcfce4  vmovaps xmm1, [rsp+0x100]
0000798fc6fcfced  por xmm6, xmm1
0000798fc6fcfcf1  movaps [r15+0x1A0], xmm6
0000798fc6fcfcf9  vmovaps xmm14, [rsp+0xB0]
0000798fc6fcfd02  vpermilpd xmm14, xmm14, 0x00
0000798fc6fcfd08  vmovaps xmm6, [rsp+0xF0]
0000798fc6fcfd11  vmovaps [rsp+0xF0], xmm1
0000798fc6fcfd1a  movaps xmm11, xmm6
0000798fc6fcfd1e  mulpd xmm11, xmm14
0000798fc6fcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000798fc6fcfd29  ptest xmm1, xmm1
0000798fc6fcfd2e  jnz 0x0000798FC6FD264D
0000798fc6fcfd34  lea rax, [r14+0x20]
0000798fc6fcfd38  movups xmm1, [r13+rax*1]
0000798fc6fcfd3e  movaps [r15+0x110], xmm1
0000798fc6fcfd46  vmovaps xmm6, [rsp+0xE0]
0000798fc6fcfd4f  vmovaps [rsp+0xE0], xmm1
0000798fc6fcfd58  movaps xmm14, xmm6
0000798fc6fcfd5c  addpd xmm14, xmm2
0000798fc6fcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000798fc6fcfd67  ptest xmm1, xmm1
0000798fc6fcfd6c  jnz 0x0000798FC6FD279A
0000798fc6fcfd72  vmovaps xmm1, [rsp+0xB0]
0000798fc6fcfd7b  vpermilpd xmm1, xmm1, 0x00
0000798fc6fcfd81  movaps xmm6, xmm5
0000798fc6fcfd84  mulpd xmm6, xmm1
0000798fc6fcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000798fc6fcfd8d  ptest xmm2, xmm2
0000798fc6fcfd92  jnz 0x0000798FC6FD28DC
0000798fc6fcfd98  vmovaps xmm5, [rsp+0x20]
0000798fc6fcfd9e  movaps xmm1, xmm5
0000798fc6fcfda1  addpd xmm1, xmm13
0000798fc6fcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000798fc6fcfdab  ptest xmm2, xmm2
0000798fc6fcfdb0  jnz 0x0000798FC6FD2A1C
0000798fc6fcfdb6  vmovaps xmm13, [rsp+0x80]
0000798fc6fcfdbf  vpermilpd xmm13, xmm13, 0x00
0000798fc6fcfdc5  vmovaps xmm2, [rsp+0xE0]
0000798fc6fcfdce  vmovaps [rsp+0x20], xmm1
0000798fc6fcfdd4  movaps xmm5, xmm2
0000798fc6fcfdd7  mulpd xmm5, xmm13
0000798fc6fcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000798fc6fcfde1  ptest xmm1, xmm1
0000798fc6fcfde6  jnz 0x0000798FC6FD2B5D
0000798fc6fcfdec  vmovaps xmm1, [rsp+0x80]
0000798fc6fcfdf5  vpermilpd xmm1, xmm1, 0x00
0000798fc6fcfdfb  movaps xmm13, xmm10
0000798fc6fcfdff  mulpd xmm13, xmm1
0000798fc6fcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000798fc6fcfe0a  ptest xmm2, xmm2
0000798fc6fcfe0f  jnz 0x0000798FC6FD2C9E
0000798fc6fcfe15  vmovaps xmm10, [rsp+0x30]
0000798fc6fcfe1b  movaps xmm1, xmm15
0000798fc6fcfe1f  addpd xmm1, xmm10
0000798fc6fcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000798fc6fcfe29  ptest xmm2, xmm2
0000798fc6fcfe2e  jnz 0x0000798FC6FD2DE1
0000798fc6fcfe34  vmovaps xmm10, [rsp+0xC0]
0000798fc6fcfe3d  movaps xmm15, xmm10
0000798fc6fcfe41  addpd xmm15, xmm11
0000798fc6fcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000798fc6fcfe4c  ptest xmm2, xmm2
0000798fc6fcfe51  jnz 0x0000798FC6FD2F23
0000798fc6fcfe57  vmovaps xmm11, [rsp+0x80]
0000798fc6fcfe60  vpermilpd xmm11, xmm11, 0x00
0000798fc6fcfe66  movaps xmm10, xmm12
0000798fc6fcfe6a  mulpd xmm10, xmm11
0000798fc6fcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000798fc6fcfe75  ptest xmm2, xmm2
0000798fc6fcfe7a  jnz 0x0000798FC6FD3067
0000798fc6fcfe80  vmovaps xmm12, [rsp+0x80]
0000798fc6fcfe89  vpermilpd xmm12, xmm12, 0x00
0000798fc6fcfe8f  vmovaps xmm2, [rsp+0xA0]
0000798fc6fcfe98  vmovaps [rsp+0x30], xmm1
0000798fc6fcfe9e  movaps xmm11, xmm2
0000798fc6fcfea2  mulpd xmm11, xmm12
0000798fc6fcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000798fc6fcfead  ptest xmm1, xmm1
0000798fc6fcfeb2  jnz 0x0000798FC6FD31AB
0000798fc6fcfeb8  movaps xmm1, xmm14
0000798fc6fcfebc  addpd xmm1, xmm6
0000798fc6fcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000798fc6fcfec5  ptest xmm12, xmm12
0000798fc6fcfecb  jnz 0x0000798FC6FD32EE
0000798fc6fcfed1  vmovaps xmm12, [rsp+0x20]
0000798fc6fcfed7  movaps xmm14, xmm12
0000798fc6fcfedb  addpd xmm14, xmm5
0000798fc6fcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000798fc6fcfee6  ptest xmm6, xmm6
0000798fc6fcfeeb  jnz 0x0000798FC6FD342F
0000798fc6fcfef1  vmovaps xmm12, [rsp+0x90]
0000798fc6fcfefa  vpermilpd xmm12, xmm12, 0x00
0000798fc6fcff00  movaps xmm6, xmm9
0000798fc6fcff04  mulpd xmm6, xmm12
0000798fc6fcff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000798fc6fcff0e  ptest xmm5, xmm5
0000798fc6fcff13  jnz 0x0000798FC6FD3572
0000798fc6fcff19  movaps xmm12, xmm15
0000798fc6fcff1d  addpd xmm12, xmm13
0000798fc6fcff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000798fc6fcff28  ptest xmm9, xmm9
0000798fc6fcff2e  jnz 0x0000798FC6FD36B4
0000798fc6fcff34  vmovaps xmm13, [rsp+0x30]
0000798fc6fcff3a  movaps xmm15, xmm13
0000798fc6fcff3e  addpd xmm15, xmm10
0000798fc6fcff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000798fc6fcff49  ptest xmm9, xmm9
0000798fc6fcff4f  jnz 0x0000798FC6FD37F8
0000798fc6fcff55  vmovaps xmm13, [rsp+0xD0]
0000798fc6fcff5e  vmovaps xmm10, [rsp+0xD0]
0000798fc6fcff67  por xmm13, xmm10
0000798fc6fcff6c  movaps [r15+0x250], xmm13
0000798fc6fcff74  vmovaps [rsp+0x20], xmm7
0000798fc6fcff7a  vmovaps xmm13, [rsp+0x20]
0000798fc6fcff80  por xmm7, xmm13
0000798fc6fcff85  movaps [r15+0x2A0], xmm7
0000798fc6fcff8d  vmovaps [rsp+0x20], xmm3
0000798fc6fcff93  vmovaps xmm13, [rsp+0x20]
0000798fc6fcff99  por xmm3, xmm13
0000798fc6fcff9e  movaps [r15+0x1D0], xmm3
0000798fc6fcffa6  lea rax, [r14+0x40]
0000798fc6fcffaa  movups xmm13, [r13+rax*1]
0000798fc6fcffb0  movaps [r15+0x2C0], xmm13
0000798fc6fcffb8  vmovaps xmm10, [rsp+0x90]
0000798fc6fcffc1  vpermilpd xmm10, xmm10, 0x00
0000798fc6fcffc7  movaps xmm9, xmm8
0000798fc6fcffcb  mulpd xmm9, xmm10
0000798fc6fcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000798fc6fcffd6  ptest xmm5, xmm5
0000798fc6fcffdb  jnz 0x0000798FC6FD3946
0000798fc6fcffe1  movaps xmm10, xmm1
0000798fc6fcffe5  addpd xmm10, xmm11
0000798fc6fcffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000798fc6fcfff0  ptest xmm8, xmm8
0000798fc6fcfff6  jnz 0x0000798FC6FD3A8A
0000798fc6fcfffc  movaps xmm1, xmm14
0000798fc6fd0000  addpd xmm1, xmm6
0000798fc6fd0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000798fc6fd0009  ptest xmm11, xmm11
0000798fc6fd000f  jnz 0x0000798FC6FD3BCD
0000798fc6fd0015  vmovaps xmm14, [rsp+0x90]
0000798fc6fd001e  vpermilpd xmm14, xmm14, 0x00
0000798fc6fd0024  movaps xmm11, xmm13
0000798fc6fd0028  mulpd xmm11, xmm14
0000798fc6fd002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000798fc6fd0033  ptest xmm8, xmm8
0000798fc6fd0039  jnz 0x0000798FC6FD3D0E
0000798fc6fd003f  vmovaps xmm14, [rsp+0x90]
0000798fc6fd0048  vpermilpd xmm14, xmm14, 0x00
0000798fc6fd004e  vmovaps xmm8, [rsp+0x10]
0000798fc6fd0054  movaps xmm13, xmm8
0000798fc6fd0058  mulpd xmm13, xmm14
0000798fc6fd005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000798fc6fd0063  ptest xmm6, xmm6
0000798fc6fd0068  jnz 0x0000798FC6FD3E52
0000798fc6fd006e  vmovaps xmm14, [rsp+0x60]
0000798fc6fd0074  vpermilpd xmm14, xmm14, 0x00
0000798fc6fd007a  movaps xmm8, xmm7
0000798fc6fd007e  mulpd xmm8, xmm14
0000798fc6fd0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000798fc6fd0089  ptest xmm6, xmm6
0000798fc6fd008e  jnz 0x0000798FC6FD3F96
0000798fc6fd0094  movaps xmm14, xmm12
0000798fc6fd0098  addpd xmm14, xmm9
0000798fc6fd009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000798fc6fd00a3  ptest xmm7, xmm7
0000798fc6fd00a8  jnz 0x0000798FC6FD40D9
0000798fc6fd00ae  vmovaps xmm12, [rsp+0x60]
0000798fc6fd00b4  vpermilpd xmm12, xmm12, 0x00
0000798fc6fd00ba  vmovaps xmm7, [rsp+0xF0]
0000798fc6fd00c3  movaps xmm9, xmm7
0000798fc6fd00c7  mulpd xmm9, xmm12
0000798fc6fd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000798fc6fd00d2  ptest xmm6, xmm6
0000798fc6fd00d7  jnz 0x0000798FC6FD421D
0000798fc6fd00dd  movaps xmm12, xmm15
0000798fc6fd00e1  addpd xmm12, xmm11
0000798fc6fd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000798fc6fd00ec  ptest xmm7, xmm7
0000798fc6fd00f1  jnz 0x0000798FC6FD4360
0000798fc6fd00f7  vmovaps xmm15, [rsp+0x60]
0000798fc6fd00fd  vpermilpd xmm15, xmm15, 0x00
0000798fc6fd0103  vmovaps xmm7, [rsp+0x40]
0000798fc6fd0109  movaps xmm11, xmm7
0000798fc6fd010d  mulpd xmm11, xmm15
0000798fc6fd0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000798fc6fd0118  ptest xmm6, xmm6
0000798fc6fd011d  jnz 0x0000798FC6FD44A4
0000798fc6fd0123  movaps xmm15, xmm10
0000798fc6fd0127  addpd xmm15, xmm13
0000798fc6fd012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000798fc6fd0132  ptest xmm7, xmm7
0000798fc6fd0137  jnz 0x0000798FC6FD45E7
0000798fc6fd013d  vmovaps xmm13, [rsp+0x60]
0000798fc6fd0143  vpermilpd xmm13, xmm13, 0x00
0000798fc6fd0149  vmovaps xmm7, [rsp+0x50]
0000798fc6fd014f  movaps xmm10, xmm7
0000798fc6fd0153  mulpd xmm10, xmm13
0000798fc6fd0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000798fc6fd015e  ptest xmm6, xmm6
0000798fc6fd0163  jnz 0x0000798FC6FD472B
0000798fc6fd0169  movaps xmm13, xmm1
0000798fc6fd016d  addpd xmm13, xmm8
0000798fc6fd0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000798fc6fd0178  ptest xmm7, xmm7
0000798fc6fd017d  jnz 0x0000798FC6FD486E
0000798fc6fd0183  lea rax, [r14+0x70]
0000798fc6fd0187  movups xmm1, [r13+rax*1]
0000798fc6fd018d  movaps [r15+0x240], xmm1
0000798fc6fd0195  movaps xmm8, xmm14
0000798fc6fd0199  addpd xmm8, xmm9
0000798fc6fd019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000798fc6fd01a4  ptest xmm7, xmm7
0000798fc6fd01a9  jnz 0x0000798FC6FD49BB
0000798fc6fd01af  movaps [r15+0x170], xmm8
0000798fc6fd01b7  vmovaps xmm14, [rsp+0x70]
0000798fc6fd01bd  vpermilpd xmm14, xmm14, 0x00
0000798fc6fd01c3  movaps xmm9, xmm1
0000798fc6fd01c7  mulpd xmm9, xmm14
0000798fc6fd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000798fc6fd01d2  ptest xmm7, xmm7
0000798fc6fd01d7  jnz 0x0000798FC6FD4AFF
0000798fc6fd01dd  vmovaps xmm1, [rsp+0x70]
0000798fc6fd01e3  vpermilpd xmm1, xmm1, 0x00
0000798fc6fd01e9  movaps xmm14, xmm4
0000798fc6fd01ed  mulpd xmm14, xmm1
0000798fc6fd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000798fc6fd01f8  ptest xmm7, xmm7
0000798fc6fd01fd  jnz 0x0000798FC6FD4C42
0000798fc6fd0203  movaps [r15+0x180], xmm14
0000798fc6fd020b  movaps xmm1, xmm12
0000798fc6fd020f  addpd xmm1, xmm11
0000798fc6fd0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000798fc6fd0219  ptest xmm7, xmm7
0000798fc6fd021e  jnz 0x0000798FC6FD4D84
0000798fc6fd0224  movaps [r15+0x210], xmm1
0000798fc6fd022c  movups xmm12, [r13+r14*1]
0000798fc6fd0232  lea rax, [r14+0x10]
0000798fc6fd0236  movups xmm11, [r13+rax*1]
0000798fc6fd023c  movaps [r15+0x230], xmm11
0000798fc6fd0244  movaps xmm7, xmm15
0000798fc6fd0248  addpd xmm7, xmm10
0000798fc6fd024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000798fc6fd0252  ptest xmm6, xmm6
0000798fc6fd0257  jnz 0x0000798FC6FD4EDA
0000798fc6fd025d  movaps [r15+0x130], xmm7
0000798fc6fd0265  vmovaps xmm15, [rsp+0x70]
0000798fc6fd026b  vpermilpd xmm15, xmm15, 0x00
0000798fc6fd0271  movaps xmm10, xmm11
0000798fc6fd0275  mulpd xmm10, xmm15
0000798fc6fd027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000798fc6fd0280  ptest xmm6, xmm6
0000798fc6fd0285  jnz 0x0000798FC6FD501C
0000798fc6fd028b  movaps [r15+0x220], xmm10
0000798fc6fd0293  vmovaps xmm15, [rsp+0x70]
0000798fc6fd0299  vpermilpd xmm15, xmm15, 0x00
0000798fc6fd029f  movaps xmm11, xmm12
0000798fc6fd02a3  mulpd xmm11, xmm15
0000798fc6fd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000798fc6fd02ae  ptest xmm6, xmm6
0000798fc6fd02b3  jnz 0x0000798FC6FD5160
0000798fc6fd02b9  movaps xmm15, xmm13
0000798fc6fd02bd  addpd xmm15, xmm9
0000798fc6fd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000798fc6fd02c8  ptest xmm12, xmm12
0000798fc6fd02ce  jnz 0x0000798FC6FD52A4
0000798fc6fd02d4  movaps [r15+0x140], xmm15
0000798fc6fd02dc  movaps xmm13, xmm8
0000798fc6fd02e0  addpd xmm13, xmm14
0000798fc6fd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000798fc6fd02eb  ptest xmm12, xmm12
0000798fc6fd02f1  jnz 0x0000798FC6FD53E8
0000798fc6fd02f7  movaps [r15+0x150], xmm13
0000798fc6fd02ff  movaps xmm14, xmm1
0000798fc6fd0303  addpd xmm14, xmm10
0000798fc6fd0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000798fc6fd030e  ptest xmm12, xmm12
0000798fc6fd0314  jnz 0x0000798FC6FD552C
0000798fc6fd031a  movaps [r15+0x160], xmm14
0000798fc6fd0322  movaps xmm1, xmm7
0000798fc6fd0325  addpd xmm1, xmm11
0000798fc6fd032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000798fc6fd032f  ptest xmm12, xmm12
0000798fc6fd0335  jnz 0x0000798FC6FD566F
0000798fc6fd033b  movaps [r15+0x120], xmm1
0000798fc6fd0343  mov eax, 0x430920
0000798fc6fd0348  movups [r13+rax*1], xmm15
0000798fc6fd034e  mov eax, 0x430930
0000798fc6fd0353  movups [r13+rax*1], xmm13
0000798fc6fd0359  mov eax, 0x430940
0000798fc6fd035e  movups [r13+rax*1], xmm14
0000798fc6fd0364  mov eax, 0x430950
0000798fc6fd0369  movups [r13+rax*1], xmm1
0000798fc6fd036f  mov eax, [r15+0x108]
0000798fc6fd0376  sahf
0000798fc6fd0377  jnz 0x0000798FC6FD03A9
0000798fc6fd0379  cmp dword ptr [r15+0x318], 0x00
0000798fc6fd0381  jz 0x0000798FC6FDB900
0000798fc6fd0387  nop [rax+rax*1], ax
0000798fc6fd0390  nop [rax+rax*1], eax
0000798fc6fd0398  mov eax, 0x410444
0000798fc6fd039d  mov [r15+0x100], rax
0000798fc6fd03a4  jmp 0x0000798FC6DFE110
0000798fc6fd03a9  cmp dword ptr [r15+0x318], 0x00
0000798fc6fd03b1  jz 0x0000798FC6FD57E0
0000798fc6fd03b7  nop [rax+rax*1], ax
0000798fc6fd03c0  nop [rax+rax*1], eax
0000798fc6fd03c8  mov eax, 0x410278
0000798fc6fd03cd  mov [r15+0x100], rax
0000798fc6fd03d4  jmp 0x0000798FC6DFE110
0000798fc6fd03d9  int3
0000798fc6fd03da  call 0x0000798FC6EB52F0
0000798fc6fd03df  jmp 0x0000798FC6FCF016
0000798fc6fd03e4  call 0x0000798FC6EC4620
0000798fc6fd03e9  jmp 0x0000798FC6FCF023
0000798fc6fd03ee  call 0x0000798FC6EC33A0
0000798fc6fd03f3  jmp 0x0000798FC6FCF035
0000798fc6fd03f8  call 0x0000798FC6EC2120
0000798fc6fd03fd  jmp 0x0000798FC6FCF03F
0000798fc6fd0402  call 0x0000798FC6EC0860
0000798fc6fd0407  jmp 0x0000798FC6FCF067
0000798fc6fd040c  call 0x0000798FC6EBF5F0
0000798fc6fd0411  jmp 0x0000798FC6FCF073
0000798fc6fd0416  call 0x0000798FC6EC0860
0000798fc6fd041b  jmp 0x0000798FC6FCF0A5
0000798fc6fd0420  call 0x0000798FC6EBF5F0
0000798fc6fd0425  jmp 0x0000798FC6FCF0B1
0000798fc6fd042a  call 0x0000798FC6EC4740
0000798fc6fd042f  jmp 0x0000798FC6FCF0BE
0000798fc6fd0434  call 0x0000798FC6EB5400
0000798fc6fd0439  jmp 0x0000798FC6FCF0CB
0000798fc6fd043e  call 0x0000798FC6EB52F0
0000798fc6fd0443  jmp 0x0000798FC6FCF0D8
0000798fc6fd0448  call 0x0000798FC6EC4620
0000798fc6fd044d  jmp 0x0000798FC6FCF0E5
0000798fc6fd0452  call 0x0000798FC6EC0860
0000798fc6fd0457  jmp 0x0000798FC6FCF10D
0000798fc6fd045c  call 0x0000798FC6EBF5F0
0000798fc6fd0461  jmp 0x0000798FC6FCF119
0000798fc6fd0466  call 0x0000798FC6E09D70
0000798fc6fd046b  jmp 0x0000798FC6FCF11F
0000798fc6fd0470  call 0x0000798FC6EBE9C0
0000798fc6fd0475  jmp 0x0000798FC6FCF129
0000798fc6fd047a  call 0x0000798FC6EC0860
0000798fc6fd047f  jmp 0x0000798FC6FCF151
0000798fc6fd0484  call 0x0000798FC6EBF5F0
0000798fc6fd0489  jmp 0x0000798FC6FCF15D
0000798fc6fd048e  call 0x0000798FC6EBD750
0000798fc6fd0493  jmp 0x0000798FC6FCF16A
0000798fc6fd0498  call 0x0000798FC6EBC4E0
0000798fc6fd049d  jmp 0x0000798FC6FCF177
0000798fc6fd04a2  call 0x0000798FC6EC4740
0000798fc6fd04a7  jmp 0x0000798FC6FCF184
0000798fc6fd04ac  call 0x0000798FC6EB5400
0000798fc6fd04b1  jmp 0x0000798FC6FCF191
0000798fc6fd04b6  call 0x0000798FC6EB52F0
0000798fc6fd04bb  jmp 0x0000798FC6FCF19E
0000798fc6fd04c0  call 0x0000798FC6EC4620
0000798fc6fd04c5  jmp 0x0000798FC6FCF1AB
0000798fc6fd04ca  call 0x0000798FC6EC0860
0000798fc6fd04cf  jmp 0x0000798FC6FCF1BE
0000798fc6fd04d4  call 0x0000798FC6EBB270
0000798fc6fd04d9  jmp 0x0000798FC6FCF1CB
0000798fc6fd04de  call 0x0000798FC6EBA000
0000798fc6fd04e3  jmp 0x0000798FC6FCF1D8
0000798fc6fd04e8  call 0x0000798FC6EB8D90
0000798fc6fd04ed  jmp 0x0000798FC6FCF1E5
0000798fc6fd04f2  call 0x0000798FC6EB8A20
0000798fc6fd04f7  jmp 0x0000798FC6FCF1F2
0000798fc6fd04fc  call 0x0000798FC6EB5400
0000798fc6fd0501  jmp 0x0000798FC6FCF1FC
0000798fc6fd0506  call 0x0000798FC6EC2240
0000798fc6fd050b  jmp 0x0000798FC6FCF206
0000798fc6fd0510  call 0x0000798FC6EB52F0
0000798fc6fd0515  jmp 0x0000798FC6FCF210
0000798fc6fd051a  call 0x0000798FC6EC2120
0000798fc6fd051f  jmp 0x0000798FC6FCF21A
0000798fc6fd0524  call 0x0000798FC6EB77B0
0000798fc6fd0529  jmp 0x0000798FC6FCF224
0000798fc6fd052e  call 0x0000798FC6EB6550
0000798fc6fd0533  jmp 0x0000798FC6FCF22E
0000798fc6fd0538  call 0x0000798FC6EBFD50
0000798fc6fd053d  jmp 0x0000798FC6FCF240
0000798fc6fd0542  call 0x0000798FC6EB8EA0
0000798fc6fd0547  jmp 0x0000798FC6FCF24A
0000798fc6fd054c  call 0x0000798FC6EBFC30
0000798fc6fd0551  jmp 0x0000798FC6FCF257
0000798fc6fd0556  call 0x0000798FC6EB8D90
0000798fc6fd055b  jmp 0x0000798FC6FCF264
0000798fc6fd0560  call 0x0000798FC6EC2240
0000798fc6fd0565  jmp 0x0000798FC6FCF271
0000798fc6fd056a  call 0x0000798FC6EB5400
0000798fc6fd056f  jmp 0x0000798FC6FCF27E
0000798fc6fd0574  call 0x0000798FC6EB52F0
0000798fc6fd0579  jmp 0x0000798FC6FCF28B
0000798fc6fd057e  call 0x0000798FC6EC2120
0000798fc6fd0583  jmp 0x0000798FC6FCF298
0000798fc6fd0588  call 0x0000798FC6EB52F0
0000798fc6fd058d  jmp 0x0000798FC6FCF2AB
0000798fc6fd0592  call 0x0000798FC6EB52F0
0000798fc6fd0597  jmp 0x0000798FC6FCF2BE
0000798fc6fd059c  call 0x0000798FC6EB52F0
0000798fc6fd05a1  jmp 0x0000798FC6FCF2D1
0000798fc6fd05a6  call 0x0000798FC6EB52F0
0000798fc6fd05ab  jmp 0x0000798FC6FCF2E4
0000798fc6fd05b0  call 0x0000798FC6EC2240
0000798fc6fd05b5  jmp 0x0000798FC6FCF2F9
0000798fc6fd05ba  call 0x0000798FC6EC2240
0000798fc6fd05bf  jmp 0x0000798FC6FCF30C
0000798fc6fd05c4  call 0x0000798FC6EC2120
0000798fc6fd05c9  jmp 0x0000798FC6FCF319
0000798fc6fd05ce  call 0x0000798FC6EB52F0
0000798fc6fd05d3  jmp 0x0000798FC6FCF32C
0000798fc6fd05d8  call 0x0000798FC6EB52F0
0000798fc6fd05dd  jmp 0x0000798FC6FCF34F
0000798fc6fd05e2  call 0x0000798FC6EB52F0
0000798fc6fd05e7  jmp 0x0000798FC6FCF362
0000798fc6fd05ec  call 0x0000798FC6DFF540
0000798fc6fd05f1  jmp 0x0000798FC6FCF380
0000798fc6fd05f6  call 0x0000798FC6E08C20
0000798fc6fd05fb  jmp 0x0000798FC6FCF38A
0000798fc6fd0600  call 0x0000798FC6ED6600
0000798fc6fd0605  jmp 0x0000798FC6FCF396
0000798fc6fd060a  call 0x0000798FC6DFF540
0000798fc6fd060f  jmp 0x0000798FC6FCF3A6
0000798fc6fd0614  call 0x0000798FC6EC0370
0000798fc6fd0619  jmp 0x0000798FC6FCF3D4
0000798fc6fd061e  call 0x0000798FC6EBF100
0000798fc6fd0623  jmp 0x0000798FC6FCF3DD
0000798fc6fd0628  call 0x0000798FC6EC0370
0000798fc6fd062d  jmp 0x0000798FC6FCF43B
0000798fc6fd0632  call 0x0000798FC6EBF100
0000798fc6fd0637  jmp 0x0000798FC6FCF444
0000798fc6fd063c  call 0x0000798FC6EC0370
0000798fc6fd0641  jmp 0x0000798FC6FCF48B
0000798fc6fd0646  call 0x0000798FC6EBF100
0000798fc6fd064b  jmp 0x0000798FC6FCF494
0000798fc6fd0650  call 0x0000798FC6E0B720
0000798fc6fd0655  jmp 0x0000798FC6FCF4D7
0000798fc6fd065a  call 0x0000798FC6EB47C0
0000798fc6fd065f  jmp 0x0000798FC6FCF4EA
0000798fc6fd0664  call 0x0000798FC6E08B00
0000798fc6fd0669  jmp 0x0000798FC6FCF501
0000798fc6fd066e  call 0x0000798FC6DFF430
0000798fc6fd0673  jmp 0x0000798FC6FCF514
0000798fc6fd0678  call 0x0000798FC6DFF430
0000798fc6fd067d  jmp 0x0000798FC6FCF527
0000798fc6fd0682  sub rsp, 0x08
0000798fc6fd0686  push rax
0000798fc6fd0687  push rcx
0000798fc6fd0688  push rdx
0000798fc6fd0689  push rdi
0000798fc6fd068a  push rsi
0000798fc6fd068b  push r8
0000798fc6fd068d  push r9
0000798fc6fd068f  push r10
0000798fc6fd0691  push r11
0000798fc6fd0693  sub rsp, 0xF0
0000798fc6fd069a  vmovaps [rsp], xmm0
0000798fc6fd069f  vmovaps [rsp+0x10], xmm2
0000798fc6fd06a5  vmovaps [rsp+0x20], xmm3
0000798fc6fd06ab  vmovaps [rsp+0x30], xmm4
0000798fc6fd06b1  vmovaps [rsp+0x40], xmm5
0000798fc6fd06b7  vmovaps [rsp+0x50], xmm6
0000798fc6fd06bd  vmovaps [rsp+0x60], xmm7
0000798fc6fd06c3  vmovaps [rsp+0x70], xmm8
0000798fc6fd06c9  vmovaps [rsp+0x80], xmm9
0000798fc6fd06d2  vmovaps [rsp+0x90], xmm10
0000798fc6fd06db  vmovaps [rsp+0xA0], xmm11
0000798fc6fd06e4  vmovaps [rsp+0xB0], xmm12
0000798fc6fd06ed  vmovaps [rsp+0xC0], xmm13
0000798fc6fd06f6  vmovaps [rsp+0xD0], xmm14
0000798fc6fd06ff  vmovaps [rsp+0xE0], xmm15
0000798fc6fd0708  sub rsp, 0x30
0000798fc6fd070c  movaps [rsp], xmm1
0000798fc6fd0710  movaps [rsp+0x10], xmm15
0000798fc6fd0716  movaps [rsp+0x20], xmm14
0000798fc6fd071c  lea rdi, [rsp]
0000798fc6fd0720  mov esi, 0x00
0000798fc6fd0725  mov rax, 0x63E558B23530
0000798fc6fd072f  call rax
0000798fc6fd0731  movaps xmm1, [rsp]
0000798fc6fd0735  add rsp, 0x30
0000798fc6fd0739  vmovaps xmm0, [rsp]
0000798fc6fd073e  vmovaps xmm2, [rsp+0x10]
0000798fc6fd0744  vmovaps xmm3, [rsp+0x20]
0000798fc6fd074a  vmovaps xmm4, [rsp+0x30]
0000798fc6fd0750  vmovaps xmm5, [rsp+0x40]
0000798fc6fd0756  vmovaps xmm6, [rsp+0x50]
0000798fc6fd075c  vmovaps xmm7, [rsp+0x60]
0000798fc6fd0762  vmovaps xmm8, [rsp+0x70]
0000798fc6fd0768  vmovaps xmm9, [rsp+0x80]
0000798fc6fd0771  vmovaps xmm10, [rsp+0x90]
0000798fc6fd077a  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd0783  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd078c  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd0795  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd079e  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd07a7  add rsp, 0xF0
0000798fc6fd07ae  pop r11
0000798fc6fd07b0  pop r10
0000798fc6fd07b2  pop r9
0000798fc6fd07b4  pop r8
0000798fc6fd07b6  pop rsi
0000798fc6fd07b7  pop rdi
0000798fc6fd07b8  pop rdx
0000798fc6fd07b9  pop rcx
0000798fc6fd07ba  pop rax
0000798fc6fd07bb  add rsp, 0x08
0000798fc6fd07bf  jmp 0x0000798FC6FCF581
0000798fc6fd07c4  sub rsp, 0x08
0000798fc6fd07c8  push rax
0000798fc6fd07c9  push rcx
0000798fc6fd07ca  push rdx
0000798fc6fd07cb  push rdi
0000798fc6fd07cc  push rsi
0000798fc6fd07cd  push r8
0000798fc6fd07cf  push r9
0000798fc6fd07d1  push r10
0000798fc6fd07d3  push r11
0000798fc6fd07d5  sub rsp, 0xF0
0000798fc6fd07dc  vmovaps [rsp], xmm0
0000798fc6fd07e1  vmovaps [rsp+0x10], xmm1
0000798fc6fd07e7  vmovaps [rsp+0x20], xmm2
0000798fc6fd07ed  vmovaps [rsp+0x30], xmm3
0000798fc6fd07f3  vmovaps [rsp+0x40], xmm4
0000798fc6fd07f9  vmovaps [rsp+0x50], xmm5
0000798fc6fd07ff  vmovaps [rsp+0x60], xmm6
0000798fc6fd0805  vmovaps [rsp+0x70], xmm7
0000798fc6fd080b  vmovaps [rsp+0x80], xmm8
0000798fc6fd0814  vmovaps [rsp+0x90], xmm9
0000798fc6fd081d  vmovaps [rsp+0xA0], xmm10
0000798fc6fd0826  vmovaps [rsp+0xB0], xmm11
0000798fc6fd082f  vmovaps [rsp+0xC0], xmm12
0000798fc6fd0838  vmovaps [rsp+0xD0], xmm14
0000798fc6fd0841  vmovaps [rsp+0xE0], xmm15
0000798fc6fd084a  sub rsp, 0x30
0000798fc6fd084e  movaps [rsp], xmm13
0000798fc6fd0853  movaps [rsp+0x10], xmm1
0000798fc6fd0858  movaps [rsp+0x20], xmm14
0000798fc6fd085e  lea rdi, [rsp]
0000798fc6fd0862  mov esi, 0x00
0000798fc6fd0867  mov rax, 0x63E558B23530
0000798fc6fd0871  call rax
0000798fc6fd0873  movaps xmm13, [rsp]
0000798fc6fd0878  add rsp, 0x30
0000798fc6fd087c  vmovaps xmm0, [rsp]
0000798fc6fd0881  vmovaps xmm1, [rsp+0x10]
0000798fc6fd0887  vmovaps xmm2, [rsp+0x20]
0000798fc6fd088d  vmovaps xmm3, [rsp+0x30]
0000798fc6fd0893  vmovaps xmm4, [rsp+0x40]
0000798fc6fd0899  vmovaps xmm5, [rsp+0x50]
0000798fc6fd089f  vmovaps xmm6, [rsp+0x60]
0000798fc6fd08a5  vmovaps xmm7, [rsp+0x70]
0000798fc6fd08ab  vmovaps xmm8, [rsp+0x80]
0000798fc6fd08b4  vmovaps xmm9, [rsp+0x90]
0000798fc6fd08bd  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd08c6  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd08cf  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd08d8  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd08e1  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd08ea  add rsp, 0xF0
0000798fc6fd08f1  pop r11
0000798fc6fd08f3  pop r10
0000798fc6fd08f5  pop r9
0000798fc6fd08f7  pop r8
0000798fc6fd08f9  pop rsi
0000798fc6fd08fa  pop rdi
0000798fc6fd08fb  pop rdx
0000798fc6fd08fc  pop rcx
0000798fc6fd08fd  pop rax
0000798fc6fd08fe  add rsp, 0x08
0000798fc6fd0902  jmp 0x0000798FC6FCF5CF
0000798fc6fd0907  sub rsp, 0x08
0000798fc6fd090b  push rax
0000798fc6fd090c  push rcx
0000798fc6fd090d  push rdx
0000798fc6fd090e  push rdi
0000798fc6fd090f  push rsi
0000798fc6fd0910  push r8
0000798fc6fd0912  push r9
0000798fc6fd0914  push r10
0000798fc6fd0916  push r11
0000798fc6fd0918  sub rsp, 0xF0
0000798fc6fd091f  vmovaps [rsp], xmm0
0000798fc6fd0924  vmovaps [rsp+0x10], xmm1
0000798fc6fd092a  vmovaps [rsp+0x20], xmm2
0000798fc6fd0930  vmovaps [rsp+0x30], xmm3
0000798fc6fd0936  vmovaps [rsp+0x40], xmm4
0000798fc6fd093c  vmovaps [rsp+0x50], xmm5
0000798fc6fd0942  vmovaps [rsp+0x60], xmm6
0000798fc6fd0948  vmovaps [rsp+0x70], xmm7
0000798fc6fd094e  vmovaps [rsp+0x80], xmm8
0000798fc6fd0957  vmovaps [rsp+0x90], xmm9
0000798fc6fd0960  vmovaps [rsp+0xA0], xmm10
0000798fc6fd0969  vmovaps [rsp+0xB0], xmm11
0000798fc6fd0972  vmovaps [rsp+0xC0], xmm12
0000798fc6fd097b  vmovaps [rsp+0xD0], xmm13
0000798fc6fd0984  vmovaps [rsp+0xE0], xmm14
0000798fc6fd098d  sub rsp, 0x30
0000798fc6fd0991  movaps [rsp], xmm15
0000798fc6fd0996  movaps [rsp+0x10], xmm14
0000798fc6fd099c  movaps [rsp+0x20], xmm1
0000798fc6fd09a1  lea rdi, [rsp]
0000798fc6fd09a5  mov esi, 0x00
0000798fc6fd09aa  mov rax, 0x63E558B23530
0000798fc6fd09b4  call rax
0000798fc6fd09b6  movaps xmm15, [rsp]
0000798fc6fd09bb  add rsp, 0x30
0000798fc6fd09bf  vmovaps xmm0, [rsp]
0000798fc6fd09c4  vmovaps xmm1, [rsp+0x10]
0000798fc6fd09ca  vmovaps xmm2, [rsp+0x20]
0000798fc6fd09d0  vmovaps xmm3, [rsp+0x30]
0000798fc6fd09d6  vmovaps xmm4, [rsp+0x40]
0000798fc6fd09dc  vmovaps xmm5, [rsp+0x50]
0000798fc6fd09e2  vmovaps xmm6, [rsp+0x60]
0000798fc6fd09e8  vmovaps xmm7, [rsp+0x70]
0000798fc6fd09ee  vmovaps xmm8, [rsp+0x80]
0000798fc6fd09f7  vmovaps xmm9, [rsp+0x90]
0000798fc6fd0a00  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd0a09  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd0a12  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd0a1b  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd0a24  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd0a2d  add rsp, 0xF0
0000798fc6fd0a34  pop r11
0000798fc6fd0a36  pop r10
0000798fc6fd0a38  pop r9
0000798fc6fd0a3a  pop r8
0000798fc6fd0a3c  pop rsi
0000798fc6fd0a3d  pop rdi
0000798fc6fd0a3e  pop rdx
0000798fc6fd0a3f  pop rcx
0000798fc6fd0a40  pop rax
0000798fc6fd0a41  add rsp, 0x08
0000798fc6fd0a45  jmp 0x0000798FC6FCF617
0000798fc6fd0a4a  sub rsp, 0x08
0000798fc6fd0a4e  push rax
0000798fc6fd0a4f  push rcx
0000798fc6fd0a50  push rdx
0000798fc6fd0a51  push rdi
0000798fc6fd0a52  push rsi
0000798fc6fd0a53  push r8
0000798fc6fd0a55  push r9
0000798fc6fd0a57  push r10
0000798fc6fd0a59  push r11
0000798fc6fd0a5b  sub rsp, 0xF0
0000798fc6fd0a62  vmovaps [rsp], xmm0
0000798fc6fd0a67  vmovaps [rsp+0x10], xmm2
0000798fc6fd0a6d  vmovaps [rsp+0x20], xmm3
0000798fc6fd0a73  vmovaps [rsp+0x30], xmm4
0000798fc6fd0a79  vmovaps [rsp+0x40], xmm5
0000798fc6fd0a7f  vmovaps [rsp+0x50], xmm6
0000798fc6fd0a85  vmovaps [rsp+0x60], xmm7
0000798fc6fd0a8b  vmovaps [rsp+0x70], xmm8
0000798fc6fd0a91  vmovaps [rsp+0x80], xmm9
0000798fc6fd0a9a  vmovaps [rsp+0x90], xmm10
0000798fc6fd0aa3  vmovaps [rsp+0xA0], xmm11
0000798fc6fd0aac  vmovaps [rsp+0xB0], xmm12
0000798fc6fd0ab5  vmovaps [rsp+0xC0], xmm13
0000798fc6fd0abe  vmovaps [rsp+0xD0], xmm14
0000798fc6fd0ac7  vmovaps [rsp+0xE0], xmm15
0000798fc6fd0ad0  sub rsp, 0x30
0000798fc6fd0ad4  movaps [rsp], xmm1
0000798fc6fd0ad8  movaps [rsp+0x10], xmm14
0000798fc6fd0ade  movaps [rsp+0x20], xmm10
0000798fc6fd0ae4  lea rdi, [rsp]
0000798fc6fd0ae8  mov esi, 0x00
0000798fc6fd0aed  mov rax, 0x63E558B23530
0000798fc6fd0af7  call rax
0000798fc6fd0af9  movaps xmm1, [rsp]
0000798fc6fd0afd  add rsp, 0x30
0000798fc6fd0b01  vmovaps xmm0, [rsp]
0000798fc6fd0b06  vmovaps xmm2, [rsp+0x10]
0000798fc6fd0b0c  vmovaps xmm3, [rsp+0x20]
0000798fc6fd0b12  vmovaps xmm4, [rsp+0x30]
0000798fc6fd0b18  vmovaps xmm5, [rsp+0x40]
0000798fc6fd0b1e  vmovaps xmm6, [rsp+0x50]
0000798fc6fd0b24  vmovaps xmm7, [rsp+0x60]
0000798fc6fd0b2a  vmovaps xmm8, [rsp+0x70]
0000798fc6fd0b30  vmovaps xmm9, [rsp+0x80]
0000798fc6fd0b39  vmovaps xmm10, [rsp+0x90]
0000798fc6fd0b42  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd0b4b  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd0b54  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd0b5d  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd0b66  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd0b6f  add rsp, 0xF0
0000798fc6fd0b76  pop r11
0000798fc6fd0b78  pop r10
0000798fc6fd0b7a  pop r9
0000798fc6fd0b7c  pop r8
0000798fc6fd0b7e  pop rsi
0000798fc6fd0b7f  pop rdi
0000798fc6fd0b80  pop rdx
0000798fc6fd0b81  pop rcx
0000798fc6fd0b82  pop rax
0000798fc6fd0b83  add rsp, 0x08
0000798fc6fd0b87  jmp 0x0000798FC6FCF631
0000798fc6fd0b8c  sub rsp, 0x08
0000798fc6fd0b90  push rax
0000798fc6fd0b91  push rcx
0000798fc6fd0b92  push rdx
0000798fc6fd0b93  push rdi
0000798fc6fd0b94  push rsi
0000798fc6fd0b95  push r8
0000798fc6fd0b97  push r9
0000798fc6fd0b99  push r10
0000798fc6fd0b9b  push r11
0000798fc6fd0b9d  sub rsp, 0xF0
0000798fc6fd0ba4  vmovaps [rsp], xmm0
0000798fc6fd0ba9  vmovaps [rsp+0x10], xmm1
0000798fc6fd0baf  vmovaps [rsp+0x20], xmm2
0000798fc6fd0bb5  vmovaps [rsp+0x30], xmm3
0000798fc6fd0bbb  vmovaps [rsp+0x40], xmm4
0000798fc6fd0bc1  vmovaps [rsp+0x50], xmm5
0000798fc6fd0bc7  vmovaps [rsp+0x60], xmm6
0000798fc6fd0bcd  vmovaps [rsp+0x70], xmm7
0000798fc6fd0bd3  vmovaps [rsp+0x80], xmm8
0000798fc6fd0bdc  vmovaps [rsp+0x90], xmm9
0000798fc6fd0be5  vmovaps [rsp+0xA0], xmm10
0000798fc6fd0bee  vmovaps [rsp+0xB0], xmm11
0000798fc6fd0bf7  vmovaps [rsp+0xC0], xmm12
0000798fc6fd0c00  vmovaps [rsp+0xD0], xmm14
0000798fc6fd0c09  vmovaps [rsp+0xE0], xmm15
0000798fc6fd0c12  sub rsp, 0x30
0000798fc6fd0c16  movaps [rsp], xmm13
0000798fc6fd0c1b  movaps [rsp+0x10], xmm14
0000798fc6fd0c21  movaps [rsp+0x20], xmm2
0000798fc6fd0c26  lea rdi, [rsp]
0000798fc6fd0c2a  mov esi, 0x00
0000798fc6fd0c2f  mov rax, 0x63E558B23530
0000798fc6fd0c39  call rax
0000798fc6fd0c3b  movaps xmm13, [rsp]
0000798fc6fd0c40  add rsp, 0x30
0000798fc6fd0c44  vmovaps xmm0, [rsp]
0000798fc6fd0c49  vmovaps xmm1, [rsp+0x10]
0000798fc6fd0c4f  vmovaps xmm2, [rsp+0x20]
0000798fc6fd0c55  vmovaps xmm3, [rsp+0x30]
0000798fc6fd0c5b  vmovaps xmm4, [rsp+0x40]
0000798fc6fd0c61  vmovaps xmm5, [rsp+0x50]
0000798fc6fd0c67  vmovaps xmm6, [rsp+0x60]
0000798fc6fd0c6d  vmovaps xmm7, [rsp+0x70]
0000798fc6fd0c73  vmovaps xmm8, [rsp+0x80]
0000798fc6fd0c7c  vmovaps xmm9, [rsp+0x90]
0000798fc6fd0c85  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd0c8e  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd0c97  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd0ca0  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd0ca9  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd0cb2  add rsp, 0xF0
0000798fc6fd0cb9  pop r11
0000798fc6fd0cbb  pop r10
0000798fc6fd0cbd  pop r9
0000798fc6fd0cbf  pop r8
0000798fc6fd0cc1  pop rsi
0000798fc6fd0cc2  pop rdi
0000798fc6fd0cc3  pop rdx
0000798fc6fd0cc4  pop rcx
0000798fc6fd0cc5  pop rax
0000798fc6fd0cc6  add rsp, 0x08
0000798fc6fd0cca  jmp 0x0000798FC6FCF64C
0000798fc6fd0ccf  sub rsp, 0x08
0000798fc6fd0cd3  push rax
0000798fc6fd0cd4  push rcx
0000798fc6fd0cd5  push rdx
0000798fc6fd0cd6  push rdi
0000798fc6fd0cd7  push rsi
0000798fc6fd0cd8  push r8
0000798fc6fd0cda  push r9
0000798fc6fd0cdc  push r10
0000798fc6fd0cde  push r11
0000798fc6fd0ce0  sub rsp, 0xF0
0000798fc6fd0ce7  vmovaps [rsp], xmm0
0000798fc6fd0cec  vmovaps [rsp+0x10], xmm2
0000798fc6fd0cf2  vmovaps [rsp+0x20], xmm3
0000798fc6fd0cf8  vmovaps [rsp+0x30], xmm4
0000798fc6fd0cfe  vmovaps [rsp+0x40], xmm5
0000798fc6fd0d04  vmovaps [rsp+0x50], xmm6
0000798fc6fd0d0a  vmovaps [rsp+0x60], xmm7
0000798fc6fd0d10  vmovaps [rsp+0x70], xmm8
0000798fc6fd0d16  vmovaps [rsp+0x80], xmm9
0000798fc6fd0d1f  vmovaps [rsp+0x90], xmm10
0000798fc6fd0d28  vmovaps [rsp+0xA0], xmm11
0000798fc6fd0d31  vmovaps [rsp+0xB0], xmm12
0000798fc6fd0d3a  vmovaps [rsp+0xC0], xmm13
0000798fc6fd0d43  vmovaps [rsp+0xD0], xmm14
0000798fc6fd0d4c  vmovaps [rsp+0xE0], xmm15
0000798fc6fd0d55  sub rsp, 0x30
0000798fc6fd0d59  movaps [rsp], xmm1
0000798fc6fd0d5d  movaps [rsp+0x10], xmm10
0000798fc6fd0d63  movaps [rsp+0x20], xmm2
0000798fc6fd0d68  lea rdi, [rsp]
0000798fc6fd0d6c  mov esi, 0x00
0000798fc6fd0d71  mov rax, 0x63E558B23530
0000798fc6fd0d7b  call rax
0000798fc6fd0d7d  movaps xmm1, [rsp]
0000798fc6fd0d81  add rsp, 0x30
0000798fc6fd0d85  vmovaps xmm0, [rsp]
0000798fc6fd0d8a  vmovaps xmm2, [rsp+0x10]
0000798fc6fd0d90  vmovaps xmm3, [rsp+0x20]
0000798fc6fd0d96  vmovaps xmm4, [rsp+0x30]
0000798fc6fd0d9c  vmovaps xmm5, [rsp+0x40]
0000798fc6fd0da2  vmovaps xmm6, [rsp+0x50]
0000798fc6fd0da8  vmovaps xmm7, [rsp+0x60]
0000798fc6fd0dae  vmovaps xmm8, [rsp+0x70]
0000798fc6fd0db4  vmovaps xmm9, [rsp+0x80]
0000798fc6fd0dbd  vmovaps xmm10, [rsp+0x90]
0000798fc6fd0dc6  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd0dcf  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd0dd8  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd0de1  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd0dea  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd0df3  add rsp, 0xF0
0000798fc6fd0dfa  pop r11
0000798fc6fd0dfc  pop r10
0000798fc6fd0dfe  pop r9
0000798fc6fd0e00  pop r8
0000798fc6fd0e02  pop rsi
0000798fc6fd0e03  pop rdi
0000798fc6fd0e04  pop rdx
0000798fc6fd0e05  pop rcx
0000798fc6fd0e06  pop rax
0000798fc6fd0e07  add rsp, 0x08
0000798fc6fd0e0b  jmp 0x0000798FC6FCF6B4
0000798fc6fd0e10  sub rsp, 0x08
0000798fc6fd0e14  push rax
0000798fc6fd0e15  push rcx
0000798fc6fd0e16  push rdx
0000798fc6fd0e17  push rdi
0000798fc6fd0e18  push rsi
0000798fc6fd0e19  push r8
0000798fc6fd0e1b  push r9
0000798fc6fd0e1d  push r10
0000798fc6fd0e1f  push r11
0000798fc6fd0e21  sub rsp, 0xF0
0000798fc6fd0e28  vmovaps [rsp], xmm0
0000798fc6fd0e2d  vmovaps [rsp+0x10], xmm1
0000798fc6fd0e33  vmovaps [rsp+0x20], xmm2
0000798fc6fd0e39  vmovaps [rsp+0x30], xmm3
0000798fc6fd0e3f  vmovaps [rsp+0x40], xmm4
0000798fc6fd0e45  vmovaps [rsp+0x50], xmm5
0000798fc6fd0e4b  vmovaps [rsp+0x60], xmm6
0000798fc6fd0e51  vmovaps [rsp+0x70], xmm7
0000798fc6fd0e57  vmovaps [rsp+0x80], xmm8
0000798fc6fd0e60  vmovaps [rsp+0x90], xmm9
0000798fc6fd0e69  vmovaps [rsp+0xA0], xmm10
0000798fc6fd0e72  vmovaps [rsp+0xB0], xmm11
0000798fc6fd0e7b  vmovaps [rsp+0xC0], xmm12
0000798fc6fd0e84  vmovaps [rsp+0xD0], xmm13
0000798fc6fd0e8d  vmovaps [rsp+0xE0], xmm14
0000798fc6fd0e96  sub rsp, 0x30
0000798fc6fd0e9a  movaps [rsp], xmm15
0000798fc6fd0e9f  movaps [rsp+0x10], xmm10
0000798fc6fd0ea5  movaps [rsp+0x20], xmm2
0000798fc6fd0eaa  lea rdi, [rsp]
0000798fc6fd0eae  mov esi, 0x00
0000798fc6fd0eb3  mov rax, 0x63E558B23530
0000798fc6fd0ebd  call rax
0000798fc6fd0ebf  movaps xmm15, [rsp]
0000798fc6fd0ec4  add rsp, 0x30
0000798fc6fd0ec8  vmovaps xmm0, [rsp]
0000798fc6fd0ecd  vmovaps xmm1, [rsp+0x10]
0000798fc6fd0ed3  vmovaps xmm2, [rsp+0x20]
0000798fc6fd0ed9  vmovaps xmm3, [rsp+0x30]
0000798fc6fd0edf  vmovaps xmm4, [rsp+0x40]
0000798fc6fd0ee5  vmovaps xmm5, [rsp+0x50]
0000798fc6fd0eeb  vmovaps xmm6, [rsp+0x60]
0000798fc6fd0ef1  vmovaps xmm7, [rsp+0x70]
0000798fc6fd0ef7  vmovaps xmm8, [rsp+0x80]
0000798fc6fd0f00  vmovaps xmm9, [rsp+0x90]
0000798fc6fd0f09  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd0f12  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd0f1b  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd0f24  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd0f2d  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd0f36  add rsp, 0xF0
0000798fc6fd0f3d  pop r11
0000798fc6fd0f3f  pop r10
0000798fc6fd0f41  pop r9
0000798fc6fd0f43  pop r8
0000798fc6fd0f45  pop rsi
0000798fc6fd0f46  pop rdi
0000798fc6fd0f47  pop rdx
0000798fc6fd0f48  pop rcx
0000798fc6fd0f49  pop rax
0000798fc6fd0f4a  add rsp, 0x08
0000798fc6fd0f4e  jmp 0x0000798FC6FCF706
0000798fc6fd0f53  sub rsp, 0x08
0000798fc6fd0f57  push rax
0000798fc6fd0f58  push rcx
0000798fc6fd0f59  push rdx
0000798fc6fd0f5a  push rdi
0000798fc6fd0f5b  push rsi
0000798fc6fd0f5c  push r8
0000798fc6fd0f5e  push r9
0000798fc6fd0f60  push r10
0000798fc6fd0f62  push r11
0000798fc6fd0f64  sub rsp, 0xF0
0000798fc6fd0f6b  vmovaps [rsp], xmm0
0000798fc6fd0f70  vmovaps [rsp+0x10], xmm2
0000798fc6fd0f76  vmovaps [rsp+0x20], xmm3
0000798fc6fd0f7c  vmovaps [rsp+0x30], xmm4
0000798fc6fd0f82  vmovaps [rsp+0x40], xmm5
0000798fc6fd0f88  vmovaps [rsp+0x50], xmm6
0000798fc6fd0f8e  vmovaps [rsp+0x60], xmm7
0000798fc6fd0f94  vmovaps [rsp+0x70], xmm8
0000798fc6fd0f9a  vmovaps [rsp+0x80], xmm9
0000798fc6fd0fa3  vmovaps [rsp+0x90], xmm10
0000798fc6fd0fac  vmovaps [rsp+0xA0], xmm11
0000798fc6fd0fb5  vmovaps [rsp+0xB0], xmm12
0000798fc6fd0fbe  vmovaps [rsp+0xC0], xmm13
0000798fc6fd0fc7  vmovaps [rsp+0xD0], xmm14
0000798fc6fd0fd0  vmovaps [rsp+0xE0], xmm15
0000798fc6fd0fd9  sub rsp, 0x30
0000798fc6fd0fdd  movaps [rsp], xmm1
0000798fc6fd0fe1  movaps [rsp+0x10], xmm10
0000798fc6fd0fe7  movaps [rsp+0x20], xmm12
0000798fc6fd0fed  lea rdi, [rsp]
0000798fc6fd0ff1  mov esi, 0x00
0000798fc6fd0ff6  mov rax, 0x63E558B23530
0000798fc6fd1000  call rax
0000798fc6fd1002  movaps xmm1, [rsp]
0000798fc6fd1006  add rsp, 0x30
0000798fc6fd100a  vmovaps xmm0, [rsp]
0000798fc6fd100f  vmovaps xmm2, [rsp+0x10]
0000798fc6fd1015  vmovaps xmm3, [rsp+0x20]
0000798fc6fd101b  vmovaps xmm4, [rsp+0x30]
0000798fc6fd1021  vmovaps xmm5, [rsp+0x40]
0000798fc6fd1027  vmovaps xmm6, [rsp+0x50]
0000798fc6fd102d  vmovaps xmm7, [rsp+0x60]
0000798fc6fd1033  vmovaps xmm8, [rsp+0x70]
0000798fc6fd1039  vmovaps xmm9, [rsp+0x80]
0000798fc6fd1042  vmovaps xmm10, [rsp+0x90]
0000798fc6fd104b  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd1054  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd105d  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd1066  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd106f  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd1078  add rsp, 0xF0
0000798fc6fd107f  pop r11
0000798fc6fd1081  pop r10
0000798fc6fd1083  pop r9
0000798fc6fd1085  pop r8
0000798fc6fd1087  pop rsi
0000798fc6fd1088  pop rdi
0000798fc6fd1089  pop rdx
0000798fc6fd108a  pop rcx
0000798fc6fd108b  pop rax
0000798fc6fd108c  add rsp, 0x08
0000798fc6fd1090  jmp 0x0000798FC6FCF732
0000798fc6fd1095  sub rsp, 0x08
0000798fc6fd1099  push rax
0000798fc6fd109a  push rcx
0000798fc6fd109b  push rdx
0000798fc6fd109c  push rdi
0000798fc6fd109d  push rsi
0000798fc6fd109e  push r8
0000798fc6fd10a0  push r9
0000798fc6fd10a2  push r10
0000798fc6fd10a4  push r11
0000798fc6fd10a6  sub rsp, 0xF0
0000798fc6fd10ad  vmovaps [rsp], xmm0
0000798fc6fd10b2  vmovaps [rsp+0x10], xmm1
0000798fc6fd10b8  vmovaps [rsp+0x20], xmm2
0000798fc6fd10be  vmovaps [rsp+0x30], xmm3
0000798fc6fd10c4  vmovaps [rsp+0x40], xmm4
0000798fc6fd10ca  vmovaps [rsp+0x50], xmm5
0000798fc6fd10d0  vmovaps [rsp+0x60], xmm6
0000798fc6fd10d6  vmovaps [rsp+0x70], xmm7
0000798fc6fd10dc  vmovaps [rsp+0x80], xmm8
0000798fc6fd10e5  vmovaps [rsp+0x90], xmm9
0000798fc6fd10ee  vmovaps [rsp+0xA0], xmm10
0000798fc6fd10f7  vmovaps [rsp+0xB0], xmm11
0000798fc6fd1100  vmovaps [rsp+0xC0], xmm12
0000798fc6fd1109  vmovaps [rsp+0xD0], xmm13
0000798fc6fd1112  vmovaps [rsp+0xE0], xmm14
0000798fc6fd111b  sub rsp, 0x30
0000798fc6fd111f  movaps [rsp], xmm15
0000798fc6fd1124  movaps [rsp+0x10], xmm10
0000798fc6fd112a  movaps [rsp+0x20], xmm12
0000798fc6fd1130  lea rdi, [rsp]
0000798fc6fd1134  mov esi, 0x00
0000798fc6fd1139  mov rax, 0x63E558B23530
0000798fc6fd1143  call rax
0000798fc6fd1145  movaps xmm15, [rsp]
0000798fc6fd114a  add rsp, 0x30
0000798fc6fd114e  vmovaps xmm0, [rsp]
0000798fc6fd1153  vmovaps xmm1, [rsp+0x10]
0000798fc6fd1159  vmovaps xmm2, [rsp+0x20]
0000798fc6fd115f  vmovaps xmm3, [rsp+0x30]
0000798fc6fd1165  vmovaps xmm4, [rsp+0x40]
0000798fc6fd116b  vmovaps xmm5, [rsp+0x50]
0000798fc6fd1171  vmovaps xmm6, [rsp+0x60]
0000798fc6fd1177  vmovaps xmm7, [rsp+0x70]
0000798fc6fd117d  vmovaps xmm8, [rsp+0x80]
0000798fc6fd1186  vmovaps xmm9, [rsp+0x90]
0000798fc6fd118f  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd1198  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd11a1  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd11aa  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd11b3  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd11bc  add rsp, 0xF0
0000798fc6fd11c3  pop r11
0000798fc6fd11c5  pop r10
0000798fc6fd11c7  pop r9
0000798fc6fd11c9  pop r8
0000798fc6fd11cb  pop rsi
0000798fc6fd11cc  pop rdi
0000798fc6fd11cd  pop rdx
0000798fc6fd11ce  pop rcx
0000798fc6fd11cf  pop rax
0000798fc6fd11d0  add rsp, 0x08
0000798fc6fd11d4  jmp 0x0000798FC6FCF75E
0000798fc6fd11d9  call 0x0000798FC6DFF430
0000798fc6fd11de  jmp 0x0000798FC6FCF7EE
0000798fc6fd11e3  call 0x0000798FC6DFF430
0000798fc6fd11e8  jmp 0x0000798FC6FCF801
0000798fc6fd11ed  sub rsp, 0x08
0000798fc6fd11f1  push rax
0000798fc6fd11f2  push rcx
0000798fc6fd11f3  push rdx
0000798fc6fd11f4  push rdi
0000798fc6fd11f5  push rsi
0000798fc6fd11f6  push r8
0000798fc6fd11f8  push r9
0000798fc6fd11fa  push r10
0000798fc6fd11fc  push r11
0000798fc6fd11fe  sub rsp, 0xF0
0000798fc6fd1205  vmovaps [rsp], xmm0
0000798fc6fd120a  vmovaps [rsp+0x10], xmm2
0000798fc6fd1210  vmovaps [rsp+0x20], xmm3
0000798fc6fd1216  vmovaps [rsp+0x30], xmm4
0000798fc6fd121c  vmovaps [rsp+0x40], xmm5
0000798fc6fd1222  vmovaps [rsp+0x50], xmm6
0000798fc6fd1228  vmovaps [rsp+0x60], xmm7
0000798fc6fd122e  vmovaps [rsp+0x70], xmm8
0000798fc6fd1234  vmovaps [rsp+0x80], xmm9
0000798fc6fd123d  vmovaps [rsp+0x90], xmm10
0000798fc6fd1246  vmovaps [rsp+0xA0], xmm11
0000798fc6fd124f  vmovaps [rsp+0xB0], xmm12
0000798fc6fd1258  vmovaps [rsp+0xC0], xmm13
0000798fc6fd1261  vmovaps [rsp+0xD0], xmm14
0000798fc6fd126a  vmovaps [rsp+0xE0], xmm15
0000798fc6fd1273  sub rsp, 0x30
0000798fc6fd1277  movaps [rsp], xmm1
0000798fc6fd127b  movaps [rsp+0x10], xmm13
0000798fc6fd1281  movaps [rsp+0x20], xmm2
0000798fc6fd1286  lea rdi, [rsp]
0000798fc6fd128a  mov esi, 0x00
0000798fc6fd128f  mov rax, 0x63E558B23530
0000798fc6fd1299  call rax
0000798fc6fd129b  movaps xmm1, [rsp]
0000798fc6fd129f  add rsp, 0x30
0000798fc6fd12a3  vmovaps xmm0, [rsp]
0000798fc6fd12a8  vmovaps xmm2, [rsp+0x10]
0000798fc6fd12ae  vmovaps xmm3, [rsp+0x20]
0000798fc6fd12b4  vmovaps xmm4, [rsp+0x30]
0000798fc6fd12ba  vmovaps xmm5, [rsp+0x40]
0000798fc6fd12c0  vmovaps xmm6, [rsp+0x50]
0000798fc6fd12c6  vmovaps xmm7, [rsp+0x60]
0000798fc6fd12cc  vmovaps xmm8, [rsp+0x70]
0000798fc6fd12d2  vmovaps xmm9, [rsp+0x80]
0000798fc6fd12db  vmovaps xmm10, [rsp+0x90]
0000798fc6fd12e4  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd12ed  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd12f6  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd12ff  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd1308  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd1311  add rsp, 0xF0
0000798fc6fd1318  pop r11
0000798fc6fd131a  pop r10
0000798fc6fd131c  pop r9
0000798fc6fd131e  pop r8
0000798fc6fd1320  pop rsi
0000798fc6fd1321  pop rdi
0000798fc6fd1322  pop rdx
0000798fc6fd1323  pop rcx
0000798fc6fd1324  pop rax
0000798fc6fd1325  add rsp, 0x08
0000798fc6fd1329  jmp 0x0000798FC6FCF82C
0000798fc6fd132e  call 0x0000798FC6E0E760
0000798fc6fd1333  jmp 0x0000798FC6FCF839
0000798fc6fd1338  sub rsp, 0x08
0000798fc6fd133c  push rax
0000798fc6fd133d  push rcx
0000798fc6fd133e  push rdx
0000798fc6fd133f  push rdi
0000798fc6fd1340  push rsi
0000798fc6fd1341  push r8
0000798fc6fd1343  push r9
0000798fc6fd1345  push r10
0000798fc6fd1347  push r11
0000798fc6fd1349  sub rsp, 0xF0
0000798fc6fd1350  vmovaps [rsp], xmm0
0000798fc6fd1355  vmovaps [rsp+0x10], xmm1
0000798fc6fd135b  vmovaps [rsp+0x20], xmm2
0000798fc6fd1361  vmovaps [rsp+0x30], xmm3
0000798fc6fd1367  vmovaps [rsp+0x40], xmm4
0000798fc6fd136d  vmovaps [rsp+0x50], xmm5
0000798fc6fd1373  vmovaps [rsp+0x60], xmm6
0000798fc6fd1379  vmovaps [rsp+0x70], xmm7
0000798fc6fd137f  vmovaps [rsp+0x80], xmm8
0000798fc6fd1388  vmovaps [rsp+0x90], xmm9
0000798fc6fd1391  vmovaps [rsp+0xA0], xmm10
0000798fc6fd139a  vmovaps [rsp+0xB0], xmm11
0000798fc6fd13a3  vmovaps [rsp+0xC0], xmm12
0000798fc6fd13ac  vmovaps [rsp+0xD0], xmm14
0000798fc6fd13b5  vmovaps [rsp+0xE0], xmm15
0000798fc6fd13be  sub rsp, 0x30
0000798fc6fd13c2  movaps [rsp], xmm13
0000798fc6fd13c7  movaps [rsp+0x10], xmm2
0000798fc6fd13cc  movaps [rsp+0x20], xmm1
0000798fc6fd13d1  lea rdi, [rsp]
0000798fc6fd13d5  mov esi, 0x00
0000798fc6fd13da  mov rax, 0x63E558B23530
0000798fc6fd13e4  call rax
0000798fc6fd13e6  movaps xmm13, [rsp]
0000798fc6fd13eb  add rsp, 0x30
0000798fc6fd13ef  vmovaps xmm0, [rsp]
0000798fc6fd13f4  vmovaps xmm1, [rsp+0x10]
0000798fc6fd13fa  vmovaps xmm2, [rsp+0x20]
0000798fc6fd1400  vmovaps xmm3, [rsp+0x30]
0000798fc6fd1406  vmovaps xmm4, [rsp+0x40]
0000798fc6fd140c  vmovaps xmm5, [rsp+0x50]
0000798fc6fd1412  vmovaps xmm6, [rsp+0x60]
0000798fc6fd1418  vmovaps xmm7, [rsp+0x70]
0000798fc6fd141e  vmovaps xmm8, [rsp+0x80]
0000798fc6fd1427  vmovaps xmm9, [rsp+0x90]
0000798fc6fd1430  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd1439  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd1442  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd144b  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd1454  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd145d  add rsp, 0xF0
0000798fc6fd1464  pop r11
0000798fc6fd1466  pop r10
0000798fc6fd1468  pop r9
0000798fc6fd146a  pop r8
0000798fc6fd146c  pop rsi
0000798fc6fd146d  pop rdi
0000798fc6fd146e  pop rdx
0000798fc6fd146f  pop rcx
0000798fc6fd1470  pop rax
0000798fc6fd1471  add rsp, 0x08
0000798fc6fd1475  jmp 0x0000798FC6FCF878
0000798fc6fd147a  sub rsp, 0x08
0000798fc6fd147e  push rax
0000798fc6fd147f  push rcx
0000798fc6fd1480  push rdx
0000798fc6fd1481  push rdi
0000798fc6fd1482  push rsi
0000798fc6fd1483  push r8
0000798fc6fd1485  push r9
0000798fc6fd1487  push r10
0000798fc6fd1489  push r11
0000798fc6fd148b  sub rsp, 0xF0
0000798fc6fd1492  vmovaps [rsp], xmm0
0000798fc6fd1497  vmovaps [rsp+0x10], xmm2
0000798fc6fd149d  vmovaps [rsp+0x20], xmm3
0000798fc6fd14a3  vmovaps [rsp+0x30], xmm4
0000798fc6fd14a9  vmovaps [rsp+0x40], xmm5
0000798fc6fd14af  vmovaps [rsp+0x50], xmm6
0000798fc6fd14b5  vmovaps [rsp+0x60], xmm7
0000798fc6fd14bb  vmovaps [rsp+0x70], xmm8
0000798fc6fd14c1  vmovaps [rsp+0x80], xmm9
0000798fc6fd14ca  vmovaps [rsp+0x90], xmm10
0000798fc6fd14d3  vmovaps [rsp+0xA0], xmm11
0000798fc6fd14dc  vmovaps [rsp+0xB0], xmm12
0000798fc6fd14e5  vmovaps [rsp+0xC0], xmm13
0000798fc6fd14ee  vmovaps [rsp+0xD0], xmm14
0000798fc6fd14f7  vmovaps [rsp+0xE0], xmm15
0000798fc6fd1500  sub rsp, 0x30
0000798fc6fd1504  movaps [rsp], xmm1
0000798fc6fd1508  movaps [rsp+0x10], xmm15
0000798fc6fd150e  movaps [rsp+0x20], xmm2
0000798fc6fd1513  lea rdi, [rsp]
0000798fc6fd1517  mov esi, 0x00
0000798fc6fd151c  mov rax, 0x63E558B23530
0000798fc6fd1526  call rax
0000798fc6fd1528  movaps xmm1, [rsp]
0000798fc6fd152c  add rsp, 0x30
0000798fc6fd1530  vmovaps xmm0, [rsp]
0000798fc6fd1535  vmovaps xmm2, [rsp+0x10]
0000798fc6fd153b  vmovaps xmm3, [rsp+0x20]
0000798fc6fd1541  vmovaps xmm4, [rsp+0x30]
0000798fc6fd1547  vmovaps xmm5, [rsp+0x40]
0000798fc6fd154d  vmovaps xmm6, [rsp+0x50]
0000798fc6fd1553  vmovaps xmm7, [rsp+0x60]
0000798fc6fd1559  vmovaps xmm8, [rsp+0x70]
0000798fc6fd155f  vmovaps xmm9, [rsp+0x80]
0000798fc6fd1568  vmovaps xmm10, [rsp+0x90]
0000798fc6fd1571  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd157a  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd1583  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd158c  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd1595  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd159e  add rsp, 0xF0
0000798fc6fd15a5  pop r11
0000798fc6fd15a7  pop r10
0000798fc6fd15a9  pop r9
0000798fc6fd15ab  pop r8
0000798fc6fd15ad  pop rsi
0000798fc6fd15ae  pop rdi
0000798fc6fd15af  pop rdx
0000798fc6fd15b0  pop rcx
0000798fc6fd15b1  pop rax
0000798fc6fd15b2  add rsp, 0x08
0000798fc6fd15b6  jmp 0x0000798FC6FCF8AC
0000798fc6fd15bb  sub rsp, 0x08
0000798fc6fd15bf  push rax
0000798fc6fd15c0  push rcx
0000798fc6fd15c1  push rdx
0000798fc6fd15c2  push rdi
0000798fc6fd15c3  push rsi
0000798fc6fd15c4  push r8
0000798fc6fd15c6  push r9
0000798fc6fd15c8  push r10
0000798fc6fd15ca  push r11
0000798fc6fd15cc  sub rsp, 0xF0
0000798fc6fd15d3  vmovaps [rsp], xmm0
0000798fc6fd15d8  vmovaps [rsp+0x10], xmm1
0000798fc6fd15de  vmovaps [rsp+0x20], xmm2
0000798fc6fd15e4  vmovaps [rsp+0x30], xmm3
0000798fc6fd15ea  vmovaps [rsp+0x40], xmm4
0000798fc6fd15f0  vmovaps [rsp+0x50], xmm5
0000798fc6fd15f6  vmovaps [rsp+0x60], xmm6
0000798fc6fd15fc  vmovaps [rsp+0x70], xmm7
0000798fc6fd1602  vmovaps [rsp+0x80], xmm8
0000798fc6fd160b  vmovaps [rsp+0x90], xmm9
0000798fc6fd1614  vmovaps [rsp+0xA0], xmm10
0000798fc6fd161d  vmovaps [rsp+0xB0], xmm11
0000798fc6fd1626  vmovaps [rsp+0xC0], xmm12
0000798fc6fd162f  vmovaps [rsp+0xD0], xmm13
0000798fc6fd1638  vmovaps [rsp+0xE0], xmm15
0000798fc6fd1641  sub rsp, 0x30
0000798fc6fd1645  movaps [rsp], xmm14
0000798fc6fd164a  movaps [rsp+0x10], xmm2
0000798fc6fd164f  movaps [rsp+0x20], xmm15
0000798fc6fd1655  lea rdi, [rsp]
0000798fc6fd1659  mov esi, 0x00
0000798fc6fd165e  mov rax, 0x63E558B23530
0000798fc6fd1668  call rax
0000798fc6fd166a  movaps xmm14, [rsp]
0000798fc6fd166f  add rsp, 0x30
0000798fc6fd1673  vmovaps xmm0, [rsp]
0000798fc6fd1678  vmovaps xmm1, [rsp+0x10]
0000798fc6fd167e  vmovaps xmm2, [rsp+0x20]
0000798fc6fd1684  vmovaps xmm3, [rsp+0x30]
0000798fc6fd168a  vmovaps xmm4, [rsp+0x40]
0000798fc6fd1690  vmovaps xmm5, [rsp+0x50]
0000798fc6fd1696  vmovaps xmm6, [rsp+0x60]
0000798fc6fd169c  vmovaps xmm7, [rsp+0x70]
0000798fc6fd16a2  vmovaps xmm8, [rsp+0x80]
0000798fc6fd16ab  vmovaps xmm9, [rsp+0x90]
0000798fc6fd16b4  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd16bd  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd16c6  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd16cf  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd16d8  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd16e1  add rsp, 0xF0
0000798fc6fd16e8  pop r11
0000798fc6fd16ea  pop r10
0000798fc6fd16ec  pop r9
0000798fc6fd16ee  pop r8
0000798fc6fd16f0  pop rsi
0000798fc6fd16f1  pop rdi
0000798fc6fd16f2  pop rdx
0000798fc6fd16f3  pop rcx
0000798fc6fd16f4  pop rax
0000798fc6fd16f5  add rsp, 0x08
0000798fc6fd16f9  jmp 0x0000798FC6FCF8E7
0000798fc6fd16fe  sub rsp, 0x08
0000798fc6fd1702  push rax
0000798fc6fd1703  push rcx
0000798fc6fd1704  push rdx
0000798fc6fd1705  push rdi
0000798fc6fd1706  push rsi
0000798fc6fd1707  push r8
0000798fc6fd1709  push r9
0000798fc6fd170b  push r10
0000798fc6fd170d  push r11
0000798fc6fd170f  sub rsp, 0xF0
0000798fc6fd1716  vmovaps [rsp], xmm0
0000798fc6fd171b  vmovaps [rsp+0x10], xmm1
0000798fc6fd1721  vmovaps [rsp+0x20], xmm2
0000798fc6fd1727  vmovaps [rsp+0x30], xmm3
0000798fc6fd172d  vmovaps [rsp+0x40], xmm4
0000798fc6fd1733  vmovaps [rsp+0x50], xmm5
0000798fc6fd1739  vmovaps [rsp+0x60], xmm6
0000798fc6fd173f  vmovaps [rsp+0x70], xmm7
0000798fc6fd1745  vmovaps [rsp+0x80], xmm8
0000798fc6fd174e  vmovaps [rsp+0x90], xmm9
0000798fc6fd1757  vmovaps [rsp+0xA0], xmm10
0000798fc6fd1760  vmovaps [rsp+0xB0], xmm11
0000798fc6fd1769  vmovaps [rsp+0xC0], xmm12
0000798fc6fd1772  vmovaps [rsp+0xD0], xmm13
0000798fc6fd177b  vmovaps [rsp+0xE0], xmm14
0000798fc6fd1784  sub rsp, 0x30
0000798fc6fd1788  movaps [rsp], xmm15
0000798fc6fd178d  movaps [rsp+0x10], xmm2
0000798fc6fd1792  movaps [rsp+0x20], xmm1
0000798fc6fd1797  lea rdi, [rsp]
0000798fc6fd179b  mov esi, 0x00
0000798fc6fd17a0  mov rax, 0x63E558B23530
0000798fc6fd17aa  call rax
0000798fc6fd17ac  movaps xmm15, [rsp]
0000798fc6fd17b1  add rsp, 0x30
0000798fc6fd17b5  vmovaps xmm0, [rsp]
0000798fc6fd17ba  vmovaps xmm1, [rsp+0x10]
0000798fc6fd17c0  vmovaps xmm2, [rsp+0x20]
0000798fc6fd17c6  vmovaps xmm3, [rsp+0x30]
0000798fc6fd17cc  vmovaps xmm4, [rsp+0x40]
0000798fc6fd17d2  vmovaps xmm5, [rsp+0x50]
0000798fc6fd17d8  vmovaps xmm6, [rsp+0x60]
0000798fc6fd17de  vmovaps xmm7, [rsp+0x70]
0000798fc6fd17e4  vmovaps xmm8, [rsp+0x80]
0000798fc6fd17ed  vmovaps xmm9, [rsp+0x90]
0000798fc6fd17f6  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd17ff  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd1808  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd1811  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd181a  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd1823  add rsp, 0xF0
0000798fc6fd182a  pop r11
0000798fc6fd182c  pop r10
0000798fc6fd182e  pop r9
0000798fc6fd1830  pop r8
0000798fc6fd1832  pop rsi
0000798fc6fd1833  pop rdi
0000798fc6fd1834  pop rdx
0000798fc6fd1835  pop rcx
0000798fc6fd1836  pop rax
0000798fc6fd1837  add rsp, 0x08
0000798fc6fd183b  jmp 0x0000798FC6FCF923
0000798fc6fd1840  call 0x0000798FC6DFF430
0000798fc6fd1845  jmp 0x0000798FC6FCF930
0000798fc6fd184a  sub rsp, 0x08
0000798fc6fd184e  push rax
0000798fc6fd184f  push rcx
0000798fc6fd1850  push rdx
0000798fc6fd1851  push rdi
0000798fc6fd1852  push rsi
0000798fc6fd1853  push r8
0000798fc6fd1855  push r9
0000798fc6fd1857  push r10
0000798fc6fd1859  push r11
0000798fc6fd185b  sub rsp, 0xF0
0000798fc6fd1862  vmovaps [rsp], xmm0
0000798fc6fd1867  vmovaps [rsp+0x10], xmm1
0000798fc6fd186d  vmovaps [rsp+0x20], xmm3
0000798fc6fd1873  vmovaps [rsp+0x30], xmm4
0000798fc6fd1879  vmovaps [rsp+0x40], xmm5
0000798fc6fd187f  vmovaps [rsp+0x50], xmm6
0000798fc6fd1885  vmovaps [rsp+0x60], xmm7
0000798fc6fd188b  vmovaps [rsp+0x70], xmm8
0000798fc6fd1891  vmovaps [rsp+0x80], xmm9
0000798fc6fd189a  vmovaps [rsp+0x90], xmm10
0000798fc6fd18a3  vmovaps [rsp+0xA0], xmm11
0000798fc6fd18ac  vmovaps [rsp+0xB0], xmm12
0000798fc6fd18b5  vmovaps [rsp+0xC0], xmm13
0000798fc6fd18be  vmovaps [rsp+0xD0], xmm14
0000798fc6fd18c7  vmovaps [rsp+0xE0], xmm15
0000798fc6fd18d0  sub rsp, 0x30
0000798fc6fd18d4  movaps [rsp], xmm2
0000798fc6fd18d8  movaps [rsp+0x10], xmm1
0000798fc6fd18dd  movaps [rsp+0x20], xmm14
0000798fc6fd18e3  lea rdi, [rsp]
0000798fc6fd18e7  mov esi, 0x00
0000798fc6fd18ec  mov rax, 0x63E558B23530
0000798fc6fd18f6  call rax
0000798fc6fd18f8  movaps xmm2, [rsp]
0000798fc6fd18fc  add rsp, 0x30
0000798fc6fd1900  vmovaps xmm0, [rsp]
0000798fc6fd1905  vmovaps xmm1, [rsp+0x10]
0000798fc6fd190b  vmovaps xmm3, [rsp+0x20]
0000798fc6fd1911  vmovaps xmm4, [rsp+0x30]
0000798fc6fd1917  vmovaps xmm5, [rsp+0x40]
0000798fc6fd191d  vmovaps xmm6, [rsp+0x50]
0000798fc6fd1923  vmovaps xmm7, [rsp+0x60]
0000798fc6fd1929  vmovaps xmm8, [rsp+0x70]
0000798fc6fd192f  vmovaps xmm9, [rsp+0x80]
0000798fc6fd1938  vmovaps xmm10, [rsp+0x90]
0000798fc6fd1941  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd194a  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd1953  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd195c  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd1965  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd196e  add rsp, 0xF0
0000798fc6fd1975  pop r11
0000798fc6fd1977  pop r10
0000798fc6fd1979  pop r9
0000798fc6fd197b  pop r8
0000798fc6fd197d  pop rsi
0000798fc6fd197e  pop rdi
0000798fc6fd197f  pop rdx
0000798fc6fd1980  pop rcx
0000798fc6fd1981  pop rax
0000798fc6fd1982  add rsp, 0x08
0000798fc6fd1986  jmp 0x0000798FC6FCF96D
0000798fc6fd198b  sub rsp, 0x08
0000798fc6fd198f  push rax
0000798fc6fd1990  push rcx
0000798fc6fd1991  push rdx
0000798fc6fd1992  push rdi
0000798fc6fd1993  push rsi
0000798fc6fd1994  push r8
0000798fc6fd1996  push r9
0000798fc6fd1998  push r10
0000798fc6fd199a  push r11
0000798fc6fd199c  sub rsp, 0xF0
0000798fc6fd19a3  vmovaps [rsp], xmm0
0000798fc6fd19a8  vmovaps [rsp+0x10], xmm1
0000798fc6fd19ae  vmovaps [rsp+0x20], xmm2
0000798fc6fd19b4  vmovaps [rsp+0x30], xmm3
0000798fc6fd19ba  vmovaps [rsp+0x40], xmm4
0000798fc6fd19c0  vmovaps [rsp+0x50], xmm5
0000798fc6fd19c6  vmovaps [rsp+0x60], xmm6
0000798fc6fd19cc  vmovaps [rsp+0x70], xmm7
0000798fc6fd19d2  vmovaps [rsp+0x80], xmm8
0000798fc6fd19db  vmovaps [rsp+0x90], xmm9
0000798fc6fd19e4  vmovaps [rsp+0xA0], xmm10
0000798fc6fd19ed  vmovaps [rsp+0xB0], xmm11
0000798fc6fd19f6  vmovaps [rsp+0xC0], xmm12
0000798fc6fd19ff  vmovaps [rsp+0xD0], xmm13
0000798fc6fd1a08  vmovaps [rsp+0xE0], xmm14
0000798fc6fd1a11  sub rsp, 0x30
0000798fc6fd1a15  movaps [rsp], xmm15
0000798fc6fd1a1a  movaps [rsp+0x10], xmm14
0000798fc6fd1a20  movaps [rsp+0x20], xmm1
0000798fc6fd1a25  lea rdi, [rsp]
0000798fc6fd1a29  mov esi, 0x00
0000798fc6fd1a2e  mov rax, 0x63E558B23530
0000798fc6fd1a38  call rax
0000798fc6fd1a3a  movaps xmm15, [rsp]
0000798fc6fd1a3f  add rsp, 0x30
0000798fc6fd1a43  vmovaps xmm0, [rsp]
0000798fc6fd1a48  vmovaps xmm1, [rsp+0x10]
0000798fc6fd1a4e  vmovaps xmm2, [rsp+0x20]
0000798fc6fd1a54  vmovaps xmm3, [rsp+0x30]
0000798fc6fd1a5a  vmovaps xmm4, [rsp+0x40]
0000798fc6fd1a60  vmovaps xmm5, [rsp+0x50]
0000798fc6fd1a66  vmovaps xmm6, [rsp+0x60]
0000798fc6fd1a6c  vmovaps xmm7, [rsp+0x70]
0000798fc6fd1a72  vmovaps xmm8, [rsp+0x80]
0000798fc6fd1a7b  vmovaps xmm9, [rsp+0x90]
0000798fc6fd1a84  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd1a8d  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd1a96  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd1a9f  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd1aa8  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd1ab1  add rsp, 0xF0
0000798fc6fd1ab8  pop r11
0000798fc6fd1aba  pop r10
0000798fc6fd1abc  pop r9
0000798fc6fd1abe  pop r8
0000798fc6fd1ac0  pop rsi
0000798fc6fd1ac1  pop rdi
0000798fc6fd1ac2  pop rdx
0000798fc6fd1ac3  pop rcx
0000798fc6fd1ac4  pop rax
0000798fc6fd1ac5  add rsp, 0x08
0000798fc6fd1ac9  jmp 0x0000798FC6FCF9E7
0000798fc6fd1ace  call 0x0000798FC6DFF430
0000798fc6fd1ad3  jmp 0x0000798FC6FCF9F4
0000798fc6fd1ad8  sub rsp, 0x08
0000798fc6fd1adc  push rax
0000798fc6fd1add  push rcx
0000798fc6fd1ade  push rdx
0000798fc6fd1adf  push rdi
0000798fc6fd1ae0  push rsi
0000798fc6fd1ae1  push r8
0000798fc6fd1ae3  push r9
0000798fc6fd1ae5  push r10
0000798fc6fd1ae7  push r11
0000798fc6fd1ae9  sub rsp, 0xF0
0000798fc6fd1af0  vmovaps [rsp], xmm0
0000798fc6fd1af5  vmovaps [rsp+0x10], xmm1
0000798fc6fd1afb  vmovaps [rsp+0x20], xmm2
0000798fc6fd1b01  vmovaps [rsp+0x30], xmm3
0000798fc6fd1b07  vmovaps [rsp+0x40], xmm4
0000798fc6fd1b0d  vmovaps [rsp+0x50], xmm5
0000798fc6fd1b13  vmovaps [rsp+0x60], xmm6
0000798fc6fd1b19  vmovaps [rsp+0x70], xmm7
0000798fc6fd1b1f  vmovaps [rsp+0x80], xmm8
0000798fc6fd1b28  vmovaps [rsp+0x90], xmm9
0000798fc6fd1b31  vmovaps [rsp+0xA0], xmm10
0000798fc6fd1b3a  vmovaps [rsp+0xB0], xmm11
0000798fc6fd1b43  vmovaps [rsp+0xC0], xmm12
0000798fc6fd1b4c  vmovaps [rsp+0xD0], xmm13
0000798fc6fd1b55  vmovaps [rsp+0xE0], xmm15
0000798fc6fd1b5e  sub rsp, 0x30
0000798fc6fd1b62  movaps [rsp], xmm14
0000798fc6fd1b67  movaps [rsp+0x10], xmm13
0000798fc6fd1b6d  movaps [rsp+0x20], xmm1
0000798fc6fd1b72  lea rdi, [rsp]
0000798fc6fd1b76  mov esi, 0x00
0000798fc6fd1b7b  mov rax, 0x63E558B23530
0000798fc6fd1b85  call rax
0000798fc6fd1b87  movaps xmm14, [rsp]
0000798fc6fd1b8c  add rsp, 0x30
0000798fc6fd1b90  vmovaps xmm0, [rsp]
0000798fc6fd1b95  vmovaps xmm1, [rsp+0x10]
0000798fc6fd1b9b  vmovaps xmm2, [rsp+0x20]
0000798fc6fd1ba1  vmovaps xmm3, [rsp+0x30]
0000798fc6fd1ba7  vmovaps xmm4, [rsp+0x40]
0000798fc6fd1bad  vmovaps xmm5, [rsp+0x50]
0000798fc6fd1bb3  vmovaps xmm6, [rsp+0x60]
0000798fc6fd1bb9  vmovaps xmm7, [rsp+0x70]
0000798fc6fd1bbf  vmovaps xmm8, [rsp+0x80]
0000798fc6fd1bc8  vmovaps xmm9, [rsp+0x90]
0000798fc6fd1bd1  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd1bda  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd1be3  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd1bec  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd1bf5  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd1bfe  add rsp, 0xF0
0000798fc6fd1c05  pop r11
0000798fc6fd1c07  pop r10
0000798fc6fd1c09  pop r9
0000798fc6fd1c0b  pop r8
0000798fc6fd1c0d  pop rsi
0000798fc6fd1c0e  pop rdi
0000798fc6fd1c0f  pop rdx
0000798fc6fd1c10  pop rcx
0000798fc6fd1c11  pop rax
0000798fc6fd1c12  add rsp, 0x08
0000798fc6fd1c16  jmp 0x0000798FC6FCFAAF
0000798fc6fd1c1b  sub rsp, 0x08
0000798fc6fd1c1f  push rax
0000798fc6fd1c20  push rcx
0000798fc6fd1c21  push rdx
0000798fc6fd1c22  push rdi
0000798fc6fd1c23  push rsi
0000798fc6fd1c24  push r8
0000798fc6fd1c26  push r9
0000798fc6fd1c28  push r10
0000798fc6fd1c2a  push r11
0000798fc6fd1c2c  sub rsp, 0xF0
0000798fc6fd1c33  vmovaps [rsp], xmm0
0000798fc6fd1c38  vmovaps [rsp+0x10], xmm1
0000798fc6fd1c3e  vmovaps [rsp+0x20], xmm2
0000798fc6fd1c44  vmovaps [rsp+0x30], xmm3
0000798fc6fd1c4a  vmovaps [rsp+0x40], xmm4
0000798fc6fd1c50  vmovaps [rsp+0x50], xmm5
0000798fc6fd1c56  vmovaps [rsp+0x60], xmm6
0000798fc6fd1c5c  vmovaps [rsp+0x70], xmm7
0000798fc6fd1c62  vmovaps [rsp+0x80], xmm8
0000798fc6fd1c6b  vmovaps [rsp+0x90], xmm9
0000798fc6fd1c74  vmovaps [rsp+0xA0], xmm10
0000798fc6fd1c7d  vmovaps [rsp+0xB0], xmm11
0000798fc6fd1c86  vmovaps [rsp+0xC0], xmm12
0000798fc6fd1c8f  vmovaps [rsp+0xD0], xmm13
0000798fc6fd1c98  vmovaps [rsp+0xE0], xmm14
0000798fc6fd1ca1  sub rsp, 0x30
0000798fc6fd1ca5  movaps [rsp], xmm15
0000798fc6fd1caa  movaps [rsp+0x10], xmm13
0000798fc6fd1cb0  movaps [rsp+0x20], xmm1
0000798fc6fd1cb5  lea rdi, [rsp]
0000798fc6fd1cb9  mov esi, 0x00
0000798fc6fd1cbe  mov rax, 0x63E558B23530
0000798fc6fd1cc8  call rax
0000798fc6fd1cca  movaps xmm15, [rsp]
0000798fc6fd1ccf  add rsp, 0x30
0000798fc6fd1cd3  vmovaps xmm0, [rsp]
0000798fc6fd1cd8  vmovaps xmm1, [rsp+0x10]
0000798fc6fd1cde  vmovaps xmm2, [rsp+0x20]
0000798fc6fd1ce4  vmovaps xmm3, [rsp+0x30]
0000798fc6fd1cea  vmovaps xmm4, [rsp+0x40]
0000798fc6fd1cf0  vmovaps xmm5, [rsp+0x50]
0000798fc6fd1cf6  vmovaps xmm6, [rsp+0x60]
0000798fc6fd1cfc  vmovaps xmm7, [rsp+0x70]
0000798fc6fd1d02  vmovaps xmm8, [rsp+0x80]
0000798fc6fd1d0b  vmovaps xmm9, [rsp+0x90]
0000798fc6fd1d14  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd1d1d  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd1d26  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd1d2f  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd1d38  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd1d41  add rsp, 0xF0
0000798fc6fd1d48  pop r11
0000798fc6fd1d4a  pop r10
0000798fc6fd1d4c  pop r9
0000798fc6fd1d4e  pop r8
0000798fc6fd1d50  pop rsi
0000798fc6fd1d51  pop rdi
0000798fc6fd1d52  pop rdx
0000798fc6fd1d53  pop rcx
0000798fc6fd1d54  pop rax
0000798fc6fd1d55  add rsp, 0x08
0000798fc6fd1d59  jmp 0x0000798FC6FCFAEB
0000798fc6fd1d5e  call 0x0000798FC6DFF430
0000798fc6fd1d63  jmp 0x0000798FC6FCFAF8
0000798fc6fd1d68  sub rsp, 0x08
0000798fc6fd1d6c  push rax
0000798fc6fd1d6d  push rcx
0000798fc6fd1d6e  push rdx
0000798fc6fd1d6f  push rdi
0000798fc6fd1d70  push rsi
0000798fc6fd1d71  push r8
0000798fc6fd1d73  push r9
0000798fc6fd1d75  push r10
0000798fc6fd1d77  push r11
0000798fc6fd1d79  sub rsp, 0xF0
0000798fc6fd1d80  vmovaps [rsp], xmm0
0000798fc6fd1d85  vmovaps [rsp+0x10], xmm1
0000798fc6fd1d8b  vmovaps [rsp+0x20], xmm2
0000798fc6fd1d91  vmovaps [rsp+0x30], xmm3
0000798fc6fd1d97  vmovaps [rsp+0x40], xmm4
0000798fc6fd1d9d  vmovaps [rsp+0x50], xmm5
0000798fc6fd1da3  vmovaps [rsp+0x60], xmm6
0000798fc6fd1da9  vmovaps [rsp+0x70], xmm7
0000798fc6fd1daf  vmovaps [rsp+0x80], xmm8
0000798fc6fd1db8  vmovaps [rsp+0x90], xmm9
0000798fc6fd1dc1  vmovaps [rsp+0xA0], xmm10
0000798fc6fd1dca  vmovaps [rsp+0xB0], xmm11
0000798fc6fd1dd3  vmovaps [rsp+0xC0], xmm12
0000798fc6fd1ddc  vmovaps [rsp+0xD0], xmm13
0000798fc6fd1de5  vmovaps [rsp+0xE0], xmm15
0000798fc6fd1dee  sub rsp, 0x30
0000798fc6fd1df2  movaps [rsp], xmm14
0000798fc6fd1df7  movaps [rsp+0x10], xmm13
0000798fc6fd1dfd  movaps [rsp+0x20], xmm2
0000798fc6fd1e02  lea rdi, [rsp]
0000798fc6fd1e06  mov esi, 0x00
0000798fc6fd1e0b  mov rax, 0x63E558B23530
0000798fc6fd1e15  call rax
0000798fc6fd1e17  movaps xmm14, [rsp]
0000798fc6fd1e1c  add rsp, 0x30
0000798fc6fd1e20  vmovaps xmm0, [rsp]
0000798fc6fd1e25  vmovaps xmm1, [rsp+0x10]
0000798fc6fd1e2b  vmovaps xmm2, [rsp+0x20]
0000798fc6fd1e31  vmovaps xmm3, [rsp+0x30]
0000798fc6fd1e37  vmovaps xmm4, [rsp+0x40]
0000798fc6fd1e3d  vmovaps xmm5, [rsp+0x50]
0000798fc6fd1e43  vmovaps xmm6, [rsp+0x60]
0000798fc6fd1e49  vmovaps xmm7, [rsp+0x70]
0000798fc6fd1e4f  vmovaps xmm8, [rsp+0x80]
0000798fc6fd1e58  vmovaps xmm9, [rsp+0x90]
0000798fc6fd1e61  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd1e6a  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd1e73  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd1e7c  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd1e85  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd1e8e  add rsp, 0xF0
0000798fc6fd1e95  pop r11
0000798fc6fd1e97  pop r10
0000798fc6fd1e99  pop r9
0000798fc6fd1e9b  pop r8
0000798fc6fd1e9d  pop rsi
0000798fc6fd1e9e  pop rdi
0000798fc6fd1e9f  pop rdx
0000798fc6fd1ea0  pop rcx
0000798fc6fd1ea1  pop rax
0000798fc6fd1ea2  add rsp, 0x08
0000798fc6fd1ea6  jmp 0x0000798FC6FCFB24
0000798fc6fd1eab  sub rsp, 0x08
0000798fc6fd1eaf  push rax
0000798fc6fd1eb0  push rcx
0000798fc6fd1eb1  push rdx
0000798fc6fd1eb2  push rdi
0000798fc6fd1eb3  push rsi
0000798fc6fd1eb4  push r8
0000798fc6fd1eb6  push r9
0000798fc6fd1eb8  push r10
0000798fc6fd1eba  push r11
0000798fc6fd1ebc  sub rsp, 0xF0
0000798fc6fd1ec3  vmovaps [rsp], xmm0
0000798fc6fd1ec8  vmovaps [rsp+0x10], xmm2
0000798fc6fd1ece  vmovaps [rsp+0x20], xmm3
0000798fc6fd1ed4  vmovaps [rsp+0x30], xmm4
0000798fc6fd1eda  vmovaps [rsp+0x40], xmm5
0000798fc6fd1ee0  vmovaps [rsp+0x50], xmm6
0000798fc6fd1ee6  vmovaps [rsp+0x60], xmm7
0000798fc6fd1eec  vmovaps [rsp+0x70], xmm8
0000798fc6fd1ef2  vmovaps [rsp+0x80], xmm9
0000798fc6fd1efb  vmovaps [rsp+0x90], xmm10
0000798fc6fd1f04  vmovaps [rsp+0xA0], xmm11
0000798fc6fd1f0d  vmovaps [rsp+0xB0], xmm12
0000798fc6fd1f16  vmovaps [rsp+0xC0], xmm13
0000798fc6fd1f1f  vmovaps [rsp+0xD0], xmm14
0000798fc6fd1f28  vmovaps [rsp+0xE0], xmm15
0000798fc6fd1f31  sub rsp, 0x30
0000798fc6fd1f35  movaps [rsp], xmm1
0000798fc6fd1f39  movaps [rsp+0x10], xmm13
0000798fc6fd1f3f  movaps [rsp+0x20], xmm2
0000798fc6fd1f44  lea rdi, [rsp]
0000798fc6fd1f48  mov esi, 0x00
0000798fc6fd1f4d  mov rax, 0x63E558B23530
0000798fc6fd1f57  call rax
0000798fc6fd1f59  movaps xmm1, [rsp]
0000798fc6fd1f5d  add rsp, 0x30
0000798fc6fd1f61  vmovaps xmm0, [rsp]
0000798fc6fd1f66  vmovaps xmm2, [rsp+0x10]
0000798fc6fd1f6c  vmovaps xmm3, [rsp+0x20]
0000798fc6fd1f72  vmovaps xmm4, [rsp+0x30]
0000798fc6fd1f78  vmovaps xmm5, [rsp+0x40]
0000798fc6fd1f7e  vmovaps xmm6, [rsp+0x50]
0000798fc6fd1f84  vmovaps xmm7, [rsp+0x60]
0000798fc6fd1f8a  vmovaps xmm8, [rsp+0x70]
0000798fc6fd1f90  vmovaps xmm9, [rsp+0x80]
0000798fc6fd1f99  vmovaps xmm10, [rsp+0x90]
0000798fc6fd1fa2  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd1fab  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd1fb4  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd1fbd  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd1fc6  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd1fcf  add rsp, 0xF0
0000798fc6fd1fd6  pop r11
0000798fc6fd1fd8  pop r10
0000798fc6fd1fda  pop r9
0000798fc6fd1fdc  pop r8
0000798fc6fd1fde  pop rsi
0000798fc6fd1fdf  pop rdi
0000798fc6fd1fe0  pop rdx
0000798fc6fd1fe1  pop rcx
0000798fc6fd1fe2  pop rax
0000798fc6fd1fe3  add rsp, 0x08
0000798fc6fd1fe7  jmp 0x0000798FC6FCFB52
0000798fc6fd1fec  sub rsp, 0x08
0000798fc6fd1ff0  push rax
0000798fc6fd1ff1  push rcx
0000798fc6fd1ff2  push rdx
0000798fc6fd1ff3  push rdi
0000798fc6fd1ff4  push rsi
0000798fc6fd1ff5  push r8
0000798fc6fd1ff7  push r9
0000798fc6fd1ff9  push r10
0000798fc6fd1ffb  push r11
0000798fc6fd1ffd  sub rsp, 0xF0
0000798fc6fd2004  vmovaps [rsp], xmm0
0000798fc6fd2009  vmovaps [rsp+0x10], xmm1
0000798fc6fd200f  vmovaps [rsp+0x20], xmm3
0000798fc6fd2015  vmovaps [rsp+0x30], xmm4
0000798fc6fd201b  vmovaps [rsp+0x40], xmm5
0000798fc6fd2021  vmovaps [rsp+0x50], xmm6
0000798fc6fd2027  vmovaps [rsp+0x60], xmm7
0000798fc6fd202d  vmovaps [rsp+0x70], xmm8
0000798fc6fd2033  vmovaps [rsp+0x80], xmm9
0000798fc6fd203c  vmovaps [rsp+0x90], xmm10
0000798fc6fd2045  vmovaps [rsp+0xA0], xmm11
0000798fc6fd204e  vmovaps [rsp+0xB0], xmm12
0000798fc6fd2057  vmovaps [rsp+0xC0], xmm13
0000798fc6fd2060  vmovaps [rsp+0xD0], xmm14
0000798fc6fd2069  vmovaps [rsp+0xE0], xmm15
0000798fc6fd2072  sub rsp, 0x30
0000798fc6fd2076  movaps [rsp], xmm2
0000798fc6fd207a  movaps [rsp+0x10], xmm1
0000798fc6fd207f  movaps [rsp+0x20], xmm13
0000798fc6fd2085  lea rdi, [rsp]
0000798fc6fd2089  mov esi, 0x00
0000798fc6fd208e  mov rax, 0x63E558B23530
0000798fc6fd2098  call rax
0000798fc6fd209a  movaps xmm2, [rsp]
0000798fc6fd209e  add rsp, 0x30
0000798fc6fd20a2  vmovaps xmm0, [rsp]
0000798fc6fd20a7  vmovaps xmm1, [rsp+0x10]
0000798fc6fd20ad  vmovaps xmm3, [rsp+0x20]
0000798fc6fd20b3  vmovaps xmm4, [rsp+0x30]
0000798fc6fd20b9  vmovaps xmm5, [rsp+0x40]
0000798fc6fd20bf  vmovaps xmm6, [rsp+0x50]
0000798fc6fd20c5  vmovaps xmm7, [rsp+0x60]
0000798fc6fd20cb  vmovaps xmm8, [rsp+0x70]
0000798fc6fd20d1  vmovaps xmm9, [rsp+0x80]
0000798fc6fd20da  vmovaps xmm10, [rsp+0x90]
0000798fc6fd20e3  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd20ec  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd20f5  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd20fe  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd2107  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd2110  add rsp, 0xF0
0000798fc6fd2117  pop r11
0000798fc6fd2119  pop r10
0000798fc6fd211b  pop r9
0000798fc6fd211d  pop r8
0000798fc6fd211f  pop rsi
0000798fc6fd2120  pop rdi
0000798fc6fd2121  pop rdx
0000798fc6fd2122  pop rcx
0000798fc6fd2123  pop rax
0000798fc6fd2124  add rsp, 0x08
0000798fc6fd2128  jmp 0x0000798FC6FCFBAB
0000798fc6fd212d  call 0x0000798FC6DFF430
0000798fc6fd2132  jmp 0x0000798FC6FCFBB8
0000798fc6fd2137  sub rsp, 0x08
0000798fc6fd213b  push rax
0000798fc6fd213c  push rcx
0000798fc6fd213d  push rdx
0000798fc6fd213e  push rdi
0000798fc6fd213f  push rsi
0000798fc6fd2140  push r8
0000798fc6fd2142  push r9
0000798fc6fd2144  push r10
0000798fc6fd2146  push r11
0000798fc6fd2148  sub rsp, 0xF0
0000798fc6fd214f  vmovaps [rsp], xmm0
0000798fc6fd2154  vmovaps [rsp+0x10], xmm1
0000798fc6fd215a  vmovaps [rsp+0x20], xmm2
0000798fc6fd2160  vmovaps [rsp+0x30], xmm3
0000798fc6fd2166  vmovaps [rsp+0x40], xmm4
0000798fc6fd216c  vmovaps [rsp+0x50], xmm5
0000798fc6fd2172  vmovaps [rsp+0x60], xmm6
0000798fc6fd2178  vmovaps [rsp+0x70], xmm7
0000798fc6fd217e  vmovaps [rsp+0x80], xmm8
0000798fc6fd2187  vmovaps [rsp+0x90], xmm9
0000798fc6fd2190  vmovaps [rsp+0xA0], xmm10
0000798fc6fd2199  vmovaps [rsp+0xB0], xmm11
0000798fc6fd21a2  vmovaps [rsp+0xC0], xmm12
0000798fc6fd21ab  vmovaps [rsp+0xD0], xmm13
0000798fc6fd21b4  vmovaps [rsp+0xE0], xmm14
0000798fc6fd21bd  sub rsp, 0x30
0000798fc6fd21c1  movaps [rsp], xmm15
0000798fc6fd21c6  movaps [rsp+0x10], xmm13
0000798fc6fd21cc  movaps [rsp+0x20], xmm1
0000798fc6fd21d1  lea rdi, [rsp]
0000798fc6fd21d5  mov esi, 0x00
0000798fc6fd21da  mov rax, 0x63E558B23530
0000798fc6fd21e4  call rax
0000798fc6fd21e6  movaps xmm15, [rsp]
0000798fc6fd21eb  add rsp, 0x30
0000798fc6fd21ef  vmovaps xmm0, [rsp]
0000798fc6fd21f4  vmovaps xmm1, [rsp+0x10]
0000798fc6fd21fa  vmovaps xmm2, [rsp+0x20]
0000798fc6fd2200  vmovaps xmm3, [rsp+0x30]
0000798fc6fd2206  vmovaps xmm4, [rsp+0x40]
0000798fc6fd220c  vmovaps xmm5, [rsp+0x50]
0000798fc6fd2212  vmovaps xmm6, [rsp+0x60]
0000798fc6fd2218  vmovaps xmm7, [rsp+0x70]
0000798fc6fd221e  vmovaps xmm8, [rsp+0x80]
0000798fc6fd2227  vmovaps xmm9, [rsp+0x90]
0000798fc6fd2230  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd2239  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd2242  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd224b  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd2254  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd225d  add rsp, 0xF0
0000798fc6fd2264  pop r11
0000798fc6fd2266  pop r10
0000798fc6fd2268  pop r9
0000798fc6fd226a  pop r8
0000798fc6fd226c  pop rsi
0000798fc6fd226d  pop rdi
0000798fc6fd226e  pop rdx
0000798fc6fd226f  pop rcx
0000798fc6fd2270  pop rax
0000798fc6fd2271  add rsp, 0x08
0000798fc6fd2275  jmp 0x0000798FC6FCFBF7
0000798fc6fd227a  sub rsp, 0x08
0000798fc6fd227e  push rax
0000798fc6fd227f  push rcx
0000798fc6fd2280  push rdx
0000798fc6fd2281  push rdi
0000798fc6fd2282  push rsi
0000798fc6fd2283  push r8
0000798fc6fd2285  push r9
0000798fc6fd2287  push r10
0000798fc6fd2289  push r11
0000798fc6fd228b  sub rsp, 0xF0
0000798fc6fd2292  vmovaps [rsp], xmm0
0000798fc6fd2297  vmovaps [rsp+0x10], xmm1
0000798fc6fd229d  vmovaps [rsp+0x20], xmm2
0000798fc6fd22a3  vmovaps [rsp+0x30], xmm3
0000798fc6fd22a9  vmovaps [rsp+0x40], xmm4
0000798fc6fd22af  vmovaps [rsp+0x50], xmm5
0000798fc6fd22b5  vmovaps [rsp+0x60], xmm6
0000798fc6fd22bb  vmovaps [rsp+0x70], xmm7
0000798fc6fd22c1  vmovaps [rsp+0x80], xmm8
0000798fc6fd22ca  vmovaps [rsp+0x90], xmm9
0000798fc6fd22d3  vmovaps [rsp+0xA0], xmm10
0000798fc6fd22dc  vmovaps [rsp+0xB0], xmm11
0000798fc6fd22e5  vmovaps [rsp+0xC0], xmm12
0000798fc6fd22ee  vmovaps [rsp+0xD0], xmm13
0000798fc6fd22f7  vmovaps [rsp+0xE0], xmm15
0000798fc6fd2300  sub rsp, 0x30
0000798fc6fd2304  movaps [rsp], xmm14
0000798fc6fd2309  movaps [rsp+0x10], xmm11
0000798fc6fd230f  movaps [rsp+0x20], xmm1
0000798fc6fd2314  lea rdi, [rsp]
0000798fc6fd2318  mov esi, 0x00
0000798fc6fd231d  mov rax, 0x63E558B23530
0000798fc6fd2327  call rax
0000798fc6fd2329  movaps xmm14, [rsp]
0000798fc6fd232e  add rsp, 0x30
0000798fc6fd2332  vmovaps xmm0, [rsp]
0000798fc6fd2337  vmovaps xmm1, [rsp+0x10]
0000798fc6fd233d  vmovaps xmm2, [rsp+0x20]
0000798fc6fd2343  vmovaps xmm3, [rsp+0x30]
0000798fc6fd2349  vmovaps xmm4, [rsp+0x40]
0000798fc6fd234f  vmovaps xmm5, [rsp+0x50]
0000798fc6fd2355  vmovaps xmm6, [rsp+0x60]
0000798fc6fd235b  vmovaps xmm7, [rsp+0x70]
0000798fc6fd2361  vmovaps xmm8, [rsp+0x80]
0000798fc6fd236a  vmovaps xmm9, [rsp+0x90]
0000798fc6fd2373  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd237c  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd2385  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd238e  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd2397  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd23a0  add rsp, 0xF0
0000798fc6fd23a7  pop r11
0000798fc6fd23a9  pop r10
0000798fc6fd23ab  pop r9
0000798fc6fd23ad  pop r8
0000798fc6fd23af  pop rsi
0000798fc6fd23b0  pop rdi
0000798fc6fd23b1  pop rdx
0000798fc6fd23b2  pop rcx
0000798fc6fd23b3  pop rax
0000798fc6fd23b4  add rsp, 0x08
0000798fc6fd23b8  jmp 0x0000798FC6FCFC21
0000798fc6fd23bd  sub rsp, 0x08
0000798fc6fd23c1  push rax
0000798fc6fd23c2  push rcx
0000798fc6fd23c3  push rdx
0000798fc6fd23c4  push rdi
0000798fc6fd23c5  push rsi
0000798fc6fd23c6  push r8
0000798fc6fd23c8  push r9
0000798fc6fd23ca  push r10
0000798fc6fd23cc  push r11
0000798fc6fd23ce  sub rsp, 0xF0
0000798fc6fd23d5  vmovaps [rsp], xmm0
0000798fc6fd23da  vmovaps [rsp+0x10], xmm1
0000798fc6fd23e0  vmovaps [rsp+0x20], xmm2
0000798fc6fd23e6  vmovaps [rsp+0x30], xmm3
0000798fc6fd23ec  vmovaps [rsp+0x40], xmm4
0000798fc6fd23f2  vmovaps [rsp+0x50], xmm5
0000798fc6fd23f8  vmovaps [rsp+0x60], xmm6
0000798fc6fd23fe  vmovaps [rsp+0x70], xmm7
0000798fc6fd2404  vmovaps [rsp+0x80], xmm8
0000798fc6fd240d  vmovaps [rsp+0x90], xmm9
0000798fc6fd2416  vmovaps [rsp+0xA0], xmm10
0000798fc6fd241f  vmovaps [rsp+0xB0], xmm11
0000798fc6fd2428  vmovaps [rsp+0xC0], xmm12
0000798fc6fd2431  vmovaps [rsp+0xD0], xmm14
0000798fc6fd243a  vmovaps [rsp+0xE0], xmm15
0000798fc6fd2443  sub rsp, 0x30
0000798fc6fd2447  movaps [rsp], xmm13
0000798fc6fd244c  movaps [rsp+0x10], xmm11
0000798fc6fd2452  movaps [rsp+0x20], xmm1
0000798fc6fd2457  lea rdi, [rsp]
0000798fc6fd245b  mov esi, 0x00
0000798fc6fd2460  mov rax, 0x63E558B23530
0000798fc6fd246a  call rax
0000798fc6fd246c  movaps xmm13, [rsp]
0000798fc6fd2471  add rsp, 0x30
0000798fc6fd2475  vmovaps xmm0, [rsp]
0000798fc6fd247a  vmovaps xmm1, [rsp+0x10]
0000798fc6fd2480  vmovaps xmm2, [rsp+0x20]
0000798fc6fd2486  vmovaps xmm3, [rsp+0x30]
0000798fc6fd248c  vmovaps xmm4, [rsp+0x40]
0000798fc6fd2492  vmovaps xmm5, [rsp+0x50]
0000798fc6fd2498  vmovaps xmm6, [rsp+0x60]
0000798fc6fd249e  vmovaps xmm7, [rsp+0x70]
0000798fc6fd24a4  vmovaps xmm8, [rsp+0x80]
0000798fc6fd24ad  vmovaps xmm9, [rsp+0x90]
0000798fc6fd24b6  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd24bf  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd24c8  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd24d1  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd24da  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd24e3  add rsp, 0xF0
0000798fc6fd24ea  pop r11
0000798fc6fd24ec  pop r10
0000798fc6fd24ee  pop r9
0000798fc6fd24f0  pop r8
0000798fc6fd24f2  pop rsi
0000798fc6fd24f3  pop rdi
0000798fc6fd24f4  pop rdx
0000798fc6fd24f5  pop rcx
0000798fc6fd24f6  pop rax
0000798fc6fd24f7  add rsp, 0x08
0000798fc6fd24fb  jmp 0x0000798FC6FCFC76
0000798fc6fd2500  call 0x0000798FC6DFF430
0000798fc6fd2505  jmp 0x0000798FC6FCFC83
0000798fc6fd250a  sub rsp, 0x08
0000798fc6fd250e  push rax
0000798fc6fd250f  push rcx
0000798fc6fd2510  push rdx
0000798fc6fd2511  push rdi
0000798fc6fd2512  push rsi
0000798fc6fd2513  push r8
0000798fc6fd2515  push r9
0000798fc6fd2517  push r10
0000798fc6fd2519  push r11
0000798fc6fd251b  sub rsp, 0xF0
0000798fc6fd2522  vmovaps [rsp], xmm0
0000798fc6fd2527  vmovaps [rsp+0x10], xmm1
0000798fc6fd252d  vmovaps [rsp+0x20], xmm2
0000798fc6fd2533  vmovaps [rsp+0x30], xmm3
0000798fc6fd2539  vmovaps [rsp+0x40], xmm4
0000798fc6fd253f  vmovaps [rsp+0x50], xmm5
0000798fc6fd2545  vmovaps [rsp+0x60], xmm6
0000798fc6fd254b  vmovaps [rsp+0x70], xmm7
0000798fc6fd2551  vmovaps [rsp+0x80], xmm8
0000798fc6fd255a  vmovaps [rsp+0x90], xmm9
0000798fc6fd2563  vmovaps [rsp+0xA0], xmm10
0000798fc6fd256c  vmovaps [rsp+0xB0], xmm11
0000798fc6fd2575  vmovaps [rsp+0xC0], xmm12
0000798fc6fd257e  vmovaps [rsp+0xD0], xmm13
0000798fc6fd2587  vmovaps [rsp+0xE0], xmm14
0000798fc6fd2590  sub rsp, 0x30
0000798fc6fd2594  movaps [rsp], xmm15
0000798fc6fd2599  movaps [rsp+0x10], xmm11
0000798fc6fd259f  movaps [rsp+0x20], xmm1
0000798fc6fd25a4  lea rdi, [rsp]
0000798fc6fd25a8  mov esi, 0x00
0000798fc6fd25ad  mov rax, 0x63E558B23530
0000798fc6fd25b7  call rax
0000798fc6fd25b9  movaps xmm15, [rsp]
0000798fc6fd25be  add rsp, 0x30
0000798fc6fd25c2  vmovaps xmm0, [rsp]
0000798fc6fd25c7  vmovaps xmm1, [rsp+0x10]
0000798fc6fd25cd  vmovaps xmm2, [rsp+0x20]
0000798fc6fd25d3  vmovaps xmm3, [rsp+0x30]
0000798fc6fd25d9  vmovaps xmm4, [rsp+0x40]
0000798fc6fd25df  vmovaps xmm5, [rsp+0x50]
0000798fc6fd25e5  vmovaps xmm6, [rsp+0x60]
0000798fc6fd25eb  vmovaps xmm7, [rsp+0x70]
0000798fc6fd25f1  vmovaps xmm8, [rsp+0x80]
0000798fc6fd25fa  vmovaps xmm9, [rsp+0x90]
0000798fc6fd2603  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd260c  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd2615  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd261e  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd2627  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd2630  add rsp, 0xF0
0000798fc6fd2637  pop r11
0000798fc6fd2639  pop r10
0000798fc6fd263b  pop r9
0000798fc6fd263d  pop r8
0000798fc6fd263f  pop rsi
0000798fc6fd2640  pop rdi
0000798fc6fd2641  pop rdx
0000798fc6fd2642  pop rcx
0000798fc6fd2643  pop rax
0000798fc6fd2644  add rsp, 0x08
0000798fc6fd2648  jmp 0x0000798FC6FCFCBC
0000798fc6fd264d  sub rsp, 0x08
0000798fc6fd2651  push rax
0000798fc6fd2652  push rcx
0000798fc6fd2653  push rdx
0000798fc6fd2654  push rdi
0000798fc6fd2655  push rsi
0000798fc6fd2656  push r8
0000798fc6fd2658  push r9
0000798fc6fd265a  push r10
0000798fc6fd265c  push r11
0000798fc6fd265e  sub rsp, 0xF0
0000798fc6fd2665  vmovaps [rsp], xmm0
0000798fc6fd266a  vmovaps [rsp+0x10], xmm1
0000798fc6fd2670  vmovaps [rsp+0x20], xmm2
0000798fc6fd2676  vmovaps [rsp+0x30], xmm3
0000798fc6fd267c  vmovaps [rsp+0x40], xmm4
0000798fc6fd2682  vmovaps [rsp+0x50], xmm5
0000798fc6fd2688  vmovaps [rsp+0x60], xmm6
0000798fc6fd268e  vmovaps [rsp+0x70], xmm7
0000798fc6fd2694  vmovaps [rsp+0x80], xmm8
0000798fc6fd269d  vmovaps [rsp+0x90], xmm9
0000798fc6fd26a6  vmovaps [rsp+0xA0], xmm10
0000798fc6fd26af  vmovaps [rsp+0xB0], xmm12
0000798fc6fd26b8  vmovaps [rsp+0xC0], xmm13
0000798fc6fd26c1  vmovaps [rsp+0xD0], xmm14
0000798fc6fd26ca  vmovaps [rsp+0xE0], xmm15
0000798fc6fd26d3  sub rsp, 0x30
0000798fc6fd26d7  movaps [rsp], xmm11
0000798fc6fd26dc  movaps [rsp+0x10], xmm6
0000798fc6fd26e1  movaps [rsp+0x20], xmm14
0000798fc6fd26e7  lea rdi, [rsp]
0000798fc6fd26eb  mov esi, 0x00
0000798fc6fd26f0  mov rax, 0x63E558B23530
0000798fc6fd26fa  call rax
0000798fc6fd26fc  movaps xmm11, [rsp]
0000798fc6fd2701  add rsp, 0x30
0000798fc6fd2705  vmovaps xmm0, [rsp]
0000798fc6fd270a  vmovaps xmm1, [rsp+0x10]
0000798fc6fd2710  vmovaps xmm2, [rsp+0x20]
0000798fc6fd2716  vmovaps xmm3, [rsp+0x30]
0000798fc6fd271c  vmovaps xmm4, [rsp+0x40]
0000798fc6fd2722  vmovaps xmm5, [rsp+0x50]
0000798fc6fd2728  vmovaps xmm6, [rsp+0x60]
0000798fc6fd272e  vmovaps xmm7, [rsp+0x70]
0000798fc6fd2734  vmovaps xmm8, [rsp+0x80]
0000798fc6fd273d  vmovaps xmm9, [rsp+0x90]
0000798fc6fd2746  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd274f  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd2758  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd2761  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd276a  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd2773  add rsp, 0xF0
0000798fc6fd277a  pop r11
0000798fc6fd277c  pop r10
0000798fc6fd277e  pop r9
0000798fc6fd2780  pop r8
0000798fc6fd2782  pop rsi
0000798fc6fd2783  pop rdi
0000798fc6fd2784  pop rdx
0000798fc6fd2785  pop rcx
0000798fc6fd2786  pop rax
0000798fc6fd2787  add rsp, 0x08
0000798fc6fd278b  jmp 0x0000798FC6FCFD34
0000798fc6fd2790  call 0x0000798FC6DFF430
0000798fc6fd2795  jmp 0x0000798FC6FCFD3E
0000798fc6fd279a  sub rsp, 0x08
0000798fc6fd279e  push rax
0000798fc6fd279f  push rcx
0000798fc6fd27a0  push rdx
0000798fc6fd27a1  push rdi
0000798fc6fd27a2  push rsi
0000798fc6fd27a3  push r8
0000798fc6fd27a5  push r9
0000798fc6fd27a7  push r10
0000798fc6fd27a9  push r11
0000798fc6fd27ab  sub rsp, 0xF0
0000798fc6fd27b2  vmovaps [rsp], xmm0
0000798fc6fd27b7  vmovaps [rsp+0x10], xmm1
0000798fc6fd27bd  vmovaps [rsp+0x20], xmm2
0000798fc6fd27c3  vmovaps [rsp+0x30], xmm3
0000798fc6fd27c9  vmovaps [rsp+0x40], xmm4
0000798fc6fd27cf  vmovaps [rsp+0x50], xmm5
0000798fc6fd27d5  vmovaps [rsp+0x60], xmm6
0000798fc6fd27db  vmovaps [rsp+0x70], xmm7
0000798fc6fd27e1  vmovaps [rsp+0x80], xmm8
0000798fc6fd27ea  vmovaps [rsp+0x90], xmm9
0000798fc6fd27f3  vmovaps [rsp+0xA0], xmm10
0000798fc6fd27fc  vmovaps [rsp+0xB0], xmm11
0000798fc6fd2805  vmovaps [rsp+0xC0], xmm12
0000798fc6fd280e  vmovaps [rsp+0xD0], xmm13
0000798fc6fd2817  vmovaps [rsp+0xE0], xmm15
0000798fc6fd2820  sub rsp, 0x30
0000798fc6fd2824  movaps [rsp], xmm14
0000798fc6fd2829  movaps [rsp+0x10], xmm6
0000798fc6fd282e  movaps [rsp+0x20], xmm2
0000798fc6fd2833  lea rdi, [rsp]
0000798fc6fd2837  mov esi, 0x00
0000798fc6fd283c  mov rax, 0x63E558B23530
0000798fc6fd2846  call rax
0000798fc6fd2848  movaps xmm14, [rsp]
0000798fc6fd284d  add rsp, 0x30
0000798fc6fd2851  vmovaps xmm0, [rsp]
0000798fc6fd2856  vmovaps xmm1, [rsp+0x10]
0000798fc6fd285c  vmovaps xmm2, [rsp+0x20]
0000798fc6fd2862  vmovaps xmm3, [rsp+0x30]
0000798fc6fd2868  vmovaps xmm4, [rsp+0x40]
0000798fc6fd286e  vmovaps xmm5, [rsp+0x50]
0000798fc6fd2874  vmovaps xmm6, [rsp+0x60]
0000798fc6fd287a  vmovaps xmm7, [rsp+0x70]
0000798fc6fd2880  vmovaps xmm8, [rsp+0x80]
0000798fc6fd2889  vmovaps xmm9, [rsp+0x90]
0000798fc6fd2892  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd289b  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd28a4  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd28ad  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd28b6  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd28bf  add rsp, 0xF0
0000798fc6fd28c6  pop r11
0000798fc6fd28c8  pop r10
0000798fc6fd28ca  pop r9
0000798fc6fd28cc  pop r8
0000798fc6fd28ce  pop rsi
0000798fc6fd28cf  pop rdi
0000798fc6fd28d0  pop rdx
0000798fc6fd28d1  pop rcx
0000798fc6fd28d2  pop rax
0000798fc6fd28d3  add rsp, 0x08
0000798fc6fd28d7  jmp 0x0000798FC6FCFD72
0000798fc6fd28dc  sub rsp, 0x08
0000798fc6fd28e0  push rax
0000798fc6fd28e1  push rcx
0000798fc6fd28e2  push rdx
0000798fc6fd28e3  push rdi
0000798fc6fd28e4  push rsi
0000798fc6fd28e5  push r8
0000798fc6fd28e7  push r9
0000798fc6fd28e9  push r10
0000798fc6fd28eb  push r11
0000798fc6fd28ed  sub rsp, 0xF0
0000798fc6fd28f4  vmovaps [rsp], xmm0
0000798fc6fd28f9  vmovaps [rsp+0x10], xmm1
0000798fc6fd28ff  vmovaps [rsp+0x20], xmm2
0000798fc6fd2905  vmovaps [rsp+0x30], xmm3
0000798fc6fd290b  vmovaps [rsp+0x40], xmm4
0000798fc6fd2911  vmovaps [rsp+0x50], xmm5
0000798fc6fd2917  vmovaps [rsp+0x60], xmm7
0000798fc6fd291d  vmovaps [rsp+0x70], xmm8
0000798fc6fd2923  vmovaps [rsp+0x80], xmm9
0000798fc6fd292c  vmovaps [rsp+0x90], xmm10
0000798fc6fd2935  vmovaps [rsp+0xA0], xmm11
0000798fc6fd293e  vmovaps [rsp+0xB0], xmm12
0000798fc6fd2947  vmovaps [rsp+0xC0], xmm13
0000798fc6fd2950  vmovaps [rsp+0xD0], xmm14
0000798fc6fd2959  vmovaps [rsp+0xE0], xmm15
0000798fc6fd2962  sub rsp, 0x30
0000798fc6fd2966  movaps [rsp], xmm6
0000798fc6fd296a  movaps [rsp+0x10], xmm5
0000798fc6fd296f  movaps [rsp+0x20], xmm1
0000798fc6fd2974  lea rdi, [rsp]
0000798fc6fd2978  mov esi, 0x00
0000798fc6fd297d  mov rax, 0x63E558B23530
0000798fc6fd2987  call rax
0000798fc6fd2989  movaps xmm6, [rsp]
0000798fc6fd298d  add rsp, 0x30
0000798fc6fd2991  vmovaps xmm0, [rsp]
0000798fc6fd2996  vmovaps xmm1, [rsp+0x10]
0000798fc6fd299c  vmovaps xmm2, [rsp+0x20]
0000798fc6fd29a2  vmovaps xmm3, [rsp+0x30]
0000798fc6fd29a8  vmovaps xmm4, [rsp+0x40]
0000798fc6fd29ae  vmovaps xmm5, [rsp+0x50]
0000798fc6fd29b4  vmovaps xmm7, [rsp+0x60]
0000798fc6fd29ba  vmovaps xmm8, [rsp+0x70]
0000798fc6fd29c0  vmovaps xmm9, [rsp+0x80]
0000798fc6fd29c9  vmovaps xmm10, [rsp+0x90]
0000798fc6fd29d2  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd29db  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd29e4  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd29ed  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd29f6  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd29ff  add rsp, 0xF0
0000798fc6fd2a06  pop r11
0000798fc6fd2a08  pop r10
0000798fc6fd2a0a  pop r9
0000798fc6fd2a0c  pop r8
0000798fc6fd2a0e  pop rsi
0000798fc6fd2a0f  pop rdi
0000798fc6fd2a10  pop rdx
0000798fc6fd2a11  pop rcx
0000798fc6fd2a12  pop rax
0000798fc6fd2a13  add rsp, 0x08
0000798fc6fd2a17  jmp 0x0000798FC6FCFD98
0000798fc6fd2a1c  sub rsp, 0x08
0000798fc6fd2a20  push rax
0000798fc6fd2a21  push rcx
0000798fc6fd2a22  push rdx
0000798fc6fd2a23  push rdi
0000798fc6fd2a24  push rsi
0000798fc6fd2a25  push r8
0000798fc6fd2a27  push r9
0000798fc6fd2a29  push r10
0000798fc6fd2a2b  push r11
0000798fc6fd2a2d  sub rsp, 0xF0
0000798fc6fd2a34  vmovaps [rsp], xmm0
0000798fc6fd2a39  vmovaps [rsp+0x10], xmm2
0000798fc6fd2a3f  vmovaps [rsp+0x20], xmm3
0000798fc6fd2a45  vmovaps [rsp+0x30], xmm4
0000798fc6fd2a4b  vmovaps [rsp+0x40], xmm5
0000798fc6fd2a51  vmovaps [rsp+0x50], xmm6
0000798fc6fd2a57  vmovaps [rsp+0x60], xmm7
0000798fc6fd2a5d  vmovaps [rsp+0x70], xmm8
0000798fc6fd2a63  vmovaps [rsp+0x80], xmm9
0000798fc6fd2a6c  vmovaps [rsp+0x90], xmm10
0000798fc6fd2a75  vmovaps [rsp+0xA0], xmm11
0000798fc6fd2a7e  vmovaps [rsp+0xB0], xmm12
0000798fc6fd2a87  vmovaps [rsp+0xC0], xmm13
0000798fc6fd2a90  vmovaps [rsp+0xD0], xmm14
0000798fc6fd2a99  vmovaps [rsp+0xE0], xmm15
0000798fc6fd2aa2  sub rsp, 0x30
0000798fc6fd2aa6  movaps [rsp], xmm1
0000798fc6fd2aaa  movaps [rsp+0x10], xmm5
0000798fc6fd2aaf  movaps [rsp+0x20], xmm13
0000798fc6fd2ab5  lea rdi, [rsp]
0000798fc6fd2ab9  mov esi, 0x00
0000798fc6fd2abe  mov rax, 0x63E558B23530
0000798fc6fd2ac8  call rax
0000798fc6fd2aca  movaps xmm1, [rsp]
0000798fc6fd2ace  add rsp, 0x30
0000798fc6fd2ad2  vmovaps xmm0, [rsp]
0000798fc6fd2ad7  vmovaps xmm2, [rsp+0x10]
0000798fc6fd2add  vmovaps xmm3, [rsp+0x20]
0000798fc6fd2ae3  vmovaps xmm4, [rsp+0x30]
0000798fc6fd2ae9  vmovaps xmm5, [rsp+0x40]
0000798fc6fd2aef  vmovaps xmm6, [rsp+0x50]
0000798fc6fd2af5  vmovaps xmm7, [rsp+0x60]
0000798fc6fd2afb  vmovaps xmm8, [rsp+0x70]
0000798fc6fd2b01  vmovaps xmm9, [rsp+0x80]
0000798fc6fd2b0a  vmovaps xmm10, [rsp+0x90]
0000798fc6fd2b13  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd2b1c  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd2b25  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd2b2e  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd2b37  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd2b40  add rsp, 0xF0
0000798fc6fd2b47  pop r11
0000798fc6fd2b49  pop r10
0000798fc6fd2b4b  pop r9
0000798fc6fd2b4d  pop r8
0000798fc6fd2b4f  pop rsi
0000798fc6fd2b50  pop rdi
0000798fc6fd2b51  pop rdx
0000798fc6fd2b52  pop rcx
0000798fc6fd2b53  pop rax
0000798fc6fd2b54  add rsp, 0x08
0000798fc6fd2b58  jmp 0x0000798FC6FCFDB6
0000798fc6fd2b5d  sub rsp, 0x08
0000798fc6fd2b61  push rax
0000798fc6fd2b62  push rcx
0000798fc6fd2b63  push rdx
0000798fc6fd2b64  push rdi
0000798fc6fd2b65  push rsi
0000798fc6fd2b66  push r8
0000798fc6fd2b68  push r9
0000798fc6fd2b6a  push r10
0000798fc6fd2b6c  push r11
0000798fc6fd2b6e  sub rsp, 0xF0
0000798fc6fd2b75  vmovaps [rsp], xmm0
0000798fc6fd2b7a  vmovaps [rsp+0x10], xmm1
0000798fc6fd2b80  vmovaps [rsp+0x20], xmm2
0000798fc6fd2b86  vmovaps [rsp+0x30], xmm3
0000798fc6fd2b8c  vmovaps [rsp+0x40], xmm4
0000798fc6fd2b92  vmovaps [rsp+0x50], xmm6
0000798fc6fd2b98  vmovaps [rsp+0x60], xmm7
0000798fc6fd2b9e  vmovaps [rsp+0x70], xmm8
0000798fc6fd2ba4  vmovaps [rsp+0x80], xmm9
0000798fc6fd2bad  vmovaps [rsp+0x90], xmm10
0000798fc6fd2bb6  vmovaps [rsp+0xA0], xmm11
0000798fc6fd2bbf  vmovaps [rsp+0xB0], xmm12
0000798fc6fd2bc8  vmovaps [rsp+0xC0], xmm13
0000798fc6fd2bd1  vmovaps [rsp+0xD0], xmm14
0000798fc6fd2bda  vmovaps [rsp+0xE0], xmm15
0000798fc6fd2be3  sub rsp, 0x30
0000798fc6fd2be7  movaps [rsp], xmm5
0000798fc6fd2beb  movaps [rsp+0x10], xmm2
0000798fc6fd2bf0  movaps [rsp+0x20], xmm13
0000798fc6fd2bf6  lea rdi, [rsp]
0000798fc6fd2bfa  mov esi, 0x00
0000798fc6fd2bff  mov rax, 0x63E558B23530
0000798fc6fd2c09  call rax
0000798fc6fd2c0b  movaps xmm5, [rsp]
0000798fc6fd2c0f  add rsp, 0x30
0000798fc6fd2c13  vmovaps xmm0, [rsp]
0000798fc6fd2c18  vmovaps xmm1, [rsp+0x10]
0000798fc6fd2c1e  vmovaps xmm2, [rsp+0x20]
0000798fc6fd2c24  vmovaps xmm3, [rsp+0x30]
0000798fc6fd2c2a  vmovaps xmm4, [rsp+0x40]
0000798fc6fd2c30  vmovaps xmm6, [rsp+0x50]
0000798fc6fd2c36  vmovaps xmm7, [rsp+0x60]
0000798fc6fd2c3c  vmovaps xmm8, [rsp+0x70]
0000798fc6fd2c42  vmovaps xmm9, [rsp+0x80]
0000798fc6fd2c4b  vmovaps xmm10, [rsp+0x90]
0000798fc6fd2c54  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd2c5d  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd2c66  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd2c6f  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd2c78  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd2c81  add rsp, 0xF0
0000798fc6fd2c88  pop r11
0000798fc6fd2c8a  pop r10
0000798fc6fd2c8c  pop r9
0000798fc6fd2c8e  pop r8
0000798fc6fd2c90  pop rsi
0000798fc6fd2c91  pop rdi
0000798fc6fd2c92  pop rdx
0000798fc6fd2c93  pop rcx
0000798fc6fd2c94  pop rax
0000798fc6fd2c95  add rsp, 0x08
0000798fc6fd2c99  jmp 0x0000798FC6FCFDEC
0000798fc6fd2c9e  sub rsp, 0x08
0000798fc6fd2ca2  push rax
0000798fc6fd2ca3  push rcx
0000798fc6fd2ca4  push rdx
0000798fc6fd2ca5  push rdi
0000798fc6fd2ca6  push rsi
0000798fc6fd2ca7  push r8
0000798fc6fd2ca9  push r9
0000798fc6fd2cab  push r10
0000798fc6fd2cad  push r11
0000798fc6fd2caf  sub rsp, 0xF0
0000798fc6fd2cb6  vmovaps [rsp], xmm0
0000798fc6fd2cbb  vmovaps [rsp+0x10], xmm1
0000798fc6fd2cc1  vmovaps [rsp+0x20], xmm2
0000798fc6fd2cc7  vmovaps [rsp+0x30], xmm3
0000798fc6fd2ccd  vmovaps [rsp+0x40], xmm4
0000798fc6fd2cd3  vmovaps [rsp+0x50], xmm5
0000798fc6fd2cd9  vmovaps [rsp+0x60], xmm6
0000798fc6fd2cdf  vmovaps [rsp+0x70], xmm7
0000798fc6fd2ce5  vmovaps [rsp+0x80], xmm8
0000798fc6fd2cee  vmovaps [rsp+0x90], xmm9
0000798fc6fd2cf7  vmovaps [rsp+0xA0], xmm10
0000798fc6fd2d00  vmovaps [rsp+0xB0], xmm11
0000798fc6fd2d09  vmovaps [rsp+0xC0], xmm12
0000798fc6fd2d12  vmovaps [rsp+0xD0], xmm14
0000798fc6fd2d1b  vmovaps [rsp+0xE0], xmm15
0000798fc6fd2d24  sub rsp, 0x30
0000798fc6fd2d28  movaps [rsp], xmm13
0000798fc6fd2d2d  movaps [rsp+0x10], xmm10
0000798fc6fd2d33  movaps [rsp+0x20], xmm1
0000798fc6fd2d38  lea rdi, [rsp]
0000798fc6fd2d3c  mov esi, 0x00
0000798fc6fd2d41  mov rax, 0x63E558B23530
0000798fc6fd2d4b  call rax
0000798fc6fd2d4d  movaps xmm13, [rsp]
0000798fc6fd2d52  add rsp, 0x30
0000798fc6fd2d56  vmovaps xmm0, [rsp]
0000798fc6fd2d5b  vmovaps xmm1, [rsp+0x10]
0000798fc6fd2d61  vmovaps xmm2, [rsp+0x20]
0000798fc6fd2d67  vmovaps xmm3, [rsp+0x30]
0000798fc6fd2d6d  vmovaps xmm4, [rsp+0x40]
0000798fc6fd2d73  vmovaps xmm5, [rsp+0x50]
0000798fc6fd2d79  vmovaps xmm6, [rsp+0x60]
0000798fc6fd2d7f  vmovaps xmm7, [rsp+0x70]
0000798fc6fd2d85  vmovaps xmm8, [rsp+0x80]
0000798fc6fd2d8e  vmovaps xmm9, [rsp+0x90]
0000798fc6fd2d97  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd2da0  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd2da9  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd2db2  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd2dbb  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd2dc4  add rsp, 0xF0
0000798fc6fd2dcb  pop r11
0000798fc6fd2dcd  pop r10
0000798fc6fd2dcf  pop r9
0000798fc6fd2dd1  pop r8
0000798fc6fd2dd3  pop rsi
0000798fc6fd2dd4  pop rdi
0000798fc6fd2dd5  pop rdx
0000798fc6fd2dd6  pop rcx
0000798fc6fd2dd7  pop rax
0000798fc6fd2dd8  add rsp, 0x08
0000798fc6fd2ddc  jmp 0x0000798FC6FCFE15
0000798fc6fd2de1  sub rsp, 0x08
0000798fc6fd2de5  push rax
0000798fc6fd2de6  push rcx
0000798fc6fd2de7  push rdx
0000798fc6fd2de8  push rdi
0000798fc6fd2de9  push rsi
0000798fc6fd2dea  push r8
0000798fc6fd2dec  push r9
0000798fc6fd2dee  push r10
0000798fc6fd2df0  push r11
0000798fc6fd2df2  sub rsp, 0xF0
0000798fc6fd2df9  vmovaps [rsp], xmm0
0000798fc6fd2dfe  vmovaps [rsp+0x10], xmm2
0000798fc6fd2e04  vmovaps [rsp+0x20], xmm3
0000798fc6fd2e0a  vmovaps [rsp+0x30], xmm4
0000798fc6fd2e10  vmovaps [rsp+0x40], xmm5
0000798fc6fd2e16  vmovaps [rsp+0x50], xmm6
0000798fc6fd2e1c  vmovaps [rsp+0x60], xmm7
0000798fc6fd2e22  vmovaps [rsp+0x70], xmm8
0000798fc6fd2e28  vmovaps [rsp+0x80], xmm9
0000798fc6fd2e31  vmovaps [rsp+0x90], xmm10
0000798fc6fd2e3a  vmovaps [rsp+0xA0], xmm11
0000798fc6fd2e43  vmovaps [rsp+0xB0], xmm12
0000798fc6fd2e4c  vmovaps [rsp+0xC0], xmm13
0000798fc6fd2e55  vmovaps [rsp+0xD0], xmm14
0000798fc6fd2e5e  vmovaps [rsp+0xE0], xmm15
0000798fc6fd2e67  sub rsp, 0x30
0000798fc6fd2e6b  movaps [rsp], xmm1
0000798fc6fd2e6f  movaps [rsp+0x10], xmm15
0000798fc6fd2e75  movaps [rsp+0x20], xmm10
0000798fc6fd2e7b  lea rdi, [rsp]
0000798fc6fd2e7f  mov esi, 0x00
0000798fc6fd2e84  mov rax, 0x63E558B23530
0000798fc6fd2e8e  call rax
0000798fc6fd2e90  movaps xmm1, [rsp]
0000798fc6fd2e94  add rsp, 0x30
0000798fc6fd2e98  vmovaps xmm0, [rsp]
0000798fc6fd2e9d  vmovaps xmm2, [rsp+0x10]
0000798fc6fd2ea3  vmovaps xmm3, [rsp+0x20]
0000798fc6fd2ea9  vmovaps xmm4, [rsp+0x30]
0000798fc6fd2eaf  vmovaps xmm5, [rsp+0x40]
0000798fc6fd2eb5  vmovaps xmm6, [rsp+0x50]
0000798fc6fd2ebb  vmovaps xmm7, [rsp+0x60]
0000798fc6fd2ec1  vmovaps xmm8, [rsp+0x70]
0000798fc6fd2ec7  vmovaps xmm9, [rsp+0x80]
0000798fc6fd2ed0  vmovaps xmm10, [rsp+0x90]
0000798fc6fd2ed9  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd2ee2  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd2eeb  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd2ef4  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd2efd  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd2f06  add rsp, 0xF0
0000798fc6fd2f0d  pop r11
0000798fc6fd2f0f  pop r10
0000798fc6fd2f11  pop r9
0000798fc6fd2f13  pop r8
0000798fc6fd2f15  pop rsi
0000798fc6fd2f16  pop rdi
0000798fc6fd2f17  pop rdx
0000798fc6fd2f18  pop rcx
0000798fc6fd2f19  pop rax
0000798fc6fd2f1a  add rsp, 0x08
0000798fc6fd2f1e  jmp 0x0000798FC6FCFE34
0000798fc6fd2f23  sub rsp, 0x08
0000798fc6fd2f27  push rax
0000798fc6fd2f28  push rcx
0000798fc6fd2f29  push rdx
0000798fc6fd2f2a  push rdi
0000798fc6fd2f2b  push rsi
0000798fc6fd2f2c  push r8
0000798fc6fd2f2e  push r9
0000798fc6fd2f30  push r10
0000798fc6fd2f32  push r11
0000798fc6fd2f34  sub rsp, 0xF0
0000798fc6fd2f3b  vmovaps [rsp], xmm0
0000798fc6fd2f40  vmovaps [rsp+0x10], xmm1
0000798fc6fd2f46  vmovaps [rsp+0x20], xmm2
0000798fc6fd2f4c  vmovaps [rsp+0x30], xmm3
0000798fc6fd2f52  vmovaps [rsp+0x40], xmm4
0000798fc6fd2f58  vmovaps [rsp+0x50], xmm5
0000798fc6fd2f5e  vmovaps [rsp+0x60], xmm6
0000798fc6fd2f64  vmovaps [rsp+0x70], xmm7
0000798fc6fd2f6a  vmovaps [rsp+0x80], xmm8
0000798fc6fd2f73  vmovaps [rsp+0x90], xmm9
0000798fc6fd2f7c  vmovaps [rsp+0xA0], xmm10
0000798fc6fd2f85  vmovaps [rsp+0xB0], xmm11
0000798fc6fd2f8e  vmovaps [rsp+0xC0], xmm12
0000798fc6fd2f97  vmovaps [rsp+0xD0], xmm13
0000798fc6fd2fa0  vmovaps [rsp+0xE0], xmm14
0000798fc6fd2fa9  sub rsp, 0x30
0000798fc6fd2fad  movaps [rsp], xmm15
0000798fc6fd2fb2  movaps [rsp+0x10], xmm10
0000798fc6fd2fb8  movaps [rsp+0x20], xmm11
0000798fc6fd2fbe  lea rdi, [rsp]
0000798fc6fd2fc2  mov esi, 0x00
0000798fc6fd2fc7  mov rax, 0x63E558B23530
0000798fc6fd2fd1  call rax
0000798fc6fd2fd3  movaps xmm15, [rsp]
0000798fc6fd2fd8  add rsp, 0x30
0000798fc6fd2fdc  vmovaps xmm0, [rsp]
0000798fc6fd2fe1  vmovaps xmm1, [rsp+0x10]
0000798fc6fd2fe7  vmovaps xmm2, [rsp+0x20]
0000798fc6fd2fed  vmovaps xmm3, [rsp+0x30]
0000798fc6fd2ff3  vmovaps xmm4, [rsp+0x40]
0000798fc6fd2ff9  vmovaps xmm5, [rsp+0x50]
0000798fc6fd2fff  vmovaps xmm6, [rsp+0x60]
0000798fc6fd3005  vmovaps xmm7, [rsp+0x70]
0000798fc6fd300b  vmovaps xmm8, [rsp+0x80]
0000798fc6fd3014  vmovaps xmm9, [rsp+0x90]
0000798fc6fd301d  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd3026  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd302f  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd3038  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd3041  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd304a  add rsp, 0xF0
0000798fc6fd3051  pop r11
0000798fc6fd3053  pop r10
0000798fc6fd3055  pop r9
0000798fc6fd3057  pop r8
0000798fc6fd3059  pop rsi
0000798fc6fd305a  pop rdi
0000798fc6fd305b  pop rdx
0000798fc6fd305c  pop rcx
0000798fc6fd305d  pop rax
0000798fc6fd305e  add rsp, 0x08
0000798fc6fd3062  jmp 0x0000798FC6FCFE57
0000798fc6fd3067  sub rsp, 0x08
0000798fc6fd306b  push rax
0000798fc6fd306c  push rcx
0000798fc6fd306d  push rdx
0000798fc6fd306e  push rdi
0000798fc6fd306f  push rsi
0000798fc6fd3070  push r8
0000798fc6fd3072  push r9
0000798fc6fd3074  push r10
0000798fc6fd3076  push r11
0000798fc6fd3078  sub rsp, 0xF0
0000798fc6fd307f  vmovaps [rsp], xmm0
0000798fc6fd3084  vmovaps [rsp+0x10], xmm1
0000798fc6fd308a  vmovaps [rsp+0x20], xmm2
0000798fc6fd3090  vmovaps [rsp+0x30], xmm3
0000798fc6fd3096  vmovaps [rsp+0x40], xmm4
0000798fc6fd309c  vmovaps [rsp+0x50], xmm5
0000798fc6fd30a2  vmovaps [rsp+0x60], xmm6
0000798fc6fd30a8  vmovaps [rsp+0x70], xmm7
0000798fc6fd30ae  vmovaps [rsp+0x80], xmm8
0000798fc6fd30b7  vmovaps [rsp+0x90], xmm9
0000798fc6fd30c0  vmovaps [rsp+0xA0], xmm11
0000798fc6fd30c9  vmovaps [rsp+0xB0], xmm12
0000798fc6fd30d2  vmovaps [rsp+0xC0], xmm13
0000798fc6fd30db  vmovaps [rsp+0xD0], xmm14
0000798fc6fd30e4  vmovaps [rsp+0xE0], xmm15
0000798fc6fd30ed  sub rsp, 0x30
0000798fc6fd30f1  movaps [rsp], xmm10
0000798fc6fd30f6  movaps [rsp+0x10], xmm12
0000798fc6fd30fc  movaps [rsp+0x20], xmm11
0000798fc6fd3102  lea rdi, [rsp]
0000798fc6fd3106  mov esi, 0x00
0000798fc6fd310b  mov rax, 0x63E558B23530
0000798fc6fd3115  call rax
0000798fc6fd3117  movaps xmm10, [rsp]
0000798fc6fd311c  add rsp, 0x30
0000798fc6fd3120  vmovaps xmm0, [rsp]
0000798fc6fd3125  vmovaps xmm1, [rsp+0x10]
0000798fc6fd312b  vmovaps xmm2, [rsp+0x20]
0000798fc6fd3131  vmovaps xmm3, [rsp+0x30]
0000798fc6fd3137  vmovaps xmm4, [rsp+0x40]
0000798fc6fd313d  vmovaps xmm5, [rsp+0x50]
0000798fc6fd3143  vmovaps xmm6, [rsp+0x60]
0000798fc6fd3149  vmovaps xmm7, [rsp+0x70]
0000798fc6fd314f  vmovaps xmm8, [rsp+0x80]
0000798fc6fd3158  vmovaps xmm9, [rsp+0x90]
0000798fc6fd3161  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd316a  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd3173  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd317c  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd3185  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd318e  add rsp, 0xF0
0000798fc6fd3195  pop r11
0000798fc6fd3197  pop r10
0000798fc6fd3199  pop r9
0000798fc6fd319b  pop r8
0000798fc6fd319d  pop rsi
0000798fc6fd319e  pop rdi
0000798fc6fd319f  pop rdx
0000798fc6fd31a0  pop rcx
0000798fc6fd31a1  pop rax
0000798fc6fd31a2  add rsp, 0x08
0000798fc6fd31a6  jmp 0x0000798FC6FCFE80
0000798fc6fd31ab  sub rsp, 0x08
0000798fc6fd31af  push rax
0000798fc6fd31b0  push rcx
0000798fc6fd31b1  push rdx
0000798fc6fd31b2  push rdi
0000798fc6fd31b3  push rsi
0000798fc6fd31b4  push r8
0000798fc6fd31b6  push r9
0000798fc6fd31b8  push r10
0000798fc6fd31ba  push r11
0000798fc6fd31bc  sub rsp, 0xF0
0000798fc6fd31c3  vmovaps [rsp], xmm0
0000798fc6fd31c8  vmovaps [rsp+0x10], xmm1
0000798fc6fd31ce  vmovaps [rsp+0x20], xmm2
0000798fc6fd31d4  vmovaps [rsp+0x30], xmm3
0000798fc6fd31da  vmovaps [rsp+0x40], xmm4
0000798fc6fd31e0  vmovaps [rsp+0x50], xmm5
0000798fc6fd31e6  vmovaps [rsp+0x60], xmm6
0000798fc6fd31ec  vmovaps [rsp+0x70], xmm7
0000798fc6fd31f2  vmovaps [rsp+0x80], xmm8
0000798fc6fd31fb  vmovaps [rsp+0x90], xmm9
0000798fc6fd3204  vmovaps [rsp+0xA0], xmm10
0000798fc6fd320d  vmovaps [rsp+0xB0], xmm12
0000798fc6fd3216  vmovaps [rsp+0xC0], xmm13
0000798fc6fd321f  vmovaps [rsp+0xD0], xmm14
0000798fc6fd3228  vmovaps [rsp+0xE0], xmm15
0000798fc6fd3231  sub rsp, 0x30
0000798fc6fd3235  movaps [rsp], xmm11
0000798fc6fd323a  movaps [rsp+0x10], xmm2
0000798fc6fd323f  movaps [rsp+0x20], xmm12
0000798fc6fd3245  lea rdi, [rsp]
0000798fc6fd3249  mov esi, 0x00
0000798fc6fd324e  mov rax, 0x63E558B23530
0000798fc6fd3258  call rax
0000798fc6fd325a  movaps xmm11, [rsp]
0000798fc6fd325f  add rsp, 0x30
0000798fc6fd3263  vmovaps xmm0, [rsp]
0000798fc6fd3268  vmovaps xmm1, [rsp+0x10]
0000798fc6fd326e  vmovaps xmm2, [rsp+0x20]
0000798fc6fd3274  vmovaps xmm3, [rsp+0x30]
0000798fc6fd327a  vmovaps xmm4, [rsp+0x40]
0000798fc6fd3280  vmovaps xmm5, [rsp+0x50]
0000798fc6fd3286  vmovaps xmm6, [rsp+0x60]
0000798fc6fd328c  vmovaps xmm7, [rsp+0x70]
0000798fc6fd3292  vmovaps xmm8, [rsp+0x80]
0000798fc6fd329b  vmovaps xmm9, [rsp+0x90]
0000798fc6fd32a4  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd32ad  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd32b6  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd32bf  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd32c8  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd32d1  add rsp, 0xF0
0000798fc6fd32d8  pop r11
0000798fc6fd32da  pop r10
0000798fc6fd32dc  pop r9
0000798fc6fd32de  pop r8
0000798fc6fd32e0  pop rsi
0000798fc6fd32e1  pop rdi
0000798fc6fd32e2  pop rdx
0000798fc6fd32e3  pop rcx
0000798fc6fd32e4  pop rax
0000798fc6fd32e5  add rsp, 0x08
0000798fc6fd32e9  jmp 0x0000798FC6FCFEB8
0000798fc6fd32ee  sub rsp, 0x08
0000798fc6fd32f2  push rax
0000798fc6fd32f3  push rcx
0000798fc6fd32f4  push rdx
0000798fc6fd32f5  push rdi
0000798fc6fd32f6  push rsi
0000798fc6fd32f7  push r8
0000798fc6fd32f9  push r9
0000798fc6fd32fb  push r10
0000798fc6fd32fd  push r11
0000798fc6fd32ff  sub rsp, 0xF0
0000798fc6fd3306  vmovaps [rsp], xmm0
0000798fc6fd330b  vmovaps [rsp+0x10], xmm2
0000798fc6fd3311  vmovaps [rsp+0x20], xmm3
0000798fc6fd3317  vmovaps [rsp+0x30], xmm4
0000798fc6fd331d  vmovaps [rsp+0x40], xmm5
0000798fc6fd3323  vmovaps [rsp+0x50], xmm6
0000798fc6fd3329  vmovaps [rsp+0x60], xmm7
0000798fc6fd332f  vmovaps [rsp+0x70], xmm8
0000798fc6fd3335  vmovaps [rsp+0x80], xmm9
0000798fc6fd333e  vmovaps [rsp+0x90], xmm10
0000798fc6fd3347  vmovaps [rsp+0xA0], xmm11
0000798fc6fd3350  vmovaps [rsp+0xB0], xmm12
0000798fc6fd3359  vmovaps [rsp+0xC0], xmm13
0000798fc6fd3362  vmovaps [rsp+0xD0], xmm14
0000798fc6fd336b  vmovaps [rsp+0xE0], xmm15
0000798fc6fd3374  sub rsp, 0x30
0000798fc6fd3378  movaps [rsp], xmm1
0000798fc6fd337c  movaps [rsp+0x10], xmm14
0000798fc6fd3382  movaps [rsp+0x20], xmm6
0000798fc6fd3387  lea rdi, [rsp]
0000798fc6fd338b  mov esi, 0x00
0000798fc6fd3390  mov rax, 0x63E558B23530
0000798fc6fd339a  call rax
0000798fc6fd339c  movaps xmm1, [rsp]
0000798fc6fd33a0  add rsp, 0x30
0000798fc6fd33a4  vmovaps xmm0, [rsp]
0000798fc6fd33a9  vmovaps xmm2, [rsp+0x10]
0000798fc6fd33af  vmovaps xmm3, [rsp+0x20]
0000798fc6fd33b5  vmovaps xmm4, [rsp+0x30]
0000798fc6fd33bb  vmovaps xmm5, [rsp+0x40]
0000798fc6fd33c1  vmovaps xmm6, [rsp+0x50]
0000798fc6fd33c7  vmovaps xmm7, [rsp+0x60]
0000798fc6fd33cd  vmovaps xmm8, [rsp+0x70]
0000798fc6fd33d3  vmovaps xmm9, [rsp+0x80]
0000798fc6fd33dc  vmovaps xmm10, [rsp+0x90]
0000798fc6fd33e5  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd33ee  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd33f7  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd3400  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd3409  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd3412  add rsp, 0xF0
0000798fc6fd3419  pop r11
0000798fc6fd341b  pop r10
0000798fc6fd341d  pop r9
0000798fc6fd341f  pop r8
0000798fc6fd3421  pop rsi
0000798fc6fd3422  pop rdi
0000798fc6fd3423  pop rdx
0000798fc6fd3424  pop rcx
0000798fc6fd3425  pop rax
0000798fc6fd3426  add rsp, 0x08
0000798fc6fd342a  jmp 0x0000798FC6FCFED1
0000798fc6fd342f  sub rsp, 0x08
0000798fc6fd3433  push rax
0000798fc6fd3434  push rcx
0000798fc6fd3435  push rdx
0000798fc6fd3436  push rdi
0000798fc6fd3437  push rsi
0000798fc6fd3438  push r8
0000798fc6fd343a  push r9
0000798fc6fd343c  push r10
0000798fc6fd343e  push r11
0000798fc6fd3440  sub rsp, 0xF0
0000798fc6fd3447  vmovaps [rsp], xmm0
0000798fc6fd344c  vmovaps [rsp+0x10], xmm1
0000798fc6fd3452  vmovaps [rsp+0x20], xmm2
0000798fc6fd3458  vmovaps [rsp+0x30], xmm3
0000798fc6fd345e  vmovaps [rsp+0x40], xmm4
0000798fc6fd3464  vmovaps [rsp+0x50], xmm5
0000798fc6fd346a  vmovaps [rsp+0x60], xmm6
0000798fc6fd3470  vmovaps [rsp+0x70], xmm7
0000798fc6fd3476  vmovaps [rsp+0x80], xmm8
0000798fc6fd347f  vmovaps [rsp+0x90], xmm9
0000798fc6fd3488  vmovaps [rsp+0xA0], xmm10
0000798fc6fd3491  vmovaps [rsp+0xB0], xmm11
0000798fc6fd349a  vmovaps [rsp+0xC0], xmm12
0000798fc6fd34a3  vmovaps [rsp+0xD0], xmm13
0000798fc6fd34ac  vmovaps [rsp+0xE0], xmm15
0000798fc6fd34b5  sub rsp, 0x30
0000798fc6fd34b9  movaps [rsp], xmm14
0000798fc6fd34be  movaps [rsp+0x10], xmm12
0000798fc6fd34c4  movaps [rsp+0x20], xmm5
0000798fc6fd34c9  lea rdi, [rsp]
0000798fc6fd34cd  mov esi, 0x00
0000798fc6fd34d2  mov rax, 0x63E558B23530
0000798fc6fd34dc  call rax
0000798fc6fd34de  movaps xmm14, [rsp]
0000798fc6fd34e3  add rsp, 0x30
0000798fc6fd34e7  vmovaps xmm0, [rsp]
0000798fc6fd34ec  vmovaps xmm1, [rsp+0x10]
0000798fc6fd34f2  vmovaps xmm2, [rsp+0x20]
0000798fc6fd34f8  vmovaps xmm3, [rsp+0x30]
0000798fc6fd34fe  vmovaps xmm4, [rsp+0x40]
0000798fc6fd3504  vmovaps xmm5, [rsp+0x50]
0000798fc6fd350a  vmovaps xmm6, [rsp+0x60]
0000798fc6fd3510  vmovaps xmm7, [rsp+0x70]
0000798fc6fd3516  vmovaps xmm8, [rsp+0x80]
0000798fc6fd351f  vmovaps xmm9, [rsp+0x90]
0000798fc6fd3528  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd3531  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd353a  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd3543  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd354c  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd3555  add rsp, 0xF0
0000798fc6fd355c  pop r11
0000798fc6fd355e  pop r10
0000798fc6fd3560  pop r9
0000798fc6fd3562  pop r8
0000798fc6fd3564  pop rsi
0000798fc6fd3565  pop rdi
0000798fc6fd3566  pop rdx
0000798fc6fd3567  pop rcx
0000798fc6fd3568  pop rax
0000798fc6fd3569  add rsp, 0x08
0000798fc6fd356d  jmp 0x0000798FC6FCFEF1
0000798fc6fd3572  sub rsp, 0x08
0000798fc6fd3576  push rax
0000798fc6fd3577  push rcx
0000798fc6fd3578  push rdx
0000798fc6fd3579  push rdi
0000798fc6fd357a  push rsi
0000798fc6fd357b  push r8
0000798fc6fd357d  push r9
0000798fc6fd357f  push r10
0000798fc6fd3581  push r11
0000798fc6fd3583  sub rsp, 0xF0
0000798fc6fd358a  vmovaps [rsp], xmm0
0000798fc6fd358f  vmovaps [rsp+0x10], xmm1
0000798fc6fd3595  vmovaps [rsp+0x20], xmm2
0000798fc6fd359b  vmovaps [rsp+0x30], xmm3
0000798fc6fd35a1  vmovaps [rsp+0x40], xmm4
0000798fc6fd35a7  vmovaps [rsp+0x50], xmm5
0000798fc6fd35ad  vmovaps [rsp+0x60], xmm7
0000798fc6fd35b3  vmovaps [rsp+0x70], xmm8
0000798fc6fd35b9  vmovaps [rsp+0x80], xmm9
0000798fc6fd35c2  vmovaps [rsp+0x90], xmm10
0000798fc6fd35cb  vmovaps [rsp+0xA0], xmm11
0000798fc6fd35d4  vmovaps [rsp+0xB0], xmm12
0000798fc6fd35dd  vmovaps [rsp+0xC0], xmm13
0000798fc6fd35e6  vmovaps [rsp+0xD0], xmm14
0000798fc6fd35ef  vmovaps [rsp+0xE0], xmm15
0000798fc6fd35f8  sub rsp, 0x30
0000798fc6fd35fc  movaps [rsp], xmm6
0000798fc6fd3600  movaps [rsp+0x10], xmm9
0000798fc6fd3606  movaps [rsp+0x20], xmm12
0000798fc6fd360c  lea rdi, [rsp]
0000798fc6fd3610  mov esi, 0x00
0000798fc6fd3615  mov rax, 0x63E558B23530
0000798fc6fd361f  call rax
0000798fc6fd3621  movaps xmm6, [rsp]
0000798fc6fd3625  add rsp, 0x30
0000798fc6fd3629  vmovaps xmm0, [rsp]
0000798fc6fd362e  vmovaps xmm1, [rsp+0x10]
0000798fc6fd3634  vmovaps xmm2, [rsp+0x20]
0000798fc6fd363a  vmovaps xmm3, [rsp+0x30]
0000798fc6fd3640  vmovaps xmm4, [rsp+0x40]
0000798fc6fd3646  vmovaps xmm5, [rsp+0x50]
0000798fc6fd364c  vmovaps xmm7, [rsp+0x60]
0000798fc6fd3652  vmovaps xmm8, [rsp+0x70]
0000798fc6fd3658  vmovaps xmm9, [rsp+0x80]
0000798fc6fd3661  vmovaps xmm10, [rsp+0x90]
0000798fc6fd366a  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd3673  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd367c  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd3685  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd368e  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd3697  add rsp, 0xF0
0000798fc6fd369e  pop r11
0000798fc6fd36a0  pop r10
0000798fc6fd36a2  pop r9
0000798fc6fd36a4  pop r8
0000798fc6fd36a6  pop rsi
0000798fc6fd36a7  pop rdi
0000798fc6fd36a8  pop rdx
0000798fc6fd36a9  pop rcx
0000798fc6fd36aa  pop rax
0000798fc6fd36ab  add rsp, 0x08
0000798fc6fd36af  jmp 0x0000798FC6FCFF19
0000798fc6fd36b4  sub rsp, 0x08
0000798fc6fd36b8  push rax
0000798fc6fd36b9  push rcx
0000798fc6fd36ba  push rdx
0000798fc6fd36bb  push rdi
0000798fc6fd36bc  push rsi
0000798fc6fd36bd  push r8
0000798fc6fd36bf  push r9
0000798fc6fd36c1  push r10
0000798fc6fd36c3  push r11
0000798fc6fd36c5  sub rsp, 0xF0
0000798fc6fd36cc  vmovaps [rsp], xmm0
0000798fc6fd36d1  vmovaps [rsp+0x10], xmm1
0000798fc6fd36d7  vmovaps [rsp+0x20], xmm2
0000798fc6fd36dd  vmovaps [rsp+0x30], xmm3
0000798fc6fd36e3  vmovaps [rsp+0x40], xmm4
0000798fc6fd36e9  vmovaps [rsp+0x50], xmm5
0000798fc6fd36ef  vmovaps [rsp+0x60], xmm6
0000798fc6fd36f5  vmovaps [rsp+0x70], xmm7
0000798fc6fd36fb  vmovaps [rsp+0x80], xmm8
0000798fc6fd3704  vmovaps [rsp+0x90], xmm9
0000798fc6fd370d  vmovaps [rsp+0xA0], xmm10
0000798fc6fd3716  vmovaps [rsp+0xB0], xmm11
0000798fc6fd371f  vmovaps [rsp+0xC0], xmm13
0000798fc6fd3728  vmovaps [rsp+0xD0], xmm14
0000798fc6fd3731  vmovaps [rsp+0xE0], xmm15
0000798fc6fd373a  sub rsp, 0x30
0000798fc6fd373e  movaps [rsp], xmm12
0000798fc6fd3743  movaps [rsp+0x10], xmm15
0000798fc6fd3749  movaps [rsp+0x20], xmm13
0000798fc6fd374f  lea rdi, [rsp]
0000798fc6fd3753  mov esi, 0x00
0000798fc6fd3758  mov rax, 0x63E558B23530
0000798fc6fd3762  call rax
0000798fc6fd3764  movaps xmm12, [rsp]
0000798fc6fd3769  add rsp, 0x30
0000798fc6fd376d  vmovaps xmm0, [rsp]
0000798fc6fd3772  vmovaps xmm1, [rsp+0x10]
0000798fc6fd3778  vmovaps xmm2, [rsp+0x20]
0000798fc6fd377e  vmovaps xmm3, [rsp+0x30]
0000798fc6fd3784  vmovaps xmm4, [rsp+0x40]
0000798fc6fd378a  vmovaps xmm5, [rsp+0x50]
0000798fc6fd3790  vmovaps xmm6, [rsp+0x60]
0000798fc6fd3796  vmovaps xmm7, [rsp+0x70]
0000798fc6fd379c  vmovaps xmm8, [rsp+0x80]
0000798fc6fd37a5  vmovaps xmm9, [rsp+0x90]
0000798fc6fd37ae  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd37b7  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd37c0  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd37c9  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd37d2  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd37db  add rsp, 0xF0
0000798fc6fd37e2  pop r11
0000798fc6fd37e4  pop r10
0000798fc6fd37e6  pop r9
0000798fc6fd37e8  pop r8
0000798fc6fd37ea  pop rsi
0000798fc6fd37eb  pop rdi
0000798fc6fd37ec  pop rdx
0000798fc6fd37ed  pop rcx
0000798fc6fd37ee  pop rax
0000798fc6fd37ef  add rsp, 0x08
0000798fc6fd37f3  jmp 0x0000798FC6FCFF34
0000798fc6fd37f8  sub rsp, 0x08
0000798fc6fd37fc  push rax
0000798fc6fd37fd  push rcx
0000798fc6fd37fe  push rdx
0000798fc6fd37ff  push rdi
0000798fc6fd3800  push rsi
0000798fc6fd3801  push r8
0000798fc6fd3803  push r9
0000798fc6fd3805  push r10
0000798fc6fd3807  push r11
0000798fc6fd3809  sub rsp, 0xF0
0000798fc6fd3810  vmovaps [rsp], xmm0
0000798fc6fd3815  vmovaps [rsp+0x10], xmm1
0000798fc6fd381b  vmovaps [rsp+0x20], xmm2
0000798fc6fd3821  vmovaps [rsp+0x30], xmm3
0000798fc6fd3827  vmovaps [rsp+0x40], xmm4
0000798fc6fd382d  vmovaps [rsp+0x50], xmm5
0000798fc6fd3833  vmovaps [rsp+0x60], xmm6
0000798fc6fd3839  vmovaps [rsp+0x70], xmm7
0000798fc6fd383f  vmovaps [rsp+0x80], xmm8
0000798fc6fd3848  vmovaps [rsp+0x90], xmm9
0000798fc6fd3851  vmovaps [rsp+0xA0], xmm10
0000798fc6fd385a  vmovaps [rsp+0xB0], xmm11
0000798fc6fd3863  vmovaps [rsp+0xC0], xmm12
0000798fc6fd386c  vmovaps [rsp+0xD0], xmm13
0000798fc6fd3875  vmovaps [rsp+0xE0], xmm14
0000798fc6fd387e  sub rsp, 0x30
0000798fc6fd3882  movaps [rsp], xmm15
0000798fc6fd3887  movaps [rsp+0x10], xmm13
0000798fc6fd388d  movaps [rsp+0x20], xmm10
0000798fc6fd3893  lea rdi, [rsp]
0000798fc6fd3897  mov esi, 0x00
0000798fc6fd389c  mov rax, 0x63E558B23530
0000798fc6fd38a6  call rax
0000798fc6fd38a8  movaps xmm15, [rsp]
0000798fc6fd38ad  add rsp, 0x30
0000798fc6fd38b1  vmovaps xmm0, [rsp]
0000798fc6fd38b6  vmovaps xmm1, [rsp+0x10]
0000798fc6fd38bc  vmovaps xmm2, [rsp+0x20]
0000798fc6fd38c2  vmovaps xmm3, [rsp+0x30]
0000798fc6fd38c8  vmovaps xmm4, [rsp+0x40]
0000798fc6fd38ce  vmovaps xmm5, [rsp+0x50]
0000798fc6fd38d4  vmovaps xmm6, [rsp+0x60]
0000798fc6fd38da  vmovaps xmm7, [rsp+0x70]
0000798fc6fd38e0  vmovaps xmm8, [rsp+0x80]
0000798fc6fd38e9  vmovaps xmm9, [rsp+0x90]
0000798fc6fd38f2  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd38fb  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd3904  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd390d  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd3916  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd391f  add rsp, 0xF0
0000798fc6fd3926  pop r11
0000798fc6fd3928  pop r10
0000798fc6fd392a  pop r9
0000798fc6fd392c  pop r8
0000798fc6fd392e  pop rsi
0000798fc6fd392f  pop rdi
0000798fc6fd3930  pop rdx
0000798fc6fd3931  pop rcx
0000798fc6fd3932  pop rax
0000798fc6fd3933  add rsp, 0x08
0000798fc6fd3937  jmp 0x0000798FC6FCFF55
0000798fc6fd393c  call 0x0000798FC6E0C260
0000798fc6fd3941  jmp 0x0000798FC6FCFFB0
0000798fc6fd3946  sub rsp, 0x08
0000798fc6fd394a  push rax
0000798fc6fd394b  push rcx
0000798fc6fd394c  push rdx
0000798fc6fd394d  push rdi
0000798fc6fd394e  push rsi
0000798fc6fd394f  push r8
0000798fc6fd3951  push r9
0000798fc6fd3953  push r10
0000798fc6fd3955  push r11
0000798fc6fd3957  sub rsp, 0xF0
0000798fc6fd395e  vmovaps [rsp], xmm0
0000798fc6fd3963  vmovaps [rsp+0x10], xmm1
0000798fc6fd3969  vmovaps [rsp+0x20], xmm2
0000798fc6fd396f  vmovaps [rsp+0x30], xmm3
0000798fc6fd3975  vmovaps [rsp+0x40], xmm4
0000798fc6fd397b  vmovaps [rsp+0x50], xmm5
0000798fc6fd3981  vmovaps [rsp+0x60], xmm6
0000798fc6fd3987  vmovaps [rsp+0x70], xmm7
0000798fc6fd398d  vmovaps [rsp+0x80], xmm8
0000798fc6fd3996  vmovaps [rsp+0x90], xmm10
0000798fc6fd399f  vmovaps [rsp+0xA0], xmm11
0000798fc6fd39a8  vmovaps [rsp+0xB0], xmm12
0000798fc6fd39b1  vmovaps [rsp+0xC0], xmm13
0000798fc6fd39ba  vmovaps [rsp+0xD0], xmm14
0000798fc6fd39c3  vmovaps [rsp+0xE0], xmm15
0000798fc6fd39cc  sub rsp, 0x30
0000798fc6fd39d0  movaps [rsp], xmm9
0000798fc6fd39d5  movaps [rsp+0x10], xmm8
0000798fc6fd39db  movaps [rsp+0x20], xmm10
0000798fc6fd39e1  lea rdi, [rsp]
0000798fc6fd39e5  mov esi, 0x00
0000798fc6fd39ea  mov rax, 0x63E558B23530
0000798fc6fd39f4  call rax
0000798fc6fd39f6  movaps xmm9, [rsp]
0000798fc6fd39fb  add rsp, 0x30
0000798fc6fd39ff  vmovaps xmm0, [rsp]
0000798fc6fd3a04  vmovaps xmm1, [rsp+0x10]
0000798fc6fd3a0a  vmovaps xmm2, [rsp+0x20]
0000798fc6fd3a10  vmovaps xmm3, [rsp+0x30]
0000798fc6fd3a16  vmovaps xmm4, [rsp+0x40]
0000798fc6fd3a1c  vmovaps xmm5, [rsp+0x50]
0000798fc6fd3a22  vmovaps xmm6, [rsp+0x60]
0000798fc6fd3a28  vmovaps xmm7, [rsp+0x70]
0000798fc6fd3a2e  vmovaps xmm8, [rsp+0x80]
0000798fc6fd3a37  vmovaps xmm10, [rsp+0x90]
0000798fc6fd3a40  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd3a49  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd3a52  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd3a5b  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd3a64  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd3a6d  add rsp, 0xF0
0000798fc6fd3a74  pop r11
0000798fc6fd3a76  pop r10
0000798fc6fd3a78  pop r9
0000798fc6fd3a7a  pop r8
0000798fc6fd3a7c  pop rsi
0000798fc6fd3a7d  pop rdi
0000798fc6fd3a7e  pop rdx
0000798fc6fd3a7f  pop rcx
0000798fc6fd3a80  pop rax
0000798fc6fd3a81  add rsp, 0x08
0000798fc6fd3a85  jmp 0x0000798FC6FCFFE1
0000798fc6fd3a8a  sub rsp, 0x08
0000798fc6fd3a8e  push rax
0000798fc6fd3a8f  push rcx
0000798fc6fd3a90  push rdx
0000798fc6fd3a91  push rdi
0000798fc6fd3a92  push rsi
0000798fc6fd3a93  push r8
0000798fc6fd3a95  push r9
0000798fc6fd3a97  push r10
0000798fc6fd3a99  push r11
0000798fc6fd3a9b  sub rsp, 0xF0
0000798fc6fd3aa2  vmovaps [rsp], xmm0
0000798fc6fd3aa7  vmovaps [rsp+0x10], xmm1
0000798fc6fd3aad  vmovaps [rsp+0x20], xmm2
0000798fc6fd3ab3  vmovaps [rsp+0x30], xmm3
0000798fc6fd3ab9  vmovaps [rsp+0x40], xmm4
0000798fc6fd3abf  vmovaps [rsp+0x50], xmm5
0000798fc6fd3ac5  vmovaps [rsp+0x60], xmm6
0000798fc6fd3acb  vmovaps [rsp+0x70], xmm7
0000798fc6fd3ad1  vmovaps [rsp+0x80], xmm8
0000798fc6fd3ada  vmovaps [rsp+0x90], xmm9
0000798fc6fd3ae3  vmovaps [rsp+0xA0], xmm11
0000798fc6fd3aec  vmovaps [rsp+0xB0], xmm12
0000798fc6fd3af5  vmovaps [rsp+0xC0], xmm13
0000798fc6fd3afe  vmovaps [rsp+0xD0], xmm14
0000798fc6fd3b07  vmovaps [rsp+0xE0], xmm15
0000798fc6fd3b10  sub rsp, 0x30
0000798fc6fd3b14  movaps [rsp], xmm10
0000798fc6fd3b19  movaps [rsp+0x10], xmm1
0000798fc6fd3b1e  movaps [rsp+0x20], xmm11
0000798fc6fd3b24  lea rdi, [rsp]
0000798fc6fd3b28  mov esi, 0x00
0000798fc6fd3b2d  mov rax, 0x63E558B23530
0000798fc6fd3b37  call rax
0000798fc6fd3b39  movaps xmm10, [rsp]
0000798fc6fd3b3e  add rsp, 0x30
0000798fc6fd3b42  vmovaps xmm0, [rsp]
0000798fc6fd3b47  vmovaps xmm1, [rsp+0x10]
0000798fc6fd3b4d  vmovaps xmm2, [rsp+0x20]
0000798fc6fd3b53  vmovaps xmm3, [rsp+0x30]
0000798fc6fd3b59  vmovaps xmm4, [rsp+0x40]
0000798fc6fd3b5f  vmovaps xmm5, [rsp+0x50]
0000798fc6fd3b65  vmovaps xmm6, [rsp+0x60]
0000798fc6fd3b6b  vmovaps xmm7, [rsp+0x70]
0000798fc6fd3b71  vmovaps xmm8, [rsp+0x80]
0000798fc6fd3b7a  vmovaps xmm9, [rsp+0x90]
0000798fc6fd3b83  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd3b8c  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd3b95  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd3b9e  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd3ba7  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd3bb0  add rsp, 0xF0
0000798fc6fd3bb7  pop r11
0000798fc6fd3bb9  pop r10
0000798fc6fd3bbb  pop r9
0000798fc6fd3bbd  pop r8
0000798fc6fd3bbf  pop rsi
0000798fc6fd3bc0  pop rdi
0000798fc6fd3bc1  pop rdx
0000798fc6fd3bc2  pop rcx
0000798fc6fd3bc3  pop rax
0000798fc6fd3bc4  add rsp, 0x08
0000798fc6fd3bc8  jmp 0x0000798FC6FCFFFC
0000798fc6fd3bcd  sub rsp, 0x08
0000798fc6fd3bd1  push rax
0000798fc6fd3bd2  push rcx
0000798fc6fd3bd3  push rdx
0000798fc6fd3bd4  push rdi
0000798fc6fd3bd5  push rsi
0000798fc6fd3bd6  push r8
0000798fc6fd3bd8  push r9
0000798fc6fd3bda  push r10
0000798fc6fd3bdc  push r11
0000798fc6fd3bde  sub rsp, 0xF0
0000798fc6fd3be5  vmovaps [rsp], xmm0
0000798fc6fd3bea  vmovaps [rsp+0x10], xmm2
0000798fc6fd3bf0  vmovaps [rsp+0x20], xmm3
0000798fc6fd3bf6  vmovaps [rsp+0x30], xmm4
0000798fc6fd3bfc  vmovaps [rsp+0x40], xmm5
0000798fc6fd3c02  vmovaps [rsp+0x50], xmm6
0000798fc6fd3c08  vmovaps [rsp+0x60], xmm7
0000798fc6fd3c0e  vmovaps [rsp+0x70], xmm8
0000798fc6fd3c14  vmovaps [rsp+0x80], xmm9
0000798fc6fd3c1d  vmovaps [rsp+0x90], xmm10
0000798fc6fd3c26  vmovaps [rsp+0xA0], xmm11
0000798fc6fd3c2f  vmovaps [rsp+0xB0], xmm12
0000798fc6fd3c38  vmovaps [rsp+0xC0], xmm13
0000798fc6fd3c41  vmovaps [rsp+0xD0], xmm14
0000798fc6fd3c4a  vmovaps [rsp+0xE0], xmm15
0000798fc6fd3c53  sub rsp, 0x30
0000798fc6fd3c57  movaps [rsp], xmm1
0000798fc6fd3c5b  movaps [rsp+0x10], xmm14
0000798fc6fd3c61  movaps [rsp+0x20], xmm6
0000798fc6fd3c66  lea rdi, [rsp]
0000798fc6fd3c6a  mov esi, 0x00
0000798fc6fd3c6f  mov rax, 0x63E558B23530
0000798fc6fd3c79  call rax
0000798fc6fd3c7b  movaps xmm1, [rsp]
0000798fc6fd3c7f  add rsp, 0x30
0000798fc6fd3c83  vmovaps xmm0, [rsp]
0000798fc6fd3c88  vmovaps xmm2, [rsp+0x10]
0000798fc6fd3c8e  vmovaps xmm3, [rsp+0x20]
0000798fc6fd3c94  vmovaps xmm4, [rsp+0x30]
0000798fc6fd3c9a  vmovaps xmm5, [rsp+0x40]
0000798fc6fd3ca0  vmovaps xmm6, [rsp+0x50]
0000798fc6fd3ca6  vmovaps xmm7, [rsp+0x60]
0000798fc6fd3cac  vmovaps xmm8, [rsp+0x70]
0000798fc6fd3cb2  vmovaps xmm9, [rsp+0x80]
0000798fc6fd3cbb  vmovaps xmm10, [rsp+0x90]
0000798fc6fd3cc4  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd3ccd  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd3cd6  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd3cdf  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd3ce8  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd3cf1  add rsp, 0xF0
0000798fc6fd3cf8  pop r11
0000798fc6fd3cfa  pop r10
0000798fc6fd3cfc  pop r9
0000798fc6fd3cfe  pop r8
0000798fc6fd3d00  pop rsi
0000798fc6fd3d01  pop rdi
0000798fc6fd3d02  pop rdx
0000798fc6fd3d03  pop rcx
0000798fc6fd3d04  pop rax
0000798fc6fd3d05  add rsp, 0x08
0000798fc6fd3d09  jmp 0x0000798FC6FD0015
0000798fc6fd3d0e  sub rsp, 0x08
0000798fc6fd3d12  push rax
0000798fc6fd3d13  push rcx
0000798fc6fd3d14  push rdx
0000798fc6fd3d15  push rdi
0000798fc6fd3d16  push rsi
0000798fc6fd3d17  push r8
0000798fc6fd3d19  push r9
0000798fc6fd3d1b  push r10
0000798fc6fd3d1d  push r11
0000798fc6fd3d1f  sub rsp, 0xF0
0000798fc6fd3d26  vmovaps [rsp], xmm0
0000798fc6fd3d2b  vmovaps [rsp+0x10], xmm1
0000798fc6fd3d31  vmovaps [rsp+0x20], xmm2
0000798fc6fd3d37  vmovaps [rsp+0x30], xmm3
0000798fc6fd3d3d  vmovaps [rsp+0x40], xmm4
0000798fc6fd3d43  vmovaps [rsp+0x50], xmm5
0000798fc6fd3d49  vmovaps [rsp+0x60], xmm6
0000798fc6fd3d4f  vmovaps [rsp+0x70], xmm7
0000798fc6fd3d55  vmovaps [rsp+0x80], xmm8
0000798fc6fd3d5e  vmovaps [rsp+0x90], xmm9
0000798fc6fd3d67  vmovaps [rsp+0xA0], xmm10
0000798fc6fd3d70  vmovaps [rsp+0xB0], xmm12
0000798fc6fd3d79  vmovaps [rsp+0xC0], xmm13
0000798fc6fd3d82  vmovaps [rsp+0xD0], xmm14
0000798fc6fd3d8b  vmovaps [rsp+0xE0], xmm15
0000798fc6fd3d94  sub rsp, 0x30
0000798fc6fd3d98  movaps [rsp], xmm11
0000798fc6fd3d9d  movaps [rsp+0x10], xmm13
0000798fc6fd3da3  movaps [rsp+0x20], xmm14
0000798fc6fd3da9  lea rdi, [rsp]
0000798fc6fd3dad  mov esi, 0x00
0000798fc6fd3db2  mov rax, 0x63E558B23530
0000798fc6fd3dbc  call rax
0000798fc6fd3dbe  movaps xmm11, [rsp]
0000798fc6fd3dc3  add rsp, 0x30
0000798fc6fd3dc7  vmovaps xmm0, [rsp]
0000798fc6fd3dcc  vmovaps xmm1, [rsp+0x10]
0000798fc6fd3dd2  vmovaps xmm2, [rsp+0x20]
0000798fc6fd3dd8  vmovaps xmm3, [rsp+0x30]
0000798fc6fd3dde  vmovaps xmm4, [rsp+0x40]
0000798fc6fd3de4  vmovaps xmm5, [rsp+0x50]
0000798fc6fd3dea  vmovaps xmm6, [rsp+0x60]
0000798fc6fd3df0  vmovaps xmm7, [rsp+0x70]
0000798fc6fd3df6  vmovaps xmm8, [rsp+0x80]
0000798fc6fd3dff  vmovaps xmm9, [rsp+0x90]
0000798fc6fd3e08  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd3e11  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd3e1a  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd3e23  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd3e2c  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd3e35  add rsp, 0xF0
0000798fc6fd3e3c  pop r11
0000798fc6fd3e3e  pop r10
0000798fc6fd3e40  pop r9
0000798fc6fd3e42  pop r8
0000798fc6fd3e44  pop rsi
0000798fc6fd3e45  pop rdi
0000798fc6fd3e46  pop rdx
0000798fc6fd3e47  pop rcx
0000798fc6fd3e48  pop rax
0000798fc6fd3e49  add rsp, 0x08
0000798fc6fd3e4d  jmp 0x0000798FC6FD003F
0000798fc6fd3e52  sub rsp, 0x08
0000798fc6fd3e56  push rax
0000798fc6fd3e57  push rcx
0000798fc6fd3e58  push rdx
0000798fc6fd3e59  push rdi
0000798fc6fd3e5a  push rsi
0000798fc6fd3e5b  push r8
0000798fc6fd3e5d  push r9
0000798fc6fd3e5f  push r10
0000798fc6fd3e61  push r11
0000798fc6fd3e63  sub rsp, 0xF0
0000798fc6fd3e6a  vmovaps [rsp], xmm0
0000798fc6fd3e6f  vmovaps [rsp+0x10], xmm1
0000798fc6fd3e75  vmovaps [rsp+0x20], xmm2
0000798fc6fd3e7b  vmovaps [rsp+0x30], xmm3
0000798fc6fd3e81  vmovaps [rsp+0x40], xmm4
0000798fc6fd3e87  vmovaps [rsp+0x50], xmm5
0000798fc6fd3e8d  vmovaps [rsp+0x60], xmm6
0000798fc6fd3e93  vmovaps [rsp+0x70], xmm7
0000798fc6fd3e99  vmovaps [rsp+0x80], xmm8
0000798fc6fd3ea2  vmovaps [rsp+0x90], xmm9
0000798fc6fd3eab  vmovaps [rsp+0xA0], xmm10
0000798fc6fd3eb4  vmovaps [rsp+0xB0], xmm11
0000798fc6fd3ebd  vmovaps [rsp+0xC0], xmm12
0000798fc6fd3ec6  vmovaps [rsp+0xD0], xmm14
0000798fc6fd3ecf  vmovaps [rsp+0xE0], xmm15
0000798fc6fd3ed8  sub rsp, 0x30
0000798fc6fd3edc  movaps [rsp], xmm13
0000798fc6fd3ee1  movaps [rsp+0x10], xmm8
0000798fc6fd3ee7  movaps [rsp+0x20], xmm14
0000798fc6fd3eed  lea rdi, [rsp]
0000798fc6fd3ef1  mov esi, 0x00
0000798fc6fd3ef6  mov rax, 0x63E558B23530
0000798fc6fd3f00  call rax
0000798fc6fd3f02  movaps xmm13, [rsp]
0000798fc6fd3f07  add rsp, 0x30
0000798fc6fd3f0b  vmovaps xmm0, [rsp]
0000798fc6fd3f10  vmovaps xmm1, [rsp+0x10]
0000798fc6fd3f16  vmovaps xmm2, [rsp+0x20]
0000798fc6fd3f1c  vmovaps xmm3, [rsp+0x30]
0000798fc6fd3f22  vmovaps xmm4, [rsp+0x40]
0000798fc6fd3f28  vmovaps xmm5, [rsp+0x50]
0000798fc6fd3f2e  vmovaps xmm6, [rsp+0x60]
0000798fc6fd3f34  vmovaps xmm7, [rsp+0x70]
0000798fc6fd3f3a  vmovaps xmm8, [rsp+0x80]
0000798fc6fd3f43  vmovaps xmm9, [rsp+0x90]
0000798fc6fd3f4c  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd3f55  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd3f5e  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd3f67  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd3f70  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd3f79  add rsp, 0xF0
0000798fc6fd3f80  pop r11
0000798fc6fd3f82  pop r10
0000798fc6fd3f84  pop r9
0000798fc6fd3f86  pop r8
0000798fc6fd3f88  pop rsi
0000798fc6fd3f89  pop rdi
0000798fc6fd3f8a  pop rdx
0000798fc6fd3f8b  pop rcx
0000798fc6fd3f8c  pop rax
0000798fc6fd3f8d  add rsp, 0x08
0000798fc6fd3f91  jmp 0x0000798FC6FD006E
0000798fc6fd3f96  sub rsp, 0x08
0000798fc6fd3f9a  push rax
0000798fc6fd3f9b  push rcx
0000798fc6fd3f9c  push rdx
0000798fc6fd3f9d  push rdi
0000798fc6fd3f9e  push rsi
0000798fc6fd3f9f  push r8
0000798fc6fd3fa1  push r9
0000798fc6fd3fa3  push r10
0000798fc6fd3fa5  push r11
0000798fc6fd3fa7  sub rsp, 0xF0
0000798fc6fd3fae  vmovaps [rsp], xmm0
0000798fc6fd3fb3  vmovaps [rsp+0x10], xmm1
0000798fc6fd3fb9  vmovaps [rsp+0x20], xmm2
0000798fc6fd3fbf  vmovaps [rsp+0x30], xmm3
0000798fc6fd3fc5  vmovaps [rsp+0x40], xmm4
0000798fc6fd3fcb  vmovaps [rsp+0x50], xmm5
0000798fc6fd3fd1  vmovaps [rsp+0x60], xmm6
0000798fc6fd3fd7  vmovaps [rsp+0x70], xmm7
0000798fc6fd3fdd  vmovaps [rsp+0x80], xmm9
0000798fc6fd3fe6  vmovaps [rsp+0x90], xmm10
0000798fc6fd3fef  vmovaps [rsp+0xA0], xmm11
0000798fc6fd3ff8  vmovaps [rsp+0xB0], xmm12
0000798fc6fd4001  vmovaps [rsp+0xC0], xmm13
0000798fc6fd400a  vmovaps [rsp+0xD0], xmm14
0000798fc6fd4013  vmovaps [rsp+0xE0], xmm15
0000798fc6fd401c  sub rsp, 0x30
0000798fc6fd4020  movaps [rsp], xmm8
0000798fc6fd4025  movaps [rsp+0x10], xmm7
0000798fc6fd402a  movaps [rsp+0x20], xmm14
0000798fc6fd4030  lea rdi, [rsp]
0000798fc6fd4034  mov esi, 0x00
0000798fc6fd4039  mov rax, 0x63E558B23530
0000798fc6fd4043  call rax
0000798fc6fd4045  movaps xmm8, [rsp]
0000798fc6fd404a  add rsp, 0x30
0000798fc6fd404e  vmovaps xmm0, [rsp]
0000798fc6fd4053  vmovaps xmm1, [rsp+0x10]
0000798fc6fd4059  vmovaps xmm2, [rsp+0x20]
0000798fc6fd405f  vmovaps xmm3, [rsp+0x30]
0000798fc6fd4065  vmovaps xmm4, [rsp+0x40]
0000798fc6fd406b  vmovaps xmm5, [rsp+0x50]
0000798fc6fd4071  vmovaps xmm6, [rsp+0x60]
0000798fc6fd4077  vmovaps xmm7, [rsp+0x70]
0000798fc6fd407d  vmovaps xmm9, [rsp+0x80]
0000798fc6fd4086  vmovaps xmm10, [rsp+0x90]
0000798fc6fd408f  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd4098  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd40a1  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd40aa  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd40b3  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd40bc  add rsp, 0xF0
0000798fc6fd40c3  pop r11
0000798fc6fd40c5  pop r10
0000798fc6fd40c7  pop r9
0000798fc6fd40c9  pop r8
0000798fc6fd40cb  pop rsi
0000798fc6fd40cc  pop rdi
0000798fc6fd40cd  pop rdx
0000798fc6fd40ce  pop rcx
0000798fc6fd40cf  pop rax
0000798fc6fd40d0  add rsp, 0x08
0000798fc6fd40d4  jmp 0x0000798FC6FD0094
0000798fc6fd40d9  sub rsp, 0x08
0000798fc6fd40dd  push rax
0000798fc6fd40de  push rcx
0000798fc6fd40df  push rdx
0000798fc6fd40e0  push rdi
0000798fc6fd40e1  push rsi
0000798fc6fd40e2  push r8
0000798fc6fd40e4  push r9
0000798fc6fd40e6  push r10
0000798fc6fd40e8  push r11
0000798fc6fd40ea  sub rsp, 0xF0
0000798fc6fd40f1  vmovaps [rsp], xmm0
0000798fc6fd40f6  vmovaps [rsp+0x10], xmm1
0000798fc6fd40fc  vmovaps [rsp+0x20], xmm2
0000798fc6fd4102  vmovaps [rsp+0x30], xmm3
0000798fc6fd4108  vmovaps [rsp+0x40], xmm4
0000798fc6fd410e  vmovaps [rsp+0x50], xmm5
0000798fc6fd4114  vmovaps [rsp+0x60], xmm6
0000798fc6fd411a  vmovaps [rsp+0x70], xmm7
0000798fc6fd4120  vmovaps [rsp+0x80], xmm8
0000798fc6fd4129  vmovaps [rsp+0x90], xmm9
0000798fc6fd4132  vmovaps [rsp+0xA0], xmm10
0000798fc6fd413b  vmovaps [rsp+0xB0], xmm11
0000798fc6fd4144  vmovaps [rsp+0xC0], xmm12
0000798fc6fd414d  vmovaps [rsp+0xD0], xmm13
0000798fc6fd4156  vmovaps [rsp+0xE0], xmm15
0000798fc6fd415f  sub rsp, 0x30
0000798fc6fd4163  movaps [rsp], xmm14
0000798fc6fd4168  movaps [rsp+0x10], xmm12
0000798fc6fd416e  movaps [rsp+0x20], xmm9
0000798fc6fd4174  lea rdi, [rsp]
0000798fc6fd4178  mov esi, 0x00
0000798fc6fd417d  mov rax, 0x63E558B23530
0000798fc6fd4187  call rax
0000798fc6fd4189  movaps xmm14, [rsp]
0000798fc6fd418e  add rsp, 0x30
0000798fc6fd4192  vmovaps xmm0, [rsp]
0000798fc6fd4197  vmovaps xmm1, [rsp+0x10]
0000798fc6fd419d  vmovaps xmm2, [rsp+0x20]
0000798fc6fd41a3  vmovaps xmm3, [rsp+0x30]
0000798fc6fd41a9  vmovaps xmm4, [rsp+0x40]
0000798fc6fd41af  vmovaps xmm5, [rsp+0x50]
0000798fc6fd41b5  vmovaps xmm6, [rsp+0x60]
0000798fc6fd41bb  vmovaps xmm7, [rsp+0x70]
0000798fc6fd41c1  vmovaps xmm8, [rsp+0x80]
0000798fc6fd41ca  vmovaps xmm9, [rsp+0x90]
0000798fc6fd41d3  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd41dc  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd41e5  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd41ee  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd41f7  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd4200  add rsp, 0xF0
0000798fc6fd4207  pop r11
0000798fc6fd4209  pop r10
0000798fc6fd420b  pop r9
0000798fc6fd420d  pop r8
0000798fc6fd420f  pop rsi
0000798fc6fd4210  pop rdi
0000798fc6fd4211  pop rdx
0000798fc6fd4212  pop rcx
0000798fc6fd4213  pop rax
0000798fc6fd4214  add rsp, 0x08
0000798fc6fd4218  jmp 0x0000798FC6FD00AE
0000798fc6fd421d  sub rsp, 0x08
0000798fc6fd4221  push rax
0000798fc6fd4222  push rcx
0000798fc6fd4223  push rdx
0000798fc6fd4224  push rdi
0000798fc6fd4225  push rsi
0000798fc6fd4226  push r8
0000798fc6fd4228  push r9
0000798fc6fd422a  push r10
0000798fc6fd422c  push r11
0000798fc6fd422e  sub rsp, 0xF0
0000798fc6fd4235  vmovaps [rsp], xmm0
0000798fc6fd423a  vmovaps [rsp+0x10], xmm1
0000798fc6fd4240  vmovaps [rsp+0x20], xmm2
0000798fc6fd4246  vmovaps [rsp+0x30], xmm3
0000798fc6fd424c  vmovaps [rsp+0x40], xmm4
0000798fc6fd4252  vmovaps [rsp+0x50], xmm5
0000798fc6fd4258  vmovaps [rsp+0x60], xmm6
0000798fc6fd425e  vmovaps [rsp+0x70], xmm7
0000798fc6fd4264  vmovaps [rsp+0x80], xmm8
0000798fc6fd426d  vmovaps [rsp+0x90], xmm10
0000798fc6fd4276  vmovaps [rsp+0xA0], xmm11
0000798fc6fd427f  vmovaps [rsp+0xB0], xmm12
0000798fc6fd4288  vmovaps [rsp+0xC0], xmm13
0000798fc6fd4291  vmovaps [rsp+0xD0], xmm14
0000798fc6fd429a  vmovaps [rsp+0xE0], xmm15
0000798fc6fd42a3  sub rsp, 0x30
0000798fc6fd42a7  movaps [rsp], xmm9
0000798fc6fd42ac  movaps [rsp+0x10], xmm7
0000798fc6fd42b1  movaps [rsp+0x20], xmm12
0000798fc6fd42b7  lea rdi, [rsp]
0000798fc6fd42bb  mov esi, 0x00
0000798fc6fd42c0  mov rax, 0x63E558B23530
0000798fc6fd42ca  call rax
0000798fc6fd42cc  movaps xmm9, [rsp]
0000798fc6fd42d1  add rsp, 0x30
0000798fc6fd42d5  vmovaps xmm0, [rsp]
0000798fc6fd42da  vmovaps xmm1, [rsp+0x10]
0000798fc6fd42e0  vmovaps xmm2, [rsp+0x20]
0000798fc6fd42e6  vmovaps xmm3, [rsp+0x30]
0000798fc6fd42ec  vmovaps xmm4, [rsp+0x40]
0000798fc6fd42f2  vmovaps xmm5, [rsp+0x50]
0000798fc6fd42f8  vmovaps xmm6, [rsp+0x60]
0000798fc6fd42fe  vmovaps xmm7, [rsp+0x70]
0000798fc6fd4304  vmovaps xmm8, [rsp+0x80]
0000798fc6fd430d  vmovaps xmm10, [rsp+0x90]
0000798fc6fd4316  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd431f  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd4328  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd4331  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd433a  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd4343  add rsp, 0xF0
0000798fc6fd434a  pop r11
0000798fc6fd434c  pop r10
0000798fc6fd434e  pop r9
0000798fc6fd4350  pop r8
0000798fc6fd4352  pop rsi
0000798fc6fd4353  pop rdi
0000798fc6fd4354  pop rdx
0000798fc6fd4355  pop rcx
0000798fc6fd4356  pop rax
0000798fc6fd4357  add rsp, 0x08
0000798fc6fd435b  jmp 0x0000798FC6FD00DD
0000798fc6fd4360  sub rsp, 0x08
0000798fc6fd4364  push rax
0000798fc6fd4365  push rcx
0000798fc6fd4366  push rdx
0000798fc6fd4367  push rdi
0000798fc6fd4368  push rsi
0000798fc6fd4369  push r8
0000798fc6fd436b  push r9
0000798fc6fd436d  push r10
0000798fc6fd436f  push r11
0000798fc6fd4371  sub rsp, 0xF0
0000798fc6fd4378  vmovaps [rsp], xmm0
0000798fc6fd437d  vmovaps [rsp+0x10], xmm1
0000798fc6fd4383  vmovaps [rsp+0x20], xmm2
0000798fc6fd4389  vmovaps [rsp+0x30], xmm3
0000798fc6fd438f  vmovaps [rsp+0x40], xmm4
0000798fc6fd4395  vmovaps [rsp+0x50], xmm5
0000798fc6fd439b  vmovaps [rsp+0x60], xmm6
0000798fc6fd43a1  vmovaps [rsp+0x70], xmm7
0000798fc6fd43a7  vmovaps [rsp+0x80], xmm8
0000798fc6fd43b0  vmovaps [rsp+0x90], xmm9
0000798fc6fd43b9  vmovaps [rsp+0xA0], xmm10
0000798fc6fd43c2  vmovaps [rsp+0xB0], xmm11
0000798fc6fd43cb  vmovaps [rsp+0xC0], xmm13
0000798fc6fd43d4  vmovaps [rsp+0xD0], xmm14
0000798fc6fd43dd  vmovaps [rsp+0xE0], xmm15
0000798fc6fd43e6  sub rsp, 0x30
0000798fc6fd43ea  movaps [rsp], xmm12
0000798fc6fd43ef  movaps [rsp+0x10], xmm15
0000798fc6fd43f5  movaps [rsp+0x20], xmm11
0000798fc6fd43fb  lea rdi, [rsp]
0000798fc6fd43ff  mov esi, 0x00
0000798fc6fd4404  mov rax, 0x63E558B23530
0000798fc6fd440e  call rax
0000798fc6fd4410  movaps xmm12, [rsp]
0000798fc6fd4415  add rsp, 0x30
0000798fc6fd4419  vmovaps xmm0, [rsp]
0000798fc6fd441e  vmovaps xmm1, [rsp+0x10]
0000798fc6fd4424  vmovaps xmm2, [rsp+0x20]
0000798fc6fd442a  vmovaps xmm3, [rsp+0x30]
0000798fc6fd4430  vmovaps xmm4, [rsp+0x40]
0000798fc6fd4436  vmovaps xmm5, [rsp+0x50]
0000798fc6fd443c  vmovaps xmm6, [rsp+0x60]
0000798fc6fd4442  vmovaps xmm7, [rsp+0x70]
0000798fc6fd4448  vmovaps xmm8, [rsp+0x80]
0000798fc6fd4451  vmovaps xmm9, [rsp+0x90]
0000798fc6fd445a  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd4463  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd446c  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd4475  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd447e  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd4487  add rsp, 0xF0
0000798fc6fd448e  pop r11
0000798fc6fd4490  pop r10
0000798fc6fd4492  pop r9
0000798fc6fd4494  pop r8
0000798fc6fd4496  pop rsi
0000798fc6fd4497  pop rdi
0000798fc6fd4498  pop rdx
0000798fc6fd4499  pop rcx
0000798fc6fd449a  pop rax
0000798fc6fd449b  add rsp, 0x08
0000798fc6fd449f  jmp 0x0000798FC6FD00F7
0000798fc6fd44a4  sub rsp, 0x08
0000798fc6fd44a8  push rax
0000798fc6fd44a9  push rcx
0000798fc6fd44aa  push rdx
0000798fc6fd44ab  push rdi
0000798fc6fd44ac  push rsi
0000798fc6fd44ad  push r8
0000798fc6fd44af  push r9
0000798fc6fd44b1  push r10
0000798fc6fd44b3  push r11
0000798fc6fd44b5  sub rsp, 0xF0
0000798fc6fd44bc  vmovaps [rsp], xmm0
0000798fc6fd44c1  vmovaps [rsp+0x10], xmm1
0000798fc6fd44c7  vmovaps [rsp+0x20], xmm2
0000798fc6fd44cd  vmovaps [rsp+0x30], xmm3
0000798fc6fd44d3  vmovaps [rsp+0x40], xmm4
0000798fc6fd44d9  vmovaps [rsp+0x50], xmm5
0000798fc6fd44df  vmovaps [rsp+0x60], xmm6
0000798fc6fd44e5  vmovaps [rsp+0x70], xmm7
0000798fc6fd44eb  vmovaps [rsp+0x80], xmm8
0000798fc6fd44f4  vmovaps [rsp+0x90], xmm9
0000798fc6fd44fd  vmovaps [rsp+0xA0], xmm10
0000798fc6fd4506  vmovaps [rsp+0xB0], xmm12
0000798fc6fd450f  vmovaps [rsp+0xC0], xmm13
0000798fc6fd4518  vmovaps [rsp+0xD0], xmm14
0000798fc6fd4521  vmovaps [rsp+0xE0], xmm15
0000798fc6fd452a  sub rsp, 0x30
0000798fc6fd452e  movaps [rsp], xmm11
0000798fc6fd4533  movaps [rsp+0x10], xmm7
0000798fc6fd4538  movaps [rsp+0x20], xmm15
0000798fc6fd453e  lea rdi, [rsp]
0000798fc6fd4542  mov esi, 0x00
0000798fc6fd4547  mov rax, 0x63E558B23530
0000798fc6fd4551  call rax
0000798fc6fd4553  movaps xmm11, [rsp]
0000798fc6fd4558  add rsp, 0x30
0000798fc6fd455c  vmovaps xmm0, [rsp]
0000798fc6fd4561  vmovaps xmm1, [rsp+0x10]
0000798fc6fd4567  vmovaps xmm2, [rsp+0x20]
0000798fc6fd456d  vmovaps xmm3, [rsp+0x30]
0000798fc6fd4573  vmovaps xmm4, [rsp+0x40]
0000798fc6fd4579  vmovaps xmm5, [rsp+0x50]
0000798fc6fd457f  vmovaps xmm6, [rsp+0x60]
0000798fc6fd4585  vmovaps xmm7, [rsp+0x70]
0000798fc6fd458b  vmovaps xmm8, [rsp+0x80]
0000798fc6fd4594  vmovaps xmm9, [rsp+0x90]
0000798fc6fd459d  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd45a6  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd45af  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd45b8  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd45c1  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd45ca  add rsp, 0xF0
0000798fc6fd45d1  pop r11
0000798fc6fd45d3  pop r10
0000798fc6fd45d5  pop r9
0000798fc6fd45d7  pop r8
0000798fc6fd45d9  pop rsi
0000798fc6fd45da  pop rdi
0000798fc6fd45db  pop rdx
0000798fc6fd45dc  pop rcx
0000798fc6fd45dd  pop rax
0000798fc6fd45de  add rsp, 0x08
0000798fc6fd45e2  jmp 0x0000798FC6FD0123
0000798fc6fd45e7  sub rsp, 0x08
0000798fc6fd45eb  push rax
0000798fc6fd45ec  push rcx
0000798fc6fd45ed  push rdx
0000798fc6fd45ee  push rdi
0000798fc6fd45ef  push rsi
0000798fc6fd45f0  push r8
0000798fc6fd45f2  push r9
0000798fc6fd45f4  push r10
0000798fc6fd45f6  push r11
0000798fc6fd45f8  sub rsp, 0xF0
0000798fc6fd45ff  vmovaps [rsp], xmm0
0000798fc6fd4604  vmovaps [rsp+0x10], xmm1
0000798fc6fd460a  vmovaps [rsp+0x20], xmm2
0000798fc6fd4610  vmovaps [rsp+0x30], xmm3
0000798fc6fd4616  vmovaps [rsp+0x40], xmm4
0000798fc6fd461c  vmovaps [rsp+0x50], xmm5
0000798fc6fd4622  vmovaps [rsp+0x60], xmm6
0000798fc6fd4628  vmovaps [rsp+0x70], xmm7
0000798fc6fd462e  vmovaps [rsp+0x80], xmm8
0000798fc6fd4637  vmovaps [rsp+0x90], xmm9
0000798fc6fd4640  vmovaps [rsp+0xA0], xmm10
0000798fc6fd4649  vmovaps [rsp+0xB0], xmm11
0000798fc6fd4652  vmovaps [rsp+0xC0], xmm12
0000798fc6fd465b  vmovaps [rsp+0xD0], xmm13
0000798fc6fd4664  vmovaps [rsp+0xE0], xmm14
0000798fc6fd466d  sub rsp, 0x30
0000798fc6fd4671  movaps [rsp], xmm15
0000798fc6fd4676  movaps [rsp+0x10], xmm10
0000798fc6fd467c  movaps [rsp+0x20], xmm13
0000798fc6fd4682  lea rdi, [rsp]
0000798fc6fd4686  mov esi, 0x00
0000798fc6fd468b  mov rax, 0x63E558B23530
0000798fc6fd4695  call rax
0000798fc6fd4697  movaps xmm15, [rsp]
0000798fc6fd469c  add rsp, 0x30
0000798fc6fd46a0  vmovaps xmm0, [rsp]
0000798fc6fd46a5  vmovaps xmm1, [rsp+0x10]
0000798fc6fd46ab  vmovaps xmm2, [rsp+0x20]
0000798fc6fd46b1  vmovaps xmm3, [rsp+0x30]
0000798fc6fd46b7  vmovaps xmm4, [rsp+0x40]
0000798fc6fd46bd  vmovaps xmm5, [rsp+0x50]
0000798fc6fd46c3  vmovaps xmm6, [rsp+0x60]
0000798fc6fd46c9  vmovaps xmm7, [rsp+0x70]
0000798fc6fd46cf  vmovaps xmm8, [rsp+0x80]
0000798fc6fd46d8  vmovaps xmm9, [rsp+0x90]
0000798fc6fd46e1  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd46ea  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd46f3  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd46fc  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd4705  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd470e  add rsp, 0xF0
0000798fc6fd4715  pop r11
0000798fc6fd4717  pop r10
0000798fc6fd4719  pop r9
0000798fc6fd471b  pop r8
0000798fc6fd471d  pop rsi
0000798fc6fd471e  pop rdi
0000798fc6fd471f  pop rdx
0000798fc6fd4720  pop rcx
0000798fc6fd4721  pop rax
0000798fc6fd4722  add rsp, 0x08
0000798fc6fd4726  jmp 0x0000798FC6FD013D
0000798fc6fd472b  sub rsp, 0x08
0000798fc6fd472f  push rax
0000798fc6fd4730  push rcx
0000798fc6fd4731  push rdx
0000798fc6fd4732  push rdi
0000798fc6fd4733  push rsi
0000798fc6fd4734  push r8
0000798fc6fd4736  push r9
0000798fc6fd4738  push r10
0000798fc6fd473a  push r11
0000798fc6fd473c  sub rsp, 0xF0
0000798fc6fd4743  vmovaps [rsp], xmm0
0000798fc6fd4748  vmovaps [rsp+0x10], xmm1
0000798fc6fd474e  vmovaps [rsp+0x20], xmm2
0000798fc6fd4754  vmovaps [rsp+0x30], xmm3
0000798fc6fd475a  vmovaps [rsp+0x40], xmm4
0000798fc6fd4760  vmovaps [rsp+0x50], xmm5
0000798fc6fd4766  vmovaps [rsp+0x60], xmm6
0000798fc6fd476c  vmovaps [rsp+0x70], xmm7
0000798fc6fd4772  vmovaps [rsp+0x80], xmm8
0000798fc6fd477b  vmovaps [rsp+0x90], xmm9
0000798fc6fd4784  vmovaps [rsp+0xA0], xmm11
0000798fc6fd478d  vmovaps [rsp+0xB0], xmm12
0000798fc6fd4796  vmovaps [rsp+0xC0], xmm13
0000798fc6fd479f  vmovaps [rsp+0xD0], xmm14
0000798fc6fd47a8  vmovaps [rsp+0xE0], xmm15
0000798fc6fd47b1  sub rsp, 0x30
0000798fc6fd47b5  movaps [rsp], xmm10
0000798fc6fd47ba  movaps [rsp+0x10], xmm7
0000798fc6fd47bf  movaps [rsp+0x20], xmm13
0000798fc6fd47c5  lea rdi, [rsp]
0000798fc6fd47c9  mov esi, 0x00
0000798fc6fd47ce  mov rax, 0x63E558B23530
0000798fc6fd47d8  call rax
0000798fc6fd47da  movaps xmm10, [rsp]
0000798fc6fd47df  add rsp, 0x30
0000798fc6fd47e3  vmovaps xmm0, [rsp]
0000798fc6fd47e8  vmovaps xmm1, [rsp+0x10]
0000798fc6fd47ee  vmovaps xmm2, [rsp+0x20]
0000798fc6fd47f4  vmovaps xmm3, [rsp+0x30]
0000798fc6fd47fa  vmovaps xmm4, [rsp+0x40]
0000798fc6fd4800  vmovaps xmm5, [rsp+0x50]
0000798fc6fd4806  vmovaps xmm6, [rsp+0x60]
0000798fc6fd480c  vmovaps xmm7, [rsp+0x70]
0000798fc6fd4812  vmovaps xmm8, [rsp+0x80]
0000798fc6fd481b  vmovaps xmm9, [rsp+0x90]
0000798fc6fd4824  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd482d  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd4836  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd483f  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd4848  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd4851  add rsp, 0xF0
0000798fc6fd4858  pop r11
0000798fc6fd485a  pop r10
0000798fc6fd485c  pop r9
0000798fc6fd485e  pop r8
0000798fc6fd4860  pop rsi
0000798fc6fd4861  pop rdi
0000798fc6fd4862  pop rdx
0000798fc6fd4863  pop rcx
0000798fc6fd4864  pop rax
0000798fc6fd4865  add rsp, 0x08
0000798fc6fd4869  jmp 0x0000798FC6FD0169
0000798fc6fd486e  sub rsp, 0x08
0000798fc6fd4872  push rax
0000798fc6fd4873  push rcx
0000798fc6fd4874  push rdx
0000798fc6fd4875  push rdi
0000798fc6fd4876  push rsi
0000798fc6fd4877  push r8
0000798fc6fd4879  push r9
0000798fc6fd487b  push r10
0000798fc6fd487d  push r11
0000798fc6fd487f  sub rsp, 0xF0
0000798fc6fd4886  vmovaps [rsp], xmm0
0000798fc6fd488b  vmovaps [rsp+0x10], xmm1
0000798fc6fd4891  vmovaps [rsp+0x20], xmm2
0000798fc6fd4897  vmovaps [rsp+0x30], xmm3
0000798fc6fd489d  vmovaps [rsp+0x40], xmm4
0000798fc6fd48a3  vmovaps [rsp+0x50], xmm5
0000798fc6fd48a9  vmovaps [rsp+0x60], xmm6
0000798fc6fd48af  vmovaps [rsp+0x70], xmm7
0000798fc6fd48b5  vmovaps [rsp+0x80], xmm8
0000798fc6fd48be  vmovaps [rsp+0x90], xmm9
0000798fc6fd48c7  vmovaps [rsp+0xA0], xmm10
0000798fc6fd48d0  vmovaps [rsp+0xB0], xmm11
0000798fc6fd48d9  vmovaps [rsp+0xC0], xmm12
0000798fc6fd48e2  vmovaps [rsp+0xD0], xmm14
0000798fc6fd48eb  vmovaps [rsp+0xE0], xmm15
0000798fc6fd48f4  sub rsp, 0x30
0000798fc6fd48f8  movaps [rsp], xmm13
0000798fc6fd48fd  movaps [rsp+0x10], xmm1
0000798fc6fd4902  movaps [rsp+0x20], xmm8
0000798fc6fd4908  lea rdi, [rsp]
0000798fc6fd490c  mov esi, 0x00
0000798fc6fd4911  mov rax, 0x63E558B23530
0000798fc6fd491b  call rax
0000798fc6fd491d  movaps xmm13, [rsp]
0000798fc6fd4922  add rsp, 0x30
0000798fc6fd4926  vmovaps xmm0, [rsp]
0000798fc6fd492b  vmovaps xmm1, [rsp+0x10]
0000798fc6fd4931  vmovaps xmm2, [rsp+0x20]
0000798fc6fd4937  vmovaps xmm3, [rsp+0x30]
0000798fc6fd493d  vmovaps xmm4, [rsp+0x40]
0000798fc6fd4943  vmovaps xmm5, [rsp+0x50]
0000798fc6fd4949  vmovaps xmm6, [rsp+0x60]
0000798fc6fd494f  vmovaps xmm7, [rsp+0x70]
0000798fc6fd4955  vmovaps xmm8, [rsp+0x80]
0000798fc6fd495e  vmovaps xmm9, [rsp+0x90]
0000798fc6fd4967  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd4970  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd4979  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd4982  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd498b  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd4994  add rsp, 0xF0
0000798fc6fd499b  pop r11
0000798fc6fd499d  pop r10
0000798fc6fd499f  pop r9
0000798fc6fd49a1  pop r8
0000798fc6fd49a3  pop rsi
0000798fc6fd49a4  pop rdi
0000798fc6fd49a5  pop rdx
0000798fc6fd49a6  pop rcx
0000798fc6fd49a7  pop rax
0000798fc6fd49a8  add rsp, 0x08
0000798fc6fd49ac  jmp 0x0000798FC6FD0183
0000798fc6fd49b1  call 0x0000798FC6DFF430
0000798fc6fd49b6  jmp 0x0000798FC6FD018D
0000798fc6fd49bb  sub rsp, 0x08
0000798fc6fd49bf  push rax
0000798fc6fd49c0  push rcx
0000798fc6fd49c1  push rdx
0000798fc6fd49c2  push rdi
0000798fc6fd49c3  push rsi
0000798fc6fd49c4  push r8
0000798fc6fd49c6  push r9
0000798fc6fd49c8  push r10
0000798fc6fd49ca  push r11
0000798fc6fd49cc  sub rsp, 0xF0
0000798fc6fd49d3  vmovaps [rsp], xmm0
0000798fc6fd49d8  vmovaps [rsp+0x10], xmm1
0000798fc6fd49de  vmovaps [rsp+0x20], xmm2
0000798fc6fd49e4  vmovaps [rsp+0x30], xmm3
0000798fc6fd49ea  vmovaps [rsp+0x40], xmm4
0000798fc6fd49f0  vmovaps [rsp+0x50], xmm5
0000798fc6fd49f6  vmovaps [rsp+0x60], xmm6
0000798fc6fd49fc  vmovaps [rsp+0x70], xmm7
0000798fc6fd4a02  vmovaps [rsp+0x80], xmm9
0000798fc6fd4a0b  vmovaps [rsp+0x90], xmm10
0000798fc6fd4a14  vmovaps [rsp+0xA0], xmm11
0000798fc6fd4a1d  vmovaps [rsp+0xB0], xmm12
0000798fc6fd4a26  vmovaps [rsp+0xC0], xmm13
0000798fc6fd4a2f  vmovaps [rsp+0xD0], xmm14
0000798fc6fd4a38  vmovaps [rsp+0xE0], xmm15
0000798fc6fd4a41  sub rsp, 0x30
0000798fc6fd4a45  movaps [rsp], xmm8
0000798fc6fd4a4a  movaps [rsp+0x10], xmm14
0000798fc6fd4a50  movaps [rsp+0x20], xmm9
0000798fc6fd4a56  lea rdi, [rsp]
0000798fc6fd4a5a  mov esi, 0x00
0000798fc6fd4a5f  mov rax, 0x63E558B23530
0000798fc6fd4a69  call rax
0000798fc6fd4a6b  movaps xmm8, [rsp]
0000798fc6fd4a70  add rsp, 0x30
0000798fc6fd4a74  vmovaps xmm0, [rsp]
0000798fc6fd4a79  vmovaps xmm1, [rsp+0x10]
0000798fc6fd4a7f  vmovaps xmm2, [rsp+0x20]
0000798fc6fd4a85  vmovaps xmm3, [rsp+0x30]
0000798fc6fd4a8b  vmovaps xmm4, [rsp+0x40]
0000798fc6fd4a91  vmovaps xmm5, [rsp+0x50]
0000798fc6fd4a97  vmovaps xmm6, [rsp+0x60]
0000798fc6fd4a9d  vmovaps xmm7, [rsp+0x70]
0000798fc6fd4aa3  vmovaps xmm9, [rsp+0x80]
0000798fc6fd4aac  vmovaps xmm10, [rsp+0x90]
0000798fc6fd4ab5  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd4abe  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd4ac7  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd4ad0  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd4ad9  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd4ae2  add rsp, 0xF0
0000798fc6fd4ae9  pop r11
0000798fc6fd4aeb  pop r10
0000798fc6fd4aed  pop r9
0000798fc6fd4aef  pop r8
0000798fc6fd4af1  pop rsi
0000798fc6fd4af2  pop rdi
0000798fc6fd4af3  pop rdx
0000798fc6fd4af4  pop rcx
0000798fc6fd4af5  pop rax
0000798fc6fd4af6  add rsp, 0x08
0000798fc6fd4afa  jmp 0x0000798FC6FD01AF
0000798fc6fd4aff  sub rsp, 0x08
0000798fc6fd4b03  push rax
0000798fc6fd4b04  push rcx
0000798fc6fd4b05  push rdx
0000798fc6fd4b06  push rdi
0000798fc6fd4b07  push rsi
0000798fc6fd4b08  push r8
0000798fc6fd4b0a  push r9
0000798fc6fd4b0c  push r10
0000798fc6fd4b0e  push r11
0000798fc6fd4b10  sub rsp, 0xF0
0000798fc6fd4b17  vmovaps [rsp], xmm0
0000798fc6fd4b1c  vmovaps [rsp+0x10], xmm1
0000798fc6fd4b22  vmovaps [rsp+0x20], xmm2
0000798fc6fd4b28  vmovaps [rsp+0x30], xmm3
0000798fc6fd4b2e  vmovaps [rsp+0x40], xmm4
0000798fc6fd4b34  vmovaps [rsp+0x50], xmm5
0000798fc6fd4b3a  vmovaps [rsp+0x60], xmm6
0000798fc6fd4b40  vmovaps [rsp+0x70], xmm7
0000798fc6fd4b46  vmovaps [rsp+0x80], xmm8
0000798fc6fd4b4f  vmovaps [rsp+0x90], xmm10
0000798fc6fd4b58  vmovaps [rsp+0xA0], xmm11
0000798fc6fd4b61  vmovaps [rsp+0xB0], xmm12
0000798fc6fd4b6a  vmovaps [rsp+0xC0], xmm13
0000798fc6fd4b73  vmovaps [rsp+0xD0], xmm14
0000798fc6fd4b7c  vmovaps [rsp+0xE0], xmm15
0000798fc6fd4b85  sub rsp, 0x30
0000798fc6fd4b89  movaps [rsp], xmm9
0000798fc6fd4b8e  movaps [rsp+0x10], xmm1
0000798fc6fd4b93  movaps [rsp+0x20], xmm14
0000798fc6fd4b99  lea rdi, [rsp]
0000798fc6fd4b9d  mov esi, 0x00
0000798fc6fd4ba2  mov rax, 0x63E558B23530
0000798fc6fd4bac  call rax
0000798fc6fd4bae  movaps xmm9, [rsp]
0000798fc6fd4bb3  add rsp, 0x30
0000798fc6fd4bb7  vmovaps xmm0, [rsp]
0000798fc6fd4bbc  vmovaps xmm1, [rsp+0x10]
0000798fc6fd4bc2  vmovaps xmm2, [rsp+0x20]
0000798fc6fd4bc8  vmovaps xmm3, [rsp+0x30]
0000798fc6fd4bce  vmovaps xmm4, [rsp+0x40]
0000798fc6fd4bd4  vmovaps xmm5, [rsp+0x50]
0000798fc6fd4bda  vmovaps xmm6, [rsp+0x60]
0000798fc6fd4be0  vmovaps xmm7, [rsp+0x70]
0000798fc6fd4be6  vmovaps xmm8, [rsp+0x80]
0000798fc6fd4bef  vmovaps xmm10, [rsp+0x90]
0000798fc6fd4bf8  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd4c01  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd4c0a  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd4c13  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd4c1c  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd4c25  add rsp, 0xF0
0000798fc6fd4c2c  pop r11
0000798fc6fd4c2e  pop r10
0000798fc6fd4c30  pop r9
0000798fc6fd4c32  pop r8
0000798fc6fd4c34  pop rsi
0000798fc6fd4c35  pop rdi
0000798fc6fd4c36  pop rdx
0000798fc6fd4c37  pop rcx
0000798fc6fd4c38  pop rax
0000798fc6fd4c39  add rsp, 0x08
0000798fc6fd4c3d  jmp 0x0000798FC6FD01DD
0000798fc6fd4c42  sub rsp, 0x08
0000798fc6fd4c46  push rax
0000798fc6fd4c47  push rcx
0000798fc6fd4c48  push rdx
0000798fc6fd4c49  push rdi
0000798fc6fd4c4a  push rsi
0000798fc6fd4c4b  push r8
0000798fc6fd4c4d  push r9
0000798fc6fd4c4f  push r10
0000798fc6fd4c51  push r11
0000798fc6fd4c53  sub rsp, 0xF0
0000798fc6fd4c5a  vmovaps [rsp], xmm0
0000798fc6fd4c5f  vmovaps [rsp+0x10], xmm1
0000798fc6fd4c65  vmovaps [rsp+0x20], xmm2
0000798fc6fd4c6b  vmovaps [rsp+0x30], xmm3
0000798fc6fd4c71  vmovaps [rsp+0x40], xmm4
0000798fc6fd4c77  vmovaps [rsp+0x50], xmm5
0000798fc6fd4c7d  vmovaps [rsp+0x60], xmm6
0000798fc6fd4c83  vmovaps [rsp+0x70], xmm7
0000798fc6fd4c89  vmovaps [rsp+0x80], xmm8
0000798fc6fd4c92  vmovaps [rsp+0x90], xmm9
0000798fc6fd4c9b  vmovaps [rsp+0xA0], xmm10
0000798fc6fd4ca4  vmovaps [rsp+0xB0], xmm11
0000798fc6fd4cad  vmovaps [rsp+0xC0], xmm12
0000798fc6fd4cb6  vmovaps [rsp+0xD0], xmm13
0000798fc6fd4cbf  vmovaps [rsp+0xE0], xmm15
0000798fc6fd4cc8  sub rsp, 0x30
0000798fc6fd4ccc  movaps [rsp], xmm14
0000798fc6fd4cd1  movaps [rsp+0x10], xmm4
0000798fc6fd4cd6  movaps [rsp+0x20], xmm1
0000798fc6fd4cdb  lea rdi, [rsp]
0000798fc6fd4cdf  mov esi, 0x00
0000798fc6fd4ce4  mov rax, 0x63E558B23530
0000798fc6fd4cee  call rax
0000798fc6fd4cf0  movaps xmm14, [rsp]
0000798fc6fd4cf5  add rsp, 0x30
0000798fc6fd4cf9  vmovaps xmm0, [rsp]
0000798fc6fd4cfe  vmovaps xmm1, [rsp+0x10]
0000798fc6fd4d04  vmovaps xmm2, [rsp+0x20]
0000798fc6fd4d0a  vmovaps xmm3, [rsp+0x30]
0000798fc6fd4d10  vmovaps xmm4, [rsp+0x40]
0000798fc6fd4d16  vmovaps xmm5, [rsp+0x50]
0000798fc6fd4d1c  vmovaps xmm6, [rsp+0x60]
0000798fc6fd4d22  vmovaps xmm7, [rsp+0x70]
0000798fc6fd4d28  vmovaps xmm8, [rsp+0x80]
0000798fc6fd4d31  vmovaps xmm9, [rsp+0x90]
0000798fc6fd4d3a  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd4d43  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd4d4c  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd4d55  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd4d5e  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd4d67  add rsp, 0xF0
0000798fc6fd4d6e  pop r11
0000798fc6fd4d70  pop r10
0000798fc6fd4d72  pop r9
0000798fc6fd4d74  pop r8
0000798fc6fd4d76  pop rsi
0000798fc6fd4d77  pop rdi
0000798fc6fd4d78  pop rdx
0000798fc6fd4d79  pop rcx
0000798fc6fd4d7a  pop rax
0000798fc6fd4d7b  add rsp, 0x08
0000798fc6fd4d7f  jmp 0x0000798FC6FD0203
0000798fc6fd4d84  sub rsp, 0x08
0000798fc6fd4d88  push rax
0000798fc6fd4d89  push rcx
0000798fc6fd4d8a  push rdx
0000798fc6fd4d8b  push rdi
0000798fc6fd4d8c  push rsi
0000798fc6fd4d8d  push r8
0000798fc6fd4d8f  push r9
0000798fc6fd4d91  push r10
0000798fc6fd4d93  push r11
0000798fc6fd4d95  sub rsp, 0xF0
0000798fc6fd4d9c  vmovaps [rsp], xmm0
0000798fc6fd4da1  vmovaps [rsp+0x10], xmm2
0000798fc6fd4da7  vmovaps [rsp+0x20], xmm3
0000798fc6fd4dad  vmovaps [rsp+0x30], xmm4
0000798fc6fd4db3  vmovaps [rsp+0x40], xmm5
0000798fc6fd4db9  vmovaps [rsp+0x50], xmm6
0000798fc6fd4dbf  vmovaps [rsp+0x60], xmm7
0000798fc6fd4dc5  vmovaps [rsp+0x70], xmm8
0000798fc6fd4dcb  vmovaps [rsp+0x80], xmm9
0000798fc6fd4dd4  vmovaps [rsp+0x90], xmm10
0000798fc6fd4ddd  vmovaps [rsp+0xA0], xmm11
0000798fc6fd4de6  vmovaps [rsp+0xB0], xmm12
0000798fc6fd4def  vmovaps [rsp+0xC0], xmm13
0000798fc6fd4df8  vmovaps [rsp+0xD0], xmm14
0000798fc6fd4e01  vmovaps [rsp+0xE0], xmm15
0000798fc6fd4e0a  sub rsp, 0x30
0000798fc6fd4e0e  movaps [rsp], xmm1
0000798fc6fd4e12  movaps [rsp+0x10], xmm12
0000798fc6fd4e18  movaps [rsp+0x20], xmm11
0000798fc6fd4e1e  lea rdi, [rsp]
0000798fc6fd4e22  mov esi, 0x00
0000798fc6fd4e27  mov rax, 0x63E558B23530
0000798fc6fd4e31  call rax
0000798fc6fd4e33  movaps xmm1, [rsp]
0000798fc6fd4e37  add rsp, 0x30
0000798fc6fd4e3b  vmovaps xmm0, [rsp]
0000798fc6fd4e40  vmovaps xmm2, [rsp+0x10]
0000798fc6fd4e46  vmovaps xmm3, [rsp+0x20]
0000798fc6fd4e4c  vmovaps xmm4, [rsp+0x30]
0000798fc6fd4e52  vmovaps xmm5, [rsp+0x40]
0000798fc6fd4e58  vmovaps xmm6, [rsp+0x50]
0000798fc6fd4e5e  vmovaps xmm7, [rsp+0x60]
0000798fc6fd4e64  vmovaps xmm8, [rsp+0x70]
0000798fc6fd4e6a  vmovaps xmm9, [rsp+0x80]
0000798fc6fd4e73  vmovaps xmm10, [rsp+0x90]
0000798fc6fd4e7c  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd4e85  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd4e8e  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd4e97  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd4ea0  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd4ea9  add rsp, 0xF0
0000798fc6fd4eb0  pop r11
0000798fc6fd4eb2  pop r10
0000798fc6fd4eb4  pop r9
0000798fc6fd4eb6  pop r8
0000798fc6fd4eb8  pop rsi
0000798fc6fd4eb9  pop rdi
0000798fc6fd4eba  pop rdx
0000798fc6fd4ebb  pop rcx
0000798fc6fd4ebc  pop rax
0000798fc6fd4ebd  add rsp, 0x08
0000798fc6fd4ec1  jmp 0x0000798FC6FD0224
0000798fc6fd4ec6  call 0x0000798FC6EE20A0
0000798fc6fd4ecb  jmp 0x0000798FC6FD0232
0000798fc6fd4ed0  call 0x0000798FC6E09D70
0000798fc6fd4ed5  jmp 0x0000798FC6FD023C
0000798fc6fd4eda  sub rsp, 0x08
0000798fc6fd4ede  push rax
0000798fc6fd4edf  push rcx
0000798fc6fd4ee0  push rdx
0000798fc6fd4ee1  push rdi
0000798fc6fd4ee2  push rsi
0000798fc6fd4ee3  push r8
0000798fc6fd4ee5  push r9
0000798fc6fd4ee7  push r10
0000798fc6fd4ee9  push r11
0000798fc6fd4eeb  sub rsp, 0xF0
0000798fc6fd4ef2  vmovaps [rsp], xmm0
0000798fc6fd4ef7  vmovaps [rsp+0x10], xmm1
0000798fc6fd4efd  vmovaps [rsp+0x20], xmm2
0000798fc6fd4f03  vmovaps [rsp+0x30], xmm3
0000798fc6fd4f09  vmovaps [rsp+0x40], xmm4
0000798fc6fd4f0f  vmovaps [rsp+0x50], xmm5
0000798fc6fd4f15  vmovaps [rsp+0x60], xmm6
0000798fc6fd4f1b  vmovaps [rsp+0x70], xmm8
0000798fc6fd4f21  vmovaps [rsp+0x80], xmm9
0000798fc6fd4f2a  vmovaps [rsp+0x90], xmm10
0000798fc6fd4f33  vmovaps [rsp+0xA0], xmm11
0000798fc6fd4f3c  vmovaps [rsp+0xB0], xmm12
0000798fc6fd4f45  vmovaps [rsp+0xC0], xmm13
0000798fc6fd4f4e  vmovaps [rsp+0xD0], xmm14
0000798fc6fd4f57  vmovaps [rsp+0xE0], xmm15
0000798fc6fd4f60  sub rsp, 0x30
0000798fc6fd4f64  movaps [rsp], xmm7
0000798fc6fd4f68  movaps [rsp+0x10], xmm15
0000798fc6fd4f6e  movaps [rsp+0x20], xmm10
0000798fc6fd4f74  lea rdi, [rsp]
0000798fc6fd4f78  mov esi, 0x00
0000798fc6fd4f7d  mov rax, 0x63E558B23530
0000798fc6fd4f87  call rax
0000798fc6fd4f89  movaps xmm7, [rsp]
0000798fc6fd4f8d  add rsp, 0x30
0000798fc6fd4f91  vmovaps xmm0, [rsp]
0000798fc6fd4f96  vmovaps xmm1, [rsp+0x10]
0000798fc6fd4f9c  vmovaps xmm2, [rsp+0x20]
0000798fc6fd4fa2  vmovaps xmm3, [rsp+0x30]
0000798fc6fd4fa8  vmovaps xmm4, [rsp+0x40]
0000798fc6fd4fae  vmovaps xmm5, [rsp+0x50]
0000798fc6fd4fb4  vmovaps xmm6, [rsp+0x60]
0000798fc6fd4fba  vmovaps xmm8, [rsp+0x70]
0000798fc6fd4fc0  vmovaps xmm9, [rsp+0x80]
0000798fc6fd4fc9  vmovaps xmm10, [rsp+0x90]
0000798fc6fd4fd2  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd4fdb  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd4fe4  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd4fed  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd4ff6  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd4fff  add rsp, 0xF0
0000798fc6fd5006  pop r11
0000798fc6fd5008  pop r10
0000798fc6fd500a  pop r9
0000798fc6fd500c  pop r8
0000798fc6fd500e  pop rsi
0000798fc6fd500f  pop rdi
0000798fc6fd5010  pop rdx
0000798fc6fd5011  pop rcx
0000798fc6fd5012  pop rax
0000798fc6fd5013  add rsp, 0x08
0000798fc6fd5017  jmp 0x0000798FC6FD025D
0000798fc6fd501c  sub rsp, 0x08
0000798fc6fd5020  push rax
0000798fc6fd5021  push rcx
0000798fc6fd5022  push rdx
0000798fc6fd5023  push rdi
0000798fc6fd5024  push rsi
0000798fc6fd5025  push r8
0000798fc6fd5027  push r9
0000798fc6fd5029  push r10
0000798fc6fd502b  push r11
0000798fc6fd502d  sub rsp, 0xF0
0000798fc6fd5034  vmovaps [rsp], xmm0
0000798fc6fd5039  vmovaps [rsp+0x10], xmm1
0000798fc6fd503f  vmovaps [rsp+0x20], xmm2
0000798fc6fd5045  vmovaps [rsp+0x30], xmm3
0000798fc6fd504b  vmovaps [rsp+0x40], xmm4
0000798fc6fd5051  vmovaps [rsp+0x50], xmm5
0000798fc6fd5057  vmovaps [rsp+0x60], xmm6
0000798fc6fd505d  vmovaps [rsp+0x70], xmm7
0000798fc6fd5063  vmovaps [rsp+0x80], xmm8
0000798fc6fd506c  vmovaps [rsp+0x90], xmm9
0000798fc6fd5075  vmovaps [rsp+0xA0], xmm11
0000798fc6fd507e  vmovaps [rsp+0xB0], xmm12
0000798fc6fd5087  vmovaps [rsp+0xC0], xmm13
0000798fc6fd5090  vmovaps [rsp+0xD0], xmm14
0000798fc6fd5099  vmovaps [rsp+0xE0], xmm15
0000798fc6fd50a2  sub rsp, 0x30
0000798fc6fd50a6  movaps [rsp], xmm10
0000798fc6fd50ab  movaps [rsp+0x10], xmm11
0000798fc6fd50b1  movaps [rsp+0x20], xmm15
0000798fc6fd50b7  lea rdi, [rsp]
0000798fc6fd50bb  mov esi, 0x00
0000798fc6fd50c0  mov rax, 0x63E558B23530
0000798fc6fd50ca  call rax
0000798fc6fd50cc  movaps xmm10, [rsp]
0000798fc6fd50d1  add rsp, 0x30
0000798fc6fd50d5  vmovaps xmm0, [rsp]
0000798fc6fd50da  vmovaps xmm1, [rsp+0x10]
0000798fc6fd50e0  vmovaps xmm2, [rsp+0x20]
0000798fc6fd50e6  vmovaps xmm3, [rsp+0x30]
0000798fc6fd50ec  vmovaps xmm4, [rsp+0x40]
0000798fc6fd50f2  vmovaps xmm5, [rsp+0x50]
0000798fc6fd50f8  vmovaps xmm6, [rsp+0x60]
0000798fc6fd50fe  vmovaps xmm7, [rsp+0x70]
0000798fc6fd5104  vmovaps xmm8, [rsp+0x80]
0000798fc6fd510d  vmovaps xmm9, [rsp+0x90]
0000798fc6fd5116  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd511f  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd5128  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd5131  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd513a  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd5143  add rsp, 0xF0
0000798fc6fd514a  pop r11
0000798fc6fd514c  pop r10
0000798fc6fd514e  pop r9
0000798fc6fd5150  pop r8
0000798fc6fd5152  pop rsi
0000798fc6fd5153  pop rdi
0000798fc6fd5154  pop rdx
0000798fc6fd5155  pop rcx
0000798fc6fd5156  pop rax
0000798fc6fd5157  add rsp, 0x08
0000798fc6fd515b  jmp 0x0000798FC6FD028B
0000798fc6fd5160  sub rsp, 0x08
0000798fc6fd5164  push rax
0000798fc6fd5165  push rcx
0000798fc6fd5166  push rdx
0000798fc6fd5167  push rdi
0000798fc6fd5168  push rsi
0000798fc6fd5169  push r8
0000798fc6fd516b  push r9
0000798fc6fd516d  push r10
0000798fc6fd516f  push r11
0000798fc6fd5171  sub rsp, 0xF0
0000798fc6fd5178  vmovaps [rsp], xmm0
0000798fc6fd517d  vmovaps [rsp+0x10], xmm1
0000798fc6fd5183  vmovaps [rsp+0x20], xmm2
0000798fc6fd5189  vmovaps [rsp+0x30], xmm3
0000798fc6fd518f  vmovaps [rsp+0x40], xmm4
0000798fc6fd5195  vmovaps [rsp+0x50], xmm5
0000798fc6fd519b  vmovaps [rsp+0x60], xmm6
0000798fc6fd51a1  vmovaps [rsp+0x70], xmm7
0000798fc6fd51a7  vmovaps [rsp+0x80], xmm8
0000798fc6fd51b0  vmovaps [rsp+0x90], xmm9
0000798fc6fd51b9  vmovaps [rsp+0xA0], xmm10
0000798fc6fd51c2  vmovaps [rsp+0xB0], xmm12
0000798fc6fd51cb  vmovaps [rsp+0xC0], xmm13
0000798fc6fd51d4  vmovaps [rsp+0xD0], xmm14
0000798fc6fd51dd  vmovaps [rsp+0xE0], xmm15
0000798fc6fd51e6  sub rsp, 0x30
0000798fc6fd51ea  movaps [rsp], xmm11
0000798fc6fd51ef  movaps [rsp+0x10], xmm12
0000798fc6fd51f5  movaps [rsp+0x20], xmm15
0000798fc6fd51fb  lea rdi, [rsp]
0000798fc6fd51ff  mov esi, 0x00
0000798fc6fd5204  mov rax, 0x63E558B23530
0000798fc6fd520e  call rax
0000798fc6fd5210  movaps xmm11, [rsp]
0000798fc6fd5215  add rsp, 0x30
0000798fc6fd5219  vmovaps xmm0, [rsp]
0000798fc6fd521e  vmovaps xmm1, [rsp+0x10]
0000798fc6fd5224  vmovaps xmm2, [rsp+0x20]
0000798fc6fd522a  vmovaps xmm3, [rsp+0x30]
0000798fc6fd5230  vmovaps xmm4, [rsp+0x40]
0000798fc6fd5236  vmovaps xmm5, [rsp+0x50]
0000798fc6fd523c  vmovaps xmm6, [rsp+0x60]
0000798fc6fd5242  vmovaps xmm7, [rsp+0x70]
0000798fc6fd5248  vmovaps xmm8, [rsp+0x80]
0000798fc6fd5251  vmovaps xmm9, [rsp+0x90]
0000798fc6fd525a  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd5263  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd526c  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd5275  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd527e  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd5287  add rsp, 0xF0
0000798fc6fd528e  pop r11
0000798fc6fd5290  pop r10
0000798fc6fd5292  pop r9
0000798fc6fd5294  pop r8
0000798fc6fd5296  pop rsi
0000798fc6fd5297  pop rdi
0000798fc6fd5298  pop rdx
0000798fc6fd5299  pop rcx
0000798fc6fd529a  pop rax
0000798fc6fd529b  add rsp, 0x08
0000798fc6fd529f  jmp 0x0000798FC6FD02B9
0000798fc6fd52a4  sub rsp, 0x08
0000798fc6fd52a8  push rax
0000798fc6fd52a9  push rcx
0000798fc6fd52aa  push rdx
0000798fc6fd52ab  push rdi
0000798fc6fd52ac  push rsi
0000798fc6fd52ad  push r8
0000798fc6fd52af  push r9
0000798fc6fd52b1  push r10
0000798fc6fd52b3  push r11
0000798fc6fd52b5  sub rsp, 0xF0
0000798fc6fd52bc  vmovaps [rsp], xmm0
0000798fc6fd52c1  vmovaps [rsp+0x10], xmm1
0000798fc6fd52c7  vmovaps [rsp+0x20], xmm2
0000798fc6fd52cd  vmovaps [rsp+0x30], xmm3
0000798fc6fd52d3  vmovaps [rsp+0x40], xmm4
0000798fc6fd52d9  vmovaps [rsp+0x50], xmm5
0000798fc6fd52df  vmovaps [rsp+0x60], xmm6
0000798fc6fd52e5  vmovaps [rsp+0x70], xmm7
0000798fc6fd52eb  vmovaps [rsp+0x80], xmm8
0000798fc6fd52f4  vmovaps [rsp+0x90], xmm9
0000798fc6fd52fd  vmovaps [rsp+0xA0], xmm10
0000798fc6fd5306  vmovaps [rsp+0xB0], xmm11
0000798fc6fd530f  vmovaps [rsp+0xC0], xmm12
0000798fc6fd5318  vmovaps [rsp+0xD0], xmm13
0000798fc6fd5321  vmovaps [rsp+0xE0], xmm14
0000798fc6fd532a  sub rsp, 0x30
0000798fc6fd532e  movaps [rsp], xmm15
0000798fc6fd5333  movaps [rsp+0x10], xmm13
0000798fc6fd5339  movaps [rsp+0x20], xmm9
0000798fc6fd533f  lea rdi, [rsp]
0000798fc6fd5343  mov esi, 0x00
0000798fc6fd5348  mov rax, 0x63E558B23530
0000798fc6fd5352  call rax
0000798fc6fd5354  movaps xmm15, [rsp]
0000798fc6fd5359  add rsp, 0x30
0000798fc6fd535d  vmovaps xmm0, [rsp]
0000798fc6fd5362  vmovaps xmm1, [rsp+0x10]
0000798fc6fd5368  vmovaps xmm2, [rsp+0x20]
0000798fc6fd536e  vmovaps xmm3, [rsp+0x30]
0000798fc6fd5374  vmovaps xmm4, [rsp+0x40]
0000798fc6fd537a  vmovaps xmm5, [rsp+0x50]
0000798fc6fd5380  vmovaps xmm6, [rsp+0x60]
0000798fc6fd5386  vmovaps xmm7, [rsp+0x70]
0000798fc6fd538c  vmovaps xmm8, [rsp+0x80]
0000798fc6fd5395  vmovaps xmm9, [rsp+0x90]
0000798fc6fd539e  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd53a7  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd53b0  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd53b9  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd53c2  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd53cb  add rsp, 0xF0
0000798fc6fd53d2  pop r11
0000798fc6fd53d4  pop r10
0000798fc6fd53d6  pop r9
0000798fc6fd53d8  pop r8
0000798fc6fd53da  pop rsi
0000798fc6fd53db  pop rdi
0000798fc6fd53dc  pop rdx
0000798fc6fd53dd  pop rcx
0000798fc6fd53de  pop rax
0000798fc6fd53df  add rsp, 0x08
0000798fc6fd53e3  jmp 0x0000798FC6FD02D4
0000798fc6fd53e8  sub rsp, 0x08
0000798fc6fd53ec  push rax
0000798fc6fd53ed  push rcx
0000798fc6fd53ee  push rdx
0000798fc6fd53ef  push rdi
0000798fc6fd53f0  push rsi
0000798fc6fd53f1  push r8
0000798fc6fd53f3  push r9
0000798fc6fd53f5  push r10
0000798fc6fd53f7  push r11
0000798fc6fd53f9  sub rsp, 0xF0
0000798fc6fd5400  vmovaps [rsp], xmm0
0000798fc6fd5405  vmovaps [rsp+0x10], xmm1
0000798fc6fd540b  vmovaps [rsp+0x20], xmm2
0000798fc6fd5411  vmovaps [rsp+0x30], xmm3
0000798fc6fd5417  vmovaps [rsp+0x40], xmm4
0000798fc6fd541d  vmovaps [rsp+0x50], xmm5
0000798fc6fd5423  vmovaps [rsp+0x60], xmm6
0000798fc6fd5429  vmovaps [rsp+0x70], xmm7
0000798fc6fd542f  vmovaps [rsp+0x80], xmm8
0000798fc6fd5438  vmovaps [rsp+0x90], xmm9
0000798fc6fd5441  vmovaps [rsp+0xA0], xmm10
0000798fc6fd544a  vmovaps [rsp+0xB0], xmm11
0000798fc6fd5453  vmovaps [rsp+0xC0], xmm12
0000798fc6fd545c  vmovaps [rsp+0xD0], xmm14
0000798fc6fd5465  vmovaps [rsp+0xE0], xmm15
0000798fc6fd546e  sub rsp, 0x30
0000798fc6fd5472  movaps [rsp], xmm13
0000798fc6fd5477  movaps [rsp+0x10], xmm8
0000798fc6fd547d  movaps [rsp+0x20], xmm14
0000798fc6fd5483  lea rdi, [rsp]
0000798fc6fd5487  mov esi, 0x00
0000798fc6fd548c  mov rax, 0x63E558B23530
0000798fc6fd5496  call rax
0000798fc6fd5498  movaps xmm13, [rsp]
0000798fc6fd549d  add rsp, 0x30
0000798fc6fd54a1  vmovaps xmm0, [rsp]
0000798fc6fd54a6  vmovaps xmm1, [rsp+0x10]
0000798fc6fd54ac  vmovaps xmm2, [rsp+0x20]
0000798fc6fd54b2  vmovaps xmm3, [rsp+0x30]
0000798fc6fd54b8  vmovaps xmm4, [rsp+0x40]
0000798fc6fd54be  vmovaps xmm5, [rsp+0x50]
0000798fc6fd54c4  vmovaps xmm6, [rsp+0x60]
0000798fc6fd54ca  vmovaps xmm7, [rsp+0x70]
0000798fc6fd54d0  vmovaps xmm8, [rsp+0x80]
0000798fc6fd54d9  vmovaps xmm9, [rsp+0x90]
0000798fc6fd54e2  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd54eb  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd54f4  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd54fd  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd5506  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd550f  add rsp, 0xF0
0000798fc6fd5516  pop r11
0000798fc6fd5518  pop r10
0000798fc6fd551a  pop r9
0000798fc6fd551c  pop r8
0000798fc6fd551e  pop rsi
0000798fc6fd551f  pop rdi
0000798fc6fd5520  pop rdx
0000798fc6fd5521  pop rcx
0000798fc6fd5522  pop rax
0000798fc6fd5523  add rsp, 0x08
0000798fc6fd5527  jmp 0x0000798FC6FD02F7
0000798fc6fd552c  sub rsp, 0x08
0000798fc6fd5530  push rax
0000798fc6fd5531  push rcx
0000798fc6fd5532  push rdx
0000798fc6fd5533  push rdi
0000798fc6fd5534  push rsi
0000798fc6fd5535  push r8
0000798fc6fd5537  push r9
0000798fc6fd5539  push r10
0000798fc6fd553b  push r11
0000798fc6fd553d  sub rsp, 0xF0
0000798fc6fd5544  vmovaps [rsp], xmm0
0000798fc6fd5549  vmovaps [rsp+0x10], xmm1
0000798fc6fd554f  vmovaps [rsp+0x20], xmm2
0000798fc6fd5555  vmovaps [rsp+0x30], xmm3
0000798fc6fd555b  vmovaps [rsp+0x40], xmm4
0000798fc6fd5561  vmovaps [rsp+0x50], xmm5
0000798fc6fd5567  vmovaps [rsp+0x60], xmm6
0000798fc6fd556d  vmovaps [rsp+0x70], xmm7
0000798fc6fd5573  vmovaps [rsp+0x80], xmm8
0000798fc6fd557c  vmovaps [rsp+0x90], xmm9
0000798fc6fd5585  vmovaps [rsp+0xA0], xmm10
0000798fc6fd558e  vmovaps [rsp+0xB0], xmm11
0000798fc6fd5597  vmovaps [rsp+0xC0], xmm12
0000798fc6fd55a0  vmovaps [rsp+0xD0], xmm13
0000798fc6fd55a9  vmovaps [rsp+0xE0], xmm15
0000798fc6fd55b2  sub rsp, 0x30
0000798fc6fd55b6  movaps [rsp], xmm14
0000798fc6fd55bb  movaps [rsp+0x10], xmm1
0000798fc6fd55c0  movaps [rsp+0x20], xmm10
0000798fc6fd55c6  lea rdi, [rsp]
0000798fc6fd55ca  mov esi, 0x00
0000798fc6fd55cf  mov rax, 0x63E558B23530
0000798fc6fd55d9  call rax
0000798fc6fd55db  movaps xmm14, [rsp]
0000798fc6fd55e0  add rsp, 0x30
0000798fc6fd55e4  vmovaps xmm0, [rsp]
0000798fc6fd55e9  vmovaps xmm1, [rsp+0x10]
0000798fc6fd55ef  vmovaps xmm2, [rsp+0x20]
0000798fc6fd55f5  vmovaps xmm3, [rsp+0x30]
0000798fc6fd55fb  vmovaps xmm4, [rsp+0x40]
0000798fc6fd5601  vmovaps xmm5, [rsp+0x50]
0000798fc6fd5607  vmovaps xmm6, [rsp+0x60]
0000798fc6fd560d  vmovaps xmm7, [rsp+0x70]
0000798fc6fd5613  vmovaps xmm8, [rsp+0x80]
0000798fc6fd561c  vmovaps xmm9, [rsp+0x90]
0000798fc6fd5625  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd562e  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd5637  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd5640  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd5649  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd5652  add rsp, 0xF0
0000798fc6fd5659  pop r11
0000798fc6fd565b  pop r10
0000798fc6fd565d  pop r9
0000798fc6fd565f  pop r8
0000798fc6fd5661  pop rsi
0000798fc6fd5662  pop rdi
0000798fc6fd5663  pop rdx
0000798fc6fd5664  pop rcx
0000798fc6fd5665  pop rax
0000798fc6fd5666  add rsp, 0x08
0000798fc6fd566a  jmp 0x0000798FC6FD031A
0000798fc6fd566f  sub rsp, 0x08
0000798fc6fd5673  push rax
0000798fc6fd5674  push rcx
0000798fc6fd5675  push rdx
0000798fc6fd5676  push rdi
0000798fc6fd5677  push rsi
0000798fc6fd5678  push r8
0000798fc6fd567a  push r9
0000798fc6fd567c  push r10
0000798fc6fd567e  push r11
0000798fc6fd5680  sub rsp, 0xF0
0000798fc6fd5687  vmovaps [rsp], xmm0
0000798fc6fd568c  vmovaps [rsp+0x10], xmm2
0000798fc6fd5692  vmovaps [rsp+0x20], xmm3
0000798fc6fd5698  vmovaps [rsp+0x30], xmm4
0000798fc6fd569e  vmovaps [rsp+0x40], xmm5
0000798fc6fd56a4  vmovaps [rsp+0x50], xmm6
0000798fc6fd56aa  vmovaps [rsp+0x60], xmm7
0000798fc6fd56b0  vmovaps [rsp+0x70], xmm8
0000798fc6fd56b6  vmovaps [rsp+0x80], xmm9
0000798fc6fd56bf  vmovaps [rsp+0x90], xmm10
0000798fc6fd56c8  vmovaps [rsp+0xA0], xmm11
0000798fc6fd56d1  vmovaps [rsp+0xB0], xmm12
0000798fc6fd56da  vmovaps [rsp+0xC0], xmm13
0000798fc6fd56e3  vmovaps [rsp+0xD0], xmm14
0000798fc6fd56ec  vmovaps [rsp+0xE0], xmm15
0000798fc6fd56f5  sub rsp, 0x30
0000798fc6fd56f9  movaps [rsp], xmm1
0000798fc6fd56fd  movaps [rsp+0x10], xmm7
0000798fc6fd5702  movaps [rsp+0x20], xmm11
0000798fc6fd5708  lea rdi, [rsp]
0000798fc6fd570c  mov esi, 0x00
0000798fc6fd5711  mov rax, 0x63E558B23530
0000798fc6fd571b  call rax
0000798fc6fd571d  movaps xmm1, [rsp]
0000798fc6fd5721  add rsp, 0x30
0000798fc6fd5725  vmovaps xmm0, [rsp]
0000798fc6fd572a  vmovaps xmm2, [rsp+0x10]
0000798fc6fd5730  vmovaps xmm3, [rsp+0x20]
0000798fc6fd5736  vmovaps xmm4, [rsp+0x30]
0000798fc6fd573c  vmovaps xmm5, [rsp+0x40]
0000798fc6fd5742  vmovaps xmm6, [rsp+0x50]
0000798fc6fd5748  vmovaps xmm7, [rsp+0x60]
0000798fc6fd574e  vmovaps xmm8, [rsp+0x70]
0000798fc6fd5754  vmovaps xmm9, [rsp+0x80]
0000798fc6fd575d  vmovaps xmm10, [rsp+0x90]
0000798fc6fd5766  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd576f  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd5778  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd5781  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd578a  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd5793  add rsp, 0xF0
0000798fc6fd579a  pop r11
0000798fc6fd579c  pop r10
0000798fc6fd579e  pop r9
0000798fc6fd57a0  pop r8
0000798fc6fd57a2  pop rsi
0000798fc6fd57a3  pop rdi
0000798fc6fd57a4  pop rdx
0000798fc6fd57a5  pop rcx
0000798fc6fd57a6  pop rax
0000798fc6fd57a7  add rsp, 0x08
0000798fc6fd57ab  jmp 0x0000798FC6FD033B
0000798fc6fd57b0  call 0x0000798FC6E0E880
0000798fc6fd57b5  jmp 0x0000798FC6FD034E
0000798fc6fd57ba  call 0x0000798FC6E0C380
0000798fc6fd57bf  jmp 0x0000798FC6FD0359
0000798fc6fd57c4  call 0x0000798FC6E0D600
0000798fc6fd57c9  jmp 0x0000798FC6FD0364
0000798fc6fd57ce  call 0x0000798FC6DFF540
0000798fc6fd57d3  jmp 0x0000798FC6FD036F
0000798fc6fd57d8  int3
0000798fc6fd57d9  nop [rax], eax
0000798fc6fd57e0  mov rax, [r15+0x40]
0000798fc6fd57e4  mov r14, [r15+0x58]
0000798fc6fd57e8  lea r12, [rax+r14*1]
0000798fc6fd57ec  movaps xmm1, [r15+0x1D0]
0000798fc6fd57f4  vmovaps [rsp+0x10], xmm1
0000798fc6fd57fa  vmovaps xmm15, [rsp+0x10]
0000798fc6fd5800  por xmm1, xmm15
0000798fc6fd5805  movaps xmm14, [r15+0x1A0]
0000798fc6fd580d  vmovaps [rsp+0x10], xmm14
0000798fc6fd5813  vmovaps xmm13, [rsp+0x10]
0000798fc6fd5819  por xmm14, xmm13
0000798fc6fd581e  lea rax, [r12+0x30]
0000798fc6fd5823  mov r11, [r13+rax*1]
0000798fc6fd5828  lea rax, [r12+0x38]
0000798fc6fd582d  mov r10, [r13+rax*1]
0000798fc6fd5832  movq xmm13, r11
0000798fc6fd5837  movq xmm12, r10
0000798fc6fd583c  movq xmm13, xmm13
0000798fc6fd5841  vmovaps [rsp+0x10], xmm13
0000798fc6fd5847  movq xmm13, xmm13
0000798fc6fd584c  movaps [r15+0x130], xmm13
0000798fc6fd5854  movq xmm12, xmm12
0000798fc6fd5859  vmovaps [rsp+0x20], xmm12
0000798fc6fd585f  movq xmm12, xmm12
0000798fc6fd5864  movaps [r15+0x280], xmm12
0000798fc6fd586c  movaps xmm13, [r15+0x270]
0000798fc6fd5874  vmovaps [rsp+0x30], xmm13
0000798fc6fd587a  vmovaps xmm12, [rsp+0x30]
0000798fc6fd5880  por xmm13, xmm12
0000798fc6fd5885  lea rax, [r12+0x20]
0000798fc6fd588a  mov r11, [r13+rax*1]
0000798fc6fd588f  lea rax, [r12+0x28]
0000798fc6fd5894  mov r10, [r13+rax*1]
0000798fc6fd5899  movq xmm12, r11
0000798fc6fd589e  movq xmm11, r10
0000798fc6fd58a3  movq xmm12, xmm12
0000798fc6fd58a8  vmovaps [rsp+0x30], xmm12
0000798fc6fd58ae  movq xmm12, xmm12
0000798fc6fd58b3  movaps [r15+0x150], xmm12
0000798fc6fd58bb  movq xmm11, xmm11
0000798fc6fd58c0  vmovaps [rsp+0x40], xmm11
0000798fc6fd58c6  movq xmm11, xmm11
0000798fc6fd58cb  movaps [r15+0x140], xmm11
0000798fc6fd58d3  lea rax, [r12+0x10]
0000798fc6fd58d8  mov r11, [r13+rax*1]
0000798fc6fd58dd  lea rax, [r12+0x18]
0000798fc6fd58e2  mov r10, [r13+rax*1]
0000798fc6fd58e7  movq xmm12, r11
0000798fc6fd58ec  movq xmm11, r10
0000798fc6fd58f1  movq xmm12, xmm12
0000798fc6fd58f6  vmovaps [rsp+0x50], xmm12
0000798fc6fd58fc  movq xmm12, xmm12
0000798fc6fd5901  movaps [r15+0x170], xmm12
0000798fc6fd5909  movq xmm11, xmm11
0000798fc6fd590e  vmovaps [rsp+0x60], xmm11
0000798fc6fd5914  movq xmm11, xmm11
0000798fc6fd5919  movaps [r15+0x160], xmm11
0000798fc6fd5921  mov rax, [r13+r12*1]
0000798fc6fd5926  vmovq xmm12, rax
0000798fc6fd592b  vpbroadcastq xmm12, xmm12
0000798fc6fd5930  lea rax, [r12+0x08]
0000798fc6fd5935  mov r12, [r13+rax*1]
0000798fc6fd593a  movq xmm11, r12
0000798fc6fd593f  movaps [r15+0x230], xmm11
0000798fc6fd5947  mov rax, [r15+0xF8]
0000798fc6fd594e  lea r12, [rax+0x50]
0000798fc6fd5952  movups xmm11, [r13+r12*1]
0000798fc6fd5958  lea r12, [rax+0x60]
0000798fc6fd595c  movups xmm10, [r13+r12*1]
0000798fc6fd5962  lea r12, [rax+0x30]
0000798fc6fd5966  movups xmm9, [r13+r12*1]
0000798fc6fd596c  mov r12, [r15+0x50]
0000798fc6fd5970  lea r11, [r12+r14*1]
0000798fc6fd5974  mov [r15+0x60], r11
0000798fc6fd5978  lea r12, [r14+0x40]
0000798fc6fd597c  mov [r15+0x58], r12
0000798fc6fd5980  movaps xmm8, xmm12
0000798fc6fd5984  mulpd xmm8, xmm15
0000798fc6fd5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000798fc6fd598f  ptest xmm7, xmm7
0000798fc6fd5994  jnz 0x0000798FC6FD67B7
0000798fc6fd599a  movq xmm15, qword ptr [r15+0x230]
0000798fc6fd59a3  vmovaps [rsp+0x70], xmm15
0000798fc6fd59a9  vpermilpd xmm15, xmm15, 0x00
0000798fc6fd59af  movaps xmm7, xmm9
0000798fc6fd59b3  mulpd xmm7, xmm15
0000798fc6fd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000798fc6fd59bd  ptest xmm6, xmm6
0000798fc6fd59c2  jnz 0x0000798FC6FD68FB
0000798fc6fd59c8  vxorps xmm15, xmm15, xmm15
0000798fc6fd59cd  vpbroadcastq xmm15, xmm15
0000798fc6fd59d2  movaps xmm9, xmm12
0000798fc6fd59d6  mulpd xmm9, xmm10
0000798fc6fd59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000798fc6fd59e1  ptest xmm6, xmm6
0000798fc6fd59e6  jnz 0x0000798FC6FD6A3D
0000798fc6fd59ec  movaps xmm10, xmm12
0000798fc6fd59f0  mulpd xmm10, xmm11
0000798fc6fd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000798fc6fd59fb  ptest xmm6, xmm6
0000798fc6fd5a00  jnz 0x0000798FC6FD6B81
0000798fc6fd5a06  movaps xmm11, [r15+0x1F0]
0000798fc6fd5a0e  movaps xmm6, xmm12
0000798fc6fd5a12  mulpd xmm6, xmm11
0000798fc6fd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000798fc6fd5a1c  ptest xmm5, xmm5
0000798fc6fd5a21  jnz 0x0000798FC6FD6CC5
0000798fc6fd5a27  movaps xmm12, [r15+0x2A0]
0000798fc6fd5a2f  vmovaps [rsp+0x80], xmm12
0000798fc6fd5a38  vmovaps xmm11, [rsp+0x80]
0000798fc6fd5a41  por xmm12, xmm11
0000798fc6fd5a46  movaps xmm11, [r15+0x250]
0000798fc6fd5a4e  vmovaps [rsp+0x80], xmm11
0000798fc6fd5a57  vmovaps xmm5, [rsp+0x80]
0000798fc6fd5a60  por xmm11, xmm5
0000798fc6fd5a65  vmovaps xmm4, [rsp+0x70]
0000798fc6fd5a6b  vpermilpd xmm4, xmm4, 0x00
0000798fc6fd5a71  movaps xmm3, xmm5
0000798fc6fd5a74  mulpd xmm3, xmm4
0000798fc6fd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000798fc6fd5a7d  ptest xmm2, xmm2
0000798fc6fd5a82  jnz 0x0000798FC6FD6E07
0000798fc6fd5a88  mov [rsp+0x80], rax
0000798fc6fd5a90  xor eax, eax
0000798fc6fd5a92  mov r14d, 0x200
0000798fc6fd5a98  cmp r12, r14
0000798fc6fd5a9b  cmc
0000798fc6fd5a9c  lahf
0000798fc6fd5a9d  seto al
0000798fc6fd5aa0  mov [r15+0x108], eax
0000798fc6fd5aa7  movaps xmm5, xmm8
0000798fc6fd5aab  addpd xmm5, xmm15
0000798fc6fd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000798fc6fd5ab5  ptest xmm4, xmm4
0000798fc6fd5aba  jnz 0x0000798FC6FD6F47
0000798fc6fd5ac0  movaps xmm8, [r15+0x1B0]
0000798fc6fd5ac8  movaps xmm4, xmm9
0000798fc6fd5acc  addpd xmm4, xmm8
0000798fc6fd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000798fc6fd5ad6  ptest xmm2, xmm2
0000798fc6fd5adb  jnz 0x0000798FC6FD7089
0000798fc6fd5ae1  movaps xmm9, xmm10
0000798fc6fd5ae5  addpd xmm9, xmm8
0000798fc6fd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000798fc6fd5af0  ptest xmm2, xmm2
0000798fc6fd5af5  jnz 0x0000798FC6FD71CB
0000798fc6fd5afb  movaps xmm10, [r15+0x2F0]
0000798fc6fd5b03  vmovaps [rsp+0x90], xmm10
0000798fc6fd5b0c  vmovaps xmm8, [rsp+0x90]
0000798fc6fd5b15  por xmm10, xmm8
0000798fc6fd5b1a  movaps xmm8, [r15+0x2E0]
0000798fc6fd5b22  vmovaps [rsp+0x90], xmm8
0000798fc6fd5b2b  vmovaps xmm2, [rsp+0x90]
0000798fc6fd5b34  por xmm8, xmm2
0000798fc6fd5b39  movaps xmm2, [r15+0x2D0]
0000798fc6fd5b41  vmovaps [rsp+0x90], xmm2
0000798fc6fd5b4a  vmovaps [rsp+0xA0], xmm1
0000798fc6fd5b53  vmovaps xmm1, [rsp+0x90]
0000798fc6fd5b5c  por xmm2, xmm1
0000798fc6fd5b60  movaps xmm1, [r15+0x200]
0000798fc6fd5b68  vmovaps [rsp+0x90], xmm1
0000798fc6fd5b71  vmovaps [rsp+0xB0], xmm15
0000798fc6fd5b7a  vmovaps xmm15, [rsp+0x90]
0000798fc6fd5b83  por xmm1, xmm15
0000798fc6fd5b88  movaps xmm15, [r15+0x1C0]
0000798fc6fd5b90  vmovaps [rsp+0x90], xmm15
0000798fc6fd5b99  vmovaps [rsp+0xC0], xmm1
0000798fc6fd5ba2  vmovaps xmm1, [rsp+0x90]
0000798fc6fd5bab  por xmm15, xmm1
0000798fc6fd5bb0  movaps xmm1, [r15+0x190]
0000798fc6fd5bb8  vmovaps [rsp+0x90], xmm1
0000798fc6fd5bc1  vmovaps [rsp+0xD0], xmm15
0000798fc6fd5bca  vmovaps xmm15, [rsp+0x90]
0000798fc6fd5bd3  por xmm1, xmm15
0000798fc6fd5bd8  movaps xmm15, [r15+0x300]
0000798fc6fd5be0  vmovaps [rsp+0x90], xmm15
0000798fc6fd5be9  vmovaps [rsp+0xE0], xmm1
0000798fc6fd5bf2  vmovaps xmm1, [rsp+0x90]
0000798fc6fd5bfb  por xmm15, xmm1
0000798fc6fd5c00  mov rax, [rsp+0x80]
0000798fc6fd5c08  lea r14, [rax+0xA0]
0000798fc6fd5c0f  movups xmm1, [r13+r14*1]
0000798fc6fd5c15  lea r14, [rax+0xB0]
0000798fc6fd5c1c  vmovaps [rsp+0x80], xmm1
0000798fc6fd5c25  movups xmm1, [r13+r14*1]
0000798fc6fd5c2b  vmovaps [rsp+0x90], xmm1
0000798fc6fd5c34  vmovaps [rsp+0xF0], xmm15
0000798fc6fd5c3d  vmovaps xmm15, [rsp+0xB0]
0000798fc6fd5c46  vmovaps [rsp+0xB0], xmm14
0000798fc6fd5c4f  movaps xmm1, xmm6
0000798fc6fd5c52  addpd xmm1, xmm15
0000798fc6fd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000798fc6fd5c5c  ptest xmm14, xmm14
0000798fc6fd5c62  jnz 0x0000798FC6FD7323
0000798fc6fd5c68  lea r14, [rax+0xF0]
0000798fc6fd5c6f  movups xmm15, [r13+r14*1]
0000798fc6fd5c75  movaps xmm14, xmm4
0000798fc6fd5c79  addpd xmm14, xmm3
0000798fc6fd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000798fc6fd5c84  ptest xmm6, xmm6
0000798fc6fd5c89  jnz 0x0000798FC6FD746E
0000798fc6fd5c8f  movaps xmm6, xmm9
0000798fc6fd5c93  addpd xmm6, xmm7
0000798fc6fd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000798fc6fd5c9c  ptest xmm4, xmm4
0000798fc6fd5ca1  jnz 0x0000798FC6FD75B0
0000798fc6fd5ca7  vmovaps xmm9, [rsp+0x70]
0000798fc6fd5cad  vpermilpd xmm9, xmm9, 0x00
0000798fc6fd5cb3  vmovaps xmm4, [rsp+0x90]
0000798fc6fd5cbc  movaps xmm7, xmm4
0000798fc6fd5cbf  mulpd xmm7, xmm9
0000798fc6fd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000798fc6fd5cc9  ptest xmm3, xmm3
0000798fc6fd5cce  jnz 0x0000798FC6FD76F1
0000798fc6fd5cd4  vmovaps xmm9, [rsp+0x50]
0000798fc6fd5cda  vpermilpd xmm9, xmm9, 0x00
0000798fc6fd5ce0  movaps xmm4, xmm15
0000798fc6fd5ce4  mulpd xmm4, xmm9
0000798fc6fd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000798fc6fd5cee  ptest xmm3, xmm3
0000798fc6fd5cf3  jnz 0x0000798FC6FD7832
0000798fc6fd5cf9  lea r14, [rax+0xE0]
0000798fc6fd5d00  movups xmm15, [r13+r14*1]
0000798fc6fd5d06  vmovaps xmm9, [rsp+0x70]
0000798fc6fd5d0c  vpermilpd xmm9, xmm9, 0x00
0000798fc6fd5d12  vmovaps [rsp+0x70], xmm1
0000798fc6fd5d18  vmovaps xmm1, [rsp+0x80]
0000798fc6fd5d21  vmovaps [rsp+0x80], xmm15
0000798fc6fd5d2a  movaps xmm3, xmm1
0000798fc6fd5d2d  mulpd xmm3, xmm9
0000798fc6fd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000798fc6fd5d37  ptest xmm15, xmm15
0000798fc6fd5d3d  jnz 0x0000798FC6FD797E
0000798fc6fd5d43  vmovaps xmm1, [rsp+0xF0]
0000798fc6fd5d4c  vmovaps xmm15, [rsp+0xF0]
0000798fc6fd5d55  por xmm1, xmm15
0000798fc6fd5d5a  movaps [r15+0x300], xmm1
0000798fc6fd5d62  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd5d6b  vmovaps xmm9, [rsp+0xE0]
0000798fc6fd5d74  por xmm15, xmm9
0000798fc6fd5d79  movaps [r15+0x190], xmm15
0000798fc6fd5d81  vmovaps xmm9, [rsp+0x50]
0000798fc6fd5d87  vpermilpd xmm9, xmm9, 0x00
0000798fc6fd5d8d  vmovaps [rsp+0x90], xmm1
0000798fc6fd5d96  vmovaps [rsp+0xE0], xmm15
0000798fc6fd5d9f  vmovaps xmm15, [rsp+0x80]
0000798fc6fd5da8  vmovaps [rsp+0x80], xmm14
0000798fc6fd5db1  movaps xmm1, xmm15
0000798fc6fd5db5  mulpd xmm1, xmm9
0000798fc6fd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000798fc6fd5dbf  ptest xmm14, xmm14
0000798fc6fd5dc5  jnz 0x0000798FC6FD7ABF
0000798fc6fd5dcb  lea r14, [rax+0x90]
0000798fc6fd5dd2  movups xmm15, [r13+r14*1]
0000798fc6fd5dd8  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd5de1  vmovaps xmm9, [rsp+0xD0]
0000798fc6fd5dea  por xmm14, xmm9
0000798fc6fd5def  movaps [r15+0x1C0], xmm14
0000798fc6fd5df7  vmovaps xmm9, [rsp+0xC0]
0000798fc6fd5e00  vmovaps [rsp+0xD0], xmm1
0000798fc6fd5e09  vmovaps xmm1, [rsp+0xC0]
0000798fc6fd5e12  por xmm9, xmm1
0000798fc6fd5e17  movaps [r15+0x200], xmm9
0000798fc6fd5e1f  vmovaps [rsp+0xC0], xmm2
0000798fc6fd5e28  vmovaps xmm1, [rsp+0xC0]
0000798fc6fd5e31  por xmm2, xmm1
0000798fc6fd5e35  movaps [r15+0x2D0], xmm2
0000798fc6fd5e3d  vmovaps [rsp+0xC0], xmm8
0000798fc6fd5e46  vmovaps xmm1, [rsp+0xC0]
0000798fc6fd5e4f  por xmm8, xmm1
0000798fc6fd5e54  movaps [r15+0x2E0], xmm8
0000798fc6fd5e5c  vmovaps [rsp+0xC0], xmm15
0000798fc6fd5e65  movaps xmm1, xmm5
0000798fc6fd5e68  addpd xmm1, xmm7
0000798fc6fd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000798fc6fd5e71  ptest xmm15, xmm15
0000798fc6fd5e77  jnz 0x0000798FC6FD7C0B
0000798fc6fd5e7d  vmovaps xmm15, [rsp+0x50]
0000798fc6fd5e83  vpermilpd xmm15, xmm15, 0x00
0000798fc6fd5e89  vmovaps xmm5, [rsp+0xC0]
0000798fc6fd5e92  vmovaps [rsp+0xC0], xmm1
0000798fc6fd5e9b  movaps xmm7, xmm5
0000798fc6fd5e9e  mulpd xmm7, xmm15
0000798fc6fd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000798fc6fd5ea8  ptest xmm1, xmm1
0000798fc6fd5ead  jnz 0x0000798FC6FD7D4B
0000798fc6fd5eb3  lea r14, [rax+0x80]
0000798fc6fd5eba  movups xmm1, [r13+r14*1]
0000798fc6fd5ec0  vmovaps xmm5, [rsp+0x70]
0000798fc6fd5ec6  vmovaps [rsp+0x70], xmm1
0000798fc6fd5ecc  movaps xmm15, xmm5
0000798fc6fd5ed0  addpd xmm15, xmm3
0000798fc6fd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000798fc6fd5edb  ptest xmm1, xmm1
0000798fc6fd5ee0  jnz 0x0000798FC6FD7E96
0000798fc6fd5ee6  vmovaps xmm5, [rsp+0x80]
0000798fc6fd5eef  movaps xmm1, xmm5
0000798fc6fd5ef2  addpd xmm1, xmm4
0000798fc6fd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000798fc6fd5efb  ptest xmm3, xmm3
0000798fc6fd5f00  jnz 0x0000798FC6FD7FD8
0000798fc6fd5f06  vmovaps [rsp+0x80], xmm10
0000798fc6fd5f0f  vmovaps xmm5, [rsp+0x80]
0000798fc6fd5f18  por xmm10, xmm5
0000798fc6fd5f1d  movaps [r15+0x2F0], xmm10
0000798fc6fd5f25  vmovaps xmm5, [rsp+0x50]
0000798fc6fd5f2b  vpermilpd xmm5, xmm5, 0x00
0000798fc6fd5f31  vmovaps xmm3, [rsp+0x70]
0000798fc6fd5f37  vmovaps [rsp+0x50], xmm1
0000798fc6fd5f3d  movaps xmm4, xmm3
0000798fc6fd5f40  mulpd xmm4, xmm5
0000798fc6fd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000798fc6fd5f49  ptest xmm1, xmm1
0000798fc6fd5f4e  jnz 0x0000798FC6FD8118
0000798fc6fd5f54  lea r14, [rax+0xD0]
0000798fc6fd5f5b  movups xmm1, [r13+r14*1]
0000798fc6fd5f61  vmovaps xmm3, [rsp+0xD0]
0000798fc6fd5f6a  vmovaps [rsp+0x70], xmm1
0000798fc6fd5f70  movaps xmm5, xmm6
0000798fc6fd5f73  addpd xmm5, xmm3
0000798fc6fd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000798fc6fd5f7c  ptest xmm1, xmm1
0000798fc6fd5f81  jnz 0x0000798FC6FD8262
0000798fc6fd5f87  vmovaps xmm1, [rsp+0x60]
0000798fc6fd5f8d  vpermilpd xmm1, xmm1, 0x00
0000798fc6fd5f93  movaps xmm6, xmm9
0000798fc6fd5f97  mulpd xmm6, xmm1
0000798fc6fd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000798fc6fd5fa0  ptest xmm3, xmm3
0000798fc6fd5fa5  jnz 0x0000798FC6FD83A2
0000798fc6fd5fab  movaps [r15+0x260], xmm6
0000798fc6fd5fb3  vxorps xmm1, xmm1, xmm1
0000798fc6fd5fb7  vpbroadcastq xmm1, xmm1
0000798fc6fd5fbc  movaps [r15+0x1B0], xmm1
0000798fc6fd5fc4  vmovaps xmm1, [rsp+0x60]
0000798fc6fd5fca  vpermilpd xmm1, xmm1, 0x00
0000798fc6fd5fd0  vmovaps xmm3, [rsp+0x70]
0000798fc6fd5fd6  vmovaps [rsp+0x70], xmm15
0000798fc6fd5fdc  movaps xmm9, xmm3
0000798fc6fd5fe0  mulpd xmm9, xmm1
0000798fc6fd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000798fc6fd5feb  ptest xmm15, xmm15
0000798fc6fd5ff1  jnz 0x0000798FC6FD84E3
0000798fc6fd5ff7  lea r14, [rax+0xC0]
0000798fc6fd5ffe  movups xmm1, [r13+r14*1]
0000798fc6fd6004  vmovaps xmm3, [rsp+0xC0]
0000798fc6fd600d  vmovaps [rsp+0x80], xmm1
0000798fc6fd6016  movaps xmm15, xmm3
0000798fc6fd601a  addpd xmm15, xmm7
0000798fc6fd601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000798fc6fd6025  ptest xmm1, xmm1
0000798fc6fd602a  jnz 0x0000798FC6FD862F
0000798fc6fd6030  vmovaps [rsp+0xC0], xmm13
0000798fc6fd6039  vmovaps xmm1, [rsp+0xC0]
0000798fc6fd6042  por xmm13, xmm1
0000798fc6fd6047  movaps [r15+0x270], xmm13
0000798fc6fd604f  vmovaps xmm1, [rsp+0xB0]
0000798fc6fd6058  vmovaps xmm7, [rsp+0xB0]
0000798fc6fd6061  por xmm1, xmm7
0000798fc6fd6065  movaps [r15+0x1A0], xmm1
0000798fc6fd606d  vmovaps xmm1, [rsp+0x60]
0000798fc6fd6073  vpermilpd xmm1, xmm1, 0x00
0000798fc6fd6079  vmovaps [rsp+0xB0], xmm1
0000798fc6fd6082  vmovaps xmm1, [rsp+0x80]
0000798fc6fd608b  vmovaps [rsp+0x80], xmm15
0000798fc6fd6094  vmovaps xmm15, [rsp+0xB0]
0000798fc6fd609d  vmovaps [rsp+0xB0], xmm14
0000798fc6fd60a6  movaps xmm3, xmm1
0000798fc6fd60a9  mulpd xmm3, xmm15
0000798fc6fd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000798fc6fd60b3  ptest xmm14, xmm14
0000798fc6fd60b9  jnz 0x0000798FC6FD8771
0000798fc6fd60bf  lea r14, [rax+0x20]
0000798fc6fd60c3  movups xmm1, [r13+r14*1]
0000798fc6fd60c9  movaps [r15+0x110], xmm1
0000798fc6fd60d1  vmovaps xmm14, [rsp+0x70]
0000798fc6fd60d7  vmovaps [rsp+0x70], xmm1
0000798fc6fd60dd  movaps xmm15, xmm14
0000798fc6fd60e1  addpd xmm15, xmm4
0000798fc6fd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000798fc6fd60ec  ptest xmm1, xmm1
0000798fc6fd60f1  jnz 0x0000798FC6FD88BC
0000798fc6fd60f7  vmovaps xmm1, [rsp+0x60]
0000798fc6fd60fd  vpermilpd xmm1, xmm1, 0x00
0000798fc6fd6103  movaps xmm14, xmm2
0000798fc6fd6107  mulpd xmm14, xmm1
0000798fc6fd610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000798fc6fd6112  ptest xmm4, xmm4
0000798fc6fd6117  jnz 0x0000798FC6FD89FF
0000798fc6fd611d  vmovaps xmm4, [rsp+0x50]
0000798fc6fd6123  movaps xmm1, xmm4
0000798fc6fd6126  addpd xmm1, xmm9
0000798fc6fd612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000798fc6fd6130  ptest xmm2, xmm2
0000798fc6fd6135  jnz 0x0000798FC6FD8B41
0000798fc6fd613b  vmovaps xmm9, [rsp+0x30]
0000798fc6fd6141  vpermilpd xmm9, xmm9, 0x00
0000798fc6fd6147  vmovaps xmm2, [rsp+0x70]
0000798fc6fd614d  vmovaps [rsp+0x50], xmm1
0000798fc6fd6153  movaps xmm4, xmm2
0000798fc6fd6156  mulpd xmm4, xmm9
0000798fc6fd615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000798fc6fd6160  ptest xmm1, xmm1
0000798fc6fd6165  jnz 0x0000798FC6FD8C82
0000798fc6fd616b  vmovaps xmm1, [rsp+0x30]
0000798fc6fd6171  vpermilpd xmm1, xmm1, 0x00
0000798fc6fd6177  vmovaps xmm2, [rsp+0x90]
0000798fc6fd6180  vmovaps [rsp+0x60], xmm15
0000798fc6fd6186  movaps xmm9, xmm2
0000798fc6fd618a  mulpd xmm9, xmm1
0000798fc6fd618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000798fc6fd6195  ptest xmm15, xmm15
0000798fc6fd619b  jnz 0x0000798FC6FD8DC3
0000798fc6fd61a1  vmovaps xmm15, [rsp+0x80]
0000798fc6fd61aa  movaps xmm1, xmm15
0000798fc6fd61ae  addpd xmm1, xmm6
0000798fc6fd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000798fc6fd61b7  ptest xmm2, xmm2
0000798fc6fd61bc  jnz 0x0000798FC6FD8F05
0000798fc6fd61c2  movaps xmm15, xmm5
0000798fc6fd61c6  addpd xmm15, xmm3
0000798fc6fd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000798fc6fd61d1  ptest xmm6, xmm6
0000798fc6fd61d6  jnz 0x0000798FC6FD9046
0000798fc6fd61dc  vmovaps xmm6, [rsp+0x30]
0000798fc6fd61e2  vpermilpd xmm6, xmm6, 0x00
0000798fc6fd61e8  movaps xmm5, xmm8
0000798fc6fd61ec  mulpd xmm5, xmm6
0000798fc6fd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000798fc6fd61f5  ptest xmm3, xmm3
0000798fc6fd61fa  jnz 0x0000798FC6FD9188
0000798fc6fd6200  vmovaps xmm8, [rsp+0x30]
0000798fc6fd6206  vpermilpd xmm8, xmm8, 0x00
0000798fc6fd620c  movaps xmm6, xmm10
0000798fc6fd6210  mulpd xmm6, xmm8
0000798fc6fd6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000798fc6fd621a  ptest xmm3, xmm3
0000798fc6fd621f  jnz 0x0000798FC6FD92C9
0000798fc6fd6225  vmovaps xmm8, [rsp+0x60]
0000798fc6fd622b  movaps xmm10, xmm8
0000798fc6fd622f  addpd xmm10, xmm14
0000798fc6fd6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000798fc6fd623a  ptest xmm3, xmm3
0000798fc6fd623f  jnz 0x0000798FC6FD940B
0000798fc6fd6245  vmovaps xmm8, [rsp+0x50]
0000798fc6fd624b  movaps xmm14, xmm8
0000798fc6fd624f  addpd xmm14, xmm4
0000798fc6fd6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000798fc6fd625a  ptest xmm3, xmm3
0000798fc6fd625f  jnz 0x0000798FC6FD954F
0000798fc6fd6265  vmovaps xmm8, [rsp+0x40]
0000798fc6fd626b  vpermilpd xmm8, xmm8, 0x00
0000798fc6fd6271  movaps xmm4, xmm13
0000798fc6fd6275  mulpd xmm4, xmm8
0000798fc6fd627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000798fc6fd627f  ptest xmm3, xmm3
0000798fc6fd6284  jnz 0x0000798FC6FD9692
0000798fc6fd628a  movaps xmm13, xmm15
0000798fc6fd628e  addpd xmm13, xmm9
0000798fc6fd6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000798fc6fd6299  ptest xmm8, xmm8
0000798fc6fd629f  jnz 0x0000798FC6FD97D4
0000798fc6fd62a5  movaps xmm15, xmm1
0000798fc6fd62a9  addpd xmm15, xmm5
0000798fc6fd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000798fc6fd62b4  ptest xmm9, xmm9
0000798fc6fd62ba  jnz 0x0000798FC6FD9918
0000798fc6fd62c0  vmovaps [rsp+0x30], xmm11
0000798fc6fd62c6  vmovaps xmm1, [rsp+0x30]
0000798fc6fd62cc  por xmm11, xmm1
0000798fc6fd62d1  movaps [r15+0x250], xmm11
0000798fc6fd62d9  vmovaps [rsp+0x30], xmm12
0000798fc6fd62df  vmovaps xmm1, [rsp+0x30]
0000798fc6fd62e5  por xmm12, xmm1
0000798fc6fd62ea  movaps [r15+0x2A0], xmm12
0000798fc6fd62f2  vmovaps xmm1, [rsp+0xA0]
0000798fc6fd62fb  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd6304  por xmm1, xmm11
0000798fc6fd6309  movaps [r15+0x1D0], xmm1
0000798fc6fd6311  lea r14, [rax+0x40]
0000798fc6fd6315  movups xmm1, [r13+r14*1]
0000798fc6fd631b  movaps [r15+0x2C0], xmm1
0000798fc6fd6323  vmovaps xmm11, [rsp+0x40]
0000798fc6fd6329  vpermilpd xmm11, xmm11, 0x00
0000798fc6fd632f  vmovaps xmm8, [rsp+0xE0]
0000798fc6fd6338  movaps xmm9, xmm8
0000798fc6fd633c  mulpd xmm9, xmm11
0000798fc6fd6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000798fc6fd6347  ptest xmm5, xmm5
0000798fc6fd634c  jnz 0x0000798FC6FD9A64
0000798fc6fd6352  movaps xmm11, xmm10
0000798fc6fd6356  addpd xmm11, xmm6
0000798fc6fd635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000798fc6fd6361  ptest xmm8, xmm8
0000798fc6fd6367  jnz 0x0000798FC6FD9BA8
0000798fc6fd636d  movaps xmm10, xmm14
0000798fc6fd6371  addpd xmm10, xmm4
0000798fc6fd6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000798fc6fd637c  ptest xmm8, xmm8
0000798fc6fd6382  jnz 0x0000798FC6FD9CEB
0000798fc6fd6388  vmovaps xmm14, [rsp+0x40]
0000798fc6fd638e  vpermilpd xmm14, xmm14, 0x00
0000798fc6fd6394  movaps xmm8, xmm1
0000798fc6fd6398  mulpd xmm8, xmm14
0000798fc6fd639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000798fc6fd63a3  ptest xmm6, xmm6
0000798fc6fd63a8  jnz 0x0000798FC6FD9E2E
0000798fc6fd63ae  movaps xmm1, [r15+0x2B0]
0000798fc6fd63b6  vmovaps xmm14, [rsp+0x40]
0000798fc6fd63bc  vpermilpd xmm14, xmm14, 0x00
0000798fc6fd63c2  movaps xmm6, xmm1
0000798fc6fd63c5  mulpd xmm6, xmm14
0000798fc6fd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000798fc6fd63cf  ptest xmm5, xmm5
0000798fc6fd63d4  jnz 0x0000798FC6FD9F71
0000798fc6fd63da  vmovaps xmm1, [rsp+0x10]
0000798fc6fd63e0  vpermilpd xmm1, xmm1, 0x00
0000798fc6fd63e6  movaps xmm14, xmm12
0000798fc6fd63ea  mulpd xmm14, xmm1
0000798fc6fd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000798fc6fd63f5  ptest xmm5, xmm5
0000798fc6fd63fa  jnz 0x0000798FC6FDA0B2
0000798fc6fd6400  movaps xmm1, xmm13
0000798fc6fd6404  addpd xmm1, xmm9
0000798fc6fd6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000798fc6fd640e  ptest xmm12, xmm12
0000798fc6fd6414  jnz 0x0000798FC6FDA1F5
0000798fc6fd641a  vmovaps xmm13, [rsp+0x10]
0000798fc6fd6420  vpermilpd xmm13, xmm13, 0x00
0000798fc6fd6426  movaps xmm12, xmm7
0000798fc6fd642a  mulpd xmm12, xmm13
0000798fc6fd642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000798fc6fd6435  ptest xmm9, xmm9
0000798fc6fd643b  jnz 0x0000798FC6FDA337
0000798fc6fd6441  movaps xmm13, xmm15
0000798fc6fd6445  addpd xmm13, xmm8
0000798fc6fd644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000798fc6fd6450  ptest xmm9, xmm9
0000798fc6fd6456  jnz 0x0000798FC6FDA47A
0000798fc6fd645c  movaps xmm15, [r15+0x290]
0000798fc6fd6464  vmovaps xmm9, [rsp+0x10]
0000798fc6fd646a  vpermilpd xmm9, xmm9, 0x00
0000798fc6fd6470  movaps xmm8, xmm15
0000798fc6fd6474  mulpd xmm8, xmm9
0000798fc6fd6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000798fc6fd647f  ptest xmm7, xmm7
0000798fc6fd6484  jnz 0x0000798FC6FDA5BE
0000798fc6fd648a  movaps xmm15, xmm11
0000798fc6fd648e  addpd xmm15, xmm6
0000798fc6fd6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000798fc6fd6499  ptest xmm9, xmm9
0000798fc6fd649f  jnz 0x0000798FC6FDA702
0000798fc6fd64a5  movaps xmm11, [r15+0x1E0]
0000798fc6fd64ad  vmovaps xmm9, [rsp+0x10]
0000798fc6fd64b3  vpermilpd xmm9, xmm9, 0x00
0000798fc6fd64b9  movaps xmm7, xmm11
0000798fc6fd64bd  mulpd xmm7, xmm9
0000798fc6fd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000798fc6fd64c7  ptest xmm6, xmm6
0000798fc6fd64cc  jnz 0x0000798FC6FDA845
0000798fc6fd64d2  movaps xmm11, xmm10
0000798fc6fd64d6  addpd xmm11, xmm14
0000798fc6fd64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000798fc6fd64e1  ptest xmm9, xmm9
0000798fc6fd64e7  jnz 0x0000798FC6FDA987
0000798fc6fd64ed  lea r14, [rax+0x70]
0000798fc6fd64f1  movups xmm14, [r13+r14*1]
0000798fc6fd64f7  movaps [r15+0x240], xmm14
0000798fc6fd64ff  movaps xmm10, xmm1
0000798fc6fd6503  addpd xmm10, xmm12
0000798fc6fd6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000798fc6fd650e  ptest xmm9, xmm9
0000798fc6fd6514  jnz 0x0000798FC6FDAAD5
0000798fc6fd651a  movaps [r15+0x170], xmm10
0000798fc6fd6522  vmovaps xmm1, [rsp+0x20]
0000798fc6fd6528  vpermilpd xmm1, xmm1, 0x00
0000798fc6fd652e  movaps xmm12, xmm14
0000798fc6fd6532  mulpd xmm12, xmm1
0000798fc6fd6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000798fc6fd653d  ptest xmm9, xmm9
0000798fc6fd6543  jnz 0x0000798FC6FDAC18
0000798fc6fd6549  vmovaps xmm1, [rsp+0x20]
0000798fc6fd654f  vpermilpd xmm1, xmm1, 0x00
0000798fc6fd6555  vmovaps xmm9, [rsp+0xB0]
0000798fc6fd655e  movaps xmm14, xmm9
0000798fc6fd6562  mulpd xmm14, xmm1
0000798fc6fd6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000798fc6fd656d  ptest xmm6, xmm6
0000798fc6fd6572  jnz 0x0000798FC6FDAD5B
0000798fc6fd6578  movaps [r15+0x180], xmm14
0000798fc6fd6580  movaps xmm1, xmm13
0000798fc6fd6584  addpd xmm1, xmm8
0000798fc6fd6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000798fc6fd658e  ptest xmm9, xmm9
0000798fc6fd6594  jnz 0x0000798FC6FDAE9E
0000798fc6fd659a  movaps [r15+0x210], xmm1
0000798fc6fd65a2  movups xmm13, [r13+rax*1]
0000798fc6fd65a8  lea r14, [rax+0x10]
0000798fc6fd65ac  movups xmm9, [r13+r14*1]
0000798fc6fd65b2  movaps [r15+0x230], xmm9
0000798fc6fd65ba  movaps xmm8, xmm15
0000798fc6fd65be  addpd xmm8, xmm7
0000798fc6fd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000798fc6fd65c9  ptest xmm6, xmm6
0000798fc6fd65ce  jnz 0x0000798FC6FDAFF4
0000798fc6fd65d4  movaps [r15+0x130], xmm8
0000798fc6fd65dc  vmovaps xmm15, [rsp+0x20]
0000798fc6fd65e2  vpermilpd xmm15, xmm15, 0x00
0000798fc6fd65e8  movaps xmm7, xmm9
0000798fc6fd65ec  mulpd xmm7, xmm15
0000798fc6fd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000798fc6fd65f6  ptest xmm6, xmm6
0000798fc6fd65fb  jnz 0x0000798FC6FDB137
0000798fc6fd6601  movaps [r15+0x220], xmm7
0000798fc6fd6609  vmovaps xmm15, [rsp+0x20]
0000798fc6fd660f  vpermilpd xmm15, xmm15, 0x00
0000798fc6fd6615  movaps xmm9, xmm13
0000798fc6fd6619  mulpd xmm9, xmm15
0000798fc6fd661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000798fc6fd6624  ptest xmm6, xmm6
0000798fc6fd6629  jnz 0x0000798FC6FDB279
0000798fc6fd662f  movaps xmm15, xmm11
0000798fc6fd6633  addpd xmm15, xmm12
0000798fc6fd6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000798fc6fd663e  ptest xmm13, xmm13
0000798fc6fd6644  jnz 0x0000798FC6FDB3BD
0000798fc6fd664a  movaps [r15+0x140], xmm15
0000798fc6fd6652  movaps xmm13, xmm10
0000798fc6fd6656  addpd xmm13, xmm14
0000798fc6fd665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000798fc6fd6661  ptest xmm12, xmm12
0000798fc6fd6667  jnz 0x0000798FC6FDB501
0000798fc6fd666d  movaps [r15+0x150], xmm13
0000798fc6fd6675  movaps xmm14, xmm1
0000798fc6fd6679  addpd xmm14, xmm7
0000798fc6fd667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000798fc6fd6684  ptest xmm12, xmm12
0000798fc6fd668a  jnz 0x0000798FC6FDB645
0000798fc6fd6690  movaps [r15+0x160], xmm14
0000798fc6fd6698  movaps xmm1, xmm8
0000798fc6fd669c  addpd xmm1, xmm9
0000798fc6fd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000798fc6fd66a6  ptest xmm12, xmm12
0000798fc6fd66ac  jnz 0x0000798FC6FDB787
0000798fc6fd66b2  movaps [r15+0x120], xmm1
0000798fc6fd66ba  movups [r13+r11*1], xmm15
0000798fc6fd66c0  lea rax, [r11+0x10]
0000798fc6fd66c4  movups [r13+rax*1], xmm13
0000798fc6fd66ca  lea rax, [r11+0x20]
0000798fc6fd66ce  movups [r13+rax*1], xmm14
0000798fc6fd66d4  lea rax, [r11+0x30]
0000798fc6fd66d8  movups [r13+rax*1], xmm1
0000798fc6fd66de  mov eax, [r15+0x108]
0000798fc6fd66e5  sahf
0000798fc6fd66e6  jnz 0x0000798FC6FD6718
0000798fc6fd66e8  cmp dword ptr [r15+0x318], 0x00
0000798fc6fd66f0  jz 0x0000798FC6FDB900
0000798fc6fd66f6  nop [rax+rax*1], ax
0000798fc6fd66ff  nop [rax+rax*1], eax
0000798fc6fd6707  mov eax, 0x410444
0000798fc6fd670c  mov [r15+0x100], rax
0000798fc6fd6713  jmp 0x0000798FC6DFE110
0000798fc6fd6718  cmp dword ptr [r15+0x318], 0x00
0000798fc6fd6720  jz 0x0000798FC6FD57E0
0000798fc6fd6726  nop [rax+rax*1], ax
0000798fc6fd672f  nop [rax+rax*1], eax
0000798fc6fd6737  mov eax, 0x410278
0000798fc6fd673c  mov [r15+0x100], rax
0000798fc6fd6743  jmp 0x0000798FC6DFE110
0000798fc6fd6748  int3
0000798fc6fd6749  call 0x0000798FC6E0A4B0
0000798fc6fd674e  jmp 0x0000798FC6FD5828
0000798fc6fd6753  call 0x0000798FC6E09240
0000798fc6fd6758  jmp 0x0000798FC6FD5832
0000798fc6fd675d  call 0x0000798FC6E0A4B0
0000798fc6fd6762  jmp 0x0000798FC6FD588F
0000798fc6fd6767  call 0x0000798FC6E09240
0000798fc6fd676c  jmp 0x0000798FC6FD5899
0000798fc6fd6771  call 0x0000798FC6E0A4B0
0000798fc6fd6776  jmp 0x0000798FC6FD58DD
0000798fc6fd677b  call 0x0000798FC6E09240
0000798fc6fd6780  jmp 0x0000798FC6FD58E7
0000798fc6fd6785  call 0x0000798FC6EB47C0
0000798fc6fd678a  jmp 0x0000798FC6FD5926
0000798fc6fd678f  call 0x0000798FC6E0B720
0000798fc6fd6794  jmp 0x0000798FC6FD593A
0000798fc6fd6799  call 0x0000798FC6EBFC30
0000798fc6fd679e  jmp 0x0000798FC6FD5958
0000798fc6fd67a3  call 0x0000798FC6EBE9C0
0000798fc6fd67a8  jmp 0x0000798FC6FD5962
0000798fc6fd67ad  call 0x0000798FC6EBD750
0000798fc6fd67b2  jmp 0x0000798FC6FD596C
0000798fc6fd67b7  sub rsp, 0x08
0000798fc6fd67bb  push rax
0000798fc6fd67bc  push rcx
0000798fc6fd67bd  push rdx
0000798fc6fd67be  push rdi
0000798fc6fd67bf  push rsi
0000798fc6fd67c0  push r8
0000798fc6fd67c2  push r9
0000798fc6fd67c4  push r10
0000798fc6fd67c6  push r11
0000798fc6fd67c8  sub rsp, 0xF0
0000798fc6fd67cf  vmovaps [rsp], xmm0
0000798fc6fd67d4  vmovaps [rsp+0x10], xmm1
0000798fc6fd67da  vmovaps [rsp+0x20], xmm2
0000798fc6fd67e0  vmovaps [rsp+0x30], xmm3
0000798fc6fd67e6  vmovaps [rsp+0x40], xmm4
0000798fc6fd67ec  vmovaps [rsp+0x50], xmm5
0000798fc6fd67f2  vmovaps [rsp+0x60], xmm6
0000798fc6fd67f8  vmovaps [rsp+0x70], xmm7
0000798fc6fd67fe  vmovaps [rsp+0x80], xmm9
0000798fc6fd6807  vmovaps [rsp+0x90], xmm10
0000798fc6fd6810  vmovaps [rsp+0xA0], xmm11
0000798fc6fd6819  vmovaps [rsp+0xB0], xmm12
0000798fc6fd6822  vmovaps [rsp+0xC0], xmm13
0000798fc6fd682b  vmovaps [rsp+0xD0], xmm14
0000798fc6fd6834  vmovaps [rsp+0xE0], xmm15
0000798fc6fd683d  sub rsp, 0x30
0000798fc6fd6841  movaps [rsp], xmm8
0000798fc6fd6846  movaps [rsp+0x10], xmm12
0000798fc6fd684c  movaps [rsp+0x20], xmm15
0000798fc6fd6852  lea rdi, [rsp]
0000798fc6fd6856  mov esi, 0x00
0000798fc6fd685b  mov rax, 0x63E558B23530
0000798fc6fd6865  call rax
0000798fc6fd6867  movaps xmm8, [rsp]
0000798fc6fd686c  add rsp, 0x30
0000798fc6fd6870  vmovaps xmm0, [rsp]
0000798fc6fd6875  vmovaps xmm1, [rsp+0x10]
0000798fc6fd687b  vmovaps xmm2, [rsp+0x20]
0000798fc6fd6881  vmovaps xmm3, [rsp+0x30]
0000798fc6fd6887  vmovaps xmm4, [rsp+0x40]
0000798fc6fd688d  vmovaps xmm5, [rsp+0x50]
0000798fc6fd6893  vmovaps xmm6, [rsp+0x60]
0000798fc6fd6899  vmovaps xmm7, [rsp+0x70]
0000798fc6fd689f  vmovaps xmm9, [rsp+0x80]
0000798fc6fd68a8  vmovaps xmm10, [rsp+0x90]
0000798fc6fd68b1  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd68ba  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd68c3  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd68cc  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd68d5  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd68de  add rsp, 0xF0
0000798fc6fd68e5  pop r11
0000798fc6fd68e7  pop r10
0000798fc6fd68e9  pop r9
0000798fc6fd68eb  pop r8
0000798fc6fd68ed  pop rsi
0000798fc6fd68ee  pop rdi
0000798fc6fd68ef  pop rdx
0000798fc6fd68f0  pop rcx
0000798fc6fd68f1  pop rax
0000798fc6fd68f2  add rsp, 0x08
0000798fc6fd68f6  jmp 0x0000798FC6FD599A
0000798fc6fd68fb  sub rsp, 0x08
0000798fc6fd68ff  push rax
0000798fc6fd6900  push rcx
0000798fc6fd6901  push rdx
0000798fc6fd6902  push rdi
0000798fc6fd6903  push rsi
0000798fc6fd6904  push r8
0000798fc6fd6906  push r9
0000798fc6fd6908  push r10
0000798fc6fd690a  push r11
0000798fc6fd690c  sub rsp, 0xF0
0000798fc6fd6913  vmovaps [rsp], xmm0
0000798fc6fd6918  vmovaps [rsp+0x10], xmm1
0000798fc6fd691e  vmovaps [rsp+0x20], xmm2
0000798fc6fd6924  vmovaps [rsp+0x30], xmm3
0000798fc6fd692a  vmovaps [rsp+0x40], xmm4
0000798fc6fd6930  vmovaps [rsp+0x50], xmm5
0000798fc6fd6936  vmovaps [rsp+0x60], xmm6
0000798fc6fd693c  vmovaps [rsp+0x70], xmm8
0000798fc6fd6942  vmovaps [rsp+0x80], xmm9
0000798fc6fd694b  vmovaps [rsp+0x90], xmm10
0000798fc6fd6954  vmovaps [rsp+0xA0], xmm11
0000798fc6fd695d  vmovaps [rsp+0xB0], xmm12
0000798fc6fd6966  vmovaps [rsp+0xC0], xmm13
0000798fc6fd696f  vmovaps [rsp+0xD0], xmm14
0000798fc6fd6978  vmovaps [rsp+0xE0], xmm15
0000798fc6fd6981  sub rsp, 0x30
0000798fc6fd6985  movaps [rsp], xmm7
0000798fc6fd6989  movaps [rsp+0x10], xmm9
0000798fc6fd698f  movaps [rsp+0x20], xmm15
0000798fc6fd6995  lea rdi, [rsp]
0000798fc6fd6999  mov esi, 0x00
0000798fc6fd699e  mov rax, 0x63E558B23530
0000798fc6fd69a8  call rax
0000798fc6fd69aa  movaps xmm7, [rsp]
0000798fc6fd69ae  add rsp, 0x30
0000798fc6fd69b2  vmovaps xmm0, [rsp]
0000798fc6fd69b7  vmovaps xmm1, [rsp+0x10]
0000798fc6fd69bd  vmovaps xmm2, [rsp+0x20]
0000798fc6fd69c3  vmovaps xmm3, [rsp+0x30]
0000798fc6fd69c9  vmovaps xmm4, [rsp+0x40]
0000798fc6fd69cf  vmovaps xmm5, [rsp+0x50]
0000798fc6fd69d5  vmovaps xmm6, [rsp+0x60]
0000798fc6fd69db  vmovaps xmm8, [rsp+0x70]
0000798fc6fd69e1  vmovaps xmm9, [rsp+0x80]
0000798fc6fd69ea  vmovaps xmm10, [rsp+0x90]
0000798fc6fd69f3  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd69fc  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd6a05  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd6a0e  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd6a17  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd6a20  add rsp, 0xF0
0000798fc6fd6a27  pop r11
0000798fc6fd6a29  pop r10
0000798fc6fd6a2b  pop r9
0000798fc6fd6a2d  pop r8
0000798fc6fd6a2f  pop rsi
0000798fc6fd6a30  pop rdi
0000798fc6fd6a31  pop rdx
0000798fc6fd6a32  pop rcx
0000798fc6fd6a33  pop rax
0000798fc6fd6a34  add rsp, 0x08
0000798fc6fd6a38  jmp 0x0000798FC6FD59C8
0000798fc6fd6a3d  sub rsp, 0x08
0000798fc6fd6a41  push rax
0000798fc6fd6a42  push rcx
0000798fc6fd6a43  push rdx
0000798fc6fd6a44  push rdi
0000798fc6fd6a45  push rsi
0000798fc6fd6a46  push r8
0000798fc6fd6a48  push r9
0000798fc6fd6a4a  push r10
0000798fc6fd6a4c  push r11
0000798fc6fd6a4e  sub rsp, 0xF0
0000798fc6fd6a55  vmovaps [rsp], xmm0
0000798fc6fd6a5a  vmovaps [rsp+0x10], xmm1
0000798fc6fd6a60  vmovaps [rsp+0x20], xmm2
0000798fc6fd6a66  vmovaps [rsp+0x30], xmm3
0000798fc6fd6a6c  vmovaps [rsp+0x40], xmm4
0000798fc6fd6a72  vmovaps [rsp+0x50], xmm5
0000798fc6fd6a78  vmovaps [rsp+0x60], xmm6
0000798fc6fd6a7e  vmovaps [rsp+0x70], xmm7
0000798fc6fd6a84  vmovaps [rsp+0x80], xmm8
0000798fc6fd6a8d  vmovaps [rsp+0x90], xmm10
0000798fc6fd6a96  vmovaps [rsp+0xA0], xmm11
0000798fc6fd6a9f  vmovaps [rsp+0xB0], xmm12
0000798fc6fd6aa8  vmovaps [rsp+0xC0], xmm13
0000798fc6fd6ab1  vmovaps [rsp+0xD0], xmm14
0000798fc6fd6aba  vmovaps [rsp+0xE0], xmm15
0000798fc6fd6ac3  sub rsp, 0x30
0000798fc6fd6ac7  movaps [rsp], xmm9
0000798fc6fd6acc  movaps [rsp+0x10], xmm12
0000798fc6fd6ad2  movaps [rsp+0x20], xmm10
0000798fc6fd6ad8  lea rdi, [rsp]
0000798fc6fd6adc  mov esi, 0x00
0000798fc6fd6ae1  mov rax, 0x63E558B23530
0000798fc6fd6aeb  call rax
0000798fc6fd6aed  movaps xmm9, [rsp]
0000798fc6fd6af2  add rsp, 0x30
0000798fc6fd6af6  vmovaps xmm0, [rsp]
0000798fc6fd6afb  vmovaps xmm1, [rsp+0x10]
0000798fc6fd6b01  vmovaps xmm2, [rsp+0x20]
0000798fc6fd6b07  vmovaps xmm3, [rsp+0x30]
0000798fc6fd6b0d  vmovaps xmm4, [rsp+0x40]
0000798fc6fd6b13  vmovaps xmm5, [rsp+0x50]
0000798fc6fd6b19  vmovaps xmm6, [rsp+0x60]
0000798fc6fd6b1f  vmovaps xmm7, [rsp+0x70]
0000798fc6fd6b25  vmovaps xmm8, [rsp+0x80]
0000798fc6fd6b2e  vmovaps xmm10, [rsp+0x90]
0000798fc6fd6b37  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd6b40  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd6b49  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd6b52  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd6b5b  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd6b64  add rsp, 0xF0
0000798fc6fd6b6b  pop r11
0000798fc6fd6b6d  pop r10
0000798fc6fd6b6f  pop r9
0000798fc6fd6b71  pop r8
0000798fc6fd6b73  pop rsi
0000798fc6fd6b74  pop rdi
0000798fc6fd6b75  pop rdx
0000798fc6fd6b76  pop rcx
0000798fc6fd6b77  pop rax
0000798fc6fd6b78  add rsp, 0x08
0000798fc6fd6b7c  jmp 0x0000798FC6FD59EC
0000798fc6fd6b81  sub rsp, 0x08
0000798fc6fd6b85  push rax
0000798fc6fd6b86  push rcx
0000798fc6fd6b87  push rdx
0000798fc6fd6b88  push rdi
0000798fc6fd6b89  push rsi
0000798fc6fd6b8a  push r8
0000798fc6fd6b8c  push r9
0000798fc6fd6b8e  push r10
0000798fc6fd6b90  push r11
0000798fc6fd6b92  sub rsp, 0xF0
0000798fc6fd6b99  vmovaps [rsp], xmm0
0000798fc6fd6b9e  vmovaps [rsp+0x10], xmm1
0000798fc6fd6ba4  vmovaps [rsp+0x20], xmm2
0000798fc6fd6baa  vmovaps [rsp+0x30], xmm3
0000798fc6fd6bb0  vmovaps [rsp+0x40], xmm4
0000798fc6fd6bb6  vmovaps [rsp+0x50], xmm5
0000798fc6fd6bbc  vmovaps [rsp+0x60], xmm6
0000798fc6fd6bc2  vmovaps [rsp+0x70], xmm7
0000798fc6fd6bc8  vmovaps [rsp+0x80], xmm8
0000798fc6fd6bd1  vmovaps [rsp+0x90], xmm9
0000798fc6fd6bda  vmovaps [rsp+0xA0], xmm11
0000798fc6fd6be3  vmovaps [rsp+0xB0], xmm12
0000798fc6fd6bec  vmovaps [rsp+0xC0], xmm13
0000798fc6fd6bf5  vmovaps [rsp+0xD0], xmm14
0000798fc6fd6bfe  vmovaps [rsp+0xE0], xmm15
0000798fc6fd6c07  sub rsp, 0x30
0000798fc6fd6c0b  movaps [rsp], xmm10
0000798fc6fd6c10  movaps [rsp+0x10], xmm12
0000798fc6fd6c16  movaps [rsp+0x20], xmm11
0000798fc6fd6c1c  lea rdi, [rsp]
0000798fc6fd6c20  mov esi, 0x00
0000798fc6fd6c25  mov rax, 0x63E558B23530
0000798fc6fd6c2f  call rax
0000798fc6fd6c31  movaps xmm10, [rsp]
0000798fc6fd6c36  add rsp, 0x30
0000798fc6fd6c3a  vmovaps xmm0, [rsp]
0000798fc6fd6c3f  vmovaps xmm1, [rsp+0x10]
0000798fc6fd6c45  vmovaps xmm2, [rsp+0x20]
0000798fc6fd6c4b  vmovaps xmm3, [rsp+0x30]
0000798fc6fd6c51  vmovaps xmm4, [rsp+0x40]
0000798fc6fd6c57  vmovaps xmm5, [rsp+0x50]
0000798fc6fd6c5d  vmovaps xmm6, [rsp+0x60]
0000798fc6fd6c63  vmovaps xmm7, [rsp+0x70]
0000798fc6fd6c69  vmovaps xmm8, [rsp+0x80]
0000798fc6fd6c72  vmovaps xmm9, [rsp+0x90]
0000798fc6fd6c7b  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd6c84  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd6c8d  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd6c96  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd6c9f  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd6ca8  add rsp, 0xF0
0000798fc6fd6caf  pop r11
0000798fc6fd6cb1  pop r10
0000798fc6fd6cb3  pop r9
0000798fc6fd6cb5  pop r8
0000798fc6fd6cb7  pop rsi
0000798fc6fd6cb8  pop rdi
0000798fc6fd6cb9  pop rdx
0000798fc6fd6cba  pop rcx
0000798fc6fd6cbb  pop rax
0000798fc6fd6cbc  add rsp, 0x08
0000798fc6fd6cc0  jmp 0x0000798FC6FD5A06
0000798fc6fd6cc5  sub rsp, 0x08
0000798fc6fd6cc9  push rax
0000798fc6fd6cca  push rcx
0000798fc6fd6ccb  push rdx
0000798fc6fd6ccc  push rdi
0000798fc6fd6ccd  push rsi
0000798fc6fd6cce  push r8
0000798fc6fd6cd0  push r9
0000798fc6fd6cd2  push r10
0000798fc6fd6cd4  push r11
0000798fc6fd6cd6  sub rsp, 0xF0
0000798fc6fd6cdd  vmovaps [rsp], xmm0
0000798fc6fd6ce2  vmovaps [rsp+0x10], xmm1
0000798fc6fd6ce8  vmovaps [rsp+0x20], xmm2
0000798fc6fd6cee  vmovaps [rsp+0x30], xmm3
0000798fc6fd6cf4  vmovaps [rsp+0x40], xmm4
0000798fc6fd6cfa  vmovaps [rsp+0x50], xmm5
0000798fc6fd6d00  vmovaps [rsp+0x60], xmm7
0000798fc6fd6d06  vmovaps [rsp+0x70], xmm8
0000798fc6fd6d0c  vmovaps [rsp+0x80], xmm9
0000798fc6fd6d15  vmovaps [rsp+0x90], xmm10
0000798fc6fd6d1e  vmovaps [rsp+0xA0], xmm11
0000798fc6fd6d27  vmovaps [rsp+0xB0], xmm12
0000798fc6fd6d30  vmovaps [rsp+0xC0], xmm13
0000798fc6fd6d39  vmovaps [rsp+0xD0], xmm14
0000798fc6fd6d42  vmovaps [rsp+0xE0], xmm15
0000798fc6fd6d4b  sub rsp, 0x30
0000798fc6fd6d4f  movaps [rsp], xmm6
0000798fc6fd6d53  movaps [rsp+0x10], xmm12
0000798fc6fd6d59  movaps [rsp+0x20], xmm11
0000798fc6fd6d5f  lea rdi, [rsp]
0000798fc6fd6d63  mov esi, 0x00
0000798fc6fd6d68  mov rax, 0x63E558B23530
0000798fc6fd6d72  call rax
0000798fc6fd6d74  movaps xmm6, [rsp]
0000798fc6fd6d78  add rsp, 0x30
0000798fc6fd6d7c  vmovaps xmm0, [rsp]
0000798fc6fd6d81  vmovaps xmm1, [rsp+0x10]
0000798fc6fd6d87  vmovaps xmm2, [rsp+0x20]
0000798fc6fd6d8d  vmovaps xmm3, [rsp+0x30]
0000798fc6fd6d93  vmovaps xmm4, [rsp+0x40]
0000798fc6fd6d99  vmovaps xmm5, [rsp+0x50]
0000798fc6fd6d9f  vmovaps xmm7, [rsp+0x60]
0000798fc6fd6da5  vmovaps xmm8, [rsp+0x70]
0000798fc6fd6dab  vmovaps xmm9, [rsp+0x80]
0000798fc6fd6db4  vmovaps xmm10, [rsp+0x90]
0000798fc6fd6dbd  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd6dc6  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd6dcf  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd6dd8  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd6de1  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd6dea  add rsp, 0xF0
0000798fc6fd6df1  pop r11
0000798fc6fd6df3  pop r10
0000798fc6fd6df5  pop r9
0000798fc6fd6df7  pop r8
0000798fc6fd6df9  pop rsi
0000798fc6fd6dfa  pop rdi
0000798fc6fd6dfb  pop rdx
0000798fc6fd6dfc  pop rcx
0000798fc6fd6dfd  pop rax
0000798fc6fd6dfe  add rsp, 0x08
0000798fc6fd6e02  jmp 0x0000798FC6FD5A27
0000798fc6fd6e07  sub rsp, 0x08
0000798fc6fd6e0b  push rax
0000798fc6fd6e0c  push rcx
0000798fc6fd6e0d  push rdx
0000798fc6fd6e0e  push rdi
0000798fc6fd6e0f  push rsi
0000798fc6fd6e10  push r8
0000798fc6fd6e12  push r9
0000798fc6fd6e14  push r10
0000798fc6fd6e16  push r11
0000798fc6fd6e18  sub rsp, 0xF0
0000798fc6fd6e1f  vmovaps [rsp], xmm0
0000798fc6fd6e24  vmovaps [rsp+0x10], xmm1
0000798fc6fd6e2a  vmovaps [rsp+0x20], xmm2
0000798fc6fd6e30  vmovaps [rsp+0x30], xmm4
0000798fc6fd6e36  vmovaps [rsp+0x40], xmm5
0000798fc6fd6e3c  vmovaps [rsp+0x50], xmm6
0000798fc6fd6e42  vmovaps [rsp+0x60], xmm7
0000798fc6fd6e48  vmovaps [rsp+0x70], xmm8
0000798fc6fd6e4e  vmovaps [rsp+0x80], xmm9
0000798fc6fd6e57  vmovaps [rsp+0x90], xmm10
0000798fc6fd6e60  vmovaps [rsp+0xA0], xmm11
0000798fc6fd6e69  vmovaps [rsp+0xB0], xmm12
0000798fc6fd6e72  vmovaps [rsp+0xC0], xmm13
0000798fc6fd6e7b  vmovaps [rsp+0xD0], xmm14
0000798fc6fd6e84  vmovaps [rsp+0xE0], xmm15
0000798fc6fd6e8d  sub rsp, 0x30
0000798fc6fd6e91  movaps [rsp], xmm3
0000798fc6fd6e95  movaps [rsp+0x10], xmm5
0000798fc6fd6e9a  movaps [rsp+0x20], xmm4
0000798fc6fd6e9f  lea rdi, [rsp]
0000798fc6fd6ea3  mov esi, 0x00
0000798fc6fd6ea8  mov rax, 0x63E558B23530
0000798fc6fd6eb2  call rax
0000798fc6fd6eb4  movaps xmm3, [rsp]
0000798fc6fd6eb8  add rsp, 0x30
0000798fc6fd6ebc  vmovaps xmm0, [rsp]
0000798fc6fd6ec1  vmovaps xmm1, [rsp+0x10]
0000798fc6fd6ec7  vmovaps xmm2, [rsp+0x20]
0000798fc6fd6ecd  vmovaps xmm4, [rsp+0x30]
0000798fc6fd6ed3  vmovaps xmm5, [rsp+0x40]
0000798fc6fd6ed9  vmovaps xmm6, [rsp+0x50]
0000798fc6fd6edf  vmovaps xmm7, [rsp+0x60]
0000798fc6fd6ee5  vmovaps xmm8, [rsp+0x70]
0000798fc6fd6eeb  vmovaps xmm9, [rsp+0x80]
0000798fc6fd6ef4  vmovaps xmm10, [rsp+0x90]
0000798fc6fd6efd  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd6f06  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd6f0f  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd6f18  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd6f21  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd6f2a  add rsp, 0xF0
0000798fc6fd6f31  pop r11
0000798fc6fd6f33  pop r10
0000798fc6fd6f35  pop r9
0000798fc6fd6f37  pop r8
0000798fc6fd6f39  pop rsi
0000798fc6fd6f3a  pop rdi
0000798fc6fd6f3b  pop rdx
0000798fc6fd6f3c  pop rcx
0000798fc6fd6f3d  pop rax
0000798fc6fd6f3e  add rsp, 0x08
0000798fc6fd6f42  jmp 0x0000798FC6FD5A88
0000798fc6fd6f47  sub rsp, 0x08
0000798fc6fd6f4b  push rax
0000798fc6fd6f4c  push rcx
0000798fc6fd6f4d  push rdx
0000798fc6fd6f4e  push rdi
0000798fc6fd6f4f  push rsi
0000798fc6fd6f50  push r8
0000798fc6fd6f52  push r9
0000798fc6fd6f54  push r10
0000798fc6fd6f56  push r11
0000798fc6fd6f58  sub rsp, 0xF0
0000798fc6fd6f5f  vmovaps [rsp], xmm0
0000798fc6fd6f64  vmovaps [rsp+0x10], xmm1
0000798fc6fd6f6a  vmovaps [rsp+0x20], xmm2
0000798fc6fd6f70  vmovaps [rsp+0x30], xmm3
0000798fc6fd6f76  vmovaps [rsp+0x40], xmm4
0000798fc6fd6f7c  vmovaps [rsp+0x50], xmm6
0000798fc6fd6f82  vmovaps [rsp+0x60], xmm7
0000798fc6fd6f88  vmovaps [rsp+0x70], xmm8
0000798fc6fd6f8e  vmovaps [rsp+0x80], xmm9
0000798fc6fd6f97  vmovaps [rsp+0x90], xmm10
0000798fc6fd6fa0  vmovaps [rsp+0xA0], xmm11
0000798fc6fd6fa9  vmovaps [rsp+0xB0], xmm12
0000798fc6fd6fb2  vmovaps [rsp+0xC0], xmm13
0000798fc6fd6fbb  vmovaps [rsp+0xD0], xmm14
0000798fc6fd6fc4  vmovaps [rsp+0xE0], xmm15
0000798fc6fd6fcd  sub rsp, 0x30
0000798fc6fd6fd1  movaps [rsp], xmm5
0000798fc6fd6fd5  movaps [rsp+0x10], xmm8
0000798fc6fd6fdb  movaps [rsp+0x20], xmm15
0000798fc6fd6fe1  lea rdi, [rsp]
0000798fc6fd6fe5  mov esi, 0x00
0000798fc6fd6fea  mov rax, 0x63E558B23530
0000798fc6fd6ff4  call rax
0000798fc6fd6ff6  movaps xmm5, [rsp]
0000798fc6fd6ffa  add rsp, 0x30
0000798fc6fd6ffe  vmovaps xmm0, [rsp]
0000798fc6fd7003  vmovaps xmm1, [rsp+0x10]
0000798fc6fd7009  vmovaps xmm2, [rsp+0x20]
0000798fc6fd700f  vmovaps xmm3, [rsp+0x30]
0000798fc6fd7015  vmovaps xmm4, [rsp+0x40]
0000798fc6fd701b  vmovaps xmm6, [rsp+0x50]
0000798fc6fd7021  vmovaps xmm7, [rsp+0x60]
0000798fc6fd7027  vmovaps xmm8, [rsp+0x70]
0000798fc6fd702d  vmovaps xmm9, [rsp+0x80]
0000798fc6fd7036  vmovaps xmm10, [rsp+0x90]
0000798fc6fd703f  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd7048  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd7051  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd705a  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd7063  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd706c  add rsp, 0xF0
0000798fc6fd7073  pop r11
0000798fc6fd7075  pop r10
0000798fc6fd7077  pop r9
0000798fc6fd7079  pop r8
0000798fc6fd707b  pop rsi
0000798fc6fd707c  pop rdi
0000798fc6fd707d  pop rdx
0000798fc6fd707e  pop rcx
0000798fc6fd707f  pop rax
0000798fc6fd7080  add rsp, 0x08
0000798fc6fd7084  jmp 0x0000798FC6FD5AC0
0000798fc6fd7089  sub rsp, 0x08
0000798fc6fd708d  push rax
0000798fc6fd708e  push rcx
0000798fc6fd708f  push rdx
0000798fc6fd7090  push rdi
0000798fc6fd7091  push rsi
0000798fc6fd7092  push r8
0000798fc6fd7094  push r9
0000798fc6fd7096  push r10
0000798fc6fd7098  push r11
0000798fc6fd709a  sub rsp, 0xF0
0000798fc6fd70a1  vmovaps [rsp], xmm0
0000798fc6fd70a6  vmovaps [rsp+0x10], xmm1
0000798fc6fd70ac  vmovaps [rsp+0x20], xmm2
0000798fc6fd70b2  vmovaps [rsp+0x30], xmm3
0000798fc6fd70b8  vmovaps [rsp+0x40], xmm5
0000798fc6fd70be  vmovaps [rsp+0x50], xmm6
0000798fc6fd70c4  vmovaps [rsp+0x60], xmm7
0000798fc6fd70ca  vmovaps [rsp+0x70], xmm8
0000798fc6fd70d0  vmovaps [rsp+0x80], xmm9
0000798fc6fd70d9  vmovaps [rsp+0x90], xmm10
0000798fc6fd70e2  vmovaps [rsp+0xA0], xmm11
0000798fc6fd70eb  vmovaps [rsp+0xB0], xmm12
0000798fc6fd70f4  vmovaps [rsp+0xC0], xmm13
0000798fc6fd70fd  vmovaps [rsp+0xD0], xmm14
0000798fc6fd7106  vmovaps [rsp+0xE0], xmm15
0000798fc6fd710f  sub rsp, 0x30
0000798fc6fd7113  movaps [rsp], xmm4
0000798fc6fd7117  movaps [rsp+0x10], xmm9
0000798fc6fd711d  movaps [rsp+0x20], xmm8
0000798fc6fd7123  lea rdi, [rsp]
0000798fc6fd7127  mov esi, 0x00
0000798fc6fd712c  mov rax, 0x63E558B23530
0000798fc6fd7136  call rax
0000798fc6fd7138  movaps xmm4, [rsp]
0000798fc6fd713c  add rsp, 0x30
0000798fc6fd7140  vmovaps xmm0, [rsp]
0000798fc6fd7145  vmovaps xmm1, [rsp+0x10]
0000798fc6fd714b  vmovaps xmm2, [rsp+0x20]
0000798fc6fd7151  vmovaps xmm3, [rsp+0x30]
0000798fc6fd7157  vmovaps xmm5, [rsp+0x40]
0000798fc6fd715d  vmovaps xmm6, [rsp+0x50]
0000798fc6fd7163  vmovaps xmm7, [rsp+0x60]
0000798fc6fd7169  vmovaps xmm8, [rsp+0x70]
0000798fc6fd716f  vmovaps xmm9, [rsp+0x80]
0000798fc6fd7178  vmovaps xmm10, [rsp+0x90]
0000798fc6fd7181  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd718a  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd7193  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd719c  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd71a5  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd71ae  add rsp, 0xF0
0000798fc6fd71b5  pop r11
0000798fc6fd71b7  pop r10
0000798fc6fd71b9  pop r9
0000798fc6fd71bb  pop r8
0000798fc6fd71bd  pop rsi
0000798fc6fd71be  pop rdi
0000798fc6fd71bf  pop rdx
0000798fc6fd71c0  pop rcx
0000798fc6fd71c1  pop rax
0000798fc6fd71c2  add rsp, 0x08
0000798fc6fd71c6  jmp 0x0000798FC6FD5AE1
0000798fc6fd71cb  sub rsp, 0x08
0000798fc6fd71cf  push rax
0000798fc6fd71d0  push rcx
0000798fc6fd71d1  push rdx
0000798fc6fd71d2  push rdi
0000798fc6fd71d3  push rsi
0000798fc6fd71d4  push r8
0000798fc6fd71d6  push r9
0000798fc6fd71d8  push r10
0000798fc6fd71da  push r11
0000798fc6fd71dc  sub rsp, 0xF0
0000798fc6fd71e3  vmovaps [rsp], xmm0
0000798fc6fd71e8  vmovaps [rsp+0x10], xmm1
0000798fc6fd71ee  vmovaps [rsp+0x20], xmm2
0000798fc6fd71f4  vmovaps [rsp+0x30], xmm3
0000798fc6fd71fa  vmovaps [rsp+0x40], xmm4
0000798fc6fd7200  vmovaps [rsp+0x50], xmm5
0000798fc6fd7206  vmovaps [rsp+0x60], xmm6
0000798fc6fd720c  vmovaps [rsp+0x70], xmm7
0000798fc6fd7212  vmovaps [rsp+0x80], xmm8
0000798fc6fd721b  vmovaps [rsp+0x90], xmm10
0000798fc6fd7224  vmovaps [rsp+0xA0], xmm11
0000798fc6fd722d  vmovaps [rsp+0xB0], xmm12
0000798fc6fd7236  vmovaps [rsp+0xC0], xmm13
0000798fc6fd723f  vmovaps [rsp+0xD0], xmm14
0000798fc6fd7248  vmovaps [rsp+0xE0], xmm15
0000798fc6fd7251  sub rsp, 0x30
0000798fc6fd7255  movaps [rsp], xmm9
0000798fc6fd725a  movaps [rsp+0x10], xmm10
0000798fc6fd7260  movaps [rsp+0x20], xmm8
0000798fc6fd7266  lea rdi, [rsp]
0000798fc6fd726a  mov esi, 0x00
0000798fc6fd726f  mov rax, 0x63E558B23530
0000798fc6fd7279  call rax
0000798fc6fd727b  movaps xmm9, [rsp]
0000798fc6fd7280  add rsp, 0x30
0000798fc6fd7284  vmovaps xmm0, [rsp]
0000798fc6fd7289  vmovaps xmm1, [rsp+0x10]
0000798fc6fd728f  vmovaps xmm2, [rsp+0x20]
0000798fc6fd7295  vmovaps xmm3, [rsp+0x30]
0000798fc6fd729b  vmovaps xmm4, [rsp+0x40]
0000798fc6fd72a1  vmovaps xmm5, [rsp+0x50]
0000798fc6fd72a7  vmovaps xmm6, [rsp+0x60]
0000798fc6fd72ad  vmovaps xmm7, [rsp+0x70]
0000798fc6fd72b3  vmovaps xmm8, [rsp+0x80]
0000798fc6fd72bc  vmovaps xmm10, [rsp+0x90]
0000798fc6fd72c5  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd72ce  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd72d7  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd72e0  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd72e9  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd72f2  add rsp, 0xF0
0000798fc6fd72f9  pop r11
0000798fc6fd72fb  pop r10
0000798fc6fd72fd  pop r9
0000798fc6fd72ff  pop r8
0000798fc6fd7301  pop rsi
0000798fc6fd7302  pop rdi
0000798fc6fd7303  pop rdx
0000798fc6fd7304  pop rcx
0000798fc6fd7305  pop rax
0000798fc6fd7306  add rsp, 0x08
0000798fc6fd730a  jmp 0x0000798FC6FD5AFB
0000798fc6fd730f  call 0x0000798FC6ED64F0
0000798fc6fd7314  jmp 0x0000798FC6FD5C15
0000798fc6fd7319  call 0x0000798FC6ED64F0
0000798fc6fd731e  jmp 0x0000798FC6FD5C2B
0000798fc6fd7323  sub rsp, 0x08
0000798fc6fd7327  push rax
0000798fc6fd7328  push rcx
0000798fc6fd7329  push rdx
0000798fc6fd732a  push rdi
0000798fc6fd732b  push rsi
0000798fc6fd732c  push r8
0000798fc6fd732e  push r9
0000798fc6fd7330  push r10
0000798fc6fd7332  push r11
0000798fc6fd7334  sub rsp, 0xF0
0000798fc6fd733b  vmovaps [rsp], xmm0
0000798fc6fd7340  vmovaps [rsp+0x10], xmm2
0000798fc6fd7346  vmovaps [rsp+0x20], xmm3
0000798fc6fd734c  vmovaps [rsp+0x30], xmm4
0000798fc6fd7352  vmovaps [rsp+0x40], xmm5
0000798fc6fd7358  vmovaps [rsp+0x50], xmm6
0000798fc6fd735e  vmovaps [rsp+0x60], xmm7
0000798fc6fd7364  vmovaps [rsp+0x70], xmm8
0000798fc6fd736a  vmovaps [rsp+0x80], xmm9
0000798fc6fd7373  vmovaps [rsp+0x90], xmm10
0000798fc6fd737c  vmovaps [rsp+0xA0], xmm11
0000798fc6fd7385  vmovaps [rsp+0xB0], xmm12
0000798fc6fd738e  vmovaps [rsp+0xC0], xmm13
0000798fc6fd7397  vmovaps [rsp+0xD0], xmm14
0000798fc6fd73a0  vmovaps [rsp+0xE0], xmm15
0000798fc6fd73a9  sub rsp, 0x30
0000798fc6fd73ad  movaps [rsp], xmm1
0000798fc6fd73b1  movaps [rsp+0x10], xmm6
0000798fc6fd73b6  movaps [rsp+0x20], xmm15
0000798fc6fd73bc  lea rdi, [rsp]
0000798fc6fd73c0  mov esi, 0x00
0000798fc6fd73c5  mov rax, 0x63E558B23530
0000798fc6fd73cf  call rax
0000798fc6fd73d1  movaps xmm1, [rsp]
0000798fc6fd73d5  add rsp, 0x30
0000798fc6fd73d9  vmovaps xmm0, [rsp]
0000798fc6fd73de  vmovaps xmm2, [rsp+0x10]
0000798fc6fd73e4  vmovaps xmm3, [rsp+0x20]
0000798fc6fd73ea  vmovaps xmm4, [rsp+0x30]
0000798fc6fd73f0  vmovaps xmm5, [rsp+0x40]
0000798fc6fd73f6  vmovaps xmm6, [rsp+0x50]
0000798fc6fd73fc  vmovaps xmm7, [rsp+0x60]
0000798fc6fd7402  vmovaps xmm8, [rsp+0x70]
0000798fc6fd7408  vmovaps xmm9, [rsp+0x80]
0000798fc6fd7411  vmovaps xmm10, [rsp+0x90]
0000798fc6fd741a  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd7423  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd742c  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd7435  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd743e  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd7447  add rsp, 0xF0
0000798fc6fd744e  pop r11
0000798fc6fd7450  pop r10
0000798fc6fd7452  pop r9
0000798fc6fd7454  pop r8
0000798fc6fd7456  pop rsi
0000798fc6fd7457  pop rdi
0000798fc6fd7458  pop rdx
0000798fc6fd7459  pop rcx
0000798fc6fd745a  pop rax
0000798fc6fd745b  add rsp, 0x08
0000798fc6fd745f  jmp 0x0000798FC6FD5C68
0000798fc6fd7464  call 0x0000798FC6EE5820
0000798fc6fd7469  jmp 0x0000798FC6FD5C75
0000798fc6fd746e  sub rsp, 0x08
0000798fc6fd7472  push rax
0000798fc6fd7473  push rcx
0000798fc6fd7474  push rdx
0000798fc6fd7475  push rdi
0000798fc6fd7476  push rsi
0000798fc6fd7477  push r8
0000798fc6fd7479  push r9
0000798fc6fd747b  push r10
0000798fc6fd747d  push r11
0000798fc6fd747f  sub rsp, 0xF0
0000798fc6fd7486  vmovaps [rsp], xmm0
0000798fc6fd748b  vmovaps [rsp+0x10], xmm1
0000798fc6fd7491  vmovaps [rsp+0x20], xmm2
0000798fc6fd7497  vmovaps [rsp+0x30], xmm3
0000798fc6fd749d  vmovaps [rsp+0x40], xmm4
0000798fc6fd74a3  vmovaps [rsp+0x50], xmm5
0000798fc6fd74a9  vmovaps [rsp+0x60], xmm6
0000798fc6fd74af  vmovaps [rsp+0x70], xmm7
0000798fc6fd74b5  vmovaps [rsp+0x80], xmm8
0000798fc6fd74be  vmovaps [rsp+0x90], xmm9
0000798fc6fd74c7  vmovaps [rsp+0xA0], xmm10
0000798fc6fd74d0  vmovaps [rsp+0xB0], xmm11
0000798fc6fd74d9  vmovaps [rsp+0xC0], xmm12
0000798fc6fd74e2  vmovaps [rsp+0xD0], xmm13
0000798fc6fd74eb  vmovaps [rsp+0xE0], xmm15
0000798fc6fd74f4  sub rsp, 0x30
0000798fc6fd74f8  movaps [rsp], xmm14
0000798fc6fd74fd  movaps [rsp+0x10], xmm4
0000798fc6fd7502  movaps [rsp+0x20], xmm3
0000798fc6fd7507  lea rdi, [rsp]
0000798fc6fd750b  mov esi, 0x00
0000798fc6fd7510  mov rax, 0x63E558B23530
0000798fc6fd751a  call rax
0000798fc6fd751c  movaps xmm14, [rsp]
0000798fc6fd7521  add rsp, 0x30
0000798fc6fd7525  vmovaps xmm0, [rsp]
0000798fc6fd752a  vmovaps xmm1, [rsp+0x10]
0000798fc6fd7530  vmovaps xmm2, [rsp+0x20]
0000798fc6fd7536  vmovaps xmm3, [rsp+0x30]
0000798fc6fd753c  vmovaps xmm4, [rsp+0x40]
0000798fc6fd7542  vmovaps xmm5, [rsp+0x50]
0000798fc6fd7548  vmovaps xmm6, [rsp+0x60]
0000798fc6fd754e  vmovaps xmm7, [rsp+0x70]
0000798fc6fd7554  vmovaps xmm8, [rsp+0x80]
0000798fc6fd755d  vmovaps xmm9, [rsp+0x90]
0000798fc6fd7566  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd756f  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd7578  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd7581  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd758a  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd7593  add rsp, 0xF0
0000798fc6fd759a  pop r11
0000798fc6fd759c  pop r10
0000798fc6fd759e  pop r9
0000798fc6fd75a0  pop r8
0000798fc6fd75a2  pop rsi
0000798fc6fd75a3  pop rdi
0000798fc6fd75a4  pop rdx
0000798fc6fd75a5  pop rcx
0000798fc6fd75a6  pop rax
0000798fc6fd75a7  add rsp, 0x08
0000798fc6fd75ab  jmp 0x0000798FC6FD5C8F
0000798fc6fd75b0  sub rsp, 0x08
0000798fc6fd75b4  push rax
0000798fc6fd75b5  push rcx
0000798fc6fd75b6  push rdx
0000798fc6fd75b7  push rdi
0000798fc6fd75b8  push rsi
0000798fc6fd75b9  push r8
0000798fc6fd75bb  push r9
0000798fc6fd75bd  push r10
0000798fc6fd75bf  push r11
0000798fc6fd75c1  sub rsp, 0xF0
0000798fc6fd75c8  vmovaps [rsp], xmm0
0000798fc6fd75cd  vmovaps [rsp+0x10], xmm1
0000798fc6fd75d3  vmovaps [rsp+0x20], xmm2
0000798fc6fd75d9  vmovaps [rsp+0x30], xmm3
0000798fc6fd75df  vmovaps [rsp+0x40], xmm4
0000798fc6fd75e5  vmovaps [rsp+0x50], xmm5
0000798fc6fd75eb  vmovaps [rsp+0x60], xmm7
0000798fc6fd75f1  vmovaps [rsp+0x70], xmm8
0000798fc6fd75f7  vmovaps [rsp+0x80], xmm9
0000798fc6fd7600  vmovaps [rsp+0x90], xmm10
0000798fc6fd7609  vmovaps [rsp+0xA0], xmm11
0000798fc6fd7612  vmovaps [rsp+0xB0], xmm12
0000798fc6fd761b  vmovaps [rsp+0xC0], xmm13
0000798fc6fd7624  vmovaps [rsp+0xD0], xmm14
0000798fc6fd762d  vmovaps [rsp+0xE0], xmm15
0000798fc6fd7636  sub rsp, 0x30
0000798fc6fd763a  movaps [rsp], xmm6
0000798fc6fd763e  movaps [rsp+0x10], xmm9
0000798fc6fd7644  movaps [rsp+0x20], xmm7
0000798fc6fd7649  lea rdi, [rsp]
0000798fc6fd764d  mov esi, 0x00
0000798fc6fd7652  mov rax, 0x63E558B23530
0000798fc6fd765c  call rax
0000798fc6fd765e  movaps xmm6, [rsp]
0000798fc6fd7662  add rsp, 0x30
0000798fc6fd7666  vmovaps xmm0, [rsp]
0000798fc6fd766b  vmovaps xmm1, [rsp+0x10]
0000798fc6fd7671  vmovaps xmm2, [rsp+0x20]
0000798fc6fd7677  vmovaps xmm3, [rsp+0x30]
0000798fc6fd767d  vmovaps xmm4, [rsp+0x40]
0000798fc6fd7683  vmovaps xmm5, [rsp+0x50]
0000798fc6fd7689  vmovaps xmm7, [rsp+0x60]
0000798fc6fd768f  vmovaps xmm8, [rsp+0x70]
0000798fc6fd7695  vmovaps xmm9, [rsp+0x80]
0000798fc6fd769e  vmovaps xmm10, [rsp+0x90]
0000798fc6fd76a7  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd76b0  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd76b9  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd76c2  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd76cb  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd76d4  add rsp, 0xF0
0000798fc6fd76db  pop r11
0000798fc6fd76dd  pop r10
0000798fc6fd76df  pop r9
0000798fc6fd76e1  pop r8
0000798fc6fd76e3  pop rsi
0000798fc6fd76e4  pop rdi
0000798fc6fd76e5  pop rdx
0000798fc6fd76e6  pop rcx
0000798fc6fd76e7  pop rax
0000798fc6fd76e8  add rsp, 0x08
0000798fc6fd76ec  jmp 0x0000798FC6FD5CA7
0000798fc6fd76f1  sub rsp, 0x08
0000798fc6fd76f5  push rax
0000798fc6fd76f6  push rcx
0000798fc6fd76f7  push rdx
0000798fc6fd76f8  push rdi
0000798fc6fd76f9  push rsi
0000798fc6fd76fa  push r8
0000798fc6fd76fc  push r9
0000798fc6fd76fe  push r10
0000798fc6fd7700  push r11
0000798fc6fd7702  sub rsp, 0xF0
0000798fc6fd7709  vmovaps [rsp], xmm0
0000798fc6fd770e  vmovaps [rsp+0x10], xmm1
0000798fc6fd7714  vmovaps [rsp+0x20], xmm2
0000798fc6fd771a  vmovaps [rsp+0x30], xmm3
0000798fc6fd7720  vmovaps [rsp+0x40], xmm4
0000798fc6fd7726  vmovaps [rsp+0x50], xmm5
0000798fc6fd772c  vmovaps [rsp+0x60], xmm6
0000798fc6fd7732  vmovaps [rsp+0x70], xmm8
0000798fc6fd7738  vmovaps [rsp+0x80], xmm9
0000798fc6fd7741  vmovaps [rsp+0x90], xmm10
0000798fc6fd774a  vmovaps [rsp+0xA0], xmm11
0000798fc6fd7753  vmovaps [rsp+0xB0], xmm12
0000798fc6fd775c  vmovaps [rsp+0xC0], xmm13
0000798fc6fd7765  vmovaps [rsp+0xD0], xmm14
0000798fc6fd776e  vmovaps [rsp+0xE0], xmm15
0000798fc6fd7777  sub rsp, 0x30
0000798fc6fd777b  movaps [rsp], xmm7
0000798fc6fd777f  movaps [rsp+0x10], xmm4
0000798fc6fd7784  movaps [rsp+0x20], xmm9
0000798fc6fd778a  lea rdi, [rsp]
0000798fc6fd778e  mov esi, 0x00
0000798fc6fd7793  mov rax, 0x63E558B23530
0000798fc6fd779d  call rax
0000798fc6fd779f  movaps xmm7, [rsp]
0000798fc6fd77a3  add rsp, 0x30
0000798fc6fd77a7  vmovaps xmm0, [rsp]
0000798fc6fd77ac  vmovaps xmm1, [rsp+0x10]
0000798fc6fd77b2  vmovaps xmm2, [rsp+0x20]
0000798fc6fd77b8  vmovaps xmm3, [rsp+0x30]
0000798fc6fd77be  vmovaps xmm4, [rsp+0x40]
0000798fc6fd77c4  vmovaps xmm5, [rsp+0x50]
0000798fc6fd77ca  vmovaps xmm6, [rsp+0x60]
0000798fc6fd77d0  vmovaps xmm8, [rsp+0x70]
0000798fc6fd77d6  vmovaps xmm9, [rsp+0x80]
0000798fc6fd77df  vmovaps xmm10, [rsp+0x90]
0000798fc6fd77e8  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd77f1  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd77fa  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd7803  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd780c  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd7815  add rsp, 0xF0
0000798fc6fd781c  pop r11
0000798fc6fd781e  pop r10
0000798fc6fd7820  pop r9
0000798fc6fd7822  pop r8
0000798fc6fd7824  pop rsi
0000798fc6fd7825  pop rdi
0000798fc6fd7826  pop rdx
0000798fc6fd7827  pop rcx
0000798fc6fd7828  pop rax
0000798fc6fd7829  add rsp, 0x08
0000798fc6fd782d  jmp 0x0000798FC6FD5CD4
0000798fc6fd7832  sub rsp, 0x08
0000798fc6fd7836  push rax
0000798fc6fd7837  push rcx
0000798fc6fd7838  push rdx
0000798fc6fd7839  push rdi
0000798fc6fd783a  push rsi
0000798fc6fd783b  push r8
0000798fc6fd783d  push r9
0000798fc6fd783f  push r10
0000798fc6fd7841  push r11
0000798fc6fd7843  sub rsp, 0xF0
0000798fc6fd784a  vmovaps [rsp], xmm0
0000798fc6fd784f  vmovaps [rsp+0x10], xmm1
0000798fc6fd7855  vmovaps [rsp+0x20], xmm2
0000798fc6fd785b  vmovaps [rsp+0x30], xmm3
0000798fc6fd7861  vmovaps [rsp+0x40], xmm5
0000798fc6fd7867  vmovaps [rsp+0x50], xmm6
0000798fc6fd786d  vmovaps [rsp+0x60], xmm7
0000798fc6fd7873  vmovaps [rsp+0x70], xmm8
0000798fc6fd7879  vmovaps [rsp+0x80], xmm9
0000798fc6fd7882  vmovaps [rsp+0x90], xmm10
0000798fc6fd788b  vmovaps [rsp+0xA0], xmm11
0000798fc6fd7894  vmovaps [rsp+0xB0], xmm12
0000798fc6fd789d  vmovaps [rsp+0xC0], xmm13
0000798fc6fd78a6  vmovaps [rsp+0xD0], xmm14
0000798fc6fd78af  vmovaps [rsp+0xE0], xmm15
0000798fc6fd78b8  sub rsp, 0x30
0000798fc6fd78bc  movaps [rsp], xmm4
0000798fc6fd78c0  movaps [rsp+0x10], xmm15
0000798fc6fd78c6  movaps [rsp+0x20], xmm9
0000798fc6fd78cc  lea rdi, [rsp]
0000798fc6fd78d0  mov esi, 0x00
0000798fc6fd78d5  mov rax, 0x63E558B23530
0000798fc6fd78df  call rax
0000798fc6fd78e1  movaps xmm4, [rsp]
0000798fc6fd78e5  add rsp, 0x30
0000798fc6fd78e9  vmovaps xmm0, [rsp]
0000798fc6fd78ee  vmovaps xmm1, [rsp+0x10]
0000798fc6fd78f4  vmovaps xmm2, [rsp+0x20]
0000798fc6fd78fa  vmovaps xmm3, [rsp+0x30]
0000798fc6fd7900  vmovaps xmm5, [rsp+0x40]
0000798fc6fd7906  vmovaps xmm6, [rsp+0x50]
0000798fc6fd790c  vmovaps xmm7, [rsp+0x60]
0000798fc6fd7912  vmovaps xmm8, [rsp+0x70]
0000798fc6fd7918  vmovaps xmm9, [rsp+0x80]
0000798fc6fd7921  vmovaps xmm10, [rsp+0x90]
0000798fc6fd792a  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd7933  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd793c  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd7945  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd794e  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd7957  add rsp, 0xF0
0000798fc6fd795e  pop r11
0000798fc6fd7960  pop r10
0000798fc6fd7962  pop r9
0000798fc6fd7964  pop r8
0000798fc6fd7966  pop rsi
0000798fc6fd7967  pop rdi
0000798fc6fd7968  pop rdx
0000798fc6fd7969  pop rcx
0000798fc6fd796a  pop rax
0000798fc6fd796b  add rsp, 0x08
0000798fc6fd796f  jmp 0x0000798FC6FD5CF9
0000798fc6fd7974  call 0x0000798FC6EE5820
0000798fc6fd7979  jmp 0x0000798FC6FD5D06
0000798fc6fd797e  sub rsp, 0x08
0000798fc6fd7982  push rax
0000798fc6fd7983  push rcx
0000798fc6fd7984  push rdx
0000798fc6fd7985  push rdi
0000798fc6fd7986  push rsi
0000798fc6fd7987  push r8
0000798fc6fd7989  push r9
0000798fc6fd798b  push r10
0000798fc6fd798d  push r11
0000798fc6fd798f  sub rsp, 0xF0
0000798fc6fd7996  vmovaps [rsp], xmm0
0000798fc6fd799b  vmovaps [rsp+0x10], xmm1
0000798fc6fd79a1  vmovaps [rsp+0x20], xmm2
0000798fc6fd79a7  vmovaps [rsp+0x30], xmm4
0000798fc6fd79ad  vmovaps [rsp+0x40], xmm5
0000798fc6fd79b3  vmovaps [rsp+0x50], xmm6
0000798fc6fd79b9  vmovaps [rsp+0x60], xmm7
0000798fc6fd79bf  vmovaps [rsp+0x70], xmm8
0000798fc6fd79c5  vmovaps [rsp+0x80], xmm9
0000798fc6fd79ce  vmovaps [rsp+0x90], xmm10
0000798fc6fd79d7  vmovaps [rsp+0xA0], xmm11
0000798fc6fd79e0  vmovaps [rsp+0xB0], xmm12
0000798fc6fd79e9  vmovaps [rsp+0xC0], xmm13
0000798fc6fd79f2  vmovaps [rsp+0xD0], xmm14
0000798fc6fd79fb  vmovaps [rsp+0xE0], xmm15
0000798fc6fd7a04  sub rsp, 0x30
0000798fc6fd7a08  movaps [rsp], xmm3
0000798fc6fd7a0c  movaps [rsp+0x10], xmm1
0000798fc6fd7a11  movaps [rsp+0x20], xmm9
0000798fc6fd7a17  lea rdi, [rsp]
0000798fc6fd7a1b  mov esi, 0x00
0000798fc6fd7a20  mov rax, 0x63E558B23530
0000798fc6fd7a2a  call rax
0000798fc6fd7a2c  movaps xmm3, [rsp]
0000798fc6fd7a30  add rsp, 0x30
0000798fc6fd7a34  vmovaps xmm0, [rsp]
0000798fc6fd7a39  vmovaps xmm1, [rsp+0x10]
0000798fc6fd7a3f  vmovaps xmm2, [rsp+0x20]
0000798fc6fd7a45  vmovaps xmm4, [rsp+0x30]
0000798fc6fd7a4b  vmovaps xmm5, [rsp+0x40]
0000798fc6fd7a51  vmovaps xmm6, [rsp+0x50]
0000798fc6fd7a57  vmovaps xmm7, [rsp+0x60]
0000798fc6fd7a5d  vmovaps xmm8, [rsp+0x70]
0000798fc6fd7a63  vmovaps xmm9, [rsp+0x80]
0000798fc6fd7a6c  vmovaps xmm10, [rsp+0x90]
0000798fc6fd7a75  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd7a7e  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd7a87  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd7a90  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd7a99  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd7aa2  add rsp, 0xF0
0000798fc6fd7aa9  pop r11
0000798fc6fd7aab  pop r10
0000798fc6fd7aad  pop r9
0000798fc6fd7aaf  pop r8
0000798fc6fd7ab1  pop rsi
0000798fc6fd7ab2  pop rdi
0000798fc6fd7ab3  pop rdx
0000798fc6fd7ab4  pop rcx
0000798fc6fd7ab5  pop rax
0000798fc6fd7ab6  add rsp, 0x08
0000798fc6fd7aba  jmp 0x0000798FC6FD5D43
0000798fc6fd7abf  sub rsp, 0x08
0000798fc6fd7ac3  push rax
0000798fc6fd7ac4  push rcx
0000798fc6fd7ac5  push rdx
0000798fc6fd7ac6  push rdi
0000798fc6fd7ac7  push rsi
0000798fc6fd7ac8  push r8
0000798fc6fd7aca  push r9
0000798fc6fd7acc  push r10
0000798fc6fd7ace  push r11
0000798fc6fd7ad0  sub rsp, 0xF0
0000798fc6fd7ad7  vmovaps [rsp], xmm0
0000798fc6fd7adc  vmovaps [rsp+0x10], xmm2
0000798fc6fd7ae2  vmovaps [rsp+0x20], xmm3
0000798fc6fd7ae8  vmovaps [rsp+0x30], xmm4
0000798fc6fd7aee  vmovaps [rsp+0x40], xmm5
0000798fc6fd7af4  vmovaps [rsp+0x50], xmm6
0000798fc6fd7afa  vmovaps [rsp+0x60], xmm7
0000798fc6fd7b00  vmovaps [rsp+0x70], xmm8
0000798fc6fd7b06  vmovaps [rsp+0x80], xmm9
0000798fc6fd7b0f  vmovaps [rsp+0x90], xmm10
0000798fc6fd7b18  vmovaps [rsp+0xA0], xmm11
0000798fc6fd7b21  vmovaps [rsp+0xB0], xmm12
0000798fc6fd7b2a  vmovaps [rsp+0xC0], xmm13
0000798fc6fd7b33  vmovaps [rsp+0xD0], xmm14
0000798fc6fd7b3c  vmovaps [rsp+0xE0], xmm15
0000798fc6fd7b45  sub rsp, 0x30
0000798fc6fd7b49  movaps [rsp], xmm1
0000798fc6fd7b4d  movaps [rsp+0x10], xmm15
0000798fc6fd7b53  movaps [rsp+0x20], xmm9
0000798fc6fd7b59  lea rdi, [rsp]
0000798fc6fd7b5d  mov esi, 0x00
0000798fc6fd7b62  mov rax, 0x63E558B23530
0000798fc6fd7b6c  call rax
0000798fc6fd7b6e  movaps xmm1, [rsp]
0000798fc6fd7b72  add rsp, 0x30
0000798fc6fd7b76  vmovaps xmm0, [rsp]
0000798fc6fd7b7b  vmovaps xmm2, [rsp+0x10]
0000798fc6fd7b81  vmovaps xmm3, [rsp+0x20]
0000798fc6fd7b87  vmovaps xmm4, [rsp+0x30]
0000798fc6fd7b8d  vmovaps xmm5, [rsp+0x40]
0000798fc6fd7b93  vmovaps xmm6, [rsp+0x50]
0000798fc6fd7b99  vmovaps xmm7, [rsp+0x60]
0000798fc6fd7b9f  vmovaps xmm8, [rsp+0x70]
0000798fc6fd7ba5  vmovaps xmm9, [rsp+0x80]
0000798fc6fd7bae  vmovaps xmm10, [rsp+0x90]
0000798fc6fd7bb7  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd7bc0  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd7bc9  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd7bd2  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd7bdb  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd7be4  add rsp, 0xF0
0000798fc6fd7beb  pop r11
0000798fc6fd7bed  pop r10
0000798fc6fd7bef  pop r9
0000798fc6fd7bf1  pop r8
0000798fc6fd7bf3  pop rsi
0000798fc6fd7bf4  pop rdi
0000798fc6fd7bf5  pop rdx
0000798fc6fd7bf6  pop rcx
0000798fc6fd7bf7  pop rax
0000798fc6fd7bf8  add rsp, 0x08
0000798fc6fd7bfc  jmp 0x0000798FC6FD5DCB
0000798fc6fd7c01  call 0x0000798FC6EE5820
0000798fc6fd7c06  jmp 0x0000798FC6FD5DD8
0000798fc6fd7c0b  sub rsp, 0x08
0000798fc6fd7c0f  push rax
0000798fc6fd7c10  push rcx
0000798fc6fd7c11  push rdx
0000798fc6fd7c12  push rdi
0000798fc6fd7c13  push rsi
0000798fc6fd7c14  push r8
0000798fc6fd7c16  push r9
0000798fc6fd7c18  push r10
0000798fc6fd7c1a  push r11
0000798fc6fd7c1c  sub rsp, 0xF0
0000798fc6fd7c23  vmovaps [rsp], xmm0
0000798fc6fd7c28  vmovaps [rsp+0x10], xmm2
0000798fc6fd7c2e  vmovaps [rsp+0x20], xmm3
0000798fc6fd7c34  vmovaps [rsp+0x30], xmm4
0000798fc6fd7c3a  vmovaps [rsp+0x40], xmm5
0000798fc6fd7c40  vmovaps [rsp+0x50], xmm6
0000798fc6fd7c46  vmovaps [rsp+0x60], xmm7
0000798fc6fd7c4c  vmovaps [rsp+0x70], xmm8
0000798fc6fd7c52  vmovaps [rsp+0x80], xmm9
0000798fc6fd7c5b  vmovaps [rsp+0x90], xmm10
0000798fc6fd7c64  vmovaps [rsp+0xA0], xmm11
0000798fc6fd7c6d  vmovaps [rsp+0xB0], xmm12
0000798fc6fd7c76  vmovaps [rsp+0xC0], xmm13
0000798fc6fd7c7f  vmovaps [rsp+0xD0], xmm14
0000798fc6fd7c88  vmovaps [rsp+0xE0], xmm15
0000798fc6fd7c91  sub rsp, 0x30
0000798fc6fd7c95  movaps [rsp], xmm1
0000798fc6fd7c99  movaps [rsp+0x10], xmm5
0000798fc6fd7c9e  movaps [rsp+0x20], xmm7
0000798fc6fd7ca3  lea rdi, [rsp]
0000798fc6fd7ca7  mov esi, 0x00
0000798fc6fd7cac  mov rax, 0x63E558B23530
0000798fc6fd7cb6  call rax
0000798fc6fd7cb8  movaps xmm1, [rsp]
0000798fc6fd7cbc  add rsp, 0x30
0000798fc6fd7cc0  vmovaps xmm0, [rsp]
0000798fc6fd7cc5  vmovaps xmm2, [rsp+0x10]
0000798fc6fd7ccb  vmovaps xmm3, [rsp+0x20]
0000798fc6fd7cd1  vmovaps xmm4, [rsp+0x30]
0000798fc6fd7cd7  vmovaps xmm5, [rsp+0x40]
0000798fc6fd7cdd  vmovaps xmm6, [rsp+0x50]
0000798fc6fd7ce3  vmovaps xmm7, [rsp+0x60]
0000798fc6fd7ce9  vmovaps xmm8, [rsp+0x70]
0000798fc6fd7cef  vmovaps xmm9, [rsp+0x80]
0000798fc6fd7cf8  vmovaps xmm10, [rsp+0x90]
0000798fc6fd7d01  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd7d0a  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd7d13  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd7d1c  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd7d25  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd7d2e  add rsp, 0xF0
0000798fc6fd7d35  pop r11
0000798fc6fd7d37  pop r10
0000798fc6fd7d39  pop r9
0000798fc6fd7d3b  pop r8
0000798fc6fd7d3d  pop rsi
0000798fc6fd7d3e  pop rdi
0000798fc6fd7d3f  pop rdx
0000798fc6fd7d40  pop rcx
0000798fc6fd7d41  pop rax
0000798fc6fd7d42  add rsp, 0x08
0000798fc6fd7d46  jmp 0x0000798FC6FD5E7D
0000798fc6fd7d4b  sub rsp, 0x08
0000798fc6fd7d4f  push rax
0000798fc6fd7d50  push rcx
0000798fc6fd7d51  push rdx
0000798fc6fd7d52  push rdi
0000798fc6fd7d53  push rsi
0000798fc6fd7d54  push r8
0000798fc6fd7d56  push r9
0000798fc6fd7d58  push r10
0000798fc6fd7d5a  push r11
0000798fc6fd7d5c  sub rsp, 0xF0
0000798fc6fd7d63  vmovaps [rsp], xmm0
0000798fc6fd7d68  vmovaps [rsp+0x10], xmm1
0000798fc6fd7d6e  vmovaps [rsp+0x20], xmm2
0000798fc6fd7d74  vmovaps [rsp+0x30], xmm3
0000798fc6fd7d7a  vmovaps [rsp+0x40], xmm4
0000798fc6fd7d80  vmovaps [rsp+0x50], xmm5
0000798fc6fd7d86  vmovaps [rsp+0x60], xmm6
0000798fc6fd7d8c  vmovaps [rsp+0x70], xmm8
0000798fc6fd7d92  vmovaps [rsp+0x80], xmm9
0000798fc6fd7d9b  vmovaps [rsp+0x90], xmm10
0000798fc6fd7da4  vmovaps [rsp+0xA0], xmm11
0000798fc6fd7dad  vmovaps [rsp+0xB0], xmm12
0000798fc6fd7db6  vmovaps [rsp+0xC0], xmm13
0000798fc6fd7dbf  vmovaps [rsp+0xD0], xmm14
0000798fc6fd7dc8  vmovaps [rsp+0xE0], xmm15
0000798fc6fd7dd1  sub rsp, 0x30
0000798fc6fd7dd5  movaps [rsp], xmm7
0000798fc6fd7dd9  movaps [rsp+0x10], xmm5
0000798fc6fd7dde  movaps [rsp+0x20], xmm15
0000798fc6fd7de4  lea rdi, [rsp]
0000798fc6fd7de8  mov esi, 0x00
0000798fc6fd7ded  mov rax, 0x63E558B23530
0000798fc6fd7df7  call rax
0000798fc6fd7df9  movaps xmm7, [rsp]
0000798fc6fd7dfd  add rsp, 0x30
0000798fc6fd7e01  vmovaps xmm0, [rsp]
0000798fc6fd7e06  vmovaps xmm1, [rsp+0x10]
0000798fc6fd7e0c  vmovaps xmm2, [rsp+0x20]
0000798fc6fd7e12  vmovaps xmm3, [rsp+0x30]
0000798fc6fd7e18  vmovaps xmm4, [rsp+0x40]
0000798fc6fd7e1e  vmovaps xmm5, [rsp+0x50]
0000798fc6fd7e24  vmovaps xmm6, [rsp+0x60]
0000798fc6fd7e2a  vmovaps xmm8, [rsp+0x70]
0000798fc6fd7e30  vmovaps xmm9, [rsp+0x80]
0000798fc6fd7e39  vmovaps xmm10, [rsp+0x90]
0000798fc6fd7e42  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd7e4b  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd7e54  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd7e5d  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd7e66  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd7e6f  add rsp, 0xF0
0000798fc6fd7e76  pop r11
0000798fc6fd7e78  pop r10
0000798fc6fd7e7a  pop r9
0000798fc6fd7e7c  pop r8
0000798fc6fd7e7e  pop rsi
0000798fc6fd7e7f  pop rdi
0000798fc6fd7e80  pop rdx
0000798fc6fd7e81  pop rcx
0000798fc6fd7e82  pop rax
0000798fc6fd7e83  add rsp, 0x08
0000798fc6fd7e87  jmp 0x0000798FC6FD5EB3
0000798fc6fd7e8c  call 0x0000798FC6ED64F0
0000798fc6fd7e91  jmp 0x0000798FC6FD5EC0
0000798fc6fd7e96  sub rsp, 0x08
0000798fc6fd7e9a  push rax
0000798fc6fd7e9b  push rcx
0000798fc6fd7e9c  push rdx
0000798fc6fd7e9d  push rdi
0000798fc6fd7e9e  push rsi
0000798fc6fd7e9f  push r8
0000798fc6fd7ea1  push r9
0000798fc6fd7ea3  push r10
0000798fc6fd7ea5  push r11
0000798fc6fd7ea7  sub rsp, 0xF0
0000798fc6fd7eae  vmovaps [rsp], xmm0
0000798fc6fd7eb3  vmovaps [rsp+0x10], xmm1
0000798fc6fd7eb9  vmovaps [rsp+0x20], xmm2
0000798fc6fd7ebf  vmovaps [rsp+0x30], xmm3
0000798fc6fd7ec5  vmovaps [rsp+0x40], xmm4
0000798fc6fd7ecb  vmovaps [rsp+0x50], xmm5
0000798fc6fd7ed1  vmovaps [rsp+0x60], xmm6
0000798fc6fd7ed7  vmovaps [rsp+0x70], xmm7
0000798fc6fd7edd  vmovaps [rsp+0x80], xmm8
0000798fc6fd7ee6  vmovaps [rsp+0x90], xmm9
0000798fc6fd7eef  vmovaps [rsp+0xA0], xmm10
0000798fc6fd7ef8  vmovaps [rsp+0xB0], xmm11
0000798fc6fd7f01  vmovaps [rsp+0xC0], xmm12
0000798fc6fd7f0a  vmovaps [rsp+0xD0], xmm13
0000798fc6fd7f13  vmovaps [rsp+0xE0], xmm14
0000798fc6fd7f1c  sub rsp, 0x30
0000798fc6fd7f20  movaps [rsp], xmm15
0000798fc6fd7f25  movaps [rsp+0x10], xmm5
0000798fc6fd7f2a  movaps [rsp+0x20], xmm3
0000798fc6fd7f2f  lea rdi, [rsp]
0000798fc6fd7f33  mov esi, 0x00
0000798fc6fd7f38  mov rax, 0x63E558B23530
0000798fc6fd7f42  call rax
0000798fc6fd7f44  movaps xmm15, [rsp]
0000798fc6fd7f49  add rsp, 0x30
0000798fc6fd7f4d  vmovaps xmm0, [rsp]
0000798fc6fd7f52  vmovaps xmm1, [rsp+0x10]
0000798fc6fd7f58  vmovaps xmm2, [rsp+0x20]
0000798fc6fd7f5e  vmovaps xmm3, [rsp+0x30]
0000798fc6fd7f64  vmovaps xmm4, [rsp+0x40]
0000798fc6fd7f6a  vmovaps xmm5, [rsp+0x50]
0000798fc6fd7f70  vmovaps xmm6, [rsp+0x60]
0000798fc6fd7f76  vmovaps xmm7, [rsp+0x70]
0000798fc6fd7f7c  vmovaps xmm8, [rsp+0x80]
0000798fc6fd7f85  vmovaps xmm9, [rsp+0x90]
0000798fc6fd7f8e  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd7f97  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd7fa0  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd7fa9  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd7fb2  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd7fbb  add rsp, 0xF0
0000798fc6fd7fc2  pop r11
0000798fc6fd7fc4  pop r10
0000798fc6fd7fc6  pop r9
0000798fc6fd7fc8  pop r8
0000798fc6fd7fca  pop rsi
0000798fc6fd7fcb  pop rdi
0000798fc6fd7fcc  pop rdx
0000798fc6fd7fcd  pop rcx
0000798fc6fd7fce  pop rax
0000798fc6fd7fcf  add rsp, 0x08
0000798fc6fd7fd3  jmp 0x0000798FC6FD5EE6
0000798fc6fd7fd8  sub rsp, 0x08
0000798fc6fd7fdc  push rax
0000798fc6fd7fdd  push rcx
0000798fc6fd7fde  push rdx
0000798fc6fd7fdf  push rdi
0000798fc6fd7fe0  push rsi
0000798fc6fd7fe1  push r8
0000798fc6fd7fe3  push r9
0000798fc6fd7fe5  push r10
0000798fc6fd7fe7  push r11
0000798fc6fd7fe9  sub rsp, 0xF0
0000798fc6fd7ff0  vmovaps [rsp], xmm0
0000798fc6fd7ff5  vmovaps [rsp+0x10], xmm2
0000798fc6fd7ffb  vmovaps [rsp+0x20], xmm3
0000798fc6fd8001  vmovaps [rsp+0x30], xmm4
0000798fc6fd8007  vmovaps [rsp+0x40], xmm5
0000798fc6fd800d  vmovaps [rsp+0x50], xmm6
0000798fc6fd8013  vmovaps [rsp+0x60], xmm7
0000798fc6fd8019  vmovaps [rsp+0x70], xmm8
0000798fc6fd801f  vmovaps [rsp+0x80], xmm9
0000798fc6fd8028  vmovaps [rsp+0x90], xmm10
0000798fc6fd8031  vmovaps [rsp+0xA0], xmm11
0000798fc6fd803a  vmovaps [rsp+0xB0], xmm12
0000798fc6fd8043  vmovaps [rsp+0xC0], xmm13
0000798fc6fd804c  vmovaps [rsp+0xD0], xmm14
0000798fc6fd8055  vmovaps [rsp+0xE0], xmm15
0000798fc6fd805e  sub rsp, 0x30
0000798fc6fd8062  movaps [rsp], xmm1
0000798fc6fd8066  movaps [rsp+0x10], xmm5
0000798fc6fd806b  movaps [rsp+0x20], xmm4
0000798fc6fd8070  lea rdi, [rsp]
0000798fc6fd8074  mov esi, 0x00
0000798fc6fd8079  mov rax, 0x63E558B23530
0000798fc6fd8083  call rax
0000798fc6fd8085  movaps xmm1, [rsp]
0000798fc6fd8089  add rsp, 0x30
0000798fc6fd808d  vmovaps xmm0, [rsp]
0000798fc6fd8092  vmovaps xmm2, [rsp+0x10]
0000798fc6fd8098  vmovaps xmm3, [rsp+0x20]
0000798fc6fd809e  vmovaps xmm4, [rsp+0x30]
0000798fc6fd80a4  vmovaps xmm5, [rsp+0x40]
0000798fc6fd80aa  vmovaps xmm6, [rsp+0x50]
0000798fc6fd80b0  vmovaps xmm7, [rsp+0x60]
0000798fc6fd80b6  vmovaps xmm8, [rsp+0x70]
0000798fc6fd80bc  vmovaps xmm9, [rsp+0x80]
0000798fc6fd80c5  vmovaps xmm10, [rsp+0x90]
0000798fc6fd80ce  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd80d7  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd80e0  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd80e9  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd80f2  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd80fb  add rsp, 0xF0
0000798fc6fd8102  pop r11
0000798fc6fd8104  pop r10
0000798fc6fd8106  pop r9
0000798fc6fd8108  pop r8
0000798fc6fd810a  pop rsi
0000798fc6fd810b  pop rdi
0000798fc6fd810c  pop rdx
0000798fc6fd810d  pop rcx
0000798fc6fd810e  pop rax
0000798fc6fd810f  add rsp, 0x08
0000798fc6fd8113  jmp 0x0000798FC6FD5F06
0000798fc6fd8118  sub rsp, 0x08
0000798fc6fd811c  push rax
0000798fc6fd811d  push rcx
0000798fc6fd811e  push rdx
0000798fc6fd811f  push rdi
0000798fc6fd8120  push rsi
0000798fc6fd8121  push r8
0000798fc6fd8123  push r9
0000798fc6fd8125  push r10
0000798fc6fd8127  push r11
0000798fc6fd8129  sub rsp, 0xF0
0000798fc6fd8130  vmovaps [rsp], xmm0
0000798fc6fd8135  vmovaps [rsp+0x10], xmm1
0000798fc6fd813b  vmovaps [rsp+0x20], xmm2
0000798fc6fd8141  vmovaps [rsp+0x30], xmm3
0000798fc6fd8147  vmovaps [rsp+0x40], xmm5
0000798fc6fd814d  vmovaps [rsp+0x50], xmm6
0000798fc6fd8153  vmovaps [rsp+0x60], xmm7
0000798fc6fd8159  vmovaps [rsp+0x70], xmm8
0000798fc6fd815f  vmovaps [rsp+0x80], xmm9
0000798fc6fd8168  vmovaps [rsp+0x90], xmm10
0000798fc6fd8171  vmovaps [rsp+0xA0], xmm11
0000798fc6fd817a  vmovaps [rsp+0xB0], xmm12
0000798fc6fd8183  vmovaps [rsp+0xC0], xmm13
0000798fc6fd818c  vmovaps [rsp+0xD0], xmm14
0000798fc6fd8195  vmovaps [rsp+0xE0], xmm15
0000798fc6fd819e  sub rsp, 0x30
0000798fc6fd81a2  movaps [rsp], xmm4
0000798fc6fd81a6  movaps [rsp+0x10], xmm3
0000798fc6fd81ab  movaps [rsp+0x20], xmm5
0000798fc6fd81b0  lea rdi, [rsp]
0000798fc6fd81b4  mov esi, 0x00
0000798fc6fd81b9  mov rax, 0x63E558B23530
0000798fc6fd81c3  call rax
0000798fc6fd81c5  movaps xmm4, [rsp]
0000798fc6fd81c9  add rsp, 0x30
0000798fc6fd81cd  vmovaps xmm0, [rsp]
0000798fc6fd81d2  vmovaps xmm1, [rsp+0x10]
0000798fc6fd81d8  vmovaps xmm2, [rsp+0x20]
0000798fc6fd81de  vmovaps xmm3, [rsp+0x30]
0000798fc6fd81e4  vmovaps xmm5, [rsp+0x40]
0000798fc6fd81ea  vmovaps xmm6, [rsp+0x50]
0000798fc6fd81f0  vmovaps xmm7, [rsp+0x60]
0000798fc6fd81f6  vmovaps xmm8, [rsp+0x70]
0000798fc6fd81fc  vmovaps xmm9, [rsp+0x80]
0000798fc6fd8205  vmovaps xmm10, [rsp+0x90]
0000798fc6fd820e  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd8217  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd8220  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd8229  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd8232  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd823b  add rsp, 0xF0
0000798fc6fd8242  pop r11
0000798fc6fd8244  pop r10
0000798fc6fd8246  pop r9
0000798fc6fd8248  pop r8
0000798fc6fd824a  pop rsi
0000798fc6fd824b  pop rdi
0000798fc6fd824c  pop rdx
0000798fc6fd824d  pop rcx
0000798fc6fd824e  pop rax
0000798fc6fd824f  add rsp, 0x08
0000798fc6fd8253  jmp 0x0000798FC6FD5F54
0000798fc6fd8258  call 0x0000798FC6ED64F0
0000798fc6fd825d  jmp 0x0000798FC6FD5F61
0000798fc6fd8262  sub rsp, 0x08
0000798fc6fd8266  push rax
0000798fc6fd8267  push rcx
0000798fc6fd8268  push rdx
0000798fc6fd8269  push rdi
0000798fc6fd826a  push rsi
0000798fc6fd826b  push r8
0000798fc6fd826d  push r9
0000798fc6fd826f  push r10
0000798fc6fd8271  push r11
0000798fc6fd8273  sub rsp, 0xF0
0000798fc6fd827a  vmovaps [rsp], xmm0
0000798fc6fd827f  vmovaps [rsp+0x10], xmm1
0000798fc6fd8285  vmovaps [rsp+0x20], xmm2
0000798fc6fd828b  vmovaps [rsp+0x30], xmm3
0000798fc6fd8291  vmovaps [rsp+0x40], xmm4
0000798fc6fd8297  vmovaps [rsp+0x50], xmm6
0000798fc6fd829d  vmovaps [rsp+0x60], xmm7
0000798fc6fd82a3  vmovaps [rsp+0x70], xmm8
0000798fc6fd82a9  vmovaps [rsp+0x80], xmm9
0000798fc6fd82b2  vmovaps [rsp+0x90], xmm10
0000798fc6fd82bb  vmovaps [rsp+0xA0], xmm11
0000798fc6fd82c4  vmovaps [rsp+0xB0], xmm12
0000798fc6fd82cd  vmovaps [rsp+0xC0], xmm13
0000798fc6fd82d6  vmovaps [rsp+0xD0], xmm14
0000798fc6fd82df  vmovaps [rsp+0xE0], xmm15
0000798fc6fd82e8  sub rsp, 0x30
0000798fc6fd82ec  movaps [rsp], xmm5
0000798fc6fd82f0  movaps [rsp+0x10], xmm6
0000798fc6fd82f5  movaps [rsp+0x20], xmm3
0000798fc6fd82fa  lea rdi, [rsp]
0000798fc6fd82fe  mov esi, 0x00
0000798fc6fd8303  mov rax, 0x63E558B23530
0000798fc6fd830d  call rax
0000798fc6fd830f  movaps xmm5, [rsp]
0000798fc6fd8313  add rsp, 0x30
0000798fc6fd8317  vmovaps xmm0, [rsp]
0000798fc6fd831c  vmovaps xmm1, [rsp+0x10]
0000798fc6fd8322  vmovaps xmm2, [rsp+0x20]
0000798fc6fd8328  vmovaps xmm3, [rsp+0x30]
0000798fc6fd832e  vmovaps xmm4, [rsp+0x40]
0000798fc6fd8334  vmovaps xmm6, [rsp+0x50]
0000798fc6fd833a  vmovaps xmm7, [rsp+0x60]
0000798fc6fd8340  vmovaps xmm8, [rsp+0x70]
0000798fc6fd8346  vmovaps xmm9, [rsp+0x80]
0000798fc6fd834f  vmovaps xmm10, [rsp+0x90]
0000798fc6fd8358  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd8361  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd836a  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd8373  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd837c  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd8385  add rsp, 0xF0
0000798fc6fd838c  pop r11
0000798fc6fd838e  pop r10
0000798fc6fd8390  pop r9
0000798fc6fd8392  pop r8
0000798fc6fd8394  pop rsi
0000798fc6fd8395  pop rdi
0000798fc6fd8396  pop rdx
0000798fc6fd8397  pop rcx
0000798fc6fd8398  pop rax
0000798fc6fd8399  add rsp, 0x08
0000798fc6fd839d  jmp 0x0000798FC6FD5F87
0000798fc6fd83a2  sub rsp, 0x08
0000798fc6fd83a6  push rax
0000798fc6fd83a7  push rcx
0000798fc6fd83a8  push rdx
0000798fc6fd83a9  push rdi
0000798fc6fd83aa  push rsi
0000798fc6fd83ab  push r8
0000798fc6fd83ad  push r9
0000798fc6fd83af  push r10
0000798fc6fd83b1  push r11
0000798fc6fd83b3  sub rsp, 0xF0
0000798fc6fd83ba  vmovaps [rsp], xmm0
0000798fc6fd83bf  vmovaps [rsp+0x10], xmm1
0000798fc6fd83c5  vmovaps [rsp+0x20], xmm2
0000798fc6fd83cb  vmovaps [rsp+0x30], xmm3
0000798fc6fd83d1  vmovaps [rsp+0x40], xmm4
0000798fc6fd83d7  vmovaps [rsp+0x50], xmm5
0000798fc6fd83dd  vmovaps [rsp+0x60], xmm7
0000798fc6fd83e3  vmovaps [rsp+0x70], xmm8
0000798fc6fd83e9  vmovaps [rsp+0x80], xmm9
0000798fc6fd83f2  vmovaps [rsp+0x90], xmm10
0000798fc6fd83fb  vmovaps [rsp+0xA0], xmm11
0000798fc6fd8404  vmovaps [rsp+0xB0], xmm12
0000798fc6fd840d  vmovaps [rsp+0xC0], xmm13
0000798fc6fd8416  vmovaps [rsp+0xD0], xmm14
0000798fc6fd841f  vmovaps [rsp+0xE0], xmm15
0000798fc6fd8428  sub rsp, 0x30
0000798fc6fd842c  movaps [rsp], xmm6
0000798fc6fd8430  movaps [rsp+0x10], xmm9
0000798fc6fd8436  movaps [rsp+0x20], xmm1
0000798fc6fd843b  lea rdi, [rsp]
0000798fc6fd843f  mov esi, 0x00
0000798fc6fd8444  mov rax, 0x63E558B23530
0000798fc6fd844e  call rax
0000798fc6fd8450  movaps xmm6, [rsp]
0000798fc6fd8454  add rsp, 0x30
0000798fc6fd8458  vmovaps xmm0, [rsp]
0000798fc6fd845d  vmovaps xmm1, [rsp+0x10]
0000798fc6fd8463  vmovaps xmm2, [rsp+0x20]
0000798fc6fd8469  vmovaps xmm3, [rsp+0x30]
0000798fc6fd846f  vmovaps xmm4, [rsp+0x40]
0000798fc6fd8475  vmovaps xmm5, [rsp+0x50]
0000798fc6fd847b  vmovaps xmm7, [rsp+0x60]
0000798fc6fd8481  vmovaps xmm8, [rsp+0x70]
0000798fc6fd8487  vmovaps xmm9, [rsp+0x80]
0000798fc6fd8490  vmovaps xmm10, [rsp+0x90]
0000798fc6fd8499  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd84a2  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd84ab  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd84b4  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd84bd  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd84c6  add rsp, 0xF0
0000798fc6fd84cd  pop r11
0000798fc6fd84cf  pop r10
0000798fc6fd84d1  pop r9
0000798fc6fd84d3  pop r8
0000798fc6fd84d5  pop rsi
0000798fc6fd84d6  pop rdi
0000798fc6fd84d7  pop rdx
0000798fc6fd84d8  pop rcx
0000798fc6fd84d9  pop rax
0000798fc6fd84da  add rsp, 0x08
0000798fc6fd84de  jmp 0x0000798FC6FD5FAB
0000798fc6fd84e3  sub rsp, 0x08
0000798fc6fd84e7  push rax
0000798fc6fd84e8  push rcx
0000798fc6fd84e9  push rdx
0000798fc6fd84ea  push rdi
0000798fc6fd84eb  push rsi
0000798fc6fd84ec  push r8
0000798fc6fd84ee  push r9
0000798fc6fd84f0  push r10
0000798fc6fd84f2  push r11
0000798fc6fd84f4  sub rsp, 0xF0
0000798fc6fd84fb  vmovaps [rsp], xmm0
0000798fc6fd8500  vmovaps [rsp+0x10], xmm1
0000798fc6fd8506  vmovaps [rsp+0x20], xmm2
0000798fc6fd850c  vmovaps [rsp+0x30], xmm3
0000798fc6fd8512  vmovaps [rsp+0x40], xmm4
0000798fc6fd8518  vmovaps [rsp+0x50], xmm5
0000798fc6fd851e  vmovaps [rsp+0x60], xmm6
0000798fc6fd8524  vmovaps [rsp+0x70], xmm7
0000798fc6fd852a  vmovaps [rsp+0x80], xmm8
0000798fc6fd8533  vmovaps [rsp+0x90], xmm10
0000798fc6fd853c  vmovaps [rsp+0xA0], xmm11
0000798fc6fd8545  vmovaps [rsp+0xB0], xmm12
0000798fc6fd854e  vmovaps [rsp+0xC0], xmm13
0000798fc6fd8557  vmovaps [rsp+0xD0], xmm14
0000798fc6fd8560  vmovaps [rsp+0xE0], xmm15
0000798fc6fd8569  sub rsp, 0x30
0000798fc6fd856d  movaps [rsp], xmm9
0000798fc6fd8572  movaps [rsp+0x10], xmm3
0000798fc6fd8577  movaps [rsp+0x20], xmm1
0000798fc6fd857c  lea rdi, [rsp]
0000798fc6fd8580  mov esi, 0x00
0000798fc6fd8585  mov rax, 0x63E558B23530
0000798fc6fd858f  call rax
0000798fc6fd8591  movaps xmm9, [rsp]
0000798fc6fd8596  add rsp, 0x30
0000798fc6fd859a  vmovaps xmm0, [rsp]
0000798fc6fd859f  vmovaps xmm1, [rsp+0x10]
0000798fc6fd85a5  vmovaps xmm2, [rsp+0x20]
0000798fc6fd85ab  vmovaps xmm3, [rsp+0x30]
0000798fc6fd85b1  vmovaps xmm4, [rsp+0x40]
0000798fc6fd85b7  vmovaps xmm5, [rsp+0x50]
0000798fc6fd85bd  vmovaps xmm6, [rsp+0x60]
0000798fc6fd85c3  vmovaps xmm7, [rsp+0x70]
0000798fc6fd85c9  vmovaps xmm8, [rsp+0x80]
0000798fc6fd85d2  vmovaps xmm10, [rsp+0x90]
0000798fc6fd85db  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd85e4  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd85ed  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd85f6  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd85ff  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd8608  add rsp, 0xF0
0000798fc6fd860f  pop r11
0000798fc6fd8611  pop r10
0000798fc6fd8613  pop r9
0000798fc6fd8615  pop r8
0000798fc6fd8617  pop rsi
0000798fc6fd8618  pop rdi
0000798fc6fd8619  pop rdx
0000798fc6fd861a  pop rcx
0000798fc6fd861b  pop rax
0000798fc6fd861c  add rsp, 0x08
0000798fc6fd8620  jmp 0x0000798FC6FD5FF7
0000798fc6fd8625  call 0x0000798FC6ED64F0
0000798fc6fd862a  jmp 0x0000798FC6FD6004
0000798fc6fd862f  sub rsp, 0x08
0000798fc6fd8633  push rax
0000798fc6fd8634  push rcx
0000798fc6fd8635  push rdx
0000798fc6fd8636  push rdi
0000798fc6fd8637  push rsi
0000798fc6fd8638  push r8
0000798fc6fd863a  push r9
0000798fc6fd863c  push r10
0000798fc6fd863e  push r11
0000798fc6fd8640  sub rsp, 0xF0
0000798fc6fd8647  vmovaps [rsp], xmm0
0000798fc6fd864c  vmovaps [rsp+0x10], xmm1
0000798fc6fd8652  vmovaps [rsp+0x20], xmm2
0000798fc6fd8658  vmovaps [rsp+0x30], xmm3
0000798fc6fd865e  vmovaps [rsp+0x40], xmm4
0000798fc6fd8664  vmovaps [rsp+0x50], xmm5
0000798fc6fd866a  vmovaps [rsp+0x60], xmm6
0000798fc6fd8670  vmovaps [rsp+0x70], xmm7
0000798fc6fd8676  vmovaps [rsp+0x80], xmm8
0000798fc6fd867f  vmovaps [rsp+0x90], xmm9
0000798fc6fd8688  vmovaps [rsp+0xA0], xmm10
0000798fc6fd8691  vmovaps [rsp+0xB0], xmm11
0000798fc6fd869a  vmovaps [rsp+0xC0], xmm12
0000798fc6fd86a3  vmovaps [rsp+0xD0], xmm13
0000798fc6fd86ac  vmovaps [rsp+0xE0], xmm14
0000798fc6fd86b5  sub rsp, 0x30
0000798fc6fd86b9  movaps [rsp], xmm15
0000798fc6fd86be  movaps [rsp+0x10], xmm3
0000798fc6fd86c3  movaps [rsp+0x20], xmm7
0000798fc6fd86c8  lea rdi, [rsp]
0000798fc6fd86cc  mov esi, 0x00
0000798fc6fd86d1  mov rax, 0x63E558B23530
0000798fc6fd86db  call rax
0000798fc6fd86dd  movaps xmm15, [rsp]
0000798fc6fd86e2  add rsp, 0x30
0000798fc6fd86e6  vmovaps xmm0, [rsp]
0000798fc6fd86eb  vmovaps xmm1, [rsp+0x10]
0000798fc6fd86f1  vmovaps xmm2, [rsp+0x20]
0000798fc6fd86f7  vmovaps xmm3, [rsp+0x30]
0000798fc6fd86fd  vmovaps xmm4, [rsp+0x40]
0000798fc6fd8703  vmovaps xmm5, [rsp+0x50]
0000798fc6fd8709  vmovaps xmm6, [rsp+0x60]
0000798fc6fd870f  vmovaps xmm7, [rsp+0x70]
0000798fc6fd8715  vmovaps xmm8, [rsp+0x80]
0000798fc6fd871e  vmovaps xmm9, [rsp+0x90]
0000798fc6fd8727  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd8730  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd8739  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd8742  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd874b  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd8754  add rsp, 0xF0
0000798fc6fd875b  pop r11
0000798fc6fd875d  pop r10
0000798fc6fd875f  pop r9
0000798fc6fd8761  pop r8
0000798fc6fd8763  pop rsi
0000798fc6fd8764  pop rdi
0000798fc6fd8765  pop rdx
0000798fc6fd8766  pop rcx
0000798fc6fd8767  pop rax
0000798fc6fd8768  add rsp, 0x08
0000798fc6fd876c  jmp 0x0000798FC6FD6030
0000798fc6fd8771  sub rsp, 0x08
0000798fc6fd8775  push rax
0000798fc6fd8776  push rcx
0000798fc6fd8777  push rdx
0000798fc6fd8778  push rdi
0000798fc6fd8779  push rsi
0000798fc6fd877a  push r8
0000798fc6fd877c  push r9
0000798fc6fd877e  push r10
0000798fc6fd8780  push r11
0000798fc6fd8782  sub rsp, 0xF0
0000798fc6fd8789  vmovaps [rsp], xmm0
0000798fc6fd878e  vmovaps [rsp+0x10], xmm1
0000798fc6fd8794  vmovaps [rsp+0x20], xmm2
0000798fc6fd879a  vmovaps [rsp+0x30], xmm4
0000798fc6fd87a0  vmovaps [rsp+0x40], xmm5
0000798fc6fd87a6  vmovaps [rsp+0x50], xmm6
0000798fc6fd87ac  vmovaps [rsp+0x60], xmm7
0000798fc6fd87b2  vmovaps [rsp+0x70], xmm8
0000798fc6fd87b8  vmovaps [rsp+0x80], xmm9
0000798fc6fd87c1  vmovaps [rsp+0x90], xmm10
0000798fc6fd87ca  vmovaps [rsp+0xA0], xmm11
0000798fc6fd87d3  vmovaps [rsp+0xB0], xmm12
0000798fc6fd87dc  vmovaps [rsp+0xC0], xmm13
0000798fc6fd87e5  vmovaps [rsp+0xD0], xmm14
0000798fc6fd87ee  vmovaps [rsp+0xE0], xmm15
0000798fc6fd87f7  sub rsp, 0x30
0000798fc6fd87fb  movaps [rsp], xmm3
0000798fc6fd87ff  movaps [rsp+0x10], xmm1
0000798fc6fd8804  movaps [rsp+0x20], xmm15
0000798fc6fd880a  lea rdi, [rsp]
0000798fc6fd880e  mov esi, 0x00
0000798fc6fd8813  mov rax, 0x63E558B23530
0000798fc6fd881d  call rax
0000798fc6fd881f  movaps xmm3, [rsp]
0000798fc6fd8823  add rsp, 0x30
0000798fc6fd8827  vmovaps xmm0, [rsp]
0000798fc6fd882c  vmovaps xmm1, [rsp+0x10]
0000798fc6fd8832  vmovaps xmm2, [rsp+0x20]
0000798fc6fd8838  vmovaps xmm4, [rsp+0x30]
0000798fc6fd883e  vmovaps xmm5, [rsp+0x40]
0000798fc6fd8844  vmovaps xmm6, [rsp+0x50]
0000798fc6fd884a  vmovaps xmm7, [rsp+0x60]
0000798fc6fd8850  vmovaps xmm8, [rsp+0x70]
0000798fc6fd8856  vmovaps xmm9, [rsp+0x80]
0000798fc6fd885f  vmovaps xmm10, [rsp+0x90]
0000798fc6fd8868  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd8871  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd887a  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd8883  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd888c  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd8895  add rsp, 0xF0
0000798fc6fd889c  pop r11
0000798fc6fd889e  pop r10
0000798fc6fd88a0  pop r9
0000798fc6fd88a2  pop r8
0000798fc6fd88a4  pop rsi
0000798fc6fd88a5  pop rdi
0000798fc6fd88a6  pop rdx
0000798fc6fd88a7  pop rcx
0000798fc6fd88a8  pop rax
0000798fc6fd88a9  add rsp, 0x08
0000798fc6fd88ad  jmp 0x0000798FC6FD60BF
0000798fc6fd88b2  call 0x0000798FC6ED64F0
0000798fc6fd88b7  jmp 0x0000798FC6FD60C9
0000798fc6fd88bc  sub rsp, 0x08
0000798fc6fd88c0  push rax
0000798fc6fd88c1  push rcx
0000798fc6fd88c2  push rdx
0000798fc6fd88c3  push rdi
0000798fc6fd88c4  push rsi
0000798fc6fd88c5  push r8
0000798fc6fd88c7  push r9
0000798fc6fd88c9  push r10
0000798fc6fd88cb  push r11
0000798fc6fd88cd  sub rsp, 0xF0
0000798fc6fd88d4  vmovaps [rsp], xmm0
0000798fc6fd88d9  vmovaps [rsp+0x10], xmm1
0000798fc6fd88df  vmovaps [rsp+0x20], xmm2
0000798fc6fd88e5  vmovaps [rsp+0x30], xmm3
0000798fc6fd88eb  vmovaps [rsp+0x40], xmm4
0000798fc6fd88f1  vmovaps [rsp+0x50], xmm5
0000798fc6fd88f7  vmovaps [rsp+0x60], xmm6
0000798fc6fd88fd  vmovaps [rsp+0x70], xmm7
0000798fc6fd8903  vmovaps [rsp+0x80], xmm8
0000798fc6fd890c  vmovaps [rsp+0x90], xmm9
0000798fc6fd8915  vmovaps [rsp+0xA0], xmm10
0000798fc6fd891e  vmovaps [rsp+0xB0], xmm11
0000798fc6fd8927  vmovaps [rsp+0xC0], xmm12
0000798fc6fd8930  vmovaps [rsp+0xD0], xmm13
0000798fc6fd8939  vmovaps [rsp+0xE0], xmm14
0000798fc6fd8942  sub rsp, 0x30
0000798fc6fd8946  movaps [rsp], xmm15
0000798fc6fd894b  movaps [rsp+0x10], xmm14
0000798fc6fd8951  movaps [rsp+0x20], xmm4
0000798fc6fd8956  lea rdi, [rsp]
0000798fc6fd895a  mov esi, 0x00
0000798fc6fd895f  mov rax, 0x63E558B23530
0000798fc6fd8969  call rax
0000798fc6fd896b  movaps xmm15, [rsp]
0000798fc6fd8970  add rsp, 0x30
0000798fc6fd8974  vmovaps xmm0, [rsp]
0000798fc6fd8979  vmovaps xmm1, [rsp+0x10]
0000798fc6fd897f  vmovaps xmm2, [rsp+0x20]
0000798fc6fd8985  vmovaps xmm3, [rsp+0x30]
0000798fc6fd898b  vmovaps xmm4, [rsp+0x40]
0000798fc6fd8991  vmovaps xmm5, [rsp+0x50]
0000798fc6fd8997  vmovaps xmm6, [rsp+0x60]
0000798fc6fd899d  vmovaps xmm7, [rsp+0x70]
0000798fc6fd89a3  vmovaps xmm8, [rsp+0x80]
0000798fc6fd89ac  vmovaps xmm9, [rsp+0x90]
0000798fc6fd89b5  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd89be  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd89c7  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd89d0  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd89d9  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd89e2  add rsp, 0xF0
0000798fc6fd89e9  pop r11
0000798fc6fd89eb  pop r10
0000798fc6fd89ed  pop r9
0000798fc6fd89ef  pop r8
0000798fc6fd89f1  pop rsi
0000798fc6fd89f2  pop rdi
0000798fc6fd89f3  pop rdx
0000798fc6fd89f4  pop rcx
0000798fc6fd89f5  pop rax
0000798fc6fd89f6  add rsp, 0x08
0000798fc6fd89fa  jmp 0x0000798FC6FD60F7
0000798fc6fd89ff  sub rsp, 0x08
0000798fc6fd8a03  push rax
0000798fc6fd8a04  push rcx
0000798fc6fd8a05  push rdx
0000798fc6fd8a06  push rdi
0000798fc6fd8a07  push rsi
0000798fc6fd8a08  push r8
0000798fc6fd8a0a  push r9
0000798fc6fd8a0c  push r10
0000798fc6fd8a0e  push r11
0000798fc6fd8a10  sub rsp, 0xF0
0000798fc6fd8a17  vmovaps [rsp], xmm0
0000798fc6fd8a1c  vmovaps [rsp+0x10], xmm1
0000798fc6fd8a22  vmovaps [rsp+0x20], xmm2
0000798fc6fd8a28  vmovaps [rsp+0x30], xmm3
0000798fc6fd8a2e  vmovaps [rsp+0x40], xmm4
0000798fc6fd8a34  vmovaps [rsp+0x50], xmm5
0000798fc6fd8a3a  vmovaps [rsp+0x60], xmm6
0000798fc6fd8a40  vmovaps [rsp+0x70], xmm7
0000798fc6fd8a46  vmovaps [rsp+0x80], xmm8
0000798fc6fd8a4f  vmovaps [rsp+0x90], xmm9
0000798fc6fd8a58  vmovaps [rsp+0xA0], xmm10
0000798fc6fd8a61  vmovaps [rsp+0xB0], xmm11
0000798fc6fd8a6a  vmovaps [rsp+0xC0], xmm12
0000798fc6fd8a73  vmovaps [rsp+0xD0], xmm13
0000798fc6fd8a7c  vmovaps [rsp+0xE0], xmm15
0000798fc6fd8a85  sub rsp, 0x30
0000798fc6fd8a89  movaps [rsp], xmm14
0000798fc6fd8a8e  movaps [rsp+0x10], xmm2
0000798fc6fd8a93  movaps [rsp+0x20], xmm1
0000798fc6fd8a98  lea rdi, [rsp]
0000798fc6fd8a9c  mov esi, 0x00
0000798fc6fd8aa1  mov rax, 0x63E558B23530
0000798fc6fd8aab  call rax
0000798fc6fd8aad  movaps xmm14, [rsp]
0000798fc6fd8ab2  add rsp, 0x30
0000798fc6fd8ab6  vmovaps xmm0, [rsp]
0000798fc6fd8abb  vmovaps xmm1, [rsp+0x10]
0000798fc6fd8ac1  vmovaps xmm2, [rsp+0x20]
0000798fc6fd8ac7  vmovaps xmm3, [rsp+0x30]
0000798fc6fd8acd  vmovaps xmm4, [rsp+0x40]
0000798fc6fd8ad3  vmovaps xmm5, [rsp+0x50]
0000798fc6fd8ad9  vmovaps xmm6, [rsp+0x60]
0000798fc6fd8adf  vmovaps xmm7, [rsp+0x70]
0000798fc6fd8ae5  vmovaps xmm8, [rsp+0x80]
0000798fc6fd8aee  vmovaps xmm9, [rsp+0x90]
0000798fc6fd8af7  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd8b00  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd8b09  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd8b12  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd8b1b  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd8b24  add rsp, 0xF0
0000798fc6fd8b2b  pop r11
0000798fc6fd8b2d  pop r10
0000798fc6fd8b2f  pop r9
0000798fc6fd8b31  pop r8
0000798fc6fd8b33  pop rsi
0000798fc6fd8b34  pop rdi
0000798fc6fd8b35  pop rdx
0000798fc6fd8b36  pop rcx
0000798fc6fd8b37  pop rax
0000798fc6fd8b38  add rsp, 0x08
0000798fc6fd8b3c  jmp 0x0000798FC6FD611D
0000798fc6fd8b41  sub rsp, 0x08
0000798fc6fd8b45  push rax
0000798fc6fd8b46  push rcx
0000798fc6fd8b47  push rdx
0000798fc6fd8b48  push rdi
0000798fc6fd8b49  push rsi
0000798fc6fd8b4a  push r8
0000798fc6fd8b4c  push r9
0000798fc6fd8b4e  push r10
0000798fc6fd8b50  push r11
0000798fc6fd8b52  sub rsp, 0xF0
0000798fc6fd8b59  vmovaps [rsp], xmm0
0000798fc6fd8b5e  vmovaps [rsp+0x10], xmm2
0000798fc6fd8b64  vmovaps [rsp+0x20], xmm3
0000798fc6fd8b6a  vmovaps [rsp+0x30], xmm4
0000798fc6fd8b70  vmovaps [rsp+0x40], xmm5
0000798fc6fd8b76  vmovaps [rsp+0x50], xmm6
0000798fc6fd8b7c  vmovaps [rsp+0x60], xmm7
0000798fc6fd8b82  vmovaps [rsp+0x70], xmm8
0000798fc6fd8b88  vmovaps [rsp+0x80], xmm9
0000798fc6fd8b91  vmovaps [rsp+0x90], xmm10
0000798fc6fd8b9a  vmovaps [rsp+0xA0], xmm11
0000798fc6fd8ba3  vmovaps [rsp+0xB0], xmm12
0000798fc6fd8bac  vmovaps [rsp+0xC0], xmm13
0000798fc6fd8bb5  vmovaps [rsp+0xD0], xmm14
0000798fc6fd8bbe  vmovaps [rsp+0xE0], xmm15
0000798fc6fd8bc7  sub rsp, 0x30
0000798fc6fd8bcb  movaps [rsp], xmm1
0000798fc6fd8bcf  movaps [rsp+0x10], xmm4
0000798fc6fd8bd4  movaps [rsp+0x20], xmm9
0000798fc6fd8bda  lea rdi, [rsp]
0000798fc6fd8bde  mov esi, 0x00
0000798fc6fd8be3  mov rax, 0x63E558B23530
0000798fc6fd8bed  call rax
0000798fc6fd8bef  movaps xmm1, [rsp]
0000798fc6fd8bf3  add rsp, 0x30
0000798fc6fd8bf7  vmovaps xmm0, [rsp]
0000798fc6fd8bfc  vmovaps xmm2, [rsp+0x10]
0000798fc6fd8c02  vmovaps xmm3, [rsp+0x20]
0000798fc6fd8c08  vmovaps xmm4, [rsp+0x30]
0000798fc6fd8c0e  vmovaps xmm5, [rsp+0x40]
0000798fc6fd8c14  vmovaps xmm6, [rsp+0x50]
0000798fc6fd8c1a  vmovaps xmm7, [rsp+0x60]
0000798fc6fd8c20  vmovaps xmm8, [rsp+0x70]
0000798fc6fd8c26  vmovaps xmm9, [rsp+0x80]
0000798fc6fd8c2f  vmovaps xmm10, [rsp+0x90]
0000798fc6fd8c38  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd8c41  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd8c4a  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd8c53  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd8c5c  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd8c65  add rsp, 0xF0
0000798fc6fd8c6c  pop r11
0000798fc6fd8c6e  pop r10
0000798fc6fd8c70  pop r9
0000798fc6fd8c72  pop r8
0000798fc6fd8c74  pop rsi
0000798fc6fd8c75  pop rdi
0000798fc6fd8c76  pop rdx
0000798fc6fd8c77  pop rcx
0000798fc6fd8c78  pop rax
0000798fc6fd8c79  add rsp, 0x08
0000798fc6fd8c7d  jmp 0x0000798FC6FD613B
0000798fc6fd8c82  sub rsp, 0x08
0000798fc6fd8c86  push rax
0000798fc6fd8c87  push rcx
0000798fc6fd8c88  push rdx
0000798fc6fd8c89  push rdi
0000798fc6fd8c8a  push rsi
0000798fc6fd8c8b  push r8
0000798fc6fd8c8d  push r9
0000798fc6fd8c8f  push r10
0000798fc6fd8c91  push r11
0000798fc6fd8c93  sub rsp, 0xF0
0000798fc6fd8c9a  vmovaps [rsp], xmm0
0000798fc6fd8c9f  vmovaps [rsp+0x10], xmm1
0000798fc6fd8ca5  vmovaps [rsp+0x20], xmm2
0000798fc6fd8cab  vmovaps [rsp+0x30], xmm3
0000798fc6fd8cb1  vmovaps [rsp+0x40], xmm5
0000798fc6fd8cb7  vmovaps [rsp+0x50], xmm6
0000798fc6fd8cbd  vmovaps [rsp+0x60], xmm7
0000798fc6fd8cc3  vmovaps [rsp+0x70], xmm8
0000798fc6fd8cc9  vmovaps [rsp+0x80], xmm9
0000798fc6fd8cd2  vmovaps [rsp+0x90], xmm10
0000798fc6fd8cdb  vmovaps [rsp+0xA0], xmm11
0000798fc6fd8ce4  vmovaps [rsp+0xB0], xmm12
0000798fc6fd8ced  vmovaps [rsp+0xC0], xmm13
0000798fc6fd8cf6  vmovaps [rsp+0xD0], xmm14
0000798fc6fd8cff  vmovaps [rsp+0xE0], xmm15
0000798fc6fd8d08  sub rsp, 0x30
0000798fc6fd8d0c  movaps [rsp], xmm4
0000798fc6fd8d10  movaps [rsp+0x10], xmm2
0000798fc6fd8d15  movaps [rsp+0x20], xmm9
0000798fc6fd8d1b  lea rdi, [rsp]
0000798fc6fd8d1f  mov esi, 0x00
0000798fc6fd8d24  mov rax, 0x63E558B23530
0000798fc6fd8d2e  call rax
0000798fc6fd8d30  movaps xmm4, [rsp]
0000798fc6fd8d34  add rsp, 0x30
0000798fc6fd8d38  vmovaps xmm0, [rsp]
0000798fc6fd8d3d  vmovaps xmm1, [rsp+0x10]
0000798fc6fd8d43  vmovaps xmm2, [rsp+0x20]
0000798fc6fd8d49  vmovaps xmm3, [rsp+0x30]
0000798fc6fd8d4f  vmovaps xmm5, [rsp+0x40]
0000798fc6fd8d55  vmovaps xmm6, [rsp+0x50]
0000798fc6fd8d5b  vmovaps xmm7, [rsp+0x60]
0000798fc6fd8d61  vmovaps xmm8, [rsp+0x70]
0000798fc6fd8d67  vmovaps xmm9, [rsp+0x80]
0000798fc6fd8d70  vmovaps xmm10, [rsp+0x90]
0000798fc6fd8d79  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd8d82  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd8d8b  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd8d94  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd8d9d  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd8da6  add rsp, 0xF0
0000798fc6fd8dad  pop r11
0000798fc6fd8daf  pop r10
0000798fc6fd8db1  pop r9
0000798fc6fd8db3  pop r8
0000798fc6fd8db5  pop rsi
0000798fc6fd8db6  pop rdi
0000798fc6fd8db7  pop rdx
0000798fc6fd8db8  pop rcx
0000798fc6fd8db9  pop rax
0000798fc6fd8dba  add rsp, 0x08
0000798fc6fd8dbe  jmp 0x0000798FC6FD616B
0000798fc6fd8dc3  sub rsp, 0x08
0000798fc6fd8dc7  push rax
0000798fc6fd8dc8  push rcx
0000798fc6fd8dc9  push rdx
0000798fc6fd8dca  push rdi
0000798fc6fd8dcb  push rsi
0000798fc6fd8dcc  push r8
0000798fc6fd8dce  push r9
0000798fc6fd8dd0  push r10
0000798fc6fd8dd2  push r11
0000798fc6fd8dd4  sub rsp, 0xF0
0000798fc6fd8ddb  vmovaps [rsp], xmm0
0000798fc6fd8de0  vmovaps [rsp+0x10], xmm1
0000798fc6fd8de6  vmovaps [rsp+0x20], xmm2
0000798fc6fd8dec  vmovaps [rsp+0x30], xmm3
0000798fc6fd8df2  vmovaps [rsp+0x40], xmm4
0000798fc6fd8df8  vmovaps [rsp+0x50], xmm5
0000798fc6fd8dfe  vmovaps [rsp+0x60], xmm6
0000798fc6fd8e04  vmovaps [rsp+0x70], xmm7
0000798fc6fd8e0a  vmovaps [rsp+0x80], xmm8
0000798fc6fd8e13  vmovaps [rsp+0x90], xmm10
0000798fc6fd8e1c  vmovaps [rsp+0xA0], xmm11
0000798fc6fd8e25  vmovaps [rsp+0xB0], xmm12
0000798fc6fd8e2e  vmovaps [rsp+0xC0], xmm13
0000798fc6fd8e37  vmovaps [rsp+0xD0], xmm14
0000798fc6fd8e40  vmovaps [rsp+0xE0], xmm15
0000798fc6fd8e49  sub rsp, 0x30
0000798fc6fd8e4d  movaps [rsp], xmm9
0000798fc6fd8e52  movaps [rsp+0x10], xmm2
0000798fc6fd8e57  movaps [rsp+0x20], xmm1
0000798fc6fd8e5c  lea rdi, [rsp]
0000798fc6fd8e60  mov esi, 0x00
0000798fc6fd8e65  mov rax, 0x63E558B23530
0000798fc6fd8e6f  call rax
0000798fc6fd8e71  movaps xmm9, [rsp]
0000798fc6fd8e76  add rsp, 0x30
0000798fc6fd8e7a  vmovaps xmm0, [rsp]
0000798fc6fd8e7f  vmovaps xmm1, [rsp+0x10]
0000798fc6fd8e85  vmovaps xmm2, [rsp+0x20]
0000798fc6fd8e8b  vmovaps xmm3, [rsp+0x30]
0000798fc6fd8e91  vmovaps xmm4, [rsp+0x40]
0000798fc6fd8e97  vmovaps xmm5, [rsp+0x50]
0000798fc6fd8e9d  vmovaps xmm6, [rsp+0x60]
0000798fc6fd8ea3  vmovaps xmm7, [rsp+0x70]
0000798fc6fd8ea9  vmovaps xmm8, [rsp+0x80]
0000798fc6fd8eb2  vmovaps xmm10, [rsp+0x90]
0000798fc6fd8ebb  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd8ec4  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd8ecd  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd8ed6  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd8edf  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd8ee8  add rsp, 0xF0
0000798fc6fd8eef  pop r11
0000798fc6fd8ef1  pop r10
0000798fc6fd8ef3  pop r9
0000798fc6fd8ef5  pop r8
0000798fc6fd8ef7  pop rsi
0000798fc6fd8ef8  pop rdi
0000798fc6fd8ef9  pop rdx
0000798fc6fd8efa  pop rcx
0000798fc6fd8efb  pop rax
0000798fc6fd8efc  add rsp, 0x08
0000798fc6fd8f00  jmp 0x0000798FC6FD61A1
0000798fc6fd8f05  sub rsp, 0x08
0000798fc6fd8f09  push rax
0000798fc6fd8f0a  push rcx
0000798fc6fd8f0b  push rdx
0000798fc6fd8f0c  push rdi
0000798fc6fd8f0d  push rsi
0000798fc6fd8f0e  push r8
0000798fc6fd8f10  push r9
0000798fc6fd8f12  push r10
0000798fc6fd8f14  push r11
0000798fc6fd8f16  sub rsp, 0xF0
0000798fc6fd8f1d  vmovaps [rsp], xmm0
0000798fc6fd8f22  vmovaps [rsp+0x10], xmm2
0000798fc6fd8f28  vmovaps [rsp+0x20], xmm3
0000798fc6fd8f2e  vmovaps [rsp+0x30], xmm4
0000798fc6fd8f34  vmovaps [rsp+0x40], xmm5
0000798fc6fd8f3a  vmovaps [rsp+0x50], xmm6
0000798fc6fd8f40  vmovaps [rsp+0x60], xmm7
0000798fc6fd8f46  vmovaps [rsp+0x70], xmm8
0000798fc6fd8f4c  vmovaps [rsp+0x80], xmm9
0000798fc6fd8f55  vmovaps [rsp+0x90], xmm10
0000798fc6fd8f5e  vmovaps [rsp+0xA0], xmm11
0000798fc6fd8f67  vmovaps [rsp+0xB0], xmm12
0000798fc6fd8f70  vmovaps [rsp+0xC0], xmm13
0000798fc6fd8f79  vmovaps [rsp+0xD0], xmm14
0000798fc6fd8f82  vmovaps [rsp+0xE0], xmm15
0000798fc6fd8f8b  sub rsp, 0x30
0000798fc6fd8f8f  movaps [rsp], xmm1
0000798fc6fd8f93  movaps [rsp+0x10], xmm15
0000798fc6fd8f99  movaps [rsp+0x20], xmm6
0000798fc6fd8f9e  lea rdi, [rsp]
0000798fc6fd8fa2  mov esi, 0x00
0000798fc6fd8fa7  mov rax, 0x63E558B23530
0000798fc6fd8fb1  call rax
0000798fc6fd8fb3  movaps xmm1, [rsp]
0000798fc6fd8fb7  add rsp, 0x30
0000798fc6fd8fbb  vmovaps xmm0, [rsp]
0000798fc6fd8fc0  vmovaps xmm2, [rsp+0x10]
0000798fc6fd8fc6  vmovaps xmm3, [rsp+0x20]
0000798fc6fd8fcc  vmovaps xmm4, [rsp+0x30]
0000798fc6fd8fd2  vmovaps xmm5, [rsp+0x40]
0000798fc6fd8fd8  vmovaps xmm6, [rsp+0x50]
0000798fc6fd8fde  vmovaps xmm7, [rsp+0x60]
0000798fc6fd8fe4  vmovaps xmm8, [rsp+0x70]
0000798fc6fd8fea  vmovaps xmm9, [rsp+0x80]
0000798fc6fd8ff3  vmovaps xmm10, [rsp+0x90]
0000798fc6fd8ffc  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd9005  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd900e  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd9017  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd9020  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd9029  add rsp, 0xF0
0000798fc6fd9030  pop r11
0000798fc6fd9032  pop r10
0000798fc6fd9034  pop r9
0000798fc6fd9036  pop r8
0000798fc6fd9038  pop rsi
0000798fc6fd9039  pop rdi
0000798fc6fd903a  pop rdx
0000798fc6fd903b  pop rcx
0000798fc6fd903c  pop rax
0000798fc6fd903d  add rsp, 0x08
0000798fc6fd9041  jmp 0x0000798FC6FD61C2
0000798fc6fd9046  sub rsp, 0x08
0000798fc6fd904a  push rax
0000798fc6fd904b  push rcx
0000798fc6fd904c  push rdx
0000798fc6fd904d  push rdi
0000798fc6fd904e  push rsi
0000798fc6fd904f  push r8
0000798fc6fd9051  push r9
0000798fc6fd9053  push r10
0000798fc6fd9055  push r11
0000798fc6fd9057  sub rsp, 0xF0
0000798fc6fd905e  vmovaps [rsp], xmm0
0000798fc6fd9063  vmovaps [rsp+0x10], xmm1
0000798fc6fd9069  vmovaps [rsp+0x20], xmm2
0000798fc6fd906f  vmovaps [rsp+0x30], xmm3
0000798fc6fd9075  vmovaps [rsp+0x40], xmm4
0000798fc6fd907b  vmovaps [rsp+0x50], xmm5
0000798fc6fd9081  vmovaps [rsp+0x60], xmm6
0000798fc6fd9087  vmovaps [rsp+0x70], xmm7
0000798fc6fd908d  vmovaps [rsp+0x80], xmm8
0000798fc6fd9096  vmovaps [rsp+0x90], xmm9
0000798fc6fd909f  vmovaps [rsp+0xA0], xmm10
0000798fc6fd90a8  vmovaps [rsp+0xB0], xmm11
0000798fc6fd90b1  vmovaps [rsp+0xC0], xmm12
0000798fc6fd90ba  vmovaps [rsp+0xD0], xmm13
0000798fc6fd90c3  vmovaps [rsp+0xE0], xmm14
0000798fc6fd90cc  sub rsp, 0x30
0000798fc6fd90d0  movaps [rsp], xmm15
0000798fc6fd90d5  movaps [rsp+0x10], xmm5
0000798fc6fd90da  movaps [rsp+0x20], xmm3
0000798fc6fd90df  lea rdi, [rsp]
0000798fc6fd90e3  mov esi, 0x00
0000798fc6fd90e8  mov rax, 0x63E558B23530
0000798fc6fd90f2  call rax
0000798fc6fd90f4  movaps xmm15, [rsp]
0000798fc6fd90f9  add rsp, 0x30
0000798fc6fd90fd  vmovaps xmm0, [rsp]
0000798fc6fd9102  vmovaps xmm1, [rsp+0x10]
0000798fc6fd9108  vmovaps xmm2, [rsp+0x20]
0000798fc6fd910e  vmovaps xmm3, [rsp+0x30]
0000798fc6fd9114  vmovaps xmm4, [rsp+0x40]
0000798fc6fd911a  vmovaps xmm5, [rsp+0x50]
0000798fc6fd9120  vmovaps xmm6, [rsp+0x60]
0000798fc6fd9126  vmovaps xmm7, [rsp+0x70]
0000798fc6fd912c  vmovaps xmm8, [rsp+0x80]
0000798fc6fd9135  vmovaps xmm9, [rsp+0x90]
0000798fc6fd913e  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd9147  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd9150  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd9159  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd9162  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd916b  add rsp, 0xF0
0000798fc6fd9172  pop r11
0000798fc6fd9174  pop r10
0000798fc6fd9176  pop r9
0000798fc6fd9178  pop r8
0000798fc6fd917a  pop rsi
0000798fc6fd917b  pop rdi
0000798fc6fd917c  pop rdx
0000798fc6fd917d  pop rcx
0000798fc6fd917e  pop rax
0000798fc6fd917f  add rsp, 0x08
0000798fc6fd9183  jmp 0x0000798FC6FD61DC
0000798fc6fd9188  sub rsp, 0x08
0000798fc6fd918c  push rax
0000798fc6fd918d  push rcx
0000798fc6fd918e  push rdx
0000798fc6fd918f  push rdi
0000798fc6fd9190  push rsi
0000798fc6fd9191  push r8
0000798fc6fd9193  push r9
0000798fc6fd9195  push r10
0000798fc6fd9197  push r11
0000798fc6fd9199  sub rsp, 0xF0
0000798fc6fd91a0  vmovaps [rsp], xmm0
0000798fc6fd91a5  vmovaps [rsp+0x10], xmm1
0000798fc6fd91ab  vmovaps [rsp+0x20], xmm2
0000798fc6fd91b1  vmovaps [rsp+0x30], xmm3
0000798fc6fd91b7  vmovaps [rsp+0x40], xmm4
0000798fc6fd91bd  vmovaps [rsp+0x50], xmm6
0000798fc6fd91c3  vmovaps [rsp+0x60], xmm7
0000798fc6fd91c9  vmovaps [rsp+0x70], xmm8
0000798fc6fd91cf  vmovaps [rsp+0x80], xmm9
0000798fc6fd91d8  vmovaps [rsp+0x90], xmm10
0000798fc6fd91e1  vmovaps [rsp+0xA0], xmm11
0000798fc6fd91ea  vmovaps [rsp+0xB0], xmm12
0000798fc6fd91f3  vmovaps [rsp+0xC0], xmm13
0000798fc6fd91fc  vmovaps [rsp+0xD0], xmm14
0000798fc6fd9205  vmovaps [rsp+0xE0], xmm15
0000798fc6fd920e  sub rsp, 0x30
0000798fc6fd9212  movaps [rsp], xmm5
0000798fc6fd9216  movaps [rsp+0x10], xmm8
0000798fc6fd921c  movaps [rsp+0x20], xmm6
0000798fc6fd9221  lea rdi, [rsp]
0000798fc6fd9225  mov esi, 0x00
0000798fc6fd922a  mov rax, 0x63E558B23530
0000798fc6fd9234  call rax
0000798fc6fd9236  movaps xmm5, [rsp]
0000798fc6fd923a  add rsp, 0x30
0000798fc6fd923e  vmovaps xmm0, [rsp]
0000798fc6fd9243  vmovaps xmm1, [rsp+0x10]
0000798fc6fd9249  vmovaps xmm2, [rsp+0x20]
0000798fc6fd924f  vmovaps xmm3, [rsp+0x30]
0000798fc6fd9255  vmovaps xmm4, [rsp+0x40]
0000798fc6fd925b  vmovaps xmm6, [rsp+0x50]
0000798fc6fd9261  vmovaps xmm7, [rsp+0x60]
0000798fc6fd9267  vmovaps xmm8, [rsp+0x70]
0000798fc6fd926d  vmovaps xmm9, [rsp+0x80]
0000798fc6fd9276  vmovaps xmm10, [rsp+0x90]
0000798fc6fd927f  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd9288  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd9291  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd929a  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd92a3  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd92ac  add rsp, 0xF0
0000798fc6fd92b3  pop r11
0000798fc6fd92b5  pop r10
0000798fc6fd92b7  pop r9
0000798fc6fd92b9  pop r8
0000798fc6fd92bb  pop rsi
0000798fc6fd92bc  pop rdi
0000798fc6fd92bd  pop rdx
0000798fc6fd92be  pop rcx
0000798fc6fd92bf  pop rax
0000798fc6fd92c0  add rsp, 0x08
0000798fc6fd92c4  jmp 0x0000798FC6FD6200
0000798fc6fd92c9  sub rsp, 0x08
0000798fc6fd92cd  push rax
0000798fc6fd92ce  push rcx
0000798fc6fd92cf  push rdx
0000798fc6fd92d0  push rdi
0000798fc6fd92d1  push rsi
0000798fc6fd92d2  push r8
0000798fc6fd92d4  push r9
0000798fc6fd92d6  push r10
0000798fc6fd92d8  push r11
0000798fc6fd92da  sub rsp, 0xF0
0000798fc6fd92e1  vmovaps [rsp], xmm0
0000798fc6fd92e6  vmovaps [rsp+0x10], xmm1
0000798fc6fd92ec  vmovaps [rsp+0x20], xmm2
0000798fc6fd92f2  vmovaps [rsp+0x30], xmm3
0000798fc6fd92f8  vmovaps [rsp+0x40], xmm4
0000798fc6fd92fe  vmovaps [rsp+0x50], xmm5
0000798fc6fd9304  vmovaps [rsp+0x60], xmm7
0000798fc6fd930a  vmovaps [rsp+0x70], xmm8
0000798fc6fd9310  vmovaps [rsp+0x80], xmm9
0000798fc6fd9319  vmovaps [rsp+0x90], xmm10
0000798fc6fd9322  vmovaps [rsp+0xA0], xmm11
0000798fc6fd932b  vmovaps [rsp+0xB0], xmm12
0000798fc6fd9334  vmovaps [rsp+0xC0], xmm13
0000798fc6fd933d  vmovaps [rsp+0xD0], xmm14
0000798fc6fd9346  vmovaps [rsp+0xE0], xmm15
0000798fc6fd934f  sub rsp, 0x30
0000798fc6fd9353  movaps [rsp], xmm6
0000798fc6fd9357  movaps [rsp+0x10], xmm10
0000798fc6fd935d  movaps [rsp+0x20], xmm8
0000798fc6fd9363  lea rdi, [rsp]
0000798fc6fd9367  mov esi, 0x00
0000798fc6fd936c  mov rax, 0x63E558B23530
0000798fc6fd9376  call rax
0000798fc6fd9378  movaps xmm6, [rsp]
0000798fc6fd937c  add rsp, 0x30
0000798fc6fd9380  vmovaps xmm0, [rsp]
0000798fc6fd9385  vmovaps xmm1, [rsp+0x10]
0000798fc6fd938b  vmovaps xmm2, [rsp+0x20]
0000798fc6fd9391  vmovaps xmm3, [rsp+0x30]
0000798fc6fd9397  vmovaps xmm4, [rsp+0x40]
0000798fc6fd939d  vmovaps xmm5, [rsp+0x50]
0000798fc6fd93a3  vmovaps xmm7, [rsp+0x60]
0000798fc6fd93a9  vmovaps xmm8, [rsp+0x70]
0000798fc6fd93af  vmovaps xmm9, [rsp+0x80]
0000798fc6fd93b8  vmovaps xmm10, [rsp+0x90]
0000798fc6fd93c1  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd93ca  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd93d3  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd93dc  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd93e5  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd93ee  add rsp, 0xF0
0000798fc6fd93f5  pop r11
0000798fc6fd93f7  pop r10
0000798fc6fd93f9  pop r9
0000798fc6fd93fb  pop r8
0000798fc6fd93fd  pop rsi
0000798fc6fd93fe  pop rdi
0000798fc6fd93ff  pop rdx
0000798fc6fd9400  pop rcx
0000798fc6fd9401  pop rax
0000798fc6fd9402  add rsp, 0x08
0000798fc6fd9406  jmp 0x0000798FC6FD6225
0000798fc6fd940b  sub rsp, 0x08
0000798fc6fd940f  push rax
0000798fc6fd9410  push rcx
0000798fc6fd9411  push rdx
0000798fc6fd9412  push rdi
0000798fc6fd9413  push rsi
0000798fc6fd9414  push r8
0000798fc6fd9416  push r9
0000798fc6fd9418  push r10
0000798fc6fd941a  push r11
0000798fc6fd941c  sub rsp, 0xF0
0000798fc6fd9423  vmovaps [rsp], xmm0
0000798fc6fd9428  vmovaps [rsp+0x10], xmm1
0000798fc6fd942e  vmovaps [rsp+0x20], xmm2
0000798fc6fd9434  vmovaps [rsp+0x30], xmm3
0000798fc6fd943a  vmovaps [rsp+0x40], xmm4
0000798fc6fd9440  vmovaps [rsp+0x50], xmm5
0000798fc6fd9446  vmovaps [rsp+0x60], xmm6
0000798fc6fd944c  vmovaps [rsp+0x70], xmm7
0000798fc6fd9452  vmovaps [rsp+0x80], xmm8
0000798fc6fd945b  vmovaps [rsp+0x90], xmm9
0000798fc6fd9464  vmovaps [rsp+0xA0], xmm11
0000798fc6fd946d  vmovaps [rsp+0xB0], xmm12
0000798fc6fd9476  vmovaps [rsp+0xC0], xmm13
0000798fc6fd947f  vmovaps [rsp+0xD0], xmm14
0000798fc6fd9488  vmovaps [rsp+0xE0], xmm15
0000798fc6fd9491  sub rsp, 0x30
0000798fc6fd9495  movaps [rsp], xmm10
0000798fc6fd949a  movaps [rsp+0x10], xmm8
0000798fc6fd94a0  movaps [rsp+0x20], xmm14
0000798fc6fd94a6  lea rdi, [rsp]
0000798fc6fd94aa  mov esi, 0x00
0000798fc6fd94af  mov rax, 0x63E558B23530
0000798fc6fd94b9  call rax
0000798fc6fd94bb  movaps xmm10, [rsp]
0000798fc6fd94c0  add rsp, 0x30
0000798fc6fd94c4  vmovaps xmm0, [rsp]
0000798fc6fd94c9  vmovaps xmm1, [rsp+0x10]
0000798fc6fd94cf  vmovaps xmm2, [rsp+0x20]
0000798fc6fd94d5  vmovaps xmm3, [rsp+0x30]
0000798fc6fd94db  vmovaps xmm4, [rsp+0x40]
0000798fc6fd94e1  vmovaps xmm5, [rsp+0x50]
0000798fc6fd94e7  vmovaps xmm6, [rsp+0x60]
0000798fc6fd94ed  vmovaps xmm7, [rsp+0x70]
0000798fc6fd94f3  vmovaps xmm8, [rsp+0x80]
0000798fc6fd94fc  vmovaps xmm9, [rsp+0x90]
0000798fc6fd9505  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd950e  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd9517  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd9520  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd9529  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd9532  add rsp, 0xF0
0000798fc6fd9539  pop r11
0000798fc6fd953b  pop r10
0000798fc6fd953d  pop r9
0000798fc6fd953f  pop r8
0000798fc6fd9541  pop rsi
0000798fc6fd9542  pop rdi
0000798fc6fd9543  pop rdx
0000798fc6fd9544  pop rcx
0000798fc6fd9545  pop rax
0000798fc6fd9546  add rsp, 0x08
0000798fc6fd954a  jmp 0x0000798FC6FD6245
0000798fc6fd954f  sub rsp, 0x08
0000798fc6fd9553  push rax
0000798fc6fd9554  push rcx
0000798fc6fd9555  push rdx
0000798fc6fd9556  push rdi
0000798fc6fd9557  push rsi
0000798fc6fd9558  push r8
0000798fc6fd955a  push r9
0000798fc6fd955c  push r10
0000798fc6fd955e  push r11
0000798fc6fd9560  sub rsp, 0xF0
0000798fc6fd9567  vmovaps [rsp], xmm0
0000798fc6fd956c  vmovaps [rsp+0x10], xmm1
0000798fc6fd9572  vmovaps [rsp+0x20], xmm2
0000798fc6fd9578  vmovaps [rsp+0x30], xmm3
0000798fc6fd957e  vmovaps [rsp+0x40], xmm4
0000798fc6fd9584  vmovaps [rsp+0x50], xmm5
0000798fc6fd958a  vmovaps [rsp+0x60], xmm6
0000798fc6fd9590  vmovaps [rsp+0x70], xmm7
0000798fc6fd9596  vmovaps [rsp+0x80], xmm8
0000798fc6fd959f  vmovaps [rsp+0x90], xmm9
0000798fc6fd95a8  vmovaps [rsp+0xA0], xmm10
0000798fc6fd95b1  vmovaps [rsp+0xB0], xmm11
0000798fc6fd95ba  vmovaps [rsp+0xC0], xmm12
0000798fc6fd95c3  vmovaps [rsp+0xD0], xmm13
0000798fc6fd95cc  vmovaps [rsp+0xE0], xmm15
0000798fc6fd95d5  sub rsp, 0x30
0000798fc6fd95d9  movaps [rsp], xmm14
0000798fc6fd95de  movaps [rsp+0x10], xmm8
0000798fc6fd95e4  movaps [rsp+0x20], xmm4
0000798fc6fd95e9  lea rdi, [rsp]
0000798fc6fd95ed  mov esi, 0x00
0000798fc6fd95f2  mov rax, 0x63E558B23530
0000798fc6fd95fc  call rax
0000798fc6fd95fe  movaps xmm14, [rsp]
0000798fc6fd9603  add rsp, 0x30
0000798fc6fd9607  vmovaps xmm0, [rsp]
0000798fc6fd960c  vmovaps xmm1, [rsp+0x10]
0000798fc6fd9612  vmovaps xmm2, [rsp+0x20]
0000798fc6fd9618  vmovaps xmm3, [rsp+0x30]
0000798fc6fd961e  vmovaps xmm4, [rsp+0x40]
0000798fc6fd9624  vmovaps xmm5, [rsp+0x50]
0000798fc6fd962a  vmovaps xmm6, [rsp+0x60]
0000798fc6fd9630  vmovaps xmm7, [rsp+0x70]
0000798fc6fd9636  vmovaps xmm8, [rsp+0x80]
0000798fc6fd963f  vmovaps xmm9, [rsp+0x90]
0000798fc6fd9648  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd9651  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd965a  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd9663  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd966c  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd9675  add rsp, 0xF0
0000798fc6fd967c  pop r11
0000798fc6fd967e  pop r10
0000798fc6fd9680  pop r9
0000798fc6fd9682  pop r8
0000798fc6fd9684  pop rsi
0000798fc6fd9685  pop rdi
0000798fc6fd9686  pop rdx
0000798fc6fd9687  pop rcx
0000798fc6fd9688  pop rax
0000798fc6fd9689  add rsp, 0x08
0000798fc6fd968d  jmp 0x0000798FC6FD6265
0000798fc6fd9692  sub rsp, 0x08
0000798fc6fd9696  push rax
0000798fc6fd9697  push rcx
0000798fc6fd9698  push rdx
0000798fc6fd9699  push rdi
0000798fc6fd969a  push rsi
0000798fc6fd969b  push r8
0000798fc6fd969d  push r9
0000798fc6fd969f  push r10
0000798fc6fd96a1  push r11
0000798fc6fd96a3  sub rsp, 0xF0
0000798fc6fd96aa  vmovaps [rsp], xmm0
0000798fc6fd96af  vmovaps [rsp+0x10], xmm1
0000798fc6fd96b5  vmovaps [rsp+0x20], xmm2
0000798fc6fd96bb  vmovaps [rsp+0x30], xmm3
0000798fc6fd96c1  vmovaps [rsp+0x40], xmm5
0000798fc6fd96c7  vmovaps [rsp+0x50], xmm6
0000798fc6fd96cd  vmovaps [rsp+0x60], xmm7
0000798fc6fd96d3  vmovaps [rsp+0x70], xmm8
0000798fc6fd96d9  vmovaps [rsp+0x80], xmm9
0000798fc6fd96e2  vmovaps [rsp+0x90], xmm10
0000798fc6fd96eb  vmovaps [rsp+0xA0], xmm11
0000798fc6fd96f4  vmovaps [rsp+0xB0], xmm12
0000798fc6fd96fd  vmovaps [rsp+0xC0], xmm13
0000798fc6fd9706  vmovaps [rsp+0xD0], xmm14
0000798fc6fd970f  vmovaps [rsp+0xE0], xmm15
0000798fc6fd9718  sub rsp, 0x30
0000798fc6fd971c  movaps [rsp], xmm4
0000798fc6fd9720  movaps [rsp+0x10], xmm13
0000798fc6fd9726  movaps [rsp+0x20], xmm8
0000798fc6fd972c  lea rdi, [rsp]
0000798fc6fd9730  mov esi, 0x00
0000798fc6fd9735  mov rax, 0x63E558B23530
0000798fc6fd973f  call rax
0000798fc6fd9741  movaps xmm4, [rsp]
0000798fc6fd9745  add rsp, 0x30
0000798fc6fd9749  vmovaps xmm0, [rsp]
0000798fc6fd974e  vmovaps xmm1, [rsp+0x10]
0000798fc6fd9754  vmovaps xmm2, [rsp+0x20]
0000798fc6fd975a  vmovaps xmm3, [rsp+0x30]
0000798fc6fd9760  vmovaps xmm5, [rsp+0x40]
0000798fc6fd9766  vmovaps xmm6, [rsp+0x50]
0000798fc6fd976c  vmovaps xmm7, [rsp+0x60]
0000798fc6fd9772  vmovaps xmm8, [rsp+0x70]
0000798fc6fd9778  vmovaps xmm9, [rsp+0x80]
0000798fc6fd9781  vmovaps xmm10, [rsp+0x90]
0000798fc6fd978a  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd9793  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd979c  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd97a5  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd97ae  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd97b7  add rsp, 0xF0
0000798fc6fd97be  pop r11
0000798fc6fd97c0  pop r10
0000798fc6fd97c2  pop r9
0000798fc6fd97c4  pop r8
0000798fc6fd97c6  pop rsi
0000798fc6fd97c7  pop rdi
0000798fc6fd97c8  pop rdx
0000798fc6fd97c9  pop rcx
0000798fc6fd97ca  pop rax
0000798fc6fd97cb  add rsp, 0x08
0000798fc6fd97cf  jmp 0x0000798FC6FD628A
0000798fc6fd97d4  sub rsp, 0x08
0000798fc6fd97d8  push rax
0000798fc6fd97d9  push rcx
0000798fc6fd97da  push rdx
0000798fc6fd97db  push rdi
0000798fc6fd97dc  push rsi
0000798fc6fd97dd  push r8
0000798fc6fd97df  push r9
0000798fc6fd97e1  push r10
0000798fc6fd97e3  push r11
0000798fc6fd97e5  sub rsp, 0xF0
0000798fc6fd97ec  vmovaps [rsp], xmm0
0000798fc6fd97f1  vmovaps [rsp+0x10], xmm1
0000798fc6fd97f7  vmovaps [rsp+0x20], xmm2
0000798fc6fd97fd  vmovaps [rsp+0x30], xmm3
0000798fc6fd9803  vmovaps [rsp+0x40], xmm4
0000798fc6fd9809  vmovaps [rsp+0x50], xmm5
0000798fc6fd980f  vmovaps [rsp+0x60], xmm6
0000798fc6fd9815  vmovaps [rsp+0x70], xmm7
0000798fc6fd981b  vmovaps [rsp+0x80], xmm8
0000798fc6fd9824  vmovaps [rsp+0x90], xmm9
0000798fc6fd982d  vmovaps [rsp+0xA0], xmm10
0000798fc6fd9836  vmovaps [rsp+0xB0], xmm11
0000798fc6fd983f  vmovaps [rsp+0xC0], xmm12
0000798fc6fd9848  vmovaps [rsp+0xD0], xmm14
0000798fc6fd9851  vmovaps [rsp+0xE0], xmm15
0000798fc6fd985a  sub rsp, 0x30
0000798fc6fd985e  movaps [rsp], xmm13
0000798fc6fd9863  movaps [rsp+0x10], xmm15
0000798fc6fd9869  movaps [rsp+0x20], xmm9
0000798fc6fd986f  lea rdi, [rsp]
0000798fc6fd9873  mov esi, 0x00
0000798fc6fd9878  mov rax, 0x63E558B23530
0000798fc6fd9882  call rax
0000798fc6fd9884  movaps xmm13, [rsp]
0000798fc6fd9889  add rsp, 0x30
0000798fc6fd988d  vmovaps xmm0, [rsp]
0000798fc6fd9892  vmovaps xmm1, [rsp+0x10]
0000798fc6fd9898  vmovaps xmm2, [rsp+0x20]
0000798fc6fd989e  vmovaps xmm3, [rsp+0x30]
0000798fc6fd98a4  vmovaps xmm4, [rsp+0x40]
0000798fc6fd98aa  vmovaps xmm5, [rsp+0x50]
0000798fc6fd98b0  vmovaps xmm6, [rsp+0x60]
0000798fc6fd98b6  vmovaps xmm7, [rsp+0x70]
0000798fc6fd98bc  vmovaps xmm8, [rsp+0x80]
0000798fc6fd98c5  vmovaps xmm9, [rsp+0x90]
0000798fc6fd98ce  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd98d7  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd98e0  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd98e9  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd98f2  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd98fb  add rsp, 0xF0
0000798fc6fd9902  pop r11
0000798fc6fd9904  pop r10
0000798fc6fd9906  pop r9
0000798fc6fd9908  pop r8
0000798fc6fd990a  pop rsi
0000798fc6fd990b  pop rdi
0000798fc6fd990c  pop rdx
0000798fc6fd990d  pop rcx
0000798fc6fd990e  pop rax
0000798fc6fd990f  add rsp, 0x08
0000798fc6fd9913  jmp 0x0000798FC6FD62A5
0000798fc6fd9918  sub rsp, 0x08
0000798fc6fd991c  push rax
0000798fc6fd991d  push rcx
0000798fc6fd991e  push rdx
0000798fc6fd991f  push rdi
0000798fc6fd9920  push rsi
0000798fc6fd9921  push r8
0000798fc6fd9923  push r9
0000798fc6fd9925  push r10
0000798fc6fd9927  push r11
0000798fc6fd9929  sub rsp, 0xF0
0000798fc6fd9930  vmovaps [rsp], xmm0
0000798fc6fd9935  vmovaps [rsp+0x10], xmm1
0000798fc6fd993b  vmovaps [rsp+0x20], xmm2
0000798fc6fd9941  vmovaps [rsp+0x30], xmm3
0000798fc6fd9947  vmovaps [rsp+0x40], xmm4
0000798fc6fd994d  vmovaps [rsp+0x50], xmm5
0000798fc6fd9953  vmovaps [rsp+0x60], xmm6
0000798fc6fd9959  vmovaps [rsp+0x70], xmm7
0000798fc6fd995f  vmovaps [rsp+0x80], xmm8
0000798fc6fd9968  vmovaps [rsp+0x90], xmm9
0000798fc6fd9971  vmovaps [rsp+0xA0], xmm10
0000798fc6fd997a  vmovaps [rsp+0xB0], xmm11
0000798fc6fd9983  vmovaps [rsp+0xC0], xmm12
0000798fc6fd998c  vmovaps [rsp+0xD0], xmm13
0000798fc6fd9995  vmovaps [rsp+0xE0], xmm14
0000798fc6fd999e  sub rsp, 0x30
0000798fc6fd99a2  movaps [rsp], xmm15
0000798fc6fd99a7  movaps [rsp+0x10], xmm1
0000798fc6fd99ac  movaps [rsp+0x20], xmm5
0000798fc6fd99b1  lea rdi, [rsp]
0000798fc6fd99b5  mov esi, 0x00
0000798fc6fd99ba  mov rax, 0x63E558B23530
0000798fc6fd99c4  call rax
0000798fc6fd99c6  movaps xmm15, [rsp]
0000798fc6fd99cb  add rsp, 0x30
0000798fc6fd99cf  vmovaps xmm0, [rsp]
0000798fc6fd99d4  vmovaps xmm1, [rsp+0x10]
0000798fc6fd99da  vmovaps xmm2, [rsp+0x20]
0000798fc6fd99e0  vmovaps xmm3, [rsp+0x30]
0000798fc6fd99e6  vmovaps xmm4, [rsp+0x40]
0000798fc6fd99ec  vmovaps xmm5, [rsp+0x50]
0000798fc6fd99f2  vmovaps xmm6, [rsp+0x60]
0000798fc6fd99f8  vmovaps xmm7, [rsp+0x70]
0000798fc6fd99fe  vmovaps xmm8, [rsp+0x80]
0000798fc6fd9a07  vmovaps xmm9, [rsp+0x90]
0000798fc6fd9a10  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd9a19  vmovaps xmm11, [rsp+0xB0]
0000798fc6fd9a22  vmovaps xmm12, [rsp+0xC0]
0000798fc6fd9a2b  vmovaps xmm13, [rsp+0xD0]
0000798fc6fd9a34  vmovaps xmm14, [rsp+0xE0]
0000798fc6fd9a3d  add rsp, 0xF0
0000798fc6fd9a44  pop r11
0000798fc6fd9a46  pop r10
0000798fc6fd9a48  pop r9
0000798fc6fd9a4a  pop r8
0000798fc6fd9a4c  pop rsi
0000798fc6fd9a4d  pop rdi
0000798fc6fd9a4e  pop rdx
0000798fc6fd9a4f  pop rcx
0000798fc6fd9a50  pop rax
0000798fc6fd9a51  add rsp, 0x08
0000798fc6fd9a55  jmp 0x0000798FC6FD62C0
0000798fc6fd9a5a  call 0x0000798FC6ED64F0
0000798fc6fd9a5f  jmp 0x0000798FC6FD631B
0000798fc6fd9a64  sub rsp, 0x08
0000798fc6fd9a68  push rax
0000798fc6fd9a69  push rcx
0000798fc6fd9a6a  push rdx
0000798fc6fd9a6b  push rdi
0000798fc6fd9a6c  push rsi
0000798fc6fd9a6d  push r8
0000798fc6fd9a6f  push r9
0000798fc6fd9a71  push r10
0000798fc6fd9a73  push r11
0000798fc6fd9a75  sub rsp, 0xF0
0000798fc6fd9a7c  vmovaps [rsp], xmm0
0000798fc6fd9a81  vmovaps [rsp+0x10], xmm1
0000798fc6fd9a87  vmovaps [rsp+0x20], xmm2
0000798fc6fd9a8d  vmovaps [rsp+0x30], xmm3
0000798fc6fd9a93  vmovaps [rsp+0x40], xmm4
0000798fc6fd9a99  vmovaps [rsp+0x50], xmm5
0000798fc6fd9a9f  vmovaps [rsp+0x60], xmm6
0000798fc6fd9aa5  vmovaps [rsp+0x70], xmm7
0000798fc6fd9aab  vmovaps [rsp+0x80], xmm8
0000798fc6fd9ab4  vmovaps [rsp+0x90], xmm10
0000798fc6fd9abd  vmovaps [rsp+0xA0], xmm11
0000798fc6fd9ac6  vmovaps [rsp+0xB0], xmm12
0000798fc6fd9acf  vmovaps [rsp+0xC0], xmm13
0000798fc6fd9ad8  vmovaps [rsp+0xD0], xmm14
0000798fc6fd9ae1  vmovaps [rsp+0xE0], xmm15
0000798fc6fd9aea  sub rsp, 0x30
0000798fc6fd9aee  movaps [rsp], xmm9
0000798fc6fd9af3  movaps [rsp+0x10], xmm8
0000798fc6fd9af9  movaps [rsp+0x20], xmm11
0000798fc6fd9aff  lea rdi, [rsp]
0000798fc6fd9b03  mov esi, 0x00
0000798fc6fd9b08  mov rax, 0x63E558B23530
0000798fc6fd9b12  call rax
0000798fc6fd9b14  movaps xmm9, [rsp]
0000798fc6fd9b19  add rsp, 0x30
0000798fc6fd9b1d  vmovaps xmm0, [rsp]
0000798fc6fd9b22  vmovaps xmm1, [rsp+0x10]
0000798fc6fd9b28  vmovaps xmm2, [rsp+0x20]
0000798fc6fd9b2e  vmovaps xmm3, [rsp+0x30]
0000798fc6fd9b34  vmovaps xmm4, [rsp+0x40]
0000798fc6fd9b3a  vmovaps xmm5, [rsp+0x50]
0000798fc6fd9b40  vmovaps xmm6, [rsp+0x60]
0000798fc6fd9b46  vmovaps xmm7, [rsp+0x70]
0000798fc6fd9b4c  vmovaps xmm8, [rsp+0x80]
0000798fc6fd9b55  vmovaps xmm10, [rsp+0x90]
0000798fc6fd9b5e  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd9b67  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd9b70  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd9b79  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd9b82  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd9b8b  add rsp, 0xF0
0000798fc6fd9b92  pop r11
0000798fc6fd9b94  pop r10
0000798fc6fd9b96  pop r9
0000798fc6fd9b98  pop r8
0000798fc6fd9b9a  pop rsi
0000798fc6fd9b9b  pop rdi
0000798fc6fd9b9c  pop rdx
0000798fc6fd9b9d  pop rcx
0000798fc6fd9b9e  pop rax
0000798fc6fd9b9f  add rsp, 0x08
0000798fc6fd9ba3  jmp 0x0000798FC6FD6352
0000798fc6fd9ba8  sub rsp, 0x08
0000798fc6fd9bac  push rax
0000798fc6fd9bad  push rcx
0000798fc6fd9bae  push rdx
0000798fc6fd9baf  push rdi
0000798fc6fd9bb0  push rsi
0000798fc6fd9bb1  push r8
0000798fc6fd9bb3  push r9
0000798fc6fd9bb5  push r10
0000798fc6fd9bb7  push r11
0000798fc6fd9bb9  sub rsp, 0xF0
0000798fc6fd9bc0  vmovaps [rsp], xmm0
0000798fc6fd9bc5  vmovaps [rsp+0x10], xmm1
0000798fc6fd9bcb  vmovaps [rsp+0x20], xmm2
0000798fc6fd9bd1  vmovaps [rsp+0x30], xmm3
0000798fc6fd9bd7  vmovaps [rsp+0x40], xmm4
0000798fc6fd9bdd  vmovaps [rsp+0x50], xmm5
0000798fc6fd9be3  vmovaps [rsp+0x60], xmm6
0000798fc6fd9be9  vmovaps [rsp+0x70], xmm7
0000798fc6fd9bef  vmovaps [rsp+0x80], xmm8
0000798fc6fd9bf8  vmovaps [rsp+0x90], xmm9
0000798fc6fd9c01  vmovaps [rsp+0xA0], xmm10
0000798fc6fd9c0a  vmovaps [rsp+0xB0], xmm12
0000798fc6fd9c13  vmovaps [rsp+0xC0], xmm13
0000798fc6fd9c1c  vmovaps [rsp+0xD0], xmm14
0000798fc6fd9c25  vmovaps [rsp+0xE0], xmm15
0000798fc6fd9c2e  sub rsp, 0x30
0000798fc6fd9c32  movaps [rsp], xmm11
0000798fc6fd9c37  movaps [rsp+0x10], xmm10
0000798fc6fd9c3d  movaps [rsp+0x20], xmm6
0000798fc6fd9c42  lea rdi, [rsp]
0000798fc6fd9c46  mov esi, 0x00
0000798fc6fd9c4b  mov rax, 0x63E558B23530
0000798fc6fd9c55  call rax
0000798fc6fd9c57  movaps xmm11, [rsp]
0000798fc6fd9c5c  add rsp, 0x30
0000798fc6fd9c60  vmovaps xmm0, [rsp]
0000798fc6fd9c65  vmovaps xmm1, [rsp+0x10]
0000798fc6fd9c6b  vmovaps xmm2, [rsp+0x20]
0000798fc6fd9c71  vmovaps xmm3, [rsp+0x30]
0000798fc6fd9c77  vmovaps xmm4, [rsp+0x40]
0000798fc6fd9c7d  vmovaps xmm5, [rsp+0x50]
0000798fc6fd9c83  vmovaps xmm6, [rsp+0x60]
0000798fc6fd9c89  vmovaps xmm7, [rsp+0x70]
0000798fc6fd9c8f  vmovaps xmm8, [rsp+0x80]
0000798fc6fd9c98  vmovaps xmm9, [rsp+0x90]
0000798fc6fd9ca1  vmovaps xmm10, [rsp+0xA0]
0000798fc6fd9caa  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd9cb3  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd9cbc  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd9cc5  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd9cce  add rsp, 0xF0
0000798fc6fd9cd5  pop r11
0000798fc6fd9cd7  pop r10
0000798fc6fd9cd9  pop r9
0000798fc6fd9cdb  pop r8
0000798fc6fd9cdd  pop rsi
0000798fc6fd9cde  pop rdi
0000798fc6fd9cdf  pop rdx
0000798fc6fd9ce0  pop rcx
0000798fc6fd9ce1  pop rax
0000798fc6fd9ce2  add rsp, 0x08
0000798fc6fd9ce6  jmp 0x0000798FC6FD636D
0000798fc6fd9ceb  sub rsp, 0x08
0000798fc6fd9cef  push rax
0000798fc6fd9cf0  push rcx
0000798fc6fd9cf1  push rdx
0000798fc6fd9cf2  push rdi
0000798fc6fd9cf3  push rsi
0000798fc6fd9cf4  push r8
0000798fc6fd9cf6  push r9
0000798fc6fd9cf8  push r10
0000798fc6fd9cfa  push r11
0000798fc6fd9cfc  sub rsp, 0xF0
0000798fc6fd9d03  vmovaps [rsp], xmm0
0000798fc6fd9d08  vmovaps [rsp+0x10], xmm1
0000798fc6fd9d0e  vmovaps [rsp+0x20], xmm2
0000798fc6fd9d14  vmovaps [rsp+0x30], xmm3
0000798fc6fd9d1a  vmovaps [rsp+0x40], xmm4
0000798fc6fd9d20  vmovaps [rsp+0x50], xmm5
0000798fc6fd9d26  vmovaps [rsp+0x60], xmm6
0000798fc6fd9d2c  vmovaps [rsp+0x70], xmm7
0000798fc6fd9d32  vmovaps [rsp+0x80], xmm8
0000798fc6fd9d3b  vmovaps [rsp+0x90], xmm9
0000798fc6fd9d44  vmovaps [rsp+0xA0], xmm11
0000798fc6fd9d4d  vmovaps [rsp+0xB0], xmm12
0000798fc6fd9d56  vmovaps [rsp+0xC0], xmm13
0000798fc6fd9d5f  vmovaps [rsp+0xD0], xmm14
0000798fc6fd9d68  vmovaps [rsp+0xE0], xmm15
0000798fc6fd9d71  sub rsp, 0x30
0000798fc6fd9d75  movaps [rsp], xmm10
0000798fc6fd9d7a  movaps [rsp+0x10], xmm14
0000798fc6fd9d80  movaps [rsp+0x20], xmm4
0000798fc6fd9d85  lea rdi, [rsp]
0000798fc6fd9d89  mov esi, 0x00
0000798fc6fd9d8e  mov rax, 0x63E558B23530
0000798fc6fd9d98  call rax
0000798fc6fd9d9a  movaps xmm10, [rsp]
0000798fc6fd9d9f  add rsp, 0x30
0000798fc6fd9da3  vmovaps xmm0, [rsp]
0000798fc6fd9da8  vmovaps xmm1, [rsp+0x10]
0000798fc6fd9dae  vmovaps xmm2, [rsp+0x20]
0000798fc6fd9db4  vmovaps xmm3, [rsp+0x30]
0000798fc6fd9dba  vmovaps xmm4, [rsp+0x40]
0000798fc6fd9dc0  vmovaps xmm5, [rsp+0x50]
0000798fc6fd9dc6  vmovaps xmm6, [rsp+0x60]
0000798fc6fd9dcc  vmovaps xmm7, [rsp+0x70]
0000798fc6fd9dd2  vmovaps xmm8, [rsp+0x80]
0000798fc6fd9ddb  vmovaps xmm9, [rsp+0x90]
0000798fc6fd9de4  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd9ded  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd9df6  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd9dff  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd9e08  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd9e11  add rsp, 0xF0
0000798fc6fd9e18  pop r11
0000798fc6fd9e1a  pop r10
0000798fc6fd9e1c  pop r9
0000798fc6fd9e1e  pop r8
0000798fc6fd9e20  pop rsi
0000798fc6fd9e21  pop rdi
0000798fc6fd9e22  pop rdx
0000798fc6fd9e23  pop rcx
0000798fc6fd9e24  pop rax
0000798fc6fd9e25  add rsp, 0x08
0000798fc6fd9e29  jmp 0x0000798FC6FD6388
0000798fc6fd9e2e  sub rsp, 0x08
0000798fc6fd9e32  push rax
0000798fc6fd9e33  push rcx
0000798fc6fd9e34  push rdx
0000798fc6fd9e35  push rdi
0000798fc6fd9e36  push rsi
0000798fc6fd9e37  push r8
0000798fc6fd9e39  push r9
0000798fc6fd9e3b  push r10
0000798fc6fd9e3d  push r11
0000798fc6fd9e3f  sub rsp, 0xF0
0000798fc6fd9e46  vmovaps [rsp], xmm0
0000798fc6fd9e4b  vmovaps [rsp+0x10], xmm1
0000798fc6fd9e51  vmovaps [rsp+0x20], xmm2
0000798fc6fd9e57  vmovaps [rsp+0x30], xmm3
0000798fc6fd9e5d  vmovaps [rsp+0x40], xmm4
0000798fc6fd9e63  vmovaps [rsp+0x50], xmm5
0000798fc6fd9e69  vmovaps [rsp+0x60], xmm6
0000798fc6fd9e6f  vmovaps [rsp+0x70], xmm7
0000798fc6fd9e75  vmovaps [rsp+0x80], xmm9
0000798fc6fd9e7e  vmovaps [rsp+0x90], xmm10
0000798fc6fd9e87  vmovaps [rsp+0xA0], xmm11
0000798fc6fd9e90  vmovaps [rsp+0xB0], xmm12
0000798fc6fd9e99  vmovaps [rsp+0xC0], xmm13
0000798fc6fd9ea2  vmovaps [rsp+0xD0], xmm14
0000798fc6fd9eab  vmovaps [rsp+0xE0], xmm15
0000798fc6fd9eb4  sub rsp, 0x30
0000798fc6fd9eb8  movaps [rsp], xmm8
0000798fc6fd9ebd  movaps [rsp+0x10], xmm1
0000798fc6fd9ec2  movaps [rsp+0x20], xmm14
0000798fc6fd9ec8  lea rdi, [rsp]
0000798fc6fd9ecc  mov esi, 0x00
0000798fc6fd9ed1  mov rax, 0x63E558B23530
0000798fc6fd9edb  call rax
0000798fc6fd9edd  movaps xmm8, [rsp]
0000798fc6fd9ee2  add rsp, 0x30
0000798fc6fd9ee6  vmovaps xmm0, [rsp]
0000798fc6fd9eeb  vmovaps xmm1, [rsp+0x10]
0000798fc6fd9ef1  vmovaps xmm2, [rsp+0x20]
0000798fc6fd9ef7  vmovaps xmm3, [rsp+0x30]
0000798fc6fd9efd  vmovaps xmm4, [rsp+0x40]
0000798fc6fd9f03  vmovaps xmm5, [rsp+0x50]
0000798fc6fd9f09  vmovaps xmm6, [rsp+0x60]
0000798fc6fd9f0f  vmovaps xmm7, [rsp+0x70]
0000798fc6fd9f15  vmovaps xmm9, [rsp+0x80]
0000798fc6fd9f1e  vmovaps xmm10, [rsp+0x90]
0000798fc6fd9f27  vmovaps xmm11, [rsp+0xA0]
0000798fc6fd9f30  vmovaps xmm12, [rsp+0xB0]
0000798fc6fd9f39  vmovaps xmm13, [rsp+0xC0]
0000798fc6fd9f42  vmovaps xmm14, [rsp+0xD0]
0000798fc6fd9f4b  vmovaps xmm15, [rsp+0xE0]
0000798fc6fd9f54  add rsp, 0xF0
0000798fc6fd9f5b  pop r11
0000798fc6fd9f5d  pop r10
0000798fc6fd9f5f  pop r9
0000798fc6fd9f61  pop r8
0000798fc6fd9f63  pop rsi
0000798fc6fd9f64  pop rdi
0000798fc6fd9f65  pop rdx
0000798fc6fd9f66  pop rcx
0000798fc6fd9f67  pop rax
0000798fc6fd9f68  add rsp, 0x08
0000798fc6fd9f6c  jmp 0x0000798FC6FD63AE
0000798fc6fd9f71  sub rsp, 0x08
0000798fc6fd9f75  push rax
0000798fc6fd9f76  push rcx
0000798fc6fd9f77  push rdx
0000798fc6fd9f78  push rdi
0000798fc6fd9f79  push rsi
0000798fc6fd9f7a  push r8
0000798fc6fd9f7c  push r9
0000798fc6fd9f7e  push r10
0000798fc6fd9f80  push r11
0000798fc6fd9f82  sub rsp, 0xF0
0000798fc6fd9f89  vmovaps [rsp], xmm0
0000798fc6fd9f8e  vmovaps [rsp+0x10], xmm1
0000798fc6fd9f94  vmovaps [rsp+0x20], xmm2
0000798fc6fd9f9a  vmovaps [rsp+0x30], xmm3
0000798fc6fd9fa0  vmovaps [rsp+0x40], xmm4
0000798fc6fd9fa6  vmovaps [rsp+0x50], xmm5
0000798fc6fd9fac  vmovaps [rsp+0x60], xmm7
0000798fc6fd9fb2  vmovaps [rsp+0x70], xmm8
0000798fc6fd9fb8  vmovaps [rsp+0x80], xmm9
0000798fc6fd9fc1  vmovaps [rsp+0x90], xmm10
0000798fc6fd9fca  vmovaps [rsp+0xA0], xmm11
0000798fc6fd9fd3  vmovaps [rsp+0xB0], xmm12
0000798fc6fd9fdc  vmovaps [rsp+0xC0], xmm13
0000798fc6fd9fe5  vmovaps [rsp+0xD0], xmm14
0000798fc6fd9fee  vmovaps [rsp+0xE0], xmm15
0000798fc6fd9ff7  sub rsp, 0x30
0000798fc6fd9ffb  movaps [rsp], xmm6
0000798fc6fd9fff  movaps [rsp+0x10], xmm1
0000798fc6fda004  movaps [rsp+0x20], xmm14
0000798fc6fda00a  lea rdi, [rsp]
0000798fc6fda00e  mov esi, 0x00
0000798fc6fda013  mov rax, 0x63E558B23530
0000798fc6fda01d  call rax
0000798fc6fda01f  movaps xmm6, [rsp]
0000798fc6fda023  add rsp, 0x30
0000798fc6fda027  vmovaps xmm0, [rsp]
0000798fc6fda02c  vmovaps xmm1, [rsp+0x10]
0000798fc6fda032  vmovaps xmm2, [rsp+0x20]
0000798fc6fda038  vmovaps xmm3, [rsp+0x30]
0000798fc6fda03e  vmovaps xmm4, [rsp+0x40]
0000798fc6fda044  vmovaps xmm5, [rsp+0x50]
0000798fc6fda04a  vmovaps xmm7, [rsp+0x60]
0000798fc6fda050  vmovaps xmm8, [rsp+0x70]
0000798fc6fda056  vmovaps xmm9, [rsp+0x80]
0000798fc6fda05f  vmovaps xmm10, [rsp+0x90]
0000798fc6fda068  vmovaps xmm11, [rsp+0xA0]
0000798fc6fda071  vmovaps xmm12, [rsp+0xB0]
0000798fc6fda07a  vmovaps xmm13, [rsp+0xC0]
0000798fc6fda083  vmovaps xmm14, [rsp+0xD0]
0000798fc6fda08c  vmovaps xmm15, [rsp+0xE0]
0000798fc6fda095  add rsp, 0xF0
0000798fc6fda09c  pop r11
0000798fc6fda09e  pop r10
0000798fc6fda0a0  pop r9
0000798fc6fda0a2  pop r8
0000798fc6fda0a4  pop rsi
0000798fc6fda0a5  pop rdi
0000798fc6fda0a6  pop rdx
0000798fc6fda0a7  pop rcx
0000798fc6fda0a8  pop rax
0000798fc6fda0a9  add rsp, 0x08
0000798fc6fda0ad  jmp 0x0000798FC6FD63DA
0000798fc6fda0b2  sub rsp, 0x08
0000798fc6fda0b6  push rax
0000798fc6fda0b7  push rcx
0000798fc6fda0b8  push rdx
0000798fc6fda0b9  push rdi
0000798fc6fda0ba  push rsi
0000798fc6fda0bb  push r8
0000798fc6fda0bd  push r9
0000798fc6fda0bf  push r10
0000798fc6fda0c1  push r11
0000798fc6fda0c3  sub rsp, 0xF0
0000798fc6fda0ca  vmovaps [rsp], xmm0
0000798fc6fda0cf  vmovaps [rsp+0x10], xmm1
0000798fc6fda0d5  vmovaps [rsp+0x20], xmm2
0000798fc6fda0db  vmovaps [rsp+0x30], xmm3
0000798fc6fda0e1  vmovaps [rsp+0x40], xmm4
0000798fc6fda0e7  vmovaps [rsp+0x50], xmm5
0000798fc6fda0ed  vmovaps [rsp+0x60], xmm6
0000798fc6fda0f3  vmovaps [rsp+0x70], xmm7
0000798fc6fda0f9  vmovaps [rsp+0x80], xmm8
0000798fc6fda102  vmovaps [rsp+0x90], xmm9
0000798fc6fda10b  vmovaps [rsp+0xA0], xmm10
0000798fc6fda114  vmovaps [rsp+0xB0], xmm11
0000798fc6fda11d  vmovaps [rsp+0xC0], xmm12
0000798fc6fda126  vmovaps [rsp+0xD0], xmm13
0000798fc6fda12f  vmovaps [rsp+0xE0], xmm15
0000798fc6fda138  sub rsp, 0x30
0000798fc6fda13c  movaps [rsp], xmm14
0000798fc6fda141  movaps [rsp+0x10], xmm12
0000798fc6fda147  movaps [rsp+0x20], xmm1
0000798fc6fda14c  lea rdi, [rsp]
0000798fc6fda150  mov esi, 0x00
0000798fc6fda155  mov rax, 0x63E558B23530
0000798fc6fda15f  call rax
0000798fc6fda161  movaps xmm14, [rsp]
0000798fc6fda166  add rsp, 0x30
0000798fc6fda16a  vmovaps xmm0, [rsp]
0000798fc6fda16f  vmovaps xmm1, [rsp+0x10]
0000798fc6fda175  vmovaps xmm2, [rsp+0x20]
0000798fc6fda17b  vmovaps xmm3, [rsp+0x30]
0000798fc6fda181  vmovaps xmm4, [rsp+0x40]
0000798fc6fda187  vmovaps xmm5, [rsp+0x50]
0000798fc6fda18d  vmovaps xmm6, [rsp+0x60]
0000798fc6fda193  vmovaps xmm7, [rsp+0x70]
0000798fc6fda199  vmovaps xmm8, [rsp+0x80]
0000798fc6fda1a2  vmovaps xmm9, [rsp+0x90]
0000798fc6fda1ab  vmovaps xmm10, [rsp+0xA0]
0000798fc6fda1b4  vmovaps xmm11, [rsp+0xB0]
0000798fc6fda1bd  vmovaps xmm12, [rsp+0xC0]
0000798fc6fda1c6  vmovaps xmm13, [rsp+0xD0]
0000798fc6fda1cf  vmovaps xmm15, [rsp+0xE0]
0000798fc6fda1d8  add rsp, 0xF0
0000798fc6fda1df  pop r11
0000798fc6fda1e1  pop r10
0000798fc6fda1e3  pop r9
0000798fc6fda1e5  pop r8
0000798fc6fda1e7  pop rsi
0000798fc6fda1e8  pop rdi
0000798fc6fda1e9  pop rdx
0000798fc6fda1ea  pop rcx
0000798fc6fda1eb  pop rax
0000798fc6fda1ec  add rsp, 0x08
0000798fc6fda1f0  jmp 0x0000798FC6FD6400
0000798fc6fda1f5  sub rsp, 0x08
0000798fc6fda1f9  push rax
0000798fc6fda1fa  push rcx
0000798fc6fda1fb  push rdx
0000798fc6fda1fc  push rdi
0000798fc6fda1fd  push rsi
0000798fc6fda1fe  push r8
0000798fc6fda200  push r9
0000798fc6fda202  push r10
0000798fc6fda204  push r11
0000798fc6fda206  sub rsp, 0xF0
0000798fc6fda20d  vmovaps [rsp], xmm0
0000798fc6fda212  vmovaps [rsp+0x10], xmm2
0000798fc6fda218  vmovaps [rsp+0x20], xmm3
0000798fc6fda21e  vmovaps [rsp+0x30], xmm4
0000798fc6fda224  vmovaps [rsp+0x40], xmm5
0000798fc6fda22a  vmovaps [rsp+0x50], xmm6
0000798fc6fda230  vmovaps [rsp+0x60], xmm7
0000798fc6fda236  vmovaps [rsp+0x70], xmm8
0000798fc6fda23c  vmovaps [rsp+0x80], xmm9
0000798fc6fda245  vmovaps [rsp+0x90], xmm10
0000798fc6fda24e  vmovaps [rsp+0xA0], xmm11
0000798fc6fda257  vmovaps [rsp+0xB0], xmm12
0000798fc6fda260  vmovaps [rsp+0xC0], xmm13
0000798fc6fda269  vmovaps [rsp+0xD0], xmm14
0000798fc6fda272  vmovaps [rsp+0xE0], xmm15
0000798fc6fda27b  sub rsp, 0x30
0000798fc6fda27f  movaps [rsp], xmm1
0000798fc6fda283  movaps [rsp+0x10], xmm13
0000798fc6fda289  movaps [rsp+0x20], xmm9
0000798fc6fda28f  lea rdi, [rsp]
0000798fc6fda293  mov esi, 0x00
0000798fc6fda298  mov rax, 0x63E558B23530
0000798fc6fda2a2  call rax
0000798fc6fda2a4  movaps xmm1, [rsp]
0000798fc6fda2a8  add rsp, 0x30
0000798fc6fda2ac  vmovaps xmm0, [rsp]
0000798fc6fda2b1  vmovaps xmm2, [rsp+0x10]
0000798fc6fda2b7  vmovaps xmm3, [rsp+0x20]
0000798fc6fda2bd  vmovaps xmm4, [rsp+0x30]
0000798fc6fda2c3  vmovaps xmm5, [rsp+0x40]
0000798fc6fda2c9  vmovaps xmm6, [rsp+0x50]
0000798fc6fda2cf  vmovaps xmm7, [rsp+0x60]
0000798fc6fda2d5  vmovaps xmm8, [rsp+0x70]
0000798fc6fda2db  vmovaps xmm9, [rsp+0x80]
0000798fc6fda2e4  vmovaps xmm10, [rsp+0x90]
0000798fc6fda2ed  vmovaps xmm11, [rsp+0xA0]
0000798fc6fda2f6  vmovaps xmm12, [rsp+0xB0]
0000798fc6fda2ff  vmovaps xmm13, [rsp+0xC0]
0000798fc6fda308  vmovaps xmm14, [rsp+0xD0]
0000798fc6fda311  vmovaps xmm15, [rsp+0xE0]
0000798fc6fda31a  add rsp, 0xF0
0000798fc6fda321  pop r11
0000798fc6fda323  pop r10
0000798fc6fda325  pop r9
0000798fc6fda327  pop r8
0000798fc6fda329  pop rsi
0000798fc6fda32a  pop rdi
0000798fc6fda32b  pop rdx
0000798fc6fda32c  pop rcx
0000798fc6fda32d  pop rax
0000798fc6fda32e  add rsp, 0x08
0000798fc6fda332  jmp 0x0000798FC6FD641A
0000798fc6fda337  sub rsp, 0x08
0000798fc6fda33b  push rax
0000798fc6fda33c  push rcx
0000798fc6fda33d  push rdx
0000798fc6fda33e  push rdi
0000798fc6fda33f  push rsi
0000798fc6fda340  push r8
0000798fc6fda342  push r9
0000798fc6fda344  push r10
0000798fc6fda346  push r11
0000798fc6fda348  sub rsp, 0xF0
0000798fc6fda34f  vmovaps [rsp], xmm0
0000798fc6fda354  vmovaps [rsp+0x10], xmm1
0000798fc6fda35a  vmovaps [rsp+0x20], xmm2
0000798fc6fda360  vmovaps [rsp+0x30], xmm3
0000798fc6fda366  vmovaps [rsp+0x40], xmm4
0000798fc6fda36c  vmovaps [rsp+0x50], xmm5
0000798fc6fda372  vmovaps [rsp+0x60], xmm6
0000798fc6fda378  vmovaps [rsp+0x70], xmm7
0000798fc6fda37e  vmovaps [rsp+0x80], xmm8
0000798fc6fda387  vmovaps [rsp+0x90], xmm9
0000798fc6fda390  vmovaps [rsp+0xA0], xmm10
0000798fc6fda399  vmovaps [rsp+0xB0], xmm11
0000798fc6fda3a2  vmovaps [rsp+0xC0], xmm13
0000798fc6fda3ab  vmovaps [rsp+0xD0], xmm14
0000798fc6fda3b4  vmovaps [rsp+0xE0], xmm15
0000798fc6fda3bd  sub rsp, 0x30
0000798fc6fda3c1  movaps [rsp], xmm12
0000798fc6fda3c6  movaps [rsp+0x10], xmm7
0000798fc6fda3cb  movaps [rsp+0x20], xmm13
0000798fc6fda3d1  lea rdi, [rsp]
0000798fc6fda3d5  mov esi, 0x00
0000798fc6fda3da  mov rax, 0x63E558B23530
0000798fc6fda3e4  call rax
0000798fc6fda3e6  movaps xmm12, [rsp]
0000798fc6fda3eb  add rsp, 0x30
0000798fc6fda3ef  vmovaps xmm0, [rsp]
0000798fc6fda3f4  vmovaps xmm1, [rsp+0x10]
0000798fc6fda3fa  vmovaps xmm2, [rsp+0x20]
0000798fc6fda400  vmovaps xmm3, [rsp+0x30]
0000798fc6fda406  vmovaps xmm4, [rsp+0x40]
0000798fc6fda40c  vmovaps xmm5, [rsp+0x50]
0000798fc6fda412  vmovaps xmm6, [rsp+0x60]
0000798fc6fda418  vmovaps xmm7, [rsp+0x70]
0000798fc6fda41e  vmovaps xmm8, [rsp+0x80]
0000798fc6fda427  vmovaps xmm9, [rsp+0x90]
0000798fc6fda430  vmovaps xmm10, [rsp+0xA0]
0000798fc6fda439  vmovaps xmm11, [rsp+0xB0]
0000798fc6fda442  vmovaps xmm13, [rsp+0xC0]
0000798fc6fda44b  vmovaps xmm14, [rsp+0xD0]
0000798fc6fda454  vmovaps xmm15, [rsp+0xE0]
0000798fc6fda45d  add rsp, 0xF0
0000798fc6fda464  pop r11
0000798fc6fda466  pop r10
0000798fc6fda468  pop r9
0000798fc6fda46a  pop r8
0000798fc6fda46c  pop rsi
0000798fc6fda46d  pop rdi
0000798fc6fda46e  pop rdx
0000798fc6fda46f  pop rcx
0000798fc6fda470  pop rax
0000798fc6fda471  add rsp, 0x08
0000798fc6fda475  jmp 0x0000798FC6FD6441
0000798fc6fda47a  sub rsp, 0x08
0000798fc6fda47e  push rax
0000798fc6fda47f  push rcx
0000798fc6fda480  push rdx
0000798fc6fda481  push rdi
0000798fc6fda482  push rsi
0000798fc6fda483  push r8
0000798fc6fda485  push r9
0000798fc6fda487  push r10
0000798fc6fda489  push r11
0000798fc6fda48b  sub rsp, 0xF0
0000798fc6fda492  vmovaps [rsp], xmm0
0000798fc6fda497  vmovaps [rsp+0x10], xmm1
0000798fc6fda49d  vmovaps [rsp+0x20], xmm2
0000798fc6fda4a3  vmovaps [rsp+0x30], xmm3
0000798fc6fda4a9  vmovaps [rsp+0x40], xmm4
0000798fc6fda4af  vmovaps [rsp+0x50], xmm5
0000798fc6fda4b5  vmovaps [rsp+0x60], xmm6
0000798fc6fda4bb  vmovaps [rsp+0x70], xmm7
0000798fc6fda4c1  vmovaps [rsp+0x80], xmm8
0000798fc6fda4ca  vmovaps [rsp+0x90], xmm9
0000798fc6fda4d3  vmovaps [rsp+0xA0], xmm10
0000798fc6fda4dc  vmovaps [rsp+0xB0], xmm11
0000798fc6fda4e5  vmovaps [rsp+0xC0], xmm12
0000798fc6fda4ee  vmovaps [rsp+0xD0], xmm14
0000798fc6fda4f7  vmovaps [rsp+0xE0], xmm15
0000798fc6fda500  sub rsp, 0x30
0000798fc6fda504  movaps [rsp], xmm13
0000798fc6fda509  movaps [rsp+0x10], xmm15
0000798fc6fda50f  movaps [rsp+0x20], xmm8
0000798fc6fda515  lea rdi, [rsp]
0000798fc6fda519  mov esi, 0x00
0000798fc6fda51e  mov rax, 0x63E558B23530
0000798fc6fda528  call rax
0000798fc6fda52a  movaps xmm13, [rsp]
0000798fc6fda52f  add rsp, 0x30
0000798fc6fda533  vmovaps xmm0, [rsp]
0000798fc6fda538  vmovaps xmm1, [rsp+0x10]
0000798fc6fda53e  vmovaps xmm2, [rsp+0x20]
0000798fc6fda544  vmovaps xmm3, [rsp+0x30]
0000798fc6fda54a  vmovaps xmm4, [rsp+0x40]
0000798fc6fda550  vmovaps xmm5, [rsp+0x50]
0000798fc6fda556  vmovaps xmm6, [rsp+0x60]
0000798fc6fda55c  vmovaps xmm7, [rsp+0x70]
0000798fc6fda562  vmovaps xmm8, [rsp+0x80]
0000798fc6fda56b  vmovaps xmm9, [rsp+0x90]
0000798fc6fda574  vmovaps xmm10, [rsp+0xA0]
0000798fc6fda57d  vmovaps xmm11, [rsp+0xB0]
0000798fc6fda586  vmovaps xmm12, [rsp+0xC0]
0000798fc6fda58f  vmovaps xmm14, [rsp+0xD0]
0000798fc6fda598  vmovaps xmm15, [rsp+0xE0]
0000798fc6fda5a1  add rsp, 0xF0
0000798fc6fda5a8  pop r11
0000798fc6fda5aa  pop r10
0000798fc6fda5ac  pop r9
0000798fc6fda5ae  pop r8
0000798fc6fda5b0  pop rsi
0000798fc6fda5b1  pop rdi
0000798fc6fda5b2  pop rdx
0000798fc6fda5b3  pop rcx
0000798fc6fda5b4  pop rax
0000798fc6fda5b5  add rsp, 0x08
0000798fc6fda5b9  jmp 0x0000798FC6FD645C
0000798fc6fda5be  sub rsp, 0x08
0000798fc6fda5c2  push rax
0000798fc6fda5c3  push rcx
0000798fc6fda5c4  push rdx
0000798fc6fda5c5  push rdi
0000798fc6fda5c6  push rsi
0000798fc6fda5c7  push r8
0000798fc6fda5c9  push r9
0000798fc6fda5cb  push r10
0000798fc6fda5cd  push r11
0000798fc6fda5cf  sub rsp, 0xF0
0000798fc6fda5d6  vmovaps [rsp], xmm0
0000798fc6fda5db  vmovaps [rsp+0x10], xmm1
0000798fc6fda5e1  vmovaps [rsp+0x20], xmm2
0000798fc6fda5e7  vmovaps [rsp+0x30], xmm3
0000798fc6fda5ed  vmovaps [rsp+0x40], xmm4
0000798fc6fda5f3  vmovaps [rsp+0x50], xmm5
0000798fc6fda5f9  vmovaps [rsp+0x60], xmm6
0000798fc6fda5ff  vmovaps [rsp+0x70], xmm7
0000798fc6fda605  vmovaps [rsp+0x80], xmm9
0000798fc6fda60e  vmovaps [rsp+0x90], xmm10
0000798fc6fda617  vmovaps [rsp+0xA0], xmm11
0000798fc6fda620  vmovaps [rsp+0xB0], xmm12
0000798fc6fda629  vmovaps [rsp+0xC0], xmm13
0000798fc6fda632  vmovaps [rsp+0xD0], xmm14
0000798fc6fda63b  vmovaps [rsp+0xE0], xmm15
0000798fc6fda644  sub rsp, 0x30
0000798fc6fda648  movaps [rsp], xmm8
0000798fc6fda64d  movaps [rsp+0x10], xmm15
0000798fc6fda653  movaps [rsp+0x20], xmm9
0000798fc6fda659  lea rdi, [rsp]
0000798fc6fda65d  mov esi, 0x00
0000798fc6fda662  mov rax, 0x63E558B23530
0000798fc6fda66c  call rax
0000798fc6fda66e  movaps xmm8, [rsp]
0000798fc6fda673  add rsp, 0x30
0000798fc6fda677  vmovaps xmm0, [rsp]
0000798fc6fda67c  vmovaps xmm1, [rsp+0x10]
0000798fc6fda682  vmovaps xmm2, [rsp+0x20]
0000798fc6fda688  vmovaps xmm3, [rsp+0x30]
0000798fc6fda68e  vmovaps xmm4, [rsp+0x40]
0000798fc6fda694  vmovaps xmm5, [rsp+0x50]
0000798fc6fda69a  vmovaps xmm6, [rsp+0x60]
0000798fc6fda6a0  vmovaps xmm7, [rsp+0x70]
0000798fc6fda6a6  vmovaps xmm9, [rsp+0x80]
0000798fc6fda6af  vmovaps xmm10, [rsp+0x90]
0000798fc6fda6b8  vmovaps xmm11, [rsp+0xA0]
0000798fc6fda6c1  vmovaps xmm12, [rsp+0xB0]
0000798fc6fda6ca  vmovaps xmm13, [rsp+0xC0]
0000798fc6fda6d3  vmovaps xmm14, [rsp+0xD0]
0000798fc6fda6dc  vmovaps xmm15, [rsp+0xE0]
0000798fc6fda6e5  add rsp, 0xF0
0000798fc6fda6ec  pop r11
0000798fc6fda6ee  pop r10
0000798fc6fda6f0  pop r9
0000798fc6fda6f2  pop r8
0000798fc6fda6f4  pop rsi
0000798fc6fda6f5  pop rdi
0000798fc6fda6f6  pop rdx
0000798fc6fda6f7  pop rcx
0000798fc6fda6f8  pop rax
0000798fc6fda6f9  add rsp, 0x08
0000798fc6fda6fd  jmp 0x0000798FC6FD648A
0000798fc6fda702  sub rsp, 0x08
0000798fc6fda706  push rax
0000798fc6fda707  push rcx
0000798fc6fda708  push rdx
0000798fc6fda709  push rdi
0000798fc6fda70a  push rsi
0000798fc6fda70b  push r8
0000798fc6fda70d  push r9
0000798fc6fda70f  push r10
0000798fc6fda711  push r11
0000798fc6fda713  sub rsp, 0xF0
0000798fc6fda71a  vmovaps [rsp], xmm0
0000798fc6fda71f  vmovaps [rsp+0x10], xmm1
0000798fc6fda725  vmovaps [rsp+0x20], xmm2
0000798fc6fda72b  vmovaps [rsp+0x30], xmm3
0000798fc6fda731  vmovaps [rsp+0x40], xmm4
0000798fc6fda737  vmovaps [rsp+0x50], xmm5
0000798fc6fda73d  vmovaps [rsp+0x60], xmm6
0000798fc6fda743  vmovaps [rsp+0x70], xmm7
0000798fc6fda749  vmovaps [rsp+0x80], xmm8
0000798fc6fda752  vmovaps [rsp+0x90], xmm9
0000798fc6fda75b  vmovaps [rsp+0xA0], xmm10
0000798fc6fda764  vmovaps [rsp+0xB0], xmm11
0000798fc6fda76d  vmovaps [rsp+0xC0], xmm12
0000798fc6fda776  vmovaps [rsp+0xD0], xmm13
0000798fc6fda77f  vmovaps [rsp+0xE0], xmm14
0000798fc6fda788  sub rsp, 0x30
0000798fc6fda78c  movaps [rsp], xmm15
0000798fc6fda791  movaps [rsp+0x10], xmm11
0000798fc6fda797  movaps [rsp+0x20], xmm6
0000798fc6fda79c  lea rdi, [rsp]
0000798fc6fda7a0  mov esi, 0x00
0000798fc6fda7a5  mov rax, 0x63E558B23530
0000798fc6fda7af  call rax
0000798fc6fda7b1  movaps xmm15, [rsp]
0000798fc6fda7b6  add rsp, 0x30
0000798fc6fda7ba  vmovaps xmm0, [rsp]
0000798fc6fda7bf  vmovaps xmm1, [rsp+0x10]
0000798fc6fda7c5  vmovaps xmm2, [rsp+0x20]
0000798fc6fda7cb  vmovaps xmm3, [rsp+0x30]
0000798fc6fda7d1  vmovaps xmm4, [rsp+0x40]
0000798fc6fda7d7  vmovaps xmm5, [rsp+0x50]
0000798fc6fda7dd  vmovaps xmm6, [rsp+0x60]
0000798fc6fda7e3  vmovaps xmm7, [rsp+0x70]
0000798fc6fda7e9  vmovaps xmm8, [rsp+0x80]
0000798fc6fda7f2  vmovaps xmm9, [rsp+0x90]
0000798fc6fda7fb  vmovaps xmm10, [rsp+0xA0]
0000798fc6fda804  vmovaps xmm11, [rsp+0xB0]
0000798fc6fda80d  vmovaps xmm12, [rsp+0xC0]
0000798fc6fda816  vmovaps xmm13, [rsp+0xD0]
0000798fc6fda81f  vmovaps xmm14, [rsp+0xE0]
0000798fc6fda828  add rsp, 0xF0
0000798fc6fda82f  pop r11
0000798fc6fda831  pop r10
0000798fc6fda833  pop r9
0000798fc6fda835  pop r8
0000798fc6fda837  pop rsi
0000798fc6fda838  pop rdi
0000798fc6fda839  pop rdx
0000798fc6fda83a  pop rcx
0000798fc6fda83b  pop rax
0000798fc6fda83c  add rsp, 0x08
0000798fc6fda840  jmp 0x0000798FC6FD64A5
0000798fc6fda845  sub rsp, 0x08
0000798fc6fda849  push rax
0000798fc6fda84a  push rcx
0000798fc6fda84b  push rdx
0000798fc6fda84c  push rdi
0000798fc6fda84d  push rsi
0000798fc6fda84e  push r8
0000798fc6fda850  push r9
0000798fc6fda852  push r10
0000798fc6fda854  push r11
0000798fc6fda856  sub rsp, 0xF0
0000798fc6fda85d  vmovaps [rsp], xmm0
0000798fc6fda862  vmovaps [rsp+0x10], xmm1
0000798fc6fda868  vmovaps [rsp+0x20], xmm2
0000798fc6fda86e  vmovaps [rsp+0x30], xmm3
0000798fc6fda874  vmovaps [rsp+0x40], xmm4
0000798fc6fda87a  vmovaps [rsp+0x50], xmm5
0000798fc6fda880  vmovaps [rsp+0x60], xmm6
0000798fc6fda886  vmovaps [rsp+0x70], xmm8
0000798fc6fda88c  vmovaps [rsp+0x80], xmm9
0000798fc6fda895  vmovaps [rsp+0x90], xmm10
0000798fc6fda89e  vmovaps [rsp+0xA0], xmm11
0000798fc6fda8a7  vmovaps [rsp+0xB0], xmm12
0000798fc6fda8b0  vmovaps [rsp+0xC0], xmm13
0000798fc6fda8b9  vmovaps [rsp+0xD0], xmm14
0000798fc6fda8c2  vmovaps [rsp+0xE0], xmm15
0000798fc6fda8cb  sub rsp, 0x30
0000798fc6fda8cf  movaps [rsp], xmm7
0000798fc6fda8d3  movaps [rsp+0x10], xmm11
0000798fc6fda8d9  movaps [rsp+0x20], xmm9
0000798fc6fda8df  lea rdi, [rsp]
0000798fc6fda8e3  mov esi, 0x00
0000798fc6fda8e8  mov rax, 0x63E558B23530
0000798fc6fda8f2  call rax
0000798fc6fda8f4  movaps xmm7, [rsp]
0000798fc6fda8f8  add rsp, 0x30
0000798fc6fda8fc  vmovaps xmm0, [rsp]
0000798fc6fda901  vmovaps xmm1, [rsp+0x10]
0000798fc6fda907  vmovaps xmm2, [rsp+0x20]
0000798fc6fda90d  vmovaps xmm3, [rsp+0x30]
0000798fc6fda913  vmovaps xmm4, [rsp+0x40]
0000798fc6fda919  vmovaps xmm5, [rsp+0x50]
0000798fc6fda91f  vmovaps xmm6, [rsp+0x60]
0000798fc6fda925  vmovaps xmm8, [rsp+0x70]
0000798fc6fda92b  vmovaps xmm9, [rsp+0x80]
0000798fc6fda934  vmovaps xmm10, [rsp+0x90]
0000798fc6fda93d  vmovaps xmm11, [rsp+0xA0]
0000798fc6fda946  vmovaps xmm12, [rsp+0xB0]
0000798fc6fda94f  vmovaps xmm13, [rsp+0xC0]
0000798fc6fda958  vmovaps xmm14, [rsp+0xD0]
0000798fc6fda961  vmovaps xmm15, [rsp+0xE0]
0000798fc6fda96a  add rsp, 0xF0
0000798fc6fda971  pop r11
0000798fc6fda973  pop r10
0000798fc6fda975  pop r9
0000798fc6fda977  pop r8
0000798fc6fda979  pop rsi
0000798fc6fda97a  pop rdi
0000798fc6fda97b  pop rdx
0000798fc6fda97c  pop rcx
0000798fc6fda97d  pop rax
0000798fc6fda97e  add rsp, 0x08
0000798fc6fda982  jmp 0x0000798FC6FD64D2
0000798fc6fda987  sub rsp, 0x08
0000798fc6fda98b  push rax
0000798fc6fda98c  push rcx
0000798fc6fda98d  push rdx
0000798fc6fda98e  push rdi
0000798fc6fda98f  push rsi
0000798fc6fda990  push r8
0000798fc6fda992  push r9
0000798fc6fda994  push r10
0000798fc6fda996  push r11
0000798fc6fda998  sub rsp, 0xF0
0000798fc6fda99f  vmovaps [rsp], xmm0
0000798fc6fda9a4  vmovaps [rsp+0x10], xmm1
0000798fc6fda9aa  vmovaps [rsp+0x20], xmm2
0000798fc6fda9b0  vmovaps [rsp+0x30], xmm3
0000798fc6fda9b6  vmovaps [rsp+0x40], xmm4
0000798fc6fda9bc  vmovaps [rsp+0x50], xmm5
0000798fc6fda9c2  vmovaps [rsp+0x60], xmm6
0000798fc6fda9c8  vmovaps [rsp+0x70], xmm7
0000798fc6fda9ce  vmovaps [rsp+0x80], xmm8
0000798fc6fda9d7  vmovaps [rsp+0x90], xmm9
0000798fc6fda9e0  vmovaps [rsp+0xA0], xmm10
0000798fc6fda9e9  vmovaps [rsp+0xB0], xmm12
0000798fc6fda9f2  vmovaps [rsp+0xC0], xmm13
0000798fc6fda9fb  vmovaps [rsp+0xD0], xmm14
0000798fc6fdaa04  vmovaps [rsp+0xE0], xmm15
0000798fc6fdaa0d  sub rsp, 0x30
0000798fc6fdaa11  movaps [rsp], xmm11
0000798fc6fdaa16  movaps [rsp+0x10], xmm10
0000798fc6fdaa1c  movaps [rsp+0x20], xmm14
0000798fc6fdaa22  lea rdi, [rsp]
0000798fc6fdaa26  mov esi, 0x00
0000798fc6fdaa2b  mov rax, 0x63E558B23530
0000798fc6fdaa35  call rax
0000798fc6fdaa37  movaps xmm11, [rsp]
0000798fc6fdaa3c  add rsp, 0x30
0000798fc6fdaa40  vmovaps xmm0, [rsp]
0000798fc6fdaa45  vmovaps xmm1, [rsp+0x10]
0000798fc6fdaa4b  vmovaps xmm2, [rsp+0x20]
0000798fc6fdaa51  vmovaps xmm3, [rsp+0x30]
0000798fc6fdaa57  vmovaps xmm4, [rsp+0x40]
0000798fc6fdaa5d  vmovaps xmm5, [rsp+0x50]
0000798fc6fdaa63  vmovaps xmm6, [rsp+0x60]
0000798fc6fdaa69  vmovaps xmm7, [rsp+0x70]
0000798fc6fdaa6f  vmovaps xmm8, [rsp+0x80]
0000798fc6fdaa78  vmovaps xmm9, [rsp+0x90]
0000798fc6fdaa81  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdaa8a  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdaa93  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdaa9c  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdaaa5  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdaaae  add rsp, 0xF0
0000798fc6fdaab5  pop r11
0000798fc6fdaab7  pop r10
0000798fc6fdaab9  pop r9
0000798fc6fdaabb  pop r8
0000798fc6fdaabd  pop rsi
0000798fc6fdaabe  pop rdi
0000798fc6fdaabf  pop rdx
0000798fc6fdaac0  pop rcx
0000798fc6fdaac1  pop rax
0000798fc6fdaac2  add rsp, 0x08
0000798fc6fdaac6  jmp 0x0000798FC6FD64ED
0000798fc6fdaacb  call 0x0000798FC6EE45A0
0000798fc6fdaad0  jmp 0x0000798FC6FD64F7
0000798fc6fdaad5  sub rsp, 0x08
0000798fc6fdaad9  push rax
0000798fc6fdaada  push rcx
0000798fc6fdaadb  push rdx
0000798fc6fdaadc  push rdi
0000798fc6fdaadd  push rsi
0000798fc6fdaade  push r8
0000798fc6fdaae0  push r9
0000798fc6fdaae2  push r10
0000798fc6fdaae4  push r11
0000798fc6fdaae6  sub rsp, 0xF0
0000798fc6fdaaed  vmovaps [rsp], xmm0
0000798fc6fdaaf2  vmovaps [rsp+0x10], xmm1
0000798fc6fdaaf8  vmovaps [rsp+0x20], xmm2
0000798fc6fdaafe  vmovaps [rsp+0x30], xmm3
0000798fc6fdab04  vmovaps [rsp+0x40], xmm4
0000798fc6fdab0a  vmovaps [rsp+0x50], xmm5
0000798fc6fdab10  vmovaps [rsp+0x60], xmm6
0000798fc6fdab16  vmovaps [rsp+0x70], xmm7
0000798fc6fdab1c  vmovaps [rsp+0x80], xmm8
0000798fc6fdab25  vmovaps [rsp+0x90], xmm9
0000798fc6fdab2e  vmovaps [rsp+0xA0], xmm11
0000798fc6fdab37  vmovaps [rsp+0xB0], xmm12
0000798fc6fdab40  vmovaps [rsp+0xC0], xmm13
0000798fc6fdab49  vmovaps [rsp+0xD0], xmm14
0000798fc6fdab52  vmovaps [rsp+0xE0], xmm15
0000798fc6fdab5b  sub rsp, 0x30
0000798fc6fdab5f  movaps [rsp], xmm10
0000798fc6fdab64  movaps [rsp+0x10], xmm1
0000798fc6fdab69  movaps [rsp+0x20], xmm12
0000798fc6fdab6f  lea rdi, [rsp]
0000798fc6fdab73  mov esi, 0x00
0000798fc6fdab78  mov rax, 0x63E558B23530
0000798fc6fdab82  call rax
0000798fc6fdab84  movaps xmm10, [rsp]
0000798fc6fdab89  add rsp, 0x30
0000798fc6fdab8d  vmovaps xmm0, [rsp]
0000798fc6fdab92  vmovaps xmm1, [rsp+0x10]
0000798fc6fdab98  vmovaps xmm2, [rsp+0x20]
0000798fc6fdab9e  vmovaps xmm3, [rsp+0x30]
0000798fc6fdaba4  vmovaps xmm4, [rsp+0x40]
0000798fc6fdabaa  vmovaps xmm5, [rsp+0x50]
0000798fc6fdabb0  vmovaps xmm6, [rsp+0x60]
0000798fc6fdabb6  vmovaps xmm7, [rsp+0x70]
0000798fc6fdabbc  vmovaps xmm8, [rsp+0x80]
0000798fc6fdabc5  vmovaps xmm9, [rsp+0x90]
0000798fc6fdabce  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdabd7  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdabe0  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdabe9  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdabf2  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdabfb  add rsp, 0xF0
0000798fc6fdac02  pop r11
0000798fc6fdac04  pop r10
0000798fc6fdac06  pop r9
0000798fc6fdac08  pop r8
0000798fc6fdac0a  pop rsi
0000798fc6fdac0b  pop rdi
0000798fc6fdac0c  pop rdx
0000798fc6fdac0d  pop rcx
0000798fc6fdac0e  pop rax
0000798fc6fdac0f  add rsp, 0x08
0000798fc6fdac13  jmp 0x0000798FC6FD651A
0000798fc6fdac18  sub rsp, 0x08
0000798fc6fdac1c  push rax
0000798fc6fdac1d  push rcx
0000798fc6fdac1e  push rdx
0000798fc6fdac1f  push rdi
0000798fc6fdac20  push rsi
0000798fc6fdac21  push r8
0000798fc6fdac23  push r9
0000798fc6fdac25  push r10
0000798fc6fdac27  push r11
0000798fc6fdac29  sub rsp, 0xF0
0000798fc6fdac30  vmovaps [rsp], xmm0
0000798fc6fdac35  vmovaps [rsp+0x10], xmm1
0000798fc6fdac3b  vmovaps [rsp+0x20], xmm2
0000798fc6fdac41  vmovaps [rsp+0x30], xmm3
0000798fc6fdac47  vmovaps [rsp+0x40], xmm4
0000798fc6fdac4d  vmovaps [rsp+0x50], xmm5
0000798fc6fdac53  vmovaps [rsp+0x60], xmm6
0000798fc6fdac59  vmovaps [rsp+0x70], xmm7
0000798fc6fdac5f  vmovaps [rsp+0x80], xmm8
0000798fc6fdac68  vmovaps [rsp+0x90], xmm9
0000798fc6fdac71  vmovaps [rsp+0xA0], xmm10
0000798fc6fdac7a  vmovaps [rsp+0xB0], xmm11
0000798fc6fdac83  vmovaps [rsp+0xC0], xmm13
0000798fc6fdac8c  vmovaps [rsp+0xD0], xmm14
0000798fc6fdac95  vmovaps [rsp+0xE0], xmm15
0000798fc6fdac9e  sub rsp, 0x30
0000798fc6fdaca2  movaps [rsp], xmm12
0000798fc6fdaca7  movaps [rsp+0x10], xmm14
0000798fc6fdacad  movaps [rsp+0x20], xmm1
0000798fc6fdacb2  lea rdi, [rsp]
0000798fc6fdacb6  mov esi, 0x00
0000798fc6fdacbb  mov rax, 0x63E558B23530
0000798fc6fdacc5  call rax
0000798fc6fdacc7  movaps xmm12, [rsp]
0000798fc6fdaccc  add rsp, 0x30
0000798fc6fdacd0  vmovaps xmm0, [rsp]
0000798fc6fdacd5  vmovaps xmm1, [rsp+0x10]
0000798fc6fdacdb  vmovaps xmm2, [rsp+0x20]
0000798fc6fdace1  vmovaps xmm3, [rsp+0x30]
0000798fc6fdace7  vmovaps xmm4, [rsp+0x40]
0000798fc6fdaced  vmovaps xmm5, [rsp+0x50]
0000798fc6fdacf3  vmovaps xmm6, [rsp+0x60]
0000798fc6fdacf9  vmovaps xmm7, [rsp+0x70]
0000798fc6fdacff  vmovaps xmm8, [rsp+0x80]
0000798fc6fdad08  vmovaps xmm9, [rsp+0x90]
0000798fc6fdad11  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdad1a  vmovaps xmm11, [rsp+0xB0]
0000798fc6fdad23  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdad2c  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdad35  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdad3e  add rsp, 0xF0
0000798fc6fdad45  pop r11
0000798fc6fdad47  pop r10
0000798fc6fdad49  pop r9
0000798fc6fdad4b  pop r8
0000798fc6fdad4d  pop rsi
0000798fc6fdad4e  pop rdi
0000798fc6fdad4f  pop rdx
0000798fc6fdad50  pop rcx
0000798fc6fdad51  pop rax
0000798fc6fdad52  add rsp, 0x08
0000798fc6fdad56  jmp 0x0000798FC6FD6549
0000798fc6fdad5b  sub rsp, 0x08
0000798fc6fdad5f  push rax
0000798fc6fdad60  push rcx
0000798fc6fdad61  push rdx
0000798fc6fdad62  push rdi
0000798fc6fdad63  push rsi
0000798fc6fdad64  push r8
0000798fc6fdad66  push r9
0000798fc6fdad68  push r10
0000798fc6fdad6a  push r11
0000798fc6fdad6c  sub rsp, 0xF0
0000798fc6fdad73  vmovaps [rsp], xmm0
0000798fc6fdad78  vmovaps [rsp+0x10], xmm1
0000798fc6fdad7e  vmovaps [rsp+0x20], xmm2
0000798fc6fdad84  vmovaps [rsp+0x30], xmm3
0000798fc6fdad8a  vmovaps [rsp+0x40], xmm4
0000798fc6fdad90  vmovaps [rsp+0x50], xmm5
0000798fc6fdad96  vmovaps [rsp+0x60], xmm6
0000798fc6fdad9c  vmovaps [rsp+0x70], xmm7
0000798fc6fdada2  vmovaps [rsp+0x80], xmm8
0000798fc6fdadab  vmovaps [rsp+0x90], xmm9
0000798fc6fdadb4  vmovaps [rsp+0xA0], xmm10
0000798fc6fdadbd  vmovaps [rsp+0xB0], xmm11
0000798fc6fdadc6  vmovaps [rsp+0xC0], xmm12
0000798fc6fdadcf  vmovaps [rsp+0xD0], xmm13
0000798fc6fdadd8  vmovaps [rsp+0xE0], xmm15
0000798fc6fdade1  sub rsp, 0x30
0000798fc6fdade5  movaps [rsp], xmm14
0000798fc6fdadea  movaps [rsp+0x10], xmm9
0000798fc6fdadf0  movaps [rsp+0x20], xmm1
0000798fc6fdadf5  lea rdi, [rsp]
0000798fc6fdadf9  mov esi, 0x00
0000798fc6fdadfe  mov rax, 0x63E558B23530
0000798fc6fdae08  call rax
0000798fc6fdae0a  movaps xmm14, [rsp]
0000798fc6fdae0f  add rsp, 0x30
0000798fc6fdae13  vmovaps xmm0, [rsp]
0000798fc6fdae18  vmovaps xmm1, [rsp+0x10]
0000798fc6fdae1e  vmovaps xmm2, [rsp+0x20]
0000798fc6fdae24  vmovaps xmm3, [rsp+0x30]
0000798fc6fdae2a  vmovaps xmm4, [rsp+0x40]
0000798fc6fdae30  vmovaps xmm5, [rsp+0x50]
0000798fc6fdae36  vmovaps xmm6, [rsp+0x60]
0000798fc6fdae3c  vmovaps xmm7, [rsp+0x70]
0000798fc6fdae42  vmovaps xmm8, [rsp+0x80]
0000798fc6fdae4b  vmovaps xmm9, [rsp+0x90]
0000798fc6fdae54  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdae5d  vmovaps xmm11, [rsp+0xB0]
0000798fc6fdae66  vmovaps xmm12, [rsp+0xC0]
0000798fc6fdae6f  vmovaps xmm13, [rsp+0xD0]
0000798fc6fdae78  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdae81  add rsp, 0xF0
0000798fc6fdae88  pop r11
0000798fc6fdae8a  pop r10
0000798fc6fdae8c  pop r9
0000798fc6fdae8e  pop r8
0000798fc6fdae90  pop rsi
0000798fc6fdae91  pop rdi
0000798fc6fdae92  pop rdx
0000798fc6fdae93  pop rcx
0000798fc6fdae94  pop rax
0000798fc6fdae95  add rsp, 0x08
0000798fc6fdae99  jmp 0x0000798FC6FD6578
0000798fc6fdae9e  sub rsp, 0x08
0000798fc6fdaea2  push rax
0000798fc6fdaea3  push rcx
0000798fc6fdaea4  push rdx
0000798fc6fdaea5  push rdi
0000798fc6fdaea6  push rsi
0000798fc6fdaea7  push r8
0000798fc6fdaea9  push r9
0000798fc6fdaeab  push r10
0000798fc6fdaead  push r11
0000798fc6fdaeaf  sub rsp, 0xF0
0000798fc6fdaeb6  vmovaps [rsp], xmm0
0000798fc6fdaebb  vmovaps [rsp+0x10], xmm2
0000798fc6fdaec1  vmovaps [rsp+0x20], xmm3
0000798fc6fdaec7  vmovaps [rsp+0x30], xmm4
0000798fc6fdaecd  vmovaps [rsp+0x40], xmm5
0000798fc6fdaed3  vmovaps [rsp+0x50], xmm6
0000798fc6fdaed9  vmovaps [rsp+0x60], xmm7
0000798fc6fdaedf  vmovaps [rsp+0x70], xmm8
0000798fc6fdaee5  vmovaps [rsp+0x80], xmm9
0000798fc6fdaeee  vmovaps [rsp+0x90], xmm10
0000798fc6fdaef7  vmovaps [rsp+0xA0], xmm11
0000798fc6fdaf00  vmovaps [rsp+0xB0], xmm12
0000798fc6fdaf09  vmovaps [rsp+0xC0], xmm13
0000798fc6fdaf12  vmovaps [rsp+0xD0], xmm14
0000798fc6fdaf1b  vmovaps [rsp+0xE0], xmm15
0000798fc6fdaf24  sub rsp, 0x30
0000798fc6fdaf28  movaps [rsp], xmm1
0000798fc6fdaf2c  movaps [rsp+0x10], xmm13
0000798fc6fdaf32  movaps [rsp+0x20], xmm8
0000798fc6fdaf38  lea rdi, [rsp]
0000798fc6fdaf3c  mov esi, 0x00
0000798fc6fdaf41  mov rax, 0x63E558B23530
0000798fc6fdaf4b  call rax
0000798fc6fdaf4d  movaps xmm1, [rsp]
0000798fc6fdaf51  add rsp, 0x30
0000798fc6fdaf55  vmovaps xmm0, [rsp]
0000798fc6fdaf5a  vmovaps xmm2, [rsp+0x10]
0000798fc6fdaf60  vmovaps xmm3, [rsp+0x20]
0000798fc6fdaf66  vmovaps xmm4, [rsp+0x30]
0000798fc6fdaf6c  vmovaps xmm5, [rsp+0x40]
0000798fc6fdaf72  vmovaps xmm6, [rsp+0x50]
0000798fc6fdaf78  vmovaps xmm7, [rsp+0x60]
0000798fc6fdaf7e  vmovaps xmm8, [rsp+0x70]
0000798fc6fdaf84  vmovaps xmm9, [rsp+0x80]
0000798fc6fdaf8d  vmovaps xmm10, [rsp+0x90]
0000798fc6fdaf96  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdaf9f  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdafa8  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdafb1  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdafba  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdafc3  add rsp, 0xF0
0000798fc6fdafca  pop r11
0000798fc6fdafcc  pop r10
0000798fc6fdafce  pop r9
0000798fc6fdafd0  pop r8
0000798fc6fdafd2  pop rsi
0000798fc6fdafd3  pop rdi
0000798fc6fdafd4  pop rdx
0000798fc6fdafd5  pop rcx
0000798fc6fdafd6  pop rax
0000798fc6fdafd7  add rsp, 0x08
0000798fc6fdafdb  jmp 0x0000798FC6FD659A
0000798fc6fdafe0  call 0x0000798FC6E0C260
0000798fc6fdafe5  jmp 0x0000798FC6FD65A8
0000798fc6fdafea  call 0x0000798FC6EDE950
0000798fc6fdafef  jmp 0x0000798FC6FD65B2
0000798fc6fdaff4  sub rsp, 0x08
0000798fc6fdaff8  push rax
0000798fc6fdaff9  push rcx
0000798fc6fdaffa  push rdx
0000798fc6fdaffb  push rdi
0000798fc6fdaffc  push rsi
0000798fc6fdaffd  push r8
0000798fc6fdafff  push r9
0000798fc6fdb001  push r10
0000798fc6fdb003  push r11
0000798fc6fdb005  sub rsp, 0xF0
0000798fc6fdb00c  vmovaps [rsp], xmm0
0000798fc6fdb011  vmovaps [rsp+0x10], xmm1
0000798fc6fdb017  vmovaps [rsp+0x20], xmm2
0000798fc6fdb01d  vmovaps [rsp+0x30], xmm3
0000798fc6fdb023  vmovaps [rsp+0x40], xmm4
0000798fc6fdb029  vmovaps [rsp+0x50], xmm5
0000798fc6fdb02f  vmovaps [rsp+0x60], xmm6
0000798fc6fdb035  vmovaps [rsp+0x70], xmm7
0000798fc6fdb03b  vmovaps [rsp+0x80], xmm9
0000798fc6fdb044  vmovaps [rsp+0x90], xmm10
0000798fc6fdb04d  vmovaps [rsp+0xA0], xmm11
0000798fc6fdb056  vmovaps [rsp+0xB0], xmm12
0000798fc6fdb05f  vmovaps [rsp+0xC0], xmm13
0000798fc6fdb068  vmovaps [rsp+0xD0], xmm14
0000798fc6fdb071  vmovaps [rsp+0xE0], xmm15
0000798fc6fdb07a  sub rsp, 0x30
0000798fc6fdb07e  movaps [rsp], xmm8
0000798fc6fdb083  movaps [rsp+0x10], xmm15
0000798fc6fdb089  movaps [rsp+0x20], xmm7
0000798fc6fdb08e  lea rdi, [rsp]
0000798fc6fdb092  mov esi, 0x00
0000798fc6fdb097  mov rax, 0x63E558B23530
0000798fc6fdb0a1  call rax
0000798fc6fdb0a3  movaps xmm8, [rsp]
0000798fc6fdb0a8  add rsp, 0x30
0000798fc6fdb0ac  vmovaps xmm0, [rsp]
0000798fc6fdb0b1  vmovaps xmm1, [rsp+0x10]
0000798fc6fdb0b7  vmovaps xmm2, [rsp+0x20]
0000798fc6fdb0bd  vmovaps xmm3, [rsp+0x30]
0000798fc6fdb0c3  vmovaps xmm4, [rsp+0x40]
0000798fc6fdb0c9  vmovaps xmm5, [rsp+0x50]
0000798fc6fdb0cf  vmovaps xmm6, [rsp+0x60]
0000798fc6fdb0d5  vmovaps xmm7, [rsp+0x70]
0000798fc6fdb0db  vmovaps xmm9, [rsp+0x80]
0000798fc6fdb0e4  vmovaps xmm10, [rsp+0x90]
0000798fc6fdb0ed  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdb0f6  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdb0ff  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdb108  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdb111  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdb11a  add rsp, 0xF0
0000798fc6fdb121  pop r11
0000798fc6fdb123  pop r10
0000798fc6fdb125  pop r9
0000798fc6fdb127  pop r8
0000798fc6fdb129  pop rsi
0000798fc6fdb12a  pop rdi
0000798fc6fdb12b  pop rdx
0000798fc6fdb12c  pop rcx
0000798fc6fdb12d  pop rax
0000798fc6fdb12e  add rsp, 0x08
0000798fc6fdb132  jmp 0x0000798FC6FD65D4
0000798fc6fdb137  sub rsp, 0x08
0000798fc6fdb13b  push rax
0000798fc6fdb13c  push rcx
0000798fc6fdb13d  push rdx
0000798fc6fdb13e  push rdi
0000798fc6fdb13f  push rsi
0000798fc6fdb140  push r8
0000798fc6fdb142  push r9
0000798fc6fdb144  push r10
0000798fc6fdb146  push r11
0000798fc6fdb148  sub rsp, 0xF0
0000798fc6fdb14f  vmovaps [rsp], xmm0
0000798fc6fdb154  vmovaps [rsp+0x10], xmm1
0000798fc6fdb15a  vmovaps [rsp+0x20], xmm2
0000798fc6fdb160  vmovaps [rsp+0x30], xmm3
0000798fc6fdb166  vmovaps [rsp+0x40], xmm4
0000798fc6fdb16c  vmovaps [rsp+0x50], xmm5
0000798fc6fdb172  vmovaps [rsp+0x60], xmm6
0000798fc6fdb178  vmovaps [rsp+0x70], xmm8
0000798fc6fdb17e  vmovaps [rsp+0x80], xmm9
0000798fc6fdb187  vmovaps [rsp+0x90], xmm10
0000798fc6fdb190  vmovaps [rsp+0xA0], xmm11
0000798fc6fdb199  vmovaps [rsp+0xB0], xmm12
0000798fc6fdb1a2  vmovaps [rsp+0xC0], xmm13
0000798fc6fdb1ab  vmovaps [rsp+0xD0], xmm14
0000798fc6fdb1b4  vmovaps [rsp+0xE0], xmm15
0000798fc6fdb1bd  sub rsp, 0x30
0000798fc6fdb1c1  movaps [rsp], xmm7
0000798fc6fdb1c5  movaps [rsp+0x10], xmm9
0000798fc6fdb1cb  movaps [rsp+0x20], xmm15
0000798fc6fdb1d1  lea rdi, [rsp]
0000798fc6fdb1d5  mov esi, 0x00
0000798fc6fdb1da  mov rax, 0x63E558B23530
0000798fc6fdb1e4  call rax
0000798fc6fdb1e6  movaps xmm7, [rsp]
0000798fc6fdb1ea  add rsp, 0x30
0000798fc6fdb1ee  vmovaps xmm0, [rsp]
0000798fc6fdb1f3  vmovaps xmm1, [rsp+0x10]
0000798fc6fdb1f9  vmovaps xmm2, [rsp+0x20]
0000798fc6fdb1ff  vmovaps xmm3, [rsp+0x30]
0000798fc6fdb205  vmovaps xmm4, [rsp+0x40]
0000798fc6fdb20b  vmovaps xmm5, [rsp+0x50]
0000798fc6fdb211  vmovaps xmm6, [rsp+0x60]
0000798fc6fdb217  vmovaps xmm8, [rsp+0x70]
0000798fc6fdb21d  vmovaps xmm9, [rsp+0x80]
0000798fc6fdb226  vmovaps xmm10, [rsp+0x90]
0000798fc6fdb22f  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdb238  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdb241  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdb24a  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdb253  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdb25c  add rsp, 0xF0
0000798fc6fdb263  pop r11
0000798fc6fdb265  pop r10
0000798fc6fdb267  pop r9
0000798fc6fdb269  pop r8
0000798fc6fdb26b  pop rsi
0000798fc6fdb26c  pop rdi
0000798fc6fdb26d  pop rdx
0000798fc6fdb26e  pop rcx
0000798fc6fdb26f  pop rax
0000798fc6fdb270  add rsp, 0x08
0000798fc6fdb274  jmp 0x0000798FC6FD6601
0000798fc6fdb279  sub rsp, 0x08
0000798fc6fdb27d  push rax
0000798fc6fdb27e  push rcx
0000798fc6fdb27f  push rdx
0000798fc6fdb280  push rdi
0000798fc6fdb281  push rsi
0000798fc6fdb282  push r8
0000798fc6fdb284  push r9
0000798fc6fdb286  push r10
0000798fc6fdb288  push r11
0000798fc6fdb28a  sub rsp, 0xF0
0000798fc6fdb291  vmovaps [rsp], xmm0
0000798fc6fdb296  vmovaps [rsp+0x10], xmm1
0000798fc6fdb29c  vmovaps [rsp+0x20], xmm2
0000798fc6fdb2a2  vmovaps [rsp+0x30], xmm3
0000798fc6fdb2a8  vmovaps [rsp+0x40], xmm4
0000798fc6fdb2ae  vmovaps [rsp+0x50], xmm5
0000798fc6fdb2b4  vmovaps [rsp+0x60], xmm6
0000798fc6fdb2ba  vmovaps [rsp+0x70], xmm7
0000798fc6fdb2c0  vmovaps [rsp+0x80], xmm8
0000798fc6fdb2c9  vmovaps [rsp+0x90], xmm10
0000798fc6fdb2d2  vmovaps [rsp+0xA0], xmm11
0000798fc6fdb2db  vmovaps [rsp+0xB0], xmm12
0000798fc6fdb2e4  vmovaps [rsp+0xC0], xmm13
0000798fc6fdb2ed  vmovaps [rsp+0xD0], xmm14
0000798fc6fdb2f6  vmovaps [rsp+0xE0], xmm15
0000798fc6fdb2ff  sub rsp, 0x30
0000798fc6fdb303  movaps [rsp], xmm9
0000798fc6fdb308  movaps [rsp+0x10], xmm13
0000798fc6fdb30e  movaps [rsp+0x20], xmm15
0000798fc6fdb314  lea rdi, [rsp]
0000798fc6fdb318  mov esi, 0x00
0000798fc6fdb31d  mov rax, 0x63E558B23530
0000798fc6fdb327  call rax
0000798fc6fdb329  movaps xmm9, [rsp]
0000798fc6fdb32e  add rsp, 0x30
0000798fc6fdb332  vmovaps xmm0, [rsp]
0000798fc6fdb337  vmovaps xmm1, [rsp+0x10]
0000798fc6fdb33d  vmovaps xmm2, [rsp+0x20]
0000798fc6fdb343  vmovaps xmm3, [rsp+0x30]
0000798fc6fdb349  vmovaps xmm4, [rsp+0x40]
0000798fc6fdb34f  vmovaps xmm5, [rsp+0x50]
0000798fc6fdb355  vmovaps xmm6, [rsp+0x60]
0000798fc6fdb35b  vmovaps xmm7, [rsp+0x70]
0000798fc6fdb361  vmovaps xmm8, [rsp+0x80]
0000798fc6fdb36a  vmovaps xmm10, [rsp+0x90]
0000798fc6fdb373  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdb37c  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdb385  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdb38e  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdb397  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdb3a0  add rsp, 0xF0
0000798fc6fdb3a7  pop r11
0000798fc6fdb3a9  pop r10
0000798fc6fdb3ab  pop r9
0000798fc6fdb3ad  pop r8
0000798fc6fdb3af  pop rsi
0000798fc6fdb3b0  pop rdi
0000798fc6fdb3b1  pop rdx
0000798fc6fdb3b2  pop rcx
0000798fc6fdb3b3  pop rax
0000798fc6fdb3b4  add rsp, 0x08
0000798fc6fdb3b8  jmp 0x0000798FC6FD662F
0000798fc6fdb3bd  sub rsp, 0x08
0000798fc6fdb3c1  push rax
0000798fc6fdb3c2  push rcx
0000798fc6fdb3c3  push rdx
0000798fc6fdb3c4  push rdi
0000798fc6fdb3c5  push rsi
0000798fc6fdb3c6  push r8
0000798fc6fdb3c8  push r9
0000798fc6fdb3ca  push r10
0000798fc6fdb3cc  push r11
0000798fc6fdb3ce  sub rsp, 0xF0
0000798fc6fdb3d5  vmovaps [rsp], xmm0
0000798fc6fdb3da  vmovaps [rsp+0x10], xmm1
0000798fc6fdb3e0  vmovaps [rsp+0x20], xmm2
0000798fc6fdb3e6  vmovaps [rsp+0x30], xmm3
0000798fc6fdb3ec  vmovaps [rsp+0x40], xmm4
0000798fc6fdb3f2  vmovaps [rsp+0x50], xmm5
0000798fc6fdb3f8  vmovaps [rsp+0x60], xmm6
0000798fc6fdb3fe  vmovaps [rsp+0x70], xmm7
0000798fc6fdb404  vmovaps [rsp+0x80], xmm8
0000798fc6fdb40d  vmovaps [rsp+0x90], xmm9
0000798fc6fdb416  vmovaps [rsp+0xA0], xmm10
0000798fc6fdb41f  vmovaps [rsp+0xB0], xmm11
0000798fc6fdb428  vmovaps [rsp+0xC0], xmm12
0000798fc6fdb431  vmovaps [rsp+0xD0], xmm13
0000798fc6fdb43a  vmovaps [rsp+0xE0], xmm14
0000798fc6fdb443  sub rsp, 0x30
0000798fc6fdb447  movaps [rsp], xmm15
0000798fc6fdb44c  movaps [rsp+0x10], xmm11
0000798fc6fdb452  movaps [rsp+0x20], xmm12
0000798fc6fdb458  lea rdi, [rsp]
0000798fc6fdb45c  mov esi, 0x00
0000798fc6fdb461  mov rax, 0x63E558B23530
0000798fc6fdb46b  call rax
0000798fc6fdb46d  movaps xmm15, [rsp]
0000798fc6fdb472  add rsp, 0x30
0000798fc6fdb476  vmovaps xmm0, [rsp]
0000798fc6fdb47b  vmovaps xmm1, [rsp+0x10]
0000798fc6fdb481  vmovaps xmm2, [rsp+0x20]
0000798fc6fdb487  vmovaps xmm3, [rsp+0x30]
0000798fc6fdb48d  vmovaps xmm4, [rsp+0x40]
0000798fc6fdb493  vmovaps xmm5, [rsp+0x50]
0000798fc6fdb499  vmovaps xmm6, [rsp+0x60]
0000798fc6fdb49f  vmovaps xmm7, [rsp+0x70]
0000798fc6fdb4a5  vmovaps xmm8, [rsp+0x80]
0000798fc6fdb4ae  vmovaps xmm9, [rsp+0x90]
0000798fc6fdb4b7  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdb4c0  vmovaps xmm11, [rsp+0xB0]
0000798fc6fdb4c9  vmovaps xmm12, [rsp+0xC0]
0000798fc6fdb4d2  vmovaps xmm13, [rsp+0xD0]
0000798fc6fdb4db  vmovaps xmm14, [rsp+0xE0]
0000798fc6fdb4e4  add rsp, 0xF0
0000798fc6fdb4eb  pop r11
0000798fc6fdb4ed  pop r10
0000798fc6fdb4ef  pop r9
0000798fc6fdb4f1  pop r8
0000798fc6fdb4f3  pop rsi
0000798fc6fdb4f4  pop rdi
0000798fc6fdb4f5  pop rdx
0000798fc6fdb4f6  pop rcx
0000798fc6fdb4f7  pop rax
0000798fc6fdb4f8  add rsp, 0x08
0000798fc6fdb4fc  jmp 0x0000798FC6FD664A
0000798fc6fdb501  sub rsp, 0x08
0000798fc6fdb505  push rax
0000798fc6fdb506  push rcx
0000798fc6fdb507  push rdx
0000798fc6fdb508  push rdi
0000798fc6fdb509  push rsi
0000798fc6fdb50a  push r8
0000798fc6fdb50c  push r9
0000798fc6fdb50e  push r10
0000798fc6fdb510  push r11
0000798fc6fdb512  sub rsp, 0xF0
0000798fc6fdb519  vmovaps [rsp], xmm0
0000798fc6fdb51e  vmovaps [rsp+0x10], xmm1
0000798fc6fdb524  vmovaps [rsp+0x20], xmm2
0000798fc6fdb52a  vmovaps [rsp+0x30], xmm3
0000798fc6fdb530  vmovaps [rsp+0x40], xmm4
0000798fc6fdb536  vmovaps [rsp+0x50], xmm5
0000798fc6fdb53c  vmovaps [rsp+0x60], xmm6
0000798fc6fdb542  vmovaps [rsp+0x70], xmm7
0000798fc6fdb548  vmovaps [rsp+0x80], xmm8
0000798fc6fdb551  vmovaps [rsp+0x90], xmm9
0000798fc6fdb55a  vmovaps [rsp+0xA0], xmm10
0000798fc6fdb563  vmovaps [rsp+0xB0], xmm11
0000798fc6fdb56c  vmovaps [rsp+0xC0], xmm12
0000798fc6fdb575  vmovaps [rsp+0xD0], xmm14
0000798fc6fdb57e  vmovaps [rsp+0xE0], xmm15
0000798fc6fdb587  sub rsp, 0x30
0000798fc6fdb58b  movaps [rsp], xmm13
0000798fc6fdb590  movaps [rsp+0x10], xmm10
0000798fc6fdb596  movaps [rsp+0x20], xmm14
0000798fc6fdb59c  lea rdi, [rsp]
0000798fc6fdb5a0  mov esi, 0x00
0000798fc6fdb5a5  mov rax, 0x63E558B23530
0000798fc6fdb5af  call rax
0000798fc6fdb5b1  movaps xmm13, [rsp]
0000798fc6fdb5b6  add rsp, 0x30
0000798fc6fdb5ba  vmovaps xmm0, [rsp]
0000798fc6fdb5bf  vmovaps xmm1, [rsp+0x10]
0000798fc6fdb5c5  vmovaps xmm2, [rsp+0x20]
0000798fc6fdb5cb  vmovaps xmm3, [rsp+0x30]
0000798fc6fdb5d1  vmovaps xmm4, [rsp+0x40]
0000798fc6fdb5d7  vmovaps xmm5, [rsp+0x50]
0000798fc6fdb5dd  vmovaps xmm6, [rsp+0x60]
0000798fc6fdb5e3  vmovaps xmm7, [rsp+0x70]
0000798fc6fdb5e9  vmovaps xmm8, [rsp+0x80]
0000798fc6fdb5f2  vmovaps xmm9, [rsp+0x90]
0000798fc6fdb5fb  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdb604  vmovaps xmm11, [rsp+0xB0]
0000798fc6fdb60d  vmovaps xmm12, [rsp+0xC0]
0000798fc6fdb616  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdb61f  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdb628  add rsp, 0xF0
0000798fc6fdb62f  pop r11
0000798fc6fdb631  pop r10
0000798fc6fdb633  pop r9
0000798fc6fdb635  pop r8
0000798fc6fdb637  pop rsi
0000798fc6fdb638  pop rdi
0000798fc6fdb639  pop rdx
0000798fc6fdb63a  pop rcx
0000798fc6fdb63b  pop rax
0000798fc6fdb63c  add rsp, 0x08
0000798fc6fdb640  jmp 0x0000798FC6FD666D
0000798fc6fdb645  sub rsp, 0x08
0000798fc6fdb649  push rax
0000798fc6fdb64a  push rcx
0000798fc6fdb64b  push rdx
0000798fc6fdb64c  push rdi
0000798fc6fdb64d  push rsi
0000798fc6fdb64e  push r8
0000798fc6fdb650  push r9
0000798fc6fdb652  push r10
0000798fc6fdb654  push r11
0000798fc6fdb656  sub rsp, 0xF0
0000798fc6fdb65d  vmovaps [rsp], xmm0
0000798fc6fdb662  vmovaps [rsp+0x10], xmm1
0000798fc6fdb668  vmovaps [rsp+0x20], xmm2
0000798fc6fdb66e  vmovaps [rsp+0x30], xmm3
0000798fc6fdb674  vmovaps [rsp+0x40], xmm4
0000798fc6fdb67a  vmovaps [rsp+0x50], xmm5
0000798fc6fdb680  vmovaps [rsp+0x60], xmm6
0000798fc6fdb686  vmovaps [rsp+0x70], xmm7
0000798fc6fdb68c  vmovaps [rsp+0x80], xmm8
0000798fc6fdb695  vmovaps [rsp+0x90], xmm9
0000798fc6fdb69e  vmovaps [rsp+0xA0], xmm10
0000798fc6fdb6a7  vmovaps [rsp+0xB0], xmm11
0000798fc6fdb6b0  vmovaps [rsp+0xC0], xmm12
0000798fc6fdb6b9  vmovaps [rsp+0xD0], xmm13
0000798fc6fdb6c2  vmovaps [rsp+0xE0], xmm15
0000798fc6fdb6cb  sub rsp, 0x30
0000798fc6fdb6cf  movaps [rsp], xmm14
0000798fc6fdb6d4  movaps [rsp+0x10], xmm1
0000798fc6fdb6d9  movaps [rsp+0x20], xmm7
0000798fc6fdb6de  lea rdi, [rsp]
0000798fc6fdb6e2  mov esi, 0x00
0000798fc6fdb6e7  mov rax, 0x63E558B23530
0000798fc6fdb6f1  call rax
0000798fc6fdb6f3  movaps xmm14, [rsp]
0000798fc6fdb6f8  add rsp, 0x30
0000798fc6fdb6fc  vmovaps xmm0, [rsp]
0000798fc6fdb701  vmovaps xmm1, [rsp+0x10]
0000798fc6fdb707  vmovaps xmm2, [rsp+0x20]
0000798fc6fdb70d  vmovaps xmm3, [rsp+0x30]
0000798fc6fdb713  vmovaps xmm4, [rsp+0x40]
0000798fc6fdb719  vmovaps xmm5, [rsp+0x50]
0000798fc6fdb71f  vmovaps xmm6, [rsp+0x60]
0000798fc6fdb725  vmovaps xmm7, [rsp+0x70]
0000798fc6fdb72b  vmovaps xmm8, [rsp+0x80]
0000798fc6fdb734  vmovaps xmm9, [rsp+0x90]
0000798fc6fdb73d  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdb746  vmovaps xmm11, [rsp+0xB0]
0000798fc6fdb74f  vmovaps xmm12, [rsp+0xC0]
0000798fc6fdb758  vmovaps xmm13, [rsp+0xD0]
0000798fc6fdb761  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdb76a  add rsp, 0xF0
0000798fc6fdb771  pop r11
0000798fc6fdb773  pop r10
0000798fc6fdb775  pop r9
0000798fc6fdb777  pop r8
0000798fc6fdb779  pop rsi
0000798fc6fdb77a  pop rdi
0000798fc6fdb77b  pop rdx
0000798fc6fdb77c  pop rcx
0000798fc6fdb77d  pop rax
0000798fc6fdb77e  add rsp, 0x08
0000798fc6fdb782  jmp 0x0000798FC6FD6690
0000798fc6fdb787  sub rsp, 0x08
0000798fc6fdb78b  push rax
0000798fc6fdb78c  push rcx
0000798fc6fdb78d  push rdx
0000798fc6fdb78e  push rdi
0000798fc6fdb78f  push rsi
0000798fc6fdb790  push r8
0000798fc6fdb792  push r9
0000798fc6fdb794  push r10
0000798fc6fdb796  push r11
0000798fc6fdb798  sub rsp, 0xF0
0000798fc6fdb79f  vmovaps [rsp], xmm0
0000798fc6fdb7a4  vmovaps [rsp+0x10], xmm2
0000798fc6fdb7aa  vmovaps [rsp+0x20], xmm3
0000798fc6fdb7b0  vmovaps [rsp+0x30], xmm4
0000798fc6fdb7b6  vmovaps [rsp+0x40], xmm5
0000798fc6fdb7bc  vmovaps [rsp+0x50], xmm6
0000798fc6fdb7c2  vmovaps [rsp+0x60], xmm7
0000798fc6fdb7c8  vmovaps [rsp+0x70], xmm8
0000798fc6fdb7ce  vmovaps [rsp+0x80], xmm9
0000798fc6fdb7d7  vmovaps [rsp+0x90], xmm10
0000798fc6fdb7e0  vmovaps [rsp+0xA0], xmm11
0000798fc6fdb7e9  vmovaps [rsp+0xB0], xmm12
0000798fc6fdb7f2  vmovaps [rsp+0xC0], xmm13
0000798fc6fdb7fb  vmovaps [rsp+0xD0], xmm14
0000798fc6fdb804  vmovaps [rsp+0xE0], xmm15
0000798fc6fdb80d  sub rsp, 0x30
0000798fc6fdb811  movaps [rsp], xmm1
0000798fc6fdb815  movaps [rsp+0x10], xmm8
0000798fc6fdb81b  movaps [rsp+0x20], xmm9
0000798fc6fdb821  lea rdi, [rsp]
0000798fc6fdb825  mov esi, 0x00
0000798fc6fdb82a  mov rax, 0x63E558B23530
0000798fc6fdb834  call rax
0000798fc6fdb836  movaps xmm1, [rsp]
0000798fc6fdb83a  add rsp, 0x30
0000798fc6fdb83e  vmovaps xmm0, [rsp]
0000798fc6fdb843  vmovaps xmm2, [rsp+0x10]
0000798fc6fdb849  vmovaps xmm3, [rsp+0x20]
0000798fc6fdb84f  vmovaps xmm4, [rsp+0x30]
0000798fc6fdb855  vmovaps xmm5, [rsp+0x40]
0000798fc6fdb85b  vmovaps xmm6, [rsp+0x50]
0000798fc6fdb861  vmovaps xmm7, [rsp+0x60]
0000798fc6fdb867  vmovaps xmm8, [rsp+0x70]
0000798fc6fdb86d  vmovaps xmm9, [rsp+0x80]
0000798fc6fdb876  vmovaps xmm10, [rsp+0x90]
0000798fc6fdb87f  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdb888  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdb891  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdb89a  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdb8a3  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdb8ac  add rsp, 0xF0
0000798fc6fdb8b3  pop r11
0000798fc6fdb8b5  pop r10
0000798fc6fdb8b7  pop r9
0000798fc6fdb8b9  pop r8
0000798fc6fdb8bb  pop rsi
0000798fc6fdb8bc  pop rdi
0000798fc6fdb8bd  pop rdx
0000798fc6fdb8be  pop rcx
0000798fc6fdb8bf  pop rax
0000798fc6fdb8c0  add rsp, 0x08
0000798fc6fdb8c4  jmp 0x0000798FC6FD66B2
0000798fc6fdb8c9  call 0x0000798FC6EB3E40
0000798fc6fdb8ce  jmp 0x0000798FC6FD66C0
0000798fc6fdb8d3  call 0x0000798FC6E0C380
0000798fc6fdb8d8  jmp 0x0000798FC6FD66CA
0000798fc6fdb8dd  call 0x0000798FC6E0D600
0000798fc6fdb8e2  jmp 0x0000798FC6FD66D4
0000798fc6fdb8e7  call 0x0000798FC6DFF540
0000798fc6fdb8ec  jmp 0x0000798FC6FD66DE
0000798fc6fdb8f1  int3
0000798fc6fdb8f2  nop [rax+rax*1], ax
0000798fc6fdb8fb  nop [rax+rax*1], eax
0000798fc6fdb900  mov eax, [r15+0x48]
0000798fc6fdb904  lea r14d, [eax+0x01]
0000798fc6fdb909  mov [rsp+0x10], r14d
0000798fc6fdb90e  mov r14d, r14d
0000798fc6fdb911  mov [r15+0x48], r14
0000798fc6fdb915  xor eax, eax
0000798fc6fdb917  mov r14d, [rsp+0x10]
0000798fc6fdb91c  cmp r14d, 0x1F4
0000798fc6fdb923  cmc
0000798fc6fdb924  lahf
0000798fc6fdb925  seto al
0000798fc6fdb928  mov [r15+0x108], eax
0000798fc6fdb92f  mov eax, [r15+0x108]
0000798fc6fdb936  sahf
0000798fc6fdb937  jnz 0x0000798FC6FDB969
0000798fc6fdb939  cmp dword ptr [r15+0x318], 0x00
0000798fc6fdb941  jz 0x0000798FC6FE1AB0
0000798fc6fdb947  nop [rax+rax*1], ax
0000798fc6fdb950  nop [rax+rax*1], eax
0000798fc6fdb958  mov eax, 0x410450
0000798fc6fdb95d  mov [r15+0x100], rax
0000798fc6fdb964  jmp 0x0000798FC6DFE110
0000798fc6fdb969  cmp dword ptr [r15+0x318], 0x00
0000798fc6fdb971  jz 0x0000798FC6FDB9A0
0000798fc6fdb977  nop [rax+rax*1], ax
0000798fc6fdb980  nop [rax+rax*1], eax
0000798fc6fdb988  mov eax, 0x410274
0000798fc6fdb98d  mov [r15+0x100], rax
0000798fc6fdb994  jmp 0x0000798FC6DFE110
0000798fc6fdb999  int3
0000798fc6fdb99a  int3
0000798fc6fdb99b  nop [rax+rax*1], eax
0000798fc6fdb9a0  mov rax, [r15+0x40]
0000798fc6fdb9a4  movaps xmm1, [r15+0x1D0]
0000798fc6fdb9ac  vmovaps [rsp+0x10], xmm1
0000798fc6fdb9b2  vmovaps xmm15, [rsp+0x10]
0000798fc6fdb9b8  por xmm1, xmm15
0000798fc6fdb9bd  movaps xmm14, [r15+0x1A0]
0000798fc6fdb9c5  vmovaps [rsp+0x10], xmm14
0000798fc6fdb9cb  vmovaps xmm13, [rsp+0x10]
0000798fc6fdb9d1  por xmm14, xmm13
0000798fc6fdb9d6  lea r14, [rax+0x30]
0000798fc6fdb9da  mov r12, [r13+r14*1]
0000798fc6fdb9df  lea r14, [rax+0x38]
0000798fc6fdb9e3  mov r11, [r13+r14*1]
0000798fc6fdb9e8  movq xmm13, r12
0000798fc6fdb9ed  movq xmm12, r11
0000798fc6fdb9f2  movq xmm13, xmm13
0000798fc6fdb9f7  vmovaps [rsp+0x10], xmm13
0000798fc6fdb9fd  movq xmm13, xmm13
0000798fc6fdba02  movaps [r15+0x130], xmm13
0000798fc6fdba0a  movq xmm12, xmm12
0000798fc6fdba0f  vmovaps [rsp+0x20], xmm12
0000798fc6fdba15  movq xmm12, xmm12
0000798fc6fdba1a  movaps [r15+0x280], xmm12
0000798fc6fdba22  movaps xmm13, [r15+0x270]
0000798fc6fdba2a  vmovaps [rsp+0x30], xmm13
0000798fc6fdba30  vmovaps xmm12, [rsp+0x30]
0000798fc6fdba36  por xmm13, xmm12
0000798fc6fdba3b  lea r14, [rax+0x20]
0000798fc6fdba3f  mov r12, [r13+r14*1]
0000798fc6fdba44  lea r14, [rax+0x28]
0000798fc6fdba48  mov r11, [r13+r14*1]
0000798fc6fdba4d  movq xmm12, r12
0000798fc6fdba52  movq xmm11, r11
0000798fc6fdba57  movq xmm12, xmm12
0000798fc6fdba5c  vmovaps [rsp+0x30], xmm12
0000798fc6fdba62  movq xmm12, xmm12
0000798fc6fdba67  movaps [r15+0x150], xmm12
0000798fc6fdba6f  movq xmm11, xmm11
0000798fc6fdba74  vmovaps [rsp+0x40], xmm11
0000798fc6fdba7a  movq xmm11, xmm11
0000798fc6fdba7f  movaps [r15+0x140], xmm11
0000798fc6fdba87  lea r14, [rax+0x10]
0000798fc6fdba8b  mov r12, [r13+r14*1]
0000798fc6fdba90  lea r14, [rax+0x18]
0000798fc6fdba94  mov r11, [r13+r14*1]
0000798fc6fdba99  movq xmm12, r12
0000798fc6fdba9e  movq xmm11, r11
0000798fc6fdbaa3  movq xmm12, xmm12
0000798fc6fdbaa8  vmovaps [rsp+0x50], xmm12
0000798fc6fdbaae  movq xmm12, xmm12
0000798fc6fdbab3  movaps [r15+0x170], xmm12
0000798fc6fdbabb  movq xmm11, xmm11
0000798fc6fdbac0  vmovaps [rsp+0x60], xmm11
0000798fc6fdbac6  movq xmm11, xmm11
0000798fc6fdbacb  movaps [r15+0x160], xmm11
0000798fc6fdbad3  mov r14, [r13+rax*1]
0000798fc6fdbad8  vmovq xmm12, r14
0000798fc6fdbadd  vpbroadcastq xmm12, xmm12
0000798fc6fdbae2  lea r14, [rax+0x08]
0000798fc6fdbae6  mov rax, [r13+r14*1]
0000798fc6fdbaeb  movq xmm11, rax
0000798fc6fdbaf0  movaps [r15+0x230], xmm11
0000798fc6fdbaf8  mov rax, [r15+0xF8]
0000798fc6fdbaff  lea r14, [rax+0x50]
0000798fc6fdbb03  movups xmm11, [r13+r14*1]
0000798fc6fdbb09  lea r14, [rax+0x60]
0000798fc6fdbb0d  movups xmm10, [r13+r14*1]
0000798fc6fdbb13  lea r14, [rax+0x30]
0000798fc6fdbb17  movups xmm9, [r13+r14*1]
0000798fc6fdbb1d  mov r14, [r15+0x50]
0000798fc6fdbb21  mov [r15+0x60], r14
0000798fc6fdbb25  mov qword ptr [r15+0x58], 0x40
0000798fc6fdbb2d  movaps xmm8, xmm12
0000798fc6fdbb31  mulpd xmm8, xmm15
0000798fc6fdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000798fc6fdbb3c  ptest xmm7, xmm7
0000798fc6fdbb41  jnz 0x0000798FC6FDC96A
0000798fc6fdbb47  movq xmm15, qword ptr [r15+0x230]
0000798fc6fdbb50  vmovaps [rsp+0x70], xmm15
0000798fc6fdbb56  vpermilpd xmm15, xmm15, 0x00
0000798fc6fdbb5c  movaps xmm7, xmm9
0000798fc6fdbb60  mulpd xmm7, xmm15
0000798fc6fdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000798fc6fdbb6a  ptest xmm6, xmm6
0000798fc6fdbb6f  jnz 0x0000798FC6FDCAAE
0000798fc6fdbb75  vxorps xmm15, xmm15, xmm15
0000798fc6fdbb7a  vpbroadcastq xmm15, xmm15
0000798fc6fdbb7f  movaps xmm9, xmm12
0000798fc6fdbb83  mulpd xmm9, xmm10
0000798fc6fdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000798fc6fdbb8e  ptest xmm6, xmm6
0000798fc6fdbb93  jnz 0x0000798FC6FDCBF0
0000798fc6fdbb99  movaps xmm10, xmm12
0000798fc6fdbb9d  mulpd xmm10, xmm11
0000798fc6fdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000798fc6fdbba8  ptest xmm6, xmm6
0000798fc6fdbbad  jnz 0x0000798FC6FDCD34
0000798fc6fdbbb3  movaps xmm11, [r15+0x1F0]
0000798fc6fdbbbb  movaps xmm6, xmm12
0000798fc6fdbbbf  mulpd xmm6, xmm11
0000798fc6fdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000798fc6fdbbc9  ptest xmm5, xmm5
0000798fc6fdbbce  jnz 0x0000798FC6FDCE78
0000798fc6fdbbd4  movaps xmm12, [r15+0x2A0]
0000798fc6fdbbdc  vmovaps [rsp+0x80], xmm12
0000798fc6fdbbe5  vmovaps xmm11, [rsp+0x80]
0000798fc6fdbbee  por xmm12, xmm11
0000798fc6fdbbf3  movaps xmm11, [r15+0x250]
0000798fc6fdbbfb  vmovaps [rsp+0x80], xmm11
0000798fc6fdbc04  vmovaps xmm5, [rsp+0x80]
0000798fc6fdbc0d  por xmm11, xmm5
0000798fc6fdbc12  vmovaps xmm4, [rsp+0x70]
0000798fc6fdbc18  vpermilpd xmm4, xmm4, 0x00
0000798fc6fdbc1e  movaps xmm3, xmm5
0000798fc6fdbc21  mulpd xmm3, xmm4
0000798fc6fdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000798fc6fdbc2a  ptest xmm2, xmm2
0000798fc6fdbc2f  jnz 0x0000798FC6FDCFBA
0000798fc6fdbc35  mov [rsp+0x80], rax
0000798fc6fdbc3d  xor eax, eax
0000798fc6fdbc3f  mov r12d, 0x40
0000798fc6fdbc45  mov r11d, 0x200
0000798fc6fdbc4b  cmp r12, r11
0000798fc6fdbc4e  cmc
0000798fc6fdbc4f  lahf
0000798fc6fdbc50  seto al
0000798fc6fdbc53  mov [r15+0x108], eax
0000798fc6fdbc5a  movaps xmm5, xmm8
0000798fc6fdbc5e  addpd xmm5, xmm15
0000798fc6fdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000798fc6fdbc68  ptest xmm4, xmm4
0000798fc6fdbc6d  jnz 0x0000798FC6FDD0FA
0000798fc6fdbc73  movaps xmm8, [r15+0x1B0]
0000798fc6fdbc7b  movaps xmm4, xmm9
0000798fc6fdbc7f  addpd xmm4, xmm8
0000798fc6fdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000798fc6fdbc89  ptest xmm2, xmm2
0000798fc6fdbc8e  jnz 0x0000798FC6FDD23C
0000798fc6fdbc94  movaps xmm9, xmm10
0000798fc6fdbc98  addpd xmm9, xmm8
0000798fc6fdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000798fc6fdbca3  ptest xmm2, xmm2
0000798fc6fdbca8  jnz 0x0000798FC6FDD37E
0000798fc6fdbcae  movaps xmm10, [r15+0x2F0]
0000798fc6fdbcb6  vmovaps [rsp+0x90], xmm10
0000798fc6fdbcbf  vmovaps xmm8, [rsp+0x90]
0000798fc6fdbcc8  por xmm10, xmm8
0000798fc6fdbccd  movaps xmm8, [r15+0x2E0]
0000798fc6fdbcd5  vmovaps [rsp+0x90], xmm8
0000798fc6fdbcde  vmovaps xmm2, [rsp+0x90]
0000798fc6fdbce7  por xmm8, xmm2
0000798fc6fdbcec  movaps xmm2, [r15+0x2D0]
0000798fc6fdbcf4  vmovaps [rsp+0x90], xmm2
0000798fc6fdbcfd  vmovaps [rsp+0xA0], xmm1
0000798fc6fdbd06  vmovaps xmm1, [rsp+0x90]
0000798fc6fdbd0f  por xmm2, xmm1
0000798fc6fdbd13  movaps xmm1, [r15+0x200]
0000798fc6fdbd1b  vmovaps [rsp+0x90], xmm1
0000798fc6fdbd24  vmovaps [rsp+0xB0], xmm15
0000798fc6fdbd2d  vmovaps xmm15, [rsp+0x90]
0000798fc6fdbd36  por xmm1, xmm15
0000798fc6fdbd3b  movaps xmm15, [r15+0x1C0]
0000798fc6fdbd43  vmovaps [rsp+0x90], xmm15
0000798fc6fdbd4c  vmovaps [rsp+0xC0], xmm1
0000798fc6fdbd55  vmovaps xmm1, [rsp+0x90]
0000798fc6fdbd5e  por xmm15, xmm1
0000798fc6fdbd63  movaps xmm1, [r15+0x190]
0000798fc6fdbd6b  vmovaps [rsp+0x90], xmm1
0000798fc6fdbd74  vmovaps [rsp+0xD0], xmm15
0000798fc6fdbd7d  vmovaps xmm15, [rsp+0x90]
0000798fc6fdbd86  por xmm1, xmm15
0000798fc6fdbd8b  movaps xmm15, [r15+0x300]
0000798fc6fdbd93  vmovaps [rsp+0x90], xmm15
0000798fc6fdbd9c  vmovaps [rsp+0xE0], xmm1
0000798fc6fdbda5  vmovaps xmm1, [rsp+0x90]
0000798fc6fdbdae  por xmm15, xmm1
0000798fc6fdbdb3  mov rax, [rsp+0x80]
0000798fc6fdbdbb  lea r12, [rax+0xA0]
0000798fc6fdbdc2  movups xmm1, [r13+r12*1]
0000798fc6fdbdc8  lea r12, [rax+0xB0]
0000798fc6fdbdcf  vmovaps [rsp+0x80], xmm1
0000798fc6fdbdd8  movups xmm1, [r13+r12*1]
0000798fc6fdbdde  vmovaps [rsp+0x90], xmm1
0000798fc6fdbde7  vmovaps [rsp+0xF0], xmm15
0000798fc6fdbdf0  vmovaps xmm15, [rsp+0xB0]
0000798fc6fdbdf9  vmovaps [rsp+0xB0], xmm14
0000798fc6fdbe02  movaps xmm1, xmm6
0000798fc6fdbe05  addpd xmm1, xmm15
0000798fc6fdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000798fc6fdbe0f  ptest xmm14, xmm14
0000798fc6fdbe15  jnz 0x0000798FC6FDD4D6
0000798fc6fdbe1b  lea r12, [rax+0xF0]
0000798fc6fdbe22  movups xmm15, [r13+r12*1]
0000798fc6fdbe28  movaps xmm14, xmm4
0000798fc6fdbe2c  addpd xmm14, xmm3
0000798fc6fdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000798fc6fdbe37  ptest xmm6, xmm6
0000798fc6fdbe3c  jnz 0x0000798FC6FDD621
0000798fc6fdbe42  movaps xmm6, xmm9
0000798fc6fdbe46  addpd xmm6, xmm7
0000798fc6fdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000798fc6fdbe4f  ptest xmm4, xmm4
0000798fc6fdbe54  jnz 0x0000798FC6FDD763
0000798fc6fdbe5a  vmovaps xmm9, [rsp+0x70]
0000798fc6fdbe60  vpermilpd xmm9, xmm9, 0x00
0000798fc6fdbe66  vmovaps xmm4, [rsp+0x90]
0000798fc6fdbe6f  movaps xmm7, xmm4
0000798fc6fdbe72  mulpd xmm7, xmm9
0000798fc6fdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000798fc6fdbe7c  ptest xmm3, xmm3
0000798fc6fdbe81  jnz 0x0000798FC6FDD8A4
0000798fc6fdbe87  vmovaps xmm9, [rsp+0x50]
0000798fc6fdbe8d  vpermilpd xmm9, xmm9, 0x00
0000798fc6fdbe93  movaps xmm4, xmm15
0000798fc6fdbe97  mulpd xmm4, xmm9
0000798fc6fdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000798fc6fdbea1  ptest xmm3, xmm3
0000798fc6fdbea6  jnz 0x0000798FC6FDD9E5
0000798fc6fdbeac  lea r12, [rax+0xE0]
0000798fc6fdbeb3  movups xmm15, [r13+r12*1]
0000798fc6fdbeb9  vmovaps xmm9, [rsp+0x70]
0000798fc6fdbebf  vpermilpd xmm9, xmm9, 0x00
0000798fc6fdbec5  vmovaps [rsp+0x70], xmm1
0000798fc6fdbecb  vmovaps xmm1, [rsp+0x80]
0000798fc6fdbed4  vmovaps [rsp+0x80], xmm15
0000798fc6fdbedd  movaps xmm3, xmm1
0000798fc6fdbee0  mulpd xmm3, xmm9
0000798fc6fdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000798fc6fdbeea  ptest xmm15, xmm15
0000798fc6fdbef0  jnz 0x0000798FC6FDDB31
0000798fc6fdbef6  vmovaps xmm1, [rsp+0xF0]
0000798fc6fdbeff  vmovaps xmm15, [rsp+0xF0]
0000798fc6fdbf08  por xmm1, xmm15
0000798fc6fdbf0d  movaps [r15+0x300], xmm1
0000798fc6fdbf15  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdbf1e  vmovaps xmm9, [rsp+0xE0]
0000798fc6fdbf27  por xmm15, xmm9
0000798fc6fdbf2c  movaps [r15+0x190], xmm15
0000798fc6fdbf34  vmovaps xmm9, [rsp+0x50]
0000798fc6fdbf3a  vpermilpd xmm9, xmm9, 0x00
0000798fc6fdbf40  vmovaps [rsp+0x90], xmm1
0000798fc6fdbf49  vmovaps [rsp+0xE0], xmm15
0000798fc6fdbf52  vmovaps xmm15, [rsp+0x80]
0000798fc6fdbf5b  vmovaps [rsp+0x80], xmm14
0000798fc6fdbf64  movaps xmm1, xmm15
0000798fc6fdbf68  mulpd xmm1, xmm9
0000798fc6fdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000798fc6fdbf72  ptest xmm14, xmm14
0000798fc6fdbf78  jnz 0x0000798FC6FDDC72
0000798fc6fdbf7e  lea r12, [rax+0x90]
0000798fc6fdbf85  movups xmm15, [r13+r12*1]
0000798fc6fdbf8b  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdbf94  vmovaps xmm9, [rsp+0xD0]
0000798fc6fdbf9d  por xmm14, xmm9
0000798fc6fdbfa2  movaps [r15+0x1C0], xmm14
0000798fc6fdbfaa  vmovaps xmm9, [rsp+0xC0]
0000798fc6fdbfb3  vmovaps [rsp+0xD0], xmm1
0000798fc6fdbfbc  vmovaps xmm1, [rsp+0xC0]
0000798fc6fdbfc5  por xmm9, xmm1
0000798fc6fdbfca  movaps [r15+0x200], xmm9
0000798fc6fdbfd2  vmovaps [rsp+0xC0], xmm2
0000798fc6fdbfdb  vmovaps xmm1, [rsp+0xC0]
0000798fc6fdbfe4  por xmm2, xmm1
0000798fc6fdbfe8  movaps [r15+0x2D0], xmm2
0000798fc6fdbff0  vmovaps [rsp+0xC0], xmm8
0000798fc6fdbff9  vmovaps xmm1, [rsp+0xC0]
0000798fc6fdc002  por xmm8, xmm1
0000798fc6fdc007  movaps [r15+0x2E0], xmm8
0000798fc6fdc00f  vmovaps [rsp+0xC0], xmm15
0000798fc6fdc018  movaps xmm1, xmm5
0000798fc6fdc01b  addpd xmm1, xmm7
0000798fc6fdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000798fc6fdc024  ptest xmm15, xmm15
0000798fc6fdc02a  jnz 0x0000798FC6FDDDBE
0000798fc6fdc030  vmovaps xmm15, [rsp+0x50]
0000798fc6fdc036  vpermilpd xmm15, xmm15, 0x00
0000798fc6fdc03c  vmovaps xmm5, [rsp+0xC0]
0000798fc6fdc045  vmovaps [rsp+0xC0], xmm1
0000798fc6fdc04e  movaps xmm7, xmm5
0000798fc6fdc051  mulpd xmm7, xmm15
0000798fc6fdc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000798fc6fdc05b  ptest xmm1, xmm1
0000798fc6fdc060  jnz 0x0000798FC6FDDEFE
0000798fc6fdc066  lea r12, [rax+0x80]
0000798fc6fdc06d  movups xmm1, [r13+r12*1]
0000798fc6fdc073  vmovaps xmm5, [rsp+0x70]
0000798fc6fdc079  vmovaps [rsp+0x70], xmm1
0000798fc6fdc07f  movaps xmm15, xmm5
0000798fc6fdc083  addpd xmm15, xmm3
0000798fc6fdc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000798fc6fdc08e  ptest xmm1, xmm1
0000798fc6fdc093  jnz 0x0000798FC6FDE049
0000798fc6fdc099  vmovaps xmm5, [rsp+0x80]
0000798fc6fdc0a2  movaps xmm1, xmm5
0000798fc6fdc0a5  addpd xmm1, xmm4
0000798fc6fdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000798fc6fdc0ae  ptest xmm3, xmm3
0000798fc6fdc0b3  jnz 0x0000798FC6FDE18B
0000798fc6fdc0b9  vmovaps [rsp+0x80], xmm10
0000798fc6fdc0c2  vmovaps xmm5, [rsp+0x80]
0000798fc6fdc0cb  por xmm10, xmm5
0000798fc6fdc0d0  movaps [r15+0x2F0], xmm10
0000798fc6fdc0d8  vmovaps xmm5, [rsp+0x50]
0000798fc6fdc0de  vpermilpd xmm5, xmm5, 0x00
0000798fc6fdc0e4  vmovaps xmm3, [rsp+0x70]
0000798fc6fdc0ea  vmovaps [rsp+0x50], xmm1
0000798fc6fdc0f0  movaps xmm4, xmm3
0000798fc6fdc0f3  mulpd xmm4, xmm5
0000798fc6fdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000798fc6fdc0fc  ptest xmm1, xmm1
0000798fc6fdc101  jnz 0x0000798FC6FDE2CB
0000798fc6fdc107  lea r12, [rax+0xD0]
0000798fc6fdc10e  movups xmm1, [r13+r12*1]
0000798fc6fdc114  vmovaps xmm3, [rsp+0xD0]
0000798fc6fdc11d  vmovaps [rsp+0x70], xmm1
0000798fc6fdc123  movaps xmm5, xmm6
0000798fc6fdc126  addpd xmm5, xmm3
0000798fc6fdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000798fc6fdc12f  ptest xmm1, xmm1
0000798fc6fdc134  jnz 0x0000798FC6FDE415
0000798fc6fdc13a  vmovaps xmm1, [rsp+0x60]
0000798fc6fdc140  vpermilpd xmm1, xmm1, 0x00
0000798fc6fdc146  movaps xmm6, xmm9
0000798fc6fdc14a  mulpd xmm6, xmm1
0000798fc6fdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000798fc6fdc153  ptest xmm3, xmm3
0000798fc6fdc158  jnz 0x0000798FC6FDE555
0000798fc6fdc15e  movaps [r15+0x260], xmm6
0000798fc6fdc166  vxorps xmm1, xmm1, xmm1
0000798fc6fdc16a  vpbroadcastq xmm1, xmm1
0000798fc6fdc16f  movaps [r15+0x1B0], xmm1
0000798fc6fdc177  vmovaps xmm1, [rsp+0x60]
0000798fc6fdc17d  vpermilpd xmm1, xmm1, 0x00
0000798fc6fdc183  vmovaps xmm3, [rsp+0x70]
0000798fc6fdc189  vmovaps [rsp+0x70], xmm15
0000798fc6fdc18f  movaps xmm9, xmm3
0000798fc6fdc193  mulpd xmm9, xmm1
0000798fc6fdc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000798fc6fdc19e  ptest xmm15, xmm15
0000798fc6fdc1a4  jnz 0x0000798FC6FDE696
0000798fc6fdc1aa  lea r12, [rax+0xC0]
0000798fc6fdc1b1  movups xmm1, [r13+r12*1]
0000798fc6fdc1b7  vmovaps xmm3, [rsp+0xC0]
0000798fc6fdc1c0  vmovaps [rsp+0x80], xmm1
0000798fc6fdc1c9  movaps xmm15, xmm3
0000798fc6fdc1cd  addpd xmm15, xmm7
0000798fc6fdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000798fc6fdc1d8  ptest xmm1, xmm1
0000798fc6fdc1dd  jnz 0x0000798FC6FDE7E2
0000798fc6fdc1e3  vmovaps [rsp+0xC0], xmm13
0000798fc6fdc1ec  vmovaps xmm1, [rsp+0xC0]
0000798fc6fdc1f5  por xmm13, xmm1
0000798fc6fdc1fa  movaps [r15+0x270], xmm13
0000798fc6fdc202  vmovaps xmm1, [rsp+0xB0]
0000798fc6fdc20b  vmovaps xmm7, [rsp+0xB0]
0000798fc6fdc214  por xmm1, xmm7
0000798fc6fdc218  movaps [r15+0x1A0], xmm1
0000798fc6fdc220  vmovaps xmm1, [rsp+0x60]
0000798fc6fdc226  vpermilpd xmm1, xmm1, 0x00
0000798fc6fdc22c  vmovaps [rsp+0xB0], xmm1
0000798fc6fdc235  vmovaps xmm1, [rsp+0x80]
0000798fc6fdc23e  vmovaps [rsp+0x80], xmm15
0000798fc6fdc247  vmovaps xmm15, [rsp+0xB0]
0000798fc6fdc250  vmovaps [rsp+0xB0], xmm14
0000798fc6fdc259  movaps xmm3, xmm1
0000798fc6fdc25c  mulpd xmm3, xmm15
0000798fc6fdc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000798fc6fdc266  ptest xmm14, xmm14
0000798fc6fdc26c  jnz 0x0000798FC6FDE924
0000798fc6fdc272  lea r12, [rax+0x20]
0000798fc6fdc276  movups xmm1, [r13+r12*1]
0000798fc6fdc27c  movaps [r15+0x110], xmm1
0000798fc6fdc284  vmovaps xmm14, [rsp+0x70]
0000798fc6fdc28a  vmovaps [rsp+0x70], xmm1
0000798fc6fdc290  movaps xmm15, xmm14
0000798fc6fdc294  addpd xmm15, xmm4
0000798fc6fdc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000798fc6fdc29f  ptest xmm1, xmm1
0000798fc6fdc2a4  jnz 0x0000798FC6FDEA6F
0000798fc6fdc2aa  vmovaps xmm1, [rsp+0x60]
0000798fc6fdc2b0  vpermilpd xmm1, xmm1, 0x00
0000798fc6fdc2b6  movaps xmm14, xmm2
0000798fc6fdc2ba  mulpd xmm14, xmm1
0000798fc6fdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000798fc6fdc2c5  ptest xmm4, xmm4
0000798fc6fdc2ca  jnz 0x0000798FC6FDEBB2
0000798fc6fdc2d0  vmovaps xmm4, [rsp+0x50]
0000798fc6fdc2d6  movaps xmm1, xmm4
0000798fc6fdc2d9  addpd xmm1, xmm9
0000798fc6fdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000798fc6fdc2e3  ptest xmm2, xmm2
0000798fc6fdc2e8  jnz 0x0000798FC6FDECF4
0000798fc6fdc2ee  vmovaps xmm9, [rsp+0x30]
0000798fc6fdc2f4  vpermilpd xmm9, xmm9, 0x00
0000798fc6fdc2fa  vmovaps xmm2, [rsp+0x70]
0000798fc6fdc300  vmovaps [rsp+0x50], xmm1
0000798fc6fdc306  movaps xmm4, xmm2
0000798fc6fdc309  mulpd xmm4, xmm9
0000798fc6fdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000798fc6fdc313  ptest xmm1, xmm1
0000798fc6fdc318  jnz 0x0000798FC6FDEE35
0000798fc6fdc31e  vmovaps xmm1, [rsp+0x30]
0000798fc6fdc324  vpermilpd xmm1, xmm1, 0x00
0000798fc6fdc32a  vmovaps xmm2, [rsp+0x90]
0000798fc6fdc333  vmovaps [rsp+0x60], xmm15
0000798fc6fdc339  movaps xmm9, xmm2
0000798fc6fdc33d  mulpd xmm9, xmm1
0000798fc6fdc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000798fc6fdc348  ptest xmm15, xmm15
0000798fc6fdc34e  jnz 0x0000798FC6FDEF76
0000798fc6fdc354  vmovaps xmm15, [rsp+0x80]
0000798fc6fdc35d  movaps xmm1, xmm15
0000798fc6fdc361  addpd xmm1, xmm6
0000798fc6fdc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000798fc6fdc36a  ptest xmm2, xmm2
0000798fc6fdc36f  jnz 0x0000798FC6FDF0B8
0000798fc6fdc375  movaps xmm15, xmm5
0000798fc6fdc379  addpd xmm15, xmm3
0000798fc6fdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000798fc6fdc384  ptest xmm6, xmm6
0000798fc6fdc389  jnz 0x0000798FC6FDF1F9
0000798fc6fdc38f  vmovaps xmm6, [rsp+0x30]
0000798fc6fdc395  vpermilpd xmm6, xmm6, 0x00
0000798fc6fdc39b  movaps xmm5, xmm8
0000798fc6fdc39f  mulpd xmm5, xmm6
0000798fc6fdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000798fc6fdc3a8  ptest xmm3, xmm3
0000798fc6fdc3ad  jnz 0x0000798FC6FDF33B
0000798fc6fdc3b3  vmovaps xmm8, [rsp+0x30]
0000798fc6fdc3b9  vpermilpd xmm8, xmm8, 0x00
0000798fc6fdc3bf  movaps xmm6, xmm10
0000798fc6fdc3c3  mulpd xmm6, xmm8
0000798fc6fdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000798fc6fdc3cd  ptest xmm3, xmm3
0000798fc6fdc3d2  jnz 0x0000798FC6FDF47C
0000798fc6fdc3d8  vmovaps xmm8, [rsp+0x60]
0000798fc6fdc3de  movaps xmm10, xmm8
0000798fc6fdc3e2  addpd xmm10, xmm14
0000798fc6fdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000798fc6fdc3ed  ptest xmm3, xmm3
0000798fc6fdc3f2  jnz 0x0000798FC6FDF5BE
0000798fc6fdc3f8  vmovaps xmm8, [rsp+0x50]
0000798fc6fdc3fe  movaps xmm14, xmm8
0000798fc6fdc402  addpd xmm14, xmm4
0000798fc6fdc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000798fc6fdc40d  ptest xmm3, xmm3
0000798fc6fdc412  jnz 0x0000798FC6FDF702
0000798fc6fdc418  vmovaps xmm8, [rsp+0x40]
0000798fc6fdc41e  vpermilpd xmm8, xmm8, 0x00
0000798fc6fdc424  movaps xmm4, xmm13
0000798fc6fdc428  mulpd xmm4, xmm8
0000798fc6fdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000798fc6fdc432  ptest xmm3, xmm3
0000798fc6fdc437  jnz 0x0000798FC6FDF845
0000798fc6fdc43d  movaps xmm13, xmm15
0000798fc6fdc441  addpd xmm13, xmm9
0000798fc6fdc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000798fc6fdc44c  ptest xmm8, xmm8
0000798fc6fdc452  jnz 0x0000798FC6FDF987
0000798fc6fdc458  movaps xmm15, xmm1
0000798fc6fdc45c  addpd xmm15, xmm5
0000798fc6fdc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000798fc6fdc467  ptest xmm9, xmm9
0000798fc6fdc46d  jnz 0x0000798FC6FDFACB
0000798fc6fdc473  vmovaps [rsp+0x30], xmm11
0000798fc6fdc479  vmovaps xmm1, [rsp+0x30]
0000798fc6fdc47f  por xmm11, xmm1
0000798fc6fdc484  movaps [r15+0x250], xmm11
0000798fc6fdc48c  vmovaps [rsp+0x30], xmm12
0000798fc6fdc492  vmovaps xmm1, [rsp+0x30]
0000798fc6fdc498  por xmm12, xmm1
0000798fc6fdc49d  movaps [r15+0x2A0], xmm12
0000798fc6fdc4a5  vmovaps xmm1, [rsp+0xA0]
0000798fc6fdc4ae  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdc4b7  por xmm1, xmm11
0000798fc6fdc4bc  movaps [r15+0x1D0], xmm1
0000798fc6fdc4c4  lea r12, [rax+0x40]
0000798fc6fdc4c8  movups xmm1, [r13+r12*1]
0000798fc6fdc4ce  movaps [r15+0x2C0], xmm1
0000798fc6fdc4d6  vmovaps xmm11, [rsp+0x40]
0000798fc6fdc4dc  vpermilpd xmm11, xmm11, 0x00
0000798fc6fdc4e2  vmovaps xmm8, [rsp+0xE0]
0000798fc6fdc4eb  movaps xmm9, xmm8
0000798fc6fdc4ef  mulpd xmm9, xmm11
0000798fc6fdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000798fc6fdc4fa  ptest xmm5, xmm5
0000798fc6fdc4ff  jnz 0x0000798FC6FDFC17
0000798fc6fdc505  movaps xmm11, xmm10
0000798fc6fdc509  addpd xmm11, xmm6
0000798fc6fdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000798fc6fdc514  ptest xmm8, xmm8
0000798fc6fdc51a  jnz 0x0000798FC6FDFD5B
0000798fc6fdc520  movaps xmm10, xmm14
0000798fc6fdc524  addpd xmm10, xmm4
0000798fc6fdc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000798fc6fdc52f  ptest xmm8, xmm8
0000798fc6fdc535  jnz 0x0000798FC6FDFE9E
0000798fc6fdc53b  vmovaps xmm14, [rsp+0x40]
0000798fc6fdc541  vpermilpd xmm14, xmm14, 0x00
0000798fc6fdc547  movaps xmm8, xmm1
0000798fc6fdc54b  mulpd xmm8, xmm14
0000798fc6fdc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000798fc6fdc556  ptest xmm6, xmm6
0000798fc6fdc55b  jnz 0x0000798FC6FDFFE1
0000798fc6fdc561  movaps xmm1, [r15+0x2B0]
0000798fc6fdc569  vmovaps xmm14, [rsp+0x40]
0000798fc6fdc56f  vpermilpd xmm14, xmm14, 0x00
0000798fc6fdc575  movaps xmm6, xmm1
0000798fc6fdc578  mulpd xmm6, xmm14
0000798fc6fdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000798fc6fdc582  ptest xmm5, xmm5
0000798fc6fdc587  jnz 0x0000798FC6FE0124
0000798fc6fdc58d  vmovaps xmm1, [rsp+0x10]
0000798fc6fdc593  vpermilpd xmm1, xmm1, 0x00
0000798fc6fdc599  movaps xmm14, xmm12
0000798fc6fdc59d  mulpd xmm14, xmm1
0000798fc6fdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000798fc6fdc5a8  ptest xmm5, xmm5
0000798fc6fdc5ad  jnz 0x0000798FC6FE0265
0000798fc6fdc5b3  movaps xmm1, xmm13
0000798fc6fdc5b7  addpd xmm1, xmm9
0000798fc6fdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000798fc6fdc5c1  ptest xmm12, xmm12
0000798fc6fdc5c7  jnz 0x0000798FC6FE03A8
0000798fc6fdc5cd  vmovaps xmm13, [rsp+0x10]
0000798fc6fdc5d3  vpermilpd xmm13, xmm13, 0x00
0000798fc6fdc5d9  movaps xmm12, xmm7
0000798fc6fdc5dd  mulpd xmm12, xmm13
0000798fc6fdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000798fc6fdc5e8  ptest xmm9, xmm9
0000798fc6fdc5ee  jnz 0x0000798FC6FE04EA
0000798fc6fdc5f4  movaps xmm13, xmm15
0000798fc6fdc5f8  addpd xmm13, xmm8
0000798fc6fdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000798fc6fdc603  ptest xmm9, xmm9
0000798fc6fdc609  jnz 0x0000798FC6FE062D
0000798fc6fdc60f  movaps xmm15, [r15+0x290]
0000798fc6fdc617  vmovaps xmm9, [rsp+0x10]
0000798fc6fdc61d  vpermilpd xmm9, xmm9, 0x00
0000798fc6fdc623  movaps xmm8, xmm15
0000798fc6fdc627  mulpd xmm8, xmm9
0000798fc6fdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000798fc6fdc632  ptest xmm7, xmm7
0000798fc6fdc637  jnz 0x0000798FC6FE0771
0000798fc6fdc63d  movaps xmm15, xmm11
0000798fc6fdc641  addpd xmm15, xmm6
0000798fc6fdc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000798fc6fdc64c  ptest xmm9, xmm9
0000798fc6fdc652  jnz 0x0000798FC6FE08B5
0000798fc6fdc658  movaps xmm11, [r15+0x1E0]
0000798fc6fdc660  vmovaps xmm9, [rsp+0x10]
0000798fc6fdc666  vpermilpd xmm9, xmm9, 0x00
0000798fc6fdc66c  movaps xmm7, xmm11
0000798fc6fdc670  mulpd xmm7, xmm9
0000798fc6fdc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000798fc6fdc67a  ptest xmm6, xmm6
0000798fc6fdc67f  jnz 0x0000798FC6FE09F8
0000798fc6fdc685  movaps xmm11, xmm10
0000798fc6fdc689  addpd xmm11, xmm14
0000798fc6fdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000798fc6fdc694  ptest xmm9, xmm9
0000798fc6fdc69a  jnz 0x0000798FC6FE0B3A
0000798fc6fdc6a0  lea r12, [rax+0x70]
0000798fc6fdc6a4  movups xmm14, [r13+r12*1]
0000798fc6fdc6aa  movaps [r15+0x240], xmm14
0000798fc6fdc6b2  movaps xmm10, xmm1
0000798fc6fdc6b6  addpd xmm10, xmm12
0000798fc6fdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000798fc6fdc6c1  ptest xmm9, xmm9
0000798fc6fdc6c7  jnz 0x0000798FC6FE0C88
0000798fc6fdc6cd  movaps [r15+0x170], xmm10
0000798fc6fdc6d5  vmovaps xmm1, [rsp+0x20]
0000798fc6fdc6db  vpermilpd xmm1, xmm1, 0x00
0000798fc6fdc6e1  movaps xmm12, xmm14
0000798fc6fdc6e5  mulpd xmm12, xmm1
0000798fc6fdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000798fc6fdc6f0  ptest xmm9, xmm9
0000798fc6fdc6f6  jnz 0x0000798FC6FE0DCB
0000798fc6fdc6fc  vmovaps xmm1, [rsp+0x20]
0000798fc6fdc702  vpermilpd xmm1, xmm1, 0x00
0000798fc6fdc708  vmovaps xmm9, [rsp+0xB0]
0000798fc6fdc711  movaps xmm14, xmm9
0000798fc6fdc715  mulpd xmm14, xmm1
0000798fc6fdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000798fc6fdc720  ptest xmm6, xmm6
0000798fc6fdc725  jnz 0x0000798FC6FE0F0E
0000798fc6fdc72b  movaps [r15+0x180], xmm14
0000798fc6fdc733  movaps xmm1, xmm13
0000798fc6fdc737  addpd xmm1, xmm8
0000798fc6fdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000798fc6fdc741  ptest xmm9, xmm9
0000798fc6fdc747  jnz 0x0000798FC6FE1051
0000798fc6fdc74d  movaps [r15+0x210], xmm1
0000798fc6fdc755  movups xmm13, [r13+rax*1]
0000798fc6fdc75b  lea r12, [rax+0x10]
0000798fc6fdc75f  movups xmm9, [r13+r12*1]
0000798fc6fdc765  movaps [r15+0x230], xmm9
0000798fc6fdc76d  movaps xmm8, xmm15
0000798fc6fdc771  addpd xmm8, xmm7
0000798fc6fdc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000798fc6fdc77c  ptest xmm6, xmm6
0000798fc6fdc781  jnz 0x0000798FC6FE11A7
0000798fc6fdc787  movaps [r15+0x130], xmm8
0000798fc6fdc78f  vmovaps xmm15, [rsp+0x20]
0000798fc6fdc795  vpermilpd xmm15, xmm15, 0x00
0000798fc6fdc79b  movaps xmm7, xmm9
0000798fc6fdc79f  mulpd xmm7, xmm15
0000798fc6fdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000798fc6fdc7a9  ptest xmm6, xmm6
0000798fc6fdc7ae  jnz 0x0000798FC6FE12EA
0000798fc6fdc7b4  movaps [r15+0x220], xmm7
0000798fc6fdc7bc  vmovaps xmm15, [rsp+0x20]
0000798fc6fdc7c2  vpermilpd xmm15, xmm15, 0x00
0000798fc6fdc7c8  movaps xmm9, xmm13
0000798fc6fdc7cc  mulpd xmm9, xmm15
0000798fc6fdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000798fc6fdc7d7  ptest xmm6, xmm6
0000798fc6fdc7dc  jnz 0x0000798FC6FE142C
0000798fc6fdc7e2  movaps xmm15, xmm11
0000798fc6fdc7e6  addpd xmm15, xmm12
0000798fc6fdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000798fc6fdc7f1  ptest xmm13, xmm13
0000798fc6fdc7f7  jnz 0x0000798FC6FE1570
0000798fc6fdc7fd  movaps [r15+0x140], xmm15
0000798fc6fdc805  movaps xmm13, xmm10
0000798fc6fdc809  addpd xmm13, xmm14
0000798fc6fdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000798fc6fdc814  ptest xmm12, xmm12
0000798fc6fdc81a  jnz 0x0000798FC6FE16B4
0000798fc6fdc820  movaps [r15+0x150], xmm13
0000798fc6fdc828  movaps xmm14, xmm1
0000798fc6fdc82c  addpd xmm14, xmm7
0000798fc6fdc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000798fc6fdc837  ptest xmm12, xmm12
0000798fc6fdc83d  jnz 0x0000798FC6FE17F8
0000798fc6fdc843  movaps [r15+0x160], xmm14
0000798fc6fdc84b  movaps xmm1, xmm8
0000798fc6fdc84f  addpd xmm1, xmm9
0000798fc6fdc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000798fc6fdc859  ptest xmm12, xmm12
0000798fc6fdc85f  jnz 0x0000798FC6FE193A
0000798fc6fdc865  movaps [r15+0x120], xmm1
0000798fc6fdc86d  movups [r13+r14*1], xmm15
0000798fc6fdc873  lea rax, [r14+0x10]
0000798fc6fdc877  movups [r13+rax*1], xmm13
0000798fc6fdc87d  lea rax, [r14+0x20]
0000798fc6fdc881  movups [r13+rax*1], xmm14
0000798fc6fdc887  lea rax, [r14+0x30]
0000798fc6fdc88b  movups [r13+rax*1], xmm1
0000798fc6fdc891  mov eax, [r15+0x108]
0000798fc6fdc898  sahf
0000798fc6fdc899  jnz 0x0000798FC6FDC8CB
0000798fc6fdc89b  cmp dword ptr [r15+0x318], 0x00
0000798fc6fdc8a3  jz 0x0000798FC6FDB900
0000798fc6fdc8a9  nop [rax+rax*1], ax
0000798fc6fdc8b2  nop [rax+rax*1], eax
0000798fc6fdc8ba  mov eax, 0x410444
0000798fc6fdc8bf  mov [r15+0x100], rax
0000798fc6fdc8c6  jmp 0x0000798FC6DFE110
0000798fc6fdc8cb  cmp dword ptr [r15+0x318], 0x00
0000798fc6fdc8d3  jz 0x0000798FC6FD57E0
0000798fc6fdc8d9  nop [rax+rax*1], ax
0000798fc6fdc8e2  nop [rax+rax*1], eax
0000798fc6fdc8ea  mov eax, 0x410278
0000798fc6fdc8ef  mov [r15+0x100], rax
0000798fc6fdc8f6  jmp 0x0000798FC6DFE110
0000798fc6fdc8fb  int3
0000798fc6fdc8fc  call 0x0000798FC6EE27E0
0000798fc6fdc901  jmp 0x0000798FC6FDB9DF
0000798fc6fdc906  call 0x0000798FC6EE1570
0000798fc6fdc90b  jmp 0x0000798FC6FDB9E8
0000798fc6fdc910  call 0x0000798FC6EE27E0
0000798fc6fdc915  jmp 0x0000798FC6FDBA44
0000798fc6fdc91a  call 0x0000798FC6EE1570
0000798fc6fdc91f  jmp 0x0000798FC6FDBA4D
0000798fc6fdc924  call 0x0000798FC6EE27E0
0000798fc6fdc929  jmp 0x0000798FC6FDBA90
0000798fc6fdc92e  call 0x0000798FC6EE1570
0000798fc6fdc933  jmp 0x0000798FC6FDBA99
0000798fc6fdc938  call 0x0000798FC6E0DC20
0000798fc6fdc93d  jmp 0x0000798FC6FDBAD8
0000798fc6fdc942  call 0x0000798FC6ED59C0
0000798fc6fdc947  jmp 0x0000798FC6FDBAEB
0000798fc6fdc94c  call 0x0000798FC6EE0E30
0000798fc6fdc951  jmp 0x0000798FC6FDBB09
0000798fc6fdc956  call 0x0000798FC6EDFBC0
0000798fc6fdc95b  jmp 0x0000798FC6FDBB13
0000798fc6fdc960  call 0x0000798FC6EDE950
0000798fc6fdc965  jmp 0x0000798FC6FDBB1D
0000798fc6fdc96a  sub rsp, 0x08
0000798fc6fdc96e  push rax
0000798fc6fdc96f  push rcx
0000798fc6fdc970  push rdx
0000798fc6fdc971  push rdi
0000798fc6fdc972  push rsi
0000798fc6fdc973  push r8
0000798fc6fdc975  push r9
0000798fc6fdc977  push r10
0000798fc6fdc979  push r11
0000798fc6fdc97b  sub rsp, 0xF0
0000798fc6fdc982  vmovaps [rsp], xmm0
0000798fc6fdc987  vmovaps [rsp+0x10], xmm1
0000798fc6fdc98d  vmovaps [rsp+0x20], xmm2
0000798fc6fdc993  vmovaps [rsp+0x30], xmm3
0000798fc6fdc999  vmovaps [rsp+0x40], xmm4
0000798fc6fdc99f  vmovaps [rsp+0x50], xmm5
0000798fc6fdc9a5  vmovaps [rsp+0x60], xmm6
0000798fc6fdc9ab  vmovaps [rsp+0x70], xmm7
0000798fc6fdc9b1  vmovaps [rsp+0x80], xmm9
0000798fc6fdc9ba  vmovaps [rsp+0x90], xmm10
0000798fc6fdc9c3  vmovaps [rsp+0xA0], xmm11
0000798fc6fdc9cc  vmovaps [rsp+0xB0], xmm12
0000798fc6fdc9d5  vmovaps [rsp+0xC0], xmm13
0000798fc6fdc9de  vmovaps [rsp+0xD0], xmm14
0000798fc6fdc9e7  vmovaps [rsp+0xE0], xmm15
0000798fc6fdc9f0  sub rsp, 0x30
0000798fc6fdc9f4  movaps [rsp], xmm8
0000798fc6fdc9f9  movaps [rsp+0x10], xmm12
0000798fc6fdc9ff  movaps [rsp+0x20], xmm15
0000798fc6fdca05  lea rdi, [rsp]
0000798fc6fdca09  mov esi, 0x00
0000798fc6fdca0e  mov rax, 0x63E558B23530
0000798fc6fdca18  call rax
0000798fc6fdca1a  movaps xmm8, [rsp]
0000798fc6fdca1f  add rsp, 0x30
0000798fc6fdca23  vmovaps xmm0, [rsp]
0000798fc6fdca28  vmovaps xmm1, [rsp+0x10]
0000798fc6fdca2e  vmovaps xmm2, [rsp+0x20]
0000798fc6fdca34  vmovaps xmm3, [rsp+0x30]
0000798fc6fdca3a  vmovaps xmm4, [rsp+0x40]
0000798fc6fdca40  vmovaps xmm5, [rsp+0x50]
0000798fc6fdca46  vmovaps xmm6, [rsp+0x60]
0000798fc6fdca4c  vmovaps xmm7, [rsp+0x70]
0000798fc6fdca52  vmovaps xmm9, [rsp+0x80]
0000798fc6fdca5b  vmovaps xmm10, [rsp+0x90]
0000798fc6fdca64  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdca6d  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdca76  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdca7f  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdca88  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdca91  add rsp, 0xF0
0000798fc6fdca98  pop r11
0000798fc6fdca9a  pop r10
0000798fc6fdca9c  pop r9
0000798fc6fdca9e  pop r8
0000798fc6fdcaa0  pop rsi
0000798fc6fdcaa1  pop rdi
0000798fc6fdcaa2  pop rdx
0000798fc6fdcaa3  pop rcx
0000798fc6fdcaa4  pop rax
0000798fc6fdcaa5  add rsp, 0x08
0000798fc6fdcaa9  jmp 0x0000798FC6FDBB47
0000798fc6fdcaae  sub rsp, 0x08
0000798fc6fdcab2  push rax
0000798fc6fdcab3  push rcx
0000798fc6fdcab4  push rdx
0000798fc6fdcab5  push rdi
0000798fc6fdcab6  push rsi
0000798fc6fdcab7  push r8
0000798fc6fdcab9  push r9
0000798fc6fdcabb  push r10
0000798fc6fdcabd  push r11
0000798fc6fdcabf  sub rsp, 0xF0
0000798fc6fdcac6  vmovaps [rsp], xmm0
0000798fc6fdcacb  vmovaps [rsp+0x10], xmm1
0000798fc6fdcad1  vmovaps [rsp+0x20], xmm2
0000798fc6fdcad7  vmovaps [rsp+0x30], xmm3
0000798fc6fdcadd  vmovaps [rsp+0x40], xmm4
0000798fc6fdcae3  vmovaps [rsp+0x50], xmm5
0000798fc6fdcae9  vmovaps [rsp+0x60], xmm6
0000798fc6fdcaef  vmovaps [rsp+0x70], xmm8
0000798fc6fdcaf5  vmovaps [rsp+0x80], xmm9
0000798fc6fdcafe  vmovaps [rsp+0x90], xmm10
0000798fc6fdcb07  vmovaps [rsp+0xA0], xmm11
0000798fc6fdcb10  vmovaps [rsp+0xB0], xmm12
0000798fc6fdcb19  vmovaps [rsp+0xC0], xmm13
0000798fc6fdcb22  vmovaps [rsp+0xD0], xmm14
0000798fc6fdcb2b  vmovaps [rsp+0xE0], xmm15
0000798fc6fdcb34  sub rsp, 0x30
0000798fc6fdcb38  movaps [rsp], xmm7
0000798fc6fdcb3c  movaps [rsp+0x10], xmm9
0000798fc6fdcb42  movaps [rsp+0x20], xmm15
0000798fc6fdcb48  lea rdi, [rsp]
0000798fc6fdcb4c  mov esi, 0x00
0000798fc6fdcb51  mov rax, 0x63E558B23530
0000798fc6fdcb5b  call rax
0000798fc6fdcb5d  movaps xmm7, [rsp]
0000798fc6fdcb61  add rsp, 0x30
0000798fc6fdcb65  vmovaps xmm0, [rsp]
0000798fc6fdcb6a  vmovaps xmm1, [rsp+0x10]
0000798fc6fdcb70  vmovaps xmm2, [rsp+0x20]
0000798fc6fdcb76  vmovaps xmm3, [rsp+0x30]
0000798fc6fdcb7c  vmovaps xmm4, [rsp+0x40]
0000798fc6fdcb82  vmovaps xmm5, [rsp+0x50]
0000798fc6fdcb88  vmovaps xmm6, [rsp+0x60]
0000798fc6fdcb8e  vmovaps xmm8, [rsp+0x70]
0000798fc6fdcb94  vmovaps xmm9, [rsp+0x80]
0000798fc6fdcb9d  vmovaps xmm10, [rsp+0x90]
0000798fc6fdcba6  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdcbaf  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdcbb8  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdcbc1  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdcbca  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdcbd3  add rsp, 0xF0
0000798fc6fdcbda  pop r11
0000798fc6fdcbdc  pop r10
0000798fc6fdcbde  pop r9
0000798fc6fdcbe0  pop r8
0000798fc6fdcbe2  pop rsi
0000798fc6fdcbe3  pop rdi
0000798fc6fdcbe4  pop rdx
0000798fc6fdcbe5  pop rcx
0000798fc6fdcbe6  pop rax
0000798fc6fdcbe7  add rsp, 0x08
0000798fc6fdcbeb  jmp 0x0000798FC6FDBB75
0000798fc6fdcbf0  sub rsp, 0x08
0000798fc6fdcbf4  push rax
0000798fc6fdcbf5  push rcx
0000798fc6fdcbf6  push rdx
0000798fc6fdcbf7  push rdi
0000798fc6fdcbf8  push rsi
0000798fc6fdcbf9  push r8
0000798fc6fdcbfb  push r9
0000798fc6fdcbfd  push r10
0000798fc6fdcbff  push r11
0000798fc6fdcc01  sub rsp, 0xF0
0000798fc6fdcc08  vmovaps [rsp], xmm0
0000798fc6fdcc0d  vmovaps [rsp+0x10], xmm1
0000798fc6fdcc13  vmovaps [rsp+0x20], xmm2
0000798fc6fdcc19  vmovaps [rsp+0x30], xmm3
0000798fc6fdcc1f  vmovaps [rsp+0x40], xmm4
0000798fc6fdcc25  vmovaps [rsp+0x50], xmm5
0000798fc6fdcc2b  vmovaps [rsp+0x60], xmm6
0000798fc6fdcc31  vmovaps [rsp+0x70], xmm7
0000798fc6fdcc37  vmovaps [rsp+0x80], xmm8
0000798fc6fdcc40  vmovaps [rsp+0x90], xmm10
0000798fc6fdcc49  vmovaps [rsp+0xA0], xmm11
0000798fc6fdcc52  vmovaps [rsp+0xB0], xmm12
0000798fc6fdcc5b  vmovaps [rsp+0xC0], xmm13
0000798fc6fdcc64  vmovaps [rsp+0xD0], xmm14
0000798fc6fdcc6d  vmovaps [rsp+0xE0], xmm15
0000798fc6fdcc76  sub rsp, 0x30
0000798fc6fdcc7a  movaps [rsp], xmm9
0000798fc6fdcc7f  movaps [rsp+0x10], xmm12
0000798fc6fdcc85  movaps [rsp+0x20], xmm10
0000798fc6fdcc8b  lea rdi, [rsp]
0000798fc6fdcc8f  mov esi, 0x00
0000798fc6fdcc94  mov rax, 0x63E558B23530
0000798fc6fdcc9e  call rax
0000798fc6fdcca0  movaps xmm9, [rsp]
0000798fc6fdcca5  add rsp, 0x30
0000798fc6fdcca9  vmovaps xmm0, [rsp]
0000798fc6fdccae  vmovaps xmm1, [rsp+0x10]
0000798fc6fdccb4  vmovaps xmm2, [rsp+0x20]
0000798fc6fdccba  vmovaps xmm3, [rsp+0x30]
0000798fc6fdccc0  vmovaps xmm4, [rsp+0x40]
0000798fc6fdccc6  vmovaps xmm5, [rsp+0x50]
0000798fc6fdcccc  vmovaps xmm6, [rsp+0x60]
0000798fc6fdccd2  vmovaps xmm7, [rsp+0x70]
0000798fc6fdccd8  vmovaps xmm8, [rsp+0x80]
0000798fc6fdcce1  vmovaps xmm10, [rsp+0x90]
0000798fc6fdccea  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdccf3  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdccfc  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdcd05  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdcd0e  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdcd17  add rsp, 0xF0
0000798fc6fdcd1e  pop r11
0000798fc6fdcd20  pop r10
0000798fc6fdcd22  pop r9
0000798fc6fdcd24  pop r8
0000798fc6fdcd26  pop rsi
0000798fc6fdcd27  pop rdi
0000798fc6fdcd28  pop rdx
0000798fc6fdcd29  pop rcx
0000798fc6fdcd2a  pop rax
0000798fc6fdcd2b  add rsp, 0x08
0000798fc6fdcd2f  jmp 0x0000798FC6FDBB99
0000798fc6fdcd34  sub rsp, 0x08
0000798fc6fdcd38  push rax
0000798fc6fdcd39  push rcx
0000798fc6fdcd3a  push rdx
0000798fc6fdcd3b  push rdi
0000798fc6fdcd3c  push rsi
0000798fc6fdcd3d  push r8
0000798fc6fdcd3f  push r9
0000798fc6fdcd41  push r10
0000798fc6fdcd43  push r11
0000798fc6fdcd45  sub rsp, 0xF0
0000798fc6fdcd4c  vmovaps [rsp], xmm0
0000798fc6fdcd51  vmovaps [rsp+0x10], xmm1
0000798fc6fdcd57  vmovaps [rsp+0x20], xmm2
0000798fc6fdcd5d  vmovaps [rsp+0x30], xmm3
0000798fc6fdcd63  vmovaps [rsp+0x40], xmm4
0000798fc6fdcd69  vmovaps [rsp+0x50], xmm5
0000798fc6fdcd6f  vmovaps [rsp+0x60], xmm6
0000798fc6fdcd75  vmovaps [rsp+0x70], xmm7
0000798fc6fdcd7b  vmovaps [rsp+0x80], xmm8
0000798fc6fdcd84  vmovaps [rsp+0x90], xmm9
0000798fc6fdcd8d  vmovaps [rsp+0xA0], xmm11
0000798fc6fdcd96  vmovaps [rsp+0xB0], xmm12
0000798fc6fdcd9f  vmovaps [rsp+0xC0], xmm13
0000798fc6fdcda8  vmovaps [rsp+0xD0], xmm14
0000798fc6fdcdb1  vmovaps [rsp+0xE0], xmm15
0000798fc6fdcdba  sub rsp, 0x30
0000798fc6fdcdbe  movaps [rsp], xmm10
0000798fc6fdcdc3  movaps [rsp+0x10], xmm12
0000798fc6fdcdc9  movaps [rsp+0x20], xmm11
0000798fc6fdcdcf  lea rdi, [rsp]
0000798fc6fdcdd3  mov esi, 0x00
0000798fc6fdcdd8  mov rax, 0x63E558B23530
0000798fc6fdcde2  call rax
0000798fc6fdcde4  movaps xmm10, [rsp]
0000798fc6fdcde9  add rsp, 0x30
0000798fc6fdcded  vmovaps xmm0, [rsp]
0000798fc6fdcdf2  vmovaps xmm1, [rsp+0x10]
0000798fc6fdcdf8  vmovaps xmm2, [rsp+0x20]
0000798fc6fdcdfe  vmovaps xmm3, [rsp+0x30]
0000798fc6fdce04  vmovaps xmm4, [rsp+0x40]
0000798fc6fdce0a  vmovaps xmm5, [rsp+0x50]
0000798fc6fdce10  vmovaps xmm6, [rsp+0x60]
0000798fc6fdce16  vmovaps xmm7, [rsp+0x70]
0000798fc6fdce1c  vmovaps xmm8, [rsp+0x80]
0000798fc6fdce25  vmovaps xmm9, [rsp+0x90]
0000798fc6fdce2e  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdce37  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdce40  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdce49  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdce52  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdce5b  add rsp, 0xF0
0000798fc6fdce62  pop r11
0000798fc6fdce64  pop r10
0000798fc6fdce66  pop r9
0000798fc6fdce68  pop r8
0000798fc6fdce6a  pop rsi
0000798fc6fdce6b  pop rdi
0000798fc6fdce6c  pop rdx
0000798fc6fdce6d  pop rcx
0000798fc6fdce6e  pop rax
0000798fc6fdce6f  add rsp, 0x08
0000798fc6fdce73  jmp 0x0000798FC6FDBBB3
0000798fc6fdce78  sub rsp, 0x08
0000798fc6fdce7c  push rax
0000798fc6fdce7d  push rcx
0000798fc6fdce7e  push rdx
0000798fc6fdce7f  push rdi
0000798fc6fdce80  push rsi
0000798fc6fdce81  push r8
0000798fc6fdce83  push r9
0000798fc6fdce85  push r10
0000798fc6fdce87  push r11
0000798fc6fdce89  sub rsp, 0xF0
0000798fc6fdce90  vmovaps [rsp], xmm0
0000798fc6fdce95  vmovaps [rsp+0x10], xmm1
0000798fc6fdce9b  vmovaps [rsp+0x20], xmm2
0000798fc6fdcea1  vmovaps [rsp+0x30], xmm3
0000798fc6fdcea7  vmovaps [rsp+0x40], xmm4
0000798fc6fdcead  vmovaps [rsp+0x50], xmm5
0000798fc6fdceb3  vmovaps [rsp+0x60], xmm7
0000798fc6fdceb9  vmovaps [rsp+0x70], xmm8
0000798fc6fdcebf  vmovaps [rsp+0x80], xmm9
0000798fc6fdcec8  vmovaps [rsp+0x90], xmm10
0000798fc6fdced1  vmovaps [rsp+0xA0], xmm11
0000798fc6fdceda  vmovaps [rsp+0xB0], xmm12
0000798fc6fdcee3  vmovaps [rsp+0xC0], xmm13
0000798fc6fdceec  vmovaps [rsp+0xD0], xmm14
0000798fc6fdcef5  vmovaps [rsp+0xE0], xmm15
0000798fc6fdcefe  sub rsp, 0x30
0000798fc6fdcf02  movaps [rsp], xmm6
0000798fc6fdcf06  movaps [rsp+0x10], xmm12
0000798fc6fdcf0c  movaps [rsp+0x20], xmm11
0000798fc6fdcf12  lea rdi, [rsp]
0000798fc6fdcf16  mov esi, 0x00
0000798fc6fdcf1b  mov rax, 0x63E558B23530
0000798fc6fdcf25  call rax
0000798fc6fdcf27  movaps xmm6, [rsp]
0000798fc6fdcf2b  add rsp, 0x30
0000798fc6fdcf2f  vmovaps xmm0, [rsp]
0000798fc6fdcf34  vmovaps xmm1, [rsp+0x10]
0000798fc6fdcf3a  vmovaps xmm2, [rsp+0x20]
0000798fc6fdcf40  vmovaps xmm3, [rsp+0x30]
0000798fc6fdcf46  vmovaps xmm4, [rsp+0x40]
0000798fc6fdcf4c  vmovaps xmm5, [rsp+0x50]
0000798fc6fdcf52  vmovaps xmm7, [rsp+0x60]
0000798fc6fdcf58  vmovaps xmm8, [rsp+0x70]
0000798fc6fdcf5e  vmovaps xmm9, [rsp+0x80]
0000798fc6fdcf67  vmovaps xmm10, [rsp+0x90]
0000798fc6fdcf70  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdcf79  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdcf82  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdcf8b  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdcf94  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdcf9d  add rsp, 0xF0
0000798fc6fdcfa4  pop r11
0000798fc6fdcfa6  pop r10
0000798fc6fdcfa8  pop r9
0000798fc6fdcfaa  pop r8
0000798fc6fdcfac  pop rsi
0000798fc6fdcfad  pop rdi
0000798fc6fdcfae  pop rdx
0000798fc6fdcfaf  pop rcx
0000798fc6fdcfb0  pop rax
0000798fc6fdcfb1  add rsp, 0x08
0000798fc6fdcfb5  jmp 0x0000798FC6FDBBD4
0000798fc6fdcfba  sub rsp, 0x08
0000798fc6fdcfbe  push rax
0000798fc6fdcfbf  push rcx
0000798fc6fdcfc0  push rdx
0000798fc6fdcfc1  push rdi
0000798fc6fdcfc2  push rsi
0000798fc6fdcfc3  push r8
0000798fc6fdcfc5  push r9
0000798fc6fdcfc7  push r10
0000798fc6fdcfc9  push r11
0000798fc6fdcfcb  sub rsp, 0xF0
0000798fc6fdcfd2  vmovaps [rsp], xmm0
0000798fc6fdcfd7  vmovaps [rsp+0x10], xmm1
0000798fc6fdcfdd  vmovaps [rsp+0x20], xmm2
0000798fc6fdcfe3  vmovaps [rsp+0x30], xmm4
0000798fc6fdcfe9  vmovaps [rsp+0x40], xmm5
0000798fc6fdcfef  vmovaps [rsp+0x50], xmm6
0000798fc6fdcff5  vmovaps [rsp+0x60], xmm7
0000798fc6fdcffb  vmovaps [rsp+0x70], xmm8
0000798fc6fdd001  vmovaps [rsp+0x80], xmm9
0000798fc6fdd00a  vmovaps [rsp+0x90], xmm10
0000798fc6fdd013  vmovaps [rsp+0xA0], xmm11
0000798fc6fdd01c  vmovaps [rsp+0xB0], xmm12
0000798fc6fdd025  vmovaps [rsp+0xC0], xmm13
0000798fc6fdd02e  vmovaps [rsp+0xD0], xmm14
0000798fc6fdd037  vmovaps [rsp+0xE0], xmm15
0000798fc6fdd040  sub rsp, 0x30
0000798fc6fdd044  movaps [rsp], xmm3
0000798fc6fdd048  movaps [rsp+0x10], xmm5
0000798fc6fdd04d  movaps [rsp+0x20], xmm4
0000798fc6fdd052  lea rdi, [rsp]
0000798fc6fdd056  mov esi, 0x00
0000798fc6fdd05b  mov rax, 0x63E558B23530
0000798fc6fdd065  call rax
0000798fc6fdd067  movaps xmm3, [rsp]
0000798fc6fdd06b  add rsp, 0x30
0000798fc6fdd06f  vmovaps xmm0, [rsp]
0000798fc6fdd074  vmovaps xmm1, [rsp+0x10]
0000798fc6fdd07a  vmovaps xmm2, [rsp+0x20]
0000798fc6fdd080  vmovaps xmm4, [rsp+0x30]
0000798fc6fdd086  vmovaps xmm5, [rsp+0x40]
0000798fc6fdd08c  vmovaps xmm6, [rsp+0x50]
0000798fc6fdd092  vmovaps xmm7, [rsp+0x60]
0000798fc6fdd098  vmovaps xmm8, [rsp+0x70]
0000798fc6fdd09e  vmovaps xmm9, [rsp+0x80]
0000798fc6fdd0a7  vmovaps xmm10, [rsp+0x90]
0000798fc6fdd0b0  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdd0b9  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdd0c2  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdd0cb  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdd0d4  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdd0dd  add rsp, 0xF0
0000798fc6fdd0e4  pop r11
0000798fc6fdd0e6  pop r10
0000798fc6fdd0e8  pop r9
0000798fc6fdd0ea  pop r8
0000798fc6fdd0ec  pop rsi
0000798fc6fdd0ed  pop rdi
0000798fc6fdd0ee  pop rdx
0000798fc6fdd0ef  pop rcx
0000798fc6fdd0f0  pop rax
0000798fc6fdd0f1  add rsp, 0x08
0000798fc6fdd0f5  jmp 0x0000798FC6FDBC35
0000798fc6fdd0fa  sub rsp, 0x08
0000798fc6fdd0fe  push rax
0000798fc6fdd0ff  push rcx
0000798fc6fdd100  push rdx
0000798fc6fdd101  push rdi
0000798fc6fdd102  push rsi
0000798fc6fdd103  push r8
0000798fc6fdd105  push r9
0000798fc6fdd107  push r10
0000798fc6fdd109  push r11
0000798fc6fdd10b  sub rsp, 0xF0
0000798fc6fdd112  vmovaps [rsp], xmm0
0000798fc6fdd117  vmovaps [rsp+0x10], xmm1
0000798fc6fdd11d  vmovaps [rsp+0x20], xmm2
0000798fc6fdd123  vmovaps [rsp+0x30], xmm3
0000798fc6fdd129  vmovaps [rsp+0x40], xmm4
0000798fc6fdd12f  vmovaps [rsp+0x50], xmm6
0000798fc6fdd135  vmovaps [rsp+0x60], xmm7
0000798fc6fdd13b  vmovaps [rsp+0x70], xmm8
0000798fc6fdd141  vmovaps [rsp+0x80], xmm9
0000798fc6fdd14a  vmovaps [rsp+0x90], xmm10
0000798fc6fdd153  vmovaps [rsp+0xA0], xmm11
0000798fc6fdd15c  vmovaps [rsp+0xB0], xmm12
0000798fc6fdd165  vmovaps [rsp+0xC0], xmm13
0000798fc6fdd16e  vmovaps [rsp+0xD0], xmm14
0000798fc6fdd177  vmovaps [rsp+0xE0], xmm15
0000798fc6fdd180  sub rsp, 0x30
0000798fc6fdd184  movaps [rsp], xmm5
0000798fc6fdd188  movaps [rsp+0x10], xmm8
0000798fc6fdd18e  movaps [rsp+0x20], xmm15
0000798fc6fdd194  lea rdi, [rsp]
0000798fc6fdd198  mov esi, 0x00
0000798fc6fdd19d  mov rax, 0x63E558B23530
0000798fc6fdd1a7  call rax
0000798fc6fdd1a9  movaps xmm5, [rsp]
0000798fc6fdd1ad  add rsp, 0x30
0000798fc6fdd1b1  vmovaps xmm0, [rsp]
0000798fc6fdd1b6  vmovaps xmm1, [rsp+0x10]
0000798fc6fdd1bc  vmovaps xmm2, [rsp+0x20]
0000798fc6fdd1c2  vmovaps xmm3, [rsp+0x30]
0000798fc6fdd1c8  vmovaps xmm4, [rsp+0x40]
0000798fc6fdd1ce  vmovaps xmm6, [rsp+0x50]
0000798fc6fdd1d4  vmovaps xmm7, [rsp+0x60]
0000798fc6fdd1da  vmovaps xmm8, [rsp+0x70]
0000798fc6fdd1e0  vmovaps xmm9, [rsp+0x80]
0000798fc6fdd1e9  vmovaps xmm10, [rsp+0x90]
0000798fc6fdd1f2  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdd1fb  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdd204  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdd20d  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdd216  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdd21f  add rsp, 0xF0
0000798fc6fdd226  pop r11
0000798fc6fdd228  pop r10
0000798fc6fdd22a  pop r9
0000798fc6fdd22c  pop r8
0000798fc6fdd22e  pop rsi
0000798fc6fdd22f  pop rdi
0000798fc6fdd230  pop rdx
0000798fc6fdd231  pop rcx
0000798fc6fdd232  pop rax
0000798fc6fdd233  add rsp, 0x08
0000798fc6fdd237  jmp 0x0000798FC6FDBC73
0000798fc6fdd23c  sub rsp, 0x08
0000798fc6fdd240  push rax
0000798fc6fdd241  push rcx
0000798fc6fdd242  push rdx
0000798fc6fdd243  push rdi
0000798fc6fdd244  push rsi
0000798fc6fdd245  push r8
0000798fc6fdd247  push r9
0000798fc6fdd249  push r10
0000798fc6fdd24b  push r11
0000798fc6fdd24d  sub rsp, 0xF0
0000798fc6fdd254  vmovaps [rsp], xmm0
0000798fc6fdd259  vmovaps [rsp+0x10], xmm1
0000798fc6fdd25f  vmovaps [rsp+0x20], xmm2
0000798fc6fdd265  vmovaps [rsp+0x30], xmm3
0000798fc6fdd26b  vmovaps [rsp+0x40], xmm5
0000798fc6fdd271  vmovaps [rsp+0x50], xmm6
0000798fc6fdd277  vmovaps [rsp+0x60], xmm7
0000798fc6fdd27d  vmovaps [rsp+0x70], xmm8
0000798fc6fdd283  vmovaps [rsp+0x80], xmm9
0000798fc6fdd28c  vmovaps [rsp+0x90], xmm10
0000798fc6fdd295  vmovaps [rsp+0xA0], xmm11
0000798fc6fdd29e  vmovaps [rsp+0xB0], xmm12
0000798fc6fdd2a7  vmovaps [rsp+0xC0], xmm13
0000798fc6fdd2b0  vmovaps [rsp+0xD0], xmm14
0000798fc6fdd2b9  vmovaps [rsp+0xE0], xmm15
0000798fc6fdd2c2  sub rsp, 0x30
0000798fc6fdd2c6  movaps [rsp], xmm4
0000798fc6fdd2ca  movaps [rsp+0x10], xmm9
0000798fc6fdd2d0  movaps [rsp+0x20], xmm8
0000798fc6fdd2d6  lea rdi, [rsp]
0000798fc6fdd2da  mov esi, 0x00
0000798fc6fdd2df  mov rax, 0x63E558B23530
0000798fc6fdd2e9  call rax
0000798fc6fdd2eb  movaps xmm4, [rsp]
0000798fc6fdd2ef  add rsp, 0x30
0000798fc6fdd2f3  vmovaps xmm0, [rsp]
0000798fc6fdd2f8  vmovaps xmm1, [rsp+0x10]
0000798fc6fdd2fe  vmovaps xmm2, [rsp+0x20]
0000798fc6fdd304  vmovaps xmm3, [rsp+0x30]
0000798fc6fdd30a  vmovaps xmm5, [rsp+0x40]
0000798fc6fdd310  vmovaps xmm6, [rsp+0x50]
0000798fc6fdd316  vmovaps xmm7, [rsp+0x60]
0000798fc6fdd31c  vmovaps xmm8, [rsp+0x70]
0000798fc6fdd322  vmovaps xmm9, [rsp+0x80]
0000798fc6fdd32b  vmovaps xmm10, [rsp+0x90]
0000798fc6fdd334  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdd33d  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdd346  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdd34f  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdd358  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdd361  add rsp, 0xF0
0000798fc6fdd368  pop r11
0000798fc6fdd36a  pop r10
0000798fc6fdd36c  pop r9
0000798fc6fdd36e  pop r8
0000798fc6fdd370  pop rsi
0000798fc6fdd371  pop rdi
0000798fc6fdd372  pop rdx
0000798fc6fdd373  pop rcx
0000798fc6fdd374  pop rax
0000798fc6fdd375  add rsp, 0x08
0000798fc6fdd379  jmp 0x0000798FC6FDBC94
0000798fc6fdd37e  sub rsp, 0x08
0000798fc6fdd382  push rax
0000798fc6fdd383  push rcx
0000798fc6fdd384  push rdx
0000798fc6fdd385  push rdi
0000798fc6fdd386  push rsi
0000798fc6fdd387  push r8
0000798fc6fdd389  push r9
0000798fc6fdd38b  push r10
0000798fc6fdd38d  push r11
0000798fc6fdd38f  sub rsp, 0xF0
0000798fc6fdd396  vmovaps [rsp], xmm0
0000798fc6fdd39b  vmovaps [rsp+0x10], xmm1
0000798fc6fdd3a1  vmovaps [rsp+0x20], xmm2
0000798fc6fdd3a7  vmovaps [rsp+0x30], xmm3
0000798fc6fdd3ad  vmovaps [rsp+0x40], xmm4
0000798fc6fdd3b3  vmovaps [rsp+0x50], xmm5
0000798fc6fdd3b9  vmovaps [rsp+0x60], xmm6
0000798fc6fdd3bf  vmovaps [rsp+0x70], xmm7
0000798fc6fdd3c5  vmovaps [rsp+0x80], xmm8
0000798fc6fdd3ce  vmovaps [rsp+0x90], xmm10
0000798fc6fdd3d7  vmovaps [rsp+0xA0], xmm11
0000798fc6fdd3e0  vmovaps [rsp+0xB0], xmm12
0000798fc6fdd3e9  vmovaps [rsp+0xC0], xmm13
0000798fc6fdd3f2  vmovaps [rsp+0xD0], xmm14
0000798fc6fdd3fb  vmovaps [rsp+0xE0], xmm15
0000798fc6fdd404  sub rsp, 0x30
0000798fc6fdd408  movaps [rsp], xmm9
0000798fc6fdd40d  movaps [rsp+0x10], xmm10
0000798fc6fdd413  movaps [rsp+0x20], xmm8
0000798fc6fdd419  lea rdi, [rsp]
0000798fc6fdd41d  mov esi, 0x00
0000798fc6fdd422  mov rax, 0x63E558B23530
0000798fc6fdd42c  call rax
0000798fc6fdd42e  movaps xmm9, [rsp]
0000798fc6fdd433  add rsp, 0x30
0000798fc6fdd437  vmovaps xmm0, [rsp]
0000798fc6fdd43c  vmovaps xmm1, [rsp+0x10]
0000798fc6fdd442  vmovaps xmm2, [rsp+0x20]
0000798fc6fdd448  vmovaps xmm3, [rsp+0x30]
0000798fc6fdd44e  vmovaps xmm4, [rsp+0x40]
0000798fc6fdd454  vmovaps xmm5, [rsp+0x50]
0000798fc6fdd45a  vmovaps xmm6, [rsp+0x60]
0000798fc6fdd460  vmovaps xmm7, [rsp+0x70]
0000798fc6fdd466  vmovaps xmm8, [rsp+0x80]
0000798fc6fdd46f  vmovaps xmm10, [rsp+0x90]
0000798fc6fdd478  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdd481  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdd48a  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdd493  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdd49c  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdd4a5  add rsp, 0xF0
0000798fc6fdd4ac  pop r11
0000798fc6fdd4ae  pop r10
0000798fc6fdd4b0  pop r9
0000798fc6fdd4b2  pop r8
0000798fc6fdd4b4  pop rsi
0000798fc6fdd4b5  pop rdi
0000798fc6fdd4b6  pop rdx
0000798fc6fdd4b7  pop rcx
0000798fc6fdd4b8  pop rax
0000798fc6fdd4b9  add rsp, 0x08
0000798fc6fdd4bd  jmp 0x0000798FC6FDBCAE
0000798fc6fdd4c2  call 0x0000798FC6EB52F0
0000798fc6fdd4c7  jmp 0x0000798FC6FDBDC8
0000798fc6fdd4cc  call 0x0000798FC6EB52F0
0000798fc6fdd4d1  jmp 0x0000798FC6FDBDDE
0000798fc6fdd4d6  sub rsp, 0x08
0000798fc6fdd4da  push rax
0000798fc6fdd4db  push rcx
0000798fc6fdd4dc  push rdx
0000798fc6fdd4dd  push rdi
0000798fc6fdd4de  push rsi
0000798fc6fdd4df  push r8
0000798fc6fdd4e1  push r9
0000798fc6fdd4e3  push r10
0000798fc6fdd4e5  push r11
0000798fc6fdd4e7  sub rsp, 0xF0
0000798fc6fdd4ee  vmovaps [rsp], xmm0
0000798fc6fdd4f3  vmovaps [rsp+0x10], xmm2
0000798fc6fdd4f9  vmovaps [rsp+0x20], xmm3
0000798fc6fdd4ff  vmovaps [rsp+0x30], xmm4
0000798fc6fdd505  vmovaps [rsp+0x40], xmm5
0000798fc6fdd50b  vmovaps [rsp+0x50], xmm6
0000798fc6fdd511  vmovaps [rsp+0x60], xmm7
0000798fc6fdd517  vmovaps [rsp+0x70], xmm8
0000798fc6fdd51d  vmovaps [rsp+0x80], xmm9
0000798fc6fdd526  vmovaps [rsp+0x90], xmm10
0000798fc6fdd52f  vmovaps [rsp+0xA0], xmm11
0000798fc6fdd538  vmovaps [rsp+0xB0], xmm12
0000798fc6fdd541  vmovaps [rsp+0xC0], xmm13
0000798fc6fdd54a  vmovaps [rsp+0xD0], xmm14
0000798fc6fdd553  vmovaps [rsp+0xE0], xmm15
0000798fc6fdd55c  sub rsp, 0x30
0000798fc6fdd560  movaps [rsp], xmm1
0000798fc6fdd564  movaps [rsp+0x10], xmm6
0000798fc6fdd569  movaps [rsp+0x20], xmm15
0000798fc6fdd56f  lea rdi, [rsp]
0000798fc6fdd573  mov esi, 0x00
0000798fc6fdd578  mov rax, 0x63E558B23530
0000798fc6fdd582  call rax
0000798fc6fdd584  movaps xmm1, [rsp]
0000798fc6fdd588  add rsp, 0x30
0000798fc6fdd58c  vmovaps xmm0, [rsp]
0000798fc6fdd591  vmovaps xmm2, [rsp+0x10]
0000798fc6fdd597  vmovaps xmm3, [rsp+0x20]
0000798fc6fdd59d  vmovaps xmm4, [rsp+0x30]
0000798fc6fdd5a3  vmovaps xmm5, [rsp+0x40]
0000798fc6fdd5a9  vmovaps xmm6, [rsp+0x50]
0000798fc6fdd5af  vmovaps xmm7, [rsp+0x60]
0000798fc6fdd5b5  vmovaps xmm8, [rsp+0x70]
0000798fc6fdd5bb  vmovaps xmm9, [rsp+0x80]
0000798fc6fdd5c4  vmovaps xmm10, [rsp+0x90]
0000798fc6fdd5cd  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdd5d6  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdd5df  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdd5e8  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdd5f1  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdd5fa  add rsp, 0xF0
0000798fc6fdd601  pop r11
0000798fc6fdd603  pop r10
0000798fc6fdd605  pop r9
0000798fc6fdd607  pop r8
0000798fc6fdd609  pop rsi
0000798fc6fdd60a  pop rdi
0000798fc6fdd60b  pop rdx
0000798fc6fdd60c  pop rcx
0000798fc6fdd60d  pop rax
0000798fc6fdd60e  add rsp, 0x08
0000798fc6fdd612  jmp 0x0000798FC6FDBE1B
0000798fc6fdd617  call 0x0000798FC6EC4620
0000798fc6fdd61c  jmp 0x0000798FC6FDBE28
0000798fc6fdd621  sub rsp, 0x08
0000798fc6fdd625  push rax
0000798fc6fdd626  push rcx
0000798fc6fdd627  push rdx
0000798fc6fdd628  push rdi
0000798fc6fdd629  push rsi
0000798fc6fdd62a  push r8
0000798fc6fdd62c  push r9
0000798fc6fdd62e  push r10
0000798fc6fdd630  push r11
0000798fc6fdd632  sub rsp, 0xF0
0000798fc6fdd639  vmovaps [rsp], xmm0
0000798fc6fdd63e  vmovaps [rsp+0x10], xmm1
0000798fc6fdd644  vmovaps [rsp+0x20], xmm2
0000798fc6fdd64a  vmovaps [rsp+0x30], xmm3
0000798fc6fdd650  vmovaps [rsp+0x40], xmm4
0000798fc6fdd656  vmovaps [rsp+0x50], xmm5
0000798fc6fdd65c  vmovaps [rsp+0x60], xmm6
0000798fc6fdd662  vmovaps [rsp+0x70], xmm7
0000798fc6fdd668  vmovaps [rsp+0x80], xmm8
0000798fc6fdd671  vmovaps [rsp+0x90], xmm9
0000798fc6fdd67a  vmovaps [rsp+0xA0], xmm10
0000798fc6fdd683  vmovaps [rsp+0xB0], xmm11
0000798fc6fdd68c  vmovaps [rsp+0xC0], xmm12
0000798fc6fdd695  vmovaps [rsp+0xD0], xmm13
0000798fc6fdd69e  vmovaps [rsp+0xE0], xmm15
0000798fc6fdd6a7  sub rsp, 0x30
0000798fc6fdd6ab  movaps [rsp], xmm14
0000798fc6fdd6b0  movaps [rsp+0x10], xmm4
0000798fc6fdd6b5  movaps [rsp+0x20], xmm3
0000798fc6fdd6ba  lea rdi, [rsp]
0000798fc6fdd6be  mov esi, 0x00
0000798fc6fdd6c3  mov rax, 0x63E558B23530
0000798fc6fdd6cd  call rax
0000798fc6fdd6cf  movaps xmm14, [rsp]
0000798fc6fdd6d4  add rsp, 0x30
0000798fc6fdd6d8  vmovaps xmm0, [rsp]
0000798fc6fdd6dd  vmovaps xmm1, [rsp+0x10]
0000798fc6fdd6e3  vmovaps xmm2, [rsp+0x20]
0000798fc6fdd6e9  vmovaps xmm3, [rsp+0x30]
0000798fc6fdd6ef  vmovaps xmm4, [rsp+0x40]
0000798fc6fdd6f5  vmovaps xmm5, [rsp+0x50]
0000798fc6fdd6fb  vmovaps xmm6, [rsp+0x60]
0000798fc6fdd701  vmovaps xmm7, [rsp+0x70]
0000798fc6fdd707  vmovaps xmm8, [rsp+0x80]
0000798fc6fdd710  vmovaps xmm9, [rsp+0x90]
0000798fc6fdd719  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdd722  vmovaps xmm11, [rsp+0xB0]
0000798fc6fdd72b  vmovaps xmm12, [rsp+0xC0]
0000798fc6fdd734  vmovaps xmm13, [rsp+0xD0]
0000798fc6fdd73d  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdd746  add rsp, 0xF0
0000798fc6fdd74d  pop r11
0000798fc6fdd74f  pop r10
0000798fc6fdd751  pop r9
0000798fc6fdd753  pop r8
0000798fc6fdd755  pop rsi
0000798fc6fdd756  pop rdi
0000798fc6fdd757  pop rdx
0000798fc6fdd758  pop rcx
0000798fc6fdd759  pop rax
0000798fc6fdd75a  add rsp, 0x08
0000798fc6fdd75e  jmp 0x0000798FC6FDBE42
0000798fc6fdd763  sub rsp, 0x08
0000798fc6fdd767  push rax
0000798fc6fdd768  push rcx
0000798fc6fdd769  push rdx
0000798fc6fdd76a  push rdi
0000798fc6fdd76b  push rsi
0000798fc6fdd76c  push r8
0000798fc6fdd76e  push r9
0000798fc6fdd770  push r10
0000798fc6fdd772  push r11
0000798fc6fdd774  sub rsp, 0xF0
0000798fc6fdd77b  vmovaps [rsp], xmm0
0000798fc6fdd780  vmovaps [rsp+0x10], xmm1
0000798fc6fdd786  vmovaps [rsp+0x20], xmm2
0000798fc6fdd78c  vmovaps [rsp+0x30], xmm3
0000798fc6fdd792  vmovaps [rsp+0x40], xmm4
0000798fc6fdd798  vmovaps [rsp+0x50], xmm5
0000798fc6fdd79e  vmovaps [rsp+0x60], xmm7
0000798fc6fdd7a4  vmovaps [rsp+0x70], xmm8
0000798fc6fdd7aa  vmovaps [rsp+0x80], xmm9
0000798fc6fdd7b3  vmovaps [rsp+0x90], xmm10
0000798fc6fdd7bc  vmovaps [rsp+0xA0], xmm11
0000798fc6fdd7c5  vmovaps [rsp+0xB0], xmm12
0000798fc6fdd7ce  vmovaps [rsp+0xC0], xmm13
0000798fc6fdd7d7  vmovaps [rsp+0xD0], xmm14
0000798fc6fdd7e0  vmovaps [rsp+0xE0], xmm15
0000798fc6fdd7e9  sub rsp, 0x30
0000798fc6fdd7ed  movaps [rsp], xmm6
0000798fc6fdd7f1  movaps [rsp+0x10], xmm9
0000798fc6fdd7f7  movaps [rsp+0x20], xmm7
0000798fc6fdd7fc  lea rdi, [rsp]
0000798fc6fdd800  mov esi, 0x00
0000798fc6fdd805  mov rax, 0x63E558B23530
0000798fc6fdd80f  call rax
0000798fc6fdd811  movaps xmm6, [rsp]
0000798fc6fdd815  add rsp, 0x30
0000798fc6fdd819  vmovaps xmm0, [rsp]
0000798fc6fdd81e  vmovaps xmm1, [rsp+0x10]
0000798fc6fdd824  vmovaps xmm2, [rsp+0x20]
0000798fc6fdd82a  vmovaps xmm3, [rsp+0x30]
0000798fc6fdd830  vmovaps xmm4, [rsp+0x40]
0000798fc6fdd836  vmovaps xmm5, [rsp+0x50]
0000798fc6fdd83c  vmovaps xmm7, [rsp+0x60]
0000798fc6fdd842  vmovaps xmm8, [rsp+0x70]
0000798fc6fdd848  vmovaps xmm9, [rsp+0x80]
0000798fc6fdd851  vmovaps xmm10, [rsp+0x90]
0000798fc6fdd85a  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdd863  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdd86c  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdd875  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdd87e  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdd887  add rsp, 0xF0
0000798fc6fdd88e  pop r11
0000798fc6fdd890  pop r10
0000798fc6fdd892  pop r9
0000798fc6fdd894  pop r8
0000798fc6fdd896  pop rsi
0000798fc6fdd897  pop rdi
0000798fc6fdd898  pop rdx
0000798fc6fdd899  pop rcx
0000798fc6fdd89a  pop rax
0000798fc6fdd89b  add rsp, 0x08
0000798fc6fdd89f  jmp 0x0000798FC6FDBE5A
0000798fc6fdd8a4  sub rsp, 0x08
0000798fc6fdd8a8  push rax
0000798fc6fdd8a9  push rcx
0000798fc6fdd8aa  push rdx
0000798fc6fdd8ab  push rdi
0000798fc6fdd8ac  push rsi
0000798fc6fdd8ad  push r8
0000798fc6fdd8af  push r9
0000798fc6fdd8b1  push r10
0000798fc6fdd8b3  push r11
0000798fc6fdd8b5  sub rsp, 0xF0
0000798fc6fdd8bc  vmovaps [rsp], xmm0
0000798fc6fdd8c1  vmovaps [rsp+0x10], xmm1
0000798fc6fdd8c7  vmovaps [rsp+0x20], xmm2
0000798fc6fdd8cd  vmovaps [rsp+0x30], xmm3
0000798fc6fdd8d3  vmovaps [rsp+0x40], xmm4
0000798fc6fdd8d9  vmovaps [rsp+0x50], xmm5
0000798fc6fdd8df  vmovaps [rsp+0x60], xmm6
0000798fc6fdd8e5  vmovaps [rsp+0x70], xmm8
0000798fc6fdd8eb  vmovaps [rsp+0x80], xmm9
0000798fc6fdd8f4  vmovaps [rsp+0x90], xmm10
0000798fc6fdd8fd  vmovaps [rsp+0xA0], xmm11
0000798fc6fdd906  vmovaps [rsp+0xB0], xmm12
0000798fc6fdd90f  vmovaps [rsp+0xC0], xmm13
0000798fc6fdd918  vmovaps [rsp+0xD0], xmm14
0000798fc6fdd921  vmovaps [rsp+0xE0], xmm15
0000798fc6fdd92a  sub rsp, 0x30
0000798fc6fdd92e  movaps [rsp], xmm7
0000798fc6fdd932  movaps [rsp+0x10], xmm4
0000798fc6fdd937  movaps [rsp+0x20], xmm9
0000798fc6fdd93d  lea rdi, [rsp]
0000798fc6fdd941  mov esi, 0x00
0000798fc6fdd946  mov rax, 0x63E558B23530
0000798fc6fdd950  call rax
0000798fc6fdd952  movaps xmm7, [rsp]
0000798fc6fdd956  add rsp, 0x30
0000798fc6fdd95a  vmovaps xmm0, [rsp]
0000798fc6fdd95f  vmovaps xmm1, [rsp+0x10]
0000798fc6fdd965  vmovaps xmm2, [rsp+0x20]
0000798fc6fdd96b  vmovaps xmm3, [rsp+0x30]
0000798fc6fdd971  vmovaps xmm4, [rsp+0x40]
0000798fc6fdd977  vmovaps xmm5, [rsp+0x50]
0000798fc6fdd97d  vmovaps xmm6, [rsp+0x60]
0000798fc6fdd983  vmovaps xmm8, [rsp+0x70]
0000798fc6fdd989  vmovaps xmm9, [rsp+0x80]
0000798fc6fdd992  vmovaps xmm10, [rsp+0x90]
0000798fc6fdd99b  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdd9a4  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdd9ad  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdd9b6  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdd9bf  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdd9c8  add rsp, 0xF0
0000798fc6fdd9cf  pop r11
0000798fc6fdd9d1  pop r10
0000798fc6fdd9d3  pop r9
0000798fc6fdd9d5  pop r8
0000798fc6fdd9d7  pop rsi
0000798fc6fdd9d8  pop rdi
0000798fc6fdd9d9  pop rdx
0000798fc6fdd9da  pop rcx
0000798fc6fdd9db  pop rax
0000798fc6fdd9dc  add rsp, 0x08
0000798fc6fdd9e0  jmp 0x0000798FC6FDBE87
0000798fc6fdd9e5  sub rsp, 0x08
0000798fc6fdd9e9  push rax
0000798fc6fdd9ea  push rcx
0000798fc6fdd9eb  push rdx
0000798fc6fdd9ec  push rdi
0000798fc6fdd9ed  push rsi
0000798fc6fdd9ee  push r8
0000798fc6fdd9f0  push r9
0000798fc6fdd9f2  push r10
0000798fc6fdd9f4  push r11
0000798fc6fdd9f6  sub rsp, 0xF0
0000798fc6fdd9fd  vmovaps [rsp], xmm0
0000798fc6fdda02  vmovaps [rsp+0x10], xmm1
0000798fc6fdda08  vmovaps [rsp+0x20], xmm2
0000798fc6fdda0e  vmovaps [rsp+0x30], xmm3
0000798fc6fdda14  vmovaps [rsp+0x40], xmm5
0000798fc6fdda1a  vmovaps [rsp+0x50], xmm6
0000798fc6fdda20  vmovaps [rsp+0x60], xmm7
0000798fc6fdda26  vmovaps [rsp+0x70], xmm8
0000798fc6fdda2c  vmovaps [rsp+0x80], xmm9
0000798fc6fdda35  vmovaps [rsp+0x90], xmm10
0000798fc6fdda3e  vmovaps [rsp+0xA0], xmm11
0000798fc6fdda47  vmovaps [rsp+0xB0], xmm12
0000798fc6fdda50  vmovaps [rsp+0xC0], xmm13
0000798fc6fdda59  vmovaps [rsp+0xD0], xmm14
0000798fc6fdda62  vmovaps [rsp+0xE0], xmm15
0000798fc6fdda6b  sub rsp, 0x30
0000798fc6fdda6f  movaps [rsp], xmm4
0000798fc6fdda73  movaps [rsp+0x10], xmm15
0000798fc6fdda79  movaps [rsp+0x20], xmm9
0000798fc6fdda7f  lea rdi, [rsp]
0000798fc6fdda83  mov esi, 0x00
0000798fc6fdda88  mov rax, 0x63E558B23530
0000798fc6fdda92  call rax
0000798fc6fdda94  movaps xmm4, [rsp]
0000798fc6fdda98  add rsp, 0x30
0000798fc6fdda9c  vmovaps xmm0, [rsp]
0000798fc6fddaa1  vmovaps xmm1, [rsp+0x10]
0000798fc6fddaa7  vmovaps xmm2, [rsp+0x20]
0000798fc6fddaad  vmovaps xmm3, [rsp+0x30]
0000798fc6fddab3  vmovaps xmm5, [rsp+0x40]
0000798fc6fddab9  vmovaps xmm6, [rsp+0x50]
0000798fc6fddabf  vmovaps xmm7, [rsp+0x60]
0000798fc6fddac5  vmovaps xmm8, [rsp+0x70]
0000798fc6fddacb  vmovaps xmm9, [rsp+0x80]
0000798fc6fddad4  vmovaps xmm10, [rsp+0x90]
0000798fc6fddadd  vmovaps xmm11, [rsp+0xA0]
0000798fc6fddae6  vmovaps xmm12, [rsp+0xB0]
0000798fc6fddaef  vmovaps xmm13, [rsp+0xC0]
0000798fc6fddaf8  vmovaps xmm14, [rsp+0xD0]
0000798fc6fddb01  vmovaps xmm15, [rsp+0xE0]
0000798fc6fddb0a  add rsp, 0xF0
0000798fc6fddb11  pop r11
0000798fc6fddb13  pop r10
0000798fc6fddb15  pop r9
0000798fc6fddb17  pop r8
0000798fc6fddb19  pop rsi
0000798fc6fddb1a  pop rdi
0000798fc6fddb1b  pop rdx
0000798fc6fddb1c  pop rcx
0000798fc6fddb1d  pop rax
0000798fc6fddb1e  add rsp, 0x08
0000798fc6fddb22  jmp 0x0000798FC6FDBEAC
0000798fc6fddb27  call 0x0000798FC6EC4620
0000798fc6fddb2c  jmp 0x0000798FC6FDBEB9
0000798fc6fddb31  sub rsp, 0x08
0000798fc6fddb35  push rax
0000798fc6fddb36  push rcx
0000798fc6fddb37  push rdx
0000798fc6fddb38  push rdi
0000798fc6fddb39  push rsi
0000798fc6fddb3a  push r8
0000798fc6fddb3c  push r9
0000798fc6fddb3e  push r10
0000798fc6fddb40  push r11
0000798fc6fddb42  sub rsp, 0xF0
0000798fc6fddb49  vmovaps [rsp], xmm0
0000798fc6fddb4e  vmovaps [rsp+0x10], xmm1
0000798fc6fddb54  vmovaps [rsp+0x20], xmm2
0000798fc6fddb5a  vmovaps [rsp+0x30], xmm4
0000798fc6fddb60  vmovaps [rsp+0x40], xmm5
0000798fc6fddb66  vmovaps [rsp+0x50], xmm6
0000798fc6fddb6c  vmovaps [rsp+0x60], xmm7
0000798fc6fddb72  vmovaps [rsp+0x70], xmm8
0000798fc6fddb78  vmovaps [rsp+0x80], xmm9
0000798fc6fddb81  vmovaps [rsp+0x90], xmm10
0000798fc6fddb8a  vmovaps [rsp+0xA0], xmm11
0000798fc6fddb93  vmovaps [rsp+0xB0], xmm12
0000798fc6fddb9c  vmovaps [rsp+0xC0], xmm13
0000798fc6fddba5  vmovaps [rsp+0xD0], xmm14
0000798fc6fddbae  vmovaps [rsp+0xE0], xmm15
0000798fc6fddbb7  sub rsp, 0x30
0000798fc6fddbbb  movaps [rsp], xmm3
0000798fc6fddbbf  movaps [rsp+0x10], xmm1
0000798fc6fddbc4  movaps [rsp+0x20], xmm9
0000798fc6fddbca  lea rdi, [rsp]
0000798fc6fddbce  mov esi, 0x00
0000798fc6fddbd3  mov rax, 0x63E558B23530
0000798fc6fddbdd  call rax
0000798fc6fddbdf  movaps xmm3, [rsp]
0000798fc6fddbe3  add rsp, 0x30
0000798fc6fddbe7  vmovaps xmm0, [rsp]
0000798fc6fddbec  vmovaps xmm1, [rsp+0x10]
0000798fc6fddbf2  vmovaps xmm2, [rsp+0x20]
0000798fc6fddbf8  vmovaps xmm4, [rsp+0x30]
0000798fc6fddbfe  vmovaps xmm5, [rsp+0x40]
0000798fc6fddc04  vmovaps xmm6, [rsp+0x50]
0000798fc6fddc0a  vmovaps xmm7, [rsp+0x60]
0000798fc6fddc10  vmovaps xmm8, [rsp+0x70]
0000798fc6fddc16  vmovaps xmm9, [rsp+0x80]
0000798fc6fddc1f  vmovaps xmm10, [rsp+0x90]
0000798fc6fddc28  vmovaps xmm11, [rsp+0xA0]
0000798fc6fddc31  vmovaps xmm12, [rsp+0xB0]
0000798fc6fddc3a  vmovaps xmm13, [rsp+0xC0]
0000798fc6fddc43  vmovaps xmm14, [rsp+0xD0]
0000798fc6fddc4c  vmovaps xmm15, [rsp+0xE0]
0000798fc6fddc55  add rsp, 0xF0
0000798fc6fddc5c  pop r11
0000798fc6fddc5e  pop r10
0000798fc6fddc60  pop r9
0000798fc6fddc62  pop r8
0000798fc6fddc64  pop rsi
0000798fc6fddc65  pop rdi
0000798fc6fddc66  pop rdx
0000798fc6fddc67  pop rcx
0000798fc6fddc68  pop rax
0000798fc6fddc69  add rsp, 0x08
0000798fc6fddc6d  jmp 0x0000798FC6FDBEF6
0000798fc6fddc72  sub rsp, 0x08
0000798fc6fddc76  push rax
0000798fc6fddc77  push rcx
0000798fc6fddc78  push rdx
0000798fc6fddc79  push rdi
0000798fc6fddc7a  push rsi
0000798fc6fddc7b  push r8
0000798fc6fddc7d  push r9
0000798fc6fddc7f  push r10
0000798fc6fddc81  push r11
0000798fc6fddc83  sub rsp, 0xF0
0000798fc6fddc8a  vmovaps [rsp], xmm0
0000798fc6fddc8f  vmovaps [rsp+0x10], xmm2
0000798fc6fddc95  vmovaps [rsp+0x20], xmm3
0000798fc6fddc9b  vmovaps [rsp+0x30], xmm4
0000798fc6fddca1  vmovaps [rsp+0x40], xmm5
0000798fc6fddca7  vmovaps [rsp+0x50], xmm6
0000798fc6fddcad  vmovaps [rsp+0x60], xmm7
0000798fc6fddcb3  vmovaps [rsp+0x70], xmm8
0000798fc6fddcb9  vmovaps [rsp+0x80], xmm9
0000798fc6fddcc2  vmovaps [rsp+0x90], xmm10
0000798fc6fddccb  vmovaps [rsp+0xA0], xmm11
0000798fc6fddcd4  vmovaps [rsp+0xB0], xmm12
0000798fc6fddcdd  vmovaps [rsp+0xC0], xmm13
0000798fc6fddce6  vmovaps [rsp+0xD0], xmm14
0000798fc6fddcef  vmovaps [rsp+0xE0], xmm15
0000798fc6fddcf8  sub rsp, 0x30
0000798fc6fddcfc  movaps [rsp], xmm1
0000798fc6fddd00  movaps [rsp+0x10], xmm15
0000798fc6fddd06  movaps [rsp+0x20], xmm9
0000798fc6fddd0c  lea rdi, [rsp]
0000798fc6fddd10  mov esi, 0x00
0000798fc6fddd15  mov rax, 0x63E558B23530
0000798fc6fddd1f  call rax
0000798fc6fddd21  movaps xmm1, [rsp]
0000798fc6fddd25  add rsp, 0x30
0000798fc6fddd29  vmovaps xmm0, [rsp]
0000798fc6fddd2e  vmovaps xmm2, [rsp+0x10]
0000798fc6fddd34  vmovaps xmm3, [rsp+0x20]
0000798fc6fddd3a  vmovaps xmm4, [rsp+0x30]
0000798fc6fddd40  vmovaps xmm5, [rsp+0x40]
0000798fc6fddd46  vmovaps xmm6, [rsp+0x50]
0000798fc6fddd4c  vmovaps xmm7, [rsp+0x60]
0000798fc6fddd52  vmovaps xmm8, [rsp+0x70]
0000798fc6fddd58  vmovaps xmm9, [rsp+0x80]
0000798fc6fddd61  vmovaps xmm10, [rsp+0x90]
0000798fc6fddd6a  vmovaps xmm11, [rsp+0xA0]
0000798fc6fddd73  vmovaps xmm12, [rsp+0xB0]
0000798fc6fddd7c  vmovaps xmm13, [rsp+0xC0]
0000798fc6fddd85  vmovaps xmm14, [rsp+0xD0]
0000798fc6fddd8e  vmovaps xmm15, [rsp+0xE0]
0000798fc6fddd97  add rsp, 0xF0
0000798fc6fddd9e  pop r11
0000798fc6fddda0  pop r10
0000798fc6fddda2  pop r9
0000798fc6fddda4  pop r8
0000798fc6fddda6  pop rsi
0000798fc6fddda7  pop rdi
0000798fc6fddda8  pop rdx
0000798fc6fddda9  pop rcx
0000798fc6fdddaa  pop rax
0000798fc6fdddab  add rsp, 0x08
0000798fc6fdddaf  jmp 0x0000798FC6FDBF7E
0000798fc6fdddb4  call 0x0000798FC6EC4620
0000798fc6fdddb9  jmp 0x0000798FC6FDBF8B
0000798fc6fdddbe  sub rsp, 0x08
0000798fc6fdddc2  push rax
0000798fc6fdddc3  push rcx
0000798fc6fdddc4  push rdx
0000798fc6fdddc5  push rdi
0000798fc6fdddc6  push rsi
0000798fc6fdddc7  push r8
0000798fc6fdddc9  push r9
0000798fc6fdddcb  push r10
0000798fc6fdddcd  push r11
0000798fc6fdddcf  sub rsp, 0xF0
0000798fc6fdddd6  vmovaps [rsp], xmm0
0000798fc6fddddb  vmovaps [rsp+0x10], xmm2
0000798fc6fddde1  vmovaps [rsp+0x20], xmm3
0000798fc6fddde7  vmovaps [rsp+0x30], xmm4
0000798fc6fddded  vmovaps [rsp+0x40], xmm5
0000798fc6fdddf3  vmovaps [rsp+0x50], xmm6
0000798fc6fdddf9  vmovaps [rsp+0x60], xmm7
0000798fc6fdddff  vmovaps [rsp+0x70], xmm8
0000798fc6fdde05  vmovaps [rsp+0x80], xmm9
0000798fc6fdde0e  vmovaps [rsp+0x90], xmm10
0000798fc6fdde17  vmovaps [rsp+0xA0], xmm11
0000798fc6fdde20  vmovaps [rsp+0xB0], xmm12
0000798fc6fdde29  vmovaps [rsp+0xC0], xmm13
0000798fc6fdde32  vmovaps [rsp+0xD0], xmm14
0000798fc6fdde3b  vmovaps [rsp+0xE0], xmm15
0000798fc6fdde44  sub rsp, 0x30
0000798fc6fdde48  movaps [rsp], xmm1
0000798fc6fdde4c  movaps [rsp+0x10], xmm5
0000798fc6fdde51  movaps [rsp+0x20], xmm7
0000798fc6fdde56  lea rdi, [rsp]
0000798fc6fdde5a  mov esi, 0x00
0000798fc6fdde5f  mov rax, 0x63E558B23530
0000798fc6fdde69  call rax
0000798fc6fdde6b  movaps xmm1, [rsp]
0000798fc6fdde6f  add rsp, 0x30
0000798fc6fdde73  vmovaps xmm0, [rsp]
0000798fc6fdde78  vmovaps xmm2, [rsp+0x10]
0000798fc6fdde7e  vmovaps xmm3, [rsp+0x20]
0000798fc6fdde84  vmovaps xmm4, [rsp+0x30]
0000798fc6fdde8a  vmovaps xmm5, [rsp+0x40]
0000798fc6fdde90  vmovaps xmm6, [rsp+0x50]
0000798fc6fdde96  vmovaps xmm7, [rsp+0x60]
0000798fc6fdde9c  vmovaps xmm8, [rsp+0x70]
0000798fc6fddea2  vmovaps xmm9, [rsp+0x80]
0000798fc6fddeab  vmovaps xmm10, [rsp+0x90]
0000798fc6fddeb4  vmovaps xmm11, [rsp+0xA0]
0000798fc6fddebd  vmovaps xmm12, [rsp+0xB0]
0000798fc6fddec6  vmovaps xmm13, [rsp+0xC0]
0000798fc6fddecf  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdded8  vmovaps xmm15, [rsp+0xE0]
0000798fc6fddee1  add rsp, 0xF0
0000798fc6fddee8  pop r11
0000798fc6fddeea  pop r10
0000798fc6fddeec  pop r9
0000798fc6fddeee  pop r8
0000798fc6fddef0  pop rsi
0000798fc6fddef1  pop rdi
0000798fc6fddef2  pop rdx
0000798fc6fddef3  pop rcx
0000798fc6fddef4  pop rax
0000798fc6fddef5  add rsp, 0x08
0000798fc6fddef9  jmp 0x0000798FC6FDC030
0000798fc6fddefe  sub rsp, 0x08
0000798fc6fddf02  push rax
0000798fc6fddf03  push rcx
0000798fc6fddf04  push rdx
0000798fc6fddf05  push rdi
0000798fc6fddf06  push rsi
0000798fc6fddf07  push r8
0000798fc6fddf09  push r9
0000798fc6fddf0b  push r10
0000798fc6fddf0d  push r11
0000798fc6fddf0f  sub rsp, 0xF0
0000798fc6fddf16  vmovaps [rsp], xmm0
0000798fc6fddf1b  vmovaps [rsp+0x10], xmm1
0000798fc6fddf21  vmovaps [rsp+0x20], xmm2
0000798fc6fddf27  vmovaps [rsp+0x30], xmm3
0000798fc6fddf2d  vmovaps [rsp+0x40], xmm4
0000798fc6fddf33  vmovaps [rsp+0x50], xmm5
0000798fc6fddf39  vmovaps [rsp+0x60], xmm6
0000798fc6fddf3f  vmovaps [rsp+0x70], xmm8
0000798fc6fddf45  vmovaps [rsp+0x80], xmm9
0000798fc6fddf4e  vmovaps [rsp+0x90], xmm10
0000798fc6fddf57  vmovaps [rsp+0xA0], xmm11
0000798fc6fddf60  vmovaps [rsp+0xB0], xmm12
0000798fc6fddf69  vmovaps [rsp+0xC0], xmm13
0000798fc6fddf72  vmovaps [rsp+0xD0], xmm14
0000798fc6fddf7b  vmovaps [rsp+0xE0], xmm15
0000798fc6fddf84  sub rsp, 0x30
0000798fc6fddf88  movaps [rsp], xmm7
0000798fc6fddf8c  movaps [rsp+0x10], xmm5
0000798fc6fddf91  movaps [rsp+0x20], xmm15
0000798fc6fddf97  lea rdi, [rsp]
0000798fc6fddf9b  mov esi, 0x00
0000798fc6fddfa0  mov rax, 0x63E558B23530
0000798fc6fddfaa  call rax
0000798fc6fddfac  movaps xmm7, [rsp]
0000798fc6fddfb0  add rsp, 0x30
0000798fc6fddfb4  vmovaps xmm0, [rsp]
0000798fc6fddfb9  vmovaps xmm1, [rsp+0x10]
0000798fc6fddfbf  vmovaps xmm2, [rsp+0x20]
0000798fc6fddfc5  vmovaps xmm3, [rsp+0x30]
0000798fc6fddfcb  vmovaps xmm4, [rsp+0x40]
0000798fc6fddfd1  vmovaps xmm5, [rsp+0x50]
0000798fc6fddfd7  vmovaps xmm6, [rsp+0x60]
0000798fc6fddfdd  vmovaps xmm8, [rsp+0x70]
0000798fc6fddfe3  vmovaps xmm9, [rsp+0x80]
0000798fc6fddfec  vmovaps xmm10, [rsp+0x90]
0000798fc6fddff5  vmovaps xmm11, [rsp+0xA0]
0000798fc6fddffe  vmovaps xmm12, [rsp+0xB0]
0000798fc6fde007  vmovaps xmm13, [rsp+0xC0]
0000798fc6fde010  vmovaps xmm14, [rsp+0xD0]
0000798fc6fde019  vmovaps xmm15, [rsp+0xE0]
0000798fc6fde022  add rsp, 0xF0
0000798fc6fde029  pop r11
0000798fc6fde02b  pop r10
0000798fc6fde02d  pop r9
0000798fc6fde02f  pop r8
0000798fc6fde031  pop rsi
0000798fc6fde032  pop rdi
0000798fc6fde033  pop rdx
0000798fc6fde034  pop rcx
0000798fc6fde035  pop rax
0000798fc6fde036  add rsp, 0x08
0000798fc6fde03a  jmp 0x0000798FC6FDC066
0000798fc6fde03f  call 0x0000798FC6EB52F0
0000798fc6fde044  jmp 0x0000798FC6FDC073
0000798fc6fde049  sub rsp, 0x08
0000798fc6fde04d  push rax
0000798fc6fde04e  push rcx
0000798fc6fde04f  push rdx
0000798fc6fde050  push rdi
0000798fc6fde051  push rsi
0000798fc6fde052  push r8
0000798fc6fde054  push r9
0000798fc6fde056  push r10
0000798fc6fde058  push r11
0000798fc6fde05a  sub rsp, 0xF0
0000798fc6fde061  vmovaps [rsp], xmm0
0000798fc6fde066  vmovaps [rsp+0x10], xmm1
0000798fc6fde06c  vmovaps [rsp+0x20], xmm2
0000798fc6fde072  vmovaps [rsp+0x30], xmm3
0000798fc6fde078  vmovaps [rsp+0x40], xmm4
0000798fc6fde07e  vmovaps [rsp+0x50], xmm5
0000798fc6fde084  vmovaps [rsp+0x60], xmm6
0000798fc6fde08a  vmovaps [rsp+0x70], xmm7
0000798fc6fde090  vmovaps [rsp+0x80], xmm8
0000798fc6fde099  vmovaps [rsp+0x90], xmm9
0000798fc6fde0a2  vmovaps [rsp+0xA0], xmm10
0000798fc6fde0ab  vmovaps [rsp+0xB0], xmm11
0000798fc6fde0b4  vmovaps [rsp+0xC0], xmm12
0000798fc6fde0bd  vmovaps [rsp+0xD0], xmm13
0000798fc6fde0c6  vmovaps [rsp+0xE0], xmm14
0000798fc6fde0cf  sub rsp, 0x30
0000798fc6fde0d3  movaps [rsp], xmm15
0000798fc6fde0d8  movaps [rsp+0x10], xmm5
0000798fc6fde0dd  movaps [rsp+0x20], xmm3
0000798fc6fde0e2  lea rdi, [rsp]
0000798fc6fde0e6  mov esi, 0x00
0000798fc6fde0eb  mov rax, 0x63E558B23530
0000798fc6fde0f5  call rax
0000798fc6fde0f7  movaps xmm15, [rsp]
0000798fc6fde0fc  add rsp, 0x30
0000798fc6fde100  vmovaps xmm0, [rsp]
0000798fc6fde105  vmovaps xmm1, [rsp+0x10]
0000798fc6fde10b  vmovaps xmm2, [rsp+0x20]
0000798fc6fde111  vmovaps xmm3, [rsp+0x30]
0000798fc6fde117  vmovaps xmm4, [rsp+0x40]
0000798fc6fde11d  vmovaps xmm5, [rsp+0x50]
0000798fc6fde123  vmovaps xmm6, [rsp+0x60]
0000798fc6fde129  vmovaps xmm7, [rsp+0x70]
0000798fc6fde12f  vmovaps xmm8, [rsp+0x80]
0000798fc6fde138  vmovaps xmm9, [rsp+0x90]
0000798fc6fde141  vmovaps xmm10, [rsp+0xA0]
0000798fc6fde14a  vmovaps xmm11, [rsp+0xB0]
0000798fc6fde153  vmovaps xmm12, [rsp+0xC0]
0000798fc6fde15c  vmovaps xmm13, [rsp+0xD0]
0000798fc6fde165  vmovaps xmm14, [rsp+0xE0]
0000798fc6fde16e  add rsp, 0xF0
0000798fc6fde175  pop r11
0000798fc6fde177  pop r10
0000798fc6fde179  pop r9
0000798fc6fde17b  pop r8
0000798fc6fde17d  pop rsi
0000798fc6fde17e  pop rdi
0000798fc6fde17f  pop rdx
0000798fc6fde180  pop rcx
0000798fc6fde181  pop rax
0000798fc6fde182  add rsp, 0x08
0000798fc6fde186  jmp 0x0000798FC6FDC099
0000798fc6fde18b  sub rsp, 0x08
0000798fc6fde18f  push rax
0000798fc6fde190  push rcx
0000798fc6fde191  push rdx
0000798fc6fde192  push rdi
0000798fc6fde193  push rsi
0000798fc6fde194  push r8
0000798fc6fde196  push r9
0000798fc6fde198  push r10
0000798fc6fde19a  push r11
0000798fc6fde19c  sub rsp, 0xF0
0000798fc6fde1a3  vmovaps [rsp], xmm0
0000798fc6fde1a8  vmovaps [rsp+0x10], xmm2
0000798fc6fde1ae  vmovaps [rsp+0x20], xmm3
0000798fc6fde1b4  vmovaps [rsp+0x30], xmm4
0000798fc6fde1ba  vmovaps [rsp+0x40], xmm5
0000798fc6fde1c0  vmovaps [rsp+0x50], xmm6
0000798fc6fde1c6  vmovaps [rsp+0x60], xmm7
0000798fc6fde1cc  vmovaps [rsp+0x70], xmm8
0000798fc6fde1d2  vmovaps [rsp+0x80], xmm9
0000798fc6fde1db  vmovaps [rsp+0x90], xmm10
0000798fc6fde1e4  vmovaps [rsp+0xA0], xmm11
0000798fc6fde1ed  vmovaps [rsp+0xB0], xmm12
0000798fc6fde1f6  vmovaps [rsp+0xC0], xmm13
0000798fc6fde1ff  vmovaps [rsp+0xD0], xmm14
0000798fc6fde208  vmovaps [rsp+0xE0], xmm15
0000798fc6fde211  sub rsp, 0x30
0000798fc6fde215  movaps [rsp], xmm1
0000798fc6fde219  movaps [rsp+0x10], xmm5
0000798fc6fde21e  movaps [rsp+0x20], xmm4
0000798fc6fde223  lea rdi, [rsp]
0000798fc6fde227  mov esi, 0x00
0000798fc6fde22c  mov rax, 0x63E558B23530
0000798fc6fde236  call rax
0000798fc6fde238  movaps xmm1, [rsp]
0000798fc6fde23c  add rsp, 0x30
0000798fc6fde240  vmovaps xmm0, [rsp]
0000798fc6fde245  vmovaps xmm2, [rsp+0x10]
0000798fc6fde24b  vmovaps xmm3, [rsp+0x20]
0000798fc6fde251  vmovaps xmm4, [rsp+0x30]
0000798fc6fde257  vmovaps xmm5, [rsp+0x40]
0000798fc6fde25d  vmovaps xmm6, [rsp+0x50]
0000798fc6fde263  vmovaps xmm7, [rsp+0x60]
0000798fc6fde269  vmovaps xmm8, [rsp+0x70]
0000798fc6fde26f  vmovaps xmm9, [rsp+0x80]
0000798fc6fde278  vmovaps xmm10, [rsp+0x90]
0000798fc6fde281  vmovaps xmm11, [rsp+0xA0]
0000798fc6fde28a  vmovaps xmm12, [rsp+0xB0]
0000798fc6fde293  vmovaps xmm13, [rsp+0xC0]
0000798fc6fde29c  vmovaps xmm14, [rsp+0xD0]
0000798fc6fde2a5  vmovaps xmm15, [rsp+0xE0]
0000798fc6fde2ae  add rsp, 0xF0
0000798fc6fde2b5  pop r11
0000798fc6fde2b7  pop r10
0000798fc6fde2b9  pop r9
0000798fc6fde2bb  pop r8
0000798fc6fde2bd  pop rsi
0000798fc6fde2be  pop rdi
0000798fc6fde2bf  pop rdx
0000798fc6fde2c0  pop rcx
0000798fc6fde2c1  pop rax
0000798fc6fde2c2  add rsp, 0x08
0000798fc6fde2c6  jmp 0x0000798FC6FDC0B9
0000798fc6fde2cb  sub rsp, 0x08
0000798fc6fde2cf  push rax
0000798fc6fde2d0  push rcx
0000798fc6fde2d1  push rdx
0000798fc6fde2d2  push rdi
0000798fc6fde2d3  push rsi
0000798fc6fde2d4  push r8
0000798fc6fde2d6  push r9
0000798fc6fde2d8  push r10
0000798fc6fde2da  push r11
0000798fc6fde2dc  sub rsp, 0xF0
0000798fc6fde2e3  vmovaps [rsp], xmm0
0000798fc6fde2e8  vmovaps [rsp+0x10], xmm1
0000798fc6fde2ee  vmovaps [rsp+0x20], xmm2
0000798fc6fde2f4  vmovaps [rsp+0x30], xmm3
0000798fc6fde2fa  vmovaps [rsp+0x40], xmm5
0000798fc6fde300  vmovaps [rsp+0x50], xmm6
0000798fc6fde306  vmovaps [rsp+0x60], xmm7
0000798fc6fde30c  vmovaps [rsp+0x70], xmm8
0000798fc6fde312  vmovaps [rsp+0x80], xmm9
0000798fc6fde31b  vmovaps [rsp+0x90], xmm10
0000798fc6fde324  vmovaps [rsp+0xA0], xmm11
0000798fc6fde32d  vmovaps [rsp+0xB0], xmm12
0000798fc6fde336  vmovaps [rsp+0xC0], xmm13
0000798fc6fde33f  vmovaps [rsp+0xD0], xmm14
0000798fc6fde348  vmovaps [rsp+0xE0], xmm15
0000798fc6fde351  sub rsp, 0x30
0000798fc6fde355  movaps [rsp], xmm4
0000798fc6fde359  movaps [rsp+0x10], xmm3
0000798fc6fde35e  movaps [rsp+0x20], xmm5
0000798fc6fde363  lea rdi, [rsp]
0000798fc6fde367  mov esi, 0x00
0000798fc6fde36c  mov rax, 0x63E558B23530
0000798fc6fde376  call rax
0000798fc6fde378  movaps xmm4, [rsp]
0000798fc6fde37c  add rsp, 0x30
0000798fc6fde380  vmovaps xmm0, [rsp]
0000798fc6fde385  vmovaps xmm1, [rsp+0x10]
0000798fc6fde38b  vmovaps xmm2, [rsp+0x20]
0000798fc6fde391  vmovaps xmm3, [rsp+0x30]
0000798fc6fde397  vmovaps xmm5, [rsp+0x40]
0000798fc6fde39d  vmovaps xmm6, [rsp+0x50]
0000798fc6fde3a3  vmovaps xmm7, [rsp+0x60]
0000798fc6fde3a9  vmovaps xmm8, [rsp+0x70]
0000798fc6fde3af  vmovaps xmm9, [rsp+0x80]
0000798fc6fde3b8  vmovaps xmm10, [rsp+0x90]
0000798fc6fde3c1  vmovaps xmm11, [rsp+0xA0]
0000798fc6fde3ca  vmovaps xmm12, [rsp+0xB0]
0000798fc6fde3d3  vmovaps xmm13, [rsp+0xC0]
0000798fc6fde3dc  vmovaps xmm14, [rsp+0xD0]
0000798fc6fde3e5  vmovaps xmm15, [rsp+0xE0]
0000798fc6fde3ee  add rsp, 0xF0
0000798fc6fde3f5  pop r11
0000798fc6fde3f7  pop r10
0000798fc6fde3f9  pop r9
0000798fc6fde3fb  pop r8
0000798fc6fde3fd  pop rsi
0000798fc6fde3fe  pop rdi
0000798fc6fde3ff  pop rdx
0000798fc6fde400  pop rcx
0000798fc6fde401  pop rax
0000798fc6fde402  add rsp, 0x08
0000798fc6fde406  jmp 0x0000798FC6FDC107
0000798fc6fde40b  call 0x0000798FC6EB52F0
0000798fc6fde410  jmp 0x0000798FC6FDC114
0000798fc6fde415  sub rsp, 0x08
0000798fc6fde419  push rax
0000798fc6fde41a  push rcx
0000798fc6fde41b  push rdx
0000798fc6fde41c  push rdi
0000798fc6fde41d  push rsi
0000798fc6fde41e  push r8
0000798fc6fde420  push r9
0000798fc6fde422  push r10
0000798fc6fde424  push r11
0000798fc6fde426  sub rsp, 0xF0
0000798fc6fde42d  vmovaps [rsp], xmm0
0000798fc6fde432  vmovaps [rsp+0x10], xmm1
0000798fc6fde438  vmovaps [rsp+0x20], xmm2
0000798fc6fde43e  vmovaps [rsp+0x30], xmm3
0000798fc6fde444  vmovaps [rsp+0x40], xmm4
0000798fc6fde44a  vmovaps [rsp+0x50], xmm6
0000798fc6fde450  vmovaps [rsp+0x60], xmm7
0000798fc6fde456  vmovaps [rsp+0x70], xmm8
0000798fc6fde45c  vmovaps [rsp+0x80], xmm9
0000798fc6fde465  vmovaps [rsp+0x90], xmm10
0000798fc6fde46e  vmovaps [rsp+0xA0], xmm11
0000798fc6fde477  vmovaps [rsp+0xB0], xmm12
0000798fc6fde480  vmovaps [rsp+0xC0], xmm13
0000798fc6fde489  vmovaps [rsp+0xD0], xmm14
0000798fc6fde492  vmovaps [rsp+0xE0], xmm15
0000798fc6fde49b  sub rsp, 0x30
0000798fc6fde49f  movaps [rsp], xmm5
0000798fc6fde4a3  movaps [rsp+0x10], xmm6
0000798fc6fde4a8  movaps [rsp+0x20], xmm3
0000798fc6fde4ad  lea rdi, [rsp]
0000798fc6fde4b1  mov esi, 0x00
0000798fc6fde4b6  mov rax, 0x63E558B23530
0000798fc6fde4c0  call rax
0000798fc6fde4c2  movaps xmm5, [rsp]
0000798fc6fde4c6  add rsp, 0x30
0000798fc6fde4ca  vmovaps xmm0, [rsp]
0000798fc6fde4cf  vmovaps xmm1, [rsp+0x10]
0000798fc6fde4d5  vmovaps xmm2, [rsp+0x20]
0000798fc6fde4db  vmovaps xmm3, [rsp+0x30]
0000798fc6fde4e1  vmovaps xmm4, [rsp+0x40]
0000798fc6fde4e7  vmovaps xmm6, [rsp+0x50]
0000798fc6fde4ed  vmovaps xmm7, [rsp+0x60]
0000798fc6fde4f3  vmovaps xmm8, [rsp+0x70]
0000798fc6fde4f9  vmovaps xmm9, [rsp+0x80]
0000798fc6fde502  vmovaps xmm10, [rsp+0x90]
0000798fc6fde50b  vmovaps xmm11, [rsp+0xA0]
0000798fc6fde514  vmovaps xmm12, [rsp+0xB0]
0000798fc6fde51d  vmovaps xmm13, [rsp+0xC0]
0000798fc6fde526  vmovaps xmm14, [rsp+0xD0]
0000798fc6fde52f  vmovaps xmm15, [rsp+0xE0]
0000798fc6fde538  add rsp, 0xF0
0000798fc6fde53f  pop r11
0000798fc6fde541  pop r10
0000798fc6fde543  pop r9
0000798fc6fde545  pop r8
0000798fc6fde547  pop rsi
0000798fc6fde548  pop rdi
0000798fc6fde549  pop rdx
0000798fc6fde54a  pop rcx
0000798fc6fde54b  pop rax
0000798fc6fde54c  add rsp, 0x08
0000798fc6fde550  jmp 0x0000798FC6FDC13A
0000798fc6fde555  sub rsp, 0x08
0000798fc6fde559  push rax
0000798fc6fde55a  push rcx
0000798fc6fde55b  push rdx
0000798fc6fde55c  push rdi
0000798fc6fde55d  push rsi
0000798fc6fde55e  push r8
0000798fc6fde560  push r9
0000798fc6fde562  push r10
0000798fc6fde564  push r11
0000798fc6fde566  sub rsp, 0xF0
0000798fc6fde56d  vmovaps [rsp], xmm0
0000798fc6fde572  vmovaps [rsp+0x10], xmm1
0000798fc6fde578  vmovaps [rsp+0x20], xmm2
0000798fc6fde57e  vmovaps [rsp+0x30], xmm3
0000798fc6fde584  vmovaps [rsp+0x40], xmm4
0000798fc6fde58a  vmovaps [rsp+0x50], xmm5
0000798fc6fde590  vmovaps [rsp+0x60], xmm7
0000798fc6fde596  vmovaps [rsp+0x70], xmm8
0000798fc6fde59c  vmovaps [rsp+0x80], xmm9
0000798fc6fde5a5  vmovaps [rsp+0x90], xmm10
0000798fc6fde5ae  vmovaps [rsp+0xA0], xmm11
0000798fc6fde5b7  vmovaps [rsp+0xB0], xmm12
0000798fc6fde5c0  vmovaps [rsp+0xC0], xmm13
0000798fc6fde5c9  vmovaps [rsp+0xD0], xmm14
0000798fc6fde5d2  vmovaps [rsp+0xE0], xmm15
0000798fc6fde5db  sub rsp, 0x30
0000798fc6fde5df  movaps [rsp], xmm6
0000798fc6fde5e3  movaps [rsp+0x10], xmm9
0000798fc6fde5e9  movaps [rsp+0x20], xmm1
0000798fc6fde5ee  lea rdi, [rsp]
0000798fc6fde5f2  mov esi, 0x00
0000798fc6fde5f7  mov rax, 0x63E558B23530
0000798fc6fde601  call rax
0000798fc6fde603  movaps xmm6, [rsp]
0000798fc6fde607  add rsp, 0x30
0000798fc6fde60b  vmovaps xmm0, [rsp]
0000798fc6fde610  vmovaps xmm1, [rsp+0x10]
0000798fc6fde616  vmovaps xmm2, [rsp+0x20]
0000798fc6fde61c  vmovaps xmm3, [rsp+0x30]
0000798fc6fde622  vmovaps xmm4, [rsp+0x40]
0000798fc6fde628  vmovaps xmm5, [rsp+0x50]
0000798fc6fde62e  vmovaps xmm7, [rsp+0x60]
0000798fc6fde634  vmovaps xmm8, [rsp+0x70]
0000798fc6fde63a  vmovaps xmm9, [rsp+0x80]
0000798fc6fde643  vmovaps xmm10, [rsp+0x90]
0000798fc6fde64c  vmovaps xmm11, [rsp+0xA0]
0000798fc6fde655  vmovaps xmm12, [rsp+0xB0]
0000798fc6fde65e  vmovaps xmm13, [rsp+0xC0]
0000798fc6fde667  vmovaps xmm14, [rsp+0xD0]
0000798fc6fde670  vmovaps xmm15, [rsp+0xE0]
0000798fc6fde679  add rsp, 0xF0
0000798fc6fde680  pop r11
0000798fc6fde682  pop r10
0000798fc6fde684  pop r9
0000798fc6fde686  pop r8
0000798fc6fde688  pop rsi
0000798fc6fde689  pop rdi
0000798fc6fde68a  pop rdx
0000798fc6fde68b  pop rcx
0000798fc6fde68c  pop rax
0000798fc6fde68d  add rsp, 0x08
0000798fc6fde691  jmp 0x0000798FC6FDC15E
0000798fc6fde696  sub rsp, 0x08
0000798fc6fde69a  push rax
0000798fc6fde69b  push rcx
0000798fc6fde69c  push rdx
0000798fc6fde69d  push rdi
0000798fc6fde69e  push rsi
0000798fc6fde69f  push r8
0000798fc6fde6a1  push r9
0000798fc6fde6a3  push r10
0000798fc6fde6a5  push r11
0000798fc6fde6a7  sub rsp, 0xF0
0000798fc6fde6ae  vmovaps [rsp], xmm0
0000798fc6fde6b3  vmovaps [rsp+0x10], xmm1
0000798fc6fde6b9  vmovaps [rsp+0x20], xmm2
0000798fc6fde6bf  vmovaps [rsp+0x30], xmm3
0000798fc6fde6c5  vmovaps [rsp+0x40], xmm4
0000798fc6fde6cb  vmovaps [rsp+0x50], xmm5
0000798fc6fde6d1  vmovaps [rsp+0x60], xmm6
0000798fc6fde6d7  vmovaps [rsp+0x70], xmm7
0000798fc6fde6dd  vmovaps [rsp+0x80], xmm8
0000798fc6fde6e6  vmovaps [rsp+0x90], xmm10
0000798fc6fde6ef  vmovaps [rsp+0xA0], xmm11
0000798fc6fde6f8  vmovaps [rsp+0xB0], xmm12
0000798fc6fde701  vmovaps [rsp+0xC0], xmm13
0000798fc6fde70a  vmovaps [rsp+0xD0], xmm14
0000798fc6fde713  vmovaps [rsp+0xE0], xmm15
0000798fc6fde71c  sub rsp, 0x30
0000798fc6fde720  movaps [rsp], xmm9
0000798fc6fde725  movaps [rsp+0x10], xmm3
0000798fc6fde72a  movaps [rsp+0x20], xmm1
0000798fc6fde72f  lea rdi, [rsp]
0000798fc6fde733  mov esi, 0x00
0000798fc6fde738  mov rax, 0x63E558B23530
0000798fc6fde742  call rax
0000798fc6fde744  movaps xmm9, [rsp]
0000798fc6fde749  add rsp, 0x30
0000798fc6fde74d  vmovaps xmm0, [rsp]
0000798fc6fde752  vmovaps xmm1, [rsp+0x10]
0000798fc6fde758  vmovaps xmm2, [rsp+0x20]
0000798fc6fde75e  vmovaps xmm3, [rsp+0x30]
0000798fc6fde764  vmovaps xmm4, [rsp+0x40]
0000798fc6fde76a  vmovaps xmm5, [rsp+0x50]
0000798fc6fde770  vmovaps xmm6, [rsp+0x60]
0000798fc6fde776  vmovaps xmm7, [rsp+0x70]
0000798fc6fde77c  vmovaps xmm8, [rsp+0x80]
0000798fc6fde785  vmovaps xmm10, [rsp+0x90]
0000798fc6fde78e  vmovaps xmm11, [rsp+0xA0]
0000798fc6fde797  vmovaps xmm12, [rsp+0xB0]
0000798fc6fde7a0  vmovaps xmm13, [rsp+0xC0]
0000798fc6fde7a9  vmovaps xmm14, [rsp+0xD0]
0000798fc6fde7b2  vmovaps xmm15, [rsp+0xE0]
0000798fc6fde7bb  add rsp, 0xF0
0000798fc6fde7c2  pop r11
0000798fc6fde7c4  pop r10
0000798fc6fde7c6  pop r9
0000798fc6fde7c8  pop r8
0000798fc6fde7ca  pop rsi
0000798fc6fde7cb  pop rdi
0000798fc6fde7cc  pop rdx
0000798fc6fde7cd  pop rcx
0000798fc6fde7ce  pop rax
0000798fc6fde7cf  add rsp, 0x08
0000798fc6fde7d3  jmp 0x0000798FC6FDC1AA
0000798fc6fde7d8  call 0x0000798FC6EB52F0
0000798fc6fde7dd  jmp 0x0000798FC6FDC1B7
0000798fc6fde7e2  sub rsp, 0x08
0000798fc6fde7e6  push rax
0000798fc6fde7e7  push rcx
0000798fc6fde7e8  push rdx
0000798fc6fde7e9  push rdi
0000798fc6fde7ea  push rsi
0000798fc6fde7eb  push r8
0000798fc6fde7ed  push r9
0000798fc6fde7ef  push r10
0000798fc6fde7f1  push r11
0000798fc6fde7f3  sub rsp, 0xF0
0000798fc6fde7fa  vmovaps [rsp], xmm0
0000798fc6fde7ff  vmovaps [rsp+0x10], xmm1
0000798fc6fde805  vmovaps [rsp+0x20], xmm2
0000798fc6fde80b  vmovaps [rsp+0x30], xmm3
0000798fc6fde811  vmovaps [rsp+0x40], xmm4
0000798fc6fde817  vmovaps [rsp+0x50], xmm5
0000798fc6fde81d  vmovaps [rsp+0x60], xmm6
0000798fc6fde823  vmovaps [rsp+0x70], xmm7
0000798fc6fde829  vmovaps [rsp+0x80], xmm8
0000798fc6fde832  vmovaps [rsp+0x90], xmm9
0000798fc6fde83b  vmovaps [rsp+0xA0], xmm10
0000798fc6fde844  vmovaps [rsp+0xB0], xmm11
0000798fc6fde84d  vmovaps [rsp+0xC0], xmm12
0000798fc6fde856  vmovaps [rsp+0xD0], xmm13
0000798fc6fde85f  vmovaps [rsp+0xE0], xmm14
0000798fc6fde868  sub rsp, 0x30
0000798fc6fde86c  movaps [rsp], xmm15
0000798fc6fde871  movaps [rsp+0x10], xmm3
0000798fc6fde876  movaps [rsp+0x20], xmm7
0000798fc6fde87b  lea rdi, [rsp]
0000798fc6fde87f  mov esi, 0x00
0000798fc6fde884  mov rax, 0x63E558B23530
0000798fc6fde88e  call rax
0000798fc6fde890  movaps xmm15, [rsp]
0000798fc6fde895  add rsp, 0x30
0000798fc6fde899  vmovaps xmm0, [rsp]
0000798fc6fde89e  vmovaps xmm1, [rsp+0x10]
0000798fc6fde8a4  vmovaps xmm2, [rsp+0x20]
0000798fc6fde8aa  vmovaps xmm3, [rsp+0x30]
0000798fc6fde8b0  vmovaps xmm4, [rsp+0x40]
0000798fc6fde8b6  vmovaps xmm5, [rsp+0x50]
0000798fc6fde8bc  vmovaps xmm6, [rsp+0x60]
0000798fc6fde8c2  vmovaps xmm7, [rsp+0x70]
0000798fc6fde8c8  vmovaps xmm8, [rsp+0x80]
0000798fc6fde8d1  vmovaps xmm9, [rsp+0x90]
0000798fc6fde8da  vmovaps xmm10, [rsp+0xA0]
0000798fc6fde8e3  vmovaps xmm11, [rsp+0xB0]
0000798fc6fde8ec  vmovaps xmm12, [rsp+0xC0]
0000798fc6fde8f5  vmovaps xmm13, [rsp+0xD0]
0000798fc6fde8fe  vmovaps xmm14, [rsp+0xE0]
0000798fc6fde907  add rsp, 0xF0
0000798fc6fde90e  pop r11
0000798fc6fde910  pop r10
0000798fc6fde912  pop r9
0000798fc6fde914  pop r8
0000798fc6fde916  pop rsi
0000798fc6fde917  pop rdi
0000798fc6fde918  pop rdx
0000798fc6fde919  pop rcx
0000798fc6fde91a  pop rax
0000798fc6fde91b  add rsp, 0x08
0000798fc6fde91f  jmp 0x0000798FC6FDC1E3
0000798fc6fde924  sub rsp, 0x08
0000798fc6fde928  push rax
0000798fc6fde929  push rcx
0000798fc6fde92a  push rdx
0000798fc6fde92b  push rdi
0000798fc6fde92c  push rsi
0000798fc6fde92d  push r8
0000798fc6fde92f  push r9
0000798fc6fde931  push r10
0000798fc6fde933  push r11
0000798fc6fde935  sub rsp, 0xF0
0000798fc6fde93c  vmovaps [rsp], xmm0
0000798fc6fde941  vmovaps [rsp+0x10], xmm1
0000798fc6fde947  vmovaps [rsp+0x20], xmm2
0000798fc6fde94d  vmovaps [rsp+0x30], xmm4
0000798fc6fde953  vmovaps [rsp+0x40], xmm5
0000798fc6fde959  vmovaps [rsp+0x50], xmm6
0000798fc6fde95f  vmovaps [rsp+0x60], xmm7
0000798fc6fde965  vmovaps [rsp+0x70], xmm8
0000798fc6fde96b  vmovaps [rsp+0x80], xmm9
0000798fc6fde974  vmovaps [rsp+0x90], xmm10
0000798fc6fde97d  vmovaps [rsp+0xA0], xmm11
0000798fc6fde986  vmovaps [rsp+0xB0], xmm12
0000798fc6fde98f  vmovaps [rsp+0xC0], xmm13
0000798fc6fde998  vmovaps [rsp+0xD0], xmm14
0000798fc6fde9a1  vmovaps [rsp+0xE0], xmm15
0000798fc6fde9aa  sub rsp, 0x30
0000798fc6fde9ae  movaps [rsp], xmm3
0000798fc6fde9b2  movaps [rsp+0x10], xmm1
0000798fc6fde9b7  movaps [rsp+0x20], xmm15
0000798fc6fde9bd  lea rdi, [rsp]
0000798fc6fde9c1  mov esi, 0x00
0000798fc6fde9c6  mov rax, 0x63E558B23530
0000798fc6fde9d0  call rax
0000798fc6fde9d2  movaps xmm3, [rsp]
0000798fc6fde9d6  add rsp, 0x30
0000798fc6fde9da  vmovaps xmm0, [rsp]
0000798fc6fde9df  vmovaps xmm1, [rsp+0x10]
0000798fc6fde9e5  vmovaps xmm2, [rsp+0x20]
0000798fc6fde9eb  vmovaps xmm4, [rsp+0x30]
0000798fc6fde9f1  vmovaps xmm5, [rsp+0x40]
0000798fc6fde9f7  vmovaps xmm6, [rsp+0x50]
0000798fc6fde9fd  vmovaps xmm7, [rsp+0x60]
0000798fc6fdea03  vmovaps xmm8, [rsp+0x70]
0000798fc6fdea09  vmovaps xmm9, [rsp+0x80]
0000798fc6fdea12  vmovaps xmm10, [rsp+0x90]
0000798fc6fdea1b  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdea24  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdea2d  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdea36  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdea3f  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdea48  add rsp, 0xF0
0000798fc6fdea4f  pop r11
0000798fc6fdea51  pop r10
0000798fc6fdea53  pop r9
0000798fc6fdea55  pop r8
0000798fc6fdea57  pop rsi
0000798fc6fdea58  pop rdi
0000798fc6fdea59  pop rdx
0000798fc6fdea5a  pop rcx
0000798fc6fdea5b  pop rax
0000798fc6fdea5c  add rsp, 0x08
0000798fc6fdea60  jmp 0x0000798FC6FDC272
0000798fc6fdea65  call 0x0000798FC6EB52F0
0000798fc6fdea6a  jmp 0x0000798FC6FDC27C
0000798fc6fdea6f  sub rsp, 0x08
0000798fc6fdea73  push rax
0000798fc6fdea74  push rcx
0000798fc6fdea75  push rdx
0000798fc6fdea76  push rdi
0000798fc6fdea77  push rsi
0000798fc6fdea78  push r8
0000798fc6fdea7a  push r9
0000798fc6fdea7c  push r10
0000798fc6fdea7e  push r11
0000798fc6fdea80  sub rsp, 0xF0
0000798fc6fdea87  vmovaps [rsp], xmm0
0000798fc6fdea8c  vmovaps [rsp+0x10], xmm1
0000798fc6fdea92  vmovaps [rsp+0x20], xmm2
0000798fc6fdea98  vmovaps [rsp+0x30], xmm3
0000798fc6fdea9e  vmovaps [rsp+0x40], xmm4
0000798fc6fdeaa4  vmovaps [rsp+0x50], xmm5
0000798fc6fdeaaa  vmovaps [rsp+0x60], xmm6
0000798fc6fdeab0  vmovaps [rsp+0x70], xmm7
0000798fc6fdeab6  vmovaps [rsp+0x80], xmm8
0000798fc6fdeabf  vmovaps [rsp+0x90], xmm9
0000798fc6fdeac8  vmovaps [rsp+0xA0], xmm10
0000798fc6fdead1  vmovaps [rsp+0xB0], xmm11
0000798fc6fdeada  vmovaps [rsp+0xC0], xmm12
0000798fc6fdeae3  vmovaps [rsp+0xD0], xmm13
0000798fc6fdeaec  vmovaps [rsp+0xE0], xmm14
0000798fc6fdeaf5  sub rsp, 0x30
0000798fc6fdeaf9  movaps [rsp], xmm15
0000798fc6fdeafe  movaps [rsp+0x10], xmm14
0000798fc6fdeb04  movaps [rsp+0x20], xmm4
0000798fc6fdeb09  lea rdi, [rsp]
0000798fc6fdeb0d  mov esi, 0x00
0000798fc6fdeb12  mov rax, 0x63E558B23530
0000798fc6fdeb1c  call rax
0000798fc6fdeb1e  movaps xmm15, [rsp]
0000798fc6fdeb23  add rsp, 0x30
0000798fc6fdeb27  vmovaps xmm0, [rsp]
0000798fc6fdeb2c  vmovaps xmm1, [rsp+0x10]
0000798fc6fdeb32  vmovaps xmm2, [rsp+0x20]
0000798fc6fdeb38  vmovaps xmm3, [rsp+0x30]
0000798fc6fdeb3e  vmovaps xmm4, [rsp+0x40]
0000798fc6fdeb44  vmovaps xmm5, [rsp+0x50]
0000798fc6fdeb4a  vmovaps xmm6, [rsp+0x60]
0000798fc6fdeb50  vmovaps xmm7, [rsp+0x70]
0000798fc6fdeb56  vmovaps xmm8, [rsp+0x80]
0000798fc6fdeb5f  vmovaps xmm9, [rsp+0x90]
0000798fc6fdeb68  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdeb71  vmovaps xmm11, [rsp+0xB0]
0000798fc6fdeb7a  vmovaps xmm12, [rsp+0xC0]
0000798fc6fdeb83  vmovaps xmm13, [rsp+0xD0]
0000798fc6fdeb8c  vmovaps xmm14, [rsp+0xE0]
0000798fc6fdeb95  add rsp, 0xF0
0000798fc6fdeb9c  pop r11
0000798fc6fdeb9e  pop r10
0000798fc6fdeba0  pop r9
0000798fc6fdeba2  pop r8
0000798fc6fdeba4  pop rsi
0000798fc6fdeba5  pop rdi
0000798fc6fdeba6  pop rdx
0000798fc6fdeba7  pop rcx
0000798fc6fdeba8  pop rax
0000798fc6fdeba9  add rsp, 0x08
0000798fc6fdebad  jmp 0x0000798FC6FDC2AA
0000798fc6fdebb2  sub rsp, 0x08
0000798fc6fdebb6  push rax
0000798fc6fdebb7  push rcx
0000798fc6fdebb8  push rdx
0000798fc6fdebb9  push rdi
0000798fc6fdebba  push rsi
0000798fc6fdebbb  push r8
0000798fc6fdebbd  push r9
0000798fc6fdebbf  push r10
0000798fc6fdebc1  push r11
0000798fc6fdebc3  sub rsp, 0xF0
0000798fc6fdebca  vmovaps [rsp], xmm0
0000798fc6fdebcf  vmovaps [rsp+0x10], xmm1
0000798fc6fdebd5  vmovaps [rsp+0x20], xmm2
0000798fc6fdebdb  vmovaps [rsp+0x30], xmm3
0000798fc6fdebe1  vmovaps [rsp+0x40], xmm4
0000798fc6fdebe7  vmovaps [rsp+0x50], xmm5
0000798fc6fdebed  vmovaps [rsp+0x60], xmm6
0000798fc6fdebf3  vmovaps [rsp+0x70], xmm7
0000798fc6fdebf9  vmovaps [rsp+0x80], xmm8
0000798fc6fdec02  vmovaps [rsp+0x90], xmm9
0000798fc6fdec0b  vmovaps [rsp+0xA0], xmm10
0000798fc6fdec14  vmovaps [rsp+0xB0], xmm11
0000798fc6fdec1d  vmovaps [rsp+0xC0], xmm12
0000798fc6fdec26  vmovaps [rsp+0xD0], xmm13
0000798fc6fdec2f  vmovaps [rsp+0xE0], xmm15
0000798fc6fdec38  sub rsp, 0x30
0000798fc6fdec3c  movaps [rsp], xmm14
0000798fc6fdec41  movaps [rsp+0x10], xmm2
0000798fc6fdec46  movaps [rsp+0x20], xmm1
0000798fc6fdec4b  lea rdi, [rsp]
0000798fc6fdec4f  mov esi, 0x00
0000798fc6fdec54  mov rax, 0x63E558B23530
0000798fc6fdec5e  call rax
0000798fc6fdec60  movaps xmm14, [rsp]
0000798fc6fdec65  add rsp, 0x30
0000798fc6fdec69  vmovaps xmm0, [rsp]
0000798fc6fdec6e  vmovaps xmm1, [rsp+0x10]
0000798fc6fdec74  vmovaps xmm2, [rsp+0x20]
0000798fc6fdec7a  vmovaps xmm3, [rsp+0x30]
0000798fc6fdec80  vmovaps xmm4, [rsp+0x40]
0000798fc6fdec86  vmovaps xmm5, [rsp+0x50]
0000798fc6fdec8c  vmovaps xmm6, [rsp+0x60]
0000798fc6fdec92  vmovaps xmm7, [rsp+0x70]
0000798fc6fdec98  vmovaps xmm8, [rsp+0x80]
0000798fc6fdeca1  vmovaps xmm9, [rsp+0x90]
0000798fc6fdecaa  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdecb3  vmovaps xmm11, [rsp+0xB0]
0000798fc6fdecbc  vmovaps xmm12, [rsp+0xC0]
0000798fc6fdecc5  vmovaps xmm13, [rsp+0xD0]
0000798fc6fdecce  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdecd7  add rsp, 0xF0
0000798fc6fdecde  pop r11
0000798fc6fdece0  pop r10
0000798fc6fdece2  pop r9
0000798fc6fdece4  pop r8
0000798fc6fdece6  pop rsi
0000798fc6fdece7  pop rdi
0000798fc6fdece8  pop rdx
0000798fc6fdece9  pop rcx
0000798fc6fdecea  pop rax
0000798fc6fdeceb  add rsp, 0x08
0000798fc6fdecef  jmp 0x0000798FC6FDC2D0
0000798fc6fdecf4  sub rsp, 0x08
0000798fc6fdecf8  push rax
0000798fc6fdecf9  push rcx
0000798fc6fdecfa  push rdx
0000798fc6fdecfb  push rdi
0000798fc6fdecfc  push rsi
0000798fc6fdecfd  push r8
0000798fc6fdecff  push r9
0000798fc6fded01  push r10
0000798fc6fded03  push r11
0000798fc6fded05  sub rsp, 0xF0
0000798fc6fded0c  vmovaps [rsp], xmm0
0000798fc6fded11  vmovaps [rsp+0x10], xmm2
0000798fc6fded17  vmovaps [rsp+0x20], xmm3
0000798fc6fded1d  vmovaps [rsp+0x30], xmm4
0000798fc6fded23  vmovaps [rsp+0x40], xmm5
0000798fc6fded29  vmovaps [rsp+0x50], xmm6
0000798fc6fded2f  vmovaps [rsp+0x60], xmm7
0000798fc6fded35  vmovaps [rsp+0x70], xmm8
0000798fc6fded3b  vmovaps [rsp+0x80], xmm9
0000798fc6fded44  vmovaps [rsp+0x90], xmm10
0000798fc6fded4d  vmovaps [rsp+0xA0], xmm11
0000798fc6fded56  vmovaps [rsp+0xB0], xmm12
0000798fc6fded5f  vmovaps [rsp+0xC0], xmm13
0000798fc6fded68  vmovaps [rsp+0xD0], xmm14
0000798fc6fded71  vmovaps [rsp+0xE0], xmm15
0000798fc6fded7a  sub rsp, 0x30
0000798fc6fded7e  movaps [rsp], xmm1
0000798fc6fded82  movaps [rsp+0x10], xmm4
0000798fc6fded87  movaps [rsp+0x20], xmm9
0000798fc6fded8d  lea rdi, [rsp]
0000798fc6fded91  mov esi, 0x00
0000798fc6fded96  mov rax, 0x63E558B23530
0000798fc6fdeda0  call rax
0000798fc6fdeda2  movaps xmm1, [rsp]
0000798fc6fdeda6  add rsp, 0x30
0000798fc6fdedaa  vmovaps xmm0, [rsp]
0000798fc6fdedaf  vmovaps xmm2, [rsp+0x10]
0000798fc6fdedb5  vmovaps xmm3, [rsp+0x20]
0000798fc6fdedbb  vmovaps xmm4, [rsp+0x30]
0000798fc6fdedc1  vmovaps xmm5, [rsp+0x40]
0000798fc6fdedc7  vmovaps xmm6, [rsp+0x50]
0000798fc6fdedcd  vmovaps xmm7, [rsp+0x60]
0000798fc6fdedd3  vmovaps xmm8, [rsp+0x70]
0000798fc6fdedd9  vmovaps xmm9, [rsp+0x80]
0000798fc6fdede2  vmovaps xmm10, [rsp+0x90]
0000798fc6fdedeb  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdedf4  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdedfd  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdee06  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdee0f  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdee18  add rsp, 0xF0
0000798fc6fdee1f  pop r11
0000798fc6fdee21  pop r10
0000798fc6fdee23  pop r9
0000798fc6fdee25  pop r8
0000798fc6fdee27  pop rsi
0000798fc6fdee28  pop rdi
0000798fc6fdee29  pop rdx
0000798fc6fdee2a  pop rcx
0000798fc6fdee2b  pop rax
0000798fc6fdee2c  add rsp, 0x08
0000798fc6fdee30  jmp 0x0000798FC6FDC2EE
0000798fc6fdee35  sub rsp, 0x08
0000798fc6fdee39  push rax
0000798fc6fdee3a  push rcx
0000798fc6fdee3b  push rdx
0000798fc6fdee3c  push rdi
0000798fc6fdee3d  push rsi
0000798fc6fdee3e  push r8
0000798fc6fdee40  push r9
0000798fc6fdee42  push r10
0000798fc6fdee44  push r11
0000798fc6fdee46  sub rsp, 0xF0
0000798fc6fdee4d  vmovaps [rsp], xmm0
0000798fc6fdee52  vmovaps [rsp+0x10], xmm1
0000798fc6fdee58  vmovaps [rsp+0x20], xmm2
0000798fc6fdee5e  vmovaps [rsp+0x30], xmm3
0000798fc6fdee64  vmovaps [rsp+0x40], xmm5
0000798fc6fdee6a  vmovaps [rsp+0x50], xmm6
0000798fc6fdee70  vmovaps [rsp+0x60], xmm7
0000798fc6fdee76  vmovaps [rsp+0x70], xmm8
0000798fc6fdee7c  vmovaps [rsp+0x80], xmm9
0000798fc6fdee85  vmovaps [rsp+0x90], xmm10
0000798fc6fdee8e  vmovaps [rsp+0xA0], xmm11
0000798fc6fdee97  vmovaps [rsp+0xB0], xmm12
0000798fc6fdeea0  vmovaps [rsp+0xC0], xmm13
0000798fc6fdeea9  vmovaps [rsp+0xD0], xmm14
0000798fc6fdeeb2  vmovaps [rsp+0xE0], xmm15
0000798fc6fdeebb  sub rsp, 0x30
0000798fc6fdeebf  movaps [rsp], xmm4
0000798fc6fdeec3  movaps [rsp+0x10], xmm2
0000798fc6fdeec8  movaps [rsp+0x20], xmm9
0000798fc6fdeece  lea rdi, [rsp]
0000798fc6fdeed2  mov esi, 0x00
0000798fc6fdeed7  mov rax, 0x63E558B23530
0000798fc6fdeee1  call rax
0000798fc6fdeee3  movaps xmm4, [rsp]
0000798fc6fdeee7  add rsp, 0x30
0000798fc6fdeeeb  vmovaps xmm0, [rsp]
0000798fc6fdeef0  vmovaps xmm1, [rsp+0x10]
0000798fc6fdeef6  vmovaps xmm2, [rsp+0x20]
0000798fc6fdeefc  vmovaps xmm3, [rsp+0x30]
0000798fc6fdef02  vmovaps xmm5, [rsp+0x40]
0000798fc6fdef08  vmovaps xmm6, [rsp+0x50]
0000798fc6fdef0e  vmovaps xmm7, [rsp+0x60]
0000798fc6fdef14  vmovaps xmm8, [rsp+0x70]
0000798fc6fdef1a  vmovaps xmm9, [rsp+0x80]
0000798fc6fdef23  vmovaps xmm10, [rsp+0x90]
0000798fc6fdef2c  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdef35  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdef3e  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdef47  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdef50  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdef59  add rsp, 0xF0
0000798fc6fdef60  pop r11
0000798fc6fdef62  pop r10
0000798fc6fdef64  pop r9
0000798fc6fdef66  pop r8
0000798fc6fdef68  pop rsi
0000798fc6fdef69  pop rdi
0000798fc6fdef6a  pop rdx
0000798fc6fdef6b  pop rcx
0000798fc6fdef6c  pop rax
0000798fc6fdef6d  add rsp, 0x08
0000798fc6fdef71  jmp 0x0000798FC6FDC31E
0000798fc6fdef76  sub rsp, 0x08
0000798fc6fdef7a  push rax
0000798fc6fdef7b  push rcx
0000798fc6fdef7c  push rdx
0000798fc6fdef7d  push rdi
0000798fc6fdef7e  push rsi
0000798fc6fdef7f  push r8
0000798fc6fdef81  push r9
0000798fc6fdef83  push r10
0000798fc6fdef85  push r11
0000798fc6fdef87  sub rsp, 0xF0
0000798fc6fdef8e  vmovaps [rsp], xmm0
0000798fc6fdef93  vmovaps [rsp+0x10], xmm1
0000798fc6fdef99  vmovaps [rsp+0x20], xmm2
0000798fc6fdef9f  vmovaps [rsp+0x30], xmm3
0000798fc6fdefa5  vmovaps [rsp+0x40], xmm4
0000798fc6fdefab  vmovaps [rsp+0x50], xmm5
0000798fc6fdefb1  vmovaps [rsp+0x60], xmm6
0000798fc6fdefb7  vmovaps [rsp+0x70], xmm7
0000798fc6fdefbd  vmovaps [rsp+0x80], xmm8
0000798fc6fdefc6  vmovaps [rsp+0x90], xmm10
0000798fc6fdefcf  vmovaps [rsp+0xA0], xmm11
0000798fc6fdefd8  vmovaps [rsp+0xB0], xmm12
0000798fc6fdefe1  vmovaps [rsp+0xC0], xmm13
0000798fc6fdefea  vmovaps [rsp+0xD0], xmm14
0000798fc6fdeff3  vmovaps [rsp+0xE0], xmm15
0000798fc6fdeffc  sub rsp, 0x30
0000798fc6fdf000  movaps [rsp], xmm9
0000798fc6fdf005  movaps [rsp+0x10], xmm2
0000798fc6fdf00a  movaps [rsp+0x20], xmm1
0000798fc6fdf00f  lea rdi, [rsp]
0000798fc6fdf013  mov esi, 0x00
0000798fc6fdf018  mov rax, 0x63E558B23530
0000798fc6fdf022  call rax
0000798fc6fdf024  movaps xmm9, [rsp]
0000798fc6fdf029  add rsp, 0x30
0000798fc6fdf02d  vmovaps xmm0, [rsp]
0000798fc6fdf032  vmovaps xmm1, [rsp+0x10]
0000798fc6fdf038  vmovaps xmm2, [rsp+0x20]
0000798fc6fdf03e  vmovaps xmm3, [rsp+0x30]
0000798fc6fdf044  vmovaps xmm4, [rsp+0x40]
0000798fc6fdf04a  vmovaps xmm5, [rsp+0x50]
0000798fc6fdf050  vmovaps xmm6, [rsp+0x60]
0000798fc6fdf056  vmovaps xmm7, [rsp+0x70]
0000798fc6fdf05c  vmovaps xmm8, [rsp+0x80]
0000798fc6fdf065  vmovaps xmm10, [rsp+0x90]
0000798fc6fdf06e  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdf077  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdf080  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdf089  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdf092  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdf09b  add rsp, 0xF0
0000798fc6fdf0a2  pop r11
0000798fc6fdf0a4  pop r10
0000798fc6fdf0a6  pop r9
0000798fc6fdf0a8  pop r8
0000798fc6fdf0aa  pop rsi
0000798fc6fdf0ab  pop rdi
0000798fc6fdf0ac  pop rdx
0000798fc6fdf0ad  pop rcx
0000798fc6fdf0ae  pop rax
0000798fc6fdf0af  add rsp, 0x08
0000798fc6fdf0b3  jmp 0x0000798FC6FDC354
0000798fc6fdf0b8  sub rsp, 0x08
0000798fc6fdf0bc  push rax
0000798fc6fdf0bd  push rcx
0000798fc6fdf0be  push rdx
0000798fc6fdf0bf  push rdi
0000798fc6fdf0c0  push rsi
0000798fc6fdf0c1  push r8
0000798fc6fdf0c3  push r9
0000798fc6fdf0c5  push r10
0000798fc6fdf0c7  push r11
0000798fc6fdf0c9  sub rsp, 0xF0
0000798fc6fdf0d0  vmovaps [rsp], xmm0
0000798fc6fdf0d5  vmovaps [rsp+0x10], xmm2
0000798fc6fdf0db  vmovaps [rsp+0x20], xmm3
0000798fc6fdf0e1  vmovaps [rsp+0x30], xmm4
0000798fc6fdf0e7  vmovaps [rsp+0x40], xmm5
0000798fc6fdf0ed  vmovaps [rsp+0x50], xmm6
0000798fc6fdf0f3  vmovaps [rsp+0x60], xmm7
0000798fc6fdf0f9  vmovaps [rsp+0x70], xmm8
0000798fc6fdf0ff  vmovaps [rsp+0x80], xmm9
0000798fc6fdf108  vmovaps [rsp+0x90], xmm10
0000798fc6fdf111  vmovaps [rsp+0xA0], xmm11
0000798fc6fdf11a  vmovaps [rsp+0xB0], xmm12
0000798fc6fdf123  vmovaps [rsp+0xC0], xmm13
0000798fc6fdf12c  vmovaps [rsp+0xD0], xmm14
0000798fc6fdf135  vmovaps [rsp+0xE0], xmm15
0000798fc6fdf13e  sub rsp, 0x30
0000798fc6fdf142  movaps [rsp], xmm1
0000798fc6fdf146  movaps [rsp+0x10], xmm15
0000798fc6fdf14c  movaps [rsp+0x20], xmm6
0000798fc6fdf151  lea rdi, [rsp]
0000798fc6fdf155  mov esi, 0x00
0000798fc6fdf15a  mov rax, 0x63E558B23530
0000798fc6fdf164  call rax
0000798fc6fdf166  movaps xmm1, [rsp]
0000798fc6fdf16a  add rsp, 0x30
0000798fc6fdf16e  vmovaps xmm0, [rsp]
0000798fc6fdf173  vmovaps xmm2, [rsp+0x10]
0000798fc6fdf179  vmovaps xmm3, [rsp+0x20]
0000798fc6fdf17f  vmovaps xmm4, [rsp+0x30]
0000798fc6fdf185  vmovaps xmm5, [rsp+0x40]
0000798fc6fdf18b  vmovaps xmm6, [rsp+0x50]
0000798fc6fdf191  vmovaps xmm7, [rsp+0x60]
0000798fc6fdf197  vmovaps xmm8, [rsp+0x70]
0000798fc6fdf19d  vmovaps xmm9, [rsp+0x80]
0000798fc6fdf1a6  vmovaps xmm10, [rsp+0x90]
0000798fc6fdf1af  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdf1b8  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdf1c1  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdf1ca  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdf1d3  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdf1dc  add rsp, 0xF0
0000798fc6fdf1e3  pop r11
0000798fc6fdf1e5  pop r10
0000798fc6fdf1e7  pop r9
0000798fc6fdf1e9  pop r8
0000798fc6fdf1eb  pop rsi
0000798fc6fdf1ec  pop rdi
0000798fc6fdf1ed  pop rdx
0000798fc6fdf1ee  pop rcx
0000798fc6fdf1ef  pop rax
0000798fc6fdf1f0  add rsp, 0x08
0000798fc6fdf1f4  jmp 0x0000798FC6FDC375
0000798fc6fdf1f9  sub rsp, 0x08
0000798fc6fdf1fd  push rax
0000798fc6fdf1fe  push rcx
0000798fc6fdf1ff  push rdx
0000798fc6fdf200  push rdi
0000798fc6fdf201  push rsi
0000798fc6fdf202  push r8
0000798fc6fdf204  push r9
0000798fc6fdf206  push r10
0000798fc6fdf208  push r11
0000798fc6fdf20a  sub rsp, 0xF0
0000798fc6fdf211  vmovaps [rsp], xmm0
0000798fc6fdf216  vmovaps [rsp+0x10], xmm1
0000798fc6fdf21c  vmovaps [rsp+0x20], xmm2
0000798fc6fdf222  vmovaps [rsp+0x30], xmm3
0000798fc6fdf228  vmovaps [rsp+0x40], xmm4
0000798fc6fdf22e  vmovaps [rsp+0x50], xmm5
0000798fc6fdf234  vmovaps [rsp+0x60], xmm6
0000798fc6fdf23a  vmovaps [rsp+0x70], xmm7
0000798fc6fdf240  vmovaps [rsp+0x80], xmm8
0000798fc6fdf249  vmovaps [rsp+0x90], xmm9
0000798fc6fdf252  vmovaps [rsp+0xA0], xmm10
0000798fc6fdf25b  vmovaps [rsp+0xB0], xmm11
0000798fc6fdf264  vmovaps [rsp+0xC0], xmm12
0000798fc6fdf26d  vmovaps [rsp+0xD0], xmm13
0000798fc6fdf276  vmovaps [rsp+0xE0], xmm14
0000798fc6fdf27f  sub rsp, 0x30
0000798fc6fdf283  movaps [rsp], xmm15
0000798fc6fdf288  movaps [rsp+0x10], xmm5
0000798fc6fdf28d  movaps [rsp+0x20], xmm3
0000798fc6fdf292  lea rdi, [rsp]
0000798fc6fdf296  mov esi, 0x00
0000798fc6fdf29b  mov rax, 0x63E558B23530
0000798fc6fdf2a5  call rax
0000798fc6fdf2a7  movaps xmm15, [rsp]
0000798fc6fdf2ac  add rsp, 0x30
0000798fc6fdf2b0  vmovaps xmm0, [rsp]
0000798fc6fdf2b5  vmovaps xmm1, [rsp+0x10]
0000798fc6fdf2bb  vmovaps xmm2, [rsp+0x20]
0000798fc6fdf2c1  vmovaps xmm3, [rsp+0x30]
0000798fc6fdf2c7  vmovaps xmm4, [rsp+0x40]
0000798fc6fdf2cd  vmovaps xmm5, [rsp+0x50]
0000798fc6fdf2d3  vmovaps xmm6, [rsp+0x60]
0000798fc6fdf2d9  vmovaps xmm7, [rsp+0x70]
0000798fc6fdf2df  vmovaps xmm8, [rsp+0x80]
0000798fc6fdf2e8  vmovaps xmm9, [rsp+0x90]
0000798fc6fdf2f1  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdf2fa  vmovaps xmm11, [rsp+0xB0]
0000798fc6fdf303  vmovaps xmm12, [rsp+0xC0]
0000798fc6fdf30c  vmovaps xmm13, [rsp+0xD0]
0000798fc6fdf315  vmovaps xmm14, [rsp+0xE0]
0000798fc6fdf31e  add rsp, 0xF0
0000798fc6fdf325  pop r11
0000798fc6fdf327  pop r10
0000798fc6fdf329  pop r9
0000798fc6fdf32b  pop r8
0000798fc6fdf32d  pop rsi
0000798fc6fdf32e  pop rdi
0000798fc6fdf32f  pop rdx
0000798fc6fdf330  pop rcx
0000798fc6fdf331  pop rax
0000798fc6fdf332  add rsp, 0x08
0000798fc6fdf336  jmp 0x0000798FC6FDC38F
0000798fc6fdf33b  sub rsp, 0x08
0000798fc6fdf33f  push rax
0000798fc6fdf340  push rcx
0000798fc6fdf341  push rdx
0000798fc6fdf342  push rdi
0000798fc6fdf343  push rsi
0000798fc6fdf344  push r8
0000798fc6fdf346  push r9
0000798fc6fdf348  push r10
0000798fc6fdf34a  push r11
0000798fc6fdf34c  sub rsp, 0xF0
0000798fc6fdf353  vmovaps [rsp], xmm0
0000798fc6fdf358  vmovaps [rsp+0x10], xmm1
0000798fc6fdf35e  vmovaps [rsp+0x20], xmm2
0000798fc6fdf364  vmovaps [rsp+0x30], xmm3
0000798fc6fdf36a  vmovaps [rsp+0x40], xmm4
0000798fc6fdf370  vmovaps [rsp+0x50], xmm6
0000798fc6fdf376  vmovaps [rsp+0x60], xmm7
0000798fc6fdf37c  vmovaps [rsp+0x70], xmm8
0000798fc6fdf382  vmovaps [rsp+0x80], xmm9
0000798fc6fdf38b  vmovaps [rsp+0x90], xmm10
0000798fc6fdf394  vmovaps [rsp+0xA0], xmm11
0000798fc6fdf39d  vmovaps [rsp+0xB0], xmm12
0000798fc6fdf3a6  vmovaps [rsp+0xC0], xmm13
0000798fc6fdf3af  vmovaps [rsp+0xD0], xmm14
0000798fc6fdf3b8  vmovaps [rsp+0xE0], xmm15
0000798fc6fdf3c1  sub rsp, 0x30
0000798fc6fdf3c5  movaps [rsp], xmm5
0000798fc6fdf3c9  movaps [rsp+0x10], xmm8
0000798fc6fdf3cf  movaps [rsp+0x20], xmm6
0000798fc6fdf3d4  lea rdi, [rsp]
0000798fc6fdf3d8  mov esi, 0x00
0000798fc6fdf3dd  mov rax, 0x63E558B23530
0000798fc6fdf3e7  call rax
0000798fc6fdf3e9  movaps xmm5, [rsp]
0000798fc6fdf3ed  add rsp, 0x30
0000798fc6fdf3f1  vmovaps xmm0, [rsp]
0000798fc6fdf3f6  vmovaps xmm1, [rsp+0x10]
0000798fc6fdf3fc  vmovaps xmm2, [rsp+0x20]
0000798fc6fdf402  vmovaps xmm3, [rsp+0x30]
0000798fc6fdf408  vmovaps xmm4, [rsp+0x40]
0000798fc6fdf40e  vmovaps xmm6, [rsp+0x50]
0000798fc6fdf414  vmovaps xmm7, [rsp+0x60]
0000798fc6fdf41a  vmovaps xmm8, [rsp+0x70]
0000798fc6fdf420  vmovaps xmm9, [rsp+0x80]
0000798fc6fdf429  vmovaps xmm10, [rsp+0x90]
0000798fc6fdf432  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdf43b  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdf444  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdf44d  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdf456  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdf45f  add rsp, 0xF0
0000798fc6fdf466  pop r11
0000798fc6fdf468  pop r10
0000798fc6fdf46a  pop r9
0000798fc6fdf46c  pop r8
0000798fc6fdf46e  pop rsi
0000798fc6fdf46f  pop rdi
0000798fc6fdf470  pop rdx
0000798fc6fdf471  pop rcx
0000798fc6fdf472  pop rax
0000798fc6fdf473  add rsp, 0x08
0000798fc6fdf477  jmp 0x0000798FC6FDC3B3
0000798fc6fdf47c  sub rsp, 0x08
0000798fc6fdf480  push rax
0000798fc6fdf481  push rcx
0000798fc6fdf482  push rdx
0000798fc6fdf483  push rdi
0000798fc6fdf484  push rsi
0000798fc6fdf485  push r8
0000798fc6fdf487  push r9
0000798fc6fdf489  push r10
0000798fc6fdf48b  push r11
0000798fc6fdf48d  sub rsp, 0xF0
0000798fc6fdf494  vmovaps [rsp], xmm0
0000798fc6fdf499  vmovaps [rsp+0x10], xmm1
0000798fc6fdf49f  vmovaps [rsp+0x20], xmm2
0000798fc6fdf4a5  vmovaps [rsp+0x30], xmm3
0000798fc6fdf4ab  vmovaps [rsp+0x40], xmm4
0000798fc6fdf4b1  vmovaps [rsp+0x50], xmm5
0000798fc6fdf4b7  vmovaps [rsp+0x60], xmm7
0000798fc6fdf4bd  vmovaps [rsp+0x70], xmm8
0000798fc6fdf4c3  vmovaps [rsp+0x80], xmm9
0000798fc6fdf4cc  vmovaps [rsp+0x90], xmm10
0000798fc6fdf4d5  vmovaps [rsp+0xA0], xmm11
0000798fc6fdf4de  vmovaps [rsp+0xB0], xmm12
0000798fc6fdf4e7  vmovaps [rsp+0xC0], xmm13
0000798fc6fdf4f0  vmovaps [rsp+0xD0], xmm14
0000798fc6fdf4f9  vmovaps [rsp+0xE0], xmm15
0000798fc6fdf502  sub rsp, 0x30
0000798fc6fdf506  movaps [rsp], xmm6
0000798fc6fdf50a  movaps [rsp+0x10], xmm10
0000798fc6fdf510  movaps [rsp+0x20], xmm8
0000798fc6fdf516  lea rdi, [rsp]
0000798fc6fdf51a  mov esi, 0x00
0000798fc6fdf51f  mov rax, 0x63E558B23530
0000798fc6fdf529  call rax
0000798fc6fdf52b  movaps xmm6, [rsp]
0000798fc6fdf52f  add rsp, 0x30
0000798fc6fdf533  vmovaps xmm0, [rsp]
0000798fc6fdf538  vmovaps xmm1, [rsp+0x10]
0000798fc6fdf53e  vmovaps xmm2, [rsp+0x20]
0000798fc6fdf544  vmovaps xmm3, [rsp+0x30]
0000798fc6fdf54a  vmovaps xmm4, [rsp+0x40]
0000798fc6fdf550  vmovaps xmm5, [rsp+0x50]
0000798fc6fdf556  vmovaps xmm7, [rsp+0x60]
0000798fc6fdf55c  vmovaps xmm8, [rsp+0x70]
0000798fc6fdf562  vmovaps xmm9, [rsp+0x80]
0000798fc6fdf56b  vmovaps xmm10, [rsp+0x90]
0000798fc6fdf574  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdf57d  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdf586  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdf58f  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdf598  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdf5a1  add rsp, 0xF0
0000798fc6fdf5a8  pop r11
0000798fc6fdf5aa  pop r10
0000798fc6fdf5ac  pop r9
0000798fc6fdf5ae  pop r8
0000798fc6fdf5b0  pop rsi
0000798fc6fdf5b1  pop rdi
0000798fc6fdf5b2  pop rdx
0000798fc6fdf5b3  pop rcx
0000798fc6fdf5b4  pop rax
0000798fc6fdf5b5  add rsp, 0x08
0000798fc6fdf5b9  jmp 0x0000798FC6FDC3D8
0000798fc6fdf5be  sub rsp, 0x08
0000798fc6fdf5c2  push rax
0000798fc6fdf5c3  push rcx
0000798fc6fdf5c4  push rdx
0000798fc6fdf5c5  push rdi
0000798fc6fdf5c6  push rsi
0000798fc6fdf5c7  push r8
0000798fc6fdf5c9  push r9
0000798fc6fdf5cb  push r10
0000798fc6fdf5cd  push r11
0000798fc6fdf5cf  sub rsp, 0xF0
0000798fc6fdf5d6  vmovaps [rsp], xmm0
0000798fc6fdf5db  vmovaps [rsp+0x10], xmm1
0000798fc6fdf5e1  vmovaps [rsp+0x20], xmm2
0000798fc6fdf5e7  vmovaps [rsp+0x30], xmm3
0000798fc6fdf5ed  vmovaps [rsp+0x40], xmm4
0000798fc6fdf5f3  vmovaps [rsp+0x50], xmm5
0000798fc6fdf5f9  vmovaps [rsp+0x60], xmm6
0000798fc6fdf5ff  vmovaps [rsp+0x70], xmm7
0000798fc6fdf605  vmovaps [rsp+0x80], xmm8
0000798fc6fdf60e  vmovaps [rsp+0x90], xmm9
0000798fc6fdf617  vmovaps [rsp+0xA0], xmm11
0000798fc6fdf620  vmovaps [rsp+0xB0], xmm12
0000798fc6fdf629  vmovaps [rsp+0xC0], xmm13
0000798fc6fdf632  vmovaps [rsp+0xD0], xmm14
0000798fc6fdf63b  vmovaps [rsp+0xE0], xmm15
0000798fc6fdf644  sub rsp, 0x30
0000798fc6fdf648  movaps [rsp], xmm10
0000798fc6fdf64d  movaps [rsp+0x10], xmm8
0000798fc6fdf653  movaps [rsp+0x20], xmm14
0000798fc6fdf659  lea rdi, [rsp]
0000798fc6fdf65d  mov esi, 0x00
0000798fc6fdf662  mov rax, 0x63E558B23530
0000798fc6fdf66c  call rax
0000798fc6fdf66e  movaps xmm10, [rsp]
0000798fc6fdf673  add rsp, 0x30
0000798fc6fdf677  vmovaps xmm0, [rsp]
0000798fc6fdf67c  vmovaps xmm1, [rsp+0x10]
0000798fc6fdf682  vmovaps xmm2, [rsp+0x20]
0000798fc6fdf688  vmovaps xmm3, [rsp+0x30]
0000798fc6fdf68e  vmovaps xmm4, [rsp+0x40]
0000798fc6fdf694  vmovaps xmm5, [rsp+0x50]
0000798fc6fdf69a  vmovaps xmm6, [rsp+0x60]
0000798fc6fdf6a0  vmovaps xmm7, [rsp+0x70]
0000798fc6fdf6a6  vmovaps xmm8, [rsp+0x80]
0000798fc6fdf6af  vmovaps xmm9, [rsp+0x90]
0000798fc6fdf6b8  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdf6c1  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdf6ca  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdf6d3  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdf6dc  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdf6e5  add rsp, 0xF0
0000798fc6fdf6ec  pop r11
0000798fc6fdf6ee  pop r10
0000798fc6fdf6f0  pop r9
0000798fc6fdf6f2  pop r8
0000798fc6fdf6f4  pop rsi
0000798fc6fdf6f5  pop rdi
0000798fc6fdf6f6  pop rdx
0000798fc6fdf6f7  pop rcx
0000798fc6fdf6f8  pop rax
0000798fc6fdf6f9  add rsp, 0x08
0000798fc6fdf6fd  jmp 0x0000798FC6FDC3F8
0000798fc6fdf702  sub rsp, 0x08
0000798fc6fdf706  push rax
0000798fc6fdf707  push rcx
0000798fc6fdf708  push rdx
0000798fc6fdf709  push rdi
0000798fc6fdf70a  push rsi
0000798fc6fdf70b  push r8
0000798fc6fdf70d  push r9
0000798fc6fdf70f  push r10
0000798fc6fdf711  push r11
0000798fc6fdf713  sub rsp, 0xF0
0000798fc6fdf71a  vmovaps [rsp], xmm0
0000798fc6fdf71f  vmovaps [rsp+0x10], xmm1
0000798fc6fdf725  vmovaps [rsp+0x20], xmm2
0000798fc6fdf72b  vmovaps [rsp+0x30], xmm3
0000798fc6fdf731  vmovaps [rsp+0x40], xmm4
0000798fc6fdf737  vmovaps [rsp+0x50], xmm5
0000798fc6fdf73d  vmovaps [rsp+0x60], xmm6
0000798fc6fdf743  vmovaps [rsp+0x70], xmm7
0000798fc6fdf749  vmovaps [rsp+0x80], xmm8
0000798fc6fdf752  vmovaps [rsp+0x90], xmm9
0000798fc6fdf75b  vmovaps [rsp+0xA0], xmm10
0000798fc6fdf764  vmovaps [rsp+0xB0], xmm11
0000798fc6fdf76d  vmovaps [rsp+0xC0], xmm12
0000798fc6fdf776  vmovaps [rsp+0xD0], xmm13
0000798fc6fdf77f  vmovaps [rsp+0xE0], xmm15
0000798fc6fdf788  sub rsp, 0x30
0000798fc6fdf78c  movaps [rsp], xmm14
0000798fc6fdf791  movaps [rsp+0x10], xmm8
0000798fc6fdf797  movaps [rsp+0x20], xmm4
0000798fc6fdf79c  lea rdi, [rsp]
0000798fc6fdf7a0  mov esi, 0x00
0000798fc6fdf7a5  mov rax, 0x63E558B23530
0000798fc6fdf7af  call rax
0000798fc6fdf7b1  movaps xmm14, [rsp]
0000798fc6fdf7b6  add rsp, 0x30
0000798fc6fdf7ba  vmovaps xmm0, [rsp]
0000798fc6fdf7bf  vmovaps xmm1, [rsp+0x10]
0000798fc6fdf7c5  vmovaps xmm2, [rsp+0x20]
0000798fc6fdf7cb  vmovaps xmm3, [rsp+0x30]
0000798fc6fdf7d1  vmovaps xmm4, [rsp+0x40]
0000798fc6fdf7d7  vmovaps xmm5, [rsp+0x50]
0000798fc6fdf7dd  vmovaps xmm6, [rsp+0x60]
0000798fc6fdf7e3  vmovaps xmm7, [rsp+0x70]
0000798fc6fdf7e9  vmovaps xmm8, [rsp+0x80]
0000798fc6fdf7f2  vmovaps xmm9, [rsp+0x90]
0000798fc6fdf7fb  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdf804  vmovaps xmm11, [rsp+0xB0]
0000798fc6fdf80d  vmovaps xmm12, [rsp+0xC0]
0000798fc6fdf816  vmovaps xmm13, [rsp+0xD0]
0000798fc6fdf81f  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdf828  add rsp, 0xF0
0000798fc6fdf82f  pop r11
0000798fc6fdf831  pop r10
0000798fc6fdf833  pop r9
0000798fc6fdf835  pop r8
0000798fc6fdf837  pop rsi
0000798fc6fdf838  pop rdi
0000798fc6fdf839  pop rdx
0000798fc6fdf83a  pop rcx
0000798fc6fdf83b  pop rax
0000798fc6fdf83c  add rsp, 0x08
0000798fc6fdf840  jmp 0x0000798FC6FDC418
0000798fc6fdf845  sub rsp, 0x08
0000798fc6fdf849  push rax
0000798fc6fdf84a  push rcx
0000798fc6fdf84b  push rdx
0000798fc6fdf84c  push rdi
0000798fc6fdf84d  push rsi
0000798fc6fdf84e  push r8
0000798fc6fdf850  push r9
0000798fc6fdf852  push r10
0000798fc6fdf854  push r11
0000798fc6fdf856  sub rsp, 0xF0
0000798fc6fdf85d  vmovaps [rsp], xmm0
0000798fc6fdf862  vmovaps [rsp+0x10], xmm1
0000798fc6fdf868  vmovaps [rsp+0x20], xmm2
0000798fc6fdf86e  vmovaps [rsp+0x30], xmm3
0000798fc6fdf874  vmovaps [rsp+0x40], xmm5
0000798fc6fdf87a  vmovaps [rsp+0x50], xmm6
0000798fc6fdf880  vmovaps [rsp+0x60], xmm7
0000798fc6fdf886  vmovaps [rsp+0x70], xmm8
0000798fc6fdf88c  vmovaps [rsp+0x80], xmm9
0000798fc6fdf895  vmovaps [rsp+0x90], xmm10
0000798fc6fdf89e  vmovaps [rsp+0xA0], xmm11
0000798fc6fdf8a7  vmovaps [rsp+0xB0], xmm12
0000798fc6fdf8b0  vmovaps [rsp+0xC0], xmm13
0000798fc6fdf8b9  vmovaps [rsp+0xD0], xmm14
0000798fc6fdf8c2  vmovaps [rsp+0xE0], xmm15
0000798fc6fdf8cb  sub rsp, 0x30
0000798fc6fdf8cf  movaps [rsp], xmm4
0000798fc6fdf8d3  movaps [rsp+0x10], xmm13
0000798fc6fdf8d9  movaps [rsp+0x20], xmm8
0000798fc6fdf8df  lea rdi, [rsp]
0000798fc6fdf8e3  mov esi, 0x00
0000798fc6fdf8e8  mov rax, 0x63E558B23530
0000798fc6fdf8f2  call rax
0000798fc6fdf8f4  movaps xmm4, [rsp]
0000798fc6fdf8f8  add rsp, 0x30
0000798fc6fdf8fc  vmovaps xmm0, [rsp]
0000798fc6fdf901  vmovaps xmm1, [rsp+0x10]
0000798fc6fdf907  vmovaps xmm2, [rsp+0x20]
0000798fc6fdf90d  vmovaps xmm3, [rsp+0x30]
0000798fc6fdf913  vmovaps xmm5, [rsp+0x40]
0000798fc6fdf919  vmovaps xmm6, [rsp+0x50]
0000798fc6fdf91f  vmovaps xmm7, [rsp+0x60]
0000798fc6fdf925  vmovaps xmm8, [rsp+0x70]
0000798fc6fdf92b  vmovaps xmm9, [rsp+0x80]
0000798fc6fdf934  vmovaps xmm10, [rsp+0x90]
0000798fc6fdf93d  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdf946  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdf94f  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdf958  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdf961  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdf96a  add rsp, 0xF0
0000798fc6fdf971  pop r11
0000798fc6fdf973  pop r10
0000798fc6fdf975  pop r9
0000798fc6fdf977  pop r8
0000798fc6fdf979  pop rsi
0000798fc6fdf97a  pop rdi
0000798fc6fdf97b  pop rdx
0000798fc6fdf97c  pop rcx
0000798fc6fdf97d  pop rax
0000798fc6fdf97e  add rsp, 0x08
0000798fc6fdf982  jmp 0x0000798FC6FDC43D
0000798fc6fdf987  sub rsp, 0x08
0000798fc6fdf98b  push rax
0000798fc6fdf98c  push rcx
0000798fc6fdf98d  push rdx
0000798fc6fdf98e  push rdi
0000798fc6fdf98f  push rsi
0000798fc6fdf990  push r8
0000798fc6fdf992  push r9
0000798fc6fdf994  push r10
0000798fc6fdf996  push r11
0000798fc6fdf998  sub rsp, 0xF0
0000798fc6fdf99f  vmovaps [rsp], xmm0
0000798fc6fdf9a4  vmovaps [rsp+0x10], xmm1
0000798fc6fdf9aa  vmovaps [rsp+0x20], xmm2
0000798fc6fdf9b0  vmovaps [rsp+0x30], xmm3
0000798fc6fdf9b6  vmovaps [rsp+0x40], xmm4
0000798fc6fdf9bc  vmovaps [rsp+0x50], xmm5
0000798fc6fdf9c2  vmovaps [rsp+0x60], xmm6
0000798fc6fdf9c8  vmovaps [rsp+0x70], xmm7
0000798fc6fdf9ce  vmovaps [rsp+0x80], xmm8
0000798fc6fdf9d7  vmovaps [rsp+0x90], xmm9
0000798fc6fdf9e0  vmovaps [rsp+0xA0], xmm10
0000798fc6fdf9e9  vmovaps [rsp+0xB0], xmm11
0000798fc6fdf9f2  vmovaps [rsp+0xC0], xmm12
0000798fc6fdf9fb  vmovaps [rsp+0xD0], xmm14
0000798fc6fdfa04  vmovaps [rsp+0xE0], xmm15
0000798fc6fdfa0d  sub rsp, 0x30
0000798fc6fdfa11  movaps [rsp], xmm13
0000798fc6fdfa16  movaps [rsp+0x10], xmm15
0000798fc6fdfa1c  movaps [rsp+0x20], xmm9
0000798fc6fdfa22  lea rdi, [rsp]
0000798fc6fdfa26  mov esi, 0x00
0000798fc6fdfa2b  mov rax, 0x63E558B23530
0000798fc6fdfa35  call rax
0000798fc6fdfa37  movaps xmm13, [rsp]
0000798fc6fdfa3c  add rsp, 0x30
0000798fc6fdfa40  vmovaps xmm0, [rsp]
0000798fc6fdfa45  vmovaps xmm1, [rsp+0x10]
0000798fc6fdfa4b  vmovaps xmm2, [rsp+0x20]
0000798fc6fdfa51  vmovaps xmm3, [rsp+0x30]
0000798fc6fdfa57  vmovaps xmm4, [rsp+0x40]
0000798fc6fdfa5d  vmovaps xmm5, [rsp+0x50]
0000798fc6fdfa63  vmovaps xmm6, [rsp+0x60]
0000798fc6fdfa69  vmovaps xmm7, [rsp+0x70]
0000798fc6fdfa6f  vmovaps xmm8, [rsp+0x80]
0000798fc6fdfa78  vmovaps xmm9, [rsp+0x90]
0000798fc6fdfa81  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdfa8a  vmovaps xmm11, [rsp+0xB0]
0000798fc6fdfa93  vmovaps xmm12, [rsp+0xC0]
0000798fc6fdfa9c  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdfaa5  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdfaae  add rsp, 0xF0
0000798fc6fdfab5  pop r11
0000798fc6fdfab7  pop r10
0000798fc6fdfab9  pop r9
0000798fc6fdfabb  pop r8
0000798fc6fdfabd  pop rsi
0000798fc6fdfabe  pop rdi
0000798fc6fdfabf  pop rdx
0000798fc6fdfac0  pop rcx
0000798fc6fdfac1  pop rax
0000798fc6fdfac2  add rsp, 0x08
0000798fc6fdfac6  jmp 0x0000798FC6FDC458
0000798fc6fdfacb  sub rsp, 0x08
0000798fc6fdfacf  push rax
0000798fc6fdfad0  push rcx
0000798fc6fdfad1  push rdx
0000798fc6fdfad2  push rdi
0000798fc6fdfad3  push rsi
0000798fc6fdfad4  push r8
0000798fc6fdfad6  push r9
0000798fc6fdfad8  push r10
0000798fc6fdfada  push r11
0000798fc6fdfadc  sub rsp, 0xF0
0000798fc6fdfae3  vmovaps [rsp], xmm0
0000798fc6fdfae8  vmovaps [rsp+0x10], xmm1
0000798fc6fdfaee  vmovaps [rsp+0x20], xmm2
0000798fc6fdfaf4  vmovaps [rsp+0x30], xmm3
0000798fc6fdfafa  vmovaps [rsp+0x40], xmm4
0000798fc6fdfb00  vmovaps [rsp+0x50], xmm5
0000798fc6fdfb06  vmovaps [rsp+0x60], xmm6
0000798fc6fdfb0c  vmovaps [rsp+0x70], xmm7
0000798fc6fdfb12  vmovaps [rsp+0x80], xmm8
0000798fc6fdfb1b  vmovaps [rsp+0x90], xmm9
0000798fc6fdfb24  vmovaps [rsp+0xA0], xmm10
0000798fc6fdfb2d  vmovaps [rsp+0xB0], xmm11
0000798fc6fdfb36  vmovaps [rsp+0xC0], xmm12
0000798fc6fdfb3f  vmovaps [rsp+0xD0], xmm13
0000798fc6fdfb48  vmovaps [rsp+0xE0], xmm14
0000798fc6fdfb51  sub rsp, 0x30
0000798fc6fdfb55  movaps [rsp], xmm15
0000798fc6fdfb5a  movaps [rsp+0x10], xmm1
0000798fc6fdfb5f  movaps [rsp+0x20], xmm5
0000798fc6fdfb64  lea rdi, [rsp]
0000798fc6fdfb68  mov esi, 0x00
0000798fc6fdfb6d  mov rax, 0x63E558B23530
0000798fc6fdfb77  call rax
0000798fc6fdfb79  movaps xmm15, [rsp]
0000798fc6fdfb7e  add rsp, 0x30
0000798fc6fdfb82  vmovaps xmm0, [rsp]
0000798fc6fdfb87  vmovaps xmm1, [rsp+0x10]
0000798fc6fdfb8d  vmovaps xmm2, [rsp+0x20]
0000798fc6fdfb93  vmovaps xmm3, [rsp+0x30]
0000798fc6fdfb99  vmovaps xmm4, [rsp+0x40]
0000798fc6fdfb9f  vmovaps xmm5, [rsp+0x50]
0000798fc6fdfba5  vmovaps xmm6, [rsp+0x60]
0000798fc6fdfbab  vmovaps xmm7, [rsp+0x70]
0000798fc6fdfbb1  vmovaps xmm8, [rsp+0x80]
0000798fc6fdfbba  vmovaps xmm9, [rsp+0x90]
0000798fc6fdfbc3  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdfbcc  vmovaps xmm11, [rsp+0xB0]
0000798fc6fdfbd5  vmovaps xmm12, [rsp+0xC0]
0000798fc6fdfbde  vmovaps xmm13, [rsp+0xD0]
0000798fc6fdfbe7  vmovaps xmm14, [rsp+0xE0]
0000798fc6fdfbf0  add rsp, 0xF0
0000798fc6fdfbf7  pop r11
0000798fc6fdfbf9  pop r10
0000798fc6fdfbfb  pop r9
0000798fc6fdfbfd  pop r8
0000798fc6fdfbff  pop rsi
0000798fc6fdfc00  pop rdi
0000798fc6fdfc01  pop rdx
0000798fc6fdfc02  pop rcx
0000798fc6fdfc03  pop rax
0000798fc6fdfc04  add rsp, 0x08
0000798fc6fdfc08  jmp 0x0000798FC6FDC473
0000798fc6fdfc0d  call 0x0000798FC6EB52F0
0000798fc6fdfc12  jmp 0x0000798FC6FDC4CE
0000798fc6fdfc17  sub rsp, 0x08
0000798fc6fdfc1b  push rax
0000798fc6fdfc1c  push rcx
0000798fc6fdfc1d  push rdx
0000798fc6fdfc1e  push rdi
0000798fc6fdfc1f  push rsi
0000798fc6fdfc20  push r8
0000798fc6fdfc22  push r9
0000798fc6fdfc24  push r10
0000798fc6fdfc26  push r11
0000798fc6fdfc28  sub rsp, 0xF0
0000798fc6fdfc2f  vmovaps [rsp], xmm0
0000798fc6fdfc34  vmovaps [rsp+0x10], xmm1
0000798fc6fdfc3a  vmovaps [rsp+0x20], xmm2
0000798fc6fdfc40  vmovaps [rsp+0x30], xmm3
0000798fc6fdfc46  vmovaps [rsp+0x40], xmm4
0000798fc6fdfc4c  vmovaps [rsp+0x50], xmm5
0000798fc6fdfc52  vmovaps [rsp+0x60], xmm6
0000798fc6fdfc58  vmovaps [rsp+0x70], xmm7
0000798fc6fdfc5e  vmovaps [rsp+0x80], xmm8
0000798fc6fdfc67  vmovaps [rsp+0x90], xmm10
0000798fc6fdfc70  vmovaps [rsp+0xA0], xmm11
0000798fc6fdfc79  vmovaps [rsp+0xB0], xmm12
0000798fc6fdfc82  vmovaps [rsp+0xC0], xmm13
0000798fc6fdfc8b  vmovaps [rsp+0xD0], xmm14
0000798fc6fdfc94  vmovaps [rsp+0xE0], xmm15
0000798fc6fdfc9d  sub rsp, 0x30
0000798fc6fdfca1  movaps [rsp], xmm9
0000798fc6fdfca6  movaps [rsp+0x10], xmm8
0000798fc6fdfcac  movaps [rsp+0x20], xmm11
0000798fc6fdfcb2  lea rdi, [rsp]
0000798fc6fdfcb6  mov esi, 0x00
0000798fc6fdfcbb  mov rax, 0x63E558B23530
0000798fc6fdfcc5  call rax
0000798fc6fdfcc7  movaps xmm9, [rsp]
0000798fc6fdfccc  add rsp, 0x30
0000798fc6fdfcd0  vmovaps xmm0, [rsp]
0000798fc6fdfcd5  vmovaps xmm1, [rsp+0x10]
0000798fc6fdfcdb  vmovaps xmm2, [rsp+0x20]
0000798fc6fdfce1  vmovaps xmm3, [rsp+0x30]
0000798fc6fdfce7  vmovaps xmm4, [rsp+0x40]
0000798fc6fdfced  vmovaps xmm5, [rsp+0x50]
0000798fc6fdfcf3  vmovaps xmm6, [rsp+0x60]
0000798fc6fdfcf9  vmovaps xmm7, [rsp+0x70]
0000798fc6fdfcff  vmovaps xmm8, [rsp+0x80]
0000798fc6fdfd08  vmovaps xmm10, [rsp+0x90]
0000798fc6fdfd11  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdfd1a  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdfd23  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdfd2c  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdfd35  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdfd3e  add rsp, 0xF0
0000798fc6fdfd45  pop r11
0000798fc6fdfd47  pop r10
0000798fc6fdfd49  pop r9
0000798fc6fdfd4b  pop r8
0000798fc6fdfd4d  pop rsi
0000798fc6fdfd4e  pop rdi
0000798fc6fdfd4f  pop rdx
0000798fc6fdfd50  pop rcx
0000798fc6fdfd51  pop rax
0000798fc6fdfd52  add rsp, 0x08
0000798fc6fdfd56  jmp 0x0000798FC6FDC505
0000798fc6fdfd5b  sub rsp, 0x08
0000798fc6fdfd5f  push rax
0000798fc6fdfd60  push rcx
0000798fc6fdfd61  push rdx
0000798fc6fdfd62  push rdi
0000798fc6fdfd63  push rsi
0000798fc6fdfd64  push r8
0000798fc6fdfd66  push r9
0000798fc6fdfd68  push r10
0000798fc6fdfd6a  push r11
0000798fc6fdfd6c  sub rsp, 0xF0
0000798fc6fdfd73  vmovaps [rsp], xmm0
0000798fc6fdfd78  vmovaps [rsp+0x10], xmm1
0000798fc6fdfd7e  vmovaps [rsp+0x20], xmm2
0000798fc6fdfd84  vmovaps [rsp+0x30], xmm3
0000798fc6fdfd8a  vmovaps [rsp+0x40], xmm4
0000798fc6fdfd90  vmovaps [rsp+0x50], xmm5
0000798fc6fdfd96  vmovaps [rsp+0x60], xmm6
0000798fc6fdfd9c  vmovaps [rsp+0x70], xmm7
0000798fc6fdfda2  vmovaps [rsp+0x80], xmm8
0000798fc6fdfdab  vmovaps [rsp+0x90], xmm9
0000798fc6fdfdb4  vmovaps [rsp+0xA0], xmm10
0000798fc6fdfdbd  vmovaps [rsp+0xB0], xmm12
0000798fc6fdfdc6  vmovaps [rsp+0xC0], xmm13
0000798fc6fdfdcf  vmovaps [rsp+0xD0], xmm14
0000798fc6fdfdd8  vmovaps [rsp+0xE0], xmm15
0000798fc6fdfde1  sub rsp, 0x30
0000798fc6fdfde5  movaps [rsp], xmm11
0000798fc6fdfdea  movaps [rsp+0x10], xmm10
0000798fc6fdfdf0  movaps [rsp+0x20], xmm6
0000798fc6fdfdf5  lea rdi, [rsp]
0000798fc6fdfdf9  mov esi, 0x00
0000798fc6fdfdfe  mov rax, 0x63E558B23530
0000798fc6fdfe08  call rax
0000798fc6fdfe0a  movaps xmm11, [rsp]
0000798fc6fdfe0f  add rsp, 0x30
0000798fc6fdfe13  vmovaps xmm0, [rsp]
0000798fc6fdfe18  vmovaps xmm1, [rsp+0x10]
0000798fc6fdfe1e  vmovaps xmm2, [rsp+0x20]
0000798fc6fdfe24  vmovaps xmm3, [rsp+0x30]
0000798fc6fdfe2a  vmovaps xmm4, [rsp+0x40]
0000798fc6fdfe30  vmovaps xmm5, [rsp+0x50]
0000798fc6fdfe36  vmovaps xmm6, [rsp+0x60]
0000798fc6fdfe3c  vmovaps xmm7, [rsp+0x70]
0000798fc6fdfe42  vmovaps xmm8, [rsp+0x80]
0000798fc6fdfe4b  vmovaps xmm9, [rsp+0x90]
0000798fc6fdfe54  vmovaps xmm10, [rsp+0xA0]
0000798fc6fdfe5d  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdfe66  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdfe6f  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdfe78  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdfe81  add rsp, 0xF0
0000798fc6fdfe88  pop r11
0000798fc6fdfe8a  pop r10
0000798fc6fdfe8c  pop r9
0000798fc6fdfe8e  pop r8
0000798fc6fdfe90  pop rsi
0000798fc6fdfe91  pop rdi
0000798fc6fdfe92  pop rdx
0000798fc6fdfe93  pop rcx
0000798fc6fdfe94  pop rax
0000798fc6fdfe95  add rsp, 0x08
0000798fc6fdfe99  jmp 0x0000798FC6FDC520
0000798fc6fdfe9e  sub rsp, 0x08
0000798fc6fdfea2  push rax
0000798fc6fdfea3  push rcx
0000798fc6fdfea4  push rdx
0000798fc6fdfea5  push rdi
0000798fc6fdfea6  push rsi
0000798fc6fdfea7  push r8
0000798fc6fdfea9  push r9
0000798fc6fdfeab  push r10
0000798fc6fdfead  push r11
0000798fc6fdfeaf  sub rsp, 0xF0
0000798fc6fdfeb6  vmovaps [rsp], xmm0
0000798fc6fdfebb  vmovaps [rsp+0x10], xmm1
0000798fc6fdfec1  vmovaps [rsp+0x20], xmm2
0000798fc6fdfec7  vmovaps [rsp+0x30], xmm3
0000798fc6fdfecd  vmovaps [rsp+0x40], xmm4
0000798fc6fdfed3  vmovaps [rsp+0x50], xmm5
0000798fc6fdfed9  vmovaps [rsp+0x60], xmm6
0000798fc6fdfedf  vmovaps [rsp+0x70], xmm7
0000798fc6fdfee5  vmovaps [rsp+0x80], xmm8
0000798fc6fdfeee  vmovaps [rsp+0x90], xmm9
0000798fc6fdfef7  vmovaps [rsp+0xA0], xmm11
0000798fc6fdff00  vmovaps [rsp+0xB0], xmm12
0000798fc6fdff09  vmovaps [rsp+0xC0], xmm13
0000798fc6fdff12  vmovaps [rsp+0xD0], xmm14
0000798fc6fdff1b  vmovaps [rsp+0xE0], xmm15
0000798fc6fdff24  sub rsp, 0x30
0000798fc6fdff28  movaps [rsp], xmm10
0000798fc6fdff2d  movaps [rsp+0x10], xmm14
0000798fc6fdff33  movaps [rsp+0x20], xmm4
0000798fc6fdff38  lea rdi, [rsp]
0000798fc6fdff3c  mov esi, 0x00
0000798fc6fdff41  mov rax, 0x63E558B23530
0000798fc6fdff4b  call rax
0000798fc6fdff4d  movaps xmm10, [rsp]
0000798fc6fdff52  add rsp, 0x30
0000798fc6fdff56  vmovaps xmm0, [rsp]
0000798fc6fdff5b  vmovaps xmm1, [rsp+0x10]
0000798fc6fdff61  vmovaps xmm2, [rsp+0x20]
0000798fc6fdff67  vmovaps xmm3, [rsp+0x30]
0000798fc6fdff6d  vmovaps xmm4, [rsp+0x40]
0000798fc6fdff73  vmovaps xmm5, [rsp+0x50]
0000798fc6fdff79  vmovaps xmm6, [rsp+0x60]
0000798fc6fdff7f  vmovaps xmm7, [rsp+0x70]
0000798fc6fdff85  vmovaps xmm8, [rsp+0x80]
0000798fc6fdff8e  vmovaps xmm9, [rsp+0x90]
0000798fc6fdff97  vmovaps xmm11, [rsp+0xA0]
0000798fc6fdffa0  vmovaps xmm12, [rsp+0xB0]
0000798fc6fdffa9  vmovaps xmm13, [rsp+0xC0]
0000798fc6fdffb2  vmovaps xmm14, [rsp+0xD0]
0000798fc6fdffbb  vmovaps xmm15, [rsp+0xE0]
0000798fc6fdffc4  add rsp, 0xF0
0000798fc6fdffcb  pop r11
0000798fc6fdffcd  pop r10
0000798fc6fdffcf  pop r9
0000798fc6fdffd1  pop r8
0000798fc6fdffd3  pop rsi
0000798fc6fdffd4  pop rdi
0000798fc6fdffd5  pop rdx
0000798fc6fdffd6  pop rcx
0000798fc6fdffd7  pop rax
0000798fc6fdffd8  add rsp, 0x08
0000798fc6fdffdc  jmp 0x0000798FC6FDC53B
0000798fc6fdffe1  sub rsp, 0x08
0000798fc6fdffe5  push rax
0000798fc6fdffe6  push rcx
0000798fc6fdffe7  push rdx
0000798fc6fdffe8  push rdi
0000798fc6fdffe9  push rsi
0000798fc6fdffea  push r8
0000798fc6fdffec  push r9
0000798fc6fdffee  push r10
0000798fc6fdfff0  push r11
0000798fc6fdfff2  sub rsp, 0xF0
0000798fc6fdfff9  vmovaps [rsp], xmm0
0000798fc6fdfffe  vmovaps [rsp+0x10], xmm1
0000798fc6fe0004  vmovaps [rsp+0x20], xmm2
0000798fc6fe000a  vmovaps [rsp+0x30], xmm3
0000798fc6fe0010  vmovaps [rsp+0x40], xmm4
0000798fc6fe0016  vmovaps [rsp+0x50], xmm5
0000798fc6fe001c  vmovaps [rsp+0x60], xmm6
0000798fc6fe0022  vmovaps [rsp+0x70], xmm7
0000798fc6fe0028  vmovaps [rsp+0x80], xmm9
0000798fc6fe0031  vmovaps [rsp+0x90], xmm10
0000798fc6fe003a  vmovaps [rsp+0xA0], xmm11
0000798fc6fe0043  vmovaps [rsp+0xB0], xmm12
0000798fc6fe004c  vmovaps [rsp+0xC0], xmm13
0000798fc6fe0055  vmovaps [rsp+0xD0], xmm14
0000798fc6fe005e  vmovaps [rsp+0xE0], xmm15
0000798fc6fe0067  sub rsp, 0x30
0000798fc6fe006b  movaps [rsp], xmm8
0000798fc6fe0070  movaps [rsp+0x10], xmm1
0000798fc6fe0075  movaps [rsp+0x20], xmm14
0000798fc6fe007b  lea rdi, [rsp]
0000798fc6fe007f  mov esi, 0x00
0000798fc6fe0084  mov rax, 0x63E558B23530
0000798fc6fe008e  call rax
0000798fc6fe0090  movaps xmm8, [rsp]
0000798fc6fe0095  add rsp, 0x30
0000798fc6fe0099  vmovaps xmm0, [rsp]
0000798fc6fe009e  vmovaps xmm1, [rsp+0x10]
0000798fc6fe00a4  vmovaps xmm2, [rsp+0x20]
0000798fc6fe00aa  vmovaps xmm3, [rsp+0x30]
0000798fc6fe00b0  vmovaps xmm4, [rsp+0x40]
0000798fc6fe00b6  vmovaps xmm5, [rsp+0x50]
0000798fc6fe00bc  vmovaps xmm6, [rsp+0x60]
0000798fc6fe00c2  vmovaps xmm7, [rsp+0x70]
0000798fc6fe00c8  vmovaps xmm9, [rsp+0x80]
0000798fc6fe00d1  vmovaps xmm10, [rsp+0x90]
0000798fc6fe00da  vmovaps xmm11, [rsp+0xA0]
0000798fc6fe00e3  vmovaps xmm12, [rsp+0xB0]
0000798fc6fe00ec  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe00f5  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe00fe  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe0107  add rsp, 0xF0
0000798fc6fe010e  pop r11
0000798fc6fe0110  pop r10
0000798fc6fe0112  pop r9
0000798fc6fe0114  pop r8
0000798fc6fe0116  pop rsi
0000798fc6fe0117  pop rdi
0000798fc6fe0118  pop rdx
0000798fc6fe0119  pop rcx
0000798fc6fe011a  pop rax
0000798fc6fe011b  add rsp, 0x08
0000798fc6fe011f  jmp 0x0000798FC6FDC561
0000798fc6fe0124  sub rsp, 0x08
0000798fc6fe0128  push rax
0000798fc6fe0129  push rcx
0000798fc6fe012a  push rdx
0000798fc6fe012b  push rdi
0000798fc6fe012c  push rsi
0000798fc6fe012d  push r8
0000798fc6fe012f  push r9
0000798fc6fe0131  push r10
0000798fc6fe0133  push r11
0000798fc6fe0135  sub rsp, 0xF0
0000798fc6fe013c  vmovaps [rsp], xmm0
0000798fc6fe0141  vmovaps [rsp+0x10], xmm1
0000798fc6fe0147  vmovaps [rsp+0x20], xmm2
0000798fc6fe014d  vmovaps [rsp+0x30], xmm3
0000798fc6fe0153  vmovaps [rsp+0x40], xmm4
0000798fc6fe0159  vmovaps [rsp+0x50], xmm5
0000798fc6fe015f  vmovaps [rsp+0x60], xmm7
0000798fc6fe0165  vmovaps [rsp+0x70], xmm8
0000798fc6fe016b  vmovaps [rsp+0x80], xmm9
0000798fc6fe0174  vmovaps [rsp+0x90], xmm10
0000798fc6fe017d  vmovaps [rsp+0xA0], xmm11
0000798fc6fe0186  vmovaps [rsp+0xB0], xmm12
0000798fc6fe018f  vmovaps [rsp+0xC0], xmm13
0000798fc6fe0198  vmovaps [rsp+0xD0], xmm14
0000798fc6fe01a1  vmovaps [rsp+0xE0], xmm15
0000798fc6fe01aa  sub rsp, 0x30
0000798fc6fe01ae  movaps [rsp], xmm6
0000798fc6fe01b2  movaps [rsp+0x10], xmm1
0000798fc6fe01b7  movaps [rsp+0x20], xmm14
0000798fc6fe01bd  lea rdi, [rsp]
0000798fc6fe01c1  mov esi, 0x00
0000798fc6fe01c6  mov rax, 0x63E558B23530
0000798fc6fe01d0  call rax
0000798fc6fe01d2  movaps xmm6, [rsp]
0000798fc6fe01d6  add rsp, 0x30
0000798fc6fe01da  vmovaps xmm0, [rsp]
0000798fc6fe01df  vmovaps xmm1, [rsp+0x10]
0000798fc6fe01e5  vmovaps xmm2, [rsp+0x20]
0000798fc6fe01eb  vmovaps xmm3, [rsp+0x30]
0000798fc6fe01f1  vmovaps xmm4, [rsp+0x40]
0000798fc6fe01f7  vmovaps xmm5, [rsp+0x50]
0000798fc6fe01fd  vmovaps xmm7, [rsp+0x60]
0000798fc6fe0203  vmovaps xmm8, [rsp+0x70]
0000798fc6fe0209  vmovaps xmm9, [rsp+0x80]
0000798fc6fe0212  vmovaps xmm10, [rsp+0x90]
0000798fc6fe021b  vmovaps xmm11, [rsp+0xA0]
0000798fc6fe0224  vmovaps xmm12, [rsp+0xB0]
0000798fc6fe022d  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe0236  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe023f  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe0248  add rsp, 0xF0
0000798fc6fe024f  pop r11
0000798fc6fe0251  pop r10
0000798fc6fe0253  pop r9
0000798fc6fe0255  pop r8
0000798fc6fe0257  pop rsi
0000798fc6fe0258  pop rdi
0000798fc6fe0259  pop rdx
0000798fc6fe025a  pop rcx
0000798fc6fe025b  pop rax
0000798fc6fe025c  add rsp, 0x08
0000798fc6fe0260  jmp 0x0000798FC6FDC58D
0000798fc6fe0265  sub rsp, 0x08
0000798fc6fe0269  push rax
0000798fc6fe026a  push rcx
0000798fc6fe026b  push rdx
0000798fc6fe026c  push rdi
0000798fc6fe026d  push rsi
0000798fc6fe026e  push r8
0000798fc6fe0270  push r9
0000798fc6fe0272  push r10
0000798fc6fe0274  push r11
0000798fc6fe0276  sub rsp, 0xF0
0000798fc6fe027d  vmovaps [rsp], xmm0
0000798fc6fe0282  vmovaps [rsp+0x10], xmm1
0000798fc6fe0288  vmovaps [rsp+0x20], xmm2
0000798fc6fe028e  vmovaps [rsp+0x30], xmm3
0000798fc6fe0294  vmovaps [rsp+0x40], xmm4
0000798fc6fe029a  vmovaps [rsp+0x50], xmm5
0000798fc6fe02a0  vmovaps [rsp+0x60], xmm6
0000798fc6fe02a6  vmovaps [rsp+0x70], xmm7
0000798fc6fe02ac  vmovaps [rsp+0x80], xmm8
0000798fc6fe02b5  vmovaps [rsp+0x90], xmm9
0000798fc6fe02be  vmovaps [rsp+0xA0], xmm10
0000798fc6fe02c7  vmovaps [rsp+0xB0], xmm11
0000798fc6fe02d0  vmovaps [rsp+0xC0], xmm12
0000798fc6fe02d9  vmovaps [rsp+0xD0], xmm13
0000798fc6fe02e2  vmovaps [rsp+0xE0], xmm15
0000798fc6fe02eb  sub rsp, 0x30
0000798fc6fe02ef  movaps [rsp], xmm14
0000798fc6fe02f4  movaps [rsp+0x10], xmm12
0000798fc6fe02fa  movaps [rsp+0x20], xmm1
0000798fc6fe02ff  lea rdi, [rsp]
0000798fc6fe0303  mov esi, 0x00
0000798fc6fe0308  mov rax, 0x63E558B23530
0000798fc6fe0312  call rax
0000798fc6fe0314  movaps xmm14, [rsp]
0000798fc6fe0319  add rsp, 0x30
0000798fc6fe031d  vmovaps xmm0, [rsp]
0000798fc6fe0322  vmovaps xmm1, [rsp+0x10]
0000798fc6fe0328  vmovaps xmm2, [rsp+0x20]
0000798fc6fe032e  vmovaps xmm3, [rsp+0x30]
0000798fc6fe0334  vmovaps xmm4, [rsp+0x40]
0000798fc6fe033a  vmovaps xmm5, [rsp+0x50]
0000798fc6fe0340  vmovaps xmm6, [rsp+0x60]
0000798fc6fe0346  vmovaps xmm7, [rsp+0x70]
0000798fc6fe034c  vmovaps xmm8, [rsp+0x80]
0000798fc6fe0355  vmovaps xmm9, [rsp+0x90]
0000798fc6fe035e  vmovaps xmm10, [rsp+0xA0]
0000798fc6fe0367  vmovaps xmm11, [rsp+0xB0]
0000798fc6fe0370  vmovaps xmm12, [rsp+0xC0]
0000798fc6fe0379  vmovaps xmm13, [rsp+0xD0]
0000798fc6fe0382  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe038b  add rsp, 0xF0
0000798fc6fe0392  pop r11
0000798fc6fe0394  pop r10
0000798fc6fe0396  pop r9
0000798fc6fe0398  pop r8
0000798fc6fe039a  pop rsi
0000798fc6fe039b  pop rdi
0000798fc6fe039c  pop rdx
0000798fc6fe039d  pop rcx
0000798fc6fe039e  pop rax
0000798fc6fe039f  add rsp, 0x08
0000798fc6fe03a3  jmp 0x0000798FC6FDC5B3
0000798fc6fe03a8  sub rsp, 0x08
0000798fc6fe03ac  push rax
0000798fc6fe03ad  push rcx
0000798fc6fe03ae  push rdx
0000798fc6fe03af  push rdi
0000798fc6fe03b0  push rsi
0000798fc6fe03b1  push r8
0000798fc6fe03b3  push r9
0000798fc6fe03b5  push r10
0000798fc6fe03b7  push r11
0000798fc6fe03b9  sub rsp, 0xF0
0000798fc6fe03c0  vmovaps [rsp], xmm0
0000798fc6fe03c5  vmovaps [rsp+0x10], xmm2
0000798fc6fe03cb  vmovaps [rsp+0x20], xmm3
0000798fc6fe03d1  vmovaps [rsp+0x30], xmm4
0000798fc6fe03d7  vmovaps [rsp+0x40], xmm5
0000798fc6fe03dd  vmovaps [rsp+0x50], xmm6
0000798fc6fe03e3  vmovaps [rsp+0x60], xmm7
0000798fc6fe03e9  vmovaps [rsp+0x70], xmm8
0000798fc6fe03ef  vmovaps [rsp+0x80], xmm9
0000798fc6fe03f8  vmovaps [rsp+0x90], xmm10
0000798fc6fe0401  vmovaps [rsp+0xA0], xmm11
0000798fc6fe040a  vmovaps [rsp+0xB0], xmm12
0000798fc6fe0413  vmovaps [rsp+0xC0], xmm13
0000798fc6fe041c  vmovaps [rsp+0xD0], xmm14
0000798fc6fe0425  vmovaps [rsp+0xE0], xmm15
0000798fc6fe042e  sub rsp, 0x30
0000798fc6fe0432  movaps [rsp], xmm1
0000798fc6fe0436  movaps [rsp+0x10], xmm13
0000798fc6fe043c  movaps [rsp+0x20], xmm9
0000798fc6fe0442  lea rdi, [rsp]
0000798fc6fe0446  mov esi, 0x00
0000798fc6fe044b  mov rax, 0x63E558B23530
0000798fc6fe0455  call rax
0000798fc6fe0457  movaps xmm1, [rsp]
0000798fc6fe045b  add rsp, 0x30
0000798fc6fe045f  vmovaps xmm0, [rsp]
0000798fc6fe0464  vmovaps xmm2, [rsp+0x10]
0000798fc6fe046a  vmovaps xmm3, [rsp+0x20]
0000798fc6fe0470  vmovaps xmm4, [rsp+0x30]
0000798fc6fe0476  vmovaps xmm5, [rsp+0x40]
0000798fc6fe047c  vmovaps xmm6, [rsp+0x50]
0000798fc6fe0482  vmovaps xmm7, [rsp+0x60]
0000798fc6fe0488  vmovaps xmm8, [rsp+0x70]
0000798fc6fe048e  vmovaps xmm9, [rsp+0x80]
0000798fc6fe0497  vmovaps xmm10, [rsp+0x90]
0000798fc6fe04a0  vmovaps xmm11, [rsp+0xA0]
0000798fc6fe04a9  vmovaps xmm12, [rsp+0xB0]
0000798fc6fe04b2  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe04bb  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe04c4  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe04cd  add rsp, 0xF0
0000798fc6fe04d4  pop r11
0000798fc6fe04d6  pop r10
0000798fc6fe04d8  pop r9
0000798fc6fe04da  pop r8
0000798fc6fe04dc  pop rsi
0000798fc6fe04dd  pop rdi
0000798fc6fe04de  pop rdx
0000798fc6fe04df  pop rcx
0000798fc6fe04e0  pop rax
0000798fc6fe04e1  add rsp, 0x08
0000798fc6fe04e5  jmp 0x0000798FC6FDC5CD
0000798fc6fe04ea  sub rsp, 0x08
0000798fc6fe04ee  push rax
0000798fc6fe04ef  push rcx
0000798fc6fe04f0  push rdx
0000798fc6fe04f1  push rdi
0000798fc6fe04f2  push rsi
0000798fc6fe04f3  push r8
0000798fc6fe04f5  push r9
0000798fc6fe04f7  push r10
0000798fc6fe04f9  push r11
0000798fc6fe04fb  sub rsp, 0xF0
0000798fc6fe0502  vmovaps [rsp], xmm0
0000798fc6fe0507  vmovaps [rsp+0x10], xmm1
0000798fc6fe050d  vmovaps [rsp+0x20], xmm2
0000798fc6fe0513  vmovaps [rsp+0x30], xmm3
0000798fc6fe0519  vmovaps [rsp+0x40], xmm4
0000798fc6fe051f  vmovaps [rsp+0x50], xmm5
0000798fc6fe0525  vmovaps [rsp+0x60], xmm6
0000798fc6fe052b  vmovaps [rsp+0x70], xmm7
0000798fc6fe0531  vmovaps [rsp+0x80], xmm8
0000798fc6fe053a  vmovaps [rsp+0x90], xmm9
0000798fc6fe0543  vmovaps [rsp+0xA0], xmm10
0000798fc6fe054c  vmovaps [rsp+0xB0], xmm11
0000798fc6fe0555  vmovaps [rsp+0xC0], xmm13
0000798fc6fe055e  vmovaps [rsp+0xD0], xmm14
0000798fc6fe0567  vmovaps [rsp+0xE0], xmm15
0000798fc6fe0570  sub rsp, 0x30
0000798fc6fe0574  movaps [rsp], xmm12
0000798fc6fe0579  movaps [rsp+0x10], xmm7
0000798fc6fe057e  movaps [rsp+0x20], xmm13
0000798fc6fe0584  lea rdi, [rsp]
0000798fc6fe0588  mov esi, 0x00
0000798fc6fe058d  mov rax, 0x63E558B23530
0000798fc6fe0597  call rax
0000798fc6fe0599  movaps xmm12, [rsp]
0000798fc6fe059e  add rsp, 0x30
0000798fc6fe05a2  vmovaps xmm0, [rsp]
0000798fc6fe05a7  vmovaps xmm1, [rsp+0x10]
0000798fc6fe05ad  vmovaps xmm2, [rsp+0x20]
0000798fc6fe05b3  vmovaps xmm3, [rsp+0x30]
0000798fc6fe05b9  vmovaps xmm4, [rsp+0x40]
0000798fc6fe05bf  vmovaps xmm5, [rsp+0x50]
0000798fc6fe05c5  vmovaps xmm6, [rsp+0x60]
0000798fc6fe05cb  vmovaps xmm7, [rsp+0x70]
0000798fc6fe05d1  vmovaps xmm8, [rsp+0x80]
0000798fc6fe05da  vmovaps xmm9, [rsp+0x90]
0000798fc6fe05e3  vmovaps xmm10, [rsp+0xA0]
0000798fc6fe05ec  vmovaps xmm11, [rsp+0xB0]
0000798fc6fe05f5  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe05fe  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe0607  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe0610  add rsp, 0xF0
0000798fc6fe0617  pop r11
0000798fc6fe0619  pop r10
0000798fc6fe061b  pop r9
0000798fc6fe061d  pop r8
0000798fc6fe061f  pop rsi
0000798fc6fe0620  pop rdi
0000798fc6fe0621  pop rdx
0000798fc6fe0622  pop rcx
0000798fc6fe0623  pop rax
0000798fc6fe0624  add rsp, 0x08
0000798fc6fe0628  jmp 0x0000798FC6FDC5F4
0000798fc6fe062d  sub rsp, 0x08
0000798fc6fe0631  push rax
0000798fc6fe0632  push rcx
0000798fc6fe0633  push rdx
0000798fc6fe0634  push rdi
0000798fc6fe0635  push rsi
0000798fc6fe0636  push r8
0000798fc6fe0638  push r9
0000798fc6fe063a  push r10
0000798fc6fe063c  push r11
0000798fc6fe063e  sub rsp, 0xF0
0000798fc6fe0645  vmovaps [rsp], xmm0
0000798fc6fe064a  vmovaps [rsp+0x10], xmm1
0000798fc6fe0650  vmovaps [rsp+0x20], xmm2
0000798fc6fe0656  vmovaps [rsp+0x30], xmm3
0000798fc6fe065c  vmovaps [rsp+0x40], xmm4
0000798fc6fe0662  vmovaps [rsp+0x50], xmm5
0000798fc6fe0668  vmovaps [rsp+0x60], xmm6
0000798fc6fe066e  vmovaps [rsp+0x70], xmm7
0000798fc6fe0674  vmovaps [rsp+0x80], xmm8
0000798fc6fe067d  vmovaps [rsp+0x90], xmm9
0000798fc6fe0686  vmovaps [rsp+0xA0], xmm10
0000798fc6fe068f  vmovaps [rsp+0xB0], xmm11
0000798fc6fe0698  vmovaps [rsp+0xC0], xmm12
0000798fc6fe06a1  vmovaps [rsp+0xD0], xmm14
0000798fc6fe06aa  vmovaps [rsp+0xE0], xmm15
0000798fc6fe06b3  sub rsp, 0x30
0000798fc6fe06b7  movaps [rsp], xmm13
0000798fc6fe06bc  movaps [rsp+0x10], xmm15
0000798fc6fe06c2  movaps [rsp+0x20], xmm8
0000798fc6fe06c8  lea rdi, [rsp]
0000798fc6fe06cc  mov esi, 0x00
0000798fc6fe06d1  mov rax, 0x63E558B23530
0000798fc6fe06db  call rax
0000798fc6fe06dd  movaps xmm13, [rsp]
0000798fc6fe06e2  add rsp, 0x30
0000798fc6fe06e6  vmovaps xmm0, [rsp]
0000798fc6fe06eb  vmovaps xmm1, [rsp+0x10]
0000798fc6fe06f1  vmovaps xmm2, [rsp+0x20]
0000798fc6fe06f7  vmovaps xmm3, [rsp+0x30]
0000798fc6fe06fd  vmovaps xmm4, [rsp+0x40]
0000798fc6fe0703  vmovaps xmm5, [rsp+0x50]
0000798fc6fe0709  vmovaps xmm6, [rsp+0x60]
0000798fc6fe070f  vmovaps xmm7, [rsp+0x70]
0000798fc6fe0715  vmovaps xmm8, [rsp+0x80]
0000798fc6fe071e  vmovaps xmm9, [rsp+0x90]
0000798fc6fe0727  vmovaps xmm10, [rsp+0xA0]
0000798fc6fe0730  vmovaps xmm11, [rsp+0xB0]
0000798fc6fe0739  vmovaps xmm12, [rsp+0xC0]
0000798fc6fe0742  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe074b  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe0754  add rsp, 0xF0
0000798fc6fe075b  pop r11
0000798fc6fe075d  pop r10
0000798fc6fe075f  pop r9
0000798fc6fe0761  pop r8
0000798fc6fe0763  pop rsi
0000798fc6fe0764  pop rdi
0000798fc6fe0765  pop rdx
0000798fc6fe0766  pop rcx
0000798fc6fe0767  pop rax
0000798fc6fe0768  add rsp, 0x08
0000798fc6fe076c  jmp 0x0000798FC6FDC60F
0000798fc6fe0771  sub rsp, 0x08
0000798fc6fe0775  push rax
0000798fc6fe0776  push rcx
0000798fc6fe0777  push rdx
0000798fc6fe0778  push rdi
0000798fc6fe0779  push rsi
0000798fc6fe077a  push r8
0000798fc6fe077c  push r9
0000798fc6fe077e  push r10
0000798fc6fe0780  push r11
0000798fc6fe0782  sub rsp, 0xF0
0000798fc6fe0789  vmovaps [rsp], xmm0
0000798fc6fe078e  vmovaps [rsp+0x10], xmm1
0000798fc6fe0794  vmovaps [rsp+0x20], xmm2
0000798fc6fe079a  vmovaps [rsp+0x30], xmm3
0000798fc6fe07a0  vmovaps [rsp+0x40], xmm4
0000798fc6fe07a6  vmovaps [rsp+0x50], xmm5
0000798fc6fe07ac  vmovaps [rsp+0x60], xmm6
0000798fc6fe07b2  vmovaps [rsp+0x70], xmm7
0000798fc6fe07b8  vmovaps [rsp+0x80], xmm9
0000798fc6fe07c1  vmovaps [rsp+0x90], xmm10
0000798fc6fe07ca  vmovaps [rsp+0xA0], xmm11
0000798fc6fe07d3  vmovaps [rsp+0xB0], xmm12
0000798fc6fe07dc  vmovaps [rsp+0xC0], xmm13
0000798fc6fe07e5  vmovaps [rsp+0xD0], xmm14
0000798fc6fe07ee  vmovaps [rsp+0xE0], xmm15
0000798fc6fe07f7  sub rsp, 0x30
0000798fc6fe07fb  movaps [rsp], xmm8
0000798fc6fe0800  movaps [rsp+0x10], xmm15
0000798fc6fe0806  movaps [rsp+0x20], xmm9
0000798fc6fe080c  lea rdi, [rsp]
0000798fc6fe0810  mov esi, 0x00
0000798fc6fe0815  mov rax, 0x63E558B23530
0000798fc6fe081f  call rax
0000798fc6fe0821  movaps xmm8, [rsp]
0000798fc6fe0826  add rsp, 0x30
0000798fc6fe082a  vmovaps xmm0, [rsp]
0000798fc6fe082f  vmovaps xmm1, [rsp+0x10]
0000798fc6fe0835  vmovaps xmm2, [rsp+0x20]
0000798fc6fe083b  vmovaps xmm3, [rsp+0x30]
0000798fc6fe0841  vmovaps xmm4, [rsp+0x40]
0000798fc6fe0847  vmovaps xmm5, [rsp+0x50]
0000798fc6fe084d  vmovaps xmm6, [rsp+0x60]
0000798fc6fe0853  vmovaps xmm7, [rsp+0x70]
0000798fc6fe0859  vmovaps xmm9, [rsp+0x80]
0000798fc6fe0862  vmovaps xmm10, [rsp+0x90]
0000798fc6fe086b  vmovaps xmm11, [rsp+0xA0]
0000798fc6fe0874  vmovaps xmm12, [rsp+0xB0]
0000798fc6fe087d  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe0886  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe088f  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe0898  add rsp, 0xF0
0000798fc6fe089f  pop r11
0000798fc6fe08a1  pop r10
0000798fc6fe08a3  pop r9
0000798fc6fe08a5  pop r8
0000798fc6fe08a7  pop rsi
0000798fc6fe08a8  pop rdi
0000798fc6fe08a9  pop rdx
0000798fc6fe08aa  pop rcx
0000798fc6fe08ab  pop rax
0000798fc6fe08ac  add rsp, 0x08
0000798fc6fe08b0  jmp 0x0000798FC6FDC63D
0000798fc6fe08b5  sub rsp, 0x08
0000798fc6fe08b9  push rax
0000798fc6fe08ba  push rcx
0000798fc6fe08bb  push rdx
0000798fc6fe08bc  push rdi
0000798fc6fe08bd  push rsi
0000798fc6fe08be  push r8
0000798fc6fe08c0  push r9
0000798fc6fe08c2  push r10
0000798fc6fe08c4  push r11
0000798fc6fe08c6  sub rsp, 0xF0
0000798fc6fe08cd  vmovaps [rsp], xmm0
0000798fc6fe08d2  vmovaps [rsp+0x10], xmm1
0000798fc6fe08d8  vmovaps [rsp+0x20], xmm2
0000798fc6fe08de  vmovaps [rsp+0x30], xmm3
0000798fc6fe08e4  vmovaps [rsp+0x40], xmm4
0000798fc6fe08ea  vmovaps [rsp+0x50], xmm5
0000798fc6fe08f0  vmovaps [rsp+0x60], xmm6
0000798fc6fe08f6  vmovaps [rsp+0x70], xmm7
0000798fc6fe08fc  vmovaps [rsp+0x80], xmm8
0000798fc6fe0905  vmovaps [rsp+0x90], xmm9
0000798fc6fe090e  vmovaps [rsp+0xA0], xmm10
0000798fc6fe0917  vmovaps [rsp+0xB0], xmm11
0000798fc6fe0920  vmovaps [rsp+0xC0], xmm12
0000798fc6fe0929  vmovaps [rsp+0xD0], xmm13
0000798fc6fe0932  vmovaps [rsp+0xE0], xmm14
0000798fc6fe093b  sub rsp, 0x30
0000798fc6fe093f  movaps [rsp], xmm15
0000798fc6fe0944  movaps [rsp+0x10], xmm11
0000798fc6fe094a  movaps [rsp+0x20], xmm6
0000798fc6fe094f  lea rdi, [rsp]
0000798fc6fe0953  mov esi, 0x00
0000798fc6fe0958  mov rax, 0x63E558B23530
0000798fc6fe0962  call rax
0000798fc6fe0964  movaps xmm15, [rsp]
0000798fc6fe0969  add rsp, 0x30
0000798fc6fe096d  vmovaps xmm0, [rsp]
0000798fc6fe0972  vmovaps xmm1, [rsp+0x10]
0000798fc6fe0978  vmovaps xmm2, [rsp+0x20]
0000798fc6fe097e  vmovaps xmm3, [rsp+0x30]
0000798fc6fe0984  vmovaps xmm4, [rsp+0x40]
0000798fc6fe098a  vmovaps xmm5, [rsp+0x50]
0000798fc6fe0990  vmovaps xmm6, [rsp+0x60]
0000798fc6fe0996  vmovaps xmm7, [rsp+0x70]
0000798fc6fe099c  vmovaps xmm8, [rsp+0x80]
0000798fc6fe09a5  vmovaps xmm9, [rsp+0x90]
0000798fc6fe09ae  vmovaps xmm10, [rsp+0xA0]
0000798fc6fe09b7  vmovaps xmm11, [rsp+0xB0]
0000798fc6fe09c0  vmovaps xmm12, [rsp+0xC0]
0000798fc6fe09c9  vmovaps xmm13, [rsp+0xD0]
0000798fc6fe09d2  vmovaps xmm14, [rsp+0xE0]
0000798fc6fe09db  add rsp, 0xF0
0000798fc6fe09e2  pop r11
0000798fc6fe09e4  pop r10
0000798fc6fe09e6  pop r9
0000798fc6fe09e8  pop r8
0000798fc6fe09ea  pop rsi
0000798fc6fe09eb  pop rdi
0000798fc6fe09ec  pop rdx
0000798fc6fe09ed  pop rcx
0000798fc6fe09ee  pop rax
0000798fc6fe09ef  add rsp, 0x08
0000798fc6fe09f3  jmp 0x0000798FC6FDC658
0000798fc6fe09f8  sub rsp, 0x08
0000798fc6fe09fc  push rax
0000798fc6fe09fd  push rcx
0000798fc6fe09fe  push rdx
0000798fc6fe09ff  push rdi
0000798fc6fe0a00  push rsi
0000798fc6fe0a01  push r8
0000798fc6fe0a03  push r9
0000798fc6fe0a05  push r10
0000798fc6fe0a07  push r11
0000798fc6fe0a09  sub rsp, 0xF0
0000798fc6fe0a10  vmovaps [rsp], xmm0
0000798fc6fe0a15  vmovaps [rsp+0x10], xmm1
0000798fc6fe0a1b  vmovaps [rsp+0x20], xmm2
0000798fc6fe0a21  vmovaps [rsp+0x30], xmm3
0000798fc6fe0a27  vmovaps [rsp+0x40], xmm4
0000798fc6fe0a2d  vmovaps [rsp+0x50], xmm5
0000798fc6fe0a33  vmovaps [rsp+0x60], xmm6
0000798fc6fe0a39  vmovaps [rsp+0x70], xmm8
0000798fc6fe0a3f  vmovaps [rsp+0x80], xmm9
0000798fc6fe0a48  vmovaps [rsp+0x90], xmm10
0000798fc6fe0a51  vmovaps [rsp+0xA0], xmm11
0000798fc6fe0a5a  vmovaps [rsp+0xB0], xmm12
0000798fc6fe0a63  vmovaps [rsp+0xC0], xmm13
0000798fc6fe0a6c  vmovaps [rsp+0xD0], xmm14
0000798fc6fe0a75  vmovaps [rsp+0xE0], xmm15
0000798fc6fe0a7e  sub rsp, 0x30
0000798fc6fe0a82  movaps [rsp], xmm7
0000798fc6fe0a86  movaps [rsp+0x10], xmm11
0000798fc6fe0a8c  movaps [rsp+0x20], xmm9
0000798fc6fe0a92  lea rdi, [rsp]
0000798fc6fe0a96  mov esi, 0x00
0000798fc6fe0a9b  mov rax, 0x63E558B23530
0000798fc6fe0aa5  call rax
0000798fc6fe0aa7  movaps xmm7, [rsp]
0000798fc6fe0aab  add rsp, 0x30
0000798fc6fe0aaf  vmovaps xmm0, [rsp]
0000798fc6fe0ab4  vmovaps xmm1, [rsp+0x10]
0000798fc6fe0aba  vmovaps xmm2, [rsp+0x20]
0000798fc6fe0ac0  vmovaps xmm3, [rsp+0x30]
0000798fc6fe0ac6  vmovaps xmm4, [rsp+0x40]
0000798fc6fe0acc  vmovaps xmm5, [rsp+0x50]
0000798fc6fe0ad2  vmovaps xmm6, [rsp+0x60]
0000798fc6fe0ad8  vmovaps xmm8, [rsp+0x70]
0000798fc6fe0ade  vmovaps xmm9, [rsp+0x80]
0000798fc6fe0ae7  vmovaps xmm10, [rsp+0x90]
0000798fc6fe0af0  vmovaps xmm11, [rsp+0xA0]
0000798fc6fe0af9  vmovaps xmm12, [rsp+0xB0]
0000798fc6fe0b02  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe0b0b  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe0b14  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe0b1d  add rsp, 0xF0
0000798fc6fe0b24  pop r11
0000798fc6fe0b26  pop r10
0000798fc6fe0b28  pop r9
0000798fc6fe0b2a  pop r8
0000798fc6fe0b2c  pop rsi
0000798fc6fe0b2d  pop rdi
0000798fc6fe0b2e  pop rdx
0000798fc6fe0b2f  pop rcx
0000798fc6fe0b30  pop rax
0000798fc6fe0b31  add rsp, 0x08
0000798fc6fe0b35  jmp 0x0000798FC6FDC685
0000798fc6fe0b3a  sub rsp, 0x08
0000798fc6fe0b3e  push rax
0000798fc6fe0b3f  push rcx
0000798fc6fe0b40  push rdx
0000798fc6fe0b41  push rdi
0000798fc6fe0b42  push rsi
0000798fc6fe0b43  push r8
0000798fc6fe0b45  push r9
0000798fc6fe0b47  push r10
0000798fc6fe0b49  push r11
0000798fc6fe0b4b  sub rsp, 0xF0
0000798fc6fe0b52  vmovaps [rsp], xmm0
0000798fc6fe0b57  vmovaps [rsp+0x10], xmm1
0000798fc6fe0b5d  vmovaps [rsp+0x20], xmm2
0000798fc6fe0b63  vmovaps [rsp+0x30], xmm3
0000798fc6fe0b69  vmovaps [rsp+0x40], xmm4
0000798fc6fe0b6f  vmovaps [rsp+0x50], xmm5
0000798fc6fe0b75  vmovaps [rsp+0x60], xmm6
0000798fc6fe0b7b  vmovaps [rsp+0x70], xmm7
0000798fc6fe0b81  vmovaps [rsp+0x80], xmm8
0000798fc6fe0b8a  vmovaps [rsp+0x90], xmm9
0000798fc6fe0b93  vmovaps [rsp+0xA0], xmm10
0000798fc6fe0b9c  vmovaps [rsp+0xB0], xmm12
0000798fc6fe0ba5  vmovaps [rsp+0xC0], xmm13
0000798fc6fe0bae  vmovaps [rsp+0xD0], xmm14
0000798fc6fe0bb7  vmovaps [rsp+0xE0], xmm15
0000798fc6fe0bc0  sub rsp, 0x30
0000798fc6fe0bc4  movaps [rsp], xmm11
0000798fc6fe0bc9  movaps [rsp+0x10], xmm10
0000798fc6fe0bcf  movaps [rsp+0x20], xmm14
0000798fc6fe0bd5  lea rdi, [rsp]
0000798fc6fe0bd9  mov esi, 0x00
0000798fc6fe0bde  mov rax, 0x63E558B23530
0000798fc6fe0be8  call rax
0000798fc6fe0bea  movaps xmm11, [rsp]
0000798fc6fe0bef  add rsp, 0x30
0000798fc6fe0bf3  vmovaps xmm0, [rsp]
0000798fc6fe0bf8  vmovaps xmm1, [rsp+0x10]
0000798fc6fe0bfe  vmovaps xmm2, [rsp+0x20]
0000798fc6fe0c04  vmovaps xmm3, [rsp+0x30]
0000798fc6fe0c0a  vmovaps xmm4, [rsp+0x40]
0000798fc6fe0c10  vmovaps xmm5, [rsp+0x50]
0000798fc6fe0c16  vmovaps xmm6, [rsp+0x60]
0000798fc6fe0c1c  vmovaps xmm7, [rsp+0x70]
0000798fc6fe0c22  vmovaps xmm8, [rsp+0x80]
0000798fc6fe0c2b  vmovaps xmm9, [rsp+0x90]
0000798fc6fe0c34  vmovaps xmm10, [rsp+0xA0]
0000798fc6fe0c3d  vmovaps xmm12, [rsp+0xB0]
0000798fc6fe0c46  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe0c4f  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe0c58  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe0c61  add rsp, 0xF0
0000798fc6fe0c68  pop r11
0000798fc6fe0c6a  pop r10
0000798fc6fe0c6c  pop r9
0000798fc6fe0c6e  pop r8
0000798fc6fe0c70  pop rsi
0000798fc6fe0c71  pop rdi
0000798fc6fe0c72  pop rdx
0000798fc6fe0c73  pop rcx
0000798fc6fe0c74  pop rax
0000798fc6fe0c75  add rsp, 0x08
0000798fc6fe0c79  jmp 0x0000798FC6FDC6A0
0000798fc6fe0c7e  call 0x0000798FC6EC33A0
0000798fc6fe0c83  jmp 0x0000798FC6FDC6AA
0000798fc6fe0c88  sub rsp, 0x08
0000798fc6fe0c8c  push rax
0000798fc6fe0c8d  push rcx
0000798fc6fe0c8e  push rdx
0000798fc6fe0c8f  push rdi
0000798fc6fe0c90  push rsi
0000798fc6fe0c91  push r8
0000798fc6fe0c93  push r9
0000798fc6fe0c95  push r10
0000798fc6fe0c97  push r11
0000798fc6fe0c99  sub rsp, 0xF0
0000798fc6fe0ca0  vmovaps [rsp], xmm0
0000798fc6fe0ca5  vmovaps [rsp+0x10], xmm1
0000798fc6fe0cab  vmovaps [rsp+0x20], xmm2
0000798fc6fe0cb1  vmovaps [rsp+0x30], xmm3
0000798fc6fe0cb7  vmovaps [rsp+0x40], xmm4
0000798fc6fe0cbd  vmovaps [rsp+0x50], xmm5
0000798fc6fe0cc3  vmovaps [rsp+0x60], xmm6
0000798fc6fe0cc9  vmovaps [rsp+0x70], xmm7
0000798fc6fe0ccf  vmovaps [rsp+0x80], xmm8
0000798fc6fe0cd8  vmovaps [rsp+0x90], xmm9
0000798fc6fe0ce1  vmovaps [rsp+0xA0], xmm11
0000798fc6fe0cea  vmovaps [rsp+0xB0], xmm12
0000798fc6fe0cf3  vmovaps [rsp+0xC0], xmm13
0000798fc6fe0cfc  vmovaps [rsp+0xD0], xmm14
0000798fc6fe0d05  vmovaps [rsp+0xE0], xmm15
0000798fc6fe0d0e  sub rsp, 0x30
0000798fc6fe0d12  movaps [rsp], xmm10
0000798fc6fe0d17  movaps [rsp+0x10], xmm1
0000798fc6fe0d1c  movaps [rsp+0x20], xmm12
0000798fc6fe0d22  lea rdi, [rsp]
0000798fc6fe0d26  mov esi, 0x00
0000798fc6fe0d2b  mov rax, 0x63E558B23530
0000798fc6fe0d35  call rax
0000798fc6fe0d37  movaps xmm10, [rsp]
0000798fc6fe0d3c  add rsp, 0x30
0000798fc6fe0d40  vmovaps xmm0, [rsp]
0000798fc6fe0d45  vmovaps xmm1, [rsp+0x10]
0000798fc6fe0d4b  vmovaps xmm2, [rsp+0x20]
0000798fc6fe0d51  vmovaps xmm3, [rsp+0x30]
0000798fc6fe0d57  vmovaps xmm4, [rsp+0x40]
0000798fc6fe0d5d  vmovaps xmm5, [rsp+0x50]
0000798fc6fe0d63  vmovaps xmm6, [rsp+0x60]
0000798fc6fe0d69  vmovaps xmm7, [rsp+0x70]
0000798fc6fe0d6f  vmovaps xmm8, [rsp+0x80]
0000798fc6fe0d78  vmovaps xmm9, [rsp+0x90]
0000798fc6fe0d81  vmovaps xmm11, [rsp+0xA0]
0000798fc6fe0d8a  vmovaps xmm12, [rsp+0xB0]
0000798fc6fe0d93  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe0d9c  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe0da5  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe0dae  add rsp, 0xF0
0000798fc6fe0db5  pop r11
0000798fc6fe0db7  pop r10
0000798fc6fe0db9  pop r9
0000798fc6fe0dbb  pop r8
0000798fc6fe0dbd  pop rsi
0000798fc6fe0dbe  pop rdi
0000798fc6fe0dbf  pop rdx
0000798fc6fe0dc0  pop rcx
0000798fc6fe0dc1  pop rax
0000798fc6fe0dc2  add rsp, 0x08
0000798fc6fe0dc6  jmp 0x0000798FC6FDC6CD
0000798fc6fe0dcb  sub rsp, 0x08
0000798fc6fe0dcf  push rax
0000798fc6fe0dd0  push rcx
0000798fc6fe0dd1  push rdx
0000798fc6fe0dd2  push rdi
0000798fc6fe0dd3  push rsi
0000798fc6fe0dd4  push r8
0000798fc6fe0dd6  push r9
0000798fc6fe0dd8  push r10
0000798fc6fe0dda  push r11
0000798fc6fe0ddc  sub rsp, 0xF0
0000798fc6fe0de3  vmovaps [rsp], xmm0
0000798fc6fe0de8  vmovaps [rsp+0x10], xmm1
0000798fc6fe0dee  vmovaps [rsp+0x20], xmm2
0000798fc6fe0df4  vmovaps [rsp+0x30], xmm3
0000798fc6fe0dfa  vmovaps [rsp+0x40], xmm4
0000798fc6fe0e00  vmovaps [rsp+0x50], xmm5
0000798fc6fe0e06  vmovaps [rsp+0x60], xmm6
0000798fc6fe0e0c  vmovaps [rsp+0x70], xmm7
0000798fc6fe0e12  vmovaps [rsp+0x80], xmm8
0000798fc6fe0e1b  vmovaps [rsp+0x90], xmm9
0000798fc6fe0e24  vmovaps [rsp+0xA0], xmm10
0000798fc6fe0e2d  vmovaps [rsp+0xB0], xmm11
0000798fc6fe0e36  vmovaps [rsp+0xC0], xmm13
0000798fc6fe0e3f  vmovaps [rsp+0xD0], xmm14
0000798fc6fe0e48  vmovaps [rsp+0xE0], xmm15
0000798fc6fe0e51  sub rsp, 0x30
0000798fc6fe0e55  movaps [rsp], xmm12
0000798fc6fe0e5a  movaps [rsp+0x10], xmm14
0000798fc6fe0e60  movaps [rsp+0x20], xmm1
0000798fc6fe0e65  lea rdi, [rsp]
0000798fc6fe0e69  mov esi, 0x00
0000798fc6fe0e6e  mov rax, 0x63E558B23530
0000798fc6fe0e78  call rax
0000798fc6fe0e7a  movaps xmm12, [rsp]
0000798fc6fe0e7f  add rsp, 0x30
0000798fc6fe0e83  vmovaps xmm0, [rsp]
0000798fc6fe0e88  vmovaps xmm1, [rsp+0x10]
0000798fc6fe0e8e  vmovaps xmm2, [rsp+0x20]
0000798fc6fe0e94  vmovaps xmm3, [rsp+0x30]
0000798fc6fe0e9a  vmovaps xmm4, [rsp+0x40]
0000798fc6fe0ea0  vmovaps xmm5, [rsp+0x50]
0000798fc6fe0ea6  vmovaps xmm6, [rsp+0x60]
0000798fc6fe0eac  vmovaps xmm7, [rsp+0x70]
0000798fc6fe0eb2  vmovaps xmm8, [rsp+0x80]
0000798fc6fe0ebb  vmovaps xmm9, [rsp+0x90]
0000798fc6fe0ec4  vmovaps xmm10, [rsp+0xA0]
0000798fc6fe0ecd  vmovaps xmm11, [rsp+0xB0]
0000798fc6fe0ed6  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe0edf  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe0ee8  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe0ef1  add rsp, 0xF0
0000798fc6fe0ef8  pop r11
0000798fc6fe0efa  pop r10
0000798fc6fe0efc  pop r9
0000798fc6fe0efe  pop r8
0000798fc6fe0f00  pop rsi
0000798fc6fe0f01  pop rdi
0000798fc6fe0f02  pop rdx
0000798fc6fe0f03  pop rcx
0000798fc6fe0f04  pop rax
0000798fc6fe0f05  add rsp, 0x08
0000798fc6fe0f09  jmp 0x0000798FC6FDC6FC
0000798fc6fe0f0e  sub rsp, 0x08
0000798fc6fe0f12  push rax
0000798fc6fe0f13  push rcx
0000798fc6fe0f14  push rdx
0000798fc6fe0f15  push rdi
0000798fc6fe0f16  push rsi
0000798fc6fe0f17  push r8
0000798fc6fe0f19  push r9
0000798fc6fe0f1b  push r10
0000798fc6fe0f1d  push r11
0000798fc6fe0f1f  sub rsp, 0xF0
0000798fc6fe0f26  vmovaps [rsp], xmm0
0000798fc6fe0f2b  vmovaps [rsp+0x10], xmm1
0000798fc6fe0f31  vmovaps [rsp+0x20], xmm2
0000798fc6fe0f37  vmovaps [rsp+0x30], xmm3
0000798fc6fe0f3d  vmovaps [rsp+0x40], xmm4
0000798fc6fe0f43  vmovaps [rsp+0x50], xmm5
0000798fc6fe0f49  vmovaps [rsp+0x60], xmm6
0000798fc6fe0f4f  vmovaps [rsp+0x70], xmm7
0000798fc6fe0f55  vmovaps [rsp+0x80], xmm8
0000798fc6fe0f5e  vmovaps [rsp+0x90], xmm9
0000798fc6fe0f67  vmovaps [rsp+0xA0], xmm10
0000798fc6fe0f70  vmovaps [rsp+0xB0], xmm11
0000798fc6fe0f79  vmovaps [rsp+0xC0], xmm12
0000798fc6fe0f82  vmovaps [rsp+0xD0], xmm13
0000798fc6fe0f8b  vmovaps [rsp+0xE0], xmm15
0000798fc6fe0f94  sub rsp, 0x30
0000798fc6fe0f98  movaps [rsp], xmm14
0000798fc6fe0f9d  movaps [rsp+0x10], xmm9
0000798fc6fe0fa3  movaps [rsp+0x20], xmm1
0000798fc6fe0fa8  lea rdi, [rsp]
0000798fc6fe0fac  mov esi, 0x00
0000798fc6fe0fb1  mov rax, 0x63E558B23530
0000798fc6fe0fbb  call rax
0000798fc6fe0fbd  movaps xmm14, [rsp]
0000798fc6fe0fc2  add rsp, 0x30
0000798fc6fe0fc6  vmovaps xmm0, [rsp]
0000798fc6fe0fcb  vmovaps xmm1, [rsp+0x10]
0000798fc6fe0fd1  vmovaps xmm2, [rsp+0x20]
0000798fc6fe0fd7  vmovaps xmm3, [rsp+0x30]
0000798fc6fe0fdd  vmovaps xmm4, [rsp+0x40]
0000798fc6fe0fe3  vmovaps xmm5, [rsp+0x50]
0000798fc6fe0fe9  vmovaps xmm6, [rsp+0x60]
0000798fc6fe0fef  vmovaps xmm7, [rsp+0x70]
0000798fc6fe0ff5  vmovaps xmm8, [rsp+0x80]
0000798fc6fe0ffe  vmovaps xmm9, [rsp+0x90]
0000798fc6fe1007  vmovaps xmm10, [rsp+0xA0]
0000798fc6fe1010  vmovaps xmm11, [rsp+0xB0]
0000798fc6fe1019  vmovaps xmm12, [rsp+0xC0]
0000798fc6fe1022  vmovaps xmm13, [rsp+0xD0]
0000798fc6fe102b  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe1034  add rsp, 0xF0
0000798fc6fe103b  pop r11
0000798fc6fe103d  pop r10
0000798fc6fe103f  pop r9
0000798fc6fe1041  pop r8
0000798fc6fe1043  pop rsi
0000798fc6fe1044  pop rdi
0000798fc6fe1045  pop rdx
0000798fc6fe1046  pop rcx
0000798fc6fe1047  pop rax
0000798fc6fe1048  add rsp, 0x08
0000798fc6fe104c  jmp 0x0000798FC6FDC72B
0000798fc6fe1051  sub rsp, 0x08
0000798fc6fe1055  push rax
0000798fc6fe1056  push rcx
0000798fc6fe1057  push rdx
0000798fc6fe1058  push rdi
0000798fc6fe1059  push rsi
0000798fc6fe105a  push r8
0000798fc6fe105c  push r9
0000798fc6fe105e  push r10
0000798fc6fe1060  push r11
0000798fc6fe1062  sub rsp, 0xF0
0000798fc6fe1069  vmovaps [rsp], xmm0
0000798fc6fe106e  vmovaps [rsp+0x10], xmm2
0000798fc6fe1074  vmovaps [rsp+0x20], xmm3
0000798fc6fe107a  vmovaps [rsp+0x30], xmm4
0000798fc6fe1080  vmovaps [rsp+0x40], xmm5
0000798fc6fe1086  vmovaps [rsp+0x50], xmm6
0000798fc6fe108c  vmovaps [rsp+0x60], xmm7
0000798fc6fe1092  vmovaps [rsp+0x70], xmm8
0000798fc6fe1098  vmovaps [rsp+0x80], xmm9
0000798fc6fe10a1  vmovaps [rsp+0x90], xmm10
0000798fc6fe10aa  vmovaps [rsp+0xA0], xmm11
0000798fc6fe10b3  vmovaps [rsp+0xB0], xmm12
0000798fc6fe10bc  vmovaps [rsp+0xC0], xmm13
0000798fc6fe10c5  vmovaps [rsp+0xD0], xmm14
0000798fc6fe10ce  vmovaps [rsp+0xE0], xmm15
0000798fc6fe10d7  sub rsp, 0x30
0000798fc6fe10db  movaps [rsp], xmm1
0000798fc6fe10df  movaps [rsp+0x10], xmm13
0000798fc6fe10e5  movaps [rsp+0x20], xmm8
0000798fc6fe10eb  lea rdi, [rsp]
0000798fc6fe10ef  mov esi, 0x00
0000798fc6fe10f4  mov rax, 0x63E558B23530
0000798fc6fe10fe  call rax
0000798fc6fe1100  movaps xmm1, [rsp]
0000798fc6fe1104  add rsp, 0x30
0000798fc6fe1108  vmovaps xmm0, [rsp]
0000798fc6fe110d  vmovaps xmm2, [rsp+0x10]
0000798fc6fe1113  vmovaps xmm3, [rsp+0x20]
0000798fc6fe1119  vmovaps xmm4, [rsp+0x30]
0000798fc6fe111f  vmovaps xmm5, [rsp+0x40]
0000798fc6fe1125  vmovaps xmm6, [rsp+0x50]
0000798fc6fe112b  vmovaps xmm7, [rsp+0x60]
0000798fc6fe1131  vmovaps xmm8, [rsp+0x70]
0000798fc6fe1137  vmovaps xmm9, [rsp+0x80]
0000798fc6fe1140  vmovaps xmm10, [rsp+0x90]
0000798fc6fe1149  vmovaps xmm11, [rsp+0xA0]
0000798fc6fe1152  vmovaps xmm12, [rsp+0xB0]
0000798fc6fe115b  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe1164  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe116d  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe1176  add rsp, 0xF0
0000798fc6fe117d  pop r11
0000798fc6fe117f  pop r10
0000798fc6fe1181  pop r9
0000798fc6fe1183  pop r8
0000798fc6fe1185  pop rsi
0000798fc6fe1186  pop rdi
0000798fc6fe1187  pop rdx
0000798fc6fe1188  pop rcx
0000798fc6fe1189  pop rax
0000798fc6fe118a  add rsp, 0x08
0000798fc6fe118e  jmp 0x0000798FC6FDC74D
0000798fc6fe1193  call 0x0000798FC6E0C260
0000798fc6fe1198  jmp 0x0000798FC6FDC75B
0000798fc6fe119d  call 0x0000798FC6EBD750
0000798fc6fe11a2  jmp 0x0000798FC6FDC765
0000798fc6fe11a7  sub rsp, 0x08
0000798fc6fe11ab  push rax
0000798fc6fe11ac  push rcx
0000798fc6fe11ad  push rdx
0000798fc6fe11ae  push rdi
0000798fc6fe11af  push rsi
0000798fc6fe11b0  push r8
0000798fc6fe11b2  push r9
0000798fc6fe11b4  push r10
0000798fc6fe11b6  push r11
0000798fc6fe11b8  sub rsp, 0xF0
0000798fc6fe11bf  vmovaps [rsp], xmm0
0000798fc6fe11c4  vmovaps [rsp+0x10], xmm1
0000798fc6fe11ca  vmovaps [rsp+0x20], xmm2
0000798fc6fe11d0  vmovaps [rsp+0x30], xmm3
0000798fc6fe11d6  vmovaps [rsp+0x40], xmm4
0000798fc6fe11dc  vmovaps [rsp+0x50], xmm5
0000798fc6fe11e2  vmovaps [rsp+0x60], xmm6
0000798fc6fe11e8  vmovaps [rsp+0x70], xmm7
0000798fc6fe11ee  vmovaps [rsp+0x80], xmm9
0000798fc6fe11f7  vmovaps [rsp+0x90], xmm10
0000798fc6fe1200  vmovaps [rsp+0xA0], xmm11
0000798fc6fe1209  vmovaps [rsp+0xB0], xmm12
0000798fc6fe1212  vmovaps [rsp+0xC0], xmm13
0000798fc6fe121b  vmovaps [rsp+0xD0], xmm14
0000798fc6fe1224  vmovaps [rsp+0xE0], xmm15
0000798fc6fe122d  sub rsp, 0x30
0000798fc6fe1231  movaps [rsp], xmm8
0000798fc6fe1236  movaps [rsp+0x10], xmm15
0000798fc6fe123c  movaps [rsp+0x20], xmm7
0000798fc6fe1241  lea rdi, [rsp]
0000798fc6fe1245  mov esi, 0x00
0000798fc6fe124a  mov rax, 0x63E558B23530
0000798fc6fe1254  call rax
0000798fc6fe1256  movaps xmm8, [rsp]
0000798fc6fe125b  add rsp, 0x30
0000798fc6fe125f  vmovaps xmm0, [rsp]
0000798fc6fe1264  vmovaps xmm1, [rsp+0x10]
0000798fc6fe126a  vmovaps xmm2, [rsp+0x20]
0000798fc6fe1270  vmovaps xmm3, [rsp+0x30]
0000798fc6fe1276  vmovaps xmm4, [rsp+0x40]
0000798fc6fe127c  vmovaps xmm5, [rsp+0x50]
0000798fc6fe1282  vmovaps xmm6, [rsp+0x60]
0000798fc6fe1288  vmovaps xmm7, [rsp+0x70]
0000798fc6fe128e  vmovaps xmm9, [rsp+0x80]
0000798fc6fe1297  vmovaps xmm10, [rsp+0x90]
0000798fc6fe12a0  vmovaps xmm11, [rsp+0xA0]
0000798fc6fe12a9  vmovaps xmm12, [rsp+0xB0]
0000798fc6fe12b2  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe12bb  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe12c4  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe12cd  add rsp, 0xF0
0000798fc6fe12d4  pop r11
0000798fc6fe12d6  pop r10
0000798fc6fe12d8  pop r9
0000798fc6fe12da  pop r8
0000798fc6fe12dc  pop rsi
0000798fc6fe12dd  pop rdi
0000798fc6fe12de  pop rdx
0000798fc6fe12df  pop rcx
0000798fc6fe12e0  pop rax
0000798fc6fe12e1  add rsp, 0x08
0000798fc6fe12e5  jmp 0x0000798FC6FDC787
0000798fc6fe12ea  sub rsp, 0x08
0000798fc6fe12ee  push rax
0000798fc6fe12ef  push rcx
0000798fc6fe12f0  push rdx
0000798fc6fe12f1  push rdi
0000798fc6fe12f2  push rsi
0000798fc6fe12f3  push r8
0000798fc6fe12f5  push r9
0000798fc6fe12f7  push r10
0000798fc6fe12f9  push r11
0000798fc6fe12fb  sub rsp, 0xF0
0000798fc6fe1302  vmovaps [rsp], xmm0
0000798fc6fe1307  vmovaps [rsp+0x10], xmm1
0000798fc6fe130d  vmovaps [rsp+0x20], xmm2
0000798fc6fe1313  vmovaps [rsp+0x30], xmm3
0000798fc6fe1319  vmovaps [rsp+0x40], xmm4
0000798fc6fe131f  vmovaps [rsp+0x50], xmm5
0000798fc6fe1325  vmovaps [rsp+0x60], xmm6
0000798fc6fe132b  vmovaps [rsp+0x70], xmm8
0000798fc6fe1331  vmovaps [rsp+0x80], xmm9
0000798fc6fe133a  vmovaps [rsp+0x90], xmm10
0000798fc6fe1343  vmovaps [rsp+0xA0], xmm11
0000798fc6fe134c  vmovaps [rsp+0xB0], xmm12
0000798fc6fe1355  vmovaps [rsp+0xC0], xmm13
0000798fc6fe135e  vmovaps [rsp+0xD0], xmm14
0000798fc6fe1367  vmovaps [rsp+0xE0], xmm15
0000798fc6fe1370  sub rsp, 0x30
0000798fc6fe1374  movaps [rsp], xmm7
0000798fc6fe1378  movaps [rsp+0x10], xmm9
0000798fc6fe137e  movaps [rsp+0x20], xmm15
0000798fc6fe1384  lea rdi, [rsp]
0000798fc6fe1388  mov esi, 0x00
0000798fc6fe138d  mov rax, 0x63E558B23530
0000798fc6fe1397  call rax
0000798fc6fe1399  movaps xmm7, [rsp]
0000798fc6fe139d  add rsp, 0x30
0000798fc6fe13a1  vmovaps xmm0, [rsp]
0000798fc6fe13a6  vmovaps xmm1, [rsp+0x10]
0000798fc6fe13ac  vmovaps xmm2, [rsp+0x20]
0000798fc6fe13b2  vmovaps xmm3, [rsp+0x30]
0000798fc6fe13b8  vmovaps xmm4, [rsp+0x40]
0000798fc6fe13be  vmovaps xmm5, [rsp+0x50]
0000798fc6fe13c4  vmovaps xmm6, [rsp+0x60]
0000798fc6fe13ca  vmovaps xmm8, [rsp+0x70]
0000798fc6fe13d0  vmovaps xmm9, [rsp+0x80]
0000798fc6fe13d9  vmovaps xmm10, [rsp+0x90]
0000798fc6fe13e2  vmovaps xmm11, [rsp+0xA0]
0000798fc6fe13eb  vmovaps xmm12, [rsp+0xB0]
0000798fc6fe13f4  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe13fd  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe1406  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe140f  add rsp, 0xF0
0000798fc6fe1416  pop r11
0000798fc6fe1418  pop r10
0000798fc6fe141a  pop r9
0000798fc6fe141c  pop r8
0000798fc6fe141e  pop rsi
0000798fc6fe141f  pop rdi
0000798fc6fe1420  pop rdx
0000798fc6fe1421  pop rcx
0000798fc6fe1422  pop rax
0000798fc6fe1423  add rsp, 0x08
0000798fc6fe1427  jmp 0x0000798FC6FDC7B4
0000798fc6fe142c  sub rsp, 0x08
0000798fc6fe1430  push rax
0000798fc6fe1431  push rcx
0000798fc6fe1432  push rdx
0000798fc6fe1433  push rdi
0000798fc6fe1434  push rsi
0000798fc6fe1435  push r8
0000798fc6fe1437  push r9
0000798fc6fe1439  push r10
0000798fc6fe143b  push r11
0000798fc6fe143d  sub rsp, 0xF0
0000798fc6fe1444  vmovaps [rsp], xmm0
0000798fc6fe1449  vmovaps [rsp+0x10], xmm1
0000798fc6fe144f  vmovaps [rsp+0x20], xmm2
0000798fc6fe1455  vmovaps [rsp+0x30], xmm3
0000798fc6fe145b  vmovaps [rsp+0x40], xmm4
0000798fc6fe1461  vmovaps [rsp+0x50], xmm5
0000798fc6fe1467  vmovaps [rsp+0x60], xmm6
0000798fc6fe146d  vmovaps [rsp+0x70], xmm7
0000798fc6fe1473  vmovaps [rsp+0x80], xmm8
0000798fc6fe147c  vmovaps [rsp+0x90], xmm10
0000798fc6fe1485  vmovaps [rsp+0xA0], xmm11
0000798fc6fe148e  vmovaps [rsp+0xB0], xmm12
0000798fc6fe1497  vmovaps [rsp+0xC0], xmm13
0000798fc6fe14a0  vmovaps [rsp+0xD0], xmm14
0000798fc6fe14a9  vmovaps [rsp+0xE0], xmm15
0000798fc6fe14b2  sub rsp, 0x30
0000798fc6fe14b6  movaps [rsp], xmm9
0000798fc6fe14bb  movaps [rsp+0x10], xmm13
0000798fc6fe14c1  movaps [rsp+0x20], xmm15
0000798fc6fe14c7  lea rdi, [rsp]
0000798fc6fe14cb  mov esi, 0x00
0000798fc6fe14d0  mov rax, 0x63E558B23530
0000798fc6fe14da  call rax
0000798fc6fe14dc  movaps xmm9, [rsp]
0000798fc6fe14e1  add rsp, 0x30
0000798fc6fe14e5  vmovaps xmm0, [rsp]
0000798fc6fe14ea  vmovaps xmm1, [rsp+0x10]
0000798fc6fe14f0  vmovaps xmm2, [rsp+0x20]
0000798fc6fe14f6  vmovaps xmm3, [rsp+0x30]
0000798fc6fe14fc  vmovaps xmm4, [rsp+0x40]
0000798fc6fe1502  vmovaps xmm5, [rsp+0x50]
0000798fc6fe1508  vmovaps xmm6, [rsp+0x60]
0000798fc6fe150e  vmovaps xmm7, [rsp+0x70]
0000798fc6fe1514  vmovaps xmm8, [rsp+0x80]
0000798fc6fe151d  vmovaps xmm10, [rsp+0x90]
0000798fc6fe1526  vmovaps xmm11, [rsp+0xA0]
0000798fc6fe152f  vmovaps xmm12, [rsp+0xB0]
0000798fc6fe1538  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe1541  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe154a  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe1553  add rsp, 0xF0
0000798fc6fe155a  pop r11
0000798fc6fe155c  pop r10
0000798fc6fe155e  pop r9
0000798fc6fe1560  pop r8
0000798fc6fe1562  pop rsi
0000798fc6fe1563  pop rdi
0000798fc6fe1564  pop rdx
0000798fc6fe1565  pop rcx
0000798fc6fe1566  pop rax
0000798fc6fe1567  add rsp, 0x08
0000798fc6fe156b  jmp 0x0000798FC6FDC7E2
0000798fc6fe1570  sub rsp, 0x08
0000798fc6fe1574  push rax
0000798fc6fe1575  push rcx
0000798fc6fe1576  push rdx
0000798fc6fe1577  push rdi
0000798fc6fe1578  push rsi
0000798fc6fe1579  push r8
0000798fc6fe157b  push r9
0000798fc6fe157d  push r10
0000798fc6fe157f  push r11
0000798fc6fe1581  sub rsp, 0xF0
0000798fc6fe1588  vmovaps [rsp], xmm0
0000798fc6fe158d  vmovaps [rsp+0x10], xmm1
0000798fc6fe1593  vmovaps [rsp+0x20], xmm2
0000798fc6fe1599  vmovaps [rsp+0x30], xmm3
0000798fc6fe159f  vmovaps [rsp+0x40], xmm4
0000798fc6fe15a5  vmovaps [rsp+0x50], xmm5
0000798fc6fe15ab  vmovaps [rsp+0x60], xmm6
0000798fc6fe15b1  vmovaps [rsp+0x70], xmm7
0000798fc6fe15b7  vmovaps [rsp+0x80], xmm8
0000798fc6fe15c0  vmovaps [rsp+0x90], xmm9
0000798fc6fe15c9  vmovaps [rsp+0xA0], xmm10
0000798fc6fe15d2  vmovaps [rsp+0xB0], xmm11
0000798fc6fe15db  vmovaps [rsp+0xC0], xmm12
0000798fc6fe15e4  vmovaps [rsp+0xD0], xmm13
0000798fc6fe15ed  vmovaps [rsp+0xE0], xmm14
0000798fc6fe15f6  sub rsp, 0x30
0000798fc6fe15fa  movaps [rsp], xmm15
0000798fc6fe15ff  movaps [rsp+0x10], xmm11
0000798fc6fe1605  movaps [rsp+0x20], xmm12
0000798fc6fe160b  lea rdi, [rsp]
0000798fc6fe160f  mov esi, 0x00
0000798fc6fe1614  mov rax, 0x63E558B23530
0000798fc6fe161e  call rax
0000798fc6fe1620  movaps xmm15, [rsp]
0000798fc6fe1625  add rsp, 0x30
0000798fc6fe1629  vmovaps xmm0, [rsp]
0000798fc6fe162e  vmovaps xmm1, [rsp+0x10]
0000798fc6fe1634  vmovaps xmm2, [rsp+0x20]
0000798fc6fe163a  vmovaps xmm3, [rsp+0x30]
0000798fc6fe1640  vmovaps xmm4, [rsp+0x40]
0000798fc6fe1646  vmovaps xmm5, [rsp+0x50]
0000798fc6fe164c  vmovaps xmm6, [rsp+0x60]
0000798fc6fe1652  vmovaps xmm7, [rsp+0x70]
0000798fc6fe1658  vmovaps xmm8, [rsp+0x80]
0000798fc6fe1661  vmovaps xmm9, [rsp+0x90]
0000798fc6fe166a  vmovaps xmm10, [rsp+0xA0]
0000798fc6fe1673  vmovaps xmm11, [rsp+0xB0]
0000798fc6fe167c  vmovaps xmm12, [rsp+0xC0]
0000798fc6fe1685  vmovaps xmm13, [rsp+0xD0]
0000798fc6fe168e  vmovaps xmm14, [rsp+0xE0]
0000798fc6fe1697  add rsp, 0xF0
0000798fc6fe169e  pop r11
0000798fc6fe16a0  pop r10
0000798fc6fe16a2  pop r9
0000798fc6fe16a4  pop r8
0000798fc6fe16a6  pop rsi
0000798fc6fe16a7  pop rdi
0000798fc6fe16a8  pop rdx
0000798fc6fe16a9  pop rcx
0000798fc6fe16aa  pop rax
0000798fc6fe16ab  add rsp, 0x08
0000798fc6fe16af  jmp 0x0000798FC6FDC7FD
0000798fc6fe16b4  sub rsp, 0x08
0000798fc6fe16b8  push rax
0000798fc6fe16b9  push rcx
0000798fc6fe16ba  push rdx
0000798fc6fe16bb  push rdi
0000798fc6fe16bc  push rsi
0000798fc6fe16bd  push r8
0000798fc6fe16bf  push r9
0000798fc6fe16c1  push r10
0000798fc6fe16c3  push r11
0000798fc6fe16c5  sub rsp, 0xF0
0000798fc6fe16cc  vmovaps [rsp], xmm0
0000798fc6fe16d1  vmovaps [rsp+0x10], xmm1
0000798fc6fe16d7  vmovaps [rsp+0x20], xmm2
0000798fc6fe16dd  vmovaps [rsp+0x30], xmm3
0000798fc6fe16e3  vmovaps [rsp+0x40], xmm4
0000798fc6fe16e9  vmovaps [rsp+0x50], xmm5
0000798fc6fe16ef  vmovaps [rsp+0x60], xmm6
0000798fc6fe16f5  vmovaps [rsp+0x70], xmm7
0000798fc6fe16fb  vmovaps [rsp+0x80], xmm8
0000798fc6fe1704  vmovaps [rsp+0x90], xmm9
0000798fc6fe170d  vmovaps [rsp+0xA0], xmm10
0000798fc6fe1716  vmovaps [rsp+0xB0], xmm11
0000798fc6fe171f  vmovaps [rsp+0xC0], xmm12
0000798fc6fe1728  vmovaps [rsp+0xD0], xmm14
0000798fc6fe1731  vmovaps [rsp+0xE0], xmm15
0000798fc6fe173a  sub rsp, 0x30
0000798fc6fe173e  movaps [rsp], xmm13
0000798fc6fe1743  movaps [rsp+0x10], xmm10
0000798fc6fe1749  movaps [rsp+0x20], xmm14
0000798fc6fe174f  lea rdi, [rsp]
0000798fc6fe1753  mov esi, 0x00
0000798fc6fe1758  mov rax, 0x63E558B23530
0000798fc6fe1762  call rax
0000798fc6fe1764  movaps xmm13, [rsp]
0000798fc6fe1769  add rsp, 0x30
0000798fc6fe176d  vmovaps xmm0, [rsp]
0000798fc6fe1772  vmovaps xmm1, [rsp+0x10]
0000798fc6fe1778  vmovaps xmm2, [rsp+0x20]
0000798fc6fe177e  vmovaps xmm3, [rsp+0x30]
0000798fc6fe1784  vmovaps xmm4, [rsp+0x40]
0000798fc6fe178a  vmovaps xmm5, [rsp+0x50]
0000798fc6fe1790  vmovaps xmm6, [rsp+0x60]
0000798fc6fe1796  vmovaps xmm7, [rsp+0x70]
0000798fc6fe179c  vmovaps xmm8, [rsp+0x80]
0000798fc6fe17a5  vmovaps xmm9, [rsp+0x90]
0000798fc6fe17ae  vmovaps xmm10, [rsp+0xA0]
0000798fc6fe17b7  vmovaps xmm11, [rsp+0xB0]
0000798fc6fe17c0  vmovaps xmm12, [rsp+0xC0]
0000798fc6fe17c9  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe17d2  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe17db  add rsp, 0xF0
0000798fc6fe17e2  pop r11
0000798fc6fe17e4  pop r10
0000798fc6fe17e6  pop r9
0000798fc6fe17e8  pop r8
0000798fc6fe17ea  pop rsi
0000798fc6fe17eb  pop rdi
0000798fc6fe17ec  pop rdx
0000798fc6fe17ed  pop rcx
0000798fc6fe17ee  pop rax
0000798fc6fe17ef  add rsp, 0x08
0000798fc6fe17f3  jmp 0x0000798FC6FDC820
0000798fc6fe17f8  sub rsp, 0x08
0000798fc6fe17fc  push rax
0000798fc6fe17fd  push rcx
0000798fc6fe17fe  push rdx
0000798fc6fe17ff  push rdi
0000798fc6fe1800  push rsi
0000798fc6fe1801  push r8
0000798fc6fe1803  push r9
0000798fc6fe1805  push r10
0000798fc6fe1807  push r11
0000798fc6fe1809  sub rsp, 0xF0
0000798fc6fe1810  vmovaps [rsp], xmm0
0000798fc6fe1815  vmovaps [rsp+0x10], xmm1
0000798fc6fe181b  vmovaps [rsp+0x20], xmm2
0000798fc6fe1821  vmovaps [rsp+0x30], xmm3
0000798fc6fe1827  vmovaps [rsp+0x40], xmm4
0000798fc6fe182d  vmovaps [rsp+0x50], xmm5
0000798fc6fe1833  vmovaps [rsp+0x60], xmm6
0000798fc6fe1839  vmovaps [rsp+0x70], xmm7
0000798fc6fe183f  vmovaps [rsp+0x80], xmm8
0000798fc6fe1848  vmovaps [rsp+0x90], xmm9
0000798fc6fe1851  vmovaps [rsp+0xA0], xmm10
0000798fc6fe185a  vmovaps [rsp+0xB0], xmm11
0000798fc6fe1863  vmovaps [rsp+0xC0], xmm12
0000798fc6fe186c  vmovaps [rsp+0xD0], xmm13
0000798fc6fe1875  vmovaps [rsp+0xE0], xmm15
0000798fc6fe187e  sub rsp, 0x30
0000798fc6fe1882  movaps [rsp], xmm14
0000798fc6fe1887  movaps [rsp+0x10], xmm1
0000798fc6fe188c  movaps [rsp+0x20], xmm7
0000798fc6fe1891  lea rdi, [rsp]
0000798fc6fe1895  mov esi, 0x00
0000798fc6fe189a  mov rax, 0x63E558B23530
0000798fc6fe18a4  call rax
0000798fc6fe18a6  movaps xmm14, [rsp]
0000798fc6fe18ab  add rsp, 0x30
0000798fc6fe18af  vmovaps xmm0, [rsp]
0000798fc6fe18b4  vmovaps xmm1, [rsp+0x10]
0000798fc6fe18ba  vmovaps xmm2, [rsp+0x20]
0000798fc6fe18c0  vmovaps xmm3, [rsp+0x30]
0000798fc6fe18c6  vmovaps xmm4, [rsp+0x40]
0000798fc6fe18cc  vmovaps xmm5, [rsp+0x50]
0000798fc6fe18d2  vmovaps xmm6, [rsp+0x60]
0000798fc6fe18d8  vmovaps xmm7, [rsp+0x70]
0000798fc6fe18de  vmovaps xmm8, [rsp+0x80]
0000798fc6fe18e7  vmovaps xmm9, [rsp+0x90]
0000798fc6fe18f0  vmovaps xmm10, [rsp+0xA0]
0000798fc6fe18f9  vmovaps xmm11, [rsp+0xB0]
0000798fc6fe1902  vmovaps xmm12, [rsp+0xC0]
0000798fc6fe190b  vmovaps xmm13, [rsp+0xD0]
0000798fc6fe1914  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe191d  add rsp, 0xF0
0000798fc6fe1924  pop r11
0000798fc6fe1926  pop r10
0000798fc6fe1928  pop r9
0000798fc6fe192a  pop r8
0000798fc6fe192c  pop rsi
0000798fc6fe192d  pop rdi
0000798fc6fe192e  pop rdx
0000798fc6fe192f  pop rcx
0000798fc6fe1930  pop rax
0000798fc6fe1931  add rsp, 0x08
0000798fc6fe1935  jmp 0x0000798FC6FDC843
0000798fc6fe193a  sub rsp, 0x08
0000798fc6fe193e  push rax
0000798fc6fe193f  push rcx
0000798fc6fe1940  push rdx
0000798fc6fe1941  push rdi
0000798fc6fe1942  push rsi
0000798fc6fe1943  push r8
0000798fc6fe1945  push r9
0000798fc6fe1947  push r10
0000798fc6fe1949  push r11
0000798fc6fe194b  sub rsp, 0xF0
0000798fc6fe1952  vmovaps [rsp], xmm0
0000798fc6fe1957  vmovaps [rsp+0x10], xmm2
0000798fc6fe195d  vmovaps [rsp+0x20], xmm3
0000798fc6fe1963  vmovaps [rsp+0x30], xmm4
0000798fc6fe1969  vmovaps [rsp+0x40], xmm5
0000798fc6fe196f  vmovaps [rsp+0x50], xmm6
0000798fc6fe1975  vmovaps [rsp+0x60], xmm7
0000798fc6fe197b  vmovaps [rsp+0x70], xmm8
0000798fc6fe1981  vmovaps [rsp+0x80], xmm9
0000798fc6fe198a  vmovaps [rsp+0x90], xmm10
0000798fc6fe1993  vmovaps [rsp+0xA0], xmm11
0000798fc6fe199c  vmovaps [rsp+0xB0], xmm12
0000798fc6fe19a5  vmovaps [rsp+0xC0], xmm13
0000798fc6fe19ae  vmovaps [rsp+0xD0], xmm14
0000798fc6fe19b7  vmovaps [rsp+0xE0], xmm15
0000798fc6fe19c0  sub rsp, 0x30
0000798fc6fe19c4  movaps [rsp], xmm1
0000798fc6fe19c8  movaps [rsp+0x10], xmm8
0000798fc6fe19ce  movaps [rsp+0x20], xmm9
0000798fc6fe19d4  lea rdi, [rsp]
0000798fc6fe19d8  mov esi, 0x00
0000798fc6fe19dd  mov rax, 0x63E558B23530
0000798fc6fe19e7  call rax
0000798fc6fe19e9  movaps xmm1, [rsp]
0000798fc6fe19ed  add rsp, 0x30
0000798fc6fe19f1  vmovaps xmm0, [rsp]
0000798fc6fe19f6  vmovaps xmm2, [rsp+0x10]
0000798fc6fe19fc  vmovaps xmm3, [rsp+0x20]
0000798fc6fe1a02  vmovaps xmm4, [rsp+0x30]
0000798fc6fe1a08  vmovaps xmm5, [rsp+0x40]
0000798fc6fe1a0e  vmovaps xmm6, [rsp+0x50]
0000798fc6fe1a14  vmovaps xmm7, [rsp+0x60]
0000798fc6fe1a1a  vmovaps xmm8, [rsp+0x70]
0000798fc6fe1a20  vmovaps xmm9, [rsp+0x80]
0000798fc6fe1a29  vmovaps xmm10, [rsp+0x90]
0000798fc6fe1a32  vmovaps xmm11, [rsp+0xA0]
0000798fc6fe1a3b  vmovaps xmm12, [rsp+0xB0]
0000798fc6fe1a44  vmovaps xmm13, [rsp+0xC0]
0000798fc6fe1a4d  vmovaps xmm14, [rsp+0xD0]
0000798fc6fe1a56  vmovaps xmm15, [rsp+0xE0]
0000798fc6fe1a5f  add rsp, 0xF0
0000798fc6fe1a66  pop r11
0000798fc6fe1a68  pop r10
0000798fc6fe1a6a  pop r9
0000798fc6fe1a6c  pop r8
0000798fc6fe1a6e  pop rsi
0000798fc6fe1a6f  pop rdi
0000798fc6fe1a70  pop rdx
0000798fc6fe1a71  pop rcx
0000798fc6fe1a72  pop rax
0000798fc6fe1a73  add rsp, 0x08
0000798fc6fe1a77  jmp 0x0000798FC6FDC865
0000798fc6fe1a7c  call 0x0000798FC6EE5940
0000798fc6fe1a81  jmp 0x0000798FC6FDC873
0000798fc6fe1a86  call 0x0000798FC6E0C380
0000798fc6fe1a8b  jmp 0x0000798FC6FDC87D
0000798fc6fe1a90  call 0x0000798FC6E0D600
0000798fc6fe1a95  jmp 0x0000798FC6FDC887
0000798fc6fe1a9a  call 0x0000798FC6DFF540
0000798fc6fe1a9f  jmp 0x0000798FC6FDC891
0000798fc6fe1aa4  int3
0000798fc6fe1aa5  nop [rax+rax*1], ax
0000798fc6fe1aae  nop
0000798fc6fe1ab0  mov rax, [r15+0xF8]
0000798fc6fe1ab7  lea r14, [rax+0x140]
0000798fc6fe1abe  mov r12, [r13+r14*1]
0000798fc6fe1ac3  mov [r15+0xE8], r12
0000798fc6fe1aca  lea r14, [rax+0x130]
0000798fc6fe1ad1  mov r12, [r13+r14*1]
0000798fc6fe1ad6  lea r14, [rax+0x138]
0000798fc6fe1add  mov r11, [r13+r14*1]
0000798fc6fe1ae2  movq xmm1, r12
0000798fc6fe1ae7  movq xmm15, r11
0000798fc6fe1aec  movq xmm1, xmm1
0000798fc6fe1af0  movq xmm1, xmm1
0000798fc6fe1af4  movaps [r15+0x1A0], xmm1
0000798fc6fe1afc  movq xmm15, xmm15
0000798fc6fe1b01  movq xmm15, xmm15
0000798fc6fe1b06  movaps [r15+0x190], xmm15
0000798fc6fe1b0e  lea r14, [rax+0x120]
0000798fc6fe1b15  mov r12, [r13+r14*1]
0000798fc6fe1b1a  lea r14, [rax+0x128]
0000798fc6fe1b21  mov r11, [r13+r14*1]
0000798fc6fe1b26  movq xmm1, r12
0000798fc6fe1b2b  movq xmm15, r11
0000798fc6fe1b30  movq xmm1, xmm1
0000798fc6fe1b34  movq xmm1, xmm1
0000798fc6fe1b38  movaps [r15+0x1C0], xmm1
0000798fc6fe1b40  movq xmm15, xmm15
0000798fc6fe1b45  movq xmm15, xmm15
0000798fc6fe1b4a  movaps [r15+0x1B0], xmm15
0000798fc6fe1b52  lea r14, [rax+0x110]
0000798fc6fe1b59  mov r12, [r13+r14*1]
0000798fc6fe1b5e  lea r14, [rax+0x118]
0000798fc6fe1b65  mov r11, [r13+r14*1]
0000798fc6fe1b6a  movq xmm1, r12
0000798fc6fe1b6f  movq xmm15, r11
0000798fc6fe1b74  movq xmm1, xmm1
0000798fc6fe1b78  movq xmm1, xmm1
0000798fc6fe1b7c  movaps [r15+0x1E0], xmm1
0000798fc6fe1b84  movq xmm15, xmm15
0000798fc6fe1b89  movq xmm15, xmm15
0000798fc6fe1b8e  movaps [r15+0x1D0], xmm15
0000798fc6fe1b96  lea r14, [rax+0x100]
0000798fc6fe1b9d  mov r12, [r13+r14*1]
0000798fc6fe1ba2  lea r14, [rax+0x108]
0000798fc6fe1ba9  mov r11, [r13+r14*1]
0000798fc6fe1bae  movq xmm1, r12
0000798fc6fe1bb3  movq xmm15, r11
0000798fc6fe1bb8  movq xmm1, xmm1
0000798fc6fe1bbc  movq xmm1, xmm1
0000798fc6fe1bc0  movaps [r15+0x200], xmm1
0000798fc6fe1bc8  movq xmm15, xmm15
0000798fc6fe1bcd  movq xmm15, xmm15
0000798fc6fe1bd2  movaps [r15+0x1F0], xmm15
0000798fc6fe1bda  mov qword ptr [r15+0x40], 0x430000
0000798fc6fe1be2  mov r14d, 0x430510
0000798fc6fe1be8  mov r12, [r13+r14*1]
0000798fc6fe1bed  movq xmm1, r12
0000798fc6fe1bf2  lea r14, [rax+0x150]
0000798fc6fe1bf9  mov [r15+0xF8], r14
0000798fc6fe1c00  mov rax, [r15+0x50]
0000798fc6fe1c04  movups xmm15, [r13+rax*1]
0000798fc6fe1c0a  movaps [r15+0x120], xmm15
0000798fc6fe1c12  mov qword ptr [r15+0x48], 0x10
0000798fc6fe1c1a  xor eax, eax
0000798fc6fe1c1c  mov r14d, 0x10
0000798fc6fe1c22  mov r12d, 0x200
0000798fc6fe1c28  cmp r14, r12
0000798fc6fe1c2b  cmc
0000798fc6fe1c2c  lahf
0000798fc6fe1c2d  seto al
0000798fc6fe1c30  mov [r15+0x108], eax
0000798fc6fe1c37  pextrq rax, xmm15, 0x01
0000798fc6fe1c3e  movq xmm14, rax
0000798fc6fe1c43  movaps [r15+0x130], xmm14
0000798fc6fe1c4b  movq rax, xmm1
0000798fc6fe1c50  movq r14, xmm15
0000798fc6fe1c55  vmovq xmm1, rax
0000798fc6fe1c5a  vmovq xmm15, r14
0000798fc6fe1c5f  movaps xmm13, xmm1
0000798fc6fe1c63  addsd xmm13, xmm15
0000798fc6fe1c68  ucomisd xmm13, xmm13
0000798fc6fe1c6d  jp 0x0000798FC6FE1D86
0000798fc6fe1c73  movq xmm13, xmm13
0000798fc6fe1c78  movq rax, xmm13
0000798fc6fe1c7d  movq r14, xmm14
0000798fc6fe1c82  vmovq xmm1, rax
0000798fc6fe1c87  vmovq xmm15, r14
0000798fc6fe1c8c  movaps xmm14, xmm1
0000798fc6fe1c90  addsd xmm14, xmm15
0000798fc6fe1c95  ucomisd xmm14, xmm14
0000798fc6fe1c9a  jp 0x0000798FC6FE1DCE
0000798fc6fe1ca0  movq xmm14, xmm14
0000798fc6fe1ca5  movaps [r15+0x110], xmm14
0000798fc6fe1cad  mov eax, [r15+0x108]
0000798fc6fe1cb4  sahf
0000798fc6fe1cb5  jnz 0x0000798FC6FE1CE7
0000798fc6fe1cb7  cmp dword ptr [r15+0x318], 0x00
0000798fc6fe1cbf  jz 0x0000798FC6FE1FE0
0000798fc6fe1cc5  nop [rax+rax*1], ax
0000798fc6fe1cce  nop [rax+rax*1], eax
0000798fc6fe1cd6  mov eax, 0x410490
0000798fc6fe1cdb  mov [r15+0x100], rax
0000798fc6fe1ce2  jmp 0x0000798FC6DFE110
0000798fc6fe1ce7  cmp dword ptr [r15+0x318], 0x00
0000798fc6fe1cef  jz 0x0000798FC6FE1E20
0000798fc6fe1cf5  nop [rax+rax*1], ax
0000798fc6fe1cfe  nop [rax+rax*1], eax
0000798fc6fe1d06  mov eax, 0x410474
0000798fc6fe1d0b  mov [r15+0x100], rax
0000798fc6fe1d12  jmp 0x0000798FC6DFE110
0000798fc6fe1d17  int3
0000798fc6fe1d18  call 0x0000798FC6EE27E0
0000798fc6fe1d1d  jmp 0x0000798FC6FE1AC3
0000798fc6fe1d22  call 0x0000798FC6EE27E0
0000798fc6fe1d27  jmp 0x0000798FC6FE1AD6
0000798fc6fe1d2c  call 0x0000798FC6EE1570
0000798fc6fe1d31  jmp 0x0000798FC6FE1AE2
0000798fc6fe1d36  call 0x0000798FC6EE27E0
0000798fc6fe1d3b  jmp 0x0000798FC6FE1B1A
0000798fc6fe1d40  call 0x0000798FC6EE1570
0000798fc6fe1d45  jmp 0x0000798FC6FE1B26
0000798fc6fe1d4a  call 0x0000798FC6EE27E0
0000798fc6fe1d4f  jmp 0x0000798FC6FE1B5E
0000798fc6fe1d54  call 0x0000798FC6EE1570
0000798fc6fe1d59  jmp 0x0000798FC6FE1B6A
0000798fc6fe1d5e  call 0x0000798FC6EE27E0
0000798fc6fe1d63  jmp 0x0000798FC6FE1BA2
0000798fc6fe1d68  call 0x0000798FC6EE1570
0000798fc6fe1d6d  jmp 0x0000798FC6FE1BAE
0000798fc6fe1d72  call 0x0000798FC6EE27E0
0000798fc6fe1d77  jmp 0x0000798FC6FE1BED
0000798fc6fe1d7c  call 0x0000798FC6E0E760
0000798fc6fe1d81  jmp 0x0000798FC6FE1C0A
0000798fc6fe1d86  ucomisd xmm1, xmm15
0000798fc6fe1d8b  jp 0x0000798FC6FE1D9A
0000798fc6fe1d8d  movaps xmm13, [0x0000798FC6BFE060]
0000798fc6fe1d95  jmp 0x0000798FC6FE1C73
0000798fc6fe1d9a  vxorps xmm0, xmm1, xmm15
0000798fc6fe1d9f  pextrw eax, xmm0, 0x03
0000798fc6fe1da4  and eax, 0x7FF8
0000798fc6fe1da9  cmp eax, 0x08
0000798fc6fe1dac  jnz 0x0000798FC6FE1C73
0000798fc6fe1db2  movq rax, xmm15
0000798fc6fe1db7  shl rax, 0x0D
0000798fc6fe1dbb  jbe 0x0000798FC6FE1C73
0000798fc6fe1dc1  vorps xmm13, xmm15, [0x0000798FC6BFE070]
0000798fc6fe1dc9  jmp 0x0000798FC6FE1C73
0000798fc6fe1dce  ucomisd xmm1, xmm15
0000798fc6fe1dd3  jp 0x0000798FC6FE1DE2
0000798fc6fe1dd5  movaps xmm14, [0x0000798FC6BFE060]
0000798fc6fe1ddd  jmp 0x0000798FC6FE1CA0
0000798fc6fe1de2  vxorps xmm0, xmm1, xmm15
0000798fc6fe1de7  pextrw eax, xmm0, 0x03
0000798fc6fe1dec  and eax, 0x7FF8
0000798fc6fe1df1  cmp eax, 0x08
0000798fc6fe1df4  jnz 0x0000798FC6FE1CA0
0000798fc6fe1dfa  movq rax, xmm15
0000798fc6fe1dff  shl rax, 0x0D
0000798fc6fe1e03  jbe 0x0000798FC6FE1CA0
0000798fc6fe1e09  vorps xmm14, xmm15, [0x0000798FC6BFE070]
0000798fc6fe1e11  jmp 0x0000798FC6FE1CA0
0000798fc6fe1e16  int3
0000798fc6fe1e17  nop [rax+rax*1], ax
0000798fc6fe1e20  mov rax, [r15+0x48]
0000798fc6fe1e24  mov r14, [r15+0x50]
0000798fc6fe1e28  lea r12, [r14+rax*1]
0000798fc6fe1e2c  movups xmm1, [r13+r12*1]
0000798fc6fe1e32  movaps [r15+0x120], xmm1
0000798fc6fe1e3a  lea r14, [rax+0x10]
0000798fc6fe1e3e  mov [r15+0x48], r14
0000798fc6fe1e42  xor eax, eax
0000798fc6fe1e44  mov r12d, 0x200
0000798fc6fe1e4a  cmp r14, r12
0000798fc6fe1e4d  cmc
0000798fc6fe1e4e  lahf
0000798fc6fe1e4f  seto al
0000798fc6fe1e52  mov [r15+0x108], eax
0000798fc6fe1e59  pextrq rax, xmm1, 0x01
0000798fc6fe1e60  movq xmm15, rax
0000798fc6fe1e65  movaps [r15+0x130], xmm15
0000798fc6fe1e6d  movaps xmm14, [r15+0x110]
0000798fc6fe1e75  movq rax, xmm14
0000798fc6fe1e7a  movq r14, xmm1
0000798fc6fe1e7f  vmovq xmm1, rax
0000798fc6fe1e84  vmovq xmm14, r14
0000798fc6fe1e89  movaps xmm13, xmm1
0000798fc6fe1e8d  addsd xmm13, xmm14
0000798fc6fe1e92  ucomisd xmm13, xmm13
0000798fc6fe1e97  jp 0x0000798FC6FE1F4C
0000798fc6fe1e9d  movq xmm13, xmm13
0000798fc6fe1ea2  movq rax, xmm13
0000798fc6fe1ea7  movq r14, xmm15
0000798fc6fe1eac  vmovq xmm1, rax
0000798fc6fe1eb1  vmovq xmm15, r14
0000798fc6fe1eb6  movaps xmm14, xmm1
0000798fc6fe1eba  addsd xmm14, xmm15
0000798fc6fe1ebf  ucomisd xmm14, xmm14
0000798fc6fe1ec4  jp 0x0000798FC6FE1F94
0000798fc6fe1eca  movq xmm14, xmm14
0000798fc6fe1ecf  movaps [r15+0x110], xmm14
0000798fc6fe1ed7  mov eax, [r15+0x108]
0000798fc6fe1ede  sahf
0000798fc6fe1edf  jnz 0x0000798FC6FE1F11
0000798fc6fe1ee1  cmp dword ptr [r15+0x318], 0x00
0000798fc6fe1ee9  jz 0x0000798FC6FE1FE0
0000798fc6fe1eef  nop [rax+rax*1], ax
0000798fc6fe1ef8  nop [rax+rax*1], eax
0000798fc6fe1f00  mov eax, 0x410490
0000798fc6fe1f05  mov [r15+0x100], rax
0000798fc6fe1f0c  jmp 0x0000798FC6DFE110
0000798fc6fe1f11  cmp dword ptr [r15+0x318], 0x00
0000798fc6fe1f19  jz 0x0000798FC6FE1E20
0000798fc6fe1f1f  nop [rax+rax*1], ax
0000798fc6fe1f28  nop [rax+rax*1], eax
0000798fc6fe1f30  mov eax, 0x410474
0000798fc6fe1f35  mov [r15+0x100], rax
0000798fc6fe1f3c  jmp 0x0000798FC6DFE110
0000798fc6fe1f41  int3
0000798fc6fe1f42  call 0x0000798FC6EB52F0
0000798fc6fe1f47  jmp 0x0000798FC6FE1E32
0000798fc6fe1f4c  ucomisd xmm1, xmm14
0000798fc6fe1f51  jp 0x0000798FC6FE1F60
0000798fc6fe1f53  movaps xmm13, [0x0000798FC6BFE060]
0000798fc6fe1f5b  jmp 0x0000798FC6FE1E9D
0000798fc6fe1f60  vxorps xmm0, xmm1, xmm14
0000798fc6fe1f65  pextrw eax, xmm0, 0x03
0000798fc6fe1f6a  and eax, 0x7FF8
0000798fc6fe1f6f  cmp eax, 0x08
0000798fc6fe1f72  jnz 0x0000798FC6FE1E9D
0000798fc6fe1f78  movq rax, xmm14
0000798fc6fe1f7d  shl rax, 0x0D
0000798fc6fe1f81  jbe 0x0000798FC6FE1E9D
0000798fc6fe1f87  vorps xmm13, xmm14, [0x0000798FC6BFE070]
0000798fc6fe1f8f  jmp 0x0000798FC6FE1E9D
0000798fc6fe1f94  ucomisd xmm1, xmm15
0000798fc6fe1f99  jp 0x0000798FC6FE1FA8
0000798fc6fe1f9b  movaps xmm14, [0x0000798FC6BFE060]
0000798fc6fe1fa3  jmp 0x0000798FC6FE1ECA
0000798fc6fe1fa8  vxorps xmm0, xmm1, xmm15
0000798fc6fe1fad  pextrw eax, xmm0, 0x03
0000798fc6fe1fb2  and eax, 0x7FF8
0000798fc6fe1fb7  cmp eax, 0x08
0000798fc6fe1fba  jnz 0x0000798FC6FE1ECA
0000798fc6fe1fc0  movq rax, xmm15
0000798fc6fe1fc5  shl rax, 0x0D
0000798fc6fe1fc9  jbe 0x0000798FC6FE1ECA
0000798fc6fe1fcf  vorps xmm14, xmm15, [0x0000798FC6BFE070]
0000798fc6fe1fd7  jmp 0x0000798FC6FE1ECA
0000798fc6fe1fdc  int3
0000798fc6fe1fdd  nop [rax], eax
0000798fc6fe1fe0  mov rax, [r15+0x40]
0000798fc6fe1fe4  lea r14, [rax+0x510]
0000798fc6fe1feb  movaps xmm1, [r15+0x110]
0000798fc6fe1ff3  movq rax, xmm1
0000798fc6fe1ff8  mov [r13+r14*1], rax
0000798fc6fe1ffd  mov rax, [r15+0xF0]
0000798fc6fe2004  mov [r15+0x100], rax
0000798fc6fe200b  jmp 0x0000798FC6FCE5C0
0000798fc6fe2010  int3
0000798fc6fe2011  call 0x0000798FC6ED5EB0
0000798fc6fe2016  jmp 0x0000798FC6FE1FFD
0000798fc6fe201b  int3
0000798fc6fe201c  nop [rax], eax
0000798fc6fe2020  mov qword ptr [r15+0x100], 0x04
0000798fc6fe202b  mov esi, 0x00
0000798fc6fe2030  mov edx, 0x09
0000798fc6fe2035  mov rdi, 0x7FFC64E54C40
0000798fc6fe203f  mov rax, 0x63E5589B6970
0000798fc6fe2049  call rax
0000798fc6fe204b  cmp dword ptr [r15+0x318], 0x00
0000798fc6fe2053  jnz 0x0000798FC6DFE110
0000798fc6fe2059  jmp 0x0000798FC6DFE0A0
0000798fc6fe205e  int3
0000798fc6fe205f  int3
